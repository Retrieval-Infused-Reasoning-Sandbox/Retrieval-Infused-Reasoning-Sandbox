# Smart "Predict, then Optimize"

## Adam N. Elmachtoub

Department of Industrial Engineering and Operations Research and Data Science Institute, Columbia University, New York, NY 10027, adam@ieor.columbia.edu

## Paul Grigas

Department of Industrial Engineering and Operations Research, University of California, Berkeley, CA 94720, pgrigas@berkeley.edu

Many real-world analytics problems involve two significant challenges: prediction and optimization. Due to the typically complex nature of each challenge, the standard paradigm is predict-then-optimize. By and large, machine learning tools are intended to minimize prediction error and do not account for how the predictions will be used in the downstream optimization problem. In contrast, we propose a new and very general framework, called Smart "Predict, then Optimize" (SPO), which directly leverages the optimization problem structure, i.e., its objective and constraints, for designing better prediction models. A key component of our framework is the SPO loss function which measures the decision error induced by a prediction.

Training a prediction model with respect to the SPO loss is computationally challenging, and thus we derive, using duality theory, a convex surrogate loss function which we call the SPO+ loss. Most importantly, we prove that the SPO+ loss is statistically consistent with respect to the SPO loss under mild conditions. Our SPO+ loss function can tractably handle any polyhedral, convex, or even mixed-integer optimization problem with a linear objective. Numerical experiments on shortest path and portfolio optimization problems show that the SPO framework can lead to significant improvement under the predict-then-optimize paradigm, in particular when the prediction model being trained is misspecified. We find that linear models trained using SPO+ loss tend to dominate random forest algorithms, even when the ground truth is highly nonlinear.

Key words : prescriptive analytics; data-driven optimization; machine learning; linear regression

## 1. Introduction

In many real-world analytics applications of operations research, a combination of both machine learning and optimization are used to make decisions. Typically, the optimization model is used to generate decisions, while a machine learning tool is used to generate a prediction model that predicts key unknown parameters of the optimization model. Due to the inherent complexity of both tasks, a broad purpose approach that is often employed in analytics practice is the *predict-then-optimize* paradigm.

For example, consider a vehicle routing problem that may be solved several times a day. First, a previously trained prediction model provides predictions for the travel time on all edges of a road network based on current traffic, weather, holidays, time, etc. Then, an optimization solver provides near-optimal routes using the predicted travel times as input. We emphasize that most solution systems for real-world analytics problems involve some component of both prediction and optimization (see [Angalakudati et al. \(2014](#page-30-0)), [Chan et al.](#page-32-0) [\(2012\)](#page-32-0), [Deo et al.](#page-32-1) [\(2015](#page-32-1)), [Gallien et al. \(2015\)](#page-33-0), [Cohen et al.](#page-32-2) [\(2017](#page-32-2)), [Besbes et al. \(2015](#page-31-0)), [Mehrotra et al. \(2011](#page-33-1)), [Chan et al.](#page-32-3) [\(2013](#page-32-3)), [Ferreira et al. \(2015](#page-33-2)) for recent examples and recent expositions by [Simchi-Levi \(2013](#page-34-0)), [den Hertog and Postek \(2016](#page-32-4)), [Deng et al. \(2018](#page-32-5)), [Mišić and Perakis \(2020](#page-33-3))). Except for a few limited options, machine learning tools do not effectively account for how the predictions will be used in a downstream optimization problem. In this paper, we provide a general framework called Smart "Predict, then Optimize" (SPO) for training prediction models that effectively utilize the structure of the nominal optimization problem, i.e., its constraints and objective. *Our SPO framework is fundamentally designed to generate prediction models that aim to minimize decision error, not prediction error.*

One key benefit of our SPO approach is that it maintains the decision paradigm of sequentially predicting and then optimizing. However, when training our prediction model, the structure of the nominal optimization problem is explicitly used. The quality of a prediction is *not* measured based on prediction error such as least squares loss or other popular loss functions. Instead, in the SPO framework, the quality of a prediction is measured by the decision error. That is, suppose a prediction model is trained using historical feature data (x1, . . ., xn) and associated parameter data (c1, . . ., cn). Let (ˆc1, . . ., cˆn) denote the predictions of the parameters under the trained model. The least squares (LS) loss, for example, measures error with the squared norm kc<sup>i</sup> − cˆik 2 2 , completely ignoring the decisions induced by the predictions. In contrast, the *SPO loss* is the true cost of the decision induced by cˆ<sup>i</sup> minus the optimal cost under the true parameter c<sup>i</sup> . In the context of vehicle routing, the SPO loss measures the extra travel time incurred due to solving the routing problem on the predicted, rather than true, edge cost parameters.

In this paper, we focus on predicting unknown parameters of a contextual stochastic optimization problem, where the parameters appear linearly in the objective function, i.e., the cost vector of any linear, convex, or integer optimization problem. The core of our SPO framework is a new loss function for training prediction models. Since the SPO loss function is difficult to work with, significant effort revolves around deriving a surrogate loss function, SPO+, that is convex and therefore can be optimized efficiently. To show the validity of

the surrogate SPO+ loss, we prove a highly desirable statistical consistency property, and show it performs well empirically compared to standard predict-then-optimize approaches. In essence, we prove that the function that minimizes the Bayes risk associated to the SPO+ loss is the regression function E[c|x], which also minimizes the Bayes risk of the SPO loss (under mild assumptions). Interestingly, E[c|x] also minimizes the Bayes risk associated to the LS loss under the same conditions. Thus, SPO+ and LS (or any convex combination of the two) are essentially on "equal footing" – they are both theoretically valid (consistent) and computationally tractable choices for the loss function. However, when the ultimate goal is to solve a downstream optimization task, the SPO+ loss is the natural choice as it is tailored to the optimization problem and works significantly better in practice than LS.

Empirically, we observe that even when the prediction task is challenging due to model misspecification, the SPO framework can still yield near-optimal decisions. We note that a fundamental property of the SPO framework is the requirement that the prediction is directly "plugged in" to the downstream optimization problem. An alternative procedure may alter the decision making process in some way, such as by adding robustness or by taking into account the entire dataset (instead of just the prediction). A strong advantage of our SPO approach is that it has good performance even when the naive prediction problem is challenging, see the illustrative example in Section [3.1.](#page-12-0) Another advantage is that the downstream optimization problem is typically more computationally tractable and more attractive to practitioners than a more complex alternative procedure. On the other hand, alternative decision making procedures may provide other advantages, such as improved generalization performance via the introduction of bias and/or robustness. However, designing such procedures is more challenging in the presence of contextual data and combining them with the SPO approach would be worthwhile of future research. Overall, we believe our SPO framework provides a clear foundation for designing operations-driven machine learning tools that can be leveraged in real-world optimization settings.

Our contributions may be summarized as follows:

1. We first formally define a new loss function, which we call the SPO loss, that measures the error in predicting the cost vector of a nominal optimization problem with linear, convex, or integer constraints. The loss corresponds to the suboptimality gap – with respect to the true/historical cost vector – due to implementing a possibly incorrect decision induced by the predicted cost vector. Unfortunately, the SPO loss function can be nonconvex and

- discontinuous in the predictions, implying that training ML models under the SPO loss may be challenging.
- 2. Given the intractability of the SPO loss function, we develop a surrogate loss function which we call the SPO+ loss. This surrogate loss function is derived using a sequence of steps motivated by duality theory (Proposition [2\)](#page-15-0), a data scaling approximation, and a first-order approximation. The resulting SPO+ loss function is convex in the predictions (Proposition [3\)](#page-17-0), which allows us to design an algorithm based on stochastic gradient descent for minimizing SPO+ loss (Proposition [8\)](#page-42-0). Moreover, when training a linear regression model to predict the objective coefficients of a linear program, only a linear optimization problem needs be solved to minimize the SPO+ loss (Proposition [7\)](#page-24-0).
- 3. We prove a fundamental connection to classical machine learning under a very simple and special instance of our SPO framework. Namely, under this instance the SPO loss is exactly the 0-1 classification loss (Proposition [1\)](#page-11-0) and the SPO+ loss is exactly the hinge loss (Proposition [4\)](#page-17-1). The hinge loss is the basis of the popular SVM method and is a surrogate loss to approximately minimize the 0-1 loss, and thus our framework generalizes this concept to a very wide family of optimization problems with constraints.
- 4. We prove a key consistency result of the SPO+ loss function (Theorem [1,](#page-20-0) Proposition [5,](#page-21-0) Proposition [6\)](#page-22-0), which further motivates its use. Namely, under full distributional knowledge, minimizing the SPO+ loss function is in fact equivalent to minimizing the SPO loss if two mild conditions hold: the distribution of the cost vector (given the features) is continuous and symmetric about its mean. For example, these assumptions are satisfied by the standard Gaussian noise approximation. *This consistency property is widely regarded as an essential property of any surrogate loss function across the statistics and machine learning literature.* For example, the famous hinge loss and logistic loss functions are consistent with the 0-1 classification loss.
- 5. Finally, we validate our framework through numerical experiments on the shortest path and portfolio optimization problem. We test our SPO framework against standard predictthen-optimize approaches, and evaluate the out of sample performance with respect to the SPO loss. Generally, the value of our SPO framework increases as the degree of model misspecification increases. This is precisely due to the fact the SPO framework makes "better" wrong predictions, essentially "tricking" the optimization problem into finding near-optimal solutions. Remarkably, a linear model trained using SPO+ even dominates a state-of-the-art random forests algorithm, even when the ground truth is highly nonlinear.

## <span id="page-4-0"></span>1.1. Applications

Settings where the input parameters (cost vectors) of an optimization problem need to be predicted from contextual (feature) data are numerous. Let us now highlight a few, of potentially many, application areas for the SPO framework.

Vehicle Routing. In numerous applications, the cost of each edge of a graph needs to be predicted before making a routing decision. The cost of an edge typically corresponds to the expected length of time a vehicle would need to traverse the corresponding edge. For clarity, let us focus on one important example – the shortest path problem. In the shortest path problem, one is given a weighted directed graph, along with an origin node and destination node, and the goal is to find a sequence of edges from the origin to the destination at minimum possible cost. A well-known fact is that the shortest path problem can be formulated as a linear optimization problem, but there are also alternative specialized algorithms such as the famous Dijkstra's algorithm (see, e.g., [Ahuja et al. \(1993](#page-30-1))). The data used to predict the cost of the edges may incorporate the length, speed limit, weather, season, day, and real-time data from mobile applications such as Google Maps and Waze. Simply minimizing prediction error may not suffice nor be appropriate, as over- or under-predictions have starkly different effects across the network. The SPO framework would ensure that the predicted weights lead to shortest paths, and would naturally emphasize the estimation of edges that are critical to this decision. See Figure [3](#page-14-0) in Section [2](#page-37-0) for an in-depth example.

Inventory Management. In inventory planning problems such as the economic lot sizing problem [\(Wagner and Whitin \(1958\)](#page-35-0)) or the joint replenishment problem [\(Levi et al.](#page-33-4) [\(2006\)](#page-33-4)), the demand is the key input into the optimization model. In practical settings, demand is highly nonstationary and can depend on historical and contextual data such as weather, seasonality, and competitor sales. The decisions of when to order inventory are captured by a linear or integer optimization model, depending on the complexity of the problem. Under a common formulation (see [Levi et al. \(2006\)](#page-33-4), [Cheung et al. \(2016](#page-32-6))), the demand appears linearly in the objective, which is convenient for the SPO framework. The goal is to design a prediction model that maps feature data to demand predictions, which in turn lead to good inventory plans.

Portfolio Optimization. In financial services applications, the returns of potential investments need to be somehow estimated from data, and can depend on many features which typically include historical returns, news, economic factors, social media, and others. In portfolio optimization, the goal is to find a portfolio with the highest return subject to a constraint on the total risk, or variance, of the portfolio. While the returns are often highly dependent on auxiliary feature information, the variances are typically much more stable and are not as difficult nor sensitive to predict. Our SPO framework would result in predictions that lead to high performance investments that satisfy the desired level of risk. A least squares loss approach places higher emphasis on estimating higher valued investments, even if the corresponding risk may not be ideal. In contrast, the SPO framework directly accounts for the risk of each investment when training the prediction model.

## 1.2. Related Literature

Perhaps the most related work is that of [Kao et al. \(2009\)](#page-33-5), who also directly seek to train a machine learning model that minimizes loss with respect to a nominal optimization problem. In their framework, the nominal problem is an unconstrained quadratic optimization problem, where the unknown parameters appear in the linear portion of the objective. Their work does not extend to settings where the nominal optimization problem has constraints, which our framework does. [Donti et al. \(2017\)](#page-32-7) proposes a heuristic to address a more general setting than that of [Kao et al. \(2009\)](#page-33-5), and also focus on the case of quadratic optimization. These works also bypass issues of non-uniqueness of solutions of the nominal problem (since their problem is strongly convex), which must be addressed in our setting to avoid degenerate prediction models.

In [Ban and Rudin \(2019\)](#page-31-1), ML models are trained to directly predict the optimal solution of a newsvendor problem from data. Tractability and statistical properties of the method are shown as well as its effectiveness in practice. However, it is not clear how this approach can be used when there are constraints, since feasibility issues may arise.

The general approach in [Bertsimas and Kallus](#page-31-2) [\(2020\)](#page-31-2) considers the problem of accurately estimating an unknown optimization objective using machine learning models, specifically ML models where the predictions can be described as a weighted combination of training samples, e.g., nearest neighbors and decision trees. In their approach, they estimate the objective of an instance by applying the same weights generated by the ML model to the corresponding objective functions of those samples. This approach differs from standard predict-then-optimize *only* when the objective function is nonlinear in the unknown parameter. Note that the unknown parameters of all the applications mentioned in Section [1.1](#page-4-0)

appear linearly in the objective. Moreover, the training of the ML models does not rely on the structure of the nominal optimization problem, in contrast to the SPO framework.

The approach in [Tulabandhula and Rudin \(2013\)](#page-34-1) relies on minimizing a loss function that combines the prediction error with the operational cost of the model on an unlabeled dataset. However, the operational cost is with respect to the predicted parameters, and not the true parameters. [Gupta and Rusmevichientong \(2017](#page-33-6)) consider combining estimation and optimization in a setting without features/contexts. We also note that our SPO loss, while mathematically different, is similar in spirit to the notion of relative regret introduced in [Lim et al. \(2012\)](#page-33-7) in the specific context of portfolio optimization with historical return data and without features. Other approaches for finding near-optimal solutions from data include operational statistics [\(Liyanage and Shanthikumar \(2005](#page-33-8)), [Chu et al. \(2008](#page-32-8))), sample average approximation [\(Kleywegt et al. \(2002\)](#page-33-9), [Schütz et al. \(2009\)](#page-34-2), [Bertsimas et al. \(2018b\)](#page-31-3)), and robust optimization [\(Bertsimas and Thiele \(2006\)](#page-31-4), [Bertsimas et al. \(2018a](#page-31-5)), [Wang et al.](#page-35-1) [\(2016\)](#page-35-1)). There has also been some recent progress on submodular optimization from samples [\(Balkanski et al. \(2016,](#page-30-2) [2017\)](#page-30-3)). These approaches typically do not have a clear way of using feature data, nor do they directly consider how to train a machine learning model to predict optimization parameters.

Another related stream of work is in data-driven inverse optimization, where feasible or optimal solutions to an optimization problem are observed and the objective function has to be learned [\(Aswani et al. \(2018](#page-30-4)), [Keshavarz et al.](#page-33-10) [\(2011\)](#page-33-10), [Chan et al. \(2014](#page-32-9)), [Bertsimas et al. \(2015](#page-31-6)), [Esfahani et al. \(2018\)](#page-32-10)). In these problems, there is typically a single unknown objective, and no previous samples of the objective are provided. We also note there have been recent approaches for regularization [\(Ban et al. \(2018](#page-31-7))) and model selection [\(Besbes et al. \(2010\)](#page-31-8), [Den Boer and Sierag \(2016\)](#page-32-11), [Sen and Deng \(2017\)](#page-34-3)) in the context of an optimization problem.

Lastly, we note that our framework is related to the general setting of structured prediction (see, e.g., [Taskar et al.](#page-34-4) [\(2005\)](#page-34-4), [Tsochantaridis et](#page-34-5) al. [\(2005](#page-34-5)), [Nowozin et al. \(2011](#page-34-6)), [Osokin et al. \(2017](#page-34-7)) and the references therein). Motivated by problems in computer vision and natural language processing, structured prediction is a version of multiclass classification that is concerned with predicting structured objects, such as sequences or graphs, from feature data. The SPO+ loss is similar in spirit to that of the structured SVM (SSVM) and is indeed a convex, upper bound on the SPO loss, akin to the SSVM. However, there

are fundamental differences with our approach and the the SSVM approach. In the SSVM approach, the structured object one would be predicting is the decision w directly from the feature x [\(Taskar et al.](#page-34-4) [\(2005\)](#page-34-4)). In our setting, we have access to historical data on c which is richer than observations of decisions, since cost vectors induce optimal decisions naturally. Under one special case of our framework, we prove that the SPO loss is equivalent to 0/1 loss, while the SPO+ loss is equivalent to the hinge loss. Thus, our framework can be seen as a type of generalization of the SSVM. Finally, we remark that our derivation of the surrogate SPO+ loss relies on completely new ideas using duality theory, which help explain the strong empirical performance.

## 2. "Predict, then Optimize" Framework

We now describe the "Predict, then Optimize" framework which is central to many applications of optimization in practice. Specifically, we assume that there is a nominal optimization problem of interest with a linear objective, where the decision variable w ∈ R <sup>d</sup> and feasible region S ⊆ R <sup>d</sup> are well-defined and known with certainty. However, the cost vector of the objective, c ∈ R d , is not available at the time the decision must be made; instead, an associated feature vector x ∈ R p is available. Let D<sup>x</sup> be the conditional distribution of c given x. The goal for the decision maker is to solve, for any new instance characterized by x, is to solve the contextual stochastic optimization problem

<span id="page-7-1"></span>
$$\min_{w \in S} \mathbb{E}_{c \sim \mathcal{D}_x}[c^\top w | x] = \min_{w \in S} \mathbb{E}_{c \sim \mathcal{D}_x}[c | x]^\top w . \tag{1}$$

The predict-then-optimize framework relies on using a prediction for <sup>E</sup><sup>c</sup>∼D<sup>x</sup> [c|x], which we denote by cˆ, and solving the deterministic version of the optimization problem based on cˆ, i.e., min<sup>w</sup>∈<sup>S</sup> cˆ <sup>⊤</sup>w. Our primary interests in this paper concern defining suitable loss functions for the predict-then-optimize framework, examining their properties, and developing algorithms for training prediction models using these loss functions.

We now formally list the key ingredients of our framework:

1. *Nominal (downstream) optimization problem*, which is of the form

<span id="page-7-0"></span>
$$P(c): z^*(c) := \min_{w} c^T w$$
s.t.  $w \in S$ , (2)

where w ∈ R d are the decision variables, c ∈ R d is the problem data describing the linear objective function, and S ⊆ R d is a nonempty, compact (i.e., closed and bounded), and convex set representing the feasible region. Since we are focusing on *linear* optimization problems herein, the assumptions that S is convex and closed are without loss of generality. Indeed, if S in [\(2\)](#page-7-0) is instead possibly non-convex or non-closed, then replacing S by its closed convex hull does not change the optimal value z ∗ (c) (Lemma 8 in [Jaggi](#page-33-11) [\(2011\)](#page-33-11)). Thus, this basic equivalence for linear optimization problems implies that our methodology can be applied to combinatorial and mixed-integer optimization problems, which we elaborate further on in Section [3.2.](#page-13-0) Since S is assumed to be fixed and known with certainty, every problem instance can be described by the corresponding cost vector, hence the dependence on c in [\(2\)](#page-7-0). When solving a particular instance where c is unknown, a prediction for c is used instead. We assume access to a practically efficient optimization oracle, w ∗ (c), that returns a solution of P(c) for any input cost vector. For instance, if [\(2\)](#page-7-0) corresponds to a linear, conic, or a mixed-integer optimization problem, then a commercial optimization solver or a specialized algorithm suffices for w ∗ (c).

- 2. *Training data* of the form (x1, c1),(x2, c2), . . .,(xn, cn), where x<sup>i</sup> ∈ X is a feature vector representing contextual information associated with c<sup>i</sup> .
- 3. A *hypothesis class* H of cost vector prediction models f : X → R d , where cˆ := f(x) is interpreted as the predicted cost vector associated with feature vector x.
- 4. A *loss function* ℓ(·, ·) : R <sup>d</sup> × R <sup>d</sup> → R+, whereby ℓ(ˆc, c) quantifies the error in making prediction cˆ when the realized (true) cost vector is actually c.

Given the loss function ℓ(·, ·) and the training data (x1, c1), . . .,(xn, cn), the empirical risk minimization (ERM) principle states that we should determine a prediction model f <sup>∗</sup> ∈ H by solving the optimization problem

<span id="page-8-0"></span>
$$\min_{f \in \mathcal{H}} \frac{1}{n} \sum_{i=1}^{n} \ell(f(x_i), c_i) . \tag{3}$$

Provided with the prediction model f <sup>∗</sup> and given a feature vector x, the predict-then-optimize decision rule is to choose the optimal solution with respect to the predicted cost vector, i.e., w ∗ (f ∗ (x)). Example [1](#page-36-0) in Appendix [A](#page-36-1) contextualizes our framework in the context of a network optimization problem.

In standard applications of the "Predict, then Optimize" framework, as in Example [1,](#page-36-0) the loss function that is used is completely independent of the nominal optimization problem. In other words, the underlying structure of the optimization problem P(·) does not factor into the loss function and therefore the training of the prediction model. For example, when

ℓ(ˆc, c) = <sup>1</sup> 2 kcˆ− ck 2 2 , this corresponds to the least squares (LS) loss function. Moreover, if H is a set of linear predictors, then [\(3\)](#page-8-0) reduces to a standard least squares linear regression problem. In contrast, our focus in Section [3](#page-42-1) is on the construction of loss functions that measure decision errors in predicting cost vectors by leveraging problem structure.

Useful Notation. Let p be the dimension of a feature vector, d be the dimension of a decision vector, and n be the number of training samples. Let W<sup>∗</sup> (c) := arg min<sup>w</sup>∈<sup>S</sup> c <sup>T</sup> w denote the set of optimal solutions of P(·), and let w ∗ (·) : R <sup>d</sup> → S denote a particular *oracle* for solving P(·). That is, w ∗ (·) is a fixed deterministic mapping such that w ∗ (c) ∈ W<sup>∗</sup> (c). Note that nothing special is assumed about the mapping w ∗ (·), hence w ∗ (c) may be regarded as an arbitrary element of W<sup>∗</sup> (c). Let ξS(·) : R <sup>d</sup> → R denote the support function of S, which is defined by ξS(c) := max<sup>w</sup>∈<sup>S</sup>{c <sup>T</sup>w}. Since S is compact, ξS(·) is finite everywhere, the maximum in the definition is attained for every c ∈ R d , and note that ξS(c) = −z ∗ (−c) = c <sup>T</sup>w ∗ (−c) for all c ∈ R d . Recall also that ξS(·) is a convex function. For a given convex function h(·) : R <sup>d</sup> → R, recall that g ∈ R d is a subgradient of h(·) at c ∈ R d if h(c ′ ) ≥ h(c) + g T (c ′ − c) for all c ′ ∈ R d , and the set of subgradients of h(·) at c is denoted by ∂h(c). For two matrices B1, B<sup>2</sup> ∈ R d×p , the trace inner product is denoted by B<sup>1</sup> • B<sup>2</sup> := trace(B<sup>T</sup> <sup>1</sup> B2). Finally, we note that the name of the framework is inspired by [Farias \(2007\)](#page-33-12).

# 3. SPO Loss Functions

Herein, we introduce several loss functions that fall into the predict-then-optimize paradigm, but that are also *smart* in that they take the nominal optimization problem P(·) into account when measuring errors in predictions. We refer to these loss functions as Smart "Predict, then Optimize" (SPO) loss functions. As a starting point, let us consider a true SPO loss function that exactly measures the excess cost incurred when making a suboptimal decision due to an imprecise cost vector prediction. Following the PO paradigm, given a cost vector prediction cˆ, a decision w ∗ (ˆc) is implemented based on solving P(ˆc). After the decision w ∗ (ˆc) is implemented, the cost incurred is with respect to the cost vector c that is *actually realized*. The excess cost due to the fact that w ∗ (ˆc) may be suboptimal with respect to c is then c <sup>T</sup>w ∗ (ˆc) − z ∗ (c), which we call the SPO loss. In Figure [1,](#page-10-0) we show how two predicted values of c with the same prediction error can result in different decisions and different SPO losses. In fact, Figure [1](#page-10-0) shows that the SPO loss can be 0 when S is a polyhedron if −cˆ lies in the cone corresponding to the extreme point w ∗ (c), or when S is an ellipse and cˆ is in the same

Figure 1 Geometric Illustration of SPO Loss

<span id="page-10-0"></span>![](_page_10_Figure_3.jpeg)

Note. In these two figures, we consider a two-dimensional polyhedron and ellipse for the feasible region S. We plot the (negative) of the true cost vector c, as well as two candidate predictions cˆ<sup>A</sup> and cˆ<sup>B</sup> that are equidistant from c and thus have equivalent LS loss. One can see that the optimal decision for cˆ<sup>A</sup> coincides with that of c, since w ∗ (ˆcA) = w ∗ (c). In the polyhedron example, any predicted cost vector whose negative is not in the gray region will result in a wrong decision, where as in the ellipse example any predicted cost vector that is not exactly parallel with c results in a wrong decision.

<span id="page-10-1"></span>direction and parallel to c. Definition [1](#page-10-1) formalizes this true SPO loss associated with making the prediction cˆ when the actual cost vector is c, given a particular oracle w ∗ (·) for P(·).

Definition 1 (SPO Loss). Given a cost vector prediction cˆ and a realized cost vector c, the *true SPO loss* ℓ w∗ SPO(ˆc, c) w.r.t. optimization oracle w ∗ (·) is defined as ℓ w∗ SPO(ˆc, c) := c <sup>T</sup> w ∗ (ˆc) − z ∗ (c) .

Note that there is an unfortunate deficiency in Definition [1,](#page-10-1) which is the dependence on the particular oracle w ∗ (·) used to solve [\(2\)](#page-7-0). Practically speaking, this deficiency is not a major issue since we should usually expect w ∗ (ˆc) to be a unique optimal solution, i.e., we should expect W<sup>∗</sup> (ˆc) to be a singleton. Note that if any solution from W<sup>∗</sup> (ˆc) may be used by the loss function, then the loss function essentially becomes min<sup>w</sup>∈W∗(ˆc) c <sup>T</sup>w −z ∗ (c). Thus, a prediction model would then be incentivized to always make the degenerate prediction cˆ= 0 since W<sup>∗</sup> (0) = S. This would then imply that the SPO loss is 0.

<span id="page-10-2"></span>In any case, if one wishes to address the dependence on the particular oracle w ∗ (·) in Definition [1,](#page-10-1) then it is most natural to "break ties" by presuming that the implemented decision has worst-case behavior with respect to c. Definition [2](#page-10-2) is an alternative SPO loss function that does not depend on the particular choice of the optimization oracle w ∗ (·).

Definition 2 (Unambiguous SPO Loss). Given a cost vector prediction cˆ and a realized cost vector c, the (unambiguous) *true SPO loss* ℓSPO(ˆc, c) is defined as ℓSPO(ˆc, c) := max<sup>w</sup>∈W∗(ˆc) c <sup>T</sup>w − z ∗ (c).

Note that Definition [2](#page-10-2) presents a version of the true SPO loss that upper bounds the version from Definition [1,](#page-10-1) i.e., it holds that ℓ w∗ SPO(ˆc, c) ≤ ℓSPO(ˆc, c) for all c, c ˆ ∈ R d . As mentioned previously, the distinction between Definitions [1](#page-10-1) and [2](#page-10-2) is only relevant in degenerate cases. In the results and discussion herein, we work with the unambiguous true SPO loss given by Definition [2.](#page-10-2) Related results may often be inferred for the version of the true SPO loss given by Definition [1](#page-10-1) by recalling that Definition [2](#page-10-2) upper bounds Definition [1](#page-10-1) and that the two loss functions are almost always equal except for degenerate cases where W<sup>∗</sup> (ˆc) has multiple optimal solutions.

Notice that ℓSPO(ˆc, c) is impervious to the scaling of cˆ, in other words it holds that ℓSPO(αc, c ˆ ) = ℓSPO(ˆc, c) for all α > 0. This property is intuitive since the true loss associated with prediction cˆ should only depend on the optimal *solution* of P(·), which does not depend on the scaling of cˆ. Moreover, this property is also shared by the 0-1 loss function in binary classification problems. Namely, labels can take values in the set {−1,+1} and the prediction model predicts values in R. If the predicted value has the same sign as the true value, the loss is 0, and otherwise the loss is 1. That is, given a predicted value cˆ∈ R and a label <sup>c</sup> ∈ {−1,+1}, the 0-1 loss function is defined by <sup>ℓ</sup><sup>0</sup>−<sup>1</sup>(ˆc, c) := <sup>1</sup>(sgn(ˆc) = <sup>c</sup>) where sgn(·) is the sign function and 1(·) is an indicator function equal to 1 if its input is true and 0 otherwise. Therefore, the 0-1 loss function is also independent of the scale on the predictions. This similarity is not a coincidence; in fact, Proposition [1](#page-11-0) illustrates that binary classification is a special case of the SPO framework. All proofs can be found in Appendix [B.](#page-37-0)

<span id="page-11-0"></span>Proposition 1 (SPO Loss Generalizes 0-1 loss). *When* S = [−1/2,+1/2] *and* c ∈ {−1,+1}*, then* ℓSPO(ˆc, c) = 1(*sgn*(ˆc) = c)*, i.e., the SPO loss function exactly matches the 0-1 loss function associated with binary classification.*

Now, given the training data, we are interested in determining a cost vector prediction model with minimal true SPO loss. Therefore, given the previous definition of the true SPO loss ℓSPO(·, ·), the prediction model would be determined by following the empirical risk minimization principle as in [\(3\)](#page-8-0), which leads to the following optimization problem:

<span id="page-11-1"></span>
$$\min_{f \in \mathcal{H}} \frac{1}{n} \sum_{i=1}^{n} \ell_{SPO}(f(x_i), c_i) . \tag{4}$$

Unfortunately, the above optimization problem is difficult to solve, both in theory and in practice. Indeed, for a fixed c, ℓSPO(·, c) may not even be continuous in cˆ since w ∗ (ˆc) (and the entire set W<sup>∗</sup> (ˆc)) may not be continuous in cˆ. Moreover, since Proposition [1](#page-11-0) demonstrates that our framework captures binary classification, solving [\(4\)](#page-11-1) is at least as difficult as optimizing the 0-1 loss function, which may be NP-hard in many cases [\(Ben-David et al.](#page-31-9) [2003\)](#page-31-9). We are therefore motivated to develop approaches for producing "reasonable" approximate solutions to [\(4\)](#page-11-1) that *(i)* outperform standard PO approaches, and *(ii)* are applicable to large-scale problems where the number of training samples n and/or the dimension of the hypothesis class H may be very large.

## <span id="page-12-0"></span>3.1. An Illustrative Example

In order to build intuition, we now compare the SPO loss against the classical least squares (LS) loss function via an illustrative example. Consider a very simple shortest path problem with two nodes s and t. There are two edge that go from s to t, edge 1 and edge 2. Thus, a cost vector c is 2-dimensional in this setting, and the goal is to simply choose the edge with the lower cost. We shall not observe c directly at the decision-making time, but rather just a 1-dimensional feature x associated with the vector c. Our data consists of (x<sup>i</sup> , ci) pairs, and c<sup>i</sup> are generated nonlinearly as a function of x<sup>i</sup> .

<span id="page-12-1"></span>![](_page_12_Figure_5.jpeg)

Note. In (a), the residuals for the LS loss function are marked by the dashed lines. The residual is the distance between the prediction and the true value. In (b), the residuals for the SPO loss function are marked by the dashed black lines. The residual is 0 when the predicted values are in the right order. Otherwise, the residual is the distance between the true values.

The goal of the decision maker is to predict the cost of each edge from the feature using a simple linear regression model. The intersection of the two lines (corresponding to each edge) will signal the decision boundary in the predict-then-optimize framework. The decision maker shall try both the SPO and LS loss functions to do the linear regression. In Figure [2,](#page-12-1) we illustrate the difference between LS and SPO by visualizing the residuals for one particular dataset and linear models for prediction the edge 1 and edge 2 costs. In LS regression, one minimizes the sum of the residuals squared, which is denoted by the dashed green and red lines in Figure [2\(](#page-12-1)a). When using SPO loss, we consider "decision residuals" which only occur when the predictions result in choosing the wrong edge. In these cases, the SPO cost is the magnitude difference between the two true costs of edge 1 and edge 2, as depicted in Figure [2\(](#page-12-1)b).

In Figure [3,](#page-14-0) we consider another dataset, but this time plot the optimal LS and SPO linear regression models. In the first panel of Figure [3,](#page-14-0) we plot the dataset and the optimal decision boundary. In the second panel, we plot the best LS fit to the data, and in the last two panels we plot two different optimal solutions to the SPO linear regression. (In fact, the SPO fitted models are also optimal for SPO+ loss which we derive in Section [3.2.](#page-13-0)) Note that the the SPO loss in Figure [3](#page-14-0) is 0, as there are no decision errors as described in Figure [2.](#page-12-1)

One can see from Figure [3](#page-14-0) that the LS lines very closely approximate the nonlinear data, although the decision boundary for LS is quite far from the optimal decision boundary. For any value of x between the dotted black and red lines, the decision maker will choose the wrong edge. In contrast, the SPO lines need not approximate the data well at all, yet its decision boundary is nearly-optimal. In fact, the SPO lines have 0 training error, despite not fitting the data at all. The key intuition is that the SPO loss is incurred anytime the wrong edge is chosen, and in this example one can construct lines that cross at the right decision boundary so that the wrong edge is never chosen, resulting in zero SPO loss. Note that the only important consideration is where the lines intersect, and thus the SPO linear regression does not necessarily minimize prediction error. Of course, a convex combination of SPO and LS loss may be used to overcome the unusual looking lines generated. In fact, there are infinitely optimal solutions to the ERM problem for the SPO loss, all of which just require that the intersection of the lines occurs between the x values of 0.8 and 0.9.

# <span id="page-13-0"></span>3.2. The SPO+ Loss Function

In this section, we focus on deriving a tractable surrogate loss function that reasonably approximates ℓSPO(·, ·). Our surrogate function ℓSPO+(·, ·), which we call the SPO+ loss function, can be derived in a few steps that we shall carefully justify below. Ideally, when

<span id="page-14-0"></span>![](_page_14_Figure_2.jpeg)

Figure 3 Illustrative Example.

Note. The circles correspond to edge 1 costs and the squares correspond to edge 2 costs. Red lines and points correspond to the least squares fit and predictions, while green lines and points correspond to the SPO fit and predictions. The vertical dotted lines correspond to the decision boundaries under the true and prediction models. The SPO+ decision boundary in this stylized example coincides with the SPO decision boundary.

finding the prediction model that minimizes the empirical risk using the SPO+ loss, this prediction model will also approximately minimize [\(4\)](#page-11-1), the empirical risk using the SPO loss.

To begin the derivation of the SPO+ loss, we first observe that for any α ∈ R, the SPO loss can be written as

<span id="page-14-1"></span>
$$\ell_{\text{SPO}}(\hat{c}, c) = \max_{w \in W^*(\hat{c})} \left\{ c^T w - \alpha \hat{c}^T w \right\} + \alpha z^*(\hat{c}) - z^*(c) \tag{5}$$

since  $z^*(\hat{c}) = \hat{c}^T w$  for all  $w \in W^*(\hat{c})$ . Clearly, replacing the constraint  $w \in W^*(\hat{c})$  with  $w \in S$  in (5) results in an upper bound. Since this is true for all values of  $\alpha$ , then

<span id="page-15-1"></span>
$$\ell_{\text{SPO}}(\hat{c}, c) \leq \inf_{\alpha} \left\{ \max_{w \in S} \left\{ c^T w - \alpha \hat{c}^T w \right\} + \alpha z^*(\hat{c}) \right\} - z^*(c) . \tag{6}$$

In fact, one can show that inequality (6) is actually an equality using duality theory, and moreover, the optimal value of  $\alpha$  tends to  $\infty$ . Intuitively, one can see that as  $\alpha$  gets large, then the term  $c^Tw$  in the inner maximization objective becomes negligible and the solution tends to  $w^*(\alpha \hat{c}) = w^*(\hat{c})$ . Thus, as  $\alpha$  tends to  $\infty$ , the inner maximization over S can be replaced with maximization over  $W^*(\hat{c})$ , which recovers (5). We formalize this equivalence in Proposition 2 below.

<span id="page-15-0"></span>PROPOSITION 2 (Dual Representation of SPO Loss). For any cost vector prediction  $\hat{c} \in \mathbb{R}^d$  and realized cost vector  $c \in \mathbb{R}^d$ , the function  $\alpha \mapsto \max_{w \in S} \left\{ c^T w - \alpha \hat{c}^T w \right\} + \alpha z^*(\hat{c})$  is monotone decreasing on  $\mathbb{R}$ , and the true SPO loss function may be expressed as

<span id="page-15-3"></span><span id="page-15-2"></span>
$$\ell_{\text{SPO}}(\hat{c}, c) = \lim_{\alpha \to \infty} \left\{ \max_{w \in S} \left\{ c^T w - \alpha \hat{c}^T w \right\} + \alpha z^*(\hat{c}) \right\} - z^*(c) . \tag{7}$$

Using Proposition 2, we shall now revist the SPO ERM problem (4) which can be written as

$$\min_{f \in \mathcal{H}} \frac{1}{n} \sum_{i=1}^{n} \lim_{\alpha_{i} \to \infty} \left\{ \max_{w \in S} \left\{ c_{i}^{T} w - \alpha_{i} f(x_{i})^{T} w \right\} + \alpha_{i} z^{*}(f(x_{i})) \right\} - z^{*}(c_{i})$$

$$= \min_{f \in \mathcal{H}} \frac{1}{n} \sum_{i=1}^{n} \lim_{\alpha_{i} \to \infty} \left\{ \max_{w \in S} \left\{ c_{i}^{T} w - \alpha_{i} f(x_{i})^{T} w \right\} + \alpha_{i} f(x_{i})^{T} w^{*}(\alpha_{i} f(x_{i})) \right\} - z^{*}(c_{i})$$

$$= \min_{f \in \mathcal{H}} \frac{1}{n} \lim_{\alpha \to \infty} \left\{ \sum_{i=1}^{n} \max_{w \in S} \left\{ c_{i}^{T} w - \alpha f(x_{i})^{T} w \right\} + \alpha f(x_{i})^{T} w^{*}(\alpha f(x_{i})) - z^{*}(c_{i}) \right\}$$

$$\leq \min_{f \in \mathcal{H}} \frac{1}{n} \sum_{i=1}^{n} \max_{w \in S} \left\{ c_{i}^{T} w - 2 f(x_{i})^{T} w \right\} + 2 f(x_{i})^{T} w^{*}(2 f(x_{i})) - z^{*}(c_{i})$$

$$\leq \min_{f \in \mathcal{H}} \frac{1}{n} \sum_{i=1}^{n} \max_{w \in S} \left\{ c_{i}^{T} w - 2 f(x_{i})^{T} w \right\} + 2 f(x_{i})^{T} w^{*}(c_{i}) - z^{*}(c_{i}) . \tag{9}$$

The first equality follows from the fact that  $z^*(\alpha_i f(x_i)) = \alpha_i z^*(f(x_i))$  for any  $\alpha_i > 0$ . The second equality follows from the observation that all of the  $\alpha_i$  variables are tending to the same value, so we can replace them with one variable which we call  $\alpha$ . The first inequality follows from Proposition 2, in particular that setting  $\alpha = 2$  in (6) results in an upper bound

on the SPO loss (we shall revisit this specific choice below). Finally, the second inequality follows from the fact that w ∗ (ci) is a feasible solution of P(2f(xi)).

<span id="page-16-0"></span>The summand expression in [\(9\)](#page-15-2) is exactly what we refer to as the SPO+ loss function, which we formally state in Definition [3.](#page-16-0)

Definition 3 (SPO+ Loss). Given a cost vector prediction cˆ and a realized cost vector c, the *SPO+ loss* is defined as ℓSPO+(ˆc, c) := max<sup>w</sup>∈<sup>S</sup> c <sup>T</sup>w − 2ˆc <sup>T</sup>w + 2ˆc <sup>T</sup>w ∗ (c) − z ∗ (c).

Recall that ξS(·) is the support function of S, i.e., ξS(c) := max<sup>w</sup>∈<sup>S</sup>{c <sup>T</sup>w}. Using this notation, the SPO+ loss may be equivalently expressed as ℓSPO+(ˆc, c) = ξS(c − 2ˆc) + 2ˆc <sup>T</sup>w ∗ (c) − z ∗ (c).

Before proceeding, we shall provide reasoning as to why inequalities [\(8\)](#page-15-3) and [\(9\)](#page-15-2), which were used to derive SPO+, are indeed reasonable approximations. Although inequality [\(8\)](#page-15-3) could have been derived without the intermediary steps before it, we now claim that this inequality is actually an equality for many hypothesis classes. Namely, for any hypothesis class H where f ∈ H implies αf ∈ H for all α ≥ 0, then the inequality is tight since minimizing over αf is equivalent to minimizing over 2f. For example, the hypothesis class of linear models satisfies this property since all scalar multiples of linear models are also linear. Note that α being absorbed into the hypothesis class was possible because the α<sup>i</sup> terms in each summand can be replaced by a single α since they all tend to infinity. *We specifically choose* α = 2 *(rather than any other positive scalar) because the Bayes risk minimizer of the SPO+ loss (under some conditions) is exactly* E[c|x] *rather than a multiple of* E[c|x]*.* This notion will be formalized in Section [4.](#page-44-0)

The final step, [\(9\)](#page-15-2), in the derivation of our convex surrogate SPO+ loss function involves approximating the concave (nonconvex) function z ∗ (·) with a first-order expansion. Namely, we apply the bound z ∗ (2f(xi)) = 2z ∗ (f(xi)) ≤ 2f(xi) <sup>T</sup>w ∗ (ci), which can be viewed as a firstorder approximation of z ∗ (f(xi)) based on a supergradient computed at c<sup>i</sup> (i.e., it holds that w ∗ (ci) ∈ ∂z<sup>∗</sup> (ci)). Note that if f(xi) = c<sup>i</sup> , then ℓSPO(f(xi), ci) = ℓSPO+(f(xi), ci) = 0 which implies that when minimizing SPO+, intuitively we are trying to get f(xi) to be close to c<sup>i</sup> . Therefore, one might expect w ∗ (ci) to be a near-optimal solution to P(2f(xi)) and thus inequality [\(9\)](#page-15-2) would be a reasonable approximation. In fact, Section [4](#page-44-0) provides a consistency property under some assumptions that would suggest the prediction f(xi) is indeed reasonably close to the expected value of c<sup>i</sup> if the prediction model is trained on a sufficiently large dataset.

Next, we state the following proposition which formally shows that the SPO+ loss is an upper bound on the SPO loss and it is function is convex in cˆ. Note that while the SPO+ loss is convex in cˆ, in general it is not differentiable since ξS(·) is not generally differentiable. However, Proposition [3](#page-17-0) also shows that 2(w ∗ (c) − w ∗ (2ˆc − c)) is a subgradient of the SPO+ loss, which is utilized in developing computational approaches in Section [5.](#page-22-1)

<span id="page-17-0"></span>Proposition 3 (SPO+ Loss Properties). *Given a fixed realized cost vector* c*, it holds that:*

- 1. ℓSPO(ˆc, c) ≤ ℓSPO+(ˆc, c) *for all* cˆ∈ R d *,*
- 2. ℓSPO+(ˆc, c) *is a convex function of the cost vector prediction* cˆ*, and*
- 3. *For any given* cˆ*,* 2(w ∗ (c) − w ∗ (2ˆc − c)) *is a subgradient of* ℓSPO+(·) *at* cˆ*, i.e.,* 2(w ∗ (c) − w ∗ (2ˆc − c)) ∈ ∂ℓSPO+(ˆc, c)*.*

The convexity of the SPO+ loss function is also shared by the hinge loss function, which is a convex upper bound for the 0-1 loss function. Recall that the hinge loss given a prediction cˆ is max{0, 1−cˆ} if the true label is 1 and max{0, 1+ ˆc} if the true label is −1. More concisely, the hinge loss can be written as max{0, 1 − ccˆ} where c ∈ {−1,+1} is the true label. The hinge loss is central to the support vector machine (SVM) method, where it is used as a convex surrogate to minimize 0-1 loss. Recall that, in this setting of binary classification, the SPO loss exactly captures the 0-1 loss as formalized in Proposition [1.](#page-11-0) In the same setting, it turns out that the SPO+ loss is equal to the hinge loss evaluated at 2ˆc, i.e., twice the predicted value, which is formalized below in Proposition [4.](#page-17-1) This mild discrepancy is due to our choice of α = 2 in the above derivation of the SPO+ loss; the alternative choice of α = 1 would yield the hinge loss exactly.

<span id="page-17-1"></span>Proposition 4 (SPO+ Loss Generalizes Hinge Loss). *Under the same conditions as Proposition [1,](#page-11-0) namely when* S = [−1/2,+1/2] *and* c ∈ {−1,+1}*, it holds that* ℓSPO+(ˆc, c) = max{0, 1−2ccˆ}*, i.e., the SPO+ loss function is equivalent to the hinge loss function associated with binary classification.*

Remark 1 (Connection to structured prediction). It is worth pointing out that the previously described construction of the SPO+ loss bears some resemblance to the construction of the structured hinge loss [\(Taskar et al. \(2004](#page-34-8), [2005\)](#page-34-4), [Tsochantaridis et al.](#page-34-5) [\(2005\)](#page-34-5), [Nowozin et al. \(2011](#page-34-6))) in structured support vector machines (SSVMs). Moreover, our problem setting expands upon that of structured prediction by utilizing the objective

cost of the nominal optimization problem to naturally define the SPO loss function. That is, if we define  $w_i^* := w^*(c_i)$ , then the modified dataset  $(x_1, w_1^*), (x_2, w_2^*), \ldots, (x_n, w_n^*)$  may be regarded as the training data of a structured prediction problem. However, this reduction throws away valuable information about the cost vectors  $c_i$ , whereas the SPO+ loss function naturally exploits this information and upper bounds the SPO loss. Hence, our framework (and the surrogate SPO+ loss function) may be viewed as a type of refinement of the SSVM problem (and the structured hinge loss) to settings where there is a natural cost structure. Note that both the SPO+ loss and the structured hinge loss recover the regular hinge loss of binary classification as a special case. The hinge loss satisfies a key consistency property with respect to the 0-1 loss (Steinwart 2002), which justifies its use in practice. In Section 4 we show a similar consistency result for the SPO+ loss with respect to the SPO loss under some mild conditions. On the other hand, the structured hinge loss is often inconsistent (see, e.g., the discussion around equation (11) in Zhang (2004)), although there have been results on characterizing properties of consistent loss function in multiclass classification and structured prediction (Zhang 2004, Tewari and Bartlett 2007, Osokin et al. 2017).  $\square$ 

<span id="page-18-1"></span>REMARK 2 (WHEN  $P(\cdot)$  IS A COMBINATORIAL OR MIXED-INTEGER PROBLEM). As mentioned previously, the assumptions that S is convex and closed are without loss of generality since one can simply replace a possibly non-convex or non-closed set with its closed convex hull in (2) without changing the optimal value  $z^*(c)$ . To be more concrete, suppose that  $\tilde{S} \subseteq \mathbb{R}^d$  is a bounded but possibly non-convex or non-closed set and that S is the closed convex hull of  $\tilde{S}$ . Suppose further that the the oracle  $w^*(\cdot)$  returns an optimal solution in  $\tilde{S}$ , i.e.,  $w^*(c) \in \arg\min_{w \in \tilde{S}} c^T w \subseteq \arg\min_{w \in S} c^T w$  for all  $c \in \mathbb{R}^d$ . For example, if  $\tilde{S}$  represents the feasible region of a combinatorial or mixed-integer optimization problem, then the oracle would correspond to a practically efficient algorithm for this problem. Then, using the fact that linear optimization on  $\tilde{S}$  is equivalent to linear optimization on S, it is easy to see that the SPO and SPO+ loss functions defined with respect to  $\tilde{S}$  exactly equal the corresponding loss functions defined with respect to S. Finally, using Proposition 3, one can use the oracle  $w^*(c) \in \arg\min_{w \in \tilde{S}} c^T w$  to compute subgradients of the SPO+ loss function, which can be utilized in computational approaches as described in Section 5.  $\square$ 

Applying the ERM principle as in (4) to the SPO+ loss yields the following optimization problem for selecting the prediction model:

<span id="page-18-0"></span>
$$\min_{f \in \mathcal{H}} \frac{1}{n} \sum_{i=1}^{n} \ell_{\text{SPO}+}(f(x_i), c_i) . \tag{10}$$

Much of the remainder of the paper describes results concerning problem [\(10\)](#page-18-0). In Section [4](#page-44-0) we demonstrate the aforementioned Fisher consistency result, in Section [5](#page-22-1) we describe several computational approaches for solving problem [\(10\)](#page-18-0), and in Section [6](#page-24-1) we demonstrate that [\(10\)](#page-18-0) often offers superior practical performance over standard PO approaches. Next, we provide a theoretically motivated justification for using the SPO+ loss.

## 4. Consistency of the SPO+ Loss Function

In this section, we prove a fundamental consistency property, known as *Fisher consistency*, to describe when minimizing the SPO+ loss is equivalent to minimizing the SPO loss. The Fisher consistency of a surrogate loss function means that under full knowledge of the data distribution and no restriction on the hypothesis class, the function that minimizes the surrogate loss also minimizes the true loss [\(Lin 2004](#page-33-13), [Zou et](#page-35-3) al. [2008](#page-35-3)). One may also say that the surrogate loss is calibrated with the true loss [\(Bartlett et al. 2006\)](#page-31-10). Our result is analagous to the well-known consistency results of the hinge loss and logistic loss functions with respect to the 0-1 loss – minimizing hinge and logistic loss under full knowledge also minimizes the 0-1 loss – and provides theoretical motivation for their success in practice.

More formally, we let D denote the distribution of (x, c), i.e., (x, c) ∼ D, and consider the population version of the true SPO risk (Bayes risk) minimization problem:

<span id="page-19-0"></span>
$$\min_{f} \mathbb{E}_{(x,c)\sim\mathcal{D}}[\ell_{\text{SPO}}(f(x),c)]. \tag{11}$$

and the population version of the SPO+ risk minimization problem:

<span id="page-19-1"></span>
$$\min_{f} \mathbb{E}_{(x,c)\sim\mathcal{D}}[\ell_{\text{SPO}+}(f(x),c)] . \tag{12}$$

Note here that we place no restrictions on f(·), meaning H consists of any measurable function mapping features to cost vectors.

Definition 4 (Fisher Consistency). A loss function ℓ(·, ·) is said to be *Fisher consistent* with respect to the SPO loss if arg min<sup>f</sup> <sup>E</sup>(x,c)∼D[ℓ(f(x), c)] (the set of minimizers of the Bayes risk of ℓ) also minimizes [\(11\)](#page-19-0).

To gain some intuition, let f ∗ SPO and f ∗ SPO+ denote any optimal solution of [\(11\)](#page-19-0) and [\(12\)](#page-19-1), respectively. From [\(1\)](#page-7-1), one can see that an ideal value for f ∗ SPO(x) is simply E[c|x]. In fact, as long as the optimal solution of P(E[c|x]) is unique with probability 1 (over the distribution of x ∈ X ), i.e., almost surely, then it is indeed the case E[c|x] is a minimizer of [\(11\)](#page-19-0) (see

Proposition [5](#page-21-0) below). Moreover, any function that is almost surely equal to E[c|x] is also a minimizer of [\(11\)](#page-19-0). In Theorem [1,](#page-20-0) we show that under Assumption [1,](#page-20-1) any minimizer of the SPO+ population risk [\(12\)](#page-19-1) must satisfy f ∗ SPO+(x) = E[c|x] almost surely and therefore also minimizes the SPO risk [\(11\)](#page-19-0). In summary, the SPO+ loss is Fisher consistent with the SPO loss, under Assumption [1.](#page-20-1)

<span id="page-20-1"></span>Assumption 1. *These assumptions imply Fisher consistency of the SPO+ loss function.*

- 1. *Almost surely,* W<sup>∗</sup> (E[c|x]) *is a singleton, i.e.,* Px(|W<sup>∗</sup> (E[c|x])| = 1) = 1*.*
- 2. *For all* x ∈ X *, the distribution of* c|x *is centrally symmetric about its mean* E[c|x]*.*
- 3. *For all* x ∈ X *, the distribution of* c|x *is continuous on all of* R d *.*
- <span id="page-20-0"></span>4. *The interior of the feasible region* S *is nonempty.*

Theorem 1 (Fisher Consistency of SPO+). *Suppose Assumption [1](#page-20-1) holds. Then, any minimizer of the SPO+ risk* [\(12\)](#page-19-1) *is almost surely (over the distribution of* x ∈ X *) equal to* E[c|x] *and is also a minimizer of the SPO risk* [\(11\)](#page-19-0)*. Thus, the SPO+ loss function is Fisher consistent with respect to the SPO loss.*

The key results to prove Theorem [1](#page-20-0) are provided in Section [4.1,](#page-21-1) and the final proof is given in the Appendix. We remark that Assumption [1.](#page-20-1)1 is only needed to show that E[c|x] is a minimizer of the SPO risk. This assumption is rather mild as the set of points with multiple optimal solutions typically has measure 0. In fact, Assumption [1.](#page-20-1)1 can be removed if one uses Definition [1](#page-10-1) of the SPO loss which uses a given optimization oracle. Assumption [1.](#page-20-1)2 ensures that E[c|x] is a minimizer of the SPO+ risk. Note that a random vector d is centrally symmetric about its mean if d−E[d] is equal in distribution to E[d]−d, or equivalently d is equal in distribution to 2E[d] − d. This symmetry condition is satisfied, for instance, when the data is assumed to be of the form f(x) +ǫ where ǫ is a zero-mean Gaussian distribution with a positive semi-definite covariance matrix. Finally, Assumptions [1.](#page-20-1)3 and [1.](#page-20-1)4, both of which are standard, are used to show that E[c|x] uniquely minimizes the SPO+ risk except possibly on a set of probability measure zero. Note that Assumptions [1.](#page-20-1)2 and [1.](#page-20-1)3 may be relaxed to hold almost surely with respect to the probability measure of x ∈ X ; but for ease of presentation we state them for all x ∈ X . In Section [4.1,](#page-21-1) we discuss examples (provided in the Appendix) that show how our result may not hold if one of the assumptions are violated.

As mentioned previously, any minimizer for the least squares (LS) risk is also almost surely equal to E[c|x], and thus the least squares loss is also Fisher consistent with respect to the SPO loss. *Thus, a priori, one cannot claim LS or SPO+ to be better than the other.* Indeed, we have derived a natural surrogate loss function, SPO+, directly from the SPO loss that maintains a fundamental consistency property of the de facto standard LS loss function. In fact, it is easy to see that under Assumption 1, any convex combination of the LS and SPO+ loss functions is Fisher consistent. Since this consistency property applies under full distributional information and no model misspecification (no restriction on hypothesis class), we show in Section [6](#page-24-1) that SPO+ indeed outperforms LS in several experimental settings, due to its ability to tailor the prediction to the optimization task.

## <span id="page-21-1"></span>4.1. Key Results to Prove Fisher Consistency

Throughout this section, we consider a non-parametric setup where the dependence on the features x is dropped without loss of generality. To see this, first observe that the SPO risk satisfies <sup>E</sup>(x,c)∼D[ℓSPO(f(x), c)] = <sup>E</sup><sup>x</sup> [E<sup>c</sup> [ℓSPO(f(x), c) <sup>|</sup> <sup>x</sup>]] and likewise for the SPO+ risk. Since there is no constraint on f(·) (the hypothesis class consists of all prediction models), solving problems [\(11\)](#page-19-0) and [\(12\)](#page-19-1) is equivalent to optimizing each function value f(x) individually for all x ∈ X . Therefore, for the remainder of the section unless otherwise noted, we drop the dependence on x. Thus, we now assume that the distribution D is only over c, and the SPO and SPO+ risk is defined as RSPO(ˆc) := Ec[ℓSPO(ˆc, c)] and RSPO+(ˆc) := Ec[ℓSPO+(ˆc, c)], respectively. For convenience, let us define c¯ := Ec[c] (note that we are implicitly assuming that c¯ is finite).

Next, we fully characterize the minimizers of the true SPO risk problem [\(11\)](#page-19-0) in this setting. Proposition [5](#page-21-0) demonstrates that for any minimizer c <sup>∗</sup> of RSPO(·), all of its corresponding solutions with respect to the nominal problem, W<sup>∗</sup> (c ∗ ), are also optimal solutions for P(¯c). In other words, minimizing the true SPO risk also optimizes for the expected cost in the nominal problem (since the objective function is linear). Proposition [5](#page-21-0) also demonstrates that the converse is true – namely any cost vector prediction with a unique optimal solution that also optimizes for the expected cost is also a minimizer of the true SPO risk.

<span id="page-21-0"></span>Proposition 5 (SPO Minimizer). *If a cost vector* c ∗ *is a minimizer of* RSPO(·)*, then* W<sup>∗</sup> (c ∗ ) ⊆ W<sup>∗</sup> (¯c)*. Conversely, if* c ∗ *is a cost vector such that* W<sup>∗</sup> (c ∗ ) *is a singleton and* W<sup>∗</sup> (c ∗ ) ⊆ W<sup>∗</sup> (¯c)*, then* c ∗ *is a minimizer of* RSPO(·)*.*

Example [2](#page-36-2) in Appendix [A](#page-36-1) demonstrates that, in order to ensure that c ∗ is a minimizer of RSPO(·), it is not sufficient to allow c ∗ to be any cost vector such that W<sup>∗</sup> (c ∗ ) ⊆ W<sup>∗</sup> (¯c). In fact, it may not be sufficient for c ∗ to be c¯. This follows from the unambiguity of the SPO loss function, which chooses a worst-case optimal solution in the event that the prediction allows for more than one optimal solution.

Next, we provide Proposition [6](#page-22-0) which shows sufficient conditions for c¯ to be the minimizer of the SPO+ risk and therefore the minimizer of the SPO risk, implying Fisher consistency. We also provide conditions for when c¯ is the unique minimizer of the SPO+ risk, which alleviates any concern that there may be alternate minimizers of the SPO+ risk which are not Fisher consistent.

<span id="page-22-0"></span>Proposition 6 (SPO+ Minimizer). *Suppose that the distribution* D *of* c *is continuous and centrally symmetric about its mean* c¯ *(i.e.,* c *is equal in distribution to* 2¯c − c*).*

- *a) Then* c¯ *minimizes* RSPO+(·)*.*
- *b) In addition, suppose the interior of* S *is nonempty. Then* c¯ *is the unique minimizer of* RSPO+(·)*.*

The two important assumptions in Proposition [6](#page-22-0) are that D is centrally symmetric about its mean and continuous, both of which are not individually sufficient to ensure consistency on their own. Example [3](#page-36-3) in Appendix [A](#page-36-1) demonstrates a situation where c is continuous on R <sup>d</sup> and the minimizer of SPO+ is unique, but it does not minimize the SPO risk. Example [4](#page-37-1) in Appendix [A](#page-36-1) demonstrates a situation where the distribution of c is symmetric about its mean but there exists a minimizer of the SPO+ risk that does not minimize the SPO risk. Example [5](#page-37-2) in Appendix [A](#page-36-1) demonstrates a case where the minimizer of SPO+ is not unique if S is empty while c is continuous and centrally symmetric about its mean.

## <span id="page-22-1"></span>5. Computational Approaches

In this section, we consider computational approaches for solving the SPO+ ERM problem [\(10\)](#page-18-0). Herein, we focus on the case of linear predictors, H = {f : f(x) = Bx for some B ∈ R <sup>d</sup>×<sup>p</sup>}, with regularization possibly incorporated into the objective function, using the regularizer Ω(·) : R <sup>d</sup>×<sup>p</sup> → R. (This is equivalent to working with the hypothesis class H = {f : f(x) = Bx for some B ∈ R d×p , Ω(B) ≤ ρ} for some ρ > 0.) For example, we may use the ridge penalty Ω(B) = <sup>1</sup> 2 kBk 2 F , where kBk<sup>F</sup> denotes the Frobenius norm of B, i.e., the entry-wise ℓ<sup>2</sup> norm. Other possibilities include an entry-wise ℓ<sup>1</sup> penalty or the nuclear norm penalty,

i.e., an ℓ<sup>1</sup> penalty on the singular values of B. In any case, these presumptions lead to the following version of [\(10\)](#page-18-0):

<span id="page-23-0"></span>
$$\min_{B \in \mathbb{R}^{d \times p}} \frac{1}{n} \sum_{i=1}^{n} \ell_{\text{SPO+}}(Bx_i, c_i) + \lambda \Omega(B) , \qquad (13)$$

where λ ≥ 0 is a regularization parameter. Since the SPO loss is convex as stated in Proposition [3,](#page-17-0) then the above problem is a convex optimization problem as long as Ω(·) is a convex function.

We mainly consider two approaches for solving problem [\(13\)](#page-23-0): *(i)* reformulations based on modeling ℓSPO+(·, c) using duality, and *(ii)* stochastic gradient based methods that instead rely only on an optimization oracle for problem [\(2\)](#page-7-0). The reformulation based approach *(i)* requires an explicit description of the feasible region S, for example if S is a polytope then this approach necessitates working with an explicit list of inequality constraints describing S. On the other hand, the stochastic gradient based approach *(ii)* does not require an explicit description of S and instead *only* relies on iteratively calling the optimization oracle w ∗ (·) in order to compute stochastic subgradients of the SPO+ loss (see Proposition [3\)](#page-17-0). Therefore it is much more straightforward to apply the stochastic gradient descent approach to problems with complicated constraints, such as nonlinear problems as well as combinatorial and mixed-integer problems as mentioned in Remark [2.](#page-18-1) While approach *(i)* is more restrictive in its requirements, it does offer a few advantages. Depending on the structure of S, for example if S is a polytope with known linear inequality constraints, then approach *(i)* may able to utilize off-the-shelf conic optimization solvers such as CPLEX and Gurobi that are capable of producing high accuracy solutions for small to medium sized problem instances (see Section [5.1\)](#page-23-1). However, for large scale instances where d, p, and n might be very large, conic solvers based on interior point methods do not scale as well. Stochastic gradient methods, on the other hand, scale much better to instances where n may be extremely large, and possibly also to instances where d and p are large but the optimization oracle w ∗ (·) is efficiently computable due to the special structure of S. The details of the approach *(ii)* can be found in Appendix [C.](#page-42-1)

## <span id="page-23-1"></span>5.1. Reformulation Approach

We now discuss the reformulation approach *(i)*, which aims to recast problem [\(13\)](#page-23-0) in a form that is amenable to popular optimization solvers. To describe this approach, we presume that S is a polytope described by known linear inequalities, i.e.,  $S = \{w : Aw \ge b\}$  for some given problem data  $A \in \mathbb{R}^{m \times d}$  and  $b \in \mathbb{R}^m$ . The same approach may also be applied to particular classes of nonlinear feasible regions, although the complexity of the resulting reformulated problem will be different. The key idea is that when S is a polytope, then  $\ell_{\text{SPO+}}(\cdot,c)$  is a (piecewise linear) convex function of the prediction  $\hat{c}$  and therefore the epigraph of  $\ell_{\text{SPO+}}(\cdot,c)$  can be tractably modeled with linear constraints by employing linear programming duality. Proposition 7 formalizes this approach. (Recall that, for  $w \in \mathbb{R}^d$  and  $x \in \mathbb{R}^p$ ,  $wx^T$  denotes  $d \times p$  outer product matrix where  $(wx^T)_{ij} = w_i x_j$ .)

<span id="page-24-0"></span>PROPOSITION 7 (Reformulation of ERM for SPO+). Suppose  $S = \{w : Aw \ge b\}$  is a polytope. Then the regularized SPO+ ERM problem (13) is equivalent to the following optimization problem:

<span id="page-24-2"></span>
$$\min_{B,p} \frac{1}{n} \sum_{i=1}^{n} \left[ -b^{T} p_{i} + 2(w^{*}(c_{i}) x_{i}^{T}) \bullet B - z^{*}(c_{i}) \right] + \lambda \Omega(B)$$
s.t.  $A^{T} p_{i} = 2Bx_{i} - c_{i}$  for all  $i \in \{1, \dots, n\}$  
$$p_{i} \in \mathbb{R}^{m}, p_{i} \geq 0$$
 for all  $i \in \{1, \dots, n\}$  
$$B \in \mathbb{R}^{d \times p}$$
. (14)

Thus, as we can see, problem (14) is almost a linear optimization problem – the only part that may be nonlinear is the regularizer  $\Omega(\cdot)$ . For several natural choices of  $\Omega(\cdot)$ , problem (7) may be cast as a conic optimization problem that can be solved efficiently with interior point methods. For instance, for the LASSO penalty where  $\Omega(B) = ||B||_1$ , then (14) is equivalent to a linear program. If  $\Omega(\cdot)$  is the ridge penalty,  $\Omega(B) = \frac{1}{2}||B||_F^2$ , then (14) is equivalent to a quadratic program. If  $\Omega(\cdot)$  is the nuclear norm penalty,  $\Omega(B) = ||B||_*$ , then (14) is equivalent to a semidefinite program.

#### <span id="page-24-1"></span>6. Computational Experiments

In this section, we present computational results of synthetic data experiments wherein we empirically examine the quality of the SPO+ loss function for training prediction models, using the shortest path problem and portfolio optimization as our exemplary problem classes. Following Section 5, we focus on linear prediction models, possibly with either ridge or entrywise  $\ell_1$  regularization. We compare the performance of four different methods:

1. the previously described SPO+ method, (13).

- 2. the least squares method that replaces the SPO+ loss function in (13) with  $\ell(\hat{c}, c) = \frac{1}{2} \|\hat{c} c\|_2^2$  and also uses regularization whenever SPO+ does.
- 3. an absolute loss function (i.e.,  $\ell_1$ ) approach that replaces the SPO+ loss function in (13) with  $\ell(\hat{c}, c) = \|\hat{c} c\|_1$  and also uses regularization whenever SPO+ does.
- 4. a random forests approach that independently trains d different random forest models for each component of the cost vector, using standard parameter settings of  $\lceil p/3 \rceil$  random features at each split and 100 trees.

Note that methods (2.), (3.) and (4.) above do not utilize the structure of S in any way and hence may be viewed as independent learning algorithms with respect to each of the components of the cost vector. For methods (1.), (2.), and (3.) above, we include an intercept column in B that is not regularized. In order to ultimately measure and compare the performance of the four different methods, we compute a "normalized" version of the SPO loss of each of the four previously trained models on an independent test set of size 10,000. Specifically, if  $(\tilde{x}_1, \tilde{c}_1), (\tilde{x}_2, \tilde{c}_2), \dots, (\tilde{x}_{n_{\text{test}}}, \tilde{c}_{n_{\text{test}}})$  denotes the test set, then we define the normalized test SPO loss of a previously trained model  $\hat{f}$  by NormSPOTest $(\hat{f}) := \frac{\sum_{i=1}^{n_{\text{test}}} \ell_{\text{SPO}}(\hat{f}(\tilde{x}_i), \tilde{c}_i)}{\sum_{i=1}^{n_{\text{test}}} z^*(\tilde{c}_i)}$ . Note that we naturally normalize by the total optimal cost of the test set given full information, which with high probability will be a positive number for the examples studied herein.

## 6.1. Shortest Path Problem

We consider a shortest path problem on a  $5 \times 5$  grid network, where the goal is to go from the northwest corner to the southeast corner and the edges only go south or east. In this case, the feasible region S can be modeled using network flow constraints as in Example 1. We utilize the reformulation approach given by Proposition 7 to solve the SPO+ training problem (13). Specifically, we use the JuMP package in Julia (Dunning et al. (2017)) with the Gurobi solver to implement problem (14). The optimization problems required in methods (2.) and (3.) are also solved directly using Gurobi. In some cases we use  $\ell_1$  regularization for methods (1.), (2.), and (3.), in which case, in order to tune the regularization parameter  $\lambda$ , we try 10 different values of  $\lambda$  evenly spaced on the logarithmic scale between  $10^{-6}$  and 100. Furthermore, we use a validation set approach where we train the 10 different models on a training set of size n and then use an independent validation set of size n/4 to pick the model that performs best with respect to the SPO loss.

Synthetic Data Generation Process. Let us now describe the process used for generating the synthetic experimental data instances for both problem classes. Note that the dimension of the cost vector d = 40 corresponds to the total number of edges in the  $5 \times 5$  grid network and that p is a given number of features. First, we generate a random matrix  $B^* \in \mathbb{R}^{d \times p}$  that encodes the parameters of the true model, whereby each entry of  $B^*$  is Bernoulli random variable that is equal to 1 with probability 0.5. We generate the training data  $(x_1, c_1), (x_2, c_2), \ldots, (x_n, c_n)$  and the testing data  $(\tilde{x}_1, \tilde{c}_1), (\tilde{x}_2, \tilde{c}_2), \ldots, (\tilde{x}_n, \tilde{c}_n)$  according to the following generative model:

- 1. First, the feature vector  $x_i \in \mathbb{R}^p$  is generated from a multivariate Gaussian distribution with i.i.d. standard normal entries, i.e.,  $x_i \sim N(0, I_p)$ .
- 2. Then, the cost vector  $c_i$  is generated according to  $c_{ij} = \left[\left(\frac{1}{\sqrt{p}}(B^*x_i)_j + 3\right)^{\deg} + 1\right] \cdot \varepsilon_i^j$  for  $j = 1, \ldots, d$ , and where  $c_{ij}$  denotes the  $j^{\text{th}}$  component of  $c_i$  and  $(B^*x_i)_j$  denotes the  $j^{\text{th}}$  component of  $B^*x_i$ . Here, deg is a fixed positive integer parameter and  $\varepsilon_i^j$  is a multiplicative noise term that is generated independently at random from the uniform distribution on  $[1 \bar{\varepsilon}, 1 + \bar{\varepsilon}]$  for some parameter  $\bar{\varepsilon} \geq 0$ .

Note that the model for generating the cost vectors employs a polynomial kernel function (see, e.g., Hofmann et al. (2008)), whereby the regression function for the cost vector given the features, i.e.,  $\mathbb{E}[c|x]$ , is a polynomial function of x and the parameter deg dictates the degree of the polynomial. Importantly, we still employ a linear hypothesis class for methods (1.)-(3.) above, hence the parameter deg controls the amount of model misspecification and as deg increases we expect the performance of the SPO+ approach to improve relative to methods (2.) and (3.). When deg = 1, the expected value of c is indeed linear in x. Furthermore, for large values of deg, the least squares method will be sensitive to outliers in the cost vector generation process, which is our main motivation for also comparing against the absolute loss approach that is less sensitive to outliers. On the other hand, the random forests method is a non-parametric learning algorithm and will accurately learn the regression function for any value of deg. However, the practical performance of random forests depends heavily on the sample size n and, for relatively small values of n, random forests may perform poorly.

Results. In the following set of experiments on the shortest path problem we described, we fix the number of features at p = 5 throughout and, as previously mentioned, use a  $5 \times 5$  grid network, which implies that d = 40. Hence, in total there are pd = 200 parameters to estimate.

We vary the training set size n ∈ {100, 1000, 5000}, we vary the parameter deg ∈ {1, 2, 4, 6, 8}, and we vary the noise half-width parameter ε¯∈ {0, 0.5}. For every value of n, deg, and ε¯, we run 50 simulations, each of which has a different B<sup>∗</sup> and therefore different ground truth model. For the cases where n ∈ {100, 1000}, we employ ℓ<sup>1</sup> regularization for methods (1.)- (3.), as previously described. When n = 5000 we do not use any regularization (since it did not appear to provide any value). As mentioned previously, for each simulation, we evaluate the performance of the trained models by computing the normalized SPO loss on a test set of 10,000 samples. The computation time for solving one ERM problem using the SPO+ loss is approximately 0.5-1.0 seconds, 5-30 seconds, and 1-15 minutes for n ∈ {100, 1000, 5000}, respectively. The other methods can be solved in a few seconds using well-developed packages. Figure [4](#page-28-0) summarizes our findings, and note that the box plot for each configuration of the parameters is across the 50 independent trials.

From Figure [4,](#page-28-0) we can see that for small values of the deg parameter, i.e., deg ∈ {1, 2}, the absolute loss, least squares, and SPO+ methods perform comparably, with the least squares method slightly dominating in the case of noise with ε¯= 0.5. The slight dominance of least squares (and sometimes the absolute loss as well) in these cases might be explained by some inherent robustness properties of the least squares loss. It is also plausible that, since the SPO+ loss function is more intricate than the "simple" least squares loss function, it may overfit in situations with noise and a small training set size. On the other hand, as the parameter deg grows and the degree of model misspecification increases, then the SPO+ approach generally begins to perform best across all instances except when n = 5000, in which case random forests performs comparably to SPO+. This behavior suggests that the SPO+ loss is better than the competitors at leveraging additional data and stronger nonlinear signals.

It is interesting to point out that random forests generally does not perform well except when n = 5000, in which case it performs comparably to SPO+, which uses a much simpler linear hypothesis class. Indeed, when n ∈ {100, 1000}, random forests almost always performs worst, except for when n = 1000 and deg ∈ {6, 8}, in which case random forests outperforms least squares, performs comparably to the absolute loss method, and is strongly dominated by SPO+. Indeed, the cases where n ∈ {1000, 5000} and deg ∈ {6, 8} suggest that least squares is prone to outliers whereas the absolute loss is not, random forests is slow to converge due to its non-parametric nature, and SPO+ is best able to adapt to the large degree of model misspecification even with a modest amount of data (i.e., n = 1000).

<span id="page-28-0"></span>![](_page_28_Figure_2.jpeg)

Figure 4 Normalized test set SPO loss for the SPO+, least squares, absolute loss, and random forests methods on shortest path problem instances.

#### 6.2. Portfolio Optimization

Here we consider a simple portfolio selection problem based on the classical Markowitz model (Markowitz 1952). As discussed in Section 1, we presume that there are auxiliary features that may be used to predict the returns of d different assets, but that the covariance matrix of the asset returns does not depend on the auxiliary features. Therefore, we consider a model with a constraint that bounds the overall variance of the portfolio. Specifically, if  $\Sigma \in \mathbb{R}^{d \times d}$  denotes the (positive semidefinite) covariance matrix of the asset returns and  $\gamma \geq 0$  is the desired bound on the overall variance (risk level) of the portfolio, then the feasible region S in (2) is given by  $S := \{w : w^T \Sigma w \leq \gamma, e^T w \leq 1, w \geq 0\}$ . Here e denotes the vector of all ones

and since we only require that  $e^Tw \leq 1$ , the cost vector c in (2) represents the negative of the incremental returns of the assets above the risk-free rate. In other words, it holds that  $c = -\tilde{r}$  where  $\tilde{r} = r - r_{\rm RF}e$ , r represents the vector of asset returns, and  $r_{RF}$  is the risk-free rate. We use the SGD approach (Algorithm 1 of Appendix C) for training the SPO+ model of method (1.). Training the SPO+ model takes 3 to 5 minutes for each ERM instance, while the other methods typically take less than a second. For brevity, we defer the details of the experimental setup to Appendix D.

Figure 5 displays our results for this experiment. Generally we observe similar patterns as in the shortest path experiment, although comparatively larger values of deg are needed to demonstrate the relative superiority of SPO+. In summary across all of our experiments, our results indicate that as long as there is some degree of model misspecification, then SPO+ tends to offer significant value over competing approaches, and this value is further strengthened in cases where more data available. The SPO+ approach is either always close to the best approach, or dominating all other approaches, making it a fairly suitable choice across all parameter regimes.

<span id="page-29-0"></span>![](_page_29_Figure_4.jpeg)

Figure 5 Normalized test set SPO loss for the SPO+, least squares, absolute loss, and random forests methods on portfolio optimization instances.

# 7. Conclusion

In this paper, we provide a new framework for developing prediction models under the predict-then-optimize paradigm. Our SPO framework relies on new types of loss functions that explicitly incorporate the problem structure of the optimization problem of interest. Our framework applies for any problem with a linear objective, even when there are integer constraints.

Since the SPO loss function is nonconvex, we also derived the convex SPO+ loss function using several logical steps based on duality theory. Moreover, we prove that the SPO+ loss is consistent with respect to the SPO loss, which is a fundamental property of any loss function. In fact, our results also directly imply that the least squares loss function is also consistent with respect to the SPO loss. Thus, least squares performs well when the ground truth is near linear, although, at least empirically, SPO+ strongly outperforms all approaches when there is model misspecification. In subsequent work, we have shown how to train decision trees with SPO loss [\(Elmachtoub et al. 2020\)](#page-32-13) and developed generalization bounds of the SPO loss function [\(El Balghiti et al. 2019\)](#page-32-14). Naturally, there are many important directions to consider for future work including more empirical testing and case studies, handling unknown parameters in the constraints, and dealing with nonlinear objectives.

## Acknowledgements

The authors gratefully acknowledge the support of NSF Awards CMMI-1763000, CCF-1755705, and CMMI-1762744.

## References

- <span id="page-30-1"></span>Ahuja, Ravindra K, Thomas L Magnanti, James B Orlin. 1993. Network flows: theory, algorithms, and applications .
- <span id="page-30-0"></span>Angalakudati, Mallik, Siddharth Balwani, Jorge Calzada, Bikram Chatterjee, Georgia Perakis, Nicolas Raad, Joline Uichanco. 2014. Business analytics for flexible resource allocation under random emergencies. Management Science 60(6) 1552–1573.
- <span id="page-30-4"></span>Aswani, Anil, Zuo-Jun Shen, Auyon Siddiq. 2018. Inverse optimization with noisy data. Operations Research 66(3) 870–892.
- <span id="page-30-2"></span>Balkanski, Eric, Aviad Rubinstein, Yaron Singer. 2016. The power of optimization from samples. Advances in Neural Information Processing Systems. 4017–4025.
- <span id="page-30-3"></span>Balkanski, Eric, Aviad Rubinstein, Yaron Singer. 2017. The limitations of optimization from samples. Proceedings of the 49th Annual ACM SIGACT Symposium on Theory of Computing. ACM, 1016–1027.

- <span id="page-31-7"></span>Ban, Gah-Yi, Noureddine El Karoui, Andrew EB Lim. 2018. Machine learning and portfolio optimization. Management Science 64(3) 1136–1154.
- <span id="page-31-1"></span>Ban, Gah-Yi, Cynthia Rudin. 2019. The big data newsvendor: Practical insights from machine learning. Operations Research 67(1) 90–108.
- <span id="page-31-10"></span>Bartlett, Peter L, Michael I Jordan, Jon D McAuliffe. 2006. Convexity, classification, and risk bounds. Journal of the American Statistical Association 101(473) 138–156.
- <span id="page-31-9"></span>Ben-David, Shai, Nadav Eiron, Philip M Long. 2003. On the difficulty of approximately maximizing agreements. Journal of Computer and System Sciences 66(3) 496–514.
- <span id="page-31-14"></span>Bertsekas, Dimitri P. 1973. Stochastic optimization problems with nondifferentiable cost functionals. Journal of Optimization Theory and Applications 12(2) 218–231.
- <span id="page-31-11"></span>Bertsekas, Dimitri P. 1999. Nonlinear programming. Athena scientific Belmont.
- <span id="page-31-5"></span>Bertsimas, Dimitris, Vishal Gupta, Nathan Kallus. 2018a. Data-driven robust optimization. Mathematical Programming 167(2) 235–292.
- <span id="page-31-3"></span>Bertsimas, Dimitris, Vishal Gupta, Nathan Kallus. 2018b. Robust sample average approximation. Mathematical Programming 171(1-2) 217–282.
- <span id="page-31-6"></span>Bertsimas, Dimitris, Vishal Gupta, Ioannis Ch Paschalidis. 2015. Data-driven estimation in equilibrium using inverse optimization. Mathematical Programming 153(2) 595–633.
- <span id="page-31-2"></span>Bertsimas, Dimitris, Nathan Kallus. 2020. From predictive to prescriptive analytics. Management Science 66(3) 1025–1044.
- <span id="page-31-4"></span>Bertsimas, Dimitris, Aurélie Thiele. 2006. Robust and data-driven optimization: modern decision making under uncertainty. Models, Methods, and Applications for Innovative Decision Making. INFORMS, 95–122.
- <span id="page-31-0"></span>Besbes, Omar, Yonatan Gur, Assaf Zeevi. 2015. Optimization in online content recommendation services: Beyond click-through rates. Manufacturing & Service Operations Management 18(1) 15–33.
- <span id="page-31-8"></span>Besbes, Omar, Robert Phillips, Assaf Zeevi. 2010. Testing the validity of a demand model: An operations perspective. Manufacturing & Service Operations Management 12(1) 162–183.
- <span id="page-31-12"></span>Borwein, Jonathan, Adrian S Lewis. 2010. Convex analysis and nonlinear optimization: theory and examples. Springer Science & Business Media.
- <span id="page-31-16"></span>Bottou, Léon. 2012. Stochastic gradient descent tricks. Neural networks: Tricks of the trade. Springer, 421–436.
- <span id="page-31-15"></span>Bottou, Léon, Frank E Curtis, Jorge Nocedal. 2018. Optimization methods for large-scale machine learning. Siam Review 60(2) 223–311.
- <span id="page-31-13"></span>Boyd, Stephen, Stephen P Boyd, Lieven Vandenberghe. 2004. Convex optimization. Cambridge university press.

- <span id="page-32-0"></span>Chan, Carri W, Vivek F Farias, Nicholas Bambos, Gabriel J Escobar. 2012. Optimizing intensive care unit discharge decisions with patient readmissions. Operations research 60(6) 1323–1341.
- <span id="page-32-3"></span>Chan, Carri W, Linda V Green, Yina Lu, Nicole Leahy, Roger Yurt. 2013. Prioritizing burn-injured patients during a disaster. Manufacturing & Service Operations Management 15(2) 170–190.
- <span id="page-32-9"></span>Chan, Timothy CY, Tim Craig, Taewoo Lee, Michael B Sharpe. 2014. Generalized inverse multiobjective optimization with application to cancer therapy. Operations Research 62(3) 680–695.
- <span id="page-32-6"></span>Cheung, Maurice, Adam N Elmachtoub, Retsef Levi, David B Shmoys. 2016. The submodular joint replenishment problem. Mathematical Programming 158(1-2) 207–233.
- <span id="page-32-8"></span>Chu, Leon Yang, J George Shanthikumar, Zuo-Jun Max Shen. 2008. Solving operational statistics via a bayesian analysis. Operations Research Letters 36(1) 110–116.
- <span id="page-32-2"></span>Cohen, Maxime C, Ngai-Hang Zachary Leung, Kiran Panchamgam, Georgia Perakis, Anthony Smith. 2017. The impact of linear optimization on promotion planning. Operations Research 65(2) 446–468.
- <span id="page-32-11"></span>Den Boer, Arnoud V, Dirk D Sierag. 2016. Decision-based model selection. *[https: // www. researchgate. net/ publication/ 282075352\\_Decision-based\\_ model\\_ selection](https://www.researchgate.net/publication/282075352_Decision-based_model_selection)* .
- <span id="page-32-4"></span>den Hertog, Dick, Krzysztof Postek. 2016. Bridging the gap between predictive and prescriptive analytics-new optimization methodology needed. *[http: // www. optimization-online.org/ DB\\_ HTML/ 2016/ 12/](http://www.optimization-online.org/DB_HTML/2016/12/5779.html) 5779. html* .
- <span id="page-32-5"></span>Deng, Yunxiao, Junyi Liu, Suvrajeet Sen. 2018. Coalescing data and decision sciences for analytics. Recent Advances in Optimization and Modeling of Contemporary Problems. INFORMS, 20–49.
- <span id="page-32-1"></span>Deo, Sarang, Kumar Rajaram, Sandeep Rath, Uday S Karmarkar, Matthew B Goetz. 2015. Planning for hiv screening, testing, and care at the veterans health administration. Operations research 63(2) 287–304.
- <span id="page-32-7"></span>Donti, Priya, Brandon Amos, J Zico Kolter. 2017. Task-based end-to-end model learning in stochastic optimization. Advances in Neural Information Processing Systems. 5484–5494.
- <span id="page-32-15"></span>Drusvyatskiy, Dmitriy, Adrian S Lewis. 2011. Generic nondegeneracy in convex optimization. Proceedings of the American Mathematical Society 2519–2527.
- <span id="page-32-12"></span>Dunning, Iain, Joey Huchette, Miles Lubin. 2017. Jump: A modeling language for mathematical optimization. SIAM Review 59(2) 295–320.
- <span id="page-32-14"></span>El Balghiti, Othman, Adam N Elmachtoub, Paul Grigas, Ambuj Tewari. 2019. Generalization bounds in the predict-then-optimize framework. Advances in Neural Information Processing Systems. 14412–14421.
- <span id="page-32-13"></span>Elmachtoub, Adam N, Jason Cheuk Nam Liang, Ryan McNellis. 2020. Decision trees for decision-making under the predict-then-optimize framework. International Conference in Machine Learning .
- <span id="page-32-10"></span>Esfahani, Peyman Mohajerin, Soroosh Shafieezadeh-Abadeh, Grani A Hanasusanto, Daniel Kuhn. 2018. Data-driven inverse optimization with imperfect information. Mathematical Programming 167(1) 191– 234.

- <span id="page-33-12"></span>Farias, V. 2007. Revenue management beyond estimate, then optimize. Ph.D. thesis, Ph. D. thesis, Stanford University, Stanford, CA.
- <span id="page-33-2"></span>Ferreira, Kris Johnson, Bin Hong Alex Lee, David Simchi-Levi. 2015. Analytics for an online retailer: Demand forecasting and price optimization. Manufacturing & Service Operations Management 18(1) 69–88.
- <span id="page-33-0"></span>Gallien, Jérémie, Adam J Mersereau, Andres Garro, Alberte Dapena Mora, Martín Nóvoa Vidal. 2015. Initial shipment decisions for new products at zara. Operations Research 63(2) 269–286.
- <span id="page-33-6"></span>Gupta, Vishal, Paat Rusmevichientong. 2017. Small-data, large-scale linear optimization with uncertain objectives. Available at SSRN 3065655 .
- <span id="page-33-14"></span>Hofmann, Thomas, Bernhard Schölkopf, Alexander J Smola. 2008. Kernel methods in machine learning. The annals of statistics 1171–1220.
- <span id="page-33-11"></span>Jaggi, Martin. 2011. Convex optimization without projection steps. arXiv preprint arXiv:1108.1170 .
- <span id="page-33-5"></span>Kao, Yi-hao, Benjamin V Roy, Xiang Yan. 2009. Directed regression. Advances in Neural Information Processing Systems. 889–897.
- <span id="page-33-10"></span>Keshavarz, Arezou, Yang Wang, Stephen Boyd. 2011. Imputing a convex objective function. Intelligent Control (ISIC), 2011 IEEE International Symposium on. IEEE, 613–619.
- <span id="page-33-9"></span>Kleywegt, Anton J, Alexander Shapiro, Tito Homem-de Mello. 2002. The sample average approximation method for stochastic discrete optimization. SIAM Journal on Optimization 12(2) 479–502.
- <span id="page-33-16"></span>Lacoste-Julien, Simon, Mark Schmidt, Francis Bach. 2012. A simpler approach to obtaining an o (1/t) convergence rate for the projected stochastic subgradient method. arXiv preprint arXiv:1212.2002 .
- <span id="page-33-4"></span>Levi, Retsef, Robin O Roundy, David B Shmoys. 2006. Primal-dual algorithms for deterministic inventory problems. Mathematics of Operations Research 31(2) 267–284.
- <span id="page-33-7"></span>Lim, Andrew EB, J George Shanthikumar, Gah-Yi Vahn. 2012. Robust portfolio choice with learning in the framework of regret: Single-period case. Management Science 58(9) 1732–1746.
- <span id="page-33-13"></span>Lin, Yi. 2004. A note on margin-based loss functions in classification. Statistics & probability letters 68(1) 73–82.
- <span id="page-33-8"></span>Liyanage, Liwan H, J George Shanthikumar. 2005. A practical inventory control policy using operational statistics. Operations Research Letters 33(4) 341–348.
- <span id="page-33-15"></span>Markowitz, Harry. 1952. Portfolio selection. The journal of finance 7(1) 77–91.
- <span id="page-33-1"></span>Mehrotra, Mili, Milind Dawande, Srinagesh Gavirneni, Mehmet Demirci, Sridhar Tayur. 2011. Or practice—production planning with patterns: A problem from processed food manufacturing. Operations Research 59(2) 267–282.
- <span id="page-33-3"></span>Mišić, Velibor V, Georgia Perakis. 2020. Data analytics in operations management: A review. Manufacturing & Service Operations Management 22(1) 158–169.

- <span id="page-34-12"></span>Molchanov, Ilya. 2005. Theory of random sets, vol. 19. Springer.
- <span id="page-34-15"></span>Nemirovski, Arkadi, Anatoli Juditsky, Guanghui Lan, Alexander Shapiro. 2009. Robust stochastic approximation approach to stochastic programming. SIAM Journal on Optimization 19(4) 1574–1609.
- <span id="page-34-6"></span>Nowozin, Sebastian, Christoph H Lampert, et al. 2011. Structured learning and prediction in computer vision. Foundations and Trends® in Computer Graphics and Vision 6(3–4) 185–365.
- <span id="page-34-7"></span>Osokin, Anton, Francis Bach, Simon Lacoste-Julien. 2017. On structured prediction theory with calibrated convex surrogate losses. Advances in Neural Information Processing Systems. 302–313.
- <span id="page-34-14"></span>Parikh, Neal, Stephen Boyd, et al. 2014. Proximal algorithms. Foundations and Trends® in Optimization 1(3) 127–239.
- <span id="page-34-13"></span>Robbins, H., S. Munro. 1951. A stochastic approximation method. Annals of Mathematical Statistics 22 400–407.
- <span id="page-34-2"></span>Schütz, Peter, Asgeir Tomasgard, Shabbir Ahmed. 2009. Supply chain design under uncertainty using sample average approximation and dual decomposition. European Journal of Operational Research 199(2) 409–419.
- <span id="page-34-3"></span>Sen, Suvrajeet, Yunxiao Deng. 2017. Learning enabled optimization: Towards a fusion of statistical learning and stochastic optimization. *[http: // www. optimization-online.org/ DB\\_ HTML/ 2017/ 03/](http://www.optimization-online.org/DB_HTML/2017/03/5904.html) 5904. html* .
- <span id="page-34-0"></span>Simchi-Levi, David. 2013. Om forum—om research: From problem-driven to data-driven research. Manufacturing & Service Operations Management 16(1) 2–10.
- <span id="page-34-9"></span>Steinwart, Ingo. 2002. Support vector machines are universally consistent. Journal of Complexity 18(3) 768–791.
- <span id="page-34-11"></span>Strassen, Volker. 1965. The existence of probability measures with given marginals. The Annals of Mathematical Statistics 423–439.
- <span id="page-34-4"></span>Taskar, Ben, Vassil Chatalbashev, Daphne Koller, Carlos Guestrin. 2005. Learning structured prediction models: A large margin approach. Proceedings of the 22nd international conference on Machine learning. ACM, 896–903.
- <span id="page-34-8"></span>Taskar, Ben, Carlos Guestrin, Daphne Koller. 2004. Max-margin markov networks. Advances in neural information processing systems. 25–32.
- <span id="page-34-10"></span>Tewari, Ambuj, Peter L Bartlett. 2007. On the consistency of multiclass classification methods. Journal of Machine Learning Research 8(May) 1007–1025.
- <span id="page-34-5"></span>Tsochantaridis, Ioannis, Thorsten Joachims, Thomas Hofmann, Yasemin Altun. 2005. Large margin methods for structured and interdependent output variables. Journal of machine learning research 6(Sep) 1453– 1484.
- <span id="page-34-1"></span>Tulabandhula, Theja, Cynthia Rudin. 2013. Machine learning with operational costs. Journal of Machine Learning Research 14(1) 1989–2028.

- <span id="page-35-0"></span>Wagner, Harvey M, Thomson M Whitin. 1958. Dynamic version of the economic lot size model. Management science 5(1) 89–96.
- <span id="page-35-1"></span>Wang, Zizhuo, Peter W Glynn, Yinyu Ye. 2016. Likelihood robust optimization for data-driven problems. Computational Management Science 13(2) 241–261.
- <span id="page-35-2"></span>Zhang, Tong. 2004. Statistical analysis of some multi-category large margin classification methods. Journal of Machine Learning Research 5(Oct) 1225–1251.
- <span id="page-35-3"></span>Zou, Hui, Ji Zhu, Trevor Hastie. 2008. New multicategory boosting algorithms based on multicategory fisher-consistent losses. The Annals of Applied Statistics 2(4) 1290.

## <span id="page-36-1"></span>Appendix

## <span id="page-36-0"></span>A. Examples

Example 1 (Network Flow). An example of the nominal optimization problem is a minimum cost network flow problem, where the decisions are how much flow to send on each edge of the network. We assume that the underlying graph is provided to us, e.g., the road network of a city. The feasible region S represents flow conservation, capacity, and required flow constraints on the underlying network. The cost vector c is not known with certainty, but can be estimated from data x which can include features of time, day, edge lengths, most recent observed cost, and so on. An example of the hypothesis class is the set of linear prediction models given by H = {f : f(x) = Bx for some B ∈ R <sup>d</sup>×<sup>p</sup>}. The linear model can be trained, for example, according to the mean squared error loss function, i.e., ℓ(ˆc, c) = <sup>1</sup> 2 kcˆ− ck 2 2 . The corresponding empirical risk minimization problem to find the best linear model B<sup>∗</sup> then becomes min<sup>B</sup> 1 n P<sup>n</sup> i=1 1 2 kBx<sup>i</sup> − cik 2 2 . The decision rule to find the optimal network flow given a feature vector x is w ∗ (B∗x).

<span id="page-36-2"></span>Example 2 (Necessity of Assumption [1.](#page-20-1)1). Suppose that d = 1, S = [−1/2,+1/2], and c is normally distributed with mean c¯ = 0 and variance 1. Then W<sup>∗</sup> (¯c) = S and ℓSPO(¯c, c) = ξS(c) − z ∗ (c) = |c| for all c. Clearly though, ℓSPO(1, c) = −c/2 + |c|/2. Moreover, ℓSPO(1, c) strictly dominates ℓSPO(¯c, c) in the sense that ℓSPO(1, c) ≤ ℓSPO(¯c, c) for all c and ℓSPO(1, c) < ℓSPO(¯c, c) for c > 0. Therefore, RSPO(1) < RSPO(¯c) and hence c¯ is not a minimizer of RSPO(·).

<span id="page-36-3"></span>Example 3 (Necessity of Assumption [1.](#page-20-1)2). Define S as the two-dimensional unit square with extreme points at (0, 0),(1, 0), (1, 1) and (0, 1). Let c have a continuous distribution on R <sup>2</sup> defined in the following manner. The probability that c occurs in each quadrant is exactly 0.25. The distribution over each quadrant is a folded normal. The mean of the folded normals is (9, 9) in quadrant 1, (−1, 1) in quadrant 2, (−1,−1) in quadrant 3, and (1,−1) in quadrant 4. Thus, c¯= (2, 2) and W<sup>∗</sup> (¯c) = {(0, 0)}. Note that all cost vectors in quadrant 1 are minimized by (0, 0), quadrant 2 by (1, 0), quadrant 3 by (1, 1), and quadrant 4 by (0, 1). Therefore, Ec[w ∗ (c)] = (0.5, 0.5).

Now we claim c <sup>∗</sup> = (0, 0) is the unique minimizer of SPO+ risk. Since w ∗ (c) only depends on which quadrant c lies in and both c and −c lie in each of the four quadrants with equal probability, it holds that Ec[w ∗ (2c <sup>∗</sup> − c)] = Ec[w ∗ (−c)] = Ec[w ∗ (c)] = (0.5, 0.5) which implies <span id="page-37-1"></span>that  $c^*$  is optimal. Finally, observe that  $W^*(c^*) = S \nsubseteq \{(0,0)\} = W^*(\bar{c})$ , which means that by Proposition 5,  $c^*$  is not a minimizer of the SPO risk.  $\square$ 

EXAMPLE 4 (NECESSITY OF ASSUMPTION 1.3). Define S as the two-dimensional simplex with extreme points at (0,0),(1,0), and (0,1). Let c have a two point distribution on the points (-2,1) and (0,-1), each with probability of 0.5. One can confirm that  $\bar{c} = (-1,0)$ ,  $W^*(\bar{c}) = \{(1,0)\}, \mathbb{E}_c[w^*(c)] = (0.5,0.5)$ , and that c is symmetric around its mean (c) is equal in distribution to  $2\bar{c} - c$ ).

Now we claim  $c^* = (-0.25, -0.5)$  is a minimizer of SPO+ risk. This is confirmed by checking that  $\mathbb{E}_c[w^*(2c^*-c)] = \mathbb{E}_c[w^*(c)] = (0.5, 0.5)$ . However,  $W^*(c^*) = \{(0,1)\} \not\subseteq \{(1,0)\} = W^*(\bar{c})$ . Thus by Proposition 5,  $c^*$  is not a minimizer of the SPO risk.  $\square$ 

<span id="page-37-2"></span>EXAMPLE 5 (NECESSITY OF ASSUMPTION 1.4). Let  $S \subseteq \mathbb{R}^2$  be the interval  $S := \{(w_1, w_2)^T : -1 \le w_1 \le 1, w_2 = 0\}$  and let c be distributed according to a standard 2-dimensional Gaussian random vector with mean  $(0,0)^T$  (and covariance matrix equal to the identity). Then, one can easily show that  $R_{\text{SPO+}}(\hat{c}) = \mathbb{E}_c[|c_1 - 2\hat{c}_1|] + \sqrt{\frac{2}{\pi}}$ . Thus, it is apparent that  $(0,\beta)^T$  is a minimizer for SPO+ risk for any  $\beta \in \mathbb{R}$ . Intuitively, this follows from the fact that the second dimension is irrelevant for the optimization problem.  $\square$ 

#### <span id="page-37-0"></span>B. Omitted Proofs

#### B.1. Proof of Proposition 1

Proof. Let d=1 and the feasible region be the interval S=[-1/2,+1/2]. Here the "cost vector" c corresponds to a binary class label, i.e., c can take one of two possible values, -1 or +1. (However, the predicted cost vector is allowed to be any real number.) Notice that, for both possible values of c, it holds that  $z^*(c)=-1/2$ . There are three cases to consider for the prediction  $\hat{c}$ : (i) if  $\hat{c}>0$  then  $W^*(\hat{c})=\{-1/2\}$  and  $\ell_{\mathrm{SPO}}(\hat{c},c)=(1-c)/2$ , (ii) if  $\hat{c}<0$  then  $W^*(c)=\{+1/2\}$  and  $\ell_{\mathrm{SPO}}(\hat{c},c)=(1+c)/2$ , and (iii) if  $\hat{c}=0$  then  $W^*(\hat{c})=S=[-1/2,+1/2]$  and  $\ell_{\mathrm{SPO}}(\hat{c},c)=(1+|c|)/2=1$ . Thus, we have  $\ell_{\mathrm{SPO}}(\hat{c},c)=0$  when  $\hat{c}$  and c share the same sign, and  $\ell_{\mathrm{SPO}}(\hat{c},c)=1$  otherwise. Therefore,  $\ell_{\mathrm{SPO}}$  is exactly the 0-1 loss function.  $\square$ 

#### B.2. Proof of Proposition 2.

*Proof.* Let us first prove that the function  $q(\alpha) := \xi_S(c - \alpha \hat{c}) + \alpha z^*(\hat{c})$  is monotone decreasing on  $\mathbb{R}$ . Clearly  $q(\cdot)$  is a convex function and moreover a subgradient g of  $q(\cdot)$  for any  $\alpha$  is given by  $g := z^*(\hat{c}) - \hat{c}^T w^*(\alpha \hat{c} - c)$ . Since  $z^*(\hat{c}) = \min_{w \in S} \hat{c}^T w$ , we have that  $g \leq 0$  for any  $\alpha$ . Now, for any  $\alpha' \leq \alpha$ , the subgradient inequality implies that:

$$q(\alpha') \ \geq \ q(\alpha) + g \cdot (\alpha' - \alpha) \ \geq \ q(\alpha) \ ,$$

since g and  $\alpha' - \alpha$  are both nonpositive. Thus,  $q(\cdot)$  is monotone decreasing.

Let us now prove that

<span id="page-38-0"></span>
$$\ell_{\text{SPO}}(\hat{c}, c) = \inf_{\alpha \ge 0} \{ \xi_S(c - \alpha \hat{c}) + \alpha z^*(\hat{c}) \} - z^*(c) . \tag{15}$$

The proof of (15) employs Lagrangian duality (see, e.g., Bertsekas (1999) and the references therein). First, note that the set of optimal solutions with respect to  $\hat{c}$ ,  $W^*(\hat{c}) := \arg\min_{w \in S} \{\hat{c}^T w\}$  may be expressed as  $W^*(\hat{c}) = S \cap \{w \in \mathbb{R}^d : \hat{c}^T w \leq z^*(\hat{c})\}$ . Therefore, it holds that:

<span id="page-38-1"></span>
$$\max_{w} c^{T}w = \max_{w} c^{T}w$$
s.t.  $w \in W^{*}(\hat{c})$  s.t.  $w \in S$  (16)
$$\hat{c}^{T}w \leq z^{*}(\hat{c}) .$$

Let us introduce a scalar Lagrange multiplier  $\alpha \in \mathbb{R}_+$  associated with the inequality constraint " $\hat{c}^T w \leq z^*(\hat{c})$ " on the right side of (16) and then form the Lagrangian:

$$L(w,\alpha) := c^T w + \alpha(z^*(\hat{c}) - \hat{c}^T w) .$$

Thus  $q(\cdot)$  is exactly the dual function, i.e., it satisfies:

$$\begin{aligned} \max_{w \in S} \ L(w, \alpha) &= \ \max_{w \in S} \left\{ c^T w + \alpha (z^*(\hat{c}) - \hat{c}^T w) \right\} \\ &= \ \max_{w \in S} \left\{ (c - \alpha \hat{c})^T w \right\} + \alpha z^*(\hat{c}) \\ &= \xi_S(c - \alpha \hat{c}) + \alpha z^*(\hat{c}) = q(\alpha) \ . \end{aligned}$$

Weak duality then implies that  $\max_{w \in W^*(\hat{c})} \{c^T w\} \le \inf_{\alpha \ge 0} q(\alpha)$  and hence:

$$\ell_{\text{SPO}}(\hat{c}, c) = \max_{w \in W^*(\hat{c})} \left\{ c^T w \right\} - z^*(c) \leq \inf_{\alpha \geq 0} \left\{ \xi_S(c - \alpha \hat{c}) + \alpha z^*(\hat{c}) \right\} - z^*(c) .$$

To prove (15), we demonstrate that strong duality holds by applying Theorem 4.3.8 of Borwein and Lewis (2010). In our setting, the primal problem is the problem on the right-hand side of (16). This problem corresponds to the primal minimization problem in Borwein and Lewis (2010) by considering the objective function given by  $-c^Tw + I_S(w)$  and the constraint function  $\hat{c}^Tw - z^*(\hat{c})$ . (Note that  $I_S(w)$  is the convex indicator function equal to 0 when  $w \in S$  and  $+\infty$  otherwise.) Since S is a compact and convex set, we satisfy all of the assumptions of Theorem 4.3.8 of Borwein and Lewis (2010) and hence strong duality holds. Finally, since  $q(\cdot)$  is a monotone decreasing function, we can apply the monotone convergence theorem to replace  $\inf_{\alpha \geq 0}$  in (15) by  $\lim_{\alpha \to \infty}$ .

#### B.3. Proof of Proposition 3.

*Proof.* Part (1.) is exactly the chain of inequalities (5)-(9). Since the support function  $\xi_S(\cdot)$  is a maximum of linear functions, it is convex and therefore part (2.) follows. To see that part (3.) holds, for any  $\tilde{c}$ , we have that:

$$\ell_{\text{SPO+}}(\tilde{c},c) = \xi_S(c-2\tilde{c}) + 2\tilde{c}^T w^*(c) - z^*(c)$$

$$\geq \xi_S(c-2\hat{c}) + w^*(2\hat{c}-c)^T ((c-2\tilde{c}) - (c-2\hat{c})) + 2\tilde{c}^T w^*(c) - z^*(c)$$

$$= \xi_S(c-2\hat{c}) + 2w^*(2\hat{c}-c)^T (\hat{c}-\tilde{c}) + 2\tilde{c}^T w^*(c) - z^*(c)$$

$$= \xi_S(c-2\hat{c}) + 2\hat{c}^T w^*(c) - z^*(c) + 2(w^*(c) - w^*(2\hat{c}-c))^T (\tilde{c}-\hat{c}) ,$$

where the inequality follows since  $w^*(2\hat{c}-c) \in \arg\max_{w \in S} \{(c-2\hat{c})^T w\} = \partial \xi_S(c-2\hat{c})$  (this is a standard result in convex optimization, see, e.g., Boyd et al. (2004)). Thus, we conclude that  $2(w^*(c) - w^*(2\hat{c}-c)) \in \partial \ell_{\text{SPO+}}(\hat{c},c)$ .

#### B.4. Proof of Proposition 4.

*Proof.* In the same setup as Proposition 1, we have that S = [-1/2, +1/2] and  $c \in \{-1, +1\}$  corresponds to the true label. Note that  $\xi_S(c-2\hat{c}) = \frac{1}{2}|c-2\hat{c}|$ , and for  $c \in \{-1, +1\}$  we have  $w^*(c) = -c/2$  and  $z^*(c) = -1/2$ . Therefore,

$$\ell_{\text{SPO+}}(\hat{c},c) = \frac{1}{2}|c - 2\hat{c}| + 2\hat{c}(-c/2) + 1/2 = \frac{1}{2}|1 - 2\hat{c}c| - \hat{c}c + 1/2 = \max\{0, 1 - 2\hat{c}c\} \ ,$$

where the second equality follows since  $c \in \{-1, +1\}$ .  $\square$ 

#### B.5. Proof of Theorem 1.

Proof. Let  $x \in \mathcal{X}$  be fixed. Applying Assumptions 1.2, 1.3, and 1.4 with Proposition 6 implies that the vector  $\mathbb{E}[c|x] = \arg\min_{\substack{f(x) \in \mathbb{R}^d \\ f(x) \in \mathbb{R}^d}} \mathbb{E}_c[\ell_{\text{SPO+}}(f(x), c) \mid x]$ , i.e.,  $\mathbb{E}[c|x]$  is the unique minimizer of  $\mathbb{E}_c[\ell_{\text{SPO+}}(f(x), c) \mid x]$ . Thus, since  $\mathbb{E}_{(x,c) \sim \mathcal{D}}[\ell_{\text{SPO+}}(f(x), c)] = \mathbb{E}_x[\mathbb{E}_c[\ell_{\text{SPO+}}(f(x), c) \mid x]]$ , any minimizer of the SPO+ risk (12) must be almost surely equal to the function  $x \mapsto \mathbb{E}[c|x]$ .

Again, let  $x \in \mathcal{X}$  be fixed. If  $W^*(\mathbb{E}[c|x])$  is a singleton, then Proposition 5 implies that  $\mathbb{E}[c|x] \in \arg\min_{f(x) \in \mathbb{R}^d} \mathbb{E}_c[\ell_{\mathrm{SPO}}(f(x),c) \mid x]$ , i.e.,  $\mathbb{E}[c|x]$  is a minimizer of  $\mathbb{E}_c[\ell_{\mathrm{SPO}}(f(x),c) \mid x]$ . Since  $\mathbb{E}_{(x,c) \sim \mathcal{D}}[\ell_{\mathrm{SPO}}(f(x),c)] = \mathbb{E}_x[\mathbb{E}_c[\ell_{\mathrm{SPO}}(f(x),c) \mid x]]$  and Assumption 1.1 states that  $W^*(\mathbb{E}[c|x])$  is a singleton with probability 1 over x, we have that any function that almost surely equals the function  $x \mapsto \mathbb{E}[c|x]$  is a minimizer of the SPO risk (11). In particular, as argued in the preceding paragraph, any minimizer of the SPO+ risk (12) must be almost surely equal to the function  $x \mapsto \mathbb{E}[c|x]$  and therefore minimizes the SPO risk. Thus, we have shown that the SPO+ loss function is Fisher consistent with respect to the SPO loss.  $\square$ 

#### B.6. Proof of Proposition 5.

Proof. Consider a cost vector  $c^*$  that is a minimizer of  $R_{SPO}(\cdot)$ . Let  $\bar{w}$  be an optimal solution of  $P(\bar{c})$ , i.e.,  $\bar{w} \in W^*(\bar{c})$ , and let  $\tilde{c}$  be chosen such that  $\bar{w}$  is the unique optimal solution of  $P(\tilde{c})$ , i.e.,  $W^*(\tilde{c}) = \{\bar{w}\}$ . (Note that if  $\bar{w}$  is the unique optimal solution of  $P(\bar{c})$  then it suffices to select  $\tilde{c} \leftarrow \bar{c}$ , otherwise we may take  $\tilde{c}$  as a slight perturbation of  $\bar{c}$ ). Then it holds that:

$$0 \le R_{\text{SPO}}(\tilde{c}) - R_{\text{SPO}}(c^*) = \mathbb{E}_c \left[ \max_{w \in W^*(\tilde{c})} \left\{ c^T w \right\} \right] - \mathbb{E}_c \left[ \max_{w \in W^*(c^*)} \left\{ c^T w \right\} \right]$$

$$= \mathbb{E}_c[c^T \bar{w}] - \mathbb{E}_c \left[ \max_{w \in W^*(c^*)} \left\{ c^T w \right\} \right] = \bar{c}^T \bar{w} - \mathbb{E}_c \left[ \max_{w \in W^*(c^*)} \left\{ c^T w \right\} \right] \le \bar{c}^T \bar{w} - \max_{w \in W^*(c^*)} \left\{ \bar{c}^T w \right\} ,$$

where the first inequality and first equality are by definition, the second equality uses  $W^*(\tilde{c}) = \{\bar{w}\}$ , the third equality uses linearity of expectation, and the final inequality is Jensen's inequality. Finally, we conclude that, for any  $w \in W^*(c^*)$ , it holds that  $\bar{c}^T w \leq \bar{c}^T \bar{w} = z^*(\bar{c})$ . Therefore,  $W^*(c^*) \subseteq W^*(\bar{c})$ .

To prove the other direction, consider a cost vector  $c^*$  such that  $W^*(c^*) = \{w^*(c^*)\}$  is a singleton and  $W^*(c^*) \subseteq W^*(\bar{c})$ , i.e.,  $w^*(c^*) \in W^*(\bar{c})$ . Let  $c^{**}$  be an arbitrary minimizer of  $R_{\text{SPO}}(\cdot)$ . Then,

$$R_{\text{SPO}}(c^*) - R_{\text{SPO}}(c^{**}) = \mathbb{E}_c \left[ \max_{w \in W^*(c^*)} \left\{ c^T w \right\} \right] - \mathbb{E}_c \left[ \max_{w \in W^*(c^{**})} \left\{ c^T w \right\} \right]$$

$$= \bar{c}^T w^*(c^*) - \mathbb{E}_c \left[ \max_{w \in W^*(c^{**})} \left\{ c^T w \right\} \right]$$

$$= z^*(\bar{c}) - \mathbb{E}_c \left[ \max_{w \in W^*(c^{**})} \left\{ c^T w \right\} \right]$$

$$\leq z^*(\bar{c}) - \max_{w \in W^*(c^{**})} \left\{ \bar{c}^T w \right\} \leq 0 ,$$

where the second equality uses  $W^*(c^*) = \{w^*(c^*)\}$ , the third equality uses  $w^*(c^*) \in W^*(\bar{c})$ , and the first inequality is Jensen's inequality. Finally, we conclude that since  $c^{**}$  is a minimizer of  $R_{\text{SPO}}(\cdot)$  and  $c^*$  has at most the same risk, then  $c^*$  is also a minimizer of  $R_{\text{SPO}}(\cdot)$ .  $\square$ 

#### B.7. Proof of Proposition 6.

Proof. (a) First, note that it is straightforward to show that  $R_{\text{SPO+}}(\hat{c})$  is finite valued for all  $\hat{c}$ , which follows since S is compact and  $\bar{c} := \mathbb{E}[c]$  is finite. Moreover, by Proposition 3, it is clear that  $R_{\text{SPO+}}(\cdot)$  is convex on  $\mathbb{R}^d$ . In particular, for any point  $\hat{c}$  the subdifferential  $\partial R_{\text{SPO+}}(\hat{c})$  is nonempty and, since  $R_{\text{SPO+}}(\hat{c})$  is finite, we have that  $\partial R_{\text{SPO+}}(\hat{c}) =$ 

 $\mathbb{E}_c[\partial \ell_{\text{SPO+}}(\hat{c},c)]$  (see Strassen (1965), Bertsekas (1973)), where the latter refers to the selection expectation over the random set  $\partial \ell_{\text{SPO+}}(\hat{c},c)$  (see Section 2.1.2 in Molchanov (2005)). By the linearity of selection expectation, note that  $\partial R_{\text{SPO+}}(\hat{c}) = -2\mathbb{E}_c[W^*(2\hat{c}-c)] + 2\mathbb{E}_c[w^*(c)] = -2\mathbb{E}_c[w^*(2\hat{c}-c)] + 2\mathbb{E}_c[w^*(c)]$ , where the second equality follows since the distribution of c is continuous on all of  $\mathbb{R}^d$  which implies that  $W^*(2\hat{c}-c)$  is a singleton with probability 1 (see, e.g., the introductory discussion in Drusvyatskiy and Lewis (2011)).

Now, the optimality conditions for the convex problem  $\min_{\hat{c} \in \mathbb{R}^d} R_{\text{SPO+}}(\hat{c})$  state that  $c^*$  is a global minimizer if and only if  $0 \in \partial R_{\text{SPO+}}(c^*)$ . By the discussion in the previous paragraph, the optimality conditions may be equivalently written as  $\mathbb{E}_c[w^*(c)] = \mathbb{E}_c[w^*(2c^*-c)]$ . Finally, since c is centrally symmetric around its mean, we have that c is equal in distribution to  $2\bar{c}-c$ ; hence  $\mathbb{E}_c[w^*(c)] = \mathbb{E}_c[w^*(2\bar{c}-c)]$ . Therefore  $\bar{c}$  satisfies  $0 \in \partial R_{\text{SPO+}}(\bar{c})$  and is an optimal solution of  $\min_{\hat{c} \in \mathbb{R}^d} R_{\text{SPO+}}(\hat{c})$ .

(b) Consider any vector  $\Delta \neq 0$ , and let us rewrite the difference  $R_{\text{SPO+}}(\bar{c} + \Delta) - R_{\text{SPO+}}(\bar{c})$  as follows:

$$R_{\text{SPO+}}(\bar{c} + \Delta) - R_{\text{SPO+}}(\bar{c}) = \mathbb{E}_{c}[\xi_{S}(c - 2(\bar{c} + \Delta)) + 2(\bar{c} + \Delta)^{T}w^{*}(c) - z^{*}(c)] - \mathbb{E}_{c}[\xi_{S}(c - 2\bar{c}) + 2\bar{c}^{T}w^{*}(c) - z^{*}(c)]$$

$$= \mathbb{E}_{c}[\xi_{S}(c - 2\bar{c} - 2\Delta) - \xi_{S}(c - 2\bar{c}) + 2\Delta^{T}w^{*}(c)]$$

$$= \mathbb{E}_{c}[\xi_{S}(c - 2\bar{c} - 2\Delta) - (c - 2\bar{c})^{T}w^{*}(2\bar{c} - c) + 2\Delta^{T}w^{*}(c)]$$

$$= \mathbb{E}_{c}[\xi_{S}(c - 2\bar{c} - 2\Delta) - (c - 2\bar{c} - 2\Delta)^{T}w^{*}(2\bar{c} - c)]$$

$$= \mathbb{E}_{c}[(c - 2\bar{c} - 2\Delta)^{T}(w^{*}(2\bar{c} + 2\Delta - c) - w^{*}(2\bar{c} - c))].$$

The first equality follows from the definitions of  $R_{\rm SPO+}(\cdot)$  and  $\ell_{\rm SPO+}(\cdot,\cdot)$ , the second follows from linearity of expectation, and the third follows from the definition of  $\xi_S(\cdot)$ . The fourth equality follows from the fact that c is symmetric about its mean so  $\mathbb{E}_c[w^*(c)] = \mathbb{E}_c[w^*(2\bar{c}-c)]$  and again uses linearity of expectation. The fifth equality follows from the definition of  $\xi_S(\cdot)$ . Since  $w^*(2\bar{c}+2\Delta-c)$  is the maximizer for  $c-2\bar{c}-2\Delta$ , we have that  $(c-2\bar{c}-2\Delta)^T(w^*(2\bar{c}+2\Delta-c)-w^*(2\bar{c}-c))$  is a nonnegative random variable. Moreover, since the distribution of c is continuous on all of  $\mathbb{R}^d$  and the interior of S is non-empty, there must be some probability mass where  $w^*(2\bar{c}+2\Delta-c)$  disagrees with  $w^*(2\bar{c}-c)$ , i.e., it holds that  $\mathbb{P}(w^*(2\bar{c}+2\Delta-c)\neq w^*(2\bar{c}-c))>0$ . Note also that  $w^*(2\bar{c}+2\Delta-c)$  is the unique maximizer for  $c-2\bar{c}-2\Delta$  with probability one. Thus, we have  $\mathbb{P}((c-2\bar{c}-2\Delta)^T(w^*(2\bar{c}+2\Delta-c)-w^*(2\bar{c}-c))>0)>0$  and therefore

$$R_{\text{SPO+}}(\bar{c} + \Delta) - R_{\text{SPO+}}(\bar{c}) = \mathbb{E}_c[(c - 2\bar{c} - 2\Delta)^T(w^*(2\bar{c} + 2\Delta - c) - w^*(2\bar{c} - c))] > 0$$
.

Thus  $\bar{c} + \Delta$  is not a minimizer of the SPO+ risk, and  $\bar{c}$  must be the unique minimizer.  $\Box$ 

#### B.8. Proof of Proposition 7

*Proof.* Recall that  $\ell_{SPO+}(Bx_i, c_i) = \xi_S(c_i - 2Bx_i) + 2(Bx_i)^T w^*(c_i) - z^*(c_i)$ . Linear programming strong duality implies that:

$$\xi_S(c_i - 2Bx_i) = \max_w (c_i - 2Bx_i)^T w = \min_p -b^T p_i$$
  
s.t.  $Aw \ge b$  s.t.  $-A^T p = c_i - 2Bx_i$   
 $p \ge 0$ .

Note also that  $2(w^*(c_i)x_i^T) \bullet B$  is just a rewriting of  $2(Bx_i)^Tw^*(c_i)$  as an explicit linear function. Thus, introducing variables  $p_i \in \mathbb{R}^m$  for each  $i \in \{1, ..., n\}$ , it is clear that (14) is equivalent to (13).  $\square$ 

## <span id="page-42-1"></span>C. Stochastic Gradient Approach

The idea of this approach is to apply a stochastic gradient method (see, for example, (Robbins and Munro 1951), Bottou et al. (2018), and the references therein) directly to problem (13) in its original format. For this approach, we assume that the regularizer is convex and subdifferentiable (i.e., we can efficiently compute subgradients of  $\Omega(\cdot)$ ). For example, the ridge penalty  $\Omega(B) = \frac{1}{2} \|B\|_F^2$  and  $\ell_1$  penalty  $\Omega(B) = \|B\|_1$  satisfy this assumption. While the algorithm presented herein is generic and can be applied to any subdifferentiable regularizer, it is worth mentioning that an alternative approach to differentiating the regularizer  $\Omega(\cdot)$  is to apply a proximal gradient type method Parikh et al. (2014), which instead relies on utilizing the specific functional form of certain regularizers.

Let us now describe some more details about how to apply this approach. For convenience, let us write the objective function of (13) as  $L_{\text{SPO+}}^n(B) := \frac{1}{n} \sum_{i=1}^n \phi_i(B)$ , where  $\phi_i(B) := \ell_{\text{SPO+}}(Bx_i, c_i) + \lambda \Omega(B)$ . As mentioned in Proposition 3,  $\ell_{\text{SPO+}}(\cdot, c)$  is convex (but not necessarily differentiable) for a fixed c and therefore  $\phi_i(\cdot)$  is a convex function. The following proposition describes how to compute subgradients of  $\phi_i(\cdot)$  and also builds on Proposition 3.

<span id="page-42-0"></span>PROPOSITION 8 (Subgradient for SPO+ Linear Regression). Let  $(x_i, c_i)$  for  $i \in \{1, ..., n\}$ ,  $B \in \mathbb{R}^{d \times p}$ , and  $\Psi \in \partial \Omega(B)$  be given. Then, it holds that  $2(w^*(c_i) - w^*(2Bx_i - c_i))x_i^T + \lambda \Psi \in \partial \phi_i(B)$ .

*Proof.* Recall from Proposition 3 that  $2(w^*(c_i) - w^*(2\hat{c} - c_i)) \in \partial \ell_{SPO+}(\hat{c}, c_i)$  for any  $\hat{c}$ . Thus, letting  $\hat{c} \leftarrow Bx_i$  yields for any B' that:

$$\ell_{\text{SPO+}}(B'x_i, c_i) \geq \ell_{\text{SPO+}}(Bx_i, c_i) + 2(w^*(c_i) - w^*(2Bx_i - c_i))^T (B'x_i - Bx_i)$$

$$= \ell_{\text{SPO+}}(Bx_i, c_i) + (2(w^*(c_i) - w^*(2Bx_i - c_i))x_i^T) \bullet (B' - B),$$

and hence 
$$2(w^*(c_i) - w^*(2Bx_i - c_i))x_i^T \in \partial \ell_{SPO+}(Bx_i, c_i)$$
. Therefore,  $2(w^*(c_i) - w^*(2Bx_i - c_i))x_i^T + \lambda \Psi \in \partial \ell_{SPO+}(Bx_i, c_i) + \partial \Omega(B) = \partial \phi_i(B)$ .  $\square$ 

Algorithm 1 presents the application of stochastic subgradient descent with mini-batching to problem (13). Algorithm 1 is a standard application of stochastic subgradient descent in our setting, and closely follows Nemirovski et al. (2009). It is important to emphasize that the main computational requirement of Algorithm 1 is access to the optimization oracle  $w^*(\cdot)$  for problem (2), which is utilized N times during each iteration of the method. Therefore, Algorithm 1 may be applied in any case when a practically efficient optimization oracle is available, including some combinatorial and mixed-integer problems as mentioned in Remark 2. The main parameters that need to be set are the batch size parameter Nand the step-size sequence  $\{\gamma_t\}$  (in addition to the regularization parameter  $\lambda$ ). In Section 6, we describe precisely how we set these parameters for our experiments. In general, we recommend setting the batch size parameter to a fixed constant such as 5 or 10. The choice of the step-size depends on the properties of the regularizer  $\Omega(\cdot)$ . For general convex  $\Omega(\cdot)$ , or simply when  $\lambda = 0$ , we recommend following Nemirovski et al. (2009) where it is suggested to set the step-size sequence to  $\gamma_t = \frac{\theta}{\sqrt{t+1}}$  for a fixed constant  $\theta > 0$ . In the case of the ridge penalty  $\Omega(B) = \frac{1}{2} ||B||_F^2$  and when  $\lambda > 0$ , since this function is strongly convex one may alternatively set the step-size sequence to  $\gamma_t = \frac{2}{\lambda(t+2)}$ . Since the SPO+ loss function is convex but non-smooth (and also Lipschitz continuous), these are essentially the only two options that will lead to a precise convergence rate guarantee. Indeed, for the sequence  $\gamma_t = \frac{\theta}{\sqrt{t+1}}$ , Nemirovski et al. (2009) derive an  $O(1/\epsilon^2)$  complexity guarantee in terms of the number of iterations required to ensure that the averaged iterate is  $\epsilon$ -suboptimal in expectation. It is also straightforward to see that this guarantee can be extended to cases when the optimization oracle  $w^*(\cdot)$  is only computed approximately with an additive approximation error, as long as we only desire convergence on the order of the accuracy of the oracle. On the other hand, Lacoste-Julien et al. (2012) derive a similar  $O(1/(\lambda \epsilon))$  complexity guarantee for the  $\gamma_t = \frac{2}{\lambda(t+2)}$  sequence.

## <span id="page-44-1"></span>Algorithm 1 Stochastic Subgradient Descent with Mini-Batching for Problem (13)

Initialize  $B_0 \in \mathbb{R}^{d \times p}$  (typically  $B_0 \leftarrow 0$ ),  $t \leftarrow 0$ . Set batch size parameter  $N \ge 1$ .

At iteration  $t \ge 0$ :

1. For j = 1, ..., N:

Sample i uniformly at random from the set  $\{1, ..., n\}$ .

Compute 
$$\tilde{w}_t^j \leftarrow w^*(2B_tx_i - c_i)$$
.

Set 
$$\tilde{G}_t^j \leftarrow (w^*(c_i) - \tilde{w}_t^j) x_i^T$$
.

2. Select  $\gamma_t > 0$  and compute:

$$\Psi_t \in \partial \Omega(B_t)$$

$$G_t \leftarrow \frac{1}{N} \sum_{j=1}^{N} \tilde{G}_t^j + \lambda \Psi_t$$

$$B_{t+1} \leftarrow B_t - \gamma_t G_t$$

$$\bar{B}_t \leftarrow \frac{1}{\sum_{s=0}^t \gamma_s} \sum_{s=0}^t \gamma_s B_s$$
 .

It is important to note that Algorithm 1 is a standard and basic application of stochastic subgradient descent, and that one may consider making several adjustments to the method in order to improve its practical and possibly theoretical performance (see, e.g., Bottou (2012), and Bottou et al. (2018) and the references therein). We also mention that one may employ early stopping with this method, whereby we maintain a validation set to monitor (estimates of) the out-of-sample true SPO loss as the algorithm runs and then ultimately choose the averaged iterate  $\bar{B}_t$  with the smallest true SPO loss  $\ell_{\rm SPO}$  on the validation set as the final model.

#### <span id="page-44-0"></span>D. Experimental Details of Portfolio Optimization Application

In this experiment, we set the number of assets d = 50 and the return vectors and features are synthetically generated according to a similar process as before. As before, we generate a random matrix  $B^* \in \mathbb{R}^{d \times p}$  that encodes the parameters of the true model, whereby each entry of  $B^*$  is Bernoulli random variable that is equal to 1 with probability 0.5. Then, for some noise level parameter  $\tau \geq 0$ , we generate a factor loading matrix  $L \in \mathbb{R}^{50 \times 4}$  such that each entry of L is uniformly distributed on  $[-0.0025\tau, 0.0025\tau]$  independently of everything else. To generate a training/testing pair  $(x_i, c_i)$ , as before we first generate the feature vector  $x_i \in \mathbb{R}^p$  from a multivariate Gaussian distribution with i.i.d. standard normal entries, i.e.,

x<sup>i</sup> ∼ N(0, Ip). Then, the incremental return vector r˜<sup>i</sup> is generated according to the following process:

- 1. The conditional mean r¯ij of the j th asset return is set equal to r¯ij := 0.05 √p (B∗xi)<sup>j</sup> + (0.1)<sup>1</sup>/degdeg , where deg is a fixed positive integer parameter.
- 2. The observed return vector r˜<sup>i</sup> is set to r˜<sup>i</sup> := ¯r<sup>i</sup> + Lf + 0.01τε, where f ∼ N(0, I4) and ε ∼ N(0, I50). The cost vector c<sup>i</sup> is set to c<sup>i</sup> := −r˜<sup>i</sup> .

It follows from step (2.) above that, conditional on the observed features x<sup>i</sup> ∈ R p , the covariance matrix of the returns is Σ = LL<sup>T</sup> + (0.01τ ) 2 I50. We set the risk level parameter γ, which is part of the definition of the feasible region S, to γ := 2.25 · w¯ <sup>T</sup>Σ ¯w where w¯ := e/10 is the equal weight portfolio. Note that the particular functional form of the conditional mean returns in step (1.) above is also a polynomial function of the features x and that the parameters are set so that r¯ij ∈ [0, 1] with high probability. In this experiment, the number of features p is again kept fixed at 5. We varied the training set size n ∈ {100, 1000}, the parameter deg ∈ {1, 4, 8, 16}, and the noise level parameter τ ∈ {1, 2}. For each combination of these two parameters, we again ran 50 independent trials and used a test set of size 10,000. We do not use any regularization in this experiment, we use the SGD approach (Algorithm [1](#page-44-1) of Appendix [C\)](#page-42-1) for training the SPO+ model of method (1.), and in the same manner as before we directly solve the optimization problems of methods (2.) and (3.) using Gurobi. Note that, out of fairness to the other methods, we did not use the early stopping technique for SGD.