# APPROXIMATION TO BAYES RISK IN REPEATED PLAY James Hannan<sup>1</sup>

#### SUMMARY

This paper is concerned with the development of a dynamic theory of decision under uncertainty. The results obtained are directly applicable to the development of a dynamic theory of games in which at least one player is, at each stage, fully informed on the joint empirical distribution of the past choices of strategies of the rest. Since the decision problem can be imbedded in a sufficiently unspecified game theoretic model, the paper is written in the language and notation of the general two person game, in which, however, player I's motivation is completely unspecified.

Sections 2 - 7 consider a sequence game based on N successive plays of the same m by n game and culminate in Theorem 4 which exhibits a usable sequence-strategy for II, consisting in the use at the (k+1)-st play of a strategy Bayes against the perturbation of I's cumulative past choice by the addition of  $[3n^2/2m]^{1/2}k^{1/2}z$ , with z chosen at random from the unit m-cube.

With |B| denoting the maximum difference within rows of II's inutility matrix, Theorem 4 asserts that the expected inutility incurred by this strategy across N plays, less N times the single-game Bayes inutility against I's empirical distribution of choices within the N plays, is bounded above by  $[3n^2m/2]^{1/2}|B|N^{1/2}$ , uniformly in N and in I's N choices.

For fixed N, a sequence-strategy which minimizes the maximum of the criterion of Theorem 4 is characterized by a recursive program in Section 4. Except in the trivial case where II has a dominant column, the resulting min-max is bounded below by a non-zero multiple of  $N^{1/2}$  (Theorem 2). In a slight generalization of Matching Pennies the solution to the recursive program and the resulting min-max are explicitly exhibited.

Sections 8 - 9 consider the sequence game when the component game may be non-finite. For the restrictive class of non-finite games where a

Bayes response satisfies a Lipschitz condition of order  $\alpha>0$ , Theorem 5 asserts that the criterion of Theorem 4 is  $O(\Sigma_1^N k^{-\alpha})$  when II's strategy consists in the use of the values of this Bayes response at the successive cumulative past choices of I. The game on the square with II's inutility given by squared deviation illustrates the non-vacuity of Theorem 5 for  $\alpha\leq 1$ .

For the class of games where I has only a finite number, m, of pure strategies, Theorem 6 asserts, under regularity conditions vacuously satisfied by finite games, the truth of the natural generalization of Theorem 4 with the n of the strategy and bounds replaced by 2.

The appendix considers a semi-dynamic game suggested by an interpretation of problem 13 (ii) in the first of these Contributions. If I uses a fixed randomized strategy x on each play independently, II's expected inutility, less N times the single-game Bayes inutility against x, is O(1) when II's strategy choices are the values of any Bayes response at the successive cumulative past choices of I (Theorem 7).

## §1. INTRODUCTION

A finitary form of the (static) decision problem with numerical utilities may be described briefly as follows: exactly one of n possible decisions is required to be made in a context in which the decision-maker knows only that one of m possible states of nature obtains and, for each decision and each state, the inutility a of decision j when state i obtains.

The problem of choosing a decision which will in some sense minimize inutility has been resolved by many principles of solution [12], [13], and [16]. These principles have in each case been suggested and to some extent supported by the additional assumptions associated with some class of realizations. In particular the classical Bayes principle introduces the assumption that the state index i is subject to a known (a priori) probability distribution. Under this assumption, which is considered much too restrictive for many realizations, a decision which minimizes expected inutility is a very satisfactory solution of the problem.

The present paper is concerned with a sequence of N decision problems, which are formally alike except for the fact that the state of nature may vary arbitrarily from problem to problem. Decisions are required to be made successively and it is assumed that they may be allowed to depend on the e.d. (empirical distribution) of the states of nature across the previous problems in the sequence. This total lack of assumptions regarding the behavior of the state sequence is a feature distinguishing the present structure from many considerations of multistage processes

(cf. for example [1], [9]).

ŧ,

In a certain sense the opportunity for minimizing the average inutility of the set of N decisions depends on the e.d. of the N states involved. If this e.d. were known before any decisions had to be made, this knowledge would enable the choice of a decision Bayes with respect to this distribution. The repeated use of such a decision would reduce the average inutility across problems to the minimum expected inutility on a single problem where the Bayes assumption holds and the probability distribution on the state index is the same as the e.d. of the N states in the sequence problem (see (4.10)).

Another hypothetical situation, somewhat more suggestive for the sequence problem, is that in which successive decisions are permitted to depend on the successive e.d. of all states thru their respective presents. The use of decisions Bayes with respect to these distributions reduces average inutility to not more than the Bayes single-problem inutility with respect to the N-state e.d. (see (6.4) ff.).

The most important conclusion of this paper is that the knowledge of the successive e.d. of past states makes it constructively possible to do almost as well at reducing the average inutility across problems as in the case where N and the distribution of the N states are known in advance (or even as in the case of the preceding paragraph). The sequence of decisions exhibited which attain this performance is a sequence of randomized (not necessarily properly) decisions whose expectations are the values of a sequence of smoothed versions of the Bayes response at the successive e.d. of previous states.

The idea of using the Bayes inutility against the N-state e.d. as a goal for the performance of a set of decisions (distinguished by the term compound decision problem and with stochastic information on the N-state e.d. replacing the knowledge of past e.d. in the sequence problem) was enunciated in [14]. The program outlined in [14] for the rigorous investigation of compound decision problems was initiated in [6] and these papers exerted a strong influence on the sequence development.

The inadequacy of min-max solutions has long been noted in connection with statistical decision problems and [7], [8], [11], [14], [18], [19], are particularly relevant. The fact that this inadequacy is always present in certain compound decision problems was noted in [14] and [6]. An, example of a compound problem in which the min-max solution fails to be a direct product is exhibited in [17].

Within the theory of games the need for a dynamic theory is documented in [13] and [10]. The main development of the present paper constitutes an approach to the solution of a strong form of problem (13), part

100

(11) in [10]. A weak form is considered in an Appendix.

The use of the Bayes response across a sequence of games is coincident with a one-sided version of "the method of fictitious play", [3], [4], and [15]. Theorem 5, applied to a zero sum game in which the hypotheses of the theorem are satisfied for both players, yields an interesting bound on the rate of convergence of the method.

# PART I. FINITE GAMES

## \$2. THE COMPONENT GAME, G

The main purpose of this section is to introduce the notational framework of a single finite game, later to be used as the generic component of a sequence of games. The single game terminology can also be applied to the normal form of sequence games and for this purpose some extensions of the concept of "regret" (the loss of [16]) are introduced. These may induce interesting orderings in games with sufficient structure and, in particular, will do so for the sequence games of Section 3.

Let G be a finite two-person general game in which players and II have, respectively, m and n strategies. Their spaces of randomized strategies will be denoted by X and Y,

(1) 
$$X = \left[ x = (x_1, x_2, \dots, x_m) \mid x_1 \ge 0 \quad \sum_{1}^{m} x_1 = 1 \right]$$

$$Y = \left[ y = (y_1, y_2, \dots, y_n) \mid y_j \ge 0 \quad \sum_{1}^{n} y_j = 1 \right],$$

and their pure strategies will be represented

(2) 
$$\begin{aligned} & \boldsymbol{\epsilon} &= (\boldsymbol{\epsilon}_1, \ \boldsymbol{\epsilon}_2, \ \dots, \ \boldsymbol{\epsilon}_m) & \text{a basis vector in } \boldsymbol{X} \ , \\ & \boldsymbol{\delta} &= (\boldsymbol{\delta}_1, \ \boldsymbol{\delta}_2, \ \dots, \ \boldsymbol{\delta}_n) & \text{a basis vector in } \boldsymbol{Y} \ . \end{aligned}$$

In accord with the dominant decision theoretic orientation, the game will be consistently viewed from the position of player II. Nothing will be assumed about player I's motivation and the game will be defined only up to player II's inutility which will be described by a loss matrix A. The elements of A will be denoted by  $a_{ij}$  (or  $A_i^j$ ), the rows by  $A_i$  and the columns by  $A_i^j$ .

(3) 
$$A = \begin{bmatrix} a_{11} & a_{12} & \cdots & a_{1n} \\ \vdots & \vdots & \cdots & \vdots \\ a_{m1} & a_{m2} & \cdots & a_{mn} \end{bmatrix} = \begin{bmatrix} A_1 \\ \vdots \\ A_m \end{bmatrix} = [A^1 A^2 \cdots A^n]$$

To exclude trivial games, it will be assumed that A has no dominant column, for each j

$$\max_{\epsilon} \left[ \epsilon A^{j} - \min_{r} \epsilon A^{r} \right] > 0 ,$$

and, to avoid notation distinguishing a subset of non-weakly-dominated columns, that A has no dominated or duplicated column, for each j

(5) 
$$\epsilon A^{j} \geq \epsilon Ay \text{ for all } \epsilon \text{ only if } y_{j} = 1$$
.

The expectation of the loss when II uses a randomized strategy y will be called the risk,

$$R(\epsilon, y) = \mathcal{E}_{y} \epsilon A \delta = \epsilon A \mathcal{E}_{y} \delta = \epsilon A y$$
.

For given y, the risk function is representable as the vector, s = Ay, and the mapping from Y to S = AY furnishes a convenient canonical form for G. From the point of view of risk, G is identical with the game in which II's pure strategies are m-vectors in the set of columns of A,

(6) 
$$\sigma = (\sigma_1, ..., \sigma_m) \text{ in } \{A^1, A^2, ..., A^n\}$$
,

II's randomized strategies are m-vectors in the convex hull of the columns of A,

(7) 
$$s = (s_1, ..., s_m)$$
 in  $S = (Ay | y in Y)$ ,

and the risk of s in S is given by the scalar product

(8) 
$$R(\epsilon, s) = \mathcal{E}_{y} \epsilon \sigma = \epsilon \mathcal{E}_{y} \sigma = \epsilon s .$$

For each x in X the minimum of the expectation of risk,

is attained for s in the convex hull of the set of minimizing  $\sigma$ . This minimum will be called the Bayes risk against x and any minimizing s will be called a Bayes strategy against x. Considered as functions, Ø and s, on X, Ø will be termed the Bayes envelope, s a Bayes response. It is convenient to extend their definition to the whole of m-space by

$$\emptyset(w) = \min ws = \min w\sigma$$
 (9) 
$$s = \sigma$$
 
$$s = \text{any function to S such that } ws(w) = \emptyset(w) \text{ for each } w \text{ .}$$

Ł

1 O2 HANNAN

Some continuity properties of the Bayes envelope and the risks of Bayes strategies are immediate consequences of their definitions. These properties are little utilized in static game theory and their importance here stems from their direct use and analogical value in connection with the sequence games to be introduced in Section 3.

The Bayes envelope is known to be concave and continuous in more general games ([2] Theorem 2.27). Here Ø, as the minimum of a finite class of linear functions, is concave and piecewise linear, and

(10) 
$$(w - w')s(w) \leq \emptyset(w) - \emptyset(w') \leq (w - w')s(w') .$$

Although any Bayes response will be discontinuous at every point of possible ambiguity, each Bayes response possesses a local weak continuity at each w,

(11) 
$$ws(w') - \emptyset(w) = w[s(w') - s(w)] < (w - w')[s(w') - s(w)]$$
.

Introducing the several norms for m-vectors,

(12) 
$$\|v\| = \sum_{i=1}^{m} |v_{i}| \quad |v| = \max_{i} |v_{i}|$$
,

and the uniform bound on the variation of any Bayes response,

$$|B| = \sup_{w,w'} |s(w') - s(w)| = \max_{\sigma} \max_{\epsilon} [\epsilon \sigma - \emptyset(\epsilon)]$$

$$= \max_{j} \max_{i} \left[A_{i}^{j} - \min_{r} A_{i}^{r}\right] ,$$

the inequality (11) may conveniently be weakened to

(14) 
$$ws(w') - \emptyset(w) \le ||w - w'|| ||s(w') - s(w)|| \le ||w - w'|| ||B||$$
.

Letting  $W_j = [w \mid wA^j = \emptyset(w)]$ ,  $\emptyset$  is linear on each  $W_j$  and each  $W_j$  is convex and closed. Each  $W_j$  not containing a given w has a positive distance from it and, letting d(w) be the minimum of these distances (or  $+\infty$  if not otherwise defined), it follows that each  $\sigma$  which is Bayes with respect to a w' in the open neighborhood

$$\sum_{1}^{m} \left( w_{1}^{\prime} - w_{1} \right)^{2} < d^{2}(w)$$

(and hence also each s(w')) is necessarily Bayes with respect to w,

(15) 
$$ws(w') - \emptyset(w) > 0$$
 only if  $\sum_{i=1}^{m} (w'_{i} - w_{i})^{2} \ge d^{2}(w)$ .

The bound (11) is thus improved to zero for all  $\|w - w'\|$  sufficiently small, quite non-uniformly in w.

In zero-sum games against an intelligent opponent, attention has been concentrated on the ordering of II's strategies induced by their maximum risk. Letting R(s) denote

$$\max_{\varepsilon} \ \epsilon \mathbf{s} \quad ,$$

the value of G is given by

$$R = \min_{s} R(s)$$

and, by the min-max theorem,

(16) 
$$R = \max \min_{\mathbf{X}} \mathbf{x} \sigma = \max_{\mathbf{X}} \emptyset(\mathbf{x}) .$$

In games against Nature, the Bayes envelope is considered a worthy defensive goal for II since it is usually felt that I's move is in no way influenced by II's choice of strategy. As a consequence, a strategy s is evaluated for each x in X in terms of the "regret", the additional expected risk above  $\emptyset(x)$  which it incurs,

(17) 
$$D(x, s) = xs - \emptyset(x)$$
.

D(x, s) is clearly non-negative and its maximum with respect to x is frequently used to establish a complete ordering on S. It follows from the concavity of  $\emptyset$  that  $\mathcal{E}_{x}[\epsilon s - \emptyset(\epsilon)] \geq xs - \emptyset(x)$  and hence that equality holds in

$$\max_{\varepsilon} D(\varepsilon, s) \leq \max_{x} D(x, s) .$$

Because of the assumption (4)

$$D(s) = \max_{x} D(x, s) = \max_{\varepsilon} D(\varepsilon, s) = \max_{\varepsilon} [\varepsilon s - \emptyset(\varepsilon)] > 0 ,$$

$$D = \min_{s} D(s) > 0 ,$$

and, since

$$\max_{\epsilon} \left[ \epsilon s - \emptyset(\epsilon) \right] = \max_{X} \mathcal{E}_{X} [\epsilon s - \emptyset(\epsilon)] = \max_{X} \left[ xs - \mathcal{E}_{X} \emptyset(\epsilon) \right] ,$$

the min-max theorem yields the representation,

1 04 HANNAN

(19) 
$$D = \min \max_{\mathbf{x}} \left[ \mathbf{x} \mathbf{x} - \mathcal{E}_{\mathbf{x}} \emptyset(\epsilon) \right] = \max_{\mathbf{x}} \min_{\mathbf{x}} \left[ \mathbf{x} \mathbf{x} - \mathcal{E}_{\mathbf{x}} \emptyset(\epsilon) \right]$$

$$= \max_{\mathbf{x}} \left[ \emptyset(\mathbf{x}) - \mathcal{E}_{\mathbf{x}} \emptyset(\epsilon) \right] .$$

The restriction of the regret function,  $D(\varepsilon,\,s)$ , is associated with the degenerate (pointwise) partition of I's pure strategies. Developments in connection with the sequence games of Section 3 suggest that, in certain structured games, it may be of interest to consider modifications of regret associated with more general partitions of I's pure strategies. Letting  $\pi$  be a function of  $\varepsilon$  whose values partition I's pure strategies, T a subset of S, define the T-envelope of maximum risks on the partition  $\pi$ ,

(20) 
$$\emptyset^{T}(\pi) = \inf_{s \in T} \max_{\epsilon \mid \pi(\epsilon)} \epsilon s ,$$

and define the regret of a strategy s, relative to the use of T with the knowledge of  $\pi(\epsilon)$ , to be  $\epsilon s$  -  $\emptyset^T(\pi(\epsilon))$  (cf. [8], [18]).

# §3. THE SEQUENCE GAME, $G^N$

 $extsf{G}^{ extsf{N}}$  will denote a game consisting of N successive plays of G where the choices of pure strategies in the component games are completely unrestricted, II's choice in each component is allowed to depend on I's choices in previous components, and the loss is taken to be the sum (or average) of the losses of the component games.

The component G will be considered purely from the point of view of the normal form and the terminological accumulation will be reduced by referring to pure strategies in the component G as moves. (The results of the paper will find their most immediate application to games where I's pure strategies are moves in the ordinary sense.)

Denoting non-randomized move sequences in  $G^{\mathbb{N}}$  by the direct product of the m-vectors representing moves in the component games and introducing the abbreviations

$$\underline{\epsilon}^{\mathbf{r}} = \lambda_{1}^{\mathbf{r}} \epsilon^{\mathbf{k}} \qquad \underline{\sigma}^{\mathbf{r}} = \chi_{1}^{\mathbf{r}} \sigma^{\mathbf{k}}$$
(1)
$$\underline{\epsilon} = \underline{\epsilon}^{\mathbf{N}} \qquad \underline{\sigma} = \underline{\sigma}^{\mathbf{N}} ,$$

the total loss of any play in GN will be denoted by the function

(2) 
$$R^{\mathbb{N}}(\underline{\epsilon}, \underline{\sigma}) = \sum_{1}^{\mathbb{N}} \epsilon^{\mathbb{N}} \sigma^{\mathbb{N}}.$$

In the sequence game the unsymmetric treatment of the players will be continued. It will not be necessary to introduce strategies for I since the class of results to be obtained will hold uniformly in the move sequences of I. The present and following sections are exceptional only in that it is sometimes technically convenient to consider certain linear functions of II's sequence risk which would be readily interpretable in terms of strategies for I.

The determination of  $G^N$  will be completed (and II's class of strategies implicitly circumscribed) by specifying the extent of II's knowledge of N. Two alternative situations are envisaged:

the weak sequence game,  $\,\mathrm{N}\,$  is known to II at each component; the strong sequence game,  $\,\mathrm{N}\,$  is completely unknown to II.

The principal results of later sections will involve strong strategies and hence will apply to either form of  $G^N$ . In this connection it should be noted that the selection by II of a move sequence,  $\chi_1^N \sigma^k$ , in the strong sequence game can only be accomplished by the selection of a move sequence,  $\chi_1^\infty \sigma^k$ , in  $G^\infty$ . Such selection is implicit in all results involving strong strategies.

Non-randomized sequence strategies for II will be denoted by  $\underline{\sigma(\underline{\epsilon})} = \chi_1^N \sigma^k(\underline{\epsilon}^{k-1}) \quad \text{and their risk given by the natural extension of (2).}$  Because of the linearity of the loss in the component moves, the sequence risks attainable by arbitrary randomization are attained by the class of randomized sequence strategies induced by product p-measures,  $\underline{\gamma}(\underline{\epsilon}) = \chi_1^N \underline{\gamma}^k(\underline{\epsilon}^{k-1})$ , on the possible  $\underline{\sigma}$ . Letting

(3) 
$$s^{k}(\underline{\epsilon}^{k-1}) = \mathcal{E}_{\underline{y}(\underline{\epsilon})}\sigma^{k} = \mathcal{E}_{\underline{y}^{k}(\epsilon^{k-1})}\sigma^{k},$$

such strategies will be denoted by  $\underline{s}(\underline{\epsilon}) = \chi_1^N s^k (\underline{\epsilon}^{k-1})$  and their risk by

$$(4) R^{N}(\underline{\epsilon}, \underline{s}) = \mathcal{E}_{\underline{y}(\underline{\epsilon})} \sum_{1}^{N} \epsilon^{k} \sigma^{k} = \sum_{1}^{N} \epsilon^{k} s^{k} (\underline{\epsilon}^{k-1}) .$$

The orderings induced by maximum risk and maximum regret in  $g^N$  will be considered briefly. Letting  $\underline{x}=\chi_1^Nx^j$  be a product p-measure on  $\underline{\epsilon}$ ,

(5) 
$$\mathcal{E}_{\underline{x}} \epsilon^{k} s^{k} (\underline{\epsilon}^{k-1}) = x^{k} \mathcal{E}_{\underline{x}} s^{k} (\underline{\epsilon}^{k-1}) \geq \emptyset(x^{k}) ,$$

and from this it follows that

(6) 
$$\max_{\underline{\epsilon}} R^{N}(\underline{\epsilon}, \underline{s}) \geq \max_{\underline{x}} \sum_{1}^{N} \emptyset(x^{k}) = N \max_{\underline{x}} \emptyset(x) = N R.$$

The lower bound in (6) will be attained and  $\underline{s}(\underline{\epsilon})$  will minimax risk in  $G^N$  if  $s^k(\underline{\epsilon}^{k-1})$  minimaxes risk in G for each  $\underline{\epsilon}$  and each  $k \leq N$ . That this condition is also necessary, if II has only a constant risk minimax s in G, follows from the recursive characterization:  $\underline{s}(\underline{\epsilon})$  minimaxes risk in  $G^N$ , if and only if, for each  $\epsilon$ ,

(7) 
$$\max_{\epsilon} \epsilon s^{k}(\underline{\epsilon}^{k-1}) \leq kR - \sum_{j=1}^{k-1} \epsilon^{j} s^{j}(\underline{\epsilon}^{j-1}), \qquad k = 1, 2, ..., N.$$

This prospect of a constant risk minimax  $\underline{s}(\underline{\epsilon})$  in  $G^N$  makes the maximum risk ordering quite unattractive. Alternatively, if II has non-constant risk minimax  $\underline{s}(\underline{\epsilon})$  in  $G^N$  and additional principles will be required to discriminate among these.

A similar treatment of regret in  $\boldsymbol{G}^{N}$  is possible. Expressing the sequence game regret by

$$\sum_{1}^{N} \epsilon^{k} s^{k} (\underline{\epsilon}^{k-1}) - \sum_{1}^{N} \emptyset(\epsilon^{k}) = \sum_{1}^{N} D(\epsilon^{k}, s^{k} (\underline{\epsilon}^{k-1})) ,$$

it follows from (2.17) that

$$\max_{\underline{\epsilon}} \sum_{1}^{N} D(\epsilon^{k}, s^{k}(\underline{\epsilon}^{k-1})) = \max_{\underline{x}} \sum_{1}^{N} \mathcal{E}_{\underline{x}} D(\epsilon^{k}, s^{k}(\underline{\epsilon}^{k-1}))$$

$$\geq \max_{\underline{x}} \sum_{1}^{N} \left[ \emptyset(x^{k}) - \mathcal{E}_{\underline{x}^{k}} \emptyset(\epsilon^{k}) \right] = N D .$$
(8)

The conditions under which this lower bound will be attained, the recursive characterization of minimax regret sequence strategies and the reasons for dissatisfaction with the maximum regret ordering exactly parallel their risk counterpart.

A classification of II's strategies will be based on their degree of dependence on I's prior moves. Those in which this dependence is unrestricted will be called recursive strategies. The subclass in which  $\mathbf{s}^k$  is a function only of the empirical distribution of I's prior moves,

(9) 
$$E^{k-1} = \sum_{j=1}^{k-1} \epsilon^{j} k = 1, 2, ...,$$

will be called symmetric and denoted by  $\underline{s}(\underline{E}) = \chi_1^N s^k(\underline{E}^{k-1})$ . For introductory investigations and comparisons, the class of strategies which are not properly recursive will be distinguished. Such strategies could be used by II in the absence of any information about I's past moves,

will be called product strategies and represented by  $\chi_1^N s^k$ . Product strategies in which all components are identical will be called power strategies and denoted by the common component (or by  $[s]^N$ ).

For power strategies, the risk (4) reduces to a linear function of  $\boldsymbol{\epsilon}^{N},$ 

$$R^{N}(\underline{\epsilon}, s) = \sum_{1}^{N} \epsilon^{k} s = E^{N} s \ge \emptyset(E^{N})$$

with equality if and only if s is Bayes against  $E^N$ . Thus even if II were restricted to power strategies, advance knowledge of  $E^N$  would enable II to attain an average risk across the N games which is equal to the Bayes risk in a single game where I uses the randomized strategy  $E^N/N$ . This suggests considering the regret associated with the ignorance of the partition function  $E^N$ , in the light of the possibility of using power strategies,

(11) 
$$D^{N}(\underline{\epsilon}, \underline{s}) = \sum_{1}^{N} \epsilon^{k} s^{k} (\underline{\epsilon}^{k-1}) - \emptyset(E^{N}) .$$

It should be noted of this modification of regret and, more generally, of any modification involving the partition function  $\textbf{E}^{\textbf{N}}$ , that

$$\emptyset^{T}(E^{N}) = \inf_{\underline{s} \in T} \max_{\underline{\epsilon}^{N} \mid E^{N}} \sum_{1}^{N} \epsilon^{k} s^{k} = \inf_{\underline{s} \in T} \max_{\underline{\epsilon}^{N} \mid E^{N}} \sum_{1}^{N} \left[ \epsilon^{k} s^{k} - \emptyset(\epsilon^{k}) \right] + \sum_{1}^{N} \emptyset(\epsilon^{k})$$

and hence that in dealing with any

$$\sum_{1}^{N} \epsilon^{k} s^{k} - \emptyset^{T}(\mathbb{E}^{N})$$

it may, without loss of generality, and will, without further comment, henceforth be assumed that

(12) 
$$\emptyset(\epsilon) = \min_{j} \epsilon A^{j} = 0 \text{ for each } \epsilon.$$

In the rest of the paper the modified regret (11) will be used almost exclusively. It has the advantages of simplicity and single game interpretability over the modification based on the envelope risk function of recursive strategies,

(13) 
$$g^{N}(E^{\tilde{N}}) = \min_{\underline{s}} \max_{\epsilon^{N} \mid E^{N}} \sum_{1}^{N} \epsilon^{k} s^{k} (\underline{\epsilon}^{k-1}) .$$

108 HAINAN

In order to relate the results of later sections to those obtainable in connection with the latter modification, it is of interest to prove

THEOREM 1. 
$$\emptyset^{N}(E^{N}) \ge \emptyset(E^{N}) - (m-1)^{1/2}N^{1/2}|B|$$
.

PROOF. Letting Q be a p-measure on the N! permutations of  $\underline{\epsilon}^{\,\,\rm N}$ , the min-max theorem and the use of conditional expectation yield

$$\emptyset^{N}(\mathbf{E}^{N}) = \min_{\underline{\mathbf{S}}} \max_{\mathbf{Q}} \quad \mathbf{\mathcal{E}}_{\mathbf{Q}} \sum_{1}^{N} \epsilon^{k} \mathbf{s}^{k} (\underline{\epsilon}^{k-1}) = \max_{\mathbf{Q}} \min_{\underline{\mathbf{S}}} \quad \sum_{1}^{N} \quad \mathbf{\mathcal{E}}_{\mathbf{Q}} \epsilon^{k} \mathbf{s}^{k} (\underline{\epsilon}^{k-1})$$

$$= \max_{\mathbf{Q}} \min_{\underline{\mathbf{S}}} \quad \sum_{1}^{N} \quad \mathbf{\mathcal{E}}_{\mathbf{Q}} \mathbf{\mathcal{E}}_{\mathbf{Q}} \left[ \epsilon^{k} \mid \underline{\epsilon}^{k-1} \right] \mathbf{s}^{k} (\underline{\epsilon}^{k-1})$$

$$= \max_{\mathbf{Q}} \sum_{1}^{N} \quad \mathbf{\mathcal{E}}_{\mathbf{Q}} \emptyset \left( \mathbf{\mathcal{E}}_{\mathbf{Q}} \left[ \epsilon^{k} \mid \underline{\epsilon}^{k-1} \right] \right) .$$

If P is uniform on the N! permutations,

$$\mathcal{E}_{P}\left[\varepsilon^{k}\mid\underline{\varepsilon}^{k-1}\right]=(E^{N}-E^{k-1})/(N-k+1)\quad,$$

 $\mathbf{E}^{N}$  -  $\mathbf{E}^{k-1}$  has the same distribution as  $\mathbf{E}^{N-k+1}$  and (14) yields the lower bound,

For  $r = 1, 2, \ldots, N-1$  it follows from (2.10) and

$$\sum_{1}^{m} E_{i}^{N}/N = \sum_{1}^{m} E_{i}^{r}/r$$

that

$$\emptyset\left(\frac{\mathbf{E}^{\mathbf{r}}}{\mathbf{r}}\right) \geq \emptyset\left(\frac{\mathbf{E}^{\mathbf{N}}}{\mathbf{N}}\right) - \left(\frac{\mathbf{E}^{\mathbf{N}}}{\mathbf{N}} - \frac{\mathbf{E}^{\mathbf{r}}}{\mathbf{r}}\right) \operatorname{s}(\mathbf{E}^{\mathbf{r}})$$

$$\geq \emptyset\left(\frac{\mathbf{E}^{\mathbf{N}}}{\mathbf{N}}\right) - \frac{1}{2} \left\|\frac{\mathbf{E}^{\mathbf{N}}}{\mathbf{N}} - \frac{\mathbf{E}^{\mathbf{r}}}{\mathbf{r}}\right\| \left|\mathbf{B}\right|.$$

It can easily be verified (and is noted in [5] pp. 182-3) that

$$\mathcal{E}_{P}\left(\frac{E_{\underline{1}}^{N}-\frac{E_{\underline{1}}^{r}}{r}\right)^{2}=\frac{1}{r}\frac{E_{\underline{1}}^{N}}{N}\left(1-\frac{E_{\underline{1}}^{N}}{N}\right)\left(1-\frac{r-1}{N-1}\right),$$

and from this and two applications of the Schwarz inequality

$$\mathcal{E}_{P} \left\| \frac{E^{N}}{N} - \frac{E^{r}}{r} \right\| \leq \sum_{1}^{m} \left[ \mathcal{E}_{P} \left( \frac{E_{1}^{N}}{N} - \frac{E_{1}^{r}}{r} \right)^{2} \right]^{1/2}$$

$$\leq r^{-1/2} \sum_{1}^{m} \left[ \frac{E_{1}^{N}}{N} \left( 1 - \frac{E_{1}^{N}}{N} \right) \right]^{1/2}$$

$$\leq r^{-1/2} \left[ \sum_{1}^{m} \frac{E_{1}^{N}}{N} \sum_{1}^{m} \left( 1 - \frac{E_{1}^{N}}{N} \right) \right]^{1/2}$$

$$= r^{-1/2} (m - 1)^{1/2} .$$

From (16) and (17)

$$\sum_{1}^{N} \mathcal{E}_{P}^{g}(E^{r}/r) \geq g(E^{N}) - \left(\sum_{1}^{N-1} r^{-1/2}/2\right) (m-1)^{1/2} |B|$$

and the proof of the theorem is complete.

# §4. MINIMAX MODIFIED REGRET ORDERINGS IN $G^{\mathrm{N}}$

The results of later sections afford indirect proofs of theorems on the efficacy of recursive strategies optimal in the weak (or in a certain natural strong) ordering based on the modified regret (3.11). Exact characterizations are obtainable in the form of recursive programs and, in a slight generalization of Matching Pennies, explicit solutions are exhibited.

Some obvious properties of modified regret may be noted. Consideration of the m power moves for I shows that the maximum is nonnegative for each recursive  $\underline{s}$ ,

$$(1) D^{N}(\underline{s}) = \max_{\underline{\epsilon}} \left[ \sum_{1}^{N} \epsilon^{k} s^{k} (\underline{\epsilon}^{k-1}) - \emptyset(E^{N}) \right] > 0 .$$

(It will later be seen that  $N^{-1/2}D^{N}(\underline{s})$  is bounded away from zero.) The same consideration shows that the relative minimum of  $D^{N}(\underline{s})$ , over the class of II's product strategies, is of the order of magnitude of N,

$$(2) \qquad D\left(\chi_{1}^{N}a_{K}\right) \geq \max_{\epsilon} \left[\epsilon \sum_{1}^{N} a_{K} - \emptyset(N\epsilon)\right] = ND\left(\sum_{1}^{N} a_{K}/N\right) \geq ND .$$

It is a most important conclusion of this paper that recursive  $\underline{s}$  do not necessarily suffer from the weakness (2). Letting  $\underline{D}^N$  denote the minimum of  $\underline{D}^N(s)$  over the class of II's recursive strategies,

(3) 
$$D^{N} = \min_{\underline{s}} D^{N}(\underline{s}) = \min_{\underline{s}} \max_{\underline{\epsilon}} \left[ \sum_{1}^{N} \epsilon^{k} s^{k} (\underline{\epsilon}^{k-1}) - \emptyset(\underline{E}^{N}) \right] ,$$

a byproduct of the proof of Theorem 4 consists in the exhibition of a weak symmetric strategy,  $\underline{s}(\underline{E})$ , such that  $\underline{D}^N(\underline{s}) \leq (n^2m/2)^{1/2}N^{1/2}|B|$ . A similar byproduct of Theorem 6 uniformly improves on this result and implies that

$$D^{N} \leq (2m)^{1/2} N^{1/2} |B| .$$

The problems of the exact determination of  $D^N$  and a minimizing  $\underline{s}$  have, in principle, a simple recursive solution. It follows from the definition of a recursive  $\underline{s}$  that  $D^N$  has the representation

$$D^{N} = \min \max_{\mathbf{S}^{1} \in \mathbb{I}} \left[ \epsilon^{1} \mathbf{s}^{1} + \min \max_{\mathbf{S}^{2} \in \mathbb{I}} \left[ \epsilon^{2} \mathbf{s}^{2} + \dots \right] \right],$$

$$+ \min \max_{\mathbf{S}^{N} \in \mathbb{N}} \left[ \epsilon^{N} \mathbf{s}^{N} - \emptyset(\mathbf{E}^{N}) \right]... \right],$$

and hence that  $\underline{s}$  minimizes  $D^N(\underline{s})$  if for each  $\underline{\epsilon}^{r-1}$  and each r=N, N-1, ..., 1,  $\underline{s}^r(\underline{\epsilon}^{r-1})$  minimizes

(6) 
$$\max_{\boldsymbol{\epsilon}^{\mathbf{r}}} \left[ \boldsymbol{\epsilon}^{\mathbf{r}} \mathbf{s}^{\mathbf{r}} + \min_{\boldsymbol{s}^{\mathbf{r}+1}} \max_{\boldsymbol{\epsilon}^{\mathbf{r}+1}} \left[ \boldsymbol{\epsilon}^{\mathbf{r}+1} \mathbf{s}^{\mathbf{r}+1} + \dots \right] + \min_{\boldsymbol{s}^{\mathbf{N}}} \max_{\boldsymbol{\epsilon}^{\mathbf{N}}} \left[ \boldsymbol{\epsilon}^{\mathbf{N}} \mathbf{s}^{\mathbf{N}} - \emptyset(\mathbf{E}^{\mathbf{N}}) \right] \dots \right] \right].$$

Denoting the minimum with respect to  $s^r$  of the expression (6) by  $V^N(\textbf{E}^{r-1})$ , the  $s^r(\underline{\epsilon}^{r-1})$  minimizing (6) may be taken to be the symmetric s, minimax in the auxiliary game

(7) 
$$\epsilon s + V^{N}(E^{r-1} + \epsilon) .$$

Moreover,

$$V^{N}(E^{r-1}) = \min_{s^{r} \in \Gamma} \max_{\epsilon} \left[ \epsilon^{r} s^{r} + V^{N}(E^{r}) \right]$$

and the min-max theorem yields

$$V^{N}(E^{r-1}) = \max_{x^{r}} \left[ \emptyset(x^{r}) + \mathcal{E}_{x^{r}} V^{N}(E^{r}) \right]$$

$$= F^{r}V^{N}(E^{r}) = F^{r}F^{r+1} \cdots F^{N}(-\emptyset(E^{N}))$$

with  $F^{\mathbf{r}}$  an abbreviation for the operator which it replaces, and hence the representation,

(9) 
$$D^{N} = V^{N}(0) = F^{1}F^{2} \dots F^{N}(-\emptyset(E^{N})) ,$$

from which follow the useful lower bounds,

$$(10) \quad \mathbb{D}^{\mathbb{N}} \geq \max_{\underline{x}} \left[ \sum_{1}^{\mathbb{N}} \emptyset(x^{\mathbb{K}}) - \mathcal{E}_{\underline{x}} \emptyset(\mathbb{E}^{\mathbb{N}}) \right] \geq \max_{x} \left[ \mathbb{N}\emptyset(x) - \mathcal{E}_{[x]} \mathbb{N} \emptyset(\mathbb{E}^{\mathbb{N}}) \right].$$

These bounds could have been obtained more directly from

$$\max_{\underline{\epsilon}} D^{N}(\underline{\epsilon}, \underline{s}) = \max_{\underline{x}} \mathcal{E}_{\underline{x}} D^{N}(\underline{\epsilon}, \underline{s})$$

$$= \max_{\underline{x}} \left[ \sum_{1}^{N} x^{k} \mathcal{E}_{\underline{x}} s^{k}(\underline{\epsilon}^{k-1}) - \mathcal{E}_{\underline{x}} \delta(\underline{\epsilon}^{N}) \right].$$

The weaker of the bounds (10) can be used to obtain a more explicit lower bound for  $\mathbb{D}^{\mathbb{N}}$  which establishes the optimality, in the order of magnitude of their modified regrets, of the strategies of Theorems 4 and 6.

Considering the covering of  $X^+$  by the closed sets  $X_j = [x \mid xA^j = \emptyset(x)]$ , (2.4) insures that no single  $X_j$  covers and consequently there exists some  $x_0$  in  $X^+$  such that  $s(x_0)$  has determinations  $\sigma$  and  $\sigma^+$  with

(12) 
$$h^2 = N^{-1} \mathcal{E}_{[x_0]^N} |E^N(\sigma - \sigma')|^2 = \sum_{1}^{m} (\sigma_1 - \sigma_1')^2 x_{01} > 0$$
.

THEOREM 2. If A satisfies (2.4) there exists  $\mathbf{x}_{0}$  satisfying (12) and for any such  $\mathbf{x}_{0}$ 

$$D^{N} \ge N\emptyset(x_{0}) - \mathcal{E}_{[x_{0}]^{N}}\emptyset(E^{N}) \ge (2\pi)^{-1/2}hN^{1/2}$$
.

PROOF. For any such  $x_0$ ,  $N\emptyset(x_0) - \emptyset(E^N) \ge \max[(Nx_0 - E^N)\sigma, (Nx_0 - E^N)\sigma]$  and, representing this maximum by the average of the sum and absolute difference,

$$\mathcal{E}_{[x_0]^N} \left[ N \emptyset(x_0) - \emptyset(E^N) \right] \ge \mathcal{E}_{[x_0]^N} |E^N(\sigma - \sigma')|/2 .$$

Because of the assumption that h is positive, the random variable  $E^{N}(\sigma-\sigma')$  is asymptotically normal with mean 0, variance  $Nh^2$ , and the absolute moment of the standardized variable approaches that of the standard normal which is  $(2/\pi)^{1/2}$ . Thus

(14) 
$$\mathcal{E}_{[x_0]^N} |E^N(\sigma - \sigma')|/2 \sim (2\pi)^{-1/2} hN^{1/2}$$

and the bound of the theorem follows from (10), (13) and (14).

Theorems 4 and 6 exhibit a strong recursive  $\underline{s}^*$  for which

(15) 
$$D^{N}(\underline{\epsilon}, \underline{s}^{*}) \leq N^{1/2}(6m)^{1/2} |B| .$$

Theorem 2 and this result suggest ordering strong strategies by

$$\text{(16)} \quad \text{U}(\underline{\mathbf{s}}) = \sup_{\mathbf{N}} \, \text{N}^{-1/2} \text{D}^{\mathbf{N}}(\underline{\mathbf{s}}) = \sup_{\mathbf{N}} \, \max_{\underline{\boldsymbol{\epsilon}}} \, \text{N}^{-1/2} \, \left[ \, \sum_{1}^{\mathbf{N}} \, \boldsymbol{\boldsymbol{\epsilon}}^{\mathbf{k}} \mathbf{s}^{\mathbf{k}} (\underline{\boldsymbol{\epsilon}}^{\mathbf{k}-1}) \, - \, \boldsymbol{\vartheta}(\mathbf{E}^{\mathbf{N}}) \, \right] \quad ,$$

since they insure that

(17) 
$$h(2\pi)^{-1/2} \le \inf_{\underline{s}} U(\underline{s}) \le (6m)^{1/2} |B| .$$

No program for strong strategies optimal in the ordering (16) has been found and, after concluding the present section with an example in which weak optimal strategies can be obtained explicitly, much of the rest of the paper is devoted to a comparatively simple class of usable strong strategies.

EXAMPLE 1. MATCHING m-SIDED PENNIES<sup>2</sup>

$$A = \begin{bmatrix} 1/p_1 & 0 & 0 & \cdot & \cdot & \cdot & 0 \\ 0 & 1/p_2 & 0 & \cdot & \cdot & \cdot & 0 \\ 0 & 0 & 1/p_3 & \cdot & \cdot & \cdot & 0 \\ \cdot & \cdot & \cdot & \cdot & \cdot & \cdot & \cdot \\ 0 & 0 & 0 & \cdot & \cdot & \cdot & 1/p_m \end{bmatrix}$$

$$0 < p_i i = 1, 2, ..., m, \sum_{1}^{m} p_i = 1 .$$

Here

$$\emptyset(w) = \min_{i} w_i/p_i$$
 ,

p in Y is the unique min-max strategy for II and has the constant risk 1, p in X is the unique max-min x and  $pA^j = 1$  for all j.

The auxiliary games (4.7) can be solved explicitly by a backward induction. At stage N the i-th row of the inutility (4.7) is expressible as  $y_1^N/p_1 - \emptyset(E^{N-1} + \varepsilon(i))$  and defining  $u_i^N \geq 0$  by

$$u_{i}^{N}/p_{i} - \emptyset(E^{N-1} + \varepsilon(i)) = \max_{i} - \emptyset(E^{N-1} + \varepsilon(i))$$
 ,

it follows easily from the concavity of  $\emptyset$  in general and the particulars of the example that

$$\sum_{1}^{m} u_{1}^{N} = \mathcal{E}_{p} \emptyset(E^{N-1} + \epsilon^{N}) - \min_{\epsilon} \emptyset(E^{N-1} + \epsilon)$$

$$\leq \emptyset(E^{N-1} + p) - \emptyset(E^{N-1}) = 1 .$$

Consequently

$$\max_{\mathbf{1}} \left[ \mathbf{y}_{\mathbf{1}}^{N}/\mathbf{p}_{\mathbf{1}} - \mathbf{\emptyset}(\mathbf{E}^{N-1} + \boldsymbol{\epsilon}(\mathbf{1})) \right] \geq \max_{\mathbf{1}} - \mathbf{\emptyset}(\mathbf{E}^{N-1} + \boldsymbol{\epsilon}(\mathbf{1}))$$

and is minimized uniquely by

$$y_{i}^{N} = u_{i}^{N} + \left(1 - \sum_{1}^{m} u_{i}^{N}\right) p_{i}$$

$$= p_{i} \left[1 + \emptyset(E^{N-1} + \epsilon(i)) - \mathcal{E}_{p} \emptyset(E^{N-1} + \epsilon^{N})\right] ,$$

with the minimum being the constant risk of  $y^N$  in the auxiliary game,  $1 - \mathcal{E}_p \emptyset(E^{N-1} + \varepsilon^N)$ . A similar argument applies at each, including the induction, stage and yields at stage r that the i-th row of (4.7) is expressible

(3) 
$$y_{1}^{r}/p_{1} + \left[N - r - \mathcal{E}_{[p]}N - r^{\beta}\left(\mathbb{E}^{r-1} + \epsilon(1) + \sum_{r+1}^{N} \epsilon^{k}\right)\right],$$

that its maximum with respect to i is minimized uniquely by

$$y_{1}^{r} = p_{1} \left[ 1 + \mathcal{E}_{[p]^{N-r}}$$

and hence that the minimum is the constant risk of  $y^{r}$  in the auxiliary game,

(5) 
$$N - r + 1 - \varepsilon_{[p]^{N-r+1}} \emptyset \left( E^{r-1} + \sum_{r}^{N} \epsilon^{k} \right)$$
.

It may be noted that the  $y^r(\textbf{E}^{r-1})$  depend also on N, hence define a sequence strategy only in weak  $G^N$ , and a more complete notation would make this explicit.

In view of the apparent complexity of the strategy (4) it is of some interest to note that it could be constructively attained by the following compound randomization: choose & with distribution that induced on the values of

$$\sum_{r+1}^{N} \epsilon^{k}$$

by the product p-measure  $[p]^{N-r}$ , for each fixed  $\xi$  use the strategy  $y^r_{|\xi}$  with

(6) 
$$y_{i|\xi}^{r} = p_{i}\left[1 + \emptyset(E^{r-1} + \epsilon(i) + \xi) - \mathcal{E}_{p}\emptyset(E^{r-1} + \epsilon + \xi)\right]$$
.

Since  $\emptyset(E^{r-1}+\varepsilon(i)+\xi)=\emptyset(E^{r-1}+\xi)$  unless  $y(E^{r-1}+\xi)$  determines a unique column j and i=j, it follows from (6) that  $y^r|_{\xi}=p$  when  $y(E^{r-1}+\xi)$  is not unique, assigns probability 1 to the column j associated with  $y(E^{r-1}+\xi)$  when that column is sufficiently pre-eminent, and is in general an interpolate between p and the j-th column defined by

(7) 
$$y_{i|\xi}^{r} = p_{i} \begin{cases} [1 - p_{j}\Delta] & i \neq j \\ \\ [1 + (1 - p_{j})\Delta] & i = j \end{cases}$$

with

$$\frac{1}{p_{\mathbf{j}}} \ \geq \Delta = \emptyset \left( \mathbb{E}^{r-1} \ + \ \varepsilon(\mathbf{j}) \ + \ \xi \right) \ - \ \emptyset \left( \mathbb{E}^{r-1} \ + \ \xi \right) \geq 0 \quad .$$

Taking r equal to 1 in (5) it follows that

(8) 
$$D^{N} = N - \mathcal{E}_{[p]^{N}} \emptyset \left( \sum_{i=1}^{N} \epsilon^{k} \right) ,$$

and hence that, in this example, equality holds in (4.10). Since  $\text{[p]}^{\text{N}}$  assigns positive measure to each  $\underline{\varepsilon}$  and

$$\mathcal{E}_{[p]^{N}} D^{N}(\underline{\epsilon}, \underline{s}) = D^{N}$$

for any s, the sequence strategy  $\underline{y}(\underline{E}|N)$  defined by (4) has the modified regret  $D^N$  for all  $\underline{\epsilon}^N$ , a fact which could also have been inferred from the behavior of the  $\underline{y}^r(\underline{E}^{r-1})$  in the auxiliary games. The general bounds on  $D^N$ , (4.4) and the class of lower bounds of Theorem 2, have appropriate specializations which assert (assuming  $1/p_1 \ge \cdots \ge 1/p_m$ ) that

(9) 
$$\left[ \left( \frac{1}{p_1} + \frac{1}{p_2} \right) / 2\pi \right]^{1/2} \leq N^{-1/2} \left[ N - \mathcal{E}_{[p]} N \tilde{z}(E^N) \right] \leq [2m]^{1/2} (1/p_1) .$$

These bounds could be much improved but serve to illustrate the order of magnitude of the asymptotic evaluation.

The program for finding the  $V^N(E^{r-1})$  envisaged in (4.8) could be carried out directly as follows. Consider the maximization in  $F^N$  in the stages, over  $x^N$  such that  $\emptyset(x^N)=c$ , then over  $0\leq c\leq 1$ . For the former, each  $x_i^N\geq cp_i$  and

$$\begin{split} \emptyset \, (x^N) \; - \; & \boldsymbol{\mathcal{E}}_{x^N} \; \emptyset \, (\mathbb{E}^{N-1} + \, \boldsymbol{\varepsilon}^N) \; \leq \; \boldsymbol{c} \\ \\ & - \; \left[ \; \operatorname{cp}_{\boldsymbol{j}} \emptyset \, (\mathbb{E}^{N-1} \; + \; \boldsymbol{\varepsilon}(\, \boldsymbol{j} \,)) \; + \; (1 \; - \; \operatorname{cp}_{\boldsymbol{j}}) \emptyset \, (\mathbb{E}^{N-1} \,) \; \right] \end{split}$$

where j is the index of a column attaining  $\emptyset(E^{N-1})$ . Equality holds in (10) if  $x_j^N = cp_j$  and since the coefficient of c on the right is nonnegative, the latter maximization is accomplished at c = 1, yielding

(11) 
$$F^{N}(-\emptyset(E^{N})) = 1 + \mathcal{E}_{p}(-\emptyset(E^{N-1} + \epsilon^{N})) .$$

Because the maximizations in the operators are attained for x not depending on the values of other  $\epsilon^j$ , an easy iteration is possible and yields the result (5).

## §5. THE H, μ CLASS OF RECURSIVE RESPONSES

If s is a Bayes response (2.9), the recursive strategy for  $G^N$  with  $s^k(\underline{\epsilon}^{k-1}) = s(E^{k-1})$  for  $k=1,2,\ldots$  has some interesting aspects. It is the strategy usually attributed to II in the "method of fictitious play" ([3], [15]) evaluation of a zero-sum G. It was noted in [15] that alternative use of  $s(E^k)$  (which exceeds the concept of a recursive strategy) improves the convergence rate of the evaluation and it will be seen in Section 6 that

$$\sum_{1}^{N} \epsilon^{k} s(E^{k}) \leq \emptyset(E^{N}) .$$

If s were uniformly continuous on X it would be possible to conclude from this that

$$\sum_{1}^{N} \epsilon^{k} s(E^{k-1}) \leq \emptyset(E^{N}) + o(N)$$

uniformly in  $\underline{\epsilon}$ . Unfortunately s is necessarily discontinuous and the conclusion is easily shown to be false for any A satisfying (2.4). (It will be seen in Section 8 that in certain non-finite games neither of these objections will continue to apply.) The present section defines and examines a class of sequences of responses,  $s^{*k}$ , which induce responses uniformly continuous on X for each k, weakly monotone in k for each x, and, under appropriate conditions on  $\underline{H}$  (in addition to (1)), converging weakly in k to s for each x, with first k-differences converging to zero in norm, uniformly in x.

Let  $H^k$  k = 0, 1, ... be a non-decreasing sequence of positive numbers such that  $h^k$  =  $H^k/k$  k = 1, 2, ... is a non-increasing sequence,

(1) 
$$0 < H^0 \le H^1 \le \dots \qquad h^1 \ge h^2 \ge \dots$$

Introduce the abbreviation  $A^{qr}=A^q-A^r$  and let  $\mu$  be any p-measure on the unit m-cube,  $Z=[z=(z_1,\ \ldots,\ z_m)\mid 0\leq z_1\leq 1]$ , such that, for each q< r and each  $t_1\leq t_2$ , the distribution function of  $zA^{qr}$  satisfies the Lipschitz condition,

(2) 
$$\mu[z \mid t_1 \leq zA^{qr}/|A^{qr}| \leq t_2] \leq L(t_2 - t_1) .$$

Letting  $\sigma$  be a Bayes response (2.9), which is pure-strategy valued and such that  $\sigma(cw) = \sigma(w)$  for each c > 0, define for each k = 1, 2, ...

(3) 
$$s^{*k}(w) = \mathcal{E}_{\mu} \sigma(w + H^{k-1} z)$$
 on  $\left[ w \mid \sum_{1}^{m} w_{1} = k - 1 \right]$ 

It may be noted that  $s^{*k}$  is independent of the ambiguity in the choice of  $\sigma$  since  $\sigma$  is ambiguous at  $w + H^{k-1}z$  only if  $(w + H^{k-1}z)A^{qr} = 0$  for some  $q \neq r$ , and for each fixed w,  $H^{k-1}$ , q, r, the set of z satisfying this equation has  $\mu$ -measure zero by (2). Since the range of  $\sigma$  is the columns of A,  $s^{*k}$  may be represented somewhat more explicitly,

$$s^{*k}(w) = \sum_{1}^{n} A^{j}_{\mu} \left[ z \mid \sigma(w + H^{k-1}z) = A^{j} \right]$$

$$= \sum_{1}^{n} A^{j}_{\mu} \left( \frac{\sigma^{-1}A^{j} - w}{H^{k-1}} \right) \quad \text{on} \quad \sum_{1}^{m} w_{1} = k - 1 .$$

For the comparison of different terms of the sequence (3) it is convenient to consider the sequence of responses induced on the common domain X,

(5) 
$$s^{*k}[x] = s^{*k}((k-1)x) = \mathcal{E}_{\mu}\sigma((k-1)x + H^{k-1}z)$$
$$= \begin{cases} \mathcal{E}_{\mu}\sigma(H^{0}z) & \text{if } k = 1 \\ \mathcal{E}_{\mu}\sigma(x + h^{k-1}z) & \text{if } k > 1 \end{cases}.$$

Letting  $\Delta = \sigma((k-1)x + H^{k-1}z) - \sigma(kx + H^kz)$  it follows from

$$H^{k-1}[kx + H^kz]\Delta \ge 0 \ge H^k[(k-1)x + H^{k-1}z]\Delta$$

that  $[kH^{k-1} - (k-1)H^k]x\Delta \ge 0$  for each z and hence it is easily verified that

(6) 
$$xs^{*k}[x] \ge xs^{*k+1}[x]$$

It further follows from (2.11) that  $x\sigma(x+h^{k-1}z)-xs(x)\leq mh^{k-1}|B|$  and from (2.15) that this difference is zero if

$$\sum_{1}^{m} (h^{k-1}z_{1})^{2} < d^{2}(x) .$$

From the latter,

(7) 
$$xs^{*k}[x] = \emptyset(x) \text{ if } h^{k-1} < m^{-1/2}d(x)$$

A constructive proof of the continuity of  $s*^k[x]$  is obtainable from the definition of the  $\sigma$ -function and the assumption (2) on  $\mu$ . Because of the homogeneity of the  $\sigma$ -function it will be convenient to obtain this as one of the byproducts of a lemma which will furnish a main tool in the proof of Theorem 3 in Section 6.

LEMMA 1. If w and w' are m-vectors,  $\sigma$  is a pure strategy valued, positive-homogeneous Bayes response and  $\mu$  satisfies (2), then

$$|\mathcal{E}_{\mu}\sigma(w+z) - \mathcal{E}_{\mu}\sigma(w'+z)| \le L \frac{n^2}{4} |B| \|w'-w\|$$
.

PROOF. Letting  $T_{jk} = [z \mid \sigma(w+z) = A^j, \sigma(w'+z) = A^k],$   $\mathcal{E}_{\mu}\sigma_{i}(w+z) - \mathcal{E}_{\mu}\sigma_{i}(w'+z)$  is expressible as

$$\sum_{j \neq k} A_{i}^{jk} \mu(T_{jk})$$

and

(8) 
$$|\mathcal{E}_{\mu}\sigma_{\mathbf{i}}(w + z) - \mathcal{E}_{\mu}\sigma_{\mathbf{i}}(w' + z)| \leq \sum_{j \leq k} |A_{\mathbf{i}}^{jk}|[\mu(T_{jk}) + \mu(T_{kj})]$$
.

However, for z in  $T_{jk}$  it follows that  $(w+z)A^{jk} \leq 0 \leq (w'+z)A^{jk}$  and hence that

$$(9) wA^{jk} \leq zA^{kj} \leq w'A^{jk} .$$

From (2) and (9) at most one of  $\mu(T_{jk})$  and  $\mu(T_{kj})$  is positive and

(10) 
$$\mu(T_{jk}) + \mu(T_{kj}) \le L |(w' - w)A^{jk}|/|A^{jk}| \le L ||w' - w||$$
.

The bound of the lemma follows from (8), (10) and an elementary computation verifying that

$$\sum_{j < k} |A_j^{jk}| \le |B| n^2/4 .$$

Assuming without loss of generality that  $|B| \ge a_{i1} \ge a_{i2} \ge \cdots \ge a_{in} = 0$ ,

$$\sum_{j < k} |A_{j}^{jk}| = \sum_{j < k} (a_{ij} - a_{ik}) = \sum_{j < k} a_{ij} - \sum_{j < k} a_{ik}$$

$$= \sum_{j=1}^{n} (n - j)a_{ij} - \sum_{k=1}^{n} (k - 1)a_{ik}$$

$$= \sum_{r=1}^{n} (n + 1 - 2r)a_{ir} \le |B| \sum_{r < (n+1)/2} (n + 1 - 2r)$$

$$\le |B| n^{2/4} ,$$

thus completing the proof of the lemma.

It should be noted that the covering of  $T_{jk}$  by a non-null  $zA^{kj}$ -interval (9) is apt to be loose for n>2. This weakness of Lemma 1 will be effectively remedied in Part II where Lemma 2 will, for a different condition on  $\mu$ , yield a bound which does not depend on the number of II's strategies.

The use of Lemma 1 with  $w=x/h^{k-1}$ ,  $w'=x'/h^{k-1}$  shows that the risk vector  $s*^k[x]$  satisfies a Lipschitz condition in each component,

(11) 
$$|s^{*k}[x] - s^{*k}[x']| \le L \frac{n^2}{4} |B| \frac{|x'-x|}{h^{k-1}} \qquad k > 1$$
.

The choice,  $w = x/h^{k-1}$ ,  $w' = x/h^k$ , yields the uniform bound on the first k-difference

(12) 
$$|s^{*k}[x] - s^{*k+1}[x]| \le L \frac{n^2}{4} |B| \left[ \frac{1}{h^k} - \frac{1}{h^{k-1}} \right] \qquad k > 1$$
.

# §6. MODIFIED REGRET OF RECURSIVE STRATEGIES $\underline{s}*(\underline{E})$

This section considers strong recursive strategies  $\underline{s}^*$  obtained from sequences of responses (5.3) by evaluation at  $\underline{E}^{k-1}$ ,

(1) 
$$s^{*k}(\mathbb{E}^{k-1}) = \mathcal{E}_{\mu}\sigma(\mathbb{E}^{k-1} + \mathbb{H}^{k-1}z) \qquad k = 1, 2, \dots$$

Theorem 3 will exhibit explicit uniform bounds for  $D^N(\underline{\epsilon}, \underline{s^*})$ , the difference between the risk incurred by  $\underline{s^*}$  in the sequence game  $G^N$ ,

(2) 
$$R^{N}(\underline{\epsilon}, \underline{s}^{*}) = \sum_{1}^{N} \epsilon^{k} s^{*k} (E^{k-1}) ,$$

and the risk  $\emptyset(E^N)$  which could have been attained had II known N and I's N-cumulation  $E^N$  at each stage and had minimized his risk over the class of power strategies by the use of  $[s(E^N)]^N$ ,

(3) 
$$g(E^{N}) = \sum_{1}^{N} \epsilon^{k} s(E^{N}) = \min_{S} E^{N} s .$$

An important tool in the proof of Theorem 3 and in the motivation of the strategy (1) is an algebraic identity for the form

$$\sum_{1}^{N} \epsilon^{k} s^{k}$$

which is obtainable from a summation by parts and is easily verified directly,

$$\sum_{1}^{N} \epsilon^{k} s^{k} = E^{N} s^{N} + \sum_{1}^{N-1} E^{k-1} (s^{k} - s^{k+1}) + \sum_{1}^{N-1} \epsilon^{k} (s^{k} - s^{k+1})$$

$$= T_{1}(\underline{s}) + T_{2}(\underline{s}) + T_{3}(\underline{s})$$

with the  $T_1$  functions defined by positional correspondence. For the extra-recursive strategy with  $s^k=s(E^k),\,T_1(\underline{s})$  attains its minimum  $\emptyset(E^N)$  and each of the terms of  $T_2(\underline{s})+T_3(\underline{s})$  is non-positive. Thus the non-available sequence strategy  $\chi_1^N s(E^k)$  would lead to a non-positive regret and this fact creates considerable interest in recursive strategies which "estimate"  $\chi_1^N s(E^k)$ .

The choice (1) of  $\underline{s}^*$  is in part motivated by the following heuristic consideration of the  $T_i$ .  $T_2(\underline{s}) \leq 0$  when  $s^k = s(E^{k-1})$  and might be expected to remain moderate when  $s^k = s^k(E^{k-1})$  with the  $s^k$  function near s; such a choice would also insure that  $T_1$  is near its minimum.  $T_3$  would be moderate if the difference vector  $s^k(E^{k-1}) - s^{k+1}(E^k)$  is small which would follow if  $s^k[x]$  is sufficiently continuous in x for each k and has small k-differences for each x. It was seen in Section 5 that the  $\underline{s}^*$  have qualifications of this type and Theorem 3 displays precise bounds on its performance.

THEOREM 3. If  $\underline{s}^*$  is any recursive strategy (1),  $\underline{H}$  satisfies (5.1),  $\mu$  satisfies (5.2), and  $\theta$  =  $\mathcal{E}_{\mu}$   $\|z\|$ , then for each N and  $\underline{\varepsilon}$ 

$$- H^{N_{\theta}}|B| \leq D^{N}(\underline{\epsilon}, \underline{s}^{*}) \leq H^{N_{\theta}}|B| + L \frac{n^{2}}{4} \left( \sum_{1}^{N} \frac{2}{H^{K}} - \frac{N}{H^{N}} \right) |B| .$$

PROOF. It will be convenient to use a form of (4) involving  $\mathbf{s}^{N+1}$  ,

(5) 
$$\sum_{1}^{N} \epsilon^{k} s^{k} = E^{N} s^{N+1} + \sum_{1}^{N} E^{k-1} (s^{k} - s^{k+1}) + \sum_{1}^{N} \epsilon^{k} (s^{k} - s^{k+1}) .$$

Introducing the abbreviation  $\sigma(E^{k-1} + H^{k-1}z) = \sigma^k$ , (5) permits the representation

$$D^{N}(\underline{\epsilon}, \underline{s}^{*}) = E^{N} \mathcal{E}_{\mu} \sigma^{N+1} - \emptyset (E^{N}) + \sum_{1}^{N} E^{k-1} (\mathcal{E}_{\mu} \sigma^{k} - \mathcal{E}_{\mu} \sigma^{k+1}) + \sum_{1}^{N} \epsilon^{k} (\mathcal{E}_{\mu} \sigma^{k} - \mathcal{E}_{\mu} \sigma^{k+1}),$$

$$(6)$$

$$\mathcal{E}_{\mu} \left[ E^{N} \sigma^{N+1} - \emptyset (E^{N}) + \sum_{1}^{N} E^{k-1} (\sigma^{k} - \sigma^{k+1}) + \sum_{1}^{N} \epsilon^{k} (\sigma^{k} - \sigma^{k+1}) \right].$$

As a contribution to both bounds of the theorem it follows from (2.11) that

$$(7) \qquad \qquad 0 < \mathbb{E}^{N} \sigma^{N+1} - \emptyset (\mathbb{E}^{N}) \leq - H^{N} z [\sigma^{N+1} - \sigma(\mathbb{E}^{N})] .$$

From the definition of  $\sigma^k$ ,  $E^k(\sigma^k - \sigma^{k+1}) \ge -H^k z(\sigma^k - \sigma^{k+1})$ , whence by summation by parts on the right and the use of the bounds,  $H^N z \sigma^{N+1} \ge 0$ ,  $z \sigma^k \le \|z\| \|B\|$ ,

(8) 
$$\sum_{1}^{N} E^{k}(\sigma^{k} - \sigma^{k+1}) \ge H^{N}z\sigma^{N+1} - H^{O}z\sigma^{1} - \sum_{1}^{N} (H^{k} - H^{k-1})z\sigma^{k} \ge - H^{N} \|z\| \|B\|.$$

From (6), (7) and (8),  $D^N(\underline{\epsilon}, \chi_1^N \sigma^k) \ge -H^N \|z\| \|B\|$  for each z and the lower bound of the theorem follows upon taking expectation with respect to  $\mu$ .

From  $E^{k-1}(\sigma^k-\sigma^{k+1})\leq -H^{k-1}z(\sigma^k-\sigma^{k+1})$  k = 2, ..., N, it follows by summation by parts on the right that

(9) 
$$\sum_{1}^{N} E^{k-1} (\sigma^{k} - \sigma^{k+1}) \leq H^{N} z \sigma^{N+1} - H^{1} z \sigma^{2} - \sum_{2}^{N} (H^{k} - H^{k-1}) z \sigma^{k+1} ,$$

and from (9) and the upper bound (7) that

$$E^{N}\sigma^{N+1} - \emptyset(E^{N}) + \sum_{1}^{N} E^{k-1}(\sigma^{k} - \sigma^{k+1})$$

$$\leq H^{N}z\sigma(E^{N}) - H^{1}z\sigma^{2} - \sum_{2}^{N} (H^{k} - H^{k-1})z\sigma^{k+1}$$

$$\leq H^{N} \|z\| \|B\| ,$$

whence the first part of the upper bound of the theorem follows by expectation with respect to  $\ \mu$ .

The term

$$\mathcal{E}_{\mu} \sum_{1}^{N} \epsilon^{k} (\sigma^{k} - \sigma^{k+1})$$

is alone in that there is no interesting upper bound for the integrand which is uniform in  $\underline{\epsilon}$  for each z. The expectation of the summands,  $\underline{\epsilon}^k[s^{*k}(E^{k-1})-s^{*k+1}(E^k)]$ , could however be partitioned into a continuity term and a difference term which could then be bounded by the use of (5.11) and (5.12). Any such bound can be slightly improved by a direct application of Lemma 1 with  $w=E^{k-1}/H^{k-1}$ ,  $w'=E^k/H^k$ . With this identification,  $w_i-w_i'$  is by (5.1) non-negative if  $\underline{\epsilon}_i^k=0$  and non-positive if  $\underline{\epsilon}_i^k=1$ ,

and the conclusion of the lemma is that

(12) 
$$\epsilon^{k} \left[ s^{k}(E^{k-1}) - s^{k+1}(E^{k}) \right] \leq L \frac{n^{2}}{4} |B| \left[ \frac{k-1}{H^{k-1}} - \frac{k-2}{H^{k}} \right]$$

The second part of the upper bound of the theorem follows from (12) by summation with respect to k and the proof of the theorem is now complete.

§7. CHOICE OF 
$$\underline{H}$$
,  $\mu$  IN  $\underline{s}*(\underline{E})$ 

For any  $\underline{H},~\mu$  satisfying (5.1) and (5.2) abbreviate the upper bound of Theorem 3 by

$$U^{N}(\underline{H}, \mu) = \left[H^{N_{\theta}} + L \frac{n^{2}}{4} \left(\sum_{1}^{N} \frac{2}{H^{K}} - \frac{N}{H^{N}}\right)\right] |B|.$$

For fixed  $\mu$  it will be shown that  $U^{\mathrm{N}}$  and

$$\sup_{N} N^{-1/2} U^{N}$$

admit simple minimizing  $\underline{H}$  in the respective classes of weak and strong  $\underline{H}$ . The resulting minimums are increasing functions of L0 and the minimum of the sup of this product over all A satisfying (2.4) is attained when  $\mu$  is uniform on Z. This choice of  $\mu$  and the associated strong  $\underline{H}$  for which

$$\sup_{N} N^{-1/2} U^{N}$$

is minimal yield Theorem 4 as a corollary to Theorem 3.

By minimizing successively with respect to  $\mbox{H}^1,\mbox{ }\mbox{H}^2,\mbox{ }\ldots,\mbox{ }\mbox{H}^{N-1},$  within the constraints (5.1) it follows that

(2) 
$$\sum_{1}^{N} 2/H^{k} \ge 2N/H^{N} \text{ with equality iff } H^{1} = H^{2} = \dots = H^{N},$$

and hence that  $U^N$  is bounded below by a linear form in  $H^N$  and  $1/H^N$ ,

(3) 
$$U^{N}(\underline{H}, \mu) \geq \left[ H^{N_{\theta}} + L \frac{n^{2}}{4} N/H^{N} \right] |B| \geq N^{1/2} [Ln^{2_{\theta}}]^{1/2} |B| ,$$

with equality iff  $\underline{\textbf{H}}$  is the weak  $\underline{\textbf{H}}_{N}$  with

(4) 
$$H_N^1 = H_N^2 = \dots = H_N^N = [Ln^2/4\theta]^{1/2} N^{1/2}$$

To obtain a strong  $\underline{H}$  minimizing

$$\sup_{N} N^{-1/2} U^{N}$$

consider first the class of strong  $\underline{H}$  with  $0<\overline{\lim}\ N^{-1/2}H^{N}=\alpha<\infty$  (since  $\sup\ N^{-1/2}U^{N}=\infty$  if  $\alpha=0$  or  $\infty$ ). For such  $\underline{H}$ 

$$\frac{\lim_{N \to \infty} N^{-1/2}}{N} \sum_{1}^{N} \frac{2}{H^{k}} \ge \frac{2}{\alpha} \lim_{N \to \infty} N^{-1/2} \sum_{1}^{N} k^{-1/2} = \frac{4}{\alpha},$$

$$\frac{\overline{\lim}}{N} \left[ N^{-1/2} H^{N} \theta - L \frac{n^{2}}{4} \frac{N^{1/2}}{H^{N}} \right] = \theta \alpha - L \frac{n^{2}}{4} \frac{1}{n^{2}},$$

and hence

$$\sup_{N} N^{-1/2} U^{N} \ge \overline{\lim}_{N} N^{-1/2} U^{N} \ge \left[ \theta \alpha + 3 L n^{2} / 4 \alpha \right] |B| .$$

However, for  $H^k = \alpha k^{1/2} k = 1, 2, ...,$  it follows from

(6) 
$$\sum_{1}^{N} \frac{2}{H^{K}} = \frac{2}{\alpha} \sum_{1}^{N} k^{-1/2} < \frac{2}{\alpha} \int_{0}^{N} t^{-1/2} dt = \frac{4}{\alpha} N^{1/2}$$

that  $N^{-1/2}U^N < [\theta\alpha + 3Ln^2/4\alpha] |B|$  for each N, and hence that this choice of <u>H</u> minimizes

$$\sup_{N} N^{-1/2} U^{N}$$

in the class with

$$\lim_{N} N^{-1/2} H^{N} = \alpha .$$

Since  $\theta \alpha + 3 \text{Ln}^2/4\alpha \ge [3 \text{Ln}^2 \theta]^{1/2}$  with equality iff  $\alpha = [3 \text{Ln}^2/4\theta]^{1/2}$ ,

(7) 
$$\sup_{N} N^{-1/2} U^{N}(\underline{H}, \mu) \geq [3Ln^{2}e]^{1/2} |B|$$

and this lower bound is attained from below for the strong H with

(8) 
$$H^{k} = [3Ln^{2}/4e]^{1/2} \qquad k = 1, 2, ...$$

The upper bounds (3) and (7) are increasing functions of Le and will hold renewed interest after a specification of  $\mu$ . Before doing this it may be noted that the attaining  $\underline{H}_N$  in (3) and  $\underline{H}$  in (7) satisfy

$$\textbf{U}^{\textbf{N}}(\underline{\textbf{H}},\ \boldsymbol{\mu}) \sim \sqrt{3}\ \textbf{U}^{\textbf{N}}(\underline{\textbf{H}}_{\textbf{N}},\ \boldsymbol{\mu}), \qquad \textbf{H}^{\textbf{k}} = \sqrt{3k/\textbf{N}}\ \textbf{H}^{\textbf{k}}_{\textbf{N}} \ .$$

Thus the bound attained by the strong strategy  $\underline{s}^*$  determined by  $\underline{H}$  exceeds by the factor  $\sqrt{3}$  the bound attained by the weak strategy  $\underline{s}_N$  determined by  $\underline{H}_N$ , and  $\underline{s}^*$  is less conservative than  $\underline{s}_N^*$  for k < N/3 and more conservative for k > N/3.

The assumption that L is minimal for a given  $\,\mu\,$  satisfying (5.2) yields

(9) 
$$L(\mu, A) = \max_{q,r} \sup_{t_1 \le t_2} \mu \left[ t_1 \le zA^{qr} / |A^{qr}| \le t_2 \right] / (t_2 - t_1)$$

and

(over the class of A satisfying (2.4)) is expressible as

where a is the generic m-vector with |a|=1 and not all  $a_1$  of the same sign. It may be verified that the expression (10) does not increase in the change from  $\mu$  to the symmetrification of  $\mu$  under coordinate permutation, and hence that the attempt to minimize it may be confined to the class of symmetric  $\mu$ . Here  $\theta=m$   $\mathcal{E}_{\mu}z_{1}$  and from

$$\mu[t_1 \le za \le t_2] \ge \mu[t_1 - a_m \le z_1 \le t_2]$$

when  $a_1 = 1$ ,  $a_2 = \cdots = a_{m-1} = 0 > a_m \ge -1$ , it follows that

$$\sup_{a} \mu[t_{1} \leq za \leq t_{2}] \geq \mu[t_{1} < z_{1} \leq t_{2}]$$

and hence that

(11) 
$$\sup_{A} \theta L(\mu, A) \ge m(\mathcal{E}_{\mu} z_{1}) p \ge m/2 ,$$

where p is the essential sup of the p-density of  $z_1$  and the second inequality comes from the fact that, for fixed  $p \ge 1$ ,

$$\mathcal{E}_{\mu}z_{1} \geq \int_{0}^{1/p} z_{1}p \, dz_{1} = 1/2p$$
.

However, if  $\mu$  is taken to be uniform on Z,  $\mathcal{E}_{\mu}z_1$  = 1/2 and assuming without loss of generality that  $a_1$  = 1,

$$\mu[t_{1} \leq za \leq t_{2}] = \mathcal{E}_{\mu} \mu \left[ t_{1} - \sum_{2}^{m} z_{1}a_{1} \leq z_{1} \leq t_{2} - \sum_{2}^{m} z_{1}a_{1} \mid z_{2}, \dots, z_{m} \right]$$

$$\leq \mathcal{E}_{\mu}(t_{2} - t_{1}) = t_{2} - t_{1} ,$$

so that the lower bound of (11) is attained for this choice of  $\mu$ .

For  $\mu$  uniform on Z, L0 = m/2 by (12) and the preceding. The optimal weak  $\underline{H}_N$  of (4) are then given by  $H_N^k = [n^2/2m]^{1/2}N^{1/2}$  k = 1, 2, ..., N, and for the weak  $\underline{s}_N^*$  thereby defined it follows from (3) and Theorem 3 that

(13) 
$$-N^{1/2}[n^2m/8]^{1/2} |B| \leq D^{N}(\underline{\epsilon}, \underline{s}_{N}^{*}) \leq N^{1/2}[n^2m/2]^{1/2} |B| .$$

The lower bound can easily be improved to zero by noting the non-negativeness of  $E^k[\sigma^k-\sigma^{k+1}]$  in Section 6. A more important improvement will consist in a treatment of  $\underline{s}_N^*$  parallel to Theorem 6 which will show that n may be taken to be 2 in the strategy and bounds, regardless of the number of II's pure strategies.

The optimal strong  $\underline{H}$  of (8) are, for  $\mu$  uniform on Z, given by

(14) 
$$H^{k} = [3n^{2}/2m]^{1/2} \qquad k = 1, 2, \dots,$$

and the behavior of the resulting strong strategy  $\underline{s}^*$  is the most important single result of this paper. As a corollary to Theorem 3 via (7), (8), and (14),

THEOREM 4. If  $\mu$  is the uniform measure on the m-cube Z,  $\underline{H}$  satisfies (7.14),  $\sigma(w)$  minimizes  $w\sigma$  for each m-vector w and  $\underline{s}*(\underline{E})$  is defined by  $s*^k(\underline{E}^{k-1}) = \mathcal{E}_{\mu}\sigma(\underline{E}^{k-1} + \underline{H}^{k-1}z)$ ,  $k=1,2,\ldots$ , then for all N and  $\underline{\varepsilon}$ ,

$$-N^{1/2} \left[ 3n^2m/8 \right]^{1/2} |B|$$

$$\leq \sum_{1}^{N} \epsilon^{k} s^{*k} (E^{k-1}) - \emptyset(E^{N}) \leq N^{1/2} \left[ 3n^{2}m/2 \right]^{1/2} |B|$$
.

As in the case of  $\underline{s}_N^*$  and the bound (13), Theorem 6 will furnish the uniform improvement that, quite irrespective of the number of II's pure strategies, Theorem 4 remains true when the n of the strategy and bounds is taken to be 2.

## PART II. NON-FINITE GAMES

# §8. NOTATION; EXTENSIONS; BEHAVIOR OF $\chi_1^N$ s(E^{k-1})

In non-finite games where the Bayes response is sufficiently smooth, the generalization of the recursive strategy  $\underline{s}$  with  $\underline{s}^k(\underline{\epsilon}^{k-1}) = \underline{s}(\underline{E}^{k-1})$  has maximum modified regret of lower order than  $N^{1/2}$ . The treatment of such games is essentially simpler and, indeed, preceded and motivated the construction of  $\underline{s}^*$  for finite games. Section 8 extends the structure and notation of Part I to a class of non-finite games, briefly consider the degree of extension of the results of Part I and investigates some aspects of the behavior of the generalized  $\chi_1^N$   $\underline{s}(\underline{E}^{k-1})$ .

Let  $\,M\,$  denote the set of I's pure strategies,  $\,\varepsilon\,$  represent a generic pure strategy and the p-measure assigning probability 1 to  $\,\varepsilon\,.$  Let  $\,N\,$  and  $\,\delta\,$  do the same for II's strategies and let II's inutility be given by

(1) 
$$A_{\epsilon}^{\delta} \geq 0 \qquad \text{on} \qquad M \times N \quad .$$

As in Section 2 it is convenient to parametrize II's strategies by their risk, letting  $\sigma$  denote the generic element of the set of functions on M, [A<sup> $\delta$ </sup>| $\delta$  in N]. The scalar product,  $\epsilon\sigma$  =  $\mathcal{E}_{\epsilon}\sigma$ , is then the value of  $\sigma$  at  $\epsilon$ , the loss resulting when II uses  $\sigma$  and  $\epsilon$  obtains. Within this parametrization randomized strategies for II will be denoted by s and defined by

(2) 
$$\epsilon_{S} = \mathcal{E}_{y} \epsilon_{\sigma} = \mathcal{E}_{y} A_{\epsilon}^{\delta}$$

where y is the generic p-measure on a fixed sigma-algebra of subsets of N which includes the points  $\sigma$  and, for each  $\varepsilon$ , the inverse image under  $A_\varepsilon^\delta$  of the Borel subsets of the real line.

Letting W be the class of measures w each of which is confined to some finite subset of M, X the subset of  $\vec{p}$ -measures x in W, define

$$w\sigma = \mathcal{E}_{w}\sigma .$$

The Bayes envelope is then the function on W,

$$\emptyset(w) = \inf_{\sigma} w\sigma$$
.

It will be assumed that this infimum is attained for each  $\,w\,$  and hence that there is at least one Bayes response,  $\,\sigma(w)$ ,

$$(4) \qquad \qquad w\sigma(w) = \emptyset(w).$$

To consider  $G^N$  with a non-finite component game, notation defined by natural extension will be freely transported from Part I. The notation and arguments of Section 3 thru (3.16) are capable of direct translation and the proof of Theorem 1 fails only because of the possible extent of the domain of  $E^N$ , hence will apply to the finite-M games of Section 9. In this connection, and because of extensive future usage, the translation of (3.9) is notable.  $E^{k-1}$  is that element of W with

128

(5) 
$$E^{k-1}(\epsilon) = [\text{number of } \epsilon^1, \epsilon^2, \dots, \epsilon^{k-1}, \text{ which equal } \epsilon]$$

$$= \sum_{j=1}^{k-1} \epsilon^{j}(\epsilon) \qquad \qquad k = 1, 2, \dots .$$

The material proper to Section 4 on the modified regret ordering in weak  $G^N$  has the same translation capabilities thru (4.11). Theorem 2 fails only because (4.12) does and the translation of its proof (and of (4.10)) shows that the existence of an  $x_0$ , such that  $\sigma(x_0)$  has determinations  $\sigma$  and  $\sigma'$  for which  $h^2(x_0) = \mathcal{E}_{x_0}[\epsilon(\sigma - \sigma')]^2 > 0$ , implies the principal conclusion of that theorem,

HANNAN

$$D^{N} = \inf_{\underline{S}} \sup_{\underline{\epsilon}} \left[ \sum_{1}^{N} \epsilon^{k} s^{k} (\underline{\epsilon}^{k-1}) - \emptyset(E^{N}) \right]$$

$$\geq N\emptyset(x_{0}) - \mathcal{E}_{[x_{0}]^{N}} \emptyset(E^{N}) \geq (2\pi)^{-1/2} hN^{1/2}.$$

The developments of Sections 5 and 7 and part of the proof of Theorem 3 will be used in connection with the proof of Theorem 6 in Section 9. In the more general context of the present section it will be of interest to consider some implications of the identity analogous to (6.4),

(7) 
$$\sum_{1}^{N} \epsilon^{k} s^{k} = E^{N} s^{N} + \sum_{1}^{N-1} E^{k} (s^{k} - s^{k+1}) ,$$

concerning the behavior of the recursive strategy  $\chi_1^N$  s(E^{k-1}) and of the extra-recursive strategy  $\chi_1^N$  s(E^k).

As when the component game is finite, it follows from (7) that the latter has non-positive modified regret,

(8) 
$$\sum_{1}^{N} \epsilon^{k} s(E^{k}) \leq \emptyset(E^{N}) .$$

Letting  $\underline{\epsilon}^{!}$  denote the order reversal of  $\underline{\epsilon}^{N}$ ,

(9) 
$$\sum_{1}^{N} \epsilon^{ik} s(E^{ik}) = \sum_{1}^{N} \epsilon^{k} s(E^{N} - E^{k-1}) ;$$

and from this representation it follows, as in connection with the proof of Theorem 1, that

$$\mathcal{E}_{P} \sum_{1}^{N} \epsilon^{k} s(E^{k}) = \sum_{1}^{N} \mathcal{E}_{P} \emptyset(E^{r}/r)$$

$$\leq \emptyset^{N}(E^{N}) \leq \max_{\underline{\epsilon}^{N} \mid E^{N}} \sum_{1}^{N} \epsilon^{k} s(E^{k}) .$$

Turning to  $X_1^N$  s(E<sup>k-1</sup>), it is again more convenient to consider the variant of (7) which involves s<sup>N+1</sup> and yields the representation

$$\sum_{1}^{N} \epsilon^{k} s(E^{k-1}) - \emptyset(E^{N}) = \sum_{1}^{N} E^{k} [s(E^{k-1}) - s(E^{k})] ,$$

$$(11)$$

$$\leq \sum_{1}^{N} \epsilon^{k} [s(E^{k-1}) - s(E^{k})] .$$

This upper bound suggests the investigation of conditions under which there exists a Bayes response s which is continuous in the sense that

(12) 
$$\lim_{\epsilon \in S(x) - S(x + t\epsilon)} = 0 .$$

It is easily established that the existence of a dominant determination of s(x) is a necessary condition for (12). For, if s is a non-dominant determination of s(x), t>0, s' and  $\epsilon'$  such that  $xs'=\emptyset(x)$  and  $\epsilon'(s-s')>0$ , then it follows from

$$\mathsf{t}\varepsilon^{\,\mathsf{!}}\mathsf{S}(\mathsf{X}\,+\,\mathsf{t}\varepsilon^{\,\mathsf{!}})\,+\,\emptyset\,(\mathsf{X}\,)\,\leq\,\emptyset\,(\mathsf{X}\,+\,\mathsf{t}\varepsilon^{\,\mathsf{!}})\,\leq\,(\mathsf{X}\,+\,\mathsf{t}\varepsilon^{\,\mathsf{!}})\mathsf{S}^{\,\mathsf{!}}\,=\,\mathsf{t}\varepsilon^{\,\mathsf{!}}\mathsf{S}^{\,\mathsf{!}}\,+\,\emptyset\,(\mathsf{X}\,)$$

that  $\epsilon'[s - s(x + t\epsilon)] \ge \epsilon'(s - s')$ , hence is uniformly bounded away from zero.

If  $\sigma$  is a dominant Bayes response in the sense that, for each x,  $\sigma(x)$  is a dominant determination of s(x), a sufficient condition that  $\sigma$  satisfy (12) is the sequential compactness of the class of risk functions,  $\{\sigma(x) \mid x \in X\}$ , relative to pointwise convergence on M. That the limit in (12) exists follows from the easily established monotonicity in t of  $\varepsilon\sigma(x+t\varepsilon)$ , that the limit  $\sigma'$  of  $\sigma(x+t^{j}\varepsilon)$  for a sequence  $t^{j}$  approaching 0 is Bayes with respect to x follows from  $x[\sigma(x+t\varepsilon)-\sigma(x)] \leq t\varepsilon\sigma(x)$ , and that  $\varepsilon[\sigma(x)-\sigma']=0$  is insured by the dominance of  $\sigma(x)$ .

By restriction to the class of non-finite games where a dominant

Bayes response  $\sigma$  exists and satisfies a Lipschitz condition of order  $\alpha>0$  uniformly in x, it is assured that there exists a finite constant L such that

$$\epsilon \left[ \sigma(x) - \sigma(x + t\epsilon) \right] \le L \left( \frac{t}{1 + t} \right)^{\alpha}$$
(13)

for all  $t > 0$ ,  $\epsilon$ ,  $x$ .

Within this class of games the modified regret of the recursive strategy  $\chi^N_1$   $\sigma(\textbf{E}^{k-1})$  is readily bounded by the use of (11) and yields

THEOREM 5. If there exists a dominant Bayes response  $\sigma$  satisfying (13) for  $\alpha > 0$ , then

$$0 \leq D^{N}\left(\underline{\epsilon}, \chi_{1}^{N} \sigma(E^{k-1})\right) = \sum_{1}^{N} \epsilon^{k} \sigma(E^{k-1}) - \emptyset(E^{N}) \leq L \sum_{1}^{N} k^{-\alpha}.$$

The following example shows that Theorem 5 is not vacuous for  $\alpha \leq$  1, and thus that  $\chi_1^N$   $\sigma(E^{k-1})$  is sometimes extremely good for the purpose of reducing maximum modified regret.

EXAMPLE 2. SQUARED DEVIATION ON THE UNIT SQUARE. Let M and N be unit intervals,  $A_{\epsilon}^{\delta}=\left(\epsilon-\delta\right)^{2}$ . Then  $\sigma$  is in the collection of  $\left[\left(\epsilon-\delta\right)^{2}\mid0\leq\delta\leq1\right]$  and

$$x\sigma = \mathcal{E}_{x}(\epsilon - \delta)^{2} = \dot{\mathcal{E}}_{x}(\epsilon - \mathcal{E}_{x}\epsilon)^{2} + (\mathcal{E}_{x}\epsilon - \delta)^{2}$$
.

Hence the unique Bayes strategy with respect to x has  $\epsilon \sigma(x) = (\epsilon - \xi_x \epsilon)^2$  and a short calculation shows that the left hand side of (13) is given by

$$\left[1-\left(\frac{1}{1+t}\right)^2\right]\left(\epsilon-\mathcal{E}_{x}\epsilon\right)^2\leq 2\frac{t}{1+t}$$

so that (13) is satisfied with L = 2,  $\alpha = 1$ .

This example may be contrasted with the game on the unit square with  $A_{\epsilon}^{\delta} = |\epsilon - \delta|$ . Here  $\epsilon s(x) = \mathcal{E}_{y} |\epsilon - \delta|$  with respect to any p-measure y on  $\delta$  assigning probability 1 to the interval of medians of the distribution x (the set of numbers  $\delta$  such that  $x[0, \delta)$ ,  $x(\delta, 1] \leq 1/2$ ), and it may be verified by consideration of two possible  $\underline{\epsilon}$ ,  $(0, 1, 0, 1, \ldots)$  and  $(1, 0, 1, 0, \ldots)$ , that for any determination of s(x)

$$\sup_{\epsilon} D^{N}\left(\underline{\epsilon}, \chi_{1}^{N} s(E^{k-1})\right) \geq \frac{1}{2} \left[\frac{N+1}{2}\right] \geq \frac{N}{4} .$$

# §9. UNIFORM IMPROVEMENT OF THEOREM 4 WHEN M IS FINITE

When M consists of m elements  $\epsilon$ , a generalization of Theorem 4 can be developed under conditions vacuously satisfied by finite games. The  $\epsilon$  will be represented by the m-space basis vectors and G differs from the G of Part I only in that the set of  $\sigma$  is an arbitrary, rather than a finite, subset of m-space.

For convenience the existence of attaining  $\sigma$ , (8.4), will again be assumed as will the existence of a finite bound on the variation of the Bayes response,

(1) 
$$|B| = \sup_{w,w'} |s(w) - s(w')| < \infty$$
.

These assumptions, together with (8.1), permit the use of the analogue of (3.12),

(2) 
$$\emptyset(\epsilon) = \min_{\sigma} \epsilon_{\sigma} = \min_{\delta} A_{\epsilon}^{\delta} = 0 \text{ for each } \epsilon$$
,

without loss of generality in dealing with modified regret.

By considering the class of  $\mu$  which are uniform distributions on certain subsets of Z (instead of the class satisfying (5.2)), a functional substitute for Lemma 1 will be obtained from the examination of the effects of a simple class of transformations of the integral  $\mathcal{E}_{\mu}$   $\sigma(w+z)$ . The special case of  $\mu$  uniform on Z will then combine with the natural generalization of the proof of Theorem 4 to yield Theorem 6.

For any subset Z' of Z which is contained in a subspace of linear dimension m' and has positive m'-dimensional Lebesgue measure  $\lambda(Z')$ , define  $\mu_{Z'}$  by the density

(3) 
$$d\mu_{Z'}/d\lambda = 1/\lambda(Z') \text{ on } Z', \text{ o otherwise .}$$

The following lemma will then apply to any  $\mu$  of this type.

LEMMA 2. If for c>0, w and w' in W, T is the transformation on Z',

$$Tz = (w' + z)/c - w$$
,

then, for each  $i = 1, 2, \ldots, m$ ,

$$\begin{split} & \mathcal{E}_{\mu_{Z^{\, !}}} \; \sigma_{\underline{1}}(w \, + \, z \,) \, - \, \mathcal{E}_{\mu_{Z^{\, !}}} \; \sigma_{\underline{1}}(w^{\, !} \, + \, z \,) \\ & \leq \, |\, B \, | \; \left[ \, 1 \, - \, \mu_{Z^{\, !}}(TZ^{\, !}) \, + \, m^{\, !} \, (1 \, - \, c \,)^{+} \, \right] \; . \end{split}$$

1 32 HANNAN

PROOF. Expressing  $\mathcal{E}_{\sigma_1}(w'+z)$  as a Lebesgue integral with integration variable v, transforming via z = Tv and using the homogeneity of  $\sigma$ , noting  $\sigma_1(w+z) \geq 0$  and the domination of  $\mu_Z$ , by  $\lambda/\lambda(Z')$ ,

$$\mathcal{E}_{\sigma_{\underline{1}}(w'+z)} = \int_{Z'} \sigma_{\underline{1}}(w'+v) \frac{d\lambda}{\lambda(Z')} = c^{m'} \int_{TZ'} \sigma_{\underline{1}}(w+z) \frac{d\lambda}{\lambda(Z')}$$

$$\geq c^{m'} \int_{TZ'} \sigma_{\underline{1}}(w+z) d\mu_{Z'}.$$

Partitioning Z' by TZ',

(5) 
$$\mathcal{E}_{\sigma_{\underline{1}}(w+z)} \leq [1 - \mu_{Z_{\underline{1}}(TZ_{\underline{1}})}] |B| + \int_{TZ_{\underline{1}}} \sigma_{\underline{1}}(w+z) d\mu_{Z_{\underline{1}}}$$
,

whence by subtraction the difference of the lemma is bounded above by

(6) 
$$[1 - \mu_{Z'}(TZ')] |B| + (1 - c^{m'}) \int_{TZ'} \sigma_{\underline{i}}(w + z) d\mu_{Z'} .$$

The proof is completed by using the bound  $(1-c^{m'})^+$  |B| for the integral in (6) then weakening by  $(1-c^{m'})^+ = (1-c)^+(1+c+\ldots+c^{m'-1}) \le m'(1-c)^+$ .

The rest of this section will be devoted to applications of Lemma 2 to the particular case where Z'=Z.

Z - TZ is the subset of Z such that  $c(w_i + z_i) - w_i'$  falls outside the unit interval for at least one i. Hence

$$1 - \mu_{Z}(TZ) \leq \sum_{1}^{m} \mu_{Z} \left[ z \mid z_{1} < \frac{w_{1}^{'}}{c} - w_{1} \text{ or } z_{1} > \frac{1 + w_{1}^{'}}{c} - w_{1} \right] ,$$

and since each  $z_{\rm i}$  has the uniform distribution on (0, 1), the bound of Lemma 2 is in this case bounded above by

(7) 
$$|B| \left[ \sum_{1}^{m} \left( \frac{w_{1}'}{c} - w_{1} \right)^{+} + \sum_{1}^{m} \left( 1 + w_{1} - \frac{1 + w_{1}'}{c} \right)^{+} + m(1 - c)^{+} \right].$$

By taking c = 1 in (7) (and in (7) with w and w' interchanged) there follows a uniform strengthening of the bound deducible from Lemma 1,

(8) 
$$|\mathcal{E}_{\mu_{Z}} \sigma(w + z) - \mathcal{E}_{\mu_{Z}} \sigma(w' + z)| \leq |B| ||w' - w||$$
.

This can be used with  $\,w\,$  and  $\,w\,'\,$  identified as for (5.11) and (5.12) to obtain the strengthening of their respective particularizations to the case  $\,\mu\,=\,\mu_{7}\,\cdot\,$  For  $\,k\,>\,1$ 

(9) 
$$|s^{*k}[x] - s^{*k}[x']| \le \frac{|B|}{h^{k-1}} ||x' - x||$$
,

(10) 
$$|s^{*k}[x] - s^{*k+1}[x]| \le |B| \left[\frac{1}{h^k} - \frac{1}{h^{k-1}}\right]$$
.

For all k > 1 such that  $mh^k < 1$ , (10) may be distinctly improved by direct applications of (7). For w and w' as for (5.12) and  $c = h^{k-1}/h^k$ ,

(11) 
$$s_{i}^{*k}[x] - s_{i}^{*k+1}[x] \le |B| m \left[1 - \frac{h^{k}}{h^{k-1}}\right],$$

while from the interchange of w and w' and  $c = h^k/h^{k-1}$  it follows that the negative of the left hand side of (11) has the same upper bound, and hence

(12) 
$$|s^{*k}[x] - s^{*k+1}[x]| \le |B| m \left[1 - \frac{h^k}{h^{k-1}}\right]$$
.

The possibility of distinct improvement in the bound (12) as compared with (10) follows from the fact that  $[1-h^k/h^{k-1}]=[kH^{k-1}-(k-1)H^k]/kH^{k-1} \le k^{-1}$  by (5.1), while the bound (10) will be of order of magnitude  $k^{-1/2}$  when the  $H^k$  are of order  $k^{1/2}$ .

The most important use for Lemma 2 will be to bound

$$\mathcal{E}_{\mu} \sum_{1}^{N} \epsilon^{k} (\sigma^{k} - \sigma^{k+1})$$

in the special case  $\mu=\mu_Z$ . As in Section 6 the bounds obtainable from the use of (9) and (10) (or (12)) can be slightly improved upon by direct applications of (8). Taking  $w=E^{k-1}/H^{k-1}$ ,  $w'=E^k/H^k$ , there follows from (8) and (6.11) a generalization and improvement of the particularization of (6.12),

(13) 
$$\epsilon^{k} \left[ s^{*k} (E^{k-1}) - s^{*k+1} (E^{k}) \right] \leq |B| \left[ \frac{k-1}{H^{k-1}} - \frac{k-2}{H^{k}} \right] ,$$

whence by summation with respect to k

$$(14) \quad \mathcal{E}_{\mu_{Z}} \quad \sum_{1}^{N} \quad \epsilon^{k} \left[ \sigma(E^{k-1} + H^{k-1}z) - \sigma(E^{k} + H^{k}z) \right] \leq |B| \quad \left( \sum_{1}^{N} \frac{2}{H^{k}} - \frac{N}{H^{N}} \right)$$

1 34 HANNAN

The bound (14) can be further reduced for sufficiently large N by a substitute for (13) which is obtained directly from (7). For k>1 the choice of  $c=H^k/H^{k-1}$  yields

(15) 
$$\epsilon^{k} \left[ s^{k} (E^{k-1}) - s^{k+1} (E^{k}) \right] \leq |B| \left[ \frac{1}{H^{k-1}} + m \left( 1 - \frac{H^{k-1}}{H^{k}} \right) \right]$$

and this improves on (13) iff  $k-2>mH^{k-1}$ . By bounding the left hand side by |B| when k=1, it follows that

$$(16) \qquad \sum_{1}^{N} \epsilon^{k} [s^{*k} - s^{*k+1}] \leq |B| \left[1 + \sum_{1}^{N-1} \frac{1}{H^{k}} + m \sum_{2}^{N} \left(1 - \frac{H^{k-1}}{H^{k}}\right)\right] .$$

Since  $1 - H^{k-1}/H^k = (kH^k - kH^{k-1})kH^k \le 1/k$ , the second term of this bound is  $O(\ln N)$  and when the  $H^k$  are of order  $k^{1/2}$  it is easily verified that the bound (16) is asymptotically two thirds of that given by (14).

Noting that the proof of Theorem 3 used the finiteness of the class of II's pure strategies only thru the implied existence of  $\sigma(w)$  attaining  $\emptyset(w)$  and the bound (6.12) for

$$\mathcal{E}_{\mu} \sum_{1}^{N} \epsilon^{k} (\sigma^{k} - \sigma^{k+1})$$
,

it follows that the explicit assumption of the existence of  $\sigma(w)$  and the bound (14) prove that for  $\mu=\mu_Z$  the conclusion of Theorem 3 with n=2 applies to s\* with

$$s^{k}(E^{k-1}) = \mathcal{E}_{\mu_{Z}} \sigma(E^{k-1} + H^{k-1}z)$$
.

Further, the investigation of Section 7 of the behavior of the resulting upper bound with respect to choice of  $\underline{H}$  is immediately applicable and yields the promised improvement and generalization of (7.13),

$$(17) \qquad 0 \leq \sum_{1}^{N} \epsilon^{k} \mathcal{E}_{\mu_{Z}} \sigma \left(\mathbb{E}^{k-1} + \sqrt{\frac{2N}{m}} z\right) - \emptyset(\mathbb{E}^{N}) \leq N^{1/2} \sqrt{2m} |B| ,$$

as well as that of Theorem 4,

THEOREM 6. If  $\mu_Z$  is the uniform measure on the m-cube Z and  $\sigma(w)$  minimizes  $w\sigma$  for each m-vector w, then, for all N and  $\varepsilon$ ,

$$-N^{1/2}\sqrt{1.5m}$$
 |B|

$$\leq \sum_{1}^{N} \epsilon^{k} \mathcal{E}_{\mu_{Z}} \sigma \left( E^{k-1} + \sqrt{\frac{6k}{m}} z \right) - \emptyset (E^{N}) \leq N^{1/2} \sqrt{6m} |B| .$$

As was noted in Section 8, the natural generalization of Theorem 1 is applicable here and, with Theorem 6, proves

(18) 
$$\sum_{1}^{N} \epsilon^{k} \mathcal{E}_{\mu_{Z}} \sigma \left( \mathbb{E}^{k-1} + \sqrt{\frac{6k}{m}} z \right) - \emptyset^{N} (\mathbb{E}^{N})$$

$$\leq N^{1/2} \left( \sqrt{m-1} + \sqrt{6m} \right) |B| .$$

That of Theorem 2 proves that the strategy of Theorem 6 incurs a maximum modified regret optimal in order of magnitude if there exists  $x_0$  satisfying (4.12).

## APPENDIX. SEMI-DYNAMIC GAMES

It may be of interest to compare the behavior of  $\underline{s}^*$  in  $\underline{G}^N$  (Theorems 4 and 6) with that of an estimated Bayes response,  $\chi_1^N s(\underline{E}^{k-1})$ , in a context suggested by the interpretation of problem 13 (ii) in [10] as a semi-dynamic finite game in which I uses a fixed but unknown power strategy  $[x]^N$  in  $\underline{G}^N$ . In this context sequence strategies for II are simply ordered by their (unknown) expected inutility and for each recursive  $\underline{s}$ ,

$$\mathcal{E} \sum_{1}^{N} \epsilon^{k} s^{k} (\underline{\epsilon}^{k-1}) = \mathcal{E} \sum_{1}^{N} x s^{k} (\underline{\epsilon}^{k-1}) \geq N\emptyset(x) .$$

The expected risk of the estimated Bayes response,  $\chi_1^N$  s(E<sup>k-1</sup>),

(1) 
$$\mathcal{E} \sum_{1}^{N} \epsilon^{k} s(E^{k-1}) = \sum_{1}^{N} \mathcal{E} x s(E^{k-1}) .$$

is

Letting  $P^k$  be the  $[x]^N$  measure of the set of  $\underline{E}$  such that

$$\sum_{1}^{m} (E_{1}^{k}/k - x_{1})^{2} \ge d^{2}(x) ,$$

it follows from (2.15) that

(2) 
$$\mathcal{E}_{xs}(E^k) \leq (1 - P^k) \delta(x) + P^k[\delta(x) + |B|] = \delta(x) + P^k |B|$$
.

and hence that

(3) 
$$\mathcal{E} \sum_{1}^{N} \epsilon^{k} s(E^{k-1}) \leq N\emptyset(x) + \left(1 + \sum_{2}^{N-1} P^{k}\right) |B| .$$

The  $P^k$  may be bounded in many ways and for the present purpose it is important only that, for each fixed x,

$$C(x) = 1 + \sum_{k=0}^{\infty} P^{k}$$

is a finite constant. The latter follows from the bound

$$P^{k} \leq \mathcal{E}\left[\sum_{1}^{m} \left(E_{1}^{k}/k - x_{1}\right)^{2}\right]^{2}/d^{4}(x)$$

and a routine calculation verifying that the right hand side is a bounded function of  $\,k^{-2}$ , and thus proves

THEOREM 7. For each fixed x, there exists  $C(x) < \infty$  such that

$$0 \le \mathcal{E}_{[x]^N} \sum_{1}^{N} \epsilon^k s(E^{k-1}) - N\emptyset(x) \le C(x) |B|$$
.

The bound of the theorem may be replaced by a uniform bound. Using (2.11) and the fact that the expectation of the scalar product of  $x - E^k/k$  with any fixed m-vector is zero, (2) may be replaced by

(4) 
$$\mathcal{E} xs(E^{k}) \leq \emptyset(x) + \mathcal{E} \sum_{1}^{m} \left[ x_{1} - E_{1}^{k}/k \right]^{+} |B| .$$

Since

$$2 \sum_{1}^{m} \left[ x_{1} - E_{1}^{k}/k \right]^{+} = \sum_{1}^{m} |x_{1} - E_{1}^{k}/k| ,$$

while by two applications of the Schwarz inequality

$$(5) \sum_{1}^{m} \mathcal{E} |x_{1} - E_{1}^{k}/k| \leq k^{-1/2} \sum_{1}^{m} x_{1}^{1/2} (1 - x_{1})^{1/2} \leq k^{-1/2} (m - 1)^{1/2} ,$$

it follows from (1) and (4) that

$$\mathcal{E} \sum_{1}^{N} \epsilon^{k} s(E^{k-1}) - N\emptyset(x) \le \left[ 1 + .5(m-1)^{1/2} \sum_{1}^{N-1} k^{-1/2} \right] |B| \sim (6)$$

$$(m-1)^{1/2} N^{1/2} |B| .$$

The quantity bounded in the theorem and in (6) is a modification of regret natural to the semi-dynamic game.  $\mathcal{E}D^N(\underline{\epsilon},\chi_1^N s(E^{k-1}))$  exceeds it by the non-negative term,  $N\emptyset(x) - \mathcal{E}\emptyset(E^N)$ . By (2.10),  $N\emptyset(x) - \emptyset(E^N) \leq (Nx - E^N)s(E^N)$  and an argument similar to the previous paragraph proves

(7) 
$$0 \le N\emptyset(x) - \mathcal{E}\emptyset(E^N) \le .5(m-1)^{1/2}N^{1/2} |B|$$
.

If s(x) has a unique determination  $\sigma(x)$ , (2.15) can be used to improve (7) to

(8) 
$$N\emptyset(x) - \mathcal{E}\emptyset(E^{N}) = \mathcal{E}E^{N}[\sigma(x) - s(E^{N})] \leq N |B| P^{N},$$

while if s(x) has multiple determinations, not identical a.e. (x), it follows from (7) and Theorem 2 that  $N\emptyset(x)$  -  $\mathfrak{E}\emptyset(E^N)$  is of exact order  $N^{1/2}$ .

### BIBLIOGRAPHY

- [1] BELLMAN, R., "Decision making in the face of uncertainty II," Naval Research Logistics Quarterly 1 (1954), pp. 327-332.
- [2] BLACKWELL, D. and GIRSHICK, M. A., Theory of Games and Statistical Decisions, New York, John Wiley and Sons, 1954.
- [3] BROWN, G. W., "Some notes on computation of games solutions," RAND Report P-78 (April, 1949).
- [4] DANSKIN, J. M., "Fictitious play for continuous games," Naval Research Logistics Quarterly 1 (1954), pp. 313-320.
- [5] FELLER, W., Probability Theory and its Applications, New York, John Wiley and Sons, 1950.
- [6] HANNAN, J. F. and ROBBINS, H., "Asymptotic solutions of the compound decision problem for two completely specified distributions," Annals of Mathematical Statistics 26 (1955), pp. 37-51.
- [7] HODGES, J. L., Jr. and LEHMANN, E. L., "Some problems in minimax point estimation," Annals of Mathematical Statistics 21 (1950), pp. 182-197.

- [8] HODGES, J. L., Jr. and LEHMANN, E. L., "The use of previous experience in reaching statistical decisions," Annals of Mathematical Statistics 23 (1952), pp. 396-407.
- [9] KARLIN, S., "The structure of dynamic programming models," Naval Research Logistics Quarterly 2 (1955), pp. 285-294.
- [10] KUHN, H. W. and TUCKER, A. W., eds., Preface, Contributions to the Theory of Games, Annals of Mathematics Study No. 24 (Princeton, 1950), pp. v-xiii.
- [11] LADERMAN, J., "On the asymptotic behavior of decision procedures," Annals of Mathematical Statistics 26 (1955), pp. 551-575.
- [12] MILNOR, J., "Games against nature," Decision Processes, Chapter IV, New York, John Wiley and Sons, 1954, pp. 49-59.
- [13] von NEUMANN, J. and MORGENSTERN, O., Theory of Games and Economic Behavior, Princeton 1944, 2nd ed. 1947.
- [14] ROBBINS, H., "Asymptotically subminimax solutions of compound statistical decision problems," Proceedings of the Second Berkeley Symposium on Mathematical Statistics and Probability, University of California Press, 1951, pp. 131-148.
- [15] ROBINSON, J., "An iterative method of solving a game," Annals of Mathematics 54 (1951), pp. 296-301.
- [16] SAVAGE, L. J., The Foundations of Statistics, New York, John Wiley and Sons, 1954.
- [17] STEIN, C., "Inadmissibility of the usual estimator for the mean of a multivariate normal distribution," Proceedings of the Third Berkeley Symposium on Mathematical Statistics and Probability, University of California Press, 1956, pp. 197-206.
- [18] WESLER, O., "A modified minimax principle," TR 35, ONR, Stanford University (October, 1955).
- [19] WOLFOWITZ, J., "On  $\epsilon$ -complete classes of decision functions," Annals of Mathematical Statistics 22 (1951), pp. 461-465.

## ADDED IN THE PROOF

Professor Blackwell has recently noted, [2s], that Theorems 1 and 3 of [1s] yield a sequence strategy for II in  $(G_{m \times n})^{\infty}$ ,  $s^k(\varepsilon^{k-1}, \sigma^{k-1})$ , depending on  $\varepsilon^{k-1}$  and  $\sigma^{k-1}$  only thru  $\Sigma_1^{k-1}$   $\varepsilon^{j}\sigma^j$  and  $\varepsilon^{k-1}$ , such that

Prob. 
$$\left\{\lim \frac{1}{N} \left[ \sum_{1}^{N} \epsilon^{k} \sigma^{k} - \emptyset(E^{N}) \right] = 0 \right\} = 1$$
.

The preparation of this paper was in part supported by The Logistics Research Project, George Washington University.

The author would like to acknowledge the active participation of Professor J. W. Gaddum in the motivation and early development of this paper.

This example (and the general program it exemplifies) was suggested by the knowledge that Professor Stein had obtained optimal results in Matching Pennies [3s].

For purposes of comparison, it is interesting to note that his proof can be used to show that this strategy satisfies

$$\sum_{1}^{N} \epsilon^{k} \sigma^{k} - \emptyset(E^{N}) \leq (\sqrt{2m} + 1)N^{1/2} |B|$$

under the same assumptions as for Theorem 6 of the present paper.

## SUPPLEMENTARY BIBLIOGRAPHY

- [1s] BLACKWELL, D., "An analogue of the minimax theorem for vector payoffs," Pacific Journal of Mathematics 6 (1956), pp. 1-8.
- [2s] BLACKWELL, D.. "Controlled random walks," Proceedings of the International Congress of Mathematicians 1954, Volume III, Amsterdam, North-Holland, 1956, pp. 336-338.
- [3s] STEIN, C., "Prediction of an arbitrary sequence of zeros and ones," unpublished, 1955.

James Hannan

Michigan State University