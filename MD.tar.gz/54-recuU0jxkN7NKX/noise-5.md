[Skip to main content](#page-0-0)

[Springer Nature Link](https://link.springer.com)

[Log in](https://idp.springer.com/auth/personal/springernature?redirect_uri=https://link.springer.com/article/10.1007/s10107-015-0946-6)

[Menu](#page-8-0)

[Find a journal](https://link.springer.com/journals/) [Publish with us](https://www.springernature.com/gp/authors) [Track your research](https://link.springernature.com/home/)

[Search](#page-8-1)

[Cart](https://order.springer.com/public/cart)

- <span id="page-0-0"></span>[Home](file:///) 1.
- [Mathematical Programming](file:///journal/10107) 2.
- Article 3.

# **Fast projection onto the simplex and the \ (\pmb {l}\_\mathbf {1}\) ball**

- Short Communication •
- Series A •
- Published: 19 September 2015 •
- Volume 158, pages 575–585, (2016) •
- [Cite this article](#page-6-0) •

![](_page_0_Picture_16.jpeg)

[Mathematical Programming](file:///journal/10107) [Submit manuscript](https://www.editorialmanager.com/mapr/) 

- [Laurent Condat](#page-5-0) [1](#page-5-1) •
- 4744 Accesses •
- 289 Citations •
- 3 Altmetric •

[Explore all metrics](file:///article/10.1007/s10107-015-0946-6/metrics)  •

# **Abstract**

A new algorithm is proposed to project, exactly and in finite time, a vector of arbitrary size onto a simplex or an \(l\_1\)-norm ball. It can be viewed as a Gauss–Seidel-like variant of Michelot's variable fixing algorithm; that is, the threshold used to fix the variables is updated after each element is read, instead of waiting for a full reading pass over the list of non-fixed elements. This algorithm is empirically demonstrated to be faster than existing methods.

This is a preview of subscription content, [log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2Fs10107-015-0946-6) to check access.

# **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2Fs10107-015-0946-6)

### **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

### **Buy Now**

article

10.1007/s10107-015-0946-6

1436-4646

Fast projection onto the simplex and the \$\$\pmb {l}\_\mathbf {1}\$\$ l 1 ball

2015

| 2015                                                                                                                             |
|----------------------------------------------------------------------------------------------------------------------------------|
| Laurent Condat                                                                                                                   |
| Mathematical Programming                                                                                                         |
| 942c88b5e28d78bb9ff715e57b14fb47d32fe2b83115ff971725da409284a12f15f823755302905f80bc57b14a09fde3567cb2d5bdd0e3be27bf8760e640c60d |
| Buy article PDF 39,95 €                                                                                                          |

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

#### [Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals)

**Fig. 1**

**Fig. 2**

### **Explore related subjects**

Discover the latest articles, books and news in related subjects, suggested using machine learning.

- [Algorithms](file:///subjects/algorithms) •
- [Computational Geometry](file:///subjects/computational-geometry) •
- [Computational Complexity](file:///subjects/computational-complexity) •
- [Linear Algebra](file:///subjects/linear-algebra) •
- [Mathematics and Computing](file:///subjects/mathematics-and-computing) •
- [Optimization](file:///subjects/optimization) •

## **Notes**

Actually, Algorithm 4 is an improvement of Michelot's algorithm, with the test "\(>\)" instead of "\(\ge \)" at step 2.1. This modification has been proposed in [\[13,](file:///article/10.1007/s10107-015-0946-6#ref-CR13) Sect. 5.7]. Algorithm 4 is also the same algorithm as in [[9\]](file:///article/10.1007/s10107-015-0946-6#ref-CR9). 1.

# **References**

Bentley, J.L., McIlroy, M.D.: Engineering a sort function. Softw. Pract. Exp. **23**(11), 1249–1265 (1993) 1.

#### [Article](https://doi.org/10.1002%2Fspe.4380231105) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Engineering%20a%20sort%20function&journal=Softw.%20Pract.%20Exp.&doi=10.1002%2Fspe.4380231105&volume=23&issue=11&pages=1249-1265&publication_year=1993&author=Bentley%2CJL&author=McIlroy%2CMD)

Bioucas-Dias, J.M., Plaza, A., Dobigeon, N., Parente, M., Du, Q., Gader, P., Chanussot, J.: Hyperspectral unmixing overview: geometrical, statistical, and sparse regression-based approaches. IEEE J. Sel. Top. Appl. Earth Obs. Remote Sens. **5**(2), 354–379 (2012) 2.

#### [Article](https://doi.org/10.1109%2FJSTARS.2012.2194696) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Hyperspectral%20unmixing%20overview%3A%20geometrical%2C%20statistical%2C%20and%20sparse%20regression-based%20approaches&journal=IEEE%20J.%20Sel.%20Top.%20Appl.%20Earth%20Obs.%20Remote%20Sens.&doi=10.1109%2FJSTARS.2012.2194696&volume=5&issue=2&pages=354-379&publication_year=2012&author=Bioucas-Dias%2CJM&author=Plaza%2CA&author=Dobigeon%2CN&author=Parente%2CM&author=Du%2CQ&author=Gader%2CP&author=Chanussot%2CJ)

- Blondel, M., Fujino, A., Ueda, N.: Large-scale multiclass support vector machine training via Euclidean projection onto the simplex. In: Proceedings of the 22th International Conference on Pattern Recognition (ICPR), pp. 1289–1294 (2014) 3.
- Blum, M., Floyd, R.W., Pratt, V.R., Rivest, R.L., Tarjan, R.E.: Time bounds for selection. J. Comput. Syst. Sci. **7**(4), 448–461 (1973) 4.

#### [Article](https://doi.org/10.1016%2FS0022-0000%2873%2980033-9) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=329916) [MATH](http://www.emis.de/MATH-item?0278.68033) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Time%20bounds%20for%20selection&journal=J.%20Comput.%20Syst.%20Sci.&doi=10.1016%2FS0022-0000%2873%2980033-9&volume=7&issue=4&pages=448-461&publication_year=1973&author=Blum%2CM&author=Floyd%2CRW&author=Pratt%2CVR&author=Rivest%2CRL&author=Tarjan%2CRE)

Brodie, J., Daubechies, I., Mol, C.D., Giannone, D., Loris, I.: Sparse and stable Markowitz portfolios. Proc. Natl. Acad. Sci. **106**(30), 12267–12272 (2009) 5.

#### [Article](https://doi.org/10.1073%2Fpnas.0904287106) [MATH](http://www.emis.de/MATH-item?1203.91271) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Sparse%20and%20stable%20Markowitz%20portfolios&journal=Proc.%20Natl.%20Acad.%20Sci.&doi=10.1073%2Fpnas.0904287106&volume=106&issue=30&pages=12267-12272&publication_year=2009&author=Brodie%2CJ&author=Daubechies%2CI&author=Mol%2CCD&author=Giannone%2CD&author=Loris%2CI)

Cominetti, R., Mascarenhas, W.F., Silva, P.J.S.: A Newton's method for the continuous quadratic knapsack problem. Math. Program. Comp. **6**, 151–169 (2014) 6.

#### [Article](https://link.springer.com/doi/10.1007/s12532-014-0066-y) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=3208135) [MATH](http://www.emis.de/MATH-item?1328.65135) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20Newton%E2%80%99s%20method%20for%20the%20continuous%20quadratic%20knapsack%20problem&journal=Math.%20Program.%20Comp.&doi=10.1007%2Fs12532-014-0066-y&volume=6&pages=151-169&publication_year=2014&author=Cominetti%2CR&author=Mascarenhas%2CWF&author=Silva%2CPJS)

Duchi, J., Shalev-Shwartz, S., Singer, Y., Chandra, T.: Efficient projections onto the \ (\ell \_1\)-ball for learning in high dimensions. In: Proceedings of the 25th International Conference on Machine learning (ICML) (2008) 7.

Fadili, J., Peyré, G.: Total variation projection with first order schemes. IEEE Trans. Image Process. **20**(3), 657–669 (2011) 8.

[Article](https://doi.org/10.1109%2FTIP.2010.2072512) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2799177) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Total%20variation%20projection%20with%20first%20order%20schemes&journal=IEEE%20Trans.%20Image%20Process.&doi=10.1109%2FTIP.2010.2072512&volume=20&issue=3&pages=657-669&publication_year=2011&author=Fadili%2CJ&author=Peyr%C3%A9%2CG)

Gong, P., Gai, K., Zhang, C.: Efficient Euclidean projections via piecewise root finding and its application in gradient projection. Neurocomputing **74**, 2754–2766 (2011) 9.

[Article](https://doi.org/10.1016%2Fj.neucom.2011.02.019) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Efficient%20Euclidean%20projections%20via%20piecewise%20root%20finding%20and%20its%20application%20in%20gradient%20projection&journal=Neurocomputing&doi=10.1016%2Fj.neucom.2011.02.019&volume=74&pages=2754-2766&publication_year=2011&author=Gong%2CP&author=Gai%2CK&author=Zhang%2CC)

Held, M., Wolfe, P., Crowder, H.: Validation of subgradient optimization. Math. Program. **6**, 62–88 (1974) 10.

[Article](https://link.springer.com/doi/10.1007/BF01580223) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=341863) [MATH](http://www.emis.de/MATH-item?0284.90057) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Validation%20of%20subgradient%20optimization&journal=Math.%20Program.&doi=10.1007%2FBF01580223&volume=6&pages=62-88&publication_year=1974&author=Held%2CM&author=Wolfe%2CP&author=Crowder%2CH)

Kiwiel, K.C.: On Floyd and Rivest's SELECT algorithm. Theor. Comput. Sci. **347**, 214–238 (2005) 11.

[Article](https://doi.org/10.1016%2Fj.tcs.2005.06.032) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2184835) [MATH](http://www.emis.de/MATH-item?1080.68040) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=On%20Floyd%20and%20Rivest%E2%80%99s%20SELECT%20algorithm&journal=Theor.%20Comput.%20Sci.&doi=10.1016%2Fj.tcs.2005.06.032&volume=347&pages=214-238&publication_year=2005&author=Kiwiel%2CKC)

Kiwiel, K.C.: Breakpoint searching algorithms for the continuous quadratic knapsack problem. Math. Program. Ser. A **112**, 473–491 (2008) 12.

[Article](https://link.springer.com/doi/10.1007/s10107-006-0050-z) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2361933) [MATH](http://www.emis.de/MATH-item?1190.90121) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Breakpoint%20searching%20algorithms%20for%20the%20continuous%20quadratic%20knapsack%20problem&journal=Math.%20Program.%20Ser.%20A&doi=10.1007%2Fs10107-006-0050-z&volume=112&pages=473-491&publication_year=2008&author=Kiwiel%2CKC)

Kiwiel, K.C.: Variable fixing algorithms for the continuous quadratic knapsack problem. J. Optim. Theory Appl. **136**, 445–458 (2008) 13.

[Article](https://link.springer.com/doi/10.1007/s10957-007-9317-7) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2377517) [MATH](http://www.emis.de/MATH-item?1145.90078) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Variable%20fixing%20algorithms%20for%20the%20continuous%20quadratic%20knapsack%20problem&journal=J.%20Optim.%20Theory%20Appl.&doi=10.1007%2Fs10957-007-9317-7&volume=136&pages=445-458&publication_year=2008&author=Kiwiel%2CKC)

Knuth, D.E.: The Art of Computer Programming, vol. 2, 3rd edn, p. 232. Addison-Wesley, Boston (1998) 14.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=The%20Art%20of%20Computer%20Programming&publication_year=1998&author=Knuth%2CDE)

Lellmann, J., Kappes, J.H., Yuan, J., Becker, F., Schnörr, C.: Convex multi-class image labeling by simplex-constrained total variation. In: Proceedings of Scale Space and Variational Methods in Computer Vision (SSVM), vol. 5567, pp. 150–162 (2009) 15.

- Liu, J., Ye, J.: Efficient Euclidean projections in linear time. In: Proceedings of the 26th International Conference Machine Learning (ICML) (2009) 16.
- Michelot, C.: A finite algorithm for finding the projection of a point onto the canonical simplex of \({\mathbb{R}}^n\). J. Optim. Theory Appl. **50**(1), 195–200 (1986) 17.

[Article](https://link.springer.com/doi/10.1007/BF00938486) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=851135) [MATH](http://www.emis.de/MATH-item?0571.90074) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20finite%20algorithm%20for%20finding%20the%20projection%20of%20a%20point%20onto%20the%20canonical%20simplex%20of%20%24%24%7B%5Cmathbb%7BR%7D%7D%5En%24%24%20R%20n&journal=J.%20Optim.%20Theory%20Appl.&doi=10.1007%2FBF00938486&volume=50&issue=1&pages=195-200&publication_year=1986&author=Michelot%2CC)

Patriksson, M.: A survey on the continuous nonlinear resource allocation problem. Eur. J. Oper. Res. **185**, 1–46 (2008) 18.

[Article](https://doi.org/10.1016%2Fj.ejor.2006.12.006) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2358684) [MATH](http://www.emis.de/MATH-item?1146.90493) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20survey%20on%20the%20continuous%20nonlinear%20resource%20allocation%20problem&journal=Eur.%20J.%20Oper.%20Res.&doi=10.1016%2Fj.ejor.2006.12.006&volume=185&pages=1-46&publication_year=2008&author=Patriksson%2CM)

Patriksson, M., Strömberg, C.: Algorithms for the continuous nonlinear resource allocation problem—new implementations and numerical studies. Eur. J. Oper. Res. **243**(3), 703–722 (2015) 19.

[Article](https://doi.org/10.1016%2Fj.ejor.2015.01.029) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=3316137) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Algorithms%20for%20the%20continuous%20nonlinear%20resource%20allocation%20problem%E2%80%94new%20implementations%20and%20numerical%20studies&journal=Eur.%20J.%20Oper.%20Res.&doi=10.1016%2Fj.ejor.2015.01.029&volume=243&issue=3&pages=703-722&publication_year=2015&author=Patriksson%2CM&author=Str%C3%B6mberg%2CC)

van den Berg, E., Friedlander, M.P.: Probing the Pareto frontier for basis pursuit solutions. SIAM J. Sci. Comput. **31**, 890–912 (2008) 20.

[Article](https://doi.org/10.1137%2F080714488) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2466141) [MATH](http://www.emis.de/MATH-item?1193.49033) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Probing%20the%20Pareto%20frontier%20for%20basis%20pursuit%20solutions&journal=SIAM%20J.%20Sci.%20Comput.&doi=10.1137%2F080714488&volume=31&pages=890-912&publication_year=2008&author=Berg%2CE&author=Friedlander%2CMP)

[Download references](https://citation-needed.springer.com/v2/references/10.1007/s10107-015-0946-6?format=refman&flavour=references)

# **Author information**

#### **Authors and Affiliations**

<span id="page-5-1"></span>University of Grenoble Alpes, GIPSA-Lab, 38000, Grenoble, France Laurent Condat 1.

#### Authors

<span id="page-5-0"></span>Laurent Condat 1.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Laurent%20Condat)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Laurent%20Condat) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Laurent%20Condat%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

### **Corresponding author**

Correspondence to [Laurent Condat.](mailto:laurent.condat@gipsa-lab.grenoble-inp.fr)

### **Additional information**

This work has been partially supported by the LabEx PERSYVAL-Lab (ANR-11- LABX-0025).

# **Rights and permissions**

[Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?title=Fast%20projection%20onto%20the%20simplex%20and%20the%20%24%24%5Cpmb%20%7Bl%7D_%5Cmathbf%20%7B1%7D%24%24%20l%201%20ball&author=Laurent%20Condat&contentID=10.1007%2Fs10107-015-0946-6©right=Springer-Verlag%20Berlin%20Heidelberg%20and%20Mathematical%20Optimization%20Society&publication=0025-5610&publicationDate=2015-09-19&publisherName=SpringerNature&orderBeanReset=true)

## **About this article**

![](_page_6_Picture_8.jpeg)

### <span id="page-6-0"></span>**Cite this article**

Condat, L. Fast projection onto the simplex and the \(\pmb {l}\_\mathbf {1}\) ball. *Math. Program.* **158**, 575–585 (2016). https://doi.org/10.1007/s10107-015-0946-6

#### [Download citation](https://citation-needed.springer.com/v2/references/10.1007/s10107-015-0946-6?format=refman&flavour=citation)

Received: 26 September 2014 •

Accepted: 31 August 2015 •

Published: 19 September 2015 •

Issue date: July 2016 •

DOI: https://doi.org/10.1007/s10107-015-0946-6 •

### **Keywords**

- [Simplex](file:///search?query=Simplex&facet-discipline=%22Mathematics%22) •
- [\\(l\\_1\\)-Norm ball](file:///search?query=%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20-Norm%20ball&facet-discipline=%22Mathematics%22) •
- [Large-scale optimization](file:///search?query=Large-scale%20optimization&facet-discipline=%22Mathematics%22) •

### **Mathematics Subject Classification**

- [49M30](file:///search?query=49M30&facet-discipline=%22Mathematics%22) •
- [65C60](file:///search?query=65C60&facet-discipline=%22Mathematics%22) •
- [65K05](file:///search?query=65K05&facet-discipline=%22Mathematics%22) •
- [90C25](file:///search?query=90C25&facet-discipline=%22Mathematics%22) •

# **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2Fs10107-015-0946-6)

### **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

#### **Buy Now**

10.1007/s10107-015-0946-6

1436-4646

Fast projection onto the simplex and the \$\$\pmb {l}\_\mathbf {1}\$\$ l 1 ball

2015

| 2015                                                                                                                             |
|----------------------------------------------------------------------------------------------------------------------------------|
| Laurent Condat                                                                                                                   |
| Mathematical Programming                                                                                                         |
| 942c88b5e28d78bb9ff715e57b14fb47d32fe2b83115ff971725da409284a12f15f823755302905f80bc57b14a09fde3567cb2d5bdd0e3be27bf8760e640c60d |
| Buy article PDF 39,95 €                                                                                                          |

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals) 

Advertisement

# <span id="page-8-1"></span>**Search**

Search by keyword or author

Search

# <span id="page-8-0"></span>**Navigation**

- [Find a journal](https://link.springer.com/journals/)  •
- [Publish with us](https://www.springernature.com/gp/authors) •
- [Track your research](https://link.springernature.com/home/) •

#### **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

### **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

### **Products and services**

- [Our products](https://www.springernature.com/gp/products) •
- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

### **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •
- [Accessibility statement](https://www.springernature.com/gp/info/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •
- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

#### [Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature