![](_page_0_Picture_0.jpeg)

## Confer Proceedings of Machine Learning Research ence

on

Learnin

[edit]

# Impossible Tuning Made Possible: A New Expert Algorithm and Its Applications

Liyu Chen, Haipeng Luo, Chen-Yu Wei Proceedings of Thirty Fourth Conference on Learning Theory, PMLR 1 3 4:1 2 1 6-1 2 5 9, 2 0 2 1.

#### **Abstract**

We resolve the long-standing "impossible tuning" issue for the classic expert problem and show that, it is in fact possible to achieve regret  $O\left(\frac{1}{\sqrt{1}}\right)$  and  $\int_{\mathbb{R}^2} \frac{1}{\sqrt{1}} \, dt$  and show that, it is in fact possible to achieve regret  $\int_{\mathbb{R}^2} \frac{1}{\sqrt{1}} \, dt$  and  $\int_{\mathbb{R}^2} \frac{1}{\sqrt{1}} \, dt$  is in fact possible to achieve regret  $\int_{\mathbb{R}^2} \frac{1}{\sqrt{1}} \, dt$  in a \$T\$-round \$d\$-expert problem where  $\int_{\mathbb{R}^2} \frac{1}{\sqrt{1}} \, dt$  is in round \$t\$. Our algorithm is based on the Mirror Descent framework with a correction term and a weighted entropy regularizer. While natural, the algorithm has not been studied before and requires a careful analysis. We also generalize the bound to  $\int_{\mathbb{R}^2} \frac{1}{\sqrt{1}} \, dt$  and  $\int_{\mathbb{R}^2} \frac{1}{\sqrt{1}} \, dt$  for any prediction vector  $\int_{\mathbb{R}^2} \frac{1}{\sqrt{1}} \, dt$  that the learner receives, and recover or improve many existing results by choosing different  $\int_{\mathbb{R}^2} \frac{1}{\sqrt{1}} \, dt$ , we use the same framework to create a master algorithm that combines a set of base algorithms and learns the best one with little overhead. The new guarantee of our master allows us to derive many new results for both the expert problem and more generally Online Linear Optimization.

### Cite this Paper

| Copy to Clipboard | Download |
|-------------------|----------|
| Copy to Clipboard | Download |
| Copy to Clipboard | Download |

#### Related Material

Download PDF

This site last compiled Tue,  $\begin{array}{cccccccccccccccccccccccccccccccccccc$ 

Github Account Copyright © The authors and PMLR 2 0 2 4 . MLResearchPress