![](_page_0_Figure_1.jpeg)

<span id="page-0-1"></span>WYam63upYWf0zbeDBP4JRmLjshzN1AbnEEkOBgQvkC

IOP Publishing

Full text

<span id="page-0-0"></span>Rep Prog Phys
. 2019 Jun;82(6):064601. doi: 10.1088/1361-6633/ab052b.
Epub 2019 Feb 7.

## Physics of active emulsions

Christoph A Weber <sup>1</sup>, David Zwicker, Frank Jülicher, Chiu Fan Lee

Affiliations

PMID: 30731446 DOI: 10.1088/1361-6633/ab052b

Free article

## **Abstract**

life.

Phase separating systems that are maintained away from thermodynamic equilibrium molecular processes represent a class of active systems, which we call active emulsion. These systems are driven by external energy input, for example provided by an extern fuel reservoir. The external energy input gives rise to novel phenomena that are not present in passive systems. For instance, concentration gradients can spatially organis emulsions and cause novel droplet size distributions. Another example are active droplets that are subject to chemical reactions such that their nucleation and size can controlled, and they can divide spontaneously. In this review, we discuss the physics of phase separation and emulsions and show how the concepts that govern such phenomena can be extended to capture the physics of active emulsions. This physics is relevant to the spatial organisation of the biochemistry in living cells, for the development of novel applications in chemical engineering and models for the origin or