## Stochastic thermodynamics, fluctuation theorems, and molecular machines

## Udo Seifert

II. Institut f¨ur Theoretische Physik, Universit¨at Stuttgart, 70550 Stuttgart, Germany

Abstract. Stochastic thermodynamics as reviewed here systematically provides a framework for extending the notions of classical thermodynamics like work, heat and entropy production to the level of individual trajectories of well-defined non-equilibrium ensembles. It applies whenever a non-equilibrium process is still coupled to one (or several) heat bath(s) of constant temperature. Paradigmatic systems are single colloidal particles in time-dependent laser traps, polymers in external flow, enzymes and molecular motors in single molecule assays, small biochemical networks and thermoelectric devices involving single electron transport. For such systems, a first-law like energy balance can be identified along fluctuating trajectories. For a basic Markovian dynamics implemented either on the continuum level with Langevin equations or on a discrete set of states as a master equation, thermodynamic consistency imposes a localdetailed balance constraint on noise and rates, respectively. Various integral and detailed fluctuation theorems, which are derived here in a unifying approach from one master theorem, constrain the probability distributions for work, heat and entropy production depending on the nature of the system and the choice of non-equilibrium conditions. For non-equilibrium steady states, particularly strong results hold like a generalized fluctuation-dissipation theorem involving entropy production. Ramifications and applications of these concepts include optimal driving between specified states in finite time, the role of measurement-based feedback processes and the relation between dissipation and irreversibility. Efficiency and, in particular, efficiency at maximum power, can be discussed systematically beyond the linear response regime for two classes of molecular machines, isothermal ones like molecular motors, and heat engines like thermoelectric devices, using a common framework based on a cycle decomposition of entropy production.

PACS numbers: 05.40.-a: Fluctuation phenomena, random processes, noise, and Brownian motion; 05.70.Ln: Nonequilibrium and irreversible thermodynamics; 82.37.-j: Single molecule kinetics; 87.16.Uv, Active transport processes

| 1 |     | Introduction                                    | 6                                                        |  |  |  |  |  |  |
|---|-----|-------------------------------------------------|----------------------------------------------------------|--|--|--|--|--|--|
|   | 1.1 | From classical to stochastic thermodynamics<br> |                                                          |  |  |  |  |  |  |
|   | 1.2 |                                                 | Main features of stochastic thermodynamics               |  |  |  |  |  |  |
|   | 1.3 |                                                 | Hamiltonian, thermostatted and open quantum dynamics<br> |  |  |  |  |  |  |
|   | 1.4 |                                                 | Scope and organization of this review<br>                |  |  |  |  |  |  |
|   | 1.5 |                                                 | Complementary reviews<br><br>10                          |  |  |  |  |  |  |
| 2 |     |                                                 | Colloidal particle as paradigm<br>11                     |  |  |  |  |  |  |
|   | 2.1 |                                                 | Stochastic dynamics<br><br>11                            |  |  |  |  |  |  |
|   | 2.2 | Non-equilibrium steady states (NESSs)           |                                                          |  |  |  |  |  |  |
|   | 2.3 | Stochastic energetics                           |                                                          |  |  |  |  |  |  |
|   |     | 2.3.1                                           | The first law<br><br>13                                  |  |  |  |  |  |  |
|   |     | 2.3.2                                           | Housekeeping and "excess" heat<br><br>14                 |  |  |  |  |  |  |
|   |     | 2.3.3                                           | Heat and strong coupling<br><br>14                       |  |  |  |  |  |  |
|   |     | 2.3.4                                           | Alternative identification of work<br>14                 |  |  |  |  |  |  |
|   | 2.4 |                                                 | Stochastic entropy<br><br>15                             |  |  |  |  |  |  |
|   | 2.5 |                                                 | Ensemble averages<br><br>16                              |  |  |  |  |  |  |
|   | 2.6 |                                                 | Simple generalizations<br><br>17                         |  |  |  |  |  |  |
|   |     | 2.6.1                                           | Underdamped motion<br><br>17                             |  |  |  |  |  |  |
|   |     | 2.6.2                                           | Interacting degrees of freedom<br><br>17                 |  |  |  |  |  |  |
|   |     | 2.6.3                                           | Systems in external flow<br>18                           |  |  |  |  |  |  |
| 3 |     | Fluctuation theorems (FTs)<br>19                |                                                          |  |  |  |  |  |  |
|   | 3.1 | Phenomenological classification<br><br>19       |                                                          |  |  |  |  |  |  |
|   |     | 3.1.1                                           | Integral fluctuation theorems (IFTs)<br>19               |  |  |  |  |  |  |
|   |     | 3.1.2                                           | Detailed fluctuation theorems (DFTs)<br><br>19           |  |  |  |  |  |  |
|   |     | 3.1.3                                           | (Generalized) Crooks fluctuation theorems (CFTs)<br>20   |  |  |  |  |  |  |
|   | 3.2 | Non-equilibrium work theorems                   |                                                          |  |  |  |  |  |  |
|   |     | 3.2.1<br>Jarzynski relation (JR)<br>            |                                                          |  |  |  |  |  |  |
|   |     | 3.2.2                                           | 20<br>Bochkov-Kuzolev relation (BKR)<br>21               |  |  |  |  |  |  |
|   |     | 3.2.3                                           | Crooks fluctuation theorem (CFT)<br>21                   |  |  |  |  |  |  |
|   |     | 3.2.4                                           | Further general results on p(w)<br>21                    |  |  |  |  |  |  |
|   | 3.3 |                                                 | FTs for entropy production<br><br>22                     |  |  |  |  |  |  |
|   |     | 3.3.1                                           | IFT<br><br>22                                            |  |  |  |  |  |  |
|   |     | 3.3.2                                           | Steady-state fluctuation theorem (SSFT)<br><br>22        |  |  |  |  |  |  |
|   |     | 3.3.3                                           | Hatano-Sasa relation<br>22                               |  |  |  |  |  |  |
|   |     | 3.3.4                                           | IFT for housekeeping heat<br>23                          |  |  |  |  |  |  |
| 4 |     |                                                 | 23                                                       |  |  |  |  |  |  |
|   | 4.1 | Unification of FTs<br>Conjugate dynamics<br>    |                                                          |  |  |  |  |  |  |
|   | 4.2 |                                                 | 23<br>The master FT<br><br>25                            |  |  |  |  |  |  |
|   |     | 4.2.1                                           | Functionals with definite parity<br>25                   |  |  |  |  |  |  |
|   |     | 4.2.2                                           | Proof<br><br>25                                          |  |  |  |  |  |  |
|   | 4.3 |                                                 | <br>26                                                   |  |  |  |  |  |  |
|   | 4.4 | General IFTs<br>FTs derived from time-reversal  |                                                          |  |  |  |  |  |  |
|   |     | 4.4.1                                           | 27<br>CFTs involving reversed dynamics<br><br>27         |  |  |  |  |  |  |
|   |     | 4.4.2                                           | DFTs for symmetric and periodic driving<br><br>28        |  |  |  |  |  |  |
|   |     |                                                 |                                                          |  |  |  |  |  |  |

| CONTENTS | 3 |
|----------|---|
|          |   |

|   |     | 4.4.3 | SSFTs for NESSs                                                  |
|---|-----|-------|------------------------------------------------------------------|
|   |     | 4.4.4 | Expression for the NESS distribution                             |
|   |     | 4.4.5 | Transient fluctuation theorems TFTs                              |
|   | 4.5 |       | FTs for variants                                                 |
|   |     | 4.5.1 | FTs for underdamped motion                                       |
|   |     | 4.5.2 | FTs in the presence of external flow<br>                         |
|   |     | 4.5.3 | FT with magnetic field                                           |
|   |     | 4.5.4 | Further "detailed theorems"                                      |
|   | 4.6 |       | FTs for athermal systems<br>                                     |
|   |     | 4.6.1 | General Langevin systems                                         |
|   |     | 4.6.2 | Stochastic fields<br>                                            |
|   |     | 4.6.3 | FTs in evolutionary dynamics                                     |
| 5 |     |       | Experimental, analytical and numerical work for specific systems |
|   |     |       | with continuous degrees of freedom<br>31                         |
|   | 5.1 |       | Principal aspects<br>                                            |
|   | 5.2 |       | Overdamped motion: Colloidal particles and other systems<br>     |
|   |     | 5.2.1 | Equilibrium pdf for heat                                         |
|   |     | 5.2.2 | Moving harmonic traps and electric circuits                      |
|   |     | 5.2.3 | Harmonic traps with changing stiffness                           |
|   |     | 5.2.4 | Non-linear potentials                                            |
|   |     | 5.2.5 | Stochastic resonance                                             |
|   |     | 5.2.6 | NESS in a periodic potential<br>                                 |
|   | 5.3 |       | Underdamped motion<br>                                           |
|   |     | 5.3.1 | Torsion pendulum as experimental realization                     |
|   |     | 5.3.2 | General theoretical results                                      |
|   | 5.4 |       | Other systems                                                    |
|   |     |       |                                                                  |
| 6 |     |       | Dynamics on a discrete set of states<br>36                       |
|   | 6.1 |       | Master equation dynamics                                         |
|   |     | 6.1.1 | Transition rates and probability currents                        |
|   |     | 6.1.2 | Two classes of steady states                                     |
|   |     | 6.1.3 | Path weight and dynamical action<br>                             |
|   | 6.2 |       | Entropy production                                               |
|   |     | 6.2.1 | Stochastic entropy<br>                                           |
|   |     | 6.2.2 | Time reversal                                                    |
|   |     | 6.2.3 | Ensemble level<br>                                               |
|   |     | 6.2.4 | Splitting entropy production<br>                                 |
|   |     | 6.2.5 | Dual dynamics<br>                                                |
|   | 6.3 |       | FTs for entropy production and "work"<br>                        |
|   |     | 6.3.1 | General validity                                                 |
|   |     | 6.3.2 | Experimental case studies                                        |
|   |     | 6.3.3 | Analytical and numerical case studies<br>                        |
|   | 6.4 |       | FT for currents                                                  |

| 7 |     |          | Optimization, irreversibility, information and feedback        | 43 |
|---|-----|----------|----------------------------------------------------------------|----|
|   | 7.1 |          | Optimal protocols<br>                                          | 43 |
|   |     | 7.1.1    | General aspects<br>                                            | 43 |
|   |     | 7.1.2    | Overdamped dynamics                                            | 44 |
|   |     | 7.1.3    | Underdamped dynamics                                           | 45 |
|   |     | 7.1.4    | Discrete dynamics<br>                                          | 45 |
|   | 7.2 |          | Quantifying time's arrow                                       | 45 |
|   | 7.3 |          | Measurement and feedback<br>                                   | 46 |
|   |     | 7.3.1    | Feedback and the second law<br>                                | 46 |
|   |     | 7.3.2    | Measurement and information                                    | 46 |
|   |     | 7.3.3    | Sagawa-Ueda equality (SUE) and a generalization<br>            | 47 |
|   |     | 7.3.4    | Efficiency of Brownian information machines<br>                | 48 |
|   |     | 7.3.5    | Further theoretical work and case studies<br>                  | 49 |
|   |     | 7.3.6    | Experimental illustrations                                     | 49 |
|   |     | 7.3.7    | Hamiltonian dynamics for microcanonical initial conditions<br> | 49 |
|   |     |          |                                                                |    |
| 8 |     |          | Fluctuation-dissipation theorem (FDT) in a NESS                | 50 |
|   | 8.1 | Overview |                                                                | 50 |
|   |     | 8.1.1    | FDT in equilibrium<br>                                         | 50 |
|   |     | 8.1.2    | FDT in a NESS<br>                                              | 50 |
|   |     | 8.1.3    | Effective temperature<br>                                      | 51 |
|   | 8.2 |          | Derivation and discussion<br>                                  | 52 |
|   |     | 8.2.1    | Equivalent correlation functions in a NESS<br>                 | 52 |
|   |     | 8.2.2    | Equivalent forms of the FDT<br>                                | 53 |
|   |     | 8.2.3    | Comparison with equilibrium FDT                                | 54 |
|   |     | 8.2.4    | Systems with local detailed balance<br>                        | 55 |
|   |     | 8.2.5    | Generalized Green-Kubo relations<br>                           | 55 |
|   | 8.3 |          | Colloidal particle on a ring as paradigm<br>                   | 56 |
|   |     | 8.3.1    | Equivalent correlation functions                               | 56 |
|   |     | 8.3.2    | Three equivalent forms                                         | 56 |
|   |     | 8.3.3    | Generalized Einstein relation<br>                              | 56 |
|   |     | 8.3.4    | Experiments<br>                                                | 57 |
|   | 8.4 |          | Sheared suspensions<br>                                        | 57 |
| 9 |     |          | Biomolecular systems                                           | 58 |
|   | 9.1 | Overview |                                                                | 58 |
|   | 9.2 |          | Biopolymers with continuous degrees of freedom<br>             | 59 |
|   |     | 9.2.1    | Thermodynamic states from a microscopic model                  | 59 |
|   |     | 9.2.2    | First law<br>                                                  | 60 |
|   |     | 9.2.3    | Dynamics<br>                                                   | 61 |
|   |     | 9.2.4    | Entropy production<br>                                         | 62 |
|   |     | 9.2.5    | FTs<br>                                                        | 62 |
|   | 9.3 |          | Free energy recovery from non-equilibrium data                 | 62 |
|   |     | 9.3.1    | Hummer-Szabo relation (HSR) and variants                       | 62 |
|   |     | 9.3.2    | Experiments<br>                                                | 63 |
|   |     | 9.3.3    | Numerical work                                                 | 63 |
|   | 9.4 |          | Enzymes and molecular motors with discrete states              | 63 |
|   |     | 9.4.1    | Thermodynamic states                                           | 64 |
|   |     | 9.4.2    | First law<br>                                                  | 64 |

| CONTENTS | 5 |
|----------|---|
|          |   |

| 9.4.3<br>Role of chemiostats: Genuine NESS conditions<br><br>9.4.4<br>Stochastic trajectory and ensemble<br>9.4.5<br>Rates and local detailed balance<br><br>9.4.6<br>Entropy production and FTs<br><br>9.4.7<br>Time-dependent rates and work<br>9.4.8<br>Experiments: F1-ATPase<br><br>9.4.9<br>Biochemical reaction networks<br><br>10 Autonomous isothermal machines<br>10.1 General aspects<br>10.2 General framework for autonomous machines: Cycle representation and<br>entropy production<br>10.3 Power and efficiency<br><br>10.3.1<br>Input and output power<br>10.3.2<br>Efficiency and efficency at maximum power (EMP)<br>10.4 Linear response: Relation to phenomenological irreversible thermody<br>namics<br>10.5 Unicyclic machines<br>10.6 Multicyclic machines: Strong vs weak coupling<br><br>10.7 Efficiency and EMP of molecular motors<br>11 Efficiency of stochastic heat engines<br>11.1 Carnot, Curzon-Ahlborn and beyond<br>11.2 Autonomous heat engines<br><br>11.2.1<br>B¨uttiker-Landauer (BL) and Feynman ratchet<br><br>11.2.2<br>Electronic devices<br><br>11.2.3<br>General theory<br><br>11.2.4<br>EMP for unicyclic machines<br>11.3 Periodically driven heat engines<br>11.3.1<br>Brownian heat engine<br><br>11.3.2<br>Quantum dot<br>12 Concluding perspective<br>12.1 Summary<br><br>12.2 Beyond a Markovian dynamics: Memory effects and coarse-graining<br>12.2.1<br>Continuous states<br><br>12.2.2<br>Discrete states<br><br>12.3 Coupling of non-equilibrium steady states: A zeroth law?<br><br>12.4 Final remark |  |  |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--|--|
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |

## 1. Introduction

## 1.1. From classical to stochastic thermodynamics

Classical thermodynamics, at its heart, deals with general laws governing the transformations of a system, in particular, those involving the exchange of heat, work and matter with an environment. As a central result, total entropy production is identified that in any such process can never decrease, leading, inter alia, to fundamental limits on the efficiency of heat engines and refrigerators. The thermodynamic characterization of systems in equilibrium got its microscopic justification from equilibrium statistical mechanics which states that for a system in contact with a heat bath the probability to find it in any specific microstate is given by the Boltzmann factor. For small deviations from equilibrium, linear response theory allows to express transport properties caused by small external fields through equilibrium correlation functions. On a more phenomenological level, linear irreversible thermodynamics provides a relation between such transport coefficients and entropy production in terms of forces and fluxes. Beyond this linear response regime, for a long time, no universal exact results were available.

During the last 20 years fresh approaches have revealed general laws applicable to nonequilibrium system thus pushing the range of validity of exact thermodynamic statements beyond the realm of linear response deep into the genuine non-equilibrium region. These exact results, which become particularly relevant for small systems with appreciable (typically non-Gaussian) fluctuations, generically refer to distribution functions of thermodynamic quantities like exchanged heat, applied work or entropy production.

First, for a thermostatted shear-driven fluid in contact with a heat bath, a remarkable symmetry of the probability distribution of entropy production in the steady state was discovered numerically and justified heuristically by Evans et al. [1]. Now known as the (steady state) fluctuation theorem (FT), it was first proven for a large class of systems using concepts from chaotic dynamics by Gallavotti and Cohen [2], later for driven Langevin dynamics by Kurchan [3] and for driven diffusive dynamics by Lebowitz and Spohn [4]. As a variant, a transient fluctuation theorem valid for relaxation towards the steady state was found by Evans and Searles [5].

Second, Jarzynski proved a remarkable relation which allows to express the free energy difference between two equilibrium states by a nonlinear average over the work required to drive the system in a non-equilibrium process from one state to the other [6, 7]. By comparing probability distributions for the work spent in the original process with the time-reversed one, Crooks found a "refinement" of the Jarzynski relation (JR), now called the Crooks fluctuation theorem [8, 9]. Both, this relation and another refinement of the JR, the Hummer-Szabo relation [10] became particularly useful for determining free energy differences and landscapes of biomolecules. These relations are the most prominent ones within a class of exact results (some of which found even earlier [11, 12] and then rediscovered) valid for nonequilibrium systems driven by time-dependent forces. A close analogy to the JR, which relates different equilibrium states, is the Hatano-Sasa relation that applies to transitions between two different non-equilibrium steady states [13].

Third, for driven Brownian motion, Sekimoto realized that two central concepts of classical thermodynamics, namely the exchanged heat and the applied work, can be meaningfully defined on the level of individual trajectories [14, 15]. These quantities

entering the first law become fluctuating ones giving birth to what he called stochastic energetics as described in his monograph [16]. Fourth, Maes emphasized that entropy production in the medium is related to that part of the stochastic action, which determines the weight of trajectories that is odd under time-reversal [17, 18].

Finally, building systematically on a concept briefly noticed previously [8, 19], a unifying perspective on these developments emerged by realizing that besides the fluctuations of the entropy production in the heat bath one should similarly assign a fluctuating, or "stochastic", entropy to the system proper [20]. Once this is done, the key quantities known from classical thermodynamics are defined along individual trajectories where they become accessible to experimental or numerical measurements. This approach of taking both energy conservation, i.e., the first law, and entropy production seriously on this mesoscopic level has been called stochastic thermodynamics [21], thus revitalizing a notion originally introduced by the Brussels school in the mid-eighties where it was used on the ensemble level for chemical nonequilibrium systems [22, 23].

## 1.2. Main features of stochastic thermodynamics

Stochastic thermodynamics as here understood applies to (small) systems like colloidal particles, (bio)polymers (like DNA, RNA, and proteins), enzymes and molecular motors. All these systems are embedded in an aqueous solution. Three types of non-equilibrium situations can be distinguished for these systems. First, one could prepare the system in a non-equilibrium initial state and study the relaxation towards equilibrium. Second, genuine driving can be caused by the action of time-dependent external forces, fields, flows or unbalanced chemical reactions. Third, if the external driving is time-independent the system will reach a non-equilibrium steady state (NESS). For this latter class, particularly strong exact results exist. In all cases, even under such nonequililibrium conditions, the temperature of the system, which is the one of the embedding solution, remains well-defined. This property together with the related necessary time-scale separation between the observable, typically slow, degrees of freedom of the system and the unobservable fast ones made up by the thermal bath (and, in the case of biopolymers, by fast internal ones of the system) allows for a consistent thermodynamic description.

The collection of the relevant slow degrees of freedom makes up the state of the system. Since this state changes either due to the driving or due to the ever present fluctuations, it leads to a trajectory of the system. Such trajectories belong to an ensemble which is fully characterized by the distribution of the initial state, by the properties of the thermal noise acting on the system and by specifying the (possibily time-dependent) external driving. The thermodynamic quantities defined along the trajectory like applied work and exchanged heat thus follow a distribution which can be measured experimentally or be determined in numerical simulations.

Theoretically, the time-scale separation implies that the dynamics becomes Markovian, i.e., the future state of the system depends only on the present one with no memory of the past. If the states are made up by continuous variables (like position), the dynamics follows a Langevin equation for an individual system and a Fokker-Planck equation for the whole ensemble. Sometimes it is more convenient to identify discrete states with transition rates governing the dynamics which, on the ensemble level, leads to a master equation.

Within such a stochastic dynamics, the exact results quoted above for the

distribution functions of certain thermodynamic quantities follow universally for any system from rather unsophisticated mathematics. It is sufficient to invoke a "conjugate" dynamics, typically, but not exclusively, time-reversal, to derive these theorems in a few lines. Essentially, they lead to universal constraints on these distributions. One inevitable consequence of these theorems is the occurrence of trajectories with negative total entropy production. Such events have occasionally been called (transient) violations of the second law. In fairness to classical thermodynamics, however, one should emphasize that this classical theory ignores fluctuations. If the second law is understood as refering to the mean entropy production, it is indeed confirmed by these more recent exact relations. Moreover, they show that the probability for such events become typically exponentially small in the relevant system size which means that one has to sample exponentially many trajectories in order to observe these "violations".

Since these constraints on the distributions are so universal, one might suspect that they are useless for uncovering system specific properties. Quite to the contrary, some of them offer a surprising relation between equilibrium and non-equilibrium properties with the JR as the most prominent and useful example. Moreover, such constraints can be used as an obvious check whether the assumptions of the model apply to any particular system. Finally, studying non-universal features of these distribution functions and trying to find further common aspects in these has become an important part of the activities in this field.

Going beyond the thermodynamic framework, it turns out that many of the FTs hold formally true for any kind of Markovian stochastic dynamics. The thermodynamic interpretation of the involved quantities as heat and work is not mandatory to derive such a priori surprising relationships between functionals defined along dynamic trajectories.

## 1.3. Hamiltonian, thermostatted and open quantum dynamics

Even though I will focus in the main part of this review on systems described by a stochastic dynamics, it is appropriate to mention briefly alternative approaches as some of the FTs have originally been derived using a deterministic framework.

Hamiltonian dynamics works, in principle, if the external driving is modelled by a time-dependent potential arising, e.g., from a movable piston, tip of an atomic force microscope, or optical tweezer. Conceptually, one typically requires thermalized initial conditions, then imagines to cut off the system from the heat bath leading to the deterministic motion and finally one has to reconnect the heat bath again. In a second variant, the heat bath is considered to be part of the system but one then has to follow all degrees of freedom. One disadvantage of Hamiltonian dynamics is that it cannot deal with a genuine NESS, which is driven by a time-indepedent external field or flow, since such a setting inevitably heats up the system.

Thermostatted dynamics can deal with NESSs. Here, one keeps deterministic equations of motion and introduces a friction term making sure that on average the relevant energy (kinetic or total, depending on the scheme) does not change [24].

Even though a deterministic dynamics is sometimes considered to be more fundamental than a stochastic one, the latter has at least three advantanges from the perspective held in this review. First, from a practical point of view, in soft matter and biophysics a description focussing on the relevant (and measurable) degrees of freedom and ignoring water molecules from the outset has a certain economical

appeal. Second, stochastic dynamics can describe transitions between discrete states like in (bio)chemical reactions with essentially the same conceptual framework used for systems with continuous degrees of freedom. Third, the mathematics required for deriving the exact relations and for stating their range of validity is surpringly simple compared to what is required for dealing with NESSs in the deterministic setting.

Open quantum systems will not be discussed explicitly in this review. Some of the FTs can indeed be formulated for these systems, sometimes at the cost of requiring somewhat unrealistic measurements at the beginning and end of a process, as reviewed in [25, 26]. The results derived and discussed in the following, however, are directly applicable to open quantum systems whenever coherences, i.e. the role of non-diagonal elements in the density matrix, can be ignored. The dynamics of the driven or open quantum system is then equivalent to a classical stochastic one. For the validity of the exact relations in these cases, the quantum-mechanical origin of the transition rates is inconsequential.

#### 1.4. Scope and organization of this review

By writing this review, apart from focussing entirely on systems governed by Markovian stochastic dynamics, I have been guided by the following principles concerning format and content.

First, I have tried to present the field in a systematic order (and notation) rather than to follow the historical development which has been briefly alluded to in the introductory section above. Such an approach leads to a more concise and coherent presentation. Moreover, I have tried to keep most of the more technical parts (some of which are original) still self-contained. Both features should help those using this material as a basis for courses which I have given several times at the University of Stuttgart and at summer schools in Beijing, Boulder and J¨ulich.

Second, as a consequence of the more systematic presentation, experimental, analytical and numerical case studies of specific systems are mostly grouped together and typically placed after the general theory where they fit best.

Third, for the exact results the notions "theorem", "equality" and "relation" are used here in no particular hierarchy. I rather try to follow the practice established in the field so far. In particular, it is not implied that a result called here "theorem" is in any sense deeper that another one called "relation".

This review starts in Sect. 2 by introducing a paradigm for this field which is a colloidal particle driven by a time-dependent force as it has been realized in several experiments. Using this system, the main concepts of stochastic thermodynamics, like work, heat and entropy changes along individual trajectories, will be introduced. At the end of this section, simple generalizations of driven one-dimensional motion such as three-dimensional motion, coupled degrees of freedom and motion in external flow are discussed.

A general classification and a physical discussion of the major fluctuation theorems dealing with work and the various contributions to entropy production follows in Sect. 3. In Sect. 4, I present a unifying perspective on basically all known FTs for stochastic dynamics using the concept of a conjugate dynamics. It is shown explicitly, how these FTs follow from one master theorem. Sect. 5 contains an overview of experimental, analytical or numerical studies of Langevin-type dynamics in specific systems. Sect. 6 deals with Markovian dynamics on a discrete set of states for which FTs hold even without assuming a thermodynamic structure.

The second part of the review deals with ramifications, consequences and applications of these concepts. In Sect. 7, the optimal driving of such processes is discussed and the relation between time's arrow and the amount of dissipation derived. Both concepts can then be used to discuss the role of measurements and (optimal) feedback in these systems. Sect. 8 deals with generalizations of the wellknown fluctuation-dissipation theorem to NESSs where it is shown that stochastic entropy plays a crucial role.

Biomolecular systems are discussed in Sect. 9 where special emphasis is given to the role of time-scale separation between the fast (unobservable) degrees of freedom making up a well-defined heat bath for the non-equilibrium processes of the slow variables caused by mechanical or chemical imbalances. From a conceptual point of view the second essential new aspect of these systems is that each of the states is composed of many microstates which leads to the crucial notion of intrinsic entropy that enters some of the exact relations in a non-trivial way.

Coming back to the issues that stood at the origin of thermodynamics, the final two sections discuss the efficiency and optimization of nano and micro engines and devices where it is useful to distinguish isothermal engines like molecular motors discussed in Sect. 10 from heat engines like thermoelectric devices treated in Sect. 11. A brief summary and a few perspectives are sketched in Sect. 12.

## 1.5. Complementary reviews

A selection of further reviews dealing with the topics discussed in the first part of this article can roughly be grouped as follows.‡

The influential essay [27] had an introductory character. More recent nontechnical accounts have been given by Jarzynski [28] and van den Broeck [29] who both emphasize the relation of the fluctuation theorems with irreversibility and time's arrow. Other brief reviews by some of the main proponents include [17, 30, 31, 32] and the contributions in the collection [33]. Ritort has written a review on the role of nonequilibrium fluctuations in small systems with special emphasis on the applications to biomolecular systems [34]. A review focussing on experimental work by one of the main groups working on fluctuation theorems is [35].

For stochastic dynamics based on the master equation, a comprehensive derivation of FT's has been given by Harris and Sch¨utz [36]. The fluctuation theorem in the context of thermostatted dynamics has been systematically reviewed by Evans and Searles [37]. From the perspective of chaotic dynamics it is treated in Gallavotti's monograph [38]. The links between different approaches and rigorous mathematical statements are surveyed in [39, 40, 41].

Stochastic thermodynamics focusses on a description of individual trajectories as does an alternative approach by Attard introducing a "second entropy" [42]. On a more coarse-grained level, phenomenological thermodynamic theories of nonequilibrium systems have been developed inter alia under the label of "extended irreversible thermodynamics" [43], "GENERIC" [44], "mesoscopic dynamics of thermodynamic systems" [45] and "steady state thermodynamics" [46, 47].

Nice reviews covering related recent topics in non-equilibrium physics are [48, 49].

<sup>‡</sup> Relevant reviews for the more specific topics treated in the second part of this review will be mentioned in the respective sections.

## 2. Colloidal particle as paradigm

The main concepts of stochastic thermodynamics can be introduced using as a simple model system a colloidal particle confined to one spatial dimension, which can arguably serve as the paradigm in the field.

## 2.1. Stochastic dynamics

The overdamped motion x(τ) of a colloidal particle (or any other system with a single continuous degree of freedom) can be described using three equivalent but complementary descriptions of stochastic dynamics, the Langevin equation, the path integral, and the Fokker-Planck equation.

The Langevin equation reads

$$\dot{x} = \mu F(x, \lambda) + \zeta = \mu(-\partial_x V(x, \lambda) + f(x, \lambda)) + \zeta. \tag{1}$$

The systematic force F(x, λ) can arise from a conservative potential V (x, λ) and/or be applied to the particle directly as f(x, λ). Distinguishing these two sources is relevant only in the case of periodic boundary conditions on a ring of finite length. Both sources may be time-dependent through an external control parameter λ(τ) varied from λ(0) ≡ λ<sup>0</sup> to λ(t) ≡ λ<sup>t</sup> according to some prescribed protocol.

The thermal noise has correlations

$$\langle \zeta(\tau)\zeta(\tau')\rangle = 2D\delta(\tau - \tau')$$
 (2)

where D is the diffusion constant. In equilibrium, D and the mobility µ are related by the Einstein relation

$$D = T\mu \tag{3}$$

where T is the temperature of the surrounding medium with Boltzmann's constant k<sup>B</sup> set to unity throughout this review to make entropy dimensionless. In stochastic thermodynamics, one assumes that the strength of the noise is not affected by the presence of a time-dependent force. The range of validity of this crucial assumption can be tested experimentally or in simulations by comparing with theoretical results derived on the basis of this assumption.

The Langevin dynamics generates trajectories x(τ) starting at x(0) ≡ x<sup>0</sup> with a weight

$$p[x(\tau)|x_0] = \mathcal{N}\exp[-\mathcal{A}([x(\tau), \lambda(\tau)])] \tag{4}$$

where

$$\mathcal{A}([x(\tau), \lambda(\tau)]) \equiv \int_0^t d\tau [(\dot{x} - \mu F)^2 / 4D + \mu \partial_x F / 2]$$
 (5)

is the "action" associated with the trajectory. The last term arises from the Stratonovich convention for the discretization in the Jacobian when the weight for a noise history [ζ(τ)] is expressed by [x(τ)]. This symmetric discretization is used implicitly throughout this review. Path dependent observables Ω[x(τ)] can then be averaged using this weight in a path integral which requires a path-independent normalization N such that summing the weight (4,5) over all paths is 1. Throughout the review averages using this weight and a given initial distribution p0(x) will be denoted by h....i as in

$$\langle \Omega[x(\tau)] \rangle \equiv \int dx_0 \int d[x(\tau)] \Omega[x(\tau)] p[x(\tau)] p_0(x_0). \tag{6}$$

![](_page_11_Figure_1.jpeg)

Figure 1. Colloidal particle driven along a periodic potential  $V(x,\lambda)$  by a non-conservative force  $f(\lambda)$ . In a NESS, the external parameter  $\lambda$  is independent of time.

Equivalently, the Fokker-Planck equation for the probability  $p(x,\tau)$  to find the particle at x at time  $\tau$  is

$$\partial_{\tau} p(x,\tau) = -\partial_{x} j(x,\tau)$$

$$= -\partial_{x} (\mu F(x,\lambda) p(x,\tau) - D\partial_{x} p(x,\tau))$$
(7)

where  $j(x,\tau)$  is the probability current. This partial differential equation must be augmented by a normalized initial distribution  $p(x,0) \equiv p_0(x)$ . For further calculations, it is useful to define a mean local velocity

$$\nu(x,\tau) \equiv j(x,\tau)/p(x,\tau). \tag{8}$$

More technical background concerning these three equivalent descriptions of Markovian stochastics dynamics of a continuous degree of freedom is provided in the monographs [50, 51, 52, 53].

#### 2.2. Non-equilibrium steady states (NESSs)

For time-independent control parameter  $\lambda$ , any initial distribution will finally reach a stationary state  $p^s(x,\lambda)$ . For f=0, this stationary state is the thermal equilibrium,

$$p^{\text{eq}}(x,\lambda) = \exp[-(V(x,\lambda) - \mathcal{F}(\lambda))/T],\tag{9}$$

with the free energy

$$\mathcal{F}(\lambda) \equiv -T \ln \int dx \exp[-V(x,\lambda)/T].$$
 (10)

A non-conservative force acting on a ring as shown in Fig. 1 generates a paradigm for a genuine non-equilibrium steady state (NESS) with a stationary distribution

$$p^{s}(x,\lambda) \equiv \exp[-\phi(x,\lambda)],\tag{11}$$

where  $\phi(x,\lambda)$  is the "non-equilibrium" potential. In one dimension,  $p^s(x,\lambda)$  can be obtained explicitly by quadratures [51] or by an intriguing mapping to an equilibrium problem [54]. Characteristic for such a NESS is a steady current

$$j^{s} = \mu F(x)p^{s}(x) - D\partial_{x}p^{s}(x) \equiv v^{s}(x)p^{s}(x)$$
(12)

with the mean local velocity  $v^s(x)$ . Even for time-dependent driving, one can express the total force

$$F(x,\lambda) = [v^s(x,\lambda) - D\partial_x \phi(x,\lambda)]/\mu \tag{13}$$

through quantities referring to the corresponding stationary state which is sometimes helpful.

Occasionally, we will use  $\langle ... \rangle^{eq}$  and  $\langle ... \rangle^s$  to emphasize when averages or correlation functions are taken in genuine equilibrium and in a NESS, respectively.

#### 2.3. Stochastic energetics

2.3.1. The first law Sekimoto suggested to endow the Langevin dynamics with a thermodynamic interpretation by applying the notions appearing in the first law

$$d\bar{w} = dE + dq \tag{14}$$

to an individual fluctuating trajectory [14, 15]. Throughout the article, we use the convention that work applied to the particle (or more generally system) is positive as is heat transferred or dissipated into the environment.

It is instructive first to identify the first law for a particle in equilibrium, i.e. for f = 0 and constant  $\lambda$ . In this case, no work is applied to the system and hence an increase in internal energy, defined by the position in the potential,  $dE = dV = (\partial_x V)dx = -dq$ , must be associated with heat taken up from the reservoir.

Applying work to the particle either requires a time-dependent potential  $V(x, \lambda(\tau))$  and (or) an external force  $f(x, \lambda(\tau))$ . The increment in work applied to the particle then reads

$$dw = (\partial V/\partial \lambda) \ d\lambda + f \ dx, \tag{15}$$

where the first term arises from changing the potential at fixed particle position. Consequently, the heat dissipated into the medium must be identified with

$$dq = dw - dV = F dx. (16)$$

This relation makes physical sense since in an overdamped system the total force times the displacement corresponds to dissipation. Integrated over a time interval t, one obtains the expressions

$$w[x(\tau)] = \int_0^t [(\partial V/\partial \lambda)\dot{\lambda} + f\dot{x}] d\tau$$
 (17)

and

$$q[x(\tau)] = \int_0^t d\tau \ \dot{q} = \int_0^t F\dot{x} \, d\tau \tag{18}$$

and the integrated first law

$$w[x(\tau)] = q[x(\tau)] + \Delta V = q[x(\tau)] + V(x_t, \lambda_t) - V(x_0, \lambda_0)$$
(19)

on the level of an individual trajectory.

The expression for the heat requires a prescription of how to evaluate  $F\dot{x}$ . As above in the path integral, one has to use the mid-point, i.e., Stratonovitch rule for which the ordinary rules of calculus for differentials and integrals apply.

The expression for the heat dissipated along the trajectory  $x(\tau)$  can also be written in the form

$$q[x(\tau)] = T \frac{\mathcal{A}([x(\tau), \lambda(\tau)])}{\mathcal{A}([x(\tau), \lambda(t-\tau)])} = T \ln \frac{p[x(\tau), \lambda(\tau)]}{p[\tilde{x}(\tau), \tilde{\lambda}(\tau)]}$$
(20)

as a ratio involving the weight (5) for this trajectory given its initial point  $x_0$  compared to the weight of the time-reversed trajectory  $\tilde{x}(\tau) \equiv x(t-\tau)$  under the reversed protocol  $\tilde{\lambda}(\tau) \equiv \lambda(t-\tau)$  for  $\tilde{x}_0 = x(t) \equiv x_t$ . This formulation points to the deep relation between dissipation and time reversal which repeatedly shows up in this field.

2.3.2. Housekeeping and "excess" heat Motivated by steady state thermodynamics, it will be convenient to split the dissipated heat into two contributions [46, 13]

$$q \equiv q^{\text{hk}} + q^{\text{ex}}.$$
 (21)

The housekeeping heat is the heat inevitably dissipated in maintaining the corresponding NESS. For a Langevin dynamics, it reads

$$q^{\rm hk} \equiv \int_0^t d\tau \dot{x}(\tau) \mu^{-1} v^s(x(\tau), \lambda(\tau)). \tag{22}$$

The "excess" heat

$$q^{\text{ex}} = -(D/\mu) \int_0^t d\tau \dot{x}(\tau) \partial_x \phi(x, \lambda)$$
$$= T[-\Delta \phi + \int_0^t d\tau \dot{\lambda} \partial_\lambda \phi]$$
(23)

is the heat associated with changing the external control parameter where we have used (13,18).

- 2.3.3. Heat and strong coupling This interpretation of the first law and, in particular, of heat relies on the implicit assumption that the unavoidable coupling between particle (or, more generally, system) described by the slow variable x and the degrees of freedom making up the heat bath does neither depend crucially on x nor on the control parameter  $\lambda$ . Such an idealization may well be obeyed for a colloidal particle in a laser trap but will certainly fail for more complex systems like biomolecules. In the following, we first continue with this simple assumption. In Sect. 9.2, we discuss the general case and point out which of the results derived in the following will require a ramification. Roughly speaking, most of the fluctuation theorems hold true with minor modifications whereas infering heat correctly indeed requires one more term compared to (16).
- 2.3.4. Alternative identification of work The definition of work (15) has been criticised for supposedly being in conflict with a more conventional view that work should be given by force times displacement, see [55] and, for rebuttals, [56, 57, 58]. In principle, such a view could be integrated into the present scheme by splitting the potential into two contributions,

$$V(x,\lambda) = V^{0}(x,\lambda_{0}) + V^{\text{ex}}(x,\lambda), \tag{24}$$

the first being an intrinsic time-independent potential, and the second one a time-dependent external potential used to transmit the external force. If one defines work as

$$d\bar{w}^{\text{ex}} \equiv (-\partial_x V^{\text{ex}}(x,\lambda) + f)dx, \tag{25}$$

it is trivial to check that the first law then holds in the form

$$d\bar{w}^{\text{ex}} = dE^{\text{ex}} + dq \tag{26}$$

with the corresponding change in internal energy  $dE^{\rm ex} \equiv dV^0 = \partial_x V^0 dx$  and the identification of heat (16) unchanged. Clearly, within such a framework, it would be appropriate to identify the internal energy with changes in the intrinsic potential only. Integrated over a trajectory, this definition of work differs from the previous one by a boundary term,  $\Delta w = \Delta w^{\rm ex} + \Delta V^{\rm ex}$ .

It is crucial to appreciate that exchanged heat as a physical concept is, and should be, independent of the convention how it is split into work and changes in internal energy. The latter freedom is inconsequential as long as one stays within one scheme. A clear disadvantage of this alternative scheme, however, is that changes in the free energy of a system are no longer given by the quasistatic work relating two states. In this review, we will keep the definitions as introduced in Sect. 2.3.1 and only occasionally quote results for the alternative expression for work introduced in this section.

#### 2.4. Stochastic entropy

Having expressed the first law along an individual trajectory, it seems natural to ask whether entropy can be identified on this level as well. For a simple colloidal particle, the corresponding quantity turns out to have two contributions. First, the heat dissipated into the environment should obviously be identified with an increase in entropy of the medium

$$\Delta s^{\mathbf{m}}[x(\tau)] \equiv q[x(\tau)]/T. \tag{27}$$

Second, one identifies as a stochastic or trajectory dependent entropy of the system the quantity [20]

$$s(\tau) \equiv -\ln p(x(\tau), \tau) \tag{28}$$

where the probability  $p(x,\tau)$  obtained by first solving the Fokker-Planck equation is evaluated along the stochastic trajectory  $x(\tau)$ . Thus, the stochastic entropy depends not only on the individual trajectory but also on the ensemble. If the same trajectory  $x(\tau)$  is taken from an ensemble generated by another initial condition p(x,0), it will lead to a different value for  $s(\tau)$ .

In equilibrium, i.e., for  $f \equiv 0$  and constant  $\lambda$ , the stochastic entropy  $s(\tau)$  just defined obeys the well-known thermodynamic relation, TS = E - F, between entropy, internal energy and free energy in the form

$$Ts(\tau) = V(x(\tau), \lambda) - \mathcal{F}(\lambda), \tag{29}$$

now along the fluctuating trajectory at any time with the free energy defined in (10)

Using the Fokker-Planck equation the rate of change of the entropy of the system (28) follows as [20]

$$\dot{s}(\tau) = -\frac{\partial_{\tau} p(x,\tau)}{p(x,\tau)} \bigg|_{x(\tau)} + \left(\frac{j(x,\tau)}{Dp(x,\tau)} - \frac{\mu F(x,\lambda)}{D}\right)_{x(\tau)} \dot{x}. \tag{30}$$

Since the very last term can be related to the rate of heat dissipation in the medium (18), using  $D = T\mu$ , one obtains a balance equation for the trajectory-dependent total entropy production as

$$\dot{s}^{\text{tot}}(t) \equiv \dot{s}^{\text{m}}(t) + \dot{s}(\tau) = -\left. \frac{\partial_{\tau} p(x,\tau)}{p(x,\tau)} \right|_{x(\tau)} + \left. \frac{j(x,\tau)}{Dp(x,\tau)} \right|_{x(\tau)} \dot{x}. \tag{31}$$

The first term on the right hand side signifies a change in  $p(x,\tau)$  which can be due to a time-dependent  $\lambda(\tau)$  or, even for a constant  $\lambda_0$ , due to relaxation from a non-stationary initial state  $p_0(x) \neq p^s(x,\lambda_0)$ .

As a variant on the trajectory level, occasionally  $\phi(x,\lambda) = -\ln p^s(x,\lambda)$  has been suggested as a definition of system entropy. Such a choice is physically questionable as the following example shows. Consider diffusive relaxation of a localized initial distribution  $p_0(x)$  in a finite region  $0 \le x \le L$ . Since  $p^s(x) = 1/L$ ,  $\phi(x)$  will not change during this process. On the other hand, such a diffusive relaxation should clearly lead to an entropy increase. Only in cases where one starts in a NESS and waits for final relaxation, the change in system entropy can also be expressed by a change in the non-equilibrium potential according to  $\Delta s = \Delta \phi$ .

#### 2.5. Ensemble averages

Upon averaging, the expressions for the thermodynamic quantities along the individual trajectory should become the ensemble quantities of non-equilibrium thermodynamics derived previously for such Fokker-Planck systems, see, e.g. [19].

Averages for quantities involving the position  $x(\tau)$  of the particle are most easily performed using the probability  $p(x,\tau)$ . Somewhat more delicate are averages over quantities like the heat that involve products of the velocity  $\dot{x}$  and a function g(x). These can be performed in two steps. First, one can evaluate the average  $\langle \dot{x}|x,\tau\rangle$  conditioned on the position x in the spirit of the Stratonovitch discretization as

$$\langle \dot{x}|x,\tau\rangle \equiv \lim_{\Delta\tau \to 0} \left( \langle x(\tau + \Delta\tau) - x(\tau)|x(\tau) = x \rangle + \left( x(\tau) - x(\tau - \Delta\tau)|x(\tau) = x \rangle \right) / (2\Delta\tau).$$
(32)

The averages in the bracket on the rhs can be evaluated by discretizing the path integral (4, 5) for one step. The first term straightforwardly yields  $\mu F(x,\tau)\Delta\tau$ . In the second one, the end-point conditioning (best implemented by Bayes' theorem) is crucial which leads to an additional contribution if the distribution is not uniform. The final result is [20]

$$\langle \dot{x}|x,\tau\rangle = \mu F(x,\tau) - D\partial_x p(x,\tau) = \nu(x,\tau). \tag{33}$$

Any subsequent average over position is now trivial leading to

$$\langle g(x)\dot{x}\rangle = \langle g(x)\nu(x,\tau)\rangle = \int dx g(x)j(x,\tau).$$
 (34)

With these relations, one obtains, e.g., for the averaged total entropy production rate from (31) the expression

$$\dot{S}^{\text{tot}}(\tau) \equiv \langle \dot{s}^{\text{tot}}(\tau) \rangle = \int dx \frac{j(x,\tau)^2}{Dp(x,\tau)} = \langle \nu(x,\tau)^2 \rangle / D \ge 0, \tag{35}$$

where equality holds in equilibrium only. In a NESS, ν(x, τ) = v s (x) which thus determines the mean dissipation rate. Averaging the increase in entropy of the medium along similar lines leads to

$$\dot{S}^{\rm m}(\tau) \equiv \langle \dot{s}^{\rm m}(t) \rangle = \int dx F(x,\tau) j(x,\tau) / T. \tag{36}$$

Hence upon averaging, the increase in entropy of the system proper becomes S˙(τ) ≡ hs˙(τ)i = S˙ tot(τ)−S˙ <sup>m</sup>(τ). On the ensemble level, this balance equation for the averaged quantities can also be derived directly from the ensemble definition of the system entropy

$$S(\tau) \equiv -\int dx \ p(x,\tau) \ln p(x,\tau) = \langle s(\tau) \rangle \tag{37}$$

by using the Fokker-Planck equation (7).

## 2.6. Simple generalizations

2.6.1. Underdamped motion For some systems, it is necessary to keep the inertial term which leads with mass m and damping constant γ to the Langevin equation

$$m\ddot{x} + \gamma \dot{x} = -\partial_x V(x, \lambda) + f(\lambda) + \xi \tag{38}$$

with the noise correlations hξ(τ)ξ(τ ′ )i = 2γT δ(τ − τ ′ ).

The internal energy now must include the kinetic energy, dE = dV +mv dv, with v ≡ x˙. Since the identification of work (15) remains valid, the first law becomes

$$dq = dW - dE = Fdx - mv \ dv. \tag{39}$$

Evaluating the stochastic entropy

$$s(\tau) \equiv -\ln p(x(\tau), v(\tau), \tau) \tag{40}$$

now requires a solution of the corresponding Fokker-Plank equation

$$\partial_{\tau} p = -\partial_{x}(vp) - \partial_{v}[[(-\gamma v + F)/m]p - T(\gamma/m^{2})\partial_{v}]p \tag{41}$$

for p = p(x, v, τ) with an appropriate initial condition p0(x, v).

2.6.2. Interacting degrees of freedom The framework introduced for a single degree of freedom can easily be generalized to several degrees of freedom x obeying the coupled Langevin equations

$$\dot{\mathbf{x}} = \underline{\underline{\mu}}[-\nabla V(\mathbf{x}, \lambda) + \mathbf{f}(\mathbf{x}, \lambda)] + \zeta, \tag{42}$$

where V (x, λ) is a potential and f(x, λ) a non-conservative force. The noise correlations

$$\langle \zeta(\tau) : \zeta(\tau') \rangle = 2T\underline{\mu}\delta(\tau - \tau'),$$
 (43)

involve the mobility tensor µ. Simple examples of such system comprise a colloidal particle in three dimensions, several interacting colloidal particles, or a polymer where x labels the positions of monomers. If hydrodynamic interactions are relevant, the mobility tensor will depend on the coordinates x.

The corresponding Fokker-Planck equation becomes

$$\partial_{\tau} p(\mathbf{x}, \tau) = -\nabla \mathbf{j} = -\nabla (\underline{\mu}(-\nabla V + \mathbf{f})p - T\underline{\mu}\nabla p)$$
 (44)

with the local (probability) current j.

In particular for a NESS, there are two major formal differences compared to the one-dimensional case. First, the stationary current j s (x) becomes x dependent and, second, the stationary distribution p s (x) ≡ exp[−φ(x)] or, equivalently, the nonequilibrium potential are not known analytically except for the trivial case that the total forces are linear in x.

On a formal level, all expressions discussed above for the simple colloidal particle can easily be generalized to this multi-dimensional case by replacing scalar operations by the corresponding vector or matrix ones.

2.6.3. Systems in external flow So far, we have assumed that there is no overall hydrodynamic flow imposed on the system. For colloids, however, external flow is a common situation. Likewise, as we will see, colloids in moving traps can also be described in a co-moving frame as being subject to some flow. We therefor recall the modifications required for the basic notions of stochastic thermodynamics in the presence of external flow field u(r) [59].

The Langevin equations for k = 1, .., N coupled particles at positions r<sup>k</sup> reads

$$\dot{\mathbf{r}}_k = \mathbf{u}(\mathbf{r}_k) + \sum_l \underline{\underline{\mu}}_{kl} (-\nabla_l V + \mathbf{f}_l) + \zeta_k$$
(45)

with the usual noise correlations

$$\langle \zeta_k(\tau)\zeta_l(\tau') = 2T\underline{\underline{\mu}}_{kl}\delta(\tau - \tau') \rangle.$$
 (46)

In such a system, the increments in external work and dissipated heat are given by

$$d\bar{w} \equiv ([\partial_{\tau} + \mathbf{u}(\mathbf{r}_k)\nabla_k]V + \mathbf{f}_k[\dot{\mathbf{r}}_k - \mathbf{u}(\mathbf{r}_k)]) dt$$
(47)

and

$$dq = dw - dV = ([\dot{\mathbf{r}}_k - \mathbf{u}(\mathbf{r}_k)][-\nabla_k V + \mathbf{f}_k]) dt, \tag{48}$$

respectively. Compared to the case withour flow, the two modifications involve replacing the partial derivative by the convective one and measuring the velocity relative to the external flow velocity. These expressions guarantee frame invariance of stochastic thermodynamics [59].

For the experimentally studied case of one-dimensional colloid motion in a flow of constant velocity u discussed in Sect. 5.2.2 below, the Langevin equation simplifies to

$$\dot{x} = u + \mu(-\partial_x V + f) + \zeta \tag{49}$$

and the ingredients of the first law become

$$d\bar{w} = (\partial_{\tau}V + u\partial_{x}V)dt + f(\dot{x} - u)dt$$
(50)

and

$$dq = (\dot{x} - u)[-\partial_x V + f] dt. \tag{51}$$

## 3. Fluctuation theorems (FTs)

Fluctuation theorems express universal properties of the probability distribution p(Ω) for functionals Ω[x(τ)], like work, heat or entropy change, evaluated along the fluctuating trajectories taken from ensembles with well-specified initial distributions p0(x0). In this section, we give a phenomenogical classification into three classes according to their mathematical appearance and point out some general mathematical consequences. The most prominent ones will then be discussed in physical terms with references to their original derivation. For proofs of these relations within stochastic dynamics from the present perspective, we provide in Sect. 4 the unifying one for all FTs that also shows that there is essentially an infinity of such relations.

## 3.1. Phenomenological classification

3.1.1. Integral fluctuation theorems (IFTs) A non-dimensionalized functional Ω[x(τ)] with probability distribution function p(Ω) obeys an IFT if

$$\langle \exp(-\Omega) \rangle \equiv \int d\Omega \ p(\Omega) \exp(-\Omega) = 1.$$
 (52)

The convexity of the exponential functions then implies the inequality

$$\langle \Omega \rangle \ge 0 \tag{53}$$

which often represents a well-known thermodynamic law. With the exception of the degenerate case, p(Ω) = δ(Ω), the IFT implies that there are trajectories for which Ω is negative. Such events have sometimes then been characterized as "violating" the corresponding thermodynamic law. Such a formulation is controversial since classical thermodynamics, which ignores fluctuations from the very beginning, is silent on issues beyond its range of applicability. The probability of such events quickly diminishes for negative Ω. Using (52), it is easy to derive for ω > 0 [60]

$$\operatorname{prob}[\Omega < -\omega] \le \int_{-\infty}^{-\omega} d\Omega \ p(\Omega) \ e^{-\omega - \Omega} \le e^{-\omega}. \tag{54}$$

This estimate shows that relevant "violations" occur for Ω of order 1. Restoring the dimensions in a system with N relevant degrees of freedom, Ω will typically be of order N kBT which implies that in a large system such events are exponentially small, i.e., occur exponentially rarely. This observation essentially reconciles the effective validity of thermodynamics on the macro-scale with the still correct mathematical statements that even for large systems, in principle, such events must occur.

An IFT represents one constraint on the probability distribution p(Ω). If it is somehow known that p(Ω) is a Gaussian, the IFT implies the relation

$$\langle (\Omega - \langle \Omega \rangle)^2 \rangle = 2 \langle \Omega \rangle \tag{55}$$

between variance and mean of Ω.

3.1.2. Detailed fluctuation theorems (DFTs) A detailed fluctuation theorem corresponds to the stronger relation

$$p(-\Omega)/p(\Omega) = \exp(-\Omega) \tag{56}$$

for the pdf p(Ω). Such a symmetry constrains "one half" of the pdf which means, e.g., that the even moments of Ω can be expressed by the odd ones and vice versa. A DFT implies the corresponding IFT trivially. Further statistical properties of p(Ω) following from the validity of the DFT (and some from the IFT) are derived in [61].

Depending on the physical situation, a variable obeying the DFT has often been called to obey either a transient FT (TFT) or a steady state FT (SSFT). These notions will be explained below for the specific cases.

3.1.3. (Generalized) Crooks fluctuation theorems (CFTs) These relations compare the pdf p(Ω) of the original process one is interested in with the pdf p † (Ω) of the same physical quantity for a "conjugate" (mostly the time-reversed) process. The general statement then is that

$$p^{\dagger}(-\Omega) = p(\Omega)e^{-\Omega} \tag{57}$$

which implies the IFT (but not the DFT) for Ω since p † is normalized.

#### 3.2. Non-equilibrium work theorems

These relations deal with the probability distribution p(w) for work spent in driving the system from a (mostly equilibrium) initial state to another (not necessarily equilibrium) state. They require only a notion of work defined along the trajectory but not yet the concept of stochastic entropy.

3.2.1. Jarzynski relation (JR) In 1997, Jarzynski showed that the work spent in driving the system from an initial equilibrium state at λ<sup>0</sup> via a time-dependent potential V (x, λ(τ)) for a time t obeys [6]

$$\langle \exp(-w/T) \rangle = \exp(-(\Delta \mathcal{F}/T))$$
 (58)

where ∆F ≡ F(λt)− F(λ0) is the free energy difference between the equilibrium state corresponding to the final value λ<sup>t</sup> of the control parameter and the initial state. In the classification scheme proposed here, it can technically be viewn as the IFT for the (scaled) dissipated work

$$w_d \equiv (w - \Delta \mathcal{F})/T. \tag{59}$$

The paramount relevance of this relation – and its originally so surprising feature – is that it allows to determine the free energy difference, which is a genuine equilibrium property, from non-equilibrium measurements (or simulations). It represents a strengthening of the familiar second law hwi ≥ ∆F which follows as the corresponding inequality. It has orginally been derived using a Hamiltonian dynamics (which requires decoupling from and coupling to a heat bath at the beginning and end of the process, respectively) but soon been shown to hold for stochastic dynamics as well [7, 8, 9]. Its validity requires that one starts in the equilibrium distribution but not that the system has relaxed at time t into the new equilibrium. In fact, the actual distribution at the end will be p(x, t) but any further relaxation at constant λ would not contribute to the work anyways.

Within stochastic dynamics, the validity of the JR (as of any other FT with a thermodynamic interpretation) essentially rests on assuming that the noise in the Langevin equation (1) is not affected by the driving. A related issue arises in the Hamiltonian derivation of the JR which requires some care in identifying the proper role of the heat bath during the process [62, 63].

The JR has been studied for many systems analytically, numerically, and experimentally. Specific case studies for stochastic dynamics will be classified and quoted below in Sect. 5. As an important application, based on a generalization introduced by Hummer and Szabo [10], the Jarzynski relation can be used to reconstruct the free energy landscape of a biomolecule as discussed in Sect. 9.3 below.

3.2.2. Bochkov-Kuzolev relation (BKR) The Jarzynski relation should be distinguished from an earlier relation derived by Bochkov and Kuzolev [11, 12]. For a system initially in equilibrium in a time-independent potential  $V_0(x)$  and for  $0 \le \tau \le t$  subject to an additional space and time-dependent force (possibly arising from an additional potential), the work (25) integrated over a trajectory obeys the Bochkov-Kuzolev relation (BKR)

$$\langle \exp[-w^{\rm ex}/T] \rangle = 1. \tag{60}$$

Contrary to some claims, the BKR is different from the Jarzynski relation since they apply a priori to somewhat different situations [21, 64, 65]. The JR as discussed above applies to processes in a time-dependent potential, whereas the BKR applies to a process in a constant potential with some additional force. If, however, in the latter case, this explicit force arises from a potential as well, both the BKR and the JR (58) hold for the respective forms of work.

3.2.3. Crooks fluctuation theorem (CFT) In the Crooks relation, the pdf for work p(w) spent in the original (the "forward") process is related to the pdf for work  $\tilde{p}(w)$  applied in the reversed process where the control parameter is driven according to  $\tilde{\lambda}(\tau) = \lambda(t - \tau)$  and one starts in the equilibrium distribution corresponding to  $\tilde{\lambda}_0 = \lambda_t$ . These two pdfs obey [8, 9]

$$\tilde{p}(-w)/p(w) = \exp[-(w - \Delta \mathcal{F})/T]. \tag{61}$$

Hence,  $\Delta \mathcal{F}$  can be obtained by locating the crossing of the two pdfs which for biomolecular applications turned out to be a more reliable method than using the JR. Clearly, the Crooks relation implies the JR since  $\tilde{p}(w)$  is normalized. Technically, the Crooks relation is of the type (57) for  $R = w_d$  with the conjugate process being the reversed one.

3.2.4. Further general results on p(w) Beyond the JR and the CFT, further exact results on p(w) are scarce. For systems with linear equation of motion, the pdf for work (but not for heat) is a Gaussian for arbitrary time-dependent driving [66, 67]. For slow driving, i.e., for  $t_{\rm rel}/t \ll 1$  where  $t_{\rm rel}$  is the typical relaxation time of the system at fixed  $\lambda$  and t the duration of the process, an expansion based on this time-scale separation yields a Gaussian for any potential [68]. Such a result has previously been expected [69, 70] or justified by invoking arguments based on the central limit theorem [71]. Two observations show, however, that such an expansion is somewhat delicate. First, even in simple examples there occur terms that are non-analytic in  $t_{\rm rel}/t$  [68]. Second, for the special case of a "breathing parabola",  $V(x,\lambda) = \lambda(\tau)x^2/2$ , any protocol with  $\dot{\lambda} > 0$  leads to  $p(w) \equiv 0$  for w < 0 which is obviously violated by a Gaussian. How the latter effectively emerges in the limit of slow driving is investigated in [72].

From another perspective, Engel [73, 74] investigated the asymptotic behavior of p(w) for small T using a saddle point analysis. The value of this approach is that

it can provide exact results for the tail of the distribution. Specific examples show an exponential decay. Saha et al. [75] suggest that the work distribution for quite different systems can be mapped to a class of universal distributions.

3.3. FTs for entropy production

3.3.1. IFT The total entropy production along a trajectory as given by

$$\Delta s^{\text{tot}} \equiv \Delta s^{\text{m}} + \Delta s, \tag{62}$$

with

$$\Delta s \equiv -\ln p(x_t, \lambda_t) + \ln p(x_0, \lambda_0) \tag{63}$$

and ∆s <sup>m</sup> defined in (27), obeys the IFT [20]

$$\langle \exp(-\Delta s^{\text{tot}}) \rangle = 1$$
 (64)

for arbitrary initial distribution p(x, 0), arbitrary time-dependent driving λ(τ) and an arbitrary length t of the process.

Formally, this IFT can be considered as a refinement of the second law, h∆s toti ≥ 0, which is the corresponding inequality. Physically, however, it must be stressed that by using the Langevin equation a fundamental irreversibility has been implemented from the very beginning. Thus, this IFT should definitely not be considered to constitute a fundamental proof of the second law.

3.3.2. Steady-state fluctuation theorem (SSFT) In a NESS with fixed λ, the total entropy production obeys the stronger SSFT

$$p(-\Delta s^{\text{tot}})/p(\Delta s^{\text{tot}}) = \exp(-\Delta s^{\text{tot}})$$
 (65)

again for arbitrary length t. This relation corresponds to the genuine "fluctuation theorem". It has first been found in simulations of two-dimensional sheared fluids [1] and then been proven by Gallavotti and Cohen [2] using assumptions about chaotic dynamics. For stochastic diffusive dynamics as considered specifically in this review, it has been proven by Kurchan [3] and Lebowitz and Spohn [4]. Strictly speaking, in these early works the relation holds only asymptotically in the long-time limit since entropy production had been associated with what is here called entropy production in the medium. If one includes the entropy change of the system (28), the SSFT holds even for finite times in the steady state [20].

3.3.3. Hatano-Sasa relation The Hatano-Sasa relation applies to systems with steady states p s (x, λ) = exp[−φ(x, λ)]. With the splitting of the dissipated heat into a housekeeping and excess one (21), the IFT [13]

$$\langle \exp[-(\Delta\phi + q^{\rm ex}/T)] \rangle = 1$$
 (66)

holds for any length of trajectory with ∆φ ≡ φ(xt, λt)− φ(x0, λ0). The corresponding inequality

$$\langle \Delta \phi \rangle \ge -\langle q^{\text{ex}} \rangle / T$$
 (67)

allows an interesting thermodynamic interpretation. The left-hand side can be seen as ensemble entropy change of the system in a transition from one steady state to

another. Within the framework discussed in this review, this interpretation is literally true provided one waits for final relaxation at constant  $\lambda_t$  since then  $\Delta s = \Delta \phi$ . A recent generalization of the HS relation leads to a variational scheme for approximating the stationary state [76].

With the interpretation of the left hand side as entropy change in the system, the inequality (67) provides for transitions between NESSs what the famous Clausius inequality does for transitions between equilibrium states. The entropy change in the system is at least as big as the excess heat flowing into the system. For transitions between NESSs, the inequality (67) is sharper than the Clausius one (which still applies in this case and becomes just  $\langle \Delta s \rangle \geq -q/T$ ) since q scales with the transition time whereas  $q^{\rm ex}$  can remain bounded and can actually approach equality in (67) for quasistatic transitions.

Experimentally, the Hatano-Sasa relation has been verified for a colloidal particle pulled through a viscous liquid at different velocities which corresponds to different steady states [77].

3.3.4. IFT for housekeeping heat Finally, it should be noted that the second contribution to heat, the housekeeping heat also obeys an IFT [78]

$$\langle \exp[-q^{\rm hk}/T] \rangle = 1 \tag{68}$$

for arbitrary initial state, driving and length of trajecories.

#### 4. Unification of FTs

Originally, the FTs have been found and derived on a case by case approach. However, it has soon become clear that within stochastic dynamics a unifying strategy is to investigate the behaviour of the system under time-reversal. Subsequently, it turned out that comparing the dynamics to its "dual" one [13, 79], eventually also in connection with time-reversal, allows a further unification. In this section, we outline this general approach and show how the prominent FTs discussed above (and a few further ones mentioned below) fit into, or derive from, this framework. Even though this section is inevitably somewhat technical and dense, it is self-contained. It could be skipped by readers not interested in the proofs or systematics of the FTs. For related mathematically rigorous approaches to derive FTs for diffusive dynamics, see [80, 81, 82, 83].

#### 4.1. Conjugate dynamics

FTs for the original process with trajectories  $x(\tau)$ ,  $0 \le \tau \le t$ , an initial distribution  $p_0(x_0)$  and a conditional weight  $p[x(\tau)|x_0]$  are most generally derived by formally invoking a "conjugate" dynamics for trajectories  $x^{\dagger}(\tau)$ . These are supposed to obey a Langevin equation

$$\dot{x}^{\dagger} = \mu^{\dagger} F^{\dagger}(x^{\dagger}, \lambda^{\dagger}) + \zeta^{\dagger}. \tag{69}$$

with  $\langle \zeta^{\dagger}(\tau)\zeta^{\dagger}(\tau')\rangle = 2\mu^{\dagger}T^{\dagger}\delta(\tau-\tau')$ . The trajectories with weight  $p^{\dagger}[x^{\dagger}(\tau)|x_{0}^{\dagger}]$  run over a time t and start with an initial distribution  $p^{\dagger}(x_{0}^{\dagger})$ . Averages of the conjugate dynamics will be denoted by  $\langle ... \rangle^{\dagger}$ .

This conjugate dynamics is related to the original process by a one-to-one mapping

$$\{x(\tau), \lambda(\tau), F, \mu, T\} \to \{x^{\dagger}(\tau), \lambda^{\dagger}(\tau), F^{\dagger}, \mu^{\dagger}, T^{\dagger}\}$$
 (70)

which allows to express all quantities occurring in the conjugate dynamics in terms of the original ones.

The crucial quantity leading to the FTs is a master functional given by the logratio of the unconditioned path weights

$$R[x(\tau)] \equiv \ln \frac{p[x(\tau)]}{p^{\dagger}[x^{\dagger}(\tau)]}$$

$$= \ln \frac{p_0(x_0)}{p_0^{\dagger}(x_0^{\dagger})} + \ln \frac{p[x(\tau)|x_0]}{p^{\dagger}[x^{\dagger}(\tau)|x_0^{\dagger}]} \equiv R_0 + R_1$$
(71)

that consists of a "boundary" term  $R_0$  coming from the two initial distributions and a "bulk" term  $R_1$ .

Three choices for the conjugate dynamics and the associated mapping have been considered so far. In all cases, neither the temperature nor the functional form of the mobilities have been changed for the conjugate dynamics, i.e.,  $T^{\dagger} = T$  and  $\mu^{\dagger} = \mu$ .

(i) Reversed dynamics: This choice corresponds to "time-reversal". The mapping reads

$$x^{\dagger}(\tau) \equiv x(t - \tau) \quad \text{and} \quad \lambda^{\dagger}(\tau) \equiv \lambda(t - \tau)$$
 (72)

with no changes at the functional dependence of the force from its arguments, i.e.,  $F^{\dagger}(x^{\dagger}, \lambda^{\dagger}) = F(x^{\dagger}, \lambda^{\dagger})$ .

The weight of the conjugate trajectories is easily calculated using the mapping (72) in the weight (4,5) leading to

$$R_1 = \mathcal{A}([x^{\dagger}(\tau), \lambda^{\dagger}(\tau)]) - \mathcal{A}([x(\tau), \lambda(\tau)]) = \Delta s^{\mathrm{m}} = q/T, \tag{73}$$

which is the part of the action  $\mathcal{A}([x(\tau),\lambda(\tau)])$  that is odd under time-reversal.

This relation allows a deep physical interpretation. For given initial point  $x_0$  and final point  $x_t$ , the log ratio between the probability to observe a certain forward trajectory and the probability to observe the time-reversed trajectory is given by the heat dissipated along the forward trajectory.

(ii) Dual dynamics: This choice alters the equations of motion for the  $x^{\dagger}(\tau)$  trajectories such that (i) the stationary distribution remains the same for both processes and that (ii) the stationary current for the dual dynamics is minus the original one. Specifically, this mapping reads [79]

$$F^{\dagger}(x^{\dagger}, \lambda^{\dagger}) = F(x^{\dagger}, \lambda^{\dagger}) - 2v^{s}(x^{\dagger}, \lambda^{\dagger})/\mu \tag{74}$$

which enters the conjugate Langevin equation (69) and no modification for x and  $\lambda$ , i.e.,  $x^{\dagger}(\tau) \equiv x(\tau)$  and  $\lambda^{\dagger}(\tau) \equiv \lambda(\tau)$ .

Calculating the action for the dual dynamics (69), the functional  $R_1$  becomes

$$R_1 = q^{\rm hk}/T \equiv \Delta s^{\rm hk}.\tag{75}$$

(iii) Dual-reversed dynamics: For this choice, the dual dynamics is driven with the time-reversed protocol, i.e., the mapping of the force (74) is combined with the time-reversal (72). In this case, the functional  $R_1$  becomes [79]

$$R_1 = q^{\text{ex}}/T \equiv \Delta s^{\text{ex}}.\tag{76}$$

In summary, depending on the form of the conjugate dynamics, different parts of the dissipated heat form the functional  $R_1$ . For later reference, we have introduced in the last two equations for the scaled contributions to the dissipated heat the corresponding entropies.

## 4.2. The master FT

4.2.1. Functionals with definite parity The FT's apply to functionals  $S_{\alpha}[x(\tau)]$  of the original dynamics that map with a definite parity  $\epsilon_{\alpha} = \pm 1$  to the conjugate dynamics according to

$$S_{\alpha}^{\dagger} \left( [x^{\dagger}(\tau)], \lambda^{\dagger}, F^{\dagger} \right) = \epsilon_{\alpha} S_{\alpha} \left( [x(\tau)], \lambda, F \right) \tag{77}$$

such that  $S_{\alpha}^{\dagger}[x^{\dagger}(\tau)]$  represents the *same* physical quantity for the conjugate dynamics as  $S_{\alpha}[x(\tau)]$  does for the original one.

Examples for such functionals are work and heat that both are odd  $(\epsilon_{\alpha}=-1)$  for the reversed dynamics. For dual or dual reversed dynamics, however, these two functionals have no definite parity since both cases involve a different dynamics. Explicitly, the heat behaves under time-reversal as  $q^{\dagger} \equiv \int_0^t d\tau \dot{x}^{\dagger} F^{\dagger} = -\int_0^t d\tau \dot{x} F = -q$ . For dual dynamics, the heat transforms as  $q^{\dagger} \equiv \int_0^t d\tau \dot{x}^{\dagger} F^{\dagger} = \int_0^t d\tau \dot{x} (F - 2v^s/\mu) = q - 2q^{\rm hk}$  which has, in general, no definite parity. On the other hand, the housekeeping heat is odd for the dual dynamics and even for both the reversed and the dual-reversed dynamics.

The stochastic entropy  $\Delta s$ , in general, has no definite parity under time-reversal since  $s(\tau)$  is defined through the solution  $p(x,\tau)$  of the Fokker-Planck equation which is not odd under time-reversal. In particular,  $p(x,t-\tau)$  does not solve the Fokker-Planck equation for the time-reversed process even if one starts the reversed process with the final distribution p(x,t) of the original process. The change in the non-equilibrium potential  $\Delta \phi$ , however, is odd under time-reversal. This difference between  $\Delta s$  and  $\Delta \phi$  implies that  $\Delta \phi$  occurs more frequently in FTs.

4.2.2. Proof With these preparations, one can easily derive the master FT

$$\langle g(\{\epsilon_{\alpha} S_{\alpha}^{\dagger}[x^{\dagger}(\tau)]\})\rangle^{\dagger}$$

$$= \int dx_{0}^{\dagger} \int d[x^{\dagger}(\tau)]p_{0}^{\dagger}(x_{0}^{\dagger})p[x^{\dagger}(\tau)|x_{0}^{\dagger}]g(\{\epsilon_{\alpha}S_{\alpha}^{\dagger}\})$$

$$= \int dx_{0}^{\dagger} \int d[x^{\dagger}(\tau)]p_{0}(x_{0})p[x(\tau)|x_{0}] \exp[-R]g(\{S_{\alpha}\})$$

$$= \int dx_{0} \int d[x(\tau)]p_{0}(x_{0})p[x(\tau)|x_{0}] \exp[-R]g(\{S_{\alpha}\})$$

$$= \langle g(\{S_{\alpha}[x(\tau)]\}) \exp(-R[x(\tau)])\rangle$$
(78)

for any function g depending on an arbitrary number of such functionals  $S_{\alpha}$ . For the second equality, we use the definitions (71) and the parity relation (77); for the third we recognize that summing over all daggered trajectories is equivalent to summing over all original ones both for  $x^{\dagger}(\tau) = x(\tau)$  and  $x^{\dagger}(\tau) = x(t-\tau)$ . With the choice  $g \equiv 1$ , this FT leads to the most general IFT  $\langle e^{-R} \rangle = 1$  from which all known IFT-like relations follow as shown in Sect. 4.3.

By choosing for g the characteristic function, one obtains a generalized FT for joint probabilities in the form

$$\frac{p^{\dagger}(\{S_{\alpha}^{\dagger} = \epsilon_{\alpha} s_{\alpha}\})}{p(\{S_{\alpha} = s_{\alpha}\})} = \langle \exp(-R) | \{S_{\alpha}\} = \{s_{\alpha}\} \rangle$$
 (79)

that relates the pdf for the conjugate process to the pdf of the original one and a conditional average. All known DFTs for stochastic dynamics follow as special

cases of this general theorem as shown in Sect. 4.4. The key point is to (i) select the appropriate conjugate process for which the quantity of interest  $\Omega$  has a unique parity, which is most often just the reversed dynamics, (ii) identify for the generally free initial distribution  $p_0^{\dagger}(x)$  an appropriate function, and (iii) express the functional R using physical quantities, preferentially the quantity of interest  $\Omega$ .

## 4.3. General IFTs

The simplest choice for the function g in (78) is the identity, g = 1, leading to the IFT  $\langle e^{-R} \rangle = 1$ . Explicitly, one obtains for the three types of conjugate dynamics:

(i) By choosing the reversed dynamics (72) and with (73), the class of IFTs

$$\left\langle \frac{p_1(x_t)}{p_0(x_0)} \exp[-\Delta s^{\mathrm{m}}] \right\rangle = 1 \tag{80}$$

follows for any initial condition  $p_0(x_0)$ , any length of trajectories t, and any normalized function  $p_1(x_t) = p_0^{\dagger}(x_t)$  [20]. By specializing the latter to the solution of the Fokker-Planck equation for  $\tau = t$  one obtains the IFT for total entropy production (64).

For a system in a time-dependent potential  $V(x,\lambda)$  and by starting in an initial distribution given by the corresponding Boltzmann factor,  $p_0(x) = \exp[-(V(x,\lambda_0) - \mathcal{F}(\lambda_0))/T]$ , one obtains the JR (58) for the choice  $p_1(x_t) = \exp[-(V(x,\lambda_t) - \mathcal{F}(\lambda_t))/T]$  corresponding to the Boltzmann distribution for the final value of the control parameter.

A variety of "end-point" relations can be generated from (80) as follows. By choosing  $p_1(x) = p(x,t)g(x)/\langle g(x_t)\rangle$ , one obtains

$$\langle g(x_t) \exp[-\Delta s^{\text{tot}}] \rangle = \langle g(x_t) \rangle$$
 (81)

for any function g(x) [84]. Likewise, for  $f \equiv 0$  and  $V(x, \lambda(\tau))$ , by choosing  $p_1(x) = g(x) \exp[-(V(x, \lambda_t) - \mathcal{F}(\lambda_t))/T]/\langle g(x) \rangle_{\lambda_t}^{\text{eq}}$ , one obtains

$$\langle g(x_t) \exp[-(w - \Delta \mathcal{F})/T] \rangle = \langle g(x) \rangle_{\lambda}^{\text{eq}}$$
 (82)

which has been first derived by Crooks [9]. Here, the average on the right hand side is the equilibrium average at the final value of the control parameter. In the same fashion, one can derive

$$\langle g(x_t) \exp[-w^{\text{ex}}/T] \rangle = \langle g(x) \rangle_{\lambda_0}^{\text{eq}}$$
 (83)

by choosing  $p_1(x) = g(x) \exp[-(V(x,\lambda_0) - \mathcal{F}(\lambda_0))]/T]/\langle g(x)\rangle_{\lambda_0}^{\text{eq}}$  for a time-independent potential and arbitrary force  $f(x,\tau)$  which is the end-point relation corresponding to the BKR (60). The latter follows trivially by choosing  $g(x_t) = 1$ .

For processes with feedback control as discussed in Sect. 7.3 below, it will be convenient to exploit the end-point conditioned average

$$\left\langle \frac{1}{p_0(x_0)} \exp[-\Delta s^{\mathrm{m}}] \mid x_t = x \right\rangle p(x, t) = 1 \tag{84}$$

valid for any x which follows from (80) by choosing  $p_1(x_t) = \delta(x_t - x)$ . Equivalently, by choosing  $p_1(x,t) = p(x,t)$ ,

$$\int dx_0 \langle \exp[-\Delta s^{\mathrm{m}}] p(x_t, t) | x_0 \rangle = 1$$
 (85)

holds for summing over the initial point conditioned average.

(ii) By using the dual dynamics with p † 0 (x0) = p0(x0), the IFT for the housekeeping heat [78]

$$\langle \exp[-q^{hk}/T] \rangle = 1 \tag{86}$$

valid for any initial distribution follows.

(iii) For the dual-reversed dynamics, one gets the class of IFTs from

$$\left\langle \frac{p_1(x_t)}{p_0(x_0)} \exp[-q^{\text{ex}}/T] \right\rangle = 1 \tag{87}$$

valid for any initial distribution p0(x0) and any normalized function p1(xt). By choosing p0(x0) = exp[−φ(x0, λ0)] and p1(xt) = exp[−φ(xt, λt)], one obtains the Hatano-Sasa relation (66). Similarly, another class of end-point relations could be generated starting from (87).

Finally, since the IFTs, hexp[−Ω]i = 1, do not explicitly involve the conjugate process, one might wonder whether they can be derived in an alternative way. Indeed, some of them can be obtained by deriving an appropriate Fokker-Planck-type equation for the joint pdf p(Ω, x, τ) and then showing ∂<sup>τ</sup> he <sup>−</sup>Ωi = ∂<sup>τ</sup> R dΩ R dx e<sup>−</sup><sup>Ω</sup>p(Ω, x, τ) = 0 directly, see for the Jarzynski relation [7], for the house-keeping heat [78], and for another large class of IFTs [79].

## 4.4. FTs derived from time-reversal

In this section, the FTs following from using time-reversal as conjugate dynamics are derived systematically from (79) by specializing to the various scenarii concerning initial conditions and type of driving. More or less reversing the chronological development, we start with the more general cases and end with the more specific ones, for which the strongest constraints on these pdfs follow.

4.4.1. CFTs involving reversed dynamics By starting both, original and reversed dynamics, in the respective stationary state, the functional R becomes

$$R = \Delta \phi + \Delta s^{\mathrm{m}}. ag{88}$$

Hence, one gets from (79) the FT

$$\frac{p^{\dagger}(\{S_{\alpha}^{\dagger} = \epsilon_{\alpha} s_{\alpha}\})}{p(\{S_{\alpha} = s_{\alpha}\})} = \langle e^{-(\Delta \phi + \Delta s^{\mathrm{m}})} | \{S_{\alpha}\} = \{s_{\alpha}\} \rangle.$$
 (89)

For the special case that P <sup>α</sup> S<sup>α</sup> = ∆φ + ∆s <sup>m</sup>, this relation has first been derived by Garcia-Garcia et al. [85]. Note that in general the change in stochastic entropy ∆s is not an admissible choice for S<sup>α</sup> since it lacks definite parity under time-reversal.

By choosing for S<sup>α</sup> the work w, one gets

$$p^{\dagger}(-w) = p(w)\langle e^{-(\Delta\phi + \Delta s^{\mathrm{m}})}|w\rangle. \tag{90}$$

From this relation, the Crooks FT (57) follows for a time-dependent V (x, λ(τ)) and f = 0, if one samples both processes from the respective initial equilibria, since then ∆φ = ∆(V − F)/T and hence R = (w − ∆F)/T .

Likewise, by choosing S<sup>α</sup> = w χA(x0)χb(xt), where χA,B ≡ 1(0) if x ∈ (∈/)A, B are the characteristic functions of two regions A and B, one obtains the variants derived

and discussed in [86, 87] which allow to extend the CFT to "partially equilibrated" initial and final states. These variants have become useful in recovering free energy branches in single molecule experiments.

As another variant, by choosing for  $S_{\alpha}$  the work  $w^{\rm ex}$  and by starting the reverse process in the initial equilibrium, one gets with  $\Delta \phi = \Delta V^0$  and  $R = (\Delta V^0 + q)/T = w^{\rm ex}$  the Crooks relation for  $w^{\rm ex}$  [65]

$$p^{\dagger}(-w^{\text{ex}})/p(w^{\text{ex}}) = \exp[-w^{\text{ex}}/T]. \tag{91}$$

4.4.2. DFTs for symmetric and periodic driving For symmetric driving,  $\lambda(\tau) = \lambda(t-\tau)$ , and for  $p_0^{\dagger}(x_0^{\dagger}) = p_0(x_0)$ , the reversed dynamics becomes the original one. Hence, the FTs (89,90) derived in the previous subsection remain valid in this case if one replaces  $p^{\dagger}$  on the left hand side with p. In this case, as in those in the following subsections, the FTs no longer involve the conjugate dynamics explicitly which thus has become a mere mathematical tool to derive these relations most efficiently. In particular, for starting in the initial equilibrium, R = w/T and one gets for the pdf of work [88, 89]

$$p(-w)/p(w) = \exp[-w/T]. \tag{92}$$

Likewise, for a periodically driven system with an integer number of symmetric periods of length  $t_p$ , i.e.,  $\lambda(t_p - \tau) = \lambda(\tau)$ , the reversed dynamics is the original one. If the distribution has settled into a periodic stationary state, one has the DFT-like relation for total entropy production [90, 91]. Note that it is crucial to choose not only a periodic but also a symmetric protocol since otherwise the reversed dynamics is not the original one.

4.4.3. SSFTs for NESSs For a NESS, i.e., for time-independent driving and starting in the stationary state, the reversed dynamics becomes the original one and thus  $R = \Delta s^{\text{tot}}$ . Then (79) implies the generalized SSFT for joint probabilities in the form

$$\frac{p(\{S_{\alpha} = \epsilon_{\alpha} s_{\alpha}\})}{p(\{S_{\alpha} = s_{\alpha}\})} = \langle e^{-\Delta s_{\text{tot}}} | \{S_{\alpha}\} = \{s_{\alpha}\} \rangle.$$
(93)

For this case, system entropy is indeed odd, and hence one also has, in particular, by choosing  $S_{\alpha} = \Delta s^{\text{tot}}$  the genuine SSFT (65) for total entropy production and arbitrary length t. As variants, illustrating the potency of the general theorem, one easily gets from (93)

$$p(-\Delta s) = p(\Delta s)e^{-\Delta s} \langle e^{-\Delta s^{m}} | \Delta s \rangle$$
(94)

and

$$p(-\Delta s^{\rm m}) = p(\Delta s^{\rm m})e^{-\Delta s^{\rm m}}\langle e^{-\Delta s}|\Delta s^{\rm m}\rangle$$
(95)

involving conditional averages. Such relations seem not to have been explored in specific systems yet.

4.4.4. Expression for the NESS distribution By using an initial and end-point conditioned variant of (79), Komatsu et al. manage to express the stationary distribution  $p^s(x)$  in a NESS by non-linear averages over the difference in "excess" heat required either to reach x from the steady state or to reach the NESS starting in x [92, 93, 94] which leads to Clausius-type relations for NESSs [95]. For a related expression for  $p^s(x)$  in terms of an expansion around a corresponding equilibrium state, see [96] which contains a valuable introduction into the history of such approaches.

4.4.5. Transient fluctuation theorems TFTs This relation applies to time-independent driving and arbitrary initial condition  $p_0(x_0)$ . If the reversed dynamics is sampled using the same initial condition,  $p_0^{\dagger}(x_0^{\dagger}) = p_0(x_0)$ , then the functional R becomes

$$R = -\ln[p_0(x_t)/p_0(x_0)] + q/T \equiv \Omega_t \tag{96}$$

which has been called dissipation functional by Evans and Searles [37]. Physically,  $\Omega_t$  corresponds to the log-ratio between the probability to observe the original trajectory and the one for observing the time-reversed one. Since under these conditions  $\Omega_t$  is odd and the reversed dynamics is equivalent to the original one, one has from (79) the TFT

$$p(-\Omega_t)/p(\Omega_t) = \exp[-\Omega_t] \tag{97}$$

valid for any length t and initial condition.

If the system is originally equilibrated in a potential  $V_0(x)$  and then suddenly subject to either another time-independent potential  $V_1(x)$  or a force f(x) the dissipation functional becomes

$$\Omega_t = V_0(x_t) - V_1(x_t) + V_1(x_0) - V_0(x_0), \tag{98}$$

or  $\Omega_t = w$ , respectively. In the latter case, the TFT holds for work.

#### 4.5. FTs for variants

- 4.5.1. FTs for underdamped motion For underdamped motion as introduced in Sect. 2.6.1, the functional  $R_1$  defined in (71) under time-reversal is still given by the dissipated heat, i.e., by (39) integrated over the trajectory [97]. This fact follows by directly evaluating the action for the path integral corresponding to the underdamped Langevin equation (38). Hence, all FTs based on time-reversal hold true also for underdamped dynamics with the obvious modification that initial (and daggered) distributions now depend on x and y.
- 4.5.2. FTs in the presence of external flow—In the presence of flow, one has to specify how the flow changes in the conjugate dynamics. For genuine time-reversal, the physically appropriate choice is  $\mathbf{u}(\mathbf{r})^{\dagger} = -\mathbf{u}(\mathbf{r})$  which leads with the definitions of work and heat (47,48) to an odd parity for these two functionals. Consequently, the FT's then hold as in the case without flow. Formally, however, one could also keep the flow unchanged for the conjugate dynamics,  $\mathbf{u}(\mathbf{r})^{\dagger} = \mathbf{u}(\mathbf{r})$ , which would lead to another class of FTs. For a specific example illustrating this freedom, see the discussion in [59] for a dumbell in shear flow first investigated in [98].
- 4.5.3. FT with magnetic field In the presence of a (possibly time-dependent) magnetic field, the FTs hold true essentially unchanged as proven in great generality for the JR and the CFT for interacting particles on a curved surface [99]. This work generalized earlier case studies on the validity of the JR for specific sitations involving a magnetic field as mentioned in Sect. 5.2 below. A second motivation for this work was to refute earlier claims based on simulations that the Bohr-van-Leeuven theorem stating the absence of classical diamagnetism could fail for a closed topology [100].

4.5.4. Further "detailed theorems" Esposito and van der Broeck have derived what they call detailed fluctuation theorems for ∆s tot , ∆s hk , (called "adiabiatic" entropy change ∆s ad) and for the "non-adiabiatic" entropy change ∆s na ≡ ∆s ex + ∆s under even more general conditions [101, 102, 103]. Their relations are beyond the realm of the present systematics since they compare the pdf for different physical quantities for the original and the conjugate process whereas we always compare the pdfs of the same physical quantities.§ A unification of FTs within this broader sense involving joint distributions of these decompositions of entropy production is achieved in [104] and a generalization of the Hatano-Sasa relation in [105].

#### 4.6. FTs for athermal systems

4.6.1. General Langevin systems The derivation of the master FT in Sect. 4.2 shows that for obtaining these mathematical relations the main requirement is the existence of a conjugate dynamics such as time reversal. Therefore, imposing a relation between the strength of the noise and the mobility as done in Sect. 2.1 for colloidal particles is not really necessary. Neither is it necessary to interpret the Langevin equation using concepts of work and heat. We therefore sketch in this section the general FT for a system of Langevin equations

$$\dot{\mathbf{x}} = \mathbf{K}(\mathbf{x}, \lambda) + \boldsymbol{\zeta} \tag{99}$$

with arbitrary "force" K and noise correlations

$$\langle \boldsymbol{\zeta}(\tau) : \boldsymbol{\zeta}(\tau') \rangle = 2\underline{D}\delta(\tau - \tau').$$
 (100)

The corresponding Fokker-Planck equation becomes

$$\partial_{\tau} p(\mathbf{x}, \tau) = -\nabla \mathbf{j} = -\nabla (\mathbf{K} p - \underline{\underline{D}} \nabla p)$$
 (101)

and the local (probability) current j(x, λ). For constant λ, one has the local mean velocity

$$\mathbf{v}^{s}(\mathbf{x}, \lambda) \equiv \mathbf{j}^{s}(\mathbf{x}, \lambda)/p^{s}(\mathbf{x}, \lambda) = \mathbf{K}(\mathbf{x}, \lambda) - \underline{\underline{D}} \nabla \ln p^{s}.$$
 (102)

For time reversal as conjugate dynamics, by evaluating the corresponding weight one obtains for the master functional (73)

$$R_1 = \int_0^t d\tau \dot{\mathbf{x}} \underline{\underline{D}}^{-1} \mathbf{K} \equiv \Delta s^{\mathrm{m}}$$
 (103)

where the identification with ∆s <sup>m</sup> is now purely formal. If one adds the stochastic entropy change along a trajectory

$$\Delta s \equiv -\ln[p(\mathbf{x}_t, \lambda_t)/p(\mathbf{x}_0, \lambda_0)] \tag{104}$$

one obtains the total entropy production ∆s tot. Likewise, in analogy to the colloidal case, ∆s <sup>m</sup> can be split into

$$\Delta s^{\rm hk} \equiv \int_0^t d\tau \dot{x} \underline{\underline{D}}^{-1} \mathbf{v}^s \tag{105}$$

and

$$\Delta s^{\text{ex}} \equiv \Delta s^{\text{m}} - \Delta s^{\text{hk}} = \int_0^t d\tau \dot{\mathbf{x}} \nabla \ln p^s = -\Delta \phi + \int_0^t d\lambda \dot{\lambda} \partial_{\lambda} \phi.$$
 (106)

§ The IFT hexp[−∆s na]i = 1, however, follows directly from (87) by choosing p1(xt) = p(x, t).

With these identifications all FTs involving the various forms of entropy production derived and discussed in Sects. 3.3 and 4 hold true for such Langevin systems as well.

The identification of a generalized work makes immediate sense only if K = −(D/T )∇V (x, λ) with some potential V (x, λ) and effective temperature T in which case one is back at the thermal model with interacting degrees of freedom introduced in Sect. 2.6.2. If K cannot be derived in this way from a gradient field there seems to be no gain by trying to impose a genuine thermodynamic interpretation without further physical input.

4.6.2. Stochastic fields The generalization of the results in the previous section for coupled Langevin equations to stochastic field equations is trivially possible [21]. Consider a scalar field Ψ(r, τ) that obeys

$$\partial_{\tau}\Psi(\mathbf{r},\tau) = K[\Psi(\mathbf{r},\tau),\lambda(\tau)] + \zeta(\mathbf{r},\tau)$$
(107)

with some functional K[Ψ(r, τ), λ(τ)] and

$$\langle \zeta(\mathbf{r}, \tau) \zeta(\mathbf{r}', \tau') \rangle = 2D(\mathbf{r} - \mathbf{r}')\delta(\tau - \tau').$$
 (108)

with arbitrary spatial correlation D((r − r ′ ). The expressions for the entropy terms can easily be inferred; e.g., the analogy of the entropy change in the medium becomes

$$\Delta s^{\rm m} \equiv \int_0^t d\tau \int d\mathbf{r} \int d\mathbf{r}' \partial_\tau \Psi(\mathbf{r}, \tau) D^{-1}(\mathbf{r} - \mathbf{r}') K[\Psi(\mathbf{r}', \tau), \lambda(\tau)]. \tag{109}$$

By now, it should be obvious how to derive the corresponding FTs and how to generalize all these also to the case when Ψ(r, τ) is a multi-component field. Likewise, it would be a trivial task to specialize all this to driven or relaxing "thermal" field theories for which K includes the derivative of some Landau-Ginzburg type free energy and where the noise obeys an FDT [106].

An interesting applications concerns enstrophy dissipation in two-dimensional turbulence [107]. Field-theoretic techniques are used in [108] to derive generalized JRs and to explore the role of super-symmetry in this context. Quite generally, it will be interesting to investigate stochastic versions of the field equations of active matter [109] from this perspective.

4.6.3. FTs in evolutionary dynamics The framework of FTs has recently been applied to the stochastic evolution of molecular biological systems where it leads to an IFT for fitness flux [110].

## 5. Experimental, analytical and numerical work for specific systems with continuous degrees of freedom

#### 5.1. Principal aspects

The various relations derived and discussed above have the status of mathematically exact statements. As such they require neither a "test" nor a "verification". The justification for, and the value of, the large body of experimental and numerical work that appeared in this field during the last decade rather arises from the following considerations.

First, experimental and numerical measurements of the distributions p(Ω) entering the theorems provide non-trivial information about the specific system under consideration. Integral and detailed theorems give only one constraint on, and constrain only one half of, the distribution, respectively. Beyond the constraints imposed by the exact relations, the distributions are non-universal in particular for short times.

Second, the theorems involve non-linear averages. The necessarily limited number of data entering experimental or numerical estimates can cause deviations from the predicted exact behavior. It is important to get experience how large such statistical errors are. Systematic theoretical investigations concerning the error due to finite sampling are mentioned in Sect. 9.3 below.

Third, the thermodynamic interpretation of the mathematical relations in terms of work, heat and entropy rests on the crucial assumption that the noise in the Langevin equation is not affected by the driving. While this condition can trivially be guaranteed in simulations, it could be violated in experiments. A statistically significant deviation of experimental results from a theoretical prediction could be rooted in the violation of this assumption.

These remarks apply to systems where one expects at least in principle that a stochastic description of the relevant degrees of freedom well-separated in time-scale from an equilibrated heat bath is applicable. There are, however, systems that a priori do not belong to this class like sheared molecular fluids, shaken granular matter and alike. The proof of fluctuation theorems given above will not apply to such systems. Still, fluctuation theorems have been proved for other types of dynamics and experimentally investigated in such systems.

In the following we first focus on a review of experimental and numerical work of the first category and then briefly mention systems for which it is less clear whether they comply with the assumptions of a stochastic dynamics. When refering to the experiments and the numerical work, we will use the notions and notations established in this review, which may occasionally differ from those given by the original authors.

#### 5.2. Overdamped motion: Colloidal particles and other systems

5.2.1. Equilibrium pdf for heat Even in equilibrium, explicit calculations of the pdf for heat are typically non-trivial. In the long time t → ∞, low temperature T → 0 limit, it has been calculated for an arbitrary potential with multiple minima [111]. For a harmonic potential and any t and T , it is given by an expression involving a Bessel function [112]. It has also been derived analytically in the presence of a magnetic field [113].

5.2.2. Moving harmonic traps and electric circuits Wang et al. [114] measured the distribution of what amounts to work (called Σ<sup>t</sup> in their eq. 2) for a colloidal particle initially in equilibrium in a harmonic trap which was then displaced with constant velocity. The authors found that the pdf obeys a relation corresponding to the TFT which is strictly speaking the correct interpretation only within the co-moving frame. Interpreted in the lab frame, the driving is time-dependent. However, since for linear forces the work distribution is a Gaussian which moreover has to obey the JR with ∆F = 0, it is clear that such a Gaussian also obeys the TFT formally.

In a sequel, Wang et al. [115] considered the same set-up for a quasi-steady state situation at constant velocity. The authors showed in particular that a quantity (Ωt(r)

as defined in their eq. 19) which is equal to ∆s tot obeys the DFT also for short times as it should since this set-up seen in the co-moving frame corresponds to a genuine NESS.

For traps moving with constant velocity, explicit expressions for the Gaussian work distribution, i.e. for its mean and variance, have been calculated in [66, 116]. In all cases, the DFT type relation is fulfilled. In contrast, the pdf for the dissipated heat is non Gaussian (essentially because it involves the distribution of (x<sup>t</sup> − λt) 2 from the internal energy) with exponential tails. An explicit expression is not available, but its characteristic function and in consequence its large deviation form can be determined analytically [117, 118]. The pdf for work in a moving trap (and the pdf for heat in a stationary trap) were also measured and compared to theoretical results by Imparato et al. [119]. For a harmonically bound particle subject to a time-dependent force, Saha et al. calculated pdfs for total entropy production, in particular, for non-equilibrated initial conditions [120].

For a charged particle in a harmonic trap, work fluctuations and the JR have been studied theoretically for a time-independent magnetic field and a moving trap or time-dependent electric field in [121, 122, 123, 124, 125], and for a time-dependent magnetic field in [126], respectively.

Trepagnier et al. [77] studied experimentally the transition from one NESS to another by changing the speed of the moving trap. If interpreted in the co-moving frame, their experiment constituted the first experimental verification of the Hatano-Sasa relation (66).

Simple electric circuits can formally be mapped to the dragged colloidal particle. Corresponding FTs and pdfs have been investigated by Ciliberto and co-workers in [127, 128, 129], by Falcon and Falcon in [130] and by Bonaldi et al. [131] for actively cooled resonators used in a gravitational wave detector. A similar mapping was used by Berg to study the JR applied to gene expression dynamics [132].

- 5.2.3. Harmonic traps with changing stiffness Carberry et al. [133] investigated the motion of a colloidal particle in a harmonic trap whose stiffness is suddenly changed from one value to another. They thus verified the TFT (97) for Ω<sup>t</sup> given by (98). For strongly localized initial conditions, this TFT has been verified experimentally in [134]. Gomez-Solano et al. inferred the fluctuations of the heat exchanged between a colloidal particle and an ageing gel which bears some similarity to a time-dependent stiffness [135].
- 5.2.4. Non-linear potentials Blickle et al. [136] measured the work distribution for a colloidal particle pushed periodically by a laser towards a repulsive substrate. This experimental set-up was the first one for colloidal particles that used effectively nonharmonic potentials. The pdf for work is distinctly non-Gaussian but still in good agreement with theoretical predictions based on solving the Fokker-Planck equation. This agreement justifies a posteriori the crucial assumption that the noise correlations are not affected by the time-dependent driving. Moreover, a DFT for p(w) (92) was checked for this periodic driving with a symmetric protocol. Sun determines p(w) for a potential that switches between a single well and a double well [137].
- 5.2.5. Stochastic resonance For a colloidal particle in a double well potential that is additionally subject to a modulated linear potential to generate conditions of

![](_page_33_Figure_1.jpeg)

Figure 2. Distribution of entropy production p(∆s tot) for a colloidal particle driven along a periodic potential for two different values of external force f[144]. The insets show the total potential v(x) − fx. The different histograms refer to different trajectory lengths.

stochastic resonance [138], distributions for work, heat and entropy were measured and calculated in [139, 140]. Other numerical work using the concepts of stochastic thermodynamics to investigate stochastic resonance includes [141, 142, 143].

5.2.6. NESS in a periodic potential In an experiment for this paradigmatic geometry shown in Fig. 1 which correspond to the Langevin equation (1), the pdf for total entropy production has been measured and compared to theoretical predictions [144], see Fig 2. Characteristically, for short times, this pdf exhibits several peaks corresponding to the number of barriers the particle has surmounted. Examples for the pdf for entropy production have also been calculated in [145]. For long times, the asymptotic behaviour of this pdf in the form of a large deviation function has been calculated numerically in [146] where an interesting kink-like singularity was found. The same quantity has also been derived using a variational principle [147].

## 5.3. Underdamped motion

5.3.1. Torsion pendulum as experimental realization A driven torsion pendulum differs fundamentally from colloidal particles since here the inertia term becomes accessible. In a series of experiments reviewed in [35], Ciliberto and co-workers have investigated the pdf for various quantities with the aim of checking which ones obey FT like relationships.

In [148, 149], the JR and the Crooks relation were used to determine the "free energy difference" for the torsion pendulum for linear and periodic forcing. In [150], pdfs for the external work were determined for three different types of protocols for the time-dependent force in (38). (i) For a linearly ramped force, the pdf for starting in equilibrium was found to obey a TFT relation even for short times. Since a linear ramp corresponds to a time-dependent driving, one would, in fact, not expect a TFT. It is found here only because the work distribution for this linear system is Gaussian

and should obey the JR which constrains mean and variance such that the TFT is valid. Alternatively, an explicit calculation of the pdf shows the same result. (ii) Starting in a quasi-steady state of the linear ramp, the pdf for w ex no longer obeys the TFT for short times as expected. (iii) Likewise, for periodic driving, a DFT type for the work distribution is found only in the long time limit as expected. For the latter two cases, the finite time corrections have been calculated.

The same group investigated the pdf for the heat for similar protocols [151]. In agreement with both the general theoretical expectations and their explicit calculations the pdf for heat does neither obey a TFT for short times nor even the DFT asymptotically for long times since the internal energy is not bounded for an harmonic oscillator.

The pdf for changes in the stochastic entropy and the total one were reported for periodic driving of this system in [129]. Once the system has settled in the periodic steady state, for an integer multiple of the period the functional R becomes the total entropy change which thus fulfills a DFT as found experimentally.

5.3.2. General theoretical results Using path integral techniques, Farago determined the statistics of the power injected by the thermal forces into an underdamped particle and found it to be independent of an underlying confining potential [152].

In a series of papers for a moving trap, Taniguchi and Cohen investigated pdfs for work and heat as well as various FTs using the path integral representation [153, 154, 155, 156]. They also point out the ambiguity (or freedom) to define timereversal in this particular system.

For both a moving and a breathing trap, Minh et al. calculated work weighted propagators for underdamped motion [157]. FTs for underdamped Brownian motion were studied by Lev and Kiselev by transforming from the momentum to the energy variable [158], by Fingerle for the relativistic version [159] and by Iso et al. for motion near black holes [160]. Sabhapandit determined the work fluctuations of a randomly driven harmonic oscillator [161] which was studied experimentally in [162]. FTs for underdamped motion in the presence of two heat baths were investigated in [163, 164, 165].

## 5.4. Other systems

Ever since the DFT for entropy production has been formulated, there have been attempts to show whether it is fulfilled in a specific system both numerically and experimentally. Beyond the "clean" cases discussed above for which the dynamics of the relevant degrees of freedom is clearly compatible with a stochastic Markovian dynamics, there are a number of studies for other system where a theoretical understanding is more challenging. Such studies include an early theoretical work with three simple dissipative deterministic models [166], experimental [167, 168, 169, 170] and numerical [171, 172, 173, 174, 175, 176, 177, 178] work for granular matter or dense colloids, experimental work for turbulence [179, 180, 181], numerical work for a shell model in turbulence [182] and one on the role of hydrodynamic interactions [183], and experimental work for liquid crystals [184, 185], a vibrating plate [186], and self-propelled particles [187]. Characteristically for the experimental systems just mentioned, one cannot necessarily expect that these can be described by a stochastic Markovian dynamics for the relevant variables. Similarly, in the numerical works either the equations of motion are not of the Langevin type (or deterministic thermostatted

![](_page_35_Figure_1.jpeg)

Figure 3. Network with five states comprising three cycles (1245), (234), and (12345) and the corresponding transition rates. Without the state 3, this network would be a unicyclic one.

ones) or, if they are, not all variables are monitored which effectively amounts to some coarse-graining. Since for these cases, the FT's have not been proven, such tests give valuable hints on possible extensions beyond their established realm of validity.

Two general aspects for putting results of such case studies in perspective are the following ones. First, the putative validity of a DFT for the quantity R is typically cast in the form of checking for a constant slope of the quantity limt→∞[ln[p(ρt)/p(−ρt)]/t where ρ<sup>t</sup> is the time averaged rate corresponding to the quantity R = tρ<sup>t</sup> for which we have formulated the FT. Since such a plot is necessarily asymmetric in ρ<sup>t</sup> [172], for a non-trivial statement the contribution of higher order terms like ρ 3 <sup>t</sup> must be shown to be negligible which requires a large enough range of studied ρt-values. Moreover, a large enough t is necessary. Second, in bulk systems often only "local" quantities can be investigated which would require local forms of the FT's. From the perspective of a stochastic dynamics, this amounts to integrating out other slow degrees of freedom or some type of coarse-graining under which one can not expect the FT's to hold necessarily. We will come back to this issue at the very end of this review.

## 6. Dynamics on a discrete set of states

## 6.1. Master equation dynamics

The derivation of the FTs in Sect. 4 is based on the behavior of the weight for a stochastic trajectory under time reversal or the other operations generating the conjugate dynamics. Therefore, they hold for any kind of stochastic dynamics, in particular, for a master equation type of dynamics [188, 189] on a discrete set of states {n}, see Fig. 3.

Examples of such systems include random walks and, more generally, diffusive processes on a lattice, birth-death processes, growth processes on a lattice, conformational changes between discrete states of a biomolecule or chemical reaction networks. The latter two classes of systems differ from the previous ones since they typically occur in a well-defined thermal environment. This feature imposes additional constraints on the dynamics as discussed in Sect. 9 below. In this section, we focus on the stochastic dynamics with arbitrary transition rates.

6.1.1. Transition rates and probability currents Transitions from a state m to a state n occur with a rate wmn(λ) which may be time-dependent according to the external protocol λ(τ). For ease of notation, we will write wmn(τ) or wmn(λ) for the

more explicit  $w_{mn}(\lambda(\tau))$ . In principle, one could distinguish different transitions or "channels" connecting the same two states from which we refrain here for notational simplicity.

The probability  $p_n(\tau)$  to find the system at time  $\tau$  in state n evolves according to the master equation

$$\partial_{\tau} p_n(\tau) = \sum_{m \neq n} [w_{mn}(\tau) p_m(\tau) - w_{nm}(\tau) p_n(\tau)]$$
(110)

given an initial distribution  $p_n(0)$ . To each link (mn) one can associate a (directed) probability current

$$j_{mn}(\tau) = p_m(\tau)w_{mn}(\tau) - p_n(\tau)w_{nm}(\tau) = -j_{nm}(\tau). \tag{111}$$

6.1.2. Two classes of steady states For time-independent  $\lambda$ , the system eventually reaches a steady state provided the network is "ergodic", i.e., any two states are connected through a series of links as we will always assume in the following. The time-independent stationary probabilities can be written as

$$p_n^s(\lambda) \equiv \exp[-\phi_n(\lambda)] \tag{112}$$

which defines the analogue of the non-equilibrium potential. For small networks, there is an elegant graphical method to determine  $p_n^s$  from given rates [189, 190].

Steady states fall into two classes depending on whether or not the detailed balance condition (DBC),

$$p_n^s(\lambda)w_{nm}(\lambda) = p_m^s(\lambda)w_{mn}(\lambda),\tag{113}$$

is fulfilled. The first case corresponds to genuine equilibrium, the second one to a NESS. In the latter case, there are non-vanishing steady state probability currents

$$j_{mn}^{s} \equiv p_{m}^{s} w_{mn} - p_{n}^{s} w_{nm} = -j_{nm}^{s}. \tag{114}$$

Since knowing  $p_n^s$  is not sufficient to distinguish a genuine equilibrium from a NESS, Zia and Schmittmann [191, 192] suggested to characterize a NESS by its stationary distribution  $p_n^s$  and its stationary currents  $j_{mn}^s$ . Then the same NESS could be generated by a whole equivalence class of possible rates  $w_{mn}$  since any two sets of rates with

$$p_m^s(w_{mn} - w'_{mn}) = p_n^s(w_{nm} - w'_{nm})$$
(115)

would lead to the same NESS, i.e., the same stationary distribution and currents. In the following, we will adapt the view that a system is characterized by a definite set of rates  $w_{mn}(\lambda)$  and a protocol  $\lambda(\tau)$  from which all other quantities can, in principle, be derived.

A "distance" from equilibrium quantifying the amount of violation of the DBC has been introduced in [198]. A Lyapunov function for relaxation towards a NESS is discussed in [199]. Master equation dynamics as a gauge theory is formulated in [200].

![](_page_37_Figure_1.jpeg)

**Figure 4.** Trajectory  $n(\tau)$  of total length t jumping at discrete times  $\{\tau_j\}$  between states.

6.1.3. Path weight and dynamical action We first characterize the fluctuating trajectories. A trajectory  $n(\tau)$  with  $0 \le \tau \le t$  starts at  $n_0$  and jumps at times  $\tau_j$  from  $n_j^-$  to  $n_j^+$  ending up at state  $n_t$  after J jumps, see Fig. 4. Defining for each state the instantaneous total exit rate

$$r_n(\tau) \equiv \sum_{m \neq n} w_{nm}(\tau) \tag{116}$$

the conditional weight for a trajectory exhibiting no jump at all is given by

$$p[n(\tau) = n_0|n_0] = \exp[-\int_0^t d\tau \ r_{n_0}(\tau)]. \tag{117}$$

The weight for a trajectory with  $J \geq 1$  jumps at times  $\{\tau_j\}$  is given by

$$p[n(\tau)|n_0] = \exp\left[-\int_0^{\tau_1} d\tau \ r_{n_0}(\tau)\right] \times$$

$$\prod_{j=1}^J w_{n_j^- n_j^+}(\tau_j) \exp\left[-\int_{\tau_j}^{\tau_{j+1}} d\tau \ r_{n_j^+}(\tau)\right]$$
(118)

with  $\tau_{J+1} \equiv t$ . Averages with these weights will be denoted by  $\langle ... \rangle$  in the following. In analogy with the continuous case (5), these expressions define an "action"

$$\mathcal{A}[n(\tau)] \equiv -\ln p[n(\tau)|n_0] = \int_0^{\tau_1} d\tau \ r_{n_0}(\tau)$$

$$- \sum_{j=1}^J \left[ \ln w_{n_j^- n_j^+}(\tau_j) - \int_{\tau_j}^{\tau_{j+1}} d\tau \ r_{n_j^+}(\tau) \right]. \tag{119}$$

## 6.2. Entropy production

6.2.1. Stochastic entropy The concept of stochastic entropy can be transferred immediately from the Langevin case to the discrete one as [20]

$$s(\tau) \equiv -\ln p_{n(\tau)}(\tau). \tag{120}$$

|| For completeness, we mention a complementary approach where rates are derived by imposing mean currents as constraints [193, 194, 195, 196]. For a relation to the minimum entropy production principle, see [197] and references therein.

It is obtained by first solving the master equation (110) for  $p_n(\tau)$  with a given initial distribution and then plugging into it the specific trajectory  $n(\tau)$  taken from this ensemble.

The equation of motion for stochastic entropy becomes

$$\dot{s}(\tau) = -\left. \frac{\partial_{\tau} p_n(\tau)}{p_n(\tau)} \right|_{n(\tau)} - \sum_{j} \delta(\tau - \tau_j) \ln \frac{p_{n_j} + (\tau_j)}{p_{n_j} - (\tau_j)}. \tag{121}$$

The first term shows that even if the system remains in the same state, stochastic entropy will change whenever the ensemble is time-dependent either due to a non-equilibrated initial state or due to time-dependent rates. The second term shows the contributions from each transition. The change in stochastic entropy during time t is given by

$$\Delta s = \int_0^t d\tau \dot{s}(\tau) = -\ln p_{n_t}(t) + \ln p_{n_0}(0). \tag{122}$$

6.2.2. Time reversal Time-reversal as a choice for the conjugate dynamics works analogously to the Langevin case with  $n^{\dagger}(\tau) = n(t-\tau)$  and  $\lambda^{\dagger}(\tau) = \lambda(t-\tau)$ . Using the weights (117,118), it is trivial to check that

$$R_1 \equiv \ln \frac{p[n(\tau)|n_0]}{p^{\dagger}[n^{\dagger}(\tau)|n_0^{\dagger}]} = \sum_j \ln \frac{w_{n_j^- n_j^+}(\tau_j)}{w_{n_j^+ n_j^-}(\tau_j)} \equiv \Delta s^{\mathrm{m}}.$$
 (123)

There are two justifications for identifying  $R_1$  with the entropy change of the surrounding medium  $\Delta s^{\rm m}$ . The first is the analogy to the Langevin case, where this term turned out to be the dissipated heat (divided by temperature). In the absence of a first law for the master equation dynamics, which would require further physical input not available at this general stage, this identification is by analogy only. Second, it turns out that the sum of the system entropy change as defined in (122) and the so identified medium entropy,

$$\Delta s^{\text{tot}} \equiv \Delta s + \Delta s^{\text{m}},\tag{124}$$

will have all the properties required from a total entropy production. From the expression (123) an instantaneous entropy production rate in the medium can be identified as

$$\dot{s}^{\mathrm{m}}(\tau) = \sum_{j} \delta(\tau - \tau_{j}) \ln \frac{w_{n_{j}^{-} n_{j}^{+}}(\tau_{j})}{w_{n_{j}^{+} n_{j}^{-}}(\tau_{j})}$$
(125)

that makes the contributions from the individual jumps obvious. Combining this relation with (121), one obtains

$$\dot{s}^{\text{tot}}(\tau) = -\left. \frac{\partial_{\tau} p_n(\tau)}{p_n(\tau)} \right|_{n(\tau)} + \sum_{j} \delta(\tau - \tau_j) \ln \frac{p_{n_j^-}(\tau_j) w_{n_j^- n_j^+}(\tau_j)}{p_{n_j^+}(\tau_j) w_{n_j^+ n_j^-}(\tau_j)}.$$
(126)

6.2.3. Ensemble level By averaging these trajectory-dependent contributions for entropy production, one obtains expressions derived much earlier within the ensemble approach [23, 189, 190, 201]. On a technical level, using

$$\left\langle \sum_{j} \delta(\tau - \tau_j) d_{n_j - n_j} + (\tau) \right\rangle = \sum_{mn} p_m(\tau) w_{mn}(\tau) d_{mn}(\tau)$$
 (127)

valid for any set of quantities  $\{d_{mn}\}\$ , one obtains

$$\dot{S}^{\text{tot}}(\tau) \equiv \langle \dot{s}^{\text{tot}} \rangle = \sum_{mn} p_m(\tau) w_{mn}(\tau) \ln \frac{p_m(\tau) w_{mn}(\tau)}{p_n(\tau) w_{nm}(\tau)}, \tag{128}$$

and

$$\dot{S}^{\mathrm{m}}(\tau) \equiv \langle \dot{s}^{\mathrm{m}} \rangle = \sum_{m} p_{m}(\tau) w_{mn}(\tau) \ln \frac{w_{mn}(\tau)}{w_{nm}(\tau)}$$
(129)

which should be compared with (35) and (36), respectively.

6.2.4. Splitting entropy production Following the Langevin case, we can split the entropy production in the medium (123) into two contributions

$$\Delta s^{\rm m} = \Delta s^{\rm hk} + \Delta s^{\rm ex} \tag{130}$$

with

$$\Delta s^{\text{hk}} \equiv \sum_{j} \ln \frac{p_{n_{j}^{-}}^{s}(\lambda_{j}) w_{n_{j}^{-} n_{j}^{+}}(\lambda_{j})}{p_{n_{j}^{+}}^{s}(\lambda_{j}) w_{n_{j}^{+} n_{j}^{-}}(\lambda_{j})}$$
(131)

where  $\lambda_j \equiv \lambda(\tau_j)$  and

$$\Delta s^{\text{ex}} \equiv -\sum_{j} \ln \frac{p_{n_{j}}^{s}(\lambda_{j})}{p_{n_{j}}^{s}(\lambda_{j})}$$

$$\tag{132}$$

characterizing the entropy change associated with maintaining the corresponding steady state and the one associated with time-dependent driving, respectively. It is simple to rewrite  $\Delta s^{\rm ex}$  as the discretized version of  $-\Delta \phi + \partial_{\lambda} \phi$  as in (23). This excess entropy production has a nice geometrical interpretation along a path in the parameter space analogous to the Berry phase in quantum mechanics [202].

A somewhat different splitting of total entropy production on the trajectory level was introduced in [101, 102, 103] writing

$$\Delta s^{\text{tot}} = \Delta s^{\text{ad}} + \Delta s^{\text{na}} \tag{133}$$

with the adiabatic entropy change  $\Delta s^{\rm ad} \equiv \Delta s^{\rm hk}$  and the non-adiabatic one  $\Delta s^{\rm na} \equiv \Delta s^{\rm ex} + \Delta s$ .

6.2.5. Dual dynamics The dual dynamics is defined by rates

$$w_{mn}^{\dagger}(\lambda) \equiv w_{nm}(\lambda) p_n^s(\lambda) / p_m^s(\lambda). \tag{134}$$

These rates lead to the same stationary state as the original dynamics,  $p_m^{\dagger s} = p_m^s$ . However, the stationary currents are reversed according to

$$j_{mn}^{\dagger s}(\lambda) = -j_{nm}^{s}(\lambda). \tag{135}$$

In complete analogy to the Langevin case, by comparing the weights for the original with the dual and the dual-reversed dynamics, one obtains

$$R_1 = \Delta s^{\mathrm{hk}}$$
 and  $R_1 = \Delta s^{\mathrm{ex}},$  (136)

respectively.

6.3. FTs for entropy production and "work"

6.3.1. General validity With these identifications, all FTs from Sects. 3.3 and 4 involving the various forms of entropy changes apply under exactly the same conditions as stated there provided the occasional x (and x0, xt) is trivially replaced by n (and n0, nt).

The only variable not defined yet is the analogue of work. For networks that at constant λ fulfill the DBC (113), one can identify a (dimensionless) internal energy as φn(λ) ≡ − ln p s n (λ) that plays the role of the potential V (x, λ)/T in the Langevin case with a free energy identical to zero. At this stage, there is indeed no point in identifying a non-trivial λ-dependent free energy. Consequently, work along a trajectory corresponds to dissipated work and can be identified in analogy to (15) with

$$w \equiv \int_0^t d\tau \ \partial_{\lambda} \phi_n(\lambda)_{|n(\tau)} \dot{\lambda}. \tag{137}$$

With this identification of work, the FTs from Sects. 3.2 and 4 involving work hold for this master equation dynamics as well (setting there T = 1). It should be stressed, however, that without a more physical microscopic understanding of the network, this concept of work (and heat, if one wanted to promote ∆s <sup>m</sup> to this status) is a purely formal one without real physical meaning.

For networks that do not fulfill the DBC (113), there is no unique way of assigning internal energy to a state without further physical input, and, hence, no sensible way of identifying work even formally. Naively keeping (137), as sometimes suggested [203], fails as the counter-example of a discretized version of the driven overdamped motion on a flat ring easily shows, since φ<sup>n</sup> = const implies w = 0.

The statistics of rare events contributing to these FTs can also be studied through a "mapping" of the master equation to a Schr¨odinger equation and then analyzing the corresponding path integral [204, 205]. Finally, a somewhat formal general IFT was derived in [206].

6.3.2. Experimental case studies Experimental work measuring the distributions of these quantities with the perspective of "testing" the FTs is yet scarce. The arguably simplest non-trivial network is a two-state system with time-dependent rates. Any such two-state system necessarily obeys the DB condition. Such a two-state system was realized experimentally by driving an optical defect center in diamond with two lasers. The distributions for work (137) and for the entropy change of system, medium and total, were measured and compared to the theoretical predictions [88, 90]. Characteristically, for comparably short times these distributions show quite intricate, distinctively non-Gaussian, features, see Fig. 5.

6.3.3. Analytical and numerical case studies Entropy production and the FT for the simplest discrete system which is in essence a random walk biased in one direction by applying an external field was studied in the context of a ratchet model in [207], for a rotary motor in [208, 209] and for transport through a membrane channel in [210]. Simple three and four state systems were investigated in [211, 212]. The statistics of dissipated heat for a driven two-level system modelling single electron transport has been calculated in [213].

Entropy production on a lattice model both for a simple reaction-diffusion scheme and for transport was investigated in [214] with an attempt to clarify the occurence

![](_page_41_Figure_1.jpeg)

**Figure 5.** Probability distribution for the "work" (137), denoted here R, in a driven two-level system for two different lengths of trajectories. The histogram are experimental data, the full curve a theoretical calculation, for more details, see [88].

of a kink in the rate function at zero entropy production. In another variant of the reaction-diffusion scheme, the violation of an FT caused by breaking microscopic reversibility in the sense that some backward transitions are forbidden were studied in [215, 216]. Entropy production for a model of cyclic population dynamics was investigated in [217] and for effusion of a relativistic ideal gas in [218].

The analogue of work distributions for a spin system in time-dependent magnetic fields was investigated in [219, 220] and for time-dependent coupling constants in [221]. The surface tension in the three-dimensional Ising model is determined through simulations using the analogy of the JR in [222].

The interplay between a non-equilibrium phase transition and singularities in the entropy production has been investigated for a majority vote model [223], for driven lattice gases [224, 225], for wetting [226] and for kinetically constrained lattice models [227].

#### 6.4. FT for currents

For a network in a NESS, currents obey an FT as first derived by Gaspard and Andrieux [228, 229, 230, 231] exploiting the decomposition of such a network in cycles as introduced by Schnakenberg [189] and using concepts from large deviation theory [232]. For a concise derivation of the current FDT using the formalism developed in Sect. 4, we write the total entropy production along a trajectory in the form

$$\Delta s^{\text{tot}} = \sum_{a} n_a \Delta S_a + \Delta s_r. \tag{138}$$

Here,  $n_a$  is the number of times a cycle a has been completed in clockwise  $(n_a > 0)$  or anti-clockwise  $(n_a < 0)$  direction during this trajectory leading to a fluctuating current  $\mathcal{J}_a \equiv n_a/t$  for each cycle, see Fig. 3 for an example of cycles in a network. The entropy production associated with each cycle

$$\Delta S_a = \sum_{(mn)\in a} \ln \frac{w_{mn}}{w_{nm}} \tag{139}$$

is also called the affinity of this cycle. The remainder  $\Delta s_r$  collects the contributions arising from those parts of the trajectory that do not contribute to a full cycle. Clearly, the current  $\mathcal{J}_a$  is uneven under time-reversal and hence qualifies as a possible variable  $S_{\alpha}$  with  $\epsilon_{\alpha} = -1$  for the general SSFT (93) which thus becomes

$$\frac{p(\{-\mathcal{I}_a\})}{p(\{\mathcal{I}_a\})} = \exp[-t\sum_a \Delta S_a \mathcal{I}_a] \langle e^{-\Delta s_r} | \{\mathcal{I}_a\} \rangle.$$
 (140)

For large t,  $\Delta s_r$  and hence the second factor remains of order 1. It can thus be ignored when taking the logarithm in the long-time limit leading to the current FT

$$\lim_{t \to \infty} \frac{1}{t} \ln \frac{p(\{\mathcal{I}_a\})}{p(\{-\mathcal{I}_a\})} = \sum_{a} \Delta S_a \mathcal{I}_a. \tag{141}$$

For a network coupled to different reservoirs at different temperatures or chemical potentials, the cycle affinites  $\Delta S_a$  arise from externally imposed affinites  $\mathcal{F}_k$  as discussed in more detail in Sect. 10.2 below. These affinites give rise to mesoscopic currents

$$\mathcal{J}_k = \sum_a \mathcal{J}_a d_a^k \tag{142}$$

where  $d_a^k$  are a generalized distance counting how much each cycle contributes to the respective current. Expressed in these currents, the FT reads

$$\lim_{t \to \infty} \frac{1}{t} \ln \frac{p(\{\mathcal{I}_k\})}{p(\{-\mathcal{I}_k\})} = \sum_k \mathcal{F}_k \mathcal{I}_k.$$
 (143)

In this derivation, it is crucial that all currents that contribute to the entropy production (either on the cycle or on the mesoscopic level) are included.

Generalizations of such an FT have been derived for just one current in [233], for networks with multiple transitions between states in [234], to a current not related to entropy production for a growth model on a lattice in [235] and for networks with a particular topology in [236]. Geometrical and topologial aspects were studied in [237, 238, 239, 240]. Periodically driven systems were investigated in [241] and a relation to supersymmetry is made in [242]. In another extension, Hurtado et al. have derived an "isometric fluctuation relation" that compares pdfs for currents with different orientations [243].

The FT for entropy production has been discussed for various chemical reaction networks in the papers by Gaspard and Andrieux quoted above, and, more recently, be applied to transport in mesoscopic devices which, despite their quantum character, can often still be described by a master equation whenever coherences can be, or are, ignored. For a few recent examples, see, e.g., [204, 205, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253].

There is a large literature arising from the recent progress of understanding current fluctuations in NESS in general, not necessarily related to the FT, for which the review by Derrida could serve as a point of departure [254].

#### 7. Optimization, irreversibility, information and feedback

## 7.1. Optimal protocols

7.1.1. General aspects — The integral fluctuation theorems like the Jarzynski relation hold for any external protocol  $\lambda(\tau)$  and any time interval t. An optimal protocol  $\lambda^*(\tau)$  is the one that extremizes the mean of a functional of the trajectory like work or heat for given initial value  $\lambda_i \equiv \lambda(0)$  and final value  $\lambda_f \equiv \lambda(t)$  of a control parameter and a fixed total time t allocated to this process.

Mean work as objective functions is arguably the most relevant case. For  $t \to \infty$ , the minimal mean work required for a transition is given by the free energy difference  $\Delta \mathcal{F} \equiv \mathcal{F}(\lambda_f) - \mathcal{F}(\lambda_i)$ . For any finite time t, the mean work should be larger and the

question for the optimal protocol becomes non-trivial. Understanding this problem will allow to extract the maximum amount of work from a given free energy difference in finite time.

Formulated as a variational problem, the optimal protocol obeys a quite complicated Euler-Lagrange equation which is non-local in time since changing the control parameter at time t<sup>1</sup> affects the work increment at all later times t2. Crucial insight into general features of the solution, however, has been obtained by investigating case studies involving harmonic potentials [255]. As a general feature, jumps of the optimal protocol were found that are absent in a linear response treatment [256].

A second motivation for minimizing the work could be an attempt to improve convergence of the Jarzynski estimate to obtain free energy differences since one might expect that a small mean work may also to lead to a smaller variance. Due to the non-linearity of exp[−w/T ], however, one should rather find the optimal protocol for minimizing hexp[−2w/T ]i which turns out to have jumps as well [257].

7.1.2. Overdamped dynamics The generic jumps in the optimal protocol were first found in case studies involving harmonic potentials [255]. The simplest case is a process where the center of a harmonic potential V (x, λ) = (x − λ) <sup>2</sup>/2 is shifted from λ<sup>i</sup> = 0 to λ<sup>f</sup> in a finite time t. Such a shift does not involve any free energy difference. Hence, the mean work required for this task will approach 0 for t → ∞. For a finite time, the optimal protocol can be calculated analytically by expressing the mean work as a functional of the mean position of the particle which renders the problem local in time. The optimal protocol (in dimensionless units for time)

$$\lambda(\tau) = \lambda_f(\tau+1)/(t+2) \tag{144}$$

involves two jumps

$$\Delta \lambda \equiv \lambda(0+) - \lambda_0 = \lambda_f - \lambda(t-) = \lambda_f/(t+2) \tag{145}$$

at the beginning and the end of the process. The physical reason for, e.g., the first jump is the fact that with this jump the dissipation rate is constant throughout the process. If the trap moved with constant speed without initial jump, the friction would slowly build up at the beginning of the process which ultimately would imply stronger dissipation. The size of the in this case symmetric jumps at beginning and end vanishes as t → 0.

Similar jumps have also been found in a second case study where the stiffness of a harmonic potential V (λ, x) = λx<sup>2</sup>/2 is changed in finite time from an initial value λ<sup>i</sup> to λ<sup>f</sup> [255]. For overdamped motion of a dipol in a magnetic field that switches the orientation, the optimal protocol can even show a degeneracy [258]. Further examples for optimal protocols involving non-linear potentials were studied numerically in [257].

An intriguing mapping of this optimization problem to deterministic optimal transport like mass transport by a Burgers velocity field has been discussed in [259, 260]. For total entropy production as objective function, turning an earlier scaling argument [261] into a mathematical proof, a general bound can thus be derived, ∆S tot ≥ C/t valid for any t, where C depends on the given initial and final distribution [262]. The key point is that this optimization takes place in the space of all probability distributions rather than in a restricted space of driving potentials with a few variational parameters. In the latter case, the ∼ 1/t behavior will hold only for long times.

7.1.3. Underdamped dynamics For under-damped dynamics, the optimal protocol involves even stronger singularities at beginning and end of the process given by additional  $\delta$ -peaks in the protocol [263]. Physically, these terms guarantee that the particle at the beginning acquires, and at the end looses, a finite mean momentum instantaneously which again minimizes total dissipation.

7.1.4. Discrete dynamics Optimal protocols can also be investigated for master equation dynamics on a discrete set of states. A simple case has been studied as a model for a quantum dot with a single energy level E connected to a reservoir with chemical potential  $\mu \equiv E - \epsilon(\tau)$ . The optimal protocol for an externally controllable gap  $\epsilon(\tau)$  and given  $\epsilon(0)$  and  $\epsilon(t)$  minimizing the mean work  $W \equiv \int_0^t d\tau p(\tau)\dot{\epsilon}(\tau)$ , where  $p(\tau)$  is the probability that the energy level is occupied, shows jumps in the optimal  $\epsilon^*(\tau)$  at beginning and end which are nicely explained in physical terms in [264]. A more general approach to the optimal protocol connecting arbitrary given initial and final distributions is given in [265].

#### 7.2. Quantifying time's arrow

The concepts developed for deriving the FTs can also lead to a more quantitative understanding of irreversibility. In Sect. 4, the time-reversed process was introduced as a mere tool for deriving the FTs. By considering such a time-reversed process seriously and comparing it to the original time-forward process, one can indeed derive an interesting relation between dissipation and irreversibility. An essential tool in this analysis is the relative entropy or Kullback-Leibler distance

$$D[p||q] \equiv \int dy \ p(y) \ln[p(y)/q(y)] \ge 0 \tag{146}$$

between two distributions p(y) and q(y). Essentially, this quantity measures how distinct the two distributions are [266].

We present here the stochastic version of the basic idea first introduced using Hamiltonian dynamics [267, 268]. For a process with a time-dependent potential  $V(\mathbf{x}, \lambda)$  and its time-reversal, which start and end in the respective equilibrium states, the quantity R in the generalized FT (79) becomes  $R = w - \Delta \mathcal{F}$ . This FT thus implies

$$\langle \exp[-(w - \Delta F)] | s_{\alpha} \rangle = p^{\dagger}(\epsilon_{\alpha} s_{\alpha}) / p(s_{\alpha})$$
 (147)

where the average is conditioned on the value  $s_{\alpha}$  of an arbitrary functional  $S_{\alpha}[\mathbf{x}(\tau)]$  along the trajectory with a definite parity  $\epsilon_{\alpha}$  under time-reversal. By choosing  $S_{\alpha} = w - \Delta \mathcal{F}$ , averaging the logarithm of (147) yields

$$\langle w \rangle - \Delta \mathcal{F} = D[p(w - \Delta \mathcal{F})||p^{\dagger}(-(w - \Delta \mathcal{F}))].$$
 (148)

This relation, which can be seen as a consequence of the CFT (61), shows that the dissipated work determines how different the distributions for this quantity along the forward and the backward paths are. Likewise, a large difference of these two distribution implies a substantial dissipated work.

By choosing  $S_{\alpha} = \mathbf{x}(t_1) = \mathbf{x}^{\dagger}(t - t_1)$ , i.e., the state of the system at any intermediate time  $t_1$ , one gets from (147) the lower bound

$$\langle w \rangle - \Delta \mathcal{F} > D[p(\mathbf{x}(t_1))||p^{\dagger}(\mathbf{x}^{\dagger}(t_1))].$$
 (149)

on the dissipated work. In contrast to this stochastic case, for a Hamiltonian dynamics, one obtains an equality in (149) due to Liouville's theorem [267]. For both types of dynamics, further coarse graining, i.e., looking at the distributions for a variable y = y(x(t1)), leads to a lower bound on the dissipated work since relative entropy decreases under coarse graining [266] as nicely illustrated in the present context in [269].

Similarly, by choosing t<sup>1</sup> = t, one immediately obtains the inequality

$$\langle w \rangle - \Delta \mathcal{F} \ge D[p(\mathbf{x}(t))||p^{\text{eq}}(\mathbf{x}(t))]$$
 (150)

which bounds dissipation by the distinguishability of the instantaneous distribution with the corresponding equilibrium distribution as derived and discussed in [270].

It is trivial to derive similar relations for processes involving genuine steady states that at constant control parameter reach a NESS rather than equilibrium as pointed out in [271]. Essentially, in (147–150), one has to replace hwi − ∆F by h∆s <sup>m</sup> + ∆φi where φ is the non-equilibrium potential (11).

Related inequalities have been discussed for transitions between specified initial and final states [272]. Relations between other information theoretic measures and non-linear averages of work and entropy along non-equilibrium trajectories have been derived in [273, 274, 275]. An intriguing relation between generating information and dissipation has been made for DNA replication in [276] with a corresponding pedagogical introduction in [277].

## 7.3. Measurement and feedback

7.3.1. Feedback and the second law According to the Kelvin-Planck formulation of the second law, one cannot extract work from an equilibrated system at constant temperature without leaving any traces of this process somewhere else. The situation becomes apparently different if information about the state of the system during this process becomes available through a measurement as the classical example of Maxwell's demon and the Szilard engine reviewed in [278, 279] demonstrate.¶ Based on the result of a measurement, one can choose a particular protocol for a control parameter which will indeed allow either to extract work in a cyclic process or, in a non-cyclic process, to extract more work than the corresponding free energy difference of initial and final equilibrium state. These statements are still compatible with the second law since erasing the information acquired will also cost free energy according to Landauer's principle. Taking this additional effect into account, the ordinary second law is restored. Typically, for discussing these processes within stochastic thermodynamics the cost of measurement and erasure process is first ignored in the problem of how to convert the acquired information into work (most efficiently) as it also will be ignored in the following discussion of the main concept where we use an approach based on FTs. Related earlier work will be briefly mentioned in Sect. 7.3.5.

7.3.2. Measurement and information For a quantitative description, we assume a system evolving according to a master equation as introduced in Sect. 6. If the system at time t<sup>1</sup> is in state n<sup>1</sup> = n(t1), a measurement yields a result y<sup>1</sup> with the probability p(y1|n1) = p(n1|y1)p(y1)/p(n1, t1). Here, p(n, t) is the ordinary solution of the master equation for the given initial condition and p(y1) the probability for

¶ For an instructive criticism of one of the assumptions of the Szilard engine, see [280].

obtaining the result  $y_1$  irrespective of  $n_1$ . The (trajectory-dependent) information acquired in this measurement is [281]

$$\mathcal{I}(n_1, y_1) \equiv \ln[p(n_1|y_1)/p(n_1, t_1)] = \ln[p(y_1|n_1)/p(y_1)]. \tag{151}$$

Upon averaging with  $p(y_1|n_1)$ , this trajectory dependent information becomes the relative entropy  $D[p(n_1|y_1)||p(n_1)]$  which still depends on the result  $y_1$  of the measurement. Further averaging over  $y_1$  leads to the mutual information

$$\mathcal{I} \equiv \int dy_1 p(y_1) D[p(n_1|y_1)||p(n_1)]$$
 (152)

$$= \int dy_1 \int dn_1 p(n_1, y_1) \mathcal{I}(n_1, y_1). \tag{153}$$

7.3.3. Sagawa-Ueda equality (SUE) and a generalization After a measurement, the control parameter  $\lambda(\tau, y_1)$  for the subsequent evolution  $t_1 \leq \tau \leq t$  depends uniquely on the outcome  $y_1$  leading to the probability distribution  $p_1(n,\tau|y_1)$ . For a system with a time-dependent potential  $V(n,\lambda)$ , i.e., a system that at any fixed  $\lambda$  reaches a genuine equilibrium state, Sagawa and Ueda have generalized the JR (58) to this feedback-driven process in the form [281, 282]

$$\langle \exp[-(w - \Delta \mathcal{F} + \tau)] \rangle = 1 \tag{154}$$

which implies for the maximal mean extractable work  $W^{\text{out}} \equiv -\langle w \rangle$  the bound

$$W^{\text{out}} \le -\Delta \mathcal{F} + \mathcal{I} \tag{155}$$

with  $\mathcal{I} \equiv \langle \mathcal{I} \rangle$ . Thus, acquiring information through a measurement allows to extract more work than what one would get from a process without feedback.

The original formulation of the SUE requires the notion of a free energy difference for initial and final state. For transitions involving genuine non-equilibrium states, i.e., those that at constant control parameter reach a NESS, the analogous relation

$$\langle \exp[-(\Delta s^{\text{tot}} + \tau)] \rangle = 1$$
 (156)

with the inequality

$$\langle \Delta s^{\text{tot}} \rangle \ge -\mathcal{I}$$
 (157)

hold true as well.<sup>+</sup>

A concise proof of (156), which will be valid with a minor modification for (154) as well\*, not requiring explicit time-reversal follows from exploiting the IFTs (84,85) [283]. By using  $\Delta s^{\text{tot}} = \Delta s + \Delta s^{\text{m}}$ , splitting the last term into the two contributions associated with the two time intervals  $i = (0 \le \tau < t_1)$  and  $ii = (t_1 \le \tau \le t)$ , making the total entropy change of the system explicit with  $\Delta s = -\ln p(n_t, t|y) + \ln p_0(n_0, 0)$ , and the specific expression for the information (151), the lhs of (156) can be written

<sup>&</sup>lt;sup>+</sup> Note that even for detailed balanced systems, the equalities (154) and (156) are different since, in general  $w - \Delta \mathcal{F} \neq \Delta s^{\text{tot}}$ .

For proving the SUE (154), one only needs to replace  $p_1(n_t, t|y_1)$  by  $p^{eq}(n_t, t|y_1)$  in (158).

TENTS

as

$$\left\langle \frac{1}{p_0(n_0)} e^{-\Delta s_i^{\text{m}}} \frac{p(n_1, t_1)}{p_1(n_1, t_1 | y_1)} e^{-\Delta s_{ii}^{\text{m}}} p_1(n_t, t | y_1) \right\rangle$$

$$= \sum_{m_1} \left\langle \frac{1}{p_0(n_0)} e^{-\Delta s_i^{\text{m}}} | n_1 = m_1 \right\rangle_i p(n_1, t_1) \times$$

$$\times \left\langle e^{-\Delta s_{ii}^{\text{ex}}} p_1(n_t, t | y_1) | n_1 \right\rangle_{ii} = 1.$$
(158)

48

Introducing conditioned averages on the two intervals i and ii eliminates the explicit factor  $1/p_1(n_1, t_1|y_1)$ . The underlined term is 1 for any  $m_1$  due to (84). Likewise, the subsequent summation over  $m_1$  is 1 due to (85). The SUE thus holds force for trajectory-averages still conditioned on the results  $y_1$ . Of course, further averaging over all possible outcomes  $y_1$  is allowed. This proof (as the original one) is easily extended to multiple measurements. Thus, the Sagawa-Ueda equality and its variant (156) with the corresponding inequalities hold for any number of measurements [282, 283, 284, 285, 286].

For processes involving genuine non-equilibrium states, the generalization of the Hatano-Sasa relation (66) to processes with feedback in the form [283]

$$\langle \exp[-(\Delta s^{\text{tot}} - \Delta s^{\text{hk}} + \tau)] \rangle = 1$$
 (159)

with the inequality

$$\langle \Delta s^{\text{tot}} \rangle \ge \langle \Delta s^{\text{hk}} \rangle - \mathcal{I}$$
 (160)

follows as easily starting with conditioned variants of (87). The bound (160) is much stronger than (157) since  $\langle \Delta s^{hk} \rangle$  will typically scale with the total time t. For systems that at constant  $\lambda$  exhibit detailed balance,  $\Delta s^{hk} = 0$ , in which case (159, 160) become (156, 157).

7.3.4. Efficiency of Brownian information machines For a cyclically operating information machine, where measurements are repeated at regular intervals separated by  $t_m$  [287], the inequality (157) implies that one can extract at most a mean power  $\dot{W}^{\rm out}$  bounded by

$$\dot{W}^{\text{out}} \le \dot{\mathcal{I}},$$
 (161)

where  $\dot{\mathcal{I}}$  is the rate with which information is acquired. Likewise, for processes involving transitions between genuine non-equilibrium states, the inequality (160) implies

$$\dot{W}^{\text{out}} < \dot{W}^{\text{in}} - \langle \dot{q}^{\text{hk}} \rangle + \dot{\mathcal{I}}. \tag{162}$$

If the rate of acquiring information is large enough, i.e., if  $\dot{\mathcal{I}} > \langle \dot{q}^{\rm hk} \rangle$ , the extracted power can exceed the power  $\dot{W}^{\rm in}$  required to sustain these non-equilibrium steady states as demonstrated explicitly with a simple example in [283]. Characteristically, the power extracted from such a machine becomes larger, the smaller the intervals  $t_m$  between the measurements are.

A quite natural definition for the efficiency [287, 288] of such a Brownian information machines obeying  $0 \le \eta \le 1$  is in the first case

$$\eta \equiv \dot{W}^{\text{out}}/\dot{\mathcal{I}} \tag{163}$$

and, analogously,

$$\eta \equiv \dot{W}^{\text{out}}/[\dot{W}^{\text{in}} - \langle \dot{q}^{\text{hk}} \rangle + \dot{\mathcal{I}}] \tag{164}$$

for the second case.

7.3.5. Further theoretical work and case studies Several theoretical studies have investigated various aspects of such feedback driven processes for stochastic dynamics. Kim and Qian have considered an underdamped particle controlled by a velocitydependent force [289, 290]. This problem has been analyzed from the perspective of total entropy production in [291]. Suzuki and Fujitani investigate Brownian motion both under a time-dependent force [292] and for linear systems more generally [293]. Similarly, Sagawa and Ueda illustrated their concept using a particle that is transported in a movable harmonic trap and can still extract work from the surrounding heat bath [281]. Feedback driven transport for ratchet-type systems has been optimized in [294, 295, 296]. Maximum power for such a model has been studied in [297]. Information-theoretic and thermodynamic concepts have been combined in [298, 288, 299]. The thermodynamic cost of a measurement has been modelled in [300].

The optimal protocol for extracting the maximal work from cyclic processes for particles in harmonic traps with adjustable center and stiffness based on imperfect positional measurements has been calculated in [301] where it was shown that the bound (155) cannot be saturated if only the center of the trap is under control. Only by additionally adjusting the stiffness, all the information can be recovered provided an infinite time is allocated to the process. For such a machine, the efficiency at finite cycle time has been calculated in [287]. The issue of saturating this bound has been investigated in more depth introducing the notion of "reversible" feedback by Horowitz and Parrondo [302, 303]. A model for the cost of erasing information using a Brownian particle in a double well potential was discussed in [304].

7.3.6. Experimental illustrations Experimentally, the Sagawa-Ueda equality has been demonstrated by using an ingenious set-up involving electric fields that upon measuring the position of a colloidal particle on a "stair" prevent that the particle slides down a step that it has just climbed by thermal excitation [305]. In another experiment, Landauer's principle has been illustrated using a colloidal particle trapped in a modulated double-well potential. The mean dissipated heat indeed saturates at the Landauer bound in the limit of long erasure cycles [306].

7.3.7. Hamiltonian dynamics for microcanonical initial conditions Deviating from the restriction to stochastic dynamics as applied generally in this review, I mention a few recent studies that use Hamiltonian dynamics and feedback since they provide an additional perspective on what has just been described. The Kelvin-Planck statement of the second law does not hold for micro-canonical initial conditions which indeed allow to extract work, i.e., to decrease the mean energy from a Hamiltonian system by manipulating an external control parameter [307]. Specific examples have been given for a harmonic oscillator in [308], for a particle between movable walls [309] and for motion in a double well potential [310]. While for such microcanonical initial conditions no measurement is necessary, these results could be applied to an initially canonical ensemble if the energy of the system is measured with subsequent adaption of the protocol of the control parameter in a feedback process. As shown explicitly in [310], the full analysis including the cost of erasing information exorcizes this "demon" and restores the ordinary second law.

## 8. Fluctuation-dissipation theorem (FDT) in a NESS

#### 8.1. Overview

8.1.1. FDT in equilibrium Equilibrium systems react to small perturbations in a quite predictable way formally expressed by the FDT, see, e.g., [311]. The response of an observable A at time τ<sup>2</sup> to a perturbation h applied at time τ<sup>1</sup> can be written in the form of an equilibrium correlation function as

$$T\delta\langle A(\tau_2)\rangle/\delta h(\tau_1)_{|h=0} \equiv TR_A^{\text{eq}}(\tau_2 - \tau_1) = \partial_{\tau_1}\langle A(\tau_2)B(\tau_1)\rangle^{\text{eq}}, \tag{165}$$

where the conjugate variable

$$B = -\partial_h E \tag{166}$$

follows from the energy E(h) of the system. Here it is assumed that for any small fixed h the energy of the system is still well-defined. This FDT is the formalization and generalization of Onsager's regression hypothesis that states that the decay of an excitation is independent of whether it has been generated externally by a force (or field) h or by a thermal fluctuation. This theorem is of great practical significance since it allows to predict the response to a perturbation without ever applying one just by sampling the corresponding equilibrium fluctuations either in experiments or in simulations. Characteristically, the same B holds for any A and any time difference τ<sup>2</sup> − τ1.

8.1.2. FDT in a NESS Whether a similarly universal relation exists for NESSs has been addressed using various approaches since the seventies. For an underlying stochastic dynamics, Agarwal has expressed the response function by a correlation function involving the typically unknown stationary distribution [312]. Bochkov and Kuzovlev [12, 313, 314] and H¨anggi and Thomas [315] have derived a variety of formal expressions for stochastic processes. A comprehensive review of the general relation between fluctuations and response including, in particular, deterministic chaotic systems is given in [316].

More recently, taking up a theme introduced earlier [317], Harada and Sasa derived a relation where the "violation" of the equilibrium FDT in a NESS was related to the rate of energy dissipation for a Langevin system [318, 319] later generalized to a description in terms of a density field [320]. For the special case of a driven colloidal particle it was shown in [321] that the FDT in the NESS could be obtained from the equilibrium FDT (165) by subtracting from the right-hand side a second correlation function involving the local mean velocity. This result suggested that in the locally co-moving frame the Onsager hypothesis could be restored which was later extended to sheared systems [322] and proven for general diffusive dynamics in [323, 324]. Thus, for these systems, the decay of an excitation around a local NESS is still the same whether generated externally or by the thermal fluctuations still present in the NESS.

A concise formal derivation and discussion of the general FDT in a NESS has been given by Baiesi et al. [325, 326, 327]. The response of particular observables was treated at the same time by Prost et al. [328]. In [329], it was then shown that the latter result holds indeed for any observable and that the FDT for a NESS becomes particularly transparent when using the concept of stochastic entropy with its splitting into a total and a medium one. In this latter work, the apparent multitude of FDTs in a NESS was rationalized in terms of an equivalence relation holding for observables in NESS correlation functions.

An elegant synthesis using mathematically somewhat more demanding concepts has just been given in [330]. An extension of these concepts to obtain an FDT around non-stationary non-equilibrium states is derived in [331]. A connection with gauge fields is made in the geometrical approach of [332].

8.1.3. Effective temperature The derivation of recent exact versions of the FDT for a NESS which as a result typically express the response function by a sum of two correlation functions should be distinguished from the phenomenological concept of an effective temperature that has been reviewed in [333]. Originally introduced in the context of ageing systems, it can be formulated also for a NESS. Simply stated, guided by the equilibrium form (165) an effective temperature is defined as

$$T^{\text{eff}}(A, \tau_2 - \tau_1) \equiv \partial_{\tau_1} \langle A(\tau_2) B(\tau_1) \rangle^s / R_A(\tau_2 - \tau_1)$$
(167)

where  $R_A$  is now taken in the NESS. In general,  $T^{\text{eff}}$  will depend on both the observable A and the time-difference  $\tau_2 - \tau_1$  which upon Fourier transformation corresponds to frequency  $\omega$ . Obviously, this concept can become meaningful only if these dependencies are not too pronounced.

From a theoretical point of view, a strictly observable and frequency-independent  $T^{\rm eff}$  follows for a Langevin system like (42) with  $\mathbf{f}=0$  if the non-equilibrium conditions are caused by an additional "active" noise  $\boldsymbol{\eta}$  with correlations  $\langle \boldsymbol{\eta}(\tau_2)\boldsymbol{\eta}(\tau_1)\rangle = 2(T^{\rm eff}-T)\underline{\boldsymbol{\mu}}\delta(\tau_2-\tau_1)$ . For a linear system and active noise correlated on a scale  $\tau^{\rm ac}$ ,  $T^{\rm eff}$  will depend on frequency. For  $\omega\tau^{\rm ac}\gg 1$ , one gets the ordinary temperature, whereas for  $\omega\tau^{\rm ac}\ll 1$  the enhanced fluctuations lead to a larger  $T^{\rm eff}$ .

On the other hand, if the non-equilibrium is generated by a non-conservative force of field, such a simple reasoning is no longer possibe. Still, in interacting systems one often finds numerically good agreement with the concept of an effective temperature as briefly mentioned in Sect. 8.4 below for sheared suspensions. A fundamental understanding when and why this is the case in general seems still to be missing.

For insight into the frequency and observable dependence for specific models and systems, see, e.g, [334, 335] for a binary Lennard-Jones mixture in a simple shear flow, [336] for a glassy model system, [337, 338, 339, 340] for simple interacting model systems, [341, 342, 343] for simple Langevin systems, and [344] for field-theoretical models.

Examples of investigating biophysical systems using an effective temperature include [345] for hair bundle oscillations, [346, 347] for the cytoskeleton, [348, 349] for filament oscillations in an active medium, [350] for self-propelled particles, [351] for vesicle and [352, 353] for red-blood cell fluctuations. If the response of such a system acts effectively "against" the perturbation, the effective temperature becomes negative as occasionally found in these studies. Such an observation shows that this concept should not be taken too literally.

An intriguing, apparently simple system in this context is "hot Brownian motion" where a diffusing particle heated by a laser acts as a local heat source [354, 355, 356, 357] for which in simulations various "effective temperatures" were determined [358]. Local heating in the context of the FT has been discussed theoretically in [359].

#### 8.2. Derivation and discussion

In this section, we sketch the derivation of the various forms of the FDT in a NESS from a unifying perspective for a general Markovian dynamics on a discrete set of states. Since overdamped Langevin systems can always be discretized, this case is a very general one. We follow the concepts introduced in [325, 329] which were briefly reviewed in their continuum version in [360]. Earlier related work for a Markovian dynamics on a discrete set of states making somewhat more explicit assumptions on observable and rates for spin models include [361, 362, 363, 364, 365, 366, 367, 368] and for ageing in supercooled liquids [369].

8.2.1. Equivalent correlation functions in a NESS We consider a class of NESSs with rates  $w_{mn}(h)$  that depend on a perturbation h. The stationary distribution of the master equation dynamics (110) obeys

$$\sum_{n} L_{mn}(h) p_n^s(h) = 0 (168)$$

with the generator

$$L_{mn}(h) \equiv w_{nm}(h) - \delta_{mn} \sum_{k} w_{mk}(h). \tag{169}$$

For fixed h, any dynamic information is fully contained in the propagator

$$G_{kl}(\tau) \equiv \operatorname{prob}[n(\tau) = k|n(0) = l] \tag{170}$$

for which the master equation (110) implies the evolution

$$\partial_{\tau}G_{kl} = \sum_{m} L_{km}G_{ml}(\tau) = \sum_{m} G_{km}(\tau)L_{ml}.$$
 (171)

In a NESS, denoted in the following with  $\langle ... \rangle^s$ , two point correlation functions for state variables of the form  $A(\tau) = \sum_m A_m \delta_{n(\tau)m}$  are given by

$$\langle A(\tau_2)B(\tau_1)\rangle^s = \sum_{mn} A_m G_{mn}(\tau_2 - \tau_1)B_n p_n^s$$
(172)

if  $\tau_2 > \tau_1$ . Using (169) and (171), a time derivative with respect to the earlier time can thus be written as an ordinary two-point correlation function

$$\partial_{\tau_1} \langle A(\tau_2) B(\tau_1) \rangle^s = \langle A(\tau_2) C(\tau_1) \rangle^s \tag{173}$$

with

$$C_{n} = B_{n} \sum_{m} w_{nm} - \sum_{m} B_{m} w_{mn} p_{m}^{s} / p_{n}^{s}$$

$$= \sum_{m} (B_{n} - B_{m}) p_{m}^{s} w_{mn} / p_{n}^{s}.$$
(174)

Besides state variables as observables we will also need current variables of the type

$$D(\tau) \equiv \sum_{j} \delta(\tau - \tau_j) d_{n_j - n_j +}$$
(175)

that yield  $d_{n_j-n_j+}$  whenever a corresponding transition takes place. Their NESS average is given by  $\langle D(\tau) \rangle^s = \sum_{mn} p_m^s w_{mn} d_{mn}$ . If  $D(\tau)$  shows up in a correlation function at the earlier time  $\tau_1$ , we get

$$\langle A(\tau_2)D(\tau_1)\rangle^s = \sum_{mkl} A_m G_{ml}(\tau_2 - \tau_1) p_k^s w_{kl} d_{kl}$$
(176)

$$= \langle A(\tau_2)E(\tau_1)\rangle^s \tag{177}$$

with

$$E_n = \sum_k p_k^s w_{kn} d_{kn} / p_n^s. \tag{178}$$

These relations imply, in particular, that the formal current variable

$$\dot{B}(\tau) \equiv \sum_{j} \delta(\tau - t_{j}) (B_{n_{j}} - B_{n_{j}})$$
(179)

obeys

$$\langle A(\tau_2)\dot{B}(\tau_1)\rangle^s = \partial_{\tau_1}\langle A(\tau_2)B(\tau_1)\rangle^s \tag{180}$$

which demonstrates, quite expectedly, that time derivatives can be pulled in and out a NESS correlation function straigthforwardly.

The fact that NESS correlation functions can have the same value if the variable at the earlier time is written differently gives rise to an equivalence relation denoted by

$$O^{(1)}(\tau) \cong O^{(2)}(\tau) \tag{181}$$

if

$$\langle A(\tau_2)O^{(1)}(\tau_1)\rangle^s = \langle A(\tau_2)O^{(2)}(\tau_1)\rangle^s \tag{182}$$

holds for all A and times  $\tau_1 < \tau_2$  [329]. For the variables defined above we obviously have

$$D(\tau) \cong E(\tau) \quad \text{and} \quad \dot{B}(\tau) \cong C(\tau)$$
 (183)

which summarizes how current variables and time derivatives can be replaced by state variables in NESS correlation functions. This freedom will explain why apparently so differently looking FDTs can be derived for a NESS.

8.2.2. Equivalent forms of the FDT The apparent plethora of FDTs can be rationalized by starting with an expression for the response function using the path weight (119). In the presence of a time-dependent perturbation  $h(\tau)$ , the mean value of the observable  $A(\tau)$  is given by [325, 329]

$$\langle A(\tau) \rangle = \sum_{n(\tau)} A(\tau) p[n(\tau); h(\tau) | n_0] p_{n_0}^s$$

$$= \sum_{n(\tau)} A(\tau) \frac{p[n(\tau); h(\tau) | n_0]}{p[n(\tau) | n_0]} p[n(\tau) | n_0] p_{n_0}^s.$$
(184)

The response function

$$R_A(\tau_2 - \tau_1) \equiv \delta \langle A(\tau_2) \rangle / \delta h(\tau_1)|_{h=0} \equiv \langle A(\tau_2) B^p(\tau_1) \rangle^s$$
 (185)

can be expressed by a two-point correlation function in the unperturbed NESS by evaluating (184) with the action (119) as

$$B^{p}(\tau_{1}) = -\delta \mathcal{A}[n(\tau); h(\tau)]/\delta h(\tau_{1})|_{h=0}$$
(186)

$$= -\sum_{k} w_{n(\tau)k} \alpha_{n(\tau)k} + \sum_{j} \delta(t - \tau_{j}) \alpha_{n_{j}^{-} n_{j}^{+}}.$$
 (187)

where

$$\alpha_{mn} \equiv \partial_h \ln w_{mn}(h)|_{h=0}. \tag{188}$$

This form of the conjugate variable (with the superscript<sup>p</sup> alluding to the derivation through the path weight) is convenient since it allows to determine the response function by measuring a correlation function that requires only knowledge about how the rates depend on the control parameter which is easily availabe in simulations. The more formal aspect that the first term in (187) arises from the time-symmetric part of the action and the second one from its time-asymmetric one is emphasized and further exploited in [325, 326, 327].

A second equivalent representation of the conjugate variable is obtained by replacing (by following the scheme (175-178)) the second (current) part in  $B^p$  by its equivalent state variable form which leads to  $B^p \cong B^a$  with

$$B_n^a = -\sum_k w_{nk} \alpha_{nk} + \sum_k w_{kn} \alpha_{kn} p_k^s / p_n^s$$
(189)

$$= \sum_{k} \partial_h L_{nk}(h)|_{h=0} p_k^s / p_n^s. \tag{190}$$

The last equality follows from expanding (169) in h and the definition (188). This expression for the conjugate variable involving only state variables can also be derived by straightforward time-dependent perturbation theory of the Fokker-Planck equation as originally derived by Agarwal (hence, the superscipt<sup>a</sup>) [312]. Using this expression, however, requires knowledge of the stationary distribution which for interacting systems with many degrees of freedom is not easily available in either simulations or experiments.

Finally, as a third, arguably physically most transparent form of the conjugate variable, it is easy to check explicitly that  $-\partial_h \dot{s} \cong B^a$  by expanding (168) in h and following the recipe of how to pull a time-derivative into a correlation function given in the previous subsection. Consequently, one has [329]

$$R_A(\tau_2 - \tau_1) = -\langle \partial_h \dot{s}(\tau_1) \rangle^s \tag{191}$$

$$= \langle \partial_h \dot{s}^{\text{in}}(\tau_1) \rangle^s - \langle \partial_h \dot{s}^{\text{tot}}(\tau_1) \rangle^s. \tag{192}$$

The first form expresses the response function as a time-derivative of a correlation function where the observable  $A(\tau_2)$  is correlated with the h-derivative of the stochastic entropy at  $\tau_1$ . This form of the conjugate variable is actually unique if one wants to write the response function as a time derivative of a correlation function. Moreover, it allows a physically transparent interpretation by splitting it into the sum of medium and total entropy production as shown in the second line.

8.2.3. Comparison with equilibrium FDT For a comparison with the equilibrium FDT assume that the steady state is a genuine equilibrium state for h=0. In fact, two classes of such systems should be distinguished.

First, if the system is not only in equilibrium at h = 0 but also at small h, the stationary distribution is given by the Boltzmann distribution

$$p_n^{\text{eq}}(h) = \exp\{-[E_n(h) - \mathcal{F}(h)]/T\},$$
 (193)

where  $E_n(h)$  is the internal energy and  $\mathcal{F}(h)$  the h-dependent free energy of the system. The stochastic entropy obeys  $s_n(h) = -\ln p_n^{\text{eq}}(h) = [E_n(h) - \mathcal{F}(h)]/T$ . Along an individual trajectory,  $\mathcal{F}(h)$  is constant and hence we have

$$T\partial_h \dot{s}_n(h)_{|h=0} = \partial_h \dot{E}_n(h)_{|h=0} \tag{194}$$

Inserting this equivalence into (191), the FDT acquires its well-known equilibrium form (165,166) involving the observable conjugated to h with respect to energy.

Second, a system may be in equilibrium at h = 0 but driven into a NESS even at constant small h. The paradigmatic example is a perturbation through shear flow for which there is no corresponding E(h) for any  $h \neq 0$ . For such systems, the equilibrium FDT can still be written in the form (191) but also in the pure state form with  $B^a$  from (189,190).

8.2.4. Systems with local detailed balance A further comparison between the equilibrium and the NESS-FDT is instructive for systems for which the perturbation enters the ratio of the rates in the form of a local detailed balance condition

$$\frac{w_{mn}(h)}{w_{nm}(h)} = \frac{w_{mn}(0)}{w_{nm}(0)} \exp[hd_{mn}/T],\tag{195}$$

where  $d_{mn} = -d_{nm}$  is the distance conjugate to the field covered by the transition  $m \to n$ . For h = 0, the system is supposed to be in genuine equilibrium with averages denoted by  $\langle ... \rangle^{\text{eq}}$ ; for  $h = h_0 \neq 0$  a genuine NESS denoted by  $\langle ... \rangle^s$  is reached. In equilibrium, using the global detailed balance condition (113), one easily verifies  $\partial_h \dot{s}^m \cong B^a$  and hence one has the equilibrium FDT

$$TR_A^{\text{eq}}(\tau_2 - \tau_1) = \langle A(\tau_2)B^a(\tau_1)\rangle^{\text{eq}} = \langle A(\tau_2)\partial_h \dot{s}^{\text{m}}(\tau_1)\rangle^{\text{eq}}.$$
 (196)

On the other hand, the NESS-FDT in the form (192) always holds. Since for such systems

$$\partial_h \dot{s}^{\mathrm{m}} = \sum_j \delta(\tau - \tau_j) d_{n_j - n_j + T}$$
(197)

is independent of h, the recipe for getting the FDT in a NESS from the equilibrium FDT is to keep as a first term the observables showing up in the correlation function but to evaluate the latter under NESS conditions and to subtract an expression involving the total entropy production [329].

8.2.5. Generalized Green-Kubo relations In equilibrium, the Green-Kubo relations express transport coefficients like conductivity or viscosity by time-integrals over equilibrium correlation functions of the corresponding currents. Based on the FDT derived above, it is possible to derive similar relations between transport coefficients in a NESS and appropriate current-current correlation functions [370] as illustrated for a simple models of molecular motors in [371]. This approach of studying the linear response of a NESS should be distinguished from extensions of the Onsager symmetry relations to the non-linear response coefficients of an equilibrium system [372].

#### 8.3. Colloidal particle on a ring as paradigm

The overdamped particle driven along a periodic potential, see Fig. 1, as discussed in Sect. 2.2 can serve as paradigm for illustrating the different versions of the FDT [329].

8.3.1. Equivalent correlation functions The equivalence relation introduced in Sect. 8.2.1 for variables occurring in correlation functions in a NESS exists for continuous variables as well. For a discretized position variable, jump rates can easily be derived from discretizing the path integral. Going then through the steps as in Sect. 8.2.2 shows that the equivalence

$$\dot{x} \cong 2v^s(x) - \mu F(x) \tag{198}$$

can be used in a NESS correlation function at the earlier time.  $\sharp$  The mean local velocity  $v^s(x)$  has been introduced in (12). Sometimes, the generalization

$$g(x)\dot{x} \cong g(x)[2v^s(x) - \mu F(x)] - \mu T \partial_x g(x)$$
(199)

is useful which can be derived similarly. ††

8.3.2. Three equivalent forms First, consider a NESS generated by a force  $f_0$  which is further perturbed by an additional delta-like force impuls acting at time  $\tau_1$ . The response function can be written as correlation function in the three equivalent forms

$$TR_A(\tau_2 - \tau_1)_{|h_0 \neq 0} = \langle A(\tau_2)[\dot{x} - \mu F(x)]_{|\tau_1}/2 \rangle^s$$
 (200)

$$= \langle A(\tau_2)[v^s(x) - \mu F(x)]_{|\tau_1} \rangle^s \tag{201}$$

$$= \langle A(\tau_2)[\dot{x} - v^s(x)]_{|\tau_1} \rangle^s. \tag{202}$$

The first form follows from applying perturbation theory to the path integral expression. The advantage of this expression is that it does not require explicit knowledge of the stationary distribution. By replacing the velocity with the corresponding state variable as shown in (198) one obtains the second form. This expression can also easily directly obtained from perturbation theory of the Fokker-Plank equation as in the original derivation [312]. Finally, a simple linear combination of the first two lines leads to the third form originally first derived in [321]. In this form, both the additive correction to the equilibrium form  $TR_A(\tau_2 - \tau_1) = \langle A(\tau_2)\dot{x}(\tau_1)\rangle^{eq}$  and the significance of a locally co-moving frame become apparent.

8.3.3. Generalized Einstein relation The Einstein relation (3) connecting the bare mobility  $\mu$  embedded in a viscous fluid with its diffusion constant D has arguably been the first form of an FDT which was based on a microscopic understanding of thermal motion. This relation has many manifestations in more complex soft matter systems as reviewed in [48]. If such a particle is in a periodic potential V(x), the diffusion coefficient

$$D[V(x)] = \lim_{t \to \infty} [\langle x^2(t) \rangle - \langle x(t) \rangle^2] / 2t$$
 (203)

# In equilibrium, this equivalence becomes  $\dot{x} \cong \mu \partial_x V(x)$  where the crucial sign difference compared to naively ignoring the noise in the Langevin equation (1) should be noted.

†† Applied to a NESS correlation function with  $A(\tau_2) = 1$ , this relation leads to  $\langle g(x)\dot{x}\rangle^s = \langle g(x)[2v^s(x) - \mu F(x)]\rangle^s - \mu T\langle \partial_x g(x)\rangle^s = \langle g(x)v^s(x)\rangle^s$  which corresponds to (34) applied to a NESS.

and the effective mobility

$$\mu[V(x)] = \partial_f \langle \dot{x} \rangle_{|f=0} \tag{204}$$

still obey D[V (x)] = T µ[V (x)] even though both terms are exponentially suppressed if the barriers exceed the thermal energy.

In the presence of a non-zero base force, an effective diffusion constant D[V (x), f] and a mobility µ[V (x), f] as in (203) and (204) evaluated at a finite force, respectively, are still defined. The effective mobility is the time-integrated response function. Hence, the generalized Einstein relation between D[V (x), f] and µ[V (x), f] follows from integrating (202) from τ<sup>2</sup> = −∞ to τ<sup>2</sup> = τ<sup>1</sup> as [321]

$$T\mu[V(x), f] = D[V(x), f] + \int_0^\infty d\tau [\langle \dot{x}(\tau) - \langle \dot{x} \rangle] [v^s(x(0)) - \langle \dot{x} \rangle \rangle^s]$$
 (205)

which shows how the "violation" of the usual Einstein relation can be expressed as an integral over velocity correlation functions. This relation is a simple example of a Green-Kubo relation generalized to a NESS [370]. Its form for other simple geometries like two-dimensional motion in the presence of a magnetic field has been studied in [373] and for a discrete model showing anomalous diffusion in [374].

8.3.4. Experiments The generalized Einstein relation (205) has been measured experimentally in [375]. Significantly, in this experiment, the extra integral term in (205) can be about four times as big as T µ[V (x), f] which shows clearly that this experiment probes a genuine NESS far from any linear response regime of an equilibrium system. Still, the description of the colloidal motion by a Markovian Brownian motion with unaltered thermal noise and a drift obviously remains a faithful representation. The very fact that around a critical force f ≃ max|∂xV (x)| the diffusion coefficient becomes quite large is known as giant diffusion [376, 377].

The time-resolved version of this FDT has been studied experimentally in [378] where it was shown that even though the different correlation functions (200-202) are theoretically equivalent their statistics can be vastly different. Not surprisingly, the variant (201) involving only state functions shows better convergence properties than the ones requiring ˙x. The response not to a force but to a change in the amplitude of the periodic potential was studied experimentally in [379, 380].

## 8.4. Sheared suspensions

For studying the relation between fluctuations and response in interacting nonequilibrium systems, a colloidal suspension in shear flow provides a paradigmatic case. Such a system follows a dynamics as introduced in Sect. 2.6.3 with u(r) = ˙γye<sup>x</sup> (or the corresponding underdamped version) and some pair interaction V .

One obvious question is to investigate the generalized Einstein relation between the self-diffusion coefficient Dij ( ˙γ) and the mobility µij ( ˙γ) of a tagged particle which both become tensorial quantities in such an anisotropic system. Szamel [381] studied these quantitities analytically using the memory-function formalism. Kr¨uger and Fuchs [382] have studied this relation analytically and numerically near the glass transition. Our numerical study in the fluid phase [383] revealed that for moderate densitities the results can surpringly well be expressed as an effective temperature since the ratios Dii( ˙γ)/µii( ˙γ) of the diagonal elements become isotropic with a roughly quadratic increase with shear rate. This effective temperature which turns out to

be the kinetic one can be rationalized by comparing this interacting system to a harmonically bound single particle in shear flow [384]. The response to a perturbation in the shear rate has been investigated in [322] and the one to a static external long wave-length perturbation in [385, 386].

Further studies of the general FDT for sheared suspensions include the integration through transient formalism [387, 388]. One advantage of this approach is that all quantities can be expressed in terms of (albeit complicated) equilibrium correlation functions. The response to a time-dependent additional shear strain has been studied numerically in [322] using essentially the form (191) that makes the excess compared to the equilibrium case explicit. The relation between the violation of the equilibrium FDT and energy dissipation using field variables has been addressed in [320].

## 9. Biomolecular systems

#### 9.1. Overview

Single molecules and (small) biomolecular networks constitute a paradigmatic class of systems to which the concepts of stochastic thermodynamics can be applied. Conformational changes of single molecules have become observable through a variety of methods often summarized as single molecule techniques [389, 390, 391]. There are essentially two ways of exposing such a molecule that is embedded in an aqueous solution of well-defined temperature containing different solutes at specified concentrations to non-equilibrium conditions. First, one can apply a (possibly timedependent) mechanical force if one end is connected via polymeric spacers to the tip of an AFM or to beads in an optical tweezer. This set-up allows to study, e.g., forceinduced unfolding of proteins. Another source of non-equilibrium are unbalanced chemical reactions catalyzed by the enzyme under study. In combination with a mechanical force, this set-up allows in particular to resolve individual steps of a molecular motor and to measure force-velocity curves of such a molecular machine [392, 393].

The fluctuating conformations of biomolecules in non-equilibrium can be described in two ways [34, 394, 395]. First, one can model the observable degrees of freedom like the end to end-distance of a protein by a continuous degree of freedom subject to a Langevin equation. Such an approach is particularly appropriate for studying force-induced un- and refolding of biopolymers, in particular, with the perspective of recovering free energy differences and even landscapes from nonequilibrium experiments as reviewed in Sect. 9.3 below.

Second, one can identify discrete, distinguishable states between which (sudden) transitions take place as it has often been done to model molecular motors [396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412]. In most of these works the focus has been on elucidating the cycles involved in the action of the motor and on deriving force-velocity curves and their dependence on ATP and ADP concentrations. A combination of both types of models has been used for describing molecular motors by a Langevin dynamics in a ratchet potential that depends explicitly on the current chemical state of the motor as reviewed in [413, 414, 415, 416].

From the perspective of stochastic thermodynamics, one would like to formulate a first law, discuss entropy production and derive the corresponding fluctuation theorems on the single molecule level. Within a discrete state description, a first law along

an individual trajectory has been discussed for single enzymes in [84, 208, 417], for molecular motors in [400, 404, 405, 406, 407, 408, 409], and for small biochemical reaction networks in [228, 418, 419]. Fluctuation theorems without explicit reference to a first law were discussed for such systems in [401, 410, 420, 421, 422, 423, 424].

From a theoretical point of view, there are essentially two new aspects that enter the stochastic thermodynamics of biomolecular systems beyond a naive combination of the stochastic thermodynamics of colloids as developed in Sect. 2 and the discrete dynamics as introduced in Sect. 6. First, the rates are not arbitrary as in Sect. 6 but are rather constrained by thermodynamic consistency [189, 190, 425] as discussed in detail below. Second, each of the states visited along a stochastic trajectory contains many microstates. Transitions between these (unobserved) microstates are fast so that thermal equilibrium is reached within each state. Transitions between the states, however, are slower, observable and can be driven by external forces, flows or chemical gradients. As a consequence, each of the states described by stochastic thermodynamics carries an intrinsic entropy arising from the coupling to the fast polymeric degrees of freedom and to those of the heat bath. This effect must be taken into account in any consistent identification of heat on the single trajectory level [84, 408, 426, 427]. Some of the earlier studies quoted above missed this contribution and, hence, failed to identify the dissipated heat correctly.

How these systems can be described from the perspective of a thermodynamic engine will be pursued in Sect. 10.

## 9.2. Biopolymers with continuous degrees of freedom

In this section, we show how a continuum description fits into the framework developed for systems without relevant internal degrees of freedom like a colloidal particle. This systematic presentation is largely original, even though some of the essential concepts are implicit in most of the works dealing with free energy recovery discussed in Sect. 9.3 below.

9.2.1. Thermodynamic states from a microscopic model A biopolymer contains a large number of coupled microscopic degrees of freedom most of which will not be accessible in experiments. Still, these microscopic degrees of freedom affect processes on a larger scale that are described by stochastic thermodynamics. The microscopic configurational degrees of freedom collectively denoted by ξ are subject to a microscopic potential energy Φ(ξ, λ) containing the interactions within the molecule (and possibly with some of the surrounding solvent and solute molecules). The dependence on λ allows for an external potential like an AFM or an optical tweezer whose position can be controlled through λ.

Under non-equilibrium conditions, an external force (or field or flow) is applied to the molecule leading to conformational changes apparent through, e.g., a changing end-to-end distance. Such a quantity is an example of a meso-scale description that involves a certain number of variables denoted by x. Each such state effectively comprises many micro states. Formally, one can split all microstates {ξ} in classes C<sup>x</sup> such that each ξ belongs to exactly one Cx. The dynamics of x is supposed to be slow and observable whereas equilibration among the micro states making up one state x is fast. Under this crucial assumption, the conditioned probability p(ξ|x, λ) that a microstate is occupied is given by

$$p(\xi|\mathbf{x},\lambda) = \exp[-(\Phi(\xi,\lambda) - F(\mathbf{x},\lambda))/T]$$
(206)

with the constrained free energy

$$F(\mathbf{x}, \lambda) \equiv E(\mathbf{x}, \lambda) - TS(\mathbf{x}, \lambda) \equiv -T \ln \sum_{\xi \in \mathcal{C}_{\mathbf{x}}} \exp[-\Phi(\xi, \lambda)/T],$$
 (207)

the constrained intrinsic entropy

$$S(\mathbf{x}, \lambda) \equiv -\partial_T F(\mathbf{x}, \lambda) = -\sum_{\xi \in \mathcal{C}_{\mathbf{x}}} p(\xi | \mathbf{x}, \lambda) \ln p(\xi | \mathbf{x}, \lambda)$$
 (208)

and constrained internal energy

$$E(\mathbf{x}, \lambda) = \sum_{\xi \in \mathcal{C}_{\mathbf{x}}} \Phi(\xi, \lambda) p(\xi | \mathbf{x}, \lambda).$$
 (209)

This model includes but is more general than a more conventional description of the configurational potential in the additive form

$$\Phi(\mathbf{x}, \xi, \lambda) = \Phi^{0}(\mathbf{x}, \lambda) + \Phi^{\text{int}}(\mathbf{x}, \xi, \lambda) + \Phi^{\text{med}}(\xi, \lambda)$$
(210)

made up by a system, a coupling (of arbitrary stength) and a potential for the degrees of freedom of the medium, which all may depend on the control parameter. Here, all degrees of freedom are split into those of the system x and those of the heat bath ξ. By replacing Φ(ξ, λ) in (206,207) with Φ(x, ξ, λ) and summing without constraint over all ξ, the relations (206-209) remain true for the potential (210).

9.2.2. First law For a time-dependent λ(τ), representing, e.g., the center of a moving laser trap, the increment in applied work reads

$$dw = \sum_{\xi \in \mathcal{C}_{\mathbf{x}}} \partial_{\lambda} \Phi(\xi, \lambda) p(\xi | \mathbf{x}, \lambda) \ d\lambda$$
 (211)

$$= \partial_{\lambda} F(\mathbf{x}, \lambda) d\lambda = dF(\mathbf{x}, \lambda) - \nabla F(\mathbf{x}, \lambda) d\mathbf{x}. \tag{212}$$

In the first equality, for a changing external parameter the work arising from the microscopic interaction Φ(x, λ) is expressed as an average over all microstates contributing to the state with (fixed) x. The second equality follows with (206). Compared to the expression in the colloidal case (15), the essential difference here is that F(x, λ) is a free energy rather than a bare potential, i.e., internal energy. Consequently, the first law that, of course, should involve internal energies rather than free energies becomes

$$d\bar{w} = dE(\mathbf{x}, \lambda) + dq = dF(\mathbf{x}, \lambda) + TdS(\mathbf{x}, \lambda) + dq. \tag{213}$$

This relation together with (212) implies for the increment in heat

$$dq = -\nabla F(\mathbf{x}, \lambda) d\mathbf{x} - T dS(\mathbf{x}, \lambda), \tag{214}$$

which makes the contribution to heat that arises from the intrinsic entropy S(x, λ) clear.

For a practical evaluation of the work, one would have to know F(x, λ), which, in general, has a complicated λ-dependence if the microscopic potential Φ(ξ, λ) is genuinely λ-dependent. However, if the external potential couples only to the slow

![](_page_60_Picture_1.jpeg)

**Figure 6.** Schematic view of a protein stretched by a bead in a laser trap. In a meso-scale description, the configuration is characterized by the positions  $\mathbf{x} = \{x_1, x_2, x_3, x_4, x_5, x\}$  where x is the position of the bead. The control parameter  $\lambda$  denotes the center of the trap.

degrees of freedom  $\mathbf{x}$  as typically assumed, see Fig. 6, a significant simplification occurs. In this case, one can write

$$F(\mathbf{x}, \lambda) = F^{0}(\mathbf{x}) + V(\mathbf{x}, \lambda) = E^{0}(\mathbf{x}) - TS^{0}(\mathbf{x}) + V(\mathbf{x}, \lambda), \tag{215}$$

where the quantities with superscript<sup>0</sup> are the thermodynamic potentials (207-209) of the molecule for constrained slow variables  $\mathbf{x}$  in the absence of the external potential. As a consequence

$$d = \partial_{\lambda} V(\mathbf{x}, \lambda) d\lambda \tag{216}$$

which becomes trivial for the typical case of a harmonic potential  $V(\mathbf{x}, \lambda) = k(x_i - \lambda)^2/2$ , with  $x_i$  the relevant coordinate for the coupling and k the effective stiffness of the AFM tip or optical trap centered at  $\lambda(\tau)$ .

9.2.3. Dynamics For the dynamics of the slow degrees of freedom one has the Langevin equation

$$\dot{\mathbf{x}} = \underline{\mu}[-\nabla F(\mathbf{x}, \lambda)] + \zeta \tag{217}$$

with the noise correlations as in (43). Likewise, the Fokker-Planck equation reads

$$\partial_{\tau} p(\mathbf{x}, \tau) = \nabla(\underline{\underline{\mu}} \nabla F(\mathbf{x}, \lambda) p(\mathbf{x}, \tau) + T\underline{\underline{\mu}} \nabla p(\mathbf{x}, \tau)),$$
 (218)

Compared to the discussion in Sect. 2.6.2 the key point here is that whenever states carry intrinsic entropy, the gradient of the free energy (rather than of internal energy) has to show up in the Langevin and Fokker-Planck equations since for any fixed  $\lambda$ , the system has to reach equilibrium with the Boltzmann factor

$$p^{\text{eq}}(\mathbf{x}, \lambda) = \exp[-(F(\mathbf{x}, \lambda) - \mathcal{F}(\lambda)/T]$$
(219)

with the  $\lambda$ -dependent free energy

$$\mathcal{F}(\lambda) \equiv -T \ln \int d\mathbf{x} \exp[-F(\mathbf{x}, \lambda)/T]. \tag{220}$$

9.2.4. Entropy production The stochastic entropy along the trajectory  $\mathbf{x}(\tau)$  becomes

$$s(\tau) \equiv -\ln p(\mathbf{x}(\tau), \tau) \tag{221}$$

where  $p(\mathbf{x}, \tau)$  follows from solving the Fokker-Planck equation (218) with an appropriate initial condition. For such a system with intrinsic entropy, the total entropy production along a trajectory during time t

$$\Delta s^{\text{tot}} \equiv \int_0^t d\tau \dot{s}^{\text{tot}} = \int_0^t d\tau [\dot{s}(\tau) + \dot{S}(\mathbf{x}, \lambda) + \dot{q}/T]$$
 (222)

contains three contributions rather than two as in the case without relevant intrinsic degrees of freedom.

9.2.5. FTs In principle, the FTs holds true in the presence of intrinsic entropy as well provided the latter is taken into account properly. The crucial point is that the master functional  $R_1$  defined in (71) when using as conjugate process the time-reversed one becomes

$$R_1 = \Delta s^{\text{int}} + q/T \tag{223}$$

where

$$\Delta s^{\text{int}} \equiv S(\mathbf{x}_t, \lambda_t) - S(\mathbf{x}_0, \lambda_0)$$
 (224)

is the change in intrinsic entropy along the forward trajectory. This result follows from evaluating the action in the path weight corresponding to the Langevin equation (217) and by using the first law (213) integrated along the trajectory.

As a consequence, the FTs involving entropy production discussed in Sects. 3.3 and 4 essentially hold true with the replacement

$$\Delta s^{\rm m} \to \Delta s^{\rm m} + \Delta s^{\rm int}.$$
 (225)

All FTs involving total entropy production hold true unmodified.

The FTs involving work as defined in (212) hold true as well. In particular, the JR stands with  $\Delta \mathcal{F} = \mathcal{F}(\lambda_t) - \mathcal{F}(\lambda_0)$  where the free energies have been defined in (220). The reason why the intrinsic entropy does not spoil these relations is the fact that both the work and the force in the Langevin equation are determined by the free energy  $F(\mathbf{x}, \lambda)$  very much in the same way as the bare protential  $V(x, \lambda)$  determines the corresponding quantities in the colloidal case. Loosely speaking, the results of the simpler case hold true provided one replaces the potential  $V(x, \lambda)$  by the free energy (i.e, potential of mean force)  $F(\mathbf{x}, \lambda)$ .

In the presence of intrinsic entropy, the FDT (192) must be modified accordingly by replacing  $\dot{s}^{\rm m}$  by  $\dot{s}^{\rm m} + \dot{s}^{\rm int}$ .

#### 9.3. Free energy recovery from non-equilibrium data

9.3.1. Hummer-Szabo relation (HSR) and variants From a practical perspective, arguably the most relevant FT for biomolecules is the Hummer-Szabo relation [10, 428]. As a kind of JR resolved along a reaction coordinate, it allows to determine the free energy landscape  $F^0(\mathbf{x})$  from non-equilibrium work measurements through an external potential  $V(\mathbf{x}, \lambda)$  conditioned on a fixed value of  $\mathbf{x}$ . It reads

$$\exp[-F^{0}(\mathbf{x})/T] = \exp[(V(\mathbf{x}, \lambda_{t}) - \mathcal{F}(\lambda_{0}))/T] \times \langle \exp[-w/T]\delta(\mathbf{x}_{t} - \mathbf{x}) \rangle.$$
(226)

The right hand side is evaluated by measuring the accumulated work w as a function of position x<sup>t</sup> irrespective of the particular t.

A concise derivation [21] of the HSR starts with the IFT (80). With the necessary replacement (225), the initial equilibrium distribution p0(x, λ0) = exp[−(F(x0, λ0) − F(λ0)/T ], the free choice p1(xt) = δ(x<sup>t</sup> − x), the first law (213) and the assumption (215), it follows within a couple of lines.

A variant of the HSR not requiring the position histograms in (226) can be derived for a harmonic coupling V (x, λt) [429]. Moreover, similarly as the CFT generalizes the JR by including information from the time-reversed process, bidirectional variants of the HSR have been derived and tested in model calculations [430, 431].

9.3.2. Experiments The first experimental application of the JR to biomolecules was the determination of the free energy involved in partially unfolding RNA hairpins [432]. The CFT was first applied in another experiment measuring the free energies in RNA hairpins and RNA three-helix junctions [433]. In a series of experiments, Ritort and co-workers have used the CFT to determine the free energy involved in unfolding DNA hairpins [87, 434, 435, 436]. The free energy involved in unfolding the multidomain protein, titin, has been measured in [437] using a simplified variant of the JR leading to some criticism [438, 439]. The CFT has been used to determine free energy changes induced by mechanically unfolding coiled-coil structures [440, 441] and different topological variants of a protein [442]. Axis-dependent anisotropy in protein unfolding was investigated using the HSR in [443]. The free energy landscape derived from the HSR has been compared to equilibrium measurements in [444]

9.3.3. Numerical work As relatively scarce real experimental studies using the FTs still are, as large is the number of "numerical" experiments illustrating the use of the HSR and its variants for recovering free energy landscapes. The following brief list is necessarily incomplete. Model calculations for a single coordinate deal with the advantage of applying a periodic force protocol [445], with random forcing [446], comparison with "inherent structures" [447], with motion in a periodic potential [448], and with recovering an unknown spatially dependent mobility [449]. Multidimensional landscapes were reconstructed in [450]. Monte-Carlo or molecular dynamic simulations were used for an off-lattice model protein [451], for a protein domain in [452] and for a membrane protein in [453].

An important line of research in this context is to find methods for dealing with the error caused by having only finite (and even noisy) data for evaluating the nonlinear averages involved in the JR and the HSR. Some of the papers dealing with this issue are [86, 137, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480].

#### 9.4. Enzymes and molecular motors with discrete states

In this section, we show how the general framework for a Markovian dynamics on a discrete set of states can be adapted to describe the stochastic thermodynamics of enzymes and molecular motors in a thermal environment starting again from a microscopic model. Apart from keeping track of the intrinsic entropy of the states the essential point is to incorporate the enzymatic reactions involving solute molecules consistently.

9.4.1. Thermodynamic states The enzyme is in an aqueous solution which consists of molecules of type i with concentrations  $\{c_i\}$  and chemical potentials  $\{\mu_i\}$  enclosed in a volume V at a temperature T. It exhibits a set of states such that equilibration among microstates corresponding to the same state is fast whereas transitions between these states are assumed to be slower and observable. Under these conditions, one can assign to each state n of the enzyme a free energy  $F_n^{\rm enz}$ , an internal energy  $E_n^{\rm enz}$ , and an intrinsic entropy  $S_n^{\rm enz}$ . As explicitly discussed in [427], these quantities follow from any microscopic model that specifies the energy of the microstates of enzyme and solution. They obey the usual thermodynamic relation

$$F_n^{\text{enz}} = E_n^{\text{enz}} - TS_n^{\text{enz}} \tag{227}$$

despite the fact that the enzyme is small. Moreover, there is no need to assume that the interaction between enzyme and solution is somehow weak. In general, these thermodynamic variables of the enzyme depend on the concentrations of the various solutes.

- 9.4.2. First law In this section, we discuss the first law for the three classes of (i) pure conformational changes, (ii) enzymatic reactions including binding and release of solutes, and (iii) motor proteins.
- (i) Conformational changes: If the enzyme jumps from state m to state n, the change in internal energy

$$\Delta E^{\rm enz} \equiv E_n^{\rm enz} - E_m^{\rm enz} = -q \eqno(228)$$

must be identified with an amount q of heat being released into (or, if negative, being taken up from) the surrounding heat bath since there is no external work involved.

(ii) Enzymatic reactions: The more interesting case are enzymatic transitions that involve binding of solute molecules  $A_i$ , their transformation while bound, and finally their release from the enzyme. Quite generally, one considers transitions written as

$$n_{\rho}^{-} + \sum_{i} r_{i}^{\rho} A_{i} \rightleftharpoons n_{\rho}^{+} + \sum_{i} s_{i}^{\rho} A_{i}$$

$$(229)$$

where  $1 \leq \rho \leq N_{\rho}$  labels the possible transitions. Here,  $n_{\rho}^{-}$  and  $n_{\rho}^{+}$  denote the states of the enzyme before and after the reaction, respectively. For  $s_{i}^{\rho}=0$ , this scheme describes pure binding of solutes, and for  $r_{i}^{\rho}=0$  release of bound solutes. A transformation (like bound ATP to bound ADP + P<sub>i</sub>) can also be described by the above scheme with  $r_{i}^{\rho}=s_{i}^{\rho}=0$  and the understanding that the enzyme states contain the bound solutes, see [427] for a more detailed discussion.

The free energy difference involved in such a transition

$$\Delta F_{\rho} = \Delta E_{\rho} - T \Delta S_{\rho} \equiv \Delta F_{\rho}^{\text{enz}} + \Delta F_{\rho}^{\text{sol}}$$
 (230)

has two contributions where

$$\Delta F_{\rho}^{\rm enz} = \Delta E_{\rho}^{\rm enz} - T \Delta S_{\rho}^{\rm enz} \equiv F_{n_{+}^{+}}^{\rm enz} - F_{n_{-}^{-}}^{\rm enz}$$
(231)

denotes the free energy change of the enzyme and

$$\Delta F_{\rho}^{\text{sol}} = \Delta E_{\rho}^{\text{sol}} - T \Delta S_{\rho}^{\text{sol}} \equiv \sum_{i} (s_{i}^{\rho} - r_{i}^{\rho}) \mu_{i} \equiv \Delta \mu_{\rho}$$
 (232)

denotes the free energy change attributed to the solution in this reaction. Both free energy contributions can as usually be split into internal energy and intrinsic entropy.

As in the case of pure conformational changes, one assigns a first law type energy balance to each reaction of type  $\rho$  (229). Once an initial state is prepared, in the closed system (enzyme plus solution) there is obviously no source of external work. Neither does the system perform any work. Hence, the heat released in this transition is given by minus the change of internal energy of the combined system [427]

$$q_{\rho} = -\Delta E_{\rho} = -\Delta E_{\rho}^{\text{enz}} - \Delta \mu_{\rho} - T\Delta S_{\rho}^{\text{sol}}.$$
 (233)

This relation shows that the enzyme and the solution are treated on the same footing since only their combined change in internal energy enters. Since the heat is released into the solution acting as a thermal bath, the configurational change of the enzyme as well as binding and releasing solute molecules contribute to the same bath.

(iii) Molecular motors: Essentially the same formalism applies to an enzyme acting as a molecular motor often described by such discrete states. Most generally, if the motor undergoes a forward transition of type  $\rho$  as in (229) it may advance a distance  $d_{\rho}$  in the direction of the applied force f (or, if f < 0, opposite to it). The special cases  $d_{\rho} = 0$  (pure chemical step) or  $s_i^{\rho} = r_i^{\rho} = 0$  (pure mechanical step) are allowed. For  $d_{\rho} \neq 0$ , the mechanical work

$$w_{\rho}^{\text{mech}} \equiv f d_{\rho}$$
 (234)

is applied to (or, if negative, delivered by) the motor.

The motor operates in an environment where the concentration of molecules like ATP, ADP or  $P_i$  are essentially fixed. The first law for a single transition of type  $\rho$  becomes [427]

$$q_{\rho} = w_{\rho}^{\text{mech}} - \Delta E_{\rho} = f d_{\rho} - \Delta E_{\rho}^{\text{enz}} - \Delta \mu_{\rho} - T \Delta S_{\rho}^{\text{sol}}.$$
 (235)

9.4.3. Role of chemiostats: Genuine NESS conditions The more recent form (235) of the first law differs from an expression discussed previously for molecular motors [400, 404, 405, 406, 407, 408]. There, in the present notation and sign convention, the first law for a step like in (229) reads

$$\bar{q}_{\rho} = w_{\rho}^{\text{mech}} - \Delta E_{\rho}^{\text{enz}} - \Delta \mu_{\rho}. \tag{236}$$

The difference between the two expressions for the heat

$$\bar{q}_{\rho} - q_{\rho} = T\Delta S_{\rho}^{\text{sol}} \tag{237}$$

involves the entropy change in the solution resulting from the reaction.

The physical origin of the two different forms arises from the fact that in the older work the enzyme is thought to be coupled to "chemiostats" providing and accepting molecules at an energetic cost (or benefit) given by their chemical potential. Introducing the notion of a "chemical work"

$$w_{\rho}^{\text{chem}} \equiv -\Delta\mu_{\rho} \tag{238}$$

the first law is then written in the form

$$w_{\rho}^{\text{mech}} + w_{\rho}^{\text{chem}} = \Delta E_{\rho}^{\text{enz}} + \bar{q}_{\rho}. \tag{239}$$

The concept of chemiostats is supposed to guarantee that the concentration of solute molecules remains strictly constant. Physically, it could be implemented by an ATP buffer of ATP-regeneration scheme that involves additional enzymes. From the perspective of stochastic thermodynamics as long as one focusses on single transitions, however, it would be more appropriate to treat these additional enzymes and the chemical reactions they catalyze in the same way as the reaction involving the motor protein. It turns out that if these additional reactions operate quasistatically, then  $\bar{q}_{\rho}$  is the dissipated heat that under steady state conditions would enter an ensemble average [427]. Therefore, choosing the heat  $\bar{q}_{\rho}$  is appropriate whenever one deals with strict NESS conditions while not wanting to consider the heat involved in enforcing these conditions explicitly as an extra contribution. On the trajectory level for a single motor protein, there seems to be no sensible way for assigning  $\bar{q}_{\rho}$  instead of  $q_{\rho}$  to an individual transition.

9.4.4. Stochastic trajectory and ensemble A trajectory of the enzyme can be characterized by the sequence of jump times  $\{\tau_j\}$  and the sequence of reactions  $\{\rho_j^{\sigma_j}\}$  where  $\rho_j$  denotes the corresponding reactions (229) and  $\sigma_j = \pm$  characterizes the direction in which the reaction takes place.

An ensemble is defined by specifying (i) the initial probability  $p_n(0)$  for finding the enzyme in state n and (ii) the set of rates  $w_{\rho}^{\pm}$  with which the reactions (229) take place in either direction. Both inputs will then determine the probability  $p_n(\tau)$  to find the enzyme in state n at time  $\tau$ .

9.4.5. Rates and local detailed balance An identification of entropy production along the trajectory requires some input from the rates determining the transitions. For the simple case of pure conformational changes,  $m \rightleftharpoons n$ , choosing rates that obey

$$\frac{w_{mn}}{w_{mm}} = \exp[-(F_n^{\text{enz}} - F_m^{\text{enz}})/T]$$
 (240)

is required by thermodynamic consistency. Indeed, only this choice guarantees that irrespectively of the initial conditions the ensemble will eventually reach thermal equilibrium,

$$p_n(\tau) \to p_n^{\text{eq}} \equiv \exp[-(F_n^{\text{enz}} - \mathcal{F}^{\text{enz}})/T],$$
 (241)

with the free energy of the enzyme

$$\mathcal{F}^{\text{enz}} \equiv -T \ln \sum_{n} \exp[-F_n^{\text{enz}}/T]. \tag{242}$$

Fixing the ratio of the rates still leaves one free parameter per pair of states which can only be determined from knowing the dynamics of the underlying more microscopic model.

The corresponding relation for transitions that involve enzymatic reactions (229),

$$\frac{w_{\rho}^{+}}{w_{\rho}^{-}} = \exp[-\Delta F_{\rho}/T] = \exp[-(\Delta F_{\rho}^{\text{enz}} + \Delta \mu_{\rho})/T], \tag{243}$$

and for transitions of molecular motors,

$$\frac{w_{\rho}^{+}}{w_{\rho}^{-}} = \exp[-(\Delta F_{\rho}^{\text{enz}} + \Delta \mu_{\rho} - w_{\rho}^{\text{mech}})/T],$$
 (244)

are somewhat less obvious. Essentially, three types of justifications for choosing such ratios can be given.

First, even though microreversibility is often invoked it seem unclear how to obtain these ratios rigorously using this concept if chemical reactions are involved.

Second, one can derive (243) using the following argument. For any enzymatic reaction there will be concentrations  $\{c_i^{\text{eq}}\}$  of the solutes such that the enzyme will reach equilibrium. For these particular equilibrium concentrations, a choice of rates respecting (243) is mandatory as in the case of pure conformational changes. If one now assumes that (i) the reaction rates obey the mass action law and that (ii) the concentrations and the chemical potentials are related by the ideal solution expression,  $\mu_i(c_i) = \mu_i^{\text{eq}} + T \ln(c_i/c_i^{\text{eq}})$ , then the form (243) follows.

Third, more recently it has been shown that by requiring a consistent stochastic thermodynamic description on the trajectory level, one can indeed derive these conditions on the rates using rather mild assumptions [427].

In all cases by invoking the respective first laws (228,233,235), the ratio of the rates can also be written in the form

$$\frac{w_{\rho}^{+}}{w_{\rho}^{-}} = \exp[\Delta S_{\rho} + q_{\rho}/T] \tag{245}$$

showing that this ratio is determined by the change of intrinsic and medium entropy involved in this transition. This important relation should be compared with (20) in the colloidal case where the continuum version of such a ratio involves only the dissipated heat since there is no relevant intrinsic entropy change given here by  $\Delta S_{\rho}$ . Similarly, for a biopolymer within a continuum description, the relation (223) shows the contribution of intrinsic entropy.

9.4.6. Entropy production and FTs The total entropy production involved in one forward transition  $\rho$  at time  $\tau$  can be derived from the general expression (126) and by using the ratio of the rates (245) as

$$\Delta s_{\rho}^{\text{tot}}(\tau) = \ln \frac{p_{n_{\rho}^{-}}(\tau)w_{\rho}^{+}}{p_{n_{\rho}^{+}}(\tau)w_{\rho}^{-}} = \Delta s_{\rho} + \Delta S_{\rho} + q_{\rho}/T.$$
 (246)

It consists of three contributions. The first is the change in stochastic entropy,

$$\Delta s_{\rho}(\tau) = -\ln[p_{n_{\rho}^{+}}(\tau)/p_{n_{\rho}^{-}}(\tau)]. \tag{247}$$

The second denotes the change in the intrinsic entropy (230) of the system which consists here of enzyme and surrounding solution. The third term arises from the dissipated heat (233,235).

Summing over all reactions taking place up to time t and adding the concomitant change in stochastic entropy,  $\Delta s = -\ln p_{n_t}(t) + \ln p_{n_0}(0)$ , one obtains the total entropy production along a trajectory

$$\Delta s^{\text{tot}} = \Delta s + \sum_{j} \sigma_{j} [\Delta S_{\rho_{j}}(\tau_{j}) + q_{\rho_{j}}(\tau_{j})/T], \qquad (248)$$

where  $\sigma_j = \pm 1$  denotes the direction in which the transition  $\rho_j$  takes place at time  $\tau_j$ . The arguably most relevant situation for an enzyme modelled by discrete states is a NESS generated by non-equilibrated solute concentrations and/or an applied external force in the case of a motor protein. In such a NESS, one has the SSFT (65) for the total entropy production as defined in (248).

9.4.7. Time-dependent rates and work So far, it was implicitly assumed that the rates are time-independent. Time-dependent rates could arise either since the concentrations of the solutes are externally modulated (or, in a finite system, depleted due to the action of the enzymes) or since the forces applied to motor proteins are time-dependent. The ratio of the rates is then still constrained by (243, 244). However, under such time-dependent external conditions characterized by a parameter λ(τ), the thermodynamic state variables En, S<sup>n</sup> and F<sup>n</sup> can become time-dependent as well. In consequence, there are contributions to the first law and to entropy production even if the enzyme remains in the same state. Specifically, if the enzyme remains in state n, in analogy to (212) the first law becomes

$$dw_n = \partial_{\lambda} F_n d\lambda = (\partial_{\lambda} E_n - T \partial_{\lambda} S_n) d\lambda = \partial_{\lambda} E_n d\lambda + dq_n. \tag{249}$$

Hence, there is exchanged heat, ¯dq<sup>n</sup> = −T dSn, even if the system remains in the same state whenever the intrinsic entropy depends on a changing external parameter (like, e.g., the concentration of the solutes).

These expressions of heat and work resemble those of quasistatic processes as they should since it is implicitly assumed that the distribution of microstates that contribute to the state n adapts (almost) instantaneously to thermal equilibrium. Consequently, these contributions to work and heat do not enter the FTs non-trivially.

9.4.8. Experiments: F1-ATPase Apart from free energy reconstructions described above, experimental work using the concepts of stochastic thermodynamics is still scarce. For the F1-ATPase, two groups have published work pointing in this direction. In an intriguing example of exploiting the SSFT, the torque exterted by the F1-ATPase on a bead in an optical trap could be measured without knowing the friction constant of the bead [481]. The implicite assumption, however, with this type of analysis is that no further dissipative mechanisms exist. In another study of this molecule [482, 483], it was inferred that this motor transfers almost the full free energy from ATP hydrolysis into loading the elastic element connecting the motor with the bead.

9.4.9. Biochemical reaction networks The formalism described above for a single enzyme can easily be extended to networks involving several types of (different) enzymes [84] or ordinary chemical reactions networks using chemical master equations [228, 419]. Specific examples for which the distribution of entropy production has been calculated are [484, 485, 486].

## 10. Autonomous isothermal machines

## 10.1. General aspects

Enzymes and molecular motors as described in Sect. 9 from the stochastic thermodynamics perspective provide a paradigm for isothermal machines. In contrast to heat engines, which in their classical form are the archetypical thermodynamic machines and which in their stochastic version will be described in Sect. 11, isothermal machines do not transform heat but rather chemical energy into mechanical work (or vice versa) while the temperature of the surrounding medium remains constant.

A general classification relevant to machines is whether or not they operate autonomously. In the stochastic setting, an autonomous machine will typically

correspond to a NESS driven by externally imposed time-independent boundary conditions. Any molecular motor is a typical example of such an autonomous isothermal machine, since single molecule assays typically provide conditions of constant non-equilibrium concentrations of "fuel" molecules like ATP. For a non-autonomous machine, some time-dependent external control is required that "leads" the machine through its cycle. Building reliable artificial molecular motors in the lab still constitutes a major challenge as reviewed in [487, 488, 489, 490, 491, 492].

In this section, we present a systematic theory for isothermal autonomous machines in the discrete state version based on the representation in terms of cycles of the underlying network. In principle, this approach includes earlier models based on continuous coordinates diffusing in a ratchet potential that depends on the chemical state of the motor since any continuum model can be discretized. The emphasis here, however, is on the basic principles, and, in particular, how the thermodynamic constraints are implemented consistently.

An important quantity for any type of machine is its efficiency defined as the ratio between the power delivered by the machine and the rate of "fuel" consumption. Thermodynamics constrains this efficiency by 1 for isothermal machines and by the Carnot efficiency for thermal heat engines operating between heat baths of different temperature. In both cases working at the highest possible efficiency comes at the cost of zero delivered power since reaching the thermodynamic bound requires a quasistatic, i.e., infinitely slow operation. A practically more relevant question then is about efficiency at maximum power (EMP). We will see that in this thermodynamic framework rather general expressions for power, efficiency and efficiency at maximum power emerge.

It would be interesting to pursue these issues also for periodically driven machines, which are one step more complex than the autonomous ones. While there is a vast literature on how to generate transport by periodic modulation of system parameters as reviewed in [415, 493, 494, 495] the problem of efficiency and efficiency at maximum power, however, seems not to have been addressed systematically for such stochastic machines. One reason is that even making explicit statements about the periodic steady state is much harder than for the NESS engine at constant external parameters.

# 10.2. General framework for autonomous machines: Cycle representation and entropy production

An autonomously operating device or machine can be modelled as a Markov process on a network in a steady state. Transitions between different states in this NESS depend on rates that reflect both the coupling of the machine to reservoirs with different chemical potentials for solutes or particles and external forces or loads. These non-equilibrium conditions can be expressed by generalized thermodynamic forces or "affinities"  $\mathcal{F}_k$  as listed in Tab. 1.

For a systematic presentation it is useful first to recall the representation of a NESS in terms of cycle currents [189, 190], see Fig. 3. Rather than summing over the individual transitions (mn) or reactions  $\rho$  as we have done so far, in a NESS probability currents can be expressed by a sum over directed cycle currents

$$j_a \equiv j_a^+ - j_a^- = j_a^+ (1 - j_a^- / j_a^+) = j_a^+ (1 - \prod_{\rho \in a} w_\rho^- / w_\rho^+)$$
 (250)

where a labels the cycles and  $j_a^+$  and  $j_a^-$  denote the inverse mean times required for

Table 1. Affinities and generalized distance for isothermal machines

| process            | affinity $\mathcal{F}_k$ | gen. distance $d^k$ |  |
|--------------------|--------------------------|---------------------|--|
| linear motion      | force $f/T$              | linear distance $d$ |  |
| rotation           | torque $N/T$             | angle $\Delta \phi$ |  |
| particle transport | $-\Delta\mu/T$           | (typically) 1       |  |
| chemical reaction  | $-\Delta\mu/T$           | (typically) 1       |  |

completing the cycle in forward and backward direction, respectively.† These forward and backward (probability) currents can be expressed in a diagrammatic way by the transition rates of the whole network (not just those of the respective cycle). However, the ratio  $j_a^-/j_a^+$ , is given by the ratio between the product of all backward rates and the product of all forward rates contributing to the cycle a.

Thermodynamic consistency as formulated in (139) or (245) allows to express this ratio

$$\prod_{\rho \in a} w_{\rho}^{-}/w_{\rho}^{+} = \exp(-\Delta S_{a}) \tag{251}$$

by the sum

$$\Delta S_a \equiv \sum_{\rho \in a} (q_\rho / T + \Delta S_\rho) \equiv q_a / T + \sum_{\rho \in a} \Delta S_\rho = \bar{q}_a / T$$
 (252)

of the entropy changes in the reservoirs and heat baths associated with this cycle. The last equality recalls the definition of heat under strict steady state conditions which includes the quasi-static refilling of the reservoirs as discussed in Sect. 9.4.3. With the first law (239) summed along a cycle, this entropy change can also be written as

$$\Delta S_a = (w_a^{\text{mech}} + w_a^{\text{chem}})/T. \tag{253}$$

This representation alluding to the definition of a "chemical work" introduced in Sect. 9.4.3 becomes convenient when discussing the efficiency.

Alternatively, expressed in terms of affinities, the entropy change associated with a cycle becomes

$$\Delta S_a = \sum_k d_a^k \mathcal{F}_k,\tag{254}$$

where  $d_a^k$  is a generalized distance conjugate to the force  $\mathcal{F}_k$  as listed in Tab. 1. To each affinity  $\mathcal{F}_k$ , there corresponds a conjugate flux or current

$$J_k \equiv \sum_a (j_a^+ - j_a^-) d_a^k = \sum_a j_a^+ [1 - \exp(-\Delta S_a)] d_a^k$$
 (255)

describing the rate with which the respective quantity is "processed" by the machine.

The mean entropy production rate can be written as

$$\sigma = \sum_{a} (j_a^+ - j_a^-) \Delta S_a \tag{256}$$

$$= \sum_{a} j_a^{+} [1 - \exp(-\Delta S_a)] \Delta S_a = \sum_{k} J_k \mathcal{F}_k.$$
 (257)

These expressions are exact and do not imply any linear response assumption as the final bilinear form may suggest.

† The directed cycle current  $j_a \equiv \langle \mathcal{J}_a \rangle$  is the mean of the fluctuating current  $\mathcal{J}_a$  introduced in Sect. 6.4.

#### 10.3. Power and efficiency

10.3.1. Input and output power A device or machine is supposed to deliver some output from consuming some input. Characteristically for nano-machines, the role of output and input can easily be reversed as it depends on the signs of the corresponding affinities. Input has to be offered to the machine with a positive affinity  $\mathcal{F}_i > 0$  whereas output is associated with a current or flux that is opposite to an applied affinity  $\mathcal{F}_o < 0$ .

Quite generally, for an isothermal machine in a NESS, the total rate of production of output and input,  $P_o$  and  $P_i$ , respectively, is given by the product between a pair of corresponding flux and affinity according to

$$P_{o,i} = \epsilon_{o,i} J_{o,i}(T\mathcal{F}_{o,i}) \tag{258}$$

$$= \epsilon_{o,i} \sum_{a} j_{a}^{+} [1 - \exp(-\Delta S_{a})] d_{a}^{o,i} (T \mathcal{F}_{o,i})$$
 (259)

where  $\epsilon_o \equiv -1$  and  $\epsilon_i \equiv 1$  reflect the fact that the output is delivered against an external load  $\mathcal{F}_o < 0$ . Expressed in terms of a cycle-specific work input

$$w_{i,a} \equiv \mathcal{F}_i d_a^i \tag{260}$$

and work output

$$w_{o,a} \equiv -\mathcal{F}_o d_o^o, \tag{261}$$

the power can also be written as [496]

$$P_{o,i} = \sum_{a} j_a^{+} [1 - \exp(w_{i,a} - w_{o,a})] Tw_{\{o,i\}_a}.$$
 (262)

In the contribution of each cycle, the expressions (259, 262) separate a system specific kinetic prefactor,  $j_a^+ = j_a^+(\{\mathcal{F}_k\})$ , from the remaining thermodynamic quantities.

10.3.2. Efficiency and efficiency at maximum power (EMP) The efficiency of a machine is defined as the ratio

$$\eta \equiv P_o/P_i. \tag{263}$$

It has occasionally been argued that the traditional definition of efficiency (263) should be modified for molecular motors pulling cargo in order to include the "work" required for overcoming Stokes friction even in the absence of an external force [497, 498]. More recently, a "sustainable" efficiency has been suggested as an alternative concept [499, 500]. In this review, we keep the traditional expression (263).

For the paradigmatic case of just two non-zero affinities, the entropy production rate (257) becomes

$$\sigma = (P_i - P_o)/T \ge 0 \tag{264}$$

implying that efficiency of isothermal machines is bounded by  $0 \le \eta \le 1$ . Working at the highest possible efficiency comes at the cost of zero delivered power since reaching the thermodynamic bound requires a quasi-static, i.e., infinitely slow operation. A practically more relevant question then is about efficiency at maximum power.

The notion of efficiency at maximum power (EMP) requires one or several parameters  $\{\lambda_i\}$  with respect to the variation of which  $P_o$  can become maximal, i.e.,  $P_o^* \equiv \max_{\{\lambda_i\}} P_o \equiv P_o(\{\lambda_i^*\})$ . EMP is then given by

$$\eta^* \equiv P_o^* / P_i(\{\lambda_i^*\}). \tag{265}$$

In general, the result for EMP will depend strongly both on the choice and the allowed range of the variational parameters  $\{\lambda_i\}$  [496, 501] which is a fact occasionally ignored when statements about the EMP are made. In particular, one should distinguish variation with respect to the externally imposed affinities from those with respect to structural or intrinsic parameters of the machine. Examples for the latter are the topology of the network and common prefactors for forward and backward rates that leave their ratio and thus the thermodynamics invariant.

#### 10.4. Linear response: Relation to phenomenological irreversible thermodynamics

At this point, it is instructive to consider a machine operating close to equilibrium and to cast the results into the framework of linear irreversible thermodynamics [502, 503]. This theory truncates an expansion of the fluxes in the first order of the affinities, i.e., assumes that

$$J_k = \sum_{l} L_{kl} \mathcal{F}_l \tag{266}$$

with the Onsager coefficients  $L_{kl}$ . By expanding (255) for small affinities and using (254), we obtain for the Onsager coefficients the cycle representation

$$L_{kl} = \sum_{a} j_a^{+\text{eq}} d_a^k d_a^l. \tag{267}$$

Here,  $j_a^{+\text{eq}} \equiv j_a^+(\{\mathcal{F}_k\} = 0)$  is the equilibrium forward current of a cycle a. In this approach, the Onsager symmetry  $L_{kl} = L_{lk}$  is satisfied automatically. Similarly, the rate of total entropy production (257) becomes

$$\sigma \approx \sum_{a} j_a^+ (\Delta S_a)^2 = \sum_{kl} L_{kl} \mathcal{F}_k \mathcal{F}_l.$$
 (268)

In this lowest order, power input and output (259) become

$$P_{o,i} = \epsilon_{o,i} J_{o,i}(T\mathcal{F}_{o,i}) = \epsilon_{o,i} T \sum_{k} L_{\{o,i\}k} \mathcal{F}_k \mathcal{F}_{o,i}.$$
 (269)

In the paradigmatic case of two affinities, for fixed input affinity  $\mathcal{F}_i > 0$  and choosing the output affinity as variational parameter  $\mathcal{F}_o$ , maximum power is reached for

$$\mathcal{F}_o^* = -L_{oi}\mathcal{F}_i/2L_{oo} \tag{270}$$

leading to an EMP of [504]

$$\eta^* = L_{oi}^2 / [4L_{oo}L_{ii} - 2L_{oi}L_{io}] \le 1/2.$$
(271)

The upper bound imposed by the positivity of entropy production is realized for a degenerate matrix of Onsager coefficients,

$$L_{oo}L_{ii} = L_{oi}L_{io}, (272)$$

which implies that  $J_o \sim J_i$ . Possible realizations of this structural condition are (i) all unicyclic machines and (ii) tightly coupled multicyclic machines. These two classes and the third one of weakly coupled multicyclic machines will be defined and discussed in the next sections.

#### 10.5. Unicyclic machines

Unicyclic machines consist of only one cycle which allows to drop the cycle index a in this section, see Fig. 3 for an example. In general, the power delivered and used by a unicyclic motor becomes with (262)

$$P_{o,i} = Tj^{+}[1 - e^{w_o - w_i}]w_{o,i}. (273)$$

Its efficiency  $\eta \equiv w_o/w_i$  depends thus trivially only on the externally imposed affinities  $\mathcal{F}_k$  and the intrinsic properties  $d^{o,i}$  but is independent of the detailed kinetics. In the regime  $0 < w_o < w_i$ , the motor will work as intended. For  $w_o = w_i$ , the motor has optimal efficiency  $\eta = 1$  but does not deliver any power since it then cycles as often in forward as in backward direction.

The concept of EMP requires to identify the admissible variational parameters. A simple and physically transparent choice is to fix the input  $w_i$  and vary the output  $w_o$ , e.g., by changing the applied force or torque in the case of a molecular motor. The condition  $dP_o/dw_o = 0$  leads to the implicit relation [496]

$$w_i = w_o^* + \ln[1 + w_o^*/(1 + x_o w_o^*)] \tag{274}$$

for the optimal output  $w_o^*$  at fixed input  $w_i$  with

$$x_o \equiv d \ln j^+ / dw_o \approx x_o^{\text{eq}} + O(w_i, w_o). \tag{275}$$

These expressions can easily be evaluated for any unicyclic machine with specified rates which determine the non-universal  $j^+$ .

The linear response regime is defined by the condition  $w_o < w_i \ll 1$ . By expanding (274), one obtains

$$\eta^* = w_o^* / w_i \approx 1/2 + (x_o^{\text{eq}} + 1/2) w_i / 8 + O(w_i^2)$$
(276)

which shows how system specific features like the coefficient  $x_o^{\text{eq}}$  enter EMP beyond the universal value 1/2. This expression proves that, depending on the value of the non-universal parameter  $x_o^{\text{eq}}$ , EMP may well rise beyond the linear response regime as found first in a case study of molecular motors [505]. These results seem to be at variance with another study along similar lines where a universal bound of 1/2 was found for EMP [499]. The difference, however, is that the latter authors constrain the optimization to a parameter space that leaves the stationary distribution invariant which seems to be a somewhat artificial condition. Further analytical and numerical results for EMP of unicyclic machines using  $w_o$  or both,  $w_i$  and  $w_o$ , as variation parameters can be found in [496]. Bounds on EMP on simple unicyclic machines have been derived in [506].

#### 10.6. Multicyclic machines: Strong vs weak coupling

A discussion of multicylic machines along similar lines does not require much additional conceptual effort [496]. The crucial distinction becomes the one between "strong" (or tight) and "weak" (or loose) coupling first introduced within the phenomenological linear response treatment in [504] and later stressed by van den Broeck and co-workers mostly in the context of heat engines as reviewed in the next section. In a strongly coupled multicylic machine, any cycle containing the input transition also contains

the output transition (assuming for simplicity that input and output affect only one transition each). For such strongly coupled machines exactly the same formalism as for unicyclic machines applies with the only caveat that  $j^+$  appearing there is now given by  $j^+ \equiv \sum_a j_a^+$  where the sum runs over all cycles that include input and output transition and the  $j_a^+$  are the corresponding forward cycle currents. Thus, such strongly coupled machines obey the same relations for efficiency and EMP as unicyclic machines.

In the weak coupling case, there are cycles containing the input but not the output transition. Running through such a cycle the machine "burns" the input without delivering any output which clearly decreases the efficiency. In particular, it turns out that in the linear response regime, EMP is less that 1/2, but may still rise when moving deeper into the non-equilibrium regime [496].

#### 10.7. Efficiency and EMP of molecular motors

One important class of potential applications of the theory just described are molecular motors that transform chemical energy into mechanical energy (or vice versa). As mentioned in the introductory section above, two general types of models must be distinguished for these systems.

For dynamics on a discrete set of states, efficiency (rather than EMP) has been investigated recently for various models [507, 508]. Genuine EMP has been studied for both the simplest unicyclic and a simple multicycle network in [505]. It would be interesting to do so for more intricate models like, e.g., the one introduced in [405], but also for artificial swimmers like the one discussed in [509].

Traditionally, efficiency of molecular motors has been studied within ratchet models where the motor undergoes a continuous motion in a periodic potential that depends on the current chemical state of the motor [510, 511, 413, 414, 415, 416]. Dissipation then involves both, the continuous degree of freedom which should be treated along the lines discussed in Sect. 2 and the discrete switching of the potential due to an enzymatic event. Model systems of this type have been investigated in [403, 512, 513, 514, 515]. For a recent study of EMP in such a continuum description, see [516].

There is a second motivation for studying such models combining discrete with continuous dynamics. In the typical experimental set-up for measuring the efficiency of a molecular motor under load, an external force or torque is applied to a micron-sized bead that is connected to the molecular motor like in the recent example of the rotary motor F1-ATPase [482, 483, 517]. The discrete nano-sized steps of the motor become visible only through monitoring the biased Brownian motion of the bead which clearly is continuous. For a comprehensive description, both dissipation in the discrete steps of the motor and the one associated with the continuous motion of the bead should be combined [518].

#### 11. Efficiency of stochastic heat engines

#### 11.1. Carnot, Curzon-Ahlborn and beyond

In classical thermodynamics, a heat engine, delivering work -W by extracting heat  $-Q_1$  from a hot bath at temperature  $T_1$  and releasing heat  $Q_2$  into a cold bath at

temperature  $T_2$ , has an efficiency

$$\eta \equiv |W|/|Q_1| \le \eta_C \equiv 1 - T_2/T_1$$
(277)

limited by the Carnot efficiency  $\eta_C$  which provides a universal bound that follows from combining the first with the second law. Reaching the upper bound comes at the price of zero power since this condition requires a quasistatic, i.e., infinitely slow operation. A practially more relevant efficiency is the one at maximum power,  $\eta^*$ , which becomes well-defined only if the parameter space available for the maximization is specified. For macroscopic thermodynamics, introduction of this problem is often attributed to Curzon and Ahlborn [519] even though their result has been described earlier, see [520] and the comment made in Ref.1 of [501]. Subsequent work for macroscopic engines pursued under the label of finite-time thermodynamics is reviewed in [521, 522, 523, 524].

Curzon and Ahlborn (CA) assume ordinary heat conduction between the baths and the engine that is supposed to operate without further internal losses. By optimizing the power with respect to (i) the temperature difference responsible for the heat exchange between the baths and the machine, and (ii) the duration of the two isothermal steps (while fixing a constant ratio between the time allocated to isothermal and adiabatic steps) they obtained for EMP the expression

$$\eta_{CA} \equiv 1 - (T_2/T_1)^{1/2} \approx \eta_C/2 + \eta_C^2/8 + O(\eta_C^3).$$
(278)

which is independent of the thermal conductivities between baths and engine.

Whether or not the CA result can claim more universality that under the original "endoreversible" assumptions, or is even a bound on EMP, is a subtle, if not even ill-defined, issue since maximum power depends crucially on the admissible parameter space. Beyond the original assumption there are conditions like for a cascade of intermediate engines [525, 526] and for "weak symmetric dissipation" [527] where CA can be shown to hold for a rather reasonable choice of variational conditions. Numerical simulations of finite-time Carnot cycles for a weakly interacting gas have been analyzed for efficiency and EMP in [528, 529, 530].

A related question is the range of universal validity of the expansion in (278) for EMP. For tightly coupled machines defined by an output work flux that is proportional to the heat flux taken from the hot reservoir, the leading term,  $\eta_C/2$ , follows from simple linear irreversible thermodynamics for fixed input and variable output [504]. Such a result will hold both for macroscopic as for small engines.

The question of efficiency and EMP are indeed as relevant and applicable to small engines or devices as they are for macroscopic ones. The new aspect concerns the role of fluctuations not in the sense that a fluctuating efficiency is defined which might lead to ill-defined results given the fact that sometimes the heat taken from the hot bath would be zero or even negativ. One rather keeps the definition (277) but now W and Q are mean values that are determined by averaging over the fluctuations.‡ A main advantage of a stochastic approach compared to the macroscopic phenomenological one is the fact that a thermodynamically consistent kinetics valid beyond the linear response regime can easily be imposed.

Whether the CA result has any relevance to these small thermal engines has been one of the main issues in the field especially since the coefficient 1/8 in the second term

<sup>‡</sup> The inequality (277) is a trivial consequence of the IFT for total entropy production, if the latter quantities are expressed by fluctuating work and heat contributions [531].

of an expansion of efficiency at maximum power in η<sup>C</sup> was found in quite different systems [261, 532]. For autonomous machine, i.e., in the steady state regime, the 1/8 is indeed universal if the system possesses an additional (left-right) symmetry [533]. It should be stressed, however, that getting this coefficient requires a second (intrinsic or structural) variational parameter beyond the output control required for getting the 1/2. For such steady state machines, beyond the second term in the expansion (278), the full CA result is irrelevant.

On the other hand, for small cyclic machines, which can be treated formally in a spirit closer to CA's original approach, obtaining the factor 1/8 requires a symmetry in the exchange with the hot and cold bath [533]. Moreover, for such a machine it is possible to obtain the CA result over the full temperature range for certain conditions [261, 533].

In the following, we decribe paradigmatically how small heat engines or devices fit into the stochastic framework from which these and further results for both autonomous (steady state) and periodically driven machines can easily be derived. We focus on both the formal similarities and differences with the isothermal machines and the issue of efficiency of maximum power.S Even though we restrict the following discussion to heat engines, similar concepts can be applied to refrigerators, see, e.g., [535].

## 11.2. Autonomous heat engines

For understanding both the general issues and the necessary ramifications of the comparably simpler framework introduced in Sect. 10 for the isothermal case, it is helpful to have a few specific examples in mind.

11.2.1. B¨uttiker-Landauer (BL) and Feynman ratchet Transport of a colloidal particle in a periodic potential can be induced by an external force at constant temperature as discussed in Sect. 2. As an alternative, in the absence of an external force, a spatially periodic temperature profile (out of phase with the potential) will also lead to net motion as discussed by B¨uttiker [536], van Kampen [537] and Landauer [538]. This set-up is one example of noise-induced transport which is comprehensively reviewed by Reimann [415]. From a more thermodynamic perspective, and in the presence of an additional opposing external force, such a B¨uttiker-Landauer (BL) ratchet is a simple example for a stochastic heat engine that transforms heat into mechanical work. One can then ask for the efficiency of such a device which is a subtle question especially when using the overdamped limit for a discontinuous temperature profile [14, 539, 540, 541, 542, 543]. The optimization of such a device for maximal power has been studied both for variation of the external force [544, 545] and for variation of the intrinsic potential [546, 547]. These issues become technically simpler in discretized versions [532, 548, 549, 550, 551] as in the simple model sketched and described in Fig. 7. This system can also be seen as a simplified (one degree of freedom) version of the famous Feyman ratchet [552] that as a paradigm for rectification of thermal noise has its own conceptual subtleties [553, 14]. The Feynman ratchet has inspired various model systems which have been analyzed both analytically and in numerical simulations [554, 555].

S Universality of the efficiency if other quantities are optimized has been studied in [534].

![](_page_76_Picture_1.jpeg)

Figure 7. In a BL ratchet, a particle preferentially climbs a potential barrier with height E over a distance d1 while in contact with a heat bath at T1. It slides down a distance d2 on the cold side with T2 = T1 − ∆T. This temperature-difference driven motion to the right persists for a small enough force f < 0 pulling to the left.

![](_page_76_Picture_3.jpeg)

Figure 8. In a thermoelectric device, simplified here as a quantum dot with a single relevant energy level E, electrons are transported on average from a hot reservoir with µ1 and T1 to a cold reservoir with µ2 = µ1 + ∆µ > µ1 and T2 = T1 − ∆T using heat from the hot reservoir.

From an experimental perspective, realizing such a ratchet in aqueous solution is not straightforward since one needs significant temperature differences on rather small length scales as realized in single particle studies of thermophoresis, see, e.g., [556].

11.2.2. Electronic devices In electronic devices, temperature differences can more easily be imposed as it is done, e.g., in thermoelectrics where temperature differences are exploited to transport electrons against an electro-chemical potential. For such systems, thermodynamic considerations have been emphasized by Linke and coworkers who pointed out that such machines can indeed operate at the Carnot limit [557, 558]. More recent studies based on simple models for quantum dots have addressed in particular the issue of efficiency at maximum power [559, 560, 561]. The simple paradigm discussed in [559] is sketched in Fig. 8.

A particularly intriguing aspect of such devices is the observation that in the presence of a magnetic field the Onsager-Casimir symmetry relations, in principle, seem to allow Carnot efficiency at finite power [562]. This issue deserves further study through the analysis of microscopic models as the one suggested in [563].

Likewise, any photo-electric device is also coupled to a reservoir of rather high temperature since the photons being absorbed from the sun come with the black-body distribution of the sun's temperature. Therefore, photo-electric devices are amenable to a thermodynamic description focussing of efficiency and EMP, see, e.g., [564].

![](_page_77_Picture_1.jpeg)

Figure 9. Common three-state diagram for the simplified BL ratchet (Fig. 7) and the thermo-electric device (Fig. 8). For the BL-ratchet L and R refer to the particle sitting in the minimum and E corresponds to the particle being on the barrier top. For the electronic device, L and R refer to the electron being in the left or right reservoir. E corresponds to the electron sitting on the quantum dot. In both cases, the state R should be identified with L after the electron or particle has been transported from left to right thus completing the cycle. The log-ratio of the transition rates is given in Tab. 2.

11.2.3. General theory For any discrete autonomous heat engines in contact with heat baths of at least two different temperatures, it must be specified for each transition at which temperature it takes place, i.e., with which heat bath the machine is in contact at this particular transition. As in the isothermal case, the assumption of local detailed balance implies thermodynamic constraints on the ratios of forward and backward rates as given in Fig. 9 and Tab. 2 for the two examples introduced above.

The thermodynamic constraints imply that the total entropy production along a cycle still fulfills (251). For the representation (254), one needs the affinities with the corresponding conjugate distances entering the conjugate fluxes given for the two examples in Tab. 3. The general differences compared to the isothermal case arise from the presence of (at least) two different temperatures. First, there is a new affinity associated with the two heat baths with energy flow as the corresponding

**Table 2.** Ratio of rates for the devices shown in Figs. 7 and 8 with their network representation Fig. 9.

|                        | $\ln w_1^+ / w_1^-$ | $\ln w_2^+ / w_2^-$ |
|------------------------|---------------------|---------------------|
| BL ratchet             | $-(E+ f d_1)/T_1$   | $(E -  f d_2)/T_2$  |
| thermo-electric device | $(\mu_1 - E)/T_1$   | $(E - \mu_2)/T_2$   |

**Table 3.** Characteristic quantities for the two example of unicyclic heat engines shown in Figs. 7 and 8.

|                | relevant affinities     | $\mathcal{F}_k$ in                       | conjugate      | Input                      | Output          |
|----------------|-------------------------|------------------------------------------|----------------|----------------------------|-----------------|
|                | $\mathcal{F}_k$         | linear response                          | distance $d^k$ | $-\bar{q}^{(1)} = T_2 w_i$ | $T_2w_o$        |
| BL             | $1/T_2 - 1/T_1$         | $\Delta T/T_2^2$                         | E              | $E +  f d_1$               |                 |
| ratchet        | $f/T_1, f/T_2$          | $f/T_2, f/T_2$                           | $d_1, d_2$     |                            | $ f (d_1+d_2)$  |
| thermoelectric | $1/T_2 - 1/T_1$         | $\Delta T/T_2^2$                         | E              | $E-\mu_1$                  |                 |
| device         | $\mu_1/T_1 - \mu_2/T_2$ | $-(\Delta\mu/T_2 + \mu_1\Delta T/T_2^2)$ | 1              |                            | $\mu_2 - \mu_1$ |

flux. Second, if matter is transported between baths of different chemical potential and different temperature, the corresponding affinity involves the two temperatures. As a consequence, in linear response, the latter affinity carries both a  $\Delta\mu$  and a  $\Delta T$  term. Finally, a force applied to a particle in a thermal ratchet subject to two different temperature requires to introduce even two affinities with this force. As in the isothermal case, for an autonomous heat engine the total entropy production rate can be expressed by affinities and conjugate fluxes according to (257).

On the cycle level, the total entropy change becomes

$$\Delta S_a = \bar{q}_a^{(1)}/T_1 + \bar{q}_a^{(2)}/T_2, \tag{279}$$

where we use the heat as appropriate under NESS conditions which fulfills first laws of the type

$$w_a^{\text{mech}(1,2)} + w_a^{\text{chem}(1,2)} = \bar{q}_a^{(1,2)} + \Delta E_a^{(1,2)}$$
(280)

where  $\Delta E_a^{(1)} = -\Delta E_a^{(2)}$  is the change in internal energy of the system arising from the transitions associated with the respective heat baths labelled by superscripts. With this relation, the total entropy change along a cycle (279) can also be expressed by the heat extracted from the hot reservoir as

$$\Delta S_a = -\bar{q}_a^{(1)} \eta_C / T_2 + (w_a^{\text{mech}} + w_a^{\text{chem}}) / T_2 \equiv w_{i,a} \eta_C - w_{o,a}, \tag{281}$$

where the work terms refer to the sum of the contributions from the respective bath contacts. The definition of dimensionless input  $w_{i,a}$  is motivated by the fact that for a heat engine the input is the heat extracted from the hotter bath. Dimensionless output denoted by  $w_{o,a}$  is either mechanical or chemical work delivered by the machine.

The power of the machine can now be expressed analogously to the isothermal case as

$$P_{o,i} = \epsilon_{o,i} \sum_{a} j_a^{+} [1 - \exp(-w_{i,a}\eta_C + w_{o,a})] T_2 w_{\{o,i\}a}.$$
 (282)

where the occurence of the Carnot efficiency  $\eta_C$  in the exponent compared to the isothermal case (262) is crucial. In the affinity representation, the difference to the isothermal case is even more drastic since output and input power can no longer be written as simple products of a pair of conjugate flux  $J_{o,i}$  and affinity  $T\mathcal{F}_{o,i}$  as in (259). One could have anticipated this complication since with two baths it is not obvious which temperature should be chosen in (259) when trying to generalize to the non-isothermal case.

11.2.4. EMP for unicyclic machines For unicyclic machines (and hence dropping the cycle index a), maximizing the power  $P_o$  with respect to the output  $w_o$ , which would physically correspond to varying the external force or chemical potentials, leads to the analogue of (274) in the form

$$w_i = (w_o^* + \ln[1 + w_o^*/(1 + x_o w_o^*)])/\eta_C. \tag{283}$$

This relation implies immediately the universal  $\eta^* \equiv w_o^*/w_i \approx \eta_C/2 + O(\eta_C^2)$  in the linear response regime which can also easily be obtained from a phenomenological treatment analogously to the one presented in Sect. 10.4 [525].

Maximizing the power with respect to the input variable  $w_i$  leads to

$$w_i^* = [w_o^* + \ln(1 - \eta_C/x_i)]/\eta_C \tag{284}$$

with

$$x_i \equiv d \ln j^+ / dw_i \approx x_i^{\text{eq}} + O(\eta_C, w_o). \tag{285}$$

As the respective column in Tab. 3 show,  $w_i$  involves an intrinsic parameter of the machine like the relevant energy level. Combining the relations (283,284) and varying both  $w_o$  and  $w_i$  leads to the EMP

$$\eta^{**} = \eta_C / [1 - (x_o + x_i / \eta_C) \ln(1 - \eta_C / x_i)]$$
(286)

$$\approx \eta_C/2 - [(2x_o^{\text{eq}} + 1)/x_i^{\text{eq}}]\eta_C^2/8 + O(\eta_C^3)$$
(287)

which shows that the second order coefficient is system-specific.

It can be checked that for a unicyclic device with spatial symmetry, for which the current j reverses sign when the affinities  $\mathcal{F}_k$  change sign, the square-bracket prefactor of the second term is indeed -1 thus recovering the overall 1/8 as previously derived by extending the phenomonological irreversible thermodynamics approach to second order [533].

For an explicit evaluation of the EMP (286) one needs the specific form of  $x_{o,i} = x_{o,i}(w_o, w_i)$  which requires assumptions on the specific rates beyond the constraints imposed by thermodynamics exploited so far. For the mechanical BL ratchet, it is interesting to note that even for  $d_1 \neq d_2$ , an explicit calculation for  $w_2^+ = w_1^- = 1$  (and the other rates as given in Tab. 2) recovers the coefficient 1/8 despite the obvious breaking of the left-right symmetry. The case  $d_2 = 0$  is discussed for the full temperature range in [532], where, not surprisingly, deviations from the CA result are found. The thermoelectric device is treated in [533, 559]. For a photo-electric device, explicit results can be found in [564], where also the role of non-radiative transition is discussed. Further examples of EMP in a three and five state network have been discussed in [501].

#### 11.3. Periodically driven heat engines

The autonomous machines just discussed reach a NESS since they are permanently connected to both heat baths. For a periodically driven heat engine, contact with either one bath or, in an adiabatic step, with none, is periodically enforced externally.

11.3.1. Brownian heat engine Within stochastic thermodynamics such a model was introduced in [261] for a Brownian particle in a time-dependent potential, see Fig. 10. Optimizing for both, the potential and the time-interval spent in the isothermal transitions, EMP for fixed  $T_{1,2}$  was shown to be

$$\eta^* = \eta_C / (2 - \alpha \eta_C) \approx \eta_C + (\alpha/4) \eta_C^2 + O(\eta_C^3)$$
 (288)

where

$$\alpha \equiv 1/[1 + (\mu(T_1)/\mu(T_2))^{1/2}] \tag{289}$$

is a system-specific coefficient given by the temperature-dependence of the mobility  $\mu(T)$ . If the latter is independent of temperature, one recovers the coefficient 1/8. Since  $0 \le \alpha \le 1$ , the expression (288) implies the bounds

$$\eta_C/2 < \eta^* < \eta_C/(2 - \eta_C)$$
 (290)

on EMP later also derived under the assumption of "weak" dissipation which leads to a quite similar formalism [527, 565]. Further ramifications and classifications of such

![](_page_80_Figure_1.jpeg)

Figure 10. Paradigm for a stochastic heat engine based on a colloidal particle in a time-dependent harmonic laser trap in consecutive contact with a hot (Th) and cold (Tc) bath [261]. The steps 1 and 3 are isothermal; the steps 2 and 4 are instantanous and adiabatic during which the distributions are p<sup>b</sup> and pa, respectively.

bounds have been discussed by Wang and Tu [566, 567] and in [568]. The Onsager coefficients for a linear response treatment of this heat engine have been defined and calculated in [569].

A micron-sized heat engine based on the Stirling version of the scheme shown in Fig. 10 has just been realized experimentally [570]. The colloidal particle as "working fluid" in a laser trap acting as the analogue of a piston can be heated locally thereby realizing the contact with a hot bath. By varying the cycle time both a maximum in the power at finite time and the approach to the maximal efficiency in the quasi-static limit could be demonstrated. For further interesting comments on this experiment, see [571].

11.3.2. Quantum dot A similar analysis can be applied to a finite-time Carnot cycle of a quantum dot that can be connected to two different reservoirs similar as the set-up shown in Fig. 8 [572]. For a cyclic engine, the energy level E(τ) is controlled in both the isothermal steps when the dot is connected to either one bath and in the adiabatic steps when it is disconnected. Optimizing for the protocol E(τ) as well as for the duration of isothermal and adiabatic steps, one finds for EMP an expression similar to (288). In the limit of weak dissipation, i.e., for small deviations from the respective thermal population of the energy level, and symmetric conditions, the coefficient α turns out to be α = ηCA/η<sup>C</sup> and hence one can here recover the CA result over the full temperature range. The distributions of work and heat for such a simple two-state engine have been calculated in [573].

## 12. Concluding perspective

After this long exposition it may be appropriate to recall the basic assumption of this approach, to summarize the main achievements and to raise a few open general issues.

#### 12.1. Summary

Stochastic thermodynamics applies to systems where a few observable degrees of freedom like the positions of colloidal particles or the gross conformations of

biomolecules are in non-equilibrium due to the action of possibly time-dependent external forces, fields, flow or unbalanced chemical reactants. The unobserved degrees of freedom like those making up the aqueous solution, however, are assumed to be fast and thus always in the constrained equilibrium imposed by the instantaneous values of the observed slow degrees of freedom. Then internal energy, intrinsic entropy and free energy are well-defined and, if a microscopic Hamiltonian was given, in principle, computable for fixed values of the slow variables. This assumption is sufficient to identify a first-law like energy balance along any fluctuating trajectory recording the changing state of the slow variables.

Entropy change along such a trajectory consists of three parts: heat exchanged with the bath, intrinsic entropy of the states and stochastic entropy. The latter requires in addition an ensemble from which this trajectory is taken. If the same trajectory is taken from a different ensemble it leads to a different stochastic entropy. Thermodynamic consistency of the Markovian dynamics generating the trajectory imposes a local-detailed balance condition constraining either the noise in a Langevintype continuum dynamics or the ratio of transition rates in a discrete dynamics.

At their core, the fluctuation theorems are mathematical identities derived from properties of the weight of stochastic paths under time reversal or other transformations. They acquire physical meaning by associating the mathematical ingredients with the thermodynamic quantities identified within stochastic thermodynamics. The detailed fluctuation theorems then express a symmetry of the distribution function for thermodynamic quantities. An open question is whether the probability distributions of work, heat and entropy production can be grouped into "universality classes" characterized, e.g., by the asymptotics of such distributions, and, if yes, which specific features of a system determine this class. The more generally applicable integral theorems often can be expressed as refinements of the second law for transitions between certain states. Still, these integral fluctuation theorems should not be considered a "proof" of the second law since irreversibility has been implemented consistently from the beginning by choosing a stochastic dynamics including the local detailed balance condition.

Conceptually, a major step has been to include feedback schemes based on perfect or imperfect measurements into this framework which requires surprisingly little additional effort due to the strong formal similarity of stochastic entropy with information. Still missing is a full integration of measurement apparatus and the erasure process into the thermodynamic balance of the efficiency for specific information machines.

The crucial ingredient for the developments summarized so far is the notion of an individual trajectory and the concomitant concept of distributions for thermodynamic quantities which represents the main difference compared to classical thermodynamics.

New insights, however, have emerged from this approach even when focussing on averages and correlation functions as we have done in the second part of the review. The general fluctuation-dissipation theorem for non-equilibrium steady states shows how the response of any observable to a perturbation can be expressed as a sum of two correlation functions involving entropy production. In which cases this additive relation between response and correlation can be reformulated as a multiplicative one using the concept of an effective temperature is still not understood despite some insights gained from specific case studies.

Our discussion of molecular motors, machines and devices centered on the notion of efficiency and efficiency at maximum power. Despite the fundamental difference of

isothermal engines operating at one temperature as do all cellular ones from genuine heat engines like thermoelectric devices involving two baths of different temperature, a common framework exists based on the representation of entropy production in terms of cycles of the underlying network of states. Clearly, more realistic networks need to be studied in the future, in particular, for applications and modelling of specific biophysical systems but the basic concepts seem to be identified. One particulary intriguing perspective comes from the recent analysis of the energetic cost of sensory adaptation using the concepts of stochastic thermodynamics [574].

## 12.2. Beyond a Markovian dynamics: Memory effects and coarse-graining

The identification of states, of work and of internal energy, i.e., of the ingredients entering the first law on the level of trajectories is logically independent of the assumption of a Markovian dynamics connecting these states. The crucial step is the splitting of all degrees of freedom in slow and fast ones, the latter always being in a constraint equilibrium imposed by the instantaneous values of the slow ones. Likewise, the identification of entropy production only requires the notion of an ensemble which determines stochastic entropy along an individual trajectory. Any dynamics guaranteeing that for fixed external parameters compatible with genuine equilibrium, this equilibrium will be reached for an arbitrary initial distribution of the slow variables could qualify as a thermodynamically consistent one.

12.2.1. Continuous states A popular choice for a non-Markovian dynamics obeying these constraints is Langevin dynamics with a memory kernel that, for thermodynamics consistency, determines the correlations of the coloured noise.k Under this assumption, the notions of stochastic thermodynamics are well-defined and the various fluctuation theorems hold true as shown quite generally in [343, 578, 579, 580, 581]. Some of these papers contains illustrations for model systems as do the references [582, 583, 584]. One specific motivation to explore such a dynamics arises from the recent fascinating experimental data that show how hydrodynamic effects lead to a frequency dependent mobility for colloidal motion [585].

A somewhat different and more subtle situation occurs if not all slow variables are accessible in the experiment or the simulation. The effective dynamics for the observable ones will then no longer be Markovian and its specific form in the case on non-harmonic interactions between the slow one is typically not accessible. The proper identification of, e.g., entropy production is then difficult if not impossible. Still, one might be inclined to infer an apparent entropy production by applying the rules for Markovian dynamics and to check whether this quantity obeys the FT. In a recent study using two coupled driven colloidal particles it turned out that the apparent entropy production based on the observation of just one particle shows an FT-like symmetry but with a different prefactor for a surprisinglingly large range of parameter values. However, there are also clear cases for which not even an effective FT can be identified [586]. This type of coarse-graining in the context of the FDT for a NESS has been explored in [587].

k Stochastic thermodynamics for a non-Markovian dynamics not obeying such a constraint has been explored for generalized Langevin equations in [575, 343], for delayed Langevin systems in [576], and for Poissonian shot noise in [577].

12.2.2. Discrete states For an underlying dynamics on a discrete set of states following a Markovian master equation, one option for coarse-graining is to group several states into new "meso-states" or aggregated states. Typically, the dynamics between these meso-states is then no longer Markovian. One question is whether one can then distinguish genuine equilibrium from a NESS if only the coarse-grained trajectory is accessible. For a three state system coarse-grained into a two-state system, this issue has been addressed in [588, 589] and, for more general cases, in [590, 591].

Coarse-graining of a discrete network becomes systematically possible if states among which the transitions are much faster are grouped together. From the perspective of stochastic thermodynamics, entropy production and fluctuation theorems this approach has been followed in [592, 593, 594, 595, 596, 597, 598, 599].

## 12.3. Coupling of non-equilibrium steady states: A zeroth law?

Besides the first and the second law, classical thermodynamics is founded on a zeroth law stating that the notion of temperature and chemical potential for equilibrium systems is transitive, i.e., if a system A is in separate equilibrium with system B and system C, then upon contact of B and C neither heat nor particle flow will occur between these two systems. A natural question is whether a similar equilibration also occurs for non–equilibrium systems brought in contact such that they can exchange energy or particles. Do then quantities exist resembling temperature or chemical potential that govern "equilibration" between such steady states? On a phenomenological level this question has been introduced within the context of steady state thermodynamics by Oono and Paniconi [46] and further refined by Sasa and Tasaki [47]. For simple one-dimensional model systems like zero-range processes in contact a non-equilibrium chemical potential is indeed well-defined [600]. For twodimensional driven lattice gases in contact, numerical work has revealed that in a large parameter range such a putative zeroth law and a corresponding thermodynamic structure is approximately valid [601, 602].

## 12.4. Final remark

From its very beginnings, thermodynamics fascinated scientists by posing deep conceptual issues that needed to be resolved for understanding and optimizing quite practical matters like the design of heat engines. With the experimentally realized micron-sized heat engine [570] discussed in one of the last sections of this review, these latest developments have brought us back to the very origins of classical thermodynamics albeit on quite different time and length scales and, quite importantly, with a much refined view on individual trajectories. Indeed, without the spectacular advances in experimental techniques concerning tracking and manipulation of single particles and molecules, stochastic thermodynamics could still have been conceived as a theoretical framework but would have not reached the broader appeal that it has gained over the last fifteen years. Whether the next decade of research in the field will be dominated by specific applications, most likely for biomolecular networks and devices facilitating transport of all sorts, or by further conceptual work exploring the ultimate limits of a thermodynamic approach to non-equilibrium beyond the Markovian paradigm into feedback-driven, informationprocessing, strongly interacting systems remains to be seen.

## Acknowledgments

I thank T. Speck for a long-standing enjoyable collaboration on several topics treated in this review. Many of my graduate students, in particular, D. Abreu, E. Dieterich, B. Lander, T. Schmiedl and E. Zimmermann have contributed through their thesis works to my understanding of special topics discussed here. I have enjoyed a productive interaction with two experimental groups in Stuttgart headed by C. Bechinger and J. Wrachtrup and their students and post-docs, especially, V. Blickle, J. Mehl and C. Tietz. Discussion on fundamental aspects with C. van den Broeck, M. Esposito, P. H¨anggi, C. Jarzynski, J. Parrondo, F. Ritort, K. Sekimoto, H. Spohn, H. Wagner and R. Zia have always been most inspiring. Funding through DFG and ESF is gratefully acknowledged.

## References

- [1] D. J. Evans, E. G. D. Cohen, and G. P. Morriss. Probability of second law violations in shearing steady states. *Phys. Rev. Lett.*, 71:2401, 1993.
- [2] G. Gallavotti and E. G. D. Cohen. Dynamical ensembles in nonequilibrium statistical mechanics. *Phys. Rev. Lett.*, 74:2694, 1995.
- [3] J. Kurchan. Fluctuation theorem for stochastic dynamics. *J. Phys. A: Math. Gen.*, 31:3719, 1998.
- [4] J. L. Lebowitz and H. Spohn. A Gallavotti-Cohen-type symmetry in the large deviation functional for stochastic dynamics. *J. Stat. Phys.*, 95:333, 1999.
- [5] D. J. Evans and D. J. Searles. Equilibrium microstates which generate second law violating steady states. *Phys. Rev. E*, 50:1645, 1994.
- [6] C. Jarzynski. Nonequilibrium equality for free energy differences. *Phys. Rev. Lett.*, 78:2690, 1997.
- [7] C. Jarzynski. Equilibrium free-energy differences from nonequilibrium measurements: A master-equation approach. *Phys. Rev. E*, 56:5018, 1997.
- [8] G. E. Crooks. Entropy production fluctuation theorem and the nonequilibrium work relation for free energy differences. *Phys. Rev. E*, 60:2721, 1999.
- [9] G. E. Crooks. Path-ensemble averages in systems driven far from equilibrium. *Phys. Rev. E*, 61:2361, 2000.
- [10] G. Hummer and A. Szabo. Free energy reconstruction from nonequilibrium single-molecule pulling experiments. *Proc. Natl. Acad. Sci. U.S.A.*, 98:3658, 2001.
- [11] G. N. Bochkov and Y. E. Kuzovlev. General theory of thermal fluctuations in nonlinear systems. *Sov. Phys. JETP*, 45:125–130, 1977.
- [12] G. N. Bochkov and Y. E. Kuzlovlev. Fluctuation-disspation relations for nonequilibrium processes in open systems. *Sov. Phys. JETP*, 49:543–551, 1979.
- [13] T. Hatano and S. Sasa. Steady-state thermodynamics of Langevin systems. *Phys. Rev. Lett.*, 86:3463, 2001.
- [14] K. Sekimoto. Kinetic characterisation of heat bath and the energetics of thermal ratchet models. *J. Phys. Soc. Jpn.*, 66:1234–1237, 1997.
- [15] K. Sekimoto. Langevin equation and thermodynamics. *Prog. Theor. Phys. Supp.*, 130:17, 1998.
- [16] K. Sekimoto. *Stochastic Energetics*. Springer-Verlag, Berlin, Heidelberg, 2010.
- [17] C. Maes. On the origin and use of fluctuation relations for entropy. *S´em. Poincar´e*, 2:29, 2003.
- [18] C. Maes and K. Netocn´y. Time-reversal and entropy. *J. Stat. Phys.*, 110:269, 2003.
- [19] H. Qian. Mesoscopic nonequilibrium thermodynamics of single macromolecules and dynamic entropy-energy compensation. *Phys. Rev. E*, 65:016102, 2002.
- [20] U. Seifert. Entropy production along a stochastic trajectory and an integral fluctuation theorem. *Phys. Rev. Lett.*, 95:040602, 2005.
- [21] U. Seifert. Stochastic thermodynamics: Principles and perspectives. *Eur. Phys. J. B*, 64:423– 431, 2008.
- [22] C. van den Broeck. Stochastic thermodynamics. In W. Ebeling and H. Ulbricht, editors, *Selforganization by Nonlinear Irreversible Processes. Proceedings of the Third International Conference, K¨uhlungsborn, GDR, March 18-22, 1985*, pages 57–61, Berlin, 1985. Springer.

[23] C. Y. Mou, J.-L. Luo, and G. Nicolis. Stochastic thermodynamics of nonequilibrium steady states in chemical reaction systems. *J. Chem. Phys.*, 84:7011, 1986.

- [24] D. J. Evans and G. P. Morriss. *Statistical mechanics of nonequilibrium liquids*. Cambridge Univ. Press, Cambridge, 2nd edition, 2008.
- [25] M. Esposito, U. Harbola, and S. Mukamel. Nonequilibrium fluctuations, fluctuation theorems, and counting statistics in quantum systems. *Rev. Mod. Phys.*, 81:1665–1702, 2009.
- [26] M. Campisi, P. H¨anggi, and P. Talkner. Colloquium. quantum fluctuation relations: Foundations and applications. *Rev. Mod. Phys*, 83:771–791, 2011.
- [27] C. Bustamante, J. Liphardt, and F. Ritort. The nonequilibrium thermodynamics of small systems. *Physics Today*, 58(7):43, 2005.
- [28] C. Jarzynski. Equalities and inequalities: Irreversibility and the second law of thermodynamics at the nanoscale. *Ann. Rev. Cond. Mat. Phys.*, 2:329–351, 2011.
- [29] C. van den Broeck. The many faces of the second law. *J. Stat. Mech.*, page P10009, 2010.
- [30] H. Qian. Open-system nonequilibrium steady state: Statistical thermodynamics, fluctuations, and chemical oscillations. *J. Phys. Chem. B*, 110:15063–15074, 2006.
- [31] J. Kurchan. Non-equilibrium work relations. *J. Stat. Mech.: Theor. Exp.*, page P07005, 2007.
- [32] A. Imparato and L. Peliti. Work and heat probability distributions in out-of-equilibrium systems. *C. R. Physique*, 8:556–566, 2007.
- [33] R. Klages, W. Just, and C. Jarzynski, editors. *Nonequilibrium Statistical Physics of Small Systems: Fluctuation relations and beyond*. Reviews of Nonlinear Dynamics and Complexity. Wiley-VCH, Weinheim, 2012.
- [34] F. Ritort. Nonequilibrium fluctuations in small systems: From physics to biology. *Adv. Chem. Phys.*, 137:31–123, 2008.
- [35] S. Ciliberto, S. Joubaud, and A. Petrosyan. Fluctuations in out-of-equilibrium systems: from theory to experiment. *J. Stat. Mech.: Theor. Exp.*, page P12003, 2010.
- [36] R. J. Harris and G. M. Sch¨utz. Fluctuation theorems for stochastic dynamics. *J. Stat. Mech.: Theor. Exp.*, page P07020, 2007.
- [37] D. J. Evans and D. J. Searles. The fluctuation theorem. *Adv. Phys.*, 51:1529 1585, 2002.
- [38] G. Gallavotti. *Statistical mechanics. A short treatise.* Springer, Berlin Heidelberg, 1999.
- [39] L. Rondoni and C. Mej´ıa-Monasterio. Fluctuations in nonequilibrium statistical mechanics: models, mathematical theory, physical mechanisms. *Nonlinearity*, 20:R1–R37, 2007.
- [40] F. Zamponi. Is it possible to experimentally verify the fluctuation relation? A review of theoretical motivations and numerical evidence. *J. Stat. Mech.: Theor. Exp.*, page P02008, 2007.
- [41] E.M. Sevick, R. Prabhakar, S. R.Williams, and D. J. Searles. Fluctuation theorems. *Annu. Rev. Phys. Chem.*, 59:603–633, 2008.
- [42] P. Attard. The second entropy: a general theory for non-equilibrium thermodynamics and statistical mechanics. *Annu. Rep. Prog. Chem. Sect. C*, 105:63–173, 2009.
- [43] D. Jou, J. Casas-V´azquez, and G. Lebon. *Extended irreversible thermodynamics*. Springer, New York, Dordrecht, Heidelberg, London, 3rd enlarged edition, 2001.
- [44] H. C. Ottinger. ¨ *Beyond Equilibrium Thermodynamics*. Wiley, Hoboken, New Jersey and Canada, 2004.
- [45] D. Reguera, J. M. Rub´ı, and J. M. G. Vilar. The mesoscopic dynamics of thermodynamic systems. *J. Phys. Chem. B*, 109:21502, 2005.
- [46] Y. Oono and M. Paniconi. Steady state thermodynamics. *Prog. Theor. Phys. Suppl.*, 130:29, 1998.
- [47] S. I. Sasa and H. Tasaki. Steady State Thermodynamics. *J. Stat. Phys.*, 125:125–224, 2006.
- [48] E. Frey and K. Kroy. Brownian motion: a paradigm of soft matter and biological physics. *Ann. d. Physik*, 14:20–50, 2005.
- [49] T. Chou, K. Mallick, and R. K. P. Zia. Non-equilibrium statistical mechanics: from a paradigmatic model to biological transport. *Rep. Prog. Phys.*, 74:116601, 2011.
- [50] C. W. Gardiner. *Handbook of Stochastic Methods*. Springer-Verlag, Berlin, 3rd edition, 2004.
- [51] H. Risken. *The Fokker-Planck Equation*. Springer-Verlag, Berlin, 2nd edition, 1989.
- [52] M. Chaichian and A. Demichev. *Path integrals in physics. Volume I: Stochastic processes and quantum mechanics*. Institute of Physics publishing, Bristol and Philadelphia, 2001.
- [53] M. Chaichian and A. Demichev. *Path integrals in physics. Volume II: Quantum field theory, statistical physics and other modern applications*. Institute of Physics, Bristol and Philadelphia, 2001.
- [54] J. Tailleur, J. Kurchan, and V. Lecomte. Mapping out-of-equilibrium into equilibrium in onedimensional transport models. *J. Phys. A Math. Theor.*, 41:505001, 2008.
- [55] J. M. G. Vilar and J. M. Rubi. Failure of the work-Hamiltonian connection for free-energy

- calculations. *Phys. Rev. Lett.*, 100:020601, 2008.
- [56] L. Peliti. Comment on 'Failure of the work-Hamiltonian connection for free-energy calculations'. *Phys. Rev. Lett.*, 101:098903, 2008.
- [57] L. Peliti. On the workHamiltonian connection in manipulated systems. *J. Stat. Mech.*, page P05002, 2008.
- [58] J. Horowitz and C. Jarzynski. Comment on 'Failure of the work-Hamiltonian connection for free-energy calculations'. *Phys. Rev. Lett.*, 101:098901, 2008.
- [59] T. Speck, J. Mehl, and U. Seifert. Role of external flow and frame invariance in stochastic thermodynamics. *Phys. Rev. Lett.*, 100:178302, 2008.
- [60] C. Jarzynski. Nonequilibrium work relations: foundations and applications. *Eur. Phys. J. B*, 64:331–340, 2008.
- [61] N. Merhav and Y. Kafri. Statistical properties of entropy production derived from fluctuation theorems. *J. Stat. Mech.: Theor. Exp.*, page P12022, 2010.
- [62] E. G. D. Cohen and D. Mauzerall. A note on the Jarzynski equality. *J. Stat. Mech.: Theor. Exp.*, page P07006, 2004.
- [63] C. Jarzynski. Nonequilibrium work theorem for a system strongly coupled to a thermal environment. *J. Stat. Mech.: Theor. Exp.*, page P09005, 2004.
- [64] C. Jarzynski. Comparison of far-from-equilibrium work relations. *C. R. Physique*, 8:495–506, 2007.
- [65] J. Horowitz and C. Jarzynski. Comparison of work fluctuation relations. *J. Stat. Mech.: Theor. Exp.*, page P11002, 2007.
- [66] O. Mazonka and C. Jarzynski. Exactly solvable model illustrating far-from-equilibrium predictions. cond-mat/9912121, 1999.
- [67] T. Speck and U. Seifert. Dissipated work in driven harmonic diffusive systems: General solution and application to stretching rouse polymers. *Eur. Phys. J. B*, 43:543, 2005.
- [68] T. Speck and U. Seifert. Distribution of work in isothermal nonequilibrium processes. *Phys. Rev. E*, 70:066112, 2004.
- [69] J. Hermans. Simple analysis of noise and hysteresis in (slow-growth) free energy simulations. *J. Phys. Chem.*, 95:9029, 1991.
- [70] R. H. Wood, W. C. F. M¨uhlbauer, and P. T. Thompson. Systematic errors in free energy perturbation calculations due to a finite sample of configuration space: Sample-size hysteresis. *J. Phys. Chem.*, 95:6670, 1991.
- [71] D. A. Hendrix and C. Jarzynski. A "fast growth" method of computing free energy differences. *J. Chem. Phys.*, 114:5974, 2001.
- [72] T. Speck. Work distribution for the driven harmonic oscillator with time-dependent strength: exact solution and slow driving. *J. Phys. A: Math. Theor.*, 44:305001, 2011.
- [73] A. Engel. Asymptotics of work distributions in nonequilibrium systems. *Phys. Rev. E*, 80:021120, 2009.
- [74] D. Nickelsen and A. Engel. Asymptotics of work distributions: The pre-exponential factor. *Eur. Phys. J. B*, 82:207–218, 2011.
- [75] A. Saha, J. K. Bhattacharjee, and S. Chakraborty. Work probability distribution and tossing a biased coin. *Phys. Rev. E*, 83:011104, 2011.
- [76] C. Perez-Espigares, A. B. Kolton, and J. Kurchan. An infinite family of second law-like inequalities. *arXiv: 1110.0967*, 2011.
- [77] E. H. Trepagnier, C. Jarzynski, F. Ritort, G. E. Crooks, C. J. Bustamante, and J. Liphardt. Experimental test of Hatano and Sasa's nonequilibrium steady-state equality. *Proc. Natl. Acad. Sci. U.S.A.*, 101:15038, 2004.
- [78] T. Speck and U. Seifert. Integral fluctuation theorem for the housekeeping heat. *J. Phys. A: Math. Gen.*, 38:L581–L588, 2005.
- [79] V. Y. Chernyak, M. Chertkov, and C. Jarzynski. Path-integral analysis of fluctuation theorems for general Langevin processes. *J. Stat. Mech.: Theor. Exp.*, page P08001, 2006.
- [80] R. Chetrite and K. Gawedzki. Fluctuation relations for diffusion processes. *Comm. Math. Phys.*, 282:469–518, 2008.
- [81] H. Ge and D.-Q. Jiang. Generalized Jarzynski's equality of inhomogeneous multidimensional diffusion processes. *J. Stat. Phys.*, 131:675–689, 2008.
- [82] F. Liu and Z.-C. Ou-Yang. Generalized integral fluctuation theorem for diffusion processes. *Phys. Rev. E*, 79:060107, 2009.
- [83] Y. Sughiyama and M. Ohzeki. Extended Jarzynski equality in general Langevin systems. *Physica E*, 43:790–793, 2011.
- [84] T. Schmiedl, T. Speck, and U. Seifert. Entropy production for mechanically or chemically driven biomolecules. *J. Stat. Phys.*, 128:77, 2007.

[85] R. Garc´ıa-Garc´ıa, D. Dominguez, V. Lecomte, and A. B. Kolton. Unifying approach for fluctuation theorems from joint probability distributions. *Phys. Rev. E*, 82:030104(R), 2010.

- [86] P. Maragakis, F. Ritort, C. Bustamante, M. Karplus, and G. E. Crooks. Bayesian estimates of free energies from nonequilibrium work data in the presence of instrument noise. *J. Chem. Phys.*, 129:024102, 2008.
- [87] I. Junier, A. Mossa, M. Manosas, and F. Ritort. Recovery of free energy branches in single molecule experiments. *Phys. Rev. Lett.*, 102:070602, 2009.
- [88] S. Schuler, T. Speck, C. Tietz, J. Wrachtrup, and U. Seifert. Experimental test of the fluctuation theorem for a driven two-level system with time-dependent rates. *Phys. Rev. Lett.*, 94:180602, 2005.
- [89] M. Baiesi, T. Jacobs, C. Maes, and N. S. Skantzos. Fluctuation symmetries for work and heat. *Phys. Rev. E*, 74:021111, 2006.
- [90] C. Tietz, S. Schuler, T. Speck, U. Seifert, and J. Wrachtrup. Measurement of stochastic entropy production. *Phys. Rev. Lett.*, 97:050602, 2006.
- [91] B. H. Shargel and T. Chou. Fluctuation theorems for entropy production and heat dissipation in periodically driven markov chains. *J. Stat. Phys.*, 137:165–188, 2009.
- [92] T. S. Komatsu and N. Kakagawa. Expression for the stationary distribution in nonequilibrium steady states. *Phys. Rev. Lett.*, 100:030601, 2008.
- [93] T. S. Komatsu, N. Nakagawa, and S. Sasa. Steady-state thermodynamics for heat conduction: Microscopic derivation. *Phys. Rev. Lett.*, 100:230602, 2008.
- [94] T. S. Komatsu, N. Nakagawa, S. Sasa, and H. Tasa. Representation of nonequilibrium steady states in large mechanical systems. *J. Stat. Phys.*, 134:401–423, 2009.
- [95] T. S. Komatsu, N. Nakagawa, S. Sasa, and H. Tasaki. Entropy and nonlinear thermodynamic relation for heat conducting steady states. *J. Stat. Phys.*, 142:127–153, 2011.
- [96] M. Colangeli, C. Maes, and B. Wynants. A meaningful expansion around detailed balance. *J. Phys. A Math. Theor.*, 44:095001, 2011.
- [97] A. Imparato and L. Peliti. Fluctuation relations for a driven Brownian particle. *Phys. Rev. E*, 74:026106, 2006.
- [98] K. Turitsyn, M. Chertkov, V.Y. Chernyak, and A. Puliafito. Statistics of entropy production in linearized stochastic systems. *Phys. Rev. Lett.*, 98(180603):180603, 2007.
- [99] P. Pradhan and U. Seifert. Nonexistence of classical diamagnetism and nonequilibrium fluctuation theorems for charged particles on a curved surface. *EPL*, 89:37001, 2010.
- [100] N. Kumar and K. V. Kumar. Classical Langevin dynamics of a charged particle moving on a sphere and diamagnetism: A surprise. *EPL*, 86:17001, 2009.
- [101] M. Esposito and C. van den Broeck. Three detailed fluctuation theorems. *Phys. Rev. Lett.*, 104:090601, 2010.
- [102] M. Esposito and C. van den Broeck. Three faces of the second law. I. Master equation formulation. *Phys. Rev. E*, 82:011143, 2010.
- [103] C. van den Broeck and M. Esposito. Three faces of the second law. II. Fokker-Planck formulation. *Phys. Rev. E*, 82:011144, 2010.
- [104] R. Garc´ıa-Garc´ıa, V. Lecomte, A. B. Kolton, and D. Dominguez. Joint probability distributions and fluctuation theorems. *J. Stat. Mech.: Theor. Exp.*, page P02009, 2012.
- [105] G. Verley, R. Ch´etrite, and D. Lacoste. Inequalities generalizing the second law of thermodynamics for transitions between non-stationary states. *Phys. Rev. Lett.*, 108:120601, 2012.
- [106] M. Kardar. *Statistical Physics of Fields*. Cambridge Univ. Press, Cambridge, 2007.
- [107] M. Baiesi and C. Maes. Enstrophy dissipation in two-dimensional turbulence. *Phys. Rev. E*, 72:056314, 2005.
- [108] K. Mallick, M. Moshe, and H. Orland. A field-theoretic approach to non-equilibrium work identities. *J. Phys. A: Math. Theor.*, 44:095002, 2011.
- [109] S. Ramaswamy. The mechanics and statistics of active matter. *Ann. Rev. Cond. Mat. Phys.*, 1:323–345, 2010.
- [110] V. Mustonen and M. L¨assig. Fitness flux and ubiquity of adaptive evolution. *Proc. Natl. Acad. Sci. U.S.A.*, 107:4248–4251, 2010.
- [111] H. C. Fogedby and A. Imparato. Heat distribution function for motion in a general potential at low temperature. *J. Phys. A: Math. Theor.*, 42:475004, 2009.
- [112] D. Chatterjee and B. J. Cherayil. Exact path-integral evaluation of the heat distribution function of a trapped Brownian oscillator. *Phys. Rev. E*, 82:051104, 2010.
- [113] D. Chatterjee and B. J. Cherayil. Single-molecule thermodynamics: the heat distribution function of a charged particle in a static magnetic field. *J. Stat. Mech.: Theor. Exp.*, page P03010, 2011.

[114] G. M. Wang, E. M. Sevick, E. Mittag, D. J. Searles, and D. J. Evans. Experimental demonstration of violations of the second law of thermodynamics for small systems and short time scales. *Phys. Rev. Lett.*, 89:050601, 2002.

- [115] G. M. Wang, J. C. Reid, D. M. Carberry, D. R. M. Williams, E. M. Sevick, and D. J. Evans. Experimental study of the fluctuation theorem in a nonequilibrium steady state. *Phys. Rev. E*, 71:046142, 2005.
- [116] R. van Zon and E. G. D. Cohen. Stationary and transient work-fluctuation theorems for a dragged Brownian particle. *Phys. Rev. E*, 67:046102, 2003.
- [117] R. van Zon and E. G. D. Cohen. Extension of the fluctuation theorem. *Phys. Rev. Lett.*, 91:110601, 2003.
- [118] R. van Zon and E. G. D. Cohen. Extended heat-fluctuation theorems for a system with deterministic and stochastic forces. *Phys. Rev. E*, 69:056121, 2004.
- [119] A. Imparato, L. Peliti, G. Pesce, G. Rusciano, and A. Sasso. Work and heat probability distribution of an optically driven Brownian particle: Theory and experiments. *Phys. Rev. E*, 76(5):050101, Nov 2007.
- [120] A. Saha, S. Lahiri, and A. M. Jayannavar. Entropy production theorems and some consequences. *Phys. Rev. E*, 80:011117, 2009.
- [121] A. M. Jayannavar and M. Sahoo. Charged particle in a mangetic field: Jarzynski equality. *Phys. Rev. E*, 75:032102, 2007.
- [122] J. I. Jimenez-Aquino, R. M. Velasco, and F. J. Uribe. Fluctuation relations for a classical harmonic oscillator in an electromagnetic field. *Phys. Rev. E*, 79:061109, 2009.
- [123] J. I. Jimenez-Aquino, F. J. Uribe, and R. M. Velasco. Work-fluctuation theorems for a particle in an electromagnetic field. *J. Phys. A Math. Theor.*, 43:255001, 2010.
- [124] J. I. Jimenez-Aquino. Entropy production for a charged particle in an eletromagnetic field. *Phys. Rev. E*, 82:051118, 2010.
- [125] J. I. Jimenez-Aquino. Work-fluctuation theorem for a charged harmonic oscillator. *J. Phys. A Math. Theor.*, 44:295002, 2011.
- [126] A. Saha and A. M. Jayannavar. Nonequilibrium work distributions for a trapped Brownian particle in a time-dependent magnetic field. *Phys. Rev. E*, 77:022105, 2008.
- [127] R. van Zon, S. Ciliberto, and E. G. D. Cohen. Power and heat fluctuation theorems for electric circuits. *Phys. Rev. Lett.*, 92:130601, 2004.
- [128] N. Garnier and S. Ciliberto. Nonequilibrium fluctuations in a resistor. *Phys. Rev. E*, 71:060101(R), 2005.
- [129] S. Joubaud, N. B. Garnier, and S. Ciliberto. Fluctuations of the total entropy production in stochastic systems. *EPL*, 82:30007, 2008.
- [130] C. Falcon and E. Falcon. Fluctuations of energy flux in a simple dissipative out-of-equilibrium system. *Phys. Rev. E*, 79:041110, 2009.
- [131] M. Bonaldi, L. Conti, P. De Gregorio, L. Rondoni, G. Vedovato, A. Vinante, M. Bignotto, M. Cerdonio, P. Falferi, N. Liguori, S. Longo, R. Mezzena, A. Ortolan, G. A. Prodi, F. Salemi, L. Taffarello, S. Vitale, and J.-P. Zendri. Nonequilibrium steady-state fluctuations in actively cooled resonators. *Phys. Rev. Lett.*, 103:010601, 2009.
- [132] J. Berg. Out-of-equilibrium dynamics of gene expression and the Jarzynski equation. *Phys. Rev. Lett.*, 100:188101, 2008.
- [133] D. M. Carberry, J. C. Reid, G. M. Wang, E. M. Sevick, D. J. Searles, and D. J. Evans. Fluctuations and irreversibility: An experimental demonstration of a second-law-like theorem using a colloidal particle held in an optical trap. *Phys. Rev. Lett.*, 92:140601, 2004.
- [134] M. Khan and A. K. Sood. Irreversibility-to-reversibility crossover in transient response of an optically trapped particle. *EPL*, 94:60003, 2011.
- [135] J. R. Gomez-Solano, A. Petrosyan, and S. Ciliberto. Heat fluctuations in a nonequilibrium bath. *Phys. Rev. Lett.*, 106:200602, 2011.
- [136] V. Blickle, T. Speck, L. Helden, U. Seifert, and C. Bechinger. Thermodynamics of a colloidal particle in a time-dependent nonharmonic potential. *Phys. Rev. Lett.*, 96:070603, 2006.
- [137] S. X. Sun. Generating generalized distributions from dynamical simulation. *J. Chem. Phys.*, 118:5769, 2003.
- [138] L. Gammaitoni, P. H¨anggi, P. Jung, and F. Marchesoni. Stochastic resonance. *Rev. Mod. Phys.*, 70:223–287, 1998.
- [139] P. Jop, A. Petrosyan, and S. Ciliberto. Work and dissipation fluctuations near the stochastic resonance of a colloidal particle. *EPL*, 81(5):50005, 2008.
- [140] A. Imparato, P. Jop, A. Petrosyan, and S. Ciliberto. Probability density functions of work and heat near the stochastic resonance of a colloidal particle. *J. Stat. Mech.: Theor. Exp.*, page

- P10017, 2008.
- [141] T. Iwai. Study of stochastic resonance by method of stochastic energetics. *Physica A*, 300:350– 358, 2001.
- [142] D. Dan and A. M. Jayannavar. Bona fide stochastic resonance: a view point from stochastic energetics. *Physica A*, 345:404–410, 2005.
- [143] S. Lahiri and A. M. Jayannavar. Total entropy production fluctuation theorems in a nonequilibrium time-periodic steady state. *Eur. Phys. J. B*, 69:87–92, 2009.
- [144] T. Speck, V. Blickle, C. Bechinger, and U. Seifert. Distribution of entropy production for a colloidal particle in a nonequilibrium steady state. *EPL*, 79:30002, 2007.
- [145] A. Gomez-Marin and I. Pagonabarraga. Test of the fluctuation theorem for stochastic entropy production in a nonequilibrium steady state. *Phys. Rev. E*, 74:061113, 2006.
- [146] J. Mehl, T. Speck, and U. Seifert. Large deviation function for entropy production in driven one-dimensional systems. *Phys. Rev. E*, 78:011123, 2008.
- [147] T. Nemoto and S. Sasa. Variational formula for experimental determination of high-order correlations of current fluctuations in driven systems. *Phys. Rev. E*, 83:030105, 2011.
- [148] F. Douarche, S. Ciliberto, A. Petrosyan, and I. Rabbiosi. An experimental test of the Jarzynski equality in a mechanical experiment. *Europhys. Lett.*, 70:593, 2005.
- [149] F. Douarche, S. Ciliberto, and A. Petrosyan. Estimate of the free energy difference in mechanical systems from work fluctuations: experiments and models. *J. Stat. Mech.: Theor. Exp.*, page P09011, 2005.
- [150] F. Douarche, S. Joubaud, N. B. Garnier, A. Petrosyan, and S. Ciliberto. Work fluctuation theorems for harmonic oscillators. *Phys. Rev. Lett.*, 97:140603, 2006.
- [151] S. Joubaud, N. B. Garnier, and S. Ciliberto. Fluctuation theorems for harmonic oscillators. *J. Stat. Mech.: Theor. Exp.*, page P09018, 2007.
- [152] J. Farago. Injected power fluctuations in Langevin equation. *J. Stat. Phys.*, 107:781, 2002.
- [153] T. Taniguchi and E. G. D. Cohen. Onsager-Machlup theory for nonequilibrium steady states and fluctuation theorems. *J. Stat. Phys.*, 126:1–41, 2007.
- [154] T. Taniguchi and E. G. D. Cohen. Inertial effects in nonequilibrium work fluctuations by a path integral approach. *J. Stat. Phys.*, 130:1–26, 2008.
- [155] T. Taniguchi and E. G. D. Cohen. Nonequilibrium steady state thermodynamics and fluctuations for stochastic systems. *J. Stat. Phys.*, 130:633, 2008.
- [156] E. G. D. Cohen. Properties of nonequilibrium steady states: a path integral approach. *J. Stat. Mech.: Theor. Exp.*, page P07014, 2008.
- [157] D. D. L. Minh and A. B. Adib. Path integral analysis of Jarzynski's equality: Analytical results. *Phys. Rev. E*, 79:021122, 2009.
- [158] B. Lev and A. D. Kiselev. Energy representation for nonequilibrium Brownian-like systems: Steady states and fluctuation relations. *Phys. Rev. E*, 82:031101, 2010.
- [159] A. Fingerle. Relativistic fluctuation theorems. *C. R. Physique*, 8:696–713, 2007.
- [160] S. Iso and S. Okazawa. Stochastic equations in black hole backgrounds and non-equilibrium fluctuation theorems. *Nucl. Phys. B*, 851:380–419, 2011.
- [161] S. Sabhapandit. Work fluctuations for a harmonic oscillator driven by an external random force. *EPL*, 96:20005, 2011.
- [162] J. R. Gomez-Solano, L. Bellon, A. Petrosyan, and S. Ciliberto. Steady-state fluctuation relations for systems driven by an external random force. *EPL*, 89(6):60003, 2010.
- [163] P. Visco. Work fluctuations for a Brownian particle between two thermostats. *J. Stat. Mech.: Theor. Exp.*, page P06006, 2006.
- [164] T. Tom´e and M. J. de Oliveira. Entropy production in irreversible systems described by a Fokker-Planck equation. *Phys. Rev. E*, 82:021120, 2010.
- [165] H. C. Fogedby and A. Imparato. A bound particle coupled to two thermostats. *J. Stat. Mech.: Theor. Exp.*, page P05015, 2011.
- [166] S. Aumaitre, S. Fauve, S. McNamara, and P. Poggi. Power injected in dissipative systems and the fluctuation theorem. *Eur. Phys. J. B*, 19:449–460, 2001.
- [167] K. Feitosa and N. Menon. Fluidized granular medium as an instance of the fluctuation theorem. *Phys. Rev. Lett.*, 92:164301, 2004.
- [168] N. Kumar, S. Ramaswamy, and A. K. Sood. Symmetry properties of the large-deviation function of the velocity of a self-propelled polar particle. *Phys. Rev. Lett.*, 106:118001, 2011.
- [169] A. Naert. Experimental study of work exchange with a granular gas: the viewpoint of the fluctuation theorem. *EPL*, 97:20010, 2012.
- [170] L. G. Wilson, A. W. Harrison, W. C. K. Poon, and A. M. Puertas. Microrheology and the fluctuation theorem in dense colloids. *EPL*, 93:58007, 2011.

[171] P. Visco, A. Puglisi, A. Barrat, E. Trizac, and F. Van Wijland. Injected power and entropy flow in a heated granular gas. *Europhys. Lett.*, 72:55–61, 2005.

- [172] A. Puglisi, P. Visco, A. Barrat, E. Trizac, and F. van Wijland. Fluctuations of internal energy flow in a vibrated granular gas. *Phys. Rev. Lett.*, 95:110202, 2005.
- [173] A. Puglisi, P. Visco, E. Trizac, and F. Van Wijland. Dynamics of a tracer granular perticle as a nonequilibrium markov process. *Phys. Rev. E*, 73:021301, 2006.
- [174] A. Puglisi, L. Rondoni, and A. Vulpiani. Relevance of initial and final conditions for the fluctuation relation in markov processes. *J. Stat. Mech.: Theor. Exp.*, page P08010, 2006.
- [175] A. Sarracino, D. Villamaina, G. Gradenigo, and A. Puglisi. Irreversible dynamics of a massive intruder in dense granular fluids. *EPL*, page 34001, 2010.
- [176] S.-H. Chong, M. Otsuki, and H. Hayakawa. Generalized Green-Kubo relation and integral fluctuation theorem for driven dissipative systems without microscopic time reversibility. *Phys. Rev. E*, 81:041130, 2010.
- [177] J. A. Drocco, C. J. Olson Reichhardt, and C. Reichhardt. Characterizing plastic depinning dynamics with the fluctuation theorem. *Eur. Phys. J. E*, 34:117, 2011.
- [178] G. Gradenigo, U. Marini Bettolo Marconi, A. Puglisi, and A. Sarracino. Non-equilibrium fluctuations in a driven stochastic lorentz gas. *arXiv: 1111.5798*, 2011.
- [179] S. Ciliberto and C. Laroche. An experimental test of the Gallavotti-Cohen fluctuation theorem. *J. Phys. IV France*, 08:215–219, 1998.
- [180] S. Ciliberto, N. Garnier, S. Hernandez, C. Lacpatia, J.-F. Pinton, and G. Ruiz Chavarria. Experimental test of the Gallavotti-Cohen fluctuation theorem in turbulent flows. *Physica A*, 340:240, 2004.
- [181] X.-D. Shang, P. Tong, and K.-Q. Xia. Test of steady state fluctuation theorem in turbulent Rayleigh-B´enard convection. *Phys. Rev. E*, 72:015301R, 2005.
- [182] T. Gilbert. Entropy fluctuations in shell models of turbulence. *Europhys. Lett.*, 67:172–178, 2004.
- [183] M. Belushkin, R. Livi, and G. Foffi. Hydrodynamics and the fluctuation theorem. *Phys. Rev. Lett.*, 106:210601, 2011.
- [184] W. I. Goldburg, Y. Y. Goldschmidt, and H. Kellay. Fluctuation and dissipation in liquid-crystal electroconvection. *Phys. Rev. Lett.*, 87:245502, 2001.
- [185] S. Joubaud, G. Huillard, A. Petrosyan, and S. Ciliberto. Work fluctuations in a nematic liquid crystal. *J. Stat. Mech.: Theor. Exp.*, page P01033, 2009.
- [186] O. Cadot, A. Boudaoud, and C. Touz. Statistics of power injection in a plate set into chaotic vibration. *Eur. Phys. J. B*, 66:399–407, 2008.
- [187] R. Suzuki, H. R. Jiang, and M. Sano. Validity of fluctuation theorem on self-propelling particles. *arXiv: 1104.5607*, 2011.
- [188] N. G. van Kampen. *Stochastic Processes in Physics and Chemistry*. North-Holland, Amsterdam, 1981.
- [189] J. Schnakenberg. Network theory of microscopic and macroscopic behavior of master equation systems. *Rev. Mod. Phys.*, 48:571, 1976.
- [190] T. L. Hill. *Free Energy Transduction and Biochemical Cycle Kinetics*. Dover, Mineola, New York, 2nd edition, 1989.
- [191] R.K.P. Zia and B. Schmittmann. A possible classification of nonequilibrium steady states. *J. Phys. A: Math. Gen.*, 39:L407, 2006.
- [192] R. K. P. Zia and B. Schmittmann. Probability currents as principal characteristics in the statistical mechanics of non-equilibrium steady states. *J. Stat. Mech.: Theor. Exp.*, page P07012, 2007.
- [193] R. M. L. Evans. Rules for transition rates in nonequilibrium steady states. *Phys. Rev. Lett.*, 92:150601, 2004.
- [194] A. Baule and R. M. L. Evans. Invariant quantities in shear flow. *Phys. Rev. Lett.*, 101:240601, 2008.
- [195] A. Baule and R. M. L. Evans. Nonequilibrium statistical mechanics of shear flow: invariant quantities and current relations. *J. Stat. Mech.: Theor. Exp.*, page P03030, 2010.
- [196] C. Monthus. Non-equilibrium steady states: maximization of the Shannon entropy associated with the distribution of dynamical trajectories in the presence of constraints. *J. Stat. Mech.: Theor. Exp.*, 2011:P03008, 2011.
- [197] M. Polettini. Macroscopic constraints for the minimum entropy production principle. *Phys. Rev. E*, 84:051117, 2011.
- [198] T. Platini. Measure of the violation of the detailed balance criterion: A possible definition of a 'distance' from equilibrium. *Phys. Rev. E*, 83:011119, 2011.
- [199] C. Maes, K. Netocn´y, and B. Wynants. Monotonic return to steady nonequilibrium. *Phys.*

- *Rev. Lett.*, 107:010601, 2011.
- [200] M. Polettini. Nonequilibrium thermodynamics as a gauge theory. *EPL*, 97:30003, 2012.
- [201] J. L. Luo, C. van den Broeck, and G. Nicolis. Stability-criteria and fluctuations around nonequilibrium states. *Z. Phys. B Cond. Mat.*, 56:165–170, 1984.
- [202] T. Sagawa and H. Hayaka. Geometrical expression of excess entropy production. *Phys. Rev. E*, 84:051110, 2011.
- [203] H. Ge and H. Qian. Physical origins of entropy production, free energy dissipation, and their mathematical representations. *Phys. Rev. E*, 81:051133, 2010.
- [204] A. Altland, A. De Martino, R. Egger, and B. Narohzny. Fluctuation relations and rare realizations of transport. *Phys. Rev. Lett.*, 105:170601, 2010.
- [205] A. Altland, A. De Martino, R. Egger, and B. Narohzny. Transient fluctuation relations for time-dependent particle transport. *Phys. Rev. B*, 82:115323, 2010.
- [206] F. Liu, Y.-P. Luo, M.-C. Huang, and Z.-C. Ou-Yang. A generalized integral fluctuation theorem for general jump processes. *J. Phys. A Math. Theor.*, 42:332003, 2009.
- [207] T. Monnai. Fluctuation theorem in ratchet system. *J. Phys. A: Math. Gen.*, 37:L75–79, 2004.
- [208] U. Seifert. Fluctuation theorem for a single enzym or molecular motor. *Europhys. Lett.*, 70:36, 2005.
- [209] H. Sakaguchi. Efficiency and fluctuation in tight-coupling model of molecuar motor. *J. Phys. Soc. Japan*, 75:063001, 2006.
- [210] A. M. Berezhkovskii and S. M. Bezrukov. Counting translocations of strongly repelling particles through single channels: fluctuation theorem for membrane transport. *Phys. Rev. Lett.*, 100:038104, 2008.
- [211] B. Sun, D. G. Grier, and A. Y. Grosberg. Minimal model for Brownian vortexes. *Phys. Rev. E*, 82:021123, 2010.
- [212] N. Kumar, C. van den Broeck, M. Esposito, and K. Lindenberg. Thermodynamics of a stochastic twin elevator. *Phys. Rev. E*, 84:051134, 2011.
- [213] D. V. Averin and J. P. Pekola. Statistics of the dissipated energy in driven single-electron transitions. *EPL*, 96:67004, 2011.
- [214] S. Dorosz and M. Pleimling. Entropy production in the nonequilibrium steady states of interacting many-body systems. *Phys. Rev. E*, 83:031107, 2011.
- [215] S. Dorosz and M. Pleimling. Fluctuation ratios in the absence of microscopic time reversibility. *Phys. Rev. E*, 79:030102(R), 2009.
- [216] D. Ben-Avraham, S. Dorosz, and M. Pleimling. Realm of validity of the Crooks relation. *Phys. Rev. E*, 83:041129, 2011.
- [217] B. Andrae, J. Cremer, T. Reichenbach, and E. Frey. Entropy production of cyclic population dynamics. *Phys. Rev. Lett.*, 104:218102, 2010.
- [218] B. Cleuren, C. van den Broeck, and R. Kawai. Fluctuation theorem for the effusion of an ideal gas. *Phys. Rev. E*, 74:021117, 2006.
- [219] R. Marathe and A. Dhar. Work distribution functions for hysteresis loops in a single-spin system. *Phys. Rev. E*, 72:066112, 2005.
- [220] M. Einax and P. Maass. Work distributions for ising chains in a time-dependent magnetic field. *Phys. Rev. E*, 80:020101(R), 2009.
- [221] M. Ohzeki and H. Nishimori. Nonequilibrium relations for spin glasses with gauge symmetry. *J. Phys. So*, 79:084003, 2010.
- [222] C. Chatelain. A temperature-extended Jarzynski relation: application to the numerical calculation of surface tension. *J. Stat. Mech.: Theor. Exp.*, page P04011, 2007.
- [223] L. Crochik and T. Tom´e. Entropy production in the majority-vote model. *Phys. Rev. E*, 72:057103, 2005.
- [224] M. J. de Oliveira. Irreversible models with Boltzmann-Gibbs probability distribution and entropy production. *J. Stat. Mech.: Theor. Exp.*, page P12012, 2011.
- [225] T. Tom´e and M. J. de Oliveira. Entropy production in nonequilibrium systems at stationary states. *Phys. Rev. Lett.*, 108:020601, 2012.
- [226] A. C. Barato and H. Hinrichsen. Entropy production of a bound nonequilibrium interface. *J. Phys. A Math. Theor.*, 45:115005, 2012.
- [227] T. Speck and J. P. Garrahan. Space-time phase transitions in driven kinetically constrained lattice models. *Eur. Phys. J. B*, 79:1–6, 2011.
- [228] P. Gaspard. Fluctuation theorem for nonequilibrium reactions. *J. Chem. Phys.*, 120:8898, 2004.
- [229] D. Andrieux and P. Gaspard. Fluctuation theorem and Onsager reciprocity relations. *J. Chem. Phys.*, 121:6167, 2004.
- [230] D. Andrieux and P. Gaspard. Fluctuation theorem for transport in mesoscopic systems. *J.*

- *Stat. Mech.: Theor. Exp.*, page P01001, 2006.
- [231] D. Andrieux and P. Gaspard. Fluctuation theorem for currents and Schnakenberg network theory. *J. Stat. Phys.*, 127:107–131, 2007.
- [232] H. Touchette. The large deviation approach to statistical mechanics. *Phys. Rep.*, 478:1–69, 2009.
- [233] D. Andrieux and P. Gaspard. Network and thermodynamic conditions for a single macroscopic current fluctuation theorem. *C. R. Physique*, 8:579–590, 2007.
- [234] A. Faggionato and D. Di Pietro. Gallavotti-Cohen-type symmetry related to cycle decompositions for markov chains and biochemical applications. *J. Stat. Phys.*, 143:11– 32, 2011.
- [235] A. C. Barato, R. Chetrite, H. Hinrichsen, and D. Mukamel. Entropy production and fluctuation relations for a KPZ interface. *J. Stat. Mech.: Theor. Exp.*, page P10008, 2010.
- [236] A. C. Barato, R. Chetrite, H. Hinrichsen, and D. Mukamel. A gallavotii-Cohen-Evans-Morriss like symmetry for a class of Markov jump processes. *J. Stat. Phys.*, 146:294–313, 2012.
- [237] N. A. Sinitsyn and I. Nemenman. The berry phase and the pump flux in stochastic chemical kinetics. *EPL*, 77:58001, 2007.
- [238] V. Y. Chernyak, M. Chertkov, S. V. Malinin, and R. Teodorescu. Non-equilibrium thermodynamics and topology of currents. *J. Stat. Phys.*, 137:109147, 2009.
- [239] J. Ohkubo. The stochastic pump current and the non-adiabatic geometrical phase. *J. Stat. Mech.: Theor. Exp.*, 2008:P02011, 2008.
- [240] J. Ohkubo and T. Eggel. Noncyclic and nonadiabatic geometric phase for counting statistics. *J. Phys. A: Math. Gen.*, 43:425001, 2010.
- [241] N. Singh and B. Wynants. Dynamical fluctuations for periodically driven diffusions. *J. Stat. Mech.: Theor. Exp.*, page P03007, 2010.
- [242] N. A. Sinitsyn, A. Akimov, and V. Y. Chernyak. Supersymmetry and fluctuation relations for currents in closed networks. *Phys. Rev. E*, 83:021107, 2011.
- [243] P. I. Hurtado, C. Perez-Espigares, J. J. del Pozo, and P. L. Garrido. Symmetries in fluctuations far from equilibrium. *Proc. Natl. Acad. Sci. U.S.A.*, 108:7704–7709, 2011.
- [244] K. Saito and U. Yasuhiro. Symmetry in full counting statistics, fluctuation theorem, and relations among nonlinear transport coefficients in the presence of a magnetic field. *Phys. Rev. B*, 78:115429, 2008.
- [245] R. S´anchez, R. L´opez, D. S´anchez, and M. B¨uttiker. Mesoscopic coulomb drag, broken detailed balance, and fluctuation relations. *Phys. Rev. Lett.*, 104:076801, 2010.
- [246] T. Monnai. Derivation of quantum master equation with counting fields by monitoring a probe. *Phys. Rev. E*, 82:051113, 2010.
- [247] Y. Utsumi, D. S. Golubev, M. Marthaler, K. Saito, T. Fujisawa, and G. Sch¨on. Bidirectional single-electron counting and the fluctuation theorem. *Phys. Rev. B*, 81:125331, 2010.
- [248] D. S. Golubev, Y. Utsumi, M. Marthaler, and G. Sch¨on. Fluctuation theorem for a double quantum dot coupled to a point-contact electrometer. *Phys. Rev. B*, 84:075323, 2011.
- [249] T. Krause, G. Schaller, and T. Brandes. Incomplete current fluctuation theorems for a fourterminal model. *Phys. Rev. B*, 84:195113, 2011.
- [250] L. Nicolin and D. Segal. Non-equilibrium spin-boson model: Counting statistics and the heat exchange fluctuation theorem. *J. Chem. Phys.*, 135:164106, 2011.
- [251] L. Nicolin and D. Segal. Quantum fluctuation theorem for heat exchange in the strong coupling regime. *Phys. Rev. B*, 84:161414, 2011.
- [252] G. B. Cuetara, M. Esposito, and P. Gaspard. Fluctuation theorems for capacitively coupled electronic currents. *Phys. Rev. B*, 84:165114, 2011.
- [253] S. Ganeshan and N. A. Sinitsyn. Fluctuation relations for current components in mesoscopic electric circuits. *Phys. Rev. B*, 84:245405, 2011.
- [254] B. Derrida. Non-equilibrium steady states: fluctuations and large deviations of the density and of the current. *J. Stat. Mech.: Theor. Exp.*, page P07023, 2007.
- [255] T. Schmiedl and U. Seifert. Optimal finite-time processes in stochastic thermodynamics. *Phys. Rev. Lett.*, 98:108301, 2007.
- [256] M. de Koning. Optimizing the driving function for nonequilibrium free-energy calculations in the linear regime: A variational approach. *J. Chem. Phys.*, 122:104106, 2005.
- [257] P. Geiger and C. Dellago. Optimum protocol for fast-switching free-energy calculations. *Phys. Rev. E*, 81(2):021127, 2010.
- [258] H. Then and A. Engel. Computing the optimal protocol for finite-time processes in stochastic thermodynamics. *Phys. Rev. E*, 77:041105, 2008.
- [259] E. Aurell, C. Mejia-Monasterio, and P. Muratore-Ginanneschi. Optimal protocols and optimal transport in stochastic thermodynamics. *Phys. Rev. Lett.*, 106:250601, 2011.

[260] E. Aurell, C. Mej´ıa-Monasterio, and P. Muratore-Ginanneschi. Boundary layers in stochastic thermodynamics. *Phys. Rev. E*, 85:020103, 2012.

- [261] T. Schmiedl and U. Seifert. Efficiency at maximum power: An analytically solvable model for stochastic heat engines. *EPL*, 81:20003, 2008.
- [262] E. Aurell, K. Gawedzki, C. Mej´ıa-Monasterio, R. Mohayaee, and P. Muratore-Ginanneschi. Refined second law of thermodynamics for fast random processes. *arXiv: 1201.3207*, 2012.
- [263] A. Gomez-Marin, T. Schmiedl, and U. Seifert. Optimal protocols for minimal work processes in underdamped stochastic thermodynamics. *J. Chem. Phys.*, 129:024114, 2008.
- [264] M. Esposito, R. Kawai, K. Lindenberg, and C. van den Broeck. Finite time thermodynamics for a single level quantum dot. *EPL*, 89:20003, 2010.
- [265] P. Muratore-Ginanneschi, C. Mej´ıa-Monasterio, and L. Peliti. Heat release by controlled continuous-time markov jump processes. *arXiv: 1203.4062*, 2012.
- [266] T. M. Cover and J. A. Thomas. *Elements of information theory*. Telecommunications and signal processing. Wiley, Hoboken, NJ, and Canada, 2006.
- [267] R. Kawai, J. M. R. Parrondo, and C. van den Broeck. Dissipation: The phase-space perspective. *Phys. Rev. Lett.*, 98:080602, 2007.
- [268] J. M. R. Parrondo, C. van den Broeck, and R. Kawai. Entropy production and the arrow of time. *New J. Phys.*, 11:073008, 2009.
- [269] A. Gomez-Marin, J. M. R. Parrondo, and C. Van den Broeck. Lower bounds on dissipation upon coarse-graining. *Phys. Rev. E*, 78:011107, 2008.
- [270] S. Vaikuntanathan and C. Jarzynski. Dissipation and lag in irreversible processes. *EPL*, 87:60005, 2009.
- [271] R. A. Blythe. Reversibility, heat dissipation, and the importance of the thermal environment in stochastic models of nonequilibrium steady states. *Phys. Rev. Lett.*, 100:010601, 2008.
- [272] M. Esposito and C. van den Broeck. Second law and Landauer principle far from equilibrium. *EPL*, 95:40004, 2011.
- [273] E. H. Feng and G. E. Crooks. Length of time's arrow. *Phys. Rev. Lett.*, 101:090602, 2008.
- [274] E. H. Feng and G. E. Crooks. Far-from-equilibrium measurements of thermodynamic length. *Phys. Rev. E*, 79:012104, 2009.
- [275] G. E. Crooks and D. A. Sivak. Measures of trajectory ensemble disparity in nonequilibrium statistical dynamics. *J. Stat. Mech.: Theor. Exp.*, page P06003, 2011.
- [276] D. Andrieux and P. Gaspard. Nonequilibrium generation of information in copolymerization processes. *Proc. Natl. Acad. Sci. U.S.A.*, 105:9516–9521, 2008.
- [277] C. Jarzynski. The thermodynamics of writing a random polymer. *Proc. Natl. Acad. Sci. U.S.A.*, 105:9451–9452, 2008.
- [278] H. S. Leff and A. F. Rex. *Maxwell's Demon : Entropy, Classical and Quantum Information, Computing*. IOP, Bristol and Philadelphia, 2003.
- [279] K. Maruyama, F. Nori, and V. Vedral. Colloquium: The physics of Maxwell's demon and information. *Rev. Mod. Phys.*, 81(1):1, 2009.
- [280] T. Hondou. Equation of state in a small system: Violation of an assumption of Maxwell's demon. *EPL*, 80:50001, 2007.
- [281] T. Sagawa and M. Ueda. Generalized Jarzynski equality under nonequilibrium feedback control. *Phys. Rev. Lett.*, 104:090602, 2010.
- [282] T. Sagawa and M. Ueda. Nonequilibrium thermodynamics of feedback control. *Phys. Rev. E*, 85:021104, 2012.
- [283] D. Abreu and U. Seifert. Thermodynamics of genuine non-equilibrium states under feedback control. *Phys. Rev. Lett.*, 108:030601, 2012.
- [284] J. M. Horowitz and S. Vaikuntanathan. Nonequilibrium detailed fluctuation theorem for repeated discrete feedback. *Phys. Rev. E*, 82:061120, 2010.
- [285] M. Ponmurugan. Generalized detailed fluctuation theorem under nonequilibrium feedback control. *Phys. Rev. E*, 82(3):031129, Sep 2010.
- [286] S. Lahiri, S. Rana, and A. M. Jayannavar. Fluctuation theorems in the presence of information gain and feedback. *J. Phys. A: Math. Theor.*, 45:065002, 2012.
- [287] M. Bauer, D. Abreu, and U. Seifert. Efficiency of a Brownian information machine. *J. Phys. A Math. Theor.*, 45:162001, 2012.
- [288] F. J. Cao and M. Feito. Thermodynamics of feedback controlled systems. *Phys. Rev. E*, 79:041118, 2009.
- [289] K.-H. Kim and H. Qian. Entropy production of Brownian macromolecules with inertia. *Phys. Rev. Lett.*, 93:120602, 2004.
- [290] K.-H. Kim and H. Qian. Fluctuation theorems for a molecular refrigerator. *Phys. Rev. E*, 75:022102, 2007.

[291] T. Munakata and M. L. Rosinberg. Entropy production and fluctuation theorems under feedback control: the molecular refrigerator model revisited. *arXiv: 1202.0974*, 2012.

- [292] H. Suzuki and Y. Fujitani. One-dimensional shift of a Brownian particle under the feedback control. *Journal of the Physical Society of Japan*, 78:074007, 2009.
- [293] Y. Fujitani and H. Suzuki. Jarzynski equality modified in the linear feedback system. *Journal of the Physical Society of Japan*, 79(10):104003, 2010.
- [294] F. J. Cao, L. Dinis, and J. M. R. Parrondo. Feedback control in a collective flashing ratchet. *Phys. Rev. Lett.*, 93:040603, 2004.
- [295] L. Dinis, J. M. R. Parrondo, and F. J. Cao. Closed-loop control strategy with improved current for a flashing ratchet. *Europhys. Lett.*, 71:536–541, 2005.
- [296] M. Feito and F. J. Cao. Optimal operation of feedback flashing ratchets. *J. Stat. Mech.: Theor. Exp.*, page P010331, 2009.
- [297] M. Feito and F. J. Cao. Information and maximum power in a feedback controlled Brownian ratchet. *Eur. Phys. J. B*, 59:63–68, 2007.
- [298] H. Touchette and S. Lloyd. Information-theoretic limits of control. *Phys. Rev. Lett.*, 84:1156, 2000.
- [299] F.J. Cao, M. Feito, and H. Touchette. Information and flux in a feedback controlled Brownian ratchet. *Physica A*, 388(2-3):113 – 119, 2009.
- [300] L. Granger and H. Kantz. Thermodynamic cost of measurements. *Phys. Rev. E*, 84:061110, 2011.
- [301] D. Abreu and U. Seifert. Extracting work from a single heat bath through feedback. *Europhys. Lett.*, 94:10001, 2011.
- [302] J. M. Horowitz and J. M. R. Parrondo. Thermodynamic reversibility in feedback processes. *EPL*, 95(1):10005, 2011.
- [303] J. M. Horowitz and J. M. R. Parrondo. Designing optimal discrete-feedback thermodynamic engines. *New J. Phys.*, 13:123019, 2011.
- [304] R. Dillenschneider and E. Lutz. Memory erasure in small systems. *Phys. Rev. Lett.*, 102:210601, 2009.
- [305] S. Toyabe, T. Sagawa, M. Ueda, E. Muneyuki, and M. Sano. Experimental demonstration of information-to-energy conversion and validation of the generalized Jarzynski equality. *Nature Phys.*, 6:988, 2010.
- [306] A. B´erut, A. Arakelyan, A. Petrosyan, S. Ciliberto, R. Dillenschneider, and E. Lutz. Experimental verification of Landauer's principle linking information and thermodynamics. *Nature*, 483:187–189, 2012.
- [307] A.E. Allahverdyan and T.M. Nieuwenhuizen. A mathematical theorem as the basis for the second law: Thomsons formulation applied to equilibrium. *Physica A*, 305:542–552, 2002.
- [308] K. Sato. An example of a mechanical system whose ensemble average energy, starting with a microcanonical ensemble, decreases after an operation. *J. Phys. Soc. Japan*, 71:1065–1066, 2002.
- [309] R. Marathe and J. M. R. Parrondo. Cooling classical particles with a microcanonical Szilard engine. *Phys. Rev. Lett.*, 104(24):245704, 2010.
- [310] S. Vaikuntanathan and C. Jarzynski. Modeling Maxwell's demon with a microcanonical szilard engine. *Phys. Rev. E*, 83:061120, 2011.
- [311] R. Kubo, M. Toda, and N. Hashitsume. *Statistical Physics II*. Springer-Verlag, Berlin, 2nd edition, 1991.
- [312] G. S. Agarwal. Fluctuation-dissipation theorems for systems in non-thermal equilibrium and applications. *Z. Physik*, 252:25, 1972.
- [313] G. N. Bochkov and Y. E. Kuzovlev. Nonlinear fluctuation-dissipation relations and stochastic models in nonequilibrium thermodynamics I. Generalized fluctuation-dissipation theorem. *Physica A*, 106:443–479, 1981.
- [314] G. N. Bochkov and Y. E. Kuzovlev. Nonlinear fluctuation-dissipation relations and stochastic models in nonequilibrium thermodynamics II. Kinetic potential and variational principles for nonlinear irreversible processes. *Physica A*, 106:480–520, 1981.
- [315] P. H¨anggi and H. Thomas. Stochastic processes: Time evolution, symmetries and linear response. *Phys. Rep.*, 88:207, 1982.
- [316] U. Marconi, A. Puglisi, L. Rondoni, and A. Vulpiani. Fluctuation-dissipation: Response theory in statistical physics. *Phys. Rep.*, 461:111–195, 2008.
- [317] L. F. Cugliandolo, D. S. Dean, and J. Kurchan. Fluctuation-dissipation theorems and entropy production in relaxational systems. *Phys. Rev. Lett.*, 79:2168, 1997.
- [318] T. Harada and S. Sasa. Equality connecting energy dissipation with a violation of the fluctuation-response relation. *Phys. Rev. Lett.*, 95:130602, 2005.

[319] T. Harada and S. Sasa. Energy dissipation and violation of the fluctuation-response relation in nonequilibrium Langevin systems. *Phys. Rev. E*, 73:026131, 2006.

- [320] T. Harada. Macroscopic expression connecting the rate of energy dissipation with the violation of the fluctuation response relation. *Phys. Rev. E*, 79:030106, 2009.
- [321] T. Speck and U. Seifert. Restoring a fluctuation-dissipation theorem in a nonequilibrium steady state. *Europhys. Lett.*, 74:391, 2006.
- [322] T. Speck and U. Seifert. Extended fluctuation-dissipation theorem for soft matter in stationary flow. *Phys. Rev. E*, 79:040102(R), 2009.
- [323] R. Chetrite, G. Falkovich, and K. Gawedzki. Fluctuation relations in simple examples of nonequilibrium steady states. *J. Stat. Mech.: Theor. Exp.*, page P08005, 2008.
- [324] R. Chetrite and K. Gawedzki. Eulerian and lagrangian pictures of non-equilibrium diffusions. *J. Stat. Phys.*, 137:890–916, 2009.
- [325] M. Baiesi, C. Maes, and B. Wynants. Fluctuations and response of nonequilibrium states. *Phys. Rev. Lett.*, 103:010602, 2009.
- [326] M. Baiesi, C. Maes, and B. Wynants. Nonequilibrium linear response for Markov dynamics, I: Jump processes and overdamped diffusion. *J. Stat. Phys.*, 137:1094–1116, 2009.
- [327] M. Baiesi, E. Boksenbojm, C. Maes, and B. Wynants. Nonequilibrium linear response for markov dynamics, II: Inertial dynamics. *J. Stat. Phys.*, 139:492–505, 2010.
- [328] J. Prost, J.-F. Joanny, and J. M. R. Parrondo. Generalized fluctuation-dissipation theorem for steady-state systems. *Phys. Rev. Lett.*, 103:090601, 2009.
- [329] U. Seifert and T. Speck. Fluctuation-dissipation theorem in nonequilibrium steady states. *EPL*, 89:10007, 2010.
- [330] R. Chetrite and S. Gupta. Two refreshing views of fluctuation theorems through kinematics elements and exponential martingale. *J. Stat. Phys.*, 143:543–584, 2011.
- [331] G. Verley, R. Ch´etrite, and D. Lacoste. Modified fluctuation-dissipation theorem near nonequilibrium states and applications to the glauber-ising chain. *J. Stat. Mech.: Theor. Exp.*, page P10025, 2011.
- [332] H. Feng and J. Wang. Potential and flux decomposition for dynamical systems and nonequilibrium thermodynamics: Curvature, gauge field, and generalized fluctuation-dissipation theorem. *J. Chem. Phys.*, 135:234511, 2011.
- [333] L. F. Cugliandolo. The effective temperature. *J. Phys. A Math. Theor.*, 44:483001, 2011.
- [334] L. Berthier and J.-L. Barrat. Nonequilibrium dynamics and fluctuation-dissipation relation in a sheared fluid. *J. Chem. Phys.*, 116:6228, 2002.
- [335] C. S. O'Hern, A. J. Liu, and S. R. Nagel. Effective temperatures in driven systems: static versus time-dependent relations. *Phys. Rev. Lett.*, 93:165702, 2004.
- [336] S. Fielding and P. Sollich. Observable dependence of fluctuation-dissipation relations and effective temperatures. *Phys. Rev. Lett.*, 88:050603, 2002.
- [337] Y. Srebro and D. Levine. Exactly solvable model for driven dissipative systems. *Phys. Rev. Lett.*, 93:240601, 2004.
- [338] Y. Shokef, G. Bunin, and D. Levine. Fluctuation-dissipation relations in driven dissipative systems. *Phys. Rev. E*, 73:046132, 2006.
- [339] K. Martens, E. Bertin, and M. Droz. Dependence of the fluctuation-dissipation temperature on the choice of observable. *Phys. Rev. Lett.*, 103(26):260602, 2009.
- [340] K. Martens, E. Bertin, and M. Droz. Entropy-based characterizations of the observable dependence of the fluctuation-dissipation temperature. *Phys. Rev. E*, 81:061107, 2010.
- [341] L. F. Cugliandolo, J. Kurchan, and G. Parisi. Off equilibrium dynamics and aging in unfrustrated systems. *J. Phys. I*, 4:1641, 1994.
- [342] L. F. Cugliandolo, J. Kurchan, and L. Peliti. Energy flow, partial equilibration, and effective temperatures in systems with slow dynamics. *Phys. Rev. E*, 55:3898, 1997.
- [343] F. Zamponi, F. Bonetto, L.F. Cugliandolo, and J. Kurchan. A fluctuation theorem for nonequilibrium relaxational systems driven by external forces. *J. Stat. Mech.: Theor. Exp.*, page P09013, 2005.
- [344] P. Calabrese and A. Gambassi. On the definition of a unique effective temperature for nonequilibrium critical systems. *J. Stat. Mech.: Theor. Exp.*, page P07013, 2004.
- [345] P. Martin, A. J. Hudspeth, and F. J¨ulicher. Comparison of a hair bundle's spontaneous oscillations with its response to mechanical stimulation reveals the underlying active process. *Proc. Natl. Acad. Sci. U.S.A.*, 98:14380, 2001.
- [346] D. Mizuno, C. Tardin, C. F. Schmidt, and F. C. MacKintosh. Nonequilibrium mechanics of active cytoskeletal networks. *Science*, 315:370–373, 2007.
- [347] A. J. Levine and F. C. MacKintosh. The mechanics and fluctuation spectrum of active gels. *J. Phys. Chem. B*, 113:3820–3830, 2009.

[348] L. Le Goff, F. Amblard, and E. M. Furst. Motor-driven dynamics in actin-myosin networks. *Phys. Rev. Lett.*, 88:018101, 2002.

- [349] N. Kikuchi, A. Ehrlicher, D. Koch, J. K¨as, S. Ramaswamy, and M. Rao. Buckling, stiffening, and negative dissipation in the dynamics of a biopolymer in an active medium. *Proc. Natl. Acad. Sci. U.S.A.*, 106:19776, 2009.
- [350] D. Loi, S. Mossa, and L. F. Cuglia. Effective temperature of active matter. *Phys. Rev. E*, 77:051111, 2008.
- [351] J.-B. Manneville, P. Bassereau, S. Ramaswamy, and J. Prost. Active membrane fluctuations studied by micropipet aspiration. *Phys. Rev. E*, 64:021908, 2001.
- [352] T. Betz, M. Lenz, J.-F. Joanny, and C. Sykes. ATP-dependent mechanics of red blood cells. *Proc. Natl. Acad. Sci. U.S.A.*, 106:15320–15325, 2009.
- [353] E. Ben-Isaac, Y. Park, G. Popescu, F. L. H. Brown, N. S. Gov, and Y. Shokef. Effective temperature of red-blood-cell membrane fluctuations. *Phys. Rev. Lett.*, 106:238103, 2011.
- [354] R. Raduenz, D. Rings, K. Kroy, and F. Cichos. Hot Brownian particles and photothermal correlation spectroscopy. *J. Phys. Chem. A*, 113:1674–1677, 2009.
- [355] D. Rings, R. Schachoff, M. Selmke, F. Cichos, and K. Kroy. Hot Brownian motion. *Phys. Rev. Lett.*, 105:090604, 2010.
- [356] D. Rings, M. Selmke, F. Cichos, and K. Kroy. Theory of hot Brownian motion. *Soft Matter*, 7:3441–3452, 2011.
- [357] D. Chakraborty, M. V. Gnann, D. Rings, J. Glaser, F. Otto, F. Cichos, and K. Kroy. Generalised Einstein relation for hot Brownian motion. *EPL*, 96:60009, 2011.
- [358] L. Joly, S. Merabia, and J.-L. Barrat. Effective temperatures of a heated Brownian particle. *EPL*, 94:50007, 2011.
- [359] P. Pradhan, Y. Kafri, and D. Levine. Nonequilibrium fluctuation theorems in the presence of local heating. *Phys. Rev. E*, 77:041129, 2008.
- [360] T. Speck. Driven soft matter: Entropy production and the fluctuation-dissipation theorem. *Progr. Theor. Phys. Suppl.*, 184:248–261, 2010.
- [361] F. Ricci-Tersenghi. Measuring the fluctuation-dissipation ratio in glassy systems with no perturbing field. *Phys. Rev. E*, 68:065104, 2003.
- [362] A. Crisanti and F. Ritort. Violation of the fluctuation-dissipation theorem in glassy systems: basic notions and the numerical evidence. *J. Phys. A: Math. Gen.*, 36:R181, 2003.
- [363] C. Chatelain. On universality in ageing ferromagnets. *J. Stat. Mech.: Theor. Exp.*, page P06006, 2004.
- [364] E. Lippiello, F. Corberi, and M. Zannetti. Off-equilibrium generalization of the fluctuation dissipation theorem for ising spins and measurement of the linear response function. *Phys. Rev. E*, 71:036104, 2005.
- [365] G. Diezemann. Fluctuation-dissipation relations for markov processes. *Phys. Rev. E*, 72:011104, 2005.
- [366] M. J. de Oliveira. Fluctuation-dissipation relation for stochastic dynamics without detailed balance. *Phys. Rev. E*, 76:011114, 2007.
- [367] F. Corberi, E. Lippiello, and M. Zannetti. Fluctuation dissipation relations far from equilibrium. *J. Stat. Mech.: Theor. Exp.*, page P07002, 2007.
- [368] E. Lippiello, F. Corberi, A. Sarracino, and M. Zannetti. Nonlinear response and fluctuationdissipation relations. *Phys. Rev. E*, 78:041120, 2008.
- [369] L. Berthier. Efficient measurement of linear susceptibilities in molecular simulations: Application to aging supercooled liquids. *Phys. Rev. Lett.*, 98:220601, 2007.
- [370] U. Seifert. Generalized Einstein or Green-Kubo relations for active biomolecular transport. *Phys. Rev. Lett.*, 104:138101, 2010.
- [371] G. Verley, K. Mallick, and D. Lacoste. Modified fluctuation-dissipation theorem for nonequilibrium steady states and applications to molecular motors. *EPL*, 93:10002, 2011.
- [372] D. Andrieux and P. Gaspard. A fluctuation theorem for currents and non-linear response coefficients. *J. Stat. Mech.*, page P02006, 2007.
- [373] M. Baiesi, C. Maes, and B. Wynants. The modified SutherlandEinstein relation for diffusive non-equilibria. *Proc. Roy. Soc. A*, 467:2792–2809, 2011.
- [374] D. Villamaina, A. Sarracino, G. Gradenigo, A. Puglisi, and A. Vulpiani. On anomalous diffusion and the out-of-equilibrium response function in one-dimensional models. *J. Stat. Mech.: Theor. Exp.*, page L01002, 2011.
- [375] V. Blickle, T. Speck, C. Lutz, U. Seifert, and C. Bechinger. Einstein relation generalized to nonequilibrium. *Phys. Rev. Lett.*, 98:210601, 2007.
- [376] P. Reimann, C. van den Broeck, H. Linke, P. H¨anggi, M. Rubi, and A. P´erez-Madrid. Giant acceleration of free diffusion by use of tilted periodic potentials. *Phys. Rev. Lett.*, 87:010602,

- 2001.
- [377] P. Reimann, C. Van den Broeck, H. Linke, P. Hanggi, J. M. Rubi, and A. Perez-Madrid. Diffusion in tilted periodic potentials: Enhancement, universality, and scaling. *Phys. Rev. E*, 65(3):031104, 2002.
- [378] J. Mehl, V. Blickle, U. Seifert, and C. Bechinger. Experimental accessibility of generalized fluctuation-dissipation relations for nonequilibrium steady states. *Phys. Rev. E*, 82:032401, 2010.
- [379] J. R. Gomez-Solano, A. Petrosyan, S. Ciliberto, R. Chetrite, and K. Gawedzki. Experimental verification of a modified fluctuation-dissipation relation for a micron-sized particle in a nonequilibrium steady state. *Phys. Rev. Lett.*, 103:040601, 2009.
- [380] J. R. Gomez-Solano, A. Petrosyan, S. Ciliberto, and C. Maes. Fluctuations and response in a non-equilibrium micron-sized system. *J. Stat. Mech.*, page P01008, 2011.
- [381] G. Szamel. Self-diffusion in sheared colloidal suspensions: Violation of fluctuation-dissipation relation. *Phys. Rev. Lett.*, 93:178301, 2004.
- [382] M. Kr¨uger and M. Fuchs. Non-equilibrium relation between mobility and diffusivity of interacting Brownian particles under shear. *Progr. Theor. Phys. Suppl.*, 184:172–186, 2010.
- [383] B. Lander, U. Seifert, and T. Speck. Mobility and diffusion of a tagged particle in a driven colloidal suspension. *Europhys. Lett.*, 92(58001), 2010.
- [384] B. Lander, U. Seifert, and T. Speck. Effective confinement as origin of the equivalence of kinetic temperature and fluctuation-dissipation ratio in a dense shear driven suspension. *Phys. Rev. E*, 85:021103, 2012.
- [385] M. Zhang and G. Szamel. Effective temperatures of a driven, strongly anisotropic Brownian system. *Phys. Rev. E*, 83:061407, 2011.
- [386] G. Szamel and M. Zhang. Tagged particle in a sheared suspension: Effective temperature determines density distribution in a slowly varying external potential beyond linear response. *EPL*, 96:50007, 2011.
- [387] M. Kr¨uger and M. Fuchs. Fluctuation dissipation relations in stationary states of interacting Brownian particles under shear. *Phys. Rev. Lett.*, 102(13):135701, 2009.
- [388] M. Kr¨uger and M. Fuchs. Nonequilibrium fluctuation-dissipation relations of interacting Brownian particles driven by shear. *Phys. Rev. E*, 81:011408, 2010.
- [389] F. Ritort. Single-molecule experiments in biological physics: methods and applications. *J. Phys.: Condens. Matter*, 18:R531, 2006.
- [390] P. R. Selvin and T. Ha. *Single Molecule Techniques: A Laboratory Manual*. Cold Spring Harbor Laboratory Press, New York, December 2007.
- [391] A. A. Deniz, S. Mukhopadhyay, and E. A. Lemke. Single-molecule biophysics: at the interface of biology, physics and chemistry. *J. Royal Soc. Interface*, 5:15–45, 2008.
- [392] J. Howard. *Mechanics of Motor Proteins and the Cytoskeleton*. Sinauer, New York, 1 edition, 2001.
- [393] M. Schliwa. *Molecular Motors*. Wiley-VCH, Weinheim, 2003.
- [394] C. Bustamante, Y. R. Chemla, N. R. Forde, and D. Izhaky. Mechanical processes in biochemistry. *Ann. Rev. of Biochemistry*, 73:705–748, 2004.
- [395] S. Kumar and M. S. Li. Biomolecules under mechanical force. *Phys. Rep.*, 486:1–74, 2010.
- [396] M. E. Fisher and A. B. Kolomeisky. The force exerted by a molecular motor. *Proc. Natl. Acad. Sci. U.S.A.*, 96:6597, 1999.
- [397] R. Lipowsky. Universal aspects of the chemomechanical coupling for molecular motors. *Phys. Rev. Lett.*, 85:4401, 2000.
- [398] H. Qian. A simple theory of motor protein kinetics and energetics. ii. *Biophys. Chem.*, 83:35– 43, 2000.
- [399] C. Bustamante, D. Keller, and G. Oster. The physics of molecular motors. *Accounts Chem. Res.*, 34:412–420, 2001.
- [400] J. E. Baker. Free energy transduction in a chemical motor model. *J. Theor. Biol.*, 228:467, 2004.
- [401] D. Andrieux and P. Gaspard. Fluctuation theorems and the nonequilibrium thermodynamics of molecular motors. *Phys. Rev. E*, 74:011906, 2006.
- [402] H. Wang and T. C. Elston. Mathematical and computational methods for studying energy transduction in protein motors. *J. Stat. Phys.*, 128:35–76, 2007.
- [403] P. Gaspard and E. Gerritsma. The stochastic chemomechanics of the F1-ATPase molecular motor. *J. Theor. Biol.*, 247:672–686, 2007.
- [404] S. Liepelt and R. Lipowsky. Steady-state balance conditions for molecular motor cycles and stochastic nonequilibrium processes. *EPL*, 77:50002, 2007.
- [405] S. Liepelt and R. Lipowsky. Kinesin's network of chemomechanical motor cycles. *Phys. Rev.*

- *Lett.*, 98:258102, 2007.
- [406] R. Lipowsky and S. Liepelt. Chemomechanical coupling of molecular motors: Thermodynamics, network representations, and balance conditions. *J. Stat. Phys.*, 130:39–67, 2008.
- [407] S. Liepelt and R. Lipowsky. Operation modes of the molecular motor kinesin. *Phys. Rev. E*, 79:011917, 2009.
- [408] R. Lipowsky and S. Liepelt. Chemomechanical coupling of molecular motors: Thermodynamics, network representations, and balance conditions (vol 130, pg 39, 2008). *J. Stat. Phys.*, 135:777–778, 2009.
- [409] R. Lipowsky, S. Liepelt, and A. Valleriani. Energy conversion by molecular motors coupled to nucleotide hydrolysis. *J. Stat. Phys.*, 135:951–975, 2009.
- [410] A. W. C. Lau, D. Lacoste, and K. Mallick. Non-equilibrium fluctuations and mechanochemical couplings of a molecular motor. *Phys. Rev. Lett.*, 99:158102, 2007.
- [411] A. B. Kolomeisky and M. E. Fisher. Molecular Motors: A Theorist's Perspective. *Ann. Rev. Phys. Chem.*, 58:675–695, 2007.
- [412] R. D. Astumian. Thermodynamics and kinetics of molecular motors. *Biophys. J.*, 98:2401– 2409, 2010.
- [413] F. J¨ulicher, A. Ajdari, and J. Prost. Modeling molecular motors. *Rev. Mod. Phys.*, 69(4):1269– 1282, 1997.
- [414] R. D. Astumian and P. H¨anggi. Brownian motors. *Physics Today*, 55(11):33, 2002.
- [415] P. Reimann. Brownian motors: noisy transport far from equilibrium. *Phys. Rep.*, 361:57, 2002.
- [416] J. M. R. Parrondo and B. J. De Cisneros. Energetics of Brownian motors: a review. *Applied Physics A*, 75:179, 2002.
- [417] Wei Min, Liang Jiang, Ji Yu, S. C. Kou, Hong Qian, and X. Sunney Xie. Nonequilibrium steady state of a nanometric biochemical system: Determinig the thermodynamic driving force from single enzyme turnover time traces. *Nano Lett.*, 5:2373–2378, 2005.
- [418] T. Shibata. A generalization of Clausius inequality for processes between nonequilibrium steady states in chemical reaction systems. *cond-mat/0012404*, 2000.
- [419] T. Schmiedl and U. Seifert. Stochastic thermodynamics of chemical reaction networks. *J. Chem. Phys.*, 126:044101, 2007.
- [420] U. Seifert. Fluctuation theorem for birth-death or chemical master equations with timedependent rates. *J. Phys. A: Math. Gen.*, 37:L517, 2004.
- [421] C. Jarzynski. Lag inequality for birth-death processes with time-dependent rates. *J. Phys. A: Math. Gen.*, 38:L227, 2005.
- [422] H. Qian and X. S. Xie. Generalized Haldane equation and fluctuation theorem in the steadystate cycle kinetics of single enzymes. *Phys. Rev. E*, 74:010902, 2006.
- [423] D. Lacoste, A. W. C. Lau, and K. Mallick. Fluctuation theorem and large deviation function for a solvable model of a molecular motor. *Phys. Rev. E*, 78:011915, 2008.
- [424] D. Lacoste and K. Mallick. Fluctuation theorem for the flashing ratchet model of molecular motors. *Phys. Rev. E*, 80:021923, 2009.
- [425] D. A. Beard and H. Qian. *Chemical Biophysics: Quantitative Analysis of Cellular Systems*. Cambridge Univ. Press, Cambridge, 2008.
- [426] K. Sekimoto. Microscopic heat from the energetics of stochastic phenomena. *Phys. Rev. E*, 76:060103(R), 2007.
- [427] U. Seifert. Stochastic thermodynamics of single enzymes and molecular motors. *Eur. Phys. J. E*, 34:26, 2011.
- [428] G. Hummer and A. Szabo. Free energy surfaces from single-molecule force spectroscopy. *Acc. Chem. Res.*, 38:504–513, 2005.
- [429] G. Hummer and A. Szabo. Free energy profiles from single-molecule pulling experiments. *Proc. Natl. Acad. Sci. U.S.A.*, 107:21441–21446, 2010.
- [430] D. D. L. Minh and A. B. Adib. Optimized free energies from bidirectional single-molecule force spectroscopy. *Phys. Rev. Lett.*, 100:180602, 2008.
- [431] P. Nicolini, P. Procacci, and R. Chelli. Hummer and Szabo-like potential of mean force estimator for bidirectional nonequilibrium pulling experiments/simulations. *J. Phys. Chem. B*, 114:9546–9554, 2010.
- [432] J. Liphardt, S. Dumont, S. B. Smith, I. Tinoco Jr, and C. Bustamante. Equilibrium information from nonequilibrium measurements in an experimental test of Jarzynski's equality. *Science*, 296:1832, 2002.
- [433] D. Collin, F. Ritort, C. Jarzynski, S.B. Smith, I. Tinoco, and C. Bustamante. Verification of the Crooks fluctuation theorem and recovery of RNA folding free energies. *Nature*, 437:231, 2005.

[434] A. Mossa, M. Manosas, N. Forns, J. M. Huguet, and F. Ritort. Dynamic force spectroscopy of DNA hairpins: I. Force kinetics and free energy landscapes. *J. Stat. Mech.: Theor. Exp.*, page P02060, 2009.

- [435] M. Manosas, A. Mossa, N. Forns, J. M. Huguet, and F. Ritort. Dynamic force spectroscopy of DNA hairpins: II. Irreversibility and dissipation. *J. Stat. Mech.: Theor. Exp.*, P02061, 2009.
- [436] A. Mossa, S. de Lorenzo, J. M. Huguet, and F. Ritort. Measurement of work in single-molecule pulling experiments. *J. Chem. Phys.*, 130:234116, 2009.
- [437] N. C. Harris, Y. Song, and C. H. Kiang. Experimental free energy surface reconstruction from single-molecule force spectroscopy using Jarzynski's equality. *Phys. Rev. Lett.*, 99:068101, 2007.
- [438] R. W. Friddle. Experimental free energy surface reconstruction from single-molecule force spectroscopy using Jarzynski's equality - comment. *Phys. Rev. Lett.*, 100:019801, 2008.
- [439] N. C. Harris, Y. Song, and C. H. Kiang. Experimental free energy surface reconstruction from single-molecule force spectroscopy using Jarzynski's equality - reply. *Phys. Rev. Lett.*, 100:019802, 2008.
- [440] T. Bornschl¨ogl and M. Rief. Single-molecule dynamics of mechanical coiled-coil unzipping. *Langmuir*, 24:1338–1342, 2008.
- [441] J. C. M. Gebhardt, T. Bornschl¨ogl, and M. Rief. Full distance-resolved folding energy landscape of one single protein molecule. *Proc. Natl. Acad. Sci. U.S.A.*, 107:2013–2018, 2010.
- [442] E. A. Shank, C. Cecconi, J. W. Dil, S. Marqusee, and C. Bustamante. The folding cooperativity of a protein is controlled by its chain topology. *Nature*, 465:637, 2010.
- [443] R. A. Nome, J. M. Zhao, W. D. Hoff, and N. F. Scherer. Axis-dependent anisotropy in protein unfolding from integrated nonequilibrium single-molecule experiments, analysis, and simulation. *Proc. Natl. Acad. Sci. U.S.A.*, 104:20799–20804, 2007.
- [444] N. A. Gupta, V. Abhilash, K. Neupane, H. Yu, F. Wang, and M. T. Woodside. Experimental validation of free-energy-landscape reconstruction from non-equilibrium single-molecule force spectroscopy measurements. *Nature Physics*, 7:631–634, 2011.
- [445] O. Braun, A. Hanke, and U. Seifert. Probing molecular free energy landscapes by periodic loading. *Phys. Rev. Lett.*, 93:158105, 2004.
- [446] D. D. L. Minh. Free-energy reconstruction from experiments performed under different biasing programs. *Phys. Rev. E*, 74:061120, 2006.
- [447] A. Imparato, S. Luccioli, and A. Torcini. Reconstructing the free-energy landscape of a mechanically unfolded model protein. *Phys. Rev. Lett.*, 99:168101, 2007.
- [448] R. Berkovich, J. Klafter, and M. Urbakh. Analyzing friction forces with the Jarzynski equality. *J. Phys.: Condens. Matter*, 20:354008, 2008.
- [449] I. Kosztin, B. Barz, and L. Janosi. Calculating potentials of mean force and diffusion coefficients from nonequilibrium processes without Jarzynskis equality. *J. Chem. Phys.*, 124:064106, 2006.
- [450] D. D. L. Minh. Multidimensional potentials of mean force from biased experiments along a single coordinate. *J. Phys. Chem. B*, 111:4137–4140, 2007.
- [451] A. Imparato and L. Peliti. The distribution function of entropy flow in stochastic systems. *J. Stat. Mech.: Theor. Exp.*, page L02001, 2007.
- [452] S. Mitternacht, S. Luccioli, A. Torcini, A. Imparato, and A. Irb¨ack. Changing the mechanical unfolding pathway of F nIII10 by tuning the pulling strength. *Biophys. J.*, 96:429–441, 2009.
- [453] J. Preiner, H. Janovjak, C. Rankl, H. Knaus, D. A. Cisneros, A. Kedrov, F. Kienberger, D. J. Muller, and P. Hinterdorfer. Free energy of membrane protein unfolding derived from singlemolecule force measurements. *Biophys. J.*, 93:930–937, 2007.
- [454] G. Hummer. Fast-growth thermodynamic integration: Error and efficiency analysis. *J. Chem. Phys.*, 114:7330, 2001.
- [455] D. M. Zuckerman and T. B. Woolf. Theory of a systematic computational error in free energy differences. *Phys. Rev. Lett.*, 89:180602, 2002.
- [456] S. Park, F. Khalili-Araghi, E. Tajkhorshid, and K. Schulten. Free energy calculation from steered molecular dynamics simulations using Jarzynski's equality. *J. Chem. Phys.*, 119:3559, 2003.
- [457] J. Gore, F. Ritort, and C. Bustamante. Bias and error in estimates of equilibrium free-energy differences from nonequilibrium measurements. *Proc. Natl. Acad. Sci. U.S.A.*, 100:12564, 2003.
- [458] D. M. Zuckerman and T. B. Woolf. Systematic finite-sampling inaccuracy in free energy differences and other nonlinear quantities. *J. Stat. Phys.*, 114:1303–1323, 2004.

[459] S. Park and K. Schulten. Calculating potentials of mean force from steered molecular dynamics simulations. *J. Chem. Phys.*, 120:5946, 2004.

- [460] F. M. Ytreberg and D. M. Zuckerman. Single-ensemble nonequilibrium path-sampling estimates of free energy differences. *J. Chem. Phys.*, 120:10876, 2004.
- [461] H. Oberhofer, C. Dellago, and P. L. Geissler. Biased sampling of nonequilibrium trajectories: Can fast switching simulations outperform conventional free energy calculation methods? *J. Phys. Chem. B*, 109:6902, 2005.
- [462] C. Jarzynski. Rare events and the convergence of exponentially averaged work values. *Phys. Rev. E*, 73:046105, 2006.
- [463] P. Maragakis, M. Spichty, and M. Karplus. Optimal estimates of free energies from multistate nonequilibrium work data. *Phys. Rev. Lett.*, 96:100602, 2006.
- [464] S. Presse and R. Silbey. Ordering of limits in the Jarzynski equality. *J. Chem. Phys.*, 124:054117, 2006.
- [465] D. K. West, P. D. Olmsted, and E. Paci. Free energy for protein folding from nonequilibrium simulations using the Jarzynski equality. *J. Chem. Phys.*, 125:204910, 2006.
- [466] W. Lechner and C. Dellago. On the efficiency of path sampling methods for the calculation of free energies from non-equilibrium simulations. *J. Stat. Mech.: Theor. Exp.*, page P04001, 2007.
- [467] S. Vaikuntanathan and C. Jarzynski. Escorted free energy simulations: Improving convergence by reducing dissipation. *Phys. Rev. Lett.*, 100:190601, 2008.
- [468] A. M. Hahn and H. Then. Using bijective maps to improve free energy estimates. *Phys. Rev. E*, 79:011113, 2009.
- [469] P. Nicolini and R. Chelli. Improving fast-switching free energy estimates by dynamicsl freezing. *Phys. Rev. E*, 80:041124, 2009.
- [470] H. Oberhofer and C. Dellago. Efficient extraction of free energy profiles from nonequilibrium experiments. *J. Comp. Chem.*, 30:1726, 2009.
- [471] M. Goette and H. Grubm¨uller. Accuracy and convergence of free energy differences calculated from nonequilibrium switching processes. *J. Comp. Chem.*, 30:447–456, 2009.
- [472] G. E. Lindberg, T. C. Berkelbach, and W. Feng. Optimizing the switching function for nonequilibrium free-energy calculations: An one-the-fly approach. *J. Chem. Phys.*, 130:174705, 2009.
- [473] E. N. Zimanyi and R. J. Silbey. The work-Hamiltonian connection and the usefulness of the Jarzynski equality for free energy calculations. *J. Chem. Phys.*, 130:171102, 2009.
- [474] A. Pohorille, C. Jarzynski, and C. Chipot. Good practices in free-energy calculations. *J. Phys. Chem. B*, 114:10235–10253, 2010.
- [475] D. D. L. Minh and J. D. Chodera. Estimating equilibrium ensemble averages using multiple time slices from driven nonequilibrium processes: Theory and application to free energies, moments, and thermodynamic length in single-molecule pulling experiments. *J. Chem. Phys.*, 134:024111, 2011.
- [476] D. D. L. Minh and S. Vaikuntanathan. Density-dependent analysis of nonequilibrium paths improves free energy estimates II. A FeynmanKac formalism. *J. Chem. Phys.*, 134:034117, 2011.
- [477] S. Vaikuntanathan and C. Jarzynski. Escorted free energy simulations. *J. Chem. Phys.*, 134:054107, 2011.
- [478] A. Davydov. Inequalities for non-equilibrium fluctuations of work. *J. Stat. Phys.*, 142:394–402, 2011.
- [479] M. Palassini and F. Ritort. Improving free-energy estimates from unidirectional work. *Phys. Rev. Lett.*, 107:060601, 2011.
- [480] A. Kundu, S. Sabhapandit, and A. Dhar. Application of importance sampling to the computation of large deviations in nonequilibrium processes. *Phys. Rev. E*, 83:031119, 2011.
- [481] K. Hayashi, H. Ueno, R. Iino, and H. Noji. Fluctuation theorem applied to F1-ATPase. *Phys. Rev. Lett.*, 104:218103, 2010.
- [482] S. Toyabe, T. Okamoto, T. Watanabe-Nakayama, H. Taketani, S. Kudo, and E. Muneyuki. Nonequilibrium energetics of a single F1-ATPase molecule. *Phys. Rev. Lett.*, 104:198103, 2010.
- [483] S. Toyabe, T. Watanabe-Nakayama, T. Okamoto, S. Kudo, and E. Muneyuki. Thermodynamic efficiency and mechanochemical coupling of F1-ATPase. *Proc. Natl. Acad. Sci. U.S.A.*, 108:17951–17956, 2011.
- [484] T. J. Xiao, Z. H. Hou, and H. W. Xin. Entropy production and fluctuation theorem along a stochastic limit cycle. *J. Chem. Phys*, 129:114506, 2008.
- [485] T. J. Xiao, Z. H. Hou, and H. W. Xin. Stochastic thermodynamics in mesoscopic chemical

- oscillation systems. *J. Phys. Chem. B*, 113:9316, 2009.
- [486] T. Rao, T. Xiao, and Z. Hou. Entropy production in a mesoscopic chemical reaction system with oscillatory and excitable dynamics. *J. Chem. Phys.*, 134:214112, 2011.
- [487] W. R. Browne and B. L. Feringa. Making molecular machines work. *Nature Nanotechnology*, 1:25–35, 2006.
- [488] E. R. Kay, D. A. Leigh, and F. Zerbetto. Synthetic molecular motors and mechanical machines. *Angew. Chemie - Int. Edition*, 46:72–191, 2007.
- [489] J. Bath and A. J. Turberfield. DNA nanomachines. *Nature Nanotechnology*, 2:275–284, 2007.
- [490] M. G. L. van den Heuvel and C. Dekker. Motor proteins at work for nanotechnology. *Science*, 317:333–336, 2007.
- [491] V. Balzani, A. Credi, and M. Venturi. Light powered molecular machines. *Chem. Soc. Rev.*, 38:1542–1550, 2009.
- [492] A. Coskun, M. Banaszak, R. D. Astumian, J. F. Stoddart, and B. A. Grzybowski. Great expectations: can artificial molecular machines deliver on their promise? *Chem. Soc. Rev.*, 41:19–30, 2012.
- [493] P. H¨anggi and F. Marchesoni. Artificial Brownian motors: Controlling transport on the nanoscale. *Rev. Mod. Phys*, 81:387–442, 2009.
- [494] N. A. Sinitsyn. The stochastic pump effect and geometric phases in dissipative and stochastic systems. *J. Phys. A Math. Theor.*, 42:193001, 2009.
- [495] R. D. Astumian. Stochastic conformational pumping: A mechanism for free-energy transduction by molecules. *Ann. Rev. Biophys.*, 40:289–313, 2011.
- [496] U. Seifert. Efficiency of autonomous soft nano-machines at maximum power. *Phys. Rev. Lett.*, 106:020601, 2011.
- [497] I. Derenyi, M. Bier, and R. D. Astumian. Generalized efficiency and its application to microscopic engines. *Phys. Rev. Lett.*, 83:903, 1999.
- [498] H. Wang and G. F. Oster. The Stokes efficiency for molecular motors and its applications. *Europhys. Lett.*, 57:134, 2002.
- [499] B. Gaveau, M. Moreau, and L. S. Schulman. Stochastic thermodynamics and sustainable efficiency in work production. *Phys. Rev. Lett.*, 105:060601, 2010.
- [500] M. Moreau, B. Gaveau, and L. S. Schulman. Stochastic dynamics, efficiency and sustainable power production. *Eur. Phys. J. B*, 62:67–71, 2011.
- [501] B. Gaveau, M. Moreau, and L. S. Schulman. Constrained maximal power in small engines. *Phys. Rev. E*, 82:051109, 2010.
- [502] S. R. de Groot and P. Mazur. *Non-equilibrium thermodynamics*. North-Holland, Amsterdam, 1962.
- [503] N. Pottier. *Nonequilibrium Statistical Physics: Linear Irreversible Processes*. Oxford University Press, New York, 2009.
- [504] O. Kedem and S. R. Caplan. Degree of coupling and its relation to efficiency of energy conversion. *Trans. Faraday Soc.*, 61:1897, 1965.
- [505] T. Schmiedl and U. Seifert. Efficiency of molecular motors at maximum power. *EPL*, 83:30005, 2008.
- [506] C. van den Broeck. Efficiency of isothermal molecular machines at maximum power. *arXiv: 1201.6396*, 2012.
- [507] K. Kawaguchi and M. Sano. Efficiency of free energy transduction in autonomous systems. *J. Phys. Soc. Japan*, 80:083003, 2011.
- [508] A. Efremov and Z. Wang. Universal optimal working cycles of molecular motors. *Phys. Chem. Chem. Phys.*, 13:6223–6233, 2011.
- [509] R. Golestanian. Synthetic mechanochemical molecular swimmer. *Phys. Rev. Lett.*, 105:018103, 2010.
- [510] M. O. Magnasco. Molecular combustion motors. *Phys. Rev. Lett.*, 72:2656–2659, 1994.
- [511] A. Parmeggiani, F. J¨ulicher, A. Ajdari, and J. Prost. Energy transduction of isothermal ratchets: Generic aspects and specific examples close to and far from equilibrium. *Phys. Rev. E*, 60:2127, 1999.
- [512] H. Wang. Chemical and mechanical efficiencies of molecular motors and implications for motor mechanisms. *J. Phys. Cond. Mat.*, 17:S3997–S4014, 2005.
- [513] M. Qian, X. Zhang, R. J. Wilson, and J. Feng. Efficiency of Brownian motors in terms of entropy production rate. *EPL*, 84, 2008.
- [514] E. Boksenbojm and B. Wynants. The entropy and efficiency of a molecular motor model. *J. Phys. A: Math. Theor.*, 42, 2009.
- [515] E. Gerritsma and P. Gaspard. Chemomechanical coupling and stochastic thermodynamics of the F1-ATPase molecuar motor with an applied external torque. *Biophys. Rev. Lett.*,

- 5:163–208, 2010.
- [516] N. Golubeva, A. Imparato, and L. Peliti. Efficiency of molecular machines with continuous phase space. *EPL*, 97:60005, 2012.
- [517] S. Toyabe, H. Ueno, and E. Muneyuki. Recovery of state-specific potential of molecular motor from single-molecule trajectory. *EPL*, 97:40004, 2012.
- [518] E. Zimmermann and U. Seifert. preprint. 2012.
- [519] F. L. Curzon and B. Ahlborn. Efficiency of a Carnot engine at maximum power output. *Am. J. Phys.*, 43:22, 1975.
- [520] I. I. Novikov. The efficiency of atomic power stations. *J. Nucl. Energy II*, 7:125–128, 1958.
- [521] L. Chen, C. Wu, and F. Sun. Finite time thermodynamic optimization of entropy generation minimization of energy systems. *J. Non-Equilib. Thermodyn.*, 24:327–359, 1999.
- [522] P. Salamon, J. D. Nulton, G. Siragusa, T. R. Andersen, and A. Limon. Principles of control thermodynamics. *Energy*, 26:307–319, 2001.
- [523] K. H. Hoffmann, J. Burzler, A. Fischer, M. Schaller, and S. Schubert. Optimal process paths for endoreversible systems. *J. Noneq. Thermodyn.*, 28:233–268, 2003.
- [524] B. Andresen. Current trends in finite-time thermodynamics. *Angew. Chem. Int. Ed.*, 50:2690– 2704, 2011.
- [525] C. van den Broeck. Thermodynamic efficiency at maximum power. *Phys. Rev. Lett.*, 95:190602, 2005.
- [526] B. Jim´enez de Cisneros and A. C. Hern´andez. Collective working regimes for coupled heat engines. *Phys. Rev. Lett.*, 98:130602, 2007.
- [527] M. Esposito, R. Kawai, K. Lindenberg, and C. van den Broeck. Efficiency at maximum power of low-dissipation carnot engines. *Phys. Rev. Lett.*, 105:150603, 2010.
- [528] Y. Izumida and K. Okuda. Molecular kinetic analysis of a finite-time Carnot cycle. *EPL*, 83:60003, 2008.
- [529] Y. Izumida and K. Okuda. Onsager coefficients of a finite-time Carnot cycle. *Phys. Rev. E*, 80:021121, 2009.
- [530] Y. Izumida and K. Okuda. Numerical experiments of a finite-time thermodynamic cycle. *Progr. Theor. Phys. Suppl.*, 178:163, 2009.
- [531] N. A. Sinitsyn. Fluctuation relation for heat engines. *J. Phys. A: Math. Gen.*, 44:405001, 2011.
- [532] Z. C. Tu. Efficiency at maximum power of Feynman's ratchet as a heat engine. *J. Phys. A: Math. Theor.*, 41:312003, 2008.
- [533] M. Esposito, K. Lindenberg, and C. van den Broeck. Universality of efficiency at maximum power. *Phys. Rev. Lett.*, 102:130602, 2009.
- [534] N. S´anchez-Salas, L. L´opez-Palacios, S. Velasco, and A. Calvo Hern´andez. Optimization criteria, bounds, and efficiencies of heat engines. *Phys. Rev. E*, 82:051101, 2010.
- [535] C. de Tom´as, A. C. Hern´andez, and J. M. M. Roco. Optimal low symmetric dissipation Carnot engines and refrigerators. *Phys. Rev. E*, 85:010104, 2012.
- [536] M. B¨uttiker. Transport as a consequence of state-dependent diffusion. *Z. Phys. B*, 68:161, 1987.
- [537] N. G. van Kampen. Relative stability in nonuniform temperature. *IBM J. of Research and Development*, 32:107–111, 1988.
- [538] R. Landauer. Motion out of noisy states. *J. Stat. Phys.*, 53:233, 1988.
- [539] I. Derenyi and R. D. Astumian. Efficiency of Brownian heat engines. *Phys. Rev. E*, 59:R6219– R6222, 1999.
- [540] M. Matsuo and S. Sasa. Stochastic energetics of non-uniform temperature systems. *Physica A*, 276:188, 2000.
- [541] T. Hondou and K. Sekimoto. Unattainability of Carnot efficiency in the Brownian heat engine. *Phys. Rev. E*, 62:6021, 2000.
- [542] K. Sekimoto, F. Takagi, and T. Hondou. Carnot's cycle for small systems: Irreversibility and cost of operations. *Phys. Rev. E*, 62:7759, 2000.
- [543] R. Benjamin and R. Kawai. Inertial effects in buttiker-Landauer motor and refrigerator at the overdamped limit. *Phys. Rev. E*, 77:051132, 2008.
- [544] M. Asfaw and M. Bekele. Current, maximum power and optimized efficiency of a Brownian heat engine. *Eur. Phys. J. B*, 38:457, 2004.
- [545] A. Gomez-Marin and J. M. Sancho. Tight coupling in thermal Brownian motors. *Phys. Rev. E*, 74:062102, 2006.
- [546] M. Asfaw. Modeling an efficient Brownian heat engine. *Eur. Phys. J. B*, 65:109–116, 2008.
- [547] F. Berger, T. Schmiedl, and U. Seifert. Optimal potentials for temperature ratchets. *Phys. Rev. E*, 79:031118, 2009.

[548] C. Jarzynski and O. Mazonka. Feynman's ratchet and pawl: An exactly solvable model. *Phys. Rev. E*, 59:6448–6459, 1999.

- [549] S. Velasco, J. M. M. Roco, A. Medina, and A. C. Hernandez. Feynman's ratchet optimization: maximum power and maximum efficiency regimes. *J. Phys. D*, 34:1000–1006, 2001.
- [550] Y. P. Zhang, J. Z. He, X. A. He, and J. L. Xiao. Thermodynamic performance characteristics of a Brownian microscopic heat engine driven by discrete and periodic temperature field. *Comm. Theor. Phys.*, 54:857–862, 2010.
- [551] L. Chen, Z. Ding, and F. Sun. Optimum performance analysis of Feynman's engine as cold and hot ratchets. *J. Non-Equilib. Thermodyn.*, 36:155–177, 2011.
- [552] R. P. Feynman, R. B. Leighton, and M. Sands. *The Feynman Lectures on Physics. Vol. I*. Addison-Wesley, Reading, MA, 1963.
- [553] J. M. R. Parrondo and P. Espanol. Criticism of Feynman's analysis of the ratchet as an engine. *Am. J. Phys.*, 64:1125–1130, 1996.
- [554] C. van den Broeck, R. Kawai, and P. Meurs. Microscopic analysis of a thermal Brownian motor. *Phys. Rev. Lett.*, 93:090601, 2004.
- [555] J. Zheng, X. Zheng, C. Y. Yam, and G. H. Chen. Computer simulation of Feynman's ratchet and pawl system. *Phys. Rev. E*, 81:061104, 2010.
- [556] S. Duhr and D. Braun. Thermophoretic depletion follows Boltzmann distribution. *Phys. Rev. Lett.*, 96:168301, 2006.
- [557] T. E. Humphrey, R. Newbury, R. P. Taylor, and H. Linke. Reversible quantum Brownian heat engines for electrons. *Phys. Rev. Lett.*, 89:116801, 2002.
- [558] T. E. Humphrey and H. Linke. Reversible thermoelectric nanomaterials. *Phys. Rev. Lett.*, 94:096601, 2005.
- [559] M. Esposito, K. Lindenberg, and C. van den Broeck. Thermoelectric efficiency at maximum power in a quantum dot. *Europhys. Lett.*, 85:60010, 2009.
- [560] R. S´anchez and M. B¨uttiker. Optimal energy quanta to current conversion. *Phys. Rev. B*, 83:085428, 2011.
- [561] M. Esposito, N. Kumar, K. Lindenberg, and C. van den Broeck. Stochastically driven single level quantum dot: a nano-scale finite-time thermodynamic machine and its various operational modes. *arXiv: 1201.0669*, 2012.
- [562] G. Benenti, K. Saito, and G. Casati. Thermodynamic bounds on efficiency for systems with broken time-reversal symmetry. *Phys. Rev. Lett.*, 106:230602, 2011.
- [563] K. Saito, G. Benenti, G. Casati, and T. Prosen. Thermopower with broken time-reversal symmetry. *Phys. Rev. B*, 84:201306, 2011.
- [564] B. Rutten, M. Esposito, and B. Cleuren. Reaching optimal efficiencies using nanosized photoelectric devices. *Phys. Rev. B*, 80:235122, 2009.
- [565] Y. Izumida and K. Okuda. Efficiency at maximal power of minimal nonlinear irreversible heat engines. *EPL*, 97:10004, 2012.
- [566] Y. Wang and Z. C. Tu. Efficiency at maximum power output of linear irreversible Carnot-like heat engines. *Phys. Rev. E*, 85:011127, 2012.
- [567] Y. Wang and Z. C. Tu. Bounds of efficiency at maximum power for linear, superlinear and sublinear irreversible Carnot-like heat engines. *arXiv: 1110.6493*, 2011.
- [568] Y. Apertet, H. Ouerdane, C. Goupil, and P. Lecoeur. Irreversibilities and efficiency at maximum power of heat engines: The illustrative case of a thermoelectric generator. *Phys. Rev. E*, 85:031116, 2012.
- [569] Y. Izumida and K. Okuda. Onsager coefficients of a Brownian Carnot cycle. *Eur. Phys. J. B*, 77:499–504, 2010.
- [570] V. Blickle and C. Bechinger. Realization of a micrometre-sized stochastic heat engine. *Nature Phys.*, 8:143, 2012.
- [571] J. M. Horowitz and J. M. R. Parrondo. Thermodynamics: A Stirling effort. *Nature Phys.*, 8:108–109, 2012.
- [572] M. Esposito, R. Kawai, K. Lindenberg, and C. van den Broeck. Quantum-dot Carnot engine at maximum power. *Phys. Rev. E*, 81:041106, 2010.
- [573] P. Chvosta, M. Einax, V. Holubec, A. Ryabov, and P. Maass. Energetics and performance of a microscopic heat engine based on exact calculations of work and heat distributions. *J. Stat. Mech.: Theor. Exp.*, page P03002, 2010.
- [574] G. Lan, P. Sartori, S. Neumann, V. Sourjik, and Y. Tu. The energyspeedaccuracy trade-off in sensory adaptation. *Nature Phys.*, 2012.
- [575] J. Farago. Power fluctuations in stochastic models of dissipative systems. *Physica A*, 331:69– 89, 2004.
- [576] H. Jiang, T. Xiao, and Z. Hou. Stochastic thermodynamics for delayed Langevin systems.

- *Phys. Rev. E*, 83:061144, 2011.
- [577] A. Baule and E. G. D. Cohen. Steady-state work fluctuations of a dragged particle under external and thermal noise. *Phys. Rev. E*, 80:011110, 2009.
- [578] T. Speck and U. Seifert. The Jarzynski relation, fluctuation theorems, and stochastic thermodynamics for non-markovian processes. *J. Stat. Mech.: Theor. Exp.*, page L09002, 2007.
- [579] T. Ohkuma and T. Ohta. Fluctuation theorems for non-linear generalized Langevin systems. *J. Stat. Mech.: Theor. Exp.*, page P10010, 2007.
- [580] J. Ohkubo. Posterior probability and fluctuation theorem in stochastic processes. *J. Phys. Soc. Japan*, 78:123001, 2009.
- [581] C. Aron, G. Biroli, and L. F. Cugliandolo. Symmetries of generating functionals of Langevin processes with colored multiplicative noise. *J. Stat. Mech.: Theor. Exp.*, page P11018, 2010.
- [582] T. Mai and A. Dhar. Nonequilibrium work fluctuations for oscillators in non-markovian baths. *Phys. Rev. E*, 75:061101, 2007.
- [583] A. Puglisi and D. Villamaina. Irreversible effects of memory. *EPL*, 88:30004, 2009.
- [584] H. Hasegawa. Classical open systems with nonlinear nonlocal dissipation and state-dependent diffusion: Dynamical responses and the Jarzynski equality. *Phys. Rev. E*, 84:051124, 2011.
- [585] T. Franosch, M. Grimm, M. Belushkin, F. M. Mor, G. Foffi, L. Forro, and S. Jeney. Resonances arising from hydrodynamic memory in Brownian motion. *Nature*, 478:85–88, 2011.
- [586] J. Mehl, B. Lander, C. Bechinger, V. Blickle, and U. Seifert. Role of hidden slow degrees of freedom in the fluctuation theorem. *arXiv: 1205.0238*, 2012.
- [587] A. Crisanti, A. Puglisi, and D. Villamaina. Non-equilibrium and information: the role of cross-correlations. *arXiv:1202.0508*, 2012.
- [588] H. Qian and M. Qian. Pumped biochemical reactions, nonequilibrium circulation, and stochastic resonance. *Phys. Rev. Lett.*, 84:2271, 2000.
- [589] C. P. Amann, T. Schmiedl, and U. Seifert. Communications: Can one identify nonequilibrium in a three-state system by analyzing two-state trajectories? *J. Chem. Phys.*, 132:041102, 2010.
- [590] E. Roldan and J. M. R. Parrondo. Estimating dissipation from single stationary trajectories. *Phys. Rev. Lett.*, 105:150607, 2010.
- [591] E. Roldan and J. M. R. Parrondo. Entropy production and Kullback-Leibler divergence between stationary trajectories of discrete systems. *Phys. Rev. E*, 85:031129, 2012.
- [592] S. Rahav and C. Jarzynski. Fluctuation relations and coarse-graining. *J. Stat. Mech.: Theor. Exp.*, page P09012, 2007.
- [593] Y. Li, T. Zhao, P. Bhimalapuram, and A. R. Dinner. How the nature of an observation affects single-trajectory entropies. *J. Chem. Phys.*, 128:074102, 2008.
- [594] A. Puglisi, S. Pigolotti, L. Rondoni, and A. Vulpiani. Entropy production and coarse graining in markov processes. *J. Stat. Mech.*, page P05015, 2010.
- [595] G. Szab´o, T. Tom´e, and I. Borsos. Probability currents and entropy production in nonequilibrium lattice systems. *Phys. Rev. E*, 82:011105, 2010.
- [596] G. Nicolis. Transformation properties of entropy production. *Phys. Rev. E*, 83:011112, 2011.
- [597] H. Hinrichsen, C. Gogolin, and P. Janotta. Non-equilibrium dynamics, thermalization and entropy production. *J. Phys. Conf. Ser.*, 297:012011, 2011.
- [598] M. Esposito. Stochastic thermodynamics under coarse-graining. *arXiv: 1112.5410*, 2012.
- [599] B. Altaner and J. Vollmer. Fluctuation preserving coarse graining for biochemical systems. *arXiv: 1112.4745*, 2012.
- [600] E. Bertin, K. Martens, O. Dauchot, and M. Droz. Intensive thermodynamic parameters in nonequilibrium systems. *Phys. Rev. E*, 75:031120, 2007.
- [601] P. Pradhan, C. P. Amann, and U. Seifert. Nonequilibrium steady states in contact: approximate thermodynamic structure and zeroth law for driven lattice gases. *Phys. Rev. Lett.*, 105:150601, 2010.
- [602] P. Pradhan, R. Ramsperger, and U. Seifert. Approximate thermodynamic structure for driven lattice gases in contact. *Phys. Rev. E*, 84:041104, 2011.