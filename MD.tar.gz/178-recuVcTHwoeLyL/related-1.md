# Ensemble and Trajectory Thermodynamics: A Brief Introduction.

Christian Van den Broeck Hasselt University - B-3590 Diepenbeek, Belgium

## Massimiliano Esposito

Complex Systems and Statistical Mechanics, University of Luxembourg, L-1511 Luxembourg, Luxembourg

We revisit stochastic thermodynamics for a system with discrete energy states in contact with a heat and particle reservoir.

#### PACS numbers: 05.70.Ln,05.40.-a,05.20.-y

# I. INTRODUCTION

Over the last few years, it has become clear that one can extend thermodynamics, which is traditionally confined to the description of equilibrium states of macroscopic systems or to the transition between such states, to cover the nonequilibrium dynamics of small scale systems. This extension has been carried out at several levels of description including systems described by discrete and continuous Markovian and non-Markovian stochastic dynamics, by classical Hamiltonian and quantum Hamiltonian dynamics and by thermostatted systems. These developments can be seen, on one side, as extending the work of Onsager and Prigogine [1–4] by including microscopic dynamical properties into the far from equilibrium irreversible realm. On the other side, they have led to the reassessment of the cornerstone of thermodynamics, namely the second law of thermodynamics, which is replaced by a much deeper symmetry relation, embodied in the integral and detailed fluctuation theorems. On the more practical side, the new formulation allows to address new questions, either related to nonequilibrium properties, such as efficiency at maximum power or information to work conversion, or relating to the thermodynamic description of small systems, e.g., the discussion of Brownian motors and refrigerators or the efficiency of quantum dots and other small scale devices. In this paper, we present a brief introduction to stochastic thermodynamics. We refer to the literature for more advanced reviews [5–13].

## II. ENSEMBLE THERMODYNAMICS

We consider a system, with discrete non-degenerate states, in contact with a single (ideal, non-dissipative) heat and particle reservoir at temperature T ( $\beta = 1/(k_BT)$ ) and chemical potential  $\mu$ . The states are identified by an index m, with corresponding energy  $\epsilon_m$  and particle number  $n_m$ . For simplicity we consider a single type of particle. We assume that the system can also exchange work with an (ideal, non-dissipative) work source which controls its energy levels  $\epsilon(\lambda)$  via an time-dependent control parameter  $\lambda = \lambda(t)$ . The particle number in a given state is however supposed to be fixed.

In the ensemble picture, the state of the system is described by a probability distribution  $P_m$  to be in the state m, with  $\sum_m P_m = 1$ . Note that this distribution does not have to be of the equilibrium form, so that "traditional equilibrium concepts", such as temperature and chemical potential need not exist for the system. They are however well defined for the ideal reservoir, and when appearing in the formulas below, T and  $\mu$  refer to this reservoir. The time evolution of the state is described by a Markovian master equation:

$$d_t P_m = \sum_{m'} W_{m,m'} P_{m'}. (1)$$

Here  $W_{m,m'}$  is the probability per unit time to make a transition from state m' to m. We use the shorthand notation with diagonal elements defined as  $W_{m,m} = -\sum_{m' \neq m} W_{m',m}$ . Alternatively:

$$\sum W_{m,m'} = 0, \tag{2}$$

a property that guarantees the conservation of normalization. The transition rates have to satisfy an additional property. In the steady state, the system is at equilibrium with the reservoir. Statistical physics prescribes that the steady state distribution is given by the grand canonical equilibrium distribution  $P_m^{eq}$  [14]:

<span id="page-0-1"></span>
$$P_m^{eq} = \exp\{-\beta(\epsilon_m - \mu n_m - \Omega^{eq})\}. \tag{3}$$

The (equilibrium) grand potential  $\Omega^{eq}$  follows from the normalization of  $P^{eq}$ :

$$\exp\{-\beta\Omega^{eq}\} = \sum_{m} \exp\{-\beta(\epsilon_m - \mu n_m)\}.$$
 (4)

The crucial property that is required from the rates is the so-called condition of detailed balance, i.e., at equilibrium every transition, say from m to m', and its inverse, from m' to m, have to be equally likely:

$$W_{m,m'}P_{m'}^{eq} = W_{m',m}P_{m}^{eq}. (5)$$

Combined with the explicit expression of the equilibrium distribution, this gives:

<span id="page-0-0"></span>
$$k_B \ln \frac{W_{m',m}}{W_{m,m'}} = \frac{\epsilon_m - \epsilon_{m'} - \mu(n_m - n_{m'})}{T} = \frac{q_{m,m'}}{T}.(6)$$

 $q_{m,m'}$  is the "elementary" heat absorbed by the system to make the transition from m' to m. We stress that in the presence of driving, which is shifting the energy levels in time, this relation is supposed to hold at each moment in time, hence the rates also become time-dependent. This condition will be crucial to obtain the correct formulation of the second law.

We next introduce the basic state functions -quantities that depend on probability distribution  $P_m$  of the system, but not on the way this distribution was achieved-namely the ensemble-averaged and in general nonequilibrium values of energy, particle number and entropy:

<span id="page-1-3"></span>
$$E = \sum_{m} \epsilon_m P_m = \langle \epsilon_m \rangle, \tag{7}$$

$$N = \sum_{m} n_m P_m = \langle n_m \rangle, \tag{8}$$

$$S = -k_B \sum_{m} P_m \ln P_m = \langle -k_B \ln P_m \rangle. \tag{9}$$

It is clear from the above formulas that these state variables can change due to two different mechanisms: a change in occupation of the levels, i.e., a modification of  $P_m$ , or a shift of the energy levels, i.e., a change of the energy level  $\epsilon_m$ . In particular, the rate of energy change is given by:

<span id="page-1-4"></span>
$$d_t E = \sum_m \{ \epsilon_m d_t P_m + d_t \epsilon_m P_m \}$$
 (10)

$$= \dot{Q} + \dot{W}_{chem} + \dot{W} \tag{11}$$

This decomposition reproduces the first law. Work rate (power)  $\dot{W}$ , particle flow  $d_t N$  and heat flow  $\dot{Q}$  are given by:

<span id="page-1-0"></span>
$$\dot{W} = \sum_{m} d_t \epsilon_m P_m = d_t \lambda \ d_\lambda E, \tag{12}$$

$$d_t N = \sum_m n_m d_t P_m, \tag{13}$$

$$\dot{Q} = \sum_{m} \epsilon_{m} d_{t} P_{m} - \dot{W}_{chem}. \tag{14}$$

with the chemical work rate  $\dot{W}_{chem}$ 

<span id="page-1-1"></span>
$$\dot{W}_{chem} = \mu d_t N. \tag{15}$$

In words, work is the result of the energy shift of an occupied state. Heat and chemical work correspond to transitions between states, implying a change in occupation probability. As is well known, heat and work are not state functions (or the difference of state functions) as they depend on the way the transition between states is carried out. We also mention for later use the following expression for the heat flux, cf. (13,14,15):

<span id="page-1-2"></span>
$$\dot{Q} = \sum_{m} (\epsilon_m - \mu n_m) d_t P_m. \tag{16}$$

Turning to the second law, we will show that the above definition of nonequilibrium entropy is a proper choice that reduces to the standard thermodynamic entropy at equilibrium, but with the additional advantage that it preserves -in nonequilibrium- the basic features of the second law, namely the relation between heat and entropy exchange and the positivity of the entropy production. Explicitly:

<span id="page-1-5"></span>
$$d_t S = \dot{S}_e + \dot{S}_i, \tag{17}$$

$$\dot{S}_e = \dot{Q}/T,\tag{18}$$

$$\dot{S}_i \ge 0. \tag{19}$$

The proof goes as follows:

$$d_{t}S = -k_{B} \sum_{m} d_{t}P_{m} \ln P_{m} = -k_{B} \sum_{m,m'} W_{m,m'}P_{m'} \ln P_{m}$$

$$= -k_{B} \sum_{m,m'} W_{m,m'}P_{m'} \ln \frac{P_{m}}{P_{m'}}$$

$$= \frac{k_{B}}{2} \sum_{m,m'} (W_{m,m'}P_{m'} - W_{m',m}P_{m}) \ln \frac{P_{m'}}{P_{m}}$$

$$= \frac{k_{B}}{2} \sum_{m,m'} (W_{m,m'}P_{m'} - W_{m',m}P_{m}) \ln \frac{W_{m,m'}P_{m'}}{W_{m',m}P_{m}}$$

$$+ \frac{k_{B}}{2} \sum_{m,m'} (W_{m,m'}P_{m'} - W_{m',m}P_{m}) \ln \frac{W_{m',m}}{W_{m,m'}}. (20)$$

We thus identify the entropy production and entropy flow as:

$$\dot{S}_{i} = \frac{k_{B}}{2} \sum_{m,m'} (W_{m,m'} P_{m'} - W_{m',m} P_{m}) \ln \frac{W_{m,m'} P_{m'}}{W_{m',m} P_{m}} (21)$$

$$\dot{S}_e = \frac{k_B}{2} \sum_{m,m'} (W_{m,m'} P_{m'} - W_{m',m} P_m) \ln \frac{W_{m',m}}{W_{m,m'}}, \quad (22)$$

or:

$$\dot{S}_i = \sum_{m,m'} J_{m,m'} X_{m,m'}, \tag{23}$$

$$\dot{S}_e = \sum_{m>m'} J_{m,m'} \frac{q_{m,m'}}{T},$$
 (24)

with

$$J_{m,m'} = W_{m,m'} P_{m'} - W_{m',m} P_m, \tag{25}$$

$$X_{m,m'} = k_B \ln \frac{W_{m,m'} P_{m'}}{W_{m',m} P_m},$$
(26)

$$q_{m,m'} = \epsilon_m - \epsilon_{m'} - \mu(n_m - n_{m'}). \tag{27}$$

 $J_{m,m'}$  is the net rate of transitions from m' to m and  $X_{m,m'}$  the corresponding thermodynamic force.  $\dot{S}_i$  is clearly non-negative. In fact, a stronger property holds: it is the sum of contributions due to all pairwise transitions between different states m and m', and each of these terms in non-negative. Concerning  $\dot{S}_e$ , one finds

using (6,16):

$$\dot{S}_e = k_B \sum_{m,m'} W_{m,m'} P_{m'} \ln \frac{W_{m',m}}{W_{m,m'}}$$
 (28)

$$= \sum_{m,m'} W_{m,m'} P_{m'} \frac{\epsilon_m - \epsilon_{m'} - \mu(n_m - n_{m'})}{T}$$
 (29)

$$=\sum_{m,m'}W_{m,m'}P_{m'}\frac{\epsilon_m-\mu n_m}{T}$$
(30)

$$=\sum_{m}d_{t}P_{m}\frac{\epsilon_{m}-\mu n_{m}}{T}=\frac{\dot{Q}}{T},$$
(31)

which is indeed the expected expression for the entropy flow.

Besides energy, particle number and entropy, it is convenient to introduce another state function, namely the grand potential:

<span id="page-2-0"></span>
$$\Omega = E - TS - \mu N. \tag{32}$$

One immediately finds that:

$$d_t \Omega = d_t E - T d_t S - \mu d_t N = \dot{W} - T \dot{S}_i \tag{33}$$

or

<span id="page-2-1"></span>
$$T\dot{S}_i = \dot{W} - d_t \Omega \ge 0. \tag{34}$$

As a consequence the rate of decrease  $-d_t\Omega$  in grand potential is an upper bound for the corresponding output power  $-\dot{W}$ .

The above description provides a generalization of the usual equilibrium thermodynamics to far from equilibrium states. It is reassuring that at equilibrium it reproduce the properties of the equilibrium state. By filling in the equilibrium expression for the probability distribution (3) in (7,8,9,32), one finds the corresponding results for the energy, number of particles, entropy and grand potential,  $E^{eq}$ ,  $N^{eq}$ ,  $S^{eq}$ ,  $\Omega^{eq}$ . At equilibrium, (32) thus reproduces the equilibrium Euler relation  $\Omega^{eq} = E^{eq} - TS^{eq} - \mu N^{eq}$ . Note furthermore that the knowledge of the equilibrium grand potential as a function of T,  $\lambda$  and  $\mu$ ,  $\Omega^{eq} = \Omega^{eq}(T,\lambda,\mu)$  provides a fundamental relation, i.e., a full characterization of the system. The energy-particle spectrum that characterizes the system can be recovered through an inverse Laplace transform [14]. This is obviously no longer true for the nonequilibrium potential  $\Omega$ . We however point out the following revealing property: the nonequilibrium potential is always larger than its equilibrium value:

<span id="page-2-2"></span>
$$\Omega - \Omega^{eq} = k_B T I, \tag{35}$$

$$I = D(P||P^{eq}) = \sum_{m} P_m \ln \frac{P_m}{P_m^{eq}} \ge 0.$$
 (36)

Here  $D(P||P^{eq})$  is the relative entropy or Kullback Leibler distance [15] between the distributions P and  $P^{eq}$ . Combined with the second law under the form (34), we conclude that any nonequilibrium state has the potential to generate an output work of at most  $k_BTI$ , upper limit reached for a reversible scenario (zero entropy production).

We finally consider a quasi-static transformation generated by the work source. In this case the equilibrium shape of the distribution is preserved in time,  $P_m = P_m^{eq}(t)$ . Hence, as the energy levels are shifted via work, a corresponding instantaneous redistribution over the levels has to take place, with a concomitant heat and particle exchange. One immediately finds that for such a transformation:

$$d_t S = -k_B \sum_m d_t P_m^{eq} \ln P_m^{eq}$$
 (37)

$$= \sum_{m} d_t P_m^{eq} \frac{\epsilon_m - \mu n_m - \Omega^{eq}}{T}$$
 (38)

$$=\frac{\dot{Q}}{T}=\dot{S}_e. (39)$$

This also implies  $\dot{S}_i = 0$  and  $\dot{W} = d_t \Omega^{eq}$ . These relations reproduce the familiar thermodynamic statement for quasi-static processes:  $d_t S = \dot{Q}/T$ .

#### III. MULTIPLE RESERVOIRS

The case of multiple energy and particle reservoirs is of obvious theoretical and technological interest. On the theory side, we mention the study of nonequilibrium steady states. With respect to applications, engines, pumps and refrigerators all involve contact with multiple reservoirs. We briefly explain how the above formalism can be extended to cover this situation. The main new ingredient is the fact that the transitions in the system are now due to the coupling with the different reservoirs, which we identify by the index  $\nu$  (e.g., temperature  $T^{\nu}$ , chemical potential  $\mu^{\nu}$ , etc.). We assume that these contacts do not interfere, hence:

$$W_{m,m'} = \sum W_{m,m'}^{\nu}, \tag{40}$$

with  $W^{\nu}$  the transition matrix due to coupling with reservoir  $\nu$ . This latter satisfies detailed balance

$$W^{\nu}_{m,m'}P^{eq,\nu}_{m'}=W^{\nu}_{m',m}P^{eq,\nu}_{m} \eqno(41)$$

with respect to the equilibrium distribution  $P^{eq,\nu}$  imposed by reservoir  $\nu$  at each moment in time (i.e. for the prevailing energy spectrum  $\epsilon_m = \epsilon_m(t)$ ):

$$P_m^{eq,\nu} = \exp\{-\beta(\epsilon_m - \mu^{\nu}n_m - \Omega^{eq,\nu})\}, \quad (42)$$

$$\exp\{-\beta\Omega^{eq,\nu}\} = \sum_{m} \exp\{-\beta^{\nu}(\epsilon_m - \mu^{\nu}n_m)\}. \quad (43)$$

We can now write:

$$d_t P_m = \sum_{\nu} \dot{P}_m^{\nu},\tag{44}$$

$$\dot{P}_{m}^{\nu} = \sum_{m'} W_{m,m'}^{\nu} P_{m'}. \tag{45}$$

Hence, in all of the above the formulas where the derivative of the probability appears, one can identify the separate contributions of the different reservoirs. In particular, the first law (10) remains of course valid, but particle, heat and chemical work flux can be separated into contributions from each reservoir:

$$d_t N = \sum \dot{N}^{\nu}, \tag{46}$$

$$\dot{Q} = \sum_{\nu} \dot{Q}^{\nu},\tag{47}$$

$$\dot{W}_{chem} = \sum_{\nu} \dot{W}_{chem}^{\nu}, \tag{48}$$

with

$$\dot{N}^{\nu} = \sum_{m} n_m \dot{P}_m^{\nu},\tag{49}$$

$$\dot{Q}^{\nu} = \sum (\epsilon_m - \mu^{\nu} n_m) \dot{P}_m^{\nu}, \tag{50}$$

$$\dot{W}_{chem}^{\nu} = \sum_{m} \mu^{\nu} n_{m} \dot{P}_{m}^{\nu}. \tag{51}$$

For the second law, the derivation is modified as follows:

$$d_{t}S = -k_{B} \sum_{m} d_{t}P_{m} \ln P_{m} = -k_{B} \sum_{\nu} \sum_{m,m'} W_{m,m'}^{\nu} P_{m'} \ln P_{m}$$

$$= \sum_{\nu} \frac{k_{B}}{2} \sum_{m,m'} \left( W_{m,m'}^{\nu} P_{m'} - W_{m',m}^{\nu} P_{m} \right) \ln \frac{P_{m'}}{P_{m}}$$

$$= \frac{k_{B}}{2} \sum_{\nu} \sum_{m,m'} \left( W_{m,m'}^{\nu} P_{m'} - W_{m',m}^{\nu} P_{m} \right) \ln \frac{W_{m,m'}^{\nu} P_{m'}}{W_{m',m}^{\nu} P_{m}}$$

$$+ \frac{k_{B}}{2} \sum_{\nu} \sum_{m,m'} \left( W_{m,m'}^{\nu} P_{m'} - W_{m',m}^{\nu} P_{m} \right) \ln \frac{W_{m',m}^{\nu}}{W_{m,m'}^{\nu}}. \tag{52}$$

One thus finds:

$$\dot{S}_i = \sum_{\nu} \dot{S}_i^{\nu},\tag{53}$$

$$\dot{S}_e = \sum_{\nu} \dot{S}_e^{\nu},\tag{54}$$

with

$$\dot{S}_{i}^{\nu} = \sum_{m > m'} J_{m,m'}^{\nu} X_{m,m'}^{\nu}, \tag{55}$$

$$\dot{S}_e^{\nu} = \sum_{m > m'} J_{m,m'}^{\nu} \frac{q_{m,m'}^{\nu}}{T^{\nu}} = \frac{\dot{Q}^{\nu}}{T^{\nu}},\tag{56}$$

and

$$J_{m,m'}^{\nu} = W_{m,m'}^{\nu} P_{m'} - W_{m',m}^{\nu} P_m, \tag{57}$$

$$X_{m,m'}^{\nu} = k_B \ln \frac{W_{m,m'}^{\nu} P_{m'}}{W_{m',m}^{\nu} P_m},$$
(58)

$$q_{m,m'}^{\nu} = \epsilon_m - \epsilon_{m'} - \mu^{\nu} (n_m - n_{m'}). \tag{59}$$

The above formulas allow to investigate the far from equilibrium thermodynamics of small scale systems, for example of quantum dots in contact with leads [16–19]. Another question that has received a lot of attention is the universal features of the efficiency of such machines when operating at maximum power [20–29]. We finally mention the simplification in the absence of particle transport, achieved by setting in the above formulas all the chemical potentials equal to zero,  $\mu^{\nu} = 0, \forall \nu$ .

#### IV. TRAJECTORY THERMODYNAMICS

In the limit of a very large system (with no long range correlations), one expects by the law of large numbers that the properties are self-averaging, so that an ensemble description in terms of average quantities is sufficient. In a small scale system, this is no longer the case and the quantities that are measured will vary from one experiment to another. One could of course still apply the above presented ensemble thermodynamics to describe the average outcome upon repeating the experiment many times. Nevertheless, one can wonder about the stochastic properties that are revealed at the trajectory level. Furthermore, due to the spectacular progress in nano-technology, the experimental measurement of such properties are now within reach. But there is an even more important motivation: it turns out, as we proceed to show, that the trajectory properties reveal a much deeper formulation of the second law. We will limit our presentation, for clarity and simplicity of notation, to the case of a single particle and energy reservoir.

We thus consider a small system and focus on its trajectory in the course of time in a single realization of the experiment. The state of the system at time t is its actual state m=m(t). The analogues of the above introduced ensemble averaged state functions  $E,\ N,\ S$  and  $\Omega$  for this particular state are the stochastic energy e, the stochastic number of particles n, the stochastic entropy s introduced by Seifert [30], and the stochastic grand canonical potential  $\omega$  of this state:

<span id="page-3-0"></span>
$$e = \epsilon_{m(t)}(t), \tag{60}$$

$$n = n_{m(t)},\tag{61}$$

$$s = -k_B \ln P_{m(t)}(t), \tag{62}$$

$$\omega = e - Ts - \mu n. \tag{63}$$

We have assumed that the particle number of a given state is fixed, so that  $n_{m(t)}$  has no explicit time dependence. The above definitions are consistent with the ensemble description,  $E = \langle e \rangle$ ,  $N = \langle n \rangle$ ,  $S = \langle s \rangle$  and  $\Omega = \langle \omega \rangle$ , where the averaging bracket refer to an average with respect to the probability distribution  $P_{m(t)}(t)$ . We will henceforth use the lower case notation to distinguish the stochastic variables from the corresponding ensemble averaged quantities (it should be clear from the context not to confuse the energy e with Euler's number e = 2,718...). Note that at the trajectory level, there appears an essential difference between the variables e and e on the one hand, and e and e on the other hand: the

latter retain an ensemble character, trademark of their thermodynamic content, as they depend, not only on the actual state m(t), but also on the probability distribution  $P_{m(t)}$ . Hence, even though we are monitoring single trajectories, their thermodynamic properties are defined with respect to the stochastic dynamics of the system under consideration.

In the following it will be convenient, in order to take time-derivatives, to extract the time-dependence on the actual state m(t) with a delta-Kronecker function:

$$f_{m(t)}(t) = \sum_{m} \delta_{m,m(t)}^{Kr} f_m(t),$$
 (64)

$$d_t f_{m(t)}(t) = \sum_{m} \dot{\delta}_{m,m(t)}^{Kr} f_m(t) + \delta_{m,m(t)}^{Kr} d_t f_m(t).$$
 (65)

Note that the contribution in  $\dot{\delta}_{mm'}^{Kr}$  correspond to a change of level occupation from state m' to m and will give rise to a Dirac delta function contribution centered at the times  $t^*$  of the jumps and with amplitude  $f_m(t^*) - f_{m'}(t^*)$ .

The first law at the trajectory level is obtained by differentiating (60) with respect to time:

<span id="page-4-1"></span>
$$d_t e = \dot{q} + \dot{w}_{chem} + \dot{w},\tag{66}$$

$$\dot{w} = \sum_{m} \delta_{m,m(t)}^{Kr} d_t \epsilon_m(t), \tag{67}$$

$$\dot{q} = \sum_{m} \epsilon_{m}(t) \dot{\delta}_{m,m(t)}^{Kr} - \dot{w}_{chem}, \qquad (68)$$

$$\dot{w}_{chem} = \sum_{m} \mu n_m \dot{\delta}_{m,m(t)}^{Kr}.$$
 (69)

The interpretation is essentially the same as in the ensemble description: work corresponds to the shift of an occupied level while heat plus chemical work are the result of a transition between levels.

The second law at the trajectory level is obtained by calculating as follows the time-derivative of the stochastic entropy (62):

<span id="page-4-0"></span>
$$d_{t}s = -k_{B} \sum_{m} \{\dot{\delta}_{m,m(t)}^{Kr} \ln P_{m}(t) + \delta_{m,m(t)}^{Kr} \frac{d_{t}P_{m}(t)}{P_{m}(t)}\}$$

$$= -k_{B} \sum_{m} \{\dot{\delta}_{m,m(t)}^{Kr} \ln \frac{P_{m}(t)}{P_{m}^{eq}(t)} + \delta_{m,m(t)}^{Kr} \frac{d_{t}P_{m}(t)}{P_{m}(t)} + \dot{\delta}_{m,m(t)}^{Kr} \ln P_{m}^{eq}(t)\}.$$
(70)

Here we introduced the instantaneous equilibrium distribution  $P_m^{eq}(t)$ , see also (3):

<span id="page-4-4"></span>
$$P_m^{eq}(t) = \exp\{-\beta[\epsilon_m(t) - \mu n_m - \Omega^{eq}(t)]\}. \tag{71}$$

The crucial point is to identify the last term in the r.h.s. of (70) as the stochastic entropy flow, using (68,69):

<span id="page-4-2"></span>
$$\dot{s}_e = -k_B \sum_m \dot{\delta}_{m,m(t)}^{Kr} \ln P_m^{eq}(t)$$

$$= \frac{1}{T} \sum_m \dot{\delta}_{m,m(t)}^{Kr} \{ \epsilon_m(t) - \mu n_m \}$$

$$= \frac{\dot{q}}{T}.$$
(72)

From the decomposition

$$d_t s = \dot{s}_i + \dot{s}_e, \tag{73}$$

first obtained by Seifert in Ref. [30], we conclude that the stochastic entropy production is given by

<span id="page-4-3"></span>
$$\dot{s}_i = -k_B \sum_{m} \{ \dot{\delta}_{m,m(t)}^{Kr} \ln \frac{P_m(t)}{P_m^{eq}(t)} + \delta_{m,m(t)}^{Kr} \frac{d_t P_m(t)}{P_m(t)} \}. (74)$$

It consists of two different terms. The second one in the r.h.s. corresponds to a smooth contribution: it is positive or negative depending on whether the actual state becomes less or more probable in time. The first term in the r.h.s. gives discontinuous contributions, appearing at the instances when the actual state of the system changes. Note that neither of the above contributions has a definite sign.

By averaging the result (72) for entropy flow with  $P_{m(t)}(t)$ , one recovers its ensemble version (18). To do the same for the entropy production requires a little bit more work. By summation over all the actual states m(t) = m' (i.e. this index becomes a dummy summation variable) one finds that the second term in the stochastic entropy production (74) averages out to zero. As for the first term, we note that the stochastic entropy production jumps by an amount  $k_B \ln \frac{P_{m'}P_m^{eq}}{P_{m'}^{eq}P_m}$  for a change in state from m' to m. The probability per unit time for such a transition is  $W_{m,m'}P_{m'}$ . The average  $\langle \dot{s}_i \rangle$  of the stochastic entropy production thus becomes (note that the averaging brackets now refer to an average with respect to  $W_{m,m'}P_{m'}$ , and that we have dropped for simplicity of notation the explicit t dependence):

$$\dot{S}_{i} = k_{B} \sum_{m,m'} W_{m,m'} P_{m'} \ln \frac{P_{m'} P_{m}^{eq}}{P_{m'}^{eq} P_{m}}$$

$$= k_{B} \sum_{m,m'} W_{m,m'} P_{m'} \ln \frac{W_{m,m'} P_{m'}}{W_{m',m} P_{m}}$$

$$= \frac{k_{B}}{2} \sum_{m,m'} \{W_{m,m'} P_{m'} - W_{m',m} P_{m}\} \ln \frac{W_{m,m'} P_{m'}}{W_{m',m} P_{m}} \ge 0.$$

This is indeed the expression for the ensemble entropy production given earlier.

Turning to the stochastic grand potential (63), one finds by a combination of the stochastic first and second law, very much in the same way as for the ensemble average, that (compare with (34)):

<span id="page-4-5"></span>
$$T\dot{s}_i = \dot{w} - d_t \omega. \tag{76}$$

We next make the important observation that, when the probability distribution has the equilibrium form  $P_m = P_m^{eq}$ , and in particular for a quasi-static process  $P_m = P_m^{eq}(t)$ , cf. (71), the stochastic grand potential given in (63) becomes independent of the state, and reduces to the ensemble average instantaneous equilibrium expression (using the explicit expression for the stochastic entropy given in (62)):

$$\omega^{eq}(t) = \Omega^{eq}(t). \tag{77}$$

For a transition between an initial and a final equilibrium state (but with no conditions on the state of the system in the intermediate process), one can thus write by integration of (76):

<span id="page-5-1"></span>
$$T\Delta_i s = w - \Delta \Omega^{eq}, \tag{78}$$

with the important consequence that the statistical properties of entropy production  $\Delta_i s$  and work w are the same, apart from a shift by  $\Delta\Omega^{eq}$  and rescaling by T. Finally, the difference of equilibrium and nonequilibrium grand potential can be written as follows:

$$\omega - \omega^{eq} = k_B T i, \tag{79}$$

$$i = \ln \frac{P_m}{P_m^{eq}},\tag{80}$$

which is the stochastic analogue of (35).

#### V. PATH DESCRIPTION

The expression (74) for the entropy production is not physically nor mathematically transparent. A more revealing expression is obtained by considering the cumulative entropy production  $\Delta_i s$  along a trajectory. We represent a system trajectory by m, referring to the state of the system, m(t), as a function of time  $t = [t_i = 0, t_f = \tau]$ . The corresponding probability for such a trajectory will be denoted by P(m). We also need to define an "inverse experiment", corresponding to reversing the timedependence of the "driving", i.e., of the transition rates, while using as starting probability for the states in the inverse experiment, the final distribution of the states in the forward experiment. We will denote by superscript "tilde" the quantities related to the reverse experiment, for example  $\tilde{t} = \tau - t$ ,  $\tilde{t}_i = \tau - t_f = 0$ ,  $m(t) = \tilde{m}(\tilde{t})$ ,  $P_{m(t_f)}(t_f) = \tilde{P}_{\tilde{m}(\tilde{t}_i)}(\tilde{t}_i)$ , etc..  $\tilde{\mathbf{m}}$  refers to the time-inverse trajectory of  $\mathbf{m}$  and  $\tilde{\mathbf{P}}(\tilde{\mathbf{m}})$  to the probability for the timereversed path in the time-reversed experiment. We will now prove the following main result. The cumulated entropy production  $\Delta_i s = \Delta_i s(\mathbf{m})$  along a forward trajectory m is the logratio of the probabilities to observe this trajectory in forward and backward experiment, respectively:

<span id="page-5-0"></span>
$$\Delta_i s(\mathbf{m}) = k_B \ln \frac{\mathbf{P}(\mathbf{m})}{\tilde{\mathbf{P}}(\tilde{\mathbf{m}})}.$$
 (81)

Note that the probability for a trajectory is in fact a probability density defined in the function space of trajectories, but as only ratio's of such quantities appear (and the Jacobian for the transformation to the time-inverse variables is one), the above expression is well defined. The proof is surprisingly simple. One can identify three contributions to the probability for a trajectory. First, we have the starting probabilities for direct and reverse paths,  $P_{m(t_i)}(t_i)$  and  $\tilde{P}_{m(\tilde{t}_i)}(\tilde{t}_i) = P_{m(t_f)}(t_f)$  (the latter by construction),

respectively. The logratio of these quantities gives the stochastic entropy change of the forward trajectory  $\Delta s(\mathbf{m}) = k_B \ln P_{m(t_f)}(t_f) - k_B \ln P_{m(t_i)}(t_i)$ . Second, we have the probabilities to make jumps, say from m to m' in the forward process and hence from m' to m in the reverse experiment. The logratio of these probabilities is  $\ln \frac{W_{m',m}}{W_{m,m'}} = \frac{-q_{m',m}}{k_B T}$  (evaluated at the time of the jump), which is the heat  $-q_{m',m}$  leaving the system divided by the  $k_B$  times temperature. When summed over all transitions (times  $k_B$ ), it gives  $-\Delta_e s(\mathbf{m})$ . Finally the probabilities for not making jumps are at every instant of time the same in the forward and reverse experiments, so these contributions cancel out. We conclude that the logratio of the path probabilities is  $\Delta s(\mathbf{m}) - \Delta_e s(\mathbf{m}) = \Delta_i s(\mathbf{m})$ .

#### VI. FLUCTUATION AND WORK THEOREM

The cumulated entropy production  $\Delta_i s$  is a random variable: it has the value specified in (81) when the system has followed the specified trajectory  $\mathbf{m}$ , which happens with probability  $\mathbf{P}(\mathbf{m})$ . The resulting probability for  $\Delta_i s$  is given by the following path integral:

$$P(\Delta_i s) = \int_{\mathbf{m}} d\mathbf{m} \, \delta\left(\Delta_i s - k_B \ln \frac{\mathbf{P}(\mathbf{m})}{\tilde{\mathbf{P}}(\tilde{\mathbf{m}})}\right) \mathbf{P}(\mathbf{m}).(82)$$

Due to the very specific structure of  $\Delta_i s$ , namely the fact that it is a log-ratio of probabilities, one can perform the following trick:

$$P(\Delta_{i}s) = \int_{\mathbf{m}} d\mathbf{m} \, \delta \left( \Delta_{i}s - k_{B} \ln \frac{\mathbf{P}(\mathbf{m})}{\tilde{\mathbf{P}}(\tilde{\mathbf{m}})} \right) \mathbf{P}(\mathbf{m})$$

$$= e^{\frac{\Delta_{i}s}{k_{B}}} \quad \int_{\mathbf{m}} d\mathbf{m} \, \delta \left( \Delta_{i}s - k_{B} \ln \frac{\mathbf{P}(\mathbf{m})}{\tilde{\mathbf{P}}(\tilde{\mathbf{m}})} \right) \tilde{\mathbf{P}}(\tilde{\mathbf{m}})$$

$$= e^{\frac{\Delta_{i}s}{k_{B}}} \quad \int_{\tilde{\mathbf{m}}} d\tilde{\mathbf{m}} \, \delta \left( -\Delta_{i}s - k_{B} \ln \frac{\tilde{\mathbf{P}}(\tilde{\mathbf{m}})}{\mathbf{P}(\mathbf{m})} \right) \tilde{\mathbf{P}}(\tilde{\mathbf{m}})$$

$$= \exp \frac{\Delta_{i}s}{k_{B}} \quad \tilde{P}(-\Delta_{i}s), \tag{83}$$

where we have used the fact that the Jacobian for the transformation from  $\mathbf{m}$  to  $\tilde{\mathbf{m}}$  is equal to one. This result is usually written under the following form:

<span id="page-5-2"></span>
$$\frac{P(\Delta_i s)}{\tilde{P}(-\Delta_i s)} = \exp\frac{\Delta_i s}{k_B},\tag{84}$$

also known as the detailed fluctuation theorem [31]. In words: the probability for a stochastic entropy increase (in the forward dynamics) is exponentially more probable than that of a corresponding decrease (in the reverse dynamics). At this point it is important to clarify the meaning of:

$$\tilde{P}(-\Delta_{i}s) = \int_{\tilde{\mathbf{m}}} d\tilde{\mathbf{m}} \, \delta\left(-\Delta_{i}s - k_{B} \ln \frac{\tilde{\mathbf{P}}(\tilde{\mathbf{m}})}{\mathbf{P}(\mathbf{m})}\right) \tilde{\mathbf{P}}(\tilde{\mathbf{m}}).$$
(85)

 $\tilde{P}(\tilde{\mathbf{m}})$  is obviously the probability density to observe in the reverse dynamics a trajectory  $\tilde{\mathbf{m}}$  whose inverse trajectory  $\mathbf{m}$  has an entropy production  $\Delta_i s$ . It is quite natural to wonder what is the relation, if any, with the entropy production  $\Delta_i \tilde{s}(\tilde{\mathbf{m}})$  of the reverse trajectory  $\tilde{\mathbf{m}}$  in the reverse scenario. By applying (81) to the reverse process one finds that the corresponding entropy production reads:

<span id="page-6-0"></span>
$$\Delta_{i}\tilde{s}(\tilde{\mathbf{m}}) = k_{B} \ln \frac{\tilde{\mathbf{P}}(\tilde{\mathbf{m}})}{\tilde{\tilde{\mathbf{P}}}(\tilde{\tilde{\mathbf{m}}})}.$$
 (86)

It is obvious that  $\tilde{\tilde{\mathbf{m}}} = \mathbf{m}$ , and it is tempting to assume that  $\tilde{\mathbf{P}} = \mathbf{P}$ , implying  $\Delta_i \tilde{s}(\tilde{\mathbf{m}}) = -\Delta_i s(\mathbf{m})$ . Indeed the transition rates of the doubly tilded stochastic process (twice time-inversion of the driving) are again the original ones  $\tilde{\tilde{\mathbf{W}}} = \mathbf{W}$ , so that  $\mathbf{P}$  and  $\tilde{\tilde{\mathbf{P}}}$  obey the same master equation. But  $\tilde{\mathbf{P}} = \mathbf{P}$  also requires that their initial distributions coincide. This is in general not the case. Indeed, we recall that - for (86) to correspond to the entropy production in the reverse process - the initial probability distribution of  $\tilde{\mathbf{P}}$  has to be the final probability  $\tilde{\mathbf{P}}$ . In general the latter distribution will be different from the initial distribution of the forward process so that  $\mathbf{P} \neq \tilde{\mathbf{P}}$ . Hence, there is in general no simple relation between the entropy production of forward and backward processes, and the fluctuation theorem is a statement only about the forward entropy production. There are however several cases of interest where the initial conditions match. One prominent situation is for the system starting and ending in a stationary state. This is obviously the case for nonequilibrium steady states (same stationary state all the time), but also if both before and after the timedependent perturbation, the system has enough time to relax to the corresponding steady state. A particularly interesting special case of this type arises if we consider a system starting and ending in an equilibrium state. Indeed the stochastic entropy is then directly related to the work performed on the system, cf. (78), and the statistical properties of the entropy production carry over to the work, leading to the so-called Crooks relation [32–34]:

$$\frac{P(w)}{\tilde{P}(-w)} = \exp\frac{w - \Delta\Omega^{eq}}{k_B T}.$$
 (87)

A key remark at this stage is that the fluctuating work (67) naturally stops evolving when the time-dependent perturbation stops. The ending state can therefore be any arbitrary nonequilibrium state and the final value of the grand potential will correspond to the value of the time-dependent perturbation at that final nonequilibrium state. The Crooks relation thus only requires the initial condition to be in an equilibrium state.

We next turn to another relation that derives from (84), irrespective of whether or not  $\tilde{\tilde{\mathbf{P}}} = \mathbf{P}$ . Indeed we have:

$$\int d\Delta_i s \, e^{\frac{-\Delta_i s}{k_B}} P(\Delta_i s) = \int d\Delta_i s \, \tilde{P}(-\Delta_i s) = 1, \quad (88)$$

where we use the fact that  $\tilde{P}$  is a probability density, hence normalized to one. We thus obtain the so-called integral fluctuation theorem, which is valid irrespective of any conditions on initial or final states [30]:

$$\langle \exp \frac{-\Delta_i s}{k_B} \rangle = 1. \tag{89}$$

If the initial state corresponds to equilibrium (for the same reason as the Crooks relation the final state need not be at equilibrium), we obtain from (78) the famous Jarzynski relation [35, 36] (usually written in the absence of particle exchange, with the Helmholtz free energy F replacing the grand potential  $\Omega$ ):

$$\langle \exp \frac{-w}{k_B T} \rangle = \exp \frac{-\Delta \Omega^{eq}}{k_B T}.$$
 (90)

As a closing remark, we mention that the integral fluctuation relation and a fortiori the detailed fluctuation relation imply the positivity - on average - of the entropy production:

$$\langle \Delta_i s \rangle \ge 0. \tag{91}$$

This result can be reproduced in a more direct and revealing way from the result (81) for the stochastic entropy production. Its average is given by:

$$\langle \Delta_i s \rangle = k_B D(\mathbf{P}(\mathbf{m}) || \tilde{\mathbf{P}}(\tilde{\mathbf{m}})),$$
 (92)

where D is the relative entropy introduced earlier:

$$D(\mathbf{P}(\mathbf{m})||\tilde{\mathbf{P}}(\tilde{\mathbf{m}})) = \int_{\mathbf{m}} d\mathbf{m} \ \mathbf{P}(\mathbf{m}) \ln \frac{\mathbf{P}(\mathbf{m})}{\tilde{\mathbf{P}}(\tilde{\mathbf{m}})}. \quad (93)$$

This quantity is zero, if and only if  $\mathbf{P}(\mathbf{m}) = \tilde{\mathbf{P}}(\tilde{\mathbf{m}})$ ,  $\forall \mathbf{m}$ . This reveals again the stringent conditions associated to the absence of entropy production, namely the vanishing of any time-asymmetry: every single trajectory and its reverse have to be equally probable. This observation is in accordance with the founding principle of the second law, namely the absence of a perpetuum mobile of the second kind. Indeed, any time-asymmetry in a trajectory could in principle be used to extract work, hence the system cannot be at equilibrium under such a condition.

# VII. DISCUSSION

Stochastic thermodynamics offers a good marriage between statistical physics and thermodynamics. We described the system via its microscopic energy states, with Markovian dynamics induced by its contact with idealized work and reservoirs. One may wonder whether the obtained results are limited to this particular setting, or are in fact much more general and deep. As mentioned in the introduction, many of the results, and in particular the detailed and integral work and fluctuation theorems have been obtained in other settings lending credance to the believe that we are indeed dealing with a more

profound reformulation of thermodynamics. The further development and consolidation of this theory is in fact in full swing, including surprising findings such as integral and detailed fluctuation theorems for quantities other than the entropy production. We have not discussed here the microscopic origin of irreversibility: the Master equation is irreversible from the very start. Nevertheless, the picture presented by stochastic thermodynamics is fully consistent with a microscopic derivation that addresses this issue, see in particular [37].

## ACKNOWLEDGMENTS

This research is supported by the research network "Exploring the Physics of Small Devices" of the European Science Foundation. C. V.d.B. is supported by the "Fonds voor Wetenschappelijk Onderzoek Vlaanderen", and M. E. by the "National Research Fund of Luxembourg", project FNR/A11/02 and INTER/FWO/13/09.

- <span id="page-7-0"></span>[1] L. Onsager, Phys. Rev. 37, 405 (1931).
- [2] L. Onsager, Phys. Rev. 38, 2265 (1931).
- [3] I. Prigogine, Thermodynamics of Irreversible Processes (Wiley-Interscience, 1961).
- <span id="page-7-1"></span>[4] S. R. de Groot and P. Mazur, Non-equilibrium thermodynamics (Dover, 1984).
- <span id="page-7-2"></span>[5] D. J. Evans and G. Morris, Statistical Mechanics of Nonequilibrium Liquids, 2nd ed. (Cambridge University Press, 2008).
- [6] C. Bustamante, J. Liphardt, and F. Ritort, Physics Today 58, 43 (2005), issue 7.
- [7] M. Esposito, U. Harbola, and S. Mukamel, Rev. Mod. Phys. 81, 1665 (2009).
- [8] M. Campisi, P. Hänggi, and P. Talkner, Rev. Mod. Phys. 83, 771 (2011).
- [9] C. Jarzynski, Annual Review of Condensed Matter Physics 2, 329 (2011).
- [10] U. Seifert, Rep. Prog. Phys. **75**, 126001 (2012).
- [11] C. Van den Broeck, Il Nuovo Cimento (2012), DOI 10.3254/978-1-61499-278-3-155.
- [12] X.-J. Zhang, H. Qian, and M. Qian, Physics Reports 510, 1 (2012).
- <span id="page-7-3"></span>[13] H. Ge, M. Qian, and H. Qian, Physics Reports 510, 87 (2012).
- <span id="page-7-4"></span>[14] L. E. Reichl, A Modern Course in Statistical Physics (Wiley, 2009).
- <span id="page-7-5"></span>[15] T. M. Cover and J. A. Thomas, Elements of information theory (Wiley, 2006).
- <span id="page-7-6"></span>[16] M. Esposito, U. Harbola, and S. Mukamel, Phys. Rev. B. 75, 155316 (2007).
- [17] M. Esposito, K. Lindenberg, and C. Van den Broeck, EPL 85, 60010 (2009).

- [18] M. Esposito, R. Kawai, K. Lindenberg, and C. Van den Broeck, EPL 89, 20003 (2010).
- <span id="page-7-7"></span>[19] P. Strasberg, G. Schaller, T. Brandes, and M. Esposito, Phys. Rev. E 88, 062107 (2013).
- <span id="page-7-8"></span>[20] C. Van den Broeck, Phys. Rev. Lett. 95, 190602 (2005).
- [21] T. Schmiedl and U. Seifert, Phys. Rev. Lett. 98, 108301 (2007).
- [22] Z. C. Tu, J. Phys. A: Math. Theor. 41, 312003 (2008).
- [23] M. Esposito, K. Lindenberg, and C. Van den Broeck, Phys. Rev. Lett. 102, 130602 (2009).
- [24] B. Rutten, M. Esposito, and B. Cleuren, Phys. Rev. B 80, 235122 (2009).
- [25] M. Esposito, R. Kawai, K. Lindenberg, and C. Van den Broeck, Phys. Rev. E 81, 041106 (2010).
- [26] U. Seifert, Phys. Rev. Lett. **106**, 020601 (2011).
- [27] B. Cleuren, B. Rutten, and C. Van den Broeck, Phys. Rev. Lett. 108, 120603 (2012).
- [28] K. Brandner, K. Saito, and U. Seifert, Phys. Rev. Lett. 110, 070603 (2013).
- <span id="page-7-9"></span>[29] Z. C. Tu, arXiv:1312.5812 (2013).
- <span id="page-7-10"></span>[30] U. Seifert, Phys. Rev. Lett. 95, 040602 (2005).
- <span id="page-7-11"></span>[31] M. Esposito and C. Van den Broeck, Phys. Rev. Lett. **104**, 090601 (2010).
- <span id="page-7-12"></span>[32] G. E. Crooks, J. Stat. Phys. 90, 1481 (1998).
- [33] G. E. Crooks, Phys. Rev. E **60**, 2721 (1999).
- <span id="page-7-13"></span>[34] G. E. Crooks, Phys. Rev. E 61, 2361 (2000).
- <span id="page-7-14"></span>[35] C. Jarzynski, Phys. Rev. Lett. 78, 2690 (1997).
- <span id="page-7-15"></span>[36] C. Jarzynski, Phys. Rev. E 56, 5018 (1997).
- <span id="page-7-16"></span>[37] M. Esposito, K. Lindenberg, and C. Van den Broeck, New J. Phys. 12, 013013 (2010).