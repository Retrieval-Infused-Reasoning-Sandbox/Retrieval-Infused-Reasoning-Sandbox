![](_page_0_Picture_0.jpeg)

<span id="page-1-0"></span>![](_page_1_Picture_0.jpeg)

## Homogeneous nucleation: theory and experiment

D W Oxtoby

Published under licence by IOP Publishing Ltd

[Journal of Physics: Condensed Matter](file:///journal/0953-8984), [Volume 4](file:///volume/0953-8984/4), [Number 38](file:///issue/0953-8984/4/38)

**Citation** D W Oxtoby 1992 J. Phys.: Condens. Matter **4** 7627

**DOI** 10.1088/0953-8984/4/38/001

This article is corrected by 1998 [J. Phys.: Condens. Matter](file:///article/10.1088/0953-8984/10/4/019) **[10](file:///article/10.1088/0953-8984/10/4/019)** 897

[Buy this article in print](https://pod-iopscience.org?doi=10.1088/0953-8984/4/38/001&UTCDate=15102025_171021)