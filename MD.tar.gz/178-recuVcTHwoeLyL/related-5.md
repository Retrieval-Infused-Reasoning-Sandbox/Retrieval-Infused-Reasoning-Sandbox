![](_page_0_Picture_0.jpeg)

<span id="page-1-0"></span>![](_page_1_Picture_0.jpeg)

## **TOPICAL REVIEW**

## Nucleation: theory and applications to protein solutions and colloidal suspensions

Richard P Sear

Published 3 January 2007 • IOP Publishing Ltd

[Journal of Physics: Condensed Matter](file:///journal/0953-8984), [Volume 19,](file:///volume/0953-8984/19) [Number 3](file:///issue/0953-8984/19/3)

**Citation** Richard P Sear 2007 J. Phys.: Condens. Matter **19** 033101

**DOI** 10.1088/0953-8984/19/3/033101

- Received 2 November 2006 1.
- Published 3 January 2007 2.

[Buy this article in print](https://pod-iopscience.org?doi=10.1088/0953-8984/19/3/033101&UTCDate=15102025_171023)