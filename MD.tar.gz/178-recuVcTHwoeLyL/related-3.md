### On the applicability of the classical nucleation theory in an Ising system **⊘**

V. A. Shneidman; K. A. Jackson; K. M. Beatty

![](_page_0_Picture_4.jpeg)

J. Chem. Phys. 111, 6932-6941 (1999) https://doi.org/10.1063/1.479985

![](_page_0_Picture_6.jpeg)

![](_page_0_Picture_7.jpeg)

26 October 2025 14:11:29

![](_page_0_Picture_10.jpeg)

### On the applicability of the classical nucleation theory in an Ising system

V. A. Shneidman, K. A. Jackson, and K. M. Beatty
Department of Materials Science and Engineering, The University of Arizona, Tucson, Arizona 85721

(Received 7 June 1999; accepted 20 July 1999)

Large-scale dynamic Monte Carlo simulations of a lattice gas on a  $2000 \times 2000$  square lattice with a Glauber-type spin flip dynamics were performed. The results are discussed in the light of classical nucleation theory (CNT) which can be fully specified for the problem due to the availability of exact values for the interfacial energy of a large nucleus, known from the Onsager solution. Several alternative (field-theoretic or nonclassical) descriptions were also considered. Special attention was paid to the pre-exponential in the cluster distribution function and to the finite-size corrections to the interfacial energies which are required in order to comply with observations. If taken literally, the CNT produces large errors when predicting either the cluster distribution function or the nucleation rate. However, at intermediate temperatures (up to  $0.7\ T_c$ ) the correspondence can be substantially improved by considering the low-temperature properties of small clusters and adjusting the pre-exponential. At higher temperatures the CNT is in qualitative disagreement with the simulations. Several explanations for this, including coagulation between clusters, are proposed. © 1999 American Institute of Physics. [S0021-9606(99)51638-3]

#### I. INTRODUCTION

In 1926 Volmer and Weber, using the ideas of fluctuational thermodynamics developed earlier by Einstein, proposed the celebrated expression for the nucleation rate

$$I \propto \exp(-W_*/T) \tag{1}$$

with  $W_*$  being the minimal work required to form a critical nucleus (temperature T is measured in units of Boltzmann constant). This work is related to the interfacial energy of the critical nucleus,  $W_*^{\sigma}$ , by the Gibbs relation  $W_* = W_*^{\sigma}/d$  with d being the dimensionality of a system. These relations with bulk (though possibly anisotropic) values of the interfacial energy determine the thermodynamic part of what became known as the classical nucleation theory (CNT), which turned out to be remarkably successful in explaining a plethora of experimental data in such diverse areas as vapor condensation, boiling and crystallization, condensation of an electron-hole liquid, etc.

There remains, however, a fundamental question of the pre-factor in Eq. (1). The early works of Farkas, Becker and Döring, Zeldovich, and Frenkel<sup>6</sup> provided an important insight into the kinetic nature of this pre-factor, expressing the nucleation rate as

$$I = \frac{\beta(n_*)}{\Delta_n \sqrt{\pi}} f(n_*). \tag{2}$$

Here  $\beta(n)$  is the attachment frequency of new monomers for a cluster of size n ( $n_*$  being the critical size) and  $\Delta_n$  is the fluctuational region near the top of the nucleation barrier (see Sec. III). The quasiequilibrium distribution, f(n), is related to the work W(n)

$$f(n) = A \exp(-W(n)/T) \tag{3}$$

thus establishing the connection of the leading exponential term in Eq. (2) with the Volmer's expression.

Strictly speaking, the pre-exponential factor in Eq. (3) cannot be determined from purely macroscopic considerations.<sup>7</sup> This problem is not specific for metastability, but also appears when describing fluctuations in thermodynamically stable systems.<sup>8</sup> The tradition of CNT is to estimate the pre-factor A in this equation as the number of the smallest clusters ("monomers"). This implies, in particular, that the macroscopic expression for the work W(n) should be valid at the molecular level—an assumption rejected by Farkas, and later re-introduced into the theory by Becker and Döring.<sup>6</sup> Later, several corrections to the prefactor were suggested, most notably in the context of vapor condensation—see, e.g., Ref. 9 and references therein.

It is also unclear whether the prefactor can be treated as size independent. The macroscopic treatment can only state that this prefactor should be a "very smooth" function of n compared to the exponential, which does not rule out, for example, a power law. Nonclassical (finite-size) corrections to the work  $W(n_*)^{10}$  result in effects which are equivalent to a size-dependence A.

Experimental determination of the pre-factor is usually hindered by the fact that CNT is remarkably forgiving to inaccuracies in the value of A. Indeed, due to large values of the barrier,  $W_* \!\! > \!\! T$ , usually encountered in the nucleation problems, the exponential term is dominant, completely overshadowing the pre-factor dilemma. In this context it is useful to remember that multiple confirmations of CNT usually rely on the "old" classical expression, Eq. (1), rather than its specification given by Eqs. (2,3), or equivalent expressions with a fixed value of A.

Nevertheless, the problem of the pre-factor is far from being a purely academic one. A flexible fitting parameter in the nucleation rate expression often prevents one from ruling out competitive theories. In many experimental studies the surface tension is not known with sufficient accuracy, and knowledge of the pre-factor combined with accurate measurements of the nucleation rates could provide invaluable information on the microscopic properties of the nucleating phase.

One can hope to gain additional insight into the nucleation kinetics and, specifically to understand the role of the pre-factor from the studies of nucleation in Ising systems. Here the equilibrium thermodynamics and the surface tension are known exactly in two dimensions from the Onsager solution<sup>11–13</sup> and accurate numerical data and cluster expansions are available for the three-dimensional case (see, e.g., Refs. 14–16 and references therein). Kinetics of nucleation in a metastable state can be derived from large scale Monte Carlo simulations.<sup>17–27</sup> Some rigorous mathematical results<sup>28–30</sup> also provide a useful background for understanding the validity of more intuitive descriptions of nucleation and growth.

Already from early computer studies  $^{18,19,31,32}$  it became clear that a constant pre-factor does not correspond to cluster distributions near the critical temperature  $T_c$ . Much better agreement (at least in the two-dimensional case) is achieved with a power-law correction,  $A(n) \propto n^{-\nu}$  with a nonzero index  $\nu \approx 2.1$ , as suggested by Fisher.  $^{33}$  At lower temperature, however, this value of  $\nu$  is too large.  $^{19,31,34}$ 

Numerical differentiation of the nucleation rate as a function of magnetic field at  $T\!=\!0.8T_c$  on a square lattice (combined with available exact data for macroscopic  $W_*^\sigma)^{25,35}$  seems to favor the field-theoretic nucleation descriptions,  $^{36}$  which effectively correspond to the value of  $\nu$  close to 1.25 (see Sec. III). Values of  $\nu$  close to 0.5 are indicated by cluster distributions on a hexagonal (triangular) lattice  $^{26}$  for  $T\!\approx\!0.82T_c$ . On the other hand, there are multiple claims (see, e.g., Ref. 21 and references therein) that the CNT works well for various dimensions; while nonclassical nucleation effects are associated with long-range interactions.  $^{23}$ 

The current status of CNT for the Ising system and of competing theories thus remains unclear, despite the fact that comparative studies of various approaches were initiated as early as 1976. The problem here is similar to that in real-life experiments: it is hard to distinguish the slowly varying pre-factor on the background of a rapidly changing exponential, and thus to rule out one or the other theoretical possibility. Nevertheless, the available exact data for the surface tension combined with the results of simulations on a large scale, can shed more light on the size dependence of the pre-exponential, while the possibility of low-temperature cluster expansions provides a unique opportunity to improve the estimates of the *absolute* values of *A* compared to those of CNT. Investigation of these problems will represent the main goal of the present work.

A square lattice will be considered for which the interfacial energy was studied in the most detail, including the effects of anisotropy. The Attention will be devoted primarily to the thermodynamic aspect of the nucleation description, namely to the equilibrium cluster distribution function. The kinetics of CNT also will be briefly considered, but at present those seem to be more reliable, 22,26 at least for small undercoolings and not too high temperatures when coagulation 19,26,39 is still negligible. For example, if the equi-

librium distribution and growth rates are "measured" (not calculated!) one can predict the steady-state nucleation rate, *I*, as well as the more delicate transient behavior. <sup>26</sup> The Kolmogorov–Avrami picture of post nucleation growth and interaction of clusters also is remarkably accurate <sup>26,27</sup> for a two-dimensional Ising system. At the same time, a first principles description of the nucleation kinetics in an Ising system which does not rely on any measured parameters, still remains a challenging task.

The paper is organized in the following manner. In Sec. II the spin flip dynamics used in the computational model are briefly described, and relevant thermodynamics of nucleus formation on a two-dimensional lattice are reviewed in some detail and specified for the problem considered. In Sec. III the classical and field-theoretic expressions for the nucleation rate are presented. In Sec. IV, distributions of small clusters at low temperature are considered. Those are used to control the simulation scheme, and also to refine the prefactor of CNT. In Sec. V the adjusted cluster distributions of CNT are compared with the simulation results at several temperatures. Results for the pre-exponential in the observed distributions and for non-bulk interfacial energies of small clusters are also presented. In Sec. VI illustrative results for the nucleation rate (obtained, alternatively from the number of nuclei and from the transformed area) are compared with the proposed estimations, and Sec. VII contains the discus-

#### II. BACKGROUND

#### A. Spin flip dynamics

To implement the spin flip dynamics we used the computational model developed earlier by Jackson, Gilmer, and Tëmkin  $(JGT)^{40}$  which has been extensively studied in the crystallization context. The rates of down-up  $(\mp)$  and updown  $(\pm)$  spin flips are given, respectively, by

$$\nu^{\mp} = \exp\{-\Delta S\}, \quad \nu^{\pm} = \exp\{H/T\}.$$
 (4)

Here  $\Delta S$  is an input parameter, while H is determined by interactions with the nearest up spins with the bond energy  $\phi$ . This is a nonconserved dynamics of the Glauber type.

Equilibrium is achieved at  $\Delta S = 2 \phi / T$ . Otherwise,

$$\delta S = 2 \phi / T - \Delta S \tag{5}$$

is the "reduced undercooling," which corresponds to a doubled reduced magnetic field, 2h/T, in the conventional descriptions. Initially, all spins are oriented down, so that for  $\delta S > 0$  one has a metastable phase.

A more detailed description of this realization of the JGT model is contained in Refs. 26,41. Clusters were defined as connected groups of n spins; an alternative, Klein–Coniglio<sup>42</sup> definition of a cluster is expected to give virtually identical results for the lower temperatures considered. Cluster distributions over the numbers n were recorded during the simulation runs. Comparison of these distributions with low-temperature cluster expansions (see Sec. IV) provides an accurate test of the computational scheme for very rare events which are typical for the nucleation problem.

![](_page_3_Figure_4.jpeg)

FIG. 1. Reduced surface tension,  $4\sigma/\phi\chi(T)$ , in the directions parallel and diagonal to the lattice vector, as given by Eqs. (6) and (7), solid and dashed lines, respectively. Numerically exact values (squares) for reduced  $\sigma_{\rm eff}$  are based on Eq. (9). Dotted line—approximation given by Eq. (12). Data for finite cluster numbers, n, are obtained from cluster concentrations, see Sec. IV. The critical temperature is  $T_c{\simeq}1.70$  for the chosen bond energy,  $\phi=3$ .

#### B. Thermodynamics of a nucleus on a square lattice

Thermodynamically, the current realization of the JGT model is equivalent to a lattice gas with nearest-neighbor interaction between the up spins. It is well known<sup>43</sup> that the lattice gas model can be mapped to the original Ising model solved by Onsager (in that case the interaction energies between antiparallel and parallel neighboring spins would correspond to  $\pm \phi/4$ , respectively). The critical temperature,  $T_c$ , is 0.567 295  $\phi$ .

In the nucleation context the most interesting feature of the Ising model is the possibility of evaluating the surface tension,  $\sigma$ . In general,  $\sigma$  is anisotropic, and its values in the direction of the lattice vector, and in the direction of the unit cell diagonal are given, respectively, by<sup>11,44</sup>

$$\frac{1}{T}\sigma_{\parallel} = 2K + \ln(\tanh K),\tag{6}$$

$$\frac{1}{T}\sigma_{\text{diag}} = \sqrt{2}\ln(\sinh 2K) \tag{7}$$

with  $K = \phi/4T$ . These values are shown by a solid and dashed lines in Fig. 1 where the temperature is specified for the chosen value of  $\phi = 3$ . Generalizations of Eqs. (6) and (7) for arbitrary directions also are available.<sup>37,38</sup>

The equilibrium shapes of a nucleus are determined by the Wulff droplet construction and range from a perfect square at T=0 to a circle at  $T \ge 0.5 T_c$ , <sup>37</sup> where the anisotropy effects practically disappear, as can be seen from Fig. 1.

We will define an "effective" surface tension,  $\sigma_{\rm eff}(T)$ , which gives accurate values of the total interfacial free energy of a nucleus

$$W^{\sigma}(n) = 2\sqrt{\pi n}\,\sigma_{\text{eff}}(T) \tag{8}$$

whether this nucleus is actually circular or not.

Exact values of  $W^{\sigma}(T)$  can be obtained from Eq. (11) of Ref. 38 by Zia and Avron. After simple transformations one obtains

$$\left(\frac{1}{T}\sigma_{\text{eff}}(T)\right)^{2} = \frac{4\phi}{\pi\chi(T)} \int_{1/T_{c}}^{1/T} [1 - q(T)]K'[m(T)]d(1/T). \tag{9}$$

Here K' is the elliptic integral,<sup>45</sup> while q(T) and m(T) are given by

$$q(T) = \frac{3 - \exp(-\phi/T)}{\sinh(\phi/T)}, \quad m(T) = 8 \frac{\cosh(\phi/T) - 1}{(\cosh(\phi/T) + 1)^2}.$$
(10)

The equilibrium concentration of up spins,  $\chi(T)$  which is included in the definition of  $\sigma_{\rm eff}$ , is given by the Onsager prediction<sup>46,47</sup>

$$\chi(T) = (1 - \sinh^{-4}(2K))^{1/8} \tag{11}$$

(due to the small power, 1/8, the numerical values of  $\chi(T)$  are very close to unity, except for the immediate vicinity of  $T_c$ ).

Values of  $\sigma_{\rm eff}(T)$  which follow from Eq. (9) are shown by square symbols in Fig. 1. When analyzing nucleation data we will often use a simple expression

$$\sigma_{\text{eff}} \simeq \frac{1}{2\sqrt{\chi(T)}} (\sigma_{\parallel} + \sigma_{\text{diag}}), \quad T \gtrsim 0.25T_c$$
 (12)

which is shown by dotted lines in Fig. 1 and which accurately approximates Eq. (9) in the simulation region, and far beyond.

Alternatively, in the low-temperature region one has (see Appendix B)

$$\sigma_{\text{eff}} \approx \sigma_0 \left[ 1 - 5.6 (T/\phi)^2 \right] \tag{13}$$

with  $\sigma_0 = \phi / \sqrt{\pi}$  being the effective surface tension at T = 0

The work required to form a nucleus is given by the difference between the interface and the bulk terms:

$$W(n) = W^{\sigma}(n) - nT \delta S. \tag{14}$$

With the effective interface tension introduced above, one has

$$W_* = \pi \sigma_{\text{eff}}^2 / T \delta S, \quad n_* = \pi (\sigma_{\text{eff}} / T \delta S)^2.$$
 (15)

These are standard expressions of CNT for a circular nucleus; but with the chosen  $\sigma_{\rm eff}(T)$  they are accurate for a noncircular nucleus as well.

Although the Onsager solution used to evaluate the interfacial tension was obtained for the equilibrium case,  $\delta S = 0$ , there seem to exist rigorous indications in mathematical literature<sup>30</sup> that the same value determines the value of  $W_*$ . There are additional indications that equilibrium interfacial energy can be used when evaluating W(n) at  $n < n_*$ —see Sec. IV. At the same time, there remain some subtle points with respect to precise definition of the interfacial tension which should be considered in the nucleation context. We postpone their discussion until Appendix B, and *define* the CNT as using the interfacial tension described above.

## III. CLASSICAL AND ALTERNATIVE EXPRESSIONS FOR THE NUCLEATION RATE

Once the dominant factor  $\exp(-W_*/T)$  is known, it makes sense to focus on the more delicate pre-exponential terms in the expression for the nucleation rate.

The thermodynamic parameter  $\Delta_n$  in Eq. (2) is given by

$$\Delta_n = \left\{ -\frac{1}{2T} \frac{\partial^2 W}{\partial n^2} \bigg|_{n=n_{\star}} \right\}^{-1/2} = \frac{2\sqrt{\pi}\sigma_{\text{eff}}}{T(\delta S)^{3/2}}.$$
 (16)

To obtain the kinetic factor  $\beta(n_*)$ , we note that the attachment probability for a circular n cluster in the JGT model is given by

$$\beta(n) \approx \beta_0 2 \sqrt{\pi n}, \quad \beta_0 = \exp(\delta S - 2\phi/T)$$
 (17)

with  $\beta_0$  corresponding to  $\nu^{\mp}$  in Eq. (4).

With the specified dependencies, the nucleation rate, Eqs. (2,3) is given by

$$I^{\text{CNT}} = \beta_0 (\delta S)^{1/2} f(n_*) = A \beta_0 (\delta S)^{1/2} \exp\left\{-\frac{\pi \sigma_{\text{eff}}^2}{T \delta S}\right\}$$
(18)

with A being of the order of the number of down spins,  $f_0$ , in the framework of CNT.

In the field-theoretic (FT) description one relates the nucleation rate,  $I^{FT}$ , to the imaginary part of the free energy of the system<sup>36</sup>

$$I^{\text{FT}} = \frac{k}{\pi T} \text{Im } \mathcal{F}. \tag{19}$$

The increment of the unstable mode  $\kappa$  of Ref. 36 corresponds to  $2\beta(n_*)/\Delta_n^2$ . The exponential part of Im  $\mathcal{F}$  is identical to that of CNT, and it is widely believed (see Ref. 48, and references therein) that for a two-dimensional Ising model the prefactor of Im  $\mathcal{F}$  is proportional to the first power of the undercooling:

$$\operatorname{Im} \mathcal{F} \propto \delta S \exp(-W_{*}/T). \tag{20}$$

Thus, one has a different undercooling dependence for the nucleation rate:

$$I^{\text{FT}} \propto I^{\text{CNT}} (\delta S)^{5/2}. \tag{21}$$

In case one still relies on the extremely robust Eq. (2), this dependence can be reproduced from Eq. (3) with a size-dependent pre-factor in the cluster distribution

$$A(n) \propto n^{-\nu}, \quad \nu = \nu^{\text{FT}} = 5/4.$$
 (22)

In contrast to the FT description, nonclassical approaches to nucleation kinetics  $^{10}$  usually employ the classical-type pre-factor for the nucleation rate, but consider finite-size corrections to the work  $W_{*}$ . It is expected that at higher temperatures such corrections become appreciable if radius of a critical cluster is comparable to the correlation length which for the Ising model is given by  $\zeta \sim T/\sigma$ . Some attempts to estimate the finite-size corrections to  $W^{\sigma}(n)$  are mentioned in Ref. 49 which also contains earlier references. It is possible to estimate the non-classical values of interfacial energies from the observed distributions of small clusters, as will be discussed in Sec. V. At low temperatures nonclassical effects can persist up to exponentially

![](_page_4_Picture_23.jpeg)

FIG. 2. Cluster configurations and their statistical weights up to n=4. Such configurations are used to calculate the low-temperature distributions of small clusters and to test the consistency of the computational scheme—see Fig. 3.

large values of n due to the closeness of a roughening transition on a strictly infinite interface<sup>15</sup> at T=0. This will be briefly discussed in Sec. VII and in Appendix B.

# IV. DISTRIBUTIONS OF SMALL CLUSTERS, AND ADJUSTED CNT

The quasiequilibrium distribution of clusters in CNT takes an especially simple form at zero undercooling:

$$f^{\text{eq}}(n) = A \exp\{-2\sqrt{\pi n}\sigma_{\text{eff}}/T\}. \tag{23}$$

Due to the condition  $n_* = \infty$ , this distribution has no restrictions as a function of cluster size, corresponding, in contrast to Eq. (3), to a true rather than to a constrained equilibrium. The study of this distribution is also convenient from the point of view of simulations<sup>26</sup> since it has an infinite lifetime, and the accuracy of its determination is limited exclusively by computational power.

Alternatively, at low temperatures one can calculate the equilibrium distributions of small clusters from their Boltzmann weights. Neglecting the depletion of down spins, a given microscopic configuration of n up spins with energy  $-\phi\epsilon_n$  and statistical weight  $w_n$  will be encountered with frequency  $w_n \exp(-\phi\epsilon_n)$ . Typical configuration for  $n \le 4$  are shown in Fig. 2. The corresponding distributions are given by

$$f_1^{\text{eq}} = f_0 e^{-2\phi/T}, \quad f_2^{\text{eq}} = 2 f_0 e^{-3\phi/T}, \quad f_3^{\text{eq}} = 6 f_0 e^{-4\phi/T},$$
 (24)

$$f_A^{\text{eq}} = f_0 e^{-4\phi/T} (1 + 18e^{-\phi/T}) \tag{25}$$

which are shown in Fig. 3 together with the simulation results (the identification provides a very accurate test of the computational scheme—see the next section). A more complete list of configurations, up to n = 5 (without distinguishing shapes of clusters within the same topological class), can be found in Ref. 14 by Domb.

Note that for  $n \le 3$  the clusters are "microcanonical," each allowing configurations with a single energy,  $\epsilon_n = n + 1$ . Thus, the three smallest clusters do not mimic—in any sense—the macroscopic droplets, and the CNT estimation of

![](_page_5_Figure_4.jpeg)

FIG. 3. Low-temperature expansions for small cluster numbers, Eqs. (24), (25), and (29) (dashed lines) and simulation data (symbols) for a 2000  $\times$  2000 lattice for different values of (T,  $\delta S$ ). Diamonds correspond to equilibrium ( $\delta S$ =0) and squares to the undercooled case.

 $A \simeq f_0$  is not expected to be accurate. The n=4 clusters, on the other hand, allow a competition between the low energy—low entropy and, alternatively, high-energy—high entropy states, and can be treated as the first acceptable caricature of a droplet. In the absence of estimations for larger clusters (which for the next square, n=9, would probably require computer assistance due to a large number of configurations), one could relate Eqs. (23) and (25) in order to estimate A. This gives

$$A_4^{\rm ACT} \approx f_0 \exp\{4\sqrt{\pi}(\sigma_{\rm eff}(T) - \sigma_{\rm eff}(0))/T\}(1 + 18e^{-\phi/T}) \tag{26}$$

with the superscript standing for "adjusted classical theory" and the index 4 indicating the cluster size used for matching. Generalization for an arbitrary matching index, m, is straightforward once an expression for  $f_m^{\rm eq}$  (or simulation data) are available:

$$A_m^{\text{ACT}} = f_m^{\text{eq}} \exp\{2\sqrt{\pi m} \,\sigma_{\text{eff}}(T)/T\}. \tag{27}$$

The corresponding equilibrium distribution function at larger sizes is given by

$$f^{\text{ACT}}(n) = A_m^{\text{ACT}} \exp\left\{-\frac{2\sqrt{\pi n}\sigma_{\text{eff}}(T)}{T}\right\}, \quad n \ge m.$$
 (28)

For m=0 this expression corresponds to the prediction of CNT; selection of m=1 is similar to "self-consistent corrections" to CNT in the vapor condensation context.<sup>9,50</sup> Larger values of m are required, however, in order to improve correspondence with the observed distributions.

In the strict limit  $T \rightarrow 0$  the coefficient  $A_m^{\text{CNT}}$  defined in Eq. (27) approaches the classical value of  $f_0$  for any m which is a perfect square. The absence of size dependent, "nonclassical" corrections to  $W^{\sigma}(n)$  even for the smallest value of n=1 is remarkable, and reflects the fact that a smaller and a larger square (compare, e.g., the ones with n=1 and n=4 in Fig. 2) have a strictly proportional number of broken bonds, i.e., proportional values of the interfacial energy. The CNT,

however, will dramatically overestimate the number of small clusters which are not perfect squares, and for T>0 it will overestimate the number of squares as well.

When applied to the nonequilibrium case,  $\delta S > 0$ , both the CNT and the exact cluster expansions predict the increase of distributions to be

$$f_n(\delta S) = f_n^{\text{eq}} \exp(n \delta S), \quad n \leq n_* - \Delta_n$$
 (29)

as long as n remains well below the critical size, and as long as nucleation which eventually depletes smaller clusters is negligible. In other words, the interfacial free energies associated with the subcritical clusters are not changed with the undercooling. This conclusion seems to complement rigorous results on the possibility of using equilibrium interfacial tension for the evaluation of the critical cluster.<sup>30</sup>

For the same reason, the adjusted pre-factor  $A_m^{\rm ACT}$  in Eqs. (26) and (27) will not depend on undercooling, and can be used in Eq. (18) for the nucleation rate.

#### V. COMPARISON WITH SIMULATION DATA

Simulations in order to evaluate  $f_n^{\text{eq}}$  were performed on a  $2000 \times 2000$  lattice both at equilibrium ( $\delta S = 0$ ) and for small  $\delta S$  with minor nucleation effects, in which case Eq. (29) was employed. Typically, cluster distributions were sampled each 100 Monte Carlo steps, with a 1000 samplings for each simulation run, and the average numbers of clusters of each size and their dispersions were calculated, provided the system remained stable or at least negligibly depleted by growing particles. (The latter sometimes resulted in smaller number of available samplings, about 500 for  $\delta S > 0$ .) Nucleation was studied separately by increasing the undercooling—see Sec. VI.

As a test of consistency of the computational scheme, observed distributions of small clusters with  $n \le 4$  were compared with Eqs. (24) and (25) which are expected to be exact at low temperatures (Fig. 3). Close correspondence was observed even for rather rare events with  $f_n/f_0 \ge 10^{-6}$ . For smaller  $f_n$  (less than one cluster per the entire lattice) simulations produced somewhat higher results, and such rare data were treated as unreliable. The minor deviation at the higher temperature in Fig. 3, on the other hand, seems to be quite physical, reflecting cluster–cluster interactions for their increased concentrations, which reduces the numbers of the smallest clusters compared to Eqs. (24) and (25).

Results of simulations for distributions of large clusters are shown in Fig. 4 for three different temperatures. The dashed line shows the adjusted classical theory, Eqs. (26) and (28). The correspondence is reasonable for the two lower temperatures, even though matching at m=9 instead of m=4 could further improve the correspondence. At the higher temperature, however, the CNT gives a wrong size dependence of the distribution, and a mere adjustment of a constant pre-factor does not cure the problem.

To isolate the pre-factor, a combination

$$A(n) = f_n^{\text{eq}} \exp\{2\sigma_{\text{eff}}\sqrt{\pi n}/T\}$$
 (30)

was computed for all sizes where simulation data are expected to be reliable. If the CNT were correct, all points

![](_page_6_Figure_4.jpeg)

FIG. 4. Equilibrium distributions of large clusters at different temperatures and the classical nucleation theory adjusted at m = 4, Eqs. (26) and (28). Error bars characterize relative fluctuations in the observed numbers of clusters.

would fall on a horizontal straight line,  $f_0 = 4 \times 10^6$ . Such a horizontal line is also anticipated for perfect squares at T = 0 (see Fig. 5). In reality, however, while a region of a horizontal line is observed for the two lower temperatures, its value is much lower than the CNT prediction, in accord with the above discussion. Adjusting the pre-factor at m = 4 using Eq. (26) would improve the correspondence by more than an order of magnitude for T = 1 and T = 1.2; a still better agreement is achieved with matching at m = 9, although at present this can be done only numerically.

At the two higher temperatures in Fig. 5 the pre-factor A(n) is obviously nonconstant. At  $T = T_c \approx 1.70...$  it decays as  $n^{-\nu}$  with  $\nu \approx 2$ . This is in agreement with early observations,<sup>31</sup> and is close to the Fisher prediction<sup>33</sup> of  $\nu = 31/15$ . Alternatively, at T = 1.43, using the field-theoretic

![](_page_6_Figure_8.jpeg)

FIG. 5. The pre-exponential factor in the observed cluster distribution (dashed lines) based on simulation data and Eq. (30). Classical values of the pre-factor (diamonds) at T=0 are expected for n being perfect squares (see the text). The square symbols are the calculated values of the pre-factor at T=1 and  $T=T_c$  for  $n \le 4$ . (At  $T=T_c$  the distribution changes with time and is presented for t=1000 Monte Carlo steps, with the pre-factor matched at n=1, to account for cluster depletion.) The dotted line is the pre-exponential at  $T=T_c$  recalculated from data at  $\delta S=-0.1$ ; its deviation from the lower curve ( $\delta S=0$ ) indicates coagulation effects—see Sec. VII.

power index  $A(n) \propto n^{-1.25}$  would substantially improve the correspondence. With such a pre-factor in the cluster distribution, the nucleation rate is also anticipated to follow the prescribed FT dependence, as observed in Refs. 25,35. Nevertheless, it remains unclear whether such value of  $\nu$  has any fundamental meaning at least in a finite range of temperatures, or whether it corresponds just to a transition from classical values of  $\nu \approx 0$  at lower temperatures to near critical values in the high-temperature region.

As seen from Fig. 5, the calculated pre-factor at  $n \le 4$  remains reasonable up to the critical temperature (with the correction for depletion). The practical use of such calculations when describing nucleation is restricted, however, to lower temperatures where smaller values of n (smaller critical sizes) are of interest.

Since at any temperature, except for  $T = T_c$ , the prefactor does not follow a power law at all sizes, it could be useful to consider instead more general, nonclassical corrections to the interfacial energy  $W^{\sigma}(n)$ . The latter can be obtained from measured cluster numbers as

$$W(n) = -T \ln(f_n^{\text{eq}}/f_0). \tag{31}$$

Alternatively, for  $n \le 4$ , Eqs. (24) and (25) can be used to evaluate  $f_n^{\text{eq}}$  and thus  $W^{\sigma}(n)$ .

The effective interfacial tension can be obtained from Eq. (8). Results are shown in Fig. 1 for n up to  $6.^2$  The simulation data were used only for the two colder temperatures since at T=1.43 the possibility of ignoring the cluster interactions is less clear. The cluster numbers corresponding to a radius of the order of the correlation length are about n=3 (T=1) and n=7(T=1.2), respectively. Note that small clusters are effectively "colder," with the surface tension closer to that at T=0. The shapes of such clusters on average remain closer to squares, even if the macroscopic Wulff construction dictates otherwise. While it is still impossible to conclude from Fig. 1 at which n the bulk values of  $\sigma$  are recovered (see also the Appendix B), the results seem to point in the proper direction.

If the deviation from the classical distribution at large n indeed can be accounted by a constant pre-factor, corrections to bulk values of  $\sigma$  can be described as

$$\sigma_{\text{eff}}(n,T) - \sigma_{\text{eff}}(\infty,T) \propto 1/\sqrt{n}.$$
 (32)

This is in qualitative agreement with the Gibbs-Tolman corrections, even if the latter often are of a different sign. <sup>51,52</sup>

An interesting remaining thermodynamic question is the degree of universality of the corrections to CNT for a different lattice. One expects that at least the effects which extend beyond the correlation length should be similar. In Ref. 26 we studied cluster distribution over radii,  $f(R) \approx f(n) 2 \sqrt{\pi n}$ , at  $T \approx 0.82 T_c$  for a hexagonal (triangular) lattice. In the absence of an explicit expression for the interfacial energy it is hard to extract unambiguously the value of the pre-exponential from simulation data. Nevertheless, it is likely that the square-lattice expression for the interfacial energy can be employed for the triangular lattice as well (possibly, with a different geometric factor), if the Onsager parameter  $k(T) = 1/\sinh^2(2K)$  in the expression for  $\sigma_{\rm diag}$  is replaced by an appropriate "triangular" value<sup>53</sup> (see, e.g.,

![](_page_7_Figure_4.jpeg)

FIG. 6. Number of nuclei which exceed a given radius R at T=1 and  $\delta S = 0.45$ . The approximately constant slope of the initial portion of the lines indicates steady-state nucleation, and determines the nucleation rate, I. Reduction of the cluster numbers at later times is due to coagulation.

Ref. 13, Chap. (6). With such approach, and using data of Ref. 26 together with simulations at higher temperatures, we observed a qualitatively similar behavior of the pre-factor. At lower temperatures, however, we were unable to observe a positive increment of the pre-factor in  $f(R) \propto R \times \exp(-W(R)/T)$  which is characteristic of CNT.

## VI. ILLUSTRATIVE CALCULATIONS OF THE NUCLEATION RATE

For a given size of simulated system, two basic types of nucleation can be observed, <sup>25</sup> namely the single (also, random) or, alternatively, multiparticle (also, deterministic) nucleation. In view of the discussion in Sec. V, single nucleation events are not considered reliable in our study, while the multidroplet measurements are expected to be accurate. (Consideration of single nucleation events was still useful when evaluating the growth rates—see below.)

In the multidroplet regime the nucleation rate can be determined in two alternative ways. The direct method is based on counting the number of nucleated clusters,  $\rho(t)$ , somewhat similar to what is done in real experiments on crystal nucleation in glasses. A faster way to find the nucleation rate (with a few additional assumptions) is to use the Kolmogorov–Avrami expression for the transformed area. Avrami

An example of the cluster counting approach is shown in Fig. 6 for  $T=1.0\approx 0.59T_c$  and  $\delta S=0.45$ . In a sense, this low-temperature situation is simpler than the one considered earlier for  $T\approx 0.82T_c$  (Ref. 26) since there is now a longer time interval before coagulation alters the cluster distributions. In particular, the curvature of the  $\rho(t)$  curves due to time-dependent nucleation effects (which is important at higher  $T^{26}$ ) could be ignored in the present case. Evaluating the slope, one obtains  $I\approx 0.01$ . The independence of this slope of the cluster counting size,  $R=\sqrt{n/\pi}$ , indicates steady-state nucleation and negligible coagulation effects.

To apply the Kolmogorov-Avrami expression for the concentration of up spins

![](_page_7_Figure_12.jpeg)

FIG. 7. Application of the Kolmogorov-Avrami (KA) expression to determine the nucleation rate in Eq. (33). Parameters are the same as in Fig. 6, and results agree within 20% percent.

$$X(t) = 1 - \exp\left\{-\frac{\pi}{3f_0}Iv_{\infty}^2t^3\right\}$$
 (33)

one needs to know the growth velocity,  $v_{\infty}$ . For small undercoolings the latter can be estimated as

$$v_{\infty} = -\frac{1}{2T\sqrt{\pi}} \lim_{n \to \infty} \frac{\beta(n)}{\sqrt{n}} \frac{\partial W}{\partial n} \lesssim \delta S e^{-2\phi/T}.$$
 (34)

Note that we did not include  $\delta S$  in the exponential to emphasize the linear approximation. (Nonlinear expressions for  $v_{\infty}$  for a somewhat different spin flip dynamics are presented in the Appendix of Ref. 27.)

The above Eq. (34) is a slight overestimation since not all surface sites of a nucleus effectively contribute to growth. For example, adding an up spin to a smooth stretch of a droplet perimeter will almost certainly result in a reverse flip of that spin. In the subcritical region such effects are accounted for by using the correct (measured) values of the quasiequilibrium distribution which determine loss via the detailed balance condition, but for growth a more accurate description for the structure of the interface could be required at low temperatures.<sup>55</sup> On the other hand, at intermediate temperatures no serious errors are expected in Eq. (34). For example, at T=1 it overestimates the measured growth rates  $v_{\infty} \approx 0.0016 \delta S$  by less than 60%, as long as  $\delta S$  remains small. (The growth rate is obtained, e.g., from following the largest cluster in a single nucleation event.) Extrapolating the empirical dependence to  $\delta S = 0.45$ , and using the I in Eq. (33) as a matching parameter in order to reproduce the observed transformed area—see Fig. 7—one obtains a value of  $I \approx 0.012$ . This is in reasonable agreement with the cluster counting method, indicating the consistency of the study. (Measuring  $v_{\infty}$  as a rate of a flat interface with a truncated spin flip dynamics<sup>26</sup> leads to a somewhat larger  $I \approx 0.017$ .) The theoretical value of  $I^{\text{CNT}}$  in Eq. (18) is 4.1, which is

The theoretical value of  $I^{\text{CNT}}$  in Eq. (18) is 4.1, which is more than two orders larger than the experimental value. If the CNT is adjusted at m=4 a much better agreement with the measured values is observed,  $I_4^{\text{ACT}} \approx 0.09$ . Matching at m=9 cannot be performed analytically at the moment, but if one uses the corresponding effective surface tension from

Fig. 1, one obtains a value of *I*'0.06. A similar value is obtained directly from using the Becker–Do¨ring model with the measured cluster distributions ~see the Appendix!.

#### **VII. DISCUSSION**

In the present study an attempt was made to understand the limitations of the classical nucleation theory ~CNT! when applied to an Ising model. The main focus was on the thermodynamic aspects, as given by the equilibrium distribution of clusters *f* eq(*n*) at zero undercooling ~zero magnetic field!.

The problem in evaluating the CNT is complicated by the fact that in most cases this theory is reasonable, having a correct ~or almost correct—see below! exponential term. Extraction of a slowly varying correction to a fast exponential is a notoriously hard problem, both analytically and in simulations. Nevertheless, the unique feature of a twodimensional system, the availability of exact expressions for the bulk interfacial energy, combined with advanced computational powers, allows the highlighting of the mild discrepancies of CNT and allows to suggest some corrections.

The major limitation to CNT is due to the small clusters which do not reproduce the macroscopic Wulff shape, and which have an effectively higher interfacial energy. On the other hand, concentrations of such clusters can be calculated analytically up to some reasonably small size. This allows one to adjust the prefactor of CNT at the largest accessible cluster size (*n*54 in the present case!, removing the major discrepancy of that theory. This approach is reasonable when describing the distribution at intermediate temperatures ~Figs. 4 and 5! or when predicting the nucleation rate. On the other hand, one should stress that currently there is still no analytical or extensive numerical justification for a constant value of this prefactor at arbitrarily large cluster sizes.

The availability of low-temperature analytical expressions for the small cluster numbers also ensures a very accurate verification of the computational scheme. This is important since nucleation typically deals with extremely rare events, where even the best available random number generators56 or associated probability trees can become biased. The test confirmed the accuracy of the scheme for most of the parameters considered, but it also established limitations in the reliability of computations at very low temperatures or at very large sizes. ~For example, a slight tendency towards an increase of the aforementioned preexponential at *T*51 and *T*51.2 is observed at large *n*, but at the moment any conclusions here are not reliable.!

Besides the limitations of CNT for small clusters, there are also limitations at low and high temperatures. In the former case, as discussed in Appendix B, one could require exponentially large *n* in order to observe a smooth distribution, rather than a typical ''sawtooth'' structure which is characteristic for *T*→0.

At high *T*, as suggested by simulations in Fig. 5, there exists a correction of a power-law type to the classical prefactor ~although the power index is temperature dependent, in contrast, e.g., to the field-theoretic descriptions!. There does not exist yet an unambiguous explanation of this phenomenon, and with the limited information available at least three scenarios can be suggested.

First, it could be that that those are essentially 'nonclassical' corrections due to finite values of *n*. The nonclassical corrections are expected to vanish for *n*@pz2,z being the correlation length. In practice, the latter should be a strong inequality, since the approach to bulk values of interfacial energy can be slow—see, e.g., Sec. V. Unfortunately, even for *T*51.43 with z'3 it is currently impossible to exceed the above inequality even by one order of magnitude, but with rapidly increasing computational powers this issue could be resolved in the near future.

The second explanation is the presence of coagulation effects which are ignored in the CNT and which increase near *Tc* . Such effects can be revealed by deviations of quasiequilibrium cluster distributions at nonzero undercooling from simple exponentials given by Eq. ~29!. Without coagulation, simulations at any undercooling should lead to identical preexponentials in Fig. 5. Nevertheless, simulations at *T*51.43 for small negative <sup>d</sup>*S* ~where coagulation effects should be smaller! reveal a slight flattening tendency at the largest *n*, although at present it is hard to distinguish this tendency from a computational artifact. Flattening of the preexponential with suppressed coagulation becomes most pronounced at *T*5*Tc* , which is indicated by the dotted line in Fig. 5.

Finally, even within the CNT, and for *n*→`, it is not completely clear whether the standard expression for the surface tension of the two-dimensional Ising model is the one which should be used when evaluating the interfacial energy of a nucleus. Some arguments in favor of such potential differences are briefly considered in Appendix B.

Besides thermodynamics, the nucleation problem also has a purely kinetic aspect. The question here is whether nucleation indeed can be accurately approximated as a onedimensional random walk of a dropletlike cluster in the *n* space, while in reality it is a multidimensional random walk among the plethora of cluster shapes, some of them being very far from a droplet ~see Fig. 2!. If the one-dimensional picture is adequate and the equilibrium distribution is known, the kinetic part of the nucleation theory, Eqs. ~2! or ~A1!, should be accurate.

Indeed, reasonable agreement was observed between the predicted and measured nucleation rates. An interesting point is that analytical evaluation of the rate was performed using exclusively microscopic dynamics ~and the adjusted classical theory! without matching parameters. Most of the earlier work, including our Ref. 26, relied on at least one measured quantity, e.g., the absolute value of the pre-factor, or the growth rate. At the same time one should note that a perfect correspondence between the predicted and measured nucleation rates was not yet achieved, even if the measured equilibrium distributions are used in Eq. ~A1!. Most likely, this points out the limitations of the one-dimensional random walk model of nucleation, at least for not too large values of the critical size.

#### **VIII. CONCLUSION**

The validity of classical nucleation theory ~CNT! for a two-dimensional Ising system with a nonconserved spin flip dynamics was examined at various temperatures using large scale Monte Carlo simulations and exact data for the interfacial energy available for a square lattice.

At intermediate temperatures (up to  $0.7T_c$ ) distributions of large clusters is in qualitative agreement with CNT but differs by a constant pre-factor. The latter can be estimated analytically from low-temperature cluster expansions. The CNT adjusted for this pre-factor is in much better agreement with the observed cluster distributions and the observed nucleation rate.

In the limit  $T\rightarrow 0$ , where simulation data are unavailable, it is still possible to argue that certain features of CNT will be recovered for selected, "magic" cluster numbers (perfect squares). In general, however, this theory is invalid here due to strong nonclassical nucleation effects when properties of finite-sized clusters are very different from those predicted by the macroscopic Wulff droplet construction.

In the high temperature region the CNT is in qualitative disagreement with simulation, and a size-dependent prefactor needs to be added into classical expression for the cluster distribution. The latter, most likely, is due to coagulation effects, but other possible explanations were also considered in the study.

#### **ACKNOWLEDGMENTS**

The authors wish to thank R. Baxter and P. A. Rikvold for very useful e-mail correspondence, and R. Schonmann for sending reprints of his works.

#### APPENDIX A: EXACT FLUX WITHIN THE BECKER-DÖRING MODEL

The model introduced by Farkas, Becker, and Döring (BD)<sup>6</sup> describes nucleation as a random walk of a cluster in the space of its sizes, n. The gain probability is given by  $\beta(n)$  while the loss can be reconstructed from detailed balance as  $\alpha(n) = \beta(n-1)f(n-1)/f(n)$ . The depletion of "monomers" is neglected in the BD model (see, however, Ref. 57), which seems reasonable at moderate times for a high nucleation barrier and away from  $T_c$ . In a sense, the BD model is more general than is usually attributed to CNT, as long as one does not specify the quasiequilibrium distributions, f(n).

According to Farkas,<sup>6</sup> the steady-state flux of nuclei within the BD model can be obtained exactly. In the present notations the result can be cast as

$$I(\delta S) = 2\sqrt{\pi}\beta_0 \left\{ \sum_{n=0}^{\infty} \frac{\exp(-n\delta S)}{\sqrt{n}f_n^{\text{eq}}} \right\}^{-1}$$
 (A1)

(i.e., the  $\delta S$  dependence of the nucleation rate is expressed through a discrete Laplace transform of the equilibrium combination  $1/\sqrt{n}f_n^{\rm eq}$ ). If the function  $n\,\delta S + \ln f_n^{\rm eq}$  behaves smoothly in the vicinity of the critical size, but still exhibits a distinct minimum with a width  $\Delta_n \ll n_*$ , Eq. (A1) becomes equivalent to Eq. (2). Smoothness of f(n) is not always expected, however, due to "magic" cluster numbers (e.g., squares for the two-dimensional Ising case). Nevertheless, and despite the fact that  $\Delta_n$  was comparable to  $n_*$  in the

present simulations, Eqs. (A1) and (2) produced numerically very similar results if the measured value of  $f(n_*)$  was used.

### APPENDIX B: CORRECTIONS TO CNT AT LOW TEMPERATURES

First, consider the low-temperature behavior of Eq. (9). For  $m \rightarrow 0$  the elliptic integral K'(m) has an asymptote  $\ln(4/\sqrt{m}) \rightarrow \phi/T$ . This gives the only divergent term in Eq. (9) when K' is multiplied by 1 in the square brackets in Eq. (9). The divergence is quadratic in 1/T, and it makes  $\sigma_{\rm eff}$  approach  $\sigma_0$  in the strict limit T=0. There are no linearly divergent terms. Integration of nondivergent terms results in a constant for which an explicit expression can be written, but which has to be evaluated numerically anyway. This leads to a correction to  $\sigma_{\rm eff}$  which is quadratic in T, as in Eq. (13).

Now consider, instead, a large but finite cluster with size *n* being a perfect square. The number of such clusters at low temperatures will be given by

$$f_n^{\text{eq}} = f_0 \exp\left(-\frac{2\phi\sqrt{n}}{T}\right) (1 + B_n^1 e^{-\phi/T} + B_n^2 e^{-2\phi/T} + \cdots),$$
(B1)

where  $B_n^i$  is the number of configurations of n which have i bonds less than a square. (In the case of n=4 in Fig. 2 one has  $B_4^1 = 18$  and  $B_4^2 = 0$ .)

With Eqs. (13) and (B1), the pre-factor for the equilibrium distribution of small clusters can be written as

$$A(n) \approx f_0 \exp(-11.2\sqrt{n}T/\phi + B_n^1 e^{-\phi/T} + B_n^2 e^{-2\phi/T} + \cdots).$$
 (B2)

We keep the exponential terms even in the presence of a linear one since potentially,  $B_n^i$ , can become large (see below). Formally, the prefactor becomes "classical" in the strict limit T=0 (see Fig. 5), although this will not be the case if n is not a perfect square or if T is finite and n is larger than  $(\phi/11T)^2$ .

For large  $n \ge 1$  the factor  $B_n^1$  increases with n approximately as  $n^2$ . Thus, for  $n \le e^{\phi/2T}$  the cluster will remain close to a square with flat faces, and with interfacial energy which remains exponentially close to the one at T = 0. This drastically differs from the limit  $n \to \infty$ . Here each term in the sum in Eq. (B1) diverges, effectively erasing the flat surfaces (recall that the interface is rough in two dimensions for any  $T > 0^{15}$ ), and leading to much larger, power-law corrections to the interfacial energy.

The above transition is expected at  $n \ge e^{\phi/2T}$ , although the details could be determined by other terms. For such exponentially large n another feature of CNT is expected to be recovered, namely the "saw-tooth" structure of the distribution is expected to diminish if not vanish completely. The main reason for the strongly (exponentially) nonsmooth n-dependence of  $f_n^{eq}$  is due to a discrete change in the numbers of bonds, and the prevalence of the term  $e^{\phi/T}$  over the difference between the neighboring configurational factors. Once the situation is reversed, and the high entropy configurations start to dominate, there seems to be no special reason for a strongly nonsmooth distribution.

An important remaining question is whether in the limit *n*→` one indeed will recover the bulk values of the interfacial energy discussed in Sec. II B. In the standard derivations of the interfacial energy ~e.g., Refs. 13 and 37! one fixes the end points of an interface, otherwise allowing for all possible configurations. On the other hand, when defining a cluster, the interface is allowed to fluctuate without changing the amount of each phase. An essential difference between these two definitions can be seen from the fact that the latter is applicable for nonzero undercooling, and should not depend on the value of <sup>d</sup>*S*. The former definition, on the other hand, is hard to implement for the nonequilibrium case, since the stable phase will tend to grow, curving the interface to the radius of the order of *<sup>R</sup>*\* . While it is not surprising that a rigorous unique definition of a interface is not obvious,49 the distinguishing between the two situations is straightforward and can be clarified quantitatively, which we consider to be a future task.

- 1M. Volmer and A. Weber, Z. Phys. Chem. <sup>~</sup>Munich! **<sup>119</sup>**, 227 <sup>~</sup>1926!. 2A. Einstein, Ann. Phys. <sup>~</sup>Leipzig! **<sup>33</sup>**, 1275 <sup>~</sup>1910!. 3F. F. Abraham, *Homogeneous Nucleation Theory* <sup>~</sup>Academic, New York,
- <sup>1974</sup>!. 4P. Debenedetti, *Metastable Liquids* <sup>~</sup>Princeton University Press, Princeton,
- NJ, 1996!. 5R. M. Westewelt, Phys. Status Solidi B **<sup>74</sup>**, 727 <sup>~</sup>1976!; **<sup>76</sup>**, 31 <sup>~</sup>1976!; I. M. Fishman, Usp. Fiz. Nauk **<sup>155</sup>**, 329 <sup>~</sup>1987!. 6L. Farkas, Z. Phys. Chem. <sup>~</sup>Munich! **<sup>125</sup>**, 236 <sup>~</sup>1927!; R. Becker and W.
- Do¨ring, Ann. Phys. ~N.Y.! **24**, 719 ~1935!; Ya. B. Zeldovich, Ann. Phys. ~N.Y.! **18**, 1 ~1943!; J. Frenkel, *Kinetic Theory of Liquids* ~Oxford University Press, Oxford, 1946!.
- 7E. M. Lifshits and L. P. Pitaevskii, *Physical Kinetics* ~Pergamon, New York, 1981!, Sec. 99. 8G. Ruppeiner, Rev. Mod. Phys. **<sup>67</sup>**, 605 <sup>~</sup>1995!.
- 9G. Wilemski, J. Chem. Phys. **103**, 1119 ~1995!.
- 10D. W. Oxtoby and P. R. Harrowell, J. Chem. Phys. **96**, 3834 ~1992!; Y. C. Shen and D. W. Oxtoby, *ibid.* **104**, 4233 ~1996!; Phys. Rev. Lett. **77**, 3585 ~1996!.
- 11L. Onsager, Phys. Rev. **<sup>65</sup>**, 117 <sup>~</sup>1944!. 12B. M. McCoy and T. T. Wu, *The Two-Dimensional Ising Model* <sup>~</sup>Harvard
- University Press, Cambridge, MA, 1973!. 13R. J. Baxter, *Exactly Solved Models in Statistical Mechanics* <sup>~</sup>Academic, New York, 1982!. 14C. Domb, Adv. Phys. **<sup>9</sup>**, 149 <sup>~</sup>1960!. <sup>15</sup> J. D. Weeks, G. H. Gilmer, and H. J. Leamy, Phys. Rev. Lett. **<sup>31</sup>**, 549
- <sup>~</sup>1973!. 16M. Hasenbusch and K. Pinn, Physica A **<sup>203</sup>**, 189 <sup>~</sup>1994!. 17K. Kawasaki, ''Kinetics of Ising models,'' in *Phase Transitions and Criti-*
- *cal Phenomena*, edited by C. Domb and M. S. Green ~Academic, New
- York, 1972!, Vol. 2, pp. 443–501. <sup>18</sup>*Applications of the Monte Carlo Method in Statistical Physics*, 2ed., edited by K. Binder ~Springer-Verlag, New York, 1987!.
- 19K. Binder and D. Stauffer, Adv. Phys. **25**, 343 ~1976!.
- <sup>20</sup> J. Marro, J. L. Lebowitz, and M. H. Kalos, Phys. Rev. Lett. **43**, 282 ~1979!.
- 21D. Stauffer, A. Coniglio, and D. W. Heermann, Phys. Rev. Lett. **49**, 1299

- ~1982!; D. Stauffer, Int. J. Mod. Phys. C **3**, 1059 ~1992!; Physica A **244**,
- <sup>344</sup> <sup>~</sup>1997!; M. Acharyya and D. Stauffer, Eur. Phys. J. B **<sup>5</sup>**, 571 <sup>~</sup>1998!. 22D. Stauffer and J. Kertesz, Physica A **<sup>177</sup>**, 381 <sup>~</sup>1991!.
- 23D. W. Heerman and W. Klein, Phys. Rev. B **27**, 1732 ~1983!; Phys. Rev. Lett. **50**, 1062 ~1983!.
- 24H. M. Duiker and P. D. Beale, Phys. Rev. B **<sup>41</sup>**, 490 <sup>~</sup>1990!. 25P. A. Rikvold, H. Tomita, S. Miyashita, and S. W. Sides, Phys. Rev. E **<sup>49</sup>**,
- <sup>5080</sup> <sup>~</sup>1994!. 26V. A. Shneidman, K. A. Jackson, and K. M. Beatty, Phys. Rev. B **<sup>59</sup>**, 3579
- <sup>~</sup>1999!. 27R. A. Ramos, P. A. Rikvold, and M. A. Novotny, Phys. Rev. B **<sup>59</sup>**, 9053

- <sup>~</sup>1999!. <sup>28</sup> J. P. Marchand and P. A. Martin, Physica A **127A**, 681 <sup>~</sup>1984!. 29R. Kotecky and E. Olivieri, J. Stat. Phys. **<sup>70</sup>**, 1121 <sup>~</sup>1993!. 30E. J. Neves and R. H. Schonmann, Commun. Math. Phys. **<sup>137</sup>**, 209 ~1991!; Probab. Theory Relat. Fields **91**, 331 ~1992!; R. H. Schonmann, Commun. Math. Phys. **161**, 1 ~1994!; R. H. Schonmann and S. B. Shlosman, *ibid.* **194**, 389 ~1998!.
- 31E. Stoll, K. Binder, and T. Schneider, Phys. Rev. B **<sup>6</sup>**, 2777 <sup>~</sup>1972!. 32K. Binder, Phys. Rev. B **<sup>15</sup>**, 4425 <sup>~</sup>1977!. 33M. E. Fisher, Physics <sup>~</sup>Long Island City, N.Y.! **<sup>3</sup>**, 255 <sup>~</sup>1967!. 34V. A. Shneidman, Physica A **<sup>190</sup>**, 145 <sup>~</sup>1992!.

- 35H. L. Richards, S. W. Sides, M. A. Novotny, and P. A. Rikvold, J. Magn. Magn. Mater. **150**, 37 ~1995!.

- <sup>36</sup> J. S. Langer, Ann. Phys. <sup>~</sup>N.Y.! **<sup>54</sup>**, 258 <sup>~</sup>1969!; *ibid.* **<sup>65</sup>**, 53 <sup>~</sup>1971!. 37C. Rottman and M. Wortis, Phys. Rev. B **<sup>24</sup>**, 6274 <sup>~</sup>1981!. 38R. K. Zia and J. E. Avron, Phys. Rev. B **<sup>25</sup>**, 2042 <sup>~</sup>1982!. 39P. G. van Dongen and M. H. Ernst, J. Stat. Phys. **<sup>37</sup>**, 301 <sup>~</sup>1984!. 40G. H. Gilmer, Mater. Sci. Eng. **<sup>65</sup>**, 15 <sup>~</sup>1984!; K. A. Jackson, G. H. Gilmer, and D. E. Te¨mkin, Phys. Rev. Lett. **75**, 2530 ~1995!; K. A. Jackson *et al.*, J. Cryst. Growth **163**, 461 ~1996!; K. M. Beatty and K. A. Jackson, *ibid.* **174**, 28 ~1997!.
- 41K. M. Beatty, Ph.D. dissertation, University of Arizona, 1997.

- 42A. Coniglio and W. Klein, J. Phys. A **<sup>13</sup>**, 2775 <sup>~</sup>1980!. 43C. N. Yang and T. D. Lee, Phys. Rev. **<sup>87</sup>**, 404 <sup>~</sup>1952!; **<sup>87</sup>**, 410 <sup>~</sup>1999!. 44M. E. Fisher and A. E. Ferdinand, Phys. Rev. Lett. **<sup>19</sup>**, 169 <sup>~</sup>1967!. 45M. Abramowitz and I. Stegun, *Handbook of Mathematical Functions* <sup>~</sup>Dover, New York, 1972!. 46L. Onsager, Nuovo Cimento Suppl. **<sup>6</sup>**, 261 <sup>~</sup>1949!.
- 47C. N. Yang, Phys. Rev. **85**, 808 ~1952!.
- 48M. J. Lowe and D. J. Wallace, J. Phys. A **13**, L381 ~1980!; C. K. Harris, Physica A **17**, 1767 ~1984!; C. C. Gu¨nther, P. A. Rikvold, and M. A. Novotny, *ibid.* **212**, 194 ~1994!.

- 49C. Rottman and M. Wortis, Phys. Rep. **<sup>103</sup>**, 59 <sup>~</sup>1984!. <sup>50</sup> J. L. Katz, Pure Appl. Chem. **<sup>64</sup>**, 1661 <sup>~</sup>1992!. 51S. Ono and S. Kondo, *Molecular Theory of Surface Tension* <sup>~</sup>Springer,
- Berlin, 1960!. 52A. Laaksonen and R. McGraw, Europhys. Lett. **<sup>35</sup>**, 367 <sup>~</sup>1996!. 53R. Baxter <sup>~</sup>private communication!; a more detailed study of the interfacial tension for a triangular lattice is given in R. K. Zia, J. Stat. Phys. **45**,
- <sup>801</sup> <sup>~</sup>1986!. 54P. James, Phys. Chem. Glasses **<sup>15</sup>**, 95 <sup>~</sup>1974!; V. Fokin, A. Kalinina, and V. Filipovich, Fiz. Khim. Stekla **3**, 122 ~1977!; J. Deubener, R. Bru¨kner,
- and M. Sternizke, J. Non-Cryst. Solids **<sup>163</sup>**, 1 <sup>~</sup>1993!. 55V. A. Shneidman, K. A. Jackson, and K. M. Beatty, J. Cryst. Growth
- <sup>~</sup>submitted!. 56W. H. Press, B. P. Flannery, S. A. Teukolsky, and W. T. Vetterling, *Numerical Recipies in C* ~Cambridge University Press, Cambridge, 1988!.
- 57O. Penrose and J. Lebowitz, in *Studies in Statistical Mechanics*, Vol. VII, edited by E. Montrol and J. Lebowitz ~North-Holland, Amsterdam, 1979!; J. Ball, J. Carr, and O. Penrose, Commun. Math. Phys. **104**, 657 ~1986!.