# On the Capacity of the Discrete-Time Poisson Channel

Amos Lapidoth, Fellow, IEEE, and Stefan M. Moser, Member, IEEE

Abstract—The large-inputs asymptotic capacity of a peak-power and average-power limited discrete-time Poisson channel is derived using a new firm (nonasymptotic) lower bound and an asymptotic upper bound. The upper bound is based on the dual expression for channel capacity and the notion of capacity-achieving input distributions that escape to infinity. The lower bound is based on a lower bound on the entropy of a conditionally Poisson random variable in terms of the differential entropy of its conditional mean.

Index Terms—Channel capacity, direct detection, high signal-tonoise ratio (SNR), optical communication, photon, pulse amplitude modulation, Poisson channel.

#### I. Introduction

E consider a memoryless discrete-time channel whose output Y takes value in the set of nonnegative integers  $\mathbb{Z}_0^+$  and whose input takes value in the set of nonnegative real numbers  $\mathbb{R}_0^+$ . Conditional on the input  $x \geq 0$ , the output is Poisson distributed with mean  $x + \lambda_0$ , where  $\lambda_0$  is some nonnegative constant, called dark current. Thus, the conditional channel law is given by

$$W(y \mid x) = e^{-(x+\lambda_0)} \frac{(x+\lambda_0)^y}{y!}, \quad y \in \mathbb{Z}_0^+, \ x \in \mathbb{R}_0^+.$$
 (1)

This channel is often used to model pulse-amplitude modulated (PAM) optical communication with a direct-detection receiver [1]. Here the input x is proportional to the product of the transmitted light intensity by the pulse duration; the dark current  $\lambda_0$  similarly models the time-by-intensity product of the background radiation; and the output Y models the number of photons arriving at the receiver during the pulse duration. A peak-power constraint on the transmitter is accounted for by the peak-input constraint

$$\Pr[X > \mathsf{A}] = 0 \tag{2}$$

Manuscript received October 12, 2007; revised March 01, 2008. Current version published December 24, 2008. The work of S. M. Moser was supported in part by the ETH under Grant TH-23 02-2. The material in this paper was presented in part at the 2003 Winter School on Coding and Information Theory, Monte Veritá, Ascona, Switzerland, February 2003, and at the 41st Annual Allerton Conference on Communication, Control, and Computing, Allerton House, Monticello, IL, October 2003, and have been published as part of S. M. Moser's Ph.D. dissertation.

A. Lapidoth is with the Department of Information Technology and Electrical Engineering, Swiss Federal Institute of Technology (ETH), 8092 Zurich, Switzerland (e-mail: lapidoth@isi.ee.ethz.ch).

S. M. Moser is with the Department of Communication Engineering, National Chiao Tung University (NCTU), Hsinchu 30010, Taiwan (stefan.moser@ieee.org).

Communicated by Y. Steinberg, Associate Editor for Shannon Theory. Digital Object Identifier 10.1109/TIT.2008.2008121

and an average-power constraint by

$$\mathsf{E}[X] \le \mathcal{E}. \tag{3}$$

Note that since the input is proportional to the light intensity, the power constraints apply to the input directly and not to the square of its magnitude (as is usually the case for electrical transmission models).

We use  $0 < \alpha \le 1$  to denote the average-to-peak-power ratio

$$\alpha \triangleq \frac{\mathcal{E}}{\mathsf{A}}.\tag{4}$$

The case  $\alpha=1$  corresponds to the absence of an average-power constraint, whereas  $\alpha\ll 1$  corresponds to a very weak peakpower constraint.

Although we also provide firm lower bounds on channel capacity that are valid for all values of the peak and average power, our main interest in this paper is mostly in the case where both the allowed average power and the allowed peak power are large. In fact, we shall compute the asymptotic behavior of channel capacity as both A and  $\mathcal{E}$  tend to infinity with the ratio  $\alpha$  held fixed. The low-input regime where the input power is small was studied in [2] and [3].

No analytic expression for the capacity of the Poisson channel is known. In [1], Shamai showed that capacity-achieving input distributions are discrete with a finite number of mass points, where the number of mass points increases to infinity as the constraints are relaxed.

In [4], Brady and Verdú considered the case of the Poisson channel with only an average-power constraint. The following bounds were derived. Let  $\mathcal E$  and  $\lambda_0$  tend to infinity with their ratio  $\mathrm{SNR} \triangleq \frac{\mathcal E}{\lambda_0}$  held fixed. Given  $\epsilon > 0$  there exists an  $\mathcal E_\epsilon$  such that for all  $\mathcal E > \mathcal E_\epsilon$  the capacity is bounded by

$$C(\mathcal{E}) \ge \frac{1}{2} \log \frac{\mathcal{E}}{2\pi} - \frac{1}{2} \log \left( 1 + \frac{1}{\text{SNR}} \right) - \epsilon$$

$$C(\mathcal{E}) \le \frac{1}{2} \log \frac{\mathcal{E}}{2\pi} + \log \left( \sqrt{\text{SNR}} \left( 1 + \frac{1}{\mathcal{E}_{\epsilon}} \right) + \frac{1}{\sqrt{\text{SNR}}} \right)$$

$$+ 1 + \log \frac{3}{2} + \epsilon.$$
(6)

Note that the difference between the upper and lower bound is unbounded if the dark current is held constant while  $\mathcal{E}$  tends to infinity.

While the capacity of the discrete-time Poisson channel is unknown, the capacity of the general continuous-time Poisson channel where the input signal is not restricted to be PAM has been derived exactly: the case with a peak-power constraint only was solved by Kabanov [5]; the more general situation of peakand average-power constraints was treated by Davis [6]; Wyner [7] found the reliability function of the channel; and Frey [8], [9] studied the capacity of the Poisson channel under an -norm constraint.

The capacity of the continuous-time Poisson channel can only be achieved by input processes that have unbounded bandwidth. Since this is not realistic, Shamai and Lapidoth [10] investigated the channel capacity of a Poisson channel with some spectral constraints, but without restricting the input to use PAM. Note that even though the penalty incurred by the PAM scheme tends to zero once the pulse duration is shortened to zero, a PAM scheme is not optimal if we only limit the minimal pulsewidth, but not the pulse shape [11].

Besides the Poisson channel model there are a few related channel models used to describe optical communication. The free-space optical intensity channel has been investigated in [12, Ch. 3], [13]–[18]. A variation of this model where the noise depends on the input has been studied in [12, Ch. 4], [19].

One of the obstacles to an exact expression for the capacity of the Poisson channel is that the Poisson distribution does not seem to admit a simple analytic expression. Recently, however, Martinez [20] derived a new expression for the entropy of a Poisson random variable based on an integral representation that can be easily computed numerically. Using this expression he derived firm lower and upper bounds on the capacity for the discrete-time Poisson channel with only an average-power constraint and no dark current

$$C(\mathcal{E}) \ge \frac{1}{2} \log(1 + \mathcal{E})$$

$$C(\mathcal{E}) \le \left(\mathcal{E} + \frac{1}{2}\right) \log\left(\mathcal{E} + \frac{1}{2}\right) - \mathcal{E} \log \mathcal{E} - \frac{1}{2}$$

$$+ \log\left(1 + \frac{\sqrt{2e} - 1}{\sqrt{1 + 2\mathcal{E}}}\right).$$
(8)

Similarly to the bounds presented here, the derivation of (8) is based on a duality approach. We would like to emphasize that (8) is a firm bound valid for all values of whereas we will present upper bounds that are only valid asymptotically as the available power tends to infinity. However, in the derivation in [20] there is a tiny gap in the proof that is shown only numerically. Nevertheless, Martinez' bounds are very close and actually tighter than the bounds presented here (see Fig. 2 in Section II).

Here we present results for the more general case where we enforce both peak- and average-power constraints and assume a general (nonnegative) dark current . We will derive new lower bounds on channel capacity that are tighter than previous bounds. These bounds are based on a new result that proves that the entropy of the output of a Poisson channel is always larger than the differential entropy of the channel's input (see Section III-B for more details).

We will also introduce an asymptotic upper bound on channel capacity, where "asymptotic" means that the bound is valid when the available peak and average power tend to infinity with their ratio held fixed.1 The upper and lower bounds asymptotically coincide, thus yielding the exact asymptotic behavior of channel capacity.

The derivation of the upper bounds is based on a technique introduced in [21] using a dual expression for mutual information. We will not state it in its full generality but adapted to the form needed in this paper. For more details and for a proof we refer to [21, Sec. V], [12, Ch. 2]

*Proposition 1:* Assume a channel2 with input alphabet and output alphabet . Then for an arbitrary distribution over the channel output alphabet, the channel capacity is upper-bounded by

$$C \le \mathsf{E}_{Q^*}[D(\tilde{W}(\cdot|X)||R(\cdot))]. \tag{9}$$

Here, stands for the relative entropy [22, Ch. 2], and denotes the capacity-achieving input distribution.

Proof: See [21, Sec. V]. 
$$\Box$$

The challenge of using (9) lies in a clever choice of the arbitrary law that will lead to a good upper bound. Moreover, note that the bound (9) still contains an expectation over the (unknown) capacity-achieving input distribution . To handle this expectation we will need to resort to the concept of *input distributions that escape to infinity* as introduced in [21], [23]. This concept will be briefly reviewed in Section IV-B1.

The results of this paper are partially based on [24] and have appeared in the Ph.D. dissertation [12, Ch. 5].

The remainder of this paper is structured as follows. After some brief remarks about our notation, we summarize our main results in the subsequent section. The derivations are then given in Section III (lower bounds) and Section IV (upper bounds). These two derivation sections both contain a subsection with mathematical preliminaries. In particular, in Section III-B we prove that the entropy of the output of a Poisson channel is lower-bounded by the differential entropy of its input, in Section IV-B1 we review the concept of *input distributions that escape to infinity*, and in Section IV-B2 we show an adapted version of the channel model with continuous channel output. We will conclude the paper in Section V.

We try to distinguish between those quantities that are random and those that are constant: for random quantities we use uppercase letters and for their realizations lower case letters. Scalars are typically denoted using Greek letters or lower case Roman letters. However, there will be a few exceptions to these rules. Since they are widely used in the literature, we will stick with the common customary shape of the following symbols: stands for capacity, denotes the entropy of a discrete random variable, denotes the relative entropy between two probability measures, and stands for the mutual information functional. Moreover, we have decided to use the capitals and to denote probability mass functions (PMF) in case of discrete random variables or cumulative distribution functions (CDF) in case of continuous random variables, respectively:

- denotes a distribution on an input of a channel;
- denotes a channel law, i.e., the distribution of the channel output conditioned on the channel input; and
- denotes a distribution on the channel output.

<sup>1</sup>In contrast to [4], we regard the dark current as a parameter of the channel that remains unchanged, i.e., we will always keep constant.

<sup>2</sup>There are certain measurability assumptions on the channel that we omit for simplicity. See [21, Sec. V], [12, Ch. 2].

In the case when  $Q(\cdot)$  or  $R(\cdot)$  represents a CDF, the corresponding probability density function (PDF) is denoted by  $Q'(\cdot)$  and  $R'(\cdot)$ , respectively.

The symbol  $\mathcal E$  denotes average power and A stands for peak power. We shall denote the mean- $\eta$  Poisson distribution by  $\mathcal Po(\eta)$  and the uniform distribution on the interval [a,b) by  $\mathcal U([a,b))$ . All rates specified in this paper are in nats per channel use, and all logarithms are natural logarithms.

Finally, we give the following definition.

Definition 2: Let  $f: \mathbb{R}_0^+ \to \mathbb{R}$  be a function that tends to zero as its argument tends to infinity, i.e., for any  $\epsilon > 0$  there exists a constant  $z_0$  such that for all  $z > z_0$ 

$$|f(z)| < \epsilon. \tag{10}$$

Then we write<sup>3</sup>

$$f(z) = o_z(1). (11)$$

#### II. MAIN RESULTS

We present upper and lower bounds on the capacity of channel (1). While the lower bounds are valid for all values of the power, the upper bounds are valid asymptotically only, i.e., only in the limit when the average power and the peak power tend to infinity with their ratio kept fixed. It will turn out that in this limit the lower and upper bounds coincide, i.e., asymptotically we can specify the capacity precisely.

We distinguish between three cases: in the first case, we have both an average- and a peak-power constraint where the average-to-peak-power ratio (4) is in the range  $0<\alpha<\frac{1}{3}$ . In the second case,  $\frac{1}{3}\leq\alpha\leq1$ , which includes the situation with only a peak-power constraint  $\alpha=1$ . And finally, in the third case, we look at the situation with only an average-power constraint.

We begin with the first case.

Theorem 3: The channel capacity  $C(A, \mathcal{E})$  of a Poisson channel with dark current  $\lambda_0$  under a peak-power constraint (2) and an average-power constraint (3), where the ratio  $\alpha = \frac{\mathcal{E}}{A}$  lies in  $(0, \frac{1}{3})$ , is bounded as follows:

$$C(A, \mathcal{E}) \ge \frac{1}{2} \log A - (1 - \alpha)\mu - \log\left(\frac{1}{2} - \alpha\mu\right)$$

$$-e^{\mu} \left(\frac{1}{2} - \alpha\mu\right) \left[\log\left(1 + \frac{\lambda_0 + \frac{1}{12}}{A}\right) + 2\sqrt{\frac{\lambda_0 + \frac{1}{12}}{A}} \arctan\left(\sqrt{\frac{A}{\lambda_0 + \frac{1}{12}}}\right)\right]$$

$$+ (\mathcal{E} + 1)\log\left(1 + \frac{1}{\mathcal{E}}\right) - 1 - \frac{1}{2}\log 2\pi e \quad (12)$$

$$C(A, \alpha A) \le \frac{1}{2}\log A - (1 - \alpha)\mu - \log\left(\frac{1}{2} - \alpha\mu\right)$$

$$-\frac{1}{2}\log 2\pi e + o_A(1). \quad (13)$$

<sup>3</sup>Note that by this notation we want to imply that  $o_z(1)$  does not depend on any other nonconstant variable apart from z.

Here  $\mu$  is the solution to

$$\alpha = \frac{1}{2\mu} - \frac{e^{-\mu}}{\sqrt{\mu}\sqrt{\pi}\mathrm{erf}(\sqrt{\mu})}$$
 (14)

where the error function  $\operatorname{erf}(\cdot)$  is defined as

$$\operatorname{erf}(\xi) \triangleq \frac{2}{\sqrt{\pi}} \int_0^{\xi} e^{-t^2} dt = 1 - 2\mathcal{Q}(\sqrt{2}\xi), \quad \forall \, \xi \in \mathbb{R} \quad (15)$$

with the Gaussian Q-function

$$Q(\xi) \triangleq \int_{\xi}^{\infty} \frac{1}{\sqrt{2\pi}} \cdot e^{-\frac{t^2}{2}} dt, \quad \forall \, \xi \in \mathbb{R}.$$
 (16)

Note that the function  $\mu\mapsto \frac{1}{2\mu}-\frac{e^{-\mu}}{\sqrt{\mu}\sqrt{\pi}\mathrm{erf}(\sqrt{\mu})}$  is monotonically decreasing in  $[0,\infty)$  and tends to  $\frac{1}{3}$  for  $\mu\downarrow 0$  and to 0 for  $\mu\uparrow\infty$ .

The error term  $o_A(1)$  tends to zero as the average power and the peak power tend to infinity with their ratio held fixed at  $\alpha$ ,  $0 < \alpha < \frac{1}{3}$ . Hence, the asymptotic expansion of channel capacity is

$$\begin{split} &\lim_{\mathsf{A}\uparrow\infty} \left\{ \mathcal{C}(\mathsf{A},\alpha\mathsf{A}) - \frac{1}{2}\log\mathsf{A} \right\} \\ &= -\frac{1}{2}\log 2\pi e - (1-\alpha)\mu - \log\left(\frac{1}{2} - \alpha\mu\right), \quad 0 < \alpha < \frac{1}{3} \end{split} \tag{17}$$

where  $\mu$  is defined as above to be the solution to (14).

In the second case  $\alpha \geq \frac{1}{3}$ , we have the following bounds.

Theorem 4: The channel capacity  $\mathcal{C}(A, \mathcal{E})$  of a Poisson channel with dark current  $\lambda_0$  under a peak-power constraint (2) and an average-power constraint (3), where the ratio  $\alpha = \frac{\mathcal{E}}{A}$  lies in  $[\frac{1}{3}, 1]$ , is bounded as follows:

$$\mathcal{C}(\mathsf{A},\mathcal{E}) \ge \frac{1}{2}\log\mathsf{A} + \left(\frac{\mathsf{A}}{3} + 1\right)\log\left(1 + \frac{3}{\mathsf{A}}\right) - 1$$
$$-\sqrt{\frac{\lambda_0 + \frac{1}{12}}{\mathsf{A}}}\left(\frac{\pi}{4} + \frac{1}{2}\log 2\right) - \frac{1}{2}\log\frac{\pi e}{2} \quad (18)$$
$$\mathcal{C}(\mathsf{A},\alpha\mathsf{A}) \le \frac{1}{2}\log\mathsf{A} - \frac{1}{2}\log\frac{\pi e}{2} + o_{\mathsf{A}}(1). \quad (19)$$

Here the error term  $o_A(1)$  tends to zero as the average power and the peak power tend to infinity with their ratio held fixed at  $\alpha$ ,  $\frac{1}{3} \leq \alpha \leq 1$ . Hence, the asymptotic expansion for the channel capacity is

$$\lim_{\mathsf{A}\uparrow\infty} \left\{ \mathcal{C}(\mathsf{A}, \alpha\mathsf{A}) - \frac{1}{2}\log\mathsf{A} \right\} = -\frac{1}{2}\log\frac{\pi e}{2}, \quad \frac{1}{3} \le \alpha \le 1.$$
(20)

The bounds of Theorem 3 and 4 are depicted in Fig. 1 for different values of  $\alpha$ .

Remark 5: For  $\alpha \uparrow \frac{1}{3}$  the solution  $\mu$  to (14) tends to zero. If in (13)  $\mu$  is chosen to be zero, then (13) coincides with (19). On the other hand, the lower bound (12) does not converge to (18) for  $\mu \downarrow 0$ . The reason for this lies in a detail of the derivations shown

![](_page_3_Figure_2.jpeg)

Fig. 1. This plot depicts the firm lower bounds (12) and (18) (valid for all values of A) and the asymptotic upper bounds (13) and (19) (valid only in the limit when A  $\uparrow \infty$ ) on the capacity of a Poisson channel under an average- and a peak-power constraint with average-to-peak-power ratio  $\alpha$ . For  $\alpha \ge \frac{1}{3}$  (including the case of only a peak-power constraint  $\alpha = 1$ ) the bounds do not depend on  $\alpha$ . The upper bounds do not depend on the dark current. For the lower bounds, the dark current is assumed to be  $\lambda_0 = 3$ . The horizontal axis is measured in decibels where A [dB] =  $10 \log_{10} A$ .

in Section III-D: in the case of only a peak-power constraint we are able to derive the value of  $E[\log(1+\frac{a}{X})]$  exactly (see (49)), whereas in the case of a peak- and average-power constraint we need to bound this value (see (45)).

*Remark 6:* Note that in Theorem 4 both the lower and the upper bound do not depend on  $\alpha$ . Asymptotically, the average-power constraint becomes inactive for  $\alpha \in [\frac{1}{3}, 1]$  so the transmitter uses less than the available average power.

Finally, for the case with only an average-power constraint the results are as follows.

Theorem 7: The channel capacity  $C(\mathcal{E})$  of a Poisson channel with dark current  $\lambda_0$  under an average-power constraint (3) is bounded as follows:

$$C(\mathcal{E}) \ge \frac{1}{2} \log \mathcal{E} - \sqrt{\frac{\pi \left(\lambda_0 + \frac{1}{12}\right)}{2\mathcal{E}}} + (\mathcal{E} + 1) \log \left(1 + \frac{1}{\mathcal{E}}\right) - 1 \qquad (21)$$

$$C(\mathcal{E}) \le \frac{1}{2} \log \mathcal{E} + o_{\mathcal{E}}(1). \qquad (22)$$

Here the error term  $o_{\mathcal{E}}(1)$  tends to zero as  $\mathcal{E} \uparrow \infty$ . Hence, the asymptotic expansion for the channel capacity is

The bounds of Theorem 7 are shown in Fig. 2, together with the lower and upper bound equations (5) and (6) from [4] and equations (7) and (8) from [20].

*Remark 8:* If we keep  $\mathcal E$  fixed and let  $A \uparrow \infty$ , we get  $\alpha \downarrow 0$ . For  $\alpha \ll 1$ , the solution  $\mu$  to (14) tends to  $\frac{1}{2\alpha} \gg 1$  which makes sure that (13) tends to (22). To see this note that for  $\mu \gg 1$  we can approximate  $\operatorname{erf}(\sqrt{\mu}) \approx 1$ . Then we get from (14) that

$$\frac{1}{2} - \alpha \mu \approx \sqrt{\frac{\mu}{\pi}} e^{-\mu}.$$
 (24)

Using this together with

$$\frac{1}{2}\log A = \frac{1}{2}\log \mathcal{E} - \frac{1}{2}\log \alpha \qquad (25)$$

$$\approx \frac{1}{2}\log \mathcal{E} + \frac{1}{2}\log 2\mu \qquad (26)$$

we get from (13)

$$\frac{1}{2}\log A - \mu + \underbrace{\alpha\mu}_{\approx \frac{1}{2}} - \log\left(\frac{1}{2} - \alpha\mu\right) - \frac{1}{2}\log 2\pi e$$

$$\approx \frac{1}{2}\log \mathcal{E} + \frac{1}{2}\log 2\mu - \mu + \frac{1}{2} - \log\sqrt{\frac{\mu}{\pi}}e^{-\mu} - \frac{1}{2}\log 2\pi e$$
(27)

 $\lim_{\mathcal{E}\uparrow\infty} \left\{ \mathcal{C}(\mathcal{E}) - \frac{1}{2}\log\mathcal{E} \right\} = 0. \tag{23}$   $= \frac{1}{2}\log\mathcal{E}. \tag{28}$ 

![](_page_4_Figure_2.jpeg)

Fig. 2. This plot depicts the firm lower bound (21) (valid for all values of  $\mathcal{E}$ ) and the asymptotic upper bound (22) (valid only in the limit when  $\mathcal{E}\uparrow\infty$ ) on the capacity of a Poisson channel with average-power constraint  $E[X] \leq \mathcal{E}$ . The lower bound assumes a dark current  $\lambda_0=3$ . Additionally asymptotic versions of the lower and upper bound (5) and (6) by Brady and Verdú [4] are plotted where we have assumed  $\mathcal{E}_\epsilon\uparrow\infty$ ,  $\epsilon=0$ , and  $\lambda_0=3$ , and the firm lower and upper bounds (7) and (8) by Martinez [20] are shown. Note that the lower bound (7) assumes  $\lambda_0=0$  and is therefore not directly comparable with (21). The horizontal axis is measured in decibels where  $\mathcal{E}$  [dB] =  $10\log_{10}\mathcal{E}$ .

Similarly, (12) converges to (21) which can be seen by noting that for  $\mathcal{E}$  fixed and  $A \uparrow \infty$  such that  $\alpha \downarrow 0$  we get

$$e^{\mu} \left( \frac{1}{2} - \alpha \mu \right) \left[ \log \left( 1 + \frac{\lambda_0 + \frac{1}{12}}{\mathsf{A}} \right) + 2\sqrt{\frac{\lambda_0 + \frac{1}{12}}{\mathsf{A}}} \arctan \left( \sqrt{\frac{\mathsf{A}}{\lambda_0 + \frac{1}{12}}} \right) \right]$$

$$\to \sqrt{\frac{\pi \left( \lambda_0 + \frac{1}{12} \right)}{2\mathcal{E}}}, \quad \alpha \downarrow 0. \tag{29}$$

Hence, Theorem 7 can be seen as corollary to Theorem 3.

#### III. DERIVATION OF THE LOWER BOUNDS

#### A. Overview

The key ideas of the derivation of the lower bounds are as follows. We drop the optimization in the definition of capacity and simply choose one particular  $Q(\,\cdot\,)$ 

$$C = \sup_{Q(\cdot)} I(X;Y) \ge I(X;Y)|_{\text{for a specific } Q(\cdot)}.$$
 (30)

This leads to a natural lower bound on capacity.

We would like to choose a distribution  $Q(\cdot)$  that is reasonably close to the capacity-achieving input distribution in order to get a tight lower bound. However, we might have the difficulty

that for such a  $Q(\cdot)$  the evaluation of I(X;Y) is intractable. Note that even for relatively "simple" distributions  $Q(\cdot)$  the distribution of the corresponding channel output Y may be difficult to compute, let alone H(Y).

To avoid this problem we lower-bound H(Y) in terms of h(X) and upper-bound H(Y|X) in terms of  $\operatorname{E}[\log X]$ . This will lead to a lower bound on  $\mathcal C$  that only depends on  $Q(\,\cdot\,)$  through the expression

$$h(X) - \frac{1}{2} \mathsf{E}[\log X]. \tag{31}$$

We then choose the CDF  $Q(\cdot)$  to maximize this expression under the given power constraints.

#### B. Mathematical Preliminaries

The following lemma summarizes some basic properties of a Poisson distribution.

Lemma 9: Let K be Poisson distributed with mean  $\eta, K \sim \mathcal{P}o(\eta)$ , i.e.,

$$\Pr[K = k] = e^{-\eta} \frac{\eta^k}{k!}, \quad k \in \mathbb{Z}_0^+.$$
 (32)

Then the following holds:

$$\mathsf{E}[K] = \eta \tag{33}$$

$$Var(K) = \eta \tag{34}$$

$$\mathsf{E}[(K - \mathsf{E}[K])^3] = \eta \tag{35}$$

and is monotonically nondecreasing for and monotonically nonincreasing for .

*Proof:* See, e.g., [25].

Since no simple analytic expression for the entropy of a Poisson random variable is known, we shall resort to simple bounds. We begin with an upper bound.

*Lemma 10:* If is a mean- Poisson random variable, then its entropy is upper-bounded by

$$H(K) \le \frac{1}{2} \log 2\pi e \left( \eta + \frac{1}{12} \right). \tag{36}$$

*Proof:* See [22, Theorem 16.3.3].

In Section IV-B2 we will present a lower bound on that is valid asymptotically when the mean tends to infinity.

The following proposition is the key in the derivation of the lower bounds on channel capacity. It demonstrates that if is conditionally Poisson given a mean , then the entropy can be lower-bounded in terms of the differential entropy .

*Proposition 11:* Let be the output of a Poisson channel with input and dark current according to (1). Assume that has a finite positive expectation . Then

$$H(Y) \ge h(X) + (1 + \mathsf{E}[X]) \log \left(1 + \frac{1}{\mathsf{E}[X]}\right) - 1$$
 (37)  
>  $h(X)$ . (38)

*Proof:* A proof is given in Appendix A.

# *C. Proof of the Lower Bound (12)*

Using Lemma 10 and Proposition 11 we get

$$I(X;Y) \ge h(X) + (\mathsf{E}[X] + 1) \log \left( 1 + \frac{1}{\mathsf{E}[X]} \right) - 1$$
$$- \frac{1}{2} \log 2\pi e - \frac{1}{2} \mathsf{E}[\log X]$$
$$- \frac{1}{2} \mathsf{E} \left[ \log \left( 1 + \frac{\lambda_0 + \frac{1}{12}}{X} \right) \right]. \tag{39}$$

We choose an input distribution with the following density:

$$Q'(x) = \frac{\sqrt{\mu}}{\sqrt{A\pi x} \cdot \operatorname{erf}(\sqrt{\mu})} \cdot e^{-\frac{\mu}{A}x}, \quad 0 \le x \le A$$
 (40)

where is defined in (15) and where is chosen to achieve the average-power constraint

$$\mathsf{E}[X] = \frac{\mathsf{A}}{2\mu} - \frac{\mathsf{A}e^{-\mu}}{\sqrt{\pi\mu} \cdot \mathrm{erf}(\sqrt{\mu})} \stackrel{!}{=} \alpha \mathsf{A} \tag{41}$$

i.e., is the solution to (14). Note that the choice (40) corresponds to the distribution that maximizes (31) under the constraints (2) and (3), [22, Ch. 12]. We then have

$$h(X) = \frac{1}{2}\log\frac{\mathsf{A}}{\mu} + \log\sqrt{\pi}\mathrm{erf}(\sqrt{\mu}) + \alpha\mu + \frac{1}{2}\mathsf{E}[\log X] \tag{42}$$

and for

$$\mathsf{E}\left[\log\left(1+\frac{a}{X}\right)\right] = \int_0^\mathsf{A} \log\left(1+\frac{a}{x}\right) \cdot \frac{\sqrt{\mu}}{\sqrt{\mathsf{A}\pi x} \cdot \mathrm{erf}(\sqrt{\mu})} \cdot \underbrace{e^{-\frac{\mu}{\mathsf{A}}x}}_{\leq 1} \, \mathrm{d}x \quad (43)$$

$$\leq \int_0^A \log\left(1 + \frac{a}{x}\right) \cdot \frac{\sqrt{\mu}}{\sqrt{A\pi x} \cdot \operatorname{erf}(\sqrt{\mu})} \, \mathrm{d}x \tag{44}$$

$$= \frac{4\sqrt{\frac{a}{A}}\sqrt{\mu}\arctan\left(\sqrt{\frac{A}{a}}\right) + 2\sqrt{\mu}\log\left(1 + \frac{a}{A}\right)}{\sqrt{\pi}\cdot\operatorname{erf}(\sqrt{\mu})}.$$
 (45)

The result (12) now follows from (39) with (14), (42), and (45) where is replaced by .

## *D. Proof of the Lower Bounds (18) and (21)*

The lower bound (18) follows from (39) with the following choice of an input distribution :

$$Q'(x) \triangleq \frac{1}{\sqrt{4\mathsf{A}x}}, \quad 0 \le x \le \mathsf{A}.$$
 (46)

Note that this choice corresponds to (40) with . It is the distribution that maximizes (31) under the peak-power constraint (2) [22, Ch. 12].

We then get

$$\mathsf{E}[X] = \frac{\mathsf{A}}{3} \tag{47}$$

$$h(X) = \frac{1}{2}\log A + \frac{1}{2}\log 4 + \frac{1}{2}\mathsf{E}[\log X]$$
 (48)

$$\mathsf{E}\left[\log\left(1+\frac{a}{X}\right)\right] = \sqrt{\frac{a}{4\mathsf{A}}}(\pi+2\log 2). \tag{49}$$

Plugging this into (39) with substituted by yields the desired result.

As noted in Remark 8, (21) can be seen as limiting case of (12) for . It could also be derived analogously to (12) with the choice

$$Q'(x) \triangleq \frac{1}{\sqrt{2\pi\mathcal{E}x}} \cdot e^{-\frac{x}{2\mathcal{E}}}, \quad x \ge 0$$
 (50)

(which is the limiting PDF of (40) for ).

## IV. DERIVATION OF THE UPPER BOUNDS

#### *A. Overview*

The derivation of the upper bounds is based on the following key ideas.

• We will assume that the dark current is zero, i.e., . This is no loss in generality because any upper bound to the capacity of a Poisson channel without dark current is also an upper bound to the case with nonzero dark current. This can be seen as follows: conditional on let . Then can be written as

$$Y = Y_1 + Y_2 \tag{51}$$

where and where . Expanding mutual information twice using the chain rule we get

$$I(X; Y_1, Y) = I(X; Y_1) + I(X; Y|Y_1)$$
(52)

$$= I(X; Y_1) + I(X; Y_1 + Y_2 | Y_1)$$
 (53)

$$= I(X; Y_1) + I(X; Y_2|Y_1)$$
 (54)

$$=I(X;Y_1) \tag{55}$$

and

$$I(X; Y_1, Y) = I(X; Y) + I(X; Y_1 | Y)$$
(56)

$$\geq I(X;Y) \tag{57}$$

where the inequality follows from the nonnegativity of mutual information. Hence

$$I(X; Y_1) \ge I(X; Y_1 + Y_2)$$
 (58)

which proves our claim.

Actually, we will show that asymptotically the dark current has no impact on the capacity.

• One difficulty of the Poisson channel model (1) is that while we have a continuous input, the output is discrete. This complicates the application of the technique explained in Proposition 1 considerably. To circumvent this problem we slightly change the channel model without changing its capacity value. The idea is to add some independent continuous noise to the channel output that is uniformly distributed between and , i.e.,

$$\tilde{Y} \triangleq Y + U \tag{59}$$

where , independent of and . There is no loss in information because, given , we can always recover by applying the "floor"-operation

$$Y = \lfloor \tilde{Y} \rfloor \tag{60}$$

where for any denotes the largest integer smaller than or equal to .

- We will rely on Proposition 1 to derive an upper bound on the capacity of this new channel model with input and output , i.e., we will choose an output distribution and evaluate (9). In various places we will need to resort to further upper-bounding.
- To evaluate the expectation in (9) over the unknown capacity-achieving input distribution we will resort to the concept of *input distributions that escape to infinity* as introduced in [21] and further refined in [23]. In short, even if is unknown, this concept allows us to compute for arbitrary bounded functions in the asymptotic limit when the available power tends to infinity. The price we pay is that our upper bounds are only valid asymptotically for infinite power. For more details, see Section IV-B1.
- As mentioned before, no strictly analytic expression for the entropy of a Poisson distributed random variable is known. We will resort to an asymptotic lower bound on that is valid as tends to infinity. We then again use

the concept of *input distributions that escape to infinity* to show that if the available power tends to infinity also tends to infinity.

### *B. Mathematical Preliminaries*

In Section IV-B1 we will review the concept of *input distributions that escape to infinity* and some of its implications. Note that the stated results are general and not restricted to the case of a Poisson channel. Section IV-B2 shows how the Poisson channel model can be modified to have a continuous output.

*1) Input Distributions That Escape to Infinity:* In this subsection, we will briefly review the notion of *input distributions that escape to infinity* as introduced in [21] and further refined in [23]. Loosely speaking, a sequence of input distributions parametrized by the allowed cost is said to escape to infinity if it assigns to any fixed compact set a probability that tends to zero as the allowed cost tends to infinity.

This notion is important because we can show that for most channels of interest, the capacity-achieving input distribution must escape to infinity. In fact, not only the capacity-achieving input distributions escape to infinity: every sequence of input distributions that achieves a mutual information having the same asymptotic growth rate as capacity must escape to infinity.

The statements in this section are valid in general, i.e., they are not restricted to the Poisson channel. We will only assume that the input and output alphabets and of some channel are separable metric spaces, and that for any set the mapping from to is Borel measurable.4 We then consider a general cost function which is assumed measurable.

Recall the following definition of a capacity-cost function with an average and a peak constraint.

*Definition 12:* Given a channel over the input alphabet and the output alphabet and given some nonnegative cost function , we define the capacity-cost function by

$$C(A, \mathcal{E}) \stackrel{\triangle}{=} \sup_{Q(\cdot)} I(X; Y), \quad A, \mathcal{E} \ge \inf_{x \in \mathcal{X}} g(x)$$
 (61)

where the supremum is over all input distributions that satisfy

$$Q(\lbrace x \in \mathcal{X} : g(x) > \mathsf{A} \rbrace) = 0 \tag{62}$$

and

$$\mathsf{E}_Q[g(X)] \le \mathcal{E}. \tag{63}$$

Note that all the following results also hold in the case of only an average constraint, without limitation on the peak power. However, for brevity we will omit the explicit statements for this case.

We will now define the notion of input distributions that escape to infinity. For an intuitive understanding of the following definition and some of its consequences, it is best to focus on the example of the Poisson channel where the channel inputs

4In the case of the Poisson channel, the channel output alphabet is discrete. However, it will be shown in Section IV-B2 that this channel can be easily modified to have a continuous output without changing its basic properties.

are nonnegative real numbers and where the cost function is .

*Definition 13:* Fixing as ratio of available average to peak cost

$$\alpha \triangleq \frac{\mathcal{E}}{\Delta} \tag{64}$$

we say that a family of input distributions

$$\{Q_{\mathsf{A},\mathcal{E}}(\cdot)\}_{\mathsf{A} \ge \inf_{x} \frac{g(x)}{\alpha}, \mathcal{E} = \alpha \mathsf{A}} \tag{65}$$

on parametrized by and escapes to infinity if for any

$$\lim_{\mathsf{A} \uparrow \infty} Q_{\mathsf{A}, \alpha \mathsf{A}}(\{x \in \mathcal{X} : g(x) \le \mathsf{A}_0\}) = 0. \tag{66}$$

Based on this definition, in [23], a general theorem was presented demonstrating that if the ratio of mutual information to channel capacity is to approach one, then the input distributions must escape to infinity.

*Proposition 14:* Let the capacity–cost function be finite but unbounded. Let be a function that captures the asymptotic behavior of the capacity–cost function in the sense that

$$\lim_{A \uparrow \infty} \frac{\mathcal{C}(A, \alpha A)}{\mathcal{C}_{asv}(A)} = 1.$$
 (67)

Assume that satisfies the growth condition

$$\underline{\lim}_{\mathsf{A}\uparrow\infty} \left\{ \sup_{\mu \in (0,\mu_0]} \frac{\mu \mathcal{C}_{\mathrm{asy}}\left(\frac{\mathsf{A}}{\mu}\right)}{\mathcal{C}_{\mathrm{asy}}(\mathsf{A})} \right\} < 1, \quad \forall \ 0 < \mu_0 < 1. \tag{68}$$

Let be a family of input distributions satisfying the cost constraints (62) and (63) such that if

$$\lim_{A \uparrow \infty} \frac{I(X_A; Y)}{\mathcal{C}_{\text{asy}}(A)} = 1.$$
 (69)

Then escapes to infinity.

*Proof:* See [23, Sec. VII.C.3].

Note that in [1] it has been shown that the Poisson channel has a unique capacity-achieving input distribution. We will now show that this distribution falls into the setting of Proposition 14, i.e., that it escapes to infinity.

*Corollary 15:* Fix the average-to-peak-power ratio

$$\alpha \stackrel{\triangle}{=} \frac{\mathcal{E}}{\mathsf{A}}.\tag{70}$$

Then, the capacity-achieving input distribution of a Poisson channel (1) with peak- and average-power constraints (2) and (3) escapes to infinity. Similarly, for the situation with only an average-power constraint (3), escapes to infinity.

*Proof:* To prove this statement, we will show that the function

$$C_{\text{asy}}(\mathsf{A}) = \frac{1}{2}\log\mathsf{A} \tag{71}$$

satisfies both conditions (67) and (68) of Proposition 14. The latter has already been shown in [23, Remark 9] and is therefore omitted. The former condition is more tricky. The difficulty lies in the fact that we need to derive the asymptotic behavior of the capacity at this early stage of the proof, even though precisely this asymptotic behavior is our main result of this paper. Note, however, that for the proof of this corollary it is sufficient to find the first term in the asymptotic expansion of capacity.

Nevertheless, our proof relies heavily on the lower bounds derived in Section III, on Proposition 1, and also on Lemmas 17–19 of Section IV-B2. Of course, we made sure that none of the used results relies in turn on this corollary!

The details are deferred to the very end of this paper in Appendix F.

*Remark 16:* If a family of input distributions escapes to infinity, then for every bounded function that decays to zero, i.e., that satisfies

$$f(x) = o_x(1) \tag{72}$$

we have

$$\lim_{\mathsf{A}\uparrow\infty} \mathsf{E}_{Q_{\mathsf{A},\alpha\mathsf{A}}}[f(X)] = 0. \tag{73}$$

*2) A Poisson Channel With Continuous Output:* In the following, we define an adapted Poisson channel model which has a continuous output. To this end, let be the output of a Poisson channel with input as given in (1). We define a new random variable

$$\tilde{Y} \triangleq Y + U \tag{74}$$

where is independent of and uniformly distributed between and , . Then is continuous with the probability density function5

$$\widetilde{W}(\widetilde{y} \mid x) = W(\lfloor \widetilde{y} \rfloor \mid x) = e^{-(x+\lambda_0)} \frac{(x+\lambda_0)^{\lfloor \widetilde{y} \rfloor}}{\lfloor \widetilde{y} \rfloor!}, 
\widetilde{y} \ge 0, x \ge 0, \lambda_0 \ge 0.$$
(75)

The Poisson channel with continuous output is equivalent to the Poisson channel as defined in Section I. This is shown in the following lemma.

*Lemma 17:* Let the random variables and be defined as above. Then

a) 
$$I(X;Y) = I(X;Y) \tag{76}$$

b) 
$$h(\tilde{Y}|X=x) = H(Y|X=x)$$
 (77)

c) 
$$h(\tilde{Y}) = H(Y). \tag{78}$$

*Proof:* Define . The random variables

$$X \multimap Y \multimap Y \multimap Y \multimap Y' \tag{79}$$

form a Markov chain. Hence, from the data processing inequality it follows

$$I(X;Y) \ge I(X;\tilde{Y}) \ge I(X;Y'). \tag{80}$$

However, since , Part is proven.

<sup>5</sup>Slightly misusing our notation we will write to denote a PDF rather than a CDF. We believe that it simplifies the reading.

Part follows from the definition of and , respectively, and the fact that, for any

$$h(\tilde{Y}|X=x) = -\int_0^\infty \tilde{W}(\tilde{y}|x) \log \tilde{W}(\tilde{y}|x) \,\mathrm{d}\tilde{y} \tag{81}$$
$$= -\sum_{y=0}^\infty \int_y^{y+1} W(\lfloor \tilde{y} \rfloor |x) \log W(\lfloor \tilde{y} \rfloor |x) \,\mathrm{d}\tilde{y}$$

$$= -\sum_{y=0}^{\infty} W(y|x) \log W(y|x) \int_{y}^{y+1} d\tilde{y} \quad (83)$$

$$= -\sum_{y=0}^{\infty} W(y|x) \log W(y|x)$$
(84)

$$=H(Y|X=x). (85)$$

Part now follows from and .

We will next derive some more properties of the "continuous Poisson" distribution (75). Without loss of generality, in the rest of this section we will restrict ourselves to the case of .

The expected logarithm of a Poisson distributed random variable is unbounded since the random variable takes on the value zero with a nonzero probability. However, is well defined. It can be bounded as follows.

*Lemma 18:* Let be defined as above with PDF given in (75) and assume that . Fix an arbitrary . Then

$$\begin{aligned} & \mathsf{E}[\log \tilde{Y} \mid X = x] \\ & \leq \log(1+x) - \log\left(1 + \frac{1}{x}\right) + 2\log(1+\delta) \\ & + \left(\frac{1}{x} + \frac{1}{12x^2}\right) \frac{1}{\left(1 + \frac{\delta}{2}\right)^2} \left(1 + \frac{2}{\delta} + \log\frac{\delta/2}{1+\delta}\right), \\ & x \geq \frac{1}{\delta} \end{aligned} \tag{86}$$

$$\begin{aligned}
&\text{E}[\log \tilde{Y} \mid X = x] \\
&\leq \log(1+x) + \log(1+\delta) + \left(4x + \frac{1}{3}\right) \frac{1}{2x+1}, \\
&\qquad x < \frac{1}{8} \quad (87)
\end{aligned}$$

$$\begin{aligned} & \mathsf{E}[\log \tilde{Y} \mid X = x] \\ & \geq \log(1+x) - \log\left(1 + \frac{1}{x}\right) + 2\log(1-\delta) \\ & - \frac{1}{\left(\delta + \frac{1}{2x}\right)^2} \left(\frac{1}{x} + \frac{1}{12x^2}\right), \qquad x \geq \frac{1}{\delta} \end{aligned} \tag{88}$$

$$& \mathsf{E}[\log \tilde{Y} \mid X = x]$$

$$\log T | X - x |$$

$$\ge \log(1+x) - 1 - \log(1+x), \qquad x < \frac{1}{\delta}. \tag{89}$$

From this it follows that

$$\mathsf{E}[\log \tilde{Y} \,|\, X = x] = \log(1+x) + o_x(1) \tag{90}$$

where the term is bounded and tends to zero as tends to infinity.

*Proof:* A proof is given in Appendix B.

We next derive a lower bound on the entropy of a Poisson random variable of sufficiently large mean.

*Lemma 19:* Let be defined as above with PDF given in (75) and assume that . Fix an arbitrary . Then

$$h(\tilde{Y}|X=x) \ge \frac{1}{2}\log 2\pi e(1+x) + \log(1-\delta)$$

$$+ \frac{1}{2}\log \frac{x}{1+x} - \frac{1}{6x} - e^{-x}\frac{x^2}{2}\log x$$

$$- \frac{1}{2}e^{-x}\log 2\pi$$

$$- \frac{1}{\left(\delta - \frac{1}{2x}\right)^2} \left(\frac{1}{x} + \frac{1}{12x^2}\right), \quad x \ge \frac{1}{\delta}$$
 (91)

$$h(\tilde{Y}|X=x) \ge 0, \qquad x \ge 0. \tag{92}$$

Consequently

$$\underline{\lim}_{x \to \infty} \left\{ h(\tilde{Y}|X = x) - \frac{1}{2} \log x \right\} \ge \frac{1}{2} \log 2\pi e \tag{93}$$

which together with Lemma 10 and Lemma 17 Part implies

$$h(\tilde{Y}|X=x) = \frac{1}{2}\log 2\pi e(1+x) + o_x(1)$$
 (94)

where the term is bounded and tends to zero as tends to infinity.

*Proof:* A proof is given in Appendix C.

Finally, we state some other properties of .

*Lemma 20:* Let be defined as above with PDF given in (75) and assume that . Let and let be fixed (in particular, is not allowed to depend on ). Then we have the following:

$$\lim_{\mathsf{A}\uparrow\infty} \int_{\mathsf{A}(1+\delta)}^{\infty} \tilde{W}(\tilde{y}|\mathsf{A}) \, \mathrm{d}\tilde{y} = 0 \tag{95}$$

$$\lim_{\mathsf{A}\uparrow\infty} \int_{\mathsf{A}(1+\delta)}^{\infty} \tilde{W}(\tilde{y}|\mathsf{A}) \log \mathsf{A} \, \mathrm{d}\tilde{y} = 0 \tag{96}$$

$$\lim_{\mathsf{A}\uparrow\infty} \int_{\mathsf{A}(1+\delta)}^{\infty} \tilde{W}(\tilde{y}|\mathsf{A}) \log \frac{1}{\tilde{W}(\tilde{y}|\mathsf{A})} \, \mathrm{d}\tilde{y} = 0. \tag{97}$$

*Proof:* A proof is given in Appendix D.

## *C. Proof of the Upper Bound (13)*

The derivation of (13) is based on (9) with the following choice of an output distribution :

$$R'(\tilde{y}) \triangleq \begin{cases} p \cdot \frac{\tilde{y}^{\nu-1} e^{-\frac{\tilde{y}}{\beta}}}{\beta^{\nu} \gamma \left(\nu, \frac{\mathsf{A}(1+\delta)}{\beta}\right)}, & \forall \ 0 \leq \tilde{y} \leq \mathsf{A}(1+\delta) \\ (1-p) \cdot e^{-(\tilde{y}-\mathsf{A}(1+\delta))}, & \forall \ \tilde{y} > \mathsf{A}(1+\delta) \end{cases}$$
(98)

where are free parameters that will be specified later, where

$$p = p(\mathsf{A}) \triangleq \Pr[\tilde{Y} \le \mathsf{A}(1+\delta) \,|\, X = \mathsf{A}] \tag{99}$$

and where denotes the incomplete gamma function

$$\gamma(\nu,\xi) \triangleq \int_0^{\xi} e^{-t} t^{\nu-1} \, \mathrm{d}t, \quad \nu > 0.$$
 (100)

Note that

$$\frac{\tilde{y}^{\nu-1}e^{-\frac{\tilde{y}}{\beta}}}{\beta^{\nu}\gamma\left(\nu,\frac{\mathsf{A}(1+\delta)}{\beta}\right)}\tag{101}$$

is the PDF on that maximizes differential entropy under the constraints that and are constant. The choice of an exponential distribution on is motivated by simplicity. It will turn out that asymptotically this "tail" of our output distribution has no influence on the result.

With this choice we get

$$-\int_{0}^{\infty} \tilde{W}(\tilde{y}|x) \log R'(\tilde{y}) d\tilde{y}$$

$$= \underbrace{-\log p \cdot \Pr[\tilde{Y} \leq \mathsf{A}(1+\delta) \mid X = x]}_{c_{a}}$$

$$-\int_{0}^{\mathsf{A}(1+\delta)} \tilde{W}(\tilde{y}|x) \log \frac{\tilde{y}^{\nu-1}e^{-\frac{\tilde{y}}{\beta}}}{\beta^{\nu}\gamma\left(\nu, \frac{\mathsf{A}(1+\delta)}{\beta}\right)} d\tilde{y}$$

$$\underbrace{-\log(1-p) \cdot \Pr[\tilde{Y} > \mathsf{A}(1+\delta) \mid X = x]}_{c_{c}}$$

$$+\int_{\mathsf{A}(1+\delta)}^{\infty} \tilde{W}(\tilde{y}|x)(\tilde{y} - \mathsf{A}(1+\delta)) d\tilde{y}. \tag{102}$$

We will now consider each term individually. We start with a simple bound on

$$c_{\mathbf{a}} = \underbrace{\Pr[\tilde{Y} \le \mathsf{A}(1+\delta) \mid X = x]}_{\le 1} \underbrace{\log \frac{1}{p}}_{\ge 0} \le \log \frac{1}{p}. \tag{103}$$

Next, we bound as follows:

$$c_{b} = \int_{0}^{A(1+\delta)} \tilde{W}(\tilde{y}|x) \log \frac{\beta^{\nu} \gamma \left(\nu, \frac{A(1+\delta)}{\beta}\right)}{\tilde{y}^{\nu-1} e^{-\frac{\tilde{y}}{\beta}}} d\tilde{y}$$

$$= \left(\nu \log \beta + \log \gamma \left(\nu, \frac{A(1+\delta)}{\beta}\right)\right)$$

$$\cdot \Pr[\tilde{Y} \leq A(1+\delta) \mid X = x]$$

$$+ (1-\nu) \left(\mathbb{E}[\log \tilde{Y} \mid X = x]\right)$$

$$- \underbrace{\int_{A(1+\delta)}^{\infty} \tilde{W}(\tilde{y}|x) \log \tilde{y} d\tilde{y}}_{\geq 0 \text{ for } A > 1}\right)$$

$$+ \frac{1}{\beta} \left(\mathbb{E}[\tilde{Y} \mid X = x] - \underbrace{\int_{A(1+\delta)}^{\infty} \tilde{y} \tilde{W}(\tilde{y}|x) d\tilde{y}}_{\geq 0}\right)$$

$$= \underbrace{\left(A(1+\delta)\right)}_{\geq 0}$$

$$(A(1+\delta))$$

$$\cdot \Pr[\tilde{Y} \le \mathsf{A}(1+\delta) \,|\, X = x]$$

$$+ (1-\nu)\mathsf{E}[\log \tilde{Y} \,|\, X = x] + \frac{1}{\beta} \left( x + \frac{1}{2} \right)$$

$$(106)$$

where for the inequality (104) we have assumed that and , and where we have used that .

For we use the monotonicity of the Poisson distribution (Lemma 9) and the peak-power constraint to get

$$c_{\rm c} = \Pr[\tilde{Y} > \mathsf{A}(1+\delta) \,|\, X = x] \log \frac{1}{1-p}$$
 (107)

$$\leq \Pr[\tilde{Y} > \mathsf{A}(1+\delta) \,|\, X = \mathsf{A}] \log \frac{1}{1-n} \tag{108}$$

$$= (1 - p)\log\frac{1}{1 - p} \tag{109}$$

where the last equality follows from (99).

Finally, we bound as follows:

$$\begin{aligned}
\mathbf{r}_{d} &= \int_{\mathsf{A}(1+\delta)}^{\infty} \tilde{y} \tilde{W}(\tilde{y}|x) \, \mathrm{d}\tilde{y} - \mathsf{A}(1+\delta) \int_{\mathsf{A}(1+\delta)}^{\infty} \tilde{W}(\tilde{y}|x) \, \mathrm{d}\tilde{y} \\
&\leq \int_{\lfloor \mathsf{A}(1+\delta) \rfloor}^{\infty} \tilde{y} \tilde{W}(\tilde{y}|x) \, \mathrm{d}\tilde{y} - \mathsf{A}(1+\delta) \int_{\mathsf{A}(1+\delta)}^{\infty} \tilde{W}(\tilde{y}|x) \, \mathrm{d}\tilde{y} \\
&= \sum_{y=\lfloor \mathsf{A}(1+\delta) \rfloor}^{\infty} \left(y + \frac{1}{2}\right) e^{-x} \frac{1}{y!} x^{y} \\
&- \underbrace{\mathsf{A}(1+\delta) \mathrm{Pr}[\tilde{Y} > \mathsf{A}(1+\delta) \, | \, X = x]}_{>0}
\end{aligned} \tag{112}$$

$$\leq \sum_{y=\lfloor \mathsf{A}(1+\delta)\rfloor}^{\infty} y e^{-x} \frac{1}{y!} x^y + \frac{1}{2} \Pr[Y > \lfloor \mathsf{A}(1+\delta)\rfloor \mid X = x]$$
(113)

$$= x \sum_{y=\lfloor \mathsf{A}(1+\delta)\rfloor}^{\infty} e^{-x} \frac{1}{(y-1)!} x^{y-1}$$

$$+ \frac{1}{2} \Pr[Y > \lfloor \mathsf{A}(1+\delta)\rfloor \mid X = x]$$

$$= x \sum_{y=\lfloor \mathsf{A}(1+\delta)\rfloor}^{\infty} e^{-x} \frac{1}{y!} x^{y}$$
(114)

$$+ \frac{1}{2} \Pr[Y > \lfloor \mathsf{A}(1+\delta) \rfloor \,|\, X = x]$$

$$= x \int_{-\infty}^{\infty} \tilde{W}(\tilde{y}|x) \,\mathrm{d}\tilde{y}$$
(115)

$$+\frac{1}{2}\Pr[\tilde{Y} > \lfloor \mathsf{A}(1+\delta)\rfloor \,|\, X = x] \tag{116}$$

$$= x \Pr[Y > \lfloor \mathsf{A}(1+\delta) \rfloor - 1 \mid X = x]$$

$$+ \frac{1}{2} \Pr[\tilde{Y} > \lfloor \mathsf{A}(1+\delta) \rfloor \mid X = x]$$
(117)

$$\leq \mathsf{APr}[\tilde{Y} > \mathsf{A}(1+\delta_2) \,|\, X=x]$$

$$+\frac{1}{2}\Pr[\tilde{Y} > \mathsf{A}(1+\delta_2) \,|\, X=x]$$
 (118)

$$\leq \left(\mathsf{A} + \frac{1}{2}\right) \Pr[\tilde{Y} > \mathsf{A}(1 + \delta_2) \,|\, X = \mathsf{A}] \tag{119}$$

$$\leq \left(\mathsf{A} + \frac{1}{2}\right) \mathsf{E}\left[e^{r\tilde{Y}} \mid X = \mathsf{A}\right] e^{-r\mathsf{A}(1+\delta_2)}. \tag{120}$$

Here in (118) we have chosen an arbitrary , assuming that is large enough such that

$$A(1+\delta_2) < \lfloor A(1+\delta) \rfloor - 1 < \lfloor A(1+\delta) \rfloor. \tag{121}$$

Equation (119) follows again from monotonicity of the Poisson distribution; and the final inequality (120) follows from Chernov's bound [26]

$$\Pr[V \ge a] \le \mathsf{E}[e^{rV}]e^{-ra}, \quad \forall r > 0, \ \forall a \ge \mathsf{E}[V]. \quad (122)$$

Next, we upper-bound the moment-generating function of

$$\mathsf{E}\big[e^{r\tilde{Y}} \,\big|\, X = \mathsf{A}\big] = \int_0^\infty e^{r\tilde{y}} \tilde{W}(\tilde{y}|\mathsf{A}) \,\mathrm{d}\tilde{y} \tag{123}$$

$$\leq \sum_{y=0}^{\infty} e^{r(y+1)} e^{-A} \frac{1}{y!} A^y$$
 (124)

$$=e^{r-A+Ae^r} (125)$$

and choose . This yields

$$c_{\rm d} \le \left( \mathsf{A} + \frac{1}{2} \right) (1 + \delta_2) e^{-\mathsf{A} \left( (1 + \delta_2) \log(1 + \delta_2) - \delta_2 \right)}.$$
 (126)

Note that for , i.e.,

$$\left(A + \frac{1}{2}\right) (1 + \delta_2) e^{-A\left((1+\delta_2)\log(1+\delta_2) - \delta_2\right)} = o_A(1). \quad (127)$$

Plugging all these bounds together with (102) into (9) yields

$$C \leq \mathsf{E}_{Q^*} \left[ -h(\tilde{Y} \mid X = x) + \log \frac{1}{p} \right.$$

$$\left. + \left( \nu \log \beta + \log \gamma \left( \nu, \frac{\mathsf{A}(1+\delta)}{\beta} \right) \right) \right.$$

$$\cdot \Pr[\tilde{Y} \leq \mathsf{A}(1+\delta) \mid X = x]$$

$$\left. + (1-\nu)\mathsf{E}[\log \tilde{Y} \mid X = x] + \frac{1}{\beta} \left( X + \frac{1}{2} \right) \right.$$

$$\left. + (1-p)\log \frac{1}{1-p} \right.$$

$$\left. + \left( \mathsf{A} + \frac{1}{2} \right) (1+\delta_2)e^{-\mathsf{A}\left((1+\delta_2)\log(1+\delta_2) - \delta_2\right)} \right].$$
(128)

Next, we introduce

$$\tilde{p}(\mathsf{A}) \triangleq \mathsf{E}_{Q^*}[\Pr[\tilde{Y} \le \mathsf{A}(1+\delta) \,|\, X = x]]$$
 (129)

and we choose

$$\beta \triangleq \frac{\mathsf{A}(1+\delta)}{\mu} \tag{130}$$

where is the solution to (14). Note that such a solution always exists, is unique, and is nonnegative as long as .

Then, using (90) from Lemma 18 and (94) from Lemma 19 we get

$$C \leq -\frac{1}{2}\log 2\pi e - \frac{1}{2}\mathsf{E}_{Q^*}[\log(1+X)] + \log\frac{1}{p(\mathsf{A})} + \underbrace{\left(\nu\log\frac{\mathsf{A}(1+\delta)}{\mu} + \log\gamma(\nu,\mu)\right)}_{\geq 0 \text{ if A is large enough}} \tilde{p}(\mathsf{A}) + \underbrace{\left(\nu\log\frac{\mathsf{A}(1+\delta)}{\mu} + \log\gamma(\nu,\mu)\right)}_{\geq 0 \text{ if A is large enough}} \tilde{p}(\mathsf{A}) + (1-\nu)\mathsf{E}_{Q^*}[\log(1+X)] + \frac{\mu}{\mathsf{A}(1+\delta)} \left(\mathcal{E} + \frac{1}{2}\right) + (1-p(\mathsf{A}))\log\frac{1}{1-p(\mathsf{A})} + \underbrace{\left(\mathsf{A} + \frac{1}{2}\right)(1+\delta_2)e^{-\mathsf{A}\left((1+\delta_2)\log(1+\delta_2)-\delta_2\right)}_{=o_{\mathsf{A}}(1)} + \underbrace{\mathsf{E}_{Q^*}[o_X(1)]}_{=o_{\mathsf{A}}(1)} + \underbrace{\mathsf{E}_{Q^*}[o_X(1)]}_{=o_{\mathsf{A}}(1)} + \underbrace{\mathsf{E}_{Q^*}[o_X(1)]}_{=o_{\mathsf{A}}(1+\delta)} + \underbrace{\mathsf{E}_{Q^*}[\log(1+X)]}_{+o_{\mathsf{A}}(1+\delta)} + \underbrace{\mathsf{E}_{Q^*}[o_X(1)]}_{+o_{\mathsf{A}}(1)+\mathsf{E}_{Q^*}[o_X(1)]} + \underbrace{\mathsf{E}_{Q^*}[o_X(1)]}_{+o_{\mathsf{A}}(1)+\mathsf{E}_{Q^*}[o_X(1)]} + \underbrace{\mathsf{E}_{Q^*}[o_X(1)]}_{+o_{\mathsf{A}}(1+\delta)} + \underbrace{\mathsf{E}_{Q^*}[o_X(1)]}_{+o_{\mathsf{A}}(1+\delta)} + \underbrace{\mathsf{E}_{Q^*}[o_X(1)]}_{+o_{\mathsf{A}}(1+\delta)} + \underbrace{\mathsf{E}_{Q^*}[o_X(1)]}_{+o_{\mathsf{A}}(1)+\mathsf{E}_{Q^*}[o_X(1)]}.$$

$$(133)$$

Here, in (132) we upper-bound assuming that is large enough so that the terms in the brackets are larger than zero. In (133) we choose , use the relation

$$\gamma\left(\frac{1}{2},\mu\right) = \sqrt{\pi} \operatorname{erf}(\sqrt{\mu})$$
 (134)

and recall that .

Finally, we recall from Lemma 20 that

$$\lim_{\mathsf{A} \uparrow = 0} p(\mathsf{A}) = 1 \tag{135}$$

and therefore

$$\lim_{A \uparrow \infty} (1 - p(A)) \log \frac{1}{1 - p(A)} = 0.$$
 (136)

Together with (73) and (14) this yields

$$C \le \frac{1}{2} \log \mathsf{A} - \frac{1}{2} \log 2\pi e + \frac{1}{2} \log(1+\delta) - \mu$$
$$-\log\left(\frac{1}{2} - \alpha\mu\right) + \frac{\alpha\mu}{1+\delta} + o_{\mathsf{A}}(1). \tag{137}$$

Since is arbitrary, this concludes our proof.

#### D. Proof of the Upper Bounds (19) and (22)

The derivation of the asymptotic upper bound (22) could be done according to the scheme described in Section IV-C with a different choice of an output distribution  $R(\cdot)$ 

$$R'(\tilde{y}) \triangleq \frac{\tilde{y}^{\nu-1} e^{-\frac{\tilde{y}}{\beta}}}{\beta^{\nu} \Gamma(\nu)}, \quad \tilde{y} \ge 0$$
 (138)

where  $\nu, \beta > 0$ . However, because (22) can be seen as limiting case of (13) for  $\alpha \downarrow 0$  as explained in Remark 8 we omit the details of the proof.

The bound (19) could also be derived very similarly. However, there is an alternative derivation that is less general than the derivation shown in Section IV-C and implicitly demonstrates the power of the duality approach (9). We will derive (19) using this alternative approach. Details can be found in Appendix E.

#### V. CONCLUSION

New (firm) lower bounds and new (asymptotic) upper bounds on the capacity of the discrete-time Poisson channel subject to a peak-power constraint and an average-power constraint were derived. The gap between the lower bounds and the upper bounds tends to zero asymptotically as the peak-power and average-power tend to infinity with their ratio held fixed. The bounds thus yield the asymptotic expansion of channel capacity in this regime.

The derivation of the lower bounds relies on a new result that relates the differential entropy of a Poisson channel's input to the entropy of its output (see Proposition 11).

The asymptotic upper bounds were derived in two ways: in a less elegant version, we lower-bound the conditional entropy h(Y|X) in such a way that we get an expression that depends solely on the distribution of the channel output. Then we upperbound this expression by choosing the maximizing distribution. In a more powerful approach, we rely on a technique that has been introduced in [21]: we upper-bound capacity using dualitybased upper bounds on mutual information (see Proposition 1).

In both versions we additionally need to rely on another concept introduced in [21] and [23]: the notion of input distributions that escape to infinity (see Section IV-B1) that allows us to compute asymptotic expectations over the unknown capacity-achieving input distribution.

## APPENDIX A A Proof of Proposition 11

Given X = x, Y can be written as  $Y = Y_1 + Y_2$ , where  $Y_1 \sim \mathcal{P}o(x)$  and  $Y_2 \sim \mathcal{P}o(\lambda_0), Y_1 \perp \!\!\! \perp Y_2$ . But

$$H(Y) = H(Y_1 + Y_2) \tag{139}$$

$$> H(Y_1 + Y_2|Y_2)$$
 (140)

$$= H(Y_1|Y_2) (141)$$

$$=H(Y_1) \tag{142}$$

and we can restrict ourselves to the case where  $\lambda_0 = 0$ .

<sup>6</sup>The PDF (138) maximizes the entropy  $h(\bar{Y})$  under the constraints that  $E[\bar{Y}]$ and  $E[\log Y]$  are constant.

The proof is based on the data processing inequality of the relative entropy [27, Ch. 1, Lemma 3.11(ii)].

Let  $Q(\cdot)$  denote an arbitrary CDF on  $\mathbb{R}_0^+$  with a certain finite mean  $\mathsf{E}_Q[X] = \eta > 0$ . Let  $Q_{\mathsf{E}}(\cdot)$  denote the mean- $\eta$  exponential CDF on  $\mathbb{R}^+_0$ . Let  $R(\cdot)$  be the PMF of Y when Y is conditionally Poisson given X and  $X \sim Q(\cdot)$ , and let  $R_{G}(\cdot)$ be the PMF of Y when Y is conditionally Poisson given X and  $X \sim Q_{\rm E}(\cdot)$ . It is straightforward to show that  $R_{\rm G}(\cdot)$  is a mean- $\eta$  geometric PMF on  $\mathbb{Z}_0^+$ .

By the data processing theorem we obtain

$$D(Q(\cdot) || Q_{E}(\cdot)) \ge D(R(\cdot) || R_{G}(\cdot))$$
 (143)

where  $D(\cdot||\cdot)$  denotes relative entropy. The first inequality in the proposition's statement now follows by evaluating the left-hand side of (143)

$$D(Q(\cdot) || Q_{E}(\cdot)) = \int_{0}^{\infty} Q'(x) \log \frac{Q'(x)}{\frac{1}{\eta} e^{-\frac{x}{\eta}}} dx \quad (144)$$
$$= -h(X) + \log \eta + 1 \quad (145)$$

and evaluating the right-hand side of (143)

$$D(R(\cdot) || R_{G}(\cdot)) = \sum_{y=0}^{\infty} R(y) \log \frac{R(y)}{\frac{1}{1+\eta} \left(\frac{\eta}{1+\eta}\right)^{y}}$$
(146)  
=  $-H(Y) + (1+\eta) \log(1+\eta) - \eta \log \eta$ . (147)

The second inequality in the proposition's statement follows by noting that  $(1+\eta)\log(1+\eta^{-1})-1$  is monotonically decreasing in  $\eta$  and approaches zero, as  $\eta \uparrow \infty$ .

## APPENDIX B A Proof of Lemma 18

Everything in the following derivation is conditional on X =x. Recall that here we assume  $\lambda_0 = 0$ . We start with the proof of (89)

$$\begin{aligned}
& \mathsf{E}[\log \tilde{Y} \mid X = x] \\
&= \int_{0}^{\infty} \tilde{W}(\tilde{y} \mid x) \log \tilde{y} \, d\tilde{y} \\
&= \int_{0}^{1} \tilde{W}(\tilde{y} \mid x) \log \tilde{y} \, d\tilde{y} + \int_{0}^{\infty} \tilde{W}(\tilde{y} \mid x) \log \tilde{y} \, d\tilde{y} \quad (149)
\end{aligned}$$

$$= \int_{0}^{1} \underbrace{\tilde{W}(\tilde{y}|x)}_{\leq 1} \underbrace{\log \tilde{y}}_{\leq 0} \, d\tilde{y} + \underbrace{\int_{1}^{\infty} \tilde{W}(\tilde{y}|x) \log \tilde{y}}_{>0} \, d\tilde{y}$$
(149)

$$\geq \int_0^1 \log \tilde{y} \, \mathrm{d}\tilde{y} = -1. \tag{150}$$

For the derivation of (86)–(88) we let

$$Z_x \triangleq \frac{\tilde{Y}}{x} \tag{151}$$

be a nonnegative continuous random variable with density

$$f_x(z) \triangleq \frac{\mathrm{d}}{\mathrm{d}z} \Pr[Z_x \le z] = -\frac{\mathrm{d}}{\mathrm{d}z} \Pr[Z_x \ge z] = x \tilde{W}(zx|x).$$
(152)

Then from the definition of in (74) and from Lemma 9 we have

$$\mathsf{E}[Z_x] = \frac{\mathsf{E}[\tilde{Y}]}{x} = \frac{x + \frac{1}{2}}{x} = 1 + \frac{1}{2x} \tag{153}$$

$$\operatorname{Var}(Z_x) = \frac{\operatorname{Var}(\tilde{Y})}{x^2} = \frac{1}{x^2} \left( x + \frac{1}{12} \right) = \frac{1}{x} + \frac{1}{12x^2}. \quad (154)$$

Moreover, using the fact that the probability distribution of a Poisson random variable is monotonically increasing for all values below its mean (see Lemma 9), we get for

$$\Pr[Z_x \le z] = \Pr[\tilde{Y} \le zx] \tag{155}$$

$$= \int_0^{zx} \tilde{W}(\tilde{y}|x) \,\mathrm{d}\tilde{y} \tag{156}$$

$$= \int_{0}^{zx} W(\lfloor \tilde{y} \rfloor \mid x) \, \mathrm{d}\tilde{y} \tag{157}$$

$$\leq \int_{0}^{zx} W(\lfloor zx \rfloor \,|\, x) \,\mathrm{d}\tilde{y} \tag{158}$$

$$= zxW(|zx||x) \tag{159}$$

$$= zx\tilde{W}(zx|x) \tag{160}$$

$$=zf_x(z), \quad z \le 1. \tag{161}$$

Here, from Lemma 9 the inequality (158) holds as long as , i.e., . The last equality follows from (152).

We now have

$$E[\log \tilde{Y} \mid X = x]$$

$$= \log x + E[\log Z_x]$$

$$= \log x + \int_0^{1-\delta} f_x(z) \log z \, dz + \int_{1-\delta}^{1+\delta} f_x(z) \log z \, dz$$

$$+ \int_{1+\delta}^{\infty} f_x(z) \log z \, dz$$
(163)

where is arbitrary. We will now find upper and lower bounds to each of the three integrals separately.

$$0 \le -\int_0^{1-\delta} f_x(z) \log z \, \mathrm{d}z \tag{164}$$

$$= -\lim_{a \downarrow 0} \int_{a}^{1-\delta} f_x(z) \log z \, \mathrm{d}z \tag{165}$$

$$= \lim_{a \downarrow 0} \left\{ \underbrace{-\log(1-\delta)}_{>0} \underbrace{\Pr[Z_x \le 1-\delta]}_{<1} + \underbrace{\Pr[Z_x \le a] \log a}_{<0} \right\}$$

$$+ \int_{a}^{1-\delta} \Pr[Z_x \le z] \frac{1}{z} \, \mathrm{d}z$$
 (166)

$$\leq -\log(1-\delta) + \int_0^{1-\delta} \Pr[Z_x \leq z] \frac{1}{z} \, \mathrm{d}z \tag{167}$$

$$\leq -\log(1-\delta) + \int_0^{1-\delta} f_x(z) \, \mathrm{d}z \tag{168}$$

$$= -\log(1 - \delta) + \Pr[Z_x \le 1 - \delta] \tag{169}$$

$$= -\log(1 - \delta)$$

$$+\Pr\left[Z_x - \mathsf{E}[Z_x] \le 1 - \delta - 1 - \frac{1}{2x}\right]$$
 (170)

$$+\Pr\left[(Z_x - \mathsf{E}[Z_x])^2 \ge \left(-\delta - \frac{1}{2x}\right)^2\right] \tag{171}$$

$$\leq -\log(1-\delta) + \frac{1}{\left(\delta + \frac{1}{2x}\right)^2} \left(\frac{1}{x} + \frac{1}{12x^2}\right).$$
(172)

Here (166) follows from integration by parts; (168) from (161); and (172) follows from Chebyshev's inequality [26]

$$\Pr\Big[|V - \mathsf{E}[V]|^2 > \epsilon^2\Big] \le \frac{\mathsf{Var}(V)}{\epsilon^2}.\tag{173}$$

For the second integral we only use the monotonicity of

$$\int_{1-\delta}^{1+\delta} f_x(z) \log z \, dz \le \log(1+\delta) \underbrace{\int_{1-\delta}^{1+\delta} f_x(z) \, dz}_{1-\delta}$$
(174)

$$\leq \log(1+\delta) \tag{175}$$

$$\int_{1-\delta}^{1+\delta} f_x(z) \log z \, dz \ge \underbrace{\log(1-\delta)}_{\le 0} \underbrace{\int_{1-\delta}^{1+\delta} f_x(z) \, dz}_{\le 1}$$
 (176)

$$\ge \log(1 - \delta). \tag{177}$$

For the last integral term we use integration by parts, similarly to the first integral:

$$0 \le \int_{1+\delta}^{\infty} f_x(z) \log z \, \mathrm{d}z \tag{178}$$

$$= \lim_{a \uparrow \infty} \int_{1+\delta}^{a} f_x(z) \log z \, dz \tag{179}$$

$$= \lim_{a \uparrow \infty} \left\{ \underbrace{-\Pr[Z_x \ge a] \log a}_{\le 0} + \underbrace{\Pr[Z_x \ge 1 + \delta]}_{\le 1} \log(1 + \delta) \right\}$$

$$+ \int_{1+\delta}^{a} \Pr[Z_x \ge z] \frac{1}{z} \, \mathrm{d}z$$
 (180)

$$\leq \log(1+\delta) + \int_{1+\delta}^{\infty} \Pr[Z_x \geq z] \frac{1}{z} dz. \tag{181}$$

Now we distinguish between two cases. In the first case, we assume that . Then

$$1 + \delta \ge 1 + \frac{1}{2x} \tag{182}$$

and we can use Chebyshev's inequality (173)

$$\int_{1+\delta}^{\infty} \Pr[Z_x \ge z] \frac{1}{z} dz$$

$$= \int_{1+\delta}^{\infty} \Pr\left[ (Z_x - \mathsf{E}[Z_x])^2 \ge \left(z - 1 - \frac{1}{2x}\right)^2 \right] \frac{1}{z} dz$$
(183)

$$\leq \int_{1+\delta}^{\infty} \frac{1}{(z-1-\frac{1}{z})^2 z} \left(\frac{1}{x} + \frac{1}{12x^2}\right) dz \tag{184}$$

$$\leq \left(\frac{1}{x} + \frac{1}{12x^2}\right) \int_{1+\delta}^{\infty} \frac{1}{\left(z - 1 - \frac{\delta}{2}\right)^2 z} \,\mathrm{d}z \tag{185}$$

$$= \left(\frac{1}{x} + \frac{1}{12x^2}\right) \frac{1}{\left(1 + \frac{\delta}{2}\right)^2} \left(1 + \frac{2}{\delta} + \log\frac{\delta/2}{1+\delta}\right)$$
 (186)

where in (185) we use once more that .

For we need to make one additional step

$$\int_{1+\delta}^{\infty} \Pr[Z_x \ge z] \frac{1}{z} dz$$

$$= \int_{1+\delta}^{1+\frac{1}{x}} \Pr[Z_x \ge z] \frac{1}{z} dz + \int_{1+\frac{1}{x}}^{\infty} \Pr[Z_x \ge z] \frac{1}{z} dz$$

$$= \int_{1+\delta}^{1+\frac{1}{x}} \Pr[Z_x \ge z] \frac{1}{z} dz$$

$$+ \int_{1+\frac{1}{x}}^{\infty} \Pr\left[ (Z_x - \mathsf{E}[Z_x])^2 \ge \left(z - 1 - \frac{1}{2x}\right)^2 \right] \frac{1}{z} dz$$

$$\leq \int_{1+\delta}^{1+\frac{1}{x}} \frac{1}{z} dz + \left(\frac{1}{x} + \frac{1}{12x^2}\right) \frac{1}{\left(1 + \frac{1}{2x}\right)^2}$$

$$\cdot \left(1 + 2x + \log \frac{\frac{1}{2x}}{1 + \frac{1}{x}}\right) \qquad (189)$$

$$= \log\left(1 + \frac{1}{x}\right) - \log(1 + \delta)$$

$$+ \left(\frac{1}{x} + \frac{1}{12x^2}\right) \frac{4x^2}{(2x+1)^2} \left(1 + 2x + \log \frac{1}{2x+2}\right) \qquad (190)$$

$$\leq \log\left(1 + \frac{1}{x}\right) - \log(1 + \delta) + \left(4x + \frac{1}{3}\right) \frac{1}{2x+1} \qquad (191)$$

where (189) follows again from Chebyshev's inequality.

The claimed results now follow by combining the corresponding terms.

# APPENDIX C A PROOF OF LEMMA 19

Everything in the following derivation is conditional on . Recall that here we assume . The bound (92) follows from Lemma 17 Part and the fact that entropy is nonnegative. To derive (91) we write

$$h(\tilde{Y}|X=x)$$

$$= -\int_{0}^{\infty} \tilde{W}(\tilde{y}|x) \log \tilde{W}(\tilde{y}|x) d\tilde{y}$$

$$= -\int_{0}^{\infty} \tilde{W}(\tilde{y}|x) \log \left(e^{-x} \frac{1}{\lfloor \tilde{y} \rfloor!} x^{\lfloor \tilde{y} \rfloor}\right) d\tilde{y}$$

$$= x - \mathsf{E}[\lfloor \tilde{Y} \rfloor \mid X = x] \log x$$

$$+ \int_{0}^{\infty} \tilde{W}(\tilde{y}|x) \log(\lfloor \tilde{y} \rfloor!) d\tilde{y}$$

$$= x - \mathsf{E}[Y \mid X = x] \log x$$

$$+ \int_{1}^{\infty} \tilde{W}(\tilde{y}|x) \log(\lfloor \tilde{y} \rfloor!) d\tilde{y}$$

$$= x - \mathsf{E}[Y \mid X = x] \log x$$

$$+ \int_{1}^{\infty} \tilde{W}(\tilde{y}|x) \log(\lfloor \tilde{y} \rfloor!) d\tilde{y}$$

$$(195)$$

$$= x - x \log x + \sum_{y=1}^{\infty} W(y|x) \log(y!)$$
 (196)

where in (195) we use that . Using Stirling's bound [28], [29]

$$\sqrt{2\pi n} \left(\frac{n}{e}\right)^n e^{\frac{1}{12n+1}} \le n! \le \sqrt{2\pi n} \left(\frac{n}{e}\right)^n e^{\frac{1}{12n}} \tag{197}$$

and the Taylor expansion of around

$$y \log y = x \log x + (1 + \log x)(y - x) + \frac{1}{2x}(y - x)^{2}$$

$$- \frac{1}{6x^{2}}(y - x)^{3} + \underbrace{\frac{1}{12(x + \theta(y - x))^{3}}(y - x)^{4}}_{\geq 0}$$

$$\geq x \log x + (1 + \log x)(y - x) + \frac{1}{2x}(y - x)^{2}$$

$$- \frac{1}{6x^{2}}(y - x)^{3}$$
(199)

(where 
$$0 < \theta < 1$$
), we get 
$$h(\tilde{Y}|X = x)$$

$$\geq x - x \log x$$

$$+ \sum_{y=1}^{\infty} W(y|x) \left(\frac{1}{2} \log 2\pi y + y \log y - y + \underbrace{\frac{1}{12y+1}}_{\geq 0}\right)$$

$$(200)$$

$$\geq -x \log x + \frac{1}{2} (1 - e^{-x}) \log 2\pi + \frac{1}{2} \sum_{y=1}^{\infty} W(y|x) \log y$$

$$+ \sum_{y=0}^{\infty} W(y|x) y \log y$$

$$(201)$$

$$\geq -x \log x + \frac{1}{2} (1 - e^{-x}) \log 2\pi + \frac{1}{2} \sum_{y=2}^{\infty} W(y|x) \log y$$

$$+ \sum_{y=0}^{\infty} W(y|x) \left(x \log x + (1 + \log x)(y - x) + \frac{1}{2x} (y - x)^2 - \frac{1}{6x^2} (y - x)^3\right)$$

$$= \frac{1}{2} \log 2\pi + \frac{1}{2} - \frac{1}{6x} + \frac{1}{2} \sum_{y=2}^{\infty} W(y|x) \log y$$

$$- \frac{1}{2} e^{-x} \log 2\pi.$$

$$(203)$$

Here, (200) follows from the lower bound in (197); in (201) we use the mean of a Poisson distribution, however, noting that the summation starts at instead of ; then in (202) we insert (199); and in the final step (203) we again use Lemma 9.

In order to evaluate the remaining sum in (203) we introduce as shown in (151)–(161) in Appendix B.

$$\sum_{y=2}^{\infty} W(y|x) \log y$$

$$\geq \int_{2}^{\infty} \tilde{W}(\tilde{y}|x) \log(\tilde{y} - 1) \, d\tilde{y}$$

$$= \int_{1}^{\infty} \tilde{W}(\tilde{y} + 1|x) \log \tilde{y} \, d\tilde{y}$$
(204)

(206)

$$= \int_{\frac{1}{2}}^{\infty} f_x \left( z + \frac{1}{x} \right) (\log x + \log z) dz \tag{207}$$

$$= \Pr\left[Z_x \ge \frac{2}{x}\right] \log x + \int_{\frac{1}{x}}^{\infty} f_x \left(z + \frac{1}{x}\right) \log z \, dz$$
 (208)  

$$= \Pr\left[Z_x \ge \frac{2}{x}\right] \log x + \int_{\frac{1}{x}}^{1-\delta} f_x \left(z + \frac{1}{x}\right) \log z \, dz$$
  

$$+ \int_{1-\delta}^{1+\delta} f_x \left(z + \frac{1}{x}\right) \log z \, dz$$
  

$$+ \int_{1+\delta}^{\infty} f_x \left(z + \frac{1}{x}\right) \log z \, dz$$
 (209)

where we introduce an arbitrary and assume that .

We will now find bounds for each integral separately, similarly to the derivation in Appendix B. We again start with integration by parts

$$-\int_{\frac{1}{x}}^{1-\delta} f_x \left(z + \frac{1}{x}\right) \log z \, dz$$

$$= \underbrace{-\log(1-\delta)}_{\geq 0} \Pr\left[Z_x \le 1 - \delta + \frac{1}{x}\right]$$

$$+ \underbrace{\Pr\left[Z_x \le \frac{2}{x}\right] \log \frac{1}{x}}_{\leq 0 \text{ because } x \ge \frac{1}{\delta} > 2} \Pr\left[Z_x \le z + \frac{1}{x}\right] \frac{1}{z} \, dz$$

$$\leq -\log(1-\delta) + \int_{\frac{1}{x}}^{1-\delta} f_x \left(z + \frac{1}{x}\right) \frac{z + \frac{1}{x}}{z} dz$$
 (211)  
$$\leq -\log(1-\delta) + \frac{\frac{1}{x} + \frac{1}{x}}{1} \int_{-\infty}^{1-\delta} f_x \left(z + \frac{1}{x}\right) dz$$
 (212)

$$= -\log(1 - \delta) + 2\Pr\left[Z_x \le 1 - \delta + \frac{1}{x}\right]$$

$$-2\Pr\left[Z_x \le \frac{2}{x}\right]$$

$$>0$$
(213)

$$\leq -\log(1-\delta)$$

$$+2\Pr\left[Z_x - \mathsf{E}[Z_x] \leq 1 - \delta + \frac{1}{x} - 1 - \frac{1}{2x}\right] \qquad (214)$$

$$= -\log(1-\delta)$$

$$+2\Pr\left[(Z_x - \mathsf{E}[Z_x])^2 \ge \left(\delta - \frac{1}{2x}\right)^2\right] \tag{215}$$

$$\leq -\log(1-\delta) + \frac{2}{\left(\delta - \frac{1}{2x}\right)^2} \left(\frac{1}{x} + \frac{1}{12x^2}\right).$$
 (216)

Here, (211) follows from (161) using our assumption that ; (212) is due to the monotonicity in of ; in (215) we use that ; and the last inequality (216) follows from Chebyshev's inequality (173).

For the second integral we use the monotonicity of :

$$\int_{1-\delta}^{1+\delta} f_x \left( z + \frac{1}{x} \right) \log z \, dz$$

$$\geq \underbrace{\log(1-\delta)}_{\leq 0} \underbrace{\int_{1-\delta}^{1+\delta} f_x \left( z + \frac{1}{x} \right) \, dz}_{\leq 1}$$
(217)

$$\geq \log(1 - \delta). \tag{218}$$

The third integral we simply lower-bound by zero

$$\int_{1+\delta}^{\infty} f_x \left( z + \frac{1}{x} \right) \log z \, \mathrm{d}z \ge 0. \tag{219}$$

Combined this yields for

$$h(\tilde{Y}|X=x)$$

$$\geq \frac{1}{2}\log 2\pi + \frac{1}{2} - \frac{1}{6x} + \frac{1}{2}\Pr\left[Z_x \geq \frac{2}{x}\right]\log x$$

$$+ \log(1-\delta) - \frac{1}{\left(\delta - \frac{1}{2x}\right)^2} \left(\frac{1}{x} + \frac{1}{12x^2}\right)$$

$$- \frac{1}{2}e^{-x}\log 2\pi \qquad (220)$$

$$= \frac{1}{2}\log 2\pi e + \log(1-\delta) + \frac{1}{2}\log x - \frac{1}{6x}$$

$$- \frac{1}{2}\Pr\left[Z_x < \frac{2}{x}\right]\log x - \frac{1}{2}e^{-x}\log 2\pi$$

$$- \frac{1}{\left(\delta - \frac{1}{2x}\right)^2} \left(\frac{1}{x} + \frac{1}{12x^2}\right). \qquad (221)$$

We then again use (161) under the condition to show that

$$\frac{1}{2}\Pr\left[Z_x < \frac{2}{x}\right]\log x \le \frac{1}{2}\frac{2}{x}f_x\left(\frac{2}{x}\right)\log x \qquad (222)$$

$$= \frac{1}{x}x\tilde{W}(2|x)\log x \qquad (223)$$

$$=e^{-x}\frac{x^2}{2}\log x.$$
 (224)

Hence

$$h(\tilde{Y}|X=x) \ge \frac{1}{2}\log 2\pi e + \log(1-\delta) + \frac{1}{2}\log x - \frac{1}{6x}$$
$$-e^{-x}\frac{x^2}{2}\log x - \frac{1}{2}e^{-x}\log 2\pi$$
$$-\frac{1}{\left(\delta - \frac{1}{2x}\right)^2} \left(\frac{1}{x} + \frac{1}{12x^2}\right). \tag{225}$$

## APPENDIX D A PROOF OF LEMMA 20

Let . From the definition of we have for any integer

$$W(y+1|A) = e^{-A} \cdot \frac{A^{y+1}}{(y+1)!}$$
(226)

$$=e^{-\mathsf{A}} \cdot \frac{\mathsf{A}^y}{y!} \cdot \frac{\mathsf{A}}{y+1} \tag{227}$$

$$\leq e^{-\mathsf{A}} \cdot \frac{\mathsf{A}^{y}}{y!} \cdot \frac{\mathsf{A}}{\left[\mathsf{A}(1+\delta_{1})\right]+1} \tag{228}$$

$$\leq e^{-\mathsf{A}} \cdot \frac{\mathsf{A}^y}{y!} \cdot \frac{1}{1+\delta_1} \tag{229}$$

$$= W(y|\mathsf{A}) \cdot \frac{1}{1+\delta_1}, \quad y \ge \lfloor \mathsf{A}(1+\delta_1) \rfloor \tag{230}$$

where for (229) we use

$$[A(1+\delta_1)] + 1 \ge A(1+\delta_1).$$
 (231)

Therefore, knowing that , we get

$$W(y|\mathsf{A}) \le W(\lfloor \mathsf{A}(1+\delta_1)\rfloor |\mathsf{A}) \cdot \left(\frac{1}{1+\delta_1}\right)^{y-\lfloor \mathsf{A}(1+\delta_1)\rfloor}$$

$$\le \left(\frac{1}{1+\delta_1}\right)^{y-\lfloor \mathsf{A}(1+\delta_1)\rfloor}, \quad y \ge \lfloor \mathsf{A}(1+\delta_1)\rfloor.$$
(232)
$$(233)$$

Hence

$$\int_{\mathsf{A}(1+\delta)}^{\infty} \tilde{W}(\tilde{y}|\mathsf{A}) \, \mathrm{d}\tilde{y} \\
\leq \int_{\lfloor \mathsf{A}(1+\delta) \rfloor}^{\infty} \tilde{W}(\tilde{y}|\mathsf{A}) \, \mathrm{d}\tilde{y} \tag{234}$$

$$= \sum_{y=|\mathsf{A}(1+\delta)|}^{\infty} W(y|\mathsf{A}) \tag{235}$$

$$\leq \sum_{y=|\mathsf{A}(1+\delta)|}^{\infty} \left(\frac{1}{1+\delta_1}\right)^{y-\left[\mathsf{A}(1+\delta_1)\right]} \tag{236}$$

$$= \left(\frac{1}{1+\delta_1}\right)^{\lfloor A(1+\delta)\rfloor - \lfloor A(1+\delta_1)\rfloor} \sum_{y=0}^{\infty} \left(\frac{1}{1+\delta_1}\right)^y \quad (237)$$

$$= \left(\frac{1}{1+\delta_1}\right)^{\lfloor \mathsf{A}(1+\delta)\rfloor - \lfloor \mathsf{A}(1+\delta_1)\rfloor} \cdot \frac{1+\delta_1}{\delta_1} \tag{238}$$

$$\leq \left(\frac{2}{2+\delta}\right)^{\frac{A^{\frac{\delta}{2}-1}}{\delta}} \cdot \frac{2+\delta}{\delta} \tag{239}$$

where for (239) we use

$$\lfloor \mathsf{A}(1+\delta) \rfloor - \lfloor \mathsf{A}(1+\delta_1) \rfloor$$

$$\geq \mathsf{A}(1+\delta) - 1 - \mathsf{A}(1+\delta_1) \tag{240}$$

$$=A\frac{\delta}{2}-1. \tag{241}$$

Note that the left-hand sides of (95) and (96) are trivially lowerbounded by zero. Hence, (95) and (96) follow from (239).

To prove (97) we again assume

$$V(y+1|A) \log \frac{1}{W(y+1|A)}$$

$$\leq W(y|A) \frac{1}{1+\delta_1} \log \frac{1}{W(y|A) \frac{1}{1+\delta_1}}$$

$$= \frac{1}{1+\delta_1} W(y|A) \log \frac{1}{W(y|A)} + \frac{\log(1+\delta_1)}{1+\delta_1} \cdot W(y|A)$$

$$\leq \frac{1}{1+\delta_1} W(y|A) \log \frac{1}{W(y|A)}$$

$$+ \frac{\log(1+\delta_1)}{1+\delta_1} \cdot W(y|A) \log \frac{1}{W(y|A)}$$

$$= \frac{1+\log(1+\delta_1)}{1+\delta_1} \cdot W(y|A) \log \frac{1}{W(y|A)}$$

$$= \frac{1+\log(1+\delta_1)}{1+\delta_1} \cdot W(y|A) \log \frac{1}{W(y|A)}$$

$$= \frac{1+\log(1+\delta_1)}{1+\delta_1} \cdot W(y|A) \log \frac{1}{W(y|A)}$$
(244)

Here, (242) can be argued as follows: for , the function is monotonically increasing. For large (as a matter of fact is already sufficiently large), is small enough such that is monotonically increasing. Therefore, we can use (230). Inequality (244) follows because for large (again is sufficiently large) we have . Hence

$$W(y|\mathsf{A})\log\frac{1}{W(y|\mathsf{A})} \le W(\lfloor\mathsf{A}(1+\delta_1)\rfloor|\mathsf{A})\log\frac{1}{W(\lfloor\mathsf{A}(1+\delta_1)\rfloor|\mathsf{A})} \cdot \left(\frac{1+\log(1+\delta_1)}{1+\delta_1}\right)^{y-\lfloor\mathsf{A}(1+\delta_1)\rfloor}$$

$$\le \left(\frac{1+\log(1+\delta_1)}{1+\delta_1}\right)^{y-\lfloor\mathsf{A}(1+\delta_1)\rfloor} ,$$

$$y \ge \lfloor\mathsf{A}(1+\delta_1)\rfloor.$$
 (247)

Therefore, (97) can be derived as follows:

$$\int_{\mathsf{A}(1+\delta)}^{\infty} \tilde{W}(\tilde{y}|\mathsf{A}) \log \frac{1}{\tilde{W}(\tilde{y}|\mathsf{A})} \, \mathrm{d}\tilde{y}$$

$$\leq \int_{\lfloor \mathsf{A}(1+\delta) \rfloor}^{\infty} \tilde{W}(\tilde{y}|\mathsf{A}) \log \frac{1}{\tilde{W}(\tilde{y}|\mathsf{A})} \, \mathrm{d}\tilde{y} \tag{248}$$

$$= \sum_{y=\lfloor \mathsf{A}(1+\delta)\rfloor}^{\infty} W(y|\mathsf{A}) \log \frac{1}{W(y|\mathsf{A})}$$
 (249)

$$\leq \sum_{y=|\mathsf{A}(1+\delta)|}^{\infty} \left( \frac{1 + \log(1+\delta_1)}{1+\delta_1} \right)^{y-\left\lfloor \mathsf{A}(1+\delta_1) \right\rfloor} \tag{250}$$

$$= \sum_{u=0}^{\infty} \left( \frac{1 + \log(1 + \delta_1)}{1 + \delta_1} \right)^{y + \lfloor \mathsf{A}(1 + \delta) \rfloor - \lfloor \mathsf{A}(1 + \delta_1) \rfloor} (251)$$

$$= \frac{1 + \delta_1}{\delta_1 - \log(1 + \delta_1)} \cdot \left(\frac{1 + \log(1 + \delta_1)}{1 + \delta_1}\right)^{\lfloor A(1+\delta) \rfloor - \lfloor A(1+\delta_1) \rfloor}$$
(252)

$$\leq \frac{1+\delta_1}{\delta_1 - \log(1+\delta_1)} \left( \frac{1+\log(1+\delta_1)}{1+\delta_1} \right)^{A\frac{\delta}{2}-1}. (253)$$

Here for (253) we have again used (241). Note that the left-hand side of (97) is trivially lower-bounded by zero since . Hence, (97) follows from (253).

# APPENDIX E PROOF OF THE UPPER BOUND (19)

To derive (19) we first note that the capacity of a channel with an imposed peak- and average-power constraint is upperbounded by the capacity of the same channel with a peak-power constraint only. Hence, any upper bound on the capacity for the case is implicitly an upper bound on the capacity for all , i.e., we will derive an upper bound for the case only.

(245)

The derivation of this upper bound could be done according to the scheme in Section IV-C with a choice of an output distribution with PDF

$$R'(\tilde{y}) \triangleq \begin{cases} p \cdot \frac{\beta \cdot \tilde{y}^{\beta-1}}{(\mathsf{A}(1+\delta))^{\beta}}, & \forall \ 0 \le \tilde{y} \le \mathsf{A}(1+\delta) \\ (1-p) \cdot e^{-(\tilde{y}-\mathsf{A}(1+\delta))}, & \forall \ \tilde{y} > \mathsf{A}(1+\delta) \end{cases}$$
(254)

where , and

$$p = p(A) \stackrel{\triangle}{=} \Pr[\tilde{Y} \le A(1+\delta)|X=A].$$
 (255)

However, we will show a different approach here that does not rely on the duality-based technique of Proposition 1. This approach is more cumbersome and less general, but clearly illustrates the elegance and power of the duality approach.

The new approach uses the trick to "transfer" the problem of computing the mutual information between input and output of the channel to a problem that depends only on the distribution of the channel output. More specifically, we will lower-bound by an expression containing such that the mutual information is upper-bounded by an expression that contains

$$h(\tilde{Y}) - \frac{1}{2} \mathsf{E}[\log \tilde{Y}] \tag{256}$$

and does not directly depend on . We can then find a valid upper bound by maximizing this expression over all allowed output distributions. Unfortunately, this maximum is unbounded as we do not have a peak-power constraint on the *output*. Hence, we additionally need to "transfer" the peak-power constraint to the output side, i.e., we need to show that the contribution of the terms for are asymptotically negligible. As a matter of fact, we will only be able to show that the terms for are negligible for an arbitrary .

Interestingly, the PDF that will achieve the maximum in (256) is (almost) our choice of (254). Therefore, the derivations of both approaches are very similar in many aspects. The main difference—and also the reason why this alternative derivation is much less powerful—is that in this alternative derivation we have to *transfer* the problem to the output side (including the peak-power constraint!) and then *prove* that our choice of is entropy-maximizing. This is in stark contrast to the approach of Section IV-C, where we may simply specify without any justification. In the case of only a peak-power constraint such a justification is possible; in the more complicated scenario of both a peak- and an average-power constraint such a proof may be very difficult.

We will now show the details. Again assume . Using Lemma 17 Part as well as Lemmas 18 and 19 we get

$$I(X;Y) = h(\tilde{Y}) - \mathsf{E}_{Q} \left[ \frac{1}{2} \log(1+X) + \frac{1}{2} \log 2\pi e + o_{X}(1) \right] (257)$$

$$= h(\tilde{Y}) - \mathsf{E}_{Q} \left[ \frac{1}{2} \mathsf{E}[\log \tilde{Y} \mid X = x] - o_{X}(1) \right]$$

$$- \frac{1}{2} \log 2\pi e + \mathsf{E}_{Q}[o_{X}(1)]$$
(258)

$$=h(\tilde{Y}) - \frac{1}{2} \operatorname{E}[\log \tilde{Y}] - \frac{1}{2} \log 2\pi e + \operatorname{E}_{Q}[o_{X}(1)]$$

$$\leq \int_{0}^{\mathsf{A}(1+\delta)} p_{\tilde{Y}}(\tilde{y}) \log \frac{1}{p_{\tilde{Y}}(\tilde{y})} \, \mathrm{d}\tilde{y}$$

$$+ \int_{\mathsf{A}(1+\delta)}^{\infty} p_{\tilde{Y}}(\tilde{y}) \log \frac{1}{p_{\tilde{Y}}(\tilde{y})} \, \mathrm{d}\tilde{y}$$

$$- \frac{1}{2} \int_{0}^{\mathsf{A}(1+\delta)} p_{\tilde{Y}}(\tilde{y}) \log \tilde{y} \, \mathrm{d}\tilde{y} - \frac{1}{2} \log 2\pi e$$

$$+ \operatorname{E}_{Q}[o_{X}(1)]$$

$$(259)$$

where (260) follows because for large

$$\int_{\mathsf{A}(1+\delta)}^{\infty} p_{\tilde{Y}}(\tilde{y}) \log \tilde{y} \, \mathrm{d}\tilde{y} \ge 0. \tag{261}$$

In order to prove that is small we note that for the output distribution can be bounded as follows:

$$p_{\tilde{Y}}(\tilde{y}) = \int_0^{\mathsf{A}} Q(x) \tilde{W}(\tilde{y}|x) \, \mathrm{d}x \tag{262}$$

$$\leq \max_{0 < x < \mathsf{A}} \tilde{W}(\tilde{y}|x) \tag{263}$$

$$= \tilde{W}(\tilde{y}|\mathsf{A}), \qquad \tilde{y} > \mathsf{A}(1+\delta). \tag{264}$$

Since is small for large , we can use the monotonicity of for small to bound

$$\int_{\mathsf{A}(1+\delta)}^{\infty} p_{\tilde{Y}}(\tilde{y}) \log \frac{1}{p_{\tilde{Y}}(\tilde{y})} \, \mathrm{d}\tilde{y}$$

$$\leq \int_{\mathsf{A}(1+\delta)}^{\infty} \tilde{W}(\tilde{y}|\mathsf{A}) \log \frac{1}{\tilde{W}(\tilde{y}|\mathsf{A})} \, \mathrm{d}\tilde{y}$$

$$= o_{\mathsf{A}}(1) \tag{266}$$

where (266) follows from (97).

Let

$$\tilde{p} = \tilde{p}(A) \triangleq \Pr[\tilde{Y} \le A(1+\delta)]$$
 (267)

where as . Let further

$$\hat{p}_{\tilde{Y}}(\tilde{y}) \triangleq \begin{cases} \frac{1}{\tilde{p}} p_{\tilde{Y}}(\tilde{y}), & \text{for } 0 \leq \tilde{y} \leq \mathsf{A}(1+\delta) \\ 0, & \text{otherwise.} \end{cases}$$
 (268)

Note that is a probability density, i.e., it is nonnegative and integrates to one. Hence

$$\leq \int_{0}^{\mathsf{A}(1+\delta)} \tilde{p} \cdot \hat{p}_{\tilde{Y}}(\tilde{y}) \log \frac{1}{\tilde{p} \cdot \hat{p}_{\tilde{Y}}(\tilde{y})} \, \mathrm{d}\tilde{y} - \frac{1}{2} \log 2\pi e$$

$$- \frac{1}{2} \int_{0}^{\mathsf{A}(1+\delta)} \tilde{p} \cdot \hat{p}_{\tilde{Y}}(\tilde{y}) \log \tilde{y} \, \mathrm{d}\tilde{y} + \mathsf{E}_{Q}[o_{X}(1)] + o_{\mathsf{A}}(1)$$
(269)
$$= \tilde{p} \left( \int_{0}^{\mathsf{A}(1+\delta)} \hat{p}_{\tilde{Y}}(\tilde{y}) \log \frac{1}{\hat{p}_{\tilde{Y}}(\tilde{y})} \, \mathrm{d}\tilde{y} \right)$$

$$- \frac{1}{2} \int_{0}^{\mathsf{A}(1+\delta)} \hat{p}_{\tilde{Y}}(\tilde{y}) \log \tilde{y} \, \mathrm{d}\tilde{y}$$

$$+ \tilde{p} \log \frac{1}{\tilde{p}} - \frac{1}{2} \log 2\pi e + \mathsf{E}_{Q}[o_{X}(1)] + o_{\mathsf{A}}(1)$$
(270)

Authorized licensed use limited to: Tsinghua University. Downloaded on October 25,2025 at 10:44:20 UTC from IEEE Xplore. Restrictions apply.

$$\leq \tilde{p} \cdot \sup_{\hat{p}_{\tilde{Y}} \in \tilde{\mathcal{Y}}} \left\{ \int_{0}^{\mathsf{A}(1+\delta)} \hat{p}_{\tilde{Y}}(\tilde{y}) \log \frac{1}{\hat{p}_{\tilde{Y}}(\tilde{y})} \, \mathrm{d}\tilde{y} \right. \\
\left. - \frac{1}{2} \int_{0}^{\mathsf{A}(1+\delta)} \hat{p}_{\tilde{Y}}(\tilde{y}) \log \tilde{y} \, \mathrm{d}\tilde{y} \right\} \\
+ \tilde{p} \log \frac{1}{\tilde{p}} - \frac{1}{2} \log 2\pi e + \mathsf{E}_{Q}[o_{X}(1)] + o_{\mathsf{A}}(1) \qquad (271) \\
= \tilde{p} \cdot \sup_{\eta} \left\{ \sup_{\hat{p}_{\tilde{Y}} \in \tilde{\mathcal{Y}}_{\eta}} h(\tilde{Y}) - \frac{1}{2}\eta \right\} + \tilde{p} \log \frac{1}{\tilde{p}} - \frac{1}{2} \log 2\pi e \\
+ \mathsf{E}_{Q}[o_{X}(1)] + o_{\mathsf{A}}(1) \qquad (272)$$

where denotes the set of all distributions over , and the set of all distributions over that satisfy the constraint .

The supremum over is achieved by the distributions [22, Ch. 11]

$$\hat{p}_{\tilde{Y}}^*(\tilde{y}) = \frac{\beta \cdot \tilde{y}^{\beta - 1}}{(A(1 + \delta))^{\beta}}, \quad \beta > -1$$
 (273)

with

$$\mathsf{E}_{\hat{p}_{\tilde{Y}}^*}[\log \tilde{Y}] = \log(\mathsf{A}(1+\delta)) - \frac{1}{\beta} \tag{274}$$

$$h_{\hat{p}_{\tilde{Y}}^*}(\tilde{Y}) = \log(\mathsf{A}(1+\delta)) - \log\beta + \frac{\beta-1}{\beta}.$$
 (275)

Hence

$$I(X;Y)$$

$$\leq \tilde{p} \cdot \sup_{\beta} \left\{ \frac{1}{2} \log A + \frac{1}{2} \log(1+\delta) - \log \beta + 1 - \frac{1}{2\beta} \right\}$$

$$+ \tilde{p} \log \frac{1}{\tilde{p}} - \frac{1}{2} \log 2\pi e + \mathsf{E}_{Q}[o_{X}(1)] + o_{A}(1) \qquad (276)$$

$$= \tilde{p} \left( \frac{1}{2} \log A + \frac{1}{2} \log(1+\delta) - \log \frac{1}{2} + 1 - \frac{1}{2 \cdot \frac{1}{2}} \right)$$

$$+ \tilde{p} \log \frac{1}{\tilde{p}} - \frac{1}{2} \log 2\pi e + \mathsf{E}_{Q}[o_{X}(1)] + o_{A}(1) \qquad (277)$$

$$\leq \frac{1}{2} \log A + \frac{1}{2} \log(1+\delta) + \log 2 + \tilde{p}(A) \log \frac{1}{\tilde{p}(A)}$$

$$- \frac{1}{2} \log 2\pi e + \mathsf{E}_{Q}[o_{X}(1)] + o_{A}(1) \qquad (278)$$

$$= \frac{1}{2} \log A - \frac{1}{2} \log \frac{\pi e}{2} + \frac{1}{2} \log(1+\delta) + \mathsf{E}_{Q}[o_{X}(1)]$$

$$+ o_{A}(1) \qquad (279)$$

where the supremum in (276) is achieved for , and where in (278) we have bounded .

Finally, we use (73) and Corollary 15. The result now follows since is arbitrary.

## APPENDIX F A PROOF OF COROLLARY 15

To prove the claim of this corollary we rely on Proposition 14, i.e., we need to derive a function that satisfies (67) and (68).

From the lower bounds in Theorems 3, 4, and 7 (which are proven in Section III) we know that

$$\underline{\lim_{\mathsf{A}\uparrow\infty}} \frac{\mathcal{C}(\mathsf{A}, \alpha\mathsf{A})}{\frac{1}{2}\log\mathsf{A}} \ge 1 \tag{280}$$

and

$$\underline{\lim_{\mathcal{E}\uparrow\infty}} \frac{\mathcal{C}(\mathcal{E})}{\frac{1}{2}\log\mathcal{E}} \ge 1 \tag{281}$$

respectively.

We next derive upper bounds on the channel capacity. Note that

$$C(A, \alpha A) \le C_{PP}(A) \le C_{avg}(A)$$
 (282)

where and denote the capacity under a peakpower and average-power constraint, respectively. Hence, it will be sufficient to show an upper bound for the average-power constraint case only. Moreover, as shown in (58), we can further upper-bound capacity by assuming .

Our derivation is based on Lemma 17 Part and on (9) with the choice of an output distribution on having the following density:

$$R'(\tilde{y}) \triangleq \frac{e^{-\frac{\tilde{y}}{\mathcal{E}}}}{\sqrt{\pi \tilde{y} \mathcal{E}}}, \quad \tilde{y} \ge 0.$$
 (283)

For we get

$$D(\tilde{W}(\cdot|x)||R(\cdot))$$

$$= -h(\tilde{Y}|X=x) + \frac{1}{2}\mathsf{E}[\log \tilde{Y}|X=x]$$

$$+ \frac{1}{2}\log \mathcal{E} + \frac{1}{2}\log \pi + \frac{1}{\mathcal{E}}\mathsf{E}[\tilde{Y}|X=x] \qquad (284)$$

$$= -h(\tilde{Y}|X=x) + \frac{1}{2}\mathsf{E}[\log \tilde{Y}|X=x]$$

$$+ \frac{1}{2}\log \mathcal{E} + \frac{1}{2}\log \pi + \frac{x}{\mathcal{E}} + \frac{1}{2\mathcal{E}} \qquad (285)$$

where we use that (the additional term follows from (74)). We fix an arbitrary and continue by a case distinction. For we use the bounds (86) and (91) to get

$$\begin{split} & \mathcal{O}(\tilde{W}(\cdot|x)||R(\cdot)) \\ & \leq -\frac{1}{2}\log 2\pi e - \log(1-\delta) - \frac{1}{2}\log x + \frac{1}{6x} \\ & + e^{-x}\frac{x^2}{2}\log x + \frac{1}{2}e^{-x}\log 2\pi \\ & + \frac{1}{\left(\delta - \frac{1}{2x}\right)^2} \left(\frac{1}{x} + \frac{1}{12x^2}\right) + \frac{1}{2}\log x + \log(1+\delta) \\ & + \frac{1}{2}\left(\frac{1}{x} + \frac{1}{12x^2}\right) \frac{1}{\left(1 + \frac{\delta}{2}\right)^2} \left(1 + \frac{2}{\delta} + \log\frac{\delta/2}{1+\delta}\right) \\ & + \frac{1}{2}\log \mathcal{E} + \frac{1}{2}\log \pi + \frac{x}{\mathcal{E}} + \frac{1}{2\mathcal{E}} \\ & \leq -\frac{1}{2} - \log(1-\delta) + \frac{\delta}{6} + 1 + \frac{4}{\delta^2}\left(\delta + \frac{\delta^2}{12}\right) \\ & + \frac{1}{2}\left(\delta + \frac{\delta^2}{12}\right) \frac{1}{\left(1 + \frac{\delta}{2}\right)^2} \left(1 + \frac{2}{\delta} + \log\frac{\delta/2}{1+\delta}\right) \\ & + \frac{1}{2}\log \mathcal{E} + \frac{1}{2}\log \pi + \frac{x}{\mathcal{E}} + \frac{1}{2\mathcal{E}} + \log(1+\delta) \end{split} \tag{287}$$

$$= \frac{1}{2}\log\mathcal{E} + \frac{x}{\mathcal{E}} + \frac{1}{2\mathcal{E}} + O(1) \tag{288}$$

where in (287) we use and , and where we use in various places that . Here denotes some finite terms that only depend on , but not on or .

For we use (87) and (92) to get

$$\begin{aligned}
\mathcal{D}(W(\cdot|x)||R(\cdot)) \\
&\leq \frac{1}{2}\log(1+x) + \frac{1}{2}\log(1+\delta) + \frac{1}{2}\left(4x + \frac{1}{3}\right)\frac{1}{2x+1} \\
&+ \frac{1}{2}\log\mathcal{E} + \frac{1}{2}\log\pi + \frac{x}{\mathcal{E}} + \frac{1}{2\mathcal{E}} \\
&\leq \frac{1}{2}\log\left(1 + \frac{1}{\delta}\right) + \frac{1}{2}\log(1+\delta) + \frac{1}{2}\left(\frac{4}{\delta} + \frac{1}{3}\right) \\
&+ \frac{1}{2}\log\mathcal{E} + \frac{1}{2}\log\pi + \frac{x}{\mathcal{E}} + \frac{1}{2\mathcal{E}} \\
&= \frac{1}{2}\log\mathcal{E} + \frac{x}{\mathcal{E}} + \frac{1}{2\mathcal{E}} + O(1)
\end{aligned} \tag{291}$$

where we upper-bound and where we use in various places that . Again does not depend on or .

Hence, we get

$$C(\mathcal{E}) \leq \mathsf{E}_{Q^*}[D(\tilde{W}(\cdot|X)||R(\cdot))] \tag{292}$$

$$\leq \frac{1}{2}\log\mathcal{E} + \frac{\mathcal{E}}{\mathcal{E}} + \frac{1}{2\mathcal{E}} + O(1) \tag{293}$$

$$= \frac{1}{2}\log\mathcal{E} + o_{\mathcal{E}}(1) + O(1) \tag{294}$$

and therefore

$$\overline{\lim_{\mathcal{E}\uparrow\infty}} \frac{\mathcal{C}(\mathcal{E})}{\frac{1}{2}\log\mathcal{E}} \le 1.$$
 (295)

Hence, we have shown that satisfies the conditions of Proposition 14. This proves our claim.

## REFERENCES

- [1] S. Shamai (Shitz), "Capacity of a pulse amplitude modulated direct detection photon channel," *Proc. Inst. Elec. Eng.*, vol. 137, no. 6, pp. 424–430, Dec. 1990, part I (Communications, Speech and Vision).
- [2] A. Lapidoth, J. H. Shapiro, V. Venkatesan, and L. Wang, "The Poisson channel at low input powers," in *Proc. 25th IEEE Conv. Electrical & Electronics Engineers in Israel (IEEEI)*, Eilat, Israel, Dec. 2008, pp. 654–658.
- [3] V. Venkatesan, "On low power capacity of the Poisson channel," Master's thesis, Signal and Information Processing Lab., ETH Zurich, Zurich, Switzerland, Apr. 2008, supervised by Prof. Dr. Amos Lapidoth.
- [4] D. Brady and S. Verdú, "The asymptotic capacity of the direct detection photon channel with a bandwidth constraint," in *Proc. 28th Allerton Conf. Communication, Control and Computing*, Allerton House, Monticello, IL, Oct. 1990, pp. 691–700.
- [5] Y. Kabanov, "The capacity of a channel of the Poisson type," *Theory Prob. Its Applic.*, vol. 23, pp. 143–147, 1978.
- [6] M. H. A. Davis, "Capacity and cutoff rate for Poisson-type channels," *IEEE Trans. Inf. Theory*, vol. IT-26, no. 6, pp. 710–715, Nov. 1980.
- [7] A. D. Wyner, "Capacity and error exponent for the direct detection photon channel—Parts I and II," *IEEE Trans. Inf. Theory*, vol. 34, no. 6, pp. 1462–1471, Nov. 1988.
- [8] M. R. Frey, "Capacity of the norm-constrained Poisson channel," *IEEE Trans. Inf. Theory*, vol. 38, no. 2, pp. 445–450, Mar. 1992.

- [9] M. R. Frey, "Information capacity of the Poisson channel," *IEEE Trans. Inf. Theory*, vol. 37, no. 2, pp. 244–256, Mar. 1991.
- [10] S. Shamai (Shitz) and A. Lapidoth, "Bounds on the capacity of a spectrally constrained Poisson channel," *IEEE Trans. Inf. Theory*, vol. 39, no. 1, pp. 19–29, Jan. 1993.
- [11] I. Bar-David and G. Kaplan, "Information rates of photon-limited overlapping pulse position modulation channels," *IEEE Trans. Inf. Theory*, vol. IT-30, no. 3, pp. 455–464, May 1984.
- [12] S. M. Moser, "Duality-based bounds on channel capacity," Ph.D. dissertation, Swiss Federal Institute of Technology (ETH), Zurich, Switzerland, Oct. 2004 [Online]. Available: http: moser.cm.nctu. edu.tw, Diss. ETH No. 15769.
- [13] T. H. Chan, S. Hranilovic, and F. R. Kschischang, "Capacity-achieving probability measure for conditionally Gaussian channels with bounded inputs," *IEEE Trans. Inf. Theory*, vol. 51, no. 6, pp. 2073–2088, Jun. 2005.
- [14] S. Hranilovic and F. R. Kschischang, "Capacity bounds for power- and band-limited optical intensity channels corrupted by Gaussian noise," *IEEE Trans. Inf. Theory*, vol. 50, no. 5, pp. 784–795, May 2004.
- [15] A. A. Farid and S. Hranilovic, "Upper and lower bounds on the capacity of wireless optical intensity channels," in *Proc. IEEE Int. Symp. Information Theory (ISIT)*, Nice, France, Jun. 2007, pp. 2416–2420.
- [16] A. Lapidoth, S. M. Moser, and M. A. Wigger, "On the capacity of freespace optical intensity channels," in *Proc. IEEE Int. Symp. Information Theory (ISIT)*, Toronto, ON, Canada, Jul. 2008, pp. 2419–2423.
- [17] A. Lapidoth, S. M. Moser, and M. A. Wigger, "On the Capacity of Free-Space Optical Intensity Channels," June 2008, submitted for publication.
- [18] A. A. Farid and S. Hranilovic, "Design of non-uniform capacity-approaching signaling for optical wireless intensity channels," in *Proc. IEEE Int. Symp. Information Theory (ISIT)*, Toronto, ON, Canada, Jul. 2008, pp. 2327–2331.
- [19] A. Lapidoth and S. M. Moser, "On the Capacity of an Optical Intensity Channel with Input-Dependent Noise," 2008, in preparation.
- [20] A. Martinez, "Spectral efficiency of optical direct detection," *J. Opt. Soc. America B*, vol. 24, no. 4, pp. 739–749, Apr. 2007.
- [21] A. Lapidoth and S. M. Moser, "Capacity bounds via duality with applications to multiple-antenna systems on flat fading channels," *IEEE Trans. Inf. Theory*, vol. 49, no. 10, pp. 2426–2467, Oct. 2003.
- [22] T. M. Cover and J. A. Thomas*, Elements of Information Theory*. New York: Wiley, 1991.
- [23] A. Lapidoth and S. M. Moser, "The fading number of single-input multiple-output fading channels with memory," *IEEE Trans. Inf. Theory*, vol. 52, no. 2, pp. 437–453, Feb. 2006.
- [24] B. Rankov and D. Lenz, "Bounds on the capacity of Poisson channels," Master's thesis, Signal and Information Processing Laboratory, ETH Zurich, Zurich, Switzerland, Mar. 2002, supervised by Prof. Dr. Amos Lapidoth.
- [25] N. L. Johnson, S. Kotz, and N. Balakrishnan*, Continuous Univariate Distributions*, 2nd ed. New York: Wiley, 1994, vol. 1.
- [26] R. G. Gallager*, Information Theory and Reliable Communication*. New York: Wiley, 1968.
- [27] I. Csiszár and J. Körner*, Information Theory: Coding Theorems for Discrete Memoryless Systems*. New York: Academic, 1981.
- [28] W. Feller*, An Introduction to Probability Theory and Its Applications*, 3rd ed. New York: Wiley, 1957/1968, vol. 1.
- [29] H. Robbins, "A remark on Stirling's formula," *Amer. Math. Monthly*, vol. 62, pp. 26–29, 1955.

**Amos Lapidoth** (S'89–M'95–SM'00–F'04) received the B.A. degree in mathematics (*summa cum laude*, 1986), the B.Sc. degree in electrical engineering (*summa cum laude*) in 1986, and the M.Sc. degree in electrical engineering in 1990, all from the Technion–Israel Institute of Technology, Haifa. He received the Ph.D. degree in electrical engineering from Stanford University, Stanford, CA, in 1995.

During 1995–1999, he was an Assistant and Associate Professor in the Department of Electrical Engineering and Computer Science at the Massachusetts Institute of Technology, Cambridge, and was the KDD Career Development Associate Professor in Communications and Technology. He is now Professor of Information Theory at the Signal and Information Processing Laboratory, ETH Zurich, Switzerland. His research interests are in digital communications and information theory.

Dr. Lapidoth served during 2003–2004 as Associate Editor for Shannon Theory for the IEEE TRANSACTIONS ON INFORMATION THEORY.

**Stefan M. Moser** (S'01–M'05) was born in Switzerland. He received the M.Sc. degree in electrical engineering (with distinction) in 1999, the M.Sc. degree in industrial management (M.B.A.) in 2003, and the Ph.D. degree in the field of information theory in 2004, all from the Swiss Federal Institute of Technology (ETH) in Zurich, Switzerland.

During 1999 to 2003, he was a Research and Teaching Assistant, and from 2004 to 2005, he was a Senior Research Assistant with the Signal and Information Processing Laboratory, ETH Zurich. Since August 2005, he has been an Assistant Professor with the Departmentof Communication Engineering, National Chiao Tung University (NCTU), Hsinchu, Taiwan. His research interests are in information theory and digital communications.

Dr. Moser received the National Chiao Tung University Outstanding Researchers Award in 2007 and 2008, the National Chiao Tung University Excellent Teaching Award and the National Chiao Tung University Outstanding Mentoring Award both in 2007, the Willi Studer Award of ETH in 1999, and the ETH Silver Medal for an excellent Master's thesis in 1999.