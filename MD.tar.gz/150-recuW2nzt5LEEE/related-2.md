# Deterministic Identification Over Fading Channels

Mohammad J. Salariseddigh<sup>∗</sup> , Uzi Pereg<sup>∗</sup> , Holger Boche† , and Christian Deppe<sup>∗</sup> ∗ Institute for Communications Engineering, Technical University of Munich †Chair of Theoretical Information Technology, Technical University of Munich

*Abstract*—Deterministic identification (DI) is addressed for Gaussian channels with fast and slow fading, where channel side information is available at the decoder. In particular, it is established that the number of messages scales as 2 <sup>n</sup> log(n)<sup>R</sup>, where n is the block length and R is the coding rate. Lower and upper bounds on the DI capacity are developed in this scale for fast and slow fading. Consequently, the DI capacity is infinite in the exponential scale and zero in the double-exponential scale, regardless of the channel noise.

*Index Terms*—Fading channels, identification without randomization, deterministic codes, super exponential growth, channel side information.

## I. INTRODUCTION

Modern communications require the transfer of enormous amount of data in wireless systems, for cellular communication, sensor networks, smart appliances internet of things, etc. Wireless communication is often modelled by fading channels with AWGN [1], [2]. In the fast fading regime, the transmission spans over a large number of coherence time intervals [2], hence the signal attenuation is characterized by a stochastic process or a sequence random parameters. In some applications, the receiver may acquire channel side information (CSI) by instantaneous estimation of the channel parameters [3]. On the other hand, in the slow fading regime, the latency is short compared to the coherence time [2], and the behaviour is that of a compound channel.

In the fundamental point-to-point communication paradigm, a sender conveys a message through a noisy channel in a such a manner that the receiver will retrieve the original message. Ahlswede and Dueck [4] introduced a scenario of a different nature where the decoder only performs identification and determines whether a particular message was sent or not [4], [5]. Applications include vehicle-to-X communications [6], digital watermarking [7], molecular communications [8], [9] and other event-triggered systems. In vehicle-to-X communications, a vehicle that collects sensor data may ask whether a certain alert message, concerning the future movement of an adjacent vehicle, was transmitted or not [10]. In molecular communications (MC) [11], [12], information is transmitted via chemical signals or molecules. In various environments, e.g. inside the human body, conventional wireless communication with electromagnetic (EM) waves is not feasible or could be detrimental. The research on micro-scale MC for medical applications, such as intra-body networks, is still in its early stages and faces many challenges. MC is a promising contender for future applications such as 7G+.

The original identification setting by Ahlswede and Dueck [4] requires randomized encoding, i.e., a randomized source available to the sender. It is known that this resource cannot increase the *transmission* capacity of discrete memoryless channels [13]. A remarkable result of identification theory is that given local randomness at the encoder, reliable identification can be attained such that the code size, i.e., the number of messages, grows double exponentially in the block length n, i.e., ∼ 2 2 nR [4]. This differs sharply from the traditional transmission setting where the code size scales only exponentially, i.e., ∼ 2 nR. Yet, the implementation of such a coding scale is challenging, as it requires the encoder to process a bit string of exponential length. The construction of identification codes is considered in [5], [14], [15]. Identification for Gaussian channels is considered in [16].

In the deterministic setup, given a discrete memoryless channel (DMC), the number of messages grows exponentially with the blocklength [4], [17]–[19], as in the traditional setting of transmission. Nevertheless, the achievable identification rates are higher than those of transmission. In addition, deterministic codes often have the advantage of simpler implementation and explicit construction. In particular, JaJ´ a [18] showed ´ that the deterministic identification (DI) capacity of a binary symmetric channel is 1 bit per channel use, as one can exhaust the entire input space and assign (almost) all binary n-tuples as codewords. The DI capacity in the literature is also referred to as the non-randomized identification (NRI) capacity [17] or the dID capacity [20]. Ahlswede et al. [4], [17] stated that the DI capacity of a discrete memoryless channel (DMC) with a stochastic matrix W is given by the logarithm of the number of distinct row vectors of W [4], [17]. The DI ε-capacity of the Gaussian channel was determined by Burnashev [20].

In a recent work by the authors [21], we addressed deterministic identification for the DMC subject to an input constraint and have also shown that the DI capacity of the standard Gaussian channel, without fading, is infinite in the exponential scale. Our previous results [21] reveal a gap of knowledge in the following sense. For a finite blocklength n, the number of codewords must be finite. Thereby, the meaning of the infinite capacity result is that the number of messages scales superexponentially. The question remains what is the true order of the code size. In mathematical terms, what is the scale L for which the DI capacity is positive yet finite. Here, we will answer this question.

In this paper, we consider deterministic identification for Gaussian channels with fast fading and slow fading, where channel side information (CSI) is available at the decoder. We show that for Gaussian channels, the number of messages scales as 2 <sup>n</sup> log(n)<sup>R</sup>, and develop lower and upper bounds on the DI capacity in this scale. As a consequence, we deduce that the DI capacity of a Gaussian Channel with fast fading is infinite in the exponential scale and zero in the double-exponential scale, regardless of the channel noise. For slow fading, the DI capacity in the exponential scale is infinite, unless the fading gain can be zero or arbitrarily close to zero (with positive probability), in which case the DI capacity is zero. As opposed to RI coding, double exponential number of messages cannot be achieved with deterministic codes.

The results have the following geometric interpretation. While identification allows overlap between decoding regions [13], [16], overlap at the encoder is not allowed for deterministic codes. We observe that when two messages are represented by codewords that are close to one another, then identification fails. Thus, deterministic coding imposes the restriction that the codewords need to be distanced from each other. Based on fundamental properties in the lattice and group theory [22], the optimal packing of non-overlapping spheres of radius  $\sqrt{n\varepsilon}$ contains an exponential number of spheres, and by decreasing the radius of the codeword spheres, the exponential rate can be made arbitrarily large. However, in the derivation of our lower bound, we show achievability of rates in the  $2^{n \log(n)}$ scale by using spheres of radius  $\sqrt{n\varepsilon_n} \sim n^{1/4}$ , which results in  $\sim 2^{\frac{1}{4}n\log(n)}$  codewords. The full version of this paper with proofs can be found in [23].

#### II. DEFINITIONS AND RELATED WORK

In this section, we introduce the channel models and coding definitions. We use the following notation: a vector is denoted by  $\mathbf{x}=(x_1,x_2,\ldots,x_n)$ , and its  $\ell^2$ -norm by  $\|\mathbf{x}\|$ . Elementwise product is denoted by  $\mathbf{x} \circ \mathbf{y} = (x_t y_t)_{t=1}^n$ . We denote the hyper-sphere of radius r by  $\mathcal{S}_{\mathbf{x}_0}(n,r) = \{\mathbf{x} \in \mathbb{R}^n : \|\mathbf{x} - \mathbf{x}_0\| \le r\}$ , and the set of consecutive integers from 1 to M by  $[\![M]\!]$ . The closure of a set  $\mathcal A$  is denote by  $\mathrm{cl}(\mathcal A)$ .

## A. Fading Channels

Consider a Gaussian channel,

$$\mathbf{Y} = \mathbf{G} \circ \mathbf{x} + \mathbf{Z} \tag{1}$$

where  $\mathbf{G}$  is a random sequence of fading coefficients and  $\mathbf{Z}$  is an additive white Gaussian process, i.i.d.  $\sim \mathcal{N}(0,\sigma_Z^2)$  (see Figure 1). For fast fading,  $\mathbf{G}$  is a sequence of i.i.d. continuous random variables  $\sim f_G$ , whereas for slow fading, the fading sequence remains constant throughout the transmission, i.e.,  $G_t = G \sim f_G$ . It is assumed that the noise sequence  $\mathbf{Z}$  and the sequence of fading coefficients  $\mathbf{G}$  are statistically independent, and that the values of the fading coefficients belong to a bounded set  $\mathcal{G}$ , either countable or uncountable. The transmission power is limited to

$$\|\mathbf{x}\|^2 \le nA. \tag{2}$$

We consider codes with different size orders. For instance, when we discuss the exponential scale, we refer to a code size that scales as  $L(n,R)=2^{nR}$ . On the other hand, in the double-exponential scale, the code size is L(n,R)=

![](_page_1_Picture_11.jpeg)

Fig. 1. Deterministic identification over fading channels. For fast fading,  $\mathbf{G} = (G_t)_{t=1}^{\infty}$  is a sequence of i.i.d. fading coefficients  $\sim f_G$ . For slow fading, the fading sequence remains constant throughout the transmission block, i.e.,  $G_t = G$ .

 $2^{2^{nR}}$ . We say that a scale  $L_1$  dominates another scale  $L_2$  if  $\lim_{n \to \infty} \frac{L_2(n,b)}{L_1(n,a)} = 0$  for all a,b>0.

Definition 1. An (L(n,R),n) DI code for a Gaussian channel  $\mathscr{G}_{\mathrm{fast}}$  with CSI at the decoder, assuming L(n,R) is an integer, is defined as a system  $(\mathcal{U},\mathscr{D})$  which consists of a codebook  $\mathcal{U} = \{\mathbf{u}_i\}_{i \in \llbracket L(n,R) \rrbracket}, \, \mathcal{U} \subset \mathbb{R}^n$ , such that  $\|\mathbf{u}_i\|^2 \leq nA$ , for all  $i \in \llbracket L(n,R) \rrbracket$  and a collection of decoding regions  $\mathscr{D} = \{\mathcal{D}_{i,\mathbf{g}}\}_{i \in \llbracket 2^{nR} \rrbracket}, \, \mathbf{g} \in \mathcal{G}^n$  with  $\bigcup_{i=1}^{L(n,R)} \mathcal{D}_{i,\mathbf{g}} \subset \mathbb{R}^n$ . Given a message  $i \in \llbracket L(n,R) \rrbracket$ , the encoder transmits  $\mathbf{u}_i$ . The decoder's aim is to answer the following question: Was a desired message j sent or not? There are two types of errors that may occur: Rejecting of the true message, or accepting a false message. Those are referred to as type I and type II errors, respectively. The error probabilities are given by

$$P_{e,1}(i) = 1 - \int_{\mathcal{G}^n} f_{\mathbf{G}}(\mathbf{g}) \left[ \int_{\mathcal{D}_{i,\mathbf{g}}} f_{\mathbf{Z}}(\mathbf{y} - \mathbf{g} \circ \mathbf{u}_i) d\mathbf{y} \right] d\mathbf{g}$$
(3)

$$P_{e,2}(i,j) = \int_{\mathcal{G}^n} f_{\mathbf{G}}(\mathbf{g}) \left[ \int_{\mathcal{D}_{j,\mathbf{g}}} f_{\mathbf{Z}}(\mathbf{y} - \mathbf{g} \circ \mathbf{u}_i) \, d\mathbf{y} \right] d\mathbf{g}. \quad (4)$$

An  $(L(n,R),n,\lambda_1,\lambda_2)$  DI code further satisfies  $P_{e,1}(i) \leq \lambda_1$  and  $P_{e,2}(i,j) \leq \lambda_2$  for all  $i,j \in [\![L(n,R)]\!]$ ,  $i \neq j$ . A rate R is called achievable if for every  $\lambda_1,\lambda_2>0$  and sufficiently large n, there exists a  $(L(n,R),n,\lambda_1,\lambda_2)$  DI code. The operational DI capacity in the L-scale is defined as the supremum of achievable rates, and will be denoted by  $\mathbb{C}_{DI}(\mathscr{G}_{\mathrm{fast}},L)$ .

Coding for slow fading is defined in a similar manner. However, the errors are defined with a supremum over the values of the fading coefficient  $G \in \mathcal{G}$ , namely,

$$P_{e,1}(i) = \sup_{g \in \mathcal{G}} \left[ 1 - \int_{\mathcal{D}_{i,g}} \left( \prod_{t=1}^{n} f_Z(y_t - gu_{i,t}) \right) d\mathbf{y} \right]$$
 (5)

$$P_{e,2}(i,j) = \sup_{g \in \mathcal{G}} \left[ \int_{\mathcal{D}_{j,g}} \left( \prod_{t=1}^{n} f_Z(y_t - gu_{i,t}) \right) d\mathbf{y} \right]. \tag{6}$$

The DI capacity of the Gaussian channel with slow fading is denoted by  $\mathbb{C}_{DI}(\mathscr{G}_{\text{slow}}, L)$ .

As mentioned earlier, in the original identification setting, a randomized source is available to the sender, and the encoder may depend on the output of this source. A randomized-encoder identification (RI) code is defined similarly where the encoder is allowed to select a codeword  $U_i$  at random according to some conditional input distribution  $Q(x^n|i)$ . The RI capacity in the L-scale is then denoted by  $\mathbb{C}_{RI}(\cdot, L)$ .

Remark 1. We establish the following property [23, see Lem. 3]. Suppose that  $L_1$  is a scale that dominates another scale  $L_2$ . We note that in general, if the capacity in the  $L_2$ -scale is finite, then it is zero in the  $L_1$ -scale. Conversely, if the capacity in the  $L_1$ -scale is positive, then the capacity in the  $L_2$ -scale is  $+\infty$ .

Remark 2. Molecular communication (MC) technology has recently advanced significantly [11]. The goal is to construct complex networks, such as IoT, using MC. Nanotechnology enables the development of nanothings, devices in the nano-scale range, and Internet of NanoThings (IoNT), which will be the basis for various future healthcare and military applications [24]. Conventional electronic circuits and EMbased communication could be harmful for some application environments, such as inside the human body. Nanothings can be biological cells, or bio-nanothings, that are created by means of synthetic biology and nanotechnology techniques. Similar to artificial nanothings, bio-nanothings have control (cell nucleus), power (mitochondrion), communication (signal pathways), and sensing/actuation (flagella, pili or cilia) units. For the inter-cellular communications, MC is especially well suited, due to the natural exchange of information. The communication task of identification has significant interest for these applications. However, it is unclear whether RI codes can be incorporated there, as it is unclear how powerful random number generators should be developed for synthetic materials on these small scales. Furthermore, for Bio-NanoThings, it is uncertain whether the natural biological processes can be controlled or reinforced by local randomness. Therefore, for the design of synthetic IoNT, or for the analysis and utilization of IoBNT, deterministic identification is applicable.

## B. Related Work

We briefly review known results for the standard Gaussian channel. We begin with the RI capacity, i.e., when the encoder uses a stochastic mapping. Let  $\mathcal G$  denote the standard Gaussian channel,  $Y_t = gX_t + Z_t$ , where the gain g>0 is a deterministic constant which is known to the encoder and the decoder. As mentioned, using RI codes, it is possible to identify a double-exponential number of messages in the block length n. Despite the significant difference between the definitions in the identification and transmission settings, it was shown that the value of the RI capacity in the double-exponential scale equals the Shannon capacity of transmission.

Theorem 1 (see [4], [16]). The RI capacity in the double-exponential scale of the standard Gaussian channel satisfies

$$\mathbb{C}_{RI}(\mathcal{G}, L) = \frac{1}{2} \log \left( 1 + \frac{g^2 A^2}{\sigma^2} \right), \text{ for } L(n, R) = 2^{2^{nR}}$$
 (7)

$$\mathbb{C}_{RI}(\mathcal{G}, L) = \infty$$
, for  $L(n, R) = 2^{nR}$ . (8)

In a recent paper by the authors [21], the deterministic case was considered in the exponential scale.

Theorem 2 (see [21]). The DI capacity in the exponential scale of the standard Gaussian channel is infinite, i.e.,

$$\mathbb{C}_{DI}(\mathcal{G}, L) = \infty$$
, for  $L(n, R) = 2^{nR}$ . (9)

Our results in [21] reveal a gap of knowledge in the following sense. For a finite blocklength n, the number of codewords must be finite. Thereby, Theorem 2 implies that the code size scales super-exponentially. The question remains what is the order of the code size. In mathematical terms, what is the scale L for which the DI capacity is positive yet finite. In the next section, we provide an answer to this question.

#### III. MAIN RESULTS

## A. Main Result - Gaussian Channel with Fast Fading

Our DI capacity theorem for the Gaussian channel with fast fading is stated below.

Theorem 3. Assume that the fading coefficients are positive, i.e.,  $0 \notin cl(\mathcal{G})$ . The DI capacity of the Gaussian channel  $\mathscr{G}_{fast}$  with fast fading in the  $2^{n \log(n)}$ -scale is given by

$$\frac{1}{4} \le \mathbb{C}_{DI}(\mathcal{G}_{\text{fast}}, L) \le 1, \quad \text{for } L(n, R) = 2^{n \log(n)R}. \tag{10}$$

Hence, the DI capacity is infinite in the exponential scale and zero in the double-exponential, i.e.,

$$\mathbb{C}_{DI}(\mathscr{G}_{\text{fast}}, L) = \begin{cases} \infty & \text{for } L(n, R) = 2^{nR}. \\ 0 & \text{for } L(n, R) = 2^{2^{nR}}. \end{cases}$$
(11)

The proofs for the lower and upper bounds are given in Section IV-A and Section IV-B, respectively. The second part of Theorem 3 is a direct consequence of Remark 1.

Next, we consider the Gaussian channel  $\mathcal{G}_{slow}$  with slow fading.

Theorem 4. The DI capacity of the Gaussian channel  $\mathscr{G}_{slow}$  with slow fading in the  $2^{n \log(n)}$ -scale is bounded by

$$\frac{1}{4} \leq \mathbb{C}_{DI}(\mathcal{G}_{\text{slow}}, L) \leq 1 \quad \text{if } 0 \in \text{cl}(\mathcal{G}) \\
\mathbb{C}_{DI}(\mathcal{G}_{\text{slow}}, L) = 0 \quad \text{if } 0 \notin \text{cl}(\mathcal{G})$$
(12)

for  $L(n,R) = 2^{n \log(n)R}$ . Hence,

$$\mathbb{C}_{DI}(\mathscr{G}_{\mathrm{slow}}, L) = \begin{cases} 0 & \text{if } 0 \in \mathrm{cl}(\mathcal{G}) \\ \infty & \text{if } 0 \notin \mathrm{cl}(\mathcal{G}) \end{cases}, \text{ for } L(n, R) = 2^{nR}$$

$$\mathbb{C}_{DI}(\mathcal{G}_{\text{slow}}, L) = 0, \quad \text{for } L(n, R) = 2^{2^{nR}}. \tag{13}$$

The proof of Theorem 4 is given in [23]. The proof is based on a similar technique as for fast fading.

### IV. PROOF OF THEOREM 3

## A. Lower Bound

We show that the DI capacity is bounded by  $\mathbb{C}_{DI}(\mathscr{G}_{\mathrm{fast}},L) \geq \frac{1}{4}$  for  $L(n,R) = 2^{n\log(n)R}$ . Achievability is established using a dense packing arrangement and a simple distance-decoder. A DI code for the Gaussian channel  $\mathscr{G}_{\mathrm{fast}}$  with fast fading is constructed as follows. Consider the normalized input-output relation,

$$\bar{\mathbf{Y}} = \mathbf{G} \circ \bar{\mathbf{x}} + \bar{\mathbf{Z}} \tag{14}$$

where the noise sequence  $\bar{\mathbf{Z}}$  is i.i.d.  $\sim \mathcal{N}\left(0, \frac{\sigma^2}{n}\right)$ , and an input power constraint

$$\|\bar{\mathbf{x}}\| \le \sqrt{A} \tag{15}$$

with  $\bar{\mathbf{x}} = \frac{1}{\sqrt{n}}\mathbf{x}$ ,  $\bar{\mathbf{Z}} = \frac{1}{\sqrt{n}}\mathbf{Z}$ , and  $\bar{\mathbf{Y}} = \frac{1}{\sqrt{n}}\mathbf{Y}$ . Assuming  $0 \notin \text{cl}(\mathcal{G})$ , there exists a positive number  $\gamma$  such that  $|G_t| > \gamma$  for all t with probability 1.

Codebook construction: We use a packing arrangement of non-overlapping hyper-spheres of radius  $\sqrt{\varepsilon_n}$  that cover a hyper-sphere of radius  $(\sqrt{A} - \sqrt{\varepsilon_n})$ , with

$$\varepsilon_n = \frac{A}{n^{\frac{1}{2}(1-b)}}\tag{16}$$

where b > 0 is arbitrarily small. The small spheres are not necessarily entirely contained within the bigger sphere. The packing density is defined as the fraction of the big sphere volume that is covered by the small spheres. Based on the Minkowski-Hlawka theorem [22] in lattice theory, there exists an arrangement  $\bigcup_{i=1}^{2^n\log(n)R} \mathcal{S}_{\mathbf{u}_i}(n,\sqrt{\varepsilon_n})$  inside  $S_0(n, \sqrt{A} - \sqrt{\varepsilon_n})$  with a density of at least  $2^{-n}$ . Specifically, consider a saturated packing arrangement in  $\mathbb{R}^n$  with spheres of radius  $\sqrt{\varepsilon_n}$ , i.e., such that no spheres can be added without overlap. Then, for such an arrangement, there cannot be a point in the big sphere with a distance of more than  $2\sqrt{\varepsilon_n}$  from all sphere centers. Otherwise, a new sphere could be added. As a consequence, if we double the radius of each sphere, the  $2\sqrt{\varepsilon_n}$ -radius spheres cover the whole sphere of radius  $(\sqrt{A} - \sqrt{\varepsilon_n})$ . Doubling the radius multiplies the volume by  $2^n$ . This, in turn, implies that the original  $\sqrt{\varepsilon_n}$ -radius packing arrangement has density of at least  $2^{-n}$ . We assign a codeword to the center of each small sphere  $\mathbf{u}_i$ . Since the small spheres have the same volume, the total number of spheres, i.e., the codebook size, is roughly  $2^{n\log(n)R}\approx 2^{-n}\cdot\left(\frac{A}{\varepsilon_n}\right)^{\frac{\hat{n}}{2}}$  . To be precise,

$$R \geq \frac{1}{2\log(n)}\log\left(\frac{A}{\varepsilon_n}\right) - \frac{2}{\log(n)} = \frac{1}{4}(1-b) - \frac{2}{\log(n)}$$

which tends to  $\frac{1}{4}$  when  $n \to \infty$  and  $b \to 0$ .

Encoding: Given a message  $i \in [L(n,R)]$ , send  $\bar{\mathbf{x}} = \bar{\mathbf{u}}_i$ .

Decoding: Let  $\delta_n = \frac{\gamma^2 \varepsilon_n}{3}$ . To identify whether a message  $j \in [\![L(n,R)]\!]$  was sent, given the sequence  $\mathbf{g}$ , the decoder checks whether the channel output  $\bar{\mathbf{y}}$  belongs to

$$\mathcal{D}_{j,\mathbf{g}} = \{ \bar{\mathbf{y}} \in \mathbb{R}^n : \|\bar{\mathbf{y}} - \mathbf{g} \circ \bar{\mathbf{u}}_j\| \le \sqrt{\sigma^2 + \delta_n} \}.$$
 (17)

*Error Analysis:* Consider the type I error, i.e., when the transmitter sends  $\bar{\mathbf{u}}_i$ , yet  $\bar{\mathbf{Y}} \notin \mathcal{D}_{i,\mathbf{G}}$ . For every  $i \in [\![L(n,R)]\!]$ , the type I error probability is bounded by

$$P_{e,1}(i) = \Pr\left(\frac{1}{n} \left\| \bar{\mathbf{Y}} - \mathbf{G} \circ \bar{\mathbf{u}}_i \right\|^2 > \sigma_Z^2 + \delta_n \left\| \bar{\mathbf{x}} = \mathbf{G} \circ \bar{\mathbf{u}}_i \right\| \right)$$

$$= \Pr\left( \left\| \bar{\mathbf{Z}} \right\|^2 > \sigma_Z^2 + \delta_n \right) \le \frac{3\sigma_Z^4}{n\delta_n^2}$$
(18)

by Chebyshev's inequality. This tends to zero as  $n\to\infty$  since  $\delta_n\propto n^{-\frac{1}{2}(1-b)}.$ 

Next, we address the type II error, i.e., when  $\bar{\mathbf{Y}} \in \mathcal{D}_{j,\mathbf{G}}$  while the transmitter sent  $\bar{\mathbf{u}}_i$ . Then, for every  $i, j \in [\![L(n,R)]\!]$ , where  $i \neq j$ , the type II error probability is given by

$$P_{e,2}(i,j) = \Pr\left( \left\| \mathbf{G} \circ (\bar{\mathbf{u}}_i - \bar{\mathbf{u}}_j) + \bar{\mathbf{Z}} \right\|^2 \le \sigma_Z^2 + \delta_n \right). \tag{19}$$

Observe that the square norm can be expressed as

$$\|\mathbf{G} \circ (\bar{\mathbf{u}}_i - \bar{\mathbf{u}}_j) + \bar{\mathbf{Z}}\|^2 = \|\mathbf{G} \circ (\bar{\mathbf{u}}_i - \bar{\mathbf{u}}_j)\|^2 + \|\bar{\mathbf{Z}}\|^2 + 2\sum_{t=1}^n G(\bar{u}_{i,t} - \bar{u}_{j,t})\bar{Z}_t. \quad (20)$$

Furthermore, by Chebyshev's inequality, the probability of the event  $\left\{\left|\sum_{t=1}^n G(\bar{u}_{i,t}-\bar{u}_{j,t})\bar{Z}_t\right|>\frac{\delta_n}{2}\right\}$  is bounded by  $\frac{4\sigma_Z^2(\sigma_G^2+\mu_G^2)4A}{n\delta_n^2}$ . Therefore, for sufficiently large  $n, P_{e,2}(i,j) \leq \Pr\left(\left\|\mathbf{G}\circ(\bar{\mathbf{u}}_i-\bar{\mathbf{u}}_j)\right\|^2+\left\|\bar{\mathbf{Z}}\right\|^2\leq\sigma_Z^2+2\delta_n\right)+\eta_1.$ 

Since each codeword is surrounded by a sphere of radius  $\sqrt{\varepsilon_n}$ , we have  $\|\mathbf{G} \circ (\bar{\mathbf{u}}_i - \bar{\mathbf{u}}_i)\|^2 \ge \gamma^2 \varepsilon_n$ . Thus,,

$$P_{e,2}(i,j) \le \Pr\left(\left\|\bar{\mathbf{Z}}\right\|^2 \le \sigma_Z^2 + 2\delta_n - \gamma^2 \varepsilon_n\right) + \eta_1$$
$$= \Pr\left(\left\|\bar{\mathbf{Z}}\right\|^2 + \eta_1 \le \sigma_Z^2 - \delta_n\right) \le 2\eta_1 \qquad (21)$$

as  $2\delta_n-\gamma^2\varepsilon_n=-\delta_n$ . The proof follows by taking the limits  $n\to\infty,\ b\to0.$ 

## B. Upper Bound (Converse Proof)

We show that the capacity is bounded by  $\mathbb{C}_{DI}(\mathscr{G}_{\text{fast}}, L) \leq 1$ . Suppose that R is an achievable rate.

*Lemma* 5. For sufficiently large n, every pair of codewords are distanced by at least  $\sqrt{n\varepsilon'_n}$ , i.e.,  $\|\mathbf{u}_{i_1} - \mathbf{u}_{i_2}\| \ge \sqrt{n\varepsilon'_n}$  where

$$\varepsilon_n' = \frac{A}{n^2} \tag{22}$$

for all  $i_1, i_2 \in [\![L(n,R)]\!]$  such that  $i_1 \neq i_2$ .

*Proof.* Let  $\kappa, \eta > 0$  be arbitrarily small. Assume to the contrary that there exist two messages  $i_1$  and  $i_2$ , where  $i_1 \neq i_2$ , such that  $\|\mathbf{u}_{i_1} - \mathbf{u}_{i_2}\| < \sqrt{n\varepsilon_n^{\prime}} = \sqrt{\frac{A}{n}}$ . Then, there exists b > 0 such that  $\|\mathbf{u}_{i_1} - \mathbf{u}_{i_2}\| \leq \alpha_n$  where  $\alpha_n \equiv \frac{\sqrt{A}}{n^{\frac{1}{2}(1+2b)}}$ . Observe that  $\mathbb{E}\{\|\mathbf{G} \circ (\mathbf{u}_{i_1} - \mathbf{u}_{i_2})\|^2\} = \mathbb{E}\{G^2\}\|\mathbf{u}_{i_1} - \mathbf{u}_{i_2}\|^2$  and consider the subspace

$$\mathcal{A}_{i_1,i_2} = \{ \mathbf{g} \in \mathcal{G}^n : \|\mathbf{g} \circ (\mathbf{u}_{i_1} - \mathbf{u}_{i_2})\| > \delta'_n \}$$
 (23)

where  $\delta'_n \equiv \frac{\sqrt{A}}{n^{\frac{1}{2}(1+b)}}$ . By Markov's inequality,

$$\Pr(\mathbf{G} \in \mathcal{A}_{i_1, i_2}) \le \frac{\mathbb{E}\{G^2\}\alpha_n^2}{\delta_n'^2} = \frac{\mathbb{E}\{G^2\}}{n^b} \le \kappa.$$
 (24)

Therefore,

$$1 - P_{e,1}(i_1) = \int_{\mathcal{G}^n} f_{\mathbf{G}}(\mathbf{g}) \left[ \int_{\mathcal{D}_{i_1,\mathbf{g}}} f_{\mathbf{Z}}(\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i_1}) d\mathbf{y} \right] d\mathbf{g}$$

$$\leq \int_{\mathcal{A}_{i_1,i_2}^c} f_{\mathbf{G}}(\mathbf{g}) \left[ \int_{\mathcal{D}_{i_1},\mathbf{g}} f_{\mathbf{Z}}(\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i_1}) d\mathbf{y} \right] d\mathbf{g} + \kappa. \quad (25)$$

Next we bound the inner integral by

$$\int_{\mathcal{D}_{i_1,\mathbf{g}}\cap\mathcal{B}_{i_2}} f_{\mathbf{Z}}(\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i_1}) d\mathbf{y} + \int_{\mathcal{B}_{i_2}^c} f_{\mathbf{Z}}(\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i_1}) d\mathbf{y}$$
(26)

with  $\mathcal{B}_{i_2} = \{\mathbf{y} : \|\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i,2}\| \le \sqrt{n(\sigma^2 + \zeta)}\}$ . Consider the second term in (26). By the triangle inequality

$$\|\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i,1}\| \ge \|\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i,2}\| - \|\mathbf{g} \circ (\mathbf{u}_{i,2} - \mathbf{u}_{i,1})\|$$

$$\ge \sqrt{n(\sigma^2 + \zeta)} - \delta'_n \ge \sqrt{n(\sigma^2 + \eta)}$$
 (27)

 $\forall \mathbf{g} \in \mathcal{A}^c_{i_1,i_2}$  for large n and  $\eta < \frac{\zeta}{2}$ , following the definition of  $\mathcal{A}_{i_1,i_2}$  and  $\mathcal{B}_{i_2}$ . We deduce that the second term in (26) is bounded by

$$\int_{\{\mathbf{y}: \|\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i,1}\| > \sqrt{n(\sigma^2 + \eta)}\}} f_{\mathbf{Z}}(\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i_1}) d\mathbf{y}$$

$$= \Pr(\|\mathbf{Z}\|^2 - \sigma^2 > n\eta) \le \frac{3\sigma^4}{n\eta^2} \le \kappa \tag{28}$$

by Chebyshev's inequality. Moving to the first integral, by the triangle inequality,  $\|\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i_1}\| \leq \|\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i_2}\| + \|\mathbf{g} \circ (\mathbf{u}_{i_1} - \mathbf{u}_{i_2})\|$ . Taking the square of both sides yields

$$\|\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i_1}\|^2 \le \|\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i_2}\|^2 + \delta_n'^2 + \frac{2\sqrt{A(\sigma^2 + \zeta)}}{n^{\frac{b}{2}}}$$

by the definition of  $A_{i_1,i_2}$  and  $B_{i_2}$ . Thus, for sufficiently large n.

$$f_{\mathbf{Z}}(\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i_1}) - f_{\mathbf{Z}}(\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i_2}) \le \kappa f_{\mathbf{Z}}(\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i_1})$$
 which, in turn, implies

$$P_{e,1}(i_1) + P_{e,2}(i_2, i_1) \ge 1 - 2\kappa - \kappa \int_{\mathcal{A}_{i_1, i_2}^c} f_{\mathbf{G}}(\mathbf{g})$$

$$\times \left[ \int_{\mathcal{D}_{i_1, \mathbf{g}} \cap \mathcal{B}_{i_1, i_2}} f_{\mathbf{Z}}(\mathbf{y} - \mathbf{g} \circ \mathbf{u}_{i_1}) d\mathbf{y} \right] d\mathbf{g} \ge 1 - 3\kappa. \quad (29)$$

Hence, the assumption is false.

By Lemma 5, we can define an arrangement of non-overlapping spheres  $S_{\mathbf{u}_i}(n,\sqrt{n\varepsilon_n'})$  of radius  $\sqrt{n\varepsilon_n'}$  centered at the codewords  $\mathbf{u}_i$ . Since the codewords all belong to a sphere  $S_0(n,\sqrt{nA})$  of radius  $\sqrt{nA}$  centered at the origin, it follows that the number of packed spheres, i.e., the number of codewords  $2^{n\log(n)R}$ , is bounded by  $2^{n\log(n)R} \leq (\frac{\sqrt{A}+\sqrt{\varepsilon_n'}}{\sqrt{\varepsilon_n''}})^n$ . Thus,

$$R \le \frac{1}{\log(n)} \log \left( \frac{\sqrt{A} + \sqrt{\varepsilon_n'}}{\sqrt{\varepsilon_n'}} \right) = \frac{\log(n+1)}{\log(n)}$$
 (30)

which tends to 1 as  $n \to \infty$ . This completes the proof of Theorem 3. Further details are given in [23].

#### ACKNOWLEDGMENTS

We gratefully thank Andreas Winter, Ning Cai, and Robert Schober for useful discussions. Mohammad J. Salariseddigh, Uzi Pereg, and Christian Deppe were supported by 16KIS1005 (LNT, NEWCOM). Holger Boche was supported by 16KIS1003K (LTI, NEWCOM) and the BMBF within the national initiative for Molecular Communications (MAMOKO) under grant 16KIS0914.

#### REFERENCES

- M. Li, H. Yin, Y. Huang, and Y. Wang, "Impact of correlated fading channels on cognitive relay networks with generalized relay selection," *IEEE Access*, vol. 6, pp. 6040–6047, 2018.
- [2] D. Tse and P. Viswanath, Fundamentals of wireless communication. Cambridge university press, 2005.
- [3] A. J. Goldsmith and P. P. Varaiya, "Capacity of fading channels with channel side information," *IEEE Trans. Inf. Theory*, vol. 43, no. 6, pp. 1986–1992, 1997.
- [4] R. Ahlswede and G. Dueck, "Identification via channels," *IEEE Trans. Inf. Theory*, vol. 35, no. 1, pp. 15–29, 1989.
- [5] S. Derebeyoğlu, C. Deppe, and R. Ferrara, "Performance analysis of identification codes," *Entropy*, vol. 22, no. 10, p. 1067, 2020.
- [6] K. Guan, B. Ai, M. Liso Nicolás, R. Geise, A. Möller, Z. Zhong, and T. Körner, "On the influence of scattering from traffic signs in vehicleto-x communications," *IEEE Trans. Vehicl. Tech.*, vol. 65, no. 8, pp. 5835–5849, 2016.
- [7] Y. Steinberg and N. Merhav, "Identification in the presence of side information with application to watermarking," *IEEE Trans. Inf. Theory*, vol. 47, no. 4, pp. 1410–1422, 2001.
- [8] S. Bush, J. Paluh, G. Piro, V. S. Rao, R. Prasad, and A. Eckford, "Defining communication at the bottom," *IEEE Trans. Mol. Biol. Multi-Scale Commun.*, vol. 1, pp. 90–96, 2015.
- [9] W. Haselmayr, A. Springer, G. Fischer, C. Alexiou, H. Boche, P. Höher, F. Dressler, and R. Schober, "Integration of molecular communications into future generation wireless networks," in 6G Wireless Summit, Levi Lapland, Finland, Mar 2019.
- [10] H. Boche and C. Deppe, "Robust and secure identification," in *Proc. IEEE Int. Symp. Inf. Th.*, 2017, pp. 1539–1543.
- [11] T. Nakano, M. J. Moore, F. Wei, A. V. Vasilakos, and J. Shuai, "Molecular communication and networking: Opportunities and challenges," *IEEE Trans. Nanobiosci.*, vol. 11, no. 2, pp. 135–148, 2012.
- [12] N. Farsad, H. B. Yilmaz, A. Eckford, C. Chae, and W. Guo, "A comprehensive survey of recent advancements in molecular communication," *IEEE Commun. Surveys Tuts.*, vol. 18, no. 3, pp. 1887–1919, 2016.
- [13] A. Ahlswede, I. Althöfer, C. Deppe, and U. Tamm (Eds.), Identification and Other Probabilistic Models, Rudolf Ahlswedes Lectures on Information Theory 6, 1st ed., ser. Found. Signal Process., Commun. Netw. Springer Verlag, 2020, vol. 15, to appear.
- [14] S. Verdú and V. K. Wei, "Explicit construction of optimal constant-weight codes for identification via channels," *IEEE Trans. Inf. Theory*, vol. 39, no. 1, pp. 30–36, 1993.
- [15] J. Bringer, H. Chabanne, G. Cohen, and B. Kindarji, "Identification codes in cryptographic protocols," in *IEEE Inf. Th. Workshop*, 2010, pp. 1–5.
- [16] W. Labidi, C. Deppe, and H. Boche, "Secure identification for gaussian channels," in *IEEE Int. Conf. Acoust. Speech Sig. Proc. (ICASSP)*, 2020, pp. 2872–2876.
- [17] R. Ahlswede and Ning Cai, "Identification without randomization," IEEE Trans. Inf. Theory, vol. 45, no. 7, pp. 2636–2642, 1999.
- [18] J. JáJá, "Identification is easier than decoding," in Ann. Symp. Found. Comp. Scien. (SFCS), 1985, pp. 43–50.
- [19] M. V. Burnashev, "On the method of types and approximation of output measures for channels with finite alphabets," *Prob. Inf. Trans.*, vol. 36, no. 3, pp. 195–212, 2000.
- [20] M. V. Burnashev, "On identification capacity of infinite alphabets or continuous-time channels," *IEEE Trans. Inf. Theory*, vol. 46, no. 7, pp. 2407–2414, 2000.
- [21] M. J. Salariseddigh, U. Pereg, H. Boche, and C. Deppe, "Deterministic identification over channels with power constraints," *submitted* to IEEE Int'l Conf. Commun. (ICC), 2020. [Online]. Available: https://arxiv.org/pdf/2010.04239.pdf
- [22] J. H. Conway and N. J. A. Sloane, Sphere packings, lattices and groups. Springer Science & Business Media, 2013, vol. 290.
- [23] M. J. Salariseddigh, U. Pereg, H. Boche, and C. Deppe, "Deterministic identification over fading channels," arXiv preprint arXiv:2010.10010, 2020. [Online]. Available: https://arxiv.org/pdf/2010.10010.pdf
- [24] F. Dressler and S. Fischer, "Connecting in-body nano communication with body area networks: Challenges and opportunities of the internet of nano things," *Nano Commun. Networks*, vol. 6, pp. 29–38, 2015.