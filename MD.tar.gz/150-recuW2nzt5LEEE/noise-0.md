# Compound Poisson Noise Sources in Diffusion-Based Molecular Communication

Ali Etemadi, Paeiz Azmi<sup>®</sup>, *Senior Member, IEEE*, Hamidreza Arjmandi<sup>®</sup>, and Nader Mokari, *Member, IEEE* 

Abstract—Diffusion-based molecular communication (DMC) is one of the most promising approaches for realizing nano-scale communications for healthcare applications. The DMC systems in in-vivo environments may encounter biological entities that release molecules identical to the molecules used for signaling as part of their functionality. Such entities in the environment act as external noise sources from the DMC system's perspective. In this paper, the release of molecules by external bio-inspired noise sources is particularly modeled as a compound Poisson process. The impact of compound Poisson noise sources (CPNSs) on the performance of a point-to-point DMC system is investigated. To this end, the noise from the CPNS observed at the receiver is characterized. Considering a simple on-off keying modulation and formulating symbol-by-symbol maximum likelihood (ML) detector, the performance of the DMC system in the presence of the CPNS is analyzed. For the special case of CPNS in a highrate regime, the noise received from the CPNS is approximated as a Poisson process whose rate is normally distributed. In this case, it is proved that a simple single-threshold detector is an optimal ML detector. Our results reveal that in general, adopting the conventional simple homogeneous Poisson noise model may lead to overly optimistic performance predictions, if a CPNS is present.

Index Terms—Diffusion-based molecular communication (DMC), biological entities, compound Poisson noise source (CPNS), compound Poisson process (CPP), maximum likelihood detector.

## I. INTRODUCTION

# A. Motivation

IFFUSION based molecular communication (DMC) is a promising approach for realizing nano communications [1]. In DMC, information is encoded in the concentration, type, and/or release time of molecules. In particular, a transmitter nanomachine releases information molecules into the environment. The released molecules move randomly via Brownian motion and, as a consequence, some molecules may be observed (received) at the receiver [2]. Specific features

Manuscript received June 21, 2018; revised November 6, 2018 and January 16, 2019; accepted February 2, 2019. Date of publication February 12, 2019; date of current version June 14, 2019. This work has been supported in part by the Iran National Science Foundation (INSF) Research Grant 95826907. The associate editor coordinating the review of this paper and approving it for publication was Y. Deng. (Corresponding author: Paeiz Azmi.)

A. Etemadi, P. Azmi, and N. Mokari are with the Department of Electrical and Computer Engineering, Tarbiat Modares University, Tehran 14115-111, Iran (e-mail: ali.etemadi@modares.ac.ir; pazmi@modares.ac.ir; nader.mokari@modares.ac.ir).

H. Arjmandi is with the Department of Electrical Engineering, Yazd University, Yazd 89195-741, Iran (e-mail: arjmandi@yazd.ac.ir).

Color versions of one or more of the figures in this paper are available online at http://ieeexplore.ieee.org.

Digital Object Identifier 10.1109/TCOMM.2019.2899092

of DMC, such as its bio-compatibility, make it attractive for healthcare applications [3]–[5]. However, the application of DMC systems in in-vivo environments faces many practical challenges and requires extensive research and development. Particularly, it is essential to analyze the impact of the biological external noise sourses on the performance of DMC systems [6].

The biological entities in the body release different types of molecules as part of their functionality. The molecule release processes of biological entities exhibit a random behavior both for the time of release and the number of the released molecules. For instance, Poisson, Gaussian, and Weibull renewal models have been proposed for the timing of the bursts in the endocrine systems [7]. In particular, for the neuroendocrine system, the secretory bursts at random time instants have been modeled as a Poisson point process [8], [9]. As another example, the release of neurotransmitters in synapses has been characterized by a doubly stochastic Poisson process [10]-[12]. Also, the numbers of molecules transported by ion channels and ion pumps across the cell membrane can be stochastically modeled as Poisson random variables (RVs) [13]. DMC systems operating in in-vivo environments may encounter biological entities that release molecules identical to the molecules used for signaling. Such entities in the environment act as external noise sources from the DMC system's perspective. Therefore, accurate modeling of such noise sources taking into account their intrinsic characteristics is crucial for comprehensive performance analysis and evaluation.

# B. Related Works

In the MC literature, different noise models have been proposed to characterize the inherent uncertainty in the release process of the molecules at the transmitter, Brownian motion, the reception process at the receiver, and environment noise. In [14], the noises introduced by the transmitter and the diffusion channel are modeled as additive Gaussian noise and are referred to as particle sampling and particle counting noise, respectively. In [15], it is shown that additive inverse Gaussian noise can be used to model the molecular timing channel where the information is encoded into the release time of the molecules into the fluid medium with drift. Arjmandi et al. [16] propose a Poisson model to characterize the noise due to the randomness of the transmitter release process and the Brownian motion in the fluid medium. Also, in [17], additive stable distribution noise is introduced to characterize molecular timing channel for different modulation schemes. In [18], a mathematical framework for modeling

0090-6778 © 2019 IEEE. Personal use is permitted, but republication/redistribution requires IEEE permission. See http://www.ieee.org/publications\_standards/publications/rights/index.html for more information.

the time-variant stochastic channels of diffusive mobile MC systems is developed. Singhal et al. [19] consider the continuous collision of molecules as source of noise leading to uncertainty in the position of the molecules. To mathematically model this noise source, the Langevin model for Brownian motion in a fluid medium is considered. The uncertainty caused by the reception process of ligand receptors is considered in [20]-[22]. Unlike for the noise introduced by the transmitter release, Brownian motion, and the reception process, less considerations has been given to the environmental noise in the DMC systems. Arjmandi et al. [16] model environmental noise by a homogeneous Poisson distribution whose parameter is equal to the average number of molecules received during a given time slot. The homogeneous Poisson noise model is more elaborately presented in [23] where the dependence of the average number of noise molecules, i.e., the parameter of the distribution, on the time-slot duration is taken into account. However, these conventional noise models which are homogeneous in space and time are not capable of accurately modeling the noise introduced by external noise sources that exhibit a random behavior for the time of release and the number of the released molecules. Noel et al. [6] analyze the expected number of molecules observed at the transparent receiver originated from the external noise sources, e.g., multiuser interference caused by the transmitters of other communication links, unintended leakage from vesicles, or the output from an unrelated biochemical process. In this work, the statistics of the emission process of the external noise source is neglected by assuming a uniform emission process and the proposed analysis focuses on the expected impact and not the complete probability density function of the impact of external noise source.

## C. Proposed Model

Considering an external noise source releasing random numbers of molecules in random time instances leads to receiver noise whose statistics differ from that of the conventional noise models. In other words, conventional noise models are not able to model the noise caused by the biological external noise source. The release process of the external noise source is particularly modeled as a compound Poisson process (CPP) where the release time events constitute points of a Poisson process and the amplitudes of the events (the number of released molecules at a release time event) are random. This model is inspired from the molecule release processes observed in some endocrine systems [7]-[9] and the release of neurotransmitters in synapses [10] which is the fundamental process that drives information transfer between the neurons in the nervous system. Noteworthy, the CPP is unable to model all biological release processes. At least, Weibull renewal process is a more general model than the CPP, for the release processes in the endocrine systems [7]. An external noise source whose release process is a CPP is referred to as a compound Poisson noise source (CPNS) in the following. The CPNS takes into account the randomness of the release events of noise source in both time and amplitude. In this paper, we provide a framework for analyzing the performance of DMC systems in the presence of the CPNS.

A point-to-point DMC system is considered in the presence of a CPNS which releases molecules of the same type as the signaling molecules. To investigate the impact of the CPNS on the communication performance, a point-to-point DMC system with simple on-off keying modulation is considered. The number of noise molecules observed at the receiver is analyzed and approximated by a Poisson mixture distribution by using the rare-event property of Poisson distributions. Considering a simple on-off keying modulation, the performance of DMC system in the presence of CPNS is analyzed. A symbol-bysymbol maximum likelihood (ML) detector is derived and bit error rate (BER) is obtained by adopting a simple singlethreshold detector (STD). For the special case of CPNS in high-rate regime (high rates of release time events), the noise received from the CPNS is approximated as a Poisson distribution whose mean is normally distributed. It is proved that the noise received from the CPNS in high-rate regime has a log-concave distribution and an STD is the optimal ML detector. For the general case of CPNS, our results report that the distribution of noise received from the CPNS may not be log-concave and can even be multimodal distribution leading to optimality of multiple-threshold detector (not a simple STD). Moreover, our particle based simulation (PBS) results confirm the obtained analytical BER expressions. Also, it is revealed that the conventional homogeneous Poisson noise model is not applicable to CPNSs and leads to overly optimistic performance estimates.

The remainder of this paper is organized as follows: In Section II, we present the DMC system model including the transmitter, receiver, channel, and CPNS models. In Section III, the distributions of the received signals due to the release of molecules by the transmitter and the CPNS are derived. The optimal ML detector and the error probability of the DMC system in the presence of a CPNS are analyzed in Section IV. In Section V, we provide simulation and numerical results. Finally, the paper is concluded in Section VI.

#### II. SYSTEM MODEL

A point-to-point DMC system is considered in the presence of a CPNS. Considering the main focus of this paper which is to characterize the effect of CPNS on the DMC, we adopt simplifying assumptions on DMC system and environment. We assume a 3-dimentioanl unbounded environment where the CPNS and transmitter are point sources and the receiver is transparent [6]. It is assumed that the receiver is at the origin of the coordinate system and is synchronized with the transmitter [24]. The transmitter and the CPNS are located at distances of  $d_T$  and  $d_C$  from the receiver, respectively; see Fig. 1. The signaling molecules and the noise molecules released by the transmitter and the CPNS, respectively, are of the same type A. Simple on-off keying modulation with timeslot duration T is adopted where bits 1 and 0 are represented by the release of N molecules (on average) and no molecule at the beginning of each time slot, respectively. Assuming transmission of bit 1, the number of molecules released by the transmitter follows a Poisson distribution with mean N [16]. The receiver is assumed to be a transparent spherical volume

![](_page_2_Picture_2.jpeg)

Fig. 1. Point-to-point DMC system in the presence of a CPNS.

of radius  $r_R$  that counts the number of molecules inside the receiver volume at sampling time  $t_s$  [25]. The receiver uses the observed sample to decide about the transmitted bit. In the rest of this section, the CPNS model is presented and the adopted channel model is described.

#### A. CPNS Model

In this subsection, we propose a CPP model for the release of molecules from an external bio-inspired noise source. A CPP or space-time Poisson process is defined as follows [26]:

Definition 1: Let N(t) denote a Poisson process characterized by RV  $n_e(t, u_t)$  representing the event arrival rate of distribution family  $u_t \in U$  at time t. Also, let RV  $Q(t, w_t)$  denote the time-dependent amplitudes due to a corresponding event at time t from the distribution family  $w_t \in W$ . Then, a general CPP is defined as the sum of the event amplitudes up to time t and is given by

$$\Pi(t) = \int_0^t Q(\tau, w_\tau) n_e(\tau, u_\tau) d\tau. \tag{1}$$

The release processes observed in secretory bursts of in some endocrine systems [7]-[9] and the release of neurotransmitters in synapses [10] coincides to CPPs. In particular, Conn et al. [8] and Keenan and Veldhuis [9] model the release process of secretory bursts by superimposing the random burst amplitudes on a Poisson process representing the timing of the secretory burst events. The authors' aim is to provide a mathematical model for neurohormone secretion for physiological investigations. Considering Definition 1, this model for secretory bursts constitutes a CPP, regardless of the release amplitude distribution. The release of neurotransmitters in synapses which is the fundamental process that drives information transfer between the neurons in the nervous system has been modeled as a doubly stochastic Poisson process in [10]. A doubly Poisson process is a Poisson process with a random arrival rate. Hence, according to Definition 1, regardless of the distribution of the release amplitudes, doubly Poisson process is a CPP.

Obviously, the CPP model is incomprehensive and unable to model all release processes in the body and hence it is practically limited. For instance, Weibull renewal process is a more general model than the CPP, for the release processes in the endocrine systems [7]. More accurately, the Weibull

renewal process could consider a range of release processes from the uncorrelated to the fully-correlated time intervals between the release events. However, the Poisson process is analytically more tractable because of its specific characteristics, e.g., thinning and memoryless properties. Besides, this specific model could give insightful ideas about more general models. Thereby, in this paper, a CPP model for an external bio-inspired noise source in MC is adopted. Such an external noise source is referred to as a CPNS.

The resulting CPNS models the randomness of the molecule release process both in time and amplitude. In particular, the molecule release times of the CPNS are modeled as a Poisson point process with rate  $n_e(t,u_t)$  and the number of molecules released at a release event,  $Q(t,w_t)$ , is also a RV, which may follow some time-dependent distribution.

We assume that the CPNS follows a special CPP where the Poisson point process representing the release times has a fixed rate of  $\lambda_e$ . This simplifying assumption is justified based on the slow variation of biological processes modulating the release rate of CPNS compared to the transmission time slot duration of DMC systems (usually in the order of seconds). Moreover, the release amplitude (the number of molecules released at the release time of the CPNS) is assumed to be a Poisson RV with parameter  $\lambda_a$ . This assumption is confirmed in [13] where the authors show that the number of molecules released by ion channels and ion pumps over the cell membrane are Poisson distributed. For better perception of the logic behind this assumption, consider a chamber including large number of molecules. If each molecule has a small probability to exit during a time interval, the total number of exiting molecules is Poisson distributed RV with mean of the average exiting molecules during the time interval. In summary, we assume a CPNS with the Poisson point process representing the release times of the fixed rate of  $\lambda_e$  where the release event amplitudes are assumed mutually independent and identical Poisson RVs, independent from the Poisson point process of the release time events.

#### B. Channel Model

In the considered DMC system, the transmitter and the CPNS release molecules into the environment. The molecules diffuse following a Brownian motion and their movements are assumed to be independent of each other. Given a molecule A having diffusion coefficient D is released in the described unbounded environment at the origin,  $\mathbf{r} = (0,0,0)$  and at time t=0, the probability that the released molecule is observed by a transparent spherical receiver with volume  $V_R = \frac{4}{3}\pi r_R^3$ , whose center is at a distance of r from the source, can be approximated as [28]:

$$p(t) = \frac{V_R}{(4\pi Dt)^{3/2}} \exp\left(-\frac{r^2}{4Dt}\right) u(t).$$
 (2)

It is obvious from (2) that the DMC channel has memory, i.e., a molecule released at the beginning of the current time slot may not be observed at the receiver in the current time slot but may be observed in one of the next time slots. Theoretically, the DMC channel has infinite memory, since p(t)

given in (2) has an infinite tail. However, from a practical perspective, a finite channel memory can be assumed [29]. To this end, we define the channel memory as the time it takes until a released molecule arrives at the receiver with a high probability which is denoted by  $\rho$  in this paper, i.e., we have

$$\int_{\tau=0}^{t_m} p(\tau)d\tau = \rho \int_{\tau=0}^{\infty} p(\tau)d\tau, \tag{3}$$

where  $t_m$  denotes the channel memory in seconds. Correspondingly,  $k = \lfloor t_m/T \rfloor$  is the channel memory in terms of the number of time slots where  $\lfloor x \rfloor$  denotes the largest integer less than or equal to x. The memories of the transmitter-to-receiver channel and the CPNS-to-receiver channel that depend on  $d_T$  and  $d_C$ , respectively, are denoted by  $k_T$  and  $k_C$ , respectively.

Remark 1: We have adopted simply an unbounded environment with point source CPNS and transparent receiver for evaluation of DMC in the presence of the CPNS in Section V. However, our proposed analysis in the rest of paper can be simply generalized for a diffusion channel in which the diffusing molecules are exposed to boundaries of biological entity, the protein receptors over the receiver surface, and/or degradation reactions in the environment. More accurately, in our analysis, the time probability densities of receiving a molecule released from the transmitter and CPNS at the receiver, i.e.,  $p_T(t)$  and  $p_C(t)$  are parameters which are adopted based on the considered system model.

## III. RECEIVED SIGNAL AT THE RECEIVER

In order to investigate the performance of the considered DMC system, the received signal has to be characterized. In other words, the distribution of the number of molecules observed at the receiver at sampling time  $t_s$  has to be obtained. The molecules observed at the receiver originate from two independent sources, namely the transmitter and the CPNS. In this section, we derive the distributions of the numbers of molecules received from the transmitter and the CPNS, respectively. Specifically, the rare-event property of the Poisson process is employed to obtain a simplified closed-form expression for distribution of the noise received from CPNS. Also, for the special case of CPNS in high-rate regime, the noise received from the CPNS is approximated by a Poisson process whose rate is normal distributed.

## A. Signal Received From Transmitter

Let  $B_0 \in \{0,1\}$  and  $B_j \in \{0,1\}, j=1,2,\cdots,k_T$ , denote the RVs representing the bits transmitted in the current time slot and the  $j^{th}$  previous time slot, respectively. Based on the system model described in Section II, to transmit bit  $B_j$ , the transmitter releases  $X_j$  molecules at the beginning of the  $j^{th}$  time slot where  $X_j|B_j=b_j\sim \operatorname{Poisson}(b_jN)$ . In other words, if  $B_j=0$ , no molecule is released and if  $B_j=1$ , the number of released molecules is Poisson distributed with parameter N. A molecule released at the beginning of the  $j^{th}$ ,  $j=0,1,\cdots,k_T$ , time slot is observed at the receiver at sampling time  $t_s$  of the current time slot with probability  $p_T(jT+t_s)$ , where  $p_T(t)$  is given in (2) after substituting

![](_page_3_Picture_9.jpeg)

Fig. 2. A schematic illustration of Poisson point process over time. The 'x' signs over the time axes represent the instances of release events.

r by  $d_T$ . Based on the thinning property of the Poisson distribution [30], the number of molecules received at the receiver due to transmission of  $B_0 = b_0$  in the current time slot,  $Y_T^c$ , is Poisson distributed with mean  $Nb_0 \ p_T(t_s)$ , i.e.,

$$p_{Y_T^c}[k|B_0 = b_0] = \exp\left(-Nb_0 p_T(t_s)\right) \frac{\left(Nb_0 p_T(t_s)\right)^k}{k!}, \quad k = 0, 1, 2, \cdots.$$
(4)

Similarly, the number of molecules observed at the receiver in the current time slot due to transmission of  $B_j=b_j$  in the  $j^{th}$  previous time slot is Poisson distributed with parameter  $Nb_jp_T(jT+t_s)$ , i.e.,  $Y_T^j|B_j=b_j\sim \mathrm{Poisson}\left(Nb_jp_T(jT+t_s)\right)$ . The number of molecules observed at the receiver in the current time slot due to transmission of all previous bits (interference) equals  $Y_T^I=\sum_{j=1}^{k_T}Y_T^j$ . Given the previous transmitted bits  $B_j=b_j, j=1,2,\cdots,k_T$ , the  $Y_T^j, j=1,\cdots,k_T$ , are independent and  $Y_T^I$  follows a Poisson distribution with mean  $N\sum_{j=1}^{k_T}b_jp_T(jT+t_s)$ , i.e., we have:

$$p_{Y_T^I}[k|\mathbf{B}_{1:k_T} = \mathbf{b}_{1:k_T}]$$

$$= \exp\left(-N\sum_{j=1}^{k_T} b_j p_T(jT + t_s)\right)$$

$$\times \frac{\left(N\sum_{j=1}^{k_T} b_j p_T(jT + t_s)\right)^k}{k!}, \quad k = 0, 1, 2, \dots, \quad (5)$$

where  $\mathbf{B}_{1:k_T} = [B_1, B_2, \cdots, B_{k_T}], \mathbf{b}_{1:k_T} = [b_1, b_2, \cdots, b_{k_T}],$  and the notation  $\mathbf{A}_{i:k}$  denotes vector  $[A_i, A_{i+1}, \cdots, A_k].$ 

#### B. Noise Received From CPNS

The memory of the channel between the CPNS and the receiver is  $k_C$  time slots. Considering the CPNS Poisson point process of release events with rate  $\lambda_e$ , the number of release events in the  $k_C$  previous time slots,  $k_CT$ , denoted by  $N_e(k_CT)$ , is a Poisson RV with mean  $\lambda_e k_CT$ . For ease of notation, in the rest of the paper, we denote  $N_e(k_CT)$  by  $N_e$ . The time elapsed since the time instant  $-k_CT+t_s$  until the  $i^{th}$  release event is denoted by  $\Theta_i$ ; see Fig. 2. Hence, the  $i^{th}$  release event occurs at time  $-k_CT+t_s+\Theta_i$ .

Given the release of a molecule by the CPNS at time 0, the probability of observing this molecule at the receiver is  $p_C(t)$ , given by (2) after substituting r by  $d_C$ . The release amplitude of the  $i^{th}$  event is Poisson distributed with parameter  $\lambda_a$ . Therefore, based on the thinning property of the Poisson distribution, the number of molecules observed at the receiver

due to the  $i^{th}$  release event of the CPNS,  $Y_C^i$ , is Poisson distributed with mean  $\lambda_a p_C(k_C T - \theta_i)$  for  $\Theta_i = \theta_i$ , i.e.,

$$Y_C^i|\Theta_i = \theta_i \sim \text{Poisson}(\lambda_a p_C(k_C T - \theta_i)).$$
 (6)

The total number of molecules observed at the receiver in the current time slot (at time  $t=t_s$ ) due to the molecule release by the CPNS during the  $k_C$  previous time slots is equal to  $Y_C = \sum_{i=1}^{N_e} Y_C^i$ . Given  $N_e = n$ , i.e., the number of release events in the  $k_C$  previous time slots is equal to n and  $\Theta_{1:n} = \theta_{1:n}, Y_C$  follows a Poisson distribution with parameter  $\lambda_a \sum_{i=1}^n p_C(k_C T - \theta_i)$ . Therefore, we can write (7), shown at the bottom of this page, where  $p_{Y_C}[\cdot]$  denotes the distribution of RV  $Y_C$ , the  $\Theta_i$ s are points of a Poisson process,  $N_e$  is the RV representing the total number of release events occurring during  $[-k_C T + t_s, t_s]$ , respectively. Also,  $f_{\Theta_{1:n}}(\theta_{1:n}|N_e = n)$  is the joint pdf of release time events  $\Theta_{1:n}$  given n events, and  $d\theta_{1:n}$  stands for  $d\theta_1 d\theta_2 \cdots d\theta_n$ . Since the points of a Poisson process,  $\Theta_{1:n}$ , form a Markov chain [31], we have:

$$f_{\Theta_{1:n}}(\theta_{1:n}|N_e = n)$$

$$= \prod_{i=1}^{n} f_{\Theta_i}(\theta_i|\theta_{i-1}, N_e = n) = f_{\Theta_1}(\theta_1|N_e = n)$$

$$\times f_{\Theta_2}(\theta_2|\theta_1, N_e = n) \cdots f_{\Theta_n}(\theta_n|\theta_{n-1}, N_e = n). \quad (8)$$

The time difference between two events of a Poisson process is exponentially distributed, which leads to:

$$f_{\Theta_i}(\theta_i|\theta_{i-1}, N_e = n) = \lambda_e e^{-\lambda_e(\theta_i - \theta_{i-1})} u(\theta_i - \theta_{i-1}), \quad (9)$$

where  $u(\cdot)$  denotes the unit step function. Therefore, (8) reduces to

$$f_{\Theta_{1:n}}(\theta_{1:n}|N_e = n) = \lambda_e^n e^{-\lambda_e \theta_n} u(\theta_n - \theta_{n-1}).$$
 (10)

Substituting  $p_{N_e}[n] = e^{-\lambda_e k_C T} (\lambda_e k_C T)^n/n!$  and applying (10) in (7), we obtain (11), shown at the bottom of this page. Generally, obtaining a closed-form expression for the integral in (11) is cumbersome. In the next subsection, the rare-event property [32] of the Poisson process is employed to obtain a simplified closed-form expression for  $p_{Y_C}[k]$ .

# C. Rare Event Based Analysis of the Noise Received From the CPNS

The rare event property of a Poisson process with parameter  $\lambda$  states that the probability of occurrence of an event in a short time interval  $\Delta t$  ( $\Delta t \ll 1/\lambda$ ) is proportional to

the duration of the interval, i.e.,  $\lambda \Delta t$ . Also, for sufficiently small  $\Delta t$ , the probability of occurrence of more than one event is negligible. As a result, the probability of no event occurring in this interval is equal to  $1 - \lambda \Delta t$  [30], [32].

For a sufficiently short time interval  $\tilde{T}$ , such that  $\lambda_e \tilde{T} \ll 1$ , the rare event property holds. Given  $\tilde{T}$ , the channel memory duration,  $k_C T$ , can be divided into  $\tilde{k}_C = \frac{k_C T}{\tilde{T}}$  distinct time intervals of length  $\tilde{T}$ . Let  $\tilde{Y}_C^i$  denote the number of molecules received in the current time slot due to the release event of the CPNS in the  $i^{th}$ ,  $i=1,\cdots,\tilde{k}_C$ , previous short time interval,  $[-(\tilde{k}_C-i+1)\tilde{T}+t_s,-(\tilde{k}_C-i)\tilde{T}+t_s]$ . Therefore, the total number of molecules received from the CPNS in the current time slot is  $Y_C = \sum_{i=1}^{k_C} \tilde{Y}_C^i$ . Because of the independence of the release time instants in distinct intervals for a Poisson process, the  $\tilde{Y}_C^i$  are mutually independent, and we have

$$p_{Y_C}[k] = p_{\tilde{Y}_C^1}[k] \otimes p_{\tilde{Y}_C^2}[k] \otimes \cdots \otimes p_{\tilde{Y}_C^{\tilde{k}_C}}[k], \qquad (12)$$

where  $\otimes$  is the convolution operator and  $p_{\tilde{Y}_{C}^{i}}[k]$  denotes the distribution of the number of molecules received in the current time slot due to the release event of the CPNS in the  $i^{th}$ ,  $i=1,\cdots,\tilde{k}_{C}$ , previous short time interval.

In the  $i^{th}$  previous short time interval, the probability of releasing no molecules is  $1-\lambda_e\tilde{T}$ . If no molecule is released, which we refer to as event  $\mathcal{F}_0^i$ , no molecule is observed at the receiver, i.e.,  $p_{\tilde{Y}_C^i}[k|\mathcal{F}_0^i]=\delta[k]$ . Otherwise, one event occurs in the  $i^{th}$  short time interval at time  $t_i$ ,  $t_i\in[-(\tilde{k}_C-i+1)\tilde{T}+t_s,-(\tilde{k}_C-i)\tilde{T}+t_s]$ , which can be modeled as a uniform RV, since the time interval is short and includes only one occurrence. Defining  $\tilde{\Theta}_i=t_i+\tilde{k}_C\tilde{T}-t_s$  (the time elapsed since time instant  $-\tilde{k}_C\tilde{T}+t_s$  until the release event at  $t_i$ ),  $\tilde{\Theta}_i$  is a uniform RV in interval  $[(i-1)\tilde{T},i\tilde{T}]$ , correspondingly. Thereby, given one event occurrence,  $\mathcal{F}_1^i$ , and the occurrence time  $\tilde{\Theta}_i=\tilde{\theta}_i$ , the number of molecules received in the current time slot follows a Poisson distribution with parameter  $\mu(\tilde{\Theta}_i)=\lambda_a p_C(k_CT-\tilde{\Theta}_i)$ , i.e.,

$$p_{\tilde{Y}_{C}^{i}}[k|\mathcal{F}_{1}^{i}] = \int_{(i-1)\tilde{T}}^{i\tilde{T}} p_{\tilde{Y}_{C}^{i}}[k|\mathcal{F}_{1}^{i}, \tilde{\theta}_{i}] \frac{1}{\tilde{T}} d\tilde{\theta}_{i}$$

$$= \int_{(i-1)\tilde{T}}^{i\tilde{T}} e^{-\mu(\tilde{\theta}_{i})} \frac{\left(\mu(\tilde{\theta}_{i})\right)^{k}}{k!} \frac{1}{\tilde{T}} d\tilde{\theta}_{i},$$

$$i = 1, 2, \dots, \tilde{k}_{C}. \tag{13}$$

(11)

$$p_{Y_{C}}[k] = \sum_{n=0}^{\infty} \int_{\theta_{1:n}} p_{Y_{C}}[k|N_{e} = n, \Theta_{1:n} = \theta_{1:n}] f_{\Theta_{1:n}}(\theta_{1:n}|N_{e} = n) p_{N_{e}}[n] d\theta_{1:n}$$

$$= \sum_{n=0}^{\infty} \int_{\theta_{1:n}} \exp\left(-\lambda_{a} \sum_{i=1}^{n} p_{C}(k_{C}T - \theta_{i})\right) \frac{\left(\lambda_{a} \sum_{i=1}^{n} p_{C}(k_{C}T - \theta_{i})\right)^{k}}{k!} f_{\Theta_{1:n}}(\theta_{1:n}|N_{e} = n) p_{N_{e}}[n] d\theta_{1:n}, \tag{7}$$

$$p_{Y_{C}}[k] = \sum_{n=0}^{\infty} \int_{\theta_{1:n}} \exp\left(-\lambda_{a} \sum_{i=1}^{n} p_{C}(k_{C}T - \theta_{i})\right) \frac{\left(\lambda_{a} \sum_{i=1}^{n} p_{C}(k_{C}T - \theta_{i})\right)^{k}}{k!} \lambda_{e}^{n} e^{-\lambda_{e}\theta_{n}} \exp\left(-\lambda_{e}k_{C}T\right) \frac{\left(\lambda_{e}k_{C}T\right)^{n}}{n!} d\theta_{1:n}.$$

Therefore, we obtain

$$p_{\tilde{Y}_{C}^{i}}[k] = p_{\tilde{Y}_{C}^{i}}[k|\mathcal{F}_{0}^{i}]p(\mathcal{F}_{0}^{i}) + p_{\tilde{Y}_{C}^{i}}[k|\mathcal{F}_{1}^{i}]p(\mathcal{F}_{1}^{i})$$

$$= (1 - \lambda_{e}\tilde{T})\delta[k] + (\lambda_{e}\tilde{T})p_{\tilde{Y}_{C}^{i}}[k|\mathcal{F}_{1}^{i}],$$

$$i = 1, 2, \cdots, \tilde{k}_{C},$$
(14)

where  $p_{\tilde{Y}_{C}^{i}}[k|\mathcal{F}_{1}^{i}]$  is given by (13). To simplify the notation, we employ  $f_{i}[k] = p_{\tilde{Y}_{C}^{i}}[k|\mathcal{F}_{1}^{i}]$  in the rest of the paper. Eq. (12) can be simplified as follows, see Appendix A,

$$p_{Y_C}[k] = \sum_{i=0}^{\tilde{k}_C} (1 - \lambda_e \tilde{T})^{\tilde{k}_C - i} (\lambda_e \tilde{T})^i$$

$$\times \sum_{h=1}^{\tilde{\kappa}_i} \delta[k] \otimes f_{\alpha_1^h}[k] \otimes \cdots \otimes f_{\alpha_i^h}[k], \quad (15)$$

where  $\mathfrak{K}_i \stackrel{\Delta}{=} \binom{\tilde{k}_C}{i}$  is the number of i-element subsets of set  $\{1,2,\cdots,\tilde{k}_C\}$ , and the elements of the  $h^{th}$  i-element subset are denoted by  $\alpha_1^h,\cdots,\alpha_i^h$ . The distribution in (15) is complicated and does not have a closed form expression when the exact distribution of  $p_{\tilde{Y}_C^i}[k]$  given in (13) is employed which is referred to as rare-event exact distribution for the noise received from the CPNS. To obtain a closed form expression, we approximate  $p_{\tilde{Y}_C^i}[k|\mathcal{F}_1^i]$  as a Poisson distribution with a fixed mean. Since  $\tilde{\Theta}_i$  is a uniform RV in interval  $[(i-1)\tilde{T},i\tilde{T}]$ , by adopting sufficiently small  $\tilde{T}$  ( $\tilde{T} \ll k_C T$ ),  $k_C T - (i-1)\tilde{T}$ , very closely approximates  $k_C T - \tilde{\Theta}_i$ . Therefore, we can approximate the mean  $\mu(\tilde{\Theta}_i)$  as follows

$$\mu(\tilde{\Theta}_i) = \lambda_a p_C (k_C T - \tilde{\Theta}_i)$$

$$\simeq \lambda_a p_C (k_C T - (i-1)\tilde{T}) \stackrel{\Delta}{=} \mu_i, \quad i = 1, 2, \cdots, \tilde{k}_C,$$
(16)

which leads to  $f_i[k] = p_{\tilde{Y}_{C}^i}[k|\mathcal{F}_1^i] \cong e^{-\mu_i} \frac{(\mu_i)^k}{k!}$ . Thereby, the convolution term in (15) is reduced to

$$f_{\alpha_0^h}[k] \otimes f_{\alpha_1^h}[k] \otimes \cdots \otimes f_{\alpha_i^h}[k]$$

$$\cong \exp\left(-\sum_{l=0}^i \mu_{\alpha_l^h}\right) \frac{(\sum_{l=0}^i \mu_{\alpha_l^h})^k}{k!}, \quad (17)$$

and hence

$$p_{Y_C}[k] = \sum_{i=0}^{\tilde{k}_C} (1 - \lambda_e \tilde{T})^{\tilde{k}_C - i} (\lambda_e \tilde{T})^i \times \sum_{h=1}^{\tilde{\kappa}_i} \exp\left(-\sum_{l=0}^i \mu_{\alpha_l^h}\right) \frac{(\sum_{l=0}^i \mu_{\alpha_l^h})^k}{k!}, \quad (18)$$

which is a Poisson mixture distribution [33], i.e.,  $p_{Y_C}[k]$  is a summation of weighted Poisson distributions where the sum of the weights is equal to 1, since

$$\sum_{i=0}^{\tilde{k}_C} (1 - \lambda_e \tilde{T})^{\tilde{k}_C - i} (\lambda_e \tilde{T})^i \mathfrak{K}_i = 1.$$
 (19)

We refer to the approximation in (18) as rare-event approximate distribution for noise received from the CPNS. Our simulation results demonstrate that the rare-event approximate

analysis very closely approaches the rare-event exact analysis in (15) for small values of  $\tilde{T}$ .

## D. Noise Received From the CPNS in the High-Rate Regime

From Subsection III-B, the number of molecules received from the CPNS at the current time slot follows a Poisson distribution with random rate  $M = \lambda_a \sum_{i=1}^{N_e} p_C(k_CT - \Theta_i)$  where  $N_e$  is a RV denoting the number of release events during the  $k_C$  previous time slots and  $\Theta_i$  denotes a RV representing the release time of the  $i^{th}$  event with respect to the beginning of the  $k_C^{th}$  previous time slot. Defining a stochastic process  $\mathbf{M}(t) = \sum_{i=1}^{N_e} \lambda_a p_C(t - \Theta_i)$ , we can write  $M = \mathbf{M}(k_CT)$ . The  $\mathbf{M}(t)$  can be interpreted as a shot-noise process passed over a linear time invariant (LTI) system with impulse response  $\lambda_a p_C(t)$  [36], [37], i.e.,

$$\mathbf{M}(t) = \sum_{i=-\infty}^{+\infty} \delta(t - \Theta_i) \otimes \lambda_a p_C(t), \tag{20}$$

where  $p_C(t)$  is given in (2) and  $\Theta_i$ s are points of a Poisson process with rate  $\lambda_e$ .<sup>1</sup> The cumulants of a shot-noise process passing from an LTI system with impulse response h(t) are time invariant which are given by [37]:

$$k_n = \lambda_e \int_{-\infty}^{+\infty} h^n(\tau) d\tau, \quad \forall \ n \ge 1.$$
 (21)

Thereby, this process is a first order strict sense stationary (SSS) process whose first order distribution function is time independent. Rice [36] shows that for high values of  $\lambda_e$  ( $\lambda_e \to \infty$ ), the first order distribution of this process approaches a Gaussian distribution with mean  $k_1$  and variance  $k_2$  given in (21). Considering  $h(t) = \lambda_a p_C(t)$  where  $p_C(t)$  is given in (2), the cumulants of  $\mathbf{M}(t)$  are obtained as follows

$$k_n = \frac{1}{n} G_1 G_2^n \Gamma(\frac{3n}{2} - 1, \frac{nd_C^2}{4Dk_C T}), \quad \forall n \ge 1,$$
 (22)

where  $G_1=\frac{\lambda_e d^2}{4D}$ ,  $G_2=\frac{\lambda_e V_R}{\pi^{3/2} d_C^3}$ , and  $\Gamma(s,x)=\int_x^\infty t^{s-1} e^{-t} dt$  denotes the upper incomplete Gamma function. Therefore, for CPNS in a high-rate regime (large values of  $\lambda_e$ ),  $(\lambda_e \to \infty)$ , M follows a Gaussian distribution with mean  $k_1$  and variance  $k_2$  given in (22), i.e.,

$$f_M(m) = (2\pi k_2)^{1/2} \exp\left(-\frac{(m-k_1)^2}{2k_2}\right),$$
 (23)

As a result, the number of molecules received from the CPNS in high rate regime,  $Y_C$ , follows a Poisson distribution with parameter  $M \sim \mathcal{N}(k_1, k_2)$ , and we can write:

$$p_{Y_C}[k] = \int_0^{+\infty} p_{Y_C}[k|m] f_M(m) dm.$$
 (24)

In Appendix B, we obtain the following closed form expression for  $p_{Y_C}[k]$ 

$$p_{Y_C}[k] = l(k_1, k_2) k_2^{(k+1)/2} D_{-k-1} \left( \sqrt{k_2} \left( 1 - \frac{k_1}{k_2} \right) \right), \quad (25)$$

 $^1 \mathrm{Since}$  we have  $p_C(t)=0$  for t<0 and  $t>k_CT$ , inclusion of  $\Theta_i<0$  or  $\Theta_i>k_CT$  in the summation of  $\mathbf{M}(t)=\sum_{i=1}^{N_e}\lambda_a p_C(t-\Theta_i)$  is allowed and equivalently we can write  $\mathbf{M}(t)=\sum_{i=-\infty}^{+\infty}\lambda_a p_C(t-\Theta_i)$ 

where

$$l(k_1, k_2) \stackrel{\Delta}{=} (2\pi k_2)^{-1/2} \exp(-k_1^2/2k_2 + k_2(1 - \frac{k_1}{k_2})^2/4),$$
(26)

and  $D_{\nu}(z)$  is the parabolic cylinder function which is defined as follows

$$D_{\nu}(z) \stackrel{\Delta}{=} 2^{\nu/2} e^{-z^2/4} \left[ \frac{\sqrt{\pi}}{\Gamma(\frac{1-\nu}{2})} {}_{1}F_{1}(-\frac{\nu}{2}, \frac{1}{2}; \frac{z^2}{2}) - \frac{\sqrt{2\pi}z}{\Gamma(-\frac{\nu}{2})} {}_{1}F_{1}(\frac{1-\nu}{2}, \frac{3}{2}; \frac{z^2}{2}) \right], \quad (27)$$

in which  ${}_1F_1(\alpha,\gamma;z)$  denotes the confluent hypergeometric function as follows:

$$_{1}F_{1}(\alpha,\gamma;z) = \sum_{n=0}^{+\infty} \frac{\Gamma(\alpha+n)\Gamma(\gamma)}{\Gamma(\alpha)\Gamma(\gamma+n)} \frac{z^{n}}{n!}.$$
 (28)

where  $\Gamma(.)$  denotes the Gamma function

#### IV. ERROR PROBABILITY ANALYSIS

In Section III, the signal received from the transmitter,  $Y_T$ , and the noise received from the CPNS,  $Y_C$ , were analyzed. In this section, we analyze the performance of a point-to-point DMC link in the presence of a CPNS in terms of the BER. The total received signal at the receiver is given by

$$Y = Y_T + Y_C = Y_T^c + Y_T^I + Y_C, (29)$$

where  $Y_T^c$  is the signal received in the current time slot due to the current transmission and  $Y_T^I$  is the interference received in the current time slot originating from transmissions in previous time slots.  $Y_T^c$  and  $Y_T^I$  are independent Poisson-distributed RVs with parameters  $Nb_0p_T(t_s)$  and  $N\sum_{j=1}^{k_T}b_jp_T(jT+t_s)$ , given  $B_0=b_0$  and  $\mathbf{B}_{1:k_T}=\mathbf{b}_{1:k_T}$ , respectively. Thereby,  $Y_T=Y_T^c+Y_T^I$  follows a Poisson distribution with parameter  $\sum_{j=0}^{k_T}NB_jp_T(jT+t_s)$ , i.e.,

$$p_{Y_T}[k|\mathbf{B}_{0:k_T} = \mathbf{b}_{0:k_T}] = \exp\left(-\sum_{j=0}^{k_T} Nb_j p_T(jT + t_s)\right) \times \frac{\left(\sum_{j=0}^{k_T} Nb_j p_T(jT + t_s)\right)^k}{k!}.$$
(30)

The noise received from the CPNS,  $Y_C$ , is a Poisson mixture given by (18). Therefore, conditioned on current and previous transmitted bits,  $\mathbf{B}_{0:k_T} = \mathbf{b}_{0:k_T}$ , the total number

of molecules observed at the receiver also follows a Poisson mixture distribution as follows:

$$p_{Y}[k|\mathbf{B}_{0:k_{T}} = \mathbf{b}_{0:k_{T}}] = \sum_{i=0}^{\tilde{k}_{C}} (1 - \lambda_{e}\tilde{T})^{\tilde{k}_{C} - i} (\lambda_{e}\tilde{T})^{i} \sum_{h=1}^{\tilde{\kappa}_{i}} e^{-\upsilon_{i}^{h}(\mathbf{b}_{0:k_{T}})} \frac{\left(\upsilon_{i}^{h}(\mathbf{b}_{0:k_{T}})\right)^{k}}{k!},$$
(31)

where  $\upsilon_i^h(\mathbf{b}_{0:k_T}) = \sum_{j=0}^{k_T} Nb_j p_T(jT+t_s) + \sum_{l=0}^i \mu_{\alpha_l^h}$ . Assuming equiprobable input bits and receiving Y=y molecules in the current time slot, a symbol-by-symbol maximum likelihood (ML) detector which has no information about the previously transmitted bits is given by [41], [42]:

$$\hat{B}_0 = \underset{b_0 \in \{0,1\}}{\operatorname{argmax}} \ p_Y[y|B_0 = b_0], \tag{32}$$

where  $p_Y[y|B_0 = b_0]$  is computed by applying the total probability law as follows:

$$p_Y[y|B_0 = b_0] = (\frac{1}{2})^{k_T} \sum_{\mathbf{b}_{1:k_T}} p_Y[y|\mathbf{B}_{0:k_T} = \mathbf{b}_{0:k_T}], \quad (33)$$

and  $p_Y[y|\mathbf{B}_{0:k_T} = \mathbf{b}_{0:k_T}]$  is given in (31).

Generally, the optimal ML detector (32) is a MTD which is characterized by m threshold values,  $\zeta_1, \zeta_2, \cdots, \zeta_m$  partitioning feasible observation space  $(y \in \mathbb{R}_+)$  and the decisions on the transmitted bit based on the observed y in all disjoint partitions determined by the threshold values. For nanomachines, which have limited resources, STDs (m = 1) are desirable. An STD, denoted by  $\Phi(y)$ , is characterized as follows:

$$\Phi(y) = \begin{cases} 0 & y < \zeta \\ 1 & y \ge \zeta, \end{cases}$$
(34)

where y is the observation and  $\zeta$  is the decision threshold. Given an STD with threshold value  $\zeta$ , the BER of the system is obtained as follows:

$$P_e = (\frac{1}{2})^{k_T} \sum_{\mathbf{b}_{1:k_T}} \Pr(E|\mathbf{B}_{1:k_T} = \mathbf{b}_{1:k_T}), \tag{35}$$

in which E is the error event  $(\hat{B}_0 \neq B_0)$  and BER conditioned to the previous transmitted bits,  $\Pr(E|\mathbf{B}_{1:k_T} = \mathbf{b}_{1:k_T})$ , is given by (36), shown at the bottom of this page, where  $\mathcal{F}_Y(\cdot)$  denotes the cumulative distribution function (CDF) of RV Y.

Considering the distribution of received signal given by (31), the BER terms  $\Pr(\hat{B}_0 = 1|B_0 = 0, \mathbf{B}_{1:k_T} = \mathbf{b}_{1:k_T})$  and  $\Pr(\hat{B}_0 = 0|B_0 = 1, \mathbf{B}_{1:k_T} = \mathbf{b}_{1:k_T})$  in (36) are calculated as (37) and (38) are shown at the top of the next page, where  $\Gamma(\delta, \sigma)$  is the incomplete Gamma function given by

$$\Pr(E|\mathbf{B}_{1:k_{T}} = \mathbf{b}_{1:k_{T}}) = \frac{1}{2}\Pr(\hat{B}_{0} = 1|B_{0} = 0, \mathbf{B}_{1:k_{T}} = \mathbf{b}_{1:k_{T}}) + \frac{1}{2}\Pr(\hat{B}_{0} = 0|B_{0} = 1, \mathbf{B}_{1:k_{T}} = \mathbf{b}_{1:k_{T}})$$

$$= \frac{1}{2}\Pr(y \ge \zeta|B_{0} = 0, \mathbf{B}_{1:k_{T}} = \mathbf{b}_{1:k_{T}}) + \frac{1}{2}\Pr(y < \zeta|B_{0} = 1, \mathbf{B}_{1:k_{T}} = \mathbf{b}_{1:k_{T}})$$

$$= \frac{1}{2}\left(1 - \mathcal{F}_{Y}(\zeta|B_{0} = 0, \mathbf{B}_{1:k_{T}} = \mathbf{b}_{1:k_{T}}) + \mathcal{F}_{Y}(\zeta|B_{0} = 1, \mathbf{B}_{1:k_{T}} = \mathbf{b}_{1:k_{T}})\right), \tag{36}$$

$$\Pr(\hat{B}_{0} = 1|B_{0} = 0, \mathbf{B}_{1:k_{T}} = \mathbf{b}_{1:k_{T}})$$

$$= \Pr(y > \zeta|B_{0} = 0, \mathbf{B}_{1:k_{T}} = \mathbf{b}_{1:k_{T}}) = \sum_{i=0}^{\tilde{k}_{C}} (1 - \lambda_{e}\tilde{T})^{\tilde{k}_{C} - i} (\lambda_{e}\tilde{T})^{i} \sum_{h=1}^{\tilde{K}_{i}} \left(1 - \frac{\Gamma(\zeta, v_{i}^{h}(b_{0} = 0, \mathbf{b}_{1:k_{T}}))}{\Gamma(\zeta)}\right), \tag{37}$$

$$\Pr(\hat{B}_{0} = 0|B_{0} = 1, \mathbf{B}_{1:k_{T}} = \mathbf{b}_{1:k_{T}})$$

$$= \Pr(y \le \zeta|B_{0} = 1, \mathbf{B}_{1:k_{T}} = \mathbf{b}_{1:k_{T}}) = \sum_{i=0}^{\tilde{k}_{C}} (1 - \lambda_{e}\tilde{T})^{\tilde{k}_{C} - i} (\lambda_{e}\tilde{T})^{i} \sum_{h=1}^{\tilde{K}_{i}} \frac{\Gamma(\zeta, v_{i}^{h}(b_{0} = 1, \mathbf{b}_{1:k_{T}}))}{\Gamma(\zeta)}, \tag{38}$$

 $\Gamma(\delta,\sigma)=\int_{\sigma}^{\infty}e^{-t}t^{\delta-1}dt$  and  $\Gamma(\delta,\sigma)/\Gamma(\delta)$  denotes the CDF of the Poisson distribution with parameter  $\sigma$ .

# A. On the Optimality of Single-Threshold Detector

In this subsection, we first prove that STD is optimal for CPNS in high-rate regime and then discuss on optimality of STD in general case.

Theorem 1: For the CPNS in the high-rate regime (large values of  $\lambda_e$ ), the optimal ML detector (32) is a single-threshold detector.

*Proof:* The detector is supposed to detect the transmitted bits 1 or 0 which is equivalent to the presence or absence of signal  $\operatorname{Poisson}(Np_T(t_s))$  which is embedded in the noise  $Y_T^I + Y_C$ .  $Y_T^I$  is Poisson distributed with mean  $\sum_{j=1}^{k_T} NB_jp_T(jT+t_s)$  independent from  $Y_C$ . For CPNS in high-rate regime, we showed in Subsection III-D that  $Y_C$ , follows a Poisson distribution with rate  $M \sim \mathcal{N}(k_1, k_2)$ . Therefore, given the previously transmitted bits,  $B_{1:k_T} = b_{1:k_T}$ , the additive noise is distributed as  $Y_{IC} = Y_T^I + Y_C \sim \operatorname{Poisson}(M')$  where  $M' \sim \mathcal{N}(k_1', k_2)$  and  $k_1' = k_1 + \sum_{j=1}^{k_T} Nb_j p_T(jT+t_s)$ . Therefore, we have

$$p_{Y_{IC}}[k] = (\frac{1}{2})^{k_T} \sum_{\mathbf{b}_{1:k_T}} \int_0^{+\infty} p_{Y_{IC}}[k|m, B_{1:k_T} = b_{1:k_T}] \times f_{M'}(m|B_{1:k_T} = b_{1:k_T}) dm, \quad (39)$$

where  $p_{Y_{IC}}[k|m, B_{1:k_T} = b_{1:k_T}] = p_{Y_{IC}}[k|m] = \exp(-m)\frac{m^k}{k!}$  and  $f_{M'}(m|B_{1:k_T} = b_{1:k_T}) = (2\pi k_2)^{-1/2} \exp\left(-\frac{(m-k_1')^2}{2k_2}\right)$ . It is easy to see that  $p_{Y_{IC}}[k|m]$  is a log-concave distribution in terms of (k,m),  $f_{M'}(m|B_{1:k_T} = b_{1:k_T})$  is log-concave distribution of  $p_{B_{1:k_T}}[b_{1:k_T}] = (\frac{1}{2})^{k_T}$  is log-concave distribution. Since pointwise multiplication of log-concave functions is log-concave [35], joint distribution of  $(Y_{IC}, M', B_{1:k_T})$ , i.e.,  $(\frac{1}{2})^{k_T} p_{Y_{IC}}[k|m, b_{1:k_T}] f_{M'}(m, b_{1:k_T})$ , is log-concave. Moreover, the marginal distributions of log-concave joint distribution is a log-concave [35]. Therefore,  $p_{Y_{IC}}[k]$  is a log-concave distribution. On the other hand, the optimal ML detector of the presence of signal embedded in the additive log-concave noise is a single-threshold detector [40].

Now, we derive the BER of the considered DMC system in the presence of CPNS in high-rate regime. Obviously, given  $\mathbf{B}_{0:k_T} = \mathbf{b}_{0:k_T}, \ Y = Y_T^c + Y_T^I + Y_C$  is a Poisson RV whose mean is  $M'' = M + \sum_{j=0}^{k_T} Nb_j p_T(jT + t_s)$ . Since  $M \sim \mathcal{N}(k_1, k_2)$ , we have  $M'' \sim \mathcal{N}(k_1'', k_2)$  in which

 $k_1'' = k_1 + \sum_{j=0}^{k_T} N b_j p_T (jT + t_s)$ . Considering (25), we can write

$$p_{Y}[k|\mathbf{B}_{0:k_{T}} = \mathbf{b}_{0:k_{T}}]$$

$$= l(k_{1}'', k_{2})k_{2}^{(k+1)/2}D_{-k-1}\left(\sqrt{k_{2}}(1 - \frac{k_{1}''}{k_{2}})\right). \quad (40)$$

Therefore, given an STD with threshold  $\zeta$ , error probability is given by

$$P_{e} = \left(\frac{1}{2}\right)^{k_{T}+1} \sum_{\mathbf{b}_{1:k_{T}}} \left(1 - \mathcal{F}_{Y}(\zeta|B_{0} = 0, \mathbf{B}_{1:k_{T}} = \mathbf{b}_{1:k_{T}}) + \mathcal{F}_{Y}(\zeta|B_{0} = 1, \mathbf{B}_{1:k_{T}} = \mathbf{b}_{1:k_{T}})\right), \quad (41)$$

where  $\mathcal{F}_Y(\cdot)$  denotes the CDF of RV Y whose pdf is given by (40). To obtain the optimal threshold value, one should minimize BER in (41) in terms of  $\zeta$ . The following simple lemma concludes that when STD is an optimal ML detector, the corresponding error probability is quasiconvex. Therefore, numerical iterative algorithms such as bisection method can be employed to obtain the optimal threshold value [34], [35].

Lemma 1: The optimal ML detector in (32) is single-threshold with optimal threshold  $\zeta_o$ , if and only if the BER in (41) is a quasiconvex function of the threshold with global minimum at  $\zeta_o$ .

*Proof:* The proof is provided in Appendix C.

Corollary 1: Obviously, when the BER is not a quasiconvex function of  $\zeta$ , it has multiple local minimum and maximum points at  $\zeta_1, \zeta_2, \dots, \zeta_m$  characterizing optimal MTD.

Optimality of STD in special case of large values of  $\lambda_e$  is borrowed from the log-concavity of normal distribution of M that results the log-concavity of  $Y_C$ . But, in the general case of CPNS, our results indicate that distributions of M and then  $Y_C \sim \text{Poisson}(M)$  may not be log-concave and may even be multimodal in some conditions. Thereby, the distributions of received signals given  $b_0 = 0$ , and 1 in (33) may have multiple intersection points and correspondingly leading to optimality of a MTD (and not an STD). Fig. 3 (Left) depicts the logarithm of distribution of noise  $Y_C$  obtained based on simulation, where  $N=2\times 10^5,\, T=0.2,\, d_T=10~\mu m,$  $d_C = 5.5 \ \mu m, \ \lambda_a = 5 \times 10^5, \ \lambda_e = 15, \ r_R = 2.2 \ \mu m.$  It is obvious that it is not a concave curve and then the logarithm of distribution of noise is not a log-concave distribution. Correspondingly, Fig. 3 (Right) shows the distributions of the number of received molecules given the transmission of bits 1 and 0 in the current time slot, i.e.,  $p_Y[k|B_0=1]$  and  $p_Y[k|B_0=0]$  given by (33), respectively. It is observed that

![](_page_8_Figure_2.jpeg)

Fig. 3. (Left) The Logarithm of CPNS noise distribution. (Right) The received signal distribution given transmission of bits 0 and 1.

 $\label{eq:table_interpolation} \mbox{TABLE I} \\ \mbox{DMC System Parameters Used in Simulations}$ 

| Parameter                                                   | Variable              | Value                                              |
|-------------------------------------------------------------|-----------------------|----------------------------------------------------|
| Diffusion coefficient                                       | D                     | $1.14 \times 10^{-9} \text{ m}^2 \text{sec}^{-1}$  |
| Time-slot duration                                          | T                     | 0.5, 0.2, 0.1, and 0.02 sec                        |
| Number of transmitted molecules for bit '1'                 | N                     | $0.5 \times 10^{5}$                                |
| Distance between transmitter and receiver                   | $d_T$                 | $4~\mu\mathrm{m}$                                  |
| Distance between CPNS and receiver                          | $d_C$                 | $6, 8, 12, 25, 50, \text{ and } 100 \ \mu\text{m}$ |
| memory of transmitter-to-receiver channel for $\rho = 0.95$ | $k_T$                 | 10                                                 |
| memory of CPNS-to-receiver channel for $\rho = 0.95$        | $k_C$                 | 15                                                 |
| CPNS release time rate                                      | $\lambda_e \tilde{T}$ | 0.001, 0.01, 0.1, 0.25 and 0.5                     |
| CPNS release amplitude rate                                 | $\lambda_a$           | $8 \times 10^6, 10^5, \text{ and } 2 \times 10^4$  |
| Receiver radius                                             | $r_R$                 | $0.5~\mu\mathrm{m}$                                |
| Number of transmitted bits for PBS                          | _                     | $10^8$ bits                                        |
| Time step for PBS                                           | $\Delta t$            | $10^{-4} \ {\rm sec}$                              |

these two distributions are bimodal and have 3 intersection points and then the optimal ML detector has 4 decision making regions which results in a MTD.

Remark 2: Based on our vast numerical and simulation results, this phenomenon rarely occurs for considered MC system in the presence of CPNS and is only theoretically of interest. Note that even for such rare scenarios, the difference between BER of the suboptimal STD and the optimal MTD would be negligible, as it is deduced from Fig. 3.

#### V. NUMERICAL AND SIMULATION RESULTS

In this section, we evaluate the performance of the point-to-point DMC system in the presence of a CPNS employing a simple OOK modulation. We have employed the PBS introduced in [43] for analysis. To perform the PBS, the time is divided into small time steps  $\Delta t$  s. The molecule locations are known and the molecules move independently in the 3- dimensional space in the PBS. In each dimension, the displacement of a molecule in  $\Delta t$  s is modeled as Gaussian distribution with zero mean and variance  $2D\Delta t$ . The DMC system parameters adopted for the analytical and simulation are given in Table I.

Fig. 4 shows the BER of the DMC system in the presence of a CPNS as a function of the time interval  $\tilde{T}$  used for the rare-event analysis obtained based on (i) the rare-event exact analysis given in (15), (ii) the rare-event approximate analysis given in (18) and (iii) PBS. The distance between the CPNS and the receiver and the corresponding channel memory are  $d_C=8~\mu m$  and  $k_C=10$ , respectively. The event amplitude of the CPNS, which we refer to as the CPNS amplitude, is set to  $\lambda_a=10^5$ . The BER curves are plotted

![](_page_8_Figure_11.jpeg)

Fig. 4. Comparison of BERs (exact, approximation, and PBS) versus time interval  $\tilde{T}$  for different values of CPNS rate  $(\lambda_e)$ .

for two different CPNS rates,  $\lambda_e=2$  and 10. We observe that both approximation and exact analytical results approach the PBS results for sufficiently short time intervals  $\tilde{T}$  for which rare-event property holds ( $\lambda_e \tilde{T} \ll 1$ ). Also, it is observed that the rare-event analysis deviates from the corresponding PBS result for higher  $\tilde{T}$  values, since the condition  $\lambda \tilde{T} \ll 1$  is not well satisfied leading to the rare event property of Poisson distribution does not hold.

Fig. 5 depicts the BERs of the DMC system in the presence of a CPNS obtained from the rare-event approximate analysis and the PBS. As observed, the PBS results confirm the proposed analysis. Also, this figure compares the BERs of the DMC system for a CPNS (the rare-event approximate analysis) and a homogeneous Poisson noise [16]. For a higher accuracy

![](_page_9_Figure_1.jpeg)

Fig. 5. BER of the DMC system in the presence of a CPNS obtained based on the rare-event approximation (confirmed by PBS) compared to the homogeneous Poisson noise assumption.

![](_page_9_Figure_3.jpeg)

Fig. 6. Distribution of M(t) in (20) obtained from simulation and normal approximation for various CPNS rate  $(\lambda_e)$ .

of rare-event analysis for the CPNS, we use very small value of  $\tilde{T}=0.002$ . To have a fair comparison, the average mean of the homogeneous Poisson noise received in the current time slot, denoted by  $\lambda_0$ , is set equal to the average number of molecules received from the CPNS in the current time slot, i.e.,

$$\hat{\lambda}_0 = \sum_{n=0}^{\infty} \int_{\theta_{1:n}} \lambda_a \sum_{i=1}^n p_C(k_C T - \theta_i) f_{\theta}(\theta_{1:n}) p_{N_e}[n] d\theta_{1:n}.$$
(42)

The BER is depicted versus the threshold value  $\zeta$  for  $\lambda_e=0.5$  and  $\lambda_e=5$ . We use  $d_C=8~\mu m$ . Fig. 5 reveals that assuming a homogeneous Poisson noise at the receiver leads to an overly optimistic performance prediction when the noise source is actually a CPNS. Therefore, homogeneous Poisson noise models are not capable of modeling CPNSs. Furthermore, a CPNS with a lower rate ( $\lambda_e=0.5$ ), results in a higher performance than a CPNS with a higher rate ( $\lambda_e=5$ ), as expected. Also, it is observed that the simulation results confirm the provided analysis.

Fig. 6 compares the distribution of  $M=\lambda_a\sum_{i=1}^{N_e}p_C$   $(k_CT-\Theta_i)$  obtained based on the simulation with normal distribution approximation  $\mathcal{N}(k_1,k_2)$  given in (23), for different values of  $\lambda_e$ . It is observed that the distribution of M approaches the normal distribution for high values of

![](_page_9_Figure_9.jpeg)

Fig. 7. BER of the DMC system versus CPNS rate  $(\lambda_e)$  obtained based on simulation and high-rate analysis.

![](_page_9_Figure_11.jpeg)

Fig. 8. BER of the DMC system in the presence of a CPNS employing the rare-event approximation analysis.

 $\lambda_e$  ( $\lambda_e > 100$ ), confirming our analysis provided in Section III-D. Correspondingly, Fig. 7 depicts the BER of the DMC system in the presence of a CPNS versus  $\lambda_e$  obtained based on Monte Carlo simulation<sup>2</sup> and analysis given in (41) which employs normal approximation of  $\mathcal{N}(k_1,k_2)$ , for different values of T=0.02,0.1. It is observed that the simulation results coincide our analysis for high values of  $\lambda_e$  ( $\lambda_e > 100$ ). As Fig. 6 confirms, Gaussian approximation is not accurate for smaller  $\lambda_e$  values which leads to the increasing gap between the BERs obtained from the high-rate analysis and simulation results. Moreover, we observe that BER increases by increasing  $\lambda_e$ .

Fig. 8 shows the BER of the DMC system in the presence of a CPNS in low and moderate rate regime ( $\lambda_e=0.5,5,10$ ) versus threshold  $\zeta$ , for various parameters including  $\lambda_a$ , N, and  $d_C$ . The rare-event approximation analysis was used. The distance between the transmitter and the receiver is fixed to  $d_T=4~\mu m$ . For all five considered scenarios, the BER is a quasiconvex function of  $\zeta$ , and considering Lemma 1, the optimal detector is a simple STD.

Fig. 9 depicts the BER of the DMC system versus CPNS amplitude rate  $(\lambda_a)$  for different values of  $d_C = 6, 12, 25, 50, 100 \ \mu m$ . As expected, by increasing the distance

 $<sup>^2</sup>$ A Monte-Carlo simulation has been employed, since applying the PBS takes very long time for large values of  $\lambda_e$ .

![](_page_10_Figure_2.jpeg)

Fig. 9. BER of the DMC system in the presence of a CPNS versus CPNS ampitude  $(\lambda_a)$  for various distances.

of the CPNS from the receiver,  $d_C$ , the BER decreases which results in a better performance. For small values of  $\lambda_a$  such as  $\lambda_a \leq 10^3$ , the performance is approximately the same for all distances as the impact of the CPNS becomes negligible for extremely low  $\lambda_a$ s. In these cases, the randomness of the diffusion channel between the transmitter and receiver is the dominant effect on the performance. On the other hand, when we have higher  $\lambda_a$  values or smaller  $d_C$ s, sensitivity of BER to both values of  $\lambda_a$  and  $d_C$  increases.

#### VI. CONCLUSION

In this paper, impact of the presence of external bio-inspired noise source for DMC system was investigated. The release of molecules by a noise source was particularly modeled as a CPP, inspired by the release processes of some biological entities. A point-to-point DMC link in the presence of a CPNS was considered. The distribution of the number of molecules received from CPNS was analyzed based on the rare event distribution and shown to be a Poisson mixture distribution. Assuming a simple on-off keying modulation, symbol-bysymbol ML detector was formulated and BER was analyzed in closed-form expressions. For special case of CPNS in high-rate regime, the noise received from the CPNS is approximated by a Poisson process whose rate is normally distributed. It was proved that the optimal ML detector is a simple STD, for CPNS in high rate regime. However, our results revealed that STD may not be the optimal ML detector, in the general case of CPNS. Moreover, based on our results, the presented model and our analysis for the DMC system performance in the presence of a CPNS is necessary and simply adopting conventional homogeneous Poisson noise model may lead to overly optimistic performance predictions. This new type of noise source introduces diffusion channel different from conventional MC channels that should be investigated from various perspectives. Analyzing the capacity of this new introduced diffusion channel in the presence of a CPNS, the extension of single CPNS source to the multiple CPNS sources, employing more complicated modulation schemes, and considering more realistic assumptions for the biological environment are left for future works. Moreover, analyzing the impact of external noise sources with more complicated release processes on the DMC system performance remains open. Also, the proposed analysis for received noise from the CPNS may be used to study hormonal uptake rate by the target entities and neural communications in the body.

# APPENDIX A EQUIVALENCE OF (12) AND (15)

It is straightforward to see that (12) and (15) are equivalent. For simplicity of presentation, we show this equivalence for special case of  $\tilde{k}_C = 3$ . Starting from (12), for  $\tilde{k}_C = 3$  we have:

$$p_{Y_C}[k] = p_{\tilde{Y}_C^1}[k] \otimes p_{\tilde{Y}_C^2}[k] \otimes p_{\tilde{Y}_C^3}[k], \tag{43}$$

Substituting  $p_{\tilde{Y}_{C}^{1}}[k]$ ,  $p_{\tilde{Y}_{C}^{2}}[k]$ , and  $p_{\tilde{Y}_{C}^{3}}[k]$  with (14) and employing  $f_{i}[k] = p_{\tilde{Y}_{C}^{i}}[k|\mathcal{F}_{1}]$ , we obtain:

$$p_{Y_C}[k] = ((1 - \lambda_e \tilde{T})\delta[k] + \lambda_e \tilde{T} f_1[k]) \otimes ((1 - \lambda_e \tilde{T})\delta[k] + \lambda_e \tilde{T} f_2[k]) \otimes ((1 - \lambda_e \tilde{T})\delta[k] + \lambda_e \tilde{T} f_3[k]) = (1 - \lambda_e \tilde{T})^3 \delta[k] + (1 - \lambda_e \tilde{T})^2 (\lambda_e \tilde{T}) \times (f_1[k] + f_2[k] + f_3[k]) + (1 - \lambda_e \tilde{T})(\lambda_e \tilde{T})^2 \times (f_1[k] \otimes f_2[k] + f_1[k] \otimes f_3[k] + f_2[k] \otimes f_3[k]) + (\lambda_e \tilde{T})^3 (f_1[k] \otimes f_2[k] \otimes f_3[k])$$
(44)

which can be rewritten as follows:

$$p_{Y_C}[k]$$

$$= (1 - \lambda_e \tilde{T})^3 \delta[k] + (1 - \lambda_e \tilde{T})^2 (\lambda_e \tilde{T}) \sum_{h=1}^3 \delta[k] \otimes f_{\alpha_1^h}[k]$$

$$+ (1 - \lambda_e \tilde{T})(\lambda_e \tilde{T})^2 \sum_{h=1}^3 \delta[k] \otimes f_{\alpha_1^h}[k] \otimes f_{\alpha_2^h}[k]$$

$$+ (\lambda_e \tilde{T})^3 (\delta[k] \otimes f_{\alpha_1^h}[k] \otimes f_{\alpha_2^h}[k] \otimes f_{\alpha_3^h}[k])$$

$$= \sum_{i=0}^3 (1 - \lambda_e \tilde{T})^{3-i} (\lambda_e \tilde{T})^i \sum_{h=1}^{\mathfrak{K}_i} \delta[k] \otimes f_{\alpha_1^h}[k] \otimes \cdots \otimes f_{\alpha_i^h}[k].$$

$$(45)$$

where  $\mathfrak{K}_i \stackrel{\Delta}{=} \begin{pmatrix} 3 \\ i \end{pmatrix}$ . This completes the proof.

# APPENDIX B DERIVING CLOSED-FORM EXPRESSION FOR $p_{Y_C}[k]$ IN THE HIGH-RATE REGIME

From (24), we have:

$$p_{Y_C}[k] = \int_0^{+\infty} e^{-m} \frac{m^k}{k!} (2\pi k_2)^{-1/2} \exp\left(-\frac{(m-k_1)^2}{2k_2}\right) dm$$

$$= \frac{(2\pi k_2)^{-1/2}}{k!} \int_0^{+\infty} m^k \exp\left(-m - \frac{(m-k_1)^2}{2k_2}\right) dm$$

$$= \frac{(2\pi k_2)^{-1/2}}{k!} e^{-k_1^2/k_2}$$

$$\times \int_0^{+\infty} m^k \exp\left(-\frac{m^2}{2k_2} - (1 - \frac{k_1}{k_2})m\right) dm. \quad (46)$$

By changing variable  $m = (2k_2)^{1/2}x$ , we obtain

$$p_{Y_C}[k] = \frac{(2\pi k_2)^{-1/2}}{k!} e^{-k_1^2/k_2} (2k_2)^{(k+1)/2} \times \int_0^{+\infty} x^k \exp\left(-x^2 - \sqrt{2k_2}(1 - \frac{k_1}{k_2})x\right) dx.$$
(47)

On the other hand we have the following integral [38], [39]:

$$\int_0^{+\infty} x^{\nu} e^{-x^2 - \gamma x} dx = 2^{-(\nu+1)/2} \Gamma(\nu+1) \times e^{\gamma^2/8} D_{-\nu-1}(\gamma/\sqrt{2}).$$
 (48)

Substituting  $\gamma = \sqrt{2k_2}(1 - \frac{k_1}{k_2})$  and  $\nu = k$  into (48) and applying (47), (25) is resulted.

# APPENDIX C THE PROOF FOR LEMMA 1

Given an STD with the threshold value of  $\zeta$ , the BER of the system is given by (35). Therefore, we have

$$\frac{\partial \mathbf{P}_e}{\partial \zeta} = \frac{1}{2} \Big( p_Y[\zeta | B_0 = 1] - p_Y[\zeta | B_0 = 0] \Big). \tag{49}$$

First we provide the direct proof, i.e., if the optimal ML detector in (32) is STD with optimal threshold  $\zeta_o$ ,  $P_e$  in (35) is necessarily quasiconvex function of  $\zeta$  with global minimum at  $\zeta_o$ : Assume that the optimal ML detector is an STD, where the optimal threshold value is  $\zeta_o$ . Considering (32) and (34), we can write  $1 = \operatorname{argmax} p_Y[\zeta|B_0 = b_0]$ , for all  $\zeta > \zeta_o$ and  $0 = \mathop{\rm argmax} p_Y[\zeta|B_0^{b_0} = b_0],$  for all  $\zeta < \zeta_o.$  Equivalently, we have  $p_Y^{b_0}[\zeta|B_0 = 1] \ge p_Y[\zeta|B_0 = 0]$  and  $p_Y[y|B_0 =$ 1]  $\leq p_Y[\zeta|B_0=0]$  for all  $\zeta > \zeta_o$  and  $\zeta < \zeta_o$ , respectively. Therefore, we can write  $p_Y[\zeta|B_0=1]-p_Y[\zeta|B_0=0]\geq 0$ and  $p_Y[\zeta|B_0=1]-p_Y[\zeta|B_0=0]\leq 0$  for all  $\zeta>\zeta_o$  and  $\zeta < \zeta_o$ , respectively. Regarding to (49),  $\partial P_e/\partial \zeta$  is positive and negative for  $\zeta > \zeta_o$  and  $\zeta < \zeta_o$ , respectively. Equivalently,  $P_e$  is decreasing function for  $\zeta < \zeta_o$  and increasing for  $\zeta > \zeta_o$ . Thereby,  $P_e$  is a quasiconvex function of  $\zeta$  which has a global minimum at  $\zeta_o$ .

Now, we provide the converse proof, i.e., if BER given in (35) is quasiconvex fucntion of  $\zeta$  with global minimum at  $\zeta_o$ , the optimal ML detector in (32) is an STD with optimal threshold  $\zeta_o$ : Assuming  $P_e$  given in (35) is quasiconvex of  $\zeta$  with a global minimum at  $\zeta_o$ ,  $\partial P_e/\partial \zeta$  is positive and negative for all  $\zeta > \zeta_o$  and  $\zeta < \zeta_o$ , respectively. Therefore, we have  $p_Y[\zeta|B_0=1]-p_Y[\zeta|B_0=0]\geq 0$  and  $p_Y[\zeta|B_0=1]-p_Y[\zeta|B_0=0]\leq 0$  for  $\zeta > \zeta_o$  and  $\zeta < \zeta_o$ , respectively, considering (49). Equivalently,  $p_Y[\zeta|B_0=1]\geq p_Y[y|B_0=0]$  and  $p_Y[\zeta|B_0=1]\leq p_Y[y|B_0=0]$  for all  $\zeta > \zeta_o$  and  $\zeta < \zeta_o$ , respectively. Therefore, we can write  $0=\operatorname{argmax} p_Y[\zeta|B_0=b_0]$ , for  $\zeta < \zeta_o$  and  $\zeta < \zeta_o$  which is equivalent to optimality of STD with threshold  $\zeta_o$ , considering (32) and (34).

#### ACKNOWLEDGMENT

The authors would like to thank Prof. Robert Schober for his valuable and constructive comments on this paper.

#### REFERENCES

- I. F. Akyildiz, F. Brunetti, and C. Blázquez, "Nanonetworks: A new communication paradigm," *Comput. Netw.*, vol. 52, no. 12, pp. 2260–2279, Aug. 2008.
- [2] M. Pierobon and I. F. Akyildiz, "A physical end-to-end model for molecular communication in nanonetworks," *IEEE J. Sel. Areas Commun.*, vol. 28, no. 4, pp. 602–611, May 2010.
- [3] I. F. Akyildiz, M. Pierobon, S. Balasubramaniam, and Y. Koucheryavy, "The Internet of bio-nano things," *IEEE Commun. Mag.*, vol. 53, no. 3, pp. 32–40, Mar. 2015.
- [4] B. Atakan, O. B. Akan, and S. Balasubramaniam, "Body area nanonet-works with molecular communications in nanomedicine," *IEEE Commun. Mag.*, vol. 50, no. 1, pp. 28–34, Jan. 2012.
- [5] Y. Chahibi, M. Pierobon, S. O. Song, and I. F. Akyildiz, "A molecular communication system model for particulate drug delivery systems," *IEEE Trans. Biomed. Eng.*, vol. 60, no. 12, pp. 3468–3483, Dec. 2013.
- [6] A. Noel, K. C. Cheung, and R. Schober, "A unifying model for external noise sources and ISI in diffusive molecular communication," *IEEE J. Sel. Areas Commun.*, vol. 32, no. 12, pp. 2330–2343, Dec. 2014.
- [7] J. D. Veldhuis, D. M. Keenan, and S. M. Pincus, "Motivations and methods for analyzing pulsatile hormone secretion," *Endocrine Rev.*, vol. 29, no. 7, pp. 823–864, Dec. 2008.
- [8] P. M. Conn, M. L. Johnson, and J. D. Veldhuis, *Quantitative Neuroen-docrinology*, vol. 28. New York, NY, USA: Academic, 1995.
- [9] D. M. Keenan and J. D. Veldhuis, "Stochastic model of admixed basal and pulsatile hormone secretion as modulated by a deterministic oscillator," Amer. J. Physiol.-Regulatory, Integrative Comparative Physiol., vol. 273, no. 3, pp. 1182–1192, Sep. 1997.
- [10] S. B. Lowen, S. S. Cash, M.-M. Poo, and M. C. Teich, "Quantal neurotransmitter secretion rate exhibits fractal behavior," *J. Neurosci.*, vol. 17, no. 15, pp. 5666–5677, Aug. 1997.
- [11] E. Balevi and O. B. Akan, "A physical channel model for nanoscale neuro-spike communications," *IEEE Trans. Commun.*, vol. 61, no. 3, pp. 1178–1187, Mar. 2013.
- [12] M. Veletić, P. A. Floor, Y. Chahibi, and I. Balasingham, "On the upper bound of the information capacity in neuronal synapses," *IEEE Trans. Commun.*, vol. 64, no. 12, pp. 5025–5036, Dec. 2016.
- [13] H. Arjmandi, A. Ahmadzadeh, R. Schober, and M. N. Kenari, "Ion channel based bio-synthetic modulator for diffusive molecular communication," *IEEE Trans. Nanobiosci.*, vol. 15, no. 5, pp. 418–432, Jul. 2016.
- [14] M. Pierobon and I. F. Akyildiz, "Diffusion-based noise analysis for molecular communication in nanonetworks," *IEEE Trans. Signal Process.*, vol. 59, no. 6, pp. 2532–2547, Jun. 2011.
- [15] K. V. Srinivas, A. W. Eckford, and R. S. Adve, "Molecular communication in fluid media: The additive inverse Gaussian noise channel," *IEEE Trans. Inf. Theory*, vol. 58, no. 7, pp. 4678–4692, Jul. 2012.
- [16] H. Arjmandi, A. Gohari, M. N. Kenari, and F. Bateni, "Diffusion-based nanonetworking: A new modulation technique and performance analysis," *IEEE Commun. Lett.*, vol. 17, no. 4, pp. 645–648, Apr. 2013.
- [17] N. Farsad, W. Guo, C.-B. Chae, and A. Eckford, "Stable distributions as noise models for molecular communication," in *Proc. IEEE Global Commun. Conf. (GLOBECOM)*, Dec. 2015, pp. 1–6.
- [18] A. Ahmadzadeh, V. Jamali, and R. Schober, "Stochastic channel modeling for diffusive mobile molecular communication systems," *IEEE Trans. Commun.*, vol. 66, no. 12, pp. 6205–6220, Dec. 2018.
- [19] A. Singhal, R. K. Mallik, and B. Lall, "Effect of molecular noise in diffusion-based molecular communication," *IEEE Wireless Commun. Lett.*, vol. 3, no. 5, pp. 489–492, Oct. 2014.
- [20] A. Einolghozati, M. Sardari, and F. Fekri, "Capacity of diffusion-based molecular communication with ligand receptors," in *Proc. IEEE Inf. Theory Workshop (ITW)*, Oct. 2011, pp. 85–89.
- [21] B. Atakan, "Passive molecular communication through ligand–receptor binding," in *Molecular Communications and Nanonetworks*. New York, NY, USA: Springer, 2014.
- [22] G. Aminian, M. Farahnak-Ghazani, M. Mirmohseni, M. Nasiri-Kenari, and F. Fekri, "On the capacity of point-to-point and multiple-access molecular communications with ligand-receptors," *IEEE Trans. Mol. Biol. Multi-Scale Commun.*, vol. 1, no. 4, pp. 331–346, Dec. 2015.
- [23] R. Mosayebi, H. Arjmandi, A. Gohari, M. Nasiri-Kenari, and U. Mitra, "Receivers for diffusion-based molecular communication: Exploiting memory and sampling rate," *IEEE J. Sel. Areas Commun.*, vol. 32, no. 12, pp. 2368–2380, Dec. 2014.

- [24] L. Felicetti, M. Femminella, G. Reali, T. Nakano, and A. V. Vasilakos, "TCP-like molecular communications," *IEEE J. Sel. Areas Commun.*, vol. 32, no. 12, pp. 2354–2367, Dec. 2014.
- [25] A. Ahmadzadeh, A. Noel, and R. Schober, "Analysis and design of multi-hop diffusion-based molecular communication networks," *IEEE Trans. Mol. Biol. Multi-Scale Commun.*, vol. 1, no. 2, pp. 144–157, Jun. 2015.
- [26] F. B. Hanson, *Applied Stochastic Processes and Control for Jump Diffusions: Modeling, Analysis, and Computation*, vol. 13. Philadelphia, PA, USA: SIAM, 2007.
- [27] J. Philibert, "One and a half century of diffusion: Fick, Einstein, before and beyond," *Diffusion Fundam.*, vol. 4, no. 6, pp. 1–19, 2006.
- [28] M. U. Mahfuz, D. Makrakis, and H. T. Mouftah, "A comprehensive study of sampling-based optimum signal detection in concentration-encoded molecular communication," *IEEE Trans. Nanobiosci.*, vol. 13, no. 3, pp. 208–222, Sep. 2014.
- [29] M. Pierobon and I. F. Akyildiz, "Capacity of a diffusion-based molecular communication system with channel memory and molecular noise," *IEEE Trans. Inf. Theory*, vol. 59, no. 2, pp. 942–954, Feb. 2013.
- [30] J. Grandell, *Mixed Poisson Processes*. Boca Raton, FL, USA: CRC Press, 1997.
- [31] D. J. Daley and D. Vere-Jones, *An Introduction to the Theory of Point Processes: General Theory and Structure of Probability and Its Applications*, vol. 2. Berlin, Germany: Springer, 2008.
- [32] J. Keilson, *Markov Chain Models––Rarity and Exponenitiality*, vol. 28. New York, NY, USA: Springer, 2012.
- [33] D. Karlis and E. Xekalaki, "Mixed Poisson distributions," *Int. Statist. Rev.*, vol. 73, no. 1, pp. 35–58, Art. no. 2005.
- [34] N. Tavakkoli, P. Azmi, and N. Mokari, "Optimal positioning of relay node in cooperative molecular communication networks," *IEEE Trans. Commun.*, vol. 65, no. 12, pp. 5293–5304, Dec. 2017.
- [35] S. Boyd and L. Vandenberghe, *Convex Optimization*. Cambridge, U.K.: Cambridge Univ. Press, 2004.
- [36] S. O. Rice, "Mathematical analysis of random noise," *Bell Syst. Tech. J.*, vol. 23, no. 3, pp. 282–332, Jul. 1944.
- [37] S. B. Lowen and M. C. Teich, "Power-law shot noise," *IEEE Trans. Inf. Theory*, vol. 36, no. 6, pp. 1302–1318, Nov. 1990.
- [38] V. H. Moll, *Special Integrals of Gradshteyn and Ryzhik: The Proofs*. vol. 2. Boca Raton, FL, USA: CRC Press, 2015.
- [39] A. Winkelbauer. (Sep. 2012). "Moments and absolute moments of the normal distribution." [Online]. Available: https://arxiv.org/abs/1209.4340
- [40] P. Prucnal and M. Teich, "Single-threshold detection of a random signal in noise with multiple independent observations, Part 2: Continuous case," *IEEE Trans. Inf. Theory*, vol. IT-25, no. 2, pp. 213–218, Mar. 1979.
- [41] B. Tepekule, A. E. Pusane, H. B. Yilmaz, C.-B. Chae, and T. Tugcu, "ISI mitigation techniques in molecular communication," *IEEE Trans. Mol. Biol. Multi-Scale Commun.*, vol. 1, no. 2, pp. 202–216, Jun. 2015.
- [42] J. G. Proakis and M. Salehi, *Digital Communications*. New York, NY, USA: McGraw-Hill, 2008.
- [43] A. Noel, K. C. Cheung, and R. Schober, "Improving receiver performance of diffusive molecular communication with enzymes," *IEEE Trans. Nanobiosci.*, vol. 13, no. 1, pp. 31–43, Mar. 2014.

![](_page_12_Picture_22.jpeg)

**Ali Etemadi** received the B.Sc. degree in electrical engineering from the University of Tabriz, Tabriz, Iran, in 2010 and the M.Sc. degree in electrical engineering majoring in communication systems from Tarbiat Modares University, Tehran, Iran, in 2012, where he is currently pursuing the Ph.D. degree with the School of Electrical and Computer Engineering. He is currently a Visiting Research Scholar with Friedrich-Alexander Universität Erlangen-Nürnberg, Erlangen, Germany. His main research interests are molecular communication, biological modeling, cognitive radio, and statistical signal processing.

![](_page_12_Picture_24.jpeg)

**Paeiz Azmi** (M'05–SM'10) was born in Tehran, Iran, in 1974. He received the B.Sc., M.Sc., and Ph.D. degrees in electrical engineering from the Sharif University of Technology, Tehran, in 1996, 1998, and 2002, respectively. From 1999 to 2001, he was with the Advanced Communication Science Research Laboratory, Iran Telecommunication Research Center (ITRC), Tehran. From 2002 to 2005, he was with the Signal Processing Research Group at ITRC. Since 2002, he has been with the Electrical and Computer Engineering Department,

Tarbiat Modares University, Tehran, where he became an Associate Professor in 2006 and he is currently a Full Professor. His current research interests include modulation and coding techniques, digital signal processing, wireless communications, and estimation and detection theories.

![](_page_12_Picture_27.jpeg)

**Hamidreza Arjmandi** received the Ph.D. degree in electrical engineering from the Sharif University of Technology, Tehran, Iran, in 2016 and the M.Sc. degree in electrical engineering majoring in communication systems from the University of Tehran, Tehran, in 2010. He is currently an Assistant Professor with the Department of Electrical Engineering, Yazd University, Yazd, Iran. His main research interests are molecular communications and nano-bio communication networks.

![](_page_12_Picture_29.jpeg)

**Nader Mokari** received the Ph.D. degree in electrical engineering from Tarbiat Modares University, Tehran, Iran, in 2014. He joined the Department of Electrical and Computer Engineering, Tarbiat Modares University, as an Assistant Professor, in 2015. He was also involved in a number of large scale network design and consulting projects in the telecom industry. His research interests include the design, analysis, and optimization of communications networks. He has also been a technical program committee member of some international conferences.