## P 9 Elliptic Problems in Nonsmooth Domains

Pierre Grisvard

![](_page_0_Picture_3.jpeg)

Society for Industrial and Applied Mathematics Philadelphia

# Elliptic Problems in Nonsmooth Domains

Books in the Classics in Applied Mathematics series are monographs and textbooks declared out of print by their original publishers, though they are of continued importance and interest to the mathematical community. SIAM publishes this series to ensure that the information presented in these texts is not lost to today's students and researchers.

#### Editor*-in*-Chief

Robert E. O'Malley, Jr., University of Washington

#### Editorial Board

John Boyd, University of Michigan Susanne Brenner, *Louisiana* State University Bernard Deconinck, *University* of Washington Leah Edelstein-Keshet, University of British Columbia William G. Faris, *University* of *Arizona* Nicholas J. Higham, *University* of Manchester Peter Hoff, University of Washington

Mark Kot, University of Washington Peter Olver, University of Minnesota Philip Protter, *CorneU* University Matthew Stephens, The University of Chicago Divakar Viswanath, *University* of *Michigan* Gerhard Wanner, L' Université *de* Genève

#### Classics *in* Applied Mathematics

C. C. Lin and L. A. Segel, Mathematics *Applied* to Deterministic *Problems* in the Natural *Sciences*

Johan G. F. Belinfante and Bernard Kolman, A *Survey* of *Lie* Groups and *Lie* Algebras with Applications and *Computational Methods*

James M. Ortega, *Numerical* Analysis: A Second Course

Anthony V. Fiacco and Garth P. McCormick, *Nonlinear Programming:* Sequential *Unconstrained* Minimization Techniques

F. H. Clarke, Optimization and Nonsmooth Analysis

George F. Carrier and Carl E. Pearson, *Ordinary Differential* Equations

Leo Breiman, Probability

R. Bellman and G. M. Wing, An *Introduction* to Invariant *Imbedding*

Abraham Berman and Robert J. Plemmons, Nonnegative *Matrices* in *the Mathematical Sciences*

Olvi L. Mangasarian, *Nonlinear* Programming

\*Carl Friedrich Gauss, *Theory* of the Combination of Observations Least *Subject to Errors: Part* One, *Part Two, Supplement.* Translated by G. W. Stewart

*U. M.* Ascher, R. *M. M.* Mattheij, and R. D. Russell, *Numerical* Solution of Boundary *Value* Problems *for Ordinary* Diff*ferential erential* Equations

K. E. Brenan, S. L. Campbell, and L. R. Petzold, *Numerical* Solution of Initial-Value Problems in Differential-Algebraic ferential-Algebraic Equations

Charles L. Lawson and Richard J. Hanson, Sol ving *Least Squares* Problems

J. E. Dennis, Jr. and Robert B. Schnabel, *Numerical Methods for Unconstrained* Optimization and Nonlinear Equations

Richard E. Barlow and Frank Proschan, *Mathematical Theory* of Reliability

Cornelius Lanczos, *Linear* Dif*ferential ferential Operators*

Richard Beliman, Introduction to Matrix Analysis, Second Edition

Beresford N. Parlett, The Symmetric Eigenvalue Problem

Richard Haberman, Mathematical Models: Mechanical Vibrations, *Population* Dynamics, *and Traffic* Flow

Peter W. M. John, Statistical Design and Analysis of Experiments

Tamer Ba§ar and Geert Jan Olsder, Dynamic Noncooperative Game Theory, Second Edition

Emanuel Parzen, Stochastic *Processes*

Petar Kokotovic, Hassan K. Khalil, and John O'Reilly, Singular *Perturbation* Methods in Control: Analysis and Design

Jean Dickinson Gibbons, Ingram Olkin, and Milton Sobel, *Selecting* and *Ordering* Populations: A *New* Statistical Methodology

James A. Murdock, *Perturbations:* Theory *and* Methods

<sup>\*</sup>First time in print.

#### Classics in Applied Mathematics (continued)

Ivar Ekeland and Roger Témam, Convex Analysis and Variational Problems

Ivar Stakgold, Boundary Value Problems *of* Mathematical Physics, Volumes I and II

J. M. Ortega and W. C. Rheinboldt, Iterative Solution *of* Nonlinear Equations in Several Variables

David Kinderlehrer and Guido Stampacchia, An *Introduction* to Variational Inequalities *and* Their Applications

F. Natterer, The Mathematics *of Computerized* Tomography

Avinash C. Kak and Malcolm Slaney, Principles *of Computerized* Tomographic Imaging

R. Wong, Asymptotic *Approximations of* Integrals

O. Axelsson and V. A. Barker, Finite Element Solution *of Boundary* Value Problems: *Theory* and Computation

David R. Brillinger, Time Series: Data Analysis *and Theory*

Joel N. Franklin, Methods *of* Mathematical Economics: Linear *and* Nonlinear Programming, Fixed-Point *Theorems*

Philip Hartman, Ordinary *Differential* Equations, *Second* Edition

Michael D. Intriligator, Mathematical Optimization *and* Economic *Theory*

Philippe G. Ciarlet, The Finite Element *Method for* Elliptic Problems

Jane K. Cullum and Ralph A. Willoughby, Lanczos Algorithms *for Large* Symmetric Eigenvalue Computations, Vol. I: *Theory*

M. Vidyasagar, *Nonlinear* Systems Analysis, *Second* Edition

Robert Mattheij and Jaap Molenaar, *Ordinary Differentialferential* Equations *in Theory and Practice*

Shanti S. Gupta and S. Panchapakesan, Multiple Decision *Procedures: Theory* and Methodology *of* Selecting and Ranking Populations

Eugene L. Allgower and Kurt Georg, Introduction to *Numerical* Continuation Methods

Leah Edelstein-Keshet, Mathematical *Models* in Biology

Heinz-Otto Kreiss and Jens Lorenz, Initial-Boundary Value Problems and the Navier-Stokes Equations

J. L. Hodges, Jr. and E. L. Lehmann, Basic *Concepts of* Probability and Statistics, *Second* Edition

George F. Carrier, Max Krook, and Carl E. Pearson, Functions *of a* Complex Variable: *Theory and Technique*

Friedrich Pukelsheim, Optimal Design *of* Experiments

Israel Gohberg, Peter Lancaster, and Leiba Rodman, Invariant Subspaces *of Matrices* with *Applications*

Lee A. Segel with G. H. Handelman, Mathematics Applied to *Continuum* Mechanics

Rajendra Bhatia, *Perturbation Bounds for* Matrix Eigenvalues

Barry C. Arnold, N. Balakrishnan, and H. N. Nagaraja, A First *Course* in *Order* Statistics

Charles A. Desoer and M. Vidyasagar, *Feedback* Systems: Input-Output *Properties*

Stephen L. Campbell and Carl D. Meyer, Generalized *Inverses of Linear* Transf*ormations* Alexander Morgan, Solving Polynomial Systems Using Continuation *for* Engineering and *Scientific* Problems

I. Gohberg, P. Lancaster, and L. Rodman, Matrix Polynomials

Galen R. Shorack and Jon A. Wellner, Empirical Processes with Applications to Statistics

Rabi N. Bhattacharya and Edward C. Waymire, Stochastic Processes with Applications

Richard W. Cottle, Jong-Shi Pang, and Richard E. Stone, The Linear Complementarity Problem

Robert J. Adler, *The Geometry of* Random Fields

Mordecai Avriel, Walter E. Diewert, Siegfried Schaible, and Israel Zang, *Generalized* Concavity

Rabi N. Bhattacharya and R. Ranga Rao, Norma.l *Approximation* and Asymptotic Expansions

Francoise Chatelin, *Spectral* Approximation *of Linear Operators*

Yousef Saad, *Numerical* Methods *for* Large Eigenvalue Problems, Revised Edition

Achi Brandt and Oren E. Livne, Multigrid Techniques: 1984 *Guide* with Applications to Fluid Dynamics, *Revised* Edition

Bernd Fischer, Polynomial Based Iteration Methods *for* Symmetric Linear Systems

Pierre Grisvard, Elliptic Problems in Nonsmooth Domains

Copyright © 2011 by the Society for Industrial and Applied Mathematics

This SIAM edition is a republication of the work first published by Pitman Publishing Inc., Marshfield, Massachusetts, in 1985.

10987654321

All rights reserved. Printed in the United States of America. No part of this book may be reproduced, stored, or transmitted in any manner without the written permission of the publisher. For information, write to the Society for Industrial and Applied Mathematics, 3600 Market Street, 6th Floor, Philadelphia, PA 19104-2688 USA.

#### Library of Congress Cataloging-in-Publication Data

Grisvard, P. (Pierre)

Elliptic problems in nonsmooth domains / Pierre Grisvard. -- SIAM ed.

p. cm. -- (Classics in applied mathematics ; 69)

Originally published: Boston: Pitman Advanced Pub. Program, 1985.

Includes bibliographical references and index.

ISBN 978-1-611972-02-3 (pbk.)

1. Boundary value problems--Numerical solutions. 2. Differential equations, Elliptic--Numerical solutions. 1. Title.

QA379.G74 2011 515'.782--dc23

2011028564

![](_page_4_Picture_15.jpeg)

1985: To Catherine, Olivier, óéatricc, and Etienne

![](_page_5_Picture_2.jpeg)

#### 2011:

To the memory of our beloved father, from béatrice, Etienne, CAS Olivier GriBvard

## **Contents**

|   | Fore                                                     | word xiii                                      |  |  |  |
|---|----------------------------------------------------------|------------------------------------------------|--|--|--|
|   | Pref                                                     | ace xv                                         |  |  |  |
| 1 | Sobolev spaces 1                                         |                                                |  |  |  |
|   |                                                          | Motivation 1                                   |  |  |  |
|   | 1.2                                                      | Boundaries 4                                   |  |  |  |
|   |                                                          | 1.2.1 Graphs and manifolds 5                   |  |  |  |
|   |                                                          | 1.2.2 Segment property and cone property 10    |  |  |  |
|   | 1.3                                                      | Spaces 14                                      |  |  |  |
|   |                                                          | 1.3.1 Euclidean space 14                       |  |  |  |
|   |                                                          | 1.3.2 Open subsets of the Euclidean space 16   |  |  |  |
|   |                                                          | 1.3.3 Manifolds 19                             |  |  |  |
|   | 1.4                                                      |                                                |  |  |  |
|   |                                                          | 1.4.1 Multiplication and differentiation 20    |  |  |  |
|   |                                                          | 1.4.2 Density results 24                       |  |  |  |
|   |                                                          | 1.4.3 Continuation, compactness and convexity  |  |  |  |
|   |                                                          | inequalities 25                                |  |  |  |
|   |                                                          | 1.4.4 Imbeddings 27                            |  |  |  |
|   |                                                          | 1.4.5 Spaces defined on polygons 33            |  |  |  |
|   | 1.5                                                      |                                                |  |  |  |
|   |                                                          | 1.5.1 Hyperplanes 36                           |  |  |  |
|   |                                                          | 1.5.2 Polygons 42                              |  |  |  |
|   |                                                          | 1.5.3 Maximal domains of elliptic operators 52 |  |  |  |
|   | 1.6                                                      |                                                |  |  |  |
|   |                                                          | 1.6.1 Normal systems 62                        |  |  |  |
|   | 1.7                                                      | A model domain with a cut 74                   |  |  |  |
| 2 | Regular second-order elliptic boundary value problems 81 |                                                |  |  |  |
|   | 2.1                                                      | Foreword 84                                    |  |  |  |
|   | 2.2                                                      | Variational solution of special problems 84    |  |  |  |
|   |                                                          | 2.2.1 Existence and uniqueness 84              |  |  |  |
|   |                                                          | 2.2.2 Smoothness 87                            |  |  |  |
|   |                                                          |                                                |  |  |  |

| X |      | CONTENTS                                                           |
|---|------|--------------------------------------------------------------------|
|   | 2.3  | A priori estimates 92                                              |
|   |      | 2.3.1 An inequality based on the duality mapping 92                |
|   |      | 2.3.2 An inequality in the half space 97                           |
|   |      | 2.3.3 A general a priori estimate 105                              |
|   | 2.4  | Existence and uniqueness, the general case 111                     |
|   |      | 2.4.1 The basic result 111                                         |
|   |      | 2.4.2 Applications of the Fredholm theory and                      |
|   |      | the maximum principle 119                                          |
|   | 2.5  | Other kinds of solutions 128                                       |
|   |      | 2.5.1 More on smoothness 128                                       |
|   |      | 2.5.2 Very weak solution 129                                       |
| 3 | Seco | ond-order elliptic boundary value problems in convex               |
|   | dom  | ains 132                                                           |
|   | 3.1  | A priori estimates and the curvature of the boundary 132           |
|   |      | 3.1.1 An identity based on integration by parts 133                |
|   |      | 3.1.2 A priori inequalities for the Laplace operator revisited 138 |
|   |      | 3.1.3 A priori inequalities for more general operators 142         |
|   | 3.2  | Boundary value problems in convex domains 147                      |
|   |      | 3.2.1 Linear boundary conditions 147                               |
|   |      | 3.2.2 Nonlinear boundary conditions (review) 151                   |
|   |      | 3.2.3 Nonlinear boundary conditions (continued) 156                |
|   |      | 3.2.4 Oblique boundary conditions 167                              |
|   | 3.3  | Boundary value problems in domains with turning points 174         |
| 4 |      | ond-order elliptic boundary value problems in polygons 182         |
|   |      | Foreword 182                                                       |
|   | 4.2  |                                                                    |
|   |      | 4.2.1 Explicit solution by Fourier transform and                   |
|   |      | consequences 184                                                   |
|   |      | 4.2.2 $L_p$ bounds for the second derivatives of the solution 189  |
|   | 4.3  | Bounds in a polygon 194                                            |
|   |      | 4.3.1 The $L_2$ case 194                                           |
|   |      | 4.3.2 The $L_p$ case $(p \neq 2)$ 199                              |
|   | 4.4  | The Fredholm alternative 208                                       |
|   |      | 4.4.1 The semi-Fredholm properties 208                             |
|   |      | 4.4.2 The adjoint problem 217                                      |
|   |      | 4.4.3 The Fredholm alternative for variational                     |
|   |      | problems 226                                                       |
|   |      | 4.4.4 The Fredholm alternative for nonvariational                  |

problems 234

|   |                   | CONTENTS                                                    |  |  |  |
|---|-------------------|-------------------------------------------------------------|--|--|--|
| 5 | Mor               | e singular solutions 249                                    |  |  |  |
| • | 5.1               |                                                             |  |  |  |
|   |                   | 5.1.1 Special data 250                                      |  |  |  |
|   |                   | 5.1.2 A trace theorem 256                                   |  |  |  |
|   |                   | 5.1.3 More singular solutions 261                           |  |  |  |
|   | 5.2               | Operators with variable coefficients 265                    |  |  |  |
| 6 | Resi              | ults in spaces of Hölder functions 274                      |  |  |  |
|   |                   | Foreword 274                                                |  |  |  |
|   |                   | A brief review of Hölder spaces 275                         |  |  |  |
|   | 6.3               |                                                             |  |  |  |
|   |                   | revisited 282                                               |  |  |  |
|   |                   | 6.3.1 The Schauder inequality 282                           |  |  |  |
|   |                   | 6.3.2 Smoothness 287                                        |  |  |  |
|   | 6.4               | Second-order elliptic problems in polygons revisited 289    |  |  |  |
|   |                   | 6.4.1 The Schauder inequality in an infinite strip 289      |  |  |  |
|   |                   | 6.4.2 The Schauder inequality in a polygon and its          |  |  |  |
|   |                   | consequences 295                                            |  |  |  |
| 7 | Αn                | odel fourth-order problem 301                               |  |  |  |
|   | 7.1               | -                                                           |  |  |  |
|   | 7.2               |                                                             |  |  |  |
|   |                   | 7.2.1 Kondratiev's method in weighted spaces 305            |  |  |  |
|   |                   | 7.2.2 Getting rid of the weights 321                        |  |  |  |
|   | 7.3               | Singular solutions, the $L_p$ case 328                      |  |  |  |
|   |                   | 7.3.1 A priori inequalities 328                             |  |  |  |
|   |                   | 7.3.2 Smoothness 335                                        |  |  |  |
|   |                   | 7.3.3 The related Stokes problem 340                        |  |  |  |
| 8 | Miscellaneous 345 |                                                             |  |  |  |
|   | 8.1               | The Dirichlet problem for a strongly nonlinear equation 345 |  |  |  |
|   | 8.2               | Some three-dimensional results (an outline) 356             |  |  |  |
|   |                   | 8.2.1 Edges 357                                             |  |  |  |
|   |                   | 8.2.2 Conical points and vertices 361                       |  |  |  |
|   | 8.3               |                                                             |  |  |  |
|   | 8.4               | The numerical solution of elliptic problems with            |  |  |  |
|   |                   | singularities 384                                           |  |  |  |
|   |                   | 8.4.1 Weighted spaces and mesh refinements 384              |  |  |  |
|   |                   | 8.4.2 Augmenting the space of trial functions 394           |  |  |  |
|   |                   | 8.4.3 Calculating the stress intensity factor 396           |  |  |  |

Bibliography 400

Index 409

## Foreword

Since the publication of Pierre Grisvard's monograph in 1985, the theory of elliptic problems in nonsmooth domains has become increasingly important for research in partial differential equations and their numerical solutions. While significant advances have occurred during the last two decades, Grisvard's monograph remains an excellent introduction to the subject and a good source for the basic material.

1 had the good fortune to obtain one of the last available copies of this monograph in the early 1990s just before it went out of print, and it has become a regular reference in my work ever since. 1 am, therefore, delighted to be able to play a role in bringing this monograph back into print in the SIAM Classics in Applied Mathematics series. 1 hope a new generation of mathematicians will also find it useful.

Susanne C. Brenner Louisiana State University June 2011

### **Preface**

In this book, we focus our attention on elliptic boundary value problems in domains with nonsmooth boundaries and problems with mixed boundary conditions. So far this topic has been mainly ignored. Indeed most of the available mathematical theories about elliptic boundary value problems deal with domains with very smooth boundaries; few of them deal with mixed boundary conditions. However, the majority of the elliptic boundary value problems which arise in practice are naturally posed in domains whose geometry is simple but not smooth. These domains are very often three-dimensional polyhedra. For the purpose of solving them numerically these problems are usually reduced to two-dimensional domains. Thus the domains are plane polygons and the boundary conditions are mixed. Accordingly this book is primarily intended for mathematicians working in the field of elliptic partial differential equations as well as for numerical analysts and users of such elliptic equations.

Perhaps the main feature of elliptic boundary value problems in a domain with smooth boundary is the so-called 'shift theorem'. Let us describe it on the simplest example, the Dirichlet problem for the Laplace equation. This will be our model problem throughout this introduction. Accordingly we consider a function u which is a solution of the equation

$$\Delta u = f \tag{1}$$

in a bounded open subset  $\Omega$  of the two-dimensional Euclidean space  $R^2$ . Here the function f is given and we assume that u coincides with some smooth given function g on the boundary  $\Gamma$  of  $\Omega$ . The shift theorem can be phrased in the framework of either the Sobolev spaces or the Hölder spaces. Here, for simplicity, we describe only the Sobolev version.

We denote by  $W_p^m(\Omega)$  the space of those functions defined in  $\Omega$  whose derivatives up to the order m have their pth power integrable in  $\Omega$ . We assume that p is strictly greater than 1 and is finite. For the time being, we also assume that the boundary of  $\Omega$  is smooth, i.e. is a  $C^\infty$  manifold. Then when f is given in  $W_p^m(\Omega)$ , the corresponding solution u of the

problem (1) belongs to  $W_p^{m+2}(\Omega)$ . In other words the order of the Sobolev space is shifted from m to m+2, by the inverse operator of  $\Delta$ .

The particular case when p=2 has a simpler proof and is usually the only one needed by numerical analysts. However, the general case when p is allowed to differ from 2 (especially p large) is useful when one studies nonlinear boundary value problems by some kind of linearization or fixed point method. Most of the current error estimates for the numerical solution of an elliptic boundary value problem rely on this shift theorem. Therefore it is particularly important to know whether or not the same result holds for boundary value problems in a domain with a nonsmooth boundary.

From now on let us assume that  $\Omega$  has one corner. For convenience we assume that this corner is at the origin of  $\mathbb{R}^2$  and that, in some neighbourhood of the corner,  $\Omega$  coincides with the sector

$$G = \{(r \cos \theta, r \sin \theta); r > 0, 0 < \theta < \omega\}$$

in the usual polar coordinates, where  $\omega$  is the size of the angle at the origin. Otherwise we assume that  $\Gamma$  is smooth. For each positive integer k, we define a function  $u_k$  in the following way:

$$u_k = r^{k\pi/\omega} \sin(k\pi\theta/\omega)$$

when  $k\pi/\omega$  is not an integer and

$$u_k = r^{k\pi/\omega} \{ \ln r \sin (k\pi\theta/\omega) + \theta \cos (k\pi\theta/\omega) \}$$

when  $k\pi/\omega$  is an integer. It is readily seen that  $u_k$  is harmonic in  $\Omega$  (thus  $f_k = \Delta u_k = 0$ ) and that  $u_k$  coincides with a smooth function  $g_k$  on  $\Gamma$ . Indeed  $u_k$  vanishes on  $\Gamma$  near the origin when  $k\pi/\omega$  is not an integer, while it vanishes on one side of G (for  $\theta = 0$ ) and coincides with the polynomial  $(-1)^k \omega r^{k\pi/\omega}$  on the other side of G (for  $\theta = \omega$ ) when  $k\pi/\omega$  is an integer. Consequently if the shift theorem were valid on  $\Omega$ ,  $u_k$  ought to belong to the intersection of all the Sobolev spaces on  $\Omega$ . This would imply that  $u_k$  has all its derivatives of all orders continuous in the closure of  $\Omega$  by the well-known Sobolev imbedding theorem. However, it is easy to check from the explicit formula above for  $u_k$ , that  $u_k$  is l times continuously differentiable if and only if l is strictly smaller that  $k\pi/\omega$ . A little extra work shows that  $u_k$  belongs to the Sobolev space  $W_p^l(\Omega)$  if and only if its Sobolev exponent l-2/p is strictly smaller than  $k\pi/\omega$ , again.

So much for the shift theorem when  $\Omega$  has a corner. Surprisingly enough, the functions  $u_k$  are all we need to formulate an alternative statement. Indeed, when f is given in  $W_p^m(\Omega)$ , the corresponding solution u of the problem (1) has the following property: there exist numbers  $c_k$  such that

$$u - \sum c_k u_k \in W_p^{m+2}(\Omega)$$

where the k in the summation ranges over all integers such that

$$\pi/\omega \leq k\pi/\omega \leq m+2-2/p$$
,

provided the Sobolev exponent m+2-2/p is not an integer itself. The limitation on k in the summation means that we exclude the  $u_k$  which belong to the space  $W_p^{m+2}(\Omega)$ . This result demonstrates that the solution has the usual regularity far from the corner while it describes accurately the behaviour near the corner of that part of the solution which does not belong to the required space.

The terms in the expansion of u above coincide with the terms in the formal power series derived by Lehman (1959).

The above modified version of the shift theorem does not express a regularity result in the whole of  $\Omega$ . Thus the following question remains open: under which assumptions of f does the solution u belong to  $W_p^{m+2}(\Omega)$ ? In other words when do the coefficients  $c_k$  vanish? These are continuous linear functionals of the data f and g. It turns out that they are local functionals if and only if  $k\pi/\omega$  is an integer. This means that they only depend on the restriction of the data f and g to any neighbourhood of the corner. For instance we have

$$c_1 = f(0, 0)/\pi$$

when  $\omega = \pi/2$ . On the other hand when  $k\pi/\omega$  is not an integer the functional  $c_k$  is global; this means that  $c_k$  may not vanish even when the data f and g are zero near the corner. As a consequence the functional  $c_k$  depends on the geometry of  $\Omega$  far from the corner and it is not possible to make it explicit in such a general case.

Deriving similar modified shift theorems for various boundary value problems is what this book is about. Let us now proceed with a detailed description of the various chapters.

#### Chapter 1

The properties of the Sobolev spaces have been thoroughly investigated even when they are defined on very rough domains. We review the only properties we need without proofs and rely on the well-known book by Nečas (1967) for the proofs and references. In dealing with boundary value problems, one cannot skip a preliminary study of the boundary values of the functions belonging to Sobolev spaces. Very little is available about this question when the boundary is a polygon, although a complete answer has been given by Nikol'skii (1956, 1958), in the framework of slightly different spaces more suitable in the approximation theory. Accordingly we describe completely the boundary properties of

xviii PREFACE

functions belonging to Sobolev spaces on domains with polygonal boundaries. We include the proofs which turn out to be very similar to Nikol'skii's proofs. Some extensions of the classical Green formula are also worked out in the spirit of Lions and Magenes (1963) in the more general case of nonsmooth domains. This is why Chapter 1 is surprisingly long.

#### Chapter 2

As a first step toward the generalization of the classical shift theorem, we attempt to find the minimal assumptions under which one of the classical methods of proof can be worked out. Our technique is to look at the problem locally, flatten the boundary by a change of variables, freeze the coefficients and use partial Fourier transforms. Basically this is the method followed in Agmon et al. (1959). It turns out that the minimal assumption under which one obtains solutions in the Sobolev space  $W_p^m(\Omega)$  is that the boundary  $\Gamma$  is of class  $C^m$ . This means that  $\Gamma$  can be locally represented as the graph of a  $C^m$  function. Actually one can allow a boundary of class  $C^{m-1,1}$ . Consequently a variational solution to a second-order boundary value problem is shown to belong to  $W_p^2(\Omega)$  provided the boundary is at least of class  $C^{1,1}$  This assumption does not allow a polygonal boundary. We recall that  $C^{1,1}$  denotes the class of the functions with Lipschitz first derivatives.

#### Chapter 3

The classical method outlined above includes the proof of an *a priori* estimate which looks roughly like this:

$$\int_{\Omega} \left| \frac{\partial u}{\partial x_i \, \partial x_i} \right|^p \, \mathrm{d}x \le C \int_{\Omega} |\Delta u|^p \, \mathrm{d}x + \text{lower-order terms.}$$
 (2)

Usually we have very poor control of the constant C involved in this inequality. This is due to the local character of the method of proof. However in the case when p=2, an alternative proof based on integration by parts leads to a very accurate evaluation of the constant C. This is achieved under very general (possibly nonlinear) boundary conditions on u, in any n-dimensional domain. Such a proof (for the Dirichlet boundary condition) goes back to Caccioppoli (1950–51). It turns out that the constant C depends only on the negative part of the curvature of  $\Gamma$  (roughly speaking). This allows one to take limits with respect to the domain  $\Omega$  and to prove some regularity results in general convex domains as well as in domains with turning points. Such a technique has been used for the first time by Kadlec (1964).

#### Chapters 4 and 5

These chapters are devoted to the proof of a modified shift theorem similar to the one outlined at the beginning of this introduction for general boundary value problems for the Laplace equation in a plane polygon. On each side of the polygon, the condition is either a Dirichlet or a Neumann or an oblique boundary condition. In Chapter 4 we prove the regularity of the second derivatives of the solution, while Chapter 5 focuses on the higher derivatives. In addition, some boundary value problems involving operators with variable coefficients as well as nonhomogeneous operators are investigated.

#### Chapter 6

The same boundary value problems as in Chapters 4 and 5 are investigated in the framework of the spaces *C"` - `* <sup>T</sup>*(Q),* i.e. the space of the functions which are m times continuously differentiahle and whose derivatives of order *ni* fulfil a uniform Hölder condition of order o- throughout *n* (0<o- <l).

#### Chapter 7

This chapter is focused on the Dirichlet problem for the biharmonie equation in a plane polygon. We have chosen this particular problem as our model fourth-order problem because of its importance in several physical questions (bending of platen, elasticity, fluid dynamics). Again we prove a suitably modified shift theorem in the Sobolev spaces W (Q ). We follow very closely the method of Kondratiev (1 967a) when p = 2. The shift theorem is also reformulated for the linear Stokes system and for the stationary Navier—Stokes equations in a plane polygon.

#### Chapter 8

This chapter includes miscellaneous topics all closely related to the content of the previous chapters.

First, the Dirichlet problem for a strongly nonlinear elliptic equation in a convex plane polygon is solved by applying a classical global inversion theorem following a work by Najmi (1978). The method relies strongly on the results of Chapters 4 and 5.

The method of Chapter 3 is adapted to the heat equation for a domain which is not time-like (with only one space variable for simplicity). Here we follow a work by Sadallah (1976, 1977, 1978).

The third section of Chapter 8 describes without complete proofs the few results about the behaviour of the solution of a second-order boundary value problem in a three-dimensional polyhedron.

Finally the fourth section is devoted to the consequences of the results of the previous chapters for the numerical analysis of boundary value problems.

Singular solutions like the  $u_k$  above have a strong polluting effect on the classical finite element methods. This difficulty is usually overcome in two main ways which are described in this section. The first consists (in a few words) in augmenting the usual spaces of trial functions by the addition of some of the singular solutions which have been explicitly calculated here.

The second relies on mesh refinements near the corners. Again the way the mesh has to be refined is governed by the behaviour of the singular solutions near the corners. We give here an analysis of the related error estimates.

In conclusion, let me acknowledge that this book has been strongly influenced by the outstanding paper by Kondratiev about general elliptic boundary value problems in domains with conical points.

I wish to express my gratitude to the many mathematical colleagues in the Universities of Algiers, Maryland and Nice, with whom I have had so many fruitful talks.

Finally I wish to express my sincere appreciation to Pitman Publishing for their most efficient handling of the publication of this book.

Nice P.G. August. 1984

1

## Sobolev spaces

#### 1.1 Motivation

Why do mathematicians use Sobolev spaces instead of the simpler looking spaces of continuously differentiable functions?

The most famous Sobolev space is H' (,l ), the set of all functions u which are square integrable, together with all their first derivatives, in ,l, an open subset of R", the usual n-dimensional Euclidian space. The derivatives are to be understood in the sense of distributions. It is not even true that any function in *H'(Q)* is continuous. For instance, the function

$$u(x, y) = \left| \ln \frac{1}{2} (x^2 + y^2) \right|^{1/3}$$

is in *H' (,l, ),* where *(2* is the unit circle in the plane:

$$\Omega_1 = \{(x, y) \in \mathbb{R}^2, x^2 + y^2 < 1\}.$$

However, u is not continuous at (0, 0) and not even bounded. Such spaces are obviously not easy to handle.

There are several reasons that lead us to use such spaces. The most significant is perhaps that they appear naturally in the solution of elliptic boundary value problems by the method of calculus of variations. The variational approach to the Dirichlet problem in (2 (with n = 2, say) is the following. Given a function *f* in (2, we want to find a function *u,* also defined in (2, a solution of

$$D_x^2 u(x, y) + D_y^2 u(x, y) = f(x, y)$$
 for all  $(x, y) \in \Omega$ , (1,1,1)

with the boundary condition

$$u(\mathbf{x}, \mathbf{y}) = 0$$
 for all  $(\mathbf{x}, \mathbf{y}) \in \partial \Omega$ . (1,1,2)

We now try to view equation (1,1,1) as the equation of a critical point u for

some functional. One possible functional is obviously

$$u \mapsto F(u) = \frac{1}{2} \int_{\Omega} [|D_x u|^2 + |D_y u|^2] dx dy + \int_{\Omega} f u dx dy.$$
 (1,1,3)

If we assume that f is continuous, then F is a differentiable functional over V, the space of all functions which are continuous together with their first and second derivatives in ^l and which vanish on the boundary afi. The Frechet derivative of F at u is

$$v \mapsto \langle F'(u), v \rangle = \int_{\Omega} \left[ D_{x} u D_{x} v + D_{y} u D_{y} v \right] dx dy + \int_{\Omega} f v dx dy,$$

or, after integrating by parts

$$v \mapsto \langle F'(u), v \rangle = \int_{\Omega} \left[ -D_x^2 u - D_y^2 u + f \right] v \, \mathrm{d}x \, \mathrm{d}y. \tag{1,1,4}$$

Consequently, if u is a critical point for F, then u is solution of equation (1,1,1); u fulfils the boundary condition (1,1,2), simply because it is an element of V. Now our initial problem is converted into the problem of finding critical points for F. Obviously F is a convex quadratic functional on V; its minima are critical points, provided they exist. Usually a minimum is obtained by considering a minimizing sequence. This means a sequence up,, n = 1, 2,... in V such that

$$F(u_n) \searrow m \tag{1.1.5}$$

where

$$m = \inf_{u \in V} F(u).$$

From (1,1,5), it follows that D<sup>X</sup> u,t and Dun, n = 1, 2,... are bounded sequences in *L<sup>2</sup> (Q ),* the space of all square integrable functions on (2. Taking in account the boundary condition, an integration shows that u,, *n = 1, 2,...* is also a bounded sequence in *L<sup>2</sup> (D).*

We conclude, by using the property of bounded sequences in Hilbert space, that there exists a subsequence which is weakly convergent. Consequently, there exist

$$u, v_1, v_2 \in L_2(\Omega),$$

such that

$$\begin{cases} u_n \to u \\ D_x u_n \to v_1 \\ D_y u_n \to v_2 \end{cases}$$

weakly in  $L_2(\Omega)$ . The theory of distributions shows that  $v_1 = D_x u$  and  $v_2 = D_y u$ , and therefore u is an element of the Sobolev space  $H^1(\Omega)$ .

Summing up, we have first replaced the original problem (1,1,1) (1,1,2) by the problem of finding a minimum for the functional F defined by (1,1,3). This was achieved in the space V, i.e. in the framework of spaces of twice continuously differentiable functions. Then the construction of a minimum for F leads to considering a sequence of functions in V (and, consequently, in  $C^2(\bar{\Omega})$ ) which does not converge in  $C^2(\bar{\Omega})$  but which is convergent in the weak topology of  $H^1(\Omega)$ . Its limit appears naturally as an element of  $H^1(\Omega)$ .

Actually, it can be proved that there exists a continuous f such that u, the solution of (1,1,1) (1,1,2), does not belong to  $C^2(\Omega)$ . Indeed, assume the contrary, then the mapping

$$f \mapsto D_x D_y u \tag{1.1.6}$$

would be a linear mapping from  $C^0(\bar{\Omega})$  into itself; here we denote by  $C^0(\bar{\Omega})$ , the space of all continuous functions in  $\bar{\Omega}$  equipped with the maximum norm. It follows from the closed graph theorem that (1,1,6) is a continuous mapping. Consequently, there exists a measure  $d\mu$  on  $\bar{\Omega}$  such that

$$D_{\mathbf{x}}D_{\mathbf{y}}u(0,0) = \int_{\Omega} f \,\mathrm{d}\mu.$$
 (1,1,7)

However, the solution u of problem (1,1,1) (1,1,2) is well known for some particular domains  $\Omega$ . For instance, when  $\Omega_1$  is the unit circle, following Courant and Hilbert (1962) we have

$$u(x, y) = \iint_{\Omega_1} K(x, y; \xi, \eta) f(\xi, \eta) d\xi d\eta.$$

where

$$K(x, y; \xi, \eta) = +\frac{1}{2\pi} \log \frac{r_1}{r_2} - \frac{1}{2\pi} \log \rho$$

$$r_1 = \sqrt{[(x - \xi)^2 + (y - \eta)^2]}, \qquad \rho = \sqrt{(\xi^2 + \eta^2)}$$

$$r_2 = \sqrt{[(x - \xi/\rho^2)^2 + (y - \eta/\rho^2)^2]}.$$

It follows that

$$D_{x}D_{y}K(0,0;\xi,\eta) = \frac{1}{\pi}\xi\eta\frac{1-\rho^{4}}{\rho^{4}}$$

and this is a singular kernel at the origin. Consequently,  $D_x D_y u(0,0)$  is

given by the singular integral

$$D_{\mathbf{x}}D_{\mathbf{y}}u(0,0) = \lim_{\epsilon \to 0} \frac{1}{\pi} \iint_{\epsilon < \rho \le 1} \xi \eta \frac{1 - \rho^4}{\rho^4} f(\xi, \eta) \, \mathrm{d}\xi \, \mathrm{d}\eta. \tag{1.1.8}$$

This is in contradiction with (1,1,7).

Now we have at least one good reason for using the space  $H^1(\Omega)$ ; but, what about spaces of functions with more square integrable derivatives? And, what about spaces of functions of which certain derivatives have pth power integrable for some p, with  $1 \le p < \infty$ ? The former appear in the variational method for solving equations of order higher than two, while the latter appear in the solution of nonlinear equations.

There are, of course, several other reasons for using Sobolev spaces in the solution of partial differential equations and boundary value problems. One of them is simply the property that the Fourier transform converts any partial differential equation with constant coefficients into a division problem. Plancherel's theorem allows one to handle functions with square integrable derivatives. Unfortunately, there is no counterpart of Plancherel's theorem for continuous functions. Consequently, the solutions are built in Sobolev spaces first and their differentiability properties in the classical sense are obtained through the so-called imbedding theorems (see Section 1.4.4).

To end this introductory section, let us define the scope of this chapter about Sobolev spaces. There is a tremendous amount of literature available concerning Sobolev spaces. Most of it is quoted in Avantaggiati (1975) and Triebel (1978), for instance. However, we shall mainly work with spaces defined on domains whose boundaries are polygons or polyhedras. On such domains, Sobolev spaces happen to have some strange properties, which are hard to find in the current literature. Consequently, the guideline that we shall follow throughout this chapter is to cite only those properties which are easy to find elsewhere and to give precise references for their proofs (most of them are to be found in Nečas (1967)). Meanwhile we shall give precise statements together with complete proofs for all those properties that we need and whose proofs are too scattered in the present literature. As far as only definitions and statements of properties are concerned, we attempt to make this chapter self-contained.

#### 1.2 Boundaries

The properties of functions in a given Sobolev space,  $H^1(\Omega)$  for instance, depend very strongly on the properties of the boundary  $\Gamma$  of the domain  $\Omega$ . Several different points of view have been followed by mathematicians

for specifying the properties of the boundary  $\Gamma$ . The purpose of the present section is to introduce the three main points of view and to compare them.

#### 1.2.1 Graphs and manifolds

Many authors view (whenever possible) the boundary  $\Gamma$  of  $\Omega$  as being locally the graph of a function  $\varphi$ . Then the properties of  $\Gamma$  are specified through the properties of  $\varphi$ , e.g. continuity, Lipschitz property, differentiability and so on. This is the point of view followed by Aronszjan and Smith (1961), Adams (1975), Ladyzenskaia and Uralc'eva (1968), Miranda (1970), Nečas (1967) for instance. This last author will be our usual reference in the present subsection.

**Definition 1.2.1.1** Let  $\Omega$  be an open subset of  $\mathbb{R}^n$ . We say that its boundary  $\Gamma$  is continuous (respectively Lipschitz, continuously differentiable, of class  $C^{k,1}$ , m times continuously differentiable  $\dagger$ ) if for every  $x \in \Gamma$  there exists a neighbourhood V of x in  $\mathbb{R}^n$  and new orthogonal coordinates  $\{y_1, \ldots, y_n\}$  such that

(a) V is an hypercube in the new coordinates:

$$V = \{(y_1, \ldots, y_n) \mid -a_j < y_j < a_j, 1 \le j \le n\};$$

(b) there exists a continuous‡ (resp. Lipschitz,§ continuously differentiable, of class  $C^{k,1}$ , m times continuously differentiable) function  $\varphi$ , defined in

$$V' = \{(y_1, \ldots, y_{n-1}) \mid -a_i < y_i < a_i, 1 \le i \le n-1\}$$

and such that

$$|\varphi(y')| \le a_n/2 \text{ for every } y' = (y_1, \dots, y_{n-1}) \in V',$$
  
 $\Omega \cap V = \{ y = (y', y_n) \in V \mid y_n < \varphi(y') \},$  (1,2,1,1)  
 $\Gamma \cap V = \{ y = (y', y_n) \in V \mid y_n = \varphi(y') \}.$ 

In other words, in a neighbourhood of x,  $\Omega$  is below the graph of  $\varphi$  and consequently the boundary  $\Gamma$  is the graph of  $\varphi$ . We recall that saying that  $\varphi$  belongs to the class  $C^{k,1}$  means that it is k times continuously differentiable and its derivatives of order k are Lipschitz continuous.

If an open set  $\Omega$  has a continuous boundary  $\Gamma$ , then  $\Omega$  is not on both sides of  $\Gamma$  at any point of  $\Gamma$ . For instance,  $\mathbb{R}^* = \mathbb{R} \setminus \{0\}$  has not a continuous

<sup>#</sup> m and k are integers  $\ge 1$ , possibly equal to  $+\infty$ .

 $<sup>\</sup>ddagger$  Observe that the word continuous may be omitted there. Indeed, if a function fulfils the conditions (1,2,1,1), it is easily proved that  $\varphi$  has to be continuous.

<sup>§</sup> By Lipschitz condition, we always mean uniform Lipschitz condition.

![](_page_21_Figure_3.jpeg)

Figure 1.1

boundary in the sense of Definition 1.2.1.1. Likewise, a domain with a cut does not fulfil the conditions of Definition 1.2.1.1. However, this definition allows turning points.

The most important examples in the sequel are the following. A bounded open subset of R2 , whose boundary 1' is a polygon, has a Lipschitz boundary and lacks a continuously differentiable boundary. Similarly, a bounded open subset of ll , whose boundary T is a polyhedron, has a Lipschitz boundary and lacks a continuously differentiable boundary.

Many other authors, such as Lions and Magenes (1968) and Hörmander (1963), prefer to consider (whenever possible) the closure D of the domain (2, as an *n-*dimensional manifold with boundary, imbedded in R. They add various regularity assumptions on the manifold.

*Definition 1.2.1.2 Let fl be an open subset* of *D. We say that 12 is an n-dimensional continuous (respectively Lipschitz, continuously diferenti-* able, of class  $C^{k,1}$ , m times continuously differentiable) submanifold<sup>†</sup> with boundary in  $\mathbb{R}^n$ , if for every  $x \in \Gamma$  there exists a neighbourhood V of x in  $\mathbb{R}^n$  and a mapping  $\psi$  from V into  $\mathbb{R}^n$  such that

- (a) ψ is injective
- (b)  $\psi$  together with  $\psi^{-1}$  (defined on  $\psi(V)$ ) is continuous (respectively Lipschitz, continuously differentiable, of class  $C^{k,1}$ , m times continuously differentiable)
- (c)  $\Omega \cap V = \{y \in \Omega \mid \psi_n(y) < 0\}$  where  $\psi_n(y)$  denotes the nth component of  $\psi(y)$ .

As a consequence of condition (c), the boundary  $\Gamma$  of  $\Omega$  is defined locally by the equation  $\psi_n(y) = 0$ .

In the notations of Definition 1.2.1.1, define  $\psi$  as follows:

$$\psi(y) = \{y_1, \dots, y_{n-1}, y_n - \varphi(y')\}$$
 (1,2,1,2)

It is easily seen that  $\psi$  fulfils all the conditions in Definition 1.2.1.2 with the same amount of differentiability for  $\psi$  and  $\psi^{-1}$  as for  $\varphi$ . In other words, Definition 1.2.1.1 implies Definition 1.2.1.2 and it is natural to ask whether the converse is also true. Unfortunately the converse statement is only partly true. It follows from the implicit functions theorem that Definition 1.2.1.2 implies Definition 1.2.1.1 provided everything is at least continuously differentiable. Indeed, we rebuild a function  $\varphi$  from a given  $\psi$ , by solving the equation

$$\psi_n(y) = 0$$

with respect to  $y_i$  where j is chosen in such a way that  $D_i\psi_n$  does not vanish (locally). This is possible when  $\psi$  is continuously differentiable. Then the chain rule shows that  $\varphi$  is continuously differentiable (resp. of class  $C^{k,1}$ , m times continuously differentiable) when  $\psi$  is continuously differentiable (resp. of class  $C^{k,1}$ , m times continuously differentiable).

The implicit function theorem does not hold for Lipschitz functions and the following counterexample will show that Definition 1.2.1.2 does not imply Definition 1.2.1.1 under the single assumption that  $\psi$  together with  $\psi^{-1}$  is Lipschitz. This counterexample was shown to me by Zerner. We need some preliminary lemmas.

**Lemma 1.2.1.3** The Definition 1.2.1.2 of n-dimensional Lipschitz submanifolds with boundary in  $\mathbb{R}^n$  is invariant under bi-Lipschitz homeomorphisms.

A homeomorphism  $\eta$  of  $\bar{\Omega}_1$  onto  $\bar{\Omega}_2$  and of a neighbourhood  $W_1$  of  $\bar{\Omega}_1$ 

<sup>†</sup> A continuous manifold is more usually called a topological manifold.

onto a neighbourhood  $W_2$  of  $\bar{\Omega}_2$  will be called a bi-Lipschitz homeomorphism of  $\bar{\Omega}_1$  onto  $\bar{\Omega}_2$  if  $\eta$  and  $\eta^{-1}$  are uniformly Lipschitz-continuous. Lemma 1.2.1.3 is an easy consequence of the chain rule for the Lipschitz functions due to Rademacher (1919–20).

We now define a bi-Lipschitz homeomorphism from  $\mathbb{R}^2$  onto  $\mathbb{R}^2$  by

$$\eta(x) = \{x_1, \varphi(x_1) + x_2\}$$

where

$$\varphi(t) = \begin{cases} 3|t| - \frac{1}{2^{2k-1}} & \text{for } \frac{1}{2^{2k+1}} \le |t| \le \frac{1}{2^{2k}} \\ -3|t| + \frac{1}{2^{2k}} & \text{for } \frac{1}{2^{2k+2}} \le |t| \le \frac{1}{2^{2k+1}}. \end{cases}$$

The slope of  $\varphi$  is either 3 or -3. Consequently,  $\varphi$  is a uniformly Lipschitz function (with Lipschitz constant equal to 3). This implies that  $\eta$  together with  $\eta^{-1}$  are uniformly Lipschitz mappings.

Let  $\Omega$  be defined as follows:

$$\Omega = \{(x_1, x_2) | 0 < x_1 < 1, 0 < x_2 < x_1\}.$$

It is clear that  $\Omega$  has a Lipschitz boundary according to Definition 1.2.1.1.

![](_page_23_Figure_12.jpeg)

Figure 1.2

Therefore, *D* is a two-dimensional Lipschitz submanifold with boundary, in R<sup>2</sup> , according to Definition 1.2.1.2, since Definition 1.2.1.1 implies Definition 1.2.1.2. Next, consider the new domain *-r (Q ).* This is also a two-dimensional Lipschitz submanifold with boundary in R<sup>2</sup> , owing to Lemma 1.2.1.3. Now we have the following result.

*Lemma 1.2.1.4 '(D) has not a continuous boundary according to Definition 1.2.1.1.*

*Proof* It is obvious from the geometry of *î(L2)* (see Fig. 1.3) that every linear segment with origin at 0, which cuts T, actually cuts P at infinitely many points. This property is true without any restriction on the length of the segment under consideration. This prevents the existence of a neighbourhood V of 0, together with the existence of new coordinates such that T fl V should be the graph of a function as in Definition 1.2.1.1. Accordingly 77(Q) lacks a continuous boundary in the sense of Definition 1.2.1.1. E

Summing up, the comparison between Definition 1.2.1.1 and Definition 1.2.1.2 is the following.

![](_page_24_Figure_7.jpeg)

Figure 1.3

**Theorem 1.2.1.5** A bounded open subset  $\Omega$  in  $\mathbb{R}^n$  has a continuously differentiable (respectively of class  $C^{k,1}$ , m times continuously differentiable) boundary  $\Gamma$  if and only if  $\bar{\Omega}$  is an n-dimensional continuously differentiable (respectively of class  $C^{k,1}$ , m times continuously differentiable) submanifold with boundary in  $\mathbb{R}^n$ . A bounded open subset  $\Omega$  in  $\mathbb{R}^n$  with continuous (respectively Lipschitz) boundary  $\Gamma$  has a closure  $\bar{\Omega}$  which is an n-dimensional continuous (respectively Lipschitz) submanifold with boundary in  $\mathbb{R}^n$ . The converse statement is not true.

In some special questions, for technical reasons, we shall need uniformly Lipschitz unbounded domains of the following kind.

**Definition 1.2.1.6** An open subset  $\Omega$  of  $\mathbb{R}^n$  is said to be a uniform Lipschitz epigraph if there exists new coordinates  $\{y_1, \ldots, y_n\}$  and an uniformly Lipschitz continuous function  $\varphi$  of n-1 variables, such that

$$\Omega = \{ y = (y', y_n) \mid y_n > \varphi(y') \}. \tag{1,2,1,3}$$

Examples of such domains are infinite cones or plane sectors.

#### 1.2.2 Segment property and cone property

In the early stages of the theory of Sobolev spaces, many authors preferred to describe the boundary properties of the possible domains  $\Omega$  in a more straightforward fashion. Namely, they required that for each point x of the boundary  $\Gamma$  of  $\Omega$ , there exists a linear segment C with origin at x or a cone C with vertex at x, such that  $C\setminus\{x\}$  is contained in  $\Omega$ . Usually a local uniformity assumption is added (cf. below). This point of view, adopted by Sobolev, has been followed by Agmon (1965) and Calderon (1961).

**Definition 1.2.2.1** Let  $\Omega$  be an open subset of  $\mathbb{R}^n$ . We say that  $\Omega$  has the uniform (or restricted) segment property (resp. cone property) if for every  $x \in \Gamma$ , there exists a neighbourhood V of x in  $\mathbb{R}^n$  and new coordinates  $\{y_1, \ldots, y_n\}$  such that

(a) V is a hypercube in the new coordinates:

$$V = \{(y_1, \ldots, y_n) \mid -a_i < y_i < a_i, 1 \le j \le n\}$$

(b)  $y-z \in \Omega$  whenever  $y \in \overline{\Omega} \cap V$  and  $z \in C$ , where C is the open segment  $\{(0,\ldots,0,z_n) \mid 0 < z_n < h\}$  (resp. C is the open cone  $\{z=(z',z_n) \mid (\cot\theta) \mid z' \mid < z_n < h\}$  for some  $\theta \in ]0, \pi/2]$ ) for some h > 0.

It is obvious that if  $\Omega$  has a continuous boundary according to Defini-

![](_page_26_Figure_3.jpeg)

Figure 1.4

tion 1.2.1.1, then it has the uniform segment property (just choose  $h < a_n/2$ ). The same way, if  $\Omega$  has a Lipschitz boundary, then it has the uniform cone property. Indeed, this is seen by replacing all the  $a_i$  by  $a_i/2$  in Definition 1.2.1.2 and by choosing  $h < a_n/2$  together with

$$\theta \le \inf \left( \arctan \frac{1}{K}; \arctan \frac{a_1}{a_n}; \cdots \arctan \frac{a_{n-1}}{a_n} \right),$$

where K is the Lipschitz constant of  $\varphi$ .

The converse statement has been known to be true for a long time by oral tradition. However, an actual proof has been published only recently by Chenais (1973). We shall give a transcript of the proof only for domains having the uniform cone property, because it is slightly simpler and it is the only one we need in the following sections.

12 SOBOLEV SPACES

*Theorem* 1.2.2.2 *A bounded open* subset *,(l of ^"* has *the uniform cone* property *if and* only if its boundary *T* is Lipschitz.

*Proof* We have already observed that the condition of having a Lipschitz boundary is sufficient. Thus, let us consider x E T, assuming that (2 has the uniform cone property of Definition 1.2.2.1. We know that {x} — C c ƒ2, but we can also observe that {x} + C c Ch2, at least if the distance from x to CV is greater than h/cos 0; this last condition can always be achieved by choosing a smaller h. Indeed, if {x} + C n (2 is not empty, let y be a point in the intersection; then y e (2 n V since I y /, — xn < h; consequently, {y} — C c f, but this contradicts the fact that {y} — C 3 x.

From this remark it follows that if we translate the origin of the coordinates {y <sup>l</sup> , ... , y<sup>n</sup> } at x and define a cylinder K by

$$K = \{(y', y_n) \mid -h < y_n < h, |y'| < h \text{ tan } \theta\},$$

then we have

$$\Gamma \cap K \subset \{(y', y_n) \mid |y_n| \tan \theta < |y'| < h \tan \theta\};$$

This means that F cannot `escape' through the top of K. We conclude by defining cp in the following way

$$\varphi(y') = \sup \{ y_n \mid (y', y_n) \in \Gamma \cap K \};$$

cp is defined only for Iy'I < h tan 0. Clearly, (v', 9(y')) E T. Then the cone property shows that all points (y', y<sup>n</sup> ) E K with y,, < Q (y') are in (2; by contradiction, as we did previously for x, we show that all points (y', y <sup>n</sup> ) E K with yn > cp (y') are in CD. Finally, if we consider two points (y', cp (y')) and (z', p(z')) on the graph of cp, it foliows from the cone property that

$$y_n - z_n > -|y' - z'| \cot \theta;$$

this implies that '.p is a uniformly Lipshitz function with constant K = cot 0.

We conclude the proof by observing that all the conditions in Definition 1.2.1.1 are fulfilled when we choose the a; small enough. •

A useful consequence is the following:

*Coroitary 1.2.2.3 Let f2 be a bounded open convex* subset *of R",* then *D has a* Lipschitz *boundary.*

*Proof* Let x0 be any point in *D* and let *r >0* be the radius of a balt *B* with centre x0, contained in (2. Since (2 is convex, all the points ty + (1 — t)z with y E (2, z E B, 0 t < 1, are in ƒ2. This shows already that (2 has some kind of a cone property but we still need uniformity.

![](_page_28_Picture_3.jpeg)

Figure 1.5

Now fix  $x \in \Gamma$  and choose new coordinates  $\{y_1, \ldots, y_n\}$  with, say, origin at x and such that  $x_0x$  is parallel to  $Oy_n$ . Denote by l the distance from  $x_0$  to x. Then to each  $y \in \overline{\Omega}$  at a distance less than r/2 from x, we associate a ball B(y) centred at  $(y', y_n - l)$  with radius r/2. Obviously  $B(y) \subset B$ , and therefore all the points ty + (1 - t)z with  $z \in B(y)$ ,  $0 \le t < 1$  are in  $\Omega$ . The property in Definition 1.2.2.1 is verified by choosing the  $a_j$  small enough, h = l and  $\sin \theta = r/2l$ .

Remark 1.2.2.4 Unfortunately domains with cuts or with turning points are not well classified by the various previous definitions. Let us consider, for instance, the following domains in the plane:

$$\Omega_1 = \{(x_1, x_2) \mid -1 < x_1 < 1, -1 < x_2 < -|x_1|^{1/2}\}$$
  
$$\Omega_2 = \{(x_1, x_2) \mid 0 < x_1 < 2, -1 < x_2 < -(x_1/2)^{1/2}\}.$$

The domain  $\Omega_1$  is easily seen to have a continuous (and non-Lipschitz) boundary according to Definition 1.2.1.1. On the other hand,  $\Omega_2$  has not the segment property of Definition 1.2.2.1; consequently, it lacks a

![](_page_29_Figure_2.jpeg)

Figure 1.6

continuous boundary. However, 111 <sup>2</sup> is the image of 111 <sup>1</sup> through the mapping

$$\varphi:(x_1, x_2) \mapsto (x_1 + x_2^2, x_2)$$

which is a diffeomorphism of class C°° of l2 onto R .

#### 1.3 Spaces

This section is just a list of the definitions of the Sobolev spaces. We confine our attention strictly to those spaces which we really need in the following chapters. Consequently we will not consider any of those functional spaces such as Besov spaces and Nikolski spaces that are very closely related to Sobolev spaces and have better properties. The reader interested in those spaces is referred to Triebel (1978) for instance.

The Sobolev spaces are very easy to define on the whole Euclidean space. Then a possible definition of Sobolev spaces on a subdomain (2 of ff" with boundary uses restrictions to (2. This is why we treat the spaces on R' separately and first.

#### 1.3.1 Euclidean space

In what follows, s is any real number and p is a real number such that 1 <p < oc. We shall denote by m the integer part of s and by u its fractional part; consequently, s = m + o- and 0 <— u <1.

*Definition 1.3.1.1 We denote by W'(D ) the space* of *all distributions (all functions and distributions are complex valued unless otherwise specified) defined in* lv', *such that*

*(a) Du* E *L, ((Rn ), for la ; m, when s = m is a nonnegative integer,*

(b)  $u \in W_p^m(\mathbb{R}^n)$  and

$$\iint\limits_{\mathbb{R}^n \times \mathbb{R}^n} \frac{|D^{\alpha}u(x) - D^{\alpha}u(y)|^p}{|x - y|^{n + \sigma p}} dx dy < +\infty$$

for  $|\alpha| = m$ , when  $s = m + \sigma$  is nonnegative and is not an integer.

As usual,  $L_p(\mathbb{R}^n)$  is the space of all measurable functions u such that  $|u|^p$  is integrable over  $\mathbb{R}^n$ . We define a Banach norm on  $W_p^s(\mathbb{R}^n)$  by

$$||u||_{m,p,\mathbb{R}^n} = \left\{ \sum_{|\alpha| \le m} \int_{\mathbb{R}^n} |D^{\alpha}u|^p \, \mathrm{d}x \right\}^{1/p}$$
 (1,3,1,1)

in case (a), and by

$$||u||_{s,p,\mathbb{R}^n} = \left\{ ||u||_{m,p,\mathbb{R}^n}^p + \sum_{|\alpha| = m} \iint_{\mathbb{R}^n \times \mathbb{R}^n} \frac{|D^{\alpha}u(x) - D^{\alpha}u(y)|^p}{|x - y|^{n + \sigma p}} dx dy \right\}^{1/p}$$
(1,3,1,2)

in case (b).

The previous definition is extended to negative values of p by duality as follows:

**Definition 1.3.1.2** For s < 0 we denote by  $W_p^s(\mathbb{R}^n)$  the dual space of  $W_q^s(\mathbb{R}^n)$ , where  $p^{-1} + q^{-1} = 1$ .

In the special case where p=2, we shall use the more common notation  $H^s(\mathbb{R}^n)$  instead of  $W_2^s(\mathbb{R}^n)$ . The norms defined in (1,3,1,1) and (1,3,1,2) are Hilbert norms when p=2.

In some special questions where the use of Fourier transform cannot be avoided, it is useful to introduce a different kind of spaces as follows.

**Definition 1.3.1.3** We denote by  $H_p^s(\mathbb{R}^n)$  the space of all distributions in  $\mathbb{R}^n$  such that

$$G_{s} * u \in L_{p}(\mathbb{R}^{n}),$$

where G<sub>s</sub> is the Bessel potential of order s defined by

$$(FG_s)(\xi) = (1+|\xi|^2)^{s/2}$$

As usual, F is the Fourier transform operator defined by

$$(Fu)(\xi) = \frac{1}{(2\pi)^{n/2}} \int_{\mathbb{R}^n} e^{-ix\xi} u(x) dx$$

and the star \* denotes the convolution product.

It is known that  $H_2^s(\mathbb{R}^n) = W_2^s(\mathbb{R}^n)$  (by Plancherel's theorem) for all real s, and that  $H_p^m(\mathbb{R}^n) = W_p^m(\mathbb{R}^n)$  (by Mikhlin's theorem) for all integer m and 1 . Furthermore, it is proved in Taibleson (1964) that

$$H_p^s(\mathbb{R}^n) \supseteq W_p^s(\mathbb{R}^n), \qquad 1$$

while

$$W_p^s(\mathbb{R}^n) \supseteq H_p^s(\mathbb{R}^n), \qquad 2 \le p < \infty,$$

for any real s.

It is also easily checked that  $W_p^s(\mathbb{R}^n)$  and  $H_p^s(\mathbb{R}^n)$  decrease when s increases and finally Lions and Peetre (1964) have proved that

$$W_{p}^{s'}(\mathbb{R}^n) \subset H_{p}^{s''}(\mathbb{R}^n) \subset W_{p}^{s'''}(\mathbb{R}^n)$$

for any real numbers s', s", s"' such that

#### 1.3.2 Open subsets of the Euclidean space

We now deal with  $\Omega$ , an open subset of  $\mathbb{R}^n$ , possibly different from  $\mathbb{R}^n$  itself. Our purpose is to extend the definitions given in Section 1.3.1, in order to define Sobolev spaces on  $\Omega$ . In doing that, we can follow different schools. Here are the three main methods:

- (a) We can reproduce Definition 1.3.1.1 by restricting the domain of integration (replacing  $\mathbb{R}^n$  by  $\Omega$ ). This is the point of view in Lions and Magenes (1960-63) and Nečas (1967), for instance.
- (b) We can define  $W_p^s(\Omega)$  as being the set of restrictions to  $\Omega$  of all functions in  $W_p^s(\mathbb{R}^n)$ . This is the point of view in Hörmander (1963).
- (c) Finally, following Agmon (1965) and Miranda (1970), we can consider the completion of the space of smooth functions in  $\bar{\Omega}$ , with respect to the norm in (a).

It turns out that each of these three methods has its advantages. All three lead to the same spaces when  $\Omega$  is smooth enough (we shall give a precise meaning to this sentence in the next sections). However, for general domains they may produce three different spaces, which we shall have to compare.

**Definition 1.3.2.1** We denote by  $W_p^s(\Omega)$  the space of all distributions u defined in  $\Omega$ , such that

(a)  $D^{\alpha}u \in L_p(\Omega)$ , for  $|\alpha| \le m$ , when s = m is a nonnegative integer,

(b)  $u \in W_p^m(\Omega)$  and

$$\iint\limits_{\Omega \cup \Omega} \frac{|D^{\alpha}u(x) - D^{\alpha}u(y)|^{p}}{|x - y|^{n + \sigma p}} dx dy < +\infty$$

for  $|\alpha| = m$ , when  $s = m + \sigma$  is nonnegative and is not an integer.

We define a Banach norm on  $W_{p}^{s}(\Omega)$  by

$$\|u\|_{m,p,\Omega} = \left\{ \sum_{|\alpha| \le m} \int_{\Omega} |D^{\alpha}u|^p \, \mathrm{d}x \right\}^{1/p} \tag{1,3,2,1}$$

in the case (a), and by

$$||u||_{s,p,\Omega} = \left\{ ||u||_{m,p,\Omega}^{p} + \sum_{|\alpha|=m} \iint_{\Omega \times \Omega} \frac{|D^{\alpha}u(x) - D^{\alpha}u(y)|^{p}}{|x - y|^{n + \sigma p}} dx dy \right\}^{1/p}$$
 (1,3,2,2)

in the case (b).

We cannot directly reproduce Definition 1.3.1.2 since in general  $\mathcal{D}(\Omega)$ , the space of all  $C^{\infty}$  functions with compact support in  $\Omega$ , is not dense in  $W_p^s(\Omega)$ . Consequently, the dual space of  $W_p^s(\Omega)$  cannot be identified to a space of distributions in  $\Omega$ . This is the reason for introducing another family of Sobolev spaces.

**Definition 1.3.2.2** For s > 0, we denote by  $\mathring{W}_{p}^{s}(\Omega)$  the closure of  $\mathfrak{D}(\Omega)$  in  $W_{p}^{s}(\Omega)$ .

Equivalently, it is the closure in  $W_p^s(\hat{\Omega})$  of all distributions with compact support in  $\Omega$  which belong to  $W_p^s(\Omega)$ .

Then the extension of Definition 1.3.1.2 is the following:

**Definition 1.3.2.3** For s < 0, we denote by  $W_p^s(\Omega)$  the dual space of  $\mathring{W}_q^{-s}(\Omega)$ , where  $p^{-1} + q^{-1} = 1$ .

In the special case when p=2, we shall also use the common notation, namely  $H^s(\Omega)$  instead of  $W_2^s(\Omega)$  and  $\mathring{H}^s(\Omega)$  instead of  $\mathring{W}_2^s(\Omega)$ . These are Hilbert spaces.

When s is a negative integer -m,  $W_p^s(\Omega)$  is also the space of all distributions T in  $\Omega$  such that

$$T = \sum_{|\alpha| \le m} D^{\alpha} f_{\alpha} \tag{1,3,2,3}$$

where  $f_{\alpha} \in L_p(\Omega)$ . The proof can be found in Magenes and Stampacchia (1958), for instance. An extension of (1,3,2,3) to non integer s is given in Lions (1961b).

SOBOLEV SPACES

For the sake of clarity in the following sections, it will be convenient to have a specific notation for the space defined by restriction.

**Definitions 1.3.2.4** For every s > 0, we denote by  $W_p^s(\bar{\Omega})$  the space of all distributions in  $\Omega$  which are restrictions of elements of  $W_p^s(\mathbb{R}^n)$ .

In other words,  $W_p^s(\bar{\Omega})$  is the space of all  $u \mid_{\Omega}$  where  $u \in W_p^s(\mathbb{R}^n)$  and  $u \mid_{\Omega}$  is defined by  $\langle u \mid_{\Omega} ; \varphi \rangle = \langle u, \tilde{\varphi} \rangle$  for all  $\varphi \in \mathcal{D}(\Omega)$ , where  $\tilde{\varphi}$  is the continuation of  $\varphi$  by zero, outside  $\Omega$ . We define a Banach norm on  $W_p^s(\bar{\Omega})$  by

$$||u||_{s,p,\vec{\Omega}} = \inf_{\substack{U \in W_p^*(\mathbb{R}^n) \\ U|_{G} = u}} ||U||_{s,p,\mathbb{R}^n}.$$
 (1,3,2,4)

As obvious consequences of the definition, we have the following inclusions:

$$W_{p}^{s}(\bar{\Omega}) \subseteq W_{p}^{s}(\Omega) \tag{1,3,2,5}$$

for every real s > 0, and

18

$$\mathring{W}_{p}^{m}(\Omega) \subseteq W_{p}^{m}(\bar{\Omega}) \subseteq W_{p}^{m}(\Omega) \tag{1,3,2,6}$$

for every integer m > 0.

Unfortunately we shall need one more kind of Sobolev space whose technical interest will appear much later.

**Definition 1.3.2.5** For every positive s, we denote by  $\tilde{W}_p^s(\Omega)$ , the space of all  $u \in W_p^s(\Omega)$ , where  $\tilde{u} \in W_p^s(\mathbb{R}^n)$ .

 $\tilde{W}_{p}^{s}(\Omega)$  is a Banach space for the norm

$$\|u\|_{s,p,\Omega}^{\infty} = \|\tilde{u}\|_{s,p,\mathbb{R}^n} \tag{1,3,2,7}$$

The only obvious inclusions concerning  $\tilde{W}_{p}^{s}(\Omega)$  are the following

$$\tilde{W}_{p}^{s}(\Omega) \subseteq W_{p}^{s}(\bar{\Omega}) \tag{1,3,2,8}$$

for all s > 0 and

$$\mathring{W}_{p}^{m}(\Omega) \subseteq \tilde{W}_{p}^{m}(\Omega) \tag{1,3,2,9}$$

for m integer >0.

The norm defined in (1,3,2,7), although it is the natural one, is somewhat tricky, because it is the norm induced by  $W_p^s(\Omega)$  only when s is an integer.

#### **Lemma 1.3.2.6** Let u belong to $\tilde{W}_{p}^{s}(\Omega)$ ; then

$$\|u\|_{m,p,\Omega}^{\sim} = \|u\|_{m,p,\Omega} \tag{1,3,2,10}$$

when s = m is an integer, while

$$\|u\|_{s,p,\Omega}^{\sim} = \left\{ \|u\|_{s,p,\Omega}^{p} + \sum_{|\alpha|=m} \int_{\Omega} |D^{\alpha}u(x)|^{p} \rho_{\sigma,p}(x) \, \mathrm{d}x \right\}^{1/p} \geqslant \|u\|_{s,p,\Omega}$$
when  $s = m + \sigma$  is not an integer, where
$$(1,3,2,11)$$

 $\rho_{\sigma,p}(x) = 2 \int_{\Omega} \frac{\mathrm{d}y}{|x-y|^{n+\sigma p}}.$ 

It is not easy to describe the weight  $\rho_{\sigma,p}$  in general. However, when  $\Omega$  is bounded and has a Lipschitz boundary, there exist two constants  $C_1$ ,  $C_2$  with  $0 < C_1 \le C_2$ , such that

$$C_1 d(x; \Gamma)^{-\sigma p} \leq \rho_{\sigma, p}(x) \leq C_2 d(x; \Gamma)^{-\sigma p}$$

$$(1, 3, 2, 12)$$

where  $d(x, \Gamma)$  denotes the distance from x to the boundary  $\Gamma$  of  $\Omega$ . The same inequalities hold when  $\Omega$  is a uniform Lipschitz epigraph (Definition 1.2.1.6).

#### 1.3.3 Manifolds

In the following sections, we shall need Sobolev spaces on manifolds which are only (possibly part of) boundaries of open subsets of  $\mathbb{R}^n$  fulfilling the assumptions in Definition 1.2.1.1. In other words, they will be (n-1)-dimensional hypersurfaces in  $\mathbb{R}^n$ . Consequently, keeping the same notations as in Definition 1.2.1.1, the boundary  $\Gamma$  of  $\Omega$  is such that for every  $x \in \Gamma$ , there exists a neighbourhood V of x in  $\mathbb{R}^n$ , fulfilling the condition (a) in Definition 1.2.1.1 and a function fulfilling the condition (b) such that

$$\Gamma \cap V = \{ y = (y', y_n) \in V \mid y_n = \varphi(y') \}.$$

Let us define  $\Phi$  as follows:

$$\Phi(y) = \{y_1, \dots, y_{n-1}, \varphi(y_1, \dots, y_{n-1})\}, \tag{1,3,3,1}$$

then  $(\Gamma \cap V, \Phi)$  is a map of  $\Gamma$  around x, where we now view  $\Gamma$  as a (n-1)-dimensional Lipschitz (respectively continuously differentiable, of class  $C^{k,1}$ , m times continuously differentiable) submanifold of  $\mathbb{R}^n$ .

The following statement expresses in a precise way the stability of Sobolev spaces under sufficiently smooth changes of variables. We assume that  $\psi$  is at least a bi-Lipschitz mapping from  $\bar{\Omega}_1$  onto  $\bar{\Omega}_2$  where  $\Omega_1$  and  $\Omega_2$  are bounded open subsets of  $\mathbb{R}^n$ . This hypothesis ensures that Lebesgue measure is mapped by  $\psi$  or  $\psi^{-1}$  to an equivalent image measure.

**Lemma 1.3.3.1** Let  $u \in W_p^s(\Omega_2)$ ; assume that  $\psi$  and  $\psi^{-1}$  are of class  $C^{k,1}$  where k is an integer  $\ge s-1$ ; then  $u \circ \psi \in W_p^s(\Omega_1)$ .

This property is easy to check with the help of the results in Rademacher (1919). It is a justification for the following definition.

**Definition 1.3.3.2** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a boundary  $\Gamma$  of class  $C^{k,1}$ , where k is a nonnegative integer. Let  $\Gamma_0$  be an open subset of  $\Gamma$ . A distribution u on  $\Gamma_0$  belongs to  $W_p^s(\Gamma_0)$  with  $|s| \le k+1$  if  $u \circ \Phi \in W_p^s(V' \cap \Phi^{-1}(\Gamma_0 \cap V))$  for all possible V and  $\varphi$  fulfilling the assumptions in Definition 1.2.1.1.

Usually distributions are defined only on  $C^{\infty}$  manifolds. When  $\Gamma_0$  is only an open subset of a  $C^{k,1}$  manifold we consider distributions whose order is less than or equal to k+1; those span the dual space of the space of all  $C^{k,1}$  functions with compact support in  $\Gamma_0$ . Functions are identified with distributions by means of the usual injection  $u \mapsto T_u$ , defined by

$$\langle T_u; v \rangle = \int_{\Gamma_u} uv \, d\sigma$$

where  $d\sigma$  is the usual hypersurface measure on  $\Gamma$  (defined provided  $\Gamma$  is a Lipschitz hypersurface).

One possible Banach norm on  $W_p^s(\Gamma)$  is

$$u \mapsto \sum_{j=1}^{J} \|u \circ \Phi_{j}\|_{s,p,V_{i}' \cap \Phi_{j}^{-1}(\Gamma_{0} \cap V_{j}')}^{p}$$
 (1,3,3,2)

where  $(V_i, \Phi_i)_{i=1}^J$  is any atlas of  $\Gamma$  such that each couple  $(V_i, \varphi_i)$  fulfils the assumptions of Definition 1.3.3.1 (we recall that  $\Phi_i$  is defined from  $\varphi_i$  by (1,3,3,1)).

In the particular case when  $s \in ]0, 1[$ , one can easily check that any of the norms defined in (1,3,3,2) is equivalent to

$$u \mapsto \left\{ \int_{\Gamma_0} |u|^p \, d\sigma + \int_{\Gamma_0 \times \Gamma_0} \frac{|u(x) - u(y)|^p}{|x - y|^{n-1+sp}} \, d\sigma(x) \, d\sigma(y) \right\}^{1/p}. \tag{1,3,3,3}$$

#### 1.4 Basic properties

This section is only a list of the main properties of the spaces defined above. We do not report any proof but just indicate easy references where all the details can be found.

#### 1.4.1 Multiplication and differentiation

The question here is to know sufficient conditions on a function  $\varphi$  defined in  $\Omega$ , ensuring that  $u \to \varphi u$  is a continuous linear mapping in a given

 $W_p^s(\Omega)$ . We state here a very simple answer, which is just a straightforward consequence of the definitions given in Section 1.3. A more complete answer will be given in Section 1.4.4 as a consequence of the imbedding theorems (see Theorem 1.4.4.2).

We denote by  $C_c^{k,\alpha}(\bar{\Omega})$  (k a nonnegative integer and  $\alpha \in [0,1]$ ) the space of all functions defined in  $\bar{\Omega}$  which are restrictions to  $\bar{\Omega}$  of functions of class  $C^{k,\alpha}$  defined on the whole of  $\mathbb{R}^n$  which have a compact support.

**Theorem 1.4.1.1** Let  $\varphi \in C_c^{k,\alpha}(\bar{\Omega})$  with  $k+\alpha \ge |s|$  when s is an integer and  $k+\alpha > |s|$  when s is not an integer, then  $\varphi u \in W_p^s(\Omega)$  for every  $u \in W_p^s(\Omega)$ , and there exists a constant  $K = K(\varphi, s, p)$  such that

$$\|\varphi u\|_{s,p,\Omega} \leq K \|u\|_{s,p,\Omega}. \tag{1,4,1,1}$$

An easy consequence is that under the same hypothesis on  $\varphi$ ,  $u \to \varphi u$  is a continuous linear mapping in  $W_p^s(\bar{\Omega})$  and in  $\tilde{W}_p^s(\Omega)$ . The following result is also easy to check.

**Theorem 1.4.1.2** Let  $\varphi \in C_c^{k,\alpha}(\bar{\Omega})$  with  $k + \alpha \ge |s|$  when s is an integer and  $k + \alpha > |s|$  when s is not an integer, then  $\varphi u \in \mathring{W}_p^s(\Omega)$  for every  $u \in \mathring{W}_p^s(\Omega)$ .

For a nonnegative integer m, the space  $W_p^m(\Omega)$  is just the space of all functions defined in  $\Omega$ , which are m times differentiable in  $L_p(\Omega)$ , so to say. The definition of  $W_p^s(\Omega)$  for a noninteger s has been stated with the underlying idea that  $W_p^s(\Omega)$  should be the space of all functions in  $\Omega$  which are s times differentiable in some sense. Consequently, one could expect  $D^{\alpha}$  to be a continuous linear operator from  $W_p^s(\Omega)$  into  $W_p^{s-|\alpha|}(\Omega)$ . The extension of the definition of  $W_p^s(\Omega)$  to negative values of s was devised with the hope that this rule should hold for every s. Unfortunately, this is not always true, as we shall begin to show now.

Firstly,  $D^{\alpha}$  maps  $W_p^s(\Omega)$  into  $W_p^{s-|\alpha|}(\Omega)$  provided either  $|\alpha| \le s$  or  $s \le 0$ . This follows from Definition 1.3.2.1 when  $|\alpha| \le s$ . Then, from Definition 1.3.2.2, we see that  $D^{\alpha}$  is also a continuous linear operator from  $\mathring{W}_p^s(\Omega)$  into  $\mathring{W}_p^{s-|\alpha|}(\Omega)$  when  $|\alpha| \le s$ . Transposing this result and remembering Definition 1.3.2.3, we conclude that  $D^{\alpha}$  maps  $W_p^s(\Omega)$  into  $W_p^{s-|\alpha|}(\Omega)$  when  $s \le 0$ .

Now it remains to understand how differentiation operates from spaces with positive order to spaces with negative order. For this purpose it is enough to consider an elementary differentiation operator  $D_i$  with respect to  $x_i$ , with  $1 \le i \le n$ .

**Lemma 1.4.1.3**  $D_j$  is a continuous linear operator from  $W_p^s(\mathbb{R}^n)$  into  $W_p^{s-1}(\mathbb{R}^n)$ .

The only case we have to consider is when 0 < s < 1. When p = 2 and consequently  $W_p^s(\mathbb{R}^n) = H^s(\mathbb{R}^n) = H_2^s(\mathbb{R}^n)$ , the property is obvious from Definition 1.3.1.3. Unfortunately, we need another method of proof when p is not 2. We describe it now. Here R belongs to  $\mathfrak{D}(\mathbb{R}^n)$  and has its support in the unit ball and integral equal to one.

**Lemma 1.4.1.4** Let  $u \in W_n^s(\mathbb{R}^n)$  and set

$$U(x, x_{n+1}) = \frac{1}{x_{n+1}^{n}} \int_{\mathbb{R}^{n}} R\left(\frac{y-x}{x_{n+1}}\right) u(y) \, dy, \qquad x \in \mathbb{R}^{n}, \quad x_{n+1} > 0;$$
then  $x_{n+1}^{1-s-1/p} D_{k} U \in L_{p}(\mathbb{R}^{n+1}), \ k = 1, 2, \dots, n+1.$ 

$$(1,4,1,2)$$

**Proof** We follow the method used in Lemma 5.6, Chapter 2 in Nečas (1967), just adding a weight. We first consider  $D_k U$  where  $1 \le k \le n$ . We have

$$D_k U(x, x_{n+1}) = -\frac{1}{x_{n+1}^{n+1}} \int_{\mathbb{R}^n} D_k R\left(\frac{y-x}{x_{n+1}}\right) u(y) \, dy$$
$$= -\frac{1}{x_{n+1}^{n+1}} \int_{\mathbb{R}^n} D_k R\left(\frac{y-x}{x_{n+1}}\right) [u(y) - u(x)] \, dy$$

since obviously

$$\int_{\mathbb{R}^n} D_k R\left(\frac{y-x}{x_{n+1}}\right) dy = 0.$$

It follows that

$$D_k U(x, x_{n+1}) = \int_{\mathbb{R}^n} D_k R(z) [u(x) - u(x + x_{n+1}z)] \frac{\mathrm{d}z}{x_{n+1}}$$

and consequently

$$\int_{0}^{\infty} \left( \int_{\mathbb{R}^{n}} x_{n+1}^{p-sp-1} |D_{k}U(x, x_{n+1})|^{p} dx \right) dx_{n+1} 
\leq c \int_{0}^{\infty} \left( \int_{\mathbb{R}^{n}} x_{n+1}^{p-sp-1} \left\{ \int_{|z| \leq 1} |u(x) - u(x + x_{n+1}z)|^{p} \frac{dz}{x_{n+1}^{p}} \right\} dx \right) dx_{n+1} 
= c \int_{0}^{\infty} \left( \int_{\mathbb{R}^{n}} x_{n+1}^{-1-sp} \left\{ \int_{|x-y| \leq x_{n+1}} |u(x) - u(y)|^{p} \frac{dy}{x_{n+1}^{n}} \right\} dx \right) dx_{n+1} 
= c \int_{\mathbb{R}^{n} \times \mathbb{R}^{n}} |u(x) - u(y)|^{p} \left\{ \int_{|x-y|}^{\infty} x_{n+1}^{-1-sp-n} dx_{n+1} \right\} dx dy 
= \frac{c}{sp+n} \int_{\mathbb{R}^{n} \times \mathbb{R}^{n}} \frac{|u(x) - u(y)|^{p}}{|x-y|^{n+sp}} dx dy$$

where c is a constant depending on R.

Now let us consider  $D_{n+1}U$ ; we have

$$D_{n+1}U(x, x_{n+1}) = -\frac{n}{x_{n+1}^{n+1}} \int_{\mathbb{R}^{n}} R\left(\frac{y-x}{x_{n+1}}\right) u(y) \, dy - \frac{1}{x_{n+1}^{n+1}}$$

$$\times \int_{\mathbb{R}^{n}} \sum_{j=1}^{n} D_{j} R\left(\frac{y-x}{x_{n+1}}\right) \frac{y_{j} - x_{j}}{x_{n+1}} u(y) \, dy$$

$$= -\frac{n}{x_{n+1}^{n+1}} \int_{\mathbb{R}^{n}} R\left(\frac{y-x}{x_{n+1}}\right) [u(y) - u(x)] \, dy$$

$$-\frac{1}{x_{n+1}^{n+1}} \int_{\mathbb{R}^{n}} \sum_{j=1}^{n} D_{j} R\left(\frac{y-x}{x_{n+1}}\right) \frac{y_{j} - x_{j}}{x_{n+1}} [u(y) - u(x)] \, dy$$

since

$$\frac{n}{x_{n+1}^{n+1}} \int_{\mathbb{R}^n} R\left(\frac{y-x}{x_{n+1}}\right) dy + \frac{1}{x_{n+1}^{n+1}} \int_{\mathbb{R}^n} \sum_{j=1}^n D_j R\left(\frac{y-x}{x_{n+1}}\right) \frac{y_j - x_j}{x_{n+1}} dy = 0$$

by integration by parts. Then each integral in  $D_{n+1}U$  is estimated as we did for  $D_kU$ .

Proof of Lemma 1.4.1.3 We consider the bilinear form

$$u, v \mapsto \int_{\mathbb{R}^n} D_j uv \, \mathrm{d}x$$

and we prove that it is defined and continuous on  $W_p^s(\mathbb{R}^n) \times W_q^{1-s}(\mathbb{R}^n)$ , where (1/p) + (1/q) = 1. From u and v we construct U and V according to identity (1,4,1,2). We know from Lemma 1.4.1.4 that

$$\begin{cases} x_{n+1}^{1-s-1/p} D_k U \in L_p(\mathbb{R}^{n+1}), & 1 \le k \le n+1 \\ x_{n+1}^{s-1/q} D_k V \in L_q(\mathbb{R}^n), & 1 \le k \le n+1. \end{cases}$$

Furthermore, in the topology of  $L_p(\mathbb{R}^n)$  we have

$$\lim_{x \to 1 \to 0} U = u, \qquad \lim_{x \to 1 \to \infty} U = 0$$

while in the topology of  $L_q(\mathbb{R}^n)$  we have

$$\lim_{\mathbf{x}_{n+1}\to 0} \mathbf{V} = \mathbf{v}, \qquad \lim_{\mathbf{x}_{n+1}\to \infty} \mathbf{V} = 0.$$

This implies that

$$\int_{\mathbb{R}^n} D_j U(x, x_{n+1}) V(x, x_{n+1}) dx$$

$$= - \int_{x}^{+\infty} \int_{\mathbb{R}^n} \left[ D_j U(x, t) D_{n+1} V(x, t) - D_{n+1} U(x, t) D_j V(x, t) \right] dx dt$$

and consequently

$$\begin{split} & \left| \int_{\mathbb{R}^{n}} D_{j} U(x, x_{n+1}) V(x, x_{n+1}) \, \mathrm{d}x \right| \\ & \leq \sum_{k,l=1}^{n+1} \|x_{n+1}^{1-s-1/p} D_{k} U\|_{L_{p}(\mathbb{R}^{n+1})} \|x_{n+1}^{s-1/q} D_{l} V\|_{L_{q}(\mathbb{R}^{n+1})} \\ & \leq K \|u\|_{W^{s}(\mathbb{R}^{n})} \|v\|_{W^{1-s}(\mathbb{R}^{n})}, \end{split}$$

where K is some constant produced by Lemma 1.4.1.4. Taking the limit when  $x_{n+1} \rightarrow 0$ , one gets

$$|\langle D_{\mathbf{j}}u;v\rangle| \leq K \|u\|_{W^{s}_{q}(\mathbb{R}^{n})} \|v\|_{W^{1-s}_{q}(\mathbb{R}^{n})}.$$

This proves Lemma 1.4.1.3.

As a consequence of Lemma 1.4.1.3, it is clear that for  $u \in W_p^s(\bar{\Omega})$ ,  $D_j u$  is the restriction to  $\Omega$  of a distribution belonging to  $W_p^{s-1}(\mathbb{R}^n)$ . Consequently, a complete answer to the question of whether or not  $D_j$  maps  $W_p^s(\Omega)$  into  $W_p^{s-1}(\Omega)$  will follow the study of continuation and restriction properties.

#### 1.4.2 Density results

Here we quote only one basic result proved in Agmon (1959) and Nečas (1967) for instance. We denote by  $C_c^{\infty}(\bar{\Omega})$  the space of all functions defined in  $\Omega$  which are restrictions to  $\Omega$  of  $C^{\infty}$  functions with compact support in  $\mathbb{R}^n$ .

**Theorem 1.4.2.1** Let  $\Omega$  be an open subset of  $\mathbb{R}^n$  with a continuous boundary; then  $C_c^{\infty}(\bar{\Omega})$  is dense in  $W_p^s(\Omega)$  for all s > 0.

It follows easily from Definition 1.3.2.3 that  $C^{\infty}(\bar{\Omega})$  is dense in  $W_p^s(\Omega)$  for all s < 0, without any hypothesis on  $\Omega$ .

Moreover,  $\mathfrak{D}(\mathbb{R}^n)$  is dense in  $W_p^s(\mathbb{R}^n)$  for all s and consequently  $C_c^{\infty}(\bar{\Omega})$  is dense in  $W_p^s(\bar{\Omega})$  without any assumption on  $\Omega$ .

Another result, closely related to Theorem 1.4.2.1, is the following:

**Theorem 1.4.2.2** Let  $\Omega$  be an open subset of  $\mathbb{R}^n$  with a continuous boundary, then  $\mathfrak{D}(\Omega)$  is dense in  $\tilde{W}_p^s(\Omega)$  for all s > 0.

Together with the identity (1,3,2,10), this shows that when s = m is an integer and  $\Omega$  is a domain with a continuous boundary, then

$$\tilde{\mathbf{W}}_{p}^{m}(\Omega) = \mathbf{\mathring{W}}_{p}^{m}(\Omega). \tag{1,4,2,1}$$

An easy and useful consequence of Theorem 1.4.2.2 is the following:

*Proposition 1.4.2.3 Let 11 be an open subset* of *Rn with a continuous boundary and let T belong to W,(") with s <0. Then the restriction* of *T to ,fl belongs to the dual space* of Wq S(Q).

Finally we state an improvement of Theorem 1.4.2.1 in the particular case when s 1 /p.

*Theorem 1.4.2.4 Let (2 be a bounded open subset* of *ff " with a Lipschitz boundary; then 2(f2) is dense in W p(L2) ƒor 0< s ;1 /p.*

The same is true when *Sl* is uniform Lipschitz epigraph (Definition 1.2.1.6).

In view of Theorem 1.4.2.1 we only have to approximate functions in C(Q) by functions in 2(D) for the norm of Wp(,f2). This is easily achieved by means of a sequence of cut-off functions.

A direct consequence is that under the assumptions of Theorem 1.4.2.4, Wp((2) is the same space as W ,(f2), when 0< s ;1/p.

#### 1.4.3 Continuation, compactness and convexity inequalities

Now we clarify partly the relation between W(f2) and Wp(). The following result is proved in Agmon (1965), Aronszajn and Smith (1961), Lions (1957), Necas (1967), Stein (1970).

*Theorem 1.4.3.1 Let (2 be a bounded open subset* of Rn *with a Lipschitz boundary; then for every s >0 there exists a continuous linear operator P<sup>S</sup> Erom W'(() into W,(on) such that*

$$P_{s}u\mid_{\Omega}=u. \tag{1,4,3,1}$$

The same resuits hold when D is an uniform Lipschitz epigraph or an infinite strip.

In other words each function u e W' (L2) is the restriction of a function P,u E W'(R/z). A counterexample in Lions (1957) shows that the property may not hold when fl has not a Lipschitz boundary. Consequently we have Wp((2) = *W(f2)* when *D* is bounded and has a Lipschitz boundary.

In addition it has been shown in Seeley (1964) and Aronszajn and Smith (1961) that PS can be chosen independently of s.

The continuation theorems are powerful tools for extending several results proved on R" to similar results on a bounded domain with a Lipschitz boundary. We list some of them now.

**Theorem 1.4.3.2** Let  $s' > s'' \ge 0$  and assume that  $\Omega$  is a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary. Then the injection of  $W_p^{s'}(\Omega)$  in  $W_p^{s''}(\Omega)$  is compact.

(For the sake of convenience here we define  $W_p^0(\Omega)$  as being  $L_p(\Omega)$ .) This result originally due to Kondrašov (1945) is proved in Nečas (1961) for the case in which s' and s'' are integers. The extension to possibly non-integer values of s' and s'' may be found in Lions and Peetre (1964).

The following inequality is closely related to the previous theorem, through a lemma of Lions (cf. Lemma 2,7, Chapter 1 in Magenes and Stampacchia (1958)).

**Theorem 1.4.3.3** Let  $s' > s'' > s''' \ge 0$  and assume that  $\Omega$  is a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary. Then there exists a constant C (depending on  $\Omega$ , s', s'', s''' and p) such that

$$\|u\|_{s'',p,\Omega} \leq \varepsilon \|u\|_{s',p,\Omega} + K \varepsilon^{-(s''-s''')/(s'-s'')} \|u\|_{s''',p,\Omega}$$
for all  $u \in W_p^{s'}(\Omega)$ . (1,4,3,2)

Such an inequality is also true when  $\Omega = \mathbb{R}^n$  or  $\Omega$  is any subset of  $\mathbb{R}^n$  with the continuation property of Theorem 1.4.3.1.

This is an interpolation inequality which follows from the similar inequality on  $\mathbb{R}^n$ . See Lions and Magenes (1960–63) for a proof. In the case when s', s'' and s''' are integers, this is a particular case of more general inequalities by Gagliardo (1958) and Nirenberg (1959).

Let us also recall here a related inequality often referred to as Poincare's inequality (cf. Nečas (1967), for instance).

**Theorem 1.4.3.4** Assume that  $\Omega$  is a bounded open subset of  $\mathbb{R}^n$ . Then there exists a constant  $K(\Omega)$  which depends only on the diameter of  $\Omega$  such that

$$||u||_{0,p,\Omega} \le K(\Omega) \left\{ \sum_{i=1}^n \int_{\Omega} \left| \frac{\partial u}{\partial x_i} \right|^p dx \right\}^{1/p}$$
 (1,4,3,3)

for all  $u \in \mathring{W}^{1}_{p}(\Omega)$ .

Closely related to the inequality in Theorem 1.4.3.3 is the interpolation theorem (cf. Lions and Peetre (1964)).

**Theorem 1.4.3.5** Let  $\Pi$  be a continuous linear operator in  $W_p^s(\mathbb{R}^n)$ ,  $1 , <math>s \in \mathbb{R}$ . Assume that for some t > s the restriction of  $\Pi$  to  $W_p^t(\mathbb{R}^n)$ 

is *continuous in Wp(R ). Then for every u* E ]s, *t[, the restriction* of *II to W"(R') is continuous in W"(*llr) .

Due to the continuation property a similar statement holds concerning the Sobolev spaces on D a bounded open subset of R" with a Lipschitz boundary.

#### 1.4.4 Imbeddings

The most outstanding result about Sobolev spaces is the famous imbedding theorem, derived first by Sobolev himself. The main statement is this:

#### *Theorem 1.4.4.1 The following inclusions hold:*

$$W_p^s(\mathbb{R}^n) \subseteq W_q^t(\mathbb{R}^n) \tag{1,4,4,1}$$

*for t s and q p such that s — n/p = t — n/q t* and

$$W_p^s(\mathbb{R}^n) \subset C^{k,\alpha}(\mathbb{R}^n) \tag{1,4,4,2}$$

for k < s — n/p *< k + 1, where a = s — k* — n/p, *k a nonnegative integer.*

It is possible to state a weaker result in the limit cases when s *—* n/p is an integer, as follows. We have

$$W_{\mathsf{p}}^{n/\mathsf{p}}(\mathbb{R}^n) \subset L_q(\mathbb{R}^n) \tag{1,4,4,3}$$

for all q y p, and

$$W_{\mathfrak{p}}^{k+n/\mathfrak{p}}(\mathbb{R}^n) \subset C^{k-1,\alpha}(\mathbb{R}^n) \tag{1,4,4,4}$$

for all a E [O, 1[, where k is an integer —> 1.

The proof may be found in any of the references quoted before about Sobolev spaces.

As a consequence we have the following inclusions

$$W_{p}^{s}(\bar{\Omega}) \subset W_{q}^{t}(\bar{\Omega}) \tag{1.4.4.5}$$

for *t; s, q > p* such that s — n/p = *t —* n/q and

$$W_p^s(\bar{\Omega}) \subset C^{k,\alpha}(\bar{\Omega})$$
 (1,4,4,6)

for k <s — n/p < k + 1, a = s — k -- n/p, k a non-negative integer. These inclusions hold without any assumption on (2. As a consequence of Theorem 1.4.3.1, similar inclusions hold for Wp(Q), when ,l is a bounded open subset of l, with a Lipschitz boundary.

t Negative values of t are admitted and W(0) means L, (R" ).

SOBOLEV SPACES

The main interest of these results, in the subsequent sections, is the following. Assume we are able to build a solution to some given boundary value problem, which belongs to  $W_p^s(\Omega)$ , with s large enough; then we know that it is differentiable in the usual sense up to an order (strictly less) than s - n/p.

A by-product of Theorem 1.4.4.1 is that  $W_p^s(\mathbb{R}^n)$  is an algebra for s > n/p. The more general result which follows has been proved by Zolesio (1977).

**Theorem 1.4.4.2** Let  $s_1 \ge s$  and  $s_2 \ge s$  be such that either

$$s_1 + s_2 - s \ge n \left( \frac{1}{p_1} + \frac{1}{p_2} - \frac{1}{p} \right) \ge 0, \quad s_j - s > n \left( \frac{1}{p_j} - \frac{1}{p} \right), \quad j = 1, 2$$

or

28

$$s_1 + s_2 - s > n\left(\frac{1}{p_1} + \frac{1}{p_2} - \frac{1}{p}\right) \ge 0, \quad s_j - s \ge n\left(\frac{1}{p_i} - \frac{1}{p}\right), \quad j = 1, 2,$$

then  $u, v \mapsto u \cdot v$  is a continuous bilinear map from  $W_{p_1}^{s_1}(\mathbb{R}^n) \times W_{p_2}^{s_2}(\mathbb{R}^n)$  into  $W_p^s(\mathbb{R}^n)$ .

A similar statement holds for Sobolev spaces defined on a bounded open subset of  $\mathbb{R}^n$ , with a Lipschitz boundary. It is a complement to Theorem 1.4.1.1.

Imbedding results of a different sort deal with weighted spaces. They are consequences of the well-known Hardy inequality (more precisely Theorem 330 in *Hardy et al.* (1952)). Let us recall a convenient statement of the Hardy inequality. Here we denote by  $L_{p,\alpha}(\mathbb{R}_+)$  the space of all measurable functions u defined in  $\mathbb{R}_+$  such that

$$||u||_{L_{p,\alpha}}^p = \int_0^\infty |u(t)t^\alpha|^p dt < +\infty.$$

Then, we define two linear operators H and L by

$$(Hu)(t) = \frac{1}{t} \int_0^t u(s) \, ds$$
$$(Lu)(t) = \frac{1}{t} \int_0^\infty u(s) \, ds.$$

It turns out that H is linear continuous in  $L_{p,\alpha}(\mathbb{R}_+)$  iff  $\alpha + 1/p < 1$ , while L is linear continuous in  $L_{p,\alpha}(\mathbb{R}_+)$  iff  $\alpha + 1/p > 1$ . In both cases the norm of the operator is bounded by  $|\alpha + 1/p - 1|^{-1}$ .

**Theorem 1.4.4.3** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz

boundary  $\Gamma$  and denote by  $\rho(x)$  the distance from a point x to  $\Gamma$ . Then when 0 < s < 1/p, we have  $u/p s \in L_p(\Omega)$  for all  $u \in W_p^s(\Omega)$  and when  $1/p < s \le 1$ , we have  $u/p s \in L_p(\Omega)$  for all  $u \in W_p^s(\Omega)$ .

The same result holds (with the same proof) when  $\Omega$  is a uniform Lipschitz epigraph (Definition 1.2.1.6).

This result is proved in Grisvard (1963) for spaces defined on a half space  $\mathbb{R}^n_+$ . The result is extended to the case of a Lipschitz domain by bi-Lipschitz changes of coordinates (use Theorem 1.4.1.1 and Lemma 1.3.3.1).

Iteration of Theorem 1.4.4.3 provides a more complete result concerning the spaces  $\mathring{W}_{p}^{s}(\Omega)$ . Since this is not a result easy to find in the current literature on Sobolev spaces, we give the statement together with a detailed proof.

**Theorem 1.4.4.4** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary  $\Gamma$ , then for all  $u \in \mathring{W}_p^s(\Omega)$  such that s-1/p is not an integer, the following property holds:

$$\rho^{-s+|\alpha|}D^{\alpha}u \in L_{p}(\Omega) \tag{1,4,4,7}$$

for all  $|\alpha| \leq s$ .

**Proof** We observe first that by replacing s by  $s - |\alpha|$  it is enough to prove the result when  $|\alpha| = 0$ .

Let us consider first the case when  $\Omega = \mathbb{R}_+$  the nonnegative real axis and s = m is an integer. Then, for  $u \in \mathcal{D}(\mathbb{R}_+)$  we have

$$u(x) = \int_0^x \frac{(x-y)^{m-1}}{(m-1)!} u^{(m)}(y) dy$$

and consequently

$$\frac{|u(x)|}{x^m} \le \frac{1}{(m-1)!} \frac{1}{x} \int_0^x |u^{(m)}(y)| \, \mathrm{d}y, \tag{1,4,4,8}$$

Hardy's inequality (mentioned above) implies that

$$||x^{-m}u||_{L_p(\mathbb{R}_+)} \le \frac{p}{(m-1)!(p-1)} ||u^{(m)}||_{L_p(\mathbb{R}_+)}.$$

By density, this implies the desired result for  $\mathring{W}_{p}^{m}(\mathbb{R}_{+})$ .

Let us consider then the case when  $\Omega$  is still  $\mathbb{R}_+$  but  $s=m+\sigma$  is no longer an integer. We consider now  $v=u^{(m)}$ , which belongs to  $\mathring{W}_p^{\sigma}(\mathbb{R}_+)$ . We make use of the following strange identity:

$$v(x) = -w(x) + \int_{x}^{+\infty} \frac{w(y)}{y} dy$$
 (1,4,4,9)

where

$$w(x) = \frac{1}{x} \int_0^x \left[ v(t) - v(x) \right] dt.$$
 (1,4,4,10)

We first show that  $x^{-\sigma}w \in L_p(\mathbb{R}_+)$ . Indeed, we have

$$\begin{split} &\int_0^\infty x^{-\sigma p} \left( \frac{1}{x} \int_0^x \left[ v(t) - v(x) \right] \mathrm{d}t \right)^p \mathrm{d}x \\ &\leq \int_0^\infty x^{-\sigma p - 1} \int_0^x \left| v(t) - v(x) \right|^p \mathrm{d}t \, \mathrm{d}x \\ &\leq \int_0^\infty \int_0^\infty \frac{\left| v(t) - v(x) \right|^p}{\left| x - t \right|^{1 + \sigma p}} \, \mathrm{d}t \, \, \mathrm{d}x \leq \|v\|_{\sigma, p, \mathbb{R}_+}^p. \end{split}$$

Then Hardy's inequality shows that, when  $\sigma < 1/p$ ,

$$x^{-\sigma} \int_{x}^{\infty} \frac{w(y)}{y} \, \mathrm{d}y \in L_{p}(\mathbb{R}_{+})$$

and consequently  $x^{-\sigma}v \in L_p(\mathbb{R}_+)$ . Unfortunately, when  $\sigma > 1/p$ , using formula (1,4,4,9) is inconclusive; we therefore use

$$v(x) = -w(x) - \int_0^x \frac{w(y)}{y} dy$$
 (1,4,4,11)

with the same w. Now, Hardy's inequality shows that

$$x^{-\sigma} \int_0^x \frac{w(y)}{y} \, \mathrm{d}y \in L_p(\mathbb{R}_+),$$

and consequently, again,  $x^{-\sigma}v \in L_p(\mathbb{R}_+)$ . Now inequality (1,4,4,8) and one more application of Hardy's inequality implies that

$$x^{-m-\sigma}u \in L_p(\mathbb{R}_+).$$

This is the desired result in  $\mathring{W}_{p}^{s}(\mathbb{R}_{+})$  provided s-1/p is not an integer.

We conclude by extending this result to a general  $\Omega$ . Let us use the same notation as in Definition 1.2.1.1 and consider a function u whose support is contained in V. One can always reduce the general case to this particular case, using a partition of unity. Now for  $y' \in V'$  let us set

$$u_{y'}(t) = u(y', \varphi(y') - t).$$

For almost all  $y' \in V'$ , we have  $u_{y'} \in \mathring{W}_p^s(\mathbb{R}_+)$  and consequently  $t^{-s}u_{y'} \in L_p(\mathbb{R}_+)$  with

$$||t^{-s}u_{y'}||_{L_p(\mathbb{R}_+)}^p \leq K^p ||u_{y'}||_{s,p,\mathbb{R}_+}^p$$

where K does not depend on y'. Integrating this inequality in y' leads to

$$\|[\varphi(y')-y_n]^{-s}u\|_{L_p(\Omega)} \le K \|u\|_{s,p,\Omega}.$$

Since  $\varphi$  is a Lipschitz function, the weight  $\varphi(y') - y_n$  is equivalent to  $\rho(y)$ , the distance from y to  $\Gamma$ , throughout V. This completes the proof of Theorem 1.4.4.4.

**Corollary 1.4.4.5** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary; then when s-1/p is not an integer we have

$$\tilde{\mathbf{W}}_{p}^{s}(\Omega) = \mathring{\mathbf{W}}_{p}^{s}(\Omega), \tag{1,4,4,12}$$

and furthermore, when 0 < s < 1/p we have

$$\tilde{W}_{p}^{s}(\Omega) = \mathring{W}_{p}^{s}(\Omega) = W_{p}^{s}(\Omega). \tag{1,4,4,13}$$

**Proof** From Lemma 1.3.2.6 and Theorem 1.4.4.4, we know that the norms of  $W_p^s(\Omega)$  and of  $\tilde{W}_p^s(\Omega)$  are equivalent at least on  $\mathcal{D}(\Omega)$  when s-1/p is not an integer. Then, from Definition 1.3.2.2 and Lemma 1.4.2.2 we know that  $\mathcal{D}(\Omega)$  is dense in both spaces  $\tilde{W}_p^s(\Omega)$  and  $\mathring{W}_p^s(\Omega)$ . Consequently,  $\tilde{W}_p^s(\Omega)$  and  $\mathring{W}_p^s(\Omega)$  are the completions on  $\mathcal{D}(\Omega)$  for two equivalent norms. This proves identity (1,4,4,12).

We always have  $\tilde{W}_{p}^{s}(\Omega) \subseteq W_{p}^{s}(\Omega)$ . Then when s < 1/p, it follows from Theorem 1.4.4.3 and Lemma 1.3.2.6 that  $W_{p}^{s}(\Omega) = \tilde{W}_{p}^{s}(\Omega)$ . This proves identity (1,4,4,13).

Another useful consequence of Theorem 1.4.4.4 is the extension of Lemma 1.4.1.3 to a bounded open domain  $\Omega$  with a Lipschitz boundary.

**Theorem 1.4.4.6** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary. Then  $D_j$  is a linear continuous operator from  $W_p^s(\Omega)$  into  $W_p^{s-1}(\Omega)$  unless s=1/p.

**Proof** We have already seen in Subsection 1.4.1 that  $D_i$  maps  $W_p^s(\Omega)$  into  $W_p^{s-1}(\Omega)$  when either  $s \ge 1$  or  $s \le 0$ . Let us assume that 0 < s < 1. We know from Theorem 1.4.3.1 that  $W_p^s(\Omega) = W_p^s(\bar{\Omega})$ . Consequently, for  $u \in W_p^s(\Omega)$ ,  $D_i u$  is the restriction to  $\Omega$  of a distribution  $T \in W_p^{s-1}(\mathbb{R}^n)$ . More precisely, we have

$$\langle D_i u, v \rangle = \langle T, \tilde{v} \rangle$$

for every  $v \in \mathfrak{D}(\Omega)$ . Furthermore, we have

$$|\langle D_j u, v \rangle| \le ||T||_{s-1, p, \mathbb{R}^n} ||\tilde{v}||_{1-s, q, \mathbb{R}^n} = ||T||_{s-1, p, \mathbb{R}^n} ||V||_{1-s, q, \Omega}$$

where (1/p)+(1/q)=1. This shows that T belongs to the dual space of

 $\tilde{W}_q^{1-s}(\Omega)$ . Due to Corollary 1.4.4.5, this last space coincides with  $\mathring{W}_q^{1-s}(\Omega)$  provided  $1-s\neq 1/q$ ; this means  $s\neq 1/p$ . Therefore  $D_j u$  belongs to  $W_p^{s-1}(\Omega)$  provided  $s\neq 1/p$ .

Remark 1.4.4.7 The preceding proof shows that  $D_j u$  belongs to the dual space of  $\tilde{W}_q^{1/q}(\Omega)$  when u belongs to  $W_p^{1/p}(\Omega)$ . This result cannot be improved as will be shown now. Here, for simplicity, we assume that p=2.

**Proposition 1.4.4.8** The bilinear form (defined for u and v smooth)

$$u, v \mapsto \int_0^1 u'v \, \mathrm{d}x \tag{1,4,4,14}$$

has no continuous extension to  $H^{1/2}(]0, 1[) \times H^{1/2}(]0, 1[)$ .

This obviously implies that for  $u \in H^{1/2}(]0, 1[), u'$  is not necessarily in  $H^{-1/2}(]0, 1[)$ , the dual space of  $H^{1/2}(]0, 1[)$ , since  $H^{1/2}(]0, 1[) = \mathring{H}^{1/2}(]0, 1[)$  (see Theorem 1.4.2.4).

**Proof** Let us assume that (1,4,4,14) is continuous on  $H^{1/2}(]0,1[) \times H^{1/2}(]0,1[)$ ; then there exists a constant K such that

$$\int_0^1 u'v \, dx \le K \|u\|_{1/2,2,]0,1[} \|v\|_{1/2,2,]0,1[}$$

for all  $u, v \in \mathcal{D}([0, 1])$ . Now let us assume that  $v = \psi u$ , where  $\psi$  is some cut-off function  $(\psi \in \mathcal{D}([0, 1]), \psi(0) = 1$  and  $\psi(1) = 0$ ). We have

$$\int_0^1 u'v \, dx = \int_0^1 u'\psi u \, dx = -\frac{1}{2}u^2(0) - \frac{1}{2}\int_0^1 \psi' u^2 \, dx;$$

consequently, there exists a new constant C such that

$$|u(0)| \le C ||u||_{1/2,2,]0,1[}$$

for all  $u \in \mathcal{D}([0, 1])$ . By translation we also have

$$\max_{x \in [0,1/2]} |u(x)| \le C \|u\|_{1/2,2,]0,1[}.$$

By density, this last inequality implies that all the functions in  $H^{1/2}(]0, 1[)$  are continuous near zero. However, the particular function

$$u(x) = \log \left| \log \frac{x}{2} \right|$$

is an obvious counterexample to this property. Consequently, the form (1,4,4,14) cannot be continuous.

Remark 1.4.4.9 A by-product of the previous proof is that Sobolev's theorem (1.4.4.1) cannot be improved in the case where s = n/p (here n = 1 and p = 2). Indeed, we have

$$H^{1/2}(]0, 1[) \not\subset L_{\infty}(]0, 1[);$$

this is the negation of the inclusion (1,4,4,1) in the limit case. The same way, we have

$$H^{1/2}(]0,1[) \notin C^0([0,1])$$

and this is the negation of (1,4,4,2) in the limit case.

As a last consequence of Theorem 1.4.4.4, we can investigate further <sup>0</sup> the relations between W'(Il) and W(Q) in the exceptional case when s -- l /p is an integer.

*Corollary* 1.4.4.10 *Let ,i2 be a bounded open* subset *of* Rn with a Lipschitz *boundary; then for* all s >0, we have

$$\tilde{W}_{p}^{s}(\Omega) = \left\{ u \mid u \in \mathring{W}_{p}^{s}(\Omega), \frac{D^{\alpha}u}{\rho^{\sigma}} \in L_{p}(\Omega), |\alpha| = m \right\}$$
 (1,4,4,15)

*where p(x)* is the distante *from x* to the boundary *T of (* and s = m + a, m *integer,* o- E [0, 1 [.

Proof Let us denote by Z(fl) the space on the right-hand side of (1,4,4,15). From Theorem 1.4.2.2 we know that 2(,fl) is dense in W(fl) for the norm given by (1,3,2,11). This implies the inclusion

$$\tilde{W}_{p}^{s}(\Omega) \subseteq Z(\Omega).$$

To prove the converse inclusion, first we observe that

$$D^{\alpha}\tilde{u} = \widetilde{D^{\alpha}u}, \quad |\alpha| \le m \tag{1.4.4.16}$$

for all u E W *(Q).* This identity is obvious for *u E 2 (f);* it is extended to the whole of W P (Q) by density. Now let us start with u E Z(Q) . From (1,4,4,16) we deduce that *ü E* Wp (R'). To prove that *u E W'(Q),* we just need to check that *Dau e* Wp-m((^n), for *(al = m,* according to Definitions 1.3.2.5 and 1.3.2.1. This means that

$$\|D^\alpha u\|_{s-m,p,\Omega}^\sim$$

has to be finite, in view of (1,3,2,11). This is obvious from the assumption that ucZ(Q). n

#### 1.4.5 Spaces defined on polygons

In most of the forthcoming sections, we shail deal with plane domains whose boundaries are (possibly curvilinear) polygons. First we shall make

precise what we mean by curvilinear polygon. Then we shall review briefly the consequences of the results of the preceding sections, in the case when  $\Omega$  has such a polygonal boundary.

Roughly speaking a curvilinear polygon is a manifold with corners. More precisely, let us state a definition similar in most respects to Definition 1.2.1.2.

**Definition 1.4.5.1** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$ . We say that the boundary  $\Gamma$  is a curvilinear polygon of class  $C^m$ , m integer  $\geq 1$  (respectively  $C^{k,\alpha}$ , k integer  $\geq 1$ ,  $0 < \alpha \leq 1$ ) if for every  $x \in \Gamma$  there exists a neighbourhood V of x in  $\mathbb{R}^2$  and a mapping  $\psi$  from V in  $\mathbb{R}^2$  such that

- (a)  $\psi$  is injective,
- (b)  $\psi$  together with  $\psi^{-1}$  (defined on  $\psi(V)$ ) belongs to the class  $C^m$  (respectively  $C^{k,\alpha}$ ).
- (c)  $\Omega \cap V$  is either

or

$$\{y \in \Omega \mid \psi_2(y) < 0\}, \{y \in \Omega \mid \psi_1(y) < 0 \text{ and } \psi_2(y) < 0\}$$
  
 $\{y \in \Omega \mid \psi_1(y) < 0 \text{ or } \psi_2(y) < 0\}$ 

where  $\psi_i(y)$  denotes the jth component of  $\psi$ .

Any domain  $\Omega$  fulfilling the requirements in Definition 1.4.5.1 has a Lipschitz boundary according to Definition 1.2.1.1. Consequently, the Sobolev spaces on  $\Omega$  will have all the properties already listed for Sobolev spaces on bounded domains with Lipschitz boundary. However, the actual advantages of these domains will appear clearly in the next section dedicated to the trace theorems.

**Theorem 1.4.5.2** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$  whose boundary  $\Gamma$  is a curvilinear polygon. Then we have the following inclusions and identities:

- (a)  $\tilde{W}_{p}^{s}(\Omega) \subseteq \tilde{W}_{p}^{s}(\Omega) \subseteq W_{p}^{s}(\bar{\Omega}) = W_{p}^{s}(\Omega)$  for s > 0.
- (b)  $\tilde{W}_{p}^{s}(\Omega) = \mathring{W}_{p}^{s}(\Omega)$  for s 1/p non-integer,
- (c)  $W_p^s(\Omega) = W_p^s(\Omega)$  for s < 1/p,

(d) 
$$\tilde{W}_{p}^{s}(\Omega) = \left\{ u \in \mathring{W}_{p}^{s}(\Omega) \middle| \frac{D^{\alpha}u}{\rho^{\sigma}} \in L_{p}(\Omega), |\alpha| = m \right\}$$

for  $s = m + \sigma$ , m a non-negative integer. Furthermore,  $C^{\infty}(\bar{\Omega})$  is dense in  $W_p^s(\Omega)$  and  $\mathfrak{D}(\Omega)$  is dense in  $\tilde{W}_p^s(\Omega)$  for all s > 0. We also have

(e) 
$$W_p^s(\Omega) \subseteq W_q^t(\Omega)$$
,  $s - \frac{2}{p} = t - \frac{2}{q}$ ,  $t \le s$ 

and

(f) 
$$W_p^s(\Omega) \subseteq C^{k,\alpha}(\bar{\Omega}), k+\alpha = s - \frac{2}{p}$$

for s-2/p>0, not an integer.

In practice, we shall often have to check whether or not some concrete functions belong to a given Sobolev space. For instance, we shall deal with functions which have an isolated singularity. A criterion for such functions is the following.

**Theorem 1.4.5.3** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$ , whose boundary  $\Gamma$  is a curvilinear polygon. Assume that  $0 \in \Gamma$ . Let V be a neighbourhood of 0 such that

$$V \cap \bar{\Omega} \subseteq \{(r \cos \theta, r \sin \theta) | r \ge 0, a \le \theta \le b\}$$

with  $b-a<2\pi$ . Finally let u be a function which is smooth in  $\bar{\Omega}\setminus\{0\}$  and which coincides with

$$r^{\alpha}\varphi(\theta)$$

in  $V \cap \Omega$ , where  $\varphi \in C^{\infty}([a, b])$ . Then

$$u \in W_p^s(\Omega)$$
 for Re  $\alpha > s - \frac{2}{p}$  (1,4,5,1)

while

$$u \notin W_p^s(\Omega)$$
 for Re  $\alpha \le s - \frac{2}{p}$  (1,4,5,2)

when Re  $\alpha$  is not an integer.

It is very easy to check these inclusions when s is an integer. However, when s is not an integer the double integrals which appear in the norm (1,3,2,2) are so complicated that it is almost impossible to estimate them directly. The method of proof devised by Babuška consists in proving that  $u \in W_r^m(\Omega)$  for m integer >s and r < p and then using the Sobolev imbeddings. We get thus all the desired results when  $p \ge 2$ . The general proof for p < 2 makes use of weighted Sobolev spaces; we skip it since we shall mostly need inclusion (1,4,5,1) when  $p \ge 2$ .

**Proof** A derivative of order m of u behaves as a finite sum of functions  $r^{\alpha-m}\psi(\theta)$ , where  $\psi \in C^{\infty}([a,b])$ , in  $V \cap \Omega$  (This is true unless  $\alpha$  is an integer where cancellations can occur.) Consequently its rth power is

integrable in  $\Omega$  iff Re  $\alpha > m-2/r$ . In other words

$$\begin{cases} u \in W_r^m(\Omega) & \text{if Re } \alpha > m - \frac{2}{r} \\ u \notin W_r^m(\Omega) & \text{if Re } \alpha \le m - \frac{2}{r}. \end{cases}$$

By Sobolev imbeddings it follows that

- (a)  $u \in W_p^s(\Omega)$  provided there exists an integer  $m \ge s$  and an  $r \in ]1, p]$  such that Re  $\alpha > m 2/r$  and m 2/r = s 2/p. This last condition is always fulfilled when  $p \ge 2$ .
- (b)  $u \notin W_p^s(\Omega)$  when there exists an integer  $m \le s$  and an  $r \ge p$  such that  $\text{Re } \alpha \le m 2/r$  and m 2/r = s 2/p. This last condition is always fulfilled when  $p \le 2$ .

So far, we have proved (1,4,5,1) when  $p \ge 2$  and (1,4,5,2) when  $p \le 2$ . We shall not attempt to extend (1,4,5,1) to all values of p < 2 since this requires the use of weighted spaces as we already mentioned it earlier. However, the extension of (1,4,5,2) to all p > 2 is simple at least when s - 2/p is not an integer. Indeed, a derivative of order m of u is clearly Hölder continuous with exponent  $\text{Re } \alpha - m$  when  $m < \text{Re } \alpha \le m + 1$ , and it is not Hölder continuous with a larger exponent. Consequently, the second Sobolev imbedding implies (1,4,5,2) in the remaining cases when  $\text{Re } \alpha < s - 2/p$ .

Remark 1.4.5.4 Similar results hold for the functions  $r^{\alpha}(\ln r)\varphi(\theta)$ .

#### 1.5 Traces

Among the many consequences of Sobolev's imbeddings is the continuity of the functions belonging to  $W_p^s(\Omega)$  when s > n/p. It is even continuity up to the boundary, which allows one to consider the values on the boundary, of such functions. This is obviously of the utmost importance in the study of boundary value problems. However, if we agree to consider boundary values of functions in a weaker sense, we can relax the condition on s. This is the purpose of the present section.

#### 1.5.1 Hyperplanes

Here, for the sake of convenience, we denote by  $\gamma_n$  the operator defined by

$$(\gamma_n u)(x_1,\ldots,x_{n-1})=u(x_1,\ldots,x_{n-1},0)$$

when u is a smooth function, continuous, say. In other words, we want to consider the restriction of u on the hyperplane  $x_n = 0$ . The basic fact about  $\gamma_n$  is that  $\gamma_n u$  is well defined as soon as  $u \in W_p^s(\mathbb{R}^n)$  when s > 1/p. We observe that this condition is less restrictive than the condition s > n/p which is necessary for ensuring the continuity with respect to all variables.

The proof of the following result may be found in Agmon (1965) when p = 2, in Nečas (1967) when s is an integer and in Uspenskii (1962) in the general case

**Theorem 1.5.1.1** Assume that s-1/p is not an integer and that  $s-1/p = k + \sigma$ ,  $0 < \sigma < 1$ , k an integer  $\ge 0$ . Then the mapping

$$u \mapsto \{\gamma_n u, \gamma_n D_n u, \ldots, \gamma_n D_n^k u\},\$$

which is defined for  $u \in \mathcal{D}(\mathbb{R}^n)$ , has a unique continuous extension as an operator from

$$W_p^s(\mathbb{R}^n)$$
 onto  $\prod_{j=0}^k W_p^{s-j-1/p}(\mathbb{R}^{n-1})$ .

This operator has a right continuous inverse which does not depend on p.

This result is easily extended to the case when  $\mathbb{R}^{n-1}$  is replaced by an (n-1)-dimensional submanifold of  $\mathbb{R}^n$ , which is smooth enough. This simply uses changes of variables. More precisely, when  $\Gamma$  is the Lipschitz boundary of a bounded open subset of  $\mathbb{R}^n$ , we define a normal vector field as follows. Let us keep the same notation as in Definition 1.2.1.1; then a unit outward normal vector  $\mathbf{v}$  is defined a.e. (for the usual surface measure on  $\Gamma$ ) by

$$\nu(y', \varphi(y')) = \frac{\{-D_1\varphi(y'), \dots, -D_{n-1}\varphi(y'), 1\}}{\sqrt{[1+D_1\varphi(y')^2 + \dots + D_{n-1}\varphi(y')^2]}}$$

for  $y' \in V'$ . This vector field is easily extended to the whole of V by defining it independently of  $x_n$ . Finally, by a partition of unity, we define an  $L^{\infty}$  vector field in a neighbourhood of  $\overline{\Omega}$ , such that  $\boldsymbol{\nu}$  is the unit outward normal a.e. on  $\Gamma$ . Then we observe that when the boundary of  $\Omega$  is of class  $C^{k,1}$ , the vector field  $\boldsymbol{\nu}$  is only of class  $C^{k-1,1}$ . Now we denote by  $\gamma$  the operator defined by  $(\gamma u) = u \mid_{\Gamma}$  when u is a smooth function.

**Theorem 1.5.1.2** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a  $C^{k,1}$  boundary  $\Gamma$ . Assume that s-1/p is not an integer,  $s \le k+1$ ,  $s-1/p = l+\sigma$ ,  $0 < \sigma < 1$ , l an integer  $\ge 0$ . Then the mapping

$$u \mapsto \left\{ \gamma u, \, \gamma \frac{\partial u}{\partial \nu}, \dots, \, \gamma \frac{\partial^l u}{\partial \nu^l} \right\}$$

which is defined for  $u \in C^{k,1}(\bar{\Omega})$ , has a unique continuous extension as an operator from

$$W^s_p(\Omega)$$
 onto  $\prod_{i=0}^l W^{s-j-1/p}_p(\Gamma)$ .

This operator has a right continuous inverse which does not depend on p.

The particular case when s = 1 and k = 0 was proved a long time ago by Gagliardo (1957).

**Theorem 1.5.1.3** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary  $\Gamma$ . Then the mapping  $u \to \gamma u$  which is defined for  $u \in C^{0,1}(\bar{\Omega})$ , has a unique continuous extension as an operator from  $W^1_p(\Omega)$  onto  $W^{1-1/p}_p(\Gamma)$ . This operator has a right continuous inverse independent of p.

In the sequel we shall always denote by  $\gamma$  the extended operator defined on the whole of  $W_n^1(\Omega)$  and we shall call it the trace operator.

In addition it is also possible to characterize the kernel of the trace operator  $\gamma$  and even of the mapping

$$u \mapsto \left\{ \gamma u, \, \gamma \frac{\partial u}{\partial \nu}, \, \ldots, \, \gamma \frac{\partial^l u}{\partial \nu^l} \right\},$$

in several cases.

**Theorem 1.5.1.4** Assume that s-1/p is not an integer and that  $s-1/p = k+\sigma$ ,  $0<\sigma<1$ , k an integer  $\geq 0$ . Then  $u \in \tilde{W}_p^s(\mathbb{R}_+^n)$  if and only if  $u \in W_p^s(\mathbb{R}_+^n)$  and

$$\gamma_n u = \gamma_n D_n u = \cdots = \gamma_n D_n^k u = 0.$$

Here we denote by  $\mathbb{R}^n_+$ , the half space defined by  $x_n > 0$ . By changing variables, we deduce the following result.

**Theorem 1.5.1.5** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a  $C^{k,1}$  boundary  $\Gamma$ . Assume that s-1/p is not an integer and that  $s-1/p=l+\sigma$ ,  $0<\sigma<1$ , l an integer  $\geq 0$ . Then for  $s\leq k+1$ ,  $u\in \tilde{W}_p^s(\Omega)$  if and only if  $u\in W_p^s(\Omega)$  and

$$\gamma u = \gamma \frac{\partial u}{\partial \nu} = \cdots = \gamma \frac{\partial^l u}{\partial \nu^l} = 0.$$

Remembering Corollary 1.4.4.5, we see that Theorem 1.5.1.5 implies also the following result.

**Corollary 1.5.1.6** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a  $C^{k,1}$  boundary  $\Gamma$ . Assume that  $s \le k+1$  and that s-1/p is not an integer. Let  $s-1/p=l+\sigma$ ,  $0<\sigma<1$ , l an integer  $\ge 0$ . Then  $u \in \mathring{W}^s_p(\Omega)$  if and only if  $u \in W^s_p(\Omega)$  and

$$\gamma u = \gamma \frac{\partial u}{\partial \nu} = \cdots = \gamma \frac{\partial^l u}{\partial \nu^l} = 0.$$

In some special problems related to the study of mixed boundary conditions on a regular boundary, it will be convenient to split the boundary  $\Gamma$  into pieces and correspondingly to split the trace operator  $\gamma$ . The related trace theorems follow. We first consider functions defined on  $\mathbb{R}^n$  and define  $\gamma_+$  and  $\gamma_-$  by

$$\begin{cases} \gamma_{+}u(x_{1},\ldots,x_{n-1}) = u(x_{1},\ldots,x_{n-1},0), x_{n-1} > 0 \\ \gamma_{-}u(x_{1},\ldots,x_{n-1}) = u(x_{1},\ldots,x_{n-1},0), x_{n-1} < 0. \end{cases}$$

**Theorem 1.5.1.7** Assume that s-1/p is not an integer and that  $s-1/p = k+\sigma$ ,  $0 < \sigma < 1$ , k an integer  $\ge 0$ . Then the mapping  $u \mapsto (\{f_i^+\}_{i=0}^k, \{f_i^-\}_{i=0}^k)$  defined by

$$f_j^{\pm} = \gamma_{\pm} D_n^j u, \qquad 0 \le j \le k$$

defined on  $\mathfrak{D}(\mathbb{R}^n)$  has a continuous extension as an operator from  $W^s_p(\mathbb{R}^n)$  on the subspace of

$$T = \prod_{j=0}^{k} W_{p}^{s-j-1/p}(\mathbb{R}_{+}^{n-1}) \times \prod_{j=0}^{k} W_{p}^{s-j-1/p}(\mathbb{R}_{-}^{n-1})$$

defined by the conditions

(a) 
$$\gamma_{n-1}D_{n-1}^lf_j^+ = \gamma_{n-1}D_{n-1}^lf_j^-, \quad l < s-j-\frac{2}{p}$$

and

(b) 
$$\int_0^{+\infty} \int_{\mathbb{R}^{n-2}} |D_{n-1}^l f_j^+(x_1, \dots, x_{n-2}, t) - D_{n-1}^l f_j^-(x_1, \dots, x_{n-2}, -t)|^p dx_1 \cdots dx_{n-1} \frac{dt}{t} < +\infty$$

for l = s - j - 2/p, when s - 2/p is an integer.

The notation is self explanatory: we denote by  $\mathbb{R}^{n-1}_{\pm}$  the subset of  $\mathbb{R}^{n-1}$  defined by  $x_{n-1} \ge 0$  respectively,  $\gamma_{n-1}$  is the trace operator on the hyperplane  $x_{n-1} = 0$  defined in Theorem 1.5.1.1. This statement is a direct consequence of Theorem 1.5.1.1 through the following lemma.

SOBOLEV SPACES

**Lemma 1.5.1.8** Let  $f^{\pm} \in W_n^r(\mathbb{R}^{n-1}_+)$  and define f by

$$f(x) = f^{\pm}(x)$$
 when  $x_{n-1} \ge 0$ ;

then  $f \in W_p^r(\mathbb{R}^{n-1})$  if and only if

40

(a) 
$$\gamma_{n-1}D_{n-1}^{l}f^{+} = \gamma_{n-1}D_{n-1}^{l}f^{-}, \quad l < r - \frac{1}{p},$$

(b) 
$$\int_0^{+\infty} \int_{\mathbb{R}^{n-2}} |D_{n-1}^l f^+(x_1, \dots, x_{n-2}, t) - D_{n-1}^l f^-(x_1, \dots, x_{n-2}, t)|^2 dx_1 \cdots dx_{n-2} \frac{dt}{t} < +\infty$$

for l = r - 1/p when r - 1/p is an integer.

The corresponding results for a domain whose boundary is not a hyperplane will be detailed only in the case of a plane domain in the next subsection.

All the results that we have mentioned so far about trace properties are rather qualitative. It is often useful to have also quantitative results for traces. Here is a very elementary result in that direction. Before stating it, we need an auxiliary result about Lipschitz boundaries.

**Lemma 1.5.1.9** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary  $\Gamma$ . Then there exist  $\delta > 0$  and  $\mu \in C^{\infty}(\bar{\Omega})^n$  such that

$$\mu \cdot \nu \geqslant \delta \text{ a.e. on } \Gamma.$$
 (1,5,1,1)

Inequality (1,5,1,1) means that  $\mu$  is not very different from the normal  $\nu$  on  $\Gamma$ . However,  $\mu$  is much smoother than  $\nu$ .

**Proof** It is very easy to define  $\mu$  locally. In the notation of Definition 1.2.1.1 we can choose  $\mu_V$  (in V) as the unit vector in the direction of  $y_n$ . Indeed, the component of  $\nu$  in the direction of  $y_n$  is  $[1+|\nabla \varphi(y')|^2]^{-1/2}$  and consequently we have

$$\mu_{V} \cdot \nu \ge [1 + L_{V}]^{-1/2}$$

where  $L_V^2$  is the Lipschitz constant of  $\varphi$  in V'.

Then we cover the boundary  $\Gamma$  of  $\Omega$  by the interiors of a finite number of hypercubes  $V_k$ ,  $1 \le k \le K$ , each of which fulfils the conditions of Definition 1.2.1.1. To each  $V_k$  corresponds a vector  $\mu_{V_k}$  by the construction described above. Then we can define  $\mu$  as follows:

$$\boldsymbol{\mu} = \sum_{k=1}^{K} \theta_k \, \boldsymbol{\mu}_{V_k}$$

where  $\theta_k$ ,  $1 \le k \le K$ , is a partition of unity on  $\Gamma$  such that  $\theta_k \in \mathcal{D}(\mathbb{R}^n)$ ,  $\theta_k \ge 0$  and  $\theta_k$  has its support in the interior of  $V_k$ .

Obviously  $\mu$  is a smooth vector field, and on  $\Gamma$  we have

$$\mu \cdot \nu = \sum_{k=1}^{K} \theta_k \mu_{V_k} \cdot \nu \ge \inf_{k=1}^{K} \left[ 1 + L_{V_k}^2 \right]^{-1/2} = \delta. \quad \blacksquare$$

**Theorem 1.5.1.10** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary  $\Gamma$ . Then there exists a constant K such that

$$\int_{\Gamma} |\gamma u|^p d\sigma \le K \left[ \varepsilon^{1-1/p} \int_{\Omega} |\nabla u|^p dx + \varepsilon^{-1/p} \int_{\Omega} |u|^p dx \right]$$
 (1.5,1,2)

for all  $u \in W^1_p(\Omega)$  and  $\varepsilon \in ]0, 1[$ . In addition K depends only on the norm of  $\mu$  in  $C^1(\bar{\Omega})$  and on  $\delta$  (defined in Lemma 1.5.1.9).

**Proof** In view of Theorem 1.4.2.1 it is sufficient to prove inequality (1,5,1,2) for all  $u \in C^1(\bar{\Omega})$ . For such a function, we have

$$\int_{\Omega} \nabla |u|^{p} \cdot \mu \, dx = \sum_{j=1}^{n} \int_{\Omega} \frac{\partial |u|^{p}}{\partial x_{j}} \, \mu_{j} \, dx = \sum_{j=1}^{n} p \int_{\Omega} |u|^{p-2} u \frac{\partial u}{\partial x_{j}} \, \mu_{j} \, dx$$
$$= p \int_{\Omega} |u|^{p-2} u \, \nabla u \cdot \mu \, dx.$$

On the other hand, applying the Green theorem (see also Theorem 1.1, Section 3.1 in Nečas (1967), or Theorem 1.5.3.1) we obtain

$$\int_{\Omega} \nabla |u|^{p} \cdot \mu \, dx = \int_{\Gamma} |u|^{p} \, \mu \cdot \nu \, d\sigma - \int_{\Omega} |u|^{p} \, \operatorname{div} \mu \, dx.$$

It follows that

$$\int_{\Gamma} |u|^{p} \, \boldsymbol{\mu} \cdot \boldsymbol{\nu} \, d\sigma = p \int_{\Omega} |u|^{p-2} u \, \nabla u \cdot \boldsymbol{\mu} \, dx + \int_{\Omega} |u|^{p} \, \operatorname{div} \boldsymbol{\mu} \, dx$$

and consequently that

$$\delta \int_{\Gamma} |u|^{p} d\sigma \leq p \max_{\overline{\Omega}} |\mu| \int_{\Omega} |u|^{p-1} |\nabla u| dx + \max_{\overline{\Omega}} |\operatorname{div} \mu| \int_{\Omega} |u|^{p} dx.$$

Then, applying Hölder's inequality, we get

$$\delta \int_{\Gamma} |u|^p d\sigma \leq \|\mu\|_{C^1(\overline{\Omega})} \left\{ p \left( \int_{\Omega} |u|^p dx \right)^{1/q} \left( \int_{\Omega} |\nabla u|^p dx \right)^{1/p} + \int_{\Omega} |u|^p dx \right\}$$

where  $p^{-1} + q^{-1} = 1$  and then

$$\delta \int_{\Gamma} |u|^{p} d\sigma \leq \|\mu\|_{C^{1}(\overline{\Omega})} \Big\{ \varepsilon^{1-1/p} \int_{\Omega} |\nabla u|^{p} dx + \varepsilon^{-1/p} \frac{p}{q} \int_{\Omega} |u|^{p} dx + \int_{\Omega} |u|^{p} dx \Big\}.$$

This inequality, clearly implies (1,5,1,2) when  $\varepsilon \in ]0,1[$ .

#### 1.5.2 Polygons

The results stated in Theorem 1.5.1.2 and 1.5.1.3 are not sufficient for studying the Neumann problem in a domain whose boundary is a polygon. Indeed such a domain is never of class  $C^{1,1}$ . However, those theorems give us a hint of what happens.

First let us fix some notation. From now on, we consider a bounded open subset  $\Omega$  of  $\mathbb{R}^2$ , whose boundary is a curvilinear polygon of class  $C^{k,1}$ . We denote each of the  $C^{k,1}$  curves which constitute the boundary by  $\bar{\Gamma}_j$  for some j ranging from 1 to N. The curve  $\bar{\Gamma}_{j+1}$  follows  $\bar{\Gamma}_j$  according to the positive orientation, on each connected component of  $\Gamma$ . We denote by  $S_j$  the vertex which is the end point of  $\bar{\Gamma}_j$ . Following the same method as in Section 1.5.1 we define a  $C^{k-1,1}$  vector field  $\mathbf{v}_j$  on a neighbourhood of  $\bar{\Omega}$ , which is the unit outward normal a.e. on  $\Gamma_j$ . (We observe that  $\mathbf{v}_j = \mathbf{v}$  a.e. on  $\Gamma_j$ , but in general  $\mathbf{v}_j \neq \mathbf{v}$  inside  $\Omega$ .) Finally we denote by  $\omega_j$  the measure of the angle at  $S_j$  (toward the interior of  $\Omega$ ). For a smooth function  $\mathbf{u} \in \mathcal{D}(\bar{\Omega})$  we denote by  $\gamma_j \mathbf{u}$  its restriction to  $\Gamma_j$ . ( $\Gamma_j$  is the interior of  $\bar{\Gamma}_j$ , i.e., the set  $\bar{\Gamma}_j$  without its endpoints  $S_{j-1}$  and  $S_j$ .)

**Theorem 1.5.2.1** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$ , whose boundary is a curvilinear polygon of class  $C^{k,1}$ ; then for each j, the mapping

$$u \mapsto \left\{ \gamma_j u, \, \gamma_i \frac{\partial u}{\partial \nu_i}, \dots, \, \gamma_i \frac{\partial^l u}{\partial \nu_j^l} \right\}, \qquad l < s - \frac{1}{p},$$

which is defined for  $u \in \mathfrak{D}(\bar{\Omega})$ , has a unique continuous extension as an operator from

$$W_p^m(\Omega)$$
 onto  $\prod_{j=0}^l W_p^{m-j-1/p}(\Gamma_j)$ ,  $l \le m-1 \le k$ .

**Lemma 1.5.2.2** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$  whose boundary is a curvilinear polygon of class  $C^1$ . Let  $f_i = \gamma_i u$ ; then we have

$$\iint_{\Gamma_i \times \Gamma_k} \frac{|f_j(x) - f_k(y)|^p}{|x - y|^p} d\sigma(x) d\sigma(y) < +\infty.$$
(1,5,2,1)

This is just a consequence of the finiteness of the norm of  $\gamma u$  in  $W_p^{1-1/p}(\Gamma)$ . From (1,3,3,3), splitting the domain of integration  $\Gamma \times \Gamma$  in  $\bigcup_{i,k} \Gamma_i \times \Gamma_k$ , we get

$$\sum_{j=1}^{N} \iint\limits_{\Gamma_{i} \times \Gamma_{i}} \frac{|f_{j}(x) - f_{j}(y)|^{p}}{|x - y|^{p}} d\sigma(x) d\sigma(y)$$

$$+ 2 \sum_{j \neq k} \iint\limits_{\Gamma_{i} \times \Gamma_{k}} \frac{|f_{j}(x) - f_{k}(y)|^{p}}{|x - y|^{p}} d\sigma(x) d\sigma(y) < +\infty.$$

Since we already knew from Theorem 1.5.2.1 that  $f_i \in W_p^{1-1/p}(\Gamma_i)$ ,  $1 \le j \le N$  (and consequently  $f_i \in L_p(\Gamma_i)$ ,  $1 \le j \le N$ ), the condition (1,5,2,1) is automatically fulfilled when the distance from  $\Gamma_i$  to  $\Gamma_k$  is strictly positive. In other words, (1,5,2,1) is an extra condition only when  $\Gamma_i$  and  $\Gamma_k$  have a common end point. By possibly exchanging j and k, we can assume that k = j + 1. Then let  $\sigma$  be the distance along  $\Gamma$ , starting at  $S_i$ , and let  $x_i(\sigma)$  be the point on  $\Gamma$  whose distance to  $S_i$  is  $\sigma$ . Consequently for  $|\sigma|$  small enough,  $|\sigma| \le \delta_i$ , say, we have  $x_i(\sigma) \in \Gamma_i$  when  $\sigma < 0$  and  $x_i(\sigma) \in \Gamma_{i+1}$  when  $\sigma > 0$ . With these notations, condition (1,5,2,1) may be rewritten as

$$\int_0^{\delta_i} \int_0^{\delta_i} \frac{|f_{j+1}(x_j(\sigma)) - f_j(x_j(-\tau))|^p}{|\sigma + \tau|^p} d\sigma d\tau < +\infty$$
(1,5,2,2)

since the angle at  $S_i$  is not allowed to be 0 or  $2\pi$  (and therefore  $|x_i(\sigma)-x_i(-\tau)|$  and  $|\sigma+\tau|$  are equivalent functions). On the other hand, the fact that  $f_i \in W_p^{1-1/p}(\Gamma_i)$  and  $f_{i+1} \in W_p^{1-1/p}(\Gamma_{i+1})$  implies the convergence of the following integrals:

$$\int_0^{\delta_i} \int_0^{\delta_i} \frac{|f_j(x_j(-\sigma)) - f_j(x_j(-\tau))|^p}{|\tau - \sigma|^p} d\sigma d\tau < +\infty$$
(1,5,2,3)

$$\int_{0}^{\delta_{i}} \int_{0}^{\delta_{i}} \frac{|f_{j+1}(x_{j}(\sigma)) - f_{j+1}(x_{j}(\tau))|^{p}}{|\tau - \sigma|^{p}} d\sigma d\tau < +\infty.$$
 (1,5,2,4)

From these inequalities, we shall deduce the following result, which is nothing but a rephrasing of Gagliardo's theorem. For simplicity we assume that  $\Gamma$  has only one connected component and agree that  $\Gamma_{N+1} = \Gamma_1$ ; the extension of the forthcoming results to non-simply connected domains is obvious and just leads to complications in the notation.

**Theorem 1.5.2.3** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$  whose boundary  $\Gamma$  is a curvilinear polygon of class  $C^1$ . Then the mapping  $u \mapsto \{f_i\}_{i=1}^N$ , where  $f_i = \gamma_i u$ , is a linear continuous mapping from  $W_p^1(\Omega)$  onto the subspace of

**SOBOLEV SPACES** 

 $\prod_{i=1}^{N} W_{p}^{1-1/p}(\Gamma_{i})$  defined by

- (a) no extra condition when 1 ,
- (b)  $f_i(S_i) = f_{i+1}(S_i), 1 \le j \le N \text{ when } 2$

(c) 
$$\int_0^{\delta_i} \frac{|f_{j+1}(x_j(\sigma)) - f_j(x_j(-\sigma))|^2}{\sigma} d\sigma < \infty, \ 1 \le j \le N$$

when p=2.

We observe that condition (b) is meaningful since, for p > 2, it follows from Sobolev's imbedding theorem that  $f_i$  and  $f_{i+1}$  are continuous on  $\bar{\Gamma}_i$  and  $\bar{\Gamma}_{i+1}$  respectively. Furthermore, if for some particular  $u \in H^1(\Omega)$ ,  $f_i$  and  $f_{i+1}$  are Hölder continuous near  $S_i$ , then it is easily seen that condition (c) reduces to condition (b). Unfortunately, condition (b) is not always meaningful when p = 2, since functions in  $H^{1/2}(\Gamma_i)$  are not always continuous (see Remark 1.4.4.9). This is one of the few cases where Sobolev spaces related to p = 2 are more complicated to handle than Sobolev spaces related to  $p \neq 2$ .

**Proof** We know from Theorem 1.5.2.1, that for  $u \in W_p^1(\Omega)$ ,

$$\{f_j\}_{j=1}^N \in \prod_{j=1}^N W_p^{1-1/p}(\Gamma_j).$$

Furthermore, when p > 2, u is continuous up to the boundary  $\Gamma$  and consequently we have  $f_i = u \mid_{\Gamma_i}$  for all j; in particular, we have

$$u(S_i) = f_i(S_i) = f_{i+1}(S_i)$$

and this shows that condition (b) is necessary. Finally, in the limit case p = 2, condition (c) will follow from (1,5,2,2). Indeed, we have

$$\begin{split} & \left[ \int_{0}^{\delta_{i}} \int_{0}^{\delta_{i}} \frac{|f_{j+1}(x_{j}(\sigma)) - f_{i}(x_{j}(-\sigma))|^{2}}{|\sigma + \tau|^{2}} d\sigma d\tau \right]^{1/2} \\ & \leq \left[ \int_{0}^{\delta_{i}} \int_{0}^{\delta_{i}} \frac{|f_{j+1}(x_{j}(\sigma)) - f_{i}(x_{j}(-\tau))|^{2}}{|\sigma + \tau|^{2}} d\sigma d\tau \right]^{1/2} \\ & + \left[ \int_{0}^{\delta_{i}} \int_{0}^{\delta_{i}} \frac{|f_{i}(x_{j}(-\tau)) - f_{i}(x_{j}(-\sigma))|^{2}}{|\sigma - \tau|^{2}} d\sigma d\tau \right]^{1/2} \end{split}$$

and this is finite in view of (1,5,2,2) and of the fact that  $f_i$  belongs to  $H^{1/2}(\Gamma_i)$ . We conclude by observing that

$$\lim_{\sigma \to 0} \sigma \int_0^{\delta_i} \frac{d\tau}{|\sigma + \tau|^2} = 1$$

and consequently we have proved that

$$\int_0^{\delta_i} |f_{j+1}(x_j(\sigma)) - f_j(x_j(-\sigma))|^2 \frac{\mathrm{d}\sigma}{\sigma} < +\infty.$$

This is why condition (b) is necessary.

We now turn to prove that those conditions are sufficient.

First case  $1 . We want to prove that the mapping is onto; in other words, for every <math>\{f_j\}_{j=1}^N \in \prod_{j=1}^N W_p^{1-1/p}(\Gamma_j)$  we must show that there exists a  $u \in W_p^1(\Omega)$  such that  $\gamma_j u = f_j$ . For that purpose, we take advantage of Theorem 1.5.1.3 and it is enough to build up a function f on  $\Gamma$  from all the given  $f_j$  and to check that  $f \in W_p^{1-1/p}(\Gamma)$ . Thus we set

$$f(x) = f_i(x), \qquad x \in \Gamma_i$$

Since  $f_i$  is given in  $W_p^{1-1/p}(\Gamma_i)$ , we know that  $f \in L_p(\Gamma)$  and that

$$\int_{\Gamma_{i}} \int_{\Gamma_{i}} \frac{|f_{i}(x) - f_{k}(y)|^{p}}{|x - y|^{p}} d\sigma(x) d\sigma(y) < +\infty$$

is finite when j = k and when  $k \neq j - 1$ , j, j + 1 (so that the distance from  $\Gamma_j$  to  $\Gamma_k$  is strictly positive). Remembering identity (1,3,3,2), it remains to check that

$$I_{j}^{p} = \int_{\Gamma_{j+1}} \frac{|f_{j}(x) - f_{j+1}(y)|^{p}}{|x - y|^{p}} d\sigma(x) d\sigma(y) < +\infty.$$
 (1,5,2,5)

Indeed, we have

$$\begin{split} I_{j} & \leq \left[ \int_{\Gamma_{i}} |f_{i}(x)|^{p} \left\{ \int_{\Gamma_{i+1}} \frac{\mathrm{d}\sigma(y)}{|x-y|^{p}} \right\} \mathrm{d}\sigma(x) \right]^{1/p} \\ & + \left[ \int_{\Gamma_{i+1}} |f_{i+1}(y)|^{p} \left\{ \int_{\Gamma_{i}} \frac{\mathrm{d}\sigma(x)}{|x-y|^{p}} \right\} \mathrm{d}\sigma(y) \right]^{1/p}. \end{split}$$

Since  $\Gamma_{j+1}$  is a  $C^1$  curve, the function

$$\int_{\Gamma_{i+1}} \frac{\mathrm{d}\sigma(y)}{|x-y|^p}$$

is equivalent to  $d(x, \Gamma_{j+1})^{-p+1}$  and therefore

$$\begin{split} I_{j} &\leq K \bigg[ \int_{\Gamma_{j}} |f_{j}(x)|^{p} \frac{\mathrm{d}\sigma(x)}{\mathrm{d}(x; \Gamma_{j+1})^{p-1}} \bigg]^{1/p} + K \bigg[ \int_{\Gamma_{j+1}} |f_{j+1}(y)|^{p} \frac{\mathrm{d}\sigma(y)}{\mathrm{d}(y; \Gamma_{j})^{p-1}} \bigg]^{1/p} \\ &\leq K' \bigg\{ \|f\|_{L_{p}(\Gamma)} + \int_{0}^{\delta_{i}} |f_{j}(x_{i}(-\sigma))|^{p} \frac{\mathrm{d}\sigma}{\sigma^{p-1}} + \int_{0}^{\delta_{i}} |f_{j+1}(x_{j}(\sigma))|^{p} \frac{\mathrm{d}\sigma}{\sigma^{p-1}} \bigg\}^{1/p} \end{split}$$

where K and K' are some constants. The last two integrals are finite as is

shown in Theorem 1.4.4.3, since

$$1-\frac{1}{p}<\frac{1}{p}$$

when p < 2. Consequently, (1,5,2,5) is proved and  $f \in W_p^{1-1/p}(\Gamma)$ .

Second case  $2 \le p < \infty$ . We follow the same method and eventually we have to check the finiteness of  $I_i$ . This is equivalent to the finiteness of

$$I_i' = \left[ \int_0^{\delta_i} \int_0^{\delta_i} \frac{|f_j(x_j(-\sigma)) - f_{j+1}(x_j(\tau))|^p}{|\sigma + \tau|^p} d\sigma d\tau \right]^{1/p}.$$

This last integral is less than or equal to

$$\begin{split} & \left[ \int_{0}^{\delta_{i}} \int_{0}^{\delta_{i}} \frac{|f_{i}(x_{i}(-\sigma)) - f_{i+1}(x_{i}(\sigma))|^{p}}{|\sigma + \tau|^{p}} d\sigma d\tau \right]^{1/p} \\ & + \left[ \int_{0}^{\delta_{i}} \int_{0}^{\delta_{i}} \frac{|f_{i+1}(x_{i}(\sigma)) - f_{i+1}(x_{i}(\tau))|^{p}}{|\sigma - \tau|^{p}} d\sigma d\tau \right]^{1/p} \\ & \leq K \left[ \int_{0}^{\delta_{i}} |f_{i}(x_{i}(-\sigma)) - f_{i+1}(x_{i}(\sigma))|^{p} \frac{d\sigma}{\sigma^{p-1}} \right]^{1/p} + K \|f_{i+1}\|_{1-1/p, p, \Gamma_{i+1}}, \end{split}$$

$$(1,5,2,6)$$

where K is some constant. This is obviously finite when p=2 as a consequence of condition (c). Then when p>2 let us denote by h the function

$$\sigma \mapsto \psi(\sigma)[f_i(x_i(-\sigma)) - f_{i+1}(x_i(\sigma))]$$

where  $\psi$  is some smooth cut-off function, which is identically equal to 1 near zero and which is zero for  $\sigma \ge \frac{1}{2}\delta_i$ . We know that h belongs to  $W_p^{1-1/p}(]0, \delta_i[)$  and that  $h(\delta_i) = 0$  by construction and that h(0) = 0 in view of condition (b). Consequently, we have  $h \in \tilde{W}_p^{1-1/p}(]0, \delta_i[)$  by Corollary 1.5.1.5. Finally, it follows from Theorem 1.4.4.3 that

$$\frac{h}{\sigma^{1-(1/p)}} \in L_p(]0, \delta_i[)$$

and this shows the finiteness of the integral which appears in (1,5,2,6). Consequently we have shown the convergence of  $I'_i$  in all cases; this means that  $f \in W_p^{1-1/p}(\Gamma)$  and the proof of Theorem 1.5.2.3 is complete.

The remainder of this section is devoted to the extension of Theorem 1.5.2.3 to the spaces  $W_p^m(\Omega)$ , when m > 1. Essentially the method of proof is the same; however, for the sake of clarity we shall consider

successively the cases where  $\Omega$  is a quadrant, then a rectilinear polygon and finally a curvilinear polygon. First let us denote by  $\mathbb{R}_+ \times \mathbb{R}_+$  the first quadrant defined by x > 0 and y > 0.

**Theorem 1.5.2.4** The mapping  $u \mapsto \{\{f_k\}_{k=0}^{m-1}, \{g_l\}_{l=0}^{m-1}\}$  defined by

$$f_{k} = D_{y}^{k} u \big|_{y=0}, \qquad g_{l} = D_{x}^{l} u \big|_{x=0}$$
 (1,5,2,7)

for  $u \in \mathfrak{D}(\overline{\mathbb{R}_+ \times \mathbb{R}_+})$ , has a unique continuous extension as an operator from  $W_n^m(\mathbb{R}_+ \times \mathbb{R}_+)$  onto the subspace of

$$T = \prod_{k=0}^{m-1} W_p^{m-k-1/p}(\mathbb{R}_+) \times \prod_{l=0}^{m-1} W_p^{m-l-1/p}(\mathbb{R}_+)$$

defined by

(a) 
$$D_{x}^{l}f_{k}(0) = D_{y}^{k}g_{l}(0), \ l+k < m-2/p \ for \ all \ p, \ and$$
  
(b)  $\int_{0}^{1} |D_{x}^{l}f_{k}(t) - D_{y}^{k}g_{l}(t)|^{2} \frac{dt}{t} < +\infty, \ l+k = m-1$   
for  $p=2$ . (1,5,2,8)

(Here we shall denote by  $\gamma_1$  the trace operator on x = 0 and by  $\gamma_2$  the trace operator on y = 0; accordingly  $f_k = \gamma_2 D_v^k u$  and  $g_l = \gamma_1 D_x u$ .)

The proof makes use of a simple continuation result which is proved by applying twice Nikolski's continuation method (once with respect to each variable). This method is explained in Section 3.6, §3, Chapter 2 of Nečas (1967). See also Theorem 1.4.3.1 since  $\mathbb{R}_+ \times \mathbb{R}_+$  is a uniform Lipschitz epigraph.)

**Lemma 1.5.2.5** We have 
$$W_p^m(\overline{\mathbb{R}_+ \times \mathbb{R}_+}) = W_p^m(\mathbb{R}_+ \times \mathbb{R}_+)$$
.

**Proof of Theorem 1.5.2.4** Let U be any function in  $W_p^m(\mathbb{R}^2)$  such that u is the restriction of U to  $\mathbb{R}_+ \times \mathbb{R}_+$ . Applying Theorem 1.5.1.1, we see that the traces of u must be in T. Then for each k and l such that  $k+l \le m-1$ , we consider

$$u_{k,l} = D_x^l D_y^k u$$
, on  $]0, 1[\times]0, 1[$ .

It is obvious that  $u_{k,l}$  belongs to  $W_p^1(]0, 1[\times]0, 1[)$  and consequently conditions (a) and (b) in Theorem 1.5.2.4 follow from Theorem 1.5.2.3.

Now we are left with the problem of showing that the trace mapping is onto. We also need a continuation property on  $\mathbb{R}_+$  for spaces of fractional order.

**Lemma 1.5.2.6** We have  $W_p^s(\overline{\mathbb{R}_+}) = W_p^s(\mathbb{R}_+)$  for all s > 0.

**Proof** A short proof is the following. We can apply Theorem 1.4.3.1 to  $u_1$ , the restriction of a given  $u \in W^s_p(\mathbb{R}_+)$  to ]0, 1[. Let  $U = P_s u_1$  and let  $\varphi$  be a cut-off function such that  $\varphi(x) = 0$  for  $x \ge \frac{2}{3}$  and  $\varphi(x) = 1$  for  $x \le \frac{1}{3}$ ; then

$$\omega U + (1 - \omega)\tilde{u}$$

is the desired continuation of u.

End of the proof of Theorem 1.5.2.4 Let  $\{f_k\}_{k=0}^{m-1}$  and  $\{g_l\}_{l=0}^{m-1}$  fulfil all the conditions in Theorem 1.5.2.4. We must find  $u \in W_p^m(\mathbb{R}_+ \times \mathbb{R}_+)$  such that (1,5,2,7) holds. We first reduce our problem to the case when  $g_l = 0$  for all l. For that purpose, let  $G_l$  be a continuation of  $g_l$  with  $G_l \in W_p^{m-l-1/p}(\mathbb{R})$ . From Theorem 1.5.1.1 we know that there exists  $U \in W_p^m(\mathbb{R}^2)$ , such that  $\gamma_1 D_x^l U = G_l$ ,  $0 \le l \le m-1$ , where  $\gamma_1$  refers here to the trace operator on the hyperplane x = 0.

Then, instead of looking for u, we shall look for  $v = u - U|_{\mathbb{R}_+ \times \mathbb{R}_+} \in W_p^m(\mathbb{R}_+ \times \mathbb{R}_+)$  such that

$$\begin{cases} \gamma_2 D_y^k v = f_k - h_k, & 0 \le k \le m - 1 \\ \gamma_1 D_x^l v = 0, & 0 \le l \le m - 1 \end{cases}$$

where  $h_k = \gamma_2 D_y^k(U|_{\mathbb{R}_+ \times \mathbb{R}_+})$ . From the direct part of Theorem 1.5.2.4 which we have already proved, we know that

$$h_k \in W_p^{m-k-1/p}(\mathbb{R}_+)$$

and in addition

(c) 
$$D_x^l h_k(0) = D_y^k g_l(0)$$
,  $l + k < m - \frac{2}{p}$  for all  $p$  and

(d) 
$$\int_0^1 |D_x^l h_k(t) - D_y^k g_l(t)|^2 \frac{dt}{t} < +\infty, \ l+k = m-1$$

for p=2. Let us denote by  $\varphi_k$  the difference  $f_k-h_k$ ; then  $\varphi_k \in W_p^{m-k-1/p}(\mathbb{R}_+)$  and from (a)-(d) it follows that

$$\varphi_k^{(l)}(0) = 0, \qquad l < m - k - \frac{2}{p} \text{ for all } p$$
 (1,5,2,9)

and

$$\int_{0}^{1} |\varphi_{k}^{(l)}(t)|^{2} \frac{\mathrm{d}t}{t} < +\infty, \qquad l = m - k - 1 \text{ for } p = 2.$$
 (1,5,2,10)

At this step our problem is the following. We are seeking  $v \in$ 

Wp (EF x) such that

$$\begin{cases} \gamma_2 D_y^k v = \varphi_k, & 0 \le k \le m - 1 \\ \gamma_1 D_x^l v = 0, & 0 \le l \le m - 1. \end{cases}$$

For the time being, let us accept the following result.

*Lemma 1.5.2.7 Under* assumptions (1,5,2,9) and (1,5,2,10), we have Pk E W -k - i /P(R+), 0= k m —1.

This means that cpk E Wp -k-' /P(R), and applying Theorem 1.5.2.1 we know that there exists w E Wp (O 2) such that

$$\gamma_2 D_y^k w = \tilde{\varphi}_k,$$

where y2 refers to the trace operator on the hyperplane y = 0. Then we obtain v as follows:

$$v(x, y) = w(x, y) - \sum_{j=1}^{m} \lambda_{j} w(-jx, y), \quad x > 0, \quad y > 0$$

where the A; are real numbers such that

$$\sum_{j=1}^{m} (-j)^{l} \lambda_{j} = 1, \qquad 0 \leq l \leq m-1.$$

It is obvious that v E W' (R x R+). Then we have

$$(\gamma_1 D_y^k v)(x) = \tilde{\varphi}_k(x) - \sum_{j=1}^m \lambda_j \tilde{\varphi}_k(-jx) = \varphi_k(x)$$

for 0 = k - m —1, since x >0. We also have

$$(\gamma_2 D_x^l v)(y) = \left[1 - \sum_{j=1}^m \lambda_j (-j)^l\right] (\gamma_2 D_x^l w)(y) = 0$$

and consequently v is the desired function. The proof of Theorem 1.5.2.4 is complete provided we check Lemma 1.5.2.7. n

*Proof of* Lemma *1.5.2.7* We just need to extend some of the previous results valid on a finite open interval to the case of (J <sup>+</sup> . We again use a cut-off function iji which is identically equal to 1 for x < 3 and zero for x .. Then (1 — qi)cpk E W' - ' /P((^ <sup>+</sup> ) and its support is far from zero; it is readily seen from Definition 1.3.1.1 and Definition 1.3.2.5 that (1— :')cp <sup>k</sup> E <sup>W</sup>pm-k-1/p(R,). On the other hand, we can consider (cpk as belonging to Wp ^ k-' /p(]0, 1[). Applying Corollary 1.5.1.6 together with identity (1,4,4,12) when p 2 and Corollary 1.4.4.10 when p = 2, we see that

(1,5,2,9) and (1,5,2,10) imply that  $\psi \varphi_k \in \tilde{W}_p^{m-k-1/p}(]0,1[)$  and consequently that  $\psi \varphi_k \in \tilde{W}_p^{m-k-1/p}(\mathbb{R}_+)$ . The lemma is proved by addition, writing  $\varphi_k = \psi \varphi_k + (1-\psi)\varphi_k$ .

An extension of Theorem 1.5.2.4 to  $W_p^s(\mathbb{R}_+ \times \mathbb{R}_+)$  with a noninteger s can be found in Grisvard (1966). The method of proof followed here is close to the method used in Nikolski (1956a,b, 1956–58, 1961) for studying the traces of some slightly different spaces.

The previous results are easily extended to an infinite sector with angle  $\omega \in ]0, \pi[$ , by means of a linear change of coordinates. We also observe that the same results hold for the complement of the first quadrant owing to Lemma 1.5.2.5. Again, a linear change of coordinate allows one to extend those results to any infinite sector with angle  $\omega \in ]\pi, 2\pi[$ . Eventually using a partition of unity, we obtain the corresponding results on a polygon; for simplicity we assume its boundary to be of class  $C^{\infty}$ .

**Theorem 1.5.2.8** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$  whose boundary  $\Gamma$  is a curvilinear polygon of class  $C^{\infty}$ . Then the mapping  $u \to \{\gamma_i \partial^l u / \partial \nu_i^l \}$ ,  $1 \le j \le N$ ,  $0 \le l \le m-1$  is linear continuous from  $W_p^m(\Omega)$  onto the subspace of

$$T = \prod_{j=1}^{N} \prod_{l=0}^{m-1} W_{p}^{m-l-1/p}(\Gamma_{j})$$

defined by the following condition: Let L be any linear differential operator with coefficients of class  $C^{\infty}$  and of order  $d \leq m-2/p$ . Denote by  $P_{j,l}$  the differential operator tangential to  $\Gamma_j$  such that  $L = \sum_{l \geq 0} P_{j,l} \partial^l / \partial \nu_j^l$ ; then

(a) 
$$\sum_{l \ge 0} (P_{j,l}f_{j,l})(S_j) = \sum_{l \ge 0} (P_{j+1,l}f_{j+1,l})(S_j) \text{ for } d < m - \frac{2}{p}$$

(b) 
$$\int_{0}^{\delta_{i}} \left| \sum_{l \ge 0} (P_{i,l} f_{j,l})(x_{j}(-\sigma)) - \sum_{l \ge 0} (P_{j+1,l} f_{j+1,l})(x_{j}(\sigma)) \right|^{2} \frac{d\sigma}{\sigma} < +\infty$$

for d = m - 1 and p = 2.

**Proof** Using a partition of unity, we can restrict ourselves to the study of one vertex. Then a change of variables of class  $C^{\infty}$  replaces the corresponding vertex by zero, the angle by  $\pi/2$  or  $3\pi/2$  and the sides by the coordinate axis. Now the only difference between Theorems 1.5.2.4 and 1.5.2.8 is that in the former we only consider the operators  $D_x^l D_y^k$ , while in the latter we consider all the operators with coefficients in  $C^{\infty}$ . However, in the case of a right angle with straight sides, this is equivalent. Indeed, let the  $f_k$  and the  $g_l$  fulfil condition (a) of Theorem 1.5.2.4 and

51

let L be of order d < m - 2/p. We can write

$$L = \sum_{k=0}^{d} P_{2,k}(D_x) D_y^k = \sum_{l=0}^{d} P_{1,l}(D_y) D_x^l;$$
 (1,5,2,11)

then

$$\begin{cases} P_{2,k}(D_x) = \sum_{l=0}^{d-k} a_{k,l}(x, y) D_x^l \\ P_{1,l}(D_y) = \sum_{k=0}^{d-l} a_{k,l}(x, y) D_y^k. \end{cases}$$
(1,5,2,12)

Consequently we have

$$\begin{split} \sum_{k=0}^{d} \left[ P_{2,k}(D_{x}) f_{k} \right] (0) &= \sum_{k=0}^{d} \left\{ \sum_{l=0}^{d-k} a_{k,l}(0,0) D_{x}^{l} f_{k}(0) \right\} \\ &= \sum_{l=0}^{d} \left\{ \sum_{k=0}^{d-l} a_{k,l}(0,0) D_{y}^{k} g_{l}(0) \right\} = \sum_{l=0}^{d} \left[ P_{1,l}(D_{y}) g_{l} \right] (0) \end{split}$$

and this is condition (a) in Theorem 1.5.2.8 (with the necessary change of notation).

Then in the case p = 2, let us assume further that the  $g_k$  and the  $f_l$  fulfil condition (b) of Theorem 1.5.2.4. We want to check condition (b) of Theorem 1.5.2.8. A preliminary remark is that we also have

$$\int_{0}^{1} |D_{x}^{t} f_{k}(t) - D_{y}^{k} g_{t}(t)|^{2} \frac{dt}{t} < +\infty$$
(1,5,2,14)

for l+k < m-1. Indeed in that case we have

$$D_x^l f_k - D_y^k g_l \in H^{3/2}(]0, 1[).$$

From Sobolev's imbedding theorem, we know that  $D_x^l f_k - D_y^k g_l$  is Hölder continuous of order  $\alpha$  for every  $\alpha \in ]0, 1[$ . Since this function also vanishes at zero by assumption, there exists a constant K such that

$$|D_x^l f_k(t) - D_y^k g_l(t)| \le Kt^{\alpha}, \quad t \in ]0, 1[.$$

This implies (1,5,2,14). Then using the same identities (1,5,2,11), (1,5,2,12) and (1,5,2,13), it is easy to check condition (b) in Theorem 1.5.2.8.

Remark 1.5.2.9 In some questions related to the solution of mixed boundary value problems, we have to admit the value  $\pi$  as possible value for the measure of the angles of  $\Omega$ . In view of Theorem 1.5.1.7, the conditions (a) and (b) in Theorem 1.5.2.8 have to be replaced by the

following, when the measure of the angle at  $S_i$  is  $\pi$ :

(a) 
$$f_{j,l}(S_j) = f_{j+1,l}(S_j)$$
 for  $l < m - \frac{2}{p}$ 

(b) 
$$\int_0^{\delta_i} |f_{j,l}(x_j(-\sigma)) - f_{j+1,l}(x_j(\sigma))|^2 \frac{\mathrm{d}\sigma}{\sigma} < +\infty$$

for l = m - 1 and p = 2.

Remark 1.5.2.10 In the particular case when  $\Omega$  is a rectilinear polygon, it is enough to consider only those operators L which are homogeneous and with constant coefficients in the corresponding statement of Theorem 1.5.2.8.

Remark 1.5.2.11 As in Corollary 1.5.1.6 we can characterize the kernel of the mapping

$$u \mapsto \left\{ \gamma_j \frac{\partial^l u}{\partial \nu_i^l} \right\}, \qquad 1 \le j \le N, \quad 0 \le l \le m-1$$

as being  $\mathring{W}_{p}^{m}(\Omega)$ .

#### 1.5.3 Maximal domains of elliptic operators

So far, we have defined the trace of a function belonging to some Sobolev space  $W_p^s(\Omega)$ , under the assumption that s is larger than 1/p. However, it was shown in Lions and Magenes (1960–63) that when a function u is a solution, in  $\Omega$ , of an elliptic equation, u has traces on the boundary provided it belongs to any Sobolev space, without any restriction on s and p. The purpose of the present subsection is just to extend part of this result to the case of a domain with a polygonal boundary. A different approach to this kind of result is presented in Goulaouic and Grisvard (1970).

The method of proof devised by Lions and Magenes uses Green's formula. First we recall that Green's formula is valid in any bounded Lipschitz domain, as is shown in Nečas (1967) (Theorem 1.1, \$1, Chapter 3).

**Theorem 1.5.3.1** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary  $\Gamma$ . Then for every  $u \in W^1_p(\Omega)$  and  $v \in W^1_q(\Omega)$ , with 1/p + 1/q = 1, we have

$$\int_{\Omega} D_i u v \, dx + \int_{\Omega} u D_i v \, dx = \int_{\Gamma} \gamma u \gamma v v^i \, d\sigma \qquad (1,5,3,1)$$

( $\nu^i$  denotes the ith component of the vector field  $\mathbf{v}$  which was defined in Section 1.5.1.)

We shall apply this formula twice to derive the following, where A denotes a second-order elliptic operator with coefficients smooth enough.

$$Au = \sum_{i,k=1}^{n} D_{i}(a_{i,k}D_{k}u) + \sum_{i=1}^{n} a_{i}D_{i}u + a_{0}u.$$

Precisely, we assume that  $a_{i,k}$  and  $a_i$  are Lipschitz continuous and  $a_0 \in L_{\infty}(\Omega)$ . The adjoint operator will be denoted by  $A^*$ , i.e.,

$$A^*v = \sum_{i,k=1}^n D_k(a_{i,k}D_iv) - \sum_{i=1}^n D_i(a_iv) + a_0v.$$

The corresponding 'conormal derivatives' are

$$\frac{\partial u}{\partial \nu_A} = \sum_{i,k=1}^n a_{i,k} \nu^i D_k u, \qquad \frac{\partial v}{\partial \nu_A} = \sum_{i,k=1}^n a_{i,k} \nu^k D_i v.$$

**Lemma 1.5.3.2** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary  $\Gamma$ . Then for every  $u \in W_p^2(\Omega)$  and  $v \in W_q^2(\Omega)$  with 1/p + 1/q = 1, we have

$$\int_{\Omega} Auv \, dx - \int_{\Omega} uA^*v \, dx$$

$$= \int_{\Gamma} \gamma \frac{\partial u}{\partial \nu_A} \gamma v \, d\sigma - \int_{\Gamma} \gamma u\gamma \, \frac{\partial v}{\partial \nu_{A^*}} \, d\sigma + \int_{\Gamma} \left( \sum_{i=1}^{n} \nu^i a_i \right) \gamma u\gamma u \, d\sigma. \quad (1,5,3,2)$$

When  $\Omega$  is a plane bounded domain, whose boundary  $\Gamma$  is a  $C^{1,1}$  curvilinear polygon, we can restate this lemma. Using the same notation as in the previous subsection, we define, for each j, a Lipschitz vector field  $\mathbf{v}_i$  on  $\overline{\Omega}$ , such that  $\mathbf{v}_i$  is the unit outward normal a.e. on  $\Gamma_i$ . Accordingly, we define several 'conormal derivatives'

$$\frac{\partial u}{\partial \nu_{A,i}} = \sum_{i,k=1}^{2} a_{i,k} \nu_{i}^{i} D_{k} u, \qquad \frac{\partial v}{\partial \nu_{A^{*},i}} = \sum_{i,k=1}^{2} a_{i,k} \nu_{i}^{k} D_{i} v.$$

For  $u \in W_p^2(\Omega)$ ,  $v \in W_q^2(\Omega)$ , we have

$$\frac{\partial u}{\partial \nu_{A,j}} \in W_p^1(\Omega)$$
 and  $\frac{\partial v}{\partial \nu_{A^*,j}} \in W_q^1(\Omega)$ 

since  $a_{i,k}$  and  $\nu_i^i$  are all Lipschitz functions. Consequently,  $\gamma_i(\partial u/\partial \nu_{A,i})$  and  $\gamma_i(\partial v/\partial \nu_{A^*,i})$  are well defined and coincide a.e. on  $\Gamma_i$  with  $\gamma \partial u/\partial \nu_A$  and  $\gamma \partial v/\partial \nu_{A^*}$  respectively, as defined previously.

**Lemma 1.5.3.3** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$  whose boundary is a curvilinear polygon of class  $C^{1,1}$ . Then for every  $u \in W_p^2(\Omega)$  and  $v \in W_q^2(\Omega)$  with 1/p+1/q=1, we have

$$\int_{\Omega} Auv \, dx - \int_{\Omega} uA^*v \, dx$$

$$= \sum_{i=1}^{N} \left( \int_{\Gamma_{i}} \gamma_{i} \frac{\partial u}{\partial \nu_{A,j}} \gamma_{i}v \, d\sigma - \int_{\Gamma_{i}} \gamma_{i}u\gamma_{i} \frac{\partial v}{\partial \nu_{A^*,j}} \, d\sigma + \int_{\Gamma_{i}} \mathbf{v}_{i} \cdot \mathbf{a}\gamma_{i}u\gamma_{i}v \, d\sigma \right), \tag{1,5,3,3}$$

where **a** denotes the vector with components  $a_1$  and  $a_2$ .

The first consequence of this Green formula concerns the domain of the maximal extension of the operator A in  $L_p(\Omega)$ , which we denote by  $D(A; L_p(\Omega))$ . In other words<sup>†</sup>

$$D(A; L_p(\Omega)) = \{ u \in L_p(\Omega); Au \in L_p(\Omega) \}.$$

This is a Banach space for the norm

$$u \mapsto \{ \|u\|_{0,p,\Omega}^p + \|Au\|_{0,p,\Omega}^p \}^{1/p}.$$

Furthermore  $\mathfrak{D}(\bar{\Omega})$  is dense in  $D(A; L_p(\Omega))$  when  $\Omega$  has a  $C^{1,1}$  boundary. The same proof as in Lions and Magenes (1960-63) works, although they only deal with  $C^{\infty}$  boundaries. Then these authors show that the mapping

$$u\mapsto \left\{\gamma u\,;\,\gamma\,\frac{\partial u}{\partial\nu}\right\}$$

has a continuous extension as an operator from  $D(A; L_p(\Omega))$  into  $W_p^{-1/p}(\Gamma) \times W_p^{-1-1/p}(\Gamma)$ . Again, their method of proof allows one to handle domains with a  $C^{1,1}$  boundary. However, the similar result for a domain with a polygonal boundary deserves a proof.

**Theorem 1.5.3.4** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$ , whose boundary is a curvilinear polygon of class  $C^{1,1}$ . Then the mapping

$$u \mapsto \left\{ \gamma_j u, \, \gamma_j \frac{\partial u}{\partial \nu_{A,j}} \right\}$$

which is defined for  $u \in W_p^2(\Omega)$  has a unique continuous extension as an operator from  $D(A; L_p(\Omega))$  into

$$W_p^{-1/p}(\Gamma_j) \times W_p^{-1-1/p}(\Gamma_j)$$

† We observe that for  $u \in L_p(\Omega)$ , we have  $D_j u \in W_p^{-1}(\Omega)$  and consequently  $a_{ij}D_j u$  is well defined and belongs to  $W_p^{-1}(\Omega)$  too, since  $a_{ij}$  is Lipschitz continuous. Therefore, Au is well defined as an element of  $W_p^{-2}(\Omega)$ .

when  $p \neq 2$  and into

$$H^{-(1/2)-\varepsilon}(\Gamma_i)\times H^{-(3/2)-\varepsilon}(\Gamma_i)$$

for all  $\varepsilon > 0$  when p = 2.

Actually when p=2 we shall prove that the trace mapping defined above, maps  $D(A, L_2(\Omega))$  into the dual space of

$$\tilde{H}^{1/2}(\Gamma_i) \times \tilde{H}^{3/2}(\Gamma_i)$$
.

It will also be clear from the proof that it is enough to assume that A is nowhere characteristic on the boundary  $\Gamma$  of  $\Omega$ .

Finally, a different approach (as in Goulaouic and Grisvard (1970)) allows one to show that the trace mapping in Theorem 1.5.3.4 is onto. However, this is useless for the purpose of the next chapters.

**Proof** For  $u \in W_p^2(\Omega)$  and  $v \in W_q^2(\Omega)$ , it follows from (1,5,3,3) that

$$\left| \sum_{j=1}^{N} \left\{ \int_{\Gamma_{i}} \gamma_{i} \frac{\partial u}{\partial \nu_{A,j}} \gamma_{i} v \, d\sigma - \int_{\Gamma_{i}} \gamma_{i} u \left( \gamma_{i} \frac{\partial v}{\partial \nu_{A^{*},j}} - \mathbf{v}_{i} \cdot \mathbf{a} \gamma_{i} v \right) d\sigma \right\} \right| \leq K \|v\|_{2,q,\Omega},$$

where K is some constant depending on u. In particular, for a fixed j, we consider those functions v which belong to

$$V = \{ v \in W_q^2(\Omega) \mid \gamma_k v = \gamma_k \frac{\partial v}{\partial \nu_k} = 0 \quad \text{on} \quad \Gamma_k \quad \text{for} \quad k \neq j \}.$$

For  $v \in V$  we also have  $\gamma_k(\partial v/\partial v_{A*,k}) = 0$  on  $\Gamma_k$  for  $k \neq j$  and consequently

$$\left| \int_{\Gamma_i} \gamma_i \frac{\partial u}{\partial \nu_{A,i}} \gamma_i v \, d\sigma - \int_{\Gamma_i} \gamma_i u \left( \gamma_i \frac{\partial v}{\partial \nu_{A^*,i}} - \mathbf{v}_i \cdot \mathbf{a} \gamma_i v \right) d\sigma \right| \leq K \| v \|_{2,q,\Omega}.$$

$$(1,5,3,4)$$

On the other hand, we know from Theorem 1.5.2.8 that the mapping

$$v \mapsto \left\{ f_{i,0} = \gamma_i v; f_{i,1} = \gamma_i \frac{\partial v}{\partial \nu_i} \right\}$$

maps V onto the subspace of  $W_q^{2-1/q}(\Gamma_i) \times W_q^{1-1/q}(\Gamma_i)$  defined by the following conditions, where  $\tau_i$  is the unit tangent vector to  $\Gamma_i$  (following the positive orientation with respect to  $\Omega$ ).

(a) 
$$f_{j,0}(S_j) = f_{j,0}(S_{j-1}) = 0$$
 for all  $q$ 

(b) 
$$\frac{\partial}{\partial \tau_i} f_{i,0}(S_i) = \frac{\partial}{\partial \tau_i} f_{i,0}(S_{i-1}) = 0$$
 and  $f_{i,1}(S_i) = f_{i,1}(S_{i-1}) = 0$  for  $q > 2$ 

(c) 
$$\int_{0}^{\delta_{i}} \left| \left( \frac{\partial}{\partial \tau_{j}} f_{j,0} \right) (x_{j}(-\sigma)) \right|^{2} \frac{d\sigma}{\sigma} < +\infty,$$

$$\int_{0}^{\delta_{i-1}} \left| \left( \frac{\partial}{\partial \tau_{j}} f_{j,0} \right) (x_{j-1}(\sigma)) \right|^{2} \frac{d\sigma}{\sigma} < +\infty,$$

$$\int_{0}^{\delta_{i}} |f_{j,1}(x_{j}(-\sigma))|^{2} \frac{d\sigma}{\sigma} < +\infty \text{ and}$$

$$\int_{0}^{\delta_{i-1}} |f_{j,1}(x_{j-1}(\sigma))|^{2} \frac{d\sigma}{\sigma} < +\infty$$

for q=2.

These conditions show that  $f_{i,0} \in \mathring{W}_{q}^{2-1/q}(\Gamma_{i})$  and  $f_{j,1} \in \mathring{W}_{q}^{1-1/q}(\Gamma_{i})$  through Corollary 1.5.1.6, when  $q \neq 2$ ; however, when q = 2, these conditions show that  $f_{j,0} \in \tilde{H}^{3/2}(\Gamma_{j})$  and  $f_{j,1} \in \tilde{H}^{1/2}(\Gamma_{j})$  through Corollary 1.4.4.10. In other words,  $v \mapsto \{f_{i,0}; f_{i,1}\}$  maps V onto

$$\mathring{W}_{q}^{2-1/q}(\Gamma_{i}) \times \mathring{W}_{q}^{1-1/q}(\Gamma_{i})$$

when  $q \neq 2$  (and consequently  $p \neq 2$ ) and onto

$$\tilde{H}^{3/2}(\Gamma_{j}) \times \tilde{H}^{1/2}(\Gamma_{j})$$

when q = p = 2.

Now, since A is non-characteristic on  $\Gamma_i$ , we have

$$\gamma_i \frac{\partial v}{\partial \nu_{A^*,j}} = \alpha \gamma_i \frac{\partial v}{\partial \nu_i} + \beta_1 \gamma_i v + \beta_0 \frac{\partial}{\partial \tau_i} \gamma_i v$$

where  $\alpha$  is strictly positive on  $\Gamma_{j}$ . Conversely, we have

$$\gamma_{i} \frac{\partial v}{\partial \nu_{i}} = \frac{1}{\alpha} \gamma_{i} \frac{\partial v}{\partial \nu_{A^{*},i}} - \frac{1}{\alpha} \left\{ \beta_{1} \gamma_{i} v + \beta_{0} \frac{\partial}{\partial \tau_{i}} \gamma_{i} v \right\}.$$

It follows that

$$v \mapsto \left\{ \gamma_i v; \gamma_j \frac{\partial v}{\partial \nu_{A^*,j}} - \nu_i \cdot \mathbf{a} \gamma_i v \right\}$$

maps V onto

$$\mathring{W}_{q}^{2-1/q}(\Gamma_{j}) \times \mathring{W}_{q}^{1-1/q}(\Gamma_{j})$$

when  $q \neq 2$ , and onto

$$\tilde{H}^{3/2}(\Gamma_i) \times \tilde{H}^{1/2}(\Gamma_i)$$
.

This result, together with inequality (1,5,3,4), shows that

$$\{\varphi,\psi\}\mapsto \int_{\Gamma_i} \gamma_j \frac{\partial u}{\partial \nu_{A,j}} \varphi \, d\sigma - \int_{\Gamma_i} \gamma_j u \psi \, d\sigma$$

is a continuous bilinear form on

$$\mathring{W}_{q}^{2-1/q}(\Gamma_{j}) \times \mathring{W}_{q}^{1-1/q}(\Gamma_{j})$$

when  $q \neq 2$ , and on

$$\tilde{H}^{3/2}(\Gamma_i) \times \tilde{H}^{1/2}(\Gamma_i)$$

when q=2. This defines  $\gamma_j \partial u/\partial \nu_{A,i}$  as an element of  $W_p^{-1-1/p}(\Gamma_j)$  and  $\gamma_j u$  as an element of  $W_p^{-1/p}(\Gamma_i)$  when  $p \neq 2$ ; while this defines  $\gamma_i \partial u/\partial \nu_{A,j}$  as an element of the dual space of  $\tilde{H}^{3/2}(\Gamma_j)$  and  $\gamma_i u$  as an element of the dual space of  $\tilde{H}^{1/2}(\Gamma_j)$  when p=2. This proves Theorem 1.5.3.4.

Remark 1.5.3.5 Actually, since A is non characteristic on  $\Gamma$ ,  $\gamma_i \partial u/\partial \nu_i$  is also defined as an element of  $W_p^{-1-1/p}(\Gamma_i)$  (respectively the dual of  $\tilde{H}^{3/2}(\Gamma_i)$ ) when  $p \neq 2$  (respectively p = 2).

We shall also need a Green's formula, extending (1,5,3,3) to  $u \in D(A, L_p(\Omega))$ . When  $\Omega$  is a bounded open subset of  $\mathbb{R}^n$  with a  $C^{\infty}$  boundary  $\Gamma$ , it is shown that (1,5,3,2) has a natural extension. Indeed, Lions and Magenes (1960–63) prove that

$$\int_{\Omega} Au \, dx - \int_{\Omega} uA^*v \, dx = \left\langle \gamma \frac{\partial u}{\partial \nu_A}; \gamma v \right\rangle - \left\langle \gamma u; \gamma \left[ \frac{\partial v}{\partial \nu_{A^*}} - \left( \sum_{i=1}^{n} \nu_i a_i \right) \gamma v \right] \right\rangle$$
(1,5,3,5)

for all  $u \in D(A; L_p(\Omega))$  and  $v \in W_q^2(\Omega)$ . Here the brackets denote the duality pairing between  $W_p^{-1-1/p}(\Gamma)$  and  $W_q^{1+1/p}(\Gamma)$  for the first and between  $W_p^{-1/p}(\Gamma)$  and  $W_q^{1/p}(\Gamma)$  for the second. The same result holds with the same proof, if we only assume that  $\Omega$  has a  $C^{1,1}$  boundary.

Unfortunately, the analogue of (1,5,3,5) no longer holds, if we consider a bounded plane open set  $\Omega$  whose boundary  $\Gamma$  is a curvilinear polygon which actually has corners. The reason is that, in general, for  $u \in D(A, L_p(\Omega))$  and  $v \in W_q^2(\Omega)$ , the traces  $\gamma_i \frac{\partial u}{\partial \nu_{A,j}}$  and  $\gamma_i v$  are in the spaces  $W_p^{-1-1/p}(\Gamma_i)$  and  $W_q^{1+1/p}(\Gamma_i)$  respectively and these spaces are not in duality. (This is for  $p \neq 2$ ; the situation is even worse for p = 2.) Consequently, we shall prove only the following statement.

**Theorem 1.5.3.6** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$  whose boundary is a curvilinear polygon of class  $C^{1,1}$ . Then we have

$$\int_{\Omega} Auv \, dx - \int_{\Omega} uA^*v \, dx$$

$$= \sum_{i=1}^{N} \left\{ \left\langle \gamma_{i} \frac{\partial u}{\partial \nu_{A,i}}; \gamma_{i}v \right\rangle - \left\langle \gamma_{i}u; \gamma_{i} \left[ \frac{\partial v}{\partial \nu_{A^*,i}} - \nu_{i} \cdot \mathbf{a}v \right] \right\rangle \right\}$$
(1,5,3,6)

for  $u \in D(A, L_p(\Omega))$  and  $v \in W_q^2(\Omega)$ , 1/p + 1/q = 1, such that

- (a)  $v(S_i) = 0, j = 1, 2, ..., N \text{ when } p > 2$
- (b)  $v(S_i) = 0$ , and  $\nabla v(S_i) = 0$ , j = 1, 2, ..., N when p < 2
- (c) v = 0 in a neighbourhood of  $S_i$ , j = 1, 2, ..., N when p = 2.

**Proof** We already know from Lemma 1.5.3.2 that (1,5,3,6) holds for  $u \in W_p^2(\Omega)$  and  $v \in W_q^2(\Omega)$ . We also know that  $W_p^2(\Omega)$  is dense in  $D(A; L_p(\Omega))$ . So we just have to prove that the right-hand side of (1,5,3,6) is continuous in u for the norm of  $D(A; L_p(\Omega))$  for those particular v specified in the statement of Theorem 1.5.3.6.

Now, because of Theorem 1.5.3.4, we just have to check that

$$\gamma_i v \in \mathring{W}_q^{1+1/p}(\Gamma_i), \qquad \gamma_i \frac{\partial v}{\partial \nu_{A^*i}} \in \mathring{W}_q^{1/p}(\Gamma_i),$$

at least when  $p \neq 2$ . It follows from Theorem 1.5.2.1 that

$$\gamma_j v \in W_q^{1+1/p}(\Gamma_j)$$
 and  $\gamma_j \frac{\partial v}{\partial \nu_{A^*,j}} \in W_q^{1/p}(\Gamma_j)$ .

Then from the extra hypotheses (a) and (b), we have

$$\gamma_i v(S_i) = v(S_i) = 0, \qquad \gamma_i v(S_{i-1}) = v(S_{i-1}) = 0$$

for all p and

$$\begin{cases} \gamma_{i} \frac{\partial v}{\partial \nu_{A^{*},i}} (S_{i}) = \frac{\partial v}{\partial \nu_{A^{*},i}} (S_{i}) = 0 \\ \gamma_{i} \frac{\partial v}{\partial \nu_{A^{*},i}} (S_{i-1}) = \frac{\partial v}{\partial \nu_{A^{*},i}} (S_{i-1}) = 0 \end{cases}$$

for p < 2. By Corollary 1.5.1.6 we therefore know that

$$\gamma_j v \in \mathring{W}_q^{1+1/p}(\Gamma_j)$$
 and  $\gamma_j \frac{\partial v}{\partial \nu_{A^*,j}} \in \mathring{W}_q^{1/p}(\Gamma_j),$ 

and this is enough to prove our Theorem for  $p \neq 2$ .

In the particular case when p = 2,  $\gamma_i v$  and  $\gamma_i \frac{\partial v}{\partial \nu_{A^*,i}}$  have closed supports inside  $\Gamma_i$ . Consequently, it follows from Corollary 1.4.4.10 that

$$\gamma_i v \in \tilde{H}^{3/2}(\Gamma_i)$$
 and  $\gamma_i \frac{\partial v}{\partial \nu_{\mathbf{A}^*,i}} \in \tilde{H}^{1/2}(\Gamma_i)$ .

This shows that the right-hand side terms in (1,5,3,6) depend continuously on  $u \in D(A, L_2(\Omega))$  (in view of the first remark, just after the statement of Theorem 1.5.3.4).

In dealing with variational solutions of some boundary value problems, we shall often need similar results concerning a 'half' Green formula. Indeed, the following is an easy consequence of Theorem 1.5.3.1. (We restrict ourselves to the Laplace operator for simplicity, since we shall only need this result in the coming sections.)

**Lemma 1.5.3.7** let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary  $\Gamma$ . Then for every  $u \in H^2(\Omega)$  and  $v \in H^1(\Omega)$ , we have

$$\int_{\Omega} (\Delta u)v \, dx = -\int_{\Omega} \nabla u \cdot \nabla v \, dx + \int_{\Gamma} \gamma \frac{\partial u}{\partial \nu} \gamma v \, d\sigma. \tag{1.5.3.7}$$

The corresponding statement on polygons is (according to the notation introduced previously in this subsection) the following:

**Lemma 1.5.3.8** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$  whose boundary is a curvilinear polygon of class  $C^{1,1}$ . Then for every  $u \in H^2(\Omega)$  and  $v \in H^1(\Omega)$ , we have

$$\int_{\Omega} (\Delta u)v \, dx = -\int_{\Omega} \nabla u \cdot \nabla v \, dx + \sum_{j=1}^{N} \int_{\Gamma_{i}} \gamma_{i} \frac{\partial u}{\partial \nu_{j}} \gamma_{i} v \, d\sigma.$$
 (1,5,3,8)

Again this can be extended to more functions u. Let us set

$$E(\Delta; L_p(\Omega)) = \{ u \in H^1(\Omega); \Delta u \in L_p(\Omega) \}.$$

This is a Banach space for the obvious norm

$$u\mapsto \|u\|_{1,2,\Omega}+\|\Delta u\|_{0,p,\Omega}.$$

As before,  $\mathfrak{D}(\bar{\Omega})$  is dense in  $E(\Delta; L_p(\Omega))$  when  $\Omega$  has a Lipschitz boundary, but this now requires a proof.

**Lemma 1.5.3.9** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary; then  $\mathfrak{D}(\bar{\Omega})$  is dense in  $E(\Delta; L_p(\Omega))$ .

**Proof** Let P be any continuation operator defined on  $H^1(\Omega)$ . In other words, P is a continuous linear mapping from  $H^1(\Omega)$  to  $H^1(\mathbb{R}^n)$  such that

$$Pu\mid_{\Omega}=u,$$

for every  $u \in H^1(\Omega)$  (see Theorem 1.4.3.1). With the help of P we can view  $H^1(\Omega)$  as a closed subspace of  $H^1(\mathbb{R}^n)$ . Thus for every continuous linear form l on  $E(\Delta, L_p(\Omega))$  there exists  $f \in H^{-1}(\mathbb{R}^n)$  and  $g \in L_q(\Omega)$  such that

$$l(u) = \langle f; Pu \rangle + \int_{\Omega} g \, \Delta u \, dx$$

for all  $u \in E(\Delta, L_p(\Omega))$ . In addition, since l depends only on u and not on  $Pu|_{C\Omega}$ , the support of f is contained in  $\bar{\Omega}$ . (See also Theorem 2.3 in Magenes and Stampacchia (1958), Chapter 1.)

Now, in order to prove the claim of Lemma 1.5.3.9, we just need to show that any l which vanishes on  $\mathcal{D}(\bar{\Omega})$  is actually zero everywhere. Indeed for  $U \in \mathcal{D}(\mathbb{R}^n)$ , we have

$$\langle f; U \rangle + \langle \tilde{g}, \Delta U \rangle = 0,$$

since we have

60

$$\langle f; U \rangle = \langle f; Pu \rangle$$

where  $u = U|_{\Omega}$ , due to the properties of the support of f. It follows that

$$\Delta \tilde{g} = -f$$

in the sense of distributions.

The ellipticity of  $\Delta$  implies that  $\tilde{g} \in H^1(\mathbb{R}^n)$  and consequently that  $g \in \mathring{H}^1(\Omega)$ . Let us now consider a sequence  $g_m$ , m = 1, 2, ... of functions belonging to  $\mathfrak{D}(\Omega)$  and such that

$$g_m \to g, \qquad m \to +\infty$$

in  $\mathring{H}^1(\Omega)$ . For every  $u \in E(\Delta, L_p(\Omega))$ , we have

$$l(u) = \lim_{m \to \infty} \left\{ -\langle \Delta \tilde{g}_m, Pu \rangle + \int_{\Omega} g_m \Delta u \, dx \right\}$$
$$= \lim_{m \to \infty} \left\{ -\int_{\Omega} \Delta g_m u \, dx + \int_{\Omega} g_m \Delta u \, dx \right\}$$
$$= 0.$$

Thus l is identically zero.

The inclusion

$$E(\Delta; L_p(\Omega)) \subseteq D(\Delta; L_p(\Omega))$$

shows that  $\gamma_i \frac{\partial u}{\partial \nu_i}$  is well defined and

$$\gamma_i \frac{\partial u}{\partial \nu_i} \in W_p^{-1-1/p}(\Gamma_i)$$

when  $p \neq 2$  and

$$\gamma_i \frac{\partial u}{\partial \nu_i} \in \tilde{H}^{3/2}(\Gamma_i)^*$$

when p = 2. However, this result can be improved.

**Theorem 1.5.3.10** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$ , whose boundary is a curvilinear polygon of class  $C^{1,1}$ . Then the mapping

$$u \mapsto \gamma_i \frac{\partial u}{\partial \nu_i}$$

which is defined on  $\mathfrak{D}(\bar{\Omega})$ , has a unique continuous extension as an operator from  $E(\Delta; L_p(\Omega))$  into

$$\tilde{H}^{1/2}(\Gamma_i)^*$$
.

**Proof** Consider  $v \in V$ , where

$$V = \{v \in H^1(\Omega) \mid \gamma_k v = 0, \ k \neq j\}.$$

Then  $\gamma_i v \in \tilde{H}^{1/2}(\Gamma_i)$  (see Subsection 1.5.2). Furthermore, for  $u \in \mathcal{D}(\bar{\Omega})$ , we have by Lemma 1.5.3.8

$$\int_{\Gamma_i} \gamma_i \frac{\partial u}{\partial \nu_i} \gamma_i v \, d\sigma = \int_{\Omega} (\Delta u) v \, dx + \int_{\Omega} \nabla u \cdot \nabla v \, dx.$$

It follows that

$$\left| \int_{\Gamma_{i}} \gamma_{i} \frac{\partial u}{\partial \nu_{i}} \gamma_{i} v \, d\sigma \right| \leq \| u \|_{E(\Delta; L_{\eta}(\Omega))} \| v \|_{1, 2, \Omega}$$

and consequently there exists a constant C such that

$$\left\|\gamma_{j}\frac{\partial u}{\partial \nu_{j}}\right\|_{\dot{H}^{1/2}(\Gamma_{j})^{*}} \leq K \left\|u\right\|_{E(\Delta;L_{p}(\Omega))}.$$

The result follows by density.

We can now extend the Green formula (1,5,3,7) to  $u \in E(\Delta; L_p(\Omega))$ .

**Theorem 1.5.3.11** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$ , whose boundary is a curvilinear polygon of class  $C^{1,1}$ . Then we have

$$\int_{\Omega} \Delta u v \, dx = -\int_{\Omega} \nabla u \cdot \nabla v \, dx + \sum_{i=1}^{N} \left\langle \gamma_{i} \frac{\partial u}{\partial \nu_{i}}; \gamma_{i} v \right\rangle$$
 (1,5,3,9)

for  $u \in E(\Delta; L_v(\Omega))$  and  $v \in W_r^1(\Omega)$ , r > 2 such that

$$v(S_i) = 0, \quad 1 \leq j \leq N.$$

**Proof** The identity (1,5,3,9) holds by Lemma 1.5.3.8 for every  $u \in \mathcal{D}(\bar{\Omega})$  and  $v \in W_r^1(\Omega)$ , r > 2 (since this last space is included in  $H^1(\Omega)$ ). Then assuming that v is zero at the corners, implies that

$$\gamma_i v \in \mathring{W}_r^{1-1/r}(\Gamma_i) \subseteq \tilde{H}^{1/2}(\Gamma_i).$$

SOBOLEV SPACES

Consequently, all the terms involved in identity (1,5,3,9) are continuous in u for the norm of  $E(\Delta; L_p(\Omega))$ . Again, the result follows for density.

Finally, let us recall for later reference, the corresponding result on domains with smooth boundary, due to Lions and Magenes (1960-63). Here  $\Omega$  is a bounded open subset of  $\mathbb{R}^n$  with a  $C^{1,1}$  boundary. Then  $\mathfrak{D}(\bar{\Omega})$  is dense in  $E(\Delta; L_p(\Omega))$ , the trace operator

$$u \mapsto \gamma \frac{\partial u}{\partial \nu}$$

62

is linear continuous from  $E(\Omega; L_p(\Omega))$  to  $H^{-1/2}(\Gamma)$  and the Green formula

$$\int_{\Omega} \Delta u v \, dx = -\int_{\Omega} \nabla u \cdot \nabla v \, dx + \left\langle \gamma \frac{\partial u}{\partial \nu}; \gamma v \right\rangle \tag{1.5,3,10}$$

holds for every  $u \in E(\Omega; L_n(\Omega))$  and  $v \in H^1(\Omega)$ .

#### 1.6 Boundary conditions

So far, we have studied the traces on the boundary of a function u, together with its derivatives in the direction of  $\nu$  up to a certain order. For the purpose of studying boundary value problems, it is convenient to replace the powers of  $\partial/\partial\nu$  by a more general set of differential operators. This is the main goal of this section.

#### 1.6.1 Normal systems

From now on, we consider a set of given differential operators

$$B_k(x, D_x) = \sum_{|\alpha| \leq d_k} a_{\alpha}(x) D_x^{\alpha}, \qquad k = 1, \dots, K$$

with  $C^{\infty}$  coefficients defined in  $\Omega$ . For convenience, we assume that these operators are numbered according to the increasing orders of their degrees; in other words, we assume that  $k \to d_k$  is a nondecreasing function of k.

Furthermore, we make the very restrictive assumption that the system  $\{B_k\}_{k=1}^K$  is 'normal'. This means the following

**Definition 1.6.1.1** Let  $\Omega$  be an open subset of  $\mathbb{R}^n$  with a Lipschitz boundary  $\Gamma$ . The system  $\{B_k\}_{k=1}^K$  is said to be normal on a subset  $\Gamma'$  of  $\Gamma$  if

(a) the degrees  $d_k$  are all different

(b) the  $B_k$  are all uniformly noncharacteristic on  $\Gamma$ : i.e. there exists m and M such that  $0 < m \le M$  and

$$m \leq \left| \sum_{|\alpha| = d_k} a_{\alpha}(x) \mathbf{v}^{\alpha} \right| \leq M$$

a.e. on  $\Gamma'$ . (As usual  $\mathbf{v}^{\alpha}$  means  $(\mathbf{v}^1)^{\alpha_1} \cdots (\mathbf{v}^n)^{\alpha_n}$ .)

This definition agrees with the usual one given for a bounded  $\Omega$  with  $C^*$  boundary. We observe that  $k \to d_k$  is now a strictly increasing function.

We shall now investigate the mapping

$$u \mapsto \{\gamma B_k u\}_{k=1}^K$$

when u varies in some Sobolev space. We first quote the classical results of Lions and Magenes (1960–63).

**Theorem 1.6.1.2** Let  $\{B_k\}_{k=1}^K$  be a system of homogeneous differential operators with constant coefficients in  $\mathbb{R}^n$ , which is normal on the hyperplane  $x_n = 0$ . Then for s - 1/p non-integer and  $>d_K$ , the mapping

$$u \mapsto \{\gamma_n B_k u\}_{k=1}^K$$

from  $W_p^s(\mathbb{R}^n)$  into  $\prod_{k=1}^K W_p^{s-d_k-1/p}(\mathbb{R}^{n-1})$  is onto.

This is a consequence of Theorem 1.5.1.1. The following is a consequence of Theorem 1.5.1.2.

**Theorem 1.6.1.3** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a boundary of class  $C^{l,1}$ . Let also  $\{B_k\}_{k=1}^K$  be a system of differential operators in  $\Omega$  with coefficients belonging to  $C^{\infty}(\overline{\Omega})$ , which is normal on the boundary  $\Gamma$  of  $\Omega$ . Then for s-1/p non-integer,  $s-1/p>d_K$  and  $s \leq l+1$ , the mapping

$$u \mapsto \{\gamma B_k u\}_{k=1}^K$$

from  $W_p^s(\Omega)$  into  $\prod_{k=1}^K W_p^{s-d_k-1/p}(\Gamma)$  is onto.

We now restrict our purpose to plane domains whose boundaries are curvilinear polygons of class  $C^{\infty}$ , for simplicity. We also assume that s = m is an integer. We use the same notation as in Section 1.5.2. With each of the curves  $\Gamma_i$  we consider a set of differential operators

$$B_{j,k}(x, D_x) = \sum_{|\alpha| \leq d_{j,k}} a_{j,\alpha}(x) D_x^{\alpha}, \qquad k = 1, 2, \dots, K_j.$$

We assume that the coefficients  $a_{j,\alpha}$  belong to  $C^{\infty}(\bar{\Omega})$  and that the set  $\{B_{j,k}\}_{k=1}^{K}$  is normal on  $\Gamma_{j}$  for each  $j=1,2,\ldots,N$ . It follows from

Theorem 1.5.2.1 that for  $u \in W_{\nu}^{m}(\Omega)$  we have

$$f_{j,k} = \gamma_j B_{j,k} u \in W_p^{m-d_{j,k}-1/p}(\Gamma_j).$$

Then, let us consider for each j, all the possible sets of differential operators  $P_{j,k}(x, D_x)$ ,  $k = 1, 2, ..., K_j$  and  $Q_{j+1,k}(x, D_x)$ ,  $k = 1, 2, ..., K_{j+1}$  such that  $P_{j,k}$  is tangential to  $\Gamma_i$  for all k and  $Q_{j+1,k}$  is tangential to  $\Gamma_{i+1}$  for all k. In addition, we assume that

$$\sum_{k=1}^{K_i} P_{j,k} B_{j,k} = \sum_{k=1}^{K_{j-1}} Q_{j+1,k} B_{j+1,k}$$
 (1,6,1,1)

at  $S_j$  and that the degree of  $P_{j,k}$  is  $\leq d - d_{j,k}$  and the degree of  $Q_{j+1,k}$  is  $\leq d - d_{j+1,k}$ . Consequently, the degree of the operator L in (1,6,1,1) is  $\leq d$  and for  $u \in W_p^m(\Omega)$  we have

$$Lu \in W_p^{m-d}(\Omega)$$
.

Then, Theorem 1.5.2.8 shows that

$$\sum_{k=1}^{K_i} (P_{j,k} f_{j,k})(S_j) = \sum_{k=1}^{K_{i+1}} (Q_{j+1,k} f_{j+1,k})(S_j)$$
 (1,6,1,2)

when d < m - 2/p, while

$$\int_{0}^{\delta_{i}} \left| \sum_{k=1}^{K_{i}} (P_{i,k} f_{j,k})(x_{j}(-\sigma)) - \sum_{k=1}^{K_{i-1}} (Q_{j+1,k} f_{j+1,k})(x_{j}(\sigma)) \right|^{2} \frac{d\sigma}{\sigma} < +\infty \quad (1,6,1,3)$$

when d = m - 1 and p = 2.

Conditions (1,6,1,2) are obviously necessary conditions on the traces  $f_{j,k}$ . It turns out that they are also sufficient conditions.

**Theorem 1.6.1.4** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$ , whose boundary is a curvilinear polygon of class  $C^{\infty}$ . Let also  $\{B_{j,k}\}_{k=1}^K$  be, for each j, a system of differential operators in  $\Omega$ , with coefficients belonging to  $C^{\infty}(\bar{\Omega})$ , which is normal on  $\Gamma_j$ . Then for  $p \neq 2$ , the mapping

$$u \mapsto \{f_{j,k} = \gamma_j B_{j,k} u\}, \quad j = 1, \ldots, N, \quad k = 1, \ldots, K_j,$$

maps  $W_p^m(\Omega)$  onto the subspace of

$$T = \prod_{j=1}^{N} \prod_{k=1}^{K_{i}} W_{p}^{m-d_{i,k}-1/p}(\Gamma_{j})$$

defined by the conditions (1,6,1,2) for all possible systems of differential operators  $\{P_{j,k}\}_{k=1}^{K_{i+1}}$  tangential to  $\Gamma_j$  and  $\{Q_{j+1,k}\}_{k=1}^{K_{i+1}}$  tangential to  $\Gamma_{j+1}$ , such that identity (1,6,1,1) holds.

Proof The conditions (1,6,1,2) have a local character. This allows one,

through partition of the unity and changes of variables, to reduce the proof of the sufficiency of (1,6,1,2) to the case when  $\Omega$  is replaced by  $\mathbb{R}_+ \times \mathbb{R}_+$  and the functions  $f_{i,k}$  have bounded supports. (Indeed, when the angle at  $S_i$  is less than  $\pi$  the problem is thus reduced to the case when  $\Omega$  is replaced by  $\mathbb{R}_+ \times \mathbb{R}_+$ . On the other hand, when the angle at  $S_i$  is more than  $\pi$ ,  $\Omega$  is replaced by the complement of  $\mathbb{R}_+ \times \mathbb{R}_+$ . However, owing to the continuation theorem, it is equivalent to prove sufficiency in  $\mathbb{R}_+ \times \mathbb{R}_+$ .)

Since we consider a domain with only one corner, it will be convenient, throughout the proof, to adopt some slightly different notation. We replace  $P_{j,k}$  by  $P_k$  (setting  $K_j = K'$ ),  $Q_{j+1,k}$  by  $Q_k$  (setting  $K_{j+1} = K''$ ),  $B_{j,k}$  by  $B_k$  (setting  $d_{j,k} = m'_k$ ) and finally  $B_{j+1,k}$  by  $C_k$  (setting  $d_{j+1,k} = m''_k$ ). Thus, we start from

$$\varphi_k \in W_p^{m-m_k'-1/p}(\mathbb{R}_+), \qquad \psi_l \in W_p^{m-m_l''-1/p}(\mathbb{R}_+)$$

 $1 \le k \le K'$  and  $1 \le l \le K''$ , such that

$$\sum_{k=1}^{K'} (P_k(D_y)\varphi_k)(0) = \sum_{l=1}^{K''} (Q_l(D_x)\psi_l)(0)$$
 (1,6,1,4)

for all possible systems of operators  $P_k$  and  $Q_l$  such that

$$\sum_{k=1}^{K'} P_k(D_y) B_k(D_x, D_y) = \sum_{l=1}^{K''} Q_l(D_x) C_l(D_x, D_y)$$
 (1,6,1,5)

and this sum is an operator of degree d < m - 2/p. With this data, we look for a function  $u \in W_p^m(\mathbb{R}_+ \times \mathbb{R}_+)$  such that

$$\gamma_1 B_k u = \varphi_k$$
 and  $\gamma_2 C_l u = \psi_l$ . (1,6,1,6)

Instead of building directly a function u, we shall only look for those functions  $f_k$  and  $g_l$  which, through the application of Theorem 1.5.2.4, allow us to find a function  $u \in W_p^m(\mathbb{R}_+ \times \mathbb{R}_+)$ , such that

$$\gamma_1 D_x^l u = g_l$$
 and  $\gamma_2 D_y^k u = f_k$ 

for k, l = 1, 2, ..., m - 1. In other words, we have to solve the following problem: Find

$$f_k \in W_p^{m-k-1/p}(\mathbb{R}_+), \quad g_l \in W_p^{m-l-1/p}(\mathbb{R}_+), \qquad k, l = 0, \dots, m-1$$

such that  $D_x^l f_k(0) = D_y^k g_l(0)$ , l + k < m - 2/p and that

$$\sum_{l=0}^{m'_k} B_{k,l}(D_y) g_l = \varphi_{k'} \qquad 1 \le k \le K'$$

$$\sum_{k=0}^{m''} C_{l,k}(D_x) f_k = \psi_l, \qquad 1 \le l \le K''$$
(1,6,1,7)

where the operators  $B_{k,l}$  and  $C_{l,k}$  are defined by

$$B_{k}(D_{x}, D_{y}) = \sum_{l=0}^{m'_{k}} B_{k,l}(D_{y})D_{x}^{l}$$

$$C_{l}(D_{x}, D_{y}) = \sum_{k=0}^{m''_{l}} C_{l,k}(D_{x})D_{y}^{k}.$$

Since we have assumed that the systems of operators  $\{B_k\}_{k=1}^{K'}$  and  $\{C_l\}_{l=1}^{K''}$  are normal on x=0 and y=0 respectively,  $B_{k,m'_k}$  and  $C_{l,m''_l}$  are just nonvanishing functions. Consequently (1,6,1,7) may be rewritten as

$$\begin{cases}
g_{m'_{k}} = \frac{1}{B_{k,m'_{k}}} \left\{ \varphi_{k} - \sum_{l=0}^{m'_{k}-1} B_{k,l}(D_{y}) g_{l} \right\} \\
f_{m''_{l}} = \frac{1}{C_{l,m''_{l}}} \left\{ \psi_{l} - \sum_{k=0}^{m''_{l}-1} C_{l,k}(D_{x}) f_{k} \right\}.
\end{cases} (1,6,1,8)$$

In other words, we know  $g_{m'_k}$  and  $f_{m''_l}$  as soon as we know  $g_l$  for  $l \le m'_k - 1$  and  $f_k$  for  $k \le m''_l - 1$ . However, these identities do not define all the  $g_l$  and the  $f_k$  since we never assumed that  $m'_k = k - 1$  and that  $m''_l = l - 1$ .

As a first step in the construction of the missing  $g_l$  and  $f_k$ , we first look for the numbers

$$a_{k,l} = D_x^l f_k(0) = D_y^k g_l(0), \qquad k+l < m-\frac{2}{p}.$$

These numbers are solution of the linear system of equations which we obtain by differentiating the first equation in (1,6,1,7) with respect to y and the second with respect to x and then writing the corresponding equations at 0 when this makes sense. Namely, we have

$$\sum_{l=0}^{m'_{k}} D_{y}^{\lambda} B_{k,l}(D_{y}) g_{l} = \varphi_{k}^{(\lambda)}, \qquad 1 \leq k \leq K', \quad \lambda \geq 0$$

$$\sum_{k=0}^{m''_{l}} D_{x}^{\mu} C_{l,k}(D_{x}) f_{k} = \psi_{l}^{(\mu)}, \qquad 1 \leq l \leq K'', \quad \mu \geq 0.$$
(1,6,1,9)

We now adopt the following notation:

$$\begin{cases} D_{y}^{\lambda}B_{k,l}(D_{y}) = \sum_{\alpha=0}^{m_{k}'+\lambda-l} b_{k,l}^{\lambda,\alpha}D_{y}^{\alpha} \\ D_{x}^{\mu}C_{l,k}(D_{x}) = \sum_{\beta=0}^{m_{l}'+\mu-k} c_{l,k}^{\mu,\beta}D_{x}^{\beta}, \end{cases}$$

where  $b_{k,l}^{\lambda,\alpha}$  and  $c_{l,k}^{\lambda,\beta}$  are functions. Then at (), (1,6,1,9) implies

$$\begin{cases} \sum_{l=0}^{m'_k} \sum_{\alpha=0}^{m'_k+\lambda-l} b_{k,l}^{\lambda,\alpha}(0) a_{\alpha,l} = \varphi_k^{(\lambda)}(0), & m'_k+\lambda < m - \frac{2}{p} \\ \sum_{k=0}^{m''_l} \sum_{\beta=0}^{m''_l+\mu-k} c_{l,k}^{\mu,\beta}(0) a_{k,\beta} = \psi_l^{(\mu)}(0), & m''_l+\mu < m - \frac{2}{p}. \end{cases}$$
(1,6,1,10)

This is the system of linear equations in  $a_{k,l}$ . This system is possibly overdetermined. We must therefore check that it has a solution.

The simplest way to prove that (1,6,1,10) has actually a solution is to prove that the data are in the kernel of the transposed matrix. In other words, the data have to annihilate all the linear forms which are zero after composition with the matrix of the system. We must therefore check that

$$\sum_{k,\lambda} p_{k,\lambda} \varphi_k^{(\lambda)}(0) = \sum_{l,\mu} q_{l,\mu} \psi_l^{(\mu)}(0)$$
 (1,6,1,11)

for all possible numbers  $p_{k,\lambda}$ ,  $1 \le k \le K'$ ,  $\lambda = 0, 1, \ldots, r - m'_k$  and  $q_{l,\mu}$ ,  $1 \le l \le K''$ ,  $\mu = 0, 1, \ldots, r - m''_l$  (r is the integral part of m - 2/p), such that

$$\sum_{k,\lambda} p_{k,\lambda} b_{k,\hat{i}}^{\lambda,\hat{\alpha}}(0) = \sum_{l,\mu} q_{l,\mu} c_{l,\hat{k}}^{\mu,\hat{\beta}}(0)$$
 (1,6,1,12)

for all possible values of  $\hat{\alpha} = \hat{k}$  and  $\hat{\beta} = \hat{l}$ . For that purpose, let us consider the operators

$$P_{k}(D_{y}) = \sum_{\lambda=0}^{r-m'_{k}} p_{k,\lambda}(x, y) D_{y}^{\lambda}, \qquad Q_{l}(D_{x}) = \sum_{\mu=0}^{r-m'_{l}} q_{l,\mu}(x, y) D_{x}^{\mu},$$

where the numbers  $p_{k,\lambda} = p_{k,\lambda}(0,0)$  and  $q_{l,\mu} = q_{l,\mu}(0,0)$  fulfil (1,6,1,12). We then have

$$\sum_{k=1}^{K'} P_k(D_y) B_k(D_x, D_y) = \sum_{k=1}^{K'} \sum_{\lambda=0}^{r-m_k'} p_{k,\lambda} D_y^{\lambda} \sum_{l=0}^{m_k'} B_{k,l}(D_y) D_x^l$$

$$= \sum_{k=1}^{K'} \sum_{\lambda=0}^{r-m_k'} \sum_{l=0}^{m_k'} \sum_{\alpha=0}^{m_k'+\lambda-l} p_{k,\lambda} b_{k,l}^{\lambda,\alpha} D_x^l D_y^{\alpha}.$$

As a consequence of (1,6,1,12), this operator is also

$$\begin{split} \sum_{l=1}^{K''} \sum_{\mu=0}^{r-m_l''} \sum_{k=0}^{m_l''} \sum_{\beta=0}^{m_l''+\mu-k} q_{l,\mu} C_{l,k}^{\mu,\beta} D_x^{\beta} D_y^k &= \sum_{l=1}^{K''} \sum_{\mu=0}^{r-m_l''} q_{l,\mu} D_x^{\mu} \sum_{k=0}^{m_l''} C_{l,k}(D_x) D_y^k \\ &= \sum_{l=1}^{K''} Q_l(D_x) C_l(D_x, D_y). \end{split}$$

SOBOLEV SPACES

This is exactly identity (1,6,1,5). It follows that (1,6,1,4) holds and this can be rewritten as

$$\sum_{k,\mu} p_{k,\lambda} \varphi_k^{(\lambda)}(0) = \sum_{l,\mu} q_{l,\mu} \psi_l^{(\mu)}(0).$$

This proves identity (1,6,1,11). Summing up, we have shown that the linear system (1,6,1,10) has a solution.

From now on, let us consider any solution of (1,6,1,10). We must find

$$f_k \in W_p^{m-k-1/p}(\mathbb{R}_+), \qquad g_l \in W_p^{m-l-1/p}(\mathbb{R}_+)$$
 (1,6,1,13)

such that

$$f_k^{(l)}(0) = a_{k,l}, \qquad 0 \le l < m - k - \frac{2}{p}$$
 (1,6,1,14)

$$f_k^{(l)}(0) = a_{k,l}, \qquad 0 \le l < m - k - \frac{2}{p}$$

$$g_l^{(k)}(0) = a_{k,l}, \qquad 0 \le k < m - l - \frac{2}{p}$$

$$(1,6,1,14)$$

and that (1,6,1,8) holds. We obtain the functions  $f_k$  such that  $k \neq m_l^m$  $(l=1,2,\ldots,K'')$  and the functions  $g_l$  such that  $l\neq m'_k$   $(k=1,2,\ldots,K')$ from the one-dimensional version of Theorem 1.5.1.1. Indeed this theorem implies that the mapping

$$h \mapsto \{h(0), \ldots, h^{(k)}(0)\}$$

from  $W_p^s(\mathbb{R})$  into  $\mathbb{R}^{k+1}$ , is onto, when k < s-1/p. We then obtain the functions  $f_{m''_l}$  (l = 1, 2, ..., K'') and  $g_{m'_k}$  (k = 1, 2, ..., K') from (1, 6, 1, 8).

The functions which have been thus constructed satisfy (1,6,1,13) and (1,6,1,8). They also satisfy (1.6.1.14) for  $k \neq m''_l$  (l = 1, 2, ..., K'') and (1,6,1,15) for  $l \neq m'_k$  (k = 1, 2, ..., K'). The last step of the proof consists in checking (1,6,1,14) and (1,6,1,15) for the remaining k and l. We do this by induction on  $m''_1$  and  $m'_k$  separately.

Let us assume that we already know that

$$f_k^{(\mu)}(0) = a_{k,\mu}$$

for  $k \le m_1'' - 1$   $(0 \le \mu < m - k - 2/p)$  and for  $k = m_1''$  but only for  $0 \le \mu \le m$  $\hat{\mu} - 1$  (possibly with  $\hat{\mu} = 0$ ; this means no information about  $f_{m''}$ ). We shall then show that

$$f_{m_i''}^{(\hat{\mu})}(0) = a_{m_i'',\hat{\mu}}.$$

Indeed we have (1,6,1,8) which is equivalent to (1,6,1,7). Thus

$$\begin{split} \psi_{l}^{(\hat{\mu})} &= D_{x}^{\hat{\mu}} \sum_{k=0}^{m_{l}''} C_{l,k}(D_{x}) f_{k} = \sum_{k=0}^{m_{l}''} \sum_{\beta=0}^{m_{l}''+\hat{\mu}-k} c_{l,k}^{\hat{\mu},\beta} f_{k}^{(\beta)} \\ &= c_{l,m_{l}'}^{\hat{\mu},\hat{\mu}} f_{m_{l}''}^{(\hat{\mu})} + \sum_{\beta=0}^{\hat{\mu}-1} c_{l,m_{l}''}^{\hat{\mu},\beta} f_{m_{l}''}^{(\beta)} + \sum_{k=0}^{m_{l}''-1} \sum_{\beta=0}^{m_{l}''+\hat{\mu}-k} c_{l,k}^{\hat{\mu},\beta} f_{k}^{(\beta)}. \end{split}$$

At zero this implies

$$c_{l,m_{l'}''(0)}^{\hat{\mu},\hat{\mu}''(0)}f_{m_{l'}''(0)}^{(\hat{\mu},)}(0) + \sum_{\beta=0}^{\hat{\mu},-1} c_{l,m_{l'}''(0)}^{\hat{\mu},\beta}a_{m_{l'}',\beta} + \sum_{k=0}^{m_{l'}'-1} \sum_{\beta=0}^{m_{l'}'+1} c_{l,k}^{\hat{\mu},\beta}(0)a_{k,\beta} = \psi_{l}^{(\hat{\mu})}(0).$$

This is one of the equations of the system (1,6,1,10) with  $a_{m_l^{\mu},\hat{\mu}}$  replaced by  $f_{m_l^{\mu}}^{(\hat{\mu})}$ . Fortunately  $c_{l,m_l^{\mu}}^{\hat{\mu},\hat{\mu}}(0)$  is not zero because  $c_{l,m_l^{\mu}}^{\hat{\mu},\hat{\mu}}$  is just the coefficient of  $D_y^{m_l^{\mu}}$  in  $C_l(D_x,D_y)$  and the axis  $\{y=0\}$  is not characteristic for this operator, by assumption. This shows that

$$f_{m_i''}^{(\hat{\mu})}(0) = a_{m_i'',\hat{\mu}}.$$

Consequently we check (1,6,1,14) by induction. We do the same for (1,6,1,15). The proof of Theorem 1.6.1.4 is now complete.

In the case when p = 2, which we have excluded so far, conditions (1,6,1,2) and (1,6,1,3) turn out to be also sufficient conditions on the traces  $f_{i,k}$ . However, this is really a result which is more easily proved by using interpolation methods. For this reason we shall only prove the sufficiency of (1,6,1,2) and (1,6,1,3) in some particular cases that we need in the forthcoming chapters.

**Theorem 1.6.1.5** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$ , whose boundary is a polygon. Let also  $\{B_{j,k}\}_{k=1}^{K_{i-1}}$  be for each j, a system of homogeneous linear differential operators, with constant coefficients, which is normal on  $\Gamma_i$ . Then the mapping

$$u \mapsto \{f_{i,k} = \gamma_i B_{i,k} u\}, \quad j = 1, \dots, N, \quad k = 1, 2, \dots, K_i$$

maps  $H^m(\Omega)$  onto the subspace of

$$T = \prod_{i=1}^{N} \prod_{k=1}^{K_i} H^{m-d_{i,k}-1/2}(\Gamma_i)$$

defined by the conditions (1,6,1,2) and (1,6,1,3) for all possible systems of homogeneous differential operators with constant coefficients  $\{P_{j,k}\}_{k=1}^{K_{i+1}}$  tangential to  $\Gamma_i$  and  $\{Q_{i+1,k}\}_{k=1}^{K_{i+1}}$  such that (1,6,1,1) holds.

**Proof** The beginning of the proof is quite similar to that of Theorem 1.6.1.4. Using a partition of unity and affine changes of coordinates, we reduce the proof to the case when  $\Omega$  is replaced by  $\mathbb{R}_+ \times \mathbb{R}_+$ . After this reduction, we still deal with homogeneous operators with constant coefficients.

Then we adopt the same simplified notation as in the previous proof. Thus we are given

$$\varphi_k \in H^{m-m_k'-1/2}(\mathbb{R}_+), \qquad \psi_l \in H^{m-m_l''-1/2}(\mathbb{R}_+)$$

 $1 \le k \le K'$ ,  $1 \le l \le K''$  such that

$$\sum_{k=1}^{K'} (P_k(D_y)\varphi_k)(0) = \sum_{l=1}^{K''} (Q_l(D_x)\psi_l)(0)$$
 (1,6,1,16)

when d < m - 1, while

$$\int_{0}^{1} \left| \sum_{k=1}^{K'} (P_{k}(D_{y})\varphi_{k})(t) - \sum_{l=1}^{K''} (Q_{l}(D_{x})\psi_{l})(t) \right|^{2} \frac{\mathrm{d}t}{t} < \infty$$
 (1,6,1,17)

when d = m - 1, for all possible systems of operators  $P_k$  and  $Q_l$  such that

$$\sum_{k=1}^{K'} P_k(D_y) B_k(D_x, D_y) = \sum_{l=1}^{K''} Q_l(D_x) C_l(D_x, D_y)$$
 (1,6,1,18)

and this sum is an operator of degree  $d \le m-1$ . We look for a function  $u \in H^m(\mathbb{R}_+ \times \mathbb{R}_+)$  such that

$$\gamma_1 B_k u = \varphi_k$$
 and  $\gamma_2 C_l u = \psi_l$ . (1,6,1,19)

Equivalently we look for functions  $f_k$  and  $g_l$  such that

$$f_k \in H^{m-k-1/2}(\mathbb{R}_+), \qquad g_l \in H^{m-l-1/2}(\mathbb{R}_+)$$

for k, l = 1, 2, ..., m - 1, with

$$D_{x}^{l}f_{k}(0) = D_{y}^{k}g_{l}(0), l+k < m-1$$

$$\int_{0}^{1} |D_{x}^{l}f_{k}(t) - D_{y}^{k}g_{l}(t)|^{2} \frac{dt}{t} < +\infty, l+k = m-1$$

and such that

$$\begin{cases} \sum_{l=0}^{m'_{k}} b_{k,l} D_{y}^{m'_{k}-l} g_{l} = \varphi_{k}, & 1 \leq k \leq K' \\ \sum_{m''_{l}} c_{l,k} D_{x}^{m''_{l}-k} f_{k} = \psi_{l}, & 1 \leq l \leq K'' \end{cases}$$

$$(1,6,1,20)$$

where the numbers  $b_{k,l}$  and  $c_{l,k}$  are defined by

$$B_{k}(D_{x}, D_{y}) = \sum_{l=0}^{m'_{k}} b_{k,l} D_{y}^{m'_{k}-l} D_{x}^{l}$$

$$C_{l}(D_{x}, D_{y}) = \sum_{k=0}^{m''_{k}} c_{l,k} D_{x}^{m''_{k}-k} D_{y}^{k}.$$

The first step will be to find the numbers

$$a_{k,l} = D_x^l f_k(0) = D_y^k g_l(0), \qquad k+l < m-1$$

together with those functions  $a_{k,l} \in H^{1/2}(\mathbb{R}_+)$  such that

$$\begin{cases} \int_{0}^{1} |D_{x}^{l} f_{k}(t) - a_{k,l}(t)|^{2} \frac{\mathrm{d}t}{t} < +\infty \\ \int_{0}^{1} |D_{y}^{k} g_{l}(t) - a_{k,l}(t)|^{2} \frac{\mathrm{d}t}{t} < +\infty \end{cases} k + l = m - 1.$$

The necessary conditions on the  $a_{k,l}$  are obtained by differentiating (1,6,1,20) and then considering the behaviour of  $\varphi_k^{(\lambda)}$  and  $\psi_l^{(\mu)}$  near zero. Namely, we have

$$\begin{cases} \sum_{l=0}^{m'_{k}} b_{k,l} a_{m'_{k}-l+\lambda,l} = \varphi_{k}^{(\lambda)}(0), & m'_{k}+\lambda < m-1 \\ \sum_{k=0}^{m''_{l}} c_{l,k} a_{k,m''_{l}-k+\mu} = \psi_{l}^{(\mu)}(0), & m''_{l}+\mu < m-1 \end{cases}$$

$$(1.6,1,21)$$

and in addition

$$\begin{cases} \int_{0}^{1} \left| \sum_{l=0}^{m'_{k}} b_{k,l} a_{m-l-1,l}(t) - \varphi_{k}^{(m-1-m'_{k})}(t) \right|^{2} \frac{dt}{t} < +\infty, & k = 1, \dots, K' \\ \int_{0}^{1} \left| \sum_{k=0}^{m''_{l}} c_{l,k} a_{k,m-k-1}(t) - \psi_{l}^{(m-1-m''_{l})}(t) \right|^{2} \frac{dt}{t} < +\infty, & l = 1, \dots, K''. \end{cases}$$

$$(1,6,1,22)$$

Now the interest of the assumption that all the involved operators are homogeneous is that the systems (1,6,1,21) and (1,6,1,22) are not coupled. In other words, the unknowns in (1,6,1,21) are only the  $a_{k,l}$  with k+l < m-1, while the unknowns in (1,6,1,22) are only the  $a_{k,l}$  with k+l=m-1. This allows one to solve the two systems separately. The system (1,6,1,21) is the same as (1,6,1,10) and it has a solution since we assumed (1,6,1,16) which is identical with (1,6,1,4).

We are left with the problem of solving (1,6,1,22). We can consider the set of functions  $\{a_{k,l}\}_{k+l=m-1}$  as a vector valued function **a** in  $\mathbb{R}^m$  and consequently (1,6,1,22) can be rewritten as

$$\int_{0}^{1} ||A\mathbf{a}(t) - \mathbf{b}(t)||^{2} \frac{\mathrm{d}t}{t} < +\infty$$
 (1,6,1,23)

where A is some matrix from  $\mathbb{R}^m$  into  $\mathbb{R}^N$  and **b** is some given function of class  $H^{1/2}(\mathbb{R}_+)$  with values in  $\mathbb{R}^N$ . Here N = K' + K'' and **b** is the function whose components are the corresponding  $\varphi_k^{(m-1-m'_k)}$  and  $\psi_l^{(m-1-m'_l)}$ . We shall use the following auxiliary result

**Lemma 1.6.1.6** Let  $\mathbf{b} \in H^{1/2}(\mathbb{R}_+; \mathbb{R}^N)$ ; then there exists  $\mathbf{a} \in H^{1/2}(\mathbb{R}_+; \mathbb{R}^m)$  which is a solution of (1,6,1,23) if and only if  $\int_0^1 |\varphi(\mathbf{b}(t))|^2 dt/t < +\infty$  for all linear forms  $\varphi$  on  $\mathbb{R}^N$  such that  $\varphi \circ A = 0$ .

Applying this to (1,6,1,22), we find a solution if and only if

$$\int_{0}^{1} \left| \sum_{k=1}^{K'} p_{k} \varphi_{k}^{(m-1-m'_{k})}(t) - \sum_{l=1}^{K''} q_{l} \psi_{l}^{(m-1-m'_{l})}(t) \right|^{2} \frac{\mathrm{d}t}{t} < +\infty$$
 (1,6,1,24)

for all numbers  $p_k$  and  $q_i$  such that

$$\sum_{k=1}^{K'} p_k b_{k,\hat{l}} = \sum_{l=1}^{K''} q_l c_{l,\hat{k}}$$
 (1,6,1,25)

for all  $\hat{k}$  and  $\hat{l}$  such that  $\hat{k} + \hat{l} = m - 1$ . Let us now introduce the operators

$$P_k(D_y) = p_k D_y^{m-1-m_k'}, \qquad Q_l(D_x) = q_l D_x^{m-1-m_l''};$$

then we have

$$\begin{split} \sum_{k=1}^{K'} P_k(D_y) B_k(D_x; D_y) &= \sum_{k=1}^{K'} p_k D_y^{m-1-m_k'} \sum_{l=0}^{m_k'} b_{k,l} D_y^{m_k'-l} D_x^l \\ &= \sum_{k=1}^{K'} \sum_{l=0}^{m_k'} p_k b_{k,l} D_y^{m-1-l} D_x^l. \end{split}$$

As a consequence of (1,6,1,25), this operator is also

$$\begin{split} \sum_{l=1}^{K''} \sum_{k=0}^{m_l''} q_l c_{l,k} D_x^{m-1-k} D_y^k &= \sum_{l=1}^{K''} q_l D_x^{m-1-m_l''} \sum_{k=0}^{m_l''} c_{k,l} D_x^{m_l''-k} D_y^k \\ &= \sum_{l=1}^{K''} Q_l (D_y) C_l (D_x, D_y). \end{split}$$

This is exactly identity (1,6,1,18), from which (1,6,1,17) follows. This last inequality is exactly inequality (1,6,1,24), which we wanted to check. Summing up, we have proved the existence of the numbers  $a_{k,l}$  and the functions  $a_{k,l}$  which are solutions of (1,6,1,21) and (1,6,1,22).

Now we are left with the problem of finding the functions  $f_k$  and  $g_l$ . We recall that (1,6,1,20) implies identities similar to (1,6,1,8), namely

$$\begin{cases}
g_{m'_{k}} = \frac{1}{b_{k,m'_{k}}} \left\{ \varphi_{k} - \sum_{l=0}^{m'_{k}-1} b_{k,l} g_{l}^{(m'_{k}-1)} \right\}, & 1 \leq k \leq K' \\
f_{m''_{l}} = \frac{1}{c_{l,m''_{l}}} \left\{ \psi_{l} - \sum_{k=0}^{m''_{l}-1} c_{l,k} f_{k}^{(m''_{l}-k)} \right\}, & 1 \leq l \leq K''
\end{cases}$$
(1,6,1,26)

We obtain the functions  $f_k$  such that  $k \neq m''_l$  for all l and the functions  $g_l$  such that  $l \neq m'_k$  for all k by applying the following lemma.

**Lemma 1.6.1.7** Let  $a_0, \ldots, a_{m-2} \in \mathbb{R}$  be given together with  $a_{m-1} \in H^{1/2}(\mathbb{R}_+)$ ; then there exists  $f \in H^{m+1/2}(\mathbb{R}_+)$  such that

$$\begin{cases} f^{(k)}(0) = a_k, & 0 \le k \le m - 2 \\ \int_0^1 |f^{(m-1)}(t) - a_{m-1}(t)|^2 \frac{dt}{t} < +\infty. \end{cases}$$

The remainder of the proof is similar to that of Theorem 1.6.1.4. Indeed, so far, we have built  $f_k \in H^{m-k-1/2}(\mathbb{R}_+)$  and  $g_l \in H^{m-l-1/2}(\mathbb{R}_+)$  such that (1,6,1,20) holds and such that

$$\begin{cases} f_k^{(1)}(0) = a_{k,l}, & 0 \le l \le m - k - 1\\ \int_0^1 |f_k^{(m-k-1)}(t) - a_{k,m-k-1}(t)|^2 \frac{\mathrm{d}t}{t} < +\infty \end{cases}$$
 (1,6,1,27)

for  $k \neq m_l''$  (l = 1, 2, ..., K''), and such that

$$\begin{cases} g_l^{(k)}(0) = a_{k,l}, & 0 \le k \le m - l - 1\\ \int_0^1 |g^{(m-l-1)}(t) - a_{m-l-1,l}(t)|^2 \frac{\mathrm{d}t}{t} < +\infty \end{cases}$$
 (1,6,1,28)

for  $l \neq m'_k$  (k = 1, ..., K'). We still have to check the similar property for the remaining indexes  $k = m''_l$  and  $l = m'_k$ . Proving that  $f_k^{(l)}(0) = a_{k,l} = g_l^{(k)}(0)$  for k + l < m - 1 is exactly the last step of the proof of Theorem 1.6.1.4. Consequently, let us only check that

$$\int_0^1 |f_{m_i''}^{(m-1-m_i'')}(t) - a_{m_i'',m-m_i''-1}(t)|^2 \frac{\mathrm{d}t}{t} < +\infty$$

for one  $l = \hat{l}$  provided we already know that the property holds for  $l \le \hat{l} - 1$ . Indeed we have

$$f_{m_i''-1}^{(m-m_i''-1)} = \frac{1}{c_{l,m_i''}} \left\{ \psi_l^{(m-m_i''-1)} - \sum_{k=0}^{m_i''-1} c_{l,k} f_k^{(m-k-1)} \right\}.$$

Near zero this implies that

$$\int_0^1 \left| c_{\hat{l},m_i^n} f_{m_i^n}^{(m-m_i^n-1)}(t) - \psi_i^{(m-m_{i-1}^n-1)}(t) - \sum_{k=0}^{m_{i-1}^n} c_{\hat{l},k} a_{k,m-k-1}(t) \right|^2 \frac{\mathrm{d}t}{t} < +\infty$$

because of our induction hypothesis. On the other hand, it follows from (1,6,1,22) that

$$\int_{0}^{1} \left| c_{\hat{l},m_{\hat{l}}''} a_{m_{\hat{l}}'',m-m_{\hat{l}}''-1}(t) - \psi_{\hat{l}}^{(m-m_{\hat{l}}''-1)}(t) - \sum_{k=0}^{m_{\hat{l}}''-1} c_{\hat{l},k} a_{k,m-k-1}(t) \right|^{2} \frac{\mathrm{d}t}{t} < +\infty$$

and since  $c_{1,m_i^2} \neq 0$ , this shows that

$$\int_0^1 \left| f_{m_i''}^{(m-m_i''-1)}(t) - a_{m_i'',m-m_i''-1}(t) \right|^2 \frac{\mathrm{d}t}{t} < +\infty.$$

This is the desired result. Consequently (1,6,1,27) is proved by induction for  $k = m_l''$  for all l; (1,6,1,28) is proved the same way.

The existence of u solving our trace problem follows from that of  $f_k$  and  $g_l$ , through the application of Theorem 1.5.2.4. This completes the proof of Theorem 1.6.1.5.

*Proof of Lemma 1.6.1.6* We just write that

$$\mathbf{a} = M\mathbf{b}$$

where *M* is any matrix such that *AM = P* and P is a projection operator on the image of A. Fredholm's alternative theorem implies that the image of A is the orthogonal of all linear forms *cp* such that *cp o* A = 'Apr = 0. n

Proof of *Lemma* 1.6.1.7 We set

$$f(t) = \left\{ \sum_{k=0}^{m-2} a_k \frac{t^k}{k!} + \int_0^t \frac{(t-s)^{m-2}}{(m-2)!} a_{m-1}(s) \, \mathrm{d}s \right\} \xi(t),$$

where is any smooth cut-off function which is zero for *t* > 3 and identically equal to 1 for t <. <sup>n</sup>

*Remark 1.6.1.8* Assume in Theorem 1.6.1.4 that *fl* has a (strictly) polygonal boundary and the B *<sup>k</sup>* are homogeneous and have constant coefficients (as in Theorem 1.6.1.5); then the necessary and sufficient conditions (1,6,1,2) in Theorem 1.6.1.4 involve only operators P*1, <sup>k</sup>* and Q; +, , *<sup>k</sup>* homogeneous and with constant coefficients. This is easily checked by inspecting the proof of Theorem 1.6.1.4.

#### 1.7 A model domain with a cut

Domains with cuts sometimes occur in practice (in fracture mechanics for instance). We shall not undertake here a comprehensive study of the properties of Sobolev spaces on such domains. We shall only illustrate, on the simplest possible example, the basic trick which reduces most of the proofs for domains with cuts to the more classical proofs of the previous sections. This relies on the trace theorems.

Our model domain is

$$\Omega = \{(x, y) \mid x^2 + y^2 < 1, x < 0 \text{ when } y = 0\}.$$

In other words f2 is obtained by removing the right half x-axis from the unit disc. Such a domain does not fulfil the assumptions of any of the definitions in Section 1.2.

The space Wp (Q) has been defined in Section 1.3, but no property has been obtained in Sections 1.4-1.6 for this space. However, the trace theorems in Section 1.5.2 imply many properties. The trick consists in splitting *f* into two pieces: let us denote by *D,* the domains

$$\Omega_+ = \Omega \cap \{y > 0\}, \qquad \Omega_- = \Omega \cap \{y < 0\}.$$

Then *12±* are plane open domains whose boundaries are curvilinear

![](_page_90_Picture_3.jpeg)

polygons of class C. For u *E* Wp (Q) we set

$$u_+=u\mid_{\Omega_+}, \qquad u_-=u\mid_{\Omega_-}.$$

It is obvious that u*t E* W(rZi) and consequently u, have welf-defined traces, up to the order m — 1, on {y = 0}. To make things more precise we denote by -yam the trace operators from W(Q) onto Wp*- 'JP(]* 1, + 1[) which are defined by

$$(\gamma_{\pm}u)(x)=u(x,0)$$

for u *E* 2(,D±) respectively (see Theorem 1.5.2.1). We can reconstruct u from u <sup>+</sup> and u- by the following result:

*Theorem 1.7.1 Let u belong to 4(D) and denote by u, its restrictions to <sup>D</sup>*t *respectively; then u E W' (Q)* iff u*t E W' (Q) and*

$$(\gamma_+ D_y^k u_+)(x) = (\gamma_- D_y^k u_-)(x), \qquad 0 \le k \le m - 1,$$
 (1,7,1)

*for almost every x E ]-* 1, U[.

*Proof* We prove the necessity of (1,7,1) by approximating *u* by u" *<sup>E</sup> v = 1, 2,...* in the norm of Wp (Q*R* ), where

$$\Omega_{g} = \Omega \cap \{x < 0\}.$$

Since ,2g has a continuous boundary we can apply Theorem 1.4.2.1. Now, on ]— 1, 0[, we have

$$(\gamma_{+}D_{y}^{k}u_{\nu})(x) = (\gamma_{-}D_{y}^{k}u_{\nu})(x) = (D_{y}^{k}u_{\nu})(x,0).$$

By continuity the first identity is extended to u.

We prove the sufficiency as follows. We can approximate  $u_+$  by  $u_+^{\nu} \in \mathcal{D}(\bar{\Omega}_+)$  and  $u_-$  by  $u_-^{\nu} \in \mathcal{D}(\bar{\Omega}_-)$ ,  $\nu = 1, 2, \ldots$  in the norm of  $W_p^m(\Omega_+)$  and  $W_p^m(\Omega_-)$  respectively. We define a distribution  $u^{\nu}$  by setting

$$\langle u^{\nu}; \varphi \rangle = \int_{\Omega} u_{+}^{\nu} \varphi \, dx \, dy + \int_{\Omega} u_{-}^{\nu} \varphi \, dx \, dy$$

for all test functions  $\varphi \in \mathcal{D}(\Omega)$ . It is a classical result that

$$\langle D_{x}^{k} D_{y}^{l} u^{\nu}; \varphi \rangle = \int_{\Omega_{-}} D_{x}^{k} D_{y}^{l} u_{+}^{\nu} \varphi \, dx \, dy + \int_{\Omega_{-}} D_{x}^{k} D_{y}^{l} u_{-}^{\nu} \varphi \, dx \, dy$$

$$+ \sum_{i=0}^{l-1} (-1)^{i} \int_{-1}^{0} \left[ (D_{x}^{k} \gamma_{+} D_{y}^{l-i-1} u_{+}^{\nu})(x, 0) - (D_{x}^{k} \gamma_{-} D_{y}^{l-i-1} u_{-}^{\nu})(x, 0) \right] D_{y}^{i} \varphi(x, 0) \, dx.$$

By continuity, we obtain

$$\langle D_{x}^{k} D_{y}^{l} u; \varphi \rangle = \int_{\Omega_{+}} D_{x}^{k} D_{y}^{l} u_{+} \varphi \, dx \, dy + \int_{\Omega_{-}} D_{x}^{k} D_{y}^{l} u_{-} \varphi \, dx \, dy$$

$$+ \sum_{j=0}^{l-1} (-1)^{j} \int_{-1}^{0} \left[ (D_{x}^{k} \gamma_{+} D_{y}^{l-j-1} u_{+})(x, 0) - (D_{x}^{k} \gamma_{-} D_{y}^{l-j-1} u_{-})(x, 0) \right] D_{y}^{j} \varphi(x, 0) \, dx$$

provided  $k+l \le m-1$ . This, together with (1,7,1), proves that

$$\langle D_x^k D_y^l u; \varphi \rangle = \int_{\Omega_+} D_x^k D_y^l u_+ \varphi \, dx \, dy + \int_{\Omega_-} D_x^k D_y^l u_- \varphi \, dx \, dy \qquad (1,7,2)$$

for  $k+l \le m-1$ . Consequently  $D_x^k D_y^l u$  is a function and belongs to  $L_p(\Omega)$ . This completes the proof.

We shall now draw some conclusions from Theorem 1.7.1. First, in general, there is no reason why  $\gamma_+ u_+$  and  $\gamma_- u_-$  should coincide on ]0, 1[. This implies that  $C^{\infty}(\bar{\Omega})$  is not dense in  $W_p^m(\Omega)$ . Indeed  $\bar{\Omega}$  is the closed unit disc. For all  $u \in C^{\infty}(\bar{\Omega})$  we have  $\gamma_+ u_+ = \gamma_- u_-$  on ]-1, +1[; by continuity this identity is also valid for all u belonging to the closure of  $C^{\infty}(\bar{\Omega})$  in  $W_p^m(\Omega)$ . It is also obvious that the norms of  $W_p^m(\Omega)$  and of  $W_p^m(\Omega_1)$ , where  $\Omega_1$  is the open unit disc, coincide on  $W_p^m(\Omega_1)$ . Consequently the closure of  $C^{\infty}(\bar{\Omega})$  in  $W_p^m(\Omega)$  is the space of the restrictions to  $\Omega$  of all the functions in  $W_p^m(\Omega_1)$ . Since  $W_p^m(\bar{\Omega}_1) = W_p^m(\Omega_1)$ , this shows that  $W_p^m(\bar{\Omega}) \neq W_p^m(\Omega)$ ; in other words  $W_p^m(\Omega)$  has no extension property similar to that in Theorem 1.4.3.1.

In order to obtain some convenient density and imbedding results we must introduce some other spaces.

**Definition 1.7.2** We denote by  $C^{k,\alpha}(\tilde{\Omega})$  the space of all functions u

defined in  $\Omega$ , which are uniformly continuous together with their derivatives up to the order k and such that their derivatives of order k satisfy a uniform Hölder condition with exponent  $\alpha$ , in  $\Omega$ .

It is easily seen that  $u \in C^{k,\alpha}(\tilde{\Omega})$  iff

$$u_+ \in C^{k,\alpha}(\Omega_+)$$

and

$$D_{\mathbf{y}}^{l}u_{+}(x,0) = D_{\mathbf{y}}^{l}u_{-}(x,0), \qquad -1 < x < 0$$

for all l such that  $0 \le l \le k$ .

An easy consequence of Theorems 1.7.1 and 1.4.5.2 is that

$$W_p^s(\Omega) \subseteq W_q^t(\Omega) \tag{1.7.3}$$

provided  $s-2/p \ge t-2/q$ ,  $t \le s$  and

$$W_{n}^{s}(\Omega) \subseteq C^{k,\alpha}(\tilde{\Omega}) \tag{1.7.4}$$

provided  $k + \alpha \le s - 2/p$  and s - 2/p is not an integer.

The main consequence of Theorem 1.7.1 is a trace theorem for the space  $W_p^m(\Omega)$ . We shall state it and derive it carefully since it is fundamental for studying boundary value problems in a domain like  $\Omega$ .

For this purpose, besides the trace operators  $\gamma_{\pm}$  already defined, we introduce the trace operator  $\gamma_c$  on the unit circle. We consider the subdomains  $\Omega_c$  defined by

$$\Omega_{\varepsilon} = \{ (r \cos \theta; r \sin \theta) \mid 0 < r < 1, \varepsilon < \theta < 2\pi - \varepsilon \}$$

for  $\varepsilon > 0$ . Clearly  $\Omega = \Omega_0 = \bigcup_{r>0} \Omega_r$  and  $\Omega_r$  has a Lipschitz boundary. We denote by  $C_r$  the interior of the intersection of the unit circle with  $\Gamma_r$  the boundary of  $\Omega_r$ . The function

$$\gamma u|_{C}$$

is well defined by Theorem 1.5.2.1 applied to  $\Omega_{\epsilon}$ . In addition it belongs to  $W_p^{1-1/p}(C_{\epsilon})$  when u belongs to  $W_p^1(\Omega)$ . We define a function  $\gamma_c u$  a.e. on  $C_0$  by setting

$$\gamma_C u|_{C_r} = \gamma u|_{C_r}$$

for every  $\varepsilon > 0$ . (This definition may seem artificial, but it saves the proof of a density theorem which is not easy.)

From now on we set

$$\gamma_C \frac{\partial^l u}{\partial r^l} = g_l, \qquad l = 0, 1, \dots, m - 1$$
 (1,7,5)

SOBOLEV SPACES

and

78

$$\gamma_{\pm}D_{\nu}^{l}u = f_{\pm,l}, \qquad l = 0, 1, \dots, m-1$$

for  $u \in W_p^m(\Omega)$ . We consider  $g_l$  as a function of  $\theta \in ]0, 2\pi[$ , and  $f_{\pm,l}$  as a function of  $x \in ]0, 1[$ .

#### **Theorem 1.7.3** The mapping

$$u \rightarrow \{g_l, f_{+,l}, f_{-,l}\}_{l=0}^{m-1}$$

is linear continuous from  $W_p^m(\Omega)$  onto the subspace of

$$\prod_{l=0}^{m-1} W_{\mathsf{p}}^{m-l-1/\mathsf{p}}(]0, 2\pi[) \times W_{\mathsf{p}}^{m-l-1/\mathsf{p}}(]0, 1[) \times W_{\mathsf{p}}^{m-l-1/\mathsf{p}}(]0, 1[)$$

defined by the following conditions

(a) 
$$g_1^{(k)}(0) = f_{+,k}^{(l)}(1), \quad g_1^{(k)}(2\pi) = f_{-,k}^{(l)}(1), \quad f_{+,k}^{(l)}(0) = f_{-,k}^{(l)}(0)$$

for k+1 < m-2/p

(b) 
$$\int_{0}^{1} |g_{+,k}^{(k)}(t) - f_{+,k}^{(l)}(1-t)|^{2} \frac{dt}{t} < +\infty,$$

$$\int_{0}^{1} |g_{+,k}^{(k)}(2\pi - t) - f_{-,k}^{(l)}(1-t)|^{2} \frac{dt}{t} < +\infty,$$

$$\int_{0}^{1} |f_{+,k}^{(l)}(t) - f_{-,k}^{(l)}(t)|^{2} \frac{dt}{t} < +\infty$$

$$for \ k + l = m - 1, \ when \ p = 2.$$

**Proof** The necessity of the compatibility conditions between the  $g_l$  and the  $f_{+,k}$  follows from Theorem 1.5.2.8 on  $\Omega_+$ . In the same way Theorem 1.5.2.8 on  $\Omega_-$  implies the compatibility conditions between the  $g_l$  and the  $f_{-,k}$ .

On the other hand the functions  $D_y^l u_{\pm}$  have traces  $\gamma_{\pm} D_y^l u_{\pm}$  which belong to

$$W_p^{m-l-1/p}(]-1,+1[)$$

and which coincide for  $x \in ]-1, 0[$  by Definition 1.7.1. Consequently, we have

$$(f_{+,l}-f_{-,l}) \in \tilde{W}_{p}^{m-l-1/p}(]0, 1[).$$

The compatibility conditions between  $f_{+,l}$  and  $f_{-,l}$  follow from Theorem 1.5.1.5 for k+l < m-2/p and from Lemma 1.3.2.6 for k+l = m-1 (and p=2).

In order to prove that the above conditions are sufficient, we start from given functions  $g_l$  and  $f_{\pm,k}$  fulfilling those conditions. Then instead of

looking for  $u \in W_p^m(\Omega)$ , having such traces, we first look for functions  $F_k$ , k = 0, 1, ..., m-1, the traces of u on the segment  $\{(x, y); -1 < x < 0\}$ . We claim that there exists

$$F_k \in W_p^{m-k-1/p}(]-1,0[)$$

such that

$$F_k^{(l)}(0) = f_{+k}^{(l)}(0) \tag{1.7.6}$$

for k+l < m-2/p,

$$\int_{0}^{1} |F_{k}^{l}(-t) - f_{+,k}^{l}(t)|^{2} \frac{\mathrm{d}t}{t} < +\infty$$
(1,7,7)

for k + l = m - 1 (p = 2) and

$$F_k^{(1)}(-1) = (-1)^{k+1}g_1^{(k)}(\pi) \tag{1.7.8}$$

for k+l < m-2/p

$$\int_{0}^{1} |F_{k}^{(l)}(-1+t) - (-1)^{k+l} g_{l}^{(k)}(\pi-t)|^{2} \frac{\mathrm{d}t}{t} < +\infty$$
 (1,7,9)

for k + l = m - 1 (p = 2).

The construction of such functions  $F_k$  is easy when  $p \neq 2$ , while their existence follows from Lemma 1.6.1.7 when p = 2. Then we set

$$F_{\pm,k}(x) = \begin{cases} F_k(x) & \text{for } -1 < x < 0 \\ f_{\pm,k}(x) & \text{for } 0 < x < 1. \end{cases}$$

Clearly  $F_{\pm,k} \in W_p^{m-k-1/p}(]-1, +1[)$  and applying Theorem 1.5.2.8 to  $\Omega_+$  and  $\Omega_-$  we check that there exists

$$u_{\pm} \in W^m_p(\Omega_{\pm})$$

such that

$$\gamma_{\pm} D_{y}^{k} u_{\pm} = F_{\pm,k}, \qquad 0 \leq k \leq m-1$$

and that

$$\gamma_c \frac{\partial^l u_{\pm}}{\partial r^l} = g_l, \qquad 0 \le l \le m - 1$$

on  $]0, \pi[$  and  $]\pi, 2\pi[$  respectively.

Since we have obviously

$$\gamma_{+}D_{y}^{k}u_{+} = \gamma_{-}D_{y}^{k}u_{-}$$
 on ]-1,0[

for  $0 \le k \le m-1$ , it follows that the function on  $\Omega$  built up from  $u_+$  and  $u_-$  belongs to  $W_p^m(\Omega)$ . In addition it has the required traces.

80 SOBOLEV SPACES *Remark 1.7.4* It is easy to combine the results of Theorems 1.7.3 and 1.5.2.8 to obtain the description of the traces for more general domains with cuts. It turns out that the statement of Theorem 1.5.2.8 remains valid if we admit domains with cuts provided we consider both sides of the cut as two different sides of fl. In the same way the Theorems 1.6.1.4 and 1.6.1.5 remain valid for domains with cuts. Also Theorem 1.4.5.3 holds for such domains.

## Regular secondworder elliptic boundary value problems

#### 2.1 Foreword

In the following chapters, we shall carry out the study of some elliptic houndary value prohlems in domains whose boundaries are not smooth: for example, domains with polygonal boundaries. Throughout this study, we shall make an extensive use of results concerning the same kind of boundary value problems in domains with regular houndaries. (We shall call these problems `regular'.) The theory of such houndary value problems can be found in Normander (1963) and Lions and Magenes (1960-- 63), for instance. These authors consider problems of arhitrary order in domains with a C i houndary. Less general houndary value problems are solved in domains with less smooth boundaries by Agmon (1965), Miranda (1970), Nécas (1967).

In spite of the great numher of possible referenties on elliptic houndary value problems, we shall devote this chapter to a self-contained study of second-order strongly elliptic houndary value problems in regular domains. Apart trom the objective of making this pook as self-contained as possihle, the purpose of this chapter is two-fold.

Three kinds of methods, at least, have proved to he quite successful in solving regular elliptic houndary value prohlems. Namely,

- (a) A *priori* estimates as in Agmon (1965), Lions and Magenes (1960-- 63), Miranda (1970) and Nécas (1967);
- (h) parametrices as in Hörmander (1963);
- (c) pseudo-differential operators as in Seeley (1966).

These methods have long heen known to allow ;ene to solve elliptic houndary value problems involving, operators with coefficients only a few times differentiable, in domains with houndaries also only a few times differentiable. However. most of the availahle referenties deal oniv with the C case. It is within the scope of this book to try to see to what extent the assumptions on the coefficients and on the boundary can be

weakened when applying those methods. Actually we shall restrict ourselves to the *a priori* estimates method, which seems to be more flexible in this respect. It turns out that the most general domains that one is able to handle with such methods, have a boundary of class  $C^{1,1}$ . This assumption clearly excludes polygonal boundaries.

The second purpose of this chapter is to give a brief account of the  $L_p$ theory. The  $L_n$  theory of linear elliptic boundary value problems is of the utmost importance in the study of nonlinear problems. The reason is that, for a given m and a given domain  $\Omega$ , the Sobolev space  $W_n^m(\Omega)$  is more likely to be an algebra when p is large. The core of the  $L_p$  theory is the celebrated  $L_p$  a priori estimate proved by Agmon et al. (1959). These authors deal with problems of great generality. Their proofs can hardly be found, even in simpler particular cases, outside this original reference (but see Freeman and Schechter (1974)). We give here a simplified proof of the L<sub>n</sub> estimate in the case of second-order strongly elliptic boundary value problems. This proof is closer to the  $L_2$  proof, since it uses the partial Fourier transform, with the Plancherel theorem being replaced by the famous L<sub>p</sub> multiplier theorem of Mih'lin (1956) (see also Hörmander (1960)). The proof makes use of a technical idea introduced for a different purpose by Boutet de Monvel (1971). The related existence and uniqueness results will be worked out in domains whose boundary is only of class  $C^{1,1}$ . This does not seem to be standard material and will be useful in the next chapters. (Here we attempt to work with the weakest assumptions on the domain but not on the coefficients of the operators. Indeed, in most practical cases one deals with simple operators—such as operators with constant coefficients—in bad domains.)

Let us now introduce the following framework for the remainder of this chapter. The domain  $\Omega$  will be a bounded open subset of  $\mathbb{R}^n$ . The operator A is a second-order strongly elliptic real operator in  $\Omega$ , and B is a real boundary operator of order d (d=0 or 1). In most of the forthcoming sections, we shall make the following assumptions:

- (a) the boundary  $\Gamma$  of  $\Omega$  is of class  $C^{1,1}$  (see Definition 1.2.1.1)
- (b) the operator A is in divergence form:

$$Au = \sum_{i,j=1}^{n} D_i(a_{ij}D_ju)$$

with  $a_{i,j} = a_{j,i} \in C^{0,1}(\vec{\Omega})$  and there exists  $\alpha > 0$  such that

$$\sum_{i,j=1}^{n} a_{i,j}(x)\xi_{i}\xi_{j} \leq -\alpha |\xi|^{2}$$
(2,1,1)

for all  $x \in \overline{\Omega}$  and  $\xi \in \mathbb{R}^n$ .

(c) B is either the identity operator (thus d = 0) or

$$Bu = \sum_{i=1}^{n} b_i D_i u {(2,1,2)}$$

with  $b_i \in C^{0.1}(\bar{\Omega})$ ,  $i \le i \le n$  (then d = 1) and  $\sum_{i=1}^n b_i \nu^i \ne 0$  everywhere on  $\Gamma$ . (In other words,  $\Gamma$  is nowhere characteristic for B.)

For a given function f defined in  $\Omega$  and a given function g defined on  $\Gamma$ , we shall look for u defined in  $\bar{\Omega}$  such that

$$\begin{cases} Au = f & \text{in } \Omega \\ Bu = g & \text{on } \Gamma. \end{cases}$$
 (2,1,3)

For some technical reasons, it will often be convenient to consider the related problem with an extra real parameter  $\lambda$  as follows.

$$\begin{cases} Au + \lambda u = f & \text{in } \Omega \\ Bu = g & \text{on } \Gamma. \end{cases}$$
 (2,1.4)

Later on, we shall add lower order terms to A and B and get rid of  $\lambda$ . In the particular case where B = I, our problem is just a Dirichlet problem for the equation  $Au + \lambda u = f$ . Another particular case is when Bu is the 'co-normal derivative' of u corresponding to A, i.e.

$$b_i = \sum_{j=1}^n a_{i,j} \nu^i \quad \text{on } \Gamma,$$

where  $v^j$ ,  $1 \le j \le n$  are the components of the unit outer normal vector field on  $\Gamma$ . Then, our problem is a Neumann problem for the equation  $Au + \lambda u = f$ . In the general case when d = 1, we are solving the equation  $Au + \lambda u = f$  with an 'oblique' boundary condition.

Actually, we shall pose the problem (2,1,4) in the framework of Sobolev spaces. Thus we shall look for conditions ensuring that

$$T_{p,\lambda}: u \mapsto \{Au + \lambda u, \gamma Bu\}$$

is an isomorphism from  $W_p^2(\Omega)$  onto  $L_p(\Omega) \times W_p^{2-d-1/p}(\Gamma)$ , 1 .

Let us conclude this introductory section with some examples of the results which we will look for in this chapter. These examples are related to the Laplace operator  $\Delta$ . First, Theorem 2.4.2.5 implies that for every  $f \in L_p(\Omega)$  and every  $g \in W_p^{2-1/p}(\Gamma)$ , there exists a unique  $u \in W_p^2(\Omega)$  which is a solution of

$$\begin{cases} \Delta u = f & \text{in } \Omega \\ \gamma u = g & \text{on } \Gamma \end{cases}$$

provided  $1 and <math>\Omega$  is a bounded open subset of  $\mathbb{R}^n$  with a  $C^{1,1}$ 

boundary. Then, Theorem 2.4.2.6 implies that for every  $f \in L_p(\Omega)$  and every  $g \in W_p^{1-1/p}(\Gamma)$  there exists a unique  $u \in W_p^2(\Omega)$  which is a solution of

$$\begin{cases} \Delta u = f & \text{in } \Omega \\ \gamma \left( \frac{\partial u}{\partial \nu} + b_0 u \right) = g & \text{on } \Gamma \end{cases}$$

provided  $b_0 \in C^{0,1}(\bar{\Omega})$  and  $b_0 > 0$  everywhere on  $\Gamma$ , under the same assumptions as above on p and  $\Omega$ . Similarly, Theorem 2.4.2.7 implies that for every  $f \in L_p(\Omega)$  and every  $g \in W_p^{1-1/p}(\Gamma)$  there exists a unique  $u \in W_p^2(\Omega)$  which is a solution of

$$\begin{cases} -\Delta u + a_0 u = f & \text{in } \Omega \\ \gamma \frac{\partial u}{\partial \nu} = g & \text{on } \Gamma \end{cases}$$

provided  $a_0 \in L^{\infty}(\Omega)$  and  $a_0 \ge \beta > 0$  a.e. in  $\overline{\Omega}$ , under the same assumptions as before on p and  $\Omega$ . Oblique boundary conditions are also considered in those theorems.

Unless otherwise indicated, we only consider real-valued functions in this chapter (with the exception of some proofs in Section 2.3.2 which require the use of the Fourier transform).

#### 2.2 Variational solution of special problems

The roots of almost all the forthcoming results lie in a basic existence and uniqueness theorem for solutions in  $H^1(\Omega)$ . This result is proved by the variational method introduced first by Euler. A much more detailed description of the extent of this powerful method can be found in Magenes and Stampacchia (1958), Lions (1956), Něcas (1967) and Agmon (1959) for instance. We quote here the minimal material that we will need in the following chapters. In particular, we restrict ourselves to Dirichlet's and Neumann's problems although the variational approach allows us to solve problems with an oblique boundary condition.

#### 2.2.1 Existence and uniqueness

According to what is said above we are looking for u which is a solution of

$$Au + \lambda u = \sum_{i,j=1}^{n} D_i(a_{ij}D_ju) + \lambda u = f \quad \text{in } \Omega$$
 (2,2,1,1)

with either a Dirichlet boundary condition

$$u = 0 \qquad \text{on } \Gamma \tag{2,2,1,2}$$

or a Neumann boundary condition

$$\frac{\partial u}{\partial \nu_{\Delta}} = \sum_{i,j=1}^{n} a_{ij} \nu^{i} \frac{\partial u}{\partial x_{i}} = g \qquad \text{on } \Gamma.$$
 (2,2,1,3)

Euler's variational approach to these problems consists of viewing them as the equation of critical points for some functional (see Section 1.1). However, we shall use a slightly different setting based on the famous Lax-Milgram Lemma. This will allow us also to deal with oblique boundary conditions later on.

**Lemma 2.2.1.1** Let V be a Hilbert space and let a be a continuous bilinear form on  $V \times V$ . (a does not need to be symmetric.) Assume that a is coercive, i.e. that there exists a constant  $\alpha > 0$  such that

$$a(u; u) \ge \alpha ||u||_V^2$$

for all  $u \in V$ . Then for every continuous linear form l on V, there exists a unique  $u \in V$  such that

$$a(u; v) = l(v)$$
 (2,2.1,4)

for every  $v \in V$ .

Now the problem is to convert equation (2,2,1,1) and the boundary condition into a problem of the form (2,2,1,4). This is achieved by performing integration by parts, using Theorem 1.5.3.1. Let us assume, for instance, that  $u \in H^2(\Omega)$  is a solution of (2,2,1,1), (2,2,1,2) and that  $v \in \mathring{H}^1(\Omega)$ . Then we have

$$\int_{\Omega} f v \, dx = \sum_{i,j=1}^{n} \int_{\Omega} (D_{i} a_{ij} D_{j} u) v \, dx + \lambda \int_{\Omega} u v \, dx$$

$$= -\sum_{i,j=1}^{n} \int_{\Omega} a_{ij} D_{j} u D_{i} v \, dx + \lambda \int_{\Omega} u v \, dx. \qquad (2,2,1,5)$$

It is therefore natural to define a and l on  $V = \mathring{H}^1(\Omega)$  as follows:

$$a(u, v) = -\sum_{i,j=1}^{n} \int_{\Omega} a_{ij} D_{i} u D_{i} v \, dx + \lambda \int_{\Omega} u v \, dx$$
$$l(v) = \int_{\Omega} f v \, dx.$$

With this choice of V, a and l, our u is a solution of problem (2,2,1,4).

Conversely, it is easily seen that a is bilinear, continuous and coercive on V for  $\lambda \ge 0$ , while l is continuous for  $f \in L_2(\Omega)$ . Applying Lemma 2.2.1.1, we obtain the basic existence and uniqueness result for Dirichlet's problem.

**Theorem 2.2.1.2** For every  $f \in L_2(\Omega)$  there exists a unique  $u \in H^1(\Omega)$  solution of equation (2,2,1,1), with the boundary condition  $\gamma u = 0$ , provided  $\lambda \ge 0$ .

**Proof** Identity (2,2,1,4) with all  $v \in \mathcal{D}(\Omega)$ , means that  $Au + \lambda u = f$  in the sense of distributions. This is all the information that we can get from (2,2,1,4) since  $\mathcal{D}(\Omega)$  is dense in  $\mathring{H}^1(\Omega)$ . The fulfillment of the boundary condition  $\gamma u = 0$  follows from Corollary 1.5.1.6.

We turn now to the Neumann problem. Let us assume, as a starting point, that  $u \in H^2(\Omega)$  is a solution of (2,2,1,1), (2,2,1,3) and that we have  $v \in H^1(\Omega)$ . Then we have

$$\int_{\Omega} fv \, dx = \sum_{i,j=1}^{n} \int_{\Omega} (D_{i} a_{ij} D_{j} u) v \, dx + \lambda \int_{\Omega} uv \, dx$$

$$= -\sum_{i,j=1}^{n} \int_{\Omega} a_{ij} D_{j} u D_{i} v \, dx + \int_{\Gamma} gv \, d\sigma + \lambda \int_{\Omega} uv \, dx. \qquad (2,2,1,6)$$

Accordingly, we define a as above and l as follows on  $V = H^1(\Omega)$ :

$$l(v) = \int_{\Omega} f v \, dx - \int_{\Gamma} g v \, d\sigma.$$

It follows again that u is a solution of problem (2,2,1,4).

Conversely, it is easily seen that a is bilinear, continuous and coercive on V for  $\lambda > 0$ , while l is continuous provided  $f \in L_2(\Omega)$  and  $g \in L_2(\Gamma)$ . We again apply Lemma 2.2.1.1 for proving the basic existence and uniqueness result for Neumann's problem:

**Theorem 2.2.1.3** For every  $f \in L_2(\Omega)$  and  $g \in L_2(\Gamma)$  there exists a unique  $u \in H^1(\Omega)$  such that

$$-\sum_{i,j=1}^{n} \int_{\Omega} a_{ij} D_{j} u D_{i} v \, dx + \lambda \int_{\Omega} u v \, dx = \int_{\Omega} f v \, dx - \int_{\Gamma} g v \, d\sigma \qquad (2,2,1,7)$$

for all  $v \in H^1(\Omega)$ , provided  $\lambda > 0$ .

If we restrict identity (2,2,1,7) to  $v \in \mathfrak{D}(\Omega)$  only, we check that  $Au + \lambda u = f$  in the sense of distributions. Consequently we have  $u \in E(A, L_2(\Omega))$  (a space defined in 1.5) and  $\gamma \partial u/\partial \nu_A$  is defined as an element of  $H^{-1/2}(\Gamma)$ . This allows one to prove that  $\gamma \partial u/\partial \nu_A = g$  on  $\Gamma$  in the sense of  $H^{-1/2}(\Gamma)$  (see details in Lions (1961a)), but we do not need this in the sequel.

#### 2.2.2 Smoothness

In this short section, we shall prove that the solutions to the Dirichlet and Neumann problems that we obtained in 2.2.1 actually belong to  $H^2(\Omega)$ . The main tool for proving this is the well-known method of tangential differential quotients due to Nirenberg. We shall use this method only near a flat boundary, taking advantage of the invariance of our set of problems under cut offs and  $C^{1.1}$  changes of coordinates.

Let us begin with the Dirichlet problem. Thus, let  $u \in \mathring{H}^{1}(\Omega)$  be a solution of

$$-\sum_{i,j=1}^{n} \int_{\Omega} a_{ij} D_j u D_i v \, dx + \lambda \int_{\Omega} u v \, dx = \int_{\Omega} f v \, dx$$
 (2,2,2,1)

for all  $v \in \mathring{H}^1(\Omega)$ . Let  $\theta$  be any function in  $\mathfrak{D}(\overline{\Omega})$  and set  $u_1 = \theta u$ . It is clear that  $u_1 \in \mathring{H}^1(\Omega)$  and that

$$-\sum_{i,j=1}^n \int_{\Omega} a_{ij} D_i u_1 D_i v \, dx + \lambda \int_{\Omega} u_1 v \, dx = \int_{\Omega} f_1 v \, dx$$

for all  $v \in \mathring{H}^1(\Omega)$  with

$$f_1 = \theta f + \sum_{i,j=1}^{n} \{ a_{ij}(D_i \theta)(D_j u) + D_i [a_{ij}(D_j \theta) u] \}.$$

This function  $f_1$  is again in  $L_2(\Omega)$  since  $a_{ij} \in C^{1,1}(\bar{\Omega})$  and  $u \in H^1(\Omega)$ .

Now let V be an open subset of  $\mathbb{R}^n$  and let  $\Phi$  be a  $C^{1,1}$  diffeomorphism of  $\overline{V}$  onto a neighbourhood of the support of  $\theta$ . Assume that

$$\Phi^{-1}(\Omega \cap \Phi(V)) = U = \mathbb{R}^n_+ \cap V.$$

(We recall that we denote by  $\mathbb{R}^n$  the half space defined by  $x_n > 0$ . In addition, possibly, V does not cut the hyperplane  $\{x_n = 0\}$ .) Then we consider  $u_2 = u_1 \circ \Phi$ . Again we have  $u_2 \in \mathring{H}^1(U)$  and setting  $\Psi = \Phi^{-1}$ , we have

$$-\sum_{k,l=1}^{n} \int_{U} a_{k,l}^{\#} D_{k} u_{2} D_{l} v \, dx + \lambda \int_{U} |D\Phi| u_{2} v \, dx = \int_{U} f_{2} v \, dx \qquad (2,2,2,2)$$

for all  $v \in \mathring{H}^1(U)$ , where

$$a_{k,l}^{\#} = \sum_{i,j=1}^{n} \left[ a_{i,j} (D_i \Psi_k) (D_j \Psi_l) \right] \circ \Phi \left| D\Phi \right|$$
$$f_2 = \left| D\Phi \right| f \circ \Phi.$$

It is clear that  $f_2 \in L_2(U)$ ,  $a_{k,l}^{\#} \in C^{0,1}(\bar{U})$ . In addition, it follows from (2,1,1)

that

$$\sum_{k,l=1}^{n} a_{k,l}^{\#}(y)\xi_{k}\xi_{l} \leq -\alpha^{\#} |\xi|^{2}$$
 (2,2,2,3)

for all  $\xi \in \mathbb{R}^n$  and  $y \in \overline{U}$ , with some  $\alpha^{\#} > 0$ .

The first step is the following.

#### **Lemma 2.2.2.1** Under the above hypotheses, we have $u_2 \in H^2(U)$ .

**Proof** We shall use identity (2,2,2,2) with a special test function v deduced from  $u_2$ . We observe that the support of  $u_2$  is contained in the inverse image of the support of  $\theta$ , by  $\Phi$ . Consequently, the support of  $u_2$  is compact in V and cuts the boundary of U only on the hyperplane  $x_n = 0$ . We extend  $u_2$  to  $\tilde{u}_2$ , a function which is zero outside of V. It is clear that  $\tilde{u}_2 \in \mathring{H}^1(\mathbb{R}^n_+)$ .

We define v as follows:

$$v = \left(\frac{\tau_{i,h} + \tau_{i,-h} - 2}{h^2}\right) \tilde{u}_2$$

where  $\tau_{i,h}$  is the operator defined by

$$\tau_{i,h}\varphi(x) = \varphi(x + he_i), \qquad 1 \le i \le n-1, \ h \in \mathbb{R},$$

 $e_i$  being the unit vector in the direction of  $x_i$ . We have  $v \in \mathring{H}^1(U)$  for h small enough. Writing identity (2,2,2,2) with this particular v, we get

$$\begin{split} & - \sum_{k,l=1}^{n} \int_{U} a_{k,l}^{\#} D_{k} \tilde{u}_{2} D_{l} \left( \frac{\tau_{i,h} - 1}{h} \right) \left( \frac{\tau_{i,-h} - 1}{h} \right) \tilde{u}_{2} \, \mathrm{d}x \\ & + \lambda \int_{U} \left| D\Phi \right| \tilde{u}_{2} \left( \frac{\tau_{i,h} - 1}{h} \right) \left( \frac{\tau_{i,-h} - 1}{h} \right) \tilde{u}_{2} \, \mathrm{d}x = \int_{U} f_{2} \frac{\tau_{i,h} - 1}{h} \frac{\tau_{i,-h} - 1}{h} \, \tilde{u}_{2} \, \mathrm{d}x. \end{split}$$

This identity implies the following, which is obtained through a discrete integration by parts, the adjoint of the operator  $\tau_{i,h}$  being  $\tau_{i,-h}$ .

$$-\sum_{k,l=1}^{n} \int_{U} \left[ \left( \frac{\tau_{i,+h} - 1}{h} \right) a_{k,l}^{\#} D_{k} \tilde{u}_{2} \right] D_{l} \left[ \frac{\tau_{i,h} - 1}{h} \tilde{u}_{2} \right] dx + \lambda \int_{U} \left[ \left( \frac{\tau_{i,h} - 1}{h} \right) |D\Phi| \tilde{u}_{2} \right] \left[ \frac{\tau_{i,h} - 1}{h} \tilde{u}_{2} \right] dx = \int_{U} f_{2} \frac{\tau_{i,h} - 1}{h} \frac{\dot{\tau}_{i,-h} - 1}{h} \tilde{u}_{2} dx.$$

Then we observe that for any two functions a and  $\varphi$  we have

$$\frac{\tau_{i,h}-1}{h}\left(a\varphi\right) = \left[\frac{\tau_{i,h}-1}{h}a\right]\tau_{i,h}\varphi + a\left[\frac{\tau_{i,h}-1}{h}\right]\varphi.$$

Therefore we find

$$\begin{split} & - \sum_{k,l=1}^{n} \int_{U} a_{k,l}^{\#} D_{k} \left[ \frac{\tau_{i,h} - 1}{h} \, \tilde{u}_{2} \right] D_{l} \left[ \frac{\tau_{i,h} - 1}{h} \, \tilde{u}_{2} \right] \mathrm{d}x \\ & = \sum_{k,l=1}^{n} \int_{U} \left[ \frac{\tau_{i,h} - 1}{h} \, a_{k,l}^{\#} \right] [\tau_{i,h} D_{k} \tilde{u}_{2}] D_{l} \left[ \frac{\tau_{i,h} - 1}{h} \, \tilde{u}_{2} \right] \mathrm{d}x \\ & - \lambda \int_{U} \left| D\Phi \right| \left[ \frac{\tau_{i,h} - 1}{h} \, \tilde{u}_{2} \right]^{2} \mathrm{d}x - \lambda \int_{U} \left[ \frac{\tau_{i,h} - 1}{h} \left| D\Phi \right| \right] \\ & \times \left[ \tau_{i,h} \tilde{u}_{2} \right] \left[ \frac{\tau_{i,h} - 1}{h} \, \tilde{u}_{2} \right] \mathrm{d}x + \int_{U} f_{2} \frac{\tau_{i,h} - 1}{h} \frac{\tau_{i,-h} - 1}{h} \, \tilde{u}_{2} \, \mathrm{d}x. \end{split}$$

From this and inequality (2,2,2,3) we deduce the following:

$$\alpha^{\#} \sum_{k=1}^{n} \left\| D_{k} \frac{\tau_{i,h} - 1}{h} \tilde{u}_{2} \right\|^{2} \leq \sum_{k,l=1}^{n} M \left\| D_{k} \tilde{u}_{2} \right\| \left\| D_{l} \frac{\tau_{i,h} - 1}{h} \tilde{u}_{2} \right\| + \lambda N \left\| \frac{\tau_{i,h} - 1}{h} \tilde{u}_{2} \right\|^{2} + \lambda N' \left\| \tilde{u}_{2} \right\| \left\| \frac{\tau_{i,h} - 1}{h} \tilde{u}_{2} \right\|^{2} + \left\| f_{2} \right\| \left\| \frac{\tau_{i,h} - 1}{h} \frac{\tau_{i,h} - 1}{h} \tilde{u}_{2} \right\|.$$

$$(2,2,2,4)$$

Here we use the norm of  $L_2(U)$ , while M is a bound for all the Lipschitz constants of the functions  $a_{k,l}^{\#}$ ,  $1 \le k$ ,  $l \le n$ , N is the maximum of  $|D\Phi|$  and finally N' is the Lipschitz constant of  $|D\Phi|$ . We already know that  $u_2 \in H^1(U)$ , therefore, from (2,2,2,4) we deduce that there exist two constants  $C_1$  and  $C_2$  such that

$$\sum_{k=1}^{n} \left\| D_k \frac{\tau_{i,h} - 1}{h} \tilde{u}_2 \right\|^2 \le C_1 + C_2 \left\| \frac{\tau_{i,h} - 1}{h} \frac{\tau_{i,-h} - 1}{h} \tilde{u}_2 \right\|$$
 (2,2,2,5)

owing to the following lemma (the proof is easy and left to the reader):

**Lemma 2.2.2.2** For  $\varphi \in H^1(\mathbb{R}^n_+)$  we have

$$\left\|\frac{\tau_{i,h}-1}{h}\varphi\right\| \leq \|D_i\varphi\|, \qquad 1 \leq i \leq n-1.$$

Next we again apply Lemma 2.2.2.2 to  $\varphi = ((\tau_{i,h} - 1)/h)\tilde{u}_2$ ; we thus get

$$\sum_{k=1}^{n} \left\| D_{k} \frac{\tau_{i,h} - 1}{h} \tilde{u}_{2} \right\|^{2} \leq C_{1} + C_{2} \left\| D_{i} \frac{\tau_{i,h} - 1}{h} \tilde{u}_{2} \right\|$$

REGULAR SECOND-ORDER PROBLEMS

and consequently

90

$$\sum_{k=1}^{n} \left\| D_k \frac{\tau_{i,h} - 1}{h} \tilde{u}_2 \right\|^2 \le 2C_1 + C_2^2 \tag{2.2.2.6}$$

for  $1 \le i \le n-1$ .

To conclude, for each i, we consider any sequence  $h_i \searrow 0$ , such that

$$D_k \frac{\tau_{i,h_i} - 1}{h_i} \tilde{u}_2, \qquad 1 \le k \le n$$

converges weakly to some limit  $\varphi_{k,i}$  in  $L_2(\mathbb{R}^n_+)$ . This is clearly possible, due to the properties of bounded sequences in a Hilbert space. We have obviously

$$D_k \frac{\tau_{i,h_i} - 1}{h_i} \tilde{u}_2 \to D_k D_i \tilde{u}_2$$

in the sense of distributions, and consequently

$$D_k D_i \tilde{u}_2 = \varphi_{k,i} \in L_2(\mathbb{R}^n_+) \tag{2,2,2,7}$$

for  $1 \le i \le n-1$ ,  $1 \le k \le n$ . This shows that all second derivatives of  $u_2$  except  $D_n^2 u_2$  are square integrable in U. However, it follows from (2,2,2,2) that

+ 
$$\sum_{k,l=1}^{n} D_{l} a_{k,l}^{\#} D_{k} u_{2} + \lambda |D\Phi| u_{2} = f_{2}$$

in *U*. Furthermore, from (2,2,2,3), we have  $a_{n,n}^{\#} \le -\alpha^{\#}$ , so that we can write

$$D_n^2 u_2 = \frac{1}{a_{n,n}^{\#}} \left\{ f_2 - \lambda |D\Phi| u_2 - \sum_{k+l \leq 2n-1} D_l a_{k,l}^{\#} D_k u_2 - (D_n a_{n,n}^{\#}) D_n u_2 \right\}$$

and this shows that  $D_n^2 u_2 \in L_2(U)$ . The proof of Lemma 2.2.2.1 is complete.

Now we prove the global result corresponding to Lemma 2.2.2.2.

**Theorem 2.2.2.3** For every  $f \in L_2(\Omega)$  there exists a unique  $u \in H^2(\Omega)$  solving equation (2,2,1,1) with the boundary condition  $\gamma u = 0$ , provided  $\lambda \ge 0$ .

**Proof** We recall that from the beginning we assume (a), (b) in Section 2.1. Thus  $\Omega$  is bounded and has a  $C^{1,1}$  boundary, while  $a_{i,j} \in C^{0,1}(\bar{\Omega})$  for  $i, j = 1, \ldots, n$ . It is therefore possible to find a finite number of open subsets  $V_k$ ,  $1 \le k \le \kappa$ , of  $\mathbb{R}^n$  together with  $C^{1,1}$  diffeomorphisms  $\Phi_k$  from

 $\bar{V}_k$  onto  $\Phi_k(\bar{V}_k)$ ,  $1 \le k \le \kappa$  such that

- (a)  $\Phi_k(V_k)$ ,  $1 \le k \le \kappa$ , is a covering of  $\bar{\Omega}$
- (b)  $\Phi_k^{-1}(\Omega \cap \Phi_k(V_k)) = U_k = \mathbb{R}_+^n \cap V_k, \quad 1 \le k \le \kappa.$

We observe that  $V_k$  need not meet the hyperplane  $x_n = 0$ , in order that the  $\Phi_k(V_k)$  also cover  $\Omega$ . We used here Theorem 1.2.1.5 which allows us to consider  $\bar{\Omega}$  as a *n*-dimensional manifold with boundary, of class  $C^{1.1}$  in  $\mathbb{R}^n$ .

With this covering of  $\bar{\Omega}$  we associate a partition of the unity  $\theta_k$ ,  $1 \le k \le \kappa$ , such that

- (c)  $\theta_k \in \mathfrak{D}(\tilde{\Omega})$
- (d) the support of  $\theta_k$  is included in  $\Phi_k(V_k)$
- (e)  $\sum_{k=1}^{\kappa} \theta_k = 1$  on  $\overline{\Omega}$ .

We apply Theorem 2.2.1.2 to prove the existence of a solution  $u \in \mathring{H}^{1}(\Omega)$  to equation (2,2,1,1). Then Lemma 2.2.2.1 shows that for each k

$$(\theta_k u) \circ \Phi_k \in H^2(U_k).$$

We conclude by reconstructing u as follows

$$u = \sum_{k=1}^{\kappa} \theta_k u = \sum_{k=1}^{\kappa} (\theta_k u) \circ \Phi_k \circ \Phi_k^{-1} \in H^2(\Omega)$$

due to Lemma 1.3.3.1.

#### Corollary 2.2.2.4 The mapping

$$u \mapsto \{Au + \lambda u; \gamma u\}$$

is invertible from  $H^2(\Omega)$  onto  $L_2(\Omega) \times H^{3/2}(\Gamma)$ , for  $\lambda > 0$ .

This is an obvious consequence of Theorem 2.2.2.3 using Theorem 1.5.1.2.

We shall now prove the same kind of results for the Neumann problem. We start from  $u \in H^1(\Omega)$  fulfilling the same identity (2,2,2,1) for all  $v \in H^1(\Omega)$  (instead of  $\mathring{H}^1(\Omega)$ ). Such a solution u exists by Theorem 2.2.1.3 with g = 0. Then exactly the same proof as in Lemma 2.2.2.1 shows that

$$(\theta u) \circ \Phi \in H^2(U)$$
.

The corresponding global result is this:

**Theorem 2.2.2.5** For every  $f \in L_2(\Omega)$  there exists a unique  $u \in H^2(\Omega)$  solving equation (2,2,1,1) with the boundary condition  $\gamma \partial u/\partial \nu_A = 0$ , provided  $\lambda > 0$ .

92

**Proof** The property that  $u \in H^2(\Omega)$  is proved exactly as in Theorem 2.2.2.3. Then identity (2,2,2,1) shows that  $Au + \lambda u = f$  in the sense of distributions (this uses  $v \in \mathcal{D}(\Omega)$ ). This allows one to rewrite (2,2,2,1) as follows:

$$-\sum_{i,j=1}^n \int_{\Omega} a_{ij} D_j u D_i v \, dx = \sum_{i,j=1}^n \int_{\Omega} (D_i a_{i,j} D_j u) v \, dx$$

for all  $v \in H^1(\Omega)$ . Finally due to Theorem 1.5.3.1, this identity is equivalent to

$$\sum_{i,j=1}^{n} \int_{\Gamma} \gamma(a_{ij}\nu_{i}D_{j}u)\gamma v \, d\sigma = 0$$

for all  $\gamma v \in H^{1/2}(\Gamma)$ . This shows that

$$\gamma \frac{\partial u}{\partial \nu_A} = \sum_{i,j=1}^n \gamma(a_{ij}\nu_i D_j u) = 0$$

in the space  $H^{1/2}(\Gamma)$  (since u belongs to  $H^2(\Omega)$ ).

#### Corollary 2.2.2.6 The mapping

$$u \mapsto \left\{ Au + \lambda u; \gamma \frac{\partial u}{\partial \nu_A} \right\}$$

is invertible from  $H^2(\Omega)$  onto  $L_2(\Omega) \times H^{1/2}(\Gamma)$  for  $\lambda > 0$ .

This follows from Theorems 2.2.2.5 and 1.5.1.2.

#### 2.3 A priori estimates

We now consider the general operators A and B introduced in Section 2.1. We no longer restrict ourselves to Dirichlet or Neumann problems. We shall prove the basic a priori estimate:

$$||u||_{2,p,\Omega} \le C\{||Au + \lambda u||_{0,p,\Omega} + ||\gamma Bu||_{2-d-1/p,p,\Gamma}\}$$
 (2,3,1,1)

for  $u \in W_p^2(\Omega)$ . This estimate holds only for  $\lambda$  large enough. This is essentially the inequality in Agmon *et al.* (1959); however, the proof given here is slightly different.

#### 2.3.1 An inequality based on the duality mapping

The duality mapping from  $L_p(\Omega)$  into its dual  $L_q(\Omega)$  (with 1/p + 1/q = 1) is the mapping  $u \mapsto u^*$  defined by

$$u^*(x) = \begin{cases} |u(x)|^{p-1} \operatorname{sgn} u(x) & \text{if } u(x) \neq 0 \\ 0 & \text{if } u(x) = 0. \end{cases}$$

The reason for introducing  $u^*$  is that it is the unique function in  $L_1(\Omega)$ , such that

$$\begin{cases} \|u^*\|_{0,q,\Omega}^{\alpha} = \|u\|_{0,p,\Omega}^{p} \\ \int_{\Omega} uu^* dx = \|u\|_{0,p,\Omega} \|u^*\|_{0,q,\Omega}. \end{cases}$$

The strong ellipticity of A allows us to prove some very useful estimates for  $\|u\|_{0,p,\Omega}$ , just by multiplying the equation  $Au + \lambda u = f$ , by  $u^*$  and integrating by parts. The boundary condition allows one to drop or to estimate the boundary integrals that appear in the integration by parts. This is the purpose of this subsection.

The differentiation of  $u^*$  will be difficult at points where u vanishes, since the sign of u will be undefined. So we shall approximate  $u^*$  by  $u^*_{\varepsilon}$  defined as follows for  $\varepsilon > 0$ :

$$u_{\nu}^{\pm}(x) = (u(x)^2 + \varepsilon)^{(p-2)/2} u(x). \tag{2.3.1.2}$$

Assuming that  $u \in C^1(\bar{\Omega})$ , we can differentiate  $u_{\varepsilon}^*$  as follows:

$$D_{i}u_{+}^{*}(x) = (u(x)^{2} + \varepsilon)^{(p-2)/2}D_{i}u(x) + (p-2)(u(x)^{2} + \varepsilon)^{(p-4)/2}u(x)^{2}D_{i}u(x).$$
(2,3,1,3)

**Lemma 2.3.1.1** For  $u \in C^1(\bar{\Omega})$ , we have

$$-\sum_{i,j=1}^{n} a_{ij}(x) D_i u D_j u_{\varepsilon}^* \ge \alpha' (u(x)^2 + \varepsilon)^{(p-2)/2} |\nabla u(x)|^2$$
 (2.3,1.4)

for all  $x \in \overline{\Omega}$ , where  $\alpha' = \alpha \inf \{1, p-1\}$ .

Proof We have

$$-\sum_{i,j=1}^{n} a_{ij} D_{i} u D_{j} u_{i}^{*} = -(u^{2} + \varepsilon)^{(p+4)/2} \{ u^{2} + \varepsilon + (p-2)u^{2} \} \sum_{i,j=1}^{n} a_{ij} D_{i} u D_{j} u$$

$$\ge -\inf \{ 1, p-1 \} (u^{2} + \varepsilon)^{(p-2)/2} \sum_{i,j=1}^{n} a_{ij} D_{i} u D_{j} u$$

$$\ge \alpha \inf \{ 1, p-1 \} (u^{2} + \varepsilon)^{(p-2)/2} |\nabla u|^{2}.$$

**Lemma 2.3.1.2** Let P be any first-order differential operator, with Lipschitz coefficients, tangential to  $\Gamma$ , everywhere on  $\Gamma$ . Then there exists  $\beta$  such that

$$\int_{\Omega} (Au + \lambda u) u_{\varepsilon}^* dx \ge \int_{\Gamma} \left( \frac{\partial u}{\partial \nu_A} + Pu \right) u_{\varepsilon}^* d\sigma - \beta \int_{\Omega} (u^2 + \varepsilon)^{p/2} dx + \lambda \int_{\Omega} (u^2 + \varepsilon)^{(p-2)/2} |u|^2 dx$$

$$(2,3,1,5)$$

for all  $u \in C^2(\bar{\Omega})$ .

94

Proof We have

$$\int_{\Omega} (Au + \lambda u) u_{\varepsilon}^* dx = -\sum_{i,j=1}^n \int_{\Omega} a_{ij} D_j u D_i u_{\varepsilon}^* dx + \int_{\Gamma} \frac{\partial u}{\partial \nu_A} u_{\varepsilon}^* d\sigma + \int_{\Omega} \lambda u u_{\varepsilon}^* dx.$$
(2,3,1,6)

Using Lemma 2.3.1.1 we deduce the following inequality:

$$\int_{\Omega} (Au + \lambda u) u_{\varepsilon}^* dx \ge \alpha' \int_{\Omega} (u^2 + \varepsilon)^{(p-2)/2} |\nabla u|^2 dx + \int_{\Gamma} \frac{\partial u}{\partial \nu_A} u_{\varepsilon}^* d\sigma$$

$$+ \lambda \int_{\Omega} (u^2 + \varepsilon)^{(p-2)/2} |u|^2 dx.$$
(2.3.1,7)

We then transform the boundary integral. We have

$$\int_{\Gamma} \frac{\partial u}{\partial \nu_{A}} u_{\varepsilon}^{*} d\sigma = \int_{\Gamma} \left( \frac{\partial u}{\partial \nu_{A}} + Pu \right) u_{\varepsilon}^{*} d\sigma - \int_{\Gamma} Pu u_{\varepsilon}^{*} d\sigma$$

and

$$\int_{\Gamma} Puu_{\varepsilon}^* d\sigma = \int_{\Gamma} (u^2 + \varepsilon)^{(p-2)/2} (Pu)u d\sigma$$

$$= \int_{\Gamma} (u^2 + \varepsilon)^{(p-2)/2} \frac{1}{2} Pu^2 d\sigma$$

$$= \frac{1}{p} \int_{\Gamma} P[(u^2 + \varepsilon)^{p/2}] d\sigma.$$

We use the following auxiliary lemma, which we shall prove later.

**Lemma 2.3.1.3** For all  $\varphi \in C^1(\bar{\Omega})$ , we have

$$\left| \int_{\Gamma} P\varphi \, d\sigma \right| \le C \int_{\Gamma} |\varphi| \, d\sigma. \tag{2.3.1.8}$$

Setting  $\varphi = (u^2 + \varepsilon)^{p/2}$ , we finally obtain

$$\left| \int_{\Gamma} Puu_{\varepsilon}^* d\sigma \right| \leq \frac{C}{p} \int_{\Gamma} (u^2 + \varepsilon)^{p/2} d\sigma.$$

We now take advantage of inequality (1,5,1,2). This leads to

$$\left| \int_{\Gamma} Puu_{\varepsilon}^* d\sigma \right| \leq \frac{CK}{p} \left[ \sqrt{\delta} \int_{\Omega} |\nabla (u^2 + \varepsilon)^{p/4}|^2 dx + \frac{1}{\sqrt{\delta}} \int_{\Omega} (u^2 + \varepsilon)^{p/2} dx \right]$$

for all  $\delta > 0$ . In other words, we have

$$\left| \int_{\Gamma} Puu_{\varepsilon}^* d\sigma \right| \leq \frac{CK}{p} \left[ \sqrt{\delta \frac{p^2}{4}} \int_{\Omega} (u^2 + \varepsilon)^{(p+2)/2} |\nabla u|^2 dx + \frac{1}{\sqrt{\delta}} \int_{\Omega} (u^2 + \varepsilon)^{p/2} dx \right]. \tag{2.3.1.9}$$

We can choose  $\delta$  such that  $(CKp/4) \sqrt{\delta} = \alpha'$  and summing up from (2,3,1,7) we obtain

$$\int_{\Omega} (Au + \lambda u) u_{\varepsilon}^* dx \ge \int_{\Gamma} \left( \frac{\partial u}{\partial \nu_{\Lambda}} + Pu \right) u_{\varepsilon}^* d\sigma + \lambda \int_{\Omega} (u^2 + \varepsilon)^{(p-2)/2} |u|^2 dx$$
$$- \frac{CK}{p \sqrt{\delta}} \int_{\Omega} (u^2 + \varepsilon)^{p/2} dx.$$

If we choose  $\beta$  large enough, this implies (2,3,1,5).

**Proof of Lemma 2.3.1.3** Using a partition of unity and local  $(C^{1,1})$  coordinates, it is enough to prove (2,3,1,8) when  $\Gamma$  is replaced by  $\mathbb{R}^{n-1}$ , P is a first-order operator with Lipschitz coefficients on  $\mathbb{R}^{n-1}$  and  $\varphi$  has compact support. Thus we have

$$\int_{\mathbb{R}^{n-1}} P\varphi \ dx = \sum_{k=1}^{n-1} \int_{\mathbb{R}^{n-1}} a_k D_k \varphi \ dx = -\int_{\mathbb{R}^{n-1}} \varphi \left\{ \sum_{k=1}^{n-1} D_k a_k \right\} dx$$

and (2,3,1,8) follows. We observe that the constant C depends only on bounds for the coefficients of P and their first derivatives.

**Lemma 2.3.1.4** Under the assumptions of Lemma 2.3.1.2, we have

$$\int_{\Omega} |u|^{p} dx \leq \frac{1}{\lambda - \beta} \left[ \left( \int_{\Omega} |Au + \lambda u|^{p} dx \right)^{1/p} \left( \int_{\Omega} |u|^{p} dx \right)^{1/q} + \left( \int_{\Gamma} \left| \gamma \left( \frac{\partial u}{\partial \nu_{A}} + Pu \right) \right|^{p} d\sigma \right)^{1/p} \left( \int_{\Gamma} |\gamma u|^{p} d\sigma \right)^{1/q} \right]$$
(2,3,1,10)

for all  $u \in W_p^2(\Omega)$ .

**Proof** We begin with  $u \in C^2(\bar{\Omega})$  and let  $\varepsilon \to 0$  in (2,3,1,5). It is obvious that  $u^*_{\varepsilon} \to u^*$  pointwise everywhere and that  $u^*_{\varepsilon}$  remains uniformly bounded in  $\bar{\Omega}$  when  $\varepsilon \to 0$ , because u is continuous in  $\bar{\Omega}$ . Consequently, by Lebesgue theorem we know that

$$u^*_{\epsilon} \rightarrow u^*$$

strongly in  $L_q(\Omega)$  and in  $L_q(\Gamma)$ . Thus from (2,3,1,5) we deduce that

$$\int_{\Omega} (Au + \lambda u)u^* dx \ge \int_{\Gamma} \left( \frac{\partial u}{\partial \nu_A} + Pu \right) u^* d\sigma + (\lambda - \beta) \int_{\Omega} uu^* dx.$$

Now applying Hölder's inequality, we obtain

$$\int_{\Omega} |u|^{p} dx \leq \frac{1}{\lambda - \beta} \left[ \left( \int_{\Omega} |Au + \lambda u|^{p} dx \right)^{1/p} \left( \int_{\Omega} |u|^{p} dx \right)^{1/q} + \left( \int_{\Gamma} \left| \frac{\partial u}{\partial \nu_{A}} + Pu \right|^{p} d\sigma \right)^{1/p} \left( \int_{\Gamma} |u|^{p} d\sigma \right)^{1/q} \right].$$

This is exactly (2,3,1,10) when  $u \in C^2(\bar{\Omega})$ . However, this inequality does not involve  $u^*$ , so that it is easily extended to all  $u \in W_p^2(\Omega)$  by density.

We are now able to prove

**Theorem 2.3.1.5** Let A and B satisfy the assumptions in Section 2.1; then there exists  $\lambda_0$  such that, for  $\lambda > \lambda_0$ :

$$||u||_{0,p,\Omega} \leq \frac{1}{\lambda - \lambda_0} ||Au + \lambda u||_{0,p,\Omega}$$
 (2,3,1,11)

for all  $u \in W_p^2(\Omega)$ , such that  $\gamma Bu = 0$ .

**Proof** We consider first the case when the order of B is one, i.e. d = 1. We observe that the boundary condition  $\gamma Bu = 0$  may be rewritten as  $\gamma(\partial u/\partial \nu_A + Pu) = 0$ , for some tangential operator P with Lipschitz coefficients. Indeed we have:

$$Bu = \sum_{i=1}^{n} b_i D_i u = b_{\nu} \frac{\partial u}{\partial \nu} + \mathbf{b}_T \cdot \nabla_T u$$

where  $b_{\nu}$  is the component of the vector  $\mathbf{b} = (b_1, \dots, b_n)$  in the direction of  $\mathbf{v}$  and  $\mathbf{b}_T$  is the projection of  $\mathbf{b}$  on the tangent hyperplane to  $\Gamma$ . We denote by  $\nabla_T$  the tangential gradient on  $\Gamma$ . In the same way, we have

$$\frac{\partial u}{\partial \nu_{\Delta}} = \sum_{i=1}^{n} c_{i} D_{i} u = c_{\nu} \frac{\partial u}{\partial \nu} + \mathbf{c}_{T} \cdot \nabla_{T} u$$

where  $c_i = \sum_{i=1}^n a_{ii} \nu^i$ .

We assumed that  $\Gamma$  is not characteristic for B and this means that  $b_{\nu}$  does not vanish on  $\Gamma$ . Consequently we have

$$\frac{c_{\nu}}{b_{\nu}}Bu = \frac{\partial u}{\partial \nu_{A}} - \mathbf{c}_{T} \cdot \nabla_{T}u + \frac{c_{\nu}}{b_{\nu}}\mathbf{b}_{T} \cdot \nabla_{T}u.$$

We define P by

$$Pu = \left(\frac{c_{\nu}}{b_{\nu}} \mathbf{b}_{T} - \mathbf{c}_{T}\right) \cdot \nabla_{T} u$$

and the boundary condition  $\gamma Bu = 0$  implies

$$\gamma \left( \frac{\partial u}{\partial \nu_{\Delta}} + Pu \right) = 0.$$

We observe the  $c_{\nu}$ ,  $b_{\nu}$ ,  $\mathbf{b}_{T}$ ,  $\mathbf{c}_{T}$  are all Lipschitz functions since  $a_{i,j}$  and  $b_{i}$  are so and  $\Gamma$  is of class  $C^{1,1}$  by assumption.

We now make use of inequality (2,3,1,10) and get the following:

$$\|u\|_{0,p,\Omega}^{p} \leq \frac{1}{\lambda - \beta} \|Au + \lambda u\|_{o,p,\Omega} \|u\|_{0,p,\Omega}^{p/q}.$$

Inequality (2,3,1,11) follows easily.

So far we have left out the case of a Dirichlet problem (i.e. B=1 and d=0). In that case (2,3,1,11) follows obviously from (2,3,1,10), with P=0, say, because  $\gamma u=0$  on  $\Gamma$ . Consequently (2,3,1,11) holds.

#### 2.3.2 An inequality in the half space

Here we consider a second-order, homogeneous, strongly elliptic operator L, with constant real coefficients

$$L = \sum_{j,k=1}^{n} l_{j,k} D_{j} D_{k}$$

together with a first-order, homogeneous differential operator M, with constant real coefficients

$$M=\sum_{j=1}^n m_j D_j.$$

We assume that the hyperplane  $x_n = 0$  is not characteristic for M. This means that  $m_n \neq 0$ . The strong ellipticity of -L means that there exists  $\mu > 0$  such that

$$\sum_{i,k=1}^{n} l_{i,k} \xi_i \xi_k \le -\mu |\xi|^2 \tag{2.3.2.1}$$

for all  $\xi \in \mathbb{R}^n$ . The corresponding boundary value problem in  $\mathbb{R}^n_+ = \{x \in \mathbb{R}^n \mid x_n > 0\}$  is

$$\begin{cases}
Lu = f & \text{in } \mathbb{R}^n_+ \\
\gamma_n Mu = g & \text{on } \mathbb{R}^{n-1}
\end{cases}$$
(2,3,2,2)

where  $y_n$  is the trace operator on  $x_n = 0$ .

The purpose of this subsection is to prove an estimate for a  $u \in W_p^2(\mathbb{R}_+^n)$  which is a solution of (2,3,2,2). Namely, we shall prove that there exists some constant C such that

$$||u||_{2,p,\mathbb{R}^n} \le C[||Lu||_{0,p,\mathbb{R}^n} + ||\gamma_n Mu||_{1-1/p,p,\mathbb{R}^{n-1}} + ||u||_{1,p,\mathbb{R}^n}]. \tag{2.3.2.3}$$

We shall also prove the corresponding estimate for the Dirichlet problem (i.e. when M is replaced by I). This is the first step of the proof of Agmon et al.'s inequality. The proof presented here is different.

We shall use two auxiliary results, one of which is the powerful  $L_p$ -multiplier theorem of Mih'lin (1956) (see also Hörmander (1960)). Here, we denote by  $\mathbb{R}_*^n$  the set  $\mathbb{R}^n \setminus \{0\}$ . (In the rest of this section, we allow our functions to be complex valued.)

**Theorem 2.3.2.1** Let  $a \in C^n(\mathbb{R}^n_*)$  be such that there exists a constant C with

$$|\xi|^{|\alpha|} |D^{\alpha}a(\xi)| \le C \tag{2.3.2.4}$$

for all  $\xi \in \mathbb{R}_{*}^{n}$  and  $|\alpha| \leq n$ . Then the operator

$$g \mapsto F^{-1}aFg$$

is continuous in  $L_p(\mathbb{R}^n)$  and there exists a function  $n, p \mapsto K(n, p)$  such that

$$||F^{-1}aFg||_{0,p,\mathbb{R}^n} \le K(n,p)C ||g||_{0,p,\mathbb{R}^n}$$
(2.3.2.5)

for all  $g \in L_p(\mathbb{R}^n)$  and 1 .

We emphasize the fact that K(n, p) blows up when  $p \to 1$  and when  $p \to \infty$ . The case p = 2 is useless since (2,3,2,5) holds with K(n, 2) = 1 and  $C = \max_{\mathbb{R}^n} |a|$ , by Plancherel's theorem.

#### Lemma 2.3.2.2 The mapping

$$\gamma_n^*: g \mapsto g \otimes \delta_n$$

where  $\delta_n$  denotes the Dirac measure in the variable  $x_n$ , is continuous from  $W_p^s(\mathbb{R}^{n-1})$  into  $W_p^{s+1/p-1}(\mathbb{R}^n)$  provided s < 0.

**Proof** This is a very simple consequence of Theorem 1.5.1.1 since  $\gamma_n^*$  is obviously the transposed operator of the trace operator  $\gamma_n$ .

We shall also use an elementary solution E for L+1, defined by

$$FE(\xi) = \left[ -\sum_{j,k,+1}^{n} l_{j,k} \xi_j \xi_k + 1 \right]^{-1}, \qquad \xi \in \mathbb{R}^n.$$

The assumption (2,3,2,1) implies the existence of a constant C such that

 $a = D^{\beta}FE$  fulfils (2,3,2,4) when  $|\beta| \le 2$ . Consequently the convolution operator by E maps  $L_n(\mathbb{R}^n)$  into  $W_n^2(\mathbb{R}^n)$ .

We now use the elementary solution for reducing the boundary value problem

$$\begin{cases} Lu + u = f & \text{in } \mathbb{R}^n_+ \\ \gamma_n Mu = g & \text{on } \mathbb{R}^{n-1} \end{cases}$$
 (2,3,2,6)

to an equation on  $\mathbb{R}^{n-1}$ . For that purpose we set

$$v = u - E * \tilde{f}. \tag{2.3.2.7}$$

We then have

$$\begin{cases}
Lv + v = 0 \\
\gamma_n Mv = h
\end{cases}$$
(2,3,2,8)

where  $h = g - \gamma_n ME * \tilde{f}$ . We now denote by  $\hat{\varphi}$  the partial Fourier transform of  $\varphi$ , in  $x_1, \ldots, x_{n-1}$  (or Fourier transform on  $\mathbb{R}^{n-1}$ ), i.e.,

$$\hat{\varphi}(\xi, x_n) = \frac{1}{(2\pi)^{(n-1)/2}} \int_{\mathbb{R}^{n-1}} e^{-ix' \cdot \xi} \varphi(x', x_n) dx'$$

where  $x' = (x_1, \dots, x_{n-1})$ . We use the same notation for the Fourier transform of a function defined on  $\mathbb{R}^{n-1}$ 

$$\hat{\psi}(\xi) = \frac{1}{(2\pi)^{(n-1)/2}} \int_{\mathbb{R}^{n-1}} e^{-ix \cdot \xi} \psi(x) \, dx.$$

It follows from (2,3,2,8) that

$$\begin{cases} l_{n,n}D_{n}^{2}\hat{v} + 2i\sum_{j=1}^{n-1}l_{n,j}\xi_{j}D_{n}\hat{v} + \left(1 - \sum_{j,k=1}^{n-1}l_{j,k}\xi_{j}\xi_{k}\right)\hat{v} = 0, & x_{n} > 0\\ m_{n}D_{n}\hat{v} + i\sum_{j=1}^{n-1}m_{j}\xi_{j}\hat{v} = \hat{h}, & x_{n} = 0. \end{cases}$$
(2,3,2,9)

We now solve the differential equation in (2,3,2,9). The corresponding characteristic equation is

$$l_{n,n}\tau^2 + 2i\sum_{j=1}^{n-1} l_{n,j}\tau\xi_j + \left(1 - \sum_{j,k=1}^{n-1} l_{j,k}\xi_j\xi_k\right) = 0.$$
 (2,3,2,10)

If we set  $\zeta = (\xi_1, \dots, \xi_{n-1}, \tau/i)$ , this is equivalent to

$$1 - \sum_{j,k=1}^{n} l_{j,k} \zeta_{j} \zeta_{k} = 0.$$

This equation has no real solution, due to the strong ellipticity of -L (see (2,3,2,1)). Furthermore, since the  $l_{j,k} \cdot s$  are real, the solutions are conju-

gates. It follows that (2,3,2,10) has two symmetric, nonimaginary solutions in  $\tau$ , which are functions of  $\xi$ . We denote them by

$$p_{+}(\xi)$$

with Re  $p_+(\xi) > 0$  and Re  $p_-(\xi) < 0$ . It follows that  $\hat{v}$  is, for almost every  $\xi$ , a linear combination of the functions

$$\exp x_n p_+(\xi), \qquad \exp x_n p_-(\xi).$$

However, due to the assumption that  $\hat{v}$  is a Fourier transform, the fast increasing component has to be excluded.

**Lemma 2.3.2.3** Let  $v \in H^2(\mathbb{R}^n_+)^{\dagger}$  be a solution of

$$Lv + v = 0$$
 in  $\mathbb{R}^n_+$ 

then

$$\hat{v}(\xi, x_n) = \widehat{\gamma_n v}(\xi) \exp x_n p_-(\xi), \qquad x_n > 0$$

for almost every  $\xi \in \mathbb{R}^{n-1}$ .

Proof At first glance we have

$$\hat{v}(\xi, x_n) = \alpha(\xi) \exp x_n p_-(\xi) + \beta(\xi) \exp x_n p_+(\xi), \qquad x_n > 0$$

for almost every  $\xi$ , where  $\alpha$  and  $\beta$  are some functions. From this, it follows that

$$\begin{cases} \alpha + \beta = \widehat{\gamma_n v} & \text{a.e.} \\ p_- \alpha + p_+ \beta = \widehat{\gamma_n D_n v} & \text{a.e.} \end{cases}$$

and this shows that  $\alpha$  and  $\beta$  are measurable functions since  $\widehat{\gamma_n v}$  and  $\widehat{\gamma_n D_n v}$  are square integrable measurable functions.

Then, from the fact that v belongs to  $L_2(\mathbb{R}^n_+)$  we deduce that  $\hat{v}$  also belongs to  $L_2(\mathbb{R}^n_+)$  (in the variables  $(\xi, x_n)$ ) and consequently  $\beta = 0$  a.e. It follows that  $\alpha = \widehat{\gamma_n v}$ .

An immediate consequence of (2,3,2,10) is that

$$\widehat{\gamma_n D_n v} = p_- \widehat{\gamma_n v}$$
 a.e.

and thus the boundary condition in (2,3,2,8) may be rewritten as follows, where  $k_0 = \gamma_n v$ :

$$\left(m_n p_- + \sum_{i=1}^{n-1} i m_i \xi_i\right) \hat{k}_0 = \hat{h}. \tag{2,3,2,11}$$

† It is enough to consider here the case p = 2, since later on we shall take advantage of the density of  $W_p^2(\mathbb{R}_+^n) \cap H^2(\mathbb{R}_+^n)$  in  $W_p^2(\mathbb{R}_+^n)$ .

This is the equation on the boundary, which is equivalent to problem (2,3,2,9).

The equation (2,3,2,11) is obviously uniquely solvable since the function  $\xi \mapsto (m_n p_- + \sum_{j=1}^{n-1} i m_j \xi_j)$  does not vanish on  $\mathbb{R}^n$ . Indeed the  $m_j$  are all real and Re  $p_-(\xi) < 0$  everywhere. This leads to the representation formula in Lemma 2.3.2.4.

**Lemma 2.3.2.4** Let  $u \in H^2(\mathbb{R}^n_+)$  be the solution of problem (2,3,2,6); then we have

$$u = E * \left( \tilde{f} + l_{n,n} k_0 \otimes \delta'_n + \left[ l_{n,n} k_1 + 2 \sum_{j=1}^{n-1} l_{n,j} D_j k_0 \right] \otimes \delta_n \right), \qquad (2,3,2,12)$$

where  $\hat{k}_0 = (m_n p_- + \sum_{i=1}^{n-1} i m_i \xi_i)^{-1} \hat{h}$ ,  $\hat{k}_1 = p_- \hat{k}_0$  and  $h = g - \gamma_n ME * \tilde{f}$ .

**Proof** We first observe that we can apply Lemma 2.3.2.3 to  $v = u - E * \tilde{f}$ , since  $f \in L_2(\mathbb{R}^n_+)$  and consequently  $E * \tilde{f} \in H^2(\mathbb{R}^n_+)$ .

Let us consider the equation of  $\tilde{v}$  (again  $\tilde{u}$  is the extension of u defined by  $\tilde{u} = 0$  for  $x_n < 0$ ):

$$\begin{split} L\tilde{v} + \tilde{v} &= \sum_{i,k=1}^{n} l_{i,k} D_{i} D_{k} \tilde{v} + \tilde{v} \\ &= l_{n,n} D_{n}^{2} \tilde{v} + 2 \sum_{i=1}^{n-1} l_{i,n} D_{i} D_{n} \tilde{v} + \sum_{i,k=1}^{n-1} l_{i,k} D_{i} D_{k} \tilde{v} + \tilde{v} \\ &= l_{n,n} (\gamma_{n} v \otimes \delta'_{n} + \gamma_{n} D_{n} v \otimes \delta_{n}) + 2 \sum_{i=1}^{n-1} l_{i,n} D_{i} \gamma_{n} v \otimes \delta_{n}. \end{split}$$

Since  $\tilde{v}$  is a tempered distribution we check by Fourier transform that

$$\tilde{v} = E * \left( l_{n,n} [\gamma_n v \otimes \delta'_n + \gamma_n D_n v \otimes \delta_n] + 2 \sum_{i=1}^{n-1} l_{i,n} D_i \gamma_n v \otimes \delta_n \right).$$

Then we derive  $k_0 = \gamma_n v$  from (2,3,2,11) and substitute  $\gamma_n D_n v$  by  $k_1$ , where  $\hat{k}_1 = p_- \hat{k}_0$  by Lemma 2.3,2,3.

The representation formula (2,3,2,12) is the key tool for proving the estimate (2,3,2,3). We need two more auxiliary lemmas.

**Lemma 2.3.2.5** Let a fulfil the assumptions in Theorem 2.3.2.1. Then the operator

$$M_a: g \mapsto F^{-1}aFg$$

is continuous in  $W_p^s(\mathbb{R}^n)$  for all  $s \in \mathbb{R}$ .

This result can be found in Triebel (1978), however, we can also obtain it as a consequence of Theorem 2.3.2.1.

Proof of Lemma 2.3.2.5 Applying Theorem 2.3.2.1 with a replaced by

$$\xi \mapsto (1+|\xi|^2)^{m/2}a(\xi)(1+|\xi|^2)^{-m/2}$$

and remembering Definition 1.3.1.3, we check that  $M_a$  is continuous in  $H_p^m(\mathbb{R}^n)$  for all  $m \in \mathbb{Z}$ . Now,  $H_p^m(\mathbb{R}^n)$  is the same space as  $W_p^m(\mathbb{R}^n)$ . The result stated in Lemma 2.3.2.5 for a non-integer s, follows by the interpolation Theorem 1.4.3.5.

#### Lemma 2.3.2.6 The functions

$$\xi \mapsto |\xi|^{|\alpha|-1} D^{\alpha} p_{\pm}(\xi)$$

are bounded on  $\mathbb{R}^{n-1}$  for all  $\alpha$ .

**Proof** This is easily checked on the explicit formula for the roots of (2,3,2,10)

$$p_{\pm}(\xi) = l_{n,n}^{-1} \left\{ -i \sum_{j=1}^{n-1} l_{n,j} \xi_j \mp \left[ -\left( \sum_{j=1}^{n-1} l_{n,j} \xi_j \right)^2 - l_{n,n} \left( 1 - \sum_{j,k=1}^{n-1} l_{j,k} \xi_j \xi_k \right) \right]^{1/2} \right\}.$$

It follows from (2,3,2,1) that  $l_{n,n} < 0$  and that the polynomial in the bracket is always strictly positive.

We are now able to prove the basic estimate.

**Theorem 2.3.2.7** Let -L be a homogeneous strongly elliptic second-order operator with constant coefficients and let M be a homogeneous first-order operator with constant coefficients. Assume that  $x_n = 0$  is not characteristic for M. Then there exists a constant C such that (2.3,2,3) holds for all  $u \in W_p^2(\mathbb{R}_+^n)$ .

**Proof** It is enough to prove inequality (2,3,2,3) for  $u \in H^2(\mathbb{R}^n_+) \cap W^2_p(\mathbb{R}^n_+)$ , since this is a dense subspace of  $W^2_p(\mathbb{R}^n_+)$ . This allows one to use the representation formula (2,3,2,12) for u. We shall consider each term separately.

We start from  $f \in L_p(\mathbb{R}^n_+)$  and  $h \in W_p^{1-1/p}(\mathbb{R}^{n-1})$ . Since E maps  $L_p(\mathbb{R}^n)$  into  $W_p^2(\mathbb{R}^n)$ , we have

$$||E * \tilde{f}||_{2,p,\mathbb{R}^n} \le C_1 ||f||_{0,p,\mathbb{R}^n}. \tag{2.3.2.13}$$

Then let us set

$$b(\xi) = \left(m_n p_{-}(\xi) + i \sum_{j=1}^{n-1} m_j \xi_j\right)^{-1}.$$

It follows from Lemma 2.3.2.6 that b,  $\xi_i b$ ,  $1 \le j \le n-1$  and  $p_- b$ , all fulfil (2,3,2,4). Consequently the mappings

$$h \mapsto k_0 = F^{-1}bFh$$

$$h \mapsto D_j k_0 = F^{-1}i\xi_j bFh, \qquad 1 \le j \le n-1$$

$$h \mapsto k_1 = F^{-1}p_-bFh$$

are continuous operators in  $W_p^{1-1/p}(\mathbb{R}^{n-1})$  owing to Lemma 2.3.2.5. Thus we have

$$||k_0||_{2^{-1/p,p,\mathbb{R}^{n-1}}} + ||k_1||_{1-1/p,p,\mathbb{R}^{n-1}} \le C_2 ||h||_{1-1/p,p,\mathbb{R}^{n-1}}. \tag{2.3.2.14}$$

From this we deduce that

$$\zeta = l_{n,n}k_1 + 2\sum_{j=1}^{n-1} l_{n,j}D_jk_0 \in W_p^{1-1/p}(\mathbb{R}^{n-1}).$$

Then  $\zeta \in W_p^{1-1/p}(\mathbb{R}^{n-1})$  and  $D_j \zeta \in W_p^{-1/p}(\mathbb{R}^{n-1})$ ,  $1 \le j \le n-1$ . Lemma 2.3.2.2 implies that

$$\zeta \otimes \delta_n \in W_p^{-1}(\mathbb{R}^n)$$
 and  $D_i \zeta \otimes \delta_n \in W_p^{-1}(\mathbb{R}^n)$ ,  $1 \le j \le n-1$ .

Consequently

$$E * (\zeta \otimes \delta_n) \in W_n^1(\mathbb{R}^n)$$

$$D_i E * (\zeta \otimes \delta_n) = E * (D_i \zeta \otimes \delta_n) \in W_p^1(\mathbb{R}^n), \quad 1 \le j \le n-1$$

by Lemma 2.3.2.5. In other words, we have shown that

$$E * (\zeta \otimes \delta_n) \in L_p(\mathbb{R}^n)$$

$$D_i E * (\zeta \otimes \delta_n) \in L_p(\mathbb{R}^n), \qquad 1 \leq j \leq n$$

$$D_j D_k E * (\zeta \otimes \delta_n) \in L_p(\mathbb{R}^n), \qquad 2 \leq j + k \leq 2n - 1.$$

We just need to check that  $D_n^2 E * (\zeta \otimes \delta_n) \in L_p(\mathbb{R}_+^n)$  in order to prove that  $E * (\zeta \otimes \delta_n) \in W_p^2(\mathbb{R}_+^n)$ . This is achieved by using the fact that E is an elementary solution for L+1. This implies that in  $\mathbb{R}_+^n$  we have

$$D_n^2 E * (\zeta \otimes \delta_n) = -\frac{1}{l_{n,n}} \left[ E * (\zeta \otimes \delta_n) + \sum_{j+k \leq 2n-1} l_{j,k} D_j D_k E * (\zeta \otimes \delta_n) \right].$$

Summing up, we have shown that

$$E * \left[ l_{n,n}k_1 + 2 \sum_{i=1}^{n-1} l_{n,i}D_i k_0 \right] \otimes \delta_n \in W_p^2(\mathbb{R}^n_+)$$

and in addition, we have

$$\left\| E * \left[ l_{n,n} k_1 + 2 \sum_{j=1}^{n-1} l_{n,j} D_j k_0 \right] \otimes \delta_n \right\|_{2,p,\mathbb{R}^n}$$

$$\leq C_3 \left[ \| k_0 \|_{2^{-1/p,p,\mathbb{R}^{n-1}}} + \| k_1 \|_{1+1/p,p,\mathbb{R}^{n-1}} \right]$$
(2.3.2.15)

owing to the continuity of all the involved operators.

Finally, let us consider  $E*(k_0 \otimes \delta'_n)$ . We start from  $k_0 \in W_p^{2-1/p}(\mathbb{R}^{n-1})$ , so that  $k_0 \in W_p^{-1/p}(\mathbb{R}^{n-1})$ ,  $D_j k_0 \in W_p^{-1/p}(\mathbb{R}^{n-1})$ ,  $1 \le j \le n-1$  and  $D_j D_k k_0 \in W_p^{-1/p}(\mathbb{R}^{n-1})$ ,  $1 \le j$ ,  $k \le n-1$ . From Lemmas 2.3.2.2 and 2.3.2.5 it follows that

$$E * (k_0 \otimes \delta'_n) \in L_p(\mathbb{R}^n)$$

$$D_j E * (k_0 \otimes \delta'_n) \in L_p(\mathbb{R}^n), \qquad 1 \leq j \leq n-1$$

$$D_j D_k E * (k_0 \otimes \delta'_n) \in L_p(\mathbb{R}^n), \qquad 1 \leq j, k \leq n-1.$$

Then we write that

$$D_n E * (k_0 \otimes \delta'_n) = D_n^2 E * (k_0 \otimes \delta_n)$$

$$= -\frac{1}{l_{n,n}} \left[ E * (k_0 \otimes \delta_n) + \sum_{j+k \leq 2n-1} l_{j,k} D_j D_k E * (k_0 \otimes \delta_n) \right]$$

since E is an elementary solution for L+1. It follows that in  $\mathbb{R}^n_+$ , we have

$$D_{n}E * (k_{0} \otimes \delta'_{n}) = -\frac{1}{l_{n,n}} \left[ E * (k_{0} \otimes \delta_{n}) + \sum_{j,k=1}^{n-1} l_{j,k}E * (D_{j}D_{k}k_{0}) \otimes \delta_{n} + 2 \sum_{j=1}^{n-1} l_{j,n}E * (D_{j}k_{0} \otimes \delta'_{n}) \right]$$

and that

$$D_{i}D_{n}E * (k_{0} \otimes \delta'_{n}) = -\frac{1}{l_{n,n}} \left[ E * (D_{i}k_{0} \otimes \delta_{n}) + \sum_{j,k=1}^{n-1} l_{j,k}D_{i}E * (D_{j}D_{k}k_{0}) \otimes \delta_{n} + 2\sum_{j=1}^{n-1} l_{j,n}E * (D_{i}D_{j}k_{0} \otimes \delta'_{n}) \right], \qquad 1 \leq i \leq n-1.$$

Again applying Lemmas 2.3.2.2 and 2.3.2.5, we show that

$$D_n E * (k_0 \otimes \delta'_n) \in L_p(\mathbb{R}^n_+)$$

$$D_i D_n E * (k_0 \otimes \delta_n') \in L_n(\mathbb{R}_+^n), \qquad 1 \leq i \leq n-1.$$

The only derivative missing for proving that  $E*(k_0 \otimes \delta'_n) \in W^2_p(\mathbb{R}^n_+)$  is  $D^2_n E*(k_0 \otimes \delta'_n)$ . Using the property of the elementary solution E, we derive this last fact as we did for  $D^2_n E*(\zeta \otimes \delta_n)$ . Summing up, we have proved that

$$E * (k_0 \otimes \delta'_n) \in W^2_p(\mathbb{R}^n_+)$$

and in addition,

$$||E * (k_0 \otimes \delta'_n)||_{2,p,\mathbb{R}^n_+} \le C_4 ||k_0||_{2-1/p,p,\mathbb{R}^{n-1}}.$$
 (2,3,2,16)

Putting together identity (2,3,2,12) with inequalities (2,3,2,13) to (2,3,2,16), we obtain the existence of a constant C such that

$$||u||_{2,p,\mathbb{R}^n_+} \le C[||Lu+u||_{0,p,\mathbb{R}^n_+} + ||\gamma_n Mu||_{1-1/p,p,\mathbb{R}^{n-1}}]$$

for all  $u \in W_p^2(\mathbb{R}_+^n) \cap H^2(\mathbb{R}_+^n)$ . By density, the same is true for all  $u \in W_p^2(\mathbb{R}_+^n)$  and inequality (2,3,2,3) follows obviously. This completes the proof of Theorem 2.3.2.7.

Remark 2.3.2.8 Inspection shows that the constant C (deduced from  $C_1$  to  $C_4$ ) is bounded by a continuous function of the  $l_{i,k}$  and the  $m_i$ .

The similar statement concerning Dirichlet's problem is this.

**Theorem 2.3.2.9** Let -L be a homogeneous strongly elliptic second-order operator with constant coefficients. Then there exists a constant C such that

$$||u||_{2,p,\mathbb{R}^n_+} \le C[||Lu||_{0,p,\mathbb{R}^n_+} + ||\gamma_n u||_{2-1/p,p,\mathbb{R}^{n-1}} + ||u||_{1,p,\mathbb{R}^n_+}]$$
(2,3,2,17)
$$for \ all \ u \in W^2_p(\mathbb{R}^n_+).$$

**Proof** We use here the same representation formula (2,3,2,12) but with  $k_0 = h = g - \gamma_n E * \tilde{f}$  and  $\hat{k}_1 = p_- \hat{k}_0$ . The rest of the proof is exactly similar to that of Theorem 2.3.2.7.

#### 2.3.3 A general a priori estimate

We consider again the general operators A and B of Section 2.1, in a general bounded domain  $\Omega$  with a  $C^{1,1}$  boundary. We shall now extend inequality (2,3,2,3) to this general case. Namely, we shall prove that there exists a constant C such that

$$||u||_{2,p,\Omega} \le C[||Au||_{0,p,\Omega} + ||\gamma Bu||_{2-d-1/p,p,\Gamma} + ||u||_{1,p,\Omega}]. \tag{2.3.3.1}$$

Then we shall combine inequalities (2,3,1,1) and (2,3,3,1) to obtain the basic inequality for the remaining sections of this chapter.

Inequality (2,3,3,1) is very flexible because of the norm of u in  $W_p^1(\Omega)$  that appears on the right-hand side. Indeed, it allows us to 'localize' the inequality. This property is rigorously stated as follows.

**Lemma 2.3.3.1** Assume that each point  $x \in \overline{\Omega}$  has a neighbourhood  $V_x$  such that (2,3,3,1) holds for all the functions u in  $W^2_p(\Omega)$  which have their support in  $V_x$ . Then (2,3,3,1) holds for all  $u \in W^2_p(\Omega)$  (with possibly another constant).

**Proof** The compactness of  $\bar{\Omega}$  allows us to find a finite number of points  $x_1, \ldots, x_N$  in  $\bar{\Omega}$ , such that  $\bar{\Omega}$  is covered by the interiors of  $V_x$ ,  $1 \le j \le N$ .

Then we choose a partition of unity corresponding to this covering. Namely we assume that

$$1 = \sum_{i=1}^{N} \theta_i$$

on  $\bar{\Omega}$ , where  $\theta_j \in \mathcal{D}(\bar{\Omega})$  and the support of  $\theta_j$  is contained in the interior of  $V_x$ ,  $1 \le j \le N$ .

The assumption of Lemma 2.3.3.1 is that (2,3,3,1) holds in particular for all the  $\theta_i u$ . It follows that

$$||u||_{2,p,\Omega} \leq \sum_{j=1}^{N} ||\theta_{j}u||_{2,p,\Omega}$$

$$\leq C \sum_{j=1}^{N} [||A(\theta_{j}u)||_{0,p,\Omega} + ||\gamma B(\theta_{j}u)||_{2-d-1/p,p,\Gamma} + ||\theta_{j}u||_{1,p,\Omega}]$$

$$\leq C_{1}[||Au||_{0,p,\Omega} + ||\gamma Bu||_{2-d-1/p,p,\Gamma} + ||u||_{1,p,\Omega}]$$

$$+ C \sum_{j=1}^{N} [||[A;\theta_{j}]u||_{0,p,\Omega} + ||\gamma [B;\theta_{j}]u||_{2-d-1/p,p,\Gamma}]. \qquad (2,3,3,2)$$

Here  $[A; \theta_i]$  is a first-order operator with continuous coefficients so that there exists  $C_2$  such that

$$\|[A; \theta_i]u\|_{0,p,\Omega} \le C_2 \|u\|_{1,p,\Omega}, \quad 1 \le j \le N$$
 (2,3,3,3)

for all  $u \in W_p^2(\Omega)$ . The same way,  $[B; \theta_i]$  is either 0 when d = 0 (i.e. B = I) or the multiplication by a Lipschitz-continuous function when d = 1. In both cases there exists  $C_3$  such that

$$\|\gamma[B; \theta_j]u\|_{2-d-1/p, p, \Gamma} \le C_3 \|u\|_{1, p, \Omega}, \qquad 1 \le j \le N$$
 (2,3,3,4)

for all  $u \in W_p^2(\Omega)$ . Inequality (2,3,3,1) follows from (2,3,3,2), (2,3,3,3) and (2,3,3,4) by addition.

We shall now prove inequality (2,3,3,1).

**Theorem 2.3.3.2** Let A and B fulfil the assumptions in Section 2.1; then there exists a constant C such that (2,3,3,1) holds for all  $u \in W_p^2(\Omega)$ .

Taking advantage of Lemma 2.3.3.1 we shall restrict ourselves to proving inequality (2,3,3,1) in those two particular cases.

Case (a) the support of u is compact in  $\Omega$ .

Case (b) the support of u is contained in  $\Phi(V)$  where V is an open neighbourhood of O and  $\Phi$  is a  $C^{1,1}$  diffeomorphism of V onto  $\Phi(V)$  such that

$$\Phi^{-1}(\Omega \cap \Phi(V)) = U = \mathbb{R}^n_+ \cap V.$$

We observe that the norms involved in (2,3,3,1) are invariant under C' - I changes of coordinates. Furthermore the properties of A and B are also invariant under C' - ' changes of coordinates. That is why we shall consider u ° 4) instead of u. This reduces the proof to the particular case where the intersection of the support of u with I' is contained in {xi, = 0}.

The case (a) is solved with the help of this lemma.

*Lemma 2.3.3.3 For all* y E (2, *there* exists a *neighbourhood V of y* in f2, such that *(2,3,3,1) holds for all u E* W' ((2), whose *support is contained in* V.

*Proof* We use the famous perturbation argument known as Korn's procedure. Freezing the coefficients of A at y, we obtain an operator with constant coefficients

$$L = \sum_{i,j=1}^{n} l_{i,j} D_i D_j,$$

where l<sup>i</sup> , <sup>j</sup> = a<sup>i</sup>\_ <sup>j</sup>(y), which satisfies the assumptions of Section 2.3.2. We then observe that

$$Lu + u = Au - \left[ \sum_{i,j=1}^{n} D_i(a_{i,j} - l_{i,j}) D_j u - u \right]$$

in (2. If we denote by ai any Lipschitz functions defined everywhere, such that ai.j = a<sup>i</sup> ,<sup>j</sup> on (2, we have

$$L\tilde{u} + \tilde{u} = \widetilde{Au} - \left[\sum_{i,j=1}^{n} (\alpha_{i,j} - l_{i,j}) \widetilde{D_i D_j u} + \sum_{i,j=1}^{n} (D_i \alpha_{i,j}) \widetilde{D_j u} - \tilde{u}\right].$$

Now we assume that the support of u is contained in V such that V c (2. Using the elementary solution E introduced in Section 2.3.2, we obtain

$$\widetilde{u} = E * A\widetilde{u} - E * \left[ \sum_{i,j=1}^{n} (a_{i,j} - l_{i,j}) \widetilde{D_i D_j u} + \sum_{i,j=1}^{n} (D_i \alpha_{i,j}) \widetilde{D_j u} - \widetilde{u} \right].$$

Since E \* is a linear continuous map from L^, (E ") into W2((l^" ), it follows that

$$||u||_{2,p,\Omega} \leq C \left[ ||Au||_{0,p,\Omega} + \sum_{i,j=1}^{n} ||(a_{i,j} - l_{i,j})D_{i}D_{j}u||_{0,p,\Omega} \right] + C_{1} ||u||_{1,p,\Omega}.$$

Let us now call b the diameter of V and K a bound for the Lipschitz constants of all the ai.; in n. We then have

$$||u||_{2,p,\Omega} \le C[||Au||_{0,p,\Omega} + n^2 K\delta ||u||_{2,p,\Omega}] + C_1 ||u||_{1,p,\Omega}.$$

We conclude by choosing b small enough; indeed, if we assume that b is

less than or equal to  $1/2Cn^2K$ , we have

$$||u||_{2,p,\Omega} \le 2C ||Au||_{0,p,\Omega} + 2C_1 ||u||_{1,p,\Omega}.$$

This is exactly inequality (2,3,3,1) for u, since the support of u is contained in  $V \subset \Omega$  and consequently  $\gamma B u = 0$ . The proof of Lemma 2.3.3.3 is complete.

Let us now consider the case (b). It is solved with the help of this last lemma.

**Lemma 2.3.3.4** Let  $y \in \Gamma$  have a neighbourhood W in  $\Gamma$ , contained in the hyperplane  $\{x_n = 0\}$ . Then there exists a neighbourhood U of y in  $\overline{\Omega}$  such that (2,3,3,1) holds for all  $u \in W_p^2(\Omega)$ , whose support is contained in U.

**Proof** We shall use the same perturbation argument as in the proof of the previous lemma. We freeze the coefficients of A and B at y and obtain operators with constant coefficients:

$$L = \sum_{i,j=1}^{n} l_{i,j} D_i D_j$$

$$M = \text{either } I \text{ or } \sum_{j=1}^{n} m_j D_j$$

where  $l_{i,j} = a_{i,j}(y)$  and  $m_j = b_j(y)$  (when d = 1). These operators satisfy the assumptions of Section 2.3.2.

We start with an open neighbourhood U of y in  $\bar{\Omega}$  such that  $U \cap \Gamma \subset W$ , and we assume that the support of u is contained in U. We then have

$$Lu = Au - \left[ \sum_{i,j=1}^{n} D_{i}(a_{i,j} - l_{i,j}) D_{i}u \right]$$

in  $U \cap \Omega$  and

$$\gamma_n M u = \gamma_n B u - \gamma_n \left[ \sum_{j=1}^n (b_j - m_j) D_j u \right]$$

in W if d=1, while  $\gamma_n u = \gamma_n B u$  if d=0. We again denote by  $\alpha_{i,j}$  (respectively  $\beta_j$ ) any Lipshitz functions defined everywhere, such that  $\alpha_{i,j} = a_{i,j}$  in  $\bar{\Omega}$  (respectively  $\beta_j = b_j$  in  $\bar{\Omega}$ ). We have

$$L\widetilde{u} = \widetilde{Au} - \left[ \sum_{i,j=1}^{n} (\alpha_{i,j} - l_{i,j}) \widetilde{D_i D_j u} + \sum_{i,j=1}^{n} (D_i \alpha_{i,j}) \widetilde{D_j u} \right]$$

in  $\mathbb{R}^n_+$  and

$$\gamma_n M \widetilde{u} = \gamma_n B u - \gamma_n \left[ \sum_{j=1}^n (\beta_j - m_j) \widetilde{D_j u} \right]$$

on  $\{x_n = 0\}$  if d = 1, while  $\gamma_n \tilde{u} = \gamma_n \widetilde{Bu}$  if d = 0. Since  $\tilde{u} \in W_p^2(\mathbb{R}_+^n)$  we can use estimate (2,3,2,3) proved in Theorems 2.3.2.7 for d = 1 and 2.3.2.9 for d = 0. It follows that

$$||u||_{2,p,\Omega} = C \left\{ ||Au||_{0,p,\Omega} + \sum_{i,j=1}^{n} ||(a_{i,j} - l_{i,j})D_{i}D_{j}u||_{0,p,\Omega} + ||\gamma Bu||_{2-d-1/p,p,\Gamma} + \sum_{i=1}^{n} ||(b_{i} - m_{i})D_{j}u||_{2-d-1/p,p,\Gamma} \right\} + C_{1} ||u||_{1,p,\Omega}$$

when d=1 (the additional boundary term  $\sum_{j=1}^{n} ||(b_j-m_j)D_ju||_{2+d-1/p,p,\Gamma}$  does not appear when d=0).

Let us again denote by  $\delta$  a bound for the diameter of U and by K a bound for the Lipschitz constants of all the  $a_{i,j}$  and  $b_{j}$ . It follows that

$$||u||_{2,p,\Omega} \le C\{||\Lambda u||_{0,p,\Omega} + ||\gamma B u||_{2-d-1/p,p,I}\} + C_1 ||u||_{1,p,\Omega}$$

$$+ n^2 KC\delta ||u||_{2,p,\Omega} + \sum_{j=1}^n C_2 ||(b_j - m_j)D_j u||_{1,p,\Omega}$$
(2,3,3,5)

by the trace theorem (Section 1.5.1). Let us consider separately the last term of this inequality. We have

$$||(b_{i} - m_{i})D_{i}u||_{1,p,\Omega}^{p} = \sum_{i=1}^{n} ||D_{i}(b_{i} - m_{i})D_{i}u||_{0,p,\Omega}^{p} + ||(b_{i} - m_{i})D_{i}u||_{0,p,\Omega}^{p}$$

$$\leq (nK\delta)^{p} ||u||_{2,p,\Omega}^{p} + C_{3} ||u||_{1,p,\Omega}^{p}.$$
(2,3,3,6)

From (2,3,3,5) and (2,3,3,6) we deduce that

$$||u||_{2,p,\Omega} \le C\{||Au||_{0,p,\Omega} + ||\gamma Bu||_{2-d-1/p,p,\Gamma}\} + C_4 ||u||_{1,p,\Omega} + \{n^2C + nC_5\}K\delta ||u||_{2,p,\Omega}.$$

Choosing  $\delta$  small enough so that  $\{n^2C + nC_5\}K\delta \leq \frac{1}{2}$ , we obtain finally

$$||u||_{2,p,\Omega} \le 2C\{||Au||_{0,p,\Omega} + ||\gamma Bu||_{2-d-1/p,p,\Gamma}\} + 2C_4||u||_{1,p,\Omega}.$$

This is inequality (2,3,3,1).

Proof of Theorem 2.3.3.2 We apply Lemma 2.3.3.1. The existence of  $V_x$  follows from Lemma 2.3.3.3 when  $x \in \Omega$  while it follows from Lemma 2.3.3.4 after change of coordinates, when  $x \in \Gamma$ . In this last case we assume at once that  $V_x \subset \Phi(V)$ , where  $(V, \Phi)$  is a map of the manifold  $\bar{\Omega}$ , near x (see notation above). This allows us to 'flatten' the boundary  $\Gamma$ , near x, by replacing u by  $u \circ \Phi$ .

Remark 2.3.3.5 Actually we have proved a little more than Theorem 2.3.3.2 and this will be useful in the next subsection. In the proof of Lemma 2.3.3.1, it is enough to cover the support of u by the interiors of

*<sup>V</sup>r., 1 \_ j = N.* Consequently we can release the assumptions on *(.* Let us assume that ,fl is a (possibly unbounded) open subset of R" with a C" <sup>1</sup> boundary. Then for each compact subset K of D, there exists a constant C (depending on K) such that inequality (2,3,3,1) holds for all u E Wp(Q), with support in K.

We are now able to perform the final step of our search for *a priori* estimates.

*Theorem 2.3.3.6 Let A and B f ul fil* the assum*ptions in Section 2.1, then there* exist *C and A0* such that

$$||u||_{2,p,\Omega} \le C[||Au + \lambda u||_{0,p,\Omega} + ||\gamma Bu||_{2-d-1/p,p,\Gamma}]$$
(2,3,3,7)

*for* all *u E* Wp(,l) *and A* > A<sup>0</sup> .

*Proof* We first improve inequality (2,3,3,1), using Theorem 1.4.3.3. We have

$$\|u\|_{1,p,\Omega} \le \varepsilon \|u\|_{2,p,\Omega} + \frac{K}{\varepsilon} \|u\|_{0,p,\Omega}$$

$$(2,3,3,8)$$

for all u e W(Q) and e >0. Choosing r >0 small enough and substituting (2,3,3,8) in (2,3,3,1) we obtain:

$$||u||_{2,p,\Omega} \leq C_{1}[||Au||_{0,p,\Omega} + ||\gamma Bu||_{2-d-1/p,p,\Gamma} + ||u||_{0,p,\Omega}]$$

$$\leq C_{1}[||Au + \lambda u||_{0,p,\Omega} + ||\gamma Bu||_{2-d-1/p,p,\Gamma} + (1+\lambda) ||u||_{0,p,\Omega}].$$
(2,3,3,9)

We now take advantage of (2,3,1,11). We have

$$||u||_{0,p,\Omega} \leq \frac{1}{\lambda - \lambda_0} ||Au + \lambda u||_{0,p,\Omega}$$

for u E W(f2) such that yBu = 0. From (2,3,3,9) it follows that

$$||u||_{2,p,\Omega} \le C_1 \left(1 + \frac{1+\lambda}{\lambda - \lambda_0}\right) ||Au + \lambda u||_{0,p,\Omega} = C_2 ||Au + \lambda u||_{0,p,\Omega}.$$

This is exactly (2,3,3,7) in the particular case where yBu = 0.

Let us now consider the general case. From Theorem 1.6.1.3 we know that there exists a linear continuous operator R from Wp-d- 1/p(F) into *W(f2)* such that

$$\gamma BRg = g$$

for all g E *Wp-d-' /p(P).* We set *v = u - RyyBu.* It is clear that v E W(Q)

and that  $\gamma Bv = 0$  so that (2,3,3,7) holds for v. It follows that

$$\begin{aligned} \|u\|_{2,p,\Omega} &\leq \|v\|_{2,p,\Omega} + \|R\gamma Bu\|_{2,p,\Omega} \\ &\leq C_2 \|Av + \lambda v\|_{0,p,\Omega} + C_3 \|\gamma Bu\|_{2-d-1/p,p,\Gamma} \\ &\leq C_2 \{ \|Au + \lambda u\|_{0,p,\Omega} + \|(A+\lambda)R\gamma Bu\|_{0,p,\Omega} \} + C_2 \|\gamma Bu\|_{2-d-1/p,p,\Gamma} \\ &\leq C_4 \{ \|Au + \lambda u\|_{0,p,\Omega} + \|\gamma Bu\|_{2-d-1/p,p,\Gamma} \}. \end{aligned}$$

This is (2,3,3,7).

#### 2.4 Existence and uniqueness, the general case

In this section we derive a general existence and uniqueness result for problem (2,1,4) as a consequence of the *a priori* estimate of Section 2.3. Then we remove the parameter  $\lambda$  and attempt to solve problem (2,1,3).

#### 2.4.1 The basic result

We shall show that under the assumptions of Section 2.1, the mapping

$$T_{p,\lambda}: u \mapsto \{Au + \lambda u; \gamma Bu\}$$

is an isomorphism from  $W_p^2(\Omega)$  onto  $L_p(\Omega) \times W_p^{2-d-1/p}(\Gamma)$ , for  $\lambda$  large enough. For that purpose, we shall consider successively the three cases (a) p = 2, (b) p < 2, (c) p > 2.

The starting point of the proof consists in observing that  $T_{2,\lambda}$  is a semi-Fredholm operator for  $\lambda$  large enough. Indeed, from (2,3,3,7), it follows that  $T_{2,\lambda}$  is one to one and that the image of  $T_{2,\lambda}$  is closed in  $L_2(\Omega) \times H^{3/2-d}(\Gamma)$ . This allows us to consider the index of  $T_{2,\lambda}$  which is (in this particular case):

$$\chi(T_{2,\lambda}) = -\operatorname{def} R(T_{2,\lambda})$$

where  $R(T_{2,\lambda})$  is the image (range) of  $T_{2,\lambda}$  and def  $R(T_{2,\lambda})$  is the codimension (possibly infinite) of  $R(T_{2,\lambda})$  i.e., the dimension of

$${L_2(\Omega)\times H^{3/2-d}(\Gamma)}/{R(T_{2,\lambda})}$$
.

It is well known that the index remains constant when one performs a homotopy from an operator to another, remaining in the set of all semi-Fredholm operators (see Kato (1966), Chapter IV, §5). We shall only use the following very simple form of this general principle:

**Lemma 2.4.1.1** Let X, Y be a pair of Banach spaces and let  $t \to T_t$  be a continuous mapping from [a, b] (a and b are any real numbers) into the space L(X; Y) of all continuous linear operators from X into Y. Assume

*that for each t, there* exists C, such that

$$||x||_X \le C_t ||T_t x||_Y, \qquad x \in X$$
 (2,4,1,1)

Assum, *Ta is* an *isoinlorphism; then T,, is* also an *isomorphism.*

A direct elementary proof, avoiding the general theory of semi-Fredholm operators, can be built from the fact that isomorphisms define an open subset of L(X; Y).

Many of the estimates that we have derived involve a parameter A whose lower bound depends on the particular problem which is under consideration. In performing homotopies from one problem to another, this will cause problems. This is why we shall use the following technical lemma.

*Lemma* 2.4.1.2 *Let X,* Y be a pair *of* Banach spaces. Let t +— T, be a *continuous* rnapping *from [a, b] into L(X, Y). Let* also *S be a fixed element of L(X; Y).* Assume that *for each t there* exists *C, and A,* such that

$$||x||_X \le C_t ||T_t x + \lambda S x||_Y, \qquad x \in X$$
 (2,4,1,2)

*for all* A > A,. Then *there* exists *C and J-* such that

$$||x||_X \le \bar{C} ||T_t x + \lambda S x||_Y, \qquad x \in X$$
 (2,4,1,3)

*for all* A A *and t* e [a, *b].*

*Proof* Consider any pair of numbers t and *t'* in [a, b]. Then we have, for

$$||x||_X \le C_t ||T_t x + \lambda Sx||_Y \le C_t ||T_t - T_t||_{X \to Y} ||x||_X + C_t ||T_t x + \lambda Sx||_Y.$$

If we assume that t and t' are close enough to one another, we have

$$||T_t - T_t||_{X \to Y} \leq \frac{1}{2}C_t$$

since the mapping t H T, is continuous. It follows that

$$||x||_X \leq 2C_t ||T_t x + \lambda Sx||_Y$$

for A . A,. This shows the existence of C and £ locally. The desired result follows, since [a, b] is compact. n

We now prove our basic result

*Theorem 2.4.1.3 Let A,* B and *fl f* ul fil *the* assumptions in Section 2.1. *Then for* 1 <p < x, *there* exists A,, *such that*

$$T_{p,\lambda}: u \mapsto \{Au + \lambda u; \gamma Bu\}$$

*is an isomorphism from W(Q) onto* L, (D) x W2 -d -1lp(F) *for all* A % Ap.

**Proof** for p=2 This is nothing but Corollary 2.2.2.4 when B=I, i.e. when we are solving Dirichlet's problem. The same way, this is nothing but Corollary 2.2.2.6 when  $B=\partial/\partial\nu_A$  on  $\Gamma$ , i.e. when we are solving Neumann's problem.

Let us consider now an oblique boundary condition (i.e. d = 1). We shall perform a homotopy from Neumann's problem to our problem. For that purpose, we introduce the operators

$$B_t u = (1-t)\frac{\partial u}{\partial \nu_A} + tBu, \qquad t \in [0, 1].$$

We observe that  $\Gamma$  is not characteristic for  $B_i$ , for all  $t \in [0, 1]$ , provided  $b_{\nu} = \sum_{i=1}^{n} b_i \nu_i < 0^{\dagger}$  (if this is not the case we replace B by -B). Accordingly, we can apply Theorem 2.3.3.6 to the mapping

$$T_i: u \to \{Au; \gamma B_i u\}$$

and there exists  $C_t$  and  $\lambda_t$  such that

$$||u||_{2,2,\Omega} \le C_t[||Au + \lambda u||_{0,2,\Omega} + ||\gamma B_t u||_{1/2,2,\Gamma}]$$

for all  $u \in H^2(\Omega)$  and  $\lambda \ge \lambda_t$ .

Let us now set  $X = H^2(\Omega)$ ,  $Y = L_2(\Omega) \times H^{1/2}(\Gamma)$  and

$$S: u \mapsto \{u, 0\}.$$

It is obvious that  $t \mapsto T_t$  is continuous from [0, 1] into L(X; Y). Applying Lemma 2.4.1.2, we find  $\bar{\lambda}$  and  $\bar{C}$  such that

$$||u||_{2,2,\Omega} \le \bar{C}[||Au + \lambda u||_{0,2,\Omega} + ||\gamma B_t u||_{1/2,2,\Gamma}]$$
(2,4,1,4)

for all  $u \in H^2(\Omega)$ ,  $\lambda \ge \overline{\lambda}$  and  $t \in [0, 1]$ .

A first application of Lemma 2.4.1.1, using homotopy in  $\lambda$  instead of t, shows that  $T_0 + \lambda S$  is an isomorphism for all  $\lambda \ge \overline{\lambda}$ , since by Corollary 2.2.2.6 we already know that  $T_0 + \lambda S$  is an isomorphism for  $\lambda$  large enough.

A second application of Lemma 2.4.1.1, using homotopy in t with a fixed  $\lambda \ge \overline{\lambda}$ , shows that  $T_1 + \lambda S$  is an isomorphism, since  $T_0 + \lambda S$  is so. This proves Theorem 2.4.1.3 when p = 2.

Proof of Theorem 2.4.1.3 for all p < 2 Inequality (2,3,3,7) shows that  $T_{p,\lambda}$  is one to one and has a closed range for  $\lambda$  large enough. On the other hand, the result already proved for p = 2 shows that the range of  $T_{p,\lambda}$  contains  $L_2(\Omega) \times H^{3/2}(\Gamma)$ , since  $H^2(\Omega) \subseteq W_p^2(\Omega)$ . Consequently, the range of  $T_{p,\lambda}$  is also dense; this proves that  $T_{p,\lambda}$  is onto.

<sup>†</sup> We recall that  $b_{\nu}$  does not vanish on  $\Gamma$ , since  $\Gamma$  is not characteristic for B.

*Proof of Theorem 2.4.1.3 for all p >2* We shall make use of this auxiliary smoothness result which will be proved later on.

*Lemma 2.4.1.4 Let A, B and f2 f ul fil the assumptions in Section 2.1. Let u E W (Q) be a solution of*

$$\begin{cases} Au = f & \text{in } \Omega \\ \gamma Bu = g & \text{on } \Gamma \end{cases}$$

*where f E L,((2), g* E *Wp-d- "p(F). Assume that p \_ rn/(n — r) if* r < n. *Then u* E *Wp(fi).*

Exactly as in all the preceding cases, it follows from inequality (2,3,3,7) that Tp.,, is one to one and that its range is closed. To prove that is onto, we start from f E L<sup>p</sup> ((2) and g E Wp-*d-* "p(I'). We have consequently *f E* L<sup>2</sup> (L) and g E *H312-'<sup>1</sup> (V).* Applying again the result already proved for p = 2, we know that there exists u E *H<sup>2</sup> (()* such that

$$\begin{cases} Au + \lambda u = f & \text{in } \Omega \\ \gamma Bu = g & \text{on } \Gamma \end{cases}$$

for A large enough. A (possibly iterated) application of Lemma 2.4.1.4 shows that u E Wp(Q). Consequently, Tp,,, is onto. n

*Proof of Lemrna 2.4.1.4 It* uses methods very similar *to* those in Section 2.2.2. Accordingly, we shall first localize our problem with the aid of cut-off functions. Then we shall use a C'' change of coordinates to flatten the boundary. Finally we shall use Friedrichs' mollifiers method instead of Nirenberg's tangential differential quotients. This is to prove smoothness in the case where the boundary is flat.

Thus, let 0 be any function in *2(D)* and set u, = 8u. It follows that u, E W2 (Q) and that

$$f_1 = Au_1 = \theta f + [A; \theta]u \in L_p(\Omega).$$

Indeed the assumption on p ensures that *W* r *(ƒ2)* is contained in Lp (L) by Sobolev's imbedding theorem (see Section 1.4.4). Then we have

$$g_1 = \gamma B u_1 = \theta g \in W_p^{2-1/p}(\Gamma)$$

when d = 0 and

$$g_1 = \gamma B u_1 = \theta g + \gamma [B; \theta] u \in W_p^{1-1/p}(\Gamma)$$

when d=1.

Now let V be an open subset of ll " and let P be a C" diffeomorphism of V onto a neighbourhood of the support of 0. Assume that

$$\Phi^{-1}(\Omega \cap \Phi(V)) = U = \mathbb{R}^n_+ \cap V.$$

(We do not exclude here the possibility that  $\Gamma \cap \Phi(V) = \emptyset$ .) Then we consider  $u_2 = u_1 \circ \Phi$ . Again we have  $u_2 \in W_r^2(U)$  and setting  $\Psi = \Phi^{-1}$ , we have

$$A^{\#}u_{2} = \sum_{k,l=1}^{n} D_{l}a_{k,l}^{\#}D_{k}u_{2} = f_{2} \quad \text{in } U$$
 (2,4,1,5)

where

$$a_{k,l}^{\#} = \sum_{i,j=1}^{n} \left[ a_{i,j} (D_i \Psi_k) (D_j \Psi_l) \right] \circ \Phi |D\Phi|,$$
  
$$f_2 = |D\Phi| f_1 \circ \Phi.$$

Clearly we have  $f_2 \in L_p(U)$ ,  $a_{k,l}^\# \in C^{0,1}(\bar{U})$  and in addition

$$\sum_{k,l=1}^{n} a_{k,l}^{\#}(y) \xi_{k} \xi_{l} \leq -\alpha^{\#} |\xi|^{2}$$

for all  $\xi \in \mathbb{R}^n$  and all  $y \in \overline{U}$ , for some  $\alpha^{\#} > 0$ . We also have

$$\gamma u_2 = g_2 = g_1 \circ \Phi$$
 in  $V \cap \{x_n = 0\}$  (2,4,1,6)

when d = 0 and

$$\gamma B^{\#} u_2 = \gamma \sum_{j=1}^n b_j^{\#} D_j u_2 = g_2 = g_1 \circ \Phi$$
 in  $V \cap \{x_n = 0\}$ , (2.4,1,7)

where

$$b_i^{\#} = \sum_{i=1}^n \left[ b_i(D_i \Psi_i) \right] \circ \Phi$$

if d = 1. Clearly again, we have  $g_2 \in W_p^{2-d-1/p}(V \cap \{x_n = 0\}), b_j^\# \in C^{0,1}(\bar{U})$  and

$$b_n^{\#} = \sum_{i=1}^n \left[ b_i(D_i \Psi_n) \right] \circ \Phi$$

does not vanish on  $\{x_n = 0\}$  since  $\mathbf{v}$  and the gradient of  $\mathbf{\Psi}_n$  are parallel. A first technical step is:

**Lemma 2.4.1.5** Under the above assumptions, we have  $u_2 \in W_p^2(U)$ .

Then, since  $\Omega$  is bounded and has a  $C^{1,1}$  boundary, it is possible to find a finite number of open subsets  $V_k$ ,  $1 \le k \le N$  of  $\mathbb{R}^n$ , together with  $C^{1,1}$  diffeomorphisms from  $\bar{V}_k$  onto  $\Phi_k(\bar{V}_k)$ ,  $1 \le k \le N$ , such that

- (a)  $\{\Phi_k(V_k)\}_{k=1}^N$  is a covering of  $\bar{\Omega}$
- (b)  $\Phi_k^{-1}(\Omega \cap \Phi_k(V_k)) = U_k = \mathbb{R}_+^n \cap V_k, \quad 1 \le k \le N.$

With this covering of , we associate a partition of unity o<sup>k</sup> , 1 k ; N, such that

- (c) ek E 2(D)
- (d) the support of ek is inciuded in <Pk (Vk)
- (e) Ik=l ek =1 on

Now Lemma 2.4.1.5 shows that for each k, we have

$$(\theta_k u) \circ \Phi_k \in W^2_p(U_k).$$

Consequently

$$u = \sum_{k=1}^{N} \theta_k u = \sum_{k=1}^{N} \left[ (\theta_k u) \circ \Phi_k \circ \Phi_k^{-1} \right]^{\sim} \in W_p^2(\Omega).$$

Here the symbol means that the function has been continued by zero in D \ <Pk (Vk). Lemma 2.4.1.4 is proved. n

Before proving Lemma 2.4.1.5, let us quote and prove one particular form of the famous mollifiers lemma due to Friedrichs. Here we denote by pm, m = 1, 2,... a sequence of functions belonging to g(R"'') such that

$$\rho_{m}(x') = m^{n-1}\rho(mx')$$

where p E ^.((ln - I) is such that p (x') dx' = 1. Therefore, the convolution by p,, is an approximation of the identity operator when m — +o°.

*Lemma 2.4.1.6 Let a be a uniformly* Lipschitz *function on Rn ; then there* exists a constant C such that

$$||a(\rho_m * D_i v) - \rho_m * (aD_i v)||_{0,p,\mathbb{R}^n_+} \le C ||v||_{0,p,\mathbb{R}^n_+}$$
for all  $m$  and  $1 \le i \le n-1$ .

*Proof* Explicitly we have for *v E g((^+):*

$$(a\rho_{m} * D_{i}v - \rho_{m} * aD_{i}v)(x)$$

$$= \int_{\mathbb{R}^{n-1}} \rho_{m}(x' - y')[a(x', x_{n}) - a(y', x_{n})](D_{i}v)(y', x_{n}) dy'$$

$$= \int_{\mathbb{R}^{n-1}} D_{i}\rho_{m}(x' - y')[a(x', x_{n}) - a(y', x_{n})]v(y', x_{n}) dy'$$

$$+ \int_{\mathbb{D}^{n-1}} \rho_{m}(x' - y')D_{i}a(y', x_{n})v(y', x_{n}) dy'.$$

Consequently we have the following estimate where K denotes the

2.4 EXISTENCE AND UNIQUENESS, THE GENERAL CASE 117

Lipschitz constant of a:

$$\begin{aligned} &|(a\rho_m * D_i v - \rho_m * a D_i v)(x)| \\ &\leq K \int_{\mathbb{R}^{n+1}} \left\{ |\rho_m(x' - y')| + |x' - y'| \left| D_i \rho_m(x' - y')| \right\} \left| v(y', x_n) \right| dy'. \end{aligned}$$

Applying Young's inequality, we obtain

$$\begin{aligned} \|a\rho_{m} * D_{i}v - \rho_{m} * (aD_{i}v)\|_{0,p,\mathbb{R}^{n}_{+}} \\ &\leq K \|v\|_{0,p,\mathbb{R}^{n}_{+}} \int_{\mathbb{R}^{n-1}} \left[ |\rho_{m}(x')| + |x'| |D_{i}\rho_{m}(x')| \right] \mathrm{d}x' \\ &= K \|v\|_{0,p,\mathbb{R}^{n}_{+}} \int_{\mathbb{R}^{n-1}} \left[ |\rho(x')| + |x'| |D_{i}\rho(x')| \right] \mathrm{d}x'. \end{aligned}$$

This is exactly (2,4,1,8) when  $v \in \mathfrak{D}(\mathbb{R}^n_+)$ . The general case follows by density.

**Proof of Lemma 2.4.1.5** The main idea is to apply inequality (2,3,3,1) to a sequence of smooth functions  $u_2^m$ , m = 1, 2, ... which approximates  $u_2$ . It is convenient to extend  $u_2$  in  $\tilde{u}_2$  defined, as usual by

$$\tilde{u}_2 = \begin{cases} u_2 & \text{in } U \\ 0 & \text{in } \mathbb{R}^n_+ \setminus U. \end{cases}$$

Since  $u_2$  has compact support in V, it is clear that  $\tilde{u}_2 \in W_r^2(\mathbb{R}_+^n)$ . We extend  $f_2$  and  $g_2$  in a similar fashion. Then  $\tilde{f}_2 \in L_p(\mathbb{R}_+^n)$  and  $\tilde{g}_2 \in W_p^{2-d-1/p}(\mathbb{R}^{n-1})$ . We extend also the functions  $a_{k,l}^\#$  and  $b_l^\#$  to the whole of  $\mathbb{R}_+^n$  in any way that preserves all the properties of  $A^\#$  and  $B^\#$ . Accordingly, we have

$$\begin{cases} A^{\#}\tilde{u}_2 = \tilde{f}_2 & \text{in } \mathbb{R}^n_+ \\ \gamma_n B^{\#}\tilde{u}_2 = \tilde{g}_2 & \text{on } \mathbb{R}^{n-1}. \end{cases}$$

We now set

$$u_2^m = \rho_m * \tilde{u}_2.$$

We first show that  $u_2^m \in W_p^2(\mathbb{R}_+^n)$ . Indeed, we know that  $\tilde{u}_2 \in W_p^1(\mathbb{R}_+^n)$  by the Sobolev imbedding. It follows that

$$D_i D_j u_2^m \in L_p(\mathbb{R}^n_+), \qquad i+j \leq 2n-1$$

since the effect of  $\rho_m$  \* is to smooth up the functions in the directions of  $x_i$ ,  $1 \le i \le n-1$ . It is a little more tricky to show that  $D_n^2 u_2^m \in L_p(\mathbb{R}_+^n)$ . Indeed, we observe that

$$D_n^2 \tilde{u}_2 = \frac{1}{a_{n,n}^\#} \left\{ A^\# \tilde{u}_2 - \sum_{i+j \leq 2n-1} D_i(a_{i,j}^\# D_i \tilde{u}_2) - (D_n a_{n,n}^\#) D_n \tilde{u}_2 \right\}.$$

Consequently, we have

$$D_n^2 \tilde{u}_2 \in L_p(\mathbb{R}_+; W_p^{-1}(\mathbb{R}^{n-1}))$$

if we agree to consider  $\tilde{u}_2$  as a vector-valued function of  $x_n$ . Smoothing with  $\rho_m *$ , we obtain

$$D_n^2 u_2^m \in L_p(\mathbb{R}^n_+).$$

We observe in addition that  $u_2^m$  remains bounded in  $W_p^1(\mathbb{R}_+^n)$ :

$$\|u_2^m\|_{1,p,\mathbb{R}^n_+} \le \|\tilde{u}_2\|_{1,p,\mathbb{R}^n_+}. \tag{2,4,1,9}$$

We now show that  $A^{\#}u_2^m = f_2^m$  remains bounded in  $L_p(\mathbb{R}^n_+)$ . We use Lemma 2.4.1.6 to compare  $A^{\#}u_2^m$  with  $\rho_m * \tilde{f}_2$ . First, since  $\tilde{u}_2 \in W_r^2(\mathbb{R}^n_+) \subseteq W_p^1(\mathbb{R}^n_+)$ , we know that

$$a_{k,l}^{\#}D_{k}\rho_{m}*D_{l}\tilde{u}_{2}-\rho_{m}*a_{k,l}^{\#}D_{k}D_{l}\tilde{u}_{2}$$

remains bounded in  $L_p(\mathbb{R}^n_+)$  for  $1 \le k \le n-1$ ,  $1 \le l \le n$ . Then we write

$$D_n^2 \tilde{u}_2 = \frac{\tilde{f}_2}{a_{n,n}^\#} - \sum_{k=1}^{n-1} \sum_{l=1}^n \left\{ D_k \left( \frac{a_{k,l}^\#}{a_{n,n}^\#} D_l \tilde{u}_2 \right) + a_{k,l}^\# \frac{D_k a_{n,n}^\#}{a_{n,n}^\#} D_l \tilde{u}_2 \right\} - \frac{D_n a_{n,n}^\#}{a_{n,n}^\#} D_n \tilde{u}_2.$$

This shows that

$$D_n^2 \tilde{u}_2 = F - \sum_{k=1}^{n-1} D_k G_k \tag{2,4,1,10}$$

where F and  $G_k$ ,  $1 \le k \le n-1$ , belong to  $L_p(\mathbb{R}^n_+)$ . Thus we have

$$a_{n,n}^{\#}\rho_{m} * D_{n}^{2}\tilde{u}_{2} - \rho_{m} * a_{n,n}^{\#}D_{n}^{2}\tilde{u}_{2}$$

$$= \left[a_{n,n}^{\#}\rho_{m} * F - \rho_{m} * (a_{n,n}^{\#}F)\right] - \sum_{k=1}^{n-1} \left[a_{n,n}^{\#}\rho_{m} * D_{k}G_{k} - \rho_{m} * a_{n,n}^{\#}D_{k}G_{k}\right]$$

and this is bounded in  $L_p(\mathbb{R}^n_+)$ , owing again to Lemma 2.4.1.6. Adding, we obtain the boundedness in  $L_p(\mathbb{R}^n_+)$  of

$$\sum_{k,l=1}^{n} a_{k,l}^{\#} D_k D_l u_2^m - \rho_m * \sum_{k,l=1}^{n} a_{k,l}^{\#} D_k D_l \tilde{u}_2.$$

Clearly, it follows that there exists  $C_1$  such that

$$||A^{\#}u_{2}^{m} - \rho_{m} * \tilde{f}_{2}||_{0, n \mathbb{R}^{n}} \le C_{1}. \tag{2.4.1.11}$$

Finally we show that  $\gamma_n B^{\#} u_2^m = g_2^m$  remains bounded in  $W_p^{2-d-1/p}(\mathbb{R}^{n-1})$ . In the case where d=0, we simply have  $\gamma_n B^{\#} u_2^m = \gamma_n u_2^m = \rho_m * \tilde{g}_2$  and the claim is obvious. In the case where d=1, we again compare  $\gamma_n B^{\#} u_2^m$  with  $\rho_m * \tilde{g}_2$ . First, since  $\tilde{u}_2 \in W_p^1(\mathbb{R}_+^n)$ , it is clear that

$$b_i^{\#} \rho_m * D_i \tilde{u}_2 - \rho_m * b_i^{\#} D_i \tilde{u}_2, \qquad 1 \le j \le n$$

remains bounded in  $L_p(\mathbb{R}^n_+)$  and that

$$\begin{split} D_{k}(b_{j}^{\#}\rho_{m}*D_{j}\tilde{u}_{2}-\rho_{m}*b_{j}^{\#}D_{j}\tilde{u}_{2}) &= (D_{k}b_{j}^{\#})\rho_{m}*D_{j}\tilde{u}_{2}-\rho_{m}*(D_{k}b_{j}^{\#})D_{j}\tilde{u}_{2} \\ &+ [b_{i}^{\#}\rho_{m}*D_{j}D_{k}\tilde{u}_{2}-\rho_{m}*b_{j}^{\#}D_{j}D_{k}\tilde{u}_{2}] \end{split}$$

also remains bounded in  $L_p(\mathbb{R}^n_+)$  provided  $1 \le j \le n-1$ ,  $1 \le k \le n$ , because of Lemma 2.4.1.6. Then we write

$$\begin{split} D_k (b_n^\# \rho_m * D_n \tilde{u}_2 - \rho_m * b_n^\# D_n \tilde{u}_2) \\ &= (D_k b_n^\#) (\rho_m * D_n \tilde{u}_2) - \rho_m * (D_k b_n^\#) D_n \tilde{u}_2 \\ &+ [b_n^\# \rho_m * D_n^2 \tilde{u}_2 - \rho_m * b_n^\# D_n^2 \tilde{u}_2] \\ &= (D_k b_n^\#) (\rho_m * D_n \tilde{u}_2) - \rho_m * (D_k b_n^\#) D_n \tilde{u}_2 + b_n^\# \rho_m * F - \rho_m * b_n^\# F \\ &- \sum_{k=1}^{n-1} \left[ b_n^\# \rho_m * D_k G_k - \rho_m * b_n^\# D_k G_k \right] \end{split}$$

owing to (2,4,1,10). Using again Lemma 2.4.1.6 we show that there exists  $C_2$  such that

$$||B^{\#}u_2^m - \rho_m * B^{\#}\tilde{u}_2||_{1,p,\mathbb{R}^n_+} \le C_2.$$

Taking the traces, we deduce that

$$\|\gamma_n B^{\#} u_2^m - \rho_m * \tilde{g}_2\|_{1 - 1/p, p, \mathbb{R}^{n-1}} \le C_3. \tag{2,4,1,12}$$

The conclusion of the proof is now straightforward. The functions  $u_2^m$  have their support in a fixed compact set. This allows us to use inequality (2,3,3,1) (see Remark 2.3.3.5). Accordingly there exists  $C_4$  such that

$$||u_2^m||_{2,p,\mathbb{R}_1^m} \leq C_4\{||A^{\#}u_2^m||_{0,p,\mathbb{R}_1^m} + ||\gamma_n B^{\#}u_2^m||_{2-d-1/p,p,\mathbb{R}^{n-1}} + ||u_2^m||_{1,p,\mathbb{R}_1^m}\}.$$

The estimates (2,4,1,9), (2,4,1,11) and (2,4,1,12) imply then that  $u_2^m$ ,  $m=1,2,\ldots$  is a bounded sequence in  $W_p^2(\mathbb{R}_+^n)$ . On the other hand, we have

$$u_2^m \to \tilde{u}_2, \qquad m \to +\infty$$

in  $W^1_p(\mathbb{R}^n_+)$ . This implies that  $\tilde{u}_2 \in W^2_p(\mathbb{R}^n_+)$ . The proof of Lemma 2.4.1.5 is now complete.

## 2.4.2 Applications of the Fredholm theory and the maximum principle

So far, we have dealt with operators A and B respectively fulfilling the assumptions (b) and (c) introduced in Section 2.1. We are now able to widen our class of operators by adding lower-order terms. Thus we now

assume that

$$Au = \sum_{i,j=1}^{n} D_{i}(a_{i,j}D_{j}u) + \sum_{i=1}^{n} a_{i}D_{i}u + a_{0}u$$

where  $a_{i,j} = a_{j,i} \in C^{0,1}(\bar{\Omega})$  fulfil (2,1,1) again and where  $a_i \in L^{\infty}(\Omega)$ ,  $0 \le i \le n$ . In addition B is either the identity operator (d=0) or

$$Bu = \sum_{i=1}^{n} b_i D_i u + b_0 u$$

where  $b_i \in C^{0,1}(\bar{\Omega})$ ,  $0 \le i \le n$  and  $b_{\nu} = \sum_{i=1}^n b_i \nu^i$  does not vanish on  $\Gamma$  (d=1). It will be convenient to assume that  $b_{\nu} < 0$  on  $\Gamma$  (by possibly changing B to -B).

Adding lower-order terms to A and B means adding a compact operator to  $T_{p,\lambda}$ . Indeed, it follows from Theorem 1.4.3.2 that

$$u \mapsto \left\{ \sum_{i=1}^{n} a_i D_i u + a_0 u - \lambda u; \gamma(b_0 u) \right\}$$

is a compact mapping from  $W_p^2(\Omega)$  into  $L_p(\Omega) \times W_p^{1-1/p}(\Gamma)$ . Adding this to  $T_{p,\lambda}$ , which is an isomorphism for  $\lambda$  large, implies the following lemma:

#### Lemma 2.4.2.1 The mapping

$$T_p: u \mapsto \{Au, \gamma Bu\}$$

is a Fredholm operator of index zero from  $W^2_p(\Omega)$  into  $L_p(\Omega) \times W^{2-d-1/p}_p(\Gamma)$ .

In other words, this means that the operator under consideration has a finite dimensional kernel and a range of finite codimension. In addition, the codimension  $\mu$  of its range is equal to the dimension of its kernel (see, for instance, Theorem 5.26, §5, Chapter IV in Kato (1966)).

The problem of showing that the mapping  $T_p$  is actually an isomorphism is now reduced to showing that  $\mu = 0$ , i.e. that  $T_p$  is one to one. This is a much simpler question since we have some strong smoothness results for functions in the kernel of  $T_p$ .

**Lemma 2.4.2.2** Let  $u \in W_p^2(\Omega)$  be a solution of

$$\begin{cases} Au = 0 & \text{in } \Omega \\ \gamma Bu = 0 & \text{on } \Gamma; \end{cases}$$
 (2,4,2,1)

then  $u \in \bigcap_{1 \le q \le \infty} W_q^2(\Omega) \subseteq C^1(\bar{\Omega})$ .

By the way, this shows that ker  $T_p$  does not depend on p.

*Proof of Lernma 2.4.2.2* The differentiability of u up to the boundary follows from Lemma 2.4.1.4. This lemma does not apply directly to A and B since we have weakened our assumptions on these operators. However, it applies to A () and B0 defined as follows:

$$A_0 u = \sum_{i,j=1}^n D_i(a_{ij}D_j u)$$

and B<sup>0</sup> u is either u (d = 0) or

$$B_0u=\sum_{i=1}^nb_iD_iu.$$

Indeed it follows from (2,4,2,1) that

$$D_{\mathfrak{i}}u\in W^1_{\mathfrak{p}}(\Omega)$$

and that -yu =0 when d =0 and yB<sup>0</sup> u E Wp- '^p(F) when d = 1. In all cases Sobolev's imbedding theorem implies that

$$\begin{cases} A_0 u \in L_q(\Omega) \\ \gamma B_0 u \in W_q^{2-d-1/q}(\Gamma) \end{cases}$$

where q pn/(n -- p) for p < n and q < x for p n. Lemma 2.4.1.4 shows that u E Wq([2).

Iterating the previous procedure eventually shows that

$$u \in \bigcap_{1 < q < \infty} W_q^2(\Omega).$$

We conciude by using again Sobolev's imbedding theorem which implies that uEC'(Q). n

Of course, the result of Lemma 2.4.2.2 is an invitation to use the maximum principle for showing uniqueness. The proof of uniqueness would be quite simple if we also knew that u E C<sup>2</sup> Q). However, this may not be true under our assumptions on the coefficients a <sup>i</sup> , 1 i = n. Thus we shall make use of the generalized form of the maximum principle for weak solutions, due to Stampacchia (1965). This author considers general weak solutions in H' ffl). Here we shali take advantage of the smoothness proved in Lemma 2.4.2.2 to give a simpler proof.

Theorem 2.4.2.3 Let u E fl,<,,<. W<sup>2</sup> (Q) be a solution of Au =0 in D. Assume *that either ai = 0,* 1 i n *and a<sup>0</sup> .0 or a0 3 > 0, then*

$$\max_{x \in \overline{\Omega}} u(x) \leq \max \left( 0, \max_{x \in \Gamma} u(x) \right). \tag{2.4.2.2}$$

The proof of this result will follow after some preliminaries. We set  $k = \max(0, \max_{x \in \Gamma} u(x))$  and

$$u_k(x) = \max(u - k; 0)$$
 (2,4,2,3)

**Lemma 2.4.2.4**  $u_k$  belongs to  $\mathring{W}_p^1(\Omega)$  for all p.

**Proof** We can redefine  $u_k$  as being  $\varphi_k \circ u$ , where

$$\varphi_k(t) = \max(t - k; 0)$$

This is a uniformly Lipschitz function with Lipschitz constant equal to one. Since  $u \in C^1(\bar{\Omega})$ , it follows that  $u_k$  is also a Lipschitz function and furthermore, applying a theorem of Rademacher (1919), we see that

$$D_i u_k = (\varphi_k' \circ u) D_i u$$

almost everywhere. It follows that  $|D_i u_k| \le |D_i u|$  and consequently  $u_k \in W^1_p(\Omega)$  for all p. In addition, we have shown that

$$D_{i}u_{k} = \begin{cases} 0 \text{ a.e. in } \{x \mid u(x) \leq k\} \\ D_{i}u \text{ a.e. in } \{x \mid u(x) > k\}. \end{cases}$$
 (2.4.2.4)

Finally, to show that  $\gamma u_k = 0$ , we approximate  $\varphi_k$  by means of a sequence of functions  $\varphi_{k,m}$ , m = 1, 2, ... such that

- (a)  $\varphi_{k,m} \in C^1(\mathbb{R})$
- (b)  $\varphi_{k,m}$  is uniformly Lipschitz continuous, with Lipschitz constant equal to one
- (c)  $0 \le \varphi_{k,m} \le \varphi_k$
- (d)  $\varphi_{k,m} \to \varphi_k$  uniformly when  $m \to +\infty$ .

Then we approximate  $u_k$  by  $\varphi_{k,m} \circ u$ . It is obvious that  $\varphi_{k,m} \circ u \in C^1(\overline{\Omega})$  and that  $\varphi_{k,m} \circ u$  vanishes on  $\Gamma$ . Then we show that there exists an increasing sequence  $m_i$ ,  $j=1,2,\ldots$  such that  $\varphi_{k,m_i} \circ u \to u_k$  in  $W^1_p(\Omega)$ . This implies that  $\gamma u_k = \lim_{j\to\infty} \gamma(\varphi_{k,m_i} \circ u) = 0$ , i.e.,  $u_k \in \mathring{W}^1_p(\Omega)$ .

Actually we have

$$\varphi_{k,m} \circ u(x) \to u_k(x)$$

for all x and in addition

$$|(\varphi_{k,m} \circ u)(x)| \le |u(x)|$$
  
$$|(D_i \varphi_{k,m} \circ u)(x)| \le |D_i u(x)|, \qquad 1 \le i \le n$$

for all x. Applying Lebesgue's dominated convergence theorem we find an increasing sequence  $m_i$  and functions  $v_i$ ,  $0 \le j \le n$  in  $L_p(\Omega)$  such that

$$\varphi_{k,m} \circ u \to v_0$$

$$D_i \varphi_{k,m} \circ u \to v_i, \qquad 1 \le i \le n$$

2.4 EXISTENCE AND UNIQUENESS, THE GENERAL CASE 123

in  $L_p(\Omega)$ . Applying also Lebesgue's subsequence theorem we can achieve the choice of the sequence  $m_i$  in order that

$$\varphi_{k,m} \circ u \to v_0$$

almost everywhere. We conclude by observing that  $v_0 = u_k$  almost everywhere on the one hand and that  $v_i = D_i v_0$ ,  $1 \le i \le n$  in the sense of distributions on the other hand. Thus  $u_k = v_0 \in W^1_p(\Omega)$  and  $\varphi_{k,m} \circ u \to u_k$  in  $W^1_p(\Omega)$ . This completes the proof of Lemma 2.4.2.4.

Now, as in Section 2.3.1, we shall consider the corresponding function  $u_k^*$  through the duality mapping from  $L_p(\Omega)$  into  $L_q(\Omega)$ , i.e.,

$$u_k^*(x) = |u_k(x)|^{p-2} u_k(x). \tag{2.4.2.5}$$

Since we shall only use large values of p, we can view  $u_k^*$  as  $\psi_p \circ u_k$ , where

$$\psi_{\mathbf{p}}(t) = |t|^{\mathbf{p}-2} t \tag{2.4.2.6}$$

is a continuously differentiable function. Since function  $u_k$  is uniformly Lipschitz continuous, we can again apply Rademacher's theorem to differentiate  $u_k^*$ . This leads to the following identity

$$D_i u_k^*(x) = (p-1) |u_k(x)|^{p-2} D_i u_k(x)$$
 (2,4,2,7)

almost everywhere,  $1 \le i \le n$ . This together with identity (2,4,2,4), implies the following:

$$D_{i}u_{k}^{*}(x) = \begin{cases} 0 & \text{a.e. in } \{x \mid u(x) \leq k\} \\ (p-1) |u_{k}(x)|^{p-2} D_{i}u(x) & \text{in } \{x \mid u(x) > k\} \end{cases}$$
 (2,4,2,8)

Proof of Theorem 2.4.2.3 We start from the identity

$$\int_{\Omega} Auu_k^* \, \mathrm{d}x = 0$$

which is obvious, and then we integrate by parts. Since  $u_k \in \mathring{H}^1(\Omega)$ , we obtain

$$-\sum_{i,j=1}^{n} \int_{\Omega} a_{ij} D_{i} u D_{i} u_{k}^{*} dx + \sum_{i=1}^{n} \int_{\Omega} a_{i} D_{i} u u_{k}^{*} dx + \int_{\Omega} a_{0} u u_{k}^{*} dx = 0.$$

This is equivalent to the following, where  $A_k$  denotes the set  $\{x \in \Omega \mid u(x) > k\}$ :

$$\begin{split} &-\sum_{i,j=1}^{n}(p-1)\int_{A_{k}}a_{ij}|u_{k}|^{p-2}D_{j}u_{k}D_{i}u_{k}\,\mathrm{d}x+\sum_{i=1}^{n}\int_{A_{k}}a_{i}D_{i}u_{k}|u_{k}|^{p-2}u_{k}\,\mathrm{d}x\\ &+\int_{A_{k}}a_{0}(u_{k}+k)|u_{k}|^{p-2}u_{k}\,\mathrm{d}x=0. \end{split}$$

We now denote by M an upper bound for  $|a_i|$ ,  $1 \le i \le k$  in  $\bar{\Omega}$ . It follows from (2,1,1) that we have:

$$\begin{split} &\alpha(p-1)\int_{A_k} |u_k|^{p-2} |\nabla u_k|^2 \, \mathrm{d}x - Mn \int_{A_k} |\nabla u_k| \, |u_k|^{p-1} \, \mathrm{d}x + \int_{A_k} a_0 \, |u_k|^p \, \mathrm{d}x \\ &\leq -k \int_{A_k} a_0 \, |u_k|^{p-2} \, u_k \, \mathrm{d}x \leq 0. \end{split}$$

Then using Cauchy-Schwarz inequality, we get the following inequality for all  $\varepsilon > 0$ 

$$\left[\alpha(p-1) - \frac{Mn}{2\varepsilon}\right] \int_{A_k} |u_k|^{p-2} |\nabla u_k|^2 dx + \left[\beta - \frac{Mn}{2}\varepsilon\right] \int_{A_k} |u_k|^p dx \le 0,$$
(2,4,2,9)

where  $\beta \le a_0(x)$  a.e. We finally chose  $\varepsilon$  small enough so that  $\beta - (Mn/2)\varepsilon \ge 0$ . This is possible under the assumptions of Theorem 2.4.2.3, which mean that either  $\beta > 0$  or M = 0 if  $\beta = 0$ . Once we have chosen  $\varepsilon$  we can find p large enough such that  $\alpha(p-1) > Mn/2\varepsilon$ . From (2,4,2,9) we conclude that

$$|u_k|^{p-2} |\nabla u_k|^2 = 0$$

a.e. in  $A_k$ . Equivalently, we have

$$(u-k)\nabla u=0$$

everywhere in  $A_k$  (since  $u \in C^1(\bar{\Omega})$ ). In other words

$$\nabla (u-k)^2 = 0$$

in  $A_k$  and consequently u - k is constant in  $A_k$ . On the other hand, we have u = k on the boundary of  $A_k$ ; thus u = k everywhere in  $A_k$ . This means that  $u \le k$ .

It is now easy to deduce several uniqueness theorems corresponding to various kinds of boundary conditions, from Theorem 2.4.2.3. First let us consider the Dirichlet boundary condition.

**Theorem 2.4.2.5** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a  $C^{1,1}$  boundary. Let  $a_{i,j}$  be uniformly Lipschitz functions and  $a_i$  be bounded measurable functions such that  $a_{j,i} = a_{i,j}$ ,  $1 \le i, j \le n$  and that there exists  $\alpha > 0$  with

$$\sum_{i,j=1}^{n} a_{i,j}(x)\xi_i \xi_j \leq -\alpha |\xi|^2$$

for all  $\xi \in \mathbb{R}^n$  and for almost every  $x \in \overline{\Omega}$ . Assume in addition, that either

 $a_i = 0$ ,  $1 \le i \le n$  and  $a_0 \ge 0$  a.e. or  $a_0 \ge \beta > 0$  a.e. Then for every  $f \in L_p(\Omega)$  and every  $g \in W_p^{2-1/p}(\Gamma)$ , there exists a unique  $u \in W_p^2(\Omega)$  solution of

$$\begin{cases} \sum_{i,j=1}^{n} D_i(a_{i,j}D_ju) + \sum_{i=1}^{n} a_iD_iu + a_0u = f & \text{in } \Omega \\ \gamma u = g & \text{on } \Gamma. \end{cases}$$

Proof According to Lemma 2.4.2.1, we just have to prove that  $T_p$  is one to one. Thus let  $u \in \ker T_p$ . From Lemma 2.4.2.2, we know that actually  $u \in \ker T_p$  for all p. Then applying Theorem 2.4.2.3, we have

$$\max_{x \in \bar{\Omega}} u(x) = 0$$

since  $\max_{x \in \Gamma} u(x) = 0$ . The same holds for -u, so that u = 0.

Let us now consider the so-called third boundary value problem and more generally an operator B of order d = 1, with a nonzero coefficient  $b_0$ .

**Theorem 2.4.2.6** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$ , with a  $C^{1,1}$  boundary. Let  $a_{i,j}$  and  $b_i$  be uniformly Lipschitz functions and let  $a_i$  be bounded measurable functions in  $\overline{\Omega}$ . Assume that  $a_{i,j} = a_{j,i}$ ,  $1 \le i, j \le n$  and that there exists  $\alpha > 0$  with

$$\sum_{i,j=1}^n a_{i,j}(x)\xi_i\xi_j \leqslant -\alpha |\xi|^2$$

for all  $\xi \in \mathbb{R}^n$  and almost every  $x \in \overline{\Omega}$ . Assume in addition, that either  $a_i = 0$ ,  $1 \le i \le n$  and  $a_0 \ge 0$  a.e. or  $a_0 \ge \beta > 0$  a.e. in  $\overline{\Omega}$ . Assume finally that

$$b_0 b_{\nu} = b_0 \sum_{j=1}^{n} b_j \nu^j > 0$$

on  $\Gamma$ . Then for every  $f \in L_p(\Omega)$  and every  $g \in W_p^{1-1/p}(\Gamma)$ , there exists a unique  $u \in W_p^2(\Omega)$  which is a solution of

$$\begin{cases} \sum_{i,j=1}^{n} D_i(a_{i,j}D_ju) + \sum_{i=1}^{n} a_iD_iu + a_0u = f & \text{in } \Omega \\ \gamma \left(\sum_{j=1}^{n} b_jD_ju + b_0u\right) = g & \text{on } \Gamma. \end{cases}$$

**Proof** Again, owing to Lemma 2.4.2.1, we just have to prove that  $T_p$  is one to one. Thus let  $u \in \text{Ker } T_p$ . We know from Lemma 2.4.2.2 that  $u \in \bigcap_{1 . This allows us to apply Theorem 2.4.2.3. We want to$ 

126

prove that

$$\max_{x \in \bar{\Omega}} u(x) \le 0. \tag{2,4,2,10}$$

Assume the contrary; then necessarily, the maximum of u is attained on the boundary  $\Gamma$ . Since the first derivatives of u are continuous up to the boundary, the boundary condition is fulfilled in the classical sense. In other words, we have

$$\sum_{j=1}^{n} b_{j}(x)D_{j}u(x) + b_{0}(x)u(x) = 0,$$

for all  $x \in \Gamma$ .

At the particular point  $x_0$  where u reaches its maximum, the tangential derivatives of u vanish and the derivative of u in the direction of v is nonnegative. We can rewrite the boundary condition at  $x_0$  as follows:

$$b_{\nu}(x_0) \frac{\partial u}{\partial \nu}(x_0) + b_0(x_0)u(x_0) = 0.$$

This is contradictory since we assumed that  $u(x_0) > 0$  and that  $b_{\nu}(x_0)$  and  $b_0(x_0)$  are both nonzero numbers and have the same sign. This shows that (2,4,2,10) holds. The same holds for -u, so that u = 0.

In the next statement we shall allow  $b_0$  to vanish so as to be able to consider a Neumann boundary condition for instance. As a counterpart, we have to assume that  $a_0 \ge \beta > 0$  a.e.

**Theorem 2.4.2.7** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$ , with a  $C^{1,1}$  boundary. Let  $a_{i,j}$  and  $b_i$  be uniformly Lipschitz functions in  $\overline{\Omega}$  and let  $a_i$  be bounded measurable functions in  $\overline{\Omega}$ . Assume that  $a_{i,j} = a_{j,i}$ ,  $1 \le i, j \le n$  and that there exists  $\alpha > 0$  with

$$\sum_{i,j=1}^n a_{i,j}(x)\xi_i\xi_j \leqslant -\alpha |\xi|^2$$

for all  $\xi \in \mathbb{R}^n$  and almost every  $x \in \bar{\Omega}$ . Assume in addition that  $a_0 \ge \beta > 0$  a.e. in  $\bar{\Omega}$  and that

$$b_0 b_{\nu} = b_0 \sum_{j=1}^{n} b_j \nu^j \ge 0, \qquad b_{\nu} \ne 0$$

on  $\Gamma$ . Then for every  $f \in L_p(\Omega)$  and every  $g \in W_p^{1-1/p}(\Gamma)$ , there exists a unique  $u \in W_p^2(\Omega)$ , which is a solution of

$$\begin{cases} \sum_{i,j=1}^{n} D_i(a_{i,j}D_ju) + \sum_{i=1}^{n} a_iD_iu + a_0u = f & \text{in } \Omega \\ \gamma \left(\sum_{j=1}^{n} b_jD_ju + b_0u\right) = g & \text{on } \Gamma. \end{cases}$$

$$(2,4,2,11)$$

**Proof** We introduce a function  $\rho \in C^{1,1}(\bar{\Omega})$  such that  $\rho > 0$  in  $\Omega$ ,  $\rho = 0$  on  $\Gamma$  and  $\partial \rho / \partial \nu < 0$  on  $\Gamma$ .† Then we define  $\nu$  by setting

$$u = \exp(-\varepsilon \rho)v$$

and we show that u is a solution of problem (2,4,2,11) if and only if v is a solution of a problem which fulfils the assumptions of Theorem 2.4.2.6, at least for  $\varepsilon > 0$  small enough. The result will follow by applying Theorem 2.4.2.6 to v.

Indeed, we have

$$D_i u = \exp(-\varepsilon \rho)(D_i v - \varepsilon [D_i \rho] v), \qquad 1 \le j \le n$$

and consequently

$$Au = \sum_{i,j=1}^{n} D_{i} \{ a_{i,j} \exp(-\varepsilon \rho) (D_{i}v - \varepsilon [D_{i}\rho]v) \}$$
  
+ 
$$\sum_{i=1}^{n} \exp(-\varepsilon \rho) a_{i} (D_{i}v - \varepsilon [D_{i}\rho]v) + \exp(-\varepsilon \rho) a_{0}v.$$

It follows that

$$\exp(\varepsilon\rho)Au = \sum_{i,j=1}^{n} \{D_{i}a_{i,j}D_{j}v - \varepsilon D_{i}(a_{i,j}D_{j}\rho)v - \varepsilon a_{i,j}D_{j}\rho D_{i}v$$
$$-\varepsilon a_{i,j}D_{i}\rho(D_{j}v - \varepsilon[D_{j}\rho]v)\} + \sum_{j=1}^{n} a_{j}(D_{j}v - \varepsilon[D_{j}\rho]v) + a_{0}v$$

and finally that

$$\sum_{i,j=1}^{n} D_{i} a_{i,j} D_{j} v + \sum_{j=1}^{n} \left[ a_{j} - 2\varepsilon \sum_{i=1}^{n} a_{i,j} D_{i} \rho \right] D_{j} v$$

$$+ \left[ a_{0} - \varepsilon \sum_{j=1}^{n} a_{j} D_{j} \rho - \varepsilon \sum_{i,j=1}^{n} D_{i} (a_{i,j} D_{j} \rho) \right]$$

$$+ \varepsilon^{2} \sum_{i,j=1}^{n} a_{i,j} D_{i} \rho D_{j} \rho v = \exp(\varepsilon \rho) f.$$

On the other hand, we have

$$Bu = \sum_{i=1}^{n} b_{i} \exp(-\varepsilon \rho) (D_{i}v - \varepsilon [D_{i}\rho]v) + b_{0} \exp(-\varepsilon \rho)v$$

<sup>†</sup> It is easy to define  $\rho$  locally near the boundary. In the notations of Definition 1.2.1.1, we can define  $\rho_V$  as being  $(y', y_n) \mapsto \varphi(y') - y_n$ . Then covering  $\Gamma$  by a finite number of hypercubes such as V, we build up a function  $\rho$  from the  $\rho_V \cdot s$  with the help of a partition of unity.

and consequently

$$\gamma \left( \sum_{j=1}^{n} b_{j} D_{j} v + \left[ b_{0} - \varepsilon \sum_{j=1}^{n} b_{j} D_{j} \rho \right] v \right) = g$$

on  $\Gamma$ .

We now check that the problem of which v is a solution fulfils the assumptions of Theorem 2.4.2.6. Indeed we have

$$a_0 - \varepsilon \sum_{j=1}^n a_j D_j \rho - \varepsilon \sum_{i,j=1}^n D_i (a_{i,j} D_j \rho) + \varepsilon^2 \sum_{i,j=1}^n a_{ij} D_i \rho D_j \rho \ge \beta/2 > 0$$

a.e. in  $\bar{\Omega}$  for  $\varepsilon$  small enough, if  $a_0 \ge \beta > 0$  a.e. in  $\bar{\Omega}$ . Then we have

$$\left[b_0 - \varepsilon \sum_{j=1}^n b_j D_j \rho\right] \sum_{j=1}^n b_j \nu^j = \left[b_0 - \varepsilon b_\nu \frac{\partial \rho}{\partial \nu}\right] b_\nu \ge -\varepsilon b_\nu^2 \frac{\partial \rho}{\partial \nu} > 0$$

since  $b_{\nu}$  does not vanish and  $\partial \rho / \partial \nu < 0$  everywhere on  $\Gamma$ .

#### Other kinds of solutions

#### 2.5.1 More on smoothness

If we add the same amount of smoothness—so to speak—to the boundary of  $\Omega$ , to the coefficients of the involved operators and to the data of our problem, we obtain eventually the same amount of extra smoothness for the solution. More precisely, let k be any positive integer and consider the operators A and B introduced in Section 2.1. Assume that

- the boundary  $\Gamma$  of  $\Omega$  is of class  $C^{k+1,1}$   $a_{i,j} = a_{j,i} \in C^{k,1}(\tilde{\Omega}), \ b_i \in C^{k,1}(\tilde{\Omega}).$

Then we have the following smoothness result.

**Theorem 2.5.1.1** Let  $u \in W_p^2(\Omega)$  be such that

$$\begin{cases} Au = f \in W_p^k(\Omega) \\ \gamma Bu = g \in W_p^{2+k-d-1/p}(\Gamma) \end{cases}$$

then  $u \in W_n^{k+2}(\Omega)$ .

*Proof* This follows very closely the proof of Lemma 2.4.1.4 to begin with. That is why we use the same notation. In addition, it is clear that we can prove by induction on m that  $u \in W_p^{2+m}(\Omega)$  implies that  $u \in$  $W_p^{2+m+1}(\Omega)$  provided  $m \le k-1$ . Thus we have to prove that  $u_2 \in$  $W_p^{2+m+1}(U)$ , knowing that  $u_2 \in W_p^{2+m}(U)$ .

Our additional smoothness hypotheses, imply that  $a_{k,l}^\# \in C^{k,1}(\bar{U}), b_i^\# \in C^{k,1}(\bar{U})$ 

C'`. ' (U), f2 E Wp' +' (U) and g2 E W `` --' l n(U). At this step, instead of using Friedrichs' mollifier technique, it is possible to go back to Nirenberg's tangential differential quotients as in the proof of Lemma 2.2.2.1. However, for the sake of using the notation of Lemma 2.4.1.4, we proceed with Friedrichs' technique.

With the help of Lemma 2.4.1.6, it is easy to check that

$$u_2^m = \rho_m * \tilde{u}_2 \in W_p^{2+m+1}(\mathbb{R}^n_+),$$

that u remains bounded in W2 <sup>+</sup> '► t(R) and that A# u2t is bounded in m+l #^` m 2+m+1-d-1/p ►t-i <sup>W</sup> ((}fit), while yB u, is bounded in W (R ). Then the inequality (2,3,3,1) shows that u2' is actually bounded in Wp <sup>+</sup> "' +' (Rti ). Letting m --^ x, this shows that U<sup>2</sup> E Wn+"t (t) and consequently u<sup>2</sup> <sup>E</sup> W2+"t(U).

The remaining steps of the proof are exactly similar to the corresponding steps in the proof of Lemma 2.4.1.4. n

*Remark 2.5.1.2* To each of the existence and uniqueness results of Section 2.4.2, corresponds a result with additional smoothness, proved with the aid of Theorem 2.5.1.1. Briefly, those results are the following.

Under the assumptions of Theorem 2.4.2.5, plus the hypotheses (d) and (e) above and if a E C' *'(Q), 0 i < n,* the mapping (notation as in Section 2.4.2)

$$u \mapsto \{Au; \gamma u\}$$

is an isomorphism from W; +2 Q) onto WI(n) x WI }2- ' /p(T).

Under the assumptions of either Theorem 2.4.2.6 or Theorem 2.4.2.7, plus the hypotheses (d) and (e) above, and if at E C`` ' (fl ), bi E C'`- ' (f ), the mapping (notations of Section 2.4.2)

u -Au; yBu}

is an isomorphism from WI +2(,f2) onto WI(f2) x Wk } ' -l' / (T).

Remark 2.5.1.3 Under the hypotheses of this section we have

$$\ker \mathsf{T}_p \subseteq C^2(\bar{\Omega}).$$

This raakes the proof of Theorem 2.4.2.3 much simpler (see Hopf (1927) for instance).

#### 2.5.2 Very weak solution

Here, for the sake of later reference, we prove a simple basic result which is obtained from the results in Section 2.4.2, by applying the transposition procedure of Lions and Magenes (1960-63).

Let us begin with Dirichlet's problem.

**Theorem 2.5.2.1** Let the assumptions of Theorem 2.4.2.5 be fulfilled. Assume in addition that  $a_i = 0$ ,  $1 \le i \le n$ . Then the mapping

$$u \mapsto \{Au, \gamma u\}$$

is an isomorphism from  $D(A; L_p(\Omega))$  onto  $L_p(\Omega) \times W_p^{-1/p}(\Gamma)$ .

Proof Let us consider the mapping

$$v \mapsto \{Av, \gamma v\}$$

which is an isomorphism from  $W_q^2(\Omega)$  onto  $L_q(\Omega) \times W_q^{2-1/q}(\Gamma)$ . The transposed operator  $\mathsf{T}_q^*$  is also an isomorphism. Assume that  $p^{-1} + q^{-1} = 1$  and consider  $f \in L_p(\Omega)$  and  $g \in W_p^{-1/p}(\Gamma)$ . Define a continuous linear form on  $W_q^2(\Omega)$  by

$$v \mapsto l(v) = \int_{\Omega} f v \, dx + \left\langle g; \gamma \frac{\partial v}{\partial \nu_{A}} \right\rangle.$$

Here the brackets denote the duality pairing between  $W_q^{1-1/q}(\Gamma)$  and  $W_p^{-1/p}(\Gamma)$ .

Since  $\mathsf{T}_q^*$  is an isomorphism, there exists a unique  $u \in L_p(\Omega)$  and a unique  $\varphi \in W_p^{-1-1/p}(\Gamma)$  such that

$$l(v) = \int_{\Omega} u A v \, dx + \langle \varphi; \gamma v \rangle$$

for all  $v \in W_q^2(\Omega)$ . In other words, we have

$$\int_{\Omega} f v \, dx - \int_{\Omega} u A v \, dx = \langle \varphi; \gamma v \rangle - \left\langle g; \gamma \frac{\partial v}{\partial \nu_A} \right\rangle$$
 (2,5,2,1)

for all  $v \in W_q^2(\Omega)$ .

If we use this identity with  $v \in \mathcal{D}(\Omega)$  only, we check that Au = f. Consequently u belongs to  $D(A, L_p(\Omega))$ . This allows us to use Green's formula (see identity (1,5,3,5)): we have

$$\int_{\Omega} f v \, dx - \int_{\Omega} u A v \, dx = \left\langle \gamma \frac{\partial u}{\partial \nu_{A}}; \gamma v \right\rangle - \left\langle \gamma u; \gamma \frac{\partial v}{\partial \nu_{A}} \right\rangle \tag{2.5,2,2}$$

for all  $v \in W_q^2(\Omega)$ . It follows from (2,5,2,1) and (2,5,2,2) that

$$\left\langle \gamma \frac{\partial u}{\partial \nu_{\Delta}} - \varphi; \gamma v \right\rangle = \left\langle \gamma u - g; \gamma \frac{\partial v}{\partial \nu_{\Delta}} \right\rangle$$

for all  $v \in W_q^2(\Omega)$ . By the trace theorem 1.5.1.2 this implies that

$$\left\langle \gamma \frac{\partial u}{\partial \nu_{\rm A}} - \varphi ; \psi_0 \right\rangle = \left\langle \gamma u - g ; \psi_1 \right\rangle$$

for all  $\psi_0 \in W_q^{2-1/q}(\Omega)$  and all  $\psi_1 \in W_q^{1-1/q}(\Gamma)$ . Consequently we have

$$\gamma u = g$$

and

$$\varphi = \gamma \frac{\partial u}{\partial \nu_{A}}.$$

This proves the desired result.

Actually we shall only use this consequence of Theorem 2.5.2.1.

**Corollary 2.5.2.2** Let the assumptions of Theorem 2.4.2.5 be fulfilled. Assume in addition that  $a_i = 0$ ,  $1 \le i \le n$ . Let  $u \in D(A, L_p(\Omega))$  be a solution of

$$\begin{cases} Au = f \in L_p(\Omega) \\ \gamma u = g \in W_p^{2-1/p}(\Gamma) \end{cases}$$

then  $u \in W^2_p(\Omega)$ .

This is a straightforward consequence of Theorems 2.4.2.5 and 2.5.2.1. The corresponding result for Neumann's problem is this

**Proposition 2.5.2.3** Let the assumptions of Theorem 2.4.2.5 be fulfilled. Assume in addition that  $a_i = 0$ ,  $1 \le i \le n$  and that  $a_0 \ge \beta > 0$  a.e. in  $\Omega$ . Let  $u \in D(A; L_p(\Omega))$  be a solution of

$$\begin{cases} Au = f \in L_p(\Omega) \\ \gamma \frac{\partial u}{\partial \nu_A} = g \in W_p^{1-1/p}(\Gamma); \end{cases}$$

then  $u \in W^2_p(\Omega)$ .

The proof of Proposition 2.5.2.3 is similar to the proof of Corollary 2.5.2.2. The corresponding statement for an oblique boundary condition requires a little more smoothness on the coefficients.

**Proposition 2.5.2.4** Let the assumptions of Theorem 2.4.2.7 be fulfilled. Assume in addition that  $a_i = 0$ ,  $1 \le i \le n$  and that  $b_i \in C^{1,1}(\bar{\Omega})$ ,  $1 \le j \le n$ . Let  $u \in D(A; L_p(\Omega))$  be a solution of

$$\begin{cases} Au = f \in L_p(\Omega) \\ \gamma Bu = g \in W_p^{1-1/p}(\Gamma) \end{cases}$$

then  $u \in W^2_p(\Omega)$ .

3

## Secondworder elliptic boundary value problems in convex domains

#### 3.1 *A priori* estimates and the curvature of the boundary

One of our basic tools throughout Chapter 2 has been the *a priori* inequality (2,3,3,7) proved in Theorem 2.3.3.6. In the present chapter we propose an alternative proof of this inequality in the particular case when p =2 and when the function *u E H2(f)* under consideration fulfils the homogeneous boundary condition

$$\gamma Bu = 0.$$

We shall mainly consider boundary value problems for the Laplace operator (in order to avoid some extra technical difficulties). However, we shall allow some nonlinear boundary conditions.

The main idea of the forthcoming alternative proof is to bypass the use of local coordinates. These were used in Section 2.3 to reduce the problem to the case when the boundary I, of the domgin D is flat. Here we shall perform straightforward integration by parts to prove the inequality

$$|u|_{2,2,\Omega} \le C(\Omega) \|Au\|_{0,2,\Omega}$$
 (3,1,1)

for all *u e H2(Q)* such that yBu =0 on *T.* The constant *C(Q)* takes into precise account the curvature of T.

This inequality has various applications, all of which are along the following lines. We shall consider very rough domains fl, such as general convex domains or domains whose boundary has turning points. We shall approximate these domains by sequences of domains with a C2 boundary for which the constant in inequality (3,1,1) can easily be controlled. Taking the limit will prove smoothness results for the solution of a boundary value problem in f, although D is far from having a C<sup>2</sup> boundary.

#### 3.1.1 An identity based on integration by parts

In this section we shall consider a bounded open subset  $\Omega$  of  $\mathbb{R}^n$  with a  $C^2$  boundary  $\Gamma$  together with its second fundamental quadratic form, denoted by  $\mathcal{B}$ . Let us recall briefly an elementary definition of  $\mathcal{B}$ . For that purpose, let P be any point on  $\Gamma$ . It is possible to find n-1 curves of class  $C^2$  in a neighbourhood of P, passing through P, and being orthogonal there. Let us denote by  $\mathscr{C}_1, \ldots, \mathscr{C}_{n-1}$  those curves, by  $\tau_1, \ldots, \tau_{n-1}$  the unit tangent vectors to  $\mathscr{C}_1, \ldots, \mathscr{C}_{n-1}$  respectively, and by  $s_1, \ldots, s_{n-1}$  the arc lengths along  $\mathscr{C}_1, \ldots, \mathscr{C}_{n-1}$  respectively. We can assume that  $\{\tau_1, \ldots, \tau_{n-1}\}$  has the direct orientation at P.

Then, at P,  $\mathcal{B}_P$  is the bilinear form (we shall often drop the subscript P and write  $\mathcal{B}$  instead of  $\mathcal{B}_P$ , whenever this does not lead to any misunderstanding)

$$\xi, \eta \mapsto -\sum_{j,k} \frac{\partial \nu}{\partial s_j} \cdot \tau_k \xi_j \eta_k$$

where  $\xi$  and  $\eta$  are the tangent vectors to  $\Gamma$  at P, whose components are  $\{\xi_1, \ldots, \xi_{n-1}\}$  and  $\{\eta_1, \ldots, \eta_{n-1}\}$ , respectively, in the basis  $\{\tau_1, \ldots, \tau_{n-1}\}$ . In other words, we have

$$\mathcal{B}(\boldsymbol{\xi},\boldsymbol{\eta}) = -\frac{\partial \boldsymbol{\nu}}{\partial \boldsymbol{\xi}} \cdot \boldsymbol{\eta}$$

where  $\partial/\partial \xi$  denotes differentiation in the direction of  $\xi$ . (Actually, we could also extend the definition of  $\mathcal{B}$  to sets  $\Omega$  with a  $C^{1,1}$  boundary with just a little more extra work. All the subsequent results hold for domains with a  $C^{1,1}$  boundary instead of  $C^2$ .)

Another point of view is this. Let us consider a point P of  $\Gamma$  and (according to Definition 1.2.1.1) related new coordinates  $\{y_1, \ldots, y_n\}$  with origin at P as follows: there exists a hypercube

$$V = \{(y_1, \dots, y_n) \mid -a_i < y_i < a_i, 1 \le j \le n\}$$

and a function  $\varphi$  of class  $C^2$  in  $\bar{V}'$ , where

$$V' = \{(y_1, \ldots, y_{n-1}) \mid -a_i < y_i < a_i, 1 \le j \le n-1\}$$

such that

$$|\varphi(y')| \le a_n/2 \text{ for every } y' \in \overline{V}'$$

$$\Omega \cap V = \{ y = (y', y_n) \in V \mid y_n < \varphi(y') \}$$

$$\Gamma \cap V = \{ y = (y', y_n) \in V \mid y_n = \varphi(y') \}.$$

Let us assume further that  $\nabla \varphi(0) = 0$ . This means that the new coordinates have been chosen in such a way that the hyperplane  $y_n = 0$  is

134 SECOND-ORDER PROBLEMS IN CONVEX DOMAINS

tangent to  $\Gamma$  at P. Then, it is easily checked that the form  ${\mathcal B}$  is

$$\mathcal{B}(\boldsymbol{\xi},\boldsymbol{\eta}) = \sum_{j,k=1}^{n-1} \frac{\partial^2 \varphi}{\partial y_k \ \partial y_j} (0) \xi_k \eta_j,$$

where  $\{\xi_1,\ldots,\xi_{n-1}\}$  and  $\{\eta_1,\ldots,\eta_{n-1}\}$  are the components of  $\xi$  and  $\eta$  respectively in the directions of  $\{y_1,\ldots,y_{n-1}\}$ . In particular, when  $\Omega$  is convex, the function  $-\varphi$  is also convex, and consequently the form  $\mathcal{B}$  is nonpositive.

Let us observe, finally, that in the general case of a domain  $\Omega$  with a  $C^2$  boundary the form  $\mathcal{B}$  is uniformly bounded on  $\Gamma$ . In other words, there exists K such that

$$|\mathcal{B}_{P}(\xi, \eta)| \leq K |\xi| |\eta|$$

for all  $P \in \Gamma$ , where  $\xi$  and  $\eta$  are tangent vectors to  $\Gamma$  at P. Indeed,  $\nu$  is a  $C^1$  vector field on  $\Gamma$ . This is why domains with a  $C^2$  boundary (or even  $C^{1,1}$ ) are said to have a boundary with bounded curvature.

Now we introduce some more notation. Let  $\mathbf{v}$  be any vector field on  $\Gamma$ ; we shall denote by  $\mathbf{v}_{\nu}$  the component of  $\mathbf{v}$  in the direction of  $\mathbf{v}$ , while we shall denote by  $\mathbf{v}_{\tau}$  the projection of  $\mathbf{v}$  on the tangent hyperplane to  $\Gamma$ . In other words

$$v_{\nu} = \mathbf{v} \cdot \mathbf{v}$$
 and  $\mathbf{v}_{T} = \mathbf{v} - v_{\nu} \mathbf{v}$ .

In the same way, we shall denote by  $\nabla_T$  the projection of the gradient operator on the tangent hyperplane:

$$\nabla_T u = \nabla u - \frac{\partial u}{\partial \nu} \nu.$$

We can now state the following.

**Theorem 3.1.1.1** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a  $C^2$  boundary, and let  $\mathbf{v} \in H^1(\Omega)^n$ . Then, we have

$$\int_{\Omega} |\operatorname{div} \mathbf{v}|^{2} dx - \sum_{i,j=1}^{n} \int_{\Omega} \frac{\partial v_{i}}{\partial x_{i}} \frac{\partial v_{i}}{\partial x_{i}} dx$$

$$= -2\langle (\gamma \mathbf{v})_{T}; \nabla_{T} [\gamma \mathbf{v} \cdot \mathbf{v}] \rangle - \int_{\Gamma} \{\mathcal{B}((\gamma \mathbf{v})_{T}; (\gamma \mathbf{v})_{T}) + (\operatorname{tr} \mathcal{B})[(\gamma \mathbf{v}) \cdot \mathbf{v}]^{2} \} d\sigma. \quad (3,1,1,1)$$

Here tr B is the trace of the bilinear form B, i.e.,

$$\operatorname{tr} \mathscr{B} = -\sum_{j=1}^{n-1} \frac{\partial \boldsymbol{\nu}}{\partial s_j} \cdot \boldsymbol{\tau}_j$$

in the above notation.

**Proof** First, we apply repeatedly the Green formula of Theorem 1.5.3.1 which holds as soon as  $\Gamma$  is Lipschitz. We thus get, for  $\mathbf{v} \in C^2(\bar{\Omega})^n$ ,

$$\int_{\Omega} |\operatorname{div} \mathbf{v}|^2 \, \mathrm{d}x = \sum_{i,j=1}^n \int_{\Omega} \frac{\partial v_i}{\partial x_i} \frac{\partial v_j}{\partial x_j} \, \mathrm{d}x$$

$$= -\sum_{i,j=1}^n \int_{\Omega} v_i \frac{\partial^2 v_j}{\partial x_i} \, \mathrm{d}x + \sum_{i,j=1}^n \int_{\Gamma} v_i \frac{\partial v_j}{\partial x_j} \, \nu_i \, \mathrm{d}\sigma$$

$$= \sum_{i,j=1}^n \int_{\Omega} \frac{\partial v_i}{\partial x_j} \frac{\partial v_j}{\partial x_i} \, \mathrm{d}x + \sum_{i,j=1}^n \int_{\Gamma} v_i \frac{\partial v_j}{\partial x_i} \, \nu_i \, \mathrm{d}\sigma$$

$$-\sum_{i,j=1}^n \int_{\Gamma} v_i \frac{\partial v_j}{\partial x_i} \, \nu_j \, \mathrm{d}\sigma.$$

In other words, we have

$$I(v) = \int_{\Omega} |\operatorname{div} \mathbf{v}|^{2} dx - \sum_{i,j=1}^{n} \int_{\Omega} \frac{\partial v_{i}}{\partial x_{i}} \frac{\partial v_{j}}{\partial x_{i}} dx$$

$$= \int_{\Gamma} v_{\nu} \operatorname{div} \mathbf{v} d\sigma - \int_{\Gamma} \{(\mathbf{v} \cdot \nabla)\mathbf{v}\} \cdot \mathbf{v} d\sigma. \tag{3,1,1,2}$$

We shall now transform the integrand on the boundary. This can be done locally. Let us consider any point P on  $\Gamma$  and choose an open neighbourhood W of P in  $\Gamma$  small enough to allow the existence of (n-1) families of  $C^2$  curves on W with these properties: a curve of each family passes through every piont of W and the unit tangent vectors to these curves form an orthonormal system (which we assume to have the direct orientation) at every point of W. The lengths  $s_1, \ldots, s_{n-1}$  along each family of curves, respectively, are a possible system of coordinates in W. We denote by  $\tau_1, \ldots, \tau_{n-1}$  the unit tangent vectors to each family of curves, respectively.

With this notation, we have

$$\mathbf{v} = \mathbf{v}_T + v_{\nu} \mathbf{v}, \qquad \mathbf{v}_T = \sum_{k=1}^{n-1} v_k \mathbf{\tau}_k,$$

where  $v_i = \mathbf{v} \cdot \mathbf{\tau}_i$ . We also have for any  $\varphi \in C^1(\overline{\Omega})$ :

$$\nabla \varphi = \nabla_T \varphi + \frac{\partial \varphi}{\partial \nu} \nu, \qquad \nabla_T \varphi = \sum_{j=1}^{n-1} \frac{\partial \varphi}{\partial s_j} \tau_j$$

and consequently

$$\operatorname{div} \mathbf{v} = \sum_{j=1}^{n-1} \frac{\partial \mathbf{v}}{\partial s_j} \cdot \boldsymbol{\tau}_j + \frac{\partial \mathbf{v}}{\partial \boldsymbol{\nu}} \cdot \boldsymbol{\nu}.$$

Consider now the first integrand on  $\Gamma$  in the right-hand side of

(3.1,1.2). We have

$$\operatorname{div} \mathbf{v} = \sum_{j=1}^{n-1} \frac{\partial \mathbf{v}}{\partial s_{j}} \cdot \mathbf{\tau}_{j} + \frac{\partial \mathbf{v}}{\partial \nu} \cdot \mathbf{v}$$

$$= \sum_{j,k=1}^{n-1} \left[ \frac{\partial v_{k}}{\partial s_{j}} \mathbf{\tau}_{k} + v_{k} \frac{\partial \mathbf{\tau}_{k}}{\partial s_{j}} \right] \cdot \mathbf{\tau}_{j} + \sum_{j=1}^{n-1} \left[ \frac{\partial v_{\nu}}{\partial s_{j}} \mathbf{v} + v_{\nu} \frac{\partial \mathbf{v}}{\partial s_{j}} \right] \cdot \mathbf{\tau}_{j}$$

$$+ \sum_{k=1}^{n-1} \left[ \frac{\partial v_{k}}{\partial \nu} \mathbf{\tau}_{k} + v_{k} \frac{\partial \mathbf{\tau}_{k}}{\partial \nu} \right] \cdot \mathbf{v} + \left[ \frac{\partial v_{\nu}}{\partial \nu} \mathbf{v} + v_{\nu} \frac{\partial \mathbf{v}}{\partial \nu} \right] \cdot \mathbf{v}$$

and thus

$$v_{\nu} \operatorname{div} \mathbf{v} = v_{\nu} \left\{ \sum_{j=1}^{n-1} \frac{\partial v_{j}}{\partial s_{j}} + \sum_{j,k=1}^{n-1} v_{k} \frac{\partial \mathbf{\tau}_{k}}{\partial s_{j}} \cdot \mathbf{\tau}_{j} + v_{\nu} \sum_{j=1}^{n-1} \frac{\partial \mathbf{v}}{\partial s_{j}} \cdot \mathbf{\tau}_{j} + \sum_{k=1}^{n-1} v_{k} \frac{\partial \mathbf{\tau}_{k}}{\partial \nu} \cdot \mathbf{v} + \frac{\partial v_{\nu}}{\partial \nu} \right\}$$

$$(3,1,1,3)$$

since  $(\partial \mathbf{v}/\partial \mathbf{v}) \cdot \mathbf{v} = 0$ .

We then consider the second integrand on  $\Gamma$  in the right-hand side of (3,1,1,2). We have

$$(\mathbf{v} \cdot \nabla) \mathbf{v} = \sum_{j=1}^{n-1} v_j \frac{\partial \mathbf{v}}{\partial s_j} + v_\nu \frac{\partial \mathbf{v}}{\partial \nu}$$

$$= \sum_{j,k=1}^{n-1} v_j \left( \frac{\partial v_k}{\partial s_j} \mathbf{\tau}_k + v_k \frac{\partial \mathbf{\tau}_k}{\partial s_j} \right) + \sum_{j=1}^{n-1} v_j \left( \frac{\partial v_\nu}{\partial s_j} \mathbf{v} + v_\nu \frac{\partial \mathbf{v}}{\partial s_j} \right)$$

$$+ \sum_{k=1}^{n-1} v_\nu \left( \frac{\partial v_k}{\partial \nu} \mathbf{\tau}_k + v_k \frac{\partial \mathbf{\tau}_k}{\partial \nu} \right) + v_\nu \left( \frac{\partial v_\nu}{\partial \nu} \mathbf{v} + v_\nu \frac{\partial \mathbf{v}}{\partial \nu} \right),$$

and thus

$$\{(\mathbf{v} \cdot \nabla)\mathbf{v}\} \cdot \mathbf{v} = \sum_{j,k=1}^{n-1} v_j v_k \frac{\partial \mathbf{\tau}_k}{\partial s_j} \cdot \mathbf{v} + \sum_{j=1}^{n-1} v_j \frac{\partial v_\nu}{\partial s_j} + \sum_{k=1}^{n-1} v_\nu v_k \frac{\partial \mathbf{\tau}_k}{\partial \nu} \cdot \mathbf{v} + v_\nu \frac{\partial v_\nu}{\partial \nu}$$

$$(3,1,1,4)$$

because  $(\partial \mathbf{v}/\partial s_i) \cdot \mathbf{v} = 0$ .

Subtracting identities (3,1,1,3) and (3,1,1,4), we finally obtain

$$v_{\nu} \operatorname{div} \mathbf{v} - \{(\mathbf{v} \cdot \nabla)\mathbf{v}\} \cdot \mathbf{v} = v_{\nu} \sum_{j=1}^{n-1} \frac{\partial v_{j}}{\partial s_{j}} + v_{\nu} \sum_{j,k=1}^{n-1} v_{k} \frac{\partial \mathbf{\tau}_{k}}{\partial s_{j}} \cdot \mathbf{\tau}_{j} + v_{\nu}^{2} \sum_{j=1}^{n-1} \frac{\partial \mathbf{v}}{\partial s_{j}} \cdot \mathbf{\tau}_{j} - \sum_{j,k=1}^{n-1} v_{j} v_{k} \frac{\partial \mathbf{\tau}_{k}}{\partial s_{j}} \cdot \mathbf{v} - \sum_{j=1}^{n-1} v_{j} \frac{\partial v_{\nu}}{\partial s_{j}}.$$

$$(3,1,1,5)$$

On the other hand, using  $s_1, \ldots, s_{n-1}$  as coordinates in W, we know

that B is defined by

$$\mathcal{B}(\boldsymbol{\xi},\boldsymbol{\eta}) = -\sum_{i,k=1}^{n-1} \frac{\partial \boldsymbol{\nu}}{\partial s_i} \cdot \boldsymbol{\tau}_k \boldsymbol{\xi}_i \boldsymbol{\eta}_k = +\sum_{i,k=1}^{n-1} \boldsymbol{\nu} \cdot \frac{\partial \boldsymbol{\tau}_k}{\partial s_i} \, \boldsymbol{\xi}_i \boldsymbol{\eta}_k$$

and consequently we have

$$\operatorname{tr} \mathscr{B} = -\sum_{j=1}^{n-1} \boldsymbol{\tau}_j \cdot \frac{\partial \boldsymbol{\nu}}{\partial s_j}.$$

It follows that (3,1,1,5) may be rewritten as:

$$v_{\nu} \operatorname{div} \mathbf{v} - \{ (\mathbf{v} \cdot \nabla) \mathbf{v} \} \cdot \mathbf{v} = v_{\nu} \sum_{j=1}^{n-1} \frac{\partial v_{j}}{\partial s_{j}} + v_{\nu} \sum_{j,k=1}^{n-1} v_{k} \frac{\partial \mathbf{\tau}_{k}}{\partial s_{j}} \cdot \mathbf{\tau}_{j}$$

$$- (\operatorname{tr} \mathcal{B}) v_{\nu}^{2} - \mathcal{B}(\mathbf{v}_{T}; \mathbf{v}_{T}) - \sum_{j=1}^{n-1} v_{j} \frac{\partial v_{\nu}}{\partial s_{j}}. \quad (3,1,1,6)$$

Let us finally calculate

$$\operatorname{div}_{T}(v_{\nu}\mathbf{v}_{T}) = \sum_{i=1}^{n-1} \frac{\partial(v_{\nu}\mathbf{v}_{T})}{\partial s_{i}} \cdot \mathbf{\tau}_{i} = \sum_{i,k=1}^{n-1} \frac{\partial(v_{\nu}v_{k}\mathbf{\tau}_{k})}{\partial s_{i}} \cdot \mathbf{\tau}_{i}.$$

Thus, we have

$$\operatorname{div}_{\mathbf{T}} (v_{\nu} \mathbf{v}_{\mathbf{T}}) = \sum_{j,k=1}^{n-1} \left\{ \frac{\partial v_{\nu}}{\partial s_{j}} v_{k} \mathbf{\tau}_{k} + v_{\nu} \frac{\partial v_{k}}{\partial s_{j}} \mathbf{\tau}_{k} + v_{\nu} v_{k} \frac{\partial \mathbf{\tau}_{k}}{\partial s_{j}} \right\} \cdot \mathbf{\tau}_{j}$$

$$= \sum_{j=1}^{n-1} \frac{\partial v_{\nu}}{\partial s_{j}} v_{j} + v_{\nu} \sum_{j=1}^{n-1} \frac{\partial v_{j}}{\partial s_{j}} + v_{\nu} \sum_{j,k=1}^{n-1} v_{k} \frac{\partial \mathbf{\tau}_{k}}{\partial s_{j}} \cdot \mathbf{\tau}_{j}. \tag{3.1.1.7}$$

Then, from (3,1,1,6) and (3,1,1,7), we deduce

$$\begin{aligned} v_{\nu} \operatorname{div} \mathbf{v} - & \{ (\mathbf{v} \cdot \nabla) \mathbf{v} \} \cdot \mathbf{v} \\ &= \operatorname{div}_{\mathbf{T}} (v_{\nu} \mathbf{v}_{\mathbf{T}}) - (\operatorname{tr} \mathcal{B}) v_{\nu}^{2} - \mathcal{B}(\mathbf{v}_{\mathbf{T}}; \mathbf{v}_{\mathbf{T}}) - 2 \sum_{i=1}^{n-1} v_{i} \frac{\partial v_{\nu}}{\partial s_{i}} \\ &= \operatorname{div}_{\mathbf{T}} (v_{\nu} \mathbf{v}_{\mathbf{T}}) - (\operatorname{tr} \mathcal{B}) v_{\nu}^{2} - \mathcal{B}(\mathbf{v}_{\mathbf{T}}; \mathbf{v}_{\mathbf{T}}) - 2 \mathbf{v}_{\mathbf{T}} \cdot \nabla_{\mathbf{T}} v_{\nu}. \end{aligned}$$
(3,1,1,8

This expression of the integrand on  $\Gamma$  in (3,1,1,2) no longer involves the particular coordinates in W. Varying W, it is consequently true everywhere on  $\Gamma$ . Thus, we have

$$\int_{\Omega} |\operatorname{div} \mathbf{v}|^{2} dx - \sum_{i,j=1}^{n} \int_{\Omega} \frac{\partial v_{i}}{\partial x_{i}} \frac{\partial v_{j}}{\partial x_{i}} dx$$

$$= -2 \int_{\Omega} \mathbf{v}_{T} \cdot \nabla_{T} v_{\nu} d\sigma - \int_{\Gamma} \left\{ (\operatorname{tr} \mathcal{B}) v_{\nu}^{2} + \mathcal{B} \left( \mathbf{v}_{T}; \mathbf{v}_{T} \right) \right\} d\sigma. \quad (3,1,1,9)$$

Indeed, the integral of  $\operatorname{div}_{\mathbf{T}}(v_{\nu}\mathbf{v}_{\mathbf{T}})$  is zero since the vector field  $v_{\nu}\mathbf{v}_{\mathbf{T}}$  is everywhere tangent to  $\Gamma$ .

138 SECOND-ORDER PROBLEMS IN CONVEX DOMAINS

We have proved (3,1,1,9) assuming that  $\mathbf{v} \in C^2(\bar{\Omega})^n$ . However, since the boundary of  $\Omega$  is of class  $C^2$ , the space  $C^2(\bar{\Omega})$  is dense in  $H^1(\Omega)$ . From (3,1,1,9) we deduce (3,1,1,1) by approximating  $\mathbf{v} \in H^1(\Omega)^n$  by a sequence  $\mathbf{v}_m$ ,  $m=1,2,\ldots$  of elements of  $C^2(\bar{\Omega})^n$  for which (3,1,1,9) holds.

Theorem 3.1.1.1 is thus completely proved. Most of the previous proof can be carried out under weaker assumptions on  $\Omega$ . We shall say that a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary  $\Gamma$  has a piecewise  $C^2$  boundary if  $\Gamma = \Gamma_0 \cup \Gamma_1$ , where

- (a)  $\Gamma_0$  has zero measure (for the surface measure  $d\sigma$ ).
- (b)  $\Gamma_1$  is open in  $\Gamma$ , and each point  $x \in \Gamma_1$  has the property of Definition 1.2.1.1 with a function  $\varphi$  of class  $C^2$ .

**Theorem 3.1.1.2** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary  $\Gamma$ . Assume, in addition, that  $\Gamma$  is piecewise  $C^2$ . Then for all  $\mathbf{v} \in H^2(\Omega)^n$  we have

$$\int_{\Omega} |\operatorname{div} \mathbf{v}|^{2} dx - \sum_{i,j=1}^{n} \int_{\Omega} \frac{\partial v_{i}}{\partial x_{j}} \frac{\partial v_{j}}{\partial x_{i}} dx = \int_{\Gamma_{1}} \left\{ \operatorname{div}_{T} (v_{\nu} \mathbf{v}_{T}) - 2 \mathbf{v}_{T} \cdot \nabla_{T} v_{\nu} \right\} d\sigma 
- \int_{\Gamma_{1}} \left\{ (\operatorname{tr} \mathcal{B}) v_{\nu}^{2} + \mathcal{B}(\mathbf{v}_{T}; \mathbf{v}_{T}) \right\} d\sigma.$$
(3,1,1,10)

**Proof** This is quite similar to the proof of Theorem 3.1.1.1. Indeed, (3,1,1,2) holds since  $\Gamma$  is Lipschitz. Then identity (3,1,1,8) holds at any point of  $\Gamma_1$ . Integrating (3,1,1,8), we obtain (3,1,1,10) since  $\Gamma_0$  has measure zero. Finally, we extend (3,1,1,10) from  $\mathbf{v} \in C^2(\bar{\Omega})^n$  to  $\mathbf{v} \in H^2(\Omega)^n$  only, since it is now impossible to give a meaning to the bracket of  $\mathbf{v}_T$  and  $\nabla_T v_{\mathbf{v}}$  when  $\mathbf{v} \in H^1(\Omega)^n$  and  $\Gamma$  is only Lipschitz globally.

#### 3.1.2 A priori inequalities for the Laplace operator revisited

We now take advantage of the results of Section 3.1.1 to prove inequality (3,1,1). Such an inequality has been proved by Caccioppoli (1950-51) and Ladyzhenskaia and Ural'ceva (1968) in the case when  $\Omega$  has a  $C^{1,1}$  boundary. These latter authors call it 'the second fundamental a priori estimate'. All of them make use of local coordinates in order to flatten the boundary. The proof given below follows Grisvard and Iooss (1975); it allows better control of the constant  $C(\Omega)$ . It also allows one to consider some nonlinear boundary conditions. A slightly different point of view is developed in Lewis (1978) for two-dimensional domains.

For the sake of clarity, we shall first consider the particular case when the operator A is the Laplace operator  $\Delta$ , or the modified Laplace

operator  $\Delta - \lambda$  with  $\lambda > 0$ . The first inequality concerns a Dirichlet boundary condition.

**Theorem 3.1.2.1** Let  $\Omega$  be a convex, bounded open subset of  $\mathbb{R}^n$  with a  $C^2$  boundary  $\Gamma$ . Then there exists a constant  $C(\Omega)$ , which depends only on the diameter of  $\Omega$ , such that

$$\|u\|_{2,2,\Omega} \le C(\Omega) \|\Delta u\|_{0,2,\Omega} \tag{3,1,2,1}$$

for all  $u \in H^2(\Omega) \cap \mathring{H}^1(\Omega)$ .

**Proof** We first apply identity (3,1,1,1) to  $\mathbf{v} = \nabla u$ , observing that, since  $\gamma u = 0$  on  $\Gamma$ , we also have  $(\gamma \mathbf{v})_T = \gamma \nabla_T u = 0$  on  $\Gamma$ . Thus, we have

$$\int_{\Omega} |\Delta u|^2 dx - \sum_{i,j=1}^n \int_{\Omega} \left| \frac{\partial^2 u}{\partial x_i \partial x_j} \right|^2 dx = -\int_{\Gamma} (\operatorname{tr} \mathcal{B}) (\gamma \mathbf{v} \cdot \mathbf{v})^2 d\sigma.$$

Due to the convexity of  $\Omega$ , we have tr  $\Re \leq 0$  and consequently

$$\sum_{i,j=1}^{n} \int_{\Omega} \left| \frac{\partial^{2} u}{\partial x_{i} \partial x_{j}} \right|^{2} dx \le \int_{\Omega} |\Delta u|^{2} dx. \tag{3.1,2,2}$$

So far, we have estimated the second derivatives of u. The estimate for the first derivatives is well known to be obtainable by the straightforward integration by parts which follows. We have

$$\sum_{i=1}^{n} \int_{\Omega} \left| \frac{\partial u}{\partial x_{i}} \right|^{2} dx = -\int_{\Omega} \Delta u \cdot u \, dx \le ||\Delta u|| \, ||u||$$

where the norm is the norm of  $L_2(\Omega)$ . On the other hand, the Poincaré inequality implies that

$$||u||^2 \le K(\Omega)^2 \sum_{i=1}^n \int_{\Omega} \left| \frac{\partial u}{\partial x_i} \right|^2 dx$$

where  $K(\Omega)$  depends only on the diameter of  $\Omega$  (see Theorem 1.4.3.4). It follows that

$$\sum_{i=1}^{n} \int_{\Omega} \left| \frac{\partial u}{\partial x_i} \right|^2 dx \le K(\Omega)^2 \|\Delta u\|^2$$
 (3,1,2,3)

and that

$$\|u\| \le K(\Omega)^2 \|\Delta u\|.$$
 (3,1,2,4)

Adding up inequalities (3,1,2,2) to (3,1,2,4), we obtain inequality (3,1,2,1) with  $C(\Omega)^2 \le 1 + K(\Omega)^2 + K(\Omega)^4$ .

Remark 3.1.2.2 In the case when we assume  $\Omega$  to be only a bounded

open subset of  $\mathbb{R}^n$  with a  $C^2$  boundary without the assumption of convexity, we again obtain inequality (3,1,2,1). This is achieved with the aid of identity (3,1,1,1), inequality (1,5,1,2) and by using an upper bound for tr  $\mathcal{B}$ . Consequently, the constant  $C(\Omega)$  depends not only on the diameter of  $\Omega$  but also on an upper bound for tr  $\mathcal{B}$ . In other words, the constant  $C(\Omega)$  depends on the curvature of  $\Gamma$ . This is nothing but an alternative proof of the corresponding inequality in Section 2.3.

Let us now consider a Neumann boundary condition and even some nonlinear boundary conditions closely related to the 'third boundary problem'. Here we consider a real-valued, nondecreasing function  $\beta$  defined on the real line. In addition we assume  $\beta(0) = 0$ , and we assume  $\beta$  to be uniformly Lipschitz continuous. We now deal with the following boundary problem for a function  $u \in H^2(\Omega)$ :

$$\begin{cases}
-\Delta u + \lambda u = f & \text{in } \Omega, \\
-\gamma \frac{\partial u}{\partial \nu} = \beta(\gamma u) & \text{on } \Gamma.
\end{cases}$$
(3,1,2,5)

The corresponding estimate is the following:

**Theorem 3.1.2.3** Let  $\Omega$  be a convex, bounded open subset of  $\mathbb{R}^n$  with a  $C^2$  boundary  $\Gamma$ , and let  $\beta$  be a uniformly Lipschitz, nondecreasing function such that  $\beta(0) = 0$ . Then we have

$$||u||_{2,2,\Omega} \le \left(\frac{1}{\lambda^2} + \frac{1}{\lambda} + 4\right)^{1/2} ||-\Delta u + \lambda u||_{0,2,\Omega}$$
 (3,1,2,6)

for all  $u \in H^2(\Omega)$  such that  $-\gamma \partial u/\partial \nu = \beta(\gamma u)$  on  $\Gamma$  and all  $\lambda > 0$ .

The particular case when the function  $\beta$  is identically zero is just a Neumann problem. Obviously the interest of inequality (3,1,2,6) is that the constant depends neither on  $\Omega$  nor on  $\beta$ . This will allow us to extend widely the possible  $\Omega$ s and the possible  $\beta$ s, in the following sections.

**Proof** We again apply identity (3,1,1,1) to  $\mathbf{v} = \nabla u$ . The boundary condition now means that  $-(\gamma \mathbf{v}) \cdot \mathbf{v} = \beta(\gamma u)$  on  $\Gamma$ . Thus we get

$$\begin{split} \int_{\Omega} |\Delta u|^2 \, \mathrm{d}x - \sum_{i,j=1}^n \int_{\Omega} \left| \frac{\partial^2 u}{\partial x_i \, \partial x_j} \right|^2 \, \mathrm{d}x \\ &= +2 \langle \nabla_T (\gamma u); \nabla_T \beta (\gamma u) \rangle \\ &- \int_{\Gamma} \left\{ \mathcal{B}((\gamma \mathbf{v})_T; (\gamma \mathbf{v})_T) + (\mathrm{tr} \, \mathcal{B})[(\gamma \mathbf{v}) \cdot \mathbf{v}]^2 \right\} \, \mathrm{d}\sigma. \end{split}$$

Due to the convexity of  $\Omega$ ,  $\mathcal{B}$  is nonpositive. On the other hand,  $\gamma u \in H^{3/2}(\Gamma)$ , and since  $\beta$  is uniformly Lipschitz, we also have  $\beta(\gamma u) \in H^1(\Gamma)$ . This allows one to rewrite the bracket as an integral. Consequently, we have

$$\int_{\Omega} |\Delta u|^2 dx - \sum_{i,j=1}^n \int_{\Omega} \left| \frac{\partial^2 u}{\partial x_i \partial x_j} \right|^2 dx \ge +2 \int_{\Gamma} \nabla_{\tau} (\gamma u) \cdot \nabla_{\tau} \beta(\gamma u) d\sigma.$$

The integrand on  $\Gamma$  is

$$2\nabla_{\mathbf{T}}(\gamma u)\nabla_{\mathbf{T}}\beta(\gamma u) = 2\beta'(\gamma u) |\nabla_{\mathbf{T}}(\gamma u)|^2;$$

this is a nonnegative function since  $\beta$  is nondecreasing. We conclude that

$$\sum_{i,j=1}^{n} \int_{\Omega} \left| \frac{\partial^{2} u}{\partial x_{i} \partial x_{j}} \right|^{2} dx \le \int_{\Omega} |\Delta u|^{2} dx. \tag{3.1.2.7}$$

The estimate of the remaining terms in the  $H^2(\Omega)$  norm of u is obtained, as usual, by integrating  $(-\Delta u + \lambda u)u$ . Indeed, we have

$$\int_{\Omega} (-\Delta u + \lambda u) u \, dx = \sum_{i=1}^{n} \int_{\Omega} \left| \frac{\partial u}{\partial x_{i}} \right|^{2} dx + \lambda \int_{\Omega} |u|^{2} \, dx - \int_{\Gamma} \gamma \frac{\partial u}{\partial \nu} \gamma u \, d\sigma.$$

Consequently, we have

$$\lambda \int_{\Omega} |u|^2 dx + \sum_{i=1}^n \int_{\Omega} \left| \frac{\partial u}{\partial x_i} \right|^2 dx \le ||-\Delta u + \lambda u|| ||u|| - \int_{\Omega} \beta(\gamma u) \gamma u d\sigma.$$

Since we assume  $\beta$  to be nondecreasing and  $\beta(0) = 0$ , it follows that

$$\beta(\gamma u)\gamma u \ge 0$$
 a.e.

on  $\Gamma$ . Then, we have

$$\lambda \int_{\Omega} |u|^2 dx + \sum_{i=1}^n \int_{\Omega} \left| \frac{\partial u}{\partial x_i} \right|^2 dx \le \|-\Delta u + \lambda u\| \|u\|$$

and consequently

$$||u|| \le \frac{1}{\lambda} ||-\Delta u + \lambda u||$$
 (3,1,2,8)

and

$$\sum_{i=1}^{n} \int_{\Omega} \left| \frac{\partial u}{\partial x_i} \right|^2 dx \le \frac{1}{\lambda} \| -\Delta u + \lambda u \|^2.$$
 (3,1,2,9)

The conclusion follows from inequalities (3,1,2,7) to (3,1,2,9).

Remark 3.1.2.4 Again we can drop the convexity assumption on  $\Omega$  and let  $\Omega$  be any bounded open subset of  $\mathbb{R}^n$  with a  $C^2$  boundary. Then, we

142 SECOND-ORDER PROBLEMS IN CONVEX DOMAINS

deduce from (1,5,1,2) and (3,1,1,1) the inequality

$$\|u\|_{2,2,\Omega} \le C(\lambda;\Omega) \|-\Delta u + \lambda u\|_{0,2,\Omega}$$
 (3,1,2,10)

for every  $u \in H^2(\Omega)$  such that  $-\gamma \partial u/\partial \nu = \beta(\gamma u)$  and every  $\lambda > 0$ . Here the constant  $C(\lambda, \Omega)$  depends only on  $\lambda$  and on the curvature of  $\Omega$  (or more precisely, on an upper bound for  $\mathcal{B}$ ). It is important to observe that  $C(\lambda, \Omega)$  does not depend on  $\beta$ .

Remark 3.1.2.5 A priori bounds in  $H^2$  for solutions of the Laplace operator under oblique boundary conditions are also proved in Subsection 3.2.4 in the particular case n = 2.

#### 3.1.3 A priori inequalities for more general operators

The purpose of this subsection is to extend the results of the previous subsection to the more general operators A that we introduced in Chapter 2. Here we shall no longer consider nonlinear boundary conditions. This is to avoid some very cumbersome calculations which can be found in Grisvard and Iooss (1975).

Accordingly, we consider an operator A defined by

$$Au = \sum_{i,j=1}^{n} D_i(a_{i,j}D_ju)$$

with  $a_{i,j} = a_{j,i} \in C^{0,1}(\bar{\Omega})$ . We assume again that -A is strongly elliptic; i.e. there exists  $\alpha > 0$  such that

$$\sum_{i,j=1}^{n} a_{ij}(x)\xi_{i}\xi_{j} \leq -\alpha |\xi|^{2}$$
(3,1,3,1)

for all  $x \in \overline{\Omega}$  and  $\xi \in \mathbb{R}^n$ .

We only consider here Dirichlet and Neumann boundary conditions.

**Theorem 3.1.3.1** Let  $\Omega$  be a convex, bounded open subset of  $\mathbb{R}^n$  with a  $C^2$  boundary. Then there exists a constant  $C(\Omega; A)$ , which depends only on the diameter of  $\Omega$  and on the Lipschitz norms of the coefficients  $a_{i,j}$ ,  $1 \le i, j \le n$ , such that

$$\|u\|_{2,2,\Omega} \le C(\Omega; A) \|Au\|_{0,2,\Omega}$$
 (3,1,3,2)

for all  $u \in H^2(\Omega) \cap \mathring{H}^1(\Omega)$ .

**Proof** We could again use identity (3,1,1,1) with

$$\mathbf{v} = \mathcal{A} \nabla u$$

where A is the matrix of the  $a_{i,j}$ . However, the less natural method of

proof that we shall follow here is simpler. Namely, we shall deduce inequality (3,1,3,2) directly from inequality (3,1,2,1) through the same perturbation procedure that we already used in Section 2.3.3. The main step is the following:

**Lemma 3.1.3.2** Each point  $y \in \overline{\Omega}$  has a neighbourhood  $V_y$  such that

$$\|u\|_{2,2,\Omega} \le C_{\nu}\{\|Au\|_{0,2,\Omega} + \|u\|_{1,2,\Omega}\|\} \tag{3.1,3,3}$$

for all  $u \in H^2(\Omega) \cap \mathring{H}^1(\Omega)$  whose support is contained in  $V_y$ . Furthermore, the constant  $C_y$  depends only on the diameter of  $\Omega$  and on the Lipschitz norm of the  $a_{i,j}$ . The neighbourhood  $V_y$  depends only on the Lipschitz norm of the  $a_{i,j}$ .

**Proof** As in Lemma 2.3.3.3 we freeze the coefficients of A at y. Thus, we set  $l_{i,j} = a_{i,j}(y)$ . This defines a strictly negative symmetric matrix L, and consequently there exists a nonsingular matrix R such that -RLR is the identity matrix (R is the inverse of the square root of -L.) If we set

$$v(x) = u(R^{-1}x),$$
  $g(x) = f(R^{-1}x),$ 

then the equation

$$\sum_{i,j=1}^{n} l_{i,j} D_i D_j u = f$$

is equivalent to

$$-\Delta v = \varrho$$

We can apply inequality (3,1,2,1) to v.

Precisely, our assumptions on u imply that

$$v \in H^2(R\Omega) \cap \mathring{H}^1(R\Omega)$$
.

On the other hand,  $R\Omega$  is convex and has a  $C^{1,1}$  boundary. Consequently, we have

$$||v||_{2,2,R\Omega} \le C(R\Omega) ||g||_{0,2,R\Omega}$$

Going back to the original variables, we also have

$$\|u\|_{2,2,\Omega} \le K(R,\Omega) \left\| \sum_{i,j=1}^{n} l_{i,j} D_i D_j u \right\|_{0,2,\Omega},$$
 (3,1,3,4)

where K is a continuous function of the matrix R and of the diameter of  $\Omega$ .

We compare the right-hand side in (3,1,3,4) with the norm of Au in

144 SECOND-ORDER PROBLEMS IN CONVEX DOMAINS

*L2(fJ).* Actually, we have

$$\begin{split} \sum_{i,j=1}^{n} l_{i,j} D_{i} D_{j} u - A u &= \sum_{i,j=1}^{n} D_{i} (l_{i,j} - a_{ij}) D_{j} u \\ &= \sum_{i,j=1}^{n} (l_{i,j} - a_{ij}) D_{i} D_{j} u - \sum_{i,j=1}^{n} (D_{i} a_{ij}) (D_{j} u). \end{split}$$

It follows that

$$\left\| \sum_{i,j=1}^{n} l_{i,j} D_{i} D_{j} u - A u \right\|$$

$$\leq n^{2} \left\{ \max_{x \in V_{y}} |a_{ij}(y) - a_{ij}(x)| \|u\|_{2,2,\Omega} + M \|u\|_{1,2,\Omega} \right\}, \tag{3.1,3,5}$$

where M is a common bound for the Lipschitz norms of all the a ij. From (3,1,3,4) and (3,1,3,5), it follows that H42,2,n:^^- K(R, 1l)

$$\left(\|Au\|_{0,2,\Omega}+Mn^{2}\left\{\max_{x\in V_{y}}|x-y|\|u\|_{2,2,\Omega}+\|u\|_{1,2,\Omega}\right\}\right).$$

The inequality (3,1,3,3) follows by choosing the neighbourhood V y small enough to ensure that

$$|x-y| \leq \frac{1}{2K(R,\Omega)Mn^2}$$

for all x E V.

The proof of Lemma 3.1.3.2 is complete. The claim in Theorem 3.1.3.1 follows easily with the aid of a partition of the unity on 11 n

We turn now to the Neumann problem.

*Theorem 3.1.3.3 Let Q be a convex, bounded open* subset *of* ll with a *C2 boundary. Then there* exists a *constant C(A, A),* which *depends* only on *A, a t and the C°' <sup>1</sup> norm of the* aij, *such that*

$$||u||_{2,2,\Omega} \le C(\lambda, A) ||Au + \lambda u||_{0,2,\Omega}$$
 (3,1,3,6)

*for all u E H2(Q) such* that *— y aulavA = 0 on 1, and* all A >0.

*Proof* We first apply identity (3,1,1,1) to

$$\mathbf{v} = \mathcal{A} \, \nabla u$$

where is the matrix of the ai;. We observe that

$$Au = \text{div } \mathbf{v} \quad \text{in } \Omega$$

t We recall that a is the ellipticity constant which occurs in (3,1,3,1).

and that

$$\gamma \frac{\partial u}{\partial \nu_{A}} = \sum_{i,j=1}^{n} \nu^{i} a_{ij} \gamma \frac{\partial u}{\partial x_{j}} = (\gamma \mathbf{v}) \cdot \mathbf{v} \quad \text{on } \Gamma$$

Accordingly, we have

$$\int_{\Omega} |Au|^2 dx - \sum_{i,j=1}^n \int_{\Omega} \frac{\partial v_i}{\partial x_j} \frac{\partial v_j}{\partial x_i} dx = -\int_{\Gamma} \mathcal{B}((\gamma \mathbf{v})_T; (\gamma \mathbf{v})_T) d\sigma \ge 0$$
(3,1,3,7)

since  $\Omega$  is assumed to be convex.

We then use the following lemma, whose proof is postponed to the completion of the proof of Theorem 3.1.3.3 (cf. also Lemma 7.1, p. 152 in Ladyzhenskaia and Ural'ceva (1968)).

**Lemma 3.1.3.4** The following inequality holds for all  $u \in H^2(\Omega)$ :

$$\alpha^{2} \sum_{i,j=1}^{n} \left| \frac{\partial^{2} u}{\partial x_{i} \partial x_{j}} \right|^{2} \leq \sum_{i,j,k,l=1}^{n} a_{i,k} a_{j,l} \frac{\partial^{2} u}{\partial x_{i} \partial x_{k}} \frac{\partial^{2} u}{\partial x_{i} \partial x_{l}}$$
(3,1,3,8)

a.e. in  $\Omega$ .

From (3,1,3,8) it follows that

$$\alpha^{2} \sum_{i,j=1}^{n} \left| \frac{\partial^{2} u}{\partial x_{i} \partial x_{j}} \right|^{2} \leq \sum_{i,j=1}^{n} \frac{\partial v_{i}}{\partial x_{i}} \frac{\partial v_{j}}{\partial x_{i}} + 2 \sum_{i,i,k,l=1}^{n} \left| a_{i,k} \frac{\partial^{2} u}{\partial x_{i} \partial x_{k}} \frac{\partial a_{i,l}}{\partial x_{i}} \frac{\partial u}{\partial x_{i}} \right|$$

a.e. in  $\Omega$ . Integrating, we have

$$\alpha^{2} \sum_{i,j=1}^{n} \int_{\Omega} \left| \frac{\partial^{2} u}{\partial x_{i} \, \partial x_{j}} \right|^{2} dx \leq \sum_{i,j=1}^{n} \int_{\Omega} \frac{\partial v_{i}}{\partial x_{j}} \frac{\partial v_{j}}{\partial x_{i}} dx + 2n^{4} M^{2} \int_{\Omega} \sum_{i=1}^{n} \left| \frac{\partial u}{\partial x_{i}} \right| \sum_{i,j=1}^{n} \left| \frac{\partial^{2} u}{\partial x_{i} \, \partial x_{j}} \right| dx,$$

where M is a common bound for the  $C^{0,1}$  norms of all the  $a_{ij}$ . This, together with inequality (3,1,3,7), implies:

$$\alpha^{2} \sum_{i,j=1}^{n} \int_{\Omega} \left| \frac{\partial^{2} u}{\partial x_{i} \partial x_{j}} \right|^{2} dx$$

$$\leq \int_{\Omega} |Au|^{2} dx + 2n^{4} M^{2} \int_{\Omega} \sum_{i=1}^{n} \left| \frac{\partial u}{\partial x_{i}} \right| \sum_{i,j=1}^{n} \left| \frac{\partial^{2} u}{\partial x_{i} \partial x_{j}} \right| dx$$

$$\leq \int_{\Omega} |Au|^{2} dx + \frac{\alpha^{2}}{2} \sum_{i,j=1}^{n} \int_{\Omega} \left| \frac{\partial^{2} u}{\partial x_{i} \partial x_{j}} \right|^{2} dx + 2 \frac{n^{8} M^{4}}{\alpha^{2}} \sum_{i=1}^{n} \int_{\Omega} \left| \frac{\partial u}{\partial x_{i}} \right|^{2} dx.$$

146

Thus we get

$$\alpha^{2} \sum_{i,j=1}^{n} \int_{\Omega} \left| \frac{\partial^{2} u}{\partial x_{i} \partial x_{j}} \right|^{2} dx \leq 2 \int_{\Omega} |Au|^{2} dx + 4 \frac{n^{2} M^{4}}{\alpha^{2}} \sum_{i=1}^{n} \int_{\Omega} \left| \frac{\partial u}{\partial x_{i}} \right|^{2} dx.$$

$$(3,1,3,9)$$

The estimate of the remaining terms in the norm of u in  $H^2(\Omega)$  is the classical one. Indeed, we have

$$\int_{\Omega} (Au + \lambda u)u \, dx = \sum_{i,j=1}^{n} \int_{\Omega} a_{ij} \frac{\partial u}{\partial x_{i}} \frac{\partial u}{\partial x_{j}} \, dx + \lambda \int_{\Omega} |u|^{2} \, dx$$

and consequently

$$\lambda \|u\|^2 + \alpha \sum_{i=1}^n \|D_i u\|^2 \le \|Au + \lambda u\| \|u\|.$$

It follows that

$$||u|| \le \frac{1}{\lambda} ||Au + \lambda u||$$
 (3,1,3,10)

and that

$$\sum_{i=1}^{n} \|D_{i}u\|^{2} \leq \frac{1}{\alpha \lambda} \|Au + \lambda u\|^{2}.$$
 (3,1,3,11)

Adding inequalities (3,1,3,9) to (3,1,3,11), we obtain (3,1,3,6). Indeed, we have

$$||u||_{2,2,\Omega}^{2} = ||u||^{2} + \sum_{i=1}^{n} ||D_{i}u||^{2} + \sum_{i,j=1}^{n} ||D_{i}D_{j}u||^{2}$$

$$\leq \left(\frac{1}{\lambda^{2}} + \frac{1}{\alpha\lambda}\right) ||Au + \lambda u||^{2} + \frac{2}{\alpha^{2}} ||Au||^{2} + \frac{4}{\alpha\lambda} \frac{n^{2}M^{4}}{\alpha^{4}} ||Au + \lambda u||^{2}$$

$$\leq \left(\frac{1}{\lambda^{2}} + \frac{1}{\alpha\lambda} + \frac{4n^{2}M^{4}}{\lambda\alpha^{5}} + \frac{8}{\alpha^{2}}\right) ||Au + \lambda u||^{2}. \quad \blacksquare$$

Proof of Lemma 3.1.3.4 By density, it is enough to prove inequality (3,1,3,8) for  $u \in C^2(\bar{\Omega})$ . At a particular fixed point x, let  $\lambda_1, \ldots, \lambda_n$  be the eigenvalues of the matrix whose entries are the  $a_{ij}$ . Also, let  $y_1, \ldots, y_n$  be a new system of orthogonal axes which diagonalize this matrix. The inequality (3,1,3,8) is equivalent to

$$\alpha^2 \sum_{i,j=1} \left| \frac{\partial^2 u}{\partial y_i \, \partial y_j} \right|^2 \leq \sum_{i,j=1}^n \lambda_i \lambda_j \left| \frac{\partial^2 u}{\partial y_i \, \partial y_j} \right|^2.$$

This is evident since all the eigenvalues are  $\leq -\alpha$ .

#### 3.2 Boundary value problems in convex domains

For some of the boundary value problems introduced at the beginning of Chapter 2, we now have two kinds of results. First an existence and uniqueness result for a solution in  $H^2(\Omega)$  provided  $\Omega$  is bounded and has a  $C^{1,1}$  boundary (see Section 2.4 mainly). On the other hand, we proved (in Section 3.1) a priori bounds for solutions in  $H^2(\Omega)$ , where the constants depend very weakly on  $\Omega$  provided it is convex and has a  $C^2$  boundary. In most of the inequalities the constants do not depend on the curvature of  $\Gamma$ , i.e. on the fact that  $\Gamma$  is  $C^{1,1}$ . This will allow us to take limits with respect to  $\Omega$ , i.e. to let  $\Omega$  vary among convex domains. Thus we shall extend our previous results to general bounded convex domains.

The first result of this kind is due to Kadlec (1964) and concerns the Dirichlet problem. The extension of this result to other boundary conditions has been achieved in Grisvard and Iooss (1975).

#### 3.2.1 Linear boundary conditions

The possibility of approximating a general convex domain by domains with  $C^2$  boundaries follows easily from the results in Eggleston (1958).

**Lemma 3.2.1.1** Let  $\Omega$  be a convex, bounded and open subset of  $\mathbb{R}^n$ . Then for every  $\varepsilon > 0$ , there exist two convex open subsets  $\Omega_1$  and  $\Omega_2$  in  $\mathbb{R}^n$  such that

- (a)  $\Omega_1 \subset \Omega \subset \Omega_2$
- (b)  $\Omega_i$  has a  $C^{\frac{1}{2}}$  boundary  $\Gamma_i$ , j = 1, 2.
- (c)  $d(\Gamma_1, \Gamma_2) \leq \varepsilon$ ,

where  $d(\Gamma_1, \Gamma_2)$  denotes the distance from  $\Gamma_1$  to  $\Gamma_2$ .

This lemma allows us to approximate a given  $\Omega$  either from the inside or from the outside by a domain with a smoother boundary. The inside approximation is more convenient for studying the Dirichlet boundary condition while the outside approximation is more suitable for dealing with boundary conditions of the Neumann type. By the way, we recall that we already proved in Section 1.2 that a bounded convex open subset of  $\mathbb{R}^n$  always has a Lipschitz boundary.

In the following results A denotes the same operator as in 3.1.3, fulfilling the assumption (3,1,3,1).

**Theorem 3.2.1.2** Let  $\Omega$  be a convex, bounded and open subset of  $\mathbb{R}^n$ . Then for each  $f \in L_2(\Omega)$ , there exists a unique  $u \in H^2(\Omega)$ , the solution of

$$\begin{cases} Au = f & \text{in } \Omega \\ \gamma u = 0 & \text{on } \Gamma. \end{cases}$$
 (3,2,1,1)

**Proof** We choose a sequence  $\Omega_m$ ,  $m=1,2,\ldots$  of convex open subsets of  $\mathbb{R}^n$  with  $C^2$  boundaries  $\Gamma_m$  such that  $\Omega_m \subseteq \Omega$  and  $d(\Gamma_m,\Gamma)$  tends to zero as  $m \to +\infty$ . We consider the solution  $u_m \in H^2(\Omega_m)$  of the Dirichlet problem in  $\Omega_m$ , i.e.

$$\begin{cases} Au_m = f & \text{in } \Omega_m \\ \gamma_m u_m = 0 & \text{on } \Gamma_m, \end{cases}$$
 (3,2,1,2)

where  $\gamma_m$  denotes the trace operator on  $\Gamma_m$ ,  $m = 1, 2, \dots$  Such a solution  $u_m$  exists by Theorem 2.2.2.3.

It follows from Theorem 1.5.1.5 that  $u_m \in \tilde{H}^1(\Omega_m)$ ; in other words, we have  $\tilde{u}_m \in H^1(\mathbb{R}^n)$ . Then from Theorem 3.1.3.1 we know that there exists a constant C such that

$$\|u_m\|_{2,2,\Omega_m} \le C.$$
 (3,2,1,3)

This implies that  $\tilde{u}_m$  is a bounded sequence in  $H^1(\mathbb{R}^n)$ , and in addition that

$$v_{m,i,j} = (D_i D_i u_m)^{\sim}, \qquad m = 1, 2, ...$$

are bounded sequences in  $L_2(\mathbb{R}^n)$  for  $1 \le i, j \le n$ . Consequently there exist  $U \in H^1(\mathbb{R}^n)$  and  $V_{i,j} \in L_2(\mathbb{R}^n)$  and a suitable increasing sequence of integers  $m_k$ ,  $k = 1, 2, \ldots$  such that

$$\begin{cases} \tilde{u}_{m_k} \to U & \text{weakly in } H^1(\mathbb{R}^n), \quad k \to \infty \\ v_{m,i,j} \to V_{i,j} & \text{weakly in } L_2(\mathbb{R}^n), \quad k \to \infty. \end{cases}$$

First, we shall check that the restriction u of U to  $\Omega$  is solution of the Dirichlet problem in  $\Omega$ . Indeed we have  $u \in H^1(\Omega)$ . In addition, all the  $\tilde{u}_m$  have their support in  $\bar{\Omega}$ ; it follows that U also has its support in  $\bar{\Omega}$ , i.e.  $U = \tilde{u}$ . By Definition 1.3.2.5, this means that  $u \in \tilde{H}^1(\Omega)$  and finally Corollary 1.5.1.5 implies that  $\gamma u = 0$  on  $\Gamma$  (here the Corollary is applied with k = 0, which is possible owing to Corollary 1.2.2.3). Finally, let  $\varphi \in \mathcal{D}(\Omega)$ ; then there exists  $k(\varphi)$  such that the support of  $\varphi$  is contained in  $\Omega_{m_k}$  for all  $k \ge k(\varphi)$ . Thus for  $k \ge k(\varphi)$  we have

$$\int_{\Omega} f \varphi \, dx = \int_{\Omega_{m_k}} A u_{m_k} \varphi \, dx = -\sum_{i,j=1}^n \int_{\Omega_{m_k}} a_{ij} D_i u_{m_k} D_j \varphi \, dx$$
$$= -\sum_{i,j=1}^n \int_{\Omega} a_{ij} D_i \tilde{u}_{m_k} D_j \varphi \, dx.$$

Taking the limit in k, we obtain

$$\int_{\Omega} f \varphi \, dx = -\sum_{i,j=1}^{n} \int_{\Omega} a_{ij} D_i u D_j \varphi \, dx.$$

This identity is valid for all cp E g(Q); it means that

$$Au = f$$
 in  $\Omega$ 

in the sense of distributions.

So far we proved the existence of u E *H'(Q),* the solution of (3,2,1,1). The uniqueness of u is a classical result by the energy method (see for instance Necas (1967)). To complete the proof we have to check that the second derivatives of u are square integrable. We again let cp belong to .9(D). Then for k k (q ) , we have

$$\int_{\Omega} \tilde{u}_{m_k} D_i D_j \varphi \, dx = \int_{\Omega_{m_k}} u_{m_k} D_i D_j \varphi \, dx = \int_{\Omega_{m_k}} D_i D_j u_{m_k} \varphi \, dx = \int_{\Omega} v_{m,i,j} \varphi \, dx.$$

Taking the limit in k, we get

$$\int_{\Omega} u D_i D_j \varphi \, dx = \int_{\Omega} V_{i,j} \varphi \, dx.$$

In other words, the distributional derivative *DiDu* is the restriction of VV.i to , T; this is a square integrable function for all i, j = 1, ... , n. n

*Theorem 3.2.1.3* Let ( *be a convex, bounded and open* subset *of* D. *Then for each f E L(f2) and for each A >0 there exists a unique* u E H2(,^) which is the solution of

$$-\sum_{i,j=1}^{n} \int_{\Omega} a_{ij} D_i u D_j v \, dx + \lambda \int_{\Omega} u v \, dx = \int_{\Omega} f v \, dx$$
 (3,2,1,4)

*for* all v E H'(,fl).

Identity (3,2,1,4) is the weak form of the Neumann problem for the equation

$$Au + \lambda u = f \qquad \text{in } \Omega. \tag{3.2,1,5}$$

As we saw in the proof of Theorem 2.2.2.5, identity (3,2,1,4) is equivalent to equation (3,2,1,5) together with the boundary condition

$$\sum_{i,j=1}^{n} \nu_{i} \gamma(a_{ij} D_{j} u) = 0 \quad \text{a.e. on } \Gamma.$$
 (3,2,1,6)

This makes sense since T is Lipschitz and ai;D;u E H'(Q).

*Proof* This time, we choose a sequence ,klm, m = 1, 2,... , of bounded convex open subsets of Rn with C2 boundaries I'm such that fl C ,klm and *d (Tm, T)* tends to zero as m --\* oc. We consider the solution um E H2(Dm) of the Neumann problem in  $\Omega_m$ , i.e.

$$\begin{cases} A u_m + \lambda u_m = \tilde{f} & \text{in } \Omega_m \\ \gamma_m \frac{\partial u_m}{\partial \nu_A} = 0 & \text{on } \Gamma_m. \end{cases}$$
 (3.2.1.7)

Obviously  $\tilde{f} \in L_2(\Omega_m)$  and  $u_m$  exists by Corollary 2.2.2.6.

From Theorem 3.1.3.3, we know that there exists a constant C such that

$$\|u_m\|_{2,2,\Omega_m} \le C.$$
 (3.2.1.8)

Consequently, restricting the  $u_m$  to  $\Omega$  we obtain a bounded sequence in  $H^2(\Omega)$  and then a weakly convergent subsequence. In other words, there exists an increasing sequence of integers  $m_k$  and a function  $u \in H^2(\Omega)$  such that

$$u_{m_k}|_{\Omega} \to u$$
 weakly in  $H^2(\Omega)$ , as  $k \to \infty$ .

We now complete the proof by checking that u is a solution of (3,2,1,4). Indeed let  $v \in H^1(\Omega)$ . Since  $\Gamma$  is Lipschitz, we can apply Theorem 1.4.3.1 to find a  $V \in H^1(\mathbb{R}^n)$  such that  $V|_{\Omega} = v$ . It is clear that  $V|_{\Omega} = H^1(\Omega_m)$  and from (3,2,1,7) we deduce that

$$-\sum_{i,j,=1}^{n} \int_{\Omega_{m_k}} a_{i,j} D_i u_{m_k} D_j V \, dx + \lambda \int_{\Omega_{m_k}} u_{m_k} V \, dx = \int_{\Omega} f v \, dx.$$
 (3,2,1,9)

We shall now consider the limit of (3,2,1,9) when  $k \to \infty$ . We have first

$$\int_{\Omega_{m_k}} u_{m_k} V \, \mathrm{d}x - \int_{\Omega} uv \, \mathrm{d}x = \int_{\Omega_{m_k} \setminus \Omega} u_{m_k} V \, \mathrm{d}x + \int_{\Omega} (u_{m_k} - u)v \, \mathrm{d}x$$

and consequently

$$\begin{split} & \left| \int_{\Omega_{m_{k}}} u_{m_{k}} V \, \mathrm{d}x - \int_{\Omega} u v \, \mathrm{d}x \right| \\ & \leq \left\| u_{m_{k}} \right\|_{0,2,\Omega_{m_{k}}} \left( \int_{\Omega_{m_{k}} \setminus \Omega} V^{2} \, \mathrm{d}x \right)^{1/2} + \left\| u_{m_{k}} - u \right\|_{0,2,\Omega} \left\| V \right\|_{0,2,\Omega}. \end{split}$$

The right-hand side of this inequality converges to zero due to (3,2,1,8) and the compactness of the injection of  $H^2(\Omega)$  in  $L_2(\Omega)$  (see Theorem 1.4.3.2). In the same way, we prove that

$$\int_{\Omega_{m_i}} a_{i,j} D_i u_{m_k} D_j V \, \mathrm{d}x \to \int_{\Omega} a_{i,j} D_i u D_j v \, \mathrm{d}x$$

owing to the compactness of the injection of  $H^2(\Omega)$  in  $H^1(\Omega)$ . Summing up we obtain identity (3,2,1,4) as the limit of (3,2,1,9) when  $k \to \infty$ .

Remark 3.2.1.4 One can prove results similar to those of Theorems 3.2.1.2 and 3.2.1.3 when  $\Omega$  is a plane bounded domain with Lipschitz and piecewise  $C^2$  boundary whose angles are all convex.

#### 3.2.2 Nonlinear boundary conditions (review)

In the next subsection we shall take advantage of inequality (3,1,2,6), which concerns the nonlinear boundary condition.

$$-\gamma \frac{\partial u}{\partial \nu} = \beta(\gamma u) \quad \text{on } \Gamma$$

where  $\beta$  is a uniformly Lipschitz continuous and nondecreasing function such that  $\beta(0) = 0$ . We shall take limits with respect to  $\Omega$  and  $\beta$ . In this subsection we review some known results about monotone operators. Here we follow Brezis (1971).

Let H be a Hilbert space and A a mapping from H into the family of all subsets of H. In other words, A is a (possibly multivalued) mapping from

$$D(A) = \{x \in H; Ax \neq \emptyset\}$$

into H. A is said to be monotone if

$$(y_1 - y_2; x_1 - x_2) \ge 0,$$

 $\forall x_1, x_2 \in D(A)$  and  $y_1 \in Ax_1, y_2 \in Ax_2$ . Then A is said to be maximal monotone if it is maximal in the sense of inclusions of graphs; i.e., it admits no proper monotone extension. For each  $\lambda > 0$  we define an inverse for the multivalued mapping  $(\lambda A + I)$  as follows:

$$(\lambda A + I)^{-1} y = \left\{ x \in D(A) \mid \frac{1}{\lambda} (y - x) \in Ax \right\}.$$

It turns out that  $(\lambda A + I)^{-1}$  is univalued and is a contraction in H provided A is monotone. It was shown by Minty (1962) that A is maximal if and only if  $(\lambda A + I)$  is onto for  $\lambda > 0$ , or equivalently  $(\lambda A + I)^{-1}$  is defined everywhere.

In what follows we shall only consider monotone operators which are in some sense the gradient of a convex function. More precisely, let  $\varphi$  be a convex lower semicontinuous function from H into  $]-\infty+\infty]$ . We assume that  $\varphi$  is proper, i.e. that  $\varphi \not\equiv +\infty$ . Let

$$D(\varphi) = \{ x \in H \mid \varphi(x) < +\infty \}.$$

For  $x \in D(\varphi)$  the set

$$\partial \varphi(x) = \{ y \in H \mid \varphi(z) - \varphi(x) \geqslant (y; z - x), \quad \forall z \in D(\varphi) \}$$

is called the subdifferential of  $\varphi$  at x. It was shown by Minty (1964) that the operator  $x \mapsto \partial \varphi(x)$  is maximal monotone.

152

Following Moreau (1965), such a convex function can be approximated by smooth convex functions  $\varphi_{\lambda}$  defined for  $\lambda > 0$ , by

$$\varphi_{\lambda}(x) = \min_{z \in H} \left\{ \frac{1}{2\lambda} |x - z|^2 + \varphi(z) \right\}. \tag{3.2.2.1}$$

It turns out that  $\varphi_{\lambda}$  is convex and Frechet differentiable. Thus

$$\partial \varphi_{\lambda}(x) = \{\phi_{\lambda}'(x)\}$$

for every  $x \in H$ . In addition  $\varphi_{\lambda}(x)$  is a decreasing function of  $\lambda$  and

$$\varphi_{\lambda}(x) \rightarrow \varphi(x)$$

for every  $x \in H$  as  $\lambda \to 0$ . Finally

$$\varphi_{\lambda}'(x) = \frac{1}{\lambda} \{ x - (\lambda \ \partial \varphi + I)^{-1} x \}. \tag{3,2,2,2}$$

This is simply the so-called Yosida approximation of  $A = \partial \varphi$ , which is monotone and Lipschitz continuous with Lipschitz constant  $1/\lambda$ .

Not all maximal monotone operators are subdifferentials of convex functions; however, in the particular case when H is just the real line  $\mathbb{R}$ , this does hold. Here are two typical examples of subdifferentials of convex functions in R. First, if we assume that

$$\varphi(x) = \begin{cases} +\infty & x \neq 0 \\ 0 & x = 0 \end{cases}$$

then it is easy to check that

$$\partial \varphi(x) = \begin{cases} \emptyset & x \neq 0 \\ \mathbb{R} & x = 0. \end{cases}$$

This is a maximal monotone operator in  $\mathbb{R}$ . The Moreau approximation of  $\varphi$  is

$$\varphi_{\lambda}(x) = \frac{x^2}{2\lambda}$$

and accordingly the Yosida approximation of  $\partial \varphi$  is

$$\varphi'_{\lambda}(x) = \frac{x}{\lambda}.$$

On the other hand, let

$$\varphi(x) = \begin{cases} +\infty & x < 0 \\ 0 & x \ge 0; \end{cases}$$

then it is easy to check that

$$\partial \varphi(x) = \begin{cases} \emptyset & x < 0 \\ [-\infty, 0] & x = 0 \\ \{0\} & x > 0 \end{cases}$$

$$\varphi_{\lambda}(x) = \begin{cases} \frac{x^2}{2\lambda}, & x \leq 0 \\ 0, & x \geq 0 \end{cases}$$

$$\varphi_{\lambda}'(x) = \begin{cases} \frac{x}{\lambda}, & x \leq 0 \\ 0, & x \geq 0. \end{cases}$$

Turning back to the general case, an important existence result is the following:

**Lemma 3.2.2.1** Let  $\varphi$  be a convex, lower semi-continuous and proper function on H. Assume that  $\varphi$  is coercive, i.e. that

$$\varphi(x) \to +\infty \quad \text{when} \quad ||x|| \to +\infty.$$
 (3,2,2,3)

Then  $\varphi$  has a minimum in H. The minimum is unique when  $\varphi$  is strictly convex.

Accordingly, if  $x_0$  is such a minimum, we have

$$0 \in \partial \varphi(x_0)$$
.

This is an existence result for the subdifferential of  $\varphi$ .

*Proof of Lemma 3.2.2.1* We denote by m the g.l.b. of  $\varphi$ . There exists a sequence  $x_n$ ,  $n = 1, 2, \ldots$  of elements of H such that

$$\varphi(x_n) \to m$$

when  $n \to +\infty$ . Since  $\varphi$  is proper, we have  $m < +\infty$  and condition (3,2,2,3) implies that the sequence  $x_n$ , n = 1, 2, ... is bounded in H.

Consequently, by possibly replacing the original sequence by a suitable subsequence, we can assume that  $x_n$ , n = 1, 2, ... is weakly convergent to some limit  $x \in H$ . By the very definition of m we have

$$\varphi(x) \ge m$$
.

On the other hand, since  $\varphi$  is lower semi-continuous (for either the strong

154 SECOND-ORDER PROBLEMS IN CONVEX DOMAINS

topology or the weak topology on H), we have

$$\varphi(x) \leq \limsup_{n \to \infty} \varphi(x_n) \leq m.$$

Summing up we have proved that  $\varphi(x) = m$  and x is the desired minimum.

The uniqueness of the minimum, when  $\varphi$  is strictly convex is obvious.

We shall use this existence result as follows. We consider a maximal operator  $\beta$  in  $\mathbb{R}$  and the corresponding convex function j on  $\mathbb{R}$  such that

$$\beta = \partial j$$
.

Then we build a new convex function on  $L_2(\Omega)$  by setting

$$\varphi(v) = \begin{cases} \frac{1}{2} \int_{\Omega} |\nabla v|^2 dx + \int_{\Gamma} j(\gamma v) d\sigma \\ & \text{if } v \in H^1(\Omega) \text{ and } j(\gamma v) \in L_1(\Gamma) \\ +\infty & \text{otherwise} \end{cases}$$
(3,2,2,4)

We are looking for solutions of the following boundary value problem where c > 0,  $f \in L_2(\Omega)$  and  $\Omega$  is, say, a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary  $\Gamma$ :

$$\begin{cases} -\Delta u + cu = f & \text{in } \Omega \\ -(\gamma \nabla u) \cdot \mathbf{v} \in \beta(\gamma u) & \text{a.e. on } \Gamma \end{cases}$$
 (3,2,2,5)

The function  $\varphi$  allows a weak formulation for problem (3,2,2,5). Indeed we have this lemma.

**Lemma 3.2.2.2** Let  $u \in H^2(\Omega)$  be a solution of (3,2,2,5), then we have

$$\varphi(v) + \frac{c}{2} ||v||^2 - \int_{\Omega} fv \, dx \ge \varphi(u) + \frac{c}{2} ||u||^2 - \int_{\Omega} fu \, dx$$
 (3,2,2,6)

for all  $v \in L_2(\Omega)$ .

**Proof** The boundary condition in (3,2,2,5) implies that for  $v \in H^1(\Omega)$  such that  $j(\gamma v) \in L_1(\Gamma)$  we have

$$j(\gamma v) - j(\gamma u) \ge -(\gamma \nabla u) \cdot \boldsymbol{v}(\gamma v - \gamma u)$$

and consequently that

$$\int_{\Omega} \{j(\gamma v) - j(\gamma u)\} d\sigma \ge - \int_{\Omega} (\mathbf{v} \cdot \mathbf{\gamma} \nabla u)(\gamma v - \gamma u) d\sigma.$$

Then by the Green formula, we have

$$\int_{\Omega} f(v-u) \, \mathrm{d}x = \int_{\Omega} (-\Delta u + cu)(v-u) \, \mathrm{d}x$$

$$= -\int_{\Gamma} (\mathbf{v} \cdot \mathbf{\gamma} \, \nabla u)(\mathbf{\gamma} v - \mathbf{\gamma} u) \, \mathrm{d}\sigma$$

$$+ \int_{\Omega} \nabla u \cdot \nabla (v-u) \, \mathrm{d}x + c \int_{\Omega} u(v-u) \, \mathrm{d}x$$

and consequently

$$\int_{\Omega} f(v-u) \, \mathrm{d}x \le \int_{\Omega} \left\{ j(\gamma v) - j(\gamma u) \right\} \, \mathrm{d}\sigma + \int_{\Omega} \nabla u \cdot \nabla (v-u) \, \mathrm{d}x$$
$$+ c \int_{\Omega} u(v-u) \, \mathrm{d}x.$$

Finally, observing that

$$2u(v-u) \leqslant v^2 - u^2$$

and that

$$2 \nabla u \cdot \nabla (v - u) \leq |\nabla v|^2 - |\nabla u|^2$$

we conclude that

$$\begin{split} &\frac{1}{2} \int_{\Omega} |\nabla v|^2 \, \mathrm{d}x + \frac{c}{2} \int_{\Omega} |v|^2 \, \mathrm{d}x + \int_{\Gamma} j(\gamma v) \, \mathrm{d}\sigma - \int_{\Omega} f v \, \mathrm{d}x \\ & \geqslant &\frac{1}{2} \int_{\Omega} |\nabla u|^2 \, \mathrm{d}x + \frac{c}{2} \int_{\Omega} |u|^2 \, \mathrm{d}x + \int_{\Gamma} j(\gamma u) \, \mathrm{d}\sigma - \int_{\Omega} f u \, \mathrm{d}x. \end{split}$$

This is exactly inequality (3,2,2,6) when  $v \in H^1(\Omega)$  and  $j(\gamma v) \in L_1(\Gamma)$ . In the other cases, we have  $\varphi(v) = +\infty$  and inequality (3,2,2,6) is obvious.

In other words, we have reduced the problem of solving (3,2,2,5) to that of minimizing the function

$$v \mapsto \varphi(v) + \frac{c}{2} ||v||^2 - \int_{\Omega} fv \, dx.$$
 (3,2,2,7)

This is easily achieved, owing to the following lemma.

**Lemma 3.2.2.3** For c > 0 and  $f \in L_2(\Omega)$  the function (3,2,2,7) is convex, lower semicontinuous, proper and coercive on  $L_2(\Omega)$ , provided  $\beta(0) \ni 0$ .

**Proof** All but the coerciveness is obvious. To prove (3,2,2,3), we observe that  $j(x) \ge 0$  everywhere. Indeed, the condition that  $\partial j(0) = \beta(0) \ge 0$ 

156 SECOND-ORDER PROBLEMS IN CONVEX DOMAINS

means that the graph of j is contained in the upper half-plane. Then it follows that

$$\varphi(v) + \frac{c}{2} \|v\|^2 - \int_{\Omega} fv \, dx \ge \frac{1}{2} \int_{\Omega} |\nabla v|^2 \, dx + \frac{c}{4} \int_{\Omega} |v|^2 \, dx - \frac{1}{c} \int_{\Omega} |f|^2 dx.$$

This lower bound obviously tends to  $+\infty$  when  $||v|| \to \infty$ .

#### 3.2.3 Nonlinear boundary conditions (continued)

Let us first state the result which is the purpose of this subsection.

**Theorem 3.2.3.1** Let  $\Omega$  be a bounded convex open subset of  $\mathbb{R}^n$ . Let  $\beta$  be a maximal monotone operator on  $\mathbb{R}$  such that  $\beta(0) \ni 0$ . Then for each  $f \in L^2(\Omega)$  and for each c > 0, there exists a unique  $u \in H^2(\Omega)$  which is the solution of (3,2,2,5).

Before proving this theorem, let us take a look at some examples. Let us assume first that

$$j(x) = \begin{cases} +\infty & x \neq 0 \\ 0 & x = 0. \end{cases}$$

Then obviously we have

$$\varphi(v) = \begin{cases} \frac{1}{2} \int_{\Omega} |\nabla v|^2 dx & \text{if } v \in \mathring{H}^1(\Omega) \\ +\infty & \text{otherwise.} \end{cases}$$

Then, surprisingly enough, problem (3,2,2,5) is just a Dirichlet problem. Indeed, the boundary condition means that a.e. on  $\Gamma$ ,

$$(\gamma u, -\mathbf{v} \cdot \gamma \nabla u)$$

is a point of  $\mathbb{R}^2$ , which actually lies on the vertical axis. In other words,  $\gamma u = 0$  a.e. on  $\Gamma$  With this special choice of j, Theorem 3.2.3.1 is just a particular case of Theorem 3.2.1.2.

Let us assume now that

$$j(x) = \begin{cases} +\infty & x < 0 \\ 0 & x \ge 0. \end{cases}$$

Then we have

$$\varphi(v) = \begin{cases} \frac{1}{2} \int_{\Omega} |\nabla v|^2 \, \mathrm{d}x & \text{if } v \in H^1(\Omega) \text{ and } \gamma v \ge 0 \text{ a.e. on } \Gamma \\ +\infty & \text{otherwise.} \end{cases}$$

The boundary condition in (3,2,2,5) means that a.e. on  $\Gamma$ 

$$(\gamma u, -\mathbf{v} \cdot \gamma \nabla u) \in G$$

where G is the graph of  $\beta = \partial i$ , i.e.

$$G = \{(x, y) \in \mathbb{R}^2 \mid x \ge 0, y \le 0, x \cdot y = 0\}.$$

Accordingly we have

$$\gamma u \ge 0, \quad \mathbf{v} \cdot \mathbf{\gamma} \, \nabla u \ge 0, \quad (\gamma u)(\mathbf{v} \cdot \mathbf{\gamma} \, \nabla u) = 0$$
 (3,2,3,1)

a.e. on  $\Gamma$  and this is the famous Signorini boundary condition.

Finally let us observe that if we assume that

$$j(x) = b\frac{x^2}{2}$$

where  $b \ge 0$ , then

$$\varphi(v) = \begin{cases} \frac{1}{2} \int_{\Omega} |\nabla v|^2 dx + \frac{b}{2} \int_{\Gamma} |\gamma v|^2 d\sigma & \text{if } v \in H^1(\Omega) \\ +\infty & \text{otherwise.} \end{cases}$$

Accordingly, we have  $\beta(x) = j'(x) = bx$  and the boundary condition in (3,2,2,5) is just

$$-\mathbf{v}\cdot(\mathbf{v}\,\mathbf{\nabla}u)=b\mathbf{v}u$$
 a.e. on  $\Gamma$ .

In particular, when b = 0, this is a Neumann boundary condition and we have a particular case of Theorem 3.2.1.3.

Before proving Theorem 3.2.3.1, we need some preliminary results on the approximation of  $\Omega$ .

**Lemma 3.2.3.2** Let  $\Omega$  be a convex, bounded and open subset of  $\mathbb{R}^n$  and let  $\Omega_m$ , m = 1, 2, ... be a sequence of convex, bounded and open subsets of  $\mathbb{R}^n$  such that  $\Omega \subseteq \Omega_m$ ,  $\Omega_m$  has a  $C^2$  boundary  $\Gamma_m$  and

$$d(\Gamma_m, \Gamma) \to 0$$
 when  $m \to \infty$ .

Then, for large enough m, there exists a finite number of open subsets  $V_k$ , k = 1, 2, ..., K in  $\mathbb{R}^n$  with the following properties:

(a) For each k there exist new coordinates  $\{y_1^k, \ldots, y_n^k\}$  in which  $V_k$  is the hypercube

$$\{(y_1^k, \ldots, y_n^k) \mid -a_j^k < y_j^k < a_j^k, \qquad 1 \le j \le n\}$$

(b) For each k there exist Lipschitz functions  $\varphi^k$  and  $\varphi^k_m$  defined in

$$V'_{k} = \{(y_{1}^{k}, \dots, y_{n-1}^{k}) \mid -a_{j}^{k} < y_{j}^{k} < a_{j}^{k}, \quad 1 \le j \le n-1\}$$

and such that

$$|\varphi^{k}(z^{k})|, |\varphi^{k}_{m}(z^{k})| \leq \frac{\alpha_{n}^{k}}{2} \text{ for every } z^{k} \in V_{k}'$$

$$\Omega \cap V_{k} = \{y^{k} = (z^{k}, y_{n}^{k}) \mid y_{n}^{k} < \varphi^{k}(z^{k})\}$$

$$\Omega_{m} \cap V_{k} = \{y^{k} = (z^{k}, y_{n}^{k}) \mid y_{n}^{k} < \varphi^{k}_{m}(z^{k})\}$$

$$\Gamma \cap V_{k} = \{y^{k} = (z^{k}, y_{n}^{k}) \mid y_{n}^{k} = \varphi^{k}(z^{k})\}$$

$$\Gamma_{m} \cap V_{k} = \{y^{k} = (z^{k}, y_{n}^{k}) \mid y_{n}^{k} = \varphi^{k}_{m}(z^{k})\}$$

$$(c) \qquad \Gamma \subset \bigcup_{k=1}^{K} V_{k}, \qquad \Gamma_{m} \subset \bigcup_{k=1}^{K} V_{k}.$$

In addition  $-\phi^k$  and  $-\phi_m^k$  are convex functions,  $\phi_m^k$  is of class  $C^2$  for all large enough m and

(d)  $\varphi_m^k$  converges uniformly to  $\varphi^k$  on  $V_k'$  and there exists L such that

$$|\nabla \varphi^k(z^k)|, |\nabla \varphi_m^k(z^k)| \le L \text{ for every } z^k \in V_k', \qquad 1 \le k \le K.$$

$$(3,2,3,2)$$

Finally,  $\nabla \varphi_m^k \to \nabla \varphi^k$  a.e. in  $V_k'$ .

It follows from Corollary 1.2.2.3 that  $\Omega$  and all the  $\Omega_m$  have Lipschitz boundaries. Accordingly, properties (a) and (b) just refer to the corresponding properties in Definition 1.2.1.1. We actually just have to check that property (d) holds.

Proof of property (d) in Lemma 3.2.3.2 Since the distance from  $\Gamma$  to  $\Gamma_m$  converges to zero when  $m \to \infty$ , it follows that the distance from the graph of  $\varphi^k$  to the graph of  $\varphi^k_m$  converges to zero. This means that  $\varphi^k_m$  converges uniformly to  $\varphi^k$ .

Inequality (3,2,3,2) follows from the geometry. Indeed let us consider a fixed k and a fixed m. Let  $y^k = (z^k, \varphi_m^k(z^k))$  be a point on  $\Gamma_m \cap V^k$ , with

$$-a_i^k + \varepsilon < y_i^k < a_i^k - \varepsilon, \qquad 1 \le j \le n - 1$$

for a given  $\varepsilon > 0$ . The set

$$S = \left\{ \left( z^k, -\frac{a_n^k}{2} \right) \mid z^k \in V_k' \right\}$$

is included in  $\Omega_m$ . So is the line segment from  $y^k$  to any point of  $\partial S$ . The slope of such a line has a modulus less than or equal to  $a_n^k/\varepsilon$ . This implies that

$$|\nabla \varphi_m^k(z^k)| \leq a_n^k/\varepsilon.$$

We conclude by replacing all the  $a_i^k$ ,  $1 \le j \le n-1$  by  $a_i^k - \varepsilon$  with an

![](_page_174_Figure_3.jpeg)

Figure 3.1

 $\varepsilon > 0$  small enough to preserve the condition  $\Gamma \subset \bigcup_{k=1}^K V_k$ . Since  $d(\Gamma_m, \Gamma) \to 0$  as  $m \to +\infty$ , the condition  $\Gamma_m \subset \bigcup_{k=1}^K V_k$  is also preserved for m large enough. We can define L as follows:

$$L = \max_{k=1}^{K} a_n^k / \varepsilon.$$

Let us now complete the proof by looking at the convergence of  $\nabla \varphi_m^k$  to  $\nabla \varphi^k$ . Since  $\varphi^k$  is Lipschitz continuous, it has a gradient a.e. in  $V_k'$ . Let us consider such a point  $z \in V_k'$  such that  $\nabla \varphi^k(z)$  exists. The tangent hyperplane at  $(z, \varphi_m^k(z))$  to the graph of  $\varphi_m^k$  is above the graph of  $\varphi_m^k$ , since  $\varphi^k$  and  $\varphi_m^k$  are concave functions and  $\varphi_m^k \geqslant \varphi^k$ . In other words, we have

$$\varphi_m^k(z) + \nabla \varphi_m^k(z) \cdot (\boldsymbol{\xi} - \boldsymbol{z}) \ge \varphi^k(\boldsymbol{\xi})$$

for all  $\xi \in V'_k$ . Since  $\varphi^k$  has a gradient at z in the usual sense, it follows that

$$\varphi_m^k(z) + \nabla \varphi_m^k(z) \cdot (\boldsymbol{\xi} - \boldsymbol{z}) \geqslant \varphi^k(z) + \nabla \varphi^k(z) \cdot (\boldsymbol{\xi} - \boldsymbol{z}) - \mathcal{O}(|\boldsymbol{\xi} - \boldsymbol{z}|)$$

160 SECOND-ORDER PROBLEMS IN CONVEX DOMAINS

for all  $\xi \in V'_k$ . Then for each j = 1, 2, ..., n-1, we have

$$\varphi_m^k(z) + tD_i\varphi_m^k(z) \ge \varphi^k(z) + tD_i\varphi^k(z) + \mathcal{O}(|t|)$$

for |t| small enough. If we denote by  $\alpha_i$  and  $\beta_i$  the limits

$$\alpha_{j} = \lim_{m \to \infty} \inf D_{j} \varphi_{m}^{k}(z), \qquad \beta_{j} = \lim_{m \to \infty} \sup D_{j} \varphi_{m}^{k}(z),$$

we easily see that

cashly see that 
$$\alpha_i \ge D_j \varphi^k(z) + \mathcal{O}(1), \qquad \beta_j \le D_j \varphi^k(z) + \mathcal{O}(1).$$

This shows that

$$D_i \varphi_m^k(z) \to D_i \varphi^k(z)$$

when  $m \to \infty$  and completes the proof.

Proof of Theorem 3.2.3.1 We shall approximate  $\Omega$  by a sequence of convex open subsets  $\Omega_m$ ,  $m=1,2,\ldots$  of  $\mathbb{R}^n$  as in Lemma 3.2.3.2. We shall also approximate j by its Moreau approximation  $j_{\lambda}$ , or equivalently  $\beta$  by its Yosida approximation  $\beta_{\lambda} = j'_{\lambda}$ . Thus we start from  $u_{\lambda,m} \in L_2(\Omega_m)$ , which minimizes the functional

$$\psi_{m,\lambda}(v) = \begin{cases} \frac{1}{2} \int_{\Omega_m} |\nabla v|^2 \, \mathrm{d}x + \frac{c}{2} \int_{\Omega_m} |v|^2 \, \mathrm{d}x + \int_{\Omega_m} j_{\lambda}(\gamma_m v) \, \mathrm{d}\sigma_m - \int_{\Omega} f v \, \mathrm{d}x \\ & \text{if } v \in H^1(\Omega_m) \\ +\infty & \text{otherwise.} \end{cases}$$

We observe that since  $j'_{\lambda}$  is uniformly Lipschitz, its primitive  $j_{\lambda}$  does not grow faster than a quadratic function. Accordingly, when  $v \in H^1(\Omega_m)$ , we have  $j_{\lambda}(\gamma_m v) \in L_1(\Gamma_m)$ .

There are four main steps in the proof.

1st step We check that  $u_{\lambda,m} \in H^2(\Omega_m)$ .

2nd step We prove that  $\|u_{\lambda,m}\|_{2,2,\Omega_m}$  remains bounded uniformly in m and  $\lambda$ .

3rd step We take the limit in m.

4th step We take the limit in  $\lambda$ .

In the first step we use the fact that  $u_{\lambda,m}$  is the solution of

$$\begin{cases} -\Delta u_{\lambda,m} + c u_{\lambda,m} = \tilde{f} & \text{in } \Omega_m \\ -\gamma_m \frac{\partial u_{\lambda,m}}{\partial \nu_m} = \beta_\lambda (\gamma_m u_{\lambda,m}) & \text{on } \Gamma_m. \end{cases}$$

Indeed, we first observe that since  $\psi_{m,\lambda}(u_{\lambda,m}) < +\infty$ ,  $u_{\lambda,m}$  must belong to

 $H^1(\Omega_m)$ . Thus it is the minimum for  $\psi_{m,\lambda}$  on  $H^1(\Omega_m)$ . It is easily checked that  $\psi_{m,\lambda}$  is Frechet differentiable on  $H^1(\Omega_m)$  and consequently we have

$$\psi'_{m,\lambda}(u_{\lambda,m})=0.$$

In other words we have

$$\int_{\Omega_{m}} \nabla u_{\lambda,m} \cdot \nabla v \, dx + c \int_{\Omega_{m}} u_{\lambda,m} v \, dx + \int_{\Gamma_{m}} \beta_{\lambda} (\gamma_{m} u_{\lambda,m}) \gamma v \, d\sigma_{m}$$

$$- \int_{\Omega_{m}} f v \, dx = 0 \quad (3,2,3,3)$$

for all  $v \in H^1(\Omega_m)$ . Making use of (3,2,3,3) with only  $v \in \mathring{H}^1(\Omega_m)$ , we readily see that

$$-\Delta u_{\lambda,m} + c u_{\lambda,m} = f \quad \text{in } \Omega_m.$$

Then applying the Green formula (1,5,3,10), we rewrite (3,2,3,3) as follows:

$$-\left\langle \gamma_m \frac{\partial u_{\lambda,m}}{\partial \nu_m} ; \gamma_m v \right\rangle = \int_{\Gamma_m} \beta_{\lambda} (\gamma_m u_{\lambda,m}) \gamma v \, d\sigma_m$$

for all  $\gamma_m v \in H^{1/2}(\Gamma_m)$ . This implies the boundary condition on  $u_{\lambda,m}$ , i.e.  $-\gamma_m \partial u_{\lambda,m}/\partial v_m = \beta_\lambda(\gamma_m u_{\lambda,m})$  in the sense of  $H^{-1/2}(\Gamma_m)$ .

Let us now consider  $\beta_{\lambda}(\gamma u_{\lambda,m})$  as the Neumann data for  $u_{\lambda,m}$ . Since  $u_{\lambda,m} \in H^1(\Omega_m)$ , we have  $\gamma_m u_{\lambda,m} \in H^{1/2}(\Gamma_m)$ . Then, taking advantage of the fact that  $\beta_{\lambda}$  is uniformly Lipschitz continuous, we conclude that

$$\beta_{\lambda}(\gamma_m u_{\lambda,m}) \in H^{1/2}(\Gamma_m).$$

Now it follows from Corollary 2.2.2.6 that  $u_{\lambda,m} \in H^2(\Omega_m)$  since  $\Gamma_m$  is  $C^2$ .

The second step is just an application of Theorem 3.1.2.3. This theorem can be used here because  $\Omega_m$  is convex and has a  $C^2$  boundary, while  $\beta_{\lambda}$  is uniformly Lipschitz, non-decreasing and fulfils the condition

$$\beta_{\lambda}(0) = 0.$$

Indeed, we have  $-\beta_{\lambda}(0) = (1/\lambda)(\lambda\beta + I)^{-1}0$  and  $(\lambda\beta + I)^{-1}0 = 0$  since  $0 \in (\lambda\beta + I)(0)$ . Thus, we have

$$||u_{\lambda,m}||_{2,2,\Omega_m} \le \left(\frac{1}{c^2} + \frac{1}{c} + 4\right)^{1/2} ||f||_{0,2,\Omega}.$$
 (3,2,3,4)

 $u_{\lambda,m}$ ,  $m=1,2,\ldots$  is consequently a bounded sequence in  $H^2(\Omega)$ . By possibly considering a suitable subsequence we can therefore assume that there exists  $u_{\lambda} \in H^2(\Omega)$  such that

$$u_{\lambda,m} \to u_{\lambda}$$

weakly in  $H^2(\Omega)$  when  $m \to +\infty$ .

In the third step we take the limit in m in the equation which expresses that  $\psi_{m,\lambda}$  has a minimum at  $u_{\lambda,m}$ . Actually we have

$$\frac{1}{2} \int_{\Omega_{m}} |\nabla u_{\lambda,m}|^{2} dx + \frac{c}{2} \int_{\Omega_{m}} |u_{\lambda,m}|^{2} dx + \int_{\Gamma_{m}} j_{\lambda}(\gamma_{m} u_{\lambda,m}) d\sigma_{m} - \int_{\Omega} u_{\lambda,m} f dx$$

$$\leq \frac{1}{2} \int_{\Omega_{m}} |\nabla V|^{2} dx + \frac{c}{2} \int_{\Omega_{m}} |V|^{2} dx + \int_{\Gamma_{m}} j_{\lambda}(\gamma_{m} V) d\sigma_{m} - \int_{\Omega} V f dx$$

$$(3,2,3,5)$$

for all  $V \in H^1(\mathbb{R}^n)$ . It is easy to check that

$$\frac{1}{2} \int_{\Omega_m} |\nabla V|^2 \, \mathrm{d}x + \frac{c}{2} \int_{\Omega_m} |V|^2 \, \mathrm{d}x \to \frac{1}{2} \int_{\Omega} |\nabla V|^2 \, \mathrm{d}x + \frac{c}{2} \int_{\Omega} |V|^2 \, \mathrm{d}x.$$

Then obviously we have

$$\liminf_{m \to \infty} \int_{\Omega_m} |\nabla u_{\lambda,m}|^2 \, \mathrm{d}x \ge \lim_{m \to \infty} \int_{\Omega} |\nabla u_{\lambda,m}|^2 \, \mathrm{d}x = \int_{\Omega} |\nabla u_{\lambda}|^2 \, \mathrm{d}x$$

$$\liminf_{m \to \infty} \int_{\Omega_m} |u_{\lambda,m}|^2 \, \mathrm{d}x \ge \lim_{m \to \infty} \int_{\Omega} |u_{\lambda,m}|^2 \, \mathrm{d}x = \int_{\Omega} |u_{\lambda}|^2 \, \mathrm{d}x$$

since  $\Omega_m \supseteq \Omega$ . Also, we have

$$\int_{\Omega} f u_{m,\lambda} \, \mathrm{d}x \to \int_{\Omega} f u_{\lambda} \, \mathrm{d}x.$$

Thus the only difficult point in taking the limit in (3,2,3,5), is to prove that

$$\int_{\Gamma_m} j_{\lambda}(\gamma_m V) \, d\sigma_m \to \int_{\Gamma} j_{\lambda}(\gamma V) \, d\sigma \tag{3.2.3.6}$$

$$\liminf_{m\to\infty} \int_{\Gamma_m} j_{\lambda}(\gamma_m u_{\lambda,m}) \, d\sigma_m \ge \int_{\Gamma} j_{\lambda}(\gamma u_{\lambda}) \, d\sigma. \tag{3.2.3.7}$$

For this purpose, we fix a partition of unity on  $\Gamma$  and  $\Gamma_m$  corresponding to the covering  $V_k$ ,  $1 \le k \le K$ , introduced in Lemma 3.2.3.2, i.e. we consider  $\theta_k \in \mathcal{D}(\mathbb{R}^n)$ ,  $1 \le k \le K$ , such that  $\theta_k$  has its support in  $V_k$  and

$$1 = \sum_{k=1}^{K} \theta_k(x)$$

for all  $x \in \Gamma$  and all  $x \in \Gamma_m$  (for m large enough). We have to prove that

$$\int_{\Gamma_m} \theta_k j_{\lambda}(\gamma_m V) d\sigma_m \to \int_{\Gamma} \theta_k j_{\lambda}(\gamma V) d\sigma. \tag{3.2,3,8}$$

We drop the index k and set  $\eta = \theta j_{\lambda}(V)$ . It follows that

$$\int_{\Gamma_m} \gamma_m \eta \, d\sigma_m = \int_{V'} (\gamma_m \eta)(z, \varphi_m(z)) [1 + |\nabla \varphi_m(z)|^2]^{1/2} \, dz.$$

Clearly we have

$$(\gamma_m \eta)(z, \varphi_m(z))[1 + |\nabla \varphi_m(z)|^2]^{1/2} \rightarrow (\gamma \eta)(z, \varphi(z))[1 + |\nabla \varphi(z)|^2]^{1/2}$$

a.e. in V'. In addition, we have

$$\begin{aligned} &|(\gamma_m \eta)(z, \varphi_m(z))| \left[ 1 + |\nabla \varphi_m(z)|^2 \right]^{1/2} \\ &\leq & \left[ 1 + L^2 \right]^{1/2} \bigg\{ |(\gamma \eta)(z, \varphi(z))| + \left[ \varphi_m(z) - \varphi(z) \right]^{1/2} \\ &\quad \times \bigg[ \int_{-a/2}^{a_{m/2}} |D_n \eta(z, y)|^2 \, \mathrm{d}y \bigg]^{1/2} \bigg\}. \end{aligned}$$

Thus we have a fixed square integrable bound, and applying Lebesgue's dominated convergence theorem, we conclude that (3,2,3,8) holds.

To prove (3,2,3,7) we introduce  $U_{\lambda} \in H^2(\mathbb{R}^n)$  such that  $U_{\lambda}|_{\Omega} = u_{\lambda}$ . Then, we have

$$\begin{split} \int_{\Gamma_m} j_{\lambda}(\gamma_m u_{\lambda,m}) \, \mathrm{d}\sigma_m - \int_{\Gamma} j_{\lambda}(\gamma u_{\lambda}) \, \mathrm{d}\sigma \\ &= \int_{\Gamma_m} \left\{ j_{\lambda}(\gamma_m u_{\lambda,m}) - j_{\lambda}(\gamma_m U_{\lambda}) \right\} \mathrm{d}\sigma_m \\ &+ \int_{\Gamma} j_{\lambda}(\gamma_m U_{\lambda}) \, \mathrm{d}\sigma_m - \int_{\Gamma} j_{\lambda}(\gamma u_{\lambda}) \, \mathrm{d}\sigma. \end{split}$$

It follows from (3,2,3,6) that

$$\int_{\Gamma_m} j_{\lambda}(\gamma_m U_{\lambda}) d\sigma_m \to \int_{\Gamma} j_{\lambda}(\gamma u_{\lambda}) d\sigma.$$

Then we observe that for  $x, y \in \mathbb{R}$  we have

$$j_{\lambda}(x) - j_{\lambda}(y) \ge \beta_{\lambda}(y)(x - y)$$

and thus

$$\int_{\Gamma_{m}} \{j_{\lambda}(\gamma_{m}u_{\lambda,m}) - j_{\lambda}(\gamma_{m}U_{\lambda})\} d\sigma_{m} \ge \int_{\Gamma_{m}} \beta_{\lambda}(\gamma_{m}U_{\lambda})\{\gamma_{m}u_{\lambda,m} - \gamma_{m}U_{\lambda}\} d\sigma_{m}.$$
(3,2,3,9)

We shall show that the right-hand side of this inequality converges to zero. Indeed, we have

$$\int_{\Gamma_m} |\beta_{\lambda}(\gamma_m U_{\lambda})|^2 d\sigma_m \leq \frac{1}{\lambda^2} \int_{\Gamma_m} |\gamma_m U_{\lambda}|^2 d\sigma_m \leq \frac{K}{\lambda^2} \int_{\Omega_m} \left[ |\nabla U_{\lambda}|^2 + |U_{\lambda}|^2 \right] dx$$

164

with a constant K which does not depend on m, due to Lemma 3.2.3.3 below and Theorem 1.5.1.10.

Lemma 3.2.3.3 Under the assumptions of Lemma 3.2.3.2, there exists a Lipschitz vector field  $\mu$  defined on  $\mathbb{R}^n$  and a constant  $\delta > 0$  such that  $\mu \cdot \nu_m \ge \delta$  on  $\Gamma_m$  for all m.

We postpone the proof of this lemma until the proof of Theorem 3.2.3.1 is completed.

This shows that  $\|\beta_{\lambda}(\gamma_m U_{\lambda})\|_{0,2,\Gamma_m}$  remains bounded when  $m \to \infty$ . Then let us set

$$\eta_m = \theta_k (u_{\lambda,m} - U_{\lambda}).$$

Use local coordinates and drop k. We have

$$\int_{\Gamma_m} |\theta\{\gamma_m u_{\lambda,m} - \gamma_m U_{\lambda}\}|^2 d\sigma_m = \int_{V'} |\eta_m(z,\varphi_m(z))|^2 [1 + |\nabla \varphi_m(z)|^2]^{1/2} dz.$$

We write

$$\eta_m(z, \varphi_m(z)) = \eta_m(z, \varphi(z)) + \int_{\varphi(z)}^{\varphi_m(z)} D_n \eta_m(z, y) \, \mathrm{d}y$$

and consequently

$$\begin{aligned} |\eta_m(z, \varphi_m(z))| &\leq |\eta_m(z, \varphi(z))| \\ &+ [\varphi_m(z) - \varphi(z)]^{1/2} \left( \int_{\varphi(z)}^{\varphi_m(z)} |D_n \eta_m(z, y)|^2 \, \mathrm{d}y \right)^{1/2}. \end{aligned}$$

Thus we have

$$\begin{split} \left\{ \int_{V'} |\eta_{m}(z, \varphi_{m}(z))|^{2} \left[ 1 + |\nabla \varphi_{m}(z)|^{2} \right]^{1/2} dz \right\}^{1/2} \\ & \leq \left[ 1 + L^{2} \right]^{1/4} \left\{ \int_{V'} |\eta_{m}(z, \varphi(z))|^{2} \left[ 1 + |\nabla \varphi(z)|^{2} \right]^{1/2} dz \right\}^{1/2} \\ & + \left[ 1 + L^{2} \right]^{1/4} \max_{z \in V'} \left[ \varphi_{m}(z) - \varphi(z) \right]^{1/2} \\ & \times \left\{ \int_{V'} \int_{\sigma(z)}^{\varphi_{m}(z)} |D_{n} \eta_{m}(z, y)|^{2} dz dy \right\}^{1/2}. \end{split}$$

In other words

$$\begin{split} & \left\{ \int_{\Gamma_{m}} |\theta \gamma_{m} (u_{\lambda,m} - U_{\lambda})|^{2} d\sigma_{m} \right\}^{1/2} \\ & \leq \left[ 1 + L^{2} \right]^{1/4} \left( \left\{ \int_{\Gamma} |\theta \gamma (u_{\lambda,m} - U_{\lambda})|^{2} d\sigma \right\}^{1/2} \\ & + \max_{z \in V'} \left[ \varphi_{m}(z) - \varphi(z) \right]^{1/2} \|\theta (u_{\lambda,m} - U_{\lambda})\|_{1,2,\Omega_{m}} \right). \end{split}$$

This shows that

$$\int_{\Gamma_{m}} |\gamma_{m}(u_{\lambda,m} - U_{\lambda})|^{2} d\sigma_{m} \to 0$$

when  $m \to \infty$  since  $u_{\lambda,m} \to U_{\lambda}$  in  $H^1(\Omega)$  and  $||u_{\lambda,m}||_{1,2,\Omega_m}$  remains bounded. Summing up we have proved that

$$\int_{\Gamma_m} \beta_{\lambda}(\gamma_m U_{\lambda}) \{ \gamma_m u_{\lambda,m} - \gamma_m U_{\lambda} \} \, \mathrm{d}\sigma_m \to 0$$

and remembering (3,3,2,9), this implies (3,2,3,7).

Taking the infimum limit in m, of inequality (3,2,3,5), we eventually obtain

$$\psi_{\lambda}(u_{\lambda}) \leq \psi_{\lambda}(v) \tag{3.2,3,10}$$

for all  $v \in H^1(\Omega)$ , where  $\psi_{\lambda}$  is defined by

$$\psi_{\lambda}(v) = \frac{1}{2} \int_{\Omega} |\nabla v|^2 dx + \frac{c}{2} \int_{\Omega} |v|^2 dx + \int_{\Gamma} j_{\lambda}(\gamma v) d\sigma - \int_{\Omega} v f dx.$$

In addition, taking the limit in (3,2,3,4) we also have

$$\|u_{\lambda}\|_{2,2,\Omega} \le \left(\frac{1}{c^2} + \frac{1}{c} + 4\right)^{1/2} \|f\|_{0,2,\Omega}.$$
 (3,2,3,11)

We can now perform the *last step* of the proof. Due to (3,2,3,11) we can find a sequence  $\lambda_j$ ,  $j = 1, 2, \ldots$  such that

$$\lambda_i \to 0, \quad j \to \infty$$

and there exists  $u \in H^2(\Omega)$  such that

$$u_{\lambda_i} \to u, \quad j \to \infty$$

weakly in  $H^2(\Omega)$  and consequently strongly in  $H^{2-\epsilon}(\Omega)$  for  $\epsilon > 0$ . In addition, by the Lebesgue theorem on subsequences, we can also assume

166

that

$$\begin{cases} \gamma u_{\lambda_i} \to \gamma u, & j \to \infty \\ \mathbf{v} \cdot \gamma \nabla u_{\lambda_i} \to \mathbf{v} \cdot \gamma \nabla u, & j \to \infty \end{cases}$$

a.e. on  $\Gamma$ 

On the other hand, as in the first step of the proof, inequality (3,2,3,10) implies that

$$\begin{cases} -\Delta u_{\lambda} + c u_{\lambda} = f & \text{in } \Omega \\ -\mathbf{v} \cdot \gamma \nabla u_{\lambda} = \beta_{\lambda} (\gamma u_{\lambda}) & \text{a.e. on } \Gamma. \end{cases}$$
 (3,2,3,12)

It is easy to take the limit in this equation. We thus obviously obtain

$$-\Delta u + cu = f \quad \text{in } \Omega.$$

To take the limit in the boundary condition, we use the following trick.

**Lemma 3.2.3.4** Let  $\beta$  be a maximal monotone operator in  $\mathbb{R}$  and let  $\beta_{\lambda}$  be its Yosida approximation. Let  $x_m$ ,  $y_m$ ,  $\lambda_m$  be three sequences of real numbers such that

$$\begin{cases} x_m \to x, \ y_m \to y \\ \lambda_m \to 0 \\ y_m = \beta_{\lambda_m}(x_m). \end{cases}$$

Then

$$y \in \beta(x)$$
.

We consequently obtain

$$-\mathbf{v} \cdot \mathbf{\gamma} \nabla \mathbf{u} \in \boldsymbol{\beta}(\mathbf{\gamma}\mathbf{u})$$

a.e. on  $\Gamma$ . Summing up,  $u \in H^2(\Omega)$  is the solution of problem (3,2,2,5). The uniqueness of u follows from Lemma 3.2.2.2 since the functional which is minimized there is strictly convex (see also Lemma 3.2.2.3). This completes the proof of Theorem 3.2.3.1.

**Proof of Lemma 3.2.3.3** We fix a point  $x_0 \in \Omega$  and a ball B of radius  $\rho > 0$  and centre at  $x_0$  such that  $B \subseteq \Omega$ . Then we fix a function  $\theta \in \mathfrak{D}(\mathbb{R}^n)$  such that  $\theta \equiv 1$  on all  $\Omega_m$  for large enough m. Then we can define  $\mu$  by

$$\boldsymbol{\mu}(x) = \boldsymbol{\theta}(x)(\mathbf{x} - \mathbf{x}_0).$$

It is clear that the angle of  $\mu$  with  $\nu_m$  is less than or equal to

$$\left\{\frac{\pi}{2} - \arcsin\frac{\rho}{|x - x_0|}\right\}$$

at  $x \in \Gamma_m$ . Consequently we have

$$\boldsymbol{\mu} \cdot \boldsymbol{\nu}_m \geq |\boldsymbol{\mu}| \frac{\rho}{|\boldsymbol{x} - \boldsymbol{x}_0|}.$$

Thus a  $\delta > 0$  obviously exists and on the other hand, it is easy to check that  $\mu$  is Lipschitz continuous.

*Proof of Lemma 3.2.3.4* Using the definition of  $\beta_{\lambda}$  it is easy to check that

$$y_m \in \beta(x_m - \lambda_m y_m).$$

Since  $y_m \to y$  and  $x_m - \lambda_m y_m \to x$ , it follows that

$$y \in \beta(x)$$

since the graph of  $\beta$  is closed (by maximality).

#### 3.2.4 Oblique boundary conditions

Here, for the sake of simplicity, we shall restrict our purpose to boundary value problems in a plane domain  $\Omega$ . Thus let us assume that  $\Omega$  is a bounded convex open subset of  $\mathbb{R}^2$ ; its boundary is a closed Lipschitz curve  $\Gamma$  along which the arc-length s is well defined. We assume, in addition, that c is a given Lipschitz function in  $\bar{\Omega}$ . We shall solve the following problem: for a given  $f \in L_2(\Omega)$  and  $\lambda > 0$ , find  $u \in H^2(\Omega)$  which is a solution of

$$\begin{cases}
-\Delta u + \lambda u = f & \text{in } \Omega \\
-\gamma \frac{\partial u}{\partial \nu} = c \frac{\partial}{\partial s} \gamma u & \text{on } \Gamma
\end{cases}$$
(3,2,4,1)

The main result below is due to Moussaoui (1974).

**Theorem 3.2.4.1** Let  $\Omega$  be a bounded convex open subset of  $\mathbb{R}^2$  and let  $c \in C^{0,1}(\overline{\Omega})$ . Then there exists  $\lambda_0$  such that for each  $\lambda > \lambda_0$  and for each  $f \in L_2(\Omega)$  there exists a unique  $u \in H^2(\Omega)$  which is a solution of

$$\int_{\Omega} \nabla u \cdot \nabla v \, dx + \lambda \int_{\Omega} uv \, dx = \int_{\Omega} fv \, dx - \left\langle c \frac{\partial}{\partial s} \gamma u; \gamma v \right\rangle$$
 (3,2,4,2)

for all  $v \in H^1(\Omega)$ .

Of course, identity (3,2,4,2) is a weak form for problem (3,2,4,1). Indeed, applying the Green formula of Theorem 1.5.3.1, it is easy to check that for  $u \in H^2(\Omega)$ , (3,2,4,1) and (3,2,4,2) are equivalent.

Exactly as we did in the proof of Theorem 3.2.3.1, we shall approximate  $\Omega$  by a decreasing sequence of smoother convex domains  $\Omega_m$ ,  $m=1,2,\ldots$  (see Lemma 3.2.3.2). In each of these domains, we shall solve a problem similar to (3,2,4,1). Then it will be possible to take the limit in m with the help of an a priori estimate. Let us first prove this estimate.

**Theorem 3.2.4.2** Let  $\Omega$  be a bounded convex open subset of  $\mathbb{R}^2$  with a  $C^2$  boundary. Let  $c \in C^{0,1}(\overline{\Omega})$  and  $\mu \in C^{0,1}(\overline{\Omega})^2$  be such that  $\mu \cdot \nu \ge \delta > 0$  everywhere on  $\Gamma$ ; then there exists  $\lambda_0$  and k such that

$$||u||_{2,2,\Omega} \le k ||-\Delta u + \lambda u||_{0,2,\Omega} \tag{3.2.4.3}$$

for all  $u \in H^2(\Omega)$ , such that  $-\gamma \partial u/\partial \nu = c \partial (\gamma u)/\partial s$  on  $\Gamma$ . Moreover, k and  $\lambda_0$  depend only on  $\delta$ , the Lipschitz norm of  $\mu$  and  $\max_{\Gamma} |\partial c/\partial s|$ .

Note that the existence of  $\mu$  follows from Lemma 1.5.1.9.

**Proof** We apply again identity (3,1,1,1) to  $\mathbf{v} = \nabla u$ . The two-dimensional version of this identity and the convexity of  $\Omega$ , imply that<sup>†</sup>

$$\int_{\Omega} |\operatorname{div} \mathbf{v}|^2 \, \mathrm{d}x - \sum_{i,j=1}^2 \int_{\Omega} \frac{\partial v_i}{\partial x_j} \frac{\partial v_j}{\partial x_i} \, \mathrm{d}x \ge -2 \int_{\Gamma} (\gamma \mathbf{v})_{\mathrm{T}} \, \mathrm{d}(\gamma \mathbf{v})_{\nu}.$$

In other words, we have

$$\int_{\Omega} |\Delta u|^2 dx \quad \sum_{i,j=1}^2 \int_{\Omega} \left| \frac{\partial^2 u}{\partial x_i \partial x_j} \right|^2 dx \ge -2 \int_{\Gamma} \frac{\partial}{\partial s} (\gamma u) d\left( \gamma \frac{\partial u}{\partial \nu} \right).$$

Due to the boundary condition, we have

$$-2\int_{\Gamma} \frac{\partial}{\partial s} (\gamma u) d\left(\gamma \frac{\partial u}{\partial \nu}\right) = 2\int_{\Gamma} \frac{\partial}{\partial s} (\gamma u) d\left(c \frac{\partial}{\partial s} \gamma u\right) = \int_{\Gamma} \left|\frac{\partial}{\partial s} \gamma u\right|^{2} dc.$$

Denoting by M an upper bound for  $|\partial c/\partial s|$  on  $\Gamma$ , we have

$$\sum_{i,j=1}^{2} \int_{\Omega} \left| \frac{\partial^{2} u}{\partial x_{i} \partial x_{j}} \right|^{2} dx \le \int_{\Omega} |\Delta u|^{2} dx + M \int_{\Gamma} \left| \frac{\partial}{\partial s} \gamma u \right|^{2} ds. \tag{3.2,4.4}$$

Besides this, we have as usual

$$\int_{\Omega} (-\Delta u + \lambda u) u \, dx = \int_{\Omega} |\nabla u|^2 \, dx + \lambda \int_{\Omega} |u|^2 \, dx - \int_{\Gamma} \gamma \frac{\partial u}{\partial \nu} \gamma u \, dx.$$

It follows from the boundary condition that

$$-\int_{\Gamma} \gamma \frac{\partial u}{\partial \nu} \gamma u \, ds = \int_{\Gamma} c \left( \frac{\partial}{\partial s} \gamma u \right) \gamma u \, ds = -\frac{1}{2} \int_{\Gamma} \frac{\partial c}{\partial s} |\gamma u|^2 \, ds$$

<sup>†</sup> For any vector field  ${\bf a},\,a_{\nu}$  and  $a_{T}$  are the normal and tangential components of  ${\bf a}$  on  $\Gamma$ .

and consequently

$$\int_{\Omega} |\nabla u|^2 \, \mathrm{d}x + \lambda \int_{\Omega} |u|^2 \, \mathrm{d}x$$

$$= \int_{\Omega} (-\Delta u + \lambda u) u \, \mathrm{d}x + \frac{1}{2} \int_{\Gamma} \frac{\partial c}{\partial s} |\gamma u|^2 \, \mathrm{d}s$$

$$\leq ||-\Delta u + \lambda u|| \, ||u|| + M \int_{\Gamma} |\gamma u|^2 \, \mathrm{d}\sigma$$

$$\leq ||-\Delta u + \lambda u|| \, ||u|| + MK \, \sqrt{\varepsilon} \int_{\Omega} |\nabla u|^2 \, \mathrm{d}x + \frac{MK}{\sqrt{\varepsilon}} \int_{\Omega} |u|^2 \, \mathrm{d}x$$

owing to inequality (1,5,1,2) of Lemma 1.5.1.10. Choosing  $\varepsilon$  small enough (e.g. such that  $Mk \sqrt{\varepsilon} \leq \frac{1}{2}$  and  $\lambda_0 \geq (MK/\sqrt{\varepsilon}) + 1$ , we finally obtain

$$\frac{1}{2} \|\nabla u\|^2 + \|u\|^2 \le \|-\Delta u + \lambda u\|^2. \tag{3.2.4.5}$$

On the other hand, we have

$$\left|\frac{\partial}{\partial s} \gamma u\right| \leq |\gamma \nabla u|$$

consequently it follows from inequality (3,2,4,4) that

$$\begin{split} & \sum_{i,j=1}^2 \int_{\Omega} \left| \frac{\partial^2 u}{\partial x_i \, \partial x_j} \right|^2 \mathrm{d}x \leq \int_{\Omega} |\Delta u|^2 \, \mathrm{d}x + M \int_{\Gamma} |\gamma \, \nabla u|^2 \, \mathrm{d}s \\ & \leq \int_{\Omega} |\Delta u|^2 \, \mathrm{d}x + MK \, \sqrt{\varepsilon} \sum_{i,j=1}^2 \int_{\Omega} \left| \frac{\partial^2 u}{\partial x_i \, \partial x_j} \right|^2 \mathrm{d}x + \frac{MK}{\sqrt{\varepsilon}} \|\nabla u\|^2 \end{split}$$

by a new application of Theorem 1.5.1.10. Then we have

$$\sum_{i,j=1}^{2} \int_{\Omega} \left| \frac{\partial^{2} u}{\partial x_{i} \partial x_{j}} \right|^{2} dx \le 2 \int_{\Omega} |\Delta u|^{2} dx + L \|\nabla u\|^{2}$$
(3,2,4,6)

where  $L = MK/\sqrt{\varepsilon}$ ,  $MK\sqrt{\varepsilon} = \frac{1}{2}$ .

Combining inequalities (3,2,4,5) and (3,2,4,6), we plainly obtain the desired result.

Remark 3.2.4.3 The same proof can be worked out, without the convexity assumption on  $\Omega$ ; of course in that case, the constants k and  $\lambda_0$  will also depend on the curvature of  $\Gamma$ .

Remark 3.2.4.4 We can combine the two kinds of computations that we did in the proof of Theorems 3.1.2.3 and 3.2.4.2 to deal with the more complicated boundary condition

$$-\gamma \frac{\partial u}{\partial u} = c \frac{\partial}{\partial s} \gamma u + \beta (\gamma u)$$

170

assuming that  $\beta$  is a nondecreasing Lipschitz function. Unfortunately, we shall not be able to take advantage of such a result in what follows.

We now turn to the

**Proof of Theorem 3.2.4.1** We use a sequence of plane convex domains  $\Omega_m$ , m = 1, 2, ..., as in Lemma 3.2.3.2. We extend c to the whole plane in such a fashion that

$$c \in C^{0,1}(\mathbb{R}^2)$$
.

Consequently c is defined on  $\Gamma_m$ . Then, in each  $\Omega_m$ , we consider  $u_m \in H^2(\Omega_m)$ , a solution of

$$\begin{cases} -\Delta u_m + \lambda u_m = \tilde{f} & \text{in } \Omega_m \\ -\gamma_m \frac{\partial u_m}{\partial \nu_m} = c \frac{\partial}{\partial s_m} \gamma_m u_m & \text{on } \Gamma_m. \end{cases}$$
(3,2,4,7)

The existence of such a function  $u_m$  follows from Theorem 2.4.2.7 for  $\lambda > 0$ . We shall now use inequality (3,2,4,3) to show that  $||u_m||_{2,2,\Omega}$  remains bounded when  $m \to \infty$ .

Here, we take advantage of Lemma 3.2.3.3 again. Obviously  $\max_{\Gamma_m} |\partial c/\partial s_m|$  remains bounded uniformly in m. This implies the existence of constants k and  $\lambda_0$ , both independent of m, such that

$$\|u_m\|_{2,2,\Omega_m} \le k \|f\|_{0,2,\Omega_m} \tag{3,2,4,8}$$

provided  $\lambda \ge \lambda_0$ .

Now we proceed as in the proof of Theorem 3.2.3.1. We first observe that (3,2,4,7) implies this:

$$\int_{\Omega_{m}} \nabla u_{m} \cdot \nabla V \, dx + \lambda \int_{\Omega_{m}} u_{m} V \, dx = \int_{\Omega} f V \, dx - \int_{\Gamma_{m}} c \frac{\partial}{\partial s_{m}} \gamma_{m} u_{m} \gamma_{m} V \, ds_{m}$$
(3,2,4,9)

for all  $V \in H^1(\Omega_m)$ .

On the other hand by inequality (3,2,4,8), there exists a subsequence of the sequence  $u_m$ ,  $m=1,2,\ldots$  which is weakly convergent in  $H^2(\Omega)$  to some  $u \in H^2(\Omega)$ . Let us again denote this subsequence  $u_m$ ,  $m=1,2,\ldots$  for the sake of avoiding further complications in the notation. We shall show that u is the desired solution of (3,2,4,2); this will be achieved by taking the limit in identity (3,2,4,9).

First let  $V \in C^1(\mathbb{R}^2)$  be fixed. We shall set  $v = V|_{\Omega}$ . Exactly as in the proof of Theorem 3.2.1.3 we show that

$$\int_{\Omega_m} \nabla u_m \cdot \nabla V \, \mathrm{d}x \to \int_{\Omega} \nabla u \cdot \nabla v \, \mathrm{d}x \tag{3,2,4,10}$$

and that

$$\int_{\Omega_m} u_m V \, \mathrm{d}x \to \int_{\Omega} uv \, \mathrm{d}x. \tag{3,2,4,11}$$

To complete the proof, we shall show that

$$\int_{\Gamma_{m}} c \frac{\partial}{\partial s_{m}} \gamma_{m} u_{m} \gamma_{m} V \, ds_{m} = \int_{\Gamma_{m}} c (\gamma_{m} \nabla u_{m})_{T_{m}} \gamma_{m} V \, ds_{m}$$

$$\rightarrow \int_{\Gamma} c (\gamma \nabla u)_{T} \gamma v \, ds = \left\langle c \frac{\partial}{\partial s} \gamma u; \gamma v \right\rangle. \tag{3.2.4.12}$$

This requires much more care. First we fix a partition of unity  $(\theta_k, 1 \le k \le K)$  on  $\Gamma$  and  $\Gamma_m$  corresponding to the covering  $V_k$ ,  $1 \le k \le K$  in Lemma 3.2.3.2. The limit in (3,2,4,12) will follow by adding these limits:

$$\int_{\Gamma_m} \theta_k c(\gamma_m \nabla u_m)_{T_m} V \, \mathrm{d}s_m \to \int_{\Gamma} \theta_k c(\gamma \nabla u)_T v \, \mathrm{d}s. \tag{3.2,4,13}$$

We shall use the local coordinates of Lemma 3.2.3.2 in each  $V_k$ . Let us first introduce some auxiliary notation:

$$\mathbf{w}_{m} = \nabla u_{m}, \qquad \eta = \theta_{k} c V.$$

From now on, we shall drop the subscript k to simplify the notation. In addition, we consider a function  $U \in H^2(\mathbb{R}^2)$  such that  $U|_{\Omega} = u$  (see Theorem 1.4.3.1) we shall consider separately

$$\int_{\Gamma_m} \eta [\gamma_m (\mathbf{w}_m - \mathbf{W})]_{T_m} \, \mathrm{d} s_m$$

and

$$\int_{\Gamma_m} \eta[\gamma_m \mathbf{W}]_{T_m} ds_m - \int_{\Gamma} \eta[\gamma \mathbf{W}]_{\Gamma} ds$$

where  $\mathbf{W} = \nabla U$ .

According to the notation in Lemma 3.2.3.2, we have (after dropping the k):

$$\left| \int_{\Gamma_m} \eta [\gamma_m(\mathbf{w}_m - \mathbf{W})]_{T_m} \, \mathrm{d}s_m \right| \leq a \int_{\Gamma_m \cap V} |\gamma_m(\mathbf{w}_m - \mathbf{W})| \, \mathrm{d}s_m$$

$$= a \int_{V'} |\gamma_m(\mathbf{w}_m - \mathbf{W})(z, \varphi_m(z))|$$

$$\times \sqrt{(1 + \varphi_m'(z)^2)} \, \mathrm{d}z$$

where a does not depend on m. Owing to (3,2,3,2) we have

$$\begin{split} &\left| \int_{\Gamma_{m}} \eta[\gamma_{m}(\mathbf{w}_{m} - \mathbf{W})]_{T_{m}} \, \mathrm{d}s_{m} \right| \\ & \leq a \, \sqrt{(1 + L^{2})} \bigg\{ \int_{V'} \left| \gamma(\mathbf{w}_{m} - \mathbf{W})(z, \varphi(z)) \right| \, \mathrm{d}z \\ & + \int_{V'} \left| \gamma_{m}(\mathbf{w}_{m} - \mathbf{W})(z, \varphi_{m}(z)) - \gamma(\mathbf{w}_{m} - \mathbf{W})(z, \varphi(z)) \right| \, \mathrm{d}z \bigg\} \\ & \leq b \, \| \gamma(\nabla u_{m} - \nabla u) \|_{0, 2, \Gamma} + a \, \sqrt{(1 + L^{2})} \\ & \times \int_{V'} \left\{ \int_{\varphi(z)}^{\varphi_{m}(z)} \left| D_{y}(\mathbf{w}_{m} - \mathbf{W})(z, y) \right| \, \mathrm{d}y \right\} \, \mathrm{d}z \\ & \leq b \, \| \gamma(\nabla u_{m} - \nabla u) \|_{0, 2, \Gamma} + \max_{z \in V'} |\varphi_{m}(z) - \varphi(z)|^{1/2} \, b \, \|u_{m} - U\|_{2, 2, \Omega_{m}}. \end{split}$$

This implies that

$$\int_{\Gamma} \eta [\gamma_m(\mathbf{w}_m - \mathbf{W})]_{T_m} ds_m \to 0$$
 (3,2,4,14)

since  $u_m \to u$  weakly in  $H^2(\Omega)$  and  $\varphi_m \to \varphi$  uniformly in V'. Next we have

$$\int_{\Gamma_{m}} \eta(\gamma_{m} \mathbf{W})_{T_{m}} ds_{m} = \int_{\Gamma_{m}} \eta \mathbf{\tau}_{m} \cdot \gamma_{m} \mathbf{W} ds_{m}$$

$$= \int_{V'} [\eta \mathbf{\tau}_{m} \cdot \gamma_{m} \mathbf{W}](z, \varphi_{m}(z)) \sqrt{[1 + \varphi'_{m}(z)^{2}]} dz$$

$$= \int_{V'} \eta(z, \varphi_{m}(z)) [\gamma_{m} D_{1} U(z, \varphi_{m}(z))$$

$$+ \varphi'_{m}(z) \gamma_{m} D_{2} U(z, \varphi_{m}(z))] dz. \qquad (3.2.4.15)$$

Obviously  $\eta(z, \varphi_m(z))$  converges uniformly to  $\eta(z, \varphi(z))$  in V'. On the other hand, we have

$$\begin{aligned} |\gamma_m \mathbf{W}(z, \varphi_m(z)) - \gamma \mathbf{W}(z, \varphi(z))| &\leq \int_{\varphi(z)}^{\varphi_m(z)} |D_2 \mathbf{W}(z, y)| \, \mathrm{d}y \\ &\leq |\varphi_m(z) - \varphi(z)|^{1/2} \\ &\qquad \times \left\{ \int_{-a_n/2}^{a_n/2} |D_2 \mathbf{W}(z, y)|^2 \, \mathrm{d}y \right\}^{1/2} \end{aligned}$$

and consequently  $\gamma_m \mathbf{W}(z, \varphi_m(z))$  converges to  $\gamma \mathbf{W}(z, \varphi(z))$  almost everywhere in V'. Summing up this shows that the integrand in (3,2,4,15) has a limit almost everywhere in V'.

In addition, we have

$$|\gamma_{m} \mathbf{W}(z, \varphi_{m}(z))| \leq |\gamma \mathbf{W}(z, \varphi(z))| + |\varphi_{m}(z) - \varphi(z)|^{1/2} \times \left\{ \int_{-a/2}^{a_{m}/2} |D_{2} \mathbf{W}(z, y)|^{2} dy \right\}^{1/2}.$$

Thus the integrand in (3,2,4,15) is bounded by a fixed integrable function on V'. One of Lebesgue's theorems implies, therefore, that

$$\int_{\Gamma_{m}} \eta(\gamma_{m} \mathbf{W})_{T_{m}} ds_{m} \to \int_{\Gamma} \eta(\gamma \mathbf{W})_{T} ds. \tag{3,2,4,16}$$

Now (3,2,4,13) follows from (3,2,4,14) and (3,2,4,16). Accordingly, we have shown that (3,2,4,2) holds for all  $v \in C^1(\overline{\Omega})$ . This identity is extended to all  $v \in H^1(\Omega)$  by density. Finally, the uniqueness of u follows from (3,2,4,2) by substituting u for v and assuming  $\lambda$  large enough.

Remark 3.2.4.5 We can make the lower bound  $\lambda_0$  more precise in the statement of Theorem 3.2.4.1. Indeed, let us set v = u in (3,2,4,2); thus we obtain

$$\int_{\Omega} |\nabla u|^2 dx + \lambda \int_{\Omega} |u|^2 dx = \int_{\Omega} f u dx + \frac{1}{2} \int_{\Gamma} \frac{\partial c}{\partial s} |\gamma u|^2 ds.$$

Then let K be the best possible constant in inequality (1,5,1,2) and set

$$M = \max_{\Gamma} \frac{\partial c}{\partial s};$$

it follows that

$$\int_{\Omega} |\nabla u|^2 dx + \lambda \int_{\Omega} |u|^2 dx \le \int_{\Omega} f u dx + \frac{KM}{2}$$

$$\times \left\{ \sqrt{\varepsilon} \int_{\Omega} |\nabla u|^2 dx + \frac{1}{\sqrt{\varepsilon}} \int_{\Omega} |u|^2 dx \right\}.$$

Choosing  $\sqrt{\varepsilon} = 2/KM$ , we obtain

$$\left\{\lambda - \left(\frac{KM}{2}\right)^2\right\} \int_{\Omega} |u|^2 \, \mathrm{d}x \le \int_{\Omega} fu \, \, \mathrm{d}x$$

accordingly we have

$$\left\{\lambda - \left(\frac{KM}{2}\right)^2\right\} \|u\| \leq \|f\|$$

and this shows that  $(KM/2)^2$  is a possible value for  $\lambda_0$ .

Remark 3.2.4.6 In all the previous results the convexity of  $\Omega$  can be replaced by the weaker assumptions that there exists a sequence  $\Omega_m$ ,  $m=1,2,\ldots$  of bounded open subsets of  $\mathbb{R}^n$ , with  $C^2$  boundaries  $\Gamma_m$  such that  $d(\Gamma_m,\Gamma)\to 0$  as  $u\to +\infty$ , the sequence of the corresponding second fundamental forms  $\mathcal{B}_m$ ,  $m=1,2,\ldots$  is uniformly bounded from above independently of m, and  $\Omega_m\subseteq\Omega$  to solve the Dirichlet problem or  $\Omega_m\supseteq\Omega$  to solve the other boundary value problems. This assumption is obviously fulfilled when  $\Omega$  is a bounded open subset of  $\mathbb{R}^2$  whose boundary is a curvilinear polygon of class  $C^{1,1}$ , provided all the angles are strictly convex.

#### 3.3 Boundary value problems in domains with turning points

As we observed in Remark 3.2.4.6, the good domains  $\Omega$  for the regularity in  $H^2(\Omega)$  are those which are piecewise  $C^2$  with convex corners. This is an upper bound on the measure of the possible angles and this leads naturally to the question whether turning points (i.e. angles with measure zero) allow the solution of an elliptic boundary value problem to belong to  $H^2(\Omega)$ . The answer is yes for several boundary conditions as it is shown in Khelif (1978).

We shall consider here only the simplest problem, namely the Dirichlet problem for the Laplace equation in a plane domain  $\Omega$  with a boundary  $\Gamma$  which is  $C^2$  everywhere except in one point, which is a turning point. To be more precise we assume that this turning point is at O and that there exists  $\rho > 0$  such that, denoting by V the disc with centre at zero and radius  $\rho$ , we have

$$V \cap \Omega = \{(x, y) \in V; x > 0, \varphi_1(x) < y < \varphi_2(x)\}$$

where  $\varphi_1$  and  $\varphi_2$  are a pair of  $C^2$  functions such that

$$\begin{cases} \varphi_1(0) = \varphi_2(0) = 0 \\ \varphi_1'(0) = \varphi_2'(0) = 0 \\ \varphi_1'(x) < \varphi_2'(x), \ 0 < x < \rho. \end{cases}$$

Thus, near the origin, the boundary of  $\Omega$  is a pair of  $C^2$  curves which meet at zero and which are tangent there to the positive half x-axis.

We are going to prove the following result of Ibuki (1974) applying the method of Khelif (1978) which is simpler and more general.

**Theorem 3.3.1** Given  $f \in L_2(\Omega)$  there exists a unique  $u \in H^2(\Omega) \cap \mathring{H}^1(\Omega)$  such that

$$\Delta u = f$$

![](_page_190_Picture_3.jpeg)

Figure 3.2

in  $\Omega$  provided

$$\limsup_{x \to 0} \frac{(|\varphi_1''(x)| + |\varphi_2''(x)|)[\varphi_2(x) - \varphi_1(x)]}{[\varphi_2'(x) - \varphi_1'(x)]^2} < 2$$

(One can observe that those conditions are fulfilled in the following example:  $\varphi_1(x) = 0$  and  $\varphi_2(x) = x^a$ , where a is any real number >1.)

Exactly as in the previous section the method consists in approximating  $\Omega$  by a sequence  $\Omega_m$ , m = 1, 2, ..., of 'better' domains. For this purpose we consider a decreasing sequence  $a_m$ , m = 1, 2, ... of positive real numbers and we set

$$\Omega_m = \Omega \cap \{(x, y); x > a_m\}.$$

Clearly, we have

$$\Omega = \bigcup_{m=1}^{\infty} \Omega_m,$$

and each  $\Omega_m$  has a piecewise  $C^2$  boundary with two convex angles.

Consequently there exists a unique

$$u_m \in H^2(\Omega_m) \cap \mathring{H}^1(\Omega_m)$$

which is a solution of

$$\Delta u_m = f|_{\Omega_m}$$

in fl,. We are going to show that the sequence

$$||u_m||_{2,2,\Omega_m}$$

is bounded as m -+ +00.

*Lemma 3.3.2 Under the* assumptions *of Theorem 3.3.1 there* exists a constant K such that

$$\|u_{m}\|_{2,2,\Omega_{m}} \leq K \|f\|_{0,2,\Omega} \tag{3.3.1}$$

for every m and every f E L<sup>2</sup> (,Q).

*Proof* Integration by parts of *(Au<sup>m</sup> )um* and the Poincaré inequality (Theorem 1.4.3.4) yield a constant C, such that

$$\|u_m\|_{1,2,\Omega_m} \le C_1 \|f\|_{0,2,\Omega}.$$
 (3,3,2)

Then we apply Theorem 3.1.1.2 in order to bound the second derivatives of u<sup>m</sup> . For this purpose, we assume that m is fixed and we set

$$v = D_{\mathbf{x}} u_{\mathbf{m}}, \qquad \mathbf{w} = D_{\mathbf{y}} u_{\mathbf{m}}. \tag{3.3.3}$$

The functions v and w only belong to H' (,2 <sup>m</sup> ) and we approximate them by functions belonging to *H2(2m ).*

We observe that v and w fulfil the following boundary conditions:

$$\begin{cases} \gamma w(a_m, y) = 0, & \varphi_1(a_m) < y < \varphi_2(a_m) \\ \lambda \gamma v + \mu \gamma w = 0 & \text{on } \Gamma \cap \{(x, y) \mid x > a_m\}, \end{cases}$$

where A and µ are the components of the unit tangent vector to T. Accordingly, there exists a couple of sequences of functions V<sup>k</sup> , W<sup>k</sup> , k = 1, 2, ... , such that

$$v_k \to v, \qquad w_k \to w$$

in H' (Q<sup>11</sup> ) as k --> +x and such that

$$\begin{cases} v_k, w_k \in H^2(\Omega_m) \\ \gamma w_k(a_m, y) = 0, & \varphi_1(a_m) < y < \varphi_2(a_m) \\ \lambda \gamma v_k + \mu \gamma w_k = 0 & \text{on } \Gamma \cap \{(x, y) \mid x > a_m\}. \end{cases}$$

(We skip the proof of this density result due to its similarity to Lemma 4.3.1.3.)

Applying identity (3,1,1,10) to the vector function  $\{v_k, w_k\}$ , we obtain

$$\int_{\Omega_{m}} |D_{x}v_{k} + D_{y}w_{k}|^{2} dx dy = \int_{\Omega_{m}} [|D_{x}v_{k}|^{2} + |D_{y}w_{k}|^{2} + 2D_{x}w_{k}D_{y}v_{k}] dx dy - \int_{\Gamma_{m}} (\operatorname{tr} \Re) |\nu_{1}\gamma v_{k} + \nu_{2}\gamma w_{k}|^{2} d\sigma.$$

Then, taking the limit in k, we have

$$\int_{\Omega_{m}} |D_{x}v + D_{y}w|^{2} dx dy = \int_{\Omega_{m}} [|D_{x}v|^{2} + |D_{y}w|^{2} + 2D_{x}wD_{y}v] dx dy$$
$$-\int_{\Gamma_{m}} (\operatorname{tr} \mathcal{B}) |\nu_{1}\gamma_{v} + \nu_{2}\gamma_{w}|^{2} d\sigma$$

and consequently, using (3,3,3), we have

$$\int_{\Omega_{m}} |f|^{2} dx dy = \int_{\Omega_{m}} \left[ |D_{x}^{2} u_{m}|^{2} + |D_{y}^{2} u_{m}|^{2} + 2 |D_{x} D_{y} u_{m}|^{2} \right] dx dy$$

$$- \int_{\Gamma_{m}} (\operatorname{tr} \mathcal{B}) \left| \gamma \frac{\partial u_{m}}{\partial \nu} \right|^{2} d\sigma. \tag{3.3.4}$$

Let us now consider the boundary integral in (3,3,4). The second fundamental form  $\mathcal{B}$  vanishes on the segment

$$\{(a_m, y), \varphi_1(x) < y < \varphi_2(x)\}$$

which is curvature free. On the other hand the form  $\mathcal{B}$  is bounded on each  $C^2$  curve; in addition  $\mathcal{B}$  is bounded by  $|\varphi_j^m(x)|$  at  $(x, \varphi_j(x))$ . Thus we shall consider differently the points of the boundary  $\Gamma_m$  according to their distance to the origin. For this purpose let  $\delta > 0$  be small enough to ensure that the points  $(\delta, \varphi_1(\delta))$  and  $(\delta, \varphi_2(\delta))$  lie in V. Assuming that m is large enough to ensure  $a_m < \delta$ , there exists a constant  $M_2$  such that

$$\int_{\Gamma_{m}} (\operatorname{tr} \mathcal{B}) \left| \gamma \frac{\partial u_{m}}{\partial \nu} \right|^{2} d\sigma \leq M_{2} \int_{\Gamma_{m} \cap \{(x,y); x \geq \delta\}} \left| \gamma \frac{\partial u_{m}}{\partial \nu} \right|^{2} d\sigma$$

$$+ \int_{a_{m}}^{\delta} \left| \gamma \frac{\partial u_{m}}{\partial \nu} (x, \varphi_{1}(x)) \right|^{2} |\varphi_{1}''(x)| dx$$

$$+ \int_{a_{m}}^{\delta} \left| \gamma \frac{\partial u_{m}}{\partial \nu} (x, \varphi_{2}(x)) \right|^{2} |\varphi_{2}''(x)| dx.$$
 (3,3,5)

Since

$$\Omega_{\delta} = \Omega \cap \{(x, y) : x > \delta\}$$

has a Lipschitz boundary, Theorem 1.5.1.10 implies the existence of a

178 SECOND-ORDER PROBLEMS IN CONVEX DOMAINS

constant  $K_\delta$  such that

$$\int_{\Gamma_{m} \cap \{(x,y); x \ge \delta\}} \left| \gamma \frac{\partial u_{m}}{\partial \nu} \right|^{2} d\sigma$$

$$\leq K_{\delta} \left\{ \varepsilon^{1/2} \int_{\Omega_{\delta}} \left[ |D_{x}^{2} u_{m}|^{2} + |D_{y}^{2} u_{m}|^{2} + 2 |D_{x} D_{y} u_{m}|^{2} \right] dx dy$$

$$+ \varepsilon^{-1/2} \int_{\Omega} |\nabla u_{m}|^{2} dx dy \right\} \tag{3.3.6}$$

for every  $\varepsilon > 0$ .

Next on the graph of  $\varphi_i$  (j = 1, 2) we have

$$\gamma u_m(x, \varphi_i(x)) = 0 \tag{3,3,7}$$

and consequently

$$\gamma(D_{\mathbf{x}}u_{m})(\mathbf{x},\,\varphi_{i}(\mathbf{x}))+\varphi_{i}'(\mathbf{x})\gamma(D_{\mathbf{y}}u_{m})(\mathbf{x},\,\varphi_{i}(\mathbf{x}))=0$$

for a.e. x. On the other hand we have

$$\gamma \frac{\partial u_m}{\partial \nu} = \frac{-\varphi_2' \gamma D_x u_m + \gamma D_y u_m}{\sqrt{(1 + \varphi_2'^2)}}$$

at  $(x, \varphi_2(x))$ . It follows that

$$\gamma \frac{\partial u_m}{\partial \nu} = \sqrt{({\varphi_2'}^2 + 1)} \frac{\gamma D_x u_m + {\varphi_1'} \gamma D_y u_m}{{\varphi_1'} - {\varphi_2'}}$$

and there exists a constant  $N_{\delta}$  such that

$$\left| \gamma \frac{\partial u_m}{\partial \gamma} \right| \leq N_{\delta} \frac{1}{(\varphi_2' - \varphi_1')} \left| \gamma D_{\chi} u_m + \varphi_1' \gamma D_{\chi} u_m \right|$$

for  $a_m < x \le \delta$  (and  $N_{\delta} \to 1$  as  $\delta \to 0$ ).

The boundary integral corresponding to the graph of  $\varphi_2$  in (3,3,5) is bounded by

$$I = N_{\delta} \int_{a_{m}}^{\delta} |\gamma D_{x} u_{m}(x, \varphi_{2}(x)) + \varphi'_{1}(x) D_{y} u_{m}(x, \varphi_{2}(x))|^{2} \frac{|\varphi''_{2}(x)| dx}{|\varphi'_{1}(x) - \varphi'_{2}(x)|^{2}}.$$
(3,3,8)

Since we have

$$\gamma D_{\mathbf{x}} u_{\mathbf{m}}(\mathbf{x}, \varphi_{1}(\mathbf{x})) + \varphi'_{1}(\mathbf{x}) \gamma D_{\mathbf{y}} u_{\mathbf{m}}(\mathbf{x}, \varphi_{1}(\mathbf{x})) = 0,$$

by (3,3,7), we can write

$$\gamma D_{\mathbf{x}} u_{\mathbf{m}}(\mathbf{x}, \varphi_{2}(\mathbf{x})) + \varphi_{1}'(\mathbf{x}) \gamma D_{\mathbf{y}} u_{\mathbf{m}}(\mathbf{x}, \varphi_{2}(\mathbf{x}))$$

$$= \int_{\varphi_{1}(\mathbf{x})}^{\varphi_{2}(\mathbf{x})} D_{\mathbf{y}} \{D_{\mathbf{x}} u_{\mathbf{m}} + \varphi_{1}'(\mathbf{x}) D_{\mathbf{y}} u_{\mathbf{m}}\} \, \mathrm{d}\mathbf{y}.$$

Hence

$$\begin{aligned} |\gamma D_{x} u_{m}(x, \varphi_{2}(x)) + \varphi_{1}'(x) \gamma D_{y} u_{m}(x, \varphi_{2}(x))| \\ &\leq [\varphi_{2}(x) - \varphi_{1}(x)]^{1/2} \left[ \int_{\varphi_{1}(x)}^{\varphi_{2}(x)} |D_{y} D_{x} u_{m}|^{2} dy \right]^{1/2} \\ &+ |\varphi_{1}'(x)| \left[ \varphi_{2}(x) - \varphi_{1}(x) \right]^{1/2} \left[ \int_{\varphi_{1}(x)}^{\varphi_{2}(x)} |D_{y}^{2} u_{m}|^{2} dy \right]^{1/2} \end{aligned}$$

Finally this implies that

$$I^{1/2} \leq N_{\delta}^{1/2} \max_{0 < x \leq \delta} \frac{\left( |\varphi_{2}''(x)| \left[ \varphi_{2}(x) - \varphi_{1}(x) \right] \right)^{1/2}}{|\varphi_{1}'(x) - \varphi_{2}'(x)|}$$

$$\times \left[ \left\{ \int_{a_{m}}^{\delta} \int_{\varphi_{1}(x)}^{\varphi_{2}(x)} |D_{y}D_{x}u_{m}|^{2} dx dy \right\}^{1/2}$$

$$+ \max_{0 < x \leq \delta} |\varphi_{1}'(x)| \int_{a_{m}}^{\delta} \int_{\varphi_{1}(x)}^{\varphi_{2}(x)} |D_{y}^{2}u_{m}|^{2} dx dy \right\}^{1/2} .$$

$$(3,3,9)$$

We have a similar inequality for the boundary integral corresponding to  $\varphi_1$ . Summing up, there exists a constant  $M_2$  such that

$$\begin{split} & \left| \int_{\Gamma_{m}} \left( \operatorname{tr} \mathcal{B} \right) \left| \gamma \frac{\partial u_{m}}{\partial \gamma} \right|^{2} d\sigma \right| \\ & \leq M_{2} K_{\delta} \left\{ \varepsilon^{1/2} \int_{\Omega_{\delta}} \left[ \left| D_{x}^{2} u_{m} \right|^{2} + \left| D_{y}^{2} u_{m} \right|^{2} + 2 \left| D_{x} D_{y} u_{m} \right|^{2} \right] dx dy \right. \\ & + \varepsilon^{-1/2} \int_{\Omega_{\delta}} \left| \nabla u_{m} \right|^{2} dx dy \right\} \\ & + N_{\delta} \max_{0 < x \leq \delta} \frac{\left[ \left| \varphi_{1}''(x) \right| + \left| \varphi_{2}''(x) \right| \right] \left[ \varphi_{2}(x) - \varphi_{1}(x) \right]}{\left| \varphi_{1}'(x) - \varphi_{2}'(x) \right|^{2}} \\ & \times \left\{ (1 + \eta) \int_{\Omega_{m} \setminus \Omega_{\delta}} \left| D_{y} D_{x} u_{m} \right|^{2} dx dy \right. \\ & + \left( 1 + \frac{1}{\eta} \right) \max_{0 < x \leq \delta} \left[ \left| \varphi_{1}'(x) \right|^{2} + \left| \varphi_{2}'(x) \right|^{2} \right] \int_{\Omega_{m} \setminus \Omega_{\delta}} \left| D_{y}^{2} u_{m} \right|^{2} dx dy \right\} \end{split}$$

$$(3,3,10)$$

for every  $\eta > 0$ .

Now we can make precise the choice of  $\delta$ . We choose  $\delta$  small enough so that

$$A = \max_{0 < x \le \delta} \frac{\left[ |\varphi_1''(x)| + |\varphi_2''(x)| \right] [\varphi_2(x) - \varphi_1(x)]}{\left[ \varphi_2'(x) - \varphi_2'(x) \right]^2} < 2.$$

180 SECOND-ORDER PROBLEMS IN CONVEX DOMAINS

Then we choose  $\eta$  in such a way that again

$$A(1+\eta) < 2$$
.

Then we can replace  $\delta$  by a smaller one to ensure that for this value of  $\eta$  we have

$$N_8A(1+\eta)<2$$

and

$$N_{\delta}A\left(1+\frac{1}{\eta}\right)\max_{0< x \leq \delta}\left[|\varphi_1'(x)|^2+|\varphi_2'(x)|^2\right]<1.$$

This is clearly possible since  $\varphi_1'(0) = \varphi_2'(0) = 0$  and  $N_{\delta} \to 1$  as  $\delta \to 0$ . Finally we choose  $\varepsilon$  small enough so that

$$M_2K_{\delta}\varepsilon^{1/2}<1.$$

Then the inequality (3,3,10) may be rewritten merely as

$$\left| \int_{\Gamma_{m}} (\operatorname{tr} \mathcal{B}) \left| \gamma \frac{\partial u_{m}}{\partial \nu} \right|^{2} d\sigma \right|$$

$$\leq \alpha \int_{\Omega_{m}} \left[ |D_{x} u_{m}|^{2} + |D_{y} u_{m}|^{2} + 2 |D_{x} D_{y} u_{m}|^{2} \right] dx dy$$

$$+ \beta \int_{\Omega_{m}} |\nabla u_{m}|^{2} dx dy \tag{3.3.11}$$

where  $\alpha < 1$  and neither  $\alpha$  nor  $\beta$  depend on m.

Let us go back to the identity (3,3,4). Together with (3,3,11) it yields

$$\int_{\Omega_{m}} [|D_{x}^{2} u_{m}|^{2} + |D_{y} u_{m}|^{2} + 2 |D_{x} D_{y} u_{m}|^{2}] dx dy$$

$$\leq \frac{1}{1 - \alpha} \left[ \int_{\Omega_{m}} |f|^{2} dx dy + \beta \int_{\Omega_{m}} |\nabla u_{m}|^{2} dx dy \right]. \tag{3.3.12}$$

This last inequality combined with (3,3,2) implies (3,3,1).

**Proof of Theorem 3.3.1** This is very similar to the proof of Theorem 3.2.1.2. By the same technique we find an increasing sequence of integers  $m_k$ , k = 1, 2, ... and a function u such that

$$\tilde{u}_{m_k} \rightarrow u$$

weakly in  $H^1(\Omega)$ ,

$$\widetilde{D_i}\widetilde{D_j}u_{m_k} \to D_iD_ju$$

weakly in  $L_2(\Omega)$  such that

$$\Delta u = f$$

in  $\Omega$ .

Obviously u belongs to  $H^2(\Omega)$  and we just have to check that u belongs to  $\mathring{H}^1(\Omega)$ . Here  $\Omega$  has no Lipschitz boundary and  $\mathring{H}^1(\Omega)$  must be understood as the closure of  $\mathfrak{D}(\Omega)$  in  $H^1(\Omega)$  (according to Definition 1.3.2.2). Indeed  $u_{m_k}$  belongs to the closure of  $\mathfrak{D}(\Omega_{m_k})$  for the norm of  $H^1(\Omega_{m_k})$ . Therefore  $\tilde{u}_{m_k}$  belongs to the closure of  $\mathfrak{D}(\Omega)$  for the norm of  $H^1(\Omega)$  since  $\Omega_{m_k}$  is a subset of  $\Omega$ . By taking the limit in k it is clear that u belongs to the closure of  $\mathfrak{D}(\Omega)$  in  $H^1(\Omega)$ .

Remark 3.3.3 In the work of Khelif (1978) conditions on  $\varphi_1$  and  $\varphi_2$  are given for the smoothness of the solution of the Laplace equation under other boundary conditions. For instance the conditions corresponding to the Neumann problem are

$$\limsup_{x \to 0} \frac{|\varphi_{j}''(x)| [\varphi_{2}(x) - \varphi_{1}(x)]}{[\varphi_{2}'(x) - \varphi_{1}'(x)]^{2}} < 1.$$

Mixed boundary conditions are also considered.

## Second-order elliptic boundary value problems in polygons

#### 4.1 Foreword

The purpose of this chapter is to investigate the properties of the second derivatives of the solutions of boundary value problems for the Laplace operator in a plane domain with a polygonal boundary. Here, we just consider classical polygons, i.e. the union of a finite number of linear segments  $\bar{\Gamma}_j$ ,  $1 \le j \le N$  (it is convenient to assume that  $\Gamma_j$  is an open linear segment). We also fix a partition of  $\{1, 2, \ldots, N\}$  into two subsets  $\mathcal N$  and  $\mathcal D$ . The union of the  $\Gamma_j$  with  $j \in \mathcal D$  is going to be the part of the boundary where we consider a Dirichlet boundary condition. We shall consider first-order boundary conditions (either Neumann or oblique) on the other sides. Accordingly, our main problem will be the following. Given  $f \in L_p(\Omega)$ , we look for  $u \in W_p^2(\Omega)$ , a solution of

$$\begin{cases} \Delta u = f & \text{in } \Omega \\ \gamma_{i} u = 0 & \text{on } \Gamma_{j}, \quad j \in \mathcal{D} \end{cases}$$

$$\begin{cases} \gamma_{i} \frac{\partial u}{\partial \nu_{i}} + \beta_{i} \frac{\partial}{\partial \tau_{i}} \gamma_{j} u = 0 & \text{on } \Gamma_{j}, \quad j \in \mathcal{N} \end{cases}$$

$$(4,1,1)$$

where  $\nu_i$  denotes the unit normal on  $\Gamma_i$ , while  $\tau_i$  denotes the unit tangent vector on  $\Gamma_i$  (following the direct orientation; finally  $\beta_i$ ,  $j \in \mathcal{N}$  are given real numbers).

The first step in solving (4,1,1) is the proof of a priori bounds for solutions in  $W_p^2(\Omega)$ . Actually, we shall prove the existence of a constant C depending on  $\Omega$ , p,  $\mathcal{D}$  and  $\beta_i$   $(j \in \mathcal{N})$  such that

$$||u||_{2,p,\Omega} \le C\{||\Delta u||_{0,p,\Omega} + ||u||_{0,p,\Omega}\} \tag{4,1,2}$$

for all  $u \in W_p^2(\Omega)$  fulfilling the boundary conditions in (4,1,1).

Curiously enough the inequality (4,1,2) always holds when p=2, while it does not hold for some exceptional values of the numbers  $\beta_i$   $(j \in \mathcal{N})$  when  $p \neq 2$  (a detailed investigation of some exceptional cases can be

found in Fabes et al. (1977)). Actually our methods of proof when p=2 and when  $p \neq 2$  are quite different. Our proof for p=2 starts from a particular case of identity (3,1,1,10) which we shall prove directly by performing integration by parts. On the other hand, when  $p \neq 2$ , we shall use a local method which, together with the same change of variables as in Kondratiev (1967), reduces our problem to a boundary value problem in an infinite plane strip. The main advantage is that such a strip has a smooth boundary. There, we essentially use the same techniques as in Subsection 2.3.2. That is, we write the solution as a double layer potential which is estimated by applying Mikhlin's multipliers theorem.

Inequalities like (4,1,2) when p=2 for the Dirichlet problem have been proven in Aronszajn (1951) and Hanna and Smith (1967). General boundary conditions are dealt with in Grisvard (1972).

The second step in solving (4,1,1) is the following. The *a priori* bound (4,1,2) implies that the Laplace operator  $\Delta$  has a closed range in  $L_p(\Omega)$  when we look at it, as an unbounded operator whose domain is the subspace of  $W_p^2(\Omega)$  defined by the boundary conditions in (4,1,1). Therefore, the annihilator of the range is a space of functions in  $L_q(\Omega)$  (where  $p^{-1}+q^{-1}=1$ ) which are, in some weak sense, solutions of the homogeneous adjoint problem. Using separation of variables in polar coordinates, we shall be able to derive precise expansions of those functions near the corners. Then it will be easy to calculate the codimension of the range of the Laplace operator in  $L_p(\Omega)$ . This is carried out in Section 4.4.

Such results for  $p \neq 2$  were first proven by Merigot (1972), who makes use of quite different methods. A comprehensive detailed study of problem (4,1,1) has been carried out independently by Lorenzi (1978) and Moussaoui (1977). Here is a simplified version of their work.

The reader interested only by the p = 2 case may skip Section 4.2 and Subsection 4.3.2.

Here are some additional notation. We denote by  $\omega_i$  the measure (we allow  $\omega_i = \pi$  in order to consider also mixed problems along a flat boundary) of the angle at  $S_i$  and we set

$$\mathbf{\mu}_{i} = \begin{cases} \mathbf{\nu}_{i} + \beta_{i} \mathbf{\tau}_{i}, & j \in \mathcal{N} \\ \mathbf{\tau}_{i} & j \in \mathcal{D} \end{cases}$$

$$(4,1,3)$$

Accordingly we have  $\gamma_i(\partial u/\partial \mu_i) = 0$  for all j when u fulfils the boundary conditions in (4,1,1). Finally, we define  $\Phi_i$  by

$$\begin{cases} \tan \Phi_i = \beta_i & j \in \mathcal{N} \\ \Phi_j = \pi/2 & j \in \mathcal{D}, \end{cases}$$

$$(4,1,4)$$

thus  $\Phi_i$  is the angle of the vectors  $\mathbf{v}_i$  and  $\mathbf{\mu}_i$ .

Finally, let us mention that all the results in this section hold for

domains with holes. Considering domains with holes (or domains which are not connected) just leads to more complicated notation.

#### 4.2 A priori estimates for a problem in an infinite strip

This whole section is devoted to the proof of bounds for solutions of the following boundary value problem in the infinite strip  $B = \mathbb{R} \times ]0, h[(h>0)$ . We shall denote by x and y the coordinates in  $\mathbb{R}^2$  and thus we have

$$B = \{(x, y) \mid x \in \mathbb{R}, 0 < y < h\}.$$

We shall deal with a boundary value problem for the operator L defined by

$$Lu = D_x^2 u + D_y^2 u + aD_x u + bu,$$

where a and b are real numbers. The boundary conditions involve the operators

$$M_i u = \alpha_i D_v u + \beta_i D_x u + \lambda_i u, \quad j = 0, 1.$$

where  $\alpha_j$ ,  $\beta_j$  and  $\lambda_j$  are real numbers j=0, 1. (Actually, we shall only need, in the forthcoming sections, these two special cases: either  $\alpha_j = 1$  or  $\alpha_j = \beta_j = 0$  and  $\lambda_j = 1$ .) Precisely, we look at  $u \in W_p^2(B)$ , a solution of

$$\begin{cases} Lu = f & \text{in } B \\ \gamma_i M_i u = 0 & \text{on } F_i, \quad j = 0, 1 \end{cases}$$

$$(4,2,1)$$

where  $F_0 = \{(x, 0) \mid x \in \mathbb{R}\}$ ,  $F_1 = \{(x, h) \mid x \in \mathbb{R}\}$  and  $\gamma_j$  denotes the trace operator on  $F_i$ , j = 0, 1.

We shall look for conditions on the coefficients a, b, c,  $\alpha_i$ ,  $\beta_i$ ,  $\lambda_i$ , j = 0, 1, ensuring the existence of a constant C such that

$$||u||_{2,p,B} \le C ||f||_{0,p,B}.$$
 (4,2,2)

For that purpose we shall calculate explicitly a solution u of (4,2,1) by a Fourier transform in x. Then the explicit solution will be suitably estimated by using Mikhlin's theorem.

#### 4.2.1 Explicit solution by Fourier transform and consequences

As in Subsection 2.3.2 we denote by  $\hat{u}$  (respectively  $\hat{f}$ ) the partial Fourier transform of u (respectively f) with respect to x, i.e.

$$\hat{u}(\xi, y) = \frac{1}{\sqrt{(2\pi)}} \int_{-\infty}^{+\infty} e^{-ix\xi} u(x, y) dx,$$

for e E f I and y E ]0, h[. Actually, in order to deal only with Fourier transforms which are functions, we shall always assume that u E *H<sup>2</sup> (B).* Eventually, we shall take advantage of density theorems for extending our results to the whole of WP(B).

After performing the Fourier transform, problem (4,2,1) becomes a two-point boundary value problem in the interval ]0, h[ depending on the parameter e. Namely this problem is

$$\begin{cases} \hat{u}'' + (-\xi^2 + ia\xi + b)\hat{u} = \hat{f} & \text{in } ]0, h[\\ \alpha_0 \hat{u}'(\xi, 0) + (i\beta_0 \xi + \lambda_0)\hat{u}(\xi, 0) = 0\\ \alpha_1 \hat{u}'(\xi, h) + (i\beta_1 \xi + \lambda_1)\hat{u}(\xi, h) = 0 \end{cases}$$
(4,2,1,1)

for all e E (l, where the superscript prime denotes differentiation with respect to y.

As is well known for two-point boundary value problems, problem (4,2,1,1) is well posed if and only if the only solution ofte corresponding homogeneous boundary value problem is zero. This possibly leads to exceptional values of e. More precisely we have the following.

*Theorem 4.2.1.1* Assuming *b >0, a 0,* then *the problem* (4,2,1,1) is well *posed unless*

$$\sin \rho h(\alpha_0 \alpha_1 \rho^2 - \beta_0 \beta_1 \xi^2 + \lambda_0 \lambda_1 + i[\beta_0 \lambda_1 + \beta_1 \lambda_0] \xi) 
= \rho \cos \rho h([\alpha_0 \lambda_1 - \alpha_1 \lambda_0] + i[\alpha_0 \beta_1 - \alpha_1 \beta_0] \xi),$$

$$\text{where } \rho = (b + ia\xi - \xi^2)^{1/2}. \dagger$$
(4,2,1,2)

The case when b > 0, a 0 is the only one that we need in the sequel.

*Proof* A fundamental system of solutions for the differential equation in (4,2,1,1) is the couple of functions

$$v_1(y) = \sin \rho y, \qquad v_2(y) = \cos \rho y$$

where p = (b + ia — e <sup>2</sup>) <sup>112</sup> , for R. Thus any solution of the homogeneous equation

$$v'' + (b + ia\xi - \xi^2)v = 0$$

has the form

$$v = \mu_1 v_1 + \mu_2 v_2.$$

The boundary conditions in problem (4,2,1,1) are fulfilled if and only if

$$\begin{cases} \alpha_0(\mu_1v_1'(0) + \mu_2v_2'(0)) + (\mathrm{i}\beta_0\xi + \lambda_0)(\mu_1v_1(0) + \mu_2v_2(0)) = 0 \\ \alpha_1(\mu_1v_1'(h) + \mu_2v_2'(h)) + (\mathrm{i}\beta_1\xi + \lambda_1)(\mu_1v_1(h) + \mu_2v_2(h)) = 0. \end{cases}$$

t We define the square root of a complex number by placing the cut on the negative real axis.

This is a linear system in  $(\mu_1, \mu_2)$  whose only solution is zero, provided its determinant d is different from zero. Actually we have

$$\begin{split} d &= \{\alpha_0 v_1'(0) + (\mathrm{i}\beta_0 \xi + \lambda_0) v_1(0)\} \{\alpha_1 v_2'(h) + (\mathrm{i}\beta_1 \xi + \lambda_1) v_2(h)\} \\ &- \{\alpha_0 v_2'(0) + (\mathrm{i}\beta_0 \xi + \lambda_0) v_2(0)\} \{\alpha_1 v_1'(h) + (\mathrm{i}\beta_1 \xi + \lambda_1) v_1(h)\} \\ &= \alpha_0 \rho \{-\alpha_1 \rho \sin \rho h + (\mathrm{i}\beta_1 \xi + \lambda_1) \cos \rho h\} \\ &- (\mathrm{i}\beta_0 \xi + \lambda_0) \{\alpha_1 \rho \cos \rho h + (\mathrm{i}\beta_1 \xi + \lambda_1) \sin \rho h\} \\ &= -\sin \rho h \{\alpha_0 \alpha_1 \rho^2 + (\mathrm{i}\beta_0 \xi + \lambda_0) (\mathrm{i}\beta_1 \xi + \lambda_1)\} \\ &+ \rho \cos \rho h \{\alpha_0 (\mathrm{i}\beta_1 \xi + \lambda_1) - \alpha_1 (\mathrm{i}\beta_0 \xi + \lambda_0)\}. \end{split}$$

The condition that d = 0 is exactly (4,2,1,2). It is the one that allows the homogeneous problem corresponding to problem (4,2,1,1) to admit non-zero solutions.

We observe that condition (4,2,1,2) involves only analytic functions of  $\xi$ . Thus, it is fulfilled for countably many exceptional values of  $\xi$ . In addition, due to the asymptotic behaviour, for large  $|\xi|$ , of both members of equation (4,2,1,2), there is only a finite number of exceptional values on the real axis. From now on we shall assume that problem (4,2,1,1) is well posed for all  $\xi \in \mathbb{R}$ . In other words, we assume that equation (4,2,1,2) has no real root.

**Theorem 4.2.1.2** Assuming b>0,  $a\neq 0$  and that  $\xi$  is not a root of (4,2,1,2), the solution of problem (4,2,1,1) is

$$\hat{u}(\xi, y) = \int_0^h K(\xi, y, z) \hat{f}(\xi, z) \, dz, \tag{4.2.1.3}$$

where, for  $z \ge y$ ,

$$K(\xi, y, z) = \frac{1}{\delta} \left[ \alpha_0 \cos \rho y - \frac{i\beta_0 \xi + \lambda_0}{\rho} \sin \rho y \right]$$
$$\times \left[ \alpha_1 \cos \rho (z - h) - \frac{i\beta_1 \xi + \lambda_1}{\rho} \sin \rho (z - h) \right]$$

and, for  $z \leq y$ ,

$$K(\xi, y, z) = \frac{1}{\delta} \left[ \alpha_1 \cos \rho (y - h) - \frac{i\beta_1 \xi + \lambda_1}{\rho} \sin \rho (y - h) \right]$$
$$\times \left[ \alpha_0 \cos \rho z - \frac{i\beta_0 \xi + \lambda_0}{\rho} \sin \rho z \right]$$

where 
$$\rho = (b + ia\xi - \xi^2)^{1/2}$$
 and

$$\delta = [\alpha_1(i\beta_0\xi + \lambda_0) - \alpha_0(i\beta_1\xi + \lambda_1)]\cos\rho h + [\alpha_0\alpha_1\rho^2 + (i\beta_0\xi + \lambda_0)(i\beta_1\xi + \lambda_1)]\frac{\sin\rho h}{\rho}.$$

Although these formulas are consequences of general procedures for solving two-point boundary value problems, it is simpler to check them directly by verifying that (4,2,1,3) actually gives the solution of problem (4,2,1,1). This is straightforward.

We shall now use identity (4,2,1,3) to show the existence of a constant  $C_0$  such that

$$||u||_{0,p,B} \le C_0 ||Lu||_{0,p,B} \tag{4.2.1.4}$$

for all  $u \in W_p^2(B) \cap H^2(B)$  which fulfils the boundary conditions in (4,2,1), assuming the problem is well posed. We shall need the following lemma.

**Lemma 4.2.1.3** Let  $\xi$ , y,  $z \mapsto K(\xi, y, z)$  be a smooth function such that

$$\max_{\mathbf{y} \in [0,h]} \int_{0}^{h} \max_{\xi \in \mathbb{R}} \{ |K(\xi, y, z)| + |\xi| |D_{\xi}K(\xi, y, z)| \} \, \mathrm{d}z < +\infty$$
 (4,2,1,5)

and

$$\max_{z \in [0,h[} \int_{0}^{h} \max_{\xi \in \mathbb{R}} \{ |K(\xi, y, z)| + |\xi| |D_{\xi}K(\xi, y, z)| \} \, \mathrm{d}y < +\infty; \tag{4.2.1.6}$$

then the mapping  $u \mapsto f$  defined by

$$\hat{u}(\xi, y) = \int_0^h K(\xi, y, z) \hat{f}(\xi, z) dz$$

is continuous in  $L_p(B)$  for p such that 1 .

**Proof** Let us denote by M the function

$$M(y, z) = \max_{\xi \in \mathbb{R}} \{ |K(\xi, y, z)| + |\xi| |D_{\xi}K(\xi, y, z)| \}.$$

Applying Mikhlin's theorem (see Theorem 2.3.2.1) we know that there exists a constant C such that

$$\left(\int_{-\infty}^{+\infty} |u(x, y)|^p dx\right) \leq C \int_0^h M(y, z) \left(\int_{-\infty}^{+\infty} |f(x, z)|^p dx\right)^{1/p} dz.$$

We conclude by applying a classical result on integral operators (see for instance Widom (1965).

Now we have to check the conditions in Lemma 4.2.1.3 on the kernel defined in Theorem 4.2.1.2. It is easy to derive the following bounds for K when the problem is well posed (i.e. when (4,2,1,2) has no real root). Indeed there exists a constant L such that

$$|K(\xi, y, z)| \leq \frac{L}{|\rho|} \exp |\rho| (y + z - 2h)$$
  
$$|\xi| |D_{\xi}K(\xi, y, z)| \leq L \exp |\rho| (y + z - 2h),$$

while the asymptotic behaviour of  $\rho$  is like  $\pm i\xi$ , when  $|\xi| \to \infty$ . It follows that inequalities (4,2,1,5) and (4,2,1,6) hold and consequently we have proved inequality (4,2,1,4).

Summing up, we have proved the following result.

**Theorem 4.2.1.4** Let us assume that b>0,  $a\neq 0$  and that equation (4,2,1,2) has no real root, then there exists a constant  $C_0$  such that (4,2,1,4) holds for all  $u \in W^2_p(B) \cap H^2(B)$  fulfilling the boundary conditions in (4,2,1).

Actually, with a little more care, we should be able to bound the first derivatives of u in  $L_p(B)$ , by using the same Lemma 4.2.1.3. Unfortunately, this does not allow us to bound the second derivatives, which is our real goal.

Finally in most cases, a simple density argument allows us to extend the previous result to all  $u \in W_p^2(B)$  fulfilling the boundary conditions.

**Corollary 4.2.1.5** Under the assumptions of Theorem 4.2.1.4, inequality (4,2,1,4) holds for all  $u \in W_p^2(B)$  fulfilling the boundary conditions in (4,2,1), provided either  $\alpha_i = 1$  or  $\alpha_i = \beta_i = 0$ ,  $\lambda_i = 1$  for each i = 0, 1.

This is deduced from Theorem 4.2.1.4 with the help of the following lemma.

**Lemma 4.2.1.6** Assuming  $\alpha_i = 1$  or  $\alpha_i = \beta_i = 0$ ,  $\lambda_i = 1$  for each j = 0, 1, the subspace of  $W_p^2(B) \cap H^2(B)$  defined by the boundary conditions  $\gamma_i M_i u = 0$  on  $F_i$  is dense in the subspace of  $W_p^2(B)$  defined by the same boundary conditions.

*Proof* Due to the trace theorems in Section 1.5 we can view  $W_p^2(B)$  as

$$\mathring{W}_{p}^{2}(B) \times \prod_{i=0}^{1} \{W_{p}^{2-1/p}(F_{i}) \times W_{p}^{1-1/p}(F_{i})\}$$

and  $H^2(B)$  as

$$\mathring{H}^{2}(B) \times \prod_{i=0}^{1} \{ H^{3/2}(F_{i}) \times H^{1/2}(F_{i}) \}.$$

Since  $\mathring{H}^2(B) \cap \mathring{W}^2_p(B)$  is dense in  $\mathring{W}^2_p(B)$ , it will be enough to prove that for each j the space  $Z_2 \cap Z_p$  is dense in  $Z_p$ , where  $Z_q$  is defined for all q as follows:

$$Z_q = \{(k, l) \mid k \in W_q^{2-1/q}(F_i), \ l \in W_q^{1-1/q}(F_i), \ \alpha_i l + \beta_i D_x k + \lambda_i k = 0\}.$$

In the case when  $\alpha_i = \beta_i = 0$  and  $\lambda_i = 1$ , the space  $Z_q$  reduces to  $0 \times W_q^{1-1/q}(F_i)$  and thus  $Z_2 \cap Z_p$  is obviously dense in  $Z_p$ .

In the case when  $\alpha_i = 1$ , the space  $Z_q$  is nothing but

$$\{(k,-\beta_jD_xk-\lambda_jk)\mid k\in W_q^{2-1/q}(F_j)\},$$

which is isomorphic to  $W_q^{2-1/q}(F_i)$ . Again  $Z_2 \cap Z_p$  is obviously dense in  $Z_p$ .

#### 4.2.2 $L_p$ bounds for the second derivatives of the solution

In order to be able to bound the second derivatives of u, the solution of problem (4,2,1), we replace it by a slightly different problem:

$$\begin{cases} L_1 u = g & \text{in } B \\ \gamma_i M_i u = 0 & \text{on } F_i, \quad j = 0, 1, \end{cases}$$
 (4,2,2,1)

where

$$L_1 u = D_x^2 u + D_y^2 u - u = (\Delta - 1)u.$$

The reason for doing this is that  $(1-\Delta)$  has an elementary solution E with good properties in the Sobolev spaces. This was not true for L.

We shall prove in this subsection that there exists a constant  $C_1$  such that

$$||D^{\alpha}u||_{0,p,B} \le C_1 ||(1-\Delta)u||_{0,p,B} \tag{4,2,2,2}$$

for all  $|\alpha| = 2$  and  $u \in W_p^2(B) \cap H^2(B)$  which fulfils the boundary conditions in (4,2,2,1). Then it will be very easy to deduce (4,2,2) from (4,2,1,4) combined with (4,2,2,2).

Now we proceed exactly as in Subsection 2.3.2. The elementary solution for  $\Delta - 1$ , namely

$$E = -F^{-1}[1+|\xi|^2]^{-1}$$

is linear continuous from  $L_p(\mathbb{R}^2)$  into  $W_p^2(\mathbb{R}^2)$  according to Theorem 2.3.2.1. Then let us denote by v the function

$$v = u - E * \tilde{g};$$
 (4,2,2,3)

we obviously have

$$\begin{cases} (1 - \Delta)v = 0 & \text{in } B \\ \gamma_j M_j v = h_j & \text{on } F_i, \quad j = 0, 1 \end{cases}$$
 (4,2,2,4)

where

$$h_i = -\gamma_i M_i E * \tilde{g}, \qquad j = 0, 1.$$
 (4,2,2,5)

Thus, denoting by  $d_i$  the order of  $M_i = \alpha_i D_y + \beta_i D_x + \lambda_i$ , we obviously have

$$h_i \in W_p^{2-d_i-1/p}(F_i) \cap H^{2-d_i-1/2}(F_i), \quad j=0,1.$$

We shall calculate explicitly the partial Fourier transform in x of v. It is a solution of

$$\begin{cases} -\hat{v}'' + (1 + \xi^2)\hat{v} = 0 & \text{in } ]0, h[\\ \alpha_0 \hat{v}(\xi, 0) + (i\beta_0 \xi + \lambda_0)\hat{v}(\xi, 0) = \hat{h}_0\\ \alpha_1 \hat{v}'(\xi, h) + (i\beta_1 \xi + \lambda_1)\hat{v}(\xi, h) = \hat{h}_1 \end{cases}$$

for almost all  $\xi \in \mathbb{R}$ .

Consequently we have  $\hat{v}(\xi, y) = \alpha(\xi) \cosh ry + \beta(\xi) \sinh ry$  where  $r = \sqrt{(1+\xi^2)}$  and

$$\alpha(\xi) = \frac{1}{d} \left\{ \alpha_0 r \hat{h}_1 - \left[ \alpha_1 r \cosh r h + (i\beta_1 \xi + \lambda_1) \sinh r h \right] \hat{h}_0 \right\}$$

$$\beta(\xi) = \frac{1}{d} \left\{ -(i\beta_0 \xi + \lambda_0) \hat{h}_1 + \left[ \alpha_1 r \sinh r h + (i\beta_1 \xi + \lambda_1) \cosh r h \right] \hat{h}_0 \right\}$$

$$d = r \cosh r h \left[ \alpha_0 (i\beta_1 \xi + \lambda_1) - \alpha_1 (i\beta_0 \xi + \lambda_0) \right]$$

$$+ \sinh r h \left[ r^2 \alpha_0 \alpha_1 - (i\beta_0 \xi + \lambda_0) (i\beta_1 \xi + \lambda_1) \right]. \tag{4.2.2.6}$$

Of course these identities make sense only if we assume that d does not vanish.

From these formulas, we shall deduce the traces

$$k_j = \gamma_j v$$
 on  $F_j$ ,  $l_j = \gamma_j D_y v$  on  $F_j$ ,  $j = 0, 1$ .

Actually we have

$$\hat{k}_0(\xi) = \alpha(\xi), \qquad \hat{l}_0(\xi) = r(\xi)\beta(\xi)$$

$$\hat{k}_1(\xi) = \alpha(\xi)\cosh rh + \beta(\xi)\sinh rh$$

$$\hat{l}_1(\xi) = \alpha(\xi)r\sinh rh + \beta(\xi)r\cosh rh.$$

**Lemma 4.2.2.1** Assume that d defined by (4,2,2,6) does not vanish for any  $\xi \in \mathbb{R}$ , then there exists a constant C such that

$$\sum_{j=0}^1 \{ ||k_j||_{2-1/p,p,F_i} + ||l_j||_{1-1/p,p,F_i} \} \le C \sum_{j=0}^1 ||h_j||_{2-d,-1/p,p,F_j}.$$

Proof This is just a repeated application of Lemma 2.3.2.5.

Then we look at  $\tilde{v}$ , the continuation of v by zero outside B. It is a solution of

$$(1 - \Delta)\tilde{v} = -k_0 \otimes \delta_0' + k_1 \otimes \delta_h' - l_0 \otimes \delta_0 + l_1 \otimes \delta_h, \tag{4,2,2,7}$$

where  $\delta_0$  (respectively  $\delta_h$ ) is the Dirac measure at zero (respectively h).

Consequently we have

$$u = E * \{ \tilde{g} - k_0 \otimes \delta_0' + k_1 \otimes \delta_h' - l_0 \otimes \delta_0 + l_1 \otimes \delta_h \}.$$

From this representation of u we shall deduce the following basic result.

*Theorem* 4.2.2.2 Assume that *d defined* by (4,2,2,6) *does* not uanish *for any real e, then there* exists a constant C1 such *that*

$$||u||_{2,p,B} \le C_1 ||g||_{0,p,B} \tag{4,2,2,8}$$

*for all u e* W<sup>2</sup> (B) fl *H<sup>2</sup> (B) which are solutions of problem* (4,2,2,1).

*Proof* This is mainly the same proof as for Theorem 2.3.2.7. Indeed we know that there exists a constant C such that

$$||E * \tilde{g}||_{2,p,\mathbb{R}^2} \le C ||g||_{0,p,\mathbb{R}^2}.$$

Then, let us consider one typical term E \* (k(,®). From (4,2,2,5) and Theorems 2.3.2.1 and 1.5.1.1, we know that there exists a constant C such that

$$||h_i||_{2-d_i-1/p,p,F_i} \le C ||g||_{0,p,B}.$$

Then combining this inequality with Lemma 4.2.2.1 we have (with possibly a larger constant)

$$||k_0||_{2-1/p,p,F_0} \le C ||g||_{0,p,B}.$$

Now Lemma 2.3.2.2 shows that

$$k_0 \otimes \delta_0', \qquad D_x k_0 \otimes \delta_0', \qquad D_x^2 k_0 \otimes \delta_0' \in W_p^{-2}(\mathbb{R}^2)$$

and depend continuously on k { , E W2- ' /p(F0). Then setting

$$u_0 = E * (k_0 \otimes \delta_0')$$

and applying Lemma 2.3.2.5, we see that

$$u_0, D_x u_0, D_x^2 u_0 \in L_p(\mathbb{R}^2)$$

and depend continuously on k <sup>0</sup> E W2-1/p(F0).

Then we write

$$D_{y}u_{0} = D_{y}^{2}E * (k_{0} \otimes \delta_{0}) = (1 - D_{x}^{2})E * (k_{0} \otimes \delta_{0})$$

in the half plane y >0. Thus

$$D_{y}u_{0} = E * (k_{0} \otimes \delta_{0}) - E * (D_{x}^{2}k_{0} \otimes \delta_{0})$$

and

$$D_{\mathbf{x}}D_{\mathbf{y}}u_0 = E * (D_{\mathbf{x}}k_0 \otimes \delta_0) - D_{\mathbf{x}}E * (D_{\mathbf{x}}^2k_0 \otimes \delta_0).$$

Applying again Lemmas 2.3.2.2 and 2.3.2.5 we show that

$$D_{\nu}u_0, D_{\kappa}D_{\nu}u_0 \in L_{\nu}(B)$$

and depend continuously on  $k_0 \in W_p^{2-1/p}(F_0)$ .

Finally we write that

$$D_y^2 u_0 = u_0 - D_x^2 u_0$$
 in B.

Consequently  $D_y^2 u_0 \in L_p(B)$  and depend continuously on  $k_0 \in W_p^{2-1/p}(F_0)$ . Summing up we have proved that

$$||u_0||_{2,p,B} \le C ||g||_{0,p,B}$$

for some constant C. The other terms in (4,2,2,7) are estimated by the same techniques.

Again using the density result of Lemma 4.2.1.6, we can extend inequality (4,2,2,8) to all  $u \in W_p^2(B)$  in most cases.

**Corollary 4.2.2.3** Under the assumptions of Theorem 4.2.2.2, inequality (4,2,2,8) holds for all  $u \in W_p^2(B)$  which are solutions of problem (4,2,2,1) provided either  $\alpha_i = 1$  or  $\alpha_i = \beta_i = 0$  and  $\lambda_i = 1$  for each j = 0, 1.

**Theorem 4.2.2.4** Assume that b > 0,  $a \ne 0$  and that for each j = 0 or 1 we have either  $\alpha_i = 1$  or  $\alpha_i = \beta_i = 0$  and  $\lambda_i = 1$ . Assume in addition that equation (4,2,1,2) has no real root. Then there exists a constant C such that inequality (4,2,2) holds for  $u \in W_p^2(B)$  the solution of problem (4,2,1).

In the proof, we shall need this auxiliary lemma which we will prove later.

**Lemma 4.2.2.5** Assume that b>0,  $a\neq 0$  and that for each j we have either  $\alpha_i=1$  or  $\alpha_i=\beta_i=0$ . Then it is possible to find  $\mu_i$ , j=0,1, such that

$$\begin{split} r\cosh rh[\alpha_{0}(\mathrm{i}\beta_{1}\xi+\mu_{1}) - \alpha_{1}(\mathrm{i}\beta_{0}\xi+\mu_{0})] \\ + \sinh rh[r^{2}\alpha_{0}\alpha_{1} - (\mathrm{i}\beta_{0}\xi+\mu_{0})(\mathrm{i}\beta_{1}\xi+\mu_{1})], \end{split}$$

where  $r = \sqrt{(1+\xi^2)}$  does not vanish for  $\xi \in \mathbb{R}$ .

Proof of Theorem 4.2.2.4 Due to the assumption that equation (4,2,1,2) has no real root, inequality (4,2,1,4) holds. Next we shall use inequality (4,2,2,8) with  $\lambda_i$  replaced by  $\mu_i$ . From Corollary 4.2.2.3 and the trace theorems in Subsection 1.5, we deduce the existence of a constant  $C_1$  such that

$$||u||_{2,p,B} \le C_1 \left( ||-\Delta u + u||_{0,p,B} + \sum_{i=0}^1 ||\gamma_i(\alpha_i D_y u + \beta_i D_x u + \mu_i u)||_{2-d_i-1/p,p,F_i} \right)$$

for all  $u \in W_p^2(B)$ . In particular when u satisfies the boundary condition

$$\gamma_i(\alpha_i D_v u + \beta_i D_x u + \lambda_i u) = 0 \tag{4.2.2.9}$$

on  $F_{j}$ , we have

$$||u||_{2,p,B} \le C_1 \left\{ ||-\Delta u + u||_{0,p,B} + \sum_{d_i = 1} |\lambda_i - \mu_i| \, ||\gamma_i u||_{1 - 1/p,p,F_i} \right\}. \tag{4.2.2.10}$$

We observe that we have no boundary terms in the case when  $d_i = 0$ , since  $\gamma_i u = 0$ .

From (4,2,2,10) it follows that

$$||u||_{2,p,B} \le C_1 \Big\{ ||Lu||_{0,p,B} + ||aD_x u + (b+1)u||_{0,p,B} + \sum_{d_i=1} |\lambda_i - \mu_i| \, ||\gamma_i u||_{1-1/p,p,F_i} \Big\}.$$

In other words, we have

$$||u||_{2,p,B} \le C_2\{||Lu||_{0,p,B} + ||u||_{1,p,B}\}.$$

Next we take advantage of the inequality

$$||u||_{1,p,B} \leq \varepsilon ||u||_{2,p,B} + \frac{K}{\varepsilon} ||u||_{0,p,B}$$

for all  $\varepsilon < 1$ . If we choose  $\varepsilon$  to be  $1/2C_2$ , we obtain

$$||u||_{2,p,B} \le 2C_2 \Big\{ ||Lu||_{0,p,B} + \frac{K}{\varepsilon} ||u||_{0,p,B} \Big\}.$$

Finally, using inequality (4,2,1,4) we conclude that there exists a constant  $C_3$  such that

$$||u||_{2,p,B} \leq C_3 ||Lu||_{0,p,B}$$

for all  $u \in W_p^2(B)$  which fulfils the boundary conditions (4,2,3,9).

**Proof of Lemma 4.2.2.5** Let us consider first the case when  $\alpha_j = \beta_j = 0$  for j = 0, 1. Then the requirement is that equation

$$\mu_0 \mu_1 \sinh \sqrt{(1+\xi^2)} \ h = 0$$

should have no real root  $\xi$ . This is achieved provided  $\mu_i \neq 0$ , j = 0, 1.

Next we consider the mixed case when  $\alpha_0 = \beta_0 = 0$  and  $\alpha_1 = 1$ . Then the requirement is that equation

$$\mu_0 \sqrt{(1+\xi^2)} \cosh \sqrt{(1+\xi^2)} h + \mu_0 (i\beta_1 \xi + \mu_1) \sinh \sqrt{(1+\xi^2)} h = 0$$

should have no real root. The real part of the equation is

$$\mu_0\{\sqrt{1+\xi^2}\cosh\sqrt{1+\xi^2}\}\ h + \mu_1\sinh\sqrt{1+\xi^2}\ h\} = 0.$$

The condition is achieved if we choose  $\mu_0 \neq 0$  and  $\mu_1 = 0$ , for instance. Of course in the case  $\alpha_1 = \beta_1 = 0$  and  $\alpha_0 = 1$  we choose  $\mu_0 = 0$  and  $\mu_1 \neq 0$ .

Finally, let us consider the case when  $\alpha_0 = \alpha_1 = 1$ . Then we require that

$$\sqrt{(1+\xi^2)} \cosh \sqrt{(1+\xi^2)} h[i(\beta_1 - \beta_0)\xi + (\mu_1 - \mu_0)] + \sinh \sqrt{(1+\xi^2)} h[(1+\xi^2) - (i\beta_0\xi + \mu_0)(i\beta_1\xi + \mu_1)] = 0$$

should have no real root. The real part of this equation is

$$(\mu_1 - \mu_0)\sqrt{(1+\xi^2)} \cosh \sqrt{(1+\xi^2)} h + [1+\xi^2\{1+\beta_0\beta_1\} - \mu_0\mu_1] \sinh \sqrt{(1+\xi^2)} h = 0.$$

When  $1 + \beta_0 \beta_1 \ge 0$ , we can choose  $\mu_0 = \mu_1 = 0$ ; then the equation becomes

$$[1 + \xi^2 \{1 + \beta_0 \beta_1\}] \sinh \sqrt{1 + \xi^2} h = 0,$$

which has no real root. On the other hand, when  $1 + \beta_0 \beta_1 < 0$ , we can choose  $\mu_0 = \mu_1 = 2$ ; then the equation becomes

$$[-3+\xi^2\{1+\beta_0\beta_1\}] \sinh \sqrt{(1+\xi^2)} h$$

which has no real root either.

#### 4.3 Bounds in a polygon

#### 4.3.1 The L<sub>2</sub> case

We prove here inequality (4,1,2) when p=2. We follow word by word the proof in Grisvard (1972). The principle is the same as in Theorem 3.1.1.2 plus an additional density result. Again here, it is technically more convenient to work with

$$v = D_{x}u, \qquad w = D_{y}u.$$

The boundary conditions for v and w are the following.

**Lemma 4.3.1.1** Let  $u \in H^2(\Omega)$  fulfil the boundary conditions in (4,1,1); then for all j there exist two real numbers  $\lambda_j$  and  $\mu_j$  such that

$$\lambda_{i}\gamma_{i}v + \mu_{i}\gamma_{i}w = 0 \qquad \text{on } \Gamma_{i}$$
and  $\lambda_{i}^{2} + \mu_{i}^{2} \neq 0$ . (4,3,1,1)

**Proof** The condition (4,3,1,1) means that  $\nabla u$  is orthogonal to some nonzero vector whose components are  $\lambda_i$  and  $\mu_i$ . Indeed, in the notation of Section 4.1, we assume that

$$\boldsymbol{\gamma}_i \, \boldsymbol{\nabla} \boldsymbol{u} \, \cdot (\boldsymbol{v}_i + \boldsymbol{\beta}_i \boldsymbol{\tau}_i) = 0$$

on  $\Gamma_i$  for  $j \in \mathcal{N}$ , and that

$$\gamma_i \nabla u \cdot \tau_i = 0$$

on  $\Gamma_i$  for  $j \in \mathfrak{D}$ .

From now on, we denote by  $G^{s}(\Omega)$  the space

$$\{(v, w) \in H^s(\Omega) \times H^s(\Omega) \mid \gamma_i(\lambda_i v + \mu_i w) = 0 \text{ on } \Gamma_i, 1 \le j \le N\}.$$

#### Lemma 4.3.1.2 The identity

$$\int_{\Omega} D_{x}vD_{y}w \,dx \,dy = \int_{\Omega} D_{y}vD_{x}w \,dx \,dy \qquad (4,3,1,2)$$

holds for all  $(v, w) \in G^2(\Omega)$ .

**Proof** Integrating by parts twice, we obtain

$$\int_{\Omega} D_{x}vD_{y}w \,dx \,dy - \int_{\Omega} D_{y}vD_{x}w \,dx \,dy = \int_{\Gamma} \gamma v \,d\gamma w,$$

owing to the Green formula.

Next we split the boundary integral into pieces. We have

$$\int_{\Gamma} \gamma v \, d\gamma w = \sum_{j=1}^{N} \int_{\Gamma_{i}} \gamma_{i} v \, d\gamma_{i} w.$$

We assume that the  $\Gamma_j$  have been numbered according to the positive orientation of the boundary. We denote by  $S_i$  the terminal point of  $\Gamma_i$ ; thus  $S_{i-1}$  is the origin of  $\Gamma_i$  for i > 1, while  $S_N$  is the origin of  $\Gamma_1$ . (It is obviously convenient to set  $S_N = S_0$ ,  $\Gamma_{N+1} = \Gamma_1$ .)

When  $\mu_i \neq 0$ , we write  $\gamma_i w = -(\lambda_i/\mu_i)\gamma_i v$ , and consequently

$$\int_{\Gamma_i} \gamma_i v \, d\gamma_i w = -\frac{\lambda_i}{\mu_i} \int_{\Gamma_i} \gamma_i v \, d\gamma_i v = -\frac{\lambda_i}{2\mu_i} \{ (\gamma_i v)^2 (S_i) - (\gamma_i v)^2 (S_{i-1}) \}.$$

This identity is meaningful since  $v \in H^2(\Omega)$  and consequently  $v \in C(\overline{\Omega})$  by the Sobolev imbedding theorem.

When  $\mu_i = 0$  we just have  $\gamma_i v = 0$  on  $\Gamma_i$  and accordingly

$$\int_{\Gamma_i} \gamma_i v \, \mathrm{d}\gamma_i w = 0.$$

Next we observe that  $(\gamma_i v)(S_i) = (\gamma_{i+1} v)(S_i)$  due to Theorem 1.5.2.8. Thus,

we have

$$\begin{split} 2 \int_{\Gamma} \gamma v \, d\gamma w &= \sum_{\substack{\mu_{i}\mu_{i+1} \neq 0 \\ \mu_{i+1} \neq 0}} \bigg( \frac{\lambda_{j+1}}{\mu_{j+1}} - \frac{\lambda_{j}}{\mu_{j}} \bigg) (\gamma_{j}v)^{2} (S_{j}) \\ &+ \sum_{\substack{\mu_{i} = 0 \\ \mu_{i+1} \neq 0}} \frac{\lambda_{j+1}}{\mu_{j+1}} (\gamma_{j}v)^{2} (S_{j}) - \sum_{\substack{\mu_{i} \neq 0 \\ \mu_{i+1} = 0}} \frac{\lambda_{j}}{\mu_{j}} (\gamma_{j}v)^{2} (S_{j}). \end{split}$$

We shall now check that  $(\gamma_i v)(S_i) = 0$  for all j such that  $\lambda_{j+1} \mu_j \neq \lambda_j \mu_{j+1}$  and consequently that

$$\int_{\Gamma} \gamma v \, \mathrm{d} \gamma w = 0.$$

Indeed at  $S_i$  the boundary conditions corresponding to  $\Gamma_i$  and  $\Gamma_{i+1}$  hold together by continuity. Thus, we have

$$\begin{cases} \lambda_i(\gamma_j v)(S_i) + \mu_i(\gamma_j w)(S_i) = 0 \\ \lambda_{i+1}(\gamma_i v)(S_i) + \mu_{i+1}(\gamma_j w)(S_i) = 0. \end{cases}$$

This implies that  $\gamma_i v(S_i) = 0$  when  $\lambda_i \mu_{i+1} \neq \lambda_{i+1} \mu_i$ . This is the claim. Summing up, we have proved that

$$\int_{\Omega} D_{x}vD_{y}w \, dx \, dy = \int_{\Omega} D_{y}vD_{x}w \, dx \, dy$$

for all  $(v, w) \in G^2(\Omega)$ .

In order to extend the previous result to the whole of  $G^1(\Omega)$ , we need a density lemma.

**Lemma 4.3.1.3**  $G^2(\Omega)$  is dense in  $G^1(\Omega)$ ; consequently (4,3,1,2) holds for all  $\{v, w\}$  in  $G^1(\Omega)$ .

**Proof** The trace Theorem 1.5.1.3 allows us to consider  $H^1(\Omega)$  as the direct sum of  $\mathring{H}^1(\Omega)$  with the space  $H^{1/2}(\Gamma)$ . Thus any continuous linear form l on  $G^1(\Omega)$  may be represented as

$$\langle l; \{v, w\} \rangle = \langle S, v - \rho \gamma v \rangle + \langle T, w - \rho \gamma w \rangle + \langle g, \gamma v \rangle + \langle h, \gamma w \rangle$$

where S,  $T \in H^{-1}(\Omega)$  and g,  $h \in H^{-1/2}(\Gamma)$  and where  $\rho$  is a right inverse for the trace operator  $\gamma$ .

Let us assume that l vanishes on  $G^2(\Omega)$ . Then, in particular, it vanishes on  $\mathring{H}^2(\Omega) \times \mathring{H}^2(\Omega)$  and, therefore, we have

$$\langle S, v \rangle + \langle T, w \rangle = 0$$

for all  $v, w \in \mathring{H}^2(\Omega)$ . This implies that S = T = 0. We have thus shown that any continuous linear form on  $G^1(\Omega)$  which vanishes on  $G^2(\Omega)$  may be

represented as

$$\langle l; \{v, w\} \rangle = \langle g; \gamma v \rangle + \langle h; \gamma w \rangle,$$

where g and  $h \in H^{-1/2}(\Gamma)$ .

Now, in order to prove that  $G^2(\Omega)$  is dense in  $G^1(\Omega)$ , we have to check that any such l is identically zero. In view of the above representation formula, it is therefore enough to prove that the space  $Z^2(\Gamma)$  of the traces of the functions in  $G^2(\Omega)$  is dense in the space  $Z^1(\Gamma)$  of the traces of the functions in  $G^1(\Omega)$ .

A first step is to describe these spaces, taking advantage of Theorem 1.6.1.5. Let us begin with  $Z^1(\Gamma)$ . This is a subspace of  $\{\prod_{i=1}^N H^{1/2}(\Gamma_i)\}^2$ . An element belonging to  $Z^1(\Gamma)$  will be denoted

$$\{g_j, h_j\}_{j=1}^N$$

where  $g_i$  stands for  $\gamma_i v$  and  $h_i$  stands for  $\gamma_i w$ . According to this notation  $Z^{1}(\Gamma)$  is the subspace defined by

$$\begin{cases} \lambda_{i}g_{i} + \mu_{i}h_{j} = 0 & \text{on} \quad \Gamma_{i}, & 1 \leq j \leq N \\ \int_{0}^{\delta_{i}} \frac{|h_{j+1}(x_{j}(\sigma)) - h_{j}(x_{j}(-\sigma))|^{2}}{\sigma} d\sigma < \infty, & 1 \leq j \leq N \\ \int_{0}^{\delta_{i}} \frac{|g_{j+1}(x_{j}(\sigma)) - g_{j}(x_{j}(-\sigma))|^{2}}{\sigma} d\sigma < \infty, & 1 \leq j \leq N. \end{cases}$$

$$(4,3,1,3)$$

Now we choose N pairs of real numbers  $(\xi_i, \eta_i)$  with  $\xi_i^2 + \eta_i^2 \neq 0$ ,  $1 \le i \le N$  and such that

(a) 
$$\xi_i \mu_i - \eta_i \lambda_i \neq 0$$
,  $1 \leq j \leq N$ 

(a) 
$$\xi_{j}\mu_{j} - \eta_{j}\lambda_{j} \neq 0$$
,  $1 \leq j \leq N$   
(b)  $(\xi_{j}, \eta_{j}) = (\xi_{j+1}, \eta_{j+1})$  for all  $j$  such that  $\lambda_{j}\mu_{j+1} - \lambda_{j+1}\mu_{j} = 0$ .

In other words, we require the vector  $\mathbf{v}_i = (\xi_i; \eta_i)$  to be linearly independent of the vector  $(\lambda_i; \mu_i)$  and in addition we require  $\mathbf{v}_i$  to be equal to  $\mathbf{v}_{i+1}$  whenever  $(\lambda_i, \mu_i)$  and  $(\lambda_{i+1}, \mu_{i+1})$  are linearly dependent. Such a choice of vectors  $\mathbf{v}_i$  is obviously possible. Next, let us define

$$\varphi_i = \xi_i g_i + \eta_i h_j, \qquad 1 \le j \le N. \tag{4.3.1.4}$$

It is easy to check that  $Z^{1}(\Gamma)$  is isomorphic to the subspace of those

$$\{\varphi_i\}_{i=1}^N \in \prod_{j=1}^N H^{1/2}(\Gamma_i)$$

such that

$$\begin{cases}
\int_{0}^{\delta_{i}} |\varphi_{j}(x_{i}(-\sigma))|^{2} \frac{d\sigma}{\sigma} < \infty \\
\int_{0}^{\delta_{i}} |\varphi_{j+1}(x_{j}(\sigma))|^{2} \frac{d\sigma}{\sigma} < \infty
\end{cases}$$
(4,3,1,5)

when  $\lambda_i \mu_{i+1} - \lambda_{i+1} \mu_i \neq 0$  and such that

$$\int_{0}^{\delta_{i}} |\varphi_{j}(x_{j}(-\sigma)) - \varphi_{j+1}(x_{j}(\sigma))|^{2} \frac{d\sigma}{\sigma} < \infty$$

$$(4,3,1,6)$$

when  $\lambda_i \mu_{i+1} - \lambda_{i+1} \mu_i = 0$ .

In the same way we describe the space  $Z^2(\Gamma)$ . It is the subspace of  $\{\prod_{i=1}^{N} H^{3/2}(\Gamma_i)\}^2$  defined by

$$\begin{cases} \lambda_{j}g_{j} + \mu_{j}h_{j} = 0 & \text{on} \quad \Gamma_{j}, & 1 \leq j \leq N \\ h_{j+1}(S_{j}) = h_{j}(S_{j}), & 1 \leq j \leq N \\ g_{j+1}(S_{i}) = g_{i}(S_{i}), & 1 \leq j \leq N. \end{cases}$$

$$(4,3,1,7)$$

Then introducing again  $\varphi_i$  defined by (4,3,1,4), we check that  $Z^2(\Gamma)$  is isomorphic to the subspace of those  $\{\varphi_j\}_{j=1}^N \in \prod_{j=1}^N H^{3/2}(\Gamma_j)$  such that

$$\varphi_i(S_i) = \varphi_{i+1}(S_i) = 0 \tag{4.3.1.8}$$

when  $\lambda_i \mu_{i+1} - \lambda_{i+1} \mu_i \neq 0$  and such that

$$\varphi_i(S_i) = \varphi_{i+1}(S_i) \tag{4,3,1,9}$$

when  $\lambda_i \mu_{i+1} - \lambda_{i+1} \mu_i = 0$ .

Finally let us consider  $\{\varphi_i\}_{i=1}^N \in Z^1(\Gamma)$ . Due to the density of  $\mathfrak{D}(\Gamma_i)$  in  $\tilde{H}^{1/2}(\Gamma_i)$  and of  $\mathfrak{D}(\bar{\Gamma}_i)$  in  $H^{1/2}(\Gamma_i)$  (see Subsection 1.4.2), we can approximate  $\varphi_i$  by  $\varphi_{i,m} \in H^{3/2}(\Gamma_i)$ ,  $m = 1, 2, \ldots$  such that, for each m, (4,3,1,8)and (4,3,1,9) hold with  $\varphi_i$  replaced by  $\varphi_{i,m}$ . This can be achieved in such a way that

$$\varphi_{i,m} \rightarrow \varphi_i$$

in the norm of  $H^{1/2}(\Gamma_i)$  and, in addition, that

$$\int_{0}^{\delta_{i}} |(\varphi_{i} - \varphi_{i,m})(\mathbf{x}_{i}(-\sigma))|^{2} \frac{d\sigma}{\sigma} \to 0$$

$$\int_{0}^{\delta_{i}} |(\varphi_{i+1} - \varphi_{i+1,m})(\mathbf{x}_{i}(\sigma))|^{2} \frac{d\sigma}{\sigma} \to 0$$

when  $\lambda_i \mu_{i+1} - \lambda_{i+1} \mu_i \neq 0$ , while

$$\int_0^{\delta_i} |(\varphi_j - \varphi_{j,m})(x_j(-\sigma)) - (\varphi_{j+1} - \varphi_{j+1,m})(x_j(\sigma))|^2 \frac{\mathrm{d}\sigma}{\sigma} \to 0$$

when  $\lambda_i \mu_{i+1} - \lambda_{i+1} \mu_i = 0$ . This completes the proof of Lemma 4.3.1.3.

We are now able to prove our main result.

**Theorem 4.3.1.4** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$  with a (strictly)

polygonal boundary  $\Gamma$ . Then there exists a constant C such that

$$||u||_{2,2,\Omega} \le C\{||f||_{0,2,\Omega} + ||u||_{0,2,\Omega}\} \tag{4,3,1,10}$$

for all  $u \in H^2(\Omega)$  which are solutions of problem (4,1,1).

*Proof* This is proved via a very straightforward calculation. As in Section 3.1.2 we calculate the following integral

$$\int_{\Omega} |\Delta u|^2 dx dy = \int_{\Omega} |D_x^2 u + D_y^2 u|^2 dx dy$$

$$= \int_{\Omega} |D_x^2 u|^2 dx dy + \int_{\Omega} |D_y^2 u|^2 dx dy + 2 \int_{\Omega} |D_x^2 u D_y^2 u dx dy$$
(4,3,1,11)

Then applying Lemma 4.3.1.3 to  $v = D_x u$ ,  $w = D_y u$ , we obtain

$$\int_{\Omega} \{ |D_x^2 u|^2 + |D_y^2 u|^2 + 2 |D_x D_y u|^2 \} dx dy = \int_{\Omega} |\Delta u|^2 dx dy.$$

Consequently we have

$$||u||_{2,2,\Omega}^2 \le ||f||_{0,2,\Omega}^2 + ||u||_{1,2,\Omega}^2$$

and the result follows by inequality (1,4,3,2).

Remark 4.3.1.5 Here we have a very precise control of the constant in inequality (4,3,1,10). Indeed it depends only on the best constant K in inequality (1,4,3,2); in this particular case this is

$$||u||_{1,2,\Omega} \le \varepsilon ||u||_{2,2,\Omega} + K\varepsilon^{-1} ||u||_{0,2,\Omega}$$

In most practical cases, given a plane domain  $\Omega$  with a polygonal boundary, the constant K can be determined explicitly as a function of  $\Omega$ .

Remark 4.3.1.6 Let us observe for further reference that we have proved identity (4,3,1,11) for all functions  $u \in H^2(\Omega)$  which fulfil the boundary conditions in (4,1,1).

Remark 4.3.1.7 So far we have excluded the domains  $\Omega$  with cuts. However, the inequality (4,3,1,10) remains valid if one allows  $\Omega$  to have cuts. Indeed the only modification of the proof occurs in Lemma 4.3.1.3. An application of Theorem 1.7.3 must be substituted for the application of Theorem 1.6.1.5 at the appropriate corners.

#### 4.3.2 The $L_p$ case $(p \neq 2)$

We shall now derive inequality (4,1,2) for  $p \neq 2$ . The method that we shall use here is quite different from the method of Subsection 4.3.1. Curiously

enough, the method used here does not work when p = 2. (See, however, Section 4 in Kondratiev (1967a) who deals with the case p = 2.) It relies essentially on the estimates proved in Section 4.2.

We shall need some new weighted spaces similar to those introduced by Kondratiev (1967a) in the case when p = 2. We shall denote by  $\rho(x, y)$  the distance from the point (x, y) to the vertices  $(S_i, 1 \le j \le N)$  of  $\Omega$ .

**Definition 4.3.2.1** We denote by  $P_p^m(\Omega)$  the space of all functions u defined in  $\Omega$  such that

$$\rho^{|\alpha|-m}D^{\alpha}u\in L_p(\Omega)$$

for all  $|\alpha| \leq m$ .

Obviously we can define a Banach norm on  $P_{\mathfrak{p}}^m(\Omega)$  by setting

$$||u||_{P_p^m(\Omega)} = \sum_{|\alpha| \leq m} ||\rho^{|\alpha|-m} D^{\alpha} u||_{0,p,\Omega}.$$

The inclusion of  $P_p^m(\Omega)$  into  $W_p^m(\Omega)$  is obvious. We shall actually need a converse statement. Fortunately the converse inclusion holds, up to the addition of a finite-diensional space, at least when  $p \neq 2$ .

**Theorem 4.3.2.2** Let  $u \in W_p^m(\Omega)$  be such that

$$D^{\alpha}u(S_i) = 0$$
 for  $|\alpha| < m - \frac{2}{p}$ 

j = 1, 2, ..., N and  $p \neq 2$ ; then  $u \in P_p^m(\Omega)$ .

Proof By induction on k, we shall prove that

$$\rho^{-k}D^{\alpha}u \in L_{p}(\Omega) \tag{4.3.2.1}$$

for  $|\alpha| \le m - k$ . Thus we assume that inclusion (4,3,2,1) holds for a given k and we derive the same inclusion where k is replaced by k+1.

Let  $|\alpha| \le m - k - 1$  and set  $v = D^{\alpha}u$ . Thus we know that

$$\rho^{-k}v, \qquad \rho^{-k} \nabla v \in L_p(\Omega).$$

In addition we know that  $v(S_i) = 0$  when p > 2 or when  $k \ge 1$ . We shall show that this implies that

$$\rho^{-k-1}v\in L_p(\Omega).$$

Let us first look at the case where k = 0 and p < 2. We observe that the condition that  $\rho^{-k-1}v$  belongs to  $L_p(\Omega)$  is relevant only near the vertices.

<sup>†</sup> Let l be the greatest integer < m - 2/p; it follows from Sobolev's imbedding theorem, that  $u \in C^1(\bar{\Omega})$  and consequently the condition  $D^{\alpha}u(S_i) = 0$  is meaningful for  $|\alpha| < m - 2/p$ .

This allows us to localize the problem. Let  $\eta_i \in \mathcal{D}(\mathbb{R}^2)$  be such that  $\eta_i \equiv 1$  near  $S_i$  and  $\eta_i \equiv 0$  outside a small circle centred at  $S_i$  which contains no other vertex of  $\Omega$ . Let us denote its radius by  $\delta_i$ . Now we only need to show that

$$\rho^{-1}\eta_i v \in L_p(\Omega)$$

for all j. Using polar coordinates centred at  $S_i$ , we can write

$$(\eta_{j}v)(\rho e^{i\theta}) = \int_{0}^{\delta_{i}} \frac{\partial}{\partial \sigma} (\eta_{j}v)(\sigma e^{i\theta}) d\sigma.$$

Equivalently, we have

$$\rho^{-1}(\eta_{j}v)(\rho e^{i\theta}) = \frac{1}{\rho} \int_{\rho}^{\infty} \frac{\partial}{\partial \sigma} (\eta_{j}v)(\sigma e^{i\theta}) d\sigma.$$

From the assumptions on v it follows that  $|(\partial/\partial\sigma)(\eta_j v)|^p$  is integrable with respect to the measure  $\sigma$  d $\sigma$  d $\theta$ . By Hardy's inequality (see Subsection 1.4.4) it follows that  $|\rho^{-1}\eta_i v|^p$  is integrable with respect to the measure  $\rho$  d $\rho$  d $\theta$ . This is the claim.

Let us now consider the case where either p > 2 or  $k \ge 1$ . Then with the same notation we write

$$\rho^{-1}(\eta_i v)(\rho e^{i\theta}) = \frac{1}{\rho} \int_0^\rho \frac{\partial}{\partial \sigma} (\eta_i v)(\sigma e^{i\theta}) d\sigma,$$

and again the inequality mentioned above shows that  $|\rho^{-1}\eta_i v|^p$  is integrable with respect to the measure  $\rho d\rho d\theta$ .

The basic result in this subsection is the following

#### **Theorem 4.3.2.3** There exists a constant C such that

$$||u||_{P_{\sigma}^{2}(\Omega)} \le C\{||f||_{0,p,\Omega} + ||u||_{1,p,\Omega}\}$$

for all  $u \in P_p^2(\Omega)$  which are solutions of problem (4,1,1), provided

$$\frac{1}{\pi} \left( \Phi_{j+1} - \Phi_j - \frac{2}{q} \omega_j \right)$$

is not an integer for any j, where  $\Phi_j = \arctan \beta_j$  for  $j \in \mathcal{N}$  and  $\Phi_j = \pi/2$  for  $j \in \mathcal{D}$ .

**Proof** Again we can consider our problem locally. We fix a partition of unity  $\{\eta\}_i$ ,  $j=0,\ldots,N$  on  $\bar{\Omega}$  such that  $\eta_i \in \mathcal{D}(\mathbb{R}^2)$  for each j and

- (a) the support of  $\eta_0$  does not contain any vertex of  $\Omega$ ,
- (b) the support of  $\eta_i$  contains  $S_i$  and does not contain any other vertex; in addition the support of  $\eta_i$  does not intersect  $\Gamma_k$  for  $k \neq j$  and  $k \neq j+1$ .

(c)  $\partial \eta_j / \partial \nu_k + \beta_k (\partial \eta_j / \partial \tau_k) = 0$  on  $\Gamma_k$  for k = j if  $j \in \mathcal{N}$  and for k = j + 1 if  $j + 1 \in \mathcal{N}$ .

It follows that there exists  $K_i$  such that

$$\|\Delta(\eta_{i}u) - \eta_{i}f\|_{0,p,\Omega} \le K_{i} \|u\|_{1,p,\Omega} \tag{4.3.2.2}$$

and

$$\begin{cases} \eta_{i}u = 0 & \text{on } \Gamma_{k}, \quad k \in \mathcal{D} \\ \frac{\partial}{\partial \nu_{k}} (\eta_{i}u) + \beta_{k} \frac{\partial}{\partial \tau_{k}} (\eta_{i}u) = 0 & \text{on } \Gamma_{k}, \quad k \in \mathcal{N} \end{cases}$$

for i = 1, 2, ..., N.

The results in Subsection 2.3.3 imply that

$$\|\eta_0 u\|_{2,p,\Omega} \le C_0 \{ \|f\|_{0,p,\Omega} + \|u\|_{1,p,\Omega} \}$$

$$(4,3,2,3)$$

since the support of  $\eta_0 u$  is at a strictly positive distance from the corners.

We are now left with estimating  $\eta_j u$  for j = 1, ..., N. For that purpose we use local coordinates as follows.

We fix j once and for all and choose polar coordinates with origin at  $S_j$ , and such that  $\theta = 0$  on  $\Gamma_{j+1}$ , while  $\theta = \omega_j$  on  $\Gamma_j$ . We also denote by G the

![](_page_217_Figure_14.jpeg)

Figure 4.1

infinite sector defined by the half lines with origin at  $S_i$  and which contain  $\Gamma_i$  and  $\Gamma_{i+1}$  respectively.

With this notation the function  $v = \widetilde{\eta_i u}$  is a solution of

$$\Delta v = g$$
 in  $G$ 

where

$$||g||_{0,p,G} \le K\{||f||_{0,p,\Omega} + ||u||_{1,p,\Omega}\}$$

with the following boundary conditions. On the line  $\theta = 0$  we have

$$\mathbf{v} = 0$$

if  $j+1 \in \mathcal{D}$  and we have

$$\frac{1}{r}\frac{\partial v}{\partial \theta} - \beta_{i+1}\frac{\partial v}{\partial r} = 0$$

if  $j+1 \in \mathcal{N}$ . In the same way, on  $\theta = \omega_j$  we have

$$v = 0$$

if  $j \in \mathcal{D}$  and we have

$$\frac{1}{r}\frac{\partial v}{\partial \theta} - \beta_i \frac{\partial v}{\partial r} = 0$$

if  $j \in \mathcal{N}$ .

Finally we set

$$w(t, \theta) = e^{-(2/q)t}v(e^{t+i\theta}),$$
 (4,3,2,4)

where we make the following abuse of notation whose meaning is obvious: we denote by  $v(e^{t+i\theta})$  the value of v at the point whose polar coordinates are  $e^t$  and  $\theta$ . Then w is solution of a boundary value problem in the strip

$$B = \mathbb{R} \times ]0, \omega_{i}[.$$

The equation is

$$D_{t}^{2}w + D_{\theta}^{2}w + \frac{4}{q}D_{t}w + \frac{4}{q^{2}}w = k$$
 (4,3,2,5)

in B, where we have set

$$k(t;\theta) = e^{-(2/q)t} \{ e^{2t} g(e^{t+i\theta}) \}.$$
 (4,3,2,6)

The boundary condition at  $\theta = \omega_i$  is as follows:

$$w = 0 (4,3,2,7a)$$

if  $i \in \mathcal{D}$  and

$$D_{\theta}w - \beta_{j}D_{t}w - \frac{2}{a}\beta_{j}w = 0$$
 (4,3,2,7b)

if  $j \in \mathcal{N}$ . In the same way, the boundary condition at  $\theta = 0$  is as follows

$$w = 0 (4,3,2,8a)$$

if  $i+1 \in \mathcal{D}$  and

$$D_{\theta}w - \beta_{j+1}D_{t}w - \frac{2}{q}\beta_{j+1}w = 0$$
 (4,3,2,8b)

if  $j+1 \in \mathcal{N}$ .

The boundary value problem (4,3,2,5) (4,3,2,7) (4,3,2,8) is one of those that we have studied in Section 4.2. Applying Theorem 4.2.2.4, we know that inequality (4,2,2) holds provided the following equation has no real root. When j and  $j+1 \in \mathcal{N}$  the equation is

$$\sin \rho \omega_i (1 + \beta_i \beta_{i+1}) = \cos \rho \omega_i (\beta_{i+1} - \beta_i), \tag{4.3.2.9a}$$

where  $\rho = 2/q + i\xi$ ,  $\xi \in \mathbb{R}$ . When  $j \in \mathcal{N}$  and  $j + 1 \in \mathcal{D}$  the equation is

$$\beta_i \sin \rho \omega_i = \cos \rho \omega_i. \tag{4,3,2,9b}$$

When  $j \in \mathcal{D}$  and  $j+1 \in \mathcal{N}$  the equation is

$$\beta_{i+1}\sin\rho\omega_i = -\cos\rho\omega_i. \tag{4,3,2,9c}$$

Finally, when j and  $j+1 \in \mathcal{D}$ , the equation is just

$$\sin \rho \omega_j = 0. \tag{4.3.2.9d}$$

Separating the real part and the imaginary part in equations (4,3,2,9) we obtain the following systems of equations:

$$\begin{cases} (1+\beta_{i}\beta_{i+1})\sin\frac{2}{q}\omega_{i}\cosh\xi\omega_{i} = (\beta_{i+1}-\beta_{i})\cos\frac{2}{q}\omega_{i}\cosh\xi\omega_{i} \\ (1+\beta_{i}\beta_{i+1})\cos\frac{2}{q}\omega_{i}\sinh\xi\omega_{i} = (\beta_{i}-\beta_{i+1})\sin\frac{2}{q}\omega_{i}\sinh\xi\omega_{i} \end{cases}$$

when j and j+1 belong to  $\mathcal{N}$  and

$$\begin{cases} \beta_{i} \sin \frac{2}{q} \omega_{i} \cosh \xi \omega_{i} = \cos \frac{2}{q} \omega_{i} \cosh \xi \omega_{i} \\ \beta_{i} \cos \frac{2}{q} \omega_{i} \sinh \xi \omega_{i} = -\sin \frac{2}{q} \omega_{i} \sinh \xi \omega_{i} \end{cases}$$

when  $j \in \mathcal{N}$  and  $j+1 \in \mathcal{D}$  and

$$\begin{cases} \beta_{j+1} \sin \frac{2}{q} \omega_j \cosh \xi \omega_j = -\cos \frac{2}{q} \omega_j \cosh \xi \omega_j \\ \beta_{j+1} \cos \frac{2}{q} \omega_j \sinh \xi \omega_j = \sin \frac{2}{q} \omega_j \sinh \xi \omega_j \end{cases}$$

when  $j \in \mathcal{D}$  and  $j+1 \in \mathcal{N}$  and finally

$$\begin{cases} \sin\frac{2}{q}\omega_i \cosh \xi \omega_i = 0\\ \cos\frac{2}{q}\omega_i \sinh \xi \omega_i = 0 \end{cases}$$

when j and j+1 belong to  $\mathfrak{D}$ .

In each of the previous systems of equations,  $\xi = 0$  is a root of the second equation, while the first equation can be divided by  $\cosh \xi \omega_i$ . It follows that equation (4,3,2,9) has no real root iff

$$(1+\beta_i\beta_{i+1})\sin\frac{2}{q}\,\omega_i\neq(\beta_{i+1}-\beta_i)\cos\frac{2}{q}\,\omega_i$$

when j and j+1 belong to  $\mathcal{N}$  and

$$\beta_{\rm j} \sin \frac{2}{q} \omega_{\rm j} \neq \cos \frac{2}{q} \omega_{\rm j}$$

when  $j \in \mathcal{N}$  and  $j+1 \in \mathcal{D}$  and

$$\beta_{j+1}\sin\frac{2}{q}\,\omega_j\neq-\cos\frac{2}{q}\,\omega_j$$

when  $j \in \mathcal{D}$  and  $j+1 \in \mathcal{N}$  and finally

$$\sin\frac{2}{q}\,\omega_j\neq 0$$

when j and j+1 belong to  $\mathfrak{D}$ . If we define  $\Phi_j$  by the equation

$$\tan \Phi_i = \beta_i$$

when  $j \in \mathcal{N}$  and set  $\Phi_j = \pi/2$  when  $j \in \mathcal{D}$ , then all the previous conditions can be summarized as

$$\frac{\Phi_{j+1} - \Phi_j + k\pi}{\omega_i} \neq \frac{2}{q}.$$
 (4,3,2,10)

for all  $k \in \mathbb{Z}$  (i.e. k an integer).

When condition (4,3,2,10) is fulfilled then inequality (4,2,2) holds for

206

our problem and this means the existence of a constant  $C_i$  such that

$$||w||_{2,p,B} \leq C_i ||k||_{0,p,B}$$

Finally, performing the inverse change of variables in (4,3,2,4) and (4,3,2,6), we see that there exists another constant  $C'_i$  such that

$$||v||_{P_n^2(G)} \le C_i' ||g||_{0,p,G}$$

and consequently

$$\|\eta_{j}u\|_{P^{2}(G)} \leq C'_{j}K\{\|f\|_{0,p,\Omega} + \|u\|_{1,p,\Omega}\}. \tag{4,3,2,11}$$

These last inequalities together with inequality (4,3,2,3) imply the claim in Theorem 4.3,2.3.

An easy consequence of Theorems 4.3.2.2 and 4.3.2.3 is the following theorem.

**Theorem 4.3.2.4** Assume that  $p \neq 2$  and that

$$\frac{1}{\pi} \left( \Phi_{j+1} - \Phi_j - \frac{2}{q} \omega_j \right)$$

is not an integer for any j where  $\Phi_j = \arctan \beta_i$  for  $j \in \mathcal{N}$  and  $\Phi_j = \pi/2$  for  $j \in \mathcal{D}$ . Then there exists a constant C such that

$$||u||_{2,p,\Omega} \le C\{||\Delta u||_{0,p,\Omega} + ||u||_{1,p,\Omega}\}$$
(4,3,2,12)

for all  $u \in W^2_p(\Omega)$  which are solutions of the problem (4,1,1).

**Proof** Let us denote by E the space of all  $u \in W_p^2(\Omega)$  which fulfil the boundary conditions of problem (4,1,1). Let us also denote by F the subspace of E defined by the conditions

$$u(S_j) = 0, \qquad 1 \le j \le N$$

(This is not an extra condition when j or j+1 belongs to  $\mathcal{D}$ ) and

$$\nabla u(S_i) = 0, \quad 1 \le j \le N \quad \text{when } p > 2.$$

(This is not an extra condition when j and j+1 belong to  $\mathcal{N}$  and  $\mathbf{v}_j + \boldsymbol{\beta}_j \boldsymbol{\tau}_j$  and  $\mathbf{v}_{j+1} + \boldsymbol{\beta}_{j+1} \boldsymbol{\tau}_{j+1}$  are linearly independent. It is not an extra condition either when  $j \in \mathcal{D}$ ,  $j+1 \in \mathcal{N}$  and  $\boldsymbol{\tau}_j$  and  $\boldsymbol{v}_{j+1} + \boldsymbol{\beta}_{j+1} \boldsymbol{\tau}_{j+1}$  are independent (and, mutatis mutandis, when  $j \in \mathcal{N}$  and  $j+1 \in \mathcal{D}$ ).) The codimension of F in E is finite and due to Theorem 4.3.2.2, F is a subspace of  $P_p^2(\Omega)$ . Thus inequality (4,3,2,12) holds for all  $u \in F$ , by Theorem 4.3.2.3.

Now let us denote by  $\Pi$  any projection from E onto F. It is clear that

$$\Pi u = u - \sum_{i=1}^{N} u(S_i) \varphi_i$$

when p < 2 and

$$\Pi u = u - \sum_{i=1}^{N} \{ u(S_i) \varphi_i + D_x u(S_i) \psi_i + D_y u(S_i) \xi_i \}$$

when p>2 where  $\varphi_i$ ,  $\psi_i$ ,  $\xi_i$  belong to  $W_p^2(\Omega)$ . This representation shows that  $\Pi$  is also a linear continuous operator in the norm of  $W_p^s(\Omega)$  provided

$$\frac{2}{p} < s \le 2 \qquad \text{when} \quad p < 2$$

and

$$1 + \frac{2}{p} < s \le 2$$
 when  $p > 2$ . (4,3,2,13)

We can now prove the desired inequality. Let  $u \in E$ , then we have

$$||u||_{2,p,\Omega} \le ||u - \Pi u||_{2,p,\Omega} + ||\Pi u||_{2,p,\Omega}$$
  
$$\le ||u - \Pi u||_{2,p,\Omega} + C\{||\Delta \Pi u||_{0,p,\Omega} + ||\Pi u||_{1,p,\Omega}\}$$

since we can apply Theorem 4.3.2.3 to  $\Pi u$ . It follows that

$$||u||_{2,p,\Omega} \leq ||u - \Pi u||_{2,p,\Omega} + C\{||\Delta u||_{0,p,\Omega} + ||\Delta (u - \Pi u)||_{0,p,\Omega} + ||u||_{1,p,\Omega} + ||u - \Pi u||_{1,p,\Omega}\}$$
  
$$\leq C_1 ||u - \Pi u||_{2,p,\Omega} + C\{||\Delta u||_{0,p,\Omega} + ||u||_{1,p,\Omega}\}.$$

Next, we observe that on the finite dimensional space  $(1-\Pi)E$ , the norms of  $W_p^2(\Omega)$  and of  $W_p^s(\Omega)$  are equivalent for s < 2. We choose s such that condition (4,3,2,13) is fulfilled so that  $\Pi$  is continuous in the  $W_p^s(\Omega)$  norm. Therefore we have

$$||u||_{2,p,\Omega} \le C_2 ||u - \Pi u||_{s,p,\Omega} + C\{||\Delta u||_{0,p,\Omega} + ||u||_{1,p,\Omega}\}$$
  
$$\le C_3 ||u||_{s,p,\Omega} + C ||\Delta u||_{0,p,\Omega}.$$

We conclude by taking advantage of inequality (1,4,3,2) which implies that

$$||u||_{s,p,\Omega} \le \varepsilon ||u||_{2,p,\Omega} + K\varepsilon^{(1-s)/(2-s)} ||u||_{1,p,\Omega}$$

for every  $\varepsilon \in ]0, 1[$ . Choosing  $C_3 \varepsilon = \frac{1}{2}$ , we conclude that

$$||u||_{2,p,\Omega} \le 2C ||\Delta u||_{0,p,\Omega} + C_3 K \varepsilon^{(1-s)/(2-s)} ||u||_{1,p,\Omega}.$$

This is inequality (4,3,2,12).

Remark 4.3.2.5 The inequality (4,1,2) follows plainly from inequality

(4,3,2,12) by applying again inequality (1,4,3,2):

$$||u||_{1,p,\Omega} \le \varepsilon ||u||_{2,p,\Omega} + K\varepsilon^{-1} ||u||_{0,p,\Omega}$$

for for every s E ]0, 1[.

Remark 4.3.2.6 Here we have very poor control of the constant in inequality (4,3,2,12) in particular because of the abstract functional analysis procedure that we used for dealing with the equivalences of norms on finite-dimensional spaces. In that respect we have much less information in the case p 2 in comparison with the case p =2 (see Remark 4.3.1.5).

Remark 4.3.2.7 The inequality (4,3,2,12) remains valid for domains with cuts (i.e. we allow Wi = 21r for some j). Indeed the results in Section 4.2 have been derived without any limitation on the width h of the strip B. Thus the only modification lies in the proof of Theorem 4.3.2.4. There the imbedding (1,7,4) has to replace the usual Sobolev imbedding (1,4,4,6) in the definition of the space E.

#### 4.4 The Fredholm alternative

In this section we shall derive the consequences of the inequality (4,1,2). An immediate consequence is that our problem has the semi-Fredholm property. Then in most cases we shall be able to prove the uniqueness of the solution by very straightforward arguments. Studying the range of the Laplace operator under the given boundary conditions will require much more work. A careful study of the orthogonal of the range will allow us to calculate exactly the index of our problem.

#### 4.4.1 The semi-Fredholm properties

We first need a classical result of functional analysis.

Lemma 4.4.1.1 *Let E1 and E2 be* two Banach spaces *such that* E1 is *cornpactly imbedded* in E<sup>2</sup> . Assume that A is a *continuous linear operator from* El *into E2* and that *there* exists a constant C such that

$$||x||_{E_1} \le C\{||Ax||_{E_2} + ||x||_{E_2}\}$$
 (4,4,1,1)

*for* all x E E<sup>1</sup> . Then A has a finite-dimensional *kernel and a closed range.*

In other words, A is a semi-Fredholm operator. We now apply this

result to  $A = \Delta$  considered as an operator from

$$E_1 = \{ u \in W_p^2(\Omega); \ \gamma_i u = 0 \text{ on } \Gamma_i, j \in \mathcal{D} \text{ and}$$
$$\gamma_i(\partial u/\partial \nu_i) + \beta_i(\partial/\partial \tau_i)\gamma_i u = 0 \text{ on } \Gamma_i, j \in \mathcal{N} \}$$

into  $E_2 = L_p(\Omega)$ . Due to Theorem 1.4.3.2,  $E_1$  is compactly imbedded in  $E_2$  and inequality (4,1,2) is nothing but inequality (4,4,1,1). Thus Lemma 4.4.1.1 shows that the space of the solutions  $u \in W_p^2(\Omega)$  of problem (4,1,1) for f = 0 is finite-dimensional. In addition, the subspace of all  $f \in L_p(\Omega)$ , for which problem (4,1,1) has a solution  $u \in W_p^2(\Omega)$ , is closed in  $L_p(\Omega)$ .

We shall now investigate the uniqueness of u. We shall state two kinds of results corresponding to two different methods of proof. We first look at problems for which uniqueness (possibly up to a constant) follows from the consideration of

$$\int_{\Omega} \Delta u \, u \, dx \, dy.$$

**Theorem 4.4.1.2** Assume that  $\beta_i \leq \beta_{j-1}$  whenever j-1 and  $j \in \mathbb{N}$ . Then problem (4,1,1) has at most one solution  $u \in W^2_p(\Omega)$  defined up to an additive constant. If in addition,  $\mathfrak{D}$  is non-empty, then problem (4,1,1) has at most one solution in  $W^2_p(\Omega)$ .

In other words the kernel of  $\Delta$ , considered as an operator from  $E_1$  to  $E_2$ , is either one-dimensional (when  $\mathcal{D} = \emptyset$ ) or zero (when  $\mathcal{D} \neq \emptyset$ ).

**Proof** Let us assume that  $u \in W_p^2(\Omega)$  is a solution of problem (3,1,1) with f = 0. We use the classical identity

$$-\int_{\Omega} \Delta u \, u \, dx \, dy = \int_{\Omega} |\nabla u|^2 \, dx \, dy - \sum_{j=1}^{N} \int_{\Gamma_i} \gamma_j \frac{\partial u}{\partial \nu_j} \gamma_j u \, d\sigma. \tag{4.4.1.2}$$

Such an identity obviously holds for functions in  $W_p^2(\Omega) \cap W_q^2(\Omega)$  with 1/p + 1/q = 1 (see Lemma 1.5.3.3). We therefore consider a sequence  $u_m$ ,  $m = 1, 2, \ldots$  of functions belonging to  $W_p^2(\Omega) \cap W_q^2(\Omega)$  and such that

$$u_m \rightarrow u$$

in  $W_p^2(\Omega)$  when  $m \to +\infty$ . We have

$$-\int_{\Omega} \Delta u_m u_m dx dy = \int_{\Omega} |\nabla u_m|^2 dx dy - \sum_{i=1}^{N} \int_{\Gamma_i} \gamma_i \frac{\partial u_m}{\partial \nu_i} \gamma_i u_m d\sigma.$$

for all m, and we can take the limit in m, since by Sobolev's imbedding

210 SECOND-ORDER PROBLEMS IN POLYGONS

theorem (see Subsection 1.4.4), we have

$$u_{m} \to u \qquad \text{in } L_{q}(\Omega)$$

$$\nabla u_{m} \to \nabla u \qquad \text{in } L_{2}(\Omega)$$

$$\gamma_{j} \frac{\partial u_{m}}{\partial \nu_{j}} \to \gamma_{j} \frac{\partial u}{\partial \nu_{j}} \qquad \text{in } L_{p}(\Gamma_{j})$$

$$\gamma_{j} u_{m} \to \gamma_{j} u \qquad \text{in } L_{q}(\Gamma_{j}).$$

This proves identity (4,4,1,2).

Then since  $\Delta u = 0$  and u fulfils the boundary conditions, we have

$$0 = \int_{\Omega} |\nabla u|^2 dx dy + \sum_{j=1}^{N} \beta_j \int_{\Gamma_j} \frac{\partial}{\partial \tau_j} \gamma_j u \gamma_j u d\sigma$$
$$= \int_{\Omega} |\nabla u|^2 dx dy + \sum_{j=1}^{N} \frac{(\beta_j - \beta_{j+1})}{2} u(S_j)^2.$$

This identity is meaningful since u is continuous up to the boundary of  $\Omega$ . The assumption that  $\beta_i \ge \beta_{i+1}$  for all j implies

$$\int_{\Omega} |\nabla u|^2 \, \mathrm{d}x \, \mathrm{d}y = 0$$

and therefore u is a constant (since  $\Omega$  is connected). This constant is zero if and only if  $\mathcal{D}$  is nonempty.

Next we consider problems for which uniqueness follows from the consideration of

$$\int_{\Omega} |\Delta u|^2 \, \mathrm{d}x \, \mathrm{d}y.$$

**Theorem 4.4.1.3** Assume that  $p \ge 2$  and that at least two of the vectors  $\mu_i$  are linearly independent. Then problem (4,1,1) has at most one solution  $u \in W^2_p(\Omega)$  defined up to the addition of a constant. If in addition,  $\mathcal{D}$  is nonempty, then problem (4,1,1) has at most one solution in  $W^2_p(\Omega)$ .

In other words, the kernel of  $\Delta$  as an operator from  $E_1$  to  $E_2$  is either one-dimensional (when  $\mathfrak{D} = \emptyset$ ) or zero (when  $\mathfrak{D} \neq \emptyset$ .)

**Proof** Let  $u \in W_p^2(\Omega)$  be a solution of problem (3,1,1) with f = 0. Then since we assume that  $p \ge 2$ , we have

$$u \in H^2(\Omega)$$
.

It follows that

$$0 = \int_{\Omega} |\Delta u|^2 dx dy = \int_{\Omega} \{ |D_x^2 u|^2 + |D_y^2 u|^2 + 2 |D_x D_y u|^2 \} dx dy$$

by Remark 4.3.1.6. This shows that u is a polynomial of degree less than or equal to 1.

Let us assume from now on that  $u = \xi x + \eta y + \alpha$ . The boundary condition on  $\Gamma_i$  means that the vector whose components are  $\xi$  and  $\eta$ , is orthogonal to  $\mu_i$ . Since two of these vectors are linearly independent by assumption, this implies that  $u = \alpha$ , a constant. The constant  $\alpha$  is zero if and only if  $\mathfrak{D}$  is nonempty.

The above investigation of the kernel of  $\Delta$  as an operator from  $E_1$  to  $E_2$  is conclusive in most of the practical cases. We turn now to studying the range of  $\Delta$ . Taking advantage of the fact that it is closed, we shall instead investigate its annihilator which is a subspace of  $L_q(\Omega)$  with 1/p + 1/q = 1. Naturally this is, in some sense, the space of the solutions of a homogeneous adjoint problem. This will be stated in a precise way with the aid of Theorem 1.5.3.6.

From now on we shall denote by  $N_q$  the subspace of all functions  $v \in L_a(\Omega)$  such that

$$\int_{\Omega} f v \, dx \, dy = 0$$

for all  $f \in L_p(\Omega)$  such that there exists  $u \in W_p^2(\Omega)$  satisfying (4,1,1). This is the annihilator of the image of  $\Delta$ . Obviously  $N_q$  is a space of harmonic functions. Indeed, for all  $u \in \mathcal{D}(\Omega)$  we have

$$\int_{\Omega} \Delta u \, v \, dx \, dy = 0,$$

and consequently  $\Delta v = 0$  in the sense of distributions. This implies that

$$v \in D(\Delta; L_a(\Omega)),$$

a space defined in Subsection 1.5.3. Therefore by Theorem 1.5.3.4 the traces of v and  $\partial v/\partial v_j$  are well defined on each of the sides  $\Gamma_i$ ,  $1 \le j \le N$ . Precisely, we have

$$\gamma_j v \in W_q^{-1/q}(\Gamma_j), \qquad \gamma_j \frac{\partial v}{\partial \nu_i} \in W_q^{-1-1/q}(\Gamma_j)$$

when  $p \neq 2$  and

$$\gamma_i v \in (\tilde{H}^{1/2}(\Gamma_i))^*, \qquad \gamma_i \frac{\partial v}{\partial \nu_i} \in (\tilde{H}^{3/2}(\Gamma_i))^*$$

when p = 2. Accordingly the following statement is meaningful.

**Lemma 4.4.1.4** Let  $v \in N_q$ ; then v is solution of the following boundary value problem

$$\begin{cases} \Delta v = 0 & \text{in } \Omega, \\ \gamma_{j}v = 0 & \text{on } \Gamma_{j}, \ j \in \mathcal{D}, \\ \gamma_{j}\frac{\partial v}{\partial \nu_{j}} - \beta_{j}\frac{\partial}{\partial \tau_{j}} \gamma_{j}v = 0 & \text{on } \Gamma_{j}, \ j \in \mathcal{N}. \end{cases}$$

$$(4,4,1,3)$$

For convenience, in what follows, we shall denote by  $M_q$  the space of the solutions of problem (4,4,1,3) which belong to  $L_a(\Omega)$ .

**Proof** Let us first look at the case when  $p \neq 2$ . Given  $\varphi_i \in \mathring{W}_p^{2-1/p}(\Gamma_i)$ ,  $j \in \mathcal{N}$ , and  $\psi_i \in \mathring{W}_p^{1-1/p}(\Gamma_i)$ ,  $j \in \mathcal{D}$ , there exists  $u \in W_p^2(\Omega)$  such that

$$\begin{cases} \gamma_{i}u = \varphi_{i}, \ \gamma_{i}\frac{\partial u}{\partial \nu_{i}} = -\beta_{i}\frac{\partial \varphi_{i}}{\partial \tau_{i}}, & j \in \mathcal{N} \\ \\ \gamma_{i}u = 0, \ \gamma_{j}\frac{\partial u}{\partial \nu_{i}} = \psi_{i}, & j \in \mathcal{D}. \end{cases}$$

This is a direct application of Theorem 1.5.2.8. Indeed all the conditions (a) in this theorem are obviously fulfilled since both sides of the desired identities vanish (see Corollary 1.5.1.6).

We observe that  $u(S_i) = 0$  for all j and in addition that

$$\nabla u(S_j) = 0$$
 for all  $j$ 

when p>2. Consequently, we can apply Theorem 1.5.3.6 (the Green formula) to this function u and  $v \in N_q$ . We obtain

$$\sum_{j=1}^{N} \left\langle \gamma_{j} \frac{\partial u}{\partial \nu_{j}}; \gamma_{j} v \right\rangle - \left\langle \gamma_{j} u; \gamma_{j} \frac{\partial v}{\partial \nu_{j}} \right\rangle = 0,$$

i.e.

$$\sum_{j \in \mathcal{D}} \langle \psi_i; \gamma_j v \rangle - \sum_{j \in \mathcal{N}} \left\{ \left\langle -\beta_j \frac{\partial \varphi_i}{\partial \tau_j}; \gamma_i v \right\rangle - \left\langle \varphi_i, \gamma_j \frac{\partial v}{\partial \nu_j} \right\rangle \right\} = 0.$$

If we let  $\varphi_i$  vary in  $\mathring{W}_p^{2-1/p}(\Gamma_i)$  and  $\psi_i$  vary in  $\mathring{W}_p^{1-1/p}(\Gamma_i)$ , this identity shows that

$$\begin{aligned} \gamma_{i}v &= 0, & j \in \mathcal{D}, \\ \gamma_{i}\frac{\partial v}{\partial \nu_{i}} - \beta_{i}\frac{\partial}{\partial \tau_{i}}\gamma_{i}v &= 0, & j \in \mathcal{N}. \end{aligned}$$

We have thus checked that v is solution of problem (4,4,1,3) when  $p \neq 2$ . To conclude we must look at the case where p = 2. We just observe Downloaded 10/24/25 to 211.83.126.166. Redistribution subject to SIAM license or copyright; see https://epubs.siam.org/terms-privacy

that  $N_2 \subseteq N_a$  for q < 2 and consequently  $v \in N_2$  is also a solution of problem (4,4,1,3).

In the next subsection we shall show that  $M_a$ , the space of the solutions of problem (4,4,1,3), is a finite-dimensional subspace of  $L_a(\Omega)$ . Furthermore we shall be able to calculate its dimension in most cases. This will show that  $\Delta$  is a Fredholm operator from  $E_1$  to  $E_2$ . Actually, calculating its index will require some additional work since in many cases  $N_a$ happens to be a strict subspace of the space of the solutions of (4,4,1,3) in  $L_a(\Omega)$ . Indeed, let

$$\varphi_i \in \mathcal{D}(\bar{\Omega}), \qquad \psi_i \in \mathcal{D}(\bar{\Omega})^2$$

be such that:

- The supports of  $\varphi_i$  and  $\psi_i$  do not meet  $\overline{\Gamma}_l$  for  $l \neq j$  and j+1 (in particular they do not contain  $S_l$  for  $l \neq j$ ).
- $\varphi_i(S_i) = 1$ ,  $D_x \psi_i(S_i) = (1, 0)$ ,  $D_y \psi_i(S_i) = (0, 1)$ ,  $\nabla \varphi_i(S_i) = 0$ ,  $\psi_i(S_i) = 0$ . (b)

With this notation we can state the following lemma:

**Lemma 4.4.1.5** Let  $v \in N_q$ ; then for all  $u \in W_p^2(\Omega)$ , fulfilling the boundary conditions in (4,1,1) and all i, we have

$$\int_{\Omega} \{u(S_{i}) \Delta \varphi_{i} + \nabla u(S_{i}) \cdot \Delta \psi_{i}\} v \, dx \, dy$$

$$= \sum_{k \in \mathcal{N} \cap \{i; i+1\}} \left\langle \left[ \frac{\partial}{\partial \nu_{k}} + \beta_{k} \frac{\partial}{\partial \tau_{k}} \right] \{u(S_{i}) \varphi_{i} + \nabla u(S_{i}) \cdot \psi_{i}\}; \gamma_{k} v \right\rangle$$

$$- \sum_{k \in \mathcal{D} \cap \{i; i+1\}} \left\langle \{u(S_{i}) \varphi_{i} + \nabla u(S_{i}) \cdot \psi_{i}\}; \gamma_{k} \frac{\partial v}{\partial \nu_{k}} \right\rangle \tag{4.4.1.4}$$

when p > 2, and

$$\int_{\Omega} u(S_{i}) \Delta \varphi_{j} v \, dx \, dy = \sum_{k \in \mathcal{N} \cap \{j:j+1\}} \left\langle \left[ \frac{\partial}{\partial \nu_{k}} + \beta_{k} \frac{\partial}{\partial \nu_{k}} \right] u(S_{j}) \varphi_{j}; \gamma_{k} v \right\rangle$$

$$(4,4,1,5)$$

when p < 2.

**Proof** This is again an application of Theorem 1.5.3.6. Let us look at the case when p > 2 first. Let  $u \in W_p^2(\Omega)$  and set

$$w = u - \sum_{j=1}^{N} u(S_j) \varphi_j - \sum_{j=1}^{N} \nabla u(S_j) \cdot \psi_j.$$

Then obviously  $w \in W_p^2(\Omega)$  and

$$w(S_i) = 0, \quad \nabla w(S_i) = 0.$$
 (4,4,1,6)

for all j. Since  $v \in N_q$  is also in  $D(\Delta; L_q(\Omega))$ , we can apply identity (1,5,3,6) to w and v.

Thus we have

$$\int_{\Omega} \Delta w \, v \, dx \, dy = \sum_{k=1}^{N} \left\{ \left\langle \gamma_{k} \frac{\partial w}{\partial \nu_{k}}; \, \gamma_{k} v \right\rangle - \left\langle \gamma_{k} w; \, \gamma_{k} \frac{\partial v}{\partial \nu_{k}} \right\rangle \right\}$$

since  $\Delta v = 0$ . We then observe that (4,4,1,6) implies that  $\gamma_k w \in \mathring{W}_p^{2-1/p}(\Gamma_k)$ . On the other hand, we have proved in Lemma 4.4.1.4 that

$$\gamma_k \frac{\partial v}{\partial \nu_k} = \beta_k \frac{\partial}{\partial \tau_k} \gamma_k v$$

when  $k \in \mathcal{N}$ . It follows that

$$\left\langle \gamma_{k}w; \gamma_{k} \frac{\partial v}{\partial \nu_{k}} \right\rangle = \beta_{k} \left\langle \gamma_{k}w; \frac{\partial}{\partial \tau_{k}} \gamma_{k}v \right\rangle = -\beta_{k} \left\langle \frac{\partial}{\partial \tau_{k}} \gamma_{k}w; \gamma_{k}v \right\rangle.$$

Thus we have

$$\int_{\Omega} \Delta w \, v \, dx \, dy = \sum_{k \in \mathcal{N}} \left\langle \gamma_k \frac{\partial w}{\partial \nu_k} + \beta_k \frac{\partial}{\partial \tau_k} \, \gamma_k w; \, \gamma_k v \right\rangle - \sum_{k \in \mathcal{D}} \left\langle \gamma_k w; \, \gamma_k \frac{\partial v}{\partial \nu_k} \right\rangle.$$

Since

$$\int_{\Omega} \Delta u \, v \, dx \, dy = 0,$$

$$\gamma_k \frac{\partial u}{\partial \nu_k} + \beta_k \frac{\partial}{\partial \tau_k} \gamma_k u = 0 \quad \text{on } \Gamma_k \quad \text{for} \quad k \in \mathcal{N}$$

and

$$\gamma_k u = 0$$
 on  $\Gamma_k$  for  $k \in \mathcal{D}$ ,

it follows that

$$\int_{\Omega} \Delta \sum_{j=1}^{N} \{u(S_{j})\varphi_{j} + \nabla u(S_{j}) \cdot \psi_{j}\} v \, dx \, dy$$

$$= \sum_{k \in \mathcal{N}} \sum_{j=1}^{N} \left\langle \left[ \frac{\partial}{\partial \nu_{k}} + \beta_{k} \frac{\partial}{\partial \tau_{k}} \right] \{u(S_{j})\varphi_{j} + \nabla u(S_{j}) \cdot \psi_{j}\}; \gamma_{k} v \right\rangle$$

$$- \sum_{k \in \mathcal{D}} \sum_{j=1}^{N} \left\langle \{u(S_{j})\varphi_{j} + \nabla u(S_{j}) \cdot \psi_{j}\}; \gamma_{k} \frac{\partial v}{\partial \nu_{k}} \right\rangle.$$

Now if we let u vary, the values of  $\{u(S_i), \nabla u(S_i)\}$  for different j are

Downloaded 10/24/25 to 211.83.126.166. Redistribution subject to SIAM license or copyright; see https://epubs.siam.org/terms-privacy

$$\begin{split} & \int_{\Omega} \Delta \{u(S_{i})\varphi_{i} + \nabla u(S_{i})\psi_{i}\}v \, dx \, dy \\ & = \sum_{k \in \mathcal{N}} \left\langle \left[\frac{\partial}{\partial \nu_{k}} + \beta_{k} \frac{\partial}{\partial \tau_{k}}\right] \{u(S_{i})\varphi_{i} + \nabla u(S_{i}) \cdot \psi_{i}\}; \, \gamma_{k} v \right\rangle \\ & - \sum_{k \in \mathcal{D}} \left\langle \{u(S_{i})\varphi_{i} + \nabla u(S_{i}) \cdot \psi_{i}\}; \, \gamma_{k} \frac{\partial v}{\partial \nu_{k}} \right\rangle. \end{split}$$

Due to the assumptions on the supports of  $\varphi_j$  and  $\psi_i$  the sum in k has to be extended to k = j and k = j + 1 only. This proves (4,4,1,4).

In the case when p < 2, we make the same calculations defining w as

$$w = u - \sum_{j=1}^{N} u(S_j) \varphi_j.$$

The last sum

$$\sum_{k \in \mathcal{D} \cap \{i, j+1\}} u(S_i) \left\langle \varphi_i; \gamma_k \frac{\partial v}{\partial \nu_k} \right\rangle$$

is always zero since when  $\mathfrak{D} \cap \{j, j+1\} \neq \emptyset$  we must have  $u(S_i) = 0$ .

Remark 4.4.1.6 The meaning of these two lemmas is the following: In addition to being a solution of problem (4,4,1,3), every function  $v \in N_a$  must fulfil a finite number of linear conditions defined by (4,4,1,4) or (4,4,1,5) (observe that it is not clear whether or not these conditions are independent). By the way, this shows that the adjoint problem to (4,1,1) is not exactly the adjoint boundary value problem as is always the case when the boundary of  $\Omega$  is smooth.

Remark 4.4.1.7 The conditions on v expressed by (4,4,1,4) and (4,4,1,5) can be simplified in most cases. Let us first look at the case when p < 2; we have two possible cases:

- (a) If j or j+1 belongs to  $\mathcal{D}$ , we always have  $u(S_j) = 0$  and (4,4,1,5) is not an additional condition on v.
- (b) If j and j+1 belong to  $\mathcal{N}$ , then  $u(S_j)$  is any real number and consequently condition (4,4,1,5) is nothing but

$$\int_{\Omega} \Delta \varphi_{i} v \, dx \, dy = \sum_{k=i}^{j+1} \left\langle \left[ \frac{\partial}{\partial \nu_{k}} + \beta_{k} \frac{\partial}{\partial \tau_{k}} \right] \varphi_{i}; \gamma_{k} v \right\rangle. \tag{4.4.1.7}$$

Then when p > 2, there are many more cases.

(a) If j and j+1 belong to  $\mathfrak{D}$  and the angle  $\omega_j$  is not flat (the case of a

flat angle with Dirichlet boundary conditions on both sides is irrelevant since flat angles are considered only when dealing with mixed boundary conditions), then we always have  $u(S_i)$  and  $\nabla u(S_i) = 0$ . Therefore, (4,4,1,4) is not an additional condition on v.

- If  $j \in \mathcal{D}$  and  $j+1 \in \mathcal{N}$  and if we assume that  $\tau_i$  and  $\mu_{i+1}$  are linearly independent, we also have  $u(S_i) = 0$  and  $\nabla u(S_i) = 0$  and thus no additional condition on v.
- The same holds when  $j \in \mathcal{N}$ ,  $j+1 \in \mathcal{D}$  and if  $\tau_{i+1}$  and  $\mu_i$  are linearly (c) independent.
- If  $j \in \mathcal{D}$  and  $j+1 \in \mathcal{N}$  and if  $\tau_i$  and  $\mu_{i+1}$  are parallel, we have only  $u(S_i) = 0$  and  $\nabla u(S_i) \cdot \tau_i = 0$ .

Thus condition (4,4,1,4) is equivalent to

$$\int_{\Omega} \Delta \psi_{i} \cdot \mathbf{v}_{i} v \, dx \, dy$$

$$= \left\langle \left[ \frac{\partial}{\partial \mathbf{v}_{i+1}} + \beta_{i+1} \frac{\partial}{\partial \tau_{i+1}} \right] \psi_{i} \cdot \mathbf{v}_{i}; \gamma_{i+1} v \right\rangle - \left\langle \psi_{i} \cdot \mathbf{v}_{i}; \gamma_{i} \frac{\partial v}{\partial \nu_{i}} \right\rangle. \tag{4,4,1,8}$$

- A similar result holds mutatis mutandis when  $j \in \mathcal{N}$  and  $j+1 \in \mathcal{D}$ .
- When j and j+1 belong to  $\mathcal{N}$  and  $\mu_i$  and  $\mu_{i+1}$  are linearly independent, then we have  $\nabla u(S_i) = 0$  and condition (4,4,1,4) reduces to (4,4,1,7) again.
- Finally, when j and j+1 belong to  $\mathcal{N}$  and  $\mu_i$  is parallel to  $\mu_{i+1}$ , we have only

$$\nabla u(S_i) \cdot \mathbf{\mu}_i = 0$$

while  $u(S_i)$  and  $\nabla u(S_i) \cdot \tau_i$  are any real numbers. Therefore, condition (4,4,1,4) is equivalent to condition (4,4,1,7) and the following condition:

$$\int_{\Omega} \Delta \psi_{j} \cdot \tau_{j} v \, dx \, dy = \sum_{k=j}^{j+1} \left\langle \left[ \frac{\partial}{\partial \nu_{k}} + \beta_{k} \frac{\partial}{\partial \tau_{k}} \right] \psi_{j} \cdot \tau_{j}; \gamma_{k} v \right\rangle. \tag{4.4.1.9}$$

Summing up, we have proved the following theorem.

**Theorem 4.4.1.8** Let  $p \neq 2$ ; then  $N_q$  is the space of all solutions  $v \in L_q(\Omega)$ of problem (4,4,1,3) which in addition fulfil the following conditions:

- (4,4,1,7) for all j such that both j and j+1 belong to  $\mathcal{N}$ ; and, when p > 2:
- (4,4,1,8) for all j such that  $j \in \mathcal{D}$  and  $j+1 \in \mathcal{N}$  or such that  $j \in \mathcal{N}$  and  $j+1\in \mathcal{D}$  and  $\mu_i$  is parallel to  $\mu_{i+1}$ ;
- (4,4,1,9) for all j such that both j and j+1 belong to N and  $\mu_i$  is (c) parallel to  $\mu_{i+1}$ .

Unfortunately we are unable to prove such a precise result when p = 2. The reason is that, for  $u \in H^2(\Omega)$ , it is not possible to apply the Green formula of Theorem 1.5.3.6 to the function

$$w = u - \sum_{i=1}^{N} u(S_i) \varphi_i.$$

Indeed, in general we have  $\gamma_i w \in H^{3/2}(\Gamma_i)$ , and in addition

$$\gamma_j w(S_{j-1}) = \gamma_j w(S_j) = 0,$$

but this is not enough to conclude that  $\gamma_i w \in \tilde{H}^{3/2}(\Gamma_i)$  (see Subsection 1.5.1).

#### 4.4.2 The adjoint problem

In this subsection we shall show that the dimension of  $N_q$  is finite in most cases. This will be achieved by studying thoroughly the behaviour of the solutions of problem (4,4,1,3) which belong to  $L_q(\Omega)$ . Sometimes, this will also allow us to calculate exactly the dimension of  $N_q$ .

**Lemma 4.4.2.1** Let  $v \in M_q$ , then  $v \in C^{\infty}(\bar{\Omega} \setminus V)$ , where V is any neighbourhood of the vertices of  $\Omega$ .

**Proof** Actually v is a harmonic function in  $\Omega$  and it is well known that it is smooth inside  $\Omega$ . We must prove the smoothness of v near any of the  $\Gamma_j$ . For that purpose we fix j and perform a change of coordinate axes such that the segment  $\Gamma_j$  is on the axis  $\{x_2=0\}$  and such that  $\Omega$  is above  $\Gamma_j$ . Then we introduce a cut-off function  $\varphi \in \mathcal{D}(\bar{\Omega})$ , whose support does not intersect any of the sides  $\bar{\Gamma}_k$  with  $k \neq j$  (consequently it does not contain any of the corners) and such that  $\varphi$  does not depend on  $x_2$  for small values of  $x_2$ . We shall now investigate the smoothness of  $\varphi v$ .

The function  $w = \widetilde{\varphi v}$  belongs to  $L_q(\mathbb{R}^2_+)$  where  $\mathbb{R}^2_+ = \{x_2 > 0\}$ . In addition, w is solution of

$$\begin{cases}
-\Delta w + w = f & \text{in } \mathbb{R}^2_+ \\
\gamma \frac{\partial w}{\partial x_2} + \beta_j \gamma \frac{\partial w}{\partial x_1} = g & \text{on } \{x_2 = 0\} & \text{if } j \in \mathcal{N}, \\
\gamma w = 0 & \text{on } \{x_2 = 0\} & \text{if } j \in \mathcal{D},
\end{cases}$$

where

$$f = \{ \varphi v - 2 \nabla \varphi \cdot \nabla v - (\Delta \varphi) v \}$$

and

$$g = \left\{ \left( \frac{\partial \varphi}{\partial x_2} + \beta_j \frac{\partial \varphi}{\partial x_1} \right) \gamma v \right\} \qquad \text{if } j \in \mathcal{N}.$$

At first sight we have f E W,'(f^+) and g E Wq' <sup>l</sup>Q(F ). However, f is actually a little better than this. Indeed, f is smooth for x <sup>2</sup> > 0, while for small values of x<sup>2</sup> , we have

$$f = \left\{ \varphi v - 2 \frac{\partial \varphi}{\partial x_1} \frac{\partial v}{\partial x_1} - (\Delta \varphi) v \right\}^{\sim},$$

due to the fact that cp does not depend on x <sup>2</sup> . It follows that

$$f \in L_q(\mathbb{R}_+; W_q^{-1}(\mathbb{R}))$$

if we agree to view f as a vector-valued function of x <sup>2</sup> . This will allow us to show that w E W(l) as a first step.

We replace w by Rw, where R is the inverse operator of (1- i.e.

$$Rw = F_1^{-1}(1+\xi_1^2)^{-1/2}F_1w,$$

where F, denotes the Fourier transform in x <sup>1</sup> . It follows from Lemma 2.3.2.5 that Rw ` Lq (ll+) and that

$$\begin{cases}
-\Delta Rw + Rw = Rf & \text{in } \mathbb{R}^2_+ \\
\gamma \left\{ \frac{\partial Rw}{\partial x_2} + \beta_j \frac{\partial Rw}{\partial x_1} \right\} = Rg & \text{on } \{x_2 = 0\} & \text{if } j \in \mathcal{N} \\
\gamma Rw = 0 & \text{on } \{x_2 = 0\} & \text{if } j \in \mathcal{D},
\end{cases}$$

where R f E Lq (l ) and Rg E W' '^Q(R) . We conclude by applying Proposition 2.5.2.4 when j E M and Corollary *2.5.2.2* when j E 2, replacing *D* by any domain I12 with a smooth boundary containing the support of cp and such that fl c aQ <sup>1</sup> . It follows that

$$Rw\mid_{\Omega_1}\in W^2_q(\Omega_1)$$

and consequently we have Rw E W(9) and w E W,(R <sup>2</sup> ). If we vary cp and j, we finally show that

$$v \in W_q^1(\Omega \setminus V),$$

where V is any neighbourhood of the vertices of D.

Now we retrace all the previous steps of the proof. Since we know that v belongs to Wq(Q\V), we also know that f€ L"(O ) and g E Wq -' <sup>l</sup>q(R+). Thus, applying Corollary 2.5.2.2 and Proposition 2.5.2.4 to w in this case (instead of Rw) shows that

$$w\mid_{\Omega_1}\in W^2_q(\Omega_1),$$

and consequently

$$v \in W_q^2(\Omega \setminus V)$$
,

where V is any neighbourhood of the corners of  $\Omega$ .

Finally, repeated application of Theorem 2.5.1.1 with  $\Omega$  replaced by  $\Omega_1$  as above, shows that

$$v \in W_a^{k+2}(\Omega \setminus V)$$

for every positive integer k. The Sobolev imbedding theorem (Subsection 1.4.4) implies that

$$v \in C^{\infty}(\bar{\Omega} \setminus V).$$

The proof of Lemma 4.4.2.1 is complete.

Now we shall study the behaviour of  $v \in M_q$  near the corners. For simplicity we begin with those corners  $S_i$  which correspond to self-adjoint conditions. In other words, we assume that  $\beta_i = 0$  if  $j \in \mathcal{N}$  and that  $\beta_{j+1} = 0$  if  $j+1 \in \mathcal{N}$ . For technical purposes, we shall need the eigenfunctions of the operator

$$\varphi \mapsto -\varphi''$$

under various boundary conditions in the interval  $]0, \omega_i[$ .

More precisely, let us define the unbounded operator  $\Lambda_i$ , in  $\mathcal{H}_i = L_2(]0, \omega_i[)$  as follows:

$$\Lambda_i \varphi = -\varphi'',$$

where  $\varphi \in D(\Lambda_i)$ , the domain of  $\Lambda_i$ , given by

$$D(\Lambda_j) = \begin{cases} \{\varphi \in H^2(]0, \, \omega_j[) \mid \varphi(0) = \varphi(\omega_j) = 0\} & \text{if } j \text{ and } j+1 \in \mathcal{D} \\ \{\varphi \in H^2(]0, \, \omega_j[) \mid \varphi'(0) = \varphi'(\omega_j) = 0\} & \text{if } j \text{ and } j+1 \in \mathcal{N} \\ \{\varphi \in H^2(]0, \, \omega_j[) \mid \varphi(0) = \varphi'(\omega_j) = 0\} & \text{if } j \in \mathcal{N} \text{ and } j+1 \in \mathcal{D} \\ \{\varphi \in H^2(]0, \, \omega_j[) \mid \varphi'(0) = \varphi(\omega_j) = 0\} & \text{if } j \in \mathcal{D} \text{ and } j+1 \in \mathcal{N}. \end{cases}$$

This is a nonnegative self-adjoint operator with a discrete spectrum. We shall denote by  $\varphi_{j,m}$ , m = 1, 2, ... the normalized eigenfunctions and by  $\lambda_{j,m}^2$ , m = 1, 2, ... the corresponding eigenvalues in increasing order of magnitude. We thus have

$$-\varphi_{i,m}'' = \lambda_{i,m}^2 \varphi_{i,m}$$

where  $\varphi_{i,m} \in D(\Lambda_i)$  for every m.

Of course, we have

$$\varphi_{j,m}(\theta) = \sqrt{\left(\frac{2}{\omega_{j}}\right)} \sin \frac{m\pi\theta}{\omega_{j}}, \qquad \lambda_{j,m} = \frac{m\pi}{\omega_{j}} \quad \text{when} \quad j \text{ and } j+1 \in \mathcal{D}$$

$$\varphi_{j,m}(\theta) = \begin{cases} 1/\sqrt{\omega_{j}} & \\ \sqrt{\left(\frac{2}{\omega_{j}}\right)} \cos \frac{(m-1)\pi\theta}{\omega_{j}}, & \lambda_{j,m} = \begin{cases} 0 & m=1\\ \frac{(m-1)\pi}{\omega_{j}} & m \ge 2 \end{cases}$$

when j and  $j+1 \in \mathcal{N}$ 

$$\varphi_{j,m}(\theta) = \sqrt{\left(\frac{2}{\omega_j}\right)\sin\frac{(m-\frac{1}{2})\pi\theta}{\omega_j}}, \qquad \lambda_{j,m} = \frac{(m-\frac{1}{2})\pi}{\omega_j}$$

when  $j \in \mathcal{N}$  and  $j+1 \in \mathcal{D}$ 

$$\varphi_{j,m}(\theta) = \sqrt{\left(\frac{2}{\omega_j}\right) \sin \frac{(m - \frac{1}{2})\pi(\omega_j - \theta)}{\omega_j}}, \quad \lambda_{j,m} = \frac{(m - \frac{1}{2})\pi}{\omega_j}$$

when  $j \in \mathcal{D}$  and  $j + 1 \in \mathcal{N}$ .

Using the polar coordinates with origin at  $S_i$  (introduced in Subsection 4.3.2), any  $v \in M_a$  is a solution of

$$\frac{\partial^2 v}{\partial r^2} + \frac{1}{r} \frac{\partial v}{\partial r} + \frac{1}{r^2} \frac{\partial^2 v}{\partial \theta^2} = 0, \qquad 0 < \theta < \omega_j, \quad 0 < r < \rho, \tag{4,4,2,1}$$

where  $\rho > 0$  is small enough (chosen such that the disc whose centre is  $S_i$  and radius is  $\rho$  does not cut any side of  $\Omega$  except  $\Gamma_i$  and  $\Gamma_{i+1}$ . We set  $D_{\rho} = \Omega \cap \{0 < r_i < \rho\}$ ). In addition it fulfils the following boundary conditions: at  $\theta = 0$ 

$$v = 0$$
 if  $j + 1 \in \mathcal{D}$  and  $\frac{\partial v}{\partial \theta} = 0$  if  $j + 1 \in \mathcal{N}$ ,

and at  $\theta = \omega_i$ 

$$v = 0$$
 if  $j \in \mathcal{D}$  and  $\frac{\partial v}{\partial \theta} = 0$  if  $j \in \mathcal{N}$ .

Since v is smooth for r>0 by Lemma 4.4.2.1, we have

$$v(re^{i\theta}) \in H^2(]0, \omega_i[).$$

It follows that

$$v(re^{i\theta}) \in D(\Lambda_i)$$

for each  $r \in ]0, \rho[$ .

Consequently we have

$$\frac{\partial^2 v}{\partial r^2} + \frac{1}{r} \frac{\partial v}{\partial r} - \frac{1}{r^2} \Lambda_i v = 0, \qquad 0 < r < \rho. \tag{4,4,2,2}$$

This implies that v can be expanded in series of the eigenfunctions of  $\Lambda_i$ , in a very special fashion, which we describe now.

**Proposition 4.4.2.2** Let  $v \in C^{\infty}(]0, \rho]$ ;  $D(\Lambda_{k})$  be a solution of Equation (4,4,2,2) and assume that  $v \in L_{q}(D\rho)$ . Then

$$v(re^{i\theta}) = v_1(r)\varphi_{j,1}(\theta) + \sum_{m \geq 2} \alpha_m r^{\lambda_{j,m}} \varphi_{j,m}(\theta) + \sum_{0 < \lambda_{j,m} < 2/q} \beta_m r^{-\lambda_{j,m}} \varphi_{j,m}(\theta),$$

where

$$v_1(r) = \alpha_1 r^{\lambda_{i,1}} \qquad if \ \lambda_{i,1} > 0$$

and

$$v_1(r) = \alpha_1 + \beta_1 \log r$$
 if  $\lambda_{i,1} = 0$ ,

and where  $\alpha_m$  and  $\beta_m$  are real numbers such that

$$|\alpha_m| \leq L m^{1/q} \rho^{-\lambda_{i,m}}, \tag{4,4,2,3}$$

where L is a constant which depends only on v.

**Proof** Since the sequence  $\varphi_{j,m}$ , m = 1, 2, ... is a basis of  $\mathcal{X}_j$ , we have

$$v(re^{i\theta}) = \sum_{m \ge 1} v_m(r)\varphi_{j,m}(\theta), \tag{4,4,2,4}$$

where

$$v_m(r) = \int_0^{\omega_i} v(re^{i\theta}) \varphi_{j,m}(\theta) d\theta. \tag{4.4.2.5}$$

However, since v is differentiable in r with values in  $D(\Lambda_i)$ , the differential equation (4,4,2,2) implies that

$$v_m''(r) + \frac{1}{r}v_m'(r) - \frac{\lambda_{j,m}^2}{r^2}v_m(r) = 0, \quad 0 < r < \rho.$$

Accordingly, we have

$$v_m(r) = \alpha_m r^{\lambda_{i,m}} + \beta_m r^{-\lambda_{i,m}}$$

when  $\lambda_{i,m} > 0$ , and

$$v_m(r) = \alpha_m + \beta_m \log r$$

when  $\lambda_{i,m} = 0$ .

On the other hand, since v belongs to  $L_q(D_p)$ , it follows from identity (4,4,2,5) that

$$|v_m(r)|^q \leq \sqrt{2^q} \omega_i^{q/p-q/2} \int_0^{\omega_i} |v(re^{i\theta})|^q d\theta$$

and consequently

$$\int_0^p |v_m(r)|^q r \, \mathrm{d}r \le \sqrt{2^q \omega_j^{q/p - q/2}} \, \|v\|_{0, q, D_o}^q. \tag{4.4.2.6}$$

This implies that  $\beta_m = 0$  when  $\lambda_{i,m} \ge 2/q$ , and in addition that

$$|\alpha_m|^q \int_0^p r^{\lambda_{i,m}q+1} dr = |\alpha_m|^q \frac{\rho^{\lambda_{i,m}q+2}}{\lambda_{i,m}q+2} \le \sqrt{2^q \omega_i^{q/p-q/2}} \|v\|_{0,q,D_\rho}^q$$

for  $\lambda_{i,m} \ge 2/q$ . This completes the proof of Proposition 4.4.2.2.

We shall now show that  $v \in M_q$  has an expansion near each corner (which looks very much like the expansion in Proposition 4.4.2.2) in the general case where  $\beta_i$ ,  $\beta_{i+1}$  are possibly nonzero. We shall use here the eigenfunctions and eigenvalues of a different operator. Let us denote by  $\Lambda_i$  the unbounded operator in  $\mathcal{H}_i = L_2(]0, \omega_i[] \times L_2(]0, \omega_j[]$  defined by

$$\Lambda_{i}\{v_{1}, v_{2}\} = \{v_{2}', -v_{1}'\}$$

where  $\{v_1, v_2\} \in D(\Lambda_i)$  and

$$D(\Lambda_{i}) = \left\{ \{v_{1}, v_{2}\} \in H^{1}(]0, \omega_{i}[) \times H^{1}(]0, \omega_{i}[) \\ \times \begin{vmatrix} \cos \Phi_{i+1}v_{2}(0) - \sin \Phi_{i+1}v_{1}(0) = 0 \\ \cos \Phi_{i}v_{2}(\omega_{i}) - \sin \Phi_{i}v_{1}(\omega_{i}) = 0 \end{vmatrix} \right\}$$

It is obvious that  $\Lambda_i$  is a self-adjoint operator and has a discrete spectrum. The expansions in terms of eigenfunctions are as follows:

**Lemma 4.4.2.3** Every  $\{v_1, v_2\} \in \mathcal{H}_i$  has an expansion of the following form

$$v_1 = \sum_{-\infty}^{+\infty} \frac{1}{\sqrt{\omega_j}} \alpha_m \cos (\lambda_{j,m} \theta + \Phi_{j+1})$$

$$v_2 = \sum_{-\infty}^{+\infty} \frac{1}{\sqrt{\omega_i}} \beta_m \sin (\lambda_{i,m} \theta + \Phi_{i+1})$$

where

$$\lambda_{j,m} = \frac{\Phi_j - \Phi_{j+1} + m\pi}{\omega_i}$$

and

$$\alpha_{m} = \frac{1}{\sqrt{\omega_{i}}} \int_{0}^{\omega_{i}} \left[ v_{1}(\theta) \cos \left( \lambda_{j,m} \theta + \Phi_{j+1} \right) + v_{2}(\theta) \sin \left( \lambda_{j,m} \theta + \Phi_{j+1} \right) \right] d\theta$$

provided  $(\Phi_i - \Phi_{i+1})/\pi$  is not an integer.

When  $(\Phi_i - \Phi_{i+1})/\pi$  is an integer l, the expansion is

$$v_1 = \frac{\alpha_{-l}}{\sqrt{[\omega_i(1 + \tan^2 \Phi_i)]}} + \sum_{m \neq -l} \frac{1}{\sqrt{\omega_i}} \alpha_m \cos(\lambda_{j,m}\theta + \Phi_{j+1})$$

$$v_2 = \frac{\alpha_{-l} \tan \Phi_j}{\sqrt{[\omega_j (1 + \tan^2 \Phi_j)]}} + \sum_{m \neq -l} \frac{1}{\sqrt{\omega_j}} \alpha_m \sin (\lambda_{j,m} \theta + \Phi_{j+1})$$

where

$$\alpha_{-l} = \frac{1}{\sqrt{\left[\omega_i(1 + \tan^2 \Phi_i)\right]}} \int_0^{\omega_i} \left[v_1(\theta) + \tan \Phi_i v_2(\theta)\right] d\theta$$

and  $\alpha_m$ ,  $m \neq -l$  is as before.

**Proof** It is easy to check that the eigenvalues of  $\Lambda_i$  are the numbers  $\lambda_{i,m}$ ,  $-\infty < m < +\infty$ , m integer and that the corresponding eigenvectors are

$$\boldsymbol{\varphi}_{j,m}(\theta) = \frac{1}{\sqrt{\omega_i}} \left\{ \cos \left( \lambda_{j,m} \theta + \boldsymbol{\Phi}_{j+1} \right); \sin \left( \lambda_{j,m} \theta + \boldsymbol{\Phi}_{j+1} \right) \right\}$$

for  $\lambda_{i,m} \neq 0$  and

$$\boldsymbol{\varphi}_{i,m}(\boldsymbol{\theta}) = \frac{1}{\sqrt{[\boldsymbol{\omega}_i(1 + \tan^2 \boldsymbol{\Phi}_i)]}} \{1; \tan \boldsymbol{\Phi}_i\}$$

for  $\lambda_{j,m} = 0$ .

Using again the polar coordinates introduced in Subsection 4.3.2, we see that each  $v \in M_q$  has the following features. First, by Lemma 4.4.2.1, v is a differentiable function of r with values in  $H^2(]0, \omega_i]$ ) for  $r \in ]0, \rho[$ , where  $\rho > 0$  is suitably small. Then, we have again

$$\frac{\partial^2 v}{\partial r^2} + \frac{1}{r} \frac{\partial v}{\partial r} + \frac{1}{r^2} \frac{\partial^2 v}{\partial \theta^2} = 0, \qquad 0 < \theta < \omega_j, \ 0 < r < \rho, \tag{4,4,2,7}$$

where v fulfils the boundary conditions

$$\begin{cases} \cos \Phi_{j+1} \frac{\partial v}{\partial \theta} + \sin \Phi_{j+1} r \frac{\partial v}{\partial r} = 0 & (\text{and } v = 0 \text{ if } j+1 \in \mathcal{D}), \\ 0 < r < \rho, \ \theta = 0 & (4,4,2,8) \end{cases}$$

$$\cos \Phi_{j} \frac{\partial v}{\partial \theta} + \sin \Phi_{j} r \frac{\partial v}{\partial r} = 0 & (\text{and } v = 0 \text{ if } j \in \mathcal{D}), \\ 0 < r < \rho, \ \theta = \omega_{j}. \end{cases}$$

224 SECOND-ORDER PROBLEMS IN POLYGONS

Let us set

$$w_1 = r \frac{\partial v}{\partial r}, \qquad w_2 = -\frac{\partial v}{\partial \theta},$$

then, obviously,  $\mathbf{w} = \{w_1, w_2\}$  is a differentiable function of r with values in  $D(\Lambda_i)$  for  $0 < r \le \rho$  and

$$r\frac{\partial \mathbf{w}}{\partial r} = \Lambda_i \mathbf{w}. \tag{4,4,2,9}$$

This implies the following:

**Theorem 4.4.2.4** Let  $v \in C^{\infty}(]0, \rho]$ ;  $H^2(]0, \omega_i[)$  be a solution of equation (4,4,2,7) fulfilling the boundary conditions (4,4,2,8). Assume, in addition, that  $v \in L_a(D_o)$ . Then

$$v(re^{i\theta}) = \sum_{\lambda_{i,m} > -2/a} \frac{c_m}{\sqrt{\omega_i}} \frac{r^{\lambda_{i,m}}}{\lambda_{i,m}} \cos(\lambda_{i,m}\theta + \Phi_{j+1}) + \kappa$$

where  $c_m$  and  $\kappa$  are real numbers such that

$$|c_m| \leq L\rho^{-\lambda_{i,m}} \tag{4,4,2,10}$$

for some constant L depending only on v, provided  $(\Phi_i - \Phi_{i+1})/\pi$  is not an integer.

When  $(\Phi_i - \Phi_{i+1})/\pi$  is an integer l, the expansion of v is

$$v(re^{i\theta}) = c_{-l} \frac{\log r - \theta \tan \Phi_j}{\sqrt{[\omega_j(1 + \tan^2 \Phi_j)]}} + \sum_{\substack{\lambda_{j,m} > 2/q \\ m \neq -l}} \frac{c_m}{\sqrt{\omega_j}} \frac{r^{\lambda_{j,m}}}{\lambda_{j,m}} \cos(\lambda_{j,m}\theta + \Phi_{j+1}) + \kappa$$

with the same growth condition on the sequence c<sub>m</sub>.

**Proof** The beginning of the proof is similar to that of Proposition 4.4.2.2. Indeed, the sequence  $\varphi_{i,m}$  is a basis of  $\mathcal{H}_i$ , and thus we have

$$\mathbf{w}(re^{i\theta}) = \sum_{-\infty}^{+\infty} w_m(r)\boldsymbol{\varphi}_{j,m}(\theta)$$
 (4,4,2,11)

where

$$w_m(r) = \int_0^{\omega_i} \mathbf{w}(re^{i\theta}) \cdot \boldsymbol{\varphi}_{i,m}(\theta) d\theta. \tag{4,4,2,12}$$

In other words, we have

$$r\frac{\partial v}{\partial r}(re^{i\theta}) = \sum_{-\infty}^{+\infty} w_m(r) \frac{1}{\sqrt{\omega_i}} \cos(\lambda_{i,m}\theta + \Phi_{i+1})$$

$$\frac{\partial v}{\partial \theta}(re^{i\theta}) = -\sum_{-\infty}^{+\infty} w_m(r) \frac{1}{\sqrt{\omega_j}} \sin(\lambda_{j,m}\theta + \Phi_{j+1}),$$

where

$$\begin{split} w_m(r) &= \frac{1}{\sqrt{\omega_i}} \int_0^{\omega_i} \left\{ r \frac{\partial v}{\partial r} (r e^{i\theta}) \cos \left( \lambda_{j,m} \theta + \Phi_{j+1} \right) \right. \\ &\left. - \frac{\partial v}{\partial \theta} (r e^{i\theta}) \sin \left( \lambda_{j,m} \theta + \Phi_{j+1} \right) \right\} d\theta \end{split}$$

with the obvious necessary modification when  $(\Phi_i - \Phi_{i+1})/\pi$  happens to be an integer. Then the Equation (4,4,2,9) implies that

$$rw'_{m}(r) = \lambda_{i,m}w_{m}(r),$$

and, accordingly

$$w_m(r) = c_m r^{\lambda_{i,m}}.$$

Thus it follows that

$$\begin{split} c_{m} &= r^{-\lambda_{i,m}} \frac{1}{\sqrt{\omega_{i}}} \int_{0}^{\omega_{i}} \left\{ r \frac{\partial v}{\partial r} (r e^{i\theta}) \cos \left(\lambda_{j,m} \theta + \Phi_{j+1}\right) \right. \\ &\left. - \frac{\partial v}{\partial \theta} (r e^{i\theta}) \sin \left(\lambda_{j,m} \theta + \Phi_{j+1}\right) \right\} d\theta \end{split}$$

for every  $r \in ]0, \rho]$  and therefore there exists a constant L(r) such that  $|c_m| \leq L(r)r^{-\lambda_{l,m}}$ 

for every  $r \in ]0, \rho]$ . This implies the uniform convergence of the following series:

$$r\frac{\partial v}{\partial r}(re^{i\theta}) = \frac{1}{\sqrt{\omega_i}} \sum_{-\infty}^{+\infty} c_m r^{\lambda_{i,m}} \cos(\lambda_{i,m}\theta + \Phi_{i+1})$$
$$\frac{\partial v}{\partial \theta}(re^{i\theta}) = \frac{-1}{\sqrt{\omega_i}} \sum_{-\infty}^{+\infty} c_m r^{\lambda_{i,m}} \sin(\lambda_{i,m}\theta + \Phi_{i+1})$$

in the rectangles  $Q_{\varepsilon} = \{(r, \theta); \ \varepsilon \le r \le \rho - \varepsilon, \ 0 \le \theta \le \omega_{j}\}$  for  $\varepsilon > 0$ . Integrating, we obtain

$$v(re^{i\theta}) = \frac{1}{\sqrt{\omega_j}} \sum_{-\infty}^{+\infty} c_m \frac{r^{\lambda_{j,m}}}{\lambda_{j,m}} \cos(\lambda_{j,m}\theta + \Phi_{j+1}) + \kappa.$$

This expansion is valid in  $\bigcup_{\varepsilon>0} Q_{\varepsilon}$ , i.e. for  $r\in ]0, \rho]$  and  $\theta\in [0, \omega_i]$  (here, for simplicity, we have assumed that none of the eigenvalues  $\lambda_{i,m}$  vanish; the modifications for covering the general case are obvious). The condition that v belongs to  $L_q(D_{\rho})$  imply that  $c_m=0$  when  $\lambda_{i,m} \leq -2/q$ .

Remark 4.4.2.5 The results in Theorem 4.4.2.4 clearly imply those of Proposition 4.4.2.2.

#### 4.4.3 The Fredholm alternative for variational problems

In this subsection, we restrict our purpose to those problems (4,1,1) which are variational. That is why we assume that

$$\beta_i = 0$$
 unless both  $j - 1$  and  $j + 1$  belong to  $\mathcal{D}$ . (4,4,3,1)

Indeed we have the following statement

**Lemma 4.4.3.1** Assume that (4,4,3,1) holds. Then for every given  $f \in L_p(\Omega)$ , problem (4,1,1) has a unique solution  $u \in H^1(\Omega)$  when  $\mathcal{D}$  is nonempty. On the other hand, when  $\mathcal{D}$  is empty, for every given  $f \in L_p(\Omega)$  such that

$$\int_{\Omega} f \, \mathrm{d}x \, \mathrm{d}y = 0,$$

the problem (4,1,1) has a solution  $u \in H^1(\Omega)$ , which is unique up to an additive constant.

Note that due to (4,4,3,1) this is a pure Neumann problem when  $\mathcal{D} = \emptyset$ .

**Proof** As usual, we define a variational solution of problem (4,1,1) as being any function

$$u \in V = \{u \in H^1(\Omega) \mid \gamma_i u = 0, \quad \forall j \in \mathcal{D}\}\$$

such that

$$a(u; v) = -\int_{\Omega} fv \, dx \, dy$$
 (4,4,3,2)

for every  $v \in V$ , where

$$a(u;v) = \int_{\Omega} \nabla u \cdot \nabla v \, dx \, dy + \sum_{j \in \mathcal{N}} \beta_j \left\langle \frac{\partial}{\partial \tau_j} \gamma_j u; \gamma_j v \right\rangle. \tag{4.4.3.3}$$

We observe that the bilinear form a is continuous on  $V \times V$  because the only boundary terms that actually occur (with  $\beta_i \neq 0$ ) are such that

$$\gamma_i u$$
 and  $\gamma_i v \in \tilde{H}^{1/2}(\Gamma_i)$ 

due to (4,4,3,1) and Theorem 1.5.2.3. On the other hand, by Remark 1.4.4.7 we know that  $\partial/\partial\tau_i$  maps  $H^{1/2}(\Gamma_i)$  into the dual of  $\tilde{H}^{1/2}(\Gamma_i)$ . Consequently all brackets in the right-hand side of (4,4,3,3) are continuous on  $V \times V$ .

Finally we observe that the form a is coercive (see Lemma 2.2.1.1)

because we have

$$a(u; u) = \int_{\Omega} |\nabla u|^2 dx dy.$$
 (4,4,3,4)

Indeed, for every  $\varphi \in \mathfrak{D}(\Gamma_i)$  we have obviously

$$\left\langle \frac{\partial \varphi}{\partial \tau_j}; \varphi \right\rangle = \int_{\Gamma_j} \frac{\partial \varphi}{\partial \tau_j} \varphi \, d\sigma = 0.$$

Then, since  $\mathfrak{D}(\Gamma_i)$  is dense in  $\tilde{H}^{1/2}(\Gamma_i)$ , we have also

$$\left\langle \frac{\partial \varphi}{\partial \tau_{i}}; \varphi \right\rangle = 0$$

for every  $\varphi \in \tilde{H}^{1/2}(\Gamma_i)$ .

From identity (4,4,3,4), the coerciveness of a follows with the aid of Poincaré's inequality when  $\mathcal{D}$  is not empty. When  $\mathcal{D}$  is empty, we have only shown that the form

$$\dot{u}, \dot{v} \mapsto a(u; v)$$

is coercive on  $V = H^1(\Omega)/C$ , where C denotes the subspace of the constant functions.

The existence and uniqueness of a solution  $u \in V$  to problem (4,4,3,2) follows now by Lemma 2.2.1.1 when  $\mathcal{D}$  is not empty. In the case when  $\mathcal{D}$  is empty, we have existence and uniqueness in  $H^1(\Omega)/C$ , provided

$$\dot{v} \mapsto \int_{\Omega} fv \, dx \, dy$$

is a continuous linear form on  $H^1(\Omega)/C$ . This means that we have existence in  $H^1(\Omega)$  up to an additive constant, provided

$$\int_{\Omega} f \, \mathrm{d}x \, \mathrm{d}y = 0.$$

We conclude by showing that our variational solution is actually a solution of problem (4,1,1). Indeed, restricting identity (4,4,3,2) to  $v \in \mathcal{D}(\Omega)$  shows that  $\Delta u = f$  in  $\Omega$  in the sense of distributions. Accordingly, u belongs to  $E(-\Delta; L_p(\Omega))$  (see Subsection 1.5.3) and  $\gamma_i u$  and  $\gamma_i \partial u / \partial v_i$  are well defined on each  $\Gamma_i$  by Theorem 1.5.3.10. Then the Green formula of Theorem 1.5.3.11 shows that

$$\gamma_i \frac{\partial u}{\partial \nu_i} + \beta_i \frac{\partial}{\partial \tau_i} \gamma_i u = 0$$

on  $\Gamma_i$  for every  $j \in \mathcal{N}$ .

We shall now try to calculate the dimension of  $M_q$ . The first technical step is the following. Here, again,  $\eta_i$  is any cut-off function which is 1 in a neighborhood of  $S_i$ , whose support does not intersect  $\bar{\Gamma}_k$  for  $k \neq j$  and j+1 and such that

$$\frac{\partial \eta_{i}}{\partial \nu_{l}} - \beta_{l} \frac{\partial \eta_{i}}{\partial \tau_{l}} = 0$$

on  $\Gamma_i$  when  $l \in \mathcal{N} \cap \{i; i+1\}$ .

**Lemma 4.4.3.2** For each j and each  $\lambda_{i,m} \in ]-2/q, 0]$  there exists  $\sigma_{i,m} \in M_q$  such that

$$\sigma_{i,m} - \eta_i u_{i,m} \in H^1(\Omega),$$

where

$$u_{i,m}(r_i e^{i\theta_i}) = \begin{cases} \frac{r_j^{\lambda_{i,m}}}{(\sqrt{\omega_j})\lambda_{i,m}} \cos(\lambda_{i,m}\theta_i + \Phi_{i+1}) & \text{if } \lambda_{i,m} < 0\\ \frac{\log r_j - \theta_i \tan \Phi_i}{\sqrt{[\omega_i(1 + \tan^2 \Phi_i)]}} & \text{if } \lambda_{i,m} = 0\\ & \text{and } j \text{ and } j + 1 \text{ are } \\ & \text{not both in } \mathcal{D}. \end{cases}$$

Here, again,  $r_i$ ,  $\theta_i$  denote the polar coordinates with origin at  $S_i$ .

Proof It is obvious that

$$\Delta \eta_j u_{j,m} = f_{j,m} \in C^{\infty}(\bar{\Omega})$$

and that

$$\begin{cases} \gamma_{l} \frac{\partial \eta_{j} u_{j,m}}{\partial \nu_{l}} - \beta_{l} \frac{\partial}{\partial \tau_{l}} \gamma_{l} \eta_{j} u_{j,m} = 0 & \text{on } \Gamma_{l}, \quad l \in \mathcal{N} \\ \gamma_{l} \eta_{j} u_{j,m} = 0 & \text{on } \Gamma_{l}, \quad l \in \mathcal{D}. \end{cases}$$

In addition  $\int_{\Omega} f_{i,m} dx dy = 0$  when  $\mathcal{D}$  is empty.

We can therefore apply Lemma 4.4.3.1 to prove the existence of  $v_{i,m} \in H^1(\Omega)$ , a solution of

$$\begin{cases} \Delta v_{j,m} = f_{j,m} & \text{in } \Omega \\ \gamma_l \frac{\partial v_{j,m}}{\partial \nu_l} - \beta_l \frac{\partial}{\partial \tau_l} \gamma_l v_{j,m} = 0 & \text{on } \Gamma_l, \quad l \in \mathcal{N} \\ \gamma_l v_{j,m} = 0 & \text{on } \Gamma_l, \quad l \in \mathcal{D}. \end{cases}$$

The conclusion of this lemma follows by setting

$$\sigma_{j,m} = \eta_j u_{j,m} - v_{j,m}. \quad \blacksquare$$

We are now able to state the key result of this subsection.

**Theorem 4.4.3.3** Under the assumption (4,4,3,1) and when

$$(\Phi_{\rm i} - \Phi_{\rm i+1} + 2\omega_{\rm i}/q)/\pi$$

is not an integer for any j, the dimension of the space of all solutions in  $L_q(\Omega)$  of problem (4,4,1,3) is

$$\mu(\Omega) = \sum_{j,j+1 \in \mathcal{D}} \operatorname{card} \left\{ m \in \mathbb{Z} \left| -\frac{2\omega_j}{q} < m\pi < 0 \right. \right\}$$

$$+ \sum_{j \text{ or } j+1 \in \mathcal{N}} \operatorname{card} \left\{ m \in \mathbb{Z} \left| -\frac{2\omega_j}{q} < \Phi_j - \Phi_{j+1} + m\pi \le 0 \right. \right\}$$

when  $\mathfrak D$  is not empty and  $\mu(\Omega)+1$  when  $\mathfrak D$  is empty.

**Proof** Let  $v \in L_q(\Omega)$  be solution of problem (4,4,1,3) and consider any fixed corner  $S_i$ . We apply Theorem 4.4.2.4 and Lemma 4.4.3.2 in the related disc D of radius  $\rho$ . It turns out that

$$v - \sum_{0 \ge \lambda_{i,m} > -2/q} c_{j,m} \sigma_{j,m} - \sum_{\lambda_{i,m} > 0} \frac{c_{j,m}}{\sqrt{\omega_j}} \frac{r_j^{\lambda_{i,m}}}{\lambda_{j,m}} \cos(\lambda_{j,m} \theta_j + \Phi_{j+1}) \in H^1(D)$$
(4,4,3,5)

with  $c_{j,m} = 0$  in the particular case when  $\lambda_{j,m} = 0$  and j and j + 1 belong to  $\mathfrak{D}$ .

We shall now show that the series in (4,4,3,5) belong to  $H^1(D_1)$  for every disc of radius  $\rho_1 < \rho$ . Indeed, let us denote this series by w. We have

$$\begin{aligned} & \frac{\partial w}{\partial r_{j}} = \sum_{\lambda_{i,m} > 0} \frac{c_{j,m}}{\sqrt{\omega_{j}}} r_{j}^{\lambda_{i,m}-1} \cos \left(\lambda_{j,m} \theta_{j} + \Phi_{j+1}\right) \\ & \frac{1}{r_{j}} \frac{\partial v}{\partial \theta_{j}} = -\sum_{\lambda_{i,m} > 0} \frac{c_{j,m}}{\sqrt{\omega_{j}}} r_{j}^{\lambda_{j,m}-1} \sin \left(\lambda_{j,m} \theta_{j} + \Phi_{j+1}\right) \end{aligned}$$

and consequently

$$|\nabla w| \leq \sum_{\lambda_{i,m}>0} |c_{i,m}| r_{i,m}^{\lambda_{i,m}-1} \frac{2}{\sqrt{\omega_i}}.$$

Then due to inequality (4,4,2,10),  $\nabla w$  is bounded in  $D_1$ ; indeed we have

$$|\nabla w(r_j e^{i\theta_j})| \leq \sum_{\lambda_{i,m} > 0} \frac{2}{\sqrt{\omega_j}} L m^{1/q} \frac{\rho_{1,m}^{\lambda_{i,m}-1}}{\rho^{\lambda_{i,m}}}$$

and this last series is convergent since  $\rho_1 > \rho$ . In other words, we have

$$v - \sum_{0 \geqslant \lambda_{i,m} > -2/q} c_{i,m} \sigma_{i,m} \in H^1(D_1).$$

230

Such a smoothness result holds near each of the corners  $S_i$ . Then, with the help of Lemma 4.4.2.1, we conclude that

$$v - \sum_{\substack{j=1,2\cdots N\\0\geqslant \lambda_{l,m} > -2/q}} c_{j,m} \sigma_{j,m} \in H^1(\Omega)$$

$$(4,4,3,6)$$

where  $c_{i,m} = 0$  for  $\lambda_{i,m} = 0$ , when both j and j+1 belong to  $\mathfrak{D}$ .

To end the proof, let us denote by  $\varphi$  the function in (4,4,3,6). It is a solution of problem (4,4,1,3) and in addition it belongs to  $H^1(\Omega)$ . Thus Lemma 4.4.3.1 shows that  $\varphi = 0$ , unless  $\mathfrak{D}$  is empty, where  $\varphi$  is a constant K. In other words, we have

$$v = \sum_{\substack{j=1,\ldots,N\\0\geqslant\lambda_{i,m}>-2/q}} c_{j,m}\sigma_{j,m} + K$$

where K = 0 unless  $\mathcal{D}$  is empty. The statement of Theorem 4.4.3.3 is an easy consequence.

Then, with the help of Theorem 4.4.1.6, we can derive a bound for the actual dimension of  $N_a$ .

#### Corollary 4.4.3.4 Assume that (4,4,3,1) holds and that

$$(\Phi_i - \Phi_{i+1} + 2\omega_i/q)/\pi$$

is not an integer for any j. Then when p < 2, the dimension of  $N_q$  is less than or equal to

$$\nu(\Omega) = \sum_{j=1}^{N} \operatorname{card} \left\{ m \in \mathbb{Z} \left| -\frac{2\omega_{j}}{q} < \Phi_{j} - \Phi_{j+1} + m\pi < 0 \right. \right\}$$

if  $\mathfrak D$  is not empty and  $\nu(\Omega)+1$  if  $\mathfrak D$  is empty. When p>2 the dimension of  $N_a$  is less than or equal to

$$\nu(\Omega)$$
 – card  $\{j \mid \mu_j \text{ is parallel to } \mu_{j+1}\}$ 

if  $\mathcal{D}$  is not empty and  $\nu(\Omega)+1$  again if  $\mathcal{D}$  is empty.

Observe that when  $\mathcal{D}$  is empty, we are just dealing with a pure Neumann problem, owing to (4,4,3,1).

*Proof* So far, we have shown that the  $\sigma_{i,m}$ ,  $1 \le j \le N$ ,  $-2/q < \lambda_{i,m} < 0$  (if j and  $j+1\in\mathcal{D}$ ,  $-2/q<\lambda_{i,m}\leq 0$  (if j or  $j+1\in\mathcal{N}$ ) are a basis of  $M_q$  (possibly up to the constant function).

We shall first show that any  $\sigma_{i,m}$  corresponding to  $\lambda_{i,m} = 0$  does not belong to  $N_q$ . Due to assumption (4,4,3,1)  $\lambda_{j,m}$  can vanish iff j and  $j+1 \in \mathcal{N}$  (and consequently  $\Phi_j = \Phi_{j+1} = 0$ ). The corresponding  $\sigma_{j,m}$  is eliminated by condition (4,4,1,7) (see Theorem 4.4.1.8). Indeed we have (in the polar coordinates related to  $S_i$ )

$$\sigma_{j,m} = \eta \log r_j / \sqrt{(\omega_j)} + v,$$

where  $v \in H^1(\Omega)$ ,  $\eta(0) = 1$ ,  $\eta$  depends only on  $r_i$ ,  $\eta(r_i) = 1$  for  $r_i \le \rho_i$ ,  $\eta(r_i) = 0$  for  $r_i \ge \rho_e$  where  $0 < \rho_i < \rho_e$  are chosen in such a way that the support of  $\eta$  does not meet  $\Gamma_k$  for  $k \ne j$  and j + 1. Then, in condition (4,4,1,7), we can choose  $\varphi_i = \eta$ . Accordingly, this condition reduces to

$$\int_{\Omega} \Delta \eta \sigma_{j,m} \, \mathrm{d}x \, \mathrm{d}y = 0.$$

Actually we have

$$\int_{\Omega} \Delta \eta v \, dx \, dy = \int_{\Omega} \eta \Delta v \, dx \, dy$$

since both  $\eta$  and v belong to  $H^1(\Omega)$ ,  $\eta$  has a small support around  $S_i$  and both  $\eta$  and v fulfil a Neumann boundary condition on  $\Gamma_i$  and  $\Gamma_{i+1}$ .

On the other hand, we have

$$\int_{\Omega} \Delta \eta(\eta \log r_i) \, dx \, dy = \int_{\Omega'} \Delta \eta(\eta \log r_i) \, dx \, dy$$

where  $\Omega' = \Omega \setminus \{r_i \le \rho_i\}$ , since  $\Delta \eta$  vanishes in  $\Omega \setminus \Omega'$ . We can apply again Green's formula since both  $\eta$  and  $\eta \log r_i$  are smooth in  $\Omega'$ . We thus get

$$\int_{\Omega} \Delta \eta(\eta \log r_i) dx dy$$

$$= \int_{\Omega'} \eta \Delta(\eta \log r_i) dx dy + \int_{\gamma} \left\{ \frac{\partial \eta}{\partial \nu} \eta \log r_i - \eta \frac{\partial}{\partial \nu} (\eta \log r_i) \right\} d\sigma$$

where  $\gamma = \partial \Omega' \setminus \partial \Omega$ . It follows that

$$\int_{\Omega} \Delta \eta (\eta \log r_{i}) dx dy / \sqrt{\omega_{i}}$$

$$= \int_{\Omega} \eta (\Delta \sigma_{i,m} - \Delta v) dx dy - \int_{0}^{\omega_{i}} \frac{1}{\rho_{i}} \rho_{i} d\theta / \sqrt{\omega_{i}} = -\int_{\Omega} \eta \Delta v dx dy - \sqrt{\omega_{i}}$$

since  $\sigma_{i,m}$  is harmonic.

Finally, we have

$$\int_{\Omega} \Delta \eta \sigma_{j,m} \, \mathrm{d}x \, \mathrm{d}y = -\sqrt{\omega_j}$$

and this contradicts the condition (4,4,1,7). Accordingly,  $\sigma_{i,m}$  does not

belong to  $N_q$ . Consequently, the dimension of  $N_q$  is less than or equal to  $\nu(\Omega)$  when  $\mathcal{D}$  is not empty and to  $\nu(\Omega)+1$  when  $\mathcal{D}$  is empty.

To complete the proof of Corollary 4.4.3.4 we observe that any  $\sigma_{i,m}$  corresponding to  $\lambda_{i,m} = -1$  is eliminated from  $N_q$  by condition (4,4,1,8) or (4,4,1,9) in Theorem 4.4.1.6 when p is greater than 2. The calculations are very similar to the previous one, so that we do not need to repeat it. The condition  $\lambda_{i,m} = -1$  for one integer m is fulfilled iff  $\mu_i$  is parallel to  $\mu_{i+1}$ .

This result, together with Lemma 4.4.3.1, allows us to calculate the index of  $\Delta$  as an operator from  $E_1$  to  $E_2$  (these spaces have been defined in Subsection 4.4.1). We shall also be able to conclude when p=2, due to the inclusion  $N_2 \subseteq N_a$  which holds for q < 2.

For that purpose, let us again use the polar coordinates with origin at  $S_i$  and let us consider the functions

$$S_{j,m}(r_j e^{i\theta_j}) = \frac{r_j^{-\lambda_{j,m}}}{(\sqrt{\omega_j})\lambda_{j,m}} \cos(\lambda_{j,m}\theta_j + \Phi_{j+1})\eta_j(r_j e^{i\theta_j})$$
(4,4,3,7)

with  $\lambda_{i,m} < 0$ , not an integer. Here are some properties of these functions.

**Lemma 4.4.3.5** 
$$S_{j,m} \in H^1(\Omega) \setminus W_p^2(\Omega)$$
 for

$$-\frac{2}{q} \leq \lambda_{j,m} < 0, \qquad 1 \leq j \leq N, \quad \lambda_{j,m} \neq -1$$

and in addition

$$\begin{cases} \Delta S_{\mathbf{j},m} \in C^{\infty}(\bar{\Omega}) \\ \gamma_{l} \frac{\partial S_{\mathbf{j},m}}{\partial \nu_{l}} + \beta_{l} \frac{\partial}{\partial \tau_{l}} \gamma_{l} S_{\mathbf{j},m} = 0 & on \ \Gamma_{l} \quad \text{if } l \in \mathcal{N} \\ \gamma_{l} S_{\mathbf{j},m} = 0 & on \ \Gamma_{l} \quad \text{if } l \in \mathcal{D}. \end{cases}$$

This is obvious. The following statement deserves a proof.

**Lemma 4.4.3.6** Assuming that (4,4,3,1) holds,  $\Delta S_{j,m}$  is not orthogonal to  $N_q$  for

$$-\frac{2}{q} \leq \lambda_{j,m} < 0, \qquad 1 \leq j \leq N, \quad \lambda_{j,m} \neq -1.$$

**Proof** This can be proved by contradiction. Thus, if we assume that  $S_{i,m}$  is orthogonal to  $N_q$ , then there exists  $w_{i,m} \in W_p^2(\Omega)$  fulfilling the boundary conditions in (4,1,1) such that

$$\Delta w_{j,m} = \Delta S_{j,m}$$

Therefore  $w_{j,m} - S_{j,m}$  is a solution of the homogeneous problem and belongs to  $H^1(\Omega)$ . By the uniqueness result of Lemma 4.4.3.1, this implies that  $S_{j,m}$  belongs to  $W_p^2(\Omega)$ . This contradicts Lemma 4.4.3.5.

We are now able to conclude.

**Theorem 4.4.3.7** We assume that (4,4,3,1) holds and that

$$(\Phi_i - \Phi_{i+1} + 2\omega_i/q)/\pi$$

is not an integer for any j, that in addition  $\mu_i$  is never parallel to  $\mu_{j+1}$ , when p=2. Then for each  $f \in L_p(\Omega)$ , there exist unique real numbers  $C_{j,m}$  and a unique u such that

$$u - \sum_{\substack{1 \le j \le N \\ -2/q < \lambda_{j,m} < 0 \\ \lambda_{j} \ne -1}} C_{j,m} S_{j,m} \in W_{p}^{2}(\Omega)$$

$$(4,4,3,8)$$

and u is solution of problem (4,1,1) when  $\mathcal{D}$  is not empty. Otherwise, when  $\mathcal{D}$  is empty u is unique up to an additive constant and exists iff

$$\int_{\Omega} f \, \mathrm{d}x \, \mathrm{d}y = 0.$$

*Proof* The functions  $\Delta S_{j,m}$  corresponding to

$$-\frac{2}{q} < \lambda_{j,m} < 0, \quad \lambda_{j,m} \neq -1, \quad j = 1, 2, ..., N$$

are in  $L_p(\Omega)$  and are clearly linearly independent. Since they are not orthogonal to  $N_q$ , they do not belong to the image of  $E_1$  through  $\Delta$ . Moreover, their number is exactly the upper bound for the dimension of  $N_q$  (possibly minus one when  $\mathcal{D}$  is empty) that we found in Corollary 4.4.3.4. Consequently,  $L_p(\Omega)$  is the span of the image of  $E_1$  through  $\Delta$  and of these functions  $\Delta S_{i,m}$ . The claim follows by Lemma 4.4.3.1.

One could ask why there is a gap in the index of the problem corresponding to the eigenvalue  $\lambda_{j,m} = -1$ . Actually, there is no longer any gap when we consider nonhomogeneous boundary conditions:

**Corollary 4.4.3.8** Under the assumptions of Theorem 4.4.3.7, let  $f \in L_p(\Omega)$  and  $g_j \in W_p^{2-1/p}(\Gamma_j)$ ,  $j \in \mathcal{D}$ ,  $g_j \in W_p^{1-1/p}(\Gamma_j)$ ,  $j \in \mathcal{N}$  be given such that

$$g_{j}(S_{j}) = \frac{\partial g_{j+1}}{\partial \mu_{j}}(S_{j}) \text{ if } j \in \mathcal{N} \text{ and } j+1 \in \mathcal{D} \text{ or } g_{j+1}(S_{j}) = \frac{\partial g_{j}}{\partial \mu_{j+1}}(S_{j})$$

$$\text{if } j \in \mathcal{D} \text{ and } j+1 \in \mathcal{N}, \quad (4,4,3,9)$$

whenever  $\mu_i$  is parallel to  $\mu_{i+1}$ , and p>2. Then assuming that  $\mathfrak{D}$  is not empty, there exist unique real numbers  $C_{i,m}$  and a unique u such that (4,4,3,8) holds and u is solution of

$$\begin{cases} \Delta u = f, & (\Omega) \\ \gamma_{i} u = g_{i}, & j \in \mathcal{D} \\ \gamma_{i} \frac{\partial u}{\partial \nu_{i}} + \beta_{i} \frac{\partial}{\partial \tau_{i}} \gamma_{i} u = g_{i}, & j \in \mathcal{N}. \end{cases}$$

When  $\mathcal{D}$  is empty the condition (4,4,3,9) is void and u is unique up to the addition of a constant and exists iff

$$\int_{\Omega} f \, \mathrm{d}x \, \mathrm{d}y - \sum_{j=1}^{N} \int_{\Gamma_{j}} g_{j} \, \mathrm{d}\sigma = 0.$$

This result follows from Theorem 4.4.3.7 and the trace theorems in Subsection 1.5.2. We observe that the number of extra conditions that we have added on the data in (4,4,3,9) is exactly

$$\sum_{j=1}^{N} \operatorname{card} \left\{ \lambda_{j,m} \left| -\frac{2}{q} < \lambda_{j,m} = -1 \right. \right\}.$$

#### 4.4.4 The Fredholm alternative for nonvariational problems

Here, we try as far as possible, to deal with problem (4,1,1) in most cases. The existence and uniqueness result of Lemma 4.4.3.1 has been a basic tool in the study that we carried out in Subsection 4.4.3. Unfortunately, if we drop the assumption (4,4,3,1), it may happen that problem (4,1,1) could not be solved uniquely in  $H^1(\Omega)$ . This will make our analysis much more complicated.

On the one hand, we still have an existence result in  $H^1(\Omega)$ , which is an application of a lemma in Lions (1956). We recall this result with a slightly different proof.

**Lemma 4.4.4.1** Let W and V be a pair of Hilbert spaces with a continuous injection of W in V and let a be a continuous bilinear form on  $V \times W$ . Assume that there exists a constant  $\alpha > 0$  such that

$$a(v, v) \ge \alpha \|v\|_V^2$$
 (4,4,4,1)

for all  $v \in W$ . Then for every continuous linear form l on V, there exists  $u \in V$ , possibly non-unique, such that

$$a(u; v) = l(v)$$
 (4,4,4,2)

for every  $v \in W$ .

This lemma is somewhat similar to Lemma 2.2.1.1 and is actually a consequence of it.

**Proof** For  $\varepsilon > 0$ , we introduce the form

$$a_{\varepsilon}(u, v) = a(u; v) + \varepsilon(u; v)_{w}, \qquad u, v \in W.$$

This is a continuous bilinear form on  $W \times W$ , which, in addition, is coercive (with coerciveness constant  $\ge \varepsilon$ ). Consequently, by Lemma 2.2.1.1, there exists a unique  $u_{\varepsilon} \in W$  such that

$$a_{\varepsilon}(u_{\varepsilon}, v) = l(v) \tag{4,4,4,3}$$

for every  $v \in W$ .

Using the coerciveness assumption on a and setting  $v = u_{\varepsilon}$  in identity (4,4,4,3), we find bounds for  $u_{\varepsilon}$ :

$$\alpha \|u_{\varepsilon}\|_{V}^{2} + \varepsilon \|u_{\varepsilon}\|_{W}^{2} = l(u_{\varepsilon}) \leq \|l\|_{V^{*}} \|u_{\varepsilon}\|_{V}.$$

Consequently, we have

$$\begin{cases} \|u_{\varepsilon}\|_{V} \leq \alpha^{-1} \|l\|_{V^{*}}, \\ \|\sqrt{\varepsilon} u_{\varepsilon}\|_{W} \leq \alpha^{-1/2} \|l\|_{V^{*}}. \end{cases}$$

Due to the famous property of bounded sequences in Hilbert spaces, we can find a sequence  $\varepsilon_j$ ,  $j = 1, 2, \ldots$  converging to zero, together with  $u \in V$  (clearly we cannot expect u to be unique in general) and  $w \in W$  such that

$$\begin{cases} u_{\varepsilon_i} \rightharpoonup u \text{ weakly in } V \\ (\sqrt{\varepsilon_i})u_{\varepsilon_i} \rightharpoonup w \text{ weakly in } W. \end{cases}$$

Going back to identity (4,4,4,2), we have

$$a(u_{\varepsilon_i}, v) + \sqrt{\varepsilon_i} (\sqrt{\varepsilon_i} u_{\varepsilon_i}; v)_{\mathbf{w}} = l(v)$$

for every  $v \in W$ . Taking the limit in j proves identity (4,4,4,2).

Lemma 4.4.4.1 will be applied as follows. Again, as in Subsection 4.4.3, we set

$$V = \{ u \in H^1(\Omega) \mid \gamma_i u = 0, \quad \forall j \in \mathcal{D} \}.$$

Then we set

$$W = \{u \in H^2(\Omega) \mid \gamma_i u = 0, \forall j \in \mathcal{D} \text{ and } u(S_i) = 0, \forall j\};$$

this is a Hilbert space for the norm of  $H^2(\Omega)$ . Finally the form a is defined by

$$a(u; v) = \int_{\Omega} \nabla u \cdot \nabla v \, dx \, dy + \frac{1}{2} \sum_{i \in \mathcal{N}} \beta_i \left\{ \left\langle \frac{\partial}{\partial \tau_i} \gamma_i u; \gamma_i v \right\rangle - \left\langle \gamma_i u; \frac{\partial}{\partial \tau_i} \gamma_i v \right\rangle \right\}. \tag{4.4.4.4}$$

It is easy to check that a is well defined<sup>†</sup> and continuous on  $V \times W$ , since for  $u \in V$  and  $v \in W$ , we have

$$\gamma_j u \in H^{1/2}(\Gamma_j), \qquad \frac{\partial}{\partial \tau_i} \gamma_j u \in \tilde{H}^{1/2}(\Gamma_j)^*$$

and

$$\gamma_i v \in H^{3/2}(\Gamma_i) \cap \mathring{H}^1(\Gamma_i) \subset \tilde{H}^{1/2}(\Gamma_i), \qquad \frac{\partial}{\partial \tau_i} \gamma_i v \in H^{1/2}(\Gamma_i).$$

The coerciveness of a in the sense of (4,4,4,1) follows obviously from Poincaré's inequality when  $\mathcal{D}$  is not empty. When  $\mathcal{D}$  is empty, we must replace everywhere V by V/C, where C denotes the space of constant functions in  $\Omega$ .

Consequently, given  $f \in L_p(\Omega)$ , there exists at least one  $u \in H^1(\Omega)$  such that

$$a(u; v) = -\int_{\Omega} fv \, dx \, dy$$
 (4,4,4,5)

for every  $v \in W$  (provided  $\int_{\Omega} f dx dy = 0$  when  $\mathcal{D}$  is empty).

We must now make it clear in what sense such a u is the solution of problem (4,1,1). Obviously, we show that

$$\Delta u = f$$
 in  $\Omega$ ,

by writing (4,4,4,5) with  $v \in \mathcal{D}(\Omega)$ . Therefore, u belongs to the space  $E(\Delta; L_p(\Omega))$  defined in Subsection 1.5.3. Consequently,  $\gamma_i \partial u/\partial \nu_i$  is well defined as an element of  $\tilde{H}^{1/2}(\Gamma_i)^*$ . Then, applying the Green formula (1,5,3,9), we deduce from (4,4,4,4) and (4,4,4,5) that

$$\sum_{i \in \mathcal{N}} \frac{\tan \Phi_i}{2} \left\{ \left\langle \frac{\partial}{\partial \tau_i} \gamma_i u; \gamma_i v \right\rangle - \left\langle \gamma_i u; \frac{\partial}{\partial \tau_i} \gamma_i v \right\rangle \right\} = -\sum_{i \in \mathcal{N}} \left\langle \gamma_i \frac{\partial u}{\partial \nu_i}; \gamma_i v \right\rangle$$

for every  $v \in W$  (which is a subspace of the space of possible test-functions in Theorem 1.5.3.11). In other words, this identity holds for every

$$\gamma_i v \in H^{3/2}(\Gamma_i) \cap \mathring{H}^1(\Gamma_i), \quad j \in \mathcal{N}.$$

 $\dagger$  Observe that under assumption (4,4,3,1) the forms defined by (4,4,3,3) and (4,4,4,4) coincide, since

$$\left\langle \frac{\partial}{\partial \tau_{i}} \varphi; \psi \right\rangle = \left\langle \varphi; \frac{\partial \psi}{\partial \tau_{i}} \right\rangle$$

for every  $\varphi$  and  $\psi \in \tilde{H}^{1/2}(\Gamma_i)$ .

This is enough to prove that

$$\gamma_i \frac{\partial u}{\partial \nu_i} + \tan \Phi_i \frac{\partial}{\partial \tau_i} \gamma_i u = 0, \quad j \in \mathcal{N}.$$

Summing up, we have proved the following statement.

**Lemma 4.4.4.2** Assume that  $\mathfrak{D}$  is not empty, then for every given  $f \in L_p(\Omega)$ , problem (4,1,1) has a (possibly nonunique) solution  $u \in H^1(\Omega)$ . When  $\mathfrak{D}$  is empty, the same result holds provided

$$\int_{\Omega} f \, \mathrm{d}x \, \mathrm{d}y = 0.$$

Our main trouble now is that we have no uniqueness result in  $H^1(\Omega)$ . However, we have results in some particular cases, if we assume in addition that u is slightly more regular, namely  $u \in W^1_p(\Omega)$  with p > 2.

In the first particular case, we assume that  $\mathcal{D}$  is empty and that

$$\beta_2 \geqslant \cdots \geqslant \beta_i \geqslant \beta_{i+1} \geqslant \cdots \geqslant \beta_1, \qquad 2 \leqslant j \leqslant N$$
 (4,4,4,6)

**Lemma 4.4.4.3** Let  $u \in W_p^1(\Omega)$  with p > 2 be the solution of problem (4,4,1) with f = 0. Assume that (4,4,4,6) holds, then u is a constant.

This will be proved as usual, by calculating the integral of  $\Delta u$  against u on  $\Omega$ . Unfortunately, this cannot be done directly and we must approximate u by a sequence of smoother functions. This is the purpose of the following auxiliary lemma, whose proof is similar to that of Lemma 1.5.3.9 and Theorem 1.5.3.10.

**Lemma 4.4.4.4**  $\mathfrak{D}(\bar{\Omega})$  is dense in the space

$$F(\Delta; L_p(\Omega)) = \{ u \in W_p^1(\Omega); \Delta u \in L_p(\Omega) \}$$

equipped with the norm

$$u \mapsto ||u||_{1,p,\Omega} + ||\Delta u||_{0,p,\Omega}.$$

In addition  $u \mapsto \gamma_j \partial u/\partial v_j$  has a continuous extension as an operator from  $F(\Delta; L_p(\Omega))$  into  $W_p^{-1/p}(\Gamma_i)$ .

**Proof of Lemma 4.4.4.3** We let  $u_m$ , m = 1, 2, ... be a sequence of functions in  $W_p^2(\Omega)$  such that

$$\begin{cases} u_m \to u & \text{in } W^1_p(\Omega) \\ \Delta u_m \to \Delta u & \text{in } L_p(\Omega) \end{cases}$$

where  $m \to \infty$ .

For  $u_m \in W_n^2(\Omega)$  the usual Green formula holds. Thus we have

$$\begin{split} &-\int_{\Omega} \Delta u_{m} u_{m} \, dx \, dy \\ &= \int_{\Omega} |\nabla u_{m}|^{2} \, dx \, dy - \sum_{j=1}^{N} \int_{\Gamma_{i}} \gamma_{j} \frac{\partial u_{m}}{\partial \nu_{i}} \gamma_{j} u_{m} \, d\sigma \\ &= \int_{\Omega} |\nabla u_{m}|^{2} \, dx \, dy - \sum_{j=1}^{N} \int_{\Gamma_{i}} \left( \gamma_{j} \frac{\partial u_{m}}{\partial \nu_{j}} + \beta_{j} \frac{\partial}{\partial \tau_{j}} \gamma_{j} u_{m} \right) \gamma_{j} u_{m} \, d\sigma \\ &+ \sum_{i=1}^{N} \frac{\beta_{i}}{2} \{ u_{m}^{2}(S_{i}) - u_{m}^{2}(S_{i-1}) \} \\ &= \int_{\Omega} |\nabla u_{m}|^{2} \, dx \, dy - \sum_{j=1}^{N} \int_{\Gamma_{i}} \left( \gamma_{j} \frac{\partial u_{m}}{\partial \nu_{j}} + \beta_{j} \frac{\partial}{\partial \tau_{j}} \gamma_{j} u_{m} \right) \gamma_{j} u_{m} \, d\sigma \\ &+ \sum_{j=1}^{N} \frac{\beta_{i} - \beta_{j+1}}{2} u_{m}^{2}(S_{i}). \end{split}$$

We can take the limit in m of this identity, due to the fact that p is strictly larger than 2. Thus we get

$$-\int_{\Omega} \Delta u \, u \, dx \, dy = \int_{\Omega} |\nabla u|^2 \, dx \, dy$$

$$-\sum_{i=1}^{N} \left\langle \gamma_i \frac{\partial u}{\partial \nu_i} + \beta_i \frac{\partial}{\partial \tau_i} \gamma_i u; \gamma_j u \right\rangle + \sum_{j=1}^{N} \frac{\beta_j - \beta_{j+1}}{2} u^2(S_j). \tag{4,4,4,7}$$

We observe that the bracket on  $\Gamma_i$  is meaningful since

$$\gamma_i u \in W^{1-1/p}(\Gamma_i) \subset W_q^{1/p}(\Gamma_i) = \mathring{W}_q^{1/p}(\Gamma_i)$$

and

$$\gamma_i \frac{\partial u}{\partial \nu_i} + \beta_i \frac{\partial}{\partial \tau_i} \gamma_i u \in W^{-1/p}_p(\Gamma_i)$$

for j = 1, ..., N.

Actually the same identity holds with u replaced by  $u - u(S_1)$ . Thus we get

$$-\int_{\Omega} \Delta u (u - u(S_1)) \, dx \, dy$$

$$= \int_{\Omega} |\nabla u|^2 \, dx \, dy - \sum_{j=1}^{N} \left\langle \gamma_j \frac{\partial u}{\partial \nu_j} + \beta_j \frac{\partial}{\partial \tau_j} \gamma_j u; \gamma_j u - u(S_1) \right\rangle$$

$$+ \sum_{j=2}^{N} \frac{\beta_j - \beta_{j+1}}{2} \{ u(S_j) - u(S_1) \}^2.$$

Since u is harmonic and fulfils the boundary conditions in (4,4,1), we finally conclude that

$$0 = \int_{\Omega} |\nabla u|^2 dx dy + \sum_{j=2}^{N} \frac{\beta_j - \beta_{j+1}}{2} \{ u(S_j) - u(S_1) \}^2.$$

Since by assumption (4,4,4,6) we have

$$\beta_i - \beta_{i+1} \ge 0$$

for i = 2, ..., N, it follows that u is a constant function.

Another useful particular case is this: We assume that  $\mathcal{D} = \{3, ..., N\}$  and that

$$\beta_1 \geqslant \beta_2. \tag{4,4,4,8}$$

Again we have a uniqueness result for solutions in  $W_p^1(\Omega)$  with p > 2.

**Lemma 4.4.4.5** Let  $u \in W_p^1(\Omega)$ , with p > 2, be the solution of problem (4,4,1) with f = 0. Assume that (4,4,4,8) holds, then u is zero.

**Proof** Again identity (4,4,4,7) holds for u. Thus we have

$$0 = \int_{\Omega} |\nabla u|^2 dx dy + \frac{\beta_1 - \beta_2}{2} u(S_1)^2$$

and consequently u is zero.

We shall now study the space  $M_q$ . First we observe that the analogue of Lemma 4.4.3.2 holds in the most general case.

**Lemma 4.4.4.6** For each j and each  $\lambda_{j,m} \in ]-2/q, 0]$  there exists  $\sigma_{j,m} \in M_q$  such that

$$w_{i,m} = \sigma_{i,m} - \eta_{i,m} u_{i,m} \in H^1(\Omega)$$

if  $\lambda_{i,m} < 0$  or if  $\lambda_{i,m} = 0$  and j and j+1 do not both belong to  $\mathfrak{D}$ .

**Proof** This is quite similar to the proof of Lemma 4.4.3.2, since there we only used the existence result in Lemma 4.4.3.1. The corresponding existence result is now provided by Lemma 4.4.4.2.

However, we can improve this result due to the fact that 0 is not a limit point of the set  $\{\lambda_{j,m} \mid m \in \mathbb{Z}\}$ .

**Lemma 4.4.4.7** There exists p > 2 such that

$$w_{j,m} \in W^1_p(\Omega)$$

for each  $\lambda_{j,m} \in ]-2/q, 0]$ , provided  $(\Phi_k - \Phi_{k+1} + 2\omega_k/q)/\pi$  is not an integer for any k.

**Proof** The function  $w_{j,m}$  is one solution of the homogeneous problem near each corner  $S_k$ . In addition it belongs to  $L_q(\Omega)$  and it is smooth in  $\bar{\Omega}\setminus\{S_1,\ldots,S_N\}$  by Lemma 4.4.2.1. Thus it follows from Theorem 4.4.2.4 that

$$w_{j,m}(r_k e^{i\theta_k}) = \sum_{\lambda_{k,l} > -2/q} \frac{c_{k,l}}{\sqrt{\omega_k}} \frac{r_k^{\lambda_{k,l}}}{\lambda_{k,l}} \cos(\lambda_{k,l}\theta_k + \Phi_{k+1}) + \mathcal{X}$$

for  $r_k$  small enough, provided  $(\Phi_k - \Phi_{k+1} + 2\omega_k/q)/\pi$  is not an integer. Consequently, by Lemma 4.4.4.6, we have

$$\sum_{\lambda_{k,l} > -2/q} \frac{c_{k,l}}{\sqrt{\omega_k}} \frac{r_k^{\lambda_{k,l}}}{\lambda_{k,l}} \cos(\lambda_{k,l} \theta_k + \Phi_{k+1}) \in H^1(D)$$
(4,4,4,9)

where D is  $\Omega \cap \{r_k < \rho\}$  for  $\rho$  small enough.

Now inequality (4,4,2,10) implies that

$$|c_{k,l}| l^{-1/q} \rho^{\lambda_{k,l}}$$

is bounded as  $l \to +\infty$ . It follows that

$$\sum_{\lambda_{k,l}>0} \frac{c_{k,l}}{\sqrt{\omega_k}} \frac{r_k^{\lambda_{k,l}}}{\lambda_{k,l}} \cos(\lambda_{k,l} \theta_k + \Phi_{k+1}) \in W_p^1(D_1)$$
 (4,4,4,10)

for each  $D_1 = \Omega \cap \{r_k < \rho_1\}$ , where  $\rho_1 < \rho$ . This implies, by difference between (4,4,4,9) and (4,4,4,10), that

$$\sum_{-2/q < \lambda_{k,l} \leq 0} \frac{c_{k,l}}{\sqrt{\omega_k}} \frac{r_{k,l}^{\lambda_{k,l}}}{\lambda_{k,l}} \cos(\lambda_{k,l}\theta_k + \Phi_{k+1}) \in H^1(D_1).$$

Consequently we have

$$c_{k,l} = 0$$
 for  $\lambda_{k,l} \leq 0$ .

Summing up, we have

$$w_{i,m}(r_k e^{i\theta_k}) = \sum_{\lambda_{k+1} > 0} \frac{c_{k,l}}{\sqrt{\omega_k}} \frac{r_k^{\lambda_{k,l}}}{\lambda_{k,l}} \cos(\lambda_{k,l}\theta_k + \Phi_{k+1})$$

near  $S_k$  and by (4,4,4,10) this shows that

$$w_{i,m} \in W^1_p(D_1)$$

for  $\inf \{\lambda_{l,k} \mid \lambda_{l,k} > 0\} > 1 - 2/p$ . This is true near each corner  $S_k$  and consequently we have

$$w_{j,m} \in W^1_p(\Omega)$$

for some p > 2.

We are now able to calculate the dimension of  $M_q$  in two particular cases 'adjoint' to the cases considered in Lemmas 4.4.4.3 and 4.4.4.5.

**Theorem 4.4.4.8** Assume that  $\mathfrak{D}$  is empty, that  $(\Phi_i - \Phi_{j+1} + 2\omega_j/q)/\pi$  is not an integer for any j and that

$$\tan \Phi_2 \leqslant \cdots \leqslant \tan \Phi_i \leqslant \tan \Phi_{i+1} \leqslant \cdots \leqslant \tan \Phi_N \leqslant \tan \Phi_1$$
.

Then the dimension of  $N_a$  is less than or equal to

$$\mu(\Omega) = \sum_{j=1}^{N} \operatorname{card} \left\{ m \in \mathbb{Z} \left| -\frac{2\omega_{j}}{q} < \Phi_{j} - \Phi_{j+1} + m\pi < 0 \right. \right\} + 1.$$

**Proof** Let  $v \in M_q$ . Then  $v \in L_q(\Omega)$  and is a solution of the problem (4,4,1,3). By Lemma 4.4.2.1, we know that v is smooth, far from the corners. Then near each corner  $S_i$ , v has an expansion given by Theorem 4.4.2.4. In other words, we have

$$v = \sum_{\lambda_{i,m} > -2/q} \frac{c_{i,m}}{\sqrt{\omega_i}} \frac{r_{i,m}^{\lambda_{i,m}}}{\lambda_{i,m}} \cos(\lambda_{i,m}\theta_i + \Phi_{i+1})$$

in  $D = \Omega \cap \{r_i < \rho\}$  for some  $\rho > 0$ .

Again here, due to inequality (4,4,2,10), the series

$$\sum_{\lambda_{i,m}>0} \frac{c_{i,m}}{\sqrt{\omega_i}} \frac{r_{i,m}^{\lambda_{i,m}}}{\lambda_{i,m}} \cos\left(\lambda_{i,m}\theta_i + \Phi_{i+1}\right)$$

belongs to  $W_p^1(D)$ . This, together with Lemma 4.4.4.7, implies that

$$v - \sum_{-2/q < \lambda_{i,m} \leqslant 0} c_{j,m} \sigma_{j,m} \in W^1_p(D).$$

Since  $\sigma_{j,m} \in W^1_p(\Omega \setminus \overline{D})$ , it follows that

$$w = v - \sum_{\substack{j=1,2,\ldots,N\\-2/q < \lambda_{j,m} \leq 0}} c_{j,m} \sigma_{j,m} \in W^1_{\mathfrak{p}}(\Omega)$$

for some p > 2.

Now w is solution of the homogeneous problem (4,4,1,3). Applying Lemma 4.4.4.3 we see that w must be a constant. Finally, the function  $\sigma_{j,m}$  corresponding (possibly) to  $\lambda_{j,m} = 0$  is eliminated from  $N_q$  by condition (4,4,1,7) of Theorem 4.4.1.8 as in the proof of Corollary 4.4.3.4.

The same method of proof, with Lemma 4.4.4.3 replaced by Lemma 4.4.4.5, leads to the following statement.

**Theorem 4.4.4.9** Assume that  $\mathcal{D} = \{3, 4, ..., N\}$ , that

$$(\Phi_i - \Phi_{i+1} + 2\omega_i/q)/\pi$$

is not an integer for any j and that

 $\tan \Phi_1 \leq \tan \Phi_2$ .

Then the dimension of  $N_q$  is less than or equal to

$$\mu(\Omega) = \sum_{i=1}^{N} \operatorname{card} \left\{ m \in \mathbb{Z} \mid -\frac{2\omega_{i}}{q} < \Phi_{i} - \Phi_{i+1} + m\pi < 0 \right\}.$$

Now, exactly as we did in Subsection 4.4.3, we shall derive existence results in the space spanned by  $W_p^2(\Omega)$  and the functions  $S_{i,m}$  corresponding to  $-2/q < \lambda_{i,m} < 0$ . Indeed, the result of Lemma 4.4.3.5 holds in the most general case. The analogue of Lemma 4.4.3.6 is the following.

**Lemma 4.4.4.10**  $\Delta S_{j,m}$  is not orthogonal to  $N_q$  for  $-2/q \le \lambda_{j,m} < 0$ ,  $1 \le j \le N$ ,  $\lambda_{j,m} \ne -1$ .

Proof Actually, we shall prove that

$$\int_{\Omega} \Delta S_{i,m} \sigma_{i,m} \, dx \, dy = \frac{1}{\lambda_{i,m}}.$$
 (4,4,4,11)

Indeed we have  $\sigma_{j,m} = \psi_{j,m} + w_{j,m}$ , where

$$\psi_{j,m} = \frac{r_{j,m}^{\lambda_{j,m}}}{(\sqrt{\omega_j})\lambda_{j,m}} \cos(\lambda_{j,m}\theta_j + \Phi_{j+1})\eta_j$$

in the polar coordinates with origin at  $S_j$ . In addition, both  $S_{j,m}$  and  $w_{j,m}$  belong to  $W_p^1(\Omega)$  for some p>2. This allows us to apply the classical Green formula; thus we get

$$\begin{split} & \int_{\Omega} \Delta S_{i,m} w_{i,m} \, dx \, dy - \int_{\Omega} S_{i,m} \Delta w_{i,m} \, dx \, dy \\ & = \sum_{l=1}^{N} \left\{ \left\langle \gamma_{l} \frac{\partial S_{i,m}}{\partial \nu_{l}}; \, \gamma_{l} w_{j,m} \right\rangle - \left\langle \gamma_{l} S_{i,m}; \, \gamma_{l} \frac{\partial w_{i,m}}{\partial \nu_{l}} \right\rangle \right\} \\ & = -\sum_{l=1}^{N} \tan \left. \Phi_{l} (S_{i,m} w_{i,m}) \right|_{S_{l-1}}^{S_{l-1}} = 0. \end{split}$$

This is due to the boundary conditions

$$\gamma_{l} \frac{\partial S_{j,m}}{\partial \nu_{l}} + \tan \Phi_{l} \frac{\partial}{\partial \tau_{l}} \gamma_{l} S_{j,m} = 0 \quad \text{on } \Gamma_{l}$$

$$\gamma_{l} \frac{\partial w_{j,m}}{\partial \nu_{l}} - \tan \Phi_{l} \frac{\partial}{\partial \tau_{l}} \gamma_{l} w_{j,m} = 0 \quad \text{on } \Gamma_{l},$$

to the properties of the support of  $S_{j,m}$  and to the obvious fact that  $S_{i,m}(S_i) = 0$ .

Since  $\Delta \sigma_{j,m} = 0$  we have

$$\int_{\Omega} \Delta S_{i,m} \sigma_{i,m} \, \mathrm{d}x \, \mathrm{d}y = \int_{\Omega} \Delta S_{i,m} \psi_{i,m} \, \mathrm{d}x \, \mathrm{d}y - \int_{\Omega} S_{i,m} \Delta w_{i,m} \, \mathrm{d}x \, \mathrm{d}y. \tag{4.4.4.12}$$

Then, we cannot apply directly the Green formula to  $S_{i,m}$  and  $\psi_{i,m}$  because  $\psi_{i,m}$  is singular at  $S_i$ . Thus, we are led to introduce

$$\Omega' = \Omega \cap \{r_i > \rho\},\,$$

where  $\rho$  is chosen such that  $\eta_i(re^{i\theta}) = 1$  for  $r < \rho$ . Since the support of  $\Delta S_{i,m}$  is contained in  $\Omega'$ , we have

$$\int_{\Omega} \Delta S_{j,m} \psi_{j,m} \, dx \, dy = \int_{\Omega'} \Delta S_{j,m} \psi_{j,m} \, dx \, dy.$$

We can now apply the classical Green formula in  $\Omega'$ , since both  $\sigma_{i,m}$  and  $\psi_{i,m}$  are smooth in  $\bar{\Omega}'$ .

Let us denote by  $\Gamma'_l$  the intersection of  $\Gamma_l$  with  $\partial\Omega'$  and set

$$\gamma = \{ r_i e^{i\theta_i} | r_i = \rho, \qquad 0 < \theta_i < \omega_i \}.$$

We have

$$\begin{split} & \int_{\Omega'} \Delta S_{i,m} \psi_{j,m} \, dx \, dy - \int_{\Omega'} S_{j,m} \, \Delta \psi_{j,m} \, dx \, dy \\ & = \sum_{l=1}^{N} \int_{\Gamma'_{i}} \left[ \frac{\partial S_{i,m}}{\partial \nu_{l}} \psi_{j,m} - S_{j,m} \frac{\partial \psi_{i,m}}{\partial \nu_{l}} \right] d\sigma - \int_{\gamma} \left[ \frac{\partial S_{j,m}}{\partial r_{j}} \psi_{j,m} - S_{j,m} \frac{\partial \psi_{j,m}}{\partial r_{j}} \right] d\sigma \\ & = -\sum_{l=1}^{N} \tan \Phi_{l} \left( S_{j,m} \psi_{j,m} \, \Big|_{A_{l}}^{B_{l}} \right) - \mathcal{J} \end{split}$$

due to the boundary conditions on  $S_{i,m}$  and on  $\psi_{i,m}$ , i.e.

$$\gamma_l \frac{\partial \psi_{j,m}}{\partial \nu_l} - \tan \Phi_l \frac{\partial}{\partial \tau_l} \gamma_l \psi_{j,m} = 0 \quad \text{on } \Gamma_l.$$

Here we denote by  $A_l$  the origin of  $\Gamma'_l$  and by  $B_l$  the endpoint of  $\Gamma'_l$ , according to the positive orientation. We have also set

$$\mathscr{I} = \int_{\gamma} \left[ \frac{\partial S_{i,m}}{\partial r_i} \psi_{i,m} - S_{i,m} \frac{\partial \psi_{i,m}}{\partial r_i} \right] d\sigma.$$

Due to the properties of the supports of  $S_{i,m}$  and  $\psi_{i,m}$ , it turns out that

$$\int_{\Omega} \Delta S_{j,m} \psi_{j,m} \, dx \, dy - \int_{\Omega} S_{j,m} \, \Delta \psi_{j,m} \, dx \, dy$$

$$= \tan \Phi_{j+1} \frac{\cos^2 \Phi_{j+1}}{\omega_j \lambda_{j,m}^2} - \tan \Phi_j \frac{\cos^2 \Phi_j}{\omega_j \lambda_{j,m}^2} + \mathcal{I}. \tag{4,4,4,13}$$

Finally, we calculate  $\mathcal{I}$  explicitly. This is elementary, and we get

$$\mathcal{J} = \frac{1}{\lambda_{j,m}} + \frac{\sin \Phi_j \cos \Phi_j - \sin \Phi_{j+1} \cos \Phi_{j+1}}{\omega_j \lambda_{j,m}^2}.$$
 (4,4,4,14)

The identity (4,4,4,11) follows plainly from identities (4,4,4,12) to (4.4.4.14).

**Corollary 4.4.4.11** Assume that the hypotheses of Theorem 4.4.4.8 are fulfilled. Then for each  $f \in L_p(\Omega)$  such that  $\int_{\Omega} f \, dx \, dy = 0$ , there exist real numbers  $c_{i,m}$  and a function u such that

$$u - \sum_{\substack{1 \leq j \leq N \\ -2/q < N, m < 0 \\ \lambda, m \neq -1}} c_{j,m} S_{j,m} \in W_p^2(\Omega)$$

and u is a solution of problem (4,1,1).

**Proof** This is a simple consequence of the fact that  $L_p(\Omega)$  is the space spanned by the annihilator of  $N_q$ , the constant functions and the functions  $\Delta S_{i,m}$  corresponding to the eigenvalues such that

$$-\frac{2}{q} < \lambda_{j,m} < 0, \qquad \lambda_{j,m} \neq -1.$$

Clearly these functions are linearly independent (this follows from their explicit definition in identity (4,4,3,7)), do not belong to the annihilator of  $N_q$  by Lemma 4.4.4.10 and span a subspace of  $L_p(\Omega)$  whose dimension is suitable by Theorem 4.4.4.8.

Replacing Theorem 4.4.4.8 by Theorem 4.4.4.9, we obtain the following statement.

**Corollary 4.4.4.12** Assume that the hypotheses of Theorem 4.4.4.9 are fulfilled. Then for each  $f \in L_p(\Omega)$  there exist real numbers  $c_{i,m}$  and a function u such that

$$u - \sum_{\substack{1 \le j \le N \\ -2/q < \lambda_{j,m} < 0 \\ \lambda_{i,m} \neq -1}} c_{j,m} S_{j,m} \in W_p^2(\Omega)$$

and u is a solution of problem (4,1,1).

Now with the help of Theorems 4.4.3.7 and Corollaries 4.4.4.11 and 4.4.4.12, we reach our final goal.

**Theorem 4.4.4.13** We assume that  $(\Phi_j - \Phi_{j+1} + 2\omega_j/q)/\pi$  is not an integer for any j. Then for each  $f \in L_p(\Omega)$  (such that  $\int_{\Omega} f \, dx \, dy = 0$  when  $\mathcal{D}$  is empty) there exist real numbers  $c_{j,m}$  and a function u (possibly non-unique) such that

$$u - \sum_{\substack{1 \leq j \leq N \\ -2/q < \lambda_{j,m} \leq 0 \\ \lambda_{i,m} \neq -1}} c_{j,m} S_{j,m} \in W_p^2(\Omega)$$

and u is the solution of problem (4,1,1).

**Proof** We start from one solution  $u \in H^1(\Omega)$  to problem (4,1,1); such a solution exists by Lemma 4.4.4.2. Then we study locally the behaviour of u. Since we have

$$\Delta u \in L_p(\Omega)$$
,

it follows plainly that  $\eta u \in W_p^2(\Omega)$  for every  $\eta \in \mathcal{D}(\Omega)$ . This describes the smoothness of u inside  $\Omega$ .

Then let us look at the behaviour of u near the regular points of the boundary. For that purpose we let  $\eta \in \mathcal{D}(\bar{\Omega})$  have a support which does not meet  $\bar{\Gamma}_l$  for  $l \neq j$ . Since  $u \in H^1(\Omega)$ , we have

$$\Delta \eta u \in L_p(\Omega) + L_2(\Omega)$$

and

$$\bigg(\gamma_{i}\frac{\partial}{\partial\nu_{i}}+\beta_{i}\frac{\partial}{\partial\tau_{i}}\gamma_{i}\bigg)\eta u=\bigg(\frac{\partial\eta}{\partial\nu_{i}}+\beta_{i}\frac{\partial\eta}{\partial\tau_{i}}\bigg)\gamma_{i}u\in H^{1/2}(\Gamma_{i})+W_{\mathfrak{p}}^{1-1/p}(\Gamma_{i}).$$

Choosing a plane open subset  $\Omega'$  with a  $C^{1,1}$  boundary such that  $\partial \Omega' \supseteq \Gamma_j$  and such that  $\bar{\Omega}'$  contains the support of  $\eta$ , we see that

$$\begin{cases} \Delta\widetilde{\eta u} \in L_p(\Omega') + L_2(\Omega') \\ \left(\gamma \frac{\partial}{\partial \nu} + \beta_i \frac{\partial}{\partial \tau} \gamma\right) \eta u \in H^{1/2}(\partial \Omega') + W_p^{1-1/p}(\partial \Omega') \end{cases}$$

Therefore, we have  $\eta u \in H^2(\Omega) + W_p^2(\Omega)$  by Theorem 2.4.1.3. Varying  $\eta$  this shows that  $u \in H^2(\Omega \setminus V) + W_p^2(\Omega \setminus V)$ , where V is any closed neighbourhood of the corners of  $\Omega$ . Accordingly, it follows that

$$\left(\gamma \frac{\partial}{\partial \nu} + \beta_j \frac{\partial}{\partial \tau} \gamma\right) \widetilde{\eta} \widetilde{u} \in H^{3/2}(\partial \Omega') \subset W_p^{1-1/p}(\partial \Omega').$$

Applying again Theorem 2.4.1.3, we see that  $\eta u \in W_p^2(\Omega)$ . Varying  $\eta$  this shows that

$$u \in W_p^2(\Omega \setminus V)$$
.

Finally, let us study the behaviour of u near one of the corners, say  $S_1$ . We shall use one of the model problems studied before. For that purpose we introduce new boundary conditions on  $\Gamma_i$ ,  $3 \le i \le N$ , as follows:

First case  $1 \in \mathcal{D}$  or  $2 \in \mathcal{D}$ : we set

$$L_i = I, \quad j = 3, \ldots, N.$$

Second case 1 and  $2 \in \mathcal{N}$ ,  $\tan \Phi_1 > \tan \Phi_2$ : we set

$$L_j = \frac{\partial}{\partial \nu_j} + \tan \Phi'_j \frac{\partial}{\partial \tau_j}, \quad j = 3, \dots, N$$

with  $\tan \Phi_2 \le \tan \Phi'_i \le \tan \Phi'_{i+1} \le \cdots \le \tan \Phi_1$ ,  $j = 3, \ldots, N$ .

Third case 1 and  $2 \in \mathcal{N}$ ,  $\tan \Phi_1 \leq \tan \Phi_2$ : we set

$$L_i = I, \quad j = 3, \ldots, N.$$

In all cases, we have  $\eta_1 u \in H^1(\Omega)$  and

$$\begin{cases} \Delta \eta_1 u \in L_p(\Omega) \\ \gamma_i L_j \eta_1 u = 0 & \text{on } \Gamma_j, \quad 3 \leq j \leq N \\ \gamma_j \eta_1 u = 0 & \text{on } \Gamma_j, \quad j \in \mathcal{D} \cap \{1, 2\} \\ \gamma_j \frac{\partial \eta_1 u}{\partial \nu_j} + \tan \Phi_j \frac{\partial}{\partial \tau_j} \gamma_i \eta_1 u = 0 & \text{on } \Gamma_j, \quad j \in \mathcal{N} \cap \{1, 2\}. \end{cases}$$

This is a problem that we have already solved in Theorem 4.4.3.7 in the first case, Corollary 4.4.4.11 in the second case and in Corollary 4.4.4.12 in the third case. Accordingly, there exists  $v \in H^1(\Omega)$  and constants  $c_{1,m}$  such that

$$v - \sum_{\substack{-2/q < \lambda_{1,m} < 0 \\ \lambda_{1,m} \neq -1}} c_{1,m} S_{1,m} \in W_p^2(\Omega \cap V)$$
(4,4,4,15)

where V is a neighbourhood of  $S_1$  and v is the solution of the same problem as  $\eta_1 u$ . In other words, we have

$$\begin{cases} \eta_{1}u - v \in H^{1}(\Omega) \\ \Delta(\eta_{1}u - v) = 0 & \text{in } \Omega \\ \gamma_{i}(\eta_{1}u - v) = 0 & \text{on } \Gamma_{i}, \quad j \in \mathcal{D} \cap \{1, 2\} \\ \left(\gamma_{i}\frac{\partial}{\partial \nu_{i}} + \tan \Phi_{i}\frac{\partial}{\partial \tau_{i}}\gamma_{i}\right)(\eta_{1}u - v) = 0 & \text{on } \Gamma_{i}, \quad j \in \mathcal{N} \cap \{1, 2\}. \end{cases}$$

The last step is to apply Theorem 4.4.2.4 to  $\eta_1 u - v$ . This shows that  $\eta_1 u - v$  can be expanded as follows near zero:

$$\eta_1 u - v = \sum_{\lambda_{1,m} < 0} \frac{c_m}{\sqrt{\omega_1}} \frac{r_1^{-\lambda_{1,m}}}{\lambda_{1,m}} \cos(\lambda_{1,m} \theta_1 + \Phi_2) + \mathcal{K},$$

where

$$|c_m| \leq L |m|^{1/q} \rho^{\lambda_{1,m}}$$

for some L and  $\rho$ . Consequently, we have

$$\eta_1 u - v - \sum_{\substack{-2/q < \lambda_{1,m} < 0 \\ \lambda_{1,m} \neq -1}} c_m S_{1,m} \in W_p^2(\Omega \cap V). \tag{4,4,4,16}$$

Adding (4,4,4,15) and (4,4,4,16) we see that

$$\eta_1 u - \sum_{\substack{2/q < \lambda_{1,m} < 1 \\ \lambda_{1,m} \neq -1}} (c_m + c_{1,m}) S_{1,m} \in W_p^2(\Omega \cap V).$$

A similar result holds for  $\eta_i u$  near  $S_i$  for each j and this completes the proof of Theorem 4.4.4.13.

We conclude with a statement concerning the nonhomogeneous boundary value problem.

**Corollary 4.4.4.14** Under the assumptions of Theorem 4.4.4.13, let  $f \in L_p(\Omega)$  and  $g_i \in W_p^{2-1/p}(\Gamma_i)$ ,  $j \in \mathcal{D}$  and  $g_i \in W_p^{1-1/p}(\Gamma_i)$ ,  $j \in \mathcal{N}$  be given such that

$$g_{i}(S_{j}) = \frac{\partial g_{i+1}}{\partial \mu_{i}}(S_{i})$$
 if  $j \in \mathcal{N}$  and  $j+1 \in \mathcal{D}$ 

or

$$g_{j+1}(S_i) = \frac{\partial g_j}{\partial \mu_{j+1}}(S_i)$$
 if  $j \in \mathcal{D}$  and  $j+1 \in \mathcal{N}$ 

or

$$g_{j+1}(S_j) = \frac{\mu_j \cdot \mu_{j+1}}{|\mu_{j+1}|^2} g_j(S_j) \quad \text{if } j \in \mathcal{N} \quad \text{and} \quad j+1 \in \mathcal{N}$$

whenever  $\mu_j$  is parallel to  $\mu_{j+1}$  p>2, and  $g_j(S_j)=g_{j+1}(S_j)$  if  $j\in \mathcal{D}$  and  $j+1\in \mathcal{D}$ . Then there exists a function u and numbers  $c_{j,m}$  (possibly non-unique) such that

$$u - \sum_{\substack{1 \leq j \leq N \\ -2/q < \lambda_{j,m} < 0 \\ \lambda_{j,m} \neq -1}} c_{j,m} S_{j,m} \in W_p^2(\Omega)$$

and u is solution of problem (4,1,1).

Remark 4.4.4.15 In this whole chapter we have excluded the domains with cuts (i.e.  $\omega_i = 2\pi$  for some j) for simplicity. However, if we allow cuts, the basic a priori inequality of Section 4.3 remains valid (see Remarks 4.3.1.7 and 4.3.2.7). The main tool in Section 4.4 has been the

Green formula in a Lipschitz domain. To handle domains with cuts requires derivation of the corresponding Green formula. This can be achieved by using the trick, described at the beginning of Section 1.7, of considering separately the restrictions of the functions to  $\Omega_+$  and  $\Omega_-$ . Accordingly the results of Theorem 4.4.4.13 and Corollary 4.4.4.14 hold for domains with cuts (i.e. if we allow  $\omega_i = 2\pi$  in the statements).

Remark 4.4.4.16 In the particular case of self-adjoint boundary conditions (i.e. either Dirichlet or Neumann) along a cut the results mentioned above may be easily deduced from the Theorem 4.4.4.13. Indeed, to make an example, let us assume that  $\omega_j = 2\pi$  and  $j, j+1 \in \mathcal{D}$ . Then by looking at the problem locally one can assume that  $\Omega$  is symmetric with respect to  $\Gamma_j$ . A rotation and a translation reduce the problem to the particular case when  $S_j = 0$  and  $\Gamma_j$  together with  $\Gamma_{j+1}$  lie on the positive x-axis.

Now let us write u as the sum of an even function  $u_e$  and an odd function  $u_0$  with respect to y:

$$u_e(x, y) = \frac{u(x, y) + u(x, -y)}{2}, \qquad u_0(x, y) = \frac{u(x, y) - u(x, -y)}{2}.$$

Assuming that  $f \in L_p(\Omega)$ ,  $g_i = 0$  and  $g_{i+1} = 0$  imply that  $u_0$  fulfils a homogeneous Dirichlet on the axis y = 0 in a neighbourhood of O. Therefore we have

$$u_0 \in W_p^2(V \cap \Omega),$$
 (4,4,4,17)

where V is a suitable neighbourhood of O. In the same way  $u_{\epsilon}$  fulfils a homogeneous mixed boundary condition near O:

$$\begin{cases} u_e(x, 0) = 0, & 0 < x < \delta \\ D_y u_e(x, 0) = 0, & -\delta < x < 0 \end{cases}$$

for some  $\delta > 0$ . Accordingly, by Theorem 4.4.4.13 there exist constants  $c_{i,m}$  such that

$$u_e - \sum_{1/2 - 2/q < m < 1/2} c_{j,m} r_j^{-m+1/2} \sin\left(m - \frac{1}{2}\right) \theta_j \in W_p^2(V \cap \Omega). \tag{4,4,4,18}$$

By adding (4,4,4,17) and (4,4,4,18) we obtain the behaviour of u near 0. This is an alternative proof of the results stated in Remark 4.4.4.15. The same method allows one to handle the following cases:

$$\begin{cases} \omega_{j} = 2\pi, & j \in \mathcal{D}, \quad j+1 \in \mathcal{N} \quad \text{or} \quad j \in \mathcal{N}, \quad j+1 \in \mathcal{D} \\ \omega_{j} = 2\pi, & j \in \mathcal{N}, \quad j+1 \in \mathcal{N}. \end{cases}$$

## More singular solutions

#### 5.1 Behaviour of the derivatives of order higher than two

In this section, we look for  $u \in W_p^{k+2}(\Omega)$ , where k is a nonnegative integer, which are solutions of the same boundary value problems as in Chapter 4. However, we shall also consider non-homogeneous boundary conditions. In other words, we shall try to find necessary and sufficient conditions on the functions f and  $g_j$ ,  $1 \le j \le N$ , ensuring that the following problem should have a solution u belonging to  $W_p^{k+2}(\Omega)$ :

$$\begin{cases} \Delta u = f & \text{in } \Omega \\ \gamma_{j} u = g_{j} & \text{on } \Gamma_{j}, \quad j \in \mathcal{D} \end{cases}$$

$$\begin{cases} \gamma_{i} \frac{\partial u}{\partial \nu_{j}} + \beta_{i} \frac{\partial}{\partial \tau_{j}} \gamma_{i} u = g_{i} & \text{on } \Gamma_{i}, \quad j \in \mathcal{N}. \end{cases}$$

$$(5,1,1)$$

Here we keep the notation of Chapter 4.

Some necessary conditions are obvious. Indeed, if there exists  $u \in W_p^{k+2}(\Omega)$  which is a solution of (5,1,1) we must have

$$\begin{split} &f\in W^k_p(\Omega),\\ &g_j\in W^{k+2-1/p}_p(\Gamma_j),\quad j\in\mathcal{D} \qquad\text{and}\qquad g_j\in W^{k+1-1/p}_p(\Gamma_j),\quad j\in\mathcal{N}. \end{split}$$

In addition, we must have

(a) 
$$g_j(S_j) = g_{j+1}(S_j)$$
, if  $j$  and  $j+1 \in \mathcal{D}$  (5,1,2)

(b) 
$$\frac{\partial g_j}{\partial \mu_{j+1}}(S_j) = g_{j+1}(S_j)$$
 if  $j \in \mathcal{D}$ ,  $j+1 \in \mathcal{N}$ ,  $\mu_{j+1}$  is parallel to  $\tau_j$  and  $k+1 > (2/p)$ 

(c) 
$$g_j(S_j) = \frac{\partial g_{j+1}}{\partial \mu_j}(S_j)$$
 if  $j \in \mathcal{N}, j+1 \in \mathcal{D}, \mu_j$  is parallel to  $\tau_{j+1}$  and  $k+1 > (2/p)$ 

(d) 
$$g_j(S_j) = \lambda^{-1}g_{j+1}(S_j)$$
 if  $j$  and  $j+1 \in \mathcal{N}$ ,  $\mu_j = \lambda \mu_{j+1}$  and  $k+1 > (2/p)$ .

(When p = 2 and k + 1 = 1, the pointwise conditions in (b)-(d) must be replaced by the corresponding conditions with integrals.)

As we saw in Chapter 4 in the particular case when k=0, some additional orthogonality conditions occur. They were the orthogonality of f to the space  $N_q$ . Here we shall find many more orthogonality conditions of the same nature when k is  $\geq 1$ . However, for several special values of the measure of the angles of  $\Omega$ , we shall find additional conditions which generalize (5,1,2). This makes the study of higher derivatives of u a lot more difficult than the study of the second derivatives that we carried out in Chapter 4.

The technique that we shall use here is mainly based on the following idea. We shall extensively use the trace theorems of Chapter 1 to reduce the general problem (5,1,1) to the particular case when  $g_i = 0$  for every j and  $f \in \mathring{W}_p^k(\Omega)$ . In this particular case, the given function f fulfils a lot of unnatural homogeneous boundary conditions. However, due to these boundary conditions on f, it turns out that the derivatives up to the order k of the corresponding solution u are solutions of boundary value problems for the Laplace operator of the same kind as (4,1,1). Accordingly, we shall take advantage of the results proven in Chapter 4 to find the behaviour of these derivatives of u near the corners.

#### 5.1.1 Special data

Let us look in a first step, at  $u \in W_p^2(\Omega)$  which is a solution of (5,1,1) under the assumption that  $g_j = 0$  for every j and that  $f \in \mathring{W}_p^1(\Omega)$ . In other words we have

$$\begin{cases} \Delta u = f & \text{in } \Omega \\ \gamma_{i}u = 0 & \text{on } \Gamma_{j}, \quad j \in \mathcal{D} \end{cases}$$

$$(5,1,1,1)$$

$$\begin{cases} \gamma_{i}\frac{\partial u}{\partial \nu_{i}} + \beta_{j}\frac{\partial}{\partial \tau_{i}} \gamma_{i}u = 0 & \text{on } \Gamma_{j}, \quad j \in \mathcal{N}. \end{cases}$$

We already know that u is smoother far from the corners.

**Lemma 5.1.1.1** Let  $u \in W_p^2(\Omega)$  be the solution of problem (5,1,1,1) with f given in  $W_p^1(\Omega)$ ; then we have

$$u \in W^3_p(\Omega \setminus V)$$

for every closed neighbourhood V of the corners of  $\Omega$ .

Proof First let 
$$\eta \in \mathcal{D}(\Omega)$$
; we have 
$$-\Delta(\widetilde{\eta u}) + \widetilde{\eta u} = -\widetilde{\eta f} - [\Delta; \eta]u + \widetilde{\eta u} \in W_0^1(\mathbb{R}^2)$$

and  $\widetilde{\eta u} \in W^2_p(\mathbb{R}^2)$ . Accordingly

$$\widetilde{\eta u} = E * \{ -\widetilde{\eta f} - [\Delta; \eta] u + \widetilde{\eta u} \}$$

where E is the elementary solution of  $-\Delta + 1$  defined by

$$FE(\xi) = [1 + |\xi|^2]^{-1}, \quad \xi \in \mathbb{R}^2.$$

Then Theorem 2.3.2.1 shows that  $\eta u \in W_p^3(\Omega)$ .

Now let  $\eta \in \mathfrak{D}(\bar{\Omega})$  be such that the support of  $\eta$  meets only the interior of one side,  $\Gamma_i$  say. Then let  $\omega$  be any plane open set with smooth boundary such that  $\bar{\omega}$  contains the support of  $\eta$  and  $\Gamma \cap \partial \omega \subseteq \Gamma_i$ . With the obvious modification when  $j \in \mathfrak{D}$ , we have

$$\begin{cases} \Delta \widetilde{\eta u} = \widetilde{\eta f} + \widetilde{[\Delta; \eta]u} \in W_p^1(\omega) \\ \gamma \frac{\partial \widetilde{\eta u}}{\partial \nu} + \beta_i \frac{\partial}{\partial \tau} \gamma \widetilde{\eta u} = \left(\frac{\partial \eta}{\partial \nu} + \beta_i \frac{\partial \eta}{\partial \tau}\right) \gamma u \in W_p^{1-1/p}(\partial \omega) \end{cases}$$

and it follows from Theorem 2.5.1.1 that

$$\widetilde{\eta u} \in W^3_p(\omega)$$
.

The claim of Lemma 5.1.1.1 follows by partition of unity on  $\Omega \setminus V$ .

Now we consider any unit vector  $\lambda = (\alpha; \beta)$  and the corresponding derivative of u, i.e.

$$v = \frac{\partial u}{\partial \lambda} = \alpha D_{x} u + \beta D_{y} u.$$

This is obviously a function belonging to  $W^1_p(\Omega)$  which is a solution of

$$\Delta v = \frac{\partial f}{\partial \lambda} \in L_p(\Omega).$$

The boundary conditions on v are the following.

**Lemma 5.1.1.2** Assume that  $u \in W_p^2(\Omega)$  is the solution of problem (5,1,1,1) with f given in  $\mathring{W}_p^1(\Omega)$ . Let  $\chi_i$  be the angle from  $\tau$  to  $\lambda$ ; then

$$\gamma_{i} \frac{\partial v}{\partial \nu_{i}} + \tan \left( \Phi_{i} - \chi_{i} \right) \frac{\partial}{\partial \tau_{i}} \gamma_{i} v = 0 \qquad on \Gamma_{i}$$
(5,1,1,2)

when  $(\Phi_i - \chi_i)/\pi - \frac{1}{2}$  is not an integer, and

$$\gamma_i v = 0$$
 on  $\Gamma_i$  (5,1,1,2')

when  $(\Phi_i - \chi_i)/\pi - \frac{1}{2}$  is an integer.

Proof By possibly performing a rotation of the coordinate axes, we can

assume that  $\Gamma_i$  is supported by the axis  $\{y = 0\}$  and that  $\Omega$  is 'above'  $\Gamma_i$ . Accordingly we have

$$\tau_i = (1,0), \quad \nu_i = (0,-1)$$

and the boundary condition for u on  $\Gamma_i$  is

$$-(\cos \Phi_i)\gamma_i D_y u + (\sin \Phi_i) D_x \gamma_i u = 0. \tag{5.1.1.3}$$

Differentiating with respect to x, we get

$$-(\cos \Phi_i)D_x \gamma_i D_y u + (\sin \Phi_i)D_x^2 \gamma_i u = 0.$$
 (5,1,1,4)

On the other hand, the assumption that  $f \in \mathring{W}^{1}_{p}(\Omega)$  implies that

$$\gamma_i f = \gamma_i D_y^2 u + D_x^2 \gamma_i u = 0. (5,1,1,5)$$

From the definition of  $\chi_i$  it follows that

$$v = (\cos \chi_i) D_x u + (\sin \chi_i) D_y u.$$

Accordingly, we have

$$\gamma_i \frac{\partial v}{\partial \nu_i} = -(\cos \chi_i) D_x \gamma_i D_y u - (\sin \chi_i) \gamma_i D_y^2 u$$

$$\gamma_i \frac{\partial v}{\partial \tau_i} = (\cos \chi_i) D_x^2 \gamma_i u + (\sin \chi_i) D_x \gamma_i D_y u$$

and finally

$$\cos (\Phi_{i} - \chi_{i}) \gamma_{i} \frac{\partial v}{\partial \nu_{i}} + \sin (\Phi_{i} - \chi_{i}) \frac{\partial}{\partial \tau_{i}} \gamma_{i} v$$

$$= -(\cos \Phi_{i}) D_{x} \gamma_{i} D_{y} u - \sin \chi_{i} \cos (\Phi_{i} - \chi_{i}) \gamma_{i} D_{y}^{2} u$$

$$+ \cos \chi_{i} \sin (\Phi_{i} - \chi_{i}) D_{x}^{2} \gamma_{i} u.$$

Using (5,1,1,5), we deduce that

$$\cos (\Phi_{i} - \chi_{j}) \gamma_{i} \frac{\partial v}{\partial \nu_{i}} + \sin (\Phi_{i} - \chi_{j}) \frac{\partial}{\partial \tau_{i}} \gamma_{i} v$$

$$= -(\cos \Phi_{i}) D_{x} \gamma_{i} D_{y} u + (\sin \Phi_{i}) D_{x}^{2} \gamma_{i} u;$$

this last expression is zero by (5,1,1,4). This is the desired result when  $(\Phi_j - \chi_j)/\pi - \frac{1}{2}$  is not an integer. Otherwise we have

$$\cos \chi_i = \varepsilon \sin \Phi_i$$
,  $\sin \chi_i = -\varepsilon \cos \Phi_i$ 

where  $\varepsilon$  is either +1 or -1. Accordingly, we have

$$\gamma_i v = \varepsilon \{ (\sin \Phi_i) D_x \gamma_i u - (\cos \Phi_i) \gamma_i D_y u \}$$

and this is zero due to (5,1,1,3).

We are now able to apply the results of Chapter 4. However, a side difficulty arises here. We shall not be able to apply Theorem 4.4.4.13 because of the possible non-uniqueness in that statement. Accordingly, we shall try to make use of Theorem 4.4.3.7, which deals with variational problems only. This is why we first have to localize our problem.

For this purpose, we introduce a cut-off function related to  $S_i$  as follows:  $\eta_i \in \mathcal{D}(\bar{\Omega})$ ,  $\eta_i$  is one near  $S_i$ , the support of  $\eta_i$  does not meet  $\bar{\Gamma}_t$  for  $l \neq j, j+1$  and

$$\frac{\partial \eta_i}{\partial \nu_{i+1}} + \tan\left(\Phi_{i+1} - \Phi_i - \frac{\pi}{2} - \omega_i\right) \frac{\partial \eta_i}{\partial \tau_{i+1}} = 0 \tag{5.1.1.6}$$

if  $(\Phi_{i+1} - \Phi_i - \omega_i)/\pi$  is not an integer.

Then we look at

$$v_i = \frac{\partial u}{\partial \mu_i} ;$$

in other words, we choose  $\lambda = \mu_i/|\mu_i|$  in order to study the behaviour of u near  $S_i$ . By Lemma 5.1.1.2, we have (the boundary condition is plainly  $\gamma_{i+1}v_i = 0$  on  $\Gamma_{i+1}$  when  $(\Phi_{i+1} - \Phi_i - \omega_i)/\pi$  is an integer)

$$\begin{cases} \gamma_{i}v_{i} = 0 & \text{on } \Gamma_{i} \\ \gamma_{i+1} \frac{\partial v_{i}}{\partial \nu_{i+1}} + \tan\left(\Phi_{i+1} - \Phi_{i} - \frac{\pi}{2} - \omega_{i}\right) \frac{\partial}{\partial \tau_{i+1}} \gamma_{i+1}v_{i} = 0 & \text{on } \Gamma_{i+1}. \end{cases}$$

$$(5,1,1,7)$$

The boundary conditions on the other sides will not matter, since we finally introduce

$$w_i = \eta_i v_i$$

By Lemma 5.1.1.1 we know that  $w_i \in W^1_p(\Omega)$  and that

$$\Delta w_i = \eta_i \frac{\partial}{\partial \mu_i} f + [\eta_i, \Delta] v_i \in L_p(\Omega).$$

The boundary conditions on  $w_i$  follow from (5,1,1,6) and (5,1,1,7). Accordingly, we have (see the note preceding (5,1,1,7))

$$\begin{cases} \gamma_{l}w_{i} = 0 & \text{on } \Gamma_{l'} \quad l \neq j+1 \\ \gamma_{j+1} \frac{\partial w_{i}}{\partial \nu_{j+1}} + \tan \left( \Phi_{j+1} - \Phi_{j} - \frac{\pi}{2} - \omega_{j} \right) \frac{\partial}{\partial \tau_{j+1}} \gamma_{j+1}w_{j} = 0 & \text{on } \Gamma_{j+1}. \end{cases}$$

$$(5,1,1,8)$$

Assuming  $p \ge 2$  so that  $w_i \in H^1(\Omega)$ , it follows from Theorem 4.4.3.7

that there exist numbers  $c'_{i,m'}$  such that

$$w_{j} - \sum_{\substack{-2/q < \lambda'_{j,m'} < 0 \\ \lambda'_{i,m'} \neq -1}} c'_{j,m'} s'_{j,m'} \in W_{p}^{2}(V_{j})$$
(5,1,1,9)

where  $V_i$  is a neighbourhood of  $S_i$  in  $\Omega$  and

$$\begin{split} &\lambda_{i,m'}' = \frac{\Phi_i - \Phi_{i+1} + m'\pi}{\omega_i} + 1, \\ &S_{i,m'}' = \frac{r_i^{-\lambda'_{i,m'}}}{(\sqrt{\omega_i})\lambda'_{i,m'}} \cos\left(\lambda'_{i,m}\theta_i + \Phi_{i+1} - \Phi_i - \frac{\pi}{2} - \omega_i\right) \eta_i(r_i e^{i\theta_i}). \end{split}$$

This holds provided  $\lambda'_{i,m'} \neq -2/q$  for all m.

We can now easily derive the following result.

**Proposition 5.1.1.3** Let  $u \in W_p^2(\Omega)$  be the solution of problem (5,1,1,1). Assume that  $f \in \mathring{W}_p^1(\Omega)$  and  $p \ge 2$ . Then there exist real numbers  $C_{j,m}$  such that

$$u - \sum_{\substack{-1 - 2/q < \lambda_{i,m} < -1 \\ \lambda_{i,m} \neq -2}} C_{i,m} S_{i,m} \in W_p^3(V_j)$$
 (5,1,1,10)

where  $V_i$  is a neighbourhood of  $S_i$  and  $\lambda_{i,m} = (\Phi_{i+1} - \Phi_i + m\pi)/\omega_i$  (m an integer),

$$S_{j,m} = \frac{r_j^{-\lambda_{j,m}}}{(\sqrt{\omega_i})\lambda_{j,m}} \cos(\lambda_{j,m}\theta_j + \Phi_{j+1})$$

provided  $\lambda_{j,m} \neq -1-2/q$  for all m.

**Proof** We merely integrate (5,1,1,9). Indeed  $w_i$  coincides with  $\partial u/\partial \mu_i$  near  $S_i$ . We can rewrite (5,1,1,9) as follows:

$$\frac{\partial}{\partial \mu_{j}} \left( u - \sum_{\substack{-1 - 2/q < \lambda_{j,m} < -1 \\ \lambda_{j,m} \neq -2}} C_{j,m} S_{j,m} \right) \in W_{p}^{2}(V_{j}), \tag{5,1,1,11}$$

for some real numbers  $C_{i,m}$ . Then let us consider any vector  $\xi_i$  orthogonal to  $\mu_i$  and having the same length  $l = |\mu_i|$ . We shall show that

$$\frac{\partial}{\partial \xi_{i}} \left( u - \sum_{\substack{-1-2/q < \lambda_{i,m} < -1 \\ j \neq -2}} C_{j,m} S_{j,m} \right) \in W_{p}^{2}(V_{j}). \tag{5,1,1,12}$$

Indeed, let us set

$$\psi = u - \sum_{\substack{-1-2/q < \lambda_{j,m} < -1 \\ \lambda_{j,m} \neq -2}} C_{j,m} S_{j,m}.$$

We already know from (5,1,1.11), that

$$\frac{\partial^{\alpha+\beta}\psi}{\partial\mu_{i}^{\alpha}\partial\xi_{i}^{\beta}} \in L_{p}(V_{i}) \tag{5.1,1,13}$$

for  $\alpha + \beta \le 3$ , provided  $\alpha \ge 1$ . We just need to check that

$$\frac{\partial^3 \psi}{\partial \xi_i^3} \in L_p(V_i),$$

since it is clear from the assumptions on u and the  $\lambda_{j,m}$  that  $\psi \in W_p^2(V_j)$  and accordingly  $\psi$ ,  $\partial \psi / \partial \xi_j$ ,  $\partial^2 \psi / \partial \xi_j^2 \in L_p(V_j)$ .

For this purpose we observe that

$$\Delta \psi = f \in W^1_p(V_i)$$

since  $S_{i,m}$  is harmonic near  $S_i$ . It follows that

$$\frac{\partial^3 \psi}{\partial \xi_i^3} = \frac{1}{l^2} \frac{\partial f}{\partial \xi_i} - \frac{\partial^3 \psi}{\partial \mu_i^2 \partial \xi_i} \in L_p(V_i)$$

due to (5,1,1,13). The claim (5,1,1,10) is an obvious consequence of (5,1,1,11) and (5,1,1,12).

We are now able to reach the main purpose of this subsection.

**Theorem 5.1.1.4** Let f be given in  $\mathring{W}_{p}^{1}(\Omega)$  with  $p \ge 2$  and  $\int_{\Omega} f \, dx \, dy = 0$  when  $\mathcal{D}$  is empty. Assume that  $(\Phi_{i} - \Phi_{i+1} + \omega_{i} + 2\omega_{i}/q)/\pi$  is not an integer for any j. Then there exists a function u (possibly non-unique) and numbers  $C_{i,m}$  such that

$$u - \sum_{\substack{-1 - 2/q < \lambda_{i,m} < 0 \\ \lambda_{i,m} \neq -1, -2}} C_{j,m} S_{j,m} \in W_p^3(\Omega)$$

and u is solution of problem (5,1,1,1).

**Proof** We can choose  $p_1 \ge p$  such that  $(\Phi_j - \Phi_{j+1} + 2\omega_j/q_1)/\pi$  is not an integer for any j where  $q_1$  is conjugate to  $p_1$ . Since  $f \in L_{p_1}(\Omega)$ , we can apply Theorem 4.4.4.13 with p replaced by  $p_1$ . Thus we know the existence of a function u and of numbers  $C_{j,m}$  such that

$$\psi = u - \sum_{\substack{1 \le j \le N \\ -2/q < \lambda_{j,m} \le 0 \\ \lambda_{i,m} \ne -1}} C_{j,m} S_{j,m} \in W_{p_1}^2(\Omega)$$

and u is solution of problem (5,1,1,1). Since the functions  $S_{i,m}$  are all solutions of the homogeneous problem corresponding to (5,1,1,1), we can apply Proposition 5.1.1.3 to  $\psi$  near each of the corners  $S_i$ . The smoothness of u far from the corners follows from Lemma 5.1.1.1.

Iterating the above procedure yields the following result.

**Theorem 5.1.1.5** Let f be given in  $\mathring{W}_{p}^{k}(\Omega)$  with  $p \ge 2$ . Assume that

$$\frac{\Phi_i - \Phi_{i+1} + k\omega_i + 2\omega_i/q}{\pi}$$

is not an integer for any j. Then there exists a function u (possibly non-unique) and numbers  $C_{i,m}$  such that

$$u - \sum_{\substack{-k-2/q < \lambda_{j,m} < 0 \\ \lambda_{i,m} \neq -1, -2, \dots, -k}} C_{j,m} S_{j,m} \in W_p^{k+2}(\Omega)$$

and u is solution of problem (5,1,1,1).

#### 5.1.2 A trace theorem

We now want to solve the general non-homogeneous boundary value problem (5,1,1). This will be achieved by reducing the general case to the particular case which we solved in Section 5.1.1. For this purpose we need to find the necessary and sufficient conditions on the functions  $f \in W_p^k(\Omega)$  and  $g_i \in W_p^{k+2-1/p}(\Gamma_i)$ ,  $j \in \mathcal{D}$ ,  $g_i \in W_p^{k+1-1/p}(\Gamma_i)$ ,  $j \in \mathcal{N}$  which ensure the existence of a function  $v \in W_p^{k+2}(\Omega)$  s.t.

$$\begin{cases} \gamma_{i}v = g_{j} & \text{on } \Gamma_{i}, \quad j \in \mathcal{D} \\ \gamma_{i}\frac{\partial v}{\partial \nu_{i}} + \beta_{j}\frac{\partial}{\partial \tau_{i}} \gamma_{i}v = g_{j} & \text{on } \Gamma_{i}, \quad j \in \mathcal{N} \end{cases}$$

$$(5,1,2,1)$$

and

$$\Delta v - f \in \mathring{W}^k_p(\Omega).$$

In other words, we are looking for a function v which fulfils the boundary conditions (5,1,2,1) and

$$\gamma_i \frac{\partial^l}{\partial \nu_i^l} \Delta u = \gamma_i \frac{\partial^l f}{\partial \nu_i^l} \quad \text{on } \Gamma_i, \quad 0 \le l \le k - 1$$
(5,1,2,2)

(see Remark 1.5.2.11). This trace problem will be solved with the help of Theorems 1.6.1.4 and 1.6.1.5 (and Remark 1.6.1.8).

In a first step let us define the operators  $B_{j,l}$ , which we shall need to apply Theorem 1.6.1.4. The first operator  $B_{j,1}$  will be either I when  $j \in \mathcal{D}$  or  $\partial/\partial \mu_i$  when  $j \in \mathcal{N}$ , while

$$B_{j,l} = \left(\frac{\partial}{\partial \nu_i}\right)^{l-2} \Delta, \qquad l = 2, \ldots, k+1.$$

Accordingly, the order of  $B_{i,1}$  is either zero or one, while the order of  $B_{i,l}$  is l, l = 2, ..., k+1. In order to be able to apply Theorem 1.6.1.4 we must find all the operators  $P_{i,l}$  and  $Q_{i+1,l}$  fulfilling condition (1,6,1,1).

Since we are dealing with a polygon (in the strict sense) and the operators  $B_{j,l}$  are homogeneous with constant coefficients, we can restrict ourselves to looking for operators  $P_{j,l}$  and  $Q_{j+1,l}$ , also homogeneous and with constant coefficients.

We shall first look for the operators  $P_{i,1}$  and  $Q_{i+1,1}$ . We must have (by 1,6,1,1))

$$P_{j,1}B_{j,1} - Q_{j+1,1}B_{j+1,1} = \sum_{l=2}^{k+1} \left\{ Q_{j+1,l} \left( \frac{\partial}{\partial \nu_{j+1}} \right)^{l-2} - P_{j,l} \left( \frac{\partial}{\partial \nu_{j}} \right)^{l-2} \right\} \Delta.$$
 (5,1,2,3)

We observe that

$$\sum_{l=2}^{k+1} Q_{j+1,l} \left( \frac{\partial}{\partial \nu_{j+1}} \right)^{l-2} \quad \text{and} \quad \sum_{l=2}^{k+1} P_{j,l} \left( \frac{\partial}{\partial \nu_{l}} \right)^{l-2}$$

can be any homogeneous differential operators of order d-2 when d is the order of both sides of (5,1,2,3). Indeed  $Q_{j+1,l}$  and  $P_{j,l}$  are tangential operators to  $\Gamma_{j+1}$  and  $\Gamma_j$  respectively. Accordingly, the identity (5,1,2,3) means that the symbol of

$$P_{j,1}B_{j,1}-Q_{j+1,1}B_{j+1,1}$$

can be divided by the symbol of  $\Delta$ .

Since  $P_{j,1}$  and  $Q_{j+1,1}$  are tangential to  $\Gamma_{j-1}$  and  $\Gamma_{j}$ , respectively, it turns out that

$$P_{j,1} = \begin{cases} a_j \left(\frac{\partial}{\partial \tau_j}\right)^d & \text{if } j \in \mathcal{D} \\ a_j \left(\frac{\partial}{\partial \tau_j}\right)^{d-1} & \text{if } j \in \mathcal{N} \end{cases}$$
 (5,1,2,4)

$$Q_{j+1,1} = \begin{cases} b_j \left(\frac{\partial}{\partial \tau_{j+1}}\right)^d & \text{if } j+1 \in \mathcal{D} \\ b_j \left(\frac{\partial}{\partial \tau_{j+1}}\right)^{d-1} & \text{if } j+1 \in \mathcal{N}. \end{cases}$$

$$(5,1,2,5)$$

**Lemma 5.1.2.1** There exists real numbers  $a_i$  and  $b_i$  s.t.  $P_{j,1}B_{j,1} - Q_{j+1,1}B_{j+1,1}$  can be divided by  $\Delta$  where  $P_{j,1}$  and  $Q_{j+1,1}$  are defined by (5,1,2,4) and (5,1,2,5) and such that

$$a_i^2 + b_i^2 \neq 0$$

iff  $(\Phi_{i+1} - \Phi_i - d\omega_i)/\pi$  is an integer.

**Proof** Let us look for instance at the particular case when both j and

j+1 belong to  $\mathcal{N}$ . Accordingly, we must be able to divide the symbol of

$$a_{i}\left(\frac{\partial}{\partial \tau_{i}}\right)^{d-1}\frac{\partial}{\partial \mu_{i}}-b_{i}\left(\frac{\partial}{\partial \tau_{i+1}}\right)^{d-1}\frac{\partial}{\partial \mu_{i+1}}$$

by the symbol of  $\Delta$ . Equivalently we must be able to divide the polynomial

$$a_{i}(-1)^{d-1}(x \cos \omega_{i} + y \sin \omega_{i})^{d-1}([-x \sin \omega_{i} + y \cos \omega_{i}] - \tan \Phi_{i}[x \cos \omega_{i} + y \sin \omega_{i}]) - b_{i}x^{d-1}(-y + \tan \Phi_{i+1}x) = p(x, y)$$

by  $x^2 + y^2$ . This means that  $x = \pm iy$  are roots of the polynomial p(x, y). Writing  $p(\pm iy, y) = 0$  leads to the following system of two equations in the two unknowns  $a_i$  and  $b_i$ :

$$a_{j}(-1)^{d-1}(\sin \omega_{j} \pm i \cos \omega_{j})^{d-1}([\cos \omega_{j} \mp i \sin \omega_{j}]$$
$$-\tan \Phi_{j}[\sin \omega_{j} \pm i \cos \omega_{j}]) - b_{j}(\pm i)^{d}(-1 \pm i \tan \Phi_{j+1}) = 0.$$

This system is equivalent to the following

$$a_i(-1)^{d-1}e^{\mp i\omega_i d}[1 \mp i \tan \Phi_i] + b_i[1 \mp i \tan \Phi_{i+1}] = 0.$$
 (5,1,2,6)

The determinant is proportional to

$$\begin{split} & e^{-i\omega_{i}d}(1-i\tan\Phi_{j})(1+i\tan\Phi_{j+1}) - e^{i\omega_{i}d}(1+i\tan\Phi_{j})(1-i\tan\Phi_{j+1}) \\ & = e^{-i\omega_{i}d}(1+\tan\Phi_{j}\tan\Phi_{j+1}+i[\tan\Phi_{j+1}-\tan\Phi_{j}]) \\ & - e^{i\omega_{i}d}(1+\tan\Phi_{j}\tan\Phi_{j+1}-i[\tan\Phi_{j+1}-\tan\Phi_{j}]) \\ & = (1+\tan\Phi_{j}\tan\Phi_{j+1})\{e^{-i\omega_{j}d}(1+i\tan[\Phi_{j+1}-\Phi_{j}]) \\ & - e^{+i\omega_{j}d}(1-i\tan[\Phi_{j+1}-\Phi_{j}])\} \\ & = (1+\tan\Phi_{j}\tan\Phi_{j+1})\frac{e^{-i\omega_{j}d}e^{i(\Phi_{j+1}-\Phi_{j})} - e^{+i\omega_{j}d}e^{-i(\Phi_{j+1}-\Phi_{j})}}{\cos[\Phi_{j+1}-\Phi_{j}]} \\ & = 2i(1+\tan\Phi_{j}\tan\Phi_{j+1})\frac{\sin[\Phi_{j+1}-\Phi_{j}-\omega_{j}d]}{\cos[\Phi_{j+1}-\Phi_{j}]}. \end{split}$$

Obviously this determinant is zero iff  $(\Phi_{j+1} - \Phi_j - \omega_j d)/\pi$  is an integer. Similar calculations yield to the same result when j or j+1 belong to  $\mathcal{D}$ . The system (5,1,2,6) is replaced by

$$a_i(-1)^{d-1}e^{\pm id\omega_i}[\pm i] - b_i[1 \mp i \tan \Phi_{i+1}] = 0$$
 (5,1,2,7)

when  $j \in \mathcal{D}$  and  $j+1 \in \mathcal{N}$ ,

$$a_i(-1)^{d-1}e^{\mp id\omega}[1\mp i\tan\Phi_i]\mp ib_i=0$$
 (5,1,2,8)

when  $j \in \mathcal{N}$  and  $j+1 \in \mathcal{D}$  and

$$a_i(-1)^d e^{\pm i d\omega_i} - b_i = 0 (5,1,2,9)$$

when j and  $j+1 \in \mathfrak{D}$ .

Remark 5.1.2.2 When the determinant is zero, the space of the solutions of the systems (5,1,2,6) to (5,1,2,9) is one-dimensional. We shall completely determine  $a_i$  and  $b_i$ , by assuming in addition that  $b_i = 1$ . Accordingly, we have (setting  $m = (\Phi_{i+1} - \Phi_i - \mathrm{d}\omega_i)/\pi$ ):

$$a_i = (-1)^d e^{i\omega_i d} \frac{1 - i \tan \Phi_{i+1}}{1 - i \tan \Phi_i} = (-1)^{d - m} \frac{\cos \Phi_i}{\cos \Phi_{i+1}}$$

when j and  $j+1 \in \mathcal{N}$ ,

$$a_i = (-1)^d e^{id\omega} i[1 - i \tan \Phi_{i+1}] = \frac{(-1)^{d+m}}{\cos \Phi_{i+1}}$$

when  $j \in \mathcal{D}$  and  $j+1 \in \mathcal{N}$ ,

$$a_i = (-1)^d e^{id\omega_i} \frac{-i}{[1 - i \tan \Phi_i]} = (-1)^{d+m} \cos \Phi_i$$

when  $j \in \mathcal{N}$  and  $j+1 \in \mathcal{D}$  and

$$a_i = (-1)^d e^{id\omega_i} = (-1)^{d+m}$$

when j and  $j+1 \in \mathfrak{D}$ .

Let us now introduce one more notation. We denote by  $R_{j,d}$  the differential operator (homogeneous and of order d-2: i.e.,  $R_{j,d}=0$  if d<2) s.t.

$$a_{i} \left(\frac{\partial}{\partial \tau_{i}}\right)^{d-1} \frac{\partial}{\partial \mu_{i}} - \left(\frac{\partial}{\partial \tau_{i+1}}\right)^{d-1} \frac{\partial}{\partial \mu_{i+1}} = R_{i,d} \Delta$$
 (5,1,2,10)

when j and  $j+1 \in \mathcal{N}$ ,

$$a_{i} \left(\frac{\partial}{\partial \tau_{i}}\right)^{d} - \left(\frac{\partial}{\partial \tau_{i+1}}\right)^{d-1} \frac{\partial}{\partial \mu_{i+1}} = R_{i,d} \Delta$$
 (5,1,2,11)

when  $j \in \mathcal{D}$  and  $j+1 \in \mathcal{N}$ ,

$$a_{i} \left(\frac{\partial}{\partial \tau_{i}}\right)^{d-1} \frac{\partial}{\partial \mu_{i}} - \left(\frac{\partial}{\partial \tau_{i+1}}\right)^{d} = R_{i,d} \Delta \tag{5.1,2,12}$$

when  $j \in \mathcal{N}$  and  $j+1 \in \mathcal{D}$ , and

$$a_{i} \left(\frac{\partial}{\partial \tau_{i}}\right)^{d} - \left(\frac{\partial}{\partial \tau_{i+1}}\right)^{d} = R_{i,d} \Delta \tag{5.1,2,13}$$

when j and  $j+1 \in \mathcal{D}$ . These identities are nothing but identity (1,6,1,1) in the particular case that we study here.

Accordingly, Theorem 1.6.1.4 implies the following result.

**Theorem 5.1.2.3** Assume  $p \neq 2$  and let  $f \in W_p^k(\Omega)$  and  $g_j \in \mathbb{R}$ 

 $W^{k+2-1/p}(\Gamma_j)$ ,  $j \in \mathcal{D}$ ,  $g \in W^{k+1-1/p}(\Gamma_j)$ ,  $j \in \mathcal{N}$  be given. Then there exists a solution  $v \in W_p^{k+2}(\Omega)$  of the boundary conditions (5,1,2,1) and (5,1,2,2) iff the following equalities hold:

$$a_{i} \frac{\partial^{d-1} g_{j}}{\partial \tau_{i+1}^{d-1}} (S_{j}) - \frac{\partial^{d-1} g_{j+1}}{\partial \tau_{i+1}^{d-1}} (S_{j}) = R_{j,d} f(S_{j})$$
 (5,1,2,14)

when i and  $i+1 \in \mathcal{N}$ ,

$$a_{i} \frac{\partial^{d} g_{i}}{\partial \tau_{i}^{d}}(S_{i}) - \frac{\partial^{d-1} g_{i+1}}{\partial \tau_{i+1}^{d-1}}(S_{i}) = R_{i,d} f(S_{i})$$
 (5,1,2,15)

when  $j \in \mathfrak{D}$  and  $j + 1 \in \mathcal{N}$ ,

$$a_{j} \frac{\partial^{d-1} g_{j}}{\partial \tau_{j}^{d-1}}(S_{j}) - \frac{\partial^{d} g_{j+1}}{\partial \tau_{j+1}^{d}}(S_{j}) = R_{j,d} f(S_{j})$$
 (5,1,2,16)

when  $j \in \mathcal{N}$  and  $j+1 \in \mathcal{D}$  and

$$a_i \frac{\partial^d g_i}{\partial \tau_i^d}(S_i) - \frac{\partial^d g_{i+1}}{\partial \tau_{i+1}^d}(S_i) = R_{i,d} f(S_i)$$
 (5,1,2,17)

when j and  $j+1\in \mathcal{D}$ , for all  $d\in [0, k+2/q[$  and j s.t.  $(\Phi_{j+1}-\Phi_j-d\omega_j)/\pi$  is an integer.  $(d\geq 1)$  when j or  $j+1\in \mathcal{N}$ .

Proof We just have rewritten the identity

$$P_{j,1}g_{j}(S_{j}) - Q_{j+1,1}g_{j+1}(S_{j}) = \sum_{l=2}^{k+1} Q_{j+1,l} \frac{\partial^{l-2}f}{\partial \nu_{j+1}^{l-2}}(S_{j}) - \sum_{l=2}^{k-1} P_{j,l} \frac{\partial^{l-2}f}{\partial \nu_{j}^{l-2}}(S_{j})$$

as

$$P_{i,1}g_i(S_i) - Q_{i+1,1}g_{i+1}(S_i) = R_{i,d}f(S_i)$$

for the corresponding value of d.

The similar result when p = 2 follows from Theorem 1.6.1.5.

**Theorem 5.1.2.4** Let  $f \in H^k(\Omega)$  and  $g_j \in H^{k+3/2}(\Gamma_j)$ ,  $j \in \mathcal{D}$ ,  $g_j \in H^{k+1/2}(\Gamma_j)$ ,  $j \in \mathcal{N}$  be given. Then there exists a solution  $v \in H^{k+2}(\Omega)$  of the boundary conditions (5,1,2,1) and (5,1,2,2) iff equalities (5,1,2,14) to (5,1,2,17) hold for all  $d \in [0, k+1[$  and j s.t.  $(\Phi_{j+1} - \Phi_j - d\omega_j)/\pi$  is an integer and provided

$$\frac{\Phi_{j+1}-\Phi_j-(k+1)\omega_j}{\pi}$$

is not an integer for any j.

This last provision is made to avoid possible identities (5,1,2,10) to

(5,1,2,13) corresponding to the order d = k + 1. Such an identity would yield a condition with an integral similar to (1,6,1,3).

**Remark 5.1.2.5** The identities (5,1,2,10) to (5,1,2,13) corresponding to either d = 0 or d = 1 are just (5,1,2).

#### 5.1.3 More singular solutions

We first infer the consequences of Theorem 5.1.1.5 and Theorem 5.1.2.3 or 5.1.2.4.

**Theorem 5.1.3.1** Let  $f \in W_p^k(\Omega)$  and  $g_i \in W_p^{k+2-1/p}(\Gamma_i)$ ,  $j \in \mathcal{D}$ ,  $g_i \in W_p^{k+1-1/p}(\Gamma_i)$ ,  $j \in \mathcal{N}$ , be given. Assume that  $(\Phi_{j+1} - \Phi_j - k\omega_j - 2\omega_j/q)/\pi$  is not an integer for any j and that the identities (5,1,2,14) to (5,1,2,17) hold for all  $d \in [0, k+1[$  and all j such that  $(\Phi_{j+1} - \Phi_j - d\omega_j)/\pi$  is an integer. Then there exists a function u (possibly non-unique) and numbers  $c_{i,m}$  such that

$$u - \sum_{\substack{-k-2/q < \lambda_{j,m} < 0 \\ \lambda_{j,m} \neq -1, -2, \dots, -k}} C_{j,m} S_{j,m} \in W_p^{k+2}(\Omega)$$

and u is solution of problem (5,1,1,1).

Indeed, let v be given by Theorem 5.1.2.3 or Theorem 5.1.2.4; we just have to apply Theorem 5.1.1.5 with f replaced by  $f - \Delta v$ , since this function belongs to  $\mathring{W}_{p}^{k}(\Omega)$ .

Remark 5.1.3.2 The number of extra conditions (5,1,2,14) to (5.1.2.17) on the data of f and  $g_i$ ,  $1 \le j \le N$ , is exactly the number of eigenvalues  $\lambda_{i,m}$  which are excluded from the sum which describes the singular behaviour of u, by the condition

$$\lambda_{j,m} \neq -1, -2, \ldots, -k.$$

For practical purposes, the identities (5,1,2,14) to (5,1,2,17) are not easy to check on functions given explicitly. This is due, in particular, to the fact that we did not attempt to find the operators  $R_{i,d}$ . We shall rather try to understand the particularly singular behaviour of the solution u which occurs when one of these identities is not fulfilled. We need a preliminary result.

#### Lemma 5.1.3.3 Let s be the function

$$s(r;\theta) = r^{-\lambda_{j,m}} \left[ \ln r \cos \left( \lambda_{j,m} \theta + \Phi_{j+1} \right) + \theta \sin \left( \lambda_{j,m} \theta + \Phi_{j+1} \right) \right]$$

where  $\lambda_{j,m} = (\Phi_j - \Phi_{j+1} + m\pi)/\omega_i$  is assumed to be a negative integer. Then

s is harmonic for r > 0 and  $\theta \in ]0, \omega_i[$ . Furthermore, we have

$$\begin{cases} -\frac{1}{r}\frac{\partial s}{\partial \theta} + \tan \Phi_{j+1}\frac{\partial s}{\partial r} = 0 & \text{for } r > 0, \quad \theta = 0 \\ s = 0 & \text{for} \quad r > 0, \quad \theta = 0 \text{ if } \cos \Phi_{j+1} = 0 \end{cases}$$

$$\begin{cases} \frac{1}{r}\frac{\partial s}{\partial \theta} - \tan \Phi_{j}\frac{\partial s}{\partial r} = (-1)^{m}\frac{\lambda_{j,m}\omega_{j}}{\cos \Phi_{j}} r^{-\lambda_{j,m}-1} & \text{for } r > 0, \quad \theta = \omega_{j} \\ s = (-1)^{m}\omega_{j}\sin \Phi_{j}r^{-\lambda_{j,m}} & \text{for } r > 0, \quad \theta = \omega_{j} \quad \text{if } \cos \Phi_{j} = 0. \end{cases}$$

This can be verified directly. Now let us consider a cut-off function  $\eta_i$  similar to the one we have used in Chapter 4. In other words, we have  $\eta_i \in \mathcal{D}(\bar{\Omega}), \ \eta_i = 1 \text{ near } S_i$ ; the support of  $\eta_i$  does not meet  $\bar{\Gamma}_l$  for  $l \neq j, j+1$ , and

$$\begin{cases} \frac{\partial \eta_{j}}{\partial \mu_{j}} = 0 & \text{on } \Gamma_{j} & \text{if } j \in \mathcal{N} \\ \\ \frac{\partial \eta_{j}}{\partial \mu_{j+1}} = 0 & \text{on } \Gamma_{j+1} & \text{if } j+1 \in \mathcal{N}. \end{cases}$$

Let us then set

$$\mathfrak{S}_{j,m}(r_j e^{i\theta_j}) = r_j^{-\lambda_{j,m}} [\ln r_j \cos (\lambda_{j,m} \theta_j + \Phi_{j+1}) + \theta_j \sin (\lambda_{j,m} \theta_j + \Phi_{j+1})] \eta_i(r_j e^{i\theta_j}).$$

$$(5,1,3,1)$$

This function has the following properties:

$$\Delta \mathfrak{S}_{i,m} = f_{i,m} \in C^{\infty}(\bar{\Omega})$$

where  $f_{j,m}$  is zero near all the corners and

$$\gamma_k \frac{\partial \mathfrak{S}_{j,m}}{\partial \nu_k} + \tan \Phi_k \frac{\partial}{\partial \gamma_k} \mathfrak{S}_{j,m} = g_{j,m,k} \in C^{\infty}(\bar{\Gamma}_k)$$

for  $k \in \mathcal{N}$  and

$$\gamma_k \mathfrak{S}_{j,m} = g_{j,m,k} \in C^{\infty}(\bar{\Gamma}_k)$$

for  $k \in \mathcal{D}$ . In addition  $g_{j,m,k}$  is zero for all k, but k = j and k = j + 1, and we have

$$g_{j,m,j} = \begin{cases} (-1)^m \frac{\lambda_{j,m} \omega_j}{\cos \Phi_j} r_j^{-\lambda_{j,m}-1} & \text{if } j \in \mathcal{N} \\ (-1)^m \omega_j \sin \Phi_j r_j^{-\lambda_{j,m}} & \text{if } j \in \mathcal{D} \end{cases}$$

near  $S_i$ , while

$$g_{i,m,i+1} = 0$$

near  $S_i$ .

Accordingly, the necessary condition at  $S_i$  in Theorem 5.1.2.3 is not fulfilled. On the other hand, it is easy to check that

$$\mathfrak{S}_{i,m} \in H^{s}(\Omega)$$

iff  $s < -\lambda_{i,m} + 1$ , while  $\mathfrak{S}_{i,m} \notin H^{-\lambda_{i,m}+1}(\Omega)$ .

The conclusion of these preliminaries is the following, where for convenience, we introduce a new definition.

**Definition 5.1.3.4** We define the function  $\mathfrak{S}_{i,m}$  as follows:

$$\mathfrak{S}_{i,m}(r_i e^{i\theta_i}) = r_i^{-\lambda_{i,m}} \cos(\lambda_{i,m}\theta_i + \Phi_{i+1}) \eta_i(r_i e^{i\theta_i})$$

when  $\lambda_{i,m}$  is not an integer† and

$$\mathfrak{S}_{i,m}(r_i e^{i\theta_i}) = r_i^{-\lambda_{i,m}} \{ \ln r_i \cos (\lambda_{i,m} \theta_i + \Phi_{i+1}) + \theta_i \sin (\lambda_{i,m} \theta_i + \Phi_{i+1}) \} \eta_i(r_i e^{i\theta_i})$$

when  $\lambda_{i,m}$  is an integer.

**Theorem 5.1.3.5** Let  $f \in W_p^k(\Omega)$  and

$$g_i \in W^{k+2-1/p}_p(\varGamma_i), \quad j \in \mathcal{D}, \qquad g_i \in W^{k+1-1/p}_p(\varGamma_i), \quad j \in \mathcal{N},$$

be given. Assume that  $(\Phi_{j+1} - \Phi_j - k\omega_j - 2\omega_j/q)/\pi$  is not an integer for any j and that  $g_j(S_j) = g_{j+1}(S_j)$  whenever j and  $j+1 \in \mathfrak{D}$ . Then there exists a function u (possibly non-unique) and numbers  $k_{j,m}$ , such that

$$u - \sum_{k-2/q < \lambda_{i,m} < 0} k_{j,m} \mathfrak{S}_{j,m} \in W_p^{k+2}(\Omega)$$

and u is solution of problem (5,1,1,1).

**Proof** We shall apply Theorem 5.1.3.1. For each j,m such that  $\lambda_{j,m}$  is an integer belonging to the interval ]-k-2/q,0[, let us define  $k_{j,m}$  as follows:

$$k_{i,m} \left[ a_i \frac{\partial^{d-1} g_{i,m,j}}{\partial \tau_i^{d-1}} (S_i) - \frac{\partial^{d-1} g_{i,m,j+1}}{\partial \tau_{i+1}^{d-1}} (S_i) \right]$$

$$= \left[ a_i \frac{\partial^{d-1} g_i}{\partial \tau_i^{d-1}} (S_i) - \frac{\partial^{d-1} g_{i+1}}{\partial \tau_{i+1}^{d-1}} (S_i) - R_{i,d} f(S_i) \right]$$

<sup>†</sup> Observe that here  $\mathfrak{S}_{i,m}$  is just a relabelling for  $(\sqrt{\omega_i})\lambda_{i,m}S_{i,m}$ .

when j and  $j+1 \in \mathcal{N}$ ,  $d = (\Phi_{j+1} - \Phi_j - m\pi)/\omega_j$ . We define  $k_{j,m}$  in a similar fashion (mutatis mutandis) when j or  $j+1 \in \mathcal{D}$ .

It is clear that

$$f' = f - \sum_{\substack{-k - 2/q < \lambda_{j,m} < 0 \\ \lambda_{i,m} \text{ integer}}} k_{j,m} f_{j,m}$$

and

$$g'_{j} = g_{j} - \sum_{\substack{-k-2/q < \lambda_{l,m} < 0 \\ \lambda_{l,m} \text{ integer}}} k_{l,m} g_{l,m,j}, \qquad 1 \leq j \leq N,$$

fulfil the assumptions of Theorem 5.1.3.1. Consequently, there exist a function u' and numbers  $c_{i,m}$  such that

$$u' - \sum_{\substack{-k-2/q < \lambda_{i,m} < 0 \\ \lambda_{i,m} \neq -1, -2, \dots, -k}} c_{j,m} S_{j,m} \in W_p^{k+2}(\Omega)$$

and u' is a solution of

$$\begin{cases} \Delta u' = f' & \text{in } \Omega \\ \gamma_i u' = g_i' & \text{on } \Gamma_i, \quad j \in \mathcal{D} \\ \gamma_i \frac{\partial u'}{\partial \nu_i} + \beta_i \frac{\partial}{\partial \tau_i} \gamma_i u' = g_i' & \text{on } \Gamma_i, \quad j \in \mathcal{N} \end{cases}$$

We conclude the proof by setting

$$u = u' + \sum_{\substack{-k-2/q < \lambda_{i,m} < 0 \\ \lambda_{i,m} \text{ integer}}} k_{i,m} \mathfrak{S}_{i,m}$$

and  $k_{j,m} = c_{j,m}/(\sqrt{\omega_j})\lambda_{j,m}$ 

Remark 5.1.3.6 The solution u in Theorem 5.1.3.5 is unique when there is uniqueness in the space  $H^1(\Omega)$  (see Section 4.4.3) or in the space  $W_r^1(\Omega)$  with r>2 (see Section 4.4.4).

Remark 5.1.3.7 Again one can also handle the domains with cuts by applying the same techniques (see Remark 1.7.4 in connection with the trace results of Subsection 5.1.2). Therefore the results in Theorem 5.1.3.5 still hold if we allow  $\omega_i = 2\pi$  for some j. For instance in the case of a Dirichlet problem on both sides of a cut (i.e.  $\omega_j = 2\pi$  and  $j \in \mathcal{D}$ ,  $j+1 \in \mathcal{D}$ ) the singular solutions are the following:

$$\mathfrak{S}_{j,m} = r_j^{m/2} \sin(m\theta_j/2) \eta_j (r_j e^{i\theta} j)$$

when m is odd and

$$\mathfrak{S}_{j,m} = r_i^{m/2} \{ \ln r_i \sin (m\theta_i/2) + \theta_i \cos (m\theta_i/2) \} \eta_i (r_i e^{i\theta_i})$$

when m is even.

#### 5.2 Operators with variable coefficients

A natural continuation of the study carried out in the previous sections would be to investigate boundary value problems with variable coefficients in a plane domain whose boundary is a curvilinear polygon. The simplest idea is to apply the well-known perturbation method to reduce such a problem to similar problems involving only homogeneous operators with constant coefficients. This method will enable us to extend only part of the preceding results to problems with variable coefficients.

Here just to illustrate such a method, we shall restrict ourselves to the study of a Dirichlet problem. Thus we will also avoid a lot of side difficulties which have nothing to do with the specific problem of singular behaviour of solutions near the corners.

The data are the following. We consider a plane bounded open domain  $\Omega$  whose boundary  $\Gamma$  is a curvilinear polygon of class  $C^{1,1}$  (see Definition 1.4.5.1). Thus  $\Gamma = \bigcup_{i=1}^{N} \Gamma_i$ , where  $\Gamma_i$  is an open arc of curve of class  $C^{1,1}$  and  $\bar{\Gamma}_i$  meets  $\bar{\Gamma}_{i+1}$  at  $S_i$ . The measure of the angle of the tangent vectors to  $\bar{\Gamma}_i$  and  $\bar{\Gamma}_{i+1}$  at  $S_i$  (toward the interior of  $\Omega$ ), will again by denoted by  $\omega_i$ ,  $1 \le j \le N$ . Next, we consider the elliptic operator A defined by

$$Au = \sum_{i,j=1}^{2} D_i(a_{ij}D_ju) + \sum_{i=1}^{2} a_iD_iu + a_0u,$$

where  $a_{i,j} = a_{j,i} \in C^{0,1}(\bar{\Omega})$  (it is sufficient throughout this section to assume that  $a_{i,j} \in W_p^1(\Omega)$  for some p > 2)  $a_i \in L^{\infty}(\bar{\Omega})$ ,  $0 \le i \le 2$ . The ellipticity of A means the existence of  $\alpha > 0$  such that

$$\sum_{i,j=1}^{2} a_{i,j}(x)\xi_{i}\xi_{j} \leq -\alpha |\xi|^{2}$$
(5,2,1)

for all  $x \in \overline{\Omega}$  and  $\xi \in \mathbb{R}^2$ .

Our first purpose is to calculate the index of the operator A from  $W_p^2(\Omega) \cap \mathring{W}_p^1(\Omega)$  into  $L_p(\Omega)$ . For simplicity, we assume that the corresponding boundary value problem has a unique variational solution in  $\mathring{H}^1(\Omega)$ . This can be achieved by assuming for instance that

$$\min_{x \in \bar{\Omega}} a_0(x) > \frac{1}{4\alpha} \max_{\substack{x \in \bar{\Omega} \\ i = 1, 2}} |a_i(x)|^2.$$
 (5,2,2)

Consequently, applying Lemma 2.2.1.1, it is easily seen that for any given  $f \in L_p(\Omega)$ , there exists a unique solution  $u \in \mathring{H}^1(\Omega)$  of the equation

$$Au = f \qquad \text{in } \Omega. \tag{5.2.3}$$

In addition it follows from the results in Subsection 2.5.1, that

$$u \in W^2_p(\Omega \setminus V)$$

for every closed neighbourhood V of the corners. Thus we just have to investigate the behaviour of u near the corners.

Before stating our main result, we need to introduce one more notation. We consider the operator  $A_j$  obtained from A by freezing the coefficients of its principal part at  $S_i$ :

$$A_j u = \sum_{k,l=1}^2 a_{k,l}(S_j) D_k D_l u.$$

Then let us consider one matrix  $\mathcal{T}_i$  such that

$$-\mathcal{T}_{i}\mathcal{A}_{i}\mathcal{T}_{i}=I$$

266

where  $\mathcal{A}_{j}$  is the symmetrix matrix whose entries are the  $a_{k,l}(S_{j})$ ,  $1 \le k, l \le 2$ . We clearly have

$$(A_i u)(\mathcal{F}_i^{-1} x) = -(\Delta v_i)(x)$$

where  $v_i(x) = u(\mathcal{T}_i^{-1}x)$ .

**Definition 5.2.1** We denote by  $\omega_i(A)$  the measure of the angle at  $\mathcal{T}_iS_i$  of  $\mathcal{T}_i\Omega$ .

We are now able to calculate the index of A.

**Theorem 5.2.2** Assume that  $2\omega_i(A)/\pi q$  is not an integer for any j; then the image of  $W_p^2(\Omega)$  through the mapping

$$T: u \mapsto \{Au; \gamma_i u, 1 \le j \le N\}$$

is a closed subspace of codimension

$$\sum_{j=1}^{N} \operatorname{card} \left\{ m \left| -\frac{2}{q} < \frac{m\Pi}{\omega_{j}(A)} < 0 \right. \right\}$$

in the space

$$Z = \{ (f; g_j, 1 \le j \le N) \mid f \in L_p(\Omega), g_j \in W_p^{2-1/p}(\Gamma_j), 1 \le j \le N, g_j(S_j) \\ = g_{j+1}(S_j), 1 \le j \le N \}.$$

This general result will be deduced from a sequence of lemmas of technical character. In these we are going to deal with the particular case when  $\Omega$  has only one corner. This is possible since we now consider curvilinear polygons. One can think of the cross section of a wing, for instance. We shall refer to this particular case as the case when N=1.

**Lemma 5.2.3** Assume that N = 1; then there exists a constant C s.t.

$$\|u\|_{2,p,\Omega} \le C \|Au\|_{0,p,\Omega} \tag{5,2,4}$$

for all  $u \in W^2_p(\Omega) \cap \mathring{W}^1_p(\Omega)$ , provided  $2\omega_1(A)/\pi q$  is not an integer.

![](_page_282_Picture_3.jpeg)

Figure 5.1

**Proof** This will be derived from inequalities (2,3,3,1) and (4,1,2), with the help of the same technique that we have already used in Subsection 2.3.3.

First we select a neighbourhood W of  $S_1$  and a change of variable  $\mathcal{U}: W \to \mathcal{U}W$  with the following properties:

- (a)  $\mathcal{U}$  is of class  $C^{1,1}$ ,
- (b) the Frechet derivative of  $\mathcal{U}$  at  $S_1$  is the linear operator defined by the matrix  $\mathcal{T}_1$ ,
- (c)  $\mathcal{U}(\Gamma \cap W)$  is the union of two straight segments with origin at  $\mathcal{U}S_1$ .

Then we choose a cut-off function  $\eta$  with support in W s.t.  $\eta$  is identically equal to one near  $S_1$ . We shall look separately at  $\eta u$  and  $(1-\eta)u$ . Set

$$v(x) = (\eta u)(\mathcal{U}^{-1}x), \qquad x \in \mathcal{U}W$$

and select any plane open domain  $\omega$  with a polygonal boundary such that

- (a)  $\bar{\omega} \subset \mathcal{U}W$ ,
- (b)  $\tilde{\omega}$  contains the support of v,
- (c)  $\partial \omega$  coincides with  $\mathcal{U} \partial \Omega$  near  $\mathcal{U} S_1$ .

It is clear that  $v \in W^2_p(\omega) \cap \mathring{W}^1_p(\omega)$  and that

$$-\Delta v + \sum_{i,j=1}^{2} b_{i,j} D_{i} D_{j} v + \sum_{i=1}^{2} b_{i} D_{i} v + b_{0} v = g$$

in  $\omega$ , where

$$g = (A\eta u) \circ \mathcal{U}^{-1}$$

and where  $b_{i,i} \in C^{0,1}(\bar{\omega}), b_i \in L^{\infty}(\omega), 0 \le i \le 2$  and in addition:

$$b_{i,j}(\mathcal{U}S_1)=0.$$

We apply inequality (4,1,2) to v. This is possible since the angle of  $\omega$  at  $\mathscr{U}S_1$  is  $\omega_1(A)$  and we have assumed that  $2\omega_1(A)/\pi q$  is not an integer. It is always possible to choose the other angles of  $\omega$  so as to avoid the exceptional cases for inequality (4,1,2). Accordingly, we have

$$||v||_{2,p,\omega} \le C ||g - \sum_{i,j=1}^{2} b_{i,j} D_i D_j v + \sum_{i=1}^{2} b_i D_i v + b_0 v||_{0,p,\omega}.$$

It follows that

$$||v||_{2,p,\omega} \le C \bigg\{ ||g||_{0,p,\omega} + 4 \max_{\substack{i,j=1,2\\x \in \text{supp } n^{-Q^{-1}}}} |b_{i,j}(x)| \, ||v||_{2,p,\omega} + ||v||_{1,p,\omega} \bigg\}.$$

Now since  $b_{i,j}$  vanishes at  $US_1$ , we can choose the support of  $\eta$  small enough so that

$$\max_{\substack{i,j=1,2\\x\in\text{supp }\eta^{-2}u^{-1}}} |b_{i,j}(x)| \leq 1/8C.$$

Accordingly, we have

$$||v||_{2,p,\omega} \le 2C\{||g||_{0,p,\omega} + ||v||_{1,p,\omega}\}.$$

Going back to u, this implies that

$$\|\eta u\|_{2,p,\Omega} \le C(\|A\eta u\|_{0,p,\Omega} + \|\eta u\|_{1,p,\Omega})$$
(5,2,5)

with possibly another value for C.

Then we can choose another plane open domain,  $\Omega'$  with a  $C^{1,1}$  boundary, such that the boundary of  $\Omega'$  coincides with the boundary of  $\Omega$  out of the set  $\{\eta = 1\}$  where  $\eta$  is equal to one. Accordingly, we have  $(1-\eta)u \in W_p^2(\Omega') \cap W_p^1(\Omega')$  and applying inequality (2,3,3,1), we have

$$||(1-\eta)u||_{2,p,\Omega} \le C\{||A(1-\eta)u||_{0,p,\Omega} + ||(1-\eta)u||_{1,p,\Omega}.$$
 (5,2,6)

Adding inequalities (5,2,5) and (5,2,6), we obtain the estimate

$$||u||_{2,p,\Omega} \le C\{||Au||_{0,p,\Omega} + ||u||_{1,p,\Omega}\}. \tag{5,2,7}$$

On the other hand, a direct integration by parts shows that

$$\|u\|_{1,2,\Omega} \le C \|Au\|_{0,\nu,\Omega}. \tag{5,2,8}$$

The inequality (5,2,4) follows from (5,2,7) and (5,2,8) with the help of inequality (1,4,3,2).

The next step is the following.

**Lemma 5.2.4** Assume that N=1 and that the boundary of  $\Omega$  is rectilinear near  $S_1$ . Then the image of  $W^2_p(\Omega) \cap \mathring{W}^1_p(\Omega)$  through  $\Delta$  is a closed subspace of codimension  $[2\omega_1/\pi q]^{\dagger}$  in  $L_p(\Omega)$ , provided  $2\omega_1/\pi q$  is not an integer.

*Proof* Let  $f \in L_p(\Omega)$  be given and let  $u \in \mathring{H}^1(\Omega)$  be the solution of

$$-\Delta u = f \qquad \text{in } \Omega. \tag{5.2.9}$$

It is clear from the results in Chapter 2 that

$$u \in W^2_p(\Omega \setminus W)$$

where W is any closed neighbourhood of  $S_1$ . Again let  $\eta$  be a cut-off function which is equal to 1 near  $S_1$ . We have

$$(1-\eta)u\in W_p^2(\Omega),$$

and if we choose the support of  $\eta$  small enough,  $\eta u$  is solution of the Dirichlet problem for the equation

$$-\Delta \eta u = \eta f - [\Delta; \eta] u = f_1$$

in a plane open domain  $\omega$ , whose boundary  $\partial \omega$  is a polygon which coincides with  $\partial \Omega$  near  $S_1$ . It is clear that  $f_1 \in L_p(\omega)$  and, applying Theorem 4.4.3.7, we know that there exists numbers  $C_m$  such that

$$\eta u - \sum_{0 < m\pi/\omega_1 < 2/a} C_m r_1^{m\pi/\omega_1} \sin \frac{m\pi\theta_1}{\omega_1} \in W_p^2(W),$$

where W is a neighbourhood of  $S_1$  in  $\omega$ .

Adding these results, we have

$$u - \sum_{0 < m\pi/\omega_1 < 2/q} C_m r_1^{m\pi/\omega_1} \sin \frac{m\pi\theta_1}{\omega_1} \, \eta_1 \in W_p^2(\Omega).$$

The numbers  $C_m$  are continuous linear functionals of  $f_1$  and consequently also of f through the Green operator

$$\Sigma: f \to u$$

defined by (5,2,9). Accordingly, we have  $u \in W_p^2(\Omega) \cap \mathring{W}_p^1(\Omega)$  iff f annihilates  $[2\omega_1/\pi q]$  linear functionals on  $L_p(\Omega)$ .

**Lemma 5.2.5** Assume that N=1 and that the boundary of  $\Omega$  is rectilinear near  $S_1$ . Then the image of  $W^2_p(\Omega) \cap \mathring{W}^1_p(\Omega)$  through A is a closed subspace whose codimension is  $[2\omega_1(A)/\pi q]$  provided  $2\omega_1(A)/\pi q$  is not an integer.

<sup>† [</sup>S] denotes the integral part of S.

**Proof** Let us first look at the particular case when  $A_1 = -\Delta$  or equivalently

$$a_{k,l}(S_1) = \delta_{k,l}, \quad 1 \leq k, \quad l \leq 2.$$

Then we shall derive the result by homotopy from  $-\Delta$  to A. Let us set

$$A(t) = tA - (1-t)\Delta, \quad t \in [0, 1].$$

Applying Lemma 5.2.3, we know that for each  $t \in [0, 1]$  there exists a constant  $C_t$  such that

$$||u||_{2,p,\Omega} \le C_t ||A(t)u||_{0,p,\Omega}$$

for all  $u \in W_p^2(\Omega) \cap \mathring{W}_p^1(\Omega)$ . Accordingly, A(t) is a semi-Fredholm operator from  $W_p^2(\Omega) \cap \mathring{W}_p^1(\Omega)$  into  $L_p(\Omega)$  for every  $t \in [0, 1]$ .

The operator A(t) depends continuously on t. Thus by a theorem in Kato (1966), the index of A(t) does not depend on t. Consequently, the index of A(1) = A is equal to the index of  $A(0) = -\Delta$ , which is  $-[2\omega_1/IIq]$ , by Lemma 5.2.1.4. This completes the proof of Lemma 5.2.5 when  $A_1 = -\Delta$ , since A is one to one (inequality (5,2,4)).

The general case is reduced to the particular case when  $A_1 = -\Delta$  by composition with the matrix  $\mathcal{T}_1$ .

**Proof** of Theorem 5.2.2 Let us start from  $f \in L_p(\Omega)$ . There exists a solution  $u \in \mathring{H}^1(\Omega)$  of

$$Au = f \qquad \text{in } \Omega \tag{5,2,10}$$

and in addition  $u \in W^2_p(\Omega \setminus V)$ , where V is any closed neighbourhood of the corners. This was observed earlier. For further convenience we denote by  $\Sigma$  the continuous linear operator from  $L_p(\Omega)$  into  $\mathring{H}^1(\Omega)$  defined by (5,2,10).

Let  $\eta_i$  be a cut-off function whose support is small near  $S_i$  and such that  $\eta_i = 1$  in a neighbourhood of  $S_i$ . Obviously, we have

$$A\eta_i u = \eta_i f + [A; \eta_i] \Sigma f = f_i \in L_p(\omega_i)$$

and  $\eta_i u \in W_p^2(\omega_i) \cap \mathring{W}_p^1(\omega_i)$ , where  $\omega_i$  is an open plane domain whose boundary is a curvilinear polygon of class  $C^{1,1}$  with only one corner at  $S_i$ , which contains the support of  $\eta_i$  and such that the boundary of  $\omega_i$  coincides with the boundary of  $\Omega$  near  $S_i$ .

Finally, we select a change of variable  $\mathcal{U}_i$  defined in a neighbourhood  $W_1$  of  $S_i$  such that

- (a)  $\mathcal{U}_i$  is of class  $C^{1,1}$
- (b) the Frechet derivative of  $\mathcal{U}_i$  at  $S_i$  is the identity operator  $\mathcal{U}$
- (c)  $\mathcal{U}_i(\Gamma \cap W_i)$  is the union of two straight segments with origin at  $\mathcal{U}_iS_i$ .

If the support of  $\eta_i$  is small enough, we can also choose  $\omega_i$  small enough

to be contained in  $W_i$ . Under these assumptions, we can apply Lemma 5.2.1.5 in the domain  $\mathcal{U}_i\omega_i$ .

The conclusion is that  $\eta_i u \in W_p^2(\omega_i)$  iff  $f_i$  annihilates  $[2\omega_i(A)/\pi q]$  continuous linear forms on  $L_p(\omega_i)$ ,  $1 \le j \le N$ . Accordingly,  $u \in W_p^2(\Omega)$  iff f annihilates

$$\nu = \sum_{j=1}^{N} \left[ \frac{2\omega_{j}(A)}{\pi q} \right]$$

continuous linear forms on  $L_p(\Omega)$ , since

$$f_i = \eta_i f + [A; \eta_i] \Sigma f.$$

Thus we have shown that A is a one-to-one mapping from  $W_p^2(\Omega) \cap \mathring{W}_p^1(\Omega)$  onto a closed subspace of  $L_p(\Omega)$ , whose codimension is  $\nu$ . This, together with a trace theorem (Subsection 1.6) implies the claim of Theorem 5.2.2.

Remark 5.2.6 The general principle underlying Theorem 5.2.2 is that we can easily extend the index property of our boundary value problems from the case when all the operators have constant coefficients to the general case. However, for practical purposes, one also needs to know which singular functions must be added to  $W_p^2(\Omega)$  in order to get surjectivity. The perturbation method used here will allow us to conclude only in some particular cases when the singular functions remain the same when passing from the constant coefficient case to the general case.

**Theorem 5.2.7** Assume that  $2\omega_i(A)/\pi q$  is not an integer and that

$$p < \omega_j(A)/(\omega_j(A) - \pi) \tag{5.2.11}$$

for all j s.t.  $\omega_i(A) > \pi$ . Then for every  $(f; g_i, 1 \le j \le N)$  given in Z, (as defined in the statement of Theorem 5.2.2), there exists a unique function u and unique numbers  $C_{i,m}$  such that

$$u - \sum_{\substack{0 < m < 2\omega_{\mathbf{i}}(\mathbf{A})/\pi q \\ j=1,2,\dots,N}} C_{j,m} \hat{\mathbf{S}}_{j,m} \in W^2_{\mathbf{p}}(\Omega),$$

ana

$$\begin{cases} Au = f & \text{in } \Omega \\ \gamma_i u = g_i & \text{on } \Gamma_i, \quad 1 \leq j \leq N, \end{cases}$$

where

$$\hat{S}_{j,m}(\mathcal{T}_i^{-1}x) = r_i^{m\pi/\omega_i(A)} \sin \frac{m\pi\theta_i}{\omega_i(A)} \, \eta_i(r_i e^{i\theta_i}).\dagger$$

† We identify x with  $r_i e^{i\theta_i}$  in  $\mathcal{F}_i \Omega$ , where  $r_i$ ,  $\theta_i$  are the polar coordinates of the corner  $\mathcal{F}_i S_i$  of  $\mathcal{F}_i \Omega$ ; i.e.,  $\mathcal{F}_i S_i$  is the point  $r_i = 0$ , while the lines tangent to  $\mathcal{F}_i \Gamma$  at  $\mathcal{F}_i S_i$  correspond to  $\theta_i = 0$  and  $\theta_i = \omega_i(A)$  respectively.

**Proof** Clearly the functions  $\hat{S}_{j,m}$  belong to  $H^1(\Omega)\backslash W_p^2(\Omega)$  when  $0 < m\pi/\omega_j(A) < 2/q$ . We shall show that

$$A\hat{S}_{i,m} \in L_p(\Omega), \qquad \gamma_k \hat{S}_{i,m} \in W_p^{2-1/p}(\Gamma_k), \qquad 1 \leq k \leq N,$$

provided condition (5,2,11) is fulfilled.

Indeed, we have

$$(A\hat{S}_{j,m}) \circ \mathcal{F}_{j}^{-1} = \left(-\Delta + \sum_{k,l=1}^{2} b_{k,l} D_{k} D_{l} + \sum_{k=1}^{2} b_{k} D_{k} + b_{0}\right) \hat{S}_{j,m} \circ \mathcal{F}_{j}^{-1}$$

where  $b_{k,l} \in C^{0,1}(\mathcal{T}_i \bar{\Omega}), b_k \in L_{\infty}(\mathcal{T}_i \bar{\Omega}), 0 \le k \le 2$  and

$$b_{k,l}(\mathcal{T}_i S_i) = 0.$$

From the above definition of  $\hat{S}_{i,m}$ , it follows that

$$(A\hat{S}_{i,m})\circ\mathcal{T}_i^{-1}(x)=0(r_i^{m\pi/\omega_i(A)-1})$$

near  $\mathcal{T}_i S_i$ , while  $A\hat{S}_{i,m}$  is smooth in  $\mathcal{T}_i(\bar{\Omega} \setminus S_i)$ . This shows that

$$A\hat{S}_{i,m} \in L_p(\Omega)$$
.

On the other hand, we have  $\gamma_k \hat{S}_{j,m} \in W_p^{2-1/p}(\Gamma_k)$  for all k, because  $\gamma_k \hat{S}_{j,m} = 0$  for  $k \neq j, j+1$ , while when k is j or j+1 we can apply the following Lemma which follows easily from the definition of the space  $W_p^{2-1/p}(]0, a[)$ .

**Lemma 5.2.8** Assume that  $\varphi \in C^{1,1}([0, a])$  with a > 0 and that  $\varphi(0) = \varphi'(0) = 0$ . Then the function  $u = \varphi^{\alpha}$  belongs to  $W_p^{2-1/p}(]0, a[)$  provided  $\alpha > 1 - 1/p$ .

Here, choosing the coordinate axes suitably, we can assume that  $\mathcal{F}_i\Gamma_{i+1}$  is the graph of a function  $\varphi$  fulfilling the assumption of Lemma 5.2.8. Then we have

$$\gamma_{j+1}\hat{S}_{j,m}\mathcal{F}_{j}^{-1}(x,y) = \sqrt{(x^2 + \varphi(x)^2)^{m\pi/\omega_j(A)}} \sin\left(\frac{m\pi}{\omega_j(A)}\arctan\frac{\varphi(x)}{x}\right)$$

near the origin. Accordingly,  $\gamma_{j+1}\hat{S}_{j,m}$  belongs to  $W_p^{2-1/p}(\Gamma_{j+1})$  iff  $p < \omega_j(A)/(\omega_j(A) - \pi)$  when  $\omega_j(A) > \pi$ ,  $m = 1, 2, \ldots$ 

A similar proof shows that  $\gamma_i \hat{S}_{i,m} \in W_p^{2-1/p}(\Gamma_i)$ .

Summing up, we have shown that the mapping T (defined in the statement of Theorem 5.2.2) maps the space E spanned by  $W_p^2(\Omega)$  and the functions  $\hat{S}_{j,m}$   $(1 \le j \le N, 0 < m < 2\omega_j(A)/\pi q)$  into Z. The codimension of  $W_p^2(\Omega)$  in E is obviously

$$\nu = \sum_{j=1}^{N} \left[ \frac{2\omega_{j}(A)}{\pi q} \right].$$

Consequenty if follows from Theorem 5.2.2 that T is an isomorphism from E onto Z, since T is one to one on *E c H'(ƒ2).*

*Remark* 5.2.9 In the particular case when f2 is a strict polygon (but A still has variable coefficients), we can replace the condition (5,2,11) by the weaker one

$$P < \frac{2\omega_i(A)}{\pi - \omega_i(A)}$$

Indeed we still have AS;, <sup>m</sup> E L<sup>p</sup> ((2), while WS;, <sup>m</sup> =0 for all *k.*

*Remark 5.2.10* Starting from the results explained in Remark 4.4.1.14, one can also apply the techniques of this section when w; (A) = 2#ir. This takes care of domains with turning points toward the interior of £2 (see Section 3.3 for the treatment of turning points toward the exterior of D).

*Remark 5.2.11* A technique for calculating singular solutions of other boundary value problems has been worked out in Mghazli (1983). This technique allows one to handle second-order elliptic boundary value problems for nonhomogeneous operators (i.e. including lower-order terms) .

l.J

## Results in spaces of Holder functions

#### 6.1 Foreword

All the results in the previous chapters have been stated in the framework of the Sobolev spaces described in Chapter 1. The basic reason for using such spaces was explained in Section 1.1. However, one is mainly interested in statements claiming that the solution of a given boundary value problem has continuous derivatives up to a certain order. Such a property cannot be derived directly due to the bad behaviour of the kernels involved in the maximum norm (see Section 1.1 again). This is the reason why the classical property of continuity of some derivatives of the solution has been derived indirectly through the use of the Sobolev imbedding theorem of Subsection 1.4.4.

Another approach to the continuous differentiability of the solution of a boundary value problem consists in using spaces of functions with derivatives up to a certain order (say rn a nonnegative integer) which are Hölder continuous (with exponent o- a real number between zero and one). Of course these spaces are closer to the classical spaces of continuously differentiable functions than the Sobolev spaces. However, they have few nice properties besides the ones which are obvious from the definition. Precise statements are given in Section 6.2. Fortunately a very nice multiplier theorem, similar to Mikhlin's theorem (Theorem 2.3.2.1) for the Lebesgue space L,, (Pn ), holds for the Hölder spaces. As it turned out in Chapters 2 and 4, the multiplier theorem was the basic tool for proving the *a priori* inequalities. Accordingly similar *a priori* inequalities hold in the framework of Hölder spaces. They will be proved in this chapter and the corresponding regularity (or singularity) results will be derived.

To conclude this introductory section, let us mention some references about regularity in Hölder spaces. A wide set of results is derived in the classical book Miranda (1970) which deals with second-order problems in a domain with smooth boundary. Some of these results are extended to

problems of higher order in Agmon et al. (1959). Second-order problems in domains with corners are studied in Volkoff (1965a,b), Azzam (1979, 1981) and Moussaoui (1971). The first two authors restrict their purpose to the Dirichiet problem. Their results are included in the present chapter.

#### 6.2 A brief review of Hölder spaces

In this section, after defining precisely the spaces under consideration, we shall review their basic properties. In doing this, we shall follow the same plan as in Chapter 1 for the Sobolev spaces. Here D denotes any open subset of Di".

Definition 6.2.1 *Let m* be a nonnegative *integer and u a real number* such that 0<0 -1. *We denote by C"`•`'(Q) the* space *of* all *fu*nctions *u defined in* n whose *derivatives, up to the order m, are continuous and bounded in (2 and* whose *derivatives of order m are uniformly Hölder continuous with exponent o-.*

We define a Banach norm on C"<sup>1</sup> (T( - ) by setting

$$||u||_{s,\infty,\bar{\Omega}} = \sum_{|\alpha| \le m} \lim_{x \in \bar{\Omega}} |D^{\alpha}u(x)| + \sum_{|\alpha| = m} \lim_{x,y \in \bar{\Omega}} \frac{|D^{\alpha}u(x) - D^{\alpha}u(y)|}{|x - y|^{\sigma}}, \quad (6,2,1)$$

where s = m + a-. Observe that this definition includes the case when 12 =ll".

In order to be able to describe the traces on the boundary I' of (2 of such functions, we need a definition for similar spaces on I. This requires some smoothness assumption on I. Precisely we assume that (2 is bounded and that its boundary is of class Ck- ' with k + 1>- s = m + CF. We use the same notation as in Chapter 1; in particular P is defined by the identity (1,3,3,1), where cp is described in the Definition 1.2.1.1.

Definition 6.2.2 *Let (2 be a bounded open* subset *of* (ion with *a boundary of* class C'` - ', *where k* is a nonnegative *integer. Let I'" be an open* subset *of F. A function u defined in ['" belongs to Cm'° (F0), m* a nonnegative *integer,* o E]O, *1],s=m+a- -k+1,iffu* ° SEC"`'`T(V'fl 'P '(I'<sup>0</sup> nV))forallpossi*bEe* V and cp fulfilling *the* assumptions in Definition 1.2.1.1.

It follows plainly from this definition that u belongs to C"•°(T) iff u is Hölder continuous with exponent o- in the usual sense. In addition, it is clear that the trace u r of a function u E Cm'°(,2) is well defined and belongs to C`" (T). A converse statement will be derived later.

Some of the properties of the Sobolev spaces have analogues which are just obvious; among them are the following. First  $C^{m,\sigma}(\bar{\Omega})$  and  $C^{m,\sigma}(\Gamma)$  are algebras for the usual multiplication. Next the differentiation operator  $D_i$ ,  $1 \le i \le n$ , is a continuous mapping from  $C^{m,\sigma}(\bar{\Omega})$  into  $C^{m-1,\sigma}(\bar{\Omega})$ . Finally the natural imbedding of  $C^{m,\sigma}(\bar{\Omega})$  into  $C^{m',\sigma'}(\bar{\Omega})$  (and of  $C^{m,\sigma}(\Gamma)$  into  $C^{m',\sigma'}(\Gamma)$ ) is compact provided  $m' + \sigma' < m + \sigma$ ; this is a simple consequence of the well-known Ascoli theorem.

On the other hand some of the most useful properties of the Sobolev spaces have no analogue at all for the Hölder spaces. For instance, there is no convenient density result. Indeed it is easy to check that any function u in the closure of  $\mathfrak{D}(\mathbb{R}^n)$  for the norm of  $C^{m,\sigma}(\mathbb{R}^n)$ , has the following extra properties:

(a) 
$$D^{\alpha}u(x) \rightarrow 0$$
 when  $|x| \rightarrow +\infty$ , for  $|\alpha| \le m$ 

(b) 
$$\frac{|D^{\alpha}u(x) - D^{\alpha}u(y)|}{|x - y|^{\alpha}} \to 0 \quad \text{when } |x - y| \to 0, \quad \text{for } |\alpha| = m.$$

The main reason for introducing these Hölder spaces is the following multiplier theorem.

**Theorem 6.2.3** Let  $a \in C^n(\mathbb{R}^n)$  be such that there exists a constant C with

$$|D^{\alpha}a(\xi)| \le C(1+|\xi|)^{-|\alpha|}$$
 (6,2,2)

for all  $\xi \in \mathbb{R}^n$  and  $|\alpha| \le n$ . Then the operator

$$g \mapsto F^{-1}aFg$$

is continuous in  $C^{m,\sigma}(\mathbb{R}^n)$  for all m (a nonnegative integer) and  $\sigma \in ]0, 1[$ .

A short outline of the proof may be found in Meyer (1978) while a detailed proof is given in Triebel (1978).

Let us now focus our attention on the continuation property. The case of a Lipschitz condition, i.e. the case when  $\sigma=1$ , is very peculiar. For instance, if  $\Omega$  is bounded, any function  $u \in C^{m,1}(\bar{\Omega})$  is the restriction to  $\bar{\Omega}$  of some function  $U \in C^{m,1}(\mathbb{R}^n)$ . This very strong result may be found in Schwarz (1965) for instance. Unfortunately, since Theorem 6.2.3 excludes the case when  $\sigma=1$ , we shall mainly use the spaces with  $0 < \sigma < 1$  in studying boundary value problems. There exists a Hölder version of Theorem 1.4.3.1: under the same assumptions,  $P_s$  maps  $C^{m,\sigma}(\bar{\Omega})$  into  $C^{m,\sigma}(\mathbb{R}^n)$ , where  $s=m+\sigma$ . It is hard to give a precise reference for this result. However, the proof is just the same as the corresponding proof for the Sobolev spaces with Theorem 2.3.2.1 replaced by Theorem 6.2.3. The following statements, whose proofs are easy, are sufficient for our purpose.

**Theorem 6.2.4** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a boundary  $\Gamma$  of class  $C^{m,1}$ . Then there exists a continuous linear operator  $P_{m+1}$  from  $C^{m,\sigma}(\bar{\Omega})$  into  $C^{m,\sigma}(\mathbb{R}^n)$  for every  $\sigma \in ]0,1]$ , such that

$$P_{m+1} u|_{\bar{\Omega}} = u. ag{6.2,3}$$

Outline of proof This is quite similar to the proof of Theorem 3.9, Section 3, Chapter 2, in Nečas (1967). The first step is a reduction to the case when  $\Omega$  is replaced by a half space  $\mathbb{R}^n_+$  defined by  $x_n > 0$ . This is achieved through the use of local coordinates near the boundary and a partition of unity. The second step consists in defining U by

$$U(x_1, \dots, x_n) = \begin{cases} u(x_1, \dots, x_n), & x_n \ge 0\\ \sum_{i=1}^{m+1} \lambda_i u(x_1, \dots, x_{n-1}, -ix_n), & x_n < 0, \end{cases}$$
ming that

assuming that

$$1 = \sum_{i=1}^{m+1} (-i)^{\alpha} \lambda_i, \qquad \alpha = 0, 1, \dots, m.$$
 (6,2,4)

It is very easy to check that  $U \in C^{m,\sigma}(\mathbb{R}^n)$ , when u is given in  $C^{m,\sigma}(\mathbb{R}^n_+)$ , and that  $U_{\mathbb{R}^n_+} = u$ .

**Theorem 6.2.5** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$  whose boundary  $\Gamma$  is a curvilinear polygon of class  $C^{m,1}$ . There exists a continuous linear operator  $P_{m+1}$  from  $C^{m,\sigma}(\bar{\Omega})$  into  $C^{m,\sigma}(\mathbb{R}^2)$ , for every  $\sigma \in ]0,1]$ , such that

$$P_{m+1}u|_{\bar{\Omega}}=u$$
 for every  $u \in C^{m,\alpha}(\bar{\Omega})$ .

**Proof** This is basically a repeat of the previous proof. Again we use a partition of unity and local coordinates. According to Definition 1.4.5.1, the problem is reduced to one of the following cases:

- (a)  $\Omega$  is a half space and we proceed as in the proof of Theorem 6.2.4;
- (b)  $\Omega$  is a quadrant, defined by  $x_1 > 0, x_2 > 0$  and we define U as follows:

$$U(x_1, x_2) = \begin{cases} V(x_1, x_2), & x_2 \ge 0 \\ \sum_{i=1}^{m+1} \lambda_i V(x_1, -ix_2), & x_2 < 0 \end{cases}$$

where

ere
$$V(x_1, x_2) = \begin{cases} u(x_1, x_2), & x_1 \ge 0, x_2 \ge 0 \\ \sum_{i=1}^{m+1} \lambda_i u(-ix_1, x_2), & x_1 < 0, x_2 \ge 0. \end{cases}$$

assuming again that (6,2,4) holds. Clearly  $U \in C^{m,\sigma}(\mathbb{R}^2)$ , when u is given in  $C^{m,\sigma}(\bar{\Omega})$  and  $U|_{\bar{\Omega}} = u$ .

(c)  $\Omega$  is the complement of a quadrant, defined by  $x_1 \ge 0$  or  $x_2 \ge 0$ . Here we proceed by steps. We start from  $u \in C^{m,\sigma}(\overline{\Omega})$  and we denote by  $u_1$  the restriction of u to the half plane defined by  $x_1 \ge 0$ . Then we define  $V_1$  by

$$V_1(x_1, x_2) = \begin{cases} u_1(x_1, x_2), & x_1 \ge 0 \\ \sum_{i=1}^{m+1} \lambda_i u_1(-ix_1, x_2), & x_1 < 0 \end{cases}$$

still assuming that (6,2,4) holds. Clearly  $V_1$  belongs to  $C^{m,\sigma}(\mathbb{R}^2)$  and  $V_1 = u$  for  $x_1 \ge 0$ .

Next we set  $w = u - V_1$  in the half plane defined by  $x_2 \ge 0$ . We have  $w \in C^{m,\sigma}(\mathbb{R}^2_+)$  and w = 0 in the first quadrant  $(x_1 \ge 0 \text{ and } x_2 \ge 0)$ . We finally define a continuation W for w by

$$W(x_1, x_2) = \begin{cases} w(x_1, x_2), & x_2 \ge 0\\ \sum_{i=1}^{m+1} \lambda_i w(x_1, -ix_2), & x_2 < 0 \end{cases}$$

again. The function W belongs to  $C^{m,\sigma}(\mathbb{R}^2)$  and vanishes for  $x_1 \ge 0$ . Consequently the function

$$U = V_1 + W$$

is a suitable continuation for u.

As a consequence of the above continuation property, it is easy to derive the following inequality. Assuming that s' > s'' > s''' > 0 and that  $\Omega$  is a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary, there exists a constant K (depending on s', s'', s''' and  $\Omega$ ) such that

$$\|u\|_{s'',\infty,\bar{\Omega}} \le \varepsilon \|u\|_{s',\infty,\bar{\Omega}} + \varepsilon^{-(s''-s''')/(s'-s'')} \|u\|_{s''',\infty,\bar{\Omega}}$$

$$(6,2,5)$$

for all  $\varepsilon > 0$  and all  $u \in C^{m,\sigma}(\bar{\Omega})$ ,  $s' = m + \sigma$ .

We shall conclude this section by a brief survey of trace results for the Hölder spaces. We shall obviously need them in the study of boundary value problems. Their proofs are much easier than the corresponding proofs for Sobolev spaces.

**Theorem 6.2.6** Let  $\Omega$  be either a half space or a bounded open subset of  $\mathbb{R}^n$  with a  $C^{k,1}$  boundary  $\Gamma$ . Then the mapping

$$u \mapsto \left\{ \gamma u, \gamma \frac{\partial u}{\partial \nu}, \dots, \gamma \frac{\partial^l u}{\partial \nu^l} \right\}$$
 (6,2,6)

maps  $C^{m,\sigma}(\bar{\Omega})$  onto  $\prod_{i=0}^{l} C^{m-i,\sigma}(\Gamma)$ , provided  $l \leq m$  and  $m+\sigma \leq k+1$ .

As in the previous chapters  $\gamma$  denotes the mapping

$$u\mapsto u|_{\Gamma}$$
.

Here all the functions we consider the traces of are continuous and accordingly no extension is needed to define  $\gamma$  (compare with Subsection 1.5.1).

Theorem 6.2.6 is proved by reduction to the case when  $\Omega$  is a half space using local coordinates and a partition of unity. Assume that the half-space is defined by  $x_n > 0$ , then the claim is that

$$u \mapsto \{\gamma_n u, \gamma_n D_n u, \ldots, \gamma_n D_n^l u\}$$

maps  $C^{m,\sigma}(\overline{\mathbb{R}}^n_+)$  onto  $\prod_{i=0}^l C^{m-j,\sigma}(\mathbb{R}^{n-1})$ . Indeed starting from  $u \in C^{m,\sigma}(\overline{\mathbb{R}}^n_+)$ , it is clear that  $D^i_n u|_{x_n=0}$  belongs to  $C^{m-j,\sigma}(\mathbb{R}^{n-1})$ . Therefore the mapping in (6,2,6) is well defined. To show that it is onto one can follow the method of proof of Theorem 5.8, Chapter 2 in Nečas (1967). (Observe that the same kind of proof works when  $\Omega$  is an infinite strip  $]a,b[\times\mathbb{R}$  (with  $a,b\in\mathbb{R}$ ; a< b). This will be useful later.)

We also need trace results for domains with corners. The model result (corresponding to Theorem 1.5.2.4) is the following:

**Theorem 6.2.7** The mapping  $u \mapsto (\{f_k\}_{k=0}^m; \{g_l\}_{l=0}^m)$  defined by

$$f_k = D_y^k u|_{y=0}, \qquad g_l = D_x^l u|_{x=0}$$
 (6,2,7)

is a continuous mapping from  $C^{m,\sigma}(\overline{\mathbb{R}_+ \times \mathbb{R}_+})$  onto the subspace of

$$T = \prod_{k=0}^m C^{m-k,\sigma}(\overline{\mathbb{R}}_+) \times \prod_{l=0}^m C^{m-l,\sigma}(\overline{\mathbb{R}}_+)$$

defined by

$$D_{x}^{l}f_{k}(0) = D_{y}^{k}g_{l}(0), \qquad l+k \le m.$$
 (6,2,8)

**Proof** The direct part of the statement is easy. Indeed when u is given in  $C^{m,\sigma}(\mathbb{R}_+ \times \mathbb{R}_+)$ , it is obvious from the definitions that

$$(\{f_k\}_{k=0}^m; \{g_l\}_{l=0}^m)$$

belongs to T and satisfies the compatibility conditions (6,2,8). We just have to prove the converse, i.e. that the mapping is onto.

For this purpose we start from  $f_k \in C^{m-l,\sigma}(\overline{\mathbb{R}}_+)$ ,  $0 \le k \le m$  and  $g_l \in C^{m-l,\sigma}(\overline{\mathbb{R}}_+)$ ,  $0 \le l \le m$ , given such that the conditions (6,2,8) are fulfilled. We have to find  $u \in C^{m,\sigma}(\overline{\mathbb{R}}_+ \times \overline{\mathbb{R}}_+)$  such that (6,2,7) holds. As we did in the proof of Theorem 1.5.2.4, we first select functions  $G_l \in C^{m-l,\sigma}(\mathbb{R})$  such that

$$G_{l|\mathbb{R}_i} = g_l, \qquad 0 \leq l \leq m.$$

Then, by the trace theorem for Hölder functions in a half space, there exists  $U \in C^{m,\sigma}(\mathbb{R}^2_+)$  such that

$$D_x^l U|_{x=0} = G_l, \quad 0 \le l \le m.$$

Next, instead of looking for u, we look for v = u - U, i.e. for a function  $v \in C^{m,\sigma}(\overline{\mathbb{R}_+ \times \mathbb{R}_+})$  such that

$$\begin{cases} D_{y}^{k}v|_{y=0} = f_{k} - D_{y}^{k}U|_{y=0} = h_{k}, & 0 \le k \le m \\ D_{x}^{l}v|_{x=0} = 0, & 0 \le l \le m. \end{cases}$$

In other words, we have reduced our problem to the particular case when  $g_l$  is replaced by zero for all l. It is clear from (6,2,8) that

$$D_x^l h_k(0) = 0, \qquad l + k \le m$$

and consequently  $\tilde{h}_k \in C^{m,\sigma}(\mathbb{R})$ . (Again,  $\sim$  denotes the continuation by zero out of the domain of definition of the function.)

Applying again the trace results concerning a half space, we can find  $w \in C^{m,\sigma}(\mathbb{R}^2_+)$  such that

$$D_y^k w|_{y=0} = \tilde{h}_k, \qquad 0 \leq k \leq m.$$

We obtain v as follows:

$$v(x, y) = w(x, y) - \sum_{j=1}^{m+1} \lambda_j w(-jx, y), \quad x > 0, \quad y > 0,$$

assuming that

$$\sum_{j=1}^{m+1} (-j)^l \lambda_j = 1, \qquad 0 \le l \le m. \quad \blacksquare$$

This theorem implies a similar result on curvilinear polygons whose proof uses the same techniques as the proof of Theorem 1.5.2.8.

**Corollary 6.2.8** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$  whose boundary  $\Gamma$  is a curvilinear polygon of class  $C^{\infty}$ . Then the mapping

$$u \mapsto \left\{ \gamma_j \frac{\partial^l u}{\partial \nu_i^l} \right\}, \qquad 1 \le j \le N, \quad 0 \le l \le m,$$

is linear continuous from  $C^{m,\sigma}(\bar\Omega)$  onto the subspace of

$$T = \prod_{j=1}^{N} \prod_{l=0}^{m} C^{m-l,\sigma}(\bar{\Gamma}_{j})$$

defined by the following conditions: Let L be any linear differential operator with coefficients of class  $C^{\infty}$  and order  $d \leq m$ . Denote by  $P_{j,l}$  the differential

operators tangential to  $\Gamma_i$  such that

$$L = \sum_{i \ge 0} P_{i,i} \frac{\partial^i}{\partial \nu_i^i};$$

then

$$\sum_{l \ge 0} (P_{i,l} f_{i,l})(S_i) = \sum_{l \ge 0} (P_{i+1,l} f_{i+1,l})(S_i). \tag{6.2.9}$$

The notation is the same as in the previous chapters. Namely  $\Gamma_i$  is the jth side of  $\Gamma$ ,  $\nu_i$  the corresponding outward normal vector field and  $\gamma_i$  is the corresponding trace operator,  $1 \le j \le N$ . Following the direct orientation,  $\bar{\Gamma}_i$  ends at  $S_i$ .

Another consequence of Theorem 6.2.7 through Corollary 6.2.8, is a statement similar to Theorem 1.6.1.4. Here we keep the same notation.

**Theorem 6.2.9** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$  whose boundary is a curvilinear polygon of class  $C^{\infty}$ . Let  $\{B_{j,k}\}_{k=1}^{K}$  be for each j, a system of differential operators in  $\Omega$ , with coefficients belonging to  $C^{\infty}(\bar{\Omega})$ , which is normal on  $\Gamma_i$ . Then the mapping

$$u \mapsto \{f_{i,k} = \gamma_i B_{i,k} u\}, \quad 1 \le j \le N, \quad 1 \le k \le K_i$$

maps  $C^{m,\sigma}(\bar{\Omega})$  onto the subspace of

$$T = \prod_{j=1}^{N} \prod_{k=1}^{K_{i}} C^{m-d_{j,k},\sigma}(\bar{\Gamma}_{j})$$

defined by the conditions (1, 6, 1, 2) for  $d \le m$  and all possible systems of differential operators  $\{P_{j,k}\}_{k=1}^{K}$  tangential to  $\Gamma_j$  and  $\{Q_{j+1,k}\}_{k=1}^{K}$  tangential to  $\Gamma_{j+1}$ , such that identity (1,6,1,1) holds.

The proof is quite similar to that of Theorem 1.6.1.4.

Now we conclude this section with one technical result which is useful in the remainder of this chapter. It is an extension of Theorem 1.4.5.3.

**Theorem 6.2.10** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$ , whose boundary  $\Gamma$  is a curvilinear polygon. Assume that  $0 \in \Gamma$ . Let V be a neighbourhood of O such that

$$V \cap \bar{\Omega} \subseteq \{(r \cos \theta, r \sin \theta); r \ge 0, a \le \theta \le b\}$$

with  $b-a < 2\pi$ . Finally let u be a function which is smooth in  $\Omega \setminus \{0\}$  and which is equal to

$$r^{\alpha}\varphi(\theta)$$

in  $V \cap \Omega$ , where  $\varphi \in C^{\infty}([a:b])$ . Then

$$u \in C^{m,\sigma}(\bar{\Omega}) \tag{6.2.10}$$

for  $\alpha \ge m + \sigma$ , while

$$u \notin C^{m,\sigma}(\bar{\Omega}) \tag{6,2,11}$$

for  $\alpha < m + \sigma$ , when  $\alpha$  is not an integer.

Observe that (6,2,10) follows from (1,4,5,1) with the help of the Sobolev imbedding theorem, when  $\alpha$  is strictly larger than  $m + \sigma$ . Otherwise it is a matter of direct elementary proof.

## 6.3 Regular second-order elliptic boundary value problems revisited

#### 6.3.1 The Schauder inequality

Here we shall derive a Hölder version of the *a priori* estimate proved in Section 2.3. Let us first briefly recall the notation (which we keep consistent with that in Chapter 2). The domain  $\Omega$  is a bounded open subset of  $\mathbb{R}^n$  with a  $C^{2,1}$  boundary; -A is a strongly elliptic real second order operator in  $\Omega$  and B is a real boundary operator of order d (d=0 or 1) which is nowhere characteristic on  $\Gamma$ . The reader is referred to Section 2.1 for the detailed assumptions on the coefficients. Our aim is to prove that there exists a constant C such that

$$||u||_{\sigma+2,\infty,\bar{\Omega}} \leq C[||Au||_{\sigma,\infty,\bar{\Omega}} + ||\gamma Bu||_{\sigma+2-d,\infty,\Gamma} + ||u||_{\sigma+1,\infty,\bar{\Omega}}]$$
for all  $u \in C^{2,\sigma}(\bar{\Omega})$ ,  $0 < \sigma < 1$ .

Exactly as in Section 2.3 the first step is the proof of an inequality in the half space. Here we make use of the notation of Subsection 2.3.2. Namely, L is a strongly elliptic, real, homogeneous second-order operator which has constant coefficients, while M is a real, homogeneous, first-order operator with constant coefficients, noncharacteristic on the hyperplane  $x_n = 0$ . We now intend to prove that there exists a constant C such that

$$||u||_{2+\alpha \times \mathbb{R}^n} \le c [||Lu||_{\alpha \times \mathbb{R}^n} + ||\gamma_n Mu||_{1+\alpha \times \mathbb{R}^{n-1}} + ||u||_{1+\alpha \times \mathbb{R}^n}]$$
 (6,3,1,2)

for all  $u \in C^{2,\sigma}(\widetilde{\mathbb{R}}^n_+)$  whose support is bounded.

Observing that such a function u also belongs to  $H^2(\mathbb{R}^n_+)$ , we can use the representation formula (2,3,2,12). Thus we have

$$u = E * \left( F + l_{n,n} k_0 \otimes \delta'_n + \left[ l_{n,n} k_1 + 2 \sum_{j=1}^{n-1} l_{n,j} D_j k_0 \right] \otimes \delta_n \right).$$
 (6,3,1,3)

Here F is a suitable continuation of f = Lu + u such that  $F \in C^{0,\sigma}(\mathbb{R}^n)$  and has compact support; E is the elementary solution for L+1 defined in

Subsection 2.3.2. In addition we have

$$\hat{k}_{0} = \left(m_{n}p_{-} + \sum_{j=1}^{n-1} i m_{j} \xi_{j}\right)^{-1} \hat{h}$$

$$\hat{k}_{1} = p_{-} \hat{k}_{0}$$

$$h = g - \gamma_{n} ME * F$$
(6,3,1,4)

where  $g = \gamma_n Mu$ .

Now it is very tempting to proceed with the same proofs as in Subsection 2.3.2, just substituting Theorem 6.2.3 in Mikhlin's multiplier theorem 2.3.2.1. Unfortunately this method of proof requires using spaces  $W_p^s$  corresponding to a negative order of differentiation s. This is in particular necessary for Lemma 2.3.2.2. A theory of Hölder spaces with negative order of differentiation is not yet well established. We shall not attempt to define such spaces and accordingly we shall not be able to derive any property of the operator  $\gamma_n^*$  in the framework of Hölder spaces. However, we shall be able to conclude by deriving directly the properties of the Poisson operator

$$P: \varphi \mapsto E * (\varphi \otimes \delta'_n). \tag{6,3,1,5}$$

**Lemma 6.3.1.1** When u belongs to  $H^2(\mathbb{R}^n_+)$  then

$$u = E * (F + \varphi \otimes \delta'_n), \qquad x_n > 0, \tag{6.3.1.6}$$

where

$$\hat{\varphi} = +l_{n,n}\hat{k}_0 + \frac{1}{p_-} \left[ l_{n,n}\hat{k}_1 + 2\sum_{j=1}^{n-1} l_{n,j}D_j\hat{k}_0 \right]. \tag{6.3,1,7}$$

In other words u is the solution of a Dirichlet problem

$$\begin{cases} Lu + u = f, & x_n > 0 \\ \gamma_n u = \varphi, & x_n = 0. \end{cases}$$

$$(6,3,1,8)$$

Proof This is a consequence of identity (6,3,1,3), observing that

$$\hat{E}(\xi, x_n) = -\frac{1}{l_{n,n}} \frac{e^{x_n p_{-}(\xi)}}{p_{+}(\xi) - p_{-}(\xi)}$$

for  $x_n > 0$ .

From identities (6,3,1,4) and (6,3,1,7) and from the multiplier theorem 6.2.3, it follows that there exists a constant C such that

$$\|\varphi\|_{2+\sigma,\infty,\mathbb{R}^{n-1}} \le C\{\|f\|_{\sigma,\infty,\mathbb{R}^n} + \|g\|_{1+\sigma,\infty,\mathbb{R}^{n-1}}\}. \tag{6.3.1.9}$$

Next we focus our attention on problem (6,3,1,8). A suitable linear transformation of coordinates reduces L+1 to  $-\Delta+1$ , and accordingly we can assume now that L is simply  $-\Delta$ . The basic estimate is the following.

**Lemma 6.3.1.2** For  $0 < \sigma < 1$ , there exists a constant C such that

$$||u||_{2+\sigma,\infty,\bar{\mathbb{R}}_{+}^{n}} \leq C\{||-\Delta u + u||_{\sigma,\infty,\bar{\mathbb{R}}_{+}^{n}} + ||\gamma_{n}u||_{2+\sigma,\infty,\mathbb{R}^{n-1}}\}$$

$$(6,3,1,10)$$
for all  $u \in C^{2,\sigma}(\bar{\mathbb{R}}_{+}^{n}).$ 

**Proof** We first reduce the general case to the particular one when both  $\gamma_n u$  and  $\gamma_n f$  vanish. Indeed, by the trace theorem 6.2.6, we know that

$$\gamma_n u \in C^{2,\sigma}(\mathbb{R}^{n-1})$$
 and  $\gamma_n f \in C^{0,\sigma}(\mathbb{R}^{n-1}),$ 

and consequently there exists  $v \in C^{2,\sigma}(\overline{\mathbb{R}}^n_+)$  such that

$$\begin{cases} \gamma_n v = \gamma_n u \\ \gamma_n D_n^2 v = \left( -\sum_{j=1}^{n-1} D_j^2 + I \right) \gamma_n u - \gamma_n f. \end{cases}$$

In addition, v depends continuously on  $\gamma_n u$  and f, i.e. there exists  $C_1$  such that

$$||v||_{2+\sigma,\infty,\bar{\mathbb{R}}_{1}^{n}} \leq C_{1}\{||f||_{\sigma,\infty,\bar{\mathbb{R}}_{1}^{n}} + ||\gamma_{n}u||_{2+\sigma,\infty,\mathbb{R}^{n-1}}\}. \tag{6.3.1.11}$$

Then we look at w = u - v; this function is a solution of a homogenous Dirichlet problem:

$$\begin{cases}
-\Delta w + w = g, & x_n > 0 \\
\gamma_n w = 0, & x_n = 0,
\end{cases}$$

where  $g = f - (-\Delta v + v)$ . Therefore  $g \in C^{0,\sigma}(\overline{\mathbb{R}}^n_+)$  and  $\gamma_n g = 0$ . We now perform an odd reflection through the hyperplane  $x_n = 0$ , i.e. we define W as follows:

$$W(x', x_n) = \begin{cases} w(x', x_n), & x_n \ge 0 \\ -w(x', -x_n), & x_n < 0. \end{cases}$$

We define G in a similar fashion. Since  $\gamma_n g = 0$ ,  $\gamma_n w = 0$  and  $\gamma_n D_n^2 w = 0$ , it follows that  $G \in C^{0,\sigma}(\mathbb{R}^n)$  and  $W \in C^{2,\sigma}(\mathbb{R}^n)$ . In addition we have

$$(-\Delta+1)W=G \qquad \text{in } \mathbb{R}^n.$$

Consequently the multiplier Theorem 6.2.3 shows that there exists a constant  $C_2$  such that

$$||W||_{2+\sigma,\infty,\mathbb{R}^n} \leq C_2 ||G||_{\sigma,\infty,\mathbb{R}^n}.$$

By restriction to  $\mathbb{R}_+^n$  we derive the existence of another constant  $C_3$  such that

$$\|w\|_{2+\sigma,\infty,\bar{\mathbb{R}}_{i}^{n}} \leq C_{3} \|g\|_{\sigma,\infty,\bar{\mathbb{R}}_{i}^{n}}. \tag{6,3,1,12}$$

Finally inequality (6,3,1,10) follows from (6,3,1,11) and (6,3,1,12).

With the help of inequality (6,3,1,9) we conclude:

**Theorem 6.3.1.3** Let -L be a homogeneous strongly elliptic second-order operator with real constant coefficients and let M be either the identity operator or a homogeneous first-order operator with constant coefficients for which the hyperplane  $x_n = 0$  is not characteristic. Then for  $0 < \sigma < 1$  there exists a constant C such that

$$\|u\|_{2+\sigma,\infty,\bar{\mathbb{R}}_{\cdot}^{n}} \leq C[\|Lu\|_{\sigma,\infty,\mathbb{R}_{\cdot}} + \|\gamma_{n}Mu\|_{2+\sigma-d,\infty,\mathbb{R}^{n-1}} + \|u\|_{1+\sigma,\infty,\bar{\mathbb{R}}_{\cdot}^{n}}] \quad (6,3,1,13)$$
 for all  $u \in C^{2,\sigma}(\bar{\mathbb{R}}_{+}^{n})$  with bounded support  $(0 < \sigma < 1)$ .

This statement is quite similar to Theorem 2.3.2.7 in the framework of Hölder spaces. Then by applying exactly the same technique as in the proof of Theorem 2.3.3.2, we derive a statement concerning operators with variable coefficients:

**Theorem 6.3.1.4** Let A, B and  $\Omega$  fulfil the assumptions in Section 2.1 Assume in addition that

- (a) the boundary  $\Gamma$  of  $\Omega$  is of class  $C^{2,1}$
- (b)  $a_{i,j} \in C^{1,\sigma}(\bar{\Omega}), 1 \le i, j \le n$
- (c)  $b_i \in C^{1,\sigma}(\bar{\Omega})$ .

Then for  $0 < \sigma < 1$  there exists a constant C such that (6,3,1,1) holds for all  $u \in C^{2,\sigma}(\bar{\Omega})$ .

We first prove that it is enough that each  $x \in \bar{\Omega}$  has a neighbourhood  $V_x$  so that (6,3,1,1) holds for all  $u \in C^{2,\sigma}(\bar{\Omega})$  whose support is contained in  $V_x$ . This is a statement similar to Lemma 2.3.3.1. The proof is exactly the same in the Hölder norms due to the extra assumptions that are made on the coefficients of A and B.

Then the existence of  $V_x$  is checked in the two particular cases (a) and (b) similar to those in the proof of Theorem 2.3.3.2. Accordingly we have two lemmas:

**Lemma 6.3.1.5** For every  $y \in \Omega$ , there exists a neighbourhood V of y in  $\Omega$  such that (6,3,1,1) holds for all  $u \in C^{2,\sigma}(\bar{\Omega})$  whose support is contained in V.

Some minor modifications of the proof of Lemma 2.3.3.3 are necessary. This is why we shall detail the proof of Lemma 6.3.1.5.

**Proof** We freeze the coefficients of A at y and thus we obtain an operator L with constant coefficients such that -L is strongly elliptic:

$$L = \sum_{i,j=1}^{n} l_{i,j} D_i D_j$$

where  $l_{i,i} = a_{i,i}(y)$ .

Then if the support of u is contained in V and  $\bar{V} \subset \Omega$  we have

$$L\widetilde{u}+\widetilde{u}=\widetilde{Au}-\left[\sum_{i,j=1}^{n}\left(\alpha_{i,j}-l_{i,j}\right)\widetilde{D_{i}D_{j}u}+\sum_{i,j=1}^{n}\left(D_{i}\alpha_{i,j}\right)\widetilde{D_{j}u}-\widetilde{u}\right]$$

where  $\alpha_{i,j}$  are functions belonging to  $C^{1,\sigma}(\mathbb{R}^n)$  such that  $\alpha_{i,j} = a_{i,j}$  in  $\bar{\Omega}$ . Let E be the elementary solution for L+1 introduced in Section 2.3.2. It follows that

$$\widetilde{u} = E * \widetilde{Au} - E * \left[ \sum_{i,j=1}^{n} (\alpha_{i,j} - l_{i,j}) \widetilde{D_i D_j u} + \sum_{i,j=1}^{n} (D_i \alpha_{i,j}) \widetilde{D_j u} - \widetilde{u} \right].$$

By Theorem 6.2.3, E\* is a linear continuous mapping from  $C^{0,\sigma}(\mathbb{R}^n)$  into  $C^{2,\sigma}(\mathbb{R}^n)$  since the Fourier transform of any derivative of E up to order 2 fulfils the assumptions of that theorem. Therefore there exists a constant  $C_1$  such that

$$||u||_{2+\sigma,\infty,\bar{\Omega}} \leq C_1 \left[ ||Au||_{\sigma,\infty,\bar{\Omega}} + ||u||_{1+\sigma,\infty,\bar{\Omega}} + \sum_{i,j=1}^n ||(a_{i,j} - l_{i,j})D_i D_j u||_{\sigma,\infty,\bar{\Omega}} \right].$$

$$(6,3,1,14)$$

Handling the last term is slightly more tricky than in the case of the Sobolev norms. Actually we have

$$\|(a_{i,j}-l_{i,j})D_{i}D_{j}u\|_{\sigma,\infty,\bar{\Omega}} \leq \max_{v \in V} |a_{i,j}-l_{i,j}| \|D_{i}D_{j}u\|_{\sigma,\infty,\bar{\Omega}} + \|a_{i,j}-l_{i,j}\|_{\sigma,\infty,\bar{\Omega}} \max_{v \in V} |D_{i}D_{j}u|,$$

provided u has its support in V. If we assume that the diameter of V is  $\leq \delta$ , then we have

$$\max_{x \in V} |a_{i,j}(x) - l_{i,j}| \leq K\delta^{\sigma}$$

since  $a_{i,j} \in C^{0,\sigma}(\tilde{\Omega})$  and we also have

$$\max_{x \in V} |D_i D_j u(x)| \leq \delta^{\sigma} ||u||_{2+\sigma,\infty,\bar{\Omega}}.$$

Accordingly there exists a constant  $C_2$  such that

$$||u||_{2+\sigma,\infty,\bar{\Omega}} \le C_2[||Au||_{\sigma,\infty,\bar{\Omega}} + ||u||_{1+\sigma,\infty,\bar{\Omega}} + \delta^{\sigma} ||u||_{2+\sigma,\infty,\bar{\Omega}}]. \tag{6.3,1,15}$$

We conclude by choosing  $\delta$  small enough to ensure that  $C_2\delta^{\sigma}$  is less than 1. Then (6,3,1,13) holds for all  $u \in C^{2,\sigma}(\bar{\Omega})$  with support in V, provided  $\bar{V}$  is contained in  $\Omega$  and the diameter of V is less than  $\delta$ .

The technical lemma corresponding to Lemma 2.3.3.4 is the following:

**Lemma 6.3.1.6** Let  $y \in \Gamma$  have a neighbourhood W in  $\Gamma$ , contained in the hyperplane  $\{x_n = 0\}$ . Then there exists a neighbourhood U of y in  $\overline{\Omega}$  such that (6,3,1,13) holds for all  $u \in C^{2,\sigma}(\overline{\Omega})$ , whose support is contained in U.

Translating the proof of Lemma 2.3.3.4 into the framework of Hölder spaces requires the same kind of modifications as for Lemma 6.3.1.5. It is not worth detailing a theorem.

#### 6.3.2 Smoothness

We shall now derive some regularity results similar to those in Section 2.5.1. We assume again that A and B fulfil the assumptions in Section 2.1. In addition we assume that

- (d) the boundary  $\Gamma$  of  $\Omega$  is of class  $C^{2,1}$
- (e)  $a_{ij} \in C^{1,1}(\bar{\Omega}), b_i \in C^{1,1}(\bar{\Omega}).$

These requirements are slightly more restrictive than those in Theorem 6.3.1.4 (about the *a priori* inequalities). These extra assumptions could be avoided, but they will save many boring technicalities.

**Theorem 6.3.2.1** Let  $u \in W_p^2(\Omega)$ , with p > n, be such that

$$\begin{cases} Au = f \in C^{0,\sigma}(\tilde{\Omega}) \\ \gamma Bu = g \in C^{2-d,\sigma}(\Gamma) \end{cases}$$

with  $0 < \sigma < 1$ ; then  $u \in C^{2,\sigma}(\bar{\Omega})$ .

Basically we shall approximate the data f and g by better ones to which the regularity result of Theorem 2.5.1.1 may be applied. Then we shall be able to take limits with the help of the a priori inequalities of Subsections 2.3.3 and 6.3.1. However, the lack of convenient density results in the Hölder spaces introduces an additional complication. The following statement is a possible substitute for a density result.

**Lemma 6.3.2.2** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^n$  with a Lipschitz boundary  $\Gamma$ . Then each  $u \in C^{m,\sigma}(\bar{\Omega})$  can be approximated by a sequence  $u_{\nu}$ ,  $\nu = 1, \ldots$  such that

(a)  $u_{\nu} \in \mathcal{D}(\bar{\Omega})$ ,

- (b)  $||u_{\nu}||_{m+\sigma,\infty,\bar{\Omega}}$  is bounded when  $\nu \to +\infty$ ,
- (c)  $||u_{\nu} u||_{m + \sigma', \alpha, \bar{\Omega}} \rightarrow 0$  when  $\nu \rightarrow +\infty$  for every  $\sigma' < \sigma$ .

**Proof** This is straightforward. One can define  $u_{\nu}$  as follows:

$$u_{\nu} = (\rho_{\nu} * U)|_{\bar{\Omega}},$$

where  $U \in C^{m,\sigma}(\mathbb{R}^n)$  is a continuation of u (i.e.  $U|_{\bar{\Omega}} = u$ ) and  $\rho_{\nu}$ ,  $\nu = 1, \ldots$  is an approximation of identity; in other words

$$\rho_{\nu} \in \mathcal{D}(\mathbb{R}^n), \qquad \int_{\mathbb{R}^n} \rho_{\nu} \, \mathrm{d}x = 1$$

and the support of  $\rho_{\nu}$  converges to  $\{0\}$  when  $\nu \rightarrow \infty$ .

Proof of Theorem 6.3.2.1 We first choose  $\lambda$  large enough for inequality (2,3,3,7) to hold. Then we set  $h = f + \lambda u$ ; it is clear that  $h \in C^{0,\sigma}(\bar{\Omega})$ .

Let  $h_{\nu} \in C^1(\bar{\Omega})$  and  $g_{\nu} \in C^3(\Gamma)$  be such that  $||h_{\nu}||_{\sigma,\infty,\bar{\Omega}}$  and  $||g_{\nu}||_{2-d+\sigma,\infty,\Gamma}$  remain bounded and

$$\begin{aligned} \|h_{\nu} - h\|_{\sigma', \infty, \bar{\Omega}} &\to 0, & \nu \to \infty \\ \|g_{\nu} - g\|_{2-d+\sigma', \infty, \Gamma} &\to 0, & \nu \to \infty \end{aligned}$$

for all  $\sigma' < \sigma$ . Such sequences can be found by Lemma 6.3.2.2. (In order to approximate g, we can consider g as the trace of a function G belonging to  $C^{2-d,\sigma}(\bar{\Omega})$  and apply Lemma 6.3.2.2 to G.) Finally let  $u_{\nu}$  be solution of

$$\begin{cases} Au_{\nu} + \lambda u_{\nu} = h_{\nu} & \text{in } \Omega \\ \gamma Bu_{\nu} = g_{\nu} & \text{on } \Gamma. \end{cases}$$

We know that  $u_{\nu}$  exists by Theorem 2.4.1.3. Then Theorem 2.5.1.1 shows that  $u_{\nu} \in W_p^3(\Omega)$  for every  $p < +\infty$ . Consequently  $u_{\nu} \in C^{2,\sigma}(\bar{\Omega})$ .

In order to take the limit in  $\nu$ , we make use of the two *a priori* inequalities (2,3,3,7) and (6,3,1,1). We first have

$$||u_{\nu} - u||_{2,p,\Omega} \le C[||h_{\nu} - h||_{0,p,\Omega} + ||g_{\nu} - g||_{2-d-1/p,p,\Gamma}]$$

and consequently  $u_{\nu} \rightarrow u$  in  $W_p^2(\Omega)$ , when  $\nu \rightarrow +\infty$ .

On the other hand, we have

$$\begin{aligned} \|u_{\nu} - u_{\nu'}\|_{\sigma' + 2, \infty, \bar{\Omega}} &\leq C[\|h_{\nu} - h_{\nu'}\|_{\sigma', \infty, \bar{\Omega}} + \|g_{\nu} - g_{\nu'}\|_{\sigma' + 2 - d, \infty, \Gamma} \\ &+ \|u_{\nu} - u_{\nu'}\|_{\sigma' + 1, \infty, \bar{\Omega}}] \end{aligned}$$

and since  $W^2_p(\Omega)$  is continuously imbedded in  $C^{1,\sigma'}(\bar{\Omega})$  for p large enough, this shows that  $u_\nu$ ,  $\nu=1,2,\ldots$  is also a Cauchy sequence in  $C^{2,\sigma'}(\bar{\Omega})$  for all  $\sigma' < \sigma$ . It follows that  $u \in C^{2,\sigma'}(\bar{\Omega})$  and that  $D_i D_j u_\nu(x) \to D_i D_j u(x)$  for all  $x \in \bar{\Omega}$ ,  $i,j=1,2,\ldots,n$ .

Finally, applying again inequality (6,3,1,1), we see that  $||u_{\nu}||_{2,\sigma,\bar{\Omega}}$  remains bounded as  $\nu \to +\infty$ . Accordingly, there exists a constant K such that

$$|D_i D_i u_{\nu}(x) - D_i D_i u_{\nu}(y)| \leq K |x - y|^{\sigma}$$

for all  $i, j = 1, 2, ..., n, \nu = 1, 2...$ , and  $x, y \in \overline{\Omega}$ . Taking the limit shows that all the second derivatives of u are Hölder continuous with exponent  $\sigma$ .

Remark 6.3.2.3 A proof of the same result assuming that  $a_{ij}$  and  $b_i$  belong to  $C^{1,\alpha}(\bar{\Omega})$  requires application of the same technique as in the proof of Lemma 2.4.1.4 (i.e. locally flattening the boundary and mollifying tangentially).

Remark 6.3.2.4 As a consequence of Theorem 6.3.2.1, we can restate each of the Theorems 2.4.2.5–2.4.2.7 in the framework of the Hölder spaces. For instance the result corresponding to Theorem 2.4.2.5 reads as follows. Assume that the hypotheses of Theorem 2.4.2.5 are fulfilled and that in addition the boundary  $\Gamma$  of  $\Omega$  is of class  $C^{2.1}$  and that  $a_{i,j} \in C^{1,\sigma}(\bar{\Omega})$ ,  $1 \le i,j \le n$ ;  $a_i \in C^{0,\sigma}(\bar{\Omega})$ ,  $0 \le i \le n$ . Then, for every  $f \in C^{0,\sigma}(\bar{\Omega})$  and every  $g \in C^{2,\sigma}(\Gamma)$ , there exists a unique solution  $u \in C^{2,\sigma}(\bar{\Omega})$  of

$$\begin{cases} \sum_{i,j=1}^{n} D_{i}(a_{ij}D_{j}u) + \sum_{i=1}^{n} a_{i}D_{i}u + a_{0}u = f & \text{in } \Omega \\ \gamma u = g & \text{on } \Gamma. \end{cases}$$

#### 6.4 Second-order elliptic problems in polygons revisited

#### 6.4.1 The Schauder inequality in an infinite strip

We now look again at the boundary value problems of Section 4.2. Keeping the same notation, we are going to find sufficient conditions on the coefficients  $a, b, \alpha_i, \beta_i, \lambda_i, j = 0, 1$  for the existence of a constant C such that

$$||u||_{2+\sigma,\infty,\bar{B}} \le C ||Lu||_{\sigma,\infty,\bar{B}}$$
 (6,4,1,1)

for all  $u \in C^{2,\sigma}(\vec{B})$  such that  $\gamma_i M_i u = 0$  on  $F_i$ , j = 0, 1.

A first step will be the proof of the weaker inequality.

$$\max_{\tilde{B}} |u| \le C \|Lu\|_{\sigma, \infty, \tilde{B}}. \tag{6.4.1.2}$$

The technique is quite similar to the one we used in Subsection 4.2.2, just replacing the multiplier theorem 2.3.2.1 by Theorem 6.2.3. Then inequal-

ity (6,4,1,2) makes it possible to replace L by a - 1 to estimate the second derivatives of u in C°•`r(B).

*Theorem 6.4.1.1* Assume that *b > 0,* a 0 and that *for Bach 1=0 or 1,* we have *either ai = 1 or a;* = (3i =0 and Ai = 1. Assume *in addition* that the *characteristic equation* (4,2,1,2) has *no real root.* Then *for* 0<o<1 *there exists a constant C such that inequality* (6,4,1,2) *holds for* u E *C<sup>2</sup> •°(B) such* that y;M;u =0 *on F, 1=0, 1.*

*Proof* We first consider the particular case when u E C <sup>2</sup>'°(B) and has a bounded support. Thus *u* also belongs to *H2(B)* and we can apply Theorem 4.2.1.2. In other words identity (4,2,1,3) holds.

Then a Hölder version of Lemma 4.2.1.3 is this one:

*Lemma 6.4.1.2 Let* , y, z H K(^, y, z) *be a smooth function* such *that*

$$\max_{\mathbf{y} \in ]0,h[} \int_0^h \max_{\xi \in \mathbb{R}} \{ |K(\xi, \mathbf{y}, z)| + (1 + |\xi|) |D_{\xi}K(\xi, \mathbf{y}, z)| \} \, \mathrm{d}z < +\infty;$$

then the mapping u '—\* f defined by

$$\hat{u}(\xi, y) = \int_0^h K(\xi, y, z) \hat{f}(\xi, z) dz$$

is *continuous f rom C°°°(B) into* the spare *of continuous bounded functions* in B.

Applying this lemma we obtain inequality (6,4,1,2) but only for u E C2'°(B) fl *H2(B)* such that y;M; u =0 on F; , 1=0, 1.

We shall reduce the general case to the previous particular one with the help of cut-off functions. Accordingly let 0 e 2(B) be such that

$$\begin{cases} \theta(x) = 1, & |x| \leq 1 \\ \theta(x) = 0, & |x| \geq 2 \end{cases}$$

and let for E > 0, 0, be defined by

$$\theta_{\varepsilon}(x) = \theta(\varepsilon x).$$

Clearly 0" (x) --> 1 when e -\*0. Thus let us start from u E *C2"(B)* such that *-y;M, u = 0* on *F, j = 0,* 1. We have

$$\gamma_i M_j \theta_{\epsilon} u = \beta_j \theta_{\epsilon}' \gamma_j u$$
 on  $F_j$ ,  $j = 0, 1$ .

By the trace theorem (Section 6.2) we know that there exists v £ E *C2.0()*

such that

$$\begin{cases} \gamma_i v_{\epsilon} = 0 & \text{on } F_i, \quad j = 0, 1 \\ \gamma_j M_j v_{\epsilon} = \beta_j \theta'_{\epsilon} \gamma_j u & \text{on } F_i, \quad j = 0, 1 \end{cases}$$

and there exists a constant C, such that

$$\|v_{\varepsilon}\|_{2+\sigma,\infty,\bar{B}} \leq C_1 \sum_{j=0}^{1} \|\beta_j \theta_{\varepsilon}' \gamma_j u\|_{1+\sigma,\infty,F_j}$$

$$(6,4,1,3)$$

If we replace  $v_{\varepsilon}$  by  $\theta_{2\varepsilon}v_{\varepsilon}$  we can assume in addition that  $v_{\varepsilon}$  has a bounded support. Consequently we have

$$\theta_{\varepsilon}u - v_{\varepsilon} \in C^{2,\sigma}(\bar{B}) \cap H^2(B)$$

and

$$\gamma_i M_i(\theta_{\varepsilon} u - v_{\varepsilon}) = 0$$
 on  $F_i$ ,  $j = 0, 1$ .

Applying inequality (6,4,1,2) to  $\theta_{\varepsilon}u - v_{\varepsilon}$ , we get

$$\max_{\bar{\alpha}} |\theta_{\varepsilon} u - v_{\varepsilon}| \leq C \|L(\theta_{\varepsilon} u) - Lv_{\varepsilon}\|_{\sigma, \infty, \bar{B}}.$$

Therefore it follows that

$$\max_{\bar{B}} |\theta_{\varepsilon}u - v_{\varepsilon}| \leq C \{ \|\theta_{\varepsilon}Lu\|_{\sigma,\infty,\bar{B}} + \|\theta_{\varepsilon}''u\|_{\sigma,\infty,\bar{B}}$$
$$+ 2 \|\theta_{\varepsilon}'D_{x}u\|_{\sigma,\infty,\bar{B}} + |a| \|\theta_{\varepsilon}'u\|_{\sigma,\infty,\bar{B}} + C_{2} \|v_{\varepsilon}\|_{2+\sigma,\infty,\bar{B}} \}$$

Finally with the help of (6,4,1,3) we get

$$\max_{\vec{B}} |\theta_{\varepsilon}u| \leq C\{\|\theta_{\varepsilon}Lu\|_{\sigma,\infty,\vec{B}} + \|\theta_{\varepsilon}''u\|_{\sigma,\infty,\vec{B}} + 2\|\theta_{\varepsilon}'D_{x}u\|_{\sigma,\infty,\vec{B}} + |a| \|\theta_{\varepsilon}'u\|_{\sigma,\infty,\vec{B}} + C_{3} \|\theta_{\varepsilon}'u\|_{1+\sigma,\infty,\vec{B}}\}$$

and taking the limit in  $\varepsilon \to 0$  yields plainly

$$\max_{\tilde{B}} |u| \leq ||Lu||_{\sigma,\infty,\tilde{B}};$$

this is the desired result.

**Proof of Lemma 6.4.1.2** Again, as in the proof of Lemma 4.2.1.3, we denote by M the function

$$M(y; z) = \lim_{\xi \in \mathbb{R}} \{ |K(\xi, y, z)| + (1 + |\xi|) |D_{\xi}K(\xi, y, z)| \}.$$

It follows from Theorem 6.2.3 that there exists C such that

$$\begin{aligned} & \text{l.u.b. } |u(x, y)| + \underset{\substack{x, x' \in \mathbb{R} \\ x \neq x'}}{\text{l.u.b.}} \frac{|u(x, y) - u(x', y)|}{|x - x'|^{\sigma}} \\ & \leq C \int_{0}^{h} M(y, z) \left\{ \underset{\substack{x \in \mathbb{R} \\ x \neq x'}}{\text{l.u.b. }} |f(x, z)| + \underset{\substack{x, x' \in \mathbb{R} \\ x \neq x'}}{\text{l.u.b. }} \frac{|f(x, z) - f(x', z)|}{|x - x'|^{\sigma}} \right\} dz. \end{aligned}$$

It follows that

$$\max_{\bar{B}} |u| \leq C \int_0^h M(y, z) \, \mathrm{d}z \, ||f||_{\sigma, \infty, \bar{B}}. \quad \blacksquare$$

We are now able to prove the stronger inequality (6,4,1,1).

**Theorem 6.4.1.3** Under the assumptions of Theorem 6.4.1.1, there exists a constant C such that inequality (6,4,1,1) holds for  $u \in C^{2,\sigma}(\bar{B})$  such that  $\gamma_i M_i u = 0$  on  $F_i$ , j = 0, 1.

**Proof** Exactly as in the proof of Theorem 6.4.1.1, we begin with the particular case when u has a bounded support and therefore belongs to  $H^2(B)$ . We choose  $\mu_i$ , j = 0, 1 as in Lemma 4.2.2.5 and set

$$\begin{cases}
g = \Delta u - u \\
\Psi_j = \gamma_j (\alpha_j D_y u + \beta_j D_x u + \mu_j u), & j = 0, 1.
\end{cases}$$

Clearly we have

$$\begin{cases}
g = Lu - aD_x u + (b - 1)u \\
\Psi_j = (\mu_j - \lambda_j)\gamma_j u, & j = 0, 1.
\end{cases}$$
(6,4,1,4)

Then we set v = u - E \* G where G is a continuation of g from  $\overline{B}$  (i.e.  $G|_{\overline{B}} = g$ ) such that  $G \in C^{0,\sigma}(\mathbb{R}^2)$  has bounded support and

$$||G||_{\sigma,\infty,\mathbb{R}^2} \leq C_1 ||g||_{\sigma,\infty,\bar{B}},$$

and where E is the elementary solution of  $(\Delta - 1)$  defined by

$$E = -F^{-1}(1+|\xi|^2)^{-1}$$
.

By Theorem 6.2.3 the convolution by E maps continuously  $C^{0,\sigma}(\mathbb{R}^2)$  into  $C^{2,\sigma}(\mathbb{R}^2)$ . Consequently there exists a constant  $C_2$  such that

$$||u||_{2+\alpha \propto \bar{B}} \le C_2 \{||v||_{2+\alpha \propto \bar{B}} + ||g||_{\alpha \propto \bar{B}} \}. \tag{6.4.1.5}$$

Now, we have to estimate v which is a solution of

$$\begin{cases} -\Delta v + v = 0 & \text{in } B \\ \gamma_j(\alpha_j D_y v + \beta_j D_x v + \mu_j v) = h_j, & j = 0, 1, \end{cases}$$

$$(6,4,1,6)$$

where  $h_i$  is defined by

$$h_i = \Psi_i - \gamma_i \{ (\alpha_i D_y + \beta_i D_x + \mu_i) E * G \}, \qquad j = 0, 1.$$
 (6,4,1,7)

Since G has a bounded support, it belongs to  $L_2(\mathbb{R}^2)$  and E\*G belongs to  $H^2(\mathbb{R}^2)$ . It follows that v also belongs to  $H^2(B)$ . This is why we can use the calculations in Subsection 4.2.2.

This means that, setting  $k_j = \gamma_j v$  and  $l_i = \gamma_i D_v v$ , j = 0, 1, we have:

$$\hat{k}_0 = \alpha$$
,  $\hat{l}_0 = r\beta$ ,

$$\hat{k}_1 = \alpha \cosh(rh) + \beta \sinh(rh)$$

$$\hat{l}_1 = \alpha r \sinh(rh) + \beta r \cosh(rh),$$

where

$$\alpha = \frac{1}{d} \left\{ \alpha_0 r \hat{h}_1 - \left[ \alpha_1 r \cosh (rh) + (i\beta_1 \xi + \mu_1) \sinh (rh) \right] \hat{h}_0 \right\}$$

$$\beta = \frac{1}{d} \left\{ -(i\beta_0 \xi + \mu_0) \hat{h}_1 + [\alpha_1 r \sinh(rh) + (i\beta_1 \xi + \mu_1) \cosh(rh)] \hat{h}_0 \right\}$$

$$d = r \cosh (rh) [\alpha_0 (i\beta_1 \xi + \mu_1) - \alpha_1 (i\beta_0 \xi + \mu_0)] + \sinh (rh) [r^2 \alpha_0 \alpha_1 - (i\beta_0 \xi + \mu_0) (i\beta_1 \xi + \mu_1)] r = \sqrt{(1 + \xi^2)}.$$

It is worth recalling here that due to Lemma 4.2.2.5 d does not vanish for any real  $\xi$ . Applying Theorem 6.2.3 we get the following inequality:

$$\sum_{j=0}^1 \left\{ \|k_j\|_{2+\sigma,\infty,F_i} + \|l_j\|_{1+\sigma,\infty,F_i} \right\} \leq C_3 \sum_{j=0}^1 \|h_j\|_{2-d_i+\sigma,\infty,F_j}.$$

Then (6,4,1,4) and (6,4,1,7) imply that

$$\sum_{j=0}^{1} \{ \|k_j\|_{2+\sigma,\infty,F_i} + \|l_j\|_{1+\sigma,\infty,F_i} \} \le C_4 \{ \|Lu\|_{\sigma,\infty,\tilde{B}} + \|u\|_{1+\sigma,\infty,\tilde{B}} \}.$$
 (6,4,1,8)

To conclude we write the equation of  $\tilde{v}$ :

$$(-\Delta+1)\tilde{v} = -k_0 \otimes \delta'_0 + k_1 \otimes \delta'_h - l_0 \otimes \delta_0 + l_1 \otimes \delta_h.$$

Accordingly we have

$$\tilde{v} = -E * \{-k_0 \otimes \delta_0' + k_1 \otimes \delta_h' - l_0 \otimes \delta_0 + l_1 \otimes \delta_h\}.$$

And consequently (as in Lemma 6.3.1.1†)

$$v = -E * \{ \varphi_0 \otimes \delta_0' + \varphi_1 \otimes \delta_n' \}$$
 (6,4,1,9)

† Here

$$\hat{E}(\xi, x_2) = \frac{\exp(-|x_2|\sqrt{(1+\xi^2)})}{2\sqrt{(1+\xi^2)}}.$$

where

$$\hat{\varphi}_0 = -\hat{k}_0 + \frac{\hat{l}_0}{\sqrt{(1+\xi^2)}}, \qquad \hat{\varphi}_1 = \hat{k}_1 + \frac{\hat{l}_1}{\sqrt{(1+\xi^2)}}. \tag{6.4,1,10}$$

Thus, in B,v is the sum of two functions  $v_0$  and  $v_1$  which are solutions of a Dirichlet problem in the half planes  $x_2 > 0$  and  $x_2 < h$  respectively

$$\begin{split} v_0 &= -E * \varphi_0 \otimes \delta_0', & v_1 &= -E * \varphi_1 \otimes \delta_h' \\ & \begin{cases} -\Delta v_0 + v_0 &= 0, & x_2 > 0 \\ \gamma_0 v_0 &= -\frac{1}{2} \varphi_0 & \end{cases} \\ & \begin{cases} -\Delta v_1 + v_1 &= 0, & x_2 < h \\ \gamma_h v_1 &= \frac{1}{2} \varphi_1. \end{cases} \end{split}$$

Applying Lemma 6.3.1.2 twice, we get the inequality

$$||v||_{2+\sigma,\infty,\bar{B}} \le C_5 \sum_{j=0}^{1} ||\varphi_j||_{2+\sigma,\infty,F_j}.$$

This implies, by (6,4,1,10) and Theorem 6.2.3, that

$$||v||_{2+\sigma,\infty,\tilde{B}} \le C_6 \sum_{j=0}^{1} \{ ||k_j||_{2+\sigma,\infty,F_j} + ||l_j||_{1+\sigma,\infty,F_j} \}.$$
 (6,4,1,11)

Summing up, from the inequalities (6,4,1,5), (6,4,1,8) and (6,4,1,11) it follows that

$$\|u\|_{2+\sigma,\infty,\bar{B}} \le C_7 \{ \|Lu\|_{\sigma,\infty,\bar{B}} + \|u\|_{1+\sigma,\infty,\bar{B}} \}.$$
 (6,4,1,12)

Now we take advantage of the classical inequality (6,2,5) in the case of an infinite strip:

Lemma 6.4.1.4 There exists a constant K such that

$$||u||_{1+\sigma,\infty,\vec{B}} \le \varepsilon ||u||_{2+\sigma,\infty,\vec{B}} + K\varepsilon^{-(1+\sigma)} \max_{\vec{B}} |u|$$

for all  $\varepsilon \in ]0, 1]$  and all  $u \in C^{2,\sigma}(\tilde{B})$ .

Choosing  $\varepsilon$  small enough, inequality (6,4,1,1) follows from (6,4,1,12) and (6,4,1,2).

So far we have always assumed that u had a compact support. In order to remove this extra assumption, we approximate a general u by  $\theta_{\varepsilon}u$  exactly as in the proof of Theorem 6.4.1.1.

Proof of Lemma 6.4.1.4 One first extends the function u into a function

 $U \in C^{2,\alpha}(\mathbb{R}^2)$ . Then the corresponding inequality on the whole plane, is an easy consequence of the Taylor formula.

#### 6.4.2 The Schauder inequality in a polygon and its consequences

The notation is now that of Section 4.4. Thus  $\Omega$  is a bounded open subset of  $\mathbb{R}^2$  whose boundary  $\Gamma$  is a polygon. To each side  $\Gamma_i$  corresponds a boundary condition which is either the Dirichlet condition or an oblique condition (in the direction of  $\mu_i = \nu_i + \beta_i \tau_i$ ). Given  $f \in C^{0,\sigma}(\bar{\Omega})$ ,  $0 < \sigma < 1$ , we look for a solution  $u \in C^{2,\sigma}(\bar{\Omega})$  of

$$\begin{cases} \Delta u = f & \text{in } \Omega \\ \gamma_{i}u = 0 & \text{in } \Gamma_{i}, \quad j \in \mathcal{D} \end{cases}$$

$$(6,4,2,1)$$

$$\begin{cases} \gamma_{i}\frac{\partial u}{\partial \nu_{i}} + \beta_{i}\frac{\partial}{\partial \tau_{i}} \gamma_{i}u = 0 & \text{on } \Gamma_{i}, \quad j \in \mathcal{N} \end{cases}$$

We begin with the proof of an estimate of the Schauder type namely

$$||u||_{\sigma+2,\infty,\bar{\Omega}} \leq C\{||\Delta u||_{\sigma,\infty,\bar{\Omega}} + ||u||_{1+\sigma,\infty,\bar{\Omega}}\}$$

for all  $u \in C^{2,\sigma}(\bar{\Omega})$  which fulfil the boundary conditions in (6,4,2,1). Here we shall use the same local method of proof as in Subsection 4.3.2, using suitable weighted spaces (depending on  $\rho$ , the distance to the corners):

**Definition 6.4.2.1** We denote by  $P_{\infty}^{m,\sigma}(\Omega)$  the space of all functions u defined in  $\bar{\Omega}$  such that

- (a)  $\rho^{|\alpha|-m-\sigma}D^{\alpha}u$  is continuous and bounded in  $\Omega$  for all  $\alpha$  with  $|\alpha| \leq m$ ,
- (b)  $D^{\alpha}u \in C^{0,\sigma}(\bar{\Omega})$  for  $|\alpha| = m$ .

A Banach norm for this space

$$||u||_{P_{\alpha}^{m,\sigma}(\bar{\Omega})} = \sum_{|\alpha| \leq m} |\lim_{\Omega} b. \, \rho^{|\alpha| - m - \sigma} |D^{\alpha}u|$$

$$+ \sum_{|\alpha| = m} \lim_{x \in \bar{\Omega}, y \in \bar{\Omega}} \frac{|D^{\alpha}u(x) - D^{\alpha}u(y)|}{|x - y|^{\sigma}}.$$

The space  $P_{\infty}^{m,\sigma}(\bar{\Omega})$  is a subspace of  $C^{m,\sigma}(\bar{\Omega})$  while a converse inclusion is given by the following result.

**Theorem 6.4.2.2** Let  $u \in C^{m,\sigma}(\bar{\Omega})$  be such that

$$D^{\alpha}u(S_{j}) = 0 \quad \text{for} \quad |\alpha| \leq m$$

$$j = 1, 2, ..., N; \text{ then } u \in P_{\infty}^{m,\sigma}(\bar{\Omega}).$$

This is an elementary application of Taylor's formula using polar coordinates near each corner (see the proof of Theorem 4.3.2.2).

The basic estimate here is the following.

**Theorem 6.4.2.3** For  $0 < \sigma < 1$  there exists a constant C such that

$$\|u\|_{\mathbf{P}^{2,\sigma}_{\omega}(\bar{\Omega})} \le C\{\|f\|_{\sigma^{\infty},\bar{\Omega}} + \|u\|_{1+\sigma^{\infty},\bar{\Omega}}\}$$
 (6,4,2,2)

for all solutions  $u \in P^{2,\sigma}_{\infty}(\bar{\Omega})$  of problem (6,4,2,1), provided

$$\frac{1}{\pi}(\phi_{j+1}-\phi_j-[2+\sigma]\omega_j)$$

is not an integer for any j, where  $\phi_i = \arctan \beta_i$ ,  $j \in \mathcal{N}$  and  $\phi_i = \pi/2$ ,  $j \in \mathcal{D}$ .

Sketch of the proof We just outline this proof since it is very similar to the proof of Theorem 4.3.2.3. We consider the problem locally with the help of a partition of unity  $\{\eta_i\}_{i=0,\ldots,N}$  on  $\bar{\Omega}$  such that  $\eta_i \in \mathfrak{D}(\mathbb{R}^2)$  for each j and such that

- (a) the support of  $\eta_0$  does not meet any vertex of  $\bar{\Omega}$ .
- (b) the support of  $\eta_i$  contains  $S_i$  and none of the  $S_k$  with  $k \neq j, j = 1, 2, ..., N$ .
- (c) we have

$$\frac{\partial \eta_i}{\partial \nu_k} + \beta_k \frac{\partial \eta_i}{\partial \tau_k} = 0 \qquad \text{on } \Gamma_k$$

for k = i if  $i \in \mathcal{N}$  and for k = i + 1 if  $i + 1 \in \mathcal{N}$ .

Thus we have

$$\|\Delta(\eta_{i}u) - \eta_{i}f\|_{\sigma,\infty,\bar{\Omega}} \leq K_{i} \|u\|_{1+\sigma,\infty,\bar{\Omega}}$$

$$(6,4,2,3)$$

and

$$\begin{cases} \gamma_k(\eta_j u) = 0 & \text{on } \Gamma_k, \quad k \in \mathcal{D} \\ \\ \gamma_k \frac{\partial}{\partial \nu_k} (\eta_j u) + \beta_k \frac{\partial}{\partial \tau_k} \gamma_k(\eta_j u) = 0 & \text{on } \Gamma_k, \quad k \in \mathcal{N}, \end{cases}$$

$$j=1,2,\ldots,N.$$

We can apply inequality (6,3,1,1) to  $\eta_0 u$  and this yields the following inequality:

$$\|\eta_0 u\|_{p^{2,\alpha}(\tilde{\Omega})} \le C_0 \{ \|f\|_{\sigma,\infty,\tilde{\Omega}} + \|u\|_{1+\sigma,\infty,\tilde{\Omega}} \}. \tag{6.4.2.4}$$

We now consider the functions  $\eta_i u$ ,  $1 \le j \le N$ .

Using the polar coordinates with origin at  $S_i$  and setting (for a given j)

$$w(t, \theta) = e^{-(\sigma+2)t}(\widetilde{\eta_j u})(e^{t+i\theta}),$$

Downloaded 10/24/25 to 211.83.126.166. Redistribution subject to SIAM license or copyright; see https://epubs.siam.org/terms-privacy

we obtain a function belonging to  $C^{2,\sigma}(\bar{B})$  where  $B = \mathbb{R} \times [0, \omega_i]$ . In addition w is solution of a boundary value problem in B to which inequality (6,4,1,1) may be applied. This implies the following

$$\|\eta_i u\|_{P^{2,\alpha}(\bar{\Omega})} \le C_i \|\Delta(\eta_i u)\|_{\sigma,\infty,\bar{\Omega}}. \tag{6,4,2,5}$$

Finally inequality (6,4,2,2) is a plain consequence of (6,4,2,3), (6,4,2,4)and (6,4,2,5).

Now Theorem 6.4.2.2 shows that  $P_{\infty}^{2,\sigma}(\bar{\Omega})$  contains a subspace of  $C^{2,\sigma}(\bar{\Omega})$  whose codimension is finite in  $C^{2,\sigma}(\bar{\Omega})$ . Therefore a proof similar to that of Theorem 4.3.2.4 yields the following:

**Theorem 6.4.2.4** Assume that  $0 < \sigma < 1$  and that  $1/\pi(\phi_{i+1} - \phi_i - \phi_i)$  $[2+\sigma]\omega_i$ ) is not an integer for any j. Then there exists a constant C such that

$$\|u\|_{2+\sigma,\infty,\bar{\Omega}} \le C\{\|\Delta u\|_{\sigma,\infty,\bar{\Omega}} + \|u\|_{1+\sigma,\infty,\bar{\Omega}}\} \tag{6,4,2,6}$$

for all  $u \in C^{2,\sigma}(\bar{\Omega})$ , a solution of the problem (6,4,2,1).

We are now going to draw the consequences of Theorem 6.4.2.4. The following existence result is closely related to the content of Subsection 5.1.3. Let us recall briefly some notation (taken from Definition 5.1.3.4):

$$\lambda_{j,m} = \frac{\phi_j - \phi_{j+1} + m\pi}{\omega_i}, \quad j = 1, 2, \dots, N, \quad m \in \mathbb{Z},$$

$$\mathfrak{S}_{j,m}(r_j e^{i\theta_j}) = r_j^{-\lambda_{j,m}} \cos(\lambda_{j,m}\theta_j + \phi_{j+1}) \eta_j(r_j e^{i\theta_j})$$

where  $\lambda_{j,m}$  is not an integer and

$$\mathfrak{S}_{j,m}(r_j e^{i\theta_j}) = r_i^{-\lambda_{j,m}} \{ \ln r_j \cos (\lambda_{j,m} \theta_j + \phi_{j+1}) + \theta_j \sin (\lambda_{j,m} \theta_j + \phi_{j+1}) \} \eta_j (r_j e^{i\theta_j})$$

when  $\lambda_{j,m}$  is an integer. Here again  $r_j$  and  $\theta_j$  are the polar coordinates with origin at  $S_i$ .

The basic result is the following where, for the sake of simplicity, we assume the uniqueness of the solution in  $H^2(\Omega)$ . Sufficient conditions for this uniqueness have been found in Theorem 4.4.1.3.

**Theorem 6.4.2.5** Assume that D is not empty and that at least two of the vectors  $\mu_i$  are linearly independent. Assume in addition that  $(1/\pi)(\phi_{i+1}+\phi_i-[2+\sigma]\omega_i)$  is not an integer for any j. Then for each  $f \in C^{0,\sigma}(\bar{\Omega})$ , with  $0 < \sigma < 1$ , there exists a function u and numbers  $c_{i,m}$ such that

$$u - \sum_{-(\sigma+2) < \lambda_{i,m} < 0} c_{j,m} \mathfrak{S}_{j,m} \in C^{2,\sigma}(\bar{\Omega})$$

and u is solution of the problem (6,4,2,1).

**Proof** We choose  $p \ge 2$  such that  $(\phi_j - \phi_{j+1} + 2\omega_j/q)/\pi$  is not an integer for any j and apply Theorem 4.4.4.11. Since  $f \in L_p(\Omega)$ , there exists a function u and numbers  $c_{i,m}$  such that

$$w = u - \sum_{\substack{1 \le j \le N \\ -2/q < \lambda_{j,m} < 0 \\ \lambda_{j,m} \neq -1}} c_{j,m} \mathfrak{S}_{j,m} \in W_p^2(\Omega)$$

and u is a solution of the problem (6,4,2,1). Now we study w. Clearly we have

$$\begin{cases} \Delta w = f - \sum_{\substack{1 \leq i \leq N \\ -2/q < \lambda_{i,m} < 0 \\ \lambda_{i,m} \neq -1}} c_{j,m} \Delta \mathfrak{S}_{j,m} = g & \text{in } \Omega \\ \\ \gamma_{j} w = 0 & \text{on } \Gamma_{j}, \quad j \in \mathfrak{D} \\ \\ \gamma_{j} \frac{\partial w}{\partial \gamma_{j}} + \beta_{j} \frac{\partial}{\partial \tau_{j}} \gamma_{j} w = 0 & \text{on } \Gamma_{j}, \quad j \in \mathcal{N} \end{cases}$$

because the functions  $\mathfrak{S}_{j,m}$  fulfil all the homogeneous boundary conditions in (6,4,2,1). In addition we have  $g \in C^{0,\sigma}(\bar{\Omega})$  since  $\mathfrak{S}_{j,m}$  is harmonic near  $S_i$  and smooth far from  $S_i$ .

On the other hand  $\Delta$  is one to one (Theorem 4.4.1.3) and has finite index (Theorem 4.4.4.11) from

$$E = \left\{ w \in W_p^2(\Omega); \, \gamma_j w = 0 \text{ on } \Gamma_j, \, j \in \mathcal{D}, \, \gamma_j \frac{\partial w}{\partial \nu_j} + \beta_j \frac{\partial}{\partial \tau_j} \, \gamma_j w = 0 \text{ on } \Gamma_j, \, j \in \mathcal{N} \right\}$$

into  $L_p(\Omega)$ . Let us denote by  $v_1, \ldots, v_M$  a basis of the annihilator (formerly denoted by  $N_q$  in Chapter 4) of  $\Delta E$ . Necessarily we have

$$(g; v_k) = 0, \qquad k = 1, 2, \dots, M.$$
 (6,4,2,7)

We shall now approximate w by smoother solutions. For this purpose we shall approximate g by smoother functions, trying to keep (6,4,2,7).

We apply Lemma 6.3.2.2. This provides us with a sequence  $g_{\nu}$ ,  $\nu = 1, 2, ...$  such that

- (a)  $g_{\nu} \in \mathfrak{D}(\bar{\Omega}),$
- (b)  $\|g_{\nu}\|_{\sigma,\infty,\bar{\Omega}_{+}}$  is bounded when  $\nu \to +\infty$ ,
- (c)  $\|g_{\nu} g\|_{\sigma',\infty,\bar{\Omega}} \to 0$  when  $\nu \to \infty$  for every  $\sigma' < \sigma$ .

Unfortunately there is no reason why  $g_{\nu}$  should be orthogonal to  $v_k, k = 1, 2, ..., M$ . Thus we introduce  $\varphi_k, k = 1, 2, ..., M$  belonging to  $\mathfrak{D}(\Omega)$  and such that

$$(v_k, \varphi_l) = \delta_{k,l}, \qquad k, l = 1, 2, \ldots, M.$$

If we replace  $g_{\nu}$  by  $g_{\nu} - \sum_{k=1}^{M} (g_{\nu}; v_k) \varphi_k$ , we get a new sequence that we

still denote by  $g_{\nu}$ ,  $\nu = 1, 2, ...$ , such that the properties (a)–(c) above still hold and that in addition

$$(g_{\nu}; v_{k}) = 0,$$
  $k = 1, 2, ..., M,$   $\nu = 1, 2 ....$ 

Accordingly there exists for each  $\nu$  a unique  $w_{\nu} \in E$  such that  $\Delta w_{\nu} = g_{\nu}$ . In addition  $w_{\nu} \to w$  in  $W_p^2(\Omega)$  when  $\nu \to +\infty$ .

Next Theorem 5.1.3.5 shows there exist real sequences  $C_{i,m,\nu}$  such that

$$w_{\nu} - \sum_{-1-2/q_1 < \lambda_{j,m} < -2/q} C_{j,m,\nu} \mathfrak{S}_{j,m} \in W^3_{\mathfrak{p}_1}(\Omega)$$

where  $p_1$  has been chosen such that none of the  $[\phi_{j+1} - \phi_j - \omega_j - 2\omega_j/q_1]\pi$  is an integer,  $1/p_1 + 1/q_1 = 1$ . If  $p_1$  is large enough the Sobolev imbedding theorem implies that

$$W_{p_1}^3(\Omega) \subseteq C^{2,\sigma}(\bar{\Omega}).$$

Consequently we have

$$w_{\nu} = \sum_{-(2+\sigma)<\lambda_{i,m}<-2/q} C_{j,m,\nu} \mathfrak{S}_{j,m} \in C^{2,\sigma}(\bar{\Omega}).$$

In other words  $w_{\nu}$  belongs to S, the space

$$\Sigma = \left\{ w \in C^{2,\sigma}(\bar{\Omega}); \, \gamma_j w = 0 \text{ on } \Gamma_j, \, j \in \mathcal{D}, \, \gamma_i \frac{\partial w}{\partial \nu_i} + \beta_j \frac{\partial}{\partial \tau_j} \, \gamma_j w = 0 \text{ on } \Gamma_j, \, j \in \mathcal{N} \right\}$$

augmented with the span of the functions  $\mathfrak{S}_{j,m}$  corresponding to  $-(2+\sigma) < \lambda_{j,m} < -2/q$ ,  $j=1,2,\ldots,N$ . If p is also large enough, the Sobolev imbedding theorem implies that

$$W_p^2(\Omega) \subset C^{1,\sigma}(\bar{\Omega})$$

and consequently we have  $S \subseteq C^{1,\sigma}(\bar{\Omega})$ . A natural Banach norm on S is

$$\|\omega\|_{S} = \inf \left\{ \|\varphi\|_{2+\sigma,\infty,\bar{\Omega}} + \sum_{-(2+\sigma)<\lambda_{i,m}<-2/q} |C_{i,m}| \right\},\,$$

where the infimum is taken over all the possible functions  $\varphi \in \Sigma$  and numbers  $C_{i,m}$  such that

$$w = \varphi + \sum_{-(2+\sigma) < \lambda_{i,m} < -2/q} C_{j,m} \mathfrak{S}_{j,m}.$$

In addition,  $\Sigma$  has a finite codimension in S. It follows from Theorem 6.4.2.4 that there exists a new constant C such that

$$||w||_{S} \le C\{||\Delta w||_{\sigma,\infty,\bar{\Omega}} + ||w||_{1+\sigma,\infty,\bar{\Omega}}\}.$$

We apply this last inequality to  $w_{\nu}$ . It shows that  $w_{\nu}$ ,  $\nu=1,2,\ldots$ , is a bounded sequence in S. Remembering that  $w_{\nu} \to w$  in  $W_{\nu}^{2}(\Omega)$  when  $\nu \to +\infty$ , it is now easy to conclude that  $w \in S$ . Going back to u we see that

it belongs to  $C^{2,\sigma}(\bar{\Omega})$  augmented with the span of all the functions  $\mathfrak{S}_{j,m}$  corresponding (with the exception of  $\lambda_{j,m} = -1$ ) to  $-(2+\sigma) < \lambda_{j,m} < 0$ ,  $j = 1, 2, \ldots, N$ .

Theorem 6.4.2.5 is a Hölder version of Theorem 4.4.4.11. In Section 5.1, we proved a wide extension of Theorem 4.4.4.11, namely Theorem 5.1.3.5, where the behaviour of higher-order derivatives of the solution is investigated. This was achieved by differentiating the original problem (4,1,1) and taking advantage of the very general trace theorem 1.6.1.4. Replacing Theorem 1.6.1.4 by its Hölder version, Theorem 6.2.9 yields the following extension of Theorem 6.4.2.5.

**Theorem 6.4.2.6** Assume that  $\mathfrak{D}$  is not empty and that at least two of the vectors  $\mu_i$  are linearly independent. Assume in addition that

$$(\phi_{j+1}-\phi_j-[k+2+\sigma]\omega_j)$$

is not an integer for any j. Then for each  $f \in C^{k,\sigma}(\bar{\Omega})$  and  $g_j \in C^{k+2,\sigma}(\bar{\Gamma}_i)$ ,  $j \in \mathcal{D}$ ,  $g_j \in C^{k+1,\sigma}(\bar{\Gamma}_i)$   $j \in \mathcal{N}$  with  $0 < \sigma < 1$  such that  $g_j(S_j) = g_{j+1}(S_j)$  when j and  $j+1 \in \mathcal{D}$ , there exists a solution u of

$$\begin{cases} \Delta u = f & \text{in } \Omega \\ \gamma_{i}u = g_{i} & \text{on } \Gamma_{i}, \quad j \in \mathcal{D} \\ \gamma_{i}\frac{\partial u}{\partial \nu_{i}} + \beta_{i}\frac{\partial}{\partial \tau_{i}} \gamma_{i}u = g_{i} & \text{on } \Gamma_{i}, \quad j \in \mathcal{N} \end{cases}$$

and there exist real numbers  $C_{i,m}$  such that

$$u - \sum_{-(k+2+\sigma) < \lambda_{j,m} < 0} C_{j,m} \mathfrak{S}_{j,m} \in C^{k+2,\sigma}(\bar{\Omega}).$$

Remark 6.4.2.7 This statement is also valid when one allows cuts in  $\Omega$  (i.e.  $\omega_i = 2\pi$  for some j).

## A model fourthmorder problem

#### 7.1 Introductory resuits

In this chapter we shall study the properties of the solutions of the first boundary value problem for the biharmonic operator in a plane domain with a polygonal boundary. All the notation concerning the domain n will be the same as in Chapter 4. Our main goal is this: Given f E W(Q) with 1 <p < +oc, k integer , -1, we look for a solution u E Wk + <sup>4</sup> (Q) of

$$\begin{cases} \Delta^2 u = f & \text{in } \Omega \\ \gamma_j u = 0 & \text{on } \Gamma_j, \quad j = 1, 2, \dots, N \\ \gamma_j \frac{\partial u}{\partial \nu_j} = 0 & \text{on } \Gamma_j, \quad j = 1, 2, \dots, N. \end{cases}$$
 (7,1,1)

The reason why it is useful to consider f given in Wp'(Q) will appear clearly in Section 7.4, which is devoted to the related Stokes problem.

We shall start from a variational solution u E *H2(f2)* to problem (7,1,1). Then localizing the problem near one corner, we shall apply the method introduced in Kondratiev (1967a), to study the behaviour of u near the corners. This is done in the framework of the weighted Sobolev spaces which we defined in Subsection 4.3.2. Then the trace theorems of Subsection 1.5.2 allow one to get rid of the weights in a very simple way. Finally we shall extend all the results to the case p 2, by a technique using *a priori* estimates, very similar to those of Subsection 4.3.2.

First let us recall briefly the classical variational approach to the problem (7,1,1). We apply the Lax—Milgram lemma (see Lemma 2.2.1.1) with the following choice of V and a:

$$V = \mathring{H}^{2}(\Omega) = \left\{ u \in H^{2}(\Omega) \mid \gamma_{j} u = \gamma_{j} \frac{\partial u}{\partial \nu_{j}} = 0 \text{ on } \Gamma_{j}, j = 1, 2, \dots, N \right\}$$

and

$$a(u;v) = \sum_{i,j=1}^{2} \int_{\Omega} \frac{\partial^{2} u}{\partial x_{i} \partial x_{j}} \frac{\partial^{2} v}{\partial x_{i} \partial x_{j}} dx$$

It is obvious that

$$a(u; u) = \sum_{i,j=1}^{2} \left\| \frac{\partial^{2} u}{\partial x_{i} \partial x_{j}} \right\|^{2} \ge \alpha \|u\|_{2,2,\Omega}^{2}$$

for  $\alpha > 0$ , due to Poincaré's inequality. Therefore a is a continuous and coercive bilinear form on V. Applying Lemma 2.2.1.1 we get the following result.

**Lemma 7.1.1** For any  $f \in W_p^{-1}(\Omega)$  given, there exists a unique  $u \in \mathring{H}^2(\Omega)$  solution of problem (7,1,1).

Indeed we solve the variational problem:

$$a(u; v) = \langle f; v \rangle$$

for all  $v \in \mathring{H}^2(\Omega)$ . The Sobolev imbedding of  $\mathring{H}^2(\Omega)$  into  $\mathring{W}^1_q(\Omega)$  for any  $q \in ]1, \infty[$ , implies that f is a continuous linear form on V.

In order to be able to study the behaviour of u only near the corners we need a smoothness result away from the corners.

**Theorem 7.1.2** Let  $u \in \mathring{H}^2(\Omega)$  be the solution of the problem (7,1,1) with  $f \in W_p^k(\Omega)$ . Then  $u \in W_p^{k+4}(\Omega \setminus V)$  for any neighbourhood V of the corners.

The smoothness of u inside  $\Omega$  is well known. Indeed we have  $\varphi u \in W^{k+4}_p(\Omega)$  for every  $\varphi \in \mathcal{D}(\Omega)$ . The corresponding smoothness result near the sides  $\Gamma_i$  of  $\Omega$ , deserves a proof. Here, we denote by  $\mathbb{R}^2_+$  the half plane defined by  $x_2 > 0$ ;  $\gamma$  is the trace operator on  $\{x_2 = 0\}$ .

**Lemma 7.1.3** Let  $v \in W^1_p(\mathbb{R}^2_+)$ ,  $l \ge 2$  be a solution with bounded support of

$$\begin{cases} \Delta^2 v = g \in W_p^{l-3}(\mathbb{R}_+^2) \\ \gamma v = \gamma \frac{\partial v}{\partial x_2} = 0. \end{cases}$$

Then  $v \in W_p^{l+1}(\mathbb{R}^2_+)$ 

**Proof** We shall prove that  $\gamma \Delta v \in W_p^{1-1-1/p}(\mathbb{R})$ . The claim will follow from the known results for the Dirichlet problem for the Laplace equation (see Subsection 2.5.1) applied to  $\psi = \Delta v$  and then to v.

First we shall prove a representation formula for v in terms of  $(-\Delta+1)^2v$ ,  $\gamma v$  and  $\gamma \frac{\partial v}{\partial x_2}$ . For this purpose, we approximate v by a sequence of functions  $v_m$ ,  $m=1,2,\ldots$ , such that

$$v_m \in W_p^l(\mathbb{R}^2_+) \cap H^4(\mathbb{R}^2_+)$$

and such that  $v_m \to v$  in  $W_p^1(\mathbb{R}^2_+)$ . Then we write

$$v_m = w_m + E * E * Ph_m$$

where E is the elementary solution for  $-\Delta + 1$  introduced in Subsection 2,

$$h_m = (-\Delta + 1)^2 v_m,$$

P is a continuation operator form  $W_p^{l-3}(\mathbb{R}^2)$  into  $W_p^{l-3}(\mathbb{R}^2)$  and from  $L^2(\mathbb{R}^2)$  into  $L^2(\mathbb{R}^2)$ . Obviously we have

$$\begin{cases} (-\Delta+1)^2 w_m = 0 & \text{in } \mathbb{R}^2_+ \\ \gamma w_m = \gamma v_m - \gamma E * E * Ph_m \in W_p^{t-1/p}(\mathbb{R}) \cap H^{7/2}(\mathbb{R}) \\ \gamma \frac{\partial w_m}{\partial x_2} = \gamma \frac{\partial v_m}{\partial x_2} - \gamma \frac{\partial}{\partial x_2} E * E * Ph_m \in W_p^{t-1-1/p}(\mathbb{R}) \cap H^{5/2}(\mathbb{R}). \end{cases}$$

Let us now perform a Fourier transform in  $x_1$ . We get

$$\begin{cases} (1 + \xi_1^2 - D_2^2)^2 \hat{w}_m = 0 & \text{a.e. in } \mathbb{R}_+^2 \\ \hat{w}_m(\xi_1, 0) = \hat{\varphi}_{0,m}(\xi_1) & \text{a.e. in } \mathbb{R} \\ D_2 \hat{w}_m(\xi_1, 0) = \hat{\varphi}_{1,m}(\xi_1) & \text{a.e. in } \mathbb{R}, \end{cases}$$

where  $\varphi_{0,m} = \gamma w_m$  and  $\varphi_{1,m} = \gamma D_2 w_m$ . It follows that

$$\hat{w}_m(\xi_1, x_2) = \exp\left[-\sqrt{(1 + \xi_1^2)x_2}\right] [\hat{\varphi}_{0,m}(\xi_1)\{1 + x_2\sqrt{(1 + \xi_1^2)}\} + \hat{\varphi}_{1,m}(\xi_1)x_2].$$
ardingly we have

Accordingly we have

$$\Delta \hat{w}_m(\xi_1, 0) = -(1 + 2\xi_1^2)\hat{\varphi}_{0,m} - 2\sqrt{(1 + \xi_1^2)\hat{\varphi}_{1,m}}.$$

In other words, if we denote by T the operator defined as follows:

$$(T\hat{\varphi})(\xi_1) = \sqrt{(1+\xi_1^2)\hat{\varphi}(\xi_1)},$$

we have

$$\gamma \Delta w_m = \varphi_{0,m} - 2T\varphi_{1,m} - 2T^2\varphi_{0,m}$$

Equivalently, we have

$$\gamma \Delta v_m = \gamma \Delta w_m + \gamma \Delta E * E * Ph_m$$
  
=  $(\gamma - 2T\gamma D_2 - 2T^2\gamma)(v_m - E * E * Ph_m) - \gamma \Delta E * E * Ph_m$ .

Taking the limit in m, we obtain finally

$$\gamma \Delta v = (\gamma - 2T\gamma D_2 - 2T^2\gamma)(v - E * E * Ph) - \gamma \Delta E * E * Ph,$$

where  $h = (-\Delta + 1)^2 v$ . Due to the assumptions on v, we conclude that

$$\gamma \Delta v = -(\gamma - 2T\gamma D_2 - 2T^2\gamma + \gamma \Delta)E * E * P\{g - 2\Delta v + v\}.$$

The right-hand side of the identity belongs to  $W_p^{l-1-1/p}(\mathbb{R})$  due to Theorem 2.3.2.1.

*Proof of Theorem 7.1.2* It is a step by step proof using Lemma 7.1.3 at each step.

Assuming first that p is larger than two and that  $f \in W_p^{-1}(\Omega)$  we show that  $u \in W_p^2(\Omega \setminus V)$ . Otherwise there is nothing to prove since  $H^2(\Omega) \subset W_p^2(\Omega)$  when  $p \le 2$ . Let us consider one of the sides  $\Gamma_j$ . After translation and rotation we can assume for convenience that  $\Gamma_j$  lies in  $\{x_2 = 0\}$ . Let us consider  $\eta \in \mathcal{D}(\bar{\Omega})$  a cut-off function whose support is contained in  $\{x_2 \ge 0\}$  and does not meet  $\Gamma_l$  for  $l \ne j$ . Finally let us define v by

$$v = \widetilde{\varphi u}$$
.

Therefore  $v \in H^2(\mathbb{R}^2_+)$ ,  $\gamma v = \gamma \partial v/\partial x_2 = 0$  and

$$\Delta^2 v = \widetilde{\varphi f} + ([\Delta^2; \varphi] u)^{\sim} \in H^{-1}(\mathbb{R}^2_+).$$

Applying Lemma 7.1.3 shows that  $v \in H^3(\mathbb{R}^2_+)$ . Then varying  $\varphi$  and j shows that  $u \in H^3(\Omega \setminus V) \subset W^2_p(\Omega \setminus V)$ .

Now we assume that we know that  $u \in W_p^1(\Omega \setminus V)$ ,  $2 \le l < k+3$  for every neighbourhood V of the corners and we show that this implies that  $u \in W_p^{l+1}(\Omega \setminus V)$ . Indeed we go through the same steps as before. Setting

$$v = \widetilde{\varphi u}$$

we have  $v \in W_p^1(\mathbb{R}^2_+)$ ,  $\gamma v = \gamma \partial v / \partial x_2 = 0$  and

$$\Delta^2 v = \widetilde{\varphi f} + ([\Delta^2; \varphi]u)^{\sim} \in W_p^{l-3}(\mathbb{R}_+^2).$$

Lemma 7.1.3 shows that  $v \in W_p^{l+1}(\mathbb{R}^2_+)$  and therefore varying  $\varphi$  and j shows that  $u \in W_p^{l+1}(\Omega \setminus V)$ .

We conclude by induction.

In order to study the behaviour of u the solution of the problem (7,1,1), near one of the corners, say  $S_i$ , we use the related polar coordinates  $(r_i, \theta_i)$  as in Subsection 4.3.2. We also use a cut-off function  $\eta_i$  which is equal to one near  $S_i$  and has a bounded support which does not intersect any of the  $\bar{\Gamma}_l$  but  $\Gamma_i$  and  $\Gamma_{i+1}$ . Therefore  $u_i = \widehat{\eta_i u}$  is the solution of a boundary value problem in the infinite sector

$$G_i = \{ r_i e^{i\theta_i} \mid r_i > 0, 0 < \theta_i < \omega_i \}.$$

Precisely we have  $u_i \in \mathring{H}^2(G_i)$  and

$$\Delta^2 u_i = (\eta_i \Delta^2 u)^{\sim} + ([\eta_i; \Delta^2] u)^{\sim} = f_i \in W_p^k(G_i)$$

and in addition  $u_i$  has a bounded support. Dropping, for convenience, the subscript j, we are left with the problem of investigating the behaviour of

*u* E *H2(G)* a solution with bounded support of the problem

$$\Delta^2 u = f \in W_p^k(G) \tag{7.1.2}$$

in an infinite plane sector G with angle cv.

#### 7.2 Singular solutions, the 1.*<sup>2</sup>* case

#### 7.2.1 Kondratiev's method in weighted spaces

In this section we shall study the problem (7,1,2) in the framework of the spaces P2(G) defined in Subsection 4.3.2. Briefly, we recall that a function u belongs to Pk(G) iff

$$r^{-k+|\alpha|}D^{\alpha}u\in L_{p}(G), \quad |\alpha|\leq k.$$

Theorem 4.3.2.2 has been useful in comparing the weighted space Pk(G) with the usual Sobolev space Wp(G); unfortunately it excluded the case when p = 2. A corresponding weaker statement, when p = 2, is the following:

#### *Theorem 7.2.1.1 Let u E Hk (G), then u* E P2(G).

The proof of this result is quite similar to the corresponding part of the proof of Theorem 1.4.4.4.

For technical reasons which will become obvious later, it is also convenient to introduce a weighted space of order —1:

#### *Definition* 7.2.1.2 *We denote by PP'(G) the space* of all *the distributions*

$$T = \frac{g_0}{r} + D_1 g_1 + D_2 g_2 \tag{7.2,1,1}$$

*where g*; E *L<sup>p</sup> (G), U i 2.*

A Banach norm on *PP'(G)* is the following.

$$T \mapsto g.l.b. \sum_{j=1}^{2} \|g_j\|_{0,p,G},$$

where the g.l.b. is taken with respect to all the functions g ; , 0 , *j <* 2 belonging to LP (G) and such that (7,2,1,1) holds.

Now let us go back to the problem (7,1,2). Accordingly we consider

$$u \in P_2^2(G)$$

(remember Theorem 7.2.1.1) such that u has a bounded support and such

that

$$\Delta^2 u = f \in P_2^k(G)$$

with  $k \ge -1$  and such that  $\gamma u = \gamma \partial u / \partial \nu = 0$ . We shall denote by R a number such that

$$u(r, \theta) = 0$$
 for  $r \ge R$ .

The Kondratiev method consists in performing the same change of variable  $r = e^t$  as in Subsection 4.3.2 and then solving the problem by Fourier transform with respect to t. Thus we replace the equation  $\Delta^2 u = f$  in the infinite sector G by a similar equation in an infinite strip

$$B = \mathbb{R} \times ]0, \omega[.$$

This change of variable also replaces the weighted Sobolev spaces by ordinary Sobolev spaces. More precisely, the rule is the following.

**Lemma 7.2.1.3** Assume that  $\varphi \in P_p^k(G)$  with  $k \ge -1$  and define  $\psi$  by

$$\psi(t, \theta) = \varphi(e^t \cos \theta, e^t \sin \theta)e^{(-k+2/p)t},$$

then  $\psi \in W_p^k(B)$ .

**Proof** This result is rather obvious when k is nonnegative. Consequently we leave its proof to the reader. However the case when k is -1 is less obvious and deserves a detailed proof.

From Definition 7.2.1.2 we know that

$$\varphi = \frac{g_0}{r} + D_1 g_1 + D_2 g_2$$

where  $g_j \in L_p(G)$ ,  $0 \le j \le 2$ . Using polar coordinates this means that

$$\varphi = \frac{k_0}{r} + \frac{\partial k_1}{\partial r} + \frac{1}{r} \frac{\partial k_2}{\partial \theta},$$

where  $k_j \in L_p(G)$ , j = 0, 1, 2. Consequently we have

$$\psi(t; \theta) = e^{(2/p)t} \left\{ k_0(e^t \cos \theta, e^t \sin \theta) - \frac{2}{p} k_1(e^t \cos \theta, e^t \sin \theta) \right\}$$

$$+ D_t \{ e^{(2/p)t} k_1(e^t \cos \theta, e^t \sin \theta) \}$$

$$+ D_\theta \{ e^{(2/p)t} k_2(e^t \cos \theta, e^t \sin \theta) \}.$$

Here, each function

$$t, \theta \mapsto e^{(2/p)t}k_i(e^t \cos \theta, e^t \sin \theta), \qquad j = 0, 1, 2$$

belongs to  $L_p(B)$ . This clearly implies that  $\psi$  belongs to  $W_p^{-1}(B)$ .

Since u belongs to  $P_2^2(G)$  by assumption, we set

$$v(t,\theta) = e^{-t}u(e^{t}\cos\theta; e^{t}\sin\theta)$$
 (7,2,1,2)

in accordance with Lemma 7.2.1.3. Hence

$$v \in \mathring{H}^2(B) \tag{7.2,1,3}$$

since, in addition, v and  $\partial v/\partial \theta$  have zero traces on  $F_0 = \mathbb{R} \times \{0\}$  and  $F_1 = \mathbb{R} \times \{\omega\}$ . The equation of v is

$$(D_t^4 - 2D_t^2 + 1)v + 2(D_t^2 + 1)D_\theta^2 v + D_\theta^4 v = g$$
 (7,2,1,4)

in B where

$$g(t, \theta) = e^{3t} f(e^t \cos \theta; e^t \sin \theta). \tag{7.2,1,5}$$

We observe that the assumption that f belongs to  $P_2^k(G)$  implies that

$$e^{-(k+2)t}g \in H^k(B).$$
 (7,2,1,6)

Finally, since u vanishes for  $r \ge R$ , it follows that v vanishes for  $t \ge \log R$ . We recall that we define the partial Fourier transform of v with respect to t by

$$\hat{v}(\tau,\theta) = \frac{1}{\sqrt{(2\pi)}} \int_{\infty}^{+\infty} e^{-it\tau} v(t,\theta) dt.$$
 (7,2,1,7)

Here  $\tau$  is the dual variable of t and is possibly a complex number. From (7,2,1,3) and from the fact that v vanishes for  $t \ge \log R$ , we derive that  $\hat{v}$  is defined for Im  $\tau \ge 0$ , analytic in Im  $\tau > 0$  and that

$$\left\{ \sum_{j=0}^{2} \int_{-\infty}^{+\infty} |\tau_{1} + i\tau_{2}|^{4-2j} \|\hat{v}(\tau_{1} + i\tau_{2}, \theta)\|_{j,2,]0,\omega[}^{2} d\tau_{1} \right\}^{1/2} \leq R^{\tau_{2}} \|v\|_{2,2,B}$$

$$(7,2,1,8)$$

for every  $\tau_2 \ge 0$ . Here we have applied the Paley-Wiener and Plancherel theorems.

In addition the function  $\theta \mapsto \hat{v}(\tau, \theta)$  is, for almost every  $\tau_1(\tau = \tau_1 + i\tau_2, \tau_2 \ge 0)$ , an element of the space  $\mathring{H}^2(]0, \omega[)$ . This implies four boundary conditions on v (valid for every  $\tau$  with Im  $\tau > 0$  since  $\hat{v}$  is analytic).

$$\hat{v}(\tau, 0) = \hat{v}(\tau, \omega) = D_{\theta}\hat{v}(\tau, 0) = D_{\theta}\hat{v}(\tau, \omega) = 0. \tag{7.2.1.9}$$

From (7,2,1,4), we derive the equation of  $\hat{v}$ :

$$(\tau^4 + 2\tau^2 + 1)\hat{v} + (2 - 2\tau^2)D_{\theta}^2\hat{v} + D_{\theta}^4\hat{v} = \hat{g}. \tag{7,2,1,10}$$

For each  $\tau$  (7,2,1,10) and (7,2,1,9) define a two-point boundary value problem for a fourth-order differential equation in  $]0, \omega[$ . Solving such a problem is easy. It is uniquely solvable away from a discrete set of characteristic values for  $\tau$ . This will make  $\hat{v}$  an analytic function of  $\tau$  in

any subset E of the complex plane where  $\hat{g}$  is an analytic function of  $\tau$ , away from the characteristic values. Eventually we take advantage of (7,2,1,6), from which we derive that  $\hat{g}$  is defined for Im  $\tau \ge -(k+2)$ . This will provide us with an analytic continuation for  $\hat{v}$  which implies more regularity for v.

Now we shall make all the previous outline more precise, step by step. First we investigate how well posed the problem (7,2,1,9), (7,2,1,10) is. The characteristic equation for the differential equation is

$$p^4 + 2(1 - \tau^2)p^2 + (\tau^4 + 2\tau^2 + 1) = 0$$

and its roots are  $p = \pm \tau \pm i$ . Accordingly, a fundamental system of solutions for the fourth-order equation is

 $\sin \theta \sinh \tau \theta$ ,  $\sin \theta \cosh \tau \theta$ ,  $\cos \theta \sinh \tau \theta$ ,  $\cos \theta \cosh \tau \theta$ 

when  $\tau$  is different from 0 and  $\pm i$ . In the particular case when  $\tau = 0$ , a fundamental system of solutions is

$$\sin \theta$$
,  $\cos \theta$ ,  $\theta \sin \theta$ ,  $\theta \cos \theta$ 

while in the particular case when  $\tau = \pm i$ , a fundamental system of solutions is

1,  $\theta$ ,  $\sin 2\theta$ ,  $\cos 2\theta$ .

For each  $\tau$ , a Fredholm alternative holds; namely, for a given  $\hat{g}$  the problem (7,2,1,9) (7,2,1,10) has a unique solution iff the corresponding homogeneous problem has only the zero solution. In other words we are reduced to checking whether the following problem has only the zero solution:

$$\begin{cases} (\tau^4 + 2\tau^2 + 1)\psi + 2(1 - \tau^2)\psi'' + \psi^{(IV)} = 0 & \text{in } ]0, \omega[\\ \psi(0) = \psi(\omega) = \psi'(0) = \psi'(\omega) = 0. & (7,2,1,11) \end{cases}$$

Later we shall call regular the values of  $\tau$  for which (7,2,1,11) has only the zero solution.

**Lemma 7.2.1.4** The problem (7,2,1,11) has only the zero solution in the following cases

(a)  $\tau$  is not a root of the characteristic equation

$$\sinh^2(\tau\omega) = \tau^2 \sin^2 \omega \tag{7,2,1,12}$$

- (b)  $\tau = 0$ .
- (c)  $\tau = \pm i$  if  $\omega \neq \tan \omega$  and  $\omega \neq 2\pi$ .

<sup>†</sup> When  $\tau = 0$ ,  $p = \pm i$  are double roots and when  $\tau = \pm i$ , p = 0 is double root.

Consequently the characteristic values are the roots of (7,2,1,12) except 0 and  $\pm i$  in the general case and except 0 when  $\tan \omega = \omega$ .

**Proof** When  $\tau$  is neither zero nor  $\pm i$ ,  $\psi$  solution of the equation in (7,2,1,11) is of the following form

$$\psi = \sin \theta [\alpha \sinh \tau \theta + \beta \cosh \tau \theta] + \cos \theta [\gamma \sinh \tau \theta + \delta \cosh \tau \theta]$$

where  $\alpha$ ,  $\beta$ ,  $\gamma$ ,  $\delta$  are complex numbers. Substituting  $\psi$  in the boundary conditions, one finds an homogeneous system of four equations in the four unknowns  $\alpha$ ,  $\beta$ ,  $\gamma$ ,  $\delta$ . The corresponding determinant is

$$\sinh^2(\tau\omega) - \tau^2\sin^2\omega$$
.

When  $\tau = 0$ ,  $\psi$  is of the particular form

$$\psi = \sin \theta [\alpha + \beta \theta] + \cos \theta [\gamma + \delta \theta].$$

The determinant is now

$$\sin^2 \omega - \omega^2$$
,

which is not zero.

Finally when  $\tau = \pm i$ ,  $\psi$  is of the particular form

$$\psi = \alpha + \beta \theta + \gamma \sin 2\theta + \delta \cos 2\theta.$$

The corresponding determinant is proportional to

$$\sin \omega \left[ \sin \omega - \omega \cos \omega \right].$$

This is not zero unless  $\omega = \tan \omega$  or  $2\pi$ .

In each case,  $\alpha$ ,  $\beta$ ,  $\gamma$ ,  $\delta$  are all zero and thus  $\psi$  vanishes unless the determinant is zero.

Let us denote by D the set of all the regular values (i.e. the noncharacteristic values) for the problem (7,2,1,10) (7,2,1,9). D is the complement of a discrete set in the complex plane. When  $\tau \in D$  the problem has a unique solution

$$\hat{v} \in \mathring{H}^2(]0, \omega[)$$

provided  $\hat{g}$  is given in  $H^{-2}(]0, \omega[)$ . In addition, let E be any open subset of the complex plane such that

$$\tau \mapsto \hat{g}$$

is analytic from E into  $H^{-2}(]0, \omega[)$ , then

$$\tau \mapsto \hat{v}$$

is analytic from  $D \cap E$  into  $\mathring{H}^2(]0, \omega[)$ . Let us now find a subset E.

We recall that g, like u, vanishes for  $t > \log R$ . Applying the Paley-Wiener and Plancherel theorems, we derive from (7,2,1,6) that, when k is nonnegative g is defined for Im  $\tau \ge -(k+2)$ , analytic for Im  $\tau > -(k+2)$  and in addition that

$$\left\{ \sum_{j=0}^{k} \int_{-\infty}^{+\infty} |\tau_{1} + i(\tau_{2} + k + 2)|^{2(k-j)} \|\hat{g}(\tau_{1} + i\tau_{2}, \theta)\|_{j,2,]0,\omega[}^{2} d\tau_{1} \right\}^{1/2} \\
\leq R^{\tau_{2} + (k+2)} \|e^{-(k+2)t}g\|_{k,2,B}. \tag{7.2.1.13}$$

A similar result when k = -1 deserves a detailed proof.

**Lemma 7.2.1.5** Assume that  $e^{-t}g \in H^{-1}(B)$  and that g vanishes for t > R. Then  $\hat{g}$  is defined in  $\text{Im } \tau \ge -1$ , analytic in  $\text{Im } \tau \ge -1$  with values in  $H^{-1}(]0, \omega[)$ . Furthermore for each R' > R, there exists  $\hat{g}_1$  and  $\hat{g}_2$  such that

$$\hat{g} = \hat{g}_1 + \hat{g}_2$$

where  $\hat{g}_1$ , respectively  $\hat{g}_2$ , is defined in Im  $\tau \ge -1$ , analytic in Im  $\tau \ge -1$  with values in  $L_2(]0, \omega[)$ , respectively  $H^{-1}(]0, \omega[)$ . In addition there exists a constant C such that

$$\left\{ \int_{\infty}^{+\infty} [|\tau_{1} + i\tau_{2} + i|^{-2} \|\hat{g}_{1}(\tau_{1} + i\tau_{2}, \theta)\|_{0,2,]0,\omega[}^{2} + \|\hat{g}_{2}(\tau_{1} + i\tau_{2}, \theta)\|_{-1,2,]0,\omega[}^{2}] d\tau_{1} \right\}^{1/2} \leq CR^{r(\tau_{2}+1)}$$
for every  $\tau_{2} \geq -1$ .
$$(7,2,1,14)$$

**Proof** The assumption that  $e^{-t}g \in H^{-1}(B)$  implies that

$$e^{-t}g = f_0 + D_t f_1 + D_{\theta} f_2 \tag{7.2.1.15}$$

where  $f_i \in L_2(B)$ ,  $0 \le j \le 2$ . Now we fix R' > R; then with the help of a cut-off function we can modify the  $f_i$  in order that they vanish for  $t \ge R'$ . Taking the Fourier transform in (7,2,1,15) we derive that

$$\hat{g}(\tau - i, \theta) = \hat{f}_0(\tau, \theta) + i\tau \hat{f}_1(\tau, \theta) + D_{\theta}\hat{f}_2(\tau, \theta),$$

where the  $f_i$  are defined in Im  $\tau \ge 0$ , analytic in Im  $\tau > 0$  and there exists a constant  $C_1$  such that:

$$\int_{0}^{+\infty} \|\hat{f}_{j}(\tau_{1} + i\tau_{2}, \theta)\|_{0,2,]0,\omega[}^{2} d\tau_{1} \leq C_{1}R'^{2\tau_{2}}, \qquad 0 \leq j \leq 2$$

for every  $\tau_2 \ge 0$ . One obtains the desired result by setting

$$\begin{split} \hat{g}_1(\tau,\,\theta) &= \mathrm{i}(\tau + \mathrm{i})\hat{f}_1(\tau + \mathrm{i},\,\theta) \\ \hat{g}_2(\tau,\,\theta) &= \hat{f}_0(\tau + \mathrm{i},\,\theta) + D_\theta f_2(\tau + \mathrm{i},\,\theta). \end{split}$$

Observe that this method of proof lets  $\hat{g}_1$  and  $\hat{g}_2$  depend on R'.

Going back to the problem (7,2,1,9) (7,2,1,10), we know that  $\hat{v}$  is analytic in Im  $\tau > 0$ , while  $\hat{g}$  is analytic in Im  $\tau > -(k+2)$ . Consequently  $\hat{v}$  has an analytic continuation to the domain

$$\{-(k+2) < \operatorname{Im} \tau\} \cap D$$

where D is the set of the regular values defined above. We still denote this continuation by  $\hat{v}$ . Furthermore, from (7,2,1,13), (7,2,1,14) we shall derive some growth condition on  $\hat{v}$ .

**Lemma 7.2.1.6** Assume that (7,2,1,3), (7,2,1,6), (7,2,1,9) and (7,2,1,10) hold and that v vanishes for  $t \ge \log R$ . Then there exists K such that

$$\underset{-(k+2) \leqslant \tau_2 \leqslant 0}{\text{l.u.b.}} \left\{ \int_{|\tau_1| \ge K} \sum_{i=0}^{k+4} |\tau_1|^{2(k+4-i)} \| \hat{v}(\tau_1 + i\tau_2, \theta) \|_{j,2,]0,\omega[}^2 d\tau_1 \right\} < \infty.$$
 (7,2,1,16)

**Proof** The main step is to find a bound for  $\hat{v}$  in term of  $\hat{g}$  at least for large values of  $|\tau_1|$ . This is straightforward for k=-1 and k=0. Indeed we calculate  $\langle D_{\theta}^{2l}\hat{v}; \hat{g} \rangle$  for l=0,1,2, where the brackets denote the pairing between distributions and functions in  $]0, \omega[$ . Integrating by parts, we find a constant C and a number K such that

$$\sum_{j=0}^{k+4} |\tau_1|^{k+4-j} \|\hat{v}\|_{j,2,]0,\omega[} \le C \|\hat{g}\|_{k,2,]0,\omega[}$$
 (7,2,1,17)

for 
$$k = -2, -1, 0, |\tau_1| \ge K, -(k+2) \le \tau_2 \le 0.$$

It is not possible to estimate further derivatives of  $\hat{v}$  by mere integration by parts. We shall prove the corresponding inequality later.

**Lemma 7.2.1.7** For every nonnegative integer k, there exists a constant C and a number K such that the solution  $\hat{v}$  of (7,2,1,9) (7,2,1,10) verifies

$$\sum_{j=0}^{k+4} |\tau_1|^{k+4-j} \|\hat{v}\|_{j,2,]0,\omega[} \le C \sum_{j=0}^{k} |\tau_1|^{k-j} \|\hat{g}\|_{j,2,]0,\omega[}$$
 (7,2,1,18)

for 
$$|\tau_1| \ge K$$
,  $-(k+2) \le \tau_2 \le 0$ .

It is clear that (7,2,1,16) follows from (7,2,1,13) and (7,2,1,18) when k is nonnegative. Now let us look at the case when k is -1. The inequality (7,2,1,17) implies in particular that the problem (7,2,1,9) (7,2,1,10) is well posed for  $|\tau_1| \ge K$ ,  $-1 \le \tau_2 \le 0$ . Thus we can write

$$\hat{v} = \hat{v}_1 + \hat{v}_2$$

where

$$(\tau^4 + 2\tau^2 + 1)\hat{v}_i + (2 - 2\tau^2)D_{\theta}^2\hat{v}_i + D_{\theta}^4\hat{v}_i = \hat{g}_i$$

*j* = 1, 2, with g l and g2 given by Lemma 7.2.1.5 and i3, *v2* fulfilling the boundary conditions (7,2,1,9). The inequality (7,2,1,16) follows by applying (7,2,1,17) with *k=0* to <sup>v</sup>1 and with *k=-1* to v<sup>2</sup> . <sup>n</sup>

*Proof of Lemma 7.2.1.7* First we consider an auxiliary problem on the half-line R+ = 10, *oo[: w E* H*2*((t+) is a solution of

$$\tau_1^4 w - 2\tau_1^2 w'' + w^{(iv)} = h \qquad \text{in } \mathbb{R}_+. \tag{7,2,1,19}$$

It is clear that w *E* H" <sup>4</sup>(R) when g is given in H" (R). In addition, for *T1* = 1, there exists a constant K*k* such that

$$||w||_{k+4,2,\mathbb{R}_{+}} \le K_{k} ||h||_{k,2,\mathbb{R}_{+}}.$$
 (7,2,1,20)

Then we observe that replacing 0 by 0/1T <sup>1</sup> 1 reduces the equation (7,2,1,19) to a similar one where T, = 1. Performing this change of variable in (7,2,1,20) leads to

$$\sum_{j=0}^{k+4} |\tau_1|^{k+4-j} \|w\|_{j,2,\mathbb{R}_+} \le K_k' \sum_{j=0}^k |\tau_1|^{k-j} \|h\|_{j,2,\mathbb{R}_+}$$
 (7,2,1,21)

for all T, E !R.

Next it is easy to check that the same inequality holds for w <sup>E</sup> H2(]0, i0[) solution of the same equation in the interval ]0, w[. (Use a cut-off function and continuation by zero, then apply inequality (7,2,1,21)).

Finally we can consider v solution of (7,2,1,9) (7.2.1.10). We observe that w = v is solution of

$$\tau_1^4 \hat{v} - 2\tau_1^2 \hat{v}'' + \hat{v}^{(iv)} = h$$
 in  $]0, \omega[,$ 

where

$$h = \hat{g} + (\tau_1^4 - \tau^4 - 2\tau^2 - 1)\hat{v} + (2\tau^2 - 2 - 2\tau_1^2)D_{\theta}^2\hat{v}.$$

Consequently we can apply the previous inequality to v. We get

$$\begin{split} &\sum_{i=0}^{k+4} |\tau_1|^{k+4-i} \|\hat{v}\|_{j,2,]0,\omega[} \leq K_k'' \\ &\sum_{j=0}^{m} |\tau_1|^{k-i} \{ \|\hat{g}\|_{j,2,]0,\omega[} + |\tau_1|^3 \|\hat{v}\|_{j,2,]0,\omega[} + |\tau_1| \|\hat{v}\|_{j+2,2,]0,\omega[} \} \end{split}$$

since we assume that *—(k +* 2) ; T2 ; 0. It is now clear that we can choose K large enough such that (7,2,1,18) holds. n

Remark 7.2.1.8 The inequality (7,2,1,18) is also a particular case of some more general inequalities proved in Agranovitch and Višik (1964).

We shall now consider the continuation  $\hat{v}$  of the solution  $\hat{v}$  of problem (7,2,1,9) (7,2,1,10) on the horizontal line

$$\tau_2 = -(k+2)$$
.

The function  $\hat{v}$  is well defined almost everywhere on this line provided there is no characteristic value (for the problem (7,2,1,11)). In addition, it follows from (7,2,1,16) that

$$\int_{-\infty}^{+\infty} \sum_{j=0}^{k+4} |\tau_1|^{2(k+4-j)} \|\hat{v}(\tau_1 - \mathbf{i}[k+2])\|_{j,2,]0,\omega[}^2 d\tau_1 < +\infty.$$

This inequality implies that

$$\tau_1 \mapsto \hat{v}(\tau_1 - i[k+2])$$

is the Fourier transform of a function

$$w(t, \theta) = \frac{1}{\sqrt{(2\pi)}} \int_{-\infty}^{+\infty} e^{it\tau_1} \hat{v}(\tau_1 - i[k+2], \theta) d\tau_1$$

which belongs to  $H^{k+4}(B)$ .

It is easy to compare v with w. Indeed from (7,2,1,7) it follows that

$$v(t,\theta) = \frac{1}{\sqrt{(2\pi)}} \int_{-\infty}^{+\infty} e^{it\tau_1} \hat{v}(\tau_1,\theta) d\tau_1$$

and by Cauchy's formula that

$$v(t, \theta) = e^{t(k+2)}w(t, \theta) + \sum_{-(k+2)<\text{Im }\tau_m<0} s_m(t, \theta)$$
 (7,2,1,22)

where  $\tau_m$ , m = 1, 2, ... denotes the sequence of the characteristic values and  $s_m$  is the residue of

$$\tau \mapsto i\sqrt{(2\pi)}e^{it\tau}\hat{v}(\tau,\theta)$$

at  $\tau = \tau_m$ .

We shall now calculate these residues. Some additional understanding of the characteristic values is necessary for this purpose.

**Lemma 7.2.1.9** Let  $\tau_m$  be any characteristic value of the problem (7,2,1,11); then for  $\tau=\tau_m$  the solutions of the problem (7,2,1,11) span a one-dimensional space. In addition let  $\hat{g}$  be any analytic function in a neighbourhood of  $\tau_m$ , with values in  $H^{-2}(]0,\omega[)$ , then the corresponding solution of the problem (7,2,1,9) (7,2,1,10) has the following Laurent

Downloaded 10/24/25 to 211.83.126.166. Redistribution subject to SIAM license or copyright; see https://epubs.siam.org/terms-privacy

expansion near  $\tau_m$ :

(a) 
$$\hat{v}(\tau,\theta) = \frac{\psi_m(\theta)}{\tau - \tau_m} + \hat{w}_m(\tau,\theta)$$
 (7,2,1,23)

where  $\psi_m$  is a solution of (7,2,1,11) with  $\tau = \tau_m$ , and  $\hat{w}_m$  is an analytic function near  $\tau_m$ , with values in  $H^2(]0, \omega[)$ , provided  $\tau_m$  is a simple root of (7,2,1,12).

(b) 
$$\hat{v}(\tau, \theta) = \frac{\psi_m(\theta)}{(\tau - \tau_m)^2} + \frac{\varphi_m(\theta)}{\tau - \tau_m} + \hat{w}_m(\tau, 0)$$
 (7,2,1,24)

with similar properties for  $\psi_m$  and  $\hat{w}_m$ , while  $\varphi_m$  is a solution of

$$(\tau_m^4 + 2\tau_m^2 + 1)\varphi_m + 2(1 - \tau_m^2)\varphi_m'' + \varphi_m^{(iv)}$$
  
=  $-4\tau_m(\tau_m^2 + 1)\psi_m + 4\tau_m\psi_m''$  (7,2,1,25)

in ]0,  $\omega$ [, with the boundary conditions (7,2,1,9) provided  $\tau_m$  is a double root of (7,2,1,12).

Finally, the equation (7,2,1,12) has no root with a multiplicity larger than two.

**Proof** It is readily seen that any solution of the equation is (7,2,1,11) which fulfils the boundary conditions at zero, is a linear combination of  $u_1$  and  $u_2$  defined below:

$$u_1(\tau, \theta) = \frac{\sin \theta \sinh \tau \theta}{\tau}, \qquad \tau \neq 0$$

$$u_1(0, \theta) = \theta \sin \theta$$

$$u_2(\tau, \theta) = \frac{1}{\tau^2 + 1} \left\{ \frac{\cos \theta \sinh \tau \theta}{\tau} - \sin \theta \cosh \tau \theta \right\}, \qquad \tau \neq 0, \pm$$

$$u_2(0, \theta) = \theta \cos \theta - \sin \theta$$

$$u_2(\pm i, \theta) = \frac{1}{2} \left\{ \frac{\sin 2\theta}{2} - \theta \right\}.$$

These functions are entire analytic functions of  $\tau$ . Then it follows from the general results about the two-point boundary value problems that  $\hat{v}$ , the solution of (7,2,1,9) (7,2,1,10), is such that  $d\hat{v}$  is analytic near  $\tau_m$ , where d is the determinant

$$d(\tau) = u_1(\tau, \omega) D_{\theta} u_2(\tau, \omega) - u_2(\tau, \omega) D_{\theta} u_1(\tau, \omega)$$
$$= \frac{1}{(\tau^2 + 1)} \left[ \sin^2 \omega - \frac{\sinh^2 \tau \omega}{\tau^2} \right].$$

The zeros of d are described in Lemma 7.2.1.4. They are either the

solutions of the equation (7,2,1,12) with  $\tau \neq 0$ ,  $\pm i$  or  $\pm i$  in the particular case when  $\omega = \tan \omega$  or  $\omega = 2\pi$ . In addition the order of the zeros of d is the multiplicity of the solutions of (7,2,1,12) when  $\tau \neq 0$ ,  $\pm i$ , while  $\pm i$  is a simple zero of d when  $\tan \omega = \omega$  or  $\omega = 2\pi$ .

Differentiating the identity (7,2,1,12) with respect to  $\tau$  shows that the multiplicity of the solutions is at most two.

If we assume that d has a simple zero at  $\tau_m$ , then  $\hat{v}$  has a simple pole at  $\tau_m$  and consequently (7,2,1,23) holds. Applying the differential operator

$$(\tau^4 + 2\tau^2 + 1) + (2 - 2\tau^2)D_{\theta}^2 + D_{\theta}^4 = L(\tau, D_{\theta})$$

to both sides of this identity multiplied by  $(\tau - \tau_m)$  yields

$$(\tau - \tau_m)\hat{g} = L(\tau, D_\theta)\psi_m + (\tau - \tau_m)L(\tau, D_\theta)\hat{w}_m.$$

It follows obviously that  $L(\tau_m, D_\theta)\psi_m = 0$ . The boundary conditions on  $\psi_m$  are obvious and thus  $\psi_m$  is a solution of the homogeneous problem (7,2,1,11) at  $\tau = \tau_m$ .

Let us now assume that d has a double zero at  $\tau_m$ , then  $\hat{v}$  has a double pole at  $\tau_m$  and consequently (7,2,1,24) holds. Applying the differential operator  $L(\tau, D_{\theta})$  and multiplying by  $(\tau - \tau_m)^2$ , we obtain

$$(\tau - \tau_m)^2 \hat{g} = L(\tau, D_\theta) \psi_m + (\tau - \tau_m) L(\tau, D_\theta) \varphi_m + (\tau - \tau_m)^2 L(\tau, D_\theta) \hat{w}_m.$$

Again it is obvious that  $L(\tau_m, D_\theta)\psi_m = 0$  and that  $\psi_m$  fulfils the boundary conditions in (7,2,1,11). Next we have

$$(\tau - \tau_m)\hat{\mathbf{g}} = \frac{L(\tau; D_\theta)\psi_m}{\tau - \tau_m} + L(\tau; D_\theta)\varphi_m + (\tau - \tau_m)L(\tau, D_\theta)\hat{\mathbf{w}}_m,$$

and consequently

$$L(\tau;D_{\theta})\varphi_{m}=-\frac{L(\tau;D_{\theta})-L(\tau_{m};D_{\theta})}{\tau-\tau_{m}}\,\psi_{m}+(\tau-\tau_{m})\{\hat{g}-L(\tau,D_{\theta})\hat{w}_{m}\}.$$

Taking the limit when  $\tau \to \tau_m$  implies the equation for  $\psi_m$ , namely

$$L(\tau_m, D_\theta)\varphi_m = -4\tau_m(\tau_m^2 + 1)\psi_m + 4\tau_m\psi_m''$$

Again, the boundary conditions on  $\varphi_m$  are obvious.

Remark 7.2.1.10 The existence of  $\varphi_m$  solution of (7,2,1,25) with the boundary conditions (7,2,1,9) is not obvious since  $\tau_m$  is a characteristic value. Accordingly we must check that the right-hand side

$$-4\tau_{m}(\tau_{m}^{2}+1)\psi_{m}+4\tau_{m}\psi_{m}''=-L_{\tau}'(\tau_{m};D_{\theta})\psi_{m}$$

is orthogonal to the kernel of the transposed problem. In other words we must check that this function is orthogonal to every function  $\eta$  which is a

316 A MODEL FOURTH-ORDER PROBLEM

solution of

$$\begin{cases} L(\bar{\tau}_m; D_{\theta}) \eta = 0 & \text{in } ]0, \omega[\\ \eta(0) = \eta(\omega) = \eta'(0) = \eta'(\omega) = 0. \end{cases}$$

An auxiliary result for this verification, is the following.

*Lemma 7.2.1.11 The double solutions of the equation* (7,2,1,12) *are* all imaginary.

*Proof* All the solutions of (7,2,1,12) are solutions of either

$$\sinh(\tau\omega) = \tau \sin \omega \tag{7,2,1,26}$$

[•j

$$\sinh(\tau\omega) = -\tau \sin \omega \tag{7,2,1,27}$$

Let us consider the first of these equations, for instance, and assume that T, is a double root. We have

$$\sinh (\tau_m \omega) = \tau_m \sin \omega,$$

together with the differentiated equation

$$\omega \cosh(\tau_m \omega) = \sin \omega$$
.

If we denote by ^", and re <sup>m</sup> the real part and imaginary part of T►n, respectively, we derive

$$\begin{cases} \sinh (\xi_m \omega) \cos (\eta_m \omega) = \xi_m \sin \omega \\ \cosh (\xi_m \omega) \sin (\eta_m \omega) = \eta_m \sin \omega \\ \omega \cosh (\xi_m \omega) \cos (\eta_m \omega) = \sin \omega \\ \sinh (\xi_m \omega) \sin (\eta_m \omega) = 0. \end{cases}$$

From the last equation, it follows that we have either m =0 or m = kir/w, where k is an integer. Assuming that m 0 and accordingly that lim = kir/w, it follows from the second equation that k = 0, i.e. ^ =0. Then the first equation yields

$$\frac{\sinh\left(\xi_{m}\omega\right)}{\xi_{m}\omega}=\frac{\sin\omega}{\omega}.$$

This equation is impossible since we have j t)/tL % 1 for every t, while we have ( (sin w )/w 1 < 1.

In conclusion, all the double roots are such that tm =0. <sup>n</sup>

Since -r" a double root, is imaginary, we have *<sup>T</sup>m = — <sup>T</sup>m* and conse-

quently  $L(\tau_m; D_\theta) = L(\tilde{\tau}_m; D_\theta)$ . Going back to the existence condition on  $\varphi_m$  we must check that  $L'_{\tau}(\tau_m, D_\theta)\psi_m$  is orthogonal to all the solutions of the problem (7,2,1,11) with  $\tau = \tau_m$ .

Let  $u(\tau, \theta)$  be the solution of

$$\begin{cases} L(\tau; D_{\theta})u = 0 & \text{in } ]0, \omega[, \\ u(\tau, 0) = 0, \\ D_{\theta}u(\tau, 0) = 0, \\ u(\tau, \omega) = 0, \\ D_{\theta}^{2}u(\tau, 0) = 1. \end{cases}$$

It is easily seen that u exists and is unique near each characteristic value  $\tau_m$ . The function  $\psi_m(\theta)$  is a scalar multiple of  $u(\tau_m, \theta)$ , since the space of the solutions of the problem (7,2,1,11) is one-dimensional. Let us differentiate with respect to  $\tau$  the identity

$$\int_0^{\omega} L(\tau; D_{\theta}) u(\tau; \theta) \overline{u(\tau; \theta)} d\theta = 0.$$

This yields

$$\int_0^\omega L_\tau'(\tau;\,D_\theta)u(\tau;\,\theta)\overline{u(\tau;\,\theta)}\,\mathrm{d}\theta + \int_0^\omega L(\tau;\,D_\theta)u_\tau'(\tau,\,\theta)\overline{u(\tau,\,\theta)}\,\mathrm{d}\theta = 0.$$

At  $\tau = \tau_m$ , we obtain

$$\begin{split} & \int_{0}^{\omega} L_{\tau}'(\tau_{m}, D_{\theta}) u(\tau_{m}, \theta) \overline{u(\tau_{m}, \theta)} \, \mathrm{d}\theta \\ & + \int_{0}^{\omega} u_{\tau}'(\tau_{m}, \theta) \overline{L(\tau_{m}; D_{\theta}) u(\tau_{m}; \theta)} \, \mathrm{d}\theta = 0. \end{split}$$

Consequently  $L'_{\tau}(\tau_m, D_{\theta})u(\tau_m; \theta)$  is orthogonal to  $u(\tau_m, \theta)$  and the same way  $L'_{\tau}(\tau_m, D_{\theta})\psi_m(\theta)$  is orthogonal to  $\psi_m$  in  $L_2(]0, \omega[)$ . This shows that the solution  $\varphi_m$  of equation of (7,2,1,25) with the boundary conditions of (7,2,1,9) actually exists.

Now going back to identity (7,2,1,22), we have

$$v(t, \theta) = e^{t(k+2)} w(t, \theta) + \sum_{-(k+2) < \lim \tau_m' < 0} i \sqrt{(2\pi)} e^{it\tau_m'} \psi_m(\theta)$$

$$+ \sum_{-(k+2) < \lim \tau_m'' < 0} i \sqrt{(2\pi)} e^{it\tau_m''} \{ \varphi_m(\theta) + it\psi_m(\theta) \},$$

where we denote by  $\tau_m'$  the characteristic values which are simple and by  $\tau_m''$  the double ones.

Summing up, we have proved the following statement where we have performed the change of variable  $r = e^t$  and used Lemma 7.2.1.3.

**Theorem 7.2.1.12** We assume that  $u \in P_2^2(G)$  is a solution with bounded support of

$$\Delta^2 u = f$$
 in G

with the boundary conditions

$$\gamma u = \gamma \frac{\partial u}{\partial \nu} = 0 \qquad on \ \partial G$$

We assume in addition, that  $f \in P_2^k(G)$  with  $k \ge -1$  and that the problem (7,2,1,11) has no characteristic value on the line

$$\operatorname{Im} \tau = -(k+2).$$

Then  $u = u_r + u_s$ , where  $u_r \in P_2^{k+4}(G)$  and

$$u_{s}(r;\theta) = \sum_{-(k+2)<\ln \tau'_{m}<0} i\sqrt{(2\pi)}r^{1+i\tau'_{m}}\psi_{m}(\theta) + \sum_{-(k+2)<\ln \tau''_{m}<0} i\sqrt{(2\pi)}^{1+i\tau''_{m}}\{\varphi_{m}(\theta)+i(\ln r)\psi_{m}(\theta)\}$$
 (7,2,1,28)

where  $\tau_m'$ ,  $m=1,2,\ldots$  denotes the sequence of the simple roots of the characteristic equation (7,2,1,12) (augmented with  $\pm i$  when  $\tan \omega = \omega$ ),  $\tau_m''$ ,  $m=1,2,\ldots$  denotes the sequence of the double roots of equation (7,2,1,12),  $\psi_m$  is a solution of (7,2,1,11) with  $\tau=\tau_m'$  or  $\tau_m''$  and finally  $\varphi_m$  is a solution of (7,2,1,25) and (7,2,1,9) with  $\tau=\tau_m''$ .

This result holds in particular when f is given in  $\mathring{H}^k(G)$  by Theorem 7.2.1.1. It implies that  $u_r$  belongs to  $H^{k+4}(G)$ .

In what follows it will be convenient to restate the expansion (7,2,1,28) in a slightly different way. We define the function  $s_m$  by

$$\begin{cases} (\tau_m^4 + 2\tau_m^2 + 1)s_m + 2(1 - \tau_m^2)s_m'' + s_m^{(iv)} = 0 & \text{in } ]0, \omega[\\ s_m(0) = s_m(\omega) = s_m'(0) = s_m'(\omega) = 0 & (7.2, 1, 29) \end{cases}$$

with the normalization condition

$$\int_0^{\omega} |s_m(\theta)|^2 d\theta = 1$$
 (7,2,1,30)

and we define the function  $\sigma_m$  by

$$\begin{cases} (\tau_m''^4 + 2\tau_m''^2 + 1)\sigma_m + 2(1 - \tau_m''^2)\sigma_m'' + \sigma_m^{(iv)} \\ = -4\tau_m''(\tau_m''^2 + 1)s_m + 4\tau_m''s_m'', & \text{in } ]0, \omega[ \\ \sigma_m(0) = \sigma_m(\omega) = \sigma_m'(0) = \sigma_m'(\omega) = 0 \end{cases}$$
(7,2,1,31)

with the orthogonality condition

$$\int_{0}^{\omega} s_{m}(\theta) \overline{\sigma_{m}(\theta)} d\theta = 0.$$
 (7,2,1,32)

The functions  $s_m$  and  $\sigma_m$  are uniquely determined and  $\psi_m$  is a multiple of  $s_m$ , say,

$$i\sqrt{(2\pi)}\psi_m = \lambda_m s_m$$

for some complex number  $\lambda_m$ ; then obviously  $i\sqrt{(2\pi)}\varphi_m - \lambda_m\sigma_m$  is a multiple of  $s_m$ , say,

$$i\sqrt{(2\pi)}\varphi_m = \lambda_m\sigma_m + \mu_m s_m$$

for another complex number  $\mu_m$ . Accordingly we have

$$\begin{split} u_{s}(r,\theta) &= \sum_{-(k+2) < \operatorname{Im} \tau_{m}' < 0} \lambda_{m} r^{1 + i \tau_{m}'} s_{m}(\theta) \\ &+ \sum_{-(k+2) < \operatorname{Im} \tau_{m}'' < 0} \lambda_{m} r^{1 + i \tau_{m}''} \{ \sigma_{m}(\theta) + i (\ln r) s_{m}(\theta) \} + \mu_{m} r^{1 + i \tau_{m}''} s_{m}(\theta). \end{split}$$

$$(7,2,1,33)$$

Remark 7.2.1.13 When the assumption on the characteristic values of the problem (7,2,1,11) is not satisfied, one can prove some partial results. Indeed if there is some characteristic value on the line Im  $\lambda = -(k+2)$ , there exists  $\varepsilon > 0$  arbitrarily small such that there is no characteristic value on the line Im  $\lambda = -(k+2) + \varepsilon$ . Again

$$\tau_1 \mapsto \hat{v}(\tau_1 - \mathrm{i}[k+2] + \mathrm{i}\varepsilon)$$

is the Fourier transform of a function belonging to  $H^{k+3}(B)$ . Consequently we can replace (7,2,1,22) by

$$v(t, \theta) = e^{t(k+2-\varepsilon)}\rho(t, \theta) + \sum_{-(k+2)+\varepsilon < \text{Im } \tau_m < 0} s_m(t, \theta)$$

where  $\rho \in H^{k+3}(B)$ . Then the corresponding expansion in Theorem 7.2.1.12 implies that  $u = u_r + u_s$ , where  $u_r \in P_2^{k+3}(G)$  and  $u_s$  is given again by (7,2,1,28). This is not the best possible result but this will be technically convenient in Subsection 7.3.2.

Remark 7.2.1.14 It is easily checked that  $s_m$  is proportional to the function

 $-\sinh \tau_m \omega \{\sinh \tau_m \theta \sin (\theta - \omega)\} + \tau_m \sin \omega \{\sinh \tau_m (\theta - \omega) \sin \theta\}$ and that  $\sigma_m$  is a linear combination of the function above and its derivative (with respect to  $\tau_m$ ), i.e. the function

$$-\omega \cosh \tau_m''\omega \{\sinh \tau_m''\theta \sin (\theta - \omega)\} + \sin \omega \{\sinh \tau_m''(\theta - \omega) \sin \theta\} -\sinh \tau_m''\omega \{\theta \cosh \tau_m''\theta \sin (\theta - \omega)\} + \tau_m'' \sin \omega \{(\theta - \omega) \cosh \tau_m''(\theta - \omega) \sin \theta\}.$$

Remark 7.2.1.15 One can derive similar results for the boundary value problem (7,2,1,3) (7,2,1,4) in a strip B whose width is  $\omega = 2\pi$ . This takes care of fracture problems. The characteristic values are the numbers  $\tau_m = -im/2$  with m an integer  $(m \neq 0)$ . The multiplicities are 2 unless |m| = 2. It is readily seen that the solutions of the homogeneous problem (7,2,1,11) span the two-dimensional space generated by the functions

$$g_m(\theta) = \sin(1 + m/2)\theta - \frac{m+2}{m-2}\sin(-1 + m/2)\theta$$

and

$$h_m(\theta) = \cos((1+m/2)\theta) - \cos((-1+m/2)\theta).$$

This implies that the function  $\psi_m$  defined by (7,2,1,23) is a linear combination of  $g_m$  and  $h_m$ . On the other hand, when  $\tau_m$  is a double root,  $\psi_m$  defined by (7,2,1,24) vanishes while  $\varphi_m$  is again a linear combination of  $g_m$  and  $h_m$  (this follows from the solvability condition for the problem (7,2,1,25)). Consequently the expansion (7,2,1,28) is simply:

$$u_{s} = \sum_{0 < m < 2(k+2)} r^{1+m/2} \{ \alpha_{m} g_{m}(\theta) + \beta_{m} h_{m}(\theta) \},$$

where  $\alpha_m$  and  $\beta_m$  are constants. Actually only the terms corresponding to odd values of m are relevant in this expansion (since the other terms are simply polynomial). Thus it will be convenient to relabel everything by replacing m by 2m-1. The expansion (7,2,1,33) now has the following form:

$$u_{s} = \sum_{1 \leq m \leq k+5/2} \lambda_{m} r^{m+1/2} s_{m}^{(1)}(\theta) + \nu_{m} r^{m+1/2} s_{m}^{(2)}(\theta),$$

where

$$s_m^{(1)}(\theta) = \sin(m + \frac{1}{2})\theta - \frac{2m+1}{2m-3}\sin(m - \frac{3}{2})\theta$$

and

$$s_m^{(2)}(\theta) = \cos{(m + \frac{1}{2})}\theta - \cos{(m - \frac{3}{2})}\theta.$$

Again we have  $u - u_S \in P_2^{k+3}(G)$  according to Remark 7.2.1.13.

#### 7.2.2 Getting rid of the weights

First we go back to the original problem (7,1,1) in a polygon  $\Omega$ . This will be merely a matter of notation. Again we denote by  $\Gamma_i$ ,  $1 \le i \le N$ , the sides of  $\Omega$ ,  $S_i$  being the final point of  $\Gamma_i$ . We denote by  $\omega_i$  the measure of the angle at  $S_i$  and finally we use again the polar coordinates with origin at  $S_i$ .

Now we define the singular functions corresponding to each corner. The sequence  $\lambda_{j,m}$ ,  $m=1,2,\ldots$  denotes the set of all the roots of the characteristic equation

$$\sinh^2(\lambda \omega_i) = \lambda^2 \sin^2 \omega_i \tag{7,2,2,1}$$

excluding 0 and +i when  $\tan \omega_i \neq \omega_i$  and excluding only zero when  $\tan \omega_i = \omega_i$ . Then the sequence  $\lambda_{i,m}$ ,  $m = 1, 2, \ldots$  denotes the set of the simple roots of (7,2,2,1) including +i when  $\tan \omega_i = \omega_i$ . Finally  $\lambda''_{i,m}$ ,  $m = 1, 2, \ldots$  denotes the set of the double roots of (7,2,2,1). Accordingly we have

$$\{\lambda_{i,m}\}_{m=1,2,...} = \{\lambda'_{i,m}\}_{m=1,2,...} U\{\lambda''_{i,m}\}_{m=1,2,...}$$

and the numbers  $\lambda''_{i,m}$  are all imaginary. Next we set

$$\mathcal{S}_{j,m}(r_j,\,\theta_j) = r_j^{1+i\lambda'_{j,m}} s_{j,m}(\theta_j) \eta_j(r_j e^{i\theta_j}), \tag{7.2.2.2}$$

where  $\eta_i$  is a cut-off function which is equal to one near  $S_i$  and vanishes near all the other corners and near all the sides but  $\Gamma_i$  and  $\Gamma_{i+1}$  and where  $s_{i,m}$  is a solution of the equation.

$$(\lambda_{j,m}^{\prime 4} + 2\lambda_{j,m}^{\prime 2} + 1)s_{j,m} + 2(1 - \lambda_{j,m}^{\prime 2})s_{j,m}'' + s_{j,m}^{(iv)} = 0$$
 (7,2,2,3)

in  $]0, \omega_i[$  with the boundary conditions

$$s_{i,m}(0) = s_{i,m}(\omega_i) = s'_{i,m}(0) = s'_{i,m}(\omega_i) = 0$$
 (7,2,2,4)

and the normalization condition

$$\int_0^{\omega_i} |s_{j,m}(\theta)|^2 d\theta = 1.$$

We also set

$$\mathcal{F}_{j,m}(r_j,\theta_j) = r_j^{1+i\lambda_{i,m}^m} t_{j,m}(\theta_j) \eta_j(r_j e^{i\theta_j}), \qquad (7,2,2,5)$$

where  $t_{j,m}$  is a solution of the same problem as  $s_{j,m}$  with  $\lambda'_{j,m}$  replaced by  $\lambda'_{j,m}$  and

$$\mathcal{U}_{j,m}(r_j, \theta_j) = r_j^{1+i\lambda_{j,m}^m} \{ u_{j,m}(\theta_j) + i(\ln r_j) t_{j,m}(\theta_j) \} \eta_j(r_j e^{i\theta_j}), \tag{7.2.2.6}$$

where  $u_{i,m}$  is a solution of the equation

$$(\lambda_{j,m}^{"4} + 2\lambda_{j,m}^{"2} + 1)u_{j,m} + 2(1 - \lambda_{j,m}^{"2})u_{j,m}^{"} + u_{j,m}^{(iv)}$$

$$= -4\lambda_{j,m}^{"}(\lambda_{j,m}^{"2} + 1)t_{j,m} + 4\lambda_{j,m}^{"}t_{j,m}^{"}$$
(7,2,2,7)

in ]0,  $\omega_i$ [ with the boundary conditions

$$u_{j,m}(0) = u_{j,m}(\omega_j) = u'_{j,m}(0) = u'_{j,m}(\omega_j) = 0$$
 (7,2,2,8)

and the orthogonality condition

$$\int_0^{\omega_j} u_{j,m}(\theta) \overline{t_{j,m}(\theta)} \, \mathrm{d}\theta = 0.$$

Our starting point in this section is the following statement.

**Theorem 7.2.2.1** We assume that  $u \in \mathring{H}^2(\Omega)$  is a solution of

$$\Delta^2 u = f$$
 in  $\Omega$ 

with  $f \in \mathring{H}^k(\Omega)$ ,  $k \ge -1$ . (Let us agree for convenience that  $\mathring{H}^{-1}(\Omega) = H^{-1}(\Omega)$ .) We assume in addition that the equations (7,2,2,1) for  $j = 1,2,\ldots,N$ , have no roots (other than -i) on the line

$$\operatorname{Im} \lambda = -(k+2)$$

and we exclude the case k = -1 when  $\tan \omega_i = \omega_i$  for at least one value of j,  $1 \le j \le N$ . Then u belongs to the space spanned by  $H^{k+4}(\Omega)$ , the functions  $\mathcal{G}_{i,m}$  which correspond to

$$-(k+2) < \text{Im } \lambda'_{i,m} < 0$$

and the functions  $\mathcal{T}_{j,m}$  and  $\mathcal{U}_{j,m}$  which correspond to

$$-(k+2) < \operatorname{Im} \lambda_{j,m_0}^{"} < 0.$$

**Proof** It follows from Theorem 7.1.2 that  $u \in H^{k+4}(\Omega \setminus V)$  for any neighbourhood V of the corners. Then we proceed as we did at the end of the Subsection 7.1, considering  $u_i = \eta_i u$  in the infinite sector  $G_i$  corresponding to the corner  $S_i$  (after a rotation and a translation, possibly). The function  $u_i$  belongs to  $\mathring{H}^2(G_i)$ , has a bounded support and

$$\Delta^2 u_{\rm j} = f_{\rm j},$$

where  $f_i \in \mathring{H}^k(G_i)$  has a bounded support and coincides with f near  $S_i$ . By Theorem 7.2.1.1, this implies that

$$f_i \in P_2^k(G_i)$$
.

We can conclude by applying Theorem 7.2.1.12 to  $u_i$ ,  $1 \le i \le N$ .

The purpose of the remainder of this subsection is to eliminate the very unnatural assumption that f belongs to  $\mathring{H}^k(\Omega)$  instead of  $H^k(\Omega)$  (this is an actual assumption only when  $k \ge 1$ ). This will be achieved with the help of a new trace theorem. Later in this chapter we shall also need a similar result in the framework of the Sobolev spaces related to  $L_p$  with

 $p \neq 2$ . This is the reason why we state and prove this trace theorem in the general case, at once.

**Theorem 7.2.2.2** Assume that  $k \ge -1$  and  $1 and let <math>f \in W_p^k(\Omega)$  and  $\varphi_j \in W_p^{k+4-1/p}(\Gamma_j)$ ,  $\psi_j \in W_p^{k+3-1/p}(\Gamma_j)$ ,  $1 \le j \le N$ ; then there exists

$$v \in W_n^{k+4}(\Omega)$$

such that

$$\begin{cases} \gamma_{j}v = \varphi_{j}, & 1 \leq j \leq N \\ \gamma_{j} \frac{\partial v}{\partial \nu_{j}} = \psi_{j}, & 1 \leq j \leq N \\ \Delta^{2}v - f \in \mathring{W}_{p}^{k}(\Omega) \end{cases}$$
(7,2,2,10)

iff

$$\begin{cases} \varphi_{j}(S_{j}) = \varphi_{j+1}(S_{j}) \\ \frac{\partial \varphi_{i}}{\partial \tau_{j}}(S_{j}) = -\cos \omega_{j} \frac{\partial \varphi_{j+1}}{\partial \tau_{j+1}}(S_{j}) + \sin \omega_{j} \psi_{j+1}(S_{j}) \\ \psi_{j}(S_{j}) = -\sin \omega_{j} \frac{\partial \varphi_{j+1}}{\partial \tau_{j+1}}(S_{j}) - \cos \omega_{j} \psi_{j+1}(S_{j}) \end{cases}$$
(7,2,2,12)

for j = 1, 2, ..., N, and iff in addition

$$-\cos\omega_{i}\frac{\partial^{2}\varphi_{i}}{\partial\tau_{i}^{2}}(S_{i})-\sin\omega_{i}\frac{\partial\psi_{i}}{\partial\tau_{i}}(S_{i})=-\cos\omega_{i}\frac{\partial^{2}\varphi_{i+1}}{\partial\tau_{i+1}^{2}}(S_{i})+\sin\omega_{i}\frac{\partial\psi_{i+1}}{\partial\tau_{i+1}}(S_{i})$$

when p > 2 or  $k \ge 0$  and

$$\int_{0}^{\delta_{i}} \left| \cos \omega_{i} \left\{ -\frac{\partial^{2} \varphi_{i}}{\partial \tau_{i}^{2}} (x_{i}(-\sigma)) + \frac{\partial^{2} \varphi_{i+1}}{\partial \tau_{i+1}^{2}} (x_{i}(\sigma)) \right\} \right.$$

$$\left. + \sin \omega_{i} \left\{ -\frac{\partial \psi_{i}}{\partial \tau_{i}} \left( x_{i}(-\sigma) - \frac{\partial \psi_{i+1}}{\partial \tau_{i+1}} (x_{i}(\sigma)) \right) \right\} \right|^{2} \frac{d\sigma}{\sigma} < +\infty$$

$$(7,2,2,14)$$

for j = 1, 2, ..., N when p = 2 and k = -1.

(We again identify N+1 with 1; the notation  $\delta_i$ ,  $x_i$  has been introduced in Subsection 1.5.2.)

**Proof** First, we must view the property (7,2,2,11) as a trace property. Indeed  $\Delta^2 v - f$  belongs to  $\mathring{W}_p^k(\Omega)$  iff

$$\gamma_i \frac{\partial^l}{\partial \nu_i^l} \Delta^2 v = \gamma_i \frac{\partial^l f}{\partial \nu_i^l}$$
 on  $\Gamma_i$  (7,2,2,15)

for  $0 \le l \le k-1$ ,  $1 \le j \le N$ . Consequently we look for a function v which satisfies (7,2,2,9), (7,2,2,10) and (7,2,2,15).

We shall solve this problem by applying Theorems 1.6.1.4 and 1.6.1.5. Accordingly, we have to define the operators  $B_{i,l}$  which are involved in these statements. We set

$$\begin{cases} B_{i,1} = I \\ B_{i,2} = \frac{\partial}{\partial \nu_i} \\ B_{i,l} = \frac{\partial^{l-3}}{\partial \nu_i^{l-3}} \Delta^2, \qquad 3 \le l \le k+2. \end{cases}$$
 (7,2,2,16)

The degree of  $B_{i,l}$  is clearly  $d_{i,l} = l - 1$ , when l = 1, 2 and  $d_{i,l} = l + 1$  when  $l \ge 3$ . The corresponding functions  $f_{i,l}$  are

$$\begin{cases} f_{j,1} = \varphi_j \\ f_{j,2} = \psi_j \\ f_{j,l} = \gamma_j \frac{\partial^{l-3} f}{\partial \nu_j^{l-3}}, & 3 \le l \le k+2. \end{cases}$$
Next we have to find the operators  $P_{ij}$  and  $Q_{ij}$  such that  $(1.6.1.1)$ 

Next we have to find the operators  $P_{j,l}$  and  $Q_{j+1,l}$  such that (1,6,1,1) holds. Due to Remark 1.6.1.8, we look for operators which are homogeneous and have constant coefficients. Consequently we have

$$P_{i,l} = a_l \bigg( \frac{\partial}{\partial \tau_i} \bigg)^{d-d_{i,l}}, \qquad Q_{i,l} = b_l \bigg( \frac{\partial}{\partial \tau_{i+1}} \bigg)^{d-d_{i+1,l}},$$

where for simplicity we do not make explicit the dependence of  $a_i$  and  $b_i$  also on j and d. The corresponding identity (1,6,1,1) reads as follows (when  $d \ge 4$ ).

$$\begin{split} a_1 \bigg( \frac{\partial}{\partial \tau_i} \bigg)^d + a_2 \bigg( \frac{\partial}{\partial \tau_i} \bigg)^{d-1} & \frac{\partial}{\partial \nu_i} + \sum_{l=3}^{k+2} a_l \bigg( \frac{\partial}{\partial \tau_i} \bigg)^{d-l-1} & \frac{\partial^{l-3}}{\partial \nu_i^{l-3}} \Delta^2 \\ &= b_1 \bigg( \frac{\partial}{\partial \tau_{i+1}} \bigg)^d + b_2 \bigg( \frac{\partial}{\partial \tau_{i+1}} \bigg)^{d-1} & \frac{\partial}{\partial \nu_{i+1}} + \sum_{l=3}^{k+2} b_l \bigg( \frac{\partial}{\partial \tau_{i+1}} \bigg)^{d-l-1} & \frac{\partial^{l-3}}{\partial \nu_{i+1}^{l-3}} \Delta^2. \end{split}$$

This implies the identity

$$a_1 \left(\frac{\partial}{\partial \tau_i}\right)^d + a_2 \left(\frac{\partial}{\partial \tau_i}\right)^{d-1} \frac{\partial}{\partial \nu_i} - b_1 \left(\frac{\partial}{\partial \tau_{i+1}}\right)^d - b_2 \left(\frac{\partial}{\partial \tau_{i+1}}\right)^{d-1} \frac{\partial}{\partial \nu_{i+1}} = R\Delta^2,$$
(7,2,2,18)

where R is a homogeneous differential operator of order d-4. Consider-

ing the corresponding symbols, this identity implies that the polynomial

$$a_{1}(-x\cos\omega_{j}-y\sin\omega_{j})^{d}+a_{2}(-x\cos\omega_{j}-y\sin\omega_{j})^{d-1} \times (y\cos\omega_{j}-x\sin\omega_{j})-b_{1}x^{d}+b_{2}x^{d-1}y=S(x,y)$$

can be divided by  $(x^2 + y^2)^2$ .

Equivalently, this means that  $x = \pm iy$  are double roots of S. This yields the following system of equations for  $a_1$ ,  $a_2$ ,  $b_1$ ,  $b_2$ :

$$a_1(-1)^d (\pm i \cos \omega_i + \sin \omega_i)^d + a_2(-1)^{d-1} (\pm i \cos \omega_i + \sin \omega_i)^{d-1} \times (\cos \omega_i \mp i \sin \omega_i) - b_1(\pm i)^d + b_2(\pm i)^{d-1} = 0$$

and

$$a_{1}d(-1)^{d}\cos\omega_{j}(\pm i\cos\omega_{j} + \sin\omega_{j})^{d-1} + a_{2}\{(d-1)(-1)^{d-1}\cos\omega_{j}(\pm i\cos\omega_{j} + \sin\omega_{j})^{d-2}(\cos\omega_{j} \mp i\sin\omega_{j}) + (-1)^{d}(\pm i\cos\omega_{j} + \sin\omega_{j})^{d-1}\sin\omega_{j}\} - b_{1}d(\pm i)^{d-1} + b_{2}(d-1)(\pm i)^{d-2} = 0.$$

An easy but lengthy calculation shows that the corresponding determinant is proportional to

$$d(d-2)\sin^2\omega_i - \sin(d-2)\omega_i \sin d\omega_i$$
.

Consequently the determinant does not vanish and the only solution of the system is the null solution.

Summing up, in the particular case under consideration here, there exists no nonzero operators  $P_{j,l}$  and  $Q_{j+1,l}$  such that (1,6,1,1) holds with  $d \ge 4$ . Let us now consider the cases when  $0 \le d < 4$ .

First, when d = 0, we look for numbers  $a_1$  and  $b_1$  such that  $a_1 = b_1$ ; the corresponding relation (1,6,1,2) is

$$\varphi_{i}(S_{i}) = \varphi_{i+1}(S_{i}).$$
 (7,2,2,19)

Then, when d = 1 we look for numbers  $a_1$ ,  $a_2$ ,  $b_1$ ,  $b_2$  such that

$$a_1 \frac{\partial}{\partial \tau_i} + a_2 \frac{\partial}{\partial \nu_i} = b_1 \frac{\partial}{\partial \tau_{i+1}} + b_2 \frac{\partial}{\partial \nu_{j+1}}$$

This can be any homogeneous first-order operator; the corresponding relations (1,6,1,2) are

$$\begin{cases} \frac{\partial \varphi_{i}}{\partial \tau_{j}}(S_{j}) = -\cos \omega_{i} \frac{\partial \varphi_{i+1}}{\partial \tau_{j+1}}(S_{j}) + \sin \omega_{j} \psi_{j+1}(S_{j}) \\ \psi_{j}(S_{j}) = -\sin \omega_{i} \frac{\partial \varphi_{j+1}}{\partial \tau_{j+1}}(S_{j}) - \cos \omega_{j} \psi_{j+1}(S_{j}), \end{cases}$$
(7,2,2,20)

since  $\partial/\partial \tau_j$  and  $\partial/\partial \nu_j$  generate all the first-order operators.

Next, when d = 2 we look for numbers  $a_1$ ,  $a_2$ ,  $b_1$ ,  $b_2$  such that

$$a_1 \left(\frac{\partial}{\partial \tau_i}\right)^2 + a_2 \frac{\partial^2}{\partial \tau_i \partial \nu_i} = b_1 \left(\frac{\partial}{\partial \tau_{i+1}}\right)^2 + b_2 \frac{\partial^2}{\partial \tau_{i+1} \partial \nu_{i+1}}.$$

Equivalently, we look for numbers  $\alpha_1$ ,  $\alpha_2$ ,  $\beta_1$ ,  $\beta_2$  such that

$$\alpha_1 \left(\frac{\partial}{\partial \tau_i}\right)^2 + \alpha_2 \frac{\partial^2}{\partial \tau_i} \frac{\partial^2}{\partial \tau_{i+1}} = \beta_1 \left(\frac{\partial}{\partial \tau_{i+1}}\right)^2 + \beta_2 \frac{\partial^2}{\partial \tau_i} \frac{\partial^2}{\partial \tau_{i+1}}.$$

Obviously, we have  $\alpha_1 = \beta_1 = 0$  and  $\alpha_2 = \beta_2$ . The corresponding relation (1,6,1,2) is

$$-\cos\omega_{i}\frac{\partial^{2}\varphi_{j+1}}{\partial\tau_{j+1}^{2}}(S_{i})+\sin\omega_{i}\frac{\partial\psi_{j+1}}{\partial\tau_{j+1}}(S_{j})=-\cos\omega_{j}\frac{\partial^{2}\varphi_{j}}{\partial\tau_{i}^{2}}(S_{j})-\sin\omega_{j}\frac{\partial\psi_{j}}{\partial\tau_{j}}(S_{i}).$$

$$(7,2,2,21)$$

Finally, when d = 3 we look for numbers  $a_1$ ,  $a_2$ ,  $b_1$ ,  $b_2$  such that

$$a_1 \left(\frac{\partial}{\partial \tau_i}\right)^3 + a_2 \left(\frac{\partial}{\partial \tau_i}\right)^2 \frac{\partial}{\partial \nu_i} = b_1 \left(\frac{\partial}{\partial \tau_{i+1}}\right)^3 + b_2 \left(\frac{\partial}{\partial \tau_{i+1}}\right)^2 \frac{\partial}{\partial \nu_{i+1}}.$$

Obviously the only solution is  $a_1 = a_2 = b_1 = b_2 = 0$ , and there is no corresponding relation (1,6,1,2).

In conclusion the image of  $W_p^{k+4}(\Omega)$  by the mapping

$$\{\gamma_j B_{j,l}\}_{1 \leq j \leq N, \ 1 \leq l \leq k+2}$$

is the subspace of

$$\prod_{i=1}^{N} \left( \prod_{l=1}^{k+2} W_{p}^{l+4-d_{i,l}-1/p}(\Gamma_{i}) \right)$$

defined by the conditions (7,2,2,19) (7,2,2,20) and (7,2,2,21), when  $k \ge 0$  or when k = -1 and p > 2. When k = -1 and p < 2, only the conditions (7,2,2,19) and (7,2,2,20) occur, while, in the limit case k = -1 and p = 2 (7,2,2,21) is replaced by the corresponding integral condition (the pattern being that (1,6,1,3) replaces (1,6,1,2)). This implies the claim of Theorem 7.2.2.2.

Going back to the particular case when p = 2, we get the following consequence of Theorems 7.2.2.1 and 7.2.2.2:

**Theorem 7.2.2.3** Assume that  $u \in H^2(\Omega)$  is a solution of

$$\begin{cases} \Delta^{2}u = f & \text{in } \Omega \\ \gamma_{i}u = \varphi_{i} & \text{on } \Gamma_{i}, \quad 1 \leq j \leq N \\ \gamma_{i}\frac{\partial u}{\partial \gamma_{i}} = \psi_{i} & \text{on } \Gamma_{i}, \quad 1 \leq j \leq N \end{cases}$$
 (7,2,2,22)

with  $f \in H^k(\Omega)$ ,  $\varphi_j \in H^{k+7/2}(\Gamma_j)$ ,  $\psi_j \in H^{k+5/2}(\Gamma_j)$ ,  $k \ge -1$  that (7,2,2,12) holds and that (7,2,2,13) holds when  $k \ge 0$ . In addition we assume that (7,2,2,14) holds when k = -1. Finally we assume that the equations (7,2,2,1) for  $j = 1,2,\ldots,N$  have no root (other than -i) on the line  $\mathrm{Im}\ \lambda = -(k+2)$  and we exclude the case k = -1, when  $\tan\ \omega_j = \omega_j$  for some j. Then j = 0 belongs to the space spanned by j = 0 by j = 0, the functions j = 0 which correspond to j = 0 and the functions j = 0 and j = 0 which correspond to j = 0.

**Proof** We merely apply Theorem 7.2.2.1 to

$$w = u - v$$

where  $v \in H^{k+4}(\Omega)$  is a solution of (7,2,2,9) to (7,2,2,11) given by Theorem 7.2.2.2.

Remark 7.2.2.4 When the condition that no root of the equations (7,2,2,1) lies on the line  $\mathrm{Im} = -(k+2)$  is not fulfilled, then from Remark 7.2.1.13 we conclude that u belongs to span of  $H^{k+3}(\Omega)$  and the functions  $\mathcal{G}_{i,m}$ ,  $\mathcal{T}_{i,m}$  and  $\mathcal{U}_{i,m}$  corresponding respectively to  $\mathrm{Im} \lambda'_{i,m} \in [-(k+1), 0[$  and to  $\mathrm{Im} \lambda''_{i,m} \in [-(k+1), 0[$  (see also Theorem 1.4.5.3).

Remark 7.2.2.5 If we allow cuts i.e.  $\omega_i = 2\pi$  for some j, then the assumptions (7,2,2,12) to (7,2,2,14) must be replaced by the following:

$$\begin{cases} \frac{\partial^{l} \varphi_{j}}{\partial \tau_{i}^{l}}(S_{i}) = (-1)^{l} \frac{\partial^{l} \varphi_{j+1}}{\partial \tau_{j+1}^{l}}(S_{j}), & l < k+4-\frac{2}{p} \\ \frac{\partial^{l} \psi_{j}}{\partial \tau_{i}^{l}}(S_{i}) = -(-1)^{l} \frac{\partial^{l} \psi_{j+1}}{\partial \tau_{j+1}^{l}}(S_{j}), & l < k+3-\frac{2}{p} \end{cases}$$
(7,2,2,22)

for every p and by

$$\begin{cases}
\int_{0}^{\delta_{i}} \left| \frac{\partial^{l} \varphi_{j}}{\partial \tau_{i}^{l}} (x_{j}(-\sigma)) - (-1)^{l} \frac{\partial^{l} \varphi_{j+1}}{\partial \tau_{j+1}^{l}} (x_{j}(\sigma)) \right|^{2} \frac{d\sigma}{\sigma} < +\infty, & l = k+3 \\
\int_{0}^{\delta_{i}} \left| \frac{\partial^{l} \psi_{j}}{\partial \tau_{i}^{l}} (x_{j}(-\sigma)) + (-1)^{l} \frac{\partial^{l} \psi_{j+1}}{\partial \tau_{j+1}^{l}} (x_{j}(\sigma)) \right|^{2} \frac{d\sigma}{\sigma} < +\infty, & l = k+2 \\
\end{cases} (7,2,2,23)$$

for p = 2. This result follows from Section 1.7.

Then we set  $\lambda_{j,m} = -i(m - \frac{1}{2})$  (m an integer) when  $\omega_j = 2\pi$  and

$$\mathcal{S}_{j,m}^{(i)}(\mathbf{r}_{j},\,\theta_{j}) = r_{j}^{m+1/2} s_{m}^{(i)}(\theta_{j}) \eta_{j}(r_{j} e^{i\theta_{j}}), \qquad i = 1, 2$$

where  $s_m^{(i)}$ , i = 1, 2 have been defined in the Remark 7.2.1.15.

The statement corresponding to the Theorem 7.2.2.3 is now that u, the

solution of the problem (7,2,2,22), belongs to the span of  $H^{k+3}(\Omega)$  and the functions

$$\mathcal{G}_{j,m}$$
,  $\mathcal{T}_{j,m}$  and  $\mathcal{U}_{j,m}$  corresponding to Im  $\lambda'_{j,m}$  (or  $\lambda''_{j,m}$ )  $\in$  ]-(k+2), 0[

when  $\omega_i < 2\pi$  and the functions

$$\mathcal{G}_{i,m}^{(1)}, \mathcal{G}_{i,m}^{(2)}$$
 corresponding to  $m < k + \frac{5}{2}$ 

when  $\omega_j = 2\pi$ . This holds provided  $f \in H^k(\Omega)$ ,  $\varphi_i \in H^{k+7/2}(\Gamma_i)$ ,  $\psi_i \in H^{k+5/2}(\Gamma_i)$ , (7,2,2,12) and (7,2,2,13) hold when  $\omega_j < 2\pi$ , and (7,2,2,22) and (7,2,2,23) hold when  $\omega_j = 2\pi$ .

#### 7.3 Singular solutions, the $L_p$ case

#### 7.3.1 A priori inequalities

Assuming that  $1 and <math>p \ne 2$ , we shall prove the existence of a constant C such that

$$||u||_{k+4,p,\Omega} \le C\{||\Delta^2 u||_{k,p,\Omega} + ||u||_{k+3,p,\Omega}\}$$
 (7,3,1,1)

for all  $u \in W_p^{k+4}(\Omega)$  with  $\gamma_j u = 0$  and  $\gamma_j \partial u/\partial \nu_j = 0$  on  $\Gamma_j$ ,  $k \ge -1$ , provided some conditions are satisfied by the angles. This inequality is similar to inequality (4,3,2,12) and we shall follow the same method of proof. Consequently the first step is the proof of the corresponding inequality for u belonging to the weighted space  $P_p^{k+4}(\Omega)$  (see Definition 4.3.2.1). This is done locally by considering first the equation  $\Delta^2 u = f$  in an infinite sector G.

Thus we consider

$$u \in P_p^{k+4}(G)$$

such that

$$\Delta^2 u = f \in P_n^k(G)$$

with the boundary conditions  $\gamma u = \gamma \partial u/\partial \nu = 0$  on the boundary of G, which is the infinite sector defined, in polar coordinates, by

$$G = \{(r\cos\theta, r\sin\theta); r > 0, 0 < \theta < \omega\}.$$

We use the change of variable  $r = e^t$  in order to obtain an equation in the strip  $B = \mathbb{R} \times ]0$ ,  $\omega[$ . Setting

$$\begin{cases} u(r\cos\theta, r\sin\theta) = v(t, \theta) \\ f(r\cos\theta, r\sin\theta) = g(t, \theta) \end{cases}$$

we obtain the equation

$$(D_t^4 - 4D_t^3 + 4D_t^2 + 2D_t^2D_\theta^2 - 4D_tD_\theta^2 + D_\theta^4 + 4D_\theta^2)v = e^{4t}g.$$

However, due to Lemma 7.2.1.3, it is more natural to consider

$$\begin{cases} w = e^{(-k-4+2/p)t} v \in W_p^{k+4}(B) \cap \mathring{W}_p^2(B) \\ h = e^{(-k+2/p)t} g \in W_p^k(B) \end{cases}$$

and the corresponding equation is

$$[(D_t - \rho)^4 - 4(D_t - \rho)^3 + (4 + 2D_\theta^2)(D_t - \rho)^2 - 4D_\theta^2(D_t - \rho) + D_\theta^4 + 4D_\theta^2]w = h$$
(7,3,1,2)

in B, where  $\rho = -k - 4 + 2/p$  (i.e.  $w = e^{\rho t}v$ ).

Now we use again the method of Section 4.2 We study the well posedness of the problem by performing a partial Fourier transform in t. Thus  $\hat{w}(\tau, \theta)$  is a solution of

$$\begin{cases} [(i\tau - \rho)^4 - 4(i\tau - \rho)^3 + 4(i\tau - \rho)^2] \hat{w} \\ + [2(i\tau - \rho)^2 - 4(i\tau - \rho) + 4] \hat{w}'' + \hat{w}^{(iv)} = \hat{h} & \text{in } ]0, \omega[ \\ \hat{w}(\tau, 0) = \hat{w}(\tau, \omega) = \hat{w}'(\tau, 0) = \hat{w}'(\tau, \omega) = 0 \end{cases}$$
(7,3,1,3)

for every  $\tau \in \mathbb{R}$ , where the superscript ' denotes the differentiation in  $\theta$ . Here we assume in addition that w has a bounded support (in t) in order to give a meaning to its Fourier transform everywhere in  $\tau$ .

In the particular case when p = 2 and k = -1, the problem (7,3,1,3) coincides with the problem (7,2,1,9) (7,2,1,10). In the general case let us set

$$\mathscr{E} = +\tau + i(\rho + 1).$$

then the equation in (7,3,1,3) is just

$$(\mathcal{E}^4 + 2\mathcal{E}^2 + 1)\hat{w} + (2 - 2\mathcal{E}^2)\hat{w}'' + \hat{w}^{(iv)} = \hat{h}.$$

Consequently the well posedness of the problem (7,3,1,3) has been investigated in Lemma 7.2.1.4.

**Lemma 7.3.1.1** The problem (7,3,1,3) has a unique solution for every real  $\tau$  iff the characteristic equation

$$\sinh^2(\lambda\omega) = \lambda^2 \sin^2\omega \tag{7.3.1.4}$$

has no solution on the line  $\operatorname{Im} \lambda = -(k+1+2/q)$  (assuming  $p \neq 2$  and  $k \geq -1$ ).

From now on, we assume that this condition is fulfilled. The solution of the problem (7,3,1,3) can be written down explicitly through the use of a

A MODEL FOURTH-ORDER PROBLEM

Green function:

330

$$\hat{w}(\tau;\theta) = \int_0^{\omega} K(\tau;\theta,\theta') \hat{h}(\tau,\theta') d\theta',$$

where the kernel K is smooth in  $\tau$  and three times continuously differentiable in  $\theta$  and  $\theta'$ .

More precisely, let us set

$$\begin{cases} \alpha(\theta) = \sin \theta \sinh \mathcal{E}\theta \\ \beta(\theta) = \sinh \mathcal{E}\theta \cos \theta - \mathcal{E} \cosh \mathcal{E}\theta \sin \theta \\ \gamma(\theta) = \sinh \mathcal{E}\theta \cos \theta + \mathcal{E} \cosh \mathcal{E}\theta \sin \theta \end{cases}$$

and

$$\delta = \mathscr{E}^2 \sin^2 \omega - \sinh^2 \mathscr{E}\omega;$$

then we have

$$\begin{split} K(\mathscr{E} - \mathrm{i}[\rho + 1]; \theta, \theta') \\ &= \delta^{-1} \bigg\{ \frac{\beta(\omega)}{2\mathscr{E}} \alpha(\theta) \alpha(\omega - \theta') - \frac{\alpha(\omega)}{2\mathscr{E}} \alpha(\theta) \beta(\omega - \theta') \\ &- \frac{\gamma(\omega)}{2\mathscr{E}(1 + \mathscr{E}^2)} \beta(\theta) \beta(\omega - \theta') - \frac{\alpha(\omega)}{2\mathscr{E}} \beta(\theta) \alpha(\omega - \theta') \bigg\} \\ &\qquad \qquad \text{for } 0 \le \theta \le \theta' \le \omega \end{split}$$

and

$$\begin{split} \delta^{-1} & \left\{ \frac{\beta(\omega)}{2\mathscr{E}} \alpha(\omega - \theta) \alpha(\theta') - \frac{\alpha(\omega)}{2\mathscr{E}} \beta(\omega - \theta) \alpha(\theta') \right. \\ & \left. - \frac{\gamma(\omega)}{2\mathscr{E}(1 + \mathscr{E}^2)} \beta(\omega - \theta) \beta(\theta') - \frac{\alpha(\omega)}{2\mathscr{E}} \alpha(\omega - \theta) \beta(\theta') \right\} \\ & \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad$$

It is not hard to check that the kernels K,  $\tau K$  and  $D_{\theta'}K$  fulfil the conditions of Lemma 4.2.1.3. This yields the following inequality.

**Theorem 7.3.1.2** Assume that  $p \neq 2$ ,  $k \geq -1$  and that the characteristic equation (7,3,1,4) has no solution on the line  $\text{Im } \lambda = -(k+1+2/q)$ . Then there exists a constant C such that

$$||w||_{0,p,B} \le C ||h||_{k,p,B} \tag{7.3.1.5}$$

for every  $w \in W_p^{k+4}(B) \cap \mathring{W}_p^2(B)$  such that (7,3,1,2) holds.

**Proof** When  $k \ge 0$ , we apply directly Lemma 4.2.1.3 and actually show that

$$||w||_{0,p,B} \leq ||h||_{0,p,B}.$$

In the particular case when k = -1, we write

$$h = g_0 + D_t g_1 + D_\theta g_2$$

with  $g_j \in L_p(B)$ ,  $0 \le j \le 2$ . Consequently we have

$$\hat{w}(\tau;\theta) = \int_0^\omega K(\tau;\theta,\theta') \hat{g}_0(\tau,\theta') d\theta' + \int_0^\omega i\tau K(\tau;\theta,\theta') \hat{g}_1(\tau,\theta) d\theta'$$
$$- \int_0^\omega D_{\theta'} K(\tau;\theta,\theta') \hat{g}_2(\tau,\theta') d\theta'$$

since  $K(\tau; \theta, 0) = K(\tau; \theta, \omega) = 0$ . Then applying Lemma 4.2.1.3 three times, we obtain

$$||w||_{0,p,B} \le C \left\{ \sum_{j=0}^{2} ||g_j||_{0,p,B} \right\}$$

and consequently

$$||w||_{0,p,B} \le C' ||h||_{-1,p,B}$$

for some other constant C'.

Actually these estimates have been derived only for a w which has a bounded support in t, but it is easy to deduce the general case by taking limits. Indeed the functions with bounded support are dense in  $W_p^{k+4}(B) \cap \mathring{W}_p^2(B)$  (use cut-off functions).

Inequality (7,3,1,5) is just the analogue of inequality (4,2,1,4). Now we must find bounds for the derivatives of order k+4 of w. We proceed as in Subsection 4.2.2, namely we will neglect some non leading terms in the equation (7,3,1,2). For this purpose we rewrite the equation as follows

$$(D_t^4 + 2D_\theta^2 D_t^2 + D_\theta^4) w = h_1, (7.3, 1.6)$$

where clearly there exists some constant such that

$$||h_1||_{k,p,B} \le ||h||_{k,p,B} + C ||w||_{k+3,p,B}.$$
 (7,3,1,7)

Lemma 7.3.1.3 There exists a constant C such that

$$||w||_{k+4,p,B} \le C\{||\Delta^2 w||_{k,p,B} + ||w||_{k+3,p,B}\}$$

for every  $w \in W_p^{k+4}(B) \cap \mathring{W}_p^2(B)$ .

Before proving this lemma, let us take some preliminary steps. We shall start from the inequality

$$||u||_{2,p,B} \le C_0\{||\Delta u||_{0,p,B} + ||u||_{1,p,B}\}$$
 (7,3,1,8)

which follows from (4,2,2) (see Theorem 4.2.2.4) for every  $u \in W_p^2(B) \cap \mathring{W}_p^1(B)$ . It implies the following.

332 A MODEL FOURTH-ORDER PROBLEM

**Lemma 7.3.1.4** For each integer  $k \ge 0$  there exists a constant  $C_k$  such that

$$||u||_{k+2,p,B} \le C_k \{||\Delta u||_{k,p,B} + ||u||_{k+1,p,B}\}$$
 (7,3,1,9)

for every  $u \in W_p^{k+2}(B) \cap \mathring{W}_p^1(B)$ .

**Proof** Since we already know this result for k=0, we can proceed by induction. Thus we consider  $u \in W_p^{k+2}(B) \cap \mathring{W}_p^1(B)$ , assuming that  $C_{k-1}$  exists. We have to estimate the  $L_p$  norm of the derivatives of order k+2 of u. Applying (7,3,1,9) to

$$D_{t}u \in W^{k+1}_{p}(B) \cap \mathring{W}^{1}_{p}(B),$$

we get the desired bound for all these derivatives but  $D_{\theta}^{k+2}u$ . We conclude by writing

$$D_{\theta}^{k+2}u = D_{\theta}^{k}\Delta u - D_{\theta}^{k}D_{t}^{2}u.$$

It follows that

$$||D_{\theta}^{k+2}u||_{0,p,B} \le ||\Delta u||_{k,p,B} + ||D_{t}u||_{k+1,p,B}.$$

Now using the trace theorem it is easy to deduce the following result:

**Corollary 7.3.1.5** For each integer  $k \ge 0$  there exists a constant  $L_k$  such that

$$||u||_{k+2,p,B} \le L_k \left\{ ||\Delta u||_{k,p,B} + \sum_{j=0}^{1} ||\gamma_j u||_{k+2-1/p,p,F_j} + ||u||_{k+1,p,B} \right\}$$
 (7,3,1,10)

for every  $u \in W_p^{k+2}(B)$ .

We recall that  $F_0$  and  $F_1$  denote the two components of the boundary of the strip B, i.e.

$$F_j = \mathbb{R} \times \{j\omega\}, \quad j = 0, 1$$

We are now going to apply the inequality (7,3,1,10) to  $\Delta w$  and then to w. Clearly we have

$$||w||_{k+4,p,B} \le L_{k+2} \{ ||\Delta w||_{k+2,p,B} + ||w||_{k+3,p,B} \}.$$
 (7,3,1,11)

Then we have to estimate  $\|\Delta w\|_{k+2,p,B}$ . We will apply (7,3,1,10) to w now. We get

$$\|\Delta w\|_{k+2,p,B} \le L_k \left\{ \|\Delta^2 w\|_{k,p,B} + \sum_{j=0}^1 \|\gamma_j \, \Delta w\|_{k+2-1/p,p,F_j} + \|\Delta w\|_{k+1,p,B} \right\}.$$

$$(7,3,1,12)$$

The last step is the proof of an estimate for  $\gamma_i \Delta w = \gamma_j D_0^2 w$  (since  $\gamma_i D_i^2 w = D_i^2 \gamma_i w = 0$ ) for j = 0, 1.

*Lemma 7.3.1.6 Let cp E H<sup>3</sup> (B) be such that*

$$(-\Delta + 1)^2 \varphi = 0 \qquad \text{in } B$$

then *we have*

$$\begin{split} (\gamma_0 D_\theta^2 \varphi)^\wedge(\tau) &= \rho^2 (\gamma_0 \varphi)^\wedge(\tau) + 2\rho \{\sinh^2 \rho \omega - \rho^2 \omega^2\}^{-1} \\ &\quad \times \{\rho^2 \omega \sinh \rho \omega (\gamma_1 \varphi)^\wedge(\tau) \\ &\quad + [\sinh \rho \omega - \rho \omega \cosh \rho \omega] (\gamma_1 D_\theta \varphi)^\wedge(\tau) \\ &\quad - \rho \sinh \rho \omega (\gamma_0 \varphi)^\wedge(\tau) \\ &\quad + [\rho \omega - \sinh \rho \omega \cosh \rho \omega] (\gamma_0 D_\theta \varphi)^\wedge(\tau) \} \end{split}$$

*where* p J(1 + T<sup>2</sup>) .

*Proof* It is a simple calculation: we write that cP, the Fourier transform of cp in t, is solution of the differential equation

$$(-D_{\theta}^2 + 1 + \tau^2)^2 \hat{\varphi} = 0$$
 in  $]0, \omega[$ .

Consequently we have

$$\hat{\varphi}(\tau, \theta) = (a(\tau) + b(\tau)\theta) \sinh \rho\theta + (c(\tau) + d(\tau)\theta) \cosh \rho\theta.$$

The explicit value of the functions a, b, c and d is obtained by substituting the above expression for *cp* in y(,cp, y, cp, yOD<sup>A</sup> Cp and *y l D8cp. •*

Obviously we have a similar formula (mutatis *mutandis)* for (y1De^P) ^ (T).

Actually we need a consequence of Lemma 7.3.1.6:

*Corollary 7.3.1.7 For every* k > —1, *there* exists a constant Kk such that

$$\|\gamma_{i} \Delta w\|_{k+2-1/p,p,F_{i}} \le K_{k} \|(-\Delta+1)^{2} w\|_{k,p,B}$$

$$(7,3,1,13)$$

j = 0, *1, for every* w E Wp +4(B) f1 W<sup>2</sup> (B), p , 2.

*Proof* Let us set *th = (-4* + 1) <sup>2</sup>w and assume in addition that w has a bounded support. Thus *ti E* H- l (B) f1 Wp(B). Let *1E* H- `((l <sup>2</sup>) f1 Wá(l 2) be a continuation of t out of B such that

$$||l||_{k,p,\mathbb{R}^2} \le C_1 ||\psi||_{k,p,B} \tag{7.3.1.14}$$

for some constant C<sup>1</sup> .

Then consider the elementary solution E for .-4 +1 defined by

$$FE(\xi) = (|\xi|^2 + 1)^{-1}, \quad \xi \in \mathbb{R}^2.$$

We write w = E \* E \* 1j <sup>B</sup> + cp. By the multiplier theorem 2.3.2.1, we know

334 A MODEL FOURTH-ORDER PROBLEM

that

$$||E*E*l||_{k+4,p,\mathbb{R}^2} \le C_2 ||l||_{k,p,\mathbb{R}^2}.$$
 (7,3,1,15)

Then we have  $\varphi \in H^3(B) \cap W_p^{k+4}(B)$  and in addition

$$(-\Delta+1)^2=0 \quad \text{in } B.$$

Therefore we can use the explicit formula for  $\gamma_i \Delta \varphi$  given by Lemma 7.3.1.6. Applying again the multiplier theorem (or rather its corollary, Lemma 2.3.2.5) we obtain

$$\|\gamma_{j} \Delta \varphi\|_{k+2-1/p,p,F_{j}} \leq C_{3} \sum_{j=0}^{1} \left\{ \|\gamma_{j} \varphi\|_{k+4-1/p,p,F_{j}} + \left\| \gamma_{j} \frac{\partial \varphi}{\partial \theta} \right\|_{k+3-1/p,p,F_{j}} \right\}.$$

$$(7,3,1,16)$$

On the other hand we have

$$\gamma_{j}\varphi = -\gamma_{j}(E*E*l)$$

$$\gamma_{j}\frac{\partial\varphi}{\partial\theta} = -\gamma_{j}\frac{\partial}{\partial\theta}(E*E*l)$$

and accordingly

$$\|\gamma_{i}\varphi\|_{k+4-1/p,pF_{i}} + \|\gamma_{i}\frac{\partial\varphi}{\partial\theta}\|_{k+3-1/p,p,F_{i}} \le C_{4} \|E*E*l\|_{k+4,p,B}.$$
 (7,3,1,17)

Summing up the inequalities (7,3,1,14) to (7,3,1,17) imply that

$$\begin{aligned} \|\gamma_{j} \Delta w\|_{k+2-1/p,p,F_{i}} &\leq \|\gamma_{j} \Delta E * E * l\|_{k+2-1/p,p,F_{i}} + \|\gamma_{j} \Delta \phi\|_{k+2-1/p,p,F_{i}} \\ &\leq C_{5} \|E * E * l\|_{k+4,p,B} \leq C_{2} C_{5} \|l\|_{k,p,\mathbb{R}^{2}} \\ &\leq C_{1} C_{2} C_{5} \|\psi\|_{k,p,B} = C_{1} C_{2} C_{5} \|(-\Delta+1)^{2} w\|_{k,p,B}. \end{aligned}$$

This is the desired result when w has a bounded support. The general case follows by a density argument.

We are now able to derive the Lemma 7.3.1.3.

Proof of Lemma 7.3.1.3 From (7,3,1,11) and (7,3,1,12) we easily find a constant C such that

$$||w||_{k+4,p,B} \le C \Big\{ ||\Delta^2 w||_{k,p,B} + ||w||_{k+3,p,B} + \sum_{j=0}^{1} ||\gamma_j \Delta w||_{k+2-1/p,p,F_i} \Big\}.$$

Then applying inequality (7,3,1,13) to estimate  $\gamma_i \Delta w$ , we obtain the desired result.

We conclude this subsection with a result which summarizes Theorem 7.3.1.2 and Lemma 7.3.1.3:

**Theorem 7.3.1.8** Assume that  $1 and <math>p \ne 2$ ,  $k \ge -1$  and that the characteristic equation (7,3,1,4) has no solution on the line  $\text{Im } \lambda = -(k+1+2/q)$ . Then there exists a constant C such that

$$||w||_{k+4,p,B} \le C ||h||_{k,p,B} \tag{7.3.1.18}$$

for every  $w \in W_p^{k+4}(B) \cap \mathring{W}_p^2(B)$  such that (7,3,1,2) holds.

**Proof** This is a direct consequence of the inequalities (7,3,1,5) (7,3,1,7) (1,4,3,2) and Lemma 7.3.1.3.

Going back to the original coordinates  $(r = \ln t)$  we have proved that

$$||u||_{p_n^{k+4}(G)} \le C ||\Delta^2 u||_{p_n^k(G)}$$

provided  $u \in P_p^{k+4}(G)$  and  $\gamma u = \gamma \partial u/\partial \nu = 0$  on  $\partial G$ . Finally with the help of Theorem 7.1.2 and a partition of unity we deduce the following:

**Corollary 7.3.1.9** Assume that  $1 , <math>p \ne 2$ ,  $k \ge -1$  and that the equations

$$\sinh^2(\lambda\omega_i) = \lambda^2 \sin^2\omega_i$$

have no solution on the line  $\text{Im } \lambda = -(k+1+2/q)$  for any  $j=1,2,\ldots,N$ . Then there exists a constant C such that the inequality (7,3,1,1) holds for every

$$u \in W_p^{k+4}(\Omega) \cap \mathring{W}_p^2(\Omega).$$

Proof First we obtain directly the inequality

$$||u||_{p_p^{k+4}(\Omega)} \le C' \{||\Delta^2 u||_{p_p^k(\Omega)} + ||u||_{k+3,p,\Omega}\}.$$

Then by Theorem 4.3.2.2 we know that  $P_p^{k+4}(\Omega)$  has just a finite codimension in  $W_p^{k+4}(\Omega)$ . This implies the inequality (7,3,1,1) with, possibly, another constant (see the method of proof of Theorem 4.3.2.4).

#### 7.3.2 Smoothness

We extend now the results in Theorem 7.2.2.3 to the general case 1 .

**Theorem 7.3.2.1** Assume that  $u \in H^2(\Omega)$  is a solution of

$$\begin{cases} \Delta^{2}u = f & \text{in } \Omega \\ \gamma_{i}u = \varphi_{i} & \text{on } \Gamma_{i}, \quad 1 \leq j \leq N \\ \gamma_{i} \frac{\partial u}{\partial \nu_{i}} = \psi_{i} & \text{on } \Gamma_{i}, \quad 1 \leq j \leq N \end{cases}$$

$$(7,3,2,1)$$

with  $f \in W_p^k(\Omega)$ ,  $\varphi_j \in W_p^{k+4-1/p}(\Gamma_j)$ ,  $\psi_j \in W_p^{k+3-1/p}(\Gamma_j)$ ,  $k \ge -1$  such that (7,2,2,12) holds in any case and such that (7,2,2,13) holds when either  $k \ge 0$  or p > 2 and (7,2,2,14) holds when k = -1 and p = 2. Assume in addition that the equations (7,2,2,1) for  $j = 1,2,\ldots,N$  have no root (other than -i) on the line

$$\operatorname{Im} \lambda = -(k+1+2/q)$$

and exclude finally the case k=-1 when  $\tan \omega_i = \omega_i$  for some j. Then u belongs to the space spanned by  $W_p^{k+4}(\Omega)$ , the functions  $\mathcal{G}_{i,m}$  which correspond to

Im 
$$\lambda'_{j,m} \in \left] - \left(k + 1 + \frac{2}{q}\right), 0\right[$$
 (7,3,2,2)

and the functions  $\mathcal{F}_{j,m}$  and  $\mathcal{U}_{j,m}$  which correspond to

Im 
$$\lambda_{j,m}^{"} \in \left] - \left(k + 1 + \frac{2}{q}\right), 0\right[$$
 (7,3,2,3)

**Proof** First we approximate the data of the problem (7,3,2,1) by better ones. Indeed Theorem 7.2.2.2 shows that there exists  $v \in W_p^{k+4}(\Omega)$  such that

$$\begin{cases} \gamma_{i}v = \varphi_{i}, & 1 \leq j \leq N \\ \gamma_{i}\frac{\partial v}{\partial \nu_{i}} = \psi_{i}, & 1 \leq j \leq N. \end{cases}$$

Then Theorem 1.4.2.1 implies that there exists a sequence  $v_l$ , l=1,2,... such that  $v_l \in C^{\infty}(\overline{\Omega})$  and  $v_l \to v$  in  $W_p^{k+4}(\Omega)$ ; the corresponding traces (which are smooth)

$$\begin{cases} \varphi_{j,l} = \gamma_j v_l, & 1 \leq j \leq N, \quad l \geq 1 \\ \psi_{j,l} = \gamma_j \frac{\partial v_l}{\partial \nu_j}, & 1 \leq j \leq N, \quad l \geq 1 \end{cases}$$

converge respectively to  $\varphi_i$  and  $\psi_i$  in  $W_p^{k+4-1/p}(\Gamma_i)$  and  $W_p^{k+3-1/p}(\Gamma_i)$ . In addition Theorem 7.2.2.2 implies that they fulfil the conditions (7,2,2,12) and (7,2,2,13) (7,2,2,14) when suitable. We also approximate f in  $W_p^k(\Omega)$  by a sequence  $f_l \in C^{\infty}(\bar{\Omega})$ ,  $l = 1, 2, \ldots$ 

Clearly we have  $f_l \in H^{k+2}(\Omega)$ ,  $\varphi_{j,l} \in H^{k+11/2}(\Gamma_j)$ ,  $\psi_{j,l} \in H^{k+9/2}(\Gamma_j)$  and all the conditions for applying Theorem 7.2.2.3 with k replaced by k+2 are satisfied provided the equations (7,2,2,1) have no root on the line

Im  $\lambda = -(k+4)$ . Let  $u_l \in H^2(\Omega)$  be the solution of

$$\begin{cases} \Delta^2 u_l = f_l & \text{in } \Omega \\ \gamma_i u_l = \varphi_{i,l} & \text{on } \Gamma_i, \quad 1 \leq j \leq N \\ \gamma_i \frac{\partial u_l}{\partial \nu_i} = \psi_{i,l} & \text{on } \Gamma_i, \quad 1 \leq j \leq N. \end{cases}$$

Then  $u_l$  belongs to the span of  $H^{k+6}(\Omega)$  and the functions  $\mathcal{G}_{l,m}$ ,  $\mathcal{T}_{l,m}$ ,  $\mathcal{U}_{l,m}$  corresponding respectively to  $-(k+4) < \text{Im } \lambda'_{l,m} < 0$  and  $-(k+4) < \text{Im } \lambda''_{l,m} < 0$ . When the conditions on the roots are not satisfied, one can only claim that  $u_l$  belongs to the span of  $H^{k+5}(\Omega)$  and the same functions  $\mathcal{G}_{l,m}$ ,  $\mathcal{T}_{l,m}$  and  $\mathcal{U}_{l,m}$ ; this follows from Remark 7.2.2.4.

The Sobolev theorem and Theorem 1.4.5.2 imply in both cases that

$$u_i \in E$$

where E is the span of  $W_p^{k+4}(\Omega)$  and of the singular functions  $\mathcal{G}_{j,m}$ ,  $\mathcal{T}_{j,m}$  and  $\mathcal{U}_{j,m}$  corresponding to the conditions (7,3,2,2) and (7,3,2,3).

To conclude we shall take advantage of the inequality in the following lemma, of which we postpone the proof.

#### Lemma 7.3.2.2 There is a constant C such that

$$\|u\|_{E} \leq C \left\{ \|\Delta^{2} u\|_{k,p,\Omega} + \sum_{j=1}^{N} \|\gamma_{j} u\|_{k+4-1/p,p,\Gamma_{j}} + \sum_{j=1}^{N} \|\gamma_{j} \frac{\partial u}{\partial \nu_{j}}\|_{k+3-1/p,p,\Gamma_{j}} \right\}$$

$$(7,3,2,4)$$

for all  $u \in E$ , where E is equipped with the natural norm

g.l.b. 
$$\left\{ \|\varphi\|_{k+4,p,\Omega} + \sum_{-(k+1+2/q)<\lambda'_{i,m}<0} |a_{j,m}| + \sum_{-(k+1-2/q)<\lambda''_{i,m}<0} [|b_{j,m}|+|C_{j,m}|] \right\},$$

where

$$u = \varphi + \sum_{-(k+1+2/q) < \lambda'_{i,m} < 0} a_{i,m} \mathcal{S}_{j,m} + \sum_{-(k+1-2/q) < \lambda_{i,m} < 0} [b_{i,m} \mathcal{T}_{j,m} + C_{j,m} \mathcal{U}_{j,m}].$$

Let us apply this inequality to  $u_{l'} - u_{l}$ ; this yields

$$||u_{l'} - u_{l}||_{E} \leq C \Big\{ ||f_{l'} - f_{l}||_{k,p,\Omega} + \sum_{j=1}^{N} ||\varphi_{j,l'} - \varphi_{j,l}||_{k+4-1/p,p,\Gamma_{j}} + \sum_{j=1}^{N} ||\psi_{j,l'} - \psi_{j,l}||_{k+3-1/p,p,\Gamma_{j}} \Big\}.$$

Consequently  $u_l$ , l = 1, 2, ..., is a Cauchy sequence in E; its limit u is the solution of problem (7,3,2,1). This shows that  $u \in E$ .

**Proof** of Lemma 7.3.2.2 First we observe that  $\Delta^2 \mathcal{G}_{j,m}$ ,  $\gamma_s \mathcal{G}_{j,m}$  and  $\gamma_s \partial \mathcal{G}_{j,m}/\partial \nu_s$  are smooth functions. The functions  $\mathcal{F}_{j,m}$  and  $\mathcal{U}_{j,m}$  have the same property.

Consequently

$$\left\{\Delta^2; \gamma_j, \gamma_j \frac{\partial}{\partial \nu_i}, 1 \leq j \leq N\right\}$$

actually maps E into

$$W^k_{\mathbf{p}}(\Omega) \times \prod_{j=1}^N \{W^{k+4-1/p}_{\mathbf{p}}(\Gamma_j) \times W^{k+3-1/p}_{\mathbf{p}}(\Gamma_j)\}.$$

Consequently the inequality (7,3,2,4) is meaningful.

Now we proceed by steps starting from inequality (7,3,1,1). Combined with the obvious estimate

$$||u||_{2,2,\Omega} \le C_1 ||\Delta^2 u||_{-2,2,\Omega}$$

and Theorem 1.4.3.3, it yields the existence of  $C_2$  such that

$$||u||_{k+4,p,\Omega} \le C_2 ||\Delta^2 u||_{k,p,\Omega}$$

for every  $u \in W_p^{k+4}(\Omega) \cap \mathring{W}_p^2(\Omega)$ , under the assumptions of Corollary 7.3.1.9.

Then the trace theorems imply the existence of  $C_3$  such that

$$||u||_{k+4,p,\Omega} \le C_3 \left\{ ||\Delta^2 u||_{k,p,\Omega} + \sum_{i=1}^N ||\gamma_i u||_{k+4-1/p,p,\Gamma_i} + \sum_{i=1}^N ||\gamma_i \frac{\partial u}{\partial \nu_i}||_{k+3-1/p,p,\Gamma_i} \right\}$$

for every  $u \in W_p^{k+4}(\Omega)$ . Finally the inequality (7,3,2,4) follows by augmenting  $W_p^{k+4}(\Omega)$  with the finite-dimensional space spanned by the functions  $\mathcal{G}_{i,m}$ ,  $\mathcal{T}_{i,m}$  and  $\mathcal{U}_{i,m}$  corresponding to the conditions (7,3,2,2) and (7,3,2,3) (see the method of proof of Theorem 4.3.2.4).

Remark 7.3.2.3 Theorem 7.3.2.1 does not express a regularity result in general, since the solution does not belong to  $W_p^{k+4}(\Omega)$ . However, this is a regularity result when the equations (7,2,2,1) have no roots except -i in the strip  $-(k+1+2/q) \le \text{Im } \lambda < 0$ . Then the solution u of problem (7,3,2,1) belongs to  $W_p^{k+4}(\Omega)$ . Therefore the behaviour of the solution of the biharmonic equation is reduced just to the behaviour of the roots of equation (7,2,2,1). We now mention a very useful result in this direction.

**Lemma 7.3.2.4** Assume that  $\lambda = \xi + i\eta$  is solution of

$$\sinh^2(\lambda\omega) = \lambda^2 \sin^2 \omega$$

and assume that  $0 < \omega < \pi$ ; then  $|\eta|$  is strictly larger than 1, unless  $\xi = 0$  and  $|\eta| = 1$ .

**Proof** The equation is equivalent to

 $sinh(\lambda\omega) = \pm\lambda sin \omega$ .

Taking the imaginary part of this equation yields

$$\cosh(\xi\omega)\sin(\eta\omega) = \pm\eta\sin\omega. \tag{7,3,2,5}$$

Since the function

$$t \to \frac{\sin t}{t}$$

is decreasing in  $[0, \pi]$ , it follows that

$$\left|\frac{\sin \eta \omega}{\eta \omega}\right| \geqslant \frac{\sin \omega}{\omega}$$

for  $n \in [-1, +1]$ . Consequently, we have

$$\left| \frac{\sin \eta \omega}{\eta \sin \omega} \right| \ge 1$$

and identity (7,3,2,5) is impossible unless  $\xi = 0$ , since  $\cosh(\xi \omega) > 1$  for  $\xi \neq 0$ .

This lemma together with Theorem 7.2.2.1 imply the following general principle.

**Corollary 7.3.2.5** Assume that  $\Omega$  is a convex plane polygon; then  $\Delta^2$  is an isomorphism from  $H^3(\Omega) \cap \mathring{H}^2(\Omega)$  onto  $H^{-1}(\Omega)$ .

Remark 7.3.2.6 The whole Subsection 7.3.1 is valid for a strip with width  $\omega = 2\pi$ . Taking advantage of the remarks 7.2.2.5 and 7.2.1.15, and applying the techniques of the proof of Theorem 7.3.2.1, we derive the following statement where, for simplicity, we assume that  $k \ge 0$  and  $p \ne 2$ .

The solution of the problem (7,3,2,1) belongs to the span of  $W_p^{k+4}(\Omega)$  and the functions  $\mathcal{G}_{i,m}$ ,  $\mathcal{F}_{i,m}$  and  $\mathcal{U}_{i,m}$  corresponding to  $\operatorname{Im} \lambda'_{i,m}$  (or  $\lambda''_{i,m}) \in ]-(k+1+2/q)$ , 0[,  $\omega_i < 2\pi$  and  $\mathcal{G}^{(1)}_{i,m}$ ,  $\mathcal{G}^{(2)}_{i,m}$  corresponding to m < 2(k+1+2/q) and  $\omega_i = 2\pi$ . This holds provided  $f \in W_p^k(\Omega)$ ,  $\varphi_i \in W_p^{k+4-1/p}(\Gamma_i)$ ,  $\psi_i \in W_p^{k+3-1/p}(\Gamma_i)$  and the conditions

(7,2,2,12) and (7,2,2,13) hold when 
$$\omega_i < 2\pi$$
, (7,2,2,22) hold when  $\omega_i = 2\pi$ ,

and the equations (7,2,2,1) for  $\omega_i < 2\pi$  have no root (other than -i) on the line

Im 
$$\lambda = -(k+1+2/q)$$
, and  $p \neq 4, 2, \frac{4}{3}$ .

When the conditions (7,2,2,22) are not fulfilled the following additional singular solutions must be introduced:

$$r_i^l \eta_i (r_i e^{i\theta_i}) \left\{ (\ln r_i \sin l\theta_i + \theta_i \cos l\theta_i) - \frac{l}{l-2} (\ln r_i \sin (l-2)\theta_i + \theta_i \cos (l-2)\theta_i) - \frac{2}{(l-2)^2} \sin (l-2)\theta_i \right\}$$

together with

$$r_i^l \eta_i(r_i e^{i\theta_i}) \{ (\ln r_i \cos l\theta_i - \theta_i \sin l\theta_i) - (\ln r_i \cos (l-2)\theta_i - \theta_i \sin (l-2)\theta_i) \}$$
 for  $l < k+4-2/p$ .

#### 7.3.3 The related Stokes problem

We consider here a given vector function

$$\mathbf{f} = (f_1, f_2)$$

in  $H^{-1}(\Omega)^2$  and

$$\mathbf{v} = (v_1, v_2)$$

the solution in  $\mathring{H}^1(\Omega)^2$  of the system of equations

$$\begin{cases}
-\Delta \mathbf{v} + \nabla p = \mathbf{f} \\
\nabla \cdot \mathbf{v} = 0
\end{cases} (7,3,3,1)$$

in  $\Omega$ , where p is a scalar function in  $\Omega$ .

The existence and uniqueness of v is well known. One can apply the variational method, i.e. Lemma 2.2.1.1, choosing H, V and a as follows:

V is the subspace of  $\mathring{H}^1(\Omega)^2$  spanned by the divergence-free vector functions; H is the closure of V in  $L_2(\Omega)^2$  and finally

$$a(\mathbf{u}, \mathbf{v}) = \sum_{j=1}^{2} \int_{\Omega} \nabla u_{j} \cdot \nabla v_{j} \, \mathrm{d}x.$$

the space H defined above is characterized in Teman (1977). We are not going to detail this proof of existence and uniqueness here but we rather focus our attention on the regularity of **u**. Thus, assuming that f is given in  $W_p^k(\Omega)^2$ , we ask whether **v** belongs to  $W_p^{k+2}(\Omega)^2$  or not.

We reduce this problem to the corresponding one for the biharmonic equation by considering as usual the stream function  $u \in \mathring{H}^2(\Omega)$  defined by

$$v_1 = -\frac{\partial u}{\partial y}, \qquad v_2 = \frac{\partial u}{\partial x}.$$
 (7,3,3,2)

This function u is well defined since v is divergence-free and  $\Omega$  is simply

connected (an assumption). It follows that u is a solution of

$$\Delta^2 u = g = \frac{\partial f_1}{\partial v} - \frac{\partial f_2}{\partial x} \quad \text{in } \Omega.$$
 (7,3,3,3)

This function g is given in  $W_p^{k-1}(\Omega)$  and we can apply Theorem 7.3.2.1. provided k is nonnegative. This shows why we have always included the case k = -1 in previous subsections.

It follows that there exist a function  $u_r$  and numbers  $a_{i,m}$ ,  $b_{i,m}$  and  $c_{i,m}$  such that

$$u = u_r + \sum_{-(k+2/q) < \operatorname{Im} \lambda'_{i,m} < 0} a_{j,m} \mathcal{G}_{j,m} + \sum_{-(k+2/q) < \operatorname{Im} \lambda''_{i,m} < 0} (b_{j,m} \mathcal{T}_{j,m} + c_{j,m} \mathcal{U}_{j,m})$$

where  $u_r \in W_p^{k+3}(\Omega)$ , provided the equations (7,2,2,1) have no root on the line

$$\operatorname{Im} \lambda = -\left(k + \frac{2}{a}\right).$$

Consequently we have the following expansions for  $v_1$  and  $v_2$ :

$$\begin{aligned} v_l &= v_{l,r} + (-1)^l \frac{\partial}{\partial x_{3-l}} \left\{ \sum_{-s < \operatorname{Im} \lambda'_{i,m} < 0} a_{j,m} \mathcal{S}_{j,m} \right. \\ &+ \sum_{-s < \operatorname{Im} \lambda''_{i,m} < 0} \left( b_{j,m} \mathcal{T}_{j,m} + c_{j,m} \mathcal{U}_{j,m} \right) \right\} \end{aligned}$$

l=1,2, where  $v_{l,r}$  belongs to  $W_v^{k+2}(\Omega)$  and where we set

$$s=k+\frac{2}{q}.$$

If we go back to the identities defining  $\mathcal{G}_{j,m}$ ,  $\mathcal{F}_{j,m}$  and  $\mathcal{U}_{j,m}$ , i.e. (7,2,2,2), (7,2,2,5) and (7,2,2,6), we obtain directly the singular solutions corresponding to the Stokes problem. We shall use the following notation:

$$\begin{split} S_{2,j,m}(r_{j},\theta_{j}) &= r_{j}^{i\lambda'_{i,m}} \{ (i\lambda'_{j,m}+1) \cos\theta_{j} \, S_{i,m}(\theta_{j}) - \sin\theta_{j} \, S'_{i,m}(\theta_{j}) \} \eta_{j}(r_{j}e^{i\theta_{i}}) \\ S_{1,j,m}(r_{j},\theta_{j}) &= -r_{j}^{i\lambda'_{i,m}} \{ (i\lambda'_{j,m}+1) \sin\theta_{j} \, S_{j,m}(\theta_{j}) + \cos\theta_{j} \, S'_{i,m}(\theta_{j}) \} \eta_{j}(r_{j}e^{i\theta_{j}}) \\ T_{2,j,m}(r_{j},\theta_{j}) &= r_{j}^{i\lambda''_{i,m}} \{ (i\lambda''_{j,m}+1) \cos\theta_{j}t_{j,m}(\theta_{j}) - \sin\theta_{j}t'_{j,m}(\theta_{j}) \} \eta_{j}(r_{j}e^{i\theta_{j}}) \\ T_{1,j,m}(r_{j},\theta_{j}) &= -r_{j}^{i\lambda''_{i,m}} \{ (i\lambda''_{j,m}+1) \sin\theta_{j}t_{j,m}(\theta_{j}) + \cos\theta_{j}t'_{j,m}(\theta_{j}) \} \eta_{j}(r_{j}e^{i\theta_{j}}) \\ U_{2,j,m}(r_{j},\theta_{j}) &= r_{j}^{i\lambda''_{i,m}} \{ [ (1+i\lambda''_{j,m})(u_{j,m}(\theta_{j}) + i\ln r_{j}t_{j,m}(\theta_{j})) + it_{j,m}(\theta_{j}) ] \\ &\times \cos\theta_{j} - [u'_{i,m}(\theta_{j}) + i\ln r_{j} \, t'_{i,m}(\theta_{j})] \sin\theta_{j} \} \eta_{j}(r_{j}^{i\theta_{j}}) \\ U_{1,j,m}(r_{j},\theta_{j}) &= -r_{j}^{i\lambda''_{i,m}} \{ [ (1+i\lambda''_{j,m})(u_{j,m}(\theta_{j}) + i\ln r_{j} \, t'_{j,m}(\theta_{j})) + it_{j,m}(\theta_{j}) ] \\ &\times \sin\theta_{j} + [u'_{j,m}(\theta_{i}) + i\ln r_{j} \, t'_{j,m}(\theta_{j})] \cos\theta_{j} \} \eta_{j}(r_{j}e^{i\theta_{j}}). \end{split}$$

It is clear that  $\{S_{1,j,m}, -S_{2,j,m}\}$ ,  $\{T_{1,j,m}, -T_{2,j,m}\}$  and  $\{U_{1,j,m}, U_{2,j,m}\}$  coincide respectively with  $\nabla \mathcal{G}_{j,m}, \nabla \mathcal{T}_{j,m}$  and  $\nabla \mathcal{U}_{j,m}$ .

**Theorem 7.3.3.1** Let  $\mathbf{v} \in \mathring{H}^1(\Omega)^2$  be the solution of the problem (7,3,3,1) with  $\mathbf{f}$  given in  $W_p^k(\Omega)^2$ . Assume that the equations (7,2,2,1)  $j=1,2,\ldots,N$  have no root (other than  $-\mathbf{i}$ ) on the line

$$\operatorname{Im} \lambda = -\left(k + \frac{2}{q}\right)$$

and exclude the case k = 0 when  $\tan \omega_i = \omega_j$  for some j. Then  $v_l$  belongs to the span of  $W_p^{k+2}(\Omega)$ , the functions  $S_{l,j,m}$  which correspond to

$$\operatorname{Im} \lambda'_{j,m} \in \left] - \left( k + \frac{2}{q} \right), 0 \right[, \tag{7.3.3.5}$$

and the functions  $T_{l,j,m}$  and  $U_{l,j,m}$  which correspond to

Im 
$$\lambda_{j,m}^{"} \in \left] - \left( k + \frac{2}{q} \right), 0 \right[,$$
 (7,3,3,6)

l = 1, 2.

Remark 7.3.3.2 This theorem implies that  $\mathbf{v} \in W_p^{k+2}(\Omega)^2$  in the particular case when the equations (7,2,2,1) have no root (except -i) in the strip

$$-\left(k + \frac{2}{q}\right) < \text{Im } \lambda < 0. \tag{7.3.3.7}$$

In particular, due to Lemma 7.3.2.4 (or the Corollary 7.3.2.5), if  $\mathbf{f}$  is given in  $L^2(\Omega)^2$  and  $\Omega$  is a convex plane polygon, then the solution  $\mathbf{v} \in \mathring{H}^1(\Omega)^2$  of (7,3,3,1) actually belongs to  $H^2(\Omega)^2$ . This is the result proved by Kellogg and Osborn (1976). In Chapter 3 we proved a similar result for many boundary value problems for a single Laplace equation in any convex domain and in any dimension. It would be very tempting to try to extend the previous result on the Stokes problem to a general plane convex domain. The technique in Chapter 3 was to take limits with respect to  $\Omega$ . However, here, we are unable to achieve such an extension because we have no method of proof for an inequality similar to (3,1,2,1) providing good control of the constant  $C(\Omega)$  (as a function of  $\Omega$ ).

Remark 7.3.3.3 Writing

$$\nabla p = \mathbf{f} - \Delta \mathbf{v}$$

and applying Theorem 7.3.3.1, yields that  $\nabla p$  belongs to the span of  $W_{p}^{k}(\Omega)^{2}$  and the functions  $(\Delta S_{1,j,m}, \Delta S_{2,j,m})$ ,  $(\Delta T_{1,j,m}, \Delta T_{2,j,m})$  and

 $(\Delta U_{1,j,m}, \Delta U_{2,j,m})$  corresponding to (7,3,3,5) and (7,3,3,6). By integrating, one finds easily the singular part of p which does not belong to  $W_p^{k+1}(\Omega)$ . In particular  $p \in W_p^{k+1}(\Omega)$  when there are no roots (except -i) of the equations (7,2,2,1) in the strip (7,3,3,7). When  $\mathbf{f} \in L^2(\Omega)^2$  and  $\Omega$  is convex, then  $p \in H^1(\Omega)$ .

We shall conclude this subsection with a few remarks concerning the Navier-Stokes equations. Let us first recall a now classical result (see Temam (1977) for instance). Let  $\mathbf{f}$  (a force) be given in  $L_2(\Omega)^2$ ; then there exists a unique solution  $\mathbf{v}$  (a velocity in  $\mathring{H}^1(\Omega)^2$ ) of

$$\begin{cases}
-\Delta \mathbf{v} + (\mathbf{v} \cdot \nabla)\mathbf{v} = \mathbf{f} - \nabla p \\
\nabla \cdot \mathbf{v} = 0
\end{cases}$$
(7,3,3,8)

in  $\Omega$ , where p (a pressure) belongs to  $L_2(\Omega)$  and is unique up to the addition of some constant.

We shall derive some smoothness results for  $\mathbf{v}$ , just by rewriting this problem as a linear Stokes system

$$\begin{cases}
-\Delta \mathbf{v} + \nabla p = \mathbf{f} - (\mathbf{v} \cdot \nabla) \mathbf{v} \\
\nabla \cdot \mathbf{v} = 0
\end{cases} (7,3,3,9)$$

considering the components of  $\mathbf{f} - (\mathbf{v} \cdot \nabla)\mathbf{v}$  as the data of our problem.

**Theorem 7.3.3.4** Let  $\mathbf{v} \in H^1(\Omega)^2$  be the solution of the problem (7,3,3,8) with  $\mathbf{f}$  given in  $L_2(\Omega)^2$ . Assume that the equations (7,2,2,1),  $j=1,2,\ldots,N$  have no root (other than  $-\mathbf{i}$ ) on the line  $\mathrm{Im}\ \lambda=-1$ , and assume that  $\omega_i \neq \tan \omega_i$  for every j. Then  $v_i$  belongs to the span of  $H^2(\Omega)$ , the functions  $S_{\mathbf{l},i,m}\ T_{\mathbf{l},i,m}$  and  $U_{\mathbf{l},i,m}$  which correspond to  $-1 < \mathrm{Im}\ \lambda'_{i,m} < 0$  and the functions  $T_{\mathbf{l},i,m}$  and  $U_{\mathbf{l},i,m}$  which correspond to  $-1 < \mathrm{Im}\ \lambda''_{i,m} < 0$ , l=1,2.

**Proof** Knowing that  $\mathbf{v}$  belongs to  $H^1(\Omega)^2$  implies that  $\mathbf{v} \in L_p(\Omega)^2$  for every p by Sobolev's imbedding theorem. Consequently

$$(\mathbf{v} \cdot \nabla) \mathbf{v} \in L_r(\Omega)^2$$

for every r < 2, by Hölder's inequality. We choose r > 1, such that the equations (7,2,2,1) have no root on the line

$$\operatorname{Im} \lambda = -\frac{2}{s}, \qquad \frac{1}{r} + \frac{1}{s} = 1$$

and we apply Theorem 7.3.3.1 with p = r. Thus  $v_l$  belongs to the span of  $W_r^2(\Omega)$  and the functions  $S_{l,j,m}$ ,  $T_{l,j,m}$  and  $U_{l,j,m}$  corresponding to

$$-\frac{2}{s} < \operatorname{Im} \lambda'_{j,m} < 0$$

and

$$-\frac{2}{s} < \operatorname{Im} \lambda_{j,m}'' < 0.$$

Now we observe that the functions in  $W_r^2(\Omega)$  and  $S_{l,j,m}$ ,  $T_{l,j,m}$  and  $U_{l,j,m}$  are all bounded functions. Thus  $\mathbf{v} \in L_{\infty}(\Omega)^2$  and consequently

$$(\mathbf{v} \cdot \nabla)\mathbf{v} \in L_2(\Omega)^2$$
.

We apply again Theorem 7.3.3.1 with p=2 and get the desired conclusion.

**Corollary 7.3.3.5** Let  $\mathbf{v} \in \mathring{H}^1(\Omega)^2$  be the solution of problem (7,3,3,8) with  $\mathbf{f}$  given in  $L_2(\Omega)^2$  and assume that  $\Omega$  is a convex plane polygon. Then  $\mathbf{v} \in H^2(\Omega)^2$  (and consequently  $p \in H^1(\Omega)$ ).

Now applying the same procedure as before, one can obtain further results when  $\Omega$  is convex.

**Theorem 7.3.3.6** Let  $\mathbf{v} \in \mathring{\mathbf{H}}^1(\Omega)^2$  be the solution of the problem (7,3,3,8) with  $\mathbf{f}$  given in  $L_p(\Omega)^2$ ,  $2 . Assume that <math>\Omega$  is convex and that the equations (7,2,2,1),  $j=1,2,\ldots,N$  have no root on the line

Im 
$$\lambda = -\frac{2}{q}$$
,  $\frac{1}{p} + \frac{1}{q} = 1$ 

Then  $v_l$  belongs to the span of  $W_p^2(\Omega)$ , the functions  $S_{l,j,m}$  which correspond to  $-(2/q) < \operatorname{Im} \lambda'_{i,m} < -1$  and the functions  $T_{l,j,m}$  and  $U_{l,j,m}$  which correspond to  $-(2/q) < \operatorname{Im} \lambda''_{i,m} < -1$ .

**Proof** We already know that  $\mathbf{v} \in H^2(\Omega)^2$  and consequently  $\mathbf{v} \in L_{\infty}(\Omega)^2$  and  $\nabla v_l \in L_p(\Omega)^2$ , l = 1, 2, by the imbedding theorem. Consequently we have

$$(\mathbf{v} \cdot \nabla)\mathbf{v} \in L_p(\Omega)^2$$

and we can apply Theorem 7.3.3.1.

## Miscellaneous

#### 8.1 The Dirichlet problem for a strongly non-linear equation

Let  $\Omega$  be a plane domain with a strictly polygonal boundary as in the previous chapters. We keep the same notation as in Section 4.4. We are looking for a function u in  $\Omega$  which is the solution of

$$-\nabla \cdot \varphi(|\nabla u|)\nabla u + u = f \tag{8.1,1}$$

in  $\Omega$ , with the Dirichlet boundary condition i.e. u = 0 on  $\Gamma$ . In practice the equation  $-\nabla \cdot \varphi(|\nabla u|) \nabla u = f$  is more often found. The zero-order term in equation (8,1,1) has been added just for technical convenience. See Remark 8.1.8, however. Here f is given in  $\Omega$  and  $\varphi$  is a positive nondecreasing real function defined on  $\mathbb{R}_+ = [0, \infty[$ . Therefore we have

$$\varphi(|\nabla u|) \ge \varphi(0) > 0$$

and the equation (8,1,1) is elliptic.

Such a problem has been solved by Caccioppoli (1950–51) when  $\Omega$  is a plane domain with a smooth boundary. This author does not make any assumption on the rate of growth of  $\varphi$  at infinity. In more dimensions, a similar equation has been solved by Ladyzhenskaia and Uralc'eva (1968) under the assumption that the growth of  $\varphi$  is of polynomial type at infinity. This assumption allows one to use an optimization method.

Namely one minimizes a functional related to (8,1,1) in a suitable Sobolev space  $\mathring{W}^{1}_{p}(\Omega)$ . The exponent p is given by the rate of growth of  $\varphi$  at infinity. This method provides a weak solution, while the more classical method of Caccioppoli leads to strong smooth solutions.

Here we want to allow the domain  $\Omega$  to have corners. The corresponding problem has been solved by Najmi (1978) under the assumption that  $\Omega$  is convex. The method is very close to Caccioppoli's and requires some smoothness for the solution of the linearized problem. This is the reason why it is assumed that  $\Omega$  is convex (see Chapters 4 and 5).

For technical purposes it will be convenient to introduce the function

$$a(x) = \varphi(\sqrt{x}), \qquad x \ge 0.$$

The function a is positive and nondecreasing. We shall assume in addition that a is  $C^2$ . Thus equation (8,1,1) is equivalent to

$$-\nabla \cdot a(|\nabla u|^2) \nabla u + u = f \tag{8.1.2}$$

and we shall prove the following result (due to Najmi (1978)):

**Theorem 8.1.1** Let  $\Omega$  be a plane open and convex set with a strictly polygonal boundary. Let a be any positive non decreasing  $C^2$  function. Then for every  $f \in C^{1,\sigma}(\bar{\Omega})$ , there exists a unique

$$u \in W_p^2(\Omega) \cap \mathring{W}_p^1(\Omega)$$

solution of equation (8,1,2) where  $2 and <math>\omega$  is the measure of the largest angle of  $\Omega$ .

Let us first outline the method of proof. Basically we want to globally invert the non-linear mapping

$$F: u \mapsto -\nabla \cdot a(|\nabla u|^2) \nabla u + u$$

between suitably chosen functional spaces. We observe that

$$F(u) = -\sum_{k,l=1}^{2} a_{k,l} (|\nabla u|^2) D_k D_l u + u, \qquad (8,1,3)$$

where

$$a_{k,l}(|\nabla u|^2) = a(|\nabla u|^2)\delta_{k,l} + 2a'(|\nabla u|^2)D_k u D_l u$$
(8,1,4)

for k, l = 1, 2, where  $\delta_{k,l}$  is the Kronecker delta. Consequently F is a well-defined mapping from

$$X = W_p^2(\Omega) \cap \mathring{W}_p^1(\Omega) \quad \text{into } Y = L_p(\Omega), \tag{8.1.5}$$

provided  $\nabla u$  is continuous for every  $u \in W_p^2(\Omega)$ . This is achieved by assuming p > 2 (see Subsection 1.4.5).

A simple criterion for a non-linear mapping to be onto is the following (see e.g. Ambrosetti and Prodi (1973)):

- (a) F is *locally invertible* (this can be proved by checking that the Frechet derivative of F is invertible everywhere in X).
- (b) F is proper i.e. the inverse image of every compact subset of Y is relatively compact in X (this is usually obtained by proving an a priori estimate).

In the particular case of F defined by (8,1,3) it will be easy to prove the

property (a). Unfortunately we will not be able to prove the full *a priori* estimate which implies the property (b). Thus the above principle will only be a guideline.

*Lemma 8.1.2 F* is localIy *invertible from X into Y provided 2< p <* 21(2— ir/w).

*Proof* The Frechet derivative of F at u e X is the operator

$$F'(u) \cdot v = \sum_{k,l=1}^{2} D_{k} [a_{k,l}(|\nabla u|^{2})D_{l}v] + v$$
 (8,1,6)

where the functions a <sup>k</sup> , <sup>i</sup> are defined by (8,1,4). We shall apply Theorem 5.2.1.2 to this operator. Let us check the assumptions of this theorem. (Setting A = — F'(u )).

We have

$$\sum_{k,l=1}^{2} a_{k,l}(|\nabla u|^{2})\xi_{k}\xi_{l} = a(|\nabla u|^{2})|\xi|^{2} + 2a'(|\nabla u|^{2})(\xi \cdot \nabla u)^{2} \ge a(0)|\xi|^{2}.$$

Consequently inequality (5,2,1,1) holds with a = a(0).

It is also easy to check that the coefficients a k.r(lV u 1 <sup>2</sup> ) belong to W(Q ). Indeed we have

$$\begin{aligned} &D_{i}a_{k,l}(|\nabla u|^{2}) \\ &= \sum_{i=1}^{2} \left\{ 2\delta_{k,l}a'([\nabla u|^{2})D_{i}uD_{i}D_{i}u + 4a''(|\nabla u|^{2})D_{i}uD_{k}uD_{l}uD_{j}D_{i}u \right\} \\ &+ 2a'(|\nabla u|^{2})D_{l}uD_{i}D_{k}u + 2a'(|\nabla u|^{2})D_{k}uD_{j}D_{l}u \right\}. \end{aligned}$$

Each of the terms here is the product of a second derivative of u (i.e. a function belonging to *L^, (fl ))* and continuous function of the first derivatives of u (i.e. a bounded function, by the Sobolev imbedding Theorem 1.4.5.2). Consequently we have

$$D_j a_{k,l}(|\nabla u|^2) \in L_p(\Omega), \qquad 1 \le j \le 2.$$

Finally inequality (5,2,1,2) is obvious in the particular case under consideration here (we have a <sup>i</sup> *= 0, i < i ; 2).*

In order to apply Theorem 5.2.1.2, we must calculate wi (A ). Since *u E* W(Q) f1 *Wp(,fl), Vu* is continuous up to the boundary and vanishes at the corners S<sup>i</sup> . Accordingly, we have

$$a_{k,l}(|\nabla u(S_i)|^2) = a_{k,l}(0) = a(0)\delta_{k,l}.$$

In the notation of Subsection 5.2.1, this implies that

$$A_i = -a(0)\Delta$$

MISCELLANEOUS

and  $\mathcal{T}_i$  is just the multiplication by  $a(0)^{-1/2}$ . This implies that

$$\omega_i(A) = \omega_i, \qquad 1 \leq j \leq N.$$

348

Theorem 5.2.1.2 shows that F'(u) maps  $W_p^2(\Omega) \cap \mathring{W}_p^1(\Omega)$  onto  $L_p(\Omega)$ , provided

Card 
$$\left\{ m \in \mathbb{Z} \mid -\frac{2}{q} < \frac{m\pi}{\omega_i} < 0 \right\} = 0.$$

This is achieved when  $2/q < \pi/\omega_i$  for every j when  $p < 2/(2 - \pi/\omega)$ .

A first step toward the proof of an *a-priori* inequality is the following simple form of the maximum principle (see for instance Protter and Weinberger (1967)).

**Lemma 8.1.3** Let  $u \in C^2(\Omega) \cap C^0(\Omega)$  be a solution of the equation

$$-\sum_{k,l=1}^{2} a_{k,l} D_k D_l u + \sum_{k=1}^{2} a_k D_k u + u = f \quad \text{in } \Omega$$

where the  $a_{k,l}$  and the  $a_k$  are continuous functions such that

$$a_{k,l}(x) = a_{l,k}(x), \qquad k, l = 1, 2$$

$$\sum_{k,l=1}^{2} a_{k,l}(x) \xi_k \xi_l \ge \alpha |\xi|^2$$

for every  $\xi \in \mathbb{R}^2$  and  $x \in \Omega$  with  $\alpha > 0$ . Then we have

$$\max_{\bar{\Omega}} |u| \leq \max_{\Gamma} |u| + \max_{\bar{\Omega}} |f|. \tag{8,1,7}$$

**Proof** Let  $x_0 \in \overline{\Omega}$  be a point where u reaches its maximum. There are two possible cases: either  $x_0 \in \Gamma$ , or  $x_0 \in \Omega$ . If  $x_0 \in \Gamma$  we obviously have

$$\max_{\bar{\Omega}} u \leq \max_{\Gamma} |u|. \tag{8,1,8}$$

On the other hand, if  $x_0 \in \Omega$ , the differential equation at  $x_0$  reduces to

$$-\sum_{k,l=1}^{2} a_{k,l}(x_0)(D_kD_lu)(x_0) + u(x_0) = f(x_0).$$

The operator

$$\sum_{k=1}^{2} a_{k,l}(x_0) D_k D_l$$

is nothing but the Laplace operator in different coordinates, thus we have

$$\sum_{k,l=1}^{2} a_{k,l}(x_0)(D_k D_l u)(x_0) \leq 0.$$

Consequently we have

$$\max_{\overline{\Omega}} u = u(x_0) \leq \max_{\overline{\Omega}} |f|. \tag{8.1.9}$$

Inequalities similar to (8,1,8) (8,1,9) hold for the minimum of u on  $\bar{\Omega}$  and this implies (8,1,7).

Let us now go back to equation (8,1,2) i.e.

$$F(u) = f$$

with  $u \in W_p^2(\Omega) \cap \mathring{W}_p^1(\Omega)$  and  $f \in C^{0,\sigma}(\overline{\Omega})$ . The classical interior regularity results imply that  $u \in C^{2,\sigma}(\Omega)$  (see for instance Miranda (1970); this can also be easily deduced from results in Section 6.3). In particular, we have

$$u \in C^0(\tilde{\Omega}) \cap C^2(\Omega)$$
.

Consequently Lemma 8.1.3 implies that

$$\max_{\tilde{\Omega}} |u| \leq \max_{\tilde{\Omega}} |f|. \tag{8.1,10}$$

Next we consider the equations obtained from (8,1,2) by differentiating. Let  $v_i = D_i u$ , j = 1, 2; then we have

$$-\sum_{k,l=1}^{2} a_{k,l}(|\nabla u|^{2})D_{k}D_{l}v_{j}$$

$$-\sum_{k,l=1}^{2} D_{k}D_{l}u\sum_{i=1}^{2} \left[2\delta_{k,l}a'(|\nabla u|^{2}) + 4D_{k}uD_{l}ua''(|\nabla u|^{2})\right]D_{i}uD_{i}v_{j}$$

$$-2a'(|\nabla u|^{2})\sum_{k,l=1}^{2} D_{k}D_{l}u[D_{l}uD_{k}v_{j} + D_{k}uD_{l}v_{j}] + v_{j} = D_{j}f \quad \text{in } \Omega.$$
(8,1,11)

Assuming that  $f \in C^{1,\sigma}(\bar{\Omega})$  implies that

$$v_j \in C^0(\bar{\Omega}) \cap C^2(\Omega).$$

Applying again Lemma 8.1.3 yields that

$$\max_{\bar{\Omega}} |D_i u| \leq \max_{f} |D_i u| + \max_{\bar{\Omega}} |D_i f|. \tag{8.1.12}$$

We want to find a bound for  $|\nabla u|$  in  $\bar{\Omega}$ . The last inequality shows that it is enough to find a bound for  $|\nabla u| = |\partial u/\partial v|$  on  $\Gamma$ . A classical tool is the use of 'barrier functions' (see Oleinik and Radkievitz (1971) for instance).

**Lemma 8.1.4** Let  $u \in C^1(\bar{\Omega}) \cap C^2(\Omega)$  be a solution of the equation

$$-\sum_{k,l=1}^{2} a_{k,l} D_k D_l u + u = f \quad \text{in } \Omega$$
 (8,1,13)

with the boundary condition u = 0 on  $\Gamma$ . Assume that the  $a_{k,l}$  are continuous in  $\Omega$  such that

$$a_{k,l}(x) = a_{l,k}(x), \qquad k = 1, 2$$

$$\sum_{k,l=1}^{2} a_{k,l}(x) \xi_k \xi_l \ge \alpha |\xi|^2$$

for every  $\xi \in \mathbb{R}^2$  and  $x \in \Omega$ , with  $\alpha > 0$ . Then we have

$$\max_{\Gamma} \left| \frac{\partial u}{\partial \nu} \right| \le \frac{\exp d}{\alpha} \max_{\bar{\Omega}} |f|, \tag{8,1,14}$$

where d is the diameter of  $\Omega$ .

**Proof** Let us consider one of the sides  $\Gamma_i$  of  $\Omega$ . We recall that  $\Gamma_i$  is a linear segment and  $\Omega$  is convex. Let  $\Gamma_i$  be defined by the equation r = 0 where

$$r = ax_1 + bx_2$$

for some real numbers a and b and assume that  $\Omega$  lies in r>0. We define a barrier function w by

$$w(x, y) = C(1 - e^{-r}).$$

The function w is nonnegative in  $\bar{\Omega}$ , provided  $C \ge 0$ . In addition w = 0 on  $\Gamma_i$ . Consequently we have

$$u - w \le 0 \qquad \text{on } \Gamma \tag{8.1.15}$$

and

$$u - w = 0 \qquad \text{on } \Gamma_i. \tag{8,1,16}$$

On the other hand we have

$$-\sum_{k,l=1}^{2} a_{k,l} D_k D_l(u-w) + (u-w) = f - Ce^{-r} \sum_{k,l=1}^{2} a_{k,l} D_k r D_l r - w.$$

In addition, it follows from the assumptions on the  $a_{k,l}$  that

$$\sum_{k,l=1}^{2} a_{k,l} D_k r D_l r \ge \alpha |\nabla r|^2 = \alpha (a^2 + b^2).$$

We can assume that  $a^2 + b^2 = 1$ ; consequently we have

$$-\sum_{k,l=1}^{2} a_{k,l} D_k D_l(u-w) + (u-w) \leq f - \alpha C e^{-d},$$

where d is the diameter of  $\Omega$ . The right-hand side of this last inequality is

nonpositive provided

$$C \ge \frac{e^d}{\alpha} \max_{\bar{\Omega}} |f|. \tag{8.1.17}$$

It follows that u - w cannot have a strictly positive maximum inside  $\Omega$ . Together with inequality (8,1,15) this implies that

$$u - w \leq 0$$

everywhere in  $\Omega$ . Then from (8,1,16) it follows that

$$\frac{\partial}{\partial \nu_i} (u - w) \ge 0 \quad \text{on } \Gamma_i.$$

In the same way we show that

$$\frac{\partial}{\partial \nu_i} (-u - w) \ge 0 \qquad \text{on } \Gamma_i$$

just by replacing u by -u in the above considerations. This yields

$$\left| \frac{\partial u}{\partial \nu_i} \right| \le \left| \frac{\partial w}{\partial \nu_i} \right| = C. \tag{8,1,18}$$

Summing up inequality (8,1,14) follows from (8,1,17) and (8,1,18).

The above result can be applied to u solution of F(u) = f, and with the help of (8,1,10) and (8,1,12) we conclude that

$$\max_{\bar{\Omega}} |u| + \max_{\bar{\Omega}} |\nabla u| \le K \left\{ \max_{\bar{\Omega}} |f| + \max_{\bar{\Omega}} |\nabla f| \right\}$$
 (8,1,19)

provided  $u \in W^2_p(\Omega) \cap \mathring{W}^1_p(\Omega)$ ,  $f \in C^{1,\sigma}(\vec{\Omega})$ . Here K depends only on  $\alpha$  and d.

The above inequality will not be enough for our purpose. Actually we shall need a bound for a Hölder norm of the gradient of u. This will be achieved with the help of a deep regularity result due to Caccioppoli (1950-51). This result concerns the smoothness of u inside  $\Omega$ ; however, it will be easy to extend it into a smoothness result up to the boundary, when  $\Omega$  is a convex polygon.

Let us recall Caccioppoli's result. A reasonably simple proof can be found in Talenti (1966).

**Lemma 8.1.5** Let  $\Omega$  be a bounded open subset of  $\mathbb{R}^2$ . Let

$$u \in H^2(\Omega) \cap \mathring{H}^1(\Omega)$$

be the solution of

$$-\sum_{k,l=1}^{2} a_{k,l} D_k D_l u + u = f \qquad in \ \Omega$$

where the  $a_{k,l}$  are bounded measurable functions in  $\Omega$  such that

$$a_{k,l} = a_{l,k}$$
 a.e. in  $\Omega$ 

and such that there exists  $\lambda_1, \lambda_2$  with  $0 < \lambda_1 \le \lambda_2 < +\infty$  such that

$$|\lambda_1|\xi|^2 \le \sum_{k,l=1}^2 a_{k,l} \xi_k \xi_l \le \lambda_2 |\xi|^2$$

for every  $\xi \in \mathbb{R}^2$  and a.e. in  $\Omega$ . Assume that  $f \in L_p(\Omega)$  with p > 2. Then for every compact subset K in  $\Omega$  there exists  $\mu \in ]0, 1[\dagger$  which depends only on  $\lambda_1, \lambda_2$  and p, and there exists C such that

$$\|\nabla u\|_{\mu,\infty,K} \le C\{\|f\|_{0,p,\Omega} + \|u\|_{1,2,\Omega}\}. \tag{8,1,20}$$

We shall improve this result as follows.

**Corollary 8.1.6** Assume that  $\Omega$  is a convex plane polygon and assume all the hypotheses of Lemma 8.1.5. Then  $\nabla u \in C^{0,\mu}(\bar{\Omega})$  and

$$\|\nabla u\|_{\mu,\infty,\bar{\Omega}} \le C\{\|f\|_{0,p,\Omega} + \|u\|_{1,2,\Omega}\}. \tag{8,1,21}$$

**Proof** We already know that  $\nabla u \in C^{0,\mu}(\Omega)$ . We must investigate the behaviour of  $\nabla u$  near the boundary.

Let us consider one of the sides  $\Gamma_i$ . After rotation and translation we can assume that  $\Gamma_i$  lies on the axis  $\{x_2 = 0\}$  and that  $\Omega$  lies above the axis. We perform a reflection with respect to  $x_2 = 0$  by setting

$$U(x_1, x_2) = \begin{cases} u(x_1, x_2), & x_2 \ge 0 \\ -u(x_1, -x_2), & x_2 < 0. \end{cases}$$

Then U is the solution of the equation

$$-\sum_{k,l=1}^{2} A_{k,l} D_k D_l U + U = F \quad \text{in } \omega,$$
 (8,1,22)

where F is defined from f in the same way as U was defined from u and where

$$A_{k,l}(x, y) = \begin{cases} a_{k,l}(x_1, x_2), & x_2 \ge 0\\ (-1)^{k-l} a_{k,l}(x_1, -x_2), & x_2 < 0. \end{cases}$$
(8,1,23)

<sup>†</sup>  $\mu \in ]0$ , inf  $(\lambda_1/\lambda_2, 1-2/p)[$ .

Here  $\omega$  denotes the set

$$\omega = \Omega \cup \Gamma_i \cup \check{\Omega}$$

where

$$\check{\Omega} = \{ (x_1, -x_2) \mid (x_1, x_2) \in \Omega \}.$$

Now the main remark is that the  $A_{k,l}$  are still bounded measurable and that

$$\lambda_1 |\boldsymbol{\xi}|^2 \leq \sum_{k,l=1}^2 A_{k,l} \xi_k \xi_l \leq \lambda_2 |\boldsymbol{\xi}|^2$$

for every  $\xi \in \mathbb{R}^2$  and a.e. in  $\omega$ . It is also clear that  $F \in L_p(\omega)$  and that  $U \in H^2(\omega) \cap \mathring{H}^1(\omega)$ . Consequently we can apply Lemma 8.1.5 to U. This shows that  $\nabla u$  is Hölder continuous up to the interior of  $\Gamma_i$ .

Finally let us consider one of the corners  $S_i$ . An affine change of coordinates reduces the general case to the case when  $S_i = 0$ ,  $\Gamma_i$  lies on the  $x_2$ -axis above zero and  $\Gamma_{i+1}$  lies on the  $x_1$ -axis on the right of zero. (Here we have really used the convexity assumption.) Then we perform a double reflection through  $\{x_1 = 0\}$  and  $\{x_2 = 0\}$  by setting

$$U(x_1, x_2) = \begin{cases} u(x_1, x_2) & x_1, x_2 \ge 0 \\ -u(x_1, -x_2) & x_1 \ge 0, x_2 < 0 \\ -u(-x_1, x_2) & x_1 < 0, x_2 \ge 0 \\ u(-x_1, -x_2) & x_1 < 0, x_2 < 0. \end{cases}$$

In the same way, we define F from f. Then U is solution of (8,1,22) (there is no point here in describing the corresponding  $A_{k,l}$  in full detail), where  $\omega$  denotes now the set

$$\{(x_1, x_2) \mid (\pm x_1, \pm x_2) \in \Omega \cup \Gamma_i \cup \Gamma_{i+1} \cup \{0\}\}.$$

Again, we have  $F \in L_{\rho}(\omega)$ ,  $U \in H^{2}(\omega) \cap \mathring{H}^{1}(\omega)$  and we can define  $\lambda_{1}^{*}$  and  $\lambda_{2}^{*}$  such that  $0 < \lambda_{1}^{*} \le \lambda_{2}^{*} < +\infty$  and such that

$$\lambda_1^* |\xi|^2 \le \sum_{k,l=1} A_{k,l} \xi_k \xi_l \le \lambda_2^* |\xi|^2$$

for every  $\xi \in \mathbb{R}^2$  and a.e. in  $\omega$ . Applying Lemma 8.1.5 again shows that  $\nabla u$  is Hölder continuous near  $S_i$ .

Let us again consider  $u \in X$ , a solution of F(u) = f; thus u is a solution of (8,1,3). We shall apply Corollary 8.1.6 to u. First we have to find  $\lambda_1$  and  $\lambda_2$  such that the assumptions hold. We have already shown that we can set

$$\lambda_1 = a(0).$$

MISCELLANEOUS

On the other hand inequality (8,1,19) provides a bound  $(K ||f||_{1,\infty,\tilde{\Omega}})$  for  $|\nabla u|$ . Consequently, we have

$$\sum_{k,l=1}^{2} a_{k,l} (|\nabla u|^{2}) \xi_{k} \xi_{l} \leq \{ a(K^{2} ||f||_{1,\infty,\vec{\Omega}}) + 2a'(K^{2} ||f||_{1,\infty,\vec{\Omega}}) K^{2} ||f||_{1,\infty,\vec{\Omega}} \} |\xi|^{2}.$$

This gives a value for  $\lambda_2$ .

354

Summing up, we have proved the following result.

**Proposition 8.1.7** Let  $u \in W_p^2(\Omega) \cap \mathring{W}_p^1(\Omega)$  be a solution of equation (8,1,2) where  $\Omega$  is a plane open and convex set with a strictly polygonal boundary. Assume that  $f \in C^{1,\sigma}(\bar{\Omega})$ ; then there exists  $\mu \in ]0, 1[$  ( $\mu$  depends on  $\|f\|_{1,\infty,\bar{\Omega}}$ ) such that  $\nabla u \in C^{0,\mu}(\bar{\Omega})$ , and there exists a constant C (C depends on  $\|f\|_{1,\infty,\bar{\Omega}}$ ) such that (8,1,21) holds.

Now we have all the preliminary material for proving Theorem 8.1.1.

Proof of Theorem 8.1.1 We introduce the subset  $\mathcal{N}$  of [0, 1] defined by the following condition (on  $t \in [0, 1]$ ): there exists  $u_t \in X$  which is a solution of

$$F(u_t) = tf.$$

We shall prove that  $\mathcal{N}$  is connected. Since  $\mathcal{N}$  obviously contains the value t = 0, it will follow that  $\mathcal{N}$  also contains the value t = 1, which is the claim of Theorem 8.1.1 (as far as existence is concerned).

Lemma 8.1.2 implies that  $\mathcal{N}$  is open. Then we have to show that  $\mathcal{N}$  is closed. Let us consider a sequence  $t_i$ ,  $i = 1, 2, \ldots$ , of numbers in  $\mathcal{N}$  which converges to some limit t. We have to check that  $t \in \mathcal{N}$ . Since  $t_i \in \mathcal{N}$ , there exists a solution  $u_{t_i} \in \mathcal{X}$  of

$$F(u_{t_i})=t_jf.$$

From Proposition 8.1.7 the sequence  $u_i$ , j = 1, 2, ... is bounded in  $C^{1,\mu}(\bar{\Omega})$  for some  $\mu \in ]0, 1[$ . By Ascoli's theorem we know that we can find a subsequence (which we will also denote by  $u_i$ , j = 1, 2, ... for simplicity) which converges to some limit u in the topology of  $C^1(\bar{\Omega})$ . In particular  $\nabla u_i$  converges uniformly to  $\nabla u$ . Consequently

$$a(|\nabla u_t|^2) \rightarrow a(|\nabla u|^2)$$

uniformly.

Since  $u_t$  is a solution of

$$-\nabla \cdot a(|\nabla u_{t_i}|^2) \nabla u_{t_i} + u_{t_i} = t_i f \quad \text{in } \Omega,$$

it follows that

$$-\nabla \cdot a(|\nabla u|^2) \nabla u + u = tf \quad \text{in } \Omega$$

in the sense of distributions. By uniform convergence we also have

$$u=0$$
 on  $\Gamma$ .

On the other hand *u E* C"(?) since the sequence *u,* is bounded in *C' -µ(,fl) .* Thus the function a (lV u <sup>I</sup> <sup>Z</sup>) is also a Hölder continuous. Consequently Theorem 5.2.1.2 implies that u actually belongs to W <sup>2</sup> (Q)t since we have assumed that 2<p <2/(2— rr/w ). In conclusion we have shown that *t EX* (setting u, = u).

Finally the uniqueness of the solution u in X of the equation (8,1,2) is easily checked with the help of the usual monotonicity argument. Indeed let us consider the functional

$$u \mapsto \Psi(u) = \int_{\Omega} \psi(|\nabla u|^2) \, \mathrm{d}x$$

on X, where *tIi'(t) = a(t)* for t 0. We have also

$$\Psi(u) = \int_{\Omega} \eta(|\nabla u|) \, \mathrm{d}x$$

where n(t) = (p(t <sup>2</sup>). Thus ij is a nondecreasing and convex function.

$$\begin{cases} \eta'(t) = 2ta(t^2) \ge 0 \\ \eta''(t) = 2a(t^2) + 4t^2a'(t^2) \ge 2a(0). \end{cases}$$

This implies that ' is convex on X and that its Frechet derivative is monotonous. Consequently let u' and u" be two solutions to the problem (8,1,2); we have

$$0 = \int_{\Omega} -\nabla \cdot \{a(|\nabla u'|^2) \nabla u' - a(|\nabla u''|^2) \nabla u''\} (u' - u'') \, \mathrm{d}x + \int_{\Omega} |u' - u''|^2 \, \mathrm{d}x$$

$$\geq \int_{\Omega} |u' - u''|^2 \, \mathrm{d}x.$$

Thus we have u' = u" and this proves the desired uniqueness. •

*Remark 8.1.8* As we have already mentioned at the beginning of this section, one is more likely to find the equation

$$-\nabla \cdot \varphi(|\nabla u|) \nabla u = f \tag{8,1,24}$$

in practical problems. The equation (8,1,1) is obtained by adding a zero-order term for technical convenience. Actually adding this zeroorder term has been an important simplification only for the proof of

t Here, we take advantage of the uniqueness of the solution we *H" '(Q)* of the equation

$$-\nabla \cdot a(|\nabla u|^2) \nabla w + w = tf \quad \text{in } \Omega.$$

Lemma 8.1.3. A similar maximum principle for the equation without zero-order term can be found in Stampacchia (1965) (Remark 4,4, p. 119). This allows one to show that the result of Theorem 8.1.1 is also valid for equation (8,1,24).

#### 8.2 Some three-dimensional results (an outline)

In Chapters 2 and 3 we proved some smoothness for the solution of an elliptic boundary value problem in a subset  $\Omega$  of  $\mathbb{R}^n$  without any restriction on n. Then, in Chapters 4-7 we assumed that  $\Omega$  was a plane domain. There we obtained solutions which split into two parts: one regular (in the sense of a suitable Sobolev norm) and the other singular but very explicitly described. Very few similar results are known when  $\Omega$  is a three-dimensional domain. This subsection is an outline of them. For the sake of simplicity, we shall restrict our purpose to self-adjoint problems (in other words we exclude the oblique boundary conditions).

Let us start with a few remarks about the results proved in Chapter 3. Now we consider  $\Omega$  a bounded open subset of  $\mathbb{R}^3$  whose boundary is a polyhedron. More precisely we assume that the boundary  $\Gamma$  of  $\Omega$  is the union of a finite number of faces  $\Gamma_j$ ,  $1 \le j \le N$ , each of which is plane. We assume that  $\Omega$  lies on one side of each of the  $\Gamma_j$ . We denote by  $A_{j,k}$  the edge between  $\Gamma_j$  and  $\Gamma_k$ ,  $\omega_{j,k}$  being the measure of the corresponding angle (inside  $\Omega$ ). Finally we denote by S the set of all the vertices and by S the union of all the edges.

Next we split the set  $\{1, 2, ..., N\}$  into two non-overlapping subsets  $\mathcal{D}$  and  $\mathcal{N}$  exactly as we did in Chapter 4. The boundary problem under consideration is the following. Given f we look for u such that

$$\begin{cases} \Delta u = f & \text{in } \Omega \\ \gamma_{j} u = 0 & \text{on } \Gamma_{j}, \quad j \in \mathcal{D}, \\ \gamma_{i} \frac{\partial u}{\partial \nu_{j}} = 0 & \text{on } \Gamma_{i} \quad j \in \mathcal{N}. \end{cases}$$

$$(8,2,1)$$

If we assume that f belongs to  $L_p(\Omega)$ ,  $\frac{6}{5} \le p < \infty$ , then the problem has a unique variational solution  $u \in H^1(\Omega)$ . As in the two-dimensional case the main question is to know what amount of smoothness for u can be derived from the assumption that  $f \in W_p^m(\Omega)$  for some integer  $m \ge 0$ .

Theorem 3.1.1.2 implies the existence of a constant C (which does not depend on  $\Omega$ ) such that

$$\sum_{|\alpha|=2} \|D^{\alpha}u\|_{0,2,\Omega} \leq C \|f\|_{0,2,\Omega}.$$

Then if we allow C to depend only on the diameter of  $\Omega$  and if we assume for simplicity that  $\mathfrak D$  is not empty, we have

$$\|u\|_{2,2,\Omega} \le C \|f\|_{0,2,\Omega} \tag{8,2,2}$$

for u satisfying (8,2,1). Indeed the curvature  $\mathcal{B}$  is zero on each face  $\Gamma_i$ . This is the basic a priori inequality.

Then if  $\mathcal{N}$  is empty (a Dirichlet problem) or if  $\mathfrak{D}$  is empty (a Neumann problem) we have a smoothness result when  $\Omega$  is convex. Indeed if f belongs to  $L_2(\Omega)$ , the corresponding solution u belongs to  $H^2(\Omega)$ .

These are the only results that follow easily from the general statements in Chapter 3. On the other hand, when f is given in  $W_p^m(\Omega)$ , it follows from Lemma 2.4.1.4 and Theorem 2.5.1.1 that  $u \in W_p^{m+2}(\Omega \setminus V)$  for any neighbourhood V of A. We shall now investigate the behaviour of u near an edge and later a vertex (in this latter case we shall also consider domains whose boundary has conical points).

#### 8.2.1 Edges

The basic idea (to be stated rigorously later) is that an edge with measure  $\omega$  leads to a smooth solution iff an angle with the same measure  $\omega$  leads to a smooth solution (in the two-dimensional problems). Otherwise if  $\omega$  is large enough to produce some singular solution in the two-dimensional case, then an edge with the same measure will produce infinitely many singular solutions.

Let us denote by x, y, z the three coordinates and use cylindrical coordinates around the z-axis (i.e. we use polar coordinates in the xOy plane:  $x + iy = re^{i\theta}$ ). In addition let us consider a polyhedron  $\Omega$  such that one of its edges is on the z-axis; in other words there exist j and k such that

$$A_{j,k} = \{(0,0,z) \mid a < z < b\}$$
 (8,2,1,1)

for some real numbers a and b with a < b. We also assume that the face  $\Gamma_i$  is contained in the xOz plane.

We introduce two other real numbers a' and b' with a < a' < b' < b and a cut-off function depending only on r such that  $\eta(r) = 1$  for  $r < \rho$  and  $\eta(r) = 0$  for  $r > 2\rho$ , where  $\rho$  is chosen such that

$$K = \{(x, y, z) \mid 0 < r \le 2\rho, 0 < \theta < \omega_{i,k}, a' \le z \le b'\} \subset \Omega.$$

Lemma 8.2.1.1 Define the function u by

$$u(x, y, z) = \eta(r)r^{l\pi/\omega_{j,k}} \sin \frac{l\pi\theta}{\omega_{j,k}} \varphi(z)$$

where  $\varphi \in \mathfrak{D}(]a', b'[)$ . Then  $u \in \mathring{H}^1(\Omega), \Delta u \in W_p^m(\Omega)$  and  $u \notin W_p^{m+2}(\Omega)$  provided l is an integer such that

$$\max\left\{0, \frac{\omega_{j,k}}{\pi} \left(m - \frac{2}{p}\right)\right\} < l < \frac{\omega_{j,k}}{\pi} \left(m - \frac{2}{p}\right) + 2\frac{\omega_{j,k}}{\pi}.$$
 (8,2,1,2)

The proof of this lemma is very easy. Indeed the support of u is contained in K and one applies Theorem 1.4.5.3.

This lemma produces infinitely many singular solutions, provided the condition (8.2.1.2) on l is not empty, since  $\varphi$  is allowed to span an infinite-dimensional space.

The above functions u fulfil the Dirichlet boundary condition. Similar singular solutions for other (self-adjoint) boundary conditions are easily built: the function

$$u(x, y, z) = \eta(r)r^{l\pi/\omega_{i,k}}\cos\frac{l\pi\theta}{\omega_{i,k}}\varphi(z)$$

fulfils a Neumann boundary condition on  $\Gamma_i$  and  $\Gamma_k$  (and vanishes in a neighbourhood of all the other faces) and the function

$$u(x, y, z) = \eta(r) r^{(l-\frac{1}{2})\pi/\omega_{i,k}} \sin\left(l-\frac{1}{2}\right) \frac{\pi\theta}{\omega_{i,k}} \varphi(z)$$

fulfils a Dirichlet condition on  $\Gamma_i$  and a Neumann condition on  $\Gamma_k$  (and vanishes near all the other faces).

In particular a nonconvex edge produces infinitely many variational solutions u of the Dirichlet problem (or the Neumann problem) such that  $\Delta u \in L_2(\Omega)$ , while  $u \notin H^2(\Omega)$ .

The above lemma has a negative character; let us now turn to a rather obvious regularity result.

**Theorem 8.2.1.2** Let  $u \in H^1(\Omega)$  be the solution of the problem (8,2,1) with f given in  $C^{\infty}(\overline{\Omega})$ . Then

$$u \in W_p^m(\Omega \setminus V)$$

where V is any neighbourhood of S (the set of all the vertices) provided

- (a)  $m-2/p < \pi/\omega_{j,k}$  when j and  $k \in \mathcal{D}$  or when j and  $k \in \mathcal{N}$ .
- (b)  $m-2/p < \pi/2\omega_{j,k}$  when  $j \in \mathfrak{D}$  and  $k \in \mathbb{N}$  or when  $j \in \mathbb{N}$  and  $k \in \mathfrak{D}$ .

**Proof** We look at the behaviour of u near  $A_{j,k}$ . After rotation and translation we reduce the general case to the particular case when  $A_{j,k}$  is on the Oz axis (i.e. (8,2,1,1) holds and we keep the same notation as in Lemma 8.2.1.1 assuming that  $\Gamma_j$  is in the xOz plane).

Downloaded 10/24/25 to 211.83.126.166. Redistribution subject to SIAM license or copyright; see https://epubs.siam.org/terms-privacy

It is easy to check that u is regular in the z variable. For this purpose, we replace u by

$$v(x, y, z) = \eta(r)\varphi(z)u(x, y, z),$$

with  $\varphi \in \mathfrak{D}(]a', b'[)$ . We already know that u is regular inside  $\Omega$ ; thus we have

$$\Delta v - \eta \varphi'' u - 2\eta \varphi' \frac{\partial u}{\partial z} \in C^{\infty}(\bar{\Omega}). \tag{8.2.1.3}$$

Since we start from  $u \in H^1(\Omega)$ , we have  $v \in H^1(\Omega)$ 

$$\Delta v \in L_2(\Omega)$$
.

In addition the support of v is contained in K and v fulfils the same boundary conditions as u.

Let  $\tau_h$  be the translation operator in the direction of z, i.e.

$$\tau_h w(x, y, z) = w(x, y, z + h).$$

The function  $(\tau_h v - v)/h$  is a solution of the same boundary conditions as u when h is small enough.

In addition, we have

$$\frac{\tau_h v - v}{h} \in H^1(\Omega).$$

Integrating by parts the integral

$$\int_{\Omega} (-\Delta + 1) \frac{\tau_h v - v}{h} \frac{\tau_h v - v}{h} dx dy dz$$

yields the following inequality

$$\left\| \frac{\tau_h v - v}{h} \right\|_{1,2,\Omega} \leq \left\| (-\Delta + 1) \frac{\tau_h v - v}{h} \right\|_{-1,2,\Omega}.$$

Taking the limit as  $h \searrow 0$ , we obtain

$$\left\| \frac{\partial v}{\partial z} \right\|_{1,2,\Omega} \le \left\| \frac{\partial}{\partial z} \left( -\Delta + 1 \right) v \right\|_{-1,2,\Omega}$$

and this shows that  $\partial v/\partial z \in H^1(\Omega)$ . Then letting  $\varphi$  be any function in  $\mathfrak{D}(]a',b'[)$ , we derive that

$$\eta\psi\frac{\partial u}{\partial z}\in H^1(\Omega)$$

for every  $\psi \in \mathfrak{D}([a', b'])$ .

Turning back to (8,2,1,3), we have now

$$\Delta v \in H^1(\Omega)$$

and we apply again the same procedure as above to the function

$$\left(\frac{\tau_h-1}{h}\right)^2v.$$

By iteration we eventually prove that

$$\eta \psi \frac{\partial^k u}{\partial z^k} \in H^1(\Omega)$$

for every integer  $k \ge 1$  and every  $\psi \in \mathcal{D}(]a', b'[)$ . Thus  $\eta u$  is infinitely differentiable function of z (in ]a', b'[) with values in  $H^1(G)$ , where we define G as follows:

$$G = \{(x, y) \mid 0 < r < 2\rho, 0 < \theta < \omega_{i,k}\}.$$

In particular  $\eta u$  is an infinitely differentiable function with values in  $L_p(G)$ , for every  $p \in ]1, \infty[$ . Now let us denote by  $\Delta'$  the Laplace operator in the variables x and y. We have

$$\Delta'(\eta u) = \Delta(\eta u) - \eta D_z^2 u. \tag{8.2.1.4}$$

We already know that u is regular in  $\bar{\Omega} \setminus A$ ; thus we have

$$\Delta(\eta u) \in C^{\infty}(\bar{K})$$

and consequently  $\Delta'(\eta u)$  is infinitely differentiable with values in  $L_p(G)$ . Applying Theorem 4.4.3.7 shows that  $\eta u$  is infinitely differentiable with values in  $W_p^2(G)$  provided p is such that  $2-2/p < \pi/\omega_{i,k}$  when j and k belong to the same set  $(\mathcal{D} \text{ or } \mathcal{N})$  and  $2-2/p < \pi/2\omega_{i,k}$  otherwise.

Going back to (8,2,1,4), we see now that  $\Delta'(\eta u)$  is infinitely differentiable with values in  $W_p^2(G)$ . Then Theorem 5.1.3.5 shows that  $\eta u$  is infinitely differentiable with values in  $W_p^4(G)$  provided p is such that  $4-2/p < \pi/\omega_{i,k}$  when j and k belong to the same set  $(\mathfrak{D} \text{ or } \mathcal{N})$  and  $4-2/p < \pi/2\omega_{i,k}$  otherwise.

Iterating the above procedure yields the desired result.

Remark 8.2.1.3 When the condition (a) (respectively (b)) is violated, the above proof shows that there exist functions  $k_l \in C^{\infty}(]a', b'[)$  such that

$$u(x, y, z) - \sum_{-2+2/p < \lambda_l < 0} k_l(z) \mathfrak{S}_l(x, y)$$

is an infinitely differentiable function of z with values in  $W^2_p(G)$ . (We recall here that a' and b' are any real numbers such that a < a' < b' < b and consequently  $k_l$  belongs to  $C^{\infty}(]a, b[)$ . In other words  $k_l \in C^{\infty}(A_{j,k})$ .)

Here the notation is the following:

$$\lambda_l = \frac{l\pi}{\omega_{j,k}} \qquad \text{when } j \text{ and } k \text{ both belong to } \mathscr{D} \text{ or } \mathscr{N}$$

$$\lambda_l = (l + \frac{1}{2}) \frac{\pi}{\omega_{j,k}} \qquad \text{otherwise.}$$

In addition

$$\mathfrak{S}_l(x, y) = r^{-\lambda_l} \sin(\lambda_l \theta)$$
, when j and k belongs to  $\mathfrak{D}$ 

$$\mathfrak{S}_{l}(x, y) = r^{-\lambda_{l}} \cos(\lambda_{l}\theta),$$
 when  $j$  and  $k$  belong to  $\mathcal{N}$ 

$$\mathfrak{S}_{l}(x, y) = r^{-\lambda_{l}} \sin(\lambda_{l}\theta), \quad \text{when } j \in \mathfrak{D} \text{ and } k \in \mathcal{N}$$

when Al is not an integer (go back to Definition 5.1.3.4 for the modified definition of 9 <sup>1</sup> , when Al is an integer).

*Remark 8.2.1.4* The assumption that *fe C°°(^l)* in Theorem 8.2.1.2 is not necessary. Assuming only that f belongs to Wp -2(Q) (with m > 2) leads to the same conclusion; however the proof is much more complicated. It can be found in Kondratiev (1970) when p =2 and in Grisvard (1975a) in the general case. Unfortunately we do not know the amount of regularity of the functions k[ (cf. the previous remark) that follows from the assumption that fe Wpt-2(()..

Additional resuits on the behaviour of k, when p =2 are derived in Grisvard (1982).

*Rernark 8.2.1.5* As in Section 5.3, one can extend the result of Theorem 8.2.1.2 to the case of an operator with variable coefficients in a domain with a curvilinear edge (a precise definition is left to the taste of the reader). The basic idea is still that the solution belongs to a given Sobolev space iff the two dimensional angles with the same measure as the edge (at any point of the edge) yield regularity (in the corresponding Sobolev space in two variables of course).

#### 8.2.2 Conical points and vertices

We proceed with our investigation of the behaviour of u, the solution of problem (8,2,1), by considering u near one of the vertices. For convenience, we translate this vertex to zero. Thus, in a neighbourhood of 0, fl

t The particular case when j E -9, k E X and (li <sup>k</sup> = 'r (mixed boundary condition along a 'flat edge) has been investigated in Eskin (1973). This author has given an explicit formula for the functions ki involving the data f. Inspection of this formula easily shows that the assumption that f belongs to H`((2) implies that k" belongs to NS } ' <sup>12</sup> (A,. <sup>k</sup> ). Related results can be found in Nikishkin (1979) and Maz'ya and Plamenevskii (1978).

coincides with a cone C whose intersection with the unit sphere S <sup>2</sup> is denoted by G. Thus G is an open subset of the unit sphere whose boundary is the union of a finite number of arcs of great circles.

Here, in order to include cones which have a regular basis, we shall make a more general assumption on G. We shall only assume that aG is a curvilinear polygon (a definition similar to Definition 1.4.5.1 can be made here; roughly speaking JG is the union of a finite number of curves which cut at angles and G lies on one side of each of these curves only).

As it is natural we introduce the spherical coordinates *(r, 0, g).* For the sake of definiteness cp denotes the angle between *OM (M* the point whose coordinates are x, y and z) and the z-axis; 0 denotes the angle between Om (m the projection of M on the xOy plane) and the x-axis.

The basic idea here is that such a cone can produce two kinds of singular solution:

#### (a) Solutions of the form

$$u(x, y, z) = r^{\lambda} \psi(\theta, \varphi) \tag{8.2.2.1}$$

where 0 is an eigenfunction of the Laplace—Beltrami operator 4' in G (with the suitable boundary conditions) and A is related to the eigenvalue. These are singular functions similar to the singular functions Cam, of the two-dimensional case (cf. Chapter 4). Such singular functions will arise even when the cone C has a regular basis (i.e. G is smooth). The amount of singularity is related to A and only a finite number of such functions will be generated outside a given Sobolev space.

#### (b) Solutions of the form

$$u(x, y, z) = \psi(r)\mathfrak{S}(\theta, \varphi) \tag{8.2.2.2}$$

where iji is a regular function of r, at least away from zero, while is a singular solution of 4' on G (again fulfilling suitable boundary conditions which will be made precise later). These are singular functions similar to those produced by an edge (cf. Remark 8.2.1.3). Such singular functions arise only when G has corners (or there is a mixed boundary condition). In addition, qi spans an infinite-dimensional space and accordingly there are infinitely many such singular solutions.

In order to make the above outline more precise we shall first state a result which shows how the singular solutions (8,2,2,1) arise. For this purpose it is more convenient to consider a domain Q c Dl having only conical points corresponding to a regular basis G c S<sup>2</sup> . Exactly as in Chapter 4 we shall start from an a priori inequality in H <sup>2</sup>((), which has been derived in Hanna and Smith (1967).

We consider here a bounded open subset ( of R <sup>3</sup> such that 0 belongs to its boundary *F.* We assume that *F\{0}*  is of class C<sup>2</sup> ; we assume in

![](_page_378_Picture_3.jpeg)

Figure 8.1

addition that there exists a neighbourhood V of 0 such that, in V,  $\Omega$  coincides with the infinite cone C whose intersection with the unit sphere  $S^2$  is a subset G of  $S^2$  whose boundary  $\partial G$  is of class  $C^2$ .

Given  $f \in L_2(\Omega)$  we look for a solution  $u \in H^2(\Omega)$  of

$$\Delta u = f \qquad \text{in } \Omega \tag{8,2,2,3}$$

with either a Dirichlet boundary condition

$$\gamma u = 0 \qquad \text{on } \Gamma \tag{8,2,2,4}$$

or a Neumann boundary condition

$$\gamma \frac{\partial u}{\partial \gamma} = 0$$
 on  $\Gamma \setminus \{0\}$ . (8,2,2,5)

We denote by  $\Delta'$  the Laplace-Beltrami operator on G with the corresponding boundary condition, i.e. its domain is either  $H^2(G) \cap \mathring{H}^1(G)$  for a Dirichlet problem, or

$$\left\{ \varphi \in H^2(G) \mid \gamma \frac{\partial \varphi}{\partial \nu} = 0 \text{ on } \partial G \right\}$$

for a Neumann problem. In both cases this is a self-adjoint operator in  $H = L_2(G)$  whose spectrum is an infinite sequence of real numbers

—A<sup>1</sup> , 1= 1, 2,... where Al ; 0, with no limit point. We denote by 4i<sup>1</sup> , 1= 1, 2, ... the orthonormalized sequence of the related eigenfunctions. Thus we have

$$-\Delta'\psi_l = \lambda_l\psi_l \quad \text{in } G \tag{8,2,2,6}$$

where q <sup>1</sup> E H2(G) and either q1 e Hl(G) for a Dirichlet problem or y a <sup>j</sup>la v= 0 on 3G for a Neuman problem.

The basic *a priori* inequality for the equation (8,2,2,3) with one of the boundary conditions (8,2,2,4) or (8,2,2,5), does not follow from (8,2,2) since fl is not a polyhedron. We shall prove here the following statement.

*Theorem 8.2.2.1 Assume that Al 1 for every t; then there exists a constant C such that*

$$||u||_{2,2,\Omega} \le C[||\Delta u||_{0,2,\Omega} + ||u||_{0,2,\Omega}]$$
(8,2,2,7)

*for every u* E H2*(Q) which* f ul fits *either the boundary condition* (8,2,2,4) *or the boundary condition* (8,2,2,5).

(Of course one can drop the term 11U1111,2n in the case of a Dirichlet problem.)

It is clearly seen with the help of a partition of unity that inequality (8,2,2,7) follows from (3,1,1) and a similar inequality in C for functions with bounded support. (In addition, (8,2,2,7) is just (3,1,1) when the cone C is convex.)

Next the proof of the inequality in C relies on the use of weighted spaces similar to those introduced in Subsection 4.3.2. Indeed we denote by P2 (C) the space of all the functions u defined in C such that

$$r^{|\alpha|-m}D^{\alpha}u \in L_2(C)$$

for all lal ` m.t It is obvious that a function u e P2 (C) which has bounded support also belongs to Hm (C). The converse statement is true up to the addition of a finite-dimensional space. This will be stated in a precise f ashion below; however, we must observe at once that a similar statement for the two-dimensional case does not hold (see Kondratiev (1967), Theorem 4.3.2.2, which excludes the case when p =2 and the weaker statement in Theorem 7.2.1.1 when p = 2).

*Theorem 8.2.2.2 Let u E H2(C); then u* E P2(C) iff u(0) = 0.

The condition u(0) =0 is meaningful since every u E *H*2(C) is continuous in C (see inclusion (1,4,4,6)). Conversely every u E P2(C) is locally in H2 and therefore also continuous in C for the same reason.

*t P2 (C)* is equipped with the obvious norm (see Subsection 4.3.2).

Next the condition u(0) = 0 is necessary for u to belong to  $P_2^2(C)$ , since this requires  $u/r^2$  to be square integrable near zero and u is continuous there. We just have to prove that the above condition is sufficient. This will be done in two steps.

#### Lemma 8.2.2.3 The inequality

$$\left\{ \int_{C} \frac{|u(x)|^2}{|x|^2} \, \mathrm{d}x \right\}^{1/2} \le 2 \left\{ \int_{C} |\nabla u(x)|^2 \, \mathrm{d}x \right\}^{1/2} \tag{8.2.2.8}$$

holds for every  $u \in C_c^1(\bar{C})$ .

**Proof** For  $u \in C_c^1(\bar{C})$ , we have

$$u(r\sigma) = -\int_{t}^{\infty} \left\{ \frac{\mathrm{d}}{\mathrm{d}t} u(t\sigma) \right\} \mathrm{d}t = -\int_{t}^{\infty} \sum_{k=1}^{3} \sigma_{k} \frac{\partial u}{\partial x_{k}} (t\sigma) \, \mathrm{d}t$$

for every  $\sigma \in G$ .

It follows that

$$\frac{|u(r\sigma)|}{r} \leq \frac{1}{r} \int_{r}^{\infty} |\nabla u(t\sigma)| \, \mathrm{d}t.$$

Integrating, we obtain (8,2,2,8) by applying the second Hardy inequality (see Subsection 1.4.4) with  $\alpha = 1$ .

#### Lemma 8.2.2.4 The inequality

$$\left\{ \int_{C} \frac{|u(x)|^2}{|x|^4} \, \mathrm{d}x \right\}^{1/2} \le 2 \int_{C} \frac{|\nabla u(x)|^2}{|x|^2} \, \mathrm{d}x \right\}^{1/2} \tag{8.2.2.9}$$

holds for every  $u \in C_c^1(\overline{C})$  such that u(0) = 0.

Proof Here we have

$$u(r\sigma) = \int_0^r \left\{ \frac{\mathrm{d}}{\mathrm{d}t} u(t\sigma) \right\} \mathrm{d}t$$
$$= \int_0^r \sum_{k=1}^3 \sigma_k \frac{\partial u}{\partial x_k} (t\sigma) \, \mathrm{d}t$$

for every  $\sigma \in G$ .

It follows that

$$\frac{|u(r\sigma)|}{r^2} \leq \frac{1}{r^2} \int_0^r |\nabla u(t\sigma)| dt.$$

Integrating, we obtain (8,2,2,9) by applying the first Hardy inequality (see Subsection 1.4.4) with  $\alpha = 0$ .

Proof of Theorem 8.2.2.2 We consider  $u \in C_c^2(\tilde{C})$  a dense subspace in  $H^2(C)$  (by Theorem 1.4.2.1). We fix  $\eta \in \mathcal{D}(\bar{C})$  a cut-off function, such that  $\eta(0) = 0$ , and we apply the previous lemmas to

$$u - u(0)\eta$$

and its first derivatives respectively. We obtain

$$\int_{C} \frac{|u(x) - u(0)\eta(x)|^{2}}{|x|^{4}} dx + \int_{C} \frac{|\nabla (u - u(0)\eta)(x)|^{2}}{|x|^{2}} dx$$

$$\leq K \int_{C} \sum_{i,j=1}^{3} |D_{i}D_{j}(u - u(0)\eta)(x)|^{2} dx$$

for some constant K. By density (and Sobolev's imbedding theorem) the same inequality holds for every  $u \in H^2(C)$ . The conclusion follows when u(0) = 0.

Now a first step toward the proof of Theorem 8.2.2.1 is the following preliminary result.

#### Lemma 8.2.2.5 There exists a constant K such that

$$\|u\|_{P_{\alpha}^{2}(C)} \leq K \|\Delta u\|_{0.2.C} \tag{8,2,2,10}$$

for every  $u \in P_2^2(C)$  such that either  $\gamma u = 0$  on  $\partial C$  or  $\gamma \partial u/\partial \nu = 0$  on  $\partial C$ , provided  $\lambda_1 \neq \frac{3}{4}$  for every l.

Proof In spherical coordinates, the equation

$$\Delta u = f$$

means

$$\frac{\partial^2 u}{\partial r^2} + \frac{2}{r} \frac{\partial u}{\partial r} + \frac{1}{r^2} \Delta' u = f.$$

As in Subsection 4.3.2, we perform the change of variable  $r = e^t$ , setting

$$v(t,\sigma)=u(e^t\sigma)$$

$$g(t, \sigma) = e^{2t} f(e^t \sigma)$$

for every  $t \in \mathbb{R}$  and  $\sigma \in G$ . We obtain the equation

$$\frac{\partial^2 v}{\partial t^2} + \frac{\partial v}{\partial t} + \Delta' v = g \tag{8,2,2,11}$$

in the infinite cylinder  $B = \mathbb{R} \times G$ .

If we assume that  $\gamma u = 0$  on  $\partial C$ , then we have  $\gamma v = 0$  on  $\partial B$ ; otherwise

we assume that  $\gamma \partial u/\partial \nu = 0$  on  $\partial C$  and we have  $\gamma \partial v/\partial \nu = 0$  on  $\partial B$ . Finally the assumption that u belongs to  $P_2^2(C)$  implies that

$$e^{-t/2}D^{\alpha}v \in L_2(B) = L_2(\mathbb{R}; H)$$
 (8,2,2,12)

for every  $|\alpha| \leq 2$ .

Expanding both sides of equation (8,2,2,11) on the eigenfunctions  $\psi_i$ , one obtains

$$v_l''(t) + v_l'(t) - \lambda_l v_l(t) = g_l(t), \tag{8,2,2,13}$$

where

$$v_l(t) = \int_G v(t, \sigma) \psi_l(\sigma) d\sigma$$

$$g_l(t) = \int_G g(t, \sigma) \psi_l(\sigma) d\sigma.$$

In addition the condition (8,2,2,12) reads as follows:

$$\sum_{l=1}^{\infty} \int_{-\infty}^{+\infty} e^{-t} [|v_{l}''(t)|^{2} + |\lambda_{l}|^{2} |v_{l}(t)|^{2}] dt < +\infty.$$

The function  $g_l$  is given such that  $e^{-t/2}g_l \in L_2(\mathbb{R})$ ; consequently the equation (8,2,2,13) has a unique solution  $v_l$  such that

$$\int_{-\infty}^{+\infty} e^{-t} [|v_l''(t)|^2 + |v_l(t)|^2] dt < +\infty$$

iff  $\frac{1}{2}$  is not a root of the characteristic equation (of the differential equation)

$$\alpha^2 + \alpha - \lambda_t = 0.$$

This requirement means  $\lambda_l \neq \frac{3}{4}$ .

In addition it is easy to check that there exists a constant K such that

$$\left\{ \int_{-\infty}^{+\infty} e^{-t} |v_l(t)|^2 dt \right\}^{1/2} \leq \frac{K}{|\lambda_l|} \left\{ \int_{-\infty}^{+\infty} e^{-t} |g_l(t)|^2 dt \right\}^{1/2}$$

when  $l \rightarrow +\infty$ . Summing up, we have

$$\sum_{l=1}^{\infty} \int_{-\infty}^{+\infty} e^{-t} [|v_{l}''(t)|^{2} + |\lambda_{l}|^{2} |v_{l}(t)|^{2}] dt \le K'^{2} \sum_{l=1}^{\infty} \int_{-\infty}^{+\infty} e^{-t} |g_{l}(t)|^{2} dt$$

for some K' and this implies

$$\sum_{|\alpha| \le 2} \| e^{-t/2} D^{\alpha} v \|_{0,0,B} \le K'' \| e^{-t/2} g \|_{0,0,B}$$

by the Bessel identity.

Performing the inverse change of variable t =1n r, one obtains the desired inequality (8,2,2,10). n

*Proof of Theorem 8.2.2.1* Let us assume that *u E H2(D l* and fulfils a Dirichlet boundary condition, then we have u(0) =0 and consequently

$$\eta u \in P_2^2(C)$$

by Theorem 8.2.2.2, where 9 is a cut-off function such that q E gD (fl ), rn (x) = 1 near zero and the support of q is contained in V (the neighbourhood of zero in which L coincides with C). Therefore the inequality (8,2,2,7) follows from (8,2,2,10) and from (3,1,1).

When u E H2(Q) and fulfils a Neumann boundary condition the same procedure leads to the inequality (8,2,2,7) only for those functions u E H2(Q) such that

$$\gamma \frac{\partial u}{\partial \nu} = 0$$
 on  $\Gamma \setminus \{0\}$ 

and such that in addition

$$u(0)=0.$$

This last condition defines a subspace of codimension one in the space

$$V = \left\{ u \in H^2(\Omega); \, \gamma \frac{\partial u}{\partial \nu} = 0 \right\}$$

in which we want to prove the inequality.

The same technique as in the proof of Theorem 4.3.2.4 allows one to derive the weaker inequality

$$||u||_{2,2,\Omega} \le C\{||\Delta u||_{0,2,\Omega} + ||u||_{0,2,\Omega}\}$$

This completes the proof. n

From the inequality (8,2,2,7), we shall derive a Fredholm alternative quite similar to the one in Subsection 4.4.1. Let us derive it briefly now. We apply Lemma 4.4.1.1 to the operator A = 1 considered as an operator from

$$E_1 = \left\{ u \in H^2(\Omega; \gamma u = 0 \text{ on } \Gamma \quad \left( \text{respectively } \gamma \frac{\partial u}{\partial \nu} = 0 \text{ on } \Gamma \setminus \{0\} \right) \right\}$$

into E2 = L2(Q). Thus A has a finite-dimensional kernel and a closed range.

The kernel of A is obviously {0} in the case of a Dirichlet problem and the space of the constant functions in the case of a Neumann problem.

The closed range property is far more important. Let us denote by N the orthogonal of the range of A in  $L_2(\Omega)$ . As in Subsection 4.4.1, it is easily seen that every  $v \in N$  is harmonic in  $\Omega$  and such that  $\gamma v = 0$  on  $\Gamma \setminus \{0\}$  (respectively  $\partial v/\partial v = 0$  on  $\Gamma \setminus \{0\}$ ). Since  $\Gamma \setminus \{0\}$  is of class  $C^2$  the results in Chapter 2 imply that

$$v \in W_p^2(\Omega \setminus W)$$

for every  $p < \infty$  and every neighbourhood W of 0.

Then we look at the behaviour of v in V. In spherical coordinates, we have

$$\frac{\partial^2 v}{\partial r^2} + \frac{2}{r} \frac{\partial v}{\partial r} + \frac{1}{r^2} \Delta' v = 0.$$

Expanding v on the orthonormal system  $\psi_l$ ,  $l = 1, 2, \ldots$ , we obtain

$$v(r, \sigma) = \sum_{l>1} v_l(r)\psi_l(\sigma)$$

for r small enough (say  $\leq r_0$ ), where

$$\sum_{l\geq 1} \int_{0}^{r_0} |v_l(r)|^2 r^2 \, \mathrm{d}r \leq ||v||_{0,2,\Omega}^2. \tag{8.2.2.14}$$

In addition, we have

$$v_l''(r) + \frac{2}{r}v_l'(r) - \frac{\lambda_l}{r^2}v_l(r) = 0, \quad 0 < r < r_0,$$

since v is harmonic. Consequently

$$v_l(r) = a_l r^{\alpha_l} + b_l r^{\beta_l}$$

where  $a_l$  and  $b_l$  are arbitrary real numbers and

$$\alpha_l = \frac{-1 + \sqrt{(1+4\lambda_l)}}{2}, \qquad \beta_l = \frac{-1 - \sqrt{(1+4\lambda_l)}}{2}.$$

The condition (8,2,2,14) readily implies that  $b_l = 0$  unless  $\lambda_l < \frac{3}{4}$ . Thus we have

$$v(r,\sigma) = \sum_{\lambda_i < 3/4} b_i r^{\beta_i} \psi_i(\sigma) + \sum_{l \ge 1} a_l r^{\alpha_l} \psi_i(\sigma).$$

It is clearly checked that the first sum (which is finite) does not belong to  $H^1(\Omega \cap \{r < r_0\})$  while each term of the second sum belongs to this space. More precisely, applying the method of Proposition 4.4.2.2, one shows that this series actually converges in  $H^1(\Omega \cap \{r < r_0'\})$  for every  $r_0' \in ]0, r_0[$ . Finally this implies that the dimension of N is the number  $\mu$  of the

eigenvalues Al which are less than 4 in the case of a Dirichlet problem and µ + 1 in the case of a Neumann problem (see the proof of Theorem 4.4.3.3).

Summing up, we have sketched the proof of the following result of Kondratiev (1967a).

Theorem 8.2.2.6 Assume that A, 4 for every 1 and denote by g the *number of eigenvalues k <sup>l</sup> such that*

$$\lambda_l < \frac{3}{4}$$

0 *then* the space *d (H2(D) n H<sup>1</sup> (l )) (respectively 1{u E H2([2); -y* au/av = 0 *on V\{0}}) has codimension g (respectively µ + 1)* in *L<sup>2</sup> (fJ).*

Consequently we must add µ singular functions to the space H <sup>2</sup>(fl) in order to describe all the solutions of the equation (8,2,2,3) with f given in L2(Q) under the boundary condition (8,2,2,4) (respectively (8,2,2,5)). Applying the technique of Theorem 4.4.3.7, we set

$$s_l(r\sigma) = r^{\alpha_l}\psi_l(\sigma)\eta(r\sigma)$$

for Al <. These functions are functions belonging to

$$H^2(\Omega)\setminus H^1(\Omega)$$

and such that

$$\Delta s_l \in L^2(\Omega)$$

and they fulfil the boundary condition (8,2,2,4) (respectively (8,2,2,5)). Accordingly, we have the following statement.

Corollary *8.2.2.7* Assume that *Â, 4 for every 1;* then *for every f E L<sup>2</sup> (f ) there* exist *constants c <sup>1</sup> and a function u* such that

$$u - \sum_{\lambda_1 < 3/4} c_l s_l \in H^2(\Omega),$$

*u is solution of the equation* (8,2,2,3) *and f ul* fils *the boundary condition* (8,2,2,4) *(respectively* (8,2,2,5) *provided* J0 f dx = 0); u is *unique (respec*tively unique up to the *addition of a* constant).

This shows that a conical point produces singular solutions of the form (8,2,2,1).

Let us now discuss the assumption A, 4, which has been useful in deriving the *a priori* inequality (8,2,2,7). It is easy to check that when G is contained in a hemisphere then the first eigenvalue A <sup>l</sup> corresponding to the Dirichiet problem is greater than or equal to 1 (cf. for instance Grisvard (1975b)). Accordingly we have shown that *u* belongs to *H2(fl),* when the cone C is convex; this was proved in Chapter 3. On the other hand let us consider the particular case when G is a circular cone of angle  $\beta$ . It is shown in Hanna and Smith (1967) that when  $\beta$  increases from  $\pi$  to  $2\pi$ , the first eigenvalue  $\lambda_1$  decreases from 1 to 0. Consequently there is one value ( $\beta \cong 1.45\pi$ ) for which the above method of proof is inconclusive (actually, the *a priori* inequality (8,2,2,7) does not hold either).

Curiously the inequality (8,2,2,7) always holds for polyhedral cones, i.e. cones for which  $\partial G$  is the union of a finite number of arcs of great circles (cf. inequality (8,2,2)). When the domain of  $\Delta'$  is contained in  $H^2(G)$ , the method of proof of Theorem 8.2.2.6 still works. This shows again the regularity of u in  $H^2(\Omega)$  when  $\Omega$  is a convex polyhedron.

So far, we have shown precisely how the singular functions of the form (8,2,2,1) arise. When  $\Omega$  is a polyhedron several edges meet at the same vertex. Each edge is likely to produce the kind of singular solutions that we have described in Subsection 8.2.1: the functions in Lemma 8.2.1.1 are of the form (8,2,2,2) near each vertex. Unfortunately the precise behaviour of the function  $\psi$  in (8,2,2,2) as  $r \rightarrow 0$  is not yet known.

To conclude this subsection, we give a statement which summarizes the results in Theorem 8.2.1.2 when m=2 and an extension to  $p\neq 2$  of Corollary 8.2.2.7 when  $\Omega$  is a polyhedron. The basic assumption is that the angle of the edges are small enough not to produce edge singularities. The proof is very technical and may be found in Grisvard (1975a).

We need some auxiliary notation. We denote by  $S_i$  the vertices of  $\Omega$ ,  $1 \le i \le I$ , and by  $G_i$  the intersection of the unit sphere centred at  $S_i$  with the cone  $C_i$  corresponding to  $S_i$ . We denote by  $\lambda_{i,l}$ ,  $l=1,2,\ldots$  the sequence of the eigenvalues of  $-\Delta'$  in  $G_i$  with the corresponding boundary conditions.

#### **Theorem 8.2.2.8** We assume that

- (a)  $2-2/p < \pi/\omega_{j,k}$  when j and  $k \in \mathcal{D}$  or when j and  $k \in \mathcal{N}$ .
- (b)  $2-2/p < \pi/2\omega_{j,k}$  when  $j \in \mathcal{D}$  and  $k \in \mathcal{N}$  or when  $j \in \mathcal{N}$  and  $k \in \mathcal{D}$ .

We assume in addition that  $\lambda_{i,l} \neq (2-3/p)(3-3/p)$  for every i and every l. Then the space

$$\Delta \left\{ u \in W_p^2(\Omega); \, \gamma_j u = 0 \text{ on } \Gamma_j, \, j \in \mathcal{D}, \, \gamma_j \frac{\partial u}{\partial \nu_j} = 0 \text{ on } \Gamma_j, \, j \in \mathcal{N} \right\}$$

has codimension (we assume that D is not empty for simplicity)

$$\mu = \sum_{i=1}^{l} \operatorname{card} \left\{ l \mid \lambda_{i,l} < \left(2 - \frac{3}{p}\right) \left(3 - \frac{3}{p}\right) \right\}$$

in  $L_p(\Omega)$ .

Consequently the solution u of the problem (8,2,1) with f given in  $L_n(\Omega)$  is such that

$$u - \sum_{i=1}^{I} \sum_{\lambda_{i,l} < (2-3/p)(3-3/p)} c_{i,l} s_{i,l} \in W_p^2(\Omega)$$

where  $c_{i,l}$  are real constants and

$$s_{i,l}(r_i\sigma_i) = r_i \frac{-1 + \sqrt{(1+4\lambda_{i,l})}}{2} \psi_{i,l}(\sigma_i) \eta_i(r_i\sigma_i)$$

in an obvious notation; namely:  $r_i$  denotes the distance to  $S_i$ ,  $\sigma_i$  a point of  $G_i$ ,  $\psi_{i,l}$  is the normalized eigenfunction, corresponding to  $-\lambda_{i,l}$ , of  $\Delta'$  with suitable boundary conditions; finally  $\eta_i$  is a cut-off function depending only on  $r_i$  such that  $\eta_i \in \mathcal{D}(\bar{\Omega})$ ,  $\eta_i = 1$  near  $S_i$  and  $\eta_i = 0$  outside some neighbourhood of  $S_i$ .

Remark 8.2.2.9 An asymptotic expansion near the vertices of the singular part of the solution corresponding to an edge is derived in Grisvard (1982) in the particular case p = 2 when the assumption (a) in Theorem 8.2.2.8 is not fulfilled.

#### 8.3 The heat equation

It is well known that one can derive several properties of the heat equation by applying semigroup theory, provided one has a good knowledge of the properties of the Laplace operator (and its resolvent operator). This method has been applied successfully for solving the heat equation with various mixed boundary conditions in regular cylinders. We mean here a cylinder Q of the form

$$Q = ]0, T[ \times \Omega$$

where  $\Omega$  is a domain with a smooth boundary in  $\mathbb{R}^n$  and ]0, T[ is an interval in time. Possible references are Lions (1956), Lions and Magenes (1960-63), Krein (1967). One can apply the same kind of method when  $\Omega$  is a plane polygon and consequently  $\Omega$  is a cylinder with edges.

However, we shall consider here a different problem. We shall solve a mixed boundary value problem for the heat equation in a domain Q which may not be the Cartesian product of an interval in time by a domain in space. Here we follow work by Sadallah (1976, 1977, 1978). For simplicity, we consider a problem with only one space variable. To be precise, we assume that

$$Q = \{(t, x) \mid 0 < t < T, \varphi_1(t) < x < \varphi_2(t)\},\$$

![](_page_388_Figure_3.jpeg)

Figure 8.2

where T is a finite positive number, while  $\varphi_1$  and  $\varphi_2$  are continuous real-valued functions defined in [0, T] Lipschitz continuous in ]0, T[, such that

$$\varphi_1(t) < \varphi_2(t)$$

for  $t \in ]0, T[$ . Given  $f \in L_2(Q)$  we look for a solution u (as regular as possible) of

$$\begin{cases} D_{t}u - D_{x}^{2}u = f & \text{in } Q \\ u(0, x) = 0, & \varphi_{1}(0) < x < \varphi_{2}(0) \\ u(t, \varphi_{1}(t)) = u(t, \varphi_{2}(t)) = 0, & 0 < t < T. \end{cases}$$
(8,3,1)

We emphasize that we shall allow  $\varphi_1$  to coincide with  $\varphi_2$  for t=0 and for t=T. Actually domains of the same kind under a weaker assumption on  $\varphi_1$  and  $\varphi_2$  are considered in the works by Baderko (1973, 1975, 1976). This author assumes that  $\varphi_1$  and  $\varphi_2$  are only Hölder continuous (with exponent larger than or equal to  $\frac{1}{2}$ ) and solves the heat equation in Q by the potential method introduced by Gevrey (1913). However, in order to apply this method, one must assume that  $\varphi_1(0) < \varphi_2(0)$  and that  $\varphi_1(T) < \varphi_2(T)$ .

Actually the method of Sadallah, which we shall outline here, is a straightforward extension of Chapter 3. We first prove an a priori estimate when Q is nice (in a sense to be defined later), and then we take limits in Q in order to reach the kind of domains described above. The a priori inequality is proved simply by integration by parts, and again we have very accurate control of the constants involved, as functions of Q; this is why we are able to take limits in Q.

The result we are going to prove here is the following, for which we need the technical assumption

$$\varphi_i'(t)[\varphi_2(t) - \varphi_1(t)] \to 0$$
 as  $t \to 0$ ,  $i = 1, 2$  (8,3,2)

if  $\varphi_1(0) = \varphi_2(0)$  and

$$\varphi_i'(t)[\varphi_2(t) - \varphi_1(t)] \to 0$$
 as  $t \to T$ ,  $i = 1, 2$  (8,3,3)

if  $\varphi_1(T) = \varphi_2(T)$ .

**Theorem 8.3.1** Assume that (8,3,2) and (8,3,3) hold and that f is given in  $L_2(Q)$ ; then there exists a unique function u which is a solution of

$$D_t u - D_x^2 u = f in Q (8,3,4)$$

such that  $u, D_t u, D_x u$  and  $D_x^2 u$  belong to  $L_2(Q)$  and

$$\begin{cases} \gamma u(t, \varphi_i(t)) = 0, & 0 < t < T, \quad i = 1, 2 \\ \gamma u(0, x) = 0, & \varphi_1(0) < x < \varphi_2(0). \end{cases}$$
(8,3,5)

We observe that u belongs to  $H^1(Q)$  and consequently the trace  $\gamma u$  is well defined on  $\partial Q$  away from the points  $(0, \varphi_i(0))$  and  $(T, \varphi_i(T))$ , i = 1, 2. Indeed these are the only possible points in a neighbourhood of which the boundary  $\partial Q$  may not be Lipschitz.

We emphasize that this is an existence result for a strong solution. The existence and uniqueness of a weak solution with, say,

$$u$$
 and  $D_x u \in L_2(Q)$ ,

are easy to derive (see Oleinik and Radkievitz (1971) for instance). Thus Theorem 8.3.1 is mainly a smoothness result.

Let us now carry out some preliminaries. For the time being we consider the simpler case which follows. We replace Q by

$$Q_{\alpha} = \{(t, x) \mid \alpha < t < T - \alpha, \, \varphi_1(t) < x < \varphi_2(t)\}$$

with  $\alpha > 0$ . Thus we have

$$\begin{cases} \varphi_1(\alpha) < \varphi_2(\alpha) \\ \varphi_1(T-\alpha) < \varphi_2(T-\alpha) \end{cases}$$

and  $\varphi_1$  and  $\varphi_2$  are uniformly Lipschitz continuous in  $[\alpha, t-\alpha]$ . In this case it is very easy to prove the result corresponding to Theorem 8.3.1. Indeed, we can easily find a change of variable  $\psi$  mapping  $Q_{\alpha}$  onto the rectangle

$$R_{\alpha} = ]\alpha, T - \alpha[\times]0,1[,$$

which leaves the t variable unchanged. We define  $\psi$  as follows:

$$\psi(t,x) = \left\{t, \frac{x - \varphi_1(t)}{\varphi_2(t) - \varphi_1(t)}\right\}.$$

Then we define the functions v and g in  $R_{\alpha}$  by

$$v = u \circ \psi^{-1}$$
 and  $g = f \circ \psi^{-1}$ .

The equation

$$D_t u - D_x^2 u = f$$

in  $Q_{\alpha}$  is equivalent to the following:

$$D_t v + a(t, x) D_x v - b(t) D_x^2 v = g$$
 (8,3,6)

in  $R_{\alpha}$ , where a and b are defined by

$$a(t, x) = D_t \left( \frac{x - \varphi_1(t)}{\varphi_2(t) - \varphi_1(t)} \right)$$
$$b(t) = \frac{1}{[\varphi_2(t) - \varphi_2(t)]^2}.$$

The mapping  $\psi$  is bi-Lipschitz and therefore it preserves the space  $H^1$ . In other words u belongs to  $H^1(Q_\alpha)$  iff  $v \in H^1(R_\alpha)$ . The boundary conditions on v which correspond to the boundary conditions on u are the following:

$$\begin{cases} \gamma v(\alpha, x) = 0, & 0 < x < 1 \\ \gamma v(t, 0) = v(t, 1) = 0, & \alpha < t < T - \alpha. \end{cases}$$

$$(8,3,7)$$

In a first step we consider the simplified equation

$$D_t v - b(t)D_x^2 v = g \qquad \text{in } R_\alpha$$
 (8,3,8)

with the same boundary conditions on v.

**Lemma 8.3.2** For every  $g \in L_2(R_\alpha)$  there exists a unique  $v \in H^1(R_\alpha)$ , with  $D_x^2 v \in L_2(R_\alpha)$ , which is a solution of (8,3,8) and (8,3,7).

**Proof** A simple change of variable (in t) reduces equation (8,3,6) to the heat equation and we can apply some classical results.

Indeed we define the function  $\beta$  as follows:

$$\beta(t) = \int_{\alpha}^{t} b(s) \, \mathrm{d}s.$$

This is an invertible  $C^{1,1}$  mapping from  $[\alpha, T-\alpha]$  onto  $[0, \beta(T-\alpha)]$ . It

follows from Lions and Magenes (1968), for instance, that there exists a solution  $w \in H^1(R'_{\alpha})$  of

$$D_t w - D_x^2 w = g/b$$

in  $R'_{\alpha} = ]0, \beta(T-\alpha)[\times]0, 1[$ , with

$$\begin{cases} \gamma w(0, x) = 0, & 0 < x < 1 \\ \gamma w(t, 0) = \gamma w(t, 1) = 0, & 0 < t < \beta(T - \alpha) \end{cases}$$

and such that in addition  $D_x^2 w \in L_2(R'_{\alpha})$ .

We obtain the desired function v by setting

$$v(t, x) = w(\beta(t), x).$$

**Lemma 8.3.3** For every  $g \in L_2(R_\alpha)$  there exists a unique solution  $v \in H^1(R_\alpha)$ , with  $D_x^2 v \in L_2(R_\alpha)$ , of (8,3,6) and (8,3,7).

*Proof* We denote by A the operator  $D_t - b(t)D_x^2$  defined from

$$V = \{v \in H^1(R_\alpha) \mid D_x^2 v \in L_2(R_\alpha), v \text{ fulfils } (8,3,7)\}$$

into  $L_2(R_\alpha)$ . We have shown in Lemma 8.3.2 that A is an isomorphism.

Then it is known (cf. for instance Besov [1969]) that  $D_x$  is a compact operator from V into  $L_2(R_\alpha)$ .† Since a is a bounded function, the operator  $aD_x$  is also compact from V into  $L_2(R_\alpha)$ . Consequently  $A + aD_x$  is a Fredholm operator (with index zero) from A into  $L_2(R_\alpha)$ . Thus the invertibility of  $A + aD_x$  will follow from its injectivity.

Accordingly let us consider  $v \in V$ , a solution of

$$D_t v + aD_x v - bD_x^2 v = 0,$$

in  $R_{\alpha}$ . We perform the inverse change of variable of  $\psi$ . Thus we set  $u = v \circ \psi$ .

It turns out that  $u \in H^1(Q_\alpha)$ ,  $D_x^2 u \in L_2(Q_\alpha)$  and

$$D_t u - D_x^2 u = 0 \quad \text{in } Q_\alpha.$$

In addition u fulfils the homogeneous boundary condition (8,3,5). As

† Actually since  $R_{\alpha}$  is a rectangle, it can easily be shown that there exists a continuous extension operator from  $H^{1,2}(R_{\alpha})$  into  $H^{1,2}(\mathbb{R}^2)$ ; here for a general plane domain  $\Omega$ ,  $H^{1,2}(\Omega)$  is defined by

$$H^{1,2}(\Omega) = \{u \mid u, D_t u, D_x u, D_x^2 u \in L_2(\Omega)\}.$$

Then the compactness of  $u \to \varphi D_x u$  from  $H^{1,2}(\mathbb{R}^2)$  into  $L_2(\mathbb{R}^2)$  is easily checked by Fourier transform, provided  $\varphi \in \mathfrak{D}(\mathbb{R}^2)$ .

usual we calculate the integral:

$$\int_{Q_n} (D_t u - D_x^2 u) u \, \mathrm{d}t \, \mathrm{d}x.$$

This yields

$$\frac{1}{2} \int_{O_{x}} |\gamma u|^{2} \nu_{1} ds - \int_{O_{x}} \gamma D_{x} u \gamma u \nu_{2} ds + \int_{O_{x}} |D_{x} u|^{2} dt dx = 0.$$

All the boundary integrals vanish but

$$\frac{1}{2} \int_{\alpha, (T-\alpha)}^{\varphi_2(T-\alpha)} |\gamma u(T-\alpha, x)|^2 dx,$$

which is nonnegative. This yields the inequality

$$\int_{\Omega_{x}} |D_{x}u|^{2} dt dx \leq 0,$$

which implies that u vanishes; this is the desired injectivity.

So far we have proved the desired result in the better domains  $Q_{\alpha}$ . Now we shall prove an *a priori* estimate which will allow us to take limits in  $\alpha$ .

**Lemma 8.3.4** Let ]a, b[ be a finite real interval. There exists a constant C (independent of a and b) such that

$$\int_{a}^{b} |v(x)|^{2} dx \le C(b-a)^{2} \int_{a}^{b} |v'(x)|^{2} dx$$

for every  $v \in H^1(]a, b[)$  such that  $\int_a^b v(x) dx = 0$ .

The proof of this inequality may be found in Nečas (1967) for instance (it is elementary: actually the general case follows from the particular case ]a, b[=]0, 1[ by an affine change of variable).

We shall apply this inequality later to the function  $D_x u$ , where u fulfils the assumptions of Theorem 8.3.1. This yields the inequality

$$\int_{\varphi_1(t)}^{\varphi_2(t)} |D_x u(t,x)|^2 dx \le C[\varphi_2(t) - \varphi_1(t)]^2 \int_{\varphi_1(t)}^{\varphi_2(t)} |D_x^2 u(t,x)|^2 dx.$$
 (8,3,9)

Since we have

$$\int_{\varphi_1(t)}^{\varphi_2(t)} D_x u(t, x) dx = \gamma u(t, \varphi_2(t)) - \gamma u(t, \varphi_1(t)) = 0.$$

**Lemma 8.3.5** We assume that  $\varphi_1$  and  $\varphi_2$  fulfil the conditions (8,3,2) and

(8,3,3). We assume in addition that  $u \in C^2(\bar{Q}_{\alpha})$  and

$$\begin{cases} u(\alpha, x) = 0, & \varphi_1(\alpha) \leq x \leq \varphi_2(\alpha) \\ u(t, \varphi_1(t)) = u(t, \varphi_2(t)) = 0, & \alpha \leq t \leq T - \alpha. \end{cases}$$

There exists a constant K which does not depend on  $\alpha$  and u such that

$$||u||^2 + ||D_t u||^2 + ||D_x u||^2 + ||D_x^2 u||^2 \le K ||D_t u - D_x^2 u||^2$$
(8,3,10)

in the norm of  $L_2(Q_{\alpha})$ .

**Proof** There are two main steps. First we derive a bound for  $D_x u$  by calculating

$$\int_{\Omega} (D_t u - D_x^2 u) u \, dt \, dx.$$

Second we derive a bound for  $D_x^2u$  and  $D_tu$  by calculating

$$\int_{\Omega} (D_t u - D_x^2 u)^2 dt dx$$

as we did in Chapter 3.

Setting  $f = D_t u - D_x^2 u$ , we have

$$\int_{Q_{\alpha}} fu \, dt \, dx = \int_{Q_{\alpha}} |D_{x}u|^{2} \, dt \, dx + \frac{1}{2} \int_{\partial Q_{\alpha}} |u|^{2} \nu_{1} \, ds - \int_{\partial Q_{\alpha}} D_{x}uu\nu_{2} \, ds$$

$$\geq \int_{Q_{\alpha}} |D_{x}u|^{2} \, dt \, dx.$$

It follows that

$$||D_x u||^2 \le ||f|| ||u||$$

in the norm of  $L_2(Q_{\alpha})$ .

On the other hand, Poincaré's inequality implies that

$$||u|| \leq L ||D_x u||,$$

where  $L = \max_{t \in [0,T]} [\varphi_2(t) - \varphi_1(t)]$ . It follows that

$$||u|| \le L^2 ||f||$$
  
 $||D,u|| \le L ||f||$ . (8,3,11)

Then we have

$$\int_{Q_{\alpha}} f^{2} dt dx = \int_{Q_{\alpha}} |D_{t}u|^{2} dt dx + \int_{Q_{\alpha}} |D_{x}u|^{2} dt dx + \int_{\partial Q_{\alpha}} [|D_{x}u|^{2} \nu_{1} - 2D_{t}uD_{x}u\nu_{2}] ds.$$
 (8,3,12)

We shall rewrite the boundary integral making use of the boundary conditions (8,3,5).

On the part of the boundary where  $t = \alpha$ , we have  $\nu_2 = 0$ , u = 0 and consequently  $D_x u = 0$ . The corresponding boundary integral vanishes. Then on the part of the boundary where  $t = T - \alpha$ , we have again  $\nu_2 = 0$  and  $\nu_1 = 1$ . Accordingly the corresponding boundary integral is nonnegative and we can forget it.

On the part of the boundary where  $x = \varphi_i(t)$ , i = 1, 2, we have

$$u(t,\,\varphi_i(t))=0.$$

Differentiating with respect to t we obtain

$$D_t u = -\varphi_t'(t) D_x u.$$

Consequently the corresponding boundary integral is

$$\mathcal{I} = -\int_{\alpha}^{T-\alpha} |D_{x}u(t, \varphi_{1}(t))|^{2} \varphi'_{1}(t) dt + \int_{\alpha}^{T-\alpha} |D_{x}u(t, \varphi_{2}(t))|^{2} \varphi'_{2}(t) dt.$$
(8,3,13)

We convert this boundary integral into a surface integral by setting

$$\begin{split} [D_{x}u(t,\varphi_{1}(t))]^{2} &= -\frac{\varphi_{2}(t) - x}{\varphi_{2}(t) - \varphi_{1}(t)} [D_{x}u(t,x)]^{2} \Big|_{x = \varphi_{1}(t)}^{x = \varphi_{2}(t)} \\ &= -\int_{\varphi_{1}(t)}^{\varphi_{2}(t)} \frac{\partial}{\partial x} \left\{ \frac{\varphi_{2}(t) - x}{\varphi_{2}(t) - \varphi_{1}(t)} [D_{x}u(t,x)]^{2} \right\} dx \\ &= -\int_{\varphi_{1}(t)}^{\varphi_{2}(t)} \frac{\varphi_{2}(t) - x}{\varphi_{2}(t) - \varphi_{1}(t)} 2D_{x}u(t,x)D_{x}^{2}u(t,x) dx \\ &+ \int_{\varphi_{1}(t)}^{\varphi_{2}(t)} \frac{1}{\varphi_{2}(t) - \varphi_{1}(t)} [D_{x}u(t,x)]^{2} dx \end{split}$$

and consequently

$$|D_{x}u(t,\varphi_{1}(t))|^{2} \leq 2 \int_{\varphi_{1}(t)}^{\varphi_{2}(t)} |D_{x}u(t,x)| |D_{x}^{2}u(t,x)| dx + \int_{\varphi_{2}(t)}^{\varphi_{2}(t)} \frac{1}{\varphi_{2}(t) - \varphi_{1}(t)} |D_{x}u(t,x)|^{2} dx.$$

A similar inequality holds for  $D_x u(t, \varphi_2(t))$  and this yields

$$|\mathcal{I}| \leq 2 \int_{Q_{\alpha}} |D_{x}u| |D_{x}^{2}u| [|\varphi'_{1}(t)| + |\varphi'_{2}(t)|] dt dx$$

$$+ \int_{Q_{\alpha}} \frac{|\varphi'_{1}(t)| + |\varphi'_{2}(t)|}{|\varphi_{2}(t) - \varphi_{1}(t)|} |D_{x}u|^{2} dt dx.$$

It follows that

$$|\mathcal{J}| \leq \frac{1}{2} ||D_x^2 u||^2 + \int_{Q_\alpha} |D_x u|^2 \left\{ 2[|\varphi_1'(t)| + |\varphi_2'(t)|]^2 + \frac{|\varphi_1'(t)| + |\varphi_2'(t)|}{\varphi_2(t) - \varphi_1(t)} \right\} dt dx.$$

With inequality (8,3,9) this yields

$$|\mathcal{J}| \leq \frac{1}{2} ||D_x^2 u||^2 + M_{\varepsilon} ||D_x u||^2 + N_{\varepsilon} ||D_x^2 u||^2$$

where

$$M_{\varepsilon} = \lim_{t \in ]\varepsilon, T - \varepsilon} \left\{ 2[|\varphi_1'(t)| + |\varphi_2'(t)|]^2 + \frac{|\varphi_1'(t)| + |\varphi_2'(t)|}{\varphi_2(t) - \varphi_1(t)} \right\}$$

and

$$N_{\varepsilon} = \lim_{t \in ]0, \varepsilon} \lim_{t \in ]0, \varepsilon} \left\{ 2[|\varphi_1'(t)| + |\varphi_2'(t)|]^2 [\varphi_2(t) - \varphi_1(t)]^2 + [|\varphi_1'(t)| + |\varphi_2'(t)|] [\varphi_2(t) - \varphi_1(t)] \right\}$$

for every  $\varepsilon > 0$ .

Going back to (8,3,12) we have

$$||D_{x}u||^{2} + ||D_{x}^{2}u||^{2} \le ||f||^{2} + |\mathcal{I}| \le ||f||^{2} + (\frac{1}{2} + N_{\epsilon}) ||D_{x}^{2}u||^{2} + M_{\epsilon} ||D_{x}u||^{2};$$

with (8,3,11), this yields

$$||D_t u||^2 + ||D_x^2 u||^2 \le (1 + L^2 M_{\epsilon}) ||f||^2 + (\frac{1}{2} + N_{\epsilon}) ||D_x^2 u||^2.$$

Finally we take advantage of the assumptions (8,3,2) and (8,3,3). Thus choosing  $\varepsilon$  small enough, we have  $N_{\varepsilon} \leq \frac{1}{4}$  and consequently

$$||D_t u||^2 + \frac{1}{4} ||D_x^2 u||^2 \le (1 + L^2 M_{\epsilon}) ||f||^2.$$

Summing up, we have

$$||u||^2 + ||D_x u||^2 + ||D_x^2 u||^2 + ||D_t u||^2 \le \{L^4 + L^2 + 5(1 + L^2 M_{\epsilon})\} ||f||^2$$

provided  $N_{\varepsilon} \leq \frac{1}{4}$ .

We shall need an extension of inequality (8,3,10) to functions with less regularity. This requires a density lemma:

**Lemma 8.3.6** Every  $u \in H^1(Q_\alpha)$  such that

$$\begin{cases} D_x^2 u \in L_2(Q_\alpha) \\ \gamma u(t, \varphi_1(t)) = \gamma u(t, \varphi_2(t)) = 0, & \alpha < t < T - \alpha \\ \gamma u(\alpha, x) = 0, & \varphi_1(\alpha) < x < \varphi_2(\alpha) \end{cases}$$

can be approximated by a sequence  $u_n$ , n = 1, 2, ... of functions belonging

$$\begin{cases} u_n(t, \varphi_1(t)) = u_n(t, \varphi_2(t)) = 0, & \alpha < t < T - \alpha \\ u_n(\alpha, x) = 0, & \varphi_1(\alpha) < x < \varphi_2(\alpha). \end{cases}$$

The convergence is such that

$$||u_n - u||_{1,2,Q_n} + ||D_x^2(u_n - u)||_{0,2,Q_n} \to 0$$
  
as  $n \to +\infty$ .

**Proof** One easily replaces  $Q_{\alpha}$  by  $R_{\alpha}$  with the help of the change of variable  $\psi$  defined above. Then the proof in the case of  $R_{\alpha}$  is just an exercise.

This implies clearly that the inequality (8,3,10) holds for every  $u \in H^1(Q_\alpha)$  which fulfils the assumptions in Lemma 8.3.6. We are now able to prove Theorem 8.3.1.

*Proof of Theorem 8.3.1* By Lemma 8.3.3, there exists for each  $\alpha > 0$  (small enough), a unique

$$u_{\alpha} \in H^1(Q_{\alpha})$$

Downloaded 10/24/25 to 211.83.126.166. Redistribution subject to SIAM license or copyright; see https://epubs.siam.org/terms-privacy

such that  $D_x^2 u_{\alpha} \in L_2(Q_{\alpha})$  and

$$\begin{cases} D_t u_{\alpha} - D_x^2 u_{\alpha} = f & \text{in } Q_{\alpha} \\ u_{\alpha}(\alpha, x) = 0, & \varphi_1(\alpha) < x < \varphi_2(\alpha) \\ u_{\alpha}(t, \varphi_1(t)) = u_{\alpha}(t, \varphi_2(t)) = 0, & \alpha < t < T - \alpha. \end{cases}$$

In addition the inequality (8,3,10) holds for  $u_{\alpha}$  and accordingly we have

$$||u_{\alpha}||_{1,2,Q_{\alpha}}^{2} + ||D_{x}^{2}u_{\alpha}||_{0,2,Q_{\alpha}}^{2} < K ||f||_{0,2,Q_{\alpha}}^{2}.$$

We consider a sequence  $\alpha_n \to 0$ , as  $n \to +\infty$ . The related sequences of functions

$$u_{\alpha_n}$$
,  $D_t u_{\alpha_n}$ ,  $D_x u_{\alpha_n}$  and  $D_x^2 u_{\alpha_n}$ 

 $n=1,2,\ldots$ , are bounded in  $L_2(Q)$ . By replacing  $\alpha_n$  by a suitable subsequence (that we denote again by  $\alpha_n$ ,  $n=1,2,\ldots$  for simplicity), there exist functions

$$u$$
,  $v_1$ ,  $v_2$  and  $w$ 

in  $L_2(Q)$  such that

$$\tilde{u}_{\alpha_n} \to u \qquad \widetilde{D_t u_{\alpha_n}} \to v_1 \qquad \widetilde{D_x u_{\alpha_n}} \to v_2 \qquad \widetilde{D_x^2 u_{\alpha_n}} \to w$$

weakly in  $L_2(Q)$  as  $n \to +\infty$ .

The remainder of the proof is similar to the proof of Theorem 3.2.1.2. We have clearly

$$v_1 = D_t u$$
,  $v_2 = D_x u$  and  $w = D_x^2 u$ 

in the sense of distributions in Q and consequently we have

$$D_t u - D_x^2 u = f \quad \text{in } Q.$$

Finally let  $\varphi \in \mathfrak{D}(\mathbb{R})$  be such that

$$\begin{cases} \varphi(t) = 1 & \text{for } t \le T - \varepsilon \\ \varphi(t) = 0 & \text{for } t \ge T - \varepsilon/2. \end{cases}$$

with  $\varepsilon > 0$ . We have clearly

$$\varphi \tilde{u}_{\alpha} \in \mathring{H}^{1}(Q)$$

and  $\varphi \tilde{u}_{\alpha}$  remains bounded in  $\mathring{H}^{1}(Q)$ . Thus, taking the limit, we have  $\varphi u \in \mathring{H}^{1}(Q)$ .

This implies that

$$(\gamma u)(0, x) = 0,$$
  $\varphi_1(0) < x < \varphi_2(0)$   
 $(\gamma u)(t, \varphi_1(t)) = (\gamma u)(t, \varphi_2(t)) = 0,$   $0 < t < T - \varepsilon.$ 

Since the above boundary conditions hold for every  $\varepsilon > 0$  we have proved the existence of a function u having the properties listed in Theorem 8.3.1. As we have already observed the uniqueness of u is classical.

Remark 8.3.7 Inspection of the identity (8,3,12) shows that the condition (8,3,2) is useless when  $\varphi_2$  is nondecreasing and  $\varphi_1$  is nonincreasing near zero. In the same way, the condition (8,3,3) is useless when  $\varphi_2$  is nondecreasing and  $\varphi_1$  is nonincreasing near T.

Remark 8.3.8 The works by Sadallah mentioned above include similar results for the heat equation in more space variables and for the equation

$$D_t u + (-1)^m D_x^{2m} u = f,$$

m an arbitrary positive integer (such an equation is also studied in the works by Baderko mentioned above).

The domains considered in Theorem 8.3.1 include all the convex polygons but not all the polygons. However, it is very easy to derive a similar result for any polygon.

Corollary 8.3.9 Let Q be a plane open domain with a polygonal bound-

*ary. Then the operator D, — D is a one-to-one operator from*

$$V = \{u \in H^1(Q); D_x u \in L_2(Q), \gamma u = 0 \text{ on } \Gamma'\}$$

*into L<sup>2</sup> (Q), where T' is the part of the boundary aQ where* v*l < 1. In addition the image of D, — DX is closed and has finite codirension µ, the number of corners S; = (t;, x; ), with the following property: There exists a neighbourhood Ui of Si such that*

$$t \ge t_i$$

*for every point (t, x) E* U; fl Q.

The proof consists in applying Theorem 8.3.1 in each polygon Q of a covering of Q such that

- (a) Q is a convex open subset of Q with a polygonal boundary
- (b) <sup>Q</sup>n Q; *= o* for *i j*
- (c) ó = U f= 1 Q.

The details can be found in Sadallah (1976).

*Remark 8.3.10* Similar results for the operator D, + (— are derived in Sadallah (1983).

## 8.4 The numerical solution of elliptic problems with singularities

In this section, we take for granted that the reader is familiar with the finite element method for solving elliptic boundary problems in domains with smooth boundaries (cf. for instance Ciarlet (1978)). The analysis of the finite element method usually relies on the assumption that the solution of the given problem is regular enough. However, the implementation of this method is very often done on problems in polygonal domains which prevent the solution from being smooth everywhere.

As we saw in previous chapters, the presence of corners leads to singular behaviour of the solution only near the corners. This singular behaviour occurs even when the data of the problem are very smooth. It strongly affects the accuracy of the finite element method throughout the whole domain. We shall outline here the two main procedures which have been proposed to overcome this difficulty. The first is based on mesh refinements and has been analysed by several authors; see Babuska and Kellogg (1972), Babuska et al. (1979), Raugel (1978), Schatz and Wahlbin (1978-79), Thatcher (1975) for instance. This method may be applied to most of the practical problems since it requires only a qualitative knowledge of the behaviour of the solution near the corners (see details in Subsection 8.4.1). The second consists in augmenting the space of trial functions in which one looks for the approximate solution. This is done by adding some of the singular solutions of the problem to the usual spaces of piecewise polynomial functions (cf., for instance, Fix et al. (1976), Babuska and Kellogg (1972), Lelievre (1976b), Djaoua (1977) and Ladeveze and Peyret (1974)). This procedure requires a very accurate knowledge of the singular solutions and consequently it can be applied only to special problems (see details in Subsection 8.4.2).

Since the purpose of this section is only to illustrate the procedures mentioned above, we shall consider only the simplest model problem; namely we shall consider the Dirichlet problem for the Laplace equation in a plane polygon with only one nonconvex corner. We shall approximate its solution by means of a Galerkin method using trial functions which are piecewise first-order polynomials for simplicity.

Some slightly different approaches to the singularity problems, using integral equations, may be found in Wendland et al. (1979).

#### 8.4.1 Weighted spaces and mesh refinements

Let us again fix some notation which we keep consistent with that of Chapter 4 (see Section 4.1). Accordingly  $\Omega$  is a plane domain with a polygonal boundary  $\Gamma$ , the union of a finite number N of linear segments  $\overline{\Gamma}_i$  numbered according to the positive orientation. We denote by  $\omega_i$  the

![](_page_400_Figure_3.jpeg)

Figure 8.4

angle between  $\Gamma_j$  and  $\Gamma_{j+1}$  and we assume that  $\omega_j < \pi$  for every j but j = N. For simplicity we assume that  $S_N$ , the corner point between  $\Gamma_N$  and  $\Gamma_1$ , has been translated to the origin. In addition we assume that  $\Gamma_1$  is included in the positive abscissa axis (Ox) while  $\Gamma_N$  is supported by the half line whose angle with Ox is  $\omega_N$  (counted counterclockwise). For further simplicity we set  $\omega = \omega_N$ .

Given  $f \in L_2(\Omega)$  we look for a solution  $u \in \mathring{H}^1(\Omega)$  of

$$-\Delta u = f \qquad \text{in } \Omega. \tag{8,4,1,1}$$

We know (Chapter 4) that there exists a unique solution u and in addition there exists a unique number  $\lambda$  such that

$$u - \lambda r^{\pi/\omega} \sin \frac{\pi \theta}{\omega} \in H^2(\Omega). \tag{8,4,1,2}$$

In theory this solution u is obtained by applying the variational method of Lemma 2.2.1.1. We set

$$V = \mathring{H}^1(\Omega)$$

and

$$a(u, v) = \int_{\Omega} \nabla u \cdot \nabla v \, dx, \quad u, v \in V.$$

Then u is the unique element of V such that

$$a(u, v) = \int_{\Omega} fv \, dx$$
 (8,4,1,3)

for every  $v \in V$ .

The Galerkin method for approximating u consists in replacing the space V by a finite-dimensional subspace  $V_h$  of V in the above setting. Thus we consider  $u_h$  the unique element of  $V_h$  such that

$$a(u_h, v) = \int_{\Omega} fv \, dx$$
 (8,4,1,4)

for every  $v \in V_h$ . This new problem is equivalent to a set of n linear algebraic equations with n unknowns, n being the dimension of  $V_h$ . On the one hand one expects to solve explicitly this set of equations with the minimal amount of calculations. On the other hand one expects that  $u_h$  significantly approximates u; in other words one wants the error

$$\|u-u_h\|$$

to be small for some suitable norm. Satisfying both requirements depends strongly on the choice of  $V_h$ .

The basic tool for estimating the error is Céa's lemma (see Theorem 2.4.1 in Ciarlet (1978)):

$$\|u - u_h\|_V \le \frac{M}{\alpha} \inf_{v \in V_h} \|u - v\|_V,$$
 (8,4,1,5)

where  $\alpha$  denotes the coerciveness constant (cf. Lemma 2.2.1.1) while M is the constant such that

$$|a(u,v)| \leq M ||u||_V ||v||_V$$

for every u and v in V.

In the finite element method  $V_h$  is built with the help of a triangulation  $\mathcal{T}_h$  over  $\bar{\Omega}$ ;  $\mathcal{T}_h$  is a set of closed triangles (we assume that the triangles are not 'degenerate' i.e. their interiors are not empty) such that

(a) 
$$\bar{\Omega} = \bigcup_{K \in \mathcal{F}_h} K;$$

(b) for each distinct  $K_1, K_2 \in \mathcal{T}_h$ , one has

$$\mathring{K}_1 \cap \mathring{K}_2 = \emptyset$$

(c) any edge of any triangle  $K_1$  is either a subset of the boundary  $\Gamma$  or an edge of another triangle  $K_2$  in the triangulation.

The number h related to the triangulation  $\mathcal{T}_h$  is defined by

$$h = \max_{K \in \mathcal{T}_h} h_K,$$

where  $h_K$  is the diameter of K. This number h is supposed to vary and approach zero. While h varies we assume that the corresponding family of triangulations is regular, i.e. that there exists a constant  $\sigma$  such that

$$\frac{h_K}{\rho_K} \leq \sigma$$

for every K in  $\mathcal{T}_h$ , where  $\rho_K$  is the interior diameter of K. In other words,  $\rho_K$  is the diameter of the biggest disc included in K.

Once a family of such triangulations has been chosen the simplest choice of a related family of spaces  $V_h$  is as follows: the functions belonging to  $V_h$  are the continuous functions on  $\bar{\Omega}$  which vanish on  $\Gamma$  and whose restrictions to each  $K \in \mathcal{T}_h$  are 'linear' (i.e. affine).

In order to take advantage of Céa's lemma we need an estimate for

$$\inf_{v \in V_h} ||u - v||_V = d_V(u; V_h).$$

The classical result is that there exists a constant C such that

$$d_{V}(u; V_{h}) \leq Ch^{k} \|u\|_{k+1,2,\Omega}$$
(8,4,1,6)

provided  $u \in H^{k+1}(\Omega)$ , k = 1, 2 (see Section 3.2 in Ciarlet (1978)). Extrapolating this inequality to non-integral values of  $k, 1 \le k \le 2$ , and taking in account (8,4,1,2), one expects here the estimate

$$d_V(u;\,V_h)=O(h^{\pi/\omega-\epsilon})$$

for every  $\varepsilon > 0$ . Indeed, by Theorem 1.4.5.3, we have

$$u\in H^{1+(\pi/\omega)-\varepsilon}(\Omega)\backslash H^{1+(\pi/\omega)}(\Omega)$$

for every  $\varepsilon > 0$ , if  $\lambda$  does not vanish. Even choosing higher-order finite element spaces leads to the same limitation of the asymptotic rate of convergence of the error as  $h \to 0$ . However, as we shall show now, the above inequality (8,4,1,6) does not yield the best estimate of the asymptotic rate of convergence provided some additional assumptions are made on  $\mathcal{T}_h$ .

Indeed, the property (8,4,1,2) prevents u from belonging to  $H^2(\Omega)$  when  $\lambda$  does not vanish. Nevertheless it allows u to belong to a weighted space corresponding to the second order of differentiation. For this purpose let us set a new definition.

**Definition 8.4.1.1** For  $\alpha$  a nonnegative real number, we denote by  $H^{2,\alpha}(\Omega)$  the space of all functions  $u \in H^1(\Omega)$  such that in addition

$$r^{\alpha}D^{\beta}u \in L_2(\Omega)$$

for every  $\beta$  such that  $|\beta| = 2$ .

We observe that for  $\omega \in ]\pi, 2\pi[$  we have  $u \in H^{2,\alpha}(\Omega)$  for every  $\alpha$  such that

$$\alpha > 1 - \pi/\omega \tag{8.4.1.7}$$

Some preliminary properties of those spaces will be useful.

**Lemma 8.4.1.2** We equip  $H^{2,\alpha}(\Omega)$  with the norm

$$u \rightarrow \left\{ \|u\|_{1,2,\Omega}^2 + \sum_{|\beta|=2} \|r^{\alpha}D^{\beta}u\|_{0,2,\Omega}^2 \right\}.$$

Then the natural imbedding of  $H^{2,\alpha}(\Omega)$  into  $H^1(\Omega)$  is compact for  $\alpha < 1$ . In addition  $H^{2,\alpha}(\Omega)$  is continuously imbedded in  $C^0(\bar{\Omega})$ .

*Proof* A mere application of Hölder's inequality shows that

$$H^{2,\alpha}(\Omega) \subset W^2_{\mathfrak{p}}(\Omega)$$

for every p such that 1 . Furthermore the corresponding imbedding is continuous.

It follows that  $H^{2,\alpha}(\Omega)$  is continuously imbedded in  $C^0(\bar{\Omega})$  by Theorem 1.4.5.2, provided  $\alpha < 1$ . The compactness of the imbedding of  $H^{2,\alpha}(\Omega)$  into  $H^1(\Omega)$  is a consequence of Theorem 1.4.3.2.

**Lemma 8.4.1.3** Let  $P_1(\Omega)$  be the space of the first-order polynomials restricted to  $\Omega$ . Then there exists a constant C such that

$$\inf_{p \in P_1(\Omega)} \|u - p\|_{H^{2,\alpha}(\Omega)}^2 \le C^2 \sum_{|\beta| = 2} \|r^{\alpha} D^{\beta} u\|_{0,2,\Omega}^2$$
 (8,4,1,8)

for every  $u \in H^{2,\alpha}(\Omega)$ .

It is worth observing the similarity of this lemma with Theorem 3.1.1 in Ciarlet (1978).

Proof A first step is the proof of the following inequality

$$||v||_{H^{2,\alpha}(\Omega)}^2 \le C^2 \sum_{|\beta|=2} ||r^{\alpha} D^{\beta} v||_{0,2,\Omega}^2$$
(8,4,1,9)

for every  $v \in P_1(\Omega)^{\perp}$  the orthogonal of  $P_1(\Omega)$  in  $H^{2,\alpha}(\Omega)$ .

Indeed if (8,4,1,9) does not hold, there exists a sequence v, n = 1, 2,... of functions in *P, (Q )'* such that

$$||v_n||_{H^{2,\alpha}(\Omega)} = 1 (8,4,1,10)$$

for every n, while

$$r^{\alpha}D^{\beta}v_{n} \rightarrow 0, \qquad |\beta| = 2$$
 (8,4,1,11)

in L<sup>2</sup> (Q) as n +x.

The compactness of the imbedding of *H2 x(Q)* into *H' (Q)* (Lemma 8.4.1.2) implies that there exists a subsequence which is strongly convergent in H'(Q). Again we denote this subsequence by v, n = 1, 2, .. . and thus there exists v E *H' ffl)* such that

$$v_n \rightarrow v$$

in *H'(Q)* as n-->+oc.

Next, by the very definition of the norm in H 2-"W ), v, n = 1, 2 ) ... is a Cauchy sequence in H2.`(f ). Indeed we have

$$||v_n - v_m||_{H^{2,\alpha}(\Omega)}^2 = ||v_n - v_m||_{1,2,\Omega}^2 + \sum_{|\beta|=2} ||r^{\alpha}D^{\beta}(v_n - v_m)||_{0,2,\Omega}^2$$

and both terms on the right-hand side converge to zero as tn and in —^ +c. Accordingly we have

$$v \in H^{2,\alpha}(\Omega)$$

and

$$v \rightarrow v$$

in the norm of H*2-*` *<sup>1</sup>* (Q). It foliows that v E P <sup>1</sup> (Q) <sup>1</sup> since v,, E P<sup>1</sup> (Q) <sup>1</sup> for every ti, and furthermore (8,4,1,11) implies that

$$D^{\beta}v=0, \qquad |\beta|=2.$$

It follows that v E *P, (f2)* f1 *P, (n) <sup>1</sup> ,* i.e. v = 0. This contradicts (8,4,1,10), which implies that

$$\|v\|_{H^{2,\alpha}(\Omega)}=1$$

Now we complete the proof by observing that (8,4,1,8) follows from (8,4,1,9) by setting

$$v = u - p$$

where p is the orthogonal projection of u onto P, (Q ). n

From now on we denote by K the model triangle whose vertices are

(0, 0), (0, 1) and (1, 0). For any function u E H <sup>2</sup>'° (I), we denote by Hu the first order interpolating polynomial i.e.

$$\hat{\Pi}u \in P_1(\hat{K})$$

and

$$\hat{\Pi}u = u$$
 at  $(0,0), (0,1)$  and  $(1,0)$ .

This makes sense since u is continuous by Lemma 8.4.1.2. Then for every *PC= P, (K)* we have

$$u - \hat{\Pi}u = (1 - \hat{\Pi})(u - p).$$

Both the identity operator and fl are continuous from H 2."(K) into *H' (K).* Consequently there exists a constant C such that

$$||1 - \hat{\Pi}||_{H^{2,\alpha}(\hat{K}) \to H^1(\hat{K})} \leq \hat{C}$$

and thus we have

$$\|u - \hat{\Pi}u\|_{1,2,\hat{K}} = \|(1 - \hat{\Pi})(u - p)\|_{1,2,\hat{K}} \le \hat{C} \|u - p\|_{H^{2,\alpha}(\Omega)}.$$

Taking the infimum in p it follows from (8,4,1,8) that

$$\|u - \hat{\Pi}u\|_{1,2,\hat{K}}^2 \le \hat{C}^2 \sum_{|\beta|=2} \|r^{\alpha}D^{\beta}u\|_{0,2,\hat{K}}^2$$
 (8,4,1,12)

for every u E H<sup>2</sup> • "(K).

The above inequality is fundamental in the sequel. We shall need a similar inequality on an arbitrary triangle. For this purpose let us consider a triangle K whose vertices are a, b, c with

$$a = (a_1, a_2),$$
  $b = (a_1 + b_1, a_2 + b_2),$   $c = (a_1 + c_1, a_2 + c_2).$ 

The triangle K is the image of the model triangle K under the affine mapping

$$\Phi_K: x \to a + T_K x,$$

where the matrix of TK is

$$\begin{bmatrix} b_1 & c_1 \\ b_2 & c_2 \end{bmatrix}$$

We have already introduced above the numbers h <sup>K</sup> (diameter of K) and pK (radius of the biggest circle contained in K). We can estimate T <sup>K</sup> with the help of these numbers: obviously we have

$$||T_{\kappa}|| \le \sqrt{2} h_{\kappa}$$
 and  $||T_{\kappa}^{-1}|| \le \frac{\sqrt{2}}{\rho_{\kappa}}$ . (8,4,1,13)

For u E H2-"(K) we denote by *H<sup>K</sup> u* the first-order interpolating polyno-

mial, i.e.

$$\Pi_K u \in P_1(K)$$

and

 $\Pi_K u = u$  at the vertices of K.

We have the following estimate:

**Lemma 8.4.1.4** There exists a constant C independent of the triangle K such that

$$\|\nabla(u - \Pi_K u)\|_{0,2,K}^2 \le C \|T_K^{-1}\|^{2+2\alpha} \|T_K\|^4 \sum_{|\beta|=2} \int_K d(x,a)^{2\alpha} |D^{\beta} u(x)|^2 dx \quad (8,4,1,14)$$

for every  $u \in H^{2,\alpha}(K)$ .

**Proof** We set  $\hat{u} = u \circ \Phi_K$ . Obviously we have  $\hat{u} \in H^{2,\alpha}(\hat{K})$ , and in addition

$$(\Pi_K u) \circ \Phi_K = \hat{\Pi} \hat{u}.$$

Then we can apply inequality (8,4,1,12) to  $\hat{u}$ : this yields

$$\|\nabla(\hat{u} - \hat{\Pi}\hat{u})\|_{0,2,\hat{K}}^2 \leq \hat{C}^2 \sum_{|\beta|=2} \|r^{\alpha}D^{\beta}\hat{u}\|_{0,2,\hat{K}}^2,$$

or equivalently

$$\int_{\hat{K}} |\nabla [(u - \Pi_K u) \circ \Phi_K](\hat{x})|^2 d\hat{x} \leq \hat{C}^2 \sum_{|\beta|=2} \int_{\hat{K}} |r(\hat{x})^{\alpha} D^{\beta} [u \circ \Phi_K](\hat{x})|^2 d\hat{x}.$$

Next applying the chain rule for differentiation we get

$$\begin{split} \int_{\hat{K}} |T_K[\nabla(u - \Pi_K u)] \circ \Phi_K(\hat{x})|^2 \, \mathrm{d}\hat{x} \\ &\leq \hat{C}^2 \sum_{|\beta| = 2} \int_{\hat{K}} |r(\hat{x})^\alpha T_K^2 D^\beta u \circ \Phi_K(\hat{x})|^2 \, \mathrm{d}\hat{x}. \end{split}$$

Finally we perform the obvious change of variable, setting  $x = \Phi_K(\hat{x})$ . Thus we obtain

$$\int_{K} |\nabla (u - \Pi_{K} u)|^{2} dx \le \hat{C}^{2} ||T_{K}^{-1}||^{2} ||T_{K}||^{4} \sum_{|\beta|=2} \int_{K} |r(\Phi_{K}^{-1}(x))^{\alpha} D^{\beta} u(x)|^{2} dx.$$

The desired inequality follows since we have

$$r(\Phi_K^{-1}(x)) = d(\Phi_K^{-1}(x); \Phi_K^{-1}(a)) \le ||T_K^{-1}|| d(x, a).$$

Remark 8.4.1.5 We shall use inequality (8,4,1,14) only in two particular cases. First, when  $\alpha = 0$ , we get the inequality (already proved in Ciarlet (1978)):

$$\|\nabla(u - \Pi_K u)\|_{0,2,K}^2 \le C^2 \|T_K^{-1}\|^2 \|T_K\|^4 \sum_{|\beta|=2} \|D^\beta u\|_{0,2,K}^2. \tag{8.4,1.15}$$

Second when  $\alpha < 1$  and  $\alpha = 0$  (i.e. one of the vertices of K is the origin) one gets the weighted inequality

$$\|\nabla(u - II_{K}u)\|_{0,2,K}^{2} \le C^{2} \|T_{K}^{-1}\|^{2+2\alpha} \|T_{K}\|^{4} \sum_{|\beta|=2} \|r^{\alpha}D^{\beta}u\|_{0,2,K}^{2}.$$
 (8,4,1,16)

The next statement is an easy consequence of these preliminaries. We consider a triangulation over  $\bar{\Omega}$  as above and  $\Pi_h$ , the interpolation operator, defined as follows for every  $u \in H^{2,\alpha}(\Omega)$ :

- $II_h u|_K \in P_1(K)$  for every  $K \in \mathcal{F}_h$ .
- $II_h u = u$  at any vertex of any  $K \in \mathcal{T}_h$ .

**Theorem 8.4.1.6** We assume that the family of triangulations  $\mathcal{T}_h$  satisfies the following conditions as  $h \rightarrow 0$ ; there exists  $\sigma$  such that

- $\max_{K \in \mathcal{T}_h} h_K/\rho_K \leq \sigma$  for every h;  $h_K \leq \sigma h^{1/(1-\alpha)}$  for every  $K \in \mathcal{T}_h$  such that one of the corners of K is at
- $h_K \leq \sigma h \inf_K r^{\alpha}$  for every  $K \in \mathcal{T}_h$  with no corner at 0.

Then there exists a constant C such that

$$\|u - II_{\mathsf{h}}u\|_{1,2,\Omega} \le Ch \|u\|_{H^{2,\alpha}(\Omega)}$$
 (8,4,1,17)

for every h>0 and every  $u \in H^{2,\alpha}(\Omega)$ , provided  $\alpha < 1$ .

*Proof* We observe that for every  $k \in \mathcal{T}_h$  the restriction  $II_h u|_K$  of  $II_h u$  to K is just  $\Pi_K(u|_K)$ , where  $u|_K$  is the restriction of u to K. Thus we can apply one of the inequalities (8,4,1,15), (8,4,1,16) to  $u|_{K}$ .

If one of the vertices of K is 0 we make use of (8,4,1,16); this yields

$$\|\nabla(u - II_h u)\|_{0,2,K}^2 \le C^2 \|T_K^{-1}\|^{2+2\alpha} \|T_K\|^4 \sum_{|\beta| \approx 2} \|r^{\alpha} D^{\beta} u\|_{0,2,K}^2.$$

On the other hand if no vertex of K is 0 we make use of (8,4,1,15). Thus we get

$$\begin{split} \|\nabla (u - \Pi_h u)\|_{0,2,K}^2 & \leq C^2 \|T_K^{-1}\|^2 \|T_K\|^4 \sum_{|\beta| = 2} \|D^\beta u\|_{0,2,K}^2 \\ & \leq C^2 \|T_K^{-1}\|^2 \|T_K\|^4 \left(\inf_K r^{2\alpha}\right)^{-1} \sum_{|\beta| = 2} \|r^\alpha D^\beta u\|_{0,2,K}^2. \end{split}$$

In both cases the inequalities (8,4,1,13) and the assumptions (a)–(c) in the statement of Theorem 8.4.1.6 imply the following inequality:

$$\|\nabla(u - \Pi_h u)\|_{0,2,K}^2 \le C^2 h^2 \sum_{|\beta|=2} \|r^{\alpha} D^{\beta} u\|_{0,2,K}^2$$

with possibly another value for the constant C (yet independent of K and u). Inequality (8,4,1,17) follows by addition (over  $K \in \mathcal{T}_h$ ) and with the help of Poincaré's inequality (cf. Theorem 1.4.3.4).

**Corollary 8.4.1.7** If the triangulation  $\mathcal{T}_h$  fulfils the conditions in Theorem 8.4.1.6, then there exists a constant C which depends on neither u nor h such that

$$\|u - u_h\|_{1,2,\Omega} \le Ch \|u\|_{H^{2\alpha}(\Omega)}$$
 (8,4,1,18)

(we recall that u and  $u_h$  are defined by (8,4,1,1) and (8,4,1,4) respectively).

This follows obviously from inequality (8,4,1,17) and Céa's lemma (inequality (8,4,1,5)).

This result shows that one can expect the same asymptotic rate of convergence (as  $h \to 0$ ) of the error (in the norm of  $H^1(\Omega)$ ) as in the regular case provided the mesh is refined in a suitable way near 0. In addition it is also shown in Babuska *et al.* (1979) that this is the best asymptotic rate of convergence that one can expect for spaces  $V_h$  such that the dimension does not grow faster than  $0(h^{-2})$  as  $h \to 0$ . This can also be derived from the asymptotic estimates of diameters in El-Kolli (1971).

In practice one has to make sure that meshes refined in the above way do exist. In Raugel (1978), the following method is proposed:

First step: divide  $\Omega$  into 'big' triangles;

Second step: divide each of the big triangles which have no vertex at

zero in the usual uniform way (i.e. divide each side into n

subsegments of the same length and proceed).

Third step: divide each of the big triangles which have a vertex at zero,

according to the ratios

$$\left(\frac{i}{n}\right)^{1/(1-\alpha)}, \quad 1 \leq i \leq n$$

along the sides which end at zero. Divide the third side in the usual way (see figure) and proceed as usual.

With such a procedure the dimension of  $V_h$  is equivalent to  $n^2$  (as  $n = h^{-1}$  goes to infinity).

![](_page_409_Figure_2.jpeg)

Remark 8.4.1.8 It is important to emphasize that, once a refined mesh has been chosen, the algebra of the approximate problem (8,4,1,4) is unchanged with respect to the regular case. In other words the stiffness matrix has the same structure as in the case when all the triangles have the same order of magnitude.

Remark 8.4.1.9 We observe that all the previous analysis has been done starting from the knowledge that u belongs to some weighted space  $H^{2,\alpha}(\Omega)$ . We never used the explicit form of the singularity given by (8,4,1,2). This is the reason why such an analysis may be carried out for problems which are much more general than the model problem (8,4,1,1).

Remark 8.4.1.10 No attempt is made in the current literature about the numerical treatment of singular problems to estimate the constant C in inequality (8,4,1,18). In practice, the implementation is done with a chosen h>0 and the order of magnitude of C is as important as the asymptotic rate of convergence in h for estimating the error.

#### 8.4.2 Augmenting the space of trial functions

Another method for overcoming the polluting effect of the corners on the finite element method has been proposed. Instead of refining the mesh one keeps a regular mesh all over  $\Omega$ , i.e. we consider triangulations  $\mathcal{T}_h$  such that there exists  $\sigma_1$  and  $\sigma_2$  such that

$$\sigma_1 h \leq \rho_k \leq h_K \leq \sigma_2 h$$

for every  $K \in \mathcal{F}_h$ . However, we shall consider a bigger space  $V_h$  than before.

To be precise let us denote by  $E_h$  the space of the continuous functions u on  $\Omega$  whose restriction to each  $K \in \mathcal{T}_h$  belongs to  $P_1(K)$  and which vanish on  $\Gamma$ . We also introduce a cut-off function  $\eta$ , of r, which is identically 1 near zero and which vanishes near all the  $\Gamma_i$  except  $\Gamma_1$  and  $\Gamma_N$  (notation of Subsection 8.4.1). Then we define  $V_h$  as the direct sum of  $E_h$  and the one-dimensional space generated by the function

$$r, \theta \to \eta(r)r^{\pi/\omega} \sin \frac{\pi \theta}{\omega} = \eta(r)u_s(r, \theta).$$

In other words we set

$$V_h = E_h \oplus \mathbb{R}\{\eta u_s\}.$$

With this new space  $V_h$  we consider the approximate problem (8,4,1,4). Again we can apply Cea's lemma and we get

$$||u-u_h||_{1,2,\Omega} \le \frac{M}{\alpha} \inf_{v \in V_h} ||u-v||_{1,2,\Omega}.$$

From (8,4,1,2) we know that

$$u = w + \lambda \eta u_s$$

where  $w \in H^2(\Omega)$ . Thus we have

$$\inf_{v \in V_h} \|u - v\|_{1,2,\Omega} = \inf_{\varphi \in E_h} \|w - \varphi\|_{1,2,\Omega}$$

and from the results in Section 3.2 of Ciarlet (1978), we conclude that there exists a constant C such that

$$\inf_{\varphi \in E_h} \| w - \varphi \|_{1,2,\Omega} \le Ch \| w \|_{2,2,\Omega}.$$

Summing up we have

$$\|u - u_h\|_{1,2,\Omega} \le Ch \|w\|_{2,2,\Omega}$$
 (8,4,2,1)

with, possibly, another value for C. With such a choice of  $V_h$ , we have obtained the same asymptotic rate of convergence as in the regular case (and again here the dimension of  $V_h$  is of the order  $h^{-2}$  as in Subsection 8.4.1).

Adding the one-dimensional space generated by  $\eta u_s$  to  $E_h$ , the usual space of trial functions, disturbs the sparseness of the matrix of problem (8,4,1,4). Therefore it is advisable to choose the support of  $\eta$  small enough to be contained in those  $K \in \mathcal{T}_h$  which have one corner at 0. Accordingly an accurate study of the asymptotic error estimate might be done with a cut-off function  $\eta$  depending also on h. Some details can be found in Destuynder and Djaoua (1979) and Lelievre (1976b).

#### 8.4.3 Calculating the stress intensity factor

The coefficient  $\lambda$  of the singular part of the solution in (8,4,1,2) is often called the 'stress intensity factor'. Indeed in mechanical problems the stresses are given by the gradient of the solution u. Here we have

$$u = \lambda r^{\pi/\omega} \sin \frac{\pi \theta}{\omega} + w,$$

where  $w \in H^2(\Omega)$ . Actually it was shown in Chapter 4 that there exists  $p_0 > 2$  such that  $w \in W_p^2(\Omega)$  for every  $f \in L_p(\Omega)$  provided  $p < p_0$ .† Consequently the gradient of w is bounded and the unbounded part of  $\nabla u$  is

$$\lambda \nabla r^{\pi/\omega} \sin \frac{\pi \theta}{\omega}$$
.

In most practical problems one is mainly interested in calculating (approximately)  $\lambda$  rather than the whole solution u. When one works with the method outlined in Subsection 8.4.2, one can show an error estimate of the form

$$|\lambda - \lambda_h| \leq C \sqrt{h} ||w||_{2,2,\Omega}$$

where  $\lambda_h$  is defined by

$$u_h - \lambda_h \eta u_S \in E_h$$
.

This is proved in Djaoua (1983) in the particular case of a crack. This shows poor convergence of  $\lambda_h$  toward  $\lambda$ .

In addition it is not clear how to compute  $\lambda$  when one uses only mesh refinements as outlined in Subsection 8.4.1.

Several approaches have been proposed in Schatz and Wahlbin (1978–79), Destuynder and Djaoua (1979) and finally in Destuynder et al. (1981, 1983) for the particular case of a crack. Here we shall rely on a very simple method devised in Bellout and Moussaoui (1981). We rely on the results in Section 4.4. There we introduced (Subsection 4.4.1) the space  $N_2$  of all functions v in  $L_2(\Omega)$  which are orthogonal to the image of  $H^2(\Omega) \cap \mathring{H}^1(\Omega)$  by  $\Delta$ . We saw that every v belonging to  $N_2$  is harmonic in  $\Omega$  and vanishes on the boundary  $\Gamma$  in the weak sense. In addition we have proven (in Subsection 4.4.2) that  $N_2$  is one-dimensional and generated by one function  $\sigma$  such that

$$\sigma - r^{-\pi/\omega} \sin \frac{\pi \theta}{\omega} \in H^1(\Omega).$$

† To be precise we have

$$p_0 = \min \left\{ \left( 1 - \frac{\pi}{\omega_N} \right)^{-1}; \min_{\substack{j = 1, 2, \dots, N-1 \\ \omega_j > \pi/2}} \left( 1 - \frac{\pi}{2\omega_j} \right)^{-1} \right\}.$$

This suggests that  $\lambda$  is proportional to the scalar product

$$\int_{\Omega} f\sigma \, dx.$$

Unfortunately the function  $\sigma$  is not known explicitly because  $\Omega$  is too general a domain. Consequently we are unable to calculate the proportionality ratio above. To make this calculation feasible we replace  $\Omega$  by the simpler domain

$$D_{\rho} = \{ re^{i\theta}; 0 < r < \rho, 0 < \theta < \omega \},$$

where  $\rho$  is chosen small enough such that

$$\rho < \min_{j=2,\ldots,N-1} d(0,\bar{\Gamma}_j).$$

In addition we assume that  $\eta$  vanishes for  $r \ge \rho/2$ . We can now state the basic preliminary result of this subsection.

#### **Lemma 8.4.3.1** Assume that $u \in \mathring{H}^{1}(\Omega)$ and that

$$u - \lambda r^{\pi/\omega} \sin \frac{\pi \theta}{\omega} \in H^2(\Omega);$$

then

$$\lambda = \frac{1}{\pi} \int_{\Omega} \Delta(\eta u) r^{-\pi/\omega} \sin \frac{\pi \theta}{\omega} dx. \tag{8,4,3,1}$$

**Proof** We use the same method as in Lemma 4.4.4.10. We denote by w the difference

$$u - \lambda r^{\pi/\omega} \sin \frac{\pi \theta}{\omega} = u - \lambda u_s.$$

First we shall calculate the integral

$$I_1 = \int_{\Omega} \Delta(\eta w) r^{-\pi/\omega} \sin \frac{\pi \theta}{\omega} dx$$

by applying Theorem 1.5.3.6. For this purpose we introduce a second cut-off function  $\eta_1$  which is equal to one on the support of  $\eta$  and which vanishes for  $r \ge \rho$ . Thus we have

$$I_1 = \int_{\Omega} \Delta(\eta w) \eta_1 r^{-\pi/\omega} \sin \frac{\pi \theta}{\omega} dx.$$

It is clear that  $\eta w \in W_q^2(\Omega)$  for  $q \le 2$  and that the function

$$r, \theta \rightarrow \eta_1 r^{-\pi/\omega} \sin \frac{\pi \theta}{\omega} = \psi(r, \theta)$$

belongs to  $D(A; L_n(\Omega))$  for  $p < 2\omega/\pi$ . In addition we have

$$\eta w(S_i) = 0$$

for every j. Thus (1,5,3,6) yields

$$I_1 = \int_{\Omega} \eta w \Delta \left( \eta_1 r^{-\pi/\omega} \sin \frac{\pi \theta}{\omega} \right) dx = 0,$$

since the traces of all the involved functions are zero on the boundary and the function  $r^{-\pi/\omega} \sin \pi \theta/\omega$  is harmonic on the support of  $\eta$ .

In order to calculate

$$I_2 = \int_{\Omega} \Delta \left( \eta r^{\pi/\omega} \sin \frac{\pi \theta}{\omega} \right) r^{-\pi/\omega} \sin \frac{\pi \theta}{\omega} dx,$$

we apply the Green formula on the subdomain

$$\Omega_{\varepsilon} = \Omega \setminus \{r < \varepsilon\}$$

and we take the limit as  $\varepsilon \rightarrow 0$ . This yields

$$\begin{split} I_2 &= \lim_{\varepsilon \to 0} \int_{\Omega_{\epsilon}} \Delta \bigg( \eta r^{\pi/\omega} \sin \frac{\pi \theta}{\omega} \bigg) r^{-\pi/\omega} \sin \frac{\pi \theta}{\omega} \, \mathrm{d}x \\ &= \lim_{\varepsilon \to 0} \varepsilon \int_0^{\omega} \bigg\{ \frac{\pi}{\omega} \, \varepsilon^{\pi/\omega - 1} \sin \frac{\pi \theta}{\omega} \, \varepsilon^{-\pi/\omega} \sin \frac{\pi \theta}{\omega} \\ &+ \varepsilon^{\pi/\omega} \sin \frac{\pi \theta}{\omega} \, \omega \, \varepsilon^{-\pi/\omega - 1} \sin \frac{\pi \theta}{\omega} \bigg\} \, \mathrm{d}\theta \\ &= \frac{2\pi}{\omega} \int_0^{\omega} \bigg[ \sin \frac{\pi \theta}{\omega} \bigg]^2 \, \mathrm{d}\theta = \pi. \end{split}$$

Summing up, we have proved that

$$\int_{\Omega} \Delta(\eta u) r^{-\pi/\omega} \sin \frac{\pi \theta}{\omega} dx = I_1 + \lambda I_2 = \pi \lambda. \quad \blacksquare$$

Let us set

$$\Psi = r^{-\pi/\omega} \sin \frac{\pi \theta}{\omega}.$$

Integrating by parts we derive from identity (8,4,3,1) that

$$\lambda = \frac{1}{\pi} \int_{\Omega} \left[ \eta f + 2 \nabla \eta \cdot \nabla u + (\Delta \eta) u \right] \Psi \, dx$$

$$= \frac{1}{\pi} \int_{\Omega} \left[ \eta f \Psi + (\Delta \eta) u \Psi - 2 u \, \text{div} \left( \Psi \nabla \eta \right) \right] dx$$

$$= \frac{1}{\pi} \int_{\Omega} \eta f \Psi \, dx - \frac{1}{\pi} \int_{\Omega} \left\{ \Psi \Delta \eta + 2 \nabla \eta \cdot \nabla \Psi \right\} u \, dx \qquad (8,4,3,2)$$

due to the fact that  $\nabla \eta$  vanishes for small r and for  $r \ge \rho/2$ .

This suggests that we define an approximate value for  $\lambda$  by setting

$$\lambda_h = \frac{1}{\pi} \int_{\Omega} \eta f \Psi \, dx - \frac{1}{\pi} \int_{\Omega} \{ \Psi \Delta \eta + 2 \nabla \eta \cdot \nabla \Psi \} u_h \, dx, \qquad (8,4,3,3)$$

where  $u_h$  is the solution of (8,4,1,4). It is easy to estimate  $\lambda - \lambda_h$ .

**Theorem 8.4.3.2** Let u be the solution of the problem (8,4,1,1),  $u_h$  the solution of the approximate problem (8,4,1,4) and  $\lambda$  such that (8,4,1,2) holds. Assume  $\lambda_h$  is defined by (8,4,3,3) and that the triangulations  $\mathcal{T}_h$  are regular. Then there exists a constant C (which does not depend on h or f) such that

$$|\lambda - \lambda_h| \leq Ch \|f\|_{0,2,\Omega}.$$

Proof Clearly it follows from (8,4,3,2) and (8,4,3,3) that

$$|\lambda - \lambda_h| \le K \|u - u_h\|_{0.2.0} \tag{8.4.3.4}$$

for some constant K. Then as we have shown in Section 8.4.1 it follows from (8,4,1,6) that

$$||u-u_h||_{1,2,\Omega}=O(\sqrt{h})$$

at least. In addition one has  $u \in H^{3/2}(\Omega)$  at least (assuming  $\omega < 2\pi$ ). Therefore the Aubin-Nitsche trick (cf. Ciarlet (1978)) implies that

$$\|u - u_h\|_{0,2,\Omega} = O(h).$$
 (8,4,3,5)

The result obviously follows from (8,4,3,4) and (8,4,3,5).

Remark 8.4.3.3 Let us emphasize that no mesh refinement is needed in Theorem 8.4.3.2.