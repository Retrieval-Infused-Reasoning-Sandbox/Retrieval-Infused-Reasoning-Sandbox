Zhuangyi Liu Songmu Zheng

## Semigroups associated with dissipative systems

## Semigroups associated with dissipative systems

#### **CHAPMAN & HALL/CRC**

#### Research Notes in Mathematics Series

#### Main Editors

H. Brezis, Université de Paris

R.G. Douglas, Texas A&M University

A. Jeffrey, University of Newcastle upon Tyne (Founding Editor)

#### **Editorial Board**

H. Amann, University of Zürich

R. Aris, University of Minnesota

G.I. Barenblatt, University of Cambridge

H. Begehr, Freie Universität Berlin

P. Bullen, University of British Columbia R.J. Elliott, University of Alberta

R.J. Elliott, University of Alberta

R.P. Gilbert, University of Delaware R. Glowinski, University of Houston

D. Jerison, Massachusetts Institute of Technology

K. Kirchgässner, Universität Stuttgart

B. Lawson, State University of New York at Stony Brook

B. Moodie, University of Alberta

S. Mori, Kyoto University

L.E. Payne, Cornell University

D.B. Pearson, University of Hull

1. Raeburn, University of Newcastle

G.F. Roach, University of Strathclyde

1. Stakgold, University of Delaware

W.A. Strauss, Brown University

J. van der Hoek, University of Adelaide

#### Submission of proposals for consideration

Suggestions for publication, in the form of outlines and representative samples, are invited by the Editorial Board for assessment. Intending authors should approach one of the main editors or another member of the Editorial Board, citing the relevant AMS subject classifications. Alternatively, outlines may be sent directly to the publisher's offices. Refereeing is by members of the board and other mathematical authorities in the topic concerned, throughout the world.

#### Preparation of accepted manuscripts

On acceptance of a proposal, the publisher will supply full instructions for the preparation of manuscripts in a form suitable for direct photo-lithographic reproduction. Specially printed grid sheets can be provided. Word processor output, subject to the publisher's approval, is also acceptable.

Illustrations should be prepared by the authors, ready for direct reproduction without further improvement. The use of hand-drawn symbols should be avoided wherever possible, in order to obtain maximum clarity of the text.

The publisher will be pleased to give guidance necessary during the preparation of a typescript and will be happy to answer any queries.

#### Important note

In order to avoid later retyping, intending authors are strongly urged not to begin final preparation of a typescript before receiving the publisher's guidelines. In this way we hope to preserve the uniform appearance of the series.

#### CRC Press UK

Chapman & Hall/CRC Statistics and Mathematics Pocock House 235 Southwark Bridge Road London SE1 6LY Tel: 0171 407 7335

## Zhuangyi Liu University of Minnesota, Duluth Songmu Zheng

Fudan University, Shanghai

# Semigroups associated with dissipative systems

CHAPMAN & HALL/CRC

Boca Raton London New York Washington, D.C.

#### Library of Congress Cataloging-in-Publication Data

Catalog record is available from the Library of Congress.

This book contains information obtained from authentic and highly regarded sources. Reprinted material is quoted with permission, and sources are indicated. A wide variety of references are listed. Reasonable efforts have been made to publish reliable data and information, but the author and the publisher cannot assume responsibility for the validity of all materials or for the consequences of their use.

Apart from any fair dealing for the purposes of research or private study, or criticism or review, as permitted under the UK Copyright Designs and Patents Act, 1988, this publication may not be reproduced, stored or transmitted, in any form or by any means, electronic or mechanical, including photocopying, microfilming, and recording, or by any information storage or retrieval system, without the prior permission in writing of the publishers, or in the case of reprographic reproduction only in accordance with the terms of the licenses issued by the Copyright Licensing Agency in the UK, or in accordance with the terms of the license issued by the appropriate Reproduction Rights Organization outside the UK.

The consent of CRC Press LLC does not extend to copying for general distribution, for promotion, for creating new works, or for resale. Specific permission must be obtained in writing from CRC Press LLC for such copying.

Direct all inquiries to CRC Press LLC, 2000 Corporate Blvd., N.W., Boca Raton, Florida 33431.

Trademark Notice: Product or corporate names may be trademarks or registered trademarks, and are used only for identification and explanation, without intent to infringe.

#### © 1999 by CRC Press LLC

No claim to original U.S. Government works

International Standard Book Number 0-8493-0615-9

Printed in the United States of America 1 2 3 4 5 6 7 8 9 0

Printed on acid-free paper

## Contents

| Preface |                                                                                |
|---------|--------------------------------------------------------------------------------|
| Chapter | 1 Preliminaries                                                                |
| 1.1     | Some Definitions                                                               |
| 1.2     | C <sub>0</sub> -semigroup Generated by Dissipative Operator                    |
| 1.3     | Exponential Stability and Analyticity                                          |
| 1.4     | The Sobolev Spaces and Elliptic Boundary Value Problems                        |
|         | 1.4.1 Sobolev Spaces $W^{m,p}(\Omega)$                                         |
|         | 1.4.2 The Gagliardo-Nirenberg and Poincaé Inequalities                         |
|         | 1.4.3 Abstract Functions Valued in Banach Spaces                               |
|         | 1.4.4 Linear Elliptic Boundary Value Problems                                  |
|         | <b>1.4.5</b> Interpolation Spaces                                              |
| 1.5     | Notation                                                                       |
| Chapter | 2 Linear Thermoelastic Systems                                                 |
| 2.1     | The Setting of Problems for the One-Dimensional Thermoelastic System           |
| 2.2     | The Exponential Stability for the Dirichlet Boundary Conditions at Both Ends   |
| 2.3     | The Exponential Stability for the Stress-Free Boundary Conditions at Both Ends |
| 2.4     | The Exponential Stability for the Stress-Free Boundary Conditions at One End   |

| 2.5 The Thermoelastic Kirchhoff Plate Equations                              |
|------------------------------------------------------------------------------|
| Chapter 3 Linear Viscoelastic Systems                                        |
| <b>3.1</b> Linear Viscoelastic System                                        |
| 3.2 Wave Equation with Locally Distributed Damping                           |
| 3.3 Linear Viscoelastic System with Memory                                   |
| 3.4 The Linear Viscoelastic Kirchhoff Plate with Memory                      |
| Chapter 4 Linear Thermoviscoelastic Systems                                  |
| 4.1 Linear One-Dimensional Thermoviscoelastic System                         |
| <b>4.2</b> Linear Three-Dimensional Thermoviscoelastic System with Memory 96 |
| Chapter 5 Elastic Systems with Shear Damping                                 |
| <b>5.1</b> Shear Diffusion Equations                                         |
| <b>5.2</b> Laminated Beam with Shear Damping                                 |
| Chapter 6 Linear Elastic Systems with Boundary Damping                       |
| <b>6.1</b> Second-Order Hyperbolic Equation                                  |
| <b>6.2</b> Euler-Bernoulli Beam Equation                                     |
| Chapter 7 Uniformly Stable Approximations                                    |
| <b>7.1</b> Main Theorem                                                      |
| 7.2 Approximations of the Thermoelastic System                               |
| 7.3 Approximation of the Viscoelastic System                                 |
| Bibliography                                                                 |
| Index                                                                        |

#### **Preface**

This book is concerned with exponential stability and analyticity of  $C_0$ -semigroups associated with various dissipative systems arising from mechanics. Most of the material in this book is based on research carried out by the authors and their collaborators in recent years. It also includes some very recent work by the authors.

One of important motivations of studying exponential stability comes from the control theory. There are various kinds of damping in a mechanical system, such as heat conduction, viscosity, friction, etc. It turns out that the corresponding mechanical system is dissipative. Certainly, there are many good reasons in practice to consider the corresponding control problem. For instance, controlling the vibration of an antenna of a satellite moving in outer space is a good example in that respect. There is heat condution, due to sunlight, in the antenna and the problem can be reduced to a control problem for a linear one-dimensional thermoelastic system for a rod of length l. If the exponential stability of the  $C_0$ -semigroup associated with a dissipative mechanical system (e.g., the linear one-dimensional thermoelastic system subject to appropriate boundary and initial conditions) can be shown, then by the standard approach in the control theory, it implies that the corresponding system with control is stabilizable. It turns out that the optimal control of a so-called linear quadratic regulator problem has a feedback form which can be achieved by solving an operator algebraic Riccati equation. (We refer to Gibson [1] and Gibson, Rao & Tao [1], or Chapter 7 of this book for more details.)

The study of exponential stability and analyticity is also very important in the theory of partial differential equations. The property of exponential stability, or, in other words, exponential decay of a solution to a linear system of partial differential equations will yield, through a quite standard approach, the global existence and uniqueness of the corresponding *nonlinear* system of partial differential equations with

small initial data. (We refer to Zheng [1] and the references cited there in this aspect.) On the other hand, a dissipative mechanical system can often be described by a coupled system of partial differential equations, part of which is a parabolic equation or parabolic system. It is well-known that solutions to initial boundary value problems with a bounded domain, for instance for the heat equation or a large class of linear parabolic equations, decay exponentially to zero (equilibrium) and are analytic for t>0. Clearly, it is desirable to know whether or not these two properties will still preserve for a given dissipative mechanical system. Knowledge of that will certainly deepen understanding about interaction between "parabolic equations" and "hyperbolic equations". The reader of this book will find that the exponential stability is still preserved for all mechanical systems considered in this book. However, it is also pointed out in this book that this property is no longer true for linear three-dimensional thermoelastic systems unless some assumptions on domain and initial data are made. On the other hand, the reader will find that analyticity is a more sensitive property and it is not preserved even for some systems considered in this book.

Concerning the method for proving exponential stability and analyticity, what is presented in this book is a systematic approach developed by the authors and their collaborators in past years. The spirit of this method for proving exponential stability is to combine a theorem (see Theorem 1.3.2 in this book) by Gearhart [1] (see also Wyler [1]) and Huang [1] in the semigroup theory with PDE techniques. Combination of an analogous theorem (see Theorem 1.3.3 in this book) with PDE techniques is the systematic approach presented in this book for proving analyticity. Certainly, these approaches are very different from some other methods in the literature, such as the traditional energy method, the method based on the Datko theorem, and the method of directly estimating the spectrum. It is our hope that the reader will find that the methods presented in this book are powerful and simple. We would like to emphasize that the references cited in this book are not intended to be exhaustive.

In what follows, we briefly describe the main content of this book:

In order that this book be self-contained, in Chapter 1 (mainly a reference chapter), we collect and present some concepts and results in semigroup theory, some results about Sobolev spaces, linear elliptic boundary value problems, and interpolation spaces. In particular, Theorem 1.3.2, Theorem 1.3.3, and Theorem 1.2.4 will be frequently used throughout this book.

In Chapter 2, we are concerned with linear thermoelastic systems, namely, the linear one-dimensional thermoelastic system and the linear thermoelastic Kirchhoff plate equations. Results on the exponential stability of  $C_0$ -semigroups associated with initial boundary value problems with various boundary conditions for linear one-dimensional thermoelastic system are presented. It is pointed out that analyticity is not valid for these semigroups. In the final section of this chapter we consider the initial boundary value problems for the linear thermoelastic Kirchhoff plate equations. Results on exponential stability and analyticity or non-analyticity are also presented.

Chapter 3 is devoted to the study of linear viscoelastic systems. In the first section of this chapter, it is proved that the semigroup associated with the initial boundary value problem for the linear one-dimensional elastic system with viscous damping of rate type is not only exponentially stable, but is also analytic. In the same section, an extended model is considered and results on exponential stability and analyticity are also presented. In the second section, the initial boundary value problem for wave equation with locally distributed damping is considered. We give a new proof for the exponential stability of the associated semigroup using the systematic approach presented in this book. In the third section, a linear viscoelastic system with memory is investigated in an abstract framework. The exponential stability of the corresponding semigroup is established. It is also pointed out that analyticity is not valid for such kind of systems. As an application of the general results in the third section, the final section of this chapter is devoted to the linear viscoelastic Kirchhoff plate equation with memory.

Chapter 4 is concerned with linear thermoviscoelastic systems. In other words,

both heat conduction and viscosity coexist in a mechanical system. In the first section, the linear one-dimensional thermoviscoelastic system is investigated. It is proved that if both heat conduction and viscosity are of rate type, then the corresponding semigroup is not only exponentially stable, but is also analytic. We further consider the linear three-dimensional thermoviscoelastic system with memory, a model proposed by Navarro [1]–[2]. In contrast to the linear three-dimensional thermoelastic system, the exponential stability can still be established for this thermoviscoelastic system.

Chapter 5 is devoted to the study of elastic systems with shear damping, a notion first proposed by D. Russell. Section 5.1 is concerned with the shear diffusion equations proposed by D. Russell. The exponential stability and analyticity of the corresponding semigroup is proved by our systematic method. Then, in Section 5.2, we further consider a model describing laminated beam with shear damping. Again the exponential stability and analyticity is established.

In Chapter 6, we consider a different kind of damping, i.e., boundary damping due to friction. In the first section of this chapter, we consider a linear second order hyperbolic equation in a bounded domain in  $\mathbb{R}^m$  with boundary damping. The exponential stability result was first established by Wyler [1]. But we now use our systematic method to reprove it. Section 6.2 is devoted to the study of the Euler-Bernoulli beam equation with boundary damping, which can be considered as a feedback control on the boundary. The exponential stability is established.

In Chapter 7, the final chapter of this book, we are concerned mainly with uniformly stable approximations. In the first section of this chapter, we establish a general theorem on the uniformly exponential stability for a sequence of  $C_0$ -semigroups of contractions on a sequence of Hilbert spaces. Then, in the next two sections as applications of this general result, some numerical approximations for the linear thermoelastic system and viscoelastic system are considered. It is proved that for these particular numerical schemes, the corresponding semigroups are uniformly exponentially stable.

We would like to take this opprotunity to express our special thanks to Professor H. Amann for his interest in our research and for acting as the initiator for publication of this book.

The author Z. Liu would like to record his appreciation of his other collobarators, including Kangsheng Liu, R. Miller, M. Renardy, S. Trogdon, and Jiongmin Yong for their fruitful cooperation and stimulating discussions. He also thanks his Ph.D. thesis advisor, Professor J. A. Burns, at Virginia Polytechnic Institute and State University, and Professor H. Stech, Head of the Department of Mathematics and Statistics at The University of Minnesota at Duluth, for their constant support and encouragement.

The author S. Zheng would like to acknowledge the NSF of China and the Ministry of Education of China for their continuous support. Currently, he is being supported by the grant No. 19331040 from the NSF of China and the grant No. 96024603 from the Ministry of Education of China.

Duluth and Shanghai

Professor Z. Liu

Department of Mathematics and Statistics
University of Minnesota at Duluth
Duluth, MN 55812

USA

Email: zliu@d.umn.edu

Professor Songmu Zheng Institute of Mathematics Fudan University Shanghai 200433

P. R. China

Email: szheng@srcap.stc.sh.cn

## This page intentionally left blank

## Chapter 1 Preliminaries

In this chapter we will present some definitions, some results on  $C_0$ -semigroups, including some theorems on exponential stability and analyticity. We will also collect some results on Sobolev's spaces and elliptic boundary value problems for the sake of the reader. Some theorems are proved and others are stated without proofs, but the relevant references are given. The reader may skip this chapter in the first reading, then return to it for the references of related results.

#### 1.1 Some Definitions

**Definition 1.1.1** Let H be a real or complex Hilbert space equipped with the inner product  $(\ ,\ )$  and the induced norm  $\|\cdot\|$ . Let A be a densely defined linear operator on H, i.e, A:  $D(A) \subseteq H \mapsto H$ . We say that A is dissipative if for any  $x \in D(A)$ ,

$$Re\left(Ax,x\right) \le 0. \tag{1.1.1}$$

**Definition 1.1.2** A family S(t)  $(0 \le t < \infty)$  of bounded linear operators in a Banach space H is called a strongly continuous semigroup (in short, a  $C_0$ -semigroup) if

(i) 
$$S(t_1 + t_2) = S(t_1)S(t_2), \forall t_1, t_2 \geq 0,$$

- (ii) S(0) = I,
- (iii) For each  $x \in H$ , S(t)x is continuous in t on  $[0, \infty)$ .

For such a semigroup S(t), we define an operator A with domain D(A) consisting of points x such that the limit

$$Ax = \lim_{h \to 0} \frac{S(h)x - x}{h}, \quad x \in D(A)$$
 (1.1.2)

exists. Then A is called the infinitesimal generator of the semigroup S(t). Given an operator A, if A coincides with the infinitesimal generator of S(t), then we say that it generates a strongly continuous semigroup S(t),  $t \geq 0$ . Sometimes we also denote S(t) by  $e^{At}$ .

**Definition 1.1.3**  $e^{At}$  is said to be exponentially stable if there exist positive constants  $\alpha$  and  $M \geq 1$  such that

$$||e^{At}|| \le Me^{-\alpha t}, \ \forall \ t \ge 0.$$
 (1.1.3)

Hereafter, we also use the notation  $\|\cdot\|$  to denote the norm in  $\mathcal{L}(H,H)$ , assuming that no confusion will occur.

**Definition 1.1.4**  $e^{At}$  is said to be analytic if  $e^{At}$  admits an extension  $T(\lambda)$  for  $\lambda \in \Delta_{\theta} = \{\lambda \in \mathcal{C} \mid |arg\lambda| < \theta\}$  for some  $\theta > 0$  such that  $\lambda \mapsto T(\lambda)$  is analytic and

$$\begin{cases} \lim_{\Delta_{\theta} \ni \lambda \to 0} ||T(\lambda)z - z|| = 0, & \forall z \in H, \\ T(\lambda + \mu) = T(\lambda)T(\mu), & \forall \lambda, \ \mu \in \Delta_{\theta}, \end{cases}$$
(1.1.4)

or equivalently (see Theorem 5.2 in the book Pazy [1], p.61-62) there exists a constant K>0 such that

$$||Ae^{At}|| \le Kt^{-1}, \ \forall \ t > 0.$$
 (1.1.5)

Let  $\rho(A)$  and  $\sigma(A)$  be the resolvent set and the spectrum of A, respectively. We denote

$$\sigma_0(A) \stackrel{\triangle}{=} \sup \{ Re \, \lambda \, | \, \lambda \in \sigma(A) \} \tag{1.1.6}$$

and

$$\omega_0(A) \stackrel{\triangle}{=} \lim_{t \to 0} \frac{\ln \|e^{At}\|}{t}.$$
 (1.1.7)

We say that the  $C_0$ -semigroup  $e^{At}$  has the spectrum determining growth property if  $\sigma_0(A) = \omega_0(A)$ .

This book is concerned mainly with exponential stability and analyticity of  $C_0$ semigroups of contractions in a Hilbert space generated by dissipative operators arising
from mechanics. In the following two sections we will collect some related results
concerning generation, exponential stability, and analyticity of  $C_0$ -semigroups.

## 1.2 $C_0$ -semigroup Generated by Dissipative Operator

Suppose that the linear operator A generates a  $C_0$ -semigroup  $e^{At}$  on a Hilbert space H. Then we have (see Pazy [1]):

Theorem 1.2.1 (Hille-Yosida) A linear (unbounded) operator A is the infinitesimal generator of a  $C_0$ -semigroup of contractions S(t),  $t \ge 0$ , if and only if

- (i) A is closed and  $\overline{D(A)} = H$ ,
- (ii) the resolvent set  $\rho(A)$  of A contains  $\mathbb{R}^+$  and for every  $\lambda > 0$ ,

$$\|(\lambda I - A)^{-1}\| \le \frac{1}{\lambda}.$$
 (1.2.1)

For the sake of the reader, in this section we collect the well-known Lumer-Phillips Theorem and its corollary concerning generation of the  $C_0$ -semigroup generated by a dissipative operator (see Yosida [1] and Pazy [1]). All these results are valid in Banach spaces. However, since this book only uses its version in Hilbert spaces, we restate these two theorems as follows.

**Theorem 1.2.2** Let A be a densely defined linear operator on a Hilbert space H. Then A generates a  $C_0$ -semigroup of contractions on H if and only if A is dissipative and R(I-A) = H.

The following Lumer-Phillips theorem tells us that the condition R(I-A)=H can be weakened to  $R(\lambda_0 I-A)=H$  for any given  $\lambda_0>0$ .

**Theorem 1.2.3 (Lumer-Phillips)** Let A be a linear operator with dense domain  $\mathcal{D}(A)$  in a Hilbert space H. If A is dissipative and there is a  $\lambda_0 > 0$  such that the range,  $R(\lambda_0 I - A)$ , of  $\lambda_0 I - A$  is H, then A is the infinitesimal generator of a  $C_0$ -semigroup of contractions on H.

As a collorary of the above theorem, the following result will be frequently used in this book:

**Theorem 1.2.4** Let A be a linear operator with dense domain  $\mathcal{D}(A)$  in a Hilbert space H. If A is dissipative and  $0 \in \rho(A)$ , the resolvent set of A, then A is the infinitesimal generator of a  $C_0$ -semigroup of contractions on H.

**Proof** By the assumption  $0 \in \rho(A)$ , A is invertible and  $A^{-1}$  is a bounded linear operator. By the contraction mapping theorem, it is easy to see that the operator  $\lambda I - A = A(\lambda A^{-1} - I)$  is invertible for  $0 < \lambda < \|A^{-1}\|$ . Therefore, it follows from the above Lumer-Phillips Theorem that A is the infinitesimal generator of a  $C_0$ -semigroup

#### 1.3 Exponential Stability and Analyticity

In this section we collect some results in the literature concerning the necessary and sufficient conditions for a  $C_0$ -semigroup being exponentially stable or analytic. The first result we are going to state is about the necessary and sufficient conditions of exponential stability of a  $C_0$ -semigroup on a Hilbert space. The result was obtained by Gearhart [1] and Huang [1], independently (see also Prüss [1]). The following statement is due to Huang [1].

**Theorem 1.3.1** Let  $S(t) = e^{At}$  be a  $C_0$ -semigroup on a Hilbert space. Then S(t) is exponentially stable if and only if

$$\sup\{Re\,\lambda;\ \lambda\in\sigma(A)\}<0\tag{1.3.1}$$

and

$$\sup_{Re \,\lambda > 0} \|(\lambda I - A)^{-1}\| < \infty \tag{1.3.2}$$

hold.

The following invariant of the result is due to Gearhart [1] (see Wyler [1]).

**Theorem 1.3.2** Let  $S(t) = e^{At}$  be a  $C_0$ -semigroup of contractions on a Hilbert space. Then S(t) is exponentially stable if and only if

$$\rho(A) \supseteq \{i\beta, \beta \in \mathbb{R}\} \equiv i\mathbb{R}$$
 (1.3.3)

and

$$\overline{\lim_{|\beta| \to \infty}} \| (i\beta I - A)^{-1} \| < \infty \tag{1.3.4}$$

hold.

In the following we give the proof of equivalence of these two results under the condition that  $S(t) = e^{At}$  is a  $C_0$ - semigroup of contractions on a Hilbert space.

It is obvious that (1.3.1)–(1.3.2) imply (1.3.3) and (1.3.4). We now prove that (1.3.3)–(1.3.4) imply (1.3.1) and (1.3.2) under the condition that  $||e^{At}|| \le 1$ . We first 4

notice that by Colollary 3.6 in Pazy [1], the resolvent set  $\rho(A)$  of A contains the open right half-plane, i.e.,  $\rho(A) \supseteq \{\lambda : Re \lambda > 0\}$ , and for such  $\lambda$ ,  $\|(\lambda I - A)^{-1}\| \le \frac{1}{Re \lambda}$ . This implies that for any given  $\delta_0 < 0$ , when  $Re\lambda > |\delta_0|$ , we have

$$\|(\lambda I - A)^{-1}\| \le \frac{1}{|\delta_0|}.$$
 (1.3.5)

Second, we prove that there exists  $\sigma_0 < 0$  with  $|\sigma_0|$  being sufficiently small such that  $\sigma(A) \subseteq \{\lambda, Re\lambda \le \sigma_0\}$ . Indeed, consider for  $\lambda = \mu + i\nu$ ,

$$\lambda I - A = \mu I + i\nu I - A = (\mu(i\nu I - A)^{-1} + I)(i\nu I - A).$$
 (1.3.6)

Then it follows from (1.3.4) that when  $|\mu|$  is sufficiently small, by the contraction mapping theorem,  $\mu(i\nu I - A)^{-1} + I$  is invertible. Thus, (1.3.4) implies that  $\sigma(A) \subseteq \{\lambda; Re \lambda \leq \sigma_0 < 0\}$  with  $|\sigma_0|$  small enough. Therefore,  $\sigma_0(A) \leq \sigma_0 < 0$  and for  $Re \lambda \leq |\delta_0|$ ,  $||(\lambda I - A)^{-1}|| \leq 2M$ . Combining this with (1.3.5) yields (1.3.2).

Concerning analyticity of a  $C_0$ -semigroup of contractions on a Hilbert space, we have the following result:

**Theorem 1.3.3** Let  $S(t) = e^{At}$  be a  $C_0$ -semigroup of contractions in a Hilbert space. Suppose that

$$\rho(A) \supseteq \{i\beta | \beta \in \mathbb{R}\} \equiv i\mathbb{R}. \tag{1.3.7}$$

Then, S(t) is analytic if and only if

$$\overline{\lim_{|\beta| \to \infty}} \|\beta (i\beta I - A)^{-1}\| < \infty \tag{1.3.8}$$

holds.

**Proof** The statement of Theorem 1.3.3 was first given in the old version of the paper, Liu & Yong [1], but no proof was given there. We also refer to Liu & Yong [1] for the statement of a strong version of this theorem. But no proof was given there either. The proof of the "only if" part of the present theorem is easy and it is actually a direct consequence of Theorem 5.2 of Pazy [1] (see (5.4) and (5.5) on p. 61 in that book).

The proof of the "if" part consists of the following steps:

(i) Since (1.3.8) holds, there is a positive constant M such that for any given  $\beta \in \mathbb{R}$ ,

$$\|\beta(i\beta I - A)^{-1}\| \le M.$$
 (1.3.9)

We now claim that the set  $\{\lambda \mid -\frac{|Im\lambda|}{2M} \leq Re \ \lambda \leq 0\}$  is also contained in  $\rho(A)$ . Indeed, for  $\lambda = \alpha + i\beta$  with  $-\frac{|\beta|}{2M} \leq \alpha \leq 0$ , we have  $(\alpha + i\beta)I - A = (i\beta I - A) + \alpha I = (i\beta I - A)(I + \alpha(i\beta I - A)^{-1})$ . By (1.3.9) and the contraction mapping theorem,  $I + \alpha(i\beta I - A)^{-1}$  is invertible. Thus,  $(\alpha + i\beta)I - A$  is invertible and

$$\|((\alpha + i\beta)I - A)^{-1}\| \le \frac{2M}{|\beta|} \le \frac{C}{|\lambda|}$$

$$(1.3.10)$$

with  $C = \sqrt{(4M^2 + 1)}$ .

(ii) By Corollary 7.5 in Pazy [1] (p. 29), for any  $\gamma > 0$  and  $x \in D(A^2)$ , we have

$$S(t)x = \frac{1}{2\pi i} \int_{\gamma - i\infty}^{\gamma + i\infty} e^{\lambda t} (\lambda I - A)^{-1} x d\lambda, \qquad (1.3.11)$$

and for every  $\eta > 0$ , the integral converges uniformly in t for  $t \in [\eta, \frac{1}{\eta}]$ .

For any  $y \in H$ , we have

$$(S(t)x,y) = \frac{1}{2\pi i} \lim_{\beta \to +\infty} \int_{\gamma - i\beta}^{\gamma + i\beta} (e^{\lambda t} (\lambda I - A)^{-1} x, y) d\lambda.$$
 (1.3.12)

Let  $\theta_1$  and  $\theta_2$  be two angles such that  $\tan(\theta_i) = -\frac{1}{2M}$  with  $\frac{\pi}{2} < \theta_1 < \pi$ ,  $\pi < \theta_2 < \frac{3\pi}{2}$ . Consider the closed curve in the complex plane in  $\lambda$ :  $\Gamma = \Gamma_0 \cup \Gamma_1 \cup \Gamma_2 \cup \Gamma_3 \cup \Gamma_4$  with  $\Gamma_0 = \{\lambda \mid Re \lambda = \gamma, -\beta \leq Im \lambda \leq \beta\}$ ,  $\Gamma_1 = \{\lambda \mid Im \lambda = \beta, -\frac{\beta}{2M} \leq Re \lambda \leq \gamma\}$ ,  $\Gamma_2 = \{\lambda \mid \lambda = \rho e^{i\theta_1}, 0 \leq \rho \leq \frac{C\beta}{2M}\}$ ,  $\Gamma_3 = \{\lambda \mid \lambda = \rho e^{i\theta_2}, 0 \leq \rho \leq \frac{C\beta}{2M}\}$ ,  $\Gamma_4 = \{\lambda \mid Im \lambda = -\beta, -\frac{\beta}{2M} \leq Re \lambda \leq \gamma\}$ . Since  $(e^{\lambda t}(\lambda I - A)^{-1}x, y)$  is analytic in  $\lambda \in \{\lambda \mid Re \lambda \geq 0\} \cup \{\lambda \mid -\frac{|Im \lambda|}{2M} \leq Re \lambda \leq 0\} \subset \rho(A)$ , by the Cauchy theorem in the theory of analytic functions, we have

$$\begin{split} &\int_{\gamma-\boldsymbol{i}\beta}^{\gamma+\boldsymbol{i}\beta}(e^{\lambda t}(\lambda I-A)^{-1}x,y)d\lambda = \int_{\frac{-|\beta|}{2M}}^{\gamma}(e^{(\delta+\boldsymbol{i}\beta)t}((\delta+\boldsymbol{i}\beta)I-A)^{-1}x,y)d\delta \\ &+\int_{\frac{|\beta|}{2M}}^{\gamma}(e^{(\delta-\boldsymbol{i}\beta)t}((\delta-\boldsymbol{i}\beta)I-A)^{-1}x,y)d\delta + e^{\boldsymbol{i}\theta_1}\int_{0}^{\frac{C|\beta|}{2M}}(e^{\rho te^{\boldsymbol{i}\theta_1}}(\rho e^{\boldsymbol{i}\theta_1}I-A)^{-1}x,y)d\rho \\ &+e^{\boldsymbol{i}\theta_2}\int_{0}^{\frac{C|\beta|}{2M}}(e^{\rho te^{\boldsymbol{i}\theta_2}}(\rho e^{\boldsymbol{i}\theta_2}I-A)^{-1}x,y)d\rho \\ &=I_1^{\beta}+I_2^{\beta}+I_3^{\beta}+I_4^{\beta}. \end{split} \tag{1.3.13}$$

Since S(t) is a  $C_0$ -semigroup of contractions, by Corollary 3.6 in Pazy [1], for  $\lambda$  with  $Re \lambda > 0$ , we have

$$\|(\lambda I - A)^{-1}\| \le \frac{1}{|\lambda|}.$$
 (1.3.14)

Combining (1.3.10) with (1.3.14) yields that for t > 0,

$$|I_1^{\beta}| \le \frac{C}{\beta} \int_{-\frac{\beta}{2M}}^{\gamma} e^{\delta t} d\delta ||x|| ||y|| \to 0, \quad \text{as} \quad \beta \to +\infty.$$
 (1.3.15)

The same argument also yields that  $|I_2^{\beta}| \to 0$ , as  $\beta \to +\infty$ .

By (1.3.10), we have

$$|I_3^{\beta}| \le C \int_0^{\frac{C\beta}{2M}} \frac{1}{\rho} e^{\rho t \cos \theta_1} d\rho ||x|| ||y||.$$
 (1.3.16)

It follows from (1.3.16) that as  $\beta \to +\infty$ ,  $I_3^{\beta}$  converges to

$$I_{3} = e^{i\theta_{1}} \int_{0}^{+\infty} (e^{\rho t e^{i\theta_{1}}} (\rho e^{i\theta_{1}} I - A)^{-1} x, y) d\rho. \tag{1.3.17}$$

The same argument also yields that  $I_4^\beta$  converges to

$$I_{4} = e^{i\theta_{2}} \int_{0}^{+\infty} (e^{\rho t e^{i\theta_{2}}} (\rho e^{i\theta_{2}} I - A)^{-1} x, y) d\rho.$$
 (1.3.18)

These integrals converge uniformly for  $t \in [\eta, \frac{1}{n}]$ . Thus we have

$$(S(t)x, y) = I_3 + I_4, \quad \forall t > 0.$$
 (1.3.19)

It is easy to see that  $I_3$  and  $I_4$  are differentiable with respect to t for t > 0. Then we have

$$(S'(t)x,y) = e^{2\theta_1 \mathbf{i}} \int_0^{+\infty} \rho(e^{\rho t e^{\mathbf{i}\theta_1}} (\rho e^{\mathbf{i}\theta_1} I - A)^{-1} x, y) d\rho$$
$$+ e^{2\theta_2 \mathbf{i}} \int_0^{+\infty} \rho(e^{\rho t e^{\mathbf{i}\theta_2}} (\rho e^{\mathbf{i}\theta_2} I - A)^{-1} x, y) d\rho. \tag{1.3.20}$$

Therefore,

$$|(S'(t)x,y)| \le C \left( \int_0^{+\infty} e^{\rho t \cos \theta_1} d\rho + \int_0^{+\infty} e^{\rho t \cos \theta_2} d\rho \right) ||x|| ||y|| = \frac{C_1}{t} ||x|| ||y|| \quad (1.3.21)$$

with

$$C_1 = -\frac{C}{\cos(\theta_1)} - \frac{C}{\cos(\theta_2)}. (1.3.22)$$

Since y is an arbitrary element and  $D(A^2)$  is dense in H, it follows from (1.3.21) and the dense argument that

$$||S'(t)|| = ||AS(t)|| \le \frac{C_1}{t}, \quad t > 0.$$
 (1.3.23)

Thus, from Theorem 5.2 in Pazy [1], it follows that S(t) is analytic.

#### 1.4 The Sobolev Spaces and Elliptic Boundary Value Problems

In this section we collect some basic results on function spaces and the elliptic partial differential equations which will be needed in the remainder of the book. Most results are just recalled without proofs, but the relevant references are given.

#### 1.4.1 Sobolev Spaces $W^{m,p}(\Omega)$

Let  $\Omega$  be a bounded or an unbounded domain of  $\mathbb{R}^n$  with smooth boundary  $\Gamma$ . For  $m \in \mathbb{N}$ ,  $1 \leq p \leq \infty$ ,  $W^{m,p}(\Omega)$  is defined to be the space of functions u in  $L^p(\Omega)$  whose distribution derivatives of order up to m are also in  $L^p(\Omega)$ . Then, it is known (see e.g., Adams [1] and Lions & Magenes [1]) that  $W^{m,p}(\Omega)$  is a Banach space with the norm

$$||u||_{W^{m,p}(\Omega)} = \left(\sum_{|\alpha| \le m} ||D^{\alpha}u||_{L^{p}(\Omega)}^{p}\right)^{\frac{1}{p}}$$
(1.4.1)

where  $\alpha = \{\alpha_1, \dots, \alpha_n\} \in \mathbb{N}^n$ ,  $|\alpha| = \alpha_1 + \dots + \alpha_n$ ,  $D^{\alpha}u = \frac{\partial^{\alpha_1 + \dots + \alpha_n}u}{\partial x_1^{\alpha_1} \dots \partial x_n^{\alpha_n}}$ . When p = 2, we usually denote  $W^{m,p}(\Omega)$  by  $H^m(\Omega)$  and this is a Hilbert space with the corresponding inner product.

Let  $C^k(\Omega)$   $(k \in \mathbb{N})$  or  $k = \infty$  be the space of k times continuously differentiable functions on  $\Omega$ . Let  $C_0^k(\Omega)$  be the space of  $C^k$  functions on  $\Omega$  with compact support in  $\Omega$ . The closure of  $C_0^{\infty}(\Omega)$  in  $W^{m,p}(\Omega)$  is denoted by  $W_0^{m,p}(\Omega)$  which is a subspace of  $W^{m,p}(\Omega)$ .

We now recall some important properties of the Sobolev spaces  $W^{m,p}(\Omega)$  (see, e.g., Adams [1]).

Theorem 1.4.1 (Density Theorem) If  $\Omega$  is a  $C^m$  domain,  $m \geq 1, 1 \leq p < \infty$ , then  $C^m(\bar{\Omega})$  is dense in  $W^{m,p}(\Omega)$ .

Theorem 1.4.2 (Imbedding and Compactness Theorem) Assume that  $\Omega$  is a bounded domain of class  $C^m$ . Then we have

(i) If mp < n, then  $W^{m,p}(\Omega)$  is continuously imbedded in  $L^{q^{\bullet}}(\Omega)$  with  $\frac{1}{q^{*}} = \frac{1}{p} - \frac{m}{n}$ :

$$W^{m,p}(\Omega) \hookrightarrow L^{q^{\bullet}}(\Omega).$$
 (1.4.2)

Moreover, the imbedding operator is compact for any  $q, 1 \leq q < q^*$ .

(ii) If mp = n, then  $W^{m,p}(\Omega)$  is continuously imbedded in  $L^q$ ,  $\forall q, 1 \leq q < \infty$ :

$$W^{m,p}(\Omega) \hookrightarrow L^q(\Omega).$$
 (1.4.3)

Moreover, the imbedding operator is compact,  $\forall q, 1 \leq q < \infty$ . If p = 1, m = n, then the above still holds for  $q = \infty$ .

(iii) If  $k+1 > m - \frac{n}{p} > k$ ,  $k \in \mathbb{N}$ , then writing  $m - \frac{n}{p} = k + \alpha$ ,  $k \in \mathbb{N}$ ,  $0 < \alpha < 1$ ,  $W^{m,p}(\Omega)$  is continuously imbedded in  $C^{k,\alpha}(\bar{\Omega})$ :

$$W^{m,p}(\Omega) \hookrightarrow C^{k,\alpha}(\bar{\Omega}),$$
 (1.4.4)

where  $C^{k,\alpha}(\bar{\Omega})$  is the space of functions in  $C^k(\bar{\Omega})$  whose derivatives of order k are Hölder continuous with exponent  $\alpha$ . Moreover, if n=m-k-1, and  $\alpha=1$ , p=1, then (1.4.4) holds for  $\alpha=1$ , and the imbedding operator is compact from  $W^{m,p}(\Omega)$  to  $C^{k,\beta}(\bar{\Omega}), \forall 0 \leq \beta < \alpha$ .

Remark 1.4.1 The imbedding properties (i)-(iii) are still valid for smooth unbounded domains or  $\mathbb{R}^n$  provided that  $L^q(\Omega)$  in (1.4.3) and  $C^{k,\alpha}(\bar{\Omega})$  in (1.4.4) are replaced by  $L^q_{loc}(\Omega)$  and  $C^{k,\alpha}(\mathcal{B})$  for any bounded domain  $\mathcal{B} \subset \Omega$ , respectively.

Remark 1.4.2 The regularity assumption on  $\Omega$  can be weakened (e.g., see Adams [1]). When  $u \in W_0^{m,p}(\Omega)$ , the above imbedding properties are valid without any regularity assumptions on  $\Omega$ .

Let  $\Omega$  be a smooth bounded domain of class  $C^m$  and  $u \in W^{m,p}(\Omega)$ . Then we can define the trace of u on  $\Gamma$  which coincides with the value of u on  $\Gamma$  when u is a smooth function of  $C^m(\bar{\Omega})$ .

Theorem 1.4.3 (Trace Theorem) Let  $\boldsymbol{\nu} = (\nu_1, \dots, \nu_n)$  be the unit outward normal on  $\Gamma$  and

$$\gamma_j u = \frac{\partial^j u}{\partial \nu^j} \bigg|_{\Gamma}, \quad \forall u \in C^m(\bar{\Omega}), \quad j = 0, \dots, m - 1.$$
 (1.4.5)

Then the trace operator,  $\gamma = \{\gamma_0, \dots, \gamma_{m-1}\}$ , can be uniquely extended to a continuous operator from  $W^{m,p}(\Omega)$  to  $\prod_{j=0}^{m-1} W^{m-j-\frac{1}{p},p}(\Gamma)$ :

$$\gamma: u \in W^{m,p}(\Omega) \mapsto \gamma u = \{\gamma_0 u, \cdots, \gamma_{m-1} u\} \in \prod_{i=0}^{m-1} W^{m-j-\frac{1}{p},p}(\Gamma).$$
 (1.4.6)

Moreover, it is a surjective mapping.

Notice that  $W^{m-j-\frac{1}{p},p}(\Gamma)$  are spaces with fractional-order derivatives. Refer to Lions & Magenes [1] for the definition and more about that.

Let  $\Omega$  be a bounded domain in  $\mathbb{R}^n$  with  $C^1$  boundary  $\Gamma$ . Then, for any function  $u \in H^1(\Omega)$ , by the trace theorem, we have  $u|_{\Gamma} \in H^{\frac{1}{2}}(\Gamma) \subset L^2(\Gamma)$ . We now have the following useful result.

**Theorem 1.4.4** Let  $\Omega$  be a bounded domain in  $\mathbb{R}^n$  with  $C^1$  boundary  $\Gamma$ . Then for any function  $u \in H^1(\Omega)$ , the following estimate holds:

$$||u||_{L^{2}(\Gamma)} \le C||u||_{H^{1}(\Omega)}^{\frac{1}{2}}||u||_{L^{2}(\Omega)}^{\frac{1}{2}}$$
(1.4.7)

with C being a positive constant independent of u.

The proof is actually not difficult. The inequality (1.4.7) clearly holds for  $u \in C_0^1(\mathbb{R}_+^n)$ . For  $u \in H^1(\Omega)$ , we can use the standard technique in PDE: finite covering of  $\Omega$  and decomposition of unity to reduce the problem to the corresponding one in  $\mathbb{R}_+^n$ .

#### 1.4.2 The Gagliardo-Nirenberg and Poincaré Inequalities

Throughout this book the following Gagliardo-Nirenberg interpolation inequalities (see Nirenberg [1] and Friedman [1]) will be frequently used.

First, we introduce some notation. For p>0,  $|u|_{p,\Omega}=\|u\|_{L^p(\Omega)}$ . For p<0, set  $h=\left[-\frac{n}{p}\right]$ ,  $-\alpha=h+\frac{n}{p}$  and define

$$|u|_{p,\Omega} = \sup_{\Omega} |D^h u| \equiv \sum_{|\beta|=h} \sup_{\Omega} |D^\beta u|, \quad if \quad \alpha = 0,$$
 (1.4.8)

$$|u|_{p,\Omega} = [D^h u]_{\alpha,\Omega} \equiv \sum_{|\beta|=h} \sup_{\Omega} [D^{\beta} u]_{\alpha}$$

$$\equiv \sum_{|\alpha|=h} \sup_{x,y \in \Omega} \frac{|D^{\beta} u(x) - D^{\beta} u(y)|}{|x - y|^{\alpha}}, \quad \text{if } \alpha > 0.$$
(1.4.9)

If  $\Omega = \mathbb{R}^n$ , we simply write  $|u|_p$  instead of  $|u|_{p,\Omega}$ .

**Theorem 1.4.5** Let j and m be any integers satisfying  $0 \le j < m$ , and let  $1 \le q, r \le \infty$ , and  $p \in \mathbb{R}$ ,  $\frac{j}{m} \le a \le 1$  such that

$$\frac{1}{p} - \frac{j}{n} = a(\frac{1}{r} - \frac{m}{n}) + (1 - a)\frac{1}{q}.$$
(1.4.10)

Then,

(i) For any  $u \in W^{m,r}(\mathbb{R}^n) \cap L^q(\mathbb{R}^n)$ , there is a positive constant C depending only on n, m, j, q, r, and a such that the following inequality holds:

$$|D^{j}u|_{p} \le C|D^{m}u|_{r}^{a}|u|_{q}^{1-a} \tag{1.4.11}$$

with the following exception: if  $1 < r < \infty$  and  $m - j - \frac{n}{r}$  is a nonnegative integer, then (1.4.11) holds only for a satisfying  $\frac{j}{m} \le a < 1$ .

(ii) For any  $u \in W^{m,r}(\Omega) \cap L^q(\Omega)$  where  $\Omega$  is a bounded domain with smooth boundary, there are two positive constants  $C_1$ ,  $C_2$  such that the following inequality holds:

$$|D^{j}u|_{p,\Omega} \le C_{1}|D^{m}u|_{r,\Omega}^{a}|u|_{q,\Omega}^{1-a} + C_{2}|u|_{q,\Omega}$$
(1.4.12)

with the same exception as in (i).

In particular, for any  $u \in W_0^{m,r}(\Omega) \cap L^q(\Omega)$ , the constant  $C_2$  in (1.4.12) can be taken as zero.

The following two theorems are concerned with the useful Poincaré inequalities.

**Theorem 1.4.6** Let  $\Omega$  be a bounded domain in  $\mathbb{R}^n$  and  $u \in H_0^1(\Omega)$ . Then there is a positive constant C depending only on  $\Omega$  and n such that

$$||u||_{L^2(\Omega)} \le C||\nabla u||_{L^2(\Omega)}, \quad \forall \ u \in H_0^1(\Omega).$$
 (1.4.13)

**Theorem 1.4.7** Let  $\Omega$  be a bounded domain of  $C^1$  in  $\mathbb{R}^n$ . There is a positive constant C depending only on  $\Omega$ , n such that for any  $u \in H^1(\Omega)$ ,

$$||u||_{L^{2}(\Omega)} \le C \left( ||\nabla u||_{L^{2}(\Omega)} + \left| \int_{\Omega} u dx \right| \right).$$
 (1.4.14)

#### 1.4.3 Abstract Functions Valued in Banach Spaces

For the study of evolution equations it is convenient to introduce abstract functions valued in Banach spaces.

Let X be a Banach space,  $1 \leq p < \infty$ ,  $-\infty \leq a < b \leq \infty$ . Then  $L^p((a,b);X)$  denotes the space of  $L^p$  functions from (a,b) into X. It is a Banach space with the norm

$$||f||_{L^{p}((a,b);X)} = \left(\int_{a}^{b} ||f(t)||_{X}^{p} dt\right)^{\frac{1}{p}}$$
(1.4.15)

where the integral is understood in the Bochner sense.

For  $p = \infty$ ,  $L^{\infty}((a, b); X)$  is the space of measurable functions from (a, b) into X being essentially bounded. It is a Banach space with the norm

$$||f||_{L^{\infty}((a,b);X)} = \sup_{t \in (a,b)} ess||f(t)||_{X}.$$
(1.4.16)

Similarly, when  $-\infty < a < b < \infty$ , we can define Banach spaces  $C^k([a,b];X)$  with the norm

$$||f||_{C^{k}([a,b];X)} = \sum_{i=0}^{k} \max_{t \in [a,b]} ||\frac{d^{i}f}{dt^{i}}(t)||_{X}.$$
(1.4.17)

#### 1.4.4 Linear Elliptic Boundary Value Problems

In this section we introduce some basic results on linear elliptic boundary value problems (refer to Nirenberg [2], Friedman [1], and Lions & Magenes [1]).

Let  $\Omega$  be a domain with smooth boundary  $\Gamma$ . Any linear partial differential operator with, for simplicity,  $C^{\infty}$  coefficients  $a_{\alpha}(x)$  in  $\bar{\Omega}$  has the form

$$P(x,D) = \sum_{|\alpha| \le \mu} a_{\alpha}(x)D^{\alpha}. \tag{1.4.18}$$

The operator P is called elliptic in  $\bar{\Omega}$  if the leading homogeneous part of  $P(x,\xi)$  does not vanish for  $\xi \neq 0$  and  $x \in \bar{\Omega}$ :

$$P_{\mu}(x,\xi) = \sum_{|\alpha|=\mu} a_{\alpha}(x)\xi^{\alpha} \neq 0, \quad \forall \ x \in \bar{\Omega}, \ \xi \in \mathbb{R}^n \setminus \{0\}.$$
 (1.4.19)

The Laplace operator  $\Delta$  and the biharmonic operator  $\Delta^2$  are the most familiar elliptic operators.

It follows that for an elliptic operator P with real coefficients  $a_{\alpha}$ ,  $\mu$  must be an even number  $2m, m \geq 0, m \in \mathbb{N}$ . From now on we always assume that P is a uniformly elliptic operator with real  $C^{\infty}$  coefficients  $a_{\alpha}(x)$  in  $\bar{\Omega}$ . Usually, one studies boundary value problems for elliptic operators:

$$\begin{cases}
Pu = \sum_{|\alpha| \le 2m} a_{\alpha}(x) D^{\alpha} u = f, & x \in \Omega, \\
B_{j} u|_{\Gamma} = g_{j}, & j = 0, \dots m - 1,
\end{cases}$$
(1.4.20)

where f and  $g_j$  are given functions in  $\bar{\Omega}$  and  $\Gamma$ , respectively, and  $B_j$  are certain partial differential operators defined on  $\Gamma$  and the order of each  $B_j$  is less than 2m.

#### Wellposedness

When  $g_i \equiv 0$ , the problem (1.4.20) is said to be wellposed if

- (i) Ker P belongs to  $C^{\infty}$  and  $dim(Ker P) = \nu < \infty$ .
- (ii) In suitable function spaces X, Y the operator  $P: X \mapsto Y$  is continuous and has closed range in Y of finite codimension  $\nu^*$ , i.e., P is Fredholm.

The index of operator P is defined as follows:

$$ind P = \nu - \nu^*. \tag{1.4.21}$$

The boundary operators  $B_j$   $(j=0,\cdots,m-1)$  for which the general boundary problems (1.4.20) are wellposed have been characterized and are known as the Lopatinsky boundary conditions. As far as spaces X,Y are concerned,  $C^{2m+k+\alpha}(\bar{\Omega})$ ,  $C^{k+\alpha}(\bar{\Omega})$   $(k \in \mathbb{N}, \ 0 < \alpha < 1)$  and  $W^{2m+k,p}(\Omega)$ ,  $W^{k,p}(\Omega)$  (1 are two suitable choices ofSobolev spaces.

#### Basic Results in $C^{k+\alpha}$

(i) Fredholm

The mapping

$$P: \ \left\{u \in C^{2m+k+\alpha}(\bar{\Omega}) | B_j u = 0, \text{ on } \Gamma, \ (j=0,\cdots,m-1)\right\} \ \mapsto C^{k+\alpha}(\bar{\Omega}) \quad \ (1.4.22)$$

is Fredholm and its index is independent of k.

#### (ii) Regularity

If  $g_j = 0$ ,  $f \in C^{k+\alpha}(\bar{\Omega})$  and u is a weak solution of problem (1.4.20) in the distribution sense, then  $u \in C^{2m+k+\alpha}(\bar{\Omega})$ . Thus all functions in  $Ker\ P$  are in  $C^{\infty}$ .

#### (iii) A Priori Estimate

There exist two positive constants  $C_1, C_2$  independent of u such that for any  $u \in C^{2m+k+\alpha}(\bar{\Omega})$  satisfying  $B_j u|_{\Gamma} = 0, (j = 0, \dots, m-1),$ 

$$||u||_{C^{2m+k+\alpha}} \le C_1 ||Pu||_{C^{k+\alpha}} + C_2 ||u||_C. \tag{1.4.23}$$

Moreover, if Ker P = 0, i.e., the uniqueness of problem (1.4.20) holds, then there is a positive constant  $C_3$  independent of u such that

$$||u||_{C^{2m+k+\alpha}} \le C_3 ||Pu||_{C^{k+\alpha}}. \tag{1.4.24}$$

Basic Results in  $W^{k,p}(\Omega)$   $(k \in \mathbb{N}, 1$ 

#### (i) Fredholm

The mapping

$$P: \ \left\{ u \in W^{2m+k,\,p}(\Omega) | \ B_j u = 0, \ \text{on} \ \Gamma, \ \ (j=0,\cdots,m-1) \right\} \ \mapsto W^{k,\,p}(\Omega) \quad (1.4.25)$$

is Fredholm and its index is independent of k.

#### (ii) Regularity

If  $g_j \equiv 0$ ,  $f \in W^{k,p}(\Omega)$  and u is a weak solution of problem (1.4.20), then  $u \in W^{2m+k,p}(\Omega)$ . Thus all functions in  $Ker\ P$  are in  $C^{\infty}$ .

#### (iii) A Priori Estimate

There exist two positive constants  $C_1, C_2$  independent of u such that for any  $u \in W^{2m+k,p}(\Omega)$  satisfying  $B_j u|_{\Gamma} = 0$ ,  $(j = 0, \dots, m-1)$  in the trace sense,

$$||u||_{W^{k+2m,p}} \le C_1 ||Pu||_{W^{k,p}} + C_2 ||u||_{L^p}.$$
 (1.4.26)

Moreover, if  $Ker\ P=0$ , i.e., the uniqueness of problem (1.4.20) holds, then there is a positive constant  $C_3$  independent of u such that

$$||u||_{W^{k+2m,p}} \le C_3 ||Pu||_{W^{k,p}}. \tag{1.4.27}$$

In the remainder of this book we will also need the results for the nonhomogeneous boundary value problem (1.4.20) with  $g_j \neq 0$ ,  $(j = 0, \dots, m-1)$  being in Sobolev spaces of fractional order. Let the order of  $B_j$  be  $m_j$  with  $m_j \leq 2m-1$  and let  $g_j$  be in the Sobolev spaces  $H^{2m-m_j-\frac{1}{2}}$  of fractional order. Then we have the following result (see Lions & Magenes [1]).

**Theorem 1.4.8** For any  $u \in H^{2m+k}(\Omega)$  satisfying  $B_j u|_{\Gamma} = g_j$ ,  $(j = 0, \dots, m-1)$  in the trace sense, there exist positive constants  $C_k$  depending only on  $k \geq 0$  and  $\Omega$  such that

$$||u||_{H^{2m+k}} \le C_k \left( ||Pu||_{H^k} + \sum_{j=1}^{m-1} ||g_j||_{H^{2m-m_j-\frac{1}{2}}} + ||u||_{L^2} \right)$$
(1.4.28)

Moreover, if Ker P = 0, i.e., the uniqueness of problem (1.4.20) holds, then there is a positive constant  $C_k$  independent of u such that

$$||u||_{H^{2m+k}} \le C_k \left( ||Pu||_{H^k} + \sum_{j=1}^{m-1} ||g_j||_{H^{2m-m_j-\frac{1}{2}}} \right).$$
 (1.4.29)

#### 1.4.5 Interpolation Spaces

We recall a few facts about linear operators associated with a bilinear form and interpolation spaces associated with a positive definite operator in Hilbert spaces.

Let V, H be separable Hilbert spaces such that V is dense in H and the injection  $V \hookrightarrow H$  is continuous and compact. Thus, by the Riesz representation theorem we can write

$$V \subset H \equiv H' \subset V'. \tag{1.4.30}$$

The dual product between V and V' is denoted by  $\langle \, , \, \rangle$  and the inner product in H by  $(\, , \, )$ .

Let A be a linear continuous operator from V to V'. We can associate it with a bilinear form  $a(\cdot, \cdot)$  on V in such a way that

$$a(u,v) = \langle Au, v \rangle, \quad \forall u, v \in V. \tag{1.4.31}$$

Suppose that a is symmetric:

$$a(u, v) = a(v, u)$$
 (1.4.32)

and also suppose that a is coercive, i.e., there exists a positive constant  $\alpha>0$  such that

$$a(u,u) \ge \alpha ||u||_V^2, \quad \forall u \in V. \tag{1.4.33}$$

Let

$$D(A) = \{u | u \in V, Au \in H\}.$$
 (1.4.34)

Then by the Lax-Milgram theorem, a(u, v) can be considered as an equivalent inner product. Furthermore, A is a strictly positive self-adjoint operator in H and the spectral theorem allows us to define the powers  $A^s$  of A for  $s \in \mathbb{R}$ . Since we assume that the injection  $V \hookrightarrow H$  is compact, there exists (see Yosida [1]) a complete orthonormal basis  $\{w_j\}$  of H and a sequence  $\{\lambda_j\}$  such that  $w_j \in D(A)$  and

$$\begin{cases}
Aw_{j} = \lambda_{j}w_{j}, & j = 1, 2, \cdots, \\
0 < \lambda_{1} \leq \lambda_{2} \leq \cdots, & \lambda_{j} \to \infty, \quad as \quad j \to \infty, \\
a(w_{i}, w_{j}) = \lambda_{i}\delta_{ij}, & \forall i, j \in \mathbb{N}.
\end{cases}$$
(1.4.35)

Thus, for s > 0, we define

$$D(A^s) = \left\{ u \in H \left| \sum_{j=1}^{\infty} \lambda_j^{2s} |(u, w_j)|^2 < \infty \right. \right\}, \tag{1.4.36}$$

and

$$||u||_{D(A^s)} = \left(\sum_{j=1}^{\infty} \lambda_j^{2s} |(u, w_j)|^2\right)^{\frac{1}{2}}$$
(1.4.37)

For negative  $s, D(A^s)$  is the completion of H for the norm  $\left(\sum_{j=1}^{\infty} \lambda_j^{2s} |(u, w_j)|^2\right)^{\frac{1}{2}}$ . In particular, we have  $V = D(A^{\frac{1}{2}})$ .

Let X and Y be two Banach spaces, with  $X \subset Y$ , X dense in Y, and the injection  $X \hookrightarrow Y$  being continuous. In general, there are several different methods to define the intermediate spaces between X and Y. The framework described above gives a sort of definition of intermediate spaces, namely, the interpolation spaces.

Let

$$X = V = D(A^{\frac{1}{2}}), Y = H = D(A^{0}),$$
 (1.4.38)

and

$$a(u,v) = (u,v)_X.$$
 (1.4.39)

Then interpolation spaces  $[X,Y]_{\theta}$ ,  $(0 \le \theta \le 1)$  are given by

$$[X,Y]_{\theta} = D(A^{\frac{1-\theta}{2}}), \quad \forall \theta \in [0,1].$$
 (1.4.40)

The interpolation inequality

$$||u||_{[X,Y]_{\theta}} \le C(\theta)||u||_X^{1-\theta}||u||_Y^{\theta}, \quad \forall u \in X, \quad \theta \in [0,1]$$
 (1.4.41)

also follows from (1.4.40).

A typical example of the above framework is

$$V = H_0^1(\Omega), \ H = L^2(\Omega), \ A = -\Delta$$
 (1.4.42)

and

$$D(A) = H^2(\Omega) \cap H_0^1(\Omega) \tag{1.4.43}$$

with  $\Omega$  being a bounded domain of  $C^2$ .

#### 1.5 Notation

Throughout this book we use the following common notation.

- 1. In addition to the notation  $\frac{\partial^k}{\partial t^k}$ ,  $\frac{\partial^\alpha}{\partial x_1^{\alpha_1} \cdots \partial x_n^{\alpha_n}}$ , we also widely use  $D^k$  to denote the corresponding partial derivatives with respect to x, i.e.,  $D^k = \frac{\partial^k}{\partial x^k}$ . The subscripts t and x, y are often used to denote the partial derivatives with respect to t and x, y, respectively, i.e.,  $u_{tt} = \frac{\partial^2 u}{\partial t^2}$ ,  $v_{xx} = \frac{\partial^2 v}{\partial x^2}$ , etc.
- 2. We simply denote by  $(\cdot,\cdot)$ ,  $\|\cdot\|$  the inner product and norm in  $L^2$  space, respectively.
- 3. We often use  $C, C_i (i \in \mathbb{N}), K, M$  to denote a universal positive constant which may vary in different places.

## Chapter 2

#### Linear Thermoelastic Systems

In this chapter we are concerned with linear thermoelastic systems, namely, the linear one-dimensional thermoelastic system and the thermoelastic Kirchhoff plate equations. In the first four sections, we are dealing with the exponential stability of semigroups associated with the linear one-dimensional thermoelastic system subject to various boundary conditions. It is also shown that the corresponding semigroups are not analytic. In the final section of this chapter we consider the thermoelastic Kirchhoff plate equations. The results on exponential stability and analyticity of the corresponding semigroups are established.

#### 2.1 The Setting of Problems for the One-Dimensional Thermoelastic System

In this section we first formulate the initial boundary value problems for the linear one-dimensional thermoelastic system. Consider a linear homogeneous thermoelastic bar of length l with unit reference density. Let u be the displacement and  $\theta$  be the temperature deviation from the reference temperature. Then u and  $\theta$  satisfy the following linear one-dimensional thermoelastic system (for instance, refer to Dafermos [1]):

$$u_{tt} - au_{xx} + \gamma \theta_x = 0$$
, in  $(0, l) \times (0, +\infty)$ , (2.1.1)

$$c_o\theta_t + \gamma u_{xt} - k\theta_{xx} = 0, \text{ in } (0, l) \times (0, +\infty).$$

$$(2.1.2)$$

In the above, the first equation is the momentum equation and the second equation is the energy equation. We assume that  $a, \gamma, c_o$ , and k are given constants with  $a > 0, c_o > 0, k > 0, \gamma \neq 0$ . These constants depend on the material properties.

The above system (2.1.1) and (2.1.2) is subject to the initial conditions

$$u|_{t=0} = u_0(x), \quad u_t|_{t=0} = u_1(x), \quad \theta|_{t=0} = \theta_0(x),$$
 (2.1.3)

and the boundary conditions which are very often one of the following four pairs at x = 0 or l:

$$(i) \quad \left\{ \begin{array}{l} u=0 \\ \theta=0 \end{array} \right., \quad (ii) \quad \left\{ \begin{array}{l} u=0 \\ \theta_x=0 \end{array} \right., \quad (iii) \quad \left\{ \begin{array}{l} \sigma=0 \\ \theta=0 \end{array} \right., \quad (iv) \quad \left\{ \begin{array}{l} \sigma=0 \\ \theta_x=0 \end{array} \right.$$

where  $\sigma = u_x - \gamma \theta$  is the stress. The mechanical and physical meaning of these boundary conditions are very clear. For instance, the boundary condition (iv) implies that at that end of the elastic bar the stress is free and the heat is insulated.

Concerning the initial data, we assume that  $u_0 \in H^1$ ,  $u_1 \in L^2$ ,  $\theta_0 \in L^2$  satisfying the compatibility conditions. This means that if conditions (i) or (ii) are considered at one end of the bar, then  $u_0$  is also assumed to satisfy u=0 in the trace sense at that end.

In the first two sections of this chapter we always work with the boundary condition case (i), i.e., at both ends of the bar,

$$u = 0, \quad \theta = 0, \quad \text{at} \quad x = 0, \ l.$$
 (2.1.5)

In the third and fourth sections we will treat the other boundary condition cases. We refer the reader to Liu & Zheng [1] and Burns, Liu & Zheng [1] for the discussion of these four sections.

Without loss of generality, throughout this chapter we always assume that  $c_o = a = 1$  because for the general case the only thing we have to modify the discussion throughout this chapter is to replace, for instance, the usual  $L^2$  norm for  $\theta$  by the equivalent norm  $\sqrt{\int_0^l c_o \theta^2 dx}$ , etc.

To study the initial boundary value problem (2.1.1)-(2.1.3), and (2.1.5) by the semigroup theory, we introduce the new variables:

$$v = u_t. (2.1.6)$$

Then the initial boundary value problem (2.1.1)-(2.1.3) and (2.1.5) is reduced to the

following abstract initial value problem for a first-order evolution equation:

$$\begin{cases} \frac{dy}{dt} = Ay, & \forall t > 0\\ y|_{t=0} = y_0 = (u_0, u_1, \theta_0)^T \end{cases}$$
 (2.1.7)

with

$$y = \begin{pmatrix} u \\ v \\ \theta \end{pmatrix} \tag{2.1.8}$$

and

$$\mathcal{A} = \begin{pmatrix} 0 & I & 0 \\ D^2 & 0 & -\gamma D \\ 0 & -\gamma D & kD^2 \end{pmatrix}.$$
 (2.1.9)

Here we have used the notation:  $D^i = \frac{\partial^i}{\partial x^i}$ .

Let  $\Omega = (0, l)$  and

$$\mathcal{H} = H_0^1(\Omega) \times L^2(\Omega) \times L^2(\Omega) \tag{2.1.10}$$

equipped with the norm

$$||y||_{\mathcal{H}} = (||Du||^2 + ||v||^2 + ||\theta||^2)^{\frac{1}{2}},$$
 (2.1.11)

where  $\|\cdot\|$  is the  $L^2$  norm in  $\Omega$ .

Instead of dealing with (2.1.1)–(2.1.3), and (2.1.5), we will consider (2.1.7) with the domain of the operator A:

$$\mathcal{D}(\mathcal{A}) = H^2 \cap H_0^1 \times H_0^1 \times H^2 \cap H_0^1. \tag{2.1.12}$$

Then it is clear from Chapter 1 that the operator  $\mathcal{A}$  is a densely defined operator from  $\mathcal{D}(\mathcal{A})$  to  $\mathcal{H}$ . Furthermore, we have the following.

**Theorem 2.1.1** The operator A generates a  $C_o$ -semigroup  $S(t) = e^{At}$  of contractions on the Hilbert space  $\mathcal{H}$ .

**Proof** We first prove that A is a dissipative operator. Indeed, for any  $y \in \mathcal{D}(A)$ , by the definition (2.1.11) and by integration by parts, we have

$$(\mathcal{A}y,y)_{\mathcal{H}} = \int_0^{\pi} \left( Dv \cdot Du + D^2 u \cdot v - \gamma D\theta \cdot v - Dv \cdot \theta + k D^2 \theta \cdot \theta \right) dx$$

$$= -k \|D\theta\|^2$$

$$\leq 0. \tag{2.1.13}$$

This implies that  $\mathcal{A}$  is a dissipative operator. To prove that  $\mathcal{A}$  generates a  $C_0$ -semigroup of contractions on the Hilbert space  $\mathcal{H}$ , by Theorem 1.2.4 in Chapter 1, it remains to be proved that  $0 \in \rho(\mathcal{A})$ .

For any  $F = (f_1, f_2, f_3)^T \in \mathcal{H}$ , consider the equation

$$\mathcal{A}y = F,\tag{2.1.14}$$

i.e.,

$$v = f_1, (2.1.15)$$

$$D^2u - \gamma D\theta = f_2, (2.1.16)$$

$$-\gamma Dv + kD^2\theta = f_3. (2.1.17)$$

We plug  $v = f_1$  obtained from (2.1.15) into (2.1.17) to get

$$kD^2\theta = f_3 + \gamma Df_1 \in L^2. {(2.1.18)}$$

By the standard theory in the linear elliptic equations (see Chapter 1), we have a unique  $\theta \in H^2 \cap H_0^1$  satisfying (2.1.18). Then we plug  $\theta$  just obtained from solving (2.1.18) into (2.1.16) to get

$$D^2 u = \gamma D\theta + f_2 \in L^2. \tag{2.1.19}$$

Applying the standard theory in the linear elliptic equations again yields a unique solvability of  $u \in H^2 \cap H^1_0$  for (2.1.19). Thus the unique solvability of (2.1.14) follows. It is clear from the regularity theory of the linear elliptic equations that  $||y||_H \leq$ 

 $K||F||_H$  with K being a positive constant independent of y. Thus the proof is complete.

Since we use the semigroup approach to investigate solvability of problem (2.1.1)–(2.1.3) and (2.1.5), we have to clearify the relationship between the semigroup solution given by  $y(t) = S(t)y_0$  and the previous problem. In other words, we would like to show in what sense u and  $\theta$ , the first and third component of y, satisfy problem (2.1.1)–(2.1.3) and (2.1.5).

If  $y_0 \in \mathcal{D}(\mathcal{A})$ , i.e.,  $u_0 \in H^2 \cap H_0^1$ ,  $u_1 \in H_0^1$  and  $\theta_0 \in H^2 \cap H_0^1$ , then  $y(t) = S(t)y_0 \in C([0,\infty), \mathcal{D}(\mathcal{A})) \cap C^1([0,\infty), \mathcal{H})$  and (2.1.7) is satisfied in  $\mathcal{H}$  for every t > 0. It turns out that  $u \in C([0,\infty), H^2 \cap H_0^1) \cap C^1([0,\infty), H_0^1) \cap C^2([0,\infty), L^2)$ ,  $\theta \in C([0,\infty), H^2 \cap H_0^1) \cap C^1([0,\infty), L^2)$  and they both satisfy equations (2.1.1) and (2.1.2) in  $L^2$  for every t > 0. Initial conditions in (2.1.3) are satisfied in the strong sense and the boundary conditions (2.1.5) are satisfied in the trace sense. It is also clear that if  $y_0$  is more regular, for instance,  $y_0 \in \mathcal{D}(\mathcal{A}^2)$ , then we can obtain classical solution  $u, \theta$  from the semigroup solution.

If  $y_0 \in \mathcal{H}$ , i.e.,  $u_0 \in H_0^1$ ,  $u_1$ ,  $\theta_0 \in L^2$ , then  $y(t) = S(t)y_0$  is only a mild solution to the first-order evolution equation (2.1.7). Since  $\mathcal{D}(\mathcal{A})$  is dense in  $\mathcal{H}$ , there is a sequence  $y_{0n} \in \mathcal{D}(\mathcal{A})$  converging to  $y_0$  in  $\mathcal{H}$ . Accordingly, we have a sequence  $y_n(t) = S(t)y_{0n}$  such that  $u_n$  and  $\theta_n$  satisfy (2.1.1) and (2.1.2) in  $L^2$  for every t > 0 and for any T > 0,  $u_n \to u$  in  $C([0,T], H_0^1) \cap C^1([0,T], L^2)$ ,  $\theta_n \to C([0,T], L^2) \cap L^2([0,T], H_0^1)$ . Therefore, for any  $w, z \in H_0^1$ , if we multiply equation (2.1.1) and equation (2.1.2) for  $u_n, \theta_n$  by w and z, respectively, then integrate by parts with respect to x and integrate with respect to t, and finally pass to the limit, we obtain that

$$\begin{cases} (u_t, w) - (u_1, w) + a \int_0^t ((u_x, w_x) + \gamma(\theta_x, w)) d\tau = 0, \\ c_o(\theta, z) - c_o(\theta_0, z) - \gamma(u, z_x) + \gamma(u_0, z_x) + k \int_0^t (\theta_x, z_x) d\tau = 0. \end{cases}$$
(2.1.20)

(2.1.20) is usually called the variational form of problem (2.1.1)–(2.1.3) and (2.1.5). In other words, when  $y_0 \in \mathcal{H}$ , the first and third component u and  $\theta$  of the semigroup solution y is a pair of weak solutions to problem (2.1.1)–(2.1.3) and (2.1.5) in the sense 22

that (2.1.20) is satisfied for any test functions  $w, z \in H_0^1$ .

The previous argument also works for other inital boundary value problems for the system (2.1.1) and (2.1.2).

## 2.2 The Exponential Stability for the Dirichlet Boundary Conditions at Both Ends

In this section we will prove that the semigroup S(t), generated by the dissipative operator A, is exponentially stable.

**Theorem 2.2.1** The semigroup S(t), generated by the operator A, defined in (2.1.9) is exponentially stable, i.e., there are two positive constants  $M, \alpha$  such that

$$||S(t)|| \le Me^{-\alpha t}. \tag{2.2.1}$$

Before giving the proof of Theorem 2.2.1, we first recall some related results in the literature. As far as the linear thermoelastic system is concerned, Dafermos [1] was probably the first to investigate the asymptotic behavior of solutions to the initial boundary value problems for the linear thermoelastic system. It was shown in Dafermos [1] that if  $u_0 \in H^1, u_1 \in L^2, \theta_0 \in L^2$ , then the energy function of the system defined by

$$E(t) = ||u_x||^2 + ||u_t||^2 + ||\theta||^2$$
(2.2.2)

converges to zero as time goes to infinity. However, no decay rate was given. In 1981, Slemrod [1] used the energy method to prove that for the system (2.1.1) and (2.1.2) if  $u, \theta$  satisfy the boundary conditions (ii) or (iii) at both ends (i.e., stress free, constant temperature or clamped, insulated) and if  $u_0 \in H^2, u_1 \in H^1, \theta_0 \in H^2$  satisfy the compatibility conditions, then there are positive constants M and  $\alpha$  such that

$$||u_{t}(x)||^{2} + ||u_{x}(x)||^{2} + ||u_{tt}(x)||^{2} + ||u_{xt}(x)||^{2} + ||u_{xx}(x)||^{2}$$

$$+ ||\theta(t)||^{2} + ||\theta_{t}(t)||^{2} + ||\theta_{x}(t)||^{2} + ||\theta_{xx}(t)||^{2}$$

$$\leq M(||u_{0}||_{H^{2}}^{2} + ||u_{1}||_{H^{1}}^{2} + ||\theta_{0}||_{H^{2}}^{2})e^{-\alpha t}, \quad \forall t > 0,$$
(2.2.3)

which amounts to the following estimate:

$$||S(t)y_0||_{\mathcal{D}(\mathcal{A})} \le Me^{-\alpha t}||y_0||_{\mathcal{D}(\mathcal{A})}, \quad \forall t > 0.$$
 (2.2.4)

In 1990, Rivera [1] proved that the estimate (2.2.3) still holds if u and  $\theta$  both satisfy the boundary condition (i) at both ends (i.e., clamped, constant temperature). Later on, Shibata [1] and Jiang [1] considered the initial boundary value problem with the boundary conditions (iv) at both ends. Shibata used a spectral analysis method to obtain the polynomial decay of the solution. His method requires the boundedness of initial data in more regular spaces. Jiang improved Shibata's results and used the energy method to obtain the exponential decay of solutions. Again, Jiang's method requires the boundedness of initial data in more regular spaces. We also refer the reader to Slemrod [1], Zheng [1], Racke, Shibata & Zheng [1], Zheng & Shen [1], and Jiang [2] for the results on the global existence and uniqueness for the nonlinear thermoelastic system with small initial data. However, all of the results mentioned previously involve estimates of the type (2.2.3). The problem of establishing an energy estimate of the form

$$E(t) \le Me^{-\alpha t}E(0), \quad \forall t > 0, \tag{2.2.5}$$

or equivalently establishing the exponential stability (2.2.1) of the semigroup S(t) remained open for some time because the estimate (2.2.4) (or (2.2.3)) looks weaker than (2.2.1) (or (2.2.5)). However, it has now been clear (for instance, see Zheng [1]) that these two statements are equivalent.

When u and  $\theta$  satisfy the boundary conditions (ii) or (iii) at both ends, Hansen [1] in 1990 succeeded in establishing (2.2.5) using the Fourier series expansion method and a decoupling technique. We refer to Gibson, Rosen & Tao [1] for another approach, i.e., a combination of semigroup theory and the energy method. When u and  $\theta$  both satisfy the Dirichlet boundary conditions, i.e., the boundary conditions (i), Kim [1] and the authors (Liu & Zheng [1]) independently proved that the estimate (2.2.5) still holds. The methods in these two papers are quite different. Kim's method is based on a control theory approach and a uniqueness continuation theorem by J. L. Lions. In 24

Liu & Zheng [1], the authors used a contradiction argument by combining Theorem 1.3.1 with a PDE technique. In a later paper, Burns, Liu & Zheng [1] successively established (2.2.1) for all the boundary conditions (i)–(iv) using the same technique. This technique has been developed into a more systematic approach to deal with other problems, including the higher dimensional problems such as the Kirchhoff plate equations with thermal or viscous damping, as can be seen in the remainder of this book. It should be mentioned that for the linear higher dimensional thermoelastic system, for instance, the linear three-dimensional thermoelastic system, in general, we can not expect to have the results on exponential stability unless some assumptions are made on the domain and initial data. We refer the reader to Dafermos [1], Jiang, Rivera & Racke [1], and Jiang [2] in this direction.

#### Proof of Theorem 2.2.1

We now use Theorem 1.3.2 to prove Theorem 2.2.1. We first prove (1.3.3). This consists of the following steps:

- (i) It follows from the fact that  $0 \in \rho(\mathcal{A})$  and the contraction mapping theorem that for any real number  $\beta$  with  $|\beta| < ||\mathcal{A}^{-1}||^{-1}$ , the operator  $i\beta I \mathcal{A} = \mathcal{A}(i\beta \mathcal{A}^{-1} I)$  is invertible. Moreover,  $||(i\beta I \mathcal{A})^{-1}||$  is a continuous function of  $\beta$  in the interval  $(-||\mathcal{A}^{-1}||^{-1}, ||\mathcal{A}^{-1}||^{-1})$ .
- (ii) If  $\sup\{\|(i\beta I \mathcal{A})^{-1}\| \mid |\beta| < \|\mathcal{A}^{-1}\|^{-1}\} = M < \infty$ , then by the contraction mapping theorem, the operator  $i\beta I \mathcal{A} = (i\beta_0 I \mathcal{A})(I + i(\beta \beta_0)(i\beta_0 I \mathcal{A})^{-1})$  with  $|\beta_0| < \|\mathcal{A}^{-1}\|^{-1}$  is invertible for  $|\beta \beta_0| < \frac{1}{M}$ . It turns out that by choosing  $|\beta_0|$  as close to  $\|\mathcal{A}^{-1}\|^{-1}$  as we can, we conclude that  $\{\beta \mid |\beta| < \|\mathcal{A}^{-1}\|^{-1} + \frac{1}{M}\} \subset \rho(\mathcal{A})$  and  $\|(i\beta I \mathcal{A})^{-1}\|$  is a continuous function of  $\beta$  in the interval  $(-\|\mathcal{A}^{-1}\|^{-1} \frac{1}{M}, \|\mathcal{A}^{-1}\|^{-1} + \frac{1}{M})$ .
- (iii) Thus it follows from the argument in (ii) that if (1.3.3) is not true, then there is  $\omega \in \mathbb{R}$  with  $\|\mathcal{A}^{-1}\|^{-1} \leq |\omega| < \infty$  such that  $\{i\beta; |\beta| < |\omega|\} \subset \rho(\mathcal{A})$  and  $\sup\{\|(i\beta \mathcal{A})^{-1}\| \mid |\beta| < |\omega|\} = \infty$ . It turns out that there exists a sequence  $\beta_n \in \mathbb{R}$  with  $\beta_n \to \omega, |\beta_n| < |\omega|$  and a sequence of complex vector functions  $y_n \in \mathcal{D}(\mathcal{A})$  with

 $||y_n||_{\mathcal{H}} = (||Du_n||^2 + ||v_n||^2 + ||\theta_n||^2)^{\frac{1}{2}} = 1$  such that

$$\|(\mathbf{i}\beta_n I - \mathcal{A})y_n\|_{\mathcal{H}} \to 0, \tag{2.2.6}$$

as  $n \to \infty$ , i.e,

$$i\beta_n u_n - v_n \to 0 \quad \text{in } H_0^1, \tag{2.2.7}$$

$$i\beta_n v_n - D^2 u_n + \gamma D\theta_n \to 0 \quad \text{in } L^2,$$
 (2.2.8)

$$i\beta_n\theta_n - kD^2\theta_n + \gamma Dv_n \to 0 \quad \text{in } L^2.$$
 (2.2.9)

Taking the inner product of  $(i\beta_n I - A)y_n$  with  $y_n$  in  $\mathcal{H}$  and then taking its real part yields

$$Re((\mathbf{i}\beta_n I - \mathcal{A})y_n, y_n)_{\mathcal{H}} = k||D\theta_n||^2 \to 0.$$
 (2.2.10)

Thus it follows from (2.2.9) and (2.2.10) and the Poincaré inequality that

$$kD^2\theta_n - \gamma Dv_n \to 0 \quad \text{in } L^2. \tag{2.2.11}$$

Integrating (2.2.11) from 0 to x yields

$$kD\theta_n - kD\theta_n(0) - \gamma v_n(x) \to 0 \quad \text{in } L^2.$$
 (2.2.12)

Combining (2.2.12) with (2.2.10) yields

$$kD\theta_n(0) + \gamma v_n(x) \to 0 \quad \text{in } L^2.$$
 (2.2.13)

By  $||y_n||_{\mathcal{H}} = 1$  and (2.2.7), we get that  $||Dv_n||$  is uniformly bounded with respect to n. Thus it follows from (2.2.11) that  $||D^2\theta_n||$  is uniformly bounded. By the Gagliardo-Nirenberg inequality (1.4.11), we obtain that

$$|D\theta_n(0)| \le ||D\theta_n||_{L^{\infty}} \le C_1 ||D^2\theta_n||^{\frac{1}{2}} ||D\theta_n||^{\frac{1}{2}} + C_2 ||D\theta_n|| \to 0.$$
 (2.2.14)

Combining (2.2.14) with (2.2.13) yields

$$v_n(x) \to 0 \quad \text{in } L^2. \tag{2.2.15}$$

Taking the inner product of (2.2.8) with  $u_n$  in  $L^2$  and integrating by parts also yields

$$||Du_n|| \to 0 \quad \text{in } L^2. \tag{2.2.16}$$

Thus (2.2.10), (2.2.15) and (2.2.16) contradict  $||y_n||_H = 1$ , and the proof of (1.3.3) is complete.

We now prove (1.3.4) by a contradiction argument again. Suppose that (1.3.4) is not true. Then there exists a sequence  $\beta_n$  with  $|\beta_n| \to +\infty$  and a sequence of complex vector functions  $y_n \in \mathcal{D}(\mathcal{A})$  with unit norm in  $\mathcal{H}$  such that (2.2.6) holds. Again we have (2.2.10). The remaining proof is more delicate than that in (iii) because  $\beta_n \to \infty$  now. Dividing (2.2.9) by  $\beta_n$  and using the Poincaré inequality, we get

$$\frac{kD^2\theta_n - \gamma Dv_n}{\beta_n} \to 0 \quad \text{in } L^2. \tag{2.2.17}$$

Dividing (2.2.7) by  $\beta_n$  and using (2.2.17), we obtain

$$\frac{kD^2\theta_n}{\theta_n} - i\gamma Du_n \to 0 \quad \text{in } L^2. \tag{2.2.18}$$

Since  $||Du_n|| \le 1$ , (2.2.18) implies that  $||\frac{kD^2\theta_n}{\beta_n}||$  is bounded. Taking the inner product of (2.2.18) with  $Du_n$  in  $L^2$  yields

$$\left(\frac{kD^2\theta_n}{\beta_n}, Du_n\right) - i\gamma \|Du_n\|^2 \to 0.$$
 (2.2.19)

By integration by parts, we have

$$\left(\frac{kD^2\theta_n}{\beta_n}, Du_n\right) = \left.\frac{kD\theta_nD\bar{u}_n}{\beta_n}\right|_{r=l} - \left.\frac{kD\theta_nD\bar{u}_n}{\beta_n}\right|_{r=0} - \left(\frac{kD\theta_n}{\beta_n}, D^2u_n\right).$$
(2.2.20)

Dividing (2.2.8) by  $\beta_n$  and using (2.2.10) and the fact that  $||v_n|| \leq 1$ , we deduce that  $||\frac{D^2 u_n}{\beta_n}||$  is bounded. Thus it follows from (2.2.10) and the Cauchy-Schwartz inequality that

$$\left(\frac{kD\theta_n}{\beta_n}, D^2u_n\right) \to 0. \tag{2.2.21}$$

By the Gagliardo-Nirenberg inequality (1.4.11), we have

$$\left\| \frac{D\theta_n}{\sqrt{|\beta_n|}} \right\|_{L^{\infty}} \le C_1 \|D\theta_n\|^{\frac{1}{2}} \frac{\|D^2\theta_n\|^{\frac{1}{2}}}{\sqrt{|\beta_n|}} + C_2 \frac{\|D\theta_n\|}{\sqrt{|\beta_n|}} \to 0, \tag{2.2.22}$$

and

$$\left\| \frac{Du_n}{\sqrt{|\beta_n|}} \right\|_{L^{\infty}} \le C_1 \|Du_n\|^{\frac{1}{2}} \frac{\|D^2u_n\|^{\frac{1}{2}}}{\sqrt{|\beta_n|}} + C_2 \frac{\|Du_n\|}{\sqrt{|\beta_n|}} \le C \tag{2.2.23}$$

with C being a positive constant independent of n. Then it turns out from (2.2.22) and (2.2.23) that

$$\left\| \frac{kD\theta_n D\bar{u}_n}{\beta_n} \right\|_{L^{\infty}} \le \frac{\|D\theta_n\|_{L^{\infty}}}{\sqrt{|\beta_n|}} \frac{\|Du_n\|_{L^{\infty}}}{\sqrt{|\beta_n|}} \to 0.$$
 (2.2.24)

Combining it with (2.2.19)-(2.2.21) yields

$$||Du_n|| \to 0. \tag{2.2.25}$$

Thus by (2.2.1), we get

$$\frac{Dv_n}{\beta_n} \to 0 \quad \text{in } L^2. \tag{2.2.26}$$

Taking the inner product of (2.2.6) with  $v_n$  in  $L^2$  and dividing the result by  $\beta_n$ , we obtain that

$$\mathbf{i}\|v_n\|^2 + \left(Du_n, \frac{Dv_n}{\beta_n}\right) \to 0. \tag{2.2.27}$$

Therefore, by (2.2.25)–(2.2.27), we obtain that

$$v_n \to 0 \quad \text{in } L^2. \tag{2.2.28}$$

Thus (2.2.28), (2.2.25), and (2.2.10) contradict  $||y_n||_{\mathcal{H}} = 1$ . The proof of Theorem 2.2.1 is complete.

## 2.3 The Exponential Stability for the Stress-Free Boundary Conditions at Both Ends

In this section we consider the one-dimensional thermoelastic system (2.1.1) and (2.1.2) with the stress-free boundary conditions. The boundary conditions for the temperature are the following: either it is insulated at both ends, or one end is insulated and the other is kept at a constant temperature. We can always translate the constant 28

temperature to zero without changing the form of the system. Mathematically, the boundary conditions considered in this section are the following:

$$\sigma|_{x=0,l} = (u_x - \gamma \theta)|_{x=0,l} = 0, \quad \theta_x|_{x=0,l} = 0, \tag{2.3.1}$$

or

$$\sigma|_{x=0,l} = (u_x - \gamma\theta)|_{x=0,l} = 0, \quad \theta|_{x=0} = 0, \quad \theta_x|_{x=l} = 0.$$
 (2.3.2)

If both ends are kept at a constant temperature, then the boundary conditions are separated, i.e., u satisfies the Neumann boundary condition and  $\theta$  satisfies the Dirichlet boundary condition. This easy case has been considered by Hansen [1] and others (see Section 2.1).

We first consider the case of boundary conditions (2.3.1). Notice that both

$$\int_0^l u_t dx \quad \text{and} \quad \int_0^l (\theta + \gamma u_x) dx \tag{2.3.3}$$

are conserved all the time. Hence, we make the following substitutions

$$y_1 = u_x - \frac{\gamma c_2}{1 + \gamma^2}, \tag{2.3.4}$$

$$y_2 = u_t - c_1, (2.3.5)$$

$$y_3 = \theta - \frac{c_2}{1 + \gamma^2} \tag{2.3.6}$$

where the constants  $c_1$  and  $c_2$  are given by

$$c_1 = \frac{1}{l} \int_0^l u_1 dx, \quad c_2 = \frac{1}{l} \int_0^l (\theta_0 + \gamma(u_0)_x) dx. \tag{2.3.7}$$

Then  $y_1, y_2$  and  $y_3$  satisfy the boundary conditions

$$(y_1 - \gamma y_3)|_{x=0,l} = 0, \qquad y_{3x}|_{x=0,l} = 0,$$
 (2.3.8)

as well as the constraints

$$\int_0^l y_2 dx = 0, \qquad \int_0^l (y_3 + \gamma y_1) dx = 0 \tag{2.3.9}$$

and the initial conditions

$$y_1|_{t=0} = y_{10} = (u_0)_x - \frac{\gamma c_2}{1+\gamma^2}, \quad y_2|_{t=0} = y_{20} = u_1 - c_1, \quad y_3|_{t=0} = y_{30} = \theta_0 - \frac{c_2}{1+\gamma^2}.$$
(2.3.10)

Let  $y = (y_1, y_2, y_3)^T$  and

$$\mathcal{H}_1 = \left\{ y \in L^2 \times L^2 \times L^2 \text{ subject to } (2.3.9) \right\}$$

equipped with the norm

$$||y||_{\mathcal{H}_1} = (||y_1||^2 + ||y_2||^2 + ||y_3||^2)^{\frac{1}{2}}.$$
 (2.3.11)

Define the operator  $A_1 : \mathcal{D}(A_1) \subset \mathcal{H}_1 \to \mathcal{H}_1$  by

$$A_{1}y = \begin{pmatrix} Dy_{2} \\ Dy_{1} - \gamma Dy_{3} \\ -\gamma Dy_{2} + kD^{2}y_{3} \end{pmatrix}$$
 (2.3.12)

with

$$\mathcal{D}(\mathcal{A}_1) = \left\{ y \in H^1 \times H^1 \times H^2 \mid \text{subject to (2.3.8) and (2.3.9)} \right\}. \tag{2.3.13}$$

Then system (2.1.1), (2.1.2) and (2.3.1) can be reduced to the initial value problem for a first order evolution equation:

$$\begin{cases} \frac{dy}{dt} = \mathcal{A}_1 y, \\ y(0) = (y_{10}, y_{20}, y_{30})^T. \end{cases}$$
 (2.3.14)

In the same way as in the previous section we get that

$$Re(A_1 y, y)_{\mathcal{H}_1} = -k \|\theta_x\|^2 \le 0$$
 (2.3.15)

holds for any  $y \in \mathcal{D}(\mathcal{A}_1)$ . Therefore, the operator  $\mathcal{A}_1$  is dissipative. We now use Theorem 1.2.4 to prove the following theorem.

**Theorem 2.3.1** The operator  $A_1$  generates a  $C_0$ -semigroup of contractions in  $\mathcal{H}_1$ .

**Proof** By the dense theorem in Chapter 1,  $\mathcal{D}(\mathcal{A}_1)$  is dense in  $\mathcal{H}_1$ . Therefore, it remains to prove that  $0 \in \rho(\mathcal{A}_1)$ . For any  $F = (f_1, f_2, f_3)^T \in \mathcal{H}_1$ , consider

$$\mathcal{A}_1 y = F, \tag{2.3.16}$$

i.e.,

$$Dy_2 = f_1 \text{ in } L^2, \tag{2.3.17}$$

$$Dy_1 - \gamma Dy_3 = f_2 \quad \text{in } L^2, \tag{2.3.18}$$

$$-\gamma Dy_2 + kD^2y_3 = f_3 \quad \text{in } L^2. \tag{2.3.19}$$

It follows from (2.3.17) and (2.3.9) that  $y_2$  is uniquely given by

$$y_2 = \int_0^x f_1(s)ds - \frac{\int_0^l \int_0^x f_1(s)dsdx}{l}.$$
 (2.3.20)

Integrating (2.3.18) with respect to x, we get

$$y_1 - \gamma y_3 = \int_0^x f_2 dx + C_1. \tag{2.3.21}$$

Then, by (2.3.8) and (2.3.9),  $C_1$ ,  $\int_0^l y_1 dx$  and  $\int_0^l y_3 dx$  can be uniquely determined. To determine  $y_1$  and  $y_3$ , we multiply (2.3.17) by  $\gamma$ , then add the result to (2.3.19) to get

$$kD^2y_3 = f_3 + \gamma f_1. (2.3.22)$$

Then it follows from (2.3.8) that

$$kDy_3 = \int_0^x (f_3 + \gamma f_1) dx. \tag{2.3.23}$$

Since  $\int_0^t y_3 dx$  has been uniquely determined,  $y_3$  and, therefore by (2.3.21),  $y_1$  can be uniquely determined. It is clear that  $||y||_{H_1} \leq K||F||_{H_1}$  with K being a positive constant independent of F and y. This proves that  $0 \in \rho(\mathcal{A}_1)$ . Thus the proof is complete.

Furthermore, we have the following theorem.

**Theorem 2.3.2** The semigroup  $S_1(t)$ , generated by the operator  $A_1$  which is defined in (2.3.12), is exponentially stable, i.e., there are two positive constants  $M_1, \alpha_1$  such that

$$||S_1(t)|| \le M_1 e^{-\alpha_1 t}, \quad \forall t > 0.$$
 (2.3.24)

**Proof** We still use Theorem 1.3.2 to prove this theorem. As for Theorem 2.2.2, the proof consists of the following steps:

(i) Prove that  $0 \in \rho(A_1)$ . This has been done in the proof of Theorem 2.3.1.

(ii) If  $\sup\{\|(i\beta I-\mathcal{A}_1)^{-1}\|\ |\ |\beta|<\|\mathcal{A}_1^{-1}\|^{-1}\}=M<\infty$ , then by the contraction mapping theorem, the operator  $i\beta I-\mathcal{A}_1=(i\beta_0 I-\mathcal{A}_1)(I+i(\beta-\beta_0)(i\beta_0 I-\mathcal{A}_1)^{-1})$  with  $|\beta_0|<\|\mathcal{A}_1^{-1}\|^{-1}$  is invertible for  $|\beta-\beta_0|<\frac{1}{M}$ . It turns out that by choosing  $|\beta_0|$  as close to  $\|\mathcal{A}_1^{-1}\|^{-1}$  as we can, we conclude that  $\{\beta\ |\ |\beta|<\|\mathcal{A}_1^{-1}\|^{-1}+\frac{1}{M}\}\subset\rho(\mathcal{A}_1)$  and  $\|(i\beta I-\mathcal{A}_1)^{-1}\|$  is a continuous function of  $\beta$  in  $(-\|\mathcal{A}_1^{-1}\|^{-1}-\frac{1}{M},\|\mathcal{A}_1^{-1}\|^{-1}+\frac{1}{M})$ . (iii) Thus it follows from the argument in (ii) that if (1.3.3) is not true, then there is  $\omega\in\mathbb{R}$  with  $\|\mathcal{A}_1^{-1}\|^{-1}\leq|\omega|<\infty$  such that  $\{i\beta\ |\ |\beta|<|\omega|\}\subset\rho(\mathcal{A}_1)$  and  $\sup\{\|(i\beta-\mathcal{A}_1)^{-1}\|\ |\ |\beta|<|\omega|\}=\infty$ . It turns out that there exists a sequence  $\beta_n\in\mathbb{R}$  with  $\beta_n\to\omega,\,|\beta_n|<|\omega|$  and a sequence of complex vector functions  $y^{(n)}\in\mathcal{D}(\mathcal{A}_1)$  with  $\|y^{(n)}\|_{\mathcal{H}_1}=(\|y_1^{(n)}\|^2+\|y_2^{(n)}\|^2)^{\frac{1}{2}}=1$  such that

$$\|(\mathbf{i}\beta_n I - \mathcal{A}_1)y^{(n)}\|_{\mathcal{H}_1} \to 0,$$
 (2.3.25)

as  $n \to \infty$ , i.e.,

$$i\beta_n y_1^{(n)} - Dy_2^{(n)} \to 0 \quad \text{in } L^2,$$
 (2.3.26)

$$i\beta_n y_2^{(n)} - Dy_1^{(n)} + \gamma Dy_3^{(n)} \to 0 \quad \text{in } L^2,$$
 (2.3.27)

$$i\beta_n y_3^{(n)} - kD^2 y_3^{(n)} + \gamma D y_2^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.3.28)

In the same way as in the previous section, we take the inner product of  $(i\beta_n I - A_1)y^{(n)}$  with  $y^{(n)}$  in  $\mathcal{H}_1$  and then take its real part to get

$$k||Dy_3^{(n)}||^2 \to 0.$$
 (2.3.29)

Then it follows from (2.3.27) that

$$i\beta_n y_2^{(n)} - Dy_1^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.3.30)

Multiplying (2.3.26) by  $\gamma$ , then adding the result to (2.3.28) yields

$$i\beta_n(\gamma y_1^{(n)} + y_3^{(n)}) - kD^2 y_3^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.3.31)

Taking the inner product of (2.3.31) with  $\frac{\gamma y_1^{(n)} + y_3^{(n)}}{\beta_n}$  in  $L^2$  and integrating by parts, we get

$$i\|\gamma y_1^{(n)} + y_3^{(n)}\|^2 + \frac{k}{\beta_n} (Dy_3^{(n)}, \gamma Dy_1^{(n)} + Dy_3^{(n)}) \to 0.$$
 (2.3.32)

It can be seen from (2.3.30) that  $\frac{Dy_1^{(n)}}{\beta_n}$  is uniformly bounded in  $L^2$  with respect to n. Thus we can deduce from (2.3.32) and (2.3.29) that

$$\gamma y_1^{(n)} + y_3^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.3.33)

It follows from  $\|y_3^{(n)}\| \le 1$  and (2.3.29) that  $y_3^{(n)}$  is uniformly bounded in  $H^1$ . Hence, by the compactness of the imbedding of  $H^1$  into  $L^2$ , there is a subsequence of  $y_3^{(n)}$ , still denoted by  $y_3^{(n)}$ , such that  $y_3^{(n)}$  is a Cauchy sequence in  $L^2$ , and by (2.3.29), also in  $H^1$ . Let  $y_3$  be its limit. Then we have  $Dy_3=0$  in  $L^2$ , i.e.,  $y_3=Const$ . It follows from (2.3.33) that  $y_1^{(n)}$  is also a Cauchy sequence in  $L^2$  and its limit  $y_1$  is also a constant. It follows from (2.3.26) that  $Dy_2^{(n)}$  is a Cauchy sequence in  $L^2$ . Since  $\|y_2^{(n)}\| \le 1$ , by the same argument as before, we can conclude that  $y_2^{(n)}$ , if necessary by choosing another subsequence, is a Cauchy sequence in  $H^1$ . We denote the limit by  $y_2$ . Consequently, from (2.3.27) we conclude that  $y_1^{(n)}$  is also a Cauchy sequence in  $H^1$ . Taking the limit in (2.3.26) and (2.3.27) yields

$$i\omega y_1 - Dy_2 = 0 \quad \text{in } L^2,$$
 (2.3.34)

$$i\omega y_2 = Dy_1 = 0 \quad \text{in } L^2.$$
 (2.3.35)

Thus,  $y_1 = y_2 = 0$  and by (2.3.30) and (2.3.33),  $y_2 = y_3 = 0$ . It contradicts  $||y_1||^2 + ||y_2||^2 + ||y_3||^2 = 1$ . Thus the proof for (1.3.3), i.e.,  $iR \subset \rho(A_1)$ , is complete.

(iv) We now prove (1.3.4) by a contradiction argument again. Suppose that (1.3.4) is not true. Then there is a sequence of complex vector functions  $y^{(n)} \in \mathcal{D}(\mathcal{A}_1)$  with  $\|y^{(n)}\|_{\mathcal{H}_1} = (\|y_1^{(n)}\|^2 + \|y_2^{(n)}\|^2 + \|y_3^{(n)}\|^2)^{\frac{1}{2}} = 1$  and a sequence  $\beta_n \in \mathbb{R}$  such that  $|\beta_n| \to \infty$  and

$$\|(i\beta_n I - \mathcal{A}_1)y^{(n)}\|_{\mathcal{H}_1} \to 0,$$
 (2.3.36)

as  $n \to \infty$ , i.e.,

$$i\beta_n y_1^{(n)} - Dy_2^{(n)} \to 0 \quad \text{in } L^2,$$
 (2.3.37)

$$i\beta_n y_2^{(n)} - Dy_1^{(n)} + \gamma Dy_3^{(n)} \to 0 \quad \text{in } L^2,$$
 (2.3.38)

$$i\beta_n y_3^{(n)} - kD^2 y_3^{(n)} + \gamma D y_2^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.3.39)

As the same as before, we again have (2.3.29) and (2.3.33). Again there is a subsequence of  $y_3^{(n)}$ , still denoted by  $y_3^{(n)}$  such that  $y_3^{(n)}$  is a Cauchy sequence in  $H^1$  with the limit  $y_3 = Const.$  and  $y_1^{(n)}$  is a Cauchy sequence in  $L^2$  with the limit  $y_1 = Const.$  Since  $\frac{y_2^{(n)}}{\beta_n} \to 0$  in  $L^2$ , it follows from (2.3.37) that  $\frac{y_2^{(n)}}{\beta_n}$  is a Cauchy sequence in  $H^1$ , whose limit must be zero, and

$$y_1 = 0. (2.3.40)$$

It can be seen from (2.3.38) that in order to prove that  $y_2^{(n)}$  is a Cauchy sequence in  $L^2$  with the limit zero, it suffices to prove that  $\frac{Dy_1^{(n)}}{\beta_n}$  converges to zero in  $L^2$ . We can rewrite (2.3.38) as

$$iy_2^{(n)} - \frac{Dy_1^{(n)} - \gamma Dy_3^{(n)}}{\beta_n} \to 0 \quad \text{in } L^2.$$
 (2.3.41)

Taking the inner product of (2.3.41) with  $\frac{Dy_1^{(n)} - \gamma Dy_3^{(n)}}{\beta_n}$  in  $L^2$  and integrating by parts yields

$$-i\left(\frac{Dy_2^{(n)}}{\beta_n}, y_1^{(n)} - \gamma y_3^{(n)}\right) - \frac{\|Dy_1^{(n)} - \gamma Dy_3^{(n)}\|^2}{\beta_n^2} \to 0.$$
 (2.3.42)

By (2.3.37), we have

$$(y_1^{(n)}, y_1^{(n)} - \gamma y_3^{(n)}) - \frac{\|Dy_1^{(n)} - \gamma Dy_3^{(n)}\|^2}{\beta_2^2} \to 0.$$
 (2.3.43)

Because  $y_1^{(n)} \to 0$  and  $\frac{Dy_3^{(n)}}{\beta_n} \to 0$  in  $L^2$ , we get that  $\frac{Dy_1^{(n)}}{\beta_n} \to 0$  in  $L^2$ . Thus we can deduce from (2.3.38) that

$$y_2^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.3.44)

It follows from (2.3.37) and  $y_1^{(n)} \to 0$  in  $L^2$  that  $\frac{Dy_2^{(n)}}{\beta_n} \to 0$  in  $L^2$ . Taking the inner product of (2.3.39) with  $\frac{y_3^{(n)}}{\beta_n}$  in  $L^2$ , integrating by parts and using (2.3.29), we obtain that  $y_3^{(n)} \to 0$  in  $L^2$ . Thus we again have a contradiction and the proof of the theorem is complete.

We now consider the case of boundary conditions (2.3.2). In this case, only  $\int_0^l u_t dx$  is conserved. Thus, we make the substitution

$$v = u_t - c_1 (2.3.45)$$

where  $c_1$  is the same constant as defined in (2.3.7). Let  $y = (y_1, y_2, y_3)^T = (u_x, v, \theta)^T$  and define the operator  $A_2$  the same as  $A_1$  except that

$$\mathcal{D}(\mathcal{A}_2) = \left\{ y \in H^1 \times H^1 \times H^2 \mid \text{subject to (2.3.2) and } \int_0^l v \, dx = 0 \right\}. \tag{2.3.46}$$

Then system (2.1.1)–(2.1.3) and (2.3.2) can be reduced to the initial value problem for a first order evolution equation:

$$\begin{cases} \frac{dy}{dt} = \mathcal{A}_2 y, \\ y|_{t=0} = ((u_0)_x, u_1 - c_1, \theta_0)^T. \end{cases}$$
 (2.3.47)

Let

$$\mathcal{H}_2 = \left\{ y \in L^2 \times L^2 \times L^2 \mid \int_0^{\pi} y_2 \, dx = 0 \right\}$$
 (2.3.48)

equipped with the usual  $L^2 \times L^2 \times L^2$  norm. Then it can be proved in the same way as before, which can be omitted here, that the operator  $\mathcal{A}_2$  is dissipative. Moreover,  $0 \in \rho(\mathcal{A}_2)$ . Thus from Theorem 1.2.4 in Chapter 1 we can deduce the following.

**Theorem 2.3.3** The operator  $A_2$  generates a  $C_o$ -semigroup of contractions in  $\mathcal{H}_2$ .

Similarly, we have the next theorem.

**Theorem 2.3.4** The semigroup  $S_2(t)$ , generated by the operator  $A_2$  which is defined in (2.3.12), is exponentially stable, i.e., there are two positive constants  $M_2, \alpha_2$  such that

$$||S_2(t)|| \le M_2 e^{-\alpha_2 t}. \tag{2.3.49}$$

**Proof** The method of the proof here is essentially the same as that used in the proof of Theorem 2.3.2 except for some slight modifications due to the changes in the boundary conditions and constraints. Since  $\theta|_{x=0} = 0$ , we can apply the Poincaré inequality to  $\theta$  so that the proof of this theorem becomes simpler. In order to avoid redundant work, we will only point out the differences from the proof of Theorem 2.3.2.

- (i) We still have  $0 \in \rho(A_2)$  as mentioned before.
- (ii) If (1.3.3) is not true, then there is  $\omega \in \mathbb{R}$  with  $\|\mathcal{A}_2^{-1}\|^{-1} \leq |\omega| < \infty$  such that  $\{i\beta \mid |\beta| < |\omega|\} \subset \rho(\mathcal{A}_2)$  and  $\sup\{\|(i\beta \mathcal{A}_2)^{-1}\| \mid |\beta| < |\omega|\} = \infty$ . It turns out that there exists a sequence  $\beta_n \in \mathbb{R}$  with  $\beta_n \to \omega$ ,  $|\beta_n| < |\omega|$  and a sequence of complex vector functions  $y^{(n)} \in \mathcal{D}(\mathcal{A}_2)$  with  $\|y^{(n)}\|_{\mathcal{H}_2} = (\|y_1^{(n)}\|^2 + \|y_2^{(n)}\|^2 + \|y_3^{(n)}\|^2)^{\frac{1}{2}} = 1$  such that

$$\|(\mathbf{i}\beta_n I - \mathcal{A}_2)y^{(n)}\|_{\mathcal{H}_2} \to 0,$$
 (2.3.50)

as  $n \to \infty$ , i.e.,

$$i\beta_n y_1^{(n)} - Dy_2^{(n)} \to 0 \quad \text{in } L^2,$$
 (2.3.51)

$$i\beta_n y_2^{(n)} - Dy_1^{(n)} + \gamma Dy_3^{(n)} \to 0 \quad \text{in } L^2,$$
 (2.3.52)

$$i\beta_n y_3^{(n)} - kD^2 y_3^{(n)} + \gamma D y_2^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.3.53)

Thus we have

$$k||Dy_3^{(n)}||^2 \to 0,$$
 (2.3.54)

and by the Poincaré inequality,

$$y_3^{(n)} \to 0 \quad \text{in } H^1.$$
 (2.3.55)

In the same manner as before, we have

$$\gamma y_1^{(n)} + y_3^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.3.56)

Therefore.

$$y_1^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.3.57)

By (2.3.51), we have

$$Dy_2^{(n)} \to 0 \quad \text{in } L^2,$$
 (2.3.58)

and by the Poincaré inequality,

$$y_2^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.3.59)

Thus  $iR \subset \rho(A_2)$  is proved.

(iii) We now prove (1.3.4) by a contradiction argument again. Suppose that (1.3.4) is not true. Then there is a sequence of complex vector functions  $y^{(n)} \in \mathcal{D}(\mathcal{A}_2)$  with  $\|y^{(n)}\|_{\mathcal{H}_2} = (\|y_1^{(n)}\|^2 + \|y_2^{(n)}\|^2 + \|y_3^{(n)}\|^2)^{\frac{1}{2}} = 1$  and a sequence  $\beta_n \in \mathbb{R}$  such that  $|\beta_n| \to \infty$  and (2.3.51)–(2.3.53) hold. Again we have (2.3.55) and (2.3.57). It can be seen from the proof of Theorem 2.3.2 that we still have  $\frac{Dy_1^{(n)}}{\beta_n} \to 0$  in  $L^2$  and

$$y_2^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.3.60)

Thus, we again have a contradiction and the proof of the theorem is complete.

## 2.4 The Exponential Stability for the Stress-Free Boundary Conditions at One End

In this section, we turn to the cases that one end of the rod is rigidly clamped, and the other end is free. This, together with the thermal boundary conditions (insulated or constant temperature), leads to the following possible boundary conditions:

$$u|_{x=0} = 0, \quad \sigma|_{x=l} = 0, \quad \theta_x|_{x=0,l} = 0,$$
 (2.4.1)

$$u|_{x=0} = 0, \quad \sigma|_{x=l} = 0, \quad \theta|_{x=0} = 0, \quad \theta_x|_{x=l} = 0,$$
 (2.4.2)

$$u|_{x=0} = 0, \quad \sigma|_{x=l} = 0, \quad \theta|_{x=0,l} = 0,$$
 (2.4.3)

and

$$u|_{x=0} = 0$$
,  $\sigma|_{x=l} = 0$ ,  $\theta_x|_{x=0} = 0$ ,  $\theta|_{x=l} = 0$ . (2.4.4)

Boundary condition (2.4.4) has been considered by Hansen [1]. He used the method of combining the Fourier series expansion with decoupling technique. However, his method failed for boundary conditions (2.4.1), (2.4.2), and (2.4.3) since the system (2.1.1)-(2.1.3) with these boundary conditions cannot be decoupled.

Let  $H_l^1 = \{ f(x) \in H^1 : f(0) = 0 \}$  and

$$\mathcal{H}_{3} = \left\{ y \in H_{l}^{1} \times L^{2} \times L^{2} \mid \int_{0}^{l} (y_{3} + \gamma y_{1x}) dx = 0 \right\}, \quad \mathcal{H}_{4} = \mathcal{H}_{5} = H_{l}^{1} \times L^{2} \times L^{2} \quad (2.4.5)$$

equipped with the norm

$$||y||_{\mathcal{H}_{j}} = (||Dy_{1}||^{2} + ||y_{2}||^{2} + ||y_{3}||^{2})^{\frac{1}{2}}, \ j = 3, 4, 5.$$
 (2.4.6)

In the case of boundary condition (2.4.1), to translate the equilibrium to zero, we make the following substitution:

$$y_1 = u - \frac{\gamma c_2}{1 + \gamma^2} x$$
,  $y_2 = u_t$ ,  $y_3 = \theta - \frac{c_2}{1 + \gamma^2}$ , (2.4.7)

where  $c_2$  is the constant defined by (2.3.7) in Section 2.2 of this chapter. Then  $y_1, y_3$  satisfy

$$y_1|_{x=0} = 0$$
,  $(y_{1x} - \gamma y_3)|_{x=l} = 0$ ,  $y_{3x}|_{x=0,l} = 0$ ,  $\int_0^l (y_3 + \gamma y_{1x}) dx = 0$ . (2.4.8)

Define the operators  $A_j: \mathcal{D}(A_j) \subset \mathcal{H}_j \to \mathcal{H}_j, \ j=3,4,5$  by

$$A_{j} = \begin{pmatrix} 0 & I & 0 \\ D^{2} & 0 & -\gamma D \\ 0 & -\gamma D & kD^{2} \end{pmatrix}$$
 (2.4.9)

with

$$\mathcal{D}(\mathcal{A}_3) = \{(y_1, y_2, y_3)^T \in H^2 \times H^1_t \times H^2 \mid \text{subject to } (2.4.8)\}, \quad (2.4.10)$$

$$\mathcal{D}(\mathcal{A}_4) = \left\{ (u, u_t, \theta)^T \in H^2 \times H_l^1 \times H^2 \mid \text{subject to } (2.4.2) \right\}, \qquad (2.4.11)$$

$$\mathcal{D}(\mathcal{A}_5) = \left\{ (u, u_t, \theta)^T \in H^2 \times H_l^1 \times H^2 \mid \text{subject to } (2.4.3) \right\}. \tag{2.4.12}$$

Thus, the system (2.1.1)-(2.1.3) with the boundary condition (2.4.1), (2.4.2), (2.4.3), respectively, can be reduced to the initial value problem for a first order evolution equation:

$$\begin{cases} \frac{dy}{dt} = A_j y, & j = 3, 4, 5, \\ y(0) = y_0. \end{cases}$$
 (2.4.13)

where  $y = (y_1, y_2, y_3)^T$  if j = 3;  $y = (u, u_t, \theta)^T$  if j = 4, 5. In the same manner as before, we can prove that  $A_j$ , (j = 3, 4, 5) is the infinitesimal generator of a  $C_0$ -semigroup  $S_j(t)$  of contractions on the Hilbert space  $\mathcal{H}_j$ . Since the method is exactly the same, we omit the detail here.

**Theorem 2.4.1** The semigroup  $S_j(t)$  (j=3,4,5), associated with (2.4.13), is exponentially stable, i.e., there exist constants  $M_j > 0$ ,  $\alpha_j > 0$  such that

$$||S_j(t)|| \le M_j e^{-\alpha_j t}, \quad \forall \ t > 0.$$
 (2.4.14)

Therefore, the solution y of (2.4.13) satisfies

$$||u_x(t)||^2 + ||u_t(t)||^2 + ||\theta(t)||^2$$

$$\leq M_j \left( ||(u_0)_x||^2 + ||u_1||^2 + ||\theta_0||^2 \right) e^{-\alpha,t}, \quad \text{if } j = 4, 5, \tag{2.4.15}$$

and

$$||u_{x}(t) - \frac{\gamma c_{2}}{1 + \gamma^{2}}||^{2} + ||u_{t}(t)||^{2} + ||\theta(t) - \frac{c_{2}}{1 + \gamma^{2}}||^{2}$$

$$\leq \overline{M}_{j} \left( ||(u_{0})_{x}||^{2} + ||u_{1}||^{2} + ||\theta_{0}||^{2} \right) e^{-\alpha_{j}t}, \quad \text{if } j = 3$$
(2.4.16)

where  $\overline{M}_3$  is a constant depending only on  $M_3$  and  $\gamma$ .

**Proof** Since the proof is quite similar to Theorem 2.2.1 and Theorem 2.3.2, we will only point out the major differences:

- (i) We still have  $0 \in \rho(A_i), j = 3, 4, 5$ .
- (ii) For fixed j=3,4,5, if (1.3.3) is not true, then there is  $\omega\in\mathbb{R}$  with  $\|\mathcal{A}_j^{-1}\|^{-1}\leq |\omega|<\infty$  such that  $\{i\beta\mid|\beta|<|\omega|\}\subset\rho(\mathcal{A}_j)$  and  $\sup\{\|(i\beta-\mathcal{A}_j)^{-1}\|\mid|\beta|<|\omega|\}=\infty.$  It turns out that there exists a sequence  $\beta_n\in\mathbb{R}$  with  $\beta_n\to\omega,\,|\beta_n|<|\omega|$  and

a sequence of complex vector functions  $y^{(n)} \in \mathcal{D}(\mathcal{A}_j)$  with  $||y^{(n)}||_{\mathcal{H}_j} = (||Dy_1^{(n)}||^2 + ||y_2^{(n)}||^2 + ||y_3^{(n)}||^2)^{\frac{1}{2}} = 1$  such that

$$\|(\boldsymbol{i}\beta_n I - \mathcal{A})y^{(n)}\|_{\mathcal{H}_*} \to 0, \tag{2.4.17}$$

as  $n \to \infty$ , i.e.,

$$i\beta_n y_1^{(n)} - y_2^{(n)} \to 0 \quad \text{in } H^1,$$
 (2.4.18)

$$i\beta_n y_2^{(n)} - D^2 y_1^{(n)} + \gamma D y_3^{(n)} \to 0 \quad \text{in } L^2,$$
 (2.4.19)

$$i\beta_n y_3^{(n)} - kD^2 y_3^{(n)} + \gamma D y_2^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.4.20)

Therefore, we still have

$$k||Dy_3^{(n)}||^2 \to 0.$$
 (2.4.21)

For j = 3, we have

$$\gamma D y_1^{(n)} + y_3^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.4.22)

As in the proof of Theorem 2.3.2, there exists a subsequence of  $y_3^{(n)}$ , still denoted by  $y_3^{(n)}$ , such that  $y_3^{(n)}$  is a Cauchy sequence in  $H^1$  with its limit  $y_3$  being a constant. It turns out from (2.4.22) that  $Dy_1^{(n)}$  is also a Cauchy sequence in  $L^2$ . Since  $y_1^{(n)}|_{x=0}=0$ , by the Poincaré inequality,  $y_1^{(n)}$  is a Cauchy sequence in  $L^2$ , and also in  $H^1$ . Let  $y_1$  be its limit. Then  $Dy_1 = Const$ . By (2.4.18),  $y_2^{(n)}$  is also Cauchy sequence in  $H^1$ . It follows from (2.4.19) that  $D^2y_1^{(n)}$  is a Cauchy sequence in  $L^2$ . Thus  $y_1^{(n)}$  is a Cauchy sequence in  $H^2$  with  $D^2y_1 = 0$ . Let  $y_2$  be the limit of  $y_2^{(n)}$ . By passing to the limit in (2.4.19) and (2.4.18), we get  $y_2 = 0$  and  $y_1 = 0$ , and by  $\gamma Dy_1 + y_3 = 0$ , we deduce that  $y_3 = 0$ . Thus, it contradicts  $||Dy_1||^2 + ||y_2||^2 + ||y_3||^2 = 1$  and the proof of (1.3.3), i.e.,  $iR \subset \rho(\mathcal{A}_3)$  is complete.

For j=4,5, because of the boundary conditions, we can apply the Poincaré inequality to  $y_1$  and  $y_3$ . It follows from (2.4.21) that  $y_3^{(n)} \to 0$  in  $H^1$ . Then we can deduce from (2.4.20) and (2.4.19) that  $||D^2y_3^{(n)}||$  and  $||D^2y_1^{(n)}||$  are bounded. Multiplying (2.4.18) by  $\gamma$ , then adding the result up to (2.4.20) yields

$$i\beta_n \gamma D y_1^{(n)} - k D^2 y_3^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.4.23)

Multiplying (2.4.23) by  $Dy_1^{(n)}$  and integrating by parts, we get

$$i\beta_n\gamma\|Dy_1^{(n)}\|^2 + k(Dy_3^{(n)}, D^2y_1^{(n)}) - kDy_3^{(n)}D\bar{y}_1^{(n)}|_{x=l} + kDy_3^{(n)}D\bar{y}_1^{(n)}|_{x=0} \to 0. \quad (2.4.24)$$

By the Gagliardo-Nirenberg inequality,

$$||Dy||_{L^{\infty}} \le C_1 ||D^2y||^{\frac{1}{2}} ||Dy||^{\frac{1}{2}} + C_2 ||Dy||.$$
 (2.4.25)

Thus, from (2.4.21) we can deduce that two boundary terms in (2.4.24) converge to zero. Therefore, it follows from (2.4.24) that

$$Dy_1^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.4.26)

By the Poincaré inequality, we obtain that

$$y_1^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.4.27)

Therefore, it follows from (2.4.18) that

$$y_2^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.4.28)

A contradiction again. Thus  $iR \subset \rho(A_j)$ , j = 4, 5.

(iii) We now prove (1.3.4) by a contradiction argument. For fixed j=3,4,5, suppose that (1.3.4) is not true. Then there is a sequence of complex vector functions  $y^{(n)} \in \mathcal{D}(\mathcal{A}_j)$  with  $\|y^{(n)}\|_{\mathcal{H}_j} = (\|Dy_1^{(n)}\|^2 + \|y_2^{(n)}\|^2 + \|y_3^{(n)}\|^2)^{\frac{1}{2}} = 1$  and a sequence  $\beta_n \in \mathbb{R}$  such that  $|\beta_n| \to \infty$  and (2.4.18)-(2.4.20) hold. Therefore, we still have (2.4.21).

For j=3, we have (2.4.22) and a subsequence of  $y_3^{(n)}$  and  $y_1^{(n)}$ , still denoted by  $y_3^{(n)}$  and  $y_1^{(n)}$  such that  $y_3^{(n)} \to y_3$ ,  $y_1^{(n)} \to y_1$  in  $H^1$  with  $y_3$  being a constant and  $Dy_1 = Const$ . It follows from (2.4.18) that

$$y_1^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.4.29)

Thus,  $y_1 = 0$ , and it turns out that  $y_3 = 0$  also holds. Dividing (2.4.19) by  $\beta_n$  yields

$$iy_2^{(n)} - \frac{D^2y_1^{(n)}}{\beta_n} \to 0 \quad \text{in } L^2$$
 (2.4.30)

which implies that  $\frac{1}{\beta_n}D^2y_1^{(n)}$  is uniformly bounded. Taking the inner product of (2.4.30) with  $y_2^{(n)}$  in  $L^2$  and integrating by parts yields

$$i\|y_2^{(n)}\|^2 + (Dy_1^{(n)}, \frac{Dy_2^{(n)}}{\beta_n}) - \frac{Dy_1^{(n)}}{\beta_n}\overline{y}_2^{(n)}|_{x=l} + \frac{Dy_1^{(n)}}{\beta_n}\overline{y}_2^{(n)}|_{x=0} \to 0.$$
 (2.4.31)

By the Gagliardo-Nirenberg inequality, we have

$$\frac{\|Dy_1^{(n)}\|_{L^{\infty}}}{\sqrt{|\beta_n|}} \le C_1 \frac{\|D^2y_1^{(n)}\|^{\frac{1}{2}}}{\sqrt{|\beta_n|}} \|Dy_1^{(n)}\|^{\frac{1}{2}} + C_2 \frac{\|Dy_1^{(n)}\|}{\sqrt{|\beta_n|}}, \tag{2.4.32}$$

and

$$\frac{\|y_2^{(n)}\|_{L^{\infty}}}{\sqrt{|\beta_n|}} \le C_1 \frac{\|Dy_2^{(n)}\|^{\frac{1}{2}}}{\sqrt{|\beta_n|}} \|y_2^{(n)}\|^{\frac{1}{2}} + C_2 \frac{\|y_2^{(n)}\|}{\sqrt{|\beta_n|}}.$$
 (2.4.33)

Thus two boundary terms in (2.4.31) converge to zero. It is clear that the second term in (2.4.31) also converges to zero. Therefore,

$$y_2^{(n)} \to 0 \quad \text{in } L^2.$$
 (2.4.34)

A contradiction again. Thus the proof for the case j = 3 is complete.

For j=4,5, we still have  $y_3^{(n)}\to 0$  in  $H^1$  and we can deduce from (2.4.20) and (2.4.19) that  $\|\frac{D^2y_3^{(n)}}{\beta_n}\|$  and  $\|\frac{D^2y_1^{(n)}}{\beta_n}\|$  are uniformly bounded. Now (2.4.24) should be changed into

$$i\gamma \|Dy_1^{(n)}\|^2 + k(Dy_3^{(n)}, \frac{D^2y_1^{(n)}}{\beta_n}) - kDy_3^{(n)} \frac{D\overline{y}_1^{(n)}|_{x=l}}{\beta_n} + kDy_3^{(n)} \frac{D\overline{y}_1^{(n)}|_{x=0}}{\beta_n} \to 0. \quad (2.4.35)$$

Applying the Gagliardo-Nirenberg inequality, we get (2.4.26) and (2.4.27) again. It follows from (2.4.19) that

$$iy_2^{(n)} - \frac{D^2y_1^{(n)}}{\beta_n} \to 0 \quad \text{in } L^2.$$
 (2.4.36)

Then making the same argument as for (2.4.30)–(2.4.34) yields a contradiction again. Thus the proof for j = 4, 5 is complete.

Remark 2.4.1 As proved, for instance, in Rivera & Racke [1] and Liu & Yong [1], the semigroup associated with linear one-dimensional thermoelastic system is not analytic.

#### 2.5 The Thermoelastic Kirchhoff Plate Equations

In this section we consider the thermoelastic Kirchhoff plate equations. The equations describing a linear thermoelastic Kirchhoff plate of homogeneous material (see Lagnese [3]) are the following:

$$\begin{cases} w_{tt} - \gamma \Delta w_{tt} + \Delta^2 w + \alpha \Delta \theta = 0 & \text{in } \Omega \times \mathbb{R}^+, \\ \beta \theta_t - \eta \Delta \theta + \sigma \theta - \alpha \Delta w_t = 0 & \text{in } \Omega \times \mathbb{R}^+ \end{cases}$$
 (2.5.1)

where  $\Omega$  is a bounded region in  $\mathbb{R}^2$  with smooth boundary  $\Gamma = \Gamma_0 \cup \Gamma_1 \cup \Gamma_2$  and  $\Gamma_0 \cup \Gamma_1 \neq \emptyset$ ,  $\bar{\Gamma}_0 \cap \bar{\Gamma}_1 \cap \bar{\Gamma}_2 = \emptyset$ ; w represents the vertical deflection, and  $\theta$  represents the relative temperature about the stress free state  $\theta = 0$ ;  $\alpha, \beta, \eta, \sigma > 0, \gamma \geq 0$  are given constants. The boundary conditions considered for system (2.5.1) are often the following:

(i) the structural boundary conditions

$$w = \frac{\partial w}{\partial \nu} = 0$$
 on  $\Gamma_0$  (clamped edge), (2.5.2)

$$w = \Delta w + (1 - \mu)B_1w + \alpha\theta = 0$$
 on  $\Gamma_1$  (simply supported edge), (2.5.3)

$$\begin{cases} \Delta w + (1 - \mu)B_1w + \alpha\theta = 0, \\ \frac{\partial \Delta w}{\partial \nu} + (1 - \mu)\frac{\partial B_2w}{\partial \tau} - \gamma \frac{\partial w_{tt}}{\partial \nu} + \alpha \frac{\partial \theta}{\partial \nu} = 0 \end{cases}$$
 on  $\Gamma_2$  (free edge), (2.5.4)

where  $\nu = (\nu_1, \nu_2)$  is the unit outward normal vector, and  $\tau = (-\nu_2, \nu_1)$  is a unit tangent vector to  $\Gamma$ ;  $\mu$  is the Poisson ratio with  $0 < \mu < \frac{1}{2}$ ;  $B_1$  and  $B_2$  are the boundary operators defined by

$$B_1 w = 2\nu_1 \nu_2 w_{xy} - \nu_1^2 w_{yy} - \nu_2^2 w_{xx}, \qquad (2.5.5)$$

$$B_2 w = (\nu_1^2 - \nu_2^2) w_{xy} + \nu_1 \nu_2 (w_{xx} - w_{yy}), \qquad (2.5.6)$$

(ii) the temperature boundary condition

$$\lambda_1 \eta \frac{\partial \theta}{\partial \nu} + \lambda_2 \theta = 0 \quad \text{on} \quad \Gamma$$
 (2.5.7)

with  $\lambda_1, \lambda_2 \geq 0, \lambda_1 + \lambda_2 \neq 0$ .  $\lambda_1 = 0$  corresponds to zero temperature;  $\lambda_2 = 0$  corresponds to zero flux;  $\lambda_1, \lambda_2 \neq 0$  corresponds to the Newton's cooling law.

In this section we will prove that the corresponding semigroup to (2.5.1) with  $\gamma > 0$  subject to the boundary conditions (2.5.2) and (2.5.3) (i.e.,  $\Gamma_2 = \emptyset$ ), (2.5.7) is exponentially stable. We will also prove that the corresponding semigroup to (2.5.1) with  $\gamma = 0$  subject to the boundary conditions (2.5.2)–(2.5.4) (i.e.,  $\Gamma_2 \neq \emptyset$  is allowed) and (2.5.7) is not only exponentially stable, but also analytic.

Let us first recall some related works in the literature. As far as the exponential stability is concerned, Lagnese in his book (Lagnese [3] published in 1989) proved that the semigroup associated with the thermoelastic Kirchhoff plate equations is exponetially stable provided that there are additional dissipation terms acting on the boundary. He thought, as he wrote in his book that for higher dimensional linear thermoelastic systems, including the system for linear thermoelastic plates, "it seems unlikely" that the associated semigroup will be expoentially stable "unless additional dissipative mechanisms (such as boundary damping) are included" (p. 154). It is certainly true for the three-dimensional thermoelastic system. However, as far as the two-dimensional thermoelastic Kirchhoff plate equations are concerned, the situation is different from what he expected. Actually, the case  $\gamma = 0$  and  $\gamma > 0$  corresponds to very different dynamics ("parabolic" vs. "hyperbolic" in nature). It is now clear that when  $\gamma = 0$ , the semigroup associated with thermoelastic equation (2.5.1) is not only exponentially stable, but also analytic. However, in the case  $\gamma > 0$ , the semigroup is only exponentially stable, neither compact nor differentiable.

When  $\gamma=0$ , i.e., the rotational force is neglected in the plate equation (2.5.1), Kim [1] in 1992 considered the problem with the clamped edge and zero temperature boundary conditions and proved that the corresponding semigroup is exponentially stable. Rivera & Racke [1] in 1995 considered the problem with boundary conditions  $w=\Delta w=\theta=0$ , and essentially proved the exponential stability. Liu & Zheng [5], published in 1997, proved the exponential stability for the problem with the boundary clamped on  $\Gamma_0$ , simply supported on  $\Gamma_1$  (with  $\Gamma_0 \cup \Gamma_1 = \Gamma, \bar{\Gamma}_1 \cap \bar{\Gamma}_1 = \emptyset$ ), and the Newton's cooling law temperature boundary condition (2.5.7), essentially using 44

the method described in this book. However, the problem with free edge boundary condition was left open in their papers. The results in Liu & Zheng [5] were reproved in Avalos & Lasiecka [1] by a different method. Recently, Lasiecka & Triggiani [2]–[5] obtained the results on exponential stability as well as analyticity of the corresponding semigroup associated with (2.5.1) subject to all boundary conditions mentioned above, even including the free edge boundary condition (2.5.4). Their appoarch is very different from the systematic method described in this book.

As far as analyticity is concerned, we notice that in the present situation once analyticity is established, exponential stability can be obtained by excluding the possibility that the generator of the  $C_0$ -semigroup of contractions has spectrum on the imaginary axis. In addition to the very recent works by Lasiecka & Triggiani mentioned previously, we should also refer to some earlier works in this direction. We refer to Russell [2] for the problem with the boundary conditions  $w = \Delta w = \theta = 0$ . We also refer to Liu & Renardy [1] for the result on the problem with the clamped edge and zero temperature boundary conditions and Liu & Liu [2] for the problem with boundary conditions (2.5.2) and (2.5.3) and the Dirichlet boundary condition for temperature  $\theta$ . In Liu & Yong [1], the contradiction argument for proving exponential stability was extended to studying analyticity and other semigroup properties.

When  $\gamma > 0$ , i.e., the rotational force is also taken into consideration, the first result on exponential stability was given in Avalos & Lasiecka [1] for the problem with boundary conditions (2.5.2), (2.5.3) and (2.5.7) (i.e.,  $\Gamma_2 = \emptyset$ ). When  $\Gamma_2 = \emptyset$  and the temperature satisfies the Dirichlet boundary condition, the exponential stability was proved in Liu & Liu [2]. Recently, Avalos & Lasiecka [2] succeeded in proving the exponential stability for the problem with free edge boundary condition (2.5.4) (i.e.,  $\Gamma_2 \neq \emptyset$ ) using a sharp trace theorem given in Tataru [1]. As far as anylycity is concerned for the case  $\gamma > 0$ , as Lasiecka & Triggiani [3], [6] and Chang & Triggaini [1] recently pointed out, the associated linear semigroup is not analytic, even neither compact nor differentiable.

In what follows we first consider the linear thermoelastic Kirchhoff plate equation (2.5.1) subject to the following initial condition:

$$w|_{t=0} = w_0(x,y), \quad w_t|_{t=0} = w_1(x,y), \quad \theta|_{t=0} = \theta_0(x,y)$$
 (2.5.8)

and the boundary conditions (2.5.2), (2.5.3), and (2.5.7) (i.e.,  $\Gamma_2 = \emptyset$ ). The presentation here essentially follows the line of argumentation in Liu & Liu [2]. Let us first convert this problem into a variational evolution equation. For complex functions u, v defined on  $\Omega$ , we define the following Sobolev spaces and the associated bilinear forms:

$$\begin{split} V_1 &= \left\{ u \in H^2(\Omega) \mid u = 0 \text{ on } \Gamma, \ \frac{\partial u}{\partial \nu} = 0 \text{ on } \Gamma_0 \right\}, \\ a_1(u,v) &= \int_{\Omega} [u_{xx}\bar{v}_{xx} + u_{yy}\bar{v}_{yy} + \mu(u_{xx}\bar{v}_{yy} + u_{yy}\bar{v}_{xx}) \\ &+ 2(1-\mu)u_{xy}\bar{v}_{xy}]dxdy, \quad \forall \ u,v \in V_1; \end{split}$$

$$egin{array}{lcl} H_1 &=& H_0^1(\Omega), \\ c_1(u,v) &=& \int_\Omega (\gamma 
abla u 
abla ar v + uar v) dx dy, & orall & u,v \in H_1; \end{array}$$

$$\begin{array}{rcl} V_2 & = & H^1(\Omega), \\ \\ a_2(u,v) & = & \int_{\Omega} (\eta \nabla u \nabla \bar{v} + \sigma u \bar{v}) dx dy + \int_{\Gamma} \lambda u \bar{v} d\Gamma, & \forall \ u,v \in V_2; \end{array}$$

$$egin{array}{lcl} H_2 &=& L^2_eta(\Omega), \ c_2(u,v) &=& \int_\Omega eta u ar{v} dx dy, & orall & u,v \in H_2. \end{array}$$

It is clear that  $V_i$ ,  $H_i$  (i=1,2) are Hilbert spaces with the corresponding inner products  $a_i$ ,  $c_i$  (i=1,2), and  $V_i$ , respectively are continuously and densely imbedded into  $H_i$  (i=1,2). Furthermore, the imbedding operators are compact. By the results in Section 1.4.5 of Chapter 1, there exist self-adjoint positive definite operators  $A_i$  in  $H_i$  (i=1,2), respectively such that

$$\mathcal{D}(A_i^{\frac{1}{2}}) = V_i, \quad a_i(u, v) = c_i(A_i^{\frac{1}{2}}u, A_i^{\frac{1}{2}}v), \quad \forall \ u, v \in V_j, \quad j = 1, 2.$$
 (2.5.9)

To motivate the abstract formulation of our problem, suppose that  $\{w, \theta\}$  is a regular solution of our problem (2.5.1) and (2.5.8)-(2.5.11). The pair  $\{w, \theta\}$  is then a solution of the variational equation

$$c_{1}(w_{tt}(t), \hat{w}) + c_{2}(\theta_{t}(t), \hat{\theta}) + a_{1}(w(t), \hat{w}) + a_{2}(\theta(t), \hat{\theta}) + c_{2}(\theta(t), B\hat{w}) - c_{2}(Bw_{t}(t), \hat{\theta}) = 0, \quad \forall \hat{w} \in V_{1}, \ \hat{\theta} \in V_{2}, \ t > 0$$
 (2.5.10)

where the operator B from  $H_1$  to  $H_2$  is defined as

$$Bu = \frac{\alpha}{\beta} \Delta u, \quad \forall u \in \mathcal{D}(B) = V_1.$$
 (2.5.11)

Let

$$w_t = v \quad in \quad V_1, \quad \forall t > 0, \tag{2.5.12}$$

and take  $\hat{\theta} = 0$  in (2.5.10). Then we obtain

$$c_1(v_t(t), \hat{w}) + a_1(w(t), \hat{w}) + c_2(\theta(t), B\hat{w}) = 0, \quad \forall \hat{w} \in V_1, \ t > 0.$$
 (2.5.13)

Let

$$\tilde{w} = A_1^{\frac{1}{2}} \hat{w}. \tag{2.5.14}$$

Then  $\tilde{w} \in H_1$  and we can rewrite  $c_2(\theta(t), B\hat{w})$  as  $c_2(\theta(t), BA_1^{-\frac{1}{2}}\tilde{w})$ . It is clear that the operator  $BA_1^{-\frac{1}{2}}$  is a linear continuous operator from  $H_1$  to  $H_2$ . Thus by the definition of adjoint operator in functional analysis,  $c_2(\theta(t), BA_1^{-\frac{1}{2}}\tilde{w})$  can be rewritten as  $c_1((BA_1^{-\frac{1}{2}})^*\theta(t), \tilde{w}) = c_1((BA_1^{-\frac{1}{2}})^*\theta(t), A_1^{\frac{1}{2}}\hat{w})' = c_1(A_1^{\frac{1}{2}}(BA_1^{-\frac{1}{2}})^*\theta(t), \hat{w})$ . Since  $V_1$  is dense in  $H_1$ , it turns out from (2.5.13) that

$$v_t = -A_1 w - A_1^{\frac{1}{2}} (B A_1^{-\frac{1}{2}})^* \theta \quad in \ H_1, \ \forall t > 0.$$
 (2.5.15)

If we take  $\hat{w} = 0$  in (2.5.10), since  $V_2$  is dense in  $H_2$ , we obtain that

$$\theta_t(t) = Bv - A_2\theta \quad in \ H_2, \ \forall t > 0.$$
 (2.5.16)

Let  $z = (w, v, \theta)^T$  and  $\mathcal{H} = V_1 \times H_1 \times H_2$  with the corresponding inner product. Then combining (2.5.13), (2.5.15) and (2.5.16) yields the following first-order evolution equation in  $\mathcal{H}$ :

$$\frac{dz}{dt} = Az \tag{2.5.17}$$

with

$$\mathcal{D}(\mathcal{A}) = \{ z = (w, v, \theta)^T \in \mathcal{H} \mid v \in V_1, \theta \in \mathcal{D}(A_2), A_1^{\frac{1}{2}}w + (BA_1^{-\frac{1}{2}})^*\theta \in V_1 \}, \quad (2.5.18)$$

and

$$Az = \begin{pmatrix} v \\ -A_1^{\frac{1}{2}} [A_1^{\frac{1}{2}} w + (BA_1^{-\frac{1}{2}})^* \theta] \\ Bv - A_2 \theta \end{pmatrix}, \qquad (2.5.19)$$

where  $(BA_1^{-\frac{1}{2}})^* \in \mathcal{L}(H_2, H_1)$ . Thus this first-order evolution equation can be considered as the weak formulation of our problem (2.5.1) and (2.5.8)–(2.5.11).

**Theorem 2.5.1** A generates a  $C_0$ -semigroup,  $S(t) = e^{At}$ , of contractions on  $\mathcal{H}$ . Moreover,  $0 \in \rho(A)$  with  $\rho(A)$  being the resolvent set of A.

**Proof** For any  $F = (f, g, h)^T \in \mathcal{H}$ , the equation Az = F has an unique solution  $z = (w, v, \theta)^T$ :

$$\begin{cases} v = f, \\ \theta = A_2^{-1}(Bf - h), \\ w = -A_1^{-1}g - A_1^{-\frac{1}{2}}(BA_1^{-\frac{1}{2}})^*A_2^{-1}(Bf - h). \end{cases}$$
 (2.5.20)

It is easy to verify directly that  $z \in \mathcal{D}(A)$  and

$$||z||_{\mathcal{H}} \le K||(f, g, h)^T||_{\mathcal{H}}$$
 (2.5.21)

with some K > 0 independent of F. Therefore,  $\mathcal{A}$  is closed and  $0 \in \rho(\mathcal{A})$ . The dissipativeness of  $\mathcal{A}$  can be seen in the following calculation:

$$\operatorname{Re}\langle Az, z \rangle_{\mathcal{H}} = \operatorname{Re}[a_{1}(v, w) - a_{1}(w, v) - c_{1}((BA_{1}^{-\frac{1}{2}})^{*}\theta, A_{1}^{\frac{1}{2}}v) - a_{2}(\theta, \theta) + c_{2}(Bv, \theta)]$$

$$= -a_{2}(\theta, \theta) + \operatorname{Re}[c_{2}(Bv, \theta) - c_{2}(\theta, Bv)]$$

$$= -a_{2}(\theta, \theta) < 0. \tag{2.5.22}$$

Thus, the conclusion of this theorem immediately follows from Theorem 1.2.4 in Chapter 1.  $\Box$ 

Corollary 2.5.1 Let  $(w(t), v(t), \theta(t))^T = e^{At}z_0$ . If  $z_0 \in \mathcal{D}(A)$ , then

$$\begin{cases} w \in C^{2}([0,\infty); H_{1}) \cap C^{1}([0,\infty); V_{1}), \\ \theta \in C^{1}([0,\infty); H_{2}) \cap C([0,\infty); \mathcal{D}(A_{2})) \end{cases}$$
 (2.5.23)

and they satisfy the variational equation (2.5.10).

If  $z_0 = (w_0, v_0, \theta_0)^T \in \mathcal{H}$ , then

$$\begin{cases} w(\cdot) \in C^{1}([0,\infty); H_{1}) \cap C([0,\infty); V_{1}), \\ \theta(\cdot) \in C([0,\infty); H_{2}), \\ v(\cdot) = w_{t}(\cdot) \end{cases}$$
 (2.5.24)

and z is a mild solution to the first-order evolution equation (2.5.17). Moreover, using the dense argument as before, we can easily show that  $\theta$  also belongs to  $L^2([0,\infty),V_2)$  and  $w,\theta$  satisfy the following weak variational equation: for all  $\hat{w} \in V_1$ ,  $\hat{\theta} \in V_2$  and t > 0,

$$c_{1}(w_{t}(t), \hat{w}) - c_{1}(w_{1}, \hat{w}) + c_{2}(\theta(t), \hat{\theta}) - c_{2}(\theta_{0}, \hat{\theta}) - c_{2}(Bw(t), \hat{\theta}) + c_{2}(Bw_{0}, \hat{\theta}) + \int_{0}^{t} (a_{1}(w(\tau), \hat{w}) + a_{2}(\theta(\tau), \hat{\theta}) + c_{2}(\theta(\tau), B\hat{w}))d\tau = 0.$$

$$(2.5.25)$$

Concerning exponential stability, we have the following.

**Theorem 2.5.2** The semigroup S(t), generated by the operator A, is exponentially stable, i.e., there are two positive constants  $M, \alpha$  such that

$$||S(t)|| \le Me^{-\alpha t}.$$
 (2.5.26)

**Proof** We still use Theorem 1.3.2 to prove this theorem. The proof consists of several steps:

- (i) To prove that  $0 \in \rho(A)$ . This has been done in the previous theorem.
- (ii) If  $\sup\{\|(\boldsymbol{i}\beta I-\mathcal{A})^{-1}\| \mid |\beta| < \|\mathcal{A}^{-1}\|^{-1}\} = K < \infty$ , then by the contraction mapping theorem, the operator  $\boldsymbol{i}\beta I-\mathcal{A}=(\boldsymbol{i}\beta_0 I-\mathcal{A})(I+\boldsymbol{i}(\beta-\beta_0)(\boldsymbol{i}\beta_0 I-\mathcal{A})^{-1})$  with  $|\beta_0|<\|\mathcal{A}^{-1}\|^{-1}$  is invertible for  $|\beta-\beta_0|<\frac{1}{K}$ . It turns out that by choosing  $|\beta_0|$  as close to  $\|\mathcal{A}^{-1}\|^{-1}$  as we can, we conclude that  $\{\beta\mid |\beta|<\|\mathcal{A}^{-1}\|^{-1}+\frac{1}{K}\}\subset \rho(\mathcal{A})$

and  $\|(i\beta I - \mathcal{A})^{-1}\|$  is a continuous function of  $\beta$  in  $(-\|\mathcal{A}^{-1}\|^{-1} - \frac{1}{K}, \|\mathcal{A}^{-1}\|^{-1} + \frac{1}{K})$ . Thus it follows from the above argument that if (1.3.3) is not true, then there is  $\omega \in \mathbb{R}$  with  $\|\mathcal{A}^{-1}\|^{-1} \leq |\omega| < \infty$  such that  $\{i\beta \mid |\beta| < |\omega|\} \subset \rho(\mathcal{A})$  and  $\sup\{\|(i\beta - \mathcal{A})^{-1}\| \mid |\beta| < |\omega|\} = \infty$ . It turns out that there exists a sequence  $\beta_n \in \mathbb{R}$  with  $\beta_n \to \omega, |\beta_n| < |\omega|$  and a sequence of complex vector functions  $z_n \in \mathcal{D}(\mathcal{A})$  with  $\|z_n\|_{\mathcal{H}} = (\|w_n\|_{V_1}^2 + \|v_n\|_{H_1}^2 + \|\theta_n\|_{H_2}^2)^{\frac{1}{2}} = 1$  such that as  $n \to \infty$ ,

$$||(i\beta_n - \mathcal{A})z_n||_{\mathcal{H}} \to 0, \tag{2.5.27}$$

i.e.,

$$i\beta_n w_n - v_n \rightarrow 0 \quad \text{in } V_1,$$
 (2.5.28)

$$i\beta_n v_n + A_1^{\frac{1}{2}} y_n \rightarrow 0 \text{ in } H_1,$$
 (2.5.29)

$$i\beta_n\theta_n - Bv_n + A_2\theta_n \rightarrow 0 \text{ in } H_2$$
 (2.5.30)

where  $y_n \equiv A_1^{\frac{1}{2}} w_n + (BA_1^{-\frac{1}{2}})^* \theta_n \in \mathcal{D}(A_1^{\frac{1}{2}})$ . It follows from (2.5.27) that

$$\operatorname{Re}\langle (i\rho_n - \mathcal{A})z_n, z_n \rangle_{\mathcal{H}} = \|A_2^{\frac{1}{2}}\theta_n\|_{H_2}^2 \to 0.$$
 (2.5.31)

Therefore,  $\theta_n$  converges to zero in  $H_2$  and  $(BA_1^{-\frac{1}{2}})^*\theta_n$  converges to zero in  $H_1$ . We add up the inner product of (2.5.28) with  $v_n$  in  $H_1$  with the inner product of (2.5.29) with  $w_n$  in  $H_1$  to get

$$\|A_1^{\frac{1}{2}}w_n\|_{H_1}^2 - \|v_n\|_{H_1}^2 \to 0.$$
 (2.5.32)

This, combining with the fact that  $||z_n||_{\mathcal{H}} = 1$  and  $||\theta_n||_{H_2} \to 0$ , leads to

$$\lim_{n \to \infty} \|A_1^{\frac{1}{2}} u_n\|_{H_1}^2 = \lim_{n \to \infty} \|v_n\|_{H_1}^2 = \frac{1}{2}.$$
 (2.5.33)

Furthermore, by (2.5.29) we also have

$$\lim_{n \to \infty} \left\| \frac{A_1^{\frac{1}{2}} y_n}{\beta_n} \right\|_{H_*}^2 = \frac{1}{2}.$$
 (2.5.34)

Dividing (2.5.30) by  $\beta_n$ , from (2.5.31) we obtain

$$-\frac{Bv_n}{\beta_n} + \frac{A_2\theta_n}{\beta_n} \to 0 \quad \text{in } H_2. \tag{2.5.35}$$

Since  $B \in \mathcal{L}(V_1, H_2)$  and  $(BA_1^{-\frac{1}{2}})^* \in \mathcal{L}(H_2, H_1)$ , we have

$$BA_1^{-\frac{1}{2}}(BA_1^{-\frac{1}{2}})^* \in \mathcal{L}(H_2).$$
 (2.5.36)

Thus, it follows that

$$BA_1^{-\frac{1}{2}}(BA_1^{-\frac{1}{2}})^*\theta_n \to 0 \text{ in } H_2.$$
 (2.5.37)

Inserting the term  $BA_1^{-\frac{1}{2}}(BA_1^{-\frac{1}{2}})^*\theta_n$  into (2.5.35) and using (2.5.28) to replace  $\frac{v_n}{\beta_n}$  by  $iw_n$ , we obtain that

$$-iBA_1^{-\frac{1}{2}}[A_1^{\frac{1}{2}}w_n + (BA_1^{-\frac{1}{2}})^*\theta_n] + \frac{A_2\theta_n}{\beta_n} = \frac{A_2\theta_n}{\beta_n} - iBA_1^{-\frac{1}{2}}y_n \to 0 \text{ in } H_2. \quad (2.5.38)$$

Now we want to prove that  $A_2^{\frac{1}{2}}BA_1^{-1} \in \mathcal{L}(H_1, H_2)$ . By the definition of  $V_i$  and  $H_i$  (i = 1, 2), it amounts to proving that  $BA_1^{-1} \in \mathcal{L}(H_1, H^1)$ . By the definition of the operator B, it suffices to prove that  $\mathcal{D}(A_1) \in H^3(\Omega)$ .

Let  $w \in \mathcal{D}(A_1), u = A_1 w$ . Then we have

$$a_1(w,v) = c_1(u,v) = \int_{\Omega} (\gamma \nabla u \nabla \bar{v} + u \bar{v}) dx dy = \int_{\Omega} u (1 - \gamma \Delta) \bar{v} dx dy, \quad \forall v \in V_1. \quad (2.5.39)$$

Therefore, w is a solution of the following elliptic boundary value problem:

$$\begin{cases}
\Delta^2 w = (1 - \gamma \Delta)u \in H^{-1}, \\
w = \frac{\partial w}{\partial \nu} = 0, & \text{on } \Gamma_0, \\
w = \Delta u + (1 - \mu)B_1 w = 0, & \text{on } \Gamma_1.
\end{cases}$$
(2.5.40)

Since  $\bar{\Gamma}_0 \cap \bar{\Gamma}_1 = \emptyset$ , by the regularity results on the elliptic boundary value problems (see Lions & Magenes [1] or Chapter 1 in this book), we obtain that  $w \in H^3(\Omega)$ . This proves that  $A_2^{\frac{1}{2}}BA_1^{-1} \in \mathcal{L}(H_1, H_2)$ .

Thus, it follows from (2.5.31) and (2.5.34) that

$$\left(\frac{A_2\theta_n}{\beta_n}, BA_1^{-\frac{1}{2}}y_n\right)_{H_2} = \left(A_2^{\frac{1}{2}}\theta_n, A_2^{\frac{1}{2}}BA_1^{-1}\frac{A_1^{\frac{1}{2}}y_n}{\beta_n}\right)_{H_2} \to 0.$$
(2.5.41)

By (2.5.38) and (2.5.41), we have

$$BA_1^{-\frac{1}{2}}y_n \to 0 \text{ in } H_2,$$
 (2.5.42)

$$Bw_n \to 0 \quad \text{in } H_2. \tag{2.5.43}$$

Again by the standard estimates in the elliptic PDE theory, as can be seen from Chapter 1 or from the book by Lions & Magenes [1], we have

$$||w||_{V_1} \le C||\Delta w||_{L^2} \le C||Bw||_{H_2} \to 0 \tag{2.5.44}$$

which contradicts (2.5.34). Thus, (1.3.3) is proved.

(iii) The proof for (1.3.4) is exactly the same as in (ii).

Thus the proof is complete.

Remark 2.5.1 As mentioned in Lasiecka & Triggiani [2]-[4], the semigroup considered in the above is not analytic.

In what follows we consider the equations (2.5.1) with  $\gamma = 0$  subject to the boundary conditions (2.5.2)–(2.5.4) (i.e.,  $\Gamma_2 \neq \emptyset$  is allowed), (2.5.7) and the initial conditions (2.5.8).

Let

$$H^{2}_{\Gamma_{0}}(\Omega) = \{ w \mid w \in H^{2}(\Omega), w \mid_{\Gamma_{0}} = \frac{\partial w}{\partial \nu} \mid_{\Gamma_{0}} = 0 \},$$
 (2.5.45)

$$H^{1}_{\Gamma_{1}}(\Omega) = \{ w \mid w \in H^{1}(\Omega), w \mid_{\Gamma_{1}} = 0 \}, \tag{2.5.46}$$

$$a(w,\tilde{w}) = \int_{\Omega} \biggl\{ \frac{\partial^2 w}{\partial x^2} \frac{\partial^2 \tilde{w}}{\partial x^2} + \frac{\partial^2 w}{\partial y^2} \frac{\partial^2 \tilde{w}}{\partial y^2} + \mu \frac{\partial^2 w}{\partial x^2} \frac{\partial^2 \tilde{w}}{\partial y^2} + \mu \frac{\partial^2 \tilde{w}}{\partial x^2} \frac{\partial^2 w}{\partial y^2} + 2(1-\mu) \frac{\partial^2 w}{\partial x \partial y} \frac{\partial^2 \tilde{w}}{\partial x \partial y} \biggr\} d\Omega \qquad (2.5.47)$$

and

$$\mathcal{H} = H^2_{\Gamma_0}(\Omega) \cap H^1_{\Gamma_1}(\Omega) \times L^2(\Omega) \times L^2_{\theta}(\Omega)$$
 (2.5.48)

equipped with the inner product: for any  $z=(w,v,\theta)^T, \tilde{z}=(\tilde{w},\tilde{v},\tilde{\theta})^T\in\mathcal{H},$ 

$$\langle z, \tilde{z} \rangle_{\mathcal{H}} = a(w, \tilde{w}) + (v, \tilde{v}) + \beta(\theta, \tilde{\theta}). \tag{2.5.49}$$

If we denote  $w_t$  by v, then the initial boundary value problem (2.5.1)–(2.5.8) can be reduced to the initial value problem for a first-order evolution equation:

$$\begin{cases} \frac{dz(t)}{dt} = \mathcal{A}z(t), \\ z(0) = z_0 = (w_0, w_1, \theta_0)^T \end{cases}$$
 (2.5.50)

with

$$\mathcal{A} = \begin{bmatrix} 0 & I & 0 \\ -\Delta^2 & 0 & -\alpha\Delta \\ 0 & \frac{\alpha}{\beta}\Delta & \frac{1}{\beta}(-\sigma I + \eta\Delta) \end{bmatrix}, \tag{2.5.51}$$

and

$$\mathcal{D}(\mathcal{A}) = \left\{ z \in H \middle| \begin{array}{l} w \in H^4(\Omega) \cap H^2_{\Gamma_0}(\Omega) \cap H^1_{\Gamma_1}(\Omega), \ v \in H^2_{\Gamma_0}(\Omega) \cap H^1_{\Gamma_1}(\Omega), \\ \theta \in H^2(\Omega), \ w, \ \theta \ \text{ satisfy } (2.5.3) – (2.5.8) \end{array} \right\}. \tag{2.5.52}$$

We recall the following Green's formula (see Lagnese [3]): for any  $w \in H^4$ ,  $\tilde{w} \in H^2$ ,

$$\int_{\Omega} (\Delta^{2} w) \tilde{w} d\Omega$$

$$= a(w; \tilde{w}) + \int_{\Gamma} \left\{ \left[ \frac{\partial \Delta w}{\partial \nu} + (1 - \mu) \frac{\partial B_{2} w}{\partial \tau} \right] \tilde{w} - \left[ \Delta w + (1 - \mu) B_{1} w \right] \frac{\partial \tilde{w}}{\partial \nu} \right\} d\Gamma.$$
(2.5.53)

Then we have the following theorem.

**Theorem 2.5.3** The operator  $\mathcal{A}$  defined by (2.5.51) and (2.5.52) is the infinitesimal generator of a  $C_0$ -semigroup S(t) of contractions on  $\mathcal{H} = H^2_{\Gamma_0}(\Omega) \cap H^1_{\Gamma_1}(\Omega) \times L^2(\Omega) \times L^2(\Omega)$ .

**Proof** It is clear that  $\mathcal{D}(\mathcal{A})$  is dense in  $\mathcal{H}$ . For any  $z = (w, v, \theta)^T \in \mathcal{D}(\mathcal{A})$ ,

$$Re\langle Az, z \rangle_{\mathcal{H}}$$

$$= Re\left\{a(v, w) + \left(-\Delta^{2}w - \alpha\Delta\theta, v\right) + (\alpha\Delta v - \sigma\theta + \eta\Delta\theta, \theta)\right\}$$

$$= Re\left\{a(v, w) - a(w, v) - \alpha(\theta, \Delta v) + (\alpha\Delta v - \sigma\theta + \eta\Delta\theta, \theta) - \int_{\Gamma} \left\{\left[\frac{\partial\Delta w}{\partial\nu} + (1-\mu)\frac{\partial B_{2}w}{\partial\tau} - \alpha\frac{\partial\theta}{\partial\nu}\right]\bar{v} - [\Delta w + (1-\mu)B_{1}w - \alpha\theta]\frac{\partial\bar{v}}{\partial\nu}\right\}d\Gamma\right\}$$

$$= -\sigma\|\theta\|^{2} + \eta(\Delta\theta, \theta)$$

$$= -\sigma\|\theta\|^{2} - \eta\|\nabla\theta\|^{2} - \lambda\eta\int_{\Gamma}|\theta|^{2}d\Gamma \leq 0$$
(2.5.54)

where we have used Green's formula (2.5.53) and the boundary conditions on w and  $\theta$ . Notice that when  $\lambda_1 = 0$  or  $\lambda_2 = 0$  in the temperature boundary condition (2.5.7), the boundary integral term in (2.5.54) will not appear; when  $\lambda > 0, \lambda_2 > 0$ , the boundary integral term in (2.5.54) does appear and  $\lambda = \frac{\lambda_2}{\lambda_1}$ . Thus,  $\mathcal{A}$  is dissipative. It remains to show that  $0 \in \rho(\mathcal{A})$ , i.e, for any  $F = (f, g, h)^T \in \mathcal{H}$ , we want to show that the equation

$$-Az = F \tag{2.5.55}$$

has a unique solution  $z \in \mathcal{D}(A)$ . This is equivalent to finding  $w \in H^4$  and  $\theta \in H^2$  satisfying

$$\Delta^2 w + \alpha \Delta \theta = g \in L^2(\Omega), \tag{2.5.56}$$

$$\sigma\theta - \eta\Delta\theta = h - \alpha\Delta f \in L^2(\Omega)$$
 (2.5.57)

and the boundary conditions (2.5.2)–(2.5.7). It follows from the standard results on the linear elliptic PDE theory that the elliptic boundary value problem (2.5.57), (2.5.7) has a unique solution  $\theta \in H^2$ . Furthermore, the elliptic boundary value problem

$$\begin{cases} \Delta^{2}w = g - \alpha \Delta \theta \in L^{2}(\Omega), \\ w = \frac{\partial w}{\partial \nu} = 0 \quad \text{on } \Gamma_{0}, \\ w = 0, \quad \Delta w + (1 - \mu)B_{1}w = -\alpha \theta \in H^{3/2}(\Gamma_{1}) \quad \text{on } \Gamma_{1}, \\ \Delta w + (1 - \mu)B_{1}w = -\alpha \theta \in H^{3/2}(\Gamma_{2}) \quad \text{on } \Gamma_{2}, \\ \frac{\partial \Delta w}{\partial \nu} + (1 - \mu)\frac{\partial B_{2}w}{\partial \nu} = -\alpha \frac{\partial \theta}{\partial \nu} \in H^{1/2}(\Gamma_{2}) \quad \text{on } \Gamma_{2} \end{cases}$$

$$(2.5.58)$$

has a unique solution  $w \in H^4 \cap H^2_{\Gamma_0} \cap H^1_{\Gamma_1}$ .

It is easy to see that the norm of z in  $H^4 \times H^2 \times H^2$  is bounded by  $K||F||_{\mathcal{H}}$  for some K > 0. Thus,  $(-\mathcal{A})^{-1} \in \mathcal{L}(\mathcal{H})$ . Moreover,  $\mathcal{A}^{-1}$  is compact in  $\mathcal{H}$ . Since  $\mathcal{A}$  is dissipative, by Theorem 1.3.4, we can conclude that  $\mathcal{A}$  generates a  $C_0$ -semigroup S(t) of contractions on  $\mathcal{H}$ .

Furthermore, we have the following.

**Theorem 2.5.4** The semigroup S(t), generated by A, is analytic and exponentially stable.

**Proof** In the present situation we only need to prove the analyticity, and the exponential stability follows from the analyticity. It amounts to verifying the conditions in 54

Theorem 1.3.3.

(i) We first verify the condition (1.3.7) in Theorem 1.3.3.

Since we have already proved in the last theorem that  $0 \in \rho(\mathcal{A})$  and  $\mathcal{A}^{-1}$  is compact in  $\mathcal{H}$ , it turns out that the spectrum of  $\mathcal{A}$  consists of its eigenvalues. Thus, if (1.3.7) is not true, then there is a real number  $\beta \neq 0$  such that  $i\beta$  is an eigenvalue of  $\mathcal{A}$ . It turns out that there is a complex vector function  $z = (w, v, \theta)^T \in \mathcal{D}(\mathcal{A})$  with unit norm in  $\mathcal{H}$  such that

$$(\mathbf{i}\beta I - \mathcal{A})z = 0, (2.5.59)$$

i.e.,

$$i\beta w - v = 0 \qquad \text{in} \qquad H^2, \tag{2.5.60}$$

$$i\beta v + \Delta^2 w + \Delta\theta = 0 \quad \text{in} \quad L^2, \tag{2.5.61}$$

$$i\beta\theta - \alpha\Delta v - \eta\Delta\theta + \sigma\theta = 0$$
 in  $L^2$ . (2.5.62)

Taking the real part of the inner product of (2.5.59) with z in  $\mathcal{H}$  and applying (2.5.54) yields

$$\sigma \|\theta\|^2 + \eta \|\nabla \theta\|^2 + \eta \lambda \int_{\Gamma} |\theta|^2 d\Gamma = 0.$$
 (2.5.63)

As mentioned before, when  $\lambda_1 = 0$  or  $\lambda_2 = 0$ , the boundary integral term in (2.5.63) does not appear. Anyway, we can deduce from (2.5.63) that

$$\theta = 0 \quad \text{in} \quad \Omega. \tag{2.5.64}$$

Then it follows from (2.5.62) that

$$\Delta v = 0 \quad \text{in } \Omega. \tag{2.5.65}$$

It turns out from (2.5.60) that  $\Delta w = 0$  in  $\Omega$ . Therefore, we also have that  $\Delta^2 w = 0$  in  $\Omega$ . Owing to (2.5.64), we can deduce from (2.5.61) that v = 0, and by (2.5.60), w = 0 in  $\Omega$ , a contradiction. Thus, (1.3.7) is proved.

(ii) Next, we verify (1.3.8). If (1.3.8) is not true, then there exists a sequence  $\beta_n \in \mathbb{R}$  with  $\beta_n \to \infty$  (without loss of generality, we always assume that  $\beta > 0$ ) and a sequence

of complex vector functions  $z_n = (w_n, v_n, \theta_n)^T \in \mathcal{D}(\mathcal{A})$  with unit norm in  $\mathcal{H}$  such that as  $n \to \infty$ ,

$$(iI - \frac{1}{\beta_n} \mathcal{A}) z_n \to 0 \quad \text{in } \mathcal{H},$$
 (2.5.66)

i.e.,

$$iw_n - \frac{1}{\beta}v_n \to 0$$
 in  $H^2$ , (2.5.67)

$$iv_n + \frac{1}{\beta_n} \Delta^2 w_n + \frac{\alpha}{\beta_n} \Delta \theta_n \to 0 \quad \text{in} \quad L^2,$$
 (2.5.68)

$$i\theta_n - \frac{\alpha}{\beta_n} \Delta v_n - \frac{\eta}{\beta_n} \Delta \theta_n + \frac{\sigma}{\beta_n} \theta_n \to 0$$
 in  $L^2$ . (2.5.69)

Taking the real part of the inner product of  $(iI - \frac{1}{\beta_n}A)z_n$  with  $z_n$  in  $\mathcal{H}$  and applying (2.5.54) yields

$$\frac{\sigma}{\beta_n} \|\theta_n\|^2 + \frac{\eta}{\beta_n} \|\nabla \theta_n\|^2 + \frac{\eta \lambda}{\beta_n} \int_{\Gamma} |\theta_n|^2 d\Gamma \to 0.$$
 (2.5.70)

As mentioned before, when  $\lambda_1 = 0$  or  $\lambda_2 = 0$  in the temperature boundary condition (2.5.7), the boundary term in (2.5.70) will not appear. Anyway, it follows from (2.5.70) that

$$\frac{1}{\beta_n^{1/2}} \|\theta_n\|_{H^1} \to 0. \tag{2.5.71}$$

In what follows we first show that  $\|\theta_n\|^2 \to 0$ . Taking the inner product of (2.5.69) with  $\theta_n$  in  $L^2$  leads to

$$i\|\theta_n\|^2 - \frac{\alpha}{\beta_n}(\Delta v_n, \theta_n) \to 0.$$
 (2.5.72)

From (2.5.67) we can deduce that  $\frac{1}{\beta_n}\|v_n\|_{H^2}$  is uniformly bounded with respect to n. Then by the Gagliardo-Nirenberg interpolation inequality,  $\frac{1}{\beta_n^{1/2}}\|v_n\|_{H^1}$  is also uniformly bounded. This together with (2.5.71) yields

$$\frac{1}{\beta_n}(\nabla v_n, \nabla \theta_n) \to 0. \tag{2.5.73}$$

Furthermore, by Theorem 1.4.4 in Chapter 1, we have

$$\left\| \frac{\partial v_n}{\partial \nu} \right\|_{L^2(\Gamma)} \le C \left\| v_n \right\|_{H^2(\Omega)}^{1/2} \left\| v_n \right\|_{H^1(\Omega)}^{1/2}, \tag{2.5.74}$$

$$\|\theta_n\|_{L^2(\Gamma)} \le C \|\theta_n\|_{H^1(\Omega)}^{1/2} \|\theta_n\|_{L^2(\Omega)}^{1/2} \tag{2.5.75}$$

with C being a positive constant. Then it turns out that

$$\left| \frac{1}{\beta_{n}} \int_{\Gamma} \frac{\partial v_{n}}{\partial \nu} \bar{\theta}_{n} d\Gamma \right| \\
\leq \frac{1}{\beta_{n}} \left\| \frac{\partial v_{n}}{\partial \nu} \right\|_{L^{2}(\Gamma)} \|\theta_{n}\|_{L^{2}(\Gamma)} \\
\leq C \frac{\|v_{n}\|_{H^{2}(\Omega)}^{1/2}}{\beta_{n}^{1/2}} \frac{\|v_{n}\|_{H^{1}(\Omega)}^{1/2}}{\beta_{n}^{1/4}} \frac{\|\theta_{n}\|_{H^{1}(\Omega)}^{1/2}}{\beta_{n}^{1/4}} \|\theta_{n}\|^{\frac{1}{2}} \\
\leq \frac{C}{\beta_{n}^{1/4}} \|\theta_{n}\|_{H^{1}(\Omega)}^{1/2} \to 0.$$
(2.5.76)

Therefore, it follows from (2.5.76) and (2.5.73) that

$$\frac{1}{\beta_n}(\Delta v_n, \theta_n) = \frac{1}{\beta_n} \int_{\Gamma} \frac{\partial v_n}{\partial \nu} \bar{\theta}_n d\Gamma - \frac{1}{\beta_n} (\nabla v_n, \nabla \theta_n) \to 0. \tag{2.5.77}$$

Combining it with (2.5.72) yields

$$\|\theta_n\| \to 0. \tag{2.5.78}$$

In what follows we are going to prove that  $a(w_n, w_n) + ||v_n||^2 \to 0$  which will yield the desired contradiction.

Taking the complex conjugate of the inner product of (2.5.67) with  $w_n$  in  $H^2(\Omega)$ , then adding it to the inner product of (2.5.68) with  $v_n$  in  $L^2(\Omega)$  and using Green's formula (2.5.59), we obtain

$$i(-a(w_n, w_n) + ||v_n||^2) + \frac{\alpha}{\beta_n}(\theta_n, \Delta v_n) \to 0.$$
 (2.5.79)

By (2.5.77), the last term in (2.5.79) converges to zero. Hence,

$$a(w_n, w_n) - ||v_n||^2 \to 0.$$
 (2.5.80)

It follows from (2.5.69) and (2.5.78) that

$$-\frac{\alpha}{\beta_n} \Delta v_n - \frac{\eta}{\beta_n} \Delta \theta_n \to 0 \text{ in } L^2.$$
 (2.5.81)

We can deduce from (2.5.67) that  $\frac{1}{\beta_n} \|\Delta v_n\|$  is uniformly bounded. Then it follows from (2.5.81) that  $\frac{1}{\beta_n} \|\Delta \theta_n\|$  is bounded. This further implies the uniform boundedness of

 $\frac{1}{\beta_n} \|\Delta^2 w_n\|$ , due to (2.5.68). Notice that  $w_n$  satisfies the boundary conditions (2.5.2)–(2.5.4). Thus, the standard estimates for the elliptic boundary value problems and the trace theorem (see Lions & Magenes [1] or Chapter 1 of this book) lead to

$$||w_{n}||_{H^{4}} \leq C \left( ||\Delta^{2}w_{n}|| + ||\alpha\theta_{n}||_{H^{3/2}(\Gamma)} \right)$$

$$\leq C \left( ||\Delta^{2}w_{n}|| + ||\theta_{n}||_{H^{2}} \right)$$

$$\leq C \left( ||\Delta^{2}w_{n}|| + ||\Delta\theta_{n}|| + ||\theta_{n}||_{H^{1}} \right). \tag{2.5.82}$$

Therefore,  $\frac{1}{\beta_n} \|w_n\|_{H^4}$  is uniformly bounded. Since  $\|w_n\|_{H^2} \leq 1$ , by the Gagliardo-Nirenberg inequality,  $\frac{1}{\beta_n^{1/2}} \|w_n\|_{H^3}$  is also uniformly bounded. Combining (2.5.67) with (2.5.81) yields

$$i\alpha\Delta w_n - \frac{\eta}{\beta_n}\Delta\theta_n \to 0 \quad \text{in } L^2.$$
 (2.5.83)

Therefore,

$$i\alpha \|\Delta w_n\|^2 - \frac{\eta}{\beta_n}(\Delta \theta_n, \Delta w_n) \to 0.$$
 (2.5.84)

Using integration by parts, the Cauchy-Schwarz inequality and Theorem 1.4.4, we obtain that

$$\left| \frac{1}{\beta_{n}} (\Delta \theta_{n}, \Delta w_{n}) \right| \leq \frac{1}{\beta_{n}} \left\| \frac{\partial \theta_{n}}{\partial \nu} \right\|_{L^{2}(\Gamma)} \|\Delta w_{n}\|_{L^{2}(\Gamma)} + \frac{1}{\beta_{n}} \|\theta_{n}\|_{H^{1}} \|w_{n}\|_{H^{3}} \\
\leq C \frac{\|\theta_{n}\|_{H^{1}}^{1/2}}{\beta_{n}^{1/4}} \left( \frac{\|\theta_{n}\|_{H^{2}}^{1/2}}{\beta_{n}^{1/2}} \frac{\|w_{n}\|_{H^{3}}^{1/2}}{\beta_{n}^{1/4}} \|\Delta w_{n}\|^{\frac{1}{2}} + \frac{\|\theta_{n}\|_{H^{1}}^{1/2}}{\beta_{n}^{1/4}} \frac{\|w_{n}\|_{H^{3}}}{\beta_{n}^{1/2}} \right) \\
\leq C_{1} \frac{\|\theta_{n}\|_{H^{1}}^{1/2}}{\beta_{n}^{1/4}} \to 0. \tag{2.5.85}$$

This, together with (2.5.84), leads to

$$\|\Delta w_n\| \to 0. \tag{2.5.86}$$

If  $\Gamma_2 = \emptyset$ , then  $w_n = 0$  on  $\Gamma$ . By the standard estimate for the elliptic boundary value problems, we have

$$||w_n||_{H^2} \le C||\Delta w_n|| \to 0 \tag{2.5.87}$$

which, due to (2.5.80), further yields

$$v_n \to 0 \quad \text{in } L^2,$$
 (2.5.88)

a contradiction. Thus, the proof for the case  $\Gamma_2 = \emptyset$  is proved.

For the general case that  $\Gamma_2 \neq \emptyset$ , instead of (2.5.87), we have

$$\|w_n\|_{H^2} \le C \left( \|\Delta w_n\| + \|w\|_{H^{3/2}(\Gamma_2)} \right).$$
 (2.5.89)

Therefore, it remains to prove that  $||w||_{H^{3/2}(\Gamma_2)} \to 0$ . For this purpose, we first estimate  $||\Delta w_n||_{L^2(\Gamma_2)}$  and  $||\theta||_{L^2(\Gamma_2)}$ . By Theorem 1.4.4, (2.5.86) and (2.5.75), we have

$$\frac{\|\Delta w_n\|_{L^2(\Gamma_2)}}{\beta_n^{1/4}} \le C \frac{\|w_n\|_{H^3}^{1/2}}{\beta_n^{1/4}} \|\Delta w_n\|^{1/2} \to 0, \tag{2.5.90}$$

and

$$\frac{\|\theta_n\|_{L^2(\Gamma_2)}}{\beta_n^{1/4}} \to 0. \tag{2.5.91}$$

By the trace theorem, we get that

$$\frac{\|w_n\|_{H^1(\Gamma_2)}}{\beta_n^{1/4}} \le C \frac{\|w_n\|_{H^2}}{\beta_n^{1/4}} \to 0. \tag{2.5.92}$$

If we denote by  $D_{\tau}w$ ,  $D_{\tau}^2w$  the first-order and the second-order tangential derivative of w on  $\Gamma_2$ , respectively, then a straight forward calculation yields that

$$\begin{cases}
D_{\tau}w = -\nu_{2}w_{x} + \nu_{1}w_{y}, \\
D_{\tau}^{2}w = \nu_{2}^{2}w_{xx} - 2\nu_{1}\nu_{2}w_{xy} + \nu_{1}^{2}w_{yy} + (\nu_{2}\nu_{2x}w_{x} - \nu_{1x}\nu_{2}w_{y} - \nu_{1}\nu_{2y}w_{x} + \nu_{1}\nu_{1y}w_{y}).
\end{cases}$$
(2.5.93)

Therefore, the first boundary condition on  $\Gamma_2$  can be rewritten as

$$\Delta w_n + (1 - \mu) \left( -D_\tau^2 w_n + k \frac{\partial w_n}{\partial \nu} \right) + \alpha \theta = 0 \quad \text{on } \Gamma_2$$
 (2.5.94)

where  $k = -(\nu_{1x} + \nu_{2y})$ . Since the boundary is smooth, k is bounded. It follows from (2.5.90), (2.5.91) and (2.5.94) that

$$\frac{\|D_{\tau}^2 w_n\|_{L^2(\Gamma_2)}}{\beta^{1/4}} \to 0. \tag{2.5.95}$$

Notice that  $H^2(\Gamma_2)$  is a Sobolev space on the one-dimensional manifold  $\Gamma_2$ . Therefore, a straight forward calculation shows that  $\|w_n\|_{H^2(\Gamma_2)}^2$  is equivalent to  $\|D_{\tau}^2 w_n\|_{L^2(\Gamma_2)}^2 + \|w_n\|_{H^1(\Gamma_2)}^2$ . Then we deduce from (2.5.95) and (2.5.92) that

$$\frac{\|w_n\|_{H^2(\Gamma_2)}}{\beta_n^{1/4}} \to 0. \tag{2.5.96}$$

By the interpolation inequality for the Sobolev spaces on the manifold (for instance, see Hörmander [1]) and Theorem 1.4.4, we have

$$||w_n||_{H^{3/2}(\Gamma_2)} \le C||w_n||_{H^2(\Gamma_2)}^{\frac{1}{2}} ||w_n||_{H^1(\Gamma_2)}^{\frac{1}{2}}$$

$$\le C_1 \left(\frac{||w_n||_{H^2(\Gamma_2)}}{\beta_n^{1/4}}\right)^{1/2} ||w_n||_{H^2}^{\frac{1}{4}} ||\beta_n^{\frac{1}{2}}w_n||_{H^1}^{\frac{1}{4}} \to 0, \tag{2.5.97}$$

due to (2.5.96) and the boundedness of  $w_n$  in  $H^2(\Omega)$  and  $\beta_n^{1/2}w_n$  in  $H^1(\Omega)$ . Thus, the proof is complete.

## Chapter 3

#### Linear Viscoelastic Systems

In this chapter we are concerned with exponential stability of semigroups associated with linear viscoelastic systems. We begin in the first section of this chapter by considering a very simple linear viscoelastic equation for  $(x,t) \in (0,l) \times \mathbb{R}^+$ :

$$u_{tt} - au_{xx} - \gamma u_{xxt} = 0 (3.0.1)$$

with  $a, \gamma$  being given positive constants and subject to certain initial and boundary conditions. The exponential stability and analyticity of the corresponding semigroup are proved in the first section. Then we further extend this model to an abstract setting in operator forms, using the systematic method described in this book. The second section is devoted to the wave equation with locally distributed damping. In the third section, we consider the linear viscoelastic system with memory and prove the exponential stability under certain assumptions on the kernel. We also point out that the analyticity is not valid for such kind of semigroups. In the final section, we consider the Kirchhoff plate equation with memory and give the results on the exponential stability of the corresponding semigroup, as an application of the general result established in the third section.

#### 3.1 Linear Viscoelastic System

Let us first consider the motion of an elastic rod in the x direction with the reference configeration of length l. Suppose that the stress is of rate type, i.e.,

$$\sigma = au_x + \gamma u_{xt}. (3.1.1)$$

Then, the momentum equation is written as (3.0.1). To fix our idea, let us assume that the rod is clamped at both ends, x = 0 and x = l. Then we have the following boundary conditions:

$$u|_{x=0} = 0, \quad u|_{x=l} = 0.$$
 (3.1.2)

and also the following initial conditions:

$$u|_{t=0} = u_0(x), \quad u_t|_{t=0} = u_1(x), \quad \forall t > 0.$$
 (3.1.3)

In order to convert the above problem into the first-order evolution equation, we introduce

$$v = u_t \tag{3.1.4}$$

and let  $\mathcal{H}=H^1_0(0,l)\times L^2(0,l)$  with  $H^1_0=\{u|u\in H^1,\ u(0)=u(l)=0\}$  equipped with the norm  $\|u\|_{H^1_0}=(\int_0^l a|Du|^2dx)^{\frac{1}{2}}$ . As in the previous chapters, we always denote  $D^i=\frac{\partial^i}{\partial x^i}$ . Then the initial boundary value problem (3.1.1)–(3.1.3) is reduced to the following initial value problem for a first-order evolution equation in  $\mathcal{H}$ :

$$\begin{cases}
\frac{dy}{dt} = \mathcal{A}y, & \forall t > 0 \\
y|_{t=0} = (u_0, u_1)^T
\end{cases}$$
(3.1.5)

with

$$y = \begin{pmatrix} u \\ v \end{pmatrix}, \tag{3.1.6}$$

$$Ay = \begin{pmatrix} v \\ D(aDu + \gamma Dv) \end{pmatrix}$$
 (3.1.7)

and

$$\mathcal{D}(\mathcal{A}) = \{ y \in \mathcal{H} | v \in H_0^1, \ (aDu + \gamma Dv) \in H^1 \}.$$
 (3.1.8)

It is clear, for instance from Chapter 1, that  $\mathcal{D}(A)$  is dense in  $\mathcal{H}$ . We now have the following.

**Theorem 3.1.1** The operator  $\mathcal{A}$  generates a  $C_0$ -semigroup of contractions in  $\mathcal{H}$ **Proof** For  $y \in \mathcal{D}(\mathcal{A})$ , by integration by parts we have

$$(\mathcal{A}y, y)_{\mathcal{H}} = \int_0^l (aDuDv + D(aDu + \gamma Dv)v)dx$$
$$= -\int_0^l \gamma |Dv|^2 dx \le 0. \tag{3.1.9}$$

This shows that A is dissipative. We now prove that  $0 \in \rho(A)$ . For any  $F = (f, g)^T \in \mathcal{H}$ , consider the equations Ay = F, i.e.,

$$v = f \in H_0^1, (3.1.10)$$

$$D(aDu + \gamma Dv) = g \in L^2. \tag{3.1.11}$$

We plug v = f, obtained from (3.1.10), into (3.1.11) to get

$$aD(Du) = g - \gamma D^2 f \in H^{-1}$$
 (3.1.12)

where  $H^{-1}$  is the dual space of  $H_0^1$ . Thus by the standard result in the elliptic equations (see Chapter 1, for instance), we can conclude that (3.1.12) admits a unique solution  $u \in H_0^1$ . It turns out that we obtain a unique  $(u,v)^T \in \mathcal{H}$  such that  $(u,v)^T \in \mathcal{D}(\mathcal{A})$  and satisfies (3.1.10) and (3.1.11). It is clear that  $\|(u,v)^T\|_{\mathcal{H}} \leq K\|F\|_{\mathcal{H}}$  with K being a positive constant. Thus  $0 \in \rho(\mathcal{A})$  is proved. By Theorem 1.2.4, the proof is complete.

Furthermore, we have the following.

**Theorem 3.1.2** The semigroup S(t), generated by A, is exponentially stable, i.e., there exist positive constants  $M, \alpha$  such that

$$||S(t)|| \le Me^{-\alpha t}.$$
 (3.1.13)

**Proof** As in the previous chapter, we still use Theorem 1.3.2 to prove this theorem. We first prove (1.3.3) which consists of the following steps:

- (i) Prove  $0 \in \rho(A)$  which has been done in Theorem 3.1.1.
- (ii) It follows from Remark 2.1.1 and the contraction mapping theorem that for any real number  $\beta$  with  $|\beta| < ||\mathcal{A}^{-1}||^{-1}$ , the operator  $i\beta I \mathcal{A} = \mathcal{A}(i\beta\mathcal{A}^{-1} I)$  is invertible. Moreover,  $||(i\beta I \mathcal{A})^{-1}||$  is a continuous function of  $\beta$  in  $(-||\mathcal{A}^{-1}||^{-1}, ||\mathcal{A}^{-1}||^{-1})$ .
- (iii) Thus, if (1.3.3) is not true, then there is  $\omega \in \mathbb{R}$  with  $\|\mathcal{A}^{-1}\|^{-1} \leq |\omega| < \infty$  such that  $\{i\beta \mid |\beta| < |\omega|\} \subset \rho(\mathcal{A})$  and  $\sup\{\|(i\beta \mathcal{A})^{-1}\| \mid |\beta| < |\omega|\} = \infty$ . It turns out that there exists a sequence  $\beta_n \in \mathbb{R}$  with  $\beta_n \to \omega$ ,  $|\beta_n| < |\omega|$  and a sequence of complex

vector functions  $y_n \in \mathcal{D}(A)$  with unit norm in  $\mathcal{H}$  such that

$$\|(\boldsymbol{i}\beta_n I - \mathcal{A})y_n\|_{\mathcal{H}} \to 0, \tag{3.1.14}$$

as  $n \to \infty$ , i.e.,

$$i\beta_n u_n - v_n \to 0 \quad \text{in } H_0^1, \tag{3.1.15}$$

$$i\beta_n v_n - D(aDu_n + \gamma Dv_n) \to 0 \quad \text{in } L^2.$$
 (3.1.16)

Taking the inner product of  $(i\beta_n I - A)y_n$  with  $y_n$  in  $\mathcal{H}$  and then taking its real part yields

$$Re((i\beta_n I - A)y_n, y_n) = \gamma ||Dv_n||^2 \to 0.$$
 (3.1.17)

By the Poincaré inequality, we get that

$$v_n \to 0 \quad \text{in } L^2. \tag{3.1.18}$$

Then it immediately follows from (3.1.15) that

$$u_n \to 0 \quad \text{in } H_0^1. \tag{3.1.19}$$

This contradicts  $||y_n||_{\mathcal{H}} = 1$ . Thus (1.3.3) is proved.

We now prove (1.3.4) by a contradiction argument. Suppose that (1.3.4) is not true. Then there exists a sequence  $\beta_n$  with  $|\beta_n| \to +\infty$  and a sequence of complex vector functions  $y_n \in \mathcal{D}(\mathcal{A})$  with unit norm in  $\mathcal{H}$  such that (3.1.14) holds. Again we have (3.1.17). Dividing (3.1.15) by  $\beta_n$  yields (3.1.9). Thus the proof is complete.  $\square$ 

We would like to emphasize that the viscoelastic system which we are now considering is quite different from the linear thermoelastic system in the sense that the corresponding semigroup is not only exponentially stable, but is also analytic, as shown in the following theorem.

**Theorem 3.1.3** The semigroup S(t), generated by A, is analytic.

**Proof** On the basis of the proof of the above theorem, by Theorem 1.3.3, we only need to prove (1.3.8). We still use a contradiction argument. Suppose that (1.3.8) is 64

not true. Then there exists a sequence  $\beta_n$  with  $|\beta_n| \to +\infty$  and a sequence of complex vector functions  $y_n \in \mathcal{D}(\mathcal{A})$  with unit norm in  $\mathcal{H}$  such that

$$\|(\boldsymbol{i}I - \frac{1}{\beta_n}\mathcal{A})y_n\|_{\mathcal{H}} \to 0, \tag{3.1.20}$$

as  $n \to \infty$ , i.e.,

$$iu_n - \frac{1}{\beta_n}v_n \to 0 \quad \text{in } H_0^1,$$
 (3.1.21)

$$iv_n - \frac{1}{\beta_n}D(aDu_n + \gamma Dv_n) \to 0 \quad \text{in } L^2.$$
 (3.1.22)

In the same manner as before, we get

$$\frac{1}{\beta_n} \|Dv_n\|^2 \to 0. \tag{3.1.23}$$

Now we take the inner product of (3.1.21) with  $u_n$  in  $H_0^1$  and apply the Cauchy-Schwartz inequality to obtain that

$$||Du_n||^2 \le \frac{1}{\beta_n} |(Dv_n, Du_n)| + o(1) \le \frac{1}{2} ||Du_n||^2 + \frac{1}{2\beta_n^2} ||Dv_n||^2 + o(1)$$
 (3.1.24)

where  $o(1) \to 0$ , as  $n \to +\infty$ . Thus it follows from (3.1.23) and (3.1.24) that

$$u_n \to 0 \quad \text{in } H_0^1.$$
 (3.1.25)

Taking the inner product of (3.1.22) with  $v_n$  in  $L^2$ , and then integrating by parts and applying the Cauchy-Schwartz inequality, we obtain that

$$||v_n||^2 \le \frac{\gamma}{\beta_n} ||Dv_n||^2 + \frac{a}{\beta_n} |(Du_n, Dv_n)| + o(1)$$
(3.1.26)

Thus,  $v_n \to 0$  in  $L^2$  follows from (3.1.25)-(3.1.26). A contradiction again. The proof is complete.

Remark 3.1.1 As in the previous chapter, we can also deal with other boundary conditions.

In what follows, we consider an extended model to (3.0.1) or (3.1.5)–(3.1.7). Suppose that A is a self-adjoint positive definite operator with the domain  $\mathcal{D}(A)$  being dense in a Hilbert space H. As known from Chapter 1, we can define the fractional

power  $A^{\alpha}$  with  $\alpha \in \mathbb{R}$ . Consider the following the initial value problem for a second-order evolution equation in the operator form:

$$\begin{cases} u_{tt} + Au + A^{\alpha}u_{t} = 0, \\ u|_{t=0} = u_{0}, \quad u_{t}|_{t=0} = u_{1}, \end{cases}$$
(3.1.27)

where  $0 \le \alpha \le 1$ . When  $\alpha = 1$ , the equation (3.0.1) subject to the corresponding boundary conditions (3.1.2) becomes a special case for the above abstract setting. When  $\alpha = 0$ , the following equation with appropriate initial and boundary conditions

$$u_{tt} - u_{xx} - u_t = 0, (3.1.28)$$

which is the momentum equation of a rod with the damping due to friction, is a special case for the above abstract setting. However, for  $0 < \alpha < 1$ , the mechanical meaning of the equation in (3.1.27) does not seem very clear. We now use the semigroup approach to investigate solvability of problem (3.1.27).

Let

$$\mathcal{H} = \mathcal{D}(A^{\frac{1}{2}}) \times H. \tag{3.1.29}$$

If we introduce  $v = u_t$ , then (3.1.27) can be reduced to the following initial value problem for a first-order evolution equation in  $\mathcal{H}$ :

$$\begin{cases} \frac{dy}{dt} = \mathcal{A}_{\alpha}y, \\ y|_{t=0} = y_0 = (u_0, u_1)^T \end{cases}$$
 (3.1.30)

with

$$y = \begin{pmatrix} u \\ v \end{pmatrix}, \tag{3.1.31}$$

$$\mathcal{D}(\mathcal{A}_{\alpha}) = \{ y \in \mathcal{H} \mid (u, v)^{T} \in \mathcal{D}(A^{\frac{1}{2}}) \times \mathcal{D}(A^{\frac{1}{2}}), \ A^{\frac{1}{2}}u + A^{\alpha - \frac{1}{2}}v \in \mathcal{D}(A^{\frac{1}{2}}) \}, \quad (3.1.32)$$

and

$$\mathcal{A}_{\alpha}y = \begin{pmatrix} v \\ -A^{\frac{1}{2}}(A^{\frac{1}{2}}u + A^{\alpha - \frac{1}{2}}v) \end{pmatrix}. \tag{3.1.33}$$

It is easy to verify that for  $y \in \mathcal{D}(\mathcal{A}_{\alpha})$ ,

$$(\mathcal{A}_{\alpha}y,y)_{\mathcal{H}} = (A^{\frac{1}{2}}v,A^{\frac{1}{2}}u)_{\mathcal{H}} - (A^{\frac{1}{2}}(A^{\frac{1}{2}}u+A^{\alpha-\frac{1}{2}}v),v)_{\mathcal{H}} = -\|A^{\frac{\alpha}{2}}v\|_{\mathcal{H}}^{2} \leq 0. \tag{3.1.34}$$

Thus  $A_{\alpha}$  is a dissipative operator. We now have the next theorem.

**Theorem 3.1.4** The operator  $A_{\alpha}$  generates a  $C_0$ -semigroup  $S_{\alpha}(t)$  of contractions in  $\mathcal{H}$ .

**Proof** It follows from  $\mathcal{D}(A) \times \mathcal{D}(A) \subset \mathcal{D}(\mathcal{A}_{\alpha})$  that  $\mathcal{D}(\mathcal{A}_{\alpha})$  is dense in  $\mathcal{H}$ . By Theorem 1.2.4, it suffices to prove that  $0 \in \rho(\mathcal{A}_{\alpha})$ . For any  $F = (f, g)^T \in \mathcal{D}(\mathcal{A}_{\alpha})$ , consider the following equation:

$$\mathcal{A}_{\alpha}y = F,\tag{3.1.35}$$

i.e,

$$v = f \in \mathcal{D}(A^{\frac{1}{2}}), \tag{3.1.36}$$

and

$$-A^{\frac{1}{2}}(A^{\frac{1}{2}}u + A^{\alpha - \frac{1}{2}}v) = g \in H.$$
(3.1.37)

We plug v = f obtained from (3.1.36) into (3.1.37) to get

$$-A^{\frac{1}{2}}(A^{\frac{1}{2}}u + A^{\alpha - \frac{1}{2}}f) = g \in H.$$
 (3.1.38)

Since  $A^{\frac{1}{2}}$  is invertible, (3.1.38) has a unique solution:

$$u = -A^{\frac{-1}{2}} (A^{\frac{-1}{2}} g + A^{\alpha - \frac{1}{2}} f). \tag{3.1.39}$$

It turns out that  $(u,v)^T$  belongs to  $\mathcal{D}(\mathcal{A}_{\alpha})$  and satisfies (3.1.36) and (3.1.37). We also notice that for  $0 \leq \alpha \leq \frac{1}{2}$ , it follows from  $v \in \mathcal{D}(A^{\frac{1}{2}})$  that  $A^{\alpha-\frac{1}{2}}v \in \mathcal{D}(A^{\frac{1}{2}})$ . Thus  $u \in \mathcal{D}(A)$  and  $A^{\frac{1}{2}}(A^{\frac{1}{2}}u + A^{\alpha-\frac{1}{2}}v) = Au + A^{\alpha}v$ . It is clear that  $\|(u,v)^T\|_{\mathcal{H}} \leq K\|F\|_{\mathcal{H}}$  with K being a positive constant. Thus, the proof is complete.

Furthermore, we have the following.

**Theorem 3.1.5** Let  $S_{\alpha}(t)$  be the  $C_0$ -semigroup of contractions generated by  $\mathcal{A}_{\alpha}$ . Then for  $\frac{1}{2} \leq \alpha \leq 1$ ,  $S_{\alpha}(t)$  is exponentially stable and analytic; for  $0 \leq \alpha < \frac{1}{2}$ ,  $S_{\alpha}(t)$  is exponentially stable.

**Remark 3.1.2** If we use the results by Taylor [1] concerning the characterization of Gevrey's class instead of (1.3.4), then we can also prove that for  $0 < \alpha < \frac{1}{2}$ , the semigroup  $S_{\alpha}(t)$  of contractions generated by  $\mathcal{A}_{\alpha}$  is in Gevrey's class.

**Proof of Theorem 3.1.5.** First for  $0 \le \alpha \le 1$  we want to prove that the semigroup  $S_{\alpha}(t)$  is exponentially stable. The basic strategy is still to use Theorem 1.3.2.

(i)  $0 \in \rho(\mathcal{A}_{\alpha})$ . This has been proved in the previous theorem.

(ii) We now prove (1.3.3). Suppose that it is not true. Then there is  $\omega \in \mathbb{R}$  with  $\|\mathcal{A}_{\alpha}^{-1}\|^{-1} \leq |\omega| < \infty$  such that  $\{i\beta \mid |\beta| < |\omega|\} \subset \rho(\mathcal{A}_{\alpha})$  and  $\sup\{\|(i\beta - \mathcal{A}_{\alpha})^{-1}\| \mid |\beta| < |\omega|\} = \infty$ . It turns out that there exists a sequence  $\beta_n \in \mathbb{R}$  with  $\beta_n \to \omega$ ,  $|\beta_n| < |\omega|$  and a sequence of complex vector functions  $y_n \in \mathcal{D}(\mathcal{A}_{\alpha})$  with  $\|y_n\|_{\mathcal{H}} = (\|A^{\frac{1}{2}}u_n\|_H^2 + \|v_n\|_H^2)^{\frac{1}{2}} = 1$  such that as  $n \to \infty$ ,

$$i\beta_n y^{(n)} - \mathcal{A}_{\alpha} y_n \to 0 \quad \text{in } \mathcal{H},$$
 (3.1.40)

i.e.,

$$i\beta_n u_n - v_n \to 0 \quad \text{in } \mathcal{D}(A^{\frac{1}{2}}),$$
 (3.1.41)

$$i\beta_n v_n + A^{\frac{1}{2}} (A^{\frac{1}{2}} u_n + A^{\alpha - \frac{1}{2}} v_n) \to 0 \quad \text{in } H.$$
 (3.1.42)

It follows from (3.1.40) that

$$Re(\mathbf{i}\beta_n y_n - \mathcal{A}_{\alpha} y_n, y_n)_{\mathcal{H}} = -\|A^{\frac{\alpha}{2}} v_n\|_H^2 \to 0.$$
 (3.1.43)

Thus,

$$||v_n||_H \le C||A^{\frac{\alpha}{2}}v_n||_H \to 0. \tag{3.1.44}$$

By (3.1.42), we get that

$$A^{\frac{1}{2}}(A^{\frac{1}{2}}u_n + A^{\alpha - \frac{1}{2}}v_n) \to 0$$
 in  $H$ . (3.1.45)

Taking the inner product of (3.1.45) with  $u_n$  in H yields

$$||A^{\frac{1}{2}}u_n||_H^2 + (A^{\frac{\alpha}{2}}v_n, A^{\frac{\alpha}{2}}u_n)_H \to 0.$$
 (3.1.46)

Since  $||A^{\frac{\alpha}{2}}u_n||_H$  is bounded, it follows from (3.1.43) and (3.1.46) that

$$||A^{\frac{1}{2}}u_n||_H^2 \to 0. (3.1.47)$$

(3.1.44) and (3.1.47) contradict  $||y_n||_{\mathcal{H}} = (||A^{\frac{1}{2}}u_n||_H^2 + ||v_n||_H^2)^{\frac{1}{2}} = 1$ . Thus (1.3.3) is proved.

(iii) We now prove (1.3.4) by a contradiction argument. Suppose that (1.3.4) is not true, then there exists a sequence  $\beta_n$  with  $|\beta_n| \to +\infty$  and a sequence of complex vector functions  $y_n \in \mathcal{D}(\mathcal{A}_{\alpha})$  with unit norm in  $\mathcal{H}$  such that (3.1.40) holds. As in the above, we still have (3.1.44). Dividing (3.1.41) by  $\beta_n$ , then taking the inner product with  $u_n$  in  $\mathcal{D}(A^{\frac{1}{2}})$ , we obtain that

$$i\|A^{\frac{1}{2}}u_n\|_H^2 + \frac{(A^{\frac{1}{2}}v_n, A^{\frac{1}{2}}u_n)_H}{\beta_n} \to 0.$$
 (3.1.48)

Dividing (3.1.42) by  $\beta_n$ , then taking the inner product with  $v_n$  in H yields

$$\frac{(A^{\frac{1}{2}}u_n, A^{\frac{1}{2}}v_n)_H + ||A^{\frac{\alpha}{2}}v_n||_H^2}{\beta_n} \to 0.$$
 (3.1.49)

Thus combining (3.1.49) with (3.1.48) and (3.1.44) yields

$$||A^{\frac{1}{2}}u_n||_H^2 \to 0,$$
 (3.1.50)

which together with (3.1.44) contradicts the unit norm of  $y_n$ . Thus the proof for exponential stability is complete.

We now continue to prove that for  $\frac{1}{2} \leq \alpha \leq 1$ , the semigroup is analytic. By Theorem 1.3.3, it suffices to prove that (1.3.8) holds. Suppose that (1.3.8) is not true. Then there exists a sequence  $\beta_n$  with  $|\beta_n| \to +\infty$  and a sequence of complex vector functions  $y_n \in \mathcal{D}(\mathcal{A}_{\alpha})$  with unit norm in  $\mathcal{H}$  such that as  $n \to \infty$ ,

$$iy_n - \frac{\mathcal{A}_{\alpha}y_n}{\beta_n} \to 0 \quad \text{in } \mathcal{H},$$
 (3.1.51)

i.e.,

$$iu_n - \frac{v_n}{\beta_n} \to 0 \quad \text{in } \mathcal{D}(A^{\frac{1}{2}}),$$
 (3.1.52)

$$iv_n + \frac{A^{\frac{1}{2}}(A^{\frac{1}{2}}u_n + A^{\alpha - \frac{1}{2}}v_n)}{\beta_n} \to 0 \quad \text{in } H.$$
 (3.1.53)

Taking the inner product of (3.1.51) with  $y_n$  in  $\mathcal{H}$ , we obtain that

$$\frac{\|A^{\frac{\alpha}{2}}v_n\|_H^2}{\beta_n} \to 0. \tag{3.1.54}$$

Taking the inner product of (3.1.52) with  $u_n$  and  $A^{-\alpha}v_n$  in  $\mathcal{D}(A^{\frac{1}{2}})$ , respectively, yields

$$i\|A^{\frac{1}{2}}u_n\|_H^2 - \frac{(A^{\frac{1}{2}}v_n, A^{\frac{1}{2}}u_n)_H}{\beta_n} \to 0, \tag{3.1.55}$$

and

$$i(A^{\frac{1-\alpha}{2}}u_n, A^{\frac{1-\alpha}{2}}v_n)_H - \frac{\|A^{\frac{1-\alpha}{2}}v_n\|_H^2}{\beta_n} \to 0.$$
 (3.1.56)

Since  $\frac{1}{2} \le \alpha \le 1$ ,

$$||A^{\frac{1-\alpha}{2}}v_n||_H \le C||A^{\frac{\alpha}{2}}v_n||_H. \tag{3.1.57}$$

Then it follows from (3.1.54), (3.1.56), and (3.1.57) that

$$(A^{\frac{1-\alpha}{2}}u_n, A^{\frac{1-\alpha}{2}}v_n)_H \to 0.$$
 (3.1.58)

We further take the inner product of (3.1.53) with  $A^{1-\alpha}u_n$  in H to obtain that

$$i(A^{\frac{1-\alpha}{2}}v_n, A^{\frac{1-\alpha}{2}}u_n)_H + \frac{\|A^{1-\frac{\alpha}{2}}u_n\|_H^2}{\beta_n} + \frac{(A^{\frac{1}{2}}v_n, A^{\frac{1}{2}}u_n)_H}{\beta_n} \to 0.$$
(3.1.59)

Adding (3.1.59) up with (3.1.55), then taking the imaginary part yields

$$||A^{\frac{1}{2}}u_n||_H^2 + (A^{\frac{1-\alpha}{2}}v_n, A^{\frac{1-\alpha}{2}}u_n)_H \to 0.$$
 (3.1.60)

It follows from (3.1.58) and (3.1.60) that

$$||A^{\frac{1}{2}}u_n||_H^2 \to 0. (3.1.61)$$

Taking the inner product of (3.1.53) with  $v_n$  in H and using (3.1.54) and (3.1.61), we immediately get

$$||v_n||_H^2 \to 0. (3.1.62)$$

Thus, we have contradiction again and the proof of this theorem is finally complete.

We now investigate the relationship between the semigroup solution and the solution to problem (3.1.27). In other words, we want to explain in what sense the semigroup solution satisfies problem (3.1.27).

If  $y_0 \in \mathcal{D}(\mathcal{A}_{\alpha})$ , then  $y \in C([0,\infty), \mathcal{D}(\mathcal{A}_{\alpha})) \cap C^1([0,\infty), \mathcal{H})$  satisfies (3.1.30) pointwise. It turns out that u belongs to  $C^2([0,\infty), H) \cap C^1([0,\infty), \mathcal{D}(A^{\frac{1}{2}}))$  and satisfies

$$u_{tt} + A^{\frac{1}{2}}(A^{\frac{1}{2}}u + A^{\alpha - \frac{1}{2}}u_t) = 0 (3.1.63)$$

in H for every t>0 and the initial conditions of (3.1.27) in the strong sense. Notice that when  $0 \le \alpha \le \frac{1}{2}$ , as mentioned before, we have  $A^{\frac{1}{2}}(A^{\frac{1}{2}}u + A^{\alpha - \frac{1}{2}}u_t) = Au + A^{\alpha}u_t$ , i.e, (3.1.27) is satisfied in H pointwise for every t>0.

If  $y_0 \in \mathcal{H}$ , then  $y \in C([0,\infty),\mathcal{H})$  (i.e.,  $u \in C([0,\infty),\mathcal{D}(A^{\frac{1}{2}}))$ ,  $v \in C([0,\infty),H)$ ) is a mild solution to problem (3.1.30). Since  $\mathcal{D}(\mathcal{A}_{\alpha})$  is dense in  $\mathcal{H}$ , we have a sequence  $y_{0n} \in \mathcal{D}(\mathcal{A}_{\alpha})$  converging to  $y_0$  in  $\mathcal{H}$ . Accordingly, we have a sequence  $y_n = (u_n, v_n)^T$  satisfying (3.1.63). Moreover, for any T > 0,  $u_n \to u$  in  $C([0,T],\mathcal{D}(A^{\frac{1}{2}}))$ ,  $v_n = u_{nt} \to v$  in C([0,T],H). Let w be an arbitrary element in  $\mathcal{D}(A^{\frac{1}{2}})$ . Taking the inner product of (3.1.63) for  $u_n$  with w in H, then integrating with respect to t and passing to the limit, we obtain that

$$(u_t, w)_H - (u_1, w)_H + (A^{\alpha - \frac{1}{2}}u, A^{\frac{1}{2}}w)_H - (A^{\alpha - \frac{1}{2}}u_0, A^{\frac{1}{2}}w)_H + \int_0^t (A^{\frac{1}{2}}u, A^{\frac{1}{2}}w)_H d\tau = 0$$
(3.1.64)

or equivalently,

$$\frac{d}{dt}((u_t, w)_H + (A^{\alpha - \frac{1}{2}}u, A^{\frac{1}{2}}w)_H) + (A^{\frac{1}{2}}u, A^{\frac{1}{2}}w)_H = 0, \quad \forall t > 0.$$
 (3.1.65)

(3.1.64) or (3.1.65) is usually called the variational form of (3.1.27). The above discussion shows that for  $y_0 \in \mathcal{H}$ , u, the first component of  $y = S(t)y_0$ , is a weak solution of problem (3.1.27) in the sense that the variational form (3.1.64) or (3.1.65) is satisfied for any test element  $w \in \mathcal{D}(A^{\frac{1}{2}})$ .

Remark 3.1.3 The extended model considered above seems to be initiated in Chen & Russell [1]. They considered the damped elastic system in the following form:

$$u_{tt} + Bu_t + Au = 0 (3.1.66)$$

with A being a positive definite self-adjoint operator densely defined in a Hilbert space H and B being another positive self-adjoint operator. Let  $v=u_t$ . Then equation (3.1.66) can be reduced to a first-order evolution equation:

$$\frac{dy}{dt} = \mathcal{A}_B y \tag{3.1.67}$$

with

$$\mathcal{A}_{B}y = \begin{pmatrix} v \\ -Au - Bv \end{pmatrix}. \tag{3.1.68}$$

We refer the reader to Chen & Russell [1] for the conjectures on when  $A_B$  will generate an analytic semigroup, and Huang [2]-[3] for the complete proofs of these conjectures. When B is an operator comparable to  $A^{\alpha}$ ,  $1/2 \leq \alpha \leq 1$ , we refer to Huang [4] and Chen & Triggiani [1] for the results and discussions about generation of an analytic semigroup by  $A_B$ . We also refer to Chen & Triggiani [2] for the results of generation of a semigroup in Gevrey's class when  $0 < \alpha < 1/2$ . The method used in Chen & Triggiani [1]-[2] is to directly estimate the spectrum of  $A_B$ . We refer to Liu & Liu [3] for two counter examples showing the possible illposedness for some operators B. The same conclusion on the exponential stability and analyticity for  $0 < \alpha \leq 1$  was also obtained in Liu & Liu [3], using a different factorization of  $Au + A^{\alpha}v$  from what presented here.

## 3.2 Wave Equation with Locally Distributed Damping

Notice that equation (3.1.28) indicates that the friction damping is distributed in a whole rod. However, it is desirable in practice to consider the problem with locally distributed damping. More precisely, in this section we will consider the following wave equation with locally distributed damping:

$$u_{tt} - u_{xx} + a(x)u_t = 0, \quad x \in (0, \pi), \quad \forall t > 0$$
 (3.2.1)

where a(x) is a given function such that  $a \in W^{1,\infty}$ ,  $a(x) \ge 0$  in  $[0,\pi]$  and

$$a_0 = \int_0^\pi a(x)dx > 0. (3.2.2)$$

This means that a(x) can vanish at some points of the interval  $[0, \pi]$ , but the measure of its support is positive. We consider the initial boundary value problem for equation (3.2.1) subject to the following boundary conditions and initial consitions:

$$u|_{x=0} = u|_{x=\pi} = 0, (3.2.3)$$

and

$$u|_{t=0} = u_0(x), \quad u_t|_{t=0} = u_1(x), \quad x \in [0, \pi].$$
 (3.2.4)

If we introduce  $v = u_t$  and the following Hilbert space

$$\mathcal{H} = H_0^1 \times L^2 \tag{3.2.5}$$

equipped with the inner product: for  $y_1 = (u_1, v_1)^T$ ,  $y_2 = (u_2, v_2)^T$ ,

$$(y_1, y_2)_{\mathcal{H}} = \int_0^\pi (u_{1x}\bar{u}_{2x} + v_1\bar{v}_2)dx, \tag{3.2.6}$$

then problem (3.2.1), (3.2.3), and (3.2.4) can be reduced to the following initial value problem for a first-order evolution equation on the Hilbert space  $\mathcal{H}$ :

$$\begin{cases} \frac{dy}{dt} = Ay, & t > 0, \\ y|_{t=0} = (u_0, u_1)^T \end{cases}$$
 (3.2.7)

with  $y = (u, v)^T$ ,

$$Ay = \begin{pmatrix} v \\ u_{xx} - a(x)v \end{pmatrix}, \tag{3.2.8}$$

and

$$\mathcal{D}(\mathcal{A}) = \left\{ y = (u, v)^T \in \mathcal{H} \mid v \in H_0^1, u \in H^2 \cap H_0^1 \right\}. \tag{3.2.9}$$

We should mention that this initial boundary value problem (3.2.1), (3.2.3), and (3.2.4) has been studied by many people (for instance, see Chen, Fulling, Narcowich & Sun [1] and the references cited there). What we would like to do now is to give a new proof for the exponential stability of the associated semigroup using the systematic method presented in this book. A new feature presented here is the combination of the

contradiction argument with the frequency domain multiplier technique. This technique has also been applied to certain elastic systems with damping locally distributed in the domain (see Liu & Liu [4]). We first prove the following.

**Theorem 3.2.1** The operator A defined in (3.2.8) generates a  $C_0$ -semigroup S(t) of contractions on the Hilbert  $\mathcal{H}$ .

**Proof** It is clear from Chapter 1 that  $\mathcal{D}(\mathcal{A})$  is dense in  $\mathcal{H}$ . Therefore, by Theorem 1.2.4, it suffices to prove that  $0 \in \rho(\mathcal{A})$  and  $\mathcal{A}$  is dissipative. For any  $y = (u, v)^T \in \mathcal{D}(\mathcal{A})$ , a straight forward calculation shows that

$$Re (Ay, y)_{\mathcal{H}} = Re \int_0^{\pi} (v_x \bar{u}_x + (u_{xx} - a(x)v)\bar{v}) dx$$
$$= -\int_0^{\pi} a(x)|v|^2 dx \le 0, \tag{3.2.10}$$

i.e.,  $\mathcal{A}$  is dissipative. Therefore, it remains to prove that  $0 \in \rho(\mathcal{A})$ . For any  $F = (f,g)^T \in \mathcal{H}$ , consider the equation

$$\mathcal{A}y = F,\tag{3.2.11}$$

i.e.,

$$v = f \in H_0^1, (3.2.12)$$

$$u_{xx} - av = g \in L^2. (3.2.13)$$

We plug v = f obtained from (3.2.12) into (3.2.13) to get

$$u_{xx} = af + g \in L^2. (3.2.14)$$

It easily follows from (3.2.14) or the standard result on the linear elliptic equations that (3.2.14) has a unique solution  $u \in H^2 \cap H^1_0$ . Therefore,  $0 \in \rho(\mathcal{A})$ . Moreover, it can be easily seen that  $\mathcal{A}^{-1}$  is compact in  $\mathcal{H}$ . The proof is complete.

The main result in this section is the following.

**Theorem 3.2.2** The semigroup S(t), generated by A, is exponentially stable, i.e., there exist two positive constants  $\alpha$ , M such that

$$||S(t)|| \le Me^{-\alpha t}, \quad \forall t > 0.$$
 (3.2.15)

**Proof** By Theorem 1.3.2, it suffices to verify (1.3.3) and (1.3.4). We use the contradiction argument again.

(i) If (1.3.3) is not true, then there must be a  $\beta \in \mathbb{R}$  such that  $\beta \neq 0$ ,  $i\beta$  is in the spectrum of  $\mathcal{A}$ . Since  $\mathcal{A}^{-1}$  is compact,  $i\beta$  must be an eigenvalue of  $\mathcal{A}$ . It turns out that there is a vector function  $y = (u, v)^T \in \mathcal{D}(\mathcal{A}), ||y||_{\mathcal{H}} = 1$  such that

$$i\beta y - \mathcal{A}y = 0, (3.2.16)$$

i.e.,

$$\begin{cases} i\beta u - v = 0, \\ i\beta v - u_{xx} + a(x)v = 0. \end{cases}$$
 (3.2.17)

Taking the inner product of (3.2.16) with y in  $\mathcal{H}$ , then taking its real part yields

$$Re(i\beta y - Ay, y) = \int_0^{\pi} a(x)|v|^2 dx = 0.$$
 (3.2.18)

It follows from the following estimate

$$||av||^2 = \int_0^\pi a^2 |v|^2 dx \le ||a||_{L^\infty} \int_0^\pi a|v|^2 dx = 0$$
 (3.2.19)

that

$$a(x)v = 0, \quad \forall x \in [0, \pi].$$
 (3.2.20)

Combining it with (3.2.17) yields that

$$-\beta^2 u - u_{xx} = 0. ag{3.2.21}$$

Since u satisfies the Dirichlet boundary condition, it follows from (3.2.21) that there must be an integer  $n \in \mathbb{N}$  such that

$$\beta = n, \tag{3.2.22}$$

and

$$u = C\sin nx \tag{3.2.23}$$

with  $C \neq 0$  being a constant. Therefore, it follows from the first equation in (3.2.17) that

$$0 = a(x)v = iCna(x)\sin nx, \quad \forall x \in [0, \pi]$$
(3.2.24)

which contradicts the assumptions on a(x) that  $a \ge 0$  and the measure of its support is positive. Thus (1.3.3) is proved.

(ii) Suppose that (1.3.4) is not true. There then exists a sequence  $\beta_n$  with  $\beta_n \to \infty$  and a sequence vector functions  $y_n = (u_n, v_n)^T \in \mathcal{D}(\mathcal{A})$  with unit norm in  $\mathcal{H}$  such that as  $n \to \infty$ ,

$$i\beta y_n - \mathcal{A}y_n \to 0$$
, in  $\mathcal{H}$ , (3.2.25)

i.e.,

$$f_n = i\beta_n u_n - v_n \to 0 \quad \text{in } H_0^1,$$
 (3.2.26)

$$g_n = i\beta_n v_n - u_{nxx} + a(x)v_n \to 0 \text{ in } L^2.$$
 (3.2.27)

Taking the inner product of (3.2.25) with  $y_n$  in  $\mathcal{H}$  and using the estimate (3.2.19) yields that

$$av_n \to 0$$
 in  $L^2$ . (3.2.28)

On the other hand, we can easily deduce from (3.2.27) that

$$-\beta_n^2 u_n - u_{nxx} = g_n + i\beta_n f_n - av_n.$$
 (3.2.29)

Let q(x) be a real function in  $C^1$  which will be chosen later. Taking the inner product of (3.2.29) with  $q(x)u_{nx}$  in  $L^2$ , integrating by parts, we obtain that

$$\int_0^{\pi} q_x(|u_{nx}|^2 + \beta_n^2 |u_n|^2) dx - q(1)|u_{nx}(1)|^2 + q(0)|u_{nx}(0)|^2 = 2(g_n, qu_{nx}) - 2(i\beta_n(f_n q)_x, u_n).$$
(3.2.30)

Since  $u_{nx}$ ,  $\beta_n u_n$  are uniformly bounded in  $L^2$ , the terms on the right hand side of (3.2.30) converge to zero. Taking q = x, 1 - x, respectively, we deduce from (3.2.30) and  $||y_n||_{\mathcal{H}} = 1$  that

$$|u_{nx}(1)|^2 \to 1, \quad |u_{nx}(0)|^2 \to 1.$$
 (3.2.31)

We now take  $q(x) = \int_0^x a(s)ds$  in (3.2.30) to obtain that

$$(a\beta_n u_n, \beta_n u_n) + (au_{nx}, u_{nx}) \to a_0 = \int_0^\pi a(x) dx > 0.$$
 (3.2.32)

In what follows we prove that this  $\bar{i}s$  a contradiction. Indeed, it follows from the first equation of (3.2.27) and (3.2.28) that the first term on the left hand side of (3.2.32) converges to zero. Therefore, it remains to be proved that the second term on the left hand side of (3.2.32) also converges to zero. Taking the inner product of the second equation of (3.2.27) with  $au_n$ , then integrating by parts yields

$$i(av_n, \beta_n u_n) + (au_{nx}, u_{nx}) + (a_x u_n, u_{nx}) \to 0.$$
 (3.2.33)

We can easily deduce from the first equation of (3.2.27) and (3.2.28) that the first term on the left hand side of (3.2.33) converges to zero. Dividing the first equation of (3.2.27) by  $\beta_n$  yields that  $u_n \to 0$  in  $L^2$ . Therefore, the third term on the left hand side of (3.2.33) also converges to zero. Then it turns out that the second term on the left hand side of (3.2.33) converges to zero, a contradiction. Thus, the proof is complete.

#### 3.3 Linear Viscoelastic System with Memory

In this section we consider the following linear viscoelastic system

$$u_{tt}(t) + A\left[g(0)u(t) + \int_0^{+\infty} g'(s)u(t-s)ds\right] = 0$$
 (3.3.1)

where A is a linear positive definite, self-adjoint unbounded operator on a Hilbert space H and g(s) is a "history kernel" which satisfies the following conditions:

(g1) 
$$g(s) \in C^2(0,+\infty) \cap C[0,+\infty), g' \in L^1(0,+\infty);$$

$$(g2)$$
  $g(s) > 0$ ,  $g'(s) < 0$ ,  $g''(s) > 0$  on  $(0, +\infty)$ ;

- (g3)  $g(+\infty) > 0$ , which is the equilibrium elastic modulus in linear viscoelasticity; without loss of generality, in the sequel we always assume that  $g(+\infty) = 1$ ;
- (g4)  $g''(s) + \delta g'(s) \ge 0$  on  $(0,\infty)$  for some constant  $\delta > 0$ , and there exist positive constants  $s_1, K$  such that for  $s \ge s_1, g''(s) \le K|g'(s)|$ .

Notice that condition (g4) implies that  $\frac{1}{K}g'' \leq -g'(s) \leq -g'(s_1)e^{-\delta(s-s_1)}$  for  $s > s_1 > 0$ . Condition (g1) also allows g' to be singular at s = 0. It is easy to see that the weakly singular kernel of the form

$$g'(s) = -c_1 \frac{e^{-c_3 s}}{s^{c_2}}, \quad 0 < c_2 < 1, \quad c_1, \quad c_3 > 0$$
 (3.3.2)

satisfies the above conditions. This is a fractional derivative model modified by an exponential decay factor. Fractional derivative models have been successfully used to fit experimental complex modulus data for some real materials.

Equation (3.1.1) can be written as an abstract first order evolution equation

$$\frac{dz}{dt} = Az \tag{3.3.3}$$

in a suitable Hilbert space  $\mathcal{H}$ . Let us first establish an abstract setting. Assume that V and H are a pair of Hilbert spaces with  $V \subset H$ , a continuous dense injection. Let  $V^*$  be the dual space of V. We identify H with its dual so that  $V \subset H = H^* \subset V^*$ . Consider a symmetric sesquilinear form  $\sigma$  on V such that

$$|\sigma(u,v)| \le C||u||_V||v||_V \text{ for } u,v \in V$$
 (3.3.4)

$$\sigma(u,u) \geq \omega \|u\|_V^2 \tag{3.3.5}$$

where  $\omega > 0$ . Let  $A \in \mathcal{L}(V, V^*)$  be defined by

$$\sigma(u,v) = \langle Au, v \rangle_{V^*,V} \text{ for } u,v \in V.$$
 (3.3.6)

Then, the restriction of A on H defines a positive definite and self-adjoint operator, which is exactly the operator we work with in the above, with

$$\mathcal{D}(A) = \{ u \in V \mid Au \in H \}. \tag{3.3.7}$$

Furthermore, we have  $\mathcal{D}(A^{\frac{1}{2}}) = V$ , and

$$\sigma(u,v) = \langle A^{\frac{1}{2}}u, A^{\frac{1}{2}}v \rangle_H \quad \text{for } u,v \in V.$$
 (3.3.8)

Thus, V can be equipped with a scalar inner product  $\langle u,v\rangle_V = \sigma(u,v)$ . Let  $W = L_{g'}^2(0,+\infty;V)$  be the Hilbert space of all V-valued, square integrable functions defined on the measure space  $((0,+\infty),V,|g'|ds)$  equipped with the norm

$$||w||_{W} = \left(\int_{0}^{+\infty} |g'(s)| ||w(s)||_{V}^{2} ds\right)^{1/2}.$$
 (3.3.9)

Define

$$v = u_t, \quad w(t,s) = u(t) - u(t-s),$$
 (3.3.10)

for  $t > 0, s \in (0, +\infty)$ . Then equation (3.3.1) can be written as an abstract first order evolution equation (3.3.3) on the Hilbert space  $\mathcal{H} = V \times H \times W$  equipped with the norm

$$||z||_{\mathcal{H}} = \left(||u||_{V}^{2} + ||v||_{H}^{2} + ||w||_{W}^{2}\right)^{1/2}.$$
(3.3.11)

Here  $z = (u, v, w)^T$  and

$$Az = \begin{pmatrix} v \\ -A\left(u - \int_0^{+\infty} g'(s)w(s)ds\right) \\ v - D_s w \end{pmatrix}$$
 (3.3.12)

with

$$\mathcal{D}(\mathcal{A}) = \left\{ z \in \mathcal{H} \mid u - \int_0^{+\infty} g'(s)w(s)ds \in \mathcal{D}(A); \ v \in V; \ D_s w \in W; \ w(0) = 0 \right\}$$

$$(3.3.13)$$

and  $z_0 = (u(+0), v(+0), u(+0) - u(+0-s)), s \in (0, +\infty)$  being the initial history. The energy associated with the viscoelastic system (3.3.3) is defined by

$$E(t) = \frac{1}{2} \|z\|_{\mathcal{H}}^2 \tag{3.3.14}$$

in which three parts are potential, kinetic, and memory energy.

Now let us recall some related works in the literature. When  $A = -\Delta$  subject to the Dirichlet boundary conditions, Dafermos first proved (see Dafermos [2], published in 1970) that E(t) tends to zero asymptotically under the assumptions that g satisfies conditions (g2), (g3) and

$$(g1')$$
  $g' \in C^1[0,\infty), g',g'' \in L^1(0,\infty),$ 

and that g' is convex. Later on, a similar result without the assumption of convexity on g was obtained (see Dafermos [3]). The first result giving an explicit rate at which E(t) decays to zero was provided by Day in 1980 (see Day [2]):

Let

$$a(t) = \int_{t}^{\infty} g(s)ds + a(\infty). \tag{3.3.15}$$

Assume that g(s) satisfies (g1)-(g3), and  $a(t) - a(\infty) \in L^1(\mathbb{R}^+)$  and is log convex. Then  $E(t) = o(t^{-1})$  as  $t \to \infty$  if the initial data  $(u_0)_x$  and  $(u_1)_x$  are uniformly bounded. It was shown by Desch & Miller [1]-[2] that in the case where the kernel g(s) satisfies conditions (g1'), (g2) and (g3), and decays exponentially, the solution u and  $u_t$  will also decay to zero exponentially at a rate no better than the kernel. Note that the initial history was taken to be zero in that paper. The assumption (q1') also excludes the weakly singular kernel (3.3.2) for the interesting fractional derivative model in linear viscoelastic solids. We also refer to Hannsgen & Wheeler [1]-[2] for the results with exponentially decay kernels. Their results also imply the exponential decay rate of the energy function, however, with the additional smoothness assumption on the kernel q(s) and with zero initial history. We also refer the reader to the works by Ito & Fabiano [1]-[2], but their results do not imply the exponential stability of the energy function for the singular kernels. In 1991, Fabrizio & Lazzari [1] investigated the three-dimensional viscoelastic system with memory and obtained the result on the exponential stability of the energy function E(t) with almost the same assumptions on the kernel q as stated here, except that there was no assumption like  $s \geq s_1, g''(s) \leq K|g'(s)|$  in (g4). This assumption seems to be needed for the convergence of  $\int_{s}^{+\infty} g''(s) \|w(s)\|_V^2 ds$ . The method they used is the Laplace transform and the Datko theorem. What we present in this section mainly follows the early paper by the authors (see Liu & Zheng [4]), using the systematic method described in this book. We also refer to the paper Liu & Liu [1] for the spectrum determined growth rate property of this model.

We first prove the following.

**Theorem 3.3.1** The linear operator A, defined by (3.3.12) and (3.3.13), generates a  $C_0$ -semigroup S(t) of contractions on  $\mathcal{H}$ .

This theorem has been proved under a weaker condition on g in Fabiano & Ito [1]. We will give a proof here for the sake of the reader. Before giving the proof of this theorem, we first prove some lemmas.

**Lemma 3.3.1** Suppose that g satisfies the conditions (g1)–(g3). Then for any  $w \in W$  with w(0) = 0 and  $D_s w \in W$ , we have

$$|sg'(s)| \to 0, \quad as \quad s \to 0, \tag{3.3.16}$$

and

$$|g'(s)| ||w(s)||_V^2 \to 0$$
, as  $s \to 0$ . (3.3.17)

**Proof** By condition (g2), g' is monotone increasing and |g'| = -g' is monotone decreasing. By condition (g1), if (3.3.16) is not true, then there is a sequence  $s_n > 0$ ,  $s_n \to 0$  and a constant  $\eta > 0$  such that  $s_n|g'(s_n)| \ge \eta$  for all n. By the monotonicity of g', we have  $s_n|g'(s)| \ge \eta$  for  $s \in (0, s_n)$ . Integrating with respect to s yields that  $0 < \eta \le \int_0^{s_n} |g'(s)| ds \to 0$  as  $s_n$  tends to zero, a contradiction. Thus the proof of (3.3.16) is complete.

The proof of (3.3.17) is very similar. Suppose that (3.3.17) is not true. Then there is a sequence  $s_n > 0$ ,  $s_n \to 0$  and a constant  $\eta > 0$  such that  $|g'(s_n)| ||w(s_n)||_V^2 \ge \eta$ . It follows from

$$w(s_n) = \int_0^{s_n} w'(\tau)d\tau \tag{3.3.18}$$

and the Cauchy-Schwartz inequality that

$$||w(s_n)||_V^2 \le s_n \int_0^{s_n} ||w'(\tau)||_V^2 d\tau. \tag{3.3.19}$$

Since -g'(s) = |g'(s)| is monotone decreasing, we have

$$\eta \le |g'(s_n)| \|w(s_n)\|_V^2 \le s_n \int_0^{s_n} |g'(\tau)| \|w'(\tau)\|_V^2 d\tau \to 0 \quad as \quad s_n \to 0, \tag{3.3.20}$$

a contradiction. Thus the proof of (3.3.17) is complete.

Furthermore, we have the following.

**Lemma 3.3.2** Suppose that g satisfies the conditions (g1)–(g3). Then for any  $w \in W$  with w(0) = 0 and  $D_s w \in W$ , we have

$$\int_{0}^{\infty} g''(s) \|w(s)\|_{V}^{2} ds < \infty, \tag{3.3.21}$$

and

$$|g'(s)| ||w(s)||_V^2 \to 0$$
, as  $s \to +\infty$ . (3.3.22)

**Proof** By condition (g2), for any a>0,  $\int_a^\infty g''(s)\|w(s)\|_V^2 ds < \infty$ . Let  $f(t)=g'(s)\|w(s)\|_V^2$ . Then by the assumptions on w,  $f\in L^1(a,\infty)$ . By the Cauchy-Schwartz inequality,  $f'(s)=g''(s)\|w(s)\|_V^2+2g'(s)(w,w_s)_V$  also belongs to  $L^1(a,\infty)$ . Then by the well-known result in analysis, we can conclude that (3.3.22) holds. To prove (3.3.21), for any small  $\eta>0$  and large M>0, we use integration by parts to obtain that

$$\int_{\eta}^{M} g''(s) \|w(s)\|_{V}^{2} ds$$

$$= g'(M) \|w(M)\|_{V}^{2} - g'(\eta) \|w(\eta)\|_{V}^{2} - 2 \int_{\eta}^{M} g'(s) (w(s), w_{s}(s))_{V} ds. \quad (3.3.23)$$

By the assumptions on w, the third term on the right hand side of (3.3.23) converges as  $M \to \infty$  and  $\eta \to 0$ . The first two terms converge to zero, due to (3.3.22) and (3.3.17). Thus (3.3.21) is proved.

**Proof of Theorem 3.3.1** First we prove that the operator A is dissipative. Indeed, for  $z \in \mathcal{D}(A)$ , we have

$$\langle \mathcal{A}z, z \rangle_{\mathcal{H}} = \langle v, u \rangle_{V} + \langle -A(u - \int_{0}^{\infty} g'(s)w(s)ds), v \rangle_{H}$$

$$+ \langle v - D_{s}w, w \rangle_{W}$$

$$= -\langle D_{s}w, w \rangle_{W}$$

$$= -\frac{1}{2} \int_{0}^{+\infty} g''(s) \|w(s)\|_{V}^{2} ds \leq 0.$$
(3.3.24)

Thus, the operator  $\mathcal{A}$  is dissipative. Next we prove that  $0 \in \rho(\mathcal{A})$ . For any  $F = (f_1, f_2, f_3)^T \in \mathcal{H}$ , consider the unique solvability of the equation

$$Az = F, (3.3.25)$$

i.e.,

$$v = f_1, (3.3.26)$$

$$-A(u - \int_0^\infty g'(s)w(s)ds) = f_2, \tag{3.3.27}$$

$$v - D_s w = f_3. (3.3.28)$$

We can get a unique  $v \in V$  from (3.3.26), and then from (3.3.28) we can get

$$w = \int_0^s (v - f_3(\tau))d\tau = sv - \int_0^s f_3(\tau)d\tau.$$
 (3.3.29)

It is clear that w(0) = 0,  $D_s w \in W$ . To prove that  $w \in W$ , for any T > 0,  $\epsilon > 0$ , by (g4) and the Cauchy-Schwartz inequality, we have

$$\int_{\epsilon}^{T} |g'(s)| ||w(s)||_{V}^{2} ds 
\leq \frac{1}{\delta} \int_{\epsilon}^{T} g''(s) ||w(s)||_{V}^{2} ds 
= \frac{1}{\delta} g'(T) ||w(T)||_{V}^{2} - \frac{1}{\delta} g'(\epsilon) ||w(\epsilon)||_{V}^{2} - \frac{2}{\delta} \int_{\epsilon}^{T} g'(s) \langle w, D_{s} w \rangle_{V} ds 
\leq -\frac{1}{\delta} g'(\epsilon) ||w(\epsilon)||_{V}^{2} + \frac{1}{2} \int_{\epsilon}^{T} |g'(s)| ||w(s)||_{V}^{2} ds 
+ \frac{2}{\delta^{2}} \int_{\epsilon}^{T} |g'(s)| ||D_{s} w||_{V}^{2} ds.$$
(3.3.30)

Thus,

$$\int_{\epsilon}^{T} |g'(s)| \|w(s)\|_{V}^{2} ds \leq -\frac{2}{\delta} g'(\epsilon) \|w(\epsilon)\|_{V}^{2} + \frac{4}{\delta^{2}} \int_{\epsilon}^{T} |g'(s)| \|D_{s}w\|_{V}^{2} ds. \tag{3.3.31}$$

As can be seen from the proof of Lemma 3.2.1, the following holds:

$$-\frac{2}{\delta}g'(\epsilon)\|w(\epsilon)\|_V^2\to 0,\quad \text{as}\quad \epsilon\to 0. \eqno(3.3.32)$$

It turns out from (3.3.31) by letting  $T \to +\infty$  and  $\epsilon \to 0$  that  $w \in W$  and

$$||w||_W^2 \le \frac{4}{\delta^2} \int_0^{+\infty} |g'(s)| ||D_s w||_V^2 ds.$$
 (3.3.33)

Finally we can get a unique  $u \in V$ ,  $u - \int_0^\infty g'(s)w(s)ds \in \mathcal{D}(A)$  by solving (3.3.27). Thus the unique solvability of (3.3.25) with  $z = (u, v, w)^T \in \mathcal{D}(A)$  is proved. Moreover, it can be easily seen from (3.3.26), (3.3.28), (3.3.31), and (3.3.27) that there is a positive constant K independent of  $z = (u, v, w)^T$  such that  $||z||_{\mathcal{H}} \leq K||F||_{\mathcal{H}}$ . This implies that  $0 \in \rho(A)$  and  $||A^{-1}|| \leq K$ . Since A is dissipative, as we have already proved before, by Theorem 1.2.4, A generates a  $C_0$ -semigroup of contractions in  $\mathcal{H}$ .

Furthermore, we have the following theorem.

**Theorem 3.3.2** The semigroup S(t) generated by A is exponentially stable, i.e., there exist two positive constants M,  $\alpha$  such that

$$||S(t)|| \le Me^{-\alpha t}, \ \forall t > 0.$$
 (3.3.34)

**Proof** We still use Theorem 1.3.2 to prove this theorem. The proof consists of the following steps:

(i) Since it has been proved in Theorem 3.2.1 that  $0 \in \rho(\mathcal{A})$ , in the same manner as before, we can show that if (1.3.3) is not true, then there is  $\omega \in \mathbb{R}$  with  $\|\mathcal{A}^{-1}\|^{-1} \le |\omega| < \infty$  such that  $\{i\beta \mid |\beta| < |\omega|\} \subset \rho(\mathcal{A})$  and  $\sup\{\|(i\beta - \mathcal{A})^{-1}\| \mid |\beta| < |\omega|\} = \infty$ . It turns out that there exists a sequence  $\beta_n \in \mathbb{R}$  with  $\beta_n \to \omega$ ,  $|\beta_n| < |\omega|$  and a sequence of complex vector functions  $z_n = (u_n, v_n, w_n)^T \in \mathcal{D}(\mathcal{A})$  with unit norm in  $\mathcal{H}$  such that as  $n \to \infty$ ,

$$i\beta_n z_n - \mathcal{A}z_n \to 0$$
 in  $\mathcal{H}$ , (3.3.35)

i.e.,

$$i\beta_n u_n - v_n \to 0 \quad \text{in} \quad V,$$
 (3.3.36)

$$i\beta_n v_n + A(u - \int_0^\infty g'(s)w_n(s)ds) \to 0 \quad \text{in} \quad H,$$
 (3.3.37)

$$i\beta_n w_n - v_n + D_s w_n \to 0$$
 in  $W$ . (3.3.38)

In the same manner as before, taking the inner product of (3.3.35) with  $z_n$  in  $\mathcal{H}$ , then taking its real part, we obtain

$$Re(\mathcal{A}z_n, z_n)_{\mathcal{H}} = -\frac{1}{2} \int_0^{+\infty} g''(s) \|w_n(s)\|_V^2 ds \to 0.$$
 (3.3.39)

Then it follows from condition (g4) and (3.3.39) that  $w_n \to 0$  in W which implies that

$$||u_n||_V^2 + ||v_n||_H^2 \to 1.$$
 (3.3.40)

Taking the inner product of (3.3.36) with  $v_n$  in H and taking the inner product of (3.3.37) with  $u_n$  in H, respectively, yields

$$i\beta_n(u_n, v_n)_H - ||v_n||_H^2 \to 0,$$
 (3.3.41)

and

$$i\beta_n(v_n, u_n)_H + ||u_n||_V^2 - \int_0^{+\infty} g'(s)(w_n, v_n)_V ds \to 0.$$
 (3.3.42)

By the Cauchy-Schwartz inequality and by the fact that  $w_n \to 0$  in W, the last term in (3.3.42) converges to zero. Adding (3.3.41) and (3.3.42) together, then taking its real part, we get

$$||u_n||_V^2 - ||v_n||_H^2 \to 0. (3.3.43)$$

Thus combining (3.3.43) with (3.3.40) yields

$$||u_n||_V^2 \to \frac{1}{2}, \quad ||v_n||_H^2 \to \frac{1}{2}.$$
 (3.3.44)

In what follows we want to show that this is a contradiction.

It is clear from the conditions imposed on g(s) that both  $s^2g'(s)$  and  $s^2g''(s)$  belong to  $L^1(0,+\infty)$ . We can also easily verify that  $\frac{sv_n}{\beta_n} \in W$ . Dividing (3.3.38) by  $\beta_n$ , then taking the inner product with  $\frac{sv_n}{\beta_n}$  in W and using the fact that  $w_n \to 0$  in W, we obtain that

$$\|\frac{v_n}{\beta_n}\|_V^2 \int_0^{+\infty} s|g'|ds - \frac{1}{\beta_n} \int_0^{+\infty} sg'(s) \langle D_s w_n, \frac{v_n}{\rho_n} \rangle_V ds \to 0. \tag{3.3.45}$$

We now prove that the second term of (3.3.45) converges to zero. First, it follows from the Cauchy-Schwartz inequality, Lemma 3.2.1 and Lemma 3.2.2 that

$$|sg'(s)\langle w_n(s), \frac{v_n}{\beta_n} \rangle_V |$$

$$\leq s|g'(s)| ||w_n(s)||_V ||\frac{v_n}{\beta_n} ||_V$$

$$\leq \frac{s|g'(s)|}{2} (||w_n(s)||_V^2 + ||\frac{v_n}{\beta_n} ||_V^2) \to 0, \quad \text{as} \quad s \to 0$$
(3.3.46)

and

$$\begin{split} & \left| sg'(s) \langle w_n(s), \frac{v_n}{\beta_n} \rangle_V \right| \\ & \leq & s|g'(s)| \|w_n(s)\|_V \|\frac{v_n}{\beta_n} \|_V \\ & \leq & \frac{1}{2} |g'(s)| \|w_n(s)\|_V^2 + \frac{s^2|g'(s)|}{2} \|\frac{v_n}{\beta_n}\|_V^2 \to 0, \quad \text{as} \quad s \to +\infty. \end{split} \tag{3.3.47}$$

Then we use integration by parts, the Cauchy-Schwartz inequality, (3.3.39) and the fact that  $w_n \to 0$  in W to obtain

$$\left| -\int_{0}^{+\infty} sg'(s) \langle D_{s}w_{n}, \frac{v_{n}}{\beta_{n}} \rangle_{V} ds \right| 
= \left| \int_{0}^{+\infty} sg''(s) \langle w_{n}, \frac{v_{n}}{\beta_{n}} \rangle_{V} ds + \int_{0}^{+\infty} g'(s) \langle w_{n}, \frac{v_{n}}{\beta_{n}} \rangle_{V} ds \right| 
\leq \frac{1}{2} \left( \int_{0}^{+\infty} g''(s) ||w_{n}||_{V}^{2} ds \right)^{\frac{1}{2}} + \frac{1}{2} \left( \int_{0}^{+\infty} s^{2} g''(s) ds \right)^{\frac{1}{2}} ||\frac{v_{n}}{\beta_{n}}||_{V} 
+ ||w_{n}||_{W} \left( \int_{0}^{+\infty} |g'(s)| ds \right)^{\frac{1}{2}} ||\frac{v_{n}}{\beta_{n}}||_{V} \to 0.$$
(3.3.48)

Therefore, we can deduce from (3.3.45) that

$$\|\frac{v_n}{\beta_n}\|_V^2 \to 0.$$
 (3.3.49)

It follows from (3.3.36) divided by  $\beta_n$  that

$$u_n \to 0 \quad \text{in} \quad V. \tag{3.3.50}$$

A contradiction. Thus the proof of (1.3.3) is proved.

(ii) Since in the above proof in (i) we only use the fact that  $|\beta_n|$  is bounded below from zero, the proof of (1.3.4) is exactly the same as that in (i). So we can omit the detail here.

Remark 3.3.1 It is known that for the system with history memory, in general we cannot expect that the corresponding semigroup is analytic. (see, for instance, Liu & Liu [1]).

## 3.4 The Linear Viscoelastic Kirchhoff Plate with Memory

In this section, we turn to the study of the semigroup associated with the linear viscoelastic Kirchhoff plate with memory. Suppose that a thin plate of the Kirchhoff type occupies a bounded region  $\Omega \in \mathbb{R}^2$  with smooth boundary  $\Gamma = \Gamma_0 \cup \Gamma_1 \cup \Gamma_2$ . When the viscoelastic damping is considered, the vertical deflection of the plate satisfies

$$w_{tt}(t) - \gamma \Delta w_{tt}(t) + \Delta^2 g(0)w(t) + \Delta^2 \int_0^\infty g'(s)w(t-s)ds = 0$$
 (3.4.1)

with  $\gamma \geq 0$  (see Lagnese [3]). The boundary conditions considered in this section are the following:

$$w = \frac{\partial w}{\partial \nu} = 0 \quad \text{on } \Gamma_0, \quad t > 0, \tag{3.4.2}$$

$$w = \mathcal{B}_1 \left( w(t) + \int_0^\infty g'(s)w(t-s)ds \right) = 0 \text{ on } \Gamma_1, \quad t > 0,$$
 (3.4.3)

and

$$\begin{cases} \mathcal{B}_1(w(t) + \int_0^\infty g'(s)w(t-s)ds) = 0\\ \mathcal{B}_2(w(t) + \int_0^\infty g'(s)w(t-s)ds) - \gamma \frac{\partial w_{tt}}{\partial \nu} = 0 \end{cases}$$
 on  $\Gamma_2$ ,  $t > 0$  (3.4.4)

where

$$\mathcal{B}_1 w = \Delta w + (1 - \mu) B_1 w, \quad \mathcal{B}_2 w = \frac{\partial \Delta w}{\partial \nu} + (1 - \mu) \frac{\partial B_2 w}{\partial \tau}$$
 (3.4.5)

with the operators  $B_1, B_2$  being the same as in Chapter 2:

$$\begin{cases}
B_1 w = 2\nu_1 \nu_2 \frac{\partial^2 w}{\partial x \partial y} - \nu_1^2 \frac{\partial^2 w}{\partial y^2} - \nu_2^2 \frac{\partial^2 w}{\partial x^2}, \\
B_2 w = (\nu_1^2 - \nu_2^2) \frac{\partial^2 w}{\partial x \partial y} + \nu_1 \nu_2 (\frac{\partial^2 w}{\partial y^2} - \frac{\partial^2 w}{\partial x^2})
\end{cases}$$
(3.4.6)

and  $\nu=(\nu_1,\nu_2)$  being the unit outward normal to  $\Gamma$ , and  $\tau=\{-\nu_2,\nu_1\}$ . In (3.4.5),  $\mu$  ( $\frac{1}{2}>\mu>0$ ) is the Poisson ratio. In the sequel, we always assume that  $\Gamma_0 \cup \Gamma_1 \neq \emptyset$  and  $\bar{\Gamma}_0 \cap \bar{\Gamma}_1 \cap \bar{\Gamma}_2 = \emptyset$ .

We still make the same assumptions (g1)-(g4) on the relaxation function g as in the previous section. The initial state of the plate is

$$w(0+) = w^0, \ w'(0+) = w^1, \ w(-s) = w_h(s), \ \text{for } 0 < s < \infty$$
 (3.4.7)

with  $w^0, w^1, w_h$  being given functions.

In order to convert the problem to a first-order evolution equation, as in Chapter 2 for the Linear Kirchhoff plate with thermal damping, we use the variational approach. Let

$$H = H^{1}_{\Gamma_{0} \cup \Gamma_{1}} = \{ u \mid u \in H^{1}(\Omega), u|_{\Gamma_{0} \cup \Gamma_{1}} = 0 \}, \tag{3.4.8}$$

and

$$V = H_{\Gamma_0}^2 \cap H_{\Gamma_1}^1 = \{ v \mid v \in H^2(\Omega), v|_{\Gamma_0} = \frac{\partial v}{\partial \nu}|_{\Gamma_0} = v|_{\Gamma_1} = 0 \}.$$
 (3.4.9)

For  $u, v \in V$ , as in Chapter 2, we define

$$\begin{array}{rcl} a(u,v) & = & \int_{\Omega} [u_{xx}\bar{v}_{xx} + u_{yy}\bar{v}_{yy} + \mu(u_{xx}\bar{v}_{yy} + u_{yy}\bar{v}_{xx}) \\ & & + 2(1-\mu)u_{xy}\bar{v}_{xy}]dxdy. \end{array} \tag{3.4.10}$$

We simply denote a(u, u) by a(u). H and V are equipped with the following norms, respectively:

$$||w||_{H} = (||w||^{2} + \gamma ||\nabla w||^{2})^{\frac{1}{2}},$$
 (3.4.11)

and

$$||w||_V = a(w)^{\frac{1}{2}}. (3.4.12)$$

Since  $\Gamma_0 \cup \Gamma_1 \neq \emptyset$ , the norm defined in (3.4.12) is an equivalent norm in  $H^2$ . It is clear from Chapter 1 that V is dense and continuously imbedded in H. Therefore, there is a self-adjoint and positive definite operator A with  $\mathcal{D}(A) = \{u | u \in V, Au \in H\}$  such that  $(A^{\frac{1}{2}}u, A^{\frac{1}{2}}v)_H = (u, v)_V$ .

The total energy corresponding to (3.4.1)-(3.4.6) is defined by

$$E(t) = \frac{1}{2} \int_{\Omega} \left( a(w(t)) + [w_t(t)]^2 + \gamma [\nabla w_t(t)]^2 \right) d\Omega - \frac{1}{2} \int_0^{\infty} \int_{\Omega} g'(s) a(w(t) - w(t - s)) d\Omega ds.$$
(3.4.13)

Suppose now that w is a regular solution to the problem (3.4.1)–(3.4.6), and (3.4.7). We introduce

$$v = w_t, \quad h = w(t) - w(t - s).$$
 (3.4.14)

Then we multiply (3.4.1) by  $\hat{w} \in V$  and take integration by parts to get

$$(v_t, \hat{w})_H + a(w, \hat{w}) + a(\int_0^{+\infty} -g'(s)h(s)ds, \hat{w}) = 0.$$
 (3.4.15)

Let  $W = L^2(0, \infty; |g'(\cdot)|; V)$  equipped with the norm

$$||h||_{W} = \left(\int_{0}^{+\infty} |g'(s)| ||h(s)||_{V}^{2} ds\right)^{\frac{1}{2}}$$
(3.4.16)

and let  $\mathcal{H} = V \times H \times W$ . Since V is dense in H, it follows from (3.4.15) that

$$v_t = -A(w - \int_0^{+\infty} g'(s)h(s)ds).$$
 (3.4.17)

By the definition of h, it is clear that

$$h_t = v - D_s h. (3.4.18)$$

Let  $z = (w, v, h)^T$ . Then (3.4.14), (3.4.17), and (3.4.18) are reduced to an abstract first-order evolution equation

$$\frac{dz}{dt} = \mathcal{A}z\tag{3.4.19}$$

with

$$Az = \begin{pmatrix} v \\ -A\left(w - \int_0^{+\infty} g'(s)h(s)ds\right) \\ v - D_s h \end{pmatrix}, \tag{3.4.20}$$

$$\mathcal{D}(\mathcal{A}) = \left\{ z \in \mathcal{H} \mid w - \int_0^{+\infty} g'(s)h(s)ds \in \mathcal{D}(A); \ v \in V; \ D_s h \in W; \ h(0) = 0 \right\},$$
(3.4.21)

and

$$z|_{t=0} = z_0 = (w^0, w^1, w^0 - w_h(+0 - s))^T, \ s \in (0, +\infty).$$
 (3.4.22)

¿From the above reduction, the initial value problem (3.4.19)–(3.4.22) in  $\mathcal{H}$  can be considered as the weak formulation for the problem (3.4.1)–(3.4.6), and (3.4.7). Notice that the setting here exactly falls into the general framework discussed in the previous section. Therefore, from Theorem 3.2.1 and Theorem 3.2.2, we immediately have the following.

**Theorem 3.4.1** The operator A defined by (3.4.20) generates a  $C_0$ -semigroup S(t) of contractions in  $\mathcal{H}$ . Moreover, the semigroup S(t) is exponentially stable, i.e., there exist two positive constants  $M, \alpha$  such that

$$||S(t)|| \le Me^{-\alpha t}, \quad \forall t > 0.$$
 (3.4.23)

**Remark 3.4.1** As the same as in the previous section, in general, the semigroup S(t) is not analytic.

## Chapter 4

#### Linear Thermoviscoelastic Systems

In this chapter we will discuss the semigroup associated with the linear thermoviscoelastic system. In other words, the dissipative mechanisms is not solely due to heat conduction or viscous damping. Instead, we will consider the problems with both dissipative mechanisms. In the first section, we are concerned with motion of a rod of length l with the dissipative mechanism of heat conduction and viscous damping of rate type. We will prove that the semigroup associated with that system is not only exponentially stable, but also is analytic. As we have seen from previous two chapters, heat conduction is not strong enough to make the semigroup analytic, while the viscous damping of rate type itself is strong enough to do so. The results shown in the first section of this chapter, therefore, is not surprising because we now have both dissipative mechanism. In the second section of this chapter we will discuss the linear three-dimensional thermoviscoelastic system in which both heat conduction and viscous damping have memory. Under certain conditions on the relaxation functions we will prove that the corresponding semigroup is exponentially stable. As remarked in Chapter 3, with this kind of memory, in general, we cannot expect that the corresponding semigroup is analytic.

## 4.1 Linear One-Dimensional Thermoviscoelastic System

In this section we consider the following linear system of partial differential equations in  $(0, l) \times (0, \infty)$ :

$$\begin{cases} u_{1t} - \alpha u_{2x} = 0, \\ u_{2t} - \alpha u_{1x} + \beta u_{3x} - \mu u_{2xx} = 0, \\ u_{3t} + \beta u_{2x} - k u_{3xx} = 0 \end{cases}$$

$$(4.1.1)$$

with constants  $\alpha > 0, \beta \neq 0, \mu > 0, k > 0$ . Here the subscripts t and x denote the partial derivatives with respect to t and x, respectively. This system is a model of linear one-dimensional thermoviscoelasticity with  $u_1$  being the scaled deformation gradient,  $u_2$  the velocity, and  $u_3$  the deviation of temperature from a given temperature. (4.1.1) is also a linearized system for motion of compressible viscous and heat-conductive fluids in Lagrange coordinates. System (4.1.1) is supplemented by initial conditions:

$$u_1|_{t=0} = u_1^0(x), \ u_2|_{t=0} = u_2^0(x), \ u_3|_{t=0} = u_3^0(x)$$
 (4.1.2)

and boundary conditions. As in Chapter 2, various kinds of boundary conditions can be considered. To fix our idea, without loss of generality, let us consider the following boundary conditions for system (4.1.1):

$$u_2|_{x=0} = u_2|_{x=l} = u_3|_{x=0} = u_3|_{x=l} = 0.$$
 (4.1.3)

The mechanical meaning of the boundary conditions is clear: the rod of length l is clamped at both ends and the deviation of temperature is given (to be zero). It follows from the first equation of (4.1.1) and the boundary conditions  $u_2|_{x=0,l}=0$  that  $\int_0^l u_{1t}dx=0$ , i.e.,  $\int_0^l u_1dx$  is conserved for  $t\geq 0$ . Without loss of generality, we assume that  $\int_0^l u_1dx=0$ . Otherwise, we can make the substitution  $\tilde{u}_1=u_1-\frac{1}{l}\int_0^l u_1^0(x)dx$  which does not change the system (4.1.1). We can now rewrite problem (4.1.1)-(4.1.3) as a first-order evolution system on the Hilbert space  $\mathcal{H}=\{z|u_1\in L^2,\ u_2\in L^2,\ u_3\in L^2,\ \int_0^l u_1dx=0\}$ :

$$\begin{cases} \frac{dz}{dt} = \mathcal{A}z, \\ z|_{t=0} = z_0(x) = (u_1^0, u_2^0, u_3^0)^T \end{cases}$$
 (4.1.4)

with  $z = (u, v, w)^T = (u_1, u_2, u_3)^T$ ,

$$\mathcal{A}z = \begin{pmatrix} \alpha D u_2 \\ D(\alpha u_1 + \mu D u_2) - \beta D u_3 \\ -\beta D u_2 + k D^2 u_3 \end{pmatrix}$$

$$(4.1.5)$$

and

$$\mathcal{D}(\mathcal{A}) = \left\{ z \in \mathcal{H} \middle| \alpha u_1 + \mu D u_2 \in H^1, \int_0^l u_1 dx = 0, u_2 \in H_0^1, u_3 \in H^2 \cap H_0^1 \right\}.$$
(4.1.6)

Now we have the next theorem.

**Theorem 4.1.1** The operator A generates a  $C_0$ -semigroup S(t) of contractions in  $\mathcal{H}$ . Moreover, the semigroup is exponentially stable, i.e., there exist two positive constants  $M, \alpha$  such that

$$||S(t)|| \le Me^{-\alpha t}, \quad \forall t > 0.$$
 (4.1.7)

**Proof** This theorem has been proved by one of the authors, S. Zheng, in his monograph (Zheng [1]) by the energy method. Now we use the systematic method described in this book to give a new proof.

For  $z \in \mathcal{D}(A)$ , we have

$$(\mathcal{A}z, z)_{\mathcal{H}}$$

$$= \int_{0}^{l} (\alpha u_{1} D u_{2} + u_{2} D (\alpha u_{1} + \mu D u_{2}) - \beta u_{2} D u_{3} - \beta u_{3} D u_{2} + k u_{3} D^{2} u_{3}) dx$$

$$= -\mu \|D u_{2}\|^{2} - k \|D u_{3}\|^{2} \leq 0.$$
(4.1.8)

Thus, the operator  $\mathcal{A}$  is dissipative. We now further prove that  $0 \in \rho(\mathcal{A})$ . For any  $F = (f_1, f_2, f_3)^T \in \mathcal{H}$ , we consider

$$Az = F. (4.1.9)$$

It turns out from the first equation of the vector form (4.1.9) that  $u_2$  is uniquely given by

$$u_2 = \frac{1}{\alpha} \int_0^x f_1 dx \in H_0^1. \tag{4.1.10}$$

Substituting this expression of  $u_2$  into the third equation of (4.1.9), we get

$$kD^2u_3 = f_3 + \beta Du_2 \in L^2. (4.1.11)$$

It follows from the standard result in the linear elliptic equations that (4.1.11) has a unique solution  $u_3 \in H^2 \cap H_0^1$ . Once  $u_2, u_3$  have been obtained, it turns out from the

second equation of (4.1.9) that  $u_1$  is uniquely given by

$$u_1 = \frac{1}{\alpha} \left( \int_0^x f_2(\xi) \, d\xi + C - \mu D u_2 + \beta u_3 \right) \tag{4.1.12}$$

with

$$C = -\frac{1}{l} \left( \beta \int_0^l u_3 dx + \int_0^l \int_0^x f_2 d\xi dx \right). \tag{4.1.13}$$

Thus  $\mathcal{A}$  is invertible with  $\mathcal{A}^{-1}$  being a bounded operator from  $\mathcal{H}$  to  $\mathcal{H}$ . By Theorem 1.2.4, we can conclude that  $\mathcal{A}$  generates a  $C_0$ -semigroup of contractions in  $\mathcal{H}$ . We now want to apply Theorem 1.3.2 to prove that the semigroup S(t) is exponentially stable. The proof consists of the following steps:

(i) Since  $0 \in \rho(\mathcal{A})$ , it follows from Remark 2.1.1 and the contraction mapping theorem that for any real number  $\beta$  with  $|\beta| < \|\mathcal{A}^{-1}\|^{-1}$ , the operator  $i\beta I - \mathcal{A} = \mathcal{A}(i\beta\mathcal{A}^{-1} - I)$  is invertible. Moreover,  $\|(i\beta I - \mathcal{A})^{-1}\|$  is a continuous function of  $\beta$  in  $(-\|\mathcal{A}^{-1}\|^{-1}, \|\mathcal{A}^{-1}\|^{-1})$ . Thus, if (1.3.3) is not true, then there is  $\omega \in \mathbb{R}$  with  $\|\mathcal{A}^{-1}\|^{-1} \le |\omega| < \infty$  such that  $\{i\beta \mid |\beta| < |\omega|\} \subset \rho(\mathcal{A})$  and  $\sup\{\|(i\beta - \mathcal{A})^{-1}\| \mid |\beta| < |\omega|\} = \infty$ . It turns out that there exists a sequence  $\beta_n \in \mathbb{R}$  with  $\beta_n \to \omega$ ,  $|\beta_n| < |\omega|$  and a sequence of complex vector functions  $z_n = (u_n, v_n, w_n)^T \in \mathcal{D}(\mathcal{A})$  with unit norm in  $\mathcal{H}$  such that

$$\|(\boldsymbol{i}\beta_n I - \mathcal{A})z_n\|_{\mathcal{H}} \to 0, \tag{4.1.14}$$

as  $n \to \infty$ , i.e.,

$$i\beta_n u_n - \alpha D v_n \to 0 \quad \text{in} \quad L^2,$$
 (4.1.15)

$$i\beta_n v_n - D(\alpha u_n + \mu D v_n) + \beta D w_n \to 0 \quad \text{in} \quad L^2,$$
 (4.1.16)

$$i\beta_n w_n + \beta D v_n - k D^2 w_n \to 0 \quad \text{in} \quad L^2.$$
 (4.1.17)

Taking the inner product of  $(i\beta_n I - A)z_n$  with  $z_n$  in  $\mathcal{H}$  and then taking its real part yields

$$Re((i\beta_n I - A)z_n, z_n)_{\mathcal{H}} = -\mu ||Dv_n||^2 - k||Dw_n||^2 \to 0.$$
 (4.1.18)

Thus it follows from the Poincaré inequality that

$$v_n \to 0, \quad w_n \to 0 \quad \text{in } L^2.$$
 (4.1.19)

Dividing (4.1.15) by  $\beta_n$  and using (4.1.18), we obtain that

$$u_n \to 0 \quad \text{in } L^2. \tag{4.1.20}$$

Thus, we get a contradiction. The proof of (1.3.3) is complete.

(ii) To prove (1.3.4), we use a contradiction argument again. If (1.3.4) is not true, then there exists a sequence  $\beta_n \in \mathbb{R}$  with  $|\beta_n| \to +\infty$  and a sequence of complex vector functions  $z_n = (u_n, v_n, w_n)^T \in \mathcal{D}(\mathcal{A})$  with unit norm in  $\mathcal{H}$  such that (4.1.14) holds. Following exactly the same argument as in (i) yields a contradiction again. Thus, the proof is complete.

Furthermore, we have the following theorem.

**Theorem 4.1.2** The semigroup S(t), generated by A, is analytic.

**Proof** This theorem has been proved in Liu & Yong [1] as an example of their general theorem. Now we give a direct proof. By Theorem 1.3.3, it suffices to prove that (1.3.8) holds. We use a contradiction argument again. Suppose that (1.3.8) is not true. Then there exists a sequence  $\beta_n \in \mathbb{R}$  with  $|\beta_n| \to +\infty$  and a sequence of complex vector functions  $z_n = (u_n, v_n, w_n)^T \in \mathcal{D}(\mathcal{A})$  with unit norm in  $\mathcal{H}$  such that

$$iz_n - \frac{1}{\beta_n} \mathcal{A} z_n \to 0 \quad \text{in} \quad \mathcal{H},$$
 (4.1.21)

as  $n \to \infty$ , i.e.,

$$iu_n - \frac{\alpha}{\beta_n} Dv_n \to 0 \quad \text{in} \quad L^2,$$
 (4.1.22)

$$iv_n - \frac{1}{\beta_n}(D(\alpha u_n + \mu D v_n) - \beta D w_n) \to 0 \quad \text{in} \quad L^2,$$
 (4.1.23)

$$iw_n + \frac{1}{\beta_n}(\beta Dv_n - kD^2w_n) \to 0 \text{ in } L^2.$$
 (4.1.24)

Taking the inner product of  $(iI - \frac{1}{\beta_n}A)z_n$  with  $z_n$  in  $\mathcal{H}$  and then taking its real part yields

$$Re((iI - \frac{1}{\beta_n} \mathcal{A})z_n, z_n)_{\mathcal{H}} = -\frac{1}{\beta_n} (\mu \|Dv_n\|^2 + k \|Dw_n\|^2) \to 0.$$
 (4.1.25)

Then it follows from (4.1.25), (4.1.23) and (4.1.24) that

$$iv_n - \frac{1}{\beta_n}D(\alpha u_n + \mu Dv_n) \to 0 \quad \text{in } L^2,$$
 (4.1.26)

$$iw_n - \frac{k}{\beta_n}D^2w_n \to 0 \quad \text{in } L^2.$$
 (4.1.27)

Taking the inner product of (4.1.27) with  $w_n$  in  $L^2$ , then integrating by parts and using (4.1.25), we get  $w_n \to 0$  in  $L^2$ . Taking the inner product of (4.1.26) with  $v_n$  in  $L^2$ , then integrating by parts, we get

$$|i||v_n||^2 + \frac{1}{\beta_n}((\alpha u_n, Dv_n) + \mu ||Dv_n||^2) \to 0.$$
 (4.1.28)

Using (4.1.25) and the fact that  $||u_n|| \le 1$ , we deduce from (4.1.28) that

$$||v_n||^2 \to 0. \tag{4.1.29}$$

It immediately follows from (4.1.25) and (4.1.22) that  $u_n \to 0$  in  $L^2$ . Thus, we get a contradiction again. The proof is complete.

## 4.2 Linear Three-Dimensional Thermoviscoelastic System with Memory

In this section we are concerned with the linear three-dimensional thermoviscoelastic system with fading memory.

Suppose that a body occupies a bounded domain  $\Omega \subset \mathbb{R}^3$  with smooth boundary  $\Gamma$ . We assume that the reference configuration is a natural state in which stress is zero and base temperature  $\theta_0$  is a strictly positive constant. Let  $x \in \Omega$  be the position of a material point at time t and let u(x,t) be the displacement, which is a vector function valued in  $\mathbb{R}^3$ , and let  $\theta(x,t)$  be the temperature difference from  $\theta_0$ , which is a scalar function. If we assume that the Cauchy stress T and the specific entropy difference  $\eta$  are given by functionals depending on both displacement and temperature difference history in the following form: (see Marsden & Hugens [1], Navarro [1], and Coleman & Mizel [1]):

$$T(x,t) = g(x,0)\nabla u(x,t) - \theta(x,t)l(x,0)$$

$$+ \int_0^\infty (g'(x,s)\nabla u(x,t-s) - l'(x,s)\theta(x,t-s))ds, \qquad (4.2.1)$$

$$\rho(x)\eta(x,t) = \boldsymbol{l}(x,0) \cdot \nabla \boldsymbol{u}_{t}(x,t) + \rho(x)c(x,0)\frac{\theta(x,t)}{\theta_{0}} + \int_{0}^{\infty} \left[\boldsymbol{l}'(x,s) \cdot \nabla \boldsymbol{u}_{t}(x,t-s) + \rho(x)c'(x,s)\frac{\theta(x,t-s)}{\theta_{0}}\right] ds \ (4.2.2)$$

where  $\rho(x)$  is the mass density in the natural state and the prime denotes the derivative with respect to s. The material functions g(x,s), l(x,s) and c(x,s) are the relaxation tensors of fourth, second and zero order, respectively. Their values at s=0 are called the instantaneous elastic modulus, instantaneous stress-temperature tensor, and instantaneous specific heat, respectively.

We assume Fourier's law for the heat flux vector q(x,t):

$$\mathbf{q}(x,t) = -\kappa(x)\nabla\theta(x,t) \tag{4.2.3}$$

where  $\kappa(x)$  is the thermal conductivity in the reference configuration and it is a tensor of second order. Let v denote velocity. Then the equations for balance of momentum and energy read as follows:

$$\rho(x)\mathbf{v}_t(x,t) = \operatorname{div} \mathbf{T}(x,t), \tag{4.2.4}$$

$$\theta_0 \rho(x) \eta_t(x,t) + \operatorname{div} \mathbf{q}(x,t) = 0 \tag{4.2.5}$$

where the subscript t denotes the partial derivative with respect to t.

Substituting the expressions given by (4.2.1) and (4.2.3) into (4.2.4) and (4.2.5), we obtain the following equations for a body in  $\mathbb{R}^3$  composed of a non-homogeneous anisotropic linear thermoviscoelastic material:

$$\rho(x)\boldsymbol{u}_{tt}(x,t) = \boldsymbol{div}\left[\boldsymbol{g}(x,0)\nabla\boldsymbol{u}(x,t) - \boldsymbol{\theta}(x,t)\boldsymbol{l}(x,0) + \int_{0}^{\infty} (\boldsymbol{g}'(x,s)\nabla\boldsymbol{u}(x,t-s) - \boldsymbol{l}'(x,s)\boldsymbol{\theta}(x,t-s))ds\right], \quad (4.2.6)$$

$$\rho(x)c(x,0)\boldsymbol{\theta}_{t}(x,t) = \boldsymbol{div}\left[\boldsymbol{\kappa}(x)\nabla\boldsymbol{\theta}(x,t)\right] - \boldsymbol{\theta}_{0}\boldsymbol{l}(x,0) \cdot \nabla\boldsymbol{u}_{t}(x,t) - \int_{0}^{\infty} \left[\boldsymbol{\theta}_{0}\boldsymbol{l}'(x,s) \cdot \nabla\boldsymbol{u}_{t}(x,t-s) + \rho(x)c'(x,s)\boldsymbol{\theta}_{t}(x,t-s)\right]ds \quad (4.2.7)$$

for  $(x,t) \in \Omega \times \mathbb{R}^+$ ,  $\Omega \subset \mathbb{R}^3$ . The boundary conditions considered here are

$$\boldsymbol{u}(x,t) = 0, \quad \theta(x,t) = 0 \quad \text{on } \Gamma \times \mathbb{R}^+$$
 (4.2.8)

while the prescribed initial histories for the displacement and temperature difference are given by

$$u(x, -s) = w_0(x, s), \quad \theta(x, -s) = y_0(x, s), \quad x \in \bar{\Omega}, \ s \in \mathbb{R}^+.$$
 (4.2.9)

We refer the reader to Navarro [1] for the derivation of the equations and for the results on the existence, uniqueness, and asymptotic stability of the generalized solutions as well as the semigroup approach. However, the issue of the exponential stability of the semigroup was not discussed in that paper. Our main purpose in this section is to prove that under certain reasonable assumptions on material properties, the semigroup associated with the prior mentioned system is exponentially stable. In this direction, we refer to the paper Liu & Zheng [4] by the authors on the exponential stability of the semigroup associated with the linear one-dimensional thermoviscoelastic system with fading memory for the displacement. We also refer to the recent work Rivera & Barreto [1] for the results on the exponential stability for the linear three-dimensional thermoviscoelastic system. In that paper the assumptions on material properties are quite special and it can be considered as a special case for our problem considered here. Besides, the relaxation functions are not allowed to have singularity at s=0 in Rivera & Barreto [1]. The method used in that paper is the energy method. It turns out that more regularity requirements are needed for the relaxation functions.

The main assumptions made on the material properties are the following:

 $(H_1)$   $g, l, c, \kappa, \rho$  are independent of the space variable x. This assumption is not essential and is only for the simplicity of exposition.  $\rho > 0$ .

$$(H_2) \ \boldsymbol{g}(s) = \boldsymbol{g}^T(s), \text{ i.e. } g_{ijkl}(s) = g_{klij}(s) \, (i,j,k,l=1,2,3), \text{ for } s \geq 0;$$

$$\boldsymbol{g}(s) \in C[0,\infty), \boldsymbol{g}'(s) \in L^1(0,\infty) \cap C^1(0,\infty), \text{ i.e. } g_{ijkl}(s) \in C[0,\infty), \ g'_{ijkl}(s)$$

$$\in L^1(0,\infty) \cap C^1(0,\infty); \text{ there is a positive constant } \delta > 0 \text{ such that for any}$$

$$\xi_{ij} \in \mathbb{R}, i,j=1,2,3,$$

$$g_{ijkl}^{\infty} \xi_{ij} \xi_{kl} \ge \delta \xi_{ij}^2 \tag{4.2.10}$$

where  $g_{ijkl}^{\infty} = \lim_{s \to \infty} g_{ijkl}(s)$  and hereafter the summation convention is used.

There exists a positive, monotone decreasing scalar function  $g_1(s) \in L^1(0,\infty) \cap$  $C^1(0,\infty)$  and constants  $k_1>1, k_2, s_1>0$  such that

$$k_1 g_1(s) \xi_{ij}^2 \ge -g'_{ijkl}(s) \xi_{ij} \xi_{kl} \ge g_1(s) \xi_{ij}^2, \ \forall s > 0$$
 (4.2.11)

and

$$k_2 g_1(s) \xi_{ij}^2 \ge g_{ijkl}''(s) \xi_{ij} \xi_{kl}, \quad \forall s > s_1,$$
 (4.2.12)

for all  $\xi_{ij} \in IR, i, j = 1, 2, 3$ .

 $(H_3)$   $\kappa=\kappa^T$  and there is a constant  $\delta>0$  such that for all  $\xi_i\in I\!\!R, i=1,2,3,$ 

$$\kappa_{ij}\xi_i\xi_j \ge \delta\xi_i^2. \tag{4.2.13}$$

 $(H_4)$   $c(s) \in C[0,+\infty), c'(s) \in L^1(0,\infty) \cap C^1(0,\infty)$  and there are positive constants  $c_o, s_1, k_3$  such that

$$c(0) \ge c_o > 0, \tag{4.2.14}$$

$$c'(s) > 0, \quad c''(s) \le 0, \quad \forall s > 0,$$
 (4.2.15)

$$k_3c'(s) \ge -c''(s), \quad \forall s > s_1.$$
 (4.2.16)

 $(H_5)$   $l(s) = l^T(s)$ , i.e.,  $l_{ij}(s) = l_{ji}(s)$  for  $s \ge 0$ ;  $l(s) \in C[0, +\infty)$ ,  $l'(s) \in L^1(0, \infty)$  $\bigcap C^1(0,\infty)$ . Furthermore, there is a constant  $\alpha \in (0,1)$  such that

$$||l'(s)|| = (l'_{ij}(s)l'_{ij}(s))^{\frac{1}{2}} \le \alpha(g_1(s))^{\frac{1}{2}} \left(\frac{\rho}{\theta_0}c'(s)\right)^{\frac{1}{2}}, \quad \forall s > 0, \quad (4.2.17)$$

$$||l''(s)|| = (l''_{ij}(s)l''_{ij}(s))^{\frac{1}{2}} \le \alpha(g_1(s))^{\frac{1}{2}} (-\frac{\rho}{\rho}c''(s))^{\frac{1}{2}}, \quad \forall s > 0, \quad (4.2.18)$$

 $\|\boldsymbol{l}''(s)\| = (l_{ij}''(s)l_{ij}''(s))^{\frac{1}{2}} \le \alpha(g_1(s))^{\frac{1}{2}} (-\frac{\rho}{\theta_0}c''(s))^{\frac{1}{2}}, \quad \forall s > 0. \quad (4.2.18)$ 

These assumptions on material properties are quite comparable with those made in Navarro [1]. Notice that we now allow g'(s), l'(s) and c'(s) to have singularity at s = 0(see Chapter 3 in this aspect). We will use the semigroup approach to prove that under these assumptions, the initial boundary value problem for the linear three-dimensional thermoviscoelastic system with memory (4.2.6)-(4.2.9) defines a  $C_0$ -semigroup in an

appropriate Hilbert space. We will also prove the exponential stability of that semigroup under the following additional assumptions on g(s) and c(s):

 $(H_6)$ 

$$g''_{ijkl}(s)\xi_{ij}\xi_{kl} \ge g_1(s)\xi_{ij}^2, \quad \forall s > 0, \forall \xi_{ij} \in \mathbb{R}$$
 (4.2.19)

where  $g_1$  also satisfies the following further assumption:

$$-k_4 g_1'(s) \ge g_1(s), \quad \forall s > 0$$
 (4.2.20)

with  $k_4$  being a given positive constant.

 $(H_7)$  There is a positive constant  $k_5$  such that

$$-k_5c''(s) \ge c'(s), \quad \forall s > 0.$$
 (4.2.21)

Let

$$\mathbf{w}(x,t,s) = \mathbf{u}(x,t) - \mathbf{u}(x,t-s), \ \ y(x,t,s) = \theta(x,t-s).$$
 (4.2.22)

Define the Hilbert space

$$\mathcal{H} = \boldsymbol{H}_{0}^{1}(\Omega) \times \boldsymbol{L}^{2}(\Omega) \times L^{2}(\Omega) \times \boldsymbol{L}_{\boldsymbol{g}}^{2}(0, +\infty; \boldsymbol{H}_{0}^{1}(\Omega)) \times L_{c}^{2}(0, +\infty; L^{2}(\Omega))$$

$$= U \times V \times \Theta \times W \times Y$$
(4.2.23)

equipped with the following inner product:

for 
$$z_{1} = (\boldsymbol{u}_{1}, \boldsymbol{v}_{1}, \theta_{1}, \boldsymbol{w}_{1}, y_{1})^{T}, z_{2} = (\boldsymbol{u}_{2}, \boldsymbol{v}_{2}, \theta_{2}, \boldsymbol{w}_{2}, y_{2})^{T} \in \mathcal{H},$$

$$(z_{1}, z_{2})_{\mathcal{H}}$$

$$= (\boldsymbol{u}_{1}, \boldsymbol{u}_{2})_{U} + (\boldsymbol{v}_{1}, \boldsymbol{v}_{2})_{V} + (\theta_{1}, \theta_{2})_{\Theta} + (\{\boldsymbol{w}_{1}, y_{1}\}, \{\boldsymbol{w}_{2}, y_{2}\})_{W \times Y}$$

$$= \int_{\Omega} \left[ \boldsymbol{g}^{\infty} \nabla \boldsymbol{u}_{1} \cdot \nabla \bar{\boldsymbol{u}}_{2} + \rho \boldsymbol{v}_{1} \cdot \bar{\boldsymbol{v}}_{2} + \frac{\rho}{\theta_{0}} c(0) \theta_{1} \bar{\theta}_{2} \right] d\Omega - \int_{0}^{\infty} \int_{\Omega} \left[ \boldsymbol{g}'(s) \nabla \boldsymbol{w}_{1} \cdot \nabla \overline{\boldsymbol{w}}_{2} + y_{1} (\boldsymbol{l}'(s) \cdot \nabla \overline{\boldsymbol{w}}_{2}) + (\boldsymbol{l}'(s) \cdot \nabla \boldsymbol{w}_{1}) \bar{y}_{2} - \frac{\rho}{\theta_{0}} c'(s) y_{1} \bar{y}_{2} \right] d\Omega ds.$$

$$(4.2.24)$$

By assumptions  $(H_2)$ ,  $(H_4)$ – $(H_5)$ ,

$$\int_{0}^{\infty} \int_{\Omega} \left( -\mathbf{g}'(s) \nabla \mathbf{w} \cdot \nabla \overline{\mathbf{w}} - y \mathbf{l}'(s) \cdot \nabla \overline{\mathbf{w}} - \bar{y} \mathbf{l}'(s) \cdot \nabla \mathbf{w} + \frac{\rho}{\theta_{0}} c'(s) |y|^{2} \right) d\Omega ds$$

$$\geq \int_{0}^{\infty} \left( g_{1}(s) \int_{\Omega} |\nabla \mathbf{w}|^{2} d\Omega + \frac{\rho}{\theta_{0}} c'(s) \int_{\Omega} |y|^{2} d\Omega \right) ds$$

$$-\alpha \int_{0}^{\infty} \left( g_{1}(s) \int_{\Omega} |\nabla \mathbf{w}|^{2} d\Omega + \frac{\rho}{\theta_{0}} c'(s) \int_{\Omega} |y|^{2} d\Omega \right) ds$$

$$= (1 - \alpha) \int_{0}^{\infty} \left( g_{1}(s) \int_{\Omega} |\nabla \mathbf{w}|^{2} d\Omega + \frac{\rho}{\theta_{0}} c'(s) \int_{\Omega} |y|^{2} d\Omega \right) ds$$

$$\geq 0. \tag{4.2.25}$$

It is obvious that the equal sign in (4.2.25) holds if and only if  $\mathbf{w} = 0, y = 0$ . This, together with assumption  $(H_2)$ , shows that (4.2.24) is indeed an inner product on  $\mathcal{H}$ . Let  $z = (\mathbf{u}, \mathbf{v}, \theta, \mathbf{w}, y)^T$ . Then the initial boundary value problem (4.2.6)-(4.2.9) can be reduced into the initial value problem for a first-order evolution equation in  $\mathcal{H}$ :

$$\begin{cases}
\frac{dz}{dt} = Az, \\
z(0) = z_0
\end{cases} (4.2.26)$$

where

$$\mathcal{A}z = \begin{pmatrix} \mathbf{v} \\ \frac{1}{\rho} \mathbf{div} \{ \mathbf{g}^{\infty} \nabla \mathbf{u} - \mathbf{l}(0)\theta - \int_{0}^{\infty} (\mathbf{g}' \nabla \mathbf{w} + \mathbf{l}' y) \, ds \} \\ \frac{1}{\rho c(0)} \{ -\theta_{0} \mathbf{l}(0) \cdot \nabla \mathbf{v} - \int_{0}^{\infty} (\theta_{0} \mathbf{l}' \cdot \nabla \mathbf{w}' + \rho c' y') \, ds + \mathbf{div}(\kappa \nabla \theta) \} \\ \mathbf{v} - \mathbf{w}' \\ -y' \end{pmatrix}$$
(4.2.27)

with

$$\mathcal{D}(\mathcal{A}) = \left\{ z \in \mathcal{H} \middle| \begin{array}{l} \boldsymbol{v} \in \boldsymbol{H}_0^1(\Omega), \boldsymbol{w}' \in \boldsymbol{L}_{\boldsymbol{g}}^2(0, +\infty; \boldsymbol{H}_0^1(\Omega)), \ \boldsymbol{w}(0) = 0, \\ \boldsymbol{div} \{ \boldsymbol{g}^{\infty} \nabla \boldsymbol{u} - \boldsymbol{l}(0)\theta - \int_0^{\infty} (\boldsymbol{g}' \nabla \boldsymbol{w} + \boldsymbol{l}' y) \, ds \} \in \boldsymbol{L}^2(\Omega), \\ \boldsymbol{y}' \in L_c^2(0, \infty; L^2(\Omega)), \ \boldsymbol{y}(0) = \theta \end{array} \right\}. \quad (4.2.28)$$

**Theorem 4.2.1** Under the hypotheses  $(H_1)$ – $(H_5)$ , the operator  $\mathcal{A}$  defined in (4.2.27)–(4.2.28) generates a  $C_0$ -semigroup  $S(t)=e^{\mathcal{A}t}$  of contractions on  $\mathcal{H}$ .

**Proof** We want to use Theorem 1.2.4 in Chapter 1 to prove the present theorem. It is easy to see that  $\mathcal{D}(\mathcal{A})$  is dense in  $\mathcal{H}$ . To prove the dissipativeness of  $\mathcal{A}$ , by integration by parts, we have

$$Re(\mathcal{A}z,z)_{\mathcal{H}} = Re\left\{ (\boldsymbol{v},\overline{\boldsymbol{u}})_{U} + \left(\frac{1}{\rho}\boldsymbol{div}(\boldsymbol{g}^{\infty}\nabla\boldsymbol{u} - \boldsymbol{l}(0)\theta - \int_{0}^{\infty}(\boldsymbol{g}'(s)\nabla\boldsymbol{w} + \boldsymbol{l}'(s)y)\,ds), \overline{\boldsymbol{v}}\right)_{V} + \left(\frac{1}{\rho c(0)}\left(-\theta_{0}\boldsymbol{l}(0)\cdot\nabla\boldsymbol{v} - \int_{0}^{\infty}(\theta_{0}\boldsymbol{l}'\cdot\nabla\boldsymbol{w}' + \rho c'(s)y')\,ds + \boldsymbol{div}(\kappa\nabla\theta)\right), \bar{\theta}\right)_{\Theta} - \int_{0}^{\infty}\int_{\Omega}(\boldsymbol{g}'(s)\nabla(\boldsymbol{v} - \boldsymbol{w}')\cdot\nabla\overline{\boldsymbol{w}} + \bar{\boldsymbol{y}}\boldsymbol{l}'(s)\cdot\nabla(\boldsymbol{v} - \boldsymbol{w}') - \boldsymbol{y}'\boldsymbol{l}'(s)\cdot\nabla\overline{\boldsymbol{w}} + \frac{\rho}{\theta_{0}}c'(s)y'\bar{\boldsymbol{y}}\,d\Omega ds\right\} = \int_{0}^{\infty}\int_{\Omega}\left[\frac{\boldsymbol{g}'(s)}{\boldsymbol{l}'(s)} - \frac{\rho}{\theta_{0}}c'(s)\right]\left(\nabla\boldsymbol{w}'\right)\cdot\left(\nabla\overline{\boldsymbol{w}}\right)\,d\Omega ds - \int_{\Omega}\frac{1}{\theta_{0}}\kappa\nabla\theta\cdot\nabla\bar{\theta}\,d\Omega$$

$$= \lim_{\epsilon \to 0^{+},N \to +\infty}\frac{1}{2}\int_{\Omega}\left[\frac{\boldsymbol{g}'(s)}{\boldsymbol{l}'(s)} - \frac{\boldsymbol{l}'(s)}{\theta_{0}}c'(s)\right]\left(\nabla\boldsymbol{w}\right)\cdot\left(\nabla\overline{\boldsymbol{w}}\right)\,d\Omega\right|_{s=\epsilon}^{s=N} - \frac{1}{2}Re\lim_{\epsilon \to 0^{+},N \to \infty}\int_{\epsilon}^{N}\int_{\Omega}\left[\frac{\boldsymbol{g}''(s)}{\boldsymbol{l}''(s)} - \frac{\boldsymbol{l}''(s)}{\theta_{0}}c''(s)\right]\left(\nabla\boldsymbol{w}\right)\cdot\left(\nabla\overline{\boldsymbol{w}}\right)\cdot\left(\nabla\overline{\boldsymbol{w}}\right)\,d\Omega ds - \int_{\Omega}\frac{1}{\theta_{0}}\kappa\nabla\theta\cdot\nabla\bar{\theta}\,d\Omega. \tag{4.2.29}$$

Define

$$h(s) \stackrel{\triangle}{=} -\int_{\Omega} \begin{bmatrix} \mathbf{g}'(s) & \mathbf{l}'(s) \\ \mathbf{l}'(s) & -\frac{\rho}{\theta_0} c'(s) \end{bmatrix} \begin{pmatrix} \nabla \mathbf{w} \\ y - \theta \end{pmatrix} \cdot \begin{pmatrix} \nabla \overline{\mathbf{w}} \\ \bar{y} - \bar{\theta} \end{pmatrix} d\Omega. \tag{4.2.30}$$

By assumptions  $(H_2)$ ,  $(H_4)$ , and  $(H_5)$  and  $\boldsymbol{w}' \in \boldsymbol{L}_{\boldsymbol{g}}^2(0, +\infty; \boldsymbol{H}_0^1), \ y' \in L_c^2(0, +\infty; L^2)$ , we can easily deduce that  $h(s), h'(s) \in L^1(s_1, \infty)$ . Hence

$$\lim_{N \to \infty} h(N) = 0. \tag{4.2.31}$$

In what follows, we prove by a contradiction argument that  $h(\varepsilon) \to 0$ , as  $\varepsilon \to 0$ . Suppose that it is not true. Then there is a constant  $\delta > 0$  and a sequence  $s_n, s_n \to 0^+$  102 such that  $h(s_n) \ge \delta > 0$  for all n. By (4.2.11) and (4.2.17), we have

$$h(s) \le (1 - \alpha) \left( g_1(s) \int_{\Omega} |\nabla \boldsymbol{w}|^2 d\Omega + \frac{\rho}{\theta_0} c'(s) \int_{\Omega} |y - \theta|^2 d\Omega \right). \tag{4.2.32}$$

We now prove that  $g_1(s_n) \int_{\Omega} |\nabla \boldsymbol{w}(s_n)|^2 d\Omega \to 0$ . Indeed, as  $s_n \to 0^+$ ,

$$g_{1}(s_{n}) \int_{\Omega} \nabla \boldsymbol{w}(s_{n}) \cdot \nabla \overline{\boldsymbol{w}}(s_{n}) d\Omega$$

$$= g_{1}(s_{n}) \|\nabla \boldsymbol{w}(s_{n})\|^{2}$$

$$= g_{1}(s_{n}) \|\int_{0}^{s_{n}} \nabla \boldsymbol{w}'(\tau) d\tau\|^{2}$$

$$\leq s_{n} g_{1}(s_{n}) \int_{0}^{s_{n}} \|\nabla \boldsymbol{w}'(\tau)\|^{2} d\tau$$

$$\leq s_{n} \int_{0}^{s_{n}} g_{1}(\tau) \|\nabla \boldsymbol{w}'(\tau)\|^{2} d\tau \to 0, \text{ as } s_{n} \to 0^{+}. \tag{4.2.33}$$

Similarly, we can also get

$$c'(s_n)||y(s_n) - \theta||^2 \to 0$$
, as  $\varepsilon \to 0^+$ . (4.2.34)

Thus combining (4.2.32) with (4.2.33) and (4.2.34) yields a contradiction. This proves that  $h(s) \to 0$ , as  $s \to 0$ . Then it follows from (4.2.29) that

$$-\frac{1}{2}\int_{0}^{\infty}\int_{\Omega}\left[\begin{array}{cc}g''(s) & l''(s)\\l''(s) & -\frac{\rho}{\theta_{0}}c''(s)\end{array}\right]\left(\begin{array}{c}\nabla\boldsymbol{w}\\y-\theta\end{array}\right)\cdot\left(\begin{array}{c}\nabla\overline{\boldsymbol{w}}\\\bar{y}-\bar{\theta}\end{array}\right)d\Omega ds\tag{4.2.35}$$

is convergent and

$$Re(\mathcal{A}z,z) = -\frac{1}{2} \int_{0}^{\infty} \int_{\Omega} \begin{bmatrix} \mathbf{g}''(s) & \mathbf{l}''(s) \\ \mathbf{l}''(s) & -\frac{\rho}{\theta_{0}} c''(s) \end{bmatrix} \begin{pmatrix} \nabla w \\ y - \theta \end{pmatrix} \cdot \begin{pmatrix} \nabla \overline{w} \\ \bar{y} - \bar{\theta} \end{pmatrix} d\Omega ds$$

$$-\frac{1}{\theta_{0}} \int_{\Omega} \kappa \nabla \theta \cdot \nabla \bar{\theta} d\Omega. \tag{4.2.36}$$

By assumptions  $(H_2)$ ,  $(H_3)$ , and  $(H_5)$ , each term on the right hand side of (4.2.36) is non-positive. Thus the dissipativeness of  $\mathcal{A}$  follows.

Now it remains to prove that  $0 \in \rho(A)$ . Let  $F = (f_1, f_2, f_3, f_4, f_5)^T \in \mathcal{H}$ . We consider the equation

$$-Az = F (4.2.37)$$

i.e.,

$$-\boldsymbol{v} = \boldsymbol{f}_1 \in U, \tag{4.2.38}$$

$$-\frac{1}{\rho}\operatorname{div}\left\{g^{\infty}\nabla u - \boldsymbol{l}(0)\theta - \int_{0}^{\infty}\left[g'(s)\nabla w + \boldsymbol{l}'(s)y\right]\,ds\right\} = \boldsymbol{f}_{2} \in V,\tag{4.2.39}$$

$$\frac{1}{\rho c(0)} \left\{ \theta_0 \boldsymbol{l}(0) \cdot \nabla \boldsymbol{v} + \int_0^\infty \left[ \theta_0 \boldsymbol{l}'(s) \cdot \nabla \boldsymbol{w}' + \rho c'(s) \boldsymbol{y}' \right] \, ds - \boldsymbol{div}(\boldsymbol{\kappa} \nabla \theta) \right\} = f_3 \in \Theta,$$
(4.2.40)

$$\begin{pmatrix} -\mathbf{v} + \mathbf{w}' \\ \mathbf{y}' \end{pmatrix} = \begin{pmatrix} \mathbf{f_4} \\ \mathbf{f_5} \end{pmatrix} \in W \times Y. \tag{4.2.41}$$

From equations (4.2.38) and (4.2.41) we deduce that

$$\boldsymbol{v} = -\boldsymbol{f}_1 \in U, \tag{4.2.42}$$

$$\begin{pmatrix} \boldsymbol{w} \\ y \end{pmatrix} = \begin{pmatrix} \int_0^s [\boldsymbol{f_4}(\tau) - \boldsymbol{f_1}] d\tau \\ \theta + \int_0^s f_5(\tau) d\tau \end{pmatrix}. \tag{4.2.43}$$

Since  $\{w', y'\} = \{f_4(s) - f_1, f_5(s)\} \in W \times Y$ , as in the proof of Theorem 3.2.1, we can conclude that  $w \in W$  and  $y \in Y$ . Moreover,

$$\begin{pmatrix} -\mathbf{v} + \mathbf{w}' \\ y' \end{pmatrix} \in W \times Y. \tag{4.2.44}$$

Substituting (4.2.42) and (4.2.43) into equation (4.2.39) and (4.2.40), we obtain that

$$-\frac{1}{\rho}div(g^{\infty}\nabla u - l^{\infty}\theta) = \widetilde{f}_{2}, \tag{4.2.45}$$

and

$$\frac{-1}{\rho c(0)} div(\kappa \nabla \theta) = \tilde{f}_3 \tag{4.2.46}$$

where  $l^{\infty} = \lim_{s \to \infty} l(s)$  and

$$\begin{split} \widetilde{\boldsymbol{f}_2} &= \boldsymbol{f}_2 - \frac{1}{\rho} \boldsymbol{div} \left\{ \int_0^\infty \int_0^s \left[ \boldsymbol{g}'(s) (\nabla \boldsymbol{f}_4(\tau) - \nabla \boldsymbol{f}_1) + \boldsymbol{l}'(s) f_5(\tau) \right] \, d\tau ds \right\} \in \boldsymbol{H}^{-1}, \\ \widetilde{f_3} &= f_3 - \frac{1}{\rho c(0)} \theta_0 \boldsymbol{l}(0) \cdot \nabla \boldsymbol{f}_1 \\ &+ \frac{1}{\rho c(0)} \left\{ \int_0^\infty \int_0^s \left[ \theta_0 \boldsymbol{l}'(s) \cdot (\nabla \boldsymbol{f}_4(\tau) - \nabla \boldsymbol{f}_1) + \rho c'(s) f_5(\tau) \right] \, d\tau ds \right\} \in L^2. \end{split}$$

It follows from the standard results in the elliptic boundary value problems (see Chapter 1 or Lions & Magenes [1]) that equation (4.2.46) has a unique solution  $\theta \in H_0^1(\Omega) \cap H^2(\Omega)$ . Moreover,

$$\theta_0 \boldsymbol{l}(0) \cdot \nabla \boldsymbol{v} + \int_0^\infty \left[ \theta_0 \boldsymbol{l}'(s) \cdot \nabla \boldsymbol{w}' + \rho c'(s) y' \right] ds - \boldsymbol{div}(\boldsymbol{\kappa} \nabla \theta) \in \Theta.$$
 (4.2.47)

Define the following bilinear form on  $U = \mathbf{H}_0^1(\Omega)$ :

$$b(\boldsymbol{u}, \tilde{\boldsymbol{u}}) = \rho \int_{\Omega} \boldsymbol{g}^{\infty} \nabla \boldsymbol{u} \cdot \nabla \tilde{\boldsymbol{u}} \, d\Omega. \tag{4.2.48}$$

Clearly it is bounded and coercive. Then by the Lax-Milgram theorem, there is a unique  $u \in U = H^1_0(\Omega)$  such that

$$b(\boldsymbol{u}, \tilde{\boldsymbol{u}}) = \rho(\tilde{\boldsymbol{f}}_1, \tilde{\boldsymbol{u}}) + (\boldsymbol{l}^{\infty}\boldsymbol{\theta}, \nabla \tilde{\boldsymbol{u}})_V, \quad \forall \tilde{\boldsymbol{u}} \in \boldsymbol{H}_0^1$$
(4.2.49)

where  $\langle , \rangle$  denotes the dual product between  $U = \mathbf{H}_0^1$  and  $U' = \mathbf{H}^{-1}$ . Furthermore, it follows from (4.2.45) that

$$\operatorname{div}\left\{g^{\infty}\nabla u - \boldsymbol{l}(0)\theta - \int_{0}^{\infty} \left[g'(s)\nabla w + \boldsymbol{l}'(s)y\right] ds\right\} \in V. \tag{4.2.50}$$

Finally, it follows from (4.2.43) that

$$\mathbf{w}(0) = 0, \quad y(0) = \theta.$$
 (4.2.51)

Thus, we have proved that for any  $F \in \mathcal{H}$ , the equation -Az = F has a unique solution  $z = \{u, v, \theta, w, y\} \in \mathcal{D}(A)$ . It is easy to verify that  $||z||_{\mathcal{H}} \leq K||F||_{\mathcal{H}}$  for some constant K > 0. Thus  $0 \in \rho(A)$  and by Theorem 1.2.4 in Chapter 1 we can conclude that A generates a  $C_0$ -semigroup of contractions on  $\mathcal{H}$ .

Under further assumptions  $(H_6)$  and  $(H_7)$ , we have the following result on the exponential stability.

**Theorem 4.2.2** Under the hypotheses  $(H_1)$ – $(H_7)$ , the  $C_0$ -semigroup S(t), generated by A, is exponentially stable.

**Proof** We still use Theorem 1.3.2 in Chapter 1 to prove the present theorem.

First we prove (1.3.3) by a contradiction argument. The proof consists of the following

steps:

- (i) Since  $0 \in \rho(\mathcal{A})$ ,  $i\beta \mathcal{A}$  is invertible for  $\beta \in \mathbb{R}$  and  $|\beta| < ||\mathcal{A}^{-1}||^{-1}$ .
- (ii) If (1.3.3) is not true, then there is  $\omega \in \mathbb{R}$  with  $\|\mathcal{A}^{-1}\|^{-1} \leq |\omega| < \infty$  and a sequence of complex vector functions  $z_n \in \mathcal{D}(\mathcal{A})$  with  $\|z_n\|_{\mathcal{H}} = 1$  and a sequence of  $\beta_n$  with  $|\beta_n| < |\omega|, \ \beta_n \to \omega$  such that as  $n \to +\infty$ ,

$$\lim_{n \to \infty} \|(\mathbf{i}\beta_n I - \mathcal{A})z_n\|_{\mathcal{H}} = 0, \tag{4.2.52}$$

i.e.,

$$i\beta_{n}\boldsymbol{u}_{n}-\boldsymbol{v}_{n}\to0 \quad \text{in } U, \tag{4.2.53}$$

$$i\beta_{n}\boldsymbol{v}_{n}-\frac{1}{\rho}\boldsymbol{div}\{\boldsymbol{g}^{\infty}\nabla\boldsymbol{u}-\boldsymbol{l}(0)\boldsymbol{\theta}-\int_{0}^{\infty}[\boldsymbol{g}'(s)\nabla\boldsymbol{w}_{n}+\boldsymbol{l}'(s)y_{n}]\,ds\}\to0 \quad \text{in } V, (4.2.54)$$

$$i\beta_{n}\theta_{n}+\frac{1}{\rho c(0)}\left\{\theta_{0}\boldsymbol{l}(0)\cdot\nabla\boldsymbol{v}_{n}+\int_{0}^{\infty}\left[\theta_{0}\boldsymbol{l}'(s)\cdot\nabla\boldsymbol{w}'+\rho c'(s)y'\right]\,ds+\boldsymbol{div}(\boldsymbol{\kappa}\nabla\theta_{n})\right\}$$

$$\to 0 \quad \text{in } \Theta, \tag{4.2.55}$$

$$i\beta_n \begin{pmatrix} w_n \\ y_n \end{pmatrix} - \begin{pmatrix} v_n - w'_n \\ -y'_n \end{pmatrix} \rightarrow \begin{pmatrix} 0 \\ 0 \end{pmatrix} \quad \text{in } W \times Y.$$
 (4.2.56)

It follows from (4.2.52) that

$$Re(-\mathcal{A}z_n, z_n)_{\mathcal{H}} \to 0.$$
 (4.2.57)

Thus, we obtain from (4.2.36) that

$$\int_{0}^{\infty} \int_{\Omega} \begin{bmatrix} \boldsymbol{g}''(s) & \boldsymbol{l}''(s) \\ \boldsymbol{l}''(s) & -\frac{\rho}{\theta_{0}} c''(s) \end{bmatrix} \begin{pmatrix} \nabla \boldsymbol{w}_{n} \\ y_{n} - \theta_{n} \end{pmatrix} \cdot \begin{pmatrix} \nabla \overline{\boldsymbol{w}}_{n} \\ \bar{y}_{n} - \bar{\theta}_{n} \end{pmatrix} d\Omega ds \to 0, \qquad (4.2.58)$$

and

$$\|\theta_n\|_{H_0^1(\Omega)} \to 0.$$
 (4.2.59)

By assumptions  $(H_5)$ - $(H_7)$  and (4.2.58), we have

$$\int_0^\infty \int_{\Omega} \boldsymbol{g}''(s) \nabla \boldsymbol{w}_n \cdot \nabla \overline{\boldsymbol{w}}_n \, d\Omega ds + \int_0^\infty \int_{\Omega} -\frac{\rho}{\theta_0} c''(s) |y_n - \theta_n|^2 \, d\Omega ds \to 0. \tag{4.2.60}$$

106

Since both terms in (4.2.60) are non-negative, we get

$$\begin{cases}
\int_{0}^{\infty} \int_{\Omega} \mathbf{g}''(s) \nabla \mathbf{w}_{n} \cdot \nabla \overline{\mathbf{w}}_{n} d\Omega ds & \to 0, \\
\int_{0}^{\infty} \int_{\Omega} -\frac{\rho}{\theta_{0}} c''(s) |y_{n} - \theta_{n}|^{2} d\Omega ds & \to 0,
\end{cases}$$
(4.2.61)

which further implies, due to assumption  $(H_5)$ - $(H_7)$ , that

$$\begin{cases}
\int_{0}^{\infty} g_{1}(s) \int_{\Omega} |\nabla \boldsymbol{w}_{n}|^{2} d\Omega ds & \to 0, \\
\int_{0}^{\infty} \frac{\rho}{\theta_{0}} c'(s) \int_{\Omega} |y_{n} - \theta_{n}|^{2} d\Omega ds & \to 0.
\end{cases} (4.2.62)$$

Hence,

$$\left\| \begin{pmatrix} \boldsymbol{w}_{n} \\ y_{n} - \theta_{n} \end{pmatrix} \right\|_{W \times Y}^{2}$$

$$= -\int_{0}^{\infty} \int_{\Omega} \left[ \frac{\boldsymbol{g}'(s)}{l'(s)} - \frac{l'(s)}{\theta_{0}} c'(s) \right] \begin{pmatrix} \nabla \boldsymbol{w}_{n} \\ y_{n} - \theta_{n} \end{pmatrix} \cdot \begin{pmatrix} \nabla \overline{\boldsymbol{w}}_{n} \\ \overline{y}_{n} - \overline{\theta}_{n} \end{pmatrix} d\Omega ds$$

$$\leq 2 \int_{0}^{\infty} \int_{\Omega} -\boldsymbol{g}'(s) \nabla \boldsymbol{w}_{n} \cdot \nabla \overline{\boldsymbol{w}}_{n} d\Omega ds + \frac{\rho}{\theta_{0}} c'(s) |y_{n} - \theta_{n}|^{2} d\Omega ds$$

$$\leq 2k_{1} \int_{0}^{\infty} g_{1}(s) \int_{\Omega} |\nabla \boldsymbol{w}_{n}|^{2} d\Omega ds + 2 \int_{0}^{\infty} \frac{\rho}{\theta_{0}} c'(s) \int_{\Omega} |y_{n} - \theta_{n}|^{2} d\Omega ds$$

$$\Rightarrow 0. \tag{4.2.63}$$

By (4.2.59), we obtain that

$$\left\| \begin{pmatrix} 0 \\ \theta_n \end{pmatrix} \right\|_{W \times Y}^2 = \frac{\rho}{\theta_0} \int_0^\infty \int_\Omega c'(s) |\theta_n|^2 d\Omega ds$$
$$= \frac{\rho}{\theta_0} (c^\infty - c(0)) \|\theta_n\|^2 \to 0. \tag{4.2.64}$$

Combining (4.2.64) with (4.2.63) yields

$$\left\| \left( \begin{array}{c} \boldsymbol{w}_n \\ \boldsymbol{y}_n \end{array} \right) \right\|_{W \times Y} \to 0, \tag{4.2.65}$$

i.e.,

$$\boldsymbol{w}_n \to 0 \quad \text{in } W, \quad y_n \to 0 \quad \text{in } Y.$$
 (4.2.66)

Since  $||z_n||_{\mathcal{H}} = 1$ , it follows from (4.2.59) and (4.2.65) that

$$\|\boldsymbol{u}_n\|_U^2 + \|\boldsymbol{v}_n\|_V^2 \to 1.$$
 (4.2.67)

We now take the inner product of (4.2.53) with  $\frac{u_n}{\beta_n}$  in U and (4.2.54) with  $\frac{v_n}{\beta_n}$  in V to get

$$i\|\boldsymbol{u}_{n}\|_{U}^{2} - \frac{1}{\beta_{n}}(\boldsymbol{v}_{n}, \boldsymbol{u}_{n})_{U} \to 0,$$

$$i\|\boldsymbol{v}_{n}\|_{V}^{2} + \frac{1}{\beta_{n}}(\boldsymbol{u}_{n}, \boldsymbol{v}_{n})_{U} - \frac{1}{\beta_{n}}\int_{\Omega}\boldsymbol{l}(0) \cdot \nabla \overline{\boldsymbol{v}}_{n}\theta_{n} d\Omega$$

$$+ \frac{1}{\beta_{n}}\int_{0}^{\infty} \int_{\Omega} (\boldsymbol{g}'(s)\nabla \boldsymbol{w}_{n} + \boldsymbol{l}'(s)y_{n}) \cdot \nabla \overline{\boldsymbol{v}}_{n} d\Omega ds \to 0.$$

$$(4.2.69)$$

In what follows, we prove that the last two terms of (4.2.69) converge to zero. Indeed, by integration by parts, we have

$$\left| \frac{1}{\beta_n} \int_{\Omega} \boldsymbol{l}(0) \cdot \nabla \overline{\boldsymbol{v}}_n \theta_n \, d\Omega \right| \le K \|\boldsymbol{v}_n\|_V \|\nabla \theta_n\| \to 0, \tag{4.2.70}$$

and

$$\left| \frac{1}{\beta_{n}} \int_{0}^{\infty} \int_{\Omega} (\mathbf{g}'(s) \nabla \mathbf{w}_{n} + \mathbf{l}'(s) y_{n}) \cdot \nabla \overline{\mathbf{v}}_{n} \, d\Omega ds \right| 
= \left| \left\langle \begin{pmatrix} \mathbf{w}_{n} \\ y_{n} \end{pmatrix}, \frac{1}{\beta_{n}} \begin{pmatrix} \mathbf{v}_{n} \\ 0 \end{pmatrix} \right\rangle_{W \times Y} \right| 
\leq \left\| \begin{pmatrix} \mathbf{w}_{n} \\ y_{n} \end{pmatrix} \right\|_{W \times Y} \cdot \left\| \frac{1}{\beta_{n}} \begin{pmatrix} \mathbf{v}_{n} \\ 0 \end{pmatrix} \right\|_{W \times Y} 
\leq K \left\| \begin{pmatrix} \mathbf{w}_{n} \\ y_{n} \end{pmatrix} \right\|_{W \times Y} \left\| \frac{\mathbf{v}_{n}}{\beta_{n}} \right\|_{U} \to 0$$
(4.2.71)

where we have used (4.2.53), (4.2.65) and the fact that  $||u_n||_U \leq 1$ .

Adding (4.2.68) up to the complex conjugate of (4.2.69) yields

$$\|\boldsymbol{u}_n\|_U^2 - \|\boldsymbol{v}_n\|_V^2 \to 0.$$
 (4.2.72)

Hence,

$$\|\boldsymbol{u}_n\|_U^2 \to \frac{1}{2}, \ \|\boldsymbol{v}_n\|_V^2 \to \frac{1}{2}.$$
 (4.2.73)

Dividing (4.2.56) by  $\beta_n$  and using (4.2.65), we have

$$\frac{1}{\beta_n} \begin{pmatrix} \boldsymbol{v}_n \\ 0 \end{pmatrix} - \frac{1}{\beta_n} \begin{pmatrix} \boldsymbol{w}'_n \\ y'_n \end{pmatrix} \to 0 \quad \text{in } W \times Y.$$
 (4.2.74)

Since

$$\begin{split} & \left\| \frac{1}{\beta_{n}} \begin{pmatrix} s \boldsymbol{v}_{n} \\ 0 \end{pmatrix} \right\|_{W \times Y}^{2} = \int_{0}^{\infty} \int_{\Omega} -s^{2} \boldsymbol{g}'(s) \frac{\nabla \boldsymbol{v}_{n}}{\beta_{n}} \cdot \frac{\nabla \overline{\boldsymbol{v}}_{n}}{\beta_{n}} d\Omega ds \\ & \leq K_{1} \int_{0}^{\infty} s^{2} g_{1}(s) ds \int_{\Omega} \frac{\nabla \boldsymbol{v}_{n}}{\beta_{n}} \cdot \frac{\nabla \overline{\boldsymbol{v}}_{n}}{\beta_{n}} d\Omega \\ & \leq K \|\boldsymbol{u}_{n}\|_{U}^{2} \leq K, \end{split} \tag{4.2.75}$$

we can take the inner product of (4.2.74) with  $\frac{1}{\beta_n} \begin{pmatrix} s v_n \\ 0 \end{pmatrix}$  in  $W \times Y$  to get

$$\left\| \frac{1}{\beta_n} \begin{pmatrix} s^{\frac{1}{2}} \boldsymbol{v}_n \\ 0 \end{pmatrix} \right\|_{W \times Y}^2 - \frac{1}{\beta_n^2} \left\langle \begin{pmatrix} \boldsymbol{w}_n' \\ y_n' \end{pmatrix}, \begin{pmatrix} s \boldsymbol{v}_n \\ 0 \end{pmatrix} \right\rangle_{W \times Y}$$

$$= (I) + (II) \to 0. \tag{4.2.76}$$

In what follows, we prove that (II) converges to zero.

By integration by parts with respect to t and assumptions  $(H_2)$ - $(H_7)$ , we get that

$$|II| = \frac{1}{\beta_{n}^{2}} \left| \int_{0}^{\infty} \int_{\Omega} s \boldsymbol{g}'(s) \nabla \boldsymbol{w}_{n} \cdot \nabla \overline{\boldsymbol{v}}_{n} \, d\Omega ds + \int_{0}^{\infty} \int_{\Omega} s \boldsymbol{l}'(s) \cdot \nabla \overline{\boldsymbol{v}}_{n} y_{n}' \, d\Omega ds \right|$$

$$\leq \frac{1}{\beta_{n}^{2}} \left| \int_{0}^{\infty} \int_{\Omega} s \boldsymbol{g}''(s) \nabla \boldsymbol{w}_{n} \cdot \nabla \overline{\boldsymbol{v}}_{n} \, d\Omega ds \right| + \frac{1}{\beta_{n}^{2}} \left| \int_{0}^{\infty} \int_{\Omega} \boldsymbol{g}'(s) \nabla \boldsymbol{w}_{n} \cdot \nabla \overline{\boldsymbol{v}}_{n} \, d\Omega ds \right|$$

$$+ \frac{1}{\beta_{n}^{2}} \left| \int_{0}^{\infty} \int_{\Omega} (s \boldsymbol{l}''(s) \cdot \nabla \overline{\boldsymbol{v}}_{n}) y_{n} \, d\Omega ds \right| + \frac{1}{\beta_{n}^{2}} \left| \int_{0}^{\infty} \int_{\Omega} (\boldsymbol{l}'(s) \cdot \nabla \overline{\boldsymbol{v}}_{n}) y_{n} \, d\Omega ds \right|.$$

$$(4.2.77)$$

By assumptions  $(H_2)$ – $(H_7)$ , the terms on the right hand side of (4.2.77) can be estimated as follows:

$$\frac{1}{\beta_n^2} \left| \int_0^\infty \int_\Omega s \boldsymbol{g}''(s) \nabla \boldsymbol{w}_n \cdot \nabla \overline{\boldsymbol{v}}_n \, d\Omega ds \right| \\
\leq \frac{1}{\beta_n} \left( \int_0^\infty \int_\Omega \boldsymbol{g}''(s) \nabla \boldsymbol{w}_n \cdot \nabla \overline{\boldsymbol{w}}_n \, d\Omega ds \right)^{\frac{1}{2}} \left( \int_0^\infty \int_\Omega s^2 \boldsymbol{g}''(s) \frac{\nabla \boldsymbol{v}_n}{\beta_n} \cdot \frac{\nabla \overline{\boldsymbol{v}}_n}{\beta_n} \, d\Omega ds \right)^{\frac{1}{2}}$$

$$\leq \frac{1}{\beta_{n}} \left( \int_{0}^{\infty} \int_{\Omega} \mathbf{g}''(s) \nabla \mathbf{w}_{n} \cdot \nabla \overline{\mathbf{w}}_{n} \, d\Omega ds \right)^{\frac{1}{2}} \left( \int_{0}^{s_{1}} \int_{\Omega} s^{2} \mathbf{g}''(s) \frac{\nabla \mathbf{v}_{n}}{\beta_{n}} \cdot \frac{\nabla \overline{\mathbf{v}}_{n}}{\beta_{n}} \, d\Omega ds \right) \\
+ \int_{s_{1}}^{+\infty} k_{2} s^{2} g_{1}(s) ds \int_{\Omega} \left| \frac{\nabla \mathbf{v}_{n}}{\beta_{n}} \right|^{2} d\Omega \right)^{\frac{1}{2}} \\
\leq \frac{K}{\beta_{n}} \left( \int_{0}^{\infty} \int_{\Omega} \mathbf{g}''(s) \nabla \mathbf{w}_{n} \cdot \nabla \overline{\mathbf{w}}_{n} \, d\Omega ds \right)^{\frac{1}{2}} \to 0, \qquad (4.2.78) \\
\frac{1}{\beta_{n}^{2}} \left| \int_{0}^{\infty} \int_{\Omega} -\mathbf{g}'(s) \nabla \mathbf{w}_{n} \cdot \nabla \overline{\mathbf{w}}_{n} \, d\Omega ds \right| \\
\leq \frac{1}{\beta_{n}} \left( \int_{0}^{\infty} \int_{\Omega} -\mathbf{g}'(s) \nabla \mathbf{w}_{n} \cdot \nabla \overline{\mathbf{w}}_{n} \, d\Omega ds \right)^{\frac{1}{2}} \left( \int_{0}^{\infty} k_{1} g_{1}(s) \, ds \int_{\Omega} \left| \frac{\nabla \overline{\mathbf{v}}_{n}}{\beta_{n}} \right|^{2} d\Omega \right)^{\frac{1}{2}} \\
\leq \frac{K}{\beta} \left( \int_{0}^{\infty} g_{1}(s) \int_{\Omega} |\nabla \mathbf{w}_{n}|^{2} d\Omega ds \right)^{\frac{1}{2}} \to 0, \qquad (4.2.79)$$

and

$$\frac{1}{\beta_{n}^{2}} \left| \int_{0}^{\infty} \int_{\Omega} s l''(s) \cdot \nabla \overline{v}_{n} y_{n} d\Omega ds \right| \\
\leq \frac{M_{1}}{\beta_{n}} \left( \int_{0}^{\infty} \int_{\Omega} s^{2} g_{1}(s) \left| \frac{\nabla v_{n}}{\beta_{n}} \right|^{2} d\Omega ds \right)^{\frac{1}{2}} \left( \int_{0}^{\infty} \int_{\Omega} -\frac{\rho}{\theta_{0}} c''(s) |y_{n}|^{2} d\Omega ds \right)^{\frac{1}{2}} \\
\leq \frac{K}{\beta_{n}} \left( \int_{0}^{\infty} \frac{\rho}{\theta_{0}} c'(s) \int_{\Omega} |y_{n}|^{2} d\Omega ds \right)^{\frac{1}{2}} \to 0, \tag{4.2.80}$$

$$\frac{1}{\beta_{n}^{2}} \left| \int_{0}^{\infty} \int_{\Omega} s l'(s) \cdot \nabla \overline{v}_{n} y_{n} d\Omega ds \right| \\
\leq \frac{\alpha}{\beta_{n}} \left( \int_{0}^{\infty} \int_{\Omega} s^{2} g_{1}(s) \left| \frac{\nabla v_{n}}{\beta_{n}} \right|^{2} d\Omega ds \right)^{\frac{1}{2}} \left( \int_{0}^{\infty} \int_{\Omega} \frac{\rho}{\theta_{0}} c'(s) |y_{n}|^{2} d\Omega ds \right)^{\frac{1}{2}} \\
\leq \frac{K}{\beta_{n}} \left( \int_{0}^{\infty} \int_{\Omega} \frac{\rho}{\theta} c'(s) |y_{n}|^{2} d\Omega ds \right)^{\frac{1}{2}} \to 0. \tag{4.2.81}$$

Therefore, (II) converges to zero. It turns out from (4.2.76) that (I) also converges to zero. Finally, since

$$(I) \ge \int_0^\infty s g_1(s) \, ds \int_\Omega \frac{\nabla \boldsymbol{v}_n}{\beta_n} \cdot \frac{\nabla \overline{\boldsymbol{v}}_n}{\beta_n} \, d\Omega \ge \nu \| \frac{\nabla \boldsymbol{v}_n}{\beta_n} \|_U^2 \tag{4.2.82}$$

with  $\nu$  being a positive constant, we obtain that

$$\left\| \frac{\nabla \boldsymbol{v}_n}{\beta_n} \right\|_{U} \to 0. \tag{4.2.83}$$

By (4.2.53), we conclude that

$$\|\boldsymbol{u}_n\|_U^2 \to 0 \tag{4.2.84}$$

which contradicts (4.2.73). Thus (1.3.3) is proved.

(iii). The proof of (1.3.4) is exactly the same as in (ii) because in the proof of (1.3.3) we only use the fact that  $\beta_n$  converges to a limit which is different from zero.

## Chapter 5

#### Elastic Systems with Shear Damping

In this chapter, we consider some linear elastic systems with shear damping. Section 5.1 is devoted to the so-called shear diffusion equations proposed in Russell [2]. Section 5.2 deals with the laminated beam equations with shear damping derived in Liu, Trogdon & Yong [1]. Our goal is to obtain the exponential stability and analyticity of the semigroups associated with these equations.

#### 5.1 Shear Diffusion Equations

Let us start from the following Timoshenko beam equations (see Timoshenko, Young & Weaver [1]):

$$\rho \frac{\partial^2 w}{\partial t^2} - I_{\rho} \left( \frac{\partial^4 w}{\partial x^4} + \frac{\partial^3 r}{\partial t^2 \partial x} \right) + EI \left( \frac{\partial^4 w}{\partial x^4} + \frac{\partial^3 r}{\partial x^3} \right) = 0, \text{ in } [0, L] \times \mathbb{R}^+ (5.1.1)$$

$$I_{\rho}\left(\frac{\partial^{3}w}{\partial t^{2}\partial x} + \frac{\partial^{2}r}{\partial t^{2}}\right) + \alpha r - EI\left(\frac{\partial^{3}w}{\partial x^{3}} + \frac{\partial^{2}r}{\partial x^{2}}\right) = 0, \text{ in } [0, L] \times IR^{+}$$
 (5.1.2)

where w is the lateral deflection and r is the shear angle, L is the length of the beam, and  $\rho, \alpha, I_{\rho}, E, I$  are positive constants.

When the viscous force which affects the evolution of r is taken into account, a term  $2\sigma \frac{\partial r}{\partial t}$  with  $\sigma > 0$  should be added to equation (5.1.2). If we further assume that the rotatory inertia  $I_{\rho}$  is relatively small so that the corresponding terms can be neglected, then equations (5.1.1) and (5.1.2) become the shear diffusion model proposed in Russell [2] for the Euler-Bernoulli beam equations:

$$\rho \frac{\partial^2 w}{\partial t^2} + EI\left(\frac{\partial^4 w}{\partial x^4} + \frac{\partial^3 r}{\partial x^3}\right) = 0, \tag{5.1.3}$$

$$2\sigma \frac{\partial r}{\partial t} + \alpha r - EI\left(\frac{\partial^3 w}{\partial x^3} + \frac{\partial^2 r}{\partial x^2}\right) = 0. \tag{5.1.4}$$

The boundary conditions and initial conditions considered here are

$$w = \frac{\partial w}{\partial x} + r = 0, \quad \text{at } x = 0, \tag{5.1.5}$$

$$\frac{\partial^2 w}{\partial x^2} + \frac{\partial r}{\partial x} = \frac{\partial^3 w}{\partial x^3} + \frac{\partial^2 r}{\partial x^2} = 0, \quad \text{at } x = L, \tag{5.1.6}$$

$$w(x,0) = w_0(x), \quad w_t(x,0) = w_1(x), \quad r(x,0) = r_0(x).$$
 (5.1.7)

The energy associated with this model is defined by

$$E(t) = \frac{1}{2} \int_0^L \left[ \rho \left( \frac{\partial w}{\partial t} \right)^2 + \alpha r^2 + EI \left( \frac{\partial^2 w}{\partial x^2} + \frac{\partial r}{\partial x} \right)^2 \right] dx.$$
 (5.1.8)

Let  $z = (w, v, r)^T$  and

$$\mathcal{H} = \left\{ z \middle| \begin{array}{l} w \in H^1(0, L), w|_{x=0} = 0, v, r \in L^2(0, L), \\ (Dw + r) \in H^1(0, L), (Dw + r)|_{x=0} = 0. \end{array} \right\}$$
 (5.1.9)

equipped with the norm

$$||z||_{\mathcal{H}} = (EI||D(Dw+r)||^2 + \rho||v||^2 + \alpha||r||^2)^{\frac{1}{2}}$$
 (5.1.10)

and the corresponding inner product. As usual, in the above we denote  $D^j = \frac{\partial^j}{\partial x^j}$  for  $j = 1, 2, \cdots$  and we denote by  $\|\cdot\|$  the  $L^2(0, L)$  norm. Hereafter we also denote by  $\langle\cdot\rangle$  the inner product in  $L^2(0, L)$ . It is clear that  $\mathcal{H}$  is a Hilbert space. Let  $v = w_t$ . Then the system (5.1.3)–(5.1.7) can be reduced to the following initial value problem for a first-order evolution equation on  $\mathcal{H}$ :

$$\begin{cases} \frac{dz(t)}{dt} = \mathcal{A}z(t), & \forall t > 0\\ z(0) = z_0 = (w_0, w_1, r_0)^T \end{cases}$$
 (5.1.11)

with

$$Az = \begin{pmatrix} v \\ -\frac{EI}{\rho}D^{3}(Dw+r) \\ \frac{EI}{2\sigma}D^{2}(Dw+r) - \frac{\alpha}{2\sigma}r \end{pmatrix}$$
 (5.1.12)

113

and

$$\mathcal{D}(\mathcal{A}) = \left\{ z \in \mathcal{H} \middle| \begin{array}{l} v \in H^{1}(0, L), \ v|_{x=0} = 0, \ Dw + r \in H^{3}(0, L), \\ D(Dw + r)|_{x=L} = D^{2}(Dw + r)|_{x=L} = 0, \\ Dv - \frac{\alpha}{2\sigma}r \in H^{1}(0, L), \ (Dv + \frac{EI}{2\sigma}D^{2}(Dw + r) - \frac{\alpha}{2\sigma}r)|_{x=0} = 0 \end{array} \right\}.$$
(5.1.13)

**Theorem 5.1.1** The operator A defined in (5.1.12) and (5.1.13) generates a  $C_0$ semigroup  $S(t) = e^{At}$  of contractions on the Hilbert space  $\mathcal{H}$ .

**Proof** Clearly,  $\mathcal{D}(A)$  is dense in  $\mathcal{H}$ . By integration by parts, we have

$$\langle Az, z \rangle_{\mathcal{H}}$$

$$= \left\{ EI \langle D(Dv + \frac{EI}{2\sigma}D^{2}(Dw + r) - \frac{\alpha}{2\sigma}r), D(Dw + r) \rangle - EI \langle D^{3}(Dw + r), v \rangle \right.$$

$$\left. + \alpha \langle \frac{EI}{2\sigma}D^{2}(Dw + r) - \frac{\alpha}{2\sigma}r, r \rangle \right\}$$

$$= \left. -\frac{1}{2\sigma} \|EID^{2}(Dw + r) - \alpha r\|^{2} \le 0.$$
(5.1.14)

Thus,  $\mathcal{A}$  is dissipative. To apply Theorem 1.2.4 in Chapter 1, it remains to show that  $0 \in \rho(\mathcal{A})$ . For any  $F = (f, g, h)^T \in \mathcal{H}$ , consider the following equation:

$$\mathcal{A}z = F. \tag{5.1.15}$$

Equation (5.1.15) gives

$$v = f \in H^1(0, L) \tag{5.1.16}$$

$$-EID^{3}(Dw+r) = \rho g \in L^{2}(0,L)$$
 (5.1.17)

$$EID^{2}(Dw + r) - \alpha r = 2\sigma h \in L^{2}(0, L).$$
 (5.1.18)

To show that it yields a unique solution  $z \in \mathcal{D}(A)$ , we introduce another inner product space

$$\mathcal{H}_{1} = \left\{ \{w, r\} \middle| \begin{array}{l} w \in H^{1}(0, L), w|_{x=0} = 0, r \in L^{2}(0, L), \\ (Dw + r) \in H^{1}(0, L), (Dw + r)|_{x=0} = 0. \end{array} \right\}$$
 (5.1.19)

equipped with the inner product

$$\langle \{w, r\}, \{\widetilde{w}, \widetilde{r}\} \rangle_{\mathcal{H}_1} = EI\langle D(Dw + r), D(D\widetilde{w} + \widetilde{r}) \rangle + \alpha \langle r, \widetilde{r} \rangle. \tag{5.1.20}$$

It is clear that  $\mathcal{H}_1$  is also a Hilbert space. Thus, by the Riesz representation theorem, there is a unique  $\{w,r\} \in \mathcal{H}_1$  such that

$$\langle \{w, r\}, \{\widetilde{w}, \widetilde{r}\} \rangle_{\mathcal{H}_1} = -\langle \rho g, \widetilde{w} \rangle - \langle 2\sigma h, \widetilde{r} \rangle$$
 (5.1.21)

for all  $\{\tilde{w}, \tilde{r}\} \in \mathcal{H}_1$ .

In what follows, we use the standard variational approach to discuss regularity property of a pair of solutions  $\{w,r\}$  and what boundary conditions they satisfy. For this purpose, first by taking  $\tilde{w}=0$  and  $\tilde{r}\in C_0^\infty(0,L)$  in (5.1.21), we have

$$EI\langle D(Dw+r), D\tilde{r}\rangle + \alpha \langle r, \tilde{r}\rangle = -\langle 2\sigma h, \tilde{r}\rangle.$$
 (5.1.22)

It follows from (5.1.22) that Dw + r is a weak solution of

$$EID^{2}(Dw+r) = 2\sigma h + \alpha r \in L^{2}(0,L)$$

$$(5.1.23)$$

in the distribution sense. Thus, it follows that

$$Dw + r \in H^2(0, L). (5.1.24)$$

Similarly, we take  $\tilde{r} = 0$  in (5.1.21) to get that

$$EI\langle D(Dw+r), D^2\widetilde{w}\rangle = -\langle \rho g, \widetilde{w}\rangle$$
 (5.1.25)

holds for all  $\tilde{w} \in C_0^{\infty}(0,L)$ . Thus, we also obtain that Dw + r is a weak solution of

$$-EID^{3}(Dw+r) = \rho g \tag{5.1.26}$$

in the distribution sense which implies that  $Dw+r\in H^3(0,L)$ . Moreover, since (5.1.25) holds for any  $\widetilde{w}$  with  $\{\widetilde{w},0\}\in\mathcal{H}_1$ , by integration by parts, we can easily deduce that  $D(Dw+r)|_{x=L}=D^2(Dw+r)|_{x=L}=0$ . Other boundary conditions in the definition of  $\mathcal{D}(\mathcal{A})$  can be easily verified by the assumption,  $F\in\mathcal{H}$ . Therefore, a unique solution  $z=(w,v,r)^T\in\mathcal{D}(\mathcal{A})$  to (5.1.15) is obtained. Moreover, it is clear from (5.1.16)-(5.1.18) that  $\|z\|_{\mathcal{H}}\leq K\|F\|_{\mathcal{H}}$  with K being a positive constant. Thus,  $0\in\rho(\mathcal{A})$ . By Theorem 1.2.4, the proof of this lemma is complete.

**Theorem 5.1.2** The  $C_0$ -semigroup S(t), generated by A, is exponentially stable.

**Proof** We will use the systematic method described in this book, i.e., apply Theorem 1.3.2, and use the contradiction argument to prove the present theorem.

(i) Suppose that condition (1.3.3) is false. Since  $0 \in \rho(A)$ , then there is an  $\omega \in \mathbb{R}$  with

 $\|\mathcal{A}^{-1}\|^{-1} \leq |\omega| < \infty$  such that  $\{i\beta | |\beta| < |\omega|\} \subset \rho(\mathcal{A})$  and  $\sup\{\|(i\beta - \mathcal{A})^{-1}\| | |\beta| < |\omega|\} = \infty$ . Thus, there exists a sequence  $\beta_n \to \omega$ ,  $|\beta_n| < |\omega|$ , and a sequence of complex vectors  $z_n = (w_n, v_n, r_n)^T \in \mathcal{D}(\mathcal{A})$  with  $\|z_n\|_{\mathcal{H}} = 1$  such that as  $n \to \infty$ ,

$$\|(i\beta_n I - \mathcal{A})z_n\|_{\mathcal{H}} \to 0, \tag{5.1.27}$$

i.e.,

$$i\beta_n D(Dw_n + r_n) - D(Dv_n + \frac{EI}{2\sigma}D^2(Dw_n + r_n) - \frac{\alpha}{2\sigma}r_n) \to 0 \quad \text{in } L^2(0, L),$$
(5.1.28)

$$i\beta_n v_n + \frac{EI}{\rho} D^3(Dw_n + r_n) \to 0 \quad \text{in } L^2(0, L),$$
 (5.1.29)

$$i\beta_n r_n - \frac{EI}{2\sigma}D^2(Dw_n + r_n) + \frac{\alpha}{2\sigma}r_n \to 0 \quad \text{in } L^2(0, L).$$
 (5.1.30)

Since

$$|Re\langle Az_n, z_n \rangle_{\mathcal{H}}| \le ||(i\beta_n I - A)z_n||_{\mathcal{H}}, \tag{5.1.31}$$

it follows from (5.1.14), (5.1.27), and (5.1.31) that

$$||EID^{2}(Dw_{n} + r_{n}) - \alpha r_{n}|| \to 0,$$
 (5.1.32)

which further implies  $\|\beta_n r_n\| \to 0$ , due to (5.1.30). This yields

$$||r_n|| \to 0 \tag{5.1.33}$$

because  $|\beta_n|$  is bounded below from zero. It follows from (5.1.32) that

$$||D^2(Dw_n + r_n)|| \to 0,$$
 (5.1.34)

which further leads to

$$||D(Dw_n + r_n)|| \to 0,$$
 (5.1.35)

due to the Poincaré inequality.

In what follows, we prove that  $v_n$  converges to zero in  $L^2(0,L)$ . Combining this with (5.1.33), (5.1.35), and  $||z_n||_{\mathcal{H}} = 1$  will yield a contradiction. To do so, we first take the inner product of (5.1.29) with  $\frac{v_n}{\beta_n}$  in  $L^2$  and integrate by parts to get

$$|i\rho||v_n||^2 - EI\langle D^2(Dw_n + r_n), \frac{Dv_n}{\beta_n} \rangle \to 0.$$
 (5.1.36)

On the other hand, owing to (5.1.35), we can rewrite (5.1.28) as

$$D(\frac{Dv_n}{\beta_n} + \frac{EI}{2\sigma\beta_n}D^2(Dw_n + r_n) - \frac{\alpha}{2\sigma\beta_n}r_n) \to 0 \quad \text{in } L^2.$$
 (5.1.37)

Next, we take the inner product of (5.1.37) with  $D(Dw_n + r_n)$  in  $L^2$  and integrate by parts to obtain

$$\langle \frac{Dv_n}{\beta_n}, D^2(Dw_n + r_n) \rangle + \frac{EI}{2\sigma\beta_n} ||D^2(Dw_n + r_n)||^2 - \frac{\alpha}{2\sigma\beta_n} \langle r_n, D^2(Dw_n + r_n) \rangle \to 0.$$
(5.1.38)

It follows from (5.1.34) that the second and third terms in (5.1.38) converge to zero. Thus, combining (5.1.38) with (5.1.36) yields

$$||v_n|| \to 0,$$
 (5.1.39)

i.e., the desired contradiction. Thus (1.3.3) is verified.

(ii) Suppose that (1.3.4) is not true. Then we can repeat exactly the same argument as in part (i) to get the same contradiction because in the proof of part (i) we only use the fact that  $\beta_n$  is bounded below from zero. Thus, the proof is complete.

Furthermore, we have the subsequent theorem.

**Theorem 5.1.3** The semigroup S(t), generated by A, is analytic.

**Proof** Since we have already proved that  $i\mathbb{R} \subset \rho(\mathcal{A})$  in the previous theorem, we need only to verify condition (1.3.8) of Theorem 1.3.3. Suppose it is false. Then there exists a sequence  $\beta_n \to \infty$ ,  $(\beta_n > 0$  without loss of generality) and a sequence of complex vectors  $z_n = (w_n, v_n, r_n)^T \in \mathcal{D}(\mathcal{A})$  with  $||z_n||_{\mathcal{H}} = 1$  such that as  $n \to \infty$ ,

$$\left\| (iI - \frac{1}{\beta_n} \mathcal{A}) z_n \right\|_{\mathcal{H}} \to 0, \tag{5.1.40}$$

i.e.,

$$iD(Dw_n + r_n) - D(\frac{1}{\beta_n}Dv_n + \frac{EI}{2\sigma\beta_n}D^2(Dw_n + r_n) - \frac{\alpha}{2\sigma\beta_n}r_n) \to 0 \quad \text{in } L^2(0, L),$$

$$(5.1.41)$$

$$iv_n + \frac{EI}{\rho\beta_n}D^3(Dw_n + r_n) \to 0 \quad \text{in } L^2(0, L),$$
 (5.1.42)

$$ir_n - \frac{EI}{2\sigma\beta_n}D^2(Dw_n + r_n) + \frac{\alpha}{2\sigma\beta_n}r_n \to 0 \quad \text{in } L^2(0, L).$$
 (5.1.43)

Since

$$\left| \frac{1}{\beta_n} Re \langle \mathcal{A} z_n, z_n \rangle_{\mathcal{H}} \right| \le \left\| (iI - \frac{1}{\beta_n} \mathcal{A}) z_n \right\|_{\mathcal{H}}, \tag{5.1.44}$$

it follows from (5.1.40) and (5.1.14) that

$$\frac{1}{\beta_{-}} ||EID^{2}(Dw_{n} + r_{n}) - \alpha r_{n}||^{2} \to 0, \tag{5.1.45}$$

which implies

$$||r_n|| \to 0, \tag{5.1.46}$$

due to (5.1.43). Now (5.1.45) leads to

$$\frac{1}{\beta_n^{\frac{1}{2}}} \|D^2(Dw_n + r_n)\| \to 0. \tag{5.1.47}$$

In view of (5.1.42),  $\frac{1}{\beta_n}\|D^3(Dw_n+r_n)\|$  is uniformly bounded in n. Then, it follows from (5.1.41) that  $\frac{1}{\beta_n}\|D(Dv_n-\frac{\alpha}{2\sigma}r_n)\|$  is uniformly bounded in n. On the other hand, since  $EI\|D(Dw_n+r_n)\|^2 \leq 1$ , by the Poincaré inequality,  $\|Dw_n+r_n\|$  is uniformly bounded in n, which further leads to the uniform boundedness of  $\|Dw_n\|$  because  $\|r_n\| \to 0$ . It follows from

$$\frac{1}{\beta_n} \left\| D(Dv_n + \frac{\alpha}{2\sigma}Dw_n) \right\| \le \frac{1}{\beta_n} \left( \left\| D(Dv_n - \frac{\alpha}{2\sigma}r_n) \right\| + \frac{\alpha}{2\sigma} \left\| D(Dw + r_n) \right\| \right)$$
 (5.1.48)

that  $\frac{1}{\beta_n} \|D(Dv_n + \frac{\alpha}{2\sigma}Dw_n)\|$  is uniformly bounded in n. By the Gagliardo-Nirenberg inequality, we deduce that  $\frac{1}{\beta_n^2} \|Dv_n + \frac{\alpha}{2\sigma}Dw_n\|$  is also uniformly bounded. Therefore,

$$\frac{1}{\beta_n^{\frac{1}{2}}} ||Dv_n|| \le K, \quad \forall n \tag{5.1.49}$$

for some constant K > 0.

We now take the inner product of (5.1.42) with  $v_n$  in  $L^2(0, L)$  and integrate by parts to get

$$i\rho||v_n||^2 - \frac{1}{\beta_n} EI\langle D^2(Dw_n + r_n), Dv_n \rangle \to 0.$$
 (5.1.50)

Therefore, by (5.1.49) and (5.1.47) we have

$$||v_n|| \to 0. \tag{5.1.51}$$

Similarly, taking the inner product of (5.1.41) with  $D(Dw_n+r_n)$  in  $L^2(0,L)$ , integrating by parts and applying (5.1.46), (5.1.47), and (5.1.49), we also obtain

$$||D(Dw_n + r_n)|| \to 0. (5.1.52)$$

In summary, we have proved  $||z_n||_{\mathcal{H}} \to 0$  which contradicts  $||z_n||_{\mathcal{H}} = 1$ . Thus, the proof is complete.

Remark 5.1.1 For the simply supported boundary conditions, i.e.,

$$w = D^2 w + Dr = 0$$
, at  $x = 0, L$ , (5.1.53)

the exponential stability of the associated semigroup was proved in Liu & Zheng [3]. The analyticity of this semigroup was proved in Russell [2] as an example of his general results. A quite strong assumption he imposed is that all differential operators appeared in A in his general setting are mutually commutative. This assumption rules out most of other boundary conditions including the one considered here. A recent result on analyticity of the  $C_0$ -semigroup associated with a class of general linear coupled systems without the "commutative" restriction has been obtained in Liu & Yong [1] which also includes an application to the shear diffusion equations. But only the example with simply supported boundary conditions was given.

#### 5.2 Laminated Beam with Shear Damping

In this section, we discuss the exponential stability and analyticity of the  $C_0$ -semigroup associated with a three-layer laminated beam model given in Liu, Trogdon & Yong [1].

Consider a three-layer laminated beam of unit width and length L with  $0 \le x \le L$ . The beam is composed of a top and a bottom face-plate of thicknesses  $h^{(1)}$  and  $h^{(3)}$ , and a core layer of thickness  $h^{(2)}$ . The top and bottom layers are made of linear elastic material. The core layer is assumed to be a material of Kelvin-Voigt type with a shear stress-strain relation

$$\tau = c\gamma + c_1 \gamma_t. \tag{5.2.1}$$

Under some assumptions, we are led to the following coupled system of partial differential equations (we refer to the reader to the paper Liu, Trogdon & Yong [1] for the detail of derivation):

$$\begin{cases}
\rho h w_{tt} = -E_e I_e \frac{\partial^4 w}{\partial x^4} - \frac{\alpha}{k} \frac{\partial}{\partial x} \left( \alpha \frac{\partial^3 w}{\partial x^3} - 2h^{(2)} \frac{\partial^2 \gamma}{\partial x^2} \right), \\
c_1 \gamma_t = -c \gamma - \frac{1}{k} \left( \alpha \frac{\partial^3 w}{\partial x^3} - 2h^{(2)} \frac{\partial^2 \gamma}{\partial x^2} \right)
\end{cases} (5.2.2)$$

where  $\rho, h, E_e, I_e, \alpha, k, h^{(2)}, c_1, c$  are given positive constants depending on the material properties and reference configuration of the beam; w and  $\gamma$  are the transversal displacement and shear strain of the core layer, respectively. When  $c_1 = 0$ , one can eliminate  $\gamma$  in equation (5.2.2) to obtain a sixth-order partial differential equation

$$\frac{ck}{2h^{(2)}}\frac{\rho h}{E_eI_e}w_{tt} - \frac{\rho h}{E_eI_e}\frac{\partial^2 w_{tt}}{\partial x^2} + \frac{ck}{2h^{(2)}}\left(1 + \frac{\alpha^2}{E_eI_ek}\right)\frac{\partial^4 w}{\partial x^4} - \frac{\partial^6 w}{\partial x^6} = 0. \tag{5.2.3}$$

By scaling in time, equation (5.2.3) coincides with the three-layer laminated beam equation derived in Mead & Markus [1] and D.K. Rao [1].

This system is slightly different from the shear diffusion model discussed in the previous section. However, their physical interpretation has essential differences. For the three-layer laminated beam model, shear damping in the core layer is passed on to the other layers through the interfaces to cause the energy dissipation. From mathematical point of view it significantly differs from the classical thermoelastic beam model in some aspects. Equations (5.2.2) are coupled via a spatial derivative of the beam displacement, while the classical thermoelastic beam equations are coupled via the spatial derivative of beam velocity.

The boundary conditions and the initial conditions considered in this section are the following:

$$w = \frac{\partial w}{\partial x} = \gamma = 0, \quad \text{at } x = 0,$$
 (5.2.4)

$$\begin{cases} \frac{\partial \gamma}{\partial x} = \frac{\partial^2 w}{\partial x^2} = 0, & \text{at } x = L, \\ E_e I_e \frac{\partial^3 w}{\partial x^3} + \frac{\alpha}{k} \left( \alpha \frac{\partial^3 w}{\partial x^3} - 2h^{(2)} \frac{\partial^2 \gamma}{\partial x^2} \right) = 0, & \text{at } x = L, \end{cases}$$
(5.2.5)

$$w(x,0) = w_0(x), \ w_t(x,0) = w_1(x), \ \gamma(x,0) = \gamma_0(x).$$
 (5.2.6)

The total energy of the system (5.2.2)–(5.2.5) is defined by

$$E(t) = \frac{1}{2} \int_0^L \left[ E_e I_e \left( \frac{\partial^2 w}{\partial x^2} \right)^2 + \frac{1}{k} \left( \alpha \frac{\partial^2 w}{\partial x^2} - 2h^{(2)} \frac{\partial \gamma}{\partial x} \right)^2 + 2h^{(2)} c \gamma^2 + \rho h w_t^2 \right] dx \quad (5.2.7)$$

where the first three terms in (5.2.7) represent the energy due to bending, stretching and shearing, and the last term is the kinetic energy.

Let  $H_l^m(0,L)$  be a closed subspace of the usual Sobolev space  $H^m(0,L)$  defined as follows:  $H_l^m(0,L) = \{u \in H^m(0,L) | u|_{x=0} = \cdots = D^{m-1}u|_{x=0} = 0\}$ . Let

$$\mathcal{H} = H_l^2(0, L) \times L^2(0, L) \times H_l^1(0, L)$$
(5.2.8)

equipped with the norm

$$\|(w, v, \gamma)^T\|_{\mathcal{H}} = \left(E_e I_e \|D^2 w\|^2 + \rho h \|v\|^2 + \frac{1}{k} \|\alpha D^2 w - 2h^{(2)} D\gamma\|^2 + 2h^{(2)} c \|\gamma\|^2\right)^{\frac{1}{2}}$$
(5.2.9)

and the corresponding inner product. Then it is easy to see that  $\mathcal{H}$  is also a Hilbert space. To study the initial boundary value problem (5.2.2)–(5.2.6) by the semigroup theory, we denote by  $v = w_t$  and  $z = (w, v, \gamma)^T$  and rewrite problem (5.2.2)–(5.2.6) as the initial value problem for a first-order evolution equation in  $\mathcal{H}$ :

$$\begin{cases} \frac{dz(t)}{dt} = \mathcal{A}z(t), & \forall t > 0\\ z(0) = z_0 = (w_0, w_1, \gamma_0)^T \end{cases}$$
 (5.2.10)

with

$$\mathcal{A} \begin{pmatrix} w \\ v \\ \gamma \end{pmatrix} = \begin{pmatrix} v \\ \frac{1}{\rho h} \left( -E_e I_e D^4 w - \frac{\alpha}{k} D(\alpha D^3 w - 2h^{(2)} D^2 \gamma) \right) \\ \frac{1}{c_1} \left( -c\gamma - \frac{1}{k} (\alpha D^3 w - 2h^{(2)} D^2 \gamma) \right) \end{pmatrix}$$
 (5.2.11)

and

$$\mathcal{D}(\mathcal{A}) = \left\{ (w, v, r)^T \in \mathcal{H} \middle| \begin{array}{l} w \in H^4, \ v \in H_l^2, \gamma \in H^3, \ D\gamma|_{x=L} = D^2 w|_{x=L} = 0, \\ (\alpha D^3 w - 2h^{(2)} D^2 \gamma)|_{x=0} = 0, \\ \left[ E_e I_e D^3 w + \frac{\alpha}{k} \left( \alpha D^3 w - 2h^{(2)} D^2 \gamma \right) \right] \middle|_{x=L} = 0 \end{array} \right\}.$$
(5.2.12)

Now we have the following.

**Theorem 5.2.1** The operator A defined in (5.2.11) and (5.2.12) generates a  $C_0$ -semigroup  $S(t) = e^{At}$  of contractions on the Hilbert space  $\mathcal{H}$ .

**Proof** It is clear that  $\mathcal{D}(\mathcal{A})$  is dense in  $\mathcal{H}$ . We first prove that  $\mathcal{A}$  is dissipative. For any  $(w, v, \gamma)^T \in \mathcal{D}(\mathcal{A})$ , by integration by parts we have

$$Re\langle \mathcal{A}(w, v, \gamma)^{T}, (w, v, \gamma)^{T} \rangle_{\mathcal{H}}$$

$$= Re\left[ E_{e} I_{e} \langle D^{2}v, D^{2}w \rangle + \langle -E_{e} I_{e} D^{4}w - \frac{\alpha}{k} D(\alpha D^{3}w - 2h^{(2)}D^{2}\gamma), v \rangle \right.$$

$$\left. + \frac{1}{k} \langle \alpha D^{2}v - \frac{2h^{(2)}}{c_{1}} \left( -cD\gamma - \frac{1}{k} D(\alpha D^{3}w - 2h^{(2)}D^{2}\gamma) \right), \alpha D^{2}w - 2h^{(2)}D\gamma \rangle \right.$$

$$\left. + 2h^{(2)}c \langle \frac{1}{c_{1}} \left( -c\gamma - \frac{1}{k} (\alpha D^{3}w - 2h^{(2)}D^{2}\gamma) \right), \gamma \rangle \right]$$

$$= -\frac{2h^{(2)}}{c_{1}} \|c\gamma + \frac{1}{k} \left( \alpha D^{3}w - 2h^{(2)}D^{2}r \right) \|^{2} \leq 0.$$
(5.2.13)

Thus, A is dissipative.

We then show that  $0 \in \rho(\mathcal{A})$ . In doing so, for any  $F = (f, g, p) \in \mathcal{H}$ , we consider the equation  $\mathcal{A}(w, v, r)^T = F$ , i.e.,

$$\begin{cases} v = f \in H_{l}^{2}, \\ \frac{E_{e}I_{e}}{\rho h}D^{4}w + \frac{\alpha}{k\rho h}D(\alpha D^{3}w - 2h^{(2)}D^{2}\gamma) = -g \in L^{2}, \\ \frac{c}{c_{1}}\gamma + \frac{1}{kc_{1}}\left(\alpha D^{3}w - 2h^{(2)}D^{2}\gamma\right) = -p \in H_{l}^{1}. \end{cases}$$
(5.2.14)

In order to obtain unique solvability of a pair of solutions  $\{w,\gamma\}$  to the second and third equations of (5.2.14), we introduce a bilinear form on  $H_l^2(0,L) \times H_l^1(0,L)$  as follows:

$$b(\{w,r\}, \{\widetilde{w},\widetilde{r}\}) = E_e I_e \langle D^2 w, D^2 \widetilde{w} \rangle + \frac{1}{k} \langle \alpha D^2 w - 2h^{(2)} D\gamma, \alpha D^2 \widetilde{w} - 2h^{(2)} D\widetilde{\gamma} \rangle + 2h^{(2)} c \langle \gamma, \widetilde{\gamma} \rangle.$$
 (5.2.15)

It is easy to see from the Poincaré inequality that this bilinear form is bounded and coercive on  $H^2_l(0,L)\times H^1_l(0,L)$ . Thus by the Lax-Milgram theorem, there is a unique  $\{w,r\}\in H^2_l(0,L)\times H^1_l(0,L)$  such that

$$b(\lbrace w, r \rbrace, \lbrace \widetilde{w}, \widetilde{r} \rbrace) = -\rho h(g, \widetilde{w}) - 2h^{(2)}c_1(p, \widetilde{\gamma})$$
(5.2.16)

for all  $\{\tilde{w}, \tilde{\gamma}\} \in H_l^2(0, L) \times H_l^1(0, L)$ . In what follows, we use the standard variational approach and the bootstrap argument to prove that  $(w, v, \gamma)^T \in \mathcal{D}(\mathcal{A})$  and it is the unique solution to (5.2.14).

Indeed, by taking  $\tilde{w} = 0$  , we obtain that

$$\frac{1}{k}\langle \alpha D^2 w - 2h^{(2)}D\gamma, -2h^{(2)}D\tilde{\gamma}\rangle + 2h^{(2)}c\langle \gamma, \tilde{\gamma}\rangle = -2h^{(2)}c_1\langle p, \tilde{\gamma}\rangle$$
 (5.2.17)

holds for any  $\tilde{r} \in C_0^{\infty}(0, L)$ . This means that  $w, \gamma$  satisfy the following equation in the distribution sense:

$$\frac{c}{c_1}\gamma + \frac{1}{kc_1}D\left(\alpha D^2 w - 2h^{(2)}D^1\gamma\right) = -p \in H_l^1(0, L). \tag{5.2.18}$$

Since  $\gamma, p \in H_l^1$ , we can conclude that

$$D(\alpha D^2 w - 2h^{(2)}D\gamma) \in H_l^1. \tag{5.2.19}$$

Now, we take  $\tilde{\gamma} = 0$  in (5.2.16) to get that

$$E_{e}I_{e}\langle D^{2}w, D^{2}\widetilde{w}\rangle + \frac{1}{k}\langle \alpha D^{2}w - 2h^{(2)}D\gamma, \ \alpha D^{2}\widetilde{w}\rangle = -\rho h\langle g, \widetilde{w}\rangle$$
 (5.2.20)

holds for any  $\tilde{w} \in C_0^{\infty}(0, L)$ . Thus,  $w, \gamma$  satisfy the following equation in the distribution sense:

$$\frac{E_e I_e}{\rho h} D^4 w + \frac{\alpha}{k \rho h} D^2 \left( \alpha D^2 w - 2h^{(2)} D^1 \gamma \right) = -g \in L^2(0, L). \tag{5.2.21}$$

It follows from (5.2.19) and (5.2.21) that  $w \in H^4(0,L), \gamma \in H^3(0,L)$ . Since  $w, \gamma$  satisfy (5.2.18) and (5.2.17) holds for any  $\tilde{\gamma} \in H^1_l$ , by integration by parts, we deduce that

$$(\alpha D^2 w - 2h^{(2)}D\gamma)|_{x=L} = 0. (5.2.22)$$

Similarly, since  $w, \gamma$  satisfy (5.2.21), and (5.2.20) holds for any  $\widetilde{w} \in H^2_l$ , we obtain that

$$(E_e I_e D^3 w + \frac{\alpha}{k} (\alpha D^3 w - 2h^{(2)} D^2 \gamma))|_{x=L} = 0,$$
 (5.2.23)

and

$$(E_e I_e D^2 w + \frac{\alpha}{h} (\alpha D^2 w - 2h^{(2)} D\gamma))|_{x=L} = 0.$$
 (5.2.24)

Combining (5.2.22) with (5.2.24) yields

$$D^2 w|_{x=L} = D\gamma|_{x=L} = 0. (5.2.25)$$

It follows from (5.2.23), (5.2.25), and  $F \in \mathcal{H}$  that  $\mathcal{A}(w,v,\gamma)^T = F$  has a unique solution  $(w,v,\gamma)^T \in \mathcal{D}(\mathcal{A})$ . Thus by Theorem 1.2.4 in Chapter 1,  $\mathcal{A}$  generates a  $C_0$ -semigroup of contractions in  $\mathcal{H}$ . The proof is complete.

Furthermore, we have the subsequent theorem.

**Theorem 5.2.2** The semigroup  $S(t) = e^{At}$ , generated by A, is analytic and exponentially stable.

**Proof** We first prove the analyticity of S(t) by verifying two conditions in Theorem 1.3.3 in Chapter 1.

(i) Suppose that condition (1.3.7) is false. Since we already have proved in the previous theorem that  $0 \in \rho(\mathcal{A})$ , it turns out that there exists an  $\omega \in \mathbb{R}$  with  $\|\mathcal{A}^{-1}\|^{-1} \leq |\omega| < \infty$ , a sequence of  $\beta_n \in \mathbb{R}$  with  $|\beta_n| < |\omega|$ ,  $\beta_n \to \omega$  and a sequence of complex vectors  $z_n = (w_n, v_n, \gamma_n)^T \in \mathcal{D}(\mathcal{A})$  with  $\|z_n\|_{\mathcal{H}} = 1$  such that as  $n \to \infty$ ,

$$\|(i\beta_n I - \mathcal{A})z_n\|_{\mathcal{H}} \to 0,$$
 (5.2.26)

i.e.,

$$i\beta_n w_n - v_n \to 0 \quad \text{in } H^2,$$
 (5.2.27)

$$i\beta_n v_n + \frac{E_e I_e}{\rho h} D^4 w + \frac{\alpha}{k\rho h} D\left(\alpha D^3 w_n - 2h^{(2)} D^2 \gamma_n\right) \to 0 \quad \text{in } L^2, \quad (5.2.28)$$

$$i\beta_n\gamma_n + \frac{c}{c_1}\gamma_n + \frac{1}{kc_1}\left(\alpha D^3 w_n - 2h^{(2)}D^2\gamma_n\right) \to 0 \quad \text{in } H^1.$$
 (5.2.29)

Since

$$|Re\langle Az_n, z_n\rangle_{\mathcal{H}}| \le ||(i\beta_n I - A)z_n||_{\mathcal{H}},$$
 (5.2.30)

by (5.2.13) we have

$$\|c\gamma_n + \frac{1}{k}(\alpha D^3 w_n - 2h^{(2)}D^2\gamma_n)\| \to 0,$$
 (5.2.31)

which further implies

$$\|\gamma_n\| \to 0 \tag{5.2.32}$$

due to (5.2.29). Combining (5.2.31) with (5.2.32) yields

$$\|\alpha D^3 w_n - 2h^{(2)} D^2 \gamma_n\| \to 0.$$
 (5.2.33)

By the Poincaré inequality, we have

$$\|\alpha D^2 w_n - 2h^{(2)} D\gamma_n\| \to 0.$$
 (5.2.34)

On the other hand, if we take the inner product of (5.2.27) with  $v_n$  in  $L^2$ , add it to the complex conjugate of the inner product of (5.2.28) with  $w_n$ , integrate by parts and use (5.2.34), then we obtain

$$E_e I_e ||D^2 w_n||^2 - \rho h ||v_n||^2 \to 0.$$
 (5.2.35)

Note that equation (5.2.28) implies that

$$\frac{1}{\beta_n} \|E_e I_e D^4 w_n + \frac{\alpha}{k} D(\alpha D^3 w_n - 2h^{(2)} D^2 \gamma_n)\| \le K$$
 (5.2.36)

for some positive constant K independent of n. Applying the Poincaré inequality and using (5.2.33), we also get the uniform boundedness of  $\frac{1}{\beta_n} \|D^2 \gamma_n\|$  and  $\frac{1}{\beta_n} \|D^3 w\|$ . Taking the inner product of (5.2.29) with  $\frac{c_1}{\beta_n} D^2 \gamma$  in  $L^2$ , and integarting by parts, we get that

$$c_1 i \|D\gamma_n\|^2 - \frac{1}{\beta_n} \langle c\gamma_n + \frac{1}{k} (\alpha D^3 w_n - 2h^{(2)} D^2 \gamma), D^2 \gamma_n \rangle \to 0.$$
 (5.2.37)

Combining it with (5.2.31) yields

$$||D\gamma_n|| \to 0, \tag{5.2.38}$$

which further leads to

$$||D^2 w_n|| \to 0, \quad ||v_n||^2 \to 0,$$
 (5.2.39)

due to (5.2.38), (5.2.34), and (5.2.35). In summary, we have obtained  $||z_n||_{\mathcal{H}} \to 0$ . This is a contradiction.

(ii) We now prove (1.3.8), i.e.,

$$\lim_{|\beta| \to \infty} |\beta| \|(i\beta - \mathcal{A})^{-1}\| < \infty. \tag{5.2.40}$$

Suppose it is false. Then there exists a sequence  $\beta_n > 0$  (without loss of generality),  $\beta_n \to \infty$ , and a sequence of complex vectors  $z_n = (w_n, v_n, \gamma_n)^T \in \mathcal{D}(\mathcal{A})$  with  $||z_n||_{\mathcal{H}} = 1$  such that as  $n \to \infty$ ,

$$\|(iI - \frac{1}{\beta_-}\mathcal{A})z_n\|_{\mathcal{H}} \to 0, \tag{5.2.41}$$

i.e.,

$$iw_n - \frac{1}{\beta_n}v_n \to 0 \quad \text{in } H^2, \tag{5.2.42}$$

$$iv_n + \frac{E_e I_e}{\rho h \beta_n} D^4 w_n + \frac{\alpha}{\rho h k \beta_n} D(\alpha D^3 w_n - 2h^{(2)} D^2 \gamma_n) \to 0$$
 in  $L^2$ , (5.2.43)

$$i\gamma_n + \frac{c}{c_1\beta_n}\gamma_n + \frac{1}{kc_1\beta_n}(\alpha D^3 w_n - 2h^{(2)}D^2\gamma_n) \to 0 \quad \text{in } H^1.$$
 (5.2.44)

Since

$$|Re\langle \frac{1}{\beta_n} \mathcal{A} z_n, z_n \rangle_{\mathcal{H}}| \le \|(iI - \frac{1}{\beta_n} \mathcal{A}) z_n\|_{\mathcal{H}}, \tag{5.2.45}$$

by (5.2.13) we have

$$\frac{1}{\beta_n} \|c\gamma_n + \frac{1}{k} (\alpha D^3 w_n - 2h^{(2)} D^2 \gamma_n)\|^2 \to 0$$
 (5.2.46)

which implies

$$\|\gamma_n\| \to 0, \tag{5.2.47}$$

and

$$\frac{1}{\beta_n} \|(\alpha D^3 w_n - 2h^{(2)} D^2 \gamma_n)\|^2 \to 0, \tag{5.2.48}$$

due to (5.2.44). Taking the inner product of (5.2.44) with  $\gamma_n$  in  $H_l^1$  and using the fact that  $\beta_n \to \infty$ , we have

$$i\|D\gamma_n\|^2 + \frac{1}{kc_1\beta_n} \langle D(\alpha D^3 w_n - 2h^{(2)}D^2\gamma_n), D\gamma_n \rangle \to 0.$$
 (5.2.49)

It is easy to see from (5.2.43) and (5.2.44) that both  $\frac{1}{\beta_n} \|D(\alpha D^3 w_n - 2h^2 D^2 \gamma_n)\|$  and  $\frac{1}{\beta_n} \|D^4 w_n\|$  are uniformly bounded. Thus,  $\frac{1}{\beta_n} \|D^3 \gamma_n\|$  is also uniformly bounded. By the Gagliardo-Nirenberg inequality,  $\frac{1}{\beta_n^{1/2}} \|D^2 \gamma_n\|$  is also uniformly bounded. Owing to

(5.2.48), by integration by parts we can deduce that

$$\frac{1}{\beta_n} \langle D(\alpha D^3 w_n - 2h^{(2)} D^2 \gamma_n), D\gamma_n \rangle 
= \langle \frac{1}{\beta_n^{1/2}} (\alpha D^3 w_n - 2h^{(2)} D^2 \gamma_n), \frac{1}{\beta_n^{1/2}} D^2 \gamma_n \rangle \to 0.$$
(5.2.50)

Therefore, it follows from (5.2.49) that

$$||D\gamma_n|| \to 0. \tag{5.2.51}$$

By the Gagliardo-Nirenberg inequality again, we have

$$\frac{1}{\beta_n^{1/2}} \|D^2 \gamma_n\| \le \left(\frac{1}{\beta_n} \|D^3 \gamma_n\|\right)^{\frac{1}{2}} \|D \gamma_n\|^{\frac{1}{2}} \to 0. \tag{5.2.52}$$

Combining (5.2.52) with (5.2.48), we obtain

$$\frac{1}{\beta_n^{1/2}} \|D^3 w_n\| \to 0. \tag{5.2.53}$$

By  $||z_n||_{\mathcal{H}} = 1$  and (5.2.42),  $\frac{1}{\beta_n} ||D^2 v_n||$  and  $||v_n||$  are uniformly bounded. Then by the Gagliardo-Nirenberg inequality,  $\frac{1}{\beta_n^{1/2}} ||Dv_n||$  is also uniformly bounded. We now take the inner product of (5.2.43) with  $v_n$  in  $L^2$  and integrate by parts to get

$$i\|v_{n}\|^{2} - \frac{E_{e}I_{e}}{\rho h} \langle \frac{1}{\beta_{n}^{1/2}} D^{3}w_{n}, \frac{1}{\beta_{n}^{1/2}} Dv_{n} \rangle - \frac{\alpha}{\rho h k} \langle \frac{1}{\beta_{n}^{1/2}} (\alpha D^{3}w_{n} - 2h^{(2)}D^{2}\gamma_{n}), \frac{1}{\beta_{n}^{1/2}} Dv_{n} \rangle \to 0.$$
 (5.2.54)

The last two terms in (5.2.54) converge to zero because of (5.2.48) and (5.2.53). Hence,

$$||v_n|| \to 0. \tag{5.2.55}$$

Furthermore, we take the inner product of (5.2.42) with  $w_n$  in  $H_l^2$ , then add it to the complex conjugate of the inner product of (5.2.43) with  $v_n$  in  $L^2$ . After integration by parts we arrive at

$$E_e I_e ||D^2 w_n||^2 - \rho h ||v_n||^2 \to 0.$$
 (5.2.56)

Combining (5.2.56) with (5.2.55) yields

$$||D^2w|| \to 0. \tag{5.2.57}$$

In summary, (5.2.47), (5.2.51), (5.2.55), and (5.2.57) imply

$$||z_n||_{\mathcal{H}} \to 0, \tag{5.2.58}$$

which contradicts  $||z_n||_{\mathcal{H}} = 1$ . The proof for analyticity of S(t) is complete.

The exponential stability of S(t) is just a direct consequence of analyticity since  $i\mathbb{R} \subset \rho(A)$  and S(t) is a  $C_0$ -semigroup of contractions in the Hilbert space  $\mathcal{H}$ .

### Chapter 6

## Linear Elastic Systems with Boundary Damping

In the previous chapters, we have discussed the semigroup properties of some linear elastic systems with various damping. These dampings are all distributed on the domain, either on the whole domain or on a subset of the domain whose measure is positive. We now turn our attention to some linear elastic systems with boundary damping. Exponential stability of the semigroup associated with a second-order hyperbolic equation with boundary damping, and a nonhomogeneous Euler-Bernoulli beam equation with boundary damping will be proved in section 6.1 and 6.2, respectively. We will still use the contradiction argument as in the previous chapters. As in Section 3.2, a combination of the contradiction argument with the frequency domain multiplier technique is used.

#### 6.1 Second-Order Hyperbolic Equation

Consider the following linear second-order hyperbolic equation with boundary damping

$$\begin{cases}
\rho(x)\frac{\partial^{2}w}{\partial t^{2}} - \sum_{i,j=1}^{m} \frac{\partial}{\partial x_{i}} (a_{ij}(x)\frac{\partial w}{\partial x_{j}}) + q(x)w = 0 & \text{in } \Omega \times (0,\infty), \\
w = 0 & \text{on } \Gamma_{0} \times [0,\infty), \\
\sum_{i,j=1}^{m} a_{ij}\frac{\partial w}{\partial x_{j}} \nu_{i} + b(x)\frac{\partial w}{\partial t} = 0 & \text{on } \Gamma_{1} \times [0,\infty), \\
w(x,0) = w_{0}(x), \quad w_{t}(x,0) = v_{0}(x)
\end{cases}$$
(6.1.1)

where  $\Omega$  is a bounded domain in  $\mathbb{R}^m (m \geq 2)$  with a  $C^2$  boundary  $\Gamma = \Gamma_0 \cup \Gamma_1$  and  $\overline{\Gamma}_0 \cap \overline{\Gamma}_1 = \emptyset$ ;  $\boldsymbol{\nu} = (\nu_1, \dots, \nu_m)$  is the unit outward normal vector on  $\Gamma$ ,  $b(x) \in C^1(\overline{\Gamma}_1)$  and  $b(x) \geq b_0 > 0$  on  $\Gamma_1$ . Boundary  $\Gamma_0$  is called an energy reflecting surface, and  $\Gamma_1$ , an energy absorbing surface. It is well-known that vertical vibration of a thin elastic membrane of shape  $\Omega \in \mathbb{R}^2$  with one edge  $\Gamma_0$  being clamped and another edge  $\Gamma_1$  subject to friction which is proportional to velocity, can be reduced to problem

(6.1.1).

We assume that the real-valued coefficient functions in (6.1.1) satisfy the following conditions:  $\rho(x) \in C^2(\overline{\Omega})$ ,  $q(x) \in L^{\infty}(\Omega)$  and  $a_{ij}(x)$ ,  $i, j = 1, \dots, m$  are in  $C^1(\overline{\Omega})$  and  $\rho(x) \geq \rho_0 > 0$ ,  $q(x) \geq 0$  in  $\Omega$ ;  $A(x) = (a_{ij}(x))$  is an  $m \times m$  symmetric and positive definite matrix.

Let  $H^1_{\Gamma_0}(\Omega)=\{w\in H^1(\Omega)\mid w|_{\Gamma_0}=0\}$  and we introduce the following Hilbert space

$$\mathcal{H} = H^1_{\Gamma_0}(\Omega) \times L^2_{\rho}(\Omega) \tag{6.1.2}$$

equipped with the inner product: for  $z_1 = (w_1, v_1)^T$ ,  $z_2 = (w_2, v_2)^T \in \mathcal{H}$ ,

$$\langle z_1, z_2 \rangle_{\mathcal{H}} = \int_{\Omega} ((A(x)\nabla w_1) \cdot \nabla w_2 + q(x)w_1w_2 + \rho(x)v_1v_2) dx.$$
 (6.1.3)

When w and v are complex-valued functions, we can define the inner product, accordingly. The energy of system (6.1.1) is defined by

$$E(t) = \frac{1}{2} \int_{\Omega} (\rho w_t^2 + (A \nabla w) \cdot \nabla w + q w^2) dx.$$
 (6.1.4)

In this section, we want to show that under some conditions on the coefficient functions  $\rho(x)$ ,  $a_{ij}(x)$  and on the geometry of  $\Omega$ , E(t) decays exponentially to zero, i.e., there exist constants  $M, \alpha > 0$  such that

$$E(t) \le Me^{-\alpha t}E(0), \quad t \ge 0,$$
 (6.1.5)

as long as  $E(0) < +\infty$ .

Let us first recall the related works in the literature. Quinn & Russell [1] is a pioneering work in this direction. In the case that  $a_{ij}(x) = \delta_{ij}$  and  $\rho(x) = 1$  (the equation in (6.1.1) then becomes the wave equation), Chen [1], published in 1979, was the first one to succeed in showing (6.1.5) on (star-complemented)-(strongly star-shaped) domain  $(\Omega, \Gamma_0, \Gamma_1)$  (see Chen [1] for the precise definition of such kind of domains). In 1981, Chen [2] obtained (6.1.5) again under the following relaxed conditions: there exists a vector field  $\mathbf{l}(x) = (l_1(x), \dots, l_m(x))^T \in C^4(\mathbb{R}^m, \mathbb{R}^m)$  with compact support such that

- (i)  $\boldsymbol{l} \cdot \boldsymbol{\nu} \leq 0$  on  $\Gamma_0$ ;
- (ii)  $l \cdot \nu \geq \gamma_1 > 0$  on  $\Gamma_1$  for some constant  $\gamma_1$ ;
- (iii)  $\frac{\partial l_i}{\partial x_i}(x) \frac{1}{2}\delta_{ij}$  is strictly positive definite;
- (iv) there exists constant  $\gamma_2 > 0$  small enough such that

$$\left| \frac{\partial^3 l_i}{\partial x_j^2 \partial x_i} \right| \le \gamma_2, \quad \text{on } \Omega; \quad \left| \frac{\partial^2 l_i}{\partial x_j \partial x_i} \right| \le \gamma_2 \quad \text{on } \Gamma_1.$$
 (6.1.6)

Later on in 1983, Lagnese [1]-[2] improved Chen's result by changing condition (iii) and (iv) into

(iii)' the matrix 
$$[l_{i,j}+l_{j,i}]$$
 is possitive definite on  $\overline{\Omega}$  where  $l_{i,j}=\frac{\partial l_i}{\partial x_j}$ 

Lagnese's result has subsequently been reproved by Lasiecka & Triggiani [1] and Triggiani [1] using a different method. In all of the above papers, the estimate (6.1.5) was obtained by the energy method and by employing a result of Datko [1] from the estimate on  $\int_0^\infty E(t) dt$ .

For the general second-order linear hyperbolic equation (6.1.1), in 1994 Wyler [1] obtained (6.1.5) under conditions (i), (ii) and

(iii)" the matrix  $p_{ij} = a_{ik}l_{j,k} + a_{jk}l_{i,k} + \frac{\nabla \rho \cdot \boldsymbol{l}}{\rho}a_{ij} - \nabla a_{ij} \cdot \boldsymbol{l}$  is uniformly positive definite on  $\Omega$ .

Hereafter the summation convention is used. Notice that condition (iii)' is just a special case of (iii)" when the equation in (6.1.1) is the wave equation. Wyler's method is based on Gearhart's theorem (see Theorem 1.3.2 in Chapter 1). He used a contradiction argument to prove (1.3.3). However, for the proof of (1.3.4), he used a direct estimate on the resolvent.

In what follows, we will reprove Wyler's result by a contradiction argument both for the proof of (1.3.3) and (1.3.4). To convert the system (6.1.1) into an abstract

first-order evolution equation, we define the unbounded operator  $\mathcal{A}$  and its domain  $\mathcal{D}(\mathcal{A})$  as follows:

$$\mathcal{D}(\mathcal{A}) = \left\{ z = (w, v)^T \in \mathcal{H} \middle| \begin{array}{c} w \in H^2, \ v \in H^1_{\Gamma_0}(\Omega), \\ \boldsymbol{\nu} \cdot (A(x)\nabla w) + b(x)v|_{\Gamma_1} = 0 \end{array} \right\}, \tag{6.1.7}$$

$$\mathcal{A}\begin{pmatrix} w \\ v \end{pmatrix} = \begin{pmatrix} v \\ \frac{1}{\rho(x)} [\nabla \cdot (A(x)\nabla w) - q(x)w] \end{pmatrix}. \tag{6.1.8}$$

Then (6.1.1) can be reduced to the initial value problem for an abstract first-order evolution equation

$$\begin{cases} \frac{dz}{dt} = Az, & \forall t > 0\\ z(0) = z_0 \end{cases}$$
(6.1.9)

where  $z = (w, v)^T, v = w_t, z_0 = (w_0, v_0)^T$ .

**Theorem 6.1.1** The operator A defined in (6.1.7)-(6.1.8) generates a  $C_0$ -semigroup  $S(t) = e^{At}$  of contractions on the Hilbert space  $\mathcal{H}$ .

**Proof** We use Theorem 1.2.4 in Chapter 1 to prove the present theorem.

Clearly,  $\mathcal{D}(\mathcal{A})$  is dense in  $\mathcal{H}$ . In what follows, we first prove the dissipativeness of  $\mathcal{A}$ . Let  $z = (w, v)^T \in \mathcal{D}(\mathcal{A})$ . Since

$$\langle Az, z \rangle_{\mathcal{H}}$$

$$= \int_{\Omega} ((A(x)\nabla w) \cdot \nabla v + q(x)vw)dx + \int_{\Omega} (\nabla \cdot (A(x)\nabla w) - q(x)w)vdx$$

$$= \int_{\Gamma} \boldsymbol{\nu} \cdot (A(x)\nabla w)vd\sigma$$

$$= -\int_{\Gamma} b(x)|v|^2 d\sigma \leq 0, \qquad (6.1.10)$$

 $\mathcal{A}$  is dissipative. Therefore, it suffices to show that  $0 \in \rho(\mathcal{A})$ . For any  $(f,g)^T \in \mathcal{H}$ , consider the following equation

$$\mathcal{A}\begin{pmatrix} w \\ v \end{pmatrix} = \begin{pmatrix} f \\ g \end{pmatrix}, \quad \begin{pmatrix} w \\ v \end{pmatrix} \in \mathcal{D}(\mathcal{A}), \tag{6.1.11}$$

i.e.,

$$\begin{cases} v = f \in H^1_{\Gamma_0} \\ \nabla \cdot (A(x)\nabla w) - q(x)w = \rho(x)g \in L^2(\Omega). \end{cases}$$
 (6.1.12)

To solve the second equation in (6.1.12) subject to the following boundary conditions

$$\begin{cases} w|_{\Gamma_0} = 0, \\ \mathbf{\nu} \cdot (A(x)\nabla w)|_{\Gamma_1} = -b(x)f|_{\Gamma_1} \in H^{\frac{1}{2}}(\Gamma_1), \end{cases}$$
 (6.1.13)

we introduce the following bilinear form on  $H^1_{\Gamma_0}$ ,

$$a(w,u) = \int_{\Omega} (A(x)\nabla w \cdot \nabla u + q(x)wu)dx, \tag{6.1.14}$$

which is clearly coercive and bounded. Then, problems (6.1.12) and (6.1.13) can be converted into the following weak formulation:

to find  $w \in H^1_{\Gamma_0}$  such that

$$a(w,u) + \int_{\Gamma_1} b(x) f u d\sigma = -\int_{\Omega} \rho(x) g u dx, \quad \forall u \in H^1_{\Gamma_0}.$$
 (6.1.15)

By the well known Lax-Milgram theorem, there is a unique weak solution  $w \in H^1_{\Gamma_0}$ . By the standard regularity result on the elliptic boundary value problems (see Chapter 1), we can conclude that  $w \in \mathcal{D}(\mathcal{A})$ . Moreover, it easily follows from v = f and (6.1.15) that  $\|(w,v)^T\|_{\mathcal{H}} \leq K\|(f,g)^T\|_{\mathcal{H}}$  with K being a positive constant. Thus,  $0 \in \rho(\mathcal{A})$ , and the proof is complete.  $\square$ .

Now we have the following main result in this section.

**Theorem 6.1.2** Suppose that there is a vector field  $\mathbf{l}(x) = (l_1(x), \dots, l_m(x))$  of class  $C^1(\overline{\Omega})$  satisfying (i),(ii),(iii)". Then the  $C_0$ -semigroup S(t) on  $\mathcal{H}$  generated by  $\mathcal{A}$  is exponentially stable, i.e., there exist positive constants  $M, \alpha$  such that

$$||S(t)|| \le Me^{-\alpha t}, \quad t \ge 0.$$
 (6.1.16)

**Remark 6.1.1** Inequality (6.1.5) immediately follows from (6.1.16) and  $z(t) = S(t)z_0$ .

Remark 6.1.2 In Wyler [1], the author remarked that the assumption (ii) is equivalent to

(ii) 
$$\cdot \boldsymbol{l} \cdot \boldsymbol{\nu} \geq 0$$
 on  $\Gamma_1$ .

**Proof of Theroem 6.1.2** It suffices to verify conditions (1.3.3) and (1.3.4) in Theorem 1.3.2. The whole proof consists of the following steps:

(i) If (1.3.3) is false, then there is  $i\beta$  with  $\beta \neq 0$  such that  $i\beta \in \sigma(\mathcal{A})$ . It is easy to see from the proof of the previous theorem that  $\mathcal{A}^{-1}$  is compact from  $\mathcal{H}$  to  $\mathcal{H}$ . Therefore,  $i\beta$  must be an eigenvalue. It turns out that there is a  $z = (w, v)^T \in \mathcal{D}(\mathcal{A}), z \neq 0$  such that

$$Az = i\beta z, \tag{6.1.17}$$

i.e.,

$$v = i\beta w, \tag{6.1.18}$$

$$\nabla \cdot (A(x)\nabla w) - q(x)w = i\beta\rho v. \tag{6.1.19}$$

Therefore,  $w \in H^2$  with  $w \neq 0$  satisfies

$$\begin{cases} \nabla \cdot (A(x)\nabla w) - q(x)w = -\beta^2 \rho w & \text{in } \Omega, \\ w = 0 & \text{on } \Gamma_0, \\ \sum_{i,j=1}^m a_{ij} \frac{\partial w}{\partial x_j} \nu_i + i\beta b(x)w = 0 & \text{on } \Gamma_1. \end{cases}$$

$$(6.1.20)$$

By integration by parts, we have

$$0 = Re\langle -\beta^2 \rho w - \nabla \cdot (A(x)\nabla w) + qw, i\beta w \rangle_{L^2(\Omega)}$$
$$= \int_{\Gamma_1} b(x)\beta^2 |w|^2 d\sigma. \tag{6.1.21}$$

It turns out that w=0 on  $\Gamma_1$ . We can deduce from the boundary condition on  $\Gamma_1$  in (6.1.20) that  $\sum_{i,j=1}^m a_{ij} \frac{\partial w}{\partial x_j} \nu_i = 0$  on  $\Gamma_1$ . By Lemma 2.5 in Wyler [1], which is an easy consequence of a 'Unique Continuation Theorem' of L. Hörmander for the elliptic operator, we have  $w\equiv 0$ , hence by (6.1.18),  $v\equiv 0$  in  $\Omega$ , a contradiction. Thus, (1.3.3) is proved.

(ii) Suppose that (1.3.4) is false. There then exists a sequence  $\beta_n$ ,  $\beta_n \to \infty$ , and a sequence of complex vectors  $z_n = (w_n, v_n)^T \in \mathcal{D}(\mathcal{A})$  with unit norm in  $\mathcal{H}$  such that as  $n \to \infty$ ,

$$\|(\mathbf{i}\beta_n I - \mathcal{A})z_n\|_{\mathcal{H}} \to 0, \tag{6.1.22}$$

$$i\beta_n w_n - v_n = f_n \to 0 \quad \text{in } H^1_{\Gamma_0}(\Omega),$$
 (6.1.23)

$$i\beta_n v_n - \frac{1}{\rho(x)} [\nabla \cdot (A(x)\nabla w) - q(x)w] = g_n \to 0 \quad \text{in } L^2_\rho(\Omega). \tag{6.1.24}$$

Since

$$\|(i\beta_n I - \mathcal{A})z_n\|_{\mathcal{H}} \ge |Re\langle(i\beta_n I - \mathcal{A})z_n, z_n\rangle_{\mathcal{H}}| = |Re\langle\mathcal{A}z_n, z_n\rangle_{\mathcal{H}}|, \tag{6.1.25}$$

by (6.1.22) and (6.1.10), we obtain

$$\int_{\Gamma_n} b(x)|v_n|^2 d\sigma \to 0, \tag{6.1.26}$$

i.e.,

$$||v_n||_{L^2(\Gamma_1)} \to 0.$$
 (6.1.27)

Then it follows from (6.1.23) and the trace theorem that

$$\|\beta_n w_n\|_{L^2(\Gamma_1)} \to 0.$$
 (6.1.28)

Next, we solve  $v_n$  from equation (6.1.23) and substitute it into (6.1.24) to get

$$-\beta_n^2 w_n - \frac{1}{\rho(x)} [\nabla \cdot (A(x)\nabla w_n) - q(x)w_n] = g_n + i\beta_n f_n \to 0 \quad \text{in } L^2_{\rho}(\Omega). \tag{6.1.29}$$

Taking the inner product of (6.1.29) with  $w_n$  in  $L^2_{\rho}(\Omega)$  and integrating by parts yields

$$-\int_{\Omega} \rho(x) |\beta_n w_n|^2 dx + \int_{\Omega} [(A(x)\nabla w_n) \cdot \nabla \overline{w}_n + q(x)|w_n|^2] dx$$
$$-\int_{\Gamma_1} \boldsymbol{\nu} \cdot (A(x)\nabla w_n) \overline{w}_n d\sigma = \langle g_n + \boldsymbol{i}\beta_n f_n, w_n \rangle_{L_{\rho}^2}. \tag{6.1.30}$$

It can be seen from (6.1.23) that  $\beta_n w_n$  is bounded in  $L^2_{\rho}(\Omega)$ , which also implies that  $w_n$  converges to zero in  $L^2$  because  $\beta_n \to \infty$ . This together with the fact that  $g_n, f_n$  converge to zero in  $L^2_{\rho}(\Omega)$  implies that the inner product on the right-hand side of (6.1.30) also converge to zero. Since  $||w_n||_{H^1} \leq 1$ , by the trace theorem and the Cauchy-Schwartz inequality, we have

$$\left| \int_{\Gamma_{1}} \boldsymbol{\nu} \cdot (A(x) \nabla w_{n}) \overline{w}_{n} d\sigma \right| = \left| \int_{\Gamma_{1}} b(x) v_{n} \overline{w}_{n} d\sigma \right|$$

$$\leq K \|w_{n}\|_{H_{\Gamma_{0}}^{1}} \left( \int_{\Gamma_{1}} b(x) |v_{n}|^{2} d\sigma \right)^{\frac{1}{2}} \to 0. \quad (6.1.31)$$

Therefore, it follows from (6.1.30) that

$$-\int_{\Omega} \rho(x) |\beta_n w_n|^2 dx + \int_{\Omega} [(A(x)\nabla w_n) \cdot \nabla \overline{w}_n + q(x)|w_n|^2] dx \to 0.$$
 (6.1.32)

Combining this with (6.1.23) yields

$$\int_{\Omega} [(A(x)\nabla w_n) \cdot \nabla \overline{w}_n + q(x)|w_n|^2] dx - ||v_n||_{L_{\rho}^2}^2 \to 0.$$
 (6.1.33)

Recall that  $\|(w_n, v_n)^T\|_{\mathcal{H}} = 1$ . We then obtain that

$$\int_{\Omega} [(A(x)\nabla w_n) \cdot \nabla \overline{w}_n + q(x)|w_n|^2] dx \to \frac{1}{2}, \quad \|v_n\|_{L^2_{\rho}}^2 \to \frac{1}{2}.$$
 (6.1.34)

In what follows, we will show that (6.1.34) is a contradiction. In doing so, we first take the inner product of (6.1.29) with  $l(x) \cdot \nabla w_n$  in  $L^2_{\rho}(\Omega)$  to get

$$\langle -\beta_n^2 w_n - \frac{1}{\rho(x)} [\nabla \cdot (A(x)\nabla w_n) - q(x)w_n], \boldsymbol{l}(x) \cdot \nabla w_n \rangle_{L_\rho^2} = \langle g_n + i\beta_n f_n, \boldsymbol{l}(x) \cdot \nabla w_n \rangle_{L_\rho^2}.$$
(6.1.35)

By integration by parts, (6.1.28) and the trace theorem, we have

$$\begin{aligned} & \left| \langle \beta_{n} f_{n}, \boldsymbol{l} \cdot \nabla w_{n} \rangle_{L_{\rho}^{2}} \right| \\ &= \left| \int_{\Gamma_{1}} \rho(x) (\boldsymbol{l} \cdot \boldsymbol{\nu}) f_{n} (\beta_{n} \overline{w}_{n}) d\sigma - \int_{\Omega} \beta_{n} \overline{w}_{n} (\rho(x) l_{j,j} f_{n} + \rho(x) l_{j} f_{n,j} + \nabla \rho \cdot \boldsymbol{l} f_{n}) dx \right| \\ &\leq K \|f_{n}\|_{H_{\Gamma_{0}}^{1}} \left( \|\beta_{n} w_{n}\|_{L^{2}(\Gamma_{1})} + \|\beta_{n} w_{n}\|_{L^{2}(\Omega)} \right) \to 0. \end{aligned}$$

$$(6.1.36)$$

By the Cauchy-Schwartz inequality, we have

$$\left| \langle g_n, l \cdot \nabla w_n \rangle_{L^2_{\rho}} \right| \le K \|g_n\|_{L^2_{\rho}} \|w_n\|_{H^1} \to 0.$$
 (6.1.37)

Therefore, the inner product on the right-hand side of (6.1.35) converges to zero. In what follows, we investigate three terms on the left hand side of (6.1.35). By integration by parts, we get

$$Re\langle -\beta_n^2 w_n, \boldsymbol{l} \cdot \nabla w_n \rangle_{L_{\rho}^2}$$

$$= -\frac{1}{2} \int_{\Gamma_1} \rho(x) (\boldsymbol{l} \cdot \boldsymbol{\nu}) |\beta_n w_n|^2 d\sigma + \frac{1}{2} \int_{\Omega} (l_{j,j} \rho(x) + \nabla \rho \cdot \boldsymbol{l}) |\beta_n w_n|^2 dx. \quad (6.1.38)$$

By (6.1.28), the boundary integral on the right hand side of (6.1.38) converges to zero. Since  $\|\nabla w_n\|$  is uniformly bounded and  $w_n \to 0$  in  $L^2$ , for the last term on the left hand side of (6.1.35), by the Cauchy-Schwartz inequality we have

$$Re \left\langle \frac{1}{\rho(x)} q(x) w_n, \mathbf{l} \cdot \nabla w_n \right\rangle_{L^2_{\rho}} \to 0.$$
 (6.1.39)

For the second term on the left hand side of (6.1.35), by integration by parts, we obtain that

$$Re \left\langle -\frac{1}{\rho(x)} \nabla \cdot (A(x) \nabla w_n), (\boldsymbol{l} \cdot \nabla w_n) \right\rangle_{L_{\rho}^2}$$

$$= -Re \int_{\Gamma} \boldsymbol{\nu} \cdot (A(x) \nabla w_n) (\boldsymbol{l} \cdot \nabla \overline{w}_n) d\sigma + \frac{1}{2} \int_{\Omega} w_{n,i} (a_{ik} l_{j,k} + a_{jk} l_{i,k} - \nabla a_{ij} \cdot \boldsymbol{l}) \overline{w}_{n,j} dx$$

$$+ \frac{1}{2} \int_{\Gamma} (\boldsymbol{l} \cdot \boldsymbol{\nu}) (A(x) \nabla w_n) \cdot \nabla \overline{w}_n d\sigma - \frac{1}{2} \int_{\Omega} l_{j,j} (A(x) \nabla w_n) \cdot \nabla \overline{w}_n dx. \tag{6.1.40}$$

We then substitute (6.1.36)-(6.1.40) into (6.1.35) to get

$$\frac{1}{2} \int_{\Omega} w_{n,i} (a_{ik} l_{j,k} + a_{jk} l_{i,k} - \nabla a_{ij} \cdot \boldsymbol{l}) \overline{w}_{n,j} dx 
+ \frac{1}{2} \int_{\Omega} l_{j,j} [\rho(x) |\beta_n w_n|^2 - (A(x) \nabla w_n) \cdot \nabla \overline{w}_n] dx 
+ \frac{1}{2} \int_{\Omega} (\nabla \rho \cdot \boldsymbol{l}) |\beta_n w_n|^2 dx - Re \int_{\Gamma} \boldsymbol{\nu} \cdot (A(x) \nabla w_n) (\boldsymbol{l} \cdot \nabla \overline{w}_n) d\sigma 
+ \frac{1}{2} \int_{\Gamma} (\boldsymbol{l} \cdot \boldsymbol{\nu}) (A(x) \nabla w_n) \cdot \nabla \overline{w}_n d\sigma \to 0.$$
(6.1.41)

Since  $w_n = 0$  on  $\Gamma_0$ , the real and imaginary parts of  $\nabla w_n$  are in the same direction of  $\nu$ . By the definition of vector inner product, we have the following equality:

$$Re\left(\boldsymbol{\nu}\cdot\boldsymbol{A}(x)\nabla\boldsymbol{w}_{n}\right)\left(\boldsymbol{l}\cdot\nabla\overline{\boldsymbol{w}}_{n}\right) = (\boldsymbol{l}\cdot\boldsymbol{\nu})(\boldsymbol{A}(x)\nabla\boldsymbol{w}_{n})\cdot\nabla\overline{\boldsymbol{w}}_{n}.\tag{6.1.42}$$

Thus, the boundary integrals in (6.1.41) can be rewritten as follows:

$$I = -\frac{1}{2} \int_{\Gamma_0} (\boldsymbol{l} \cdot \boldsymbol{\nu}) (A(x) \nabla w_n) \cdot \nabla \overline{w}_n d\sigma + \frac{1}{2} \int_{\Gamma_1} (\boldsymbol{l} \cdot \boldsymbol{\nu}) (A(x) \nabla w_n) \cdot \nabla \overline{w}_n d\sigma + Re \int_{\Gamma_1} b(x) v_n (\boldsymbol{l} \cdot \nabla \overline{w}_n) d\sigma.$$

$$(6.1.43)$$

By condition (ii), the third term in (6.1.43) can be bounded as follows:

$$|Re \int_{\Gamma_1} b(x) v_n (\boldsymbol{l} \cdot \nabla \overline{w}_n) d\sigma| \leq \frac{1}{4} \int_{\Gamma_1} (\boldsymbol{l} \cdot \boldsymbol{\nu}) (A(x) \nabla w_n) \cdot \nabla \overline{w}_n d\sigma + K \|v_n\|_{L^2(\Gamma_1)}^2 \quad (6.1.44)$$

with K being a positive constant. Thus, it follows from (6.1.26) and (6.1.44) that

$$I \geq -\frac{1}{2} \int_{\Gamma_0} (\boldsymbol{l} \cdot \boldsymbol{\nu}) (A(x) \nabla w_n) \cdot \nabla \overline{w}_n d\sigma + \frac{1}{4} \int_{\Gamma_1} (\boldsymbol{l} \cdot \boldsymbol{\nu}) (A(x) \nabla w_n) \cdot \nabla \overline{w}_n d\sigma + o(1) \quad (6.1.45)$$

with  $o(1) \to 0$ , as  $n \to \infty$ . Now it is easy to see that by conditions (i) and (ii), two terms of boundary integrals in (6.1.45) are positive, definite quadratic forms.

On the other hand, if we take the inner product of (6.1.29) with  $(l_j\rho)_{,j}w_n$  in  $L^2(\Omega)$ , then by the same argument as before, we have

$$\int_{\Omega} [(\rho(x)l_{j,j} + \nabla \rho \cdot \boldsymbol{l})|\beta_n w_n|^2 - (l_{j,j} + \frac{\nabla \rho \cdot \boldsymbol{l}}{\rho}) A(x) \nabla w_n \cdot \nabla \overline{w}_n] dx \to 0.$$
 (6.1.46)

Thus, the terms on the left hand side of (6.1.41) can be rewritten as the sum of I and II with

$$II = \frac{1}{2} \int_{\Omega} w_{n,i} \left[ a_{ik} l_{j,k} + a_{jk} l_{i,k} + \frac{\nabla \rho \cdot \boldsymbol{l}}{\rho} a_{ij} - \nabla a_{ij} \cdot \boldsymbol{l} \right] \overline{w}_{n,j} dx$$
 (6.1.47)

which is also a positive definite quadratic form by condition (iii)". Now it follows from (6.1.41) and (6.1.45) that  $w_n$  must converge to zero in  $H^1(\Omega)$ . This contradicts (6.1.34). Thus, the proof is complete.

#### 6.2 Euler-Bernoulli Beam Equation

In this section, we consider the following initial boundary value problem for the Euler-Bernoulli equation of a non-homogeneous beam with certain boundary damping:

$$\begin{cases}
\rho(x)w_{tt} + (p(x)w'')'' = 0, & (x,t) \in (0,1) \times (0,\infty), \\
w(0,t) = w'(0,t) = 0, & t > 0, \\
-p(1)w''(1,t) = m(t), & -(pw'')'(1,t) = h(t), & t > 0, \\
w(x,0) = w_0(x), & w_t(x,0) = v_0(x)
\end{cases}$$
(6.2.1)

where w is the vertical displacement of the beam and the prime represents the derivative with respect to the spacial variable x. In (6.2.1), we have normalized the length of the beam to one by scaling of the variable x and we have taken  $\rho(x) = \hat{\rho}(Lx)$ ,  $p(x) = L^{-4}EI(Lx)$  with L,  $\hat{\rho}(x) > 0$ , EI(x) > 0 being the length, density, and 138

Young's modulus of the beam. The mechanical meaning of boundary conditions at one end of beam x = 1 in (6.2.1) is that the bending moment and shear force applied to that end is the given function m(t) and h(t), respectively. In this section, we will consider the case that functions m(t), h(t) are given in the feedback form. More precisely, let

 $\begin{pmatrix} m(t) \\ h(t) \end{pmatrix} = diag(1, -1)F\begin{pmatrix} w'_t(1, t) \\ w_t(1, t) \end{pmatrix}$  (6.2.2)

where F is a given  $2 \times 2$  matrix of complex numbers and it will be specified later. In the control theory, this means that one measures  $w_t, w_t'$  at x = 1, then feeds them back to the bending moment and shear force at x = 1 as a control. If the resulting system (a close-loop system) is exponentially stable, then we say that the original system is exponentially stabilizable. Throughout this section, we always assume that  $\rho(x) \in C^1[0,1], p(x) \in H^2[0,1]$  and  $\rho(x), p(x) > 0$ . We are now interested in the exponential stabilization problem: find conditions on F such that the semigroup associated with system (6.2.1) is exponentially stable. The work in this section essentially follows the paper Liu & Liu [5].

The energy of the beam at time t is defined by

$$E(t) = \frac{1}{2} \int_0^1 \left[ p(x) |w''(x,t)|^2 + \rho(x) |w_t(x,t)|^2 \right] dx. \tag{6.2.3}$$

We will see later that the exponential stability of the associated  $C_0$ -semigroup is equivalent to the exponential decay of the energy, i.e.,

$$E(t) \le Me^{-\alpha t}E(0), \qquad t \ge 0 \tag{6.2.4}$$

for some constants  $\alpha > 0, M \ge 1$ . In this section we will consider the following three cases of feedback scheme:

- (i)  $F \ge k_0 I$ ,  $k_0 > 0$  (i.e., both bending moment and shear force are given simultaneously in a feedback form);
- (ii)  $F = \text{diag } (0, k_2), \ k_2 > 0$  (i.e., shear force is given in a feedback form and bending moment is free);

(iii)  $F = \text{diag } (k_1, 0), k_1 > 0$  (bending moment is given in a feedback form and shear force is free).

In what follows, we reduce (6.2.1) and (6.2.2) to an abstract first-order evolution equation in a Hilbert space.

Let

$$V = \{ w \in H^2(0,1) | w(0) = w'(0) = 0 \}, \quad ||w||_V = \left( \int_0^1 p(x) |w''|^2 dx \right)^{\frac{1}{2}}$$
 (6.2.5)

and

$$H = L_{\rho}^{2}(0,1), \qquad ||v||_{H} = \left(\int_{0}^{1} \rho(x)|v|^{2} dx\right)^{\frac{1}{2}}.$$
 (6.2.6)

Then both V and H are Hilbert spaces and so is  $\mathcal{H} = V \times H$  equipped with the norm

$$\|(w,v)^T\|_{\mathcal{H}} = \left[\int_0^1 \left(p(x)|w''|^2 + \rho(x)|v|^2\right) dx\right]^{\frac{1}{2}}.$$
 (6.2.7)

If we introduce  $v = w_t$  and define in  $\mathcal{H}$ 

$$\mathcal{D}(\mathcal{A}) = \left\{ z = (w, v)^T \middle| \begin{array}{c} w, v \in V, \ p(x)w'' \in H^2(0, 1), \\ (-p(1)w''(1), (pw'')'(1))^T = F(v'(1), v(1))^T \end{array} \right\}, \quad (6.2.8)$$

and

$$\mathcal{A}z = \begin{pmatrix} v \\ -\frac{1}{\rho(x)}(p(x)w'')'')^T \end{pmatrix}, \tag{6.2.9}$$

then the closed-loop system (6.2.1) and (6.2.2) can be reduced to the initial value problem for an abstract first-order evolution equation in  $\mathcal{H}$ :

$$\begin{cases} \frac{dz}{dt} = Az, & \forall t > 0\\ z(0) = z_0 = (w_0, v_0)^T. \end{cases}$$
(6.2.10)

We first prove the following

**Theorem 6.2.1** Suppose that F is symmetric and non-negative definite, i.e.,  $(F\eta, \eta) \ge 0$  for any  $\eta \in \mathbb{R}^2$ . Then A generates a  $C_0$ -semigroup  $S(t) = e^{At}$  of contractions on  $\mathcal{H}$ . Moreover,  $A^{-1} \in \mathcal{L}(\mathcal{H})$  is a compact operator.

**Proof** For any  $(w,v)^T \in \mathcal{D}(A)$ , by integration by parts we have

$$\langle \mathcal{A}(w,v)^{T}, (w,v)^{T} \rangle_{\mathcal{H}} = \int_{0}^{1} (pv''w'' - (pw'')''v) dx$$

$$= -(pw'')'v|_{x=1} + pw''v'|_{x=1}$$

$$= -(v'|_{x=1}, v|_{x=1})^{T} \cdot F(v'|_{x=1}, v|_{x=1})^{T} \leq 0 \quad (6.2.11)$$

where the dot "." denotes the inner product in  $\mathbb{R}^2$ . Thus,  $\mathcal{A}$  is dissipative.

In order to apply Theorem 1.2.4 in Chapter 1, it suffices to verify that  $0 \in \rho(\mathcal{A})$ . For any  $(f,g)^T \in \mathcal{H}$ , consider the equation

$$\mathcal{A}(w,v)^T = (f,g)^T, \qquad (w,v)^T \in \mathcal{D}(\mathcal{A}). \tag{6.2.12}$$

By the definition of A, we can easily deduce from (6.2.12) that

$$\begin{cases} v = f, \\ w(x) = \int_0^x \frac{x-s}{p(s)} (-1, s-1)^T \cdot F(f'(1), f(1))^T ds \\ -\int_0^x \frac{x-y}{p(y)} \int_1^y \int_1^s \rho(\tau) g(\tau) d\tau ds dy. \end{cases}$$
(6.2.13)

It is easy to see that there exists a constant M>0 independent of  $(f,g)^T$  such that

$$\|(w,v)^T\|_{\mathcal{H}} \le M\|(f,g)^T\|_{\mathcal{H}}.$$
 (6.2.14)

Therefore,  $\mathcal{A}^{-1} \in \mathcal{L}(\mathcal{H})$ ,  $0 \in \rho(\mathcal{A})$ . By Theorem 1.2.4,  $\mathcal{A}$  generates a  $C_0$ -semigroup S(t) of contractions on  $\mathcal{H}$ . Moreover, it easily follows from (6.2.13) that  $||v||_{H^2} \leq K||(f,g)^T||_{\mathcal{H}}$  and  $||w||_{H^4} \leq K||(f,g)^T||_{\mathcal{H}}$  with K being a positive constant. By the compactness of imbedding operators  $H^2(0,1) \hookrightarrow L^2(0,1)$  and  $H^4(0,1) \hookrightarrow H^2(0,1)$ , we can conclude that  $\mathcal{A}^{-1}$  is also a compact operator.

It is clear from the definition of  $\mathcal{H}$  that the exponential decay property (6.2.4) holds if and only if S(t) is exponentially stable. Now we are in position to state and prove our main result in this section.

**Theorem 6.2.2** Suppose that  $F, \rho(x)$  and p(x) satisfy one of the following conditions:

(i)  $F \ge k_0 I$ ,  $k_0 > 0$ , p'' is piecewisely continuous on [0,1]

(ii) 
$$F = diag(0, k_2), k_2 > 0, \rho + x\rho' \ge 0 \text{ and } 3p - xp' > 0 \text{ on } [0, 1]$$

(iii)  $F = diag(k_1, 0), k_1 > 0$  and there is a constant  $c \ge 0$  such that

$$\rho'\left(c + \int_0^x \frac{ds}{p(s)}\right) < \frac{\rho}{p}, \quad -p'\left(c + \int_0^x \frac{ds}{p(s)}\right) < 3 \quad on \ [0,1]. \tag{6.2.15}$$

Then the  $C_0$ -semigroup S(t), generated by A, is exponentially stable.

Before giving the proof of this theorem, we first recall the related works in the literature. When  $\rho$  and p are constants, the energy decay property (6.2.4) was established for cases (i) and (ii) in Chen, Delfour, Krall & Payre [1] by means of energy method. We also refer to Lagnese [3] and Chen, Coleman & Liu [1] for the plate and shell counterparts of cases (i) and (ii). The decay property (6.2.4) for case (iii) with constant  $\rho$ , p was established by Chen, Krantz, Ma & Wayne [1] by means of the frequency domain method. The proof in that paper uses the representation of solution to a fourth-order ordinary differential equation. The feedback scheme (iii) is simple and attractive. To our knowledge, so far there has been no result on the boundary stabilization of the plate equation by using the feedback scheme like case (iii). For the problem considered in this section with variable coefficients, auxiliary functions or so-called frequency domain multiplier techniques were used in Liu & Liu [5]. We would like to point out that if  $\rho$  and p are constants, then the conditions in Theorem 6.2.2 are clearly satisfied.

#### Proof of Theorem 6.2.2

We divide the proof into several steps which consist of the following five lemmas.

**Lemma 6.2.1** Suppose F satisfies one of the previous three conditions and suppose that  $i\mathbb{R} \subset \rho(A)$ . Then S(t) is exponentially stable.

**Proof** We use a contradiction argument to prove this lemma. By Theorem 1.3.2, the exponential stability is equivalent to (1.3.3) and (1.3.4). Therefore, if the conclusion is not true, then there exists a sequence of real numbers  $\beta_n \to \infty$  and a sequence of complex-valued vectors  $z_n = (w_n, v_n)^T \in \mathcal{D}(\mathcal{A})$  with  $||z_n||_{\mathcal{H}} = 1$  such that

$$\|(i\beta_n I - A)z_n\|_{\mathcal{H}} \to 0, \quad as \quad n \to \infty,$$
 (6.2.16)

i.e.,

$$i\beta_n w_n - v_n \equiv f_n \to 0 \quad in \quad V, \tag{6.2.17}$$

$$i\beta_n v_n + \frac{1}{\rho(x)} (p(x)w_n'')'' \equiv g_n \to 0 \quad in \ H.$$
 (6.2.18)

In view of (6.2.11) and (6.2.8), we have

$$d_n \equiv -(v'_n(1), v_n(1))^T \cdot F(v'_n(1), v_n(1))^T = \text{Re} \langle Az_n, z_n \rangle_{\mathcal{H}} \to 0.$$
 (6.2.19)

It follows from (6.2.17) and (6.2.18) that

$$i\beta_n ||w_n||_V^2 - \langle v_n, w_n \rangle_V \to 0, \tag{6.2.20}$$

$$i\beta_n ||v_n||_H^2 + \langle w_n, v_n \rangle_V \to 0, \tag{6.2.21}$$

which further imply

$$||w_n||_V^2 - ||v_n||_H^2 \to 0. (6.2.22)$$

Therefore, by  $||z_n||_{\mathcal{H}} = 1$  and (6.2.17), we obtain that

$$\lim_{n \to \infty} \|w_n\|_V^2 = \lim_{n \to \infty} \|v_n\|_H^2 = \lim_{n \to \infty} \|\beta_n w_n\|_H^2 = \frac{1}{2}.$$
 (6.2.23)

Now we claim that

$$w_n \in C^3[0,1], \quad \lim_{n \to \infty} \beta_n w_n(1) = \lim_{n \to \infty} w_n''(1) = \lim_{n \to \infty} (pw_n'')'(1) = 0.$$
 (6.2.24)

This is a key step in our proof. We postpone the proof of this claim to the end of the proof of this lemma. Now we solve  $v_n$  from equation (6.2.17) and substitute it into (6.2.18) to get

$$-\beta_n^2 w_n + \frac{1}{\rho(x)} [p(x)w_n'']'' = g_n + i\beta_n f_n.$$
 (6.2.25)

Let q(x) be a function in  $C^2([0,1])$  with q(0) = 0. Taking the inner product of (6.2.25) with  $qw'_n$  in H yields that

$$\langle -\beta_n^2 w_n + \frac{1}{a(x)} [p(x)w_n'']'', \ qw_n'\rangle_H = \langle g_n + i\beta_n f_n, qw_n'\rangle_H.$$
 (6.2.26)

We now prove that the inner product on the right-hand side of (6.2.26) converges to zero.

Dividing (6.2.17) by  $\beta_n$ , we get  $||w_n||_H \to 0$ . It is easy to see by the Poincaré inequality that the norm in V is equivalent to the norm in  $H^2$ . Thus, by the Gagliardo-Nirenberg inequality we have

$$||w_n'||_H \le C||w_n||_V^{\frac{1}{2}}||w_n||_H^{\frac{1}{2}}. (6.2.27)$$

Combining it with (6.2.23) yields that  $||w'_n||_H$  also converges to zero. Therefore,

$$|\langle g_n, qw_n' \rangle_H| \le C ||g_n||_H ||w_n||_V \to 0.$$
 (6.2.28)

By the claim (6.2.24) and integration by parts, we also obtain that

$$\begin{aligned} & |\langle \beta_n f_n, q w'_n \rangle_H | \\ & \leq C(\|f_n\|_V \| \|\beta_n w_n\|_H + |f_n(1)\beta_n w_n(1)|) \\ & \leq C\|f_n\|_V (\|\beta_n w_n\|_H + |\beta_n w_n(1)|) \to 0. \end{aligned}$$
(6.2.29)

Concerning the inner product on the left-hand side of (6.2.26), by integartion by parts we have

$$\operatorname{Re}(-\beta_n^2 w_n, q w_n')_H = -\frac{1}{2} \rho(1) q(1) |\beta_n w_n(1)|^2 + \frac{1}{2} \int_0^1 (\rho q)' |\beta_n w_n|^2 dx$$
 (6.2.30)

and

$$\operatorname{Re}\langle \frac{1}{\rho(x)}[p(x)w_{n}'']'', qw_{n}'\rangle_{H}$$

$$= \operatorname{Re}([q(pw_{n}'')' - pq'w_{n}''](1)\bar{w}_{n}'(1)) - \frac{1}{2}p(1)q(1)|w_{n}''(1)|^{2}$$

$$+ \int_{0}^{1} [\frac{1}{2}(3pq' - p'q)|w_{n}''|^{2} + \operatorname{Re}(pq''w_{n}''\bar{w}_{n}')]dx. \tag{6.2.31}$$

All the boundary terms in (6.2.30) and (6.2.31) converge to zero due to (6.2.24) and the boundedness of  $w_n$  in V. Since  $||w'_n||_H \to 0$ , it follows that

$$\int_0^1 p q'' w_n'' \bar{w}_n' dx \to 0. \tag{6.2.32}$$

We then substitute (6.2.30) and (6.2.31) into (6.2.26) to get

$$\frac{1}{2} \int_0^1 (\rho q' + \rho' q) |\beta_n w_n|^2 dx + \frac{1}{2} \int_0^1 [3pq' - p'q] |w_n''|^2 dx \to 0.$$
 (6.2.33)

One can always choose the function q(x) such that

$$\rho q' + \rho' q > 0$$
,  $3pq' - p'q > 0$  on  $[0,1]$ . (6.2.34)

For example, we can choose  $q(x) = e^{ax} - 1$  with a satisfying

$$\max\{\frac{\rho_1}{\rho_0}\,,\,\,\frac{p_1}{3p_0}\} < a < \infty \tag{6.2.35}$$

where

$$\rho_0 = \min_{x \in [0,1]} \rho(x), \quad p_0 = \min_{x \in [0,1]} p(x), \tag{6.2.36}$$

and

$$\rho_1 = \max_{x \in [0,1]} |\rho'(x)|, \quad p_1 = \max_{x \in [0,1]} |p'(x)|. \tag{6.2.37}$$

Therefore, it follows from (6.2.33) that

$$||w_n||_V \to 0, \tag{6.2.38}$$

which contradicts (6.2.23).

We now finish the proof of Lemma 6.2.1 by proving (6.2.24). The conclusion  $w_n \in C^3[0,1]$  follows from  $pw_n'' \in H^2(0,1) \subset C^1[0,1]$  and 0 . We now give the proof of (6.2.24) one by one for the three cases.

Case (i)  $(F \ge k_0 I, k_0 > 0)$ .

By (6.2.19) we have

$$\lim_{n \to \infty} v_n(1) = \lim_{n \to \infty} v'_n(1) = 0. \tag{6.2.39}$$

Hence,

$$\|([pw_n''](1), [pw_n'']'(1))^T\| \le \|\operatorname{diag}(-1, 1)F\| \|(v_n'(1), v_n(1))^T\| \to 0.$$
 (6.2.40)

In view of (6.2.17) and the Sobolev imbedding theorem, we also obtain that  $\lim_{n\to\infty} \beta_n w_n(1) = 0$ . Thus, (6.2.24) follows.

Case (ii)  $(F = diag(0, k_2), k_2 > 0)$ .

We now have

$$p(1)w_n''(1) = 0,$$
  $[pw_n'']'(1) = k_2 v_n(1).$  (6.2.41)

Moreover, (6.2.17) and (6.2.19) yield that  $\lim_{n\to\infty} \beta_n w_n(1) = \lim_{n\to\infty} v_n(1) = 0$ . Thus, (6.2.24) also follows.

Case (iii)  $(F = diag(k_1, 0), k_1 > 0)$ .

In this case, we have

$$p(1)w_n''(1) = -k_1v_n'(1),$$
  $[pw_n'']'(1) = 0.$  (6.2.42)

Thus, from (6.2.17), (6.2.19), and the Sobolev imbedding theorem we obtain that

$$\lim_{n \to \infty} w_n'''(1) = \lim_{n \to \infty} w_n''(1) = \lim_{n \to \infty} \beta_n w_n'(1) = \lim_{n \to \infty} v_n'(1) = 0.$$
 (6.2.43)

Now it remains to prove that  $\lim_{n\to\infty}\beta_n w_n(1)=0$ . To do so, we introduce another multiplier.

Let  $\xi(x) \in C^2([0,1])$  satisfy

$$\xi(0) > 0, \quad \xi(1) = 0, \quad \xi'(x) \le \xi_1 < 0.$$
 (6.2.44)

The precise form of this function will be given later. Denote  $\phi_n = \sqrt{|\beta_n|}$ . We then take the inner product of (6.2.25) with  $\frac{\rho}{\phi_n}e^{-\phi_n\xi}$  in  $L^2(0,1)$  to get

$$\langle -\phi_n^3 w_n , \rho e^{-\phi_n \xi} \rangle_{L^2} + \langle (p w_n'')'' , \frac{1}{\phi_n} e^{-\phi_n \xi} \rangle_{L^2} = \langle g_n + i \beta_n f_n , \frac{\rho}{\phi_n} e^{-\phi_n \xi} \rangle_{L^2}.$$
 (6.2.45)

The right-hand side of (6.2.45) converges to zero because

$$|\langle g_n, \frac{\rho}{\phi_n} e^{-\phi_n \xi} \rangle_{L^2}| \le C \|g_n\|_H \to 0, \tag{6.2.46}$$

and

$$\begin{aligned} & |\langle \phi_n f_n \;,\; \rho e^{-\phi_n \xi} \rangle_{L^2}| = |\int_0^1 \frac{\rho}{\xi'} f_n de^{-\phi_n \xi(x)}| \\ & = \left| \frac{\rho(1)}{\xi'(1)} f_n(1) - \int_0^1 \left( \frac{\rho}{\xi'} f_n \right)' e^{-\phi_n \xi} dx \right| \le C ||f_n||_V \to 0. \end{aligned}$$
(6.2.47)

For the second term on the left-hand side of (6.2.45), we have

$$\langle (pw_n'')'', \frac{1}{\phi_n} e^{-\phi_n \xi} \rangle_{L^2} = \left[ (pw_n'')' \frac{1}{\phi_n} e^{-\phi_n \xi} + pw_n'' \xi'(x) e^{-\phi_n \xi} \right]_0^1 + \langle pw_n'', \phi_n(\xi')^2 e^{-\phi_n \xi} - \xi'' e^{-\phi_n \xi} \rangle_{L^2}.$$
 (6.2.48)

Dividing (6.2.25) by  $\beta_n^2$  and using the fact that  $w_n \to 0$  in  $H^1$ , we get that

$$\phi_n^{-4}[pw_n'']'' \to 0 \text{ in } L^2.$$
 (6.2.49)

Thus, integrating (6.2.49) over [0,1] and using (6.2.43), we obtain that

$$\lim_{n \to \infty} \phi_n^{-4} (pw_n'')'(0) = \lim_{n \to \infty} \phi_n^{-4} (pw_n'')(0) = 0.$$
 (6.2.50)

Combining this with (6.2.43) and (6.2.44) yields that the boundary terms in (6.2.48) converge to zero. Moreover, it easily follows from (6.2.44) and  $\beta_n \to \infty$  that

$$||e^{-\phi_n \xi}||_{L^2} \to 0 \tag{6.2.51}$$

which implies that

$$|\langle pw_n'', \xi''e^{-\phi_n\xi}\rangle| \le C||w_n||_V||e^{-\phi_n\xi}|| \to 0.$$
 (6.2.52)

Thus, by (6.2.48) we have

$$\langle (pw_n'')'', \frac{1}{\phi_n} e^{-\phi_n \xi} \rangle_{L^2} = \langle pw_n'', \phi_n(\xi')^2 e^{-\phi_n \xi} \rangle_{L^2} + o(1)$$
 (6.2.53)

where  $o(1) \to 0$ , as  $n \to \infty$ . Integrating by parts again and using (6.2.43) and  $w'_n(0) = 0$ , we have

$$\langle pw_n'', \phi_n(\xi')^2 e^{-\phi_n \xi} \rangle_{L^2} = -\langle \phi_n w_n', (p(\xi')^2)' e^{-\phi_n \xi} \rangle_{L^2} + \langle \phi_n^2 w_n', p(\xi')^3 e^{-\phi_n \xi} \rangle_{L^2} + o(1).$$
(6.2.54)

By (6.2.23) and the Gagliardo-Nirenberg inequality, we can deduce that  $\|\phi_n w_n'\|_{L^2}$  is bounded. Therefore,

$$|\langle \phi_n w_n' , (p(\xi')^2)' e^{-\phi_n \xi} \rangle_{L^2}| \le C \|\phi_n w_n'\|_{L^2} \|e^{-\phi_n \xi}\|_{L^2} \to 0.$$
(6.2.55)

Then it follows that

$$\langle pw_n'', \phi_n(\xi')^2 e^{-\phi_n \xi} \rangle = \langle \phi_n^2 w_n', p(\xi')^3 e^{-\phi_n \xi} \rangle + o(1).$$
 (6.2.56)

Now we use integration by parts once more to obtain that

$$\langle \phi_n^2 w_n' , p(\xi')^3 e^{-\phi_n \xi} \rangle_{L^2} = |\beta_n| w_n(1) p(1) (\xi'(1))^3 - \langle |\beta_n| w_n , (p(\xi')^3)' e^{-\phi_n \xi} \rangle_{L^2} + \langle \phi_n^3 w_n , p(\xi')^4 e^{-\phi_n \xi} \rangle.$$

$$(6.2.57)$$

By the uniform boundedness of  $\|\beta_n w_n\|_{L^2}$  and (6.2.51), we have

$$|\langle \beta_n w_n , (p(\xi')^3)' e^{-\phi_n \xi} \rangle_{L^2}| \le C \|\beta_n w_n\|_{L^2} \|e^{-\phi_n \xi}\|_{L^2} \to 0.$$
 (6.2.58)

Then,

$$\langle \phi_n^2 w_n' , p(\xi')^3 e^{-\phi_n \xi} \rangle_{L^2} = |\beta_n| w_n(1) p(1) (\xi'(1))^3 + \langle \phi_n^3 w_n , p(\xi')^4 e^{-\phi_n \xi} \rangle_{L^2} + o(1).$$
(6.2.59)

Combining this with (6.2.53)–(6.2.59) and (6.2.45), we obtain that

$$|\beta_n|w_n(1)p(1)(\xi'(1))^3 + \langle \phi_n^3 w_n , [p(\xi')^4 - \rho]e^{-\phi_n \xi} \rangle = o(1).$$
 (6.2.60)

Now it is clear that in order to have  $\beta_n w_n(1) \to 0$ , it suffices to choose  $\xi(x)$  to satisfy the following equation

$$p(x)(\xi'(x))^4 - \rho(x) = 0. (6.2.61)$$

Clearly, the following choice of function  $\xi$ 

$$\xi(x) = \int_{x}^{1} \left(\frac{\rho(s)}{p(s)}\right)^{\frac{1}{4}} ds$$
 (6.2.62)

satisfies (6.2.44). With this special choice of  $\xi$ , (6.2.60) gives us the desired result. Thus, the proof of Lemma 6.2.1 is complete.

Now we turn our attention to the conditions on  $\rho, p$  under which one can conclude that

$$i\mathbb{R} \subset \rho(\mathcal{A}).$$
 (6.2.63)

**Lemma 6.2.2** If for each  $\beta \in \mathbb{R}$ , the following boundary value problem

$$\begin{cases} (pw'')'' - \beta^2 \rho w = 0, & w \in V, \quad pw'' \in H^2(0, 1) \\ w''(1) = w'''(1) = 0, & F(w'(1), w(1))^T = (0, 0)^T \end{cases}$$

$$(6.2.64)$$

has unique solution w = 0, then  $i \mathbb{R} \subset \rho(A)$  for A defined in (6.2.8).

**Proof** We have already proved the compactness of  $\mathcal{A}^{-1}$  in Theorem 6.2.1. Thus,  $\sigma(\mathcal{A})$ , the the spectrum of  $\mathcal{A}$  only consists of eigenvelues of  $\mathcal{A}$ . Therefore, the claim  $iR \subset \rho(\mathcal{A})$  is equivalent to that the equation

$$(i\beta I - \mathcal{A})(w, v)^T = (0, 0)^T, \quad \beta \in \mathbb{R}, \quad (w, v)^T \in \mathcal{D}(\mathcal{A})$$
 (6.2.65)

has only a trival solution. For  $\beta=0$ , multiplying the differential equation in (6.2.64) by w, then integrating by parts twice, we conclude that pw''=0. Then by the boundary conditions at x=0, we immediately get w=0. This is nothing else, but what we have proved in Theorem 6.2.1:  $0 \in \rho(A)$ .

For  $\beta \in \mathbb{R}, \beta \neq 0$ , equation (6.2.65) can be equivalently reduced to (6.2.64). In fact, we can get  $v = i\beta w$  from the first equation in (6.2.65). Then we can eliminate v from the second equation in (6.2.65) to get  $(pw'')'' - \beta^2 \rho w = 0$ . Since  $(w, v)^T \in \mathcal{D}(\mathcal{A})$ , we have  $w \in V$ ,  $pw'' \in H^2(0, 1)$  and

$$(-p(1)w''(1), (pw'')'(1))^{T} = F(v'(1), v(1))^{T}.$$
(6.2.66)

Taking the inner product of (6.2.65) with  $(w, v)^T$  in  $\mathcal{H}$  and using (6.2.11), we get  $(v'(1), v(1))^T \cdot F(v'(1), v(1))^T = 0$  which, due to the assumption that F is symmetric and non-negative definite, is equivalent to

$$F(v'(1), v(1))^T = 0.$$
 (6.2.67)

Therefore, due to (6.2.67), w''(1) = w'''(1) = 0 is equivalent to (6.2.66). Since  $v = i\beta w$  and  $\beta \neq 0$ , (6.2.67) is equivalent to  $F(w'(1), w(1))^T = (0, 0)$ . Thus the proof is completed by the derived equivalence between (6.2.65) and (6.2.64).

In what follows, we prove that if one of three conditions in the statement of Theorem 6.2.2 is satisfied, then  $iR \subset \rho(A)$ .

**Lemma 6.2.3** If condition (i) in the statement of Theorem 6.2.2 is satisfied, then  $i\mathbb{R} \subset \rho(A)$ .

**Proof** In this case, since F is positive definite, we deduce from  $F(w'(1), w(1))^T = (0,0)^T$  that w(1) = w'(1) = 0. By Lemma 6.2.2, we only need to verify that the following problem

$$\begin{cases} (pw'')'' - \beta^2 \rho w = 0, & w \in V, \ pw'' \in H^2(0,1), \\ w(1) = w'(1) = w''(1) = w'''(1) = 0 \end{cases}$$
 (6.2.68)

has only trivial solution. This follows from uniqueness of solutions to the above initial value problem for ordinary differential equation.  $\Box$ 

**Lemma 6.2.4** If condition (ii) in the statement of Theorem 6.2.2 is satisfied, then  $i\mathbb{R}\subset \rho(A)$ .

**Proof** In this case,  $F(w'(1), w(1))^T = (0, 0)^T$  implies w(1) = 0. By Lemma 6.2.2 we only need to verify that the boundary value problem

$$\begin{cases} (pw'')'' - \beta^2 \rho w = 0, \\ w(0) = w'(0) = w(1) = w''(1) = w'''(1) = 0 \end{cases}$$
 (6.2.69)

has only a trivial solution. Multiplying the ordinary differential equation in (6.2.69) by xw' and integrating by parts, noticing the boundary conditions in (6.2.69), we have

$$\int_0^1 [(\rho + x\rho)' |\beta w|^2 + (3p - xp') |w''|^2 dx = 0.$$
 (6.2.70)

By condition (ii), we deduce from (6.2.70) that  $w \equiv 0$ . Therefore,  $i \mathbb{R} \subset \rho(A)$ .

**Lemma 6.2.5** If condition (iii) in the statement of Theorem 6.2.2 is satisfied, then  $i\mathbb{R}\subset \rho(\mathcal{A})$ .

**Proof** In this case,  $F(w'(1), w(1))^T = (0, 0)^T$  implies w'(1) = 0. By Lemma 6.2.2 and Theorem 6.2.1, we only need to verify that for each  $\beta \in \mathbb{R}, \beta \neq 0$ , the boundary value problem

$$\begin{cases} (pw'')'' - \beta^2 \rho w = 0, \\ w(0) = w'(0) = w'(1) = w''(1) = w'''(1) = 0 \end{cases}$$
 (6.2.71)

has only a trivial solution.

Let

$$q(x) = \frac{1}{\rho} \left( c + \int_0^x \frac{ds}{p(s)} \right) \tag{6.2.72}$$

where  $c \in \mathbb{R}$  is the constant appearing in condition (iii) in the statement of Theorem 6.2.2. Taking the inner product of the ordinary differential equation in (6.2.71) with q(pw'')' in  $L^2(0,1)$  and integrating by parts, we obtain that

$$q(0)|(pw'')'(0)|^{2} + \int_{0}^{1} [q'|(pw'')'|^{2} + (3 + \rho qp')|\beta w'|^{2}]dx = 0.$$
 (6.2.73)

By condition (iii) in the statement in Theorem 6.2.2, we have

$$\begin{cases} q' = \left(\frac{\rho}{p} - \left(c + \int_0^x \frac{ds}{p(s)}\right) \rho'\right) \frac{1}{\rho^2} \ge 0, \\ 3 + \rho q p' = 3 + \left(c + \int_0^x \frac{ds}{p(s)}\right) p' > 0, \\ q(0) = \frac{c}{\rho} \ge 0. \end{cases}$$
 (6.2.74)

Therefore,  $\beta w = 0$  in  $H_0^1(0,1)$  which implies  $w \equiv 0$  for  $\beta \neq 0$ . Thus, the proof of Lemma 6.2.5 is complete.

Finally, we return to the proof of Theorem 6.2.2. Now it is clear that the proof of Theorem 6.2.2 is completed by combining Lemmas 6.2.1-6.2.5.

## Chapter 7

#### Uniformly Stable Approximations

All the systems discussed in previous chapters are treated as an abstract first-order evolution equation

$$\begin{cases} \frac{dz(t)}{dt} = \mathcal{A}z(t) + f(t), & \forall t > 0 \\ z(0) = z_0 \end{cases}$$
(7.0.1)

on a Hilbert space  $\mathcal{H}$ , and  $\mathcal{A}$  is the infinitesimal generator of a  $C_0$ -semigroup  $T(t) = e^{\mathcal{A}t}$  on  $\mathcal{H}$ . In order to compute the solution z(t), one often has to use various numerical approximation schemes. The most common approach for the approximation of (7.0.1) is to consider a sequence of finite-dimensional systems

$$\begin{cases} \frac{dz^N(t)}{dt} = \mathcal{A}^N z^N(t) + f^N(t), & \forall t > 0 \\ z^N(0) = z_0^N \end{cases}$$
(7.0.2)

on a sequence of finte-dimensional subspaces  $\mathcal{H}^N$  of  $\mathcal{H}$ , where  $\mathcal{A}^N$  is the infinitesimal generator of a  $C_0$ -semigroup  $T^N(t) = e^{\mathcal{A}^N t}$  on  $\mathcal{H}^N$ . Generally, (7.0.2) is derived from (7.0.1) using various discretization techniques.

**Definition 7.0.1** A sequence of  $C_0$ -semigroups  $S^N(t)$  is said to be uniformly exponentially stable in N if there exist positive constants M and  $\alpha$  independent of N such that

$$||S^N(t)|| \le Me^{-\alpha t}, \quad t \ge 0.$$
 (7.0.3)

Our main interest in this chapter is to find the conditions under which (7.0.3) holds. Our motivation arises from the study of the *linear-quadratic regulator problem* (in short, LQR problem) in the control theory. In what follows, we briefly recall the related results in the control theory (refer to Gibson [1] and Gibson, Rosen & Tao [1] for the detailed discussion in this aspect).

For f(t) = Bu(t) in (7.0.1) with  $B = \mathcal{B}(\mathbb{R}^m, \mathcal{H})$ , i.e., B is a linear bounded operator from  $\mathbb{R}^m$  to  $\mathcal{H}$ ,  $u(t) \in \mathbb{R}^m$ , we want to choose u to minimize the following functional

$$J(u) = \int_0^\infty \left[ \langle Qz(t), z(t) \rangle_{\mathcal{H}} + u^T(t) Ru(t) \right] dt$$
 (7.0.4)

where  $Q \in \mathcal{B}(\mathcal{H}, \mathcal{H})$  is a given non-negative self-adjoint linear bounded operator and  $R \in \mathbb{R}^{m \times m}$  is a given symmetric positive definite matrix. This problem is usually called the LQR problem in the control theory. We say that the operator pair (A, B) is stabilizable if there exists a bounded linear operator K such that A - BK generates an exponentially stable  $C_0$ -semigroup  $S(t) = e^{(A-BK)t}$ . It is known from the control theory that if (A, B) is stabilizable, then there is a unique non-negative self-adjoint operator solution  $\Pi \in \mathcal{B}(\mathcal{H}, \mathcal{H})$  to the following operator algebraic Riccati equation

$$A^*\Pi + \Pi A - \Pi B R^{-1} B^*\Pi + Q = 0.$$
 (7.0.5)

It turns out that the optimal control of this LQR problem mentioned previously has the feedback form

$$u(t) = -Kz(t), \quad t \ge 0 \tag{7.0.6}$$

where

$$K = R^{-1}B^*\Pi \in \mathcal{B}(\mathcal{H}, \mathbb{R}^m)$$
(7.0.7)

which is called the gain operator. A sufficient condition to guarantee the stabilizability of (A, B) is the exponential stability of  $T(t) = e^{At}$  because we can take K = 0. That is one of the important reasons why we would like to study the exponential stability of a  $C_0$ -semigroup in a Hilbert space in this book.

The finite-dimensional approximation of the LQR problem is:

For  $f^N(t) = B^N u(t)$  in (7.0.2) with  $B^N \in \mathcal{B}(\mathbb{R}^m, \mathcal{H}^N)$  and  $u(t) \in \mathbb{R}^m$ , we want to choose u(t) to minimize the following approximate functional

$$J^{N}(u) = \int_{0}^{\infty} \left[ \langle Q^{N} z^{N}(t), z^{N}(t) \rangle_{\mathcal{H}^{N}} + u^{T}(t) R u(t) \right] dt$$
 (7.0.8)

where  $Q^N \in \mathcal{B}(\mathcal{H}^N,\mathcal{H}^N)$  is self-adjoint and non-negative. Accordingly, we say that the operator pair  $(\mathcal{A}^N,B^N)$  is uniformly stabilizable, if there exists a bounded linear

operator  $K^N$  such that  $A^N - B^N K^N$  generates a  $C_0$ -semigroup  $S^N(t) = e^{(A^N - B^N K^N)t}$ satisfying (7.0.3) for all N. It is also known from the control theory that if  $(A^N, B^N)$ is uniformly stabilizable, then for every positive integer N, there is a unique nonnegative, self-adjoint solution  $\Pi^N \in \mathcal{B}(\mathcal{H}^N,\mathcal{H}^N)$  to the following finite-dimensional algebraic Riccati equation

$$(\mathcal{A}^{N})^{*}\Pi^{N} + \Pi^{N}\mathcal{A}^{N} - \Pi^{N}B^{N}R^{-1}(B^{N})^{*}\Pi^{N} + Q^{N} = 0.$$
 (7.0.9)

The corresponding optimal control has the following feedback form

$$u^{N}(t) = -K^{N} z^{N}(t), \quad t \ge 0 \tag{7.0.10}$$

with

$$K^{N} = R^{-1}(B^{N})^{*}\Pi^{N} \in \mathcal{B}(\mathcal{H}^{N}, \mathbb{R}^{m}).$$
 (7.0.11)

A natural question is: What is the relation between  $u^N$  and u, and will  $u^N$  converge to u as N goes to infinity? To answer this question, let us assume that the approximation scheme we work with is convergent in the sense that for each N, there exists a linear mapping (projection)  $P^N$  from  $\mathcal{H}$  onto  $\mathcal{H}^N$  such that

$$\lim_{N \to \infty} P^N z = z, \quad \lim_{N \to \infty} Q^N P^N z = Qz \quad \lim_{N \to \infty} B^N u = Bu, \quad \forall u \in \mathbb{R}^m, \ \forall z \in \mathcal{H},$$
(7.0.12)

$$\begin{cases}
\lim_{N \to \infty} T^N(t) P^N z = T(t) z, \\
\forall z \in H, \ t \ge 0.
\end{cases}$$

$$\lim_{N \to \infty} (T^N(t))^* P^N z = (T(t))^* z,$$
(7.0.13)

It is known from the control theory that if

$$\sup_{N} \|\Pi^{N}\| < \infty \tag{7.0.14}$$

and  $S^{N}(t) = e^{(A^{N} - B^{N}K^{N})t}$  is uniformly exponentially stable in N, then

$$\lim_{N \to \infty} \Pi^N P^N z = \Pi z, \quad z \in \mathcal{H},$$

$$\lim_{N \to \infty} S^N(t) P^N z = S(t) z, \quad z \in \mathcal{H}$$
(7.0.15)

$$\lim_{N \to \infty} S^N(t) P^N z = S(t) z, \quad z \in \mathcal{H}$$
 (7.0.16)

with the convergence being uniform in any bounded intervals of t. Moreover, it follows from (7.0.15) that

$$\lim_{N \to \infty} ||K^N P^N - K||_{\mathcal{B}(\mathcal{H}, \mathbb{R}^m)} = 0. \tag{7.0.17}$$

This leads to the strong convergence of optimal control  $u^N(t)$  of the finite-dimensional LQR problem to optimal control u(t) of the original infinite-dimensional LQR problem, i.e.,

$$\lim_{N \to \infty} \|u^N(t) - u(t)\|_{\mathbb{R}^m} = 0 \tag{7.0.18}$$

uniformly in any bounded intervals of t. As mentioned in Gibson, Rosen & Tao [1], the easiest way to guarantee (7.0.14) and the exponential stability of  $S^N(t) = e^{(A^N - B^N K^N)t}$  uniformly in N is to show that  $T^N(t) = e^{A^N(t)}$  itself possesses the exponential stability uniformly in N.

Then, it is clear from the previous discussion that when we construct an approximation scheme for the infinite-dimensional LQR problem, we need to know how to verify the uniformly exponential stability in N for a sequence of  $C_0$ -semigroups  $S^N(t)$  on the Hilbert spaces  $\mathcal{H}^N$ .

In Section 7.1, we will characterize the property (7.0.3) similar to Theorem 1.3.2. Then in Sections 7.2 and 7.3 we will apply the result to the approximations of the linear thermoelastic and viscoelastic systems.

#### 7.1 Main Theorem

In this section we will give necessary and sufficient conditions to characterize the uniform exponential stability of  $T_n(t)$ , a sequence of  $C_0$ -semigroups on the Hilbert spaces  $\mathcal{H}_n$ .

For a single  $C_0$ -semigroup T(t) on a Hilbert space, the characteristic conditions of exponential stability, as mentioned in Chapter 1, were given by Gearhart [1] and Huang [1]. In what follows, we extend their results to a sequence of  $C_0$ -semigroups  $T_n(t)$ .

**Theorem 7.1.1** Let  $T_n(t)$   $(n = 1, \cdots)$  be a sequence of  $C_0$ -semigroups of contractions

on the Hilbert spaces  $\mathcal{H}_n$  and  $\mathcal{A}_n$  be the corresponding infinitesimal generators. Then  $T_n(t)$  are uniformly exponentially stable if and only if the following three conditions hold:

$$\sup_{n \in N} \{ Re\lambda \mid \lambda \in \sigma(\mathcal{A}_n) \} = \sigma_0 < 0, \tag{7.1.1}$$

there exists  $\sigma \in (\sigma_0, 0)$  such that

$$\sup_{Re\lambda>\sigma, n\in\mathbb{N}} \left\{ \left\| (\lambda I - \mathcal{A}_n)^{-1} \right\| \right\} = M_0 < \infty, \tag{7.1.2}$$

and there exists a constant  $M_1 > 0$  independent of n such that

$$||T_n(t)|| \le M_1 < \infty, \quad \forall t > 0, \quad \forall n \in \mathbb{N}.$$
 (7.1.3)

**Proof** If  $T_n(t)$  are uniformly exponentially stable, i.e., there exist  $M, \alpha > 0$  such that

$$||T_n(t)|| \le Me^{-\alpha t}, \quad \forall t > 0, \quad \forall n \in \mathbb{N}, \tag{7.1.4}$$

then

$$\omega_0(\mathcal{A}_n) \stackrel{\text{def}}{=} \lim_{t \to +\infty} \frac{\ln ||T_n(t)||}{t} \le -\alpha. \tag{7.1.5}$$

Thus, (7.1.1) follows from the following property:

$$\sigma_0(\mathcal{A}_n) \stackrel{def}{=} \sup \left\{ \operatorname{Re} \lambda; \mid \lambda \in \sigma(\mathcal{A}_n) \right\} \le \omega_0(\mathcal{A}_n) \le -\alpha. \tag{7.1.6}$$

Let  $\sigma = -\frac{\alpha}{2}$ . Then  $\sigma_0 < \sigma < 0$ . For  $Re \lambda \ge \sigma$ , we have

$$\|(\lambda I - \mathcal{A}_n)^{-1}x\| = \|\int_0^{+\infty} e^{-\lambda t} T_n(t) x dt\|$$

$$\leq M \|x\| \int_0^{+\infty} e^{-Re \lambda t} e^{-\alpha t} dt$$

$$= \frac{M \|x\|}{\alpha + Re \lambda}$$

$$\leq \frac{2M \|x\|}{\alpha}. \tag{7.1.7}$$

This implies that (7.1.2) holds. Furthermore, (7.1.3) immediately follows from (7.1.4). Thus, the proof of the "only if" part is complete.

Now suppose (7.1.1)-(7.1.3) hold. Let

$$\tilde{\mathcal{A}}_n = \mathcal{A}_n - \frac{\sigma}{2}I. \tag{7.1.8}$$

Then

$$\sup_{n \in \mathcal{N}} \left\{ \operatorname{Re} \lambda; \mid \lambda \in \sigma(\widetilde{\mathcal{A}}_n) \right\} \le -\frac{\sigma}{2} + \sigma_0 < \frac{\sigma}{2} < 0, \tag{7.1.9}$$

and

$$\sup_{Re \, \lambda > \frac{\sigma}{2}, \, n \in \mathbb{N}} \left\{ \left\| \left( \lambda I - \widetilde{\mathcal{A}}_n \right)^{-1} \right\| \right\} = M_0 < \infty.$$
 (7.1.10)

In what follows, we prove that (7.1.9), (7.1.10), and (7.1.3) imply that there exists a positive constant M>0 independent of n such that the corresponding semigroups  $\tilde{T}_n(t)=T_n(t)e^{-\frac{\sigma}{2}t}$  to the infinitesimal generators  $\tilde{\mathcal{A}}_n$  satisfy

$$\left\| \widetilde{T}_n(t) \right\| \le M, \tag{7.1.11}$$

which results in (7.1.4) with  $\alpha = -\frac{\sigma}{2} > 0$ .

To prove (7.1.11), we use the same technique as in Huang [1]. First, by (7.1.3) we have

$$\left\| \tilde{T}_n(t) \right\| \le M_1 e^{-\frac{\sigma}{2}t}. \tag{7.1.12}$$

Therefore,

$$\omega_0(\tilde{\mathcal{A}}_n) \le -\frac{\sigma}{2}.\tag{7.1.13}$$

Our next step is to prove the following estimate:

$$\left| \left( \tilde{T}_n(t)x, \ y \right) \right| \le \frac{cM_1^2}{2\pi} \|x\| \|y\|, \text{ for } t \ge 1, \ x, y \in \mathcal{H}_n, \ \forall n,$$
 (7.1.14)

with constant c > 0. For this purpose we first prove the following two lemmas.

**Lemma 7.1.1** For any  $x \in \mathcal{H}_n, \tau > -\frac{\sigma}{2}$ , as a function of  $\omega \in \mathbb{R}$ ,

$$\left\|\left((\tau+\boldsymbol{i}\omega)I-\widetilde{\mathcal{A}}_n\right)^{-1}x\right\|\in L^2(I\!\!R),\ \left\|\left((\tau+\boldsymbol{i}\omega)I-\widetilde{\mathcal{A}}_n\right)^{-1}x\right\|\to 0,\ as\ |\omega|\to\infty.$$

Moreover,

$$\int_{-\infty}^{+\infty} \left\| \left( (\tau + i\omega)I - \widetilde{\mathcal{A}}_n \right)^{-1} x \right\|^2 d\omega \le \frac{\pi M_1^2 \|x\|^2}{\tau + \frac{\sigma}{2}}, \tag{7.1.15}$$

$$\int_{-\infty}^{+\infty} \left\| \left( (\tau - i\omega)I - \tilde{\mathcal{A}}_n^* \right)^{-1} x \right\|^2 d\omega \le \frac{\pi M_1^2 \|x\|^2}{\tau + \frac{\sigma}{2}}. \tag{7.1.16}$$

Proof By Hille-Yosida's theorem (see Pazy [1]) we have

$$\left\| \left( (\tau + i\omega)I - \tilde{\mathcal{A}}_{n} \right)^{-1} x \right\|^{2}$$

$$= \left( \int_{0}^{\infty} e^{-(\tau + i\omega)t} \tilde{T}_{n}(t) x dt, \int_{0}^{\infty} e^{-(\tau + i\omega)s} \tilde{T}_{n}(s) x ds \right)$$

$$= \int_{0}^{\infty} \int_{0}^{\infty} e^{-\tau (t+s)} e^{-i\omega(t-s)} \left( \tilde{T}_{n}(t) x, \tilde{T}_{n}(s) x \right) dt ds$$

$$= \int_{0}^{\infty} \int_{-s}^{\infty} e^{-\tau (u+2s)} e^{-i\omega u} \left( \tilde{T}_{n}(u+s) x, \tilde{T}_{n}(s) x \right) du ds$$

$$= \int_{0}^{\infty} e^{-i\omega u} \left( \int_{0}^{\infty} e^{-\tau (u+2s)} \left( \tilde{T}_{n}(u+s) x, \tilde{T}_{n}(s) x \right) ds \right) du$$

$$+ \int_{-\infty}^{0} e^{-i\omega u} \left( \int_{-u}^{\infty} e^{-\tau (u+2s)} \left( \tilde{T}_{n}(u+s) x, \tilde{T}_{n}(s) x \right) ds \right) du$$

$$\stackrel{\text{def}}{=} \int_{-\infty}^{+\infty} f(u) e^{-i\omega u} du \qquad (7.1.17)$$

with

$$f(u) = \begin{cases} \int_0^\infty e^{-\tau(u+2s)} \left( \tilde{T}_n(u+s)x, \tilde{T}_n(s)x \right) ds, & u > 0, \\ \int_{-v}^\infty e^{-\tau(u+2s)} \left( \tilde{T}_n(u+s)x, \tilde{T}_n(s)x \right) ds, & u < 0. \end{cases}$$
(7.1.18)

Therefore, by (7.1.12) we have for u > 0

$$|f(u)| \leq \int_{0}^{\infty} e^{-\tau(u+2s)} \|\widetilde{T}_{n}(u+s)x\| \cdot \|\widetilde{T}_{n}(s)x\| ds$$

$$\leq M_{1}^{2} \|x\|^{2} \int_{0}^{\infty} e^{-\tau(u+2s)} e^{-\frac{\sigma}{2}(u+s)} e^{-\frac{\sigma}{2}s} ds$$

$$= \frac{M_{1}^{2} \|x\|^{2}}{2(\tau + \frac{\sigma}{2})} e^{-(\tau + \frac{\sigma}{2})u},$$

and for u < 0,

$$|f(u)| \leq M_1^2 ||x||^2 \int_{-u}^{\infty} e^{-\tau(u+2s)} e^{-\frac{\sigma}{2}(u+s)} e^{-\frac{\sigma}{2}s} ds$$
$$= \frac{M_1^2 ||x||^2}{2(\tau + \frac{\sigma}{2})} e^{(\tau + \frac{\sigma}{2})u}.$$

It turns out that  $f(u) \in L^1(\mathbb{R}) \cap L^{\infty}(\mathbb{R})$ ,

$$||f||_{L^{\infty}} \le \frac{M_1^2 ||x||^2}{2(\tau + \frac{\sigma}{2})}.$$
 (7.1.19)

By the result in Hewitt & Stromberg [1], we conclude that  $\|((\tau + i\omega)I - \tilde{\mathcal{A}}_n)^{-1}x\|^2 \in L^1(\mathbb{R})$  and

$$\int_{-\infty}^{+\infty} \|((\tau + i\omega)I - \tilde{\mathcal{A}}_n)^{-1}x\|^2 d\omega \le 2\pi \|f\|_{L^{\infty}}.$$
 (7.1.20)

Moreover, from the Riemann-Lebesque theorem,  $\|((\tau + i\omega)I - \tilde{\mathcal{A}}_n)^{-1}x\| \to 0$  as  $|\omega| \to \infty$ . Combining (7.1.20) with (7.1.19) yields (7.1.15). Inequality (7.1.16) can be proved the same way.

**Lemma 7.1.2** For any  $x \in \mathcal{H}_n$ ,  $\omega \in \mathbb{R}$  we have

$$\left\| (\boldsymbol{i}\omega I - \widetilde{\mathcal{A}}_n)^{-1} \boldsymbol{x} \right\| \le 2^m \left\| ((-\sigma + \boldsymbol{i}\omega)I - \widetilde{\mathcal{A}}_n)^{-1} \boldsymbol{x} \right\|$$
 (7.1.21)

with m being an integer such that

$$m - 1 < -2M_0 \sigma \le m. \tag{7.1.22}$$

**Proof** Let

$$\tau_m = -\sigma, \ \Delta \tau = \frac{1}{2M_0}, \ \tau_i = \tau_m - (m-i)\Delta \tau, \ (i = m-1, \dots, 0).$$
(7.1.23)

Then  $\tau_0 \leq 0$ . Since

$$\begin{aligned} & \left\| \left[ I - (\tau_i - \tau)((\tau_i + i\omega)I - \tilde{\mathcal{A}}_n)^{-1} \right] x \right\| \\ & \geq & \left\| x \right\| - (\tau_i - \tau) \left\| ((\tau_i + i\omega)I - \tilde{\mathcal{A}}_n)^{-1} x \right\| \\ & \geq & \left\| x \right\| - \Delta \tau \cdot M_0 \cdot \| x \| \\ & \geq & \frac{1}{2} \| x \|, \quad \text{for } \tau \in [\tau_{i-1}, \ \tau_i], \end{aligned}$$

we have

$$\|[I - (\tau_i - \tau)((\tau_i + i\omega)I - \tilde{\mathcal{A}}_n)^{-1}]^{-1}\| \le 2.$$
 (7.1.24)

For any fixed  $i, (i = m, \dots, 1)$  and any  $\tau \in [\tau_{i-1}, \tau_i]$ , we obtain that

$$\| ((\tau + i\omega)I - \tilde{\mathcal{A}}_n)^{-1}x \|$$

$$= \| \left[ I - (\tau_i - \tau)((\tau_i + i\omega)I - \tilde{\mathcal{A}}_n)^{-1} \right]^{-1} ((\tau_i + i\omega)I - \tilde{\mathcal{A}}_n)^{-1}x \|$$

$$\leq \| \left[ I - (\tau_i - \tau)((\tau_i + i\omega)I - \tilde{\mathcal{A}}_n)^{-1} \right]^{-1} \| \cdot \| ((\tau_i + i\omega)I - \tilde{\mathcal{A}}_n)^{-1}x \|$$

$$\leq 2 \| ((\tau_i + i\omega)I - \tilde{\mathcal{A}}_n)^{-1}x \| .$$

$$(7.1.25)$$

This leads to (7.1.21) by induction.

Lemma 7.1.2 and 7.1.3 imply that

$$\int_{-\infty}^{+\infty} \left\| (i\omega I - \tilde{\mathcal{A}}_n)^{-1} x \right\|^2 d\omega \le c M_1^2 \|x\|^2$$
 (7.1.26)

and

$$\int_{-\infty}^{+\infty} \left\| (-i\omega I - \tilde{\mathcal{A}}_n^*)^{-1} x \right\|^2 d\omega \le c M_1^2 \|x\|^2$$
 (7.1.27)

with a positive constant c depending only on  $\sigma$ .

We are now in position to prove (7.1.14). Let  $\tau_2 > \tau_1 > -\frac{\sigma}{2} > 0$ . Then for  $x \in \mathcal{D}(\tilde{\mathcal{A}}_n^2)$ ,  $y \in \mathcal{H}_n$ , by the inverse formula (see Pazy [1], p. 29, Corollary 7.5) we have

$$\begin{split}
\left(\widetilde{T}_{n}(t)x, y\right) &= \frac{1}{2\pi i} \lim_{\omega \to +\infty} \int_{\tau_{1} - i\omega}^{\tau_{1} + i\omega} e^{\lambda t} \left( (\lambda I - \widetilde{\mathcal{A}}_{n})^{-1} x, y \right) d\lambda \\
&= \frac{1}{2\pi i} \lim_{\omega \to +\infty} \left[ \frac{e^{\lambda t}}{t} \left( (\lambda I - \widetilde{\mathcal{A}}_{n})^{-1} x, y \right) \Big|_{\tau_{1} - i\omega}^{\tau_{1} + i\omega} \right. \\
&+ \int_{\tau_{1} - i\omega}^{\tau_{1} + i\omega} \frac{e^{\lambda t}}{t} \left( (\lambda I - \widetilde{\mathcal{A}}_{n})^{-2} x, y \right) d\lambda \right]. 
\end{split} (7.1.28)$$

It turns out from Lemma 7.1.1 that

$$\left(\tilde{T}_n(t)x,\ y\right) = \lim_{\omega \to +\infty} \frac{1}{2\pi i} \int_{\tau_1 - i\omega}^{\tau_1 + i\omega} \frac{e^{\lambda t}}{t} \left( (\lambda I - \tilde{\mathcal{A}}_n)^{-2} x,\ y \right) d\lambda. \tag{7.1.29}$$

Since  $\sup_{n\in N}\left\{Re\,\lambda; \mid \lambda\in\sigma(\tilde{\mathcal{A}}_n)\right\} < \frac{\sigma}{2} < 0$ , for t>0,  $\frac{e^{\lambda t}}{t}\left((\lambda I-\tilde{\mathcal{A}}_n)^{-2}x,\ y\right)$  is analytic in the domain:  $\{\lambda\mid Re\,\lambda\in(\frac{\sigma}{2},\tau_2)\}$ . Let  $\Gamma_\omega$  be the curve composed of  $\Gamma_0=\{Re\,\lambda=\tau_1,\ -\omega\leq Im\,\lambda\leq\omega\}$ ,  $\Gamma_{1,2}=\{0\leq Re\,\lambda\leq\tau_1,\ Im\,\lambda=\pm\omega\}$  and  $\Gamma_3=\{Re\,\lambda=0,\ -\omega\leq Im\,\lambda\leq\omega\}$ . From

$$\int_{\Gamma_{\omega}} \frac{e^{\lambda t}}{t} \left( (\lambda I - \tilde{\mathcal{A}}_n)^{-2} x, \ y \right) d\lambda = 0 \tag{7.1.30}$$

and, due to Lemma 7.1.1,

$$\lim_{\omega \to +\infty} \int_{\Gamma_{1,2}} \frac{e^{\lambda t}}{t} \left( (\lambda I - \tilde{\mathcal{A}}_n)^{-2} x, \ y \right) d\lambda = 0 \tag{7.1.31}$$

it follows that

$$\begin{split} \left( \tilde{T}_n(t)x, \ y \right) &= \frac{1}{2\pi i} \lim_{\omega \to +\infty} \int_{-i\omega}^{i\omega} \frac{e^{\lambda t}}{t} \left( (\lambda I - \tilde{\mathcal{A}}_n)^{-2} x, \ y \right) d\lambda \\ &= \frac{1}{2\pi} \int_{-\infty}^{+\infty} \frac{e^{i\omega t}}{t} \left( (i\omega I - \tilde{\mathcal{A}}_n)^{-2} x, \ y \right) d\omega. \end{split}$$

Therefore,

$$\left| \left( \tilde{T}_n(t)x, \ y \right) \right| \leq \frac{1}{2\pi} \int_{-\infty}^{+\infty} \frac{1}{t} \left\| (i\omega I - \tilde{\mathcal{A}}_n)^{-1} x \right\| \cdot \left\| (-i\omega I - \tilde{\mathcal{A}}_n^*)^{-1} y \right\| d\omega$$

$$\leq \frac{1}{2\pi t} \left( \int_{-\infty}^{+\infty} \left\| (i\omega I - \tilde{\mathcal{A}}_n)^{-1} x \right\|^2 d\omega \right)^{\frac{1}{2}} \left( \int_{-\infty}^{+\infty} \left\| (-i\omega I - \tilde{\mathcal{A}}_n^*)^{-1} y \right\|^2 d\omega \right)^{\frac{1}{2}}. \quad (7.1.32)$$

Combining it with (7.1.26), (7.1.27) yields (7.1.14) for  $x \in \mathcal{D}(\tilde{\mathcal{A}}_n^2)$ ,  $y \in \mathcal{H}_n$ . Since  $\mathcal{D}(\tilde{\mathcal{A}}_n^2)$  is dense in  $\mathcal{H}_n$ , (7.1.14) also holds for any  $x, y \in \mathcal{H}_n$ . By taking  $y = \tilde{T}_n(t)x$ , we conclude that for  $t \geq 1$ 

$$\|\tilde{T}_n(t)\| \le \frac{cM_1^2}{2\pi}.$$
 (7.1.33)

For  $0 \le t \le 1$ , by (7.1.3) we have

$$\|\tilde{T}_n(t)\| = \|T_n(t)e^{-\frac{\sigma}{2}t}\| \le M_1e^{-\frac{\sigma}{2}}.$$
 (7.1.34)

Therefore,

$$\left\| \widetilde{T}_n(t) \right\| \le \max \left( \frac{cM_1^2}{2\pi}, \ M_1 e^{-\frac{\sigma}{2}} \right) \stackrel{def}{=} M, \quad \forall t > 0$$
 (7.1.35)

which results in

$$||T_n(t)|| = ||\tilde{T}_n(t)e^{\frac{\sigma}{2}t}|| \le Me^{\frac{\sigma}{2}t}, \quad \sigma < 0, \ \forall t > 0.$$
 (7.1.36)

Thus, the proof of Theorem 7.1.1 is complete.

**Theorem 7.1.2** Let  $T_n(t)$   $(n = 1, \dots)$  be a sequence of  $C_0$ -semigroups on the Hilbert spaces  $\mathcal{H}_n$  and  $\mathcal{A}_n$  be the corresponding infinitesimal generators. Then  $T_n(t)$  are uniformly exponentially stable if and only if (7.1.1), (7.1.3), and

$$\sup_{Re \, \lambda > 0, n \in \mathbb{N}} \left\{ \left\| (\lambda I - \mathcal{A}_n)^{-1} \right\| \right\} < \infty \tag{7.1.37}$$

hold.

**Proof** We only need to prove that (7.1.1), (7.1.3), and (7.1.37) imply (7.1.1)–(7.1.3). Let

$$M = \sup_{Re \, \lambda \geq 0, n \in \mathbb{N}} \left\{ \left\| (\lambda I - \mathcal{A}_n)^{-1} \right\| \right\} < \infty, \tag{7.1.38}$$

and  $\lambda = (\tau + i\omega), \ \tau \in [-\frac{1}{2M}, 0]$ . Then, we have

$$\begin{split} \left\| \left( I + \tau (i\omega I - \mathcal{A}_n)^{-1} \right) x \right\| & \geq \|x\| - \frac{1}{2M} \left\| (i\omega I - \mathcal{A}_n)^{-1} x \right\| \\ & \geq \|x\| - \frac{1}{2} \|x\| = \frac{1}{2} \|x\| \,. \end{split}$$

This implies that

$$\left\| \left( I + \tau (\mathbf{i}\omega I - \mathcal{A}_n)^{-1} \right)^{-1} \right\| \le 2. \tag{7.1.39}$$

By

$$\lambda I - \mathcal{A}_n = \left(I + \tau (i\omega I - \mathcal{A}_n)^{-1}\right) (i\omega I - \mathcal{A}_n), \tag{7.1.40}$$

we conclude that  $\lambda I - \mathcal{A}_n$  is invertible and

$$\|(\lambda I - \mathcal{A}_n)^{-1}\| = \|(i\omega I - \mathcal{A}_n)^{-1} (I + \tau (i\omega I - \mathcal{A}_n)^{-1})^{-1}\|$$

$$\leq 2 \|(i\omega I - \mathcal{A}_n)^{-1}\| \leq 2M.$$
(7.1.41)

Let

$$\sigma = \max\left(-\frac{1}{2M}, \frac{\sigma_0}{2}\right). \tag{7.1.42}$$

Then, we have

$$\sigma_0 < \sigma < 0, \quad \sigma \in \left[ -\frac{1}{2M}, \quad 0 \right).$$
 (7.1.43)

As a corollary of Theorem 7.1.2, we have the following theorem.

**Theorem 7.1.3** Let  $T_n(t)$  be a sequence of semigroups of contractions on the Hilbert spaces  $\mathcal{H}_n$  and  $\mathcal{A}_n$  be the corresponding infinitesimal generators. Then  $T_n(t)$  are uniformly exponentially stable if and only if

$$\rho(\mathcal{A}_n) \supset \{i\beta \mid \beta \in \mathbb{R}\}, \quad \forall n \in \mathbb{N}$$
 (7.1.44)

and

$$\sup_{\beta \in \mathbb{R}, n \in \mathbb{N}} \| (i\beta I - \mathcal{A}_n)^{-1} \| < \infty. \tag{7.1.45}$$

**Proof** Since  $T_n(t)$  is a  $C_0$ -semigroup of contractions, we only need to show the equivalence of (7.1.1) and (7.1.37) with (7.1.44) and (7.1.45). Obviously, (7.1.1) and (7.1.37) imply (7.1.44) and (7.1.45). We now prove that (7.1.44) and (7.1.45) also imply (7.1.1) and (7.1.37). By Corollary 3.6 in Pazy [1], the resolvent set  $\rho(\mathcal{A}_n)$  of  $\mathcal{A}_n$  contains the open right half-plane, i.e.,  $\rho(\mathcal{A}_n) \supseteq \{\lambda; Re \lambda > 0\}$ , for all n. Furthermore,  $\|(\lambda I - \mathcal{A}_n)^{-1}\| \le \frac{1}{Re \lambda}$  uniformly in n when  $Re\lambda > 0$ . Thus, for any  $\delta_0 > 0$  we have

$$\sup_{Re \, \lambda > \delta_0, \, n \in \mathbb{N}} \|(\lambda I - \mathcal{A}_n)^{-1}\| \le \frac{1}{\delta_0}. \tag{7.1.46}$$

Note that (7.1.44) and (7.1.45) imply

$$\sup_{n\in\mathbb{I}N}\left\{\|(i\beta I-\mathcal{A}_n)^{-1}\|\mid\beta\in\mathbb{I}R\right\}=M<\infty. \tag{7.1.47}$$

Let  $\lambda = \alpha + i\beta$ . Then

$$\lambda I - \mathcal{A}_n = \alpha I + i\beta I - \mathcal{A}_n = (\alpha (i\beta I - \mathcal{A}_n)^{-1} + I)(i\beta I - \mathcal{A}_n). \tag{7.1.48}$$

For  $|\alpha| \leq \frac{1}{2M}$ , by the contraction mapping theorem,  $\alpha(i\beta I - \mathcal{A}_n)^{-1} + I$  is invertible for all n. Thus, we have proved (7.1.1). Moreover, we also get

$$\sup_{n \in \mathbb{I} N} \left\{ \| (\lambda I - \mathcal{A}_n)^{-1} \| \mid |Re \, \lambda| \le \frac{1}{2M} \right\} \le 2M. \tag{7.1.49}$$

Combining (7.1.46) and (7.1.49) yields (7.1.37).

#### 7.2 Approximations of the Thermoelastic System

In this section, as an application of Theorem 7.1.3, we first present a general approximation scheme for the linear thermoelastic system

$$\begin{cases} u_{tt} - u_{xx} + \gamma \theta_x = 0, \\ \theta_t + \gamma u_{xt} - \theta_{xx} = 0 \end{cases}$$
 (7.2.1)

on  $(0,\pi)\times(0,\infty)$  with the boundary conditions

$$u|_{x=0,\pi} = \theta|_{x=0,\pi} = 0. (7.2.2)$$

Then we will use Theorem 7.1.3 to show the uniformly exponential stability of the corresponding  $C_0$ -semigroups associated with a particular approximation scheme which is often referred to as a modal method. We also provide a convergence proof of this scheme.

Recall that the corresponding abstract evolution equation for (7.2.1) and (7.2.2) is

$$\frac{d}{dt} \begin{pmatrix} u \\ v \\ \theta \end{pmatrix} = \mathcal{A} \begin{pmatrix} u \\ v \\ \theta \end{pmatrix} = \begin{bmatrix} 0 & I & 0 \\ D^2 & 0 & -\gamma D \\ 0 & -\gamma D & D^2 \end{bmatrix} \begin{pmatrix} u \\ v \\ \theta \end{pmatrix}$$
(7.2.3)

in the Hilbert space  $\mathcal{H}=H^1_0(\Omega)\times L^2(\Omega)\times L^2(\Omega)$ , where  $\Omega=(0,\pi)$  and  $\mathcal{D}(\mathcal{A})=H^2\cap H^1_0\times H^1_0\times H^2\cap H^1_0$ .

In Section 2.2, we have proved that the  $C_0$ -semigroup  $S(t)=e^{\mathcal{A}t}$  is exponentially stable. Let  $H_1^n(\Omega), H_2^n(\Omega)$  and  $H_3^n(\Omega)$  be the n-dimensional subspace of  $H_0^1(\Omega), L^2(\Omega)$  and  $L^2(\Omega)$  with basis  $\{\phi_1, \dots, \phi_n\}, \{\psi_1, \dots, \psi_n\}$  and  $\{\xi_1, \dots, \xi_n\}$ , respectively. Since  $H^2 \cap H_0^1$  is dense in  $L^2$ , we can choose  $\phi_i \in H^2 \cap H_0^1$ ,  $\psi_i \in H_0^1$ ,  $\xi_i \in H^2 \cap H_0^1$ . Let  $\mathcal{H}_n = H_1^n(\Omega) \times H_2^n(\Omega) \times H_3^n(\Omega)$  with a basis  $(j = 1, \dots, n)$ 

$$E_{j} = \begin{pmatrix} \phi_{j} \\ 0 \\ 0 \end{pmatrix}, \quad E_{n+j} = \begin{pmatrix} 0 \\ \psi_{j} \\ 0 \end{pmatrix}, \quad E_{2n+j} = \begin{pmatrix} 0 \\ 0 \\ \xi_{j} \end{pmatrix}. \tag{7.2.4}$$

The inner product on  $\mathcal{H}_n$  is that induced by the inner product of  $\mathcal{H}$  which has been given in Section 2.2. We consider the approximation to the solution of (7.2.3) in the form

$$z_n = \sum_{j=1}^{3n} \tilde{z}_j(t) E_j(x) \tag{7.2.5}$$

which is required to satisfy the following variational system:

$$\left(\frac{dz_n}{dt}, E_j\right)_{\mathcal{H}} = (\mathcal{A}z_n, E_j)_{\mathcal{H}}, \quad j = 1, \dots, 3n.$$
 (7.2.6)

Then we have

$$M_{n}\dot{\tilde{y}}_{n} = \begin{bmatrix} M_{n}^{(1)} & & \\ & M_{n}^{(2)} & \\ & & M_{n}^{(3)} \end{bmatrix} \begin{bmatrix} \dot{\tilde{z}}_{n}^{(1)} \\ \dot{\tilde{z}}_{n}^{(2)} \\ \dot{\tilde{z}}_{n}^{(3)} \end{bmatrix} = \begin{bmatrix} 0 & \widetilde{D}_{n}^{T} & 0 \\ -\widetilde{D}_{n} & 0 & -\gamma \widetilde{F}_{n} \\ 0 & \gamma \widetilde{F}_{n}^{T} & -G_{n} \end{bmatrix} \begin{bmatrix} \widetilde{z}_{n}^{(1)} \\ \widetilde{z}_{n}^{(2)} \\ \widetilde{z}_{n}^{(3)} \end{bmatrix} = \widetilde{A}_{n} \widetilde{y}_{n}$$

$$(7.2.7)$$

with

$$(M_n^{(1)})_{ij} = (D\phi_i, \ D\phi_j)_{L^2}, \quad (M_n^{(2)})_{ij} = (\psi_i, \ \psi_j)_{L^2}, \quad (M_n^{(3)})_{ij} = (\xi_i, \ \xi_j)_{L^2},$$

$$(\widetilde{D}_n)_{ij} = (D\phi_i, \ D\psi_j)_{L^2}, \quad (\widetilde{F}_n)_{ij} = (D\xi_i, \ \psi_j)_{L^2}, \quad (G_n)_{ij} = (D\xi_i, \ D\xi_j)_{L^2}$$

$$(7.2.8)$$

and

$$\tilde{z}_n^{(i)} = (\tilde{z}_{(i-1)n+1}, \cdots, \tilde{z}_{in})^T, \quad i = 1, 2, 3.$$
 (7.2.9)

By construction, the matrix  $M_n^{(i)}$  is symmetric and positive definite. Therefore, there exists a lower triangle matrix  $L_i$  such that  $M_n^{(i)} = (L_i)(L_i)^T$ . Let  $L_n = diag(L_1, L_2, L_3)$  and we denote  $L_n^T \tilde{y}_n$  by  $\bar{y}_n = (\bar{z}_n^{(1)}, \bar{z}_n^{(2)}, \bar{z}_n^{(3)})^T$ . Then to obtain approximate solution  $z_n$ , we are led to solving the following ordinary differential equations

$$\frac{d\bar{y}_n}{dt} = A_n \bar{y}_n \tag{7.2.10}$$

with

$$A_{n} = \begin{bmatrix} 0 & L_{1}^{-1} \widetilde{D}_{n}^{T} (L_{2}^{T})^{-1} & 0 \\ -L_{2}^{-1} \widetilde{D}_{n} (L_{1}^{T})^{-1} & 0 & -\gamma L_{2}^{-1} \widetilde{F}_{n} (L_{3}^{T})^{-1} \\ 0 & \gamma L_{3}^{-1} \widetilde{F}_{n}^{T} (L_{2}^{T})^{-1}, & -L_{3}^{-1} G_{n} (L_{3}^{T})^{-1} \end{bmatrix}.$$
 (7.2.11)

It is easy to see that

$$Re \left( A_n \bar{y}_n, \ \bar{y}_n \right)_{C^{3n}} = - \left( G_n (L_3^T)^{-1} \bar{z}_n^{(3)}, \ (L_3^T)^{-1} \bar{z}_n^{(3)} \right)_{C^n} \le 0 \tag{7.2.12}$$

because  $G_n$  is semi-positive definite.

The modal approximation scheme is to choose the eigenvectors of the system as basis vectors. Here we will use the eigenvectors of the uncoupled thermoelastic system, i.e.,  $\gamma = 0$  in (7.2.3), and we still call it the modal approximation. Let

$$\phi_j = \sqrt{\frac{2}{\pi}} \frac{1}{j} \sin jx, \quad \psi_j = \sqrt{\frac{2}{\pi}} \sin jx, \quad \xi_j = \sqrt{\frac{2}{\pi}} \sin jx, \quad j = 1, \dots, n.$$
 (7.2.13)

A straight forward calculation following (7.2.8) and (7.2.11) yields that  $M_n = I$  and

$$A_{n} = \begin{bmatrix} 0 & D_{n} & 0 \\ -D_{n} & 0 & -\gamma F_{n} \\ 0 & \gamma F_{n}^{T}, & -D_{n}^{2} \end{bmatrix}$$
 (7.2.14)

with

$$D_{n} = \begin{bmatrix} 1 \\ \\ \\ \\ n \end{bmatrix}, \qquad F_{ij} = \begin{cases} -\frac{4}{\pi} \frac{ij}{i^{2} - j^{2}}, & |i - j| = odd \\ 0, & otherwise. \end{cases}$$
(7.2.15)

Notice that with the previous choice of basis in  $\mathcal{H}_n$ , (7.2.5) defines an isomorphism between  $\mathcal{H}_n$  and  $\mathbb{R}^{3n}$  which is equipped with the usual inner product. Let

$$\mathcal{A}_n = P_n \mathcal{A} P_n \tag{7.2.16}$$

which is an operator from  $\mathcal{H}_n$  to itself. Then (7.2.6) can be considered as an evolution equation in  $\mathcal{H}_n$ :

$$\frac{dz}{dt} = \mathcal{A}_n z. \tag{7.2.17}$$

Notice that for  $z_n \in \mathcal{H}_n$ , we have  $(\mathcal{A}_n z_n, z_n)_{\mathcal{H}_n} = (A_n \bar{y}_n, \bar{y}_n)_{\mathbb{R}^{3n}}$ .

**Theorem 7.2.1**  $A_n$  generates a  $C_0$ - semigroup of contractions on  $\mathcal{H}_n$ .

**Proof** To apply Theorem 1.2.4, we have to show that  $\mathcal{A}_n$  is dissipative and  $0 \in \rho(\mathcal{A}_n)$ . The dissipativeness of  $\mathcal{A}_n$  comes from the straight forward calculation

$$(\mathcal{A}_n z_n, z_n)_{\mathcal{H}_n} = (A_n \bar{y}_n, \bar{y}_n)_{\mathbb{R}^{3n}} = -\|D_n \tilde{z}_n^{(3)}\|^2 \le 0.$$
 (7.2.18)

Hereafter we also denote by  $\|\cdot\|$  the  $l^2$  norm in  $\mathbb{R}^n$  or  $\mathbb{C}^n$  when no confusion occurs. We now prove that  $0 \in \rho(\mathcal{A}_n)$ . For any  $F \in \mathcal{H}_n$ , by (7.2.5), we have  $f_n = (f_{1n}, f_{2n}, f_{3n})^T \in \mathbb{R}^{3n}$ , accordingly. It follows from the definition of  $A_n$  that  $\mathcal{A}_n z_n = F$  is equivalent to

$$A_n \bar{y}_n = f_n, \tag{7.2.19}$$

i.e.,

$$\begin{cases}
D_n \bar{z}_n^{(2)} = f_{1n}, \\
-D_n \bar{z}_n^{(1)} - \gamma F_n \bar{z}_n^{(3)} = f_{2n} \\
\gamma F_n^T \bar{z}_n^{(2)} - D_n^2 \bar{z}_n^{(3)} = f_{3n}.
\end{cases} (7.2.20)$$

Notice that  $D_n$  is invertible. Then it is easy to get

$$\begin{cases}
\bar{z}_{n}^{(1)} = -D_{n}^{-1}(f_{2n} - \gamma F_{n} D_{n}^{-2}(f_{3n} - \gamma F_{n}^{T} D_{n}^{-1} f_{1n})), \\
\bar{z}_{n}^{(2)} = D_{n}^{-1} f_{1n}, \\
\bar{z}_{n}^{(3)} = -D_{n}^{-2}(f_{3n} - \gamma F_{n}^{T} D_{n}^{-1} f_{1n}).
\end{cases} (7.2.21)$$

Thus, by Theorem 1.2.4, the proof is complete.

**Theorem 7.2.2** The semigroups  $S_n(t) = e^{A_n t}$ , generated by  $A_n$  which is defined in (7.2.16), are uniformly exponentially stable, i.e., there exist positive constants M and  $\alpha$ , independent of n, such that

$$||S_n(t)||_{\mathcal{L}(\mathcal{H}_n,\mathcal{H}_n)} \le Me^{-\alpha t}. \tag{7.2.22}$$

**Proof** By Theorem 7.1.3 we need only to prove that (7.1.44) and (7.1.45) hold.

(i) We first prove (7.1.44) by a contradiction argument. Since  $\mathcal{A}_n$  is an operator from finite-dimensional space  $\mathcal{H}_n$  into itself,  $\mathcal{A}_n$  is compact. Therefore, every point in the spectrum of  $\mathcal{A}_n$  must be an eigenvalue. If (7.1.44) is not true, then there must exist at least an  $m \in \mathbb{N}$  and  $\beta_m \in \mathbb{R}$  such that  $i\beta_m$  is an eigenvalue of  $\mathcal{A}_m$ . Since  $0 \in \rho(\mathcal{A}_n), \forall n \in \mathbb{N}$ , as proved before,  $\beta_m$  is not zero. Let  $z_m \in \mathcal{D}(\mathcal{A}_m)$  with  $\|z_m\|_{\mathcal{H}_m} = 1$  be the corresponding eigenvector. Then we have

$$(\mathbf{i}\beta_m I - \mathcal{A}_m)z_m = 0. (7.2.23)$$

Let  $y_m = (u_m, v_m, \theta_m) \in C^{3m}$  be the corresponding coordinate vector to  $z_m$ . Taking the real part of the inner product of (7.2.23) with  $z_m$  in  $\mathcal{H}_n$ , we obtain that

$$||D_m \theta_m||^2 = 0. (7.2.24)$$

Since  $D_m$  is invertible,  $\theta_m = 0$ . Notice that (7.2.23) is equivalent to

$$(\mathbf{i}\beta_m I - A_m)y_m = 0. (7.2.25)$$

Taking the first 2m rows of (7.2.25) into consideration, we have

$$(\mathbf{i}\beta_m I - A_0^{(m)}) \begin{pmatrix} u_m \\ v_m \end{pmatrix} = 0 \tag{7.2.26}$$

with

$$A_0^{(m)} = \begin{bmatrix} 0 & D_m \\ -D_m & 0 \end{bmatrix}. {(7.2.27)}$$

(7.2.25) implies that  $i\beta_m$  is an eigenvalue of  $A_0^{(m)}$ . It is clear that  $A_0^{(m)}$  has eigenvalues

$$\pm ij, \quad j = 1, \cdots, m, \tag{7.2.28}$$

and the corresponding eigenvectors

$$\mathcal{E}_{j} = \frac{1}{\sqrt{2}} \begin{pmatrix} e_{j} \\ ie_{j} \end{pmatrix}, \quad \mathcal{E}_{-j} = \frac{1}{\sqrt{2}} \begin{pmatrix} e_{j} \\ -ie_{j} \end{pmatrix}, \quad j = 1, \dots, m,$$
 (7.2.29)

with  $e_j$  being the standard  $j^{th}$  unit vector in  $\mathbb{R}^m$ . It turns out that there must be some integer  $j_m$ ,  $(-m \leq j_m \leq m)$  such that  $\beta_m = j_m$  and  $(u_m, v_m)^T = \mathcal{E}_{j_m}$ , i.e.,  $u_m = \frac{1}{\sqrt{2}} e_{|j_m|}$  and  $v_m = \frac{1}{\sqrt{2}} e_{|j_m|}$  or  $v_m = -\frac{1}{\sqrt{2}} e_{|j_m|}$ . Now taking the last m rows of (7.2.25) into consideration yields

$$F_m^T v_m = 0. (7.2.30)$$

Then a contradiction easily follows from the expression of  $F_m^T$  and  $v_m$ . Thus (7.1.44) is proved.

(ii) We now prove (7.1.45) by a contradiction argument. If (7.1.45) is false, then there must exist a subsequence of  $\mathcal{A}_n$ , still denoted by  $\mathcal{A}_n$ , a sequence of  $\beta_n \in \mathbb{R}$ , and a sequence of  $z_n \in \mathcal{H}_n$  with  $\|z_n\|_{\mathcal{H}_n} = 1$  such that as  $n \to +\infty$ ,

$$(i\beta_n I - \mathcal{A}_n)z_n \to 0$$
 in  $\mathcal{H}_n$ . (7.2.31)

Let  $y_n = (u_n, v_n, \theta_n) \in C^{3n}$  be the corresponding coordinate vector to  $z_n$ . Then (7.2.31) is equivalent to

$$\|(\mathbf{i}\beta_n I - A_n)y_n\|_{C^{3n}} \to 0.$$
 (7.2.32)

It follows from

$$Re((i\beta_n I - A_n)y_n, y_n)_{C^{3n}} \to 0$$
 (7.2.33)

that

$$||D_n \theta_n||^2 \to 0. (7.2.34)$$

Therefore, we have

$$\|\theta_n\| \le \|D_n\theta_n\| \to 0.$$
 (7.2.35)

Taking the first 2n rows of (7.2.32) into consideration yields

$$\left\| (\boldsymbol{i}\beta_n I - A_0^n) \begin{pmatrix} u_n \\ v_n \end{pmatrix} + \begin{pmatrix} 0 \\ \gamma F_n \theta_n \end{pmatrix} \right\|_{C^{2n}} \to 0 \tag{7.2.36}$$

where the matrix

$$A_0^n = \begin{bmatrix} 0 & D_n \\ -D_n & 0 \end{bmatrix}$$
 (7.2.37)

has eigenvalues

$$\pm ij, \quad j = 1, \cdots, n, \tag{7.2.38}$$

and the corresponding eigenvectors

$$\mathcal{E}_{j} = \frac{1}{\sqrt{2}} \begin{pmatrix} e_{j} \\ ie_{j} \end{pmatrix}, \quad \mathcal{E}_{-j} = \frac{1}{\sqrt{2}} \begin{pmatrix} e_{j} \\ -ie_{j} \end{pmatrix}, \quad j = 1, \dots, n$$
 (7.2.39)

with  $e_i$  being the standard  $j^{th}$  unit vector in  $\mathbb{R}^n$ .

We now claim that

$$||F_n\theta_n|| \to 0. \tag{7.2.40}$$

169

In fact,

$$(F_n \theta_n)_i = \frac{2}{\pi} \left( D \sin ix, \sum_{j=1}^n (\theta_n)_j \sin jx \right)_{L^2}$$
$$= -\frac{2}{\pi} \left( \sin ix, \sum_{j=1}^n j(\theta_n)_j \cos jx \right)_{L^2}$$
(7.2.41)

By Parsaval's inequality, we have

$$||F_n \theta_n||^2 \le \frac{2}{\pi} \left\| \sum_{j=1}^n j(\theta_n)_j \cos jx \right\|_{L^2}^2 \le \sum_{j=1}^n j^2 |(\theta_n)_j|^2 = ||D_n \theta_n||^2.$$
 (7.2.42)

Thus, (7.2.40) follows from (7.2.35). Moreover, we deduce from (7.2.36) that

$$\left\| (\boldsymbol{i}\beta_n I - A_0^n) \begin{pmatrix} u_n \\ v_n \end{pmatrix} \right\|_{C^{2n}} \to 0. \tag{7.2.43}$$

Since the eigenvectors  $\{\mathcal{E}_{\pm j}\}$  form a normalized basis in  $C^{2n}$ , we have

$$\begin{pmatrix} u_n \\ v_n \end{pmatrix} = \sum_{j=-n, j\neq 0}^n \alpha_{nj} \mathcal{E}_j. \tag{7.2.44}$$

It follows from  $||y_n||_{C^{3n}} = 1$  and  $||\theta_n|| \to 0$  that

$$\left\| \begin{pmatrix} u_n \\ v_n \end{pmatrix} \right\|_{C_2^{2n}}^2 = \sum_{j=-n, j \neq 0}^n |\alpha_{nj}|^2 \to 1.$$
 (7.2.45)

Substituting (7.2.44) into (7.2.43), we obtain

$$\left\| (i\beta_{n}I - A_{0}^{n}) \begin{pmatrix} u_{n} \\ v_{n} \end{pmatrix} \right\|_{C^{2n}}^{2} = \left\| \sum_{j=-n, j\neq 0}^{n} (i\beta_{n} - ij)\alpha_{nj}\mathcal{E}_{j} \right\|_{C^{2n}}^{2}$$

$$= \sum_{j=-n, j\neq 0}^{n} |\beta_{n} - j|^{2} |\alpha_{nj}|^{2} \to 0, \quad as \ n \to +\infty.$$
(7.2.46)

If for n large enough,  $|\beta_n - j| \ge \delta > 0$  for all j, then  $\sum_{j=-n,j\neq 0}^{n} |\alpha_{n,j}|^2 \to 0$ , a contradiction with (7.2.45). Thus, we derive from (7.2.45) and (7.2.46) that there exists  $j(n) \in \{\pm 1, \pm 2, \dots, \pm n\}$  such that as  $n \to +\infty$ ,

$$\begin{cases}
\beta_{n} - j(n) & \to 0, \\
\sum_{j=-n, j \neq 0, j(n)}^{n} |\alpha_{n,j}|^{2} & \to 0, \\
|\alpha_{n,j(n)}| & \to 1,
\end{cases}$$
(7.2.47)

and

$$\left\| \begin{pmatrix} u_n \\ v_n \end{pmatrix} - \alpha_{n,j(n)} \mathcal{E}_{j(n)} \right\|_{C^{2n}} \to 0.$$
 (7.2.48)

Taking the last n rows of (7.2.32) into consideration, we obtain that

$$\left\| \boldsymbol{i}\beta_{n}\theta_{n} + D_{n}^{2}\theta_{n} - \gamma F_{n}^{T}v_{n} \right\| \to 0. \tag{7.2.49}$$

By (7.2.47), (7.2.49), and  $j(n) \neq 0$ , if we denote  $\frac{1}{i(n)}\theta_n$  by  $x_n$ , then

$$\|g_n\| \stackrel{def}{=} \|ij(n)x_n + D_n^2 x_n - i\frac{\gamma \alpha_{n,j(n)}}{\sqrt{2}|j(n)|} F_n^T e_{|j(n)|} \| \to 0.$$
 (7.2.50)

Taking the real part of the inner product of  $g_n$  with  $D_n^2 y_n$  yields

$$Re\left(g_{n}, D_{n}^{2}x_{n}\right) = \left\|D_{n}^{2}x_{n}\right\|^{2} - Re\left(i\frac{\gamma\alpha_{n,j(n)}}{\sqrt{2}|j(n)|}F_{n}^{T}e_{|j(n)|}, D_{n}^{2}x_{n}\right)$$
(7.2.51)

We now estimate the last term on the right hand side of (7.2.51). Indeed,

$$Re\left(\frac{1}{|j(n)|}F_{n}^{T}e_{|j(n)|}, D_{n}^{2}x_{n}\right) = \frac{2}{\pi j(n)}Re\sum_{i=1}^{n}\int_{0}^{\pi}-(D\sin ix)\sin j(n)xdx \cdot \overline{i^{2}(x_{n})_{i}}$$

$$= \frac{2}{\pi}Re\sum_{i=1}^{n}i\int_{0}^{\pi}\sin ix\cos j(n)xdx \cdot \overline{i(x_{n})_{i}}$$

$$= -\frac{2}{\pi}Re\sum_{i=1}^{n}\int_{0}^{\pi}\cos ix\sin j(n)xdx \cdot \overline{i(\theta_{n})_{i}}$$

$$-\frac{2}{\pi}Re\sum_{i=1}^{n}(\cos ix\cos j(n)x)\Big|_{0}^{\pi} \cdot \frac{1}{j(n)}\overline{i(\theta_{n})_{i}}. (7.2.52)$$

Therefore,

$$I \equiv \left| Re \left( i \frac{\gamma \alpha_{n,j(n)}}{\sqrt{2}|j(n)|} F_n^T e_{|j(n)|}, D_n^2 x_n \right) \right|$$

$$\leq \frac{\gamma |\alpha_{n,j(n)}|}{\sqrt{\pi}} \left( \left\| \sin j(n) x \right\|_{L^2} \left\| D_n \theta_n \right\| + 2 \left\| Dh_n \right\|_{L^{\infty}} \right)$$

$$= \frac{\gamma |\alpha_{n,j(n)}|}{\sqrt{\pi}} \left( \frac{\pi}{2} \left\| D_n \theta_n \right\| + 2 \left\| Dh_n \right\|_{L^{\infty}} \right)$$

$$(7.2.53)$$

where

$$h_n = \sqrt{\frac{2}{\pi}} \sum_{i=1}^n (x_n)_i \sin ix.$$
 (7.2.54)

By the well-known Gagliardo-Nirenberg inequality, we have

$$||Dh_n||_{L^{\infty}} \leq C_1 ||D^2h_n||_{L^2}^{\frac{1}{2}} ||Dh_n||_{L^2}^{\frac{1}{2}} + C_2 ||Dh_n||_{L^2}$$

$$= C_1 ||D_n^2x_n||^{\frac{1}{2}} ||D_nx_n||^{\frac{1}{2}} + C_2 ||D_nx_n||$$
(7.2.55)

with  $C_1, C_2$  being positive constants independent of  $h_n$ .

Combining (7.2.53) with (7.2.55) and applying Young's inequality yields

$$I \leq \frac{\gamma |\alpha_{n,j(n)}|}{\sqrt{\pi}} \left( \frac{\pi}{2} \|D_n \theta_n\| + 2C_2 \|D_n x_n\| \right) + \frac{1}{4} \|D_n^2 x_n\|^2 + C_3 \|D_n x_n\|^{\frac{2}{3}}.$$
 (7.2.56)

On the other hand, we have

$$|Re(g_n, D_n^2 x_n)| \le \frac{1}{2} ||g_n||^2 + \frac{1}{2} ||D_n^2 x_n||^2.$$
 (7.2.57)

Thus, combining (7.2.56) and (7.2.57) with (7.2.51) and (7.2.35) yields

$$||D_n^2 x_n|| \to 0. (7.2.58)$$

Let  $w_n$  be the unique solution to the equation

$$ij(n)w_n + D_n^2 w_n - i \frac{\gamma \alpha_{n,j(n)}}{\sqrt{2|j(n)|}} F_n^T e_{|j(n)|} = 0.$$
 (7.2.59)

Then

$$(w_n)_i = \begin{cases} \frac{-sign(j(n))i2\sqrt{2}\gamma\alpha_{n,j(n)}i}{\pi(ij(n)+i^2)(i^2-j^2(n))}, & |i-j(n)| = odd, \\ 0, & otherwise. \end{cases}$$
(7.2.60)

From (7.2.50) and (7.2.59), we obtain that

$$\|\widetilde{g_n}\| \stackrel{def}{=} \|ij(n)(x_n - w_n) + D_n^2(x_n - w_n)\| \to 0.$$
 (7.2.61)

Taking the real part of the inner product of  $\widetilde{g_n}$  with  $D_n^2(x_n-w_n)$  yields

$$||D_n^2(x_n - w_n)|| \to 0.$$
 (7.2.62)

It immediately follows from (7.2.58) and (7.2.62) that

$$||D_n^2 w_n|| \to 0. (7.2.63)$$

Now we are ready to show a contradiction. Since  $|\alpha_{n,j(n)}| \to 1$ , as  $n \to \infty$ , we obtain for n large enough that

$$\begin{split} \left\| D_{n}^{2} w_{n} \right\|^{2} &= \sum_{i=1, |i-j(n)| = odd}^{n} \frac{8\gamma^{2} |\alpha_{n,j(n)}|^{2} i^{6}}{\pi^{2} (j^{2}(n) + i^{4}) (i^{2} - j^{2}(n))^{2}} \\ &\geq \begin{cases} \frac{2\gamma^{2} |\alpha_{n,j(n)}|^{2} (|j(n)| + 1)^{6}}{\pi^{2} ((|j(n)| + 1)^{4} + j^{2}(n)) (2|j(n)| + 1)^{2}}, & |j(n)| < n \\ \frac{2\gamma^{2} |\alpha_{n,j(n)}|^{2} (n - 1)^{6}}{\pi^{2} ((n - 1)^{4} + n^{2}) (2n - 1)^{2}}, & |j(n)| = n \end{cases} \\ &\geq \delta > 0 \end{split}$$
 (7.2.64)

with  $\delta$  being a constant independent of n, j(n). Thus, we have a contradiction and the proof of Theorem 7.2.2 is complete.

For the cases of the Dirichlet-Neumann and Neumann-Dirichlet boundary conditions, we can show that the corresponding  $C_0$ -semigroups obtained by the modal method are also uniformly exponentially stable. For example, if u satisfies the Dirichlet boundary condition and  $\theta$  satisfies the Neumann boundary condition, then  $\int_0^{\pi} \theta(x,t)dx = \int_0^{\pi} \theta_0(x)dx$  which is derived by integrating the second equation of (7.2.1) with respect to x and t, where  $\theta_0(x)$  is the initial temperature distribution of the rod.

Having changed to the new dependent variable

$$\bar{\theta} = \theta - \frac{1}{\pi} \int_0^{\pi} \theta_0(x) dx, \qquad (7.2.65)$$

we can choose the state space  $\mathcal{H}=\left\{(y_1,y_2,y_3)\in H_0\times L^2\times L^2\,|\,\int_0^\pi y_3dx\right\}$ , and choose  $\phi_j,\ \psi_j$  as before and  $\xi_j$  to be  $\sqrt{\frac{2}{\pi}}\cos jx$ . In this case, the matrix  $D_n$  is same as (7.2.15). Moreover, the Matrix  $F_n=-D_n$ . Therefore, the proof of  $\|D_n^2y_n\|\to 0$  and  $\|D_n^2w_n\|\to 0$  can be even more easily carried out. Accordingly, we have

$$(w_n)_i = \frac{-sign(j(n))\gamma\alpha_{n,j(n)}}{\sqrt{2}(i^2 + ij(n))}$$
(7.2.66)

and

$$\left\| D_n^2 w_n \right\|^2 \ = \ \sum_{i=1}^n \frac{\gamma^2 |\alpha_{n,j(n)}|^2 i^4}{2(i^4 + j^2(n))}$$

$$\geq \frac{\gamma^2 |\alpha_{n,j(n)}|^2 j^4(n)}{2(j^4(n) + j^2(n))} \geq \delta > 0. \tag{7.2.67}$$

Remark 7.2.1 In Theorem 2.2.1, we have used a simpler contradiction argument than that used here to show the exponential stability of the  $C_0$ -semigroup associated with the thermoelastic system (7.2.1) with the Dirichlet-Dirichlet boundary conditions (7.2.2). However, it seems difficult to apply the same argument to the finite-dimensional approximation of this problem. Although we still use a contradiction argument in the proof of Theorem 7.2.2, the proof becomes much more involved. If we have the equivalence between  $F_n^T v_n$  and  $D_n v_n$ , i.e.,

$$C_2 ||D_n v_n|| \le ||F_n^T v_n|| \le C_1 ||D_n v_n||,$$
 (7.2.68)

then the argument in the proof of Theorem 2.2.1 can also work here. In the case of the Direchlet-Neumann boundary conditions,  $F_n^T = -D_n$ . Thus, (7.2.68) holds and we can use the same argument as in Section 2.2 to obtain the uniform exponential stability for a sequence of  $C_0$ -semigroups associated with the modal approximation. However, in the case of the Dirichlet-Dirichlet boundary conditions, we are only able to get the second inequality in (7.2.68). This is not surprising because for different approximation schemes, we will have different structures of the matrix  $A_n$ . Even for some approximation schemes, the corresponding  $C_0$ -semigroups are not uniformly exponentially stable (refer to Liu & Zheng [2] for the detailed discussion of this aspect).

We now turn the discussion onto the convergence of our approximation scheme. Let  $P_n$  be the orthogonal projection from  $\mathcal{H}$  to  $\mathcal{H}_n$ . Then, as mentioned before, the matrix  $A_n$  in (7.2.14) is the matrix representation of the operator  $\mathcal{A}_n = P_n \mathcal{A} P_n$  where  $\mathcal{A}$  is defined in (7.2.3). Let

$$\mathcal{D} = \mathcal{D}(\mathcal{A}) \cap (H^4 \times H^3 \times H^4). \tag{7.2.69}$$

It is easy to see that  $\mathcal{D}$  is dense in  $\mathcal{H}$ . Since  $(I - \mathcal{A})\mathcal{D}(\mathcal{A}) = \mathcal{H}$ , we also know that  $(I - \mathcal{A})\mathcal{D}$  is dense in H. To show the strong convergence of the approximation semigroups  $T_n(t)$  to T(t), by the dissipativeness of  $\mathcal{A}$  and  $\mathcal{A}_n$  and the Trotter-Kato 174

theorem (see Pazy [1], p.88, Theorem 4.5), we only need to show  $\mathcal{A}_n z \longrightarrow \mathcal{A}z$  in H for all  $z \in \mathcal{D}$ .

**Theorem 7.2.3**  $T_n(t)$ ,  $(T_n(t))^* \xrightarrow{s} T(t)$ ,  $(T(t))^*$  in H, respectively. Moreover, the convergence is uniform in any bounded intervals of t.

**Proof** Let  $z \in \mathcal{D}$ . Then

$$z = \sum_{j=1}^{\infty} \left[ a_j \begin{pmatrix} \frac{1}{j} \sin jx \\ 0 \\ 0 \end{pmatrix} + b_j \begin{pmatrix} 0 \\ \sin jx \\ 0 \end{pmatrix} + c_j \begin{pmatrix} 0 \\ 0 \\ \sin jx \end{pmatrix} \right]$$
(7.2.70)

with  $\{a_jj^3, b_jj^3, c_jj^4\}_1^{\infty}$  being  $l^2$  sequences. Furthermore, we have

$$\mathcal{A}z = \begin{pmatrix} \sum_{i=1}^{\infty} b_i \sin ix \\ \sum_{i=1}^{\infty} (-a_i i - \gamma \sum_{j=1}^{\infty} c_j j f_{ij}) \sin ix \\ \sum_{i=1}^{\infty} (-\gamma \sum_{j=1}^{\infty} b_j j f_{ij} - c_i i^2) \sin ix \end{pmatrix}$$
(7.2.71)

and

$$\mathcal{A}_{n}z = \begin{pmatrix} \sum_{i=1}^{n} b_{i} \sin ix \\ \sum_{i=1}^{n} (-a_{i}i - \gamma \sum_{j=1}^{n} c_{j}jf_{ij}) \sin ix \\ \sum_{i=1}^{n} (-\gamma \sum_{j=1}^{n} b_{j}jf_{ij} - c_{i}i^{2}) \sin ix \end{pmatrix}$$
(7.2.72)

where  $f_{ij} = \sqrt{\frac{2}{\pi}} \langle \cos jx, \sin ix \rangle_{L^2}$ . Now  $Az - A_n z$  can be written as

$$\begin{pmatrix} \sum_{i=n+1}^{\infty} b_{i} \sin ix \\ \sum_{i=n+1}^{\infty} (-a_{i}i - \gamma \sum_{j=1}^{\infty} c_{j}jf_{ij}) \sin ix \\ \sum_{i=n+1}^{\infty} (-\gamma \sum_{j=1}^{\infty} b_{j}jf_{ij} - c_{i}i^{2}) \sin ix \end{pmatrix} - \begin{pmatrix} 0 \\ \gamma \sum_{i=1}^{n} (\sum_{j=n+1}^{\infty} c_{j}jf_{ij}) \sin ix \\ \gamma \sum_{i=1}^{n} (\sum_{j=n+1}^{\infty} b_{j}jf_{ij}) \sin ix \end{pmatrix} = I + II.$$

$$(7.2.73)$$

It follows from  $\mathcal{A}z\in H$  that  $\|I\|_H\to 0$ , as  $n\to\infty$ . The second entry of II can be

estimated as follows

$$\left\| \sum_{i=1}^{n} \left( \sum_{j=n+1}^{\infty} c_{j} j f_{ij} \right) \sin ix \right\|^{2}$$

$$= \frac{\pi}{2} \sum_{i=1}^{n} \left( \sum_{j=n+1}^{\infty} c_{j} j f_{ij} \right)^{2}$$

$$\leq \frac{\pi}{2} \sum_{i=1}^{n} \left( \sum_{j=n+1}^{\infty} |c_{j}|^{2\alpha} j^{2} \sum_{j=n+1}^{\infty} |c_{j}|^{2-2\alpha} |f_{ij}|^{2} \right)$$

$$\leq \frac{\pi}{2} \left( \sum_{j=n+1}^{\infty} |c_{j}|^{2\alpha} j^{2} \right) \left( \sum_{j=n+1}^{\infty} |c_{j}|^{2-2\alpha} \sum_{i=1}^{\infty} |f_{ij}|^{2} \right)$$

$$= \frac{\pi}{2} \left( \sum_{j=n+1}^{\infty} |c_{j}|^{2\alpha} j^{2} \right) \left( \sum_{j=n+1}^{\infty} |c_{j}|^{2-2\alpha} \right)$$

$$(7.2.74)$$

Since  $\sum_{j=n+1}^{\infty} |c_j|^2 j^6$  is a convergent series, then  $\sum_{j=1}^{\infty} |c_j|^{2\alpha} j^2$  and  $\sum_{j=n+1}^{\infty} |c_j|^{2-2\alpha}$  are also convergent as long as  $\frac{5}{6} > \alpha > \frac{1}{2}$ . Therefore, by (7.2.74), we obtain that

$$\left\| \sum_{i=1}^{n} \left( \sum_{j=n+1}^{\infty} c_j j f_{ij} \right) \sin ix \right\|^2 \longrightarrow 0.$$
 (7.2.75)

Similarly, we can get

$$\left\| \sum_{i=1}^{n} \left( \sum_{j=n+1}^{\infty} b_{j} j f_{ij} \right) \sin ix \right\| \longrightarrow 0.$$
 (7.2.76)

Thus, we have proved that

$$\lim_{n \to \infty} \|\mathcal{A}z - \mathcal{A}_n z\|_H = 0, \quad \forall z \in \mathcal{D}.$$
 (7.2.77)

The convergence of approximate adjoint semigroups can be verified in a similar way since  $\mathcal{A}$  and  $\mathcal{A}^*$  only differ from the sign in front of the coupling coefficient  $\gamma$  (see Hansen [1]).

Remark 7.2.2 For the cases of the Dirichlet-Neumann and Neumann-Dirichlet boundary conditions, the convergence of  $T_n(t)$  and  $T_n^*(t)$  is obvious from above analysis since there is no need to expand  $\cos jx$  in terms of  $\sin ix$  in (7.2.71) and (7.2.72).

Remark 7.2.3 There are some works in the literature on the uniform exponential stability for the approximation of certain elastic systems. We refer to Banks, Ito & Wang [1] for the result on the wave equation with boundary damping. We also refer to Fabiano [1] and [2] for the "equivalent norm" method to construct such approximations.

#### 7.3 Approximation of the Viscoelastic System

In this section, we study the uniformly exponentially stable approximation of the following linear viscoelastic system with memory on a finite history interval:

$$u_{tt}(t) + A\left[g(0)u(t) + \int_0^r g'(s)u(t-s)ds\right] = 0$$
 (7.3.1)

where A is a positive definite, self-adjoint unbounded operator on a separable Hilbert space H, and g(t) satisfies the following conditions:

(g1) 
$$g(s) \in C^2(0,r] \cap C[0,r], g'(s) \in L^1(0,r);$$

$$({\bf g2})\ g(s)>0, g'(s)<0,\ g''(s)>0\ {\bf on}\ (0,r);$$

(g3) 
$$g''(s) + \delta g'(s) \ge 0$$
 on  $(0, r)$  for some constant  $\delta > 0$ .

Without loss of generality, we can assume g(r) = 1. Notice that equation (7.3.1) is slightly different from equation (3.2.1) where the history interval is  $(0, \infty)$ . By taking a finite history interval (0, r), we can employ some approximation schemes proposed by Fabiano & Ito [1]. Under conditions (g1) and g(2), the convergence of these approximation schemes in the sense of (7.0.13) was proved in their paper mentioned previously. To our knowledge, such a convergent approximation scheme is not available in the literature when  $r = \infty$ . Our purpose in this section is to show the uniform exponential stability of the  $C_0$ -semigroups associated with these approximation schemes if condition (g3) is also satisfied.

The semigroup setting for equation (7.3.1) is exactly the same as in Section 3.2. Let  $V = \mathcal{D}(A^{\frac{1}{2}})$  with inner product

$$\langle u, v \rangle_V = \sigma(u, v) \triangleq \langle A^{\frac{1}{2}}u, A^{\frac{1}{2}}v \rangle_H, \quad \forall u, v \in V$$
 (7.3.2)

and  $W = L_{q'}^2(0, r; V)$  with the inner product

$$\langle w_1, w_2 \rangle_W = \int_0^\tau |g'(s)| \langle w_1, w_2 \rangle_V ds.$$
 (7.3.3)

Define

$$v = u_t, \quad w(t,s) = u(t) - u(t-s),$$
 (7.3.4)

for  $t > 0, s \in (0, r)$ . Let  $z = (u, v, w)^T$  and the Hilbert space  $\mathcal{H} = V \times H \times W$  equipped with the norm

$$||z||_{\mathcal{H}} = \left(||u||_{V}^{2} + ||v||_{H}^{2} + ||w||_{W}^{2}\right)^{\frac{1}{2}}.$$
 (7.3.5)

Then equation (7.3.1) can be reduced to the following abstract first-order evolution equation on  $\mathcal{H}$ 

$$\frac{dz(t)}{dt} = \mathcal{A}z(t) \tag{7.3.6}$$

where

$$Az = \begin{pmatrix} v \\ -A(u - \int_0^r g'(s)w(s) ds) \\ v - D_s w \end{pmatrix}$$
 (7.3.7)

with

$$\mathcal{D}(\mathcal{A}) = \left\{ z \in \mathcal{H} \middle| \begin{array}{l} u - \int_0^r g'(s)w(s) \, ds \in \mathcal{D}(A), \\ v \in V, D_s w \in W, w(0) = 0 \end{array} \right\}. \tag{7.3.8}$$

It is known (refer to Fabiano & Ito [1]) that under conditions (g1) and (g2)  $\mathcal{A}$  generates a  $C_0$ -semigroup S(t) of contractions on  $\mathcal{H}$ . Moreover, S(t) is exponentially stable if, in addition, condition (g3) is also satisfied (refer to Liu & Zheng [4]).

We now present the approximation scheme of equation (7.3.1) introduced in Fabiano & Ito [1]. Let  $V^N$  be a given sequence of finite-dimensional subspaces of V. Assume that for any  $u \in V$ , there exists a sequence  $u^N \in V^N$  such that

$$||u^N - u||_V \to 0, \quad \text{as } n \to \infty. \tag{7.3.9}$$

Define a continuous linear operator  $A^N: V^N \to V^N$  by

$$\langle A^N u, v \rangle_H = \sigma(u, v), \text{ for } u, v \in V^N.$$
 (7.3.10)

Thus, the spaces  $V^N$  complete the discretization of the spatial variable in the sense that they provide a sequence of finite-dimensional subspaces of V and H, and (7.3.10) gives an approximation of the operator A. This can often be realized by choosing a standard finite-element scheme. The two approximation schemes in the time variable for the resulting equation considered here are the averaging scheme (see Banks & Burns [1]) and a spline-based scheme (see Ito & Kappel [1]). They all involve discretization of the history interval [0,r) and approximation of the differential operator  $D_s$ .

Let M be a given integer. Then we obtain the discretization of [0,r) with mesh:  $s_i^M = ih, \ i = 0, \dots, M$  and  $h = \frac{r}{M}$ . Let  $B_i^M$ ,  $i = 1, \dots, M$  be the corresponding linear spline elements:

$$B_{i}^{M}(s) = \begin{cases} \frac{1}{h}(s - s_{i-1}^{M}), & \text{for } s_{i-1}^{M} \leq s \leq s_{i}^{M}, \\ \frac{1}{h}(s_{i+1}^{M} - s), & \text{for } s_{i}^{M} \leq s \leq s_{i+1}^{M}, & i = 1, \dots, M - 1, \\ 0, & \text{elsewhere,} \end{cases}$$
(7.3.11)

$$B_{M}^{M}(s) = \begin{cases} \frac{1}{h}(s - s_{M-1}^{M}), & \text{for } s_{M-1}^{M} \le s \le s_{M}^{M}, \\ 0, & \text{elsewhere.} \end{cases}$$
 (7.3.12)

We also denote the characteristic function on  $[s_{i-1}^M, s_i^M)$  by  $E_i^M$ ,  $i=1,\dots,M$ . For each positive integer N, M, define the subspaces of W by

$$\widetilde{W}^{N,M} = \left\{ w \in W \mid w = \sum_{i=1}^{M} b_i^M B_i^M, b_i^M \in V^N \right\},$$
 (7.3.13)

$$W^{N,M} = \left\{ w \in W \mid w = \sum_{i=1}^{M} a_i^M E_i^M, \ a_i^M \in V^N \right\}.$$
 (7.3.14)

In order to approximate the operator  $D_s$ , we consider a sesquilinear form  $a^{N,M}$  on  $\widetilde{W}^{N,M} \times W^{N,M}$ :

$$a^{N,M}(w^{N,M}, h^{N,M}) = \langle D_s w^{N,M}, h^{N,M} \rangle_W$$
 (7.3.15)

for  $w^{N,M} \in \widetilde{W}^{N,M}$  and  $h^{N,M} \in W^{N,M}$ . Since  $a^{N,M}$  is continuous, there exists a linear operator  $\widetilde{D}^{N,M} : \widetilde{W}^{N,M} \to W^{N,M}$  such that

$$a^{N,M}(w^{N,M}, h^{N,M}) = \langle \widetilde{D}^{N,M} w^{N,M}, h^{N,M} \rangle_{W}. \tag{7.3.16}$$

Notice that  $D_s\widetilde{W}^{N,M}=W^{N,M}$ . Hence, a simple calculation shows that  $\widetilde{D}^{N,M}$  is given by

$$\widetilde{D}^{N,M} w^{N,M} = \frac{1}{h} \sum_{i=1}^{M} (b_i^M - b_{i-1}^M) E_i^M$$
(7.3.17)

for  $w^{N,M} = \sum_{i=1}^{M} b_i^M B_i^M$ , where  $b_i^M \in V^N$ ,  $b_0^M = 0$ . Finally, we introduce the following isomorphisms from  $\widetilde{W}^{N,M}$  to  $W^{N,M}$ :

$$i_1^{N,M} w^{N,M} = \sum_{i=1}^M b_i^M E_i^M,$$
 (7.3.18)

$$i_2^{N,M} w^{N,M} = \sum_{i=1}^M \frac{b_{i-1}^M + b_i^M}{2} E_i^M.$$
 (7.3.19)

Thus, we obtain the approximations of  $D_s$  by defining operators  $D_k^{N,M}:W^{N,M}\to W^{N,M}$  by

$$D_k^{N,M} = \widetilde{D}^{N,M} (i_k^{N,M})^{-1}, \quad k = 1, 2.$$
 (7.3.20)

For  $w^{N,M} = \sum_{i=1}^{M} a_i^M E_i^M$ , we have

$$D_1^{N,M} w^{N,M} = \frac{1}{h} \sum_{i=1}^{M} (a_i^M - a_{i-1}^M) E_i^M, \tag{7.3.21}$$

$$D_2^{N,M} w^{N,M} = \frac{1}{h} \sum_{i=1}^{M} (b_i^M - b_{i-1}^M) E_i^M, \tag{7.3.22}$$

where  $\frac{b_i^M + b_{i-1}^M}{2} = a_i^M$ ,  $i = 1, 2, \dots, M$  and  $b_0^M = 0$ . Construction of two approximation schemes is now completed.

Let  $\mathcal{H}^{N,M} = V^N \times H^N \times W^{N,M}$  equipped with the norm induced from the norm in  $\mathcal{H}$ . We now have two approximation schemes of equation (7.3.6):

$$\frac{d}{dt}z^{N,M}(t) = \mathcal{A}_k^{N,M}z^{N,M}(t), \quad k = 1,2$$
 (7.3.23)

where  $z^{N,M}(t) = (u^N(t), v^N(t), w^{N,M}(t))^T$  and

$$\mathcal{A}_{k}^{N,M} z^{N,M} = \begin{pmatrix} v^{N} \\ -A^{N} \left( u^{N} - \int_{0}^{\tau} g'(s) w^{N,M}(s) ds \right) \\ v^{N} - D_{k}^{N,M} w^{N,M} \end{pmatrix}$$
 (7.3.24)

**Lemma 7.3.1**  $\mathcal{A}_k^{N,M}$  (k=1,2) is dissipative in  $\mathcal{H}^{N,M}$  and generates a  $C_0$ -semigroup of contractions on  $\mathcal{H}^{N,M}$ . Moreover, for  $z^{N,M} = (u^N, v^N, w^{N,M})^T \in \mathcal{H}^{N,M}$  with  $w^{N,M} = \sum_{i=1}^{M} a_i^M E_i^M$ ,

$$Re \langle \mathcal{A}_{1}^{N,M} z^{N,M}, z^{N,M} \rangle_{\mathcal{H}} = \frac{1}{2} \left( \sum_{i=1}^{M-1} \frac{1}{h} (g_{i}^{M} - g_{i+1}^{M}) \|a_{i}^{M}\|_{V}^{2} + \frac{1}{h} g_{M}^{M} \|a_{M}^{M}\|_{V}^{2} + \sum_{i=1}^{M} \frac{1}{h} g_{i}^{M} \|a_{i}^{M} - a_{i-1}^{M}\|_{V}^{2} \right),$$
(7.3.25)

and

$$Re \langle \mathcal{A}_{2}^{N,M} z^{N,M}, z^{N,M} \rangle_{\mathcal{H}} = \frac{1}{2} \left( \sum_{i=1}^{M-1} \frac{1}{h} (g_{i}^{M} - g_{i+1}^{M}) \|b_{i}^{M}\|_{V}^{2} + \frac{1}{h} g_{M}^{M} \|b_{M}^{M}\|_{V}^{2} \right)$$
(7.3.26)

where

$$a_i^M = (b_{i-1}^M + b_i^M)/2, \ g_i^M = \int_{s_i^M}^{s_i^M} g'(s)ds, \ i = 1, \dots, M, \ a_0^M = b_0^M = 0.$$
 (7.3.27)

**Proof** We first prove that  $\mathcal{A}_k^{N,M}$  (k=1,2) is dissipative in  $\mathcal{H}^{N,M}$ . By the conditions on g(s), we have

$$g_i^M \le g_{i+1}^M \le 0, \quad i = 1, \dots, M - 1.$$
 (7.3.28)

Thus,

$$Re \left\langle \mathcal{A}_{1}^{N,M} z^{N,M}, z^{N,M} \right\rangle_{\mathcal{H}}$$

$$= Re \left\{ \sigma(v^{N}, u^{N}) - \sigma(u^{N} - \int_{0}^{r} g'(s)w^{N,M}(s)ds, v^{N}) - \int_{0}^{r} g'(s) \left\langle v^{N} - D_{1}^{N,M} w^{N,M}, w^{N,M} \right\rangle_{V} ds \right\}$$

$$= Re \int_{0}^{r} g'(s) \left\langle \frac{1}{h} \sum_{i=1}^{M} (a_{i}^{M} - a_{i-1}^{M}) E_{i}^{M}, w^{N,M} \right\rangle_{V} ds$$

$$= \frac{1}{h} \sum_{i=1}^{M} Re \left\langle a_{i}^{M} - a_{i-1}^{M}, a_{i}^{M} \right\rangle_{V} g_{i}^{M}$$

$$= \frac{1}{2h} \sum_{i=1}^{M} g_{i}^{M} (\|a_{i}^{M}\|_{V}^{2} - \|a_{i-1}^{M}\|_{V}^{2} + \|a_{i}^{M} - a_{i-1}^{M}\|_{V}^{2})$$

$$= \frac{1}{2h} \sum_{i=1}^{M-1} (g_{i}^{M} - g_{i+1}^{M}) \|a_{i}^{M}\|_{V}^{2} + \frac{1}{2h} g_{M}^{M} \|a_{M}^{M}\|_{V}^{2} + \frac{1}{2h} \sum_{i=1}^{M} g_{i}^{M} \|a_{i}^{M} - a_{i-1}^{M}\|_{V}^{2}$$

$$\leq 0. \tag{7.3.29}$$

Similarly, we have

$$Re \left\langle \mathcal{A}_{2}^{N,M} z^{N,M}, z^{N,M} \right\rangle_{\mathcal{H}}$$

$$= Re \left\{ \sigma(v^{N}, u^{N}) - \sigma(u^{N} - \int_{0}^{r} g'(s) w^{N,M}(s) ds, v^{N}) - \int_{0}^{r} g'(s) \langle v^{N} - D_{2}^{N,M} w^{N,M}, w^{N,M} \rangle_{V} ds \right\}$$

$$= Re \int_{0}^{r} g'(s) \langle \frac{1}{h} \sum_{i=1}^{M} (b_{i}^{M} - b_{i-1}^{M}) E_{i}^{M}, w^{N,M} \rangle_{V} ds$$

$$= \frac{1}{2h} \sum_{i=1}^{M} Re \langle b_{i}^{M} - b_{i-1}^{M}, b_{i}^{M} + b_{i-1}^{M} \rangle_{V} g_{i}^{M}$$

$$= \frac{1}{2h} \sum_{i=1}^{M} g_{i}^{M} (\|b_{i}^{M}\|_{V}^{2} - \|b_{i-1}^{M}\|_{V}^{2})$$

$$= \frac{1}{2h} \sum_{i=1}^{M-1} (g_{i}^{M} - g_{i+1}^{M}) \|b_{i}^{M}\|_{V}^{2} + \frac{1}{2h} g_{M}^{M} \|b_{M}^{M}\|_{V}^{2}$$

$$\leq 0. \tag{7.3.30}$$

Thus, to prove that  $\mathcal{A}_k^{N,M}$  (k=1,2) generates a  $C_0$ -semigroup,  $S_k^{N,M}$ , of contractions on  $\mathcal{H}^{N,M}$ , by Theorem 1.2.4 in Chapter 1, it suffices to prove that  $0 \in \rho(\mathcal{A}_k^{N,M})$  (k=1,2). For any  $F = (f_1, f_2, f_3)^T \in \mathcal{H}^{N,M}$ , consider the equations  $\mathcal{A}_k^{N,M} z^{N,M} = F$ , i.e.,

$$v^N = f_1, (7.3.31)$$

$$-A^{N}(u^{N} - \int_{0}^{\tau} g'(s)w^{N,M}(s)ds) = f_{2}, \tag{7.3.32}$$

$$v^N - D_k^{N,M} w^{N,M} = f_3. (7.3.33)$$

It follows from (7.3.31) and (7.3.33) that

$$D_k^{N,M} w^{N,M} = f_1 - f_3. (7.3.34)$$

By induction, we can obtain  $a_i^M$ ,  $(i=1,\cdots,M)$ , thus a unique  $w^{N,M}$  in case k=1. In case k=2, by induction we can obtain  $b_i^M$ ,  $(i=1,\cdots,M)$ , thus  $a_i^M$ ,  $(i=1,\cdot,M)$  and a unique  $w^{N,M}$ . Substituting  $w^{N,M}$  just obtained into (7.3.32), we can obtain a unique  $u^N$  by the assumption that A is a positive definite and self-adjoint operator and  $A^N$  is its restriction to  $V^N$ . Thus, it is clear from the above that  $0 \in \rho(\mathcal{A}_k^{N,M})$  (k=1,2) and the proof is complete.

In what follows we will show that  $S_k^{N,M}(t)$  are uniformly exponentially stable.

**Theorem 7.3.1** If the kernel g(s) satisfies conditions (g1)–(g3), then the  $C_0$ -semigroup  $S_k^{N,M}(t)$  generated by the operator  $\mathcal{A}_k^{N,M}$  defined in (7.3.20), is uniformly exponentially stable, for k = 1, 2.

**Proof** It suffices to verify conditions (7.1.44) and (7.1.45) of Theorem 7.1.3 for the cases of k = 1, 2, respectively.

#### Case 1 (k = 1 Averaging Scheme):

(i) Suppose (7.1.44) is not true. Then there is an  $\mathcal{A}_1^{N,M}$  and an  $\omega \in \mathbb{R}$  such that  $i\omega$  is an eigenvalue of  $\mathcal{A}_1^{N,M}$ . This implies that there exist a  $z^{N,M} = (u^N, v^N, w^{N,M})^T \in \mathcal{D}(\mathcal{A}_1^{N,M})$  with  $\|z^{N,M}\|_{\mathcal{H}^{N,M}} = 1$  such that

$$\left(i\omega I - \mathcal{A}_1^{N,M}\right)z^{N,M} = 0 \quad \text{in } \mathcal{H},$$
 (7.3.35)

i.e.,

$$i\omega u^N - v^N = 0 \quad \text{in } V, \tag{7.3.36}$$

$$i\omega v^N + A^N(u^N - \int_0^\tau g'(s)w^{N,M}(s)ds) = 0$$
 in  $H$ , (7.3.37)

$$i\omega w^{N,M}(s) - v^N + D_1^{N,M} w^{N,M}(s) = 0$$
 in  $W$ . (7.3.38)

Taking the real part of the inner product of (7.3.35) with  $z^{N,M}$  yields

$$\begin{split} ℜ\,\langle(\pmb{i}\,\beta^{N,M}I-\mathcal{A}_{1}^{N,M})z^{N,M},z^{N,M}\rangle_{\mathcal{H}}\\ &=\;\;-Re\,\langle\mathcal{A}_{1}^{N,M}z^{N,M},z^{N,M}\rangle_{\mathcal{H}}\\ &=\;\;-\frac{1}{2}\left(\sum_{i=1}^{M-1}\frac{1}{h}(g_{i}^{M}-g_{i+1}^{M})\|a_{i}^{M}\|_{V}^{2}+\frac{1}{h}g_{M}^{M}\|a_{M}^{M}\|_{V}^{2}+\sum_{i=1}^{M}\frac{1}{h}g_{i}^{M}\|a_{i}^{M}-a_{i-1}^{M}\|_{V}^{2}\right)\\ &=\;\;0. \end{split} \tag{7.3.39}$$

All terms in (7.3.39) are non-negative. Thus,

$$\sum_{i=1}^{M-1} \frac{1}{h} (g_{i+1}^M - g_i^M) \|a_i^M\|_V^2 = 0, \tag{7.3.40}$$

$$\frac{1}{h}g_M^M \|a_M^M\|_V^2 = 0, (7.3.41)$$

$$\sum_{i=1}^{M} \frac{1}{h} g_i^M \|a_i^M - a_{i-1}^M\|_V^2 = 0. {(7.3.42)}$$

Then, by the condition on g, we immediately get

$$||w^{N,M}||_W^2 = -\sum_{i=1}^M g_i^M ||a_i^M||_V^2 = 0.$$
 (7.3.43)

It follows from (7.3.38) that  $v^N = 0$ . Since  $0 \in \rho(\mathcal{A}_1^{N,M})$ , we deduce from (7.3.36) that  $u^N = 0$ , a contradiction.

(ii) Suppose (7.1.45) is not true. Then there exist a subsequence of  $\mathcal{A}_1^{N,M}$ , still denoted by  $\mathcal{A}_1^{N,M}$ , a sequence of  $\beta^{N,M} \in \mathbb{R}$  and a sequence of  $z^{N,M} = (u^N, v^N, w^{N,M}) \in \mathcal{D}(\mathcal{A}_1^{N,M})$  with  $\|z^{N,M}\|_{\mathcal{H}} = 1$  such that

$$\lim_{N,M\to\infty} \|(i\beta^{N,M}I - \mathcal{A}_1^{N,M})z^{N,M}\|_{\mathcal{H}} = 0, \tag{7.3.44}$$

i.e.,

$$i\beta^{N,M}u^N - v^N \rightarrow 0 \quad \text{in } V, \tag{7.3.45}$$

$$i\beta^{N,M}v^N + A^N(u^N - \int_0^\tau g'(s)w^{N,M}(s)ds) \to 0 \text{ in } H,$$
 (7.3.46)

$$i\beta^{N,M}w^{N,M}(s) - v^N + D_1^{N,M}w^{N,M}(s) \rightarrow 0 \text{ in } W.$$
 (7.3.47)

It follows from Lemma 7.3.1 and (7.3.44) that

$$\begin{split} ℜ\,\langle(\pmb{i}\beta^{N,M}I-\mathcal{A}_{1}^{N,M})z^{N,M},z^{N,M}\rangle_{\mathcal{H}}\\ &=\;\;-Re\,\langle\mathcal{A}_{1}^{N,M}z^{N,M},z^{N,M}\rangle_{\mathcal{H}}\\ &=\;\;-\frac{1}{2}\left(\sum_{i=1}^{M-1}\frac{1}{h}(g_{i}^{M}-g_{i+1}^{M})\|a_{i}^{M}\|_{V}^{2}+\frac{1}{h}g_{M}^{M}\|a_{M}^{M}\|_{V}^{2}+\sum_{i=1}^{M}\frac{1}{h}g_{i}^{M}\|a_{i}^{M}-a_{i-1}^{M}\|_{V}^{2}\right)\\ &\to\;\;0. \end{split} \tag{7.3.48}$$

All terms in (7.3.48) are non-negative. Thus, we have

$$\sum_{i=1}^{M-1} \frac{1}{h} (g_{i+1}^M - g_i^M) \|a_i^M\|_V^2 \to 0, \tag{7.3.49}$$

$$\frac{1}{h}g_M^M \|a_M^M\|_V^2 \to 0, (7.3.50)$$

$$\sum_{i=1}^{M} \frac{1}{h} g_i^M \|a_i^M - a_{i-1}^M\|_V^2 \to 0.$$
 (7.3.51)

Next, we show that (7.3.49) and (7.3.50) imply that

$$||w^{N,M}||_W^2 = -\sum_{i=1}^M g_i^M ||a_i^M||_V^2 \to 0.$$
 (7.3.52)

Since

$$\frac{(g_{i+1}^{M} - g_{i}^{M})}{h} = \int_{s_{i}^{M}}^{s_{i+1}^{M}} \frac{g'(s) - g'(s - h)}{h} ds$$

$$= \int_{s_{i}^{M}}^{s_{i+1}^{M}} g''(\xi) ds \qquad (s - h \le \xi \le s)$$

$$\ge - \int_{s_{i}^{M}}^{s_{i+1}^{M}} \delta g'(\xi) ds \qquad (\text{by } (g3))$$

$$\ge -\delta \int_{s_{i}^{M}}^{s_{i+1}^{M}} g'(s) ds = -\delta g_{i+1}^{M}, \qquad (7.3.53)$$

and

$$-\sum_{i=1}^{M} g_{i}^{M} \|a_{i}^{M}\|_{V}^{2} = \sum_{i=1}^{M-1} (g_{i+1}^{M} - g_{i}^{M}) \|a_{i}^{M}\|_{V}^{2} - \sum_{i=1}^{M-1} g_{i+1}^{M} \|a_{i}^{M}\|_{V}^{2} - g_{M}^{M} \|a_{M}^{M}\|_{V}^{2}, \quad (7.3.54)$$

we can see that (7.3.52) is an immediate result of (7.3.49) and (7.3.50). Therefore, it follows from  $||z^{N,M}||_{\mathcal{H}} = 1$  that

$$||u^N||_V^2 + ||v^N||_H^2 \to 1.$$
 (7.3.55)

By (7.3.45) and the continuous injection of V into H,  $i\beta^{N,M}u^N - v^N$  also converges to zero in H. Thus, we have

$$i\beta^{N,M}\langle u^N, v^N \rangle_H - \|v^N\|_H^2 \to 0.$$
 (7.3.56)

Taking the inner product of (7.3.46) with  $u^N$  in H, we have

$$i\beta^{N,M}\langle v^N, u^N \rangle_H + \sigma(u^N - \int_0^\tau g'(s)w^{N,M}(s)ds, \ u^N)$$

$$= i\beta^{N,M}\langle v^N, u^N \rangle_H + \|u^N\|_V^2 - \int_0^\tau g'(s)\langle w^{N,M}(s), u^N \rangle_V ds \to 0. \tag{7.3.57}$$

By (7.3.52) and the following estimate

$$\left| \int_{0}^{\tau} -g'(s) \langle w^{N,M}(s), u^{N} \rangle_{V} ds \right| \leq \|u^{N}\|_{V} \int_{0}^{\tau} -g'(s) \|w^{N,M}(s)\|_{V} ds$$

$$\leq \|u^{N}\|_{V} \left( \int_{0}^{\tau} -g'(s) ds \right)^{\frac{1}{2}} \|w^{N,M}\|_{W}, (7.3.58)$$

the third term in (7.3.57) converges to zero. Adding the complex conjugate of (7.3.57) to (7.3.56) yields

$$||u^N||_V^2 - ||v^N||_H^2 \to 0.$$
 (7.3.59)

Therefore, it follows from (7.3.56) abd (7.3.59) that

$$||u^N||_V^2 \to \frac{1}{2}, \quad ||v^N||_H^2 \to \frac{1}{2}.$$
 (7.3.60)

Now we claim that  $|\beta^{N,M}|$  is bounded below by a positive constant for N,M large enough. Otherwise, there is a subsequence of  $\beta^{N,M}$ , still denoted by  $\beta^{N,M}$ , such that  $\lim_{N,M\to\infty}\beta^{N,M}=0$ . Combining this with (7.3.45) implies that  $||v^N||_H\to 0$ . Thus, we have a contradiction to (7.3.60).

Therefore, we can divide equation (7.3.45) by  $\beta^{N,M}$  to obtain

$$\left\| \frac{v^N}{\beta^{N,M}} \right\|_V^2 \to \frac{1}{2}. \tag{7.3.61}$$

The rest of the proof is to show that (7.3.61) is a contradiction. We rewrite (7.3.47) as

$$-\frac{v^{N}}{\beta^{N,M}} + \frac{1}{\beta^{N,M}} D_{1}^{N,M} w^{N,M}(s) \to 0 \quad in \quad W, \tag{7.3.62}$$

then take the inner product with  $\frac{sv^N}{\beta^{N,M}} \in W$  in W to obtain that

$$\left\|\frac{v^N}{\beta^{N,M}}\right\|_V^2 \int_0^r sg'(s)ds - \frac{1}{\beta^{N,M}} \int_0^r sg'(s) \langle D_1^{N,M} w^{N,M}(s), \frac{v^N}{\beta^{N,M}} \rangle_V ds \to 0.$$
 (7.3.63)

In what follows, we will show that the second term in (7.3.63) converges to zero. Therefore, the first term in (7.3.63) must converge to zero, which gives the desired contradiction. In doing so, we first get the following estimate:

$$\left| \int_{0}^{r} sg'(s) \langle D_{1}^{N,M} w^{N,M}, \frac{v^{N}}{\beta^{N,M}} \rangle_{V} ds \right| 
= \left| \sum_{i=1}^{M-1} \frac{(sg)_{i+1}^{M} - (sg)_{i}^{M}}{h} \langle a_{i}^{M}, \frac{v^{N}}{\beta^{N,M}} \rangle_{V} - \frac{(sg)_{M}^{M}}{h} \langle a_{M}^{M}, \frac{v^{N}}{\beta^{N,M}} \rangle_{V} \right| 
\leq \left\| \frac{v^{N}}{\beta^{N,M}} \right\|_{V} \left( \sum_{i=1}^{M-1} \left| \frac{(sg)_{i+1}^{M} - (sg)_{i}^{M}}{h} \right| \|a_{i}^{M}\|_{V} - \frac{(sg)_{M}^{M}}{h} \|a_{M}^{M}\|_{V} \right), \quad (7.3.64)$$

where  $(sg)_i^M = \int_{s_i^M}^{s_i^M} sg'(s)ds$  for  $i = 1, \dots, M$ . A simple calculation also leads to

$$\sum_{i=1}^{M-1} \left| \frac{(sg)_{i+1}^{M} - (sg)_{i}^{M}}{h} \right| \|a_{i}^{M}\|_{V}$$

$$= \sum_{i=1}^{M-1} \left| \int_{s_{i}^{M}}^{s_{i+1}^{M}} s \frac{g'(s) - g'(s-h)}{h} ds + \int_{s_{i}^{M}}^{s_{i+1}^{M}} g'(s-h) ds \right| \|a_{i}^{M}\|_{V}$$

$$\leq \int_{h}^{r} s \frac{g'(s) - g'(s-h)}{h} \sum_{i=1}^{M-1} \|a_{i}^{M}\|_{V} E_{i}^{M} ds + \sum_{i=1}^{M-1} |g_{i}^{M}| \|a_{i}^{M}\|_{V}$$

$$\leq \left( \int_{h}^{r} s^{2} \frac{g'(s) - g'(s-h)}{h} ds \right)^{\frac{1}{2}} \left( \sum_{i=1}^{M-1} \frac{1}{h} (g_{i+1}^{M} - g_{i}^{M}) \|a_{i}^{M}\|_{V}^{2} \right)^{\frac{1}{2}} + \|w^{N,M}\|_{W}$$

$$\leq K \left( \frac{1}{h} \sum_{i=1}^{M-1} (g_{i+1}^{M} - g_{i}^{M}) \|a_{i}^{M}\|_{V}^{2} \right)^{\frac{1}{2}} + \|w^{N,M}\|_{W} \to 0 \tag{7.3.65}$$

for some constant K > 0. Here we have used (7.3.49), (7.3.52), and the fact that  $s^2g''(s) \in L^1(0,r)$ . Using the Cauchy-Schwarz inequality and (7.3.50), we also have

$$\left| \frac{(sg)_{M}^{M}}{h} \|a_{M}^{M}\|_{V} \right| \\
\leq \left( \int_{r-h}^{\tau} \frac{-s^{2}g'(s)}{h} ds \right)^{\frac{1}{2}} \left( \frac{1}{h} g_{M}^{M} \|a_{M}^{M}\|_{V}^{2} \right)^{\frac{1}{2}} \\
\leq K \left( \frac{1}{h} g_{M}^{M} \|a_{M}^{M}\|_{V}^{2} \right)^{\frac{1}{2}} \to 0.$$
(7.3.66)

Finally, we substitute (7.3.65) and (7.3.66) into (7.3.64) to obtain the desired result. Thus the proof for Case 1 (k = 1) is complete.

#### Case 2 (k = 2, Spline-based scheme):

The proof is very similar to that for Case 1. Therefore, we will only point out the main differences and omit the redundant argument.

- (i) Suppose (7.1.44) is false. Then a similar proof to part (i) of Case 1 also works here. Therefore, we can focus our attention to the proof of part (ii).
- (ii) Suppose (7.1.45) is false. Then there exist a subsequence of  $\mathcal{A}_2^{N,M}$ , still denoted by  $\mathcal{A}_2^{N,M}$ , a sequence of  $\beta^{N,M} \in \mathbb{R}$  and a sequence of  $z^{N,M} = (u^N, v^N, w^{N,M}) \in \mathcal{D}(\mathcal{A}_2^{N,M})$  with  $\|z^{N,M}\|_{\mathcal{H}} = 1$  such that

$$\lim_{NM\to\infty} \|(i\beta^{N,M}I - \mathcal{A}_2^{N,M})z^{N,M}\|_{\mathcal{H}} = 0, \tag{7.3.67}$$

$$i\beta^{N,M}u^N - v^N \rightarrow 0 \quad \text{in } V, \tag{7.3.68}$$

$$i\beta^{N,M}v^N + A^N(u^N - \int_0^r g'(s)w^{N,M}(s)ds) \to 0 \text{ in } H,$$
 (7.3.69)

$$i\beta^{N,M}w^{N,M}(s) - v^N + D_2^{N,M}w^{N,M}(s) \rightarrow 0 \text{ in } W.$$
 (7.3.70)

It follows from Lemma 7.3.1 and (7.3.67) that

$$Re \langle (i\beta^{N,M}I - A_{2}^{N,M})z^{N,M}, z^{N,M} \rangle_{\mathcal{H}}$$

$$= -Re \langle A_{2}^{N,M}z^{N,M}, z^{N,M} \rangle_{\mathcal{H}}$$

$$= \frac{1}{2} \left( \sum_{i=1}^{M-1} \frac{1}{h} (g_{i}^{M} - g_{i+1}^{M}) \|b_{i}^{M}\|_{V}^{2} + \frac{1}{h} g_{M}^{M} \|b_{M}^{M}\|_{V}^{2} \right)$$

$$\to 0.$$
(7.3.71)

Therefore,

$$\sum_{i=1}^{M-1} \frac{1}{h} (g_{i+1}^M - g_i^M) \|b_i^M\|_V^2 \to 0, \tag{7.3.72}$$

$$\frac{1}{h}g_M^M ||b_M^M||_V^2 \to 0. (7.3.73)$$

Since 
$$a_i^M = \frac{b_{i-1}^M + b_i^M}{2}, b_0^M = 0$$
, and  $g_i^M = \int_{s_{i-1}^M}^{s_i^M} g'(s) ds$ , we obtain

$$\begin{split} \|w^{N,M}\|_{W}^{2} &= -\sum_{i=1}^{M} g_{i}^{M} \|a_{i}^{M}\|_{V}^{2} \\ &\leq -\frac{1}{2} \sum_{i=1}^{M} g_{i}^{M} \left( \|b_{i-1}^{M}\|_{V}^{2} + \|b_{i}^{M}\|_{V}^{2} \right) \\ &= -\frac{1}{2} \sum_{i=1}^{M-1} g_{i+1}^{M} \|b_{i}^{M}\|_{V}^{2} - \frac{1}{2} \sum_{i=1}^{M-1} g_{i}^{M} \|b_{i}^{M}\|_{V}^{2} - \frac{1}{2} g_{M}^{M} \|b_{M}^{M}\|_{V}^{2} \\ &= -\sum_{i=1}^{M-1} g_{i+1}^{M} \|b_{i}^{M}\|_{V}^{2} + \frac{1}{2} \sum_{i=1}^{M-1} (g_{i+1}^{M} - g_{i}^{M}) \|b_{i}^{M}\|_{V}^{2} - \frac{1}{2} g_{M}^{M} \|b_{M}^{M}\|_{V}^{2} \\ &\leq \frac{1}{\delta h} \sum_{i=1}^{M-1} (g_{i+1}^{M} - g_{i}^{M}) \|b_{i}^{M}\|_{V}^{2} + \frac{1}{2} \sum_{i=1}^{M-1} (g_{i+1}^{M} - g_{i}^{M}) \|b_{i}^{M}\|_{V}^{2} \\ &- \frac{1}{2} g_{M}^{M} \|b_{M}^{M}\|_{V}^{2}, \end{split} \tag{7.3.74}$$

where we have used (7.3.53). Combining (7.3.72)-(7.3.74) yields

$$||w^{N,M}||_W^2 \to 0, \tag{7.3.75}$$

and

$$\sum_{i=1}^{M-1} g_i^M \|b_i^M\|_V^2 \to 0. \tag{7.3.76}$$

We now repeat the argument from (7.3.55)-(7.3.60) to get

$$||u^N||_V^2 \to \frac{1}{2}, \quad ||v^N||_H^2 \to \frac{1}{2}.$$
 (7.3.77)

In the same manner as before,  $|\beta^{N,M}|$  is bounded from below by a positive constant for N, M large enough. Therefore, we can divide equation (7.3.68) by  $\beta^{N,M}$  to obtain that

$$\left\| \frac{v^N}{\beta^{N,M}} \right\|_V^2 \to \frac{1}{2}.\tag{7.3.78}$$

The rest of the proof is to show that (7.3.78) leads to a contradiction. We first rewrite (7.3.70) as

$$-\frac{v^N}{\beta^{N,M}} + \frac{1}{\beta^{N,M}} D_2^{N,M} w^{N,M}(s) \to 0 \quad in \quad W.$$
 (7.3.79)

Then, we take the inner product of (7.3.79) with  $\frac{sv^N}{\beta N,M} \in W$  in W to obtain

$$\left\| \frac{v^{N}}{\beta^{N,M}} \right\|_{V}^{2} \int_{0}^{r} sg'(s)ds - \frac{1}{\beta^{N,M}} \int_{0}^{r} sg'(s) \langle D_{2}^{N,M} w^{N,M}(s), \frac{v^{N}}{\beta^{N,M}} \rangle_{V} ds \to 0.$$
 (7.3.80)

To obtain a contradiction to (7.3.78), it suffices to prove that the second term in (7.3.80) converges to zero. This can be proved as follows:

A simple calculation yields

$$\begin{split} & \left| -\int_{0}^{r} sg'(s) \langle D_{2}^{N,M} w^{N,M}, \frac{v^{N}}{\beta^{N,M}} \rangle_{V} ds \right| \\ & = \left| -\int_{0}^{r} sg'(s) \langle \frac{1}{h} \sum_{i=1}^{M} (b_{i}^{M} - b_{i-1}^{M}) E_{i}^{M}, \frac{v^{N}}{\beta^{N,M}} \rangle_{V} ds \right| \\ & = \left| \sum_{i=1}^{M-1} \frac{(sg)_{i+1}^{M} - (sg)_{i}^{M}}{h} \langle b_{i}^{M}, \frac{v^{N}}{\beta^{N,M}} \rangle_{V} - \frac{(sg)_{M}^{M}}{h} \langle b_{M}^{M}, \frac{v^{N}}{\beta^{N,M}} \rangle_{V} \right| \\ & \leq \left\| \frac{v^{N}}{\beta^{N,M}} \right\|_{V} \left( \sum_{i=1}^{M-1} \left| \frac{(sg)_{i+1}^{M} - (sg)_{i}^{M}}{h} \right| \|b_{i}^{M}\|_{V} - \frac{(sg)_{M}^{M}}{h} \|b_{M}^{M}\|_{V} \right), \quad (7.3.81) \end{split}$$

where  $(sg)_i^M = \int_{s_i^M}^{s_i^M} sg'(s)ds$  for  $i = 1, \dots, M$ .

By (7.3.72) and (7.3.76), we have

$$\begin{split} &\sum_{i=1}^{M-1} \left| \frac{(sg)_{i+1}^{M} - (sg)_{i}^{M}}{h} \right| \|b_{i}^{M}\|_{V} \\ &= \sum_{i=1}^{M-1} \left| \int_{s_{i}^{M}}^{s_{i+1}^{M}} s \frac{g'(s) - g'(s-h)}{h} \, ds + \int_{s_{i}^{M}}^{s_{i+1}^{M}} g'(s-h) \, ds \right| \|b_{i}^{M}\|_{V} \\ &\leq \sum_{i=1}^{M-1} \int_{h}^{r} s \frac{g'(s) - g'(s-h)}{h} \|b_{i}^{M}\|_{V} E_{i+1}^{M} ds + \sum_{i=1}^{M-1} |g_{i}^{M}| \|b_{i}^{M}\|_{V} \\ &\leq \left( \int_{h}^{r} s^{2} \frac{g'(s) - g'(s-h)}{h} \, ds \right)^{\frac{1}{2}} \left( \sum_{i=1}^{M-1} \frac{1}{h} (g_{i+1}^{M} - g_{i}^{M}) \|b_{i}^{M}\|_{V}^{2} \right)^{\frac{1}{2}} - \sum_{i=1}^{M} g_{i}^{M} \|b_{i}^{M}\|_{V}^{2} \\ &\leq K \left( \frac{1}{h} \sum_{i=1}^{M-1} (g_{i+1}^{M} - g_{i}^{M}) \|b_{i}^{M}\|_{V}^{2} \right)^{\frac{1}{2}} - \sum_{i=1}^{M} g_{i}^{M} \|b_{i}^{M}\|_{V}^{2} \to 0 \end{split} \tag{7.3.82}$$

for some constant K > 0.

On the other hand, by (7.3.73), we get

$$\left| \frac{(sg)_{M}^{M}}{h} \|b_{M}^{M}\|_{V} \right| \\
\leq \left( \int_{r-h}^{r} -\frac{s^{2}g'(s)}{h} ds \right)^{\frac{1}{2}} \left( \frac{1}{h} g_{M}^{M} \|b_{M}^{M}\|_{V}^{2} \right)^{\frac{1}{2}} \\
\leq K \left( \frac{1}{h} g_{M}^{M} \|b_{M}^{M}\|_{V}^{2} \right)^{\frac{1}{2}} \to 0$$
(7.3.83)

for some constant K > 0. Therefore, we have a contradiction to (7.3.78). The proof is complete.

#### **Bibliography**

#### R.A. Adams

[1] Sobolev Spaces, Academic Press, New York, 1975.

#### G.Avalos and I. Lasiecka

- [1] Exponential stability of thermoelastic system without mechanical dissipation, Rend. Istit. Mat. Univ. Trieste Suppl., Vol. XXVIII(1997), 1-28.
- [2] Exponential stability of a thermoelastic system with free boundary conditions without mechanical dissipation SIAM J. Math. Anal., Vol. 29, No.1 (1998), 155-182.

#### A.V. Balakrishnan

[1] Applied Functional Analysis, Second Edition, Springer-Verlag, New York, 1981.

#### H.T. Banks and J.A. Burns

[1] Hereditary control problems: numerical methods based on averaging approximations, SIAM J. Control and Optimization, Vol. 16, No. 2(1978), 169–208.

#### H.T. Banks, K. Ito, and C. Wang

[1] Exponentially stable approximations of weakly damped wave equations, "Estimation and Control of Distributed Parameter Systems," Proceedings of an International Conference on Control and Estimation of Distributed Parameter Systems, Vorau, July 8-14, 1990, W. Desch, F. Kappel & K. Kunisch, eds., Birkhauser, 1991.

#### H.T. Banks and K. Kunisch

[1] The linear regulator problem for parabolic systems, SIAM J. Control and Optimization, Vol. 22(1984), 684-698.

#### H.T. Banks and C. Wang

[1] Optimal feedback control of infinite dimensional parabolic evolution systems: Approximation techniques, SIAM J. Control and Optimization, Vol. 27, No. 5(1989), 1182–1219.

#### J.A. Burns and R.H. Fabiano

[1] Feedback control of a hyperblic partial-differential equation with viscoelastic damping, Control-Theory and Advanced Technology, Vol. 5, No. 2(1989), 157–188.

#### J.A. Burns, Z. Liu, and R.E. Miller

[1] Approximations of thermoelastic and viscoelastic control systems, Numerical Functional Analysis and Optimization, Vol. 12(1991), 79–136.

#### J.A. Burns, Z. Liu, and S. Zheng

[1] On the energy decay of a linear thermoelastic bar, J. of Math. Anal. Appl., Vol. 179, No. 2(1993), 574-591.

#### S.K. Chang and R. Triggiani

Spectral analysis of thermo-elastic plates with rotational forces, Optimal Control: Theory, Algorithms, and Applications, pp. 84-115, W.W. Hager and P.M. Pardalos, eds., Kluwer Academic Publishers B.V., 1998.

#### G. Chen

- [1] Energy decay estimates and exact boundary value controllability for wave equation in a bounded domain, J. Math. Pures. Appl., 58(1979), 249-273.
- [2] A note on the boundary stabilization of the wave equation, SIAM J. Contr. and Opt., 19(1981), 106-113.

#### G. Chen, M.P. Coleman, and K. Liu

[1] Boundary stabilization of Donnell's shallow circular cylindrical shell, to appear in J. Sound & Vibration.

#### G. Chen, M.C. Delfour, A.M. Krall, and G. Payre

[1] Modeling, stabilization and control of serially connected beams, SIAM J. Cont. and Opt., 25(1987), 526-546.

- G. Chen, S.A. Fulling, F.J. Narcowich, and S. Sun
  - [1] Exponential decay of evolution equations with locally distributed damping, SIAM J. Appl. Math., Vol. 51, No. 1(1991), 266-301.

#### G. Chen, S.G. Krantz, D.W. Ma, and C.E. Wayne

[1] The Euler-Bernoulli beam equation with boundary energy dissipation, in Operator Methods for Optimal Control Problems, S.J. Lee ed., Lecture Notes in Pure and Appl. Math., pp. 67-96, Marcel Dekker, Inc., New York, 1987.

#### G. Chen and D. L. Russell

[1] A mathematical model for linear elastic systems with structural damping, Quart. Appl. Math., 39(1981/1982), 433-454.

#### S. Chen and R. Triggiani

- [1] Proof of extensions of two conjectures on structural damping for elastic system, the case  $\frac{1}{2} \le \alpha \le 1$ , Pacific J. Math., 39(1989), 15-55.
- [2] Gevery class semigroups arising from elastic systems with gentle dissipation: the case  $0 < \alpha < \frac{1}{2}$ , Proc. AMS, Vol. 110, No. 2(1990), 401-415.

#### B.D. Coleman and V.J. Mizel

[1] Norms and semigroups in the theory of fading memory, Arch. Rat. Mech. Anal., Vol. 23 (1966), 87–123.

#### R.F. Curtain and A.J. Pritchard

[1] Infinite Dimensional Linear System Theory, Springer-Verlag, New York, 1978.

#### C.M. Dafermos

- [1] On the existence and the asymptotic stability of solution to the equations of linear thermoelasticity, Arch. Rat. Mech. Anal., Vol.29(1968), 241-271.
- [2] Asymptotic stability in viscoelasticity. Arch. Rat. Mech. Anal., Vol. 37(1970), 297-308.
- [3] An abstract Volterra equation with applications to linear viscoelasticity, J. Differential Equations, Vol. 7(1970), 554-569.

#### R. Datko

[1] Extending of a theorem of Liapunov to Hilbert Space, J. Math. Anal. Appl., 32(1970), 610-616.

#### A. Day

- [1] Heat Conduction with Linear Thermoelasticity, Springer-Verlag, New York, 1985.
- [2] The decay of energy in a viscoelastic body, Mathematika, Vol. 27(1980), 268– 286.

#### W. Desch and R.K. Miller

- [1] Exponential stabilization of Volterra integrodifferential equations in Hilbert space, J. Differential Equations, Vol. 70(1987), 366-389.
- [2] Exponential stabilization of Volterra integral equations with singular kernels, J. Integral Equations Applications, Vol. 1(1988), 397-433.

#### R.H. Fabiano

- [1] Stability and approximation for a linear viscoelastic model, Journal of Mathermatical Analysis and Applications, Vol. 204 (1996), 206-220.
- [2] Stability preserving Galerkin approximations for linear distributed parameter systems, preprint.

#### R.H. Fabiano and K. Ito

- [1] Semigroup theory and numerical approximation for equations arising in linear viscoelasticity, SIAM J. Math. Anal., Vol. 21, No. 2(1990), 374–393.
- [2] An approximation framework for equations in linear viscoelasticity with strongly singular kernels, to appear in Quarterly of Applied Mathematics.

#### M. Fabrizio and B. Lazzari

[1] On the existence and asymptotic stability of solutions for linearly viscoelatic solids, Arch. Rat. Mech. Anal., Vol. 116(1991), 139-152.

#### A. Friedman

[1] Partial Differential Equations, Holt, Rinehart and Winston, New York, 1969.

#### J.S. Gibson

[1] The Riccati integral equations for optimal control problems on Hilbert spaces, SIAM J. Control and Optimization, Vol. 17(1979), 537-565.

#### J.S. Gibson and A. Adamian

[1] Approximation theory for LQG optimal control of flexible structures, SIAM J. on Control and Optimization, Vol. 29, No.1(1991), 1-37.

#### J.S. Gibson and I.G. Rosen

[1] Numerical approximation for the infinite-dimensional discrete-time optimal Linear Quadratic Regulator problem, SIAM J. on Control and Optimization, Vol. 26(1988), 428-451.

#### J.S. Gibson, I.G. Rosen, and G. Tao

[1] Approximation in control of thermoelastic systems, SIAM J. on Control and Optimization, Vol. 30, No. 5(1992), 1163-1189.

#### C. Giorgi, V. Pata, and M.G. Naso

[1] Exponential stability in linear heat conduction with memory: a semigroup approach, preprint, 1998.

#### K.B. Hannsgen, Y. Renardy, and R.L. Wheeler

[1] Effectiveness and robustness with respect to time delays of boundary feedback stabilization in one-dimensional viscoelasticity, SIAM J. Control and Optimization, Vol. 26, No. 5(1988), 1200–1233.

#### K.B. Hannsgen and R.L. Wheeler

- [1] Viscoelastic and boundary feedback damping: Precise energy decay rates when creep modes are dominant. J. Integral Equations and Applications, Vol. 2(1990), 495–527.
- [2] Moment conditions for a Volterra integral equation in a Banach space, Proceedings of Delay Differential Equations and Dynamical Systems, Claremont, Lecture Notes in Mathematics, Vol. 1475, pp. 204–209, Springer-Verlag, 1991.

#### S.W. Hansen

[1] Exponential energy decay in a linear thermoelastic rod, J. of Math. Anal. Appl., Vol. 167(1992), 429-442.

- S. Hewitt and K. Stromberg
  - [1] Real and Abstract Analysis, Springer-Verlag, New York, 1965.

#### L. Hörmander

[1] The Analysis of Linear Partial Differential Operators, Springer Grundlehren, Heidelberg, 1985.

#### F.L. Huang

- [1] Characteristic condition for exponential stability of linear dynamical systems in Hilbert spaces, Ann. of Diff. Eqs. 1(1) (1985), 43-56.
- [2] On the holomorphic property of the semigroup associated with linear elastic systems with structural damping, Acta Math. Sci., (in Chinese), 55(1985), 271–277.
- [3] A problem for linear elastic systems with structural damping, Acta Math. Sci. Sinica, 6(1986), 107-113.
- [4] On the mathematical model for linear elastic systems with analytic damping, SIAM J. Control and Optimization, Vol. 26(1988), 714-724.

#### K. Ito and F. Kappel

[1] On variational formulations of the Trotter-Kato theorem, CAMS Report, # 91-7, Univ. of Southern California, April, 1991.

#### S. Jiang

- [1] Global solution of the Neumann problem in one-dimensional thermoelasticity, Nonlinear Analysis, 19(1992), 107–121.
- [2] Exponential decay and global existence of spherically symmetric solutions in thermoelasticity, to appear in Chin. Ann. Math., series A (in Chinese).

#### S. Jiang, J.E.M. Rivira, and R. Racke

[1] Asymptotic stability and global existence in thermoelasticity with symmetry, to appear in Quart. Appl. Math.

#### M. Katsoulakis and S. Koike

[1] Viscosity solutions of monotone systems for Dirichlet problems, Differential and Integral Equations, Vol. 7, No.2(1994), 367-382.

#### J.U. Kim

[1] On the energy decay of a linear thermoelastic bar and plate, SIAM J. Math. Anal., 23(1992), 889-899.

#### J. Lagnese

- [1] Decay of solutions of wave equations in a bounded region with boundary dissipation, J. Diff. Eqs, 50(1983), 163-182.
- [2] Boundary stabilization of linear elastodynamics, SIAM J. on Control and Optimization, Vol. 21, No. 6(1983), 968-983.
- [3] Boundary Stabilization of Thin Plates, SIAM Studies in Applied Mathematics, Vol. 10, Society for Industrial and Applied Mathematics, Philadelphia, 1989.

#### I. Lasiecka

 Controllability of a viscoelastic Kirchhoff plate, Numer. Math., 91 (1989), 237– 247.

#### I. Lasiecka and R. Triggiani

- [1] Uniform exponential energy decay of the wave equation in a bounded region with  $L_2(0,\infty;L_2(\Gamma))$ -feedback control in the Dirichlet boundary condition, J. Differential Euquations, 66(1987), 340-390.
- [2] Two direct proofs on the analyticity of the S.C. semigroup arising in abstract thermo-elastic quation, to appear in Advances in Differential Equation.
- [3] Analyticity, and lack thereof, of thermo-elastic semigroups, to appear in the Proceedings of the Conference on PDE Control.
- [4] Analyticity of thermo-elastic semigroups with coupled Hinged/Neumann B.C., to appear in Abstract and Applied Analysis.
- [5] Analyticity of thermo-elastic semigroups with free B. C. submitted to Anneli Scoulls Normale Superiors di Pisa.
- [6] Structual decomposition of thermo-elastic semigroups with rotational forces, to appear in Semigroup Forum.

#### G. Leugering

- [1] On boundary feedback stabilization of a viscoelastic membrane, Dynamics and Stability of Systems, Vol. 4, No. 1(1989), 71–79.
- [2] On boundary feedback stabilizability of a viscoelastic beam, Proc. Roy. Soc. Edinburgh, Sec. A, Vol. 114, No. 1(1990), 57-69.

#### J.L. Lions and E. Magenes

[1] Nonhomogeneous Boundary Value Problems and Applications, Springer, Heidelberg, 1972.

#### Z. Liu

[1] Approximation and control of a thermoviscoelastic system, Ph.D. dissertation, Virginia Polytechnic Institute and State University, Department of Mathematics, August 1989.

#### K. Liu and Z. Liu

- [1] On the type of C<sub>0</sub>-semigroup associated with the abstract linear viscoelastic system, ZAMP, 47(1996), 1-15.
- [2] Exponential stability and analyticity of abstract linear thermoelastic systems, ZAMP, 48(1997) 885–904.
- [3] Analyticity and differentiablity of semigroups associated with elastic systems with damping and gyroscopic forces, Journal of Differential Equations, Vol. 141, No. 2(1997), 340-354.
- [4] Exponential decay of energy of the Euler-Bernoulli beam with locally distributed Kelvin-Voigt damping, SIAM J. Control and Optimization, Vol. 36, No. 3(1998), 1086-1098.
- [5] Boundary stabilization of a nonhomogeneous Euler-Bernoulli beam by the frequency domain multiplier method, preprint, 1997.

#### Z. Liu and M. Renardy

[1] A note on the equation of a thermoelastic plate, Appl. Math. Lett., Vol. 8, No. 3(1995), 1-6.

#### Z. Liu, S.A. Trogdon, and J. Yong

[1] Modeling and analysis of a laminated beam, to appear in Mathematical and Computer Modeling.

#### Z. Liu and J. Yong

[1] Qualitative properties of certain  $C_0$  semigroups arising in elastic systems with various dampings, to appear in Advances in Differential Equations.

#### Z. Liu and S. Zheng

- [1] Exponential stability of semigroup associated with thermoelastic system, Quarterly Appl. Math., Vol. LI, No. 3(1993), 535-545.
- [2] Uniform exponential stability and approximation in control of thermoelastic system, SIAM. J. Control and Optimization, Vol. 32, No. 5(1994), 1226-1246.
- [3] Exponential energy decay of the Euler-Bernoulli beam with shear diffusion or thermal dissipation, Journal of Mathematical Analysis and Applications, Vol. 196(1995), 467-478.
- [4] On the exponential stability of linear viscoelasticity and thermoviscoelasticity, Quarterly Appl. Math., Vol. LIV, No.1(1996), 21-31.
- [5] Exponential stability of the Kirchhoff plate with thermal or viscoelastic damping, Quarterly of Applied Mathematics, No. 3(1997), 551-564.
- [6] Uniform exponential stability of approximation in linear viscoelasticity, Journal of Mathematical System, Estimation and Control, Vol.8, No. 2(1998), 177–180.

#### J.E. Marsden and T.J.R. Hughes

 Mathematical Foundations of Elasticity, Prentice-Hall, Englewood Cliffs, NJ, 1983.

#### D.J. Mead and S. Markus

[1] The forced vibration of a three-layer, damped sandwich beam with arbitrary boundary conditions, J. Sound Vibration, 10(1969), 163–175.

#### C.B. Navarro

[1] Asymptotic stability in linear thermoviscoelaticity, J. Math. Anal. Appl., Vol. 65(1978), 399-431.

#### L. Nirenberg

- [1] On elliptic partial differential equations, Annali della Scoula Norm. Sup. Pisa, 13 (1959), 115–162.
- [2] Topics in Nonlinear Functional Analysis, Courant Institute of Mathematical Sciences, New York, 1974.

#### A. Pazy

[1] Semigroups of Linear Operators and Applications to Partial Differential Equations, Springer, New York, 1983.

#### J. Prüss

[1] On the spectrum of  $C_0$ -semigroups, Trans. AMS, 284 (1984), 847–857.

#### J.P. Quinn and D.L. Russell

[1] Asymptotic stability and energy decay rates for solutions of hyperbolic equations with boundary damping, Proc. Roy. Soc. of Edinburgh, 77A(1977), 97-127.

#### R. Racke

- [1] Lectures on Nonlinear Evolution Equations, Aspects of Mathematics Vol. 19, VIEWEG, Bonn, 1992.
- [2] On the time-asymptotic behaviour of solutions in thermoelasticity, Proc. Roy. Soc. Edinburgh, 107A(1987), 289-298.
- [3] On the Cauchy problem in nonlinear 3-d-thermoelasticity, Math. Z., 203 (1990), 649-682.
- [4] Blow-up in nonlinear three-dimensional thermoelasticity, Math. Meth. Appl. Sci., 12 (1990), 267-273.

#### R. Racke and Y. Shibata

[1] Global smooth solutions and asymptotic stability in one-dimensional nonlinear thermoelasticity, Arch. Rat. Mech. Anal., Vol. 116(1992), 1-34.

#### R. Racke, Y. Shibata, and S. Zheng

[1] Global solvability and exponential stability in one-dimensional nonlinear thermoelasticity, Quarterly of Applied Mathematics, No. 4(1993), 751-763.

#### B. Rao

[1] A compact perturbation method for the boundary stabilization of the Raleigh beam equation, to appear in Appl. Math. Optim.

#### D.K. Rao

[1] Frequency and loss factors of sandwich beams under various boundary conditions, J. Mechanical Engineering Sciences, 20(1978), 271-282.

#### R. Rebarber

[1] Exponential stability of coupled beams with dissipative joints: a frequency domain approach, SIAM J. Control and Optimization, 33(1995), 1-28.

#### K. Rektorys

[1] Variational Methods in Mathematics, Science and Engineering, D. Reidel Publishing Company, Holland, 1977.

#### J.E.M. Rivera

- [1] Energy decay rate in linear thermoelasticity, Funkcial Ekvac., Vol. 35 (1992), 19-30.
- [2] Asymptotic behaviour in linear viscoelasticity, Quarterly of Applied Mathematics, Vol.LII, No.4(1994), 629-648.

#### J.E.M. Rivera and R.K. Barreto

[1] Uniform rates of decay in anisotropic thermo-viscoelasticity, preprint in Laboratorio Nacional de Computação Científica (LNCC).

#### J.E.M. Rivera and L.H. Fatori

[1] Smoothing effect and propagations of singularities for viscoelastic plates, Journal of Mathematical Analysis and Applications, 206(1997), 397-427.

#### J.E.M. Rivera, E.C. Lapa, and R. Barreto

[1] Decay rates for viscoelastic plates with memory, Journal of Elasticity, 44(1996), 61-87.

#### J.E.M. Rivera and R. Racke

- [1] Smoothing properties, decay and global existence of solutions to nonlinear coupled systems of thermoelastic type, SIAM J. Math. Anal., Vol. 26 (1995), 1547-1563.
- [2] Large solutions and smoothing properties for nonlinear thermoelastic systems, to appear in J. Differential Equations.

#### D.L. Russell

- [1] A comparison of certain elastic dissipation mechanisms via decoupling and projection techniques, Quarterly Appl. Math., Vol. XLIX, No. 2(1991), 373-396.
- [2] A general framework for the study of indirect damping mechanisms in elastic systems, J. of Math. Anal. Appl., Vol. 173, No. 2(1993), 339-358.

#### Y. Shibata

[1] Neumann problem for one-dimentional nonlinear thermoelasticity, preprint, 1991.

#### M. Slemrod

[1] Global existence, uniqueness, and asymptotic stability of classical smooth solutions in one-dimensional nonlinear thermoelasticity, Arch. Rational Mech. Anal., 76 (1981), 97–133.

#### D. Tataru

[1] On the regularity of boundary traces for the wave equation, preprint.

#### S. Taylor

[1] Gevrey Semigroups, Ph.D. Thesis, Chapter 5, University of Minnesota, 1989.

#### R. Temam

- [1] Infinite-Dimensional Dynamical Systems in Mechanics and Physics, Applied Mathematical Sciences 68, Springer-Verlag, New York, 1988.
- S. Timoshenko, D.H. Young, and W. Weaver, Jr
  - [1] Vibration problems in engineering, John Wiley & Sons, New York, 1974.

#### R. Triggiani,

[1] Wave equation on a bounded domain with boundary dissipation: an operator approach, J. of Math. Anal. and Appl., 137(1989), 438-461.

#### A. Wyler

[1] Stability of wave equations with dissipative boundary conditions in a bounded domain, Differential and Integral Equations, Vol. 7, No.2(1994), 345–366.

#### Songmu Zheng

[1] Nonlinear Parabolic Equations and Hyerbolic-Parabolic Coupled Systems, Pitman series Monographs and Survey in Pure and Applied Mathematics, Vol. 76, Longman, 1995.

#### Songmu Zheng (Zheng, Songmu) and Weixi Shen (Shen, Weixi)

- [1] Global solutions to the Cauchy problem of a class of quasilinear hyperbolic-parabolic coupled systems, Scientia Sinica, 4A (1987), 357-372.
- [2] Global solutions to the Cauchy problem of the equations of one-dimensional thermoviscoelasticity, Journal of Partial Differential Equations, Vol. 2, No. 2 (1989), 26-38.

## This page intentionally left blank

#### Index

Analyticity, see also analytic semigroup, 4, 5, 8, 18, 43, 44, 45, 46, 52, 54, 61, 64, 67, 72, 86, 90, 91, 95, 112, 117, 119, 124, 128

#### Approximation

approximation of the thermoelastic system, 163
approximation of the viscoelastic system, 177
finite-dimensional approximation, 153
modal approximation, 165, 174
uniformly stable approximation,

#### Beam

152

Euler-Bernoulli beam equations,
112, 129, 138

laminated beam, 119

Timoshenko beam equations, 112
thermoelastic beam, 120

#### Damping

boundary damping, 129, 138
friction damping, 66, 72
locally distributed damping, 72
shear damping, 112, 119, 120
thermal damping, 25, 88
viscoelastic damping, 87
viscous damping, 25, 91

Dissipative operator, 1, 3, 21, 23, 30, 35, 48, 63, 67, 74, 82, 83, 84, 91, 102, 103, 114, 122, 132, 141

Elliptic boundary value problem, 8, 12

wellposedness, 13

regularity, 14, 21, 51, 133

Exponential stability, exponentially stable, 2, 4, 18, 23, 24, 32, 36, 39, 44, 45, 46, 49, 50, 54, 61, 63, 64, 67, 68, 69, 72, 73, 74, 80, 84, 90, 91, 93, 94, 98, 100, 105, 112, 115, 119, 124, 128, 129, 130, 133, 139, 142, 153, 155, 164, 174, 178

 $C_0$ -semigroup uniformly exponential stability, 152, 154, 155, 156, 161, 162, 164, analyticity of, see Analyticity 167, 173, 174, 177, 183 definition of, 1 definition of infinitesimal gen-Hille-Yosida Theorem, 3, 158 erator of, 1 Inequality exponential stability of, see Gargiliardo-Nirenberg inequality, Exponential stability 10, 11, 26, 42, 43, 58, 118, 126, analytic semigroup, 2, 4, 5, 8, 18, 127, 147, 171 43, 44, 45, 46, 52, 54, 61, 64, Poincaré inequality, 10, 11, 26, 27, 67, 72, 86, 90, 91, 95, 112, 117, 36, 40, 41, 94, 118, 122, 125, 119, 124, 128 144 Shear diffusion, 112, 120 Interpolation spaces, 15 Sobolev space Kirchhoff plate, 25, 43, 44, 45, 46, 88 compactness theorem, 9 with memory, 87 definition, 8 density theorem, 9 Linear thermoelastic system, 18, 42 imbedding theorem, 9, 145, 146 Linear thermoviscoelastic system, trace theorem, 10, 58, 59 91, 92, 96, 98, 99 Solution with memory, 96 classical solution, 22 Linear viscoelastic system, 61 weak solution, 22, 71 with memory, 61, 77 Stabilizable 153 Lumer-Phillips Theorem, 3 uniformly stabilizable, 153, 154 Semigroup

#### **ABOUT THIS VOLUME**

Motivated by applications to control theory and to the theory of partial differential equations (PDF s), the authors examine the exponential stability and analyticity of  $\mathcal{C}_i$ -semigroups associated with various dissipative extens. The present a unique stematic approach in which they prove exponential stability by combining a theory from semigroup theory with partial differential equation technique—and use an analogous theorem with PDE technique—to prove analyticity. The result is a powerful but simple tool useful in determining whether the eproperties will preserve for given dissipative system.

The authors show that the exponential stability is preserved for all the mechanical varies considered in this book—linear, one-dimensional thermoelastic, varied easier and thermoelastic systems, pluss tems with shear or friction damping. However also learn that this property does not hold true for linear three dimensional system, without making assumptions on the domain and initial data, and that analyticity is a more consitive property not preserved, we not some of the estems addressed in this study.

Readership: Re-earchers and graduate students in functional analysis partial differential equations control theory solid mechanics, and viscelasticity

#### **CHAPMAN & HALL/CRC RESEARCH NOTES IN MATHEMATICS SERIES**

The aim of this series is to disseminate important new material of a specialist nature in economic form. It ranges over the whole spectrum of mathematics and also reflect the changing momentum of dialogue between hitherto distinct areas of pure and applied parts of the discipline.

The editorial board has been chosen accordingly and will from time to time be recomposed to represent the full diversity of mathematics covered by *Math. metics Reviews*.

This is a rapid means of publication for current material whose style of exposition is that of a developing subject. Work that is in most respects final and definitive but not yet refined into a formal monograph will also be considered for a place in the series. Normally homogeneous material is required, even if writte i by more than on author, thus multi-author v orks will be included provided that the strong link in theme or ditorial pattern.

Propos de and manuse upts: See inside book

#### **CHAPMAN & HALL/CRC**

![](_page_219_Figure_10.jpeg)