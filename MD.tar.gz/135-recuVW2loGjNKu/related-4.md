#### **Stat 260/CS 294-102. Learning in Sequential Decision Problems.**

#### **Peter Bartlett**

- 1. Multi-armed bandit algorithms.
  - Exponential families.
    - <sup>−</sup> Cumulant generating function.
    - <sup>−</sup> KL-divergence.
  - KL-UCB for an exponential family.
  - KL vs c.g.f. bounds.
    - <sup>−</sup> Bounded rewards: Bernoulli and Hoeffding.
  - Empirical KL-UCB.

See (Olivier Capp´e, Aur´elien Garivier, Odalric-Ambrym Maillard, R´emi Munos and Gilles Stoltz, 2013)

### **Recall: Concentration inequalities.**

**Definition:** Cumulant-generating function:

$$\Gamma_X(\lambda) = \log \mathbb{E} \exp(\lambda X),$$

We consider upper bounds ψ : R → R, satisfying ψ ( λ ) ≥ Γ X ( λ ). The *Legendre transform (convex conjugate)* of ψ is

$$\psi^*(\epsilon) = \sup_{\lambda \in \mathbb{R}} (\lambda \epsilon - \psi(\lambda)).$$

**Theorem:** For ǫ ≥ 0, P ( X − E X ≥ ǫ ) ≤ exp − ψ ∗ X − E X ( ǫ ) .

### **Recall: Concentration Inequalities.**

**Theorem:** If  $X_1, X_2, \ldots, X_n$  are mean zero, i.i.d. with cgf upper bound  $\psi$ , then  $\bar{X}_n = \frac{1}{n} \sum_{i=1}^n X_i$  satisfies

$$\mathbb{P}\left(\bar{X}_n \ge \epsilon\right) \le \exp\left(-n\psi^*(\epsilon)\right),\,$$

And the exponent can't be improved.

**Theorem:** [Cramér-Chernoff] If  $X_1, X_2, ..., X_n$  are iid and mean zero, and have cgf  $\Gamma$ , then for  $\epsilon > 0$  and  $\bar{X}_n = \frac{1}{n} \sum_{i=1}^n X_i$ ,

$$\lim_{n \to \infty} \frac{1}{n} \log \mathbb{P} \left( \bar{X}_n \ge \epsilon \right) = -\Gamma^*(\epsilon).$$

 $(\Gamma^* \text{ sometimes called } Cramér function. Lower bound is a change-of-measure argument plus central limit theorem.)$ 

# **Outline.**

For an exponential family, we can compute the c.g.f. exactly. Its convex conjugate corresponds to <sup>a</sup> KL-divergence. For reward distributions from the exponential family, concentration inequalities involving the KL-divergence define an upper confidence bound strategy: KL-UCB.

If the reward distributions are bounded, the c.g.f. of <sup>a</sup> particular exponential family (a scaled, shifted Bernoulli) gives <sup>a</sup> bound on the c.g.f. And we can bound this, in turn, with <sup>a</sup> quadratic (like Hoeffding's inequality), which corresponds to another exponential family (a Gaussian). KL-UCB for Bernoulli improves on KL-UCB for Gaussian. (KL-UCB for Gaussian corresponds to the original UCB strategy.)

There's also <sup>a</sup> non-parametric version of KL-UCB (called empirical KL-UCB) for bounded rewards. It works with the set of distributions with finite support.

**Definition:** Canonical exponential family defined wrt measure P:

$$\frac{dP_{\theta}}{dP}(x) = \exp(\theta x - A(\theta)),$$

$$A(\theta) = \log\left(\int \exp(\theta x) dP(x)\right),$$

$$\theta \in \Theta = \{\theta : A(\theta) < \infty\}.$$

$$\mu(\theta) := \mathbb{E}_{\theta} X = A'(\theta).$$
 
$$\theta(\mu) \text{ defined on } \mu(\Theta). \qquad \text{(one-to-one because } \text{Var}_{\theta} X = A''(\theta) > 0).$$
 
$$\Gamma_{\theta}(\lambda) = A(\theta + \lambda) - A(\theta),$$
 
$$\Gamma_{\theta_1}^*(\mu(\theta_2)) = A(\theta_1) - A(\theta_2) + \mu(\theta_2)(\theta_2 - \theta_1),$$
 
$$D_{KL}(P_{\theta_1}, P_{\theta_2}) = \Gamma_{\theta_2}^*(\mu(\theta_1)).$$

$$A'(\theta) = \frac{\int x \exp(\theta x) dP(x)}{\exp(A(\theta))}$$

$$= \mathbb{E}_{\theta} X.$$

$$\Gamma_{\theta}(\lambda) = \log \left( \int \exp(\lambda x + \theta x - A(\theta)) dP(x) \right)$$

$$= \log \left( \int \exp((\lambda + \theta)x) dP(x) \right) - A(\theta)$$

$$= A(\theta + \lambda) - A(\theta).$$

$$\Gamma_{\theta_1}^*(\mu(\theta_2)) = \sup_{\lambda} \left(\lambda \mu(\theta_2) - \left(A(\theta_1 + \lambda) - A(\theta_1)\right)\right)$$
Maximum has 
$$\mu(\theta_2) = \mu(\theta_1 + \lambda),$$
that is, 
$$\lambda = \theta_2 - \theta_1,$$
so 
$$\Gamma_{\theta_1}^*(\mu(\theta_2)) = (\theta_2 - \theta_1)\mu(\theta_2) + A(\theta_1) - A(\theta_2).$$

$$D_{KL}(P_{\theta_1}, P_{\theta_2}) = \int \log \frac{dP_{\theta_1}}{dP_{\theta_2}} dP_{\theta_1}$$

$$= \int ((\theta_1 - \theta_2)x) \exp(\theta_1 x - A(\theta_1)) dP(x)$$

$$+ A(\theta_2) - A(\theta_1)$$

$$= \mu(\theta_1)(\theta_1 - \theta_2) + A(\theta_2) - A(\theta_1)$$

$$= \Gamma_{\theta_2}^*(\mu(\theta_1))$$

#### **Example: Bernoulli:**

$$P_{\theta}(x) = \exp(\theta x - A(\theta)), \qquad A(\theta) = \log(1 + e^{\theta}),$$

$$\mu(\theta) = P_{\theta}(1) = \frac{e^{\theta}}{1 + e^{\theta}}, \qquad \theta = \log\frac{\mu}{1 - \mu},$$

$$\Gamma_{\theta}(\lambda) = \log(1 - \mu(\theta) + \mu(\theta)e^{\lambda}), \qquad \Theta = \mathbb{R}.$$

#### **Example: Bernoulli:**

$$\Gamma_{\theta_{1}}^{*}(\mu_{2}) = \sup_{\lambda} \left( \lambda \mu_{2} - \log \left( 1 - \mu_{1} + \mu_{1} e^{\lambda} \right) \right)$$
Maximum has
$$\mu_{2} = \frac{\mu_{1} e^{\lambda}}{1 - \mu_{1} + \mu_{1} e^{\lambda}},$$
that is,
$$\lambda = \log \frac{\mu_{2} (1 - \mu_{1})}{\mu_{1} (1 - \mu_{2})}$$
so
$$\Gamma_{\theta_{1}}^{*}(\mu_{2}) = \mu_{2} \log \frac{\mu_{2}}{\mu_{1}} + (1 - \mu_{2}) \log \frac{1 - \mu_{2}}{1 - \mu_{1}}$$

$$= D_{KL}(P_{\theta_{2}}, P_{\theta_{1}}).$$

#### **KL-UCB for exponential families: Use** ψ = Γ

Define the sample averages

$$\hat{\mu}_j(t) = \frac{1}{T_j(t)} \sum_{s=1}^t X_{I_s,s} 1[I_s = j], \qquad \hat{\mu}_{j,t} = \frac{1}{t} \sum_{s=1}^t X_{j,s}.$$

If <sup>X</sup>j,s has mean µ and c.g.f. Γ <sup>µ</sup>, and <sup>a</sup> <sup>&</sup>lt; <sup>µ</sup>,

$$\Pr\left(\hat{\mu}_{j,n} \le a\right) \le e^{-n\Gamma^*(a)},$$

that is,

$$\Pr\left(\hat{\mu}_{j,n} < \mu \text{ and } \Gamma^*_{\mu}\left(\hat{\mu}_{j,n}\right) \ge \frac{f(n)}{n}\right) \le e^{-f(n)},$$

or

$$\Pr\left(\hat{\mu}_{j,n} < \mu \text{ and } D_{KL}\left(P_{\hat{\mu}_{j,n}}, P_{\mu}\right) \ge \frac{f(n)}{n}\right) \le e^{-f(n)}.$$

(Note that <sup>P</sup>µ denotes <sup>P</sup>θ(µ).)

### **KL-UCB** for exponential families.

**KL-UCB Strategy** for an exponential family  $(P_{\mu} \text{ denotes } P_{\theta(\mu)})$ :

$$I_t = t$$
 for  $t = 1, \dots, k$ ,

$$I_t = \arg\max_{1 \leq j \leq k} \sup \left\{ \mu(\theta) : \theta \in \Theta \text{ and } \right\}$$

$$D_{KL}\left(P_{\hat{\mu}_j(t-1)}, P_{\mu}\right) \le \frac{f(t)}{T_j(t-1)} \right\},\,$$

where  $f(t) = \log t + 3 \log \log(t)$ .

• Equivalent to UCB with  $\psi = \Gamma_{\mu}$ .

#### **KL-UCB for exponential families.**

We can think of DKL <sup>P</sup>µ<sup>ˆ</sup>j,t −<sup>1</sup> , <sup>P</sup><sup>µ</sup> as <sup>a</sup> divergence defined in terms of means: for any µ, µ <sup>ˆ</sup> ∈ <sup>µ</sup>(Θ),

$$d(\hat{\mu}, \mu) = D_{KL}(P_{\hat{\mu}}, P_{\mu}) = (\theta(\hat{\mu}) - \theta(\mu)) \,\hat{\mu} - A(\theta(\hat{\mu})) + A(\theta(\mu)).$$

Then d(ˆµ, <sup>µ</sup>) <sup>=</sup> <sup>0</sup> iff µˆ = µ, d is strictly convex and differentiable. We can extend it to the closure of <sup>µ</sup>(Θ), by taking limits, allowing infinite values, and setting d (µ, <sup>µ</sup>) <sup>=</sup> <sup>0</sup> at boundaries. (Consider, for example, µ<sup>ˆ</sup> <sup>=</sup> 0 for <sup>a</sup> Bernoulli.)

**KL-UCB** for exponential families.

**Theorem:** KL-UCB for an exponential family satisfies:

$$\mathbb{E}T_j(n) \le \frac{\log n}{D_{KL}\left(P_{\mu_j}, P_{\mu^*}\right)} + O\left(\sqrt{\log n}\right).$$

And the leading term is optimal (including the constant).

#### **KL-UCB for bounded rewards.**

**Theorem:** For X <sup>∈</sup> [0, 1] with E X = µ, define Y <sup>∼</sup> Bernoulli ( µ ). Then

$$\Gamma_X(\lambda) \leq \Gamma_Y(\lambda).$$

Notice that this gives <sup>a</sup> c.g.f. bound ψ X µ for <sup>X</sup> satisfying:

$$\psi_{X_{\mu}}^{*}(\mu') = \mu' \log \frac{\mu'}{\mu} + (1 - \mu') \log \frac{1 - \mu'}{1 - \mu}.$$

#### **KL-UCB for bounded rewards.**

*Proof:* For x <sup>∈</sup> [0, 1], exp(λx ) lies below the line from (0, <sup>e</sup> 0 ) to (1, <sup>e</sup> λ ):

$$\exp(\lambda x) \le x \left(e^{\lambda} - e^{0}\right) + e^{0},$$
  
so 
$$\mathbb{E} \exp(\lambda X) \le \mu \left(e^{\lambda} - 1\right) + 1$$
$$= \mathbb{E} \exp(\lambda Y).$$

#### **KL-UCB-Bernoulli for bounded rewards.**

#### **KL-UCB-Bernoulli Strategy** For the Bernoulli family $P_{\mu}$ :

$$I_t = t$$
 for  $t = 1, \dots, k$ ,

$$I_t = \arg\max_{1 \le j \le k} \sup \left\{ \mu \in (0, 1) : \right\}$$

$$d\left(\hat{\mu}_j(t-1),\mu\right) \le \frac{f(t)}{T_j(t-1)} \right\},\,$$

where  $d(\mu_1, \mu_2) = \mu_1 \log \frac{\mu_1}{\mu_2} + (1 - \mu_1) \log \frac{1 - \mu_1}{1 - \mu_2}$  and  $f(t) = \log t + 3 \log \log(t)$ .

#### **KL-UCB-Bernoulli for bounded rewards.**

**Theorem:** KL-UCB-Bernoulli satisfies:

$$\mathbb{E}T_j(n) \le \frac{\log n}{d(\mu_j, \mu^*)} + O\left(\sqrt{\log n}\right),\,$$

where 
$$d(\mu_1, \mu_2) = \mu_1 \log \frac{\mu_1}{\mu_2} + (1 - \mu_1) \log \frac{1 - \mu_1}{1 - \mu_2}$$
.

The leading term is optimal for Bernoulli rewards, but might not be optimal, for example, if the variance is lower than  $\mu(1-\mu)$ .

#### **KL-UCB: More concentration inequalities.**

Now, Pinsker's inequality gives

$$\psi_{X_{\mu}}^{*}(\mu') = D_{KL}(\mu', \mu) = \mu' \log \frac{\mu'}{\mu} + (1 - \mu') \log \frac{1 - \mu'}{1 - \mu}$$
$$\geq 2(\mu' - \mu)^{2}.$$

which shows this is at least as good as Hoeffding's inequality:

$$\mathbb{P}\left(\bar{X}_n \ge \mu'\right) \le \exp\left(-2n(\mu' - \mu)^2\right)$$
$$\mathbb{P}\left(\bar{X}_n \ge \mu + \epsilon\right) \le \exp\left(-2n\epsilon^2\right).$$

#### **Example: Gaussian:**

$$p_{\theta}(x) = \frac{\exp(-x^2/(2\sigma^2))}{\sqrt{2\pi\sigma^2}} \exp\left(\frac{\mu}{\sigma^2}x - \frac{\mu^2}{2\sigma^2}\right),$$

$$\theta = \frac{\mu}{\sigma^2},$$

$$\mu(\theta) = \sigma^2\theta,$$

$$A(\theta) = \frac{\sigma^2\theta^2}{2},$$

$$\Gamma_{\theta}(\lambda) = \frac{\sigma^2}{2}(\lambda + \theta)^2 - \frac{\theta^2\sigma^2}{2},$$

$$\Gamma_{\theta_1}^*(\mu_2) = \frac{1}{2\sigma^2}(\mu_2 - \mu_1)^2.$$

With <sup>σ</sup><sup>2</sup> <sup>=</sup> <sup>1</sup>/<sup>4</sup>, Pinsker's inequality corresponds to Hoeffding's inequality.

So we can view the UCB strategy (based on Hoeffding's inequality), as <sup>a</sup> special case of KL-UCB, modeling the reward distributions from [0, 1] as N (µ, <sup>1</sup>/4).

#### **KL-UCB-Gaussian for bounded rewards.**

#### **KL-UCB-Gaussian Strategy** For the Gaussian family $P_{\mu}$ :

$$I_t = t$$
 for  $t = 1, \dots, k$ , 
$$I_t = \arg\max_{1 \le j \le k} \sup \left\{ \mu \in (0, 1) : d\left(\hat{\mu}_j(t-1), \mu\right) \le \frac{f(t)}{T_i(t-1)} \right\},$$

where  $f(t) = \log t + 3 \log \log(t)$  and  $d(\mu_1, \mu_2) = 2(\mu_1 - \mu_2)^2$ .

This is equivalent to the UCB strategy (based on Hoeffding) that we saw last time.

#### **UCB** for bounded rewards.

**Theorem:** UCB satisfies:

$$\mathbb{E}T_j(n) \le \frac{\log n}{d(\mu_j, \mu^*)} + O\left(\sqrt{\log n}\right),\,$$

where  $d(\mu_1, \mu_2) = 2(\mu_1 - \mu_2)^2$ .

This result is weaker (because of Pinsker's inequality) than the result for KL-UCB-Bernoulli.

Denote the canonical exponential family defined wrt <sup>a</sup> measur e m by Em:

$$\mathcal{E}_m = \left\{ P : \frac{dP}{dm}(x) = \exp(\theta x - A(\theta)), \text{ and } A(\theta) < \infty \right\},$$

where

$$A(\theta) = \log \left( \int \exp(\theta x) dm(x) \right).$$

Write Pm,θ for the element of Em with parameter θ, and <sup>P</sup>m,µ for the element of Em with mean µ (and there's <sup>a</sup> one-to-one map between θ and µ, so it's well-defined.) And define for Em the relevant divergence as <sup>a</sup> function of expectations:

$$d_m(\mu, \mu') := D_{KL}(P_{m,\mu}, P_{m,\mu'}).$$

We have derived bounds on Γ <sup>P</sup><sup>j</sup> in terms of Γ <sup>P</sup>m,µ <sup>j</sup> , for some exponential families E<sup>m</sup>. For instance, if we let P denote the set of distributions on [0, 1], and consider two exponential families, the Bernoulli (call it E B ) and the Gaussian with variance 1 / 4 (call it E <sup>G</sup>), then we have: For all P <sup>∈</sup> P with P X = µ, and all λ,

$$\Gamma_{P(\lambda)} \leq \Gamma_{P_{B,\mu}}(\lambda) \leq \Gamma_{P_{G,\mu}}(\lambda).$$

And this is equivalent to: for all µ ′ ,

$$\Gamma_P^*(\mu') \ge \Gamma_{P_{B,\mu}}^*(\mu') \ge \Gamma_{P_{G,\mu}}^*(\mu'),$$

that is,

$$\Gamma_P^*(\mu') \ge d_B(\mu', \mu) \ge d_G(\mu', \mu).$$

We have seen upper bounds on regret based on these inequalities of the form

$$\bar{R}_n \le \sum_{j:\Delta_j>0} \Delta_j \left( \frac{\log n}{d_m(\mu_j, \mu^*)} + O\left(\sqrt{\log n}\right) \right).$$

And we've seen lower bounds that are (roughly) of the form

$$\bar{R}_n \ge \sum_{j:\Delta_j > 0} \Delta_j \left( \frac{\log n}{D_{KL}(P_j, P_{j^*})} + o(1) \right).$$

To understand the gap between the upper bounds and the lower bounds, we can consider the I-projection of  $P_{j^*} \in \mathcal{E}_{P_{j^*}}$  on to  $\{P : PX = \mu_j\}$ .

**Theorem:** Fix <sup>a</sup> measure <sup>m</sup> and an exponential family E<sup>m</sup>. For all Q <sup>∈</sup> Em and P with P X = µ,

$$D_{KL}(P,Q) = D_{KL}(P, P_{m,\mu}) + D_{KL}(P_{m,\mu}, Q).$$

In particular,

$$\inf \{ D_{KL}(P,Q) : PX = \mu \} = D_{KL}(P_{m,\mu},Q).$$

We say that <sup>P</sup>m,µ is the I-projection of Q <sup>∈</sup> Em onto { P : P X = µ }.

The negative KL-divergence

$$-D_{KL}(P,Q) = -\int \log \frac{dP}{dQ} dP$$
$$= \int \frac{dP}{dQ} \log \frac{dQ}{dP} dQ$$

is also called the entropy of P (defined with respec<sup>t</sup> to Q), HQ ( P ). So the result says that among all distributions satisfying the mean constraint P X = µ, the one with maximum entropy (wrt any Q in Em) is <sup>P</sup>m,µ in the exponential family E<sup>m</sup>.

Using this fact, we can see that

$$\begin{split} D_{KL}\left(P_{j},P_{j^{*}}\right) & \geq \inf\left\{D_{KL}\left(P,P_{j^{*}}\right):PX = \mu_{j}\right\} \\ & = D_{KL}\left(P_{P_{j^{*}},\mu_{j}},P_{j^{*}}\right) \\ & = \Gamma_{P_{j^{*}}}^{*}\left(\mu_{j}\right) \qquad \qquad \text{(both distributions are in } \varepsilon_{P_{j^{*}}}) \\ & \geq \Gamma_{P_{m,\mu^{*}}}^{*}\left(\mu_{j}\right) \\ & = d_{m}(\mu_{j},\mu^{*}), \end{split}$$

where Em is one of the exponential families that give the upper bounds (Bernoulli or Gaussian).

So the upper bound might be loose because <sup>P</sup><sup>j</sup> is further from Pj ∗ than the I-projection of Pj <sup>∗</sup> on to {<sup>P</sup> <sup>X</sup> = µ j } (i.e., because <sup>P</sup><sup>j</sup> is not in E Pj ∗ ), or because Γ <sup>P</sup>m,µ ∗ is <sup>a</sup> loose upper bound on Γ Pj ∗ (i.e., because Pj ∗ is not in Em).

The KL-UCB strategies choose  $I_1 = 1, ..., I_k = k$ , and then

$$I_{t+1} = \arg \max_{1 \le j \le k} U_j(t),$$

where

$$U_j(t) = \sup \left\{ \mu \in \mu(\Theta) \text{ s.t. } d(\hat{\mu}_j(t), \mu) \le \frac{f(t)}{T_j(t)} \right\}.$$

For a suboptimal arm j, we want to bound

$$\mathbb{E}T_j(n) = 1 + \sum_{t=k}^n \mathbb{P}\{I_{t+1} = j\}.$$

We might have  $I_{t+1} = j$  if either  $U_{j^*}(t)$  is not an upper bound on  $\mu^*$  (for a suitable choice for f(t), this has negligible probability), or it is an upper bound, but  $U_j(t)$  is bigger (and so exceeds  $\mu^*$ ; this can't happen too often).

$$\{I_{t+1} = j\}$$

$$\subseteq \{\mu^* \ge U_{j^*}(t)\} \cup \{I_{t+1} = j \text{ and } \mu^* < U_{j^*}(t) \le U_j(t)\}$$

$$\subseteq \{\mu^* \ge U_{j^*}(t)\} \cup \{I_{t+1} = j \text{ and } \mu^* < U_j(t)\}.$$

Also,

$$\{\mu^* < U_j(t)\} = \left\{ \mu^* < \sup \left\{ \mu \in \mu(\Theta) \text{ s.t. } d(\hat{\mu}_j(t), \mu) \le \frac{f(t)}{T_j(t)} \right\} \right\}$$

$$\subseteq \left\{ \hat{\mu}_j(t) \ge \mu^*_{f(t)/T_j(t)} \right\},$$

$$\subseteq \left\{ \hat{\mu}_j(t) \ge \mu^*_{f(n)/T_j(t)} \right\},$$

where <sup>µ</sup><sup>∗</sup>f(n)/Tj(t) := min <sup>µ</sup> : <sup>d</sup>(µ, <sup>µ</sup><sup>∗</sup>) <sup>≤</sup> <sup>f</sup>(n) <sup>T</sup><sup>j</sup> (t) .

$$\mathbb{E}T_j(n) = 1 + \sum_{t=k}^{n-1} \mathbb{P}\{I_{t+1} = j\}.$$

And

$$\sum_{t=k}^{n-1} \mathbb{P}\{\mu^* \ge U_{j^*}(t)\} \le \dots \le 3 + 4e \log \log n.$$

times upper bound violated

$$\begin{split} &\sum_{t=k}^{n-1} \mathbb{P} \left\{ I_{t+1} = j \text{ and } \hat{\mu}_{j}(t) \geq \mu_{f(n)/T_{j}(t)}^{*} \right\} \\ &= \sum_{t=k}^{n-1} \sum_{m=2}^{n-k+1} \mathbb{P} \left\{ \hat{\mu}_{j,m-1} \geq \mu_{f(n)/(m-1)}^{*} \text{ and } m \text{th } j \text{ at } t+1 \right\} \\ &\leq \sum_{m=1}^{n-k} \mathbb{P} \left\{ \hat{\mu}_{j,m} \geq \mu_{f(n)/m}^{*} \right\} \\ &\leq M + \sum_{m=M+1}^{n-k} \mathbb{P} \left\{ \hat{\mu}_{j,m} \geq \mu_{f(n)/m}^{*} \right\}, \end{split}$$

for  $M = f(n)/d(\mu_i, \mu^*)$ .

$$\sum_{m=M+1}^{n-k} \mathbb{P}\left\{\hat{\mu}_{j,m} \ge \mu_{f(n)/m}^*\right\} \le \sum_{m=M+1}^{n-k} \exp\left(-md\left(\mu_{f(n)/m}^*, \mu_j\right)\right)$$

•

$$= O\left(\sqrt{f(n)}\right).$$

(Relate  $d\left(\mu_{f(n)/m}^*, \mu_j\right)$  to  $d(\mu_j, \mu^*)$ , bound by integral, use Laplace's method.)

#### **Empirical KL-UCB Strategy:**

$$I_t = t$$
 for  $t = 1, \dots, k$ ,

$$I_t = \arg\max_{1 \le j \le k} \sup \left\{ \mathbb{E}_P X : |\operatorname{supp}(P)| < \infty, \right.$$

$$D_{KL}\left(\hat{P}_j(t-1), P\right) \le \frac{f(t)}{T_j(t-1)}$$
,

where  $\hat{P}_j(t-1)$  is the empirical distribution of the  $T_j(t-1)$  pulls of arm j up to time t-1, and  $f(t) = \log t + 3 \log \log(t)$ .

It turns out that it's always <sup>a</sup> finite convex optimization:

$$\sup \left\{ \mathbb{E}_{P}X : |\operatorname{supp}(P)| < \infty, D_{KL} \left( \hat{P}_{j}(t-1), P \right) \leq \gamma \right\}$$

$$= \sup \left\{ \mathbb{E}_{P}X : \operatorname{supp}(P) \subseteq \operatorname{supp}(\hat{P}_{j}(t-1)) \cup \{1\}, \right.$$

$$D_{KL} \left( \hat{P}_{j}(t-1), P \right) \leq \gamma \right\}.$$

#### **Empirical KL-UCB Strategy:**

$$I_t = t$$
 for  $t = 1, \dots, k$ ,

$$I_t = \arg \max_{1 \le j \le k} \sup \left\{ \mathbb{E}_P X : \operatorname{supp}(P) \subseteq \operatorname{supp}(\hat{P}_j(t-1)) \cup \{1\}, \right\}$$

$$D_{KL}\left(\hat{P}_j(t-1), P\right) \le \frac{f(t)}{T_j(t-1)}$$
,

where  $\hat{P}_j(t-1)$  is the empirical distribution of the  $T_j(t-1)$  pulls of arm j up to time t-1, and  $f(t) = \log t + 3 \log \log(t)$ .

**Theorem:** Empirical KL-UCB for rewards in [0, 1] satisfies:

$$\mathbb{E}T_j(n) \le \frac{\log n}{\inf\{D_{KL}(P_j, P) : PX > \mu^*\}} + O\left(\log^{4/5} n \log \log n\right),$$

provided  $\mu_j > 0$  and  $\mu^* < 1$ .

The leading term is optimal (including the constant). But the remainder term is worse than in the parametric case.