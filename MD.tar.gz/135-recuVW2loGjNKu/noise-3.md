# Fixed-length lossy compression in the finite blocklength regime

Victoria Kostina, *Student Member, IEEE*, Sergio Verdú, *Fellow, IEEE*Dept. of Electrical Engineering, Princeton University, NJ, 08544, USA.
Email: vkostina@princeton.edu, verdu@princeton.edu.

Abstract—This paper studies the minimum achievable source coding rate as a function of blocklength n and probability  $\epsilon$  that the distortion exceeds a given level d. Tight general achievability and converse bounds are derived that hold at arbitrary fixed blocklength. For stationary memoryless sources with separable distortion, the minimum rate achievable is shown to be closely approximated by  $R(d) + \sqrt{\frac{V(d)}{n}}Q^{-1}\left(\epsilon\right)$ , where R(d) is the rate-distortion function, V(d) is the rate-dispersion, a characteristic of the source which measures its stochastic variability, and  $Q^{-1}\left(\cdot\right)$  is the inverse of the standard Gaussian complementary cdf.

Index Terms—achievability, converse, finite blocklength regime, lossy source coding, memoryless sources, rate-distortion, Shannon theory.

#### I. Introduction

The rate-distortion function characterizes the minimal source coding rate compatible with a given distortion level, either in average or excess distortion sense, provided that the blocklength is permitted to grow without limit. However, in some applications relatively short blocklengths are common both due to delay and complexity constraints. It is therefore of critical practical interest to assess the unavoidable penalty over the rate-distortion function required to sustain the desired fidelity at a given fixed blocklength. Neither the lossy source coding theorem nor the reliability function, which gives the asymptotic exponential decay of the probability of exceeding a given distortion level when compressing at a fixed rate, provide an answer to that question.

This paper presents new achievability and converse bounds to the minimum sustainable rate as a function of blocklength and excess probability, valid for general sources and general distortion measures. In addition, for stationary memoryless sources with separable (i.e., additive, or per-letter) distortion, we show that the finite blocklength coding rate is well approximated by

<span id="page-0-2"></span>
$$R(n, d, \epsilon) \approx R(d) + \sqrt{\frac{V(d)}{n}} Q^{-1}(\epsilon),$$
 (1)

where n is the blocklength,  $\epsilon$  is the probability that the distortion incurred by the reproduction exceeds d, and V(d) is the  $\it rate-dispersion function$ . The evaluation of the new bounds is detailed for:

 the stationary discrete memoryless source (DMS) with symbol error rate distortion;

This research was supported in part by NSF under grants CCF-1016625 and CCF 09-39370. The first author was supported in part by the Natural Sciences and Engineering Research Council of Canada.

- the stationary Gaussian memoryless source (GMS) with mean-square error distortion;
- the stationary binary memoryless source when the compressor observes it through the binary erasure channel (BES), and the distortion measure is bit error rate.

In the most basic special case, namely that of the equiprobable source with symbol error rate distortion, the rate-dispersion function is zero, and the finite blocklength coding rate is approximated by

$$R(n, d, \epsilon) = R(d) + \frac{1}{2} \frac{\log n}{n} + O\left(\frac{1}{n}\right)$$
 (2)

Section II sets up the problem, introduces the definitions of the fundamental finite blocklengths limits and presents the basic notation and properties of the information density and related quantities used throughout the paper. Section III reviews the few existing finite blocklength achievability and converse bounds for lossy compression, as well as various relevant asymptotic refinements of Shannon's lossy source coding theorem. Section IV shows the new general upper and lower bounds to the minimum rate at a given blocklength. Section V studies the asymptotic behavior of the bounds using Gaussian approximation analysis. Sections VI, VII, VIII and IX focus on the binary memoryless source (BMS)<sup>1</sup>, DMS, BES and GMS, respectively.

#### II. PRELIMINARIES

#### <span id="page-0-0"></span>A. Operational definitions

In fixed-length lossy compression, the output of a general source with alphabet A and source distribution  $P_X$  is mapped to one of the M codewords from the reproduction alphabet B. A lossy code is a (possibly randomized) pair of mappings  $f \colon A \mapsto \{1,\ldots,M\}$  and  $c \colon \{1,\ldots,M\} \mapsto B$ . A distortion measure  $d \colon A \times B \mapsto [0,+\infty]$  is used to quantify the performance of a lossy code. Given decoder c, the best encoder simply maps the source output to the closest (in the sense of the distortion measure) codeword, i.e.  $f(x) = \arg\min_m d(x, c(m))$ . The average distortion over the source statistics is a popular performance criterion. A stronger criterion is also used, namely, the probability of exceeding a given distortion level (called excess-distortion probability). The following definitions abide by the excess distortion criterion.

<span id="page-0-1"></span><sup>1</sup>Although the results in Section VI are a special case of those in Section VII, it is enlightening to specialize our results to the simplest possible setting.

**Definition 1.** An  $(M,d,\epsilon)$  code for  $\{A, B, P_X, d: A \times B \mapsto [0,+\infty]\}$  is a code with |f| = M such that  $\mathbb{P}[d(X,c(f(X)))>d] \leq \epsilon$ .

The minimum achievable code size at excess-distortion probability  $\epsilon$  and distortion d is defined by

<span id="page-1-7"></span>
$$M^{\star}(d,\epsilon) = \min \{ M \colon \exists (M,d,\epsilon) \ code \}$$
 (3)

Note that the special case d=0 and d(x,y)=1  $\{x\neq y\}$  corresponds to almost-lossless compression.

**Definition 2.** In the conventional fixed-to-fixed (or block) setting in which A and B are the n-fold Cartesian products of alphabets A and B, an  $(M,d,\epsilon)$  code for  $\{A^n, B^n, P_{X^n}, d^n \colon A^n \times B^n \mapsto [0,+\infty]\}$  is called an  $(n,M,d,\epsilon)$  code.

Fix  $\epsilon$ , d and blocklength n. The minimum achievable code size and the finite blocklength rate-distortion function (excess distortion) are defined by, respectively

$$M^{\star}(n, d, \epsilon) = \min \{ M \colon \exists (n, M, d, \epsilon) \ code \}$$
 (4)

$$R(n,d,\epsilon) = \frac{1}{n} \log M^{\star}(n,d,\epsilon) \tag{5}$$

Alternatively, using an average distortion criterion, we employ the following notations.

**Definition 3.** An  $\langle M, d \rangle$  code for  $\{A, B, P_X, d: A \times B \mapsto [0, +\infty]\}$  is a code with |f| = M such that  $\mathbb{E}[d(X, c(f(X)))] \leq d$ . The minimum achievable code size at average distortion d is defined by

$$M^{\star}(d) = \min \{ M \colon \exists \langle M, d \rangle \ code \}$$
 (6)

**Definition 4.** If A and B are the n-fold Cartesian products of alphabets A and B, an  $\langle M, d \rangle$  code for  $\{A^n, B^n, P_{X^n}, d^n \colon A^n \times B^n \mapsto [0, +\infty]\}$  is called an  $\langle n, M, d \rangle$  code.

Fix d and blocklength n. The minimum achievable code size and the finite blocklength rate-distortion function (average distortion) are defined by, respectively

$$M^{\star}(n,d) = \min \{ M \colon \exists \langle n, M, d \rangle \ code \}$$
 (7)

$$R(n,d) = \frac{\log M^{\star}(n,d)}{n} \tag{8}$$

In the limit of long blocklengths, the minimum achievable rate is characterized by the rate-distortion function [1] [2].

**Definition 5.** The rate-distortion function is defined as

$$R(d) = \limsup_{n \to \infty} R(n, d) \tag{9}$$

In a similar manner, one can define the distortion-rate functions  $D(n, R, \epsilon)$ , D(n, R) and D(R).

In the review of prior work in Section III we will use the following concepts related to variable-length coding. A variable-length code is a pair of mappings  $f \colon A \mapsto \{0,1\}^*$  and  $c \colon \{0,1\}^* \mapsto B$ , where  $\{0,1\}^*$  is the set of all possibly empty binary strings. It is said to operate at distortion level d if  $\mathbb{P}\left[d(X,\mathsf{c}(\mathsf{f}(X))) \le d\right] = 1$ . For a given code  $(\mathsf{f},\mathsf{c})$  operating at distortion d, the length of the binary codeword assigned to  $x \in A$  is denoted by  $\ell(x) = \mathrm{length}$  of f(x).

<span id="page-1-9"></span>B. Tilted information

Denote by

$$i_{X;Y}(x;y) = \log \frac{dP_{XY}}{d(P_X \times P_Y)}(x,y)$$
 (10)

the information density of the joint distribution  $P_{XY}$  at  $(x,y) \in A \times B$ . Further, for a discrete random variable X, the information in outcome x is denoted by

<span id="page-1-2"></span>
$$i_X(x) = \log \frac{1}{P_X(x)} \tag{11}$$

Under appropriate conditions, the number of bits that it takes to represent x divided by  $i_X(x)$  converges to 1 as these quantities go to infinity. Note that if X is discrete, then  $i_{X:X}(x;x) = i_X(x)$ .

For a given  $P_X$  and distortion measure, denote

<span id="page-1-0"></span>
$$\mathbb{R}_X(d) = \inf_{\substack{P_{Y|X}:\\ \mathbb{E}[d(X,Y)] < d}} I(X;Y) \tag{12}$$

We impose the following basic restrictions on the source and the distortion measure.

<span id="page-1-8"></span>(a)  $\mathbb{R}_X(d)$  is finite for some d, i.e.  $d_{\min} < \infty$ , where

<span id="page-1-10"></span>
$$d_{\min} = \inf \left\{ d \colon \ \mathbb{R}_X(d) < \infty \right\} \tag{13}$$

<span id="page-1-13"></span>(b) The distortion measure is such that there exists a finite set  $E \subset B$  such that

$$\mathbb{E}\left[\min_{y\in E}d(X,y)\right]<\infty\tag{14}$$

<span id="page-1-4"></span>(c) The infimum in (12) is achieved by a unique  $P_{Y|X}^{\star}$ , and distortion measure is finite-valued. <sup>2</sup>

The counterpart of (11) in lossy data compression, which roughly corresponds to the number of bits one needs to spend to encode x within distortion d, is the following.

<span id="page-1-6"></span>**Definition 6** (d-tilted information). For  $d > d_{\min}$ , the d-tilted information in x is defined as

<span id="page-1-5"></span>
$$j_X(x,d) = \log \frac{1}{\mathbb{E}\left[\exp\left\{\lambda^* d - \lambda^* d(x, Y^*)\right\}\right]}$$
(15)

where the expectation is with respect to the unconditional distribution<sup>3</sup> of  $Y^*$ , and

$$\lambda^* = -\mathbb{R}'_{\mathcal{X}}(d) \tag{16}$$

It can be shown that (c) guarantees differentiability of  $\mathbb{R}_X(d)$ , thus (15) is well defined. A measure-theoretic proof of the following properties can be found in [3, Lemma 1.4].

Property 1. For  $P_{V}^{\star}$ -almost every y,

<span id="page-1-12"></span>
$$j_X(x,d) = i_{X;Y^*}(x;y) + \lambda^* d(x,y) - \lambda^* d \tag{17}$$

hence the name we adopted in Definition 6, and

<span id="page-1-11"></span>
$$\mathbb{R}_X(d) = \mathbb{E}\left[\jmath_X(X,d)\right] \tag{18}$$

 $^2$ Restriction (c) is imposed for clarity of presentation. We will show in Section V that it can be dispensed with.

<span id="page-1-3"></span><span id="page-1-1"></span> $^3\mathrm{Henceforth},\,Y^\star$  denotes the rate-distortion-achieving reproduction random variable at distortion d, i.e. its distribution  $P_Y^\star$  is the marginal of  $P_{Y|X}^\star P_X,$  where  $P_{Y|X}^\star$  achieves the infimum in (12).

Property 2. For all  $y \in B$ ,

<span id="page-2-9"></span>
$$\mathbb{E}\left[\exp\left\{\lambda^{\star}d - \lambda^{\star}d(X, y) + \jmath_X(X, d)\right\}\right] \le 1 \tag{19}$$

with equality for  $P_V^*$ -almost every y.

Remark 1. While Definition 6 does not cover the case  $d = d_{\min}$ , for discrete random variables with  $d(x, y) = 1 \{x \neq y\}$  it is natural to define 0-tilted information as

$$j_X(x,0) = i_X(x) \tag{20}$$

*Example* 1. For the BMS with bias  $p \leq \frac{1}{2}$  and bit error rate distortion,

<span id="page-2-13"></span>
$$j_{X^n}(x^n, d) = i_{X^n}(x^n) - nh(d)$$
(21)

if  $0 \le d < p$ , and 0 if  $d \ge p$ .

*Example* 2. For the GMS with variance  $\sigma^2$  and mean-square error distortion,<sup>4</sup>

<span id="page-2-14"></span>
$$j_{X^n}(x^n, d) = \frac{n}{2} \log \frac{\sigma^2}{d} + \left(\frac{|x^n|^2}{\sigma^2} - n\right) \frac{\log e}{2}$$
 (22)

if  $0 < d < \sigma^2$ , and 0 if  $d \ge \sigma^2$ .

The distortion d-ball around x is denoted by

$$B_d(x) = \{ y \in B : \ d(x, y) \le d \}$$
 (23)

Tilted information is closely related to the (unconditional) probability that  $Y^*$  falls within distortion d from X. Indeed, since  $\lambda^* > 0$ , for an arbitrary  $P_Y$  we have by Markov's inequality,

$$P_Y(B_d(x)) = \mathbb{P}\left[d(x,Y) \le d\right] \tag{24}$$

$$\leq \mathbb{E}\left[\exp\left\{\lambda^{\star}d - \lambda^{\star}d(x,Y)\right\}\right]$$
 (25)

where the probability measure is generated by the unconditional distribution of Y. Thus

<span id="page-2-2"></span>
$$\log \frac{1}{P_V^{\star}(B_d(x))} \ge j_X(x, d) \tag{26}$$

As we will see in Theorem 6, under certain regularity conditions the equality in (26) can be closely approached.

#### <span id="page-2-10"></span>C. Generalized tilted information

Often it is more convenient [4] to fix  $P_Y$  defined on B and to consider, in lieu of (12), the following optimization problem:

<span id="page-2-3"></span>
$$\mathbb{R}_{X,Y}(d) = \min_{\substack{P_{Z|X}:\\\mathbb{E}[d(X;Z)] \le d}} D(P_{Z|X} || P_Y | P_X)$$
 (27)

In parallel with Definition 6, define for any  $\lambda \geq 0$ 

<span id="page-2-12"></span>
$$\Lambda_Y(x,\lambda) = \log \frac{1}{\mathbb{E}\left[\exp\left(\lambda d - \lambda d(x,Y)\right)\right]}$$
 (28)

As long as  $d > d_{\min|X,Y}$ , where

$$d_{\min|X,Y} = \inf \left\{ d \colon \ \mathbb{R}_{X,Y}(d) < \infty \right\} \tag{29}$$

<span id="page-2-1"></span><sup>4</sup>We denote the Euclidean norm by  $|\cdot|$ , i.e.  $|x^n|^2 = x_1^2 + \ldots + x_n^2$ .

the minimum in (27) is always achieved by a  $P_{Z^*|X}$  that satisfies [3]

$$\log \frac{dP_{Z^*|X}(y|x)}{dP_Y(y)}$$

$$= \log \frac{\exp\left(-\lambda_{X,Y}^* d(x,y)\right)}{\mathbb{E}\left[\exp\left(-\lambda_{X,Y}^* d(x,Y)\right)\right]}$$
(30)

$$= \Lambda_Y(x, \lambda_{X,Y}^{\star}) - \lambda_{X,Y}^{\star} d(x, y) + \lambda_{X,Y}^{\star} d \tag{31}$$

<span id="page-2-0"></span>where

<span id="page-2-11"></span>
$$\lambda_{X,Y}^{\star} = -\mathbb{R}_{X,Y}^{\prime}(d) \tag{32}$$

#### III. PRIOR WORK

In this section, we summarize the main available bounds on the fixed-blocklength fundamental limits of lossy compression and we review the main relevant asymptotic refinements to Shannon's lossy source coding theorem.

#### A. Achievability bounds

Returning to the general setup of Definition 1, the basic general achievability result can be distilled [5] from Shannon's coding theorem for memoryless sources:

<span id="page-2-4"></span>**Theorem 1** (Achievability, [2] [5]). Fix  $P_X$ , a positive integer M and  $d \ge d_{\min}$ . There exists an  $(M, d, \epsilon)$  code such that

$$\epsilon \leq \inf_{P_{Y|X}} \left\{ \mathbb{P}\left[d\left(X,Y\right) > d\right] + \inf_{\gamma > 0} \left\{ \mathbb{P}\left[i_{X;Y}\left(X;Y\right) > \log M - \gamma\right] + e^{-\exp(\gamma)} \right\} \right\}$$
(33)

<span id="page-2-8"></span>Theorem 1 is the most general existing achievability result (i.e. existence result of a code with a guaranteed upper bound on error probability). In particular, it allows us to deduce that for stationary memoryless sources with separable distortion measure, i.e. when  $P_{X^n} = P_X \times \ldots \times P_X$ ,  $d(x^n, y^n) = \frac{1}{n} \sum_{i=1}^n d(x_i, y_i)$ , it holds that

<span id="page-2-7"></span><span id="page-2-6"></span><span id="page-2-5"></span>
$$\limsup R(n,d) \le \mathbb{R}_{\mathsf{X}}(d) \tag{34}$$

$$\limsup_{n \to \infty} R(n, d, \epsilon) \le \mathbb{R}_{\mathsf{X}}(d) \tag{35}$$

where  $\mathbb{R}_{\mathsf{X}}(d)$  is defined in (12), and  $0 < \epsilon < 1$ .

For three particular setups of i.i.d. sources with separable distortion measure, we can cite the achievability bounds of Goblick [6] (fixed-rate compression of a finite alphabet source), Pinkston [7] (variable-rate compression of a finite-alphabet source) and Sakrison [8] (variable-rate compression of a Gaussian source with mean-square error distortion). Sakrison's achievability bound is summarized below as the least cumbersome of the aforementioned:

**Theorem 2** (Achievability, [8]). Fix blocklength n, and let  $X^n$  be a Gaussian vector with independent components of variance  $\sigma^2$ . There exists a variable-length code achieving average mean-square error d such that

$$\mathbb{E}\left[\ell(X^n)\right] \le -\frac{n-1}{2}\log\left(\frac{d}{\sigma^2} - \frac{1}{1.2n}\right) + \frac{1}{2}\log n + \log 4\pi + \frac{2}{3}\log e + \frac{5\log e}{12(n+1)}$$
(36)

#### B. Converse bounds

The basic converse used in conjunction with (33) to prove the rate-distortion fundamental limit with average distortion is the following simple result, which follows immediately from the data processing lemma for mutual information:

<span id="page-3-1"></span>**Theorem 3** (Converse, [2]). Fix  $P_X$ , integer M and  $d \ge d_{\min}$ . Any  $\langle M, d \rangle$  code must satisfy

$$\mathbb{R}_X(d) < \log M \tag{37}$$

where  $\mathbb{R}_X(d)$  is defined in (12).

Shannon [2] showed that in the case of stationary memoryless sources with separable distortion,  $\mathbb{R}_{X^n}(d) = n\mathbb{R}_X(d)$ . Using Theorem 3, it follows that for such sources,

$$\mathbb{R}_{\mathsf{X}}(d) \le R(n, d) \tag{38}$$

for any blocklength n and any  $d>d_{\min}$ , which together with (34) gives

$$R(d) = \mathbb{R}_{\mathsf{X}}(d) \tag{39}$$

The strong converse for lossy source coding [9], [10] states that if the compression rate R is fixed and  $R < \mathbb{R}_X(d)$ , then  $\epsilon \to 1$  as  $n \to \infty$ , which together with (35) yields that for i.i.d. sources with separable distortion and any  $0 < \epsilon < 1$ ,

$$\limsup_{n \to \infty} R(n, d, \epsilon) = \mathbb{R}_{\mathsf{X}}(d) = R(d) \tag{40}$$

For prefix-free variable-length lossy compression, the key non-asymptotic converse was obtained by Kontoyiannis [11] (see also [12] for a lossless compression counterpart).

**Theorem 4** (Converse, [11]). Assume that the infimum in the right side of (12) is achieved by some conditional distribution  $P_{Y|X}^{\star}$ . If a prefix-free variable-length code for  $P_X$  operates at distortion level d, then for any  $\gamma > 0$ ,

$$\mathbb{P}\left[\ell(X) \le j_X(X, d) - \gamma\right] \le 2^{-\gamma} \tag{41}$$

For DMS with finite alphabet and bounded separable distortion measure, a finite blocklength converse can be distilled from Marton's fixed-rate lossy compression error exponent [13]:

<span id="page-3-2"></span>**Theorem 5** (Converse, [13]). Consider a DMS with finite input and reproduction alphabets, source distribution P and separable distortion measure with  $\max_x \min_y d(x,y) = 0$ ,  $\Delta_{\max} = \max_{x,y} d(x,y) < +\infty$ . Fix  $0 < d < \Delta_{\max}$ . Let the corresponding rate-distortion and distortion-rate functions be denoted by  $R_P(d)$  and  $D_P(R)$ , respectively. Fix an arbitrary  $(n, M, d, \epsilon)$  code.

• If the code rate  $R = \frac{\log M}{r}$  satisfies

$$R < R_P(d), \tag{42}$$

then the excess-distortion probability is bounded away from zero:

$$\epsilon \ge \frac{D_P(R) - d}{\Delta_{max} - d},\tag{43}$$

 $\bullet$  If R satisfies

$$R_P(d) < R < \max_Q R_Q(d), \tag{44}$$

where the maximization is over the set of all probability distributions on A, then

<span id="page-3-5"></span>
$$\epsilon \ge \sup_{\delta > 0, Q} \left( \frac{D_Q(R) - d}{\Delta_{\max} - d} - Q^n(G_{\delta, n}{}^c) \right) \cdot \exp\left( -n \left( D(Q \| P) + \delta \right) \right), \tag{45}$$

where the supremization is over all probability distributions on A satisfying  $R_Q(d) > R$ , and

$$G_{\delta,n} = \left\{ x^n \in \mathcal{A}^n : \frac{1}{n} \log \frac{Q^n(x^n)}{P^n(x^n)} \le D(Q||P) + \delta \right\}$$

It turns out that the converse in Theorem 5 results in rather loose lower bounds on  $R(n,d,\epsilon)$  unless n is very large, in which case the rate-distortion function already gives a tight lower bound. Generalizations of the error exponent results in [13] are found in [14]–[18].

#### C. Gaussian Asymptotic Approximation

The "lossy asymptotic equipartition property (AEP)" [19], which leads to strong achievability and converse bounds for variable-rate quantization, is concerned with the almost sure asymptotic behavior of the distortion d-balls. Second-order refinements of the "lossy AEP" were studied in [11], [20], [21].<sup>5</sup>

<span id="page-3-0"></span>**Theorem 6** ("Lossy AEP"). For memoryless sources with separable distortion measure satisfying the regularity restrictions (i)–(iv) in Section V,

$$\log \frac{1}{P_{Y^n}^{\star}(B_d(X^n))} = \sum_{i=1}^n \jmath_{\mathsf{X}}(X_i, d) + \frac{1}{2}\log n + O(\log\log n)$$

almost surely.

*Remark* 2. Note the different behavior of almost lossless data compression:

$$\log \frac{1}{P_{Y^n}^{\star}(B_0(X^n))} = \log \frac{1}{P_{X^n}(X^n)} = \sum_{i=1}^n \imath_{\mathsf{X}}(X_i) \quad (46)$$

Kontoyiannis [11] pioneered the second-order refinement of the variable-length rate-distortion function showing that for memoryless sources with separable distortion measures the optimum prefix-free description length at distortion level dsatisfies

$$\ell^{\star}(X^n) = nR(d) + \sqrt{n}G_n + O(\log n) \quad a.s. \tag{47}$$

where  $G_n$  converges in distribution to a Gaussian random variable with zero mean and variance equal to the rate-dispersion function defined in Section V.

<span id="page-3-4"></span><span id="page-3-3"></span><sup>&</sup>lt;sup>5</sup>The result of Theorem 6 was pointed out in [11, Proposition 3] as a simple corollary to the analyses in [20], [21]. See [22] for a generalization to  $\alpha$ -mixing sources.

<span id="page-4-5"></span><span id="page-4-4"></span>

#### D. Asymptotics of redundancy

Considerable attention has been paid to the asymptotic behavior of the redundancy, i.e. the difference between the average distortion D(n,R) of the best n-dimensional quantizer and the distortion-rate function D(R). For finite-alphabet i.i.d. sources, Pilc [23] strengthened the positive lossy source coding theorem by showing that

<span id="page-4-1"></span>
$$D(n,R) - D(R) \le -\frac{\partial D(R)}{\partial R} \frac{\log n}{2n} + o\left(\frac{\log n}{n}\right)$$
 (48)

Zhang, Yang and Wei [24] proved a converse to (48), thereby showing that for memoryless sources with finite alphabet,

$$D(n,R) - D(R) = -\frac{\partial D(R)}{\partial R} \frac{\log n}{2n} + o\left(\frac{\log n}{n}\right)$$
 (49)

Using a geometric approach akin to that of Sakrison [8], Wyner [25] showed that (48) also holds for stationary Gaussian sources with mean-square error distortion, while Yang and Zhang [20] extended (48) to abstract alphabets. Note that as the average overhead over the distortion-rate function is dwarfed by its standard deviation, the analyses of [20], [23]–[25] are bound to be overly optimistic since they neglect the stochastic variability of the distortion.

#### <span id="page-4-0"></span>IV. NEW FINITE BLOCKLENGTH BOUNDS

In this section we give achievability and converse results for any source and any distortion measure according to the setup of Section II. When we apply these results in Sections V - IX, the source X becomes an n-tuple  $(X_1, \ldots, X_n)$ .

#### A. Converse bounds

Our first result is a general converse bound.

<span id="page-4-6"></span>**Theorem 7** (Converse). Assume the basic conditions (a)–(c) in Section II are met. Fix  $d > d_{\min}$ . Any  $(M, d, \epsilon)$  code must satisfy

<span id="page-4-9"></span>
$$\epsilon \ge \sup_{\gamma > 0} \left\{ \mathbb{P} \left[ j_X(X, d) \ge \log M + \gamma \right] - \exp(-\gamma) \right\}$$
 (50)

*Proof.* Let the encoder and decoder be the random transformations  $P_{Z|X}$  and  $P_{Y|Z}$ , where Z takes values in  $\{1,\ldots,M\}$ . Let  $Q_Z$  be equiprobable on  $\{1,\ldots,M\}$ , and let  $Q_Y$  denote

the marginal of  $P_{Y|Z}Q_Z$ . We have<sup>6</sup>, for any  $\gamma \geq 0$ 

$$\mathbb{P}\left[\jmath_X(X,d) \ge \log M + \gamma\right] \tag{51}$$

$$= \mathbb{P}\left[\jmath_X(X, d) \ge \log M + \gamma, d(X, Y) > d\right]$$

$$+ \mathbb{P}\left[j_X(X,d) \ge \log M + \gamma, d(X,Y) \le d\right] \tag{52}$$

$$\leq \epsilon + \sum_{x \in A} P_X(x) \sum_{z=1}^M P_{Z|X}(z|x)$$

$$\cdot \sum_{y \in B_d(x)} P_{Y|Z}(y|z) 1 \left\{ M \le \exp\left(j_X(x,d) - \gamma\right) \right\}$$
 (53)

$$\leq \epsilon + \exp(-\gamma) \sum_{x \in A} P_X(x) \exp(j_X(x, d))$$

<span id="page-4-3"></span>
$$\cdot \sum_{z=1}^{M} \frac{1}{M} \sum_{y \in B_d(x)} P_{Y|Z}(y|z)$$
 (54)

$$= \epsilon + \exp(-\gamma) \sum_{x \in A} P_X(x) \exp(j_X(x,d)) Q_Y(B_d(x))$$
 (55)

$$\leq \epsilon + \exp(-\gamma) \sum_{y \in B} Q_Y(y)$$

$$\cdot \sum_{x \in A} P_X(x) \exp\left(\lambda^* d - \lambda^* d(x, y) + j_X(x, d)\right)$$
 (56)

$$\leq \epsilon + \exp\left(-\gamma\right) \tag{57}$$

where

• (54) follows by upper-bounding

$$P_{Z|X}(z|x)1\{M \le \exp(\jmath_X(x,d) - \gamma)\}$$

$$\le \frac{\exp(-\gamma)}{M} \exp(\jmath_X(x,d))$$
(58)

for every  $(x, z) \in A \times \{1, \dots, M\}$ ,

- (56) uses (25) particularized to Y distributed according to  $Q_Y$ , and
- (57) is due to (19).

Remark 3. Theorem 7 gives a pleasing generalization of the almost-lossless data compression converse bound [5], [26, Lemma 1.3.2]. In fact, skipping (56), the above proof applies to the case d=0 and d(x,y)=1  $\{x\neq y\}$  that corresponds to almost-lossless data compression.

*Remark* 4. As explained in Appendix C, condition (c) can be dropped from the assumptions of Theorem 7.

Our next converse result, which is tighter than the one in Theorem 7 in some cases, is based on binary hypothesis testing. The optimal performance achievable among all randomized tests  $P_{W|X}\colon A\to\{0,1\}$  between probability distributions P and Q on A is denoted by (1 indicates that the test chooses P):

<span id="page-4-8"></span>
$$\beta_{\alpha}(P,Q) = \min_{\substack{P_{W|X}:\\\mathbb{P}[W=1] \ge \alpha}} \mathbb{Q}[W=1]$$
 (59)

<sup>6</sup>We write summations over alphabets for simplicity. All our results in Sections IV and V hold for arbitrary probability spaces.

<span id="page-4-7"></span><span id="page-4-2"></span><sup>7</sup>Throughout, P, Q denote distributions, whereas  $\mathbb{P}$ ,  $\mathbb{Q}$  are used for the corresponding probabilities of events on the underlying probability space.

<span id="page-5-1"></span>**Theorem 8** (Converse). Let  $P_X$  be the source distribution defined on the alphabet A. Any  $(M, d, \epsilon)$  code must satisfy

<span id="page-5-0"></span>
$$M \ge \sup_{Q} \inf_{y \in B} \frac{\beta_{1-\epsilon}(P_X, Q)}{\mathbb{Q}\left[d(X, y) \le d\right]} \tag{60}$$

where the supremum is over all distributions on A.

*Proof.* Let  $(P_{Z|X}, P_{Y|Z})$  be an  $(M, d, \epsilon)$  code. Fix a distribution Q on A, and observe that W = 1  $\{d(X, Y) \leq d\}$  defines a (not necessarily optimal) hypothesis test between  $P_X$  and Q with  $\mathbb{P}[W=1] \geq 1 - \epsilon$ . Thus,

$$\beta_{1-\epsilon}(P_X, Q) \le \sum_{x \in A} Q_X(x) \sum_{m=1}^M P_{Z|X}(m|x) \sum_{y \in B} P_{Y|Z}(y|m) 1\{d(x, y) \le d\}$$

$$\leq \sum_{m=1}^{M} \sum_{y \in B} P_{Y|Z}(y|m) \sum_{x \in A} Q_X(x) 1\{d(x,y) \leq d\}$$
 (61)

$$\leq \sum_{m=1}^{M} \sum_{y \in B} P_{Y|Z}(y|m) \sup_{y \in B} \mathbb{Q}\left[d(X,y) \leq d\right]$$
 (62)

$$= M \sup_{y \in B} \mathbb{Q}\left[d(X, y) \le d\right] \tag{63}$$

Suppose for a moment that X takes values on a finite alphabet, and let us further lower bound (60) by taking Q to be the equiprobable distribution on A, Q = U. Consider the set  $\Omega \subset A$  that has total probability  $1 - \epsilon$  and contains the most probable source outcomes, i.e. for any source outcome  $x \in \Omega$ , there is no element outside  $\Omega$  having probability greater than  $P_X(x)$ . For any  $x \in \Omega$ , the optimum binary hypothesis test (with error probability  $\epsilon$ ) between  $P_X$  and Q must choose  $P_X$ . Thus the numerator of (60) evaluated with Q = U is proportional to the number of elements in  $\Omega$ , while the denominator is proportional to the number of elements in a distortion ball of radius d. Therefore (60) evaluated with Q = U yields a lower bound to the minimum number of d-balls required to cover  $\Omega$ .

Remark 5. In general, the lower bound in Theorem 8 is not achievable due to overlaps between distortion d-balls that comprise the covering. One special case when it is in fact achievable is almost lossless data compression on a countable alphabet A. To encompass that case, it is convenient to relax the restriction in (59) that requires Q to be a probability measure and allow it to be a  $\sigma$ -finite measure, so that  $\beta_{\alpha}(P_X,Q)$  is no longer bounded by 1.8 Note that Theorem 8 would still hold. Letting U to be the counting measure on A (i.e. U assigns unit weight to each letter), we have (Appendix A)

<span id="page-5-3"></span>
$$\beta_{1-\epsilon}(P_X, U) \le M^*(0, \epsilon) \le \beta_{1-\epsilon}(P_X, U) + 1 \tag{64}$$

The lower bound in (64) is satisfied with equality whenever  $\beta_{1-\epsilon}(P_X,U)$  is achieved by a non-randomized test.

#### B. Achievability bounds

The following result gives an exact analysis of the excess probability of random coding, which holds in full generality.

<span id="page-5-5"></span>**Theorem 9** (Exact performance of random coding). Denote by  $\epsilon_d(c_1, \ldots, c_M)$  the probability of exceeding distortion level d achieved by the optimum encoder with codebook  $(c_1, \ldots, c_M)$ . Let  $Y_1, \ldots, Y_M$  be independent, distributed according to an arbitrary distribution on the reproduction alphabet  $P_Y$ . Then

<span id="page-5-10"></span>
$$\mathbb{E}\left[\epsilon_d\left(Y_1,\dots,Y_M\right)\right] = \mathbb{E}\left[1 - P_Y(B_d(X))\right]^M \tag{65}$$

*Proof.* Upon observing the source output x, the optimum encoder chooses arbitrarily among the members of the set

$$\arg\min_{i=1,\ldots,M} d(x,c_i)$$

The indicator function of the event that the distortion exceeds d is

$$1\left\{\min_{i=1,\dots,M} d(x,c_i) > d\right\} = \prod_{i=1}^{M} 1\left\{d(x,c_i) > d\right\}$$
 (66)

Averaging over both the input X and the choice of codewords chosen independently of X, we get

$$\mathbb{E}\left[\prod_{i=1}^{M} 1\left\{d(X, Y_i) > d\right\}\right]$$

$$= \mathbb{E}\left[\mathbb{E}\left[\prod_{i=1}^{M} 1\left\{d(X, Y_i) > d\right\} | X\right]\right]$$

$$- \mathbb{E}\left[\mathbb{E}\left[\prod_{i=1}^{M} 1\left\{d(X, Y_i) > d\right\} | X\right]\right]$$
(68)

<span id="page-5-4"></span>
$$= \mathbb{E} \prod_{i=1}^{M} \mathbb{E} \left[ 1 \left\{ d(X, Y_i) > d \right\} | X \right]$$
 (68)

$$= \mathbb{E}\left(\mathbb{P}\left[d(X,Y) > d|X\right]\right)^{M} \tag{69}$$

where in (68) we have used the fact that  $Y_1, \ldots, Y_M$  are independent even when conditioned on X.

Invoking Shannon's random coding argument, the following achievability result follows immediately from Theorem 9.

<span id="page-5-7"></span>**Theorem 10** (Achievability). There exists an  $(M, d, \epsilon)$  code with

<span id="page-5-6"></span>
$$\epsilon \le \inf_{P_Y} \mathbb{E} \left[ 1 - P_Y(B_d(X)) \right]^M \tag{70}$$

where the infimization is over all random variables defined on B, independent of X.

While the right side of (70) gives the exact performance of random coding, Shannon's random coding bound (Theorem 1) was obtained by upper bounding the performance of random coding. As a consequence, the result in Theorem 10 is tighter than Shannon's random coding bound (Theorem 1), but it is also harder to compute.

Applying  $(1-x)^M \leq e^{-Mx}$  to (70), one obtains the following more numerically stable bound.

<span id="page-5-8"></span>**Corollary 11** (Achievability). There exists an  $(M, d, \epsilon)$  code with

<span id="page-5-9"></span>
$$\epsilon \le \inf_{P_Y} \mathbb{E}\left[e^{-MP_Y(B_d(X))}\right]$$
(71)

<span id="page-5-2"></span> $<sup>^8</sup>$ The Neyman-Pearson lemma generalizes to  $\sigma$ -finite measures.

where the infimization is over all random variables defined on B, independent of X.

The last result in this section will come handy in the analysis of the bound in Theorem 10 (see Section II-C for related notation).

**Lemma 1.** For an arbitrary  $P_Y$  on B,

$$P_Y(B_d(x)) \ge \sup_{P_{\hat{X}}, \gamma > 0} \exp\left(-\Lambda_Y(x, \lambda_{\hat{X}, Y}^*) - \lambda_{\hat{X}, Y}^*\gamma\right)$$
$$\cdot \mathbb{P}\left[d - \gamma < d(x, \hat{Z}^*) \le d | \hat{X} = x\right]$$
(72)

where the supremization is over all  $P_{\hat{X}}$  on A such that  $d_{\min|\hat{X},Y} < d$ , and  $\hat{Z}^*$  achieves  $\mathbb{R}_{\hat{X},Y}(d)$ .

*Proof.* We streamline the treatment in [20, (3.26)]. Fix  $\gamma > 0$  and distribution  $P_{\hat{X}}$  on the input alphabet A. We have

$$= \sum_{y \in B_d(x)} P_Y(y) \tag{73}$$

$$\geq \sum_{y \in B_d(x) \setminus B_{d-\gamma}(x)} P_Y(y) \tag{74}$$

$$\geq \exp\left(-\lambda_{\hat{X},Y}^{\star}\gamma\right) \cdot \sum_{y \in B_{d}(x) \setminus B_{d-\gamma}(x)} P_{Y}(y) \exp\left(\lambda_{\hat{X},Y}^{\star}d - \lambda_{\hat{X},Y}^{\star}d(x,y)\right)$$

$$= \exp\left(-\Lambda_{Y}(x, \lambda_{\hat{X}, Y}^{\star}) - \lambda_{\hat{X}, Y}^{\star}\gamma\right) \cdot \sum_{y \in B_{d}(x) \setminus B_{d-x}(x)} P_{\hat{Z}^{\star} | \hat{X} = x}(y)$$

$$(76)$$

$$= \exp\left(-\Lambda_Y(x, \lambda_{\hat{X}, Y}^{\star}) - \lambda_{\hat{X}, Y}^{\star}\gamma\right)$$

$$\mathbb{P}\left[d - \gamma < d(x, \hat{Z}^{\star}) \le d|\hat{X} = x\right]$$
(77)

where (75) holds because  $y \notin B_{d-\gamma}(x)$  implies

$$\lambda d - \lambda d(x, y) - \lambda \gamma \le 0 \tag{78}$$

<span id="page-6-0"></span>for all  $\lambda > 0$ , and (76) takes advantage of (31).

#### V. GAUSSIAN APPROXIMATION

#### A. Rate-dispersion function

In the spirit of [27], we introduce the following definition.

**Definition 7.** Fix  $d \geq d_{\min}$ . The rate-dispersion function (squared information units per source output) is defined as

$$V(d) = \lim_{\epsilon \to 0} \limsup_{n \to \infty} n \left( \frac{R(n, d, \epsilon) - R(d)}{Q^{-1}(\epsilon)} \right)^2$$
 (79)

$$= \lim_{\epsilon \to 0} \limsup_{n \to \infty} \frac{n \left( R(n, d, \epsilon) - R(d) \right)^2}{2 \log_e \frac{1}{\epsilon}}$$
 (80)

Fix d,  $0 < \epsilon < 1$ ,  $\eta > 0$ , and suppose the target is to sustain the probability of exceeding distortion d bounded by  $\epsilon$  at rate  $R = (1 + \eta)R(d)$ . As (1) implies, the required blocklength scales linearly with rate dispersion:

<span id="page-6-14"></span>
$$n(d, \eta, \epsilon) \approx \frac{V(d)}{R^2(d)} \left(\frac{Q^{-1}(\epsilon)}{\eta}\right)^2$$
 (81)

where note that only the first factor depends on the source, while the second depends only on the design specifications.

#### <span id="page-6-16"></span>B. Main result

In addition to the basic conditions (a)-(c) of Section II-B, in the remainder of this section we impose the following restrictions on the source and on the distortion measure.

- <span id="page-6-1"></span>(i) The source  $\{X_i\}$  is stationary and memoryless,  $P_{X^n} = P_X \times ... \times P_X$ .
- <span id="page-6-17"></span><span id="page-6-12"></span>(ii) The distortion measure is separable,  $d(x^n, y^n) = \frac{1}{n} \sum_{i=1}^n d(x_i, y_i)$ .
- <span id="page-6-18"></span>(iii) The distortion level satisfies  $d_{\min} < d < d_{\max}$ , where  $d_{\min}$  is defined in (13), and  $d_{\max} = \inf_{\mathbf{y} \in \mathcal{B}} \mathbb{E}[d(\mathbf{X}, \mathbf{y})]$ , where averaging is with respect to the unconditional distribution of X. The excess-distortion probability satisfies  $0 < \epsilon < 1$ .
- <span id="page-6-2"></span>(iv)  $\mathbb{E}\left[d^9(X, Y^*)\right] < \infty$  where averaging is with respect to  $P_X \times P_{Y^*}$ .

The main result in this section is the following<sup>9</sup>.

<span id="page-6-9"></span>**Theorem 12** (Gaussian approximation). *Under restrictions* (i)–(iv),

$$R(n, d, \epsilon) = R(d) + \sqrt{\frac{V(d)}{n}} Q^{-1}(\epsilon) + \theta\left(\frac{\log n}{n}\right)$$
 (82)

$$V(d) = \text{Var}\left[\jmath_{\mathsf{X}}(\mathsf{X}, d)\right] \tag{83}$$

<span id="page-6-3"></span>and the remainder term in (82) satisfies

<span id="page-6-13"></span><span id="page-6-8"></span><span id="page-6-6"></span>
$$-\frac{1}{2}\frac{\log n}{n} + O\left(\frac{1}{n}\right) \le \theta\left(\frac{\log n}{n}\right) \tag{84}$$

$$\leq C \frac{\log n}{n} + \frac{\log \log n}{n} + O\left(\frac{1}{n}\right) \tag{85}$$

<span id="page-6-4"></span>where

<span id="page-6-10"></span><span id="page-6-7"></span>
$$C = \frac{1}{2} + \frac{\operatorname{Var}\left[\Lambda'_{Y^{\star}}(\mathsf{X}, \lambda^{\star})\right]}{\mathbb{E}\left[|\Lambda''_{Y^{\star}}(\mathsf{X}, \lambda^{\star})|\right] \log e}$$
 (86)

In (86),  $(\cdot)'$  denotes differentiation with respect to  $\lambda$ ,  $\Lambda_{Y^*}(x, \lambda)$  is defined in (28), and  $\lambda^* = -R'(d)$ .

*Remark* 6. Since the rate-distortion function can be expressed as (see (18) in Section II)

<span id="page-6-15"></span>
$$R(d) = \mathbb{E}\left[ \gamma_{\mathsf{X}}(\mathsf{X}, d) \right] \tag{87}$$

it is equal to the expectation of the random variable whose variance we take in (83), thereby drawing a pleasing parallel with the channel coding results in [27].

Remark 7. For almost lossless data compression, Theorem 12 still holds as long as the random variable  $i_X(X)$  has finite third moment. Moreover, using (64) the upper bound in (85) can be strengthened (Appendix B) to obtain for  $\text{Var}\left[i_X(X)\right] > 0$ 

<span id="page-6-11"></span>
$$R(n, 0, \epsilon) = H(\mathsf{X}) + \sqrt{\frac{\operatorname{Var}\left[\imath_{\mathsf{X}}(\mathsf{X})\right]}{n}} Q^{-1}\left(\epsilon\right) - \frac{1}{2} \frac{\log n}{n} + O\left(\frac{1}{n}\right)$$
(88)

<span id="page-6-5"></span><sup>9</sup>Recently, using an approach based on typical sequences and error exponents, Ingber and Kochman [28] independently found the dispersion of finite alphabet sources. The Gaussian i.i.d. source with mean-square error distortion was treated separately in [28]. The result of Theorem 12 is more general as it applies to sources with abstract alphabets.

which is consistent with the second-order refinement for almost lossless data compression developed in [29]. If  $\operatorname{Var}\left[\imath_X(X)\right]=0$ , then

<span id="page-7-0"></span>
$$R(n,0,\epsilon) = H(\mathsf{X}) - \frac{1}{n} \log \frac{1}{1-\epsilon} + o_n \tag{89}$$

where

$$0 \le o_n \le \frac{\exp\left(-nH(\mathsf{X})\right)}{(1-\epsilon)n} \tag{90}$$

As we will see in Section VI, in contrast to the lossless case in (88), the remainder term in the lossy case in (82) can be strictly larger than  $-\frac{1}{2}\frac{\log n}{n}$  appearing in (88) even when V(d)>0.

Remark 8. As will become apparent in the proof of Theorem 12, if V(d) = 0, the lower bound in (82) can be strengthened non-asymptotically:

<span id="page-7-5"></span>
$$R(n, d, \epsilon) \ge R(d) - \frac{1}{n} \log \frac{1}{1 - \epsilon}$$
 (91)

which aligns nicely with (89).

Remark 9. Let us consider what happens if we drop restriction (c) of Section II-B that R(d) is achieved by the unique conditional distribution  $P_{Y|X}^{\star}$ . If several  $P_{Y|X}$  achieve R(d), writing  $j_{X;Y}(x,d)$  for the d-tilted information corresponding to Y, Theorem 12 still holds with

$$V(d) = \begin{cases} \max \operatorname{Var} \left[ \jmath_{\mathsf{X};\mathsf{Y}}(\mathsf{X},d) \right] & 0 < \epsilon \le \frac{1}{2} \\ \min \operatorname{Var} \left[ \jmath_{\mathsf{X};\mathsf{Y}}(\mathsf{X},d) \right] & \frac{1}{2} < \epsilon < 1 \end{cases}$$
(92)

where the optimization is performed over all  $P_{Y|X}$  that achieve the rate-distortion function. Moreover, as explained in Appendix C, Theorem 7 and the converse part of Theorem 12 do not even require existence of a minimizing  $P_{Y|X}^{\star}$ .

Let us consider three special cases where V(d) is constant as a function of d.

a) Zero dispersion. For a particular value of d, V(d)=0 if and only if  $\jmath_{\mathsf{X}}(\mathsf{X},d)$  is deterministic with probability 1. In particular, for finite alphabet sources, V(d)=0 if the source distribution  $P_{\mathsf{X}}$  maximizes  $\mathbb{R}_{\mathsf{X}}(d)$  over all source distributions defined on the same alphabet [28]. Moreover, Dembo and Kontoyiannis [30] showed that under mild conditions, the rate-dispersion function can only vanish for at most finitely many distortion levels d unless the source is equiprobable and the distortion matrix is symmetric with rows that are permutations of one another, in which case V(d)=0 for all  $d\in (d_{\min}, d_{\max})$ .

b) Binary source with bit error rate distortion. Plugging n=1 into (21), we observe that the rate-dispersion function reduces to the varentropy [5] of the source,

$$V(d) = V(0) = \operatorname{Var}\left[\imath_{\mathsf{X}}(\mathsf{X})\right] \tag{93}$$

c) Gaussian source with mean-square error distortion. Plugging n=1 into (22), we see that

$$V(d) = \frac{1}{2}\log^2 e \tag{94}$$

for all  $0 < d < \sigma^2$ . Similar to the BMS case, the rate dispersion is equal to the variance of  $\log f_X(X)$ , where  $f_X(X)$  is the Gaussian probability density function.

C. Proof of Theorem 12

Before we proceed to proving Theorem 12, we state two auxiliary results. The first is an important tool in the Gaussian approximation analysis of  $R(n, d, \epsilon)$ .

<span id="page-7-6"></span>**Theorem 13** (Berry-Esseen CLT, e.g. [31, Ch. XVI.5 Theorem 2] ). Fix a positive integer n. Let  $Z_i$ , i = 1, ..., n be independent. Then, for any real t

<span id="page-7-3"></span>
$$\left| \mathbb{P} \left[ \sum_{i=1}^{n} Z_i > n \left( \mu_n + t \sqrt{\frac{V_n}{n}} \right) \right] - Q(t) \right| \le \frac{B_n}{\sqrt{n}}, \quad (95)$$

where

$$\mu_n = \frac{1}{n} \sum_{i=1}^n \mathbb{E}\left[Z_i\right] \tag{96}$$

$$V_n = \frac{1}{n} \sum_{i=1}^n \text{Var}\left[Z_i\right] \tag{97}$$

$$T_n = \frac{1}{n} \sum_{i=1}^n \mathbb{E}\left[ |Z_i - \mu_i|^3 \right]$$
 (98)

<span id="page-7-4"></span><span id="page-7-1"></span>
$$B_n = 6 \frac{T_n}{V_n^{3/2}} \tag{99}$$

The second auxiliary result, proven in Appendix D, is a nonasymptotic refinement of the lossy AEP (Theorem 6) tailored to our purposes.

**Lemma 2.** Under restrictions (i)–(iv), there exist constants  $n_0, c, K > 0$  such that for all  $n \ge n_0$ ,

$$\mathbb{P}\left[\log \frac{1}{P_{Y^{n\star}}(B_d(X^n))} \le \sum_{i=1}^n \jmath_{\mathsf{X}}(X_i, d) + C\log n + c\right]$$

$$\ge 1 - \frac{K}{\sqrt{n}} \tag{100}$$

where C is given by (86).

We start with the converse part. Note that for the converse, restriction (iv) can be replaced by the following weaker one: (iv') The random variable  $\jmath_X(X,d)$  has finite absolute third moment

To verify that (iv) implies (iv'), observe that by the concavity of the logarithm,

$$0 \le \jmath_{\mathsf{X}}(\mathsf{x}, d) + \lambda^{\star} d \le \lambda^{\star} \mathbb{E} \left[ d(\mathsf{x}, \mathsf{Y}^{\star}) \right] \tag{101}$$

so

$$\mathbb{E}\left[\left|\jmath_{\mathsf{X}}(\mathsf{X},d) + \lambda^{\star}d\right|^{3}\right] \leq \lambda^{\star 3}\mathbb{E}\left[d^{3}(\mathsf{X},\mathsf{Y}^{\star})\right] \tag{102}$$

Proof of the converse part of Theorem 12. First, observe that due to (i) and (ii),  $P_{Y^n}^{\star} = P_{Y}^{\star} \times ... \times P_{Y}^{\star}$ , and the d-tilted information single-letterizes, that is, for a.e.  $x^n$ ,

<span id="page-7-2"></span>
$$j_{X^n}(x^n, d) = \sum_{i=1}^n j_{\mathsf{X}}(x_i, d)$$
 (103)

Consider the case V(d) > 0, so that  $B_n$  in (99) with  $Z_i = \chi(X_i, d)$  is finite by restriction (iv'). Let  $\gamma = \frac{1}{2} \log n$  in (50),

and choose

$$\log M = nR(d) + \sqrt{nV(d)}Q^{-1}(\epsilon_n) - \gamma$$
 (104)

$$\epsilon_n = \epsilon + \exp(-\gamma) + \frac{B_n}{\sqrt{n}}$$
 (105)

so that  $R=\frac{\log M}{n}$  can be written as the right side of (82) with (84) satisfied. Substituting (103) and (104) in (50), we conclude that for any  $(M,d,\epsilon')$  code it must hold that

$$\epsilon' \ge \mathbb{P}\left[\sum_{i=1}^{n} \jmath_{\mathsf{X}}(X_i, d) \ge nR(d) + \sqrt{nV(d)}Q^{-1}\left(\epsilon_n\right)\right] - \exp(-\gamma) \tag{106}$$

The proof for V(d) > 0 is complete upon noting that the right side of (106) is lower bounded by  $\epsilon$  by the Berry-Esseen inequality (95) in view of (105).

If V(d)=0, it follows that  $\jmath_{\mathsf{X}}(\mathsf{X},d)=R(d)$  almost surely. Choosing  $\gamma=\log\frac{1}{1-\epsilon}$  and  $\log M=nR(d)-\gamma$  in (50) it is obvious that  $\epsilon'>\epsilon$ .

Proof of the achievability part of Theorem 12. The proof consists of the asymptotic analysis of the bound in Corollary 11 using Lemma 2. Denote

$$G_n = \log M - \sum_{i=1}^{n} j_{\mathsf{X}}(x_i, d) - C \log n - c$$
 (107)

where constants c and C were defined in Lemma 2. Letting  $X = X^n$  in (71) and weakening the right side of (71) by choosing  $P_Y = P_{Y^n}^* = P_Y^* \times \ldots \times P_Y^*$ , we conclude that there exists an  $(n, M, d, \epsilon')$  code with

$$\epsilon' \leq \mathbb{E}\left[e^{-MP_{Y^n}^*(B_d(X^n))}\right]$$

$$\leq \mathbb{E}\left[e^{-\exp(G_n)}\right] + \frac{K}{\sqrt{n}}$$

$$= \mathbb{E}\left[e^{-\exp(G_n)}1\left\{G_n < \log\frac{\log_e n}{2}\right\}\right]$$

$$+ \mathbb{E}\left[e^{-\exp(G_n)}1\left\{G_n \geq \log\frac{\log_e n}{2}\right\}\right]$$

$$+\frac{K}{\sqrt{n}} + \frac{1}{\sqrt{n}}$$

$$\leq \mathbb{P}\left[G_n < \log \frac{\log_e n}{2}\right]$$
(110)

$$+ \frac{1}{\sqrt{n}} \mathbb{P} \left[ G_n \ge \log \frac{\log_e n}{2} \right] + \frac{K}{\sqrt{n}}$$

where (109) holds for  $n \ge n_0$  by Lemma 2, and (111) follows by upper bounding  $e^{-\exp(G_n)}$  by 1 and  $\frac{1}{\sqrt{n}}$  respectively. We need to show that (111) is upper bounded by  $\epsilon$  for some  $R = \frac{\log M}{n}$  that can be written as (82) with the remainder satisfying (85). Considering first the case V(d) > 0, let

$$\log M = nR(d) + \sqrt{nV(d)}Q^{-1}(\epsilon_n) + C\log n + \log\frac{\log_e n}{2} + c$$
(112)

$$\epsilon_n = \epsilon - \frac{B_n + K + 1}{\sqrt{n}} \tag{113}$$

<span id="page-8-0"></span>where  $B_n$  is given by (99) and is finite by restriction (iv'). Substituting (112) into (111) and applying the Berry-Esseen inequality (95) to the first term in (111), we conclude that  $\epsilon' \leq \epsilon$  for all n such that  $\epsilon_n > 0$ .

<span id="page-8-2"></span>It remains to tackle the case V(d)=0, which implies  $\jmath_{\mathsf{X}}(\mathsf{X},d)=R(d)$  almost surely. Let

$$\log M = nR(d) + C\log n + c + \log\log_e \frac{1}{\epsilon - \frac{K}{\sqrt{n}}}$$
 (114)

Substituting M into (109) we obtain immediately that  $\epsilon' \leq \epsilon$ , as desired.

#### <span id="page-8-1"></span>D. Distortion-dispersion function

One can also consider the related problem of finding the minimum excess distortion  $D(n,R,\epsilon)$  achievable at blocklength n, rate R and excess-distortion probability  $\epsilon$ . We define the distortion-dispersion function at rate R by

$$\mathcal{V}(R) = \lim_{\epsilon \to 0} \limsup_{n \to \infty} \frac{n \left( D(n, R, \epsilon) - D(R) \right)^2}{2 \log_e \frac{1}{\epsilon}}$$
(115)

For a fixed n and  $\epsilon$ , the functions  $R(n,\cdot,\epsilon)$  and  $D(n,\cdot,\epsilon)$  are functional inverses of each other. Consequently, the rate-dispersion and the distortion-dispersion functions also define each other. Under mild conditions, it is easy to find one from the other:

**Theorem 14.** (Distortion dispersion) If R(d) is twice differentiable,  $R'(d) \neq 0$  and V(d) is differentiable in some interval  $(\underline{d}, \overline{d}] \subseteq (d_{\min}, d_{\max}]$  then for any rate R such that R = R(d) for some  $d \in (\underline{d}, \overline{d})$  the distortion-dispersion function is given by

$$V(R) = (D'(R))^{2}V(D(R))$$
(116)

and

<span id="page-8-6"></span><span id="page-8-3"></span>
$$D(n, R, \epsilon) = D(R) + \sqrt{\frac{\mathcal{V}(R)}{n}} Q^{-1}(\epsilon) - D'(R)\theta\left(\frac{\log n}{n}\right)$$
(117)

where  $\theta(\cdot)$  satisfies (84), (85).

In parallel to (81), suppose that the goal is to compress at rate R while exceeding distortion  $d=(1+\eta)D(R)$  with probability not higher than  $\epsilon$ . As (117) implies, the required blocklength scales linearly with the distortion-dispersion function:

$$n(R, \eta, \epsilon) \approx \frac{\mathcal{V}(R)}{D^2(R)} \left(\frac{Q^{-1}(\epsilon)}{\eta}\right)^2$$
 (118)

<span id="page-8-4"></span>The distortion-dispersion function assumes a particularly simple form for the Gaussian memoryless source with mean-square error distortion, in which case for any  $0 < d < \sigma^2$ 

$$D(R) = \sigma^2 \exp(-2R) \tag{119}$$

$$\frac{\mathcal{V}(R)}{D^2(R)} = 2\tag{120}$$

$$n(R, \eta, \epsilon) \approx 2 \left(\frac{Q^{-1}(\epsilon)}{\eta}\right)^2$$
 (121)

<span id="page-8-7"></span><span id="page-8-5"></span>so in the Gaussian case, the required blocklength is essentially independent of the target distortion.

#### VI. BINARY MEMORYLESS SOURCE

<span id="page-9-0"></span>This section particularizes the nonasymptotic bounds in Section IV and the asymptotic analysis in Section V to the stationary binary memoryless source with bit error rate distortion measure, i.e.  $d(x^n, y^n) = \frac{1}{n} \sum_{i=1}^n 1\{x_i \neq y_i\}$ . For convenience, we denote

$$\left\langle {n \atop k} \right\rangle = \sum_{i=0}^{k} \binom{n}{j} \tag{122}$$

with the convention  ${n \choose k} = 0$  if k < 0 and  ${n \choose k} = {n \choose n}$  if k > n.

#### A. Equiprobable BMS (EBMS)

The following results pertain to the i.i.d. binary equiprobable source and hold for  $0 \le d < \frac{1}{2}$ ,  $0 < \epsilon < 1$ .

Particularizing (21) to the equiprobable case, one observes that for all binary n-strings  $x^n$ 

$$j_{X^n}(x^n, d) = n \log 2 - nh(d) = nR(d)$$
 (123)

Then, Theorem 7 reduces to (91). Theorem 8 leads to the following stronger converse result.

<span id="page-9-8"></span>**Theorem 15** (Converse, EBMS). Any  $(n, M, d, \epsilon)$  code must satisfy:

<span id="page-9-5"></span>
$$\epsilon \ge 1 - M2^{-n} \left\langle \frac{n}{|nd|} \right\rangle \tag{124}$$

*Proof.* Invoking Theorem 8 with the n-dimensional source distribution playing the role of  $P_X$  therein, we have

$$M \ge \sup_{Q} \inf_{y^n \in \{0,1\}^n} \frac{\beta_{1-\epsilon}(P_{X^n}, Q)}{\mathbb{Q}[d(X^n, y^n) < d]}$$
(125)

$$\geq \inf_{y^n \in \{0,1\}^n} \frac{\beta_{1-\epsilon}(P_{X^n}, P_{X^n})}{\mathbb{P}[d(X^n, y^n) \leq d]}$$
 (126)

$$= \frac{1 - \epsilon}{\mathbb{P}\left[d(X^n, \mathbf{0}) \le d\right]}$$
 (127)

$$=\frac{1-\epsilon}{2^{-n}\left\langle \frac{n}{|nd|}\right\rangle}\tag{128}$$

where (126) is obtained by substitution  $Q = P_X$ .

<span id="page-9-3"></span>**Theorem 16** (Exact performance of random coding, EBMS). The minimal averaged probability that bit error rate exceeds d achieved by random coding with M codewords is

$$\min_{P_Y} \mathbb{E}\left[\epsilon_d\left(Y_1, \dots, Y_M\right)\right] = \left(1 - 2^{-n} \left\langle \begin{array}{c} n \\ |nd| \end{array} \right\rangle\right)^M \quad (129)$$

attained by  $P_Y$  equiprobable on  $\{0,1\}^n$ .

*Proof.* For all  $M \ge 1$ ,  $(1-z)^M$  is a convex function of z on  $0 \le z < 1$ , so the right side of (65) is lower bounded by Jensen's inequality:

<span id="page-9-2"></span>
$$\mathbb{E}\left[1 - P_{Y^n}(B_d(X^n))\right]^M \ge \left(1 - \mathbb{E}\left[P_{Y^n}(B_d(X^n))\right]\right)^M$$

Equality in (130) is attained by  $Y^n$  equiprobable on  $\{0,1\}^n$ , because then

$$P_{Y^n}(B_d(X^n)) = 2^{-n} \left\langle \begin{array}{c} n \\ |nd| \end{array} \right\rangle \text{ a.s.}$$
 (131)

Theorem 16 leads to an achievability bound since there must exist an  $(M, d, \mathbb{E} [\epsilon_d (Y_1, \dots, Y_M)])$  code.

<span id="page-9-9"></span>**Corollary 17** (Achievability, EBMS). *There exists an*  $(n, M, d, \epsilon)$  *code such that* 

$$\epsilon \le \left(1 - 2^{-n} \left\langle \begin{array}{c} n \\ |nd| \end{array} \right\rangle \right)^M \tag{132}$$

<span id="page-9-4"></span>

As mentioned in Section V after Theorem 12, the EBMS with bit error rate distortion has zero rate-dispersion function for all d. The asymptotic analysis of the bounds in (132) and (124) allows for the following more accurate characterization of  $R(n, d, \epsilon)$ .

<span id="page-9-10"></span>**Theorem 18** (Gaussian approximation, EBMS). *The minimum achievable rate at blocklength n satisfies* 

<span id="page-9-6"></span>
$$R(n,d,\epsilon) = \log 2 - h(d) + \frac{1}{2} \frac{\log n}{n} + O\left(\frac{1}{n}\right)$$
 (133)

if  $0 < d < \frac{1}{2}$ , and

$$R(n,0,\epsilon) = \log 2 - \frac{1}{n} \log \frac{1}{1-\epsilon} + o_n \tag{134}$$

where  $0 \le o_n \le \frac{2^{-n}}{(1-\epsilon)n}$ .

<span id="page-9-1"></span>A numerical comparison of the achievability bound (33) evaluated with stationary memoryless  $P_{Y^n|X^n}$ , the new bounds in (132) and (124) as well as the approximation in (133) neglecting the  $O\left(\frac{1}{n}\right)$  term is presented in Fig. 1. Note that Marton's converse (Theorem 5) is not applicable to the EBMS because the region in (44) is empty. The achievability bound in (33), while asymptotically optimal, is quite loose in the displayed region of blocklengths. The converse bound in (124) and the achievability bound in (132) tightly sandwich the finite blocklength fundamental limit. Furthermore, the approximation in (133) is quite accurate, although somewhat optimistic, for all but very small blocklengths.

#### B. Non-equiprobable BMS

The results in this subsection focus on the i.i.d. binary memoryless source with  $\mathbb{P}\left[\mathsf{X}=1\right]=p<\frac{1}{2}$  and apply for  $0\leq d< p,\ 0<\epsilon<1$ . The following converse result is a simple calculation of the bound in Theorem 7 using (21).

**Theorem 19** (Converse, BMS). For any  $(n, M, d, \epsilon)$  code, it holds that

<span id="page-9-7"></span>
$$\epsilon \ge \sup_{\gamma > 0} \left\{ \mathbb{P}\left[g_n(Z) \ge \log M + \gamma\right] - \exp\left(-\gamma\right) \right\}$$
 (135)

$$g_n(Z) = Z \log \frac{1}{p} + (n - Z) \log \frac{1}{1 - p} - nh(d)$$
 (136)

where Z is binomial with success probability p and n degrees of freedom.

An application of Theorem 8 to the specific case of non-equiprobable BMS yields the following converse bound:

![](_page_10_Figure_1.jpeg)

<span id="page-10-0"></span>Fig. 1. Bounds to  $R(n,d,\epsilon)$  and Gaussian approximation for EBMS,  $d=0.11,\,\epsilon=10^{-2}$ .

**Theorem 20** (Converse, BMS). Any  $(n, M, d, \epsilon)$  code must satisfy

$$M \ge \frac{\left\langle {n \atop r^{\star}} \right\rangle + \alpha {n \choose r^{\star} + 1}}{\left\langle {n \atop \lfloor nd \rfloor} \right\rangle} \tag{137}$$

where we have denoted the integer

$$r^* = \max \left\{ r : \sum_{k=0}^r \binom{n}{k} p^k (1-p)^{n-k} \le 1 - \epsilon \right\}$$
 (138)

and  $\alpha \in [0,1)$  is the solution to

$$\sum_{k=0}^{r^{\star}} \binom{n}{k} p^{k} (1-p)^{n-k} + \alpha p^{r^{\star}+1} (1-p)^{n-r^{\star}-1} \binom{n}{r^{\star}+1}$$

$$= 1 - \epsilon \tag{139}$$

*Proof.* In Theorem 8, the n-dimensional source distribution  $P_{X^n}$  plays the role of  $P_X$ , and we make the possibly suboptimal choice Q = U, the equiprobable distribution on  $A = \{0,1\}^n$ . The optimal randomized test to decide between  $P_{X^n}$  and U is given by

$$P_{W|X^n}(1|x^n) = \begin{cases} 0, & |x^n| > r^* + 1\\ 1, & |x^n| \le r^*\\ \alpha, & |x^n| = r^* + 1 \end{cases}$$
(140)

where  $|x^n|$  denotes the Hamming weight of  $x^n$ , and  $\alpha$  is such that  $\sum_{x^n \in A} P(x^n) P_{W|X}(1|x^n) = 1 - \epsilon$ , so

$$\beta_{1-\epsilon}(P_X, U) = \min_{\substack{P_{W|X}:\\ \sum_{x^n \in A} P(x^n) P_{W|X}(1|x^n) \ge 1-\epsilon}} 2^{-n} \sum_{x^n \in A} P_{W|X}(1|x^n) \\
= 2^{-n} \left[ \left\langle {n \atop r^*} \right\rangle + \alpha {n \choose r^*+1} \right] \tag{141}$$

The result is now immediate from (60).

An application of Theorem 10 to the non-equiprobable BMS yields the following achievability bound:

<span id="page-10-5"></span>**Theorem 21** (Achievability, BMS). *There exists an*  $(n, M, d, \epsilon)$  *code with* 

<span id="page-10-2"></span>
$$\epsilon \le \sum_{k=0}^{n} \binom{n}{k} p^{k} (1-p)^{n-k} \left[ 1 - \sum_{t=0}^{n} L_{n}(k,t) q^{t} (1-q)^{n-t} \right]^{M}$$
(142)

where

<span id="page-10-3"></span>
$$q = \frac{p - d}{1 - 2d} \tag{143}$$

and

<span id="page-10-4"></span>
$$L_n(k,t) = \binom{k}{t_0} \binom{n-k}{t-t_0} \tag{144}$$

with  $t_0 = \left\lceil \frac{t+k-nd}{2} \right\rceil^+$  if  $t-nd \le k \le t+nd$ , and  $L_n(k,t) = 0$  otherwise.

*Proof.* We compute an upper bound to (70) for the specific case of the BMS. Let  $P_{Y^n} = P_Y \times \ldots \times P_Y$ , where  $P_Y(1) = q$ . Note that  $P_Y$  is the marginal of the joint distribution that achieves the rate-distortion function (e.g. [32]). The number of binary strings of Hamming weight t that lie within Hamming distance nd from a given string of Hamming weight k is

$$\sum_{i=t_0}^k \binom{k}{i} \binom{n-k}{t-i} \ge \binom{k}{t_0} \binom{n-k}{t-t_0} \tag{145}$$

<span id="page-10-9"></span><span id="page-10-8"></span>as long as  $t - nd \le k \le t + nd$  and is 0 otherwise. It follows that if  $x^n$  has Hamming weight k,

<span id="page-10-1"></span>
$$P_{Y^n}(B_d(x^n)) \ge \sum_{t=0}^n L_n(k,t)q^t(1-q)^{n-t}$$
 (146)

Relaxing (70) using (146), (142) follows.

The following bound shows that good constant composition codes exist.

<span id="page-10-7"></span>**Theorem 22** (Achievability, BMS). *There exists an*  $(n, M, d, \epsilon)$  *constant composition code with* 

<span id="page-10-11"></span>
$$\epsilon \le \sum_{k=0}^{n} \binom{n}{k} p^k (1-p)^{n-k} \left[ 1 - \binom{n}{\lceil nq \rceil} \right]^{-1} L_n(k, \lceil nq \rceil)$$
(147)

where q and  $L_n(\cdot,\cdot)$  are defined in (143) and (144) respectively.

*Proof.* The proof is along the lines of the proof of Theorem 21, except that now we let  $P_{Y^n}$  be equiprobable on the set of binary strings of Hamming weight  $\lceil qn \rceil$ .

The following asymptotic analysis of  $R(n,d,\epsilon)$  strengthens Theorem 12.

<span id="page-10-10"></span>**Theorem 23** (Gaussian approximation, BMS). *The minimum achievable rate at blocklength* n *satisfies* (82) *where* 

$$R(d) = h(p) - h(d) \tag{148}$$

<span id="page-10-6"></span>
$$V(d) = \text{Var}[i_{\mathsf{X}}(\mathsf{X})] = p(1-p)\log^2\frac{1-p}{p}$$
 (149)

and the remainder term in (82) satisfies

$$O\left(\frac{1}{n}\right) \le \theta\left(\frac{\log n}{n}\right) \tag{150}$$

$$\leq \frac{1}{2} \frac{\log n}{n} + \frac{\log \log n}{n} + O\left(\frac{1}{n}\right) \tag{151}$$

if 0 < d < p, and

$$\theta\left(\frac{\log n}{n}\right) = -\frac{1}{2}\frac{\log n}{n} + O\left(\frac{1}{n}\right) \tag{152}$$

if d = 0.

*Proof.* The case d=0 follows immediately from (88). For 0 < d < p, the dispersion (149) is easily obtained plugging n=1 into (21). The tightened upper bound for the remainder (151) follows via the asymptotic analysis of Theorem 22 shown in Appendix G. We proceed to show the converse part, which yields a better  $\frac{\log n}{n}$  term than Theorem 12.

According to the definition of  $r^*$  in (138),

<span id="page-11-2"></span>
$$\mathbb{P}\left[\sum_{i=1}^{n} X_i > r\right] \ge \epsilon \tag{153}$$

for any  $r \leq r^*$ , where  $\{X_i\}$  are binary i.i.d. with  $P_{X_i}(1) = p$ . In particular, due to (95), (153) holds for

$$r = np + \sqrt{np(1-p)}Q^{-1}\left(\epsilon + \frac{B_n}{\sqrt{n}}\right)$$
 (154)

$$= np + \sqrt{np(1-p)}Q^{-1}(\epsilon) + O(1)$$
 (155)

where (155) follows because in the present case  $B_n = 6\frac{1-2p+2p^2}{\sqrt{p(1-p)}}$ , which does not depend on n. Using (137), we have

<span id="page-11-4"></span>
$$M \ge \frac{\left\langle \binom{n}{\lfloor r \rfloor} \right\rangle}{\left\langle \binom{n}{\lfloor nd \rfloor} \right\rangle} \tag{156}$$

Taking logarithms of both sides of (156), we have

 $\log M$   $\geq \log \left\langle {n \atop \lfloor r \rfloor} \right\rangle - \log \left\langle {n \atop \lfloor nd \rfloor} \right\rangle \tag{157}$   $= nh \left( p + \frac{1}{\sqrt{n}} \sqrt{p(1-p)} Q^{-1}(\epsilon) \right) - nh(d) + O(1) \tag{158}$   $= nh(p) - nh(d) + \sqrt{n} \sqrt{p(1-p)} h'(p) Q^{-1}(\epsilon) + O(1)$ 

where (158) is due to (359) in Appendix F. The desired bound (151) follows since 
$$h'(p) = \log \frac{1-p}{p}$$
.

Figures 2 and 3 present a numerical comparison of Shannon's achievability bound (33), the new bounds in (142), (137) and (135) as well as the Gaussian approximation in (82) in which we have neglected  $\theta\left(\frac{\log n}{n}\right)$ . The achievability bound (33) is very loose and so is Marton's converse which is essentially indistinguishable from R(d). The new finite blocklength bounds (142) and (137) are fairly tight unless the blocklength is very small. In Fig. 3 obtained with a more stringent  $\epsilon$ , the approximation of Theorem 23 is essentially halfway between the converse and achievability bounds.

<span id="page-11-1"></span>![](_page_11_Figure_19.jpeg)

(153) Fig. 2. Bounds to  $R(n,d,\epsilon)$  and Gaussian approximation for BMS with  $p=2/5,\,d=0.11$ ,  $\epsilon=10^{-2}$ .

<span id="page-11-6"></span><span id="page-11-3"></span>![](_page_11_Figure_21.jpeg)

<span id="page-11-7"></span><span id="page-11-5"></span><span id="page-11-0"></span>Fig. 3. Bounds to  $R(n,d,\epsilon)$  and Gaussian approximation for BMS with p=2/5,~d=0.11 ,  $\epsilon=10^{-4}.$ 

#### VII. DISCRETE MEMORYLESS SOURCE

This section particularizes the bounds in Section IV to stationary memoryless sources with alphabet  $\mathcal{A}$  and symbol error rate distortion measure, i.e.  $d(x^n, y^n) = \frac{1}{n} \sum_{i=1}^n 1\{x_i \neq y_i\}$ . For convenience, we denote the number of strings within Hamming distance k from a given string by

$$S_k = \sum_{j=0}^k \binom{n}{j} (|\mathcal{A}| - 1)^j$$
 (159)

#### A. Equiprobable DMS (EDMS)

In this subsection we fix  $0 \le d < 1 - \frac{1}{|A|}$ ,  $0 < \epsilon < 1$  and assume that all source letters are equiprobable, in which case the rate-distortion function is given by [33]

$$R(d) = \log |A| - h(d) - d \log(|A| - 1)$$
 (160)

As in the equiprobable binary case, Theorem 7 reduces to (91). A stronger converse bound is obtained using Theorem 8 in a manner analogous to that of Theorem 15.

**Theorem 24** (Converse, EDMS). Any  $(n, M, d, \epsilon)$  code must satisfy:

<span id="page-12-2"></span>
$$\epsilon \ge 1 - M|\mathcal{A}|^{-n}S_{|nd|} \tag{161}$$

The following result is a straightforward generalization of Theorem 16 to the non-binary case.

<span id="page-12-0"></span>**Theorem 25** (Exact performance of random coding, EDMS). The minimal averaged probability that symbol error rate exceeds d achieved by random coding with M codewords is

$$\min_{P_Y} \mathbb{E}\left[\epsilon_d\left(Y_1, \dots, Y_M\right)\right] = \left(1 - |\mathcal{A}|^{-n} S_{\lfloor nd \rfloor}\right)^M \tag{162}$$

attained by  $P_Y$  equiprobable on  $\mathcal{A}^n$ .

Theorem 25 leads to the following achievability bound.

<span id="page-12-13"></span>Theorem 26 (Achievability, EDMS). There exists an  $(n, M, d, \epsilon)$  code such that

$$\epsilon \le \left(1 - S_{|nd|} |\mathcal{A}|^{-n}\right)^M \tag{163}$$

The asymptotic analysis of the bounds in (163) and (161) yields the following tight approximation.

<span id="page-12-12"></span>**Theorem 27** (Gaussian approximation, EDMS). *The minimum* achievable rate at blocklength n satisfies

$$R(n, d, \epsilon) = R(d) + \frac{1}{2} \frac{\log n}{n} + O\left(\frac{1}{n}\right)$$
 (164)

if  $0 < d < 1 - \frac{1}{|A|}$ , and

$$R(n,0,\epsilon) = \log|\mathcal{A}| - \frac{1}{n}\log\frac{1}{1-\epsilon} + o_n \tag{165}$$

where  $0 \le o_n \le \frac{|\mathcal{A}|^{-n}}{(1-\epsilon)n}$ 

#### B. Nonequiprobable DMS

In this subsection we assume that the source is stationary memoryless on an alphabet of m = |A| letters labeled by  $\mathcal{A} = \{1, \dots, m\}$ . We assume

$$P_{X}(1) \ge P_{X}(2) \ge \dots \ge P_{X}(m)$$
 (166)

and  $0 \le d < 1 - P_X(1), 0 < \epsilon < 1$ .

Recall that the rate-distortion function is achieved by [33]

$$P_{\mathsf{Y}^{\star}}(b) = \begin{cases} \frac{P_{\mathsf{X}}(b) - \eta}{1 - d - \eta} & b \le m_{\eta} \\ 0 & \text{otherwise} \end{cases}$$
 (167)

$$P_{X|Y}^{\star}(a|b) = \begin{cases} 1 - d & a = b, \ a \le m_{\eta} \\ \eta & a \ne b, \ a \le m_{\eta} \\ P_{X}(a) & a > m_{\eta} \end{cases}$$
(168)

where  $0 \le \eta \le 1$  is the solution to

<span id="page-12-9"></span><span id="page-12-6"></span>
$$d = \sum_{a=m_{\eta}+1}^{m} P_{\mathsf{X}}(a) + (m_{\eta} - 1)\eta \tag{169}$$

$$m_{\eta} = \max\{a: P_{\mathsf{X}}(a) > \eta\} \tag{170}$$

The rate-distortion function can be expressed as [33]

<span id="page-12-5"></span>
$$R(d) = \sum_{a=1}^{m_{\eta}} P_{\mathsf{X}}(a) \imath_{\mathsf{X}}(a) + (1-d) \log(1-d) + (m_{\eta} - 1) \eta \log \eta$$
(171)

Note that if  $0 \le d < (m-1)P_X(m)$ , then  $m_{\eta} = m$ ,  $\eta = \frac{d}{m-1}$ , and (167), (168) and (171) can be simplified. In particular, the rate-distortion function on that region is given by

<span id="page-12-10"></span>
$$R(d) = H(X) - h(d) - d\log(m - 1)$$
 (172)

The first result of this section is a particularization of the bound in Theorem 7 to the DMS case.

**Theorem 28** (Converse, DMS). For any  $(n, M, d, \epsilon)$  code, it holds that

$$\epsilon \ge \sup_{\gamma \ge 0} \left\{ \mathbb{P} \left[ \sum_{i=1}^{n} j_{\mathsf{X}}(X_i, d) \ge \log M + \gamma \right] - \exp \left\{ -\gamma \right\} \right\}$$
(173)

<span id="page-12-1"></span>where

$$\jmath_{\mathsf{X}}(a,d) = (1-d)\log(1-d) + d\log\eta 
+ \min\left\{\imath_{\mathsf{X}}(a), \log\frac{1}{\eta}\right\}$$
(174)

and  $\eta$  is defined in (169).

*Proof.* Case d = 0 is obvious. For  $0 < d < 1 - P_X(1)$ , differentiating (171) with respect to d yields

$$\lambda^* = \log \frac{1 - d}{\eta} \tag{175}$$

<span id="page-12-7"></span>

Plugging (168) and  $\lambda^*$  into (17), one obtains (174).

We adopt the notation of [34]:

- type of the string:  $\mathbf{k} = (k_1, \dots, k_m), \ k_1 + \dots + k_m = n$
- probability of a given string of type k:  $p^k$  $P_{\mathsf{X}}(1)^{k_1}\dots P_{\mathsf{X}}(m)^{k_m}$
- type ordering:  $\mathbf{j} \leq \mathbf{k}$  if and only if  $p^{\mathbf{j}} \geq p^{\mathbf{k}}$
- type 1 denotes  $[n, 0, \dots, 0]$
- previous and next types:  $\mathbf{j} 1$  and  $\mathbf{j} + 1$ , respectively
   multinomial coefficient:  $\binom{n}{\mathbf{k}} = \frac{n!}{k_1! \dots k_m!}$

The next converse result is a particularization of Theorem

<span id="page-12-8"></span><span id="page-12-4"></span><span id="page-12-3"></span>**Theorem 29** (Converse, DMS). Any  $(n, M, d, \epsilon)$  code must satisfy

<span id="page-12-11"></span>
$$M \ge \frac{\sum_{\mathbf{i}=1}^{\mathbf{k}^{\star}} \binom{n}{\mathbf{i}} + \alpha \binom{n}{\mathbf{k}^{\star} + 1}}{S_{\lfloor nd \rfloor}}$$
(176)

where

$$\mathbf{k}^{\star} = \max \left\{ \mathbf{k} : \sum_{i=1}^{\mathbf{k}} {n \choose i} p^{i} \le 1 - \epsilon \right\}$$
 (177)

and  $\alpha \in [0,1)$  is the solution to

$$\sum_{i=1}^{\mathbf{k}^{\star}} \binom{n}{\mathbf{i}} p^{\mathbf{i}} + \alpha \binom{n}{\mathbf{k}^{\star} + 1} p^{\mathbf{k}^{\star} + 1} = 1 - \epsilon$$
 (178)

*Proof.* Consider a binary hypothesis test between the n-dimensional source distribution  $P_{X^n}$  and U, the equiprobable distribution on  $\mathcal{A}^n$ . From Theorem 8,

$$M \ge |\mathcal{A}|^n \frac{\beta_{1-\epsilon}(P_{X^n}, U)}{S_{|nd|}} \tag{179}$$

The calculation of  $\beta_{1-\epsilon}(P_{X^n}U)$  is analogous to the BMS case.

The following result guarantees existence good code with codewords of of all type  $([nP_{\mathsf{Y}}^{\star}(1)], \dots, [nP_{\mathsf{Y}}^{\star}(m_{\eta})], 0, \dots, 0)$ where  $[\cdot]$ denotes rounding off to a neighboring integer so  $\sum_{b=1}^{m_{\eta}} [nP_{\mathsf{Y}}^{\star}(b)] = n \text{ holds.}$ 

<span id="page-13-7"></span>**Theorem 30** (Achievability, DMS). There exists an  $(n, M, d, \epsilon)$  fixed composition code with codewords of type  $\mathbf{t}^*$  and

$$\epsilon \le \sum_{\mathbf{k}} \binom{n}{\mathbf{k}} p^{\mathbf{k}} \left( 1 - \binom{n}{\mathbf{t}^{\star}} \right)^{-1} L_n(\mathbf{k}, \mathbf{t}^{\star})$$
 (180)

$$L_n(\mathbf{k}, \mathbf{t}^*) = \prod_{a=1}^m \begin{pmatrix} k_a \\ \mathbf{t}_a \end{pmatrix} \tag{181}$$

where  $\mathbf{k} = [k_1, \dots, k_m]$  ranges over all n-types, and  $k_a$ -types  $\mathbf{t}_a = (t_{a,1}, \dots, t_{a,m_\eta})$  are given by

<span id="page-13-0"></span>
$$t_{a,b} = \left[ P_{\mathsf{X}|\mathsf{Y}}^{\star}(a|b)t_b^{\star} + \delta(a,b)n \right]$$
 (182)

where

$$\delta(a,b) = \frac{\Delta_a}{m_\eta} + \begin{cases} \frac{1}{m_\eta^2} \sum_{i=m_\eta+1}^m \Delta_i & a = b, a \le m_\eta \\ \frac{-1}{m_\eta^2(m_\eta - 1)} \sum_{i=m_\eta+1}^m \Delta_i & a \ne b, a \le m_\eta \\ 0 & a > m_\eta \end{cases}$$

 $n\Delta_a = k_a - nP_X(a), \quad a = 1, \dots, m \tag{184}$ 

In (182),  $a=1,\ldots,m,\ b=1,\ldots,m_\eta$  and  $[\cdot]$  denotes rounding off to a neighboring nonnegative integer so that

$$\sum_{b=1}^{m_{\eta}} t_{b,b} \ge n(1-d) \tag{185}$$

$$\sum_{b=1}^{m_{\eta}} t_{a,b} = k_a \tag{186}$$

$$\sum_{a=1}^{m} t_{a,b} = t_b^{\star} \tag{187}$$

and among all possible choices the one that results in the largest value for (181) is adopted. If no such choice exists,  $L_n(\mathbf{k}, \mathbf{t}^*) = 0$ .

<span id="page-13-12"></span>*Proof.* We compute an upper bound to (70) for the specific case of the DMS. Let  $P_{Y^n}$  be equiprobable on the set of m-ary strings of type  $\mathbf{t}^*$ . To compute the number of strings of type  $\mathbf{t}^*$  that are within distortion d from a given string  $x^n$  of type  $\mathbf{k}$ , observe that by fixing  $x^n$  we have divided an n-string into m bins, the a-th bin corresponding to the letter a and having size  $k_a$ . If  $t_{a,b}$  is the number of the letters b in a sequence  $y^n$  of type  $\mathbf{t}^*$  that fall into a-th bin, the strings  $x^n$  and  $y^n$  are within Hamming distance nd from each other as long as (185) is satisfied. Therefore, the number of strings of type  $\mathbf{t}^*$  that are within Hamming distance nd from a given string of type  $\mathbf{k}$  is bounded by

<span id="page-13-4"></span>
$$\sum \prod_{a=1}^{m} {k_a \choose \mathbf{t}_a} \ge L_n(\mathbf{k}, \mathbf{t}^*)$$
 (188)

where the summation in the left side is over all collections of  $k_a$ -types  $\mathbf{t}_a = (t_{a,1}, \dots, t_{a,m_\eta}), \ a = 1, \dots m$  that satisfy (185)-(187), and inequality (188) is obtained by lower bounding the sum by the term with  $t_{a,b}$  given by (182). It follows that if  $x^n$  has type  $\mathbf{k}$ ,

<span id="page-13-5"></span>
$$P_{Y^n}\left(B_d(x^n)\right) \ge \binom{n}{\mathbf{t}^*}^{-1} L_n(\mathbf{k}, \mathbf{t}^*) \tag{189}$$

Relaxing (70) using (189), (180) follows.

<span id="page-13-6"></span><span id="page-13-1"></span>Remark 10. As n increases, the bound in (188) becomes increasingly tight. This is best understood by checking that all strings with  $k_{a,b}$  given by (182) lie at a Hamming distance of approximately nd from some fixed string of type k, and recalling [24] that most of the volume of an n-dimensional ball is concentrated near its surface (a similar phenomenon occurs in Euclidean spaces as well), so that the largest contribution to the sum on the left side of (188) comes from the strings satisfying (182).

The following second-order analysis makes use of Theorem 12 and, to strengthen the bounds for the remainder term, of Theorems 29 and 30.

**Theorem 31** (Gaussian approximation, DMS). The minimum achievable rate at blocklength n,  $R(n,d,\epsilon)$ , satisfies (82) where R(d) is given by (171), and V(d) can be characterized parametrically:

<span id="page-13-8"></span>
$$V(d) = \operatorname{Var}\left[\min\left\{i_{\mathsf{X}}(\mathsf{X}), \log\frac{1}{\eta}\right\}\right]$$
 (190)

where  $\eta$  depends on d through (169), (170). Moreover, (85) can be replaced by:

<span id="page-13-9"></span><span id="page-13-2"></span>
$$\theta\left(\frac{\log n}{n}\right) \le \frac{(m-1)(m_{\eta}-1)}{2} \frac{\log n}{n} + \frac{\log\log n}{n} + O\left(\frac{1}{n}\right) \tag{191}$$

<span id="page-13-3"></span>If  $0 \le d < (m-1)P_X(m)$ , (190) reduces to

<span id="page-13-10"></span>
$$V(d) = \text{Var}\left[\imath_{\mathsf{X}}(\mathsf{X})\right] \tag{192}$$

and if d > 0, (84) can be strengthened to

<span id="page-13-11"></span>
$$O\left(\frac{1}{n}\right) \le \theta\left(\frac{\log n}{n}\right) \tag{193}$$

while if d = 0,

$$\theta\left(\frac{\log n}{n}\right) = -\frac{1}{2}\frac{\log n}{n} + O\left(\frac{1}{n}\right) \tag{194}$$

*Proof.* Using the expression for d-tilted information (174), we observe that  $\operatorname{Var}\left[\jmath_{\mathsf{X}}(\mathsf{X},d)\right] = \operatorname{Var}\left[\min\left\{\imath_{\mathsf{X}}(\mathsf{X}),\log\frac{1}{\eta}\right\}\right]$ , and (190) follows. The case d=0 is verified using (88). Theorem 30 leads to (191), as we show in Appendix I.

When  $0 < d < (m-1)P_X(m)$ , not only (171) and (190) reduce to (172) and (192) respectively, but a tighter converse for the  $\frac{\log n}{n}$  term (193) can be shown. Recall the asymptotics of  $S_{\lfloor nd \rfloor}$  in (388) (Appendix H). Furthermore, it can be shown [34] that

<span id="page-14-1"></span>
$$\sum_{i=1}^{k} {n \choose i} = \frac{C}{\sqrt{n}} \exp\left\{nH\left(\frac{k}{n}\right)\right\}$$
 (195)

for some constant C. Armed with (195) and (388), we are ready to proceed to the second-order analysis of (176). From the definition of  $\mathbf{k}^*$  in (177),

<span id="page-14-2"></span>
$$\mathbb{P}\left[\frac{1}{n}\sum_{i=1}^{n}\imath_{\mathsf{X}}(X_{i}) > H(\mathsf{X}) + \sum_{a=1}^{m}\Delta_{a}\imath_{\mathsf{X}}(a)\right] \ge \epsilon \qquad (196)$$

for any  $\Delta$  with  $\sum_{a=1}^{m} \Delta_a = 0$  satisfying  $n(\mathbf{p} + \Delta) \leq \mathbf{k}^*$ , where  $\mathbf{p} = [P_{\mathsf{X}}(1), \dots, P_{\mathsf{X}}(m)]$  (we slightly abused notation here as  $n(\mathbf{p} + \Delta)$  is not always precisely an n-type; naturally, the definition of the type ordering  $\leq$  extends to such cases). Noting that  $\mathbb{E}\left[\imath_{\mathsf{X}}(X_i)\right] = H(\mathsf{X})$  and  $\mathrm{Var}\left[\imath_{\mathsf{X}}(X_i)\right] = \mathrm{Var}\left[\imath_{\mathsf{X}}(\mathsf{X})\right]$ , we conclude from the Berry-Esseen CLT (95) that (196) holds for

<span id="page-14-5"></span>
$$\sum_{a=1}^{m} \Delta_a \imath_{\mathsf{X}}(a) = \sqrt{\frac{\operatorname{Var}\left[\imath_{\mathsf{X}}(\mathsf{X})\right]}{n}} Q^{-1} \left(\epsilon - \frac{B_n}{\sqrt{n}}\right) \tag{197}$$

where  $B_n$  is given by (99). Taking logarithms of both sides of (176), we have

 $\log M$ 

$$\geq \log \left[ \sum_{i=1}^{\mathbf{k}^{\star}} \binom{n}{i} + \alpha \binom{n}{\mathbf{k}^{\star}} \right] - \log S_{\lfloor nd \rfloor}$$
 (198)

$$\geq \log \sum_{i=1}^{k^*} \binom{n}{i} - \log S_{\lfloor nd \rfloor} \tag{199}$$

$$\geq nH(\mathbf{p} + \mathbf{\Delta}) - nh(d) - nd\log(m-1) + O(1) \tag{200}$$

$$= nH(\mathbf{p}) + n\sum_{a=1}^{m} \Delta_a i_{\mathsf{X}}(a) - nh(d) - nd\log(m-1) + O(1)$$

where we used (388) and (195) to obtain (200), and (201) is obtained by applying a Taylor series expansion to  $H(\mathbf{p} + \boldsymbol{\Delta})$ . The desired result in (193) follows by substituting (197) in (201), applying a Taylor series expansion to  $Q^{-1}\left(\epsilon - \frac{B_n}{\sqrt{n}}\right)$  in the vicinity of  $\epsilon$  and noting that  $B_n$  is a finite constant.  $\square$ 

The rate-dispersion function and the blocklength (81) required to sustain R=1.1R(d) are plotted in Fig. 4 for a quaternary source with distribution  $[\frac{1}{3},\frac{1}{4},\frac{1}{4},\frac{1}{6}]$ . Note that according to (81), the blocklength required to approach 1.1R(d)

![](_page_14_Figure_18.jpeg)

![](_page_14_Figure_19.jpeg)

<span id="page-14-6"></span>Fig. 4. Rate-dispersion function (bits) and the blocklength (81) required to sustain R=1.1R(d) provided that excess-distortion probability is bounded by  $\epsilon$  for DMS with  $P_{\rm X}=\left[\frac{1}{3},\frac{1}{4},\frac{1}{4},\frac{1}{6}\right]$ 

with a given probability of excess distortion grows rapidly as  $d \to d_{\rm max}$ .

#### <span id="page-14-0"></span>VIII. ERASED BINARY MEMORYLESS SOURCE

<span id="page-14-4"></span><span id="page-14-3"></span>Let  $S^n \in \{0,1\}^n$  be the output of the binary equiprobable source,  $X^n$  be the output of the binary erasure channel with erasure rate  $\delta$  driven by  $S^n$ . The compressor only observes  $X^n$ , and the goal is to minimize the bit error rate with respect to  $S^n$ . For  $d=\frac{\delta}{2}$ , codes with rate approaching the rate-distortion function were constructed in [35]. For  $\frac{\delta}{2} \leq d \leq \frac{1}{2}$ , the rate-distortion function is given by

$$R(d) = (1 - \delta) \left( \log 2 - h \left( \frac{d - \frac{\delta}{2}}{1 - \delta} \right) \right)$$
 (202)

Throughout the section, we assume  $\frac{\delta}{2} < d < 1 - \frac{\delta}{2}$  and  $0 < \epsilon < 1.$ 

<span id="page-15-2"></span>**Theorem 32** (Converse, BES). Any  $(n, M, d, \epsilon)$  code must satisfy

$$\epsilon \ge \sum_{k=0}^{n} \binom{n}{k} \delta^k (1-\delta)^{n-k}$$

$$\cdot \sum_{j=0}^{k} 2^{-k} \binom{k}{j} \left[ 1 - M 2^{-(n-k)} \left\langle \binom{n-k}{\lfloor nd-j \rfloor} \right\rangle \right]^+ \tag{203}$$

*Proof.* Fix an  $(n,M,d,\epsilon)$  code  $(P_{Z^n|X^n},P_{Y^n|Z^n})$ . Even if the decompressor knows erasure locations, the probability that k erased bits are at Hamming distance  $\ell$  from their representation is

<span id="page-15-3"></span>
$$\mathbb{P}\left[k \ d(S^k, Y^k) = \ell \mid X^k = (?...?)\right] = 2^{-k} \binom{k}{\ell}$$
 (204)

because given  $X^k = (?...?)$ ,  $S_i$ 's are i.i.d. binary independent of  $Y^k$ .

The probability that n-k nonerased bits lie within Hamming distance  $\ell$  from their representation can be upper bounded using Theorem 15:

$$\mathbb{P}\left[(n-k)d(S^{n-k}, Y^{n-k}) \le \ell \mid X^{n-k} = S^{n-k}\right]$$

$$\le M2^{-n+k} \left\langle {n-k \atop \ell} \right\rangle \tag{205}$$

Since the errors in the erased symbols are independent of the errors in the nonerased ones,

$$\mathbb{P}\left[d(S^{n},Y^{n}) \leq d\right]$$

$$= \sum_{k=0}^{n} \mathbb{P}[k \text{ erasures in } S^{n}]$$

$$\cdot \sum_{j=0}^{k} \mathbb{P}\left[k \ d(S^{k},Y^{k}) = j | X^{k} = ? \dots ?\right]$$

$$\cdot \mathbb{P}\left[(n-k)d(S^{n-k},Y^{n-k}) \leq nd - j | X^{n-k} = S^{n-k}\right]$$

$$\leq \sum_{k=0}^{n} \binom{n}{k} \delta^{k} (1-\delta)^{n-k}$$

$$\cdot \sum_{j=0}^{k} 2^{-k} \binom{k}{j} \min\left\{1, \ M2^{-(n-k)} \left\langle \frac{n-k}{\lfloor nd-j \rfloor} \right\rangle\right\} \quad (206)$$

<span id="page-15-7"></span>**Theorem 33** (Achievability, BES). There exists an  $(n, M, d, \epsilon)$  code such that

$$\epsilon \leq \sum_{k=0}^{n} \binom{n}{k} \delta^{k} (1-\delta)^{n-k} \cdot \sum_{j=0}^{k} 2^{-k} \binom{k}{j} \left(1 - 2^{-(n-k)} \left\langle \frac{n-k}{\lfloor nd-j \rfloor} \right\rangle \right)^{M}$$
(207)

*Proof.* Consider the ensemble of codes with M codewords drawn i.i.d. from the equiprobable distribution on  $\{0,1\}^n$ . As discussed in the proof of Theorem 32, the distortion in the erased symbols does not depend on the codebook and is given by (204). The probability that the Hamming distance between

the nonerased symbols and their representation exceeds  $\ell$ , averaged over the code ensemble is found as in Theorem 17:

$$\mathbb{P}\left[(n-k)d(S^{n-k},\mathsf{C}(\mathsf{f}(X^{n-k}))) > \ell|S^{n-k} = X^{n-k}\right]$$

$$= \left(1 - 2^{-(n-k)} \left\langle {n-k \atop \ell} \right\rangle \right)^M \tag{208}$$

<span id="page-15-0"></span>where C(m), m = 1, ..., M are i.i.d on  $\{0, 1\}^{n-k}$ . Averaging over the erasure channel, we have

$$\mathbb{P}\left[d(S^{n}, \mathsf{C}(\mathsf{f}(X^{n})))) > d\right]$$

$$= \sum_{k=0}^{n} \mathbb{P}[k \text{ erasures in } S^{n}]$$

$$\cdot \sum_{j=0}^{k} \mathbb{P}\left[k \ d(S^{k}, \mathsf{C}(\mathsf{f}(X^{k}))) = j | X^{k} = ? \dots ?\right]$$

$$\cdot \mathbb{P}\left[(n-k)d(S^{n-k}, \mathsf{C}(\mathsf{f}(X^{n-k}))) > nd - j | X^{n-k} = S^{n-k}\right]$$

$$= \sum_{k=0}^{n} \binom{n}{k} \delta^{k} (1-\delta)^{n-k}$$

$$\cdot \sum_{j=0}^{k} 2^{-k} \binom{k}{j} \left(1 - 2^{-(n-k)} \left\langle \frac{n-k}{\lfloor nd-j \rfloor} \right\rangle \right)^{M}$$
 (209)

Since there must exist at least one code whose excess-distortion probability is no larger than the average over the ensemble, there exists a code satisfying (207).

<span id="page-15-8"></span>**Theorem 34** (Gaussian approximation, BES). The minimum achievable rate at blocklength n satisfies (82) where

$$V(d) = \delta(1 - \delta)\log^2 \cosh\left(\frac{\lambda^*}{2\log e}\right) + \frac{\delta}{4}\lambda^{*2}$$
 (210)

<span id="page-15-6"></span>
$$\lambda^* = -R'(d) = \log \frac{1 - \frac{\delta}{2} - d}{d - \frac{\delta}{2}}$$
 (211)

and the remainder term in (82) satisfies

$$O\left(\frac{1}{n}\right) \le \theta\left(\frac{\log n}{n}\right) \le \frac{1}{2} \frac{\log n}{n} + \frac{\log\log n}{n} + O\left(\frac{1}{n}\right) \tag{212}$$

Remark 11. It is satisfying to observe that even though Theorem 12 is not directly applicable, still  $V(d) = \operatorname{Var}\left[\jmath_{\mathsf{S},\mathsf{X}}(\mathsf{S},\mathsf{X},d)\right]$ , where  $\jmath_{\mathsf{S},\mathsf{X}}(\mathsf{s},\mathsf{x},d)$  is spelled out in (214) below. Indeed, since the rate-distortion function is achieved by  $P_{\mathsf{Y}}^{\star}(0) = P_{\mathsf{Y}}^{\star}(1) = \frac{1}{2}$  and

$$P_{\mathsf{X}|\mathsf{Y}}^{\star}(a|b) = \begin{cases} 1 - d - \frac{\delta}{2} & b = a \\ d - \frac{\delta}{2} & b \neq a \neq ? \\ \delta & a = ? \end{cases}$$
 (213)

<span id="page-15-1"></span>where  $a \in \{0,1,?\}$  and  $b \in \{0,1\}$ , we may adapt (17) to obtain

<span id="page-15-4"></span>
$$\jmath_{S,X}(S,X,d) 
= \imath_{X;Y^*}(X;0) + \lambda^* d(S,0) - \lambda^* d$$
(214)

<span id="page-15-5"></span>
$$= -\lambda^{\star}d + \begin{cases} \log \frac{2}{1 + \exp(-\lambda^{\star})} & \text{w.p. } 1 - \delta \\ \lambda^{\star} & \text{w.p. } \frac{\delta}{2} \\ 0 & \text{w.p. } \frac{\delta}{2} \end{cases}$$
 (215)

![](_page_16_Figure_1.jpeg)

<span id="page-16-3"></span>Fig. 5. Rate-dispersion function (bits) and the blocklength (81) required to sustain R=1.1R(d) provided that excess-distortion probability is bounded by  $\epsilon$  for BES with erasure rate  $\delta=0.1$ .

The variance of (215) is (210).

The rate-dispersion function and blocklength required to sustain a given excess distortion are plotted in Fig. 5. Note that as d approaches  $\frac{\delta}{2}$ , the rate-dispersion function grows without limit. This should be expected, because for  $d=\frac{\delta}{2}$ , a code that reconstructs a sequence with vanishingly small excess-distortion probability does not exist, as about half of the erased bits will always be reconstructed incorrectly, regardless of the blocklength.

The bounds in Theorems 32 and 33 as well as the approximation in Theorem 34 are plotted in Fig. 6. The achievability and converse bounds are extremely tight. At blocklength 1000, the penalty over the rate-distortion function is 9%.

#### IX. GAUSSIAN MEMORYLESS SOURCE

<span id="page-16-0"></span>This section applies Theorems 7, 8 and 10 to the i.i.d. Gaussian source with mean-square error distortion,  $d(x^n, y^n) = \frac{1}{n} \sum_{i=1}^{n} (x_i - y_i)^2$ , and refines the second-order analysis in

![](_page_16_Figure_8.jpeg)

<span id="page-16-4"></span>Fig. 6. Bounds to  $R(n,d,\epsilon)$  and Gaussian approximation for BES with  $\delta=0.1,\,d=0.1,\,\epsilon=0.1$ 

Theorem 12. Throughout the section, it is assumed that  $X_i \sim \mathcal{N}(0, \sigma^2)$ ,  $0 < d < \sigma^2$  and  $0 < \epsilon < 1$ .

The particularization of Theorem 7 to the GMS using (22) yields the following result.

**Theorem 35** (Converse, GMS). Any  $(n, M, d, \epsilon)$  code must satisfy

<span id="page-16-2"></span>
$$\epsilon \ge \sup_{\gamma > 0} \left\{ \mathbb{P}\left[g_n(Z) \ge \log M + \gamma\right] - \exp(-\gamma) \right\}$$
 (216)

$$g_n(Z) = \frac{n}{2} \log \frac{\sigma^2}{d} + \frac{Z - n}{2} \log e$$
 (217)

where  $Z \sim \chi_2^n$  (i.e. chi square distributed with n degrees of freedom).

The following result can be obtained by an application of Theorem 8 to the GMS.

<span id="page-16-6"></span>**Theorem 36** (Converse, GMS). Any  $(n, M, d, \epsilon)$  code must satisfy

<span id="page-16-1"></span>
$$M \ge \left(\frac{\sigma}{\sqrt{d}}r_n(\epsilon)\right)^n \tag{218}$$

where  $r_n(\epsilon)$  is the solution to

<span id="page-16-5"></span>
$$\mathbb{P}\left[Z < n \ r_n^2(\epsilon)\right] = 1 - \epsilon,\tag{219}$$

and  $Z \sim \chi_n^2$ .

*Proof.* Inequality (218) simply states that the minimum number of n-dimensional balls of radius  $\sqrt{nd}$  required to cover an n-dimensional ball of radius  $\sqrt{n\sigma}r_n(\epsilon)$  cannot be smaller than the ratio of their volumes. Since

$$Z = \frac{1}{\sigma^2} \sum_{i=1}^{n} X_i^2$$
 (220)

is  $\chi_n^2$ -distributed, the left side of (219) is the probability that the source produces a sequence that falls inside  $\mathbb{B}$ , the n-dimensional ball of radius  $\sqrt{n}\sigma r_n(\epsilon)$  with center at 0. But as follows from the spherical symmetry of the Gaussian distribution,  $\mathbb{B}$  has the smallest volume among all sets in  $\mathbb{R}^n$  having probability  $1 - \epsilon$ . Since any  $(n, M, d, \epsilon)$ -code is a covering of a set that has total probability of at least  $1 - \epsilon$ , the result follows.

Note that the proof of Theorem 36 can be formulated in the hypothesis testing language of Theorem 8 by choosing Q to be the Lebesgue measure on  $\mathbb{R}^n$ .

The following achievability result can be regarded as the rate-distortion counterpart to Shannon's geometric analysis of optimal coding for the Gaussian channel [36].

<span id="page-17-4"></span>**Theorem 37** (Achievability, GMS). *There exists an*  $(n, M, d, \epsilon)$  *code with* 

<span id="page-17-0"></span>
$$\epsilon \le n \int_0^\infty \left[1 - \rho(n, z)\right]^M f_{\chi_n^2}(nz) dz \tag{221}$$

where  $f_{\chi_n^2}(\cdot)$  is the  $\chi_n^2$  probability density function, and

$$\rho(n,z) = \frac{\Gamma\left(\frac{n}{2} + 1\right)}{\sqrt{\pi n}\Gamma\left(\frac{n-1}{2} + 1\right)} \left(1 - \frac{\left(1 + z - 2\frac{d}{\sigma^2}\right)^2}{4\left(1 - \frac{d}{\sigma^2}\right)z}\right)^{\frac{n-1}{2}}$$
(222)

if  $a^2 \le z \le b^2$ , where

$$a = \sqrt{1 - \frac{d}{\sigma^2}} - \sqrt{\frac{d}{\sigma^2}} \tag{223}$$

$$b = \sqrt{1 - \frac{d}{\sigma^2}} + \sqrt{\frac{d}{\sigma^2}} \tag{224}$$

and  $\rho(n,z) = 0$  otherwise.

*Proof.* We compute an upper bound to (70) for the specific case of the GMS. Let  $P_{Y^n}$  be the uniform distribution on the surface of the n-dimensional sphere with center at 0 and radius

$$r_0 = \sqrt{n\sigma}\sqrt{1 - \frac{d}{\sigma^2}} \tag{225}$$

This choice corresponds to a positioning of representation points that is optimal in the limit of large n, see Fig. 7(a), [8], [25]. Indeed, for large n, most source sequences will be concentrated within a thin shell near the surface of the sphere of radius  $\sqrt{n}\sigma$ . The center of the sphere of radius  $\sqrt{n}d$  must be at distance  $r_0$  from the origin in order to cover the largest area of the surface of the sphere of radius  $\sqrt{n}\sigma$ .

We proceed to lower-bound  $P_{Y^n}(B_d(x^n))$ ,  $x^n \in \mathbb{R}^n$ . Observe that  $P_{Y^n}(B_d(x^n)) = 0$  if  $x^n$  is either too close or too

far from the origin, that is, if  $|x^n|<\sqrt{n}\sigma a$  or  $|x^n|>\sqrt{n}\sigma b$ , where  $|\cdot|$  denotes the Euclidean norm. To treat the more interesting case  $\sqrt{n}\sigma a\leq |x^n|\leq \sqrt{n}\sigma b$ , it is convenient to introduce the following notation.

- $S_n(r) = \frac{n\pi^{\frac{n}{2}}}{\Gamma(\frac{n}{2}+1)} r^{n-1}$ : surface area of an n-dimensional sphere of radius r;
- $S_n(r,\theta)$ : surface area of an *n*-dimensional polar cap of radius r and polar angle  $\theta$ .

Similar to [8], [25], from Fig. 7(b),

<span id="page-17-1"></span>
$$S_n(r,\theta) \ge \frac{\pi^{\frac{n-1}{2}}}{\Gamma(\frac{n-1}{2}+1)} (r\sin\theta)^{n-1}$$
 (226)

where the right side of (226) is the area of an (n-1)-dimensional disc of radius  $r \sin \theta$ . So if  $\sqrt{n}\sigma a \le |x^n| = r \le \sqrt{n}\sigma b$ ,

$$P_{Y^n}(B_d(x^n)) = \frac{S_n(|x^n|, \theta)}{S_n(|x^n|)}$$
 (227)

<span id="page-17-2"></span>
$$\geq \frac{\Gamma\left(\frac{n}{2}+1\right)}{\sqrt{\pi}n\Gamma\left(\frac{n-1}{2}+1\right)}\left(\sin\theta\right)^{n-1} \tag{228}$$

where  $\theta$  is the angle in Fig. 7(b); by the law of cosines

<span id="page-17-3"></span>
$$\cos \theta = \frac{r^2 + r_0^2 - nd}{2rr_0} \tag{229}$$

Finally, by Theorem 10, there exists an  $(n, M, d, \epsilon)$  code with

$$\epsilon \leq \mathbb{E} \left[ 1 - P_{Y^n}(B_d(X^n)) \right]^M$$

$$= \mathbb{E} \left[ \left[ 1 - P_{Y^n}(B_d(X^n)) \right]^M \mid \sqrt{n}\sigma a \leq |X^n| \leq \sqrt{n}\sigma b \right]$$

$$+ \mathbb{P} \left[ |X^n| < \sqrt{n}\sigma a \right] + \mathbb{P} \left[ |X^n| > \sqrt{n}\sigma a \right]$$
(231)

Since  $\frac{|X^n|^2}{\sigma^2}$  is  $\chi_n^2$ -distributed, one obtains (221) by plugging  $\sin^2 \theta = 1 - \cos^2 \theta$  into (228) and substituting the latter in (231).

Essentially Theorem 37 evaluates the performance of Shannon's random code with all codewords lying on the surface of a sphere contained inside the sphere of radius  $\sqrt{n}\sigma$ . The following result allows us to bound the performance of a code whose codewords lie inside a ball of radius slightly larger than  $\sqrt{n}\sigma$ .

<span id="page-17-6"></span>**Theorem 38** (Rogers [37] - Verger-Gaugry [38]). If r > 1 and  $n \ge 2$ , an n-dimensional sphere of radius r can be covered by  $\lfloor \mathbb{M}(r) \rfloor$  spheres of radius 1, where  $\mathbb{M}(r)$  is defined in (232).

The first two cases in (232) (at the bottom of the page) are encompassed by the classical result of Rogers [37] that appears not to have been improved since 1963, while the last

<span id="page-17-5"></span>
$$\mathbb{M}(r) = \begin{cases} e\left(n\log_{e}n + n\log_{e}\log_{e}n + 5n\right)r^{n} & r \geq n \\ n\left(n\log_{e}n + n\log_{e}\log_{e}n + 5n\right)r^{n} & \frac{n}{\log_{e}n} \leq r < n \end{cases} \\ \frac{7^{4\log_{e}7/7}}{4}\sqrt{2\pi} \frac{n\sqrt{n}\left[(n-1)\log_{e}rn + (n-1)\log_{e}\log_{e}n + \frac{1}{2}\log_{e}n + \log_{e}\frac{\pi\sqrt{2n}}{\sqrt{\pi n - 2}}\right]}{r\left(1 - \frac{2}{\log_{e}n}\right)\left(1 - \frac{2}{\sqrt{\pi n}}\right)\log_{e}^{2}n} r^{n} & 2 < r < \frac{n}{\log_{e}n} \end{cases}$$

$$\sqrt{2\pi} \frac{\sqrt{n}\left[(n-1)\log_{e}rn + (n-1)\log_{e}\log_{e}n + \frac{1}{2}\log_{e}n + \log_{e}\frac{\pi\sqrt{2n}}{\sqrt{\pi n - 2}}\right]}{r\left(1 - \frac{2}{\log_{e}n}\right)\left(1 - \frac{2}{\sqrt{\pi n}}\right)} r^{n} \qquad 1 < r \leq 2$$

![](_page_18_Picture_1.jpeg)

Fig. 7. Optimum positioning of the representation sphere (a) and the geometry of the excess-distortion probability calculation (b).

<span id="page-18-1"></span>two are due to the recent improvement by Verger-Gaugry [38]. An immediate corollary to Theorem 38 is the following:

<span id="page-18-2"></span>**Theorem 39** (Achievability, GMS). For  $n \geq 2$ , there exists an  $(n, M, d, \epsilon)$  code such that

<span id="page-18-0"></span>
$$M \le \mathbb{M}\left(\frac{\sigma}{\sqrt{d}}r_n(\epsilon)\right) \tag{233}$$

where  $r_n(\epsilon)$  is the solution to (219).

*Proof.* Theorem 38 implies that there exists a code with no more than  $\mathbb{M}\left(\frac{\sigma}{\sqrt{d}}r_n(\epsilon)\right)$  codewords such that all source sequences that fall inside  $\mathbb{B}$ , the n-dimensional ball of radius  $\sqrt{n}\sigma r_n(\epsilon)$  with center at  $\mathbf{0}$ , are reproduced within distortion d. The excess-distortion probability is therefore given by the probability that the source produces a sequence that falls outside  $\mathbb{B}$ .

Note that Theorem 39 studies the number of balls of radius  $\sqrt{nd}$  to cover  $\mathbb{B}$  that is provably achievable, while the converse in Theorem 36 lower bounds the minimum number of balls of radius  $\sqrt{nd}$  required to cover  $\mathbb{B}$  by the ratio of their volumes.

**Theorem 40** (Gaussian approximation, GMS). *The minimum achievable rate at blocklength n satisfies* 

<span id="page-18-7"></span>
$$R(n, d, \epsilon) = \frac{1}{2} \log \frac{\sigma^2}{d} + \sqrt{\frac{1}{2n}} Q^{-1}(\epsilon) \log e + \theta \left(\frac{\log n}{n}\right)$$
(234)

where the remainder term satisfies

$$O\left(\frac{1}{n}\right) \le \theta\left(\frac{\log n}{n}\right) \tag{235}$$

<span id="page-18-6"></span><span id="page-18-3"></span>
$$\leq \frac{1}{2} \frac{\log n}{n} + \frac{\log \log n}{n} + O\left(\frac{1}{n}\right) \tag{236}$$

*Proof.* We start with the converse part, i.e. (235).

Since in Theorem 36  $Z=\frac{1}{\sigma^2}\sum_{i=1}^n X_i^2$ ,  $X_i\sim\mathcal{N}(0,\sigma^2)$ , we apply the Berry-Esseen CLT (Theorem 13) to  $\frac{1}{\sigma^2}X_i^2$ . Each  $\frac{1}{\sigma^2}X_i^2$  has mean, second and third central moments equal to 1, 2 and 8, respectively. Let

$$r^2 = 1 + \sqrt{\frac{2}{n}}Q^{-1}\left(\epsilon + \frac{12\sqrt{2}}{\sqrt{n}}\right)$$
 (237)

$$=1+\sqrt{\frac{2}{n}}Q^{-1}\left(\epsilon\right)+O\left(\frac{1}{n}\right) \tag{238}$$

Then by the Berry-Esseen inequality (95)

<span id="page-18-5"></span><span id="page-18-4"></span>
$$\mathbb{P}\left[Z > n\bar{r}^2\right] \ge \epsilon \tag{239}$$

and therefore  $r_n(\epsilon)$  that achieves the equality in (219) must satisfy  $r_n(\epsilon) \geq r$ . Weakening (218) by plugging r instead of  $r_n(\epsilon)$  and taking logarithms of both sides therein, one obtains:

$$\log M \ge \frac{n}{2} \log \frac{\sigma^2 r^2}{d} \tag{240}$$

$$= \frac{n}{2} \log \frac{\sigma^2}{d} + \sqrt{\frac{n}{2}} Q^{-1}(\epsilon) \log e + O(1)$$
 (241)

where (241) is a Taylor approximation of the right side of (240).

The achievability part (236) is proven in Appendix K using Theorem 37. Theorem 39 leads to the correct rate-dispersion term but a weaker remainder term.

Figures 8 and 9 present a numerical comparison of Shannon's achievability bound (33) and the new bounds in (221), (233), (218) and (216) as well as the Gaussian approximation in (234) in which we took  $\theta\left(\frac{\log n}{n}\right) = \frac{1}{2}\frac{\log n}{n}$ . The achievability bound in (233) is tighter than the one in (221) at shorter blocklengths. Unsurprisingly, the converse bound in (218) is quite a bit tighter than the one in (216).

#### X. CONCLUSION

To estimate the minimum rate required to sustain a given fidelity at a given blocklength, we have shown new achievability and converse bounds, which apply in full generality and which are tighter than existing bounds. The tightness of these bounds for stationary memoryless sources allowed us to obtain a compact closed-form expression that approximates the excess rate over the rate-distortion function incurred in the nonasymptotic regime (Theorem 12). For those sources and unless the blocklength is small, the rate dispersion (along with the rate-distortion function) serves to give tight approximations to the fundamental fidelity-rate tradeoff.

![](_page_19_Figure_1.jpeg)

<span id="page-19-2"></span>Fig. 8. Bounds to  $R(n,d,\epsilon)$  and Gaussian approximation for GMS with  $\sigma=1,\,d=\frac{1}{4}$  ,  $\epsilon=10^{-2}$ .

![](_page_19_Figure_3.jpeg)

<span id="page-19-3"></span>Fig. 9. Bounds to  $R(n,d,\epsilon)$  and Gaussian approximation for GMS with  $\sigma=1,\,d=\frac14$  ,  $\epsilon=10^{-4}.$ 

#### <span id="page-19-0"></span>ACKNOWLEDGEMENT

Useful discussions with Dr. Yury Polyanskiy are gratefully acknowledged. In particular, Theorem 8 was suggested by him.

## APPENDIX A HYPOTHESIS TESTING AND ALMOST LOSSLESS DATA COMPRESSION

To show (64), without loss of generality, assume that the letters of the alphabet A are labeled  $1, 2, \ldots$  in order of

decreasing probabilities:

$$P_X(1) \ge P_X(2) \ge \dots$$
 (242)

Observe that

$$M^{\star}(0,\epsilon) = \min\left\{m \ge 1 : \mathbb{P}\left[X \le m\right] \ge 1 - \epsilon\right\}, \quad (243)$$

and the optimal randomized test to decide between  ${\cal P}_{\cal X}$  and  ${\cal U}$  is given by

$$P_{W|X}(1|a) = \begin{cases} 1, & a \le M^{*}(0, \epsilon) - 1\\ \alpha, & a = M^{*}(0, \epsilon)\\ 0, & a \ge M^{*}(0, \epsilon) + 1 \end{cases}$$
(244)

It follows that

$$\beta_{1-\epsilon}(P_X, U) = M^*(0, \epsilon) - 1 + \alpha \tag{245}$$

where  $\alpha \in (0,1]$  is the solution to

$$\mathbb{P}\left[X \le M^{\star}(0, \epsilon) - 1\right] + \alpha P_X(M^{\star}(0, \epsilon)) = 1 - \epsilon, \quad (246)$$

hence (64).

## <span id="page-19-1"></span>APPENDIX B GAUSSIAN APPROXIMATION ANALYSIS OF ALMOST LOSSLESS DATA COMPRESSION

In this appendix we strenghten the remainder term in Theorem 12 for d=0 (cf. (88)). Taking the logarithm of (64), we have

<span id="page-19-5"></span>
$$\log \beta_{1-\epsilon}(P_X, U)$$

$$\leq \log M^*(0, \epsilon)$$
(247)

$$\leq \log \left(\beta_{1-\epsilon}(P_X, U) + 1\right) \tag{248}$$

$$= \log \beta_{1-\epsilon}(P_X, U) + \log \left(1 + \frac{1}{\beta_{1-\epsilon}(P_X, U)}\right)$$
 (249)

<span id="page-19-4"></span>
$$\leq \log \beta_{1-\epsilon}(P_X, U) + \frac{1}{\beta_{1-\epsilon}(P_X, U)} \log e \tag{250}$$

where in (250) we used  $\log(1+x) \le x \log e$ , x > -1.

Let  $P_{X^n} = P_X \times \ldots \times P_X$  be the source distribution, and let  $U^n$  to be the counting measure on  $\mathcal{A}^n$ . Examining the proof of Lemma 58 of [27] on the asymptotic behavior of  $\beta_{1-\epsilon}(P,Q)$  it is not hard to see that it extends naturally to  $\sigma$ -finite Q's; thus if  $\operatorname{Var}[\imath_X(X)] > 0$ ,

$$\log \beta_{1-\epsilon}(P_{X^n}, U^n) = nH(\mathsf{X}) + \sqrt{n \operatorname{Var}\left[\imath_{\mathsf{X}}(\mathsf{X})\right]} Q^{-1}\left(\epsilon\right) - \frac{1}{2} \log n + O\left(1\right)$$
(251)

and if  $\operatorname{Var}\left[\imath_{\mathsf{X}}(\mathsf{X})\right]=0$ ,

<span id="page-19-7"></span><span id="page-19-6"></span>
$$\log \beta_{1-\epsilon}(P_{X^n}, U^n) = nH(\mathsf{X}) - \log \frac{1}{1-\epsilon}$$
 (252)

Letting  $P_{X^n}$  and  $U^n$  play the roles of  $P_X$  and U in (247) and (250) and invoking (251) and (252), we obtain (88) and (89), respectively.

#### <span id="page-20-0"></span>APPENDIX C

#### GENERALIZATION OF THEOREMS 7 AND 12

We show that even if the rate-distortion function is not achieved by any output distribution, the definition of d-tilted information can be extended appropriately, so that Theorem 7 and the converse part of Theorem 12 still hold.

We use the following general representation of the ratedistortion function due to Csiszár [3].

**Theorem 41** (Alternative representation of  $\mathbb{R}(d)$  [3]). Under the basic restrictions (a)-(b) of Section II-B, for each  $d>d_{\min}$ , it holds that

<span id="page-20-2"></span>
$$\mathbb{R}_{X}(d) = \max_{\alpha(x) = \lambda} \left\{ \mathbb{E}\left[\alpha(X)\right] - \lambda d \right\}$$
 (253)

where the maximization is over  $\alpha(x) \geq 0$  and  $\lambda \geq 0$  satisfying the constraint

<span id="page-20-3"></span>
$$\mathbb{E}\left[\exp\left\{\alpha(X) - \lambda d(X, y)\right\}\right] \le 1 \ \forall y \in B \tag{254}$$

Let  $(\alpha^{\star}(x), \lambda^{\star})$  achieve the maximum in (253) for some  $d > d_{\min}$ , and define the d-tilted information in x by

<span id="page-20-4"></span>
$$j_X(x,d) = \alpha^*(x) - \lambda^* d \tag{255}$$

Note that (19), the only property of d-tilted information we used in the proof of Theorem 7, still holds due to (254), thus Theorem 7 remains true.

The proof of the converse part of Theorem 12 generalizes immediately upon making the following two observations. First, (87) is still valid due to (253). Second, d-tilted information in (255) still single-letterizes for memoryless sources:

Lemma 3. Under restrictions (i) and (ii) in Section V-B, (103) holds.

*Proof.* Let  $(\alpha^*(x), \lambda^*)$  attain the maximum in (253) for the single-letter distribution  $P_X$ . It suffices to check that  $(\sum_{i=1}^{n} \alpha^{\star}(x_i), n\lambda^{\star})$  attains the maximum in (253) for  $P_{X^n}$  $P_{\mathsf{X}} \times \ldots \times P_{\mathsf{X}}$ .

As desired.

$$\mathbb{E}\left[\sum_{i=1}^{n} \alpha^{\star}(X_i)\right] - n\lambda^{\star}d = n\mathbb{R}_{\mathsf{X}}(d) = \mathbb{R}_{X^n}(d) \qquad (256)$$

and we just need to verify the constraints in (254) are satisfied:

$$\mathbb{E}\left[\exp\left\{\sum_{i=1}^{n} \alpha^{\star}(X_{i}) - \lambda^{\star} \sum_{i=1}^{n} d(X_{i}, y)\right\}\right]$$

$$= \prod_{i=1}^{n} \mathbb{E}\left[\exp\left\{\alpha^{\star}(X_{i}) - \lambda^{\star} d(X_{i}, y)\right\}\right]$$

$$\leq 1 \ \forall y^{n} \in \mathcal{B}^{n}$$
(258)

#### <span id="page-20-1"></span>APPENDIX D PROOF OF LEMMA 2

Before we prove Lemma 2, let us present some background results we will use. For k = 1, 2, ..., denote

<span id="page-20-5"></span>
$$\bar{d}_{Y,k}(x,\lambda) = \frac{\mathbb{E}\left[d^k(x,Y)\exp\left(-\lambda d(x,Y)\right)\right]}{\mathbb{E}\left[\exp\left(-\lambda d(x,Y)\right)\right]}$$
(259)

Observe that

<span id="page-20-6"></span>
$$\bar{d}_{Y,k}(x,0) = \mathbb{E}\left[d^k(x,Y)\right] \tag{260}$$

(the expectations in (259) and (260) are with respect to the unconditional distribution of Y). Denoting by  $(\cdot)'$  differentiation with respect to  $\lambda > 0$ , we state the following properties whose proofs can be found in [20].

<span id="page-20-8"></span><span id="page-20-7"></span>A.  $\left(\mathbb{E}\left[\Lambda_Y(X,\lambda_{X,Y}^\star)\right]\right)'=0$  where  $\lambda_{X,Y}^\star=-\mathbb{R}'_{X,Y}(d)$ . B.  $\mathbb{E}\left[\Lambda''_Y(X,\lambda)\right]<0$  for all  $\lambda>0$  if  $\mathbb{E}\left[\bar{d}_{Y,2}(X,0)\right]<\infty$ .

<span id="page-20-9"></span>

<span id="page-20-10"></span>C.  $\Lambda'_Y(x,\lambda) = -d + \bar{d}_{Y,1}(x,\lambda)$ .

D.  $\Lambda_{Y_{-}}^{''}(x,\lambda) = \left[\bar{d}_{Y,1}^{2}(x,\lambda) - \bar{d}_{Y,2}(x,\lambda)\right] (\log e)^{-1} \le 0$ if  $d_{Y,1}(x,0) < \infty$ .

<span id="page-20-12"></span>E.  $\bar{d}'_{Y,k}(x,\lambda) \leq 0$  if  $\bar{d}_{Y,k}(x,0) < \infty$ .

F.  $d_{\min|X,Y} = \mathbb{E}[\alpha_Y(X)]$ , where  $\alpha_Y(x) = \text{ess inf } d(x,Y)$ .

Remark 12. By Properties A and B,

<span id="page-20-17"></span>
$$\mathbb{E}\left[\Lambda_Y(X, \lambda_{X,Y}^{\star})\right] = \sup_{\lambda > 0} \mathbb{E}\left[\Lambda_Y(X, \lambda)\right]$$
 (261)

Remark 13. Properties C and D imply that

<span id="page-20-18"></span>
$$-d \le \Lambda'_{Y}(x,\lambda) \le -d + \bar{d}_{Y,1}(x,0) \tag{262}$$

Therefore, as long as  $\mathbb{E}\left[\bar{d}_{Y,1}(X,0)\right]<\infty$ , the differentiation in Property A can be brought inside the expectation invoking the dominated convergence theorem. Keeping this in mind while averaging the equation in Property C with  $\lambda = \lambda_{XY}^{\star}$ with respect to  $P_X$ , we observe that

<span id="page-20-11"></span>
$$\mathbb{E}\left[\bar{d}_{Y,1}(X,\lambda_{X,Y}^{\star})\right] = d \tag{263}$$

Remark 14. Properties (17) and (18) of d-tilted information imply that the equality in (263) holds if  $\lambda_{X,Y}^{\star}$  is replaced by  $\lambda^* = -\mathbb{R}'_X(d)$ , and Y is replaced by  $Y^*$  - the  $\mathbb{R}_X(d)$ achieving random variable. It follows that

<span id="page-20-16"></span><span id="page-20-14"></span>
$$\lambda^{\star} = \lambda_{X Y^{\star}}^{\star} \tag{264}$$

Remark 15. By virtue of Properties D and E we have

$$-\bar{d}_{Y,2}(x,0) < \Lambda_Y''(x,\lambda) \log e < 0 \tag{265}$$

Remark 16. Using (263), derivatives of  $\mathbb{R}_{X,Y}(d)$  are conveniently expressed via  $\mathbb{E} |d_{Y,k}(x, \lambda_{X|Y}^{\star})|$ ; in particular, at any

$$d_{\min|X,Y} < d \le d_{\max|X,Y} = \mathbb{E}\left[\bar{d}_{Y,1}(X,0)\right]$$
 (266)

$$\mathbb{R}_{X,Y}^{"}(d) = -\frac{1}{\left(\mathbb{E}\left[\bar{d}_{Y,1}(X,\lambda_{X,Y}^{\star})\right]\right)'}$$
(267)

<span id="page-20-15"></span><span id="page-20-13"></span>
$$= \frac{\log e}{\mathbb{E}\left[\bar{d}_{Y,2}(X, \lambda_{X,Y}^{\star})\right] - \mathbb{E}\left[\bar{d}_{Y,1}^{2}(X, \lambda_{X,Y}^{\star})\right]}$$
(268)  
> 0 (269)

where (268) holds by Property D and the dominated convergence theorem due to (265) as long as  $\mathbb{E} |\bar{d}_{Y,2}(X,0)| < \infty$ , and (269) is by Property B.

The proof of Lemma 2 consists of Gaussian approximation analysis of the bound in Lemma 1. First, we weaken the bound in Lemma 1 by choosing  $P_{\hat{X}}$  and  $\gamma$  in (72) in the following manner. Fix  $\tau > 0$ , and let  $\gamma = \frac{\tau}{n}$ ,  $P_Y = P_{Y^{n\star}} = P_{Y^{\star}} \times \ldots \times P_{Y^{\star}}$ , where Y\* achieves  $\mathbb{R}_{\mathsf{X}}(d)$ , and choose  $P_{\hat{X}} = P_{\hat{X}^n} = P_{\hat{X}^n} = P_{\hat{X}^n} = P_{\hat{X}^n}$   $P_{\hat{\mathbf{X}}} \times \dots P_{\hat{\mathbf{X}}}$ , where  $P_{\hat{\mathbf{X}}}$  is the measure on  $\mathcal{A}$  generated by the empirical distribution of  $x^n \in \mathcal{A}^n$ :

<span id="page-21-0"></span>
$$P_{\hat{\mathbf{X}}}(a) = \frac{1}{n} \sum_{i=1}^{n} 1\{x_i = a\}$$
 (270)

Since the distortion measure is separable, for any  $\lambda>0$  we have

$$\Lambda_{Y^{n\star}}(x^n, \lambda n) = \sum_{i=1}^n \Lambda_{Y^{\star}}(x_i, \lambda)$$
 (271)

so by Lemma 1, for all

<span id="page-21-21"></span>
$$d > d_{\min|\hat{X}^n, Y^{n\star}} \tag{272}$$

it holds that

$$P_{Y^{n*}}(B_d(x^n)) \ge \exp\left(-\sum_{i=1}^n \Lambda_{Y^*}(x_i, \lambda(x^n)) - \lambda(x^n)\tau\right)$$
$$\cdot \mathbb{P}\left[nd - \tau < \sum_{i=1}^n d(x_i, \hat{Z}_i^*) \le nd|\hat{X}^n = x^n\right]$$
(273)

where we denoted

$$\lambda(x^n) = -\mathbb{R}'_{\hat{\mathbf{X}}:\mathbf{Y}^*}(d) \tag{274}$$

 $(\lambda(x^n))$  depends on  $x^n$  through the distribution of  $\hat{X}$  in (270)), and  $P_{\hat{Z}^{n\star}} = P_{\hat{Z}^{\star}} \times \ldots \times P_{\hat{Z}^{\star}}$ , where  $P_{\hat{Z}^{\star}|\hat{X}}$  achieves  $\mathbb{R}_{\hat{X};Y^{\star}}(d)$ . The probability appearing in (273) can be lower bounded by the following lemma.

**Lemma 4.** Assume that restrictions (i)-(iv) in Section V-B hold. Then, there exist  $\delta_0, n_0 > 0$  such that for all  $\delta \leq \delta_0$ ,  $n \geq n_0$ , there exist a set  $F_n \subseteq \mathcal{A}^n$  and constants  $\tau, C_1, K_1 > 0$  such that

<span id="page-21-14"></span>
$$\mathbb{P}\left[X^n \notin F_n\right] \le \frac{K_1}{\sqrt{n}} \tag{275}$$

and for all  $x_n \in F_n$ ,

$$\mathbb{P}\left[nd - \tau < \sum_{i=1}^{n} d(x_i, \hat{Z}_i^*) \le nd|\hat{X}^n = x^n\right] \ge \frac{C_1}{\sqrt{n}} \quad (276)$$
$$|\lambda(x^n) - \lambda^*| < \delta \quad (277)$$

where  $\lambda^* = -\mathbb{R}'_{\mathsf{X}}(d)$ .

*Proof.* The reasoning is similar to the proof of [20, (4.6)]. Fix

<span id="page-21-2"></span>
$$0 < \Delta < \frac{1}{3} \min \left\{ d - d_{\min|X,Y^*}, \ d_{\max|X,Y^*} - d \right\}$$
 (278)

(the right side of (278) is positive by restriction (iii) in Section

V-B) and denote

<span id="page-21-9"></span>
$$\underline{\lambda} = -\mathbb{R}'_{\mathsf{X},\mathsf{Y}^*} \left( d + \frac{3\Delta}{2} \right) \tag{279}$$

<span id="page-21-10"></span>
$$\bar{\lambda} = -\mathbb{R}'_{\mathsf{X},\mathsf{Y}^*} \left( d - \frac{3\Delta}{2} \right) \tag{280}$$

$$\mu'' = \mathbb{E}\left[|\Lambda_{Y^{\star}}''(X, \lambda^{\star})|\right] \tag{281}$$

<span id="page-21-20"></span><span id="page-21-19"></span><span id="page-21-4"></span>
$$\delta = \frac{3\Delta}{2} \sup_{|\theta| < \frac{3\Delta}{2}} \mathbb{R}_{X,Y^*}''(d+\theta)$$
 (282)

$$\overline{V}(x^n) = \frac{1}{n} \sum_{i=1}^n \sup_{|\theta| < \delta} |\Lambda''(x_i, \lambda^* + \theta)| \log e$$
 (283)

$$\underline{V}(x^n) = \frac{1}{n} \sum_{i=1}^n \inf_{|\theta| < \delta} |\Lambda''(x_i, \lambda^* + \theta)| \log e$$
 (284)

We say that  $x^n \in F_n$  if it meets the following conditions:

<span id="page-21-12"></span><span id="page-21-5"></span>
$$\frac{1}{n} \sum_{i=1}^{n} \alpha_{\mathsf{Y}^{\star}}(x_i) < d_{\min|\mathsf{X},\mathsf{Y}^{\star}} + \Delta \tag{285}$$

$$\frac{1}{n} \sum_{i=1}^{n} \bar{d}_{Y^{\star},1}(x_i, 0) > d_{\max|X,Y^{\star}} - \Delta$$
 (286)

$$\frac{1}{n} \sum_{i=1}^{n} \bar{d}_{Y^*,1}(x_i, \underline{\lambda}) > d + \Delta$$
 (287)

<span id="page-21-1"></span>
$$\frac{1}{n} \sum_{i=1}^{n} \bar{d}_{\mathsf{Y}^{\star},1}(x_i, \bar{\lambda}) < d - \Delta \tag{288}$$

$$\frac{1}{n} \sum_{i=1}^{n} \bar{d}_{\mathsf{Y}^{\star},3}(x_i,0) \le \mathbb{E}\left[\bar{d}_{\mathsf{Y}^{\star},3}(\mathsf{X},0)\right] + \Delta \tag{289}$$

<span id="page-21-16"></span><span id="page-21-15"></span><span id="page-21-7"></span><span id="page-21-6"></span>
$$\overline{V}(x^n) \ge \frac{\mu''}{2} \log e \tag{290}$$

<span id="page-21-17"></span>
$$\underline{V}(x^n) \le \frac{3\mu''}{2} \log e \tag{291}$$

Let us first show that (277) holds with  $\delta$  given by (282) for all  $x^n$  satisfying the conditions (285)–(288). From (287) and (288),

$$\frac{1}{n} \sum_{i=1}^{n} \bar{d}_{\mathsf{Y}^{\star},1}(x_i, \bar{\lambda}) < d < \frac{1}{n} \sum_{i=1}^{n} \bar{d}_{\mathsf{Y}^{\star},1}(x_i, \underline{\lambda}) \tag{292}$$

On the other hand, from (263) we have

<span id="page-21-8"></span>
$$d = \frac{1}{n} \sum_{i=1}^{n} \bar{d}_{Y^*,1}(x_i, \lambda(x^n))$$
 (293)

<span id="page-21-18"></span>Therefore, since the right side of (293) is decreasing (Property B),

<span id="page-21-11"></span>
$$\underline{\lambda} < \lambda(x^n) < \bar{\lambda} \tag{294}$$

<span id="page-21-3"></span>Finally, an application Taylor's theorem to (279) and (280) using (264) expands (294) as

<span id="page-21-13"></span>
$$-\frac{3\Delta}{2}\mathbb{R}_{\mathsf{X},\mathsf{Y}^{\star}}^{\prime\prime}(\bar{d}) + \lambda^{\star} < \lambda(x^{n}) < \lambda^{\star} + \frac{3\Delta}{2}\mathbb{R}_{\mathsf{X},\mathsf{Y}^{\star}}^{\prime\prime}(\underline{d}) \quad (295)$$

for some  $\bar{d} \in [d, d + \frac{3\Delta}{2}], \underline{d} \in [d, d - \frac{3\Delta}{2}]$ . Note that (278), (285) and (286) ensure that

<span id="page-21-22"></span>
$$d_{\min|\mathbf{X}|\mathbf{Y}^{\star}} + 2\Delta < d < d_{\max|\mathbf{X}|\mathbf{Y}^{\star}} - 2\Delta \tag{296}$$

so the derivatives in (295) exist and are positive by Remark 16. Therefore (277) holds with  $\delta$  given by (282).

We are now ready to show that as long as  $\Delta$  (and, therefore,  $\delta$ ) is small enough, there exists a  $K_1 \geq 0$  such that (275) holds. Hölder's inequality and assumption (iv) in Section V-B imply that the third moments of the random variables involved in conditions (287)–(289) are finite. By the Berry-Esseen inequality, the probability of violating these conditions is  $O\left(\frac{1}{\sqrt{n}}\right)$ . To bound the probability of violating conditions (290) and (291), observe that since  $\Lambda''_{Y*}(X,\lambda)$  is dominated by integrable functions due to (265), we have by Fatou's lemma and continuity of  $\Lambda''_{Y*}(x,\cdot)$ 

$$\mu'' \le \liminf_{\delta \downarrow 0} \mathbb{E} \left[ \inf_{|\theta'| \le \delta} |\Lambda''_{Y^{\star}}(X, \lambda^{\star} + \theta')| \right]$$
 (297)

$$\leq \limsup_{\delta \downarrow 0} \mathbb{E} \left[ \sup_{|\theta'| \leq \delta} |\Lambda''_{\mathsf{Y}^{\star}}(\mathsf{X}, \lambda^{\star} + \theta')| \right]$$
 (298)

$$\leq \mu'' \tag{299}$$

Therefore, if  $\delta$  is small enough,

<span id="page-22-5"></span>
$$\frac{3\mu''}{4}\log e \le \mathbb{E}\left[\underline{V}(X^n)\right] \le \mathbb{E}\left[\overline{V}(X^n)\right] \le \frac{5\mu''}{4}\log e \quad (300)$$

The third absolute moments of  $\overline{V}(X^n)$  and  $\underline{V}(X^n)$  are finite by Hölder's inequality, (265) and assumption (iv) in Section V-B. Thus, the probability of violating conditions (290) and (291) is also  $O\left(\frac{1}{\sqrt{n}}\right)$ . Now, (275) follows via the union bound.

To complete the proof of Lemma 4, it remains to show (276). Toward this end, observe, recalling Properties D and E that the corresponding moments in the Berry-Esseen theorem are given by

$$\mu(x^n) = \frac{1}{n} \sum_{i=1}^n \mathbb{E}\left[d(x_i, \hat{Z}^*) | \hat{X} = x_i\right]$$
 (301)

$$= \frac{1}{n} \sum_{i=1}^{n} \bar{d}_{Y^*,1}(x_i, \lambda(x^n))$$
 (302)

$$=d \tag{303}$$

$$V(x^{n}) = \frac{1}{n} \sum_{i=1}^{n} \left[ \bar{d}_{Y^{*},2}(x_{i}, \lambda(x^{n})) - \bar{d}_{Y^{*},1}^{2}(x_{i}, \lambda(x^{n})) \right]$$
(304)

$$= -\frac{1}{n} \sum_{i=1}^{n} \Lambda''(x_i, \lambda(x^n)) \log e$$
 (305)

$$T(x^n) = (306)$$

$$\frac{1}{n} \sum_{i=1}^{n} \mathbb{E} \left[ \left| d(x_i, \hat{\mathsf{Z}}^*) - \mathbb{E} \left[ d(x_i, \hat{\mathsf{Z}}^*) \mid \hat{\mathsf{X}} = x_i \right] \right|^3 \mid \hat{\mathsf{X}} = x_i \right] \\
\leq \frac{8}{n} \sum_{i=1}^{n} \mathbb{E} \left[ \left| d(x_i, \hat{\mathsf{Z}}^*) \right|^3 \mid \hat{\mathsf{X}} = x_i \right] \tag{307}$$

$$= \frac{8}{n} \sum \bar{d}_{Y^*,3}(x_i, \lambda(x^n)) \tag{308}$$

$$\leq \frac{8}{n} \sum \bar{d}_{\mathsf{Y}^*,3}(x_i,0) \tag{309}$$

Due to (277), (290) and (291),  $\frac{\mu''}{2}\log e \leq V(x^n) \leq \frac{3\mu''}{2}\log e$  as long as  $x^n \in F_n$ . Furthermore,

$$T(x^n) \le 8\mathbb{E}\left[\bar{d}_{\mathsf{Y}^*,3}(\mathsf{X},0)\right] + 8\Delta \tag{310}$$

for such  $x^n$  due to (289). Therefore, by the Berry-Esseen inequality we have for all  $x^n \in F_n$ :

$$\mathbb{P}\left[nd - \tau < \sum_{i=1}^{n} d(x_i, \hat{Z}_i^{\star}) \le nd|\hat{X}^n = x^n\right]$$
 (311)

$$\geq \frac{1}{\sqrt{2\pi}} \int_0^{\frac{\tau}{\sqrt{nV(x^n)}}} e^{-\frac{u^2}{2}} du - \frac{12T(x^n)}{V^{\frac{3}{2}}(x^n)} \frac{1}{\sqrt{n}}$$
(312)

$$\geq \left(\frac{\tau}{\sqrt{2\pi V(x^n)}}e^{-\frac{\tau^2}{2nV(x_n)}} - \frac{12T(x^n)}{V^{\frac{3}{2}}(x^n)}\right)\frac{1}{\sqrt{n}} \tag{313}$$

<span id="page-22-0"></span>
$$\geq \left(\frac{\tau}{\sqrt{3\pi\mu''\log e}}e^{-\frac{\tau^2}{n\mu''\log e}} - 2\bar{B}\right)\frac{1}{\sqrt{n}} \tag{314}$$

where  $\bar{B}=96\sqrt{2}\frac{\mathbb{E}\left[\bar{d}_{\mathsf{Y}^\star,3}(\mathsf{X},0)\right]+\Delta}{(\mu''\log e)^{\frac{3}{2}}}.$  The proof is complete upon observing that as long as n is large enough, we can always choose  $\tau>0$  so that (314) is positive.

To upper-bound  $\sum_{i=1}^{n} \Lambda_{Y^{\star}}(x_i, \lambda(x^n))$  appearing in (273), we invoke the following result.

**Lemma 5.** Assume that restrictions (i)-(iv) in Section V-B hold. There exist constants  $n_0, K_2 > 0$  such that for  $n \ge n_0$ ,

$$\mathbb{P}\left[\sum_{i=1}^{n} \Lambda_{Y^{\star}}(X_{i}, \lambda(X^{n})) \leq \sum_{i=1}^{n} \Lambda_{Y^{\star}}(X_{i}, \lambda^{\star}) + C_{2} \log n\right]$$

$$> 1 - \frac{K_{2}}{\sqrt{n}}$$
(315)

where

<span id="page-22-7"></span><span id="page-22-6"></span><span id="page-22-2"></span><span id="page-22-1"></span>
$$C_2 = \frac{\operatorname{Var}\left[\Lambda'_{Y^{\star}}(X, \lambda^{\star})\right]}{\mathbb{E}\left[|\Lambda''_{Y^{\star}}(X, \lambda^{\star})|\right] \log e}$$
(316)

*Proof.* Using (277), we have for all  $x_n \in F_n$ ,

$$\sum_{i=1}^{n} \left[ \Lambda_{Y^{\star}}(x_i, \lambda(x^n)) - \Lambda_{Y^{\star}}(x_i, \lambda^{\star}) \right]$$

$$= \sup_{|\theta| < \delta} \sum_{i=1}^{n} \left[ \Lambda_{Y^{\star}}(x_i, \lambda^{\star} + \theta) - \Lambda_{Y^{\star}}(x_i, \lambda^{\star}) \right]$$
(317)

$$= \sup_{|\theta| < \delta} \theta \sum_{i=1}^{n} \Lambda'_{Y^{\star}}(x_i, \lambda^{\star}) + \frac{\theta^2}{2} \sum_{i=1}^{n} \Lambda''_{Y^{\star}}(x_i, \lambda^{\star} + \xi_n)$$
 (318)

<span id="page-22-3"></span>
$$\leq \sup_{|\theta| < \delta} \theta S'(x^n) - \frac{\theta^2}{2} S''(x^n) \tag{319}$$

$$\leq \frac{\left(S'(x^n)\right)^2}{2S''(x^n)} \tag{320}$$

where

- <span id="page-22-4"></span>• (317) is due to (261);
- (318) holds for some  $|\xi_n| \le \delta$  by Taylor's theorem;

• in (319) we denoted

$$S'(x^n) = \sum_{i=1}^n \Lambda'_{\mathsf{Y}^{\star}}(x_i, \lambda^{\star})$$
 (321)

$$S''(x^n) = -\sum_{i=1}^n \inf_{|\theta'| < \delta} |\Lambda''_{\mathsf{Y}^{\star}}(x_i, \lambda^{\star} + \theta')| \qquad (322)$$

and used Property D;

• in (320) we maximized the quadratic equation in (319) with respect to  $\theta$ .

Note that the reasoning leading to (320) is due to [21, proof of Theorem 3]. We now proceed to upper-bound the ratio in the right side of (320). Since  $\mathbb{E}\left[\bar{d}_{Y^*,1}(X,0)\right]<\infty$  by assumption (iv) in Section V-B, the differentiation in Property A can be brought inside the expectation by (262) and the dominated convergence theorem, so

$$\mathbb{E}\left[\frac{1}{n}S'(X^n)\right] = \mathbb{E}\left[\Lambda'_{\mathsf{Y}^{\star}}(\mathsf{X},\lambda^{\star})\right] = 0 \tag{323}$$

Denote

$$V' = \operatorname{Var}\left[\Lambda'_{\mathbf{v}^{\star}}(\mathbf{X}, \lambda^{\star})\right] \tag{324}$$

$$T' = \mathbb{E}\left[\left|\Lambda'_{Y^{\star}}(X, \lambda^{\star}) - \mathbb{E}\left[\Lambda'_{Y^{\star}}(X, \lambda^{\star})\right]\right|^{3}\right]$$
(325)

If V' = 0, there is nothing to prove as that means  $S'(X^n) = 0$  a.s. Otherwise, since (262) with Hölder's inequality and assumption (iv) in Section V-B guarantee that T' is finite, the Berry-Esseen inequality (95) implies

$$\mathbb{P}\left[\left(S'(X^n)\right)^2 > V'n\log_e n\right]$$

$$\leq \frac{12T'}{V'^{\frac{3}{2}}\sqrt{n}} + 2Q\left(\sqrt{\log_e n}\right) \tag{326}$$

$$<\left(\frac{12T'}{V'^{\frac{3}{2}}} + \sqrt{\frac{2}{\pi}} \frac{1}{\sqrt{\log_e n}}\right) \frac{1}{\sqrt{n}}$$
 (327)

$$\leq \left(\frac{12T'}{V'^{\frac{3}{2}}} + \sqrt{\frac{2}{\pi \log_e 2}}\right) \frac{1}{\sqrt{n}}$$
(328)

$$=\frac{K_2'}{\sqrt{n}}\tag{329}$$

In (327), we used

<span id="page-23-3"></span>
$$Q(t) < \frac{1}{\sqrt{2\pi t}} e^{-\frac{t^2}{2}} \tag{330}$$

and (328) obviously holds for  $n \geq 2$ . To treat  $S''(X^n)$ , observe that  $S''(x^n) = n\underline{V}(x^n) \left(\log e\right)^{-1}$  (see (284)), so as before, the variance V'' and the third absolute moment T'' of  $Z_i = \inf_{|\theta'| \leq \delta} |\Lambda_{Y_*}''(X_i, \lambda^* + \theta')|$  are finite, and  $\mathbb{E}\left[Z_i\right] \geq \frac{3\mu''}{4}$  by (300), where  $\mu'' > 0$  is defined in (281). If V'' = 0, we have  $Z_i > \frac{\mu''}{2}$  almost surely. Otherwise, by the Berry-Esseen

inequality (95),

$$\mathbb{P}\left[S''(X^n) < n\frac{\mu''}{2}\right] \le \left(\frac{6T''}{V''^{\frac{3}{2}}} + \sqrt{\frac{8V''}{\pi\mu''^2}}e^{-\frac{n\mu''^2}{32V''}}\right)\frac{1}{\sqrt{n}}$$
(331)

<span id="page-23-2"></span>
$$<\left(\frac{6T''}{V''^{\frac{3}{2}}} + \sqrt{\frac{8V''}{\pi\mu''^2}}\right)\frac{1}{\sqrt{n}}$$
 (332)

<span id="page-23-5"></span>
$$=\frac{K_2''}{\sqrt{n}}\tag{333}$$

where in (331) we used (330). Finally, denoting

$$g(x^n) = \sum_{i=1}^n \Lambda_{Y^*}(x_i, \lambda(x^n)) - \sum_{i=1}^n \Lambda_{Y^*}(x_i, \lambda^*)$$
 (334)

and letting  $G_n$  be the set of  $x^n \in \mathcal{A}^n$  satisfying both

$$\left(S'(x^n)\right)^2 \le V' n \log_e n \tag{335}$$

$$S''(x^n) \ge n\frac{\mu''}{2} \tag{336}$$

we see from (275), (329), (333) applying elementary probability rules that

$$\mathbb{P}\left[g(X^{n}) > C_{2} \log n\right] \\
= \mathbb{P}\left[g(X^{n}) > C_{2} \log n, \ g(X^{n}) \le \frac{\left(S'(X^{n})\right)^{2}}{2S''(X^{n})}\right] \\
+ \mathbb{P}\left[g(X^{n}) > C_{2} \log n, \ g(X^{n}) > \frac{\left(S'(X^{n})\right)^{2}}{2S''(X^{n})}\right] \quad (337) \\
\le \mathbb{P}\left[\frac{\left(S'(X^{n})\right)^{2}}{2S''(X^{n})} > C_{2} \log n\right] + \frac{K_{1}}{\sqrt{n}} \quad (338) \\
= \mathbb{P}\left[\frac{\left(S'(X^{n})\right)^{2}}{2S''(X^{n})} > C_{2} \log n, \ X^{n} \in G_{n}\right] \\
+ \mathbb{P}\left[\frac{\left(S'(X^{n})\right)^{2}}{2S''(X^{n})} > C_{2} \log n, \ X^{n} \notin G_{n}\right] + \frac{K_{1}}{\sqrt{n}} \quad (339) \\
< 0 + \frac{K'_{2}}{\sqrt{n}} + \frac{K''_{2}}{\sqrt{n}} + \frac{K_{1}}{\sqrt{n}} \quad (340)$$

<span id="page-23-4"></span><span id="page-23-1"></span><span id="page-23-0"></span>We conclude that (315) holds for  $n \ge n_0$  with  $K_2 = K_1 + K_2' + K_2''$ .

To apply Lemmas 4 and 5 to (273), note that (272) (and hence (273)) holds for  $x^n \in F_n$  due to (296). Weakening (273) using Lemmas 4 and 5 and the union bound we conclude that Lemma 2 holds with

$$C = \frac{1}{2} + C_2 \tag{341}$$

$$K = K_1 + K_2 (342)$$

$$c = (\lambda^* + \delta)\tau - \log C_1 \tag{343}$$

### <span id="page-24-0"></span>APPENDIX E PROOF OF THEOREM 14

In this appendix, we show that (117) follows from (82). Fix a point  $(d_{\infty}, R_{\infty})$  on the rate-distortion curve such that  $d_{\infty} \in (\underline{d}, \overline{d})$ . Let  $d_n = D(n, R_{\infty}, \epsilon)$ , and let  $\alpha$  be the acute angle between the tangent to the R(d) curve at  $d = d_n$  and the d axis (see Fig. 10). We are interested in the difference  $d_n - d_{\infty}$ . Since [10]

$$\lim_{n \to \infty} D(n, R, \epsilon) = D(R), \tag{344}$$

there exists a  $\delta > 0$  such that for large enough n,

$$d_n \in \mathbb{B}_{\delta}(d_{\infty}) = [d_{\infty} - \delta, d_{\infty} + \delta] \subset (\underline{d}, \overline{d})$$
 (345)

For such  $d_n$ ,

$$|d_n - d_{\infty}| \le \left| \frac{R(d_n) - R_{\infty}}{\tan \alpha_n} \right| \tag{346}$$

$$\leq \left| \frac{R(n, d_n, \epsilon) - R(d_n)}{\min_{d \in \mathbb{B}_{\delta}(d_{\infty})} R'(d)} \right|$$
(347)

$$=O\left(\frac{1}{\sqrt{n}}\right) \tag{348}$$

where

- (346) is by convexity of R(d);
- (347) follows by substituting  $R(n, d_n, \epsilon) = R_{\infty}$  and  $\tan \alpha_n = |R'(d_n)|$ ;
- (348) follows by Theorem 12. Note that we are allowed to plug  $d_n$  into (82) because the remainder in (82) can be uniformly bounded over all d from the compact set  $\mathbb{B}_{\delta}(d_{\infty})$  (just swap  $B_n$  in (105) for the maximum of  $B_n$ 's over  $\mathbb{B}_{\delta}(d_{\infty})$ , and similarly swap  $c, K, B_n$  in (112) and (113) for the corresponding maxima); thus (82) holds not only for a fixed d but also for any sequence  $d_n \in \mathbb{B}_{\delta}(d_{\infty})$ .

It remains to refine (348) to show (117). Write

$$V(d_n) = V(d_\infty) + O\left(\frac{1}{\sqrt{n}}\right)$$
(349)

$$R(d_n) = R(d_\infty) + R'(d_\infty)(d_n - d_\infty) + O\left(\frac{1}{n}\right)$$
 (350)  
$$= R(d_n) + \sqrt{\frac{V(d_n)}{n}}Q^{-1}(\epsilon)$$

$$+R'(d_{\infty})(d_{n}-d_{\infty})+\theta\left(\frac{\log n}{n}\right)$$
(351)

$$= R(d_n) + \sqrt{\frac{V(d_\infty)}{n}} Q^{-1}(\epsilon)$$

$$+ R'(d_\infty)(d_n - d_\infty) + \theta\left(\frac{\log n}{n}\right)$$
(352)

where

- (349) and (350) follow by Taylor's theorem and (348) using finiteness of V'(d) and R''(d) for all  $d \in \mathbb{B}_{\delta}(d_{\infty})$ ;
- (351) expands  $R_{\infty} = R(n, d_n, \epsilon)$  using (82);
- (352) invokes (349).

Rearranging (352), we obtain the desired approximation (117) for the difference  $d_n - d_{\infty}$ .

![](_page_24_Figure_24.jpeg)

<span id="page-24-4"></span><span id="page-24-3"></span>Fig. 10. Estimating  $d_n - d_\infty$  from  $R(n, d, \epsilon) - R(d)$ .

### <span id="page-24-13"></span><span id="page-24-1"></span>APPENDIX F PROOF OF THEOREM 18

<span id="page-24-6"></span><span id="page-24-5"></span>From the Stirling approximation, it follows that (e.g. [39])

$$\sqrt{\frac{n}{8k(n-k)}} \exp\left\{nh\left(\frac{k}{n}\right)\right\} \le \binom{n}{k} \tag{353}$$

$$\leq \sqrt{\frac{n}{2\pi k(n-k)}} \exp\left\{nh\left(\frac{k}{n}\right)\right\}$$
(354)

In view of the inequality

<span id="page-24-16"></span><span id="page-24-14"></span>
$$\binom{n}{k-j} \le \binom{n}{k} \left(\frac{k}{n-k}\right)^j \tag{355}$$

we can write

$$\binom{n}{k} \le \binom{n}{k} \tag{356}$$

<span id="page-24-12"></span>
$$\leq \binom{n}{k} \sum_{i=0}^{\infty} \left( \frac{k}{n-k} \right)^{j} \tag{357}$$

<span id="page-24-11"></span>
$$= \binom{n}{k} \frac{n-k}{n-2k} \tag{358}$$

<span id="page-24-9"></span><span id="page-24-8"></span><span id="page-24-7"></span>where (358) holds as long as the series converges, i.e. as long as 2k < n. Furthermore, combining (356) and (358) with Stirling's approximation (353) and (354), we conclude that for any  $0 < \alpha < \frac{1}{2}$ ,

<span id="page-24-2"></span>
$$\log \left\langle \frac{n}{|n\alpha|} \right\rangle = nh\left(\alpha\right) - \frac{1}{2}\log n + O\left(1\right) \tag{359}$$

<span id="page-24-10"></span>Taking logarithms in (124) and letting  $\log M = nR$  for any  $R \ge R(n, d, \epsilon)$ , we obtain

$$\log(1 - \epsilon) \le n(R - \log 2) + \log \left\langle \frac{n}{\lfloor nd \rfloor} \right\rangle \tag{360}$$

<span id="page-24-15"></span>
$$\leq n(R - \log 2 + h(d)) - \frac{1}{2}\log n + O(1)$$
 (361)

Since (361) holds for any  $R \geq R(n, d, \epsilon)$ , we conclude that

$$R(n, d, \epsilon) \ge R(d) + \frac{1}{2} \frac{\log n}{n} + O\left(\frac{1}{n}\right)$$
 (362)

Similarly, Corollary 17 implies that there exists an  $(\exp(nR), d, \epsilon)$  code with

$$\log \epsilon \le \exp(nR) \log \left( 1 - \frac{\left\langle \binom{n}{\lfloor nd \rfloor} \right\rangle}{2^n} \right) \tag{363}$$

$$\leq -\exp\left(nR\right) \frac{\left\langle \binom{n}{\lfloor nd\rfloor} \right\rangle}{2^n} \log e$$
 (364)

where we used  $\log(1+x) \le x \log e$ , x > -1. Taking the logarithm of the negative of both sides in (364), we have

$$\log\log\frac{1}{\epsilon} \ge n(R - \log 2) + \log\left\langle \frac{n}{\lfloor nd \rfloor} \right\rangle + \log\log e \quad (365)$$

$$= n(R - \log 2 + h(d)) - \frac{1}{2}\log n + O(1), \quad (366)$$

where (366) follows from (359). Therefore,

$$R(n,d,\epsilon) \le R(d) + \frac{1}{2} \frac{\log n}{n} + O\left(\frac{1}{n}\right) \tag{367}$$

The case d=0 follows directly from (89). Alternatively, it can be easily checked by substituting  $\binom{n}{0} = 1$  in the analysis above.

## <span id="page-25-0"></span>APPENDIX G GAUSSIAN APPROXIMATION OF THE BOUND IN THEOREM 22

By analyzing the asymptotic behavior of (147), we prove that

$$R(n, d, \epsilon) \le h(p) - h(d) + \sqrt{\frac{V(d)}{n}} Q^{-1}(\epsilon) + \frac{1}{2} \frac{\log n}{n} + \frac{\log \log n}{n} + O\left(\frac{1}{n}\right)$$
(368)

where V(d) is as in (149), thereby showing that a constant composition code that attains the rate-dispersion function exists. Letting  $M=\exp{(nR)}$  and using  $(1-x)^M \leq e^{-Mx}$  in (147), we can guarantee existence of an  $(n,M,d,\epsilon')$  code with

<span id="page-25-5"></span>
$$\epsilon' \le \sum_{k=0}^{n} \binom{n}{k} p^k (1-p)^{n-k} e^{-\binom{n}{\lceil nq \rceil}^{-1} L_n(k, \lceil nq \rceil) \exp(nR)}$$

In what follows we will show that one can choose an R satisfying the right side of (368) so that the right side of (369) is upper bounded by  $\epsilon$  when n is large enough. Letting  $k=np+n\Delta,\ t=\lceil nq\rceil,\ t_0=\lceil \frac{\lceil nq\rceil+k-nd}{2}\rceil^+$  and using Stirling's formula (353), it is an algebraic exercise to show that there exist positive constants  $\delta$  and C such that for all  $\Delta \in [-\delta, \delta]$ ,

$${n \choose t}^{-1} {k \choose t_0} {n-k \choose t-t_0} = {n \choose k}^{-1} {t \choose t_0} {n-t \choose k-t_0}$$

$$\geq \frac{C}{\sqrt{n}} \exp\{ng(\Delta)\}$$
(370)

where

$$g(\Delta) = h(p+\Delta) - qh\left(d - \frac{\Delta}{2q}\right) - (1-q)h\left(d + \frac{\Delta}{2(1-q)}\right)$$

It follows that

$$\binom{n}{\lceil nq \rceil}^{-1} L_n(np + n\Delta, \lceil qn \rceil) \ge \frac{C}{\sqrt{n}} \exp\left\{-ng(\Delta)\right\}$$
 (372)

whenever  $L_n(k, \lceil qn \rceil)$  is nonzero, that is, whenever  $\lceil nq \rceil - nd \le k \le \lceil nq \rceil + nd$ , and  $g(\Delta) = 0$  otherwise.

<span id="page-25-2"></span>Applying a Taylor series expansion in the vicinity of  $\Delta = 0$  to  $g(\Delta)$ , we get

<span id="page-25-7"></span>
$$g(\Delta) = h(p) - h(d) + h'(p)\Delta + O(\Delta^2)$$
(373)

<span id="page-25-3"></span>Since  $g(\Delta)$  is continuously differentiable with g'(0) = h'(p) > 0, there exist constants  $\underline{b}, \overline{b} > 0$  such that  $g(\Delta)$  is monotonically increasing on  $(-\underline{b}, \overline{b})$  and (371) holds. Let

$$b_n = \sqrt{\frac{p(1-p)}{n}}Q^{-1}\left(\epsilon_n\right) \tag{374}$$

$$\epsilon_n = \epsilon - \frac{2B_n}{\sqrt{n}} - \sqrt{\frac{V(d)}{2\pi n}} \frac{1}{\overline{b}} e^{-n\frac{\overline{b}^2}{2V(d)}} - \frac{1}{\sqrt{n}}$$
(375)

$$B_n = 6\frac{1 - 2p + 2p^2}{\sqrt{p(1-p)}}\tag{376}$$

<span id="page-25-8"></span>
$$R = g(b_n) + \frac{1}{2} \frac{\log n}{n} + \frac{1}{n} \log \left( \frac{\log_e n}{2C} \right)$$
 (377)

Using (373) and applying a Taylor series expansion to  $Q^{-1}(\cdot)$ , it is easy to see that R in (377) can be rewritten as the right side of (368). Splitting the sum in (369) into three sums and upper bounding each of them separately, we have

<span id="page-25-4"></span>
$$\sum_{k=0}^{n} \binom{n}{k} p^{k} (1-p)^{n-k} e^{-\binom{n}{\lceil qn\rceil}^{-1} L_{n}(k,\lceil qn\rceil) \exp(nR)}$$

$$= \sum_{k=0}^{\lfloor np-n\underline{b}\rfloor} + \sum_{k=\lfloor np-n\underline{b}\rfloor+1}^{\lfloor np+nb_{n}\rfloor} + \sum_{k=\lfloor np+nb_{n}\rfloor+1}^{n}$$

$$\leq \mathbb{P} \left[ \sum_{i=1}^{n} X_{i} \leq np - n\underline{b} \right]$$

$$+ \sum_{k=\lfloor np-n\underline{b}\rfloor+1}^{\lfloor np+nb_{n}\rfloor} \binom{n}{k} p^{k} (1-p)^{n-k} e^{-\frac{C}{\sqrt{n}} \exp\left\{nR - ng\left(\frac{k}{n} - p\right)\right\}}$$

$$+ \mathbb{P} \left[ \sum_{i=1}^{n} X_{i} \geq np + nb_{n} \right]$$

$$= \sum_{k=0}^{n} \sqrt{V(d)} \prod_{i=1}^{n} \bar{b}^{2} \prod_{i=1}^{n} B_{n}$$
(379)

<span id="page-25-9"></span>
$$\leq \frac{B_n}{\sqrt{n}} + \sqrt{\frac{V(d)}{2\pi n}} \frac{1}{\bar{b}} e^{-n\frac{\bar{b}^2}{2V(d)}} + \frac{1}{\sqrt{n}} + \epsilon_n + \frac{B_n}{\sqrt{n}}$$

$$= \epsilon$$
(380)

where  $\{X_i\}$  are i.i.d. Bernoulli random variables with bias p. The first and third probabilities in the right side of (379) are bounded using the Berry-Esseen bound (95) and (330), while the second probability is bounded using the monotonicity of  $g(\Delta)$  in  $(-\underline{b},b_n]$  for large enough n, in which case the minimum difference between R and  $g(\Delta)$  in  $(-\underline{b},b_n)$  is  $\frac{1}{2}\frac{\log n}{n}+\frac{1}{n}\log\left(\frac{\log_e n}{2C}\right)$ .

## <span id="page-25-1"></span>APPENDIX H PROOF OF THEOREM 27

<span id="page-25-6"></span>In order to study the asymptotics of (161) and (163), we need to analyze the asymptotic behavior of  $S_{|nd|}$  which can

be carried out similarly to the binary case. Recalling the inequality (355), we have

$$S_k = \sum_{j=0}^k \binom{n}{j} (m-1)^j$$
 (382)

$$\leq \binom{n}{k} \sum_{i=0}^{k} \left(\frac{k}{n-k}\right)^{j} (m-1)^{k-j} \tag{383}$$

$$\leq \binom{n}{k} (m-1)^k \sum_{i=0}^{\infty} \left( \frac{k}{(n-k)(m-1)} \right)^j \tag{384}$$

$$= \binom{n}{k} (m-1)^k \frac{n-k}{n-k\frac{m}{m-1}}$$
 (385)

where (385) holds as long as the series converges, i.e. as long as  $\frac{k}{n} < \frac{m-1}{m}$ . Using

$$S_k \ge \binom{n}{k} (m-1)^k \tag{386}$$

and applying Stirling's approximation (353) and (354), we have for  $0 < d < \frac{m-1}{m}$ 

$$\log S_{\lfloor nd \rfloor} = \log \binom{n}{\lfloor nd \rfloor} + nd \log(m-1) + O(1) \quad (387)$$

$$= nh(d) + nd\log(m-1) - \frac{1}{2}\log n + O(1)$$
 (388)

Taking logarithms in (161) and letting  $\log M = nR$  for any  $R \ge R(n, d, \epsilon)$ , we obtain

$$\log(1 - \epsilon) \le n(R - \log m) + \log S_{\lfloor nd \rfloor}$$

$$\le n(R - \log m + h(d) + d\log(m - 1))$$

$$-\frac{1}{2}\log n + O(1)$$
(389)

Since (390) holds for any  $R \geq R(n, d, \epsilon)$ , we conclude that

$$R(n, d, \epsilon) \ge R(d) + \frac{1}{2} \frac{\log n}{n} + O\left(\frac{1}{n}\right)$$
 (391)

Similarly, Theorem 26 implies that there exists ar  $(\exp(nR), d, \epsilon)$  code with

$$\log \epsilon \le \exp(nR)\log\left(1 - \frac{S_{\lfloor nd\rfloor}}{m^n}\right) \tag{392}$$

$$\leq -\exp(nR)\frac{S_{\lfloor nd\rfloor}}{m^n}\log e$$
 (393)

where we used  $\log(1+x) \le x \log e$ , x > -1. Taking the logarithm of the negative of both sides of (393), we have

$$\log\log\frac{1}{\epsilon} \ge n(R - \log m) + \log S_{\lfloor nd \rfloor} + \log\log e \qquad (394)$$

$$= n(R - \log m + h(d)) - \frac{1}{2}\log n + O(1), (395)$$

where (395) follows from (388). Therefore,

$$R(n, d, \epsilon) \le R(d) + \frac{1}{2} \frac{\log n}{n} + O\left(\frac{1}{n}\right) \tag{396}$$

The case d = 0 follows directly from (89), or can be obtained by observing that  $S_0 = 1$  in the analysis above.

#### <span id="page-26-9"></span><span id="page-26-0"></span>APPENDIX I

### Gaussian approximation of the bound in Theorem 30

Using Theorem 30, we show that

<span id="page-26-2"></span>
$$R(n,d,\epsilon) \le R(d) + \sqrt{\frac{V(d)}{n}} Q^{-1}(\epsilon)$$

$$+ \frac{(m-1)(m_{\eta}-1)}{2} \frac{\log n}{n} + \frac{\log \log n}{n} + O\left(\frac{1}{n}\right)$$
(397)

where  $m_{\eta}$  is defined in (170), and V(d) is as in (190). Similar to the binary case, we express  $L_n(\mathbf{k}, \mathbf{t}^*)$  in terms of the rate-distortion function. Observe that whenever  $L_n(\mathbf{k}, \mathbf{t}^*)$  is nonzero,

$$\binom{n}{\mathbf{t}^{\star}}^{-1} L_n(\mathbf{k}, \mathbf{t}^{\star}) = \binom{n}{\mathbf{t}^{\star}}^{-1} \prod_{a=1}^{m} \binom{k_a}{\mathbf{t}_a}$$
 (398)

$$= \binom{n}{\mathbf{k}}^{-1} \prod_{a=1}^{m_{\eta}} \binom{t_b^{\star}}{\mathbf{k}_b} \tag{399}$$

<span id="page-26-3"></span><span id="page-26-1"></span>where  $\mathbf{k}_b = (t_{1,b}, \dots, t_{m,b})$ . It can be shown [34] that for n large enough, there exist positive constants  $C_1, C_2$  such that (400) and (401) at the bottom of the page hold for small enough  $|\mathbf{\Delta}|$ , where  $\mathbf{\Delta} = (\Delta_1, \dots, \Delta_m)$ . A simple calculation using  $\sum_{a=1}^m \Delta_a = 0$  reveals that

$$\sum_{a=1}^{m} \sum_{b=1}^{m_{\eta}} \delta(a,b) \log \frac{1}{P_{\mathsf{X}|\mathsf{Y}}^{\star}(a|b)}$$

$$= \sum_{a=1}^{m_{\eta}} \Delta_a \log \frac{1}{\eta} + \sum_{a=m_{\eta}+1}^{m} \Delta_a \log \frac{1}{P_{\mathsf{X}}(a)}$$
(402)

so invoking (400) and (401) one can write

$$\binom{n}{\mathbf{k}}^{-1} \prod_{a=1}^{m_{\eta}} \binom{t_b^{\star}}{\mathbf{k}_b} \ge C n^{-\frac{(m-1)(m_{\eta}-1)}{2}} \exp\left\{-ng(\mathbf{\Delta})\right\}$$
(403)

<span id="page-26-4"></span>where C is a constant, and  $g(\Delta)$  is a twice differentiable function that satisfies

$$g(\mathbf{\Delta}) = R(d) + \sum_{a=1}^{m} \Delta_a v(a) + O\left(|\mathbf{\Delta}|^2\right)$$
 (404)

<span id="page-26-8"></span><span id="page-26-7"></span><span id="page-26-6"></span><span id="page-26-5"></span>
$$v(a) = \min\left\{i_X(a), \log\frac{1}{\eta}\right\} \tag{405}$$

$$\binom{n}{\mathbf{k}} \le C_1 n^{-\frac{m-1}{2}} \exp n \left\{ H(\mathsf{X}) + \sum_{a=1}^{m} \Delta_a \log \frac{1}{P_{\mathsf{X}}(a)} + O\left(|\mathbf{\Delta}|^2\right) \right\}$$
(400)

$$\begin{pmatrix} t_b^{\star} \\ \mathbf{k}_b \end{pmatrix} \ge C_2 n^{-\frac{m-1}{2}} \exp n \left\{ P_{\mathsf{Y}}^{\star}(b) H\left(\mathsf{X} | \mathsf{Y}^{\star} = b\right) + \sum_{a=1}^{m} \delta(a, b) \log \frac{1}{P_{\mathsf{X} | \mathsf{Y}}^{\star}(a|b)} + O\left(|\mathbf{\Delta}|^2\right) \right\}$$
 (401)

Similar to the BMS case,  $g(\Delta)$  is monotonic in  $\sum_{a=1}^m \Delta_a v(a) \in (-\underline{b}, \overline{b})$  for some constants  $\underline{b}, \overline{b} > 0$  independent of n. Let

$$b_n = \sqrt{\frac{V(d)}{n}} Q^{-1}(\epsilon) \tag{406}$$

$$\epsilon_n = \epsilon - \frac{2B_n}{\sqrt{n}} - \frac{1}{\sqrt{n}} - \sqrt{\frac{V(d)}{2\pi n}} \frac{1}{\bar{b}} e^{-n\frac{\bar{b}^2}{2V(d)}}$$
(407)

$$R = \max_{\substack{\Delta : \\ \sum_{i=1}^{m} \Delta_{a} v(a) \in (-b, b_{n}]}} g(\Delta)$$

$$+\frac{(m-1)(m_{\eta}-1)}{2}\frac{\log n}{n} + \frac{1}{n}\log\left(\frac{\log_e n}{2C}\right)$$
 (408)

where  $B_n$  is the finite constant defined in (99). Using (404) and applying a Taylor series expansion to  $Q^{-1}(\cdot)$ , it is easy to see that R in (408) can be rewritten as the right side of (397). Further, we use  $nR = \log M$  and  $(1-x)^M \le e^{-Mx}$  to weaken the right side of (180) to obtain

$$\sum_{\Delta} \binom{n}{n(\mathbf{p} + \Delta)} p^{n(\mathbf{p} + \Delta)} e^{-\binom{n}{\mathbf{t}^*}^{-1} L_n(n(\mathbf{p} + \Delta), \mathbf{t}^*) \exp(nR)}$$

$$= \sum_{\substack{\Delta : \\ \sum_{a=1}^m \Delta_a v(a) \le -\underline{b}}} + \sum_{\substack{\Delta : \\ \sum_{a=1}^m \Delta_a v(a) \in (-\underline{b}, b_n)}} + \sum_{\substack{\Delta : \\ \sum_{a=1}^m \Delta_a v(a) \ge b_n \\ (409)}}$$

$$\leq \mathbb{P} \left[ \sum_{k=1}^n v(X_k) \le \mathbb{E} \left[ v(\mathsf{X}) \right] - \underline{b} \right]$$

$$+ \sup_{\substack{\Delta : \\ \sum_{a=1}^n \Delta_a v(a) \in (-\underline{b}, b_n)}} e^{-Cn^{-\frac{(m-1)(m_{\eta} - 1)}{2}} \exp n\{R - g(\Delta)\}}$$

$$+ \mathbb{P}\left[\sum_{k=1}^{n} v(X_k) \ge \mathbb{E}\left[v(\mathsf{X})\right] + \underline{b}_n\right] \tag{410}$$

$$\leq \frac{B_n}{\sqrt{n}} + \sqrt{\frac{V(d)}{2\pi n}} \frac{1}{\bar{b}} e^{-n\frac{\bar{b}^2}{2V(d)}} + \frac{1}{\sqrt{n}} + \epsilon_n + \frac{B_n}{\sqrt{n}}$$
 (411)

where  $P_{X_k}(a) = P_{\mathsf{X}}(a)$ . The first and third probabilities in (409) are bounded using the Berry-Esseen bound (95) and (330). The middle probability is bounded by observing that the difference between R and  $g(\Delta)$  in  $\sum_{a=1}^m \Delta_a v(a) \in (-\underline{b}, b_n)$  is at least  $\frac{(m-1)(m_\eta-1)}{2}\frac{\log n}{n} + \frac{1}{n}\log\left(\frac{\log_e n}{2C}\right)$ .

### <span id="page-27-0"></span>APPENDIX J PROOF OF THEOREM 34

Converse. The proof of the converse part follows the Gaussian approximation analysis of the converse bound in Theorem 32. Let  $j=n\frac{\delta}{2}+n\Delta_1$  and  $k=n\delta-n\Delta_2$ . Using Stirling's approximation for the binomial sum (359), after applying a Taylor series expansion we have

<span id="page-27-4"></span>
$$2^{-(n-k)} \left\langle \begin{matrix} n-k \\ \lfloor nd-j \rfloor \end{matrix} \right\rangle = \frac{C(\mathbf{\Delta})}{\sqrt{n}} \exp\left\{-n \ g(\Delta_1, \Delta_2)\right\} \tag{412}$$

where  $C(\Delta)$  is such that there exist positive constants  $\underline{C}$ ,  $\overline{C}$ ,  $\xi$  such that  $\underline{C} \leq C(\Delta) \leq \overline{C}$  for all  $|\Delta| \leq \xi$ , and the twice

differentiable function  $g(\Delta_1, \Delta_2)$  can be written as

$$g(\Delta_1, \Delta_2) = R(d) + a_1 \Delta_1 + a_2 \Delta_2 + O(|\Delta|^2)$$
 (413)

<span id="page-27-3"></span>
$$a_1 = \log \frac{1 - d - \frac{\delta}{2}}{d - \frac{\delta}{2}} = \lambda^* \tag{414}$$

$$a_2 = \log \frac{2\left(1 - d - \frac{\delta}{2}\right)}{1 - \delta} = \log \frac{2}{1 + \exp(-\lambda^*)}$$
 (415)

<span id="page-27-1"></span>It follows from (413) that  $g(\Delta_1, \Delta_2)$  is increasing in  $a_1\Delta_1 + a_2\Delta_2 \in (-\underline{b}, \overline{b})$  for some constants  $\underline{b}, \overline{b} > 0$  (obviously, we can choose  $\underline{b}, \overline{b}$  small enough in order for  $\underline{C} \leq C(\Delta) \leq \overline{C}$  to hold). In the sequel, we will represent the probabilities in the right side of (203) via a sequence of i.i.d. random variables  $Z_1, \ldots, Z_n$  with common distribution

<span id="page-27-10"></span>
$$Z = \begin{cases} a_1 & \text{w.p. } \frac{\delta}{2} \\ a_2 & \text{w.p. } 1 - \delta \\ 0 & \text{otherwise} \end{cases}$$
 (416)

Note that

$$\mathbb{E}\left[\mathsf{Z}\right] = \frac{a_1 \delta}{2} + a_2 (1 - \delta) \tag{417}$$

$$Var[Z] = \delta(1 - \delta) \left(a_2 - \frac{a_1}{2}\right)^2 + \frac{\delta a_1^2}{4} = V(d)$$
 (418)

<span id="page-27-2"></span>and the third central moment of Z is finite, so that  $B_n$  in (99) is a finite constant. Let

$$b_n = \sqrt{\frac{V(d)}{n}} Q^{-1} \left(\epsilon_n\right) \tag{419}$$

$$\epsilon_n = \left(1 - \frac{\bar{C}}{\sqrt{n}}\right)^{-1} \epsilon + \frac{2B_n}{\sqrt{n}} + \sqrt{\frac{V(d)}{2\pi n}} \frac{1}{\bar{b}} e^{-n\frac{\bar{b}^2}{2V(d)}} \tag{420}$$

$$R = \min_{\substack{\Delta_1, \ \Delta_2: \\ b_n < a_1 \Delta_1 + a_2 \Delta_2 < \bar{b}}} g(\Delta_1, \Delta_2) \tag{421}$$

<span id="page-27-9"></span>
$$= R(d) + b_n + O(b_n^2) (422)$$

With  $M = \exp{(nR)}$ , since  $R \leq g(\Delta_1, \Delta_2)$  for all  $a_1\Delta_1 + a_2\Delta_2 \in [b_n, \bar{b}]$ , for such  $(\Delta_1, \Delta_2)$  it holds that

<span id="page-27-6"></span>
$$\left[1 - \frac{\bar{C}}{\sqrt{n}}M\exp\left\{-n\ g(\Delta_1, \Delta_2)\right\}\right]^+ \ge 1 - \frac{\bar{C}}{\sqrt{n}} \tag{423}$$

Denoting the random variables

$$N(x) = \frac{1}{n} \sum_{i=1}^{n} 1\{Z_i = x\}$$
 (424)

<span id="page-27-11"></span>
$$G_n = n \ g\left(N(a_1) - \frac{\delta}{2}, N(a_2) - 1 + \delta\right)$$
 (425)

and using (412) to express the probability in the right side of (203) in terms of  $Z_1, \ldots, Z_n$ , we conclude that the excess-distortion probability is lower bounded by

$$\mathbb{E}\left[\left(1 - \frac{\bar{C}}{\sqrt{n}} \exp\left\{\log M - G_n\right\}\right)^{+}\right]$$

$$\geq \left(1 - \frac{\bar{C}}{\sqrt{n}}\right) \mathbb{P}\left[b_n \leq \sum_{i=1}^{n} Z_i - n\mathbb{E}\left[Z\right] < \bar{b}\right]$$
(426)

<span id="page-27-7"></span><span id="page-27-5"></span>
$$\geq \left(1 - \frac{\bar{C}}{\sqrt{n}}\right) \left(\epsilon_n - \frac{2B_n}{\sqrt{n}} - \sqrt{\frac{V(d)}{2\pi n}} \frac{1}{\bar{b}} e^{-n\frac{\bar{b}^2}{2V(d)}}\right) \tag{427}$$

<span id="page-27-8"></span>
$$=\epsilon$$
 (428)

where (426) follows from (423), and (427) follows from the Berry-Esseen inequality (95) and (330), and (428) is equivalent to (420).

Achievability. We now proceed to the Gaussian approximation analysis of the achievability bound in Theorem 33. Let

$$b_n = \sqrt{\frac{V(d)}{n}} Q^{-1} \left(\epsilon_n\right) \tag{429}$$

$$\epsilon_n = \epsilon - \frac{2B_n}{\sqrt{n}} - \sqrt{\frac{V(d)}{2\pi n}} \frac{1}{\bar{b}} e^{-n\frac{\bar{b}^2}{2V(d)}} - \frac{1}{\sqrt{n}}$$
(430)

$$\log M = n \min_{\substack{\Delta_1, \ \Delta_2: \\ b_n \leq a_1 \Delta_1 + a_2 \Delta_2 \leq \bar{b}}} g(\Delta_1, \Delta_2)$$

$$+ \frac{1}{2}\log n + \log\left(\frac{\log_e n}{2\underline{C}}\right)$$

$$= nR(d) + \sqrt{nV(d)}Q^{-1}(\epsilon)$$
(431)

$$+\frac{1}{2}\log n + \log\log n + O(1) \tag{432}$$

where  $g(\Delta_1, \Delta_2)$  is defined in (412), and (432) follows from (413) and a Taylor series expansion of  $Q^{-1}(\cdot)$ . Using (412) and  $(1-x)^M \leq e^{-Mx}$  to weaken the right side of (207) and expressing the resulting probability in terms of i.i.d. random variables  $Z_1, \ldots, Z_n$  with common distribution (416), we conclude that the excess-distortion probability is upper bounded by (recall notation (425))

$$\mathbb{E}\left[e^{-\frac{C}{\sqrt{n}}\exp\{\log M - G_n\}}\right]$$

$$\leq \mathbb{P}\left[\sum_{i=1}^{n} Z_i \geq n\mathbb{E}\left[\mathbf{Z}\right] + nb_n\right] + \mathbb{P}\left[\sum_{i=1}^{n} Z_i \leq n\mathbb{E}\left[\mathbf{Z}\right] - n\underline{b}\right]$$

$$+ \mathbb{E}\left[e^{-\frac{C}{\sqrt{n}}\exp\{\log M - G_n\}}1\left\{n\underline{b} < \sum_{i=1}^{n} Z_i - n\mathbb{E}\left[\mathbf{Z}\right] < nb_n\right\}\right]$$
(433)

$$\leq \epsilon_n + \frac{B_n}{\sqrt{n}} + \frac{B_n}{\sqrt{n}} + \sqrt{\frac{V(d)}{2\pi n}} \frac{1}{\bar{b}} e^{-n\frac{\bar{b}^2}{2V(d)}} + \frac{1}{\sqrt{n}}$$

$$= \epsilon$$

$$(434)$$

where the probabilities are upper bounded by the Berry-Esseen inequality (95) and (330), and the expectation is bounded using the fact that in  $\underline{b} < a_1 \Delta_1 + a_2 \Delta_2 < b_n$ , the minimum difference between  $\log M$  and  $n \ g(\Delta_1, \Delta_2)$  is  $\frac{1}{2} \log n + \log \left(\frac{\log_e n}{2\underline{C}}\right)$ . Finally, (435) is just (430).

## <span id="page-28-0"></span>APPENDIX K GAUSSIAN APPROXIMATION OF THE BOUND IN THEOREM 37

Using Theorem 37, we show that  $R(n,d,\epsilon)$  does not exceed the right-hand side of (234) with the remainder satisfying (236). Since the excess-distortion probability in (221) depends on  $\sigma^2$  only through the ratio  $\frac{d}{\sigma^2}$ , for simplicity we let  $\sigma^2=1$ . Using inequality  $(1-x)^M \leq e^{-Mx}$ , the right side of (221) can be upper bounded by

<span id="page-28-5"></span>
$$\int_{0}^{\infty} e^{-\rho(n,z) \exp(nR)} f_{\chi_{n}^{2}}(nz) n \ dz, \tag{436}$$

From Stirling's approximation for the Gamma function

$$\Gamma(x) = \sqrt{\frac{2\pi}{x}} \left(\frac{x}{e}\right)^x \left(1 + O\left(\frac{1}{x}\right)\right) \tag{437}$$

it follows that

$$\frac{\Gamma\left(\frac{n}{2}+1\right)}{\sqrt{\pi n}\Gamma\left(\frac{n-1}{2}+1\right)} = \frac{1}{\sqrt{2\pi n}}\left(1+O\left(\frac{1}{n}\right)\right),\tag{438}$$

<span id="page-28-3"></span>which is clearly lower bounded by  $\frac{1}{2\sqrt{\pi n}}$  when n is large enough. This implies that for all  $a^2 \le z \le b^2$  and all n large enough

$$\rho(n,z) \ge \frac{1}{2\sqrt{\pi n}} \exp\left\{ (n-1)\log\left(1 - g(z)\right)^{\frac{1}{2}} \right\}$$
 (439)

where

<span id="page-28-4"></span>
$$g(z) = \frac{(1+z-2d)^2}{4(1-d)z}$$
(440)

<span id="page-28-1"></span>It is easy to check that g(z) attains its global minimum at  $z=[1-2d]^+$  and is monotonically increasing for  $z>[1-2d]^+$ . Let

$$b_n = \sqrt{\frac{2}{n}}Q^{-1}\left(\epsilon_n\right) \tag{441}$$

$$\epsilon_n = \epsilon - \frac{2B_n}{\sqrt{n}} - \frac{1}{\sqrt{n}} - \frac{1}{4d\sqrt{\pi n}} e^{-2d^2n} \tag{442}$$

$$R = -\frac{1}{2}\log(1 - g(1 + b_n)) + \frac{1}{2}\frac{\log n}{n} + \frac{1}{n}\log(\sqrt{\pi}\log_e n)$$
(443)

where  $B_n = 12\sqrt{2}$ . Using a Taylor series expansion, it is not hard to check that R in (443) can be written as the right side of (234). So, the theorem will be proven if we show that with R in (443), (436) is upper bounded by  $\epsilon$  for n sufficiently large.

Toward this end, we split the integral in (436) into three integrals and upper bound each separately:

$$\int_0^\infty = \int_0^{[1-2d]^+} + \int_{[1-2d]^+}^{1+b_n} + \int_{1+b_n}^\infty$$
 (444)

<span id="page-28-2"></span>The first and the third integrals can be upper bounded using the Berry-Esseen inequality (95) and (330):

$$\int_{0}^{[1-2d]^{+}} \le \mathbb{P}\left[\sum_{i=1}^{n} X_{i}^{2} < n(1-2d)\right]$$
(445)

$$\leq \frac{B_n}{\sqrt{n}} + \frac{1}{4d\sqrt{\pi n}}e^{-2d^2n} \tag{446}$$

$$\int_{1+b_n}^{\infty} \le \mathbb{P}\left[\sum_{i=1}^n X_i^2 > n(1+b_n)\right] \tag{447}$$

$$\leq \epsilon_n + \frac{B_n}{\sqrt{n}} \tag{448}$$

Finally, the second integral is upper bounded by  $\frac{1}{\sqrt{n}}$  because by the monotonicity of g(z),

$$e^{-\rho(n,z)\exp(nR)} \le e^{-\frac{1}{2\sqrt{\pi n}}\exp\left\{\frac{1}{2}\log n + \log(\sqrt{\pi}\log_e n)\right\}}$$
 (449)

$$=\frac{1}{\sqrt{n}}\tag{450}$$

for all  $[1-2d]^+ \le z \le 1+b_n$ .

#### REFERENCES

- <span id="page-29-0"></span>[1] C. E. Shannon, "A mathematical theory of communication," *Bell Syst. Tech. J.*, vol. 27, pp. 379–423, July and October 1948.
- <span id="page-29-1"></span>[2] ——, "Coding theorems for a discrete source with a fidelity criterion," *IRE Int. Conv. Rec.*, vol. 7, pp. 142–163, Mar. 1959, reprinted with changes in *Information and Decision Processes*, R. E. Machol, Ed. New York: McGraw-Hill, 1960, pp. 93-126.
- <span id="page-29-2"></span>[3] I. Csisz´ar, "On an extremum problem of information theory," *Studia Scientiarum Mathematicarum Hungarica*, vol. 9, no. 1, pp. 57–71, 1974.
- <span id="page-29-3"></span>[4] R. Blahut, "Computation of channel capacity and rate-distortion functions," *IEEE Transactions on Information Theory*, vol. 18, no. 4, pp. 460–473, 1972.
- <span id="page-29-4"></span>[5] S. Verd ´u, "ELE528: Information theory lecture notes," *Princeton University*, 2009.
- <span id="page-29-5"></span>[6] T. Goblick Jr., "Coding for a discrete information source with a distortion measure," Ph.D. dissertation, M.I.T., 1962.
- <span id="page-29-6"></span>[7] J. Pinkston, "Encoding independent sample information sources," Ph.D. dissertation, M.I.T., 1967.
- <span id="page-29-7"></span>[8] D. Sakrison, "A geometric treatment of the source encoding of a Gaussian random variable," *IEEE Transactions on Information Theory*, vol. 14, no. 3, pp. 481–486, May 1968.
- <span id="page-29-8"></span>[9] J. K ¨orner, "Coding of an information source having ambiguous alphabet and the entropy of graphs," in *6th Prague Conference on Information Theory*, 1973, pp. 411–425.
- <span id="page-29-9"></span>[10] J. Kieffer, "Strong converses in source coding relative to a fidelity criterion," *IEEE Transactions on Information Theory*, vol. 37, no. 2, pp. 257–262, Mar. 1991.
- <span id="page-29-10"></span>[11] I. Kontoyiannis, "Pointwise redundancy in lossy data compression and universal lossy data compression," *IEEE Transactions on Information Theory*, vol. 46, no. 1, pp. 136–152, Jan. 2000.
- <span id="page-29-11"></span>[12] A. Barron, "Logically smooth density estimation," Ph.D. dissertation, Stanford University, 1985.
- <span id="page-29-12"></span>[13] K. Marton, "Error exponent for source coding with a fidelity criterion," *IEEE Transactions on Information Theory*, vol. 20, no. 2, pp. 197–199, Mar. 1974.
- <span id="page-29-13"></span>[14] A. J. Viterbi and J. K. Omura, *Principles of digital communication and coding*. McGraw-Hill, Inc. New York, 1979.
- [15] S. Ihara and M. Kubo, "Error exponent for coding of memoryless Gaussian sources with a fidelity criterion," *IEICE Transactions on Fundamentals of Electronics Communications and Computer Sciences E Series A*, vol. 83, no. 10, pp. 1891–1897, Oct. 2000.
- [16] T. S. Han, "The reliability functions of the general source with fixedlength coding," *IEEE Transactions on Information Theory*, vol. 46, no. 6, pp. 2117–2132, Sep. 2000.
- [17] K. Iriyama and S. Ihara, "The error exponent and minimum achievable rates for the fixed-length coding of general sources," *IEICE Transactions on Fundamentals of Electronics, Communications and Computer Sciences*, vol. 84, no. 10, pp. 2466–2473, Oct. 2001.
- <span id="page-29-14"></span>[18] K. Iriyama, "Probability of error for the fixed-length source coding of general sources," *IEEE Transactions on Information Theory*, vol. 47, no. 4, pp. 1537–1543, May 2001.
- <span id="page-29-15"></span>[19] J. Kieffer, "Sample converses in source coding theory," *IEEE Transactions on Information Theory*, vol. 37, no. 2, pp. 263–268, Mar. 1991.
- <span id="page-29-16"></span>[20] E. Yang and Z. Zhang, "On the redundancy of lossy source coding with abstract alphabets," *IEEE Transactions on Information Theory*, vol. 45, no. 4, pp. 1092–1110, May 1999.
- <span id="page-29-17"></span>[21] A. Dembo and I. Kontoyiannis, "The asymptotics of waiting times between stationary processes, allowing distortion," *Annals of Applied Probability*, vol. 9, no. 2, pp. 413–429, May 1999.
- <span id="page-29-18"></span>[22] ——, "Source coding, large deviations, and approximate pattern matching," *IEEE Transactions on Information Theory*, vol. 48, pp. 1590–1615, June 2002.
- <span id="page-29-19"></span>[23] R. Pilc, "Coding theorems for discrete source-channel pairs," Ph.D. dissertation, M.I.T., 1967.
- <span id="page-29-20"></span>[24] Z. Zhang, E. Yang, and V. Wei, "The redundancy of source coding with a fidelity criterion," *IEEE Transactions on Information Theory*, vol. 43, no. 1, pp. 71–91, Jan. 1997.
- <span id="page-29-21"></span>[25] A. D. Wyner, "Communication of analog data from a Gaussian source over a noisy channel," *Bell Syst. Tech. J*, vol. 47, no. 5, pp. 801–812, May/June 1968.
- <span id="page-29-22"></span>[26] T. S. Han, *Information spectrum methods in information theory*. Springer, Berlin, 2003.
- <span id="page-29-23"></span>[27] Y. Polyanskiy, H. V. Poor, and S. Verd ´u, "Channel coding rate in finite blocklength regime," *IEEE Transactions on Information Theory*, vol. 56, no. 5, pp. 2307–2359, May 2010.

- <span id="page-29-24"></span>[28] A. Ingber and Y. Kochman, "The dispersion of lossy source coding," in *Data Compression Conference (DCC)*, Snowbird, UT, Mar. 2011, pp. 53–62.
- <span id="page-29-25"></span>[29] V. Strassen, "Asymptotische absch¨atzungen in Shannon's informationstheorie," *Thans. 3rd Prague Conf. Inf. Theory, Prague*, pp. 689–723, 1962.
- <span id="page-29-26"></span>[30] A. Dembo and I. Kontoyiannis, "Critical behavior in lossy source coding," *IEEE Transactions on Information Theory*, vol. 47, no. 3, pp. 1230–1236, 2001.
- <span id="page-29-27"></span>[31] W. Feller, *An introduction to probability theory and its applications*, 2nd ed. John Wiley & Sons, 1971, vol. II.
- <span id="page-29-29"></span><span id="page-29-28"></span>[32] T. Berger, *Rate distortion theory*. Prentice-Hall Englewood Cliffs, NJ, 1971.
- [33] V. Erokhin, "Epsilon-entropy of a discrete random variable," *Theory of Probability and Applications*, vol. 3, pp. 97–100, 1958.
- <span id="page-29-30"></span>[34] W. Szpankowski and S. Verd ´u, "Minimum expected length of fixedto-variable lossless compression without prefix constraints: memoryless sources," *IEEE Transactions on Information Theory*, vol. 57, no. 7, pp. 4017–4025, 2011.
- <span id="page-29-31"></span>[35] E. Martinian and J. Yedidia, "Iterative quantization using codes on graphs," *Proceedings of the 41st Annual Allerton Conference on Communication, Control, and Computing; Monticello, IL*, Sep. 2004.
- <span id="page-29-32"></span>[36] C. Shannon, "Probability of error for optimal codes in a Gaussian channel," *Bell Syst. Tech. J*, vol. 38, no. 3, pp. 611–656, 1959.
- <span id="page-29-33"></span>[37] C. A. Rogers, "Covering a sphere with spheres," *Mathematika*, vol. 10, no. 02, pp. 157–164, 1963.
- <span id="page-29-34"></span>[38] J. L. Verger-Gaugry, "Covering a ball with smaller equal balls in R n," *Discrete and Computational Geometry*, vol. 33, no. 1, pp. 143–155, 2005.
- <span id="page-29-35"></span>[39] R. Gallager, *Information theory and reliable communication*. John Wiley & Sons, Inc. New York, 1968.

Victoria Kostina (S'12) received the Bachelors degree with honors in applied mathematics and physics from the Moscow Institute of Physics and Technology, Russia, in 2004, where she was affiliated with the Institute for Information Transmission Problems of the Russian Academy of Sciences, and the Masters degree in electrical engineering from the University of Ottawa, Canada, in 2006.

She is currently pursuing a Ph.D. degree in electrical engineering at Princeton University. Her research interests lie in information theory, theory of random processes, coding, and wireless communications.

Sergio Verd ´u (S'80–M'84–SM'88–F'93) is on the faculty of the School of Engineering and Applied Science at Princeton University.

A member of the National Academy of Engineering, Verd ´u is the recipient of the 2007 Claude E. Shannon Award and of the 2008 IEEE Richard W. Hamming Medal.

In addition to the 28th Shannon Lecture, Verd ´u has given the inaugural Nyquist Lecture at Yale University, the sixth Claude E. Shannon Memorial Lecture at the University of California, San Diego, and the tenth Viterbi Lecture at the University of Southern California.