### **Extremal Properties of Rate-Distortion Functions**

RUDOLF AHLSWEDE

Abstract — At a recent workshop (Hakone, Japan, July 1-2, 1988) I. Csiszár stated that in spite of strong efforts the following question had been waiting for an answer for many years. Is it true that for fixed distortion level  $\Delta$  the rate-distortion function  $R(P, \Delta)$  has in the distribution P no local maxima with values different from the global maximum? It is shown that in general the answer is negative. However the answer is positive for Hamming distortion measures. Moreover their R is Schur-

### I. BASIC CONCEPTS AND AUXILIARY RESULTS

Let  $(X_t)_{t=1}^{\infty}$  be a discrete memoryless source (DMS), that is, a sequence of independent and identically distributed random variables (RV's) with values of a finite set  $\mathcal{X}$ . We are also given a finite reconstruction space  $\hat{\mathcal{X}}$  and a per-letter distortion measure

$$d: X \times \hat{\mathcal{X}} \to \mathbf{R}_{\perp}. \tag{1.1}$$

For a function F defined on a product space  $Y^n$ , we use the

rate 
$$(F) = \frac{1}{n} \log_2 ||F||$$
,  $||F|| =$  the cardinality of the range of  $F$ .

For an encoding function  $f_n: X^n \to \hat{\mathcal{X}}^n$ , we consider the reproduction

$$\hat{X}^n = (\hat{X}_1, \dots, \hat{X}_n) = f_n(X^n)$$
(1.3)

and the average distortion  $dist(f_n)$ , defined by

$$\operatorname{dist}(f_n) = \mathbf{E} \frac{1}{n} \sum_{t=1}^{n} d(X_t, \hat{X}_t). \tag{1.4}$$

 $\rho$  is said to be an  $\epsilon$ -achievable rate for distortion level  $\Delta$ , if for all large n there are encoding functions  $f_n$  with

$$rate(f_n) \le \rho, \quad dist(f_n) \le \Delta + \epsilon.$$
 (1.5)

Now

$$R(\Delta) = \inf \left( \bigcap_{\epsilon > 0} \left\{ \rho : \rho \text{ is } \epsilon\text{-achievable for } \Delta \right\} \right)$$
 (1.6)

can be seen to be the smallest rate which for arbitrarily small  $\epsilon$  is  $\epsilon$ -achievable for  $\Delta$ . This quantity depends on the generic distribution  $P_V$  of the source. Thus we get a function

$$R: P(\mathcal{X}) \times \mathbf{R}_{\perp} \to \mathbf{R}_{\perp}$$

$$\mathscr{P}(\mathscr{X})$$
 = set of probability distribution (PD's) on  $\mathscr{X}$ , (1.7)

of two variables, which was introduced by Shannon [1] and is called the rate-distortion function.

is of the form for m = 0

$$R(Q,\Delta) = \begin{cases} S_m [H(Q_m) - h(\Delta *) - \Delta * \log(m-1)], & \text{for } m = 0 \\ H(Q) - h(\Delta) - \Delta \log(\alpha - 1), & \text{for } m = 0 \end{cases}$$

Manuscript received August 30, 1988.

The author is with the Fakultät für Mathematik, Universität Bielefeld, Postfach 8640, 4800 Bielefeld 1, FRG.

IEEE Log Number 8933105.

Using time-sharing one readily verifies with the foregoing definitions that  $R(P, \Delta)$  is convex in  $\Delta$  for every  $P \in P(\mathcal{X})$ . A remarkable characterization of R is due to Shannon [1].

### A. Rate-Distortion Theorem

Let  $(X, \hat{X})$  denote a pair of RV's with values in  $\mathcal{X} \times \hat{\mathcal{X}}$  and  $I(X \wedge \hat{X})$  their mutual information. Then

$$R(P, \Delta) = \min_{(X, \hat{X}): P_X = P, Ed(X, \hat{X}) \le \Delta} I(X \wedge \hat{X}),$$

$$\forall \Delta \in \mathbf{P} \quad \text{and} \quad B \in P(\mathscr{X})$$

This formula has been used to derive several analytical properties of R, mainly as function of  $\Delta$ . Whereas those properties can be found in many textbooks, the properties of R as function of P are not as well understood.

An exception seems to be the following basic result of Erokhin [6], which was independently found and derived from Shannon's formula by Gallager (Theorem 9.5.1 and its extension on p. 467-469 in [2]). For its formulation we need some notation.

Let the elements in  ${\mathscr X}$  be labelled such that for fixed distribu-

$$Q(0) \ge Q(1) \ge \cdots \ge Q(\alpha - 1), \qquad \sum_{i=0}^{\alpha - 1} Q(i) = 1. \quad (1.8)$$

For the fixed distortion level  $\Delta$  let m be the smallest nonnegative integer with

$$mQ(m) + \sum_{k=m+1}^{\alpha-1} Q(K) \le \Delta \le (m-1)Q(m-1) + \sum_{k=m}^{\alpha-1} Q(k).$$
(1.9)

The conventional understanding of (1.9) is for m = 0

$$1 - Q(0) \le \Delta \le 1 \tag{1.10}$$

and for  $m = \alpha$ 

$$0 \le \Delta \le (\alpha - 1) Q(\alpha - 1). \tag{1.11}$$

We also use the abbreviations

$$S_m = \sum_{k=0}^{m-1} Q(k), \qquad T_m = 1 - S_m$$
 (1.12)

and the quantities

$$Q_m = \left(\frac{Q(0)}{S_m}, \dots, \frac{Q(m-1)}{S_m}\right), \qquad \Delta * = \frac{\Delta - T_m}{S_m}. \quad (1.13)$$

Theorem 0: For the Hamming distortion measure the rate-distortion function

$$R: \mathscr{P}(\mathscr{X}) \times [0,1] \to \mathbb{R}$$

for 
$$m = 0$$
  
otherwise  $\log (\alpha - 1)$ , for  $m = \alpha$ 

By the result in case  $m = \alpha$  one has

$$R(Q,0) = H(Q) \tag{1.14}$$

and one may therefore expect that R has similar convexity

properties than H. Already the case  $\mathcal{X} = \{0,1\}$  is instructive. One readily verifies that

$$R(Q,\Delta) = \begin{cases} 0, & \text{if } Q(1) \le \Delta \le 1\\ h(Q(1)) - h(\Delta), & \text{if } 0 \le \Delta \le Q(1) \le \frac{1}{2} \end{cases}$$
 (1.15)

Therefore R is *not* concave in Q. However our main result says that in the Hamming case even for general alphabets another basic convexity property of entropy generalizes to R, namely the property Schur-concavity.

We recall this concept. For two distributions  $P = (P(0), \dots, P(\alpha - 1))$  and  $Q = (Q(0), \dots, Q(\alpha - 1))$ . We say that P majorizes Q and write P > Q, if

$$\sum_{i=0}^{k} P[i] \ge \sum_{i=0}^{k} Q[i], \quad \text{for } k = 0, 1, \dots, \alpha - 1, \quad (1.16)$$

where P[i] (resp. Q[i]) is the *i*th largest component of P (resp. Q). A function  $\varphi: \mathcal{P}(\mathcal{X}) \to \mathbf{R}$  is Schur-concave, if

$$P > Q$$
 implies  $\varphi(P) \le \varphi(Q)$ , (1.17)

and it is strictly Schur-concave, if

$$P > Q$$
 and  $P \neq Q$  imply  $\varphi(P) < \varphi(Q)$ . (1.18)

## II. THE KEY IDEAS AND A BASIC INEQUALITY

At the Hakone workshop Csiszár also stated that the truth of the main statement

 R has no local maxima in P with values different from the global maximum

would follow from the truth of anyone of the following:

- 1) R is quasiconcave in P,
- 2) R is concave in P on  $\mathcal{P}(\mathcal{X}, \Delta) = \{ P \in \mathcal{P}(\mathcal{X}) : R(P, \Delta) > 0 \}.$

Recall that quasiconcavity means that the level sets  $\{P \in \mathcal{P}(\mathcal{X}): R(P, \Delta) > \rho\}$  are convex for all  $\rho \ge 0$ . Clearly 2) implies 1). In order to better understand the main statement, we studied first 1). We explain now our ideas to disprove 1). Those lead naturally to the counterexample to the main statement in Section IV. To find distributions  $P_1$  and  $P_2$  with

$$R(P_i, \Delta) \ge \rho$$
, for  $i = 1, 2$ ;  $R\left(\frac{1}{2}P_1 + \frac{1}{2}P_2, \Delta\right) \le \rho - \delta$  (2.1)

we consider a new DMS with generic distribution

$$\overline{P} = \frac{1}{2}P_1 + \frac{1}{2}P_2. \tag{2.2}$$

Clearly, its n-variate distribution is

$$\overline{P}^n = \prod_{1}^n \overline{P}.$$
 (2.3)

In order to get a link to sources involving  $P_1$  and  $P_2$  we view  $\overline{P}^n$  as an average over the arbitrarily varying source (AVS) defined by the set of distributions  $\{P_1, P_2\}$  that was studied intensively in [4] [5].

The set of n-variate distributions is

$$\mathscr{A}_n = \left\{ P(\cdot | s^n) : s^n \in \left\{1, 2\right\}^n \right\},\,$$

where

$$P(x^{n}|s^{n}) = \prod_{t=1}^{n} P_{s_{t}}(x_{t}), \quad \text{for } s^{n} = (s_{1}, \dots, s_{n}) \in \{1, 2\}^{n}$$

and

$$x^n = (x_1, \dots, x_n) \in X^n.$$
 (2.4)

For the distribution q on  $\{1,2\}$  with q(1) = q(2), we clearly have for  $q'' = \prod_{i=1}^{n} q$ 

$$\overline{P}(x^n) = \sum_{n} p(x^n | s^n) q^n(s^n). \tag{2.5}$$

In the light of this formula one can view the operation of  $\overline{P}^n$  as producing with "high probability" a string  $s^n$  in which the number  $\langle 1|s^n\rangle$  of 1's and number  $\langle 2|s^n\rangle$  of 2's is "approximately equal" to n/2.

Therefore  $p(\cdot|s^n)$  is typically of the form  $\prod_1^{n/2}P_1 \times \prod_1^{n/2}P_2$ . What is the rate-distortion function for such a nonstationary source? More generally, if  $\lambda$  is the fraction of  $P_1$ 's in the product, the answer is in obvious notation

$$R(P_1, P_2, \lambda, \Delta) = \frac{\inf}{|\gamma| \le \Delta} \left[ \lambda R(P_1, \Delta + \gamma) + (1 - \lambda) R(P_2, \Delta - \gamma) \right], \quad (2.6)$$

which is smaller than  $\lambda R(P_1, \Delta) + (1 - \lambda) R(P_2, \Delta)$ .

The exact difference

$$V(P_1, P_2, \lambda, \Delta) = \lambda R(P_1, \Delta) + (1 - \lambda) R(P_2, \Delta)$$
$$- R(P_1, P_2, \lambda, \Delta) \quad (2.7)$$

depends on the slopes of  $R(P_1, \Delta)$  and  $R(P_2, \Delta)$  as functions of  $\Delta$ . There is no reason why this difference cannot become arbitrary big by proper choices of  $P_1, P_2$  and the distortion measure d. But then this fact can be exploited for  $\overline{P}$  via the AVS by a simple trick. Let us consider only  $P_1, P_2$  with disjoint supports. Then the encoder can identify  $s^n$  and he can inform the decoder with n bits, that is, at a rate 1. Quasiconcavity is then disproved if the difference mentioned can be made bigger than 1. Of course our idea to estimate the rate-distortion function via AVS's works for general convex combinations

$$\vec{P} = \sum_{i=1}^{l} \lambda_i P_i, \qquad \lambda = (\lambda_1, \dots, \lambda_l). \tag{2.8}$$

Viewing  $\overline{P}$  as a  $\lambda$ -average over the AVS with generic distributions  $\mathscr{A} = \{P_i: 1 \le i \le l\}$  for any  $\eta > 0$ , we can find by Chebyshev's inequality a  $c(\eta) > 0$  and an  $n(\eta)$  such that for  $n \ge n(\eta)$  with a probability greater than  $1 - e^{-c(\eta)n}$  the relative frequencies  $\lambda_i + \eta_i$  for  $P_i$  satisfy  $|\eta_i| \le \eta$ . Therefore, as  $\eta \to 0$  and  $n \to \infty$  we conclude

$$R(\overline{P}, \Delta) \ge \min \left\{ \sum_{i=1}^{l} \lambda_i R(P_i, \Delta + \gamma_i) : \sum_{i=1}^{l} \gamma_i = 0, |\gamma_i| \le \Delta \right\}.$$
(2.9)

Even more importantly, we have also an inequality upper bounding  $R(\overline{P}, \Delta)$ . For  $\mathscr{X} = \{0, 1, \dots, \alpha - 1\}$  let  $\mathscr{X}(i) = \{(0, i), \dots, (\alpha - 1, i)\}$   $(i = 1, \dots, l)$  be l copies of  $\mathscr{X}$ , which are disjoint sets. Define a distortion measure  $d^*$  on  $\mathscr{X}^* = \bigcup_{i=1}^l \mathscr{X}(i)$  by

$$d^*((j,i),(j',i')) = d(j,j'), \tag{2.10}$$

where d is our original distortion measure on  $\mathcal{X}$ . Also define  $P^*$ on  $X^*$  by

$$P^*((j,i)) = \lambda_i P_i(j) \tag{2.11}$$

and the AVS  $\mathscr{A}^* = \{ P_i^* : 1 \le i \le l \}$ , where  $P_i^*((j, i)) = P_i(j)$  for  $j = 0, \dots, \alpha - 1$ . As earlier the encoder can now record  $s^n$ . Here by the source coding theorem a rate  $H(\lambda)$  suffices for a recording that is false with arbitrarily small probability.

Thus we have derived

$$R(P^*, \Delta) \leq \min \left\{ \sum_{i=1}^{l} \lambda_i R(P_i, \Delta + \epsilon_i) : \sum_{i=1}^{l} \epsilon_i = 0, |\epsilon_i| \leq \Delta \right\} + H(\lambda). \quad (2.12)$$

Identification of all points (j, i)  $(i = 1, \dots, l)$  with j transforms  $d^*$  into d and  $P^*$  into P. Therefore a code for the  $P^*$ -source gets transformed into a code for the  $\overline{P}$ -source with at least the same distortion level guaranteed. We summarize our findings.

#### A. Basic Inequality

For any distortion measure d and any  $\Delta \in \mathbf{R}_+$  for  $\overline{P} = \sum_{i=1}^{l} \lambda_i P_i$ 

- 1)  $R(\overline{P}, \Delta) \ge \min\{\sum_{i=1}^{\ell} \lambda_i R(P_i, \Delta + \epsilon_i) : \sum \epsilon_i = 0, |\epsilon_i| \le \Delta\}$ 2)  $R(\overline{P}, \Delta) \le \min\{\sum_{i=1}^{\ell} \lambda_i R(P_i, \Delta + \epsilon_i) : \sum \epsilon_i = 0, |\epsilon_i| \le \Delta\} +$  $H(\lambda)$ .

## III. SCHUR-CONCAVITY IN THE HAMMING CASE

We consider the case  $\mathscr{X} = \hat{\mathscr{X}}$ ,  $d = d_H$ , where

$$d_{II}(x,\hat{x}) = \begin{cases} 0, & \text{if } x = \hat{x} \\ 1, & \text{if } x \neq \hat{x} \end{cases}. \tag{3.1}$$

For fixed  $\Delta \in [0,1]$ ,  $P \in \mathcal{P}(\mathcal{X})$  is a local maximum of R if for some neighborhood  $\mathcal{U}(P)$ 

$$R(P,\Delta) \ge R(Q,\Delta), \quad \forall Q \in U(P).$$
 (3.2)

The local maximum is called strict, if

$$R(P,\Delta) > R(Q,\Delta), \quad \forall Q \in U(P) - \{P\}.$$
 (3.3)

Theorem 1: In the Hamming case for each  $\Delta \in [0,1]$  R has no strict local maximum other than the global maximum at  $(1/\alpha,\cdots,1/\alpha)$ .

Proof: We do not use Theorem 0 here or even Shannon's result from Section I. As in [5, Sect. 5] we exploit symmetry. Let  $\Pi$  be the symmetric group (the group of permutations) acting on  $\mathscr{X} = \{0, 1, \dots, \alpha - 1\}$ . For  $\pi \in \Pi$  and  $P = (P(0), \dots, P(\alpha - 1)) \in$  $\mathscr{P}(\mathscr{X})$  we denote  $(P(\pi(0)), \dots, P(\pi(\alpha-1)))$  by  $\pi P$ . Obviously since  $d_H(x, \hat{x}) = d_H(\pi(x), \pi(\hat{x}))$ 

$$R(P,\Delta) = R(\pi P, \Delta), \quad \text{for } \Delta \in [0,1].$$
 (3.4)

Now for any  $P' \in \text{conv}\{\pi P : \pi \in \Pi\}$  we have

$$P' = \sum_{\pi \in \Pi} \lambda(\pi) \cdot \pi P, \quad \lambda(\pi) \ge 0, \quad \sum_{\pi \in \Pi} \lambda(\pi) = 1. \quad (3.5)$$

Consider the AVS with  $\mathcal{A} = \{ \pi P : \pi \in \Pi \}$  and the discrete memoryless source with generic distribution P'.

From the basic inequality 1) in Theorem 2

$$R(P', \Delta) \ge \min \left\{ \sum_{\pi \in \Pi} \lambda(\pi) R(\pi P, \Delta + \gamma(\pi)) : \sum_{\pi} \gamma(\pi) = 0, \quad |\gamma(\pi)| \le \Delta \right\}. \quad (3.6)$$

However by (3.4) the quantity on the right side in (3.6) equals  $R(P, \Delta)$ .

Since for  $P \neq (1/\alpha, \dots, 1/\alpha)$  P' can be chosen arbitrarily close to but different from P, there cannot be a strict local maximum other than at  $(1/\alpha, \dots, 1/\alpha)$ . Clearly, since for every P  $(1/\alpha, \dots, 1/\alpha) \in \text{conv}\{\pi P : \pi \in \Pi\}$ , the global maximum is assumed at  $(1/\alpha, \dots, 1/\alpha)$ . A stronger conclusion can be drawn from our main result.

Theorem 2: In the Hamming case

- 1) R is Schur-concave on  $\mathcal{P}(\mathcal{X})$ , for every  $\Delta \in [0,1]$ .
- 2)  $R(P, \Delta) = 0$ . for all  $P \in \mathcal{P}(\mathcal{X})$  and  $\Delta \in [(\alpha - 1)/\alpha, 1]$ ; for  $\Delta \in [0,(\alpha-1)/\alpha]$  R has no local maximum in P other than the global maximum at  $(1/\alpha, \dots, 1/\alpha)$ .
- 3) Statement (A) is true.

Proof: 3) obviously follows from 2). The first part of 2) follows from Theorem 0. While we prove 1) we also shall prove the second statement in 2).

Since  $R(\pi P, \Delta) = R(P, \Delta)$  it suffices to consider  $P, Q \in \mathcal{P}(Q)$ with Q > P and  $P(0) \ge P(1) \ge \cdots \ge P(\alpha - 1), Q(0) \ge Q(1) \ge C$  $\cdots \ge Q(\alpha-1)$ . It is well-known (see [6]) that there are finitely many transfers  $U_{i,\epsilon}$ :  $Q \rightarrow Q_{i,\epsilon}$ , where

$$Q_{i,\epsilon} = (Q(0), Q(1), \cdots, Q(i) - \epsilon, Q(i+1) + \epsilon, \cdots) \quad (3.7)$$

$$Q(i) - \epsilon \ge Q(i+1) + \epsilon, \tag{3.8}$$

in which the successive applications finally transform Q into P. We have to show that such a transfer increases R on  $\mathcal{P}(\mathcal{X}, \Delta)$ .

$$R(Q_{i,\epsilon}, \Delta) \ge R(Q, \Delta), \quad \text{for } \epsilon > 0.$$
 (3.9)

Since  $R(Q, \Delta) = 0$  for  $Q \notin \mathscr{P}(\mathscr{X}, \Delta)$  and always  $R(P, \Delta) \ge 0$ , only Schur-concavity on  $\mathscr{P}(\mathscr{X},\Delta)$  remains to be shown. That is the m defined in (1.9) may have values between 2 and  $\alpha$ . By the assumed minimality of m we have

$$mQ(m) + \sum_{k=m+1}^{\alpha-1} Q(k) \le \Delta < (m-1)Q(m-1) + \sum_{i=m}^{\alpha-1} Q(k)$$
(3.10)

for these values of m.

Now notice that transfers for  $i = 0, 1, \dots, m-3, m+1, \dots, \alpha$ 1 have no effect on either side in (3.10). They also leave  $S_m$ ,  $T_m$ and  $Q_m$  invariant. By Theorem 0 also R does not change. For i = m - 2 (resp. i = m) the right (resp. left) side in (3.10) increases (resp. decreases), but as before  $S_m, T_m$  and finally R do not

Only the case i = m - 1 needs serious consideration. We show that for transfers  $U_{m-1,\beta}$  with

$$\Delta < (m-1)(Q(m-1)-\beta) + (Q(m)+\beta) + \sum_{i=m+1}^{\alpha-1} Q(k)$$
(3.11)

$$R(U_{m-1,\beta}Q,\Delta) > R(Q,\Delta).$$

![](_page_2_Picture_46.jpeg)

For this we calculate first the change in rate.

$$R(U_{m-1,\beta}Q, \Delta) - R(Q, \Delta) = (S_{m} - \beta) \left[ H\left(\frac{Q(0)}{S_{m} - \beta}, \dots, \frac{Q(m-1) - \beta}{S_{m} - \beta}\right) - h\left(\frac{\Delta - (T_{m} + \beta)}{S_{m} - \beta}\right) - \frac{\Delta - (T_{m} + \beta)}{S_{m} - \beta} \log(m-1) \right] - S_{m} \left[ H\left(\frac{Q_{0}}{S_{m}}, \dots, \frac{Q(m-1)}{S_{m}}\right) - h\left(\frac{\Delta - T_{m}}{S_{m}}\right) - \frac{\Delta - T_{m}}{S_{m}} \log(m-1) \right] = + (S_{m} - \beta) \log(S_{m} - \beta) - S_{m} \log S_{m} - (Q(m-1) - \beta) \log(Q(m-1) - \beta) + Q(m-1) \log Q(m-1) - (S_{m} - \beta) h\left(\frac{1 - \Delta}{S_{m} - \beta}\right) + S_{m} h\left(\frac{1 - \Delta}{S_{m}}\right) + \beta \log(m-1).$$

It suffices now to show that

$$\omega(\beta) = \frac{d}{d\beta} \left[ R(U_{m-1,\beta}Q, \Delta) - R(Q, \Delta) \right] > 0$$

for  $\beta$  satisfying (3.11).

We use that for  $f(\beta) = (x - \beta)\log(x - \beta)$ 

$$f'(\beta) = -\log(x - \beta) - 1$$
 (3.12)

and that

$$h'(y) = \log \frac{1-y}{y}$$
. (3.13)

Now

$$\omega(\beta) = -\log(S_{m} - \beta) + \log(Q(m-1) - \beta) + \log(m-1)$$

$$+ h\left(\frac{1-\Delta}{S_{m} - \beta}\right) - \frac{1-\Delta}{S_{m} - \beta} \left[\log \frac{S_{m} - \beta}{1-\Delta} - 1\right]$$

$$= \log \frac{(m-1)(Q(m-1) - \beta)}{S_{m} - \beta}$$

$$- \frac{1-\Delta}{S_{m} - \beta} \log \frac{1-\Delta}{S_{m} - \beta} - \left(1 - \frac{1-\Delta}{S_{m} - \beta}\right) \log\left(1 - \frac{1-\Delta}{S_{m} - \beta}\right)$$

$$- \frac{1-\Delta}{S_{m} - \beta} \log \frac{S_{m} - \beta - (1-\Delta)}{1-\Delta}$$

$$= \log \frac{(m-1)(Q(m-1) - \beta)}{S_{m} - \beta} + \log \frac{S_{m} - \beta}{S_{m} - \beta - (1-\Delta)}$$

$$= \log \frac{(m-1)(Q(m-1) - \beta)}{S_{m} - \beta}.$$

Since  $\Delta < (m-1)(Q(m-1)-\beta)+T_m+\beta$ , we have  $(m-1)(Q(m-1)-\beta)>\Delta-T_m-\beta=S_m-\beta-(1-\Delta)$  and thus  $\omega(\beta)>0$ . Notice that there cannot be a local maximum at Q unless  $m=\alpha$  and thus  $\Delta < (\alpha-1)Q(\alpha-1)$ . In this case the transfer is not defined.

However, since Q > P implies  $P(\alpha - 1) \ge Q(\alpha - 1)$ , we have also  $\Delta < (\alpha - 1)P(\alpha - 1)$  and by Theorem 0 not only

$$R(Q, \Delta) = H(Q) - h(\Delta) - \Delta \log(\alpha - 1)$$

but also

$$R(P, \Delta) = H(P) - h(\Delta) - \Delta \log(\alpha - 1)$$

holds. The fact that the entropy function H is strictly Schur-concave completes the proof.

Remark: The proof shows that R stays constant for transfers  $U_{i,\epsilon}(i \neq m-1)$ . Therefore (C) is not true even in the Hamming

case. We have not decided upon (B). It is worth knowing that symmetry and quasiconcavity imply Schur-concavity, but not conversely (see [6], p. 69).

#### IV. THE COUNTEREXAMPLE

Let us consider a simple distortion measure  $\tau$ , which does not equal the Hamming distortion measure.  $\mathscr{X}$  is partitioned into two sets  $\mathscr{Y}$  and  $\hat{\mathscr{X}} = \hat{\mathscr{Y}} \cup \hat{\mathscr{Z}}$ , where  $\hat{\mathscr{Y}} = \mathscr{Y}$ ,  $\hat{\mathscr{Z}} = \mathscr{Z}$ 

$$\tau(x,\hat{x}) = \begin{cases} 0, & \text{if } x = \hat{x} \\ 1, & \text{if } x \neq \hat{x} \text{ and } x, \hat{x} \in \mathcal{Y} \\ a, & \text{if } x \neq \hat{x} \text{ and } x, \hat{x} \in \mathcal{Z} \end{cases}$$

$$b, & \text{otherwise}$$

$$(4.1)$$

Basic in our analysis are the uniform distributions  $Q_1$  and  $Q_2$  on  $\mathscr{Y}$  resp.  $\mathscr{Z}$ , that is,

$$Q_1(x) = |\mathcal{Y}|^{-1}, \quad \text{for } x \in \mathcal{Y}$$

$$Q_2(x) = |\mathcal{Z}|^{-1}, \quad \text{for } x \in \mathcal{Z}. \tag{4.2}$$

The reduction to these distributions proceeds as follows. Any distribution  $P \in \mathcal{P}(\mathcal{X})$  can be written as  $\lambda P_1 + (1 - \lambda) P_2$ , where

$$P_1(x) = P(x) \left( \sum_{x \in \mathscr{A}} P(x) \right)^{-1}, \quad \text{for } x \in \mathscr{Y}$$
 (4.3)

$$P_2(x) = P(x) \left(\sum_{x \in \mathscr{Z}} P(x)\right)^{-1}, \quad \text{for } x \in \mathscr{Z}$$
 (4.4)

$$\lambda = \sum_{x \in \mathscr{A}} P(x) \tag{4.5}$$

and therefore  $P_1 \in \mathcal{P}(\mathcal{Y}), P_2 \in \mathcal{P}(\mathcal{Z})$ .

Lemma 1: For the distortion measure  $\tau$ , any  $\Delta$  and any  $P = \lambda P_1 + (1 - \lambda) P_2 \in \mathscr{P}(\mathscr{X}), P_1 \in \mathscr{P}(\mathscr{Y}), P_2 \in \mathscr{P}(\mathscr{Z})$ , the inequality

$$R(\lambda O_1 + (1 - \lambda) O_2, \Delta) \ge R(P, \Delta)$$
 (4.6)

holds.

*Proof:* We follow the idea in the proof of Theorem 1. The only difference is that now we have the groups of permutations  $\pi$  on  $\mathscr Y$  and  $\Sigma$  on  $\mathscr Z$  and we define

$$(\pi,\sigma)P = \lambda \pi P_1 + (1-\lambda)\sigma P_2. \tag{4.7}$$

Notice that

$$\sum_{(\boldsymbol{\pi},\boldsymbol{\sigma})\in[1]\times\Sigma} (\boldsymbol{\pi},\boldsymbol{\sigma}) P |\prod|^{-1} |\sum|^{-1} = \lambda Q_1 + (1-\lambda) Q_2$$

and, as explained in earlier sections, (4.6) holds.

In order to show that there are two local maxima with different values, we define three sets of distributions with the property that every continuous path from the first set to the third has to meet the second.

For  $c \in (0,1/2)$  the sets are

$$\begin{array}{ll} \mathcal{Q}_1^c = & \big\{\lambda Q_1 + (1-\lambda)Q_2 \colon \lambda \geq 1-c\big\}, \\ \mathcal{B}^c = & \big\{\lambda P_1 + (1-\lambda)P_2 \colon P_1 \in P(\mathcal{Y}), P_2 \in \mathcal{P}(\mathcal{Z}), c \leq \lambda \leq 1-c\big\} \\ \mathcal{Q}_2^c = & \big\{\lambda Q_1 + (1-\lambda)Q_2 \colon \lambda \leq c\big\}. \end{array}$$

We also use

$$\mathscr{Q}^c = \{ P \in \mathscr{B}^c \text{ of the form } \lambda Q_1 + (1 - \lambda)Q_2 \}.$$

By Lemma 1 global maxima in  $\mathcal{Q}_1^c$  and  $\mathcal{Q}_2^c$  are local maxima in  $\mathscr{P}(\mathscr{X})$  with the desired properties, if we can show that

$$\max_{P \in \mathcal{Z}^c} R(P, \Delta) < \max_{P \in \mathcal{Z}_1^c} R(P, \Delta) < \max_{P \in \mathcal{Z}_2^c} R(P, \Delta). \quad (4.8)$$

We consider the ranges

$$\gamma = |\mathcal{Z}| > \beta = |\mathcal{Y}|, a < 1 \ll b, \Delta \le \frac{\beta - 1}{\beta}, \frac{\Delta}{a} \le \frac{\gamma - 1}{\gamma}.$$
 (4.9)

By Theorem 0 we have

$$R(Q_1, \Delta) = \log \beta - h(\Delta) - \Delta \log(\beta - 1)$$

$$R(Q_2, \Delta) = \log \gamma - h\left(\frac{\Delta}{a}\right) - \frac{\Delta}{a}\log(\gamma - 1).$$

In order to simplify calculations, we give up some freedom in the choice of parameters by requiring

$$\Delta + \frac{\Delta}{a} = 1. \tag{4.10}$$

Under this constraint we choose the other parameters so that  $R(Q_1, \Delta)$  and  $R(Q_2, \Delta)$  are approximately equal, that is,

$$\log \beta - \Delta \log (\beta - 1) \sim \log \gamma - \frac{\Delta}{a} \log (\gamma - 1)$$

or

$$\beta(\beta-1)^{\Delta} \sim \gamma(\gamma-1)^{-(1-\Delta)}$$
. (4.11)

Choose now

$$\gamma = \beta^3, \Delta = \frac{1}{4} + \epsilon, a = \frac{1+\epsilon}{3-\epsilon}.$$
 (4.12)

Thus

$$\beta(\beta-1)^{2} \sim \eta^{3/4-\epsilon} \tag{4.13}$$

$$\gamma(\gamma-1)^{-(1-\Delta)} \sim \beta^{3/4+3\epsilon}$$
. (4.14)

Application of our basic inequality 2) to  $P = \lambda Q_1 + (1 - \lambda)Q_2$  yields

$$R(P, \Delta) \le \min_{|\delta| < \Delta} (\lambda R(Q_1, \Delta + \delta) + (1 - \lambda) R(Q_2, \Delta - \delta)) + \log 2$$

and for

$$\lambda = \frac{1}{2}, \Delta = \frac{1}{4}, a = \frac{1}{3}$$

$$R\left(P,\frac{1}{4}\right) \leq 1 + \frac{1}{2}\left(R\left(Q_1,\frac{1}{6} + \eta\right) + R\left(Q_2,\frac{1}{3} - \eta\right)\right),$$

where  $\eta$  is introduced to insure  $(1/3 - \eta)a^{-1} \le \gamma - 1/\gamma$ . Since  $\gamma - 1/\gamma$  goes to 1 quickly,  $\eta$  is ignorably small.

Just notice tha

$$(\log \beta)^{-1} R\left(Q_1, \frac{1}{4}\right) \to \frac{3}{4}, \quad \text{as } \beta \to \infty$$

$$(\log \beta)^{-1} R\left(Q_2, \frac{1}{4}\right) \to \frac{3}{4}, \quad \text{as } \beta \to \infty$$

$$(\log \beta)^{-1} R\left(Q_1, \frac{1}{6} + \eta\right) \to \frac{5}{6} - \eta, \quad \text{as } \beta \to \infty$$

$$(\log \beta)^{-1} R\left(Q_2, \frac{1}{3} - \eta\right) \to 9\eta, \quad \text{as } \beta \to \infty$$

and thus

$$(\log \beta)^{-1} R\left(P, \frac{1}{4}\right) \to \leq \frac{1}{2} \left(\frac{5}{6} - \eta + 9\eta\right)$$
$$= \frac{5}{12} + 4\eta < \frac{3}{4}. \quad \text{as } \beta \to \infty.$$

For  $\epsilon$  sufficiently close to 1/2

$$\max_{P \in \mathcal{P}} R\left(P, \frac{1}{4}\right) \leq \frac{1}{2} < \frac{3}{4}.$$

If by chance we should have

$$\max_{P \in \mathscr{Q}_1} R\left(P, \frac{1}{4}\right) = \max_{P \in \mathscr{Q}_2} R\left(P, \frac{1}{4}\right)$$

by continuity of R in all parameters, a slight change in them would make the maxima different.

# V. A CONSEQUENCE FOR ERROR EXPONENTS

Our results seem to be relevant to the theory of universal source coding. We present now an immediate consequence in another direction. Marton [3] has investigated and found the error exponent  $e(P, \rho, \Delta)$  for the following refined source coding problem.

For encoding functions  $f_n: \mathcal{X}^n \to \hat{\mathcal{X}}^n$  with  $\lim_{n \to \infty} \text{rate}(f_n) = \rho > R(P, \Delta)$  what is the value of

$$e(P, \rho, \Delta) = -\lim_{n \to \infty} \frac{1}{n} \min_{f_n} \log \operatorname{Prob} \left( d(x^n, f_n(x^n)) > \Delta \right)?$$
(5.1)

Her answer is Theorem 3

Theorem 3:

 $e(P,\rho,\Delta)$ 

$$= \begin{cases} \min_{Q: R(Q, \Delta) > \rho} D(Q \| P), & \text{if } R(Q, \Delta) > \rho \text{ for some } Q \\ 0, & \text{otherwise} \end{cases}$$

Since D(Q||P) is continuous in P and  $R(Q, \Delta)$  is continuous in  $\Delta$ ,  $e(P, \rho, \Delta)$  is continuous in P and in  $\Delta$ .

Csiszár mentioned his interest in the question of whether the exponent is also continuous in  $\rho$  and mentioned the following observation.

Lemma 2:  $e(P, \rho, \Delta)$  is continuous in  $\rho$ , for all  $P, \Delta$  exactly if (A) holds for R.

*Proof:* If (A) does not hold, then for some  $\Delta$  there are two local maxima at  $P_1$  and  $P_2$ , say with

$$R(P_1, \Delta) > R(P_2, \Delta)$$

For 
$$P = P_2$$
 and  $\rho = R(P_2, \Delta) - \epsilon$  we have

$$\min_{Q: |R(Q,\delta)| > p} D(Q||P_2) = D(|P_2||P_2) = 0.$$

However, if  $\epsilon = 0$ , then there is no Q in the neighborhood of  $P_1$ with  $R(Q, \Delta) > \rho$ , but there is one far away in the neighborhood of  $P_i$ . The exponent is discontinuous at  $\rho$ . Conversely, if (A) holds, no such jump can occur. This result, Theorem 2 and the example give valuable information about  $e(P, \rho, \Delta)$ .

Corollary: Marton's exponent  $e(P, \rho, \Delta)$  is continuous in  $\rho$  for Hamming distortion measures. For general distortion measures it can jump.

#### REFERENCES

- [1] C. E. Shannon, "Coding theorems for a discrete source with a fidelity criterion," IRE Nat. Conv. Rec. Pt. 4, 1959, pp. 142-163.
- R. G. Gallager, Information Theory and Reliable Communication. New York: J. Wiley, 1968
- K. Marton, "Error exponent for source coding with a fidelity criterion," IEEE Trans. Inform. Theory, Vol. 20, pp. 197-199, 1974.
- R. Ahlswede, "Coloring hypergraphs: A new approach to multi-user source coding," Pt. I. J. Comb. Inform. Syst. Sci., vol. 4, pp. 76-115,
- Coloring hypergraphs: A new approach to multi-user source coding," Pt. II, J. Comb. Inform. Syst. Sci., vol. 5, p.p. 220-226, 1980.
- A. W. Marshall and I. Olkin, "Inequalities: Theory of majorization and its applications," vol. 143, in Mathematics in Science and Engineering. New York: Academic, 1979.
- [7] V. Erokhin, "e-entropy of a discrete random variable," Theory of Probability and its Applications, vol. 3, pp. 97-101, 1958.

## A New Time Domain, Multistage **Permutation Algorithm**

SRINIVASAN V. RAMANAN, MEMBER, 1EEE, HARRY F. JORDAN, MEMBER, IEEE, AND JON R. SAUER

Abstract—It is shown that a frame of N time slots can be arbitrarily permuted with  $2\log_2 N - 1$  controlled exchange switches with associated delay elements. This is an improvement over previously known interconnection networks that require O(N) exchange elements. The proof utilizes the recursive algorithm of Benes and the time interchange properties of a particular configuration of a single exchange element.

#### I. Introduction

For more than 30 years, considerable effort has been devoted to delineating the properties of rearrangeable, multistage interconnection networks [1]-[17]. The impetus for this effort came first from telephone switching systems, and somewhat later from parallel and distributed processing systems. As an example of previous results, Wu and Feng [14] showed that an arbitrary spatial permutation can be achieved with at most  $3\log_2 N - 1$ shuffle exchange stages, each stage requiring N/2 exchange switches. More recently, in the design of an optical guided wave system, Thompson [18] has shown how to realize an arbitrary time-slot permutation with 3N switched directional couplers as exchange elements. In this system the optical switches are very expensive and the design attempts to minimize their use.

Manuscript received October 18, 1989. This work was supported by the National Science Foundation in the Engineering Research Centers Program under Grant No. CDR8622236.

The authors are with the Optoelectronic Computing Systems Center, University of Colorado at Boulder, Boulder, CO 80309-0525 IEEE Log Number 8933288.

The genesis of the present work was the design of digital optical logic systems [19] with similarly precious optical exchange elements. The result presented here, applicable to both conventional electronic and optical switching systems, is that a serial array of basic exchange blocks, each constructed from a particular configuration of a single exchange switch, can arbitrarily permute N time-slots with  $2\log_2 N - 1$  switches. The proof, given next, proceeds through the recursive Benes algorithm [2].

Before embarking on the proof, we establish some definitions and the time-interchange properties of the basic building block that will be used. This basic block, labeled K(N/2), is shown in Fig. 1 and is able to exchange time-slot pairs in the first and second half sequences within a frame of size N. The control at terminal C causes the inputs either to be exchanged, when labeled as "x", or not exchanged, "=" One of the outputs is connected to its corresponding input with a delay  $\delta$  of N/2time-slots. An exhaustive study [20] was made of the time-interchange properties of single and multiple exchange switches in various serial arrays, and the single switch configuration of Fig. 1 was found to be logically the most powerful. As is easily verified, corresponding pairs from the first and second half frames can be exchanged, leaving all other pairs in place, by setting the control "x" everywhere except at the second member of the pair. For example, for a frame with eight time-slots, Fig. 2 shows for N = 8an incoming time-slot and control sequence, along with the output sequence, which appears after a frame delay of four time-slots. In this example, the third members of each half sequence are exchanged.

![](_page_5_Figure_24.jpeg)

Fig. 1. Switch and delay for exchange of time-slot pairs separated by N/2.

![](_page_5_Figure_26.jpeg)

Fig. 2. Interchange of time-slot pairs separated by N/2

#### II. KEY RESULT

The key result of this correspondence is the following theorem.

Theorem: An arbitrary permutation of N time-slots may be achieved with  $2\log_2 N - 1$  exchange switches configured as in Fig. 1.

Proof: Assume that in the serial array structure shown in Fig. 3, the first basic block A is an exchange switch with a feedback loop of delay N/2. This is followed by a serial universal time-slot interchanger T. T operates on frames of size N/2, which is half the original frame size. The inductive assumption is that T can arbitrarily permute the first half sequence of N/2time-slots first, and then can arbitrarily permute the second half sequence of N/2 time-slots. Part of the assumption is that the frame delay is fixed, independent of the permutation, so that the