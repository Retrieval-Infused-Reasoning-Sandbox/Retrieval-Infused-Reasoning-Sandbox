# <span id="page-0-0"></span>Pacific Journal of Mathematics

## ON GENERAL MINIMAX THEOREMS

MAURICE SION

Vol. 8, No. 1 March 1958

## ON GENERAL MINIMAX THEOREMS

## MAURICE SION

1. Introduction. von Neumann's minimax theorem [10] can be stated as follows: if M and N are finite dimensional simplices and f is a bilinear function on  $M \times N$ , then f has a saddle point, i.e.:

$$\max_{\mu \in M} \min_{\nu \in N} f(\mu, \nu) = \min_{\nu \in N} \max_{\mu \in M} f(\mu, \nu).$$

There have been several generalizations of this theorem. J. Ville [9]. A. Wald [11], and others [1] variously extended von Neumann's result to cases where M and N were allowed to be subsets of certain infinite dimensional linear spaces. The functions f they considered, however, were still linear. M. Shiffman [8] seems to have been the first to have considered concave-convex functions in a minimax theorem. H. Kneser [6], K. Fan [3], and C. Berge [2] (using induction and the method of separating two disjoint convex sets in Euclidean space by a hyperplane) got minimax theorems for concave-convex functions that are appropriately semi-continuous in one of the two variables. Although these theorems include the previous results as special cases, they can also be shown to be rather direct consequences of von Neumann's theorem. H. Nikaidô [7], on the other hand, using Brouwer's fixed point theorem, proved the existence of a saddle point for functions satisfying the weaker algebraic condition of being quasi-concave-convex, but the stronger topological condition of being continuous in each variable.

Thus, there seem to be essentially two types of argument: one uses some form of separation of disjoint convex sets by a hyperplane and yields the theorem of Kneser-Fan (see 4.2), and the other uses a fixed point theorem and yields Nikaidô's result.

In this paper, we unify the two streams of thought by proving a minimax theorem for a function that is quasi-concave-convex and appropriately semi-continuous in each variable. The method of proof differs radically from any used previously. The difficulty lies in the fact that we cannot use a fixed point theorem (due to lack of continuity) nor the separation of disjoint convex sets by a hyperplane (due to lack of convexity). The key tool used is a theorem due to Knaster, Kuratowski, Mazurkiewicz based on Sperner's lemma.

It may be of some interest to point out that, in all the minimax theorems, the crucial argument is carried out on spaces M and N that

Received June 26, 1957. This research was supported by the United States Air Force, Office of Scientific Research and Development Command, under contract No. AF18(600)-1109 [Supplemental Agreement No. 4 (56-339)].

are finite dimensional simplices. When concave-convexlike functions are considered, the topological conditions of compactness and semi-continuity are used only in reducing the problem to the finite dimensional case. For quasi-concave-convex functions, however, semi-continuity is needed in a more crucial way, as can be seen from the example in 3.6.

- 2. Fundamental notions and definitions. The following definitions of concavelike and convexlike functions were first considered by K. Fan [3]. They generalize the concepts of concavity and convexity and are valid for spaces without linear structure.
- 2.1. A function f on  $M \times N$  is concavelike in M if for every  $\mu_1, \mu_2 \in M$  and  $0 \le t \le 1$ , there is a  $\mu \in M$  such that

$$tf(\mu_1, \nu) + (1-t)f(\mu_2, \nu) \le f(\mu, \nu)$$
 for all  $\nu \in N$ .

2.2. A function f on  $M \times N$  is *convexlike* in N if for every  $\nu_1, \nu_2 \in N$  and  $0 \le t \le 1$ , there is a  $\nu \in N$  such

$$tf(\mu, \nu_1) + (1-t)f(\mu, \nu_2) \ge f(\mu, \nu)$$
 for all  $\mu \in M$ .

- 2.3. A function f on  $M \times N$  is *concave-convexlike* if it is concave-like in M and convexlike in N.
- 2.4. A function f on  $M \times N$  is *quasi-concave* in M if  $\{\mu : f(\mu, \nu) \ge c\}$  is a convex set for any  $\nu \in N$  and real c.
- 2.5. A function f on  $M \times N$  is quasi-convex in N if  $\{\nu : f(\mu, \nu) \leq c\}$  is a convex set for any  $\mu \in M$  and real c.
- 2.6. A function f on  $M \times N$  is quasi-concave-convex if it is quasi-concave in M and quasi-convex in N.
- 2.7. A function f on  $M \times N$  is u. s. c.-l. s. c. if  $f(\mu, \nu)$  is upper semi-continuous in  $\mu$  for each  $\nu \in N$  and lower semi-continuous in  $\nu$  for each  $\mu \in M$ .
  - 2.8. For a function f on  $M \times N$ , we set

$$\sup\inf f = \sup_{\mu \in \mathcal{M}} \inf_{\nu \in \mathcal{N}} f(\mu, \nu) ,$$
  
$$\inf\sup f = \inf_{\nu \in \mathcal{N}} \sup_{\mu \in \mathcal{M}} f(\mu, \nu) .$$

- 2.9. The convex hull of X will be denoted by  ${}^{\mathsf{T}}X^{\mathsf{T}}$ .
- 2.10. The closure of X will be denoted by  $\overline{X}$ .

- 3. Minimax theorems for quasi-concave-convex functions. The aim of this section is Theorem 3.4. The method of proof, making use of 3.1, 3.2, and 3.3, is very different from any argument used previously in obtaining minimax theorems.
- 3.1. THEOREM. Let S be an n-dimensional simplex with vertices  $a_0, \dots, a_n$ . If  $A_0, \dots, A_n$  are open sets such that  $S \subset \bigcup_{i=0}^n A_i, S A_i$  is convex, and  $a_i \notin A_j$  for  $i \neq j$   $(i, j, =0 \dots, n)$ , then  $\bigcap_{i=0}^n A_i \neq 0$ .

*Proof.* We can set  $A_i = \bigcup_{k=0}^{\infty} B_{i,k}$  where the  $B_{i,k}$  are open and  $\overline{B}_{i,k} \subset B_{i,k+1}$ . Since S is compact, there is an integer N such that  $S \subset \bigcup_{i=0}^{n} \overline{B}_{i,N}$ . By a theorem of Knaster, Kuratowski, Mazurkiewicz [5], we have  $\bigcap_{i=0}^{n} A_i \supset \bigcap_{i=0}^{n} \overline{B}_{i,N} \neq 0$ .

3.2. Theorem. Let  $\mathfrak{N} = \{a_0, \dots, a_n\}$  consist of n+1 points in a linear space of dimension k < n. Then  $\bigcap\limits_{i=0}^n \lceil (\mathfrak{N} - \{a_i\}) \rceil \neq 0$ .

Proof. 
$$\bigcap_{\substack{i=0\\i\neq j}}^n \lceil (\mathfrak{A} - \{a_i\})^{\intercal} \supset \{a_j\} \neq 0 \text{ for } j=0, \cdots, n.$$

Hence by Helly's Theorem [14], we have the desired result.

- 3.3. LEMMA. Let M be a convex set, Y a finite set, and f a function on  $M \times Y$ , quasi-concave and upper semi-continuous in M. Suppose, in addition, that Y is minimal with respect to the property: for each  $\mu \in M$  there is a  $y \in Y$  with  $f(\mu, y) < c$ . Then there exists  $\mu_0 \in M$  such that  $f(\mu_0, y) < c$  for all  $y \in Y$ .
- *Proof.* Let  $Y = \{y_0, \dots, y_n\}$  and set  $A_i = \{\mu : f(\mu, y_i) < c\}$  for  $i = 0, \dots, n$ . Then the  $A_i$  are open and  $M A_i$  convex. By hypothesis, for each i, there exists  $a_i \in M$  such that  $a_i \in M A_j$  for  $j \neq i$ . Let  $\mathfrak{A} = \{a_0, \dots, a_n\}$ . Then  $\lceil (\mathfrak{A} \{a_i\}) \rceil \subset M A_i$  and, since  $M \subset \bigcup_{i=0}^n A_i$ , we must have  $\bigcap_{i=0}^n \lceil (\mathfrak{A} \{a_i\}) \rceil = 0$ . Hence, by 3.2.,  $\mathfrak{A}$  spans an n-dimensional simplex in M and, by 3.1, there exists a  $\mu_0 \in \bigcap_{i=0}^n A_i$ .
- 3.3'. LEMMA. Let N be a convex set, X a finite set, and f a function on  $X \times N$ , quasi-convex and lower semi-continuous in N. Suppose, in addition, that X is minimal with respect to the property: for each  $\nu \in N$  there is an  $x \in X$  with  $f(x, \nu) > c$ . Then there exists  $\nu_0 \in N$  such that  $f(x, \nu_0) > c$  for all  $x \in X$ ,

3.4. Theorem. Let M and N be convex, compact spaces, and f a function on  $M \times N$ , quasi-concave-convex and u. s. c.-l. s. c.. Then sup inf  $f = \inf$  sup f.

*Proof.* Suppose sup inf  $f < c < \inf$  sup f. Let  $A_{\mu} = \{\nu : f(\mu, \nu) > c\}$  and  $B_{\nu} = \{\mu : f(\mu, \nu) < c\}$ . The  $A_{\mu}$  are open and cover N. Since N is compact, a finite number of the  $A_{\mu}$  cover N. Similarly, a finite number of the  $B_{\nu}$  cover M. We can therefore choose finite subsets  $X_1 \subset M$  and  $Y_1 \subset N$  such that for each  $\nu \in N$ , and hence for each  $\nu \in Y_1$ , there is an  $x \in X_1$  with  $f(x, \nu) > c$ ; and for each  $\mu \in M$ , and hence for each  $\mu \in X_1$ , there is a  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$  with  $\mu \in X_1$ 

Let  $X_2$  be a minimal subset of  $X_1$  such that for each  $\nu \in {}^{\Gamma}Y_1^{\Gamma}$  there is an  $x \in X_2$  with  $f(x, \nu) > c$ . Next, let  $Y_2$  be a minimal subset of  $Y_1$  such that for each  $\mu \in {}^{\Gamma}X_2^{\Gamma}$  there is a  $y \in Y_2$  with  $f(\mu, y) < c$ .

Thus, by repeating this process of alternately reducing the  $X_i$  and  $Y_i$ , after a finite number of steps, we can choose finite subsets  $X \subset M$  and  $Y \subset N$  such that X is minimal with respect to the property: for each  $\nu \in {}^{\Gamma}Y^{\Gamma}$  there is an  $x \in X$  with  $f(x, \nu) > c$ ; and Y is minimal with respect to the property: for each  $\mu \in {}^{\Gamma}X^{\Gamma}$  there is a  $y \in Y$  with  $f(\mu, y) < c$ . By 3.3, there exists  $\mu_0 \in {}^{\Gamma}X^{\Gamma}$  such that  $f(\mu_0, y) < c$  for all  $y \in Y$  and hence (by quasi-convexity)  $f(\mu_0, \nu) < c$  for all  $\nu \in {}^{\Gamma}Y^{\Gamma}$ . By 3.3', there exists  $\mu_0 \in {}^{\Gamma}Y^{\Gamma}$  such that  $f(x, \nu_0) > c$  for all  $x \in X$  and hence (by quasi-concavity)  $f(\mu, \nu_0) > c$  for all  $\mu \in {}^{\Gamma}X^{\Gamma}$ . Then  $c < f(\mu_0, \nu_0) < c$ , which is impossible.

- 3.3. COROLLARY. Let M and N be convex spaces one of which is compact, and f a function on  $M \times N$ , quasi-concave-convex and u.s.c.-l.s.c.. Then sup inf f = inf sup f.
- *Proof.* Suppose M is compact and sup inf  $f < c < \inf$  sup f. Then there exists a finite set  $Y \subset N$  such that for any  $\mu \in M$  there is a  $y \in Y$  with  $f(\mu, y) < c$ . Taking  $f' = f/(M \times^{\Gamma} Y^{\Gamma})$ , we get sup inf  $f' < c < \inf$  sup f' in contradiction to 3.4 with N replaced by f' and f by f'.
- 3.6. Remark. In Theorem 3.4, the condition that f be u. s. c.-l s. c. cannot be removed nor appreciably weakened even if the spaces M, N are finite dimensional. To see this, we consider the following example. Let M=N=[0,1] and  $f(\mu,\nu)=0$  for  $0 \le \mu < 1/2$  and  $\nu=0$  or  $1/2 \le \mu \le 1$  and  $\nu=1$ ;  $f(\mu,\nu)=1$  otherwise. We easily check that f is quasi-concave-convex; for each  $\mu$ ,  $f(\mu,\nu)$  is lower semi-continuous in  $\nu$ ; however  $f(\mu,1)$  is not upper semi-continuous in  $\mu$ . We also have: sup inf f=0 and inf sup f=1.
  - 4. Minimax theorems for concave-convexlike functions. For con-

cave-convexlike functions, the topology for the spaces on which they are defined plays only a secondary role. Theorem 4.2 (4.2') below, which is the generalization of Kneser's theorem to concave-convexlike functions due to K. Fan [3], is not a special case of 3.4 since the concepts of concave-convexlike and quasi-concave-convex are independent of each other (see [7]). It is however a special case of 4.1' (4.1), which is itself an immediate consequence of 3.4 (actually, von Neumann's theorem).

- 4.1. THEOREM. Let M and N be any spaces, f a function on  $M \times N$  that is concave-convexlike. If for any  $c < \inf \sup f$  there exists a finite subset  $X \subset M$  such that for any  $\nu \in N$  there is an  $x \in X$  with  $f(x, \nu) > c$ , then  $\sup \inf f = \inf \sup f$ .
- 4.1'. THEOREM. Let M, N be any spaces, f a function on  $M \times N$  that is concave-convexlike. If for any  $c > \sup$  inf f there exists a finite set  $Y \subset N$  such that for any  $\mu \in M$  there is a  $y \in Y$  with  $f(\mu, y) < c$ , then  $\sup$  inf  $f = \inf$   $\sup$  f.
- 4.2. THEOREM. (Kneser, Fan). Let M be compact, N any space, f a function on  $M \times N$  that is concave-convexlike. If  $f(\mu, \nu)$  is upper semi-continuous in  $\mu$  for each  $\nu$ , then sup inf f=inf sup f.
- *Proof.* If  $c > \sup \inf f$ , let  $A_{\nu} = \{ \mu : f(\mu, \nu) < c \}$  for each  $\nu \in N$ . The  $A_{\nu}$  are open and cover M, hence a finite number of them cover M. We may therefore apply 4.1'.
- 4.2' THEOREM. Let M be any space, N compact, f a function on  $M \times N$  that is concave-convexlike. If  $f(\mu, \nu)$  is lower semi-continuous in  $\nu$  for each  $\mu$ , then sup inf f=inf sup f.

#### REFERENCES

- 1. Contributions to the theory of games, vol. I, Ann. of Math. Studies, No. 24, 1950, Princeton Univ. Press, Princeton.
- 2. C. Berge, Sur une convexité régulière et ses applications à la théorie des jeux, Bull. Soc. Math. France, 82 (1954), 301-319.
- 3. K. Fan, Minimax Theorems, Proc. Nat. Acad. Sci., 39 (1953), 42-47.
- 4. E. Helly, Über Mengen könvexer Korper mit gemeinschaftlichen Punkten, J. Deutsch. Math. Vereinig., 32 (1923), 175-176.
- 5. B. Knaster, C., Kuratowski, S. Mazurkiewicz, Ein Beweis des Fixpunktsatzes für n-dimensionale Simplexe, Fund. Math., 14 (1929), 132-138.
- 6. H. Kneser, Sur un théorème fondamental de la thérie des jeux, C. R. Acad. Sci. Paris 234 (1952), 2418-2420.
- 7. H. Nikaidô, On von Neumann's minimax theorem, Pacific J. Math., 4 (1954), 65-72.
- 8. M. Shiffman, On the equality min max=max min, and the theory of games, RAND Report RM-243, 1949,

- 9. J. Ville, Sur la théoric générale des jeux ou intervient l'habilité des joueurs. Traité du calcul des probabilites et de ses applications, IV, 2 (1938), 105-113; by E. Borel and collaborators.
- 10. J. von Neumann, Zur Theorie der Gesellshaftsphiele, Math. Ann. 100 (1928) 295-320.
- 11. A. Wald, Generalization of a theorem by von Neumann concerning zero-sum two-person games. Ann. of Math., 46 (1945), 281-286.

THE INSTITUTE FOR ADVANCED STUDY

## PACIFIC JOURNAL OF MATHEMATICS

## EDITORS

DAVID GILBARG

Stanford University Stanford, California

R. A. BEAUMONT University of Washington Seattle 5, Washington

A. L. WHITEMAN

University of Southern California Los Angeles 7, California

E. G. STRAUS

University of California Los Angeles 24, California

## ASSOCIATE EDITORS

E. F. BECKENBACH C. E. BURGESS

A. HORN V. GANAPATHY IYER R. D. JAMES

L. NACHBIN I. NIVEN

M. M. SCHIFFEl G. SZEKERES F. WOLF

M. HALL E. HEWITT M. S. KNEBELMAN

T. G. OSTROM H. L. ROYDEN

K. YOSIDA

## SUPPORTING INSTITUTIONS

UNIVERSITY OF BRITISH COLUMBIA CALIFORNIA INSTITUTE OF TECHNOLOGY UNIVERSITY OF CALIFORNIA MONTANA STATE UNIVERSITY UNIVERSITY OF NEVADA OREGON STATE COLLEGE UNIVERSITY OF OREGON OSAKA UNIVERSITY UNIVERSITY OF SOUTHERN CALIFORNIA

STANFORD UNIVERSITY UNIVERSITY OF TOKYO UNIVERSITY OF UTAH WASHINGTON STATE COLLEGE UNIVERSITY OF WASHINGTON \* \* \*

AMERICAN MATHEMATICAL SOCIETY CALIFORNIA RESEARCH CORPORATION HUGHES AIRCRAFT COMPANY THE RAMO-WOOLDRIDGE CORPORATION

Printed in Japan by Kokusai Bunken Insatsusha (International Academic Printing Co., Ltd.), Tokyo, Japan

# Pacific Journal of Mathematics

Vol. 8, No. 1 March, 1958

| Shimshon A. Amitsur,<br>Commutative linear differential operators<br>                                                          | 1   |
|--------------------------------------------------------------------------------------------------------------------------------|-----|
| Masahiko Atsuji,<br>Uniform continuity of continuous functions of metric                                                       |     |
| spaces<br>                                                                                                                     | 11  |
| S. P. Avann,<br>A numerical condition for modularity of a lattice<br>                                                          | 17  |
| Raymond G. D. Ayoub,<br>A mean value theorem for quadratic fields                                                              | 23  |
| Subalgebras of functions on a Riemann surface<br>Errett Albert Bishop,<br>                                                     | 29  |
| The relations between a spectral operator and its scalar<br>Shaul Foguel,                                                      |     |
| part<br>                                                                                                                       | 51  |
| Euclidean and weak uniformities<br>John Rolfe Isbell,<br>                                                                      | 67  |
| Samuel Karlin and James L. McGregor,<br>Many server queueing processes<br>with Poisson input and exponential service times<br> | 87  |
| Paul Joseph Kelly and Ernst Gabor Straus,<br>Curvature in Hilbert                                                              |     |
| geometries                                                                                                                     | 119 |
| John W. Lamperti,<br>Stationary measures for certain stochastic processes                                                      | 127 |
| Richard Scott Pierce,<br>Distributivity and the normal completion of Boolean<br>algebras                                       | 133 |
| F. M. Ragab,<br>Transcendental addition theorems for the hypergeometric<br>function of Gauss<br>                               | 141 |
| William T. Reid,<br>Principal solutions of non-oscillatory self-adjoint linear                                                 |     |
| differential systems<br>                                                                                                       | 147 |
| On general minimax theorems<br>Maurice Sion,<br>                                                                               | 171 |
| ∗<br>On semi-normed<br>-algebras<br>Chien Wenjen,                                                                              | 177 |