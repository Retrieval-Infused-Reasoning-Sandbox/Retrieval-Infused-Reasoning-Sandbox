ELSEVIER

Contents lists available at ScienceDirect

# Physics Letters B

www.elsevier.com/locate/physletb

![](_page_0_Picture_5.jpeg)

# The proton- $\Omega$ correlation function in Au + Au collisions at $\sqrt{s_{NN}} = 200 \text{ GeV}$

![](_page_0_Picture_7.jpeg)

## STAR Collaboration

J. Adam<sup>k</sup>, L. Adamczyk<sup>a</sup>, J.R. Adams<sup>ah</sup>, J.K. Adkins<sup>x</sup>, G. Agakishiev<sup>v</sup>, M.M. Aggarwal<sup>aj</sup>, Z. Ahammed bd, N.N. Ajitanand av, I. Alekseev b, ad, D.M. Anderson ax, R. Aoyama ba, A. Aparin V, D. Arkhipkin d, E.C. Aschenauer d, M.U. Ashraf az, F. Atetalla W, A. Attri aj, G.S. Averichev V, X. Bai i, V. Bairathi ae, K. Barish h, A.J. Bassill h, A. Behera av, R. Bellwied q, A. Bhasin<sup>u</sup>, A.K. Bhati<sup>aj</sup>, J. Bielcik<sup>l</sup>, J. Bielcikova<sup>ag</sup>, L.C. Bland<sup>d</sup>, I.G. Bordyuzhin<sup>b</sup>, J.D. Brandenburg<sup>ao</sup>, A.V. Brandin<sup>ad</sup>, D. Brown<sup>aa</sup>, J. Bryslawskyj<sup>h</sup>, I. Bunzarov<sup>v</sup>, J. Butterworth<sup>ao</sup>, H. Caines<sup>bg</sup>, M. Calderón de la Barca Sánchez<sup>f</sup>, J.M. Campbell<sup>ah</sup>, D. Cebra f, I. Chakaberia w,as, P. Chaloupka l, Z. Chang d, F.-H. Chang af, N. Chankova-Bunzarova<sup>V</sup>, A. Chatterjee<sup>bd</sup>, S. Chattopadhyay<sup>bd</sup>, J.H. Chen<sup>o,at</sup>, X. Chen<sup>s</sup>, X. Chen ar, J. Cheng Z, M. Cherney , W. Christie , G. Contin , H.J. Crawford , S. Das , T.G. Dedovich , I.M. Deppner , A.A. Derevschikov , L. Didenko , C. Dilks , X. Dong , J.L. Drachenberg <sup>y</sup>, J.C. Dunlop <sup>d</sup>, L.G. Efimov <sup>v</sup>, N. Elsey <sup>bf</sup>, J. Engelage <sup>e</sup>, G. Eppley <sup>ao</sup>, R. Esha <sup>g</sup>, S. Esumi <sup>ba</sup>, O. Eydokimov <sup>j</sup>, J. Ewigleben <sup>aa</sup>, O. Eyser <sup>d</sup>, R. Fatemi <sup>x</sup>, S. Fazio <sup>d</sup>, P. Federic ag, P. Federicova, J. Fedorisin, P. Filip, E. Finch au, Y. Fisyak, C.E. Flores, L. Fulek a, C.A. Gagliardi ax, T. Galatyuk m, F. Geurts ao, A. Gibson bc, D. Grosnick bc, D.S. Gunarathne aw, Y. Guo w, A. Gupta u, W. Guryn d, A.I. Hamad w, A. Hamed ax, A. Harlenderova<sup>1</sup>, J.W. Harris<sup>bg</sup>, L. He<sup>am</sup>, S. Heppelmann<sup>f</sup>, S. Heppelmann<sup>ak</sup>, N. Herrmann<sup>p</sup>, A. Hirsch<sup>am</sup>, L. Holub<sup>1</sup>, S. Horvat<sup>bg</sup>, B. Huang<sup>j</sup>, X. Huang<sup>az</sup>, S.L. Huang<sup>av</sup>, T. Huang <sup>af</sup>, H.Z. Huang <sup>g</sup>, T.J. Humanic <sup>ah</sup>, P. Huo <sup>av</sup>, G. Igo <sup>g</sup>, W.W. Jacobs <sup>r</sup>, A. Jentsch <sup>ay</sup>, J. Jia <sup>d, av</sup>, K. Jiang <sup>ar</sup>, S. Jowzaee <sup>bf</sup>, E.G. Judd <sup>e</sup>, S. Kabana <sup>w</sup>, D. Kalinkin <sup>r</sup>, K. Kang <sup>az</sup>, D. Kapukchyan h, K. Kauder d, H.W. Ke d, D. Keane w, A. Kechechyan v, D.P. Kikoła be, C. Kim<sup>h</sup>, T.A. Kinghorn<sup>f</sup>, I. Kisel<sup>n</sup>, A. Kisiel<sup>be</sup>, L. Kochenda<sup>ad</sup>, L.K. Kosarzewski<sup>be</sup>, A.F. Kraishan <sup>aw</sup>, L. Kramarik <sup>1</sup>, L. Krauth <sup>h</sup>, P. Kravtsov <sup>ad</sup>, K. Krueger <sup>c</sup>, N. Kulathunga <sup>q</sup>, S. Kumar <sup>aj</sup>, L. Kumar <sup>aj</sup>, R. Kunnawalkam Elayavalli <sup>bf</sup>, J. Kvapil <sup>1</sup>, J.H. Kwasizur <sup>r</sup>, R. Lacey <sup>av</sup>, J.M. Landgraf<sup>d</sup>, J. Lauret<sup>d</sup>, A. Lebedev<sup>d</sup>, R. Lednicky<sup>v</sup>, J.H. Lee<sup>d</sup>, Y. Li<sup>az</sup>, W. Li<sup>at</sup>, C. Li<sup>ar</sup>, X. Li ar, Y. Liang W, J. Lidrych I, T. Lin ax, A. Lipiec be, M.A. Lisa ah, H. Liu P, P. Liu av, F. Liu I, Y. Liu ax, T. Ljubicic d, W.J. Llope bf, M. Lomnitz Z, R.S. Longacre d, S. Luo J, X. Luo J, L. Ma O, G.L. Ma<sup>o,at</sup>, R. Ma<sup>d</sup>, Y.G. Ma<sup>o,at</sup>, N. Magdy<sup>av</sup>, R. Majka<sup>bg</sup>, D. Mallick<sup>ae</sup>, S. Margetis<sup>w</sup>, C. Markert ay, H.S. Matis Z, O. Matonoha I, D. Mayes h, J.A. Mazer ap, K. Meehan I, J.C. Mei as, N.G. Minaev<sup>al</sup>, S. Mioduszewski<sup>ax</sup>, D. Mishra<sup>ae</sup>, B. Mohanty<sup>ae</sup>, M.M. Mondal<sup>t</sup>, I. Mooney bf, D.A. Morozov al, Md. Nasim g, J.D. Negrete h, J.M. Nelson e, D.B. Nemes bg, M. Nie at, G. Nigmatkulov ad, T. Niida bf, L.V. Nogach al, T. Nonaka i, S.B. Nurushev al, G. Odyniec<sup>z</sup>, A. Ogawa<sup>d</sup>, S. Oh<sup>bg</sup>, K. Oh<sup>an</sup>, V.A. Okorokov<sup>ad</sup>, D. Olvitt Jr. <sup>aw</sup>, B.S. Page<sup>d</sup>, R. Pak<sup>d</sup>, Y. Panebratsev<sup>v</sup>, B. Pawlik<sup>ai</sup>, H. Pei<sup>i</sup>, C. Perkins<sup>e</sup>, J. Pluta<sup>be</sup>, J. Porter<sup>z</sup>, M. Posik<sup>aw</sup>, N.K. Pruthi aj, M. Przybycien a, J. Putschke bf, A. Quintero aw, S.K. Radhakrishnan Z, S. Ramachandran X, R.L. Ray ay, R. Reed aa, H.G. Ritter J. I.B. Roberts ao, O.V. Rogachevskiy V.

STAR Collaboration / Physics Letters B 790 (2019) 490-497 J.L. Romero f, L. Ruan d, J. Rusnak ag, O. Rusnakova l, N.R. Sahoo ax, P.K. Sahu t, S. Salur ap, J. Sandweiss <sup>bg</sup>, J. Schambach <sup>ay</sup>, A.M. Schmah <sup>z</sup>, W.B. Schmidke <sup>d</sup>, N. Schmitz <sup>ab</sup>, B.R. Schweid <sup>av</sup>, F. Seck <sup>m</sup>, J. Seger <sup>k</sup>, M. Sergeeva <sup>g</sup>, R. Seto <sup>h</sup>, P. Seyboth <sup>ab</sup>, N. Shah <sup>at, 1</sup>, E. Shahaliev V. P.V. Shanmuganathan aa, M. Shao ar, W.Q. Shen at, F. Shen as, S.S. Shi i, Q.Y. Shou at, E.P. Sichtermann z, S. Siejka be, R. Sikora a, M. Simko ag, S. Singha w, D. Smirnov d, N. Smirnov bg, W. Solyst P. P. Sorensen H.M. Spinka B. Srivastava m, T.D.S. Stanislaus bc, D.J. Stewart bg, M. Strikhanov d, B. Stringfellow m, A.A.P. Suaide dq, T. Sugiura da, M. Sumbera dg, B. Summa dk, X. Sun Y. Sun T, X.M. Sun B. Surrow dw, D.N. Svirida B, P. Szymanski de, Z. Tang da, A.H. Tang d, A. Taranenko dd, T. Tarnowsky dc, J.H. Thomas Z, A.R. Timmins Q, D. Tlusty do, T. Todoroki d, M. Tokarev V, C.A. Tomkiel da, S. Trentalange B, R.E. Tribble dx, P. Tribedy d, S.K. Tripathy t, O.D. Tsai B, B. Tu i, T. Ullrich d, D.C. Underwood C, L. Ungeld d S, C. Man Burne d, L. Mangled d S, C. Man Burne d, L. Mangled d S, C. Man Burne d, L. Mangled d S, C. Man Burne d, L. Mangled d S, C. Man Burne d, L. Mangled d S, C. Man Burne d, L. Mangled d S, C. Man Burne d, L. Mangled d S, C. Man Burne d, L. Mangled d S, C. Man Burne d, L. Mangled d S, C. Man Burne d, L. Mangled d S, C. Man Burne d, L. Mangled d M, Mangled L. Mangled d M, Mangled d M, Mangled L. Mangled d M, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, Mangled D, D.G. Underwood <sup>c</sup>, I. Upsal <sup>d,as</sup>, G. Van Buren <sup>d</sup>, J. Vanek <sup>ag</sup>, A.N. Vasiliev <sup>al</sup>, I. Vassiliev <sup>n</sup>, F. Videbæk<sup>d</sup>, S. Vokal<sup>v</sup>, S.A. Voloshin<sup>bf</sup>, A. Vossen<sup>r</sup>, F. Wang<sup>am</sup>, G. Wang<sup>g</sup>, Y. Wang<sup>az</sup>, Y. Wang<sup>i</sup>, J.C. Webb<sup>d</sup>, L. Wen<sup>g</sup>, G.D. Westfall<sup>ac</sup>, H. Wieman<sup>z</sup>, S.W. Wissink<sup>r</sup>, R. Witt<sup>bb</sup>, Y. Wu<sup>w</sup>, Z.G. Xiao<sup>az</sup>, W. Xie<sup>am</sup>, G. Xie<sup>j</sup>, Z. Xu<sup>d</sup>, J. Xu<sup>i</sup>, Y.F. Xu<sup>at</sup>, N. Xu<sup>z</sup>, Q.H. Xu<sup>as</sup>, Y. Yang af, C. Yang as, S. Yang d, Q. Yang as, Z. Ye j, Z. Ye j, L. Yi as, K. Yip d, I.-K. Yoo an, N. Yu i, H. Zbroszczyk be, W. Zha ar, Z. Zhang at, J. Zhang s, L. Zhang i, J. Zhang z, Y. Zhang ar, X.P. Zhang z, S. Zhang ar, S. Zhang ar, J. Zhao am, C. Zhong at, C. Zhou at, L. Zhou ar, Z. Zhu as, X. Zhu az, M. Zyzak n <sup>a</sup> AGH University of Science and Technology, FPACS, Cracow 30-059, Poland <sup>b</sup> Alikhanov Institute for Theoretical and Experimental Physics, Moscow 117218, Russia <sup>c</sup> Argonne National Laboratory, Argonne, IL 60439 <sup>d</sup> Brookhaven National Laboratory, Upton, NY 11973 <sup>e</sup> University of California, Berkeley, CA 94720 <sup>f</sup> University of California, Davis, CA 95616 g University of California, Los Angeles, CA 90095 <sup>h</sup> University of California, Riverside, CA 92521 <sup>i</sup> Central China Normal University, Wuhan, Hubei 430079 <sup>j</sup> University of Illinois at Chicago, Chicago, IL 60607 <sup>k</sup> Creighton University, Omaha, NE 68178 <sup>1</sup> Czech Technical University in Prague, FNSPE, Prague 115 19, Czech Republic <sup>m</sup> Technische Universität Darmstadt, Darmstadt 64289, Germany <sup>n</sup> Frankfurt Institute for Advanced Studies FIAS, Frankfurt 60438, Germany o Fudan University, Shanghai, 200433 <sup>p</sup> University of Heidelberg, Heidelberg 69120, Germany <sup>q</sup> University of Houston, Houston, TX 77204 <sup>r</sup> Indiana University, Bloomington, IN 47408 s Institute of Modern Physics, Chinese Academy of Sciences, Lanzhou, Gansu 730000 <sup>t</sup> Institute of Physics, Bhubaneswar 751005, India <sup>u</sup> University of Jammu, Jammu 180001, India <sup>v</sup> Joint Institute for Nuclear Research, Dubna 141 980, Russia w Kent State University, Kent, OH 44242 x University of Kentucky, Lexington, KY 40506-0055 <sup>y</sup> Lamar University, Physics Department, Beaumont, TX 77710 <sup>z</sup> Lawrence Berkeley National Laboratory, Berkeley, CA 94720 aa Lehigh University, Bethlehem, PA 18015 <sup>ab</sup> Max-Planck-Institut fur Physik, Munich 80805, Germany <sup>ac</sup> Michigan State University, East Lansing, MI 48824 <sup>ad</sup> National Research Nuclear University MEPhI, Moscow 115409, Russia ae National Institute of Science Education and Research, HBNI, Jatni 752050, India <sup>af</sup> National Cheng Kung University, Tainan 70101

y Lamar University, Physics Department, Beaumont, TX 77710

Lawrence Berkeley National Laboratory, Berkeley, CA 94720

aa Lehigh University, Bethlehem, PA 18015

ab Max-Planck-Institut fur Physik, Munich 80805, Germany

ac Michigan State University, East Lansing, MI 48824

ad National Research Nuclear University MEPhI, Moscow 115409, Russia

ae National Institute of Science Education and Research, HBNI, Jatni 752050, India

af National Cheng Kung University, Tainan 70101

ag Nuclear Physics Institute AS CR, Prague 250 68, Czech Republic

ah Ohio State University, Columbus, OH 43210

ai Institute of Nuclear Physics PAN, Cracow 31-342, Poland

aj Panjab University, Chandigarh 160014, India

ak Pennsylvania State University, University Park, PA 16802

al Institute of High Energy Physics, Protvino 142281, Russia

am Purdue University, West Lafayette, IN 47907

an Pusan National University, Pusan 46241, Republic of Korea

ao Rice University, Houston, TX 77251

ap Rutgers University, Piscataway, NJ 08854

ad Universidade de Sao Paulo, Sao Paulo, 05314-970, Brazil

ar University of Science and Technology of China, Hefei, Anhui 230026

as Shandong University, Jinan, Shandong 250100

<sup>at</sup> Shanghai Institute of Applied Physics, Chinese Academy of Sciences, Shanghai 201800

<sup>au</sup> Southern Connecticut State University, New Haven, CT 06515 <sup>av</sup> State University of New York, Stony Brook, NY 11794 <sup>aw</sup> Temple University, Philadelphia, PA 19122

- ax Texas A&M University, College Station, TX 77843
- <sup>ay</sup> University of Texas, Austin, TX 78712
- az Tsinghua University, Beijing 100084
- ba University of Tsukuba, Tsukuba, Ibaraki 305-8571, Japan
- bb United States Naval Academy, Annapolis, MD 21402
- <sup>bc</sup> Valparaiso University, Valparaiso, IN 46383
- <sup>bd</sup> Variable Energy Cyclotron Centre, Kolkata 700064, India
- be Warsaw University of Technology, Warsaw 00-661, Poland
- bf Wayne State University, Detroit, MI 48201
- bg Yale University, New Haven, CT 06520

#### ARTICLE INFO

Article history:
Received 7 August 2018
Received in revised form 21 December 2018
Accepted 28 January 2019
Available online 31 January 2019
Editor: V. Metag

Keywords: Correlations Femtoscopy NΩ dibaryon

#### ABSTRACT

We present the first measurement of the proton- $\Omega$  correlation function in heavy-ion collisions for the central (0–40%) and peripheral (40–80%) Au + Au collisions at  $\sqrt{s_{NN}}=200$  GeV by the STAR experiment at the Relativistic Heavy-Ion Collider (RHIC). Predictions for the ratio of peripheral collisions to central collisions for the proton- $\Omega$  correlation function are sensitive to the presence of a nucleon- $\Omega$  bound state. These predictions are based on the proton- $\Omega$  interaction extracted from (2 + 1)-flavor lattice QCD calculations at the physical point. The measured ratio of the proton- $\Omega$  correlation function between the peripheral (small system) and central (large system) collisions is less than unity for relative momentum smaller than 40 MeV/c. Comparison of our measured correlation ratio with theoretical calculation slightly favors a proton- $\Omega$  bound system with a binding energy of  $\sim$  27 MeV.

© 2019 Published by Elsevier B.V. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/). Funded by SCOAP<sup>3</sup>.

#### 1. Introduction

The study of the nucleon–nucleon (NN), hyperon–nucleon (YN) and hyperon-hyperon (YY) interactions is of fundamental importance in understanding the relativistic heavy-ion collisions [1–3], modeling of neutron stars [4,7,5,6] and examining the existence of various exotic hadrons [8–10]. A significant amount of NN scattering data acquired over the years allows us to construct precise NN potential models [11,12]. The availability of nominal YN scattering data and no scattering data for the multi-strange YY systems make the task of constructing YN and YY potentials very challenging. With the development of sophisticated computational techniques, it has become possible to carry out the first principle calculations based on lattice Quantum Chromodynamics (QCD) to provide constraints on some of the NN, YY and YN interactions [12–16]. Very often the experimental information on the bound states of strange baryons and nucleons (hypernuclei) is used to provide information on the YN interactions [17-19]. However, this method becomes difficult to use for the hypernuclei containing more than four baryons due to the contamination by the many-body effects, which makes it very difficult to extract the N $\Xi$ , N $\Omega$ , Y $\Xi$  and Y $\Omega$ interactions.

High-energy heavy-ion collisions produce a sizable number of hyperons in each collision [20], which provides an excellent opportunity to study the NN, YN and YY interactions. Measurement of the two-particle correlations at low relative momentum, also known as femtoscopy, has been used to study the space–time dynamics of the source created in heavy-ion collisions. In addition to this, measurement of the two-particle correlations at low relative momentum can be used to measure the final state interactions (FSI) between NN, YN and YY. This approach has been used by the STAR experiment at RHIC to extract the FSI for  $\Lambda\Lambda$  [21] and antiproton–antiproton [22]. Using a similar approach, the ALICE experiment at the Large Handron Collider (LHC) reported the mea-

surement of the proton–proton and  $\Lambda\Lambda$  correlation functions in proton + proton collisions at  $\sqrt{s} = 7$  TeV [23].

Recent study of (2+1)-flavor lattice QCD simulations for the heavy quark masses shows that the nucleon- $\Omega$  interaction  $(N\Omega)$  is attractive at all distances [16]. Using this  $N\Omega$  interaction, it is shown that the shape of the two-particle correlation function at low relative momentum changes substantially with the strength of the  $N\Omega$  attraction [24]. However, the presence of the Coulomb interaction in the proton- $\Omega$  channel makes it difficult to access the strong interaction directly from the measured two-particle correlation function. Therefore, a new measure, namely the ratio of the correlation function between peripheral (small) and central (large) collision systems is proposed in Ref. [24]. This ratio provides direct access to the strong interaction between proton and  $\Omega$ , independent of the model used for the emission source.

The attractive nature of the  $N\Omega$  interaction leads to the possible existence of an N $\Omega$  dibaryon with strangeness = -3, spin = 2, and isospin = 1/2, which was first proposed in Ref. [25]. Such an  $N\Omega$  dibaryon is the most interesting candidate [25–29] after the H-dibaryon [8] as the Pauli exclusion principle does not apply to quarks in the  $N\Omega$  dibaryon and it is stable against strong decay [30,31]. Several attempts have been made to estimate the binding energy of the N $\Omega$  state in different QCD motivated models [16,32]. The N $\Omega$  dibaryon can be produced in high-energy heavy-ion collisions through the coalescence mechanism [33]. In the N $\Omega$  system, an S-wave has two possible channels,  ${}^5S_2$  and  ${}^3S_1$  ( ${}^{2s+1}L_I$ , where the s, L and J denote spin, L wave and total angular momentum, respectively). For the  ${}^5S_2$  channel the coupling to  $\Lambda\Xi$  is dynamically suppressed, whereas in the  ${}^3S_1$  channel a sizable coupling to these octet-octet channels is possible through the rearrangement of quarks [16]. This makes direct searches via the invariant mass method very challenging in heavy-ion collisions. The measurement of the proton- $\Omega$  correlation function in peripheral and central Au + Au collisions at  $\sqrt{s_{NN}} = 200$  GeV, presented in this Letter, will provide insight into the existence of  $N\Omega$  dibaryon.

#### 2. Data analysis

STAR is a large acceptance detector at RHIC [34]. The measurements presented in this Letter are from the data taken for Au + Au

E-mail address: nehashah@iitp.ac.in (N. Shah).

<sup>&</sup>lt;sup>1</sup> Also at Department of Physics, Indian Institute of Technology Patna, Bihar 801106, India.

![](_page_3_Figure_2.jpeg)

**Fig. 1.** Proton identification using the time of flight and momentum from the TOF and the TPC detectors, respectively. The solid lines show lower and upper cuts to select protons.

collisions at  $\sqrt{s_{NN}} = 200$  GeV in 2011 and 2014.  $5.30 \times 10^8$  minimum bias events from 2011 and  $8.76 \times 10^8$  minimum bias events from 2014 were analyzed. The tracking and particle identification for the measurements were provided by the Time Projection Chamber (TPC) [35] and the Time-of-Flight (TOF) [36] detectors. These detectors are located in a 0.5 T magnetic field, and allow determination of the momentum and charge of the particles traversing the TPC. Minimum bias triggered events were selected by requiring coincident signals at forward and backward rapidities in the Vertex Position Detectors (VPD) [37] and requiring a signal at mid-rapidity in the TOF. The collision centrality was determined from the uncorrected charged particle multiplicity  $dN/d\eta$  within  $|\eta|$  < 0.5 using a Monte Carlo (MC) Glauber model [38]. The dependence of  $dN/d\eta$  on the collision vertex position along the beam direction  $V_z$  and the beam luminosity has been included to take acceptance and efficiency changes on the measured  $dN/d\eta$  into account. To suppress events from collisions with the beam pipe, the reconstructed primary vertex was required to lie within a 2 cm radial distance from the center of the beam pipe. In addition, the z-position of the vertex was required to be within  $\pm 40$  cm in the center of the STAR TPC for the data from year 2011 and  $\pm 6$  cm in the center of the Heavy Flavor Tracker (HFT) [39] for the data from year 2014, respectively.

#### 2.1. Proton identification

The TOF and TPC detectors were used for the proton (antiproton) identification in the pseudorapidity range  $|\eta| < 1$ . A proton (antiproton) track was selected if its distance of closest approach

(DCA) was less than 0.5 cm to the primary vertex, greater than 20 TPC points were measured out of a maximum of 45, and the number of TPC points used in track reconstruction divided by the number of possible points was greater than 0.52 in order to prevent split tracks. The time of flight of the particles reaching the TOF detector along with the tracking information from the TPC detector was used to calculate the square of the particle mass  $(m^2)$  to identify protons (antiprotons). Fig. 1 shows  $m^2$  from the TOF detector versus momentum from the TPC. All candidates with  $m^2$  between 0.75 and 1.10  $(\text{GeV}/c^2)^2$  were used in the analysis.

#### 2.2. $\Omega$ identification

The TPC was used for tracking, decay topology and identification of particles for  $\Omega$  ( $\bar{\Omega}$ ) reconstruction in the pseudorapidity range  $|\eta| < 1$ . To reconstruct the  $\Omega$  ( $\bar{\Omega}$ ), the decay channel  $\Omega(\bar{\Omega}) \to \Lambda K^-(\bar{\Lambda}K^+)$ , with a branching ratio of 67.8%, with subsequent decay  $\Lambda(\bar{\Lambda}) \to p\pi^-(\bar{p}\pi^+)$  (branching ratio of 63.9%) was used [40]. The  $\Lambda$  ( $\bar{\Lambda}$ ) candidates were formed from pairs of p  $(\bar{p})$  and  $\pi^ (\pi^+)$  tracks whose trajectories pointed to a common secondary decay vertex, which was well separated from the  $\Omega$  ( $\bar{\Omega}$ ) vertex. These  $\Lambda$  ( $\bar{\Lambda}$ ) candidates were then combined with the bachelor  $K^-$  ( $K^+$ ) tracks, which pointed to a common decay vertex well separated from the primary vertex. The mean specific energy loss measured by the TPC was used for the identification of the charged daughter particles  $(\pi^{\pm}, K^{\pm}, p, \bar{p})$  [41]. The decay length (DL) of an  $\Omega$  ( $\bar{\Omega}$ ) candidate was required to be larger than 4 cm from the primary vertex. As listed in Table 1, additional selection criteria on the DCA between the two  $\Lambda$   $(\bar{\Lambda})$ daughter tracks, between the  $\Lambda$  ( $\Lambda$ ) and the bachelor track, and between the  $\Lambda$  ( $\Lambda$ ) and the primary vertex position were applied to select  $\Omega$  ( $\bar{\Omega}$ ). Furthermore, a cut on the pointing angle of the  $\Omega$  ( $\bar{\Omega}$ ) candidate track with respect to the primary vertex  $(|(V_{\Omega} - V_{PV}) \times p_{\Omega}|/|V_{\Omega} - V_{PV}||p_{\Omega}|$ , where V is the position of the  $\Omega$   $(\bar{\Omega})$  candidate and the primary vertex, respectively and  $p_{\Omega}$  is the momentum of  $\Omega$   $(\bar{\Omega})$  was applied to select an  $\Omega$  $(\bar{\Omega})$ . To reduce the combinatorial background, the  $\Lambda$   $(\bar{\Lambda})$  candidates were selected in the invariant mass range between 1.112 and 1.120 GeV/ $c^2$ . In addition, the  $\Omega(\bar{\Omega})$  candidates due to misidentification of the  $\pi^-$  ( $\pi^+$ ) tracks as the bachelor  $K^-$  ( $K^+$ ) tracks were removed by checking a  $\Xi$  hypothesis. To check the  $\Xi$  hypothesis, the  $\pi$  mass was assigned to each bachelor track and the invariant mass was reconstructed for each pair of a  $\Lambda$  and the bachelor track. If the reconstructed invariant mass of the pair was in the range  $1.306 < Mass < 1.336 \text{ GeV}/c^2$ , the pair was rejected. The invariant mass distributions of combined  $\Omega$  and  $\bar{\Omega}$  candidates for 0-40% and 40-80% Au + Au collisions at  $\sqrt{s_{NN}} = 200$  GeV for the transverse momentum ( $p_T$ ) ranges  $1.5 < p_T < 2.0$  GeV/c and

**Table 1** Selection criteria for  $\Omega$  and  $\bar{\Omega}$  reconstruction.

| Selection criteria                                                            | 0-40%                     |                           | 40-80%        |
|-------------------------------------------------------------------------------|---------------------------|---------------------------|---------------|
|                                                                               | $p_T < 2.5 \text{ GeV/}c$ | $p_T > 2.5 \text{ GeV/}c$ | All $p_T$     |
| Ω DCA                                                                         | < 0.6 cm                  | < 0.7 cm                  | < 0.8 cm      |
| Λ DCA                                                                         | > 0.4 cm                  | > 0.3 cm                  | > 0.3 cm      |
| $DL(\Omega)$                                                                  | > 4.0 cm                  | > 4.0 cm                  | > 4.0 cm      |
| $DL(\Lambda)$                                                                 | > 6.0 cm                  | > 6.0 cm                  | > 5.0 cm      |
| $ (V_{\Omega} - V_{PV}) \times p_{\Omega} / V_{\Omega} - V_{PV}  p_{\Omega} $ | < 0.05                    | < 0.08                    | < 0.15        |
| $DL(\Omega) < DL(\Lambda)$                                                    | Yes                       | Yes                       | Yes           |
| proton DCA                                                                    | > 0.8 cm                  | > 0.8 cm                  | > 0.6 cm      |
| pion DCA                                                                      | > 2.0 cm                  | > 2.0 cm                  | > 1.8 cm      |
| bachelor DCA                                                                  | > 1.2 cm                  | > 1.2 cm                  | > 1.0 cm      |
| proton to pion DCA                                                            | < 0.8 cm                  | < 0.8 cm                  | < 1.0 cm      |
| Λ DCA to bachelor                                                             | < 0.8 cm                  | < 0.8 cm                  | < 1.0 cm      |
| $ M_{\Lambda} - 1.1156  \text{ GeV}/c^2$                                      | $< 0.007 \text{ GeV}/c^2$ | $< 0.007 \text{ GeV}/c^2$ | < 0.007 GeV/c |
| $ M_{\Omega} - 1.672  \text{ GeV}/c^2$                                        | $< 0.007 \text{ GeV}/c^2$ | $< 0.007 \text{ GeV}/c^2$ | < 0.007 GeV/c |

![](_page_4_Figure_2.jpeg)

Fig. 2. Reconstructed invariant mass (M) distributions of combined  $\Omega$  and  $\bar{\Omega}$  sample for 0-40% Au + Au collisions at  $\sqrt{s_{\rm NN}}=200$  GeV for the transverse momentum  $(p_T)$  range 1.5 <  $p_T<2.0$  GeV/c (a) and 3.0 <  $p_T<3.5$  GeV/c (b). The invariant mass distributions of combined  $\Omega$  and  $\bar{\Omega}$  sample for 40-80% Au + Au collisions at  $\sqrt{s_{\rm NN}}=200$  GeV for the transverse momentum  $(p_T)$  range 1.5 <  $p_T<2.0$  GeV/c (c) and 3.0 <  $p_T<3.5$  GeV/c (d). The solid lines at 1.665 and 1.679 GeV/ $c^2$  show the mass region of the reconstructed  $\Omega$  and  $\bar{\Omega}$  candidates used for the measurement of the proton- $\Omega$  correlation function.

 $3.0 < p_T < 3.5$  GeV/c are shown in Fig. 2(a–d). The signal (S) to signal + background (S + B) ratio, integrated over  $\pm 3\sigma$ , is 0.2 for the  $p_T$  range  $1.5 < p_T < 2.0$  GeV/c and 0.4 for the  $p_T$  range  $3.0 < p_T < 3.5$  GeV/c in the 0–40% centrality bin, and is 0.3 for the  $p_T$  range  $1.5 < p_T < 2.0$  GeV/c and 0.7 for the  $p_T$  range  $3.0 < p_T < 3.5$  GeV/c in the 40–80% centrality bin. All  $\Omega(\bar{\Omega})$  candidates with the invariant mass between 1.665 and 1.679 GeV/ $c^2$  were used in the analysis.

# $2.3. \ Two-particle\ correlation\ function$

The two-particle correlation function is defined as:

$$C_{\text{measured}}(k^*) = \frac{A(k^*)}{B(k^*)},\tag{1}$$

where  $A(k^*)$  is the distribution of the invariant relative momentum,  $k^* = |\vec{k}^*|$  is the relative momentum of one of the particles in the pair rest frame, for a proton and  $\Omega$  pair or anti-proton and  $\bar{\Omega}$  pair from the same event.  $B(k^*)$  is the reference distribution generated by mixing particles from different events with the same centrality and with approximately the same vertex position along the z-direction. The same single- and pair-particle cuts were applied for the real and mixed events. The data analysis was done in nine centrality bins: 0–5%, 5–10%, 10–20%, 20–30%, 30–40%, 40–50%, 50–60%, 60–70% and 70–80% for both the same events and the mixed events. The final results were combined and presented in two centrality bins: 0–40% and 40–80%. The efficiency and acceptance effects canceled out in the ratio  $A(k^*)/B(k^*)$ . Cor-

rections to the raw correlation functions were applied according to the expression:

$$C'(k^*) = \frac{C_{\text{measured}}(k^*) - 1}{P(k^*)} + 1,$$
(2)

where the pair-purity,  $P(k^*)$ , was calculated as a product of S/(S+B) for the  $\Omega$  ( $\bar{\Omega}$ ) and purity of the proton (antiproton). The selected sample of the proton candidates also included secondary protons from  $\Lambda$ ,  $\Sigma$  and  $\Xi$  decays. The estimated fraction of the primary protons (antiprotons) from the thermal model [42] studies is 52% (48%) [43]. The purity of the proton sample is obtained as a product of identification probability and fraction of primary protons. The pair-purity is 0.2 (0.36) for the 0–40% (40–80)% centrality bin and is constant over the analyzed range of the invariant relative momentum.

The effect of momentum resolution on the correlation functions has also been investigated using simulated tracks from the  $\Omega$  decay and the tracks for protons, with known momenta, embedded into the real events. Correlation functions have been corrected for the momentum resolution effect using the expression:

$$C(k^*) = \frac{C'(k^*)C_{\text{in}}(k^*)}{C_{\text{res}}(k^*)},\tag{3}$$

where  $C(k^*)$  represents the corrected correlation function, and  $C_{\rm in}(k^*)/C_{\rm res}(k^*)$  is the correction factor.  $C_{\rm in}(k^*)$  was calculated without taking into account the effect of momentum resolution and  $C_{\rm res}(k^*)$  included the effect of momentum resolution applied to each  $\Omega$  and proton candidates. More details related to these corrections can be found in Ref. [44]. The impact of momentum

![](_page_5_Figure_2.jpeg)

Fig. 3. Measured correlation function  $(C(k^*))$  for proton-Ω and antiproton- $\bar{\Omega}$  (PΩ+ $\bar{P}\bar{\Omega}$ ) for (0-40)% (a) and (40-80)% (b) Au + Au collisions at  $\sqrt{s_{NN}}=200$  GeV. The triangles represent raw correlations, open circles represent pair-purity corrected (PP) correlations, and solid circles represent pair-purity and smearing corrected (PP+SC) correlations. The error bars correspond to statistical errors and caps correspond to the systematic errors. The predictions from Ref. [24] for proton-Ω interaction potentials  $V_I$  (red),  $V_{II}$  (blue) and  $V_{III}$  (green) for source sizes  $R_p = R_{\Omega} = 5$  fm and  $R_p = R_{\Omega} = 2.5$  fm are shown in (a) and (b) respectively.

resolution on the correlation functions is negligible compared with statistical errors.

To study the shape of the correlation function for the background, the candidates from the side-bands of the invariant mass of  $\Omega$  were chosen in the range M < 1.665 GeV/ $c^2$  and M > 1.679 GeV/ $c^2$ . These selected candidates were then combined with the proton tracks from the same event to construct the relative momentum for the same event. The relative momentum for the mixed event is generated by combining the selected candidates from the side-bands of the invariant mass of  $\Omega$  with protons from different events with approximately the same vertex position along the z-direction.

## 3. Results and discussion

After applying the selection criteria for the proton and  $\Omega$ identification, as mentioned in the data analysis section, a total of  $38065 \pm 195 \; (8816 \pm 94)$  and  $3037 \pm 55 \; (679 \pm 26)$  pairs of proton- $\Omega$  and antiproton- $\bar{\Omega}$  for  $k^* < 0.2$  (0.1) GeV/c are observed for 0-40% and 40-80% Au + Au collisions, respectively. The measured proton- $\Omega$  and antiproton- $\bar{\Omega}$  correlation functions,  $P\Omega + \bar{P}\bar{\Omega}$ , the correlation functions after correction for pair-purity,  $P\Omega + \bar{P}\bar{\Omega}$  (PP), and the correlation functions after correction for pair-purity and momentum smearing,  $P\Omega + \bar{P}\bar{\Omega}$  (PP + SC), for 0–40% and 40–80% Au + Au collisions at  $\sqrt{s_{NN}} = 200$  GeV are shown in Fig. 3 (a) and 3 (b). The systematic errors for the measured proton- $\Omega$  correlation function were estimated by varying the following requirements for the selection of  $\Omega$  candidates: the decay length, DCA of  $\Omega$  to the primary vertex, pointing angle cuts and mass range, which affect the purity of the  $\Omega$  sample. The DCA and  $m^2$  requirements were varied to estimate the systematic error from the proton purity. In addition, the systematic errors from normalization and feed-down contributions were also estimated. The systematic errors from different sources were then added in quadrature. The combined systematic errors are shown in Fig. 3 as caps for each bin of the correlation function.

Predictions for the proton- $\Omega$  correlation function from Ref. [24] for the proton- $\Omega$  interaction potentials  $V_I$ ,  $V_{II}$  and  $V_{III}$  for a static source with sizes  $R_p = R_\Omega = 5.0$  fm and  $R_p = R_\Omega = 2.5$  fm are also shown in Fig. 3(a) and Fig. 3(b). The selected source sizes are not fit to the experimental data. The choice of the potentials in Ref. [24] is based on an attractive N $\Omega$  interaction in the

 $^5S_2$  channel from the lattice QCD simulations with heavy u-, d-, s-quarks from Ref. [16]. The potential  $V_{II}$  is obtained by fitting the lattice QCD data with a function  $V(r) = b_1 e^{-b_2 r^2} + b_3 (1 - e^{-b_4 r^2})(e^{-b_5 r}/r)^2$ , where  $b_1$  and  $b_3$  are negative and  $b_2$ ,  $b_4$  and  $b_5$  are positive, which represents a case with a shallow NΩ bound state. Two more potentials  $V_I$  and  $V_{III}$  represent cases without a NΩ bound state and with a deep NΩ bound state, respectively. The binding energies ( $\mathbf{E_b}$ ), scattering lengths ( $\mathbf{a_0}$ ) and effective ranges ( $\mathbf{r_{eff}}$ ) for the NΩ interaction potentials  $V_I$ ,  $V_{II}$  and  $V_{III}$  are listed in Table 2 [24]. The measured correlation function for  $P\Omega + \bar{P}\bar{\Omega}$  is in agreement with the predicted trend with the interaction potentials  $V_I$ ,  $V_{II}$  and  $V_{III}$  in 0–40% Au + Au collisions as shown in Fig. 3(a). However, due to limited statistics at the lower  $k^*$ , strong enhancement due to the Coulomb interaction is not visible in 40–80% Au + Au collisions in Fig. 3(b).

The measured proton- $\Omega$  and antiproton- $\bar{\Omega}$  correlation functions include three effects coming from the elastic scattering in the  $^5S_2$  channel, the strong absorption in the  $^3S_1$  channel and the long-range Coulomb interaction. The Coulomb interaction between the positively charged proton and negatively charged  $\Omega$  introduces a strong enhancement in the correlation function at the small  $k^*$ , as seen in Fig. 3. One can remove the Coulomb enhancement using a Gamow factor [45], however, this simple correction is not good enough to extract the characteristic feature of the correlation function from the strong interaction. A full correction with the source-size dependence is needed to isolate the effect of the strong interaction from the Coulomb enhancement. Therefore, the ratio of the correlation function between small and large collision systems, is proposed in Ref. [24] as a model-independent way to access the strong interaction with less contamination from the Coulomb interaction

The ratio of the combined proton– $\Omega$  and antiproton– $\bar{\Omega}$  correlation function from the peripheral (40–80%) to central (0–40%) collisions, defined as R = C<sub>40–80</sub>/C<sub>0–40</sub> is shown in Fig. 4. The correlation functions corrected for pair-purity and momentum smearing are used for the ratio calculations. The systematic uncertainties are propagated from the measured correlation functions for the 0–40% and 40–80% centrality bins and are shown as caps. For the background study, the candidates from the side-bands of the  $\Omega$  invariant mass were combined with protons to construct the correlation function. The same ratio, R, for the background is unity and is shown as open crosses in Fig. 4. Previous measurements

**Table 2** Binding energy  $(E_b)$ , scattering length  $(a_0)$  and effective range  $(r_{eff})$  for the Spin-2 proton- $\Omega$  potentials [24].

| Spin-2 $p\Omega$ potentials | $V_I$ | $V_{II}$ | $V_{III}$ |
|-----------------------------|-------|----------|-----------|
| E <sub>b</sub> (MeV)        | -     | 6.3      | 26.9      |
| $\mathbf{a_0}$ (fm)         | -1.12 | 5.79     | 1.29      |
| r <sub>eff</sub> (fm)       | 1.16  | 0.96     | 0.65      |

![](_page_6_Figure_4.jpeg)

**Fig. 4.** The solid circle represents the ratio (R) of small system (40–80% collisions) to large system (0–40% collisions) for proton- $\Omega$  and antiproton- $\bar{\Omega}$  ( $P\Omega + \bar{P}\bar{\Omega}$ ), where both the correlation functions are corrected for pair-purity and momentum smearing. The error bars correspond to the statistical errors and caps correspond to the systematic errors. The open crosses represent the ratio for background candidates from the side-bands of an  $\Omega$  invariant mass. Predictions for the ratio of the small system to large system [24,48] for proton- $\Omega$  interaction potentials  $V_I$  (red),  $V_{II}$  (blue) and  $V_{III}$  (green) for static source with different source sizes (S, L) = (2, 3), (2, 4), (2.5, 5) and (3, 5) fm, where S and L corresponding to small and large systems, are shown in (a), (b), (c) and (d) respectively. In addition, the prediction for the expanding source is shown in (e).

of the source sizes for  $\pi$ – $\pi$ ,  $K_S^0$ – $K_S^0$ , proton–proton and proton– $\Lambda$  correlations show that the source size decrease as the transverse mass increases [22,44,43,46,47]. Using this transverse mass dependence [47], the expected source size for proton– $\Omega$  is 2–3 fm for the peripheral collisions and 3–5 fm for the central collisions. The predictions for the ratio of the small system to the large system from Refs. [24,48] for the proton– $\Omega$  interaction potentials  $V_I$ ,  $V_{II}$  and  $V_{III}$  for a static source with different source sizes (S, L) = (2, 3), (2, 4), (2.5, 5) and (3, 5) fm, where S and L correspond to the small and large collision systems, respectively, are shown in Fig. 4(a–d). A small variation in the source size does not change the characteristic of the ratio for the choice of three potentials.

Predictions for the ratio of the small system to the large system with the effects of collective expansion are also shown in Fig. 4(e) [24]. The transverse source sizes are taken as  $R_p^{tr} = R_\Omega^{rr} = 2.5$  fm for the small system and  $R_p^{tr} = R_\Omega^{tr} = 5$  fm for the large system. The temperature at the thermal freeze-out is  $T_{p,\Omega} = 164$  MeV for the peripheral collisions and  $T_{p,\Omega} = 120$  MeV for the central collisions [49,50] and the proper-time at the thermal freeze-out is  $\tau_p(\tau_\Omega) = 3(2)$  fm/c for the peripheral collisions and  $\tau_p(\tau_\Omega) = 20(10)$  fm/c for the central collisions [51].

The predictions with an expanding source for the proton- $\Omega$  interaction potentials  $V_I$  and  $V_{II}$  are  $3\sigma$  larger than the data at  $k^*=20$  MeV/c. The predictions for the proton- $\Omega$  interaction potential  $V_{III}$  with an expanding source or static source are within  $1\sigma$  of the data at  $k^*=20$  MeV/c. As shown in Fig. 4, the measured ratios at  $k^*=20$  and 60 MeV/c are  $R=0.28\pm0.35_{stat}\pm0.03_{sys}$  (background  $=0.96\pm0.13_{stat}$ ) and  $R=0.81\pm0.22_{stat}\pm0.08_{sys}$  (background  $=0.97\pm0.05_{stat}$ ), respectively. The measured ratios at  $k^*=20$  and 60 MeV/c are compared in Fig. 5 with the model

calculations for the ratio of the correlation function for the peripheral to the central collisions and the scattering length for the proton– $\Omega$  interaction from the Ref. [24]. From the comparison, we conclude that our data favor a positive scattering length for the proton– $\Omega$  interaction. The positive scattering length and the measured ratio of the proton– $\Omega$  correlation function from peripheral to central collisions less than unity for  $k^* < 40 \text{ MeV/}c$  favors the proton– $\Omega$  interaction potential  $V_{III}$  with  $\mathbf{E_b} \sim 27 \text{ MeV}$  for proton and  $\Omega$ .

#### 4. Conclusions

The first measurement of the proton- $\Omega$  correlation functions in heavy-ion collisions is presented in this Letter. The measured ratio of the proton- $\Omega$  correlation function from peripheral to central Au + Au collisions at  $\sqrt{s_{\rm NN}}=200$  GeV is compared with the predictions based on the proton- $\Omega$  interaction extracted from (2+1)-flavor lattice QCD simulations. At present, due to limited statistics, it is not possible to extract the interaction parameters. However the measured ratio of the proton- $\Omega$  correlation function from peripheral to central collisions less than unity for  $k^* < 40 \text{ MeV}/c$  within  $1\sigma$  indicates that the scattering length is positive for the proton- $\Omega$  interaction and favors the proton- $\Omega$  bound state hypothesis.

# Acknowledgements

We thank Dr. Kenji Morita, Dr. Akira Ohnishi, Dr. Faisal Etminan and Dr. Tetsuo Hatsuda for providing the calculation and enlightening discussions. We thank the RHIC Operations Group and RCF at

![](_page_7_Figure_2.jpeg)

**Fig. 5.** The measured ratio of the correlation functions between 40–80% collisions and 0–40% collisions, R, for *k*<sup>∗</sup> = 20 (red) and 60 (blue) MeV/*c* are compared with predictions from Ref. [24] for the ratio as a function of 1*/a*0, where *a*<sup>0</sup> is scattering length. The bands represent statistical errors on the measurement.

BNL, the NERSC Center at LBNL, and the Open Science Grid consortium for providing resources and support. This work was supported in part by the Office of Nuclear Physics within the U.S. DOE Office of Science, the U.S. National Science Foundation, the Ministry of Education and Science of the Russian Federation, National Natural Science Foundation of China, Chinese Academy of Sciences, the Ministry of Science and Technology of China (973 Program No. 2014CB845400, 2015CB856900) and the Chinese Ministry of Education, the National Research Foundation of Korea, Czech Science Foundation and Ministry of Education, Youth and Sports of the Czech Republic, Department of Atomic Energy and Department of Science and Technology of the Government of India, the National Science Centre of Poland, the Ministry of Science, Education and Sports of the Republic of Croatia, ROSATOM of Russia and German Bundesministerium für Bildung, Wissenschaft, Forschung und Technologie (BMBF) and the Helmholtz Association.

#### **References**

- [1] A.R. Bodmer, Phys. Rev. D 4 (1971) 1601.
- [2] E. Witten, Phys. Rev. D 30 (1984) 272.
- [3] J.H. Chen, D. Keane, Y.G. Ma, A.H. Tang, Z.B. Xu, Phys. Rep. 760 (2018) 1.
- [4] M. Prakash, J.M. Lattimer, Nucl. Phys. A 639 (1998) 433c.
- [5] H.J. Schulze, A. Polls, A. Ramos, I. Vidana, Phys. Rev. C 73 (2006) 058801.
- [6] S. Weissenborn, D. Chatterjee, J. Schaffner-Bielich, Nucl. Phys. A 881 (2012) 62.

- [7] S. Petschauer, J. Haidenbauer, N. Kaiser, U.-G. Maißner, W. Weise, Eur. Phys. J. A 52 (2016) 15.
- [8] R. Jaffe, Phys. Rev. Lett. 38 (1977) 195.
- [9] V.G.J. Stoks, T.A. Rijken, Phys. Rev. C 59 (1999) 3009.
- [10] Z.Y. Zhang, Y.W. Yu, C.R. Ching, T.H. Ho, Z.D. Lu, Phys. Rev. C 61 (2000) 065204.
- [11] R. Machleidt, I. Slaus, J. Phys. G 27 (2001) R69.
- [12] T. Inoue, et al., HAL QCD Collaboration, Prog. Theor. Phys. 124 (2010) 591.
- [13] S.R. Beane, et al., NPLQCD Collaboration, Phys. Rev. Lett. 106 (2011) 162001.
- [14] T. Inoue, et al., HAL QCD Collaboration, Phys. Rev. Lett. 106 (2011) 162002.
- [15] T. Inoue, et al., HAL QCD Collaboration, Nucl. Phys. A 881 (2012) 28.
- [16] F. Etminan, et al., HAL QCD Collaboration, Nucl. Phys. A 928 (2014) 89.
- [17] B.I. Abelev, et al., STAR Collaboration, Science 328 (2010) 58.
- [18] L. Adamczyk, et al., STAR Collaboration, Phys. Rev. C 97 (2018) 054909.
- [19] A. Gal, E.V. Hungerford, D.J. Millener, Rev. Mod. Phys. 88 (2016) 035004, and references therein.
- [20] J. Adams, et al., STAR Collaboration, Phys. Rev. Lett. 98 (2007) 062301.
- [21] L. Adamczyk, et al., STAR Collaboration, Phys. Rev. Lett. 114 (2015) 022301.
- [22] L. Adamczyk, et al., STAR Collaboration, Nature 527 (2015) 345.
- [23] S. Acharya, et al., ALICE Collaboration, arXiv:1805.12455.
- [24] K. Morita, A. Ohnishi, F. Etminan, T. Hatsuda, Phys. Rev. C 94 (2016), 031901 (R).
- [25] T. Goldman, K. Maltman, G.J. Stephenson, K.E. Schmidt, F. Wang, Phys. Rev. Lett. 59 (1987) 627.
- [26] B. Schwesinger, F.G. Scholtz, H.B. Geyer, Phys. Rev. D 51 (1995) 1228.
- [27] M. Oka, Phys. Rev. D 38 (1988) 298.
- [28] H. Pang, J. Ping, F. Wang, T. Goldman, E. Zhao, Phys. Rev. C 69 (2004) 065207.
- [29] H. Pang, J. Ping, L. Chen, F. Wang, T. Goldman, Phys. Rev. C 70 (2004) 035201.
- [30] M. Chen, H. Huang, J. Ping, F. Wang, Phys. Rev. C 83 (2011) 015202.
- [31] H. Huang, J. Ping, F. Wang, Phys. Rev. C 92 (2015) 065202.
- [32] Q.B. Li, P.N. Shen, Eur. Phys. J. A 8 (2000) 417.
- [33] N. Shah, Y.G. Ma, J.H. Chen, S. Zhang, Phys. Lett. B 754 (2016) 6.
- [34] K.H. Ackermann, et al., STAR Collaboration, Nucl. Instrum. Methods A 499 (2003) 624.
- [35] M. Anderson, et al., Nucl. Instrum. Methods A 499 (2003) 659.
- [36] W.J. Llope, STAR Collaboration, Nucl. Instrum. Methods A 661 (2012) S110.
- [37] W.J. Llope, et al., Nucl. Instrum. Methods A 759 (2014) 23.
- [38] M.L. Miller, et al., Annu. Rev. Nucl. Part. Sci. 57 (2007) 205.
- [39] L. Adamczyk, et al., STAR Collaboration, Phys. Rev. Lett. 118 (2017) 212301; G. Contin, et al., Nucl. Instrum. Methods A 907 (2018) 60.
- [40] C. Patrignani, et al., Particle Data Group, Chin. Phys. C 40 (2016) 100001.
- [41] M. Shao, O.Y. Barannikova, X. Dong, Y. Fisyak, L. Ruan, P. Sorensen, Z. Xu, Nucl. Instrum. Methods A 558 (2006) 419.
- [42] P. Braun-Munzinger, J. Stachel, Nucl. Phys. A 606 (1996) 320; P. Braun-Munzinger, I. Heppe, J. Stachel, Phys. Lett. B 465 (1999) 15; P. Braun-Munzinger, D. Magestro, K. Redlich, J. Stachel, Phys. Lett. B 518 (2001) 41.
- [43] J. Adams, et al., STAR Collaboration, Phys. Rev. C 74 (2006) 064906.
- [44] J. Adams, et al., STAR Collaboration, Phys. Rev. C 71 (2005) 044906.
- [45] Urs Achim Wiedemann, Ulrich Heinz, Phys. Rep. 319 (1999) 145.
- [46] B.I. Abelev, et al., STAR Collaboration, Phys. Rev. C 74 (2006) 054902.
- [47] H. Zbroszczyk, Studies of baryon–baryon correlations in relativistic nuclear collisions registered at the STAR experiment, PhD thesis, https://drupal.star.bnl. gov/STAR/files/Zbroszczyk\_Hanna.pdf.
- [48] Private communications with Kenji Morita, Akira Ohnishi, Faisal Etminan and Tetsuo Hatsuda.
- [49] B. Abelev, et al., ALICE Collaboration, Phys. Lett. B 728 (2014) 216; B. Abelev, et al., ALICE Collaboration, Phys. Lett. B 734 (2014) 409 (Erratum).
- [50] C. Shen, U. Heinz, P. Huovinen, H. Song, Phys. Rev. C 84 (2011) 044903.
- [51] X. Zhu, F. Meng, H. Song, Y.X. Liu, Phys. Rev. C 91 (2015) 034904.