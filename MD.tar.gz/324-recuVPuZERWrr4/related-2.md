# Physics 221B Spring 2020 Notes 35

# Introduction to Scattering Theory and Scattering from Central Force Potentials†

# 1. Introduction

Scattering is a fundamental physical process that is important in a wide range of applications. For example, most experimental work in particle physics involves scattering, and a large part of what is known about the properties of particles has been obtained through scattering experiments. For another example, scattering of nuclear species in a hot plasma is important in determining thermonuclear reaction rates in stars or in the early universe. For yet another, one of the current experimental techniques for investigating carbon nanotubes is the scattering of photons. A long list of examples could be accumulated.

In the previous set of notes we considered some scattering problems as an application of timedependent perturbation theory, taking a time-dependent approach. In this set of notes we consider potential scattering in three dimensions, taking a time-independent approach and presenting some of the most important basic facts. We focus on the energy eigenfunctions of the time-independent Schr¨odinger equation of positive energy that satisfy certain boundary conditions. These solutions extend to infinity and are not normalizable.

We begin by exploring the asymptotic form of scattering solutions of the Schr¨odinger equation, defining the scattered wave and the scattering amplitude, the latter of which bears a simple relation to the differential cross section. We then specialize to the case of central force potentials, where the solutions are expressed in terms of radial wave functions. When the potential dies off rapidly enough the asymptotic behavior of the radial wave functions is characterized by certain phase shifts, in terms of which the scattered wave, the scattering amplitude, and the differential cross section can be expanded. We then take up hard sphere scattering as an example, examining both the low- and high-energy limits, and drawing some conclusions that apply to any localized potential. Finally we discuss the optical theorem in the case of potential scattering, which connects the total cross section with the scattering amplitude in the forward direction.

<sup>†</sup> Links to the other sets of notes can be found at:

# 2. Boundary Conditions in Potential Scattering

In these notes we shall concentrate on scattering by a potential V (x). For generality at first we do not assume it is rotationally invariant, but we do assume that it dies off at spatial infinity,

$$\lim_{r \to \infty} V(\mathbf{x}) = 0,\tag{1}$$

where r = |x|. This is the normal assumption in scattering theory. In fact, the simplest case, which we concentrate on in these notes, is the one in which V (x) → 0 faster than 1/r; we will explain this in more detail in Sec. 7.

We will speak of the scattering of a particle by the potential V (x), as if it were a fixed potential in space, but in reality the beam particle interacts with a target, which often is another particle. Then a proper treatment requires us to take into account the dynamics of both particles. The changes necessary to do this were discussed in some detail in Notes 33. For now we simply note that if the target is very massive, then it can be thought of as producing a potential for the beam particle that is fixed in space (that is, in an inertial frame), as we shall assume in these notes.

We will be interested in solving the time-independent Schr¨odinger equation,

$$H\psi(\mathbf{x}) = -\frac{\hbar^2}{2m} \nabla^2 \psi(\mathbf{x}) + V(\mathbf{x})\psi(\mathbf{x}) = E\psi(\mathbf{x}), \tag{2}$$

for positive energies E > 0. We will write the energy eigenfunction as ψ<sup>E</sup> (x) if we want to emphasize its dependence on the energy. Since the energy is positive the wave function extends to infinity and there is no quantization, that is, there exists a solution for every value of E > 0.

In fact, there exist many linearly independent solutions for a given E and we require the one that satisfies the right boundary conditions to represent the physics of a scattering problem. At first we approach the subject of the boundary conditions somewhat intuitively, starting with a classical picture of a scattering experiment, as illustrated in Fig. 1.

![](_page_1_Picture_11.jpeg)

Fig. 1. Classical scattering. A beam of particles, all with the same momentum p, is directed against a target.

In the figure a beam of particles, all with the same momentum p, is directed at a target. Potential scattering is elastic, that is, when particles gain kinetic energy by falling into a potential

well, they lose the same amount when climbing back out again, so the kinetic energy of the scattered particles at a large distance from the scatterer is the same as the kinetic energy in the incident beam. In classical scattering the beam particles will undergo some deflection in their direction of motion as long as the potential is nonzero, so if the potential dies off only gradually with distance then all particles experience some scattering and the total cross section is infinite. To obtain a finite total cross section in classical scattering V (x) must rigorously cut off beyond some radius. (Of course, if the potential dies off rapidly with distance, then we may not care about the very small angle scattering that results at large distances.)

Let us now consider how this picture changes in quantum scattering. In quantum mechanics a state of a definite momentum p is a plane wave Ceik·<sup>x</sup> , where C is a constant and p = ¯hk, so it is natural to associate the incident beam in a scattering experiment with a plane wave. This involves some idealization since a real plane wave fills up all of space and, in particular, it extends to infinity in the transverse direction, while real beams are always of finite extent in the transverse direction. An image of what happens when the incident plane wave strikes the target is given in Fig. 2; the interaction produces the scattered wave, which radiates away from the target. If the scattering potential is short range then we can intuitively expect that some of the incident wave, the parts at large impact parameter, will effectively miss the target and continue downstream as a nearly unmodified plane wave.

![](_page_2_Picture_4.jpeg)

Fig. 2. Quantum scattering by a potential V (x). Incident and scattered waves are shown.

Another idealization is involved in using energy eigenfunctions ψE(x) to describe the scattering process, since an energy eigenfunction is a stationary state, and real beams are turned on at some time and turned off at a later time. In effect, an energy eigenfunction represents the idealized steady state that would be obtained if a plane wave could be directed against a target for all times going back to t → −∞.

Another issue is that energy eigenfunctions of positive energy are not normalizable, so they cannot represent the state of a single particle. We accommodate this problem in these notes by interpreting the density ρ = |ψ| 2 , not as a probability density, but rather as a particle density in the beam. Similarly, we interpret the current,

$$\mathbf{J} = \operatorname{Re}\left[\psi^*\left(-\frac{i\hbar\nabla}{m}\right)\psi\right],\tag{3}$$

as a particle current, not a probability current. The overall normalization of the unbounded wave function is arbitrary, and represents simply the intensity of the beam. Quantities of interest, such as the differential cross section, are independent of this normalization.

The solution ψE(x) should have the right boundary conditions at large distances from the scatterer to represent both the incident plane wave and the scattered wave. We define the incident wave by

$$\psi_{\rm inc}(\mathbf{x}) = e^{i\mathbf{k}\cdot\mathbf{x}},\tag{4}$$

which is understood to apply everywhere in space, even at small radii where the potential V (x) is active. The incident wave is parameterized by a wave vector k or an equivalent momentum p = ¯hk. The incident wave does not satisfy the Schr¨odinger equation (2) everywhere in space, but we shall assume that V (x) falls off rapidly enough that at large distances from the scatterer the potential can be ignored. This applies in particular to large distances upstream where the experimenter is located, who is launching particles at the scatterer. Then at large distances the incident wave does satisfy the Schr¨odinger equation (2), and, in particular, the Schr¨odinger Hamiltonian (2) applied to ψinc brings out an energy

$$E = \frac{\hbar^2 k^2}{2m}. (5)$$

In other words, the wave number parameter k of the incident wave and the energy eigenvalue of the solution ψE(x) of the Schr¨odinger equation are connected by the free-particle relation (5). In effect, the experimenter, who chooses the incident momentum p of the particles to launch at the scatterer, determines not only the energy eigenvalue of the corresponding solution of the Schr¨odinger equation but also the boundary conditions on the energy eigenfunction.

For given incident wave vector k we now define the scattered wave by

$$\psi_{\text{scatt}}(\mathbf{x}) = \psi_E(\mathbf{x}) - \psi_{\text{inc}}(\mathbf{x}),$$
 (6)

so that

$$\psi_E(\mathbf{x}) = \psi_{\text{inc}}(\mathbf{x}) + \psi_{\text{scatt}}(\mathbf{x}) = e^{i\mathbf{k}\cdot\mathbf{x}} + \psi_{\text{scatt}}(\mathbf{x}).$$
 (7)

What gives substance to this definition is the boundary conditions we impose on ψscatt; in accordance with the picture in Fig. 2, we require that at large distances the scattered wave be purely outgoing, that is, propagating in the radial direction.

For this reason we guess that the asymptotic form of the scattered wave be given by

$$\psi_{\text{scatt}}(\mathbf{x}) \sim \frac{e^{ikr}}{r} f(\theta, \phi),$$
(8)

where the symbol ∼ means that the right-hand side is the asymptotic form of the left-hand side as r → ∞. More precisely, the symbol ∼ means that the left-hand side equals the right-hand side, plus terms that go to zero more rapidly as r → ∞ than the right-hand side itself.

We choose the asymptotic form (8) for the scattered wave for several reasons. First, assuming that V (x) can be ignored at large distances, and noting that Eq. (8) only applies asymptotically, we require that the scattered wave satisfy the free-particle Schr¨odinger equation to leading order in 1/r. That it does so follows from an application of Eq. (D.23),

$$\nabla^2 \left[ \frac{e^{ikr}}{r} f(\theta, \phi) \right] = -k^2 \left[ \frac{e^{ikr}}{r} f(\theta, \phi) \right] + O\left(\frac{1}{r^3}\right), \tag{9}$$

where the dominant term comes from the radial term of the Laplacian in spherical coordinates. Thus the kinetic energy term in the Schr¨odinger equation balances the total energy term Eψ, to leading order in 1/r. We do not require that the form (8) be an exact solution of the free particle Schr¨odinger equation because it is only an asymptotic form, with presumably higher order corrections.

Notice, by the way, that the parameter k in the asymptotic form (8) of the scattered wave is the magnitude of the wave vector in the incident wave (4), k = |k|, as required if the scattered wave is to satisfy the Schr¨odinger equation to leading asymptotic order in the asymptotic region. This again is a reflection of the fact that the scattering is elastic, so that in the asymptotic region the scattered particles have the same kinetic energy as the incident particles.

Next, the wave (8) has wave fronts r = const that are spheres. If we imagine that the scatterer has some definable finite range (continuing with an intuitive approach to the question of boundary conditions) then the angle subtended by the scatterer goes to zero as r → ∞, and all scattered waves must be propagating in the radial direction at large distances. This means that the wave fronts are spheres. Also, if the time dependence e −iEt/h¯ is appended to the scattered wave (8), then the waves are seen to be purely outgoing, that is, propagating outward in the radial direction. Finally, the factor f(θ, φ) allows the scattered wave to have a different amplitude in different directions, which is necessary since normally scattering is not isotropic.

Equations (4)–(8) define the boundary conditions that the scattering solution ψE(x) of the Schr¨odinger equation must satisfy to represent the physics of scattering. The boundary conditions are completely parameterized by the incident wave number k, which also determines the energy eigenvalue E through the free particle relation (5).

We can see now why there are many linearly independent solutions ψE(x) for a given energy E; they correspond to different initial wave vectors k, all satisfying Eq. (5). In other words, we can vary the direction of k while holding its magnitude fixed, and generate a family of energy eigenfunctions all of the same energy. The family is parameterized by points on a sphere (the direction of k). (In one-dimensional scattering this family reduces to two members, scattering waves that are incident from the right or from the left.)

For this reason we shall henceforth denote the scattering solutions of the Schr¨odinger equation (2) by ψk(x) rather than ψE(x), where k and the energy eigenvalue E are understood to be connected by the free-particle relation (5). In summary, the desired solution of the Schr¨odinger equation satisfies the boundary conditions

$$\psi_{\mathbf{k}}(\mathbf{x}) \sim e^{i\mathbf{k}\cdot\mathbf{x}} + \frac{e^{ikr}}{r} f(\theta, \phi).$$
(10)

It is plausible based on what we have said that for every k there is a unique solution to the Schr¨odinger equation of energy E = ¯h 2 k <sup>2</sup>/2m satisfying the boundary conditions (10). This is a fact that can be proven with the theory of Fredholm integral equations.

We remark that in scattering theory the game we play is that the only quantities that are interesting physically are those defined by the asymptotic (large r) properties of the wave. This applies to the differential cross section, which is what is normally measured in real experiments.

# 3. The Scattering Amplitude and Cross Section

The function f(θ, φ) is called the scattering amplitude. It is in general a complex function of the angles. A good deal of scattering theory is devoted to its determination, since it bears a simple relation to the differential cross section.

![](_page_5_Picture_6.jpeg)

Fig. 3. A particle detector intercepts a small solid angle ∆Ω which defines a cone as seen from the scatterer. Particles scattered into this cone will enter the detector.

Cross sections and differential cross sections were defined in Notes 33, where the relation between cross sections and transition rates was discussed. In the present case let us imagine an experimental situation such as illustrated in Fig. 3. A detector, located at some distance from the scatterer, intercepts all scattered particles coming out in a small cone of solid angle ∆Ω, centered on some direction nˆ = (θ, φ). The counting rate is the scattered current Jscatt integrated across the aperture to the detector.

The particle density in the incident beam is

$$n_{\rm inc} = |\psi_{\rm inc}(\mathbf{x})|^2 = 1. \tag{11}$$

Similarly, the incident current is

$$\mathbf{J}_{\text{inc}} = \text{Re}\left[e^{-i\mathbf{k}\cdot\mathbf{x}}\left(-\frac{i\hbar}{m}\nabla\right)e^{i\mathbf{k}\cdot\mathbf{x}}\right] = \frac{\hbar\mathbf{k}}{m} = \mathbf{v},\tag{12}$$

where v is the velocity of the incident beam. In magnitude, Jinc = v.

By our calculation ninc is dimensionless, and if you are fastidious you might want it to have dimensions of inverse volume (or particles per unit volume). If so you can multiply the wave function by a constant of dimensions volume−3/<sup>2</sup> , but since the physical quantities we are interested in are independent of the normalization of the wave function, this is not necessary.

As for the scattered current, in the asymptotic region it is

$$\mathbf{J}_{\text{scatt}} \sim \text{Re}\Big\{ \Big[ \frac{e^{-ikr}}{r} f(\theta, \phi)^* \Big] \Big( -\frac{i\hbar}{m} \Big) \Big[ \nabla \frac{e^{ikr}}{r} f(\theta, \phi) \Big] \Big\}, \tag{13}$$

which is only an asymptotic form since we are using the asymptotic form (8) of the scattered wave. To evaluate this we take the gradient of the scattered wave spherical coordinates (see Eq. (D.20)),

$$\nabla \frac{e^{ikr}}{r} f(\theta, \phi) = \hat{\mathbf{r}} \left[ \frac{ik \, e^{ikr}}{r} \, f(\theta, \phi) \right] + O\left(\frac{1}{r^2}\right), \tag{14}$$

where we only carry the result to leading order in 1/r. Substituting this into (3), we find

$$\mathbf{J}_{\text{scatt}} \sim v \, \frac{|f(\theta, \phi)|^2}{r^2} \, \hat{\mathbf{r}}. \tag{15}$$

To leading order, the asymptotic form of the scattered current is purely in the outward radial direction, as we expect. Terms in Jscatt that go to zero faster than 1/r<sup>2</sup> as r → ∞ will not contribute to the counting rate, since the area of the aperture of the detector, for fixed ∆Ω, is proportional to r 2 .

Now we integrate the scattered current over the aperture to the detector, which we assume is at large distance r from the scatterer, and which has area r <sup>2</sup>∆Ω. The counting rate is

$$\frac{dw}{d\Omega} \Delta\Omega = \int_{\text{aperture}} \mathbf{J}_{\text{scatt}} \cdot d\mathbf{a} = v |f(\theta, \phi)|^2 \Delta\Omega, \tag{16}$$

where da is the area element of the aperture and dw/dΩ is the counting rate per unit solid angle. Now dividing this by Jinc = v, we obtain

$$\frac{d\sigma}{d\Omega} = |f(\theta, \phi)|^2,\tag{17}$$

a simple result. This equation explains the interest in finding f(θ, φ), since it leads immediately to the differential cross section, which is measurable. Notice that the counting rate, which is physically observable in a scattering experiment, depends only on the leading asymptotic form of the scattered wave function. One does not need to know the exact form of the scattered wave (at smaller values of r where correction terms to the asymptotic expansion of the scattered wave are important, or in the scattering region where the potential is nonzero).

Now for some comments about this calculation. Notice that we computed the flux of the scattered particles intercepted by the detector, but we ignored the incident particles. In realistic scattering experiments the detector is usually located outside the beam, so incident particles do not enter it. Our incident wave (4) fills all of space, but that is an artifact of our simplified model. In reality the beam will be cut off at some finite transverse size, and if the scattering angle is not too small, the detector can be located outside the beam.

If the scattering angle is very small, however, then the detector will have to be inside the beam and it will detect incident particles as well as scattered ones. The counting rate is still the particle flux intercepted by the aperture of the detector, but the flux is neither the incident flux nor the scattered flux nor the sum of the two, but rather the flux computed from the total wave function ψ = ψinc + ψscatt. Since the current is quadratic in the wave function, there are cross terms or interference terms between the incident wave and the scattered wave. Taking all these effects into account leads to the optical theorem, which we take up in Sec. 14.

## 4. Central Force Scattering

We now specialize to the important case of a central force potential, V = V (r). The main simplification in this case is that the Schr¨odinger equation (2) is separable in spherical coordinates (see Notes 16), so the solutions can be written in the form

$$\psi_{k\ell m}(\mathbf{x}) = \psi_{k\ell m}(r, \theta, \phi) = R_{k\ell}(r) Y_{\ell m}(\theta, \phi), \tag{18}$$

where Rkℓ(r) is a solution of version one of the radial Schr¨odinger equation, Eq. (16.7), with potential V (r). The radial eigenfunction Rkℓ(r) is parameterized by ℓ because the radial Schr¨odinger equation contains ℓ in the centrifugal potential. It is also parameterized by the energy E, which we will normally indicate by an equivalent wave number k, given by E = ¯h 2 k <sup>2</sup>/2m. The three-dimensional solution ψ depends on k, ℓ and m, as indicated in Eq. (18). Of these, k ≥ 0 is a continuous index and ℓ and m are discrete.

The solutions (18) of the Schr¨odinger equation do not satisfy the boundary conditions (10) that we require for a scattering solution, but they do form a complete set so the desired scattering solution can be expressed as a linear combination of them. Since the scattering solution is an energy eigenfunction of energy E = ¯h 2 k <sup>2</sup>/2m it can only be a linear combination of central force eigenfunctions (18) with the same energy, that is, there must be coefficients Aℓm such that

$$\psi_{\mathbf{k}}(\mathbf{x}) = \sum_{\ell m} A_{\ell m} R_{k\ell}(r) Y_{\ell m}(\theta, \phi), \tag{19}$$

where the k on the left and the k on the right are related by k = |k|. In a moment we will find the expansion coefficients Aℓm in terms of some simple parameters that characterize the potential (namely, the phase shifts δℓ).

# 5. Free Particle Solutions

Free particle solutions were discussed in Secs. 16.6 –16.8. Here we recall some of that material and present some further facts that will be useful in scattering theory.

In the case of the free particle the radial Schr¨odinger equation (16.7) with energy E = ¯h 2 k <sup>2</sup>/2m has two linearly independent solutions, jℓ(kr) and yℓ(kr), where j<sup>ℓ</sup> and y<sup>ℓ</sup> are the spherical Bessel functions. The small and large argument limiting forms of these Bessel functions are given by

Eqs. (16.27)–(16.30). If the potential V(r) is zero all the way down to r = 0, that is, if the particle is free everywhere, then the y-type Bessel functions are not allowed because they diverge at r = 0. Then a complete set of free particle energy eigenfunctions is

$$\psi_{k\ell m}^{\text{free}}(r,\theta,\phi) = j_{\ell}(kr) Y_{\ell m}(\theta,\phi). \tag{20}$$

But if we are seeking free particle solutions in some region away from r = 0, such as in the asymptotic region of a scattering problem where the potential can be ignored, then the y-type solutions are also allowed.

The incident plane wave  $e^{i\mathbf{k}\cdot\mathbf{x}}$  is a free particle solution of the Schrödinger equation that is obtained by separating the wave equation in rectangular coordinates, while the solutions (20) are obtained by separating in spherical coordinates. Thus the incident plane wave can be expressed as a linear combination of the solutions (20). The expansion gives  $e^{i\mathbf{k}\cdot\mathbf{x}}$  as a linear combination of the solutions (20) with the same energy. The expansion coefficients can be worked out with some use of recursion relations satisfied by the spherical Bessel functions and the Legendre polynomials. We omit details here, which may be found in textbooks such as Messiah, Sakurai or Commins. The result, however, is useful. It is

$$e^{i\mathbf{k}\cdot\mathbf{x}} = \sum_{\ell m} 4\pi i^{\ell} j_{\ell}(kr) Y_{\ell m}^{*}(\hat{\mathbf{k}}) Y_{\ell m}(\hat{\mathbf{r}}), \tag{21}$$

where  $\hat{\mathbf{r}}$  and  $\hat{\mathbf{k}}$  refer to the directions of the vectors  $\mathbf{x}$  and  $\mathbf{k}$  on the left hand side, where  $Y_{\ell m}(\hat{\mathbf{r}})$  means the same as  $Y_{\ell m}(\theta, \phi)$  and where as usual  $k = |\mathbf{k}|$ .

This expansion can be rewritten with the use of the addition theorem for spherical harmonics, Eq. (15.71), which for present purposes we write in the form

$$P_{\ell}(\hat{\mathbf{r}} \cdot \hat{\mathbf{k}}) = P_{\ell}(\cos \gamma) = \frac{4\pi}{2\ell + 1} \sum_{m} Y_{\ell m}^{*}(\hat{\mathbf{k}}) Y_{\ell m}(\hat{\mathbf{r}}), \tag{22}$$

where  $\gamma$  is the angle between x and k. Then the expansion (21) becomes

$$e^{i\mathbf{k}\cdot\mathbf{x}} = \sum_{\ell=0}^{\infty} i^{\ell} (2\ell+1) j_{\ell}(kr) P_{\ell}(\cos\gamma). \tag{23}$$

Notice that if we take **k** to lie in the z-direction,  $\mathbf{k} = k\hat{\mathbf{z}}$ , then  $\gamma$  is the same as  $\theta$ , the usual spherical coordinate. In that case, the incident plane wave becomes

$$e^{i\mathbf{k}\cdot\mathbf{x}} = e^{ikr\cos\theta} = e^{ikz},\tag{24}$$

that is, it is independent of the azimuthal angle  $\phi$ , and the sum (23) is the expansion of the plane wave in Legendre polynomials of  $\cos \theta$ .

The spherical Bessel functions  $j_{\ell}$  and  $y_{\ell}$  are real, but complex linear combinations of them are often useful. These are the *spherical Hankel functions*, defined by

$$h_{\ell}^{(1)}(\rho) = j_{\ell}(\rho) + iy_{\ell}(\rho),$$

$$h_{\ell}^{(2)}(\rho) = j_{\ell}(\rho) - iy_{\ell}(\rho).$$
(25)

The two types of spherical Hankel functions are complex conjugates of each other,

$$h_{\ell}^{(1)}(\rho) = h_{\ell}^{(2)}(\rho)^*.$$
 (26)

These functions have particularly simple asymptotic forms when  $\rho \gg \ell$ , namely,

$$h_{\ell}^{(1)}(\rho) = \frac{e^{i[\rho - (\ell+1)\pi/2]}}{\rho},$$

$$h_{\ell}^{(2)}(\rho) = \frac{e^{-i[\rho - (\ell+1)\pi/2]}}{\rho},$$
(27)

which are equivalent to Eqs. (16.29)–(16.30). The phase  $e^{i(\ell+1)\pi/2} = i^{\ell+1}$  that makes these expressions look complicated is just a convention. Otherwise the asymptotic forms of the spherical Hankel functions are just  $e^{\pm i\rho}/\rho$ , corresponding in scattering problems to incoming and outgoing spherical waves.

## 6. Partial Waves

The exact solution of the Schrödinger equation  $\psi_{\mathbf{k}}(\mathbf{x})$  is decomposed into incident and scattered waves according to

$$\psi_{\mathbf{k}}(\mathbf{x}) = e^{i\mathbf{k}\cdot\mathbf{x}} + \psi_{\text{scatt}}(\mathbf{x}), \tag{28}$$

which is a version of Eq. (7). The angular dependence of the total wave  $\psi_{\mathbf{k}}(\mathbf{x})$  and that of the incident wave  $e^{i\mathbf{k}\cdot\mathbf{x}}$  are represented as linear combinations of  $Y_{\ell m}$ 's by Eqs. (19) and (21), respectively. Let us similarly decompose the angular dependence of the scattered wave by writing

$$\psi_{\text{scatt}}(\mathbf{x}) = \psi_{\text{scatt}}(r, \theta, \phi) = \sum_{\ell m} S_{\ell m}(r) Y_{\ell m}(\theta, \phi), \tag{29}$$

where the functions  $S_{\ell m}(r)$  are effectively the radial wave functions of the scattered wave,

$$S_{\ell m}(r) = \int d\Omega Y_{\ell m}^{*}(\theta, \phi) \,\psi_{\text{scatt}}(r, \theta, \phi). \tag{30}$$

Then Eq. (28) can be written

$$\sum_{\ell m} A_{\ell m} R_{k\ell}(r) Y_{\ell m}(\hat{\mathbf{r}}) = \sum_{\ell m} 4\pi i^{\ell} j_{\ell}(kr) Y_{\ell m}(\hat{\mathbf{r}}) Y_{\ell m}^{*}(\hat{\mathbf{k}}) + \sum_{\ell m} S_{\ell m}(r) Y_{\ell m}(\hat{\mathbf{r}}).$$
(31)

This equation is exact. But the  $Y_{\ell m}$ 's are linearly independent so Eq. (31) is equivalent to

$$A_{\ell m} R_{k\ell}(r) = 4\pi i^{\ell} j_{\ell}(kr) Y_{\ell m}^{*}(\hat{\mathbf{k}}) + S_{\ell m}(r).$$
(32)

Now we extract the leading asymptotic forms of the three terms in Eq. (32). As for the total wave function, we need the asymptotic form of  $R_{k\ell}(r)$ . We argue that if V(r) falls off rapidly enough then at large r it can be ignored and  $R_{k\ell}(r)$  must be a linear combination of the free particle solutions

 $j_{\ell}(kr)$  and  $y_{\ell}(kr)$ . Precisely how fast V(r) must fall off for this to be true is examined in Sec. 7. Actually, it is more convenient to use the spherical Hankel functions and to write

$$R_{kl}(r) \sim B_{\ell} h_{\ell}^{(1)}(kr) + B_{\ell}^* h_{\ell}^{(2)}(kr),$$
 (33)

where  $B_{\ell}$  and  $B_{\ell}^*$  are the coefficients of the linear combination. Here we are assuming that the exact radial wave function  $R_{kl}(r)$  has been chosen to be real, as we can do since the radial wave equation is a real equation. This means that the coefficients of the linear combination of the spherical Hankel functions must be complex conjugates of each other, as shown, because of Eq. (26). Thus the phase of  $R_{k\ell}(r)$  is specified to within a  $\pm$  sign, but its normalization has not been specified. The right-hand side of Eq. (33) is a good approximation to the left-hand side when r is large enough that the potential can be neglected.

We now break  $B_{\ell}$  into its magnitude and phase,

$$B_{\ell} = |B_{\ell}| e^{i\delta_{\ell}},\tag{34}$$

and absorb the magnitude  $|B_{\ell}|$  into the normalization of  $R_{k\ell}(r)$ . This fixes the normalization of the radial wave functions; they are now determined to within a  $\pm$  sign. Then we have

$$R_{k\ell}(r) \sim e^{i\delta_{\ell}} h_{\ell}^{(1)}(kr) + e^{-i\delta_{\ell}} h_{\ell}^{(2)}(kr),$$
 (35)

or, if we replace the Hankel functions by their asymptotic forms (27), valid when  $kr \gg \ell$ ,

$$R_{k\ell}(r) \sim \frac{1}{k_r} \left\{ e^{i[kr - (\ell+1)\pi/2 + \delta_{\ell}]} + e^{-i[kr - (\ell+1)\pi/2 + \delta_{\ell}]} \right\}.$$
 (36)

This is the asymptotic form of the radial wave functions; it is parameterized by the *phase shifts*  $\delta_{\ell}$ , which play a fundamental role in central force scattering.

As for the incident wave in Eq. (32), it is a plane wave whose radial wave functions are the Bessel functions  $j_{\ell}(kr)$ . These have the asymptotic form

$$j_{\ell}(kr) = \frac{1}{2} \left[ h_{\ell}^{(1)}(kr) + h_{\ell}^{(2)}(kr) \right] \sim \frac{1}{2kr} \left\{ e^{i[kr - (\ell+1)\pi/2]} + e^{-i[kr - (\ell+1)\pi/2]} \right\},\tag{37}$$

which follows from Eqs. (25) and (27).

Finally, for the scattered wave in Eq. (32) we use Eq. (8) in Eq. (30) to obtain

$$S_{\ell m}(r) \sim \frac{e^{ikr}}{r} f_{\ell m},$$
 (38)

where the  $f_{\ell m}$  are the expansion coefficients when the scattering amplitude is written as a linear combination of  $Y_{\ell m}$ 's,

$$f(\theta,\phi) = \sum_{\ell m} f_{\ell m} Y_{\ell m}(\theta,\phi). \tag{39}$$

Altogether, when we take the leading asymptotic form of all three terms in Eq. (32) we obtain

$$A_{\ell m} \frac{1}{kr} \left\{ e^{i[kr - (\ell+1)\pi/2 + \delta_{\ell}]} + e^{-i[kr - (\ell+1)\pi/2 + \delta_{\ell}]} \right\}$$

$$= 4\pi i^{\ell} \frac{1}{2kr} \left\{ e^{i[kr - (\ell+1)\pi/2]} + e^{-i[kr - (\ell+1)\pi/2]} \right\} Y_{\ell m}^{*}(\hat{\mathbf{k}}) + \frac{e^{ikr}}{r} f_{\ell m}.$$
(40)

All three terms go as 1/r at large r, so we have obtained the leading asymptotic term of the entire equation (32), and this is exact. The result is a linear combination of incoming and outgoing spherical waves, which are linearly independent; notice that that the scattered wave only has an outgoing part (this is the boundary condition imposed by the physics).

Working first with the coefficients of the incoming wave  $e^{-ikr}/r$  we see that we can solve for the coefficients  $A_{\ell m}$  in terms of the phase shifts. We find

$$A_{\ell m} = 4\pi i^{\ell} \frac{1}{2} Y_{\ell m}^{*}(\hat{\mathbf{k}}) e^{i\delta_{\ell}}. \tag{41}$$

Then using this in the outgoing part, we can solve for the expansion coefficients  $f_{\ell m}$  of the scattering amplitude. In the algebra it helps to notice that

$$i^{\ell} e^{-i(\ell+1)\pi/2} = \frac{1}{i} \quad \text{and} \quad \frac{e^{2i\delta_{\ell}} - 1}{2i} = e^{i\delta_{\ell}} \sin \delta_{\ell}. \tag{42}$$

Thus we find

$$f_{\ell m} = \frac{4\pi}{k} e^{i\delta_{\ell}} \sin \delta_{\ell} Y_{\ell m}^{*}(\hat{\mathbf{k}}), \tag{43}$$

or,

$$f(\theta,\phi) = \frac{4\pi}{k} \sum_{\ell m} e^{i\delta_{\ell}} \sin \delta_{\ell} Y_{\ell m}(\hat{\mathbf{r}}) Y_{\ell m}^{*}(\hat{\mathbf{k}}). \tag{44}$$

This is the desired result, which expresses the scattering amplitude in terms of the phase shifts  $\delta_{\ell}$ . Another version is obtained with the help of the addition theorem (22),

$$f(\theta) = \frac{1}{k} \sum_{\ell=0}^{\infty} (2\ell + 1)e^{i\delta_{\ell}} \sin \delta_{\ell} P_{\ell}(\cos \theta), \tag{45}$$

where we have set  $\mathbf{k} = k\hat{\mathbf{z}}$  so that  $\hat{\mathbf{r}} \cdot \hat{\mathbf{k}} = \cos \theta$ , where  $\theta$  is the usual spherical angle. When  $\mathbf{k} = k\hat{\mathbf{z}}$  it is obvious that the whole central force scattering problem is symmetric under rotations about the z-axis so f must be a function of  $\theta$  alone. Expressions (44) or (45) are the partial wave expansion of the scattering amplitude. We shall discuss this result momentarily, but first we examine an important point that we have glossed over so far.

# 7. Asymptotic Form of the Radial Wave Functions

In the derivation of the partial wave expansion we assumed [see Eq. (33)] that if the potential dies off rapidly enough with distance, then at large distances the radial eigenfunctions approach linear combinations of free particle solutions. Let us now examine how rapidly V(r) must die off for this to be true.

As explained in Notes 16, the radial eigenfunction  $R_{k\ell}(r)$  is related to an alternative version of the radial eigenfunction  $u_{k\ell}(r) = rR_{k\ell}(r)$ , which satisfies version two of the radial Schrödinger equation, Eq. (16.11). (Function u was called f in Notes 16.) For our present purposes we rearrange these two versions of the radial Schrödinger equation as

$$\frac{1}{r^2}\frac{d}{dr}\left(r^2\frac{dR_{k\ell}}{dr}\right) + k^2R_{k\ell}(r) = W(r)R_{k\ell}(r) \tag{46}$$

and

$$u_{k\ell}''(r) + k^2 u_{k\ell}(r) = W(r) u_{k\ell}(r), \tag{47}$$

where

$$W(r) = \frac{\ell(\ell+1)}{r^2} + \frac{2m}{\hbar^2}V(r). \tag{48}$$

Since both the true potential and the centrifugal potential go to zero as  $r \to \infty$ , the function W(r) also goes to zero as  $r \to \infty$ . So as a first stab at analyzing the asymptotic form of  $u_{k\ell}(r)$ , let us neglect W(r) altogether on the right hand side of the radial Schrödinger equation (47). Then the solution for  $u_{k\ell}(r)$  is simply a linear combination of the exponentials  $e^{\pm ikr}$ , and R(r) is a linear combination of  $e^{\pm ikr}/r$ , as we assumed in Eq. (36).

To take into account the effects of W(r), let us write the solution of Eq. (47) as

$$u_{k\ell}(r) = e^{g(r) \pm ikr},\tag{49}$$

where g(r) is a correction that will account for the effects of the function W(r). If we can show that  $g(r) \to 0$  as  $r \to \infty$ , then the correct asymptotic forms of  $u_{k\ell}(r)$  will be a linear combination of the solutions  $e^{\pm ikr}$ . That is, the function W(r) on the right hand side will make no difference in the asymptotic form of the solution. Substituting Eq. (49) into the radial Schrödinger equation (47), we obtain an equation for g,

$$g'' + g'^2 \pm 2ikg' = W(r). \tag{50}$$

This is rigorously equivalent to Eq. (47).

Now we consider the behavior of W(r) as  $r \to \infty$ . If the true potential V(r) goes to zero faster than  $1/r^2$ , then W(r) is dominated by the centrifugal potential and also goes to zero as  $1/r^2$ . We assume  $\ell \neq 0$ , so the centrifugal potential does not vanish. If the true potential goes to zero more slowly than  $1/r^2$ , let us assume that it does so as a power law,  $1/r^p$ , where 1 . This excludes the case of the Coulomb potential, for which <math>p = 1, but it approaches the Coulomb potential as  $p \to 1$ . Then W(r) has the asymptotic form,

$$W(r) \sim \frac{a}{r^p},$$
 (51)

where 1 and <math>a is a constant. The case  $\ell = 0$  can be handled as a special case, but it does not change any of the conclusions that we shall draw.

We are interested in solving Eq. (50) in the asymptotic region when W has the asymptotic behavior (51). Let us assume that g is asymptotically given by a power law,

$$g(r) \sim \frac{b}{r^s},$$
 (52)

where b is another constant and s>0. Then the three terms on the left hand side of Eq. (50) go as  $1/r^{s+2}$ ,  $1/r^{2s+2}$  and  $1/r^{s+1}$ , in that order. The third term dominates, so to leading order we have s=p-1, so that  $0< s \le 1$ , and the power law ansatz for g has a solution. That is,  $g(r) \sim b/r^{p-1}$ ,

g(r) does go to zero as  $r \to \infty$ , and thus the asymptotic form of  $u_{k\ell}(r)$  is a linear combination of  $e^{\pm ikr}$ .

But in the case of the Coulomb potential,  $W(r) \sim a/r$ , that is, with p = 1. Then taking the dominant term in Eq. (50), we have

$$\pm 2ikg'(r) = \frac{a}{r},\tag{53}$$

or,

$$g(r) = \mp \frac{ia}{2k} \ln(kr). \tag{54}$$

The logarithm does not go to zero as  $r \to \infty$ , in fact, it increases without bound (although very slowly). Thus, in the case of the Coulomb potential, the asymptotic form of the radial wave function is

$$u_{k\ell}(r) \sim \exp\left\{\pm i\left[kr - \frac{a}{2k}\ln(kr)\right]\right\}.$$
 (55)

The Coulomb potential gives rise to long range, logarithmic phase shifts that do not approach the free particle phases as  $r \to \infty$ .

In summary, if the potential V(r) goes to zero faster than 1/r, then the asymptotic form of the radial wave function is given by the linear combinations  $e^{\pm ikr}$  (for  $u_{k\ell}$ ) or by  $e^{\pm ikr}/r$  (for  $R_{k\ell}$ ), the latter of which is what we assumed in the derivation of the partial wave expansion (44) or (45). For the rest of these notes we will assume that V(r) does satisfy this condition, thereby excluding the Coulomb potential.

By the way, the derivation of Eq. (32) did not make any assumption about the asymptotic behavior of  $S_{kl}(r)$ , but now we have shown that if  $V(r) \to 0$  faster than 1/r then  $R_{kl}(r) \sim e^{\pm ikr}/r$ , so in that case  $S_{kl}(r)$  has the same behavior. Then if we choose outgoing boundary conditions we obtain the form (8) for the scattered wave. In the case of the Coulomb potential, however, the form (8) of the scattered wave is not correct. Many books just write down the form (8) of the scattered wave as if it were obvious; if that were so, the fact that it is not always valid and the conditions of valididy would be obvious, too.

#### 8. Partial Wave Expansion of the Cross Section

We return to the partial wave expansion of the scattering amplitude, Eq. (44) or (45), which give the scattering amplitude as a linear combination of spherical harmonics or Legendre polynomials. Squaring the scattering amplitude we obtain the differential cross section,

$$\frac{d\sigma}{d\Omega}(\theta,\phi) = \left(\frac{4\pi}{k}\right)^2 \sum_{\ell m\ell'm'} e^{i(\delta_{\ell} - \delta_{\ell'})} \sin \delta_{\ell} \sin \delta_{\ell'} Y_{\ell m}^*(\hat{\mathbf{k}}) Y_{\ell'm'}(\hat{\mathbf{k}}) Y_{\ell m}(\hat{\mathbf{r}}) Y_{\ell'm'}^*(\hat{\mathbf{r}}), \tag{56}$$

or, with  $\mathbf{k} = k\hat{\mathbf{z}}$ ,

$$\frac{d\sigma}{d\Omega}(\theta) = \frac{1}{k^2} \sum_{\ell\ell'} (2\ell+1)(2\ell'+1)e^{i(\delta_{\ell}-\delta_{\ell'})} \sin \delta_{\ell} \sin \delta_{\ell'} P_{\ell}(\cos \theta) P_{\ell'}(\cos \theta). \tag{57}$$

These expressions have cross terms that do not simplify, but which show up experimentally as oscillations in the angular dependence of the differential cross section. Some of these may be seen in Figs. 8 or 9.

On the other hand, when we integrate over all angles to obtain the total cross section, the cross terms integrate to zero. This is easiest to see in the form (56), due to the orthonormality of the  $Y_{\ell m}$ 's. The result is

$$\sigma = \int d\Omega \frac{d\sigma}{d\Omega} = \left(\frac{4\pi}{k}\right)^2 \sum_{\ell m} \sin^2 \delta_\ell Y_{\ell m}^*(\hat{\mathbf{k}}) Y_{\ell m}(\hat{\mathbf{k}}), \tag{58}$$

or, with another application of the addition theorem (and noting that  $\hat{\mathbf{k}} \cdot \hat{\mathbf{k}} = 1$  and  $P_{\ell}(1) = 1$ ),

$$\sigma = \frac{4\pi}{k^2} \sum_{\ell=0}^{\infty} (2\ell + 1) \sin^2 \delta_{\ell}. \tag{59}$$

This is the partial wave expansion of the total cross section.

### 9. The Phase Shifts $\delta_{\ell}$

These results show the importance of the phase shifts  $\delta_{\ell}$ , which determine the coefficients of the angular expansion of the scattering amplitude and cross section. We now make some comments on the properties and intuitive meaning of these phase shifts.

The phase shifts are defined by the asymptotic form of the radial wave functions (36) and are determined by the potential V(r). That is,  $\delta_{\ell}$  is the phase of the incoming or outgoing part of the exact radial wave function, relative to that of a free particle. Thus, the phase shifts vanish for a free particle. The phase shifts depend on  $\ell$  because the radial wave function does so. They depend on the energy, too, and if we wish to emphasize this we can write  $\delta_{\ell}(E)$ . Since by our analysis the phase of the radial wave is determined to within a  $\pm$  sign, the phase shift  $\delta_{\ell}$  is determined to within an integer multiple of  $\pi$ .

For an intuitive view of the phase shifts we can imagine launching spherical waves inward at the scatterer from a large distance, allowing them to converge on the origin and then bounce back. The wave can be given an angular modulation proportional to a  $Y_{\ell m}$  to give it a dependence on  $\ell$ . Then we will find a certain phase shift in the reflected wave compared to the incident wave. We can do this both for the free particle and the one with a potential; the difference in the phase shifts in the two cases is  $\delta_{\ell}$ .

As a more practical matter, the phase shifts can be determined by solving the radial wave equation somehow and then comparing the asymptotic form of the solution with the form (36) to get the phase shifts. In some cases this can be done analytically, and it can also be done numerically. For the latter one simply chooses regular boundary conditions for R(r) at r = 0, and then integrates the radial Schrödinger equation outward numerically. When a radius is reached where the potential is negligible a comparison of the numerical solution to Eq. (35) gives the phase shifts. Another approach is to use WKB theory; since the radial wave equation is one-dimensional, WKB theory

can be very effective in obtaining information about the radial wave function. Some aspects of this approach were explored in Prob. 7.4.

WKB theory leads easily to some general conclusions about the phase shifts. Suppose we have a well localized potential, for example, one that dies off exponentially with r such as the Yukawa potential (33.116). Let a be a measure of the range of the potential. Then the centrifugal potential, which only falls off as 1/r<sup>2</sup> , will dominate for large r if ℓ > 0. Thus for a given E, if ℓ is big enough the radial turning point in the centrifugal potential will lie outside the range a of the true potential, and the radial wave function will be able to reach the true potential only by tunneling through the centrifugal potential to reach it. The wave function decays exponentially in the classically forbidden region, so for such large ℓ values the true potential will have only an exponentially small influence on the wave function, which will be nearly the same as a free particle radial wave function of the same value of ℓ and E. Thus for such large ℓ values we expect the phase shifts to be small, and to decay exponentially with ℓ as ℓ increases.

To estimate the ℓ value beyond which such behavior holds, we set the nominal turning point in the centrifugal potential to the range of the true potential, that is,

$$E = \frac{\hbar^2 k^2}{2m} = \frac{\ell(\ell+1)\hbar^2}{2ma^2}.$$
 (60)

If we ignore the difference between ℓ and ℓ + 1, this gives the estimate,

$$\ell_{\text{cutoff}} = ka,$$
 (61)

beyond which the phase shifts decay exponentially toward δ<sup>ℓ</sup> = 0. In summary, for a well localized potential of range a, an estimate of the number of terms that contribute significantly to the partial wave expansion is ka.

## 10. Hard Sphere Scattering

As an example of the partial wave expansion, let us consider scattering from a hard sphere. The potential is

$$V(r) = \begin{cases} \infty, & r < a, \\ 0, & r > a, \end{cases}$$
 (62)

where a is the radius of the sphere. In the region r > a the solution is a linear combination of free particle solutions, which we write as

$$R_{kl}(r) = B_{\ell} h_{\ell}^{(1)}(kr) + B_{\ell}^{*} h_{\ell}^{(2)}(kr), \tag{63}$$

which is the same as Eq. (33) except for the hard sphere it is exact and Eq. (33) was only an asymptotic form. As in the analysis of Eq. (33) we write B<sup>ℓ</sup> = |Bℓ|e iδ<sup>ℓ</sup> and absorb |Bℓ| into the normalization of the Rkℓ(r), so that δ<sup>ℓ</sup> are the phase shifts.

These are determined by imposing the boundary condition that Rkl(r) vanish at the surface of the sphere,

$$R_{kl}(a) = e^{i\delta_{\ell}} h_{\ell}^{(1)}(ka) + e^{-i\delta_{\ell}} h_{\ell}^{(2)}(ka) = 0,$$
(64)

or,

$$e^{2i\delta_{\ell}} = -\frac{h_{\ell}^{(2)}(ka)}{h_{\ell}^{(1)}(ka)}. (65)$$

This can be solved for the  $\delta_{\ell}$ , which give us the scattering amplitude and differential cross section. We will consider two limiting cases, in which the limiting forms of the spherical Bessel functions can be used.

#### 11. The limit $ka \ll 1$

In the first case we assume  $ka \ll 1$ . This is equivalent to  $\lambda \gg a$ , where  $\lambda = 2\pi/k$  is the wavelength of the incident waves, that is, the scatterer is much smaller than a wavelength. The small argument forms of  $j_{\ell}$  and  $y_{\ell}$ , Eqs. (16.27) and (16.28), show that in this case  $y_{\ell}(ka)$  is large and negative and  $j_{\ell}(ka)$  is small and positive. We write Eq. (65) as

$$e^{2i\delta_{\ell}} = -\frac{j_{\ell}(ka) - iy_{\ell}(ka)}{j_{\ell}(ka) + iy_{\ell}(ka)} = \frac{1 + i(j_{\ell}/y_{\ell})}{1 - i(j_{\ell}/y_{\ell})} = 1 + 2i(j_{\ell}/y_{\ell}) = e^{2i(j_{\ell}/y_{\ell})},$$
(66)

valid when  $j_{\ell}(ka)/y_{\ell}(ka)$  is small, as here. Thus we find, to a good approximation,

$$\delta_{\ell} = -\frac{(ka)^{2\ell+1}}{(2\ell-1)!!(2\ell+1)!!}.$$
(67)

This shows that not only is the lowest phase shift  $\delta_0$  small, the higher phase shifts  $\delta_\ell$  for  $\ell \geq 1$  are even smaller. In this limit

$$\delta_0 = -ka,\tag{68}$$

and the series (45) for the scattering amplitude is dominated by the single term  $\ell = 0$ . Thus we have

$$f(\theta) = \frac{1}{k}(-ka) = -a, \qquad ka \ll 1, \tag{69}$$

since  $e^{i\delta_{\ell}} \approx 1$  and  $P_0(\cos \theta) = 1$ . We see that the differential cross section is independent of angle,

$$\frac{d\sigma}{d\Omega} = a^2,\tag{70}$$

and the total cross section is

$$\sigma = \int d\Omega \, \frac{d\sigma}{d\Omega} = 4\pi a^2. \tag{71}$$

The total cross section is four times as large as the geometrical cross-sectional area of the small sphere. The classical cross section is just this cross-sectional area,  $\pi a^2$ , but the regime  $\lambda \gg a$  is the one in which we expect classical mechanics to be a poor approximation to quantum mechanics, so we should not be surprised by the difference.

# 12. s-wave Scattering

When the partial wave ℓ = 0 dominates the expansion of the scattering amplitude, we speak of s-wave scattering. The scattered wave is isotropic and has an equal intensity in all directions, including the forward direction. Since a ≪ λ the sphere is too small to create a shadow; instead, the incident wave effectively wraps all the way around the scatterer. As we will see later, s-wave scattering applies to any localized potential whose characteristic size a satisfies a ≪ λ, that is, ka ≫ 1 (not just hard spheres). The fundamental reason was given in Sec. 9: for ℓ > 0 the radial wave functions must tunnel through the centrifugal potential to reach the scatterer, and the tunneling is deeper the higher the ℓ value. We see from Eq. (67) that when ka ≪ 1 the phase shifts are indeed an exponentially decreasing function of ℓ (in fact, including the factorials, even faster than exponential).

There are many physical examples in which s-wave scattering is important. For example, a Bose-Einstein condensate is a dilute gas of atoms at a temperature at which the de Broglie wavelength λ of the atoms due to their thermal motion is larger than the interparticle separation. Since the gas is dilute, the interparticle separation in turn is much larger than the atomic size, call it a, so we have λ ≫ a, or ka ≪ 1. Thus the interactions of the atoms with one another is described by s-wave scattering, and scattering of atoms by atoms, in all its complexity, is described by a single parameter, which is the phase shift δ0.

In s-wave scattering any two potentials that give the same phase shift δ<sup>0</sup> will have the same effect. Therefore in theoretical models the exact potential can be replaced by a simpler one, as long as the phase shift is the same. Delta function potentials are popular for this purpose, which explains their appearance in the models of Bose-Einstein condensates such as the Gross-Pitaevski equation (for which see Prob. 31.3).

When light scatters from particles that are much smaller than the wavelength, for example, when optical radiation is scattered by atoms in a gas, is this s-wave scattering, and is the scattered wave isotropic? (This is a tricky question.) The answer is no, because electromagnetic waves are vector waves, not scalar waves as we have been discussing in these notes. In the case of electromagnetic waves, the scattering when ka ≪ 1 is dominated by dipole radiation, which has a nontrivial angular dependence. Electromagnetic waves have no monopole radiation (that is, s-wave radiation), and the next higher term in the multipole series is the first one to appear. It is the one that dominates at small ka.

Similarly, gravitational radiation, which has received much attention since its actual detection a few years ago, has neither a monopole nor a dipole term, rather the first multipole to appear is the quadrupole.

# 13. The Limit ka ≫ 1

The second case we consider is the opposite extreme, ka ≫ 1, that is, λ ≪ a. In this case the

sphere is much larger than a wavelength. Now there are many ℓ values that contribute to the partial wave sum. For small ℓ, for which ℓ ≪ ka, we can use the asymptotic forms (27) in Eq. (65). We find

$$e^{2i\delta_{\ell}} = -e^{-2i[ka - (\ell+1)\pi/2]},\tag{72}$$

or, with −1 = e −iπ ,

$$\delta_{\ell} = \frac{\ell \pi}{2} - ka. \tag{73}$$

This says that δ<sup>ℓ</sup> advances by π/2 when ℓ increases by 1, but this is an approximation that is only valid when ℓ ≪ ka. According to Eq. (61) we need to sum the partial wave expansion out to ℓ ≈ ka, after which we expect the terms of the series to rapidly approach zero. Actually the increment in δℓ, which is indeed π/2 when ℓ ≪ ka, gradually decreases as ℓ climbs toward ka, after which it rapidly goes to zero. This behavior is illustrated in some numerical examples in Figs. 4 and 5.

![](_page_18_Figure_7.jpeg)

![](_page_18_Figure_8.jpeg)

Fig. 4. Phase shifts in hard sphere scattering. The phase shifts δ<sup>ℓ</sup> are represented as points on a circle with plane polar angle δℓ. The radius of the circle grows as ℓ increases, to keep the points from getting mixed up with each other as they orbit the circle. Some points are labeled with their ℓ values. The phase shifts increase with decreasing increment as ℓ increases, until ℓ ≈ ka, whereupon δ<sup>ℓ</sup> → 0. Plot is for ka = 10.

Fig. 5. Same as Fig. 4 except ka = 20.

The cutoff at ℓ ≈ ka was explained earlier in terms of WKB theory; a more intuitive explanation is illustrated in Fig. 6. We imagine particles of fixed energy E = ¯h 2 k <sup>2</sup>/2m emitted in various directions from a point on the surface of a sphere of radius a. These represent the waves scattered by the sphere. The angular momentum of the particles depends on the direction of emission; its minimum value is L = 0 when the particles are launched in the radial direction, and its maximum value L = pa = ¯hka is when the particles are launched tangentially to the sphere. The maximum value of L corresponds to a maximum angular momentum quantum number, ℓ = L/¯h = ka. The same reasoning works for any short-range potential with an effective range of a; the partial wave expansion cuts off near ℓ ≈ ka.

![](_page_19_Picture_2.jpeg)

Fig. 6. Particles of fixed energy are launched in various directions from a point on the surface of a sphere. The maximum angular momentum is achieved when the direction is tangent to the sphere at the point of launch.

We can use the behavior of the phase shifts to estimate the total cross section in the limit ka ≫ 1. While the points representing the δ<sup>ℓ</sup> are orbiting their circle as in Figs. 4 and 5, the average value of sin<sup>2</sup> δ<sup>ℓ</sup> is 1/2. Since the series cuts off near ℓ ≈ ka, the total cross section (59) can be estimated by

$$\sigma \approx \frac{4\pi}{k^2} \sum_{\ell=0}^{ka} (2\ell+1) \frac{1}{2}.$$
 (74)

Using the sum

$$\sum_{\ell=0}^{L} (2\ell+1) = (L+1)^2, \tag{75}$$

we obtain the estimate

$$\sigma \approx \frac{4\pi}{k^2} \frac{(ka)^2}{2} = 2\pi a^2,\tag{76}$$

where we ignore the difference between ka and ka + 1. We see that the cross section is twice the classical value in the case ka ≫ 1.

These conclusions are confirmed by detailed calculations, which show that σ → 4πa<sup>2</sup> as ka → 0 and σ → 2πa<sup>2</sup> as ka → ∞. See Fig. 7.

If we think of the classical limit as one in which the de Broglie wavelength λ is much smaller than the scale of the potential, then it is surprising that the limit σ → 2πa<sup>2</sup> as ka → ∞ since this is twice the classical cross section, πa<sup>2</sup> . To see how this "extra" cross-section is distributed in angle we refer to Fig. 8, a plot of the differential cross section for various values of ka.

Figure 8 shows that for small values of ka, the differential cross section is nearly independent of angle, confirming that we have s-wave scattering. The cross section dσ/dΩ is nearly a 2 in this range, confirming Eq. (70). As ka increases, dσ/dΩ decreases at large angles toward the classical value, but at small angles a forward peak rises up, growing narrower and higher. At the edge of forward peak there also arise oscillations. Figure 9 is a similar plot except that dσ/dΩ has been multiplied by sin θ, which makes the integrated cross section proportional to area under the curve.

![](_page_20_Figure_2.jpeg)

Fig. 7. Total cross section σ as a multiple of πa<sup>2</sup> for hard sphere scattering as a function of ka. The total cross section has the limits σ → 4πa<sup>2</sup> as ka → 0 and σ → 2πa<sup>2</sup> as ka → ∞.

![](_page_20_Figure_4.jpeg)

Fig. 8. Differential cross section in hard sphere scattering, as a multiple of a 2 . Curves are labeled by the value of ka, which increases from 0.1 to 8. Scattering angle θ is measured in degrees.

Fig. 9. Same as Fig. 8 except multiplied by sin θ. Area under curves in a given angle range is proportional to the total cross section in that range.

This makes it easier to see that the total cross section in the forward peak is about the same as the classical cross section. In fact, detailed calculations (see Prob. 1) show that both the forward peak and the classical cross section contribute πa<sup>2</sup> to the total. The "extra" cross section comes entirely from the forward peak.

This peak is due to diffraction. As the waves pass by the edge of the sphere they are bent in an inward direction, that is, the direction necessary to close in the shadow behind the sphere. Diffraction theory shows that if we move far enough downstream, the shadow is completely filled by diffracted waves. Of course the differential cross section is defined in the limit  $r \to \infty$ , so there is no shadow in the differential cross section. Diffraction causes the direction of the waves to change from the incident direction, and so must be counted as part of the scattering.

## 14. The Optical Theorem

The optical theorem is an exact relationship between the total cross section  $\sigma$  and the scattering amplitude f. In the context of potential scattering that we have considered in these notes, the optical theorem is

$$\sigma = \frac{4\pi}{k} \operatorname{Im} f(0), \tag{77}$$

where f(0) refers to the scattering amplitude in the forward direction.

The optical theorem is trivial to prove in the case of scattering by central force potentials. We place the z-axis along the direction of the beam so that the usual polar angle  $\theta$  is the scattering angle. Then Eq. (45) implies

$$\frac{4\pi}{k} \operatorname{Im} f(0) = \frac{4\pi}{k^2} \operatorname{Im} \sum_{\ell=0}^{\infty} (2\ell+1) e^{i\delta_{\ell}} \sin \delta_{\ell} P_{\ell}(1) = \frac{4\pi}{k^2} \sum_{\ell=0}^{\infty} (2\ell+1) \sin^2 \delta_{\ell} = \sigma, \tag{78}$$

where we have used Eqs. (59) and (15.75). This proof is straightforward but it gives no insight into what the theorem means.

The theorem (77) actually applies to scattering by any potential  $V(\mathbf{x})$  that dies off faster than 1/r as  $r \to \infty$ , so that the asymptotic wave function is

$$\psi(\mathbf{x}) \sim e^{i\mathbf{k}\cdot\mathbf{x}} + \frac{e^{ikr}}{r} f(\theta, \phi),$$
 (79)

as indicated by Eqs. (7) and (8). That is, we need not assume that the potential is rotationally invariant. The two terms in Eq. (79) are the incident and scattered waves, respectively.

Since the wave function  $\psi(\mathbf{x})$  is a solution of the time-independent Schrödinger equation, the current

$$\mathbf{J} = \operatorname{Re} \psi^*(\mathbf{x}) \left( -\frac{i\hbar \nabla}{m} \right) \psi(\mathbf{x})$$
 (80)

satisfies  $\nabla \cdot \mathbf{J} = 0$ , so by Stokes' theorem the integral of  $\mathbf{J}$  over any closed surface vanishes. See Eqs. (5.55)–(5.57). We will integrate  $\mathbf{J}$  over a large sphere of radius r centered at the origin of the coordinates, which we assume is inside the region occupied by the potential as in Fig. 2. We will take the limit  $r \to \infty$ , so that the asymptotic form (79) of the wave function can be used.

Thus the asymptotic form of the current is

$$\mathbf{J} \sim \operatorname{Re}\left[e^{-i\mathbf{k}\cdot\mathbf{x}} + \frac{e^{-ikr}}{r}f^{*}(\theta,\phi)\right]\left(-\frac{i\hbar\nabla}{m}\right)\left[e^{i\mathbf{k}\cdot\mathbf{x}} + \frac{e^{ikr}}{r}f(\theta,\phi)\right]$$

$$= v\operatorname{Re}\left[e^{-ikr\cos\theta} + \frac{e^{-ikr}}{r}f^{*}(\theta,\phi)\right]\left[\hat{\mathbf{z}}e^{ikr\cos\theta} + \hat{\mathbf{r}}\frac{e^{ikr}}{r}f(\theta,\phi)\right],$$
(81)

where we have set  $\mathbf{k} = k\hat{\mathbf{z}}$  and  $v = \hbar k/m$  and retained only the leading term in the gradient of the scattered wave, as in Eq. (14). The neglected terms will not contribute to the integral over the sphere when we take the limit  $r \to \infty$ .

The current is quadratic in the wave function  $\psi(\mathbf{x})$ , so in addition to the incident current and scattered current there is a contribution coming from the cross terms, which represent the interference between the incident wave and the scattered wave. We write

$$\mathbf{J} = \mathbf{J}_{\text{inc}} + \mathbf{J}_{\text{scatt}} + \mathbf{J}_{x},\tag{82}$$

where  $J_x$  is the interference current. By Stokes' theorem we have

$$\int_{\text{sphere}} \mathbf{J} \cdot d\mathbf{a} = 0, \tag{83}$$

where  $d\mathbf{a} = r^2 \hat{\mathbf{r}} d\Omega$  is the area element of the sphere.

![](_page_22_Picture_10.jpeg)

Fig. 10. The incident current passes straight through the sphere and produces no net flux across its surface.

![](_page_22_Picture_12.jpeg)

Fig. 11. The scattered current produces a net flux of particles leaving the sphere, proportional to the total cross section.

The incident current is

$$\mathbf{J}_{\text{inc}} = v \operatorname{Re} \left[ e^{-ikr\cos\theta} \right] \left[ \hat{\mathbf{z}} e^{ikr\cos\theta} \right] = v \hat{\mathbf{z}}, \tag{84}$$

It is a constant vector whose integral over sphere vanishes,

$$\int_{\text{sphere}} \mathbf{J}_{\text{inc}} \cdot d\mathbf{a} = 0, \tag{85}$$

as is obvious from Fig. 10.

The scattered current was already computed in Sec. 3. It is

$$\mathbf{J}_{\text{scatt}} = v \operatorname{Re} \left[ \frac{e^{-ikr}}{r} f^*(\theta, \phi) \right] \left[ \hat{\mathbf{r}} \frac{e^{ikr}}{r} f(\theta, \phi) \right] = v \frac{\hat{\mathbf{r}}}{r^2} |f(\theta, \phi)|^2, \tag{86}$$

whose integral over the sphere is

$$\int_{\text{sphere}} \mathbf{J} \cdot d\mathbf{a} = v \int_{\text{sphere}} |f(\theta, \phi)|^2 d\Omega = \sigma v, \tag{87}$$

where  $\sigma$  is the total cross section and where we have used Eq. (17). The scattered wave gives a net outgoing flux, proportional to the cross section, which is no surprise. See Fig. 11.

Therefore the interference current must provide a net inward flux that cancels the scattered flux. From Eq. (81) we have

$$\mathbf{J}_{\mathbf{x}} = \frac{v}{r} \operatorname{Re} \left[ \hat{\mathbf{z}} e^{-ikr(1-\cos\theta)} f^{*}(\theta,\phi) + \hat{\mathbf{r}} e^{ikr(1-\cos\theta)} f(\theta,\phi) \right]. \tag{88}$$

But the real part of a complex number is the same as the real part of its complex conjugate, so we can replace the first term in Eq. (88) by its complex conjugate to obtain

$$\mathbf{J}_{\mathbf{x}} = \frac{v}{r} \operatorname{Re} \left[ (\hat{\mathbf{z}} + \hat{\mathbf{r}}) e^{ikr(1 - \cos \theta)} f(\theta, \phi) \right]. \tag{89}$$

Now the interference flux is

$$\int_{\text{sphere}} \mathbf{J}_{\mathbf{x}} \cdot d\mathbf{a} = vr \operatorname{Re} \int_{0}^{2\pi} d\phi \int_{0}^{\pi} \sin\theta \, d\theta \, (1 + \cos\theta) \, e^{ikr(1 - \cos\theta)} \, f(\theta, \phi). \tag{90}$$

We wish to evaluate this integral in the limit  $r \to \infty$ , which is slightly delicate. The prefactor of r would tend to make the integral diverge, but the factor  $e^{ikr(1-\cos\theta)}$  in the integrand oscillates ever more rapidly in  $\theta$  as r gets larger, thereby chopping up the integrand and tending to make the integral vanish. To clarify the competition between these tendencies, we integrate by parts in  $\theta$ , obtaining

$$\int_{\text{sphere}} \mathbf{J}_{\mathbf{x}} \cdot d\mathbf{a} = vr \operatorname{Re} \int_{0}^{2\pi} d\phi \int_{0}^{\pi} d\theta \frac{1}{ikr} \left[ \frac{d}{d\theta} e^{ikr(1-\cos\theta)} \right] (1+\cos\theta) f(\theta,\phi) 
= \frac{v}{k} \operatorname{Re} \int_{0}^{2\pi} d\phi \left\{ -ie^{ikr(1-\cos\theta)} \left( 1+\cos\theta \right) f(\theta,\phi) \Big|_{\theta=0}^{\theta=\pi} \right. 
+ i \int_{0}^{\pi} d\theta \, e^{ikr(1-\cos\theta)} \frac{d}{d\theta} \left[ (1+\cos\theta) f(\theta,\phi) \right] \right\}.$$
(91)

The integration by parts has eliminated the prefactor of r, so now the final integral oscillates itself to death as  $r \to \infty$  and can be dropped. Evaluating the remaining term under the  $\phi$ -integral at the limits  $\theta = 0, \pi$ , we see that it vanishes at  $\theta = \pi$  and that at  $\theta = 0$  it is proportional to  $f(0, \phi)$  which is what we are writing simply as f(0) and which is independent of  $\phi$ . Thus we find

$$\int_{\text{sphere}} \mathbf{J}_{\mathbf{x}} \cdot d\mathbf{a} = \frac{v}{k} \operatorname{Re} \int_{0}^{2\pi} d\phi \, 2if(0) = -\frac{4\pi v}{k} \operatorname{Im} f(0). \tag{92}$$

The sum of this plus the scattered flux σv vanishes, which produces the optical theorem (77).

We see that the interference flux comes in from the forward direction, where it partially cancels the incident flux going in the other direction.

The optical theorem has many generalizations. One version of it applies for the scattering of classical electromagnetic waves (vector waves, in contrast to the scalar waves considered here). Another applies to inelastic scattering in quantum mechanics, in which σ is the total cross section, including both elastic and inelastic scattering, while f(0) refers only to the forward amplitude for elastic scattering. This is because only the wave for elastic scattering can interfere with the incident wave. There are many other applications in fields ranging from quantum mechanics to black hole physics.

# Problems

- 1. The strange thing about scattering from a hard sphere in the limit ka ≫ 1 is that the total cross section is 2πr<sup>2</sup> , not πr<sup>2</sup> , the geometrical cross section. When the wave length is short, we expect quantum mechanics to agree with classical mechanics, but it does not in this case.
- (a) Work out the classical differential cross section dσ/dΩ for a hard sphere of radius a, and integrate it to get the total cross section σ.
- (b) In problem 9.1, you worked out the far field wave function ψ(x, y, z), for z ≫ ka<sup>2</sup> , when a plane wave e ikz traveling in the positive z-direction strikes a screen in the x-y plane with a circular hole of radius a cut out. In that problem the hole was centered on the origin. The solution was worked out for θ = ρ/z ≪ 1 (the paraxial approximation), where ρ = p x<sup>2</sup> + y 2.

By subtracting this solution from the incident wave e ikz, you get the far field wave function when a plane wave e ikz strikes the complementary screen, that is, just a disk of radius a at the origin.

It turns out this wave field is the same as the wave field in hard sphere (of radius a) scattering in the limit ka ≫ 1, if measured in the forward direction. That is because for forward scattering from a hard scatterer, the physics is dominated by diffraction, so it is only the projection of the scatterer onto the x-y plane that matters.

Write the scattered wave as (e ikr/r)f(θ), express r as a function of z and θ for small θ, expand out to lowest order in θ, and compare to the asymptotic wave field to get an expression for the scattering amplitude for small angles θ. Use the optical theorem, Eq. (77), to compute σ.

(c) Show that dσ/dΩ in the forward direction has a narrow peak of width ∆θ ∼ 1/ka ≪ 1. Write down an integral giving the contribution of this forward peak to the total cross section in terms of the first root b of the Bessel function J1. You can approximate sin θ = θ in this integral, since θ is small. It turns out that the value of this integral does not change much if the upper limit is extended to infinity. Use the integral

$$\int_0^\infty \frac{dx}{x} J_1(x)^2 = \frac{1}{2},\tag{93}$$

to find the contribution of the forward peak to the total cross section. (See Gradshteyn and Ryzhik, integral number 6.538.2.)

2. This problem is borrowed from Sakurai. Consider a potential

$$V(r) = \begin{cases} V_0 = \text{const}, & r < a, \\ 0, & r > a, \end{cases}$$

$$\tag{94}$$

where  $V_0$  may be positive or negative. Using the method of partial waves, show that for  $|V_0| \ll E = \hbar^2 k^2/2m$  and  $ka \ll 1$  the differential cross section is isotropic and that the total cross section is given by

$$\sigma_{\text{tot}} = \frac{16\pi}{9} \frac{m^2 V_0^2 a^6}{\hbar^4}.$$
 (95)

Suppose the energy is raised slightly. Show that the angular distribution can then be written as

$$\frac{d\sigma}{d\Omega} = A + B\cos\theta. \tag{96}$$

Obtain an approximate expression for B/A.

**3.** This problem is best done after some experience with scattering of particles with spin, such as Problem 33.2.

Consider the scattering of a polarized, spin  $\frac{1}{2}$  particle by a target, such as a neutron by the nucleus of an atom (we may assume that the nucleus is polarized, too). There is some amplitude for scattering that does not flip the spin, and some for scattering that does.

Suppose the incident particle is polarized spin up, so that the incident wave function can be taken to be

$$\psi_{\rm inc} = e^{i\mathbf{k}\cdot\mathbf{r}} \begin{pmatrix} 1\\0 \end{pmatrix}. \tag{97}$$

The asymptotic form for the scattered wave is

$$\psi_{\text{scatt}} \sim \frac{e^{ikr}}{r} \begin{pmatrix} f_{+}(\theta, \phi) \\ f_{-}(\theta, \phi) \end{pmatrix},$$
(98)

where  $f_{\pm}$  are the scattering amplitudes with and without spin flip.

Find a generalization of the optical theorem in this case. Recall Eq. (18.30) for the probability current for particles with spin. Is it possible that some target could cause the spin to flip with 100% probability? How do your answers change if a magnetization term such as seen in (18.33) is included in the probability current?