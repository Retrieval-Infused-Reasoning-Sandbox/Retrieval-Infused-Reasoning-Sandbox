# Partial wave expansion

The scattering of a particle in a spherically symmetric potential V(r) conserves angular momentum, so can be analyzed separately for each angular momentum. At large radius, the wave function with an incoming plane wave in the z direction and outgoing scattered wave takes the form

$$e^{ikr\cos\theta} + \sum_{l} (2l+1)f_l P_l(\theta) \frac{e^{ikr}}{r} \tag{1}$$

$$= \sum_{l} i^{l} (2l+1) \left\{ \frac{1}{2} [h_{l}^{+}(kr) + h_{l}^{-}(kr)] + ikf_{l} h_{l}^{+}(kr) \right\} P_{l}(\cos \theta)$$
 (2)

$$= \sum_{l} i^{l} (l + \frac{1}{2}) [e^{i2\delta_{l}} h_{l}^{+}(kr) + h_{l}^{-}(kr)] P_{l}(\cos \theta), \tag{3}$$

where  $h_l^{\pm}=j_l\pm in_l$  are the spherical Hankel functions,  $j_l$  is the spherical Bessel function, and  $n_l$  is the spherical Neumann function. The first equality follows from the expansion of the plane wave in terms of Hankel functions and Legendre polynomials, and the asymptotic form of the Hankel function  $h_l^+(z)\to e^{i(z-l\pi/2)}/iz$ . The second equality defines the phase shift  $\delta_l$ . Comparing the second and third lines, we have

$$e^{i2\delta_l} = 1 + 2ikf_l$$
, hence  $f_l = \frac{e^{i2\delta_l} - 1}{2ik} = \frac{e^{i\delta_l}\sin\delta_l}{k} = \frac{1}{k}\frac{1}{\cot\delta_l - i}$ . (4)

The differential cross section is

$$d\sigma/d\Omega = |f(\theta)|^2$$
, where  $f(\theta) = \sum_{l} (2l+1)f_l P_l(\theta)$ , (5)

while the total cross section is

$$\sigma = \sum_{l} \sigma_{l}, \quad \text{with} \quad \sigma_{l} = (4\pi/k^{2})(2l+1)\sin^{2}\delta_{l}. \tag{6}$$

If the potential has a range a, the important contributions to the cross section come only from  $l \lesssim ka$ . In particular, if  $ka \lesssim 1$  then only s-wave scattering is significant.

## s-wave scattering from a spherical square barrier or well

Consider a barrier or well of height or depth  $V_0$ . Let  $s^2 = 2ma^2V_0/\hbar^2$ , and let  $s = \mathrm{sgn}(V_0)\sqrt{s^2}$ . The wavenumber q inside the barrier/well satisfies  $(qa)^2 = \mp s^2 + (ka)^2$ , and the matching condition that determines the phase shift is

<span id="page-0-0"></span>
$$q \cot q a = k \cot(ka + \delta_0) \tag{7}$$

This defines the phase shift as a function of k and  $V_0$  for fixed a and m, which we can view as a function of the dimensionless combinations ka and s,  $\delta_0(ka,s)$ .

A contour plot of  $\delta_0(ka,s)$  is shown in Fig. 1, with the phase shift by convention positive, and identified mod  $\pi$ . For attractive potentials the wave function is pulled in, so  $\delta_0$  is positive, and increases

![](_page_1_Figure_0.jpeg)

<span id="page-1-0"></span>Figure 1: Left: Phase shift  $\delta_0(ka, s)$ . Right: cross-section at ka = 0.3, as a function of s.

as the well deepens. For repulsive potentials, the barrier pushes the wave function out, so  $\delta_0$  starts out "negative", and decreases as the barrier height increases. However, since the plot uses  $\delta_0$  in the range  $[0\pi)$ , decreasing "negative" values are indicated by positive values decreasing from  $\pi$ . This opposite nature of the attractive and repulsive cases can be seen in the color sequences on the contour plot.

For the barrier (s>0) the behavior depends on whether the particle has enough energy to go over the barrier (ka>s) or not. If not, then the barrier acts more or less like a hard sphere, so the phase shift is  $\delta_0\approx -ka$ , hence the contour lines on the phase shift plot Fig. 1 are horizontal. For over the barrier scattering, I think an approximation to the phase shift is  $\delta_0\approx -s^2/(2ka)$ , so the contours are parabolas. Note that for high energy scattering, the attractive case (the potential well) behaves similarly to the barrier, except with an opposite sequence of phase shifts. Keep in mind that unless  $ka\lesssim 1$ , the s-wave is not the only important contribution to the scattering amplitude.

#### Low energy s-wave scattering

Now let's focus on the low energy scattering. Then the figure shows that the well and the barrier are not too different for most values of s(<0), but there are exceptional values of s. Away from those exceptional values, the well acts like a barrier, because the slowly varying exterior wavefunction doesn't penetrate very much into the region of the potential. You can see this if you solve for the amplitude inside, as in homework 11. But what about the exceptional values?

In the figure on the right the total cross section is plotted, in units of  $a^2$ . As s decreases, i.e. moves to more negative values, the cross section goes to zero, and then zooms up as a function of s, quickly reaching a very large maximum, before zooming back down again. This maximum occurs at a value of s that admits a zero energy bound state. The wavefunction inside the well must have vanishing derivative at r=a if it is to match onto a zero energy bound state wavefunction outside. That is,  $\cos q=0$ , so the matching condition (7) implies  $\cos(ka+\delta_0)=0$ , hence  $\delta_0=-ka+\pi/2$ . To the extent that ka is negligible, we therefore have  $\delta_0\approx\pi/2$ , hence the cross section is  $\sigma_0\approx 4\pi/k^2=4\pi a^2/(ka)^2$ . For small ka, this is much larger than the hard sphere cross-section  $4\pi a^2$ . In fact, it goes to infinity as ka does, so the cross section blows up in this limit.

The zeros of the cross section occur at values of s for which  $\delta_0 = 0 \pmod{\pi}$ . The possibility of this happening at small ka leads to a small cross section even for a deep potential. This is called the Ramsauer-Townsend effect. It isn't yet clear to me why this happens just before, i.e. for s values very close to where  $\sigma_0$  zooms up as a function of s, but the answer must be contained in (7).

#### Potential with a weakly bound state

A remarkable formula for the low energy s-wave cross section applies when there is a weakly bound state with energy  $E_{\rm b}$ :

<span id="page-2-0"></span>
$$\sigma_0 \approx \frac{2\pi\hbar^2}{m} \frac{1}{E + |E_{\rm b}|}.\tag{8}$$

This depends only on the energy of the bound state, and the energy of the scattering particle. Moreover, it is true for low energy scattering from any short range potential with a shallow bound state, i.e. it doesn't have to be a spherical square well. This result was (according to Landau & Lifshitz) first found by Wigner in 1933, and rederived by Bethe and Peierls in 1935 using the following argument.

The exterior wavefunction is  $\sin(kr+\delta_0)/r$ . This must be matched to an interior function that is regular at the origin r=0. Suppose that function is  $\chi(r)/r$ . Then at  $r=r_1\sim a$  outside the range a of the potential we can impose the matching condition  $k\cot(kr_1+\delta_0)=\chi'(r_1)/\chi(r_1)$ . Now if the scattering particle has low energy, such that  $ka\ll 1$ , then we can replace  $r_1$  in the left hand side by 0. Thus  $k\cot\delta_0=\chi'(r_1)/\chi(r_1)$ . As for  $\chi(r)$ , the fact that the bound state is shallow means that  $|E_{\rm b}|$  is much less than the depth of the potential, which in turn means that the wavefunction  $\chi(r)$  is essentially determined just by the potential, and not much affected by the scattering wavenumber k. Therefore we can approximate  $\chi(r)$  by the bound state wavefunction itself, which outside of the potential has the form  $\exp(-\kappa r)$ , where  $\kappa^2=2mE_{\rm b}/\hbar^2$ . Thus  $\chi'(r_1)/\chi(r_1)\approx -\kappa$ . It follows that  $\cot\delta_0\approx -\kappa/k$ , so the scattering amplitude is

$$f_0 = \frac{1}{k} \frac{1}{\cot \delta_0 - i} = \frac{1}{k} \frac{1}{-\frac{\kappa}{k} - i} = \frac{-1}{\kappa + ik},\tag{9}$$

and the cross-section is

$$\sigma_0 = \frac{4\pi}{k^2 + \kappa^2},\tag{10}$$

which is equivalent to (8).

### **Scattering length**

The scattering length  $a_0$  is defined by

$$a_0 = -\lim_{k \to 0} \frac{\tan \delta_0}{k}, \qquad \frac{1}{a_0} = -\lim_{k \to 0} k \cot \delta_0.$$
 (11)

Alternatively (and, I think, equivalently), Murayama defines the scattering length by  $a_0 = -d\delta_0/dk|_{k=0}$ . Aside from near the peculiar values of s,  $\delta_0 \to 0$  as  $k \to 0$ , so  $a_0 = -\lim_{k \to 0} \delta_0/k$ . In this case, the zero energy limit of the cross section is simply  $\sigma_0 = 4\pi a_0^2$ . However it may be that the low energy limit of the phase shift is, for example,  $\pi/2$ , as at a resonance associated with a zero energy bound state, whence the cross section diverges.

The scattering length is always positive for repulsive potentials. For shallow attractive potentials it starts out negative, and goes to negative infinity when a bound state first appears at zero energy. For yet deeper potentials, the scattering length comes down from positive infinity. For example, in the case of a shallow bound state discussed above,  $a_0 \approx 1/\kappa > 0$ . As the potential well deepens yet further, the scattering length passes through zero and goes again to negative infinity when a second bound state arises, etc.

An example of a shallow bound state is the deuteron, composed of a neutron and a proton, which is very shallow ( $\sim 2.2$  MeV) compared to the potential depth  $\sim 50$  MeV. Thus the formula (8) tells us

that the scattering length is

$$a_0 \approx \frac{1}{\kappa} = \sqrt{\frac{\hbar^2}{2m|E_{\rm b}|}} = \frac{\hbar c}{\sqrt{2mc^2|E_{\rm b}|}} = \frac{200\text{MeV-fm}}{\sqrt{(938\text{MeV})(2.2\text{MeV})}} = 4.4\text{fm}$$
 (12)

(using the reduced mass for the np system). The actual measured scattering length is 5.4 fm. This is about 2.5 times the radius of the deuteron. This bound state is a spin triplet. More dramatically, there is an "almost bound" spin singlet state, called a "virtual bound state," which misses being bound by only 60 keV. For scattering in the singlet channel, the scattering length is thus negative, and greater by a factor of p 2200/60 ≈ 6, so a<sup>0</sup> ≈ −26 fm. The measured scattering length in this channel is actually −23.7 fm.