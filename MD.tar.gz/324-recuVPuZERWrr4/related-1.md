| (1) |
|-----|
|     |

where

is a <u>Bessel function of the first kind</u> and, in general,

are complex numbers. The function is most commonly encountered in the case an integer, in which case it is given by

|  |          | (2) |
|--|----------|-----|
|  | $\infty$ | (3) |
|  |          | (4) |

Equation () shows the close connection between

| and the <u>sinc function</u>              |                                                                                                                                                              |
|-------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Spherical Bessel functions                |                                                                                                                                                              |
|                                           |                                                                                                                                                              |
|                                           |                                                                                                                                                              |
| are implemented in the Wolf<br>definition | $rac{1}{2} fram \ Language$ as $rac{1}{2} fram \ Language$ as $rac{1}{2} fram \ Language$ as $rac{1}{2} fram \ Language$ as $rac{1}{2} fram \ Language$ |
|                                           | (5)                                                                                                                                                          |
| which differs from the "tradi             | tional version" along the <u>branch cut</u> of the <u>square root</u>                                                                                        |

function, i.e., the negative real axis (e.g., at

| ), but has nicer analytic properties for com | nplex |  |
|----------------------------------------------|-------|--|
|                                              |       |  |
|                                              |       |  |
|                                              |       |  |
|                                              |       |  |
|                                              |       |  |
|                                              |       |  |
|                                              |       |  |
|                                              |       |  |
|                                              |       |  |

| (Falloon acca)                               |  |  |
|----------------------------------------------|--|--|
| (Falloon 2001).  The first few functions are |  |  |
|                                              |  |  |
|                                              |  |  |

|                              |       | (6) |
|------------------------------|-------|-----|
|                              | (11   | (7) |
|                              | / 2   | (8) |
| which includes the special v | value |     |
|                              | (9)   |     |

## See also

Sinc Function, Spherical Bessel Differential Equation, Bessel Function of the Second Kind, Poisson Integral Representation, Rayleigh's Formulas, Spherical Bessel Function of the Second Kind

## **Explore with Wolfram | Alpha**

## References

Handbook of Mathematical Functions with Formulas, Graphs, and Mathematical Tables, 9th printing. New York: Dover, pp. 437-442, 1972. Arfken, G. "Spherical Bessel Functions." §11.7 in Mathematical Methods for Physicists, 3rd ed. Orlando, FL: Academic Press, pp. 622-636, 1985. Falloon, P. E. Theory and Computation of Spheroidal Harmonics with General Arguments. Masters thesis. Perth, Australia: University of Western Australia, 2001.

http://www.phusics.uwa.edu.au/pub/Theses/2002/Falloon/Masters Thesis.pdf.