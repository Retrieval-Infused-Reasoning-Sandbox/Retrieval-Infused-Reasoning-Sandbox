# Scattering length and effective range of microscopic two-body potentials

Mathias Macˆedo-Lima<sup>1</sup> and Lucas Madeira1, <sup>∗</sup> 1 Instituto de F´ısica de S˜ao Carlos, Universidade de S˜ao Paulo, CP 369, 13560-970 S˜ao Carlos, S˜ao Paulo, Brazil (Dated: August 1, 2023)

Scattering processes are a fundamental way of experimentally probing distributions and properties of systems in several areas of physics. Considering two-body scattering at low energies, when the de Broglie wavelength is larger than the range of the potential, partial waves with high angular momentum are typically unimportant. The dominant contribution comes from l = 0 partial waves, commonly known as s-wave scattering. This situation is very relevant in atomic physics, e.g. cold atomic gases, and nuclear physics, e.g. nuclear structure and matter. This manuscript is intended as a pedagogical introduction to the topic while covering a numerical approach to compute the desired quantities. We introduce low-energy scattering with particular attention to the concepts of scattering length and effective range. These two quantities appear in the effective-range approximation, which universally describes low-energy processes. We outline a numerical procedure for calculating the scattering length and effective range of spherically symmetric two-body potentials. As examples, we apply the method to the spherical well, modified P¨oschl-Teller, Gaussian, and Lennard-Jones potentials. We hope to provide the tools so students can implement similar calculations and extend them to other potentials.

Keywords: low-energy scattering, scattering length, effective range

# I. INTRODUCTION

Scattering is commonly described as a process in which the observed object interacts with a scattering center. The objects are typically classical particles, waves or quantum particles. As to the scatterer, we generally deal with another entity, represented as a scattering potential. From a classical point of view, a collision is the most common example, where physical parameters such as the cross-section and the scattering angle arise [1, 2]. From a quantum point of view, scattering is related to an incident wave that "collides" with a scattering potential, resulting in a scattered wave function.

In quantum scattering theory [1, 3], if the de Broglie wavelength is comparable to (or larger than) the range of the scattering potential, we are at the low-energy limit, in which interesting behavior appears. The properties of low-energy scattering can be described universally by two parameters: the scattering length and the effective range [4]. Physically, the scattering length can be understood as an "effective size" of the target potential [3, 5]. As the name suggests, the effective range may be defined as the "real" range of the scattering potential [6].

Low-energy quantum scattering theory is important in many areas, such as nuclear, atomic, and condensed matter physics. In most physical systems, the interaction, and consequently the scattering length and effective range, is fixed. Hence, the task becomes constructing short-range potentials that describe the properties of the system. However, cold atomic gases provide a richer scenario from the point of view of varying the scattering length. The interatomic interactions between two atoms can be tuned in the laboratory via Feshbach resonances [7, 8], which allows us to explore how physical properties change as the interaction is varied. The universal behavior in the low-energy limit enables us to draw a parallel between cold atomic gases and nuclear systems, for example [9–11].

Besides textbooks, several references aim to introduce aspects of scattering theory pedagogically. Detailed studies regarding analytical solutions in simple onedimensional (1D) potentials are discussed in Refs. [12– 14]. For 1D potentials that do not support bound states, quantities such as the reflection and transmission coefficients are typically calculated. In the tridimensional (3D) case, the quantum theory of scattering is often needed, where quantities such as the S-matrix, T-matrix, and Green's functions receive attention. Concerning analytical solutions, Ref. [15] introduces electron-positron scattering by using a covariant form of the S-matrix. Reference [16] gives an analytical treatment to Green's functions of delta potentials with a parallel with the scattering amplitude. Scattering length and effective range are discussed for an arbitrary angular momentum in Ref. [17], which also presents analytical calculations for the hard-sphere, soft-sphere, spherical well and a combination of the last two potentials. As to numerical solutions, Ref. [18] provides a numerical treatment to the 1D well potential by using Numerov's method, while Ref. [19] uses the Runge-Kutta integration method to study the variable phase equation in 3D scattering.

This work aims to construct microscopic two-body potentials to describe interactions with a desired scattering length and effective range. Since we are tuning the potential to reproduce two values, the functional form of the potential must have at least two parameters. Typically, one describes the strength of the attraction, and another is responsible for the range.

<sup>∗</sup> madeira@ifsc.usp.br

Although there are known analytical results for lowenergy scattering by some potentials, it is impossible to find closed expressions for arbitrary potentials. Hence, we employed a numerical approach. This work shows how to compute the scattering length and the effective range of spherically symmetric two-body potentials by numerically solving the Schr¨odinger equation. Using Numerov's method [20], we integrate the equation, and the scattering theory gives the boundary conditions. Once we have the wave function, calculating the scattering length and effective range is straightforward.

We devised the structure of this work to encompass readers with several distinct goals. The main text is aimed at readers who wish to cover how the scattering length and the effective range arise in low-energy scattering theory and how to compute them numerically, but without going into the formal scattering theory. For those who want to cover scattering in more detail, in Appendix A, we show how to obtain the Lippmann-Schwinger equation, employ Green's functions, and contour integrations in the complex plane to get the asymptotic behavior of the wave function. Covering the scattering length in graduate and undergraduate quantum mechanics courses is common, but this is not true for the effective range. Readers familiar with the scattering length may start with Sec. II C, where we introduce the effective range and the shape-independent approximation. However, if the reader is proficient in low-energy scattering and seeks a numerical approach to calculate the scattering length and effective range of a given potential, Sec. III onwards provides the necessary steps with relevant examples.

This work is structured as follows. In Sec. II, we briefly review quantum scattering theory fundamentals focusing on the low-energy limit. To keep this section concise, we start with a qualitative discussion of the asymptotic behavior of a plane wave scattered by a potential. For the readers interested in the details of scattering theory and the derivation of the equations of Sec. II, we provide Appendix A. Section III contains the numerical procedure to calculate the scattering length and the effective range from the zero-energy solutions of the Schr¨odinger equation. In Sec. IV, we apply the method to the spherical well, modified P¨oschl-Teller (mPT), Gaussian, and Lennard-Jones (LJ) potentials as examples to illustrate the method. Finally, in Sec. V, we present our final considerations.

# II. SCATTERING THEORY

We briefly present some quantum scattering theory results to define the scattering length, following textbook references [1, 3]. We are also interested in the effectiverange expansion, which is not typically covered in undergraduate quantum mechanics courses. For this reason, we employ arguments from references [5, 6]. The reader is referred to the references mentioned above for a detailed derivation of the results.

Formally, a scattering process is described as a transition from one quantum state to another. We are interested in a particle, initially far away from the region where it will be scattered, moving toward the scattering center. The initial state |i⟩ is assumed to be a plane wave |k⟩ since it is a free particle. The final state |f⟩ is the result of the action of a scattering potential on |i⟩ which, at large distances, is an outgoing spherical wave as illustrated in Fig. 1. The initial state |i⟩ satisfies the eigenvalue equation for the free-particle Hamiltonian H<sup>0</sup> = p <sup>2</sup>/2m,

$$H_0|i\rangle = E_i|i\rangle = \frac{\hbar^2 \mathbf{k}^2}{2m} |\mathbf{k}\rangle.$$
 (1)

![](_page_1_Picture_9.jpeg)

FIG. 1. Scheme of a scattering process. We chose our coordinate system such that the incoming particle has its momentum in the z-direction, k = kzˆ. A plane wave e <sup>i</sup>k·<sup>r</sup> = e ikz travels in space until it encounters a scattering potential. It produces an outgoing spherical wave e ikr/r at large distances. The scattering angle θ defines the direction in which the momentum was transferred after the scattering process.

We choose our coordinate system such that the scattering center is at the origin, and the position vector is given by r = xxˆ + yyˆ + zzˆ. Scattering is taken into account by introducing a potential V (r) that acts on a finite range r < R, where r ≡ |r|. The Hamiltonian in this region is

$$H = H_0 + V(\mathbf{r}). \tag{2}$$

Our goal is to understand the action of H on free-particle states and how the scattering occurs. In other words, we want to know how the initial state |i⟩ transitions to a final state |f⟩.

The initial state is given by a plane wave, |i⟩ = |k⟩. We consider the particle to be inside a cubic box of side L, such that the free particle is represented in the position basis as

$$\langle \mathbf{r} | \mathbf{k} \rangle = \mathcal{N} e^{i\mathbf{k} \cdot \mathbf{r}} = \frac{e^{i\mathbf{k} \cdot \mathbf{r}}}{L^{3/2}}.$$
 (3)

The factor N = L <sup>−</sup>3/<sup>2</sup> guarantees the normalization of the plane wave, and the dot product k·r defines the scalar product between the momentum k = p/ℏ = kxxˆ +kyyˆ + kzzˆ and the position. At the end of our calculations, we must take L → ∞ to guarantee the continuum character of the state.

Although V is time-independent, we may tackle our problem with a time-dependent formalism by considering the potential as an "adiabatic switch". The potential is "turned on" while r < R, inside the scattering region, and rapidly "turned off" when r > R. Furthermore, the scattering may be assumed to be elastic. The transition is from  $|i\rangle$  to a group of continuum states  $|f\rangle$  with energies  $E_f$ , where both  $|i\rangle$  and  $|f\rangle$  are eigenstates of  $H_0$ .

The procedure outlined in the last paragraph is carried out in detail in Appendix A. Here, we reproduce the result for the asymptotic behavior of the wave function,

$$\psi(\mathbf{r}) \xrightarrow{\text{large } r} \frac{1}{L^{3/2}} \left[ e^{i\mathbf{k}\cdot\mathbf{r}} + \frac{e^{ikr}}{r} f(\mathbf{k}', \mathbf{k}) \right].$$
(4)

This is a quantitative description of what we saw in Fig. 1: at large distances, the wave function combines the incident plane wave and a scattered spherical wave. Notice that the factor  $f(\mathbf{k}', \mathbf{k})$  is multiplying the spherical wave in Eq. (4). This term is called scattering amplitude, and it indicates how much of the incident wave was scattered. It depends on the initial  $\mathbf{k}$  and final  $\mathbf{k}'$  momenta,

$$f(\mathbf{k}', \mathbf{k}) = -\frac{mL^3}{2\pi\hbar^2} \int d^3r' \langle \mathbf{k}' | \mathbf{r}' \rangle V(\mathbf{r}') \langle \mathbf{r}' | \psi \rangle. \quad (5)$$

Equation (4) contains a large amount of information. Without solving the Schrödinger equation explicitly, we arrived at a result for the wave function at large distances with only a few assumptions about the scattering potential.

## A. Partial waves expansion

To obtain Eq. (4), we assumed the scattering potential  $V(\mathbf{r})$  to be real, finite-ranged, and local. Now, we consider one last restriction: that it is spherically symmetric, i.e., V is invariant under rotations. Hence, we can write  $V(\mathbf{r}) = V(r)$ . We must then solve Schrödinger's equation for a potential V(r) such that  $V(0 < r < R) \neq 0$  and V(r > R) = 0. In the scattering region (0 < r < R), we write

$$-\frac{\hbar^2}{2m}\nabla^2\psi + V(r)\psi = E\psi. \tag{6}$$

The total energy is  $E = \hbar^2 k^2 / 2m$ . A straightforward way of seeing this is to notice that this is the energy of the particle in the region r > R, where V(r) = 0. Since the scattering process is elastic, the total energy is conserved.

The wave function  $\psi = \psi_{\mathbf{k}}(r,\theta)$  depends only on the momentum  $\mathbf{k}$ , the position r and the scattering angle  $\theta$ , due to the spherical symmetry. We want the solution to obey the asymptotic behavior of Eq. (4), which we now write as

$$\psi_{\mathbf{k}}(r,\theta) \xrightarrow{\text{large } r} \mathcal{N} \left[ e^{ikz} + \frac{e^{ikr}}{r} f(\theta) \right],$$
(7)

where  $\mathcal{N}$  is a normalization constant. We also considered  $\mathbf{k} \cdot \mathbf{r} = kz$ , corresponding to an incident plane wave in the z direction

Due to the spherical symmetry of V(r), it is convenient to employ spherical coordinates. We write the Laplace operator in spherical coordinates and  $\psi = \psi(r, \theta, \phi)$ , for which we derive the eigenvalue equation

$$\left(-\frac{\hbar^2}{2m}\frac{1}{r}\frac{\partial^2}{\partial r^2}r + \frac{L^2}{2mr^2} + V(r)\right)\psi(r,\theta,\phi) = E\psi(r,\theta,\phi). \tag{8}$$

The angular momentum operator L is such that

$$L^{2} = -\hbar^{2} \left( \frac{1}{\sin \theta} \frac{\partial}{\partial \theta} \sin \theta \frac{\partial}{\partial \theta} + \frac{1}{\sin^{2} \theta} \frac{\partial^{2}}{\partial \phi^{2}} \right). \tag{9}$$

Its z-component is given by

$$L_z = -i\hbar \frac{\partial}{\partial \phi}.$$
 (10)

We then construct a complete set of eigenfunctions related to the commuting observables  $H, L^2$ , and  $L_z$  with eigenvalues  $E, l(l+1)\hbar^2$ , and  $m\hbar$ , respectively,

$$H\psi(r,\theta,\phi) = E\psi(r,\theta,\phi),$$

$$L^{2}\psi(r,\theta,\phi) = l(l+1)\hbar^{2}\psi(r,\theta,\phi),$$

$$L_{z}\psi(r,\theta,\phi) = m\hbar\psi(r,\theta,\phi).$$
(11)

We propose a separable solution of the form

$$\psi(r,\theta,\phi) = A_l(r)Y_l^m(\theta,\phi), \tag{12}$$

where the  $A_l(r)$  are radial functions and the  $Y_l^m(\theta,\phi)$  are the spherical harmonics. The angular part of the wave function, which depends on  $\theta$  and  $\phi$ , for any spherically symmetric potential corresponds to the spherical harmonics. Typically, students first encounter this property while studying the particular case of the hydrogen atom. This is a consequence of the potential commuting with  $L^2$  and  $L_z$ ,  $[V, L^2] = 0$  and  $[V, L_z] = 0$ , which is true for any potential that depends only on the radial coordinate r.

We perform a change of variables  $A_l(r) = u_l(r)/r$ , which is convenient given that there is a first derivative in the radial equation for  $A_l(r)$ , and this change removes it from the corresponding equation for  $u_l(r)$ . Substituting Eq. (12) into (8) yields an equation that depends only on the radial coordinate,

$$\left(\frac{d^2}{dr^2} + k^2 - U(r) - \frac{l(l+1)}{r^2}\right) u_l(r) = 0,$$
(13)

where  $U(r) = 2mV(r)/\hbar^2$ . At the origin, we require that  $A_l(r)$  is finite. Since  $A_l(r) = u_l(r)/r$ , we need  $u_l(0) = 0$ . We have a free particle in the region r > R since U(r) = 0. In this case, the solutions of Eq. (13) can be written in terms of the spherical Bessel functions of the first and second kind, usually denoted by  $j_l(x)$  and  $n_l(x)$ , respectively. The solution is of the form

$$u_l(r) = c_l' r j_l(kr) + c_l'' r n_l(kr),$$
 (14)

where  $c'_l$  and  $c''_l$  are constants. It is convenient to write the solution in terms of a linear combination of spherical Bessel functions,

$$h_l^{(1)}(x) = j_l(x) + in_l(x),$$
  
 $h_l^{(2)}(x) = j_l(x) - in_l(x),$  (15)

where  $h_l^{(1)}$  and  $h_l^{(2)}$  are called spherical Hankel functions of the first and second kind, respectively. Thus, Eq. (14) can be written as

$$u_l(r) = c_l^{(1)} r h_l^{(1)}(kr) + c_l^{(2)} r h_l^{(2)}(kr),$$
 (16)

where  $c_l^{(1)}$  and  $c_l^{(2)}$  are constants.

We know that the solution for a free particle, a plane wave  $e^{ikz} = e^{ikr\cos\theta}$ , contains components with all possible values of the angular momentum, l=0,1,2,..., and we wish to decompose it into a sum of different angular momentum components. This can be done with Rayleigh's formula [21],

$$e^{ikr\cos\theta} = \sum_{l=0}^{\infty} i^l (2l+1) j_l(kr) P_l(\cos\theta), \qquad (17)$$

where the  $P_l$  are Legendre polynomials. Notice that the plane wave, and consequently its expansion, does not depend on  $\phi$ . This is due to the spherical symmetry of the problem. If we think in terms of spherical harmonics, their  $\phi$  dependence is  $Y_l^m \propto e^{im\phi}$ . The absence of  $\phi$  indicates that we must set m=0, which leads directly to the Legendre polynomials since  $Y_l^0(\theta,\phi) \propto P_l(\cos\theta)$ .

Let us analyze the asymptotic behavior of Eq.(17), when  $r \to \infty$ . Equation 15 allows us to write

$$j_l(x) = \frac{h_l^{(1)}(x) + h_l^{(2)}(x)}{2}.$$
 (18)

The spherical Hankel functions obey the following limits [21]

$$h_l^{(1)}(x) \xrightarrow{\text{large } x} (-i)^{l+1} \frac{e^{ix}}{x},$$
 $h_l^{(2)}(x) \xrightarrow{\text{large } x} i^{l+1} \frac{e^{-ix}}{x}.$  (19)

Gathering all this information, we have that

$$e^{ikr\cos\theta} \xrightarrow{\text{large } r} \sum_{l=0}^{\infty} \frac{(2l+1)}{2ikr} \left[ e^{ikr} - (-1)^l e^{-ikr} \right] P_l(\cos\theta).$$

The first term inside the square brackets represents an outgoing spherical wave, while the second is related to an incoming spherical wave.

In the region r > R we have not only the incident plane wave, but also the spherical wave produced by the scattering center. Motivated by Eq. (17) and its asymtoptic

behavior, Eq. (20), we write the solution for every r > R

$$\psi(r,\theta) = \mathcal{N} \sum_{l=0}^{\infty} i^l (2l+1) \frac{u_l(r)}{r} P_l(\cos \theta), \qquad (21)$$

where  $\mathcal{N}$  is a normalization constant. Let us analyze the behavior of  $\psi(r,\theta)$  when  $r \to \infty$ . Equations (16) and (19) yield

$$\psi(r,\theta) \xrightarrow{\text{large } r} \mathcal{N} \sum_{l=0}^{\infty} \frac{(2l+1)}{ikr} \left[ c_l^{(1)} e^{ikr} - (-1)^l c_l^{(2)} e^{-ikr} \right] P_l(\cos\theta). \tag{22}$$

Let us pause to consider the implications of this result. Equation (20) describes the asymptotic behavior of the wave function for a plane wave without being scattered, while Eq. (22) does the same, but in a situation where scattering could have taken place. If we take  $\mathcal{N}=1$ and  $c_l^{(1)} = c_l^{(2)} = 1/2$ , then both equations are the same. This is not surprising since this particular choice makes the radial function the same as the one for a free particle,  $u_l(r)/r = j_l(kr)$  [see Eqs.(16) and (18)]. However, this situation arises only because the coefficients in front of the outgoing spherical wave and the incoming one,  $c_i^{(1)}$ and  $c_l^{(2)}$  respectively, are the same. If we take  $c_l^{(1)} \neq c_l^{(2)}$ , then scattering certainly took place. Moreover, the proportion of outgoing to incoming spherical waves, given by the ratio of these two coefficients, can be used to quantify the impact of the scattering potential on the free particle.

This motivates us to introduce a new quantity related to the ratio between the constants in front of  $e^{ikr}/r$  and  $e^{-ikr}/r$ .

$$\frac{c_l^{(1)}}{c_l^{(2)}} = S_l(k) = e^{2i\delta_l(k)},\tag{23}$$

where the  $S_l(k)$  are called scattering matrix components and the  $\delta_l(k)$  are called phase shifts. Notice that  $\delta_l(k)$  depends explicitly on the momentum or, equivalently, on the energy. The free particle case,  $c_l^{(1)} = c_l^{(2)} = 1/2$ , corresponds to a phase shift  $\delta_l(k) = 0$ . Writing the ratio of two constants as a complex exponential may seem strange, but the reason will be apparent shortly.

Let us express the asymptotic wave function, Eq. (22), in terms of the phase shifts, Eq. (23),

$$\psi(r,\theta) \xrightarrow{\text{large } r} \mathcal{N} \sum_{l=0}^{\infty} \frac{(2l+1)}{ikr} c_l^{(2)} \left[ e^{2i\delta_l} e^{ikr} - (-1)^l e^{-ikr} \right] P_l(\cos \theta).$$
(24)

Recall that our analysis started with the idea that a plane wave is scattered and produces a spherical wave, the latter multiplied by the scattering amplitude  $f(\theta)$ , as given

by Eq. (7). Now, we can connect the scattering amplitude and the phase shifts. For that, we recast Eq. (7) using the asymptotic limit of Rayleigh's formula, Eq. 20,

$$\psi(r,\theta) \xrightarrow{\text{large } r} \mathcal{N} \left\{ \left[ \sum_{l=0}^{\infty} \frac{(2l+1)}{2ikr} \left( e^{ikr} - (-1)^l e^{-ikr} \right) \times \right] \right\}$$

$$\left[ P_l(\cos\theta) \right] + f(\theta) \frac{e^{ikr}}{r} \right\}.$$
(25)

Comparison between Eqs. (24) and (25) allows us to write the scattering amplitude as a function of the phase shifts,

$$f(\theta) = \sum_{l=0}^{\infty} (2l+1) \frac{(e^{2i\delta_l} - 1)}{2ik} P_l(\cos \theta).$$
 (26)

The factor  $(e^{2i\delta_l}-1)/2ik$  is referred to as the partial wave amplitude  $f_l(k)$ , which may be rewritten as

$$f_l(k) = \frac{e^{2i\delta_l} - 1}{2ik} = \frac{e^{i\delta_l} \sin \delta_l}{k},\tag{27}$$

or

$$f_l(k) = \frac{e^{i\delta_l} \sin \delta_l}{k} = \frac{1}{k \cot \delta_l - ik},$$
 (28)

whichever is more convenient. Using Eq. (23), we may also express the partial wave amplitude in terms of  $S_l(k)$  as

$$S_I(k) = 1 + 2ik f_I(k).$$
 (29)

Now we can attribute physical meaning to the partial wave scattering amplitude and the phase shifts. Conservation of the probability during scattering tells us that, at large distances, the only thing that can change is the phase of the wave function (with respect to the incident wave). The difference between the phases is the phase shift  $\delta_l(k)$ . When there is no scattering,  $V=0, \, \delta_l(k)=0$ and  $f_l(k) = 0$ , meaning that we have the free particle solution in all space, indicated as a dot-dashed line in Figure 2. For a potential  $V \neq 0$ , the radial solution for r < R will depend on the details of the potential. However, we have a free particle solution outside the range Rof the potential, V(r > R) = 0. Hence, what happens inside the range of the potential determines the phase shift observed outside of it. An attractive potential "pulls" the particle toward the origin, Fig. 2a, while a repulsive potential "pushes" it away, Fig. 2b. The mathematical advantage of this formulation is that we describe the whole process in terms of a real quantity  $\delta_l(k)$ , and we reduce our problem to calculating it.

To compute the phase shifts, we can use two properties of wave functions: they are continuous, and so are their first derivatives. Hence, we need to match the inside (r < R) and outside (r > R) solutions and their derivatives at r = R. We write the radial solution in the region r > R as

$$A_l(r) = \frac{u_l(r)}{r} = \frac{1}{2}e^{2i\delta_l}h_l^{(1)}(kr) + \frac{1}{2}h_l^{(2)}(kr)$$
 (30)

![](_page_4_Figure_14.jpeg)

(a) Attractive potential:  $\delta_0(k) > 0$ .

![](_page_4_Figure_16.jpeg)

(b) Repulsive potential:  $\delta_0(k) < 0$ .

FIG. 2. Scattered radial solution  $u_0(r)$  and the free (V=0) radial solution  $g_0(r)$  to highlight the phase shift. At low energies, an attractive potential (V(r)<0) pulls the wave function, resulting in  $\delta_0(k)>0$ . The repulsive potential (V(r)>0) pushes  $u_0(r)$  away, resulting in  $\delta_0(k)<0$ .

in terms of spherical Hankel functions, and

$$A_l(r) = e^{i\delta_l} (\cos \delta_l j_l(kr) - \sin \delta_l n_l(kr))$$
 (31)

in terms of spherical Bessel functions. To avoid calculating the normalization of the wave function, we can work with the ratio  $u_l'(r)/u_l(r)$  so that it cancels out. This quantity is known as a logarithmic derivative because

$$\frac{d}{dx}\ln f(x) = \frac{f'(x)}{f(x)}. (32)$$

We define a dimensionless logarithmic derivative by including a factor of r. At  $r = R^-$  (at the range R of the potential coming from inside), it is a constant which depends on the expression of V(r),

$$\beta_l = \left[ r \frac{u_l'(r)}{u_l(r)} \right]_{r=R^-}.$$
 (33)

The phase shift can be determined by equating the logarithmic derivative at  $r = R^-$  with the outside solution (at  $r = R^+$ ) given by Eq. (31),

$$\beta_{l} = \left[ r \frac{u'_{l}(r)}{u_{l}(r)} \right]_{r=R^{+}}$$

$$= 1 + kR \left[ \frac{\cos \delta_{l} j'_{l}(kR) - \sin \delta_{l} n'_{l}(kR)}{\cos \delta_{l} j_{l}(kR) - \sin \delta_{l} n_{l}(kR)} \right], \quad (34)$$

where the notation  $j'_l(kR)$  means the derivative of  $j_l$  with respect to kr evaluated at kR, and similarly for  $n'_l(kR)$ . After some algebra, we arrive at

$$\cot \delta_l(k) = \frac{kR \, n_l'(kR) - (\beta_l - 1) \, n_l(kR)}{kR \, j_l'(kR) - (\beta_l - 1) \, j_l(kR)}.$$
 (35)

This is an analytic expression to calculate the l-th partial wave phase-shift  $\delta_l(k)$  provided we know the inside solution to compute the constant  $\beta_l$ . This result is a cornerstone for the numerical procedure we will treat later in this article.

# B. The low-energy limit and the scattering length

From Eq. (8), it is possible to see that the particle is subjected to an effective potential for the l-th partial wave of

$$V_{\text{eff}}(r) = V(r) + \frac{\hbar^2}{2m} \frac{l(l+1)}{r^2},$$
 (36)

where the second term on the right-hand side is a repulsive centrifugal barrier. It is absent for l=0, becoming more repulsive as we increase the value l of the considered partial wave. This work focuses on low-energy scattering, where the reduced wavelength  $\lambda = \lambda/2\pi = 1/k$  is much larger than the potential range, that is  $\lambda \gg R$  or  $kR \ll 1$ . If the energy is close to zero,  $E \approx 0$ , then the particle cannot overcome the centrifugal barrier. In this case, the partial waves with l>0 are unimportant, and the l=0 component is dominant in understanding low-energy scattering.

In this low-energy scenario, we consider partial waves with  $l \neq 0$  to vanish, and the resulting l = 0 term is referred to as "s-wave". Thus, the s-wave scattering radial component is given by Eq. (31),

$$A_{0}(r) = \frac{u_{0}(r)}{r} = e^{i\delta_{0}} (\cos \delta_{0} j_{0}(kr) - \sin \delta_{0} n_{0}(kr))$$
$$= e^{i\delta_{0}} \left[ \frac{1}{kr} \sin(kr + \delta_{0}) \right], \tag{37}$$

where we used

$$j_0(x) = \frac{\sin x}{x},$$

$$n_0(x) = -\frac{\cos x}{x}.$$
(38)

Schrödinger's equation for the radial solution becomes very simple in this situation. Outside the range of the potential, V(r > R) = 0. Moreover, there is no centrifugal barrier since l = 0, and for low-energy scattering,  $k \approx 0$ . Hence, Eq. (13) reduces to

$$u_0''(r) = 0. (39)$$

The solution can be written as

$$u_0(r) = c(r-a), \tag{40}$$

where c and a are constants. Its logarithmic derivative, given by Eq. (33), is

$$r\frac{u_0'(r)}{u_0(r)} = \frac{r}{r-a}. (41)$$

This needs to be equal to the logarithmic derivative of Eq. (37),  $kr \cot(kr + \delta_0)$ . Hence,

$$kr\cot(kr + \delta_0) = \frac{r}{r - a}. (42)$$

In the limit  $k \to 0$ , and also setting r = 0, we have

$$\lim_{k \to 0} k \cot \delta_0(k) = -\frac{1}{a},\tag{43}$$

where a is called scattering length [3]. Let us consider the implications of this result. In the previous section, we reduced the scattering problem to calculating the phase shifts  $\delta_l(k)$ . Here we are considering only low-energy phenomena, to which we argued that the l=0 component is the dominant one. However, Eq. (43) reduces the problem even further: in the zero-energy limit, a single number, the scattering length, encodes all the information we need about scattering.

The scattering length has, as its name suggests, dimension of length. However, it may differ by orders of magnitude from the range R of the potential, as we will see in several examples. A geometrical interpretation is possible if we choose c = -1/a in Eq. (40) (remember that the normalization always cancels out when we work with ratios such as  $u_0'/u_0$ ),

$$u_0(r > R) = 1 - \frac{r}{a}. (44)$$

We see that the scattering length is simply the intercept of the outside wave function, or its extrapolation, as illustrated in Fig. 3. Finally, the scattering amplitude for l = 0, Eq. (28), in the low-energy limit is

$$f_0(k) = \lim_{k \to 0} \frac{1}{k \cot \delta_0 - ik} = -a.$$
 (45)

## C. The effective range

Equation (43) and the concept of scattering length are remarkable. However, the underlying  $kR \ll 1$  assumption makes them good approximations to physical situations only when the energy or the range of the potential

![](_page_6_Figure_1.jpeg)

(a) An attractive potential that is not strong enough to produce a bound state. In this case, a < 0 because we need to extrapolate the radial function to negative values to intercept the r-axis.

![](_page_6_Figure_3.jpeg)

(b) A stronger attractive potential produces a bound state, and a > 0.

![](_page_6_Figure_5.jpeg)

(c) For a repulsive potential, we always have a > 0.

FIG. 3. Geometrical interpretation of the scattering length a based on three possibilities.

goes to zero. We might wonder if we can modify Eq. (43) to consider a finite but small value of kR. In other words, we would like to express  $k \cot \delta_0(k)$  as a series in powers of k. We already know that the first term is -1/a, so the task becomes computing the next.

We follow the procedure outlined in Ref. [6]. First, let us choose a different normalization for  $u_0(r)$  in Eq. (37),

$$u_0(r) = \cot \delta_0(k) \sin(kr) + \cos(kr), \tag{46}$$

and the reason for this choice will be apparent shortly.

Let us take the l=0 radial equation, Eq. (13), for two different wave functions  $u_{k_1}(r)$  and  $u_{k_2}(r)$ , labeled by their wave vectors  $k_1 = \sqrt{2mE_1}/\hbar$  and  $k_2 = \sqrt{2mE_2}/\hbar$ ,

$$u_{k_1}''(r) - U(r)u_{k_1}(r) + k_1^2 u_{k_1}(r) = 0,$$
  

$$u_{k_2}''(r) - U(r)u_{k_2}(r) + k_2^2 u_{k_2}(r) = 0.$$
 (47)

Next, we multiply the first equation by  $u_{k_2}$  and the second by  $u_{k_1}$  and take their difference,

$$u_{k_1}''(r)u_{k_2}(r) - u_{k_1}(r)u_{k_2}''(r) = (k_2^2 - k_1^2)u_{k_1}(r)u_{k_2}(r).$$
(48)

We may write the left-hand side as

$$u_{k_1}''(r)u_{k_2}(r) - u_{k_1}(r)u_{k_2}''(r) = \frac{d}{dr} \left[ u_{k_1}'(r)u_{k_2}(r) - u_{k_2}'(r)u_{k_1}(r) \right]. \tag{49}$$

Now we integrate Eq. (48) from 0 to R,

$$\left[u_{k_2}'(r)u_{k_1}(r) - u_{k_1}'(r)u_{k_2}(r)\right]_0^R = (k_2^2 - k_1^2) \int_0^R dr \, u_{k_1}(r)u_{k_2}(r). \tag{50}$$

The integral converges since  $A_0(r) = u_0(r)/r$  is finite at the origin  $(u_0(0) = 0)$  independently of the energy).

Next, we repeat the same procedure for the freeparticle (U=0) radial equation with solutions denoted by  $g_{k_1}(r)$  and  $g_{k_2}(r)$ . The result is the same as Eq. (50) if we replace u by g. Finally, we take the difference between this result and Eq. (50),

$$\begin{aligned}
& \left[g_{k_2}'(r)g_{k_1}(r) - g_{k_1}'(r)g_{k_2}(r)\right]_0^R \\
& - \left[u_{k_2}'(r)u_{k_1}(r) - u_{k_1}'(r)u_{k_2}(r)\right]_0^R = \\
& (k_2^2 - k_1^2) \int_0^R dr \left[g_{k_1}(r)g_{k_2}(r) - u_{k_1}(r)u_{k_2}(r)\right].
\end{aligned} (51)$$

The functions  $g_{k_1}$  and  $g_{k_2}$  are given by Eq. (46), and so are  $u_{k_1}$  and  $u_{k_2}$  for  $r \ge R$ . Then, Eq. (51) becomes

$$k_2 \cot \delta_0(k_2) - k_1 \cot \delta_0(k_1) = (k_2^2 - k_1^2) \int_0^R dr \left[ g_{k_1}(r) g_{k_2}(r) - u_{k_1}(r) u_{k_2}(r) \right].$$
 (52)

If we take the limit  $k_1 \to 0$ , we can write  $k_1 \cot \delta_0(k_1)$  in terms of the scattering length, Eq. (43),

$$k \cot \delta_0(k) = -\frac{1}{a} + k^2 \int_0^R dr \left[ g_0(r) g_k(r) - u_0(r) u_k(r) \right],$$
(53)

where we dropped the subscript in  $k_2$  for simplicity. We define the quantity

$$\rho(k) \equiv 2 \int_0^R dr \left[ g_0(r) g_k(r) - u_0(r) u_k(r) \right]. \tag{54}$$

Finally, we have an expression for  $k \cot \delta_0(k)$  at low-energies,

$$k \cot \delta_0(k) = -\frac{1}{a} + \frac{1}{2}r_0k^2 + \mathcal{O}(k^4),$$
 (55)

where the term r<sup>0</sup> is referred to as "effective range" and is defined as

$$r_0 \equiv \lim_{k \to 0} \rho(k) = 2 \int_0^R dr \left[ g_0^2(r) - u_0^2(r) \right],$$
 (56)

where g0(r) is calculated by taking k → 0 in Eq. (46). The result is exactly Eq. (44), justifying the normalization choice.

Comparing Eqs. (43) and (55), we see that we were able to include the next term in the expansion, which is proportional to k 2 . Only even powers of k appear on the right-hand side of Eq. (55) because of the symmetry with respect to changing the sign of k: the phase shift would also change sign and, since cot(−x) = − cot(x), the left-hand side is unchanged. Hence, the right-hand side can only have even functions of k. To compute the effective range, we only need two zero-energy solutions of the radial equation: the free particle, g0, and the solution with the potential V (r), u0.

Equation (55) asserts that the s-wave scattering phase shift does not depend on the shape of the potential V (r) at low energies. Instead, two potentials with different forms will produce the same phase shift if their scattering lengths and effective ranges are the same. For this reason, Eq. (55) is commonly referred to as shape-independent approximation. Nevertheless, it is important to note the error order of k 4 . At higher energies, outside the scope of this work, higher order terms become relevant, and Eq. (55) may not be appropriated.

## D. Bound states

When we defined the phase shifts in terms of the ratio of the coefficients appearing in front of the outgoing and income spherical waves, Eq. (23), we also introduced the amplitude Sl(k). The analytic properties of Sl(k) contain information about bound states, as we will see in the following.

Let us rewrite Eq. (24) as

$$\psi(r,\theta) \xrightarrow{\text{large } r} \frac{1}{(2\pi)^{3/2}} \sum_{l=0}^{\infty} \frac{(2l+1)}{2ik} P_l(\cos \theta) \times \left[ S_l(k) \frac{e^{ikr}}{r} - \frac{e^{-i(kr-l\pi)}}{r} \right]. \quad (57)$$

For l = 0 and large distances, the radial wave function is proportional to

$$S_0(k)\frac{e^{ikr}}{r} - \frac{e^{-ikr}}{r}. (58)$$

For an arbitrary finite-ranged potential V , the radial solution at r > R for a bound state (E < 0) obeys

$$u''(r) = -\frac{2mE}{\hbar^2}u(r) = \kappa^2 u(r), \quad \kappa \equiv \frac{\sqrt{-2mE}}{\hbar}. \quad (59)$$

The solution can be written as

$$u(r > R) = Ae^{\kappa r} + Be^{-\kappa r}, \tag{60}$$

where A and B are constants. However, u(r → ∞) must be finite, so we set A = 0. We conclude that the radial function for a bound state at large distances is

$$A(r) = \frac{u(r)}{r} \propto \frac{e^{-\kappa r}}{r} \text{ (large } r\text{)}.$$
 (61)

The existence of a bound state is related to the Schr¨odinger equation admitting a solution with a discrete E < 0 energy. By looking at Eq. (58), we may be tempted to substitute k → iκ, with k purely imaginary, to connect it to the bound state behavior of Eq. (61),

$$\frac{e^{ikr}}{r} = \frac{e^{i(i\kappa)r}}{r} = \frac{e^{-\kappa r}}{r}.$$
 (62)

However, the important difference is that the bound state is present even without the incident wave we have used for our scattering problem formulation. In Eq. (58), S0(k) controls the ratio of the outgoing to the incoming wave. Hence, in the bound state case, we have only the outgoing component, meaning an infinite ratio: S0(k) → ∞. Since we are treating S0(k) as a function of a complex variable, this means that it has a pole at k = iκ. Hence, the conclusion is that a bound state appears as a pole in S0(k). It is convenient to represent the variable k in the complex k-plane, i.e., where the abscissa is the real part of k, and the ordinate is the imaginary part of k. The pole at k = iκ is a point on the Im(k) axis, while the scattering continuum is on the positive Re(k) axis, since k > 0, as illustrated in Figure 4.

![](_page_7_Figure_21.jpeg)

FIG. 4. Complex k-plane. A bound state is represented by a pole in the S-matrix at k = iκ, while the scattering continuum corresponds to a real value of k > 0.

Let us derive an expression for S0(k), so we can identify

the  $k = i\kappa$  pole. Eqs. (28) and (43) yield

$$f_0(k) = \frac{1}{-1/a - ik}. (63)$$

The scattering amplitude is related to  $S_0(k)$  through Eq. (29),

$$S_0(k) = 1 + 2ikf_0(k) = \frac{-k - i/a}{k - i/a}.$$
 (64)

This expression has a pole at  $k = i\kappa$  if we identify

$$\kappa = \frac{1}{a}.\tag{65}$$

Hence, in the zero-energy limit, the energy of a bound state and the scattering length are connected simply by

$$E = -\frac{\hbar^2 \kappa^2}{2m} = -\frac{\hbar^2}{2ma^2}.$$
 (66)

A single parameter originated from the potential determines the bound-state energy.

### E. Two-body scattering

So far, we considered only the problem of a single particle being scattered by a finite-ranged potential V(r) located at r=0. With a few modifications, we can use the results we obtained to describe two particles interacting through a pairwise potential which depends only on their spatial separation r.

Besides being separable in radial and angular coordinates, the Hamiltonian of a two-body system with a spherically symmetric potential is also separable in the center of mass (CM) and relative coordinates. The two-body Hamiltonian is given by

$$H = -\frac{\hbar^2}{2m_1} \nabla_{\mathbf{r}_1}^2 - \frac{\hbar^2}{2m_2} \nabla_{\mathbf{r}_2}^2 + V(\mathbf{r}_1 - \mathbf{r}_2), \tag{67}$$

where the indices 1 and 2 refer to different particles. We define the coordinates

$$\mathbf{R} = \frac{m_1 \mathbf{r}_1 + m_2 \mathbf{r}_2}{M},$$

$$\mathbf{r} = \mathbf{r}_1 - \mathbf{r}_2, \tag{68}$$

where  $M = m_1 + m_2$ . In this coordinate system, and using the fact that the potential depends only on  $r = |\mathbf{r}|$ ,

$$H = H_{\text{CM}} + H_r,$$

$$H_{\text{CM}} = -\frac{\hbar^2}{2M} \nabla_{\mathbf{R}}^2,$$

$$H_r = -\frac{\hbar^2}{2m_r} \nabla_{\mathbf{r}}^2 + V(r),$$
(69)

where  $m_r = m_1 m_2 / (m_1 + m_2)$  is the reduced mass. The CM motion satisfies the free-particle equation, so its behavior is trivial and only adds a constant to the total

energy. However, the relative movement is non-trivial and contains all the physics due to the scattering of the two particles. Notice that the relative motion Hamiltonian is exactly the one we used to discuss the one particle problem if we substitute  $m \to m_r$ . Thus we can apply our previous results to two-body scattering.

### F. Some applications

Before presenting the numerical procedure to calculate the scattering length and effective range of two-body potentials, it is instructive to show some examples of analytical calculations.

## 1. Spherically symmetric finite well

For example, let us consider a two-body system with an interaction described by an attractive spherically symmetric finite well. It has a constant value inside the range R and zero outside. We can write V(r) as

$$V(r) = \begin{cases} -v_0 \frac{\hbar^2}{m_r R^2}, & \text{for } r < R, \\ 0, & \text{for } r > R, \end{cases}$$
 (70)

where  $v_0 > 0$  is a dimensionless parameter related to the depth of the well. We generally want to tune the parameters  $v_0$  and R to achieve the physical conditions we are interested in studying. For a relatively shallow or short-ranged potential, we may only observe continuum scattering states (E > 0), but increasing its depth or range may make it strong enough to produce a bound state (E < 0).

Let us start with the E > 0 case. For simplicity, let us consider the equal mass case,  $m_1 = m_2 = m$ . The s-wave (l = 0) equation we need to solve is

$$\left(\frac{d^2}{dr^2} - \frac{2m_r}{\hbar^2}V(r) + \frac{2m_r}{\hbar^2}E\right)u(r) = 0, \quad (71)$$

where u(r) = rA(r). Writing the explicit forms inside and outside the range of the potential yields

$$u''(r) + (k_0^2 + k^2) u(r) = 0$$
 for  $r < R$ ,  
 $u''(r) + k^2 u(r) = 0$  for  $r > R$ , (72)

where  $k^2 \equiv 2m_r E/\hbar^2$  and  $k_0^2 \equiv 2v_0/R^2$ . In the region r < R, the solution may be written as

$$u(r) = A \sin\left(\sqrt{k^2 + k_0^2} \ r\right) + B \cos\left(\sqrt{k^2 + k_0^2} \ r\right).$$
 (73)

Since u(0) = 0, because the radial solution A(r) = u(r)/r is regular at the origin, we set B = 0. In the region r > R, u(r) is given by Eq. (46). Hence, the solution is of the

form

$$u(r) = \begin{cases} A \sin\left(\sqrt{k^2 + k_0^2} r\right) & \text{for } r < R, \\ \cot \delta_0(k) \sin(kr) + \cos(kr) & \text{for } r > R, \end{cases}$$
(74)

where  $\delta_0(k)$  is the phase shift. Now we equate the logarithmic derivative at  $r = R^-$  and  $r = R^+$ ,

$$\left[r\frac{u'(r)}{u(r)}\right]_{r=R^{-}} = \left[r\frac{u'(r)}{u(r)}\right]_{r=R^{+}},\tag{75}$$

which yields,

$$\frac{\sqrt{k^2 + k_0^2} \cos\left(\sqrt{k^2 + k_0^2} R\right)}{\sin\left(\sqrt{k^2 + k_0^2} R\right)} = \frac{k \cot \delta_0(k) \cos(kR) - k \sin(kR)}{\cot \delta_0(k) \sin(kR) + \cos(kR)}.$$
(76)

Without any approximation, we may solve for the phase shift  $\delta_0(k)$ ,

$$\delta_0(k) = -kR + \arctan\left[\frac{k\tan\left(\sqrt{k^2 + k_0^2} R\right)}{\sqrt{k^2 + k_0^2}}\right]. \quad (77)$$

To calculate the scattering length a, we need to take the  $k \to 0$  limit as prescribed in Eq. (43). One straightforward way to do this is to rearrange Eq. (76) so that we have factors of  $k \cot \delta_0(k)$ . It is important to keep track of the orders employed in the approximation: Eq. (43) ignores  $\mathcal{O}(k^2)$  terms. Hence, to be consistent, we need to use the following approximations,

$$\cos(kR) = 1 + \mathcal{O}(k^2),$$
  

$$\sin(kR) = kR + \mathcal{O}(k^3).$$
(78)

Performing these approximations, Eq. (76) becomes

$$\sqrt{k_0^2} \cot\left(\sqrt{k_0^2} R\right) = \frac{-1/a}{-R/a + 1}.$$
 (79)

Finally, solving for a,

$$a = R - \frac{\tan\left(\sqrt{k_0^2}R\right)}{\sqrt{k_0^2}} = R\left(1 - \frac{\tan\left(\sqrt{2v_0}\right)}{\sqrt{2v_0}}\right), \quad (80)$$

where we used  $k_0^2 = 2v_0/R^2$  in the last step. Equation (80) makes it apparent that the scattering length depends only on the parameters of the potential, its depth  $v_0$  and range R. Further inspection of the equation leads us to conclude that the scattering length diverges for specific values of  $v_0$ . As we will see in the following, these are related to the appearance of bound states.

We could repeat the above procedure if we want to consider the E<0 cases. However, suppose we recall the discussion of bound states in Sec. II D. In that case, we

conclude that we only need to replace  $k = i\kappa$  in the solution inside the range of the potential and that the solution outside is proportional to  $e^{-\kappa r}$ . Thus, the equivalent of Eq. (74) for E < 0 is

$$u(r) = \begin{cases} A' \sin\left(\sqrt{k_0^2 - \kappa^2} \ r\right) & \text{for } r < R, \\ B' e^{-\kappa r} & \text{for } r > R, \end{cases}$$
(81)

where A' and B' are constants. They can be determined by matching u(r) at r = R and normalizing the radial solution. Next, we match the logarithmic derivatives at r = R,

$$\frac{\sqrt{k_0^2 - \kappa^2} \cos\left(\sqrt{k_0^2 - \kappa^2} R\right)}{\sin\left(\sqrt{k_0^2 - \kappa^2} R\right)} = \frac{-\kappa e^{-\kappa R}}{e^{-\kappa R}}.$$
 (82)

After some manipulations,

$$\tan\left(\sqrt{k_0^2 - \kappa^2} R\right) + \frac{\sqrt{k_0^2 - \kappa^2}}{\kappa} = 0.$$
 (83)

This is a transcendental equation that shows where the bound-state energies are located. It cannot be solved analytically, although obtaining numerical solutions is straightforward. Nevertheless, the term  $\sqrt{k_0^2 - \kappa^2}/\kappa$  is always positive. The only way for Eq. (83) to be valid is if  $\tan(\sqrt{k_0^2 - \kappa^2} R)$  is negative. That is to say,

$$\frac{\pi}{2} + n\pi < \sqrt{k_0^2 - \kappa^2} \ R < \pi + n\pi, \tag{84}$$

where n is an integer. Since  $\sqrt{k_0^2 - \kappa^2} R$  is always positive,  $n = 0, 1, \dots$  The first bound state is n = 0. Thus,

$$\frac{\pi}{2R} < \sqrt{k_0^2 - \kappa^2} < \frac{\pi}{R}.\tag{85}$$

Since  $k_0 > \sqrt{k_0^2 - \kappa^2}$  then, substituting  $k_0 = \sqrt{2v_0}/R$  and using Eq. (85), we have

$$v_0 > \frac{\pi^2}{8}. (86)$$

This result shows that there are no bound states if  $v_0$  is not above a certain threshold value.

Now we have everything we need to connect the appearance of bound states and the scattering length. Equation (80) expresses the scattering length a in terms of  $v_0$ . We know that  $\tan x$  diverges for  $x = \pi/2$ , which implies that a diverges for  $v_0 = \pi^2/8$ . This value is exactly the threshold we found for the appearance of a bound state, Eq. (86). The conclusion is that the scattering length diverges when a bound state appears. However, it depends on which side we approach since

$$\lim_{x \to \frac{\pi}{2}^{-}} \tan x = +\infty,$$

$$\lim_{x \to \frac{\pi}{2}^{+}} \tan x = -\infty.$$
(87)

Let us consider the situation where we fixed the range R of the potential and start with a very shallow well. Then a<0, and no bound states are supported. If we increase the depth of the well, |a| also increases to the point we are at the threshold for a bound state to appear. At this point,  $|a|\to\infty$  and a bound state with E=0 appears. If we continue to increase  $v_0$ , then a changes sign, and it will decrease until the formation of a second bound state. This situation is illustrated in Fig. 5. We centered our discussion around the appearance of the first bound state, but Eq. (84) implies that this behavior will happen whenever the system is at the threshold of forming an additional bound state. Figure 5 shows this since the points where  $|a|\to\infty$  are exactly where  $\sqrt{2v_0}=\pi/2+n\pi$ .

![](_page_10_Figure_2.jpeg)

FIG. 5. Behavior of the scattering length a as function of  $\sqrt{2v_0}$  for the spherical well, Eq. (80). For  $\sqrt{2v_0} = \pi/2 + n\pi$  (n = 0, 1, 2, ...), a diverges. This is related to the potential admitting an additional bound state at those points.

The advantage of the low-energy scattering formulation is that we may study the behavior of the bound states of the potentials without explicitly solving Schrödinger's equation. With the benefit of hindsight, Eq. (66) had already told us that  $|a| \to \infty$  corresponds to the formation of a new bound state since that, at the threshold, the state must have E = 0.

Finally, to complete our analysis of the spherical well, we must compute the effective range as defined in Eq. (56). Notice that the normalization of the solution outside the range of the potential in Eq. (74) agrees with the one we used while deriving the effective range expansion. To determine the constant A we impose the continuity of u(r) at r = R,

$$A = \frac{\cot \delta_0(k) \sin(kR) + \cos(kR)}{\sin(\sqrt{k^2 + k_0^2}R)}.$$
 (88)

![](_page_10_Figure_7.jpeg)

FIG. 6. Behavior of the effective range  $r_0$  as function of  $\sqrt{2v_0}$  for the spherical well, Eq. (92). The vertical dashed lines denote where the scattering length diverges,  $|a| \to \infty$ , corresponding to an effective range equal to the range of the potential,  $r_0/R = 1$ .

The normalized solution is written as

$$r(r) = \frac{1}{r}$$

$$\begin{cases} \frac{\cot \delta_0(k)\sin(kR) + \cos(kR)}{\sin(\sqrt{k^2 + k_0^2}R)} \sin\left(\sqrt{k^2 + k_0^2}r\right) & \text{for } r < R, \\ \cot \delta_0(k)\sin(kr) + \cos(kr) & \text{for } r > R. \end{cases}$$
(89)

The effective range, Eq. (56), is defined in the  $k \to 0$  limit of u(r),

$$u(r) = \begin{cases} \frac{(1 - R/a)}{\sin(k_0 R)} \sin(k_0 r) & \text{for } r < R, \\ 1 - r/a & \text{for } r > R. \end{cases}$$
(90)

Then, the effective range is given by the integral

$$r_0 = 2 \int_0^R dr \left[ \left( 1 - \frac{r}{a} \right)^2 - \left( 1 - \frac{R}{a} \right)^2 \frac{\sin^2(k_0 r)}{\sin^2(k_0 R)} \right]. \tag{91}$$

After computing the integral, we use Eq. (80) to replace a in favor of R and  $k_0$ . The result is

$$r_{0} = R \left( 1 - \frac{1}{3} \left( \frac{k_{0}R}{\tan(k_{0}R) - k_{0}R} \right)^{2} + \frac{1}{k_{0}R \tan(k_{0}R) - (k_{0}R)^{2}} \right), \tag{92}$$

which shows that  $r_0$  is also dependent on parameters of the potential only. We illustrate the behavior of  $r_0$  in Fig. 6. Another characteristic is that the range of the potential and the effective range are equal  $(r_0 = R)$  only when the scattering length diverges. This stresses that even for the case of a spherical well when there is no doubt that the range of the potential is R, a rigorous analysis should be carried out in terms of the effective range if we want to capture the low-energy properties of the system.

TABLE I. Summary of the low-energy properties of two physical systems: the <sup>4</sup>He dimer and the deuteron. The values of the scattering length a, effective range r0, and bound-state energy E are taken from the indicated references. The zero-range and finite-range approximations, Ezr and Efr, were calculated using Eqs. (93) and (95).

| System    | a       | r0     | E                                                                  | Ref. | Ezr      | Efr      |
|-----------|---------|--------|--------------------------------------------------------------------|------|----------|----------|
| 4He dimer | 90.4 ˚A | 8.0 ˚A | −1.62 mK                                                           | [22] | −1.48 mK | −1.63 mK |
|           |         |        | Deuteron 5.4112 fm 1.7436 fm −2.224 MeV [23] −1.416 MeV −2.223 MeV |      |          |          |

## 2. Zero-range and finite-range approximations

Equation (65) has an immediate application when dealing with two-body bound states in the zero-energy limit. The energy can be readily calculated as follows:

$$E_{zr} = -\frac{\hbar^2 \kappa^2}{2m_r} = -\frac{\hbar^2}{2m_r a^2},\tag{93}$$

where we chose the subscript to denote the zero range, i.e., in deriving this result, r<sup>0</sup> was taken to be zero. If we want to modify the equation above to include finite-range corrections, we have to combine these results with Eq. (55) and make the substitution k → iκ, which yields [24, 25]

$$\frac{1}{a} = \kappa - \frac{1}{2}r_0\kappa^2. \tag{94}$$

We can solve this quadratic equation for κ, choose the appropriate root, and use it to compute the bound state energy,

$$E_{fr} = -\frac{\hbar^2 \kappa^2}{2m_r} = -\frac{\hbar^2}{2m_r r_0^2} \left( 1 - \sqrt{1 - \frac{2r_0}{a}} \right)^2, \quad (95)$$

where the subscript fr stands for finite-range.

Equations (93) and (95) seem very powerful in the sense that we only need one or two zero-energy parameters to compute the energy of a bound state, besides the reduced mass. However, the question of whether this model produces sensible results in realistic settings remains. At this point, applying the zero-range and finiterange results to physical systems is illustrative. To clarify, we do not compute a and r<sup>0</sup> for the examples below; we just take values from the literature. Table I contains a summary of the parameters we employed and the results obtained.

We present two examples; the first is the bound state of two <sup>4</sup>He atoms, called helium dimer. There are many realistic pairwise potentials for <sup>4</sup>He. Let us consider the one of Ref. [22]. It contains adiabatic, relativistic, and quantum electrodynamics interactions. Explaining the details of the potential is beyond the scope of this work, but we only need three values from this reference to illustrate how useful the effective-range approximation is. The authors reported that their potential produces a dimer energy of E<sup>d</sup> = −1.62 mK, a scattering length of a = 90.4 ˚A, and an effective range of r<sup>0</sup> = 8.0 ˚A.

Substituting a, and the mass of an <sup>4</sup>He atom, in Eq. (93) yields Ezr ≈ −1.48 mK, such that Ezr/E<sup>d</sup> ≈ 0.92. Let us pause to appreciate this result. We estimated the energy of a bound-state using only one parameter calculated from a zero-energy theory, and it differs only 8% from the full solution of the Schr¨odinger equation. If we include the finite-range correction, Eq. (95), then the result is Ef r = −1.63 mK, which is correct within 1%. Both the zero- and finite-range results successfully describe the physical system because kR ∼ 0.1 in this case.

The second example we chose is from nuclear physics. The deuteron (the nucleus of deuterium) is the only bound state of two nucleons, and it is formed by a proton and a neutron. The details of nuclear interaction are much more complicated than what we present here. For example, the deuteron has a quadrupole moment due to a l = 2 partial-wave component, which goes beyond s-wave (l = 0) scattering. However, this component is small, and we will give an s-wave treatment to the deuteron.

Reference [23] reports the values a = 5.4112 fm and r<sup>0</sup> = 1.7436 fm for the proton-neutron scattering length and effective range, respectively. Unlike the dimer case, where the particles are identical, the proton and neutron masses are different, although this difference is small. The reduced mass is then m<sup>r</sup> = mpmn/(m<sup>p</sup> + mn). We employed the values of the proton and neutron masses from the 2018 CODATA recommended values [26].

The experimental energy of the deuteron is E<sup>d</sup> = −2.224 MeV. Substituting the appropriate values into Eq. (93) yields Ezr = −1.416 MeV, meaning that the zero-energy theory only accounts for ≈ 64% of the deuteron energy. However, if we include the finite-range correction, Eq. (95), then the energy is Ef r = −2.223 MeV, practically coinciding with the experimental value. Unlike the helium dimer, the range of the potential needed to be taken into account to reproduce the physical system because kR ∼ 0.4 for the deuteron is larger than in the <sup>4</sup>He case.

We should emphasize that the scales are very different in both examples. The <sup>4</sup>He dimer, in the realm of atomic physics, is in a spatial scale of ˚A(10<sup>−</sup><sup>10</sup> m), and the energy is of the order of 10<sup>−</sup><sup>7</sup> eV. For the deuteron, the lengths are in the femtometer (10<sup>−</sup><sup>15</sup> m) scale, while the energy is of a few MeV (10<sup>6</sup> eV). This exemplifies how universal are these low-energy scattering results.

#### III. NUMERICAL PROCEDURE

Analytical expressions for low-energy scattering parameters are only available for a few potentials. Even in those cases, the calculations may be cumbersome, as we saw in Sec. IIF1 for one of the simplest potentials, the spherical well. In general, we need to calculate a and  $r_0$  numerically.

### A. Numerical solutions of Schrödinger's equation

#### 1. Second-order central difference

We need two main ingredients to compute the lowenergy scattering parameters, the radial wave function inside and outside the range of the potential. The latter has an analytical expression, but the former can only be computed numerically for most potentials. The radial equation for u(r) = rA(r) resembles the one-dimensional Schrödinger's equation, so we can employ any of the various numerical methods that are available in the literature [27].

A common strategy in computational physics is to consider the function u(r) in a discrete set of points  $r_i = i\Delta r$ , where i is an integer ranging from i = 0, ..., N and  $\Delta r$  is a small quantity. Then, our goal becomes finding the value of  $u(r_i)$  for every i. First, writing the expressions for the first and second numerical derivatives in this scenario is useful. For that, let us consider two Taylor expansions of u(r) around the points  $r \pm \Delta r$ ,

$$u(r + \Delta r) = u(r) + (\Delta r)u'(r) + \frac{(\Delta r)^2}{2}u''(r) + \frac{(\Delta r)^3}{6}u'''(r) + \cdots ,$$

$$u(r - \Delta r) = u(r) - (\Delta r)u'(r) + \frac{(\Delta r)^2}{2}u''(r) - \frac{(\Delta r)^3}{6}u'''(r) + \cdots$$
(96)

The difference of the two Taylor expansions yields an expression for the first derivative, while their sum results in the second derivative,

$$\left. \frac{du}{dr} \right|_{r=r_i} \approx \frac{u_{i+1} - u_{i-1}}{2\Delta r},\tag{97}$$

$$\left. \frac{d^2 u}{dr^2} \right|_{r=r_i} \approx \frac{u_{i+1} - 2u_i + u_{i-1}}{(\Delta r)^2},\tag{98}$$

where we introduced a compact notation  $u(r_i) \equiv u_i$  and, since  $\Delta r$  is small, we neglected terms of  $\mathcal{O}[(\Delta r)^3]$ . These expressions tell us that if we want to calculate the numerical derivative at some point  $r_i$ , we need to know the value of the function at the neighboring sites; for the second derivative, we also need the value of the function at the site  $r_i$ . Since the expression for the first derivative is

symmetric with respect to i, it is called the central difference. The same is true for Eq. (98), called the second-order central difference. There are other numerical approximations to numerical differentiation, each with its advantages and drawbacks [28].

Substituting Eq. (98) into the s-wave zero-energy radial equation, we have

$$u_{i+1} = 2u_i - u_{i-1} + \frac{2m_r(\Delta r)^2}{\hbar^2} V(r_i) u_i.$$
 (99)

This equation tells us that if we know the value of the radial solution for two consecutive points, at  $r_{i-1}$  and  $r_i$ , we can calculate the value for the next point  $u_{i+1}$ .

We know that u(0) = 0; hence we need to know  $u(\Delta r)$  to begin the calculation. For attractive potentials,  $u(\Delta r)$  has a non-zero value. If we want to find a solution without worrying about the normalization, we can set  $u(\Delta r) = 1$ . In other words, Schrödinger's equation is linear: if some u(r) is a solution, then Cu(r) is also a solution, with C constant.

Now we have everything to write a program that solves u(r) inside the range R of the potential V(r). For reasons that will be apparent when we compute the scattering length, it is helpful to find the solution up to  $R + \Delta r$ . The inputs are typically the number of points N (or the discretization  $\Delta r$ ), and the parameters of the potential (in the case of the spherical well, Eq. 70,  $v_0$  and R). Once we know the number of points N, we may initialize an array of the desired dimension to hold the values of  $u_i$ . We also need to write a function that returns the value of  $V(r_i)$  given a position  $r_i$ . Once these functionalities are implemented, the following algorithm will provide the values of  $u_i$  for the whole interval:

- 1. Set  $u_0 = 0$ ,  $u_1 = 1$ , and i = 1.
- 2. Use Eq.(99) to compute  $u_{i+1}$ .
- 3. If  $r_i \ge R + \Delta r$ , stop. Else, increment i by one.
- 4. Go to step 2.

#### 2. Numerov's method

Equation (98) is one possible discretization for a numerical second derivative. There are other alternatives if we want to improve the precision of our algorithm. For example, Numerov's method is a numerical technique capable of solving differential equations of second order when the first-order term is not present [20]. It applies to equations of the form

$$\frac{d^2y}{dx^2} = -\xi(x)y(x) + s(x). \tag{100}$$

The method provides a relation between  $y_i \equiv y(x_i)$  at three equally spaced consecutive points  $(x_{i-1}, x_i, \text{ and }$ 

 $x_{i+1}$ ),

$$y_{i+1} = \frac{1}{\left(1 + \frac{(\Delta x)^2}{12} \xi_{i+1}\right)} \left\{ 2y_i \left(1 - \frac{5(\Delta x)^2}{12} \xi_i\right) - y_{i-1} \left(1 + \frac{(\Delta x)^2}{12} \xi_{i-1}\right) + \frac{(\Delta x)^2}{12} (s_{i+1} + 10s_i + s_{i-1}) \right\} + \mathcal{O}[(\Delta x)^6],$$
 (101)

where  $\Delta x$  is the spacing between the points,  $\xi_i \equiv \xi(x_i)$ , and  $s_i \equiv s(x_i)$ .

The appeal of this method to our case is immediate. The s-wave zero-energy radial equation is of the form of Eq. (100) with  $y \to u$ ,  $x \to r$ , s = 0, and

$$\xi(r) = -\frac{2m_r}{\hbar^2}V(r). \tag{102}$$

The algorithm presented in Sec. III A 1 is mostly unchanged if we use Numerov's method instead of the second-order central difference. The key change is that substituting Eq. (99) by (101) increases the precision without significant technical complications.

#### 3. Dimensionless quantities

Schrödinger's equation contains relatively small quantities. Planck's reduced constant is  $\hbar \sim 10^{-34} \; \mathrm{J} \; \mathrm{s}$  (or  $\sim 10^{-15}$  eV s), while the typical masses, length, and energy scales are also small. This does not affect analytical calculations since the numerical values are commonly substituted at the end of the procedure. However, computers deal with real numbers differently. In computing, floating-point representation is an approximation that allows real numbers to be stored using an integer with a fixed precision, called the significand, scaled by an integer exponent of a fixed base. The number of bits dedicated to the significand and exponent determines the accuracy and range of the floating-point numbers that can be represented. However, due to the intrinsic limitations of representing real numbers in this format, rounding errors and other inaccuracies can occur, affecting the accuracy of computations involving floating-point numbers [28].

For these reasons, we would like to work within our program with quantities of the order of one (or close to it) so that we do not have to deal with very large or very small numbers. At the end of the calculation, once the solution is found, we may substitute the physical constants to compute the values for a particular system of interest. The procedure we describe here is equivalent to what is commonly called "set  $\hbar = m_r = 1$ ", but we provide a step-by-step derivation so that it is more clear how to recover the units at the end of the calculation.

Let us choose a length scale  $\ell$ . The convenient value of  $\ell$  depends on the system under study; for atomic physics, it may be 1 Å; for nuclear physics, we may use 1 fm or

any other length scale that makes sense for a particular problem. In this section, we denote dimensionless quantities with bars over them. Then, the scaled distance

$$\bar{r} = \frac{r}{\ell} \tag{103}$$

is dimensionless. The radial function u(r) has units of  $[length]^{-1/2}$  (a straightforward way to see this is to write the integral corresponding to its normalization). Hence the transformation to make it dimensionless is

$$\bar{u}(\bar{r}) = \frac{u(r)}{\ell^{-1/2}}.$$
 (104)

Equation (103) implies that  $d^2/dr^2=(1/\ell^2)d^2/d\bar{r}^2$ , so that the s-wave zero-energy radial equation becomes

$$-\frac{\hbar^2}{2m_r\ell^2}\frac{d^2\bar{u}}{d\bar{r}^2} + V(\bar{r})\bar{u} = 0.$$
 (105)

The quantity

$$\epsilon = \frac{\hbar^2}{m_r \ell^2} \tag{106}$$

has units of energy, so we may make the potential dimensionless by considering  $\bar{V}=V/\epsilon$ . Then, the equation we want to solve becomes

$$-\frac{1}{2}\frac{d^2\bar{u}}{d\bar{r}^2} + \bar{V}(\bar{r})\bar{u} = 0. \tag{107}$$

The net result is the same as "set  $\hbar = m_r = 1$ ", but now it is clear what to do. We implement and solve Eq. (107) in our program. After we obtained the results in this dimensionless fashion, we use Eqs. (103), (104), and (106) to recover the solutions with the desired units.

#### B. Scattering length and effective range

After following the numerical procedure outlined in Sec. III A, we should have the solution to the s-wave zero-energy radial equation for the desired potential. That is, we calculated  $u_i$  in the interval r=0 to  $R+\Delta r$  at points  $r_i$  equally spaced by  $\Delta r$ .

Equation (44) is the low-energy  $(k \to 0)$  behavior of the radial solution outside the range of the potential, which we denote by  $g_0(r)$  to avoid confusion. Then, we have the analytical expression,

$$\frac{g_0'(r)}{g_0(r)} = \frac{1}{r-a}$$
 for  $r > R$ . (108)

On the other hand, we can compute the same quantity at r = R using the numerical solution we obtained. The numerical derivative  $u'_{\text{num}}$  can be calculated using Eq. (97),

$$u'_{\text{num}}(R) = \left. \frac{du(r)}{dr} \right|_{r=R} = \frac{u(R + \Delta r) - u(R - \Delta r)}{2\Delta r}.$$
 (109)

Now it becomes apparent why we included the point  $R + \Delta r$  in the interval where we find u(r) numerically. Finally,  $u'_{\text{num}}(R)/u_{\text{num}}(R)$  must match Eq. (108) at r = R (their logarithmic derivatives must be equal at this point), which gives us the expression

$$a = R - \frac{2\Delta r \ u(R)}{u(R + \Delta r) - u(R - \Delta r)}.$$
 (110)

This expression relates the scattering length and our numerical solution.

Equation (110) depends on the ratio of radial solutions, so we ignored its normalization. In other words, if we multiply all  $u_i$  by a constant C, Eq. (110) is unaltered. However, as we saw in Sec. II C, the expression we derived for the effective range assumes a particular normalization choice. The constant C is obtained by matching the value of the numerically-obtained radial function and the analytical solution at r = R, that is Cu(R) = g(R),

$$C = \frac{g(R)}{u(R)} = \frac{(1 - R/a)}{u(R)}.$$
 (111)

So, in the following, we assume that all the  $u_i$  have been multiplied by this constant C.

Finally, what is left is to compute the integral that defines the effective range, Eq. (56), numerically. Although the V=0 radial solution, denoted by g(r), has an analytical expression, it is useful to discretize it at the same points where we determined  $u_i$  numerically,  $g_i \equiv g(r_i)$ . Then, the task becomes computing an integral of the form

$$I = \int_{x_1}^{x_N} f(x)dx \tag{112}$$

when the function f(x) is known only at a discrete set of equally spaced points,  $f(x_i) \equiv f_i$ , where i = 1, 2, 3, ..., N. This is a well-known problem in numerical calculus, and many methods accomplish the task [28]. One of the simplest methods is called the trapezoidal rule because it approximates the area under the curve by a trapezoid,

$$\int_{x_1}^{x_N} f(x)dx = \Delta x \left[ \frac{1}{2} f_1 + f_2 + \dots + f_{N-1} + \frac{1}{2} f_N \right] + \mathcal{O}\left( \frac{(x_N - x_1)^3 f''}{N^2} \right).$$
 (113)

A more sophisticated method is called Simpson's rule, which considers a quadratic interpolation between the points,

$$\int_{x_1}^{x_N} f(x)dx = \Delta x \left[ \frac{1}{3} f_1 + \frac{4}{3} f_2 + \frac{2}{3} f_3 + \frac{4}{3} f_4 + \cdots + \frac{2}{3} f_{N-2} + \frac{4}{3} f_{N-1} + \frac{1}{3} f_N \right] + \mathcal{O}\left( \frac{(x_N - x_1)^5 f^{(4)}}{N^4} \right).$$
(114)

Either method will successfully calculate the integral necessary for the effective range.

### IV. EXAMPLES

We chose four potentials to illustrate the numerical procedure described in Sec. III. The reasoning behind these choices is the following. The first one is the spherical well. Since we derived analytical expressions for its scattering length and effective range, Eqs. (80) and (92), this represents an excellent opportunity to test our program. We can readily compare our numerical solutions to the expected results, and it is much more straightforward to check the correctness of the program.

However, as we stated before, numerical computations would be unnecessary if all potentials had analytical expressions for their low-energy parameters. Hence, next, we considered the modified Pöschl-Teller potential. In this case, there is an analytical expression for the scattering length, but the effective range has a closed form only when  $|a| \to \infty$ . Next, we considered a Gaussian potential since, in this situation, everything has to be computed numerically.

In the last three examples, we only considered purely attractive potentials. However, many interesting and relevant physical situations involve potentials where there is competition between a strong short-range repulsion and a weak long-range attraction. For this reason, we also considered the Lennard-Jones potential.

### A. Spherical well

This potential has been covered extensively in the previous sections. To make comparisons easier with the other potentials, we rewrite Eq. (70) as

$$V_{\rm sw}(r) = \begin{cases} -v_{\rm sw} \frac{\hbar^2 \mu_{\rm sw}^2}{m_r}, & \text{for } r < R, \\ 0, & \text{for } r > R, \end{cases}$$
(115)

where we introduced the quantity  $\mu_{\rm sw}=1/R$ . In Fig. 7, we compare its shape with other purely attractive potentials.

### B. Modified Pöschl-Teller

The modified Pöschl-Teller potential has been used to describe systems in nuclear [9] and atomic physics [29]. We present it in the form

$$V_{\rm PT}(r) = -v_{\rm PT} \frac{\hbar^2}{m_r} \frac{\mu_{\rm PT}^2}{\cosh^2(\mu_{\rm PT}r)}.$$
 (116)

Figure 7 illustrates its shape. This potential contains two parameters,  $v_{\rm PT}$  and  $\mu_{\rm PT}$ , related to its depth and range. However, associating a range of R to this potential is not as immediate as for the spherical well case. Fortunately, we only need a point R where  $V(R) \approx 0$ . So, our numerical approach is to look for a value of R such that the

![](_page_15_Figure_1.jpeg)

FIG. 7. Spherical well, modified Pöschl-Teller, and Gaussian potentials in the unitary limit ( $|a| \to \infty$ ). We make the axis dimensionless by rescaling the distance in effective range units, and the potential in  $\hbar^2/(m_r r_0^2)$  units, such that  $\bar{V} \equiv m_r r_0^2 V/\hbar^2$  is dimensionless.

potential is negligible  $|V(R)| \leq \varepsilon$ . Using dimensionless quantities, we found that for the mPT, Gaussian, and LJ potentials,  $\varepsilon = 10^{-15}$  produces the desired results.

The eigenfunctions of the mPT potential may be obtained analytically [30], but their derivation is beyond the scope of this work. However, if we perform the substitution  $v_{\rm PT} = \lambda(\lambda - 1)/2$ , there is an analytical expression for the scattering length in terms of the parameters of the potential [31],

$$a\mu_{\rm PT} = \frac{\pi}{2}\cot\left(\frac{\pi\lambda}{2}\right) + \gamma + \Psi(\lambda),$$
 (117)

where  $\gamma$  is the Euler-Mascheroni constant [32] and  $\Psi$  is the digamma function [32].

The  $|a| \to \infty$  case corresponds to  $\lambda = 2$  (cot( $\pi$ ) diverges) or  $\lambda = -1$  ( $\Psi(-1)$  diverges), that is,  $v_{\rm PT} = 1$ . For this particular case, the s-wave zero-energy radial function takes a relatively simple form [33],

$$u_0(r) = \frac{\tanh(\mu_{\rm PT} r)}{\tanh(\mu_{\rm PT} R)}.$$
 (118)

Taking its second derivative and substituting it in the radial equation confirms it is the appropriate solution. Then, we can readily calculate the effective range by integrating Eq. (56). In this case,  $g_0(r) = 1 - r/a = 1$ , so that

$$r_{0} = 2 \int_{0}^{R} dr \left[ 1 - \frac{\tanh^{2}(\mu_{\rm PT}r)}{\tanh^{2}(\mu_{\rm PT}R)} \right] = 2 \left[ R - \frac{R}{\tanh^{2}(\mu_{\rm PT}R)} + \frac{1}{\mu_{\rm PT}\tanh(\mu_{\rm PT}R)} \right].$$
 (119)

Since  $1/\mu_{\rm PT} \sim R$  and the  $\tanh(x)$  function converges rapidly to 1 as we increase x, we may set  $\tanh(\mu R) = 1$ . Thus we have that  $r_0 = 2/\mu_{\rm PT}$  for  $v_{\rm PT} = 1$  (unitarity).

### C. Gaussian

Many interactions in physical systems are modeled through Gaussians, and their convenience and usefulness cannot be overstated. We write the Gaussian potential as

$$V_{\rm g}(r) = -v_{\rm g} \frac{\hbar^2}{m_{\rm er}} \mu_{\rm g}^2 e^{-r^2 \mu_{\rm g}^2}.$$
 (120)

The comparison of this potential with the previous two is illustrated in Fig. 7. Although there are no analytical expressions for the scattering length and effective range in this case, numerical investigations in the literature provide benchmarks [34].

#### D. Lennard-Jones

To include in our analysis a potential that also contains repulsion, we considered the Lennard-Jones potential,

$$V_{\rm LJ}(r) = \frac{\hbar^2}{m_r} \left[ \frac{C_{12}}{r^{12}} - \frac{C_6}{r^6} \right],$$
 (121)

where  $C_{12}$  and  $C_6$  are constants responsible for the strength of the repulsive and attractive interactions, with units of [length]<sup>10</sup> and [length]<sup>4</sup>, respectively. In Fig. 8 we plot this potential for  $|a| \to \infty$ . The reader may be more familiarized with an alternative way of writing this potential,

$$V_{\rm LJ}(r) = 4\varepsilon_{\rm LJ} \left[ \left( \frac{\sigma_{\rm LJ}}{r} \right)^{12} - \left( \frac{\sigma_{\rm LJ}}{r} \right)^{6} \right], \tag{122}$$

but the conversion between the different constants is straightforward.

![](_page_15_Figure_22.jpeg)

FIG. 8. Same as Fig. 7, but for the Lennard-Jones potential. Differently from the other potentials, we observe a strong repulsive component near the origin.

Besides the repulsive part, the LJ potential differs from the others considered so far because it diverges for  $r \to 0$ .

Physically, the hard core near the origin prevents two particles from coming close together. This poses a numerical difficulty since  $V_{\rm LJ}(0)$  diverges. The boundary condition u(0)=0 certainly helps, but the potential at the neighboring site,  $V_{\rm LJ}(\Delta r)$ , is still large and may lead to numerical instabilities. Hence, the first step of the algorithm presented in Sec. III A 1 must be slightly changed to circumvent this problem. Since the potential is very large and positive near  $r\approx 0$ , it prevents the particles from coming close together, i.e.,  $u\approx 0$  in this region. For this reason, we define a range  $0\leqslant r< r_{\rm min}$  where u(r)=0 and start our integration at  $r=r_{\rm min}$ . After this is done, we may proceed as outlined in Sec. III A 1. Using dimensionless units, we found that taking  $r_{\rm min}$  such that  $V(r_{\rm min})\approx 10^{10}$  produces the desired results.

# E. Tuning the parameters

The four potentials we presented have two parameters. In the case of the purely attractive ones, one parameter is associated with the depth of the potential  $(v_{\rm sw}, v_{\rm PT}, {\rm and} v_{\rm g})$  and another with its range  $(\mu_{\rm sw}, \mu_{\rm PT}, {\rm and} \mu_{\rm g})$ . In contrast, for the LJ potential, they control the attractive  $(C_6)$  and repulsive  $(C_{12})$  components. The numerical procedure we described so far works if the two parameters are known. For example, they could be listed in the literature. However, the situation is often different: the scattering length and effective range are known, and we want to tune the parameters of a particular potential to reproduce the desired a and  $r_0$  values. Since we want to match two values and have two free parameters, the correspondence is one-to-one (with the restriction of how many bound states we want).

The Sec. III A 1 algorithm can still be used in this case, but we need to apply it repeatedly as we vary the two parameters. Let us denote the values of the two parameters by  $v_1$  and  $v_2$ . The first step is to start with a guess for  $v_1$  and  $v_2$  and then perform the procedure as described in Sec. III A 1 to obtain the scattering length and effective range. They will probably not be the desired values, but it is important to check the radial wave function to see if at least the number of bound states is what we expect. Typically, we want no bound states for a < 0 and one for a > 0, in other words, a nodeless u(r) for the first and one node for the latter, as depicted in Fig. 3. If the initial guess contains more bound states than desired, then we need to decrease the potential depth until we reach the target number. Then, a possible procedure is:

- 1. Start with a guess  $(v_1, v_2)$ .
- 2. Compute a and  $r_0$  as in Sec. III A 1.
- 3. Keep  $v_2$  fixed. Vary  $v_1$  until a has the desired value. Increasing the depth of the potential will decrease the value of the scattering length (until it diverges and changes from  $-\infty$  to  $+\infty$ ).

- 4. Keep  $v_1$  fixed at the value found in step 3. Vary  $v_2$  until  $r_0$  has the desired value. Increasing the range of the potential will increase  $r_0$ .
- 5. If a and  $r_0$  match the desired values, stop. Else, go to step 3 and use the value of  $v_2$  found in step 4.

We may implement this algorithm using two nested loops: one varies  $v_1$ , and the other runs  $v_2$ . It is helpful to define a tolerance for the numerical values of  $a^{\text{num}}$  and  $r_0^{\text{num}}$ , such that  $|a^{\text{num}} - a|$  and  $|r_0^{\text{num}} - r_0|$  are small quantities. After the procedure is done, checking the number of nodes of the radial function is necessary to guarantee that it is indeed the situation we wanted to reproduce.

### F. Results

Finally, applying the numerical procedure described so far to some concrete examples is instructive. The objective is twofold: we want to illustrate the method and provide some results so the reader can use them to check their program. We present 3 cases:  $a<0, |a|\to\infty$ , and a>0, which correspond to three very distinct physical situations.

As we pointed out in Sec. IIF 2, the universality in the low-energy scattering results is not specific to a single physics area so we can choose from several instances. We picked nuclear physics since two nucleon systems are excellent for illustrating low-energy scattering. There is no bound state in the region where a is negative. That is the case of two neutrons, with a scattering length of a = -18.5 fm and an effective range of  $r_0 = 2.7$  fm [9]. The region where a > 0 is interesting due to the appearance of the first bound state of the system, where lies the deuteron, a proton and a neutron, with a = 5.4 fm and  $r_0 = 1.7$  fm. The region where  $|a| \to \infty$ , often called unitary limit, is of great interest [8]. It does not occur naturally in nuclear physics, but we can still study its properties. Table II summarizes the physical situations we cover in this section.

TABLE II. Scattering length and effective range values that we want to reproduce with four forms of two-body potentials.

| System          | a  (fm)      | $r_0 \text{ (fm)}$ |
|-----------------|--------------|--------------------|
| Neutron-neutron | -18.5        | 2.7                |
| Unitarity       | $\pm \infty$ | 1.0                |
| Deuteron        | 5.4          | 1.7                |

As a side note, it is worth mentioning that most systems have their interactions fixed by what is observed in nature, such as the case of two neutrons, the deuteron, and countless other examples. Although it is possible to theoretically investigate the continuous variation of the scattering length from negative to positive values, we would like to see this happening in a physical system. In experiments with cold atoms, this is possible. A clever

method called Feshbach resonances [7] uses the manipulation of magnetic fields to vary the scattering length of the potential between two atoms. This allows the study of systems with scattering lengths of both signs and the unitarity limit between them.

We performed the procedure described in Sec. IV E to obtain the parameters, scattering lengths, and effective ranges presented in Tables III and IV. It is worth remembering that we can check the results for the spherical well against the analytical expressions, Eqs. (80) and (92). For the mPT, Eq. (117) provides a benchmark for the scattering length, and in Sec. IV B we show that r<sup>0</sup> = 2/µPT when |a| → ∞.

TABLE III. Parameters for the spherical well, modified P¨oschl-Teller, and Gaussian potentials that reproduce the desired scattering lengths and effective range.

| Potential       | v      | µ (fm−1<br>) | a (fm) | r0<br>(fm) |  |  |  |
|-----------------|--------|--------------|--------|------------|--|--|--|
| Neutron-neutron |        |              |        |            |  |  |  |
| Well            | 1.1096 | 0.3918       | −18.52 | 2.7        |  |  |  |
| mPT             | 0.9071 | 0.7991       | −18.51 | 2.7        |  |  |  |
| Gaussian 1.2121 |        | 0.5672       | −18.55 | 2.7        |  |  |  |
| Unitarity       |        |              |        |            |  |  |  |
| Well            | 1.2337 | 1.0000       | ∼ −105 | 1.0        |  |  |  |
| mPT             | 1.0000 | 2.0000       | ∼ 109  | 1.0        |  |  |  |
| Gaussian 1.3420 |        | 1.4349       | ∼ −105 | 1.0        |  |  |  |
| Deuteron        |        |              |        |            |  |  |  |
| Well            | 1.7575 | 0.5000       | 5.4    | 1.70       |  |  |  |
| mPT             | 1.4388 | 0.8631       | 5.4    | 1.73       |  |  |  |
| Gaussian 1.9102 |        | 0.6754       | 5.4    | 1.70       |  |  |  |

TABLE IV. Numerical results for the Lennard-Jones potential.

| System                                | (fm10)<br>C12 | (fm4<br>C6<br>)              | a (fm) | r0<br>(fm) |
|---------------------------------------|---------------|------------------------------|--------|------------|
| Neutron-neutron 3.08836698 9.86668911 |               |                              | −18.5  | 2.71       |
| Unitarity                             |               | 0.00034068 0.26462461 ∼ −105 |        | 1.00       |
| Deuteron                              |               | 0.90485319 6.81472000        | 5.4    | 1.70       |

The two-body potentials are very different in shape, as shown in Figs. 7 and 8. The fact that we can tune them to produce the same scattering length a and effective range r0, although remarkable, is directly related to the shape-independent approximation, Eq. (55). As the name suggests, this equation describes the s-wave phase shift δ0(k) as independent of the shape of the scattering potential.

Besides the values of a and r0, the numerical procedure produces the reduced radial wave functions u(r). In Fig. 9, we compare u(r) solved with the Numerov's method for the spherical well, modified P¨oschl-Teller, Gaussian, and Lennard-Jones potentials. They are in excellent agreement with analytical solutions, Eq. (90) for the spherical well, and Eq. (118) for the mPT at unitarity. For the same physical system, the functions differ inside the range of the potentials but are all the same outside, 1 − r/a.

![](_page_17_Figure_10.jpeg)

(a) Neutron-neutron: a = −18.5 fm and r<sup>0</sup> = 2.7 fm.

![](_page_17_Figure_12.jpeg)

(b) Unitarity: |a| → ∞ and r<sup>0</sup> = 1.0 fm.

![](_page_17_Figure_14.jpeg)

FIG. 9. Reduced radial solutions, u(r) = rA(r), of Schr¨odinger's equation with the proposed potentials for three different situations. The dashed curves correspond to the analytical solutions. Outside the range of the potential, large r, all solutions must be the same.

It is also possible to see the geometric interpretation of

the scattering length alluded to in Figs. 3a and 3b. For a<0, Fig. 9a, u(r) does not intercept the r-axis, and the scattering length is negative because the extrapolation of the reduced radial function intercepts the axis at a negative value. In Fig. 9c, u(r) intercepts the r-axis at the scattering length, thus a>0. Neither the reduced radial function nor its extrapolation intercept the axis at unitarity, since  $|a|\to\infty$ , Fig. 9b.

Finally, after obtaining the parameters for these three illustrative physical systems, it is interesting to investigate how the scattering length varies as we continuously vary the parameters of the potentials. In Fig. 10a, we present the ratio  $a/r_0$  as a function of the potential depth of the spherical well, modified Pöschl-Teller, and Gaussian potentials ( $v_{\rm sw}$ ,  $v_{\rm PT}$ , and  $v_{\rm g}$ ). Analytical expressions are only available for the first two, and it is possible to see that our numerical investigations are in excellent agreement with them.

To produce a similar figure for the Lennard-Jones case, we fixed the value of  $C_{12}/r_0^{10}=0.000341$  and varied  $C_6$ . We present the results in Fig. 10b. Although the behavior is qualitatively similar to the purely attractive potentials, the main difference is the region close to  $C_6\approx 0$  where the scattering length is positive. This is because, for  $C_6=0$ , the Lennard-Jones potential is purely repulsive. Then the scattering length is positive not due to a bound state but because the repulsive part "pushes" the wave function away from the origin, as depicted in Fig. 3c.

# V. CONCLUSIONS

This work presented quantum scattering theory fundamentals focusing on the low-energy limit. In this context, we aimed to introduce two significant quantities: the scattering length and the effective range. To illustrate how these two parameters behave in a concrete example, we derived analytical expressions for both in the case of the spherical well. We also showed how the energy of a bound state could be calculated using zero- and finite-range expressions applied to a <sup>4</sup>He dimer and the deuteron.

After introducing the main results of low-energy scattering theory, we proceeded with our main goal: describing a numerical procedure that can be used to compute the scattering length and effective range of any spherically symmetric finite-ranged two-body potential. We chose the spherical well, modified Pöschl-Teller, Gaussian, and Lennard-Jones potentials as examples. We then performed calculations related to three physical systems: two neutrons, unitarity, and the deuteron.

This work shows that these calculations are relevant and can be readily applied in atomic and nuclear physics. Hopefully, students can follow the procedure outlined in this manuscript, reproduce our results, extend them to their choice of physical systems, and apply the method to other potentials.

![](_page_18_Figure_8.jpeg)

(a) Spherical well, modified Pöschl-Teller, and Gaussian potentials.

![](_page_18_Figure_10.jpeg)

(b) Lennard-Jones potential.

FIG. 10. Scattering length behavior as a function of the interaction strength for the spherical well, modified Pöschl-Teller, Gaussian, and Lennard-Jones potentials. The dashed curves in (a) are the analytical solutions for the spherical well, Eq. (80), and for the modified Pöschl-Teller potential, Eq. (117).

# ACKNOWLEDGMENTS

This work was partially supported by the São Paulo Research Foundation (FAPESP) grant 2018/09191-7 (L.M.), and by the National Council for Scientific and Technological Development (CNPq) grants 383501/2022-9 (L.M.) and 131025/2022-8 (M.M.L.).

#### Appendix A: Scattering theory

### 1. Time-dependent formalism

We may treat interactions more simply in a formalism called interaction picture. We denote the time evolution of a state ket at an initial time  $t_0$  in the Schrödinger picture as

$$|\phi(t)\rangle_S = U_S(t, t_0)|\phi(t_0)\rangle_S,\tag{A1}$$

where  $| \rangle_S$  is a ket in the Schrödinger picture and  $U_S(t,t_0)$  is the time-evolution operator. If H is time independent, then  $U_S(t,t_0) = e^{-iH(t-t_0)/\hbar}$ . The interaction-picture state ket,  $| \rangle_I$ , is defined as

$$|\phi(t)\rangle_I = e^{iH_0t/\hbar}|\phi(t)\rangle_S.$$
 (A2)

The operators are defined as

$$A_I = e^{iH_0t/\hbar} A_S e^{-iH_0t/\hbar}.$$
 (A3)

The Schrödinger equation  $i\hbar \frac{\partial}{\partial t} |\phi(t)\rangle_S = H|\phi(t)\rangle_S$  may be written as

$$i\hbar \frac{\partial}{\partial t} |\phi(t)\rangle_I = V_I |\phi(t)\rangle_I,$$
 (A4)

where  $V_I = e^{iH_0(t-t_0)/\hbar}Ve^{-iH_0(t-t_0)/\hbar}$  is the potential in the interaction picture. Equation (A4) is a Schrödinger-like equation. The advantage is that we remove  $H_0$  from our calculations to consider the interaction. If V = 0,  $|\phi(t)\rangle_I$  is constant in time (and equal to  $|\phi(t_0)\rangle_S$ ). Similar to Eq. A1,  $|\phi(t)\rangle_I$  evolves in time as

$$|\phi(t)\rangle_I = U_I(t, t_0)|\phi(t_0)\rangle_I, \tag{A5}$$

where  $U_I(t,t_0)$  is defined as

$$U_I(t, t_0) = e^{iH_0 t/\hbar} U_S(t, t_0) e^{-iH_0 t_0/\hbar}$$
 (A6)

and obeys the Schrödinger-like equation

$$i\hbar \frac{\partial}{\partial t} U_I(t, t_0) = V_I(t) U_I(t, t_0).$$
 (A7)

The solution of Eq. A7 may be formally written as

$$U_I(t, t_0) = 1 - \frac{i}{\hbar} \int_{t_0}^t dt' V_I(t') U_I(t', t_0), \tag{A8}$$

for the required initial condition  $U_I(t_0, t_0) = 1$ . Our goal is to calculate the evolution of the state in a distant past  $t_0 \to -\infty$ , that is,  $|\phi(t \to -\infty)\rangle = |i\rangle$ . Nevertheless, equation (A8) is only valid for finite times t and  $t_0$  and so setting  $U_I(t, -\infty)$  would lead to convergence problems. To avoid it, we will give meaning to  $U_I(t, -\infty)$  by writing it as [35] (proof in Appendix B),

$$U_I(t, -\infty) = \lim_{t_0 \to -\infty} U_I(t, t_0) = \lim_{\epsilon \to 0} \epsilon \int_{-\infty}^0 dt' \, e^{\epsilon t'} U_I(t, t'),$$
(A9)

where  $U_I(t,t')$  is defined as in eq. (A6). Despite our time-dependent treatment, we recall that H is time-independent. Thus  $U_S(t,t') = e^{-iH(t-t')/\hbar}$ . The state vector at a time t=0 is given by

$$|\phi(t=0)\rangle_I = U_I(0,-\infty)|i\rangle, \tag{A10}$$

where

$$U_I(0, -\infty) = \lim_{\epsilon \to 0} \epsilon \int_{-\infty}^0 dt' \, e^{\epsilon t'} e^{iHt'/\hbar} e^{-iH_0t'/\hbar}. \quad (A11)$$

Now applying it to equation (A10):

$$|\phi(t=0)\rangle_{I} = \lim_{\epsilon \to 0} \epsilon \int_{-\infty}^{0} dt' \, e^{\epsilon t'} e^{i(H-E_{i})t'/\hbar} |i\rangle = \lim_{\epsilon \to 0} \frac{i\epsilon}{E_{-} - H + i\epsilon} |i\rangle. \tag{A12}$$

Using the identity (proof in Appendix C)

$$\begin{split} \frac{1}{E_i - H + i\epsilon} - \frac{1}{E_i - H_0 + i\epsilon} &= \\ \frac{1}{E_i - H_0 + i\epsilon} V \frac{1}{E_i - H + i\epsilon}, \end{split} \tag{A13}$$

we rewrite Eq. (A12) as

$$|\phi(t=0)\rangle_{I} = \lim_{\epsilon \to 0} \frac{i\epsilon}{E_{i} - H_{0} + i\epsilon} |i\rangle + \frac{1}{E_{i} - H_{0} + i\epsilon} V \frac{i\epsilon}{E_{i} - H + i\epsilon} |i\rangle = \lim_{\epsilon \to 0} \frac{i\epsilon}{E_{i} - H_{0} + i\epsilon} |i\rangle + \frac{1}{E_{i} - H_{0} + i\epsilon} V |\phi(t=0)\rangle_{I}$$
(A14)

Since  $|i\rangle$  is an eigenfunction of  $H_0$  (it satisfies  $H_0|i\rangle = E_i|i\rangle$ ), the first term in the RHS is the identity operator. Then we can write

$$|\psi\rangle = |i\rangle + \frac{1}{E_i - H_0 + i\epsilon} V |\psi\rangle,$$
 (A15)

where we left off the notation  $|\phi(t=0)\rangle$  to emphasize that this is an actual time-independent problem. This is know as the Lippmann-Schwinger equation.

Back to the time-dependent formulation, the state vector at any time t could be obtained by the sequential relation of the time translation operator:  $U_I(t,t_0) = U_I(t,t')U_I(t',t_0)$ , so

$$|\phi(t)\rangle = U_I(t,0)|\phi(0)\rangle = U_I(t,-\infty)|i\rangle.$$
 (A16)

In a distant future, that is, setting  $t \to +\infty$ , we write

$$|f\rangle = S|i\rangle,\tag{A17}$$

where  $|\phi(t\to +\infty)\rangle$  is our asymptotic final state  $|f\rangle$  and the scattering matrix (or S matrix) is defined as

$$S \equiv U_I(+\infty, -\infty). \tag{A18}$$

Equation (A17) asserts that the action of the S matrix on an initial state (that exists asymptotically for  $t_0 \to -\infty$ ) transforms the ket  $|i\rangle$  into a final state that exists in a distant future  $t \to +\infty$ . That is, some sort of scattering

occurred between t and  $t_0$ . Furthermore, Eq. (A15) may be written as the power series expansion

$$|\psi\rangle = |i\rangle + G_{+}V|i\rangle + G_{+}VG_{+}V|i\rangle + \dots$$
$$= |i\rangle + G_{+}(V + VG_{+}V + \dots)|i\rangle,$$

where  $G_+ \equiv (E_i - H_0 + i\epsilon)^{-1}$ .

We define the transition matrix T as the perturbative series

$$T \equiv V + VG_{+}V + VG_{+}VG_{+}V + ..., \tag{A19}$$

which is often called the Dyson series. We may write the scattering state as

$$|\psi\rangle = |i\rangle + G_{+}T|i\rangle.$$
 (A20)

The consequence is that

$$V|\psi\rangle = T|i\rangle. \tag{A21}$$

The perturbative character of Eq. (A19) relates the T-matrix to being a species of a generalized potential, where in a first-order perturbation T and V are equivalent and thus  $|\psi\rangle \approx |i\rangle$ . This is known as the first-order Born approximation [3].

# 2. Scattering theory integral equations

Now we focus on the physical implications of Eq. (A15). Writing  $|\psi\rangle$  in the position basis and inserting a complete set of position states between  $G_+$  and V leads to the integral equation

$$\langle \mathbf{r} | \psi \rangle = \langle \mathbf{r} | i \rangle + \int d^3 \mathbf{r}' \langle \mathbf{r} | G_+ | \mathbf{r}' \rangle \langle \mathbf{r}' | V | \psi \rangle, \quad (A22)$$

where we must calculate the function

$$G_{+}(\mathbf{r}, \mathbf{r}') \equiv \frac{\hbar^2}{2m} \left\langle \mathbf{r} \left| \frac{1}{E - H_0 + i\epsilon} \right| \mathbf{r}' \right\rangle.$$
 (A23)

Recalling that the momentum basis  $\{|\mathbf{k}\rangle\}$  set elements are eigenstates of  $H_0$  with eigenvalues  $\hbar^2 \mathbf{k}^2 / 2m$ , Eq. (1), we may insert this discrete basis by writing

$$G_{+}(\mathbf{r}, \mathbf{r}') = \frac{\hbar^{2}}{2m} \sum_{\mathbf{k}', \mathbf{k}''} \langle \mathbf{r} | \mathbf{k}' \rangle \left\langle \mathbf{k}' \left| \frac{1}{E - H_{0} + i\epsilon} \right| \mathbf{k}'' \right\rangle \langle \mathbf{k}'' | \mathbf{r}' \rangle.$$
(A24)

The quantized plane waves in the position representation are written as

$$\langle \mathbf{r} | \mathbf{k} \rangle = \frac{e^{i\mathbf{k} \cdot \mathbf{r}}}{L^{3/2}} \text{ and } \langle \mathbf{k} | \mathbf{r} \rangle = \frac{e^{-i\mathbf{k} \cdot \mathbf{r}}}{L^{3/2}}.$$
 (A25)

Now by letting  $H_0$  act on  $\langle \mathbf{k}' |$  and noting that  $\langle \mathbf{k}' | \mathbf{k}'' \rangle = \delta_{\mathbf{k}'\mathbf{k}''}$  and  $E = \hbar^2 k^2 / 2m$ ,

$$G_{+}(\mathbf{r}, \mathbf{r}') = \frac{1}{L^{3}} \sum_{\mathbf{k}'} \frac{e^{i\mathbf{k}' \cdot (\mathbf{r} - \mathbf{r}')}}{k^{2} - k'^{2} + i\epsilon}, \quad (A26)$$

where we absorbed the factor  $2m/\hbar^2$  into  $\epsilon$ .

We are left with a sum in k-space, a discrete space. Due to periodic boundary conditions, each  $k_i$  (i=x,y,z) is located at  $k_i=2\pi n_i/L$ , where  $n_i=0,1,2,3...$  That is,  $\{k\}=\{0,2\pi/L,4\pi/L,...\}$ . The distance between each point in the k-space is  $\Delta k=2\pi/L$ . We must take  $L\to\infty$  to guarantee the required continuous character. For this reason, the separation between points is very small compared to L ( $\Delta k\approx 0$ ). The summation in  ${\bf k}$  may be taken to be over a continuous space. We may substitute the sum with an integral,

$$\sum_{\mathbf{k}'} \to \int \rho(k) d^3 \mathbf{k}' = \frac{L^3}{(2\pi)^3} \int d^3 \mathbf{k}', \qquad (A27)$$

where the factor  $\rho(k) = L^3/(2\pi)^3$  is the k-density in 3 dimensions. The function becomes

$$G_{+}(\mathbf{r}, \mathbf{r}') = \frac{1}{(2\pi)^3} \int d^3 \mathbf{k}' \frac{e^{i\mathbf{k}' \cdot (\mathbf{r} - \mathbf{r}')}}{k^2 - k'^2 + i\epsilon}.$$
 (A28)

We may perform this integration by choosing spherical coordinates  $(k', \theta, \phi)$  and, without loss of generalization, we may let the vector  $(\mathbf{r} - \mathbf{r}')$  lie along the  $k'_z$  axis so that  $\mathbf{k}' \cdot (\mathbf{r} - \mathbf{r}') = k' |\mathbf{r} - \mathbf{r}'| \cos \theta$ . We then write

$$G_{+}(\mathbf{r}, \mathbf{r}') = \frac{1}{(2\pi)^{2}} \int_{0}^{\infty} dk' k'^{2} \int_{0}^{\pi} d\theta \frac{e^{ik'|\mathbf{r} - \mathbf{r}'|\cos\theta}}{k^{2} - k'^{2} + i\epsilon}$$

$$= \frac{1}{4\pi^{2}|\mathbf{r} - \mathbf{r}'|} \int_{-\infty}^{\infty} dk' \frac{k'\sin(k'|\mathbf{r} - \mathbf{r}'|)}{k^{2} - k'^{2} + i\epsilon},$$
(A29)

where we note that the integrand is even. We also note a pole in  $k' = \pm \sqrt{k^2 + i\epsilon}$ . It would make it ambiguous if we chose to take  $\epsilon \to 0$  before evaluating the integral. Luckily, the pole is not on the real axis as  $\pm \sqrt{k^2 + i\epsilon} \approx k + i\epsilon/2k + \epsilon^2/8k^3 + ...$ , which gives meaning to the integration process. Ignoring terms higher than  $\epsilon^2$  and redefining  $\epsilon/2k \to \epsilon$ , we may factorize  $(k^2 - k'^2 + i\epsilon) = -(k' - k - i\epsilon)(k' + k + i\epsilon)$ . The integral is then

$$G_{+}(\mathbf{r}, \mathbf{r}') = \frac{1}{8i\pi^{2}|\mathbf{r} - \mathbf{r}'|} \int_{-\infty}^{\infty} dk' \frac{k'(e^{-ik'|\mathbf{r} - \mathbf{r}'|} - e^{ik'|\mathbf{r} - \mathbf{r}'|})}{(k' - k - i\epsilon)(k' + k + i\epsilon)}.$$
(A30)

We should let k' momentarily be a complex variable to carry out this integration and use the residue theorem [21]. Consider the paths in Fig. 11. The closed path integral may be written as the sum

$$\oint_{\Gamma_R} = \int_{\gamma_R} + \int_{C_R} = 2\pi i \times \sum_j \text{Res}\{k'; j\}, \quad (A31)$$

where the integral in the closed contour  $\Gamma_R$  is  $2\pi i$  times the sum of the residues  $\mathrm{Res}\{k';j\}$  due to poles j enclosed by the curve, and the integral through the path  $\gamma_R$  is zero due to Jordan's lemma. The only pole inside  $\Gamma_R^{\pm}$  is  $k \pm i\epsilon$ .

The residues may be calculated as follows

$$\operatorname{Res}\{k'; k + i\epsilon\} =$$

$$\lim_{\substack{k' \to k + i\epsilon \\ \epsilon \to 0}} (k' - k - i\epsilon) \frac{k' e^{ik'|\mathbf{r} - \mathbf{r}'|}}{(k' - k - i\epsilon)(k' + k + i\epsilon)} = \frac{e^{ik|\mathbf{r} - \mathbf{r}'|}}{2},$$
(A32)

$$\operatorname{Res}\{k'; -k - i\epsilon\} =$$

$$\lim_{\substack{k' \to -k - i\epsilon \\ \epsilon \to 0}} (k' + k + i\epsilon) \frac{k'e^{-ik'|\mathbf{r} - \mathbf{r}'|}}{(k' - k - i\epsilon)(k' + k + i\epsilon)} = \frac{e^{ik|\mathbf{r} - \mathbf{r}'|}}{2}.$$
(A33)

The integral through the real axis  $C_R$  is

$$\lim_{R \to \infty} \int_{-R}^{R} dk' \frac{k'(e^{-ik'|\mathbf{r} - \mathbf{r}'|} - e^{ik'|\mathbf{r} - \mathbf{r}'|})}{(k' - k - i\epsilon)(k' + k + i\epsilon)} = 2\pi i \times e^{ik|\mathbf{r} - \mathbf{r}'|}.$$
(A34)

Thus

$$G_{+}(\mathbf{r}, \mathbf{r}') = \frac{1}{4\pi} \frac{e^{ik|\mathbf{r} - \mathbf{r}'|}}{|\mathbf{r} - \mathbf{r}'|}.$$
 (A35)

Returning to Eq. (A22):

$$\langle \mathbf{r} | \psi \rangle = \langle \mathbf{r} | i \rangle - \frac{2m}{\hbar^2} \int d^3 \mathbf{r}' \frac{1}{4\pi} \frac{e^{ik|\mathbf{r} - \mathbf{r}'|}}{|\mathbf{r} - \mathbf{r}'|} \langle \mathbf{r}' | V | \psi \rangle. \quad (A36)$$

Considering the potential  $V(\mathbf{r}')$  to be local, that is,

$$\langle \mathbf{r}' | V | \mathbf{r}'' \rangle = V(\mathbf{r}') \delta(\mathbf{r}' - \mathbf{r}'').$$
 (A37)

This allows us to write

$$\langle \mathbf{r} | \psi \rangle = \langle \mathbf{r} | i \rangle - \frac{2m}{\hbar^2} \int d^3 \mathbf{r}' \frac{1}{4\pi} \frac{e^{ik|\mathbf{r} - \mathbf{r}'|}}{|\mathbf{r} - \mathbf{r}'|} V(\mathbf{r}') \langle \mathbf{r}' | \psi \rangle.$$
(A38)

We now restrict ourselves to cases where the potential is of a finite range. This condition is important because the scattering is observed far away from the scattering center. We are interested in measurements at large distances  $|\mathbf{r}| \gg |\mathbf{r}'|$ . In this regime,

$$e^{ik|\mathbf{r}-\mathbf{r}'|} \approx e^{ikr}e^{-i\mathbf{k}'\cdot\mathbf{r}'},$$
 (A39)

where  $r \equiv |\mathbf{r}|$ . Furthermore, we now specify that our initial state is  $|i\rangle = |\mathbf{k}\rangle$  and  $\langle \mathbf{r}|\mathbf{k}\rangle = e^{i\mathbf{k}\cdot\mathbf{r}}/L^{3/2}$ . Finally, we arrive at the form

$$\psi(\mathbf{r}, \theta) \xrightarrow{\text{large } r} \frac{1}{L^{3/2}} \left[ e^{i\mathbf{k}\cdot\mathbf{r}} + \frac{e^{ikr}}{r} f(\mathbf{k}', \mathbf{k}) \right], \quad (A40)$$

where

$$f(\mathbf{k}', \mathbf{k}) = -\frac{mL^3}{2\pi\hbar^2} \int d^3x' \langle \mathbf{k}' | \mathbf{r}' \rangle V(\mathbf{r}') \langle \mathbf{r}' | \psi \rangle \quad (A41)$$

is referred to as the scattering amplitude.

![](_page_21_Figure_23.jpeg)

(a) Upper plane path where  $e^{ik|\mathbf{r}-\mathbf{r'}|} \to 0$ .

![](_page_21_Figure_25.jpeg)

(b) Lower plane path where  $e^{-ik|\mathbf{r}-\mathbf{r}'|} \to 0$ .

FIG. 11. Paths to calculate the integral (A30). We must choose the upper plane path  $\Gamma_R^+$  for  $e^{+ik'|\mathbf{r}-\mathbf{r}'|}$  because  $e^{+ik'|\mathbf{r}-\mathbf{r}'|} \to 0$  as Im k' takes  $+\infty$  values. Similarly, we choose the lower plane path  $\Gamma_R^-$  for  $e^{-ik'|\mathbf{r}-\mathbf{r}'|}$  because  $e^{-ik'|\mathbf{r}-\mathbf{r}'|} \to 0$  as Im k' takes  $-\infty$  values. This makes the integration in  $\gamma_R^{\pm}$  go to 0, and we are left with the path  $C_R$ , which lies in the axis Re k'. That is, the closed path  $\Gamma_R^{\pm}$  is equal to the real integral (A30).

#### Appendix B

We follow a procedure present in Ref. [36]. Consider a well-behaved function f(t) such that

$$\lim_{t_0 \to -\infty} f(t_0) = f(-\infty).$$
 (B1)

Now consider

$$\lim_{\epsilon \to 0} \epsilon \int_{-\infty}^{0} dt' \, e^{\epsilon t'} f(t'), \tag{B2}$$

where  $\epsilon \ll 1$ . Integrating by parts leads to

$$\lim_{\epsilon \to 0} \epsilon \int_{-\infty}^{0} dt' \, e^{\epsilon t'} f(t') =$$

$$\left[ f(t') e^{\epsilon t'} \right]_{-\infty}^{0} - \lim_{\epsilon \to 0} \int_{-\infty}^{0} dt' \, \frac{df}{dt'} e^{\epsilon t'}$$

$$= f(0) - \int_{-\infty}^{0} dt' \, \frac{df}{dt'} = f(-\infty). \tag{B3}$$

Thus, we have the equality

$$\lim_{t_0 \to -\infty} f(t_0) = \lim_{\epsilon \to 0} \epsilon \int_{-\infty}^{0} dt' \, e^{\epsilon t'} f(t'). \tag{B4}$$

We may apply this prescription to the time evolution operator to give a mathematical meaning to  $U_I(t, -\infty)$  or  $U_I(+\infty, t)$ . Thus

$$U_I(t, -\infty) = \lim_{\epsilon \to 0} \epsilon \int_{-\infty}^0 dt' \, e^{\epsilon t'} U_I(t, t'), \tag{B5}$$

$$U_I(+\infty, t_0) = \lim_{\epsilon \to 0} \epsilon \int_0^{+\infty} dt' \, e^{-\epsilon t'} U_I(t', t_0).$$
 (B6)

## Appendix C

By defining  $G = (E_i - H + i\epsilon)^{-1}$  and  $G_0 = (E_i - H_0 + i\epsilon)^{-1}$  and noting that  $G_0^{-1} - G^{-1} = H - H_0 = V$ , we take the difference  $G - G_0$  as

$$G - G_0 = (G_0 G_0^{-1})G - G_0(G^{-1}G) =$$

$$G_0(G_0^{-1} - G^{-1})G = G_0 VG,$$
(C1)

which is the identity in Eq. (A13):

$$\frac{1}{E_i - H + i\epsilon} - \frac{1}{E_i - H_0 + i\epsilon} = \frac{1}{E_i - H_0 + i\epsilon} V \frac{1}{E_i - H + i\epsilon}.$$
 (C2)

Alternatively, we can also write

$$G - G_0 = G(G_0^{-1}G_0) - (GG^{-1})G_0 =$$

$$G(G_0^{-1} - G^{-1})G_0 = GVG_0,$$
(C3)

which results in

$$\frac{1}{E_i - H + i\epsilon} - \frac{1}{E_i - H_0 + i\epsilon} = \frac{1}{E_i - H + i\epsilon} V \frac{1}{E_i - H_0 + i\epsilon}.$$
 (C4)

- [1] D.J. Griffiths, Introduction to Quantum Mechanics (Cambridge University Press, Cambridge, 2018).
- [2] R.G. Newton, Scattering Theory of Waves and Particles (Dover Publications, Mineola, 2013).
- [3] J.J. Sakurai and J. Napolitano, Modern Quantum Mechanics (Oxford University Press, Oxford, 2014).
- [4] H.A. Bethe, Physical Review **76**, 1 (1949).
- [5] L.S. Rodberg and R.M. Thaler, Introduction to the Quantum Theory of Scattering (Academic Press, Cambridge, 1967).
- [6] L.B. Madsen, American Journal of Physics 70, 8 (2002).
- [7] A.J. Moerdijk, B.J. Verhaar and A. Axelsson, Physical Review A 51, 6 (1995).
- [8] M. Randeria and E. Taylor, Annual Review of Condensed Matter Physics 5, 1 (2014).
- [9] A. Gezerlis and J. Carlson, Physical Review C 77, 3 (2008).
- [10] G.C. Strinati, P. Pieri, G.Röpke, P. Schuck and M. Urban, Physics Reports 738, 1 (2018).
- [11] L. Madeira and V.S. Bagnato, Brazilian Journal of Physics 51, 2 (2021).
- [12] M.A.C. Ribeiro, V.C Franzoni, W.R. Passos, E.C. Silva and A.N.F. Aleixo, Revista Brasileira de Ensino de Fisica 26, 1 (2004).
- [13] A.S. Castro, Revista Brasileira de Ensino de Fisica **33**, 4 (2011).
- [14] L. Rizzi, O.F. Piattella, S.L. Cacciatori and V. Gorini, Revista Brasileira de Ensino de Fisica 38, 2 (2016).

- [15] E.O.A Landim and A.F.R. Rodrigues, Revista Brasileira de Ensino de Fisica 44, e20210338 (2022).
- [16] L.M. Cavalcanti, Revista Brasileira de Ensino de Fisica 21, 336 (1999).
- [17] J. Pera and J. Boronat, American Journal of Physics 91, 90 (2023).
- [18] L.B. Carvalho, W.C. Santos and E.A. Correa, Revista Brasileira de Ensino de Fisica, 41, 4 (2019).
- [19] V.D. Viterbo, N.H.T. Lemes and J.P. Braga, Revista Brasileira de Ensino de Fisica 36, 1 (2014).
- [20] F. Caruso and V. Oguri, Revista Brasileira de Ensino de Física 36, 2 (2014).
- [21] G.B. Arfken and H.J. Weber, Mathematical Methods for Physicists (Elsevier Academic Press, Cambridge, 2005).
- [22] W. Cencek, M. Przybytek, J. Komasa, J.B. Mehl, B. Jeziorski and K. Szalewicz, The Journal of Chemical Physics 136, 22 (2012).
- [23] R.W. Hackenburg, Physical Review C 73, 4 (2006).
- [24] M.J. Jamieson, A. Dalgarno and M. Kimura, Physical Review A 51, 3 (1995).
- [25] A.R. Janzen and R.A. Aziz, The Journal of Chemical Physics 103, 22 (1995).
- [26] E. Tiesinga, P.J. Mohr, D.B. Newell and B.N. Taylor, CODATA Internationally recommended 2018 values of the Fundamental Physical Constants, available in: http://physics.nist.gov/constants
- [27] N. Giordano and H. Nakanishi, Computational Physics (Prentice Hall, London, 2005).

- [28] W.H. Press, S.A. Teukolsky, W.T. Vetterling and B.P. Flannery, Numerical Recipes in Fortran 77: The Art of Scientific Computing (Cambridge University Press, Cambridge, 1996).
- [29] J. Carlson, S. Chang, V. Pandharipande and K. Schmidt, Physical Review Letters 91, 5 (2003).
- [30] S. F¨ugge, Practical Quantum Mechanics (Springer, Berlin, 1994).
- [31] L. Madeira, S. Gandolfi, K.E. Schmidt and V.S. Bagnato, Physical Review C 100, 1 (2019).
- [32] M. Abramowitz and I.A. Stegun, Handbook of Mathematical Functions (Dover Publications, Mineola, 1965).
- [33] L.D. Landau and E.M. Lifschitz, Quantum Mechanics(Non-Relativistic Theory) (Pergamon Press, Oxford, 1977).
- [34] P. Jeszenszki, A.Y. Cherny and J. Brand, Physical Review A 97, 4 (2018).
- [35] M. Gell-Mann and M.L. Goldberger, Physical Review 91, 2 (1953).
- [36] P. Roman, Advanced Quantum Theory (Addison-Wesley, Reading, 1965).