# POLYNOMIAL IDENTITIES AND HAUPTMODULN

#### By W. W. STOTHERS

[Received 22nd July 1980]

Let f(z) be a non-zero polynomial. Write k(f) for the leading coefficient, d(f) for the degree and c(f) for the number of distinct zeros of f over an algebraic closure of the field of definition.

In [2], Birch et al. made conjectures about  $d(f^3 - g^2)$ , where f and g are non-constant polynomials such that  $f^3 \neq g^2$ . The first was proved by Davenport [4] who showed that, for such polynomials,

$$d(f^3 - g^2) \ge \frac{1}{2}d(f) + 1. \tag{1}$$

We prove a generalisation of (1) and discuss the cases of equality, proving another two of the conjectures (viz. 2a, 2b). Our methods are based on those of [1].

#### 1. Inequality and equality

THEOREM 1.1. Suppose that  $p, q \in \mathbb{C}[z]$  with k(p) = k(q), d(p) = d(q) > 0 and (p, q) = 1. Then

$$c(p)+c(q)+c(p-q) \ge d(p)+1,$$
 (2)

with equality if and only if the non-trivial branch points of

$$R(z, w) = (1-w)p(z) + wq(z) = 0$$

lie over  $w \in \{0, 1, \infty\}$ .

**Proof.** Since (p, q) = 1, R(z, w) is irreducible over  $\mathbb{C}[z, w]$ , so that R = 0 defines a d(p)-sheeted covering  $\Re$  of the w-sphere. When  $z \in \Re$  lies over w, write n(z, w) for the order of z as a branch point (z is trivial when n(z, w) = 1). For z over  $w \in \mathbb{C}$ , n(z, w) is equal to the multiplicity of z as a zero of R(z, w). The z over  $w = \infty$  are  $z = \infty$ , with  $n(\infty, \infty) = d(p) - d(p - q)$ , and the zeros of p - q. For all w, we put

$$S(w) = \sum \{n(z, w) - 1\},$$

where the sum is over all z over w. Clearly,  $S(w) \ge 0$  with equality if and only if all such z are trivial.

On  $\Re$ , w = p(z)/(p(z) - q(z)), so  $\Re$  has genus zero. Then by [15], p. 150

$$\sum_{\mathbf{w} \in \mathbb{C}^*} S(\mathbf{w}) = 2d(p) - 2. \tag{3}$$

Ouart. J. Math. Oxford (2), 32 (1981), 349-370

Now, S(0) = d(p) - c(p), S(1) = d(q) - c(q) = d(p) - c(q) and  $S(\infty) = (d(p) - d(p-q) - 1) + d(p-q) - c(p-q) = d(p) - c(p-q) - 1$ . If we ignore all other terms on the left of (3), we get the inequality (2). Further, we have equality if and only if all other S(w) are zero. This is equivalent to the stated condition.

DEFINITION. A pair [p, q] of complex polynomials is special (of degree n) if p, q satisfy the hypotheses of Theorem 1.1 and give equality in (2) (and d(p) (= d(q)) = n).

THEOREM 1.2. Suppose that p and q are distinct, non-constant complex polynomials. Then

$$d(p-q) \ge d(p) - c(p) - c(q) + 1,$$
 (4)

with equality if and only if (i) [p, q] is a special pair, and (ii) p-q has distinct zeros.

**Proof.** Suppose first that  $d(p) \neq d(q)$  or  $k(p) \neq k(q)$ . Then  $d(p-q) \ge d(p)$ . Since p, q are non-constant, c(p),  $c(q) \ge 1$ , so that we have *strict* inequality in (4).

Now suppose that d(p) = d(q) and k(p) = k(q). If (p, q) = 1, then 1.1 applies. Now,  $d(p-q) \ge c(p-q)$ , with equality if and only if p-q has distinct zeros. Thus (4) holds with equality if and only if (i) and (ii) hold. If (p, q) = r, with d(r) > 0, then 1.1 applies to p/r and q/r. Then, as before,

$$c(p/r) + c(q/r) \ge d(p/r) - d((p-q)/r) + 1 = d(p) - d(p-q) + 1.$$

As (p/r, q/r) = 1, each zero of r is a zero of at most one of p/r, q/r. Hence,

$$c(p)+c(q) \ge c(p/r)+c(q/r)+c(r) > c(p/r)+c(q/r).$$

Thus we get strict inequality when p and q are not coprime.

DEFINITION. A pair of complex polynomials is extra-special (of degree n) if they give equality in (4) (and each has degree n).

THEOREM 1.3. Suppose that f and g are non-constant complex polynomials with  $f^3 \neq g^2$ . Then (1) holds, with equality if and only if (i)  $[f^3, g^2]$  is an extra-special pair, and (ii) f has distinct zeros.

*Proof.* If  $d(f^3) \neq d(g^2)$ , then we get strict inequality in (1) as  $d(f) \ge 1$ . Now suppose that there is a positive integer r with d(f) = 2r, d(g) = 3r. As  $f^3$  and  $g^2$  are non-constant, 1.2 gives

$$d(f^3-g^2) \ge d(f^3)-c(f^3)-c(g^2)+1$$

with equality if and only if (i) holds. Now,  $c(f^3) = c(f) \le 2r$  and  $c(g^3) = c(g) \le 3r$ , so that

$$d(f^3-g^2) \ge 3.2r-2r-3r+1=r+1=\frac{1}{2}d(f)+1$$

with equality if and only if (i) holds *and c(f)* = 2r (= *d(f))* and c(g) = 3r ( = d(g)). The latter is equivalent to (ii), as (/, g) = 1.

This includes Davenport's result. Clearly the result holds for any field of characteristic zero. A form has been proved by Dr. S. D. Cohen (Glasgow) for a field of non-zero characteristic. We have given the above proof since it leads more naturally to the next section.

## **2. Subgroups and Hanptmodnln**

In this section, we follow §2 of [1].

Let T = *(A, B, C: ABC* = 1). Then T can be realised as a discrete group of transformations of the hyperbolic plane *X* in such a way that A, *B* and C are parabolic. By conjugation within *PSL(2,* R), we may assume that C(T) = T + 2, so *C* fixes °° and a> = exp *{mr}* is a local variable at T = <». The surface *X/T* has genus zero. Let *w* = W(T) by the Hauptmodul with <sup>w</sup>(oo) = oo and W(T) = 0 (resp. 1) at the fixed point of A (resp. B). Then, arguing as for Theorem 2.1 of [1], we have

THEOREM 2.1. A *function z(r) is an automorphic function for a subgroup of finite index in T if and only if*

- (1) *there is an irreducible polynomial ReC[z,* w] *such that R(z(r),* W(T)) = 0, *and*
  - (2) *R(z,* w) = 0 *has all non-trivial branch points over* we{0,1,°°}.

Suppose that *G* is a subgroup of index n in T and that *X/G* has genus zero. Then we can choose a Hauptmodul Z(T) with z(°°) = «>. We note that, if Zj is another such Hauptmodul, then there are constants a, *(i* with a^O and

$$z_1 = \alpha z + \beta$$
.

As w is an automorphic function for T (and hence for *G),* there are coprime polynomials *p(z), u(z)* with *w = p(z)/u(z).* As w(<») = z(°°) = °°, *d(p)>d(u).* As *\G: T\* = *n, d(p)* = *n.* Since *X/G,* as a covering of *X/T,* is branched only over {0,1,<»}, *[p,p — u]* is a special pair of degree *n.* Further, the multiplicities of the zeros of u are the orders of the finite branch points over *w* = °°. Hence, [p, p - u] is extra-special if and only if all of these branch points are trivial.

DEFINITION. A subgroup G of T is *special (of index n)* if *X/G* has genus zero (and *\G: T\ = n).* A subgroup is *extra-special* if, in addition, *X/G* has trivial branching at the finite points over °° on *X/T.*

DEFINITION. TWO pairs [p, *q]* and [r, *s]* of complex polynomials are oo-equivalent if there exist complex numbers a, ft *y* with a, *y* non-zero and

$$p(z) = \gamma^{d(p)} r(\alpha z + \beta), \qquad q(z) = \gamma^{d(q)} s(\alpha z + \beta). \tag{5}$$

Observe that, if [p, q] is special (resp. extra-special) then the  $\infty$ -class  $\{[p, q]\}$  consists entirely of special (resp. extra-special) pairs.

The discussion above shows that a special (resp. extra-special) subgroup of index n gives rise to an  $\infty$ -class of special (resp. extra-special) pairs of degree n.

To go in the other direction, it is convenient to introduce a (partial) normalisation on special pairs. Suppose that [r, s] is special of degree n, that  $r(z) = \rho z^n + \sigma z^{n-1} + \cdots$ , and that  $r(z) - s(z) = \delta z^n + \cdots$ ,  $\delta \neq 0$ . Let  $\alpha$  be an (n-e)th root of  $(\delta/\rho)$  and put  $\gamma^{d(\rho)} = 1/\rho \alpha^n$ ,  $\beta = -\sigma/\rho n$ . Then [p, q] defined by (5) is in  $\{(r, s)\}$ , has p, q and p-q monic and

$$p(z) = z^n + O(z^{n-2}).$$
 (6)

We note that we could replace  $\alpha$  by  $\alpha \zeta^m$ , where  $\zeta = \exp \{2\pi i/(n-e)\}$  and m is an integer, without affecting the form of p, q.

DEFINITION. A special pair [p, q] is standardised if p, q and p-q are monic and p satisfies (6).

Each  $\infty$ -class of special pairs contains finitely many standardised pairs. This algebraic definition differs from the normalisation in [1], but has advantages in 2.4 below.

Suppose that [p,q] is a standardised special pair of degree n, and let  $z(\tau)$  be determined by (1-w)p(z)+wq(z)=0. Comparing the condition in 1.1 with (2) of 2.1,  $z(\tau)$  is an automorphic function for a subgroup G. The branch points over w=0 (resp. 1) have orders equal to the multiplicities of the zeros of p(z) (resp. q(z)). Those over  $w=\infty$  are at  $z=\infty$ , with order n-e where e=d(p-q), and at the zeros of p-q. As w=p/(p-q),  $\mathbb{C}(z,w)=\mathbb{C}(z)$ , so that  $\mathcal{U}/G$  has genus zero and  $z(\tau)$  is a Hauptmodul with  $z(\infty)=\infty$ . Also |G:T|=n. A local variable at  $\infty$  on  $\mathcal{U}/G$  is  $\xi=\exp\{\pi i\tau/(n-e)\}$ . If  $w=\delta w^{-1}+O(1)$ , then  $z=\varepsilon\xi^{-1}+O(1)$  where  $\varepsilon^{n-e}=\delta$  (as p,p-q are monic). We choose a particular (n-e)th root  $\varepsilon_0$  of  $\delta$ . This fixes the branch of z and hence the subgroup G. The function  $z(\tau-m)$  is a Hauptmodul for  $C^{-m}GC^{m}$  and has a pole at  $\tau=\infty$ . Now,  $\zeta^{-m}z(\tau-m)=\varepsilon_0\xi^{-1}+O(1)$  ( $\zeta=\exp\{2\pi i/(n-e)\}$ ), so that  $[p(\zeta^mz),q(\zeta^mz)]$  determines the subgroup  $C^{-m}GC^{m}$ . This new pair is another standardised pair in  $\{[p,q]\}$ .

DEFINITION. Subgroups G,  $G_1$  of T are C-equivalent if there is an integer m with  $G_1 = C^{-m}GC^m$ .

We note that conjugation by any element of T preserves the class of special subgroups while conjugation by a power of C preserves the class

of extra-special subgroups. Thus a special (resp. extra-special) pair of degree n gives rise to a C-class of special (resp. extra-special) subgroups of index n. Since C-equivalent subgroups lead to the same °°-class of pairs, we have

**THEOREM 2.2. (i)** *There is a one-one correspondence between C-classes of special (resp. extra-special) subgroups of index n in T and <^-classes of special (resp. extra-special) pairs of degree n.*

If we *choose* one mth root of *S* for each integer *m,* then we can associate a unique subgroup with each special pair, i.e. we have

**THEOREM 2.2. (ii)** *There is a one-one correspondence between special (resp. extra-special) subgroups of index n in T and special (resp. extraspecial) pairs of degree n.*

Since T is finitely generated, it has only finitely many subgroups of each finite index. Hence

**COROLLARY 2.3.** *For each n, there are finitely many <\*>-classes of special (extra-special) pairs of degree n.*

From the definition it is clear that T is free of rank 2. By a result of M. Hall Jnr., [5], the number of subgroups of index *n* is bounded above by *n • n\* (indeed is asymptotically *n • n\(l + O(l/n))).* Since this includes subgroups of all possible genera, this is likely to be much larger than the number of °°-classes.

For any integer n, we could (in theory!) find all special pairs in the following way. There are finitely many triples (a, 0, *y)* of integers, with a, *fl&l,* 7^ 0 and

$$\alpha + \beta + \gamma = n + 1. \tag{7}$$

For each such triple, there are finitely many lists of non-negative integers of the form *[(a(j)),* (00)), 70)); *d]* such that

$$\alpha = \sum_{j=1}^{\infty} \alpha(j), \qquad \beta = \sum_{j=1}^{\infty} \beta(j), \qquad \gamma = \sum_{j=1}^{\infty} \gamma(j),$$

$$\gamma \le d < n, \quad \text{with} \quad d = 0, \quad \text{if} \quad \gamma = 0,$$

$$n = \sum_{j=1}^{\infty} \alpha(j)j = \sum_{j=1}^{\infty} \beta(j)j, \qquad d = \sum_{j=1}^{\infty} \gamma(j)j.$$
(8)

DEFINITION. A *specification of order n* consists of a triple satisfying (7) and a list satisfying (8). [Since (8) determines the triple, we may omit the triple.]

With each special pair [p, q], we can associate the specification *(c(p), c(q), c(p-q)), [(a(j)),* **OO)), M"));** *<Hp-q)l* **where** *a(j)* **(resp.**

 $\gamma(j)$ ) is the number of zeros of p (resp. q, p-q) which have multiplicity j. Since a transformation of the form (5) does not affect these parameters, each  $\infty$ -class has a specification. The extra-special pairs are precisely those whose specifications have  $\gamma = d$  and  $\gamma(1) = d$ ,  $\gamma(j) = 0$  (j > 1). Either from a corresponding special pair or from geometrical considerations, a special subgroup has a specification.

Given a specification of order n, we define polynomials

$$p(z) = \prod_{j=1}^{\infty} (p_{\alpha(j)}(z))^{j}, \qquad q(z) = \prod_{j=1}^{\infty} (q_{\beta(j)}(z))^{j}, \qquad t(z) = \prod_{j=1}^{\infty} (t_{\gamma(j)}(z))^{j}$$
(9)

where  $f_k(z)$  denotes a monic polynomial of degree k. The polynomials  $P_{\alpha(j)}$ ,  $q_{\beta(j)}$ ,  $t_{\gamma(j)}$  involve  $\sum (\alpha(j) + \beta(j) + \gamma(j)) = n + 1$  coefficients,  $x_1, \ldots, x_{n+1}$ . The equation

$$t(z) = p(z) - q(z) \tag{10}$$

gives n (non-linear) equations in the  $x_k$ . We get a further (linear) equation if we insist that p(z) satisfies (6). These are the x-equations for the specification.

Suppose that we have a solution  $\{x_k\}$  of the x-equations. If pqt has fewer than n+1 distinct zeros, then the discriminant of pqt vanishes, so that the  $x_k$  satisfy an additional equation. Otherwise (p, q) = 1, so that [p, q] is a standardised special pair. There are a finite number  $(\le n-d)$  of standardised pairs in each  $\infty$ -class of this specification, so that there are a finite number of solutions of this second kind. It follows that the  $x_k$  generate an algebraic number field. Let

$$p(z) = \sum_{i=1}^{n} a_i z^i, \qquad q(z) = \sum_{i=1}^{n} b_i z^i,$$

where  $a_n = b_n = 1$ ,  $a_{n-1} = 0$ . Then  $\mathbf{F} = \mathbb{Q}(\{a_j\}, \{b_j\})$  ( $\subseteq \mathbb{Q}(\{x_k\})$ ) is of finite degree over  $\mathbb{Q}$ . Let  $\mathbf{F}^*$  be a normal extension containing  $\mathbb{F}$  and  $\zeta = \exp\{2\pi i/(n-d)\}$  and let  $L = \operatorname{Gal}(\mathbb{F}^*/\mathbb{Q})$ . If  $\sigma \in L$ , then  $\sigma(p, q]$  is a standardised special pair with the same specification as [p, q]. From the remarks before the definition of a standardised pair,  $\sigma[p, q] \sim [p, q]$  if and only if, for each j,

$$\sigma(a_i) = \zeta^{m(n-j)}a_i, \qquad \sigma(b_i) = \zeta^{m(n-j)}b_i$$

with  $m = m(\sigma)$ . Then  $K = \{\sigma \in L : \sigma[p, q] \sim [p, q]\} \leq L$ . Let  $\mathbb{F}_0$  be the subfield of  $\mathbb{F}^*$  fixed by K. the algebraic conjugates of [p, q] belong to |K: L| (= deg ( $\mathbb{F}_0/\mathbb{Q}$ ))  $\infty$ -classes. For each j,  $a_j = k^{n-j}u_j$ ,  $b_j = k^{n-j}v_j$ , with  $k^{n-d}$  and the  $u_j$ ,  $v_j$  in  $\mathbb{F}_0$ . The pair  $[p_1, q_1] = [k^{-n}p(kz), k^nq(kz)]$  is defined over  $\mathbb{F}_0$  and in the  $\infty$ -class of [p, q]. By an elementary argument using derivatives,

 $p_1$ ,  $q_1$  and  $k^{n-d}(p_1-q_1)$  factorise over  $\mathbb{F}_0$  into the form (9). (The same argument shows that the  $a_i$  and  $b_i$  actually generate  $\mathbb{Q}(\{x_k\})$ .)

THEOREM 2.4. If there are  $N \propto$ -classes of special pairs with a given specification, then each contains a pair defined over an algebraic number field of degree at most N.

We are interested in pairs defined over fields of small degree (especially Q) so it is useful to observe that a property which is preserved by conjugation determines a subset of  $\infty$ -classes which should have a smaller field.

Suppose that  $G \le H \le T$  with G special. Let [p, q] be a pair for G. As  $\mathcal{H}/H$  covers  $\mathcal{H}/G$ , it has genus zero, so H is special. Further, if G is extra-special, so is H. Considering the extension of  $\mathbb{C}[w]$  in two stages, there are polynomials r, s, u, v with

$$p(z) = v^{m}(z)r(u(z)/v(z)), q(z) = v^{m}(z)s(u(z)/v(z)) (11)$$

where m = |H:T| and [r, s] is a pair for H. Each conjugate of [p, q] has a similar decomposition, so the corresponding subgroup has an overgroup of index m in T. Thus if  $N_m$  of the C-classes of subgroups have an overgroup of index m, there are special pairs defined over a field of degree at most  $N_m$ .

We observe that this gives a method of obtaining a special pair of degree mn from a pair [r, s] of degree m. We require coprime polynomials u, v with d(u) = n > d(r) and such that the set  $\{u(z) - \alpha v(z): \alpha \text{ a zero of } rs(r-s)\}$  has mn+1-c(v) distinct zeros. (The most obvious choice would be  $u(z) = z^n + \alpha$ , v(z) = 1, where  $\alpha$  is one of the zeros.) Then (11) defines a pair whose specification is easily derived from that of [r, s] and the number of zeros of  $u(z) - \alpha v(z)$  for each relevant  $\alpha$ . We meet an example in §4.

DEFINITION. If G is a subgroup of a group S, then the *core* of G is the greatest normal subgroup of S contained in G. It is written c(G).

Suppose that G is a special subgroup of T with z a Hauptmodul for  $\mathcal{X}/G$ . Then T/c(G) is isomorphic to Gal  $(\mathbb{E}/\mathbb{C}(w))$  where  $\mathbb{E}$  is the splitting field for  $\mathbb{C}(z)$ . Then Galois group is determined by various equations satisfied by the coefficients of a special pair [p, q] for G. It follows that a conjugate of [p, q] corresponds to a subgroup  $G_1$  with  $T/c(G_1) \simeq T/c(G)$ . This may be used to determine a subset of  $\infty$ -classes.

Footnote. We could take as T the group  $\Gamma(2)$ , the principal congruence subgroup of level 2 in the modular group  $\Gamma$  (see [9]). Since we meet  $\Gamma$  later as a quotient of T, and  $\Gamma(2)$  as a subgroup of this quotient, this would be rather confusing. An advantage would be that our normalised Hauptmodul  $w(\tau)$  would be a known function. In the notation of [9], Ch.

7, W(T) = 1/A.(T), SO that the expansion at » is

$$w(\tau) = (1/16\omega) \left( 1 + 2 \sum_{n=1}^{\infty} \omega^{n^2} \right)^4 \left( 1 + \sum_{n=1}^{\infty} \omega^{n^2 + n} \right)^{-4}.$$

It follows that 16w has rational integer coefficients:

$$16w(\tau) = \omega^{-1} + 8 + 20\omega - 78\omega^{3} + \cdots$$

Further, the usual Hauptmodul, ;(T), for T is related to *w* by

$$\frac{j}{1728} = \frac{4}{27} \cdot \frac{(w^2 - w + 1)^3}{w^2 (w - 1)^2} = \frac{p(w)}{u(w)}.$$

The alert reader will have observed that

$$q(w) = p(w) - u(w) = (w^3 - \frac{3}{2}w^2 - \frac{3}{2}w + 1)^2$$

so that [p, q] is a special pair. We will meet this pair again in §4.

We observe that, with an explicit W(T), it may be possible to use the "w-equations":

$$w(p(z)-q(z)) = p(z)$$
$$(w-1)(p(z)-q(z)) = q(z)$$

in the manner of the /-equations in [1].

The existence of a Hauptmodul whose to-expansion has real coefficients allows us to study special pairs defined over R.

We note that the transformation V(T) = —f preserves *X* and has order 2.

DEFiNmoNS. (1) Let G«sPSL(2,R). Put G» = *VGV.*

(2) Let / : \*->\* . Put /\*( <sup>T</sup> ) = /(-T ) = /(V(T)). If we take T = T(2), then *T\* = T* and we have

LEMMA 2.5. (i) *If f is an automorphic function for G^T, then f\* is an automorphic function for* G\*.

(ii) *Let G be an {extra-) special subgroup of T. Then G\* is an (extra-) special subgroup of the same index. Further, if* Z(T) *is a Hauptmodul for G, then* Z\*(T) *is a Hauptmodul for G\*.*

*Proof,* (i) As / is holomorphic, so is *f\*.* As conjugation by V preserves the class of parabolic elements of *PSL(2,* R), *f\** behaves properly at the cusps. Also, if Xe G\*, then X= *VYV* with Ye G and

$$f^*(X(\tau)) = \overline{f(VX(\tau))} = \overline{f(VV(\tau))} = \overline{f(V(\tau))} = f^*(\tau).$$

(ii) Let *F* be a fundamental domain for G. Then *V(F)* is a domain for G\* and the pairing of sides corresponds to that for *F* in the obvious way. Hence Hf/G = \*/G\* as surfaces, so g(G\*) = g(G). Thus, if G is special, so is *G\*.*

Now,

$$VCV(\tau) = VC(-\bar{\tau}) = V(-\bar{\tau}+2) = \tau - 2 = C^{-1}(\tau)$$

so that

$$VCV = C^{-1}$$

Thus a T-conjugate of C" in G corresponds to a T-conjugate of C~<sup>m</sup> in G\*, so that, if G is extra-special, so is G\*.

Since the transformation V is a reflection, it preserves hyperbolic areas, so G, G\* have the same index.

Finally, if 2 is a Hauptmodul for G, then it is univalent in the interior of *F.* Hence z\* is univalent in the interior of *V(F)* and so is a Hauptmodul for G\*, after (i).

THEOREM 2.6. *Take* T = T(2). *To fix the correspondence in Theorem* 2.2 (ii), *choose the real positive roots of 8=&. Let* [p, *q] be a special pair and G the corresponding subgroup. Then*

- (0 [p. 4] *corresponds to G\*,*
- (ii) p, q eR[z] *if and only if* G = G\*.

Proof. The Hauptmodul Z(T) for G obtained from [p, q] has *<o*expansion

$$z(\tau) = (\frac{1}{16})^{1/(n-\epsilon)} \omega^{-1} + \sum_{n=0}^{\infty} \alpha_n \omega^n.$$

The On can be determined using the explicit o>-expansion of *w* (above) and the equation

$$w = p(z)/(p(z) - q(z)).$$

Conversely, the a^ can be used to calculate the coefficients of p and *q.* Since the a>-expansion of w is real, p, *q* eR[z] if and only if *a^* eR for all n.

Now, *(o* =exp{-mV}, so that o»(—T) = O»(T) and hence

$$z^*(\tau) = (\frac{1}{16})^{1/(n-\epsilon)}\omega^{-1} + \sum \bar{\alpha}_n \omega^n$$

Hence p, qeR(z) if and only if z = *z\*.* (t)

Since w = w\*,

$$w = \bar{p}(z^*)/(\bar{p}(z^*) - \bar{q}(z^*)).$$

Using the lemma and the definition of standardisation, [p, q] is the special pair for G\* and z\* the associated Hauptmodul. This proves (i).

If z = z\*, then *G = G\** since z is a Hauptmodul for G and so cannot be invariant under a larger subgroup.

Now suppose that  $G = G^*$ . As z,  $z^*$  Hauptmoduln, the only poles in a fundamental domain occur at cusp (G-equivalent to)  $\infty$ . Using the above  $\omega$ -expansions,  $z^* = z + \beta$  with  $\beta \in \mathbb{C}$ . As [p, q],  $[\bar{p}, \bar{q}]$  are standardised pairs for G (=  $G^*$ ), they are  $\infty$ -equivalent, so that  $z^* = \zeta z$  with  $\zeta \in \mathbb{C}$ . Comparing these relations,  $z = z^*$ .

Part (ii) now follows from (†).

## 3. Subgroups and Permutations

The subgroups of T can be studied using permutations in much the same way as those of  $\Gamma$  (see [7], [1]). A generalised form appears in [10]. Write  $S_n$  for the group of permutations of  $\{1, \ldots, n\}$ .

DEFINITIONS. (1) A pair (a, b) of permutations is *transitive* if (a, b) is transitive.

(2) Two pairs (a, b), (a', b') are equivalent (1-equivalent) if there is a permutation s such that  $a' = sas^{-1}$ ,  $b' = sbs^{-1}$  (and s1 = 1).

If  $G \le T$ , then premultiplication by  $X \in T$  permutes  $\{YG: Y \in T\}$ . If |G: T| = n, then we can label the cosets by  $\{1, \ldots, n\}$  with 1G = 1. Then X defines an element  $\pi(X)$  of  $S_n$ . Then  $(\pi(A), \pi(B))$  is transitive. Note that  $\pi(C) = \pi(B)^{-1}\pi(A)^{-1}$ . From [10], we have

THEOREM 3.1. There is a 1-1 correspondence between subgroups of index n in T and 1-equivalence classes of transitive pairs in  $S_n$ .

If  $G \le T$  has specification  $[(\alpha(j)), (\beta(j)), (\gamma(j))]$  and (a, b) is a corresponding pair, then

- (i) for each j,  $\alpha(j)$  (resp.  $\beta(j)$ ) is the number of j-cycles in a (resp. b),
- (ii)  $c = b^{-1}a^{-1}$  has  $1 + \sum \gamma(j)$  cycles, 1 belongs to a cycle of length  $n \sum j\gamma(j)$  and, for each j, there are  $\gamma(j)$  cycles of length j which do not contain 1,
  - (iii) if  $G \le H \le T$ , then (a, b) is imprimitive with blocks of size |G: H|,
  - (iv)  $G = \{X \in T: \pi(X)1 = 1\},$
  - (v)  $\langle a, b \rangle \simeq T/c(G)$ .

COROLLARY 3.2. Suppose that (a, b) is a pair for  $G \le T$ . Then

- (i) each conjugate of G is of the form  $\{X \in T: \pi(X)r = r\}$ , for some r,
- (ii) there is a 1-1 correspondence between conjugacy classes of subgroups of index n in T and equivalence classes of transitive pairs in  $S_n$ .

**Proof.** If YG = r (in the numbering corresponding to (a, b)), then  $X \in YGY^{-1}$  if and only if XYG = YG, i.e.  $\pi(X)r = r$ . This proves (i). For (ii), it is enough to observe that ((1, r)a(1, r), (1, r)b(1, r)) is a pair for  $YGY^{-1}$ .

COROLLARY 3.3. A 1-equivalence class of transitive pairs in  $S_n$  has (n-1)! members.

*Proof.* A pair for  $G \le T$  indicates the effect of A, B on cosets of G. The labelling of the YG  $(\ne 1G)$  is arbitrary, so there are (n-1)! labellings.

We observe that 3.1 (i), (ii) allow us to extend the definition of the specification of a subgroup to G with  $g(G) \neq 0$ . In fact, an easy calculation using 6H, Ch. VII of [6] shows that

$$g(G) = \frac{1}{2} \left\{ n + 1 - \sum_{j=1}^{\infty} (\alpha(j) + \beta(j) + \gamma(j)) \right\}.$$
 (12)

It follows that special subgroups can be recognised from their specifications.

After 1.3, 3.1, the cases of equality in (1) correspond to extra-special pairs [p, q] in which p has triple zeros and q double zeros. The corresponding subgroups are associated with subgroups of  $\Gamma$ .

Suppose that G is a subgroup of index n in T and that its specification has  $\alpha(2) = \alpha(j) = 0$  (j > 3) and  $\beta(j) = 0$  (j > 2). Then the branch points of  $\mathcal{X}/G$  over w = 0 have order 1 or 3, so G contains every T-conjugate of  $A^3$ . Similarly, G contains each T-conjugate of  $B^2$ . Thus G contains  $N = \langle A^3, B^2 \rangle^T$ . By standard presentation theory,

$$T/N \simeq \langle A_1, B_1, C_1 : A_1^3 = B_1^2 = A_1B_1C_1 = 1 \rangle \simeq \Gamma.$$

Hence there is a subgroup  $G_1$  of  $\Gamma$  with  $G/N \simeq G_1$ . Then  $|G_1: \Gamma| = |G: T| = n$ , overgroups of  $G_1$  correspond to overgroups of G and  $\Gamma/c(G_1) \simeq T/c(G)$ . Further, the surface  $\mathcal{H}/G_1$  can be obtained by "pasting" copies of the usual triangular fundamental domain for  $\Gamma$  in exactly the same way as  $\mathcal{H}/G$  is obtained from that for T. It follows that  $g(G_1) = g(G)$  and  $\mathcal{H}/G_1$  has  $\alpha(1)$  (resp.  $\alpha(3)$ ) branch points of order 1 (resp. 3) over the fixed point of  $A_1$ , and  $\beta(1)$  (resp.  $\beta(2)$ ) of order 1 (resp. 2) over that of  $\beta(1)$ . By choosing the realisation of  $\beta(1)$ , we may assume that  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$ . Then  $\beta(1) = \tau + 1$  is the other points over  $\gamma(1) = \tau + 1$ .

$$n = \alpha(1) + 3\alpha(3) = \beta(1) + 2\beta(2)$$

and hence n,  $\alpha(1)$ ,  $\beta(1)$  determine  $\alpha(3)$ ,  $\beta(2)$ . Then, from (12),  $g = g(G_1)$  satisfies

$$12g = n + 6 - \{4\alpha(1) + 3\beta(1) + \sum \gamma(j)\}. \tag{13}$$

DEFINITION. The subgroup  $G_1$  of  $\Gamma$  described above has  $\Gamma$ -specification  $[n, g, \alpha(1), \beta(1), (\gamma(j))]$  and cusp-split  $(n - \sum j\gamma(j), (\gamma(j)))$ . We use the term  $\Gamma$ -specification for a list satisfying (13) with  $n > \sum j\gamma(j)$ .

Subgroups of T (of the above type) lead to subgroups of  $\Gamma$ . It is clear that a subgroup  $G_1$  of  $\Gamma$  leads to a subgroup G of T, and that the

specification of G is determined by that of  $G_1$ . We use the terms special and extra-special for subgroups of  $\Gamma$  in the obvious senses. (In terms of  $\Gamma$ -specifications, those g = 0, and g = 0,  $\gamma(j) = 0$  (j > 1) respectively.)

DEFINITION. A transitive pair (a, b) is legitimate if  $a^3 = b^2 = 1$ .

Analogues of 3.1, 3.2 and 3.3 for  $\Gamma$  are obtained by replacing transitive by legitimate throughout. We refer to these as 3.1', 3.2' and 3.3'. With \* defined as in the footnote to §2, we note that  $\Gamma^* = \Gamma$ . We choose

$$A_1(\tau) = -(\tau + 1)/\tau$$
,  $B_1(\tau) = -1/\tau$ , so  $C_1(\tau) = \tau + 1$ .

For  $X \in PSL(2, \mathbb{R})$ , write  $X^*$  for VXV. Then  $X \mapsto X^*$  is a homomorphism and

$$A_1^* = B_1 A_1^{-1} B_1, B_1^* = B_1, \text{ so } C_1^* = C_1^{-1}.$$

LEMMA 3.4. Suppose that  $G \leq \Gamma$  has specification  $[n, g, \alpha(1), \beta(1), (\gamma(j))]$ . Then

- (i)  $G^* \leq \Gamma$  and has the same specification as G.
- (ii) if (a, b) is a legitimate pair for G, then  $(ba^{-1}b, a)$  is a legitimate pair for  $G^*$ .

**Proof.** The first part is clear from the fact that, if F is a fundamental domain for G, then V(F) is a domain for  $G^*$  and the elliptic, parabolic cycles correspond. As  $C_1 = C_1^{-1}$ , the distinguished cusp (G-equivalent to  $\infty$ ) has unaltered width.

For the second part, suppose that  $\{X_1G, \ldots, X_nG\}$  is a set of coset representatives for G, with  $X_1G = G$ . Then  $\{X_j^*G^*\}$  is set for  $G^*$ , with  $X_1^*G^* = G^*$ . Let  $(a^*, b^*)$  be the legitimate pair for  $G^*$  derived from this coset labelling. i.e.  $A_1(X_j)^*G^* = (X_{a^*(j)})^*G^*$ , etc. Then, for all j,

$$A_1(X_j)^*G^* = (A_1^*X_jG)^* = (B_1A_1^{-1}B_1X_jG)^*$$
$$= (X_{ba} - 1_{b(i)}G)^* = (X_{ba} - 1_{b(i)})^*G^*,$$

so that  $a^*(j) = ba^{-1}b(j)$ . Also,

$$B_1(X_j)^*G^* = (B_1^*X_jG)^* = (b_1X_jG)^*$$
$$= (X_{b(j)}G)^* = (X_{b(j)})^*G^*,$$

so that  $b^*(j) = b(j)$ .

The results of this section allow us to reduce problems about the existence and enumeration of special pairs to problems on permutation groups. We illustrate by considering the cases of equality in (1).

## 4. Cases of equality in (1)

DEFINITION. A pair [f, g] of non-constant complex polynomials is a (2, 3)-pair of order r if they give equality in (1), and d(f) = 2r.

An extra-special pair [p, q] in which p has triple zeros and q double zeros gives a (2, 3)-pair  $[(p/k(p))^{1/3}, (q/k(q))^{1/2}]$  of monic polynomials (see 1.3). Defining  $C_1$ -equivalence in the natural way, 1.3, 2.2 yield

THEOREM 4.1. The  $\infty$ -classes of (2, 3)-pairs of order r are in 1-1 correspondence with the  $C_1$ -classes of subgroups of  $\Gamma$  with  $\Gamma$ -specification  $[6r, 0, 0, 0, (r+1, \ldots)]$ .

DEFINITION. For non-negative integers  $\alpha$ ,  $\beta$ ,  $\gamma$  with  $4\alpha + 3\beta + 6\gamma > 6$ ,  $N(\alpha, \beta, \gamma)$  is the number of subgroups of  $\Gamma$  with  $\Gamma$ -specification  $[4\alpha + 3\beta + 6\gamma - 6, 0, \alpha, \beta, (\gamma, 0, \ldots)]$ .  $N_c(\alpha, \beta, \gamma)$  the number of conjugacy classes.

We note that the subgroups involved are all extra special.

Suppose that (a, b) is a legitimate pair in  $S_n$  (n > 1) and that b fixes the symbol t. As  $a^3 = 1$  and (a, b) is transitive, we must have  $n \ge 3$  and

$$a = \cdots (r, s, t), b = \cdots (t), \text{ so } c(=ba^{-1}) = \cdots (\ldots, r, t, \ldots).$$

We can extend these to  $S_{n+3}$  as follows:

$$a^+ = \cdots (r, s, t)(n+1, n+2, n+3),$$
  $b^+ = \cdots (t, n+1)(n+2, n+3)$ 

so that  $c^+ = b^+(a^+)^{-1} = \cdots (\dots, r, n+1, n+2, t, \dots)(n+3)$ . Then  $(a^+, b^+)$  is legitimate,  $c^+$  has one more fixed point than c,  $b^+$  one fewer than b. Conversely, if  $(a^+, b^+)$  is a legitimate pair in  $S_m$  (m>4) with  $c^+$  having at least one fixed point, then we can reverse the above process to remove one of these.

This is similar to Conway's construction in [1]. Considering conjugation in the  $S_k$  and 3.3, it is easy to prove

Proposition 4.2. If  $\alpha$ ,  $\beta$ ,  $\gamma$  are non-negative integers with  $4\alpha + 3\beta + 6\gamma > 6$  and  $\beta \ge \gamma$ , then

$$N_c(\alpha, \beta, \gamma) = N_c(\alpha, \gamma, \beta).$$

The existence of the construction is enough for our present purpose which is to prove conjecture (2a) of [2]. We have

THEOREM 4.3. For each positive integer r, there is a (2, 3)-pair of order r.

*Proof.* By 4.1, it is enough to prove that  $N_c(0, 0, r+1) > 0$ 

For r = 1, we take a = (1, 2, 3)(4, 5, 6), b = (1, 2)(3, 4)(5, 6), so that c = (2)(1, 4, 5, 3)(6).

For r > 1, 4.2 shows that it is enough to show that  $N_c(0, r+1, 0) > 0$ . For r = 2, we take a = (1, 2, 3), b = (1)(2)(3), so  $c = a^{-1}$ . For r > 2, we take  $a_r = (1, 2, 3)(4, 5, 6) \cdots (3r-5, 3r-4, 3r-3)$ ,  $b_r = (1)(2)(3, 4)(5)(6, 7) \cdots (3r-6, 3r-5)(3r-4)(3r-3)$ . It is clear that  $(a_r, b_r)$  is legitimate and  $\alpha(1) = 0$ ,  $\beta(1) = r+1$ , n = 3r-3. Then (13) shows that g = 0,  $\gamma(j) = 0$  (all j). In fact, we can enumerate the  $\infty$ -classes of (2, 3)-pairs of each order.

In the notation of [13], a subgroup of  $\Gamma$ -specification  $[n, g, \alpha, \beta, (\gamma(j))]$  is a subgroup of type  $(n, \beta, \alpha, 2g + \sum \gamma(j))$ . (This follows easily from the standard presentation for a subgroup of  $\Gamma$ , see [9], p. 69.) Then a subgroup of type  $(n, \beta, \alpha, 0)$  must have  $g = \sum \gamma(j) = 0$ , so that N(0, r+1, 0) is the number of subgroups of type (3r-3, 0, r+1, 0). From 1.4, 1.8 of [13], we have

LEMMA 4.4. For r > 1, N(0, r+1, 0) = 3(2r-2)!/(r-1)!(r+1)!

LEMMA 4.5.

- (1) N(0, 0, r+1) = 6r(2r-2)!/(r-1)!(r+1)! (r>1),
- (2) N(0, 1, s+1) = (6s+3)(2s)!/s!(s+1)!  $(s \ge 0),$
- (3) N(1, 0, s+1) = (6s+4)(2s)!/s!(s+1)!  $(s \ge 0)$ .

**Proof.** (1) Let  $\mathcal{G}$  (resp.  $\mathcal{F}$ ) be the set of legitimate pairs corresponding to the  $\Gamma$ -specification  $[3r-3,0,0,r+1,(0,0,\ldots)]$  (resp.  $[6r,0,0,0,(r+1,0,\ldots)]$ ). For each (3r-3)-element subset I of  $\{1,\ldots,6r\}$  let  $\mathcal{G}(I)=\{(a^s,b^s):(a,b)\in\mathcal{F}\}$ , where s is a fixed permutation mapping  $\{1,\ldots,3r-3\}$  to I. then  $\mathcal{G}(I)$  consists of the "legitimate pairs" of permutations of I, with s1 being the distinguished symbol.

Take  $(a, b) \in \mathcal{G}(I)$ . The (3r-3) elements of  $\{1, \ldots, 6r\} - I$  can be used to construct an element of  $\mathcal{F}$  (using the r+1 fixed points of b) in  $\{(3r+3)!/s^{r+1}(r+1)!\} \cdot \{3^{r+1}(r+1)!\}$  ways. (Consider the choice of r+1 3-cycles and the addition of each to one of the fixed points of b.) There are (6r)!/(3r-3)!(3r+3)! subsets I and each member of  $\mathcal{F}$  comes from just one of these (viz. that obtained by eliminating the fixed points of the corresponding c). Hence

$$|\mathcal{F}| = \{(6r)!/(3r-3)!(3r+3)!\}\{3r+3)!\} |\mathcal{S}|.$$

The result follows from 3.3'(ii) and 4.4.

The proofs of (2) and (3) are similar, though (3) requires the technique for the removal of a fixed point of a introduced in [1].

THEOREM 4.6. The number of  $\infty$ -classes of (2, 3)-pairs of order r is  $M_1(r) + M_2(r) + M_3(r)$ , where

$$M_1(r) = \{(2r-2)!/(r-1)!(r+1)!\} - \frac{1}{2}M_2(r) - \frac{1}{3}M_3(r),$$

and, for k = 2, 3,

$$M_k(r) = \begin{cases} 0, & \text{if } r \not\equiv -1 \pmod{k}, \\ (2s)!/s!(s+1)!, & \text{if } r = ks + (k-1). \end{cases}$$

Further, for k = 2 (resp. 3), there are precisely  $M_k(r)$  classes which contain pairs of the form  $[f_0(z^2), zg_0(z^2)]$  (resp.  $[zf_0(z^3), g_0(z^3)]$ ).

**Proof.** Suppose that  $G \le \Gamma$  has  $\Gamma$ -specification [6r, 0, 0, 0, (r+1, 0, ...)] and that  $Y \in \Gamma$ . From 3.2', 3.3',  $YGY^{-1}$  has the same  $\Gamma$ -specification if and only if  $\pi(Y)$ 1 belongs to the cycle of  $\pi(C_1)$  which contains 1. When this happens, there is an integer m with  $\pi(C_1^m)1 = \pi(Y)1$  so that  $YGY^{-1}$  is  $C_1$ -equivalent to G. Hence, from 4.1, the number of  $\infty$ -classes is equal to  $N_c(0, 0, r+1)$ . We must study the conjugacy classes by looking at the overgroups (potential normalisers) of G. It should be clear that G of this type cannot be normal.

Suppose that  $G \le H < \Gamma$  with |G:H| = k. Then, by 3.2'(iii), a corresponding pair (a, b) has blocks of imprimitivity of size k. As c has one non-trivial cycle, the fixed points of c form a number of complete blocks. Hence k divides r+1. Since k divides 6r, k divides (r+1, 6r) so that k=2,3 or 6. The action of a and b on the blocks give a legitimate pair (a',b') for H, so that c' has a (5r-1)/k cycle containing  $\{1\}$  and (r+1)/k fixed points. As  $\mathcal{H}/H$  covers  $\mathcal{H}/G$ , it has genus zero.

Case 1. 
$$k=2$$
 (so  $r=2s+1$ ). Then H has  $\Gamma$ -specification  $[6s+3,0,\alpha,\beta,(s+1,0,\ldots)]$ .

From (13),

$$6s + 3 = 4\alpha + 3\beta + 6(s + 1) - 6$$

i.e.

$$3 = 4\alpha + 3\beta$$
.

As  $\alpha$ ,  $\beta \ge 0$ , we must have  $\alpha = 0$ ,  $\beta = 1$ . As b has no fixed points while b' has one, there is a block  $\{x, y\}$  with bx = y. If c fixes either x or y then c' fixes  $\{x, y\}$  so that (a', b') is intransitive. Hence x, y are in the non-trivial cycle of c. It follows that there is a unique conjugate  $G_2$  of G with  $G_2 \triangleleft \langle G_2, B_1 \rangle$ . Also,  $\langle G_2, B_1 \rangle$  has exactly one subgroup with the necessary  $\Gamma$ -specification (consider the relation between the Hauptmoduln). As  $\langle G_2, B_1 \rangle$  has precisely one conjugacy class of elements of order 2, it has 6s+3  $\Gamma$ -conjugates, the number of subgroups with such overgroups is  $N_c(0,1,s+1) = N(0,1,s+1)/(6s+3)$ . By 4.5(2), this is equal to  $M_2(r)$ .

Case 2. k=3 (so r=3s+2). Much as in case 1, there is a unique conjugate  $G_3$  with  $G_3 \triangleleft \langle G_3, A_1 \rangle$ , the latter having  $\Gamma$ -specification  $[6s+4,0,1,0,(s+1,0,\ldots)]$ . Here, the number of classes is  $N(1,0,s+1)/(6s+4)=M_3(r)$ , by 4.5 (3).

Case 3. k = 6 (so r = 6s + 5). Then the overgroup would have  $\Gamma$ -specification  $[6s + 5, 0, \alpha, \beta, (s + 1, 0, ...)]$  with (from (13)),

$$6s + 5 = 4\alpha + 3\beta + 6(s + 1) - 6$$

i.e.

$$5 = 4\alpha + 3\beta$$
.

This cannot be satisfied with non-negative integers  $\alpha$ ,  $\beta$ .

It follows that each subgroup not of the types considered in cases 1 and 2 has precisely 6r conjugates. Let  $M_1(r)$  be the number of subgroups of this kind. Then

$$N(0, 0, r+1) = 6r(M_1(r) + \frac{1}{2}M_2(r) + \frac{1}{2}M_3(r)$$
  

$$N_c(0, 0, r+1) = M_1(r) + M_2(r) + M_3(r).$$

The values of  $M_2(r)$ ,  $M_3(r)$  are as in the statement and that of N(0, 0, r +1) given by 4.4. then  $M_1(r)$  is as in the statement.

For the last part, consider the case where G has index 2 in its normaliser H. Then [p, q], a special pair for H, has p with 2s + 1 triple zeros, q with one simple and 3s+1 double zeros. We may choose the pair so that the simple zero occurs at zero. Then  $q(r) = tg_0(t)^2$ ,  $p(r) = f_0(t)^3$ , where  $tf_0g_0$  has distinct zeros. These define a Hauptmodul  $t(\tau)$  for  $\mathcal{X}/H$ . Then  $\mathcal{X}/G$  is a 2-fold covering of  $\mathcal{X}/H$  with non-trivial branching only over t=0,  $\infty$ , so that  $z^2=t$  defines a Hauptmodul for  $\mathcal{X}/G$ . Hence  $[f_0(z^2), zg_0(z^2)]$  is a (2, 3)-pair corresponding to G. Conversely, a pair of this form leads to a subgroup with an overgroup defined by  $t(\tau) = z^2(\tau)$ . The case k = 3 is similar.

By the remarks following 2.4, the  $\infty$ -classes of (2, 3)-pairs of order r can be divided into sets  $\mathcal{M}_k(r)$  (k=1,2,3) with  $|\mathcal{M}_k(r)| = M_k(r)$ . A class in  $\mathcal{M}_{k}(r)$  contains a pair defined over a field of degree at most  $M_{k}(r)$  (the choice of zero as the simple zero, when k>1, does not need a field extension). In particular, we get a rational pair whenever  $M_r(k) = 1$ . For the first few values of r, 4.6 gives the following information, listed in the form  $(r; M_1(r), M_2(r), M_3(r))$ :

It is easy to see that, for k = 2, 3, the value of  $M_k(sk + (k-1))$  increases with s. A tedious calculation shows that, if r > 4,  $M_1(r+6) > M_1(r)$  so that there are no further values with  $M_k(r) = 1$ .

Pairs in  $M_2(1)$ ,  $M_3(2)$  are easy to find (via the Hauptmoduln of the vergroups). Example (ii) of §2.4 in [1] gives (essentially) the rational pair  $M_2(3)$ . [2] contains pairs in  $M_2(3)$  and  $M_3(5)$ . [4] gives the two omplex conjugate) pairs in  $M_3(8)$ .

We note that, from Theorem 4.6, for  $s \ge 0$ ,  $M_2(2s+1) = M_3(3s+2)$ .

This can be proved using "Conway's construction" from [1] with the overgroups). Example (ii) of §2.4 in [1] gives (essentially) the rational pair in  $M_2(3)$ . [2] contains pairs in  $M_2(3)$  and  $M_3(5)$ . [4] gives the two (complex conjugate) pairs in  $M_3(8)$ .

$$M_2(2s+1) = M_3(3s+2)$$

This can be proved using "Conway's construction" from [1] with the

legitimate pairs for the overgroups  $G_2$ ,  $G_3$  which occur in the proof of the theorem. It is not known whether the relationship has any implications for the field of definition.

Finally, since we found all overgroups in the course of the proof of 4.6. there is no splitting of the  $\mathcal{M}_{r}(r)$  on this basis.

A second possibility is that some of the  $\mathcal{M}_{k}(r)$  may split into subsets having different  $\Gamma/c(G)$ . By 3.1'(v), the necessary information is in the legitimate pairs. Theorem 1 of [16] states that a primitive permutation group of degree n with an m-cycle such that m < (n-m)! is  $A_m$  or  $S_n$ . For  $G \in \mathcal{M}_1(r)$ ,  $\langle a, b \rangle$  is primitive and  $\pi(C_1)$  is a 5r-1 cycle. As a is even and b has 3r transpositions, we have

$$\Gamma/c(G) \simeq \begin{cases} A_{6r}, & r \text{ even,} \\ S_{6r}, & r \text{ odd.} \end{cases}$$

For  $G \in \mathcal{M}_k(r)$ , k > 1, with r = ks + k - 1, s > 2, Williamson's result applies to the normaliser H. Using the results of [3], with minor changes for the alternating case, we get

k = 2:

$$\Gamma/c(G) \simeq \begin{cases} C_2^{6s+2}/S_{6s+3}, & s \text{ even,} \\ C_2^{6s+3}/A_{6s+3}, & s \text{ odd.} \end{cases}$$

k = 3:

$$\Gamma/c(G) \simeq \begin{cases} C_2^{6s+2}/S_{6s+3}, & s \text{ even,} \\ C_2^{6s+3}/A_{6s+3}, & s \text{ odd.} \end{cases}$$

$$\Gamma/c(G) \simeq \begin{cases} C_3^{6s+4}/S_{6s+4}, & s \text{ odd,} \\ C_3^{6s+4}/A_{6s+4}, & s \text{ even.} \end{cases}$$

The (six) remaining cases have low degree and can be dealt with ad hoc. Since there is only one class of suitable extensions in each case, there is no splitting on this basis.

We note that the results of 4.5 give an upper bound for the degree of the field of definition. It is quite possible that there are other rational (2, 3)-pairs. We know of no examples where the field is smaller than predicted. Even when r = 4, the x-equations are unpleasant.

To prove that there are real (2, 3)-pairs of each order, we outline the construction of legitimate pairs satisfying the condition in Lemma 3.4(ii).

Suppose that (a, b) is a legitimate pair of order n with b(1) = 1. Let  $J = \{1, ..., n\}, J' = \{1', ..., n'\}.$  We define a pair  $(a^0, b^0)$  on  $J \cup J'$  by

$$b^{0}(x) = \begin{cases} b(x), & x \in J - \{1\}, \\ (b(y))', & x = y' \in J' - \{1'\}, \\ 1, & x = 1, \\ 1', & x = 1'. \end{cases}$$

$$a^{0}(x) = \begin{cases} a(x), & x \in J, \\ (a(y))', & x = y' \in J'. \end{cases}$$

Then  $(a^0, b^0)$  is legitimate. A tedious calculation shows that  $(a^0, b^0)$  is 1-equivalent to  $(b^0(a^0)^{-1}b^0, b^0)$  using the permutation  $s = (1)(1')(2, 2'), \ldots, (n, n')$ . By Lemma 3.4(ii),  $(a^0, b^0)$  corresponds to a subgroup  $G^0$  with  $(G^0)^* = G^0$ . If G, the subgroup corresponding to (a, b) has  $\Gamma$ -specification  $[n, g, \alpha(1), \beta(1), (\gamma(j))]$ , then  $G^0$  has  $\Gamma$ -specification  $[2n, g^0, \alpha^0(1), \beta^0(1), (\gamma'(j))]$  where

$$\alpha^{0}(1) = 2\alpha(1),$$
  
 $\beta^{0}(1) = 2\beta(1) - 2,$   
 $\gamma^{0}(j) = \gamma(j), \quad (j \ge 1).$ 

These follow from the definitions of  $a^0$ ,  $b^0$  and the fact that each cycle of  $ba^{-1}$  not involving 1 gives rise to two cycles (of the same length) in  $b^0(a^0)^{-1}$ , while 1, 1' belong to a single cycle in  $b^0(a^0)^{-1}$ . Then (12) shows that

$$g^0 = 2g$$
.

Hence, if G is special, so is  $G^0$ . Further, the lengths of cycles of  $b^0(a^0)^{-1}$  show that, if G is extra-special, so is  $G^0$ .

A more complicated construction leads to a legitimate pair  $(a^1, b^1)$  of order 2n+6 from the pair (a, b). The corresponding subgroup  $G^1$  is (extra-) special if G is, and has specification  $[2n+6, g', \alpha'(1), \beta'(1), (\gamma'(j))]$  where

$$\alpha^{1}(1) = 2\alpha(1),$$
  
 $\beta^{1}(1) = 2\beta(1) - 2.$ 

To prove conjecture 2(b) of [2], we have

THEOREM 4.7. For each positive integer r, there is a (2,3)-pair defined over  $\mathbb{R}$  or order r.

**Proof.** With the above construction, we need to find subgroups G with suitable pairs (a, b).

Case 1. r = 2s + 1. If G has  $\Gamma$ -specification [6s + 3, 0, 0, 1, (s + 1, 0, 0, ...)], then  $G^0$  as defined above has  $\Gamma$ -specification [6r, 0, 0, 0, (r + 1, 0, ...)]. By Theorem 4.1, 3.4, 2.6, the pair for  $G^0$  is a real (2, 3)-pair of order r.

Case 2. r = 2(s+1). If G has  $\Gamma$ -specification  $[6s+3, 0, 0, 1, (s+1, 0, 0, \ldots)]$ , then G' leads to a real (2, 3)-pair of order r.

It follows that real pairs exist for all s provided that, for each s>0,  $N_c(0,0,s+1)>0$ . This is proved in the proof of Theorem 4.3.

#### 5. Examples and remarks

EXAMPLE 5.1. Suppose that n,  $\alpha$ ,  $\beta$ ,  $\gamma$  are non-negative integers with  $0 < \alpha$ ,  $\beta \le n$ ,  $0 \le \gamma < n$  and  $\alpha + \beta + \gamma = 1 + n$ . We show that there is an extra-special pair [p,q] of degree n such that  $c(p) = \alpha$ ,  $c(q) = \beta$ ,  $d(p-q) = c(p-q) = \gamma$  and p has  $\alpha - 1$  simple zeros, q has  $\beta - 1$ . Indeed, there is exactly one  $\infty$ -class for each quadruple.

Case 1.  $\alpha = n$ . As  $\beta > 0$ , we must have  $\beta = 1$ ,  $\gamma = 0$ . In any  $\infty$ -class there is a member with  $q(z) = z^n$  and p(z) - q(z) = 1. This determines p, so there is precisely one  $\infty$ -class,  $\{ [z^n + 1, z^n] \}$ .

Case 2.  $\beta = n$ . This is similar to case 1.

Case 3.  $\alpha$ ,  $\beta < n$ . Then p, q each have one multiple zero. In any  $\infty$ -class, there is exactly one pair with  $p(z) = z^{n+1-\alpha}p_1(z)$ ,  $q(z) = (z-1)^{n+1-\beta}q_1(z)$  and  $p_1$ ,  $q_1$  monic. Consider the equations obtained by equating the coefficients of powers of z in

$$t(z) = z^{n+1-\alpha}P(z) - (z-1)^{n+1-\beta}Q(z),$$

where  $d(t) = \gamma$ ,  $d(P) = \alpha - 1$ ,  $d(Q) = \beta - 1$  and all have undetermined coefficients. There are n+1 homogeneous linear equations in the n+2 unknowns (including k(P) and k(Q)). These have non-trivial solutions. From 1.2, any solution has  $k(P) = k(Q) \neq 0$  and defines a suitable extraspecial pair. If we now demand that k(P) = k(Q) = 1, then we have n linear equations in n unknowns and we know that there are solutions. From the form of the equations, there is a unique solution or an infinite family. Since each solution belongs to a different  $\infty$ -class of degree n, the former occurs. As the equations are rational, so is the solution (without an appeal to 2.4).

This example and 4.3 prove the existence of extra-special pairs of certain kinds. We now describe a family of  $\Gamma$ -specifications for which there are no subgroups/pairs.

EXAMPLE 5.2. There are no special pairs corresponding to the  $\Gamma$ -specification  $[6r, 0, 0, 0, (\gamma(j))]$  where  $\gamma(2) = r$  and  $\gamma(2r) = 0$ . [Petersson [8] has proved this for r = 1.]

Note that, by (13),  $\sum \gamma(j) = r + 1$  so either  $\gamma(2) = r + 1$  or  $\gamma(2) = r$ ,  $\gamma(k) = 1$   $(k \neq 2r)$  and  $\gamma(j) = 0$  for all other j.

A subgroup with such a specification would give r+2 branch points over  $\infty$ , r of order 2, two others of order k, 4r-k. By p. 421 of [11], there is one conjugacy class if k=2r and none otherwise.

[11] gives a number of other  $\Gamma$ -specifications which are not realised. Example 5.2 can also be tackled by manipulation of polynomials. To illustrate the technique, we find the special pairs in the case k = 2r.

Example 5.3. Suppose that [f, g] is a (2, 3)-pair corresponding to the  $\Gamma$ -specification  $[6r, 0, 0, 0, (\gamma(i))]$  with  $\gamma(2) = r$ ,  $\gamma(2r) = 1$  (r > 1).

By a transformation of type (5), we may assume that f, g are monic and

$$f^{3}(z) - g^{2}(z) = \frac{1}{4}27z^{2r}h^{2}(z), \tag{14}$$

with h monic of degree r. Then

$$f^3 = (g + \frac{1}{2}3\sqrt{3}iz^rh)(g - \frac{1}{2}3\sqrt{3}iz^rh).$$

As (f, g) = 1, (g, z'h) = 1 and d(g)(=3r) > d(z'h)(=2r),  $f = f_1f_2$  with  $f_1$ ,  $f_2$  monic and

$$f_1^3 = g + \frac{1}{2}3\sqrt{3}iz'h$$
,  $f_2^3 = g - \frac{1}{2}3\sqrt{3}iz'h$ . (15)

Then

$$3\sqrt{3}iz^{r}h = (f_1 - f_2)(f_1 - \zeta f_2)(f_1 - \zeta^2 f_2)$$

where  $\zeta^3 = 1$ . The factors on the right are pairwise coprime and the last two each have degree r. Choosing  $\zeta$  correctly, we have

$$f_1 - f_2 = i\sqrt{3}$$
,  $f_1 - \zeta f_2 = (1 - \zeta)z'$ ,  $f_1 - \zeta^2 f_2 = (1 - \zeta^2)h$ .

Hence  $f = f_1 f_2 = z^{2r} + \varepsilon z^r + 1$ , with  $\varepsilon = 1$  or -1 depending on  $\zeta$ , and  $h = z^r + \varepsilon$ ,  $g = z^{3r} + \frac{3}{2}\varepsilon z^{2r} - \frac{3}{2}z^r - \varepsilon$ . Replacing z by  $\exp{\pi i/r} z$  if necessary, we can assume that  $\varepsilon = -1$ . Such a transformation preserves the form (14). Thus we have found a (rational) pair of the only  $\infty$ -class. Note that we get a special pair also for r = 1. This is rationally defined although the factorization of the difference  $f^3 - g^2$  could be expected to introduce a quadratic extension. In fact, this is the special pair mentioned in the footnote to §2. Further, the identity for general r is obtained by replacing z by  $z^r$  in that for r = 1. For r = 1, the corresponding subgroup of  $\Gamma$  is  $\Gamma(2)$ —the index and branching at  $\infty$  are right and we have proved that there is only one such subgroup class. Now,  $\Gamma(2)$  has presentation

$$\langle X_1, X_2, X_3 \colon X_1 X_2 X_3 = 1 \rangle$$
 (16)

where  $X_1 = C_1^2$ ,  $X_2 = A_1 X_1 A_1^{-1}$ ,  $X_3 = A_1^{-1} X_1 A_1$ , see [9], p. 63. Thus  $\Gamma(2)$  is free on two generators,  $X_1$ ,  $X_2$  say, and a subgroup for r consists of the words with kr occurrences of  $X_1$  ( $k \in \mathbb{Z}$ ).

As in 5.3, a theorem about subgroups of genus zero in a triangle group will give a result about special pairs of specific kinds. [12] gives results about subgroups of the (2, 3, 7) triangle group  $\Delta_7$ . Now,  $\Delta_7 \simeq T/\langle A^3, B^2, C^7 \rangle^T$ , so that, using (9), we obtain

THEOREM 5.4. Suppose that n,  $\alpha$ ,  $\beta$ ,  $\gamma$  are non-negative integers such that

$$n = 28\alpha + 21\beta + 36\gamma - 84 > 0. \tag{17}$$

*Then, except for (n,a, p,* y) = (16,1,0,2), *there is a special pair (fifl>* gigl) *of degree n with* d(/a) = a, d(gj) = 0 *and*

$$f_1f_2^3 = g_1g_2^2 = h_1h_2^7$$

Formula (17) is the analogue of (13) for subgroups of genus zero in A7.

*Remark* 1. The pairs produced by the method of 4.3 and the preceeding construction are those used in [7] to prove the existence of a subgroup with a given number of branch points over oo on *XfT.* They also correspond to the coset diagrams used in [14] to prove similar results for subgroups of infinite index. In both cases, the *number* of branch points was more significant than their orders.

*Remark 2.* The proof of 4.6 was relatively straight-forward once we had a formula for the number of subgroups of a given specification. We found that our subgroups could have index 1, 2 or 3 in their normalisers. This is not an accident.

Suppose that G, H, / are discontinuous groups acting on 3? with *G<H\*\*I, \G:I\«x>* and g(G) = g(J) = 0. Then g(H) = 0. Let z, *t* be Hauptmoduln for G, *H* respectively. Applying the idea of 1.1 to z, *t* and making considerable use of the fact that C(z)/C(r) is normal and Gal (C(z)/C(f))=»H/G, we find that *H/G* is cyclic, dihedral or one of *A4, S4, A5.* The branching of *%/H* is largely determined by that of *X/G* so that the possible groups may be further reduced. Hence we might expect analogues of 4.6 for other families of specifications. The major problem appears to be the enumeration of subgroups of specific types.

## REFERENCES

- **1. A. O. L. Atkin, H. P. F. Swinnerton-Dyer, 'Modular forms on non-congruence subgroups', In:** *Combinatorics (Proc. Sympos. Pure Math.,* **19) Amer. Math. Soc., Providence, R. I. (1971).**
- **2. B. J. Birch, S. Chowla, M. Hall Jnr. and A. Schinzel, 'On the difference** *x<sup>3</sup> -y2 ', Norske Vid. Selsk. Fork. (Trondheim)* **38 (1965), 65-69.**
- **3. S. D. Cohen, The distribution of the Galois groups of integral polynomials,** *Illinois J. Math.* **23 (1979), 135-152.**
- **4. H. Davenport, 'On AO-g^O'.** *Norske VuL Selsk. Fork, (Twndheim)* **38 (1965), 86-87.**
- **5. M. Hall Jnr., 'Subgroups of finite index in free groups',** *Canad. J. Math.* **1 (1949), 187-190.**
- **6. J. Lehner,** *Discontinuous groups and automorphic functions,* **Amer. Math. Soc. (1964).**
- **7. M. H. Millington, 'Subgroups of the classical modular group',** *J. London Math. Soc.* **(2) 1 (1970), 351-357.**
- **8. H. Petersson, 'Ober die Kongruenzgruppen der Stufe 4', J.** *Reine* **Angew.** *Math.* **212 (1963), 63-72.**

- **9. R. A. Ranltin,** *Modular functions and forms,* **Cambridge University Press (1977).**
- **10. D. Singermann, 'Subgroups of Fuchsian groups and finite permutation groups',** *Bull London Math. Soc.* **2 (1970).**
- **11. W. W. Stothers, 'Impossible specifications for the modular group',** *Manuscripta Math.* **13 (1974), 415-428.**
- **12. W. W. Stothers, 'Subgroups of the (2,3,7)-triangle group',** *Manuscripta Math.* **20 (1977), 323-334.**
- **13. W. W. Stothers, The number of subgroups of given index in the modular group',** *Proc. Roy. Soc. (Edin.)* **78A (1977), 105-112.**
- **14. W. W. Stothers, \*Subgroups of infinite index in the modular group', Glasgow** *Math. J.* **19 (1978), 33-43.**
- **15. H. Weyl,** *The concept of a Riemann surface,* **Addison-Wesley (1955).**
- **16. A. Williamson, 'On primitive permutation groups containing a cycle',** *Math. Z.* **130 (1973), 159-162.**

*Department of Mathematics University of Glasgow Glasgow G12 8QW.*