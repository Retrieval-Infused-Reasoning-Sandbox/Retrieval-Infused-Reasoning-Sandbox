# Chebyshev polynomials, moment matching, and optimal estimation of the unseen

Yihong Wu and Pengkun Yang\*

December 13, 2016

#### Abstract

We consider the problem of estimating the support size of a discrete distribution whose minimum non-zero mass is at least  $\frac{1}{k}$ . Under the independent sampling model, we show that the sample complexity, i.e., the minimal sample size to achieve an additive error of  $\epsilon k$  with probability at least 0.1 is within universal constant factors of  $\frac{k}{\log k} \log^2 \frac{1}{\epsilon}$ , which improves the state-of-the-art result of  $\frac{k}{\epsilon^2 \log k}$  in [VV13]. Similar characterization of the minimax risk is also obtained. Our procedure is a linear estimator based on the Chebyshev polynomial and its approximation-theoretic properties, which can be evaluated in  $O(n + \log^2 k)$  time and attains the sample complexity within a factor of six asymptotically. The superiority of the proposed estimator in terms of accuracy, computational efficiency and scalability is demonstrated in a variety of synthetic and real datasets.

## 1 Introduction

#### <span id="page-0-0"></span>1.1 Model

Estimating the support size of a distribution from data is a classical problem in statistics with widespread applications. For example, a major task for ecologists is to estimate the number of species [FCW43] from field experiments; linguists are interested in estimating the vocabulary size of Shakespeare based on his complete works [McN73, ET76, TE87]; in population genetics it is of great interest to estimate the number of different alleles in a population [HW01]. Estimating the support size is equivalent to estimating the number of unseen symbols, which is particularly challenging when the sample size is relatively small compared to the total population size, since a significant portion of the population are never observed in the data.

We adopt the following statistical model [BO79,RRSS09]. Let P be a discrete distribution over some countable alphabet. Without loss of generality, we assume the alphabet is  $\mathbb{N}$  and denote  $P = (p_1, p_2, \ldots)$ . Given n i.i.d. samples  $X \triangleq (X_1, \ldots, X_n)$  drawn from P, the goal is to estimate the support size

$$S(P) \triangleq \sum_{i} \mathbf{1}_{\{p_i > 0\}}.\tag{1}$$

To estimate the distribution or its functionals, a sufficient statistic is the *histogram* of the samples, denoted by  $N = (N_1, N_2, ...)$  and

<span id="page-0-1"></span>
$$N_i = \sum_{j=1}^n \mathbf{1}_{\{X_j = i\}}.$$
 (2)

<sup>\*</sup>The authors are with the Department of Electrical and Computer Engineering and the Coordinated Science Lab, University of Illinois at Urbana-Champaign, Urbana, IL, {yihongwu,pyang14}@illinois.edu.

Therefore N has a multinomial distribution with parameter n and P. For estimating the support size (or other permutation-invariant functional of the distribution), the *fingerprints* form a sufficient statistic which is a further summary of the histogram N, which are defined as

<span id="page-1-5"></span>
$$h_j = \sum_i \mathbf{1}_{\{N_i = j\}},$$
 (3)

i.e., the number of items that appear exactly j times.

It is clear that unless we impose further assumptions on the distribution P, it is impossible to estimate S(P) within a given accuracy, for otherwise there can be arbitrarily many masses in the support of P that never occur in the samples with high probability and the risk for estimating S(P) is obviously infinite. To prevent the triviality, a conventional assumption [RRSS09] is to impose a lower bound on the non-zero probabilities. Therefore we restrict our attention to the parameter space  $\mathcal{D}_k$ , which consists of all probability distributions on  $\mathbb{N}$  whose minimum non-zero mass is at least  $\frac{1}{k}$ ; consequently  $S(P) \leq k$  for any  $P \in \mathcal{D}_k$ . The decision-theoretic fundamental limit of this problem is given by the minimax risk:

<span id="page-1-3"></span>
$$R^*(k,n) \triangleq \inf_{\hat{S}} \sup_{P \in \mathcal{D}_k} \mathbb{E}[\ell(\hat{S},S)], \tag{4}$$

where the loss function  $\ell(\hat{S}, S) \triangleq (\frac{\hat{S}-S}{k})^2$  is the normalized mean squared error (MSE) and  $\hat{S}$  is an integer-valued estimator measurable with respect to the samples  $X_1, \dots, X_n \stackrel{\text{i.i.d.}}{\sim} P$ .

### <span id="page-1-4"></span>1.2 Main results

<span id="page-1-1"></span>Our first main result is the following characterization of the minimax risk:

**Theorem 1.** For all  $k, n \geq 2$ ,

<span id="page-1-6"></span><span id="page-1-0"></span>
$$R^*(k,n) = \exp\left(-\Theta\left(\sqrt{\frac{n\log k}{k}} \vee \frac{n}{k} \vee 1\right)\right). \tag{5}$$

Furthermore, if  $\frac{k}{\log k} \ll n \ll k \log k$ , as  $k \to \infty$ ,

$$\exp\left(-(\sqrt{2}e + o(1))\sqrt{\frac{n\log k}{k}}\right) \le R^*(k,n) \le \exp\left(-(1.579 + o(1))\sqrt{\frac{n\log k}{k}}\right)$$
 (6)

To interpret the rate of convergence in (5), we consider three cases:

**Simple regime**  $n \gtrsim k \log k$ : we have  $R^*(k,n) = \exp(-\Theta(\frac{n}{k}))$  which can be achieved by the simple plug-in estimator

<span id="page-1-2"></span>
$$\hat{S}_{\text{seen}} \triangleq \sum_{i} \mathbf{1}_{\{N_i > 0\}},\tag{7}$$

that is, the number of observed symbols. Furthermore, if  $\frac{n}{k \log k}$  exceeds a sufficiently large constant, all symbols are present in the data and  $\hat{S}_{\text{seen}}$  is in fact exact with high probability, namely,  $\mathbb{P}[\hat{S}_{\text{seen}} \neq S] \leq \mathbb{E}(\hat{S}_{\text{seen}} - S)^2 \to 0$ . This can be understood as the classical coupon collector's problem (cf. e.g., [MU05]).

Non-trivial regime  $\frac{k}{\log k} \ll n \ll k \log k$ : In this case the samples are relatively scarce and the naive plug-in estimator grossly underestimate the true support size as many symbols are simply not observed. Nevertheless, accurate estimation is still possible and the optimal rate of convergence is given by  $R^*(k,n) = \exp(-\Theta(\sqrt{\frac{n \log k}{k}}))$ . This can be achieved by a linear estimator based on the Chebyshev polynomial and its approximation-theoretic properties. Although more sophisticated than the plug-in estimator, this procedure can be evaluated in  $O(n + \log^2 k)$  time.

Impossible regime  $n \lesssim \frac{k}{\log k}$ : no consistent estimator exists.

<span id="page-2-2"></span>Next we discuss the *sample complexity* of estimating the support size, which is defined as follows:

$$n^*(k,\epsilon) \triangleq \min\{n \ge 0 : \exists \hat{S}, \text{ s.t. } \mathbb{P}[|\hat{S} - S(P)| \ge \epsilon k] \le 0.1, \forall P \in \mathcal{D}_k\},\tag{8}$$

where  $\hat{S}$  is an integer-valued estimator measurable with respect to the samples  $X_1,\ldots,X_n\stackrel{\text{i.i.d.}}{\sim}P$ . Clearly, since  $\hat{S}-S$  is an integer, the only interesting case is  $\epsilon \geq \frac{1}{k}$ , with  $\epsilon = \frac{1}{k}$  corresponding to the exact estimation of the support size since  $|\hat{S}-S|<1$  is equivalent to  $\hat{S}=S$ . Furthermore, since S(P) takes values in [k],  $n^*(k,\frac{1}{2})=0$  by definition. The next result characterizes the sample complexity within universal constant factors that are within a factor of six asymptotically.

<span id="page-2-0"></span>**Theorem 2.** Fix a constant  $c_0 < \frac{1}{2}$ . For all  $\frac{1}{k} \le \epsilon \le c_0$ ,

<span id="page-2-4"></span><span id="page-2-3"></span>
$$n^*(k,\epsilon) \simeq \frac{k}{\log k} \log^2 \frac{1}{\epsilon}.$$
 (9)

Furthermore, if  $\epsilon \to 0$  and  $\epsilon = k^{o(1)}$ , as  $k \to \infty$ ,

$$\frac{1 + o(1)}{2e^2} \frac{k}{\log k} \log^2 \frac{1}{\epsilon} \le n^*(k, \epsilon) \le \frac{1 + o(1)}{2.494} \frac{k}{\log k} \log^2 \frac{1}{\epsilon}.$$
 (10)

Compared to Theorem 1, the only difference is that here we are dealing with the zero-one loss  $\mathbf{1}_{\left\{|S-\hat{S}|\geq\epsilon k\right\}}$  instead of the quadratic loss  $(\frac{S-\hat{S}}{k})^2$ . In the proof we shall obtain upper bound for the quadratic risk and lower bound for the zero-one loss, thereby proving both Theorem 1 and 2 simultaneously. Furthermore, the choice of 0.1 as the probability of error in the definition of the sample complexity is entirely arbitrary; replacing it by  $1-\delta$  for any constant  $\delta \in (0,1)$  only affect  $n^*(k,\epsilon)$  up to constant factors.<sup>1</sup>

## 1.3 Previous work

There is a vast amount of literature devoted to the support size estimation problem. In parametric settings, the data generating distribution is assumed to belong to certain parametric family such as uniform or Zipf [LP56, McN73, DR80] and traditional estimators, such as maximum likelihood estimator and minimum variance unbiased estimator, are frequently used [Har68, MSJ82, Sam68, ET76, LP56, HW01] – see the extensive surveys [BF93, GS04]. When difficult to postulate or justify a suitable parametric assumption, various nonparametric approaches are adopted such as the Good-Turing estimator [Goo53, Rob68] and variants due to Chao and Lee [Cha84, CL92],

<span id="page-2-1"></span><sup>&</sup>lt;sup>1</sup>Specifically, upgrading the confidence to  $1-\delta$  can be achieved by oversampling by merely a factor of  $\log \frac{1}{\delta}$ . Let  $T = \log \frac{1}{\delta}$ . With nT samples, divide them into T batches, apply the n-sample estimator to each batch and aggregate by taking the median. Then Hoeffding's inequality implies the desired confidence.

Jackknife estimator [BO79], empirical Bayes approach (e.g., Good-Toulmin estimator [GT56]), one-sided estimator [ML07]. Despite their practical popularity, little is known about the performance guarantee of these estimators, let alone their optimality. Next we discuss provable results assuming the independent sampling model in Section 1.1.

For the naive plug-in estimator (7), it is easy to show (see Proposition 2) that to estimate S(P) within  $\pm \epsilon k$  the minimal required number of samples is  $\Theta(k \log \frac{1}{\epsilon})$ , which scales logarithmically in  $\frac{1}{\epsilon}$  but linearly in k, the same scaling for estimating the distribution P itself. Recently Valiant and Valiant [VV11] showed that the sample complexity is in fact sub-linear in k; however, the performance guarantee of the proposed estimators are still far from being optimal. Specifically, an estimator based on a linear program that is a modification of [ET76, Program 2] is proposed and shown to achieve  $n^*(k,\epsilon) \lesssim \frac{k}{\epsilon^{2+\delta} \log k}$  for any arbitrary  $\delta > 0$  [VV11, Corollary 11], which has subsequently been improved to  $\frac{k}{\epsilon^2 \log k}$  in [VV13, Theorem 2, Fact 9]. The lower bound  $n^*(k,\epsilon) \gtrsim \frac{k}{\log k}$  in [VV10, Corollary 9] is optimal in k but provides no dependence on  $\epsilon$ . These results show that the optimal scaling in terms of k is  $\frac{k}{\log k}$  but the dependence on the accuracy  $\epsilon$  is  $\frac{1}{\epsilon^2}$ , which is even worse than the plug-in estimator. From Theorem 2 we see that the dependence on  $\epsilon$  can be improved from polynomial to polylogarithmic  $\log^2 \frac{1}{\epsilon}$ , which turns out to be optimal. Furthermore, this can be attained by a linear estimator which is far more scalable than linear programming on massive datasets (see the experiment on New York Times datasets of one billion words in Section 4).

A closely related problem is the distinct elements problem, where the goal is to estimate the number of distinct colors based on repeated draws from in an urn consisting of k colored balls. For sampling with replacement, this can be viewed as a restricted case of the model in the present paper, where the distribution  $P=(p_i)$  has the special form of  $p_i=\frac{k_i}{k}$ , with  $k_i\in\mathbb{Z}_+$  corresponding to the number of balls of the  $i^{\text{th}}$  color and  $\sum_i k_i = k$ . The sample complexity under multiplicative error, that is, estimating S(P) within a factor of  $\alpha$  has been shown to be  $\Theta(\frac{k}{\alpha^2})$  in [CCMN00]. For additive error, that is, estimating S(P) within  $\pm \epsilon k$ , a lower bound has been established in [RRSS09], which, for constant  $\epsilon$ , scales as  $k^{1-O(\sqrt{\frac{\log\log k}{\log k}})}$ . This, in turn, implies a lower bound for  $n^*(k,\epsilon)$ , which is slightly suboptimal compared to the tight bound  $\frac{k}{\log k} = k^{1-\frac{\log\log k}{\log k}}$ .

#### 1.4 Organization

The paper is organized as follows: In Section 2 we outline the proof for the lower bound part of Theorem 1 and 2 and the construction of the least favorable priors. In Section 3 we construct an estimator based on Chebyshev polynomials which achieves the minimax risk and the sample complexity within constant factors. In Section 4 we apply our estimators to both synthetic and real data and compare the performance with existing methodologies. Proofs of the lower and upper bounds are given in Section 5 and 6, respectively.

#### 1.5 Notations

For  $k \in \mathbb{N}$ , let  $[k] \triangleq \{1, \ldots, k\}$ . The *n*-fold product of a distribution P is denoted by  $P^{\otimes n}$ . Let  $\operatorname{Poi}(\lambda)$  denote the Poisson distribution with mean  $\lambda$  whose probability mass function is denoted by  $\operatorname{poi}(\lambda, j) \triangleq \frac{\lambda^j e^{-\lambda}}{j!}, j \geq 0$ . Given a positive random variable U, denote the Poisson mixture with respect to the distribution of U by  $\mathbb{E}\left[\operatorname{Poi}\left(U\right)\right]$ , whose probability mass function is given by  $\frac{1}{j!}\mathbb{E}[U^j e^{-U}], j \geq 0$ . Let  $\operatorname{Bern}(p) = p\delta_1 + (1-p)\delta_0$  denote the Bernoulli1i distribution. The total variation and the Kullback-Leibler divergence between probability measures P and Q are denoted by  $\operatorname{TV}(P,Q) \triangleq \frac{1}{2}\int |\mathrm{d}P - \mathrm{d}Q|$  and  $D(P\|Q) \triangleq \int \mathrm{d}P \log \frac{\mathrm{d}P}{\mathrm{d}Q}$  respectively. We use standard big-O notations, e.g., for any positive sequences  $\{a_n\}$  and  $\{b_n\}$ ,  $a_n = O(b_n)$  or  $a_n \lesssim b_n$  if  $a_n \leq Cb_n$  for

some absolute constant C > 0,  $a_n = o(b_n)$  or  $a_n \ll b_n$  or if  $\lim a_n/b_n = 0$ . In order to extract non-asymptotic statements from asymptotic ones, we pay extra attention to o(1) terms. Specifically, we write  $o_{\delta}(1)$  as  $\delta \to 0$  to indicate convergence to zero that is uniform in all other parameters.

## <span id="page-4-0"></span>2 Minimax lower bound

The lower bound argument follows the idea in [LNS99, CL11, WY16] and relies on the generalized Le Cam's lemma involving two composite hypothesis. In the following we illustrate the main idea for constructing a pair of priors that are near least favorable.

Let  $\lambda > 1$ . Given unit-mean random variables U and U' that take values in  $\{0\} \cup [1, \lambda]$ , define the following random vectors

<span id="page-4-1"></span>
$$P = \frac{1}{k}(U_1, \dots, U_k), \quad P' = \frac{1}{k}(U'_1, \dots, U'_k), \tag{11}$$

where  $U_i$  and  $U_i'$  are i.i.d. copies of U and U', respectively. Although P and P' need not be probability distributions, as long as the standard deviation of U and U' are not too big, the law of large numbers ensures that with high probability P and P' lie in a small neighborhood near the probability simplex, which we refer as the set of approximate probability distributions. Furthermore, the minimum non-zeros in P and P' are at least  $\frac{1}{k}$ . It can be shown that the minimax risk over approximate probability distributions is close to that over the original parameter space  $\mathcal{D}_k$  of probability distributions. This allows us to use P and P' as priors and apply Le Cam's method. Note that both S(P) and S(P') are binomially distributed, which, with high probability, differ by the difference in their mean values:

$$\mathbb{E}[S(\mathsf{P})] - \mathbb{E}[S(\mathsf{P}')] = k(\mathbb{P}[U > 0] - \mathbb{P}[U' > 0]) = k(\mathbb{P}[U' = 0] - \mathbb{P}[U = 0]).$$

If we can establish the impossibility of testing whether data are generated from P or P', the resulting lower bound is proportional to  $k(\mathbb{P}[U'=0]-\mathbb{P}[U=0])$ .

To simplify the argument we apply the Poissonization technique where the sample size is a  $\operatorname{Poi}(n)$  random variable instead of a fixed number n. This provably does not change the statistical nature of the problem due to the concentration of  $\operatorname{Poi}(n)$  around its mean n. Under Poisson sampling, the histograms (2) still constitute a sufficient statistic, which are distributed as  $N_i \stackrel{\operatorname{ind}}{\sim} \operatorname{Poi}(np_i)$ , as opposed to multinomial distribution in the fixed-sample-size model. Therefore through the i.i.d. construction in (11),  $N_i \stackrel{\operatorname{i.i.d.}}{\sim} \mathbb{E}[\operatorname{Poi}(\frac{n}{k}U)]$  or  $\mathbb{E}[\operatorname{Poi}(\frac{n}{k}U')]$ . Then Le Cam's lemma is applicable if  $\operatorname{TV}(\mathbb{E}[\operatorname{Poi}(\frac{n}{k}U)]^{\otimes k}, \mathbb{E}[\operatorname{Poi}(\frac{n}{k}U')]^{\otimes k})$  is strictly bounded away from one, for which it suffices to show

<span id="page-4-2"></span>
$$\mathsf{TV}(\mathbb{E}[\mathrm{Poi}(nU/k)], \mathbb{E}[\mathrm{Poi}(nU'/k)]) \le \frac{c}{k},$$
 (12)

for some constant c < 1.

The above construction provides a recipe for the lower bound. To optimize the ingredients it boils down to the following optimization problem (over one-dimensional probability distributions): Construct two priors U, U' with unit mean that maximize the difference  $\mathbb{P}[U'=0] - \mathbb{P}[U=0]$  subject to the total variation distance constraint (12), which, in turn, can be guaranteed by moment matching, i.e., ensuring U and U' have identical first L moments for some large L, and the  $L_{\infty}$ -norms U, U' are not too large. To summarize, our lower bound entails solving the following optimization

<span id="page-5-1"></span>problem:

$$\sup \mathbb{P}[U'=0] - \mathbb{P}[U=0]$$
s.t.  $\mathbb{E}[U] = \mathbb{E}[U'] = 1$ 

$$\mathbb{E}[U^{j}] = \mathbb{E}[U'^{j}], \quad j=1,\ldots,L$$

$$U, U' \in \{0\} \cup [1,\lambda].$$
(13)

The final lower bound is obtained from 13 by choosing  $L \simeq \log k$  and  $\lambda \simeq \frac{k \log k}{n}$ .

In order to evaluate the infinite-dimensional linear programming problem 13, by considering its dual program we show (in Appendix A) that 13 coincides exactly with the best uniform approximation error of the function  $x \mapsto \frac{1}{x}$  over the interval  $[1, \lambda]$  by degree-(L-1) polynomials:

<span id="page-5-3"></span>
$$\inf_{p \in \mathcal{P}_{L-1}} \sup_{x \in [1,\lambda]} \left| \frac{1}{x} - p(x) \right|,$$

where  $\mathcal{P}_{L-1}$  denotes the set of polynomials of degree L-1. The problem of best polynomial approximation has been well-studied, cf. [Tim63, DS08]; in particular, the exact formula for the best polynomial that approximates  $x \mapsto \frac{1}{x}$  and the optimal approximation error have been obtained in [Tim63, Sec. 2.11.1].

Applying the procedure described above, we obtain the following sample complexity lower bound:

<span id="page-5-2"></span>Proposition 1. Let 
$$\delta \triangleq \frac{\log \frac{1}{\epsilon}}{\log k}$$
 and  $\tau \triangleq \frac{\sqrt{\log k}/k^{1/4}}{1-2\epsilon}$ . As  $k \to \infty$ ,  $\delta \to 0$  and  $\tau \to 0$ ,
$$n^*(k,\epsilon) \ge (1 - o_{\delta}(1) - o_{k}(1) - o_{\tau}(1)) \frac{k}{2e^2 \log k} \log^2 \frac{1}{2\epsilon}. \tag{14}$$

Consequently, if  $\frac{1}{k^c} \le \epsilon \le \frac{1}{2} - c' \frac{\sqrt{\log k}}{k^{1/4}}$  for some constants c, c' then  $n^*(k, \epsilon) \gtrsim \frac{k}{\log k} \log^2 \frac{1}{2\epsilon}$ .

The lower bounds announced in Theorems 1 and 2 follow from Proposition 1 combined with a simple two-point argument. See Section 5.2.

# <span id="page-5-0"></span>3 Optimal estimator via Chebyshev polynomials

In this section we prove the upper bound part of Theorem 1 and describe the rate-optimal support size estimator. Following the same idea as in the lower bound part, we shall apply the Poissonization technique to simplify the analysis where the sample size is Poi(n) instead of a fixed number n and hence the sufficient statistics  $N = (N_1, \ldots, N_k) \stackrel{\text{ind}}{\sim} Poi(np_i)$ . Analogous to (4), the minimax risk under the Poisson sampling is defined by

$$\tilde{R}^*(k,n) \triangleq \inf_{\hat{S}} \sup_{P \in \mathcal{D}_k} \mathbb{E}[\ell(\hat{S},S)]. \tag{15}$$

Due to the concentration of Poi(n) near its mean n, the minimax risk with fixed sample size is close to that under the Poisson sampling, as shown in the following lemma, which allows us to focus on the model using Poissonized sample size.

<span id="page-5-4"></span>**Lemma 1.** For any  $\beta < 1$ ,

$$R^*(k,n) \le \frac{\tilde{R}^*(k,(1-\beta)n)}{1 - \exp(-n\beta^2/2)}.$$

In the next proposition, we first analyze the risk of the plug-in estimator  $\hat{S}_{\text{seen}}$ , which yields the optimal upper bound of Theorem 1 in the regime of  $n \gtrsim k \log k$ . This is consistent with the coupon collection intuition explained in Section 1.2.

<span id="page-6-0"></span>**Proposition 2.** For all  $n, k \ge 1$ ,

$$\sup_{P \in \mathcal{D}_k} \mathbb{E}(S(P) - \hat{S}_{\text{seen}}(N))^2 \le k^2 e^{-2n/k} + k e^{-n/k},\tag{16}$$

where  $N = (N_1, N_2, ...)$  and  $N_i \stackrel{ind}{\sim} Poi(np_i)$ .

Conversely, for P that is uniform over [k], for any fixed  $\delta \in (0,1)$ , if  $n \leq (1-\delta)k\log\frac{1}{\epsilon}$ , then as  $k \to \infty$ ,

<span id="page-6-6"></span>
$$\mathbb{P}[|S(P) - \hat{S}_{\text{seen}}(N)| \le \epsilon k] \le e^{-\Omega(k^{\delta})}.$$
(17)

To specify the optimal estimator in the regime of  $n \lesssim k \log k$ , we first introduce Chebyshev polynomials. Recall that the usual Chebyshev polynomial of degree L is

$$T_L(x) = \cos(L \arccos x) = (z^L + z^{-L})/2,$$
 (18)

where z is the solution of the quadratic equation  $z + z^{-1} = 2x$ . Note that  $T_L$  is bounded in magnitude by one over the interval [-1, 1]. The shifted and scaled Chebyshev polynomial over the interval [l, r] is given by

<span id="page-6-2"></span>
$$P_L(x) = -\frac{T_L(\frac{2x - r - l}{r - l})}{T_L(\frac{-r - l}{r - l})} \triangleq \sum_{m = 0}^{L} a_m x^m,$$
(19)

<span id="page-6-4"></span>which satisfies  $P_L(0) = -1$  and hence  $a_0 = -1$ ; the remaining coefficients  $a_1, \ldots, a_L$  can be obtained from those of the Chebyshev polynomial [Tim63, 2.9.12] and the binomial expansion, or more directly,

$$a_{j} = \frac{P_{L}^{(j)}(0)}{j!} = -\left(\frac{2}{r-j}\right)^{j} \frac{1}{j!} \frac{T_{L}^{(j)}(-\frac{r+l}{r-l})}{T_{L}(-\frac{r+l}{r-l})}.$$
 (20)

<span id="page-6-3"></span>Let

$$g_L(j) = \begin{cases} \frac{a_j j!}{n^j} + 1, & j \le L, \\ 1, & j > L. \end{cases}$$
 (21)

Obviously  $g_L(0) = 0$  since  $a_0 = -1$  by design. We Define our estimator by

<span id="page-6-5"></span><span id="page-6-1"></span>
$$\hat{S} = \sum_{i} g_L(N_i). \tag{22}$$

We proceed to explain the reasoning behind the estimator (22). Note that the bias is  $\mathbb{E}[\hat{S} - S] = \sum_{i} \mathbb{E}\left[g_L(N_i) - \mathbf{1}_{\{p_i > 0\}}\right]$ . Since  $g_L(0) = 0$  and  $g_L(j) = 1$  for j > L, each term in the bias can be written as

$$\mathbb{E}\left[g_{L}(N_{i}) - \mathbf{1}_{\{p_{i}>0\}}\right] = \mathbb{E}\left[\left(g_{L}(N_{i}) - 1\right)\mathbf{1}_{\{p_{i}>0\}}\mathbf{1}_{\{N_{i}\leq L\}}\right]$$

$$= \sum_{i=0}^{L} e^{-np_{i}} \frac{(np_{i})^{j}}{j!} \frac{a_{j}j!}{n^{j}} \mathbf{1}_{\{p_{i}>0\}} = e^{-np_{i}} P_{L}(p_{i}) \mathbf{1}_{\{p_{i}>0\}}$$
(23)

where  $P_L$  is the degree-L polynomial defined in (19).

<span id="page-7-4"></span>Let

$$L \triangleq \lfloor c_0 \log k \rfloor, \quad r \triangleq \frac{c_1 \log k}{n}, \quad l \triangleq \frac{1}{k},$$
 (24)

where  $c_0 < c_1$  are constants to be specified. The main intuition is that since  $c_0 < c_1$ , then with high probability, whenever  $N_i \leq L = \lfloor c_0 \log k \rfloor$  the corresponding mass must satisfy  $p_i \leq \frac{c_1 \log k}{n}$ . That is, if  $p_i > 0$  and  $N_i \leq L$  then  $p_i \in [\frac{1}{k}, \frac{c_1 \log k}{n}]$ , and hence  $P_L(p_i)$  is bounded by the sup-norm of  $P_L$ over the interval  $\left[\frac{1}{k}, \frac{c_1 \log k}{n}\right]$ . In view of the property of Chebyshev polynomials [Tim63, Ex. 2.13.14], (19) is the unique degree-L polynomial that passes through the point (0, -1) and deviates the least from zero over  $\left[\frac{1}{k}, \frac{c_1 \log k}{n}\right]$ . This explains the coefficients (21) which are chosen to minimize the bias. The next proposition gives an upper bound of the quadratic risk of our estimator (22):

**Proposition 3.** Let  $c_0 = 0.558$  and  $c_1 = 0.5$ . As  $\delta \triangleq \frac{n}{k \log k} \to 0$  and  $k \to \infty$ ,

$$\sup_{P \in \mathcal{D}_k} \mathbb{E}(\hat{S}(N) - S(P))^2 \le 4k^2 (1 + o_k(1)) \exp\left(-(2 + o_\delta(1))\sqrt{\kappa \frac{n \log k}{k}}\right),\tag{25}$$

where  $N = (N_1, N_2, \dots) \stackrel{ind}{\sim} \operatorname{Poi}(np_i)$ , and  $\kappa = 2.494$ .

The minimax upper bounds in Theorems 1 and 2 follow from combining Propositions 2 and 3. See Section 6.2.

The estimator (22) belong to the family of *linear estimators*:

<span id="page-7-3"></span><span id="page-7-0"></span>
$$\hat{S} = \sum_{i} f(N_i) = \sum_{j \ge 1} f(j)h_j, \tag{26}$$

which is a linear combination of fingerprints  $h_j$ 's defined in (3). Other notable examples of linear estimators include:

- Plug-in estimator (7):  $\hat{S}_{\text{seen}} = h_1 + h_2 + \dots$
- Good-Toulmin estimator [GT56]: for some t > 0.

<span id="page-7-1"></span>
$$\hat{S}_{GT} = \hat{S}_{seen} + th_1 - t^2h_2 + t^3h_3 - t^4h_4 + \dots$$
 (27)

• Efron-Thisted estimator [ET76]: for some t > 0 and  $J \in \mathbb{N}$ ,

<span id="page-7-2"></span>
$$\hat{S}_{ET} = \hat{S}_{seen} + \sum_{j=1}^{J} (-1)^{j+1} t^j b_j h_j,$$
(28)

where  $b_i = \mathbb{P}[\text{Binomial}(J, 1/(t+1)) \geq j].$ 

By definition, our estimator (22) can be written as

<span id="page-7-5"></span>
$$\hat{S} = \sum_{j=1}^{L} g_L(j)h_j + \sum_{j>L} h_j.$$
 (29)

By (21),  $g_L$  is also a polynomial of degree L, which is oscillating and results in coefficients with alternating signs (see Fig. 1). Interestingly, this behavior, although counterintuitive, coincide with many classical estimators, such as (27) and (28).

![](_page_8_Figure_0.jpeg)

<span id="page-8-1"></span>Figure 1: Coefficients of estimator g<sup>L</sup> in [\(21\)](#page-6-3) with c<sup>0</sup> = 0.45, c<sup>1</sup> = 0.5, k = 10<sup>6</sup> and n = 2 × 10<sup>5</sup> .

Remark 1 (Time complexity). The evaluation of the estimator [\(26\)](#page-7-3) consists of three parts:

- 1. Construction of the estimator: O(L 2 ) = O(log<sup>2</sup> k), which amounts to computing the coefficients fL(j) per [\(20\)](#page-6-4);
- 2. Computing the histograms N<sup>i</sup> and fingerprints h<sup>j</sup> : O(n);
- 3. Evaluating the linear combination: O(n∧k), since the number of non-zero terms in the second summation of [\(26\)](#page-7-3) is at most n ∧ k.

Therefore the total time complexity is O(n + log<sup>2</sup> k).

Remark 2. The technique of polynomial approximation has been previously used for estimating non-smooth functions (Lq-norms) in Gaussian models [\[INK87,](#page-24-11) [LNS99,](#page-24-10) [CL11\]](#page-23-6) and more recently for estimating information quantities (entropy and power sums) on large discrete alphabets [\[WY16,](#page-25-9) [JVHW15\]](#page-24-12). The design principle is to approximate the non-smooth function on a given interval using algebraic or trigonometric polynomials for which unbiased estimators exist and choose the degree to balance the bias (approximation error) and the variance (stochastic error). Note that in general uniform approximation by polynomials is only possible on a compact interval. Therefore, in many situations, the construction of the estimator is a two-stage procedure involving sample splitting: First, use half of the sample to test whether the corresponding parameter lies in the given interval; Second, use the remaining samples to construct an unbiased estimator for the approximating polynomial if the parameter belongs to the interval or apply plug-in estimators otherwise (see, e.g., [\[WY16,](#page-25-9) [JVHW15\]](#page-24-12) and [\[CL11,](#page-23-6) Section 5]).

While the benefit of sample splitting is to make the analysis tractable by capitalizing on the independence of the two subsamples, the downside is obviously sacrificing the statistical accuracy since half of the samples are wasted. In the present paper, to estimate the support size, we forgo the sample splitting approach and directly design a linear estimator. Instead of using a polynomial as a proxy for the original function and then constructing its unbiased estimator, the best polynomial approximation arises as a natural step in controlling the bias (see [\(23\)](#page-6-5)).

# <span id="page-8-0"></span>4 Experiments

We evaluate the performance of our estimator on both synthetic and real datasets in comparison with popular existing procedures. In the experiments we choose the constants c<sup>0</sup> = 0.45, c<sup>1</sup> = 0.5 in (24), instead of  $c_0 = 0.558$  which is optimized to yield the best rate of convergence in Proposition 3 under the iid sample model. The reason for such a choice is that in the real-data experiments the samples are not necessarily generated independently and dependency leads to a higher variance. By choosing a smaller  $c_0$ , the Chebyshev polynomials have a slightly smaller degree, which results in smaller variance and more robustness to model mismatch. Each experiment is averaged over 50 independent trials and the standard deviations are shown as error bars.

Synthetic data We consider data independently sampled from the following distributions, (a) the uniform distribution with  $p_i = \frac{1}{k}$ , (b) Zipf distributions with  $p_i \propto i^{-\alpha}$  and  $\alpha$  being either 1 or 0.5, (c) an even mixture of geometric distribution and Zipf distribution where for the first half of the alphabet  $p_i \propto 1/i$  and for the second half  $p_{i+k/2} \propto (1 - \frac{2}{k})^{i-1}$ ,  $1 \le i \le \frac{k}{2}$ . The alphabet size k varies in each distribution so that the minimum non-zero mass is roughly  $10^{-6}$ . Accordingly, a degree-6 Chebyshev polynomial is applied. Therefore, according to (29), we apply the polynomial estimator  $g_L$  to symbols appearing at most six times and the plug-in estimator otherwise. We compare

![](_page_9_Figure_2.jpeg)

Figure 2: Performance comparison under four data-generating distributions.

our results with the Good-Turing estimator [Goo53], the two estimators proposed by Chao and Lee [CL92], and the linear programming approach proposed by Valiant and Valiant [VV13]. Here the Good-Turing estimator refers to first estimate the total probability of seen symbols (sample coverage) by  $\hat{C} = 1 - \frac{h_1}{n}$  then estimate the support size by  $\hat{S} = \hat{S}_{\text{seen}}/\hat{C}$ . The plug-in estimator simply counts the number of distinct elements observed, which is always outperformed by the Good-Turing estimator in our experiments and hence omitted in the comparison.

Good-Turing's estimate on sample coverage performs remarkably well in the special case of

uniform distributions. This has been noticed and analyzed in [CL92, DR80]. Chao-Lee's estimators are based on Good-Turing's estimate with further correction terms for non-uniform distributions. However, with limited number of samples, if no symbol appears more than once, the sample coverage estimate  $\hat{C}$  is zero and consequently the Good-Turing estimator and Chao-Lee estimators are not even well-defined. For Zipf and mixture distributions, the output of Chao-Lee's estimators is highly unstable and thus is omitted from the plots; the convergence rate of Good-Turing estimator is much slower than our estimator and the linear programming approach, partly because it only uses the information of how many symbols occurred exactly once, namely  $h_1$ , instead of the full spectrum of fingerprints  $\{h_j\}_{j\geq 1}$ ; the linear programming approach has similar convergence rate to ours but suffers large variance when samples are scarce.

Real data Next we evaluate our estimator by a real data experiment based on the text of Ham-let, which contains about 32,000 words in total consisting of about 4,800 distinct words. Here and below the definition of "distinct word" is any distinguishable arrangement of letters that are delimited by spaces, insensitive to cases, with punctuations removed. We randomly sample the text with replacement and generate the fingerprints for estimation. The minimum non-zero mass is naturally the reciprocal of the total number of words,  $\frac{1}{32,000}$ . In this experiment we use the degree-4 Chebyshev polynomial. We also compare our estimator with the one in [VV13]. The results are plotted in Fig. 3, which shows that the estimator in [VV13] has similar convergence rate to ours;

![](_page_10_Figure_2.jpeg)

<span id="page-10-0"></span>Figure 3: Comparison of various estimates of the total number of distinct words in *Hamlet*.

however, the variance is again much larger and the computational cost of linear programming is significantly higher than linear estimators, which amounts to computing linear combinations with pre-determined coefficients.

On a larger scale experiment we used the New York Times Corpus from the years 1987 – 2007.[2](#page-11-0) This corpus has a total of 25,020,626 paragraphs consisting of 996,640,544 words with 2,047,985 distinct words. We randomly sample 1% – 50% out of the all paragraphs with replacements and feed the fingerprint to our estimator. The minimum non-zero mass is also the reciprocal of the total number of words, 1/10<sup>9</sup> , and thus the degree-9 Chebyshev polynomial is applied. Using only

![](_page_11_Figure_1.jpeg)

<span id="page-11-1"></span>Figure 4: Performance of our estimator using New York Times Corpus.

20% samples our estimator achieves a relative error of about 10%, which is a systematic error due to the model mismatch: the sampling here is paragraph by paragraph rather than word by word, which induces dependence across samples as opposed to the iid sampling model for which the estimator is designed. For this large dataset the linear programming estimator has unbearable computational cost: Even for the data of a single year the linear programming takes over 100 hours to compute on a server with E5-2623 CPU and 96 GB RAM; in contrast, the proposed linear estimator takes less than 15 minutes to run for the entire 20-year dataset on the same computer, which clearly demonstrates its computational advantage even if one factors into the difference that our implementation is based on C++ instead of MATLAB used in [\[VV13\]](#page-25-0).

Finally, we perform the classical experiment of "how many words did Shakespeare know". We feed the fingerprint of the entire Shakespearean canon (see [\[ET76,](#page-24-2) Table 1]), which contains 31,534 word types, to our estimator. We choose the minimum non-zero mass to be the reciprocal of the total number of English words, which, according to known estimates, is between 600,000 [\[ED\]](#page-24-13) to 1,000,000 [\[Mon\]](#page-24-14), and obtain an estimate of 63,148 to 73,460 for Shakespeare's vocabulary size, as compared to 66,534 obtained by Efron-Thisted [\[ET76\]](#page-24-2).

<span id="page-11-0"></span><sup>2</sup>Data available at <https://catalog.ldc.upenn.edu/LDC2008T19>.

# <span id="page-12-0"></span>5 Proof of lower bounds

## 5.1 Proof of Proposition 1

*Proof.* For  $0 < \nu < 1$ , define the set of approximate probability vectors by

$$\mathcal{D}_k(\nu) \triangleq \left\{ P = (p_1, p_2, \dots) : \left| \sum_i p_i - 1 \right| \le \nu, p_i \in \{0\} \cup \left[ \frac{1+\nu}{k}, 1 \right] \right\}.$$

which reduces to the original probability distribution space  $\mathcal{D}_k$  if  $\nu = 0$ . Generalizing the sample complexity  $n^*(k,\epsilon)$  in (8) to the Poisson sampling model over  $\mathcal{D}_k(\nu)$ , we define

$$n^*(k,\epsilon,\nu) \triangleq \min\{n \ge 0 : \exists \hat{S}, \text{ s.t. } \mathbb{P}[|\hat{S} - S(P)| \ge \epsilon k] \le 0.1, \forall P \in \mathcal{D}_k(\nu)\}, \tag{30}$$

where  $\hat{S}$  is an integer-valued estimator measurable with respect to  $N = (N_1, N_2, \dots) \stackrel{\text{ind}}{\sim} \operatorname{Poi}(np_i)$ . The sample complexity of the fixed-sample-size and Poissonized model is related by the following lemma:

<span id="page-12-5"></span>**Lemma 2.** For any  $\nu \in (0,1)$  and any  $\epsilon \in (0,\frac{1}{2})$ ,

$$n^*(k,\epsilon) \ge (1-\nu)\tilde{n}^*(k,\epsilon,\nu) \left(1 - O\left(\frac{1}{\sqrt{(1-\nu)\tilde{n}^*(k,\epsilon,\nu)}}\right)\right). \tag{31}$$

To establish a lower bound of  $\tilde{n}^*(k,\epsilon,\nu)$ , we apply generalized Le Cam's method involving two composite hypothesis. Given two random variables  $U,U'\in[0,k]$  with unit mean we can construct two random vectors by  $\mathsf{P}=\frac{1}{k}(U_1,\ldots,U_k)$  and  $\mathsf{P}'=\frac{1}{k}(U_1',\ldots,U_k')$  with i.i.d. entries. Then  $\mathbb{E}[S(\mathsf{P})]-\mathbb{E}[S(\mathsf{P}')]=k(\mathbb{P}[U>0]-\mathbb{P}[U'>0])$ . Furthermore, both  $S(\mathsf{P})$  and  $S(\mathsf{P}')$  are binomially distributed, which are tightly concentrated at the respective means. We can reduce the problem to the separation on mean values, as shown in the next lemma:

<span id="page-12-1"></span>**Lemma 3.** Let  $U, U' \in \{0\} \cup [1 + \nu, \lambda]$  be random variables such that  $\mathbb{E}[U] = \mathbb{E}[U'] = 1$ ,  $\mathbb{E}[U^j] = \mathbb{E}[U'^j]$  for  $j \in [L]$ , and  $|\mathbb{P}[U > 0] - \mathbb{P}[U' > 0]| = d$ . Then, for any  $\alpha < 1/2$ ,

<span id="page-12-4"></span>
$$\frac{2\lambda}{k\nu^2} + \frac{2}{k\alpha^2 d^2} + k\left(\frac{en\lambda}{2kL}\right)^L \le 0.6 \Rightarrow \tilde{n}^*\left(k, \frac{(1-2\alpha)d}{2}, \nu\right) \ge n. \tag{32}$$

Applying Lemma 5 in Appendix A, we obtain two random variables  $U, U' \in \{0\} \cup [1 + \nu, \lambda]$  such that  $\mathbb{E}[U] = \mathbb{E}[U'] = 1$ ,  $\mathbb{E}[U^j] = \mathbb{E}[U'^j]$ , j = 1, ..., L and

$$\mathbb{P}[U>0] - \mathbb{P}[U'>0] = 2E_{L-1}\left(\frac{1}{x}, [1+\nu, \lambda]\right) = \frac{\left(1+\sqrt{\frac{1+\nu}{\lambda}}\right)^2}{1+\nu} \left(1-\frac{2\sqrt{\frac{1+\nu}{\lambda}}}{1+\sqrt{\frac{1+\nu}{\lambda}}}\right)^L \triangleq d,$$

where the value of  $E_{L-1}(\frac{1}{x},[1+\nu,\lambda])$  follows from [Tim63, 2.11.1]. To apply Lemma 3 and obtain a lower bound of  $\tilde{n}^*(k,\epsilon,\nu)$ , we need to pick the parameters depending on the given k and  $\epsilon$  to fulfill:

<span id="page-12-2"></span>
$$\frac{(1-2\alpha)d}{2} \ge \epsilon,\tag{33}$$

<span id="page-12-3"></span>
$$\frac{2\lambda}{k\nu^2} + \frac{2}{k\alpha^2 d^2} + k\left(\frac{en\lambda}{2kL}\right)^L \le 0.6. \tag{34}$$

Let

$$L = \lfloor c_0 \log k \rfloor, \quad \lambda = \left(\frac{\gamma \log k}{\log(1/2\epsilon)}\right)^2, \quad n = C \frac{k}{\log k} \log^2 \frac{1}{2\epsilon},$$
$$\alpha = \frac{1}{k^{1/3}}, \quad \nu = \sqrt{\sqrt{\lambda/k}(1 - 2\epsilon)},$$

for some  $c_0, \gamma, C \approx 1$  to be specified, and by assumption  $L, \lambda \to \infty$ ,  $\frac{\alpha}{1-2\epsilon} = o_k(1)$ ,  $\frac{\nu}{1-2\epsilon} = o_{\tau}(1) + o_k(1)$ ,  $1/\lambda = o_{\delta}(1)$ . Since  $d \geq \frac{1}{1+\nu}(1-2\sqrt{\frac{1+\nu}{\lambda}})^L$ , a sufficient condition for (33) is that

$$\left(1 - 2\sqrt{\frac{1+\nu}{\lambda}}\right)^{L} \ge 2\epsilon \frac{1+\nu}{1-2\alpha} \Leftrightarrow \frac{\gamma}{c_0} > 2 + o_{\tau}(1) + o_{\delta}(1) + o_{k}(1).$$
(35)

Now we consider (34). By the choice of  $\nu$  and  $\alpha$ , we have

<span id="page-13-1"></span>
$$\nu \gg \sqrt{\lambda/k}, \quad \alpha \gg 1/\sqrt{k}d,$$

since  $1 - 2\epsilon \gg \frac{\sqrt{\log k}}{k^{1/4}}$ ,  $d \geq \frac{2\epsilon}{1-2\alpha}$  and  $\epsilon = k^{-o(1)}$ . Then the first two terms in (34) vanish. The last term in (34) vanishes as long as the constant  $C < \frac{2c_0}{\epsilon\gamma^2}e^{-1/c_0}$ . By the fact that

$$\sup \left\{ \frac{2c_0}{e\gamma^2} e^{-1/c_0} : 0 < 2c_0 < \gamma \right\} = \frac{1}{2e^2},$$

the optimal C satisfying (35) is  $\frac{1+o_{\delta}(1)+o_{\tau}(1)+o_{k}(1)}{2e^{2}}$ . Therefore, combining (33) – (34) and applying (32), we obtain a lower bound of  $\tilde{n}^{*}$  that

$$\tilde{n}^*(k,\epsilon,\nu) \ge \frac{1 + o_\delta(1) + o_\tau(1) + o_k(1)}{2e^2} \frac{k}{\log k} \log^2 \frac{1}{2\epsilon}.$$

Since  $1-2\epsilon\gg \frac{\sqrt{\log k}}{k^{1/4}}$ , we have  $\tilde{n}^*(k,\epsilon,\nu)\gg \sqrt{k}$ . Applying Lemma 2, we conclude the desired lower bound of  $n^*(k,\epsilon)$ .

#### <span id="page-13-0"></span>5.2 Lower bound parts of Theorems 1 and 2

Proof of lower bound of Theorem 2. The lower bound part of (10) follows from Proposition 1. Consequently, we obtain the lower bound part of (9) for  $\frac{1}{k^c} \le \epsilon \le c_0$  for the fixed constant  $c_0 < 1/2$ .

The lower bound part of (9) for  $\frac{1}{k} \leq \epsilon \leq \frac{1}{k^c}$  simply follows from the fact that  $\epsilon \mapsto n^*(k, \epsilon)$  is decreasing:

$$n^*(k,\epsilon) \ge n^*(k,1/k^c) \gtrsim k \log k \approx \frac{k}{\log k} \log^2 \frac{1}{\epsilon}.$$

Proof of lower bound of Theorem 1. By the Markov inequality,

$$n^*(k, \epsilon) > n \Rightarrow R^*(k, n) > 0.1\epsilon^2.$$

Therefore, our lower bound is

$$R^*(k,n) \ge \sup\{0.1\epsilon^2 : n^*(k,\epsilon) > n\} = 0.1\epsilon_*^2,$$

where  $\epsilon_* \triangleq \{\epsilon : n^*(k, \epsilon) > n\}$ . By the lower bound of  $n^*(k, \epsilon)$  in (14), we obtain that

$$\epsilon_* \geq \exp\left(-\left(\sqrt{2}e + o_\delta(1) + o_{\delta'}(1) + o_k(1)\right)\sqrt{\frac{n\log k}{k}}\right),$$

as  $\delta \triangleq \frac{n}{k \log k} \to 0$ ,  $\delta' \triangleq \frac{k}{n \log k} \to 0$ , and  $k \to \infty$ . Then we conclude the lower bound part of (6), which implies the lower bound part of (5) when  $n \lesssim k \log k$ .

For the lower bound part of (5) when  $n \gtrsim k \log k$ , we apply Le Cam's two-point method [LC86] by considering two possible distributions, namely P = Bern(0) and  $Q = \text{Bern}(\frac{1}{k})$ . Then

$$R^*(k,n) \ge \frac{1}{4} (S(P) - S(Q))^2 \exp(-nD(P||Q)) = \frac{k^2}{4} \exp\left(n\log\left(1 - \frac{1}{k}\right) - 2\log k\right).$$

Since  $n \gtrsim k \log k$ , we have  $n \log \left(1 - \frac{1}{k}\right) - 2 \log k \gtrsim -\frac{n}{k}$ .

#### 5.3 Proof of lemmas

Proof of Lemma 2. Fix an arbitrary  $P = (p_1, p_2, ...) \in \mathcal{D}_k(\nu)$ . Let  $N = (N_1, N_2, ...) \stackrel{\text{ind}}{\sim} \operatorname{Poi}(np_i)$  and let  $n' = \sum N_i \sim \operatorname{Poi}(n \sum p_i) \geq_{\text{s.t.}} \operatorname{Poi}(n(1-\nu))$ . Let  $\hat{S}_n$  be the optimal estimator of support size for fixed sample size n, such that whenever  $n \geq n^*(k, \epsilon)$  we have  $\mathbb{P}[|\hat{S}_n - S(P)| \geq \epsilon k] \leq 0.1$  for any  $P \in \mathcal{D}_k$ . We construct an estimator for the Poisson sampling model by  $\tilde{S}(N) = \hat{S}_{n'}(N)$ . We observe that conditioned on n' = m,  $N \sim \operatorname{Multinomial}(m, \frac{P}{\sum_i p_i})$ . Note that  $\frac{P}{\sum_i p_i} \in \mathcal{D}_k$  by the definition of  $\mathcal{D}_k(\nu)$ . Therefore

$$\mathbb{P}\left[\left|\tilde{S}(N) - S(P)\right| \ge \epsilon k\right] = \sum_{m=0}^{\infty} \mathbb{P}\left[\left|\hat{S}_{m}(N) - S\left(\frac{P}{\sum_{i} p_{i}}\right)\right| \ge \epsilon k\right] \mathbb{P}\left[n' = m\right]$$

$$\le 0.1 \,\mathbb{P}[n' \ge n^{*}] + \mathbb{P}[n' < n^{*}] = 0.1 + 0.9 \,\mathbb{P}[n' < n^{*}]$$

$$\le 0.1 + 0.9 \,\mathbb{P}[\text{Poi}(n(1 - \nu)) < n^{*}].$$

If  $n = \frac{1+\beta}{1-\nu}n^*$  for  $\beta > 0$ , then Chernoff bound (see, e.g., [MU05, Theorem 5.4]) yields that

$$\mathbb{P}[\operatorname{Poi}(n(1-\nu)) < n^*] \le \exp(-n^*(\beta - \log(1+\beta))).$$

By picking  $\beta = \frac{C}{\sqrt{n^*}}$  for some absolute constant C, we obtain  $\tilde{n}^* \leq \frac{n^* + C\sqrt{n^*}}{1-\nu}$  and hence the lemma.

*Proof of Lemma 3.* Define two random vectors

$$\mathsf{P} = \left(\frac{U_1}{k}, \dots, \frac{U_k}{k}\right), \quad \mathsf{P}' = \left(\frac{U_1'}{k}, \dots, \frac{U_k'}{k}\right),$$

where  $U_i$  and  $U_i'$  are i.i.d. copies of U and U', respectively. Conditioned on P and P' respectively, the corresponding histogram  $N = (N_1, \ldots, N_k) \stackrel{\text{ind}}{\sim} \operatorname{Poi}(nU_i/k)$  and  $N' = (N_1', \ldots, N_k') \stackrel{\text{ind}}{\sim} \operatorname{Poi}(nU_i'/k)$ . Define the following high-probability events: for  $\alpha < 1/2$ ,

$$\begin{split} E &\triangleq \left\{ \left| \frac{\sum_{i} U_{i}}{k} - 1 \right| \leq \nu, |S(\mathsf{P}) - \mathbb{E}\left[ S(\mathsf{P}) \right] | \leq \alpha k d \right\}, \\ E' &\triangleq \left\{ \left| \frac{\sum_{i} U_{i}'}{k} - 1 \right| \leq \nu, \left| S(\mathsf{P}') - \mathbb{E}\left[ S(\mathsf{P}') \right] \right| \leq \alpha k d \right\}. \end{split}$$

Now we define two priors on the set  $\mathcal{D}_k(\nu)$  by the following conditional distributions:

<span id="page-15-4"></span>
$$\pi = P_{\mathsf{P}|E}, \quad \pi' = P_{\mathsf{P}'|E'}.$$

First we consider the separation of the support sizes under  $\pi$  and  $\pi'$ . Note that  $\mathbb{E}[S(\mathsf{P})] = k\mathbb{P}[U > 0]$  and  $\mathbb{E}[S(\mathsf{P}')] = k\mathbb{P}[U' > 0]$ , so  $|\mathbb{E}[S(\mathsf{P})] - \mathbb{E}[S(\mathsf{P}')]| \ge kd$ . By the definition of the events E, E' and the triangle inequality, we obtain that under  $\pi$  and  $\pi'$ , both  $\mathsf{P}, \mathsf{P}' \in \mathcal{D}_k(\nu)$  and

$$|S(\mathsf{P}) - S(\mathsf{P}')| \ge (1 - 2\alpha)kd. \tag{36}$$

Now we consider the total variation distance of the distributions of the histogram under the priors  $\pi$  and  $\pi'$ . By the triangle inequality and the fact that total variation of product distribution can be upper bounded by the summation of individual one,

$$\mathsf{TV}(P_{N|E}, P_{N'|E'}) \le \mathsf{TV}(P_{N|E}, P_N) + \mathsf{TV}(P_N, P_{N'}) + \mathsf{TV}(P_{N'}, P_{N'|E'})$$

$$= \mathbb{P}[E^c] + \mathsf{TV}\left( (\mathbb{E}[\mathsf{Poi}(nU/k)])^{\otimes k}, (\mathbb{E}[\mathsf{Poi}(nU'/k)])^{\otimes k} \right) + \mathbb{P}[E'^c]$$

$$\le \mathbb{P}[E^c] + \mathbb{P}[E'^c] + k\mathsf{TV}(\mathbb{E}[\mathsf{Poi}(nU/k)], \mathbb{E}[\mathsf{Poi}(nU'/k)]). \tag{37}$$

By the Chebyshev's inequality and the union bound, both

$$\mathbb{P}[E^{c}], \mathbb{P}[E^{\prime c}] \leq \mathbb{P}\left[\left|\sum_{i} \frac{U_{i}}{k} - 1\right| > \nu\right] + \mathbb{P}\left[\left|S(\mathsf{P}) - \mathbb{E}\left[S(\mathsf{P})\right]\right| > \alpha k d\right] \\
\leq \frac{\sum_{i} \mathsf{var}[U_{i}]}{(k\nu)^{2}} + \frac{\sum_{i} \mathsf{var}\left[\mathbf{1}_{\{U_{i}>0\}}\right]}{(\alpha k d)^{2}} \leq \frac{\lambda}{k\nu^{2}} + \frac{1}{k\alpha^{2}d^{2}}, \tag{38}$$

where we upper bounded the variance of U by  $var[U] \leq \mathbb{E}[U^2] \leq \mathbb{E}[\lambda U] = \lambda$ .

<span id="page-15-2"></span>Applying the total variation bound for Poisson mixtures in Lemma 6 (see Appendix B) yields that

<span id="page-15-5"></span>
$$\mathsf{TV}(\mathbb{E}[\mathsf{Poi}(nU/k)], \mathbb{E}[\mathsf{Poi}(nU'/k)]) \le \left(\frac{en\lambda}{2kL}\right)^L. \tag{39}$$

Plugging (38) and (39) into (37), we obtain that

$$\mathsf{TV}(P_{N|E}, P_{N'|E'}) \le \frac{2\lambda}{k\nu^2} + \frac{2}{k\alpha^2 d^2} + k \left(\frac{en\lambda}{2kL}\right)^L. \tag{40}$$

<span id="page-15-3"></span><span id="page-15-1"></span>

Applying Le Cam's lemma [LC86], the conclusion follows from (36) and (40).

# <span id="page-15-0"></span>6 Proof of upper bounds

#### 6.1 Proof of Propositions 2 and 3

*Proof of Proposition 2.* First we consider the bias:

$$|\mathbb{E}(\hat{S}_{\text{seen}}(P) - S(P))| = \sum_{i} (1 - \mathbb{P}(N_i \ge 1)) \mathbf{1}_{\left\{p_i \ge \frac{1}{k}\right\}} = \sum_{i} \exp(-np_i) \mathbf{1}_{\left\{p_i \ge \frac{1}{k}\right\}}$$

$$\leq k \exp(-n/k).$$

The variance satisfies

$$\mathrm{var}[\hat{S}_{\mathrm{seen}}(P)] = \sum_{i} \mathrm{var} \mathbf{1}_{\{N_i > 0\}} \mathbf{1}_{\left\{p_i \geq \frac{1}{k}\right\}} \leq \sum_{i} \exp(-np_i) \mathbf{1}_{\left\{p_i \geq \frac{1}{k}\right\}} \leq k \exp(-n/k).$$

The conclusion follows.

For the negative result, under the Poissonized model and with the samples drawn from the uniform distribution, the plug-in estimator  $\hat{S}_{\text{seen}}$  is distributed as  $\text{Binomial}(k, 1 - e^{-n/k})$ . If  $n \leq (1 - \delta)k\log\frac{1}{\epsilon} < k\log\frac{1}{\epsilon}$ , then  $1 - e^{-n/k} < 1 - \epsilon$ . By the Chernoff bound,

$$\mathbb{P}[|\hat{S}_{\text{seen}} - S(P)| \le \epsilon k] = \mathbb{P}[\text{Binomial}(k, 1 - e^{-n/k}) \ge (1 - \epsilon)k]$$
$$\le e^{-kd(1 - \epsilon \|1 - e^{-n/k})} = e^{-kd(\epsilon \|e^{-n/k})},$$

where  $d(p\|q) \triangleq p \log \frac{p}{q} + (1-p) \log \frac{1-p}{1-q}$  is the binary divergence function. Since  $e^{-n/k} \geq \epsilon^{1-\delta} > \epsilon$ ,

$$d(\epsilon \| e^{-n/k}) \ge d(\epsilon \| \epsilon^{1-\delta}) \ge d(k^{-1} \| k^{-1+\delta}) \asymp k^{-1+\delta}$$

where the middle inequality follows from the fact that  $\epsilon \mapsto d(\epsilon \| \epsilon^{1-\delta})$  is increasing near zero. Therefore  $\mathbb{P}[|\hat{S}_{\text{seen}} - S(P)| \le \epsilon k] \le \exp(-\Omega(k^{\delta}))$ .

Proof of Proposition 3. First we consider the bias. Recall that  $L = \lfloor c_0 \log k \rfloor$ ,  $r = \frac{c_1 \log k}{n}$ ,  $l = \frac{1}{k}$ . By (23) the bias of  $\hat{S}$  is the summation of

<span id="page-16-1"></span>
$$b(p_i) \triangleq e^{-np_i} P_L(p_i) \mathbf{1}_{\{p_i > 0\}}.$$

Obviously b(0) = 0. If  $l \le x \le r$  then  $|P_L(x)| \le \frac{1}{|T_L(-\frac{r+l}{r-l})|} = \frac{1}{|T_L(-\frac{1+\delta}{1-\delta})|}$  by the design of  $P_L$  in (19). Therefore  $|b(x)| \le e^{-nl}/|T_L(-\frac{1+\delta}{1-\delta})|$ ; if  $r < x \le 1$ ,

$$|b(x)| \le \max_{r < x \le 1} e^{-nx} |P_L(x)| = \max_{1 < y \le \frac{2-r-l}{r-l}} \exp(-nr(1-\delta)y/2) T_L(y) \frac{\exp(-nr(1+\delta)/2)}{|T_L(-\frac{1+\delta}{1-\delta})|}.$$
 (41)

We need the following lemma:

**Lemma 4.** If  $\beta = O(L)$ , then

<span id="page-16-0"></span>
$$\max_{x \ge 1} e^{-\beta x} T_L(x) = \frac{1}{2} \left( \frac{\alpha + \sqrt{\alpha^2 + 1}}{e^{\sqrt{1 + 1/\alpha^2}}} (1 + o_L(1)) \right)^L, \quad L \to \infty, \tag{42}$$

where  $\alpha \triangleq \frac{L}{\beta}$ .

Applying Lemma 4 to (41) with  $L = \lfloor c_0 \log k \rfloor$ ,  $\beta = nr(1 - \delta)/2$  and  $\alpha = 2\rho + o(1)$  where  $\rho \triangleq c_0/c_1$ , we obtain that

$$\begin{split} |b(x)| &\leq \frac{1}{2} \left( \frac{2\rho + \sqrt{(2\rho)^2 + 1}}{e^{\sqrt{1 + 1/(2\rho)^2}}} (1 + o_k(1)) \right)^L \frac{\exp(-\frac{L}{2\rho} (1 + o_\delta(1)))}{|T_L(-\frac{1 + \delta}{1 - \delta})|} \\ &= \frac{1}{2} \left( \frac{2\rho + \sqrt{(2\rho)^2 + 1}}{e^{\sqrt{1 + 1/(2\rho)^2} + 1/(2\rho)}} (1 + o_k(1) + o_\delta(1)) \right)^L \frac{1}{|T_L(-\frac{1 + \delta}{1 - \delta})|}. \end{split}$$

Therefore  $b(p_i)$  is uniformly bounded by  $\frac{1+o_k(1)+o_\delta(1)}{|T_L(-\frac{1+\delta}{1-\delta})|}$  as long as we pick the constant  $\rho$  such that  $\frac{2\rho+\sqrt{(2\rho)^2+1}}{e^{\sqrt{1+1/(2\rho)^2}+1/(2\rho)}} < 1$ , or equivalently,  $\rho < \rho^* \approx 1.1$ . Then the bias of  $\hat{S}$  is at most

$$|\mathbb{E}[\hat{S} - S]| \le k \frac{1 + o_k(1) + o_\delta(1)}{|T_L(-\frac{1+\delta}{1-\delta})|} \le 2k(1 + o_k(1) + o_\delta(1)) \left(1 - \frac{2\sqrt{\delta}}{1 + \sqrt{\delta}}\right)^L$$

$$= 2k(1 + o_k(1)) \exp\left(-(1 + o_\delta(1))\sqrt{4c_0\rho \frac{n\log k}{k}}\right). \tag{43}$$

Now we turn to the variance of  $\hat{S}$ :

<span id="page-17-3"></span>
$$\begin{split} \operatorname{var}[\hat{S}] &= \sum_{i:p_i>0} \operatorname{var}\left[(g_L(N_i)-1)\mathbf{1}_{\{N_i \leq L\}}\right] \\ &\leq \sum_{i:p_i>0} \mathbb{E}\left[(g_L(N_i)-1)^2\mathbf{1}_{\{N_i \leq L\}}\right] \\ &= \sum_{i:p_i>0} \sum_{j=0}^L \left(\frac{a_j j!}{n^j}\right)^2 e^{-np_i} \frac{(np_i)^j}{j!} = \sum_{j=0}^L \left(\frac{a_j j!}{n^j}\right)^2 \mathbb{E}[h_j], \end{split}$$

where  $h_j \triangleq \sum_i \mathbf{1}_{\{N_i=j\}}$  is the fingerprint of samples. By definition  $\mathbb{E}[\sum_j jh_j] = n$ . Therefore

$$\operatorname{var}[\hat{S}] \leq \mathbb{E}[h_0] + \sum_{j=1}^{L} \frac{(a_j j! / n^j)^2}{j} \mathbb{E}[jh_j] \leq k + nL \max_{1 \leq j \leq L} \frac{(a_j j! / n^j)^2}{j}. \tag{44}$$

Recall the polynomial coefficients  $a_i$  given in (20):

<span id="page-17-4"></span><span id="page-17-0"></span>
$$|a_j| = \left(\frac{2}{r-l}\right)^j \frac{1}{j!} \frac{|T_L^{(j)}(-\frac{r+l}{r-l})|}{|T_L(-\frac{r+l}{r-l})|}.$$

Applying Markov brothers' inequality [Mar92] on the scaled interval  $\left[-\frac{r+l}{r-l}, \frac{r+l}{r-l}\right]$ , we obtain that

$$\left| \frac{j!}{n^j} a_j \right| \le \frac{j!}{n^j} \left( \frac{2}{r-l} \right)^j \frac{1}{j!} \frac{2^j j!}{\left| \frac{r+l}{r-l} \right|^j} \frac{L}{L+j} \binom{L+j}{2j} = \left( \frac{4}{n(r+l)} \right)^j j! \frac{L}{L+j} \binom{L+j}{2j}. \tag{45}$$

We use the following bound on binomial coefficients [Ash65, Lemma 4.7.1]:

<span id="page-17-2"></span><span id="page-17-1"></span>
$$\frac{\sqrt{\pi}}{2} \le \frac{\binom{n}{k}}{(2\pi n\lambda(1-\lambda))^{-1/2}\exp(nh(\lambda))} \le 1. \tag{46}$$

where  $\lambda = \frac{k}{n} \in (0,1)$  and  $h(\lambda) \triangleq -\lambda \log \lambda - (1-\lambda) \log (1-\lambda)$  denotes the binary entropy function. Therefore, from (45) and (46), for  $j = 1, \ldots, L-1$ ,

$$\left| \frac{a_{j}j!}{n^{j}} \right| \leq \left( \frac{4}{n(r+l)} \right)^{j} j! \frac{L}{L+j} \frac{\exp((L+j)h(\frac{2j}{L+j}))}{\sqrt{2\pi \cdot 2j\frac{L-j}{L+j}}}$$

$$\leq \left( \frac{4}{nr} \right)^{j} \frac{j!}{2} \exp\left( (L+j)h\left(\frac{2j}{L+j}\right) \right), \tag{47}$$

where we used the fact that  $\max_{j \in [L-1]} \frac{L}{\sqrt{4\pi j(L-j)(L+j)}} = \frac{L}{\sqrt{4\pi(L^2-1)}} \le \frac{1}{2}$  for  $L \ge 2$ . From (45), the upper bound (47) also holds for j = L. Using (47) and Striling's approximation that  $n! < e\sqrt{n}(\frac{n}{\epsilon})^n$ ,

$$\frac{(a_{j}j!/n^{j})^{2}}{j} \leq \frac{1}{j} \left(\frac{4}{c_{1}\log k}\right)^{2j} \left(\frac{e\sqrt{j}}{2}\right)^{2} \left(\frac{j}{e}\right)^{2j} \exp\left(2(L+j)h\left(\frac{2j}{L+j}\right)\right) 
= \frac{e^{2}}{4}k^{2c_{0}(\beta\log\frac{4\rho\beta}{e}+(1+\beta)h(\frac{2\beta}{1+\beta}))} \leq \frac{e^{2}}{4}k^{2c_{0}\tau(\rho)},$$
(48)

<span id="page-18-2"></span>where  $\beta \triangleq j/L$  and  $\tau(\rho) \triangleq \sup_{\beta \in [0,1]} (\beta \log \frac{4\rho\beta}{e} + (1+\beta)h(\frac{2\beta}{1+\beta}))$ , which occurs at  $\beta = \frac{\sqrt{1+4\rho^2}-1}{2\rho}$ . Note that from (43) the squared bias of  $\hat{S}$  is  $4k^{2-o_{\delta}(1)}$ ; from (44) and (48) the variance of  $\hat{S}$  is at most

<span id="page-18-1"></span>
$$\operatorname{var}[\hat{S}] \le k + \frac{e^2}{4} nLk^{2c_0\tau(\rho)},\tag{49}$$

which is  $\frac{e^2}{4}k^{1+2c_0\tau(\rho)+o_\delta(1)}$ . Therefore as long as we pick constant  $c_0$  such that  $2c_0\tau(\rho) < 1$  the variance of  $\hat{S}$  in (49) is lower order than the squared bias of  $\hat{S}$  in (43), and thus the MSE of  $\hat{S}$  is at most

$$\mathbb{E}(\hat{S} - S)^2 \le 4k^2(1 + o_k(1)) \exp\left(-2(1 + o_{\delta}(1))\sqrt{\frac{2\rho}{\tau(\rho)} \frac{n \log k}{k}}\right).$$

The conclusion follows from the fact that  $\sup_{\rho < \rho^*} 2\rho/\tau(\rho) \approx 2.494$ , which corresponds to choosing  $c_0 \approx 0.558$  and  $c_1 = 0.5$ .

## <span id="page-18-0"></span>6.2 Upper bound parts of Theorems 1 and 2

Proof of upper bound of Theorem 1. Combining Lemma 1 and Proposition 3 yields the upper bound part of (6), which also implies the upper bound of (5) when  $n \lesssim k \log k$ . The upper bound part of (5) when  $n \gtrsim k \log k$  follows from Proposition 2.

Proof of upper bound of Theorem 2. By the Markov inequality,

<span id="page-18-3"></span>
$$R^*(k,n) \le 0.1\epsilon^2 \Rightarrow n^*(k,\epsilon) \le n. \tag{50}$$

Therefore our upper bound is

$$n^*(k,\epsilon) \le \inf\{n : R^*(k,n) \le 0.1\epsilon^2\}.$$

By the upper bound of  $R^*(k,n)$  in (25), we obtain that

$$n^*(k,\epsilon) \le \frac{1 + o_{\delta'}(1) + o_{\epsilon}(1) + o_k(1)}{\kappa} \frac{k}{\log k} \log^2 \frac{1}{\epsilon}$$

as  $\delta' \triangleq \frac{\log(1/\epsilon)}{\log k} \triangleq 0$ ,  $\epsilon \to 0$ , and  $k \to \infty$ . Consequently, we obtain the upper bound part of (9) when  $\frac{1}{k^c} \leq \epsilon \leq c_0$  for the fixed constant  $c_0 < 1/2$ .

The upper bound part of Theorem 2 when  $\frac{1}{k} \leq \epsilon \leq \frac{1}{k^c}$  follows from the monotonicity of  $\epsilon \mapsto n^*(k,\epsilon)$  that

$$n^*(k,\epsilon) \le n^*(k,1/k) \le 3k \log k \asymp \frac{k}{\log k} \log^2 \frac{1}{\epsilon},$$

where the middle inequality follows from Proposition 2 and (50).

#### 6.3 Proof of lemmas

*Proof of Lemma 1.* We follow the same idea as in [WY16, Appendix A] using the Bayesian risk as a lower bound of the minimax risk with a more refined application of the Chernoff bound. We express the risk under the Poisson sampling as a function of the original samples that

$$\tilde{R}^*(k, (1-\beta)n) = \inf_{\{\hat{S}_m\}} \sup_{P \in \mathcal{D}_k} \mathbb{E}[\ell(\hat{S}_{n'}, S(P))],$$

where  $n' \sim \text{Poi}((1-\beta)n)$ . The Bayesian risk is a lower bound of the minimax risk:

<span id="page-19-1"></span>
$$\tilde{R}^*(k, (1-\beta)n) \ge \sup_{\pi} \inf_{\{\hat{S}_m\}} \mathbb{E}[\ell(\hat{S}_{n'}, S(P))],$$
 (51)

where  $\pi$  is a prior over the parameter space  $\mathcal{D}_k$ . For any sequence of estimators  $\{\hat{S}_m\}$ ,

$$\mathbb{E}[\ell(\hat{S}_{n'}, S)] = \sum_{m>0} \mathbb{E}[\ell(\hat{S}_m, S)] \mathbb{P}[n' = m] \ge \sum_{m=0}^{n} \mathbb{E}[\ell(\hat{S}_m, S)] \mathbb{P}[n' = m].$$

Taking infimum of both sides, we obtain

$$\inf_{\{\hat{S}_m\}} \mathbb{E}[\ell(\hat{S}_{n'}, S)] \ge \inf_{\{\hat{S}_m\}} \sum_{m=0}^n \mathbb{E}[\ell(\hat{S}_m, S)] \mathbb{P}[n' = m] = \sum_{m=0}^n \inf_{\hat{S}_m} \mathbb{E}[\ell(\hat{S}_m, S)] \mathbb{P}[n' = m].$$

Note that for any fixed prior  $\pi$ , the function  $m \mapsto \inf_{\hat{S}_m} \mathbb{E}[\ell(\hat{S}_m, S)]$  is decreasing. Therefore

$$\inf_{\{\hat{S}_m\}} \mathbb{E}[\ell(\hat{S}_{n'}, S)] \ge \inf_{\hat{S}_n} \mathbb{E}[\ell(\hat{S}_n, S)] \mathbb{P}[n' \le n]$$

$$\ge \inf_{\hat{S}_n} \mathbb{E}[\ell(\hat{S}_n, S)] (1 - \exp(n(\beta + \log(1 - \beta))))$$

$$\ge \inf_{\hat{S}_n} \mathbb{E}[\ell(\hat{S}_n, S)] (1 - \exp(-n\beta^2/2)), \tag{52}$$

where we used the Chernoff bound (see, e.g., [MU05, Theorem 5.4]) and the fact that  $\log(1-x) \le -x - x^2/2$  for x > 0. Taking supremum over  $\pi$  on both sides of (52), the conclusion follows from (51) and the minimax theorem (cf. e.g. [Str85, Theorem 46.5]).

Proof of Lemma 4. By assumption,  $\alpha = \frac{L}{\beta}$  is strictly bounded away from zero. Let  $f(x) \triangleq e^{-\beta x}T_L(x) = e^{-\beta x}\cosh(L\operatorname{arccosh}(x))$  when  $x \geq 1$ . By taking the derivative of f, we obtain that f is decreasing if and only if

<span id="page-19-0"></span>
$$\frac{\tanh(L \operatorname{arccosh}(x))}{\sqrt{x^2-1}} = \frac{\tanh(Ly)}{\sinh(y)} < \frac{1}{\alpha},$$

where  $x = \cosh(y)$ . Let  $g(y) = \frac{\tanh(Ly)}{\sinh(y)}$ . Note that g is strictly decreasing on  $\mathbb{R}_+$  with g(0) = L and  $g(\infty) = 0$ . Therefore f attains its maximum at  $x^*$  which is the unique solution of  $\frac{\tanh(L \operatorname{arccosh}(x))}{\sqrt{x^2 - 1}} = \frac{1}{\alpha}$ . It is straightforward to verify that the solution satisfies  $x^* = \sqrt{1 + \alpha^2}(1 - o_L(1))$  when  $\alpha$  is strictly bounded away from zero. Therefore the maximum value of f is

$$e^{-\beta x^*}T_L(x^*) = e^{-L\sqrt{1+1/\alpha^2}(1-o_L(1))}\frac{1}{2}(z^L+z^{-L}),$$

where we used (18) and  $z = x^* + \sqrt{x^{*2} - 1} = (\sqrt{1 + \alpha^2} + \alpha)(1 - o_L(1))$  is strictly bounded away from 1. This proves the lemma.

# <span id="page-20-0"></span>A Dual program of (13)

Define the following infinite-dimensional linear programming problem:

<span id="page-20-2"></span>
$$\mathcal{E}_{1}^{*} \triangleq \sup \mathbb{P}\left[U' = 0\right] - \mathbb{P}\left[U = 0\right]$$
s.t.  $\mathbb{E}\left[U\right] = \mathbb{E}\left[U'\right] = 1$ 

$$\mathbb{E}\left[U^{j}\right] = \mathbb{E}\left[U'^{j}\right], \quad j = 1, \dots, L + 1,$$

$$U, U' \in \{0\} \cup I,$$

$$(53)$$

where I = [a, b] with  $b > a \ge 1$ . Then (13) is a special case of (53) with  $I = [1, \lambda]$ .

<span id="page-20-1"></span>Lemma 5.  $\mathcal{E}_1^* = \inf_{p \in \mathcal{P}_L} \sup_{x \in I} \left| \frac{1}{x} - p(x) \right|.$ 

*Proof.* We first show that 13 coincides with the following optimization problem:

$$\mathcal{E}_{2}^{*} \triangleq \sup \mathbb{E}\left[\frac{1}{X}\right] - \mathbb{E}\left[\frac{1}{X'}\right]$$
s.t.  $\mathbb{E}\left[X^{j}\right] = \mathbb{E}\left[X'^{j}\right], \quad j = 1, \dots, L,$ 

$$X, X' \in I.$$
(54)

Given any feasible solution U, U' to 13, construct X, X' with the following distributions:

<span id="page-20-3"></span>
$$P_X(\mathrm{d}x) = xP_U(\mathrm{d}x),$$
  

$$P_{X'}(\mathrm{d}x) = xP_{U'}(\mathrm{d}x),$$
(55)

It is straightforward to verify that X, X' are feasible for (54) and

$$\mathcal{E}_2^* \geq \mathbb{E}\left[\frac{1}{X}\right] - \mathbb{E}\left[\frac{1}{X'}\right] = \mathbb{P}\left[U' = 0\right] - \mathbb{P}\left[U = 0\right].$$

Therefore  $\mathcal{E}_2^* \geq \mathcal{E}_1^*$ .

On the other hand, given any feasible X, X' for (54), construct U, U' with the distributions:

$$P_{U}(du) = \left(1 - \mathbb{E}\left[\frac{1}{X}\right]\right) \delta_{0}(du) + \frac{1}{u} P_{X}(du),$$

$$P_{U'}(du) = \left(1 - \mathbb{E}\left[\frac{1}{X'}\right]\right) \delta_{0}(du) + \frac{1}{u} P_{X'}(du),$$
(56)

which are well-defined since  $X, X' \geq 1$  and hence  $\mathbb{E}\left[\frac{1}{X}\right] \leq 1, \mathbb{E}\left[\frac{1}{X'}\right] \leq 1$ . Then U, U' are feasible for 13 and hence

$$\mathcal{E}_1^* \ge \mathbb{P}\left[U' = 0\right] - \mathbb{P}\left[U = 0\right] = \mathbb{E}\left[\frac{1}{X}\right] - \mathbb{E}\left[\frac{1}{X'}\right].$$

Therefore  $\mathcal{E}_1^* \geq \mathcal{E}_2^*$ . Finally, the dual of (54) is precisely the best polynomial approximation problem (see, e.g., [WY16, Appendix E]) and hence

$$\mathcal{E}_1^* = \mathcal{E}_2^* = \inf_{p \in \mathcal{P}_L} \sup_{x \in I} \left| \frac{1}{x} - p(x) \right|.$$

## <span id="page-21-1"></span>B Total variation between Poisson mixtures

The total variation distance between two Poisson mixtures is obtained in the following lemma, which is an improvement of [WY16, Lemma 3] in terms of constants. This is crucial for our purposes of obtaining the best constants in the sample complexity bounds in (10).

<span id="page-21-0"></span>**Lemma 6.** Let V and V' be random variables taking values on  $[0,\Lambda]$ . If  $\mathbb{E}[V^j] = \mathbb{E}[V'^j]$ ,  $j = 1,\ldots,L$ , then

$$\mathsf{TV}(\mathbb{E}[\mathsf{Poi}(V)], \mathbb{E}[\mathsf{Poi}(V')]) \le \frac{(\Lambda/2)^{L+1}}{(L+1)!} \left( 2 + 2^{\Lambda/2 - L} + 2^{\Lambda/(2\log 2) - L} \right). \tag{57}$$

In particular,  $\mathsf{TV}(\mathbb{E}[\mathsf{Poi}(V)], \mathbb{E}[\mathsf{Poi}(V')]) \leq (\frac{e\Lambda}{2L})^L$ . Moreover, if  $L > \frac{e}{2}\Lambda$ , then

$$\mathsf{TV}(\mathbb{E}[\mathrm{Poi}(V)], \mathbb{E}[\mathrm{Poi}(V')]) \leq \frac{2(\Lambda/2)^{L+1}}{(L+1)!} (1+o(1)), \quad \Lambda \to \infty.$$

*Proof.* Denote the best degree-L polynomial approximation error of a function f on an interval I by

$$E_L(f, I) = \inf_{p \in \mathcal{P}_L} \sup_{x \in I} |f(x) - p(x)|.$$

<span id="page-21-3"></span>Let

<span id="page-21-4"></span><span id="page-21-2"></span>
$$f_j(x) \triangleq \frac{e^{-x}x^j}{j!}. (58)$$

Let  $P_{L,j}^*$  be the best polynomial of degree L that uniformly approximates  $f_j$  over the interval  $[0,\Lambda]$  and the corresponding approximation error by  $E_L(f_j,[0,\Lambda]) = \max_{x \in [0,\Lambda]} |f_j(x) - P_{L,j}^*(x)|$ . Then  $\mathbb{E}P_{L,j}^*(V) = \mathbb{E}P_{L,j}^*(V')$  and hence

$$\mathsf{TV}(\mathbb{E}[\mathsf{Poi}(V)], \mathbb{E}[\mathsf{Poi}(V')]) = \frac{1}{2} \sum_{j=0}^{\infty} |\mathbb{E}f_{j}(V) - \mathbb{E}f_{j}(V')|$$

$$\leq \frac{1}{2} \sum_{j=0}^{\infty} |\mathbb{E}(f_{j}(V) - P_{L,j}^{*}(V))| + |\mathbb{E}(f_{j}(V') - P_{L,j}^{*}(V'))|$$

$$\leq \sum_{j=0}^{\infty} E_{L}(f_{j}, [0, \Lambda]). \tag{59}$$

A useful upper bound on the degree-L best polynomial approximation error of a function f is via the Chebyshev interpolation polynomial, whose uniform approximation error can be bounded using the L<sup>th</sup> derivative of f. Specifically, we have (cf. e.g., [Atk89, Eq. (4.7.28)])

$$E_L(f, [0, \Lambda]) \le \max_{x \in [0, \Lambda]} |f_j(x) - Q_L(f; x)| \le \frac{1}{2^L (L+1)!} \left(\frac{\Lambda}{2}\right)^{L+1} \max_{x \in [0, \Lambda]} \left| f^{(L+1)}(x) \right|, \tag{60}$$

where  $Q_L(f;x)$  denotes the degree-L interpolating polynomial for f on Chebyshev nodes (roots of the Chebyshev polynomial). To apply (60) to  $f = f_j$  defined in (58), note that  $f_j^{(L+1)}$  can be conveniently expressed in terms of Laguerre polynomials: Denote the degree-n generalized Laguerre polynomial by  $L_n^{(k)}$  and the simple Laguerre polynomial by  $L_n(x) = L_n^{(0)}$ . Recall the Rodrigues representation for Laguerre polynomials:

$$L_n^{(k)}(x) = \frac{x^{-k}e^x}{n!} \frac{\mathrm{d}^n}{\mathrm{d}x^n} (e^{-x}x^{n+k}) = (-1)^k \frac{\mathrm{d}^x}{\mathrm{d}k^x} L_{n+k}(x), \quad k \in \mathbb{N}.$$

If  $j \leq L + 1$ ,

$$f_j^{(L+1)}(x) = \frac{\mathrm{d}^{L+1-j}}{\mathrm{d}x^{L+1-j}} \left( \frac{\mathrm{d}^j}{\mathrm{d}x^j} \frac{e^{-x}x^j}{j!} \right) = \frac{\mathrm{d}^{L+1-j}}{\mathrm{d}x^{L+1-j}} (L_j(x)e^{-x}).$$

Note that  $L_j$  is a degree-j polynomial, whose derivative of order higher than j is zero. Applying general Leibniz rule for derivatives yields that

$$f_j^{(L+1)}(x) = \sum_{m=0}^{(L+1-j)\wedge j} {L+1-j \choose m} \frac{\mathrm{d}^m L_j(x)}{\mathrm{d}x^m} e^{-x} (-1)^{L+1-j-m}$$

$$= (-1)^{L+1-j} e^{-x} \sum_{m=0}^{(L+1-j)\wedge j} {L+1-j \choose m} L_{j-m}^{(m)}(x).$$
(61)

Applying [AS64, 22.14.13]

<span id="page-22-3"></span><span id="page-22-2"></span><span id="page-22-1"></span>
$$|L_n^{(k)}(x)| \le \binom{n+k}{n} e^{x/2} \tag{62}$$

when  $x \geq 0$  and  $k \in \mathbb{N}$ , we obtain that

$$\left| f_j^{(L+1)}(x) \right| \le e^{-x} \sum_{m=0}^{(L+1-j)\wedge j} {L+1-j \choose m} {j \choose j-m} e^{x/2} = e^{-x/2} {L+1 \choose j}.$$

Therefore  $\max_{x \in [0,\Lambda]} |f_j^{(L+1)}(x)| \leq {L+1 \choose j}$  when  $j \leq L+1.3$  Then, applying (60), we have

$$\sum_{j=0}^{L+1} E_L(f_j, [0, \Lambda]) \le \sum_{j=0}^{L+1} \frac{\binom{L+1}{j} (\Lambda/2)^{L+1}}{2^L (L+1)!} = \frac{2(\Lambda/2)^{L+1}}{(L+1)!}.$$
 (63)

If  $j \geq L + 2$ , the derivatives of  $f_j$  are related to the Laguerre polynomial by

<span id="page-22-4"></span>
$$f_j^{(L+1)}(x) = \frac{(L+1)!}{j!} x^{j-L-1} e^{-x} L_{L+1}^{(j-L-1)}(x).$$

Again applying (62) when  $x \geq 0$  and  $k \in \mathbb{N}$ , we obtain

$$\left| f_j^{(L+1)}(x) \right| \le \frac{(L+1)!}{j!} x^{j-L-1} e^{-x} \binom{j}{L+1} e^{x/2} = \frac{1}{(j-L-1)!} e^{-x/2} x^{j-L-1},$$

where the maximum of right-hand side on  $[0,\Lambda]$  occurs at  $x=(2(j-L-1))\wedge\Lambda$ . Therefore

$$\max_{x \in [0,\Lambda]} |f_j^{(L+1)}(x)| \le \begin{cases} \frac{1}{(j-L-1)!} \left(\frac{2(j-L-1)}{e}\right)^{j-L-1}, & L+1 \le j \le L+1+\Lambda/2, \\ \frac{1}{(j-L-1)!} e^{-\Lambda/2} \Lambda^{j-L-1}, & j \ge L+1+\Lambda/2. \end{cases}$$

Then, applying (60) and Stirling's approximation that  $(\frac{j-L-1}{e})^{j-L-1} < \frac{(j-L-1)!}{\sqrt{2\pi(j-L-1)}}$ , we have

$$\sum_{\substack{j \ge L+2\\j < L+1+\Lambda/2}} E_L(f_j, [0, \Lambda]) \le \frac{(\Lambda/2)^{L+1}}{2^L(L+1)!} \sum_{\substack{j \ge L+2\\j < L+1+\Lambda/2}} \frac{2^{j-L-1}}{\sqrt{2\pi(j-L-1)}} \le \frac{(\Lambda/2)^{L+1}2^{\Lambda/2}}{2^L(L+1)!}, \tag{64}$$

$$\sum_{j \ge L+1+\Lambda/2} E_L(f_j, [0, \Lambda]) \le \frac{(\Lambda/2)^{L+1} e^{-\Lambda/2}}{2^L (L+1)!} \sum_{j \ge L+1+\Lambda/2} \frac{\Lambda^{j-L-1}}{(j-L-1)!} \le \frac{(\Lambda/2)^{L+1} e^{\Lambda/2}}{2^L (L+1)!}.$$
 (65)

<span id="page-22-0"></span>This is in fact an equality. In view of (61) and the fact that [AS64, 22.3], we have  $|f_j^{(L+1)}(0)| = \sum_m {L+1-j \choose m} {j \choose j-m} = {L+1 \choose j}$ .

Assembling the three ranges of summations in [\(63\)](#page-22-3)-[\(65\)](#page-22-4) in the total variation bound [\(59\)](#page-21-4), we obtain

$$\mathsf{TV}(\mathbb{E}[\mathrm{Poi}(V)], \mathbb{E}[\mathrm{Poi}(V')]) \le \frac{(\Lambda/2)^{L+1}}{(L+1)!} \left(2 + 2^{\Lambda/2-L} + 2^{\Lambda/(2\log 2)-L}\right).$$

Finally, applying Stirling's approximation (L+1)! > p 2π(L + 1)( <sup>L</sup>+1 e ) <sup>L</sup>+1, we conclude TV(E[Poi(V )], E[Poi(V ( eΛ 2L ) <sup>L</sup>. If L > <sup>e</sup> <sup>2</sup>Λ > Λ 2 log 2 > Λ 2 , then 2Λ/2−<sup>L</sup> + 2Λ/(2 log 2)−<sup>L</sup> = o(1).

0

# Acknowledgment

This work was completed in part when Y.W. was visiting the Simons Institute for the Theory of Computing, whose generous support is acknowledged. The authors thank Luca Trevisan for helpful comments pertaining to Theorem [2.](#page-2-0) The authors are grateful to Dan Roth and Mark Sammons for help with the datasets used in Fig. [4.](#page-11-1)

# References

- <span id="page-23-10"></span>[AS64] Milton Abramowitz and Irene A Stegun. Handbook of mathematical functions: with formulas, graphs, and mathematical tables. Courier Corporation, 1964.
- <span id="page-23-8"></span>[Ash65] Robert B. Ash. Information Theory. Dover Publications Inc., New York, NY, 1965.
- <span id="page-23-9"></span>[Atk89] Kendall E Atkinson. An introduction to numerical analysis. John Wiley & Sons, 1989.
- <span id="page-23-2"></span>[BF93] John Bunge and M Fitzpatrick. Estimating the number of species: a review. Journal of the American Statistical Association, 88(421):364–373, 1993.
- <span id="page-23-0"></span>[BO79] Kenneth P Burnham and W Scott Overton. Robust estimation of population size when capture probabilities vary among animals. Ecology, 60(5):927–936, 1979.
- <span id="page-23-5"></span>[CCMN00] Moses Charikar, Surajit Chaudhuri, Rajeev Motwani, and Vivek Narasayya. Towards estimation error guarantees for distinct values. In Proceedings of the nineteenth ACM SIGMOD-SIGACT-SIGART Symposium on Principles of Database Systems (PODS), pages 268–279. ACM, 2000.
- <span id="page-23-3"></span>[Cha84] Anne Chao. Nonparametric estimation of the number of classes in a population. Scandinavian Journal of statistics, pages 265–270, 1984.
- <span id="page-23-4"></span>[CL92] Anne Chao and Shen-Ming Lee. Estimating the number of classes via sample coverage. Journal of the American statistical Association, 87(417):210–217, 1992.
- <span id="page-23-6"></span>[CL11] T.T. Cai and M. G. Low. Testing composite hypotheses, Hermite polynomials and optimal estimation of a nonsmooth functional. The Annals of Statistics, 39(2):1012– 1041, 2011.
- <span id="page-23-1"></span>[DR80] JN Darroch and D Ratcliff. A note on capture-recapture estimation. Biometrics, 36:149–153, 1980.
- <span id="page-23-7"></span>[DS08] Vladislav K Dzyadyk and Igor A Shevchuk. Theory of uniform approximation of functions by polynomials. Walter de Gruyter, 2008.

- <span id="page-24-13"></span>[ED] Oxford English Dictinary. <http://public.oed.com/about/>. Accessed: 2016-02-16.
- <span id="page-24-2"></span>[ET76] B. Efron and R. Thisted. Estimating the number of unseen species: How many words did Shakespeare know? Biometrika, 63(3):435–447, 1976.
- <span id="page-24-0"></span>[FCW43] Ronald Aylmer Fisher, A Steven Corbet, and Carrington B Williams. The relation between the number of species and the number of individuals in a random sample of an animal population. The Journal of Animal Ecology, pages 42–58, 1943.
- <span id="page-24-7"></span>[Goo53] Irving J Good. The population frequencies of species and the estimation of population parameters. Biometrika, 40(3-4):237–264, 1953.
- <span id="page-24-6"></span>[GS04] Alberto Gandolfi and C.C.A. Sastri. Nonparametric estimations about species not observed in a random sample. Milan Journal of Mathematics, 72(1):81–105, 2004.
- <span id="page-24-8"></span>[GT56] I.J. Good and G.H. Toulmin. The number of new species, and the increase in population coverage, when a sample is increased. Biometrika, 43(1-2):45–63, 1956.
- <span id="page-24-5"></span>[Har68] Bernard Harris. Statistical inference in the classical occupancy problem unbiased estimation of the number of classes. Journal of the American Statistical Association, pages 837–847, 1968.
- <span id="page-24-3"></span>[HW01] Shu-Pang Huang and BS Weir. Estimating the total number of alleles using a sample coverage method. Genetics, 159(3):1365–1373, 2001.
- <span id="page-24-11"></span>[INK87] I.A. Ibragimov, A.S. Nemirovskii, and R.Z. Khas'minskii. Some problems on nonparametric estimation in gaussian white noise. Theory of Probability & Its Applications, 31(3):391–406, 1987.
- <span id="page-24-12"></span>[JVHW15] Jiantao Jiao, Kartik Venkat, Yanjun Han, and Tsachy Weissman. Minimax estimation of functionals of discrete distributions. IEEE Transactions on Information Theory, 61(5):2835–2885, 2015.
- <span id="page-24-15"></span>[LC86] L. Le Cam. Asymptotic methods in statistical decision theory. Springer-Verlag, New York, NY, 1986.
- <span id="page-24-10"></span>[LNS99] Oleg Lepski, Arkady Nemirovski, and Vladimir Spokoiny. On estimation of the L<sup>r</sup> norm of a regression function. Probability theory and related fields, 113(2):221–253, 1999.
- <span id="page-24-4"></span>[LP56] Richard C Lewontin and Timothy Prout. Estimation of the number of different classes in a population. Biometrics, 12(2):211–223, 1956.
- <span id="page-24-16"></span>[Mar92] VA Markov. On functions of least deviation from zero in a given interval. St. Petersburg, 892, 1892.
- <span id="page-24-1"></span>[McN73] Donald R McNeil. Estimating an author's vocabulary. Journal of the American Statistical Association, 68(341):92–96, 1973.
- <span id="page-24-9"></span>[ML07] Chang Xuan Mao and Bruce G Lindsay. Estimating the number of classes. The Annals of Statistics, 35(2):917–930, 2007.
- <span id="page-24-14"></span>[Mon] Global Language Monitor. Number of words in the english language. [http://www.](http://www.languagemonitor.com/?attachment_id=8505) [languagemonitor.com/?attachment\\_id=8505](http://www.languagemonitor.com/?attachment_id=8505). Accessed: 2016-02-16.

- <span id="page-25-4"></span>[MSJ82] JP Marchand and FE Schroeck Jr. On the estimation of the number of equally likely classes in a population. Communications in Statistics-Theory and Methods, 11(10):1139–1146, 1982.
- <span id="page-25-3"></span>[MU05] Michael Mitzenmacher and Eli Upfal. Probability and computing: Randomized algorithms and probabilistic analysis. Cambridge University Press, 2005.
- <span id="page-25-6"></span>[Rob68] Herbert E Robbins. Estimating the total probability of the unobserved outcomes of an experiment. The Annals of Mathematical Statistics, 39(1):256–257, 1968.
- <span id="page-25-2"></span>[RRSS09] Sofya Raskhodnikova, Dana Ron, Amir Shpilka, and Adam Smith. Strong lower bounds for approximating distribution support size and the distinct elements problem. SIAM Journal on Computing, 39(3):813–842, 2009.
- <span id="page-25-5"></span>[Sam68] Ester Samuel. Sequential maximum likelihood estimation of the size of a population. The Annals of Mathematical Statistics, 39(3):1057–1068, 1968.
- <span id="page-25-11"></span>[Str85] Helmut Strasser. Mathematical theory of statistics: Statistical experiments and asymptotic decision theory. Walter de Gruyter, Berlin, Germany, 1985.
- <span id="page-25-1"></span>[TE87] Ronald Thisted and Bradley Efron. Did Shakespeare write a newly-discovered poem? Biometrika, 74(3):445–455, 1987.
- <span id="page-25-10"></span>[Tim63] Aleksandr Filippovich Timan. Theory of approximation of functions of a real variable. Pergamon Press, 1963.
- <span id="page-25-8"></span>[VV10] Gregory Valiant and Paul Valiant. A CLT and tight lower bounds for estimating entropy. In Electronic Colloquium on Computational Complexity (ECCC), volume 17, page 179, 2010.
- <span id="page-25-7"></span>[VV11] Gregory Valiant and Paul Valiant. Estimating the unseen: an n/ log(n)-sample estimator for entropy and support size, shown optimal via new CLTs. In Proceedings of the 43rd annual ACM symposium on Theory of computing, pages 685–694, 2011.
- <span id="page-25-0"></span>[VV13] Paul Valiant and Gregory Valiant. Estimating the unseen: Improved estimators for entropy and other properties. In Advances in Neural Information Processing Systems, pages 2157–2165, 2013.
- <span id="page-25-9"></span>[WY16] Yihong Wu and Pengkun Yang. Minimax rates of entropy estimation on large alphabets via best polynomial approximation. IEEE Transactions on Information Theory, 62(6):3702–3720, 2016.