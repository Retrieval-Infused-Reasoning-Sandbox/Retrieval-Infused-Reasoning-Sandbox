![](_page_0_Picture_0.jpeg)

# Learnability and the Vapnik-Chervonenkis Dimension

#### ANSELM BLUMER

Tufts University, Medford, Massachusetts

#### ANDRZEJ EHRENFEUCHT

University of Colorado at Boulder, Boulder, Colorado

AND

#### DAVID HAUSSLER AND MANFRED K. WARMUTH

University ofcalifornia at Santa Cruz, Santa Cruz, California

Abstract. Valiant's learnability model is extended to learning classes of concepts defined by regions in Euclidean space E". The methods in this paper lead to a unified treatment of some of Valiant's results, along with previous results on distribution-free convergence of certain pattern recognition algorithms. It is shown that the essential condition for distribution-free learnability is finiteness of the Vapnik-Chervonenkis dimension, a simple combinatorial parameter of the class of concepts to be learned. Using this parameter, the complexity and closure properties of learnable classes are analyzed, and the necessary and sufftcient conditions are provided for feasible learnability.

Categories and Subject Descriptors: F.2.2 [Analysis of Algorithms and Problem Complexity]: Nonnumerical Algorithms and Problems-computations on discrete structures, geometrical problems and computations; G.3 [Probability and Statistics]: probabilistic algorithms; 1.2.6 [Artificial Intelligence]: Learning-concept learning, induction; 1.50 [Pattern Recognition]: General

General Terms: Algorithms, Theory, Verification

Additional Key Words and Phrases: Capacity, learnability theory, learning from examples, Occam's razor, PAC learning, sample complexity, Vapnik-Chervonenkis classes, Vapnik-Chervonenkis dimension

An extended abstract of this research appeared in Proceedings of the 18th ACM Symposium on Theory ofcomputing (Berkeley, Calif., May 28-30). ACM, New York, 1986, pp. 273-282, and a preliminary version of this paper appeared as BLUMER, A., EHRENFEUCHT, A., HAUSSLER, D., AND WARMUTH, M. K. Classifying Learnable Geometric Concepts with the Vapnik-Chervonenkis Dimension. Tech. Rep. UCSC-CRL-86-5. Univ. Calif. at Santa Cruz, Santa Cruz, CA, 1986.

The work of D. Haussler and M. K. Warmuth was supported by the Office of Naval Research grant N00014-86-K-0454. The work of A. Blumer was supported by the National Science Foundation grant IST 83-17918. The work of E. Ehrenfeucht was supported by the National Science Foundation grant MCS 83-05245.

Authors' addresses: A. Blumer, Department of Mathematics and Computer Science, Tufts University, Medford, MA 02155; A. Ehrenfeucht, Department of Computer Science, University of Colorado at Boulder, Boulder, CO 80302; D. Haussler and M. K. Warmuth, Department of Computer and Information Sciences, University of California at Santa Cruz, Santa Cruz, CA 95064.

Permission to copy without fee all or part of this material is granted provided that the copies are not made or distributed for direct commercial advantage, the ACM copyright notice and the title of the publication and its date appear, and notice is given that copying is by permission of the Association for Computing Machinery. To copy otherwise, or to republish, requires a fee and/or specific permission. 0 1989 ACM 0004-541 l/89/1000-0929 \$01.50

# 1. Introduction

Valiant has recently introduced a new complexity-based model of learning from examples and illustrated this model by exhibiting and analyzing several learning algorithms for classes of Boolean functions [59, 601. In this paper we extend Valiant's model to learning concepts defined by regions in Euclidean n-dimensional space E", n 2 1. The general techniques we develop lead to new results in Boolean domains as well. Our methods are based on the pioneering work of Vapnik and Chervonenkis [6 I-631 on the distribution-free convergence of empirical probability estimates and its application to the theory of pattern recognition. These methods provide a unified treatment of some of Valiant's results, and extend previous results of Pearl [50, 5 I] and Devroye and Wagner ([ 151, see also [ 141) along with our results from [lo].

In learning a class C of concepts (e.g., subsets of E") from examples, a single target concept is selected from C and we are given a finite sequence of points in E", each labeled " 1" if it is in the target concept (a positive example) and "0" if it is not (a negative example). This set is called a sample of the target concept. A learning function for C is a function that, given a large enough randoml:y drawn sample of any target concept in C, returns a region in E" (a hypothesis) that is with high probability a good approximation to the target concept. More precisely:

- (1) We let P be a fixed probability distribution on E" and assume that examples are created by drawing points independently at random according to P.
- (2) The error of a hypothesis is taken to be the probability that it disagrees with the target concept on a randomly drawn example, that is, the error is just the probability (according to P) of the symmetric difference between the hypothesis and the target concept.
- (3) We demand that for a large enough sample size we get a hypothesis with arbitrarily small error with arbitrarily high probability, no matter which concept from C we are trying to learn. The bounds on the sample size must be independent of the underlying distribution P.

This notion of learning is formalized in Section 2. A class of concepts with a learning function that satisfies (3) is called uniformly learnable. Condition (3) is formalized by demanding that the hypothesis has error greater than E with probability at most 6 for small t and 6, uniformly for all concepts in C. The smallest sample size that achieves this for all distributions and all target concepts in C is called the sample complexity of the learning function. This general definition of uniform learnability imposes no restrictions of feasibility or even computability of the learning function; these considerations are postponed until Section 3.

In Section 2 (Theorem 2.1) we give necessary and sufficient conditions on a class of concepts C for the existence of a learning function satisfying (3). This result is based directly on the work of Vapnik and Chervonenkis [61-631; following [29], we have simplified some of their more general arguments to obtain sharper bounds on the sample complexity of functions satisfying (3) in the special case we consider. We have also added lower bounds for the sample complexity.

Our characterization of learnability uses a simple combinatorial parameter called the Vapnik-Chervonenkis (VC) dimension of the class C of concepts [29].' We show that there is a learning function satisfying (3) if and only if the VC dimension of C is finite. Moreover, if C does have finite VC dimension d then there is a

<sup>&#</sup>x27; This parameter is called the capacity of C in [61] (named after a similar notion from [ 131) and S(C) in [17].

learning function for C, uniformly achieving error no more than t with probability at least 1 - 6, using sample size m(c, 6) = max(4/E log(2/6), 8d/c log( 13/t)). In fact, any function from samples into the class C that always gives hypotheses consistent with the sample is a learning function for C and has sample complexity bounded by YM(~, 6). Applications of this result in Euclidean domains are given. We also give an example in a Boolean domain where this result gives significantly better bounds on the sample complexity than the simpler counting arguments used in [lo] (Example 2.4).

In Section 3 we introduce considerations of computational feasibility, investigating the implementation of learning functions by computationally efficient /earning algorithms.

We study two types of learning algorithms. One type works for all domains of Euclidean dimension n > 1 and for each n, learns concepts in a class C, G 2E", or C', C 210,'1' in the Boolean case. For example, a pattern recognition algorithm that finds linear separators might be used to learn the class C, of all half-spaces in E" for each y2 2 1 (see Example 3.1.2).

For the other type of learning algorithm, the domain is fixed, but the "complexity" of the target concept may vary. For example, the domain may be E\* and the class of target concepts C may be all convex polygons. Since the VC dimension of C is infinite, no algorithm can define a uniform learning function for C in the sense defined above. However, there are efficient learning algorithms for C if we allow the sample size to depend on the number of edges in the target concept, a natural measure of target complexity (see Example 3.2.2).

These two types of learning algorithms lead to two notions of feasible (but nonuniform) learnability for concept classes: polynomial learnability with respect to domain dimension, in which the sample size is allowed to grow polynomially in the Euclidean dimension of the domain, and polynomial learnability with respect to target complexity, in which the sample size is allowed to grow polynomially in the complexity of the target concept. In both cases we insist that the sample size also be polynomially bounded in the inverses of the error and confidence parameters E and 6, and that the learning algorithm run in time polynomial in the sample size. These notions of polynomial learnability, both closely related to the model introduced in [59] and elaborated in [36] and [52], are discussed in Sections 3.1 and 3.2, respectively.

The main result of Section 3.1 gives a characterization of polynomial learnability with respect to domain dimension. We show that the concept classes C,,, n 2 1, are polynomially learnable if and only if the VC dimension of C, grows polynomially in n and there exists a polynomial time probabilistic algorithm for finding a consistent hypothesis in C, for any sample of a target concept in C, (Theorem 3.1.1). As a corollary, we get a result of Natarajan [48] that in the Boolean case, the concept classes C,, C 2'"~'i", n 2 1, are polynomially learnable if and only if log 1 C,, 1 grows polynomially in n and there exists a polynomial time probabilistic algorithm for finding a consistent hypothesis in C, for any sample of a target concept in C, (Corollary 3.1.3). Related results are given in [30]. We give several examples that illustrate these results.

In Section 3.2 we give a sufficient condition for polynomial learnability with respect to target complexity based on the principle of preferring the simpler hypothesis, usually called Occam's Razor (Theorem 3.2.1). Essentially, this result shows that if we can efficiently produce a hypothesis that explains (i.e., is consistent with) the sample data, and is sufficiently more compact than the sample data, then we can feasibly learn. In this sense the result may be interpreted as showing a

relationship between a kind of data compression and learning (see also [55] and [651).

We use this result to study learning in concept classes that are formed .by taking either finite unions or finite intersections of a fixed base class of finite VC dimension. For example, convex polygons are defined by finite intersections of half-planes. We show that classes of this type are polynomially learnable with respect to target complexity whenever there is a polynomial-time algorithm for finding a consistent hypothesis in the base class (Theorem 3.2.4). In obta:ining this result, we employ the greedy algorithm for set cover to obtain a sufficiently simple explanation of the sample data. We do not attempt to find the simplest explanation, as this is, in general, NP-hard.

Finally, we note that this paper is mostly self-contained in that complete proofs for all the probabilistic and combinatorial lemmas are provided. However, we have relegated many of them to the Appendix. We close with a brief overview of this Appendix.

Section Al extends the notion of an t-transversal for a class of regions R G 2E" introduced in [29]\* to arbitrary probability distributions on E". For a fixed distribution, an E-transversal for R is a finite set of points N G E" such that every region in R of probability at least E contains at least one point in N. Se:ction A2 uses the notion of an c-transversal to provide the primary machinery for Theorem 2.1, following [29] and [62].

In Section A3 we briefly explore the more general problem of learning "stochastic" target concepts, that is, concepts in which the classification of each point in the domain is defined probabilistically rather than deterministically. This is a fairly standard assumption in the pattern recognition literature (e.g., [ 161). Here we provide some sufficient conditions for learning such concepts derived directly from results in [61]. These results can also be viewed in te-ms of a strengthened notion of an e-transversal. Finally, we discuss the relationship between the problem of learning stochastically defined target concepts and some recent extensions of Valiant's learning model that allow misclassifications in the training examples [4, 34, 39, 58, 601.

Notation. SAT denotes the symmetric difference of sets S and T, and 1 S 1 the cardinality of S. For S L X, Z, denotes the indicator function for S on X, that is, Is(x) =1 if x E S, Is(x) = 0, otherwise. X" denotes the m-fold Cartesian product of X. Elements of X" will be denoted by barred variables, for example, 7 or 7. We assume X denotes (x, , . . . , x,) where x, E X, 1 5 i I m, when m is clear from the context, and similarly for other barred variables. If P is a probability distribution on X, then P" denotes the m-fold product probability distribution on X". Natural logarithms are written "ln", all other logarithms are base 2. Z denotes the integers and Z+ the positive integers.

## 2. Learnability

We use the following notions of learning functions and learnability.

Definitions. A concept class is a nonempty set C G 2x of concepts. In this paper it is assumed that X is a fixed set, either finite, countably infinite, [0, l]", or E" (Euclidean n-dimensional space) for some n 2 1. In the latter cases, we assume that each c E C is a Bore1 set. For 3 = (xl, . . . , x,) E X", m 2 1, the m-sample of

<sup>2</sup> What we call an e-transversal is called an c-net in [29]. Here we have loosely borrowed some terminology from [ I 1, page 65 ] to avoid confusion with the topological notion of an e-net used in [6 l] and elsewhere.

c E C generated by 2 is given by sam,(x) = ((x,, ZJx,)), . . . , (x,, 1,(x,,,))). The sample space of C, denoted SC, is the set of all m-samples over all c E C and all ~~P,forallmr 1.

AC,H denotes the set of all functions A: SC + H, where H is a set of Bore1 sets on X. H is called the hypothesis space. Elements in Hare called hypotheses. Usually we would like the hypothesis space to be C itself, but in some cases it is computationally advantageous to allow A to approximate concepts in C using hypotheses from a different class H. A E AC,H is consistent if its hypothesis always agrees with the sample, that is, whenever h = A(( xl, al ) . . . , (xm, a,)) then for all i, 1 5 i 5 m, ai = Zh(Xi). For any A E AC,H, probability distribution P on X, c E C, and .Z E X", the error of A for concept c on 2 (with respect to P) is given by errorA,c,p(Z) = P(cAh), where h = A(sam@))). Thus, A's error is measured as the probability of the region that forms the symmetric difference between the target concept and A's hypothesis, which is just the probability that A's hypothesis will be inconsistent with the target concept on a randomly drawn point (with respect to P). When c and P are clear from the context, we refer to P(cAh) simply as the error of h.

Let m(c, S) be an integer-valued function of e and 6 for 0 < t, 6 < 1 and P be a probability distribution on X. A E A C,H is a learning function for C (with respect to P) with sample size m(t, S) if for all 0 < t, 6 < 1 and for all c E C, P"'(',')( W) 5 6, where W = (3 E X"'(',') : error,+,,(X) > E 1. If A is defined in such a way that W is not measurable for some c E C, then we require that there exist a measurable IV' such that WG W' and Pmcf,')( W' ) 5 6. Essentially, we insist that using a randomly drawn sample of size m(e, S) of any target concept in C, A produces, with probability at least 1 - 6, a hypothesis in H with error no more than t. If such an A exists, we say that C is untformly learnable by H under the distribution P.

Finally, we say A E AC,H is a learning function for C with sample size m(t, 6) only when A is a learning function for C with respect to P with sample size m(c, 6) for all probability distributions P on X. The smallest such sample size m(E, 6) is called the sample complexity of A. If such an A exists, we say C is uniformly learnable by H. When we say "C is uniformly learnable," we mean that C is uniformly learnable by H for some hypothesis space H.

Example 2.1. Consider the problem of learning concepts such as the concept of "medium build," defined (for men) as having weight between 150 and 185 pounds and height between 5'4" and 6'0". By looking at a finite database of randomly chosen men that gives their weight, height, and classification (medium build or not), we want to form a rule that approximates the true concept of medium build, and we want our approximation to be accurate independently of the underlying distribution on height-weight pairs (height and weight values are not assumed to be independent). This type of learning problem is formalized and solved as follows:

Let X be E2 and C be the set of all axis-parallel rectangles, that is, products of intervals on the x-axis with intervals on the y-axis. Let P be any probability distribution on E2. A simple algorithm to learn a concept c E C is the following. Keep track of the minimum and maximum x and y coordinates of any positive example. Let I', r', b', t ' denote these four values, respectively. After drawing a number of examples, predict that the concept is h = [I ', r'] x [b', t 'I. If no positive examples are drawn, let h = 0. Call the learning function defined by this algorithm A.

We claim that A is a learning function for C with sample complexity at most 4/t ln(4/6).

Assume the concept c to be learned is the product of the intervals [/, Y] on the x axis and [b, t ] on the y axis. Since A's hypothesis h is always contained in c, if P(c) C t, then eYYoyA,,:p of any sample of c is always less than t. Otherwise, we define four minimal side rectangles within c that each cover an area of probability at least t/4:

$$left = [l, x] \times [b, t], \text{ where } x = \inf\{x : P([l, x] \times [b, t]) \ge \epsilon/4\}$$

and right, bottom, and top are defined similarly. If the sample size is m, the probability that a particular side rectangle contains no example is at most (1 - t/4)"'. The probability that some side rectangle contains no example is bounded by 4 times this quantity. This latter quantity is smaller than 4ePmtf4, so if the sample size nz is at least 4/e ln(4/6), then with probability at least 1 - 6 we draw an example in each of these four side rectangles. If this occurs, then the probability of the region given by the symmetric difference of A's hypothesis and c will be less than 6, thus bounding the error of the hypothesis. Since this bound is independent of the particular distribution P, the claim follows.

This example readily generalizes to n-dimensional rectangles for n > 2, with a bound of 2n/t ln(2n/6), on the sample complexity.

It is not clear even in two dimensions how to generalize the above example to other types of concepts, for example, circles, half-planes or rectangles of arbitrary orientation. To show that these classes are also uniformly learnable, we use a concept first introduced in [62].

Definition. Given a nonempty concept class C C 2x and a set of points S c X, II&S) denotes the set of all subsets of S that can be obtained by intersecting S with a concept in C, that is, II&S) = (S fl c: c E C). If II,(S) = 2', then we say that S is shattered by C. The Vapnik-Chervonenkis (VC) dimension of C is the cardinality of the largest finite set of points S c X that is shattered by C. If arbitrarily large finite sets are shattered, the VC dimension of C is infinite.

Note that the empty set is always shattered, so the VC dimension is well defined. The following additional notation will also be useful.

Definition. For any integer m 2 0, II,(m) = max( 1 II&S) I) over all S C X of cardinality m.

Using this notation, the VC dimension of C can be defined as the largest integer d such that II,(d) = 2d, or infinity.

Example 2.2. Let X be the real line and let C be the set of all intervals (open or closed) on X. Then given any set S consisting of two points x1, x2 E X, we can find concepts cl, c2, c3, c4 E C such that cl n S = (x, ), c2 n S = {x2), c3 n S = 0, and c4 n S = S. Hence, S is shattered by C. However, if S consists of three points xl I x2 I x3, then there is no concept c E C that contains xl and x3 but not x2, and hence S is not shattered. Thus the VC dimension of C is 2.

More generally, let X be the real line and let C be the set of all unions of up to s intervals for some fixed s L 1. If S consists of points x1, . . . , .X~~, where X, I Xi+,, 1 I i < 2s, then it is easily verified that S is shattered by C. However, if S consists of points xl, . . . , xzs, xzs+, , where X; 5 Xi+, , 1 I i 5 2s, then no concept in C contains xl, x3, . . . , x2,7+1 without also containing a point in x2, x4, . . . , ;c2c2s. Thus S is not shattered and hence the VC dimension of C is 2s.

Generalizing in a different manner, let X be E" for some n I 1 and C be the set of axis-parallel rectangles on X as in Example 2.1 above. It is easily verified that if

S consists of the 2n points at the centers of the faces of the unit n-cube, then S is shattered by C. However, if S consists of any 2n + 1 points, then consider the smallest closed axis-parallel rectangle R that contains the points of S. Since R has only 2n faces, there must be some point x E S such that either x lies in the interior of R, or x lies on the face of R along with another point of S. Hence, any concept in C that includes all the other points of S must include X. Thus S is not shattered by C and therefore the VC dimension of C is 20.

Example 2.3. Let C be any finite concept class. Then since it requires 2d distinct concepts to shatter a set of d points, no set of cardinality larger than log ] C ] can be shattered. Hence, the VC dimension of C is at most log 1 C 1.

Vapnik and Chervonenkis [63], Dudley [ 171, Wenocur and Dudley [66], Assouad [6], and Haussler and Welzl [29] give numerous additional examples of concept classes of finite VC dimension. For example, the VC dimension of half-spaces and balls of E" is n + 1. In general, whenever C is of finite VC dimension, then Ck, the set of all Boolean combinations formed from at most k concepts in C, is also of finite VC dimension [ 171. Thus, for example, since the set Ck of convex k-gons in E" for fixed k > n is formed by k-fold intersections of half-spaces, Ck is of finite VC dimension for any finite k (see Example 3.2.2). Wenocur and Dudley [66] also prove more general results that imply, for example, that the concept class formed by the set of all half-spaces bounded by polynomial curves of fixed degree also has finite VC dimension (see Example 3.1.3). On the other hand, the set of all finite unions of intervals, like the set of all open sets or all Bore1 sets, obviously has infinite VC dimension.

Definition. A concept class C G 2x is trivial if C consists of one concept, or two disjoint concepts cl and c2 such that cl U c2 = X.

It is clear that a sample size of one is the most that is required to learn C when C is trivial.

We can now state the main result of this section.

THEOREM 2.1. Let C be a nontrivial, well-behaved 3 concept class.

- (i) C is untformly learnable tfand only if the VC dimension of C is finite.
- (ii) Ifthe VC dimension of C is d, where d < ~0, then
  - (a) for 0 < E < 1 and sample size at least

$$max\left(\frac{4}{\epsilon}\log\frac{2}{\delta}, \frac{8d}{\epsilon}\log\frac{13}{\epsilon}\right),$$

any consistent function A: Se -+ C is a learning function for C and (b)4 for 0 < e < \$ and sample size less than

$$max\left(\frac{1-\epsilon}{\epsilon}\ln\frac{1}{\delta}, d(1-2(\epsilon(1-\delta)+\delta))\right),$$

no function A: Se + H, for any hypothesis space H, is a learning function .for C.

<sup>3</sup> This is a relatively benign measure-theoretic assumption discussed in Section A 1 of the Appendix.

<sup>4</sup> This lower bound has recently been improved [20] to max(( 1 - t)/t In l/6, (d - 1)/32c) for e I \$ and 6 5 & which asymptotically meets the upper bound of (a), except for an O(log l/t) factor.

The proof will be given in a series of lemmas and theorems, most of which are given in the Appendix. We first observe that if (ii)(a) holds then the "if" part of(i) follows. This is because we can always produce a consistent function that maps from SC into C by simply well-ordering the concepts in C and choosing for each sample in S, the first concept that is consistent with this sample. In this section we are not concerned with the computability of A. Similarly, if (ii)(b) holds, then the "only if" part of(i) follows. This is because the second lower bound of (ii)(b) grows arbitrarily large with d for appropriate choice of t and 6. Hence, we need only establish (ii). The proof of (ii)(a) is given in Section 2 of the Appendix. Here we give only the following proof:

PROOF OF (ii)(b). Let C be a nontrivial concept class of finite VC dimension d, 0 < E < i, and m = max(( 1 - c)/cln l/6, d( 1 - 2(~( 1 - S) + 6))). We must show that any learning function for C must use sample size at least m. We begin with the first term of the lower bound, considering two cases for C.

Case 1. C contains two distinct concepts cl and c2 that have a nonempty intersection.

Let A be a learning function for C and let a E cl n c2 and b E c2 - cl. Let P be the probability distribution such that P(b) = c, P(a) = 1 - t, and P(x) = 0 for any other point x E X. With respect to this distribution, we can effectively replace X with the set (a, b), C with ((a], {a, b]], and H with the four subsets of (a, b], modifying A accordingly. (C may contain other subsets of X as well, but this would only make the learning problem harder.)

It is easily verified that if the sample size m is less than l/(-ln(1 - c))ln(1/6), then the probability of drawing the point a each time is greater than 6. Since 1 /(-ln( 1 - t)) > ( 1 - t)/t for all 0 < t < 1, this holds for m 5 (1 - c)/c ln( l/6). We can divide the possible learning functions for C into four types, depending on how they respond to an m-sample in which each point is a. Since both concepts in C contain a, all examples of the sample will be positive. If the learning function responds by producing the hypothesis (a), then for this sample it has error t if the target concept is (a, b}. If it responds (a, b}, (b], or 0, then, because E < jr, it has error at least E if the target concept is (a). In any case, there is a concept in C such that the probability that A produces a hypothesis of error at least t with sample size m is greater than 6. By decreasing the probability of a slightly and increasing the probability of b by the same amount it follows that the previous statement also holds for error strictly larger than t instead of error at least E. We conclude A cannot be a learning function for C with sample size m < (1 - c)/t ln( l/6)..

Case 2. C contains at least two disjoint concepts cl and c2 such that cl U c2 # x.

Let a E X - (c, U c2) and b E cl. Given any learning function A for C, we let the distribution P be defined as above in Case 1 and replace X by {a, bj, C by I(b), 01, H by 2'a,b1, and modify A accordingly. The remainder of the analysis is the same, except that we consider the case when A receives a sequence of negative examples, all of the point a.

This completes the verification of the first term of the lower bound.

For the second term of the lower bound, note that since C is nontrivial, the VC dimension d of C is at least 1. There must exist a set & of d points in X that are shattered by C. Let the probability distribution P on X be uniform on these points and 0 everywhere else. With respect to this distribution, we may replace X.with & and C with 2xd.

Suppose we draw a sequence X E X" and 1 different points are observed in this sample. For each of the 2' possible labelings of X, there are 2d-' concepts consistent with this labeling. Whatever the hypothesis of the learning function, for every point of X not observed in X, it will be correct for exactly half these concepts. Thus, the average error of the learning function on 2 over all concepts in C is at least (d - 1)/(2d) I (d - m)/(2d). This implies that the average error of the learning function over all X E X" and all concepts in C is at least (d - m)/(2d). Hence, there must be a concept with average error at least (d - m)/(2d). To make the frequency of m-sequences in which the error on this concept is greater than E at most 6, the error can be greater than t (i.e., 1) on at most 62" of the m-sequences, and must be at most c on the remainder. Hence, the average error can be at most t( 1 - S) + 6, which gives the second part of the lower bound.

Combined with the proof of (ii)(a) given in the Appendix, this completes the proof of Theorem 2.1. Cl

The above theorem shows a significant gap in the inherent sample complexity of learning problems: depending on whether or not the VC dimension of a concept class C is finite, either C is uniformly learnable with sample size O( l/t log( l/(&))) or C is not uniformly learnable at all. Furthermore, if C is uniformly learnable, then there exists one sample size proportional to the VC dimension of C that any learning algorithm for C must use, and another sample size proportional to the VC dimension of C that is sufficient for any consistent algorithm using hypothesis space C. Hence, the sample complexity of learning C is linear in the VC dimension of C in a strong sense.

It also has immediate consequences for several well-known pattern recognition algorithms. For example, since the VC dimension of half-spaces in E" is n + 1, the sample complexity of the classical perceptron learning algorithm (see, e.g., [ 161) is at most max(4/c log(2/6), 8(n + 1)/c log( 13/c)), that is, at most this many examples are required to achieve error at most t with probability at least 1 - 6, independent of the underlying distribution governing the selection of examples. (Here we assume that one random sample of an unknown half-space is drawn and the algorithm cycles through this sample until it finds a hyperplane that correctly separates the positive from the negative examples.) Since 6 appears only in a log term, this implies that good linear separators can be found with very high probability from relatively small random samples. Furthermore, the same bound applies to any learning algorithm for half-spaces that produces consistent hypotheses that are halfspaces, for example, the Ho-Kashyap algorithm or linear programming [ 161 (see also Example 3.1.2 below).

Since the above bound is O( l/c(log( l/6) + n log( l/E))), for small t it is significantly better than the O( l/~'(log( l/F) + nlog(n/t))) bound given in [51] (eq. 29) derived directly from [ 151 and [62]. However, the latter bound is more robust in that with this sample size, an accurate estimate of the true error of any half-space that is hypothesized can be obtained from its observed rate of disagreement with the target. This may be necessary in cases where no half-space is consistent with the sample data, for example, because of noise in the data, or because the target concept is not a half-space. In a recent overview paper, Devroye [ 141 discusses further applications of results of this type, derived from the original work of Vapnik and Chervonenkis, to a variety of other pattern recognition methods. In Appendix A3 we indicate how the bounds given by Vapnik [61] on the relative deviation of empirical estimates from true probabilities provide an alternate analysis in cases where the hypothesis does not fit the training data exactly. This analysis gives

smaller required sample sizes when the observed rate of disagreement between target and hypothesis is small.

Other general techniques for obtaining distribution-free learning results for the case when the hypothesis space is finite, for example, for learning problems in Boolean domains, have been described in [lo] (see also [61]). In analogy with Theorem 2. I(ii)(a), we have the following result.

THEOREM 2.2 [ 10, 6 11. Let C C 2x be anyfinite concept class. Then for sample size greater than l/t/n( 1 C//6), any consistent function A: SC + C is a learning function for C.

PROOF. Let P by any probability distribution on X and c be any target concept in C. Any hypothesis h E C with error greater than t will be inconsistent with an m-sample of c unless all examples in it land in the region outside the symmetric difference of h and c, a region of probability less than 1 - c. The probability of this occurring for a particular h E C is at most (1 - t)" I e-'". So the probability of it occurring for any h E C is at most ] C ] eetm. If m 2 l/c ln( ] C I/S), then this probability is at most 6. Hence, since A produces consistent hypotheses in C, for this sample size the probability that A's hypothesis has error greater than e is less than 6. Cl

Theorem 2.l(ii)(a) can also be used to obtain bounds of the type given in the above result, since the VC dimension of C is at most log ] C ] for finite C. However, in many cases Theorem 2.2 is easier to apply than Theorem 2.1 (you do not need to calculate the VC dimension of C) and yields slightly better bounds on the sample complexity. Its proof is also considerably simpler. On the other hand, in some cases merely counting the number of different possible concepts is too crude a measure to use in estimating the sample complexity of a learning algorithm.

Example 2.4. Consider the case of pattern recognition with linear separators on Boolean domains: Let X = (0, 1)" and C be the class of concepts on X defined by linearly separable Boolean functions on n variables (i.e., intersections of halfspaces with the Boolean n-cube) [25, 421. In [46], it is shown that 2"("-')"2 I ] c'] 5 2"\*. So by applying Theorem 2.2 we cannot show that C is uniformly learnable with a sample size that is better than O(l/t(n' + log(1/6))). In fact, since halfspaces in E" have VC dimension n + 1, the VC dimension of C is at most n + 1 and thus by Theorem 2.1, C is uniformly learnable with sample size 0( l/c(n log( l/t) + log( l/6))) by any consistent learning function. For fixed E and 6 this is a reduction in the sample complexity bound from O(n2) to O(n).

#### 3. Polynomial Learnability and Occam's Razor

In this section we examine the computational feasibility of learning various concept classes. Part of this involves looking at how learning functions can be implemented as algorithms that take samples and return hypotheses. However, to be useful, a theory of learning algorithms must start with a somewhat broader notion than that of a learning function as given in the previous section.

First, learning algorithms are often defined for domains of arbitrary Euclidean dimension. For example, the techniques for finding linear separators discussed in the previous section work for any dimension. It is best to think of such a technique, that is, the technique of finding a hypothesis with linear programming or that of cycling through the data with the perceptron algorithm, as a single learning

algorithm that works for the class of half-spaces in any Euclidean dimension. In this way we can focus on how the sample size required for learning and the computational efficiency of the hypothesis-producing procedure are affected as the dimension of the domain increases. Because the sample size required grows with the domain dimension, this type of learning result is not uniform in the strong sense defined in the previous section, where the sample size was bounded only in terms of the accuracy and confidence parameters e and 6.

Another type of nonuniform learning is also of interest in a computational theory of learnability. As an example, consider again the algorithm for learning axisparallel rectangles. In Euclidean dimension 1, this reduces to an algorithm for learning intervals on the real line. Without increasing the dimension of the domain, this algorithm can be generalized to learn target concepts that are unions of intervals of the real line (see Example 3.2.1 below). Since the VC dimension of the class C of all finite unions of intervals on the real line is infinite, Theorem 2 shows that C is not uniformly learnable. Nevertheless, the algorithm in Example 3.2.1 is a very practical learning algorithm. Given a relatively small sample of any target concept defined by a union of a small number s of intervals, it produces, with high probability, a hypothesis with small error, independent of the distribution. It does not learn C uniformly because the sample size needed grows with s.

The above example shows that it is not only useful to parameterize learning algorithms and learnability results by the dimension of the domain, but also by some natural measure of the syntactic complexity of the target concept, in this case the number of intervals used to define it. Both of these considerations are emphasized in [36] and [52] in the investigation into the learnability of Boolean functions. We treat both of these issues formally in the next two subsections. The consequences of introducing syntactic complexity into an abstract theory of learnability have recently been explored independently from our work in [8] and [41].

Before proceeding, we note that the efficiency of a learning algorithm in a realvalued domain will depend on which of the standard computational models is adopted. We can choose either the logarithmic cost model, in which real numbers are represented in finite precision and operations on them are charged time proportional to the number of bits of precision, or the uniform cost model, in which real numbers occupy one unit of space and standard operations of addition, multiplication, etc. take one unit of time (see [ 11). We deem it unwise at this point to attempt to dictate which model is correct for the study of computational learnability, so we shall leave this aspect of our basic model unspecified. Our theorems hold in either model, but specific examples are occasionally modeldependent.

3.1 POLYNOMIAL LEARNABILITY WITH RESPECT TO DOMAIN DIMENSION. For the purposes of computation, we must assume some representation for the hypotheses produced by a learning algorithm, and in addition, we may assume some representation for the target concepts. Usually the class of target concepts and hypothesis space are the same and the same representation is used, but this is not always so (see, e.g., [36]).

Definition. For each n 2 1 let X,, be a learning domain, which in this section is either E", [0, 11" or (0, 1)". For computational purposes, we assume that points in X,, are represented as n-tuples in a standard way. Let C, C 2xn be a class of target concepts on X, and let H, c 2xn be a hypothesis space. We assume that H, is wellbehaved and that both 0 and X,, are members of H,.

Let there be associated with ((X,, H,)),,, a set of representations for concepts in each H,, n 2 1, given in some representation language. We assume only the following properties of this language.

- (1) Each string in the representation language uniquely represents a concept in H,, for some y1 L I, and each such concept has a representation in the language.
- (2) The language is in P, that is, there is a polynomial-time algorithm to decide if a string is in the language or not.
- (3) There is a polynomial-time algorithm that, given a string Y in the language and a point x E X,, for some n 2 I, decides if x is in the concept represented by Y or not.

Let there be a similar representation associated with ((X,,, Cn)jnZl.

By C we denote 1(X,, C,)],,i, along with its representation, and by H we denote ((X,, H,,)],,, , along with its representation. We use the term concept c/ass to refer to C and also to refer to individual sets C,,. We say that a concept c is in C if c E U C,. Similar conventions are adopted for H, except that, following established convention, H is referred to as the hypothesis space.

Refining the learnability definitions from the previous two sections, we now give a definition of polynomial learnability with respect to the dimension Y,! of the domain. Because in this definition a learning algorithm implements a function from samples to hypotheses, we call this the functional model of polynomial learnability.

Definition. Let C and H be defined as above. We say that C is polynomial/y learnable (poly-learnable) by H if there exists a polynomial-time algorithm A that takes as input a sample of a concept in C, outputs a hypothesis in H, and has the property that for all 0 < c, 6 < 1 and n 5: 1 there exists a sample size m(t, 6, n), polynomial in l/c, l/6, and n, such that for all target concepts c E (Zn;?, and all probability distributions P on X,, given a random sample of c of size m(t, 6, n) drawn independently according to P, A produces, with probability at least 1 - 6, a hypothesis h E H, that has error at most E (i.e., a hypothesis h such that P(hAc) zz 6). The smallest such m(t, 6, n) is called the sample complexity of A.

If C is poly-learnable by C, then we say C is properly poly-learnable. Cl

Essentially this definition requires that the algorithm A define for each n 2 1 a learning function for C,, by H,, and that the sample complexity and computation time for A be polynomial in the appropriate parameters. A similar definition of polynomial learnability is used in [56].

In the above definition the computation time of the learning algorithm is measured as a function of input length. It is also possible to allow the computation time to depend explicitly on the accuracy and confidence parameters t and 6. Since this, and other extensions of the above model, are allowed in the definition of polynomial learnability in [52] and [59], we now introduce a second model of polynomial learnability, which we call the oracle model (see also [3] and [36]).

In the oracle model the learning algorithm receives the parameters c, 6, and n as input and has access to an oracle EX() that with each call returns a point in X, drawn independently at random according to a fixed distribution P, along with a label 0 or 1 indicating whether or not the point is in a fixed target concept c E C,,. Each oracle call takes unit time. After some time A halts and outputs a hypothesis in H,. In addition to allowing A access to t, 6, n, and an oracle for examples, we

also allow A to be randomized, in the sense that A can in unit time flip a fair coin to decide its next move. An algorithm of this type will be called a (randomized) oracle algorithm.

Definition. We say that C is polynomially learnable (poly-learnable) by H in the oracle model if there exists a (possibly randomized) oracle algorithm A that has the property that for .a11 0 < E, 6 < 1 and n 2 1 there exists a time bound' L(t, 6, n), polynomial in l/e, l/6, and n, such that for all target concepts c E C,, and all probability distributions P on X,,, A runs in time T,(E, 6, n) and produces, with probability at least 1 - 6, a hypothesis h E H, that has error at most t.

The functional and oracle models of polynomial learnability are shown to be equivalent in [30], along with another variant of the oracle model in which there are two probability distributions on the domain X, and two oracles, one for positive examples of the target concept and one for negative examples (e.g., [36] and [52]). However, if randomized oracle algorithms are allowed, the latter proof of equivalence also requires the assumption that H, includes (x) for every x E X,. Because of this close relationship between the models, we use the term poly-learnable to mean polynomially learnable in any one of these models, and similarly for properly poly-learnable.

The results of Section 2 show that a number of interesting concept classes are properly poly-learnable. In the following examples we can assume any of the standard representations for the concepts.

Example 3.1.1. Define C by letting C, be the class of all axis-parallel rectangles in E". Then the algorithm given in Example 2.1, extended appropriately to arbitrary dimension n, has the property that given any sample of size 2n/cln(2n/6) of a target concept that is an axis-parallel rectangle in E", it produces a hypothesis that is an axis-parallel rectangle in E" and, with probability at least 1 - 6 this hypothesis has error at most c, independent of the distribution. Since, in addition, the time required to compute the hypothesis is polynomial in the length of the input (the algorithm merely computes the smallest and largest value of coordinate i among all positive examples for each 1 5 i I n), this shows that C is properly polylearnable. Note that using the fact that the VC dimension of C, is 2n (Example 2.2) and that the algorithm always returns a consistent hypothesis in C,,, this result can also be derived directly using Theorem 2.l(ii)(a).

Example 3.1.2. Define C by letting C, be the class of all half-spaces (open or closed) in E". We can find a hypothesis in C', consistent with a sample of a concept in C, by finding a hyperplane separating the positive from the negative examples. This problem can be reduced to a linear programming problem in n + 1 dimensions in which each example forms a constraint. Thus using a polynomial-time algorithm for linear programming, e.g., Karmarkar's algorithm [33], we have a polynomialtime algorithm that always produces a consistent hypothesis in C,. Since the VC dimension of C, is n + 1, Theorem 2.l(ii)(a) shows that the function defined by any such algorithm is a learning function for C, by C, using sample-size polynomial in l/t, l/6, and n. Hence, C is properly poly-learnable.

Note that in this case Megiddo's technique for linear programming [44] would not suffice because its time complexity grows exponentially in the dimension of

<sup>5</sup> When the domain is real-valued and the logarithmic cost model is adopted, we also let the time bound depend polynomially on the length of the longest example returned by the oracle.

the linear programming problem (see, e.g., [40]). The perceptron algorithm and related pattern recognition techniques will also take exponential time to produce a separating hyperplane in some cases [25]. On the other hand, the polynom:ial-time bound for Karmarkar's algorithm holds only in the logarithmic cost model. It is still an open problem to determine if the class of half-spaces is poly-learnable by any hypothesis space in the uniform cost model.

Example 3.1.3. Let k be any positive integer constant and define C by letting C, be the set of all half-spaces in E" defined by surfaces of degree at most k, that is, regions of the form p(x,, . . . , x,) 2 0 or p(x,, . . . , x,) > 0 for some k-degree polynomial p. For k = 1, C,, is just the class of half-spaces given in Example 3.1.2. For k = 2, C,, contains n-dimensional half-spaces, balls, and all other types of halfspace regions defined by quadratic surfaces. As in Example 3.1.2, a consistent hypothesis for any sample of a concept in C,, can always be found by linear programming. In this case the dimension of the linear programming problem is O(nk), which is polynomial in n for fixed k. Furthermore, the results of [66] (also of [ 131) imply that the VC dimension of C,, is O(nk) as well. (This also follows from the fact that surfaces of degree k in II dimensions can be represented as hyperplanes in an O(n') dimensional space.) Hence, again using Karmarkar's algorithm, C is properly poly-learnable.

EXUF??pfe 3.1.4. Let k be any positive integer constant and define C by letting C,, be the class of concepts on {O, 1)" defined by k-DNF formulas. Th.ese are Boolean formulas in disjunctive normal form (i.e., a disjunction of terms, each term a conjunction of literals) in which each term contains at most k literals. Valiant gives a learning algorithm which shows that C is properly poly-learnable [59, 601. This result also holds for the dual class defined by k-CNF formulas. However, by a simple counting argument, ] C, ] 5 2((2n)"). Hence, by Theorem 2.2, any algorithm that always produces a consistent k-DNF (k-CNF) hypothesis (and in particular, the algorithm given by Valiant) defines a learning function for C,, by C,, with sample size 0( l/c(nk + log(1/6))) (the sample size used by Valiant's algorithm). Hence, any such algorithm that runs in polynomial time can lbe used to show that C is properly poly-learnable.

All of these examples rely on two basic properties of C. The first is that each class C,, has finite VC dimension and the VC dimension grows only polynomially with n, so that by Theorem 2.1, learning is possible with a reasonably small sample size. In Example 3.1.4 this is guaranteed by the fact that log ] C,, ] grows polynomially in n. The second is the existence of an efficient algorithm for producing consistent hypotheses in C', from samples of target concepts in C,,. Using the techniques of [30], [47], [48], and [52], we can cast these requirements in the form of a characterization of proper polynomial learnability.

Definition. Let C = ((X,,, Cn))n,,, along with some representation. A randomized polynomial hypothesis finder (r-poly hy-fi) for C is a randomized polynomial time algorithm that takes as input a sample of a concept in C and for some y > 0, with probability at least y produces a hypothesis in C that is consistent with this sample. We refer to y as the success rate of the r-poly hy-ti.

THEOREM 3.1.1. For any concept class C = ((A',,, C,,))ntl, C is proper/y polylearnable if and only if there is an r-poly hy-ji for C and the VC dimension of C,, grows only polynomially in n.

PROOF. For the "if" part, assume that the VC dimension of  $C_n$  is bounded by p(n) for some polynomial p and that we are given an r-poly hy-fi for C with success rate  $\gamma$ . Let A be a randomized oracle algorithm defined as follows:

On input  $(\epsilon, \delta, n)$ , A calls the oracle EX() for

$$\max\left(\frac{4}{\epsilon}\log\frac{4}{\delta}, \frac{8p(n)}{\epsilon}\log\frac{13}{\epsilon}\right)$$

random examples of the target concept  $c \in C_n$  drawn according to some distribution P on  $X_n$ . Let Q be the resulting sample of c. Then A repeats the following:

- (1) simulate the r-poly hy-fi on Q
- (2) check if the output of the r-poly hy-fi is consistent with Q until either a consistent hypothesis is found or the number of repetitions exceeds  $1/\gamma \ln(2/\delta)$ .

In the first case, A returns the hypothesis found. In the second case A returns some default hypothesis in  $C_n$ .

It is easily verified that the running time of A is polynomial in  $1/\epsilon$ ,  $1/\delta$ , and n (and, if we are using the logarithmic cost model, in the maximum size of any example returned by the oracle). Furthermore, A fails to produce a hypothesis of error at most  $\epsilon$  only if it is forced to return the default hypothesis, or it returns a hypothesis that is consistent with Q but has error greater than  $\epsilon$ . Since the success rate of the r-poly hy-fi is  $\gamma$ , A is forced to return the default hypothesis with probability at most

$$(1 - \gamma)^{1/\gamma \ln 2/\delta} \le \exp\left(-\ln \frac{2}{\delta}\right) = \frac{\delta}{2}.$$

By Theorem A2.2, the probability that any hypothesis in  $C_n$  that is consistent with Q has error greater than  $\epsilon$  is at most  $\delta/2$ . Thus A returns a hypothesis that is consistent with Q but has error greater than  $\epsilon$  with probability at most  $\delta/2$ . Hence, A produces, with probability at least  $1 - \delta$ , a hypothesis that has error at most  $\epsilon$  and therefore  $\mathbb C$  is properly poly-learnable.

For the "only if" part, note first that by Theorem 2.1(ii)(b), any learning algorithm for  $\mathbb{C}$  must use a sample size that grows linearly in the VC dimension of  $C_n$ , and hence if the VC dimension of  $C_n$  is not polynomial in n, then  $\mathbb{C}$  is not poly-learnable by any hypothesis space  $\mathbb{H}$ . To show that  $\mathbb{C}$  being poly-learnable implies that there is an r-poly hy-fi for  $\mathbb{C}$ , we use a construction from [52].

Let A be a learning algorithm for  $\mathbb{C}$  in the functional model and let  $m(\epsilon, \delta, n)$  be a polynomial in  $1/\epsilon$ ,  $1/\delta$ , and n such that given  $m(\epsilon, \delta, n)$  random examples, A produces a hypothesis that has error at most  $\epsilon$  with probability at least  $1 - \delta$  for any  $c \in C_n$  and any P on  $X_n$ . Using A, we define an r-poly hy-fi B for C with success rate  $\frac{1}{2}$  as follows:

Suppose that B is given a nonempty sample Q of some concept  $c \in C_n$ , for some  $n \ge 1$ . Let P be the distribution on  $X_n$  that is uniform on all the points of  $X_n$  that appear in examples in Q, and 0 elsewhere. Let m be the number of examples in Q,  $\epsilon = 1/(m+1)$ , and  $\delta = \frac{1}{2}$ . B determines n and then produces a sample Q' of size  $m(\epsilon, \delta, n)$  by drawing points from  $X_n$  independently according to P and labeling them with the same labels they had in Q. B then simulates the learning algorithm A on Q' and returns the output of A.

It is easily verified that B is a polynomial-time algorithm. Since 6 = i and B produces a sample of the target concept c of size m(~, 6, n) independently drawn according to the distribution P, by our assumptions on the learning algorithm A, B's simulation of A produces a hypothesis that has error at most E with respect to c and P with probability at least \$. Since every point of X, that appears in Q has probability at least l/m according to P, any hypothesis that is not consistent with Q has error greater than t. Hence, B produces a hypothesis that is consistent with Q with probability at least i. Therefore B is an r-poly hy-li for C with success rate at least f. 0

As a corollary of Theorem 3.1.1, we also obtain a useful characterization of proper polynomial learnability in the Boolean case.

LEMMA 3.1.2 [48]. Assume that X,, = (0, 1)" and C,, C 2xn for each n I 1. Then the VC dimension of C,, grows polynomially in II if and only if log) C, 1 grows polynomially in n.

PROOF. For all n 2 1, let q(n) be the VC dimension of C,. Since C,, = II,(X,,), Proposition A2.1 shows that ] C,, ] 5 (2n)q(n) + 1 = 2nq(n) + 1. Thus when q(n) grows polynomially, log ] C, ] grows polynomially. On the other hand, if ] C ] 5 2p(n) then no subset of X, of cardinality larger than p(n) can be shattered by >n, and hence q(n) I p(n). Thus when log ] C,, ] grows polynomially, q(n) grows polynomially. Cl

COROLLARY 3.1.3. For any concept class C = {({O, 1 j", Cn))nz,, C is properly poly-learnable I! and only if there is an r-poly hy-fi for C and log I C, I grows polynomially in n.

PROOF. Follows directly from Theorem 3.1.1 and Lemma 3.1.2. •i

This characterization is useful both for showing classes to be properly polylearnable, as demonstrated in Examples 3.1.1 to 3.1.4 above, and for showing that they are not properly poly-learnable unless RP = NP, as demonstrated im [52]. Here RP is the class of languages accepted by randomized polynomial-time algorithms (see, e.g., [22]) and NP is the class of languages accepted by nondeterministic polynomial-time algorithms. The negative results are obtained by reducing a known NP-complete problem to the problem of finding a hypothesis in C that is consistent with a given sample, or to the following decision problem:

Definition. For any concept class C, the consistencyproblem for C is the problem of determining if there is a concept in C that is consistent with a given sample.

Clearly, if there is an r-poly hy-li for C, then the consistency problem for C is solvable by a randomized polynomial-time algorithm. (Here we use the assurnption that the representation language for C is in P and there is a polynomial-time algorithm to check for any given c in C and point X, if x E c.) Hence if RP # NP, then when the consistency problem for C is NP-hard, Theorem 3.1.1 shows that C is not properly poly-learnable.

Results in [52] show that in the Boolean domain, when C consists of concepts represented by either DNF expressions with at most k terms or CNF expressions with at most k clauses for some fixed k 2 2 (called k-term DNF and k-clause CNF concepts, resp.), or by Boolean threshold functions (i.e., all concepts of the form (x E (0, 1)":a . x 2 y), for some a E (0, 11" and integer y > 0, where . denotes the inner product), then the consistency problem for C is NP-complete, and hence

it is unlikely that C is properly poly-learnable. However, they also show that k-term DNF concepts can also be represented by k-CNF expressions, and k-clause CNF concepts can be represented by k-DNF expressions. Hence, by the result given in Example 3.1.4 above, in either of these cases C is poly-learnable by a larger hypothesis space H (as was first shown in [52]). Since the class of concepts represented by Boolean threshold functions is contained in the class of linearly separable Boolean concepts, by Example 3.1.2, this is true for Boolean threshold concepts as well.

Results in [45] show that when C,, is the set of all concepts on E" defined by the union of two half-spaces, the consistency problem for C is NP-complete. This result holds in both the uniform and logarithmic cost models. Hence it is unlikely that C is properly poly-learnable.6

To the best of our knowledge, it is unknown if this class is poly-learnable by any hypothesis space H.

Haussler et al. [30] give an analysis of the more general case when C is polylearnable by H for distinct C and H, with an appropriately generalized definition of hypothesis finder.

3.2 POLYNOMIAL LEARNABILITY WITH RESPECT TO CONCEPT COMPLEXITY AND OCCAM'S RAZOR. We now turn to learnability results of the second type mentioned above in the introduction to this section. Here the learning domain is fixed to a single space X, but the class C G 2x of concepts is graded according to some concept complexity measure. For simplicity, we consider only the case when concepts in C are learned by hypotheses in C, although the definitions are easily extended to allow a distinct hypothesis space H.

Definition. Let X be a learning domain that for this section is either a finite set, a countably infinite set, or equal to E", for some fixed n. Let C c 2x be a wellbehaved class of concepts on X and let size be a function from C into Z'. The function size will be called a concept complexity measure. Let there also be associated with C a set of representations for concepts in C given in some representation language. As in the definition at the beginning of the previous section, we assume that there is a function from the set of representations in the language onto C, that the language is in P, and that given x E X and a string in the language, we can decide in polynomial time if x is in the concept represented by the string.

By C we denote (X, C), along with the function size and the representation for C. We use the term concept class to refer to C as well as to C. We say a concept c isinCifcEC.

In analogy with the definition of polynomial learnability in the functional model defined in the previous section, we make the following definition:

Definition. Let C be defined as above. We say that C is (properly) polynomially learnable (poly-learnable) if there exists a polynomial-time algorithm A that takes as input a sample of a concept in C, outputs a hypothesis in C, and has the property that for all 0 < t, 6 < 1 and s 2 1 there exists a sample size m(t, 6, s), polynomial in l/c, l/6, and s, such that for all target concepts c E C with size(c) I s, and all probability distributions P on X, given a random sample of c of size m(t, 6, s) drawn independently according to P, A produces, with probability at least 1 - 6, a

<sup>6</sup> A. Blum and R. Rivest have recently sharpened this result to the Boolean domain [9].

hypothesis h E C that has error at most t. The smallest such m(~, 6, s) is called the sample complexity of A.

Since we only deal with the case of C poly-learnable by C, we drop the adjective "properly" in this section. As in the previous section, there is also an oracle model of polynomial learnability in this case. In fact, the notion of polynomial learnability can be defined for situations when the size of the domain grows with a parameter n as in the previous section, and for each C,, there is also a concept complexity measure (see [30] and [36]).

Below we give a few examples to illustrate the notion of polynomial learnability with respect to concept complexity. But first we introduce some useful definitions.

Definition. Let C C 2< be a concept class. By U(C) we denote the closure of C under finite unions, that is,

$$\mathbf{U}(C) = \{c_1 \cup \cdots \cup c_s : s \ge 1 \text{ and } c_i \in C, 1 \le i \le s\}.$$

Similarly, I(C) denotes the closure of C under finite intersections.

Let us assume that there is a standard representation associated with concepts in C. This induces a standard representation for U(C) in which the concept c = Cl u ..\* u c,, where ci E C, 1 % i I s, is given as a concatenation of the representations of the ci's. The standard concept complexity measure for U(C) is the function size : U(C) + Z+ defined by letting size(c) be the smallest s such that c= Cl u 0-e U c,, where c, E C, I I i 5 s. When we say "let C = (X, U(C))", where C has some standard representation, we assume the standard representation and concept complexity measure for U(C). The class I(C) is treated similarly.

Example 3.2.1. Let C = (X, U(C)), where X is the real line and C is th,e set of intervals on X. Consider the following learning algorithm A for C.

Given a sequence of examples of a target concept c in C, sort them in increasing order according to the value of their points. Partition this ordering into alternating segments of positive and negative examples, that is, a run of consecutive negative examples, followed by a run of consecutive positive examples, etc. For each segment of positive examples form the closed interval with endpoints consisting of the smallest and largest points in the segment. Return the hypothesis h that is the union of these intervals.

It is easily verified that algorithm A always returns a hypothesis h that is consistent with the examples of c and consists of a union of the fewest possible nurnber of intervals. Hence, size(h) 5 size(c). In Example 2.2 above, we calculated the VC dimension of the class C, of all concepts c in C such that size(c) I s to be 2s. Hence, by Theorem A2.2, for any distribution P on X, given

$$\max\left(\frac{4}{\epsilon}\log\frac{2}{\delta}, \frac{16s}{\epsilon}\log\frac{13}{\epsilon}\right)$$

independent random examples of c drawn according to P, with probability at least 1 - 6, every hypothesis in C, that is consistent with all of these examples has error at most t. Since A returns a consistent hypothesis in C, and runs in polynomial time, it follows that C is poly-learnable.

Example 3.2.2. Let C = (X, I(C)), where X = E2 and C is the set of half-planes. In this case the concept class I(C) is the set of (possibly unbounded) convex polygons. In [ 191 an algorithm is developed that, given any m-sample of a convex polygon, will construct in time  $O(m \log m)$  a convex polygon that is consistent with the sample and is formed by intersecting the minimal number of half-planes, that is, a consistent hypothesis h such that size(h) is minimal.

As above, let  $C_s$  be the class of all concepts c in  $\mathbb{C}$  such that  $\operatorname{size}(c) \leq s$ , that is, polygons formed by intersecting at most s half-spaces. It is easily verified that the VC dimension of  $C_s$  is 2s + 1: First check that 2s + 1 points evenly spaced on the unit circle can be shattered by  $C_s$ .

Then note that for any set S of 2s + 2 points,

- (1) either one point lies in the convex hull of the other points, in which case, since concepts in  $C_s$  are convex, no concept in  $C_s$  contains the other points without containing this point, or
- (2) the points of S form the vertices of a convex polygon with 2s + 2 edges, in which case the subset of S consisting of every other point in the clockwise ordering of these vertices cannot be obtained by intersecting S with the intersection of less than s + 1 half-planes.

Hence, 2s + 2 points cannot be shattered and thus the VC dimension of  $C_s$  is 2s + 1.

Again by Theorem A2.2, this implies that for any distribution P on X and any  $c \in C_s$ , given

$$\max\left(\frac{4}{\epsilon}\log\frac{2}{\delta}, \frac{16s+8}{\epsilon}\log\frac{13}{\epsilon}\right)$$

independent random examples of c drawn according to P, the algorithm of [19] produces a hypothesis (in  $C_s$ ) that, with probability at least  $1 - \delta$ , has error at most  $\epsilon$ . Thus  $\mathbf{C}$  is poly-learnable.

Note that in both of the above examples, the VC dimension of the entire concept class (i.e., all unions of intervals or all convex polygons) is infinite. Hence, it does not suffice to merely find consistent hypotheses. In these cases we provided an algorithm with the stronger property that it finds consistent hypotheses with minimal complexity, and then used the fact that the VC dimension of the class  $C_s$  of hypotheses of complexity at most s grows only polynomially in s. This is a concrete case where it is provably sufficient to employ the principle of always preferring the simplest hypothesis that explains the data, usually called Occam's Razor.

However, there are simple examples where this strategy does not work because of the computational difficulty of producing consistent hypotheses of minimal complexity. Let C = (X, U(C)), where  $X = E^2$  and C is the set of all axis-parallel rectangles. Given a set of points in  $E^2$  labeled with 0's and 1's, it is NP-hard to determine the smallest s such that the set of 1-labeled points can be covered by s axis-parallel rectangles, where none of these rectangles contains a 0-labeled point [43]. Any learning algorithm for C that always produces hypotheses of minimal complexity could be used to solve this problem. Hence, finding a hypothesis of minimal complexity is NP-hard in this case.

To address the cases when it is not feasible to find the simplest hypotheses, we show that it suffices to settle for simpler rather than simplest hypotheses, that is, it suffices to produce hypotheses that are significantly simpler than the sample data itself.

Definition. Let C = (X, C) be a concept class with concept complexity measure size. Let A be a polynomial-time algorithm that, given a sample of a concept in C,

produces a consistent hypothesis in C. For every s, m 1 1, let Sc..,,m denote the set of all m-samples of concepts c E C such that size(c) I s. Let C:', C C denote the A-image of Sc.,,, that is, the set of all hypotheses produced by A when .4 is given as input an m-sample of a concept c E C with size(c) I s. We call C&,, the effective hypothesis space of A for target complexity s and sample size m. We say A is an Occam algorithm for C if there exist a polynomial p(s) and a constant a, 0 I o( < 1, such that for all s, m z 1, the VC dimension of C\$ is at most p(s)m".

In this version of Occam's Razor, the VC dimension of the effective hypothesis space C& measures how well the Razor is applied by a learning algorithm A. By allowing the hypothesis space of an Occam algorithm to grow with both target complexity and sample size, we make the search for a consistent hypothesis easier. On the other hand, we show that by restricting the VC dimension of this hypothesis space as above we guarantee polynomial learnability.

THEOREM 3.2.1. Let C be a concept class with a given concept complexity measure.

- (i) If there is an Occam algorithm for C, then C is poly-learnable.
- (ii) Let A be an Occam algorithm for C with effective hypothesis space C\$,, for target complexity s and sample size m. Then
  - (a) ifthe VC dimension of Cf, is at most p(s)m" for some polynomial' p(s) I 1 and 0 TS cx < I, then A is a polynomial-time learning algorithm for C using sample size

$$m = max \left(\frac{4}{\epsilon} log \frac{2}{\delta}, \left(\frac{8p(s)}{\epsilon} log \frac{13}{\epsilon}\right)^{1/(1-\alpha)}\right)$$

(b) if the VC dimension of C& is at most p(s)(logm)' for some polynomial p(s) 2 2 and 1 I 1, then the same result holds with the second term of the bound replaced by

$$\frac{2^{l+4}p(s)}{\epsilon} \left( log \frac{8(2l+2)^{l+1}p(s)}{\epsilon} \right)^{l+1}$$

PROOF. Since part (i) follows from part (ii)(a), it s&ices to prove part (ii). The result follows if we can show that

$$2\prod_{\mathbf{C}_{s,m}^{A}}(2m)2^{-\epsilon m/2} \le \delta, \tag{*}$$

since by Theorem A2.1, for any target concept and distribution, the left side of this inequality is a bound on the probability that there is any hypothesis in C& of error greater than t that is consistent with a random m-sample of this target. For part (a), using Proposition A2.1 (iii) and the fact that p(s) > 1, to prove (\*) it suffices to show that 2(2em/(p(s)m"))P'"'" a2-rm'2 < - 6. For part (b), using p(s) 2 2 and Proposition A2.l(ii), to prove (\*) it sufhces to show that 2(2m)p'""1"g""2-'""2 5 6. These calculations are given in Lemma A2.5 in Appendix A2.

In some ways Theorem 3.2.1 can be viewed as showing a relationship between learning and data compression.

Example 3.2.3. Let C = (X, C), where X is some countable domain, C G 2x, and for all c E C, size(c) is the number of bits needed to represent the concept c in some fixed representation language. For example, X could be the set of words

over a finite alphabet and C the class of languages represented by regular expressions, or X could be (0, 1)" for some large n and C = 2x might be all Boolean concepts on X represented by DNF expressions, decision trees, etc.

Let A be a polynomial-time algorithm that, given any m-sample of a concept c E C that can be described in s bits, produces a hypothesis in C that "explains" (i.e., is consistent with) the sample and is described in at most p(s)m" bits, for some polynomial p(s) and 0 5 o( < 1. For fixed s, this amounts to a kind of data compression on the sample.

Let C& be the effective hypothesis space of A for target complexity s and sample size m. Since ] C&, ] 5 2p(S)m", the VC dimension of C& is as most p(s)m", and hence A is an Occam algorithm for C. Thus Theorem 3.2.1 shows that A is a learning algorithm for C with reasonably small sample complexity when (Y is not close to 1.

As demonstrated in the above example, Theorem 3.2.1 shows that efficient data compression via hypothesis generation is sufficient for learning. Numerical bounds on sample complexity of Occam algorithms like the ones in that example that are slightly better in some cases than those given in Theorem 3.2.1 are derived in [IO], using a simpler argument, akin to that given in Theorem 2.2 above.

We now use Theorem 3.2.1 to demonstrate the learnability of many concept classes of the form (X, U(C)) and (X, I(C)) for C of finite VC dimension, including the case when C is the class of axis-parallel rectangles discussed above.

Definition. Let C = (X, C) be a concept class along with some representation as described above. A polynomial hypothesisfinder for C is a polynomial algorithm that, given a sample of a target concept in C, returns a hypothesis in C that is consistent with the sample. Note that, in contrast to the previous section, we do not consider randomized hypothesis finders here. The consistency problem for C (or C) is the problem of determining if there is a concept in C that is consistent with a given sample over X.

As in the previous section, given our assumptions on the representation for C, the existence of a polynomial hypothesis finder for C implies that the consistency problem for C is in P.

LEMMA 3.2.2. If C has finite VC dimension and the consistency problem for C is in P, then for any finite set S c X, the sets of n,(S) can be listed in time polynomial in the cardinality of S.

PROOF. Assume S = {xl, x2, . . . , x,,,). The size of n,(s) is polynomial in m by Proposition A2.1. To produce a list L of Il &S) we proceed as follows. Initialize L to the one element list consisting of just the empty set. This corresponds to the case m = 0. Now by induction, assume that the list L = n,( (xl, x2, . . . , xi)) has been produced for some i, 0 5 i < m. L is updated to the list II& (xi, x2, . . . , x;+~ )) as follows. For each element T of L, test the sets T and T U (xi+! 1 for membership in II& (xl, x2, . . . , x,+~ 1). Since the consistency problem for C is in P, this can be done in polynomial time by creating the appropriate samples and checking if there is a concept in C that is consistent with them. Now replace the element Tin L with either one or both of these sets, according to the outcome of this test. (Note that it is possible that T E TI& (xi, x2, . . . , xi 1) but T @ nc( (xl, x2, . . . , xi+] I).) The time for each complete update of the list L is polynomial since by Proposition A2.1 the size of L remains polynomial in m. Hence, the entire procedure is polynomial time. 0

LEMMA 3.2.3. Let C G 2x be a concept class offinite VC dimension d 2 1. Foralls~lletC,=(U~~'=,ci:c~EC,1~i~s~(resp.,C,=(~~~,c,:ciEC: 1 5 i 5 s]). Then for all s 2 1, the VC dimension of C, is less than 2dslog(3s).

PROOF. The proof is analogous to that of Lemma 4.5 of [29], which gives a slightly weaker bound. We consider only the case for unions. The case of intersections is treated similarly.

Clearly we may assume s 2 2. Consider a finite set S c X with ] S ] = m 2 1. By Proposition A2.l(i), ] Ilc(S) ] 5 ad(m). Every set in II,(S) is of the form lJfzl Si, with S'i E IIc(S), 1 I i 5 S. This shows that

$$|\Pi_{C_s}(S)| \le (|\Pi_C(S)|)^s \le (\Phi_d(m))^s.$$

If (@&m))s < 2", then S cannot be shattered by C, and the VC dimension of C, is less than m. Thus by Proposition A2.l(iii) it suffices to prove that (em/d)d" < 2'" for m = 2dslog(3s), which is equivalent to log(3s) < 9s/(2e). If the last inequality holds for some value of s, then it holds for all larger values as well. It is easy to verify it for s = 2. 0

THEOREM 3.2.4. Let C = (X, C) be a concept class and associated representation such that there exists a polynomial hypothesis finder for C and C has finite VC dimension. Then C' = (X, U(C)) (resp., C" = (X, l(C))) is polynomially learnable.

PROOF. We consider only the case C' = (X, U(C)), the other case being similar. Let S be the set of points in an m-sample of a target concept c in C'. Our strategy will be to find a hypothesis consistent with S that is formed from the union of relatively few concepts in C, that is, not many more than size(c). This problem can be formulated as a set cover problem. The set to be covered is the set of positive points of S and the sets allowed in the cover are the elements of II&S) that contain only positive points. To find the smallest set cover is NP-hard [21] and remains NP-hard for simple geometric versions such as covering with rectangles [43]. Fortunately, there is a simple greedy algorithm [32, 491 that produces a cover using at most s ln( p) + 1 sets, where s is the minimum number of sets needed for any cover and p is the size of the set to be covered: pick the set that covers the largest number of points; after this, pick the set that covers the largest nu:mber of points that have not been covered previously, and so forth.

Since the sets of B=(S) can be listed in polynomial time (Lemma 3.2.2), the largest set that contains only positive points can be found in polynomial time. Given this set, by labeling the other points negative we can use the polynomial hypothesis finder for C to produce a hypothesis in C that includes only these points of the sample. By deleting these points and then iterating this procedure, we obtain a greedy cover for the positive examples in S expressed as the union of concepts in C, which we use as a hypothesis. Call this algorithm A.

We have shown that A is polynomial time and that given any m-sample of a concept c in C' with size(c) I s, A produces a consistent hypothesis h for this sample with size(h) 5 sin(m) + 1. Hence, the effective hypothesis space C\$, of A for target complexity s and sample size m contains only hypotheses such that size(h) I sin(m) + 1. By Lemma 3.2.3, the VC dimension of C;", is O(slog(m)(logs + loglogm)). Hence, A is an Occam algorithm for C' and thus by Theorem 3.2.1, C' is polynomially learnable. 0

Example 3.2.4. Let C' = (X, U(C)), where X = E" for some fixed ~1 and C is the set of axis-parallel rectangles on E". Then C' is poly-learnable by Theorem 3.2.4 (see Examples 2.1 and 2.2).

Example 3.2.5. Let C' = (X, U(C)) and C" = (X, I(C)), where X = E" for some fixed n and C is the set of half-spaces defined by surfaces of degree at most k for some fixed k (see Example 3.1.3). Then C' and C" are poly-learnable by Theorem 3.2.4.

# 4. Summary, Open Problems, and Further Research

We have shown that the VC dimension is a useful combinatorial parameter in the context of Valiant's model of learnability by using it to give necessary and/or sufficient conditions for various types of learnability. Although we have distinguished between feasible and infeasible learning problems, we have not attempted to provide tight bounds on the number of examples and the computation time needed for various learning problems. A more relined analysis for some cases is given in [20], and in [64], where the parallel computational complexity of learning is investigated. However, considerable further research remains to be done in this area. In particular, there may be interesting general trade-offs between the sample size required for learning and the computational effort required to produce a consistent hypothesis that are yet to be discovered (see [ 121).

These issues are important if this theory of learnability is to find useful applications, for example to learning problems arising in Artificial Intelligence [26-28, 37, 56, 601. In many of the Al models of learning from examples the domain is defined by n multivalued attributes that can range from Boolean to real-valued. Attributes whose values are organized into certain types of hierarchies are also used. These domains tend to have a structure that is roughly intermediate between the Boolean domains considered in [37] and the continuous domains considered here. The techniques we have described in this paper are easily applied to these domains, and generally give better results than the simple counting argument of Theorem 2.2 [28]. More complex learning problems in which the domain consists of a set of labeled graphs representing descriptions of visual scenes and the target classes are defined by certain types of first-order formulas (e.g., Winston's "arch" concept in a blocks world domain [67]) are considered in [26] and [60]. The application of the results given here to learning methods that use connectionist or neural network representations is discussed in [7].

As for other research directions, AI applications also bring up the question of incremental learning, in which individual examples are processed one at a time and only the current hypothesis is maintained and updated [31, 421. They also bring up the issues of misclassification in the examples and the possibility of stochastically defined target concepts, discussed in Section A3 of the Appendix, and the possibility of combining random examples with other types of information, for example, the various oracles and queries discussed in [2], [3], and [59].

Another important issue is that of the representation chosen for hypotheses. In Section 3 we prove a number of results on learning algorithms that represent their hypotheses in the same form that the target concept is represented. This is line for the positive learnability results. However, for negative learnability results, one would often like something stronger, something that shows that the concept class is not polynomially learnable by any hypothesis space of the type described in Section 3.1. Using results from [24] on poly-random collections, it can be shown that there are concept classes C = (( (0, 1 I", C,,)),,, with the VC dimension of C,, growing only polynomially in n that are not polynomially learnable in this strong sense, given the existence of l-l one-way functions [53]. Given more specific cryptographic assumptions, Kearns and Valiant have shown that such "strongly

hard to learn" classes include the class of all concepts represented by Boolean formulas of size bounded by a fixed polynomial in y1 [35]. In [53] a notion of reduction among learning problems is developed that, in conjunction with the above result, implies that regular languages (represented by deterministic finite state automata) are also probably "strongly hard to learn."

Finally, we note that here we have only considered the problem of learning indicator functions of sets. Other variants of the model will be required to handle the problem of learning real-valued target functions. This problem is addressed in [ 171, [ 181, [23], [54], and [61] from a purely statistical point of view. A comprehensive overview of methods that have been proposed for generalizing the VC dimension to classes of real-valued functions are contained in [ 181. These results should be combined with considerations of computational complexity at some point, laying the groundwork for a more general computational learning tl~eory.7

We close with a few concrete open problems:

- (1) Let C = (((0, ll", G)LI, where C, is the class of concepts represented by n-term n-variable DNF expressions. Is C polynomially learnable by H for any hypothesis space H as defined in Section 3.1? This is a variant of one of the problems posed in [59].
- (2) Can we, perhaps by allowing probabilistic Occam algorithms in analclgy with the r-poly hy-E's of Section 3.1, obtain a converse of Theorem 3.2.1(i)? (I.e., does learnability with respect to target complexity imply the ability to etficiently find simple hypotheses?)
- (3) Can Theorem 3.2.4 be extended to C = (X, A(C)), where A(C) is the closure of C under finite unions, intersection and complement, and concept complexity is measured as the length of the smallest expression for c E A(C)? For example, if X = E" for some fixed n and C is the set of half-spaces, then concepts in C = (X, A(C)) can be represented as (small enough) unions of simplices, and from this is can be shown that C is poly-learnable using Theorem 3.2.4..

#### Appendix A

# A 1. Definition qf Well-Behaved Classes and t-Transversals

For Theorem 2.1 to apply, we require that the concept class C have some additional properties related to measurability, beyond the assumption that all sets in C are Borel. The properties we need are related to the following definitions, which will be used in the proof of Theorem 2. I (ii)(a) given below.

Definition. For any class of regions R c 2x, probability distribution 1' on X, and t > 0, let Rp., = {r E R : P(r) > 6 1. N L X is an c-transversal for R (with respect to P) if N contains a point in every r E Rp,, .

This definition of an E-transversal generalizes the notion of an t-net from [29] to arbitrary probability distributions. (We changed the notation here to avoid confusion with the topological notion of an t-net used in [6 1 J and elsewhere.)

Example A 1.1. If X is the interval [0, I], P is the uniform distribution and R is the set of closed intervals in X, then the set of all points ck, for natural numbers k in the range 0 I k 5 l/t, is an c-transversal for R for any t > 0. In fact, R has an c-transversal of this size for any distribution P on X. On the other hand, if R is all open sets, then clearly there are no finite c-transversals for R with respect to the uniform distribution.

<sup>&#</sup>x27;Some small progress along these lines in [28a].

We are concerned with the probability of drawing an t-transversal for a class of regions R by independently drawing random points from X. In particular, we need to measure the probabilities of the following events.

Dejinition. For any m L 1 and t > 0, Q? denotes the set of all X E X" such that the set of distinct elements of X does not form an E-transversal for R with respect to P, that is, such that there exists r E Rp,, with -- 7 rl r = 0. Jf" denotes the set of all Xy E X2m, where x, y E X", such that there exists r E Rp,,, whereZnr=0and I(i:yiEr, 1 ~i~m)l >tm/2,thatis,no element of r occurs in the first half of the sequence, but elements of r occur with frequency at least cm/2 in the second half.

In our learning application, the class of regions R will be formed by taking symmetric differences between hypotheses in a hypothesis space H C 2x and a fixed target concept c C X, that is, we have R = (hAc : h E H). Each of these regions in R represents the set of points in X that are counterexamples to a hypothesis h E H for the target concept c, that is, the error region of that hypothesis. Thus, if the sequence of points in a sample is an c-transversal of R, then the sample contains counterexamples to every hypothesis that has error greater than E.

Definition (Shai Ben-David). H is well behaved if the sets Q? and J;?" defined above are measurable for every class of regions R = (hAc: h E H) for any Bore1 set c, t > 0, m z 1 and distribution P on X.

An example of a hypothesis space H that is not well behaved is the following (see [66]). Let X be the closed interval [0, I] and let X be well-ordered such that all prefixes of the well-ordering are countable.g Let H consist of all suffixes of the wellordering, including the empty set. Note that every set in H is the complement of a countable set, hence, it is a Bore1 set. Let the target concept c be 0, so that R = H and P be the uniform distribution. It can be shown that in this case J?' is not measurable for all 0 < t < 1, even for m = 1. Hence, H is not well behaved.

This example also shows that the well-behaved condition is required for Theorem 2.1: It is readily verified that the VC dimension of H is 1, yet Theorem 2.l(ii)(a) fails for C = H. To see this, let P be the uniform distribution on X, let the target concept c be 0 as above, and consider the following learning function A: Given any finite sequence of examples (all necessarily negative), form the hypothesis consisting of the largest (by set containment) suffix in H that contains no point from the sequence of examples. Clearly, A is consistent. However, since the target concept is 0 and A's hypothesis always has measure 1, A is not a learning function for H with respect to P for any sample size. Theorem A.3 of [6 l] (described below in Proposition A3.1) also fails for this case.

On the other hand, virtually any concept class that one might consider in the context of machine-learning applications will be well behaved. Proofs of good behavior for most common concept classes can be derived by showing that they satisfy Dudley's condition of universal separability [7a, 541 (this notion is called countably S-coverable in [7a]; see the appendix of [54] for a discussion of other approaches).

Definition. A hypothesis space H C 2x is universally separable if there exists a countable subset HO of H such that each set h in H can be written as the pointwise limit of some sequence of sets in HO, that is, for all h E H there is a sequence hl,

<sup>&#</sup>x27; The existence of such a well-ordering requires the Continuum Hypothesis.

h . . . in Ho such that for every x E X, there exists y1 such that for all i L n, x2; hi if and only if x E h.

Classes of rectangles, half-spaces, etc. can easily be shown to be universally separable (see exercises 4, 5 and 7 in chapter II of [54]).

LEMMA Al. 1 (Shai Ben-David). If H is universally separable, then H is well behaved.

PROOF. Fix a Bore1 set c and let R = (hAc : h E H). It suffices to show that the sets c and Jzm are Bore1 sets. We show this for Q?, the argument for Jf" being similar.

Since H is universally separable, R is universally separable. Let T be a countable subset of R such that every set in R is the pointwise limit of a sequence of sets in T. Let yl, y2, . . . be a decreasing sequence of strictly positive real numbers converging to 0 and let cl, t2, . . . be a decreasing sequence of strictly positive real numbers converging to t. For every i, j 2 1, let

$$T_{i,j} = \{t \in T : \text{there exists } r \in R \text{ with } P(r) \ge \epsilon_i \text{ and } P(t\Delta r) \le \gamma_j \}.$$

We claim that

$$Q_{\epsilon}^{m} = \bigcup_{i=1}^{\infty} \bigcap_{j=1}^{\infty} \bigcup_{t \in T_{i,j}} \{ \bar{x} \in X^{m} : \bar{x} \cap t = \emptyset \},$$

and hence, c is a Bore1 set.

To see this, note that if X is in the right hand set above then X O t = 0 for some t E Ti,j where ti - "/j > t. For any such t we have t E R and P(t) > E. Thus X E z. On the other hand, if X E QY, then there exists i 2 1 such that X n r = 0 for some r E R with P(r) 2 ti. Since there is a sequence of sets in T that converge pointwise to r, for every j 2 1 there is a set t in T with P(tAr) 5 yj and X O t = X O r = 0. Thus, X is the right hand set above. 0

Although Lemma Al. 1 is useful in proving that most common hypothesis spaces are well behaved, it is not always sufficient. For example, if X = [0, I.] and H = 1 lx) :x E Xl, then H is well behaved but not universally separable.

We are now ready to proceed with Section A2:

# A2. Proof of Theorem 2.1 (ii)(a)

For the next two lemmas let R G 2x be a fixed nonempty class of sets and P be a distribution on X such that QT and Jz" are measurable for all m 2 1 and t > 0. The proofs of these lemmas are analogous to those of Lemma and Theorem 2 of [62]. Using Proposition A2.5, they generalize Lemmas 3.4 and 3.5 of [29] to arbitrary probability distributions.

LEMMA A2.1. For any t > 0 and m 2 2/c, Pm(Qy) < 2P2"( J,'").

PROOF. We show that P2m( Jf") > iP"'(QY). By Fubini's theorem (see, e.g., [571)

$$P^{2m}(J_{\epsilon}^{2m}) = \int_{X^{2m}} I_{J_{\epsilon}^{2m}}(x_1 \cdots x_{2m}) \ dP^{2m} = \int_{\bar{x} \in X^m} \left( \int_{\bar{y} \in X^m} I_{J_{\epsilon}^{2m}}(\bar{x}, \, \bar{y}) \ dP^m \right) dP^m$$

and this is

$$\geq \int_{\bar{x}\in Q^m_{\epsilon}} \left( \int_{\bar{y}\in X^m} I_{J^{2m}_{\epsilon}}(\bar{x}, \, \bar{y}) \, dP^m \right) dP^m,$$

since  $Q_{\epsilon}^m \subseteq X^m$ . For each  $\bar{x} \in Q_{\epsilon}^m$  let  $r_{\bar{x}}$  be a region in  $R_{P,\epsilon}$  such that  $\bar{x} \cap r = \emptyset$ . Let  $K_{\epsilon}^{2m}$  be the set of all  $\overline{xy} \in X^{2m}$ , where  $\bar{x}, \ \bar{y} \in X^m$  and  $|\{i: y_i \in r_{\bar{x}}\}| \ge \epsilon m/2$ . Obviously,  $J_{\epsilon}^{2m} \supseteq K_{\epsilon}^{2m}$  and thus

$$P^{2m}(J^{2m}_{\epsilon}) \geq \int_{\bar{x} \in O^m_{\epsilon}} \left( \int_{\bar{v} \in X^m} I_{K^{2m}_{\epsilon}}(\bar{x}, \; \bar{y}) \; dP^m \right) dP^m.$$

For each  $\bar{x} \in Q_{\epsilon}^m$ , the inner integral is just the probability that an event with probability at least  $\epsilon$  occurs with frequency at least  $\epsilon m/2$  in m independent Bernoulli trials. This probability is greater than  $\frac{1}{2}$  for any  $m \ge 2/\epsilon$ : For  $2/\epsilon \le m < 8/\epsilon$  this can be shown by a case analysis using the exact formula for the binomial distribution; for  $m \ge 8/\epsilon$ , this is easy to prove by applying Chebyshev's inequality. Hence

$$P^{2m}(J_{\epsilon}^{2m}) > \int_{\tilde{\epsilon} \in O^m} \frac{1}{2} dP^m = \frac{1}{2} P^m(Q_{\epsilon}^m).$$

LEMMA A2.2.  $P^{2m}(J_{\epsilon}^{2m}) \leq \Pi_R(2m)2^{-\epsilon m/2}$  for all  $m \geq 1$  and  $\epsilon > 0$ .

PROOF. For each j,  $1 \le j \le (2m)!$ , let  $\sigma_j$  be a distinct permutation of the indices  $1, \ldots, 2m$ . It is clear that

$$P^{2m}(J_{\epsilon}^{2m}) = \int_{X^{2m}} I_{J_{\epsilon}^{2m}}(\bar{x}) \ dP^{2m} = \int_{X^{2m}} I_{J_{\epsilon}^{2m}}(\sigma_{j}(\bar{x})) \ dP^{2m}$$

for all permutations  $\sigma_i$ . Hence

$$P^{2m}(J_{\epsilon}^{2m}) = \int_{X^{2m}} \frac{1}{(2m)!} \sum_{i=1}^{(2m)!} I_{J_{\epsilon}^{2m}}(\sigma_j(\bar{x})) \ dP^{2m}.$$

Thus, it suffices to show that

$$\frac{1}{(2m)!} \sum_{j=1}^{(2m)!} I_{J_{\epsilon}^{2m}}(\sigma_{j}(\bar{x})) \leq \Pi_{R}(2m) 2^{-\epsilon m/2},$$

for all  $\bar{x} \in X^{2m}$ .

Consider a fixed  $\bar{x} \in X^{2m}$ . Let S be the set of distinct elements of X that appear in  $\bar{x}$ . For each permutation  $\sigma_j(\bar{x})$  in  $J_{\epsilon}^{2m}$  there is a subset T of S that is a witness to the fact that  $\sigma_j(\bar{x}) \in J_{\epsilon}^{2m}$  in the sense that there exists  $r \in R_{P,\epsilon}$  such that  $T = r \cap S$ , all occurrences of members of T appear in the second half of  $\sigma_j(\bar{x})$  and there are at least  $\epsilon m/2$  such occurrences. However, for a given T, this can occur in only a small fraction of all permutations of  $\bar{x}$ . In particular, if there are l occurrences of members of T in  $\bar{x}$ , then T is a witness for at most a fraction

$$\frac{\binom{m}{l}}{\binom{2m}{l}} = \frac{m(m-1)\cdots(m-l+1)}{2m(2m-1)\cdots(2m-l+1)} \le 2^{-l} \le 2^{-\epsilon m/2}$$

of all permutations of  $\bar{x}$ . Since  $|S| \le 2m$ , there are at most  $\Pi_R(2m)$  distinct subsets T of S induced by intersections with regions  $r \in R$ , and, hence, at most  $\Pi_R(2m)$  distinct subsets induced by intersections with  $r \in R_{P,\epsilon}$ . Thus, there are at most  $\Pi_R(2m)$  distinct witnesses. It follows that

$$\frac{1}{(2m)!} \sum_{i=1}^{(2m)!} I_{J_{\epsilon}^{2m}}(\sigma_{j}(\bar{x})) \leq \Pi_{R}(2m) 2^{-\epsilon m/2}.$$

The above two lemmas can be combined to give an upper bound on the probability of not getting an  $\epsilon$ -transversal for a class R of regions in terms of the

function II,(m) (see [29]). To apply this to learning we need to use regions that form the symmetric differences between the target concept and the various possible hypotheses. The following lemma is useful.

LEMMA A2.3. For any m 2 1, c C X, and H C 2x, II,,(m) = n,(m), where R = (hAc: h E H].

PROOF. For any subset t E X, let t ' denote the complementary subset X - t. The following holds for any h, , hz E H and for any S, c C X:

$$h_1 \cap S = h_2 \cap S \Leftrightarrow h_1 \cap c' \cap S = h_2 \cap c' \cap S$$
 and  
 $h'_1 \cap c \cap S = h'_2 \cap c \cap S$   
 $\Leftrightarrow ((h'_1 \cap c) \cup (h_1 \cap c')) \cap S = ((h'_2 \cap c) \cup (h_2 \cap c')) \cap S$   
 $\Leftrightarrow (h_1 \Delta c) \cap S = (h_2 \Delta c) \cap S$ .

This implies that ] II,,(S) ] = ] II, ] and the lemma follows. 0

THEOREM A2.1. Let H he any nonempty well-behaved hypothesis space contained in 2x, P be any probability distribution on X and the target concept c be any Bore1 set contained in X. Then for any t > 0 and m 2 I, given m independent random examples of c drawn according to P, the probability that there exists a hypothesis in H that is consistent with all of these examples and has error greater than c is at most

$$2\Pi_{H}(2m)2^{-\epsilon m/2}$$
.

PROOF. Let R = (hAc: h E H). Each region in R represents the symmetric difference between the target concept c and a hypothesis h E H. A hypothesis h has error greater than t only if its symmetric difference with c has probability greater than E. Hence, if the points from the examples that are drawn form an ttransversal for R, every hypothesis in H that has error greater than E will have an example drawn from its symmetric difference with c. Since this implies -that the hypothesis is inconsistent with the example, no such hypothesis will be consistent with the entire sample. Hence, there exists a hypothesis in H that has error greater than c and is consistent with all the examples only if the points of the examples do not form an t-transversal of R.

Since H is well behaved and c is a Bore1 set, the sets Q? and J:" defined from R are measurable. If m 2 2/t, then, by Lemmas A2.1 and A2.2, the probability that the points drawn in the In random examples do not form an t-transversal for R with respect to P (i.e., the probability of QY) is less than

$$2\Pi_R(2m)2^{-\epsilon m/2}$$
.

By Lemma A2.3, nR(2m) = II,,(2m), hence, the probability of not getting an t-transversal for R is less than

$$2\Pi_H(2m)2^{-\epsilon m/2}$$
.

If I I m < 2/t, then 2II,,(2m)2-""/' > 1, and the bound holds trivially. f7

We now bound II,,(m) using the VC dimension of H.

Definition. For all d 2 0 and m 2 0, +Jrn) = cc0 (:") if m 2 d, and ad(m) = 2"', otherwise.

PROPOSITION A2.1

- (i) If the VC dimension of H is d, where d 2 0, then II,,(m) I ad(m) for all m 2 0.
- (ii) a&m) I md + 1 for all d L 0 and m 2 0. +&m) I md for all d 2 2 andm 2 2.
- (iii) @d(m) 5 2(md/d!) 5 (em/d)dfor all m 2 d > 1.

PROOF OF PART (i). A short inductive proof of part (i) above can be found in [6], along with its history of independent discoveries. We sketch the proof for completeness, using the notation from [29].

We show that for any set S with 1 S ] = m and any family F of subsets of S that has VC dimension d, ] F ] 5 +.d(m). Letting F = II,,(S) for arbitrary S C X, we obtain the result.

The assertion is trivially true for d = 0 and any m 2 0, since 1 F 1 = 1 in this case. It is also trivially true for m = 0 and any d 2 0. Assume the assertion is true for all m I 0 when F has VC dimension at most d - 1, and for m - 1 when F has VC dimension d, where d 2 1 and m 2 1.

Consider a particular set S with I S I = m and a family F of subsets of S of VC dimension d. Choose any point x E S. Let

$$F - x = \{f - \{x\} : f \in F\}$$

and

$$F^{(x)} = \{ f \in F : x \notin f, f \cup \{x\} \in F \}.$$

Note that both F - x and F(") are families of subsets of S - (xl and that 1 F 1 = 1 F - x 1 + 1 F(")I . (In mapping J to f - lx) for each f E F, pairs of the form {f; f U (xl) map to the same set. These are correctly accounted for by adding I F(")I .) Obviously F - x has VC dimension at most d; hence, by assumption, 1 F - x 1 5 +d(m - 1). We show that I;(-') has VC dimension at most d - 1 and hence, 1 F(') I 5 @'d-l (m - 1).

Let A be a subset of S - lx) that can be shattered by F(-'). Then it is easy to see that A U lx) can be shattered by F: For A ' c A there is an f E F(-') with A ' = A rlj Since x @1; A ' = (A U (xl) fl f and A ' U (x-1 = (A U {xl) fl (.fU (XT)), where bothfand f U lx) are in F. It follows that A U lx) can be shattered by F. Since the VC dimension of F is d, we must have 1 A U {xl 1 I d, so 1 A 1 I d - 1. Thus Fcx) has VC dimension at most d - 1.

It follows that 1 FI 5 @d(m - l)'+ @'d-I(m - 1). It is easily verified that +&.,(m - 1) + @(,(m - 1) = @d(m) ford, m > 1, so this completes the induction.

PROOF OF PART (ii). This part is easily verified.

PROOF OF PART (iii). The second inequality clearly holds for d = 1. To show that it holds for d I 2 we use Stirling's Approximation [38, p. 11 I]:

$$2\frac{m^d}{d!} < \frac{2m^d}{\sqrt{2\pi d}d^d e^{-d}} = \sqrt{\frac{2}{\pi d}} \left(\frac{em}{d}\right)^d < \left(\frac{em}{d}\right)^d.$$

The proof of the first inequality of Part (iii) is analogous to the proof of a similar bound given in [6 I, p. 1661 (see also [ 171). It is by induction on m and d:

If d = 1, @d(m) = m + 1 5 2m, so the result follows. If m = d > 1, @d(m) = 2". Observe that for d > 1, 2 I (1 + l/(d - l))d-' by the binomial theorem. Thus,

using induction on d we obtain

$$2^{d} \le \left(\frac{d}{d-1}\right)^{d-1} 2^{d-1}$$
 (by the above observation)  

$$\le 2\left(\frac{d}{d-1}\right)^{d-1} \frac{(d-1)^{d-1}}{(d-1)!}$$
 (by ind. hyp.)  

$$= 2\frac{d^{d}}{d!},$$

which verities the result for the case m = d > 1.

Now assume m > d > 1. Since @d(m) = iP&l(m - 1) + @d(m - l), it suffices to show that

$$2\frac{(m-1)^{d-1}}{(d-1)!} + 2\frac{(m-1)^d}{d!} \le 2\frac{m^d}{d!},$$

$$\Leftrightarrow d(m-1)^{d-1} + (m-1)^d \le m^d$$

$$\Leftrightarrow (d+m-1)(m-1)^{d-1} \le m^d$$

$$\Leftrightarrow \frac{(d+m-1)}{(m-1)} \le \frac{m^d}{(m-1)^d}$$

$$\Leftrightarrow 1 + \frac{d}{m-1} \le \left(1 + \frac{1}{m-1}\right)^d.$$

The last inequality follows from the binomial theorem. 0

From this proposition, it follows that whenever the VC dimension of H is finite, then II,f(m) grows only polynomially in m. Since the negative exponential term in the bound of Theorem A2.1 eventually dominates the polynomial IIH(Z!m), this shows that the probability that there exists a hypothesis of error greater than t that is consistent with an m-sample goes very rapidly to zero for large m. 'We now estimate the sample size m required to make this probability less than 6.

LEMMA A2.4. If

$$m \ge max \left(\frac{4}{\epsilon} log \frac{2}{\delta}, \frac{8d}{\epsilon} log \frac{13}{\epsilon}\right), \text{ then } 2\Phi_d(2m)2^{-\epsilon m/2} \le \delta.$$

PROOF. By Proposition A2.l(iii), @d(2m) I (2em/d)d, thus it suffices to show that 2(2em/d)d I 62'"/2, which is equivalent to cm/2 2 dlog(2emld) + log(2/6). The first of the two bounds on m implies cm/4 2 log(2/6). Thus, it suffices to show that tm/4 1 dlog(2emld). With q = 4d/t and t = 2e/d, this inequality is expressed as m 2 qlog(tm). If this inequality holds for some value of m, it will also hold for larger values; so suppose m is equal to the second bound in the statement of the theorem. We need to show that 2q log( 13/e) 2 q log(2qt log( 13/t)), which is equivalent to 1 32/(2qtt2) = 1 32/( 16et) 2 log( 13/t). Again, if the latter inequality holds for some value of l/c, it will also hold for larger values. The inequality is easily verified for t = 1. Cl

THEOREM A2.2. Let H be any well-behaved hypothesis space of finite VC dimension d contained in 2x, P be any probability distribution on X and the target concept c be any Bore1 set contained in X. Then for any 0 c 6, 6 < 1, given

$$m \ge max \left(\frac{4}{\epsilon} log \frac{2}{\delta}, \frac{8d}{\epsilon} log \frac{13}{\epsilon}\right)$$

independent random examples of c drawn according to P, with probability at least 1 - 6, every hypothesis in H that is consistent with all of these examples has error at most t.

PROOF. This follows directly from Theorem A2.1, Proposition A2.1, and Lemma A2.4. 0

Part (ii)(a) of Theorem 2.1 follows directly from the above theorem. Cl

Now, in order to complete the proof of Theorem 3.2.1, we close this section with the following lemma:

LEMMA A2.5

(4 Zf0<~,6< l,O~cu< l,kz 1 and

$$m = max \left(\frac{4}{\epsilon} log \frac{2}{\delta}, \left(\frac{8k}{\epsilon} log \frac{13}{\epsilon}\right)^{1/(1-\alpha)}\right),$$

then 2(2em/(km"))k"~2-'"f2 5 6.

(b) If 1 I 1 and the second term of the bound on m above is replaced by

$$\frac{2^{l+4}k}{\epsilon} \left( log \frac{8(2l+2)^{l+1}k}{\epsilon} \right)^{l+1}$$

then 2(2yn)k('o~m)'2-fm/2 5 6.

PROOF. We first prove part (a). To simplify expressions in the proof, we let q = 4k/t and t = 2e/k. Using the first bound on m as in the proof of Lemma A2.4, it suffices to show that cm/4 2 km"log2(em/(km))", that is, ml-" L qlog(tm'-\*). Again, we suppose that m is equal to its second bound, since the inequality only improves as m increases. We must show

$$2q\log\frac{13}{\epsilon} \ge q\log\left(2qt\log\frac{13}{\epsilon}\right),$$

which as in Lemma A2.4 is equivalent to 13'/( 16ec) 2 log( 13/e) and this holds for all 6 5 1.

For part (b), we let q = 4k/c as above and r'+' = 2q(21 + 2)'+'. Using the first bound on m as in the proof of Lemma A2.4, it suffices to show that m L 2q(logm)'+'. Again, we suppose that m is equal to its second bound, since the inequality only improves as m increases. We must show

$$2^{l+2}q(\log r^{l+1})^{l+1} \ge 2q[\log(2^{l+2}q(\log r^{l+1})^{l+1})]^{l+1}$$

Canceling 2q and removing the I + 1 powers gives

$$2\log r^{l+1} \ge \log(2^{l+2}q(\log r^{l+1})^{l+1}) = \log\left(2q(2l+2)^{l+1}\left(\frac{1}{l+1}\right)^{l+1}(\log r^{l+1})^{l+1}\right)$$
$$= \log\left(r^{l+1}\left(\frac{1}{l+1}\log r^{l+1}\right)^{l+1}\right) = \log r^{l+1} + \log((\log r)^{l+1}).$$

This inequality reduces to r 2 logr, which certainly holds. 0

# A3. Generalizations

A more general result than that of Theorem A2.1 above is needed if our learning model allows for the possibility of misclassification in the examples given to the

learning function. This possibility is considered in several recent papers on Valiant's learnability model [4, 34, 39, 58, 601. When misclassifications are present, it may not even be possible to find a hypothesis that is consistent with all of the examples.

This can also occur when the target concept is not in the hypothesis space used by the learning algorithm, or more generally, when the target concept itself is defined stochastically, as is a common assumption in the pattern recognition literature (e.g., [ 14, 161). Here both the distribution on the learning domain X and the target concept c C X are replaced by a single distribution on X x (0, 1) which gives the probability of drawing any given example (x, a), where x EI X and a E (0, 1). For any given x E X it is possible that both (x, 0) and (x, 1) will have positive probability, so the "target concept" will not in general be representable as a subset of the learning domain X.

The notion of a stochastic target concept can be used to model the case in which there is a (deterministic) underlying target concept and a fixed distribution on the learning domain, but the random examples received by the learning algorithm are modified by an additional random process that may change the instance points and/or their classifications, as in [4], 1391, and [58]. However, here the action of this secondary "noise" process is allowed to depend on the nature of the example it intercepts (e.g., it may be more apt to change the classification of examples that are "close to the border" of the underlying target concept). On the other hand, stochastic target concepts cannot be used to model the adversarial noise processes considered in [34], [58], and [60].

In the standard pattern recognition approach, the goal of the learning algorithm is to find a (deterministic) hypothesis that is a good appproximation to the stochastic target concept. When the stochastic element of the target concept is due .to noise, this means finding a hypothesis that will, with high probability, agree with random examples generated by the composition of two random processes: the random process generating examples of the underlying target concept and the random noise process. However, Angluin and Laird [4] have argued that in some situations where noise is present in the training examples it is more appropriate to try to find a hypothesis that is a good approximation of the underlying target concept, that is, a hypothesis that with high probability will agree with random ("noise-free") examples of the underlying target concept, as in the definition of learning we have used in previous sections of this paper. They also exhibit a simple learning situation in which these goals are incommensurate.

In this final section we give some generalizations of the results of the Iprevious section that apply when learning stochastic target concepts. Here we take the standard pattern recognition approach, showing that certain deterministic hypotheses will be good approximations to stochastic target concepts with high probability. However, the results we give are quite general, and can also be used indirectly in other approaches (see, e.g., [34, Theorem 71; generalize by replacing the Chernoff bound used with Corollary A3.1 below). The results are all relatively straightforward corollaries of a theorem of Vapnik [6 1, Theorem A.3, page 1761.

Definition. Let P be any probability distribution on X, and X = (xl, . . ,I , x,,) E X", m 2 1. For any measurable Y C X, by F<(Y) we denote the empirical estimate of P(r) based on the sample X, that is,

$$\hat{P}_{\bar{x}}(r) = \frac{|\{i: x_i \in r, \ 1 \le i \le m\}|}{m}.$$

PROPOSITION A3.1 [61]. Let R c 2x be a class of regions of X with suitable measurability properties, P be any probability distribution on X, m 1 1, 1 < q 5 2, and x > 0. If .% E X'" is chosen randomly according to P'", then the probability that there exists r E R, P(r) # 0, such that

$$\frac{P(r) - \hat{P}_{\tilde{x}}(r)}{P(r)^{1/q}} > \chi$$

is less than

$$8 \prod_{R} (2m) exp \left( \frac{-\chi^2 m^{2-2/q}}{4} \right).$$

Because the proof is lengthy, we do not sketch it here. The measurability properties required are similar to those given in our notion of well-behaved classes. We note only that it employs techniques similar to those used in [62], which form the basis of Lemmas A2.1 and A2.2 given above. A useful corollary of this result is the following:

COROLLARY A3.1. Let R, P and m be as in Proposition A3.1, and 0 < t, y 1. 1. If ,T E X" is chosen randomly according to P", then the probability that there exists a region r E R with P(r) > t such that

$$\hat{P}_{\tilde{x}}(r) \le (1 - \gamma)P(r)$$

is less than

$$8\Pi_R(2m)exp\bigg(\frac{-\gamma^2\epsilon m}{4}\bigg).$$

PROOF. I (1 - r>P(rh when P(r) > >et q = 2 and x = r&. Note that x > 0. For any r ER, if&(r) % then P(r) - pi(r) 2 yP(r), hence, (P(r) - &(r))/JP(r) 2 rm 0. If P(r) > t, then rm > y& = x. Hence, by Proposition A3.1, the prodability that there exists r E R such that P(r) > E and &r) 5 (1 - r)P(r) is at most

$$8\Pi_R(2m)\exp\left(\frac{-\chi^2m^{2-2/q}}{4}\right),$$

which is

$$8\Pi_R(2m)\exp\left(\frac{-\gamma^2\epsilon m}{4}\right).$$

This result generalizes one of the Chernoff bounds that is frequently used in papers on learnability in discrete domains [4, 5, 34, 36, 39, 52, 601. Also note that in terms of c-transversals, letting y = i it shows that the probability of not getting in m random draws an c-transversal in which each region r of R with P(r) 2 E is hit with frequency at least P(r)/2 is at most 811R(2m)exp(-tm/l6). Using Proposition A2.l(i), this is comparable to the bound given in [26, Theorem 3.61 on the probability of getting any t-transversal.

We can adapt Corollary A3.1 for application to the problem of learning stochastic target functions as follows:

Definition. Let X be a learning domain and H G 2x be a hypothesis space. As usual we assume that each h E H is a Bore1 set. Let Y = X x (0, 11 and P be a

distribution on Y. We denote by disagree(h) the set of all points in Y that disagree with h, that is, disagree(h) = ((x, a) E Y: x E h and a = 0 or x \$J h and a = 11. The error of h (with respect to P), denoted er(h), is P(disugree(h)). IFor any J E Y" we denote by eFj(h) the empirical estimate of er(h) based on j, that is, eFj(h) = Pj(disugree(h)).

In analogy to Theorem A2.1 above, we have

THEOREM A3.1. Let H, P, and Y be us above, where H has suitable measurability properties, m 2 1 and 0 < t, y 5 1.

(i) Zfp E Y" i s c h osen randomly according to P", then the probability that there exists a hypothesis h E H with er(h) > E such that

$$e\hat{r}_{\bar{y}}(h) \le (1 - \gamma)er(h)$$

is less than

$$8\Pi_{H}(2m)exp\left(\frac{-\gamma^{2}\epsilon m}{4}\right). \tag{*}$$

(ii) If the VC dimension of H is d, then for any 0 < 6 < 1, the quantity (\*) is at most 6 for any sample size m greater than

$$max\left(\frac{8}{\gamma^2\epsilon}ln\frac{8}{\delta}, \frac{16d}{\gamma^2\epsilon}ln\frac{16}{\gamma^2\epsilon}\right).$$

PROOF. For part (i), let R = (disagree(h): h E HJ. We claim that II,(m) = II,(m) for all m L 1. The argument is similar to that used in the proof of Lemma A2.3. Choose any S c Y with 1 S 1 = m. Let T = (x E X:(x, a) E S for some a E (0, 11). Since II,(S) is maximal when 1 T 1 = m, we assume this is the case. It is clear that for any h,, h2 E H, hl n T = h2 fr T if and only if disugree(h, ) n S = disugree(h\*) n S. From this it follows that II,(m) = II,(m). The result then follows directly from Corollary A3.1.

The calculation of the bound in part (ii) is similar to the calculation in Lemma A2.4, using Proposition A2.l(i) and (iii). 0

Letting y = t, the above result shows that if a learning algorithm takes a :random sample J of size

$$\max\left(\frac{32}{\epsilon}\ln\frac{8}{\delta}, \frac{64d}{\epsilon}\ln\frac{64}{\epsilon}\right)$$

and only entertains hypotheses h E H with empirical error e\$(h) 5 t/2, then the probability that it returns a hypothesis h with actual error er(h) more than c is at most 6. This is true for any stochastic target concept. By letting y = 1 and res,tricting ourselves to deterministic target concepts chosen from H, we can use Theorem A3.1 to show that any consistent function A: SH + H is a learning function for H using sample size

$$\max\left(\frac{8}{\epsilon}\ln\frac{8}{\delta}, \frac{16d}{\epsilon}\ln\frac{16}{\epsilon}\right).$$

Thus, Theorem 2.1 (ii)(a) is almost a special case of Theorem A3.1, but for the fact that its simpler proof yields slightly better constants.

ACKNOWLEDGMENTS. We thank Shai Ben-David for pointing out an error in our original definition of well-behaved classes and in Lemma A 1.1, and for suggesting the versions used here. We would like to thank Emo Welzl for many helpful discussions and ideas on c-transversals and classes of finite VC dimension, and for pointing out [6] to us. The bound on the VC dimension of s-gons given in Example 3.2.2 is also due to him. Thanks to Leen Stougie for making us aware of [61] and to Nick Littlestone for numerous important observations, especially regarding r-poly hy-fi's and Theorem 3.1.1. Les Valiant, Dana Angluin, Lenny Pitt, Jan Mycielski, John Cherniavsky, Janet Blumer, Herbert Edelsbrunner, and Sally Floyd also provided valuable suggestions at various stages of this investigation.

### REFERENCES

- 1. AHO, A., HOPCROF-~, J., AND ULLMAN, J. The Design and Analysis of Computer Algorithms. Addison-Wesley, London, 1914.
- 2. ANGLUIN, D. Learning regular sets from queries and counterexamples. Inf Compul. 75 (1987), 87-106.
- 3. ANGLUIN, D. Queries and concept learning. Mach. Learning 2,2 ( 1988), 3 19-342.
- 4. ANGLUIN, D., AND LAIRD, P. D. Learning from noisy examples. Mach. Learning 2, 2 (1988), 343-370.
- 5. ANGLUIN, D., AND VALIANT, L. Fast probabilistic algorithms for Hamiltonian circuits and matchings. J. Comput. Syst. Sci. 19 (1979), 155-193.
- 6. ASSOUAD, P. DensitC et Dimension. Ann. Inst. Fourier, Grenoble 33, 3 (1983), 233-282.
- 7. BAUM, E., AND HAUSSLER, D. What size net gives valid generalization. Neural Comput. I, 1 (I 989) 151-160.
- 7a. BEN-DAVID, S., BENEDEK, G., AND MANSOUR, Y. A parameterization scheme for classifying models of learnability. In Proceedings of the 2nd Workshop of Computational Learning Theory (Santa Cruz, Calif., July 3 I-Aug. 2). Morgan Kaufman, San Mateo, Calif., 1989, to appear.
- 8. BENEDEK, G., AND ITAI, A. Nonuniform learnability. In Proceedings of the 15th International Confirence on Automata, Languages and Programming (July). 1988, pp. 82-92.
- 9. BLUM, A., AND RIVEST, R. Training a 3-node neural network is NP-complete. In Proceedings of the 1st Workshop on Computational Learning Theory (Cambridge, Mass., Aug. 3-5). Morgan Kaufmann, San Mateo, Calif., 1988, pp.9-18.
- 10. BLUMER, A., EHRENFEUCHT, A., HAUSSLER, D., AND WARMUTH, M. K. Occam's Razor. Inf Process. Lett. 24 (1987), 377-380.
- I I. BOLLOB& B. Combinatorics. Cambridge Univ. Press, Cambridge, Mass., 1986.
- 12. BOUCHERON, S., AND SALLANTIN, J. Some remarks about space-complexity of learning and circuit complexity of recognizing. In Proceedings of the 1st Workshop on Computational Learning Theory (Cambridge, Mass., Aug. 3-5). Morgan Kaufmann, San Mateo, Calif., 1988, pp. l25- 138.
- 13. COVER, T. Geometrical and statistical properties of systems of linear inequalities with applications to pattern recognition. IEEE Trans. Elect. Comp. 14 (1965), 326-334.
- 14. DEVROYE, L. P. Automatic pattern recognition: A study of the probability of error. IEEE Trans. Pattern Analysis and Mach. Intell. 10, 4 (1988), 530-543.
- 15. DEVROYE, L. P., AND WAGNER, T. J. A distribution-free performance bound in error estimation. IEEE Trans. Inx Theorem 22 (1976), 586-587.
- 16. DUDA, R., AND HART, P. Pattern Classification and Scene Analysis. Wiley, New York, 1973.
- 17. DUDLEY, R. M. A course on empirical processes. In Lecture Notes in Mathematics, vol. 1097. Springer-Verlag, New York, 1984.
- 18. DUDLEY, R. M. Universal Donsker classes and metric entropy. Ann. Prob. 15, 4 (1987), 1306-1326.
- 19. EDELSBRUNNER, H., AND PREPARATA, F. P. Minimal polygonal separation. Inj Comput. 77 (1988), 218-232.
- 20. EHRENFEUCHT, A., HAUSSLER, D., KEARNS, M., AND VALIANT, L. G. A general lower bound on the number of examples needed for learning. In: Comput., to appear.
- 21. GAREY, M., AND JOHNSON, D. Computers and Intractability: A Guide to the Theory of NP-Completeness. W. H. Freeman, San Francisco, 1979.
- 22. GILL, J. Probabilistic Turing machines. SIAM J. Comput. 6, 4 (1977), 675-695.
- 23. GINS, E., AND ZINN, J. Lectures on the central limit theorem for empirical processes. In Lecture Notes in Mathematics, vol. 122 1. Springer-Verlag, New York, 1986.
- 24. GOLDREICH, O., GOLDWASSER, S., AND MICALI, S. How to construct random functions. J. ACM 33,4 (Oct. 1986), 792-807.
- 25. HAMPSON, S. E., AND VOLPER, D. Linear Function neurons: Structure and training. Biol. Cyber. 53 ( 1986), 203-2 17.

26. HAUSSLER, D. Learning conjunctive concepts in structural domains. Much. Learning 4', 1 (1989)

- 27. HAUSSLER, D. Applying Valiant's learning framework to AI concept learning problems. In Proceedings of the 4th International Workshop on Machine Learning. Morgan Kaufmann, San Mateo, Calif., 1987, pp. 324-336.
- 28. HAUSSLER, D. Quantifying inductive bias: AI learning algorithms and Valiant's learning framework. Art/y Intell. 36 (1988), 177-22 1.
- 28a. HAUSSLER, D. Generalizing the PAC model: Sample size bounds from metric dimension-based uniform convergence results. In Proceedings of the 30th IEEE Symposium on Foundations of Computer Science (Research Triangle Park, N.C., Oct. 30-Nov. 1). IEEE, New York:, 1989, to appear.
- 29. HAUSSLER, D., AND WELZL, E. Epsilon-nets and simplex range queries. Disc. Comput. Geometry 2(1987), 127-151.
- 30. HAUSSLER, D., KEARNS, M., LITTLESTONE, N., AND WARMUTH, M. K. Equivalence of models for polynomial learnability. Tech. Rep. UCSC-CRL-88-06. Univ. California at Santa Cruz, S,anta Cruz, Calif., 1988.
- 3 I. HAUSSLER, D., LITTLESTONE, N., AND WARMUTH, M. K. Predicting (0, 1)-functions on randomly drawn points. In Proceedings of the 29th IEEE Symposium on Foundations of Computer Science (White Plains, N.Y., Oct.). IEEE, New York, 1988, pp. 100-109.
- 32. JOHNSON, D. S. Approximation algorithms for combinatorial problems. .I. Cornput. Syst. Sci. 9 (1974), 256-278.
- 33. KARMARKAR, N. A new polynomial-time algorithm for linear programming. Combr'natoricu 4 (1984), 373-395.
- 34. KEARNS, M., AND LI, M. Learning in the presence of malicious errors. In Proceedings of the 20th Symposium on Theory of Computing (Chicago, Ill., May 2-4). ACM, New York, 1988, pp. 267-280.
- 35. KEARNS, M., AND VALIANT, L. Cryptographic limitations on learning Boolean formulae and finite automata. In Proceedings of the 21st ACM Symposium on Theory qf Computing (Seattle, Wash., May 15-17). ACM, New York, 1989, pp. 433-444.
- 36. KEARNS, M., LI, M., PITT, L., AND VALIANT, L. On the learnability of Boolean formulae. In Proceedings of the 19th ACM Symposium on Theory of Computation (New York, N.Y., May 25-27). ACM, New York, 1987, pp. 285-295.
- 37. KEARNS, M., LI, M., PITT, L., AND VALIANT, L. Recent results on Boolean concept learning. In Proceedings of the 4th International Workshop on Machine Learning. Morgan-Kaufmann, San Mateo, Calif., 1987, pp. 337-352.
- 38. KNUTH, D. E. The Art of Computer Programming, 2nd ed., vol. 1. Addison-Wesley, Reading, Mass., 1973.
- 39. LAIRD, P. D. Learning from good data and bad. Tech. Rep. YALEU/DCS/TR-55 1. Yale Univ., New Haven, Conn., 1987.
- 40. LEE, D. T., AND PREPARATA, F. P. Computational geometry-A survey. IEEE Trun.;. Comput. 33, 12 (1984), 1072-l 101.
- 41. LINIAL, N., MANSOUR, Y., AND RIVEST, R. Results on learnability and the Vapnik-Chcrvonenkis dimension. In Proceedings of the 29th IEEE Symposium on Foundations of Compuier Science (White Plains, N.Y., Oct.). IEEE, New York, 1988, pp. 120-129.
- 42. LITTLESTONE, N. Learning quickly when irrelevant attributes abound: A new linear-threshold algorithm. Mach. Learning 2, 2 (1988), 285-3 18.
- 43. MASEK, W. J. Some NP-complete set cover problems. MIT Laboratory for Computer Science, unpublished manuscript.
- 44. MEGIDDO, N. Linear programming in linear time when the dimension is fixed. J. ACM 31, 1 (Jan. 1984), 114-127.
- 45. MEGIDDO, N. On the complexity of polyhedral separability. Discrete Comput. Geometry 3 (198X), 325-337.
- 46. MUROGA, S. Threshold Logic and Its Applications. Wiley, New York, I97 I.
- 47. NATARAJAN, B. K. On learning Boolean functions. In Proceedings of the 19th Annual ACM Symposium on Theory of Computation (New York, N.Y., May 25-27). ACM, New York, 1987, pp. 296-304.
- 4X. NATARAJAN, B. K. Learning functions from examples. Tech. Rep. CMU-RI-TR-87-19. Carnegie Mellon Univ., Pittsburgh, Pa., Aug. 1987.
- 49. NIGMATULLIN, R. G. The fastest descent method for covering problems (in Russian). In Proceedings qf a Symposium on Questions of Precision and Efficiency of Computer Algorithms, Book 5. Kiev, 1969, pp. 116-126.

- 50. PEARL, J. On the connection between the complexity and credibility of inferred models. Int. J. Gen. Syst. 4 (1978), 255-264.
- 5 I. PEARL, J. Capacity and error estimates for Boolean classifiers with limited capacity. IEEE Trans. Pattern Analysis Mach. Intell. I, 4 (1979), 350-355.
- 52. PITT, L., AND VALIANT, L. G. Computational limitations on learning from examples. J. ACM 35, 4 (Oct. 1988), 965-984.
- 53. PITT, L., AND WARMUTH, M. Reductions among prediction problems, on the difficulty of predicting automata. In Proceedings of the 3rd IEEE Structure in Complexity Theory Conference (Washington, D.C.). IEEE, New York, 1988, pp. 62-69.
- 54. POLLARD, D. Convergence ofStochastic Processes. Springer-Verlag, New York, 1984.
- 55. QUINLAN, R., AND RIVEST, R. Inferring decision trees using the minimum description length principle. InJ Cornput., to appear.
- 56. RIVEST, R. Learning decision-lists. Mach. Learning 2, 3 (1987), 229-246.
- 57. ROYDEN, H. L. Real Analysis, 2nd ed. MacMillan, New York, 1968.
- 58. SLOAN, R. Types of noise in data for concept learning. In Proceedings of'the 1st Workshop on Computational Learning Theory (Cambridge, Mass., Aug. 3-5). Morgan Kaufmann, San Mateo, Calif., 1988, pp. 91-96.
- 59. VALIANT, L. G. A theory of the learnable. Commun. ACM 27, 11 (Nov. 1984), 1134-I 142.
- 60. VALIANT, L. G. Learning disjunctions of conjunctions. In Proceedings of the 9th International Confirence on ArtiJicial Intelligence (Los Angeles, Calif., Aug.), vol. 1. Morgan Kaufmann, San Mateo, Calif., 1985, pp. 560-566.
- 6 I. VAPNIK, V. N. Estimation oj'Dependences Based on Empirical Data. Springer Verlag, New York, 1982.
- 62. VAPNIK, V. N., AND CHERVONENKIS, A. YA. On the uniform convergence of relative frequencies of events to their probabilities. Theoret. Probl. and Its Appl. 16, 2 (I 97 1), 264-280.
- 63. VAPNIK, V. N., AND CHERVONENKIS, A. YA. Theory of Pattern Recognition (in Russian). Nauka, Moscow, 1974.
- 64. VITTER, J., AND LIN, J. H. Learning in parallel. In Proceedings of the 1st Workshop on Computational Leurning Theory (Cambridge, Mass., Aug. 3-5). Morgan Kaufmann, San Mateo, Calif., 1988, pp. 106-124.
- 65. WATANABE, S. Pattern recognition as information compression. In Frontiers of Pattern Recognition, S. Watanabe, Ed. Academic Press, Orlando, Fla., 1972.
- 66. WENOCUR, R. S., AND DUDLEY, R. M. Some special Vapnik-Chervonenkis classes. DiscreteMath. 33 (1981), 313-318.
- 67. WINSTON, P. Learning structural descriptions from examples. In The Psychology of Computer Vision. McGraw-Hill, New York, 1975.

RECEIVED MARCH 1986; REVISED NOVEMBER 1987 AND OCTOBER 1988; ACCEPTED NOVEMBER 1988