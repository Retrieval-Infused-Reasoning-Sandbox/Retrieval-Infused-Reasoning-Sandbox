# Linear Hashing with $\ell_{\infty}$ guarantees and two-sided Kakeya bounds

Manik Dhar
Department of Computer Science
Princeton University
Princeton, USA
manikd@princeton.edu

Zeev Dvir

Department of Computer Science and Department of Mathematics

Princeton University

Princeton, USA

zdvir@princeton.edu

Abstract—We show that a randomly chosen linear map over a finite field gives a good hash function in the  $\ell_\infty$  sense. More concretely, consider a set  $S \subset \mathbb{F}_q^n$  and a randomly chosen linear  $\operatorname{map} L: \mathbb{F}_q^n \to \mathbb{F}_q^t \text{ with } q^t \text{ taken to be sufficiently smaller than}$ |S|. Let  $U_S$  denote a random variable distributed uniformly on S. Our main theorem shows that, with high probability over the choice of L, the random variable  $L(U_S)$  is close to uniform in the  $\ell_{\infty}$  norm. In other words, every element in the range has about the same number of elements in S mapped to it. This complements the widely-used Leftover Hash Lemma (LHL) which proves the analog statement under the statistical, or  $\ell_1$ , distance (for a richer class of functions) as well as prior work on the expected largest 'bucket size' in linear hash functions [1]. By known bounds from the load balancing literature [2], our results are tight and show that linear functions hash as well as truly random function up to a constant factor in the entropy loss. Our proof leverages a connection between linear hashing and the finite field Kakeya problem and extends some of the tools developed in this area, in particular the polynomial method.

Index Terms—Kakeya, Polynomial Method, Hashing, Leftover Hash Lemma

## I. INTRODUCTION

Let  $S \subset \{0,1\}^n$  be a set. In many scenarios, one is interested in 'hashing' the space  $\{0,1\}^n$  into a smaller space so that the set S (on which we may have little or no information) is mapped in a way that is close to uniform. Specifically, we may need to find a function  $H:\{0,1\}^n \to \{0,1\}^t$  so that the random variable  $H(U_S)$  is close to the uniform distribution, where  $U_S$  denotes a random variable distributed uniformly on the set S. An important parameter here is the 'entropy-loss' given by  $\log_2 |S| - t$ . Clearly, this quantity has to be non negative, and, in practice, we would like it to be as small as possible.

An important result in this area is the celebrated Leftover Hash Lemma (LHL) of Impagliazzo, Levin and Luby [3] which asserts that, the above scenario can be handled by choosing H at random from a family of universal hash functions (one in which for every  $x \neq y$  the probability that H(x) = H(y) is at most  $2^{-t}$  over the choice of H).

**Lemma I.1** (Leftover Hash Lemma [3]). Let  $S \subset \{0,1\}^n$  and suppose  $H: \{0,1\}^n \to \{0,1\}^t$  is chosen from a family

Research supported by NSF grant DMS-1953807. Full paper link: https://arxiv.org/abs/2204.01665

of universal hash functions with  $t \leq \log_2 |S| - 2\log_2(1/\epsilon)$ . Then the random variable  $(H, H(U_S))$  is  $\epsilon$ -close to uniform in the  $\ell_1$ -norm.

A few comments about the LHL are in order. The first is that, using a standard averaging argument, the LHL implies that, for any given set, most choices of H will be good, in the sense that  $H(U_S)$  will be close to uniform in the  $\ell_1$  distance. It is also known that the *entropy loss* of the LHL, namely  $2\log(1/\epsilon)$ , is the smallest possible for any family of functions [4]. Lastly, it is possible to generalize the LHL to handle arbitrary distributions of high min-entropy<sup>3</sup> (not just those uniform on a set). This follows from the fact that any distribution with min-entropy k is a convex combination of 'flat' distributions (those uniform on a set of size  $2^k$ ).

A convenient choice of a universal family of hash functions is that given by all linear maps over the finite field of two elements  $\mathbb{F}_2$ . That is, the LHL says that, if one picks a linear map  $L:\mathbb{F}_2^n\to\mathbb{F}_2^t$  uniformly at random, then, w.h.p over the choice of L, the random variable  $L(U_S)$  will be close to uniform in the  $\ell_1$ -distance. Our main theorem shows that, with slightly larger entropy loss, one can give a stronger guarantee on the output, stated in  $\ell_\infty$  distance to uniform. A reason to consider linear maps is their simplicity and ease of implementation (only requiring very basic bit operations) for applications. Since the full statement of the theorem is quite technical (stemming from our attempts to optimize the various constants) we start by giving an informal statement. The full statements of our results (also for other larger finite fields) are given in Section II.

**Theorem I.2** (Main theorem (informal)). Let  $S \subset \mathbb{F}_2^n$  and let  $t = \log_2 |S| - O(\log_2(\log_2 |S|/\tau\delta))$ . Then, a  $1 - \delta$  fraction of all linear maps  $L : \mathbb{F}_2^n \to \mathbb{F}_2^t$  are such that  $L(U_S)$  is  $\tau 2^{-t}$ -close to uniform in the  $\ell_\infty$  norm. That is, for all  $y \in \mathbb{F}_2^t$  we

 $<sup>^{1}</sup>$ In the notation  $(H,H(U_{S})$  we assume that the function H is represented by a string of bits of some fixed length.

<sup>&</sup>lt;sup>2</sup>Typically, the conclusion of the lemma is stated with respect to the statistical distance (or total variation distance) which is defined to be 1/2 of the  $\ell_1$  distance

 $<sup>^3</sup>$ A distribution has min-entropy at least k if any output has probability at most  $2^{-k}$ .

have

$$|\mathbf{Pr}[L(U_S) = y] - 2^{-t}| \le \tau 2^{-t}.$$

An equivalent way to state this theorem comes from the observation that the set of elements in  $\mathbb{F}_2^n$  mapping to a particular  $y \in \mathbb{F}_2^t$  is always of the form  $a_y + U$ , where U is the kernel of the mapping L and  $a_y \in \mathbb{F}_2^n$  is some shift. In this view, the theorem says that most (n-t)-dimensional subspaces  $U \subset \mathbb{F}_2^n$  are such that all of their shifts intersect S in about the same number of points (up to a multiplicative factor of  $1+\tau$ ). We devote Section III to a more detailed treatment of this view, which will be the one used in the proof. The question of bounding the maximal 'bucket size' (all elements mapping to a single  $y \in \mathbb{F}_2^t$ ) in a random linear hash function was previously studied and we compare our results to the state-of-the-art in this area ([1]) in Section II after the formal statement of our results.

Our choice of the letter  $\tau$  instead of  $\epsilon$  as in the LHL is not accidental and is meant to highlight the fact that, in the  $\ell_{\infty}$  setting, we can take au to be greater than 1. When au < 1the conclusion of our theorem, namely that  $L(U_S)$  is  $\tau/2^{-t}$ close to uniform in  $\ell_{\infty}$ , implies that  $L(U_S)$  is also  $\tau$ -close to uniform in  $\ell_1$ . However, our theorem is still meaningful when  $\tau > 1$ , even though it says nothing about  $\ell_1$  distance. The advantage of taking  $\tau$  to be large comes from the fact that it can reduce our entropy loss (this can be done up to a point, as is stated in the formal theorem statement below). To give an example of a scenario in which we can take large  $\tau$ consider the case where the linear map L is used to derive a key for a digital signature scheme. We would like the key  $L(U_S)$  to be close to uniform since we know that a uniform key prevents the adversary from producing a forgery with more than negligible probability. However, if we apply our theorem with large  $\tau$  (say polynomial in n) we get that the probability of producing a forgery may increase by at most a factor of  $1+\tau$ which still results in negligible probability of forgery. More generally, the case of large  $\tau$  is relevant whenever we only care about events of small probability staying small. Another paper which focuses on these aspects of the LHL (that is, when we only care about low probability events) is [5].

The need for  $\ell_{\infty}$  guarantees for hashing appears in many places in the literature. For example, in Cryptography, in the context of key generation for local data storage [6] and batch verifying zero-knowledge proofs [7] and in Computational in the context of uniformly generating a solution to NP-search problems (see Section 6.2.4.2 in [8]). It is possible to guarantee  $\ell_{\infty}$  hashing by using a larger and more complex classes of functions, for example high degree polynomials over a large finite field [9]. For the applications in [6] and [8] our results allows one to use linear maps instead of polynomials, hence simplifying the proofs.

Our proofs leverage a connection between linear hashing and finite field Furstenberg sets (which generalize Kakeya sets). A k-dimensional Furstenberg set  $S \subset \mathbb{F}_q^n$  is a set which has a large intersection with a k-flat (k-dimensional affine subspaces) in each direction. That is, for any k-dimensional

subspace  $U\subset \mathbb{F}_q^n$  there is a shift s(U) such that the affine subspace s(U) + U has a large intersection with the set S. The goal in this area is to prove lower bounds on the size of such sets. Surprisingly, such lower bounds play a role in explicit constructions of seeded extractors [10], [11] which are randomness efficient variants of the LHL. However, the connection between Furstenberg sets and linear hashing we leverage in this paper is unrelated to the work on extractors mentioned above and is of a completely different nature. This connection was first observed in [12] and was used there to improve the best lower bounds on Furstenberg sets. Our work relies heavily on the methods developed in [12] (as well as other papers) and extends them in several respects. We devote Section III to a more complete discussion of this connection and, in particular, to explaining the phrase 'two-sided Kakeya bounds' from the title of the paper.

- a) Acknowledgments:: We are grateful to Or Ordentlich, Oded Regev and Barak Weiss for comments that led us to pursue this line of work. Their interest in theorems of this kind arose from trying to strengthen their breakthrough [13] on lattice coverings, which uses the two dimensional Kakeya bounds of [14]. (A new paper by the same group of authors, using the results of the current paper, is in preparation).
- b) Paper organization:: The rest of the paper is organized as follows. In Section II we state our main theorems formally. In Section II-A we discuss the tightness of our results, compare them to prior work, and discuss possible generalizations. In Section III we discuss the connection to the theory of Furstenberg/Kakeya sets and introduce notations and definitions that will be used in the proofs. In Section IV we give a high level overview of the proof. Section V contains the proofs of our main theorems with a lemma, giving an improved bound on Furstenberg sets, proved in the full paper.

# II. FORMAL STATEMENT OF OUR RESULTS

This section contains four variants of our main result. The four cases correspond to the distinction between large finite fields and  $\mathbb{F}_2$  and between arbitrary  $\tau$  and the special case  $\tau>1$  (in which we can get slightly better constants). We begin with the statement for large finite field and arbitrary  $\tau$ .

**Theorem II.1.** Let  $n \geq 5$  and let  $S \subset \mathbb{F}_q^n$  be a set. Let  $\tau > 0$  be a real number and  $\delta \in (0,1)$  s.t

$$q \ge 32 \max\left(\frac{n(1+\tau)}{(\tau\delta)^2}, n\right).$$

Suppose  $q^r < |S| \le q^{r+1}$  for some  $4 \le r \le n-1$  and let t = r-3. Then a  $1-\delta$  fraction of all surjective linear maps  $L: \mathbb{F}_q^n \to \mathbb{F}_q^t$  are such that  $L(U_S)$  is  $\tau/q^t$ -close to the uniform distribution in the  $\ell_\infty$  norm.

Notice that, in the setting above, the entropy loss, when measured in  $\mathbb{F}_q$ -dimension is at most 4. The restriction to the case of surjective linear maps is natural as these are maps that do not 'lose' entropy unnecessarily (one can consider all linear maps by increasing  $\delta$  slightly).

The above theorem can be used to derive similar results for small fields, by treating blocks of coordinates as representing elements in an extensions field. We do this for every possible choice of basis to ensure that our theorem works for all surjective  $\mathbb{F}_2$ -linear maps. We only treat the case of  $\mathbb{F}_2$  as this is the field most commonly used in applications (the same proof strategy will work for any finite field).

**Theorem II.2.** Let  $S \subset \mathbb{F}_2^n$  be such that  $|S| > 2^{20} \max(n^4(1+\tau)^4/(\tau\delta)^8, n^4)$  and let  $n, \tau, \delta$  satisfy  $n \geq 5\lceil \log_2(\max(n(1+\tau)/(\tau\delta)^2, n)) \rceil + 25$ . Then there exists a natural number

$$t \ge \log_2 |S| - 4\log_2 \left( \max\left(\frac{n(1+\tau)}{(\tau\delta)^2}, n\right) \right) - 20,$$

such that a  $1-\delta$  fraction of all surjective linear maps  $L: \mathbb{F}_2^n \to \mathbb{F}_2^t$  are such that  $L(U_S)$  is  $\tau 2^{-t}$ -close to uniform in the  $\ell_{\infty}$  norm.

When |S| is small we can improve the previous theorem by replacing the n in the entropy loss by  $\log_2 |S|$ . This is achieved using the following simple lemma, which allows us to first hash S into a universe of size roughly  $|S|^2$  without any collisions.

**Lemma II.3.** Let  $S \subset \mathbb{F}_2^n$  and

$$t \ge \log_2(|S|(|S|-1)/2\delta).$$

Then, at least a  $1 - \delta$  fraction of all surjective linear maps  $L : \mathbb{F}_2^n \to \mathbb{F}_2^t$  map S injectively into  $\mathbb{F}_2^t$ .

*Proof.* As surjective linear maps are a universal family of hash functions we have,

$$\Pr[L(x) = L(y)] \le 1/2^t \le \delta \frac{2}{|S|(|S| - 1)}$$

for a random surjective linear map  $L: \mathbb{F}_2^n \to \mathbb{F}_2^t$  and  $x, y \in S, x \neq y$ . By applying the union bound we see the probability that L is not injective is upper bounded by  $\delta$ .

Applying the above lemma followed by Theorem II.2 immediately leads to a concrete instance of Theorem I.2.

**Theorem II.4.** Let  $S \subset \mathbb{F}_2^n, \tau, \delta \in (0,1)$  and  $m = \log_2(|S|(|S|-1)/\delta)$  be such that

$$|S| > 2^{20} m \max(2^8 (1+\tau)^4/(\tau \delta)^8, 1)$$
 (1)

$$m \ge 5\log_2(m\max(4(1+\tau)/(\tau\delta)^2, 1)) + 25,$$
 (2)

then there exists a natural number

$$t \geq \log_2 |S| - 4\log_2 \left( m \max\left(\frac{4(1+\tau)}{(\tau\delta)^2}, 1\right) \right) - 20,$$

such that a  $1-\delta$  fraction of all surjective linear maps  $L: \mathbb{F}_2^n \to \mathbb{F}_2^t$  are such that  $L(U_S)$  is  $\tau 2^{-t}$ -close to uniform in the  $\ell_{\infty}$  norm.

*Proof.* We apply Lemma II.3 for  $\delta/2$  and linear maps from  $\mathbb{F}_2^n \to \mathbb{F}_2^m$  followed by applying Theorem II.2 for  $\delta/2$  and linear maps from  $\mathbb{F}_2^m \to \mathbb{F}_2^t$ .

The conditions (1) and (2) are not very restrictive. In the setting  $\tau = \delta = 1/n^C$  for some constant C conditions (1) and (2) are satisfied for  $|S| \ge n^{C'}$  where C' only depends on C.

An interesting setting of parameters for Theorem II.4 is that of  $\tau=1/\delta^2$ . In this case (when  $\delta$  is sufficiently small), the two terms in the 'max' function above are about the same and we get an entropy loss of  $4\log_2(4\log_2(|S|(|S|-1)/\delta))$ . With this entropy loss, we get that the output  $L(U_S)$  is  $(1/\delta)^2 \cdot 2^{-t}$  close to uniform in the  $\ell_\infty$  norm. Or, in other words, for  $1-\delta$  fraction of linear maps L, the probability of any event under  $L(U_S)$  is at most a multiplicative factor of  $1/\delta^2$  larger than its probability under the uniform distribution. In this setting (1) and (2) are satisfied by ensuring |S| is larger than some fixed universal constant.

When  $\tau>1$  we can improve the constant in the above two theorems slightly. We start with the case of large finite field. In the following theorem, the bound on the size of q does not contain the constant 32 appearing in Theorem II.1. The dependence of q on  $\tau$  changes from  $\frac{1+\tau}{\tau^2}$  to  $\frac{1+\tau}{(\tau-\sqrt{\tau})^2}$  which are asymptotically the same when  $\tau$  grows. Hence, when  $\tau$  is sufficiently large, the saving in q is roughly a factor of 32. The price we pay for this improvement is the need for n to be at least 20 (as opposed to 5) and an upper bound  $\delta<1/10$ .

**Theorem II.5.** Let  $n \ge 20$  and let  $S \subset \mathbb{F}_q^n$  be a set. Let  $\tau > 1$  be a real number and  $\delta \in (0, 1/10)$  s.t

$$q \ge \max\left(n\frac{1+\tau}{(\tau-\sqrt{\tau})^2\delta^2}, n\right).$$

Suppose  $q^r < |S| \le q^{r+1}$  for some  $4 \le r \le n-1$  and let t = r-3. Then a  $1-\delta$  fraction of all surjective linear maps  $L: \mathbb{F}_q^n \to \mathbb{F}_q^t$  are such that  $L(U_S)$  is  $\tau/q^t$ -close to the uniform distribution in the  $\ell_{\infty}$  norm.

As before, this can be used to prove a version over  $\mathbb{F}_2$  for large  $\tau$  with improved constants.

**Theorem II.6.** Let  $S \subset \mathbb{F}_2^n$  and let  $\delta \leq 1/10$ ,  $\tau > 1$  be such that  $|S| > \max(n^4(1+\tau)^4/((\tau-\sqrt{\tau})\delta)^8, n^4)$  and  $n, \tau, \delta$  satisfy  $n \geq 20\lceil \log_2(\max(n(1+\tau)/((\tau-\sqrt{\tau})\delta)^2, n)) \rceil$ . Then there exists a natural number

$$t \geq \log_2 |S| - 4\log_2 \left( \max \left( n \frac{1+\tau}{(\tau - \sqrt{\tau})^2 \delta^2}, n \right) \right),$$

such that a  $1-\delta$  fraction of all surjective linear maps  $L: \mathbb{F}_2^n \to \mathbb{F}_2^t$  have the property that  $L(U_S)$  is  $\tau 2^{-t}$ -close to uniform in the  $\ell_{\infty}$  norm.

We can again use Lemma II.3 to improve the entropy loss in the previous theorem.

**Theorem II.7.** Let  $S \subset \mathbb{F}_2^n$  and let  $\delta \leq 1/10$ ,  $\tau > 1$  and  $m = \log_2(|S|(|S|-1)/\delta)$  be such that

$$|S| > m^4 \max(2^8 (1+\tau)^4 / ((\tau - \sqrt{\tau})\delta)^8, 1)$$
  

$$m > 20 \lceil \log_2(m \max(4(1+\tau) / ((\tau - \sqrt{\tau})\delta)^2, 1)) \rceil$$

. Then there exists a natural number

$$t \ge \log_2 |S| - 4\log_2 \left( m \max \left( \frac{4(1+\tau)}{(\tau - \sqrt{\tau})^2 \delta^2}, 1 \right) \right),$$

such that a  $1-\delta$  fraction of all surjective linear maps  $L: \mathbb{F}_2^n \to \mathbb{F}_2^t$  have the property that  $L(U_S)$  is  $\tau 2^{-t}$ -close to uniform in the  $\ell_{\infty}$  norm.

#### A. Some comments

a) Tightness of our results:: It is natural to ask whether our results are tight. Fixing the parameter  $\delta$  to be constant for the sake of simplicity, can we possibly improve on the entropy loss stated in Theorem II.4? The answer is a resounding No! Even for a truly random function, the results of [2] show that we need an entropy loss of at least  $\log_2(\log_2|S|/\tau^2)$  (up to a additive constant) to acheive the conclusion of Theorem II.4. Hence, up to a reasonably small constant factor (of about 32), linear functions hash as well as random functions.

b) Prior results on linear hash functions:: Properties of random linear hashes w.r.t. the  $\ell_\infty$  norm have been studied in earlier works [1], [15], [16] with [1] being the state-of-the-art. The results in this area are typically stated as upper bounds on the expected 'maximal bucket size' (that is, the maximum size of  $L^{-1}(y)$  over all  $y \in \mathbb{F}_q^t$ ). We will see that earlier results only give bounds for  $\tau \gg 1$  (as far as we know, our paper is the first to give  $\ell_\infty$  guarantees for small  $\tau$ ).

Theorem 5 of [1] is the most relevant to this work and shows that, when  $\log_2 |S| - t = \log_2(t)$  the expected maximal bucket size is  $O(t\log_2(t))$ . A Markov argument shows then, that, with probability at least  $1-\delta$ , the maximal bucket size is at most  $O(t\log_2(t)/\delta)$  which is a factor of  $\log_2(t)/\delta$  larger than the trivial bound of  $|S|/2^t = t$ . Note that  $\log_2(t)/\delta \gg 1$ .

Theorem II.4 for small  $\tau$  shows that when  $\log_2 |S| - t \approx O(\log_2(\log_2(|S|^2/\delta)(\tau\delta)^{-2}))$ , the maximal bucket size will be at most a factor of  $1+\tau$  larger than the trivial bound of  $|S|/2^t$  with probability  $1-\delta$  over the choice of the linear function. Hence, the results of [1] deal with the case of smaller entropy loss  $(\log_2(t) \approx \log_2(\log_2(|S|))$  instead of  $O(\log_2(\log_2(|S|^2/\delta)(\tau\delta)^{-2}))$  but are a multiplicative factor of  $\log_2(t)/\delta \gg 1$  away from uniform instead of  $\tau+1$  which can be made arbitrarily close to 1 (by reducing  $\tau$  and increasing the entropy loss).

We can also make comparisons in the regime of large  $\tau$ . As stated earlier for  $\tau=1/\delta^2$  Theorem II.4 shows that the maximal bucket size will be at most a factor of  $1+1/\delta^2$  larger than the trivial bound of  $|S|/2^t$  with probability  $1-\delta$  over the choice of the linear function. In this setting for  $\delta\gg 1/\log_2(t)$ , we lose a constant factor in the entropy loss  $(\log_2\log_2|S|)$  in [1] and  $O(\log_2\log_2|S|)$  for our result) and gain in the bucket size bound  $(\log_2(t)\delta$  times  $|S|/2^t$  in [1] and  $1+1/\delta^2$  times  $|S|/2^t$  for our result). Although it should be noted that the results in [1] are incomparable in the sense that they compute the expected value of the bucket size while our results only give bounds on the bucket size with high probability.

c) Other families of universal hash functions:: In this section we look at whether our results can hold for other universal families of hash functions.

We first show that our results can not hold for all families of universal hash functions by means of an example. The family we will consider is linear maps from  $\mathbb{F}_{q^2}^2$  to  $\mathbb{F}_{q^2}$  which do

form a universal family. We will show that that known results from [1] prove that this family needs at least an entropy loss of  $\Omega(\log_2|S|)$  to get the distance guarantees of Theorem II.4. This also shows that we need high dimensionality to get good linear hash function over large fields.

Theorem 8 of [1] proves that for any finite field  $\mathbb{F}_{q^2}$  where q is a prime power if we consider the set of linear maps from  $\mathbb{F}_{q^2}^2$  to  $\mathbb{F}_{q^2}$  then there exists a set  $S_0$  of size  $q^2$  such that for every linear map the maximal bucket size is at least q.

This implies that for any  $S_0'$  of size  $q^{2+\eta}, \eta < 1$  which contains  $S_0$ , every linear map  $L: \mathbb{F}_{q^2}^2 \to \mathbb{F}_{q^2}$  will have a maximal bucket size of at least q. In other words  $L(U_{S_0'})$  will be at least  $1/q^{1+\eta} \gg C/q^2$  away from uniform in  $\ell_\infty$  distance. Equivalently, even for an entropy loss of  $\eta \log_2(q) = \Omega(\log_2 |S_0'|) \gg O(\log_2 \log_2 |S|)$ , linear maps from  $L: \mathbb{F}_{q^2}^2 \to \mathbb{F}_{q^2}$  do not guarantee that the image  $L(U_{S_0'})$  will be  $C/q^2$  close to uniform for any fixed constant C. This also means that we need at least an entropy loss of  $\Omega(\log_2 |S|)$  to get the distance guarantees of Theorem II.4.

Other families of universal hash function could still achieve the guarantees of Theorem II.4. In particular, for a prime p consider the family of hash functions  $h_{a,b}: \{0,1,\ldots,p-1\} \rightarrow \{0,\ldots,m-1\}$  for  $a\in\{1,\ldots,p-1\},b\in\{0,\ldots,p-1\}$  defined as  $h_{a,b}(x)=(ax+b\mod p)\mod m$ . From [15], we know that this family is universal. By following the framework in Section III, it can be checked that proving  $\ell_{\infty}$ -guarantees for this family is a generalization of the notoriously difficult Arithmetic Kakeya problem [17].

d) The case of high min-entropy:: As was mentioned before, The LHL holds not just for 'flat' distributions of the form  $U_S$ , but for any distribution with high min-entropy. This more general version can be derived easily from the LHL for sets using a convex combination argument. As far as we can tell, this argument fails in the case of  $\ell_\infty$  and so we cannot automatically derive a min-entropy analog of our results. While we do believe that our proof techniques could be made to handle this more general case (e.g., as is the case in [12]), we leave it for future work.

# III. CONNECTION TO PRIOR WORK ON KAKEYA AND FURSTENBERG SETS

In this section we will explain the connection between Theorem II.1 and the finite field Kakeya/Furstenberg problem. Along the way we will introduce notations and definitions that will be used later on in the proofs.

We will now describe an equivalent formulation of Theorem II.1 in terms of the kernel of the linear map  $L: \mathbb{F}_q^n \to \mathbb{F}_q^t$  appearing in the theorem. This will allow us to highlight its connection to the finite field Kakeya problem. To do so, we introduce some notations. For  $1 \leq k \leq n$  we denote by  $\mathcal{L}_k(\mathbb{F}_q^n)$  the set of k-dimensional flats in  $\mathbb{F}_q^n$  and by  $\mathcal{L}_k^*(\mathbb{F}_q^n)$  the set of k-dimensional subspaces (flats passing through the origin). Let  $S \subset \mathbb{F}_q^n$  be a set. For  $k \in [n]$ , we denote by

$$E_k(S) = |S|/q^{n-k}$$

the expectation of  $|R \cap S|$  with R chosen uniformly in  $\mathcal{L}_k(\mathbb{F}_q^n)$ . When S is clear from the context we omit it and simply write  $E_k$ .

**Definition III.1.** We say that  $R \in \mathcal{L}_k(\mathbb{F}_q^n)$  is  $\tau$ -balanced w.r.t a set  $S \subset \mathbb{F}_q^n$  if we have:

$$||R \cap S| - E_k(S)| < \tau \cdot E_k(S).$$

Otherwise, we say that R is  $\tau$ -unbalanced w.r.t S.

**Definition III.2.** We say that  $A \in \mathcal{L}_k^*(\mathbb{F}_q^n)$  is  $\tau$ -shift-balanced w.r.t S if, for all  $a \in \mathbb{F}_q^n$ , the flat R = A + a is  $\tau$ -balanced w.r.t S

Notice that if  $A \in \mathcal{L}_k^*(\mathbb{F}_q^n)$  is  $\tau$ -shift-balanced w.r.t S and  $A' \in \mathcal{L}_{k'}^*(\mathbb{F}_q^n)$  contains A (with k' > k) then A' is also  $\tau$ -shift-balanced w.r.t S.

We will now express Theorem II.1 using this new notation. Suppose  $L:\mathbb{F}_q^n\to\mathbb{F}_q^t$  is an onto linear map and let  $A=\ker(L)$  be its k=n-t dimensional kernel. Notice that, for each  $y\in\mathbb{F}_q^t$ ,

$$\mathbf{Pr}[L(U_S) = y] = \frac{|(A+a) \cap S|}{|S|},$$

for some  $a \in \mathbb{F}_q^n$  for which L(a) = y. Therefore,

$$|\mathbf{Pr}[L(U_S) = y] - q^{-t}| \le \tau q^{-t},$$

if and only if A+a is  $\tau$ -balanced w.r.t S. Hence, Theorem II.1 is equivalent to the following theorem.

**Theorem III.3.** Let  $n \geq 5$  and let  $S \subset \mathbb{F}_q^n$  be a set such that  $|S| > q^4$ . Let  $\tau > 0$ ,  $\delta \in (0,1)$  be a real number s.t  $q \geq 32 \max(n(1+\tau)/(\tau\delta)^2,n)$ . Let  $4 \leq r \leq n-1$  be an integer s.t  $q^r < |S| \leq q^{r+1}$  and let k = n-r+3. Then a  $1-\delta$  fraction of all subspaces in  $\mathcal{L}_k^*(\mathbb{F}_q^n)$  are  $\tau$ -shift-balanced w.r.t S.

We now take a moment to explain the expression 'two-sided Kakeya bounds' from the title and the connection to prior work on Kakeya sets. A Kakeya set in  $\mathbb{F}_q^n$  is a set containing a line in each direction. The main question, asked by Wolff in [18], is to lower bound the size of such sets. This question has now been completely resolved in the series of papers [11], [19], [20]. We will be mostly interested in the high dimensional variants of this problem, asking about sets containing k-dimensional flats in all directions, or more generally, sets that have large intersection with a flat in each direction (these are called Furstenberg sets). These type of questions have been also studied extensively, with tight bounds obtained in some cases [12], [14], [21]–[23].

We start by recalling some definitions from that domain.

**Definition III.4** (m-rich flats). We call a flat  $R \in \mathcal{L}_k(\mathbb{F}_q^n)$  m-rich w.r.t a set  $S \subset \mathbb{F}_q^n$  if  $|R \cap S| \geq m$ .

**Definition III.5**  $((k, m, \beta)$ -Furstenberg sets). We call a set  $K \subset \mathbb{F}_q^n$  a  $(k, m, \beta)$ -Furstenberg set if K has an m-rich k-flat for at least a  $\beta$  fraction of directions. That is, for at least

a  $\beta$ -fraction of all  $A \in \mathcal{L}_k^*(\mathbb{F}_q^n)$  there exists  $a \in \mathbb{F}_q^n$  so that a + A is m-rich w.r.t K.

Prior works on Kakeya/Furstenberg sets were focused on giving *lower bounds* on the size of (k, m, 1)-Furstenberg sets. For example, in [12], it was shown that, if S is a (k, m, 1)-Furstenberg set then  $|S| > (1 - \epsilon)mq^{n-k}$ , assuming q is sufficiently large as a function of n and  $\epsilon$  (in particular, q has to be exponential in n). Notice that this is the best possible since any set of size  $mq^{n-k}$  is (k, m, 1)-Furstenberg. Stated in the counter-positive direction, this theorem shows that: If

$$|S| \le (1 - \epsilon)mq^{n-k} \tag{3}$$

then there exists a k-dimensional subspace R such that all shifts of R have less than m-points in common with S. Notice that (3) gives us that

$$E_k(S) \le (1 - \epsilon)m$$
.

So, what we discover is that, the results in [12] simply say that, for every S, there is a subspace R such that all shifts of R have intersection with S that is not much larger from the expectation  $E_k$ . Hence, Theorem III.3 can be viewed as a two-sided generalization of this statement by showing that, in fact, there exists R such that all shifts of R have roughly the expected intersection with S.

#### IV. PROOF OVERVIEW

We now give a short sketch of the proof of Theorem II.1. The proof of Theorem II.5 (the case of  $\tau > 1$ ) is essentially the same as the proof of Theorem II.1 with a different setting of a single parameter and so we will not discuss it here. We will also not discuss the two theorems dealing with the case of  $\mathbb{F}_2$  as they will follow from the large field case by a simple encoding argument.

As discussed in Section III, Theorem II.1 is equivalent to Theorem III.3 which is stated in the language of shift-balanced sub-spaces. Given a set  $S \subset \mathbb{F}_q^n$ , the theorem claims that there are many sub-spaces  $A \in \mathcal{L}_k^*(\mathbb{F}_q^n)$  that are  $\tau$ -shift-balanced. Let us instead try and prove the easier claim that *there exists* at least one such subspace. We will prove this by contradiction. Suppose there are no  $\tau$ -shift balanced sub-spaces A. Then, for each  $A \in \mathcal{L}_k^*(\mathbb{F}_q^n)$  we can find a shift  $f(A) \in \mathbb{F}_q^n$  so that the flat  $T_A = f(A) + A$  is  $\tau$ -unbalanced.

At a very high level, the contradiction will follow by combining the following three statements:

- (Concentration Statement) A random k-2 flat is  $\tau/2$ -balanced with high probability.
- (Anti concentration statement) If T is a  $\tau$ -unbalanced k-flat and R is a randomly chosen k-2-flat in T then R is  $\tau/2$ -unbalanced with high probability.
- (Kakeya statement) Given a collection of k-flats,  $T_A$ , one in each direction  $A \in \mathcal{L}_k^*(\mathbb{F}_q^n)$ . A randomly chosen k-2-flat in a randomly chosen  $T_A$  'behaves like' a truly random k-2-flat.

Before we discuss the proofs of these statements, let us see how they can be combined to derive a contradiction. Consider the distribution on k-2-flats obtained by sampling  $A \in \mathcal{L}_k^*(\mathbb{F}_q^n)$  uniformly at random and then choosing a random k-2-flat R inside f(A)+A, where f(A) is defined above so that f(A)+A is  $\tau$ -unbalanced. By the anti-concentration statement, this distribution outputs a  $\tau/2$ -unbalanced R with high probability. Now, from the Kakeya statement we get that this should (in some way) also be the behaviour of a truly random k-2-flat, contradicting the concentration statement. This is essentially the structure of the proof, with the 'behaves like' portion of the Kakeya statement replaced by a quantitative bound on the probability of landing in a given small set (the set of unbalanced k-2 flats).

Let us now discuss the proofs of the three statements. The first two (concentration and anti-concentration), follow easily from Chebyshev's inequality and pair-wise independence and so we will only be concerned with the proof of the third one. We can generalize the Kekeya statement as follows, given a collection of k-flats  $T_A$ , one in each direction A, what can be said about the distribution of a random r-flat R in a random  $T_A$  where we allow r to be in the range  $\{0,1,\ldots,k\}$ . To recover the original (one dimensional) Kakeya problem all we have to do is set k = 1 and r = 0. Now, we are asking about the distribution of a random point R on a line  $T_A$  chosen so that its direction is uniformly random and its shift is arbitrary. The finite field Kakeya conjecture (proved in [19]) says that the distribution of R has large support. In [10], [11], motivated by applications to extractors, it was shown that, in fact, the distribution of R has high min-entropy. These results can be easily 'lifted up' to the case where k > 1 and r = k - 1 but, alas, the known (and tight) quantitative bounds on the min entropy are not sufficient for our purposes. Specifically, it is possible for the distribution of R in this case to be contained in a set of density  $2^{-n}$  inside  $\mathbb{F}_q^n$ , which is much too small for our purposes. This motivates us to take r = k - 2, which reduces to understanding the case of k = 2 and r = 0. That is, given a family of 2-flats  $T_A$ , one in each direction, what can be say about the behaviour of a random point R on a random  $T_A$ ? Luckily, in this case, the results of [12], [14] can be used to show that the distribution of R has support with density approaching one.

To prove our theorem we need to extend the results of [12], [14] in several ways, including going from support size to min entropy, reducing the field size from exponential to polynomial and handling the case of 'many' directions in stead of 'all' (which corresponds to the parameter  $\delta$  being less than one). The required lemma is stated below and proved in the full paper.

**Lemma IV.1** (Furstenberg lemma). For any  $\gamma, \beta \in [0, 1], n \in \mathbb{N}$ , q a prime power every  $(2, \gamma q^2, \beta)$ -Furstenberg set  $K \subseteq \mathbb{F}_q^n$  has size at least,

$$|K| \ge \beta \gamma^n q^n \left( 1 + \frac{1}{q} \right)^{-n}.$$

Note, this lemma has been proven in [13] with a slightly worse lower bound of  $\beta\gamma^nq^n\left(1+\frac{2}{q}\right)^{-n}$  which is enough

to prove Theorem II.1 leading to slightly worse constants in the field size requirement and hence the entropy loss of the theorem. The proof in [13] uses a combinatorial reduction to reduce the case of arbitrary  $\beta$  to constant  $\beta$ . We give a new argument to prove this lemma directly.

Our proof of this lemma follows along the lines of prior works in this area and uses the polynomial method. One important ingredient is a new variant of the celebrated Schwartz-Zippel lemma which allows us to improve the dependence on  $\beta$  above from  $\beta^n$  to just  $\beta$ . We believe this lemma could have applications in other situations where the polynomial method is used. For instance in an upcoming work [24] extensions of these arguments will be used to prove maximal Kakeya bounds in the general setting of the integers modulo a composite number.

## V. Proof of Theorems II.1 and II.5

We prove Theorems II.1 and II.5 by contradiction. We will prove the equivalent versions of the theorems stated using  $\tau$ -shift-balanced subspaces (Theorem III.3 and similarly for Theorem II.5 even though it was not stated separately). Suppose the Theorems are not true. Then there exists a function with parameters as in the Theorems:

$$f: \mathcal{L}_k^*(\mathbb{F}_q^n) \to \mathbb{F}_q^n$$

such that, for a  $\delta$  fraction of  $A \in \mathcal{L}_k^*(\mathbb{F}_q^n)$ , the flat f(A) + A is  $\tau$ -unbalanced w.r.t. S. Notice that f(A) can be taken to be any point on the flat f(A) + A (the choice doesn't matter for this proof).

For a real number  $\sigma > 0$ , let

$$B_{k-2}^{\sigma} \subset \mathcal{L}_{k-2}(\mathbb{F}_q^n)$$

denote the set of k-2-flats that are  $\sigma$ -unbalanced w.r.t. S. We will eventually set  $\sigma$  to one of two values: To prove Theorem II.1 we will set  $\sigma=\tau/2$  and, to prove Theorem II.5 (when  $\tau>1$ ) we will set  $\sigma=\sqrt{\tau}$ . Notice that, in both cases, we have  $\tau-\sigma>0$ .

For a k-flat  $T\in\mathcal{L}_k(\mathbb{F}_q^n)$  we let  $\mathcal{L}_{k-2}(T)$  be the set of k-2-flats contained in T and let

$$B_{k-2}^{\sigma}(T) = B_{k-2}^{\sigma} \cap \mathcal{L}_{k-2}(T)$$

denote the set of  $\sigma$ -unbalanced k-2-flats w.r.t. S that are contained in T.

Notice first that, by our assumption on r, we have

$$4 \le k \le n - 1 \tag{4}$$

Our first claim shows that a random k-2 flat is balanced w.h.p. This gives the 'concentration' part of the argument laid out in the proof overview.

**Claim V.1.** If R is chosen uniformly in  $\mathcal{L}_{k-2}(\mathbb{F}_q^n)$  then

$$\mathbf{Pr}[R \in B_{k-2}^{\sigma}] \le \frac{1}{\sigma^2 q}.$$

*Proof.* Since  $k \geq 3$  we can use pairwise independence and Chebyshev. The probability that  $|R \cap S|$  deviates from its expectation  $E_{k-2}$  by at least  $\sigma E_{k-2}$  is at most

$$\frac{\mathbf{V}(|R \cap S|)}{(\sigma E_{k-2})^2} \le \frac{1}{\sigma^2 E_{k-2}} \le \frac{1}{\sigma^2 q},$$

where we use the fact that  $E_{k-2} = |S|/q^{n-k+2} \ge q$  for k = n-r+3.

The next claim gives the 'anti concentration' part of the proof overview, showing that a random k-2-flat in an unbalanced k-flat is unbalanced w.h.p.

**Claim V.2.** Let  $T \in \mathcal{L}_k(\mathbb{F}_q^n)$  be  $\tau$ -unbalanced w.r.t S. Suppose R is chosen uniformly at random from  $\mathcal{L}_{k-2}(T)$ . Then

$$\mathbf{Pr}[R \in B_{k-2}^{\sigma}(T)] \ge 1 - \frac{1+\tau}{(\tau - \sigma)^2 q}.$$

*Proof.* As before, the size of  $R \cap S$  is a sum of p.w independent indicator variables with expectation:

$$\mathbb{E}[|R \cap S|] = \frac{|S \cap T|}{|T|} q^{k-2} = |S \cap T|/q^2. \tag{5}$$

Since T is  $\tau$ -unbalanced, we have that

$$||S \cap T| - E_k| > \tau E_k. \tag{6}$$

Therefore, dividing by  $q^2$  and using (5) we have that

$$|\mathbb{E}[|R \cap S|] - E_{k-2}| > \tau E_{k-2}.$$
 (7)

We will separate into two cases: case 1 is when

$$\mathbb{E}[|R \cap S|] \le (1 - \tau)E_{k-2}.\tag{8}$$

In this case (which can only happen if  $\tau < 1$ ), using Chebyshev, the probability that R is  $\sigma$ -balanced is bounded from above by,

$$\begin{split} &\mathbf{Pr}[|R\cap S| - E_{k-2} \geq -\sigma E_{k-2}] &\leq \\ &\mathbf{Pr}[|R\cap S| - \mathbb{E}[|R\cap S|] \geq (\tau-\sigma)E_{k-2}] &\leq \\ &\frac{\mathbf{V}(|R\cap S|)}{(\tau-\sigma)^2 E_{k-2}^2} \leq \frac{\mathbb{E}(|R\cap S|)}{(\tau-\sigma)^2 E_{k-2}^2} &\leq \frac{1-\tau}{(\tau-\sigma)^2 q}. \end{split}$$

In the second case we have.

$$\mathbb{E}[|R \cap S|] \ge (1+\tau)E_{k-2}.$$

In this case the probability that R is  $\sigma$ -balanced is bounded above by,

$$\begin{aligned} \mathbf{Pr}[|R \cap S| - E_{k-2} &\leq \sigma E_{k-2}] \leq \\ \mathbf{Pr}[||R \cap S| - \mathbb{E}[|R \cap S|]| &\geq \mathbb{E}[|R \cap S|] - (1 + \sigma)E_{k-2}] \leq \\ \mathbf{Pr}\left[||R \cap S| - \mathbb{E}[|R \cap S|]| &\geq \mathbb{E}[|R \cap S|] \cdot \frac{\tau - \sigma}{1 + \tau}\right] \leq \\ \frac{\mathbf{V}(|R \cap S|)}{(\tau - \sigma)^2/(1 + \tau)^2 \mathbb{E}[|R \cap S|]^2} &\leq \\ \frac{(1 + \tau)^2}{(\tau - \sigma)^2 \mathbb{E}[|R \cap S|]} &\leq \\ \frac{1 + \tau}{(\tau - \sigma)^2 q}. \end{aligned}$$

Hence, the probability that R is  $\sigma$  balanced is bounded by  $(1+\tau)/((\tau-\sigma)^2q)$  and so we are done.

We next define three important sets:

- $(\mathcal{L}_{k-2}^*(T))$ : For  $T \in \mathcal{L}_k(\mathbb{F}_q^n)$ , we define  $\mathcal{L}_{k-2}^*(T)$  to be the set of subspaces in  $\mathcal{L}_{k-2}^*(\mathbb{F}_q^n)$  which on translation can lie in T (or equivalently are parallel to T).
- $(\mathcal{L}_{k-2}(T, || W))$ : For  $T \in \mathcal{L}_k(\mathbb{F}_q^n)$  and  $W \in \mathcal{L}_{k-2}^*(T)$  we let  $\mathcal{L}_{k-2}(T, || W)$  be the set of k-2 flats in T which are parallel to W (notice that there are exactly  $q^2$  such flats and that their disjoint union is T).
- $(C_{k-2}^{\sigma,c}(T))$ : For  $T \in \mathcal{L}_k(\mathbb{F}_q^n)$  we let  $C_{k-2}^{\sigma,c}(T)$  be the set of flats W in  $\mathcal{L}_{k-2}^*(T)$  such that at least a  $1 \frac{c(1+\tau)}{(\tau-\sigma)^2q}$  fraction of the flats in  $\mathcal{L}_{k-2}(T, \| W)$  are in  $B_{k-2}^{\sigma}(T)$  (we will set  $c \geq 1$  to two different values for Theorem II.1 and Theorem II.5).

The previous lemma can now be used to prove that, if T is unbalanced, then many W's are in fact in the set  $C_{k-2}^{\sigma,c}(T)$  defined above (this is essentially a Markov style averaging argument).

**Claim V.3.** Let  $T \in \mathcal{L}_k(\mathbb{F}_q^n)$  be  $\tau$ -unbalanced w.r.t S. Suppose W is chosen uniformly at random from  $\mathcal{L}_{k-2}^*(T)$ . Then

$$\Pr[W \in C_{k-2}^{\sigma,c}(T)] \ge 1 - 1/c.$$

*Proof.* Let us say the claim is false then with probability less than 1-1/c,  $W\in C^{\sigma,c}_{k-2}(T)$  for a uniformly random  $W\in \mathcal{L}^*_{k-2}(T)$ . Equivalently, with probability greater than 1/c,  $W\not\in C^{\sigma,c}_{k-2}(T)$ . We can sample a uniformly random chosen  $R\in \mathcal{L}_{k-2}(T)$  by first picking a direction  $W\in \mathcal{L}^*_{k-2}(T)$  at random and then taking R to be a random shift of W inside T. The above assumption will then give us that:

$$\begin{aligned} \mathbf{Pr}[R \in B^{\sigma}_{k-2}(T)] \leq \\ \mathbf{Pr}[W \not\in C^{\sigma,c}_{k-2}(T)] \left(1 - \frac{c(1+\tau)}{(\tau-\sigma)^2 q}\right) + \mathbf{Pr}[W \in C^{\sigma,c}_{k-2}(T)] \leq \\ 1 - \mathbf{Pr}[W \not\in C^{\sigma,c}_{k-2}(T)] \frac{c(1+\tau)}{(\tau-\sigma)^2 q} < 1 - \frac{1+\tau}{(\tau-\sigma)^2 q}. \end{aligned}$$
 This contradicts Claim V.2.

Given  $W \in \mathcal{L}_{k-2}^*(\mathbb{F}_q^n)$ , let  $\mathcal{L}_{k-2}(\parallel W)$  be the set of k-2 flats parallel to W and  $\mathcal{L}_k^*(\parallel W)$  be the set of k-dimensional subspaces containing W. Let

$$B_{k-2}^{\sigma}(\| W) = B_{k-2}^{\sigma} \cap \mathcal{L}_{k-2}(\| W)$$

denote the set of  $\sigma$ -unbalanced flats parallel to W.

The next claim shows that there is a 'good' choice of  $W \in \mathcal{L}^*_{k-2}(\mathbb{F}^n_q)$  to which we should restrict our attention (that is, we will consider only k-2 flats parallel to W).<sup>4</sup> This W should preserve the typical behavior of a random W in two respects: one is that  $B^{\sigma}_{k-2}$  should still have low density when restricted to flats parallel to W. The other is that W hits  $C^{\sigma,c}_{k-2}(f(A)+A)$  for many  $A \in \mathcal{L}^*_k(\parallel W)$ .

<sup>4</sup>This part of the proof corresponds to the statement in the proof overview arguing that the case of general k and r can be reduced to the case of r=0 and  $k\mapsto k-r$ .

**Claim V.4.** There exists  $W \in \mathcal{L}_{k-2}^*(\mathbb{F}_q^n)$  such that

1) 
$$|B_{k-2}^{\sigma}(\parallel W)| \le \frac{1}{\sigma^2 q(1-\sqrt{1-\delta(1-1/c)})} \cdot |\mathcal{L}_{k-2}(\parallel W)| \le \frac{2c}{2c} n^{n-k+1}$$

1) 
$$|B_{k-2}^{\sigma}(\parallel W)| \leq \frac{1}{\sigma^2 q(1-\sqrt{1-\delta(1-1/c)})} \cdot |\mathcal{L}_{k-2}(\parallel W)| \leq \frac{2c}{(c-1)\sigma^2\delta} q^{n-k+1}$$
  
2)  $\mathbf{Pr}_{A \sim \mathcal{L}_k^*(\parallel W)}[W \in C_{k-2}^{\sigma,c}(f(A) + A)] \geq 1 - \sqrt{1-\delta(1-1/c)} \geq \frac{(c-1)\delta}{c+c\sqrt{1-\delta/2}} \geq \frac{\delta(c-1)}{2c}$ .

*Proof.* Notice, that  $B_{k-2}^{\sigma}$  is a disjoint union of  $B_{k-2}^{\sigma}(\parallel W)$ over all  $W \in \mathcal{L}^*_{k-2}(\mathbb{F}_q^n)$ . Suppose W is chosen uniformly at random from  $\mathcal{L}^*_{k-2}(\mathbb{F}_q^n)$ . Then, by Claim V.1 and Markov, we have that the probability that W does not satisfy 1. above is less than  $1 - \sqrt{1 - \delta(1 - 1/c)}$ .

Consider the bi-partite graph G between  $\mathcal{L}_k^*(\mathbb{F}_q^n)$  and  $\mathcal{L}_{k-2}^*(\mathbb{F}_q^n)$  where the edges correspond to pairs  $(A,W)\in$  $\mathcal{L}_{k}^{*}(\mathbb{F}_{q}^{n}) \times \mathcal{L}_{k-2}^{*}(\mathbb{F}_{q}^{n})$  such that  $W \subset A$ . Let  $\mu$  be the distribution over the pairs  $(A,W) \in \mathcal{L}_{k}^{*}(\mathbb{F}_{q}^{n}) \times \mathcal{L}_{k-2}^{*}(\mathbb{F}_{q}^{n})$  which is uniform over the edges of G. As the graph G is regular on both sides sampling from  $\mu$  is equivalent to sampling Auniformly from  $\mathcal{L}_{k}^{*}(\mathbb{F}_{q}^{n})$  and W uniformly from  $\mathcal{L}_{k-2}^{*}(A)$ . It also is equivalent to uniformly sampling  $W \in \mathcal{L}_{k-2}^*(\mathbb{F}_q^n)$  and sampling A from  $\mathcal{L}_k^*(\parallel W)$ . By Claim V.3 and the fact that at least for a  $\delta$  fraction of  $A \in \mathcal{L}_k^*(\mathbb{F}_q^n)$ , f(A) + A is  $\tau$ -unbalanced we have,

$$\mathbf{Pr}_{(A,W)\sim\mu}[W\in C_{k-2}^{\sigma,c}(f(A)+A)] \ge \delta(1-1/c).$$

By averaging, again, we get that the probability that W fails to satisfy

$$\mathbf{Pr}_{A \sim \mathcal{L}_k^*(\parallel W)}[W \not\in C_{k-2}^{\sigma,c}(f(A)+A)] \leq \sqrt{1-\delta(1-1/c)}$$

is at most  $\sqrt{1-\delta(1-1/c)}$ . By a union bound we now see that there exists a  $W \in \mathcal{L}_{k-2}^*(\mathbb{F}_q^n)$  which satisfies the two properties in the claim.

Fix  $W = \hat{W}$  satisfying the two numbered items of Claim V.4. Let  $G_{\hat{W}}$  be the random variable which outputs the random 2-flat

$$f(\operatorname{span}\{U,\hat{W}\}) + U$$

for uniformly random  $U \in \mathcal{L}_2^*(\mathbb{F}_q^n)$ . Notice that there is a small probability that span $\{U, \hat{W}\}$  is not k dimensional. In this case we set  $f(\text{span}\{U, W\}) = 0$ .

We will now show that  $G_{\hat{W}}$  has large intersections with a small set with high probability. The particular structure of the random variable  $G_{\hat{W}}$  allows us to state this using the notion of a Furstenberg set.

**Claim V.5.** There exists a set  $K \subset \mathbb{F}_q^n$  such that

1) 
$$|K| \le \frac{2c}{(c-1)\sigma^2 \delta} q^{n-1}$$
.

2) K is 
$$\left(2, \left(1 - \frac{c(1+\tau)}{(\tau-\sigma)^2 q}\right) q^2, \delta \frac{c-1}{2c} (1 - 1/q - 1/q^2)\right)$$
-Furstenberg.

Proof. We take

$$K = \bigcup_{R \in B^{\sigma}_{k-2}(\|\hat{W})} R$$

to be the union of all  $\sigma$ -unbalanced k-2-flats parallel to  $\hat{W}$ . To show that 1. holds, we use the first item of Claim V.4 and the fact that each R has  $q^{k-2}$  points.

For a uniformly random U $\in \mathcal{L}_{2}^{*}(\mathbb{F}_{q}^{n}), F =$  $f(\operatorname{span}(U, \hat{W})) + U$  gives us a sample from  $G_{\hat{W}}$ . Let T = $f(\operatorname{span}(U,\hat{W})) + \operatorname{span}(U,\hat{W})$ . If  $\hat{W} \in C_{k-2}^{\sigma,c}(T)$  then that means at least

$$\left(1 - \frac{c(1+\tau)}{(\tau-\sigma)^2 q}\right) q^2$$

many flats in  $\mathcal{L}_{k-2}(T, \| \hat{W})$  are in  $B_{k-2}^{\sigma}(T)$  and hence contained in K. F will intersect with each of these flats (and hence K) in distinct points. This is because T is a  $f(\operatorname{span}(U,\hat{W}))$ -shift of the span of U and  $\hat{W}$  and  $U \cap$  $\hat{W} = \{0\}$  so T is a disjoint union of shifts of  $\hat{W}$  by elements in  $F = f(\text{span}(U, \hat{W})) + U$ . This implies that Fis  $(1-c(1+\tau)/(\tau-\sigma)^2q)q^2$ -rich w.r.t. K. Finally, note that conditioned on the event that  $span(U, \hat{W})$  is k-dimensional T has the same distribution as f(A) + A where A is uniformly distributed over  $\mathcal{L}_k^*(\parallel \hat{W})$ . This means

$$\begin{split} \mathbf{Pr}\left[G_{\hat{W}} \text{ is } \left(1-\frac{c(1+\tau)}{(\tau-\sigma)^2q}\right)q^2\text{-rich w.r.t }K\right] \geq \\ \mathbf{Pr}_{A\sim\mathcal{L}_k^*(||\hat{W})}\left[\hat{W}\in C_{k-2}^{\sigma,c}(f(A)+A)\right]\times \\ \mathbf{Pr}_{U\in\mathcal{L}_2^*(\mathbb{F}_q^n)}\left[\dim \operatorname{span}\{U,\hat{W}\}=k\right]. \end{split}$$

We note  $\Pr_{U \in \mathcal{L}_2^*(\mathbb{F}_q^n)}[\dim \operatorname{span}\{U, \hat{W}\} = k]$  is at least  $1 - 1/q - 1/q^2$ . If we generate U by picking two random vectors then the first one being in U has probability at most  $1/q^{n-k+2} \le 1/q^2$  and the second being in the space spanned by the first and U has probability at most  $1/q^{n-k+1} \le 1/q$ . Now using Claim V.3 and the equation above we have,

$$\begin{split} \mathbf{Pr}\left[G_{\hat{W}} \text{ is } \left(1-\frac{c(1+\tau)}{(\tau-\sigma)^2q}\right)q^2\text{-rich}\right] \geq \\ \frac{(c-1)\delta}{2c}\left(1-\frac{1}{q}-\frac{1}{q^2}\right). \end{split}$$

The above equation implies 2. as  $G_{\hat{W}}$  by definition takes a uniformly chosen  $U \in \mathcal{L}_2^*(\mathbb{F}_q^n)$  and outputs a flat parallel to U. 

To finish the proof of the theorem we need a bound for  $(2, \gamma q^2, \beta)$ -Furstenberg Sets. We will use Lemma IV.1. We restate the Lemma here for convenience.

**Lemma IV.1.** For any  $\gamma, \beta \in [0, 1], n \in \mathbb{N}$ , q a prime power every  $(2, \gamma q^2, \beta)$ -Furstenberg set  $K \subseteq \mathbb{F}_q^n$  has size at least,

$$|K| \ge \beta \gamma^n q^n \left( 1 + \frac{1}{q} \right)^{-n}.$$

Given this lemma, we substitute the values

$$\gamma = \left(1 - \frac{c(1+\tau)}{(\tau-\sigma)^2 q}\right), \beta = \frac{\delta(c-1)}{2c}\left(1 - \frac{1}{q} - \frac{1}{q^2}\right)$$

and the bound on  $\left|K\right|$  given by Claim V.5 into the lemma above. We get the bound,

$$\frac{2c}{(c-1)\sigma^2\delta}q^{n-1} \ge |K| \ge q^n \left(1 - \frac{c(1+\tau)}{(\tau-\sigma)^2q}\right)^n \left(1 + \frac{1}{q}\right)^{-n} \frac{\delta(c-1)}{2c} \left(1 - \frac{1}{q} - \frac{1}{q^2}\right). \tag{9}$$

To prove Theorem II.1 use  $q \ge 32 \max(n(1+\tau)/(\tau\delta)^2, n)$ ,  $c=4, \ \sigma=\tau/2$  and  $\delta \le 1$  in (9) and re-arrange to get,

$$\frac{8}{9n} \geq \left(1 - \frac{1}{2n}\right)^n \left(1 + \frac{1}{32n}\right)^{-n} \left(1 - \frac{1}{32n} - \frac{1}{32^2n^2}\right).$$

Using  $(1-x/n)^n \ge e^{-x}(1-x^2/n)$  for  $x < n, (1+x/n)^n \le e^x$  and  $n \ge 5$  then implies,

$$\frac{8}{45} > e^{-1/5} (1 - 1/20)e^{-1/32} (1 - 1/160 - 1/(160)^2)$$

which leads to a contradiction proving Theorem II.1.

To prove Theorem II.5 use  $q \ge \max(n(1+\tau)/(\tau-\sqrt{\tau})^2\delta^2,n), \sigma=\sqrt{\tau},\ \delta\le 1/10$  and set c=10 in (9) to get.

$$\frac{400}{81n} \ge \frac{400(\tau - \sqrt{\tau})^2}{81\tau(\tau + 1)n} \ge \left(1 - \frac{1}{10n}\right)^n \left(1 + \frac{1}{n}\right)^{-n} \left(1 - \frac{1}{n} - \frac{1}{n^2}\right).$$

Using  $(1-x/n)^n \ge e^{-x}(1-x^2/n)$  for x < n,  $(1+x/n)^n \le e^x$  and  $n \ge 20$  gives us,

$$\frac{400}{81 \cdot 20} > e^{-1/10} (1 - 1/(100 \cdot 20))e^{-1} (1 - /20 - 1/400)$$

which leads to a contradiction proving Theorem II.5.

# A. The case of $\mathbb{F}_2$

In this section we prove Theorem II.2 using Theorem II.1. The same argument can be used to derive Theorem II.6 from Theorem II.5.

**Theorem II.2.** Let  $S \subset \mathbb{F}_2^n$  be such that  $|S| > 2^{20} \max(n^4(1+\tau)^4/(\tau\delta)^8,n^4)$  and let  $n,\tau,\delta$  satisfy  $n \geq 5\lceil \log_2(\max(n(1+\tau)/(\tau\delta)^2,n)) \rceil + 25$ . Then there exists a natural number

$$t > \log_2 |S| - 4 \log_2(\max(n(1+\tau)/(\tau\delta)^2, n)) - 20,$$

such that a  $1-\delta$  fraction of all surjective linear maps  $L: \mathbb{F}_2^n \to \mathbb{F}_2^t$  have the property that  $L(U_S)$  is  $\tau 2^{-t}$ -close to uniform in the  $\ell_{\infty}$  norm.

Proof. Take

$$\ell = \lceil \log_2(32 \max(n(1+\tau)/(\tau\delta)^2, n)) \rceil.$$

and set

$$q=2^{\ell}$$
.

Let

$$n' = \lceil n/\ell \rceil$$

so that we have

$$2^n < q^{n'}.$$

We now identify  $\mathbb{F}_2^n$  with an  $\mathbb{F}_2$ -linear subspace of  $\mathbb{F}_q^{n'}$ , e.g., by identifying  $\mathbb{F}_q^n$  with  $\mathbb{F}_2^{n\ell}$  as  $\mathbb{F}_2$ -vector spaces and then identifying  $\mathbb{F}_q^n$  with the first  $n \leq n'\ell$  coordinates. The above embedding of  $\mathbb{F}_2^n$  in  $\mathbb{F}_q^{n'}$  allows us to think of the set S as sitting in  $\mathbb{F}_q^{n'}$  and so we can apply Theorem II.1 if we check that all the conditions are met. We first see that, by our choice of  $\ell$ , the bound on  $q \geq 32 \max(n'(1+\tau)/(\tau\delta)^2, n')$  is met (notice that  $n' \leq n$ ). We also need to check that  $|S| > q^4$  which holds from our assumption  $|S| \geq 2^{20} \max(n^4(1+\tau)^4/(\tau\delta)^8, n^4)$ .  $n' \geq 5$  is also satisfied.

Hence we can apply Theorem II.1 in our setting. Let r be such that

$$q^r < |S| \le q^{r+1}$$

and set

$$t' = r - 3.$$

We get that for a  $1-\delta$  fraction of all surjective linear maps  $L': \mathbb{F}_q^{n'} \to \mathbb{F}_q^{t'}$  satisfy the property that  $L'(U_S)$  is  $\tau q^{-t'}$ -close to uniform in the  $\ell_\infty$  distance. Since an  $\mathbb{F}_q$ -linear map is also an  $\mathbb{F}_2$ -linear map, we can think of L' as an  $\mathbb{F}_2$ -linear map from  $\mathbb{F}_2^{n'\ell}$  to  $\mathbb{F}_2^{t'\ell}$ . Setting

$$t = t'\ell$$

and let L be the restriction of L' to the subspace we previously identified with  $\mathbb{F}_2^n$  (which contains S) we get that for any such  $L: \mathbb{F}_2^n \to \mathbb{F}_2^t$ ,  $L(U_S)$  is  $\tau 2^{-t}$ -close to uniform in the  $\ell_{\infty}$  distance (clearly  $L(U_S)$  and  $L'(U_S)$  have the same distribution).

We now bound the 'entropy loss' or  $\log_2 |S| - t$ . Notice that

$$\log_2 |S| \le (r+1)\ell$$

and that

$$t = t'\ell = (r - 3)\ell.$$

Combining the last two inequalities we get that

$$\log_2 |S| - t \le 4\ell \le 4\log_2(\max(n(1+\tau)/(\tau\delta)^2, n) - 20.$$

We are not done yet as not all surjective linear maps from  $\mathbb{F}_2^n$  to  $\mathbb{F}_2^t$  will be restrictions of surjective linear maps from  $\mathbb{F}_q^{n'}$  to  $\mathbb{F}_q^{t'}$ . We now overcome this obstacle using a random rotation argument. We started out with embedding  $S\subseteq \mathbb{F}_2^n$  in a bigger space  $\mathbb{F}_2^{n'\ell}$ . If we can show a  $(1-\delta)$ -fraction of surjective linear maps from  $\mathbb{F}_2^{n'\ell}$  to  $\mathbb{F}_2^t$  satisfy the desired property we are also done. We also let  $\phi:\mathbb{F}_2^{n'\ell}\to\mathbb{F}_q^{n'}$  be the  $\mathbb{F}_2$ -linear isomorphism between  $\mathbb{F}_2^{n'\ell}$  and  $\mathbb{F}_q^{n'}$  we had implicitly chosen in the beginning.

Let H be the set of surjective linear maps from  $\mathbb{F}_q^{n'}$  to  $\mathbb{F}_q^t$  which are also surjective linear maps from  $\mathbb{F}_q^{n'}$  to  $\mathbb{F}_q^{t'}$ . We just showed that a  $1-\delta$  fraction of the maps in H satisfy the desired property. Let M be a random invertible linear map in  $\mathrm{GL}_{n'\ell}(\mathbb{F}_2)$ . We note  $\phi \circ M$  is also a valid  $\mathbb{F}_2$ -linear isomorphism between  $\mathbb{F}_2^n n'\ell$  and  $\mathbb{F}_q^{n'}$ . If we repeated our earlier argument with this isomorphism we will have proven

that a  $1-\delta$  fraction of the maps in  $M\cdot H=\{L\circ M|L\in H\}$  satisfy the desired property. But under a random rotation we see that each surjective linear map from  $\mathbb{F}_2^{n'\ell}$  to  $\mathbb{F}_2^t$  will be included in an equal number of  $M\cdot H$ . This proves that there is at least a  $1-\delta$  fraction of surjective linear maps from  $\mathbb{F}_2^{n'\ell}$  to  $\mathbb{F}_2^t$  which satisfy the desired property.

#### ACKNOWLEDGMENT

We are grateful to Or Ordentlich, Oded Regev and Barak Weiss for comments that led us to pursue this line of work. Their interest in theorems of this kind arose from trying to strengthen their breakthrough [13] on lattice coverings, which uses the two dimensional Kakeya bounds of [14]. (A new paper by the same group of authors, using the results of the current paper, is in preparation).

#### REFERENCES

- N. Alon, M. Dietzfelbinger, P. B. Miltersen, E. Petrank, and G. Tardos, "Linear Hash Functions," *Journal of Association for Computing Machinery*, vol. 46, no. 5, p. 667–683, 1999.
- [2] M. Raab and A. Steger, "Balls into Bins" A Simple and Tight Analysis," in *Randomization and Approximation Techniques in Computer Science*. Springer, 1998, pp. 159–170.
- [3] R. Impagliazzo, L. A. Levin, and M. Luby, "Pseudo-Random Generation from One-Way Functions," in *Proceedings of the Twenty-First Annual* ACM Symposium on Theory of Computing, ser. STOC '89. Association for Computing Machinery, 1989, p. 12–24.
- [4] J. Radhakrishnan and A. Ta-Shma, "Bounds for Dispersers, Extractors, and Depth-Two Superconcentrators," SIAM Journal on Discrete Mathematics, vol. 13, no. 1, pp. 2–24, 2000.
- [5] B. Barak, Y. Dodis, H. Krawczyk, O. Pereira, K. Pietrzak, F.-X. Standaert, and Y. Yu, "Leftover Hash Lemma, Revisited," in *Advances in Cryptology CRYPTO 2011*. Springer, 2011, pp. 1–20.
- [6] R. Canetti, S. Halevi, and M. Steiner, "Mitigating Dictionary Attacks on Password-Protected Local Storage," in *Advances in Cryptology -*CRYPTO 2006. Springer, 2006, pp. 160–179.
- [7] I. Kaslasi, R. D. Rothblum, and P. N. Vasudevanr, "Public-Coin Statistical Zero-Knowledge Batch Verification Against Malicious Verifiers," in *Advances in Cryptology: EUROCRYPT 2021, Part III.* Springer, 2021, p. 219–246.
- [8] O. Goldreich, Computational Complexity: A Conceptual Perspective. Cambridge University Press, 2008.
- [9] N. Alon, L. Babai, and A. Itai, "A fast and simple randomized parallel algorithm for the maximal independent set problem," *Journal of Algorithms*, vol. 7, no. 4, pp. 567–583, 1986.
- [10] Z. Dvir and A. Wigderson, "Kakeya Sets, New Mergers and Old Extractors," in FOCS '08: Proceedings of the 2008 49th Annual IEEE Symposium on Foundations of Computer Science. IEEE Computer Society, 2008, pp. 625–633.
- [11] Z. Dvir, S. Kopparty, S. Saraf, and M. Sudan, "Extensions to the Method of Multiplicities, with Applications to Kakeya Sets and Mergers," SIAM Journal on Computing, vol. 42, no. 6, pp. 2305–2328, 2013.
- [12] M. Dhar, Z. Dvir, and B. Lund, "Simple proofs for Furstenberg sets over finite fields," *Discrete Analysis*, vol. 22, 2021.
- [13] O. Ordentlich, O. Regev, and B. Weiss, "New bounds on the density of lattice coverings," *Journal of the American Mathematical Society*, vol. 35, no. 1, pp. 295–308, 2022.
- [14] S. Kopparty, V. F. Lev, S. Saraf, and M. Sudan, "Kakeya-type sets in finite vector spaces," *Journal of Algebraic Combinatorics*, vol. 34, no. 3, pp. 337–355, 2011.
- [15] J. Carter and M. N. Wegman, "Universal classes of hash functions," Journal of Computer and System Sciences, vol. 18, no. 2, pp. 143–154, 1979.
- [16] K. Mehlhorn and U. Vishkin, "Randomized and deterministic simulations of PRAMs by parallel machines with restricted granularity of parallel memories," *Acta Informatica*, vol. 21, no. 4, pp. 339–374, 1984.
- [17] B. Green and I. Z. Ruzsa, "On the arithmetic kakeya conjecture of katz and tao," *Periodica Mathematica Hungarica*, vol. 78, no. 2, pp. 135–151, 2019

- [18] T. Wolff, "Recent work connected with the Kakeya problem," Prospects in mathematics, pp. 129–162, 1999.
- 19] Z. Dvir, "On the size of Kakeya sets in finite fields," *Journal of American Mathematical Society*, vol. 22, pp. 1093–1097, 2009.
- [20] T.-W. C. Boris Bukh, "Sharp density bounds on the finite field Kakeya problem," *Discrete Analysis*, 2021.
- [21] J. S. Ellenberg, R. Oberlin, and T. Tao, "The Kakeya set and maximal conjectures for algebraic varieties over finite fields," *Mathematika*, vol. 56, no. 1, pp. 1–25, 2010.
- [22] J. Ellenberg and D. Erman, "Furstenberg sets and Furstenberg schemes over finite fields," *Algebra & Number Theory*, vol. 10, no. 7, pp. 1415– 1436, 2016.
- [23] M. Dhar, Z. Dvir, and B. Lund, "Furstenberg sets in finite fields: Explaining and improving the Ellenberg-Erman proof," preprint arXiv:1909.02431, 2021.
- [24] M. Dhar, "Maximal Kakeya and  $(m,\epsilon)$ -Kakeya bounds over  $\mathbb{Z}/\mathbb{NZ}$  for general N," in preparation.