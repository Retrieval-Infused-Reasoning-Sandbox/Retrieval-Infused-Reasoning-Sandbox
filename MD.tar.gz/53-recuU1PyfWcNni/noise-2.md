Skip to main content

Springer Nature Link

Log in

Menu

Find a journal Publish with us Track your research

Search

☐ Cart

- <span id="page-0-0"></span>1. Home >
- 2. Acta Informatica >
- 3. Article

# Randomized and deterministic simulations of PRAMs by parallel machines with restricted granularity of parallel memories

- Published: November 1984
- Volume 21, pages 339–374, (1984)
- · Cite this article

![](_page_0_Picture_14.jpeg)

Acta Informatica Aims and scope Submit manuscript

- Kurt Mehlhorn 4 &
- <u>Uzi Vishkin<sup>2</sup></u>
- 158 Accesses

- 144 Citations •
- 3 Altmetric •
- [Explore all metrics](file:///article/10.1007/BF00264615/metrics)  •

## **Summary**

The present paper provides a comprehensive study of the following problem. Consider algorithms which are designed for shared memory models of parallel computation (PRAMs) in which processors are allowed to have fairly unrestricted access patterns to the shared memory. Consider also parallel machines in which the shared memory is organized in modules where only one cell of each module can be accessed at a time. *Problem*. Give general fast simulations of these algorithms by these parallel machines.

Each of our solutions answers two basic questions. (1) How to initially distribute the logical memory addresses of the PRAM, to be simulated, among the physical locations of the simulating machine? (2) How to compute the physical location of a logical address during the simulation?

We utilize two main ideas for the first question.

(a) 1.

> Randomization. The logical addresses are randomly distributed among the memory modules. This is done using universal hashing.

(b) 2.

Copies. We keep copies of each logical address in several memory modules.

In a typical time cycle of the PRAM some number of memory requests has to be satisfied. As a primary objective, our simulations minimize the maximum number of memory requests which are assigned to the same module. Our solutions also optimize the following computational resources. They minimize the size of the physical memory, the time for computing the mapping from logical to physical addresses and the space for storing this mapping.

We discuss extensions of our solutions to various PRAMs and various shared memory parallel machines. Our solution is also applicable to synchronous distributed machines with no shared memory where the processors can communicate through a bounded degree network.

This is a preview of subscription content, [log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2FBF00264615) to check access.

# **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2FBF00264615)

#### **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

## **Buy Now**

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals) 

## **Similar content being viewed by others**

![](_page_3_Picture_3.jpeg)

## **[Memory Checking for Parallel RAMs](https://link.springer.com/10.1007/978-3-031-48618-0_15?fromPaywallRec=true)**

#### Chapter © 2023

![](_page_3_Picture_6.jpeg)

## **[Oblivious Parallel RAM and Applications](https://link.springer.com/10.1007/978-3-662-49099-0_7?fromPaywallRec=true)**

#### Chapter © 2016

![](_page_3_Picture_9.jpeg)

**[SSC: An SRAM-Based Silence Computing Design for On-chip Memory](https://link.springer.com/10.1007/978-981-96-1545-2_4?fromPaywallRec=true)** 

Chapter © 2025

## **Explore related subjects**

Discover the latest articles, books and news in related subjects, suggested using machine learning.

- [Algorithms](file:///subjects/algorithms) •
- [Computer Memory Structure](file:///subjects/computer-memory-structure) •
- [Data Structures](file:///subjects/data-structures) •
- [Data Structures and Information Theory](file:///subjects/data-structures-and-information-theory) •
- [Mathematics of Computing](file:///subjects/mathematics-of-computing) •
- [Register-Transfer-Level Implementation](file:///subjects/register-transfer-level-implementation) •

## **References**

Aho, A.V., Hopcroft, J.E., Ullman, J.D.: The Design and Analysis of Computer Algorithms. Reading, MA: Addison-Wesley 1974 1.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=The%20Design%20and%20Analysis%20of%20Computer%20Algorithms&publication_year=1974&author=Aho%2CA.V.&author=Hopcroft%2CJ.E.&author=Ullman%2CJ.D.)

- Ajtai, M., Komlos, J., Szemeredi, E.: An *O*(*n* log *n*) sorting network. Proc. Fifteenth ACM Symposium on Theory of Computing, pp. 1–9, 1983 2.
- Awerbuch, B., Israeli, A., Shiloach, Y.: Efficient simulations of PRAM by Ultracomputer. (Preprint). Dept. of Computer Science, Technion, Haifa, Israel, 1983 [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Efficient%20simulations%20of%20PRAM%20by%20Ultracomputer&publication_year=1983&author=Awerbuch%2CB.&author=Israeli%2CA.&author=Shiloach%2CY.) 3.
- Carmichael, R.D.: Groups of finite orders. Dover: DoverPublications 1956 [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Groups%20of%20finite%20orders&publication_year=1956&author=Carmichael%2CR.D.) 4.
- Carter, J.L., Wegman, M.N.: Universal classes of hash functions. Proc. Nineth ACM Symposium on Theory of Computing, pp. 106–112, 1977 5.
- Even, S.: Graph Algorithms. Potomac, MD: Computer Science Press 1979 [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Graph%20Algorithms&publication_year=1979&author=Even%2CS.) 6.

- Goldschlager, L.M.: A Unified Approach to Models of Synchronous Parallel Machines. Proc. Tenth ACM Symposium on Theory of Computing, pp. 89–94, 1978 7.
- Gonnet, G.H.: Expected length of the longest probe sequence in hash code searching. JACM **28**, 289–304 (1981) 8.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Expected%20length%20of%20the%20longest%20probe%20sequence%20in%20hash%20code%20searching&journal=JACM&volume=28&pages=289-304&publication_year=1981&author=Gonnet%2CG.H.)

Gottlieb, A., Grishman, R., Kruskal, C.P., McAuliffe, K.P., Rudolph, L., Snir, M.: The NYU Ultracomputer-Designing, a MIMD Shared Memory Parallel Machine. IEEE Trans. Comput. c-**32**, 175–189 (1983) 9.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=The%20NYU%20Ultracomputer-Designing%2C%20a%20MIMD%20Shared%20Memory%20Parallel%20Machine&journal=IEEE%20Trans.%20Comput.&volume=c-32&pages=175-189&publication_year=1983&author=Gottlieb%2CA.&author=Grishman%2CR.&author=Kruskal%2CC.P.&author=McAuliffe%2CK.P.&author=Rudolph%2CL.&author=Snir%2CM.)

Kuck, D.J.: A survey of parallel machine organization and programming. Comput. Surveys **9**, 29–59 (1977) 10.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20survey%20of%20parallel%20machine%20organization%20and%20programming&journal=Comput.%20Surveys&volume=9&pages=29-59&publication_year=1977&author=Kuck%2CD.J.)

Lev, G., Pippenger, N., Valiant, J.G.: A fast parallel agorithm for routing in permuting networks. IEEE Trans. Comput. c-**30**, 93–100 (1981) 11.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20fast%20parallel%20agorithm%20for%20routing%20in%20permuting%20networks&journal=IEEE%20Trans.%20Comput.&volume=c-30&pages=93-100&publication_year=1981&author=Lev%2CG.&author=Pippenger%2CN.&author=Valiant%2CJ.G.)

Pippenger, N.: Superconcentrators. SIAM J. Comput. **6**, 298–304 (1977) 12.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Superconcentrators&journal=SIAM%20J.%20Comput.&volume=6&pages=298-304&publication_year=1977&author=Pippenger%2CN.)

Rabin, M.O.: Probabilistic algorithms. In: Algorithms and Complexity, J.F. Traub (ed.). New York: Academic Press 1976 13.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Probabilistic%20algorithms&publication_year=1976&author=Rabin%2CM.O.)

- Reif, J., Valiant, L.J.: A logarithmic time sort for linear size networks. Proc. Fifteenth ACM Symp. Theory Comput. pp. 10–16, 1983 14.
- Schwartz, J.T.: Ultracomputers. ACM Trans. Progr. Lang. Syst. **2**, 484–521 (1980) 15.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Ultracomputers&journal=ACM%20Trans.%20Progr.%20Lang.%20Syst.&volume=2&pages=484-521&publication_year=1980&author=Schwartz%2CJ.T.)

Shiloach, Y., Vishkin, U.: Finding the maximum, merging and sorting in a parallel computation model. J. Algorithms **2**, 88–102 (1981) 16.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Finding%20the%20maximum%2C%20merging%20and%20sorting%20in%20a%20parallel%20computation%20model&journal=J.%20Algorithms&volume=2&pages=88-102&publication_year=1981&author=Shiloach%2CY.&author=Vishkin%2CU.)

- Upfal, E.: A probabilistic relation between desirable and feasible models of parallel computation. Proc. Sixteenth ACM Symp. Theory Comput. 1984 (To appear) 17.
- Vishkin, U.: Parallel-Design space Distributed Implementation space (PDDI) general purpose computer. RC 9541, IBM T.J. Watson Research Center, Yorktown Heights, NY 10598, 1982. To appear in Theoretical Computer Science) 18.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Parallel-Design%20space%20Distributed%20%E2%80%94%20Implementation%20space%20%28PDDI%29%20general%20purpose%20computer&publication_year=1982&author=Vishkin%2CU.)

Vishkin, U.: Implementation of simultaneous memory address access in models that forbid it. J. Algorithms **4**, 45–50 (1983) 19.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Implementation%20of%20simultaneous%20memory%20address%20access%20in%20models%20that%20forbid%20it&journal=J.%20Algorithms&volume=4&pages=45-50&publication_year=1983&author=Vishkin%2CU.)

- Vishkin, U.: An optimal parallel algorithm for selection. (Preprint, 1983) 20.
- Vishkin, U., Wigderson, A.: Dynamic parallel memories. Information and Control **56**, 174–182 (1983) 21.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=Dynamic%20parallel%20memories&journal=Information%20and%20Control&volume=56&pages=174-182&publication_year=1983&author=Vishkin%2CU.&author=Wigderson%2CA.)

#### [Download references](https://citation-needed.springer.com/v2/references/10.1007/BF00264615?format=refman&flavour=references)

## **Author information**

#### **Authors and Affiliations**

- <span id="page-6-0"></span>Fachbereich 10, Universität des Saarlandes, D-6600, Saarbrücken (Fed. Rep.) Kurt Mehlhorn 1.
- <span id="page-6-1"></span>Courant Institute, New York University, 251 Mercer Street, 10012, New York, NY, USA Uzi Vishkin 2.

#### Authors

#### <span id="page-7-1"></span>Kurt Mehlhorn 1.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Kurt%20Mehlhorn)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Kurt%20Mehlhorn) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Kurt%20Mehlhorn%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### <span id="page-7-2"></span>Uzi Vishkin 2.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Uzi%20Vishkin)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Uzi%20Vishkin) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Uzi%20Vishkin%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

## **Rights and permissions**

[Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?title=Randomized%20and%20deterministic%20simulations%20of%20PRAMs%20by%20parallel%20machines%20with%20restricted%20granularity%20of%20parallel%20memories&author=Kurt%20Mehlhorn%20et%20al&contentID=10.1007%2FBF00264615©right=Springer-Verlag&publication=0001-5903&publicationDate=1984-11&publisherName=SpringerNature&orderBeanReset=true)

## **About this article**

#### <span id="page-7-0"></span>**Cite this article**

Mehlhorn, K., Vishkin, U. Randomized and deterministic simulations of PRAMs by parallel machines with restricted granularity of parallel memories. *Acta Informatica* **21**, 339–374 (1984). https://doi.org/10.1007/BF00264615

#### [Download citation](https://citation-needed.springer.com/v2/references/10.1007/BF00264615?format=refman&flavour=citation)

Received: 02 July 1984 •

Issue date: November 1984 •

DOI: https://doi.org/10.1007/BF00264615 •

#### **Keywords**

- [Shared Memory](file:///search?query=Shared%20Memory&facet-discipline=%22Computer%20Science%22) •
- [Parallel Machine](file:///search?query=Parallel%20Machine&facet-discipline=%22Computer%20Science%22) •
- [Access Pattern](file:///search?query=Access%20Pattern&facet-discipline=%22Computer%20Science%22) •
- [Memory Module](file:///search?query=Memory%20Module&facet-discipline=%22Computer%20Science%22) •

#### [Memory Address](file:///search?query=Memory%20Address&facet-discipline=%22Computer%20Science%22) •

# **Access this article**

#### [Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2FBF00264615)

## **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

## **Buy Now**

| article                                                                                                                          |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/BF00264615                                                                                                               |
| 1432-0525                                                                                                                        |
| Randomized and deterministic simulations of PRAMs by parallel machines with restricted granularity of parallel memories          |
| 1984                                                                                                                             |
|                                                                                                                                  |
| Kurt Mehlhorn, Uzi Vishkin                                                                                                       |
| Acta Informatica                                                                                                                 |
| af96ffbabcb05ce4f44e87e1d2e9d105f743bf4cb61afb613df90d2fcb029ad3f869cff42487273b8a50bf94363d15baf8e270ea1993256b09917d39af6b1557 |
| Buy article PDF 39,95 €                                                                                                          |

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

#### [Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals)

Advertisement

## <span id="page-9-1"></span>**Search**

| Search by keyword or author |  |  |
|-----------------------------|--|--|
|                             |  |  |
|                             |  |  |

Search

# <span id="page-9-0"></span>**Navigation**

- [Find a journal](https://link.springer.com/journals/)  •
- [Publish with us](https://www.springernature.com/gp/authors) •
- [Track your research](https://link.springernature.com/home/) •

#### **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

#### **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

#### **Products and services**

[Our products](https://www.springernature.com/gp/products) •

- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

## **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •
- [Accessibility statement](https://www.springernature.com/gp/info/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •
- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

[Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature