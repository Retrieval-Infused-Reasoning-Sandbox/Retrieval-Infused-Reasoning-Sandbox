#### Skip to main content

#### Advertisement

Springer Nature Link

Log in

Menu

Find a journal Publish with us Track your research

Search

<u> </u>

- 1. Home >
- 2. Randomization and Approximation Techniques in Computer Science
- 3. Conference paper

# "Balls into Bins" — A Simple and Tight Analysis

- Conference paper
- First Online: 01 January 1999
- pp 159–170
- Cite this conference paper

![](_page_0_Picture_16.jpeg)

Randomization and Approximation Techniques in Computer Science (RANDOM

1998)

- <span id="page-0-0"></span>• Martin Raab<sup>7</sup> &
- Angelika Steger<sup>7</sup>

Part of the book series: [Lecture Notes in Computer Science](https://link.springer.com/series/558) ((LNCS,volume 1518))

Included in the following conference series:

[International Workshop on Randomization and Approximation Techniques in](https://link.springer.com/conference/random) •

[Computer Science](https://link.springer.com/conference/random)

2930 Accesses •

288 Citations •

22 [Altmetric](https://link.altmetric.com/details/3701950) •

**Abstract**

Suppose we sequentially throw *m* balls into *n* bins. It is a natural question to ask for the maximum number of balls in any bin. In this paper we shall derive sharp upper and lower bounds which are reached with high probability. We prove bounds for all values of *m(n)* ≧

This is a preview of subscription content, [log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Fchapter%2F10.1007%2F3-540-49543-6_13) to check access.

*n*/polylog(*n*) by using the simple and well-known method of the first and second moment.

**Access this chapter**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Fchapter%2F10.1007%2F3-540-49543-6_13)

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/ebooks) 

**Preview**

Unable to display preview. [Download preview PDF.](file://page-one.springer.com/pdf/preview/10.1007/3-540-49543-6_13)

Unable to display preview. [Download preview PDF.](file://page-one.springer.com/pdf/preview/10.1007/3-540-49543-6_13)

## **Similar content being viewed by others**

## **[A Generalization of Multiple Choice Balls-into-Bins: Tight Bounds](https://link.springer.com/10.1007/s00453-016-0141-z?fromPaywallRec=true)**

#### Article 17 March 2016

## **[Self-stabilizing repeated balls-into-bins](https://link.springer.com/10.1007/s00446-017-0320-4?fromPaywallRec=true)**

Article Open access 18 December 2017

![](_page_2_Picture_7.jpeg)

## **[Balanced Allocation on Graphs: A Random Walk Approach](https://link.springer.com/10.1007/978-3-319-42634-1_27?fromPaywallRec=true)**

Chapter © 2016

## **Explore related subjects**

Discover the latest articles, books and news in related subjects, suggested using machine learning.

- [Combinatorics](file:///subjects/combinatorics) •
- [Combinatorial Geometry](file:///subjects/combinatorial-geometry) •
- [Discrete Mathematics in Computer Science](file:///subjects/discrete-mathematics-in-computer-science) •
- [Discrete Mathematics](file:///subjects/discrete-mathematics) •

- [Logical Analysis](file:///subjects/logical-analysis) •
- [Probability Theory](file:///subjects/probability-theory) •

# **References**

Y. Azar, A.Z. Broder, A.R. Karlin, and E. Upfal. On-line load balancing (extended abstract). In *33rd Annual Symposium on Foundations of Computer Science*, pages 218–225, Pittsburgh, Pennsylvania, 24–27 October 1992. IEEE. 1.

#### [Google Scholar](https://scholar.google.com/scholar?&q=Y.%20Azar%2C%20A.Z.%20Broder%2C%20A.R.%20Karlin%2C%20and%20E.%20Upfal.%20On-line%20load%20balancing%20%28extended%20abstract%29.%20In%2033rd%20Annual%20Symposium%20on%20Foundations%20of%20Computer%20Science%2C%20pages%20218%E2%80%93225%2C%20Pittsburgh%2C%20Pennsylvania%2C%2024%E2%80%9327%20October%201992.%20IEEE.)

B. Bollobás. *Random graphs*. Academic Press, New York-San Francisco-London-San Diego, 1985. 2.

#### [MATH](http://www.emis.de/MATH-item?0567.05042) [Google Scholar](https://scholar.google.com/scholar_lookup?&title=Random%20graphs&publication_year=1985&author=Bollob%C3%A1s%2CB.)

A. Czumaj and V. Stemann. Randomized allocation processes. In *38th Annual Symposium on Foundations of Computer Science*, pages 194–203, 1997. 3.

#### [Google Scholar](https://scholar.google.com/scholar?&q=A.%20Czumaj%20and%20V.%20Stemann.%20Randomized%20allocation%20processes.%20In%2038th%20Annual%20Symposium%20on%20Foundations%20of%20Computer%20Science%2C%20pages%20194%E2%80%93203%2C%201997.)

G.H. Gonnet. Expected length of the longest probe sequence in hash code searching. *J. ACM*, 28(2):289–304, 1981. 4.

#### [Article](https://doi.org/10.1145%2F322248.322254) [MATH](http://www.emis.de/MATH-item?0456.68067) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=612082) [Google Scholar](https://scholar.google.com/scholar_lookup?&title=Expected%20length%20of%20the%20longest%20probe%20sequence%20in%20hash%20code%20searching&journal=J.%20ACM&volume=28&issue=2&pages=289-304&publication_year=1981&author=Gonnet%2CG.H.)

N. Johnson and S. Kotz. *Urn Models and Their Applications*. John Wiley and Sons, 1977. 5.

#### [Google Scholar](https://scholar.google.com/scholar?&q=N.%20Johnson%20and%20S.%20Kotz.%20Urn%20Models%20and%20Their%20Applications.%20John%20Wiley%20and%20Sons%2C%201977.)

M.D. Mitzenmacher. *The Power of Two Choices in Randomized Load Balancing*. PhD thesis, Computer Science Department, University of California at Berkeley, 1996. 6.

[Google Scholar](https://scholar.google.com/scholar?&q=M.D.%20Mitzenmacher.%20The%20Power%20of%20Two%20Choices%20in%20Randomized%20Load%20Balancing.%20PhD%20thesis%2C%20Computer%20Science%20Department%2C%20University%20of%20California%20at%20Berkeley%2C%201996.)

#### [Download references](https://citation-needed.springer.com/v2/references/10.1007/3-540-49543-6_13?format=refman&flavour=references)

# **Author information**

## **Authors and Affiliations**

<span id="page-4-1"></span>Institut für Informatik, Technische Universität München, D-80290, München 1.

Martin Raab & Angelika Steger

#### Authors

<span id="page-4-0"></span>Martin Raab 1.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Martin%20Raab)

Search author on[:PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Martin%20Raab) [Google Scholar](http://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Martin%20Raab%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-4-2"></span>Angelika Steger 2.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Angelika%20Steger)

Search author on[:PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Angelika%20Steger) [Google Scholar](http://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Angelika%20Steger%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

# **Editor information**

## **Editors and Affiliations**

International Computer Science Institute, 1947 Center Street, Suite 600, Berkeley, CA, 94704-1198, USA 1.

Michael Luby

Computer Science Department, University of Geneva, 24, rue Général Dufour, CH-1211, Geneva 4, Switzerland 2.

José D. P. Rolim

University of Barcelona (UPC), Jordi Girona Salgado 1-3, E-08034, Barcelona, Spain Maria Serna 3.

# **Rights and permissions**

[Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?publisherName=SpringerNature&orderBeanReset=true&orderSource=SpringerLink&title=%E2%80%9CBalls%20into%20Bins%E2%80%9D%20%E2%80%94%20A%20Simple%20and%20Tight%20Analysis&author=Martin%20Raab%2C%20Angelika%20Steger&contentID=10.1007%2F3-540-49543-6_13©right=Springer-Verlag%20Berlin%20Heidelberg&publication=eBook&publicationDate=1998&startPage=159&endPage=170&imprint=Springer-Verlag%20Berlin%20Heidelberg)

# **Copyright information**

© 1998 Springer-Verlag Berlin Heidelberg

## **About this paper**

## <span id="page-5-0"></span>**Cite this paper**

Raab, M., Steger, A. (1998). "Balls into Bins" — A Simple and Tight Analysis. In: Luby, M., Rolim, J.D.P., Serna, M. (eds) Randomization and Approximation Techniques in Computer Science. RANDOM 1998. Lecture Notes in Computer Science, vol 1518. Springer, Berlin, Heidelberg. https://doi.org/10.1007/3-540-49543-6\_13

## **Download citation**

- [.RIS](https://citation-needed.springer.com/v2/references/10.1007/3-540-49543-6_13?format=refman&flavour=citation) •
- [.ENW](https://citation-needed.springer.com/v2/references/10.1007/3-540-49543-6_13?format=endnote&flavour=citation) •
- [.BIB](https://citation-needed.springer.com/v2/references/10.1007/3-540-49543-6_13?format=bibtex&flavour=citation) •
- DOI: https://doi.org/10.1007/3-540-49543-6\_13 •
- Published: 11 June 1999 •
- Publisher Name: Springer, Berlin, Heidelberg •
- Print ISBN: 978-3-540-65142-0 •
- Online ISBN: 978-3-540-49543-7 •
- eBook Packages: [Springer Book Archive](https://metadata.springernature.com/metadata/books) •

## **Keywords**

- [Binomial Distribution](file:///search?query=Binomial%20Distribution&facet-discipline=%22Computer%20Science%22) •
- [Moment Method](file:///search?query=Moment%20Method&facet-discipline=%22Computer%20Science%22) •
- [Load Balance Problem](file:///search?query=Load%20Balance%20Problem&facet-discipline=%22Computer%20Science%22) •
- [Tail Bound](file:///search?query=Tail%20Bound&facet-discipline=%22Computer%20Science%22) •
- [Chernoff Bound](file:///search?query=Chernoff%20Bound&facet-discipline=%22Computer%20Science%22) •

*These keywords were added by machine and not by the authors. This process is experimental and the keywords may be updated as the learning algorithm improves.*

## **Publish with us**

[Policies and ethics](https://www.springernature.com/gp/policies/book-publishing-policies)

# **Access this chapter**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Fchapter%2F10.1007%2F3-540-49543-6_13)

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/ebooks) 

# <span id="page-6-1"></span>**Search**

| Search by keyword or author |  |
|-----------------------------|--|
|                             |  |
|                             |  |
|                             |  |

Search

# <span id="page-6-0"></span>**Navigation**

- [Find a journal](https://link.springer.com/journals/)  •
- [Publish with us](https://www.springernature.com/gp/authors) •
- [Track your research](https://link.springernature.com/home/) •

## **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

## **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

## **Products and services**

- [Our products](https://www.springernature.com/gp/products) •
- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

## **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •
- [Accessibility statement](https://www.springernature.com/gp/info/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •
- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •

#### [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

[Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature