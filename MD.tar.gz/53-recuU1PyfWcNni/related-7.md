![](_page_0_Picture_0.jpeg)

# Is Linear Hashing Good?

Noga Alon\* Martin Dietzfelbinger<sup>†</sup> Peter Bro Miltersen<sup>‡</sup> Erez Petrank<sup>§</sup>
Gábor Tardos<sup>¶</sup>

## Abstract

Consider the set  $\mathcal{H}$  of all linear (or affine) transformations between two vector spaces over a finite field F. We study how good  $\mathcal{H}$  is as a class of hash functions, namely we consider hashing a set S of size n into a range having the same cardinality n by a randomly chosen function from  $\mathcal{H}$  and look at the expected size of the largest hash bucket.  $\mathcal{H}$  is a universal class of hash functions for any finite field, but with respect to our measure different fields behave differently.

If the finite field F has n elements then there is a bad set  $S \subset F^2$  of size n with expected maximal bucket size  $\Omega(n^{1/3})$ . If n is a perfect square then there is even a bad set with largest bucket size always at least  $\sqrt{n}$ . (This is worst possible, since with respect to a universal class of hash functions every set of size n has expected largest

\*Dep. of Math., Sackler Faculty of Exact Sciences, Tel Aviv University, Tel Aviv, Israel and Institute for Advanced Study, Princeton, NJ 08540. Research supported in part by a USA-Israeli BSF grant, by the Sloan Foundation grant No. 96-6-2 and by an NEC Research Institute grant. E-mail: noga@math.tau.ac.il.

†Fachbereich Informatik, Lehrstuhl II, Universität Dortmund, D-44221 Dortmund, Germany. E-mail: dietzf@ls2.informatik.uni-dortmund.de. Partially supported by DFG grant Di 412/5-1.

<sup>‡</sup>BRICS, Centre of the Danish National Research Foundation, University of Aarhus, Ny Munkegade, Aarhus, Denmark. Supported by the ESPRIT Long Term Research Programme of the EU under project number 20244 (ALCOM-IT). E-mail: bromille@brics.dk. Part of this work was done while the author was at the University of Toronto.

§DIMACS, P.O.Box 1179, Piscataway, NJ 08855-1179, USA. E-mail: erez@dimacs.rutgers.edu. Part of this work was done while the author was visiting the University of Toronto.

Mathematical Institute of the Hungarian Academy of Sciences, Pf. 127, Budapest, H-1364 Hungary and Institute for Advanced Study, Princeton, NJ 08540. Supported by NSF grants CCR-95-03254 and DMS-9304580, a grant from Fuji Bank and the grant OTKA-F014919. E-mail: tardos@cs.elte.hu. Part of this work was done while the author was visiting the University of Toronto.

Permission to make digital/hard copies of all or part of this material for personal or classroom use is granted without fee provided that the copies are not made or distributed for profit or commercial advantage, the copyright notice, the title of the publication and its date appear, and notice is given that copyright is by permission of the ACM. Inc. To copy otherwise, to republish, to post on servers or to redistribute to lists, requires specific permission and/or fee

STOC '97 El Paso, Texas USA

Copyright 1997 ACM 0-89791-888-6/97/05 ...\$3.50

bucket size below  $\sqrt{n} + 1/2$ .)

If, however, we consider the field of two elements then we get much better bounds. The best previously known upper bound on the expected size of the largest bucket for this class was  $O(2^{\sqrt{\log n}})$ . We reduce this upper bound to  $O(\log n \log \log n)$ . Note that this is not far from the guarantee for a random function. There, the average largest bucket would be  $O(\log n / \log \log n)$ .

In the course of our proof we develop a tool which may be of independent interest. Suppose we have a subset S of a vector space D over  $\mathbb{Z}_2$ , and consider a random linear mapping of D to a smaller vector space R. If the cardinality of S is larger than  $c_{\epsilon}|R|\log|R|$  then with probability  $1-\epsilon$ , the image of S will cover all elements in the range.

## 1 Introduction

#### 1.1 Results

The seminal paper of Carter and Wegman [CW79] introduced the concept of universal hashing. The setting is as follows. A class  $\mathcal{H}$  of hash functions, each mapping a universe U to  $\{1,2,\ldots,s\}$ , is fixed. A set  $S\subseteq U$  to be hashed is given, a member  $h\in\mathcal{H}$  is chosen uniformly at random, and S is hashed using h. Carter and Wegman defined a class  $\mathcal{H}$  to be universal if

$$\forall x \neq y \in U : \text{Prob}(h(x) = h(y)) \leq 1/s.$$

Carter and Wegman showed that if |S| = s, any particular element of S is expected to end up in a bucket of size O(1). A simple calculation shows that the expected largest bucket size is less than  $\sqrt{s} + 1/2$ . Unfortunately universality does not imply anything stronger. It is not hard to construct a twisted example of a universal class of hash functions with expected largest bucket size above  $\sqrt{s}$ . It is perhaps more surprising that innocent looking, simple and seemingly practical classes can have this bad property for some subsets of the keys as we will show in Section 2. Our main result however is to prove that linear transformations over  $\mathbb{Z}_2$  form a

<sup>&</sup>lt;sup>1</sup>We remark that a stricter definition is often used in the complexity theory literature, and a more liberal definition is often used in the data structure literature. Our results apply to all variants of the definition.

class of hash functions behaving almost optimally for the worst case expected largest bucket size measure.

Let us be more precise. Let U be the universe from which the keys are chosen. We fix a class 'H mapping U to {1, . . ..s}. Then, a set S ~ U of size n is chosen by an adversary, and we uniformly at random pick a hash function h c 7-i, hash S using h and look at the size of the largest resulting haah bucket. We denote the expectation of this size by L:. Formally,

$$L_n^s(\mathcal{H}) = \max_{S \subseteq U, |S| = n} E_{h \in \mathcal{H}} [\max_{y \in \{1, \dots, s\}} |\{x \in S \mid h(x) = y\}|]$$

Usually we think ofs being of size close ton. Note that ifs = i2(n2), any universal class yields L; = O(l).

The CISSSH we will consider is the set of linear maps between Fm ~ Fk for m > k. Here F is a finite field and s = IF lk. This class is universal for all values of the parameters.

In Section 2 we show that in case of a big finite field, more precisely when k = 1 and thus IF I = s the expected largest bucket can be large.

Theorem 1 Let F be a finite field with IFI = s. For the class Z of all linear transformations F2 ~ F we have

$$L_s^s(\mathcal{H}) = \Omega(s^{1/3}).$$

Furthermore if IF I is a perfect square we have

$$L^s(\mathcal{H}) > \sqrt{s}$$

Note how close our lower bound for quadratic fields is to the upper bound of V + 1/2 that holds for every universal class. We also mention that for the bad set we construct in Theorem 4 for a quadratic field there is no good hash function, since there always exists a bucket of size at least G.

In Section 3 and thereafter, we concentrate on the F = **Z2 case.** For this class, Markowsky, Carter and Wegman [MCW78] showed that L~(7f) = 0(s1/4). Mehlhorn and Vishkin [MV84] improved on this result (although this is implicit in their paper) and showed that L:(H) = 0(2@). We further improve the bound and show that:

Theorem 2 For the class X of all linear transformations between two vector spaces over Z2,

$$L_{\bullet}^{s}(\mathcal{H}) = O(\log s \log \log s).$$

Furthermore, we also show that even if the range is smaller than ISI by a logarithmic factor, the same still holds:

Theorem 3 For the class 7i of all linear transformations between two vector spaces over Z2,

$$L_{s \log s}^{s}(\mathcal{H}) = O(\log s \log \log s)$$

Note that even if one uses the class R of *all* functions one obtains only a slightly better result: the expected size of the largest bucket in this case is L: ('R) = @(logs/ log logs) and L; log, (%2) = @(log s), Which is the best possible bound for any class.

We do not know what the right bound is for the class of linear mappings, i.e., is it as good as O(logs/ log log s)? We leave this as an open question.

### 1.2 Motivation

There is no doubt that the method of implementing a dictionary by hashing with chaining, recommended in textbooks [CLR90, GBY90] especially for situations with many update operations, is a practically important scheme.

In situations in which a good bound on the cost of single operations is important, e. g., in real-time applications, the expected maximal bucket size as formed by all keys ever present in the dictionary during a time interval plays a crucial role. Our results show that, at least as long as the size of the hash table can be determined right at the start, using a hash family of linear functions over 22 will perform very well in this respect. For other simple hash classes such bounds on the worst case bucket size are not available or are even wrong (see Theorem 4); other, more sophisticated hash families [S89, DM90, DGMP92] that do guarantee small maximal bucket sizes consist of functions with higher evaluation time. Of course, if worst case constant time for certain operations is absolutely necessary, the known two-level hashing schemes can be used, e. g., the FKS scheme [FKS84] for static dictionaries; dynamic perfect hashing [DKMHRT94] for the dynamic case with constant time lookups and expected time O(n) for n update operations; and the "real-time dictionaries" from [DM90] that perform each operation in constant time, with high probability. It should be noted, however, that a price is to be paid for the guaranteed constant lookup time in the dynamic schemes: the (average) cost of insertions is significantly higher than in simple schemes like chained hashing; the overall storage requirements are higher as well.

### 1.3 Related work

Another direction in trying to show that a specific class has a good bound on the expected size of the largest bucket is to build a class specifically designed to have such good property.

One immediate such result is obtained by looking at the class of d-degree polynomials over finite fields, where d = clog n/ log log n (see, e.g., [AB186].) It is easy to see that this class maps each d elements of the domain independently to the range, and thus, the bound that applies to the class of all functions also applies to this class.

We can combine this with the following well known construction, (which is usually called "collapsing the universe" ) : At the expense of ~(log n+log log IU [) random bits one can construct a mapping g : U ~ {1,..., nk+2} that on any set S will be one-to-one with probability 1 – 0(1/rz~). This gives us a class with L: = @(log n/ log log n) of size 2 O(logloglUl+loga nl 10g10gn) and with evaluation time O(log n/ log log n) in a reasonable model of computation, say, a RAM with unit cost operations on members of the universe to be hashed.

More efficient (but much larger) families where given by Siegel [S89] and by Dietzfelbinger and Meyer auf der Heide [DM90]. Both provide families of size IU['" such that the functions can be evaluated in O(1) time on a RAM and with L; = ~(log n/ log log n). The families from [S89] and [DM90] are somewhat complex to implement while the class of linear mappings requires only very basic bit operations (as discussed already in [CW79]). It is therefore desirable to study this class, and this is the main purpose of the present paper.

#### 1.4 Notation

If S is a subset of the domain D of a function h we use h(S) to denote {h(s) I s E S}. If z is an element of the range we use h-l(z) to denote {s E D I h(s) = z}. If A and B are subsets of a vector space V and x E V we usethenotations A+ B= {a+ bla EAAb GB} and z+A = {z+a ]a~A}. We use Z2 to denote the two element field. All logarithms in this paper are base two.

# <sup>2</sup> **Linear hashing over a large field**

We start by showing why linear hashing over a large finite field is bad with respect to our expected largest bucket size measure. This natural example shows that universality of the class is not enough to assure small buckets. For a finite field F we prove the existence of a bad set S C F2 of size [Sl = [Fl such that the expected largest bucket in S with respect to random linear map F2 \* F is big. We prove the results in Theorem 1 separately for quadratic and non-quadratic fields.

Before the proofs we start with an intuitive description of the constructions. Linear hashing of the plane collapses all straight lines of a random direction. Thus, a bad set in the plane must contain many points on at least one line in many different directions. It is not hard to come up with bad sets that contain many points of many different lines, however the obvious constructions (subplane or grid) yield sets where many of the "popular lines" tend to be parallel and thus they only cover a few directions. This problem can be solved by a projective transformation, the transformed set has many popular

lines, but they are no longer parallel.

Theorem 4 Let F be a finite field with [Fl being a perfect square. There exists a set S c F2 of size ISI = IFI such that for evey linear map h : F2 + F, S has a large bucket, i.e. there exists a value y E F with I{z6S I h(z) =y}l ~ ~.

Proof. We have a finite field F. of which F is a quadratic extension. Let IFOI = m and IFI = m2 = n. Let a be an arbitrary element in F \ FO and define S = {(~, ~) I ~,Y E f'o}. Note that ISI = mz = **P'1.** Notice also, that S is the image of the subplane F; under the projective transformation (z, g) + (&, ~).

Fix A, B E F and consider the function h : F2 H F defined by h(z, V) = Ax+ By. We must show that there is some C E F such that [h-l(C) fl SI ~ m. If I? = O then h maps all the m elements of S' = {(l/a, y/a I y c Fo} to C = A/a, as needed. Otherwise, we claim that there is a C c F such that both ~ and ~ are in Fo. To see this observe that if gl and gz are two distinct members of FO, then agl and ag2 lie in distinct additive cosets of F. in F, since otherwise their difference, a(gl – gz) would have been in Fo, contradicting the fact that a @ F.. Thus, as g ranges over all members of FO, ag intersects distinct additive cosets of Fo in F, and hence aFo intersects all those cosets. In particular, there is some g E FO so that ag E FO+ ~, implying that C = gB satisfies the assertion of the claim. For the above C, for every choice of z E Fo, y(z) = ~z i- ~ ~ Fo. We have now A\* + B% = C, showing that h maps all the m elements of S' = {(-&, ~) I z 6 Fo} C S to c. •1

Theorem 5 Let F be a jinite *field.* There exists a set S c F2 of size ISI = IFI such that for more than ha~ of the linear maps h : F2 ~ F, S has a large bucket, i.e. there ezists a value y E F with I{z E S I h(z) = y}l ~ [F1'13/3 -1.

Proof. First we construct a set S' C F2 such that IS'I s IFI = n and there are n distinct lines in the plane F2 each wntaining at least m > n~f3/3 points of S'.

Let us first consider the case when n is a prime, so F consists of the integers modulo n. We let A = {i I 1 s i < W} and consider the square grid S' = A x A. Clearly 1S'I < n. It is well known that each of the n most popular lines contains at least m ~ n113/3 points of S'. This is usually proved for the same grid in the Euclidean plane (see e.g. [PA95], pp. 178-179)) but that result implies the same for our grid in F2.

Now let n = pk and let F. be the subfield in F of p elements. Let z E F be a primitive element, then every element of F can be uniquely expressed as a polynomial of z of degree below k with coefficients from F.. Let kl=[~],kz=k– kl = [~j and let Al = {f(~) I deg(~) < kl}, AZ = {f(z) I deg(~) < kz} where the polynomials .f have coefficients from FO. Finally we take S' = Al x Az. Clearly IS'I = n. For a c Al and b E AZ we consider the line L.,b = {(y, ay + b) I y E F} in F2. Notice that there are n such lines and we have ay + b E A2 whenever y E Al. Thus, we have n distinct lines each containing m = IA11 = pk~ points of S'. We have m > nli3 as claimed unless k s 1 (mod 3). Notice that for k ~ 2 (mod 3) our m is much higher than nli3. For the bad case k s 1 (mod 3) we apply the construction below instead.

Finally suppose n = pk, p is a prime and k s 1 (mod 3). To get our set S' in this case we have to merge the two constructions above. Let F. be the p element subfield of F, then F. consists of the integers modulo p. Weset A={ill< i~fi}. Letkl= (k+2)/3 and k2 = (2k + 1)/3 and let z E I' be a primitive element, so we can express any element of F uniquely as a polynomial of z of degree less then k with coefficients from Fo. We set Al = {f(z) I deg(~) < kl **A** f(0) E A}, A2 = {f(z) I deg(~) < k2 **A** f(0) E A} where the polynomials j have coefficients from F.. Finally we set S' = Al XAZ. Clearly IS' I s n. For j,j' E FO let Lj)ji = {(i, ji + j') I i E Fe}. Let a and b be polynomials with coefficients from F. with deg(a) < kl and deg(b) < k2. Consider the line La,b = {(y, a(z)y+b(z)) I y E F}. N@ tice that IL.,6 fl S'1 = pk'-l lLaIoJ,b(oJ il (A x A)l. Thus, from knowing that the p most popular lines in Fj contain at least m. ~ pli3/3 points from A x A we conclude that there exist n distinct lines each containing at least *k -I > n~/3js* points of S. m=m(lp' \_

In all cases now we have constructed our set S' C F2 of size IS'I ~ n with n distinct popular lines each containing at least m > nli3/3 points of S. Let P be the projective plane containing F2. Out of the n2 + n + 1 points in P every popular line covers n + 1. The ith popular line (1 < i ~ n) can only have i – 1 intersections with earlier lines thus it covers at least n + 2 – i points previously uncovered. Therefore a total of at least ~~2) – 1 points are covered by popular lines. Simple counting gives the existence of a line L in P not among the popular lines, such that more than half of the points on L are covered by popular lines. Let j be a pr~ jective transformation taking the ideal line L' = P \ F2 to L. We define S = {z E F2 I f(z) c S'}. Clearly ISI ~ IS'1 ~ n.

One linear hash function h : F2 4 F is constant zero (and thus all of S is a single bucket), for the rest there is a point xh E L' such that h collapses the points of F2 of each single line going through Zh. As we get all points of L' equal number of times (n – 1 times to be precise) it is enough to prove that whenever *f (Xh )* is covered by a popular line S has a big bucket with respect to h as claimed. So suppose *f (zh )* is in the popular line L". As L" contains at least *m* points of S' thus ~-1 (L") must

be a line through xh containing at least m – 1 points of S (the – 1 comes from the possibility of ~(z~ ) E S'). This ensures a bucket of S with respect to h of size at least m – 1 as claimed. ❑

# **3 Linear hashing over Z2—an overview of the upper bound**

In case we consider linear maps over the two element field we can prove good upper bounds on the expected largest bucket size. The rest of the paper is devoted to this proof. Here we give an overview.

We have to bound the probability of the event that many elements in the set S are mapped to a single element in the range. Denote this bad event by El. The overall idea is to present another (less natural) event E2 and show that the probability of E2 is small, yet the probability of E2 given El is big. Thus, the probability of El must be small. We remark here that a somewhat similar line of reasoning was used in the seminal paper of Vapnik and Chervonenkis [VC71].

This main line of the proof is presented in Section 5. In order to show these lower and upper bounds on the probability, we use the following tool which may be of independent interest.

Let S be a subset of a vector space D over 22 and choose a random linear mapping from D to a smaller vector space R. We show that if the cardinality of S is at least c, IRI log IRI then with probability at least 1 – e the image of S covers the entire range R. This is shown in Section 4.

# **4 A covering property of linear transformat ions**

#### 4.1 **The existential case**

We start by showing that if we have a large enough subset A of a vector space over 22 then there exists a linear transformation T to a large vector space such that T(A) is the entire range. The constant e below is the base of the natural logarithm.

Theorem 6 Let A be a jinite set of vectors in a vector space V of an arbitrary dimension over 22 and let t >0 be an integer. *If* IAI > t2t/ loge then there exists a linear mapping T : V h Z;, so that T maps A onto Z;.

Up to a constant factor this result is tight, as shown by the following proposition (in which the constant 8 can be improved).

Proposition 4.1 For every integer i? there is a set A of at least t2t/8 vectors in a vector space V over 22 so that for any linear mapping  $T: V \to \mathbf{Z}_2^t$ , T does not map A onto  $\mathbf{Z}_2^t$ .

**Proof:** Let  $V = Z_2^{t+\lfloor \log t \rfloor - 1}$  and let A be chosen at random by picking each element of V independently and with probability 1/2 into the set. With probability at least 1/2, A will have cardinality at least  $2^{t+\lfloor \log t \rfloor - 2}$ . Let us compute the probability that there exists a linear map  $T: V \to \mathbf{Z}_2^t$  such that T maps A onto  $\mathbf{Z}_2^t$ . There are  $2^{t\cdot (t+\lfloor \log t \rfloor - 1)}$  possible mappings and each of them covers  $\mathbf{Z}_2^t$  with probability at most  $\left(1 - 2^{-2^{\lfloor \log t \rfloor - 1}}\right)^{2^t}$ . So with probability almost 1/2, A is not small and still cannot be covered.

We omit the proof in this extended abstract.

In order to prove Theorem 6 we need the following simple lemma. Note that although we state the lemma for vector spaces, it holds for any finite group.

**Lemma 4.2** Let V be a finite vector space,  $A \subseteq V$ ,  $\alpha = 1 - |A|/|V|$ . Then for a random  $v \in V$  it holds that

$$E_v(1-|A\cup(v+A)|/|V|)=\alpha^2.$$

**Proof.** If v and u are both chosen uniformly independently at random from V then both events  $u \notin A$  and  $u \notin v + A$  have probability  $\alpha$  and they are independent.  $\square$ 

**Proof of Theorem 6.** Let m be the dimension of V, N = |A| and  $\alpha = 1 - |A|/|V| = 1 - N/2^m$ . Starting with  $A_0 = A$ , we choose a vector  $v_1 \in V$  so that for  $A_1 = A_0 \cup (v_1 + A_0)$ 

$$1 - \frac{|A_1|}{|V|} \le \alpha^2.$$

Such a choice for  $v_1$  exists by Lemma 4.2. Then, by the same procedure, we choose a  $v_2$  so that for

$$A_2 = A_1 \cup (v_2 + A_1) = A + \operatorname{Span}\{v_1, v_2\},$$
 
$$1 - \frac{|A_2|}{|V|} \le \alpha^4,$$

and so on up to  $A_s = A + \text{Span}\{v_1, \ldots, v_s\}$  with s = m - t for which

$$1-\frac{|A_s|}{|V|}\leq \alpha^{2^s}.$$

Note that one can assume that the vectors  $v_1, \ldots, v_s$  are linearly independent since choosing a vector  $v_i$  which depends on the previous choices makes  $A_i = A_{i-1}$ .

We now claim that  $A_s = V$ . Suppose in way of contradiction that  $A_s \neq V$ . Take a vector  $v \in V$  outside  $A_s$ , then  $v + \operatorname{Span}\{v_1, \ldots, v_s\}$  is disjoint from  $A_s$  thus

$$1-\frac{|A_s|}{|V|}\geq 2^s/2^m.$$

Combining the last two inequalities and recalling that t = m - s we get

$$2^{-t} \le \alpha^{2^t} = (1 - N/2^m)^{2^t} < e^{-N2^{-t}}$$

Taking the logarithm of both sides yields  $-t < -N \log_2 e/2^t$  contradicting our assumption on N. Thus,  $A_s = V$  must hold.

Now we choose a linear mapping  $T: V \to \mathbf{Z}_2^t$  such that its kernel  $T^{-1}(0) = \operatorname{Span}\{v_1, \ldots, v_s\}$ . The equality  $V = A_s = A + \operatorname{Span}\{v_1, \ldots, v_s\}$  implies that T maps A onto  $\mathbf{Z}_2^t$ .  $\square$ 

### 4.2 Choosing the linear mapping at random

In this subsection we strengthen Theorem 6 and prove that if A is bigger by a constant factor, then almost all choices of the linear transformation T work. This may seem immediate at first glance since Lemma 4.2 tells us that a random choice for the next vector is good on average. In particular, it might seem that for a random choice of  $v_1$  and  $v_2$  in the proof of Theorem 6,  $E_{v_1,v_2}(1 |A + \operatorname{Span}\{v_1, v_2\}|/|V| \le \alpha^4$ . Unfortunately this is not the case: For example, think of A being a linear subspace containing half of V. In this case, the ratio  $\alpha$ of points that are not covered is 1/2. As random vectors  $v_i$  are chosen to be added to A, vectors in A are chosen with probability 1/2. Thus, after i steps,  $\alpha$  remains 1/2with probability  $1/2^i$  and becomes 0 otherwise. Thus, the expected value of  $\alpha_i$  is  $2^{-i-1}$  which is much bigger than  $2^{-2}$ .

Theorem 7 For every  $\epsilon > 0$  there is a constant  $c_{\epsilon} > 0$  such that the following holds. Let A be a finite set of vectors in a vector space V of an arbitrary dimension over  $\mathbb{Z}_2$ , let t > 0 be an integer and  $0 < \epsilon < 1$ . If  $|A| \ge c_{\epsilon}t2^t$  then for a uniform random linear transformation  $T: V \to \mathbb{Z}_2^t$ 

$$Prob(T(A) = \mathbf{Z}_2^t) > 1 - \epsilon.$$

Proof: Let N = |A|,  $m = \lceil \log_2(3N/\epsilon) \rceil$ , and s = m - t. Consider the vector space  $W = \mathbf{Z}_2^m$ . Instead of choosing the transformation T uniformly at random, we choose T in two steps, which imply the same distribution on T: First, we pick uniformly at random a linear transformation  $T_0: V \to W$ . Then, we pick a random onto (full rank) linear mapping  $T_1: W \to \mathbf{Z}_2^t$ , and set  $T = T_0 \circ T_1$ . This results in a uniformly chosen linear mapping  $T: V \to \mathbf{Z}_2^t$ . In order to pick the onto mapping  $T_1$  we use the following process (similar to the one in the proof of Theorem 6). Pick s vectors  $v_1, \ldots, v_s$  uniformly at random from the vectors in W and choose  $T_1: W \to \mathbf{Z}_2^t$  to be a random onto linear transformation  $T_1: W \to \mathbf{Z}_2^t$  with the constraints  $T_1(v_i) = 0$ 

(i= 1,... ,.s), i.e. the vectors Vl, . . . ,v, are in the kernel of T1. Note that the vi's are not necessarily linearly independent and that they are not necessarily all the vectors in the kernel. After picking them, an onto transformation satisfying that the ~i's are in the kernel is chosen at random. The transformation T1 is indeed distributed uniformly at random amongst all onto linear mapping of W onto Z; since each possible kernel is chosen with equal probability, and given the kernel, the choice of the transformation is uniform.

Using notations similar to the ones used in the proof of Theorem 6 (but note the difference in the definition of Ao), let A. = TO(A), Ai = A. + Span{ vi, . . .,~i} and ~i = 1 – lAil/lWl for i = O, . . .,s. Observe that since IW I = 2m and as = 1 – lA81/W, showing a, < l/2m implies A. = W. In this case (as in the proof of Theorem 6) 7'1(Ao) = Zj and therefore T(A) = Z\. So we only have to show that

$$\operatorname{Prob}(\alpha_s < 2^{-m}) \ge 1 - \epsilon$$

where the probability is taken over the choices of To and T1 .

We first claim that Prob(lAOl s IV/2) < c/3. Since the transformation To maps any two distinct vectors from V to the same point with probability 2-m < e/(3iV), the expected number of such colliding pairs from A is (~)/2m < eN/6. In the event IAoI s ~/2, we have at lesst N/2 such colliding pairs, thus this event happens with probability at most ~/3. We regard this small chance event an "error" and concentrate on the A. > N/2 case. In this case, we have a. <1 – N/2m+1 < 1 – c/12.

Clearly ~i is nonnegative and monotone decreasing in i. We want to measure how fast ~i is decreasing. Imagine the vectors vl, . . . . V8 being chosen one by one and consider VI, . . . . vi fixed and thus ~i determined. By Lemma 4.2

$$E(\alpha_{i+1}) = \alpha_i^2. \tag{1}$$

Following the (simple) idea in [ABM87], we want to say that the choice of vi+ 1 is successful if ~i+l is small enough with respect to cq. The decrease of ~i is different depending on ai being greater or less than 1/2. Therefore, let us call the choice of t)i+l successfd if either ~i ~ 1/2 and 1 – tii+l ~ 5(1 – ~i)/4 or if ~i < 1/2 and ai~l < 3~i/4.

We first claim that given any choice of q, . . . . vi the choice of vi+l is successful with probability more than 1/3. For ~i < 1/2 this is immediate from Equation (l). In case ai ~ 1/2 the expected decrease is still the same, and in order to apply Markov's Inequality, one has to notice that since Ai+l = Ai **U** (Ai + vi+l ) we have /Ai+ll < 21Ail and thus 1- ~i+l ~ 2(1 - ~i).

Now we have a series ofs decreasing numbers {cti}~=l which decrease "a lot" in each step with high probability. We will show that with high probability as is quite

small, i.e., less than 2–m. Let C '~f 12/t. We partition the analysis into two parts, first checking the probability that ~i gets from as high as 1 – l/C' to below l/(2C2) in so 'Sf 138 log c] steps. Then, we check the probability that in the remaining s– so steps we get that CY,< 2-m.

Applying Chernoff's bound (similarly to Corollary A.7 in Appendix A of [AS92]) implies that the probability that we do not have at least 9 log C successful choices out of the choices of VI, . . . . V80 is at most c/3.

We regard this small probability event as another error and we concentrate on the case none of the two errors happens. In that case we have cro < 1 – l/C and the 9 log C successful choices reduce this number below l/(2C2) thus we have a80 < l/(2C2).

Finally for i = 1,..., s — so we call the choice of va,+i a jailure if ~30+i > Ci~~O+i\_l. By Markov's Inequality and Equation (1) we get that for any choice Ofvl, ..., v~O+i\_I the failure probability of vSO+~is less than l/Ci. Thus, the probability of ever encountering this kind of failure is below c/3.

So if failure never occurs one has

$$C^{i+2}\alpha_{s_0+i} \le (C^{i+1}\alpha_{s_0+i-1})^2$$

for every i= 1,. , . ,s – so. Thus, we must have

$$\alpha_s < C^{s-s_0+2}\alpha_s < (C^2\alpha_{s_0})^{2^{s-s_0}}.$$

If in addition none of the first two type of errora occurs we have C2a\*0 < 1/2 thus as < 2-2s-s0.

So to prove Prob(a\$ < 2-M) ~ 1 – c as needed we only have to show that 28-S0 ~ m. Using the formulae defining s, so and m this is implied by the bound N ~ C3st 2t. Thus, the choice c, = C38 satisfies the statement of the theorem. ❑

## **5 The main result**

Let us now recall and prove our main result. For convenience here we speak about hashing n log n keys to n values. Also, we assume that n is a power of 2.

Theorem 3: Let 'H be the class of linear transformations between two vector spaces over 22, then

$$L_{n\log n}^{n}(\mathcal{H}) = O(\log n \log \log n).$$

This theorem implies Theorem 2.

For the proof we fix the domain to be D = Z?, the range (the buckets) to be B = Z~g", and S C D of size ISI = nlogn.

Let us choose arbitrary I > log n and consider the space A = Z;. We construct the linear transformation h : D - B through the intermediate range A in the following way. We choose uniformly at random a linear transformation hl : D -t A and uniformly at random an onto linear transformation h2 : A - B. Now we define *h '~f hl o hz.* Note that as mentioned in the proof of Theorem 7 this yields an h which is uniformly chosen between all linear transformations from D to B.

Let us fix a threshold t. We define two events. El is the existence of a bucket of size at least t:

Event El: There exists an element a c B such that

$$\left|h^{-1}(\alpha)\cap S\right|>t.$$

We are going to limit the probability of El through the seemingly unrelated event E2:

Event E2: There exists an element a E 1? such that

$$h_2^{-1}(\alpha) \subseteq h_1(S)$$

Consider the distribution space in which hl and hz are uniformly chosen as above. We shall show that

Proposition 5.1 If for some c >0 atholds that 2! ~ (c,+ l)n logn (for the c, guaranteed by Theorem 7) then

$$Prob[E_2] \leq \epsilon$$
.

Proposition 5.2 Ift> c112(2t/n) log(2~/n) (with C112 from Theorem 7) then

$$\operatorname{Prob}[E_2|E_1] \ge \frac{1}{2}.$$

From Propositions 5.1 and 5.2 we deduce that the probability of El must be small:

Corollary 5.3 For evey c > 0 there is a constant d, such that for evey n (which **is** a power of 2) a random linear transformation hashing a subset S of a Z2 vector *space of size* IS1 = nlogn to Z~gn we have

Prob[maximum bucket size ~ d, log n log log n] < e.

Proofi We set 1 = Pog n + log log n + log(c, + 1)1 to satisfy the condition of Proposition 5.1. Then we set t(n) = fc1i2(2t/n) log(2~/n)l = O(log n log log n) to satisfy the condition of Proposition 5.2. Thus, we have Prob[E1] ~ 2c. Thus any choice for dzt satisfying t(n) ~ d2Clog n log log n is good. Since c >0 was arbitrary this proves our corollary. ❑

Let us now prove the propositions above.

Proof of Proposition 5.1: Note first that an alternative way to describe E2 is

$$h_2(A \setminus h_1(S)) \neq B$$

We will prove that Proposition 5.1 holds for any specific hl, and thus it also holds for a randomly chosen hl. so fix hl and consider the distribution in which hz is chosen uniformly amongst all full rank linear transformation from A to B.

Clearly, lhl(S)l < ISI = nlogn and thus lA\hl(S)j ~ 2f – n log n z c,n log n. By Theorem 7, a uniformly chosen hz does not satisfy h2(A \ hl (S)) = B with probability at most c, and we are done with the proof of Proposition 5.1. Note that in Theorem 7 one chooses a random element from all linear mapping and here we choose a full rank mapping but this only decreases the probability of not covering since none of the excluded mappings can cover. ❑

Proof of Proposition 5.2: Fix h for which El holds, and fix any full rank h2. We will show that the probabilityy of event E2 is at least 1/2 even when these two are fixed and thus the conditional probability is also at least 1/2.

Now since El holds there is a subset S' ~ S of cardinality at least t mapped by h to a single element aEz2 '"g". Fix this a and define D' '~f h-l(cr) and A' '~f h~l (~). Consider the distribution of hl satisfying h = hl o h2. When we restrict the attention to the mapping of D' to A', we get that the distribution implied by such hl is a uniform choice of an affine or linear mapping from D' into A' (we show this in Proposition 5.6 below). For event E2 to hold it is enough to have A' ~ hi(S). We will show that hl(S') covers all the points in A' with probability at least 1/2 and thus we get that event E2 happens with probability 1/2. Since h2 is onto we have IA'I = 24/n. On the other hand, D n S has cardinality at least t = [c112(24/n) log(2t/n)l. By Theorem 7, the probability that a set of cardinality t mapped by a random linear transformation will cover a range of cardinality 21/n is at least 1/2. (Note that Theorem 7 clearly applies to a random affine transformation too.) ❑

At this point, we have proven Corollary 5.3. This limits the probability of large buckets with linear hashing. Unfortunately the bound there is not strong enough to imply Theorem 3. We strengthen this bound below (see Corollary 5.5) to get the implication. This improvement has little practical value as people want the largest bucket to be small with high probability and this is already guaranteed by Corollary 5.3.

We need to improve the dependence of the constant hidden in the order notation of Corollary 5.3 on e. One way of doing this would be to study and improve the dependence of CCon e in Theorem 7. Although this dependence can be vastly improved, one cannot hope to get a cc = o(l/c) and thus Theorem 7 cannot be de duced this way. To solve this problem we notice that in Proposition 5.1 we use Theorem 7 in a very special case. Namely, by the setting of all parameters, we act ually use the theorem when the set hashed is quite big, and therefore we can get a much better bound on the dependence of c, on ( as follows.

Proposition 5.4 Let t and m be positive integers with

 $c=m-t-\log t \geq 4$ . Consider the vector spaces  $U=\mathbf{Z}_2^m$  and  $V=\mathbf{Z}_2^t$  and let  $A\subset U$  satisfy  $|U\setminus A|\leq t2^t$ . Then for a uniform random onto linear transformation  $T:U\to V$  we have

$$Prob[T(A) \neq V] < 2^{-c^2/2+3c}$$
.

**Proof:** The proof is similar but simpler than that of Theorem 7.

We start by observing that if  $m > 2t + \log t$  then for every onto linear transformation  $T: U \to V$  we have T(A) = V so we may assume  $m \le 2t + \log t$ .

Let s = m - t and choose s independent vectors  $x_i \in U$ , i = 1, 2, ..., s uniformly and independently at random. Then choose T uniformly at random among the onto linear transformations  $T: U \to V$  with  $T(x_i) = 0$  for i = 1, ..., s. This process yields the uniform distribution on all onto linear transformations  $T: U \to V$ .

Consider the sets  $A_i = A + \text{Span}\{x_1, \ldots, x_i\}$  and the numbers  $\alpha_i = 1 - |A_i|/|U|$  for  $i = 0, \ldots, s$ . We shall prove that  $\alpha_s$  is small with high probability.

As in the proof of Theorem 7 we imagine choosing the vectors  $x_i$  one by one. After choosing  $x_i$  the number  $\alpha_i$  is determined and by Lemma 4.2 for the random choice of  $x_{i+1}$  we have

$$E(\alpha_{i+1}) = \alpha_i^2.$$

Let us take  $C = 2^{c/2-1}$  and define the choice of  $x_{i+1}$  a failure if  $\alpha_{i+1} \geq C^{j_i+1}\alpha_i^2$  where  $j_i$  is the number of indices  $1 \leq j \leq i$  for which the choice of  $x_j$  was not a failure.

Clearly for any choices of  $x_1, \ldots, x_i$  the subsequent choice of  $x_{i+1}$  is a failure with probability at most  $C^{-j,-1}$ . Thus, the probability of the first failure to ever occur is at most  $\sum_{k=1}^{s} C^{-k} < 2/C$ . Similarly after any failure the probability of the next failure to occur is again at most 2/C. Thus, the probability of having at least d failures is at most  $(2/C)^d$  for any integer  $d \ge 1$ . Let us choose  $d = \lfloor c \rfloor - 1$  then  $(2/C)^d < 2^{-c^2/2 + 3c}$ .

Now consider the quantity  $v_i = C^{j_i+2}\alpha_i$ . If the choice of  $x_{i+1}$  was a failure then  $v_{i+1} \leq v_i$  because  $\alpha_{i+1} \leq \alpha_i$ . If however the choice of  $x_{i+1}$  was not a failure then  $j_{i+1} = j_i + 1$  and thus  $v_{i+1} \leq v_i^2$ . Thus,  $v_i \leq v_0^{2^{j_i}}$  for each  $i = 1, \ldots, s$ . Notice that by assumption we have  $\alpha_0 \leq 2^{-c}$  and therefore  $v_0 \leq 1/4$  so  $v_i \leq 2^{-2^{j_i+1}}$ . So except for the  $(2/C)^d$  error probability mentioned in the preceding paragraph we have  $\alpha_s < v_s \leq 2^{-2^{j_s-d+1}}$ . As  $s-c = \log t$  we have  $s-d \geq \log t + 1$  and thus  $2^{s-d+1} \geq 4t > m$ . Thus, in this case  $\alpha_s < 1/2^m$  and therefore  $A_s = U$  so T(A) = V as required.  $\Box$ 

Corollary 5.5 For a large enough d and any power n of 2 and for every subset S of any  $\mathbb{Z}_2$  vector space of size  $|S| = n \log n$  if we take a uniform random linear transformation to hash S to  $\mathbb{Z}_2^{\log n}$  we have

Prob[maximum bucket size  $\geq 2^d \log n \log \log n$ ]

$$< 2^{-d^2/3}$$
.

**Proof:** We go back to the scenario of choosing the random linear transformation h from the domain D to the buckets B through an intermediate domain A. We set the dimension of A to be  $\ell = \lfloor d - \log d - \log c_{1/2} \rfloor$ . So  $h = h_1 \circ h_2$  and  $h_1: D \to A$  is a uniform random linear map, while  $h_2: A \to B$  is a uniform random onto linear map. We choose the threshold  $t = 2^d \log d \log \log d$ . Now the events  $E_1$  and  $E_2$  of Propositions 5.2 are defined and the  $t > c_{1/2}(2^\ell/n)\log(2^\ell/n)$  condition is satisfied, thus we have

$$\operatorname{Prob}[E_2|E_1] \geq \frac{1}{2}.$$

To bound  $\operatorname{Prob}[E_2]$  we use Proposition 5.4 instead of Proposition 5.1 as follows. We prove that the probability of  $E_2$  is limited for every choice of  $h_1$ . Let us fix a linear map  $h_1:D\to A$  and take  $t=\log n$ ,  $m=\ell$  (thus  $c=d-\log d-O(1)$ ) and apply the proposition for the set  $A-h_1(S)$  (clearly  $|h_1(S)|\leq |S|=n\log n$ ). The proposition tells us that

$$\Pr[E_2] \le 2^{-c^2/2+3c}$$
.

Combining the last two inequalities for large enough d one gets

$$Prob[E_1] \le 2Prob[E_2] \le 2^{-c^2/2+3c+1} \le 2^{-d^2/3}$$
.

This proves the corollary. □

Remark: A more careful analysis can limit the error probability in Proposition 5.4 to  $2^{-c^2-c\log c}$ . This yields an error bound of  $2^{-d^2+2d\log d}$  for large enough d in Corollary 5.5.

**Proof of Theorem 3:**  $L_{n \log n}^n$  is the expectation of the distribution of the largest bucket size. Corollary 5.5 limits the probability of the tail of this distribution, thus yielding the desired bound on the expectation.  $\square$ 

In order for the paper to be self-contained we include a proof of the simple statement about random linear transformations used above.

**Proposition 5.6** Let D, A and B be vector spaces over  $\mathbb{Z}_2$ . Let  $h:D\to B$  be an arbitrary linear mapping, and let  $h_2:A\to B$  be an arbitrary onto linear mapping. Let  $\alpha$  be any point in B and denote  $D'\stackrel{\text{def}}{=} h^{-1}(\alpha)$  and  $A'\stackrel{\text{def}}{=} h_2^{-1}(\alpha)$ . Then, choosing a uniform linear mapping  $h_1:D\to A$  such that  $h=h_1\circ h_2$  and restricting the domain to D' we get a uniformly chosen linear mapping from D' to A' if  $\alpha=0$  or uniformly chosen affine mapping from D' to A' otherwise.

**Proof:** Consider  $D_0 \stackrel{\text{def}}{=} h^{-1}(0)$  and  $A_0 \stackrel{\text{def}}{=} h_2^{-1}(0)$ . Let us choose a complement space  $D_1$  to  $D_0$  in D, i.e.  $D_0 \cap D_1 = \{0\}$  and  $D_0 + D_1 = D$ . Let us call x the

unique vector in D' (1 D1. We have Di = *DO + x.* A linear transformation hl : D ~ A is determined by its two restrictions h' : Do ~ A and h" : D1 ~ A. Clearly the uniform random choice of hl corresponds to uniform and independent choices for h' and h". The restriction h = hl o ha means that h'(Do) G Ao and h" o ha is the restriction of h to D1. Thus, after the restriction the random choices of h' and h" are still independent. Note now that if a = O then the restriction of hl in question is exactly h' : D' ~ A). If a # O then use hl(u + z) = h'(u)+ h"(z) for u E Do to note that the restriction in question is again h', this time translated by the random value h"(z) ~ A'. n

## **6 Remarks and open questions**

### **6.1 Coupon collecting**

We consider the statements of Theorems 6 and 7 interesting in their own right; it's essentially a coupon collectors lemma for hash functions. The concern of the theorems is dual to the concern of usual hashing: it is about avoiding empty buckets. It is interesting to check whether they hold for other families of hash functions.

Not surprisingly, Theorem 7 fails for linear maps F2 ~ F, where F is a field of size n. A simple set to show this is S = {(z, tz) I z # O At E H}, where H c F is arbitrary with Ill I > 1. S has density almost Ill [/IF 1, but if we pick a non-zero linear map g(z, y) = az + by at random, then Pr[g(S) = F] = Pr[O E g(S)] = Pr[–a/b c H] < lH[/lFl.

To show that even Theorem 6 fails in this case one can take a set H C F of size IHI = [lF1/2] and consider S={(Z, V)ly#OA X/ye HA (z-1)/V @H}. S has density around one quarter and no linear map g : F2 a F satisfies g(S) = F. To see this take a nonzero linear map g : (z, y) + az + by and note that if O c g(S) then a # O and –b/a E H but in this case a # 9(8.

Another scheme for which even the assertion of The orem 6 fails (although to a much smaller extent) is the scheme that maps integers between 1 and p, for some large prime p, to integers between O and n – 1 for n = *rpiml, by* mapping z E 2P to the integer part of the fraction (az + b)( mod p)/m, where a, b are two randomly chosen elements of 2P. For this scheme, there are primes p and choices of an n and a subset S of cardinality ~(n log n log log log n) of 2P, which is not mapped by the above mapping onto [0, n – 1] under any choice of a and b.

To see this, let p be a prime satisfying ps 3( mod 4) and consider the set

$$S = \{ j^2 \bmod p \mid j \in \mathbf{Z}_p \setminus \{0\} \},\$$

of all quadratic residues modulo p, Note that for ev-

ery nonzero element a E ZP, the set aS ( mod p) is either the set of all quadratic residues or the set of all quadratic non-residues modulo p. The main result of Graham and Ringrose [GR90] asserts that for infinitely many primes p, the smallest quadratic nonresidue modulo p is at least fl(logp log log log p) (this result holds for primes p s 3 ( mod 4) as well, as follows from the remark in the end of [GR90]). Since for such primes p, – 1 is a quadratic nonresidue, it follows that for the above S and for any choice of a, b E 2P, the set aS + b (computed in 2P) avoids intervals of length at least O(log p log log logp). Choosing m = c logp log log log p for an appropriate (small) constant c, and defining n = [p/ml, it follows that ISI = (p – 1)/2 = S2(n logn logloglog n) is not mapped onto [0, n – 1] under any choice of a and b.

### 6.2 **Open questions**

The obvious question is what happens to the largest bucket with other well known families.

Examples of the families we have in mind include: Arithmetic over 2P [CW79, FKS84] (with hk(z) = (kz mod p) mod n), integer multiplication [DHKP93, AHNR95] (with h=(z) = (ax mod 2k) div 2k-r), Boolean convolution [MNT93] (with ha(z) = a o z projected to some subspace).

Another question is whether there exists a class X of size only 2°t10g10glul+10gnJ and with L:(H) = O(log n/ log log n). Note that linear maps over 22, even combined with collapsing the universe, use O(log log I.UI + (log n)z) random bits while the simple scheme using higher degree polynomials uses O(loglog Iul + (log ra)'/ loglogn).

## **References**

[AB186] N. Alon, L. Babai and A. Itai, A fast and simple randomized parallel algorithm for the maximal independent set problem. J. Algorithms 7 (1986) 567-583.

[ABM87] N. Alon, A. Barak and U. Manber, On disseminating information reliably without broadcasting, in: Proc. 7th International Conference on Distributed Computing Systems (ICDS), Berlin, 1987, pp. 74-81.

[AS92] N. Alon and J. H. Spencer, The Probabilistic Method, Wiley, New York, 1992.

[AHNR95] A. Andersson, T. Hagerup, S. Nilsaon, and R. Raman, Sorting in linear time?, in: Proc. 27th ACM Symposium on Theory of Computing, 1995, pp. 427-436.

- [CW79] J. L. Carter and M. N. Wegman, Universal classes of hash functions, J. Comput. Syst, Sci. 18 (1979) 143-154.
- [CLR90] T. H. Cormen, C. E. Leiserson, and R. L. Rlvest, Introduction to Algorithms, MIT Press, 1990.
- [DHKP93] M. Dietzfelbinger, T. Hagerup, J. Katajainen, and M. Penttonen, A reliable randomized algorithm for the closest-pair problem, Technical Report 513, Fachbereich Informatik, Universitat Dortmund, 1993.
- [DM90] M. Dietzfelbinger and F. Meyer auf der Heide, Dynamic hashing in real time, in: J. Buchmann, H. Ganzinger, W. J. Paul (Eds.): Iraformatik . Festschrijl .zum 60. Geburtstag von Gunter Hotz, Teubner-Texte zur Informatik, Band 1, B. G. Teubner, 1992, pp. 95-119. (A preliminary version appeared under the title "A New Universal Class of Hash Functions and Dynamic Hashing in Real Time" in ICALP'90.)

#### [DKMHRT94]

- M. Dietzfelbinger, A. Karlin, K. Mehlhorn, F. Meyer Auf Der Heide, H. Rohnert, R.E. Tarjan, Dynamic perfect hashing: upper and lower bounds, SIAM J. Comput. 23 (1994) 738-761.
- [DGMP92] M. Dietzfelbinger, J. Gil, Y. Matias, and N. Pippenger, Polynomial hash functions are refiable~ ICALP'92, Springer LNCS 623, pp. 235-246.
- [FKS84] M. L. Fredman, J. Komlc%, and E. Szemer~di, Storing a sparse table with O(1) worst case access time, J. Ass. Compui. Mach. 31 (1984) 538-544.
- [GBY90] G. Gonnet and R. Baeza-Yates, Handbook of Algorithms and Data Structures, Addison-Wesley, 1991.
- [GR90] S. W. Graham and C. J. Rlngrose, Lower bounds for leaat quadratic nonresidues, in: Analytic Number Theory: Proceedings of a Conference **in** Honor of P. T. Bateman, B.C. Berndt et al. (Eds.), Birkhauser, Boston, 1990.
- [MCW78] G. Markowsky, J. L. Carter, and M. N. Wegman, Analysis of a universal class of hash functions, in: Proc. 7th Conference on Maih. Found. of Computer Science (MFCX), 1978, Springer LNCS 64, pp. 345- 354.

- [MV84] K. Mehlhorn and U. Vishkin, Randomized and deterministic simulations of PRAMs by parallel machines with restricted granularity of parallel memories., Act a lraformatica 21 (1984) 339-374.
- [MNT93] Y. Mansour, N. Nisan, and P. Tiwari, The computational complexity of universal hashing. Theoretical Computer S'cience 107 (1993) 121-133.
- [PA95] J. Path and P. K. Agarwal, Combinatorial Geometry, Wiley 1995.
- [S89] A. Siegel, On universal classes of fast high performance hash functions, their timespace tradeoff, and their application, in: Proc. 30th IEEE Symposium on Foundations of Computer Science, 1989, pp. 20-25.
- [VC71] V. A. Vapnik and A. Y. Chervonenkis, On the uniform convergence of relative frequencies of events to their probabilities, Theory of Prob. Applications 16 (1971) 264–280.