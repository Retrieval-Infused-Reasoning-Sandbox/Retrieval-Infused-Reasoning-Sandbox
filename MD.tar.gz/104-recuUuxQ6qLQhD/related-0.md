## **On Matrices Having Equal Corresponding Principal Minors**

**D. J. Hartfiel**  *Mathematics Department Texas A&M University College Station, Texas* 

**and** 

**R. Loewy**  *Mathematics Department Technion -Israel Institute of Technology Haifa, lsrael* 

Submitted by Hans Schneider

#### ABSTRACT

Let A, B be 7t **x** *n* matrices with entries in a field *F.* We say A and B satisfy property D if B or B' is diagonally similar to *A.* It is clear that if A and B satisfy property ZB, then they have equal corresponding principal minors, of all orders. The question is to what extent the converse is true. There are examples which show the converse is not always true. We modify the problem slightly and give conditions on a matrix A which guarantee that if *B* is any matrix which has the same principal minors as A, then A and *B will* satisfy property ~3. These conditions on A are formulated in terms of ranks of certain submatrices of A and the concept of irreducibility.

#### **1. INTRODUCTION**

**Let F be a field, and let F"," be the set of all** *n* x *n* **matrices with entries in** *F. The* **basic question we wish to discuss is how two matrices are related when they have equal corresponding principal minors, of all possible orders.** 

**We say that a pair A,** *B E F", n* **satisfy** *property 9* if *B* **or** *Bt* is diagonally similar to A, that is, *B = D-'AD* or *Bt =* D-'AD for some nonsingular diagonal matrix *D E F", ".* **It is easy to check that if A,** *B* satisfy property 9, then they have equal corresponding principal minors. The question addressed in this paper is to what extent the converse is true. Our work concerns the subset *G(F, n)* of *F","* defined as follows: Let

*G(F,n)=* {AEF"l":if any *BEF","* has the same principal minors as A, then A, B satisfy property 9 }.

Thus, if A E G( *F, n)* and B has corresponding principal minors equal to those of A, then A and *B* satisfy property 9.

In this paper sufficient conditions for a matrix A to belong to G( *F, n) are*  given.

In case *F* is the field of real numbers or complex numbers, it turns out that these conditions describe a subset of *G(F, n)* which is dense in *F","* in the usual topology. This follows easily from Theorem 7.

As the definition of property 9 indicates, we are dealing here with the topic of diagonal similarity. This topic has been considered extensively in the literature. The question of when two given matrices A, *B* are diagonally similar has been studied in [l], [2], [3], [5], and [9]. An answer to this question in terms of circuit products for A and *B* is known in the case that A is irreducible or completely reducible; see [l] and [5]. An answer in terms of cyclic products for A and *B* is known in the case of a general matrix *A; see [9].* The terms cyclic products and circuit products are taken here in the sense of [9] and [3]. In our work, we replace cyclic products and circuit products by principal minors. Of course, each matrix has fewer principal minors than circuit products, while in general a principal minor involves several circuit products. Previously, Engel and Schneider established in [3] a link between diagonal similarity and principal minors in a special case involving two matrices A and *B,* one symmetric and the other completely reducible.

Section 2 is a collection of preliminary results. In Section 3 we consider the sets *G(F,2), G(F,3),* and *G(F,4).* Section 4 concerns *G(F, n)* for an arbitrary n. It contains our main result, Theorem 7, which gives a sufficient condition for an *n* x *n* irreducible matrix A to belong to *G(F, n).* The last section contains some examples demonstrating the strength of Theorem 7 and concludes with the statement of an open problem.

Some insight into our results concerning *G(F, n) can* be seen as follows: let *n, k* be positive integers such that *k -C n,* A,, E *Fk'k,* and A, E *FnwkSnmk.*  Consider the matrix

$$A = \begin{bmatrix} A_{11} & 0 \\ 0 & A_{22} \end{bmatrix},$$

which is not in *G(F, n) (see* Section 5). We consider under what changes of the zero blocks of this matrix we get a matrix in G( *F, n).* Results and remarks

on this problem are given in Theorem 7, and the examples and an open problem in Section 5.

We use throughout the following notation: For any positive integer n, let iv(n)= {1,2,..., n }. Given any n x *n* matrix *A* and *i E N(n),* let A(i) denote the principal submatrix of *A* obtained from A by deleting row and column i. For any *m* and *n with* 1~ *m Q n,* let Q,,," be the set of all sequences with *m*  strictly increasing integer components taken from *N(n).* Given (Y, p E Q,,,,, let A[ a]P] denote the submatrix of A having row indices in (Y and column indices in p. Further notation concerning submatrices will be given later.

Given a positive integer *n, we* say two subsets 'p and 1c/ of *N(n)* form a patiitionofN(n)ifcpU+=N(n)andcpn#=@.

# 2. SOME PRELIMINARY RESULTS

In this section we obtain some preliminary results which are used in subsequent sections to describe the set G(F, *n).* Some proofs of statements about *G(F, n) will* be inductive, and in this case the following lemma is useful.

**LEMMA 1.** *Let n >, 4, and suppose* A, *BE F",". Suppose that all the offdiagonul entries of* A *are rwnzero. Let* 

$$S_1 = \{i : 1 \le i \le n; B(i) \text{ is diagonally similar to } A(i)\}$$

$$S_2 = \{i: 1 \le i \le n; B(i)^t \text{ is diagonally similar to } A(i)\}.$$

*Then,* 

- (a) *if* IS,] > 3, *then B is diagonally similar to* A;
- (b) *if* IS,] > 3, *then B* t is *diagonally similar to A;*
- *(c) if IS,* u *S,l 2 5, then* A, *B satisfy prope~%y 9.*

*Proof.* We argue the various statements.

(a): Since we are allowed to replace A and *B* by *PAP'* and *PBP',* for any permutation matrix *P, we* may assume that 1,2,3 E S,. Thus,

$$B(1) = \operatorname{diag}(d_2^{-1}, d_3^{-1}, \dots, d_{n-1}^{-1}, 1) A(1) \operatorname{diag}(d_2, d_3, \dots, d_{n-1}, 1), \quad (1)$$

$$B(2) = \operatorname{diag}(e_1^{-1}, e_3^{-1}, \dots, e_{n-1}^{-1}, 1) A(2) \operatorname{diag}(e_1, e_3, \dots, e_{n-1}, 1),$$
(2)

and

$$B(3) = \operatorname{diag}(f_1^{-1}, f_2^{-1}, f_4^{-1}, \dots, f_{n-1}^{-1}, 1) A(3) \operatorname{diag}(f_1, f_2, f_4, \dots, f_{n-1}, 1).$$
(3)

It follows from (1) that

$$b_{in} = \frac{a_{in}}{d_i}, \quad i = 2, 3, ..., n-1$$

from (2) that

$$b_{in} = \frac{a_{in}}{e_i}, \quad i = 1, 3, ..., n-1,$$

and from (3) that

$$b_{in} = \frac{a_{in}}{f_i}, \quad i = 1, 2, 4, ..., n-1.$$

Hence *d, = ek = fk, k =* 4,5,. . . *,n -* 1, and *d, = e,, d, = f2, e, = fi.* Define now D = diag(e,, *d,, d,,.* . . *,d,\_l,* 1). It is clear that B = *D-'AD.* 

REMARK. The conclusion of part (a) is not true in general if the assump tion that all off-diagonal entries of A are nonzero is replaced by the assump tion that A is irreducible. Indeed, suppose F is a field with more than two elements, and let

$$A = \begin{bmatrix} 0 & 1 & 0 & 0 & 0 \\ 0 & 0 & 1 & 0 & 0 \\ 0 & 0 & 0 & 1 & 0 \\ 0 & 0 & 0 & 0 & 1 \\ 1 & 0 & 0 & 0 & 0 \end{bmatrix}, \quad B = \begin{bmatrix} 0 & b & 0 & 0 & 0 \\ 0 & 0 & 1 & 0 & 0 \\ 0 & 0 & 0 & 1 & 0 \\ 0 & 0 & 0 & 0 & 1 \\ 1 & 0 & 0 & 0 & 0 \end{bmatrix}, \quad \text{where} \quad b \neq 0, 1.$$

It *is easy* to check that B(1) = A(l), B(2) = A(2), and B(3) is diagonally similar to A(3), but B is not diagonally similar to A. It is also clear that the assumption that *all* off-diagonal entries of A are nonzero is not used fully in establishing (a). However, the result as stated will suffice for our purposes.

- (b): The proof is similar to part (a), with B replaced by Bt.
- (c): Follows immediately from the preceding parts, as we must have IS,I 2 3 or IS,1 >, 3. n

The next three results are concerned with a matrix A E *F"\* n* which is perturbed by adding (independent) indeterminates to some of its entries. For indeterminates xi, xs,. . . ,x, let K, = *F(x,, x2,. . . ,x,)* denote the smallest field containing *F* and xi, x2,. . . ,x,.

**THEOREM 1.** Suppose A E *F n, n is an irreducible matrix. Let x1, x2,.* . . ,x, *be (independent) indeteminutes, X =* diag(x,,x,,...,x,), and G *=(A + x)-l E K,^,". Then all entries of G are nonzero.* 

*Proof.* First note that A + X is invertible, so G is defined. Further, the cases of n = 1 and n = 2 are trivial, so we assume *n >* 3.

The main diagonal elements of G are clearly nonzero, because the determinant of any *(n -* 1) **X (n -** 1) principal submatrix of A + X is nonzero. So we need only consider the off-diagonal elements of G. For this, it suffices to prove that g,, z 0. Hence we show that

$$\det(A+X)[(2,3,\ldots,n)|(1,3,\ldots,n)]$$

$$= \det\begin{bmatrix} a_{21} & a_{23} & a_{24} & \cdots & a_{2n} \\ a_{31} & a_{33}+x_3 & a_{34} & \cdots & a_{3n} \\ a_{41} & a_{43} & a_{44}+x_4 & \cdots & a_{4n} \\ \vdots & \vdots & \vdots & & \vdots \\ a_{n1} & a_{n3} & a_{n4} & & a_{nn}+x_n \end{bmatrix} \neq 0$$

The coefficient of x3x4 - - . x, in the expansion of this determinant is *a21, so*  the statement is true if *a21 f 0.* It remains to consider the case when *a21 = 0.*  Since A is an irreducible matrix, there exists at least one directed path in the graph of A from 2 to 1. Consider a path from 2 to 1 of minimum length, say *k.* Since a2i = 0, we must have n - **1 >** *k 2* 2. Also, by a simultaneous permutation of rows and columns, we may assume a shortest path from 2 to 1 has arcs (2,3),(3,4), . . . , (k,k+l),(k+l,l), **i.e.,** *a,#O, a,#0 ,..., ak,k+l \*O,* ak+ll ~0. Wenowconsider(A+X)[(2,3,4 ,... *k,k+1)1(1,3,4 ,..., k,k +* l)], the submatrix of A + X with row indices 2,3,4,. . . , *k, k +* 1 and column indices 1,3,4 ,..., *k, k +* 1. The only nonzero entries in this *k* **x** *k* submatrix above its main diagonal are *a=, a=,* . . . , ak k+ 1 while the only nonzero entry in its first column is the last one, *ak+ 1, Ir* **or** 'else we would have a path from 2 toloflengthlessthank.Hencedet(A+X)[(2,3 ,..., k,k+1)](1,3,4 ,..., *k,k + 1)] = ( - l)k-1aDa,4..* . *a k, k + la k + 1, 1 + 0.* But this is exactly the coefficient of x *k+2Xk+3' - \* xn* in the expansion of det(A + X)[(2,3 ,..., n)](1,3,.. *.,n)] if k -C n -* 1 or the constant term in the same expansion if *k = n - 1.* In any case the proof is complete. n

**REMARK.** Theorem 1 has a converse, namely, if ail entries of G are nonzero, then A must be irreducible. Thus we have here a characterization of irreducible matrices, via the diagonal matrix of indetenninates X = diag(x,, x2,. . . , x,). Other characterizations of irreducible and fully indecomposable matrices using indeterminates were obtained by Ryser [7,8] and Schneider [ 101.

Theorem 1 can also be deduced from the next result. An independent proof of Theorem 1 was given here because of its graph-theoretic aspect.

In order to avoid complications of notation in subsequent results, we introduce the following conventions when discussing submatrices of an *n x n*  matrix A:

- (i) Supposea,,aa,..., a, are disjoint subsets of N(n), as are pi, &, . . . ,pl. ThenA[cu,,a,,...,a,lP,,Pz,..., PI] will denote the submatrix A[a]p], where we obtain the sequence cr by rearranging the elements of ai U a2 U . . . U a, in increasing order, and similarly for j3. Thus, for example, if ai = {1,7}, a2 = {2,4,8}, as = {3,10}, Pi = {1,3,7,8}, P2 = {4,6,10}, then A[a,,(~~,(~s]&,&l= A[(1,2,3,4,7,8,lO)l(1,3,4,6,7,8,10)1.
- (ii) If some subset ai (or flj) in (i) consists of a single element, say ri (or sj), we replace the notation ai by r, (fij by sj). Thus, for example, if ai = {l}, 1ya = {2,3}, cxs = {4}, pi = {1,5,6}, ,B, = {8}, the notation *A[l,* +,4]&,8] means A[(1,2,3,4)](1,5,6,8)].

We can now state the next result.

**LEMMA%** Supposethatn~landAEF",".Supposethatx,,x,,...,x,\_, are *(independent) indeterminutes. Let J? be an n x n matrix which has exactly n -* 1 *nonzero entries, ru) two* in *the same row or column, pnd suppose these nonzero entries are exactly x~,x~,...,x,\_~. Zf* det(A+ X)=0, *then*  A + X *and hence* A *itself contains an T* X s *zero block with T + s = n +* 1.

Proof The proof is by induction on *n.* It is trivial for *n =* 1 and *n =* 2, so we consider now the general case *n >* 3. We may replace A by *PAQ,* where *P*  and Q are any *n* X *n* permutation matrices. Hence we may assume that X = diag(r,, x 2,...,r,\_1,0). For convenience of notation, let Y = *A + \_j? E KETl, so* by assumption det Y = 0. Since det Y(1) is the cofactor of *alI + xl,* it must vanish. Hence, by the induction assumption, Y(1) has a zero block of size *TV* **X n -** *TV,* where 1 < *rl < n -* 1. Since all the main-diagonal entries of Y(1) except the last one contain an indeterminate, this means that there exists a partition cp, 4 of {2,3,.. ., n - l} such that Y(l)[cp, *nllC/. n] = 0,* and 1~ U {n)l=r,, l#u{n>l=n-r,. BY using a simultaneous permutation of rows and columns on Y, we may assume cp= {2,3,...,ri} and \$= {r,+l,r,+

 $2, \ldots, n-1$ . Since Y itself now has a zero block of size  $r_1 \times n - r_1$ , we have det  $Y = \det Y_1 \det Y_2 = 0$ , where  $Y_1 = Y[(2,3,\ldots,r_1,n)|(1,2,\ldots,r_1)]$  and  $Y_2 = Y[(1,r_1+1,r_1+2,\ldots,n-1)|(r_1+1,r_1+2,\ldots,n-1,n)]$ . The  $r_1 \times r_1$  matrix  $Y_1$  has  $r_1-1$  indeterminates, and the  $n-r_1 \times n - r_1$  matrix  $Y_2$  has  $n-1-r_1$  indeterminates. Further, det  $Y_1 = 0$  or det  $Y_2 = 0$ . Thus, the induction hypothesis can be applied to  $Y_1$  or to  $Y_2$ . We describe the case when it can be applied to  $Y_1$ , as the second possibility is similar. Since det  $Y_1 = 0$ , we can conclude that  $Y_1$  has a zero block of size  $r_2 \times s_2$ , with  $r_2 + s_2 = r_1 + 1$ . As  $Y[(2,3,\ldots,r_1,n)|(r_1+1,r_1+2,\ldots,n-1,n)] = 0$ , we conclude that Y has a zero block of size  $r_2 \times (s_2+n-r_1)$ . Thus, the result follows by setting  $r=r_2$  and  $s=s_2+n-r_1$  and noting that the zero block in Y will also be a zero block in A, because the indeterminates that appear in Y cannot appear in the entries of this block.

Theorem 2. Let  $n \ge 2$ , and suppose  $A \in F^{n,n}$ . Let  $\tilde{X} = \operatorname{diag}(0, 0, x_3, x_4, \ldots, x_n)$ , where  $x_3, x_4, \ldots, x_n$  are independent indeterminates, and let  $\tilde{A} = A + \tilde{X} \in K_{n-2}^{n,n}$ . If  $\det \tilde{A} = 0$ , there exists a partition  $\alpha, \beta$  of  $\{3, 4, \ldots, n\}$  such that rank  $A[1, 2, \alpha|1, 2, \beta] \le 1$ .

**Proof.** The result will be proved by induction on n. The case n=2 is trivial, so we consider the general case n>2. Since  $x_3,x_4,\ldots,x_n$  are indeterminates, it is clear that the cofactor of  $a_{nn}+x_n$  in the expansion of det  $\tilde{A}$  must vanish, and so we may apply the induction hypothesis. Moreover, since we may permute rows and columns  $3,4,\ldots,n-1$ , we assume that there exists  $k,2 \le k \le n-1$ , such that

rank 
$$A[(1,2,...,k)|(1,2,k+1,...,n-1)] \le 1$$
,

so

$$A[(1,2,...,k)|(1,2,k+1,...,n-1)] = uv^{t}$$

for some column vectors

$$u = \begin{bmatrix} u_1 \\ u_2 \\ \vdots \\ u_k \end{bmatrix} \in F^k, \qquad v = \begin{bmatrix} v_1 \\ v_2 \\ v_{k+1} \\ \vdots \\ v_{n-1} \end{bmatrix} \in F^{n+1-k}.$$

The matrix  $\tilde{A}$  looks like

$$\tilde{A} = \begin{bmatrix} u_1 v_1 & u_1 v_2 & a_{13} & \cdots & a_{1k} & u_1 v_{k+1} & u_1 v_{k+2} & \cdots & u_1 v_{n-1} & a_{1n} \\ u_2 v_1 & u_2 v_2 & a_{23} & \cdots & a_{2k} & u_2 v_{k+1} & u_2 v_{k+2} & \cdots & u_2 v_{n-1} & a_{2n} \\ u_3 v_1 & u_3 v_2 & a_{33} + x_3 & \cdots & a_{3k} & u_3 v_{k+1} & u_3 v_{k+2} & \cdots & u_3 v_{n-1} & a_{3n} \\ \vdots & \vdots & \vdots & & \vdots & & \vdots & & \vdots \\ \vdots & \vdots &$$

The result is true if u = 0, for then rank  $A[(1,2,...,k)|(1,2,k+1,...,n-1,n)] \le 1$ . It is also true if v = 0, for the same reason. Hence, we may assume  $u \ne 0$  and  $v \ne 0$ . We now have two cases.

Case 1. Suppose that  $v_1 \neq 0$  or  $v_2 \neq 0$ . We may assume  $v_1 \neq 0$  (otherwise, interchange first row and second row and do likewise with the corresponding columns). We may use elementary column operations to get a 0 block in rows  $1, 2, \ldots, k$  and columns  $2, k+1, \ldots, n-1$ . Since this block has size  $k \times n - k$ , det  $\tilde{\Lambda}$  is the product of two determinants, as follows:

$$\det \tilde{A} = \det A_1 \det A_2,$$

where

$$A_{1} = \begin{bmatrix} u_{1}v_{1} & a_{13} & \cdots & a_{1k} & a_{1n} \\ u_{2}v_{1} & a_{23} & \cdots & a_{2k} & a_{2n} \\ u_{3}v_{1} & a_{33} + x_{3} & \cdots & a_{3k} & a_{3n} \\ \vdots & \vdots & & \vdots & \vdots \\ u_{k}v_{1} & a_{k3} & \cdots & a_{kk} + x_{k} & a_{kn} \end{bmatrix}$$

and

$$A_{2} = \begin{bmatrix} a_{k+1,2} - a_{k+1,1} \frac{v_{2}}{v_{1}} & a_{k+1,k+1} + x_{k+1} - a_{k+1,1} \frac{v_{k+1}}{v_{1}} & \cdots & a_{k+1,n-1} - a_{k+1,1} \frac{v_{n-1}}{v_{1}} \\ a_{k+2,2} - a_{k+2,1} \frac{v_{2}}{v_{1}} & a_{k+2,k+1} - a_{k+2,1} \frac{v_{k+1}}{v_{1}} & \cdots & a_{k+2,n-1} - a_{k+2,1} \frac{v_{n-1}}{v_{1}} \\ \vdots & & \vdots & & \vdots \\ a_{n-1,2} - a_{n-1,1} \frac{v_{2}}{v_{1}} & a_{n-1,k+1} - a_{n-1,1} \frac{v_{k+1}}{v_{1}} & \cdots & a_{n-1,n-1} + x_{n-1} - a_{n-1,1} \frac{v_{n-1}}{v_{1}} \\ a_{n2} - a_{n1} \frac{v_{2}}{v_{1}} & a_{n,k+1} - a_{n1} \frac{v_{k+1}}{v_{1}} & \cdots & a_{n,n-1} - a_{n1} \frac{v_{n-1}}{v_{1}} \end{bmatrix}$$

Since det A = 0, we must have det A, = 0 or det A, = 0. Suppose first that det A, = 0. We may apply the induction hypothesis to A,, since the entries of A, contain *k -* 2 indeterminates. These entries don't appear on main diagonal entries of A,, but we can permute columns to achieve this, so the induction hypothesis clearly applies. So there exist a partition cp, J/ of {3,4,. *. . , k }*  such that rank A[l, 2, cp]l, 4, n] < 1. Since o1 Z 0, u Z 0, and rank A[@, 2,. . . ,k)](l, 2, *k +* 1,. . . ,n - l)] < 1, it follows now that rankA[1,2,(p]1,2,#,k+l,..., n - 1, n] 6 1, so the result holds. It remains to consider the case det A, # 0. But then det A, = 0. Let A, be the matrix obtained from A, by taking its last row and putting it as the first row of A,. Then also det A, = 0. The matrix A, satisfies the conditions of Lemma 2, so it must contain a zero block of size r X s, with r + s = n - *k +* 1. Hence, because of the location of the indeterminates in A,, there exists a partition jJ, v of {2,..., n - *k}* such that A,[l, ~11, v] = 0. Going back to A itself, we conclude that there exists a partition q, 4 of { *k +* 1, *k +* 2,. . . , n - l} such that rankA[1,2,..., *k, cp,* n]1,2, #I= 1, completing the proof in case 1.

Case 2. We consider now the case vi = va = 0. Since v # 0, we may assume without loss of generality that vk+ 1 # 0. We may again use elementary column operations to get a zero block in rows 1,2,. . . , *k* and columns 1,2, *k* +2 ,..., n - 1. Since this zero block is of size *k* **x n -** *k,* det A factors again as a product of two determinants, namely

$$\det \tilde{A} = \det A_4 \det A_5$$

where

$$A_{4} = \begin{bmatrix} a_{13} & \cdots & a_{1k} & u_{1}v_{k+1} & a_{1n} \\ a_{23} & \cdots & a_{2k} & u_{2}v_{k+1} & a_{2n} \\ a_{33} + x_{3} & \cdots & a_{3k} & u_{3}v_{k+1} & a_{3n} \\ \vdots & & \vdots & \vdots & \vdots \\ a_{k3} & \cdots & a_{kk} + x_{k} & u_{k}v_{k+1} & a_{kn} \end{bmatrix},$$

and

$$A_{5} = \begin{bmatrix} a_{k+1,1} & a_{k+1,2} & a_{k+1,k+2} - (a_{k+1,k+1} + x_{k+1}) \frac{v_{k+2}}{v_{k+1}} & \cdots & a_{k+1,n-1} - (a_{k+1,k+1} + x_{k+1}) \frac{v_{n-1}}{v_{k+1}} \\ a_{k+2,1} & a_{k+2,2} & a_{k+2,k+2} + x_{k+2} - a_{k+2,k+1} \frac{v_{k+2}}{v_{k+1}} & \cdots & a_{k+2,n-1} - a_{k+2,k+1} \frac{v_{n-1}}{v_{k+1}} \\ \vdots & \vdots & \vdots & \vdots & \vdots & \vdots \\ a_{n-1,1} & a_{n-1,2} & a_{n-1,k+2} - a_{n-1,k+1} \frac{v_{k+2}}{v_{k+1}} & \cdots & a_{n-1,n-1} + x_{n-1} - a_{n-1,k+1} \frac{v_{n-1}}{v_{k+1}} \\ a_{n,1} & a_{n,2} & a_{n,k+2} - a_{n,k+1} \frac{v_{k+2}}{v_{k+1}} & \cdots & a_{n,n-1} - a_{n,k+1} \frac{v_{n-1}}{v_{k+1}} \end{bmatrix}$$

Since det A = 0, we must have det A, = 0 or det A, = 0. Suppose first that det A, = 0. Then, by the induction hypothesis, there exists a partition cp,rc, of {3,4,...,k} such that rank A[1,2, cp]+, *k +* 1, n] < 1. Hence, rankA[1,2,(p]1,2,rC/,k+l,k+2 ,..., n-l,n]<l,andtheresultholds.

It remains to consider the case that det A, # 0, so we must have det A, = 0. Define Fi = F(x,+,), i.e., Fi is the field obtained from F by adjoining xk+ i. Let A, be the matrix obtained from A, by taking its last row and puting it as the first row of A,. Then also det A, = 0. Let

$$A_{7} = \begin{bmatrix} a_{n,1} & a_{n,2} & a_{n,k+2} - a_{n,k+1} \frac{v_{k+2}}{v_{k+1}} & \cdots & a_{n,n-1} - a_{n,k+1} \frac{v_{n-1}}{v_{k+1}} \\ a_{k+1,1} & a_{k+1,2} & a_{k+1,k+2} - (a_{k+1,k+1} + x_{k+1}) \frac{v_{k+2}}{v_{k+1}} & \cdots & a_{k+1,n-1} - (a_{k+1,k+1} + x_{k+1}) \frac{v_{n-1}}{v_{k+1}} \\ a_{k+2,1} & a_{k+2,2} & a_{k+2,k+2} - a_{k+2,k+1} \frac{v_{k+2}}{v_{k+1}} & \cdots & a_{k+2,n-1} - a_{k+2,k+1} \frac{v_{n-1}}{v_{k+1}} \\ \vdots & \vdots & \vdots & \vdots & \vdots & \vdots \\ a_{n-1,1} & a_{n-1,2} & a_{n-1,k+2} - a_{n-1,k+1} \frac{v_{k+2}}{v_{k+1}} & \cdots & a_{n-1,n-1} - a_{n-1,k+1} \frac{v_{n-1}}{v_{k+1}} \end{bmatrix}$$

so A, is a matrix with entries in the field Fr. Also,

$$A_6 = A_7 + \text{diag}(0, 0, x_{k+2}, x_{k+3}, \dots, x_{n-1})$$

By the induction hypothesis, there exists a partition 8, n of {3,4,. . . ,n - *k}*  such that rank A,[1,2,8]1,2, n] < 1. We now define a partition cp, 4 of *{k+2,k+3,..., n -* l} associated with 8, TJ in the following way. We get the elements of 'p by taking the elements of 8 and adding *k -* 1 to each; 4 is defined similarly when 8 is replaced by 17.

Suppose first that YJ = 0. Then we get immediately (since vi = oa = 0) rankA[(1,2,..., *n -* 1, n)](l,2)] < 1, so the result holds. Hence we may assume q#@, and therefore \$#0. Let *\$={k,,k, ,..., k,,k,+l ,..., k,+q},*  wherevk,#O,vkz#O ,..., vk,#Owhilevk,+,=~k,+z=~~~ =vk =O.

Consider first the case T = 0, and relate the work back to A&self. Since rank A,[1,2,8]1,2, q] Q 1 and vi = va = vk = . 1 . = vk = 0, we conclude rankA[1,2,..., *k, k +* 1, cp, 17(1,2, \$1~ 1, so the result bids. Hence we may assume that r >, 1. It is clear from the way we defined 4 via 17 that the indeterminate xk+ i appears in the element of A, in the 2, *k, - (k - 1)*  position, but the same indeterminate will not appear in the same row in columns 1,2, *k,+l-(k-* 1) ,..., *krfq - (k - 1).* Since rank A,[1,2,8]1,2, n] =G 1, we must have now A,[l, 8]1,2, *k,+l -(k -* l),. *..,kr+q -(k -* l)] = 0, so going back to A, we get A[1,2 ,..., *k, cp,* n&2, *k,+l ,..., k,,,] = 0.* If we also

haveA,[1,8]k,-(k-1) ,..., *k, - (k -* l)] = 0, then we get for A itself

rank 
$$A[1,2,...,k,\varphi,n|1,2,k+1,\psi] \le 1$$
,

because every column of this submatrix with index in 4 is just zero or a nonzero multiple of the column that corresponds to the index *k +* 1.

Finally,wehavetoconsiderthecaseA,[l,Blk,-(k-l),...,k,-(k-l)] # 0, so we may assume the element of A, in position i, *k, - (k -* 1) is nonzero, for some *i E {l}* U 8. This and the fact that rank A, [ 1,2, B ]I, 2, n] Q 1 imply that ~k+l,l=~k+1,2=~k+l,k,+~=~~~ =ak+l *k<sup>=</sup>*0. We now perform the following elementary column operations on'& (and get a matrix denoted by As): take the *k, - (k -* 1)th column, multiply it by the numbers - *vk2/vkl, - vk,/vk,',.'> - vk,/vk,,* and add into the *k, - (k -* l)th, *k, - (k -* l)th,..., *k, - (k -* 1)th columns, respectively. This will eliminate the indeterminate xk+ i from these columns, and so we have A,[1,2, *B/k, -(k*  l), *k, - (k -* l), . . . , *k, - (k -* l)] = 0. This discussion shows that in *A* itself rank A[1,2,. . . *,k, k + 1, rp, nlk,,* . . . , *k,] =* 1 (all columns of this submatrix are multiples of the column with index *k,),* and so rank A[ 1,2,. . . , *k, k +*  1, (p, n]1,2, n] = 1, completing the proof. n

Our work requires one additional lemma.

**LEMMA 3.** *Suppose T is an invertible matrix* in *F",", and suppose it has a block form* 

$$T = \begin{bmatrix} T_{11} & T_{12} \\ T_{21} & T_{22} \end{bmatrix},$$

*where T,,* is *an invertible k x k matrix. Let W = T-l, and partition W conformubly with T, so* 

$$W = \left[egin{array}{cc} W_{11} & W_{12} \ W_{21} & W_{22} \end{array}
ight].$$

Then rank W,, = rank *T,, and* rank W,, = rank *T,,.* 

*Proof.* Let Z = *T,, - T2,TI<'T,, E Fn-k,n-k.* Then Z is the Schur complement of *T,,* in *T, so* it must be invertible. It is easy to show, using elementary row operations, that W,, = - *TfilT,,Z-'* and *W,, = - Z- 'T21T;11, so* the result follows. n

## 3. THE SETS G(F,2),G(F,3), AND G(F,4)

This section describes the sets G(F,2), *G(F,3)* and *G(F,4).* First, we make a general observation concerning matrices A, B E *F", n* which have equal corresponding principal minors. Let xi, x2,. . . ,x, be (independent) indeterminates, and let X = diag(x,, xs,. . . ,xn) and K, = *F(x,, x2,.* . . ,x,,). In our work it is more convenient to consider the pair of matrices (A + X)- ' and (B + X)-l in K,"\*". We link A, B to (A + X)-',(B + X)-r as follows.

**LEMMA 4.** *Let A, B E F",", X =* diag(x,, xg ,..., x,). Then:

- (i) A, *B have equal corresponding principal minors if and only if A + X, B + X do.*
- (ii) *A, B have equal corresponding principal minors if and only if (A + X)-',(B + X)-l do.* 
  - (iii) A, *B satisfy property 9if and only if (A + X))',(B + X)-l do.*
- (iv) *Suppose A is irreducible and (A + X)-',(B + X)-l satisfy property ~viaadiagonalmatrixD=diag(l,d,,...,d,)~K,"~"(thatis,(B+X)~'= D-'(A + X)-'D or (Bt + Xt)-' = D-'(A + X)-'D). Then DE F"," and*  **A,** *B satisfy property 9 via D.*

*Proof* Part (i) is obvious. Part (ii) follows immediately from part (i), the fact that A + X and *B + X* are invertible, and the Jacobi identity relating the minors of an invertible matrix and the minors of its inverse (see [6, p. 211). One direction of (iii) is immediate, so it remains to show that if (A + X)-l and *(B + X))'* satisfy property S@ (over K,), then A, *B* satisfy property 9 over *F.* It is clear that A, *B* satisfy property 9 when viewed as matrices over *K,.* The fact that the required diagonal similarity can be performed via a diagonal matrix in *F",* " follows from Corollary 3.11 of [4]. Part (iv) follows from Corollary 3.14 of [4]; see also Proposition 2.3 of [9]. n

Our first result concerning *G(F, n)* follows.

**THEOREM 3.** *Let n =* 2 or *n = 3, and suppose A E F"\*" is irreducible, Then A E G( F, n).* 

*Proof.* Suppose *B E F","* and *A, B* have equal corresponding principal minors. We show that *A, B* satisfy property 9. There are two cases:

Case *1: n=2.* We have *a,,#O, a,,#O,* and *b,l=all, b,,=a,, b,,b,, - b,,b,, = allass -* a12a21. Define *D =* diag(1, *b,,/a,,).* Then *B = D-* **'AD, so** *B* is diagonally similar to A.

**Case 2: n = 3. Let G =(A+ X)-l, H=(B+ X)-l,** where X= diag(x,, x2, xs) and x1. x2, xa are indeterminates. Then G, H E K\$3 and all entries of G are nonzero, by Theorem 1. Also, G and H have equal corresponding principal minors, by Lemma 4. By case 1 of this theorem, H(1) is diagonally similar to G(l), and H(3) is diagonally similar to G(3). Since we may replace *H* by any matrix diagonally similar to it, we may assume

$$G = \begin{bmatrix} g_{11} & g_{12} & g_{13} \\ g_{21} & g_{22} & g_{23} \\ g_{31} & g_{32} & g_{33} \end{bmatrix}, \qquad H = \begin{bmatrix} g_{11} & g_{12} & h_{13} \\ g_{21} & g_{22} & g_{23} \\ h_{31} & g_{32} & g_{33} \end{bmatrix}$$

**We** also have g,,g,, = *h,,h,,* and det G = det *H. The* second condition implies **g12hg31 + gl3g2lg32 =** gl,g,h,l + **h,g,lg,. Now, if gl, = 43,**  then *H = G, so we* may assume g,, Z *h,,.* By factoring, we get

$$g_{12}g_{23}(g_{31}-h_{31})+g_{21}g_{32}(g_{13}-h_{13})=0,$$

so

$$g_{12}g_{23}\left(g_{31}-\frac{g_{13}g_{31}}{h_{13}}\right)+g_{21}g_{32}\left(g_{13}-h_{13}\right)=0,$$

and

$$\mathbf{g}_{12}\mathbf{g}_{23}\mathbf{g}_{31} - \mathbf{g}_{21}\mathbf{g}_{32}\mathbf{h}_{13} = 0.$$

Hence h13 = g12gDg3Jg21g32, h31= g13gdh13 = g13g21gdg12g,y and it follows that *Hf = D-'GD,* where D = diag(1, g,,/g,,, g2,g3,/gr2g,). Thus, we have shown that *H, G* always satisfy property 9. The result then follows from part (iv) of Lemma 4. n

**REMARK.** Theorem 3 shows that for *n =* 2 or *n =* 3 the condition that A is irreducible implies that A E G(F, *n).* It will be shown in Section 5 that for any n **X** *n* matrix A, a necessary condition for *A* to belong to G(F, *n)* is that A is irreducible. Hence in the cases n = 2 and *n =* 3 we have a characterization of the set G(F, *n).* For *n >* 4 the situation becomes considerably more complicated, as wiIl be demonstrated throughout the following results.

The next two results deal with the case n = 4.

**THEOREM 4.** *Suppose that A E F 4,4 and all the offdiagonal entries of A are nonzero. Suppose also that for any partition of {* 1,2,3,4} *into*  *two sets {i,,* is} and {is, i4}, *either rank A[(i,, &)I(&, id)] = 2 or mnkA[(i,, i4)l(il, i2)] = 2. Then A E G(F,4).* 

*Proof.* Suppose *B E F4S4* and A, *B* have equal corresponding principal minors. We have to show that A, *B* satisfy property 9. By Theorem 3, A(i) and B(i) satisfy property 9 for any i, i = 1,2,3,4. Define subsets S,, S, of {1,2,3,4} as in Lemma 1, so S, U S, = {1,2,3,4}. By Lemma 1, if ISi1 > 3 or IS,1 >, 3, we are done, so it remains to consider the case IS,I = IS,I = 2. By simultaneously permuting rows and columns, we may assume S, = { 1,2} and S, = {3,4}. Since we may replace *B* by a matrix diagonally similar to it, we may assume *B(1) =* A(1). We also have

$$B(2) = D^{-1}A(2)D$$
, where  $D = \text{diag}(d_1, d_3, 1)$ , (4)

$$B(3)^{t} = E^{-1}A(3)E$$
, where  $E = diag(1, e_2, e_4)$ , (5)

$$B(4)^{t} = F^{-1}A(4)F$$
, where  $F = diag(1, f_2, f_3)$ . (6)

It follows from (4) and B(1) = A(1) that

$$b_{13} = \frac{a_{13}d_3}{d_1}$$
,  $b_{31} = \frac{a_{31}d_1}{d_3}$ ,  $b_{14} = \frac{a_{14}}{d_1}$ ,  $b_{41} = a_{41}d_1$ ,  $d_3 = 1$ .

Since we may replace *B* by diag(l/d,, l,l, l)-'Bdiag(l/d,, l,l, l), we may assume *b,, = a13, b,, = a14, b,, = uS1, b41 = a41, so* 

$$A = \begin{bmatrix} a_{11} & a_{12} & a_{13} & a_{14} \\ a_{21} & a_{22} & a_{23} & a_{24} \\ a_{31} & a_{32} & a_{33} & a_{34} \\ a_{41} & a_{42} & a_{43} & a_{44} \end{bmatrix}, \qquad B = \begin{bmatrix} a_{11} & b_{12} & a_{13} & a_{14} \\ b_{21} & a_{22} & a_{23} & a_{24} \\ a_{31} & a_{32} & a_{33} & a_{34} \\ a_{41} & a_{42} & a_{43} & a_{44} \end{bmatrix}.$$

Next, it follows from (5) and (6) that

$$\begin{split} b_{21} &= a_{12}e_2 = a_{12}f_2, \qquad b_{12} = \frac{a_{21}}{e_2} = \frac{a_{21}}{f_2}\,, \\ a_{31} &= a_{13}f_3, \quad a_{41} = a_{14}e_4, \quad a_{32} = \frac{a_{23}f_3}{f_2}\,, \quad a_{42} = \frac{a_{24}e_4}{e_2}\,. \end{split}$$

Hence  $f_2 = e_2$ , and

$$B^{t} = \begin{bmatrix} a_{11} & a_{12} & a_{13} & a_{14} \\ a_{21} & a_{22} & a_{23} & a_{24} \\ a_{13}f_{3} & \frac{a_{23}f_{3}}{f_{2}} & a_{33} & a_{34} \\ a_{14}e_{4} & \frac{a_{24}e_{4}}{e_{2}} & a_{43} & a_{44} \end{bmatrix},$$

$$B = \begin{bmatrix} a_{11} & \frac{a_{21}}{e_{2}} & a_{13} & a_{14} \\ a_{12}e_{2} & a_{22} & a_{23} & a_{24} \\ a_{13}f_{3} & \frac{a_{23}f_{3}}{f_{2}} & a_{33} & a_{34} \\ a_{14}e_{4} & \frac{a_{24}e_{4}}{e_{2}} & a_{43} & a_{44} \end{bmatrix},$$

$$B^{t} = \begin{bmatrix} a_{11} & a_{12}e_{2} & a_{13}f_{3} & a_{14}e_{4} \\ \frac{a_{21}}{e_{2}} & a_{22} & \frac{a_{23}f_{3}}{f_{2}} & \frac{a_{24}e_{4}}{e_{2}} \\ a_{13} & a_{23} & a_{33} & a_{43} \\ a_{14} & a_{24} & a_{34} & a_{34} \end{bmatrix}.$$

Since  $\det A = \det B$ , we get

$$\begin{split} 0 &= \det A - \det B \\ &= a_{12}a_{13}f_3(a_{23}a_{44} - a_{24}a_{43}) - \frac{a_{21}}{e_2}a_{13}f_3(a_{23}a_{44} - a_{24}a_{43}) \\ &- a_{12}a_{14}e_4(a_{23}a_{34} - a_{24}a_{33}) + \frac{a_{21}}{e_2}a_{14}e_4(a_{23}a_{34} - a_{24}a_{33}) \\ &+ a_{13}a_{21} \bigg( \frac{a_{23}f_3}{e_2}a_{44} - a_{34}\frac{a_{24}e_4}{e_2} \bigg) - a_{13}a_{12}e_2 \bigg( \frac{a_{23}f_3}{e_2}a_{44} - a_{34}\frac{a_{24}e_4}{e_2} \bigg) \\ &- a_{14}a_{21} \bigg( \frac{a_{23}f_3}{e_2}a_{43} - a_{33}\frac{a_{24}e_4}{e_2} \bigg) + a_{14}a_{12}e_2 \bigg( \frac{a_{23}f_3}{e_2}a_{43} - a_{33}\frac{a_{24}e_4}{e_2} \bigg) \\ &= 2f_3 \bigg( a_{12} - \frac{a_{21}}{e_2} \bigg) \bigg( \frac{a_{34}e_4}{f_3} - a_{43} \bigg) (a_{13}a_{24} - a_{14}a_{23}). \end{split}$$

n

Now, ~13~24 - ~14~23 must be nonzero, for otherwise rank A[(1,2)((3,4)] = rank A[(3,4)](1,2)] = 1, contrary to assumptions on A. Hence, either ui2 = *u,,/e,,* in which case *B = A,* or uQ *=aMe4/f3,* in which case *Bt = dWL e2, f,, e4) -'Adiag(L e2, f,, e4). Thus, the* matrices A, *B* satisfy prop erty 9, completing the proof. n

**REMARK. The** assumption in the preceeding theorem that all off-diagonal entries of A should be nonzero can be replaced by a weaker assumption, namely that *A* is irreducible, as will be seen in the next theorem. However, the rank condition on some submatrices of A that appears in Theorem 4 cannot, in general, be relaxed. This will be clear in Example 3 of Section 5, which is based partially on a careful analysis of the proof of Theorem 4. It is possible to give a precise description of G(F,4), but this would be too long and involved to be done here.

**THEOREM** 5. *Suppose that A E F4s4 is irreducible, and that for any partition of {* 1,2,3,4} *into two sets {i,, i2}, {i,, i4} either*  rank *A[(i,, i2)l(i3, i4)] = 2 or* rank A[(is, i4)](il, *i,)] = 2. Then A E G(F,4).* 

*Proof.* Suppose that *B E F4\*4,* and A, *B* have equal corresponding principal minors. Let X = diag(x,, x2, x3, x4), where xi, x2, x3, x4 are (independent) indeterminates, and define G = (A + X)-l E K24, H = *(B + X)-l E K24.* Then, all entries of G are nonzero by Theorem 1. Also, for any partition {ii,iz},[i3,i4} of {I,2,3,4} we have rank *G[(i,,* i2)](i3, *i4)] = 2* or rank *G[(i,,* i4)](il, *i,)] = 2,* by Lemma 3. Hence, by Theorem 4, G E *G(F,4).*  Since G and H have equal corresponding principal minors, they must satisfy property 9. We can conclude now, exactly as in part (iv) of Lemma 4, that there exists a diagonal matrix D E *F 4,4* such that *B = D-'AD* or *Bt = D-lAD.* 

### *4.* THE SET G( *F, n)* FOR A GENERAL *n*

The next result gives a sufficient condition for an *n* **x** *n* matrix A with no zero off-diagonal entries to belong to G( *F, n).* This result will then be used in the proof of Theorem 7, the main result of this paper, which gives a sufficient condition for an *n* **X** *n* irreducible matrix to be in *G(F, n).* 

**THEOREM 6.** Suppose *n > 4 and A E F", \*. Suppose that all* offdiagonal *entries of A are mnzero, and that for any subset {i,, i,, i,, i4} of iV( n), either*  rank *A[(i,, i2))(i3,* i4)] = *2 OT* rank A[(i3, i4)](il, i,)] = *2. Then A E G(F, n).* 

*Proof.* The proof is by induction on n. It is true for *n =* 4, by Theorem 4, so we now consider the general case, *n >* 4. Let *B E F", ",* and suppose A, *B*  have equal corresponding principal minors. Choose an arbitrary i E N(n). Then A(i) and *B(i)* have equal corresponding principal minors, and *A(i)*  satisfies the assumptions of the theorem. Hence, by the induction hypothesis, *B(i)* and A(i) satisfy property 9. Using the notation of Lemma 1, we have S, U S, = N(n). Since *n >,* 5, the result follows by part (c) of Lemma 1. n

**THEOREM** 7. *Let n >,* 4, *and suppose that A E F n, n is irreducible. Suppose that for every partition of N(n) into subsets a, j3 such that llyl> 2, l/31 > 2, we have* rank A[a]p] 2 2 *and* rank A[/3]a] 2 2. *then* A E *G(F, n).* 

*Proof.* Let xi, x2 ,... , x, be independent indeterminates and let X = diag(x,, ~a,..., xn), G=(A+X)-'EK,"? Then all entries of G are nonzero, by Theorem 1. Moreover, we want to show that for any four distinct elements *i,, i,, i,,* i, of N(n), rank *G[(i,, &)I(\$, i4)] =* 2. Indeed, suppose this is not true for some choice of 4 elements. We may assume without loss of generality that rank G[(1,2)](3,4)] = 1, so det G[(1,2)](3,4)] = 0. Hence, by the Jacobi identity relating the minors of an invertible matrix and the minors ofitsinverse[6,p.21],det(A+X)[(1,2,5,6 ,..., *n)l(3,4,5,6 ,...,* n)]=O.Then, by Theorem 2, there exists a partition cp, 1c/ of {5,6,. . . , n } such that rank A[1,2, (p]3,4, \$1 = 1. Here we have equality because A is irreducible. But this conclusion contradicts the assumptions on A. We have shown that G satisfies the assumptions of Theorem 6; hence G E *G(F, n). Now* suppose *B E F", n,* and A, *B* have equal corresponding principal minors. Let *H = (B + x)-l E K,",".* Then G, *H* have equal corresponding principal minors, by Lemma 4, and since G E *G(F,* n), we conclude that G, *H* satisfy property 9. It follows from part (iv) of Lemma 4 that there exists an invertible diagonal matrix *D E F","* such that *B = D-'AD* or *Bt = D-'AD.* n

#### 5. SOME EXAMPLES AND AN OPEN PROBLEM

In conclusion, we provide some additional remarks on the results in previous sections.

**EXAMPLE 1.** The purpose of this example is to show that if *n >* 2 and A E *G(F, n),* then A must be irreducible. Indeed, suppose first that A is  $n \times n$  and has the form

$$A = \begin{bmatrix} A_{11} & A_{12} \\ 0 & A_{22} \end{bmatrix},$$

where  $A_{11} \in F^{k, k}$  for some k, 0 < k < n. Let

$$B = \begin{bmatrix} A_{11} & B_{12} \\ 0 & A_{22} \end{bmatrix},$$

where  $B_{12}$  is defined as follows. Given any  $1 \le i \le k$ ,  $1 \le j \le n - k$ , the i, jth entry of  $B_{12}$  is zero if and only if the corresponding entry of  $A_{12}$  is nonzero. Then it is easy to verify that A, B have equal corresponding principal minors, but A, B do not satisfy property  $\mathcal{D}$ , so  $A \notin G(F, n)$ .

REMARK. Now, given an arbitrary reducible matrix  $A \in F^{n,n}$ , there exists a partition  $\alpha$ ,  $\beta$  of  $\{1,2,\ldots,n\}$  with  $\alpha \neq \emptyset$ ,  $\beta \neq \emptyset$  and such that  $A[\beta|\alpha]=0$ . Thus, as above, one can define a matrix  $B \in F^{n,n}$  such that A, B have equal corresponding principal minors, but don't satisfy property  $\mathscr{D}$ . Thus, no reducible matrix A belongs to G(F,n).

Example 2. Suppose that k and n are positive integers such that k < n. Consider the  $n \times n$  matrix

$$A = \begin{bmatrix} A_{11} & 0 \\ 0 & A_{22} \end{bmatrix}, \quad \text{where} \quad A_{11} \in F^{k, k}. \tag{7}$$

Suppose that neither  $A_{11}$  nor  $A_{22}$  is diagonally similar to its transpose. Define

$$B = \begin{bmatrix} A_{11} & 0 \\ 0 & A_{22}^t \end{bmatrix}.$$

Then A and B have equal corresponding principal minors, but they don't satisfy property  $\mathscr{D}$ . [We know from Example 1 that  $A \notin G(F, n)$ , but we'll describe next a perturbation of this A to get a more complicated example of a matrix not in G(F, n).] Note that A is a direct sum of  $A_{11}$  and  $A_{22}$ , and corresponds to the partition of N(n) into  $\{1, 2, ..., k\}$  and  $\{k+1, ..., n\}$ . A similar example may be defined for an arbitrary partition of N(n) into nonempty subsets of  $\alpha, \beta$ .

We want to see now how far we can perturb the matrix A in Example 2 [for convenience, consider A given by (7)], and still get a matrix which is not in G(F, n). The perturbation will be measured in terms of the ranks of the blocks replacing the zero blocks. If only one zero block is perturbed and the second is not, we have a reducible matrix, and so a matrix which is not in G(F, n). Because of Theorem 7, it is of interest to consider only the following two possibilities: (i) both perturbed blocks have rank 1; (ii) one of the perturbed blocks has rank 1 and one has rank >, 2. We give here examples concerning (i), and formulate an open problem concerning (ii). First, we have the following lemma.

*LEMMA 5. Suppose k, n are positive integers such that k < n. Suppose that X, v E Fk, Y E Fnmk,* A,, E *Fktk, A,, E Fn-k\*n-k, and* A,, is rwnsingulur. *Let* 

$$A = \begin{bmatrix} A_{11} & xy^t \\ yv^t & A_{22} \end{bmatrix}, \qquad B = \begin{bmatrix} A_{11} & xy^t \\ yv^t & A_{22}^t \end{bmatrix}.$$

Then det A = det *B.* 

Proof. Using elementary row operations it is a straightforward calculation to show that

$$\det A = \det A_{11} \det \left[ A_{22} - (v^t A_{11}^{-1} x) y y^t \right]$$

and

$$\det B = \det A_{11} \det \left[ A_{22}^{t} - \left( v^{t} A_{11}^{-1} x \right) y y^{t} \right]$$
$$= \det A_{11} \det \left[ A_{22} - \left( v^{t} A_{11}^{-1} x \right) y y^{t} \right],$$

so the result follows. n

**EXAMPLE 3. Now** choose A, *B as* in Lemma 5 (except that A,, may be singular), but with x = v, so

$$A = \begin{bmatrix} A_{11} & xy^t \\ yx^t & A_{22} \end{bmatrix}, \qquad B = \begin{bmatrix} A_{11} & xy^t \\ yx^t & A_{22}^t \end{bmatrix},$$

and assume further that all offdiagonal entries of A are nonzero, and that A,,, A,, are not symmetric matrices (this, in particular, implies that 2 < *k < n -* 2). It is clear that A, B do not satisfy property 9. However, we claim they have equal corresponding principal minors. Indeed, let X = diag(x,, x2,. . . , xn), where x1, x2 ,..., x, are independent indetenninates. A repeated application of Lemma 5 shows that *A + X, B + X* have equal corresponding principal minors, so by Lemma 4 also *A, B* have equal corresponding principal minors. It follows that the matrix A of this example is not in G(F, n). Note that it is obtained from the matrix A in (7) by certain rank-l perturbations of both zero blocks. Engel and Schneider consider in [3] an example (3.7 there) which is essentially a special case of this example.

Finally, we pose the following question. A positive answer will give a stronger result than Theorem 7, and, in light of Example 3, essentially the best possible result concerning G(F, n).

Q **UESTION. Let n >,** 4, and suppose that *A E F","* is irreducible. Suppose that for every partition of N(n) into subsets (r, j3 such that ]oJ > 2, ]/?I > 2, either rank A[a]p] > 2 or rank A[P]e] > 2. Is *A E G(F, n)?* 

Note that if n = 4 the answer is yes, by Theorem 5. The same answer holds for *n =* 5 and *n =* 6, as proved by the second author.

*Part of the work of the second author was done while visiting the Mathematics Department at Texas A&M University.* 

### **REFERENCES**

- **L. Basset, J.** Maybee, and J. Quirk, Qualitative economics and the scope of the correspondence principle, *Econometrica* **36544-563 (1968).**
- **G. M. Engel and H. Schneider, Cyclic and diagonal products on a matrix,** *Linear Algebra* **Appl.** *730-335* **(1973).**
- **G. M. Engel and H. Schneider, Matrices diagonally similar to a symmetric matrix,**  *Linear Algebra* **Appl. 29:131-138 (1980).**
- **G. M. Engel and H. Schneider, Algorithms for testing the diagonal similarity of matrices and related problems,** *SIAM I. Algebra and Discrete Methods 3:429-438*  **(1982).**
- **M. Fiedler and V. Ptak, Cyclic products and an inequality for determinants,**  *Czechdouak Math. J.* **19:428-450 (1969).**
- **F. R. Gantmacher,** *The Theory ofMatrices,* **Vol. I, Chelsea, New York, 1960.**
- **H. J. Ryser, Indeterminates and incidence matrices,** *Linear and Multilinear Algebra* **1:149-157 (1973).**

- 8 H. J. Ryser, The formal incidence matrix, Linear and M&linear Algebra 3:QQ-104 (1975).
- 9 B. D. Saunders and H. Schneider, Flows on graphs applied to diagonal similarity and diagonal equivalence for matrices, *Discrete Math.* 24:205-220 (1978).
- 10 H. Schneider, The concepts of irreducibility and full indecomposability of a matrix in the works of Frobenius, Kijnig and Markov, *Linear* Algebra Appl. 18:139-162 (1977).

*Received 19 December 1982; revised 28 March 1983*