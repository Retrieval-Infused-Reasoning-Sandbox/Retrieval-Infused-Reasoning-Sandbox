# **Principal Minors and Diagonal Similarity of Matrices**

Raphael Loewy *Department of Mathematics Technion - Israel institute of Technology Haifa, Israel* 

Submitted by David H. Carlson

#### **ABSTRACT**

**Let A, B be n** x n **matrices** with entries in a field *F.* Our purpose is to show the following theorem: Suppose n >, 4, A is irreducible, and for every partition of {1,2,...,n} into subsets a,p with ]al>2, jfil>Z either rankA[a(p]&2 or rank A [ PIa] > 2. If A and B have equal corresponding principal minors, of all orders, then B or *B'* is diagonally similar to A.

### 1. INTRODUCTION

Let F be an arbitrary field and A, B E F",". We say B is diagonally similar to A if there exists a nonsingular diagonal matrix *D E F", "* such that *B = D- 'AD.* We say A and *B* satisfy property SS if *B* or *B'* is diagonally similar to A.

The question of when *B* is diagonally similar to A is well known, and has been extensively investigated; cf. [l], [2], [3], [4], *[5], [9].* We are interested in the relation between diagonal similarity and the property of A and *B* having equal corresponding principal minors, and our results here should be viewed as a continuation of the work begun in [7].

The reader is referred to [7] for some additional background on diagonal similarity and principal minors. Briefly, however, it is clear that if A and *B*  satisfy property 9, then they have equal corresponding principal minors, of all orders. The converse is not true in general. Our main result, Theorem 1, gives two additional properties of A under which the converse is also true, namely that A is irreducible and that for every partition of { 1,2,. . . , n } into subsets 1y, p with ]a] > 2, I/?] > 2 either rank A[cxIP] > *2* or rank A[P]a] > *2.*  Theorem 1 answers affirmatively a question raised in *[7],* where a weaker result, Theorem 7, was obtained.

The entire paper is devoted to the proof of Theorem 1. Section 2 contains some preliminary results. Section 3 contains the statement and major part of the proof of Theorem 1. Part of the proof of that theorem, which deals with some combinatorial aspects of certain systems of subsets of { 1,2,. . . , n }, is deferred to the Appendix.

We introduce now the required terminology and notation. *F* is an arbitrary field. For any positive integer n, let F", " be the set of all n x rz matrices with entries in *F,* and let N(n) = { 1,2,. . . , n }. We say that subsets cw,fi of N(n) form a partition of N(n) if aU/3=N(n), anp=0. The inclusion symbol 3 is meant in the weak sense.

Given any matrix A E *F n, n* and i E N(n), let A(i) be the (n - **l)x(n - 1)**  principal submatrix of A obtained from A by deleting row and column i. For any 1 < m < n, let Qm,, be the set of all sequences with *m* strictly increasing integer components taken from N(n). Given (Y, p E Q,,,, n and A E *F "sn,* let A[c\_x]/~] denote the submatrix of A having row indices in 1y and column indices in p. A [ a] is the principal submatrix A [ ala].

Following [7] and in order to avoid complications of notation, these conventions for denoting submatrices are generalized now as follows: (i) Suppose ffr, 1ya,. . . , a, are mutually disjoint subsets of N(n), as are Pi>&,..., PI. Then A[a,, (us ,... , a,,,lfil, &. . . , PI] will denote the submatrix A[ a]P], where we obtain the sequence (Y by rearranging the elements of (Yi u (Ys u . . . u a, in increasing order, and similarly for p. (ii) If some CX~ (or pj) in (i) consists of a single element, say ri (or sj), we replace the notation (Y~ by ri (pi by sj). Examples can be found in [7].

Similar notation is used in the Appendix, where some ordered pairs ((Y; /3) of subsets of N(n) are considered. More precisely, if o~i, as,. . . , a,, are mutually disjoint subsets of N(n), as are pi, &, . . . , pi, then (ai, as>. . . , a,,; PI> Pp.. . > j.ll) denotes the ordered pair (U;L,CY~;U~=~~~~). Here, again, if a set (Y~ (or p.) consists of a single element ri (or sj), we replace the notation LY~ by 1;: ( B j by sj).

Finally, we agree to define any product of elements to be 1 if the corresponding index set is empty.

# 2. PRELIMINARY RESULTS

**LEMMA 1.** *Let* A *be an irreducible matrix in F n, ", n >,* 2. Suppose (Y, /3 is *a partition of N(n), as is y, 8. Suppose also that a* n *y # 0,* /3 n S # 0 *and*  rank A[cx]~] = 1, rank A[y]6] = 1. Then

- (i) cony, PUS *isapatiitionofN(n) and* rankA[(Yny]PuS]=l,
- (ii) aUy, j3nS *isapatiitionofN(n) and* rankA[aUy(/3n6]=1.

Proof. We prove only (i), for the proof of (ii) is similar. It is clear that a: n y, /3 U 6 is a partition of N(n). Since /? n 6 + 0 and A is irreducible, there exists *k E j3 CT 6* such that A[ *aJk] # 0* or A[ y lk] *# 0.* This and the assumptions rank A[ a]/?] = 1 and rank A[ *y* IS] = 1 immediately imply (i). n

**LEMMA** 2. *LetA,BEF 3x3 . Suppose that all entries of* A *are nonzero, that bi,j=ai,j for every (i,j)P {(1,2),(2,1)}, and that b2,1=pa1,2 and b,,,=p-'a,,, forsomenonzero~~F. Then,* ifdetA=detB, *eithera,,,=*  **al,Zp Or a2,3a3,1 = pal,3a3,2.** 

*Proof.* A simple computation yields

$$0 = \det A - \det B$$

$$= a_{1,2}a_{2,3}a_{3,1} + a_{1,3}a_{2,1}a_{3,2} - \mu^{-1}a_{2,1}a_{2,3}a_{3,1} - \mu a_{1,3}a_{1,2}a_{3,2}$$

$$= (a_{1,2} - \mu^{-1}a_{2,1})(a_{2,3}a_{3,1} - \mu a_{1,3}a_{3,2}).$$

**LEMMA** *3. LetA,BEF 4,4. Suppose that all entries of A are rwnzero, that bi,j=ai,j for every* (i,j)P{(1,2),(2,1)}, *and that b2,1=pa,,2 and b,,, = pL- 'a 2,1 for some nonzero p E F. Suppose also* 

$$a_{j,2}a_{1,j}a_{j,1}^{-1}a_{2,j}^{-1} = \mu^{-1}$$
 for  $j = 3,4$ . (1)

*Then, if* det A = det *B, either* 

- *(9 a* **2,1= Pal,,, or**
- (ii) *a* **1,4a2,3 = a1,3a2,4' Or**
- (iii) *a* **1,3a3,4a4,1= a3,1a4,3a1,4.**

Proof. Writing *b, - -'a,,,=(p-'a,,,- a,,,)+a,,z and using prop*erties of the deternunan~~~lds

$$\begin{split} 0 &= \det A - \det B \\ &= \left(\mu^{-1}a_{2,1} - a_{1,2}\right) \det \begin{bmatrix} \mu a_{1,2} & a_{2,3} & a_{2,4} \\ a_{3,1} & a_{3,3} & a_{3,4} \\ a_{4,1} & a_{4,3} & a_{4,4} \end{bmatrix} \\ &+ \det \begin{bmatrix} 0 & a_{1,2} & a_{1,3} & a_{1,4} \\ a_{2,1} - \mu a_{1,2} & a_{2,2} & a_{2,3} & a_{2,4} \\ 0 & a_{3,2} & a_{3,3} & a_{3,4} \\ 0 & a_{4,2} & a_{4,3} & a_{4,4} \end{bmatrix} \\ &= \left(\mu^{-1}a_{2,1} - a_{1,2}\right) d, \end{split}$$

where

$$d = \det \begin{bmatrix} \mu a_{1,2} & a_{2,3} & a_{2,4} \\ a_{3,1} & a_{3,3} & a_{3,4} \\ a_{4,1} & a_{4,3} & a_{4,4} \end{bmatrix} - \mu \det \begin{bmatrix} a_{1,2} & a_{1,3} & a_{1,4} \\ a_{3,2} & a_{3,3} & a_{3,4} \\ a_{4,2} & a_{4,3} & a_{4,4} \end{bmatrix}.$$

Hence, either  $a_{2,1} = \mu a_{1,2}$ , so (i) holds, or  $a_{2,1} \neq \mu a_{1,2}$ , so d = 0. Using (1), we get

$$\begin{split} 0 &= d = a_{2,3} a_{3,4} a_{4,1} + a_{2,4} a_{3,1} a_{4,3} - \mu a_{1,3} a_{3,4} a_{4,2} - \mu a_{1,4} a_{3,2} a_{4,3} \\ &= a_{3,4} a_{4,1} \left( a_{2,3} - \mu a_{1,3} a_{4,2} a_{4,1}^{-1} \right) + a_{4,3} a_{3,1} \left( a_{2,4} - \mu a_{1,4} a_{3,2} a_{3,1}^{-1} \right) \\ &= a_{3,4} a_{4,1} \left( a_{2,3} - a_{1,3} a_{2,4} a_{1,4}^{-1} \right) + a_{4,3} a_{3,1} \left( a_{2,4} - a_{1,4} a_{2,3} a_{1,3}^{-1} \right) \\ &= a_{1,3}^{-1} a_{1,4}^{-1} \left( a_{1,4} a_{2,3} - a_{1,3} a_{2,4} \right) \left( a_{1,3} a_{3,4} a_{4,1} - a_{1,4} a_{4,3} a_{3,1} \right). \end{split}$$

LEMMA 4. Let n be a positive integer such that  $n \ge 5$ , and let  $A, B \in F^{n,n}$ . Suppose all entries of A are nonzero, that  $b_{i,j} = a_{i,j}$  for every  $(i,j) \notin \{(1,2),(2,1)\}$ , and that  $b_{2,1} = \mu a_{1,2}$ ,  $b_{1,2} = \mu^{-1} a_{2,1}$  for some nonzero  $\mu \in F$ . Suppose that A satisfies also the following:

$$a_{j,2}a_{1,j}a_{j,1}^{-1}a_{2,j}^{-1} = \mu^{-1}, \qquad j = 3,4,...,n,$$
 (2)

$$a_{1,n}a_{n,1}^{-1} = \eta^{-1}$$
 and  $a_{k,n}a_{1,k}a_{k,1}^{-1}a_{n,k}^{-1} = \eta^{-1}$ 

for some nonzero  $\eta \in F$ , and k = 3, 4, ..., n - 1, (3)

$$\operatorname{rank} A[(1,2)|(3,4,\ldots,n-1)] = \operatorname{rank} A[(3,4,\ldots,n-1)|(1,2)] = 1,$$

(4)

$$\operatorname{rank} A[(1,2,n)|(3,...,n-2)] = \operatorname{rank} A[(3,...,n-2)|(1,2,n)] = 1.$$

(5)

[(5) is trivially satisfied if n = 5.] Then, if det  $A = \det B$ , either

- (i)  $a_{2,1} = \mu a_{1,2}$  or
- (ii) rank  $A[(1,2)|(3,4,...,n)] = \operatorname{rank} A[(3,4,...,n)|(1,2)] = 1$ , or
- (iii) rank  $A[(1,2,n)|(3,4,\ldots,n-1)] = \operatorname{rank} A[(3,4,\ldots,n-1)|(1,2,n)] = 1$ , or

(iv) det 
$$A[(3,4,\ldots,n-1)|(1,3,\ldots,n-2)] - a_{n-1,1}a_{1,n-1}^{-1} \det A[(1,3,\ldots,n-2)|(3,4,\ldots,n-1)] = 0.$$

*Proof.* We apply the following elementary column operations on A and *B* and obtain matrices A, = (a\$), *B,:* For each 4 < j f n - 1, multiply the third column of A (of *B)* by - ~~,,~a;,i (by - *b,,jb,t = - ~,,~a;,;)* and add into the jth column of A (of *B);* if j = 1,2,3, n, then the jth column of A, (of B,) is equal to the corresponding column of A (of B).

Note that (4) and (5) imply A,[(l, 2)](4,. . . , *n -* l)] = 0 and, if *n >* 6, A,1(1,2,n)1(4,..., n - 2)] = 0. We use this and the Laplace expansion of the determinant based on the first two rows to get

$$\begin{split} 0 &= \det A - \det B = \det A_1 - \det B_1 \\ &= (a_{1,3}a_{2,1} - \mu a_{1,2}a_{1,3}) \det A_1 \big[ (3,4,\ldots,n) | (2,4,\ldots,n) \big] \\ &+ (-1)^n \big( - a_{1,n}a_{2,1} + \mu a_{1,2}a_{1,n} \big) \det A_1 \big[ (3,4,\ldots,n) | (2,3,\ldots,n-1) \big] \\ &+ \big( a_{1,2}a_{2,3} - \mu^{-1}a_{2,1}a_{2,3} \big) \det A_1 \big[ (3,4,\ldots,n) | (1,4,\ldots,n) \big] \\ &+ (-1)^{n+1} \big( a_{1,2}a_{2,n} - \mu^{-1}a_{2,1}a_{2,n} \big) \\ &\times \det A_1 \big[ (3,4,\ldots,n) | (1,3,\ldots,n-1) \big]. \end{split}$$

We let

$$c^{(j)} = \begin{bmatrix} a_{3,j}^{(1)} \\ a_{4,j}^{(1)} \\ \vdots \\ a_{n,j}^{(1)} \end{bmatrix} \in F^{n-2}, \qquad j = 1, 2, \dots, n,$$

$$(6)$$

and use these column vectors to define the following (n - 2)X( n - 2) matrices:

$$A_2 = \left[ \mu a_{1,3} c^{(2)} - a_{2,3} c^{(1)}, c^{(4)}, c^{(5)}, \dots, c^{(n)} \right],$$

$$A_3 = \left[ \mu a_{1,n} c^{(2)} - a_{2,n} c^{(1)}, c^{(3)}, c^{(4)}, \dots, c^{(n-1)} \right].$$

Hence we get

$$(a_{1,2} - \mu^{-1}a_{2,1}) \Big[ \det A_2 + (-1)^{n+1} \det A_3 \Big] = 0,$$

and either *a2* 1 = ~a,,~, so (i) holds, or we must have det A, +

 $(-1)^{n+1}$  det  $A_3 = 0$ . Next, we define three column vectors

$$d^{(j)} = \begin{bmatrix} a_{3,j}^{(1)} \\ a_{4,j}^{(1)} \\ \vdots \\ a_{n-1,j}^{(1)} \end{bmatrix} = \begin{bmatrix} a_{3,j} \\ a_{4,j} \\ \vdots \\ a_{n-1,j} \end{bmatrix} \in F^{n-3}, \qquad j = 1, 2, n, \tag{7}$$

and we denote by  $e_i$  the *i*th standard unit vector (whose number of entries should be clear from the discussion). In order to evaluate det  $A_2$  – det  $A_3$  we note that by (4) and (7)  $d^{(2)} = a_{3,2}a_{3,1}^{-1}d^{(1)}$ , while (2) implies

$$\begin{split} \mu a_{1,3} a_{n,2} - a_{2,3} a_{n,1} &= a_{n,1} \left( a_{1,3} a_{2,n} a_{1,n}^{-1} - a_{2,3} \right) \\ &= -a_{n,1} a_{1,3} a_{1,n}^{-1} \left( a_{2,3} a_{1,n} a_{1,3}^{-1} - a_{2,n} \right), \\ \mu a_{1,n} a_{n,2} - a_{2,n} a_{n,1} &= 0, \mu a_{1,3} a_{3,2} a_{3,1}^{-1} - a_{2,3} &= 0, \\ \mu a_{1,n} a_{3,2} a_{3,1}^{-1} - a_{2,n} &= a_{2,3} a_{1,n} a_{1,3}^{-1} - a_{2,n}. \end{split}$$

Hence,

$$0 = \det A_{2} + (-1)^{n+1} \det A_{3}$$

$$= (a_{2,3}a_{1,n}a_{1,3}^{-1} - a_{2,n})$$

$$\times \{a_{1,3}a_{n,1}a_{1,n}^{-1} \det [e_{n-2}, c^{(4)}, c^{(5)}, \dots, c^{(n)}]$$

$$+ (-1)^{n} \det [c^{(1)} - a_{n,1}e_{n-2}, c^{(3)}, c^{(4)}, \dots, c^{(n-1)}]\}.$$
(8)

Now, if  $a_{2,3}a_{1,n}=a_{1,3}a_{2,n}$ , then by (2) also  $a_{n,2}a_{3,1}-a_{n,1}a_{3,2}=0$ , so (ii) holds. Hence, it remains to consider the case that the second factor in (8) vanishes.

It is clear that the cofactor of the element in the lower right corner of the matrix  $[e_{n-2}, c^{(4)}, c^{(5)}, \ldots, c^{(n)}]$  vanishes, so we may replace its last column  $c^{(n)}$  by

$$\begin{bmatrix} a_{3,n} \\ a_{4,n} \\ \vdots \\ a_{n-1,n} \\ \hline 0 \end{bmatrix} = \begin{bmatrix} d^{(n)} \\ -\overline{0} \end{bmatrix}.$$

But by (5), we have  $d^{(n)} = a_{3,n} a_{3,1}^{-1} d^{(1)} + (a_{n-1,n} - a_{n-1,1} a_{3,n} a_{3,1}^{-1}) e_{n-3}$ .

We let

$$\hat{c}^{(j)} = \begin{bmatrix} a_{3,j} \\ a_{4,j} \\ \vdots \\ a_{n-1,j} \\ 0 \end{bmatrix} \in F^{n-2}, \qquad j = 1,3.$$

We may conclude that

$$\begin{split} a_{1,3} a_{n,1} a_{1,n}^{-1} a_{3,n} a_{3,1}^{-1} \det & \left[ e_{n-2}, c^{(4)}, \dots, c^{(n-1)}, \hat{c}^{(1)} \right] \\ &+ a_{1,3} a_{n,1} a_{1,n}^{-1} (-1)^{n+1} \left( a_{n-1,n} - a_{n-1,1} a_{3,n} a_{3,1}^{-1} \right) \\ &\times \det A_1 \left[ (3,\dots,n-2) | (4,\dots,n-1) \right] \\ &+ (-1)^n \det & \left[ \hat{c}^{(1)}, c^{(3)}, c^{(4)}, \dots, c^{(n-1)} \right] = 0. \end{split}$$

By (3), we have  $a_{n,1}a_{1,n}^{-1}a_{1,3}a_{3,1}^{-1}a_{3,n}-a_{n,3}=\eta\cdot\eta^{-1}a_{n,3}-a_{n,3}=0.$  Therefore, we get

$$\begin{split} &(-1)^n \det \bigl[ \, \hat{c}^{(1)}, \hat{c}^{(3)}, c^{(4)}, \ldots, c^{(n-1)} \bigr] \\ &+ (-1)^{n+1} a_{1,3} a_{n,1} a_{1,n}^{-1} \bigl( a_{n-1,n} a_{n-1,1} a_{3,n} a_{3,1}^{-1} \bigr) \\ & \times \det A_1 \bigl[ (3, \ldots, n-2) \big| (4, \ldots, n-1) \bigr] = 0. \end{split}$$

Recall that we showed that for  $n \ge 6$ ,  $A_1[(1,2,n)|(4,...,n-2)] = 0$ . It follows that in the first matrix appearing in the preceding expression, all elements in the last row, except possibly the main diagonal element, vanish. But the main diagonal element there is just  $a_{n,n-1}^{(1)}$ . We have by (3) and the definition of  $A_1$ 

$$a_{n,n-1}^{(1)} = a_{n,n-1} - a_{n,3} a_{1,n-1} a_{1,3}^{-1}$$

$$= \eta a_{1,n-1} a_{n-1,1}^{-1} \left( a_{n-1,n} - a_{3,n} a_{n-1,1} a_{3,1}^{-1} \right),$$

so we get

$$\begin{split} \left(a_{n-1,\,n} - a_{3,\,n} a_{n-1,\,1} a_{3,\,1}^{-1}\right) \\ & \times \left(\eta a_{1,\,n-1} a_{n-1,\,1}^{-1} \det A_1 \big[ (3,4,\ldots,n-1) | (1,3,\ldots,n-2) \big] \\ & - \eta a_{1,3} \det A_1 \big[ (3,\ldots,n-2) | (4,\ldots,n-1) \big] \big) = 0. \end{split}$$

Now, if *a.\_,,. = ~~,~a~\_~,~ai,:, we get by* (4) and (5),

rank 
$$A[(3,4,...,n-1)|(1,2,n)]=1;$$

also, by (31, u1,3~n,n\_1 - *~~,.\_,a.,, = 0, so* (4) and (5) imply rankA[(1,2,n)](3,4 ,..., n - l)] = 1, so (iii) holds.

Finally, it remains to consider the case a,\_ i, n # u3, "an\_ i, iu; :. But then we have det A,[(3,4,. . . , n - 1)](1,3,. . . , n - 2)]='a,\_,, a;.L\_lu1,3 det A, [(3 ,..., *n -* 2))(4 ,..., n - l)], which yields (iv) when substituting back the elements of A, in terms of those of A. W

# 3. MAIN RESULT

In this section we prove our main result:

**THEOREM 1.** *Let F be an arbitrary field and n a positive integer such that n 2* 4. Suppose *that* A, B E F"\*" *and that* A is *irreducible. Suppose further that* 

*A and B have equal corresponding principal minors, of all orders, (9)* 

for every partition of 
$$N(n)$$
 into subsets  $\alpha, \beta$  such that  $|\alpha| \ge 2$ ,  $|\beta| \ge 2$ , either rank  $A[\alpha|\beta] \ge 2$  or rank  $A[\beta|\alpha] \ge 2$ . (10)

*Then* A *and B satisfy property 9.* 

*Thus, we* give a positive answer to a question raised in [7], where a weaker result was obtained. The remaining part of this paper is devoted to the proof of this theorem, but at the moment we give a brief outline and motivation.

The basic approach is to use induction on *n.* The case of n = 4 is just Theorem 5 of 173. In order to take the induction step, one defines for any two matrices A, *B E F","* 

$$S_1(A, B) = \{i : 1 \le i \le n \text{ and } B(i) \text{ is diagonally similar to } A(i)\}, (11)$$

$$S_2(A, B) = \{i: 1 \le i \le n \text{ and } B(i)^t \text{ is diagonally similar to } A(i) \}.$$

For these two sets, we have the following result:

LEMMA 5 (cf. [7, Lemma 11). Suppose that n 2 4 and *A, B E* F "3 *". Suppose that all offdiagonul entries of A are nonzero. Then,* 

- (a) *if* ]S,(A, B)] > *3, then B is diagonally similar to A.*
- (b) *if [!\$(A, B)I >, 3, then B' is diagonally similar to A.*
- *(c) if* ]S,(A, B)u *\$(A, B)I > 5, then A, B satisfy property 9.*

The problems with the inductive approach are obvious. Given any *i* such that 1 < i 6 *n,* the principal submatrix A(i) does not have to be irreducible, and the condition that corresponds to (10) for *A(i)* does not have to be satisfied (and, of course, Lemma 5 might not be applicable either if A is assumed to be just irreducible). Therefore, as in [7], we introduce a certain transformation of the matrices under consideration.

Let xi, xa,...,x, be independent indeterminates, and let K, = F(r,, ~2,. . . , x,,), X = diag(x,, x2,.. ., x,) E KE,". Given A, B E *F",",* define

$$G = (A + X)^{-1} \in K_n^{n,n}, \qquad H = (B + X)^{-1} \in K_n^{n,n}.$$
 (13)

The results in [7] (Theorem 1, Lemma 3, Lemma 4) imply the following, whenever *A, B E* F", " satisfy the assumptions of Theorem 1:

- (I) All entries of G are nonzero.
- (II) G and *H* have equal corresponding principal minors.
- (III) G satisfies (10).
- (IV) If G and *H* satisfy property 9 over the field K,, then A, B satisfy property 9 over the original field *F.*

There is yet a difficulty left. The condition (10) might not be satisfied by an *(n -* 1) X *(n -* 1) principal submatrix G(i). The next lemma discusses this point.

LEMMAS. *Let n be a positive integer such that n > 5, and let* 1~ *i < n. Let A E F". ", and suppose that* A is *irreducible and satisfies* (10). *Let G be defined by* (13), and *suppose that there exists a partition vi* y J/i *of N( n)* 1 { *i } such that Ic+I~( >,2, IGil > 2, and* rankG(i)[cpi]#i] = rankG(i)[#i]vi] = 1. *Then, either* 

rank 
$$A[i, \varphi_i | \psi_i] = 1$$
 and rank  $A[i, \psi_i | \varphi_i] = 1$ , (14.1)

or

rank 
$$A[\psi_i|i, \varphi_i] = 1$$
 and rank  $A[\varphi_i|i, \psi_i] = 1$ . (14.2)

Proof Note that {i} U 'pi and qi form a partition of N(n), as do Cpi,{i}U\$i\* P ic k an element kecpi and Zflr/i, and let ~i=~i'{'} and +i =yi \ {I}. By assumption, ]@J~] >1 and ]#i] >, 1. Also, for any u E @i and ;~2\$)we have det **G(i)[(k,u)l(k~>l=~, so** by the Jacobi identities (cf. [6, . ,

$$\det(A+X)[N(n)\setminus\{l,v\}|N(n)\setminus\{k,u\}]=0.$$

Theorem 2 of [7] (see also Corollary 2 of [8]) and the irreducibility of A imply now that there exists a partition qO, /?,, of N(n) such that *k, u E a,,,*  and 1, v E &,, and rank A[o,,]&,,] = 1. Let

$$\gamma_u = \bigcap_{v \in \tilde{\psi}_i} \alpha_{uv} \quad \text{and} \quad \delta_u = \bigcup_{v \in \tilde{\psi}_i} \beta_{uv}$$

Fixing u E Gi and varying 0 over all elements of qj, we may apply Lemma 1 repeatedly (note that *k, u* belong to (Y,, and 1 belongs to j?,,, for every u E 4,) and get

$$\operatorname{rank} A\left[\gamma_u|\delta_u\right] = 1.$$

It is clear from the definition of yU and S,, that *k, u E ytr* while qi = { 1) u (6, c 6,'. It is also clear by Lemma 1 that yu and 6, form a partition of N(n).

We define now

$$\gamma = \bigcup_{u \in \tilde{\varphi}_i} \gamma_u \quad \text{and} \quad \delta = \bigcap_{u \in \tilde{\varphi}_i} \delta_u.$$

It follows from this definition and a repeated application of Lemma **1** that rank A [ y It?]= 1. It is also clear that y and 6 form a partition of N(n) and that 'pi c y and Gi c 6.

We have shown thus far that rank G(i)[cp,]qi] = 1 implies that either rank A[i, (P~]#~] = 1 or rank A[cpi]i, qi] = 1. Similarly, one shows that the assumption rank G(i)[\$i]qi] = 1 implies that either rank A[i, #i]qi] = 1 or rank A [ \$i Ii, cpi] = 1. The conclusion of the lemma is now clear, because A also satisfies (10). n

As we shall see in the proof of Theorem 1, the results of the preceding lemma and the appendix show that if A and B satisfy the assumptions of Theorem 1, if G, H are defined by (13), and if S,(G, H) and Ss(G, H) are

defined for G, H by (ll), (12), respectively, then we have to consider the possibility that IS,(G, ff)U S,(G, H)( is either 3 or 4.

The next theorem deals with the case that the cardinahty of the union is 4.

**THEOREM** 2. Let *n be a positive integer such that n > 5, and suppose that P, Q E F"," and that all offdiagonul elements of P are* nonzero. Suppose *that P and Q have equal corresponding principal minors. Suppose that there exist four distinct integers i,, i,,* is, i, E *N(n) such that S,(P, Q) = {i,,* is} ati **S,(P,Q)= {i3,i4}. Then** *there exists a partition cp, I/ of N(n)\ {i,, i,, i,, i4} such that* 

rank 
$$P[i_1, i_2, \varphi | i_3, i_4, \psi] = \text{rank } P[i_3, i_4, \psi | i_1, i_2, \varphi] = 1.$$

*Proof.* Without loss of generality, we may assume {i,, is} = { 1,2} and {i3,i4} = {3,4}. Let *M(n)=* (5 ,..., n }. The proof will be by induction on *n,*  but first we need some preliminary computations.

Obviously, we may replace *P* by any matrix diagonally similar to it. Since *P(i)* is diagonally similar to Q(i), for *i = 1,2, we* may therefore assume without loss of generality that *P(i) = Q(* i *)* f or *i =* 1,2. We thus have *qi, j = pi,* j for every *(i, j) 4* {(1,2),(2, l)}. Suppose that Q(3)t = *D-'P(3)D* and Q(4)' = *E-'P(4)&* where

$$D = diag(1, d_2, d_4, d_5, ..., d_n) \in F^{n-1, n-1}$$

$$E = \text{diag}(1, e_2, e_3, e_5, \dots, e_n) \in F^{n-1, n-1}$$

It follows easily that *d,=e,; di=ei,* i=5,...,n; q2,1=p1,2d2; q1,2= ~2, ld; 1; P4.1 = P1,4d4G p,,, = pz,rd,d, '; p3.1 = pl,3e3; p3,2 = p2,3e3d;'; *p,,,=p4,,d,da', k=5 ,..., n; pk,3=p3,Jdkec1, k=5 ,..., n; and pj,i=*  pi,jdjd;1,where5<i<nand j~{1,2,5,...,n}andwedefined,=l.

We define now *f,=l, fi=d,, f3=e3,* and fi=di, 5<i<n, and therefore *P* satisfies

$$p_{j,i} = p_{i,j} f_j f_i^{-1}$$
 whenever  $1 \le i < j \le n$  and  $(j,i) \notin \{(2,1),(4,3)\},$ 

$$(15)$$

so P looks like

$$P = \begin{bmatrix} p_{1,1} & p_{1,2} & p_{1,3} & p_{1,4} & p_{1,5} & \cdots & p_{1,n} \\ p_{2,1} & p_{2,2} & p_{2,3} & p_{2,4} & p_{2,5} & \cdots & p_{2,n} \\ p_{1,3}f_3 & \frac{p_{2,3}f_3}{f_2} & p_{3,3} & p_{3,4} & p_{3,5} & \cdots & p_{3,n} \\ p_{1,4}f_4 & \frac{p_{2,4}f_4}{f_2} & p_{4,3} & p_{4,4} & p_{4,5} & \cdots & p_{4,n} \\ p_{1,5}f_5 & \frac{p_{2,5}f_5}{f_2} & \frac{p_{3,5}f_5}{f_3} & \frac{p_{4,5}f_5}{f_4} & p_{5,5} & \cdots & p_{5,n} \\ \vdots & \vdots & \vdots & \vdots & \vdots & \vdots & \vdots \\ p_{1,n}f_n & \frac{p_{2,n}f_n}{f_2} & \frac{p_{3,n}f_n}{f_3} & \frac{p_{4,n}f_n}{f_4} & \frac{p_{5,n}f_n}{f_5} & \cdots & p_{n,n} \end{bmatrix}$$

$$(15')$$

and, as indicated, qi,j=pi,j whenever (i,j)4 {(1,2),(2,1)}, while 92,1= *Pl,2f2, 91.2 = P~,lfi-~\** 

We observe now that the 4 *x* 4 principal submatrices P[(1,2,3,4)] and Q[(l, 2,3,4)] cannot satisfy property 9. For suppose they do. Then this and the assumptions S,(P, Q) = { 1,2}, S,(P, Q) = {3,4} immediately imply that P [a], Q[ a] satisfy property 9 whenever (Y E Q4, ". A repeated application of Lemma 5 now yields that *P* and Q satisfy property 9, contrary to the assumptions on *S,(P,* Q) and *S,(P, Q).* A careful inspection of the proof of Theorem 4 of [7] leads to the conclusion that P[(1,2,3,4)] must satisfy

$$\operatorname{rank} P[(1,2)|(3,4)] = \operatorname{rank} P[(3,4)|(1,2)] = 1.$$
 (16)

We now turn to prove the theorem by induction on *n.* Suppose first that *n =* 5. *P* and Q satisfy the assumptions of Lemma 4 with a = *f2* and q = *f5, so* one of the four conclusions there must hold. The first conclusion is impossible, for we get p,,, = p,,, *f2,* implying *P = Q,* contrary to assumptions.

Suppose the last conclusion of Lemma 4 holds. Then we get

$$p_{1,3}p_{4,3}f_3 - p_{3,3}p_{1,4}f_4 - p_{1,3}p_{3,4}f_4 + p_{1,4}p_{3,3}f_4 = 0,$$

so p,,, = ~~,~\_&f~-', and we get Q' = diagtl, fi, f3, f,, .f3)Y1 Pdiag(1, fs, fs, f,, fs), contrary to assumptions.

Hence we must have rank *P[(1,2)1(3,4,5)] =* rank P[(3,4,5)](1,2)] = 1, or rank P[(1,2,5)((3,4)] = rank P[(3,4)](1,2,5)] = 1, completing the proof in case *n =* 5.

We now assume the theorem to hold if the matrices under consideration have size less than n *(n >* 6). Given any 5 Q *i < n,* consider P(i) and Q(i). It is clear that all the assumptions of the theorem are met, and, in particular, S,(P(i),Q(i))= {1,2}, S,(P(i),Q(i))= {3,4}. Hence, by the induction hypothesis, there exists a partition Oi, wi of *M(n)\ {* i} such that

$$\operatorname{rank} P[1, 2, \theta_i | 3, 4, \omega_i] = \operatorname{rank} P[3, 4, \omega_i | 1, 2, \theta_i] = 1. \tag{17}$$

Suppose that U;=s~~=Af(n). Then we get rankP[(1,2)((3,4,...,n)]= rankP[(3,4,..., n)](l,2)] = 1, so the theorem holds.

It remains to consider the case that U;\_soj f M(n). Since we may relabel the integers 5,. *. ., n, we* may assume without loss of generality that *n ~6 U~=5wj,* and therefore n ~fl;z\$,. Next, if t\_l~\_&~~ = (5,. . . , *n -* l} then we get rankP[(1,2,n)](3,4 ,..., n-l)]=rankP[(3,4 ,..., n-1)](1,2,n)]=l, so the theorem holds. Hence, it remains to consider the case (after a possible relabeling) that *n -* 1 CC Ur;\$j, so if n > 7 we must have *n -* 1 E f-l;:@,. Proceeding similarly, we may assume that for any 5 < j < *n -* 1, {j +l,..., *n } c tlj,* or else the theorem holds.

Now, if 5 E Bj for some 6 < j < n, we get, using (17) for O5 and ej, rankP[(1,2,5 ,..., n)](3,4)] = rank P[(3,4)](1,2,5,. . . , *n)] =* 1, so the theorem holds. Hence we may assume 5 ~fly,,o~. Next, if *n 2* 7 and 6 E ej for some 7< *jQn,*  rankP[(1,2,6 ,..., then we get from (17) for 0, and Oj that n)l(3,4,5)]=rankP[(3,4,5)1(1,2,6,...,n)]=l,sothetheorem holds. Similar considerations show that we may assume that for every 6~ *j<n,* {5,..., j - l} c wj, or else the theorem holds. To summarize, it remains to consider the case that *P* satisfies the following 2(n - 4) rank conditions that correspond to the elements 5,6,. . . , *n:* 

rank 
$$P[(1,2,6,...,n)|(3,4)] = \operatorname{rank} P[(3,4)|(1,2,6,...,n)] = 1,$$
(18.5)

rank 
$$P[(1,2,7,...,n)|(3,4,5)] = \operatorname{rank} P[(3,4,5)|(1,2,7,...,n)] = 1,$$
(18.6)

rank 
$$P[(1,2,8,...,n)|(3,4,5,6)] = \operatorname{rank} P[(3,4,5,6)|(1,2,8,...,n)] = 1,$$

$$(18.7)$$

$$\operatorname{rank} P[(1,2,n)|(3,4,...,n-2)] = \operatorname{rank} P[(3,4,...,n-2)|(1,2,n)] = 1,$$

$$(18.n-1)$$

$$\operatorname{rank} P[(1,2)|(3,4,\ldots,n-1)] = \operatorname{rank} P[(3,4,\ldots,n-1)|(1,2)] = 1.$$
(18.*n*)

[These rank conditions have been written for a general n, *n >* 6. Each rank condition should be understood to be meaningful for certain values of n only. For example, (18.6) is meaningful only for n > 7, (18.7) is meaningful only for n 2 8, etc.]

The matrices P and Q satisfy all the assumptions of Lemma 4, with p = fi and q = f,. Now, the first conclusion of that lemma cannot hold, for it would imply p,,, = p,,,f,, and therefore P = Q, contrary to assumptions.

If (ii) of Lemma 4 holds, we get

$$\operatorname{rank} P[(1,2)|(3,4,...,n)] = \operatorname{rank} P[(3,4,...,n)|(1,2)] = 1, \quad (19)$$

so the theorem holds. If (iii) of Lemma 4 holds, we get

$$\operatorname{rank} P[(1,2,n)|(3,4,...,n-1)] = \operatorname{rank} P[(3,4,...,n-1)|(1,2,n)] = 1,$$
(20)

so the theorem holds. It remains to consider the possibility that (iv) of Lemma 4 holds, so we get

$$\det P\left[(3,4,\ldots,n-1)|(1,3,\ldots,n-2)\right] - f_{n-1}\det P\left[(1,3,\ldots,n-2)|(3,4,\ldots,n-1)\right] = 0.$$
 (21)

Before proceeding, we deal directly with the cases *n =* 6 and *n =* 7. If *n =* 6,

then (21) is just

$$\det \begin{bmatrix} p_{3,1} & p_{3,3} & p_{3,4} \\ p_{4,1} & p_{4,3} & p_{4,4} \\ p_{5,1} & p_{5,3} & p_{5,4} \end{bmatrix} - f_5 \det \begin{bmatrix} p_{1,3} & p_{1,4} & p_{1,5} \\ p_{3,3} & p_{3,4} & p_{3,5} \\ p_{4,3} & p_{4,4} & p_{4,5} \end{bmatrix},$$

which yields, using (15) and some trivial computations,

$$\det \begin{bmatrix} p_{3,3} & p_{3,4} & p_{3,1} \\ p_{4,3} & p_{4,4} & p_{4,1} \\ p_{5,3} & p_{5,4} & p_{5,1} \end{bmatrix} - \det \begin{bmatrix} p_{3,3} & \frac{p_{4,3}f_3}{f_4} & p_{3,1} \\ \frac{p_{3,4}f_4}{f_3} & p_{4,4} & p_{4,1} \\ \frac{p_{5,3}}{f_3} & p_{5,4} & p_{5,1} \end{bmatrix} = 0.$$

The two  $3\times3$  matrices that appear above satisfy the assumptions of Lemma 2 with  $\mu = f_4 f_3^{-1}$ . The first conclusion of that lemma is impossible here, as it implies  $p_{4,3} = p_{3,4} f_4 f_3^{-1}$ , and therefore

$$Q^t = \text{diag}(1, f_2, \dots, f_6)^{-1} P \text{diag}(1, f_2, \dots, f_6),$$

contrary to our assumptions. Hence, we must have  $p_{4,1}p_{5,3} = f_4f_3^{-1}p_{3,1}p_{5,4}$ , and therefore, by (15), det  $P[(1,5)|(3,4)] = \det P[(3,4)|(1,5)] = 0$ . This and (18.5) imply now rank  $P[(1,2,5,6)|(3,4)] = \operatorname{rank} P[(3,4)|(1,2,5,6)] = 1$ , which concludes the case n = 6.

If n = 7, then (21) is just

$$\det \begin{bmatrix} p_{3,1} & p_{3,3} & p_{3,4} & p_{3,5} \\ p_{4,1} & p_{4,3} & p_{4,4} & p_{4,5} \\ p_{5,1} & p_{5,3} & p_{5,4} & p_{5,5} \\ p_{6,1} & p_{6,3} & p_{6,4} & p_{6,5} \end{bmatrix} - f_6 \det \begin{bmatrix} p_{1,3} & p_{1,4} & p_{1,5} & p_{1,6} \\ p_{3,3} & p_{3,4} & p_{3,5} & p_{3,6} \\ p_{4,3} & p_{4,4} & p_{4,5} & p_{4,6} \\ p_{5,3} & p_{5,4} & p_{5,5} & p_{5,6} \end{bmatrix} = 0,$$

which yields, using (15) and some trivial computations,

$$\det\begin{bmatrix} p_{3,3} & p_{3,4} & p_{3,5} & p_{3,6} \\ p_{4,3} & p_{4,4} & p_{4,5} & p_{4,6} \\ p_{5,3} & p_{5,4} & p_{5,5} & p_{5,6} \\ p_{1,3} & p_{1,4} & p_{1,5} & p_{1,6} \end{bmatrix} - \det\begin{bmatrix} p_{3,3} & \frac{p_{4,3}f_3}{f_4} & p_{3,5} & p_{3,6} \\ \frac{p_{3,4}f_4}{f_3} & p_{4,4} & p_{4,5} & p_{4,6} \\ \frac{p_{5,3}}{f_3} & p_{5,4} & p_{5,5} & p_{5,6} \\ p_{1,3} & p_{1,4} & p_{1,5} & p_{1,6} \end{bmatrix} = 0.$$

The two 4 x 4 matrices that appear above satisfy the assumptions of Lemma 3, with p= f, f,- '. One uses here (18.5) to check that (1) is indeed satisfied. The first conclusion of that lemma is impossible, for it yields p,,, = r)3,4f4h- i, and therefore Q" = diag(1, fa, . . . , f7) \_ ' Pdiag( 1, fa, . . . , f,), contrary to our assumptions.

If the second conclusion of Lemma 3 holds, we get ps,s~~,~ = ps,pd,e. Hence, det P[(3,4)](5,6)1 = 0, and using (15)~ also &Qp5,4 = p,,,p,,,, so det P[(5,6)](3,4)] = 0. This and (18.5) yield

rank 
$$P[(1,2,5,6,7)|(3,4)] = \operatorname{rank} P[(3,4)|(1,2,5,6,7)] = 1$$
,

so the theorem holds.

If the third conclusion of Lemma 3 holds, we get p3,5p5,6p1,3 = P5,3P1,5P3,6) which immediately implies, using (15), det P [(3,5)]( 1, S)] = det P[(1,6)](3,5)] = 0. This, (18.5), and (18.6) yield rank P[(1,2,6,7)](3,4,5)] = rank P[(3,4,5)](1,2,6,7)] = 1, completing the proof in case n = 7.

We now proceed with a further reduction of the matrices that appear in (21), and we may assume *n >,* 8. If we multiply the rows of the first matrix in (21) by h- '9 &- ', . . . , f,-- respectively, and its columns by 1, f3,. . . , fn\_2 respectively and then transpose it, we get from (21), using also (15),

$$\det \begin{bmatrix} p_{1,3} & p_{1,4} & p_{1,5} & \cdots & p_{1,n-2} & p_{1,n-1} \\ p_{3,3} & \frac{p_{4,3}f_3}{f_4} & p_{3,5} & \cdots & p_{3,n-2} & p_{3,n-1} \end{bmatrix}$$

$$\det \begin{bmatrix} \frac{p_{3,4}f_4}{f_3} & p_{4,4} & p_{4,5} & \cdots & p_{4,n-2} & p_{4,n-1} \\ p_{5,3} & p_{5,4} & p_{5,5} & \cdots & p_{5,n-2} & p_{5,n-1} \\ \vdots & \vdots & \vdots & \vdots & \vdots & \vdots \\ p_{n-2,3} & p_{n-2,4} & p_{n-2,5} & \cdots & p_{n-2,n-2} & p_{n-2,n-1} \end{bmatrix}$$

$$-\det\begin{bmatrix} p_{1,3} & p_{1,4} & p_{1,5} & \cdots & p_{1,n-2} & p_{1,n-1} \\ p_{3,3} & p_{3,4} & p_{3,5} & \cdots & p_{3,n-2} & p_{3,n-1} \\ p_{4,3} & p_{4,4} & p_{4,5} & \cdots & p_{4,n-2} & p_{4,n-1} \\ p_{5,3} & p_{5,4} & p_{5,5} & \cdots & p_{5,n-2} & p_{5,n-1} \\ \vdots & \vdots & \vdots & & \vdots & \vdots \\ p_{n-2,3} & p_{n-2,4} & p_{n-2,5} & \cdots & p_{n-2,n-2} & p_{n-2,n-1} \end{bmatrix} = 0.$$
 (22)

We let A = n - 3. In order to apply Lemma 4 we have to perform certain row and column permutations. So we define the following two 6 X fi matrices:

$$T_{1} = \begin{bmatrix} p_{3,3} & \frac{p_{4,3}f_{3}}{f_{4}} & p_{3,7} & \cdots & p_{3,n-2} & p_{3,n-1} & p_{3,6} & p_{3,5} \\ \frac{p_{3,4}f_{4}}{f_{3}} & p_{4,4} & p_{4,7} & \cdots & p_{4,n-2} & p_{4,n-1} & p_{4,6} & p_{4,5} \\ p_{7,3} & p_{7,4} & p_{7,7} & \cdots & p_{7,n-2} & p_{7,n-1} & p_{7,6} & p_{7,5} \\ \vdots & \vdots & \vdots & \vdots & \vdots & \vdots & \vdots \\ p_{n-2,3} & p_{n-2,4} & p_{n-2,7} & \cdots & p_{n-2,n-2} & p_{n-2,n-1} & p_{n-2,6} & p_{n-2,5} \\ p_{1,3} & p_{1,4} & p_{1,7} & \cdots & p_{1,n-2} & p_{1,n-1} & p_{1,6} & p_{1,5} \\ p_{6,3} & p_{6,4} & p_{6,7} & \cdots & p_{6,n-2} & p_{6,n-1} & p_{6,6} & p_{6,5} \\ p_{5,3} & p_{5,4} & p_{5,7} & \cdots & p_{5,n-2} & p_{5,n-1} & p_{5,6} & p_{5,5} \end{bmatrix}$$

$$(23)$$

and *T,* is a matrix which agrees with *T,* in every position except the 1,2 position, where its entry is just p,,,, and the 2,1 position, where its entry is just p4,s. Note that if n = 8, then *Tl* is 5 **X** *5,* and clearly only the first two and last three rows that are displayed in (23) are in fact present, and the same holds true for columns.

It follows from (22) that det *Tl =* det *T2.* We claim that the remaining assumptions of Lemma 4 are also satisfied by *Tl* and *T,.* Note that here p = *f4 f37 ' and q = fsf3- '.* It is easy to verify that (2) is satisfied for any j f Fi - 2 because of (15), and is satisfied for j = fi - 2 beause of (18.5). Next, (3) holds for every j # fi - 2 because of (15) and for j = fi - 2 because of (18.6). The two rank conditions in (18.5) imply that (4) is satisfied, while the two rank conditions in (18.6) imply that (5) holds.

Now, the first conclusion of Lemma 4 is impossible here, because we get *PC3 = p3,4f4f3- l* and this implies, as has been observed before, that Q" is diagonally similar to *P,* contrary to assumption.

If (ii) of Lemma 4 holds, we get rank P[(3,4)](5,6,. . . , n - l)] = 1 and rank P((l,S, 6,. *. . , n -* 2)](3,4)] = 1, which together with (18.5) imply rankP[(1,2,5,6 ,..,, *n)1(3,4)] =* rank P[(3,4)](1,2,5,6,. . . , n)] = 1, so the theorem holds. If (iii) of Lemma 4 holds, then we get rank *P[(3,4,5)/(6,7,.* . . , n-l)]=landrankP[(1,6,..., n - 2)](3,4, S)] = 1, which together with (18.6) imply rank P[(1,2,6,7 ,..., n)](3,4,5)]=rankP[(3,4,5)((1,2,6,7 ,..., n)]=l, so the theorem holds.

It remains to consider the case that (iv) of Lemma 4 holds, so we have det T,[(3, 4 ,..., fi- l)](l, 3 ,..., G-2)] -p6,3p-i,6 det T,[(1,3 ,..., E-2)] (3,4,..., ii - l)] = 0, which can be rewritten, using (15), (23) and trivial row

and column permutations,

$$\det P[(1,6,\ldots,n-2)|(3,7,\ldots,n-1)]$$

$$-f_6f_3^{-1}\det P[(1,3,7,\ldots,n-2)|(6,7,\ldots,n-1)] = 0$$
 (24)

(here, the set of row indices of second matrix in case n = 8 is just  $\{1,3\}$ ).

Before proceeding, we have to deal directly with three special cases, namely n = 8, 9, 10.

If n=8, then (24) is just [using (15)]  $p_{3,1}p_{6,7}-p_{6,1}p_{3,7}=0$ , which implies also  $p_{1,3}p_{7,6}-p_{1,6}p_{7,3}=0$ , and together with (18.6) and (18.7) yield rank P[(1,2,7,8)|(3,4,5,6)]= rank P[(3,4,5,6)|(1,2,7,8)]=1, completing this case.

If n = 9, then (24) is just

$$\det \begin{bmatrix} p_{1,3} & p_{1,7} & p_{1,8} \\ p_{6,3} & p_{6,7} & p_{6,8} \\ p_{7,3} & p_{7,7} & p_{7,8} \end{bmatrix} - f_6 f_3^{-1} \det \begin{bmatrix} p_{1,6} & p_{1,7} & p_{1,8} \\ p_{3,6} & p_{3,7} & p_{3,8} \\ p_{7,6} & p_{7,7} & p_{7,8} \end{bmatrix} = 0.$$

Putting  $f_6f_3^{-1}$  into the second row of the second matrix, multiplying the elements of the same row by  $p_{1,6}p_{1,3}^{-1}$  and the elements of the first column by  $p_{1,3}p_{1,6}^{-1}$ , using the fact that  $p_{6,8}=p_{3,8}p_{6,1}p_{3,1}^{-1}$  [because of (18.7)], and permuting rows yield

$$\det \begin{bmatrix} \boldsymbol{p}_{6,3} & \boldsymbol{p}_{6,7} & \boldsymbol{p}_{6,8} \\ \boldsymbol{p}_{7,3} & \boldsymbol{p}_{7,7} & \boldsymbol{p}_{7,8} \\ \boldsymbol{p}_{1,3} & \boldsymbol{p}_{1,7} & \boldsymbol{p}_{1,8} \end{bmatrix} - \det \begin{bmatrix} \boldsymbol{p}_{6,3} & \frac{\boldsymbol{p}_{3,7}\boldsymbol{p}_{6,1}}{\boldsymbol{p}_{3,1}} & \boldsymbol{p}_{6,8} \\ \frac{\boldsymbol{p}_{7,6}\boldsymbol{p}_{1,3}}{\boldsymbol{p}_{1,6}} & \boldsymbol{p}_{7,7} & \boldsymbol{p}_{7,8} \\ \boldsymbol{p}_{1,3} & \boldsymbol{p}_{1,7} & \boldsymbol{p}_{1,8} \end{bmatrix} = 0.$$

If we use (15), it is easy to check that the assumptions of Lemma 2 are satisfied with  $\mu = p_{1,3}p_{1,6}^{-1}f_7f_6^{-1}$ . If the first conclusion of Lemma 2 holds, we get, using (15),  $p_{1,3}p_{7,6}-p_{1,6}p_{7,3}=0$  and  $p_{3,1}p_{6,7}-p_{6,1}p_{3,7}=0$ , which together with (18.6) and (18.7) yields rank P[(1,2,7,8,9)|(3,4,5,6)]= rank P[(3,4,5,6)|(1,2,7,8,9)]=1, so the theorem holds. If the second conclusion of Lemma 2 holds, we get, using (15),  $p_{6,1}p_{7,8}-p_{6,8}p_{7,1}=0$  and  $p_{1,6}p_{8,7}-p_{1,7}p_{8,6}=0$ , which together with (18.7) and (18.8) yield rank P[(1,2,8,9)|(3,4,5,6,7)]= rank P[(3,4,5,6,7)|(1,2,8,9)]=1, completing the proof for n=9.

If n = 10, then (24) is just

$$\det egin{bmatrix} p_{1,3} & p_{1,7} & p_{1,8} & p_{1,9} \ p_{6,3} & p_{6,7} & p_{6,8} & p_{6,9} \ p_{7,3} & p_{7,7} & p_{7,8} & p_{7,9} \ p_{8,3} & p_{8,7} & p_{8,8} & p_{8,9} \ \end{bmatrix} = 0.$$
 $-f_6f_3^{-1}\det egin{bmatrix} p_{1,6} & p_{1,7} & p_{1,8} & p_{1,9} \ p_{3,6} & p_{3,7} & p_{3,8} & p_{3,9} \ p_{7,6} & p_{7,7} & p_{7,8} & p_{7,9} \ p_{8,6} & p_{8,7} & p_{8,8} & p_{8,9} \ \end{bmatrix} = 0.$ 

**We** put the scalar factor fs&- ' into the second row of the second matrix, and multiply its first column by p,,,p<A and its second row by pi,sp&\$ **BY (15) and** (18.7), we have P8,6Pl,3Pl,' = P8,3, P3,8Pl,6P\$f,hA' = P3,8P6,lPii = P6.6, P3,9Pl,6P[~\_fi&l = P3,9P6,lP;t = P6,9. Using these ad permuting rows yield

$$\det \begin{bmatrix} p_{6,3} & p_{6,7} & p_{6,8} & p_{6,9} \\ p_{7,3} & p_{7,7} & p_{7,8} & p_{7,9} \\ p_{8,3} & p_{8,7} & p_{8,8} & p_{8,9} \\ p_{1,3} & p_{1,7} & p_{1,8} & p_{1,9} \end{bmatrix}$$

$$-\det \begin{bmatrix} p_{6,3} & \frac{p_{3,7}p_{6,1}}{p_{3,1}} & p_{6,8} & p_{6,9} \\ \frac{p_{7,6}p_{1,3}}{p_{1,6}} & p_{7,7} & p_{7,8} & p_{7,9} \\ p_{8,3} & p_{8,7} & p_{8,8} & p_{8,9} \\ p_{1,3} & p_{1,7} & p_{1,8} & p_{1,9} \end{bmatrix} = 0.$$

It follows now from (15) (18.7), and (18.8) that the two 4 X 4 matrices above satisfy the conditions of Lemma 3 with II = Pl,3P&f7fb; '. Then, if (i) of that lemma holds, we get ~,,~p,,, - Pl,3P7,6 = 0 and therefore also ps,ips,7 p,,ips,J = 0. This, (18.6)~ and (18.7) yield rankP[(1,2,7,8,9,10)](3,4,5,6)]= rank P[(3,4,5,6)](1,2,7,8,9,10)] = 1, so the theorem holds. If (ii) of Lemma 3 holds, we get P6.9P7.8 - P6,8P7,9 = 0, and therefore C&O P8,7P9,6 - P8,6P9,7 = 0. This, (18.7), and (18.8) imply rank P [(l, 2,8,9,10)](3,4,5,6,7)] = rankP[(3,4,5,6,7)](1,2,8,9,10)]=1, so the theorem holds in this case. Finally, if (iii) of Lemma 3 holds, we get ps,sps,spr,s = ps,spr,sps\$ which implies, by (18.7) and (15) &r&g - ps,gps,i = 0, and therefore also

*PIJPQ,~ -* **~,,,PQ,, = 0.** This, (18.8), and (18.9) imply now rank P[(1,2,9,10))(3,4,. . . ,8)] = rank P[(3,4,. . . ,8)#1,2,9, lo)] = 1, complet ing the proof for n = 10.

We can now return to (24), and assume that n > 11. Our proof is completed using the next result. n

**THEOREM** 3. Let *n be a positive integer such that n >,* 11, and *let P E F"\*". Suppose that all the entries of P are nonzero, and that P satisfies*  (15) *and* (18.5),(18.6) ,..., (18.n). *Let j be a positiue integer such that j z* 2, n 2 3 j + 5, *and sicppose that* 

$$\det P\left[(1,3j,3j+1,\ldots,n-2)|(3,3j+1,3j+2,\ldots,n-1)\right]$$

$$-f_{3j}f_{3}^{-1}\det P\left[(1,3,3j+1,\ldots,n-2)|(3j,3j+1,3j+2,\ldots,n-1)\right]$$

$$=0. \quad (25)$$

Then, one **of** the *following holds:* 

$$\operatorname{rank} P[(1,2,3j+1,...,n)|(3,4,...,3j)]$$

$$= \operatorname{rank} P[(3,4,...,3j)|(1,2,3j+1,...,n)] = 1, \quad (26.3j+1)$$

or

rank 
$$P[(1,2,3j+2,...,n)|(3,4,...,3j+1)]$$
  
= rank  $P[(3,4,...,3j+1)|(1,2,3j+2,...,n)] = 1, (26.3j+2)$ 

or

rank 
$$P[(1,2,3j+3,...,n)|(3,4,...,3j+2)]$$
  
= rank  $P[(3,4,...,3j+2)|(1,2,3j+3,...,n)] = 1, (26.3j+3)$ 

or

rank 
$$P[(1,2,n-1,n)|(3,4,...,n-2)]$$
  
= rank  $P[(3,4,...,n-2)|(1,2,n-1,n)] = 1.$  (26.n-1)

Proof. The proof is basically by induction on *n -* 3j. One again uses Lemma 4 to reduce the size of the matrices that appear in (25). Let Ts be the first matrix that appears in (25), and *T4 the* second. Since (18.3j + 1) holds, we have

$$(a_{1,3j}, a_{3j+2,3j}, a_{3j+3,3j}, \dots, a_{n,3j})$$

$$= a_{1,3j} a_{1,3}^{-1} (a_{1,3}, a_{3j+2,3}, a_{3j+3,3}, \dots, a_{n,3})$$
(27)

and [using also (15)] also, for every 3 j + 2 < i < n,

$$p_{3j,i} = p_{3,i} p_{3,1}^{-1} p_{3j,1} = p_{3,i} p_{1,3j} p_{1,3} f_{3j} f_3^{-1}.$$
(28)

From (27) it follows that the first column of *T4* is just

$$p_{1,3j}p_{1,3}^{-1}(p_{1,3},p_{1,3}p_{1,3j}^{-1}p_{3,3j},p_{1,3}p_{1,3j}^{-1}p_{3j+1,3},p_{3j+2,3},p_{3j+3,3},\ldots,p_{n-2,3}).$$

If we put the scalar factor *p1,3jp\$f3jf3e1 = ~,~,,p,:* into the second row of *T4* and use (28), we get

$$\det T_3 - \det T_5 = 0, \tag{29}$$

where *T5* is a matrix which agrees with *T3* in every position except the 2,2 element, which is equal to *p* 3,3j+lp3j,lp3::, and the 3,l element, which is equal to *P3j+1,3jP1,3Pl,ija* 

In order to apply Lemma 4 we apply (the same) row and column permutations to *T3* and *T,.* We define

$$T_6 = P\left[ (3j, 3j + 1, 3j + 4, \dots, n - 2, 1, 3j + 3, 3j + 2) |$$

$$(3, 3j + 1, 3j + 4, \dots, n - 2, n - 1, 3j + 3, 3j + 2) \right]$$

[here, if n = 3j + 5, the row and column indices are understood to be (3j,3j + 1,1,3j +3,3j +2) and (3,3j + 1,3j +4,3j +3,3j +2) respectively], and *T7* is a matrix which agrees with *T6* in every position except the 1,2 element, which is equal to ps,sj+i~sj,i~~~, and the 2,l element, which is equal to psi+ i,sjr)i,spl,ij. It follows from (29) that

$$\det T_6 - \det T_7 = 0.$$

We denote by fi the order of *T6* and *T,.* We claim that all the assumptions of Lemma 4 are satisfied. Note that here, by (15) p = p1,3pl,ijf3j+l&;1 = **P1,3P3jfl-&j+l** while (15) and (18.3j + 1) imply

$$\begin{split} \eta &= p_{3j+2,3} p_{3j,3j+2}^{-1} = p_{3j+2,3} p_{3j+2,3j}^{-1} f_{3j}^{-1} f_{3j+2} = p_{1,3} p_{1,3j}^{-1} f_{3j}^{-1} f_{3j+2} \\ &= p_{1,3} p_{3j,1}^{-1} f_{3j+2}. \end{split}$$

The ratio of the 1,2 element of *T,* to the 2,l element of *Ts* is indeed p- '. Consider now the condition (2) (with index j there replaced by 1). For any 3j +2 G i G n - 2 we have by (18.3j + 1) ~,~,~p;! = p3j,lp3,t, which implies, together with (15), that (2) holds whenever 3 < 1 Q fi and 1 z fi - 2. A similar argument, using (18.3j +2), shows that (2) holds **also if** 1 = **ii -** 2. Next, (3) is satisfied for any 3 Q *k < ii -* 1 and *k f A -* 2 because of (15) and (18.3j + l), and for *k = A -* 2 because of (18.3j +3). The condition (4) is implied by (18.3j +2), and (5) holds trivially if n = 3j +5 and is implied by (18.3j + 3) if n > 3j + 6. Hence, all the assumptions of Lemma 4 hold.

If (i) of Lemma 4 holds, then we get, using (15), p,,,~~~,~~+~ p3,3j+lp3j,l= 0 and therefore ah *Pl,,P,j+1,3j - Pl,3jP3j+l,3 =O. This,*  (18.3 j), and (18.3 j + 1) imply that (26.3 j + 1) holds. If (ii) of Lemma 4 holds, we get rankP[(3j,3j+1)](3j+2,3j+3,...,n\_l)]=l and rankP[(1,3j+ 2,3j +3,..., n - 2)](3,3j + 1)] = 1, which together with (18.3 j + 1) and (18.3 j + 2) imply that (26.3 j +2) holds. If (iii) of Lemma 4 holds, we get rankP[(3j,3j+1,3j+2)](3j+3 ,..., n-l)]=1 and rankP[(1,3j+3 ,..., n - 2)](3,3j + 1,3j +2)] = 1, which together with (18.3j +2) and (18.3j +3) imply (26.3 j + 3).

Finally, suppose that (iv) of Lemma 4 holds. We get

$$\det P\left[ (3j+4,...,n-2,1,3j+3) | (3,3j+4,...,n-1) \right]$$

$$- p_{3j+3,3} p_{3j,3j+3}^{-1}$$

$$\times \det P\left[ (3j,3j+4,...,n-2,1) | (3j+4,...,n-1,3j+3) \right] = 0$$
(30)

(here, of course, if n=3j+5, the set of indices  $3j+4,\ldots,n-2$  is empty). By (18.3j+1) we have rank  $P[(3,3j)|(3j+3,3j+4,\ldots,n-1)]=1$ , so  $(p_{3j,3j+3},p_{3j,3j+4},\ldots,p_{3j,n-1})=p_{3j,3j+3}p_{3,3j+3}^{-1}(p_{3,3j+3},p_{3,3j+4},\ldots,p_{3,n-1})$ , and substituting this into (30) yields, after some row and column permutations,

$$\det P\left[(1,3j+3,...,n-2)|(3,3j+4,...,n-1)\right]$$

$$-f_{3j+3}f_3^{-1}\det P\left[(1,3,3j+4,...,n-2)|(3j+3,...,n-1)\right] = 0.$$
(31)

We are back to (25) with j replaced by j+1, so the size of the submatrices under consideration has been reduced by 3. Thus, the inductive proof will be complete once the lowest possible cases for n-3j are discussed, namely the cases that n=3j+w, where  $w \in \{5,6,7\}$ .

Suppose first n = 3j + 5. We have shown that (25) implies (26.3j + 1) or (26.3j + 2) or (26.3j + 3) or (31). But (31) for n = 3j + 5 is just

$$\begin{aligned} p_{1,3}p_{3j+3,3j+4} - p_{1,3j+4}p_{3j+3,3} \\ - f_{3j+3}f_3^{-1}(p_{1,3j+3}p_{3,3j+4} - p_{1,3j+4}p_{3,3j+3}) &= 0, \end{aligned}$$

so we immediately get rank P[(3,3j+3)|(1,3j+4)] = 1 and also rank P[(1,3j+4)|(3,3j+3)] = 1. This together with (18.3j+3) and (18.3j+4) yields (26.3j+4), which concludes the proof in this case.

Next, suppose n = 3j + 6. As in the preceding case, it remains to consider (31) for this value of n. We get here

$$\det \begin{bmatrix} p_{1,3} & p_{1,3j+4} & p_{1,3j+5} \\ p_{3j+3,3} & p_{3j+3,3j+4} & p_{3j+3,3j+5} \\ p_{3j+4,3} & p_{3j+4,3j+4} & p_{3j+4,3j+5} \end{bmatrix} \\ - f_{3j+3} f_3^{-1} \det \begin{bmatrix} p_{1,3j+3} & p_{1,3j+4} & p_{1,3j+5} \\ p_{3,3j+3} & p_{3,3j+4} & p_{3,3j+5} \\ p_{3j+4,3j+3} & p_{3j+4,3j+4} & p_{3j+4,3j+5} \end{bmatrix} = 0$$

We now put  $f_{3j+3}f_3^{-1}$  into the second row of the second matrix in the preceding expression, multiply the entries of this row by  $p_{1,3j+3}p_{1,3}^{-1}$  and the entries of the first column by  $p_{1,3}p_{1,3j+3}^{-1}$ , and use (15) and rank P[(3,3j+3)]

3)[(1,3j+5)] = 1 to get

$$\det \begin{bmatrix} p_{3j+3,3} & p_{3j+3,3j+4} & p_{3j+3,3j+5} \\ p_{3j+4,3} & p_{3j+4,3j+4} & p_{3j+4,3j+5} \\ p_{1,3} & p_{1,3j+4} & p_{1,3j+5} \end{bmatrix} = 0.$$

$$-\det \begin{bmatrix} p_{3j+3,3} & \frac{p_{3,3j+4}p_{3j+3,1}}{p_{3,1}} & p_{3j+3,3j+5} \\ \frac{p_{3j+4,3j+3}p_{1,3}}{p_{1,3j+3}} & p_{3j+4,3j+4} & p_{3j+4,3j+5} \\ p_{1,3} & p_{1,3j+4} & p_{1,3j+5} \end{bmatrix} = 0.$$

As in earlier computations, one can show now that Lemma 2 is satisfied with  $\mu = p_{1,3}p_{1,3j+3}^{-1}f_{3j+4}f_{3j+3}^{-1}$ . Therefore, either rank P[(1,3j+4)|(3,3j+3)] = rank P[(3,3j+3)|(1,3j+4)] = 1, which together with (18.3j+3) and (18.3j+4) implies (26.3j+4); or rank P[(3j+3,3j+4)|(1,3j+5)] = rank P[(1,3j+5)|(3j+3,3j+4)] = 1, which together with (18.3j+4) and (18.3j+5) implies (26.3j+5), completing the proof for n=3j+6.

Finally, suppose n=3j+7 and consider (31) for this case. Let  $T_8=P[(1,3j+3,3j+4,3j+5)|(3,3j+4,3j+5,3j+6)]$  and  $T_9=P[(1,3,3j+4,3j+5)|(3j+3,3j+4,3j+5,3j+6)]$ . Put the factor  $f_{3j+3}f_3^{-1}$  into the second row of  $T_9$ ; also multiply the entries of this row by  $p_{1,3j+3}p_{1,3}^{-1}$  and the entries of first column by  $p_{1,3}p_{1,3j+3}^{-1}$ . Use (15) and the assumptions rank P[(3,3j+3)|(1,3j+5,3j+6)]= rank P[(1,3j+5,3j+6)|(3,3j+3)]= 1 to get

$$\det T_{10} - \det T_{11} = 0,$$

where  $T_{10} = P[(3j+3,3j+4,3j+5,1)|(3,3j+4,3j+5,3j+6)]$ , and  $T_{11}$  is a matrix which agrees with  $T_{10}$  in every position except the 2,1 element, which is  $p_{3j+4,3j+3}p_{1,3}p_{1,3j+3}^{-1}$ , and the 1,2 element, which is  $p_{3,3j+4}p_{3j+3,1}p_{3,1}^{-1}$ .

Using (15) and the assumptions rank P[(1, 3j + 5)|(3, 3j + 3)] = 1, rank P[(3j + 3, 3j + 4)|(1, 3j + 6)] = 1, one can show by elementary computations that Lemma 3 holds with  $\mu = p_{1,3}p_{3j+3,1}^{-1}f_{3j+4}$ .

If (i) of Lemma 3 holds, we get rank P[(1,3j+4)|(3,3j+3)] =rank P[(3,3j+3)|(1,3j+4)] = 1, which together with (18.3j+3) and (18.3j+4) implies (26.3j+4). If (ii) of that lemma holds, we get rank P[(3j+3,3j+4)|(3j+5,3j+6)] =rank P[(3j+5,3j+6)|(3j+3,3j+4)] = 1. This together with (18.3j+4) and (18.3j+5) implies (26.3j+5). If (iii) of

that lemma holds, we get, using (15) and rank P[(1,3j +5)((3,3j +3)] = 1, that rank P[(3j +3,3j +5)](1,3j +S)] = rankP[(1,3j +6)](3j +3,3j +5)] = 1, which together with (18.3j +5) and (18.3 j +6) implies (26.33' +S), completing the proof. I

The next result deals with the case that the union of the sets S, and S,, defined by (11) and (12), consists of three elements.

**THEOREM 4.** *Let n be a positive integer such that* n > 5, *and suppose that P, Q E F n, n and that all off-diagonal elements of P are rumzero. Suppose that P and Q have equal corresponding principal minors. Suppose that there exist three distinct integers i,, i,, i, E N(n) such that S,(P, Q) = {i,,* is} *and S,(P,* **Q> = {is}. Define** 

$$\begin{split} U_1 &= \left\{i \in N(n) \smallsetminus \left\{i_1, i_2, i_3\right\} : \\ &\quad Q\left[\left(1, 2, 3, i\right)\right]^t \text{ is diagonally similar to } P\left[\left(1, 2, 3, i\right)\right]\right\}, \\ U_2 &= \left\{i \in N(n) \smallsetminus \left\{i_1, i_2, i_3\right\} : \\ &\quad Q\left[\left(1, 2, 3, i\right)\right]^t \text{ is not diagonally similar to } P\left[\left(1, 2, 3, i\right)\right]\right\}. \end{split}$$

*Then, there exists a partition LY, p of N(n) such thut {i,,* is} C a, { *i3} U u, C /3, and IpI 2 2, and* rank *P[aI/?] =* rank *P[/?Ia] =* 1.

*Proof.* It is clear that we may assume *i, =* 1, *i, = 2, i, = 3.* Let M(n) = *{4,5,..., n }. The* proof will be by induction on *n,* but first we need some preliminary observations.

Consider first P[(1,2,3)] and Q[(1,2,3)]. Theorem 3 of [7] implies that these two matrices satisfy property 9. However, if Q[(1,2,3)] is diagonally similar to *P* [(l, *2,3)], we* get from the assumptions of the theorem and Lemma 5 that Q[(l,2,3,i)] is diagonally similar to P[(1,2,3, *i)]* for any i E M(n). Therefore Q[a], P[a] satisfy property 9, for each a! E Q4+, and a repeated application of Lemma 5 yields that *P* and Q satisfy property 9, contrary to assumptions. Hence

$$Q[(1,2,3)]^t$$
 is diagonally similar to  $P[(1,2,3)]$ , but  $Q[(1,2,3)]$  is not diagonally similar to  $P[(1,2,3)]$ . (32)

Next, we show that ]U,] > 2. If U, = 0 we get again that Q[ CX] and P [ a] satisfy property 9 for ail (Y E Q4, ,,, which is impossible. If U, = { *k }* for some 4 < *k < n,* it follows (for n = 5 immediately and for n > 5 using Lemma 5) that k E S,(P, **QP UP, Q>,** contrary to assumptions. Hence IUs] > 2. Note also that the assumptions of the theorem, (32), and the proof of Theorem 4 of [7] imply that

rank 
$$P[(1,2)|(3,i)] = \operatorname{rank} P[(3,i)|(1,2)] = 1$$
 for any  $i \in U_2$ .

We now prove the theorem by induction on *n.* If *n =* 5 we must have U, = {4,5}, since IUs] >, 2. It follows from (33) that rankP[(1,2)](3,4,5)] = rank P[(3,4,5)](1,2)] = 1, completing the proof in this case.

We now assume the theorem to hold if the matrices under consideration have size less than *n (n >,* 6). Let r = ]U,] and let U, = { ji, j, ,..., j,}. If r = 0, it follows from (33) that rank P[(l, 2)](3,4,. *. . , n)] =* rank PM3,4,..., n)](l,2)] = 1, as required. Hence we may assume that r 2 1.

Given any i, 1 < i < T, consider *P(j,)* and Q(j,). It is clear they satisfy the conditions of the theorem, and therefore, by the induction hypothesis, there exists a partition ei, oi of Vi \ { ji } such that

$${\rm rank} \ P\left[1,2,\theta_{i}|3,U_{2},\omega_{i}\right] = {\rm rank} \ P\left[3,U_{2},\omega_{i}|1,2,\theta_{i}\right] = 1. \eqno(34)$$

The argument proceeds now along the same lines as the corresponding one in Theorem 2, and so will be described briefly.

If UT\_ro, =U,, then we get from (34) rankP[(1,2)](3,4,...,n)]= rankP[(3,4,..., n)](l,2)] = 1, so the theorem holds. Hence it remains to consider the case that U~\_rw, f Vi, and by relabeling we may assume j, eUi,iw,. Hence, if r > 1, we have j, •fli::ti~. Proceeding similarly, we see that the only case left to consider (after possible relabeling) is

$$\{j_{l+1}, \dots, j_r\} \subset \theta_l, \qquad l = 1, 2, \dots, r-1$$
 (35)

[(35) is of course vaccuous if r = 11. Next, if j, l t\_l~=,8,, we get from (34) and (35) that rank P[1,2, U,]3, Us] = rank *P[3,* U,]1,2, U,] = 1, so the theorem holds. Hence we may assume that if r > 1 then ji Eni,awi. Proceeding similarly, we see that the only case left to consider is when we have the

following 2r rank conditions:

rank 
$$P[1,2, j_2,..., j_r|3, U_2] = \text{rank } P[3, U_2|1, 2, j_2,..., j_r] = 1,$$

$$(36. j_1)$$

rank 
$$P[1,2,j_3,...,j_r|3,j_1,U_2] = \text{rank } P[3,j_1,U_2|1,2,j_3,...,j_r] = 1,$$
 (36.  $j_2$ )

rank 
$$P[1,2, j_4,..., j_r|3, j_1, j_2, U_2] = \text{rank } P[3, j_1, j_2, U_2|1, 2, j_4,..., j_r] = 1,$$

$$(36. j_3)$$

rank 
$$P[1,2,j_r|3,j_1,...,j_{r-2},U_2] = \text{rank } P[3,j_1,...,j_{r-2},U_2|1,2,j_r] = 1,$$

$$(36.j_{r-1})$$

rank 
$$P[1,2|3, j_1, j_2, ..., j_{r-1}, U_2] = \text{rank } P[3, j_1, j_2, ..., j_{r-1}, U_2|1,2] = 1$$

$$(36. j_r)$$

if r > 1 [here, it is also clear that (36. j,) is meaningful if r > 3, (36. j,) is meaningful if r > 4, etc.], or

$$\operatorname{rank} P[(1,2)|3, U_2] = \operatorname{rank} P[3, U_2|(1,2)] = 1 \tag{37}$$

if r=l.

In order to finish the proof in the remaining case we assume first that IV,] > 3, and let ml, ma E *U,.* Let *1 E {* 1,2} and consider Q(ml) and *P(ml).*  Since IV.] >, 3, it is clear that these two matrices satisfy the assumptions of the theorem, and by the induction hypothesis we may conclude that there exists a partition cpl, lc/l of U, such that

$$\operatorname{rank} P\left[1, 2, \varphi_{l} | 3, U_{2} \setminus \{m_{l}\}, \psi_{l}\right] = \operatorname{rank} P\left[3, U_{2} \setminus \{m_{l}\}, \psi_{l} | 1, 2, \varphi_{l}\right] = 1.$$
(38)

Comparing (38) successively with (36. j,),(36. j,\_ i), . . . ,(36. j,) if r > 1, or

with (37) if r = 1, we conclude that (P, = U,, 4, = 0, or else we are done. Since 1 E {1,2}, we get rank P[1,2, V,]3, V,] = rank P[3, U,]1,2, Vi] = 1, as required.

Finally, suppose that ]U,] = 2, and let Us = { m,,m,}. For I E {1,2}, consider P(m,) and Q(mr). Define %, by {fir} = V, \ {ml}. It is clear that the matrices P( mr) and Q( ml) satisfy Theorem 2 with { ii, i, } = { 1,2} and {is, i4} = (3, iizl}. Note that we cannot have %, E S,( P( m,), Q( m,)), or else Lemma 5 would imply that Q(m,) is diagonally similar to P( *m,),* which contradicts the assumptions of our theorem. Hence, there exists a partition (P,,I,!J, of Vi such that (38) holds. We now go on as in the case of ]U,] >, 3, completing the proof. n

We are now ready to prove our main result.

Proof of Theorem 1. The proof is by induction on n. The result is true for n = 4 by Theorem 5 of [7]. We now consider the general case, namely matrices A, B E *F"," (n 2* S), assuming the theorem to hold for matrices of order less than n, over an arbitrary field *F.* 

Define G and *H* by (13). Theorem 1, Lemma 3, and Lemma 4 of [7] imply now that G and *H* satisfy the assumptions of our theorem, and, moreover, all entries of G are nonzero. Moreover, Lemma 6 and the results of the appendix imply that G(i) and *H(i)* satisfy the assumptions of the theorem for at least three distinct integers i in N(n). Hence, by the induction hypothesis, if we let c = ]S,(G, H)U S,(G, *H)I,* then c > 3. If c > 5, then G and *H* satisfy property 9 by Lemma 5. If c = 3 or c = 4, then we get, by Theorem 2 or Theorem 4 and the fact that G satisfies (lo), that ]S,(G, *H)I >* 3 or ]S,( G, *H)I >,* 3. So, again, we may conclude by Lemma 5 that G and *H*  satisfy property 9. Finally, Lemma 4 of [7] implies now that while G and *H*  satisfy property 9 over the field K, = F( x1, xs, . . . , x "), A and B satisfy property 9 over the base field *F.* This completes the proof. n

# APPENDIX

The purpose of this appendix is to give some details that are required in the proof of Theorem 1. More precisely, the following fact was used in the proof of that theorem: if A, B satisfy the assumptions of Theorem **1 and G,** *H*  are defined by (13), then ]S,(G, H)uS,(G, *H)I >* 3. The sequence of the following results will yield a proof of this fact.

So we assume throughout that A and B satisfy the assumptions of Theorem 1, and G, *H* are defined by (13). We assume also that n > 5. Define

now a family d of ordered pairs of subsets of N(n) by

$$\mathscr{A} = \{(\alpha; \beta) : \alpha, \beta \in N(n), \ \alpha \cup \beta = N(n), \ \alpha \cap \beta = \emptyset,$$
$$|\alpha| \geqslant 2, \ |\beta| \geqslant 2, \ \text{and rank } A[\alpha|\beta] = 1\}. \tag{a.1}$$

REMARK A.l. Note that if (a; j3) E .& then (p; a) 4 &, because A satisfies (10).

REMARK A.2. We can now put some algebraic structure on &, using Lemma 1. Indeed, suppose (~;P)E&', (Y;~)E&'. Then if any+0 and /? n 6 # 0, we can form additional rank-l submatrices of A, namely A[a n yp3 u 61 and A[a u yl/? n S].

Itisthereforeclearthatif lanyl>-2then(any;puS)E~. Wesayin this case that we *row-intersect* (or briefly r.i.) (a; p) and (y; 8) to get (a n y; p u 8). Similarly, if I/3 n S( 2 2 then (a U y; p n 8) E -01, and we say that (a u y; /? n 8) is obtained from (a; p) and (y; 8) by *column intersection*  (c.i.).

REMARK A.3. Our approach to the proof of Theorem 1 also implies that if *n 2* 5 and i E *N(n)* is such that i P S,(G, ff)U S,(G, H), then there exists a partition ai, pi of *N(n)\{* i} such that Iail >, 2, [/?,I >, 2, and rank G(i)[a,I/?,] = rank *G(i)[&Ia,] =* 1. From Lemma 6 we conclude that either

$$(i, \alpha_i; \beta_i) \in \mathscr{A} \quad \text{and} \quad (i, \beta_i; \alpha_i) \in \mathscr{A}$$
 (a.2)

or

$$(\beta_i; i, \alpha_i) \in \mathscr{A} \quad \text{and} \quad (\alpha_i; i, \beta_i) \in \mathscr{A}.$$
 (a.3)

More generally, for an arbitrary element *i* of *N(n), we* say *i* is a bad index of type 1 if there exists a partition ai, & of N(n) \ { *i }* with Iail > 2, l&l >, 2 and such that (a.2) holds. Bad indices of type 2 are defined similarly, with (a.2) replaced by (a.3). For j = 1,2, we let 9j be the set of all bad indices of type j.

Note that if i is a bad index, the subsets ai and pi in (a.2) or (a.3) are not necessarily uniquely determined.

Using our new terminology, we have *N(n)\[S,(G,* ff)US,(G, H)] c Cifl U B2, and we want to show that 19i U .cS?~I < *n -* 3.

We consider first the simplest case, namely n = 5, and show J9jl< 1, j = 1,2. We show 1.9?r[ < 1, for the second case is analogous. So suppose 1 E .9?r. We may assume that the subsets (Y, and /3, that appear in (a.2) are {2,3} and {4,5}, so (1,2,3;4,5)~ .G.+' and (1,4,5;2,3)~ ~2. Suppose now that 19?r[ > 2. By symmetry, we may assume that 2 E 9?,, and also 1 E (us, where (us and /\$ are the subsets that appear in (a.2). Now, if CX~ ={ 1,3} we get &,= {4,5},so(2,1,3;4,5)~~and(2,4,5;1,3)~zZ. Wer.i.(1,4,5;2,3)and (2,4,5; 1,3) to get (4,5; 1,2,3) E .&, which is impossible because (1,2,3;4,5) E JI? (see Remark A.l).

Next, if (us = { 1,4} we get & = {3,5}, so (2,1,4;3,5) E ~2 and (2,3,5;1,4)~&'. Wer.i.(1,2,3;4,5)and(2,3,5;1,4)toget(2,3;1,4,5)EsP, which contradicts (1,4,5; 2,3) E LPP. Finally, the last case, namely (us = { 1,5}, & = { 3,4}, is ruled out similarly. *This concludes the case n = 5, and from now on we assume n > 6. The* sequence of next eight lemmas deals with elements of .%?r and 9,.

**LEMMA A.l.** *Let o =* {2,3,..., *n - 2}. Suppose that* **1 E 9?,** *and that aye, (the subsets that appear in* (a.2)) *are, respectively, o and { n -* 1, n }.

- (i) *n* 1 *and n do not belong to gI.*
- *(ii) At most one of n* **1,** *n belongs to .TB~. Zf one of them does, say n E gz, then we must have, for some* iEw, /I\$= {i,n-l} or (Y, = {i, *n -* **1).**

*Proof.* We have (1, w; *n -* 1, *n) E .&* and (1, *n -* **1,** *n; w) E z2,* and refer to these as l.L and l.R respectively.

(i): By the symmetry between *n - 1* and n it suffices to show *n @ ~3~. So*  suppose *nE.G?',.* Wemayalsoassume n-lEa,,andwelet (Y,= {n-l}u p. Thus, we have *(n, n -* 1, p; p,) E ~2 and *(n, &,; n -* 1, I\*) E .&, and we refer to these as n.L and n.R respectively. Note also that I&I > 2, IpI> 1, and p U& = {1,2 ,..., *n -* 2).

Suppose first that 1 E &. Since o f~ &, # 0, we may r.i. n.L and l.R to get *(n,n- 1;1,2 ,...,* n - 2) E .z?, which together with l.L is impossible. it remains to consider the possibility 1 E CL. Note that in this case & c o. We r.i. l.L and n.R to get (a,; *n, n -* **1, p) E .d,** which together with n.L is impossible.

**NOTE.** We showed in (i) that if 1 E .%'r and one of the subsets associated with it in (a.2) has two elements, then none of these elements can belong to .%?r. Of course, a similar statement holds if 1 E .c%'~.

(ii): We assume now at least one of *n -* 1, *n,* say n, belongs to 9Js, or else we are done, By the symmetry between on, fi, [the subsets that appear in (a.3)] we may also assume that *n -* 1 E C-X", and let (Y, = {n *-* l} U p. Thus, we have (p,; p, *n -* 1, *n) E &* and (cl, *n -* 1; /3,,, n) E &, and refer to these as n.L and n.R. Note also that ]&,I >, 2 and ]p] 2 1.

Suppose first that 1 E p. Then p,, c o, and if we c.i. l.R and n.R we get (p, *n -* 1, *n; /I,,) E d,* which together with n.L is impossible. It remains to consider the case 1 E /3,,, and then we have p c w. We want to show that ]p] = 1. Indeed, if ]p] 2 2, we c.i. l.R and n.L to get *(n, n -* 1, &,; II) E -01, and r.i. l.L and n.R to get (p; *n, n -* 1, &) E J&'. This is impossible. Hence ]~]=1,so~={(i}forsomeiEw.

Finally, *n -* 1 cannot belong to .Q?s, by the remark following the proof of (i) (applied to *n* rather than 1). n

**LEMMA A.2.** *Let x, y, z be three distinct elements of N( n). Suppose that 1and2beZongto.G3~and~,={r,y},&={y,z}.Z'henyP~',U~~.* 

*Proof.* Note that by part (i) of Lemma A.1 we must have { 1,2} *n*  {r,y,z}=er.Let 6=N(n)\{1,2,x,y,z}.Then,byassumptiononP, and &, a,={2,z}uS and a,={l,x}U6, and by (a.2) (1,2,z,S;x,y)~.&', (1, x, y;2, z, 6) E -c4, (2,1, x, 8; y, 2) E .zZ, (2, y, z; 1, x, 8) E A. We refer to these ordered pairs of subsets as l.L, l.R, 2.L, and 2.R respectively.

It is clear from part (i) of Lemma A.1 that y 4 gr, so it remains to prove that y G .G@s. Suppose y E .G?s. We apply now part (ii) of Lemma A.l. In fact, we do it twice, once considering l.L and l.R, and then considering 2.L and 2.R. This and the fact that *n > 6* imply cy,, = {x, z } or & = {x, .z }. Because of the symmetry between ey and &, we may assume (Ye = *{* x, z }. Hence, (1,2,6; y, x, Z)E -01, (x, z; y,1,2,6)~ ~2, and we refer to these as y.L and y.R, respectively.

We c.i. l.R and y.R and 2.R with y.R to get, respectively, (1, x, y, 2;2,S) E ti, (2, x, y, z; 1,s) E J&'. If we r.i. these two pairs and then l.L with 2.L, we get, respectively, (x, y, z; 1,2,S) E .EP' and (1,2,6; x, y, .z) E .\_E@, a contradiction. Hence y P .G?i U 9?s. n

**LEMMA A.3.** *Let x, y, z be three distinct elements of N(n). Suppose that 1and2beZongto3?~,and&={r,y},&={y,z}.ThenatZeastoneofx,z does not belong to B1* U B2.

Proof Wedefine 8, (ri, (us, l.L, l.R, 2.L, and2.RasinLemmaA.2. It is clear from part (i) of Lemma A.1 that x 4 .%?i and z E .%'i. It remains to show at least one of x, z does not belong to .G&'~. So suppose x and z belong to .%?a.

Applying part (ii) of Lemma A.2 and the symmetry between /I, and (Y, and between (Y; and /I,, we may assume CY, = { **u,** y } for some a + 1, and cx,= {b,y} for some *b#2.* Hence (&;x,a,y)~&, (a,y;x,&)~&, (/3,; z, *b,* **y** ) E J@, and *(b, y; z, /3,) E -01,* and we refer to these as x.L, x.R, z.L, and z.R respectively. It is clear that a f z, because of 2.L and r.R. Similarly, *b z x.* 

We show now that a f 2. Indeed, suppose a = 2. Then &\_ = { 1, .z } U S. We r.i. 2.L and x.L to get (1,6;2, X, y, Z)E XJ', and c.i. this with l.R to get (1, X, y, 6;2, Z)E .&. However, if we r-i. l.L and 2.R, we get (2, z; 1, X, y, 8) E ,rQ, a contradiction. Hence a # 2.

Next, we show *b #* 1. If *b =* 1 then j3, = (2, x } U 6. We r.i. 1.L and z.L to get (2,6; 1, X, y, z) E J&', and c.i. this with 2.R to get (2, y, z, 6; 1, x) E ~8. However, if we r.i. l.R and 2.L, we get (1, x; 2, y, z, 6) E .JY, a contradiction. Hence *b z 1.* 

We have shown a E 6 and *b E 6.* Suppose next that a = *b.* If we c.i. x.L and z.L, we get (N(n) \ {a, *y }* ; u, y) E -01, which is impossible because of x.R. Hence a # *b.* Let 8 = 8 \ { a, *b }.* We c.i. x.R with .z.R and get (a, *b, y;* 1,2, r, z, 8) E z?, and r.i. this pair with l.L to get (a, *b;* 1,2, X, y, z, 8) E &'. On the other hand, r.i. x.L and z.L to get (1,2,8; a, *b, x, y, z) E .A&',* and now c.i. this pair with l.R to get (1,2, X, y,, 8; a, *b, z) E a?.* Finally, c.i. the last pair with 2.R to get (1,2, X, y, z, 6; a, *b) E &,* a contradiction. This completes the proof. n

**LEMMA A.4.** *Let x, y, z be three distinct elements of N(n). Suppose that lund2belongto~',,undp,={x,y},p,={y,z}.ThenI~',U~~I~n-3.* 

*Proof.* We define 8, 1yi, os, l.L, LR, 2.L, and 2.R as in Lemma A.2. We know from Lemma A.2 and Lemma A.3 that y, and at least one of x, z, do not belong to .%?i u L&?~. It remains to consider the case that one of x, z does belong to 6@i U .9if2. By symmetry, we may assume it is X, and by part (i) of Lemma A.1 we must have x E 98s.

As in Lemma A.3, we may assume (Y, = {a, y }, and a must be an element of 6. Hence (/I,; x, a, y)~ ~2, (a, y; x, &)E &, and we refer to these as x.L and x.R. We let 8 = S \ {u}.

Our purpose is to show a E 99r U 9f2, for this will complete the proof. So suppose a E .9?i u ~3'~. By Lemma A.l, it must be a bad index of opposite type to that of X, that is, a E 5@,. Moreover, by the same lemma we may assumear,={y,b}forsomebP{u,x,y}.Hence,for~,=N(n)~{u,y,b} we have *(a, y, b;* jI,)E *z?* and (a, /3,; y, *b)E -01,* and refer to these as u.L and u.R. It is clear from Lemma A.1 and the fact that 1 E .4?i that *b +* 1 (in

fact, it is also easy to show *b #* 2 and *b # z,* but we don't use it). We r.i. l.R with a.R to get (1, X; 2, y, z, a, 8) E -01, and c.i. this pair with x.L to get (1,2, x, z, 8; *a, y) E .EY,* which is impossible because of r.R. This completes the proof. n

LEMMA AS. *Let x, y, u, v be distinct elements of N(n). Suppose that 1 and2belongto~',,und~~={~,y},~~={u,v}.~e~l~~~~~l~~-3~* 

*Proof.* Note that by part (i) of Lemma A.1 we must have { 1,2}n {x,y,u,v}=~zr. Let 6=N(n)\{1,2,r,y,u,v}, so (Y,={~,u,v}u~ and aa = (1, X, y}~6. Hence, (1,2,u,o,6;x,y)~ -01, (LX, y;2,u,u,6)~ d, (2,1, X, y, 6; u, v) E .&, (2, u, v; 1, X, y, 6) E .JZ?, and we refer to these as l.L, l.R, 2.L, and 2.R respectively.

By Lemma A.1 we have )9?r U .4Y21 <n - *3* unless exactly one of {x, y} and one of { u, v } are bad indices. So suppose this situation happens, and by symmetry we may assume x and u belong to GZ?~ U ~2?~. Hence, y and v do not belong to .c?Z~ u ~43~. Also, Lemma A.1 implies that x and u belong to G?a. Using the same lemma, we may assume a, = {a, *y }* for some *a #* 1, and a,,={b,v}forsomeb#2.Hence,forp,=N(n)\{x,a,y}andp,=N(n) \ { u, *b, v}, we have (P,; x, a,* Y> E d, (a, Y; x, P,..E d, <P,; u, b, v> E d, and *(b, O; u, /?,) E ~2,* and we refer to these as x.L, x.R, u.L, and u.R respectively.

We claim now that either a z v or *b # y.* Indeed, suppose *a = 0* and *b = y.* We c.i. x.L and u.L to get (1,2, x, u, 6; v, y) E &, which is impossible together with x.R. Hence a # v or *b f y.* 

Suppose first that a f v. If a @ .%i U B2, we have 193i U .bS21 <r~ - 3, as *a, u, y @ ~9~* U B2. Hence suppose that a is a bad index. By part (ii) of Lemma A.l, a must then be a bad index of opposite type to x, namely aE98,, and either fi, or a, is equal to *{ y,* c} for some c f X. By the symmetry between fi, and a, we may assume fi, = { y, c}. We now have (.%?i U CS~~I< *n -* 3 by Lemma A.4, applied to the type-l bad indices 1, *a.* 

It remains to consider the case *b # y.* If *b P 9?l* U CZ2 then l.G?i U .GY21 G *n - 3,* since *b, y, v E ~8~* U 33,. Hence suppose now *b* is a bad index. The proof now goes on as in the preceding case. We must have *b E .%?I,* and we may assume fi,, = {v, *d }* for some *d # u.* We now have IQ1 U Sf21 G n - 3 by Lemma A.4, applied to the type-1 bad indices 2 and *b.* n

LEMMA A.6. *Let i and j be two distinct elements of al, and let ai, pi, cxj, pi be the subsets corresponding to i and j in* (a.2). *Suppose that jfzai, iEai, and let Gi=ai\{j}, Ej=aj\{i}. Then,* none *of the* 

following can hold:

- (i)  $\tilde{\alpha}_i \cap \beta_i = \emptyset$ ,
- (ii)  $\tilde{\alpha}_{j} \cap \tilde{\beta}_{i} = \emptyset$ , (iii)  $\tilde{\alpha}_{i} \cap \tilde{\alpha}_{j} \neq \emptyset$  and  $|\beta_{i} \cap \beta_{j}| \ge 2$ .

*Proof.* We have  $(i, j, \tilde{\alpha}_i; \beta_i) \in \mathcal{A}$ ,  $(i, \beta_i; j, \tilde{\alpha}_i) \in \mathcal{A}$ ,  $(j, i, \tilde{\alpha}_i; \beta_i) \in \mathcal{A}$ , and  $(j, \beta_i, i, \tilde{\alpha}_i) \in \mathcal{A}$ , and refer to these as i.L, i.R, j.L, and j.R respectively. We have of course  $|\beta_i| \ge 2$  and  $|\beta_i| \ge 2$ , but also  $|\tilde{\alpha}_i| \ge 2$  and  $|\tilde{\alpha}_i| \ge 2$ , because i and j belong to  $\mathcal{B}_1$ .

Proof of (i): Suppose  $\tilde{\alpha}_i \cap \beta_j = \emptyset$ . Then  $\tilde{\alpha}_i \subset \tilde{\alpha}_j$  and  $\beta_i \supset \beta_j$ . Hence, if we r.i. i.R and j.R we get  $(\beta_i; i, j, \tilde{\alpha}_i) \in \mathcal{A}$ , and if we c.i. i.L and j.L we get  $(i, j, \tilde{\alpha}_i; \beta_i) \in \mathcal{A}$ , a contradiction.

Proof of (ii): exactly as in the previous case.

Proof of (iii): Suppose  $\tilde{\alpha}_i \cap \tilde{\alpha}_i \neq \emptyset$  and  $|\beta_i \cap \beta_i| \ge 2$ . We r.i. i.R and j.R to get  $(\beta_i \cap \beta_j; i, j, \tilde{\alpha}_i \cup \tilde{\alpha}_j) \in \mathscr{A}$ , and c.i. i.L and j.L to get  $(i, j, \tilde{\alpha}_i \cup \tilde{\alpha}_j;$  $\beta_i \cap \beta_i \in \mathscr{A}$ , a contradiction.

Before going on with our results we need two additional definitions.

**Definition.** Suppose that  $i \in \mathcal{B}_1$ , and let  $\alpha_i, \beta_i$  be the subsets corresponding to i that appear in (a.2), i.e., such that  $(i, \alpha_i; \beta_i) \in \mathscr{A}$  and  $(i, \beta_i; \alpha_i)$  $\in \mathcal{A}$ . As indicated in Remark A.3,  $\alpha_i$  and  $\beta_i$  are not necessarily uniquely determined. We say  $\beta_i$  is minimal for i if for every partition  $\gamma_i$ ,  $\delta_i$  of  $N(n)\setminus\{i\}$  such that  $(i,\gamma_i,\delta_i)\in\mathscr{A}$  and  $(i,\delta_i,\gamma_i)\in\mathscr{A}$  we have  $|\beta_i|\leqslant |\gamma_i|$  and  $|\beta_i| \leq |\delta_i|$ . This, in particular, implies  $|\beta_i| \leq |\alpha_i|$ .

**DEFINITION.** Let S be an arbitrary finite set such that  $|S| \ge 5$ , and suppose that  $i_1$  and  $i_2$  are distinct elements of S. Let  $\varphi_{i_1}, \psi_{i_1}, \varphi_{i_2}, \psi_{i_2}$  be subsets of S such that  $|\varphi_{i_{\iota}}| \ge 2$ ,  $|\psi_{i_{\iota}}| \ge 2$ , and  $\varphi_{i_{\iota}}, \psi_{i_{\iota}}$  form a partition of  $S \setminus \{i_k\}$ , k = 1,2. We say that  $i_1$  and  $i_2$  are stable with respect to  $S, \varphi_{i_1}, \psi_{i_2}, \varphi_{i_2}, \psi_{i_2}$  if and only if the following holds: let

$$\gamma_{i_1} = \left\{ \begin{aligned} \varphi_{i_1} & & \text{if} & i_2 \in \varphi_{i_1} \\ \psi_{i_1} & & \text{if} & i_2 \in \psi_{i_1} \end{aligned} \right\}, \qquad \delta_{i_2} = \left\{ \begin{aligned} \varphi_{i_2} & & \text{if} & i_1 \in \varphi_{i_2} \\ \psi_{i_2} & & \text{if} & i_1 \in \psi_{i_2} \end{aligned} \right\}$$

and let  $\tilde{\gamma}_{i_1} = \gamma_{i_1} \setminus \{i_2\}$ ,  $\tilde{\delta}_{i_2} = \delta_{i_2} \setminus \{i_1\}$ . Then  $\tilde{\gamma}_{i_1} \supset (\varphi_{i_2} \cup \psi_{i_2}) \setminus \delta_{i_2}$  [which is equivalent to  $\tilde{\delta}_{i_2} \supset (\varphi_{i_1} \cup \psi_{i_1}) \setminus \gamma_{i_1}$ ].

Thus, for example, if  $i_2 \in \varphi_{i_1}$  and  $i_1 \in \varphi_{i_2}$ , this stability just means that  $\varphi_{i_1} \setminus \{i_2\} \supset \psi_{i_2}$ , or equivalently,  $\varphi_{i_2} \setminus \{i_1\} \supset \psi_{i_1}$ .

**LEMMA** A.7. *Let* i *and j be distinct elements of .@I, and let ai> Pi> a -, Pj be the subsets corresponding to* i *and j in* (a.2). Suppose *that pi* is minima *I for i, pi is minimal fOr j, and l&l Q Ipjl. Thc?n j E (yi.* 

- Proof. Suppose j e q, so j E/3,. Let fli=pi \ { j}. Then we have (i, (Yi; j, Bi) E d, (4 j, Bi; ai) E d, (j, aj; /Ii) E d, (j, pj; 'Y~) E d, and refer to these as i.L, i.R, j.L, and j.R respectively. Note that we have IPi1 >, 2, as j E 99i.
- Case I. Suppose that i E oj. Let ~5~ = (Y j \ { i *}, so* j.L and j.R are (j, i, Go; pi) and (j, pi; i, 2j). Then pi n pi # 0 and gj n ai # 0, by (i) and (ii) of Lemma A.6. Next, we want to prove 14 n Pjl = 1. Indeed, if lpi n Fiji 2 2, we c.i. i.L and j.L to get (j, i, oi u Lij; pi n pi) E d, and r.i. i.R with j.R to get (j, & n pi; i, q **u iij) E d.** But these two members of ZZ? and the minimality of /?. for j imply now l/3jl < lPj n&l, **SO Pi 1 Pi. Hence\_ IPi1 > IPjl,**  but this contra&s the assumption lpi1 > l&l = l&l+ I. Hence IPi n Pjl= I. It follows that oi n fij # 0 and Gj *n pi f 0,* so by (iii) of Lemma A.6 we must have lq n pjl = 1. Hence we conclude that Ipi1 = 2, so. l&l Q 2, but this contradicts l&l = l&l - 12 2. Hence this case cannot occur.
- Case 2. It remains to-consider the \_case i E Pj, **SO** let fij = Pj \ { i }. Then j.L and j.R are (j, CY~; i, pi) and (j, i, pi; ai). The proof proceeds now as in the previous case, interchanging the roles of j.L and j.R. Doing that, we get j3,naj/m, ainbjzO, I&najl=l, ainaj#IzI, ,&npj#O, and finally lai n ail = 1. H ence 1~~~1 = 2, which is impossible, since Ioil > Ipi1 > l&l = lpi1 +1>3. n
- **LEMMA A.&** *Let i and j be distinct elements of .~8~, and let ai, Pi, aj, Pj be the subsets corresponding to* i *and j in* (a.2). *Suppose that pi is minimal for i, pj is minimal for j, and l&l < IfijI.*
- (i) *Zf* iEa., *then either* i *and j are stable with respect to N(n>, 0Li3 Pi,* "j> Bj> Or lPil= lPjl **=** 2 ad IPi nPjl= l.
- (ii) *Zf* i E pi, *then either i and j are stable with respect to*  N(n),ai>Pi,aj,Pj3 Or IPilc2 afd I~jnPil=lPin(Pj\(i}>l=l.
- Proof. We have j E q by Lemma A.7, so let Ei = ai \ { j}. Hence (i, j, Ed; pi) E .RZ, (i, pi; j, ci) E d, (j, aj; Pj) E d, (j, Pi; "j) E dy and we refer to these as i.L, i.R, j.L, and j.R, respectively.
- (i): Let &j = aj \ {i}, *so* j.L and j.R are (j, *i, Ej; /3,>,( j, Pj; i, gj)> respec*tively. Then Ci n pj # 0 and gj *n pi # 0* by (i) and (ii) of Lemma A.6. Suppose now that IGin pjl > 2. We c.i. i.R and j.L to get (j,i, Gj U Pi; gi n pi) E d, and r.i. i.L and j.R to get (j, Zi n Pi; *i, Gj U Pi) E d. Since Pj*

is minimal for j, we get gi 1 pi (and therefore also Gj 1 pi), so i and j are stable with respect to iV(n),cu,,&, aj,pj. If IGj n&l > 2, to get the same conclusion we c.i. j.R with i.L, r.i. j.L with i.R, and use the minimality of pi.

Hence it remains to consider the case ICi n pjl = (~5 j n pi I = 1. Since /piI 2 2, we clearly have pi *n pi # 0.* Also, i E .?ifi, and therefore part (i) of Lemma A.1 implies that Igjl > 2, so &ii f' sli f 0. Hence it follows from part (iii) of Lemma A.6 that I& n /Ii1 = 1. This and I& n piI = IGj n&j = 1 imply [piI = Ipi1 = 2, completing the proof in this case.

REMARK A.4. Note that if the conclusion [/?,I = lp,j = 2, Ipi npjI = 1 holds in (i), then l.%r U B2/ < n - 3 by Lemma A.4.

(ii): Let Sj = pi \ {i}, so j.L and j.R are ( j, CX!; i, pj),( j, i, fi,; CY j), respectively. Then &ii *n aj f 0* -and pi n pj # 0 by (1) and (ii) of Lemma A.6. Suppose now that I/?, n pjl 2 2. We c.i. i.L and j.L to get *(i, j, si* U aj; pi n sj) E a', and r.i. i.R with j.R to get (i, & n pi; j, gi U aj) E d. Since pi is minimal for *i, we* get bj 2 pi (and therefore also Gi 1 (Ye), so *i* and j are stable with respect to N(n), q, pi, oj, pi.

It remains to consider the case I/3, n pjl = 1. Then, as l&l >, 2 and lpjl 2 2, we have gi n jj #0 and aj fl pi # 0. It follows from part (iii) of Lemma A.6 that ICY j n pi I = 1. Hence I/3, I = 2, completing the proof. n

The preceding lemmas dealt with elements of .%r and Bs. The next one deals with more general subsets and the concept of stability introduced earlier.

LEMMA A.9. *Let S be a* finite *rwnempty set, and p a positive integer. Let S,= {i,,i,,..., iP} be a subset of* S. *Suppose the following conditions hold:* 

- *(i) For every k,* 1~ *k < p, there exists a partition qk, qk of S \ {* ik} *such that lqkl>, 2 and I#J > 2.*
- (ii) *For every* 1 <k *< 1~* p, i, *and i, are stable with respect to s, Q)k> +k> 'PI? 4,.*
- *(iii) Denote by 9 the set* consisting *of the* 2p *ordered pairs (of subsets of S) (ik, (Pk; \$k),(ik' \$k; (Pk)? k = 1,2,..., p.* Then *there does not exist a partition cp, 4 of S with IqI 2* 2, I\$[ > 2 *such that (cp; \$) and (+; 'p) belong to 9. Then* ISJ 2 2p +3.

*Proof.* The proof is by induction on *p.* The case *p =* 1 is trivial, so we proceed to the case of a general *p (p >,* 2).

Among the subsets (Pi, Gk, 1 Q *k < p,* there is one of minimal cardinality. We may assume it is J,~. We want to prove now i,, . . . , i, E 'pl. Suppose this is not true. Then, we may assume (possibly after relabeling) is E \$,, and then let *\$l=+l\{iz}.* F rom the definition of stability of i,, *i,* with respect to S, cpl, JIM, 'pz, qz it follows now that either 4: 3 'ps or 4,3 \$s, contradicting the minimal-cardinality assumption on +i

Hence i, ,..., i,~cp,. Let J/i=(u,,u, ,..., ut} for some t>2. By the symmetry between cp, and J/k we may assume ii E (Pk, 2 d k 6 p. AlSO, let @i=~i\{is,..., ip} and *i&=(Pk\{iI},2<k<p.* 

Given any *k,* 2 < *k < p,* the stability condition for *i,* and ik implies that @k 2 #i. Because of assumption (iii) we must have strict inequality. Thus, if **Welet** @k=@k\+l,thenI\$k+O and +\$=\$1U+k, #ln&=0.

Consider now a new set S', obtained from S by deleting i, and ul. Let S;= {ia,..., i,}.Forany2<kgp,let q;=@kU(\$l\{U1})and I&=#~. Since t 2 2 and Gk z 0, it is clear that Ic+\$I > 2, I+;[ > 2, and 'p)k, I& form a **partition** of S' \ { i, }. If we can show that assumptions (ii) and (iii) of the lemma are also satisfied for the new system, then, by the induction hypothesis, IS'1 = IS1 - 2 z 2(p - 1)+3 = *2p +* 1, *SO our* result holds.

It is clear from the way S' was formed (just deleting ii and u1 wherever they appear) that *ik* and i, are stable with respect to S', &, 4;. @;, J/i for any two distinct elements *k, 1* of *(2,.* . . , *p }.* Hence (ii) is satisfied for the new system.

Finally, we have to show that (iii) is satisfied for our new system. So let 9" be the set consisting of the 2(p - 1) ordered pairs of subsets (ik,(P;; #;),(ik, rF/i; Cp;), k=2,..., *p.* If (iii) does not hold now, there exists a partition cp', \$J' of S' with Iv'1 >, 2, I#'1 > *2,* and (q'; #') E s"', (4'; q') E 9'. Since 'pi 3 { us,. . . , ut } for every 2 Q j Q *p, we* only have to consider the case (cp';\CI')=(ikr~;;\$;), (#';~p'>=(i~,\$~',;cp'J for some *k,lE{%...,p}, k+I.*  Therefore we get { i,}~ (p;, = 'pi and J/i = { i,}U I/J;. Going back to the original system, we have (Pk=&U{iI,uI}, qI='P;,U{iI,+ik}, \$\$=+[, + k = { i, } U J, 1. Hence the set 9 contains the ordered pairs of subsets (ik, q,; *#k) = cikr 1 '1 , up vi; 4, \$I) and (it, +I; cpl) = (ir, +I; i,, U1, ik, QDg.*  which contradicts assumption (iii) on the original system. This completes the proof. n

We state now the main result of the Appendix, concerning the cardinality

**THEOREM A. 1.** *Suppose that the matrices* A *and B satisfy the assumptions of Theorem* **1,** the *matrices G and H are defined by* (13), and *n >* 6. *Let .@I and .@'z be defined as* in Remark A.3. Then lgi u .cS?~I f *n -* 3.

Proof. We show first, considering just B'i, that

$$|\mathcal{B}_1 \cup \mathcal{B}_2| \leqslant n - 3 \quad \text{or} \quad n \geqslant 2|\mathcal{B}_1| + 3 \tag{a.4}$$

It will turn out that establishing (a.4) constitutes a major part of the proof, and will lead immediately to its completion.

It is obvious that (a.4) holds if l.G?il < 2, so we may assume Bi = {ii,&,..., i, } for some r >, 2. For j = 1,2,. . . , r, let aj, pj be the subsets corresponding to *ii* in (a.2), i.e., such that (it, oj; pi) E &, (ij, pj; oj) E &. We'll refer to these ordered pairs as ir.L and zj.R, respectively. Without loss of generality we may assume that pi is minimal for j and that

$$|\beta_1| \leqslant |\beta_2| \leqslant \cdots \leqslant |\beta_r|. \tag{a.5}$$

It follows from Lemma A.7 that

$$\left\{i_{j+1},\ldots,i_r\right\} \subset \alpha_j, \qquad j=1,\ldots,r-1.$$
 (a.6)

Suppose now that I/3,1 > 3. It follows from Lemma A.8 that *i,* and *i,* are stable with respect to N(n), (Ye, Pk, q, PI for any two distinct elements *k, 1* of {I,2,..., r }. This fact, Remark A.l, and Lemma A.9 imply that n > 2lS?',l+3, so (a.4) holds. Hence, it remains to consider the case lpi1 = 2, so let ~,={x,y}.ItisclearfromLemmaA.1that~,~{i,,...,i,}=0.

Next, suppose that I&I = 2. It is trivial to check that & = { X, y } is impossible, so Ipl n /&I d 1. Then, by Lemma A.4 or Lemma A.5, IGYi U .SY21 6 n - 3, so (a.4) holds. Thus, we may assume from now on that I&,[ 2 3. We may also assume r > 3, because l&l > 3 implies Ic+/ >, l&l > 3, so *n >,* 7. Hence, if r = 2 it is obvious that (a.4) holds. The fact that l&l > 3 also implies, by Lemma A.8, that *i,* and i, are stable with respect to N(n), ok, Pk, or, /3, for any two distinct elements *k, 1* of (2,. . . , **r }.** 

Our next goal is to delete two elements, ii and one of { x, y }, from N(n) and to obtain in this way a new set for which Lemma A.9 holds. For that purpose we need some additional information on the subsets ej, pi, j = 2 ,.\*., r.

If l&l > 4, then lryjl > 4 and [piI > 4 for j = 2 ,..., T. Hence, if we pick any element of {x, **y }** and delete it from each of the subsets oj, pi, j = 2,. *. . , r,*  to which it belongs and do likewise for *i,,* then all the newly formed subsets contain at least two elements.

Suppose now that l&l = 3, and let *h* be a positive integer such that 3 = l&l = . . . =JPhJ<Jj?h+lJ. Hence 2g h<r. We claim that nix SYi\ {i,, ii} for any 2 < j < *h. So* suppose there exists j, 2 < j < *h,* for which this statement is false. Then, by (a.6), there exists *k, 2 < k < j,* such that i, E pi. Since ij E (Ye and *i,, ii* are stable with respect to *N(n), (Yk, flk, aj, Pj, we get pj \ { ik} I fik,* which contradicts Ipi] = ]Pk] = 3. Hence cyj 3 .%?i 1 {i,, *ij}*  for any 2 < j < *h.* 

We prove now that ]cY~( >. 4 for every 2 < j < T. This is clearly true if *h < j G r, so* assume 2 G j < *h.* If *h < r,* then 4 < ]P,] < ]a,]. Now ayi contains i, [by (a.6)] and also, by the stability of ij, i, with respect to *N(n), aj, Pi, ar, &, it* contains /?, or (Y,. Hence (cY~] > 4. If *h = T, we* can choose, since *h = r >* 3, *k E {2,..., h}* such that *k # j.* Then ik E cyj, *ii E (Ye,* and 'Y~ \ { *ik}* contains fik by the stability of ij, *i,* with respect to N(n), aj, pi, (Ye, Pk. Therefore ]cq >, 4.

The stability condition just mentioned also implies there exists at most one element j in (2,. . . , *h }* such that i, E pi. If such an element exists, let it be j,. We can apply part (ii) of Lemma A.8 to the elements i, and ij,) of .GYI. The first conclusion there cannot hold, since it would mean pj, = { ii, X, y }, which is impossible by Remark A.J. Hence, the second conclusion there applies, which means exactly one of {x, y } belongs to pj,. We may assume \* E Pi,\*

The discussion of the case I&] = 3 shows that if we delete y from each of the subsets aj, pj, j = 2,. . . , r, to which it belongs and do likewise for *i,,* then all the newly formed subsets contain at least two elements.

Let *S=N(n)\{i,,y}* and S,={i, ,..., *i,}.* For *k=2 ,..., r,* let (Pk be the subset of S obtained from (Ye by deleting every element of {i,, y } that belongs to (Ye; +l~~ is the subset of S obtained from Pk in a similar way. It is now clear from the preceding discussion and the fact that LQ and Pk form a partition of N(n)\{ ik}, that ]qk] >, 2, (\$k( > 2, and qk, \$k form a partition of S \ { i, }. We want to check that (ii) and (iii) of Lemma A.9 are satisfied for the system we have just defined.

Since i, and *i,* are stable with respect to *N(n), (Yk, fik, aI, Pr* for any two distinct elements *k,* 1 of { 2,. . . , r }, it is clearly true that they are stable with respect to S,q,, Gk,(pl, Gr. Hence (ii) of Lemma A.9 holds for our new system, and it remains to check (iii) of that lemma.

Suppose (iii) does not hold. Let 9 be the set of 2( r - 1) ordered pairs (i!@vk; lcik),(ik, *#k; (Pkh k = 2,. . . , r,* and suppose there exists a partition cp, 4 of S such that ]'p] > 2, I#] > 2, and (cp; \$),(#; 'p) belong to 9.

Since i, belongs to n;liqj because of (a.6) it is impossible that (91; \$) = *(ik, cpk; I/.J~)* and (4; cp)= (i,,cp,; 4,) for *k z 1,* 2 < *k, 1~ r. So we* check first the possibility that (cp; \$) = *(ik, qk; \$k)* and (I/J; cp) = *(ir, t,bl; cp!).* We must have *k > I,* because of (a.6).

Suppose that i, E (Ye. We apply part (i) of Lemma A.8 to the elements *i,*  and *i,* of gi. Since ]Pk] >, 3, we must have {x, y} C (Ye, and therefore #k = Pk. If *i, E aI,* then by a similar reasoning {x, y} c (Y! and Gr = p,.

Hence Pk = +!J~ = 4 = { i,}U +I = { ir}Up,. But the two ordered pairs (ik, ok; Pk) and (il, pl; a!) belong to ~4, and this contradicts Remark A.l. If i, E Pr, we apply part (ii) of Lemma A.8 to ii, i, E .Qi. It follows that at least one of {x, y } belongs to PI. Since r E (Yk, we have x E 9)k. Hence X E cpr C (Y/, sowemusthavey~~l,and~1=~l\{i,,y}.AlsO,P~=~k=J,={i~}U~~, so we must have lpll = [4~+2 = Ipkl+ 1, contradicting the fact that I < *k.* 

C\_onsider next the case *i, E pk.* Let bk = yk U fik, pl = yI U PI, where pk and PI are disjoint of {i,, *x, y}* and yk, yI contained in {i,, *x, y}. It* follows from part (ii) of Lemma A.8, applied\_ to ii, *ik E .%I,* that yk n {x2 y } Z 0. Computing \$k and JIl, we get lC'k=&U(yk\{ii,Y}) and \$I=PIU(~\ {i,, y }). Since 4 = \$k = { *ir}* U #!, we must have

$$\tilde{\boldsymbol{\beta}}_k = \{i_l\} \cup \tilde{\boldsymbol{\beta}}_l.$$

We want to show that yI#O. Suppose yI=O. Then {ii,x,y} C(Y~, so lettingGil=clll\{i,,x,y},weget GLn{il,x,y} =0 and **al=** *{i,,x,y}U&.*  Therefore 'pI = {r **}** U gi, and #l= p,. We also know that J, = \$k = { i[} U \$1 and cp='p[= {ik}U(Pk. Therefore rE(PkC(Yk, and since Ykn{x,y} Z0, we must have yk = (ii, y}. We conchide that P1 = PI, ok = (Pk, Pk = Yk U pk= {ii,y}U{i,}Upl= {ii~%i~~U~l~ q= {ir,Y}u~,= {il~Y~ik~u~k~ ~~=N(n)\{i,,x,y}={ils,i~}U~~U(~k~{~}).Wemaynowc.~. i,.Rand i,.L to *get (il, i,, y, ak; i,, PI) E at',* which together with i,.R is impossible, by Remark A.l. Hence yI # 0.

We want to r.i. i,.L and *ik.L.* Since I{ *il}* U oil= n - 2 and Iakl > 4 (as *we* have shown), the set *({il}ua~)n({ik}ua~> CerhhdY has at h.st two*  elements. The sets pi = {x, **y }** and Pk = yk U Pk have a common element, because yk n {x, y **}** *# 0.* Hence, we may r.i. *i,.L* and ik.L and get

$$((\{i_1\} \cup \alpha_1) \cap (\{i_k\} \cup \alpha_k); i_1, x, y, \tilde{\beta}_k) \in \mathscr{A}.$$

Sin? yI # 0, we may now c.i. i,.R and i,.R and get, using also p, = { il}U& that ( ii, X, y, Pk; (pi n q) E d [note that we do have Ia1 n q( & 2, afactwhichcanbeshowndirectlyorbecause *"1nal=({i,}U(Yl)n({ik}U ak)].* These two elements of &' contradict Remark A.l. Hence the case (q; #)=(ik?qk; J/k)? (4; q)=(i[, \$I; vl) cannot Occur.

Finally, we check the possibility (q; JI) = (ik, \$k; (Pk), (\$; (p) = (ir, IC/r; qr) for some *k, 1 E* (2,. *. . , r}, k < 1.* By (a.6) we have *i, En;I:cpj, so we* must have 1= r. We define gi, = ok \ {i,}. Since ik E cp = q,. C q, we may define &=(r, \{ik}. Recall dS0 that *ik* and *i,* are stable with respect to N(n)9 ak9 *Pk, % &.* 

We show first that *i* 1 E fik and *i, E &* is impossible. Indeed, if *i, E &,*  then we must have *i, E ak* by the stability just mentioned. Next, we claim

i, E Gi, and *i, E fir* is also impossible. Indeed, suppose it does happen. Then, by part (i) of Lemma A.8, and since lPkl >, 3, we must have {r, y} C L%~. Similarly {x, y } *c ii,.* Therefore x E qk n 'p,, so x E 'p n 4 = 0, a contradiction.

Suppose that i, E Gi, n &. As in the preceding argument, we must have {x, y} c si,, so let gk = Gk \ {i,, *x, y}.* Let P, = y, U br,, G, = 6, U &,, where {ii, x, y } contains y, and a,, and is disjoint of &,. and of &. Since x E qk = \$, then r E 4, *C &,* and therefore {ii, x} *C y,. We* have (Pk = {i,, *x}* U &k, I)~ = Pk, cp,= {i,}U&,,\$,= {xkU&. Therefore cp= {ik}UPk,={it}U& and ~={i,,x}Udk={i,,x}Up,,sowegetPk=~,and~Lk=p,.

If y, = { ii, x, y } then 8, = 0, and by the preceding discussion the ordered pairs i,.R and i,.R are respectively (ik, d,; *i,, i,, x, y, &) E ~9'* and . . (zl, zi, r, y, hk; i,, &,)E JX?. This is impossible by Remark A.l. It remains to consider the case y, = {i,, *r}, 6, = {y}.* We c.i. i,.R with i,.R to get *(i,, i,, x,y, fik; i,, &,) E s?,* but i,.R is (ik, &; i,, *i,, x, y, ijk),* and this again is impossible by Remark A.l.

The case *i, E Pk* **n Sr** is ruled out in a similar way. Alternatively, we observe there is a complete symmetry between the cases i, E Gi, fl fi, and i 1 E fik Cl ST, since we don't use in the proof arguments on ( fik 1 and I& 1.

We showed that the assumptions of Lemma A.9 are satisfied for S = N(n)\{i,,y}, S,= {ia,..., i,}, and subsets (pi, \$j, 2 < j < r. Hence, *n -* 2 = ISI > 2(r - 1)+3, so *n >* 2r +3 = 2lg',l+3. Thus, (a.4) holds. Because of the symmetry between .%Y, and g2 we may prove analogously

$$|\mathcal{B}_1 \cup \mathcal{B}_2| \leqslant n-3 \quad \text{or} \quad n \geqslant 2|\mathcal{B}_2|+3. \tag{a.7}$$

But (a.4) and (a.7) together imply lgi U 9321 < *n -* 3, because if *n >* 2lg',l+3 and n>2).%'a1+3 then2n>,21&?',1+21~!,1+6.Thiscompletestheproof. n

REMARK A.5. It can be shown that the upper bound n - 3 for l.%i u .9?21 is sharp in the sense that it can be attained, at least for the values *n =* 5,6,7,8.

This *research was supported by The Fund for The Promotion of Research at the Technion.* 

# REFERENCES

- **1 L. Basset, J. Maybee, and J. Quirk, Qualitative economics and the scope of the correspondence principle,** *Econmhica* **36544-563 (1968).**
- **2 G. M. Engel and H. Schneider, Cyclic and diagonal products on a matrix, Linear Algebra Appl. 7301-335 (1973).**

3 G. M. Engel and H. Schneider, Matrices diagonally similar to a symmetric matrix, Linear Algebra A&. 29:131-138 (1980).

- 4 G. M. Engel and H. Schneider, Algorithms for testing the diagonal similarity of matrices and related problems, SIAM I. *Algebraic Discrete Methods 3:429-438*  (1982).
- 5 M. Fiedler and V. Ptak, Cyclic products and an inequality for determinants, *Czechoslovak Math. J* 19:428-456 (1969).
- *6* F. R. Gantmacher, *The Theory OfMatrices,* Vol. I, Chelsea, New York, 1966
- 7 D. J. Hartfiel and R. Loewy, On matrices having equal corresponding principal minors, Linear Algebra A&. 58:147-167 (1984).
- 8 D. J. Hartfiel and R. Loewy, A determinantal version of the Frobenius-Kdnig theorem, to appear.
- 9 B. D. Saunders and H. Schneider, Flows on graphs applied to diagonal similarity and diagonal equivalence for matrices, Discrete *Math. 24:205-220 (1978).*

Received 3 *January 1985;* revised 11 *June 1985*