![](_page_0_Picture_2.jpeg)

# **Coarsening dynamics of phase-separating systems**

By A. J. Bray

Department of Physics and Astronomy, University of Manchester, Manchester M13 9PL, UK and Laboratoire de Physique Quantique (UMR C5626 du CNRS), Universit´e Paul Sabatier, 31062 Toulouse Cedex, France

Published online 3 March 2003

When a system such as a binary liquid is cooled rapidly from a homogeneous phase into a two-phase region, domains of the two equilibrium phases form and grow ('coarsen') with time. In the absence of an external drive, such as gravity or an imposed shear flow, a dynamical-scaling regime emerges in which the domain morphology is statistically self-similar at different times, up to an overall length-scale (coarsening scale) that grows with time. In the first part of the paper, the scaling phenomenology will be reviewed and the time-dependence of the coarsening scale will be discussed in the context of a number of different physical systems and scaling regimes. In the second part, the influence of an external drive, in particular a shear flow, will be addressed and recent developments reviewed. Interesting open questions include the late-time behaviour under shear and whether the coarsening continues indefinitely or is ultimately arrested by the shear flow.

**Keywords: phase separation; coarsening; dynamical scaling; shear flow**

#### **1. Introduction**

The coarsening dynamics of two-phase systems quenched rapidly from the homogeneous phase into the two-phase region has been studied for some 40 years (see Bray 1994, and references therein). Standard examples include binary alloys, binary liquids and polymer blends, but recent studies of coarsening phenomena include liquidcrystal systems and soap froths. Much is well understood, as least qualitatively, but there are still a number of interesting open questions. In this paper the fundamental ideas are reviewed before I discuss the areas that are still to be understood.

The outline of the paper is as follows. In the first part the fundamental processes underlying phase separation are discussed, before moving on to a presentation of some standard dynamical models, known as models A, B and H, which describe different types of system or different coarsening regimes within the history of a given system. Then the concept of dynamical scaling will be introduced and exploited, in conjunction with simple physical arguments, to determine the 'growth laws' that describe the time-dependence of the domain structures. This will bring us to the first of the 'open questions', which concerns the late stages of coarsening in a binary

One contribution of 14 to a Discussion Meeting 'Slow dynamics in soft matter'.

![](_page_1_Picture_3.jpeg)

Figure 1. Snapshots of size 256 × 256 of spinodal decomposition at times t = 70, 381 and 3761 (from left to right). The two shades represents the two phases. (Reproduced with permission from Berthier (2001).)

liquid. When the inertial terms in the Navier–Stokes equation come into play, a naive analysis suggests that the Reynolds number grows without bound. The main question is how to determine the growth law in this non-trivial regime. The final part of the paper concerns the role of an imposed shear flow. The question of whether shear arrests the coarsening, or whether coarsening continues indefinitely, will be addressed.

#### **2. Phase separation and coarsening**

When a system that, in equilibrium, phase separates under cooling is quenched rapidly into the ordered phase, domains of the two equilibrium phases form and grow (coarsen) with time. There are two possible mechanisms for the initial domain formation, as discussed by Gerard et al. (2003). These are nucleation and growth, and spinodal decomposition.

- (i) If the quench terminates at a point outside the spinodal curve, the system is stable against small fluctuations. Rare, thermally activated, large fluctuations create 'critical droplets' (nucleation) which subsequently coarsen (growth).
- (ii) If the quench terminates at a point inside the spinodal curve, the system is unstable against small fluctuations, leading to phase separation by unstable growth.

In the late stages of growth, both mechanisms give rise to qualitatively similar coarsening patterns. The two main types of coarsening pattern are 'bicontinuous', where both phases percolate, and 'droplet', where the minority phase forms isolated droplets in a background of the majority phase. (Note, however, that the dividing line between two types of structures does not necessarily correspond to the spinodal line). An example of a coarsening bicontinuous structure is shown in figure 1. The figure shows domain patterns at different times for a simulation of two-dimensional spinodal decomposition, using model-B dynamics, appropriate to a system with conserved order parameter but no hydrodynamics (see § 3 for a precise definition).

The domain patterns grow with a time-dependent characteristic length-scale

$$L(t) \sim t^n$$

with a growth exponent n, where n depends on the particular dynamics. In model-A dynamics, the order parameter is not conserved, while model H describes a system with a conserved order parameter coupled to hydrodynamic flow. Anticipating the arguments of § 3, we give the results here:

$$n = \begin{cases} \frac{1}{2} & \text{model A,} \\ \frac{1}{3} & \text{model B,} \\ 1 & \text{model H.} \end{cases}$$

Physical systems described by these models will be discussed below. But first we give explicit definitions of the dynamical models used.

### **3. Dynamical models A, B and H**

The models are expressed in terms of the Ginzburg–Landau free-energy functional, which gives the coarse-grained free-energy density as a functional of the order parameter φ(*x*, t). A standard form suitable for describing the two-phase region is

$$F[\phi] = \int d^d x [(\nabla \phi)^2 + (1 - \phi^2)^2].$$

The term (1 <sup>−</sup> <sup>φ</sup><sup>2</sup>)<sup>2</sup> represents the fact that two values of <sup>φ</sup>, <sup>φ</sup> <sup>=</sup> <sup>±</sup>1, corresponding to the two different phases, minimize the bulk free energy, while the gradient term associates a free-energy cost with having interfaces (domain walls) in the system. It is precisely the excess free energy residing in the domain walls that is the driving force for the coarsening.

The three dynamical models to be discussed take the names A, B and H, after the classification of Hohenberg & Halperin (1977). They are defined by the equations of motion

$$\frac{\partial \phi}{\partial t} = \begin{cases}
-\Gamma \frac{\delta F}{\delta \phi} & \text{model A,} \\
-\nabla \cdot \mathbf{J}_{\phi} & \text{model B,} \\
-\nabla \cdot (\mathbf{J}_{\phi} + \mathbf{v}\phi) & \text{model H,}
\end{cases}$$
(3.1)

where

$$\boldsymbol{J}_{\phi} = -\lambda \nabla \frac{\delta F}{\delta \phi} = \lambda \nabla \mu$$

and µ is the chemical potential. In equation (3.1), J<sup>φ</sup> is a 'diffusion current' and *v*φ is an 'advection current'. The fluid velocity *v* satisfies the Navier–Stokes equation

$$\rho \left( \frac{\partial \mathbf{v}}{\partial t} + (\mathbf{v} \cdot \nabla) \mathbf{v} \right) = \eta \nabla^2 \mathbf{v} - \nabla p, \tag{3.2}$$

where ρ and η are the fluid's density and viscosity respectively, and p is the pressure. Model A describes systems with no conservation laws, such as Ising models with Glauber dynamics, and twisted nematic liquid crystals (Mason et al. 1993). Model B describes binary alloys, binary liquids and polymer blends in the regime where transport of the order parameter is primarily by the Lifshitz–Slyozov mechanism evaporation from regions of high interfacial curvature and condensation on to regions of low curvature—before hydrodynamic effects become important (see Bray 1994, and references therein). Model H describes binary liquids and polymeric systems when hydrodynamics can no longer be ignored, but the 'inertial terms' on the left of the Navier–Stokes equation (3.2) are not yet important. Finally, there is a further regime, first investigated by Furukawa (1985), where the inertial terms come into play.

In order to discuss the value of the growth exponent, n, in each case, it is helpful to first introduce the concept of dynamical scaling.

#### 4. Dynamical scaling and domain growth

Experiments, computer simulations and some soluble models show that the pair-correlation function,  $C(\mathbf{r},t) = \langle \phi(\mathbf{x}+\mathbf{r},t)\phi(\mathbf{x},t)\rangle$ , has the scaling form

$$C(\boldsymbol{r},t) = f\bigg(\frac{r}{L(t)}\bigg),$$

where  $L(t) \sim t^n$  is the characteristic length-scale at time t.

Its Fourier transform, the structure factor  $S(\mathbf{k},t)$ , can be measured in scattering experiments. Its scaling form is

$$S(\mathbf{k}, t) = [L(t)]^d g[kL(t)].$$

Using the dynamical-scaling idea together with simple physical arguments it is possible to determine the form of L(t) for each of the models discussed.

## (a) The growth exponent 'n'

#### (i) Model A

There is a force per unit area,  $\sigma K$ , acting on a domain wall due to the surface tension,  $\sigma$ , where K is the total curvature at a given point on the interface. In the absence of any conservation laws, the interface is free to move and its velocity,  $v_{\rm int}$ , will be proportional to the 'pressure',  $\sigma K$ . Dynamical scaling implies that the characteristic velocity is  ${\rm d}L/{\rm d}t$  and the characteristic curvature is 1/L. This gives  ${\rm d}L/{\rm d}t \propto 1/L$  and hence  $L \propto t^{1/2}$  (i.e.  $n=\frac{1}{2}$ ).

### (ii) Model B

In this case the order parameter is conserved and interfaces can only move through transport of material through the intervening bulk phases. The interface velocity is related to the imbalance in the transport of material into and out of the interface,

$$v_{\rm int} \propto J_{\phi}^{(\rm in)} - J_{\phi}^{(\rm out)} \propto [\partial_{\rm n} \mu]_{\rm out}^{\rm in}.$$

The Gibbs–Thompson boundary condition relates the chemical potential on the interface to its curvature,  $\mu_{\rm int} \propto K$ , while dynamical scaling gives  $K \propto 1/L$  and therefore  $|\nabla \mu| \sim 1/L^2$ . Finally,

$$v_{\rm int} \sim \frac{1}{L^2} \implies \frac{\mathrm{d}L}{\mathrm{d}t} \sim \frac{1}{L^2} \implies L(t) \sim t^{1/3},$$

giving  $n = \frac{1}{3}$ .

(iii) Model H

In binary-liquid phase separation there are three regimes.

Early times: diffusive regime. When the interface velocity,  $v_{\rm int}$ , is large compared with the fluid velocity,  $\boldsymbol{v}$ , hydrodynamics is unimportant and  $L(t) \sim t^{1/3}$  as in model B.

Intermediate times: viscous hydrodynamic regime. As the system coarsens,  $v_{\rm int}$  decreases (as  $t^{-2/3}$ ) until eventually  $v_{\rm int} \sim v$ . Ignoring the 'inertial' terms on the left-hand side of the Navier–Stokes equation (3.2), and using the fact that pressure variations in a system containing interfaces of curvature of order 1/L are of order  $\sigma/L$ , gives

$$\eta \nabla^2 v = \nabla p \sim \frac{\sigma}{L^2} \quad \Longrightarrow \quad v \sim \frac{\sigma}{\eta} \quad \Longrightarrow \quad L(t) \sim \left(\frac{\sigma}{\eta}\right) t,$$

a result first obtained by Siggia (1979).†

Late times: inertial hydrodynamic regime. If the Reynolds number is much larger than unity, the inertial terms in (3.2) eventually become important. Balancing these terms against the driving terms  $\nabla p$ , and ignoring the dissipative term  $\eta \nabla^2 \mathbf{v}$ , gives (Furukawa 1985)

$$L(t) \sim \left(\frac{\sigma}{\rho}\right)^{1/3} t^{2/3}.\tag{4.1}$$

## (b) Discussion

One can estimate where the crossover between the viscous and inertial regimes occurs by equating the length-scales L(t) calculated in both regimes. This gives a crossover time-scale  $t_0 \sim \eta^3/\sigma^2\rho$  and corresponding length-scale  $L_0 \sim \eta^2/\sigma\rho$ . In fact, as Pagonabarraga et al. (2002) have noted, these are the characteristic timeand length-scales of the fluid, respectively, while the characteristic velocity scale is  $v_0 = \sigma/\eta$ . Inserting these scales into the expression for the Reynolds number,  $Re = \rho L_0 v_0 / \eta$ , gives Re = O(1) at the crossover between viscous and hydrodynamic regimes. Furthermore, according to the Furukawa prediction (4.1), Re increases without bound, as  $Re \sim (t/t_0)^{1/3}$ , in the inertial regime. This raises the question (Grant & Elder 1999) as to whether turbulent remixing of the fluid phases could arrest the coarsening at some scale, suggesting an internal inconsistency in the theory. We will return to this question below. First, though, we discuss the numerical simulation results of Pagonabarraga et al. (2002). Figure 2 shows the time dependence of the coarsening length L(t) for a phase separating binary fluid. The scale L(t) is normalized by the characteristic length-scale  $L_0$  of the fluid and the time t by the characteristic time-scale  $t_0$  (written as  $T_0$  on the plot).

Figure 2 demonstrates that the data for different system parameters collapse onto a single curve if lengths and times are expressed in units of  $L_0$  and  $t_0$ , respectively.

 $<sup>\</sup>dagger$  One should note, however, that this result is restricted to bicontinuous structures: for isolated droplets,  $t^{1/3}$  is recovered, with coarsening through droplet coalescence driven by Brownian motion in addition to the usual evaporation–condensation mechanism (see Bray 1994, and references therein).

![](_page_5_Figure_3.jpeg)

Figure 2. Growth of the coarsening length L(t) for binary fluids. Different symbols correspond to different system parameters.  $L_0$  and  $T_0$  are the characteristic length- and time-scales discussed in the text. (Reproduced with permission from Pagonabarraga *et al.* (2002).)

The system-dependent time offset  $T_{\rm int}$  improves the quality of the collapse at early times. The lines of slope 1 and  $\frac{2}{3}$  demonstrate the predicted crossover from viscous to inertial regimes as time increases. Note that the crossover value of  $L/L_0$  is a few hundred rather than close to unity. This is not at variance with the scaling arguments, which predict that the crossover should occur when L is 'of order  $L_0$ ', but does not give the constant. The corresponding value of Re is correspondingly larger than one, but there is no evidence in the data for the onset of turbulence.

The general question of the nature of coarsening in the inertial regime has been addressed in a number of recent papers which I will summarize briefly.

- (i) Grant & Elder (1999) have observed that since, in a naive scaling analysis, the Reynolds number is estimated as  $Re \sim \rho L(\mathrm{d}L/\mathrm{d}t)/\eta$ , a final growth law  $L(t) \sim t^n$  gives  $Re \sim t^{2n-1}$ , i.e. Re grows without bound for any n > 1/2. This seems to imply that n cannot be greater than one-half in the inertial regime, otherwise turbulent remixing of the fluids would stop the phase separation, leading to a contradiction.
- (ii) Kendon (2000) has criticized the simple assumption that, for large Reynolds numbers, the system can still be described by a single length-scale, L(t), and corresponding velocity scale,  $v \sim \mathrm{d}L/\mathrm{d}t$ . She argues that neglecting the dissipative terms in the Navier–Stokes equation violates energy conservation and that a consistent scaling analysis should include the Taylor microscale and the Kolmogorov dissipation scale as well as the domain scale. Including these addi-

![](_page_6_Picture_3.jpeg)

Figure 3. Snapshots of size  $L_y = 512$  and  $L_x = 2048$  (parts of a  $512 \times 4096$  system) for a shear rate  $\gamma = 0.01$  and strains S(t) = 1, 5, 10 and 50 (from top left to bottom right). (Reproduced with permission from Berthier (2001).)

tional length-scales, she recovers  $L(t) \sim t^{2/3}$  in the inertial regime, but finds that Re saturates, thus avoiding the Grant-Elder conundrum.

(iii) Solis & de la Cruz (2000a) also criticize the Furukawa analysis, again pointing to the neglect of the dissipative terms. They determine the growth-law for L(t)by studying the dynamics of a single relaxing interface, a technique which works well in other situations (see Bray 1998, and references therein). The method is to consider an interface modulated on the length-scale  $L=2\pi/k$  and to calculate the relaxation rate  $\lambda_k$ . If  $\lambda_k \sim k^z$  for small k, one infers that structures of scale  $L \sim 1/k$  relax on a time-scale  $\tau_L \sim 1/\lambda_k \sim L^z$ , i.e. the growth exponent is n=1/z. This approach leads to results in accordance with predictions obtained from other methods in nearly all cases with purely dissipative dynamics (see Bray 1998, and references therein). For the present problem, Solis & de la Cruz include both inertial and dissipative terms in the Navier-Stokes equation and obtain a relation of the form  $\lambda_k = -iak^{3/2} + bk^{7/4}$ . The first term, which corresponds to Furukawa's  $t^{2/3}$  growth law, naively dominates at small k but is imaginary and therefore is associated with interfacial oscillations rather than relaxation. The latter is described by the  $k^{7/4}$  term in  $\lambda_k$ , corresponding to a growth law  $L(t) \sim t^{4/7}$ . Furukawa, however, claims that the nonlinear terms in the Navier-Stokes equation invalidate this simple analysis as far as the coarsening behaviour is concerned (Furukawa 2000; Solis & de la Cruz 2000b).

The asymptotic coarsening dynamics in the inertial regime is, in the author's view, still an open question.

#### 5. Coarsening in an imposed shear flow

In the final part of the paper I describe a second system where the asymptotics are still not understood, namely coarsening under shear. As a simplification of what is a difficult problem, I will take the velocity field in the fluid to be determined solely be the externally imposed shear (with shear rate S),

$$v = Sye_x$$

where x is the flow direction and y is the shear direction. This approach neglects feedback on the fluid flow due to motion of the interfaces. It should be a good

approximation only in the diffusive regime. The equation of motion then becomes a modified model B:

 $\frac{\partial \phi}{\partial t} + Sy \frac{\partial \phi}{\partial x} = \lambda \nabla^2 \frac{\delta F}{\delta \phi}.$ 

The form of this equation suggests the anisotropic scaling,

$$C(\boldsymbol{r},t) = f\bigg(\frac{x}{L_x}, \frac{y}{L_y}, \frac{z}{L_z}\bigg),$$

and power counting on the equation of motion gives

$$L_x \sim StL_y,$$
 (5.1)

i.e. the system coarsens more rapidly in the flow direction.

Experiments (or simulations) at low shear rates confirm the expected anisotropy and are broadly consistent with  $L_{\parallel} \propto t L_{\perp}$  (Chan et al. 1991; Läuger et al. 1995; Padilla & Toxvaerd 1997). An example of a recent simulation is shown in figure 3. The development of anisotropic domain structure is clearly visible.

Open questions include the following. In higher shear rates (or after long times) a steady state is often reported (Hashimoto et al. 1995; Wagner & Yeomans 1999), but is this a finite size effect? Coarsening would saturate if  $L_{\parallel}$  were to become comparable with the system size in the flow direction. On the other hand, it is known that an isolated drop in a shear flow has a maximum length,  $L_{\text{max}} \sim \sigma/\eta S$ , above which it will break up into smaller drops. Does this length set the maximum length-scale for coarsening (in the hydrodynamic regime) (Ohta et al. 1990, 1991)?

I will describe two theoretical approaches to the problem. The first is an exact solution of a soluble, though physically unrealistic, model. The second is an approximate treatment of a more realistic model.

### (a) The large-N model

We generalize the model to a vector order parameter with N components,  $\phi = (\phi_1, \phi_2, \dots, \phi_N)$ , and take the limit  $N \to \infty$ . Without hydrodynamics (i.e. model B+shear), this model can be solved exactly (Rapapa & Bray 1999). One finds, at late times,

$$L_{\parallel} \sim S \left( \frac{t^5}{\ln t} \right)^{1/4}, \qquad L_{\perp} \sim \left( \frac{t}{\ln t} \right)^{1/4},$$

confirming that  $L_{\parallel} \sim StL_{\perp}$ . The logarithmic factors are a feature of this limit, which is also associated with a lack of perfect scaling. A slightly modified form of the model (Bray & Humayun 1992) restores scaling and eliminates the logarithmic terms (Lamura *et al.* 2002). The main point, however, is that coarsening continues indefinitely in both the original and modified models.

### (b) Model A with shear

We consider a *non-conserved* order parameter advected by a uniform shear flow. The equation of motion is

$$\frac{\partial \phi}{\partial t} + Sy \frac{\partial \phi}{\partial x} = -\Gamma \frac{\delta F}{\delta \phi}.$$

The model can be solved using an approximate scheme originally due to Ohta *et al.* (1982) (hereafter referred to as 'OJK') that is known to work well in the absence of shear. The result has a different form in space dimensions d = 2 and d = 3 (Bray & Cavagna 2000; Bray *et al.* 2000):

$$L_{\parallel} \sim S^{1/2} t(\ln t)^{1/4}, \quad L_{\perp} \sim S^{-1/2} (\ln t)^{-1/4}, \quad d = 2,$$
 (5.2)

$$L_{\parallel} \sim S t^{3/2}, \qquad L_{\perp} \sim t^{1/2}, \qquad d = 3.$$
 (5.3)

The distinction between the behaviour in two and three dimensions has its origin in an interesting piece of physics that is evidently respected by the OJK approximation employed. If one considers an isolated domain in two dimensions, then in the absence of shear the normal velocity of the domain wall is proportional to the local curvature, K. The rate of change of the domain area is therefore proportional to  $\oint dl K(l)$ , where the integral is around the perimeter of the domain. But this integral is a topological invariant equal to  $2\pi$ , so the area of every isolated domain decreases at the same constant rate, independent of its size and shape. The inclusion of a shear flow does not change this result. The shear flow advects the domain wall at a rate proportional to the local flow velocity, so there is an extra contribution to the rate of change of area obtained by integrating the normal component of this velocity around the perimeter of the domain. It is easy to show, however, that this contribution is precisely zero for any divergence-free velocity field (Bray & Cavagna 2000; Bray et al. 2000), which includes the case of a uniform shear flow considered here. The conclusion is that, in two dimensions, the areas of all *isolated* domains decrease at the same constant rate, independently of the shear rate. It is then tempting to conjecture that the scale area of the system,  $L_{\parallel}(t)L_{\perp}(t)$ , should increase at a constant rate, independent of the shear rate S, in two dimensions. Equation (5.2) shows that, at least within the OJK approximation employed, this conjecture is correct (indeed, even the proportionality constant is the same as in the zero-shear case (Bray & Cavagna 2000; Bray et al. 2000)).

A further refinement in d=2 is that the length-scales  $L_{\parallel}$  and  $L_{\perp}$  are defined, not with respect to the x- and y-axes, but with respect to scaling axes tilted at an angle of order 1/St to the x- and y-axes (Bray & Cavagna 2000; Bray et al. 2000). These scaling axes are essentially along and perpendicular to the mean domain orientation. The alert reader may have noticed that the relation  $L_{\parallel} \sim StL_{\perp}$  is not strictly obeyed by equation (5.2). In fact the scaling prediction (5.1) is  $L_x \sim StL_y$ . If length-scales  $L_x$  and  $L_y$  are extracted from the correlation function with spatial displacements purely in the x- and y-directions, respectively, one indeed finds  $L_x \sim StL_y$  (Bray & Cavagna 2000; Bray et al. 2000) ( $L_x$ ,  $L_y$  differ from  $L_{\parallel}$ ,  $L_{\perp}$  by powers of  $\ln t$ ), but proper dynamical scaling is only obtained when the correct scaling axes  $L_{\parallel}$ ,  $L_{\perp}$  are employed.

Finally, for  $t \to \infty$  equation (5.2) predicts  $L_{\perp} \to 0$ . Clearly, the whole calculation, based on the coarse-grained Ginzburg–Landau description, breaks down when  $L_{\perp}$  becomes comparable with the width,  $\xi$ , of a domain wall. One possibility is that the phases eventually remix. Another is that the coarsening is arrested when  $L_{\perp}$  becomes comparable with  $\xi$ .

In d=3, the situation is much simpler. Both lengths grow without bound, the relation  $L_{\parallel} \sim StL_{\perp}$  is satisfied and conventional scaling is obtained independently of whether  $L_{\parallel}$ ,  $L_{\perp}$  or  $L_x$ ,  $L_y$  are used as scaling lengths. In this system coarsening continues indefinitely.

Unfortunately, there is no generalization of the OJK method to model B, so our understanding of this system is based mainly on simulations. A recent study in two dimensions (Berthier 2001), however, found similar behaviour to the non-conserved case, with L<sup>⊥</sup> only weakly dependent on time and L growing linearly, or perhaps somewhat faster. Again, it was found that good scaling was obtained only with the correct choice of scaling axes.

## **6. Conclusion**

The coarsening dynamics of phase-separating (or phase-ordering) systems is reasonably well understood in the regimes described by models A (non-conserved order parameter), B (conserved order parameter) and H (conserved order parameter plus hydrodynamics). The coarsening is well described by a scaling phenomenology with a single characteristic length-scale, L(t) ∼ t <sup>n</sup>, with n<sup>A</sup> = 1/2, n<sup>B</sup> = 1/3 and n<sup>H</sup> = 1 in the viscous regime.

Despite the fact that coarsening dynamics is a relatively mature field, there are still many open questions. Two that I focused on in the latter part of this paper were the following.

- (i) What is the nature of the domain coarsening in the inertial hydrodynamic regime?
- (ii) What is the asymptotic fate of a system phase-separating under shear flow? Does it coarsen indefinitely, or does the shear drive the system into a nonequilibrium steady state?

#### **References**

Berthier, L. 2001 Phys. Rev. E**63**, 051503.

Bray, A. J. 1994 Adv. Phys. **43**, 357.

Bray, A. J. 1998 Phys. Rev. E**58**, 1508.

Bray, A. J. & Cavagna, A. 2000 J. Phys. A **33**, L305.

Bray, A. J. & Humayun, K. 1992 Phys. Rev. Lett. **68**, 1559.

Bray, A. J., Cavagna, A. & Travasso, R. D. M. 2000 Phys. Rev. E**62**, 4702.

Chan, C. K., Perrot, F. & Beysens, D. 1991 Phys. Rev. A **43**, 1826.

Furukawa, H. 1985 Phys. Rev. A **31**, 1103.

Furukawa, H. 2000 Phys. Rev. Lett. **85**, 4407.

Gerard, H., Cabral, J. T. & Higgins, J. S. 2003 Phil. Trans. R. Soc. Lond. A **361**, 767–779.

Grant, M. & Elder, K. R. 1999 Phys. Rev. Lett. **82**, 14.

Hashimoto, T., Matsuzaka, K., Moses, E. & Onuki, A. 1995 Phys. Rev. Lett. **74**, 126.

Hohenberg, P. C. & Halperin, B. I. 1977 Rev. Mod. Phys. **49**, 435.

Kendon, V. M. 2000 Phys. Rev. E**61**, R6071.

Lamura, A., Gonella, G. & Corberi, F. 2002 Eur. Phys. J. B **24**, 251.

L¨auger, J., Laubner, C. & Gronski, W. 1995 Phys. Rev. Lett. **75**, 3576.

Mason, N., Pargellis, A. N. & Yurke, B. 1993 Phys. Rev. Lett. **70**, 190.

Ohta, T., Jasnow, D. & Kawasaki, K. 1982 Phys. Rev. Lett. **49**, 1223.

Ohta, T., Nozaki, H. & Doi, M. 1990 Phys. Lett. A **145**, 304.

Ohta, T., Nozaki, H. & Doi, M. 1991 J. Chem. Phys. **93**, 2664.

Padilla, P. & Toxvaerd, S. 1997 J. Chem. Phys. **106**, 2342.

Pagonabarraga, I., Wagner, A. J. & Cates, M. E. 2002 J. Stat. Phys. 107, 39.
 Rapapa, N. P. & Bray, A. J. 1999 Phys. Rev. Lett. 83, 3856.

Siggia, E. D. 1979 Phys. Rev. A 20, 595.

Solis, F. J. & de la Cruz, M. O. 2000a Phys. Rev. Lett. 84, 3350.

Solis, F. J. & de la Cruz, M. O. 2000b Phys. Rev. Lett. 85, 4408.

Wagner, A. J. & Yeomans, J. M. 1999 Phys. Rev. E 59, 4366.

#### Discussion

- T. J. Sluckin (School of Mathematics, University of Southampton, UK). What about the shape of the domains? Is there anything interesting in C(r,t) which tells us about this?
- A. J. Bray. The pair-correlation function,  $C(\mathbf{r},t)$ , by itself does not contain complete information about the domain morphology. Its gross features describe rather basic properties of the system, e.g. the linear behaviour at short distance,  $C(\mathbf{r},t)=1-\text{const.}|\mathbf{r}|/L(t)+\cdots$ , merely reflects the presence of sharp interfaces (see Bray 1994, and references therein). The different morphology observed in models A and B is, however, partly reflected in the form of  $C(\mathbf{r},t)$ . For model A,  $C(\mathbf{r},t)$  is monotonically decreasing, with no interesting features, while for model B it has a damped oscillatory form, corresponding to a single maximum at  $k \sim 1/L(t)$  (with width  $\Delta k \sim 1/L(t)$ ) in the structure factor. This form is related to the characteristic 'labyrinthine structure' observed in real space (see figure 1), with a rather well-defined domain width; the morphology observed in model A is quite different.
- T. C. B. McLeish (Department of Physics and Astronomy, University of Leeds, UK). Can you explain why the effective surface tension does not limit the growth (shear convected) in the flow direction?
- A. J. Bray. There is a competition between the shear, which is trying to stretch the domains, and the surface tension, which is trying to make them more spherical. Isolated domains will shrink under surface tension (directly in model A, indirectly—via the evaporation–condensation mechanism—in model B), leaving behind larger domains. In unsheared systems this is basically the way these systems coarsen. I think your question concerns whether domains can break under shear. This can certainly happen for isolated drops in the viscous hydrodynamic regime: the Taylor instability leads to a break-up on a scale  $L_{\rm max} \sim \sigma/\eta S$ . This presumably leads to saturation in the 'off-critical' case, where the domain morphology consists of isolated drops of the minority phase in a background of the majority phase. In the case of bicontinuous structures I believe the question is still open.
- R. Blumenfeld (Cavendish Laboratory, University of Cambridge, Cambridge, UK). I wonder whether the coarse-graining in the flow direction and the shear direction can be separated by carrying out an experiment in a cylindrical geometry wherein stripes would form rather quickly in the azimuthal direction but they will coarsen slowly in the radial direction. Has this been carried out and if so with what results?
- A. J. Bray. I do not know of any experiment of this type.
- E. J. HINCH (DAMTP-CMS, University of Cambridge, UK). Large-scale motions in turbulence are independent of the kinematic viscosity, which would imply growth

as in the inertial regime (σt<sup>2</sup>/ρ)<sup>2</sup>/<sup>3</sup>. But some large-scale motions, such as growing spherical drops, are not unstable and might not be turbulent.

- R. Magerle (Physikalische Chemie II, Universit¨at Bayreuth, Germany). It is well known that turbulence involves multiple length-scales, therefore I think that it is not appropriate to search for one particular length-scale. One way to resolve this issue might be to use high-resolution, real-space-image techniques and advanced mathematical methods, such as Minkowski functionals, to characterize the complex spatial structures.
- A. J. Bray. It is clear that more than one length-scale is important for the fluid motion, but the question is whether more than one length-scale is necessary to describe the domain morphology. I think this is an interesting question. If there is more than one length present in the domain structure, it may still be possible to provide a scaling description based on the largest length-scale.
- R. C. Ball (Department of Physics, University of Warwick, Coventry, UK). What happens (and what is n) for a non-conserved order parameter, hydrodynamically coupled? And for the hydrodynamic regime when one phase is solid? I think this is sensitive to which is the majority phase.
- A. J. Bray. In the early stages, curvature-driven growth will dominate and the usual t <sup>1</sup>/<sup>2</sup> growth law of standard model A should hold. When the interface velocity becomes of the same order as the characteristic fluid velocity, σ/η, hydrodynamics will take over as the dominant coarsening mechanism, with the usual (Siggia) law, L(t) ∼ σt/η, in the viscous hydrodynamic regime and, in the inertial regime, the same (not yet fully understood) behaviour as for conventional binary fluids.

I assume that the second question refers to conventional conserved dynamics. If the viscosities of the fluids are very different (the case where one phase is solid is an extreme limit), then the onset of the hydrodynamic regime will be different for the two phases. Since the low-viscosity phase enters the hydrodynamic regime first, one can have a situation where the low-viscosity phase is in its hydrodynamic regime, but the high-viscosity phase is not. If the high-viscosity phase is the majority phase, then (in the droplet morphology) the low-viscosity minority phase will coarsen predominantly by the evaporation–condensation mechanism, analogous to Ostwald ripening of a binary alloy, with L(t) ∼ t <sup>1</sup>/<sup>3</sup>. If the low-viscosity phase is the majority phase, then the high-viscosity droplets can move under Brownian motion through the low-viscosity background and coalesce, as well as coarsening by the evaporation– condensation mechanism. Both mechanisms, however, give rise to t <sup>1</sup>/<sup>3</sup> growth (Siggia 1979).