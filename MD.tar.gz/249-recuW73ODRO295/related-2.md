![](_page_0_Picture_0.jpeg)

![](_page_0_Picture_1.jpeg)

## Journal of Advances in Modeling Earth Systems

### REGULAR ARTICLE

10.1002/2013MS000270

#### Key Points:

- Radiative-convective equilibrium becomes unstable at high temperature

#### Correspondence to:

K. Emanuel, emanuel@mit.edu

#### Citation:

Emanuel, K., A. A. Wing, and E. M. Vincent (2014), Radiative-convective instability, J. Adv. Model. Earth Syst., 6, 75–90, doi:10.1002/2013MS000270.

Received 16 SEP 2013 Accepted 19 NOV 2013 Accepted article online 22 NOV 2013 Published online 5 FEB 2014 Corrected 16 AUG 2016

This article was corrected on 16 AUG 2016. See the end of the full text for details.

## Radiative-convective instability

Kerry Emanuel1, Allison A. Wing1, and Emmanuel M. Vincent1

1 Program in Atmospheres, Oceans, and Climate, Department of Earth, Atmospheric, and Planetary Sciences, Massachusetts Institute of Technology, Cambridge, Massachusetts, USA.

Abstract Radiative-moist-convective equilibrium (RCE) is a simple paradigm for the statistical equilibrium the earth's climate would exhibit in the absence of lateral energy transport. It has generally been assumed that for a given solar forcing and long-lived greenhouse gas concentration, such a state would be unique, but recent work suggests that more than one stable equilibrium may be possible. Here we show that above a critical specified sea surface temperature, the ordinary RCE state becomes linearly unstable to large-scale overturning circulations. The instability migrates the RCE state toward one of the two stable equilibria first found by Raymond and Zeng (2000). It occurs when the clear-sky infrared opacity of the lower troposphere becomes so large, owing to high water vapor concentration, that variations of the radiative cooling of the lower troposphere are governed principally by variations in upper tropospheric water vapor. We show that the instability represents a subcritical bifurcation of the ordinary RCE state, leading to either a dry state with large-scale descent, or to a moist state with mean ascent; these states may be accessed by finite amplitude perturbations to ordinary RCE in the subcritical state, or spontaneously in the supercritical state. As first suggested by Raymond (2000) and Sobel et al. (2007), the latter corresponds to the phenomenon of selfaggregation of moist convection, taking the form of cloud clusters or tropical cyclones. We argue that the nonrobustness of self-aggregation in cloud system resolving models may be an artifact of running such models close to the critical temperature for instability.

### 1. Introduction

Radiative-convective equilibrium (RCE) is the statistical equilibrium state the atmosphere and surface would reach in the absence of lateral energy transport. Although it is arguably the simplest model of climate systems, and has been widely applied as first approximations to the climates of Earth and other planets, its physics are still not entirely understood in the case in which water (or, in other planetary atmospheres, other substances) changes phase. Among the most interesting of these issues are whether the statistical equilibrium state is stable and whether it possesses multiple stable equilibria.

It is well known that RCE in atmospheres in which the relative humidity is fixed and for which a gray approximation for absorption and emission of radiation is valid have unique stable equilibria for a given value of solar forcing, unless that forcing is large enough to cause a runaway greenhouse [Goody and Yung, 1995]. But if either of these conditions is relaxed, multiple stable equilibria may occur for some range of insolation [Pujol and North, 2002; Renno-, 1997]. This generally occurs at surface temperatures somewhat higher than observed in the tropics.

Of perhaps more general interest is the stability of RCE states when large-scale circulations are allowed to develop spontaneously, with homogenous boundary conditions. Held et al. [1993] performed experiments with a two-dimensional model with explicit convection, and showed that if the boundary conditions prevent strong shear flows from developing, the deep moist convection became localized in the domain, with dry, descending air elsewhere. Later, Tompkins [2001] and Bretherton and Khairoutdinov [2004] showed that essentially the same phenomenon can occur in three-dimensional cloud-permitting models, and this ''selfaggregation'' of convection has since been demonstrated and examined by several others [e.g., Bretherton et al., 2005; Held and Zhao, 2008; Jeevanjee and Romps, 2013; Khairoutdinov and Emanuel, 2010; Muller and Held, 2012; Nolan et al., 2007]. Nilsson and Emanuel [1999] developed a semiquantitative conceptual twocolumn model and argued on that basis that RCE would be destabilized to a single overturning cell, with ascent in one column and descent in the other, if the positive radiative feedbacks involving clouds and water vapor were sufficient to overcome the gross moist stability of the RCE state. They showed that this

indeed happens in a two-column model with advanced representations of radiation and convection, depending on how much frictional dissipation occurs, but in that case they also calculated the surface temperature, which declined as the circulation developed, more so in the descending column. Raymond and Zeng [2000] demonstrated that a similar two-column model can spontaneously develop a circulation even with constant, uniform surface temperature, and proposed that such an instability of the RCE state may lead to clustering of deep convection. Raymond [2000] was able to demonstrate RCE instability using a simple model as well. In general, single-column models and cloud-permitting models run in weak-temperature gradient (WTG) mode exhibit multiple stable equilibria [e.g., Sessions et al., 2010; Sobel et al., 2007].

There is evidence that the instability of the RCE state leading to self-aggregation is temperature dependent. Nolan et al. [2007] showed that the time it takes for an initial finite amplitude vortex to develop into a tropical cyclone in a cloud-permitting model depends strongly on potential intensity, which increases with surface temperature. Khairoutdinov and Emanuel [2010] showed that nonrotating self-aggregation in another cloud-permitting model only occurs above a threshold specified sea surface temperature, and argued that because aggregation is accompanied by a profound drying of the free troposphere, it could effectively regulate tropical temperatures by greatly increasing outgoing longwave radiation. Tobin et al. [2012] developed an aggregation index that can be applied to satellite images and showed that aggregation in nature is indeed accompanied by drying, but the increase in outgoing longwave radiation was partially offset by an decrease in reflected solar radiation. Wing and Emanuel [2013] also found a strong temperature dependence of self-aggregation, and presented evidence that, at higher temperatures, larger domains are required for self-aggregation to occur. The critical temperature for aggregation to occur in the simulations performed by Khairoutdinov and Emanuel [2010] and Wing and Emanuel [2013] is close to peak observed surface temperatures in the tropics. Near the critical temperature, the timing and other aspects of self-aggregation are quite sensitive to initial conditions. The propensity to run cloud-resolving models with realistic tropical sea surface temperatures, which by coincidence or not are close to the critical temperature for self-aggregation, may explain why the phenomenon seems exquisitely sensitive to numerical and physical model parameters [Muller and Held, 2012].

An analysis of the budget of the variance of column-integrated frozen moist static energy in selfaggregating simulations by Wing and Emanuel [2013] strongly suggests that the physics underlying the initial instability of the RCE state differ from those that maintain cloud clusters once they develop. In particular, the onset of instability manifests itself as a dry patch, mostly devoid of deep convection, that amplifies and expands to cover most of the domain, isolating deep convection into a single cluster. The variance of column-integrated frozen moist static energy is increased mostly by clear-sky radiative feedbacks as the initial dry patch develops, though, as found in much previous work, the longwave cloud radiative feedback dominates once the cloud cluster develops. There is little evidence that feedbacks between convection and moisture play an important role in self-aggregation in this model, as had been speculated in earlier work [e.g., Craig and Mack, 2013].

In this paper, we focus on the initial instability of the RCE state, taking the cue from Wing and Emanuel [2013] that the physics involves mostly clear-sky radiative feedbacks. In particular, we will show that although the clear-sky shortwave radiative feedback is nearly always positive, the temperature dependence of RCE instability arises from the water vapor dependence of longwave radiative absorption and emission. The following section develops a simple theory for RCE instability, which is further simplified in a two-layer framework in section 3. The ideas developed in these two sections are tested in a full-physics single-column model in section 4. The model is first run into an RCE state, whose stability is explored by reinitializing it in WTG mode. A summary is presented in section 5.

### 2. Theory

Consider an atmosphere in radiative-convective equilibrium over an infinite, nonrotating ocean with uniform surface temperature. We define this equilibrium as one in which the state, averaged over time intervals long compared to the typical lifetime of convective clouds, is horizontally uniform, with well-defined vertical profiles of temperature and humidity. In principle, such states can be represented by onedimensional models that have an adequate representation of turbulent processes such as moist convection. There is a long history of simulating such states with one-dimensional models [e.g., Manabe and Strickler,

1964], and more recently with three-dimensional cloud system resolving models, as reviewed in the Introduction.

Now consider perturbations to this state with horizontal scales much larger than typical intercloud spacings of the RCE state, but not so large that the WTG approximation breaks down. (In a rotating system, this breakdown occurs on scales comparable to the deformation radius, and in nonrotating systems on scales large enough that frictional damping of perturbations becomes appreciable.) An important approximation we make here is that statistical equilibrium applies to the perturbations as well as to the mean state, in the sense that we can average over the moist convective turbulence.

Above the boundary layer, since WTG applies, there will be no variation of temperature associated with such perturbations, but moisture perturbations can potentially arise in association with perturbations to the vertical velocity and moist convection. Presumably, perturbations to stratiform clouds will occur as well, but for simplicity we do not consider them here. Such moisture perturbations will change the profile of radiative cooling, and a perturbation vertical velocity must then arise to enforce WTG. Changing vertical velocity will then feedback on the moisture content, both directly and through its influence on convection, which will also be influenced directly by the moisture perturbation.

The central question considered here is whether the feedback to an initial moisture perturbation is positive, zero, or negative corresponding to instability, neutrality, or stability. We assume that radiation, convection, and vertical velocity respond instantaneously to the moisture perturbation, so the time dependence enters this problem strictly through the moisture budget. The latter is most easily developed through the Reynolds averaged budget of moist static energy in the column above the boundary layer, where WTG applies:

$$\frac{\partial h}{\partial t} = L_{v} \frac{\partial q}{\partial t} = -\mathbf{V} \cdot \nabla h - \frac{\partial F_{c}}{\partial z} + \dot{Q}, \tag{1}$$

where h is the moist static energy, q is the specific humidity,  $L_v$  is the latent heat of vaporization,  $\mathbf{V}$  the three-dimensional velocity vector,  $F_c$  the convective flux of moist static energy (assumed to be strictly vertical), and  $\dot{Q}$  the radiative heating per unit mass. We have ignored all turbulent fluxes except those associated with convection. The equivalence on the left side of (1) is owing to the constancy of the system temperature, according to WTG. According to (1), the moist static energy is changed by advection, convergence of the turbulent convective moist static energy flux, and by radiative heating. We next linearize (1) around the RCE state:

$$L_{v}\frac{\partial q'}{\partial t} = -w'\frac{\partial \bar{h}}{\partial z} - \frac{\partial F'_{c}}{\partial z} + \dot{Q}', \tag{2}$$

where the primes denote departures from RCE, w' is the perturbation vertical velocity, and  $\bar{h}$  is the moist static energy of the RCE state. (Note that the vertical velocity, as we have defined it here, vanishes in the RCE state.)

The corresponding equation for dry static energy,  $h_d$ , is:

$$\frac{\partial h_d}{\partial t} = -\mathbf{V} \cdot \nabla h_d + L_v(C - E) - \frac{\partial F_{dc}}{\partial z} + \dot{Q},\tag{3}$$

where  $F_{dc}$  is the turbulent flux of dry static energy, C is the rate of condensation, and E the rate of evaporation of hydrometeors. Unlike the case of moist static energy, there are real sources and sinks of dry static energy, so that the right-hand side of (3) cannot be treated merely as the convergence of a turbulent flux. We next follow Y and E at E and E and E and E are real sources and sinks of dry static energy, so that the right-hand side of (3) cannot be treated merely as the convergence of a turbulent flux. We next follow Y and E and E are follow E and E are follow E and E are follow E and E are follows and that the latter occupy a very small fractional area of the sky. In that limit, and given that the dry static energy within the clouds has practically the same value as that outside the clouds, the dry static energy equation (3) reduces to the equation for the dry static energy of air outside of clouds. In this case, we consider an unsaturated downdraft driven by evaporation of precipitation to be part of the "cloud". The relation for dry static energy outside of clouds so defined is then

$$\frac{\partial h_d}{\partial t} = -\mathbf{V} \cdot \nabla h_d + M \frac{\partial h_d}{\partial z} + \dot{Q},\tag{4}$$

where M is the net upward convective mass flux, including any unsaturated, precipitation-driven downdrafts. We next linearize (4) about a state of rest, giving

$$\frac{\partial h'_d}{\partial t} = -(w' - M') \frac{\partial \bar{h}_d}{\partial z} + \dot{Q}'. \tag{5}$$

According to WTG, the vertical velocity is that which is necessary to hold temperature constant at each level above the boundary layer. Setting the left side of (5) to zero, we get

$$w' = M' + \dot{Q}' / \frac{\partial \bar{h}_d}{\partial z}. \tag{6}$$

Thus, from (6), w' depends on the radiative heating, the convective mass flux, and the dry static stability of the RCE state.

In this system, the radiation can depend only on water vapor, since temperature and the other greenhouse gases are being held fixed and we are not here considering cloud or aerosol feedbacks. It is important to note that the perturbation radiative heating at any level depends potentially on the specific humidity at all levels in the atmosphere.

To close the system, we need a representation of the (perturbation) convective flux of moist static energy,  $F'_c$ , and the (perturbation) net convective mass flux, M'. Later in this paper, we present a detailed formulation of moist convective fluxes, but note that, formally, the perturbation radiative heating depends on specific humidity fluctuations in the entire column, and that the vertical velocity, through (6), depends on the convective mass flux and the radiative heating, and the convective mass flux depends on vertical velocity and surface enthalpy fluxes (formulated later; see (14)). According to aero-dynamic surface flux formulations, the latter vary with boundary layer moist static energy and with surface wind. As shown by Wing and Emanuel [2013], these two components of the fluctuations in the surface fluxes can individually be large, but tend to cancel; for simplicity, we neglect surface flux effects here. In that case, both the perturbation vertical velocity and the perturbation convective mass flux depend on radiative heating, which in turn depends on the moisture perturbation at each level in the atmosphere. Symbolically, we can rewrite (2) as

$$L_{\nu} \frac{\partial q'_{i}}{\partial t} = -\left(\frac{\partial \bar{h}}{\partial z}\right) \sum_{i} \frac{\partial w_{i}}{\partial q_{j}} q'_{j} - \sum_{i} \frac{\partial^{2} F_{ci}}{\partial z \partial q_{j}} q'_{j} + \sum_{i} \frac{\partial \dot{Q}_{i}}{\partial q_{j}} q'_{j}, \tag{7}$$

where the subscripts denote the level in the atmosphere. (Equation (7) can of course more accurately be formulated as an integro-differential equation, but we retain the finite sum here as in practice we will use a finite number of layers.) To a good approximation, we only need sum over the troposphere, as perturbations are likely to be quite weak above the tropopause, owing to lack of convection and strong thermal stratification in the stratosphere. Strictly speaking, (2) and (7) are only valid above the boundary layer, yet radiative heating at any level will also depend on moisture perturbations in the boundary layer, which we have not developed an equation for. To the extent that the boundary layer is nearly opaque in the infrared, variations in its moisture content will have minimal effect on radiative transfer.

Equation (7) is a linear matrix eigenvalue equation that can be solved for the linear growth or decay rate of the moisture perturbations, with the use of (6) for w' and with a proper formulation of the convective fluxes. The growth rate will depend crucially on such issues as the dependence of convective fluxes on moisture, and on the variation of radiative heating rates with moisture fluctuations at each level in the troposphere. In the following section, we present what we believe to be the maximally simple model of (7) that captures the essence of the instability of the RCE state.

#### 3. Two-Layer Model

As will be evident at the end of this section, the essential physics governing the instability of the RCE state are absent in an atmospheric system in which only one layer is present above the boundary layer. Therefore, we use a two-layer model, as illustrated in Figure 1. Although *Wing and Emanuel* [2013] found that

![](_page_4_Picture_3.jpeg)

Figure 1. The two-layer model. Surface temperature and the temperatures of each layer are specified and constant. The emissivities,  $\varepsilon$ , updraft and downdraft mass fluxes,  $M_u$  and  $M_d$ , large-scale vertical velocities, w, and specific humidities, q, are variable. The vertical arrows depict the convective and radi-

shortwave radiative feedbacks are important, we will show in section 4 that they are not responsible for the surface temperature dependence of self-aggregation. Thus, for simplicity, we neglect them here. The longwave emissivities/absorptivities,  $\varepsilon$ , of each layer depend on the specific humidity, a, of the layer. Convection is represented by updraft and downdraft mass fluxes, M,, and  $M_d$  in each layer, and the perturbation-scale vertical velocities, w, are also defined in each layer. In this simplest version of the model, we take these convective mass fluxes to be the same in both layers. The temperature of the surface and of each

layer are specified and constant in time; there is thus no requirement for top-of-the-atmosphere energy balance. The Stefan-Boltzmann constant is  $\sigma$ . We apply (6) and (7) to this simple two-layer model. To do so, it is first necessary to specify the moist convective fluxes.

If the boundary layer is sufficiently thin, then the turbulent moist static energy flux out of its top will equal the surface flux:

$$F_{c0} = F_s, \tag{8}$$

where  $F_{c0}$  is the convective moist static energy flux out of the boundary layer and  $F_{s}$  is the surface turbulent enthalpy flux. We take the turbulent moist static energy flux to vanish at the top of the model, nominally the tropopause.

Convective updrafts and downdrafts transport moist static energy. At the model's midpoint (the 3/2 level), the mean moist static energy should be close to its minimum value, so that it is likely that downdrafts transport values of moist static energy that are larger than their environment. Precipitation-driven downdrafts are often initiated in the middle troposphere, and it is thus not likely that they have characteristic values of moist static energy that differ greatly from the local environment. For simplicity, we neglect the downdraft moist static energy flux here. Therefore, at the midpoint of the model, we represent the convective updraft moist static energy flux as

$$F_{c\frac{3}{2}} \simeq M_u \Big( h_b - h_{\frac{3}{2}} \Big), \tag{9}$$

where the subscript  $\frac{3}{2}$  represents the level halfway between levels 1 and 2, and  $M_u$  is the convective updraft mass flux. Neglecting entrainment, the updraft moist static energy should be equal to the boundary layer moist static energy,  $h_b$ . Thus, in this model, the convergences of the convective moist static energy fluxes at levels 1 and 2 are represented by

$$-\left(\frac{\partial F_c}{\partial z}\right)_1 = \frac{F_s - M_u \left(h_b - h_{\frac{3}{2}}\right)}{H},$$

$$-\left(\frac{\partial F_c}{\partial z}\right)_2 = \frac{M_u \left(h_b - h_{\frac{3}{2}}\right)}{H},$$
(10)

where H is the layer thickness. We linearize these around the RCE state, bearing in mind that, as discussed previously, we are neglecting variations in the surface enthalpy flux. This gives

$$-\left(\frac{\partial F'_c}{\partial z}\right)_1 = \frac{-M'_u \left(h_b - \bar{h}_{\frac{3}{2}}\right) + \bar{M}_u h'_{\frac{3}{2}}}{H},$$

$$-\left(\frac{\partial F'_c}{\partial z}\right)_2 = \frac{M'_u \left(h_b - \bar{h}_{\frac{3}{2}}\right) - \bar{M}_u h'_{\frac{3}{2}}}{H},$$
(11)

where we have once again neglected fluctuations in the boundary layer moist static energy. The convective mass flux itself will be represented according to the boundary layer quasi-equilibrium hypothesis of *Raymond* [1995], as slightly modified by *Emanuel* [1995], and also including the effects of shallow, nonprecipitating convection. The net flux of low moist static energy air into the subcloud layer by deep downdrafts and shallow convection is estimated by

$$(M_u - w_1) \left( h_b - h_{\frac{3}{2}} \right) + F_{shallow} = F_s, \tag{12}$$

where  $F_{shallow}$  is the moist static energy flux by shallow convection. This simply states that the net flux of moist static energy out of the boundary layer always equals the surface enthalpy flux,  $F_s$ . The first term on the left of (12) represents the deep convective enthalpy flux out of the subcloud layer; by mass continuity,  $M_u - w_1$  equals the net downdraft mass flux into the subcloud layer. We are here assuming that the downdrafts import moist static energy from the middle level of the model. We here represent the shallow convective enthalpy flux as a fixed fraction of the surface flux:

$$F_{shallow} = (1 - \alpha)F_{s},\tag{13}$$

with  $\alpha$  < 1. Substituting (13) into (12) gives

$$M_u = w_1 + \frac{\alpha F_s}{h_b - h_{\frac{3}{3}}}. (14)$$

For the mean state, combining (14) (with  $w_1=0$ ) with (10) and (1) (with V=0) shows that

$$\alpha = \frac{\bar{Q}_2}{\bar{Q}_1 + \bar{Q}_2},\tag{15}$$

where the overbars represent the RCE state values.

Linearizing this about the RCE state gives

$$M'_{u} = W'_{1} + \frac{\alpha F_{s}}{\left(h_{b} - \bar{h}_{\frac{3}{2}}\right)^{2}} h'_{\frac{3}{2}} = W'_{1} + \frac{\bar{M}_{u}}{\left(h_{b} - \bar{h}_{\frac{3}{2}}\right)^{2}} L_{v}(q'_{1} + q'_{2}). \tag{16}$$

The second equality results because  $w_1$  vanishes in the RCE state and because temperature is constant in this system, so moist static energy fluctuations are owing to moisture fluctuations alone; we have also assumed that the specific humidity perturbation at the model midlevel is the average of the values of the two layers. We have also used (14) to relate the surface fluxes to the background state convective mass flux.

Note that the last term in (16) comes from the linearization of the last term in (14), and shows that the convective mass flux is sensitive to tropospheric moisture, increasing with the latter. This works in the same sense as entrainment would, though we do not consider entrainment here.

Although we have neglected downdraft fluxes of moist static energy at the model's mid level, it is important to account for downdrafts in calculating the compensating subsidence. Thus, the mass flux that appears in the dry static energy balance, (6), is the sum of the updraft and downdraft mass fluxes at each level. Here we assume that since downdrafts are driven mostly by water loading and evaporation of precipitation, supplied by updrafts, their magnitude is proportional to the updraft mass flux by

$$M_d = -(1 - \varepsilon_p) M_u, \tag{17}$$

where  $\varepsilon_p$  may be regarded as related to a bulk precipitation efficiency. Thus, in (6),

$$M' = M'_{u} + M'_{d} = \varepsilon_{p} M'_{u}, \tag{18}$$

where we have neglected possible fluctuations in  $\varepsilon_p$ . For simplicity, we take  $\varepsilon_p$  to have the same value at the two model levels.

We write (6) at each level, then, as

$$W'_{i} = \varepsilon_{p} M'_{u} + \frac{\dot{Q}'_{i}}{\left(\frac{\partial \bar{h}_{d}}{\partial z}\right)_{i}}, \tag{19}$$

with i = 1,2. We assume that the moist static energy perturbation halfway between the model levels, needed in (11), is just the simple arithmetic average of the perturbations at the two model levels:

$$h'_{\frac{3}{2}} = \frac{1}{2} L_{\nu} (q'_1 + q'_2) \tag{20}$$

Finally, we assume that the moist static energy profile of the RCE state is a simple, symmetric, piecewise linear profile with a minimum halfway between the model levels, and with a value of the top of the model equal to the boundary layer moist static energy. Thus,

$$\left(\frac{\partial \bar{h}}{\partial z}\right)_2 = -\left(\frac{\partial \bar{h}}{\partial z}\right)_1 = \frac{h_b - \bar{h}_{\frac{3}{2}}}{H}.$$
 (21)

For notational convenience, we introduce

$$S_i \equiv \left(\frac{\partial \bar{h}_d}{\partial z}\right)_i \tag{22}$$

This is the dry static stability of the RCE state, and we account for the fact that it is different in the two model layers. We also note that energy balance in the RCE state requires that

$$\varepsilon_p \bar{M}_u S_i = -\bar{Q}_i, \tag{23}$$

where  $\dot{\bar{Q}}_i$  is the mean state radiative heating (which is always negative). At the same time, (1) coupled with (9) and (23) requires that

$$h_b - \bar{h}_{\frac{3}{4}} = \varepsilon_p S_2 H \tag{24}$$

We are now in a position to write (7) specialized to our two-layer model. Using (11), (16), (18), and (19–24) together with the aforementioned notational simplifications, we can write the resulting matrix equation as

$$L_{\nu} \begin{pmatrix} \frac{\partial q'_{1}}{\partial t} \\ \frac{\partial q'_{2}}{\partial t} \end{pmatrix} = \begin{pmatrix} c_{11} & c_{12} \\ c_{21} & c_{22} \end{pmatrix} \begin{pmatrix} q'_{1} \\ q'_{2} \end{pmatrix}, \tag{25}$$

where the coefficients are defined as follows:

$$c_{11} \equiv \frac{\partial \dot{Q}_1}{\partial q_1}$$

$$c_{12} \equiv \frac{\partial \dot{Q}_1}{\partial q_2}$$

$$c_{21} \equiv \varepsilon_p \frac{S_2}{S_1} \frac{\partial \dot{Q}_1}{\partial q_1} + \frac{\partial \dot{Q}_2}{\partial q_1} (1 - \varepsilon_p)$$

$$c_{22} \equiv \varepsilon_p \frac{S_2}{S_1} \frac{\partial \dot{Q}_1}{\partial q_2} + \frac{\partial \dot{Q}_2}{\partial q_2} (1 - \varepsilon_p)$$
(26)

It remains to determine the dependence of the radiative heating rates on the specific humidities of the two layers. Inspection of Figure 1, and accounting for the absorption of radiation in each layer, emitted from the other layer and from the surface, gives

$$H^* \rho_1 \bar{\dot{Q}}_1 = -2\sigma \varepsilon_1 T_1^4 + \sigma \varepsilon_1 \varepsilon_2 T_2^4 + \sigma \varepsilon_1 T_5^4,$$

$$H^* \rho_2 \bar{\dot{Q}}_2 = -2\sigma \varepsilon_2 T_2^4 + \sigma \varepsilon_1 \varepsilon_2 T_1^4 + \sigma \varepsilon_2 (1 - \varepsilon_1) T_5^4,$$
(27)

where  $\rho_1$  and  $\rho_2$  are the layer densities. Remembering that the temperatures are fixed in this system, the perturbations to the radiative heating depend exclusively on the dependences of the emissivities on specific humidity. Thus,

$$\frac{\partial \dot{Q}_{1}}{\partial q_{1}} = \frac{\ddot{Q}_{1}}{\varepsilon_{1}} \frac{\partial \varepsilon_{1}}{\partial q_{1}} \qquad (<0)$$

$$\frac{\partial \dot{Q}_{1}}{\partial q_{2}} = \frac{\sigma \varepsilon_{1} T_{2}^{4}}{\rho_{1}} \frac{\partial \varepsilon_{2}}{\partial q_{2}} \qquad (>0)$$

$$\frac{\partial \dot{Q}_{2}}{\partial q_{1}} = -\frac{\sigma \varepsilon_{2}}{\rho_{2}} \frac{\partial \varepsilon_{1}}{\partial q_{1}} (T_{s}^{4} - T_{1}^{4}) \quad (<0)$$

$$\frac{\partial \dot{Q}_{2}}{\partial q_{2}} = \frac{\ddot{Q}_{2}}{\varepsilon_{2}} \frac{\partial \varepsilon_{2}}{\partial q_{2}} \qquad (<0)$$

The symbols in parentheses indicate the sign of the dependencies. We assume that the emissivities increase monotonically with water vapor, though they may saturate at sufficiently large concentrations. Note that because the mean state radiative heating is negative, and because  $T_s > T_1$ , all of these are negative except for the dependence of the heating of the first layer on the moisture content of the second. This will turn out to be crucial to the instability.

The linear equations (25) have solutions of the form  $q'_i = a_i e^{vt}$ , where the  $a'_i$ s are constants and v is the growth rate. Substitution in (25) yields solutions for v:

$$v = \frac{1}{2L_{\nu}} \left[ c_{11} + c_{22} \pm \sqrt{(c_{11} - c_{22})^2 + 4c_{12}c_{21}} \right]$$
 (29)

The growth rate will be positive if either  $c_{11}+c_{22}>0$  or  $c_{12}c_{21}>c_{11}c_{22}$ . The first of these may be written, using (26) and (28)

$$\frac{\bar{Q}_1}{\varepsilon_1} \frac{\partial \varepsilon_1}{\partial q_1} + \left(1 - \varepsilon_p\right) \frac{\bar{Q}_2}{\varepsilon_2} \frac{\partial \varepsilon_2}{\partial q_2} + \varepsilon_p \frac{S_2}{S_1} \frac{\sigma \varepsilon_1 T_2^4}{\rho_1} \frac{\partial \varepsilon_2}{\partial q_2} > 0. \tag{30}$$

Note that the RCE state heating rates,  $\dot{Q}_1$  and  $\dot{Q}_2$  are given by (27). The first two terms in (30) are negative, because the RCE radiative heating rates are always negative (compensated by convective heating.). Only the last term is positive. At high temperature, we expect the very moist lower troposphere to have high infrared emissivity. In that limit of  $\varepsilon_1 \to 1$ ,  $\partial \varepsilon_1/\partial q_1 \to 0$ , and using (27) for  $\dot{Q}_2$ , the instability criterion (30) becomes

$$\varepsilon_{p} > \frac{2 - \left(\frac{T_{1}}{T_{2}}\right)^{4}}{\frac{S_{2}}{S_{1}} \frac{\rho_{2}}{\rho_{1}} + 2 - \left(\frac{T_{1}}{T_{2}}\right)^{4}} \tag{31}$$

Since  $T_1 > T_2$ , the right side of (31) is reasonably small. (From the second relation in (27) with  $\varepsilon_1 = 1$ ,  $(T_1/T_1) = 1$  $T_2$ )<sup>4</sup> < 2 for the mean state to be cooling radiatively, which is necessary for radiative-convective equilibrium; thus the right side of (31) is positive.) This would explain why self-aggregation occurs at high temperature. More generally, according to (30), instability is favored by

- 1. Large dependence of upper tropospheric emissivity on water vapor concentration
- Small dependence of lower tropospheric emissivity on water vapor concentration

- 3. High emissivity of the lower layer
- 4. High precipitation efficiency

In particular, the instability is driven by the dependence of the radiative cooling of the lower layer on the emissivity (i.e., water vapor concentration) of the upper troposphere. That is why a model with at least two layers is necessary to capture this instability. Although convection is sensitive to free tropospheric water vapor, through (14), that sensitivity cancels out in this simple model and thus plays no role in the instability. (In a variant of this simple model, in which the moist static energy carried into the boundary layer by downdrafts is represented by that of the middle of the lowest model layer, rather than the 3/2 level, the sensitivity of convection to water vapor boosts the instability but cannot destabilize the model on its own.)

The second possible criterion for instability,  $c_{12}c_{21} > c_{11}c_{22}$ , may be written:

$$-\left(1-\varepsilon_{p}\right)\frac{\partial\varepsilon_{1}}{\partial q_{1}}\frac{\partial\varepsilon_{2}}{\partial q_{2}}\left(\sigma^{2}\frac{\varepsilon_{1}\varepsilon_{2}T_{2}^{4}}{\rho_{1}\rho_{2}}\left(T_{s}^{4}-T_{1}^{4}\right)+\frac{\bar{Q}_{1}\bar{Q}_{2}}{\varepsilon_{1}\varepsilon_{2}}\right)>0. \tag{32}$$

The left side of (32) is negative, so instability cannot occur by this second criterion, and thus the general criterion for instability is given by (30).

Note also, from (25), that

$$q'_{2} = \frac{v - c_{11}}{c_{12}} q'_{1}. \tag{33}$$

Since, from (26) and (28),  $c_{11} < 0$  and  $c_{12} > 0$ , the eigenvectors of q' corresponding to growing perturbations have the same sign in both layers. Thus either both layers dry, or both layers moisten; there is no instability in which the signs of the water vapor tendencies differ between the two layers.

The instability of the two-layer model arises when downward motion dries both layers. The decreases emissivity of the upper layer leads to enhanced radiative cooling of the lower layer, which diminishes convection, leading to cooling of both layers and reinforcing the initial downward motion. As it is a linear model, the converse is also true, substituting upward for downward motion, and moistening for drying.

In the following section, we test this basic concept of radiative-convective instability in a multilevel singlecolumn model run to a classical RCE state and then placed into a WTG configuration wherein any instability can be realized.

#### 4. Single-Column Model

Here we use a single-column model to examine some of the concepts that emerge from the two-layer model described in the previous section. Our strategy is to run the single-column model into RCE with prescribed surface temperature, and then to use the RCE state with small humidity perturbations as an initial condition for running it in WTG mode, to test for stability.

We use the MIT single-column model described originally in Rennó et al. [1994] and updated with a modified convection scheme as described in Emanuel and Živkovic-Rothman [1999]. Radiative transfer is computed interactively using the shortwave parameterization of Fouquart and Bonnel [1980] and Morcrette's [1991] longwave parameterization. Radiative fluxes are computed at each vertical level every 3 h using instantaneous profiles of temperature, humidity, cloud fraction and cloud water path, and a climatological distribution of ozone. Stratiform clouds are represented using the parameterization of Bony and Emanuel [2001]. Incoming solar radiation is specified using a control value of the solar constant of 1360  $\mathrm{Wm}^{-2}$  and averaging top-of-the-atmosphere (TOA) incoming solar radiation at 15 degrees north latitude over a year. Thus, there are no diurnal or seasonal cycles in the radiation. The surface albedo is set to 0.38. For the control experiment, CO<sub>2</sub> concentration is fixed at 360 ppm, and concentrations of CH4, N2O, CFC11, and CFC12 are fixed at 1.72 ppm, 310 ppb, 280 ppt, and 484 ppt, respectively.

The convection scheme of Emanuel and Živkovic-Rothman [1999] uses a buoyancy sorting algorithm similar to that of Raymond and Blyth [1986] and represents an entire spectrum of convective clouds, from shallow,

nonprecipitating cumulus to deep precipitating cumulonimbus. Precipitation reevaporates and drives an unsaturated downdraft that imports enthalpy and moisture into the subcloud layer. Reevaporation of cloud water, resulting from entrainment of dry air, drives penetrative downdrafts within the clouds. The cloud base mass flux is continuously relaxed so as to produce near neutrality of a parcel lifted dry adiabatically, and then moist adiabatically, to the first level above its lifted condensation level. This maintains a form of boundary layer quasi-equilibrium [Raymond, 1995].

Surface sensible and latent heat fluxes are calculated using conventional aerodynamic flux formulae with a constant exchange coefficient of 1.2 3 102<sup>3</sup> . A constant background wind speed of 5 ms2<sup>1</sup> is used in the control experiment, but this is enhanced by a gustiness factor produced by the convection scheme.

The model is run with vertical levels spaced at 25 hPa, but with greater resolution (more levels) above 100 hPa. A time step of 5 min is employed.

First, a control simulation using the aforementioned standard forcing values is initialized using a tropical sounding and run into RCE. The precipitation in the RCE state in this model is not absolutely steady but fluctuates with an approximate white noise frequency spectrum and an amplitude of about 68% of its mean value. To define the equilibrium quantities, the simulations are run until statistical equilibrium is reached for at least 50 days and the output is averaged over the last 10 days. For a simulation using an SST of 30C, the surface equilibrium precipitation rate is about 4.4 mm d2<sup>1</sup> . The temperature profile is dry adiabatic up to 950 hPa and nearly moist adiabatic to a tropopause at 150 hPa and with a temperature of around 278C; above this cold point, the temperature increases upward in the model's stratosphere. Figure 2 shows vertical profiles of actual and saturation moist static energy and convective mass fluxes in this equilibrium state.

Each simulation is then reinitialized and run in WTG mode, wherein the temperature is held fixed at and above 850 hPa, and the vertical velocity is calculated at each level at and above 850 hPa so as to maintain constant temperature. This vertical velocity and the convergence/divergence it implies alter the humidity profile. This is precisely the methodology developed by Sobel and Bretherton [2000]. The model is reinitialized with the temperature and humidity profiles of the RCE simulation, but with a uniform 10% increase or reduction of the specific humidity at each model level. The model is then run until a new equilibrium state is reached. If the new equilibrium is identical, or nearly identical, to the original RCE state, that state is deemed stable; otherwise, the RCE state is taken to be unstable. These experiments are run for SSTs of 25, 30, 35, 40, and 45C.

The WTG reinitialized simulations for surface temperatures of 25 and 30C showed little difference from the corresponding RCE states, so these are deemed stable. The WTG reinitialized simulations with surface temperatures of 35, 40, and 45C drifted away from their corresponding RCE states, toward states with mostly upward motion and a moist atmosphere (for the moist reinitialization), or mostly downward motion and a dry atmosphere (for the dry reinitialization). Thus, for this model, the onset of instability occurs at a surface

![](_page_9_Figure_10.jpeg)

Figure 2. Vertical profiles of (left) moist static energy and (right) convective mass fluxes at equilibrium in the control simulation, for which the SST 5 30C. Moist static energy is shown in blue, and saturation moist static energy is shown in green. The convective mass fluxes are composed of buoyant updrafts (blue), penetrative downdrafts (green), and a precipitationdriven unsaturated downdraft (red).

temperature somewhere between 30 and 35C. The instability leads to an evolution away from the RCE state and toward one of the two states described above. We believe that these two states correspond to the multiple equilibria found by Raymond and Zeng [2000] in a two-column model, Sobel et al. [2007] in a single-column model under WTG, and Sessions et al. [2010], using a cloud-resolving model also run in WTG mode. We argue, following Sobel et al. [2007], that these states correspond to the dry, descending and moist, ascending portions of RCE states with aggregated convection [e.g., Wing and Emanuel, 2013].

The evolutions with time of various quantities, as a function of pressure, are shown in Figure 3, for the case of SST 5 40C and using negative specific humidity anomalies in the reinitialization. Time is shown in days since reinitialization from the RCE state using WTG. The specific humidity perturbations are negative through the entire troposphere, but initially are larger at higher altitudes. Likewise, the vertical velocity perturbations are everywhere negative (positive omega). The convective heating anomaly is everywhere negative except in the subcloud layer, where a radiative cooling anomaly must be balanced by added sensible heat flux from the surface. (In Figure 3d, the dry convective adjustment of the subcloud layer is included in the definition of convective heating.) The net radiative heating anomaly evolves in a manner broadly similar to that in the descending region of aggregated convection simulations using a cloud system resolving model [Wing and Emanuel, 2013, Figure 7c].

Similar to the results of Sobel et al. [2007] and Sessions et al. [2010], the new WTG equilibrium with descent is quite dry, with relative humidity dropping off rapidly above a trade-cumulus boundary layer extending upward to about 750 hPa. Some of the deeper cumuli precipitate, and the stratiform cloud scheme of Bony and Emanuel [2001] also produces some precipitation; together these amount to about 0.2 mm d2<sup>1</sup> , compared to the RCE value of about 6 mm d2<sup>1</sup> for this value of the surface temperature.

In the case of positive initial humidity perturbations (not shown), the ultimate quasi-steady state is not in all respects a mirror image of that resulting from negative perturbations. The steady-state vertical motion is everywhere positive (negative omega) as are the specific humidity and convective heating perturbations,

![](_page_10_Figure_8.jpeg)

Figure 3. Time-height sections of perturbations from the RCE state of (a) specific humidity, (b) omega, (c) radiative heating, and (d) convective heating. Time is in days after reinitialization from the RCE state under WTG. The surface temperature in this case is 40C.

![](_page_11_Figure_4.jpeg)

Figure 4. Perturbation heating rate as a function of pressure (ordinate) and the pressure level of a 20% negative perturbation in specific humidity (abscissa), for SSTs of (left) 25C and (right) 40C. Plotted is the logarithm of 1 1 the actual heating rate, for positive heating rates, and minus the logarithm of 1 minus the heating rate, for negative heating rates.

but unlike the negative case, the radiative heating anomaly has the same (positive) sign throughout the troposphere. The precipitation is almost double that of the RCE state, at about 11 mm d2<sup>1</sup> . Thus, the steady states are far from the linear regime.

The basic physics of the RCE instability, including its temperature dependence, may be elucidated by quantifying the radiative anomalies that accompany specific humidity anomalies at various levels.

Figure 4 shows, for SSTs of 25 and 40C, the perturbation radiative heating at all levels that results from an instantaneous 20% decrease in specific humidity at each model level individually. In general, a decrease in humidity at a particular level decreases the radiative cooling rate at and above the level in question, and increases it below the level of the perturbation, broadly consistent with inferences from the two-layer model. Note that the downward remote influence is in general stronger, particularly at the higher SST.

Taking a cue from the results of both the two-layer model and the single-column model, we examine the response of radiative heating, as a function of altitude, to an instantaneous 20% reduction of specific humidity from the RCE state at all model levels. While from Figure 3a such a perturbation is clearly not exactly an eigenvector of the linear phase of the instability, perturbations of such simplified structure should allow us to understand the basic physics and temperature dependence of the instability.

Figure 5 (left) shows the perturbation to the shortwave and longwave components of the radiative heating, as well as their sum, for the case that SST 5 25C, while Figure 5 (right) shows the same quantities when

![](_page_11_Figure_11.jpeg)

Figure 5. Perturbation shortwave (red), longwave (blue), and net (black) radiative heating rates in response to an instantaneous reduction of specific humidity of 20% from the RCE states for (left) SST 5 25C and (right) 40C. Note the different scales on the abscissas.

![](_page_12_Figure_3.jpeg)

Figure 6. Perturbation net radiative heating rates in response to an instantaneous reduction of specific humidity of 20% from the RCE states for SSTs ranging from 25 to 45C.

SST 5 40C. In both cases, the shortwave radiative feedback is positive: drying leads to increased cooling, which when coupled with the resulting downward motion, would lead to further drying. At the lower SST, this is not sufficient to overcome the powerful negative feedback of the longwave radiative cooling: Drying leads to reduced longwave cooling at all levels, which would tend to produce upward vertical motion, whose moistening then counters the initial drying. At the higher SST, the sign of the longwave radiative cooling is reversed below about 750 hPa and is now a positive feedback: Decreasing the water vapor concentration at all levels results in increased longwave cooling of the lower troposphere, in response to decreased IR opacity of the upper troposphere, consistent with inferences from the two-layer model presented in section 3. While the

radiative heating anomaly is still positive aloft, there is less convective heating of the whole troposphere (Figure 3d), more than canceling the radiative heating anomaly. Note that the shortwave radiative feedback is fractionally less important at higher temperature, except in the very high troposphere. The shortwave response does not explain the temperature dependence of the RCE instability; this enters strictly through the longwave response.

Figure 6 summarizes the temperature dependence of the response of the net radiative heating to an instantaneous 20% reduction in specific humidity at all levels. At SSTs of 35C and greater, drying of the atmosphere leads to a net increase of radiative cooling at low levels, in response to the reduced IR emissivity of the upper troposphere. Clearly, the radiative response is strongly sensitive to temperature, particularly on the longwave side, owing to sensitive dependence of IR radiation on water vapor and, through the nonlinearity of Clausius-Clapeyron, to sensitive dependence of water vapor on temperature. In interpreting Figures 5 and 6, note that

![](_page_12_Figure_8.jpeg)

Figure 7. Schematic regime diagram for equilibrium states, showing the large-scale WTG vertical velocity as a function of SST. Below the critical SST, the RCE state is stable to small amplitude perturbations, but sufficiently large perturbations may transition the state to an upper stable equilibrium with ascent, or a lower stable equilibrium with descent. Above the critical SST, the RCE state is linearly unstable and such transitions are spontaneous. Question marks denote unexplored regions; in particular, it is not known whether there are minimum SST bounds on the existence of the upper and lower stable equilibria.

the heating perturbation structures should not be regarded as eigenvectors as they are in response to imposed water vapor perturbations that are not eigenvectors.

### 5. Summary

Together with the work of Wing and Emanuel [2013], the results presented here paint a fairly clear picture of RCE instability and the phenomenon of self-aggregation. The instability occurs when the lower troposphere is moist enough that its infrared opacity is not far from unity. In that limit, the lower tropospheric opacity is insensitive to small changes in its own water vapor content, yet the infrared opacity of the upper troposphere remains sensitive to moisture. Under these conditions, the introduction of a nearly vertically uniform fractional decrease in water vapor concentration leads to the following effects:

- 1. Radiative cooling of the lower troposphere increases, owing to increased IR emissions to space through the dryer upper troposphere.
- 2. Radiative cooling of the upper troposphere decreases owing to its decreased emissivity, given that its temperature is higher than radiative equilibrium.
- 3. The combination of the weak temperature gradient approximation (WTG) and boundary layer convective quasi-equilibrium leads to a decrease in upward convective mass flux.
- 4. The decreased convective mass flux enhances the net cooling of the lower troposphere and more than cancels the decreased radiative cooling of the upper troposphere, leading, through WTG, to downward large-scale motion through the depth of the troposphere.
- 5. The decreased deep convection and large-scale descent both lead to drying of the troposphere, reinforcing the original moisture perturbations.
- 6. The shortwave radiative feedback is always positive: a drier atmosphere absorbs less sunlight, increasing the radiative cooling rate. At low temperatures, this is a significant contribution to the net perturbation radiative heating, but not enough to offset the strong negative longwave radiative feedback. At high temperature, the shortwave contribution is a small fraction of the net perturbation radiative heating. The temperature dependence of the radiative feedbacks important for self-aggregation is strongly dominated by longwave effects.

For a positive moisture perturbation, the signs of the changes in (1)–(5) above are all reversed, but the same reasoning applies. But as the instability develops and reaches appreciable amplitude, the evolutions of the upward and downward perturbations proceed quite differently. In the case with downward large-scale motion, the drying of the lower troposphere eventually reduces its IR opacity to the point that it ceases to cool at a rate faster than that of the RCE state, though it still lacks deep convection. (This is evident in the reversal of the sign of the longwave radiative feedback part way through the simulation of self-aggregation by Wing and Emanuel [2013]; see their Figure 5c.) The formation of boundary layer clouds may further alter the radiative cooling profile. In the event that deep convection ceases altogether, the radiative cooling above the boundary layer is balanced entirely by subsidence warming.

The development of the upward branch of the instability proceeds quite differently once it reaches appreciable amplitude. As deep convection increases, stratiform clouds develop in its outflow and serve to further reduce OLR, thus further decreasing the radiative cooling of the column. According to the results of Wing and Emanuel [2013], this cloud-radiative feedback eventually dominates the feedback processes leading to the migration to the higher of the two equilibrium states identified by Raymond and Zeng [2000] and Sobel et al. [2007].

Self-aggregation may be regarded as the result of the linear instability of the RCE state, leading to upward motion with deep convection (the upper stable equilibrium branch identified by Sobel et al. [2007]), in part of the domain, and clear, dry air in the rest (the lower stable equilibrium of Sobel et al. [2007]). As found by Khairoutdinov and Emanuel [2010], the aggregated state persists even as surface temperature decreases to well below its critical value. Once established, the longwave cloud radiative feedback is powerful enough to maintain the aggregated state, even though the longwave opacity of the lower troposphere has elsewhere declined to well below the levels necessary to initiate instability.

The results of Wing and Emanuel [2013] together with those of the two-layer model presented here, and earlier work [e.g., Bretherton et al., 2005] that pointed to the crucial role of inhomogeneous radiation in selfaggregation, all suggest that while feedbacks between convection and moisture may boost the instability, they may not be sufficient by themselves to cause it.

When these processes are simulated in a cloud system resolving model phrased in rotating coordinates, tropical cyclones develop [Bretherton et al., 2005; Held and Zhao, 2008; Khairoutdinov and Emanuel, 2012; Nolan et al., 2007]. Nolan et al. [2007] showed that tropical cyclogenesis can occur below the critical temperature if finite amplitude perturbations are introduced. All of the previous work on aggregation and multiple equilibria of RCE, together with the results presented here, suggest that RCE instability can be characterized as a subcritical bifurcation of the RCE state, as first suggested by Emanuel and Nolan [2004]. A schematic regime diagram showing this bifurcation is displayed in Figure 7.

The instability of the RCE state is fundamentally thermodynamic in character, involving the interplay of water vapor, longwave and to a lesser extent shortwave radiation, moist convection, and large-scale vertical motion which, through WTG, is slaved to the net diabatic heating. It should not be regarded as a dynamical mode of instability as it does not involve buoyancy or interactions among velocity or vorticity perturbations. To the extent that phenomena such as the Madden-Julian Oscillation represent particular realizations of self-aggregated convection [Khairoutdinov and Emanuel, 2012], they may prove difficult to account for using standard dynamical arguments.

Khairoutdinov and Emanuel [2012] suggested that the strong increase in OLR that accompanies aggregation of convection may serve as a tropical thermostat, limiting SST to the neighborhood of its critical value, an example of a self-organized critical state. Tobin et al. [2012] found evidence for the drying effect of aggregation in satellite-based observations. If the real tropics is indeed close to the critical SST for aggregation, attempts to model self-aggregation using observed values of SST may prove unusually sensitive to physical and numerical details, as has been found in a number of studies [e.g., Muller and Held, 2012]. One might predict that such extreme sensitivity would be reduced by conducting simulations with surface temperatures well above the critical value (bearing in mind that, in that case, quite large domains might be needed, as demonstrated by Wing and Emanuel [2013]).

The presence of a large-scale background surface wind is likely to change the critical value of the SST [Sessions et al., 2010].

The radiative portion of the physics of the instability of the RCE state, as described here, should be well handled by most climate and weather models, as it initially involves mostly clear-sky radiative dependencies on water vapor. But the instability also depends on the response of deep convection to moisture perturbations, and these vary widely across models and convection schemes. Thus, self-aggregation of convection may be simulated very differently among such models, perhaps partially explaining why they have such different climatologies of tropical cyclones and the Madden-Julian Oscillation. The omission or underrepresentation of convective gustiness may lead to a strong net negative surface flux feedback [Wing and Emanuel, 2013], preventing self-aggregation from occurring.

The instability of RCE may have profound implications for the Earth's climate and for simulating it with climate models. While the results of single-column models and cloud-resolving models with homogeneous boundary conditions cannot be directly applied to the real climate system, owing to the presence of largescale circulation, knowledge of the physics underlying RCE instability may prove essential for accurate simulation of a climate in which clustering of deep convection is pervasive, as is the case in the current climate. In particular, inaccurate treatment of such physics may affect the model's ability to cluster deep convection, affecting the quality of its simulation of such phenomena as tropical cyclones and the Madden-Julian Oscillation and compromising potentially important climate feedbacks such as may occur through drying of the atmosphere [Khairoutdinov and Emanuel, 2010; Tobin et al., 2012] and mixing of the upper ocean [Emanuel, 2001; Korty et al., 2007; Vincent et al., 2012]. These are ample reasons to focus research attention on the instability of RCE states.

#### Acknowledgments

The first two authors were supported under NSF grant AGS1032244, and the second author was additionally supported by NSF grants 1136480 and 0850639 as well as by MIT's Joint Program on the Science and Policy of Global Change. The third author was supported by the NOAA Climate and Global Change Postdoctoral Fellowship Program, administered by the University Corporation for Atmospheric Research. Marat Khairoutdinov provided generous assistance with the use of the SAM model.

### References

Arakawa, A., and W. H. Schubert (1974), Interaction of a cumulus cloud ensemble with the large-scale environment, Part I, J. Atmos. Sci., 31, 674–701.

Bony, S., and K. A. Emanuel (2001), A parameterization of the cloudiness associated with cumulus convection: Evaluation using TOGA COARE data, J. Atmos. Sci., 58, 3158–3183.

Bretherton, C. S., and M. F. Khairoutdinov (2004), Convective self-aggregation in large cloud-resolving model simulations of radiative convective equilibrium, paper presented at AMS Conference on Hurricanes and Tropical Meteorology, Am. Meteorol. Soc., Miami, Fla. Bretherton, C. S., P. N. Blossey, and M. F. Khairoutdinov (2005), An energy-balance analysis of deep convective self-aggregation above uniform SST, J. Atmos. Sci., 62, 4273–4292.

Craig, G. C., and J. M. Mack (2013), A coarsening model for self-organization of tropical convection, J. Geophys. Res., 118, 8761–8769, doi: 10.1002/jgrd.50674.

Emanuel, K. A. (1995), The behavior of a simple hurricane model using a convective scheme based on subcloud-layer entropy equilibrium, J. Atmos. Sci., 52, 3959–3968.

Emanuel, K. A. (2001), The contribution of tropical cyclones to the oceans' meridional heat transport, J. Geophys. Res., 106, 14,771–14,782. Emanuel, K. A., and M. Zivkovic-Rothman (1999), Development and evaluation of a convection scheme for use in climate models, J. Atmos. Sci., 56, 1766–1782.

Emanuel, K. A., and D. S. Nolan (2004), Tropical cyclone activity and the global climate system, paper presented at 26th AMS Conference on Hurricanes and Tropical Meteorology, Am. Meteor. Soc., Miami, Fla.

![](_page_15_Picture_1.jpeg)

- Fouquart, Y., and B. Bonnel (1980), Computation of solar heating of the Earth's atmosphere: A new parameterization, Beitr. Phys. Atmos., 53, 35–62.
- Goody, R. M., and Y. L. Yung (1995), Atmospheric Radiation: Theoretical Basis, 2nd ed., 519 pp., Oxford Univ. Press, New York.
- Held, I., and M. Zhao (2008), Horizontally homogeneous rotating radiative-convective equilibria at GCM resolution, J. Atmos. Sci., 65, 2003– 2013.
- Held, I. M., R. S. Hemler, and V. Ramaswamy (1993), Radiative-convective equilibrium with explicit two-dimensional moist convection, J. Atmos. Sci., 50, 3909–3927.
- Jeevanjee, N., and D. M. Romps (2013), Convective self-aggregation, cold pools, and domain size, Geophys. Res. Lett., 40, 994–998, doi: 10.1002/grl.50204.
- Khairoutdinov, M. F., and K. Emanuel (2010), Aggregated convection and the regulation of tropical climate, paper presented at 29th Conference on Hurricanes and Tropical Meteorology, Am. Meteorol. Soc., Tucson, Ariz.
- Khairoutdinov, M. F., and K. Emanuel (2012), The effects of aggregated convection in cloud-resolved radiative-convective equilibrium, paper presented at 30th Conference on Hurricanes and Tropical Meteorology, Am. Meteorol. Soc., Jacksonville, Fla.
- Korty, R., K. A. Emanuel, and J. R. Scott (2007), Tropical cyclone-induced upper ocean mixing and climate: Application to equable climates, J. Clim., 21, 638–654.
- Manabe, S., and R. F. Strickler (1964), On the thermal equilibrium of the atmosphere with convective adjustment, J. Atmos. Sci., 21, 361–385. Morcrette, J.-J. (1991), Radiation and cloud radiative properties in the European Centre for Medium-Range Weather Forecasts forecasting system, J. Geophys. Res., 96, 9121–9132.
- Muller, C. J., and I. Held (2012), Detailed investigation of the self-aggregation of convection in cloud-resolving simulations, J. Atmos. Sci., 69, 2551–2565.
- Nilsson, J., and K. A. Emanuel (1999), Equilibrium atmospheres of a two-column radiative convective model, Q. J. R. Meteorol. Soc., 125, 2239–2264.
- Nolan, D. S., E. D. Rappin, and K. A. Emanuel (2007), Tropical cyclogenesis sensitivity to environmental parameters in radiative–convective equilibrium, Q. J. R. Meteorol. Soc., 133, 2085–2107.
- Pujol, T., and G. R. North (2002), Runaway greenhouse effect in a semigray radiative-convective model, J. Atmos. Sci., 59, 2801–2810.
- Raymond, D. J. (1995), Regulation of moist convection over the west Pacific warm pool, J. Atmos. Sci., 52, 3945–3959.
- Raymond, D. J. (2000), The Hadley circulation as a radiative–convective instability, J. Atmos. Sci., 57, 1286–1297. Raymond, D. J., and A. M. Blyth (1986), A stochastic model for nonprecipitating cumulus clouds, J. Atmos. Sci., 43, 2708–2718.
- Raymond, D. J., and X. Zeng (2000), Instability and large-scale circulations in a two-column model of the tropical troposphere, Q. J. R. Meteorol. Soc., 124, 3117–3135.
- Renno, N. O. (1997), Multiple equilibria in radiative-convective atmospheres, -Tellus, Ser. A, 49, 423–438.
- Renno, N. O., K. A. Emanuel, and P. H. Stone (1994), Radiative-convective mode l with an explicit hydrological cycle, Part I: Formulation and sensitivity to model parameters, J. Geophys. Res., 99, 14,429–14,441.
- Sessions, S. L., S. Sugaya, D. J. Raymond, and A. H. Sobel (2010), Multiple equilibria in a cloud-resolving model using the weak temperature gradient approximation, J. Geophys. Res., 115, D12110, doi:10.1029/2009JD013376.
- Sobel, A. H., and C. S. Bretherton (2000), Modeling tropical precipitation in a single column, J. Clim., 13, 4378–4392.
- Sobel, A. H., G. Bellon, and J. T. Bacmeister (2007), Multiple equilibria in a single-column model of the tropical atmosphere, Geophys. Res. Lett., 34, L22804, doi:10.1029/2007GL031320.
- Tobin, I., S. Bony, and R. Roca (2012), Observational evidence for relationships between the degree of aggregationof deep convection, water vapor, surface fluxes, and radiation, J. Clim., 25, 6885–6904.
- Tompkins, A. M. (2001), Organization of tropical convection in low vertical wind shears: The role of water vapor, J. Atmos. Sci., 58, 529–545. Vincent, E. M., G. Madec, M. Lengaigne, J. Vialard, and A. Koch-Larrouy (2012), Influence of tropical cyclones on sea surface temperature seasonal cycle and ocean heat transport, Clim. Dyn., 1–20, doi:10.1007/s00382-012-1556-0.
- Wing, A. A., and K. A. Emanuel (2013), Physical mechanisms controlling self-aggregation of convection in idealized numerical modeling simulations, J. Adv. Model. Earth Sys., 5, doi:1002/2013MS000269, in press.
- Yanai, M., S. Esbensen, and J. H. Chu (1973), Determination of bulk properties of tropical cloud clusters from large-scale heat and moisture budgets, J. Atmos. Sci., 30, 611–627.

#### **Erratum**

In the originally published version of this article (*Emanuel et al.*, 2014), we failed to point out that the radiative-convective equilibrium state is only viable for a particular combination of mean state radiative cooling rates and static stabilities. The correction relaxes this assumption and thereby provides more general results.

In our original article (hereafter referred to as EWV) we argued that the state of radiative-convective equilibrium (RCE) becomes unstable if the infrared opacity of the lower troposphere and the precipitation efficiency of the convection are sufficiently large. This conclusion was based on our interpretation of the results of *Wing and Emanuel* [2014], on experiments with a single-column model run in weak-temperature-gradient mode, and on the linear stability analysis of a two-layer model.

For the linear stability analysis to be valid, the basic state around which the equations are linearized must be a valid, steady solution to the full equations. But we failed to note that this is only so in a special case. Specifically, EWV's equation (19) cannot be satisfied in the RCE state except in the special case that

$$\frac{\overline{\dot{Q}}_1}{S_1} = \frac{\overline{\dot{Q}}_2}{S_2}$$

where  $\overline{Q_1}$  and  $\overline{Q_2}$  are the base state radiative heating rates and  $S_1$  and  $S_2$  are the base state dry static stabilities of the first and second layers, respectively. In this special case, the stability criterion expressed by EWV's equation (30) is valid.

To generalize the stability analysis to arbitrary base state radiative heating rates and static stabilities, we here replace  $\varepsilon_p$  in the second of the two equations (19) with a mass flux multiplier, which we call  $\gamma$ , so that the two equations (19) from the original paper read

$$w_1 = \varepsilon_p M_u + \frac{\dot{Q}_1}{S_1},\tag{1}$$

$$w_2 = \gamma M_u + \frac{\dot{Q}_2}{S_2},\tag{2}$$

where  $\varepsilon_p$  is the precipitation efficiency,  $w_1$  and  $w_2$  are the large-scale vertical velocities in the two layers, and  $M_u$  is the convective updraft mass flux. In the basic state,  $w_1 = w_2 = 0$ , so that (1) and (2) require that

$$\gamma = \varepsilon_p \frac{\overline{\dot{Q}_2} S_1}{\overline{\dot{Q}_1} S_2}.$$
 (3)

Note that  $\gamma$  need not be less than unity; for example, entrainment can increase the net mass flux with altitude. Equation (2) requires that in the mean state,  $\gamma M_2 S_2 = -\dot{Q}_2$ , which replaces the second part of equation (23) of EWV, while their equation (24) becomes  $h_b - \bar{h}_{3/2} = \gamma S_2 H$ . All other mean state equations are unchanged from EWV.

Working through the linearized equations as in the original paper, the first of two criteria for instability becomes

$$\frac{\overline{\dot{Q}}_{1}}{\varepsilon_{1}}\frac{\partial \varepsilon_{1}}{\partial q_{1}} + (1-\gamma)\frac{\overline{\dot{Q}}_{2}}{\varepsilon_{2}}\frac{\partial \varepsilon_{2}}{\partial q_{2}} + \frac{S_{2}}{S_{1}}\frac{\gamma(1-\gamma)}{(1-\varepsilon_{p})}\frac{\sigma\varepsilon_{1}T_{2}^{4}}{\rho_{1}}\frac{\partial \varepsilon_{2}}{\partial q_{2}} + \frac{L_{v}}{2H^{2}}\frac{\alpha F_{s}(\varepsilon_{p}-\gamma)}{(1-\varepsilon_{p})\gamma S_{2}} > 0. \tag{4}$$

Here the primes denote perturbation quantities,  $\varepsilon_1$  and  $\varepsilon_2$  are the emissivities and  $q_1$  and  $q_2$  are the specific humidities of the two layers,  $\sigma$  is the Stefan-Boltzmann constant,  $T_2$  is the (invariant) temperature of the second layer,  $\rho_1$  is the density of the first layer,  $L_v$  is the latent heat of vaporization, H is the layer depth,  $F_s$  is the surface enthalpy flux (which does not vary in our formulation), and  $\alpha$  is given by

$$\alpha \equiv \frac{\overline{\dot{Q}_2}}{\overline{\dot{Q}_1} + \overline{\dot{Q}_2}}.$$

Note that, as expected, if  $\varepsilon_p = \gamma$  then (4) reduces to (30) from EWV. If  $\varepsilon_p > \gamma$  (corresponding to  $\overline{Q_2} S_1 < \overline{Q_1} S_2$ ), the last term contributes to instability, whereas if  $\varepsilon_p < \gamma$  the last term is stabilizing. This last term can be shown to represent the gross moist stability of the base state; when this gross stability is negative, the RCE state may be unstable even if the radiative terms are stabilizing.

The second criterion for instability, corresponding to (32) from EWV, is modified to

$$-(1-\gamma)\frac{\partial \varepsilon_{1}}{\partial q_{1}}\frac{\partial \varepsilon_{2}}{\partial q_{2}}\left[\frac{\sigma^{2}\varepsilon_{1}\varepsilon_{2}}{\rho_{1}\rho_{2}}T_{2}^{4}(T_{s}^{4}-T_{1}^{4})+\frac{\overline{\dot{Q}_{1}\dot{Q}_{2}}}{\varepsilon_{1}\varepsilon_{2}}\right] + \frac{L_{v}}{2H^{2}}\frac{\alpha F_{s}(\varepsilon_{p}-\gamma)}{(1-\varepsilon_{p})\gamma S_{2}}\left[\frac{\sigma\varepsilon_{1}}{\rho_{1}}T_{2}^{4}\frac{\partial\varepsilon_{2}}{\partial q_{2}}-\frac{\overline{\dot{Q}_{1}}}{\varepsilon_{1}}\frac{\partial\varepsilon_{1}}{\partial q_{1}}\right] > 0$$

$$(5)$$

The first term is negative definite, provided c is less than 1, and is the same as (32) from our paper except that c replaces ep. The second term again depends on the gross moist stability and will be positive if the gross moist stability is negative. It is possible that the sum of the two terms can be positive when e<sup>p</sup> > c, and they will be in the limit in which the lower layer's emissivity is unity (and thus no longer depends on its water vapor content). In that case, the two stability criteria, (4) and (5), are equivalent.

Thus the gross moist stability of the base state does influence the two-layer model stability criteria except in the special case c5e<sup>p</sup> treated by EWV. In the usual case in which the gross moist stability is positive, the simple two-layer model can only be destabilized by the interaction of longwave radiation with water vapor, as in EWV, and the positive radiative feedbacks must be sufficient to overcome the gross moist stability in that case. Thus the conclusions of EWV are qualitatively valid when the gross moist stability is positive but must be modified to allow for the case when it is negative.

### References

Emanuel, K., A. A. Wing, and E. M. Vincent (2014), Radiative-convective instability, J. Adv. Model. Earth Sys., 5, 1–14, doi:[10.1002/](http://dx.doi.org/10.1002/2013MS000269) [2013MS000269](http://dx.doi.org/10.1002/2013MS000269).

Wing, A. A., and K. A. Emanuel (2014), Physical mechanisms controlling self-aggregation of convection in idealized numerical modeling simulations, J. Adv. Model. Earth Sys., 6, 75–90, doi[:10.1002/2013MS000270.](http://dx.doi.org/10.1002/2013MS000270)