## **A coarsening model for self-organization of tropical convection**

G. C. Craig1 and J. M. Mack<sup>1</sup>

Received 12 February 2013; revised 23 June 2013; accepted 18 July 2013; published 20 August 2013.

[1] If the influence of humidity on cumulus convection causes moist regions of the tropical troposphere to become moister and dry regions to become drier, and if horizontal mixing of moisture is not rapid enough to overcome this tendency, then the atmosphere will tend to separate into increasingly large moist and dry regions through a process of coarsening. We present a simple model for the moisture budget of the free troposphere, including subsidence drying, convective moistening, and horizontal mixing, and a constraint on total precipitation representing radiative-convective equilibrium. When initialized with a spatially uncorrelated moisture distribution, the model shows self-organization of precipitation with two main stages: A coarsening stage where the correlation length grows proportional to time to the power 1/2 and a droplet stage where precipitation is confined to a decreasing number of circular moist regions. A potential function is introduced to characterize the tendency for self-organization, which could be a useful diagnostic for analyzing cloud-resolving model simulations.

**Citation:** Craig, G. C., and J. M. Mack (2013), A coarsening model for self-organization of tropical convection, *J. Geophys. Res. Atmos.*, *118*, 8761–8769, doi:10.1002/jgrd.50674.

## **1. Introduction**

#### **1.1. Moisture Feedback and Convective Organization**

- [2] Tropospheric humidity has an important influence on precipitation in the tropics [*[Derbyshire et al.](#page-8-1)*, [2004;](#page-8-1) *[Parsons et al.](#page-8-2)*, [2000;](#page-8-2) *[Redelsperger et al.](#page-8-3)*, [2002\]](#page-8-3). Precipitation rates correlate strongly, and nonlinearly, with total column humidity [*[Bretherton et al.](#page-8-4)*, [2004,](#page-8-4) [2005;](#page-8-5) *Peters and Neelin*, [2006;](#page-8-6) *[Holloway and Neelin](#page-8-7)*, [2009;](#page-8-7) *[Yano et al.](#page-8-8)*, [2012\]](#page-8-8). Similarly good correlations are found between precipitation rate and humidity in the lower troposphere above the boundary layer [*[Neelin et al.](#page-8-9)*, 2009], suggesting that entrainment of environmental air by cumulus updrafts may be an important mechanism.
- [3] Early numerical simulations of radiative-convective equilibrium in cloud-resolving models showed a tendency for convection to spontaneously aggregate, leaving a large fraction of the domain increasingly dry as tropospheric subsidence removed moisture unopposed by a local convective moisture source [*[Held et al.](#page-8-10)*, 1993; *Tompkins and Craig*, 1998; *[Tompkins](#page-8-12)*[,](#page-8-11) [2001\].](#page-8-11) [Recent](#page-8-11) [studies](#page-8-11) have explored this phenomenon in larger domain simulations and document a systematic upscale growth of moist and dry regions, with precipitation confined to the moist part of the domain [*[Bretherton et al.](#page-8-5)*, 2005; *[Posselt et al.](#page-8-13)*, 2012; *Muller and Held*, 2012[\].](#page-8-14) [The](#page-8-14) [occurrence](#page-8-14) [of](#page-8-14) [self-organizatio](#page-8-14)n depends,

©2013. American Geophysical Union. All Rights Reserved. 2169-897X/13/10.1002/jgrd.50674

- however, on a number of details of the model setup, including domain size, sea surface temperature, and feedbacks in radiation and surface fluxes. The behavior is also influenced by model resolution [*[Muller and Held](#page-8-14)*, 2012] and the use of a cumulus parameterization [*[Popke et al.](#page-8-15)*, 2013].
- [4] Several mechanisms, or contributing processes, for this self-organization of convection have been proposed (reviewed by *[Muller and Held](#page-8-14)* [2012]). The idea to be considered in this work is based on the moisture budget of the tropical troposphere. As shown by *[Yanai et al.](#page-8-16)* [1973], the effective moisture source due to cumulus convection has two components: moistening by detrainment and drying by compensating subsidence. Temperature anomalies are spread rapidly in the horizontal by radiation of gravity waves [*[Bretherton and Smolarkiewicz](#page-8-17)*, 1989; *Cohen and Craig*, 2004] so that the subsidence rate is relatively uniform in space. Indeed, in radiative-convective equilibrium, subsidence warming must balance radiative cooling outside of the clouds. In contrast, detrained moisture can only be transported by advection, a much slower process, and the moisture field is highly variable. Moist regions are favorable for subsequent convective clouds, as noted above, enabling a feedback process in which the moist regions continue to become moister through detrainment from successive generations of cumulus clouds. Meanwhile, the dry areas are unfavorable for convective clouds but continue to dry due to subsidence associated with remote convection.
- [5] Consistent with this picture, simulations of a subregion of the tropical atmosphere, coupled to a mean radiativeconvective equilibrium state through the weak temperature gradient approximation, show multiple equilibria for a wide range of parameter choices, settling into either a moist or a dry state depending on initial conditions [*Sessions et al.*,

<sup>1</sup>Meteorologisches Institut, Ludwig-Maximilians-Universität, Munich, Germany.

Corresponding author: G. C. Craig, Meteorologisches Institut, Ludwig-Maximilians-Universität, Theresienstr. 37, 80333 Munich, Germany. (george.craig@lmu.de)

2010; *Bony et al.*, 2013]. Further corroboration comes from the observation that although the temperature varies little across the tropics and subtropics, the humidity frequency distribution is bimodal, with a distinct moist peak associated with air located near to convective systems [*Luo et al.*, 2012; *Zhang et al.*, 2003].

#### <span id="page-1-2"></span>1.2. Phase Separation and Coarsening

- [6] An atmosphere governed by a feedback process that leads to dry regions becoming drier and moist regions moister is an example of a bistable system, since each location tends toward one of two phases, depending on its initial conditions. In a spatially extended bistable system that allows some mixing between regions of different phases, the regions will grow in size over time, through a process called coarsening [Bray, 1994; Sethna, 2006]. In a familiar example, water vapor cooled below its critical temperature separates into drops of liquid water surrounded by vapor of low density. The saturation vapor pressure over the highly curved surfaces of the smaller drops is greater than for larger drops, and water vapor will evaporate from the small drops until the ambient humidity is supersaturated for the larger drops and condensation occurs. Larger drops therefore grow at the expense of smaller droplets until eventually the system has separated into two regions containing liquid and gas, respectively.
- [7] A simple mathematical model of coarsening is given by the Allen-Cahn equation [Allen and Cahn, 1979]:

<span id="page-1-3"></span>
$$\frac{\partial I}{\partial t} = -\frac{\delta V}{\delta I} + \nu \nabla^2 I,\tag{1}$$

where I is the order parameter, for example tropospheric humidity,  $\nu$  is a diffusion constant, V[I] is a potential function, sometimes referred to as the Landau free energy, and  $\delta/\delta I$  denotes a functional derivative. A phase transition occurs when the parameters of the system result in V having two minima, rather than one, leading to a bistable system with two equilibrium values of I. The coarsening process is characterized by dynamical scaling where the structures grow in a self-similar manner and the correlation length increases with time according to a power law. For the Allen-Cahn equation, with diffusive mixing and a nonconserved order parameter, the length scale increases proportional to  $t^{1/2}$ . Other models, with conserved order parameter, or transport by hydrodynamic flow, show other scaling exponents [Bray, 2003].

[8] In this paper, we advance the hypothesis that a feedback process in the troposphere that leads to dry regions becoming drier and moist regions moister will inevitably produce organization on increasingly larger scales through coarsening. Section 2 introduces a simplified budget equation for the humidity of the tropical troposphere representing the moisture feedback process. Numerical simulations using the simplified model are presented in section 3 to illustrate the coarsening process and identify the key sensitivities of the model. The results will be compared in more detail to previously published theoretical work in section 4.1, and possible links to cloud-resolving model simulations are discussed in section 4.2.

# <span id="page-1-0"></span>2. A Minimal Model of the Tropospheric Moisture Budget

- [9] Consider a region of the troposphere in radiative-convective equilibrium, with convection driven by radiative cooling over a sea surface of uniform temperature. Above the boundary layer, the radiative cooling is balanced by latent heat release and therefore provides a constraint on the precipitation rate. However, temperature is homogenized in the horizontal by gravity waves on a time scale of a few hours (as in the weak temperature gradient approximation [Sobel and Bretherton, 2000]). This is fast compared to the organization that we hope to explain, which occurs over many days. As a result, radiative cooling determines the spatial mean precipitation rate, but has little effect on the spatial distribution of convection.
- [10] The central assumption of the present model is that the location of convection is determined by the moisture content of the lower troposphere. This is not expected to be homogeneous in the way that temperature is, since moisture must be advected; it cannot be transported by wave propagation. We construct a minimal model based on the heat and moisture budget valid for temporal scales of days or more, where temperature can be considered to be horizontally homogeneous, on spatial scales of several tens of kilometers or more, where local variability associated with individual convective updrafts can be ignored.
- [11] In addition to assuming that the temperature is horizontally uniform, feedbacks of cloud and water vapor amount on the radiation field will be ignored. While such feedbacks are not necessary for self-organization in this model, it will be argued in section 4.2 that they would make it more likely.
- [12] The rate of cooling of the domain by radiation  $\dot{\theta}_R$  will then be constant in time. Ignoring sensible heat transport, the radiative loss of heat must be balanced by release of latent heat, so that the precipitation rate averaged over the domain of area A is also constant in time:

<span id="page-1-1"></span>
$$P_{av} = \frac{1}{A} \int PdA = \frac{c_p}{L_v} \int_{z_p}^{z_T} \dot{\theta}_R \left(\frac{p}{p_o}\right)^{\frac{R}{c_p}} \rho dz. \tag{2}$$

In this equation, the radiative cooling rate is integrated from the top of the subcloud layer  $z_B$  to tropopause height  $z_T$ , since this is the region where it is balanced by latent heat release in a steady state [Takahashi, 2009; Betts and Ridgway, 1989]. Other symbols are the density  $\rho$ , latent heat of condensation  $L_v$ , heat capacity of air at constant pressure  $c_p$ , gas constant for dry air R, and a reference pressure  $p_o$ .

[13] The central equation for our model describes the vertically integrated moisture content  $I_{\nu}$  of the free troposphere:

$$I_{\nu} = \int_{z_R}^{z_T} \rho_{\nu} dz,\tag{3}$$

where  $\rho_{\nu}$  is the density of water vapor. Other studies have considered budget equations for the whole column, including boundary layer [Bretherton et al., 2005; Muller and Held, 2012]. Such a formulation requires explicit terms for surface fluxes and horizontal transports of moisture in the subcloud layer which are not essential for the feedback between precipitation and humidity we wish to represent.

[14] The moisture content in a column is influenced by three processes: (1) subsidence drying driven by radiative cooling, a moisture sink into the subcloud layer, (2) convective moistening, a moisture source by transport from the subcloud layer, and (3) horizontal transport, either source or sink, depending on the moisture content of adjacent columns.

[15] The budget equation for  $I_{\nu}$  can be written schematically as

<span id="page-2-4"></span>
$$\frac{\partial I_{\nu}}{\partial t} = S + C + T,\tag{4}$$

where S represents subsidence drying, C convective moistening and T horizontal transport.

#### 2.1. Subsidence Drying

[16] The rate of change of humidity due to subsidence is assumed to take the form

$$\left(\frac{\partial \rho_{\nu}}{\partial t}\right)_{\text{sub}} = -w \frac{\partial \rho_{\nu}}{\partial z},\tag{5}$$

where w is a subsidence velocity related to the radiative cooling rate by  $\dot{\theta}_R = -w\partial\theta/\partial z$ . For simplicity, w is assumed to be constant between cloud base and top. Furthermore, if the water vapor is distributed exponentially in the vertical with a scale height  $H_{\nu}$ , the drying rate becomes simply

$$\left(\frac{\partial \rho_{\nu}}{\partial t}\right)_{v,t} = -w\frac{\partial}{\partial z}\left(\rho_{0}e^{-z/H_{\nu}}\right) = \frac{w}{H_{\nu}}\rho_{\nu}.$$
 (6)

Integrating in the vertical gives

<span id="page-2-5"></span>
$$S = -\alpha I_{v}, \tag{7}$$

where  $\alpha = -w/H_{\nu}$ . Typical values for w and  $H_{\nu}$  could be  $-0.01~{\rm ms}^{-1}$  and 2 km, respectively, leading to  $\alpha = 5.0 \times 10^{-6}~{\rm s}^{-1}$ . Note that the rate of drying increases linearly with  $I_{\nu}$ .

#### 2.2. Convective Moistening

[17] The major source of moisture in the troposphere is detrainment from convective clouds. To represent the feedback of humidity on the moisture source term, we must express the moistening rate C as a function of  $I_{\nu}$ ; however, we lack direct evidence of what this relationship should be. Instead, we make use of the relationship between precipitation rate P and  $I_{\nu}$ . The fraction of the moisture transported up from the subcloud layer that falls out as precipitation is denoted by the precipitation efficiency  $\epsilon$ , so that

<span id="page-2-1"></span>
$$\epsilon(P+C)=P. \tag{8}$$

Observational and numerical evidence suggests that the precipitation rate increases with increasing  $I_{\nu}$  and furthermore that this increase is substantially faster than linear [Bretherton et al., 2004, 2005; Peters and Neelin, 2006; Holloway and Neelin, 2009; Yano et al., 2012]. Here we choose an exponential fit for the precipitation rate,  $P\left(\text{kg m}^{-2}\text{day}^{-1}\right) = \exp\left(b\left(\frac{I_{\nu}}{I_{\nu}^{*}} - 0.522\right)\right)$  with the scaling parameter b = 11.4 and the saturation integrated water  $I_{\nu}^{*} = 57 \text{ kg m}^{-2}$ , following Bretherton et al. [2004, 2005]. To ensure that no precipitation will occur in a completely dry atmosphere, this relation will be modified to

<span id="page-2-0"></span>
$$P = a \left( e^{b \frac{l_v}{l_v^{\#}}} - 1 \right), \tag{9}$$

which produces a significant change only for  $I_{\nu} \approx 0$ , where the relation was not experimentally verified. The factor a in (9) will be determined at each time step by the constraint that the total amount of precipitation averaged over the area A of the domain is constant. Equation (2) gives

<span id="page-2-3"></span>
$$a(t) = \frac{P_{av}}{\frac{1}{A} \int \left( e^{b\frac{I_v}{I_v^*}} - 1 \right) dA}.$$
 (10)

A reasonable estimate for the constant  $P_{av}$  in radiative-convective equilibrium is 8 kg m<sup>-2</sup> day<sup>-1</sup> [Tompkins and Craig, 1998].

[18] The precipitation efficiency  $\epsilon$  should be an increasing function of  $I_{\nu}$ , since there will be more evaporation of cloud water and less precipitation reaching the ground in a dry environment. Here we make the simple choice

<span id="page-2-2"></span>
$$\epsilon = \beta \frac{I_{\nu}}{I^*},\tag{11}$$

where  $\beta$  has a value slightly larger than one (e.g., 1.1). The precipitation efficiency thus varies from zero for a completely dry layer to a value of  $\beta$  when the layer is saturated, reflecting observations of a net drying tendency when the air is very moist [Raymond et al., 2009]. Together, (8), (9), and (11) give the following expression for C:

<span id="page-2-6"></span>
$$C = a \left( \frac{1}{\beta \frac{I_v}{I_r^{**}}} - 1 \right) \left( e^{b \frac{I_v}{I_r^{**}}} - 1 \right), \tag{12}$$

21698996, 2013, 16, Downloaded from https://agupubs.onlinelibrary.wiley.com/doi/10.1002/gtd.50674 by Tsinghau University Library, Wiley Online Library on [2410/2025]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-ad-conditions) on Wiley Online Library for rules of uses; OA articles are governed by the applicable Cretaive Commons Licenses

where a is determined by the condition (10) above.

[19] A number of assumptions have gone into this equation that should be investigated in more detail using observations and high resolution cloud simulations. However, the precise functional form of  $C(I_{\nu})$  is not critical. As explained in section 1.2, a necessary condition for upscale growth by coarsening is a bistable system, i.e., drying must overcome moistening for small  $I_{\nu}$ , while moistening is stronger for large  $I_{\nu}$ . Since subsidence drying S increases linearly with  $I_{\nu}$ , this implies C must have faster than linear growth with  $I_{\nu}$ . The relative magnitudes of S and C are influenced by a number of model parameters. Some of these dependencies are discussed in section 4.2 to explain why self-organization is seen in some cumulus ensemble simulations, but not in others.

#### 2.3. Horizontal Transport

[20] Advection transports moisture to and from neighboring columns and is thus related to the horizontal gradient of  $I_{\nu}$ . For simplicity, the advective motions will be assumed random and will be represented as a down-gradient diffusive flux:

<span id="page-2-7"></span>
$$T = -v_h \cdot \nabla_h I_v \sim K \nabla^2 I_v, \tag{13}$$

where the eddy diffusivity  $K \sim v_0 L$ , and  $v_0$  and L are horizontal velocity and length scales associated with convective motions. Choosing typical values of  $v_0 = 10 \text{ ms}^{-1}$  and L = 10 km leads to  $K = 10^5 \text{ m}^2 \text{s}^{-1}$ . Modeling advective transport as a diffusion is not appropriate if the velocity is strongly correlated with the moisture field, for example a strong midtropospheric divergence out of the convecting region [Muller and Held, 2012]. The potential influence of such a flow on the organization process will be discussed in section 4.2.

#### CRAIG AND MACK: SELF-ORGANIZATION OF CONVECTION

![](_page_3_Figure_2.jpeg)

<span id="page-3-1"></span>**Figure 1.** Horizontal distribution of  $I_{\nu}/I_{\nu}^*$  after (a) 1, (b) 2, (c) 3, (d) 4, (e) 8, and (f) 50 days. Note the changed color scale in Figures 1e and 1f.

#### 2.4. Summary and Numerical Implementation

[21] The results of this section provide an explicit model for the time evolution of the integrated moisture content,  $I_{\nu}$ , which can be simulated for a two-dimensional region.

[22] Combining (4), (7), (12), and (13), the budget equation for  $I_{\nu}$  can be written as

<span id="page-3-2"></span>
$$\frac{\partial I_{\nu}}{\partial t} = -\alpha I_{\nu} + a(t) \left( \frac{1}{\beta \frac{I_{\nu}}{I^*}} - 1 \right) \left( e^{b \frac{I_{\nu}}{I^*_{\nu}}} - 1 \right) + K \nabla^2 I_{\nu}$$
 (14)

with a(t) given by (10).

[23] Bretherton et al. [2005] initialized their numerical simulations using spatially homogenous temperature and humidity distributions in radiative-convective equilibrium, perturbed with low-amplitude noise. The corresponding, unperturbed, initial moisture distribution for our model is given by the spatially homogenous and steady state solution of equation (14), i.e.,  $I_{\nu}^{h}(x, y; t) = I_{\nu}^{h}(t)$  and  $\partial_{t}I(t)_{\nu}^{h} = 0$ . The calculation of  $I_{\nu}^{h}$  is straightforward and results in

$$I_{v}^{h} = \frac{P_{av}}{2\alpha} \left( \sqrt{1 + \frac{4\alpha}{\beta P_{av}}} - 1 \right). \tag{15}$$

With the typical parameter values listed above, the equilibrium solution is  $I_{\nu}^{h} = 0.40 \cdot I_{\nu}^{*}$ . The simulations shown here will be initialized with the equilibrium humidity value  $I_{\nu}^{h}$ , perturbed with spatially uncorrelated noise drawn from a uniform distribution with amplitude  $\pm 5\%$  of  $I_{\nu}^{h}$ .

[24] The time evolution of equation (14) is calculated numerically for a two-dimensional domain using second-order finite differences in space and a fourth-order Runge-Kutta method in time. Results will be shown for 50 day simulations on a doubly periodic domain containing  $200 \times 200$  grid cells, each representing an area of  $40 \text{km} \times 40 \text{km}$ .

#### <span id="page-3-0"></span>3. Simulation Results

#### 3.1. Stages of Self-Organization

[25] Figure 1 shows snapshots of the horizontal distribution of the integrated moisture content normalized by its saturation value, daily for days 1 to 4, and at days 8 and 50, for a representative simulation of (14). An upscale growth of moist and dry features with time is clearly visible, but closer examination shows that three types of spatial patterns occur at different stages of the simulation.

#### CRAIG AND MACK: SELF-ORGANIZATION OF CONVECTION

![](_page_4_Figure_2.jpeg)

<span id="page-4-0"></span>**Figure 2.** Time evolution of the frequency of the integrated water content values for (a)  $I_{\nu}^* = 57 \text{kg m}^{-2}$  and (b)  $I_{\nu}^* = 3 \text{kg m}^{-2}$ .

[26] The moisture distribution is initialized as uncorrelated noise (not shown). However, the strong spatial gradients between adjacent grid boxes are rapidly removed by diffusion. After the first day of simulation (Figure 1a), the moisture field is smoother and the range of values is much smaller. We will refer to this period as the *diffusive stage*.

[27] The second stage is characterized by the emergence of large-scale features by merging of smaller features with comparable moisture content. By day 4, a further growth of length scale can be seen and the range of moisture values present in the domain has broadened (Figure 1d). This is the *coarsening stage*, and further justification for the name will be given below.

[28] The moisture distribution after 8 days (Figure 1e) looks very different to those at earlier times, with a small number of very moist regions of almost circular shape, lying isolated in a relatively dry background. Gradually, the smaller moist regions shrink, while the largest grows, and by day 50 only the largest moist region remains (Figure 1f). We call this the *droplet stage*, since it is reminiscent of the evolution of water droplets competing for water during condensation within warm clouds or cloud chambers. Comparing the moisture distributions at day 8 and day 50, it can be seen that the drying is slower than the moistening as the small moist patches have at day 8 already reached the final maximum moisture content of  $I_{\nu} \approx 0.90 \cdot I_{\nu}^*$ , whereas the dry regions become still drier.

[29] The upscale growth, followed by the emergence of a very moist circular region is comparable to the results obtained by *Bretherton et al.* [2005] for the evolution of the column-averaged moisture content in a cloud-resolving model. One obvious difference is the lack of small-scale variability in the present model, which is ubiquitous in the cloud-resolving models on the scale of individual convective cells. This is expected since the present model was designed to represent a spatially smoothed moisture content that averages out the stochastic variability associated with individual convective cells. A more important difference is that evolution happens about 4 to 5 times faster here. It will be shown later that the duration of the coarsening stage is very sensitive to the choice of model parameters.

#### 3.2. Phase Separation

[30] The three stages of development correspond to different frequency distributions of the integrated water content.

Figure 2a shows the time evolution of the frequency of occurrence of integrated water content  $I_{\nu}/I_{\nu}^*$  for the simulation in Figure 1, and the emergence of moist and dry peaks in the distribution is visible around day 4. For comparison, the corresponding diagram for a simulation where the parameter  $I_{\nu}^*$  was reduced to 3 kg m<sup>-2</sup> is shown in Figure 2b. As discussed in section 3.3, this is below the critical value for self-organization to occur and it can be seen that the distribution remains unimodal throughout the simulation.

[31] During the first day, the distribution in both simulations evolves from the initial broad structure to a narrowly peaked form. This is consistent with the low spread of  $I_{\nu}$  values noted for Figure 1a in the previous section. The narrowing of the distribution suggests that the disappearance of the smallest spatial-scale features by day 1 can be explained by a simple diffusion which reduces the extreme values of  $I_{\nu}$  in neighboring moist and dry regions. In the subcritical simulation, this process continues until  $I_{\nu}$  equals its equilibrium value throughout the domain (Figure 2b).

[32] During the coarsening stage between days 1 and 4, the distribution broadens, and after day 4, a rapid moistening of a small number of grid cells can be observed. The broadening of the distribution, corresponding to increasingly intense maximum and minimum values, is a sign that the moistening and drying processes are overwhelming the diffusive smoothing, which is dominant only within the narrow boundaries between the moist and dry regions (Figures 1c and 1d).

[33] At day 5, a second peak of moist values appears at  $I_{\nu}/I_{\nu}^* \sim 0.9$ , corresponding to the moist "droplets" in Figures 1d–1f. The appearance of a two-peaked distribution marks the transition to the droplet stage, and the grid cells corresponding to the moist peak are those which lie in the center of the moist regions. From about day 8 onward, the moist peak changes little, while the continued drying tendency shifts the dry peak further toward  $I_{\nu}/I_{\nu}^* \sim 0.0$ .

[34] Close examination of Figure 2a reveals a rather complex behavior for the intermediate moisture values during the droplet phase. We do not investigate this behavior in detail but note that the disappearance of a droplet leads to a significant decrease in the number of grid cells with intermediate moisture content as it reduces the total length of the boundary.

![](_page_5_Figure_2.jpeg)

<span id="page-5-2"></span>**Figure 3.** Potential  $V[I_{\nu}/I_{\nu}^{*}]$  calculated using (16) at selected times during the simulation. Thin solid line shows the V=0 line.

#### <span id="page-5-0"></span>3.3. Potential

[35] In order to explain some of the behavior described above, we now analyze the potential  $V[I_v]$  as defined by (1) and (4):

<span id="page-5-1"></span>
$$V[I_{\nu}] = \int_{0}^{I_{\nu}} -\alpha I_{\nu} + a(t) \left(\frac{1}{\beta \frac{I_{\nu}}{I_{\nu}^{*}}} - 1\right) (e^{b \frac{I_{\nu}}{I_{\nu}^{*}}} - 1) dI_{\nu}.$$
 (16)

It is important to note that parameter a, and therefore  $V[I_{\nu}]$ , is time dependent, so that the shape of the potential evolves throughout the simulation. To compute the potential, a is determined from (10) and the integral in (16) is performed numerically. The resulting function is shown in Figure 3 for several different times, corresponding to the initial state and the three final panels of Figure 1.

[36] For all times, the potential has a double-well (bistable) form with minima at  $I_{\nu}=0$  and  $I_{\nu}\approx 0.9 \cdot I_{\nu}^*$ . As the subsidence term in the present model is linear in  $I_{\nu}$ , but the convective term increases faster than linear with  $I_{\nu}$ , the moisture tendency will cross zero corresponding to a maximum in V. The gradient of the potential determines the rate of moistening or drying. The potential is initially very asymmetric due to the exponential dependence of V on  $I_{\nu}$ , with the depth of the minimum at  $I_{\nu}/I_{\nu}^*\approx 0.9$ . This asymmetry, though much reduced, persists for all times.

[37] The shape of the potential remains almost constant for the first 4 days, relaxes rapidly to a less asymmetric shape between days 4 and 8, and is then nearly constant for the remaining time (Figure 3). Equation (10) shows that a(t) is determined by the relative frequency of moist and dry  $I_{\nu}$  values, and the transition in the shape of the potential corresponds to the emergence of the moist and dry maxima in Figure 2a. The relaxation to a less extreme double-well potential between days 4 and 8 is associated with a decrease

in a, resulting from the increasing number of very moist grid cells which overcomes the effect of the general drying tendency. Day 8, when the potential reaches its final form, can be identified with the transition to the droplet stage described above.

[38] At the initial time, the  $I_{\nu}$  values are confined to a narrow range centered around a local extremum of the potential, here the local maximum, given by  $I_{\nu}^{h}/I_{\nu}^{*}=0.40$ . As the gradient of the potential is small close to an extremum, the tendency at a given location to evolve toward the moist or dry minimum is also small. As a result, diffusion from neighboring locations can dominate at early times, as seen in Figure 2a. However, the impact of diffusion decreases in time as the horizontal gradients are reduced; during the coarsening phase, the spread of  $I_{\nu}$  values broadens as the moist values become moister and the dry values drier. The increasing steepness of the potential for higher values of  $I_{\nu}$  implies that the moistening rate of the moistest values will increase with time, as observed between days 3 and 4 in Figures 1c, 1d, and 2a.

[39] The shape of the potential furthermore determines the stability of the initial state  $I_{\nu}^h$ , which is whether small perturbations about the extremum in V will return to the equilibrium value or grow in time. Performing a linear stability analysis for a generic reaction-diffusion equation, as for example outlined in *Cross and Greenside* [2009], shows that a local minimum at the base state, i.e.,  $\delta_{I_{\nu}}^2 V[I_{\nu}^h] > 0$ , corresponds to a stable homogeneous state  $I_{\nu}^h$  whereas a local maximum,  $\delta_{I_{\nu}}^2 V[I_{\nu}^h] < 0$ , corresponds to an unstable state. Which of these situations occurs is influenced by the values of the parameters that appear in V. A critical parameter value, i.e., a parameter value at which the stability changes, is therefore given by the value for which  $\delta_I^2 V[I_{\nu}^h] = 0$ .

[40] Using this criterion, the critical values for the five parameters appearing in (16) have been determined numerically and the results are listed in Table 1. In computing the critical value of a given parameter, the other four parameters were kept constant at their standard values. It should be noted that changes to w,  $P_{tot}$ , and  $I_{\nu}^*$  are equivalent in determining criticality since they directly scale the ratio between the subsidence drying and convective moistening terms. The two simulations shown in Figure 2 correspond to values of  $I_{\nu}^*$  above and below the critical value of  $I_{\nu}^* = 3.28 \text{ kg m}^{-2}$ .

#### 3.4. Dynamical Scaling

[41] One of the most striking characteristics of coarsening is dynamical self-similarity, where the spatial scale of structures grows according to a power law in time, which for many systems has the universal form  $t^{1/2}$  as described in section 1.2. The dependence of length scale with time will now be examined by considering the spatial autocorrelation length,  $l_{cor}$ , at successive times during the simulation. Due to the random initial conditions, we average over 100 realizations. This is plotted in Figure 4 for a range of values of the parameter b, which determines the rate of

<span id="page-5-3"></span>**Table 1.** Critical Parameter Values

| Parameter               | $w[m h^{-1}]$ | $P_{tot}[\text{mm d}^{-1}]$ | $I_v^*[\text{kg m}^{-2}]$ | <i>b</i> [ ] | β[]  |
|-------------------------|---------------|-----------------------------|---------------------------|--------------|------|
| Critical value          | 2.07          | 138.93                      | 3.28                      | 6.41         | 2.04 |
| Standard value          | 36.00         | 8.00                        | 57.00                     | 11.4         | 1.10 |
| Critical/standard value | 0.06          | 17.37                       | 0.06                      | 0.56         | 1.85 |

![](_page_6_Figure_2.jpeg)

<span id="page-6-1"></span>**Figure 4.** Spatial autocorrelation length of *Iv* as function of time for different values of parameter *b* (see equation [\(9\)](#page-2-0)). Initially, the symbols overlap as the scaling for all parameter follows closely a *t* 1/2 dependence (dashed line).

increase of the convective moistening rate with increasing *Iv* (equation [\(12\)](#page-2-6)).

[42] Figure [4](#page-6-1) indicates that the scaling exhibits a powerlaw dependence with an exponent of 0.5 during the coarsening stage. The transition time to the droplet stage is marked by the departure from this simple power law to a notably weaker time dependence. This corresponds to the weaker gradient of *V* in the droplet phase associated with the shallower depth of the moist minimum (Figure [2\)](#page-4-0). The growth of *l*cor during the droplet stage is not described by a single power law but depends on the chosen value for *b*. While the results for *b* = 14.0 and *b* = 16.0 suggest that a stationary value is reached after about 20 days, for *b* = 11.4 (the value used in all previous simulations), 50 days are required. For *b* = 10.0, a stationary value has not been achieved by the end of the simulation at 100 days, although the growth rate must eventually go to zero due to the finite size of the domain.

[43] The time of transition from *t* 1/2 scaling to slower growth is also a function of *b*. Smaller values of *b* imply a smaller gradient of the potential on the moist side of the maximum (see equation [\(3\)](#page-5-2)), so that more time is required for locations to reach the moist minimum and more time is available for the coarsening stage before the nucleation of droplets. The influence of each of the parameters in *V* has been investigated, and in each case the sensitivity was as expected from its influence on the form of the potential. Parameter *b* showed the strongest impact, since it appears in the exponential function in [\(3\)](#page-5-2). The rate of growth of *l*cor is also influenced by the diffusion constant, but this does not change the *t* 1/2 scaling in the coarsening phase. For example, an increase in *K* would shift the line in Figure [4](#page-6-1) upward during the coarsening phase but not change the slope (not shown).

## <span id="page-6-0"></span>**4. Discussion**

#### **4.1. Comparison With Previous Theoretical Models**

[44] The model of tropical tropospheric moisture presented here shows a phase transition as the initial statistically homogeneous moisture distribution separates into a wet and a dry phase. This is associated with a bistable potential, as for the classic Allen-Cahn coarsening model described in section [1.2,](#page-1-2) but unlike that model, the potential varies over time leading to different stages in the evolution. Nevertheless some insights from the Allen-Cahn model seem to apply during the coarsening stage of the present model. These include the need for a bistable potential for upscale growth to occur, allowing critical values of the model parameters to be determined, and the presence of dynamical scaling during the coarsening phase with a *t* 1/2 power law.

[45] In coarsening models, a quantitative description of the upscale growth can be obtained by writing an equation for the movement of a boundary between regions of each phase [*[Sethna](#page-8-23)*, 2006; *Bray*[, 1994\]](#page-8-22). At such a boundary, diffusion competes with the phase separation tendency described by the potential, leading to propagation of the boundary at a rate that depends upon the height of the potential barrier between the two wells (which determines the gradient of the potential in the boundary region), and the curvature of the boundary. For the Allen-Cahn model, the *t* 1/2 scaling law can be derived explicitly. A large diffusion constant also increases the rate of upscale growth and in addition, increases the width of the boundary regions between the two phases. As a result, upscale growth may be prevented in small domains where the diffusive mixing acts over a scale comparable to the domain size. An interesting subject for future work will be to determine whether a similar analysis with similar results can be obtained for the convective self-organization model presented here.

[46] The most obvious difference between our model and the classic Allen-Cahn equation is the presence of the constraint that the area-integrated precipitation is constant in time. This leads to the change in the shape of the potential over time seen in Figure [3.](#page-5-2) Systems with local conservation properties have been extensively studied (see again *[Sethna](#page-8-23)* [2006] and *Bray* [\[1994\]](#page-8-22)), but the global form of the precipitation constraint is unusual. One study that appears to be very relevant, however, is that of *Rubinstein and Sternberg* [1992], who considered the Allen-Cahn equation with the addition of a constraint that the global integral of the order parameter be constant. This would be analogous in the present model to assuming that the area-integrated water content, <sup>R</sup> *IvdA* was conserved rather than the integral of precipitation, a nonlinear function of *Iv*.

[47] Despite the difference in constraint, *Rubinstein and Sternberg* [1992] obtained regimes of behavior that are qualitatively similar to those found here. A coarsening stage was identified, where the spatial length scale increases according to an interface equation that combines the influences of the potential and diffusion terms, with the potential evolving in time as the area-integrated value of the order parameter evolves toward its final value. This was followed by a stage where the domain is separated into regions of the two phases, corresponding to the droplet stage. The total area occupied by each phase remains constant, with the interfaces moving at a speed determined by their curvature (volume-preserving curvature flow). In this stage, the individual regions of the minority phase become spherical in shape and smaller regions shrink and disappear until a single region remains. The rate of upscale growth can depend on the geometry and initial conditions, but it has recently been proven that *t* 1/2 scaling is an upper bound [*Mugnai and Seis*, 2013]. In Figure 4, the growth in the droplet stage is always slower than  $t^{1/2}$  and tends toward zero as the final state of a single droplet is reached.

## <span id="page-7-0"></span>**4.2.** Comparison With Cloud-Resolving Model Simulations

[48] At least in a qualitative sense, the two main phases of the self-organization of the moisture field in the simple model presented here are comparable to cloud-resolving model simulations. In particular, Figures 1 and 2 of *Bretherton et al.* [2005] show an initial separation into moist and dry regions with humidity values that continue to moisten and dry, respectively, as found in the coarsening stage of the current model. Their Figure 3 shows a final droplet-like state with a circular region of very high humidity, very like Figure 1f here.

[49] The details of the self-organization process in the simple coarsening model are determined largely by the structure of the potential function (16). This could provide a useful diagnostic to analyze the sensitivities found in CRM simulations, if indeed self-organization depends on the relative importance of moistening and drying processes at different humidities. An estimate of the potential should show a bistable form for numerical experiments where self-organization occurs, and otherwise not.

[50] In the example shown in Figure 2, self-organization did not occur if the saturation water vapor content  $I_{\nu}^*$  was sufficiently small. A smaller saturation humidity corresponds to cooler atmosphere, which could result, for example from a smaller sea surface temperature (SST). Indeed, the simulations of *Khairoutdinov and Emanuel* [2010] showed that self-aggregation did not occur for SST below a critical value. It is worth noting, however, that the threshold value of  $I_{\nu}^*$  found here (Table 1) is very low and would correspond to an extremely cold SST. This suggests that the shape of the potential in (16) is probably incorrect, especially for small values of  $I_{\nu}/I_{\nu}^*$ , and could be improved with information from CRM simulations.

[51] In another example, *Tompkins and Craig* [1998] found that self-organization did not occur if either the radiative cooling rates or the surface fluxes of heat and moisture were replaced by their horizontally averaged values. Interactive radiation leads to reduced descent and subsidence drying in cloudy regions, and a stronger net moistening relative to cloud-free regions, and is therefore favorable for organization. Homogenized surface fluxes would tend to reduce the preference of convection for moist regions, making a bistable potential less likely. One should be cautious of attributing the organization to any single mechanism, however, since the shape of the potential is a combination of influences and the sensitivity to a single process could be dependent on details of the model and experimental design.

[52] It is possible that numerical experiments using the weak temperature gradient (WTG) approximation might be easier to interpret than the radiative-convective equilibrium configuration explored here. In such experiments, there is no requirement that latent heat release balance radiative cooling within the domain, so a constraint such as (10) is not required. On the one hand, this results in a potential function which is constant over time and on the other hand allows the domain to have a uniform moisture

distribution ( $I_v(x,y) = const.$ ). In this case, rather than showing organization on increasing length scales, the entire model domain could evolve toward the moist or dry potential minimum, depending on which minimum the initial conditions are closer to. Indeed, two equilibrium states, one wet and one dry, have been seen in WTG experiments [Sessions et al., 2010; Bony et al., 2013].

[53] In addition to using an estimate of the potential function as a diagnostic to identify experiments that are prone to self-organization, a second diagnostic is the presence of dynamical scaling and associated scaling exponent. As an example, consider the self-organization shown in Figure 2 of Posselt et al. [2012]. Because of the quasi two-dimensional domain, a quantitative estimate of the scale of the moist and dry regions at any time can be obtained simply by counting them and dividing by the domain size. Plotting this estimate versus time (not shown) suggests that a power-law dependence appears in each of their three experiments, i.e., the scale is proportional to  $t^{\gamma}$ . For the experiment with sea surface temperature 302 K, the resulting  $\gamma$  is approximately 0.44, which is not too far from the standard coarsening result of 0.5. Interestingly, for the two experiments with lower sea surface temperatures,  $\gamma$  takes significantly larger values of 0.74 (300 K) and 0.81 (298 K). Posselt et al. [2012] argue that the most important difference between the 302 K experiment and the other two is that cooler simulations feature a strong midtropospheric stable layer associated with the freezing level, leading to a divergent circulation that systematically transports moisture out of the moist regions into drier areas. Theoretical models of coarsening predict larger exponents when a hydrodynamic streaming flow replaces the random diffusive mixing [Brav, 2003], and it is interesting to speculate that the midlevel divergent flow documented by Posselt et al. [2012] may increase the rate of self-organization by a similar mechanism. Muller and Held [2012] show that a midlevel divergent circulation exporting humidity is necessary for self-organization in their simulations, although not for its maintenance, but do not discuss sensitivities of the rate of organization.

#### 5. Conclusions

[54] A simple model of the tropical tropospheric moisture budget has been introduced and shown to exhibit self-organization of precipitation and moisture through a coarsening process. In a further stage of organization, the histogram of humidity is separated into moist and dry peaks, with the moist values concentrated in space into droplets that eventually evolve to a final state with a single circular moist region. The self-organization seen here is a generic property of local bistable systems with a weak spatial transport process such as diffusion. In the moisture budget, this corresponds to the requirement that dry regions become drier, while moist regions become moister. In (14), this can be seen to result from the linear dependence of subsidence drying on  $I_{\nu}$ , which is relatively large for small moisture contents, in combination with the exponential dependence of convective moistening, which dominates for larger  $I_{\nu}$ . The two stages of organization result from the constraint of radiativeconvective equilibrium, which requires that as the moisture field separates into increasingly moist and dry regions, the fractional area of the moist regions must decrease.

#### CRAIG AND MACK: SELF-ORGANIZATION OF CONVECTION

- <span id="page-8-0"></span>[55] The two stages of organization produced by the simple model correspond to behavior seen in cloud-resolving model experiments [*[Bretherton et al.](#page-8-5)*, 2005; *Muller and Held*, 2012[\].](#page-8-14) [Section](#page-8-14) [4.2](#page-7-0) [gives](#page-8-14) [some](#page-8-14) [examp](#page-8-14)les of how consideration of the potential function provides qualitative explanations of how physical factors such as sea surface temperature and cloud-radiative feedbacks affect the tendency toward self-organization. Some quantitative differences between the simple model behavior and the CRM results are also apparent. In particular, the organization in the coarsening stage happens more rapidly than in the simulations and the critical value of SST is much lower. This suggests that the formulation of the simple model, especially the convective moistening term that was derived in a rather indirect way, could be improved by detailed comparison with the moisture budget in a cloud-resolution model.
- [56] In addition to providing an explanation for the relative roles of various physical factors in promoting selforganization, the simple model also makes the new prediction of dynamical similarity during the upscale growth process. The moisture field can be expected to show a powerlaw dependence of correlation length with time, until a final state is reached that minimizes the global value of the bistable potential.
- [57] **Acknowledgments.** We would like to thank the anonymous reviewers for helpful suggestions regarding the presentation of the results.

### **References**

- <span id="page-8-24"></span>Allen, S., and J. Cahn (1979), A microscopic theory for antiphase boundary motion and its application to antiphase domain coarsening, *Acta Metall.*, *27*(6), 1085–1095, doi:10.1016/0001-6160(79)90196-2.
- <span id="page-8-28"></span>Betts, A. K., and W. Ridgway (1989), Climatic equilibrium of the atmospheric convective boundary layer over a tropical ocean, *J. Atmos. Sci.*, *46*(17), 2621–2641, doi:10.1175/1520-0469(1989)046<2621:CEOTAC> 2.0.CO;2.
- <span id="page-8-19"></span>Bony, S., G. Bellon, D. Klocke, S. Sherwood, S. Fermepin, and S. Denvil (2013), Robust direct effect of carbon dioxide on tropical circulation and regional precipitation, *Nat. Geosci.*, *6*, 447–451, doi:10.1038/ ngeo1799.
- <span id="page-8-22"></span>Bray, A. J. (1994), Theory of phase-ordering kinetics, *Adv. Phys.*, *43*(3), 357–459, doi:10.1080/00018739400101505.
- <span id="page-8-25"></span>Bray, A. J. (2003), Coarsening dynamics of phase-separating systems, *Philos. Trans. Ser. A, Math., Phys., Eng. Sci.*, *361*, 781–792, doi:10.1098/rsta.2002.1164.
- <span id="page-8-17"></span>Bretherton, C. S., and P. K. Smolarkiewicz (1989), Gravity waves, compensating subsidence and detrainment around cumulus clouds, *J. Atmos. Sci.*, *46*(6), 740–759, doi:10.1175/1520-0469(1989)046<0740: GWCSAD>2.0.CO;2.
- <span id="page-8-4"></span>Bretherton, C., M. Peters, and L. Back (2004), Relationships between water vapor path and precipitation over the tropical oceans, *J. Clim.*, *17*(7), 1517–1528, doi:10.1175/1520-0442(2004)017<1517:RBWVPA> 2.0.CO;2.
- <span id="page-8-5"></span>Bretherton, C. S., P. N. Blossey, and M. Khairoutdinov (2005), An energybalance analysis of deep convective self-aggregation above uniform SST, *J. Atmos. Sci.*, *62*(12), 4273–4292, doi:10.1175/JAS3614.1.
- Cohen, B. G., and G. C. Craig (2004), The response time of a convective cloud ensemble to a change in forcing, *Q. J. R. Meteorol. Soc.*, *130*(598), 933–944, doi:10.1256/qj.02.218.
- <span id="page-8-30"></span>Cross, M., and H. Greenside (2009), *Pattern Formation and Dynamics in Nonequilibrium Systems*, 1st ed., 535 pp., Cambridge University Press, Cambridge, UK.
- <span id="page-8-1"></span>Derbyshire, S., I. Beau, P. Bechtold, J.-Y. Grandpeix, J.-M. Piriou, J.-L. Redelsperger, and P. Soares (2004), Sensitivity of moist convection to environmental humidity, *Q. J. R. Meteorol. Soc.*, *130*(604), 3055–3079, doi:10.1256/qj.03.130.
- <span id="page-8-10"></span>Held, I., R. Hemler, and V. Ramaswamy (1993), Radiative-convective equilibrium with explicit two-dimensional moist convection, *J.*

- *Atmos. Sci.*, *50*(23), 3909–3927, doi:10.1175/1520-0469(1993)050< 3909:RCEWET>2.0.CO;2.
- <span id="page-8-7"></span>Holloway, C., and J. D. Neelin (2009), Moisture vertical structure, column water vapor, and tropical deep convection, *J. Atmos. Sci.*, *66*(6), 1665–1683, doi:10.1175/2008JAS2806.1.
- <span id="page-8-32"></span>Khairoutdinov, M. F., and K. E. Emanuel (2010), Aggregated convection and the regulation of tropical climate, Extended Abstracts, 29th Conf. on Hurricanes and Tropical Meteorology, Tucson, AZ, P2.69. [Available online at http://ams.confex.com/ams/29Hurricanes/techprogram/paper\_ 168418.htm.]
- <span id="page-8-20"></span>Luo, Z. J., D. Kley, R. H. Johnson, G. Y. Liu, S. Nawrath, and H. G. J. Smit (2012), Influence of sea surface temperature on humidity and temperature in the outflow of tropical deep convection, *J. Clim.*, *25*(4), 1340–1348, doi:10.1175/2011JCLI4124.1.
- <span id="page-8-31"></span>Mugnai, L., and C. Seis (2013), On the coarsening rates for attachment-limited kinetics, *SIAM J. Math. Anal.*, *45*(1), 324–344, doi:10.1137/120865197.
- <span id="page-8-14"></span>Muller, C. J., and I. M. Held (2012), Detailed investigation of the selfaggregation of convection in cloud-resolving simulations, *J. Atmos. Sci.*, *69*(8), 2551–2565, doi:10.1175/JAS-D-11-0257.1.
- <span id="page-8-9"></span>Neelin, J. D., O. Peters, and K. Hales (2009), The transition to strong convection, *J. Atmos. Sci.*, *66*(8), 2367–2384, doi:10.1175/ 2009JAS2962.1.
- <span id="page-8-2"></span>Parsons, D. B., J.-L. Redelsperger, and K. Yoneyama (2000), The evolution of the tropical western Pacific atmosphere-ocean system following the arrival of a dry intrusion, *Q. J. R. Meteorol. Soc.*, *126*(563), 517–548, doi:10.1002/qj.49712656307.
- <span id="page-8-6"></span>Peters, O., and J. D. Neelin (2006), Critical phenomena in atmospheric precipitation, *Nat. Phys.*, *2*(6), 393–396, doi:10.1038/nphys314.
- <span id="page-8-15"></span>Popke, D., B. Stevens, and A. Voigt (2013), Climate and climate change in a radiative-convective equilibrium version of ECHAM6, *J. Adv. Model. Earth Syst.*, *5*, 1–14, doi:10.1029/2012MS000191.
- <span id="page-8-13"></span>Posselt, D. J., S. V. D. Heever, G. Stephens, and M. R. Igel (2012), Changes in the interaction between tropical convection, radiation, and the largescale circulation in a warming environment, *J. Clim.*, *25*(2), 557–571, doi:10.1175/2011JCLI4167.1.
- <span id="page-8-29"></span>Raymond, D. J., S. L. Sessions, A. H. Sobel, and v. Fuchs (2009), The mechanics of gross moist stability, *J. Adv. Model. Earth Syst.*, *1*(3), doi:10.3894/JAMES.2009.1.9.
- <span id="page-8-3"></span>Redelsperger, J.-L., D. B. Parsons, and F. Guichard (2002), Recovery processes and factors limiting cloud-top height following the arrival of a dry intrusion observed during TOGA COARE, *J. Atmos. Sci.*, *59*(16), 2438–2457, doi:10.1175/1520-0469(2002)059<2438:RPAFLC> 2.0.CO;2.
- Rubinstein, J., and P. Sternberg (1992), Nonlocal reaction-diffusion equations and nucleation, *IMA J. Appl. Math.*, *48*(3), 249–264, doi:10.1093/imamat/48.3.249.
- <span id="page-8-18"></span>Sessions, S. L., S. Sugaya, D. J. Raymond, and A. H. Sobel (2010), Multiple equilibria in a cloud-resolving model using the weak temperature gradient approximation, *J. Geophys. Res.*, *115*, D12110, doi:10.1029/2009JD013376.
- <span id="page-8-23"></span>Sethna, J. P. (2006), *Statistical Mechanics: Entropy, Order Parameters and Complexity (Oxford Master Series in Physics)*, 1st ed., 376 pp., Oxford University Press, New York.
- <span id="page-8-26"></span>Sobel, A. H., and C. S. Bretherton (2000), Modeling tropical precipitation in a single column, *J. Clim.*, *13*(24), 4378–4392, doi:10.1175/1520- 0442(2000)013<4378:MTPIAS>2.0.CO;2.
- <span id="page-8-27"></span>Takahashi, K. (2009), Radiative constraints on the hydrological cycle in an idealized radiative-convective equilibrium model, *J. Atmos. Sci.*, *66*(1), 77–91, doi:10.1175/2008JAS2797.1.
- <span id="page-8-12"></span>Tompkins, A. M. (2001), Organization of tropical convection in low vertical wind shears: The role of water vapor, *J. Atmos. Sci.*, *58*(6), 529–545, doi:10.1175/1520-0469(2001)058<0529:OOTCIL>2.0.CO;2.
- <span id="page-8-11"></span>Tompkins, A. M., and G. C. Craig (1998), Radiative-convective equilibrium in a three-dimensional cloud-ensemble model, *Q. J. R. Meteorol. Soc.*, *124*(550), 2073–2097, doi:10.1002/qj.49712455013.
- <span id="page-8-16"></span>Yanai, M., S. Esbensen, and J. Chu (1973), Determination of bulk properties of tropical cloud clusters from large-scale heat and moisture budgets, *J. Atmos. Sci.*, *30*(4), 611–627, doi:10.1175/1520- 0469(1973)030<0611:DOBPOT>2.0.CO;2.
- <span id="page-8-8"></span>Yano, J.-I., C. Liu, and M. W. Moncrieff (2012), Self-organized criticality and homeostasis in atmospheric convective organization, *J. Atmos. Sci.*, *69*(12), 3449–3462, doi:10.1175/JAS-D-12-069.1.
- <span id="page-8-21"></span>Zhang, C., B. E. Mapes, and B. J. Soden (2003), Bimodality in tropical water vapour, *Q. J. R. Meteorolog. Soc.*, *129*(594), 2847–2866, doi:10.1256/qj.02.166.