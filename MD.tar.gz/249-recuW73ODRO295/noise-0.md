## **An Energy-Balance Analysis of Deep Convective Self-Aggregation above Uniform SST**

## CHRISTOPHER S. BRETHERTON AND PETER N. BLOSSEY

*Department of Atmospheric Sciences, University of Washington, Seattle, Washington*

### MARAT KHAIROUTDINOV

*Department of Atmospheric Sciences, Colorado State University, Fort Collins, Colorado*

(Manuscript received 26 August 2004, in final form 11 April 2005)

#### ABSTRACT

The spatial organization of deep moist convection in radiative–convective equilibrium over a constant sea surface temperature is studied. A 100-day simulation is performed with a three-dimensional cloud-resolving model over a (576 km)2 domain with no ambient rotation and no mean wind. The convection self-aggregates within 10 days into quasi-stationary mesoscale patches of dry, subsiding and moist, rainy air columns. The patches ultimately merge into a single intensely convecting moist patch surrounded by a broad region of very dry subsiding air.

The self-aggregation is analyzed as an instability of a horizontally homogeneous convecting atmosphere driven by convection–water vapor–radiation feedbacks that systematically dry the drier air columns and moisten the moister air columns. Column-integrated heat, water, and moist static energy budgets over (72 km)<sup>2</sup> horizontal blocks show that this instability is primarily initiated by the reduced radiative cooling of air columns in which there is extensive anvil cirrus, augmented by enhanced surface latent and sensible heat fluxes under convectively active regions due to storm-induced gustiness. Mesoscale circulations intensify the later stages of self-aggregation by fluxing moist static energy from the dry to the moist regions. A simple mathematical model of the initial phase of self-aggregation is proposed based on the simulations.

In accordance with this model, the self-aggregation can be suppressed by horizontally homogenizing the radiative cooling or surface fluxes. Lower-tropospheric wind shear leads to slightly slower and less pronounced self-aggregation into bands aligned along the shear vector. Self-aggregation is sensitive to the ice microphysical parameterization, which affects the location and extent of cirrus clouds and their radiative forcing. Self-aggregation is also sensitive to ambient Coriolis parameter *f*, and can induce spontaneous tropical cyclogenesis for large *f*. Inclusion of an interactive mixed-layer ocean slows but does not prevent self-aggregation.

#### **1. Introduction**

Radiative–convective equilibrium (RCE) above a horizontally homogeneous surface, with no ambient rotation or mean pressure gradients, is a time-honored idealization for understanding the tropical atmosphere and its sensitivity to perturbations in radiative or surface forcing, starting with single-column models (e.g., Manabe and Strickler 1964) and moving on to threedimensional (3D) cloud-resolving models (CRMs; e.g., Tompkins and Craig 1998).

*Corresponding author address:* Dr. Christopher S. Bretherton, Dept. of Atmospheric Sciences, University of Washington, Box 351640, Seattle, WA 98195-1640.

E-mail: breth@atmos.washington.edu

It is natural to assume that RCE will be characterized by a quasi-homogeneous pattern of cumulus convection. However, several CRM studies of RCE have suggested otherwise. This finding is important because the spontaneous development of large-scale convective organization (self-aggregation) can profoundly affect the horizontal mean temperature and moisture profiles and the surface and top-of-atmosphere radiative fluxes. Held et al.'s (1993) seminal study of RCE in a broad two-dimensional (2D) domain with no initial winds showed that the 2D convection spontaneously developed vigorous downward-propagating horizontal jets due to countergradient convective momentum transport. If the jets were suppressed by artificially removing any domain-mean horizontal wind, the flow selfaggregated within 10 days into two convective centers, then after 10 more days into just a single narrow stationary region of persistent and vigorous deep convection surrounded by weak subsidence and very dry conditions over the remainder of the domain. Held et al. explained this as a positive feedback between convection and water vapor, in which deep convection can more easily develop where it is already moist in the midtroposphere, and also tends to keep the middle and upper troposphere moist. They showed that addition of modest imposed vertical shear of the domain-averaged horizontal wind in the lower troposphere could prevent self-aggregation by shearing out incipient moisture anomalies.

Tompkins (2001) extended the Held et al. study using a smaller, more appropriate grid spacing and a bowling alley domain with a short (32 grid point) transverse dimension to permit 3D convection. However, the added computational burden limited his simulations to 15 days. His results had both similarities and important differences to Held et al.'s purely 2D simulations. The 3D convection did not induce jets because of convective momentum transport, and so did not require any domain-scale velocity nudging. He again found selfaggregation developing in approximately 10 days, though now in the form of moist precipitating and dry nonprecipitating patches that slowly moved. Unlike in the purely 2D case, the flow did not focus into a single vigorous convective center within the simulated period, but Tompkins also argued that his results were due to a water vapor–convection feedback.

Observations have also suggested the importance of midtropospheric water vapor in organizing marine tropical deep convection. Midtropospheric dry intrusions over the west Pacific ocean can suppress deep convection even in the presence of substantial conditional instability (e.g., Numaguti et al. 1995; Redelsperger et al. 2002). Over the Indian Ocean and west Pacific, the convectively active phase of the Madden– Julian oscillation (MJO) is preceded by a several day period of lower-tropospheric moistening that has been suggested to precondition the atmosphere for deep convection (e.g., Maloney and Hartmann 1998; Wang and Schlesinger 1999; Wheeler et al. 2000). Statistically, a strong correlation is observed over the tropical oceans between convective precipitation and column water vapor on daily and longer time scales (Sherwood and Wahrlich 1999; Raymond 2000; Bretherton et al. 2004). RCE self-aggregation simulations can help us hone our understanding of water vapor–convection interactions and the role of radiative transfer and surface fluxes in mediating these interactions.

In this paper, we take advantage of continuing ad-

vances in computational power and present CRM simulations of self-aggregation in a large square domain using a fully interactive radiation parameterization. We then quantify the feedbacks that lead to self-aggregation in our simulations by considering the columnintegrated moist static energy budget of mesoscale-size blocks, and present a simple mathematical model and some sensitivity studies that elucidate the self-aggregation process.

## **2. Model configuration and diagnosis**

We use version 6.1 of the System for Atmospheric Modeling (SAM), which is an updated version of the Colorado State University Large-Eddy Simulation/ Cloud-Resolving Model (Khairoutdinov and Randall 2003). The model uses the anelastic equations of motion with bulk microphysics. The prognostic thermodynamic variables are the mixing ratio of total nonprecipitating water *q* (composed of water vapor *q* and cloud condensate *qn*, which is partitioned based on temperature *T* between cloud water *ql* and cloud ice *qi* ), total precipitating water *qp* (*T*-partitioned between snow, which has a *T*-dependent fall speed, and rain, which has an intensity-dependent fall speed), and liquid-ice static energy *s*li *cpT gz L*(*q*liq *q*ice) *Lf q*ice, where *cp* is the isobaric specific heat of dry air, *g* is the gravitational acceleration, *L* is the latent heat of vaporization, and *Lf* is the latent heat of freezing, all assumed constant, and *q*liq and *q*ice are the mixing ratios of all liquid and ice phase condensate, respectively. The total water *qt q qp* includes water vapor and all condensed phase hydrometeors.

A Kessler scheme for autoconversion of cloud liquid water to rain is used. Cloud ice is assumed to fall at 0.4 m s<sup>1</sup> and autoconverts to snow at a *T*-dependent rate. In SAM 6.1, an autoconversion threshold of 0.1 g kg<sup>1</sup> for cloud ice to snow is chosen—this is used in a sensitivity study MOREICE, but for all other simulations presented here this autoconversion threshold is set to zero to prevent excessive production of radiatively active thin cirrus.

We use a Smagorinsky-type parameterization for subgrid-scale turbulent fluxes. The surface turbulent fluxes are computed using Monin–Obukhov similarity theory. The longwave and shortwave radiation schemes are taken from the National Center for Atmospheric Research (NCAR) Community Climate Model (CCM3) (Kiehl et al. 1998). The effective radii of cloud water and cloud ice are assumed to be 10 and 10–30 m, respectively, and precipitating water/ice is assumed to be radiatively negligible because of its large effective radius. Similar to Tompkins and Craig (1998), we remove the diurnal cycle by reducing the solar constant to  $650.83~W~m^{-2}$  and fixing the solar zenith angle at  $50.5^{\circ}$ . The readers are referred to Khairoutdinov and Randall (2003) for further details about the model.

We use 64 vertical grid levels with spacing of 75 m near the surface, smoothly increasing to 500 m above 2 km up to the domain top at approximately 28 km. The small vertical grid spacing in the boundary layer allows better resolution of evaporatively driven cold pools generated by deep convection, and of the vertical structure of the boundary layer. In a sponge layer from 19.5 to 28 km, all prognostic variables are relaxed toward their domain-mean values with damping times ranging from 2 h at the sponge bottom to 2 min at the domain top. We use a 576 km  $\times$  576 km doubly periodic domain with horizontal grid spacing of 3 km. This configuration was chosen to allow long simulations on as large a domain as we could efficiently simulate on the Linux cluster used for these computations. A 100-day simulation takes 6 days of computation time on 8 dual-processor 1.8-GHz Opteron nodes.

We specify a sea surface temperature (SST) of 301 K, no ambient rotation, and no initial wind or large-scale pressure gradient. We performed a 50-day RCE simulation on a small domain (SD; 96 km  $\times$  96 km), which is too small to permit noticeable self-aggregation. The horizontal-mean temperature and water vapor profiles averaged over days 30–50 of this simulation are used to initialize the large domain (LD) RCE simulation.

The SD–RCE simulation was identically configured and forced to simulation MOREICE (which used the default SAM6.1 ice microphysics), except for domain size. Although we later decided to remove the autoconversion threshold for cloud ice for our other simulations, we continued to use the above SD–RCE simulation for the initial large-domain sounding for convenience. We have also performed SD–RCE simulations corresponding to all of the LD model configurations discussed in this paper. In all cases, their domain-mean equilibrium soundings are quite similar, varying up to a degree in temperature and 10% in relative humidity.

To initiate convection, white noise is added to the initial  $s_{li}$  field at the five lowest grid levels, with an amplitude of 0.1 K at the lowest level, linearly decreasing to 0.02 K at the fifth level. Drifts of the mean profiles in the LD simulation away from their initial specifications are associated with the self-aggregation process and model physics differences; the former dominates when self-aggregation occurs. In both the SD and LD simulations, but in contrast to the two-dimensional simulations of Held et al. (1993), cumulus momentum transport does not spontaneously create

significant mean vertical shear and the domain-mean wind remains close to zero at all levels at all times.

Simulations identical to the base run presented in this paper except with 2-km horizontal resolution on a 512 km  $\times$  512 km domain gave similar results to the 3 km results presented here in this paper, though self-aggregation took slightly longer to initiate. They will not be discussed further.

#### a. Block averaging

To focus on mesoscale organization, we will make extensive use of block-averaged daily-mean fields. We horizontally partition the computational domain into 64 (72 km)<sup>2</sup> blocks. We horizontally average selected 2D and 3D model outputs over each block. For the 2D output fields, we average the 24 saved hourly average values for a given day to get a numerically exact daily average for each block. For the 3D output fields, we average the four stored 6-hourly instantaneous values per day to get an approximate daily average for each block.

#### b. Moist static energy and vertical averaging

Moist static energy is a useful thermodynamic variable for studying precipitating convection because it is approximately conserved in adiabatic displacements of fluid parcels, and only weakly affected by precipitation and evaporation of liquid water. To be consistent with the thermodynamic formulation of the CRM, we work in terms of a frozen moist static energy (FMSE), which is exactly conserved by the CRM governing equations following adiabatic fluid parcel displacements,

$$h_f = s_{li} + Lq_t = c_p T + gz + Lq_v - L_f q_{lce},$$

which differs from the conventional definition of moist static energy only in that it includes the ice freezing term. From here on, when we refer to moist static energy we will mean FMSE.

We will consider budgets of FMSE and other quantities integrated over the atmospheric column. They will be phrased in terms of mass-weighted vertical integrals, denoted  $I_{\rm hf}, I_{\rm qt}, \ldots$  for FMSE, total water, etc., or mass-weighted vertical averages denoted with angle brackets, for example,  $\langle h_f \rangle = gI_{\rm hf}/p_{\rm surf}$ , where  $p_{\rm surf}$  is the reference surface pressure.

#### 3. Results

Figure 1 shows horizontal maps of water vapor path (WVP), outgoing longwave radiation (OLR), precipitation (P), and total heat flux (THF), defined as the sum of the sensible and latent heat fluxes, with the

![](_page_3_Figure_3.jpeg)

Fig. 1. Horizontal maps of daily-mean WVP, OLR, *P*, and total surface (latent plus sensible) heat flux with surface wind vector superposed at day 10.

surface wind vector superposed, averaged over day 10. Self-aggregation, in the form of a developing dry hole centered at x = 180 km, y = 350 km, is beginning. A slight minimum in WVP is collocated with suppressed precipitation and surface fluxes and larger OLR. By day 20 (Fig. 2), the dry hole greatly amplifies and expands northwestward. During this amplification phase, the WVP pattern mainly amplifies in place, with only slow spatial shifts in the locations of maxima and minima. By day 50 (Fig. 3), the moist convecting region focuses into a single, nearly stationary, quasi-circular patch of intense precipitation and low OLR surrounded by very dry subsiding air with high OLR. Within the core of this region, winds are light and surface humidity very high, so there is a pronounced THF minimum. Strong surface winds associated with low-level convergence into this patch drives large latent heat flux around its periphery. In the subsiding regions, THF is also elevated because of the low boundary layer humidity. Over days 50-100, this organization persists in a near-steady state, with a slowly drifting rainy patch.

Figure 4 shows the horizontally averaged profiles of

relative humidity (left) and moist static energy  $h_f$  and saturation moist static energy  $h_s$  (right) averaged over days 1 and 50. The relative humidity sounding highlights the intense drying by day 50 over most of the domain outside the small region of intense convection. The  $h_s$  sounding shows considerable warming in response to the self-aggregation. This warming is a consequence of the elevated moist adiabat impressed on the entire domain by the very moist, high  $h_f$  lower-tropospheric air in the convective region. The horizontally averaged  $h_f$  decreases in the lower troposphere because of drying, and increases comparably in the upper troposphere because of warming.

#### a. Moisture-sorted time series

Because the dry holes move only slowly as they develop, one can quantify their development by sorting the (72 km)<sup>2</sup> blocks into quartiles by their daily blockaverage WVP, and plotting the time evolution of these quartiles (Fig. 5).

The WVP (Fig. 5a) of the driest quartile decreases almost fourfold in the first 40 days. In the moistest

![](_page_4_Figure_1.jpeg)

FIG. 2. As in Fig. 1, but for day 20.

quartile, WVP increases about 10% over this period. The WVP difference between these quartiles increases from 5 mm at day 10 to 20 mm at day 20, from which one can estimate an *e*-folding time scale of seven days. Because the WVP decreases in the dry regions are much larger than the WVP increases in the moist regions, there is a 30% drop in mean WVP (thick black curve) by day 40. This is one example of how convective self-aggregation profoundly influences the horizontalmean characteristics of the simulated atmosphere. After day 40, the moistest WVP quartile begins to dry because the moist area of active convection has focused into less than a quarter of the domain. Between 45 and 100 days, the WVP quartile structure is quasi-steady except for a slight oscillation with a period of 17 days.

The daily quartile-averaged precipitation (Fig. 5b) tracks the quartile-average WVP trends, but shows more daily variability about the trends. After day 20, there is no precipitation in the driest quartile, as the convection becomes increasingly focused into the moistest region. The strong relation between precipitation and WVP on daily and longer time scales is what gives the self-aggregation its memory and will prove a key ingredient in mathematically modeling this phenomenon.

In quasi-steady RCE, there must be a domainaveraged balance between THF (Fig. 5c) and net column-integrated radiative cooling *R* (Fig. 5d). In addition, there must be domain-averaged moisture balance between latent heat flux (which dominates the THF) and precipitation. Because this simulation is initialized from a small-domain simulation in RCE, precipitation, THF, and radiative cooling all start out nearly in balance, at around 100 W m<sup>2</sup> . As the simulation evolves due to self-aggregation, there is domain-averaged warming and drying, so these balances are affected by storage. However, they remain approximately valid. The quartile-average THF shows that the moistest columns tend to have slightly enhanced THF in the early stages of self-aggregation up until day 20 because of convective gustiness. This is a positive feedback on selfaggregation, since it feeds energy into the moistest columns, which have the highest *hf* . After day 20, the reverse is true as large air–sea humidity differences

![](_page_5_Figure_3.jpeg)

Fig. 3. As in Fig. 1, but for day 50.

start to amplify the THF into the driest columns, and winds from dry to moist regions increase the THF in the transitional regions. These effects also contribute to a gradual increase in domain-mean THF. The quartile-binned radiative feedbacks (Fig. 5d) show there is stronger atmospheric radiative flux divergence from the drier quartiles, reflecting anvil greenhouse warming of the moist, more convectively active columns. Like the surface flux, radiative cooling is a positive feedback on self-aggregation, since it preferentially removes energy from the driest columns. After day 35, all three dry quartiles are radiatively cooling at a similar rate, since the driest columns no longer have enough water vapor to cool more efficiently than somewhat moister columns.

# b. Weak temperature gradient approximation and temperature trends

A key simplifying feature in understanding these simulations is that stratified adjustment efficiently removes mesoscale horizontal temperature (or more precisely, density) gradients, as measured by density temperature  $T_{\rho} = T(1+0.608q_v-q_n-q_p)$ , where  $q_n$  and  $q_p$  are the mixing ratios of all cloud condensate and precipitating hydrometeors, respectively. Except within 1 km of the surface, daily-mean block-averaged  $T_{\rho}$  perturbations are less than 0.1 K (not shown). The condensate contribution to column integrated  $T_{\rho}$  is very small compared to the contributions of temperature and water vapor. Hence, at any time the columnintegrated difference (denoted by  $\delta$ ) of frozen moist static energy between any two blocks must essentially reflect their difference in WVP:

$$\delta I_{\rm hf} \approx (L - 0.608c_p \langle T \rangle) \delta W.$$
 (1)

In the lowest 1 km, the moistest blocks have a  $T_{\rho}$  that is a few tenths of a kelvin warmer than the driest blocks. This helps hydrostatically induce relatively low surface pressure that drives boundary layer mass convergence into the moistest regions against the retarding effects of surface drag.

The time evolution of domain-mean mass-weighted tropospheric temperature (not shown) generally mir-

![](_page_6_Figure_1.jpeg)

FIG. 4. Horizontally averaged profiles of (a) relative humidity and (b) moist static energy and saturation moist static energy averaged over days 1 and 50.

rors (with opposite sign) the evolution of domain-mean WVP seen in Fig. 5a, warming by 4 K over 50 days to keep mass-weighted vertically integrated moist static energy relatively constant during the simulation.

#### *c. Precipitation and humidity*

Another key feature of the simulated convection, already seen in Fig. 5b, is its strong correlation with humidity, as also clearly seen in satellite observations of tropical oceanic convection (Bretherton et al. 2004). Since this will prove central to developing a simple model of self-aggregation, we now quantify it. Following Raymond (2000) and Bretherton et al. (2004), we normalize WVP into a column relative humidity (CRH), defined as the ratio of WVP to the saturation water vapor path of the atmospheric column (i.e., the water vapor path were the entire air column moistened to 100% relative humidity with respect to water without change in temperature). Since deep convection involves microphysical and turbulent processes that tightly involve relative humidity, we expect CRH to be better tied to precipitation than is WVP. Bretherton et al. (2004) found that this is borne out by observations. Note that in our simulations, the saturation WVP (which depends only on temperature) is essentially horizontally uniform on mesoscale length scales and daily time scales, so horizontal variations of CRH are essentially equivalent to those of WVP. Bretherton et al. (2004) found an exponential increasing dependence of *P* on CRH on daily time scales, with considerable scatter that could be considerably reduced by further time averaging.

Figure 6 shows a scatterplot of the five-day means of block-averaged precipitation and CRH (computed as the ratio of block-averaged WVP to block-averaged saturation WVP) for the 64 blocks in the domain during three stages of the simulation. During the two later stages, some blocks had CRH 0.4; all such blocks had no precipitation. A hybrid linear–logarithmic vertical scale is used to better portray both the heavily and lightly precipitating blocks in one figure. In all three stages, precipitation increases strongly with CRH.

![](_page_7_Figure_3.jpeg)

FIG. 5. Time series of (a) daily averaged water vapor path, (b) precipitation (in energy units), (c) THF, and (d) net atmospheric column radiative heating  $\Delta R$ . The thick curves are domain means and the other curves are the means over the  $(72 \text{ km})^2$  grid boxes sorted into four quartiles on the basis of their daily mean WVP.

While this relationship is somewhat stage-dependent, Fig. 6 indicates that it can be adequately fit by

$$P(r) = P_{\text{RCE}} \exp[a_m(r - r_{\text{RCE}})], \quad a_m = 16.6,$$
 (2)

where  $P_{\rm RCE}=3.5~{\rm mm~day^{-1}}$  is the horizontal mean radiative–convective equilibrium rain rate, and  $r_{\rm RCE}=0.72$  is the CRH corresponding to that rain rate. This fit has the same form as the comparable observationally derived fit of Eq. (1) of Bretherton et al. (2004), and matches that relationship for a CRH near 0.8, but has a somewhat stronger dependence of P on CRH.

## 4. CRH-binned vertical motion, humidity, and cloud profiles

The self-aggregation also modulates the vertical structure of the vertical motion, relative humidity, condensate and hydrometeor profiles. Figure 7 shows these profiles averaged over days 16–20, binned into the four quartiles of block-averaged CRH. The two moistest quartiles have a top-heavy structure with accentuated upper-tropospheric upward motion and condensate.

These quartiles have a higher relative humidity than the mean at all levels above the boundary layer. This variation in vertical structure can be interpreted in terms of the interplay of cumulus clouds with environmental humidity. For a given virtual temperature profile, cumuli are less susceptible to entrainment-induced drying and evaporative cooling when their environment is moister. Hence, the clouds will reach deeper where it is moist, and the associated block-averaged vertical motion will therefore also be more top heavy. The deepest clouds will also develop larger stratiform anvils and betterorganized low-level precipitation-driven downdrafts, further accentuating the top-heavy vertical motion, condensate, and relative humidity profiles in the moist regions.

### a. Budget analysis

Both diabatic and adiabatic processes contribute to the drying of dry air columns and moistening of moist air columns that occurs during self-aggregation. To quantify their roles, we consider the block-averaged heat  $(s_{li})$  and moisture  $(q_t)$  budgets partitioned by

![](_page_8_Figure_1.jpeg)

Fig. 6. Scatterplot of 5-day-mean block-averaged precipitation vs CRH during three stages of the simulation. An exponential fit line is also plotted. Vertical scale is logarithmic for  $P>1~{\rm mm}$  day $^{-1}$  and linear below, to show both heavy and light precipitation regimes.

block-averaged WVP. Recalling that a mass-weighted vertical integral over the entire atmospheric column is denoted by I, these budgets have the following form, in energy units of W m<sup>-2</sup>:

$$\frac{dI_{\rm sli}}{dt} = LP + C_{\rm sli} + SHF + \Delta R,\tag{3}$$

$$L\frac{dI_{qt}}{dt} = -LP + LC_{qt} + LHF,$$
(4)

$$L\frac{dI_{\rm hf}}{dt} = C_{\rm hf} + \text{THF} + \Delta R. \tag{5}$$

A term of the form  $C_s$  indicates column-integrated net horizontal advective convergence of s, where  $C_s = -\nabla \cdot \langle \mathbf{u} s \rangle$  with  $\mathbf{u}$  the horizontal velocity vector. The column-integrated radiative flux divergence is  $\Delta R$ . The  $h_f$  budget is the sum of the  $s_{\rm li}$  (heat) budget plus the  $L_{\rm qt}$  (moisture) budget. These budgets are exactly preserved by the CRM, except for nudging of  $s_{\rm li}$  in the sponge layer, which contributes negligibly to the column integrated heat source in this simulation. Thus we can derive the advective terms (which require infrequently stored 3D fields to compute directly) as budget residuals given the other terms, which we calculate continuously during the simulations.

The column-integrated heat and moisture budget terms averaged over days 6–10 and sorted by CRH are shown in Fig. 8. Each budget is partitioned into diabatic and advective terms, which sum to the storage term. Figure 8a shows that the column diabatic  $s_{\rm li}$  source LP + SHF +  $\Delta R$  is negative in the dry columns, where it

primarily reflects column-integrated radiative cooling, and positive in the moistest columns because of latent heating. The advective tendency nearly exactly compensates the diabatic tendency; the small residual storage term is almost the same in all columns to maintain horizontal uniformity of temperature. The moisture budget (Fig. 8b) shows diabatic moistening of the driest columns by surface fluxes and diabatic drying of the moist columns due to the additional effect of precipitation. The advective moisture convergence overcompensates these trends, with the dry columns getting systematically drier.

Both of these budgets include precipitation, which can be thought of as a consequence of the convection and not a cause. Hence, it is also illuminating to consider the corresponding budget of moist static energy  $h_f$ (Fig. 9a), which does not explicitly involve precipitation. The diabatic  $h_f$  source removes energy from the dry columns, where radiative cooling exceeds surface total heat flux, and feeds it into the moist columns. The advective  $h_f$  source removes energy from the moistest columns, while feeding it into blocks with 0.62 < CRH < 0.72, which have intermediate precipitation rates. The net result is to remove energy from the driest columns and add it to moister columns. Because all columns must maintain roughly the same temperature profile, this preferential energy removal must be manifest as drying of the driest columns, as we saw in Fig. 8b.

Figures 9b,c show the moist static energy budget averaged over days 16–20 and 46–50, two representative later stages of self-aggregation. Note the expanded axis ranges in these panels. By days 16-20, the diabatic sink of  $h_f$  in the drier columns is quite weak because of enhanced latent heat fluxes due to near-surface drying combined with inefficient radiative cooling due to the extreme dryness of the driest air columns. However, there is still substantial advective divergence of  $h_f$  out of most dry blocks that sustains the net energy loss (drying) of the driest columns seen in the storage term. At this stage, self-aggregation is being driven primarily by advection and secondarily by diabatic forcing. In the final stage, days 46-50, the convective organization has evolved into a nearly steady state in which diabatic and adiabatic tendencies nearly balance. In the dry columns, weakly positive advective tendencies balance weakly negative diabatic tendencies. In contrast, strong advective divergence of  $h_f$  out of the moistest columns balances a substantial diabatic  $h_f$  source.

### b. Negative gross moist stability?

It initially surprised us that there is strong net advective divergence of  $h_f$  out of dry regions during self-aggregation. Export of moist static energy out of re-

![](_page_9_Figure_3.jpeg)

FIG. 7. Day 16–20 mean profiles of CRH block-quartile-binned (a) mass-weighted vertical velocity, (b) relative humidity, (c) cloud condensate, and (d) rain and snow.

gions of mean subsidence corresponds to negative gross moist stability (Neelin and Held 1987). If one naively imagines air converging into these regions in the upper troposphere where *hf* is relatively high, and diverging out of dry regions in the lower troposphere where *hf* tends to be smaller, one would predict net convergence of *hf* into dry regions.

However, Fig. 10 shows that the mesoscale circulations that develop during self-aggregation differ somewhat from this preconception. The contours in this figure visualize the day 16–20 mean circulation pattern as an effective streamfunction , derived as follows. The 64 blocks are ordered from lowest to highest CRH, and given an index *i* 1/2, *i* - 1, 2, . . . , 64. Then, starting with <sup>0</sup> - 0, is calculated as a horizontal integral over vertical velocity starting with the driest column,

$$\Psi_i(z) = \Psi_{i-1}(z) + \overline{\rho}(z) w_{i-1/2}(z),$$

where *wi*1/2(*z*) is the block-average vertical velocity profile and (*z*) is the reference density profile used in the anelastic governing equations. Here, *<sup>i</sup>* (*z*) can be interpreted as the net upward mass flux at height *z* accumulated over the *i* driest blocks. The shading in Fig. 10 shows the moist static energy perturbation from the horizontal mean, which is essentially a measure of the humidity of each block at each level. Since we have destroyed the topology of the original circulation in the CRH-sorting of blocks, we should be careful about overinterpreting details of the apparent horizontal advective tendencies of *hf* implied by this streamfunction, but it does capture the general mechanisms of *hf* exchange between drier and moister columns.

The mesoscale inflow to the moist blocks (40–64) is almost entirely in the lowest 1 km, and the outflow is mainly between 10 and 12 km. In the driest quartile of blocks, strong radiative cooling at the top of the moist near-surface boundary layer (1-km elevation) drives subsidence that is twice as strong as at 1.5-km elevation. To horizontally converge air into this subsidence maximum, a lateral inflow of fairly dry, low *hf* air develops at 1–1.5-km elevation in columns 1–20. Within the PBL,

![](_page_10_Figure_1.jpeg)

there is a correspondingly enhanced lateral outflow of air whose moist static energy has been raised by surface heat fluxes; this circulation advectively diverges *hf* out of the driest columns. Shallow cross-equatorial overturning circulations observed in the central Pacific ITCZ (e.g., Zhang et al. 2004), where the air just south of the equator is in a very dry trade-wind regime com-

pared to the deep convection north of the equator, may be radiatively forced in a similar manner.

The relative uniformity of upward mass flux over the 1.5–10-km height range in the moist blocks should not be interpreted as evidence that the cumulus clouds carrying this mass flux are just moving cloud-base air upward without lateral entrainment. Analysis of the thermodynamic characteristics of the cloudy updrafts in this region clearly shows the vertical profile of upward mass flux is instead a collective consequence of an ensemble of cumulus clouds that are entraining and detraining air throughout their depth, interacting in complex ways with the subsidence-region water vapor profile and the

FIG. 8. Day 6–10 block-CRH-sorted (a) *sli* and (b) *qt* budgets. FIG. 9. Moist static energy budgets for (a) days 6–10, (b) days 16–20, and (c) days 46–50. The dashed and solid curves in (a) are fits to the advective and diabatic *hf* sources discussed in section 5.

associated radiative cooling profile. For instance, we have done self-aggregation simulations identical to BASE except for the use of a different radiation parameterization taken from version 3 of the Community Atmosphere Model (CAM3). This simulation (not shown) produces a mean streamfunction with a slightly different vertical structure than showed in Fig. 10, without any net midlevel inflow into the moist columns. This shows that the net convective mass flux profile in the moistest columns can be significantly affected by changed radiative cooling.

#### *c. Role of gravity waves in convective initiation*

We have investigated the relevance of another proposed mechanism of convective self-aggregation to our simulations. Mapes (2000) has emphasized the role of second-mode convectively generated gravity waves

![](_page_11_Figure_3.jpeg)

Fig. 10. Day 16–20 block-CRH-sorted streamfunction (contour interval 0.02 kg m<sup>-2</sup> s<sup>-2</sup> starting at  $\pm 0.01$ , negative contours dashed), cloud ice (white contours, interval 1, 10 mg kg<sup>-1</sup>), and frozen moist static energy (shading).

(i.e., with roughly two half-wavelengths spanning the troposphere) in initiating new deep convection. Tulich and Randall (2005, manuscript submitted to *J. Atmos. Sci.*) showed that in simulations of radiative–convective equilibrium in a very large (4000 km long) 2D domain, the dominant mode of convective organization was squall lines that were tied to these second-mode gravity waves in a form of wave–conditional instability of the second kind (CISK).

In our 3D simulations and the bowling alley simulations of Tompkins (2001), water vapor-convection feedback dominates and creates a nearly stationary mode of self-aggregation. Presumably, the 3D geometry, which allows the second-mode gravity waves to propagate isotropically in all horizontal directions, is less favorable to development of a wave-CISK-like instability than a 2D domain. However, we still discerned the second-mode mechanism of convective initiation coexisting in our simulations. We projected the simulated temperature and moisture anomalies from the horizontal mean onto first and second vertical Fourier modes, with half-wavelengths equal to 900 and 450 mb, and stored these projections every 15 min. By animating time sequences of the second-mode projection of temperature, we saw a random bath of waves initiated by prior convection propagating across the domain. We also saw new convection preferentially initiating when a lower-tropospheric cold anomaly propagated into a region, presumably as a result of reduced convective inhibition and favorable conditions for deepening of shallow convection.

## 5. A simple semiempirical model of self-aggregation

In this section, we develop a simple semiempirical model for the initiation of self-aggregation in the CRM, based on the above results. The model aims to predict the initial *e*-folding rate of self-aggregation, but not its favored horizontal scale or ultimate evolution. The column-integrated moist static energy equation is used to derive an ordinary differential equation (ODE) for the CRH *r* in each mesoscale gridbox, in which the equilibrium solution, corresponding to horizontally uniform radiative convective equilibrium, can be unstable.

The assumptions are:

- 1) The temperature profile doesn't change in time in any block. This is an acceptable assumption during the early stages of self-aggregation (days 5–15), even though there is subsequently significant domainmean warming.
- 2) Precipitation is an exponentially increasing function of CRH, following (2).
- 3) The combined diabatic (surface flux and cloud radiative) forcing is linear with the form

THF + 
$$\Delta R = (c_S + c_R)L(P - P_{RCE})$$
. (6)

Its component forcings are phrased in terms of precipitation rather than WVP since on physical grounds, we anticipate that they should fundamentally depend on the amount of convection. In nonaggregated RCE ( $P = P_{RCE}$ ), the combined diabatic forcing is the only forcing on the domain-mean moist static energy, and therefore it must be zero to maintain a steady state. Figure 11 shows day 6–10 mean scatterplots of block-average THF and  $\Delta R$ versus P, both of which exhibit linear relationships with only slight scatter. The least squares best-fit lines have slopes  $c_S = 0.12$  and  $c_R = 0.17$ , respectively. By days 16-20, THF systematically increases in the dry regions as boundary layer air dries and large-scale circulations organize in these regions, almost eliminating the surface flux forcing (not shown). However, the radiative forcing remains almost unchanged. The solid curve in Fig. 9a shows the fit (6), with (2) used to predict P in terms of CRH, to the block-averaged day 6-10 diabatic forcing of column moist static energy. Again, the fit is quite good at this time, though it does not extend into later stages of self-aggregation. There is a small mean offset associated with domain-mean drying, because the initial sounding was derived from an SD-RCE simulation with slightly different physics than the control run.

![](_page_12_Figure_1.jpeg)

Fig. 11. Day 6–10 mean scatterplot of block-averaged (a) surface total heat flux and (b) column-integrated radiative flux convergence vs precipitation.

4) The moist static energy convergence during the onset of self-aggregation (here taken as days 6–10 of the simulation) can be modeled using the form

$$C_h = \alpha_h L(P - P_{\text{RCE}})(r_h - r), \quad r_h = 0.62, \, \alpha_h = 1.8.$$
 (7)

This fit, shown as the dashed curve on Fig. 9a, is an idealized representation of the product of two factors, (a) the divergent mass circulation associated with diabatically driven vertical motions in the column driven by the difference between precipitation heating and radiative cooling, here parameterized as  $L(P - P_{\rm RCE})$  and (b) cumuli in a moister environment with larger r having a more top-heavy distribution of latent heating and associated vertical motion, creating more moist static energy divergence per unit of upward mass flux. For  $r < r_h$  (shallow convection), there is energy divergence out of subsiding regions (low- $h_f$  inflow and high-

 $h_f$  outflow), corresponding to negative gross moist stability.

Figure 9a shows that the FMSE convergence in individual blocks scatters considerably about the curve fit, rendering this fit much more uncertain than the diabatic forcing. Given this uncertainty, we choose a value of  $\alpha_h$  in (7) that leads to self-aggregation in our idealized model with an *e*-folding time similar to that observed.

At later times during self-aggregation,  $C_h$  has a qualitatively similar structure in the range 0.65 < r < 0.8, but develops a positive offset from the above fit curve due to net import of moist static energy from the now-well-developed dry regions with r < 0.6 into the moister regions.

This convergence term is dependent on the column vertical motion profile, which is affected by its radiative cooling profile. Thus, the advective and diabatic parts of the moist static energy tendency are very tightly intertwined. Hence, if we artificially remove the true feedbacks between water vapor and cloud and radiative cooling, for example, by specifying horizontally uniform radiative cooling, this will affect not only the diabatic but also the advective forcing that governs self-aggregation.

Furthermore, both the diabatic and advective forcings are not entirely locally determined. As mean circulations strengthen, they increase the surface heat flux in the transitions between the dry and moist regions. This effect depends on the circulation scale, which in turn depends on the domain size. The mean density temperature profile also adjusts to keep the domainintegrated convective mass fluxes in balance with radiatively driven compensating subsidence at all levels. Thus, the parameterizations we are using for the diabatic and advective forcings cannot be expected to remain valid throughout the entire self-aggregation process, or even if the domain size is changed. Instead, they are only fits to the initial stages of self-aggregation, useful mainly in rationalizing the stability of the system to self-aggregation.

Before combining these assumptions into the desired ODE, we note two consequences of the horizontal and temporal uniformity of the temperature profile that combine to simplify the storage term for column moist static energy. The first consequence is that the saturation WVP (which depends only on the temperature profile) is uniform and equal to its initial (RCE) value,  $W_* = W_{\rm RCE}/r_{\rm RCE} = 57$  mm. To obtain the second consequence, we also note that the column-integrated condensate is comparatively small. Hence, the column-integrated liquid-ice static energy  $I_{\rm sli}$ , which depends on column-integrated temperature and column-integrated

condensate, is approximately time-independent and horizontally uniform.

The column moist static energy storage can be approximated as

$$\frac{dI_{\rm hf}}{dt} = \frac{dI_{\rm sli}}{dt} + L \frac{dI_{\rm qt}}{dt}.$$

By the above assumptions, the first term on the right-hand side is approximately zero. The second term on the right-hand side can be rewritten by noting that the water vapor path  $W=rW_*$  makes up almost all of the column-integrated water  $I_{\rm ot}$ . Hence,

$$\frac{dI_{\rm hf}}{dt} \approx L \frac{dW}{dt} = LW_* \frac{dr}{dt}.$$
 (8)

Substituting the above approximations (2), (6), (7), and (8) for the precipitation, diabatic forcings, convergence forcings, and storage, respectively, into the column-integrated moist static energy budget (5), we obtain

$$\frac{dr}{dt} = G(r) \equiv [c_S + c_R - \alpha_h(r - r_h)][P(r) - P_{\text{RCE}}]/W_*.$$

(9

The equilibria of this ODE are the roots of G. One root is at  $r_{\rm RCE} = 0.72$  and another is at  $r_{\rm max} = r_h + (c_S + c_R)/\alpha_h = 0.78$ , at which the equilibrium precipitation is  $P_{\rm max} = 9.5$  mm day<sup>-1</sup>. Note that  $r_{\rm max}$  is highly sensitive to  $\alpha_h$ , which is poorly constrained by our budget diagnosis.

Each equilibrium is stable if and only if dG/dr < 0. From (9),

$$\frac{dG}{dr}(r_{\text{RCE}}) = \left[c_S + c_R - \alpha_h(r_{\text{RCE}} - r_h)\right] \frac{dP}{dr} / W_*.$$

This equilibrium is unstable (and self-aggregation will occur) if

$$c_S + c_R > \alpha_h (r_{RCE} - r_h)$$
 for instability. (10)

Physically, RCE is unstable if anomalously moist columns gain more energy from additional surface flux (convective gustiness) and radiation (anvil greenhouse) forcing than they lose to additional lateral moist static energy divergence.

For our choice of parameters,  $c_S = 0.12$ ,  $c_R = 0.17$ , and  $\alpha_h(r_{\rm RCE} - r_h) = 0.18$ , so  $P_{RCE}$  is an unstable equilibrium. Similarly, one can show that  $P_{\rm max}$  is stable. Thus this model predicts that columns that start with  $r > r_{\rm RCE}$  will moisten to an equilibrium CRH of  $r_{\rm max}$ , while columns with  $r < r_{\rm RCE}$  will continue to dry indefinitely.

![](_page_13_Figure_18.jpeg)

Fig. 12. Time series of daily averaged WVP interquartile ratio for BASE-like simulations with a range of domain sizes.

The *e*-folding time of the self-aggregation instability about radiative–convective equilibrium is

$$\tau_{\rm sa} \equiv \left\lceil \frac{dG}{dr} (r_{\rm RCE}) \right\rceil^{-1}.$$
(11)

For our parameters,  $\tau_{sa} = 9$  days, in good agreement with Fig. 5a.

This model has many caveats. As already noted, the representation of convergence, surface flux, and radiation forcings are physically motivated curve fits for the initial stages of self-aggregation, and are not accurate for other times or domain sizes. The convergence term and the relationship between water vapor and precipitation both have a substantial random element. We have experimented with adding a noise term to the ODE to represent this randomness; it does not disrupt the basic self-aggregation mechanism or time scale.

#### 6. Sensitivity studies

In this section, we discuss several simulations that illustrate important sensitivities of self-aggregation to different physical processes and domain sizes, and compare these to our control simulation BASE. Where possible, we compare the results to predictions of our simple semiempirical model

#### a. Domain size sensitivity

We performed a series of 50-day simulations identical to BASE but with square domains of varying sizes, 96, 192, 288, and 384 km. Figure 12 shows the daily time series of the WVP interquartile ratio, defined as the ratio of WVP in the driest quartile to WVP in the moistest quartile of grid columns. Values exceeding 0.9

TABLE 1. Physics sensitivity simulations.

| Name    | Description                                                      |
|---------|------------------------------------------------------------------|
| UNISFLX | Surface turbulent fluxes horizontally homogenized                |
| UNIRAD  | Radiative heating rates horizontally homogenized                 |
| DBLRAD  | Doubled horizontal anomalies in radiative heating<br>rates       |
| MOREICE | Cloud ice autoconversion threshold raised from<br>0 to 0.1 g kg1 |
| SHEAR   | Mean wind nudged to min(0.001z, 5) m s1<br>westerlies            |
| MLO2    | 2-m-deep mixed-layer ocean                                       |
| FPL15N  | f plane at 15°N reference latitude                               |
| FPL30N  | f plane at 30°N reference latitude                               |

are associated with horizontally homogeneous convection; fully developed self-aggregation corresponds to values exceeding 0.5. Self-aggregation only occurred for the 384 km and BASE (576 km) domains, not for the smaller domains. We conclude that at least with our modeling system, there is a strict domain-size threshold for self-aggregation. Note that the simple semiempirical model makes no explicit reference to the domain size or the expected size of the self-aggregating moist and dry patches. We think that the domain size implicitly affects the column-integrated FMSE divergence by forcing moist and dry patches to be smaller, allowing dry air to be more efficiently swept into moist patches, damping the self-aggregation instability. However, this does not explain why the self-aggregation developed just as fast in the 384 km as in the larger 576-km domain.

#### *b. Sensitivities to changed physics*

We performed various CRM simulations that illustrate how self-aggregation depends on different physical processes and feedbacks (Table 1). Figure 13 shows the evolution of the WVP interquartile ratio for these simulations.

The first three of these simulations, UNISFLX, UNIRAD, and DBLRAD, were designed to test our simple semiempirical model. They do not constitute a comprehensive test of our simple semiempirical model, but do show that it has useful explanatory power. In all three simulations we checked that the FMSE divergence had a behavior similar to BASE that is well fit by (7). Using (10), self-aggregation would be predicted by the simple model if

$$(c_S + c_R) > 0.18.$$
 (12)

The first simulation UNISFLX was identical to BASE except that local surface–flux feedbacks were artificially removed by applying the horizontal mean surface heat and moisture flux uniformly to all grid columns. In this case, *cS* - 0; the model is destabilized only by the radiative term *cR*, which is still 0.17. As predicted by (12), UNIFLX did not self-aggregate.

The second simulation UNIRAD was identical to BASE except that local cloud–radiation feedbacks were artificially removed by uniformly applying the horizontal mean radiative heating rate profile to all grid columns, so *cR* - 0. In this case, the model is destabilized only by surface flux forcing with *cS* - 0.12. Again the simple model correctly predicts no self-aggregation.

The third simulation DBLRAD was identical to BASE except local cloud–radiation feedbacks were artificially doubled by applying to each grid column the horizontal mean radiative heating rate profile plus twice the local radiative heating perturbation from that mean. This doubles *cR* to 0.34, while *cS* remains 0.12.

![](_page_14_Figure_12.jpeg)

FIG. 13. Time series of daily averaged WVP interquartile ratio for the base simulation and several sensitivity studies to changed model physics.

![](_page_15_Figure_3.jpeg)

FIG. 14. As in Fig. 1, but for day 25 of MOREICE.

The simple model now predicts self-aggregation to grow with an *e*-folding time scale (11) of 3.5 days. Figure 13 shows that DBLRAD rapidly self-aggregates between 5 and 10 days, with the WVP ratio between the driest and moistest quartiles dropping from of columns increasing from 0.8 at 5 days to less than 0.4 at 10 days, implying an *e*-folding time of 4 days that is close to the simple model prediction.

Tompkins and Craig (1998) performed short sensitivity studies similar to the first two studies described above, but in a much smaller 100 km 100 km domain. This domain would be much too small to permit our CRM to self-aggregate even in the BASE case, but some of their simulations did exhibit incipient selfaggregation. They also concluded that both interactive radiation and interactive surface fluxes enhance selfaggregation, but only one of these feedbacks was required to stimulate some self-aggregation. Perhaps their CRM physics renders the local column radiative forcing and the surface flux forcing more sensitive to precipitation than in our CRM. According to our simple model, this could allow their model to selfaggregate even if one of these forcings is horizontally homogenized.

## *c. MOREICE*

In simulation MOREICE, the threshold mixing ratio for autoconversion from cloud ice (which is radiatively active) to snow (which is not) is raised from zero to the SAM6.1 default of 0.1 g kg<sup>1</sup> . This single change from the control run, which enhances the radiative impact and longevity of simulated cirrus clouds, profoundly affects the self-aggregation simulation in the upper troposphere. Starting from the same initial state, selfaggregation of WVP and precipitation occurs in a qualitatively similar way as in the control simulation, but starts more slowly. Figure 14 shows the WVP and OLR from MOREICE averaged over day 25, in a stage of self-aggregation roughly equivalent to day 20 of BASE. Regions of low OLR are seen over areas of convective rainfall, but more surprisingly, the lowest OLR is found over the center of the prominent dry hole, reflecting the presence of widespread high thin cirrus there. Figure 15 shows the corresponding CRH-sorted streamfunction

![](_page_16_Figure_1.jpeg)

FIG. 15. As in Fig. 10, but for days 21–25 of MOREICE.

and *hf* profiles, to be compared to Fig. 10. In MOREICE, there is an intense reverse circulation near the tropopause, with rising motion and considerable cloud ice (i.e., radiatively active cirrus) in the dry regions and sinking motion over the moist, convectively active regions below. This circulation appears to be radiatively driven by strong longwave heating at the base of the cirrus. Where the underlying air columns are dry, the upwelling longwave flux becomes large, reflecting the high longwave transmissivity of the atmospheric column and the warm underlying SST. Thus the cirrus heating is strongest over the dry columns, inducing mean lifting near the tropopause in these regions, promoting further cirrus cloud development. This cirrus is actually separated from the cumulus anvils, though it does rely on the moisture detrained in those anvils. The cirrus formation slows down the self-aggregation by partially removing the anvil greenhouse feedback in which actively convective columns radiatively cool less rapidly.

Simulation MOREICE can also be compared with the semiempirical model. A scatterplot like Fig. 11b of day 6–10 block-averaged column radiative flux divergence *R* versus precipitation shows more scatter and a lesser slope than in BASE, reflecting the greenhouse effect of cirrus patches over the dry region. The linear fit line has *cR* - 0.09, roughly half as strong as the response of *R* to precipitation in BASE. The surface flux and FMSE forcing terms are well fit by the same formulations as in BASE, so the instability condition 0.18 *cS cR* -0.12 0.09 is satisfied.

With these parameters, the simple model predicts a self-aggregation *e*-folding time scale (11) of 30 days, compared to 9 days for BASE. Consistent with this prediction, simulation MOREICE self-aggregates slower than BASE. Between 10 and 20 days into MOREICE, as self-aggregation is intensifying, the moist minus dry quartile WVP difference increases from 5 to 12 mm, which implies an *e*-folding time scale of 12 days. The limits of the simple model are shown by its 2.5-fold overestimation of this self-aggregation time scale. However, MOREICE is in a regime in which the simple model predicts a near balance between diabatic destabilization and adiabatic stabilization. In this regime, the predicted *e*-folding time will be particularly sensitive to uncertainties about the model coefficients and approximations in its formulation.

### *d. SHEAR*

In simulation SHEAR, the model physics are identical to BASE, but the domain mean wind velocity is nudged with a relaxation time of 2 h toward a profile with zero surface wind, constant 5 m s<sup>1</sup> westerlies above a height of 5 km, and a 10<sup>3</sup> s <sup>1</sup> westerly shear below 5 km. This shears out moisture anomalies in the *x* direction, which might inhibit self-aggregation as found by Tompkins (2001) in a bowling-alley-shaped domain. In our square domain, self-aggregation is slowed compared to the control run (Fig. 13), but not halted, because the water vapor–convection feedback can still work in the *y* direction. After 50 days, the driest quartile is approximately two-thirds as moist as the moistest quartile. Figure 16, the day 50 average structure, is characteristic of the entire latter half of the simulation, when self-aggregation has set in. It shows the expected zonal striping of convection, WVP and OLR by the westerly shear. An interesting feature of this simulation is the mean westerlies in the dry, subsiding branch of the circulation, brought down by the mean subsidence. These help increase the mean wind speed and latent heat flux in the dry band, nearly canceling the convective gustiness feedbacks that promote self-aggregation in BASE. This is likely a major factor in the slower self-aggregation in SHEAR compared to BASE.

## *e. Self-aggregation over a slab ocean and on an f plane*

Figure 13 also includes three 50-day simulations that illustrate the sensitivity of self-aggregation to other physical factors. Each of these has rich behaviors that space limitations do not allow us to describe here in detail, but which merit further study.

The first of these, MLO2, is like BASE but with a 2-m-deep mixed-layer ocean (interactive SST) cooled

![](_page_17_Figure_3.jpeg)

FIG. 16. As in Fig. 1, but for day 50 of SHEAR.

at a uniform rate of 60 W m<sup>2</sup> to maintain rough surface energy balance at the initial SST of 301 K. This simulation initially self-aggregates more slowly than BASE. We think this is due to cloud shading reducing insolation over precipitating regions, which is a negative feedback on the sustenance of warm SST and convection over those regions. Later in the simulation, the mean SST rapidly cools as self-aggregation intensifies, because the dry cool SST regions efficiently radiate surface-emitted longwave radiation to space, like the radiator fins of Pierrehumbert (1995).

Last, Fig. 13 shows two 50-day simulations, FPL15N and FPL30N, identical to BASE except on an *f* plane with Coriolis parameters corresponding to 15° and 30°N, respectively. FPL15N self-aggregates, but more slowly than BASE. We attribute this slowdown to weak rotational trapping of temperature anomalies reducing the efficiency of convective heating in one location in inducing vertical motion in remote location. However, FPL30N self-aggregates just as rapidly as in BASE, and spins up an intense tropical cyclone. Figure 17 shows the WVP at 29 days, at which point, the cyclone has achieved winds of 60 m s<sup>1</sup> . The high winds induce numerical instability shortly thereafter. In this simulation the Rossby radius *R* - *NH*/*f*  600 km for troposphere-deep heating with a depth *H* - 15 km and a buoyancy frequency *N* - 10<sup>2</sup> s 1 . This is comparable to the domain size, allowing efficient rotational trapping of heat within a subsection of the domain. In this case, the rotational winds seem to promote selfaggregation by intensifying the feedbacks between surface fluxes and the convection developing in the vortex. Emanuel and Nolan (2004) also found spontaneous development of a tropical cyclone in an RCE-type simulation on a similar sized domain, but they used a lower Coriolis parameter and required a correspondingly higher SST of 308 K.

### **7. Conclusions**

Using CRM simulations in large 3D domains with no mean wind and no ambient rotation, we have analyzed the feedbacks that induce convective self-aggregation in radiative–convective equilibrium above constant SST. This self-aggregation is based on convection forming preferentially in regions with a moist midtropo-

![](_page_18_Figure_1.jpeg)

FIG. 17. WVP, mean surface wind vectors, and contours of precipitation (0.5, 1, and 2 m day<sup>1</sup> ) for day 29 of FPL30N.

sphere. Both cloud–radiation feedbacks and convective gustiness help initiate self-aggregation. As regions start to dry out, they start to radiatively cool more strongly in the lower troposphere than the upper troposphere. At the same time, stratified adjustment efficiently erases horizontal virtual temperature gradients. Hence, a bottom-heavy subsidence profile develops to compensate the bottom-heavy radiative cooling. To feed this subsidence, a lower to midtropospheric return flow from moist to dry regions develops above the boundary layer flow from dry to moist, convecting regions. This lowlevel circulation, which resembles the cross-equatorial flow in the central and east Pacific, amplifies the selfaggregation by exporting moist static energy out of the dry regions, allowing them to dry further. The ultimate result after 50 days or so is to create a single small moist region of intense convection surrounded by subsidence. The domain-mean thermodynamic profiles are much warmer and drier than comparable small-domain RCE simulations.

The dynamical feedbacks on self-aggregation were different than we had expected, and inextricably intertwined with the diabatic forcings and their vertical profiles. From simple models of large-scale tropical circulation with a single vertical mode of variability, such as the quasi-equilibrium tropical circulation model of Neelin and Zeng (2000) and two-layer models such as Neelin and Held (1987), we had anticipated that convectively induced large-scale circulations would have gross moist stability, exporting moist static energy from moist, precipitating regions and importing moist static energy into dry regions. In fact, the advective moist static energy fluxes were considerably more complex, and resembled the above preconception only in the most intensely convecting regions, with negative gross moist stability elsewhere. This illustrates the importance of the interconnected vertical profiles of convection, vertical motion, and humidity in determining the exchange of moist static energy between moister and drier regions.

Sensitivity studies illustrated that for the SAM CRM, feedbacks between convection and both radiation and surface fluxes are needed to initiate self-aggregation. Our simple model suggests that only small increases in the strength of either of these feedbacks in SAM would allow self-aggregation with only one of these feedbacks active, as was found in the CRM simulations of Tompkins and Craig (1998) and Tompkins (2001). Unidirectional shear inhibits self-aggregation only in the alongshear direction. Minor changes in the SAM microphysical scheme can also affect self-aggregation by modifying the locations and lifetimes of cirrus cloud and hence the relation of column radiative cooling to column moisture. Ambient rotation and a mixed layer ocean also modify self-aggregation, but do not prevent it.

In the real atmosphere, tropical synoptic-scale and intraseasonal disturbances initiated both within the Tropics and from midlatitudes prevent convective selfaggregation going to the extreme shown in Fig. 3 by shearing out water vapor anomalies on time scales of a few days, comparable to the *e*-folding time of the selfaggregation we have simulated. Furthermore, SST gradients help pattern the large-scale circulation. Hence, one should perhaps look only at self-aggregating RCE as a singular and unrealizable metaphor. Perhaps the metaphor is most relevant over the Indian Ocean/West Pacific warm pool, where SST gradients and mean wind shear are weak. Here the MJO is a dominant form of disturbance. The MJO clearly has a rotational component, has precursors in the wind field, and propagates eastward because of beta-plane dynamics. However, the correlations between water vapor, convection, radiation, and surface fluxes observed in the MJO are similar to those in our self-aggregation simulations. We have begun to investigate the organization of convection on a beta-plane aquaplanet using an approach called Diabatic Acceleration and Rescaling (DARE) described by Kuang et al. (2005), which brings planetary and convective scales much closer to each other and allows both to be represented in an affordable CRM simulation. In the DARE simulations we have done so far, the large-scale convective organization is dominated by equatorially trapped waves of near planetary scale. It is in the interplay of water vapor, convection, surface fluxes, and radiation in these waves that we are most likely seeing the real atmosphere's manifestation of convective self-aggregation.

*Acknowledgments.* This work was supported by NASA Grants NAG5-13564 and NAGS5-10624, and was improved by helpful discussions with Zhiming Kuang and Kerry Emanuel.

#### REFERENCES

- Bretherton, C. S., M. E. Peters, and L. E. Back, 2004: Relationships between water vapor path and precipitation over the tropical oceans. *J. Climate,* **17,** 1517–1528.
- Emanuel, K. A., and D. Nolan, 2004: Tropical cyclone activity and the global climate system. *Proc. 26th Conf. on Hurricanes and Tropical Meteorology*, Miami, FL, Amer. Meteor. Soc., CD-ROM, 10A.2.
- Held, I. M., R. S. Hemler, and V. Ramaswamy, 1993: Radiativeconvective equilibrium with explicit two-dimensional convection. *J. Atmos. Sci.,* **50,** 3909–3927.
- Khairoutdinov, M. F., and D. A. Randall, 2003: Cloud resolving modeling of the ARM summer 1997 IOP: Model formulation, result, uncertainties, and sensitivities. *J. Atmos. Sci.,* **60,** 607– 625.
- Kiehl, J. T., J. J. Hack, G. B. Bonan, B. A. Boville, D. L. Williamson, and P. J. Rasch, 1998: The National Center for Atmospheric Research Community Climate Model (CCM3). *J. Climate*, **11,** 1131–1149.
- Kuang, Z., P. N. Blossey, and C. S. Bretherton, 2005: A new approach for 3D cloud-resolving simulations of large-scale atmospheric circulation. *Geophys. Res. Lett.,* **32,** L02809, doi:10.1029/2004GL021024.
- Maloney, E. D., and D. L. Hartmann, 1998: Frictional moisture convergence in a composite life cycle of the Madden–Julian oscillation. *J. Climate,* **11,** 2387–2403.
- Manabe, S., and R. F. Strickler, 1964: Thermal equilibrium of the atmosphere with a convective adjustment. *J. Atmos. Sci.,* **21,** 361–385.
- Mapes, B. E., 2000: Convective inhibition, subgrid-scale triggering

- energy, and stratiform instability in a toy tropical wave model. *J. Atmos. Sci.,* **57,** 1515–1535.
- Neelin, J. D., and I. M. Held, 1987: Modeling tropical convergence based on the moist static energy budget. *Mon. Wea. Rev.,* **115,** 3–12.
- ——, and N. Zeng, 2000: A quasi-equilibrium tropical circulation model—Formulation. *J. Atmos. Sci.,* **57,** 1741–1766.
- Numaguti, A., R. Oki, K. Nakamura, K. Tsuboki, N. Misawa, T. Aisai, and Y.-M. Kodama, 1995: 4–5 day-period variation and low-level dry air observed in the equatorial western Pacific during the TOGA-COARE IOP. *J. Meteor. Soc. Japan,* **73,** 267–290.
- Pierrehumbert, R. T., 1995: Thermostats, radiator fins and the local runaway greenhouse. *J. Atmos. Sci.,* **52,** 1784–1806.
- Raymond, D. J., 2000: Thermodynamic control of tropical rainfall. *Quart. J. Roy. Meteor. Soc.,* **126,** 889–898.
- Redelsperger, J.-L., D. B. Parsons, and F. Guichard, 2002: Recovery processes and factors limiting cloud-top height following the arrival of a dry intrusion observed during TOGA COARE. *J. Atmos. Sci.,* **59,** 2438–2457.
- Sherwood, S. C., and R. Wahrlich, 1999: Observed evolution of tropical deep convective events and their environment. *Mon. Wea. Rev.,* **127,** 1777–1795.
- Tompkins, A. M., 2001: Organization of tropical convection in low vertical wind shears: The role of water vapor. *J. Atmos. Sci.,* **58,** 529–545.
- ——, and G. C. Craig, 1998: Radiative-convective equilibrium in a three-dimensional cloud ensemble model. *Quart. J. Roy. Meteor. Soc.,* **124,** 2073–2097.
- Wang, W., and M. E. Schlesinger, 1999: The dependence on convective parameterization of the tropical intraseasonal oscillation simulated by the UIUC 11-layer atmospheric GCM. *J. Climate,* **12,** 1423–1457.
- Wheeler, M., G. N. Kiladis, and P. J. Webster, 2000: Large-scale dynamical fields associated with convectively coupled equatorial waves. *J. Atmos. Sci.,* **57,** 613–640.
- Zhang, C., M. McGauley, and N. A. Bond, 2004: Shallow meridional circulation in the tropical eastern Pacific. *J. Climate,* **17,** 133–139.