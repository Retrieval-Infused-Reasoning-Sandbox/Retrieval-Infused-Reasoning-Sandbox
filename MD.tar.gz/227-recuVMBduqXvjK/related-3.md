# Rényi Divergence and Kullback-Leibler Divergence

Tim van Erven

Peter Harremoës, Member, IEEE

Abstract—Rényi divergence is related to Rényi entropy much like Kullback-Leibler divergence is related to Shannon's entropy, and comes up in many settings. It was introduced by Rényi as a measure of information that satisfies almost the same axioms as Kullback-Leibler divergence, and depends on a parameter that is called its order. In particular, the Rényi divergence of order 1 equals the Kullback-Leibler divergence.

We review and extend the most important properties of Rényi divergence and Kullback-Leibler divergence, including convexity, continuity, limits of  $\sigma$ -algebras and the relation of the special order 0 to the Gaussian dichotomy and contiguity. We also show how to generalize the Pythagorean inequality to orders different from 1, and we extend the known equivalence between channel capacity and minimax redundancy to continuous channel inputs (for all orders) and present several other minimax results.

Index Terms— $\alpha$ -divergence, Bhattacharyya distance, information divergence, Kullback-Leibler divergence, Pythagorean inequality, Rényi divergence

#### I. Introduction

HANNON entropy and Kullback-Leibler divergence (also known as information divergence or relative entropy) are perhaps the two most fundamental quantities in information theory and its applications. Because of their success, there have been many attempts to generalize these concepts, and in the literature one will find numerous entropy and divergence measures. Most of these quantities have never found any applications, and almost none of them have found an interpretation in terms of coding. The most important exceptions are the Rényi entropy and Rényi divergence [1]. Harremoës [2] and Grünwald [3, p. 649] provide an operational characterization of Rényi divergence as the number of bits by which a mixture of two codes can be compressed; and Csiszár [4] gives an operational characterization of Rényi divergence as the cutoff rate in block coding and hypothesis testing.

Rényi divergence appears as a crucial tool in proofs of convergence of minimum description length and Bayesian estimators, both in parametric and nonparametric models [5], [6], [7, Chapter 5], and one may recognize it implicitly in many computations throughout information theory. It is also closely related to Hellinger distance, which is commonly used in the analysis of nonparametric density estimation [8]–[10]. Rényi himself used his divergence to prove the convergence of state probabilities in a stationary Markov chain to the stationary distribution [1], and still other applications of Rényi divergence can be found, for instance, in hypothesis testing [11], in multiple source adaptation [12] and in ranking of images [13].

Tim van Erven (tim@timvanerven.nl) is with the Département de Mathématiques, Université Paris-Sud, France. Peter Harremoës (harremoes@ieee.org) is with the Copenhagen Business College, Denmark. Some of the results in this paper have previously been presented at the ISIT 2010 conference.

Although the closely related Rényi entropy is well studied [14], [15], the properties of Rényi divergence are scattered throughout the literature and have often only been established for finite alphabets. This paper is intended as a reference document, which treats the most important properties of Rényi divergence in detail, including Kullback-Leibler divergence as a special case. Preliminary versions of the results presented here can be found in [16] and [7]. During the preparation of this paper, Shayevitz has independently published closely related work [17], [18].

## A. Rényi's Information Measures

For finite alphabets, the *Rényi divergence* of positive order  $\alpha \neq 1$  of a probability distribution  $P = (p_1, \dots, p_n)$  from another distribution  $Q = (q_1, \dots, q_n)$  is

<span id="page-0-0"></span>
$$D_{\alpha}(P||Q) = \frac{1}{\alpha - 1} \ln \sum_{i=1}^{n} p_i^{\alpha} q_i^{1 - \alpha}, \tag{1}$$

where, for  $\alpha>1$ , we read  $p_i^\alpha q_i^{1-\alpha}$  as  $p_i^\alpha/q_i^{(\alpha-1)}$  and adopt the conventions that 0/0=0 and  $x/0=\infty$  for x>0. As described in Section II, this definition generalizes to continuous spaces by replacing the probabilities by densities and the sum by an integral. If P and Q are members of the same exponential family, then their Rényi divergence can be computed using a formula by Huzurbazar [19] and Liese and Vajda [20, p. 43], [11]. Gil provides a long list of examples [21], [22].

**Example 1.** Let Q be a probability distribution and A a set with positive probability. Let P be the conditional distribution of Q given A. Then

$$D_{\alpha}(P||Q) = -\ln Q(A).$$

We observe that in this important special case the factor  $\frac{1}{\alpha-1}$  in the definition of Rényi divergence has the effect that the value of  $D_{\alpha}(P||Q)$  does not depend on  $\alpha$ .

The Rényi entropy

$$H_{\alpha}(P) = \frac{1}{1-\alpha} \ln \sum_{i=1}^{n} p_{i}^{\alpha}$$

can be expressed in terms of the Rényi divergence of P from the uniform distribution  $U=(1/n,\ldots,1/n)$ :

<span id="page-0-1"></span>
$$H_{\alpha}(P) = H_{\alpha}(U) - D_{\alpha}(P||U) = \ln n - D_{\alpha}(P||U).$$
 (2)

As  $\alpha$  tends to 1, the Rényi entropy tends to the Shannon entropy and the Rényi divergence tends to the Kullback-Leibler divergence, so we recover a well-known relation. The differential Rényi entropy of a distribution P with density p is given by

$$h_{\alpha}(P) = \frac{1}{1-\alpha} \ln \int (p(x))^{\alpha} dx$$

![](_page_1_Figure_2.jpeg)

<span id="page-1-0"></span>Fig. 1. Rényi divergence as a function of its order for fixed distributions

whenever this integral is defined. If P has support in an interval I of length n then

<span id="page-1-4"></span>
$$h_{\alpha}(P) = \ln n - D_{\alpha}(P||U_I), \tag{3}$$

where  $U_I$  denotes the uniform distribution on I, and  $D_{\alpha}$  is the generalization of Rényi divergence to densities, which will be defined formally in Section II. Thus the properties of both the Rényi entropy and the differential Rényi entropy can be deduced from the properties of Rényi divergence as long as P has compact support.

There is another way of relating Rényi entropy and Rényi divergence, in which entropy is considered as self-information. Let X denote a discrete random variable with distribution P, and let  $P_{\rm diag}$  be the distribution of (X,X). Then

<span id="page-1-5"></span>
$$H_{\alpha}(P) = D_{2-\alpha}(P_{\text{diag}} || P \times P). \tag{4}$$

For  $\alpha$  tending to 1, the right-hand side tends to the mutual information between X and itself, and again a well-known formula is recovered.

#### B. Special Orders

Although one can define the Rényi divergence of any order, certain values have wider application than others. Of particular interest are the values 0, 1/2, 1, 2, and  $\infty$ .

The values 0, 1, and  $\infty$  are extended orders in the sense that Rényi divergence of these orders cannot be calculated by plugging into (1). Instead, their definitions are determined by continuity in  $\alpha$  (see Figure 1). This leads to defining Rényi divergence of order 1 as the Kullback-Leibler divergence. For order 0 it becomes  $-\ln Q(\{i\mid p_i>0\})$ , which is closely related to absolute continuity and contiguity of the distributions P and Q (see Section III-F). For order  $\infty$ , Rényi divergence is defined as  $\lim \max_i \frac{p_i}{q_i}$ . In the literature on the minimum description length principle in statistics, this is called the worst-case regret of coding with Q rather than with P [3]. The Rényi divergence of order  $\infty$  is also related to the separation distance, used by Aldous and Diaconis [23] to bound the rate of convergence to the stationary distribution for certain Markov chains.

Only for  $\alpha=1/2$  is Rényi divergence symmetric in its arguments. Although not itself a metric, it is a function of the

squared Hellinger distance  $\operatorname{Hel}^2(P,Q) = \sum_{i=1}^n \left(p_i^{1/2} - q_i^{1/2}\right)^2$  [24]:

<span id="page-1-1"></span>
$$D_{1/2}(P||Q) = -2\ln\left(1 - \frac{\text{Hel}^2(P,Q)}{2}\right).$$
 (5)

Similarly, for  $\alpha = 2$  it satisfies

<span id="page-1-6"></span><span id="page-1-2"></span>
$$D_2(P||Q) = \ln(1 + \chi^2(P,Q)),$$
 (6)

where  $\chi^2(P,Q) = \sum_{i=1}^n \frac{(p_i - q_i)^2}{q_i}$  denotes the  $\chi^2$ -divergence [24]. It will be shown that Rényi divergence is nondecreasing in its order. Therefore, by  $\ln t \le t - 1$ , (5) and (6) imply that

$$\operatorname{Hel}^{2}(P,Q) \leq D_{1/2}(P||Q) \leq D_{1}(P||Q)$$
  
  $\leq D_{2}(P||Q) \leq \chi^{2}(P,Q).$  (7)

Finally, Gilardoni [25] shows that Rényi divergence is related to the *total variation distance*<sup>1</sup>  $V(P,Q) = \sum_{i=1}^{n} |p_i - q_i|$  by a generalization of *Pinsker's inequality*:

$$\frac{\alpha}{2}V^2(P,Q) \le D_{\alpha}(P\|Q) \quad \text{for } \alpha \in (0,1].$$
 (8)

(See Theorem 31 below.) For  $\alpha=1$  this is the normal version of Pinsker's inequality, which bounds total variation distance in terms of the square root of the Kullback-Leibler divergence.

#### C. Outline

The rest of the paper is organized as follows. First, in Section II, we extend the definition of Rényi divergence from formula (1) to continuous spaces. One can either define Rényi divergence via an integral or via discretizations. We demonstrate that these definitions are equivalent. Then we show that Rényi divergence extends to the extended orders 0, 1 and  $\infty$  in the same way as for finite spaces. Along the way, we also study its behaviour as a function of  $\alpha$ . By contrast, in Section III we study various convexity and continuity properties of Rényi divergence as a function of P and Q, while  $\alpha$  is kept fixed. We also generalize the Pythagorean inequality to any order  $\alpha \in (0, \infty)$ . Section IV contains several minimax results, and treats the connection to Chernoff information in hypothesis testing, to which many applications of Rényi divergence are related. We also discuss the equivalence of channel capacity and the minimax redundancy for all orders  $\alpha$ . Then, in Section V, we show how Rényi divergence extends to negative orders. These are related to the orders  $\alpha > 1$  by a negative scaling factor and a reversal of the arguments P and Q. Finally, Section VI contains a number of counterexamples, showing that properties that hold for certain other divergences are violated by Rényi divergence.

For fixed  $\alpha$ , Rényi divergence is related to various forms of power divergences, which are in the well-studied class of f-divergences [27]. Consequently, several of the results we are presenting for fixed  $\alpha$  in Section III are equivalent to known results about power divergences. To make this presentation self-contained we avoid the use of such connections and only use general results from measure theory.

<span id="page-1-3"></span> $^1$ N.B. It is also common to define the total variation distance as  $\frac{1}{2}V(P,Q)$ . See the discussion by Pollard [26, p. 60]. Our definition is consistent with the literature on Pinsker's inequality.

## Summary

Definition for the simple orders  $\alpha \in (0,1) \cup (1,\infty)$ :

$$D_{\alpha}(P||Q) = \frac{1}{\alpha - 1} \ln \int p^{\alpha} q^{1 - \alpha} d\mu.$$

For the extended orders (Thms 4-6):

$$\begin{split} &D_0(P\|Q) = -\ln Q(p>0) \\ &D_1(P\|Q) = D(P\|Q) = \text{ Kullback-Leibler divergence} \\ &D_\infty(P\|Q) = \ln \left( \operatorname{ess\,sup} \frac{p}{q} \right) = \text{worst-case regret.} \end{split}$$

Equivalent definition via discretization (Thm 10):

$$D_{\alpha}(P||Q) = \sup_{\mathcal{P} \in \text{finite partitions}} D_{\alpha}(P_{|\mathcal{P}}||Q_{|\mathcal{P}}).$$

Relations to (differential) Rényi entropy ((2), (3), (4)): For  $\alpha \in [0, \infty]$ ,

$$H_{\alpha}(P) = \ln |\mathcal{X}| - D_{\alpha}(P||U) = D_{2-\alpha}(P_{\text{diag}}||P \times P)$$
 for finite  $\mathcal{X}$ .  
 $h_{\alpha}(P) = \ln n - D_{\alpha}(P||U_I)$  if  $\mathcal{X}$  is an interval  $I$  of length  $n$ .

Relations to other divergences ((5)-(7), Remark 1) and Pinsker's inequality (Thm 31):

$$\begin{aligned} \operatorname{Hel}^2 & \leq D_{1/2} \leq D \leq D_2 \leq \chi^2 \\ & \frac{\alpha}{2} V^2 \leq D_{\alpha} \quad \text{for } \alpha \in (0, 1]. \end{aligned}$$

Relation to Fisher information (Section III-H): For a parametric statistical model  $\{P_\theta \mid \theta \in \Theta \subseteq \mathbb{R}\}$  with "sufficiently regular" parametrisation,

$$\lim_{\theta' \to \theta} \frac{1}{(\theta - \theta')^2} D_{\alpha}(P_{\theta} || P_{\theta'}) = \frac{\alpha}{2} J(\theta) \quad \text{for } \alpha \in (0, \infty).$$

Varying the order (Thms 3, 7, Corollary 2):

- $D_{\alpha}$  is nondecreasing in  $\alpha$ , often strictly so.
- $D_{\alpha}$  is continuous in  $\alpha$  on  $[0,1] \cup \{\alpha \in (1,\infty] \mid D_{\alpha} < \infty\}$ .
- $(1-\alpha)D_{\alpha}$  is concave in  $\alpha$  on  $[0,\infty]$ .

Positivity (Thm 8) and skew symmetry (Proposition 2):

- $\begin{array}{ll} \bullet & D_{\alpha} \geq 0 \text{ for } \alpha \in [0,\infty], \text{ often strictly so.} \\ \bullet & D_{\alpha}(P\|Q) = \frac{\alpha}{1-\alpha}D_{1-\alpha}(Q\|P) \text{ for } 0 < \alpha < 1. \end{array}$

Convexity (Thms 11–13):  $D_{\alpha}(P||Q)$  is

- jointly convex in (P,Q) for  $\alpha \in [0,1]$ ,
- convex in Q for  $\alpha \in [0, \infty]$ ,
- jointly quasi-convex in (P,Q) for  $\alpha \in [0,\infty]$ .

Pythagorean inequality (Thm 14): For  $\alpha \in (0, \infty)$ , let  $\mathcal{P}$  be an  $\alpha$ -convex set of distributions and let Q be an arbitrary distribution. If the  $\alpha$ -information projection  $P^* = \arg\min_{P \in \mathcal{P}} D_{\alpha}(P||Q)$  exists, then

$$D_{\alpha}(P||Q) \ge D_{\alpha}(P||P^*) + D_{\alpha}(P^*||Q)$$
 for all  $P \in \mathcal{P}$ .

Data processing (Thm 9, Example 2): If we fix the transition probabilities A(Y|X) in a Markov chain  $X \to Y$ , then

$$D_{\alpha}(P_Y || Q_Y) \le D_{\alpha}(P_X || Q_X)$$
 for  $\alpha \in [0, \infty]$ .

The topology of setwise convergence (Thms 15, 18):

- $D_{\alpha}(P||Q)$  is lower semi-continuous in the pair (P,Q) for  $\alpha \in (0,\infty]$ .
- If  $\mathcal{X}$  is finite, then  $D_{\alpha}(P||Q)$  is continuous in Q for  $\alpha \in [0, \infty]$ .

The total variation topology (Thm 17, Corollary 1):

- $D_{\alpha}(P||Q)$  is uniformly continuous in (P,Q) for  $\alpha \in (0,1)$ .
- $D_0(P||Q)$  is upper semi-continuous in (P,Q).

The weak topology (Thms 19, 20): Suppose  $\mathcal{X}$  is a Polish space. Then

- $D_{\alpha}(P||Q)$  is lower semi-continuous in the pair (P,Q) for  $\alpha \in (0,\infty]$ ;
- The sublevel set  $\{P \mid D_{\alpha}(P||Q) \leq c\}$  is convex and compact for  $c \in [0, \infty)$  and  $\alpha \in [1, \infty]$ .

Orders  $\alpha \in (0,1)$  are all equivalent (Thm 16):

$$\frac{\alpha}{\beta} \frac{1-\beta}{1-\alpha} D_{\beta} \le D_{\alpha} \le D_{\beta}$$
 for  $0 < \alpha \le \beta < 1$ .

Additivity and other consistent sequences of distributions (Thms 27, 28):

• For arbitrary distributions  $P_1,P_2,\ldots$  and  $Q_1,Q_2,\ldots$ , let  $P^N=P_1\times\cdots\times P_N$  and  $Q^N=Q_1\times\cdots\times Q_N$ . Then

$$\sum_{n=1}^N D_\alpha(P_n \| Q_n) = D_\alpha(P^N \| Q^N) \quad \begin{cases} \text{for } \alpha \in [0, \infty] & \text{if } N < \infty, \\ \text{for } \alpha \in (0, \infty] & \text{if } N = \infty. \end{cases}$$

• Let  $P^1, P^2, \ldots$  and  $Q^1, Q^2, \ldots$  be consistent sequences of distributions on  $n = 1, 2, \ldots$  outcomes. Then

$$D_{\alpha}(P^n || Q^n) \to D_{\alpha}(P^{\infty} || Q^{\infty})$$
 for  $\alpha \in (0, \infty]$ .

Limits of  $\sigma$ -algebras (Thms 21, 22):

- For  $\sigma$ -algebras  $\mathcal{F}_1 \subseteq \mathcal{F}_2 \subseteq \cdots \subseteq \mathcal{F}$  and  $\mathcal{F}_\infty = \sigma \left( \bigcup_{n=1}^\infty \mathcal{F}_n \right)$ ,  $\lim_{n \to \infty} D_{\alpha}(P_{|\mathcal{F}_n} || Q_{|\mathcal{F}_n}) = D_{\alpha}(P_{|\mathcal{F}_\infty} || Q_{|\mathcal{F}_\infty}) \quad \text{for } \alpha \in (0, \infty].$
- For  $\sigma$ -algebras  $\mathcal{F} \supseteq \mathcal{F}_1 \supseteq \mathcal{F}_2 \supseteq \cdots$  and  $\mathcal{F}_{\infty} = \bigcap_{n=1}^{\infty} \mathcal{F}_n$ ,  $\lim_{n \to \infty} D_{\alpha}(P_{|\mathcal{F}_n} || Q_{|\mathcal{F}_n}) = D_{\alpha}(P_{|\mathcal{F}_\infty} || Q_{|\mathcal{F}_\infty}) \quad \text{for } \alpha \in [0, 1)$

and also for  $\alpha \in [1, \infty)$  if  $D_{\alpha}(P_{|\mathcal{F}_m} || Q_{|\mathcal{F}_m}) < \infty$  for some m.

Absolute continuity and mutual singularity (Thms 23, 24, 25, 26):

- P ≪ Q if and only if D<sub>0</sub>(P||Q) = 0.
- $P \perp Q$  if and only if  $D_{\alpha}(P||Q) = \infty$  for some/all  $\alpha \in [0,1)$ .
- These properties generalize to contiguity and entire separation.

Hypothesis testing and Chernoff information (Thms 30, 32): If  $\alpha$  is a simple order, then

$$(1 - \alpha)D_{\alpha}(P||Q) = \inf_{R} \{\alpha D(R||P) + (1 - \alpha)D(R||Q)\}.$$

Suppose  $D(P||Q) < \infty$ . Then the Chernoff information satisfies

$$\begin{split} \sup_{\alpha \in (0,\infty)} \inf_{R} \left\{ &\alpha D(R\|P) + (1-\alpha)D(R\|Q) \right\} \\ &= \inf_{R} \sup_{\alpha \in (0,\infty)} \left\{ &\alpha D(R\|P) + (1-\alpha)D(R\|Q) \right\}, \end{split}$$

and, under regularity conditions, both sides equal  $D(P_{\alpha^*} || P) = D(P_{\alpha^*} || Q)$ .

Channel capacity and minimax redundancy (Thms 34, 36, 37, 38, Lemma 9, Conjecture 1): Suppose  $\mathcal{X}$  is finite. Then, for  $\alpha \in [0, \infty]$ ,

- The channel capacity  $C_{\alpha}$  equals the minimax redundancy  $R_{\alpha}$ ;
- There exists  $Q_{\text{opt}}$  such that  $\sup_{\theta} D(P_{\theta} || Q_{\text{opt}}) = R_{\alpha}$ ;
- If there exists a capacity achieving input distribution  $\pi_{opt}$ , then  $D(P_{\theta}||Q_{\text{opt}}) = R_{\alpha}$  almost surely for  $\theta$  drawn from  $\pi_{\text{opt}}$ ;
- If  $\alpha = \infty$  and the maximum likelihood is achieved by  $\hat{\theta}(x)$ , then  $\pi_{\rm opt}(\theta) = Q_{\rm opt}(\{x \mid \hat{\theta}(x) = \theta\})$  is a capacity achieving input distribution;

Suppose  $\mathcal{X}$  is countable and  $R_{\infty} < \infty$ . Then, for  $\alpha = \infty$ ,  $Q_{\text{opt}}$  is the Shtarkov distribution defined in (66) and

$$\sup D_{\infty}(P_{\theta}||Q) = R_{\infty} + D_{\infty}(Q_{\text{opt}}||Q) \quad \text{for all } Q.$$

We conjecture that this generalizes to a one-sided inequality for any  $\alpha > 0$ .

Negative orders (Lemma 10, Thms 39, 40):

- Results for positive  $\alpha$  carry over, but often with reversed properties.
- $D_{\alpha}$  is nondecreasing in  $\alpha$  on  $[-\infty, \infty]$ .
- $D_{\alpha}$  is continuous in  $\alpha$  on  $[0,1] \cup \{\alpha \mid -\infty < D_{\alpha} < \infty\}$ .

Counterexamples (Section VI):

- $D_{\alpha}(P||Q)$  is not convex in P for  $\alpha > 1$ .
- For  $\alpha \in (0,1),$   $D_{\alpha}(P\|Q)$  is not continuous in (P,Q) in the topology of setwise convergence.
- $D_{\alpha}$  is not (the square of) a metric.

#### II. DEFINITION OF RÉNYI DIVERGENCE

<span id="page-3-0"></span>Let us fix the notation to be used throughout the paper. We consider (probability) measures on a measurable space  $(\mathcal{X}, \mathcal{F})$ . If P is a measure on  $(\mathcal{X}, \mathcal{F})$ , then we write  $P_{|\mathcal{C}}$ for its restriction to the sub- $\sigma$ -algebra  $\mathcal{G} \subseteq \mathcal{F}$ , which may be interpreted as the marginal of P on the subset of events  $\mathcal{G}$ . A measure P is called absolutely continuous with respect to another measure Q if P(A) = 0 whenever Q(A) = 0for all events  $A \in \mathcal{F}$ . We will write  $P \ll Q$  if P is absolutely continuous with respect to Q and  $P \not\ll Q$  otherwise. Alternatively, P and Q may be *mutually singular*, denoted  $P \perp Q$ , which means that there exists an event  $A \in \mathcal{F}$  such that P(A) = 0 and  $Q(X \setminus A) = 0$ . We will assume that all (probability) measures are absolutely continuous with respect to a common  $\sigma$ -finite measure  $\mu$ , which is arbitrary in the sense that none of our definitions or results depend on the choice of  $\mu$ . As we only consider (mixtures of) a countable number of distributions, such a measure  $\mu$  exists in all cases, so this is no restriction. For measures denoted by capital letters (e.g. P or Q), we will use the corresponding lowercase letters (e.g. p, q) to refer to their densities with respect to  $\mu$ . This includes the setting with a finite alphabet from the introduction by taking  $\mu$  to be the counting measure, so that pand q are probability mass functions. Using that densities are random variables, we write, for example,  $\int p^{\alpha}q^{1-\alpha}d\mu$  instead of its lengthy equivalent  $\int p(x)^{\alpha}q(x)^{1-\alpha}d\mu(x)$ . For any event  $A \in \mathcal{F}$ ,  $\mathbf{1}_A$  denotes its indicator function, which is 1 on A and 0 otherwise. Finally, we use the natural logarithm in our definitions, such that information is measured in nats (1 bit equals  $\ln 2$  nats).

We will often need to distinguish between the orders for which Rényi divergence can be defined by a generalization of formula (1) to an integral over densities, and the other orders. This motivates the following definitions.

**Definition 1.** We call a (finite) real number  $\alpha$  a *simple order* if  $\alpha > 0$  and  $\alpha \neq 1$ . The values 0, 1, and  $\infty$  are called *extended orders*.

#### A. Definition by Formula for Simple Orders

Let P and Q be two arbitrary distributions on  $(\mathcal{X}, \mathcal{F})$ . The formula in (1), which defines Rényi divergence for simple orders on finite sample spaces, generalizes to arbitrary spaces as follows:

<span id="page-3-2"></span>**Definition 2** (Simple Orders). For any simple order  $\alpha$ , the *Rényi divergence* of *order*  $\alpha$  of P from Q is defined as

<span id="page-3-5"></span>
$$D_{\alpha}(P||Q) = \frac{1}{\alpha - 1} \ln \int p^{\alpha} q^{1 - \alpha} \,\mathrm{d}\mu, \tag{9}$$

where, for  $\alpha>1$ , we read  $p^{\alpha}q^{1-\alpha}$  as  $\frac{p^{\alpha}}{q^{\alpha-1}}$  and adopt the conventions that 0/0=0 and  $x/0=\infty$  for x>0.

For example, for any simple order  $\alpha$ , the Rényi divergence of a normal distribution (with mean  $\mu_0$  and positive variance  $\sigma_0^2$ ) from another normal distribution (with mean  $\mu_1$  and

positive variance  $\sigma_1^2$ ) is

$$D_{\alpha}\left(\mathcal{N}(\mu_0, \sigma_0^2) \| \mathcal{N}(\mu_1, \sigma_1^2) \right) = \frac{\alpha(\mu_1 - \mu_0)^2}{2\sigma_{\alpha}^2} + \frac{1}{1 - \alpha} \ln \frac{\sigma_{\alpha}}{\sigma_0^{1 - \alpha} \sigma_{\alpha}^{\alpha}}, \quad (10)$$

provided that  $\sigma_{\alpha}^{2} = (1 - \alpha)\sigma_{0}^{2} + \alpha\sigma_{1}^{2} > 0$  [20, p. 45].

<span id="page-3-1"></span>Remark 1. The interpretation of  $p^{\alpha}q^{1-\alpha}$  in Definition 2 is such that the Hellinger integral  $\int p^{\alpha}q^{1-\alpha} \, \mathrm{d}\mu$  is an f-divergence [27], which ensures that the relations from the introduction to squared Hellinger distance (5) and  $\chi^2$ -distance (6) hold in general, not just for finite sample spaces.

For simple orders, we may always change to integration with respect to P:

<span id="page-3-6"></span>
$$\int p^{\alpha} q^{1-\alpha} d\mu = \int \left(\frac{q}{p}\right)^{1-\alpha} dP,$$

which shows that our definition does not depend on the choice of dominating measure  $\mu$ . In most cases it is also equivalent to integrate with respect to Q:

$$\int p^{\alpha} q^{1-\alpha} d\mu = \int \left(\frac{p}{q}\right)^{\alpha} dQ \qquad (0 < \alpha < 1 \text{ or } P \ll Q).$$

However, if  $\alpha > 1$  and  $P \not\ll Q$ , then  $D_{\alpha}(P||Q) = \infty$ , whereas the integral with respect to Q may be finite. This is a subtle consequence of our conventions. For example, if P = (1/2, 1/2), Q = (1, 0) and  $\mu$  is the counting measure, then for  $\alpha > 1$ 

$$\int p^{\alpha} q^{1-\alpha} d\mu = \frac{(1/2)^{\alpha}}{1^{\alpha-1}} + \frac{(1/2)^{\alpha}}{0^{\alpha-1}} = \infty,$$
 (11)

but

$$\int \left(\frac{p}{q}\right)^{\alpha} dQ = \int_{q>0} \left(\frac{p}{q}\right)^{\alpha} dQ = \frac{(1/2)^{\alpha}}{1^{\alpha-1}} = 2^{-\alpha}.$$
 (12)

#### B. Definition via Discretization for Simple Orders

We shall repeatedly use the following result, which is a direct consequence of the Radon-Nikodým theorem [28]:

<span id="page-3-4"></span>**Proposition 1.** Suppose  $\lambda \ll \mu$  is a probability distribution, or any countably additive measure such that  $\lambda(\mathcal{X}) \leq 1$ . Then for any sub- $\sigma$ -algebra  $\mathcal{G} \subseteq \mathcal{F}$ 

$$\frac{\mathrm{d}\lambda_{\mid\mathcal{G}}}{\mathrm{d}\mu_{\mid\mathcal{G}}} = \mathbf{E} \left[ \left. \frac{\mathrm{d}\lambda}{\mathrm{d}\mu} \right| \mathcal{G} \right] \qquad (\mu\text{-a.s.})$$

It has been argued that grouping observations together (by considering a coarser  $\sigma$ -algebra), should not increase our ability to distinguish between P and Q under any measure of divergence [29]. This is expressed by the *data processing inequality*, which Rényi divergence satisfies:

<span id="page-3-3"></span>**Theorem 1** (Data Processing Inequality). For any simple order  $\alpha$  and any sub- $\sigma$ -algebra  $\mathcal{G} \subseteq \mathcal{F}$ 

$$D_{\alpha}(P_{\mid G} || Q_{\mid G}) \le D_{\alpha}(P || Q).$$

Theorem 9 below shows that the data processing inequality also holds for the extended orders.

<span id="page-4-0"></span>**Example 2.** The name "data processing inequality" stems from the following application of Theorem 1. Let X and Y be two random variables that form a Markov chain

$$X \to Y$$
.

where the conditional distribution of Y given X is A(Y|X). Then if Y=f(X) is a deterministic function of X, we may view Y as the result of "processing" X according to the function f. In general, we may also process X using a nondeterministic function, such that A(Y|X) is not a point-mass.

Suppose  $P_X$  and  $Q_X$  are distributions for X. Let  $P_X \circ A$  and  $Q_X \circ A$  denote the corresponding joint distributions, and let  $P_Y$  and  $Q_Y$  be the induced marginal distributions for Y. Then the reader may verify that  $D_\alpha(P_X \circ A \| Q_X \circ A) = D_\alpha(P_X \| Q_X)$ , and consequently the data processing inequality implies that processing X to obtain Y reduces Rényi divergence:

$$D_{\alpha}(P_Y || Q_Y) \le D_{\alpha}(P_X \circ A || Q_X \circ A) = D_{\alpha}(P_X || Q_X).$$
 (13)

Proof of Theorem 1: Let  $\tilde{P}$  denote the absolutely continuous component of P with respect to Q. Then by Proposition 1 and Jensen's inequality for conditional expectations

<span id="page-4-1"></span>
$$\frac{1}{\alpha - 1} \ln \int \left( \frac{d\tilde{P}_{|\mathcal{G}}}{dQ_{|\mathcal{G}}} \right)^{\alpha} dQ$$

$$= \frac{1}{\alpha - 1} \ln \int \left( \mathbf{E} \left[ \frac{d\tilde{P}}{dQ} \middle| \mathcal{G} \right] \right)^{\alpha} dQ$$

$$\leq \frac{1}{\alpha - 1} \ln \int \mathbf{E} \left[ \left( \frac{d\tilde{P}}{dQ} \right)^{\alpha} \middle| \mathcal{G} \right] dQ$$

$$= \frac{1}{\alpha - 1} \ln \int \left( \frac{d\tilde{P}}{dQ} \right)^{\alpha} dQ.$$
(14)

If  $0<\alpha<1$ , then  $p^{\alpha}q^{1-\alpha}=0$  if q=0, so the restriction of P to  $\tilde{P}$  does not change the Rényi divergence, and hence the theorem is proved. Alternatively, suppose  $\alpha>1$ . If  $P\ll Q$ , then  $\tilde{P}=P$  and the theorem again follows from (14). If  $P\not\ll Q$ , then  $D_{\alpha}(P\|Q)=\infty$  and the theorem holds as well.

The next theorem shows that if  $\mathcal X$  is a continuous space, then the Rényi divergence on  $\mathcal X$  can be arbitrarily well approximated by the Rényi divergence on finite partitions of  $\mathcal X$ . For any finite or countable partition  $\mathcal P=\{A_1,A_2,\ldots\}$  of  $\mathcal X$ , let  $P_{|\mathcal P}\equiv P_{|\sigma(\mathcal P)}$  and  $Q_{|\mathcal P}\equiv Q_{|\sigma(\mathcal P)}$  denote the restrictions of P and Q to the  $\sigma$ -algebra generated by  $\mathcal P$ .

<span id="page-4-3"></span>**Theorem 2.** For any simple order  $\alpha$ 

<span id="page-4-2"></span>
$$D_{\alpha}(P||Q) = \sup_{\mathcal{D}} D_{\alpha}(P_{|\mathcal{P}}||Q_{|\mathcal{P}}), \tag{15}$$

where the supremum is over all finite partitions  $\mathcal{P} \subseteq \mathcal{F}$ .

It follows that it would be equivalent to first define Rényi divergence for finite sample spaces and then extend the definition to arbitrary sample spaces using (15).

The identity (15) also holds for the extended orders 1 and  $\infty$ . (See Theorem 10 below.)

Proof of Theorem 2: By the data processing inequality

$$\sup_{\mathcal{D}} D_{\alpha}(P_{|\mathcal{P}} || Q_{|\mathcal{P}}) \le D_{\alpha}(P || Q).$$

To show the converse inequality, consider for any  $\varepsilon>0$  a discretization of the densities p and q into a countable number of bins

$$B_{m,n}^{\varepsilon} = \{ x \in \mathcal{X} \mid e^{m\varepsilon} \le p(x) < e^{(m+1)\varepsilon}, \\ e^{n\varepsilon} \le q(x) < e^{(n+1)\varepsilon} \},$$

where  $n, m \in \{-\infty, \dots, -1, 0, 1, \dots\}$ . Let  $\mathcal{Q}^{\varepsilon} = \{B_{m,n}^{\varepsilon}\}$  and  $\mathcal{F}^{\varepsilon} = \sigma(\mathcal{Q}^{\varepsilon}) \subseteq \mathcal{F}$  be the corresponding partition and  $\sigma$ -algebra, and let  $p_{\varepsilon} = \mathrm{d}P_{|\mathcal{Q}^{\varepsilon}}/\mathrm{d}\mu$  and  $q_{\varepsilon} = \mathrm{d}Q_{|\mathcal{Q}^{\varepsilon}}/\mathrm{d}\mu$  be the densities of P and Q restricted to  $\mathcal{F}^{\varepsilon}$ . Then by Proposition 1

$$\frac{q_{\varepsilon}}{p_{\varepsilon}} = \frac{\mathbf{E}[q \mid \mathcal{F}^{\varepsilon}]}{\mathbf{E}[p \mid \mathcal{F}^{\varepsilon}]} \le \frac{q}{p} \mathbf{e}^{2\varepsilon} \qquad (P\text{-a.s.})$$

It follows that

$$\frac{1}{\alpha - 1} \ln \int \left( \frac{q_{\varepsilon}}{p_{\varepsilon}} \right)^{1 - \alpha} \mathrm{d}P \ge \frac{1}{\alpha - 1} \ln \int \left( \frac{q}{p} \right)^{1 - \alpha} \mathrm{d}P - 2\varepsilon,$$

and hence the supremum over all countable partitions is large enough:

$$\sup_{\substack{\text{countable } \mathcal{Q} \\ \sigma(Q) \subseteq \mathcal{F}}} D_{\alpha}(P_{|\mathcal{Q}} \| Q_{|\mathcal{Q}}) \geq \sup_{\varepsilon > 0} D_{\alpha}(P_{|\mathcal{Q}^{\varepsilon}} \| Q_{|\mathcal{Q}^{\varepsilon}}) \geq D_{\alpha}(P \| Q).$$

It remains to show that the supremum over finite partitions is at least as large. To this end, suppose  $Q = \{B_1, B_2, \ldots\}$  is any countable partition and let  $\mathcal{P}_n = \{B_1, \ldots, B_{n-1}, \bigcup_{i \geq n} B_i\}$ . Then by

$$P\Big(\bigcup_{i\geq n} B_i\Big)^{\alpha} Q\Big(\bigcup_{i\geq n} B_i\Big)^{1-\alpha} \geq 0 \qquad (\alpha > 1),$$
$$\lim_{n \to \infty} P\Big(\bigcup_{i>n} B_i\Big)^{\alpha} Q\Big(\bigcup_{i>n} B_i\Big)^{1-\alpha} = 0 \qquad (0 < \alpha < 1),$$

we find that

$$\lim_{n \to \infty} D_{\alpha}(P_{|\mathcal{P}_n} || Q_{|\mathcal{P}_n}) = \lim_{n \to \infty} \frac{1}{\alpha - 1} \ln \sum_{B \in \mathcal{P}_n} P(B)^{\alpha} Q(B)^{1 - \alpha}$$

$$\geq \lim_{n \to \infty} \frac{1}{\alpha - 1} \ln \sum_{i=1}^{n-1} P(B_i)^{\alpha} Q(B_i)^{1 - \alpha}$$

$$= D_{\alpha}(P_{|\mathcal{O}|} || Q_{|\mathcal{O}|}),$$

where the inequality holds with equality if  $0 < \alpha < 1$ .

#### C. Extended Orders: Varying the Order

As for finite alphabets, continuity considerations lead to the following extensions of Rényi divergence to orders for which it cannot be defined using the formula in (9).

<span id="page-4-4"></span>**Definition 3** (Extended Orders). The *Rényi divergences* of orders 0 and 1 are defined as

$$D_0(P||Q) = \lim_{\alpha \downarrow 0} D_{\alpha}(P||Q),$$
  
$$D_1(P||Q) = \lim_{\alpha \uparrow 1} D_{\alpha}(P||Q),$$

and the Rényi divergence of order  $\infty$  is defined as

$$D_{\infty}(P||Q) = \lim_{\alpha \uparrow \infty} D_{\alpha}(P||Q).$$

Our definition of  $D_0$  follows Csiszár [4]. It differs from Rényi's original definition [1], which uses (9) with  $\alpha = 0$  plugged in and is therefore always zero. As illustrated by Section III-F, the present definition is more interesting.

The limits in Definition 3 always exist, because Rényi divergence is nondecreasing in its order:

<span id="page-5-1"></span>**Theorem 3** (Increasing in the Order). For  $\alpha \in [0, \infty]$  the Rényi divergence  $D_{\alpha}(P\|Q)$  is nondecreasing in  $\alpha$ . On  $\mathcal{A} = \{\alpha \in [0,\infty] \mid 0 \leq \alpha \leq 1 \text{ or } D_{\alpha}(P\|Q) < \infty\}$  it is constant if and only if P is the conditional distribution  $Q(\cdot \mid A)$  for some event  $A \in \mathcal{F}$ .

*Proof:* Let  $\alpha < \beta$  be simple orders. Then for  $x \geq 0$  the function  $x \mapsto x^{\frac{(\alpha-1)}{(\beta-1)}}$  is strictly convex if  $\alpha < 1$  and strictly concave if  $\alpha > 1$ . Therefore by Jensen's inequality

$$\frac{1}{\alpha - 1} \ln \int p^{\alpha} q^{1 - \alpha} d\mu = \frac{1}{\alpha - 1} \ln \int \left(\frac{q}{p}\right)^{(1 - \beta) \frac{\alpha - 1}{\beta - 1}} dP$$
$$\leq \frac{1}{\beta - 1} \ln \int \left(\frac{q}{p}\right)^{1 - \beta} dP.$$

On  $\mathcal{A}$ ,  $\int (q/p)^{1-\beta} \mathrm{d}P$  is finite. As a consequence, Jensen's inequality holds with equality if and only if  $(q/p)^{1-\beta}$  is constant P-a.s., which is equivalent to q/p being constant P-a.s., which in turn means that  $P = Q(\cdot \mid A)$  for some event A.

From the simple orders, the result extends to the extended orders by the following observations:

$$D_0(P||Q) = \inf_{0 < \alpha < 1} D_{\alpha}(P||Q),$$

$$D_1(P||Q) = \sup_{0 < \alpha < 1} D_{\alpha}(P||Q) \le \inf_{\alpha > 1} D_{\alpha}(P||Q),$$

$$D_{\infty}(P||Q) = \sup_{\alpha > 1} D_{\alpha}(P||Q).$$

Let us verify that the limits in Definition 3 can be expressed in closed form, just like for finite alphabets. We require the following lemma:

<span id="page-5-3"></span>**Lemma 1.** Let  $A = \{\alpha \text{ a simple order } | 0 < \alpha < 1 \text{ or } D_{\alpha}(P||Q) < \infty\}$ . Then, for any sequence  $\alpha_1, \alpha_2, \ldots \in A$  such that  $\alpha_n \to \beta \in A \cup \{0,1\}$ ,

<span id="page-5-2"></span>
$$\lim_{n \to \infty} \int p^{\alpha_n} q^{1-\alpha_n} \, \mathrm{d}\mu = \int \lim_{n \to \infty} p^{\alpha_n} q^{1-\alpha_n} \, \mathrm{d}\mu. \tag{16}$$

Our proof extends a proof by Shiryaev [28, pp. 366–367]. Proof: We will verify the conditions for the dominated convergence theorem [28], from which (16) follows. First suppose  $0 \le \beta < 1$ . Then  $0 < \alpha_n < 1$  for all sufficiently large n. In this case  $p^{\alpha_n}q^{1-\alpha_n}$ , which is never negative, does not exceed  $\alpha_n p + (1-\alpha_n)q \le p+q$ , and the dominated convergence theorem applies because  $\int (p+q) \, \mathrm{d}\mu = 2 < \infty$ . Secondly, suppose  $\beta \ge 1$ . Then there exists a  $\gamma \ge \beta$  such that  $\gamma \in \mathcal{A} \cup \{1\}$  and  $\alpha_n \le \gamma$  for all sufficiently large n. If  $\gamma = 1$ , then  $\alpha_n < 1$  and we are done by the same argument as above. So suppose  $\gamma>1$ . Then convexity of  $p^{\alpha_n}q^{1-\alpha_n}$  in  $\alpha_n$  implies that for  $\alpha_n\leq \gamma$ 

$$p^{\alpha_n}q^{1-\alpha_n} \leq (1-\frac{\alpha_n}{\gamma})p^0q^1 + \frac{\alpha_n}{\gamma}p^{\gamma}q^{1-\gamma} \leq q + p^{\gamma}q^{1-\gamma}.$$

Since  $\int q \, \mathrm{d}\mu = 1$ , it remains to show that  $\int p^{\gamma} q^{1-\gamma} \, \mathrm{d}\mu < \infty$ , which is implied by  $\gamma > 1$  and  $D_{\gamma}(P\|Q) < \infty$ .

The closed-form expression for  $\alpha = 0$  follows immediately:

<span id="page-5-0"></span>Theorem 4 ( $\alpha = 0$ ).

$$D_0(P||Q) = -\ln Q(p > 0).$$

Proof of Theorem 4: By Lemma 1 and the fact that  $\lim_{\alpha\downarrow 0}p^{\alpha}q^{1-\alpha}=\mathbf{1}_{\{p>0\}}q$ .

For  $\alpha=1$ , the limit in Definition 3 equals the *Kullback-Leibler divergence* of P from Q, which is defined as

$$D(P||Q) = \int p \ln \frac{p}{q} \,\mathrm{d}\mu,$$

with the conventions that  $0 \ln(0/q) = 0$  and  $p \ln(p/0) = \infty$  if p > 0. Consequently,  $D(P||Q) = \infty$  if  $P \not\ll Q$ .

<span id="page-5-5"></span>Theorem 5 ( $\alpha = 1$ ).

<span id="page-5-6"></span>
$$D_1(P||Q) = D(P||Q). (17)$$

Moreover, if  $D(P||Q) = \infty$  or there exists a  $\beta > 1$  such that  $D_{\beta}(P||Q) < \infty$ , then also

<span id="page-5-4"></span>
$$\lim_{\alpha \to 1} D_{\alpha}(P \| Q) = D(P \| Q). \tag{18}$$

For example, by letting  $\alpha \uparrow 1$  in (10) or by direct computation, it can be derived [20] that the Kullback-Leibler divergence between two normal distributions with positive variance is

$$D_1\left(\mathcal{N}(\mu_0, \sigma_0^2) \| \mathcal{N}(\mu_1, \sigma_1^2) \right) = \frac{1}{2} \left( \frac{(\mu_1 - \mu_0)^2}{\sigma_1^2} + \ln \frac{\sigma_1^2}{\sigma_0^2} + \frac{\sigma_0^2}{\sigma_1^2} - 1 \right).$$

It is possible that  $D_{\alpha}(P\|Q)=\infty$  for all  $\alpha>1$ , but  $D(P\|Q)<\infty$ , such that (18) does not hold. This situation occurs, for example, if P is doubly exponential on  $\mathcal{X}=\mathbb{R}$  with density  $p(x)=\mathrm{e}^{-2|x|}$  and Q is standard normal with density  $q(x)=\mathrm{e}^{-x^2/2}/\sqrt{2\pi}$ . (Liese and Vajda [27] have previously used these distributions in a similar example.) In this case there is no way to make Rényi divergence continuous in  $\alpha$  at  $\alpha=1$ , and we opt to define  $D_1$  as the limit from below, such that it always equals the Kullback-Leibler divergence.

The proof of Theorem 5 requires an intermediate lemma:

<span id="page-5-7"></span>**Lemma 2.** For any x > 1/2

$$(x-1)\left(1+\frac{1-x}{2}\right) \le \ln x \le x-1.$$

*Proof:* By Taylor's theorem with Cauchy's remainder term we have for any positive x that

$$\ln x = x - 1 - \frac{(x - \xi)(x - 1)}{2\xi^2}$$
$$= (x - 1)\left(1 + \frac{\xi - x}{2\xi^2}\right)$$

for some  $\xi$  between x and 1. As  $\frac{\xi - x}{2\xi^2}$  is increasing in  $\xi$  for x > 1/2, the lemma follows.

Proof of Theorem 5: Suppose  $P \not \ll Q$ . Then  $D(P\|Q) = \infty = D_{\beta}(P\|Q)$  for all  $\beta > 1$ , so (18) holds. Let  $x_{\alpha} = \int p^{\alpha}q^{1-\alpha}\,\mathrm{d}\mu$ . Then  $\lim_{\alpha\uparrow 1}x_{\alpha} = P(q>0)$  by Lemma 1, and hence (17) follows by

$$\begin{split} \lim_{\alpha \uparrow 1} \frac{1}{\alpha - 1} \ln \int p^{\alpha} q^{1 - \alpha} \, \mathrm{d}\mu \\ = \lim_{\alpha \uparrow 1} \frac{1}{\alpha - 1} \ln P(q > 0) = \infty = D(P \| Q). \end{split}$$

Alternatively, suppose  $P \ll Q$ . Then  $\lim_{\alpha \uparrow 1} x_{\alpha} = 1$  and therefore Lemma 2 implies that

$$\lim_{\alpha \uparrow 1} D_{\alpha}(P \| Q) = \lim_{\alpha \uparrow 1} \frac{1}{\alpha - 1} \ln x_{\alpha}$$

$$= \lim_{\alpha \uparrow 1} \frac{x_{\alpha} - 1}{\alpha - 1} = \lim_{\alpha \uparrow 1} \int_{p,q > 0} \frac{p - p^{\alpha} q^{1 - \alpha}}{1 - \alpha} \, \mathrm{d}\mu, \quad (19)$$

where the restriction of the domain of integration is allowed because q=0 implies p=0 ( $\mu$ -a.s.) by  $P\ll Q$ . Convexity of  $p^{\alpha}q^{1-\alpha}$  in  $\alpha$  implies that its derivative,  $p^{\alpha}q^{1-\alpha}\ln\frac{p}{q}$ , is nondecreasing and therefore for p,q>0

$$\frac{p - p^{\alpha}q^{1-\alpha}}{1 - \alpha} = \frac{1}{1 - \alpha} \int_{\alpha}^{1} p^{z}q^{1-z} \ln \frac{p}{q} dz$$

is nondecreasing in  $\alpha$ , and  $\frac{p-p^{\alpha}q^{1-\alpha}}{1-\alpha}\geq \frac{p-p^{0}q^{1-0}}{1-0}=p-q$ . As  $\int_{p,q>0}(p-q)\;\mathrm{d}\mu>-\infty$ , it follows by the monotone convergence theorem that

$$\begin{split} \lim_{\alpha \uparrow 1} \int_{p,q > 0} \frac{p - p^{\alpha} q^{1 - \alpha}}{1 - \alpha} \, \mathrm{d}\mu &= \int_{p,q > 0} \lim_{\alpha \uparrow 1} \frac{p - p^{\alpha} q^{1 - \alpha}}{1 - \alpha} \, \mathrm{d}\mu \\ &= \int_{p,q > 0} p \ln \frac{p}{q} \, \mathrm{d}\mu = D(P \| Q), \end{split}$$

which together with (19) proves (17). If  $D(P\|Q) = \infty$ , then  $D_{\beta}(P\|Q) \geq D(P\|Q) = \infty$  for all  $\beta > 1$  and (18) holds. It remains to prove (18) if there exists a  $\beta > 1$  such that  $D_{\beta}(P\|Q) < \infty$ . In this case, arguments similar to the ones above imply that

<span id="page-6-3"></span>
$$\lim_{\alpha \downarrow 1} D_{\alpha}(P||Q) = \lim_{\alpha \downarrow 1} \int_{p, q > 0} \frac{p^{\alpha} q^{1-\alpha} - p}{\alpha - 1} \,\mathrm{d}\mu \qquad (20)$$

and  $\frac{p^{\alpha}q^{1-\alpha}-p}{\alpha-1}$  is nondecreasing in  $\alpha$ . Therefore  $\frac{p^{\alpha}q^{1-\alpha}-p}{\alpha-1} \leq \frac{p^{\beta}q^{1-\beta}-p}{\beta-1} \leq \frac{p^{\beta}q^{1-\beta}}{\beta-1}$  and, as  $\int_{p,q>0} \frac{p^{\beta}q^{1-\beta}}{\beta-1} \ \mathrm{d}\mu < \infty$  is implied by  $D_{\beta}(P\|Q) < \infty$ , it follows by the monotone convergence theorem that

$$\lim_{\alpha \downarrow 1} \int_{p,q>0} \frac{p^{\alpha} q^{1-\alpha} - p}{\alpha - 1} d\mu = \int_{p,q>0} \lim_{\alpha \downarrow 1} \frac{p^{\alpha} q^{1-\alpha} - p}{\alpha - 1} d\mu$$
$$= \int_{p,q>0} p \ln \frac{p}{q} d\mu = D(P||Q),$$

which together with (20) completes the proof.

For any random variable X, the essential supremum of X with respect to P is  $\operatorname{ess\,sup}_P X = \sup\{c \mid P(X > c) > 0\}$ .

<span id="page-6-0"></span>**Theorem 6** ( $\alpha = \infty$ ).

$$D_{\infty}(P||Q) = \ln \sup_{A \in \mathcal{F}} \frac{P(A)}{Q(A)} = \ln \left( \operatorname{ess\,sup} \frac{p}{q} \right),$$

with the conventions that 0/0 = 0 and  $x/0 = \infty$  if x > 0.

If the sample space  $\mathcal X$  is countable, then with the notational conventions of this theorem the essential supremum reduces to an ordinary supremum, and we have  $D_\infty(P\|Q) = \ln \sup_x \frac{P(x)}{Q(x)}$ .

*Proof:* If  $\mathcal{X}$  contains a finite number of elements n, then

$$D_{\infty}(P||Q) = \lim_{\alpha \uparrow \infty} \frac{1}{\alpha - 1} \ln \sum_{i=1}^{n} p_i^{\alpha} q_i^{1 - \alpha}$$
$$= \ln \max_i \frac{p_i}{q_i} = \ln \max_{A \subseteq \mathcal{X}} \frac{P(A)}{Q(A)}.$$

<span id="page-6-2"></span>This extends to arbitrary measurable spaces  $(\mathcal{X}, \mathcal{F})$  by Theorem 2:

$$\begin{split} D_{\infty}(P\|Q) &= \sup_{\alpha < \infty} \sup_{\mathcal{P}} D_{\alpha}(P_{|\mathcal{P}}\|Q_{|\mathcal{P}}) \\ &= \sup_{\mathcal{P}} \sup_{\alpha < \infty} D_{\alpha}(P_{|\mathcal{P}}\|Q_{|\mathcal{P}}) \\ &= \sup_{\mathcal{P}} \ln \max_{A \in \mathcal{P}} \frac{P(A)}{Q(A)} = \ln \sup_{A \in \mathcal{F}} \frac{P(A)}{Q(A)}, \end{split}$$

where  $\mathcal{P}$  ranges over all finite partitions in  $\mathcal{F}$ .

Now if  $P \not\ll Q$ , then there exists an event  $B \in \mathcal{F}$  such that P(B)>0 but Q(B)=0, and

$$P\left(\frac{p}{q} = \infty\right) = P(q = 0) \ge P(B) > 0$$

implies that  $\exp p/q = \infty = \sup_A \frac{P(A)}{Q(A)}$ . Alternatively, suppose that  $P \ll Q$ . Then

$$P(A) = \int_{A \cap \{q>0\}} p \, \mathrm{d}\mu \le \int_{A \cap \{q>0\}} \operatorname{ess\,sup} \frac{p}{q} \cdot q \, \mathrm{d}\mu = \operatorname{ess\,sup} \frac{p}{q} \cdot Q(A)$$

for all  $A \in \mathcal{F}$  and it follows that

<span id="page-6-4"></span>
$$\sup_{A \in \mathcal{F}} \frac{P(A)}{Q(A)} \le \operatorname{ess\,sup} \frac{p}{q}. \tag{21}$$

Let  $a < \operatorname{ess\,sup} p/q$  be arbitrary. Then there exists a set  $A \in \mathcal{F}$  with P(A) > 0 such that  $p/q \ge a$  on A and therefore

$$P(A) = \int_{A} p \, d\mu \ge \int_{A} a \cdot q \, d\mu = a \cdot Q(A).$$

Thus  $\sup_{A \in \mathcal{F}} \frac{P(A)}{Q(A)} \ge a$  for any  $a < \operatorname{ess sup} p/q$ , which implies that

$$\sup_{A \in \mathcal{F}} \frac{P(A)}{Q(A)} \ge \operatorname{ess\,sup} \frac{p}{q}.$$

In combination with (21) this completes the proof.

Taken together, the previous results imply that Rényi divergence is a continuous function of its order  $\alpha$  (under suitable conditions):

<span id="page-6-1"></span>**Theorem 7** (Continuity in the Order). The Rényi divergence  $D_{\alpha}(P||Q)$  is continuous in  $\alpha$  on  $\mathcal{A} = \{\alpha \in [0,\infty] \mid 0 \leq \alpha \leq 1 \text{ or } D_{\alpha}(P||Q) < \infty\}.$ 

*Proof:* Continuity at any simple order  $\beta$  follows by Lemma 1. It extends to the extended orders 0 and  $\infty$  by the definition of Rényi divergence at these orders. And it extends to  $\alpha = 1$  by Theorem 5.

## III. FIXED NONNEGATIVE ORDERS

<span id="page-7-0"></span>In this section we fix the order α and study properties of Renyi divergence as ´ P and Q are varied. First we prove nonnegativity and extend the data processing inequality and the relation to a supremum over finite partitions to the extended orders. Then we study convexity, we prove a generalization of the Pythagorean inequality to general orders, and finally we consider various types of continuity.

*A. Positivity, Data Processing and Finite Partitions*

<span id="page-7-2"></span>Theorem 8 (Positivity). *For any order* α ∈ [0, ∞]

$$D_{\alpha}(P||Q) \ge 0.$$

*For* α > 0*,* Dα(PkQ) = 0 *if and only if* P = Q*. For* α = 0*,* Dα(PkQ) = 0 *if and only if* Q P*.*

*Proof:* Suppose first that α is a simple order. Then by Jensen's inequality

$$\frac{1}{\alpha - 1} \ln \int p^{\alpha} q^{1 - \alpha} d\mu = \frac{1}{\alpha - 1} \ln \int \left(\frac{q}{p}\right)^{1 - \alpha} dF$$
$$\geq \frac{1 - \alpha}{\alpha - 1} \ln \int \frac{q}{p} dP \geq 0.$$

Equality holds if and only if q/p is constant P-a.s. (first inequality) and Q P (second inequality), which together is equivalent to P = Q.

The result extends to α ∈ {1, ∞} by Dα(PkQ) = supβ<α Dβ(PkQ). For α = 0 it can be verified directly that − ln Q(p > 0) ≥ 0, with equality if and only if Q P.

<span id="page-7-4"></span>Theorem 9 (Data Processing Inequality). *For any order* α ∈ [0, ∞] *and any sub-*σ*-algebra* G ⊆ F

<span id="page-7-5"></span>
$$D_{\alpha}(P_{|\mathcal{G}}||Q_{|\mathcal{G}}) \le D_{\alpha}(P||Q). \tag{22}$$

Example [2](#page-4-0) also applies to the extended orders without modification.

*Proof:* By Theorem [1,](#page-3-3) [\(22\)](#page-7-5) holds for the simple orders. Let β be any extended order and let α<sup>n</sup> → β be an arbitrary sequence of simple orders that converges to β, from above if β = 0 and from below if β ∈ {1, ∞}. Then

$$D_{\beta}(P_{|\mathcal{G}} || Q_{|\mathcal{G}}) = \lim_{n \to \infty} D_{\alpha_n}(P_{|\mathcal{G}} || Q_{|\mathcal{G}})$$
  
$$\leq \lim_{n \to \infty} D_{\alpha_n}(P || Q) = D_{\beta}(P || Q).$$

<span id="page-7-1"></span>Theorem 10. *For any* α ∈ [0, ∞]

$$D_{\alpha}(P||Q) = \sup_{\mathcal{P}} D_{\alpha}(P_{|\mathcal{P}}||Q_{|\mathcal{P}}),$$

*where the supremum is over all finite partitions* P ⊆ F*.*

*Proof:* For simple orders α, the result holds by Theorem [2.](#page-4-3) This extends to α ∈ {1, ∞} by monotonicity and leftcontinuity in α:

$$D_{\alpha}(P||Q) = \sup_{\beta < \alpha} D_{\beta}(P||Q) = \sup_{\beta < \alpha} \sup_{\mathcal{P}} D_{\beta}(P_{|\mathcal{P}}||Q_{|\mathcal{P}})$$
$$= \sup_{\mathcal{P}} \sup_{\beta < \alpha} D_{\beta}(P_{|\mathcal{P}}||Q_{|\mathcal{P}}) = \sup_{\mathcal{P}} D_{\alpha}(P_{|\mathcal{P}}||Q_{|\mathcal{P}}).$$

![](_page_7_Figure_22.jpeg)

Fig. 2. Renyi divergence as a function of ´ P = (p, 1−p) for Q = (1/3, 2/3)

<span id="page-7-6"></span>![](_page_7_Figure_24.jpeg)

<span id="page-7-7"></span>Fig. 3. Level curves of D1/<sup>2</sup> (PkQ) for fixed Q as P ranges over the simplex of distributions on a three-element set

For α = 0, the data processing inequality implies that

$$D_{\alpha}(P||Q) \ge \sup_{\mathcal{P}} D_{\alpha}(P_{|\mathcal{P}}||Q_{|\mathcal{P}}),$$

and equality is achieved for the partition P = {p > 0, p = 0}.

## *B. Convexity*

Consider Figures [2](#page-7-6) and [3.](#page-7-7) They show Dα(PkQ) as a function of P for sample spaces containing two or three elements. These figures suggest that Renyi divergence is convex in its ´ first argument for small α, but not for large α. This is in agreement with the well-known fact that it is jointly convex in the pair (P, Q) for α = 1. It turns out that joint convexity extends to α < 1, but not to α > 1, as noted by Csiszar´ [\[4\]](#page-22-3). Our proof generalizes the proof for α = 1 by Cover and Thomas [\[30\]](#page-22-28).

<span id="page-7-3"></span>Theorem 11. *For any order* α ∈ [0, 1] *Renyi divergence is ´ jointly convex in its arguments. That is, for any two pairs of probability distributions* (P0, Q0) *and* (P1, Q1)*, and any* 0 < λ < 1

<span id="page-7-8"></span>
$$D_{\alpha} ((1 - \lambda) P_0 + \lambda P_1 \| (1 - \lambda) Q_0 + \lambda Q_1)$$

$$\leq (1 - \lambda) D_{\alpha} (P_0 \| Q_0) + \lambda D_{\alpha} (P_1 \| Q_1).$$
(23)

Equality holds if and only if

$$\alpha = 0 \colon D_0(P_0 \| Q_0) = D_0(P_1 \| Q_1),$$

$$p_0 = 0 \Rightarrow p_1 = 0 \; (Q_0 \text{-}a.s.) \; \text{and}$$

$$p_1 = 0 \Rightarrow p_0 = 0 \; (Q_1 \text{-}a.s.);$$

$$0 < \alpha < 1 \colon D_\alpha(P_0 \| Q_0) = D_\alpha(P_1 \| Q_1) \; \text{and}$$

$$p_0 q_1 = p_1 q_0 \; (\mu \text{-}a.s.);$$

$$\alpha = 1 \colon p_0 q_1 = p_1 q_0 \; (\mu \text{-}a.s.)$$

*Proof:* Suppose first that  $\alpha=0$ , and let  $P_{\lambda}=(1-\lambda)P_0+\lambda P_1$  and  $Q_{\lambda}=(1-\lambda)Q_0+\lambda Q_1$ . Then

$$(1 - \lambda) \ln Q_0(p_0 > 0) + \lambda \ln Q_1(p_1 > 0)$$

$$\leq \ln ((1 - \lambda) Q_0(p_0 > 0) + \lambda Q_1(p_1 > 0))$$

$$\leq \ln Q_\lambda(p_0 > 0 \text{ or } p_1 > 0) = \ln Q_\lambda(p_\lambda > 0).$$

Equality holds if and only if, for the first inequality,  $Q_0(p_0 > 0) = Q_1(p_1 > 0)$  and, for the second inequality,  $p_1 > 0 \Rightarrow p_0 > 0$  ( $Q_0$ -a.s.) and  $p_0 > 0 \Rightarrow p_1 > 0$  ( $Q_1$ -a.s.) These conditions are equivalent to the equality conditions of the theorem.

Alternatively, suppose  $\alpha > 0$ . We will show that point-wise

<span id="page-8-1"></span>
$$(1 - \lambda)p_0^{\alpha}q_0^{1-\alpha} + \lambda p_1^{\alpha}q_1^{1-\alpha} \le p_{\lambda}^{\alpha}q_{\lambda}^{1-\alpha} \qquad (0 < \alpha < 1);$$
  
$$(1 - \lambda)p_0 \ln \frac{p_0}{q_0} + \lambda p_1 \ln \frac{p_1}{q_1} \ge p_{\lambda} \ln \frac{p_{\lambda}}{q_{\lambda}} \qquad (\alpha = 1),$$
  
$$(24)$$

where  $p_{\lambda} = (1 - \lambda)p_0 + \lambda p_1$  and  $q_{\lambda} = (1 - \lambda)q_0 + \lambda q_1$ . For  $\alpha = 1$ , (23) then follows directly; for  $0 < \alpha < 1$ , (23) follows from (24) by Jensen's inequality:

$$(1 - \lambda) \ln \int p_0^{\alpha} q_0^{1-\alpha} d\mu + \lambda \ln \int p_1^{\alpha} q_1^{1-\alpha} d\mu$$

$$\leq \ln \left( (1 - \lambda) \int p_0^{\alpha} q_0^{1-\alpha} d\mu + \lambda \int p_1^{\alpha} q_1^{1-\alpha} d\mu \right). \quad (25)$$

If one of  $p_0,p_1,q_0$  and  $q_1$  is zero, then (24) can be verified directly. So assume that they are all positive. Then for  $0<\alpha<1$  let  $f(x)=-x^\alpha$  and for  $\alpha=1$  let  $f(x)=x\ln x$ , such that (24) can be written as

$$\frac{(1-\lambda)q_0}{q_\lambda}f\left(\frac{p_0}{q_0}\right) + \frac{\lambda q_1}{q_\lambda}f\left(\frac{p_1}{q_1}\right) \geq f\left(\frac{p_\lambda}{q_\lambda}\right).$$

(24) is established by recognising this as an application of Jensen's inequality to the strictly convex function f. Regardless of whether any of  $p_0, p_1, q_0$  and  $q_1$  is zero, equality holds in (24) if and only if  $p_0q_1=p_1q_0$ . Equality holds in (25) if and only if  $\int p_0^{\alpha}q_0^{1-\alpha}\,\mathrm{d}\mu=\int p_1^{\alpha}q_1^{1-\alpha}\,\mathrm{d}\mu$ , which is equivalent to  $D_{\alpha}(P_0\|Q_0)=D_{\alpha}(P_1\|Q_1)$ .

Joint convexity in P and Q breaks down for  $\alpha>1$  (see Section VI-A), but some partial convexity properties can still be salvaged. First, convexity in the second argument does hold for all  $\alpha$  [4]:

**Theorem 12.** For any order  $\alpha \in [0, \infty]$  Rényi divergence is convex in its second argument. That is, for any probability distributions P,  $Q_0$  and  $Q_1$ 

<span id="page-8-3"></span>
$$D_{\alpha}(P\|(1-\lambda)Q_0 + \lambda Q_1) \le (1-\lambda)D_{\alpha}(P\|Q_0) + \lambda D_{\alpha}(P\|Q_1)$$
(26)

for any  $0 < \lambda < 1$ . For finite  $\alpha$ , equality holds if and only if

$$\alpha = 0 \colon D_0(P\|Q_0) = D_0(P\|Q_1);$$
 
$$0 < \alpha < \infty \colon q_0 = q_1 \ (P\text{-}a.s.)$$

*Proof:* For  $\alpha \in [0,1]$  this follows from the previous theorem. (For  $P_0 = P_1$  the equality conditions reduce to the ones given here.) For  $\alpha \in (1,\infty)$ , let  $Q_\lambda = (1-\lambda)Q_0 + \lambda Q_1$  and define  $f(x,Q_\lambda) = (p(x)/q_\lambda(x))^{\alpha-1}$ . It is sufficient to show that

$$\ln \mathbf{E}_{X \sim P}[f(X, Q_{\lambda})] 
\leq (1 - \lambda) \ln \mathbf{E}_{X \sim P}[f(X, Q_{0})] + \lambda \ln \mathbf{E}_{X \sim P}[f(X, Q_{1})].$$

Noting that, for every  $x \in \mathcal{X}$ , f(x, Q) is log-convex in Q, this is a consequence of the general fact that an expectation over log-convex functions is itself log-convex, which can be shown using Hölder's inequality:

$$\mathbf{E}_{P}[f(X,Q_{\lambda})] \leq \mathbf{E}_{P}[f(X,Q_{0})^{1-\lambda}f(X,Q_{1})^{\lambda}]$$
  
$$\leq \mathbf{E}_{P}[f(X,Q_{0})]^{1-\lambda}\mathbf{E}_{P}[f(X,Q_{1})]^{\lambda}.$$

Taking logarithms completes the proof of (26). Equality holds in the first inequality if and only if  $q_0 = q_1$  (P-a.s.), which is also sufficient for equality in the second inequality. Finally, (26) extends to  $\alpha = \infty$  by letting  $\alpha$  tend to  $\infty$ .

And secondly, Rényi divergence is jointly *quasi-convex* in both arguments for all  $\alpha$ :

<span id="page-8-0"></span>**Theorem 13.** For any order  $\alpha \in [0, \infty]$  Rényi divergence is jointly quasi-convex in its arguments. That is, for any two pairs of probability distributions  $(P_0, Q_0)$  and  $(P_1, Q_1)$ , and any  $\lambda \in (0, 1)$ 

$$D_{\alpha} ((1 - \lambda) P_0 + \lambda P_1 \| (1 - \lambda) Q_0 + \lambda Q_1)$$

$$\leq \max\{ D_{\alpha} (P_0 \| Q_0), D_{\alpha} (P_1 \| Q_1) \}.$$
(27)

<span id="page-8-2"></span>*Proof:* For  $\alpha \in [0,1]$ , quasi-convexity is implied by convexity. For  $\alpha \in (1,\infty)$ , strict monotonicity of  $x \mapsto \frac{1}{\alpha-1} \ln x$  implies that quasi-convexity is equivalent to quasi-convexity of the Hellinger integral  $\int p^{\alpha}q^{1-\alpha} \, \mathrm{d}\mu$ . Since quasi-convexity is implied by ordinary convexity, it is sufficient to establish that the Hellinger integral is jointly convex in P and Q. Let  $p_{\lambda} = (1-\lambda)p_0 + \lambda p_1$  and  $q_{\lambda} = (1-\lambda)q_0 + \lambda q_1$ . Then joint convexity of the Hellinger integral is implied by the pointwise inequality

$$(1-\lambda)p_0^\alpha q_0^{1-\alpha} + \lambda p_1^\alpha q_1^{1-\alpha} \geq p_\lambda^\alpha q_\lambda^{1-\alpha},$$

which holds by essentially the same argument as for (24) in the proof of Theorem 11, with the convex function  $f(x) = x^{\alpha}$ .

Finally, the case  $\alpha = \infty$  follows by letting  $\alpha$  tend to  $\infty$ :

$$\begin{split} D_{\infty} \big( (1 - \lambda) P_0 + \lambda P_1 \| (1 - \lambda) Q_0 + \lambda Q_1 \big) \\ &= \sup_{\alpha < \infty} D_{\alpha} \big( (1 - \lambda) P_0 + \lambda P_1 \| (1 - \lambda) Q_0 + \lambda Q_1 \big) \\ &\leq \sup_{\alpha < \infty} \max \{ D_{\alpha} (P_0 \| Q_0), D_{\alpha} (P_1 \| Q_1) \} \\ &= \max \{ \sup_{\alpha < \infty} D_{\alpha} (P_0 \| Q_0), \sup_{\alpha < \infty} D_{\alpha} (P_1 \| Q_1) \} \\ &= \max \{ D_{\infty} (P_0 \| Q_0), D_{\infty} (P_1 \| Q_1) \}. \end{split}$$

#### C. A Generalized Pythagorean Inequality

An important result in statistical applications of information theory is the Pythagorean inequality for Kullback-Leibler divergence [30]–[32]. It states that, if  $\mathcal{P}$  is a convex set of distributions, Q is any distribution not in  $\mathcal{P}$ , and  $D_{\min} = \inf_{P \in \mathcal{P}} D(P||Q)$ , then there exists a distribution  $P^*$  such that

$$D(P||Q) \ge D(P||P^*) + D_{\min}$$
 for all  $P \in \mathcal{P}$ . (28)

The main use of the Pythagorean inequality lies in its implication that if  $P_1, P_2, \ldots$  is a sequence of distributions in  $\mathcal P$  such that  $D(P_n\|Q) \to D_{\min}$ , then  $P_n$  converges to  $P^*$  in the strong sense that  $D(P_n\|P^*) \to 0$ .

For  $\alpha \neq 1$  Rényi divergence does not satisfy the ordinary Pythagorean inequality, but there does exist a generalization if we replace convexity of  $\mathcal{P}$  by the following alternative notion of convexity:

**Definition 4.** For  $\alpha \in (0, \infty)$ , we will call a set of distributions  $\mathcal{P}$   $\alpha$ -convex if, for any probability distribution  $\lambda = (\lambda_1, \lambda_2)$  and any two distributions  $P_1, P_2 \in \mathcal{P}$ , we also have  $P_{\lambda} \in \mathcal{P}$ , where  $P_{\lambda}$  is the  $(\alpha, \lambda)$ -mixture of  $P_1$  and  $P_2$ , which will be defined below.

For  $\alpha=1$ , the  $(\alpha,\lambda)$ -mixture is simply the ordinary mixture  $\lambda_1P_1+\lambda_2P_2$ , so that 1-convexity is equivalent to ordinary convexity. We generalize this to other  $\alpha$  as follows:

**Definition 5.** Let  $\alpha \in (0,\infty)$  and let  $P_1,\ldots,P_m$  be any probability distributions. Then for any probability distribution  $\lambda = (\lambda_1,\ldots,\lambda_m)$  we define the  $(\alpha,\lambda)$ -mixture  $P_\lambda$  of  $P_1,\ldots,P_m$  as the distribution with density

<span id="page-9-1"></span>
$$p_{\lambda} = \frac{\left(\sum_{\theta=1}^{m} \lambda_{\theta} p_{\theta}^{\alpha}\right)^{1/\alpha}}{Z}, \text{ where } Z = \int \left(\sum_{\theta=1}^{m} \lambda_{\theta} p_{\theta}^{\alpha}\right)^{1/\alpha} d\mu$$
(29)

is a normalizing constant.

The normalizing constant Z is always well defined:

<span id="page-9-2"></span>**Lemma 3.** The normalizing constant Z in (29) is bounded by

$$Z \in \begin{cases} [m^{-(1-\alpha)/\alpha}, 1] & \text{for } \alpha \in (0, 1], \\ [1, m^{(\alpha-1)/\alpha}] & \text{for } \alpha \in [1, \infty). \end{cases}$$
 (30)

*Proof:* For  $\alpha=1$ , we have Z=1, as required. So it remains to consider the simple orders. Let  $f(y)=y^{1/\alpha}$  for  $y\geq 0$ , so that  $Z=\int f\left(\sum_{\theta}\lambda_{\theta}p_{\theta}^{\alpha}\right)\mathrm{d}\mu$ . Suppose first that  $\alpha\in(0,1)$ . Then f is convex, which implies that  $f(a+b)-f(a)\geq f(b)-f(0)=f(b)$  for any a,b, so that, by induction,  $f\left(\sum_{\theta}a_{\theta}\right)\geq\sum_{\theta}f(a_{\theta})$  for any  $a_{\theta}$ . Taking  $a_{\theta}=\lambda_{\theta}p_{\theta}^{\alpha}$  and using Jensen's inequality, we find:

$$\sum_{\theta} f\left(\lambda_{\theta} p_{\theta}^{\alpha}\right) \leq f\left(\sum_{\theta} \lambda_{\theta} p_{\theta}^{\alpha}\right) \leq \sum_{\theta} \lambda_{\theta} f(p_{\theta}^{\alpha})$$
$$\sum_{\theta} \lambda_{\theta}^{1/\alpha} p_{\theta} \leq \left(\sum_{\theta} \lambda_{\theta} p_{\theta}^{\alpha}\right)^{1/\alpha} \leq \sum_{\theta} \lambda_{\theta} p_{\theta}.$$

Since every  $p_{\theta}$  integrates to 1, it follows that

$$\sum_{\theta} \lambda_{\theta}^{1/\alpha} \le Z_{\lambda} \le 1.$$

The left-hand side is minimized at  $\lambda=1/m$ , where it equals  $m^{-(1-\alpha)/\alpha}$ , which completes the proof for  $\alpha\in(0,1)$ . The proof for  $\alpha\in(1,\infty)$  goes the same way, except that all inequalities are reversed because f is concave.

And, like for  $\alpha = 1$ , the set of  $(\alpha, \lambda)$ -mixtures is closed under taking further mixtures of its elements:

**Lemma 4.** Let  $\alpha \in (0, \infty)$ , let  $P_1, \ldots, P_m$  be arbitrary probability distributions and let  $P_{\lambda_1}$  and  $P_{\lambda_2}$  be their  $(\alpha, \lambda_1)$ -and  $(\alpha, \lambda_2)$ -mixtures for some distributions  $\lambda_1, \lambda_2$ . Then, for any distribution  $\gamma = (\gamma_1, \gamma_2)$ , the  $(\alpha, \gamma)$ -mixture of  $P_{\lambda_1}$  and  $P_{\lambda_2}$  is an  $(\alpha, \nu)$ -mixture of  $P_1, \ldots, P_m$  for the distribution  $\nu$  such that

$$\nu = \frac{\gamma_1}{Z_1^{\alpha}C}\lambda_1 + \frac{\gamma_2}{Z_2^{\alpha}C}\lambda_2,\tag{31}$$

where  $C=\frac{\gamma_1}{Z_1^{\alpha}}+\frac{\gamma_2}{Z_2^{\alpha}}$ , and  $Z_1$  and  $Z_2$  are the normalizing constants of  $P_{\lambda_1}$  and  $P_{\lambda_2}$  as defined in (29).

*Proof:* Let  $M_{\gamma}$  be the  $(\alpha, \gamma)$ -mixture of  $P_{\lambda_1}$  and  $P_{\lambda_2}$ , and take  $\lambda_i = (\lambda_{i,1}, \dots, \lambda_{i,m})$ . Then

$$\begin{split} m_{\gamma} &\propto \left(\gamma_{1} p_{\lambda_{1}}^{\alpha} + \gamma_{2} p_{\lambda_{2}}^{\alpha}\right)^{1/\alpha} \\ &= \left(\frac{\gamma_{1}}{Z_{1}^{\alpha}} \sum_{\theta} \lambda_{1,\theta} p_{\theta}^{\alpha} + \frac{\gamma_{2}}{Z_{2}^{\alpha}} \sum_{\theta} \lambda_{2,\theta} p_{\theta}^{\alpha}\right)^{1/\alpha} \\ &\propto \left(\sum_{\theta} \frac{\frac{\gamma_{1} \lambda_{1,\theta}}{Z_{1}^{\alpha}} + \frac{\gamma_{2} \lambda_{2,\theta}}{Z_{2}^{\alpha}}}{C} p_{\theta}^{\alpha}\right)^{1/\alpha}, \end{split}$$

from which the result follows.

We are now ready to generalize the Pythagorean inequality to any  $\alpha \in (0, \infty)$ :

<span id="page-9-0"></span>**Theorem 14** (Pythagorean Inequality). Let  $\alpha \in (0, \infty)$ . Suppose that  $\mathcal{P}$  is an  $\alpha$ -convex set of distributions. Let Q be an arbitrary distribution and suppose that the  $\alpha$ -information projection

$$P^* = \underset{P \in \mathcal{P}}{\arg\min} \, D_{\alpha}(P \| Q) \tag{32}$$

exists. Then we have the Pythagorean inequality

<span id="page-9-3"></span>
$$D_{\alpha}(P||Q) \ge D_{\alpha}(P||P^*) + D_{\alpha}(P^*||Q) \quad \text{for all } P \in \mathcal{P}.$$
(33)

This result is new, although the work of Sundaresan on a generalization of Rényi divergence might be related [33], [34]. Our proof follows the same approach as the proof for  $\alpha=1$  by Cover and Thomas [30].

*Proof:* For  $\alpha=1$ , this is just the standard Pythagorean inequality for Kullback-Leibler divergence. See, for example, the proof by Topsøe [32]. It remains to prove the theorem when  $\alpha$  is a simple order.

Let  $P \in \mathcal{P}$  be arbitrary, and let  $P_{\lambda}$  be the  $(\alpha, (1 - \lambda, \lambda))$ -mixture of  $P^*$  and P. Since  $\mathcal{P}$  is  $\alpha$ -convex and  $P^*$  is the minimizer over  $\mathcal{P}$ , we have  $\frac{\mathrm{d}}{\mathrm{d}\lambda}D_{\alpha}(P_{\lambda}\|Q)\big|_{\lambda=0} \geq 0$ .

This derivative evaluates to:

$$\frac{\mathrm{d}}{\mathrm{d}\lambda} D_{\alpha}(P_{\lambda} || Q) = \frac{1}{\alpha - 1} \frac{\int p^{\alpha} q^{1 - \alpha} \mathrm{d}\mu - \int (p^{*})^{\alpha} q^{1 - \alpha} \mathrm{d}\mu}{Z_{\lambda}^{\alpha} \int p_{\lambda}^{\alpha} q^{1 - \alpha} \mathrm{d}\mu} - \frac{\alpha}{\alpha - 1} \frac{(1 - \lambda) \int (p^{*})^{\alpha} q^{1 - \alpha} \mathrm{d}\mu + \lambda \int p^{\alpha} q^{1 - \alpha} \mathrm{d}\mu}{Z_{\lambda}^{\alpha + 1} \int p_{\lambda}^{\alpha} q^{1 - \alpha} \mathrm{d}\mu} \frac{\mathrm{d}}{\mathrm{d}\lambda} Z_{\lambda}.$$

Let  $X_{\lambda}=\left((1-\lambda)(p^*)^{\alpha}+\lambda p^{\alpha}\right)^{1/\alpha}$ , so that  $Z_{\lambda}=\int X_{\lambda}\mathrm{d}\mu$ . If  $\alpha\in(0,1)$ , then  $X_{\lambda}$  is convex in  $\lambda$  so that  $\frac{X_{\lambda}-X_{0}}{\lambda}$  is nondecreasing in  $\lambda$ , and if  $\alpha\in(0,\infty)$ , then  $X_{\lambda}$  is concave in  $\lambda$  so that  $\frac{X_{\lambda}-X_{0}}{\lambda}$  is nonincreasing. By Lemma 3, we also see that  $\int \frac{X_{\lambda}-X_{0}}{\lambda}\mathrm{d}\mu=\frac{Z_{\lambda}-1}{\lambda}$  is bounded by 0 for  $\lambda>0$ , from above if  $\alpha\in(0,1)$  and from below if  $\alpha\in(1,\infty)$ . It therefore follows from the monotone convergence theorem that

$$\frac{\mathrm{d}}{\mathrm{d}\lambda} Z_{\lambda} \big|_{\lambda=0} = \lim_{\lambda \downarrow 0} \frac{Z_{\lambda} - Z_{0}}{\lambda} = \lim_{\lambda \downarrow 0} \int \frac{X_{\lambda} - X_{0}}{\lambda} \mathrm{d}\mu$$
$$= \int \lim_{\lambda \downarrow 0} \frac{X_{\lambda} - X_{0}}{\lambda} \mathrm{d}\mu = \int \frac{\mathrm{d}}{\mathrm{d}\lambda} X_{\lambda} \big|_{\lambda=0} \mathrm{d}\mu,$$

where

$$\frac{\mathrm{d}}{\mathrm{d}\lambda}X_{\lambda} = \frac{1}{\alpha}\Big((1-\lambda)(p^*)^{\alpha} + \lambda p^{\alpha}\Big)^{1/\alpha - 1}(p^{\alpha} - (p^*)^{\alpha}).$$

If  $D_{\alpha}(P^*||Q) = \infty$ , then the theorem is trivially true, so we may assume without loss of generality that  $D_{\alpha}(P^*||Q) < \infty$ , which implies that  $0 < \int (p^*)^{\alpha} q^{1-\alpha} d\mu < \infty$ .

Putting everything together, we therefore find

$$\begin{split} 0 &\leq \frac{\mathrm{d}}{\mathrm{d}\lambda} D_{\alpha}(P_{\lambda} \| Q) \big|_{\lambda=0} \\ &= \frac{1}{\alpha - 1} \frac{\int p^{\alpha} q^{1-\alpha} \mathrm{d}\mu - \int (p^*)^{\alpha} q^{1-\alpha} \mathrm{d}\mu}{\int (p^*)^{\alpha} q^{1-\alpha} \mathrm{d}\mu} \\ &- \frac{1}{\alpha - 1} \int (p^*)^{1-\alpha} (p^{\alpha} - (p^*)^{\alpha}) \mathrm{d}\mu \\ &= \frac{1}{\alpha - 1} \Big( \frac{\int p^{\alpha} q^{1-\alpha} \mathrm{d}\mu}{\int (p^*)^{\alpha} q^{1-\alpha} \mathrm{d}\mu} - \int (p^*)^{1-\alpha} p^{\alpha} \mathrm{d}\mu \Big). \end{split}$$

Hence, if  $\alpha > 1$  we have

$$\int p^{\alpha} q^{1-\alpha} d\mu \ge \int (p^*)^{\alpha} q^{1-\alpha} d\mu \int (p^*)^{1-\alpha} p^{\alpha} d\mu,$$

and if  $\alpha < 1$  we have the converse of this inequality. In both cases, the Pythagorean inequality (33) follows upon taking logarithms and dividing by  $\alpha - 1$  (which flips the inequality sign for  $\alpha < 1$ ).

## D. Continuity

In this section we study continuity properties of the Rényi divergence  $D_{\alpha}(P||Q)$  of different orders in the pair of probability distributions (P,Q). It turns out that continuity depends on the order  $\alpha$  and the topology on the set of all probability distributions.

The set of probability distributions on  $(\mathcal{X}, \mathcal{F})$  may be equipped with the topology of *setwise convergence*, which is the coarsest topology such that, for any event  $A \in \mathcal{F}$ , the function  $P \mapsto P(A)$  that maps a distribution to its probability on A, is continuous. In this topology, convergence of a sequence of probability distributions  $P_1, P_2, \ldots$  to a probability distribution P means that  $P_n(A) \to P(A)$  for any  $A \in \mathcal{F}$ .

Alternatively, one might consider the topology defined by the *total variation distance* 

<span id="page-10-3"></span>
$$V(P,Q) = \int |p - q| \, d\mu = 2 \sup_{A \in \mathcal{F}} |P(A) - Q(A)|, \quad (34)$$

in which  $P_n \to P$  means that  $V(P_n,P) \to 0$ . The total variation topology is stronger than the topology of setwise

convergence in the sense that convergence in total variation distance implies convergence on any  $A \in \mathcal{F}$ . The two topologies coincide if the sample space  $\mathcal{X}$  is countable.

In general, Rényi divergence is lower semi-continuous for positive orders:

<span id="page-10-1"></span>**Theorem 15.** For any order  $\alpha \in (0, \infty]$ ,  $D_{\alpha}(P||Q)$  is a lower semi-continuous function of the pair (P,Q) in the topology of setwise convergence.

*Proof:* Suppose  $\mathcal{X} = \{x_1, \dots, x_k\}$  is finite. Then for any simple order  $\alpha$ 

$$D_{\alpha}(P||Q) = \frac{1}{\alpha - 1} \ln \sum_{i=1}^{k} p_{i}^{\alpha} q_{i}^{1 - \alpha},$$

where  $p_i=P(x_i)$  and  $q_i=Q(x_i)$ . If  $0<\alpha<1$ , then  $p_i^{\alpha}q_i^{1-\alpha}$  is continuous in (P,Q). For  $1<\alpha<\infty$ , it is only discontinuous at  $p_i=q_i=0$ , but there  $p_i^{\alpha}q_i^{1-\alpha}=0=\min_{(P,Q)}p_i^{\alpha}q_i^{1-\alpha}$ , so then  $p_i^{\alpha}q_i^{1-\alpha}$  is still lower semi-continuous. These properties carry over to  $\sum_{i=1}^k p_i^{\alpha}q_i^{1-\alpha}$  and thus  $D_{\alpha}(P\|Q)$  is continuous for  $0<\alpha<1$  and lower semi-continuous for  $\alpha>1$ . A supremum over (lower semi-)continuous functions is itself lower semi-continuous. Therefore, for simple orders  $\alpha$ , Theorem 2 implies that  $D_{\alpha}(P\|Q)$  is lower semi-continuous for arbitrary  $\mathcal{X}$ . This property extends to the extended orders 1 and  $\infty$  by  $D_{\beta}(P\|Q)=\sup_{\alpha<\beta}D_{\alpha}(P\|Q)$  for  $\beta\in\{1,\infty\}$ .

Moreover, if  $\alpha \in (0,1)$  and the total variation topology is assumed, then Theorem 17 below shows that Rényi divergence is uniformly continuous.

First we prove that the topologies induced by Rényi divergences of orders  $\alpha \in (0,1)$  are all equivalent:

<span id="page-10-2"></span>**Theorem 16.** For any  $0 < \alpha \le \beta < 1$ 

$$\frac{\alpha}{\beta} \frac{1-\beta}{1-\alpha} D_{\beta}(P||Q) \le D_{\alpha}(P||Q) \le D_{\beta}(P||Q).$$

This follows from the following symmetry-like property, which may be verified directly.

<span id="page-10-0"></span>**Proposition 2** (Skew Symmetry). For any  $0 < \alpha < 1$ 

$$D_{\alpha}(P||Q) = \frac{\alpha}{1-\alpha} D_{1-\alpha}(Q||P).$$

Note that, in particular, Rényi divergence is symmetric for  $\alpha=1/2$ , but that skew symmetry does not hold for  $\alpha=0$  and  $\alpha=1$ .

*Proof of Theorem 16:* We have already established the second inequality in Theorem 3, so it remains to prove the first one. Skew symmetry implies that

$$\frac{1-\alpha}{\alpha}D_{\alpha}(P\|Q) = D_{1-\alpha}(Q\|P)$$

$$\geq D_{1-\beta}(Q\|P) = \frac{1-\beta}{\beta}D_{\beta}(P\|Q),$$

from which the result follows.

Remark 2. By (5), these results show that, for  $\alpha \in (0,1)$ ,  $D_{\alpha}(P_n || Q) \to 0$  is equivalent to convergence of  $P_n$  to Q in Hellinger distance, which is equivalent to convergence of  $P_n$  to Q in total variation [28, p. 364].

Next we shall prove a stronger result on the relation between Rényi divergence and total variation.

<span id="page-11-1"></span>**Theorem 17.** For  $\alpha \in (0,1)$ , the Rényi divergence  $D_{\alpha}(P||Q)$  is a uniformly continuous function of (P,Q) in the total variation topology.

<span id="page-11-4"></span>**Lemma 5.** Let  $0 < \alpha < 1$ . Then for all  $x, y \ge 0$  and  $\varepsilon > 0$ 

$$|x^{\alpha} - y^{\alpha}| \le \varepsilon^{\alpha} + \varepsilon^{\alpha - 1}|x - y|.$$

*Proof:* If  $x, y \le \varepsilon$  or x = y the inequality  $|x^{\alpha} - y^{\alpha}| \le \varepsilon^{\alpha}$  is obvious. So assume that x > y and  $x > \varepsilon$ . Then

$$\frac{|x^{\alpha} - y^{\alpha}|}{|x - y|} \le \frac{|x^{\alpha} - 0^{\alpha}|}{|x - 0|} = x^{\alpha - 1} \le \varepsilon^{\alpha - 1}.$$

Proof of Theorem 17: First note that Rényi divergence is a function of the power divergence  $d_{\alpha}(P,Q) = \int \left(1-\left(\frac{\mathrm{d}P}{\mathrm{d}Q}\right)^{\alpha}\right)\mathrm{d}Q$ :

$$D_{\alpha}(P||Q) = \frac{1}{\alpha - 1} \ln \left( 1 - d_{\alpha}(P, Q) \right).$$

Since  $x\mapsto \frac{1}{\alpha-1}\ln(1-x)$  is continuous, it is sufficient to prove that  $d_\alpha(P,Q)$  is a uniformly continuous function of (P,Q). For any  $\varepsilon>0$  and distributions  $P_1,P_2$  and Q, Lemma 5 implies that

$$|d_{\alpha}(P_{1}, Q) - d_{\alpha}(P_{2}, Q)| \leq \int \left| \left( \frac{dP_{1}}{dQ} \right)^{\alpha} - \left( \frac{dP_{2}}{dQ} \right)^{\alpha} \right| dQ$$

$$\leq \int \left( \varepsilon^{\alpha} + \varepsilon^{\alpha - 1} \left| \frac{dP_{1}}{dQ} - \frac{dP_{2}}{dQ} \right| \right) dQ$$

$$= \varepsilon^{\alpha} + \varepsilon^{\alpha - 1} \int \left| \frac{dP_{1}}{dQ} - \frac{dP_{2}}{dQ} \right| dQ$$

$$= \varepsilon^{\alpha} + \varepsilon^{\alpha - 1} V(P_{1}, P_{2}).$$

As  $d_{\alpha}(P,Q)=d_{1-\alpha}(Q,P)$ , it also follows that  $|d_{\alpha}(P,Q_1)-d_{\alpha}(P,Q_2)|\leq \varepsilon^{1-\alpha}+\varepsilon^{-\alpha}V(Q_1,Q_2)$  for any  $Q_1,Q_2$  and P. Therefore

$$\begin{aligned} |d_{\alpha}(P_{1}, Q_{1}) - d_{\alpha}(P_{2}, Q_{2})| \\ &\leq |d_{\alpha}(P_{1}, Q_{1}) - d_{\alpha}(P_{2}, Q_{1})| \\ &+ |d_{\alpha}(P_{2}, Q_{1}) - d_{\alpha}(P_{2}, Q_{2})| \\ &\leq \varepsilon^{\alpha} + \varepsilon^{\alpha - 1}V(P_{1}, P_{2}) + \varepsilon^{1 - \alpha} + \varepsilon^{-\alpha}V(Q_{1}, Q_{2}), \end{aligned}$$

from which the theorem follows.

A partial extension to  $\alpha = 0$  follows:

<span id="page-11-2"></span>**Corollary 1.** The Rényi divergence  $D_0(P||Q)$  is an upper semi-continuous function of (P,Q) in the total variation topology.

*Proof:* This follows from Theorem 17 because  $D_0(P||Q)$  is the infimum of the continuous functions  $(P,Q) \mapsto D_{\alpha}(P||Q)$  for  $\alpha \in (0,1)$ .

If we consider continuity in Q only, then for any finite sample space we obtain:

<span id="page-11-0"></span>**Theorem 18.** Suppose  $\mathcal{X}$  is finite, and let  $\alpha \in [0, \infty]$ . Then for any P the Rényi divergence  $D_{\alpha}(P||Q)$  is continuous in Q in the topology of setwise convergence.

*Proof:* Directly from the closed-form expressions for Rényi divergence.

Finally, we will also consider the *weak topology*, which is weaker than the two topologies discussed above. In the weak topology, convergence of  $P_1, P_2, \ldots$  to P means that

<span id="page-11-5"></span>
$$\int f(x) dP_n(x) \to \int f(x) dP(x)$$
 (35)

for any bounded, continuous function  $f\colon \mathcal{X} \to \mathbb{R}$ . Unlike for the previous two topologies, the reference to continuity of f means that the weak topology depends on the topology of the sample space  $\mathcal{X}$ . We will therefore assume that  $\mathcal{X}$  is a *Polish space* (that is, it should be a complete separable metric space), and we let  $\mathcal{F}$  be the Borel  $\sigma$ -algebra. Then Prokhorov [35] shows that there exists a metric that makes the set of finite measures on  $\mathcal{X}$  a Polish space as well, and which is such that convergence in the metric is equivalent to (35). The weak topology then, is the topology induced by this metric.

<span id="page-11-3"></span>**Theorem 19.** Suppose that  $\mathcal{X}$  is a Polish space. Then for any order  $\alpha \in (0, \infty]$ ,  $D_{\alpha}(P||Q)$  is a lower semi-continuous function of the pair (P, Q) in the weak topology.

The proof is essentially the same as the proof for  $\alpha = 1$  by Posner [36].

*Proof:* Let  $P_1, P_2, \ldots$  and  $Q_1, Q_2, \ldots$  be sequences of distributions that weakly converge to P and Q, respectively. We need to show that

<span id="page-11-6"></span>
$$\liminf_{n \to \infty} D_{\alpha}(P_n || Q_n) \ge D_{\alpha}(P || Q). \tag{36}$$

For any set  $A \in \mathcal{F}$ , let  $\partial A$  denote its boundary, which is its closure minus its interior, and let  $\mathcal{F}_0 \subseteq \mathcal{F}$  consist of the sets  $A \in \mathcal{F}$  such that  $P(\partial A) = Q(\partial A) = 0$ . Then  $\mathcal{F}_0$  is an algebra by Lemma 1.1 of Prokhorov [35], applied to the measure P+Q, and the Portmanteau theorem implies that  $P_n(A) \to P(A)$  and  $Q_n(A) \to Q(A)$  for any  $A \in \mathcal{F}_0$  [37].

Posner [36, proof of Theorem 1] shows that  $\mathcal{F}_0$  generates  $\mathcal{F}$  (that is,  $\sigma(\mathcal{F}_0) = \mathcal{F}$ ). By the translator's proof of Theorem 2.4.1 in Pinsker's book [38], this implies that, for any finite partition  $\{A_1,\ldots,A_k\}\subseteq\mathcal{F}$  and any  $\gamma>0$ , there exists a finite partition  $\{A'_1,\ldots,A'_k\}\subseteq\mathcal{F}_0$  such that  $P(A_i\triangle A'_i)\leq\gamma$  and  $Q(A_i\triangle A'_i)\leq\gamma$  for all i, where  $A_i\triangle A'_i=(A_i\setminus A'_i)\cup(A'_i\setminus A_i)$  denotes the symmetric set difference. By the data processing inequality and lower semi-continuity in the topology of setwise convergence, this implies that (15) still holds when the supremum is restricted to finite partitions  $\mathcal{P}$  in  $\mathcal{F}_0$  instead of  $\mathcal{F}$ .

Thus, for any  $\varepsilon>0$ , we can find a finite partition  $\mathcal{P}\subseteq\mathcal{F}_0$  such that

$$D_{\alpha}(P_{|\mathcal{P}}||Q_{|\mathcal{P}}) \ge D_{\alpha}(P||Q) - \varepsilon.$$

The data processing inequality and the fact that  $P_n(A) \to P(A)$  and  $Q_n(A) \to Q(A)$  for all  $A \in \mathcal{P}$ , together with lower semi-continuity in the topology of setwise convergence, then imply that

$$D_{\alpha}(P_n || Q_n) \ge D_{\alpha}((P_n)_{|\mathcal{P}} || (Q_n)_{|\mathcal{P}})$$
  
 
$$\ge D_{\alpha}(P_{|\mathcal{P}} || Q_{|\mathcal{P}}) - \varepsilon \ge D_{\alpha}(P || Q) - 2\varepsilon$$

for all sufficiently large n. Consequently,

$$\liminf_{n \to \infty} D_{\alpha}(P_n || Q_n) \ge D_{\alpha}(P || Q) - 2\varepsilon$$

for any  $\varepsilon > 0$ , and (36) follows by letting  $\varepsilon$  tend to 0.

<span id="page-12-0"></span>**Theorem 20** (Compact Sublevel Sets). Suppose  $\mathcal{X}$  is a Polish space, let Q be arbitrary, and let  $c \in [0, \infty)$  be a constant. Then the sublevel set

$$S = \{ P \mid D_{\alpha}(P||Q) \le c \} \tag{37}$$

is convex and compact in the topology of weak convergence for any order  $\alpha \in [1, \infty]$ .

*Proof:* Convexity follows from quasi-convexity of Rényi divergence in its first argument.

Suppose that  $P_1, P_2, \ldots \in \mathcal{S}$  converges to a finite measure P. Then (35), applied to the constant function f(x) = 1, implies that  $P(\mathcal{X}) = 1$ , so that P is also a probability distribution. Hence by lower semi-continuity (Theorem 19)  $\mathcal{S}$  is closed. It is therefore sufficient to show that  $\mathcal{S}$  is relatively compact.

For any event  $A \in \mathcal{F}$ , let  $A^c = \mathcal{X} \setminus A$  denote its complement. Prokhorov [35, Theorem 1.12] shows that  $\mathcal{S}$  is relatively compact if, for any  $\varepsilon > 0$ , there exists a compact set  $A \subseteq \mathcal{X}$  such that  $P(A^c) < \varepsilon$  for all  $P \in \mathcal{S}$ .

Since  $\mathcal{X}$  is a Polish space, for any  $\delta>0$  there exists a compact set  $B_\delta\subseteq\mathcal{X}$  such that  $Q(B_\delta)\geq 1-\delta$  [37, Lemma 1.3.2]. For any distribution P, let  $P_{|B_\delta}$  denote the restriction of P to the binary partition  $\{B_\delta,B_\delta^{\rm c}\}$ . Then, by monotonicity in  $\alpha$  and the data processing inequality, we have, for any  $P\in\mathcal{S}$ ,

$$\begin{split} c &\geq D_{\alpha}(P\|Q) \geq D_{1}(P\|Q) \geq D_{1}(P_{|B_{\delta}}\|Q_{|B_{\delta}}) \\ &= P(B_{\delta}) \ln \frac{P(B_{\delta})}{Q(B_{\delta})} + P(B_{\delta}^{\mathsf{c}}) \ln \frac{P(B_{\delta}^{\mathsf{c}})}{Q(B_{\delta}^{\mathsf{c}})} \\ &\geq P(B_{\delta}) \ln P(B_{\delta}) + P(B_{\delta}^{\mathsf{c}}) \ln P(B_{\delta}^{\mathsf{c}}) + P(B_{\delta}^{\mathsf{c}}) \ln \frac{1}{Q(B_{\delta}^{\mathsf{c}})} \\ &\geq \frac{-2}{\mathsf{e}} + P(B_{\delta}^{\mathsf{c}}) \ln \frac{1}{Q(B_{\delta}^{\mathsf{c}})}, \end{split}$$

where the last inequality follows from  $x \ln x \ge -1/e$ . Consequently,

$$P(B_{\delta}^{c}) \leq \frac{c + 2/e}{\ln\left(1/Q(B_{\delta}^{c})\right)},$$

and since  $Q(B_{\delta}^{c}) \to 0$  as  $\delta$  tends to 0 we can satisfy the condition of Prokhorov's theorem by taking A equal to  $B_{\delta}$  for any sufficiently small  $\delta$  depending on  $\varepsilon$ .

## E. Limits of $\sigma$ -Algebras

As shown by Theorem 2, there exists a sequence of finite partitions  $\mathcal{P}_1, \mathcal{P}_2, \dots$  such that

<span id="page-12-2"></span>
$$D_{\alpha}(P_{|\mathcal{P}_n} || Q_{|\mathcal{P}_n}) \uparrow D_{\alpha}(P || Q). \tag{38}$$

Theorem 21 below elaborates on this result. It implies that (38) holds for any increasing sequence of partitions  $\mathcal{P}_1 \subseteq \mathcal{P}_2 \subseteq \cdots$  that generate  $\sigma$ -algebras converging to  $\mathcal{F}$ , in the sense that  $\mathcal{F} = \sigma \left( \bigcup_{n=1}^{\infty} \mathcal{P}_n \right)$ . An analogous result holds for infinite sequences of increasingly coarse partitions, which is shown by

Theorem 22. For the special case  $\alpha = 1$ , information-theoretic proofs of Theorems 21 and 22 are given by Barron [39] and Harremoës and Holst [40]. Theorem 21 may also be derived from general properties of f-divergences [27].

<span id="page-12-1"></span>**Theorem 21** (Increasing). Let  $\mathcal{F}_1 \subseteq \mathcal{F}_2 \subseteq \cdots \subseteq \mathcal{F}$  be an increasing family of  $\sigma$ -algebras, and let  $\mathcal{F}_{\infty} = \sigma(\bigcup_{n=1}^{\infty} \mathcal{F}_n)$  be the smallest  $\sigma$ -algebra containing them. Then for any order  $\alpha \in (0,\infty]$ 

<span id="page-12-3"></span>
$$\lim_{n \to \infty} D_{\alpha}(P_{|\mathcal{F}_n} || Q_{|\mathcal{F}_n}) = D_{\alpha}(P_{|\mathcal{F}_\infty} || Q_{|\mathcal{F}_\infty}).$$
 (39)

For  $\alpha = 0$ , (39) does not hold. A counterexample is given after Example 3 below.

<span id="page-12-4"></span>**Lemma 6.** Let  $\mathcal{F}_1 \subseteq \mathcal{F}_2 \subseteq \cdots \subseteq \mathcal{F}$  be an increasing family of  $\sigma$ -algebras, and suppose that  $\mu$  is a probability distribution. Then the family of random variables  $\{p_n\}_{n\geq 1}$  with members  $p_n = \mathbf{E}\left[p|\mathcal{F}_n\right]$  is uniformly integrable (with respect to  $\mu$ ).

The proof of this lemma is a special case of part of the proof of Lévy's upward convergence theorem in Shiryaev's textbook [28, p. 510]. We repeat it here for completeness.

*Proof:* For any constants b, c > 0

$$\int_{p_n > b} p_n \, d\mu = \int_{p_n > b} p \, d\mu$$

$$\leq \int_{p_n > b, p \leq c} p \, d\mu + \int_{p > c} p \, d\mu$$

$$\leq c \cdot \mu (p_n > b) + \int_{p > c} p \, d\mu$$

$$\stackrel{(*)}{\leq} \frac{c}{b} \mathbf{E}[p_n] + \int_{p > c} p \, d\mu = \frac{c}{b} + \int_{p > c} p \, d\mu,$$

in which the inequality marked by (\*) is Markov's. Consequently

$$\begin{split} \lim_{b \to \infty} \sup_{n} \int_{p_n > b} & |p_n| \, \mathrm{d}\mu = \lim_{c \to \infty} \lim_{b \to \infty} \sup_{n} \int_{p_n > b} & |p_n| \, \mathrm{d}\mu \\ & \leq \lim_{c \to \infty} \lim_{b \to \infty} \frac{c}{b} + \lim_{c \to \infty} \int_{p > c} p \, \mathrm{d}\mu = 0, \end{split}$$

which proves the lemma.

Proof of Theorem 21: As by the data processing inequality  $D_{\alpha}(P_{|\mathcal{F}_n}\|Q_{|\mathcal{F}_n}) \leq D_{\alpha}(P\|Q)$  for all n, we only need to show that  $\lim_{n\to\infty} D_{\alpha}(P_{|\mathcal{F}_n}\|Q_{|\mathcal{F}_n}) \geq D_{\alpha}(P_{|\mathcal{F}_\infty}\|Q_{|\mathcal{F}_\infty})$ . To this end, assume without loss of generality that  $\mathcal{F}=\mathcal{F}_\infty$  and that  $\mu$  is a probability distribution (i.e.  $\mu=(P+Q)/2$ ). Let  $p_n=\mathbf{E}[p|\mathcal{F}_n]$  and  $q_n=\mathbf{E}[q|\mathcal{F}_n]$ , and define the distributions  $\tilde{P}_n$  and  $\tilde{Q}_n$  on  $(\mathcal{X},\mathcal{F})$  by

$$\tilde{P}_n(A) = \int_A p_n \, d\mu, \quad \tilde{Q}_n(A) = \int_A q_n \, d\mu \qquad (A \in \mathcal{F}),$$

such that, by the Radon-Nikodým theorem and Proposition 1,  $\frac{\mathrm{d}\tilde{P}_n}{\mathrm{d}\mu}=p_n=\frac{\mathrm{d}P_{\mid\mathcal{F}_n}}{\mathrm{d}\mu_{\mid\mathcal{F}_n}}$  and  $\frac{\mathrm{d}\tilde{Q}_n}{\mathrm{d}\mu}=q_n=\frac{\mathrm{d}Q_{\mid\mathcal{F}_n}}{\mathrm{d}\mu_{\mid\mathcal{F}_n}}$  ( $\mu$ -a.s.) It follows that

$$D_{\alpha}(\tilde{P}_n || \tilde{Q}_n) = D_{\alpha}(P_{|\mathcal{F}_n} || Q_{|\mathcal{F}_n})$$

for  $0<\alpha<\infty$  and therefore by continuity also for  $\alpha=\infty$ . We will proceed to show that  $(\tilde{P}_n,\tilde{Q}_n)\to(P,Q)$  in the topology of setwise convergence. By lower semi-continuity

of Rényi divergence this implies that  $\lim_{n\to\infty}D_{\alpha}(\tilde{P}_n\|\tilde{Q}_n)\geq D_{\alpha}(P\|Q)$ , from which the theorem follows. By Lévy's upward convergence theorem [28, p.510],  $\lim_{n\to\infty}p_n=p$  ( $\mu$ -a.s.) Hence uniform integrability of the family  $\{p_n\}$  (by Lemma 6) implies that for any  $A\in\mathcal{F}$ 

$$\lim_{n \to \infty} \tilde{P}_n(A) = \lim_{n \to \infty} \int_A p_n \, \mathrm{d}\mu = \int_A p \, \mathrm{d}\mu = P(A)$$

[28, Thm. 5, p. 189]. Similarly  $\lim_{n\to\infty} \tilde{Q}_n(A) = Q(A)$ , so we find that  $(\tilde{P}_n, \tilde{Q}_n) \to (P, Q)$ , which completes the proof.

<span id="page-13-1"></span>**Theorem 22** (Decreasing). Let  $\mathcal{F} \supseteq \mathcal{F}_1 \supseteq \mathcal{F}_2 \supseteq \cdots$  be a decreasing family of  $\sigma$ -algebras, and let  $\mathcal{F}_{\infty} = \bigcap_{n=1}^{\infty} \mathcal{F}_n$  be the largest  $\sigma$ -algebra contained in all of them. Let  $\alpha \in [0,\infty)$ . If  $\alpha \in [0,1)$  or there exists an m such that  $D_{\alpha}(P_{|\mathcal{F}_m}||Q_{|\mathcal{F}_m}) < \infty$ , then

$$\lim_{n \to \infty} D_{\alpha}(P_{|\mathcal{F}_n} || Q_{|\mathcal{F}_n}) = D_{\alpha}(P_{|\mathcal{F}_\infty} || Q_{|\mathcal{F}_\infty}).$$

The theorem cannot be extended to the case  $\alpha = \infty$ .

<span id="page-13-3"></span>**Lemma 7.** Let  $\mathcal{F} \supseteq \mathcal{F}_1 \supseteq \mathcal{F}_2 \supseteq \cdots$  be a decreasing family of  $\sigma$ -algebras. Let  $\alpha \in (0,\infty)$ ,  $p_n = \frac{\mathrm{d}P_{\mid \mathcal{F}_n}}{\mathrm{d}\mu_{\mid \mathcal{F}_n}}, q_n = \frac{\mathrm{d}Q_{\mid \mathcal{F}_n}}{\mathrm{d}\mu_{\mid \mathcal{F}_n}},$  and  $X_n = f(\frac{p_n}{q_n})$ , where  $f(x) = x^{\alpha}$  if  $\alpha \neq 1$  and  $f(x) = x \ln x + \mathrm{e}^{-1}$  if  $\alpha = 1$ . If  $\alpha \in (0,1)$ , or  $\mathbf{E}_Q[X_1] < \infty$  and  $P \ll Q$ , then the family  $\{X_n\}_{n \geq 1}$  is uniformly integrable (with respect to Q).

*Proof:* Suppose first that  $\alpha \in (0,1)$ . Then for any b>0

$$\int_{X_n > b} X_n \, dQ \le \int_{X_n > b} X_n \left(\frac{X_n}{b}\right)^{(1-\alpha)/\alpha} \, dQ$$
$$\le b^{-(1-\alpha)/\alpha} \int X_n^{1/\alpha} \, dQ \le b^{-(1-\alpha)/\alpha},$$

and, as  $X_n \ge 0$ ,  $\lim_{b\to\infty} \sup_n \int_{|X_n|>b} |X_n| \, \mathrm{d}Q = 0$ , which was to be shown.

Alternatively, suppose that  $\alpha \in [1,\infty)$ . Then  $\frac{p_n}{q_n} = \frac{\mathrm{d}P_{\mid \mathcal{F}_n}}{\mathrm{d}Q_{\mid \mathcal{F}_n}}$  (Q-a.s.) and hence by Proposition 1 and Jensen's inequality for conditional expectations

$$X_{n} = f\left(\mathbf{E}\left[\frac{\mathrm{d}P}{\mathrm{d}Q}\middle|\mathcal{F}_{n}\right]\right) \leq \mathbf{E}\left[f\left(\frac{\mathrm{d}P}{\mathrm{d}Q}\right)\middle|\mathcal{F}_{n}\right] = \mathbf{E}\left[X_{1}\middle|\mathcal{F}_{n}\right]$$

(Q-a.s.) As  $\min_x x \ln x = -\mathrm{e}^{-1}$ , it follows that  $X_n \ge 0$  and for any b,c>0

$$\int_{|X_n|>b} |X_n| \, \mathrm{d}Q = \int_{X_n>b} X_n \, \mathrm{d}Q$$

$$\leq \int_{X_n>b} \mathbf{E} [X_1|\mathcal{F}_n] \, \mathrm{d}Q = \int_{X_n>b} X_1 \, \mathrm{d}Q$$

$$= \int_{X_n>b, X_1 \leq c} X_1 \, \mathrm{d}Q + \int_{X_n>b, X_1>c} X_1 \, \mathrm{d}Q$$

$$\leq c \cdot Q(X_n > b) + \int_{X_1>c} X_1 \, \mathrm{d}Q$$

$$\leq \frac{c}{b} \mathbf{E}_Q[X_n] + \int_{X_1>c} X_1 \, \mathrm{d}Q$$

$$\leq \frac{c}{b} \mathbf{E}_Q[X_1] + \int_{X_1>c} X_1 \, \mathrm{d}Q,$$

where  $\mathbf{E}_Q[X_n] \leq \mathbf{E}_Q[X_1]$  in the last inequality follows from the data processing inequality. Consequently,

$$\lim_{b \to \infty} \sup_{n} \int_{|X_n| > b} |X_n| \, dQ = \lim_{c \to \infty} \lim_{b \to \infty} \sup_{n} \int_{|X_n| > b} |X_n| \, dQ$$
$$\leq \lim_{c \to \infty} \lim_{b \to \infty} \frac{c}{b} \mathbf{E}_Q[X_1] + \lim_{c \to \infty} \int_{|X_1| > c} X_1 \, dQ = 0,$$

and the lemma follows.

Proof of Theorem 22: First suppose that  $\alpha>0$  and, for  $n=1,2,\ldots,\infty$ , let  $p_n=\frac{\mathrm{d}P_{\mid\mathcal{F}_n}}{\mathrm{d}\mu_{\mid\mathcal{F}_n}},q_n=\frac{\mathrm{d}Q_{\mid\mathcal{F}_n}}{\mathrm{d}\mu_{\mid\mathcal{F}_n}}$  and  $X_n=f\left(\frac{p_n}{q_n}\right)$  with  $f(x)=x^\alpha$  if  $\alpha\neq 1$  and  $f(x)=x\ln x+\mathrm{e}^{-1}$  if  $\alpha=1$ , as in Lemma 7. If  $\alpha\geq 1$ , then assume without loss of generality that  $\mathcal{F}=\mathcal{F}_1$  and m=1, such that  $D_\alpha(P_{\mid\mathcal{F}_m}||Q_{\mid\mathcal{F}_m})<\infty$  implies  $P\ll Q$ . Now, for any  $\alpha>0$ , it is sufficient to show that

<span id="page-13-4"></span>
$$\mathbf{E}_Q[X_n] \to \mathbf{E}_Q[X_\infty]. \tag{40}$$

By Proposition 1,  $p_n = \mathbf{E}_{\mu}[p|\mathcal{F}_n]$  and  $q_n = \mathbf{E}_{\mu}[q|\mathcal{F}_n]$ . Therefore by a version of Lévy's theorem for decreasing sequences of  $\sigma$ -algebras [41, Theorem 6.23],

$$p_{n} = \mathbf{E}_{\mu} [p|\mathcal{F}_{n}] \to \mathbf{E}_{\mu} [p|\mathcal{F}_{\infty}] = p_{\infty},$$

$$q_{n} = \mathbf{E}_{\mu} [q|\mathcal{F}_{n}] \to \mathbf{E}_{\mu} [q|\mathcal{F}_{\infty}] = q_{\infty},$$

$$(\mu\text{-a.s.})$$

and hence  $X_n \to X_\infty$  ( $\mu$ -a.s. and therefore Q-a.s.) If  $0 < \alpha < 1$ , then

$$\mathbf{E}_{Q}[X_{n}] = E_{\mu} \left[ p_{n}^{\alpha} q_{n}^{1-\alpha} \right] \le \mathbf{E}_{\mu} \left[ \alpha p_{n} + (1-\alpha)q_{n} \right] = 1 < \infty.$$

And if  $\alpha \geq 1$ , then by the data processing inequality  $D_{\alpha}(P_{|\mathcal{F}_n}||Q_{|\mathcal{F}_n}) < \infty$  for all n, which implies that also in this case  $\mathbf{E}_Q[X_n] < \infty$ . Hence uniform integrability (by Lemma 7) of the family of nonnegative random variables  $\{X_n\}$  implies (40) [28, Thm. 5, p. 189], and the theorem follows for  $\alpha > 0$ . The remaining case,  $\alpha = 0$ , is proved by

$$\begin{split} & \lim_{n \to \infty} D_0(P_{|\mathcal{F}_n} \| Q_{|\mathcal{F}_n}) \\ & = \inf_n \inf_{\alpha > 0} D_\alpha(P_{|\mathcal{F}_n} \| Q_{|\mathcal{F}_n}) = \inf_{\alpha > 0} \inf_n D_\alpha(P_{|\mathcal{F}_n} \| Q_{|\mathcal{F}_n}) \\ & = \inf_{\alpha > 0} D_\alpha(P_{|\mathcal{F}_\infty} \| Q_{|\mathcal{F}_\infty}) = D_0(P_{|\mathcal{F}_\infty} \| Q_{|\mathcal{F}_\infty}). \end{split}$$

<span id="page-13-0"></span>F. Absolute Continuity and Mutual Singularity

Shiryaev [28, pp. 366, 370] relates Hellinger integrals to absolute continuity and mutual singularity of probability distributions. His results may more elegantly be expressed in terms of Rényi divergence. They then follow from the observations that  $D_0(P\|Q)=0$  if and only if Q is absolutely continuous with respect to P and that  $D_0(P\|Q)=\infty$  if and only if P and Q are mutually singular, together with right-continuity of  $D_\alpha(P\|Q)$  in  $\alpha$  at  $\alpha=0$ . As illustrated in the next section, these properties give a convenient mathematical tool to establish absolute continuity or mutual singularity of infinite product distributions.

<span id="page-13-2"></span>**Theorem 23** ([28, Theorem 2, p. 366]). *The following conditions are equivalent:* 

<span id="page-13-5"></span>(i) 
$$Q \ll P$$
,

- <span id="page-14-5"></span>(ii) Q(p > 0) = 1,
- (iii)  $D_0(P||Q) = 0$ ,
- (iv)  $\lim_{\alpha \downarrow 0} D_{\alpha}(P||Q) = 0.$

*Proof:* Clearly (ii) is equivalent to Q(p=0)=0, which is equivalent to (i). The other cases follow by  $\lim_{\alpha\downarrow 0} D_{\alpha}(P\|Q) = D_0(P\|Q) = -\ln Q(p>0)$ .

<span id="page-14-2"></span>**Theorem 24** ( [28, Theorem 3, p. 366]). *The following conditions are equivalent:* 

- <span id="page-14-6"></span>(i)  $P \perp Q$ ,
- <span id="page-14-7"></span>(ii) Q(p > 0) = 0,
- <span id="page-14-9"></span>(iii)  $D_{\alpha}(P||Q) = \infty$  for some  $\alpha \in [0,1)$ ,
- <span id="page-14-8"></span>(iv)  $D_{\alpha}(P||Q) = \infty$  for all  $\alpha \in [0, \infty]$ .

*Proof:* Equivalence of (i), (ii) and  $D_0(P\|Q) = \infty$  follows from definitions. Equivalence of  $D_0(P\|Q) = \infty$  and (iv) follows from the fact that Rényi divergence is continuous on [0,1] and nondecreasing in  $\alpha$ . Finally, (iii) for some  $\alpha \in (0,1)$  is equivalent to

$$\int p^{\alpha} q^{1-\alpha} \, \mathrm{d}\mu = 0,$$

which holds if and only if pq = 0 ( $\mu$ -a.s.). It follows that in this case (iii) is equivalent to (i).

Contiguity and entire separation are asymptotic versions of absolute continuity and mutual singularity [42]. As might be expected, analogues of Theorems 23 and 24 also hold for these asymptotic concepts.

Let  $(\mathcal{X}_n,\mathcal{F}_n)_{n=1,2,\dots}$  be a sequence of measurable spaces, and let  $(P_n)_{n=1,2,\dots}$  and  $(Q_n)_{n=1,2,\dots}$  be sequences of distributions on these spaces. Then the sequence  $(P_n)$  is *contiguous* with respect to the sequence  $(Q_n)$ , denoted  $(P_n) \lhd (Q_n)$ , if for all sequences of events  $(A_n \in \mathcal{F}_n)_{n=1,2,\dots}$  such that  $Q_n(A_n) \to 0$  as  $n \to \infty$ , we also have  $P_n(A_n) \to 0$ . If both  $(P_n) \lhd (Q_n)$  and  $(Q_n) \lhd (P_n)$ , then the sequences are called *mutually contiguous* and we write  $(P_n) \lhd (Q_n)$ . The sequences  $(P_n)$  and  $(Q_n)$  are *entirely separated*, denoted  $(P_n) \vartriangle (Q_n)$ , if there exist a sequence of events  $(A_n \in \mathcal{F}_n)_{n=1,2,\dots}$  and a subsequence  $(n_k)_{k=1,2,\dots}$  such that  $P_{n_k}(A_{n_k}) \to 0$  and  $Q_{n_k}(\mathcal{X}_{n_k} \setminus A_{n_k}) \to 0$  as  $k \to \infty$ .

Contiguity and entire separation are related to absolute continuity and mutual singularity in the following way [28, p. 369]: if  $\mathcal{X}_n = \mathcal{X}$ ,  $P_n = P$  and  $Q_n = Q$  for all n, then

$$(P_n) \lhd (Q_n) \qquad \Leftrightarrow \qquad P \ll Q,$$

$$(P_n) \lhd \rhd (Q_n) \qquad \Leftrightarrow \qquad P \sim Q,$$

$$(P_n) \vartriangle (Q_n) \qquad \Leftrightarrow \qquad P \perp Q.$$
(41)

<span id="page-14-10"></span>Theorems 1 and 2 by Shiryaev [28, p. 370] imply the following two asymptotic analogues of Theorems 23 and 24:

<span id="page-14-3"></span>**Theorem 25.** The following conditions are equivalent:

- (i)  $(Q_n) \triangleleft (P_n)$ ,
- (ii)  $\lim_{\alpha \downarrow 0} \limsup_{n \to \infty} D_{\alpha}(P_n || Q_n) = 0.$

<span id="page-14-4"></span>**Theorem 26.** The following conditions are equivalent:

- (i)  $(P_n) \triangle (Q_n)$ ,
- (ii)  $\limsup D_{\alpha}(P_n||Q_n) = \infty$ ,
- (iii)  $\limsup_{n \to \infty} D_{\alpha}(P_n || Q_n) = \infty$  for some  $\alpha \in (0,1)$ .

(iv) 
$$\limsup_{n\to\infty} D_{\alpha}(P_n||Q_n) = \infty$$
 for all  $\alpha \in (0,\infty]$ .

If  $P_n$  and  $Q_n$  are the restrictions of P and Q to an increasing sequence of sub- $\sigma$ -algebras that generates  $\mathcal{F}$ , then the equivalences in (41) continue to hold, because we can relate Theorems 23 and 25 and Theorems 24 and 26 via Theorem 21.

#### G. Distributions on Sequences

Suppose  $(\mathcal{X}^{\infty}, \mathcal{F}^{\infty})$  is the *direct product* of an infinite sequence of measurable spaces  $(\mathcal{X}_1, \mathcal{F}_1), (\mathcal{X}_2, \mathcal{F}_2), \ldots$  That is,  $\mathcal{X}^{\infty} = \mathcal{X}_1 \times \mathcal{X}_2 \times \cdots$  and  $\mathcal{F}^{\infty}$  is the smallest  $\sigma$ -algebra containing all the *cylinder sets* 

$$S_n(A) = \{x^{\infty} \in \mathcal{X}^{\infty} \mid x_1, \dots, x_n \in A\}, \qquad A \in \mathcal{F}^n,$$

for n=1,2,..., where  $\mathcal{F}^n=\mathcal{F}_1\otimes\cdots\otimes\mathcal{F}_n$ . Then a sequence of probability distributions  $P^1,P^2,...$ , where  $P^n$  is a distribution on  $\mathcal{X}^n=\mathcal{X}_1\times\cdots\times\mathcal{X}_n$ , is called *consistent* if

$$P^{n+1}(A \times \mathcal{X}_{n+1}) = P^n(A), \qquad A \in \mathcal{F}^n.$$

For any such consistent sequence there exists a distribution  $P^{\infty}$  on  $(\mathcal{X}^{\infty}, \mathcal{F}^{\infty})$  such that its marginal distribution on  $\mathcal{X}^n$  is  $P^n$ , in the sense that

$$P^{\infty}(S_n(A)) = P^n(A), \qquad A \in \mathcal{F}^n.$$

If  $P^1, P^2, \ldots$  and  $Q^1, Q^2, \ldots$  are two consistent sequences of probability distributions, then it is natural to ask whether the Rényi divergence  $D_{\alpha}(P^n\|Q^n)$  converges to  $D_{\alpha}(P^{\infty}\|Q^{\infty})$ . The following theorem shows that it does for  $\alpha>0$ .

<span id="page-14-0"></span>**Theorem 27** (Consistent Distributions). Let  $P^1, P^2, \ldots$  and  $Q^1, Q^2, \ldots$  be consistent sequences of probability distributions on  $(\mathcal{X}^1, \mathcal{F}^1), (\mathcal{X}^2, \mathcal{F}^2), \ldots$ , where, for  $n = 1, \ldots, \infty$ ,  $(\mathcal{X}^n, \mathcal{F}^n)$  is the direct product of the first n measurable spaces in the infinite sequence  $(\mathcal{X}_1, \mathcal{F}_1), (\mathcal{X}_2, \mathcal{F}_2), \ldots$  Then for any  $\alpha \in (0, \infty]$ 

$$D_{\alpha}(P^n||Q^n) \to D_{\alpha}(P^{\infty}||Q^{\infty})$$

as  $n \to \infty$ .

Proof: Let 
$$\mathcal{G}^n = \{S_n(A) \mid A \in \mathcal{F}^n\}$$
. Then 
$$D_{\alpha}(P^n|Q^n) = D_{\alpha}(P^{\infty}_{|\mathcal{G}^n} \| Q^{\infty}_{|\mathcal{G}^n}) \to D_{\alpha}(P^{\infty} \| Q^{\infty})$$

by Theorem 21.

As a special case, we find that finite additivity of Rényi divergence, which is easy to verify, extends to countable additivity:

<span id="page-14-1"></span>**Theorem 28** (Additivity). For n = 1, 2, ..., let  $(P_n, Q_n)$  be pairs of probability distributions on measurable spaces  $(\mathcal{X}_n, \mathcal{F}_n)$ . Then for any  $\alpha \in [0, \infty]$  and any  $N \in \{1, 2, ...\}$ 

<span id="page-14-12"></span>
$$\sum_{n=1}^{N} D_{\alpha}(P_n \| Q_n) = D_{\alpha}(P_1 \times \dots \times P_N \| Q_1 \times \dots \times Q_N), \tag{42}$$

and, except for  $\alpha = 0$ , also

<span id="page-14-11"></span>
$$\sum_{n=1}^{\infty} D_{\alpha}(P_n || Q_n) = D_{\alpha}(P_1 \times P_2 \times \dots || Q_1 \times Q_2 \times \dots).$$
 (43)

Countable additivity as in (43) does not hold for  $\alpha = 0$ . A counterexample is given following Example 3 below.

*Proof:* For simple orders  $\alpha$ , (42) follows from independence of  $P_n$  and  $Q_n$  between different n, which implies that

$$\prod_{n=1}^{N} \int \left(\frac{\mathrm{d}Q_n}{\mathrm{d}P_n}\right)^{1-\alpha} \mathrm{d}P_n = \int \left(\frac{\mathrm{d}\prod_{n=1}^{N} Q_n}{\mathrm{d}\prod_{n=1}^{N} P_n}\right)^{1-\alpha} \mathrm{d}\prod_{n=1}^{N} P_n.$$

As N is finite, this extends to the extended orders by continuity in  $\alpha$ . Finally, (43) follows from Theorem 27 by observing that the sequences  $P^N = P_1 \times \cdots \times P_N$  and  $Q^N = Q_1 \times \cdots \times Q_N$ , for  $N = 1, 2, \ldots$ , are consistent.

Theorems 23 and 24 can be used to establish absolute continuity or mutual singularity of infinite product distributions, as illustrated by the following proof by Shiryaev [28] of the *Gaussian dichotomy* [43]–[45].

<span id="page-15-2"></span>**Example 3** (Gaussian Dichotomy). Let  $P=P_1\times P_2\times \cdots$  and  $Q=Q_1\times Q_2\times \cdots$ , where  $P_n$  and  $Q_n$  are Gaussian distributions with densities

$$p_n(x) = \frac{1}{\sqrt{2\pi}} e^{-\frac{1}{2}(x-\mu_n)^2}, \quad q_n(x) = \frac{1}{\sqrt{2\pi}} e^{-\frac{1}{2}(x-\nu_n)^2}.$$

Then

$$D_{\alpha}(P_n||Q_n) = \frac{\alpha}{2}(\mu_n - \nu_n)^2,$$

and by additivity for  $\alpha > 0$ 

<span id="page-15-3"></span>
$$D_{\alpha}(P||Q) = \frac{\alpha}{2} \sum_{n=1}^{\infty} (\mu_n - \nu_n)^2.$$
 (44)

Consequently, by Theorems 23 and 24 and symmetry in P and Q:

$$Q \ll P \quad \Leftrightarrow \quad P \ll Q \quad \Leftrightarrow \quad \sum_{n=1}^{\infty} (\mu_n - \nu_n)^2 < \infty, \quad (45)$$

$$Q \perp P \quad \Leftrightarrow \quad \sum_{n=1}^{\infty} (\mu_n - \nu_n)^2 = \infty. \quad (46)$$

The observation that P and Q are either equivalent (both  $P \ll Q$  and  $Q \ll P$ ) or mutually singular is called the *Gaussian dichotomy*.

By letting  $\alpha$  tend to 0, Example 3 shows that countable additivity does not hold for  $\alpha=0$ : if  $\sum_{n=1}^{\infty}(\mu_n-\nu_n)^2=\infty$ , then (44) implies that  $D_0(P\|Q)=\infty$ , while  $\sum_{n=1}^{N}D_0(P_n\|Q_n)=0$  for all N. In light of the proof of Theorem 28 this also provides a counterexample to (39) for  $\alpha=0$ .

The Gaussian dichotomy raises the question of whether the same dichotomy holds for other product distributions. Let  $P \sim Q$  denote that P and Q are equivalent (both  $P \ll Q$  and  $Q \ll P$ ). Suppose that  $P = P_1 \times P_2 \times \cdots$  and  $Q = Q_1 \times Q_2 \times \cdots$ , where  $P_n$  and  $Q_n$  are arbitrary distributions on arbitrary measurable spaces. Then if  $P_n \not\sim Q_n$  for some n, P and Q are not equivalent either. The question is therefore answered by the following theorem:

<span id="page-15-4"></span>**Theorem 29** (Kakutani's Dichotomy). Let  $\alpha \in (0,1)$  and let  $P = P_1 \times P_2 \times \cdots$  and  $Q = Q_1 \times Q_2 \times \cdots$ , where  $P_n$  and

 $Q_n$  are distributions on arbitrary measurable spaces such that  $P_n \sim Q_n$ . Then

$$Q \sim P \quad \Leftrightarrow \quad \sum_{n=1}^{\infty} D_{\alpha}(P_n || Q_n) < \infty,$$
 (47)

$$Q \perp P \quad \Leftrightarrow \quad \sum_{n=1}^{\infty} D_{\alpha}(P_n || Q_n) = \infty.$$
 (48)

Proof: If  $\sum_{n=1}^{\infty}D_{\alpha}(P_n\|Q_n)=\infty$ , then  $D_{\alpha}(P\|Q)=\infty$  and  $Q\perp P$  follows by Theorem 24.

On the other hand, if  $\sum_{n=1}^{\infty} D_{\alpha}(P_n || Q_n) < \infty$ , then for every  $\varepsilon > 0$  there exists an N such that

$$\sum_{n=N+1}^{\infty} D_{\alpha}(P_n || Q_n) \le \varepsilon,$$

and consequently by additivity and monotonicity in  $\alpha$ :

$$D_0(P||Q) = \lim_{\alpha \downarrow 0} D_\alpha(P||Q)$$
  
 
$$\leq \lim_{\alpha \downarrow 0} D_\alpha(P_1 \times \dots \times P_N ||Q_1 \times \dots \times Q_N) + \varepsilon = \varepsilon.$$

As this holds for any  $\varepsilon > 0$ ,  $D_0(P\|Q)$  must equal 0, and, by Theorem 23,  $Q \ll P$ . As  $Q \ll P$  implies  $Q \not\perp P$ , Theorem 24 implies that  $D_{\alpha}(Q\|P) < \infty$ , and by repeating the argument with the roles of P and Q reversed we find that also  $P \ll Q$ , which completes the proof.

Theorem 29 (with  $\alpha=1/2$ ) is equivalent to a classical result by Kakutani [46], which was stated in terms of Hellinger integrals rather than Rényi divergence, and according to Gibbs and Su [24] might be responsible for popularising Hellinger integrals. As shown by Rényi [47], Kakutani's result is related to the amount of information that a sequence of observations contains about the parameter of a statistical model.

## <span id="page-15-1"></span>H. Taylor Approximation for Parametric Models

Suppose  $\{P_{\theta} \mid \theta \in \Theta \subseteq \mathbb{R}\}$  is a parametric statistical model. Then it is well known that, for sufficiently regular parametrisations, a second order Taylor approximation of  $D(P_{\theta}||P_{\theta'})$  in  $\theta'$  at  $\theta$  in the interior of  $\Theta$  yields

$$\lim_{\theta' \to \theta} \frac{1}{(\theta - \theta')^2} D(P_{\theta} || P_{\theta'}) = \frac{1}{2} J(\theta), \tag{49}$$

where  $J(\theta) = \mathbf{E}\left[\left(\frac{\mathrm{d}}{\mathrm{d}\theta} \ln p_{\theta}\right)^{2}\right]$  denotes the *Fisher information* at  $\theta$  (see e.g. [30, Problem 12.7] or [48]). Haussler and Opper [6] argue that this property generalizes to

$$\lim_{\theta' \to \theta} \frac{1}{(\theta - \theta')^2} D_{\alpha}(P_{\theta} || P_{\theta'}) = \frac{\alpha}{2} J(\theta)$$
 (50)

for any  $\alpha \in (0, \infty)$ , but we are not aware of a reference that spells out the exact technical conditions on the parametrisation that are needed.

## IV. MINIMAX RESULTS

## <span id="page-15-0"></span>A. Hypothesis Testing and Chernoff Information

Rényi divergence appears in bounds on the error probabilities when testing a probabilistic hypothesis Q against an alternative P [4], [49], [50]. This can be explained by the

fact that  $(1-\alpha)D_{\alpha}(P\|Q)$  equals the *cumulant generating* function for the random variable  $\ln(p/q)$  under the distribution Q (provided  $\alpha \in (0,1)$  or  $P \ll Q$ ) [4]. The following theorem relates this cumulant generating function to two Kullback-Leibler divergences that involve the distribution  $P_{\alpha}$  with density

<span id="page-16-3"></span>
$$p_{\alpha} = \frac{q^{1-\alpha}p^{\alpha}}{\int q^{1-\alpha}p^{\alpha} \,\mathrm{d}\mu},\tag{51}$$

which is well defined if and only if  $0 < \int p^{\alpha}q^{1-\alpha} d\mu < \infty$ .

<span id="page-16-2"></span>**Theorem 30.** For any simple order  $\alpha$ 

<span id="page-16-5"></span>
$$(1 - \alpha)D_{\alpha}(P||Q) = \inf_{R} \left\{ \alpha D(R||P) + (1 - \alpha)D(R||Q) \right\},$$
(52)

with the convention that  $\alpha D(R\|P)+(1-\alpha)D(R\|Q)=\infty$  if it would otherwise be undefined. Moreover, if the distribution  $P_{\alpha}$  with density (51) is well defined and  $\alpha\in(0,1)$  or  $D(P_{\alpha}\|P)<\infty$ , then the infimum is uniquely achieved by  $R=P_{\alpha}$ .

This result gives an interpretation of Rényi divergence as a trade-off between two Kullback-Leibler divergences.

Remark 3. Theorem 30 was formulated and proved for distributions on finite sets by Shayevitz [17], but appeared in the above formulation already in [7]. Prior to either of these, the identity (53) below, which forms the heart of the proof, has been used by Csiszár [51].

*Proof of Theorem 30:* First suppose that  $P_{\alpha}$  is well defined or, equivalently, that  $D_{\alpha}(P\|Q)<\infty$ . Then for  $\alpha\in(0,1)$  or  $D(R\|P)<\infty$ , we have

<span id="page-16-4"></span>
$$\alpha D(R||P) + (1 - \alpha)D(R||Q) = D(R||P_{\alpha}) - \ln \int p^{\alpha} q^{1 - \alpha} d\mu.$$
(53)

Hence, if  $0 < \alpha < 1$  or  $D(P_{\alpha} \| P) < \infty$ , the infimum over R is uniquely achieved by  $R = P_{\alpha}$ , for which it equals  $(1 - \alpha)D_{\alpha}(P \| Q)$  as required. If, on the other hand,  $\alpha > 1$  and  $D(P_{\alpha} \| P) = \infty$ , then we still have

<span id="page-16-6"></span>
$$\inf_{R} \left\{ \alpha D(R||P) + (1 - \alpha)D(R||Q) \right\} \ge (1 - \alpha)D_{\alpha}(P||Q).$$
(54)

Secondly, suppose  $\alpha \in (0,1)$  and  $D_{\alpha}(P||Q) = \infty$ . Then  $P \perp Q$ , and consequently either  $D(R||P) = \infty$  or  $D(R||Q) = \infty$  for all R, which means that (52) holds.

Next, consider the case that  $\alpha>1$  and  $P\not\ll Q$ . Then  $D_{\alpha}(P\|Q)=\infty$  and the infimum over R is achieved by R=P, for which it equals  $-\infty$ , and again (52) holds.

Finally, we prove (52) for the remaining cases:  $\alpha>1, P\ll Q$  and either: (1)  $D_{\alpha}(P\|Q)<\infty$ , but  $D(P_{\alpha}\|P)=\infty$ ; or (2)  $D_{\alpha}(P\|Q)=\infty$ . To this end, let  $P_c=P(\cdot\mid p\leq cq)$  for all c that are sufficiently large that  $P(p\leq cq)>0$ . The reader may verify that  $D_{\alpha}(P_c\|Q)<\infty$  and  $D(S\|P_c)<\infty$  for  $s=p_c^{\alpha}q^{1-\alpha}/\int p_c^{\alpha}q^{1-\alpha}\,\mathrm{d}\mu$ , so that we have already proved that (52) holds if P is replaced by  $P_c$ . Hence, observing that for all  $P_c$ 

$$D(R||P_c) = \begin{cases} \infty & \text{if } R \not\ll P_c, \\ D(R||P) + \ln P(p \le pc) & \text{otherwise,} \end{cases}$$

we find that

$$\inf_{R} \left\{ \alpha D(R||P) + (1 - \alpha)D(R||Q) \right\}$$

$$\leq \lim_{c \to \infty} \sup_{c \to \infty} \left( -\alpha \ln P(p \le cq) + \inf_{R} \left\{ \alpha D(R||P_c) + (1 - \alpha)D(R||Q) \right\} \right)$$

$$\leq \lim_{c \to \infty} \sup_{c \to \infty} (1 - \alpha)D_{\alpha}(P_c||Q) \le (1 - \alpha)D_{\alpha}(P||Q),$$

where the last inequality follows by lower semi-continuity of  $D_{\alpha}$  (Theorem 15). In case 2, (52) follows immediately. In case 1, (52) follows by combining this inequality with its converse (54).

Theorem 30 shows that  $(1 - \alpha)D_{\alpha}(P||Q)$  is the infimum over a set of functions that are linear in  $\alpha$ , which implies the following corollary:

<span id="page-16-1"></span>**Corollary 2.** The function  $(1-\alpha)D_{\alpha}(P||Q)$  is concave in  $\alpha$  on  $[0,\infty]$ , with the conventions that it is 0 at  $\alpha=1$  even if  $D(P||Q)=\infty$  and that it is 0 at  $\alpha=\infty$  if P=Q.

*Proof:* Suppose first that  $D(P\|Q) < \infty$ . Then (52) also holds at  $\alpha = 1$ . Hence  $(1 - \alpha)D_{\alpha}(P\|Q)$  is a point-wise infimum over linear functions on  $(0, \infty)$ , and thus concave. This extends to  $\alpha \in \{0, \infty\}$  by continuity.

Alternatively, suppose that  $D(P\|Q)=\infty$ . Then  $(1-\alpha)D_{\alpha}(P\|Q)$  is still concave on [0,1), where it is also nonnegative. And by monotonicity of Rényi divergence, we have that  $D_{\alpha}(P\|Q)=\infty$  for all  $\alpha\geq 1$ . Consequently,  $(1-\alpha)D_{\alpha}(P\|Q)$  is nonnegative and concave for  $\alpha\in[0,1)$ , at  $\alpha=1$  it is 0 (by convention) and for  $\alpha\in(1,\infty]$  it is  $-\infty$ . It then follows that  $(1-\alpha)D_{\alpha}(P\|Q)$  is concave on all of  $[0,\infty]$ , as required.

In addition, Theorem 30 can be used to prove Gilardoni's extension of Pinsker's inequality from the case  $\alpha = 1$  to any  $\alpha \in (0,1]$  [25], which was mentioned in the introduction.

<span id="page-16-0"></span>**Theorem 31** (Pinsker's Inequality). Let V(P,Q) be the total variation distance, as defined in (34). Then, for any  $\alpha \in (0,1]$ ,

$$\frac{\alpha}{2}V^2(P,Q) \le D_{\alpha}(P||Q).$$

*Proof:* We omit the proof for  $\alpha=1$ , which is the standard version of Pinsker's inequality (see [52] for a survey of its history). For  $\alpha\in(0,1)$ , consider first the case of two distributions P=(p,1-p) and Q=(q,1-q) on a binary alphabet. Then  $V^2(P,Q)=4(p-q)^2$  and by Theorem 30 and the result for  $\alpha=1$ , we find

$$(1 - \alpha)D_{\alpha}(P||Q) = \inf_{R} \left\{ \alpha D(R||P) + (1 - \alpha)D(R||Q) \right\}$$
  
 
$$\geq \inf_{R} \left\{ 2\alpha(r - p)^{2} + 2(1 - \alpha)(r - q)^{2} \right\}.$$

The minimum is achieved by  $r = \alpha p + (1 - \alpha)q$ , from which

$$D_{\alpha}(P||Q) \ge 2\alpha(p-q)^2 = \frac{\alpha}{2}V^2(P,Q).$$

The general case of distributions P and Q on any sample space  $\mathcal{X}$  reduces to the binary case by the data processing inequality: for any event A, let  $P_{|A}$  and  $Q_{|A}$  denote the restrictions of P

and Q to the binary partition  $\mathcal{P} = \{A, \mathcal{X} \setminus A\}$ . Then

$$\frac{2}{\alpha}D_{\alpha}(P||Q) \ge \sup_{A} \frac{2}{\alpha}D_{\alpha}(P_{|A}||Q_{|A}) \ge \sup_{A} V^{2}(P_{|A}, Q_{|A})$$
$$= \sup_{A} 4(P(A) - Q(A))^{2} = V^{2}(P, Q),$$

as required.

As one might expect from continuity of  $D_{\alpha}(P||Q)$ , the terms on the right-hand side of (52) are continuous in  $\alpha$ , at least on (0,1):

<span id="page-17-3"></span>**Lemma 8.** If  $D(P||Q) < \infty$  or  $D(Q||P) < \infty$ , then both  $D(P_{\alpha}||Q)$  and  $D(P_{\alpha}||P)$  are finite and continuous in  $\alpha$  on (0,1).

*Proof:* The lemma is symmetric in P and Q, so suppose without loss of generality that  $D(P\|Q)<\infty$ . Then  $D_{\alpha}(P\|Q)\leq D(P\|Q)<\infty$  implies that  $P_{\alpha}$  is well defined and finiteness of both  $D(P_{\alpha}\|Q)$  and  $D(P_{\alpha}\|P)$  follows from Theorem 30. Now observe that

$$D(P_{\alpha}||Q) = \frac{1}{\int p^{\alpha}q^{1-\alpha} d\mu} \mathbf{E}_{Q} \left[ \left( \frac{p}{q} \right)^{\alpha} \ln \left( \frac{p}{q} \right)^{\alpha} \right] + (1-\alpha)D_{\alpha}(P||Q).$$

Then by continuity of  $D_{\alpha}(P\|Q)$  and hence of  $\int p^{\alpha}q^{1-\alpha} d\mu$  in  $\alpha$ , it is sufficient to verify continuity of  $\mathbf{E}_{Q}[(p/q)^{\alpha}\ln(p/q)^{\alpha}]$ . To this end, observe that

$$|(p/q)^{\alpha} \ln(p/q)^{\alpha}| \le \begin{cases} 1/e & \text{if } p < q, \\ (p/q) \ln(p/q) & \text{if } p \ge q. \end{cases}$$

As  $D(P||Q) < \infty$  implies  $\mathbf{E}_Q[\mathbf{1}_{\{p \geq q\}}(p/q)\ln(p/q)] < \infty$ , we may apply the dominated convergence theorem to obtain

$$\lim_{\alpha \to \alpha^*} \mathbf{E}_Q \left[ \left( \frac{p}{q} \right)^\alpha \ln \left( \frac{p}{q} \right)^\alpha \right] = \mathbf{E}_Q \left[ \left( \frac{p}{q} \right)^{\alpha^*} \ln \left( \frac{p}{q} \right)^{\alpha^*} \right]$$

for any  $\alpha^* \in (0,1)$ , which proves continuity of  $D(P_{\alpha}||Q)$ . Continuity of  $D(P_{\alpha}||P)$  now follows from Theorem 30 and continuity of  $(1-\alpha)D_{\alpha}(P||Q)$ .

<span id="page-17-0"></span>**Theorem 32.** Suppose that  $D(P||Q) < \infty$ . Then the following minimax identity holds:

$$\sup_{\alpha \in (0,\infty)} \inf_{R} \left\{ \alpha D(R \| P) + (1 - \alpha) D(R \| Q) \right\}$$

$$= \inf_{R} \sup_{\alpha \in (0,\infty)} \left\{ \alpha D(R \| P) + (1 - \alpha) D(R \| Q) \right\}, \quad (55)$$

with the convention that  $\alpha D(R||P) + (1-\alpha)D(R||Q) = \infty$  if it would otherwise be undefined. Moreover, (55) still holds if  $\alpha$  is restricted to (0,1) on its left-hand side; and if there exists an  $\alpha^* \in (0,1)$  such that  $D(P_{\alpha^*}||P) = D(P_{\alpha^*}||Q)$ , then  $(\alpha^*, P_{\alpha^*})$  is a saddle-point for (55) and both sides of (55) are equal to

<span id="page-17-2"></span>
$$(1 - \alpha^*) D_{\alpha^*}(P \| Q) = \sup_{\alpha \in (0,1)} (1 - \alpha) D_{\alpha}(P \| Q)$$
  
=  $D(P_{\alpha^*} \| P) = D(P_{\alpha^*} \| Q).$  (56)

The minimax value defined in (55) is the *Chernoff information*, which gives an asymptotically tight bound on both the type 1 and the type 2 errors in tests of P vs. Q. The same

connection between Chernoff information and  $D(P_{\alpha^*}||P)$  is discussed by Cover and Thomas [30, Section 12.9], with a different proof.

Proof of Theorem 32: Let  $f(\alpha,R) = \alpha D(R\|P) + (1-\alpha)D(R\|Q)$ . For  $\alpha \in (0,1)$ ,  $D_{\alpha}(P\|Q) \leq D(P\|Q) < \infty$  implies that  $P_{\alpha}$  is well defined. Suppose there exists  $\alpha^* \in (0,1)$  such that  $D(P_{\alpha^*}\|P) = D(P_{\alpha^*}\|Q)$ . Then Theorem 30 implies that  $(\alpha^*,P_{\alpha^*})$  is a saddle-point for  $f(\alpha,R)$ , so that (55) holds [53, Lemma 36.2], and Theorem 30 also implies that all quantities in (56) are equal to  $f(\alpha^*,P_{\alpha^*})$ .

Let  $\mathcal{A}$  be either (0,1) or  $(0,\infty)$ . As the sup inf is never bigger than the inf sup [53, Lemma 36.1], we have that

$$\sup_{\alpha \in \mathcal{A}} \inf_{R} f(\alpha, R) \leq \sup_{\alpha \in (0, \infty)} \inf_{R} f(\alpha, R) \leq \inf_{R} \sup_{\alpha \in (0, \infty)} f(\alpha, R),$$

so it remains to prove the converse inequality.

By Lemma 8 we know that both  $D(P_{\alpha}\|P)$  and  $D(P_{\alpha}\|Q)$  are finite and continuous in  $\alpha$  on (0,1). By the intermediate value theorem, there are therefore three possibilities: (1) there exists  $\alpha^* \in (0,1)$  such that  $D(P_{\alpha^*}\|P) = D(P_{\alpha^*}\|Q)$ , for which we have already proved (55); (2)  $D(P_{\alpha}\|P) < D(P_{\alpha}\|Q)$  for all  $\alpha \in (0,1)$ ; and (3)  $D(P_{\alpha}\|P) > D(P_{\alpha}\|Q)$  for all  $\alpha \in (0,1)$ .

We proceed with case (2), observing that

$$\begin{split} \inf_{R} \sup_{\alpha \in (0,\infty)} f(\alpha,R) &= \inf_{R \colon D(R\|Q) < \infty} \sup_{\alpha \in (0,\infty)} f(\alpha,R) \\ &= \inf_{R \colon D(R\|Q) < \infty} \left\{ D(R\|Q) \\ &+ \sup_{\alpha \in (0,\infty)} \alpha \left( D(R\|P) - D(R\|Q) \right) \right\} \\ &= \inf_{R \colon D(R\|P) \le D(R\|Q) < \infty} D(R\|Q) \\ &\le \inf_{0 < \alpha < 1} D(P_{\alpha}\|Q). \end{split}$$

Now by Theorem 30

$$\begin{split} \inf_{0<\alpha<1} &D(P_{\alpha}\|Q) \leq \liminf_{\alpha\downarrow 0} D(P_{\alpha}\|Q) \\ &= \liminf_{\alpha\downarrow 0} \left\{ D_{\alpha}(P\|Q) - \frac{\alpha}{1-\alpha} D(P_{\alpha}\|P) \right\} \\ &\leq \lim_{\alpha\downarrow 0} D_{\alpha}(P\|Q) = \lim_{\alpha\downarrow 0} (1-\alpha) D_{\alpha}(P\|Q) \\ &= \liminf_{\alpha\downarrow 0} f(\alpha,R) \leq \sup_{\alpha\in A} \inf_{R} f(\alpha,R), \end{split}$$

<span id="page-17-1"></span>as required. It remains to consider case (3), which turns out to be impossible by the following argument: two applications of Theorem 30 give

$$\begin{split} D_{1/2}(P\|Q) &= \inf_{0 < \alpha < 1} \left\{ D(P_{\alpha}\|P) + D(P_{\alpha}\|Q) \right\} \\ &\leq 2 \inf_{0 < \alpha < 1} D(P_{\alpha}\|P) \leq 2 \limsup_{\alpha \uparrow 1} D(P_{\alpha}\|P) \\ &= 2 \limsup_{\alpha \uparrow 1} \left\{ \frac{1 - \alpha}{\alpha} D_{\alpha}(P\|Q) - \frac{1 - \alpha}{\alpha} D(P_{\alpha}\|P) \right\} \\ &\leq 2 \limsup_{\alpha \uparrow 1} \frac{1 - \alpha}{\alpha} D_{\alpha}(P\|Q) = 0. \end{split}$$

It follows that P = Q, which contradicts the assumption that  $D(P_{\alpha}||P) > D(P_{\alpha}||Q)$  for any  $\alpha \in (0,1)$ .

#### B. Channel Capacity and Minimax Redundancy

Consider a non-empty family  $\{P_{\theta} \mid \theta \in \Theta\}$  of probability distributions on a sample space  $\mathcal{X}$ . We may think of  $\theta$  as a parameter in a statistical model or as an input letter of an information channel. In the main results of this section we will only consider discrete sample spaces  $\mathcal{X}$ , which are either finite with n elements or countably infinite. Whenever distributions on  $\Theta$  are involved, we also implicitly assume that  $\Theta$  is a topological space that is equipped with the Borel  $\sigma$ -algebra, that  $\{\theta\}$  is a closed set for every  $\theta$ , and that the map  $\theta \mapsto P_{\theta}$  is measurable.

We will study

$$C_{\alpha} = \sup_{\pi} \inf_{Q} \int D_{\alpha} \left( P_{\theta} \| Q \right) d\pi(\theta), \tag{57}$$

which has been proposed as the appropriate generalization of the *channel capacity* from  $\alpha = 1$  to general  $\alpha$  [4], [18].

If  $\mathcal{X}$  is finite, then the channel capacity is also finite:

**Theorem 33.** If  $\mathcal{X}$  has n elements, then  $C_{\alpha} \leq \ln n$  for any  $\alpha \in [0, \infty]$ .

*Proof:* Let U denote the uniform distribution on  $\mathcal{X}$ . Then

$$\begin{split} \sup_{\pi} \inf_{Q} & \int D_{\alpha} \left( P_{\theta} \| Q \right) \, \mathrm{d}\pi(\theta) \leq \sup_{\pi} \int D_{\alpha} \left( P_{\theta} \| U \right) \, \mathrm{d}\pi(\theta) \\ & = \sup_{\theta} D_{\alpha} \left( P_{\theta} \| U \right) \leq \sup_{\theta} D_{\infty} \left( P_{\theta} \| U \right) \\ & = \sup_{\theta} \ln \max_{x} \frac{P_{\theta}(x)}{1/n} \leq \ln n. \end{split}$$

For  $\alpha = 1$ , it is a classical result by Gallager and Ryabko [54] that the channel capacity equals the *minimax redundancy*:

$$R_{\alpha} = \inf_{Q} \sup_{\theta \in \Theta} D_{\alpha}(P_{\theta} \| Q). \tag{58}$$

For finite  $\Theta$ , Csiszár [4] has shown that this result in fact extends to any  $\alpha \in (0,\infty)$ , noting that the minimax redundancy  $R_{\alpha}$  (and therefore the channel capacity  $C_{\alpha}$ ) may be geometrically interpreted as the "radius" of the family of distributions  $\{P_{\theta} \mid \theta \in \Theta\}$  with respect to the Rényi divergence of order  $\alpha$ . It turns out that Csiszár's result extends to general  $\Theta$  and all orders  $\alpha$ :

<span id="page-18-0"></span>**Theorem 34.** Suppose  $\mathcal{X}$  is finite. Then for any  $\alpha \in [0, \infty]$  the channel capacity equals the minimax redundancy:

<span id="page-18-1"></span>
$$C_{\alpha} = R_{\alpha}. \tag{59}$$

For  $\alpha=1$ , Haussler [55] has extended this result to infinite sample spaces  $\mathcal{X}$ . It seems plausible that his approach might extend to other orders  $\alpha$  as well.

Equation 59 is equivalent to the minimax identity

$$\sup_{\pi} \inf_{Q} \psi_{\alpha}(\pi, Q) = \inf_{Q} \sup_{\pi} \psi_{\alpha}(\pi, Q), \tag{60}$$

where

$$\psi_{\alpha}(\pi, Q) = \int D_{\alpha} (P_{\theta} || Q) d\pi(\theta).$$
 (61)

We will prove this identity using Sion's minimax theorem [56], [57], which we state with its arguments exchanged to make them line up with the arguments of  $\psi_{\alpha}$ :

<span id="page-18-2"></span>**Theorem 35** (Sion's Minimax Theorem). Let A be a convex subset of a linear topological space and B a compact convex subset of a linear topological space. Let  $f: A \times B \to \mathbb{R}$  be such that

- (i)  $f(\cdot, b)$  is upper semi-continuous and quasi-concave on A for each  $b \in B$ ;
- (ii)  $f(a, \cdot)$  is lower semi-continuous and quasi-convex on B for each  $a \in A$ .

Then

$$\sup_{a \in A} \min_{b \in B} f(a, b) = \min_{b \in B} \sup_{a \in A} f(a, b).$$

Proof of Theorem 34: Sion's minimax theorem cannot be applied directly, because  $\psi_{\alpha}$  may be infinite. For  $\lambda \in (0,1)$ , we therefore introduce the auxiliary function

$$\psi_{\alpha}^{\lambda}(\pi, Q) = \psi_{\alpha}(\pi, (1 - \lambda)U + \lambda Q),$$

where U is the uniform distribution on  $\mathcal{X}$ . Finiteness of  $\psi_{\alpha}^{\lambda}$  follows from

<span id="page-18-3"></span>
$$D_{\alpha}(P_{\theta}||(1-\lambda)U + \lambda Q) \le D_{\alpha}(P_{\theta}||U) - \ln(1-\lambda)$$
  
$$\le D_{\infty}(P_{\theta}||U) - \ln(1-\lambda) \le \ln n - \ln(1-\lambda),$$
 (62)

where n denotes the number of elements in  $\mathcal{X}$ .

To verify the other conditions of Theorem 35, we observe that  $\psi_{\alpha}^{\lambda}(\cdot,Q)$  is linear, and hence continuous and concave. Convexity of  $\psi_{\alpha}^{\lambda}(\pi,\cdot)$  follows from convexity of  $\psi_{\alpha}(\pi,\cdot)$ , which holds because  $\psi_{\alpha}(\pi,\cdot)$  is a linear combination of convex functions. Continuity of  $\psi_{\alpha}^{\lambda}(\pi,\cdot)$  follows by the dominated convergence theorem (which applies by (62)) and continuity of  $D_{\alpha}(P_{\theta}\|\cdot)$ . Thus we may apply Sion's minimax theorem.

By

$$D_{\alpha}(P_{\theta}||(1-\lambda)U + \lambda Q) \le D_{\alpha}(P_{\theta}||Q) - \ln \lambda,$$

we also have  $\psi_{\alpha}^{\lambda}(\pi,Q) \leq \psi_{\alpha}(\pi,Q) - \ln \lambda$ , and hence we may reason as follows:

$$\sup_{\pi} \inf_{Q} \psi_{\alpha}(\pi, Q) - \ln \lambda \ge \sup_{\pi} \inf_{Q} \psi_{\alpha}^{\lambda}(\pi, Q)$$
$$= \inf_{Q} \sup_{\pi} \psi_{\alpha}^{\lambda}(\pi, Q) \ge \inf_{Q} \sup_{\pi} \psi_{\alpha}(\pi, Q).$$

By letting  $\lambda$  tend to 1 we find

$$\sup_{\pi} \inf_{Q} \psi_{\alpha}(\pi, Q) \ge \inf_{Q} \sup_{\pi} \psi_{\alpha}(\pi, Q).$$

As the sup inf never exceeds the inf sup [53, Lemma 36.1], the converse inequality also holds, and the proof is complete.

A distribution  $\pi_{opt}$  on the parameter space  $\Theta$  is a *capacity achieving* input distribution if

$$\inf_{\Omega} \int D_{\alpha} (P_{\theta} || Q) \, d\pi_{\text{opt}}(\theta) = C_{\alpha}. \tag{63}$$

A distribution  $Q_{\text{opt}}$  on  $\mathcal{X}$  may be called a *redundancy achieving* distribution if

$$\sup_{\theta} D_{\alpha} \left( P_{\theta} \| Q_{\text{opt}} \right) = R_{\alpha}. \tag{64}$$

If the sample space is finite, then a redundancy achieving distribution always exists:

<span id="page-19-2"></span>**Lemma 9.** Suppose  $\mathcal{X}$  is finite and let  $\alpha \in [0, \infty]$ . Then the function  $Q \mapsto \sup_{\theta} D_{\alpha}(P_{\theta}||Q)$  is continuous and convex, and has at least one minimum. Consequently, a redundancy achieving distribution  $Q_{\text{opt}}$  exists.

*Proof:* Denote the number of elements in  $\mathcal{X}$  by n, let  $\Delta_n = \{(p_1,\ldots,p_n) \mid \sum_{i=1}^n p_i = 1, p_i \geq 0\}$  denote the probability *simplex* on n outcomes, and let  $f(Q) = \sup_{\theta} D_{\alpha}(P_{\theta}\|Q)$ . Since f is the supremum over continuous, convex functions, it is lower semi-continuous and convex itself. As the domain of f is  $\Delta_n$ , which is compact, this implies that it attains its minimum. Moreover, convexity on a simplex implies upper semi-continuity [53, Theorem 10.2], so that f is both lower and upper semi-continuous, which means that it is continuous.

<span id="page-19-0"></span>**Theorem 36.** Suppose  $\mathcal{X}$  is finite and let  $\alpha \in [0, \infty]$ . If there exists a (possibly non-unique) capacity achieving input distribution  $\pi_{\text{opt}}$ , then  $\int D_{\alpha}(P_{\theta}||Q) d\pi_{\text{opt}}(\theta)$  is minimized by  $Q = Q_{\text{opt}}$  and  $D_{\alpha}(P_{\theta}||Q_{\text{opt}}) = R_{\alpha}$  almost surely under  $\pi_{\text{opt}}$ .

If  $R_{\alpha}$  is regarded as the radius of  $\{P_{\theta} \mid \theta \in \Theta\}$ , then this theorem shows how  $Q_{\text{opt}}$  may be interpreted as its center.

*Proof:* Since  $\pi_{opt}$  is capacity achieving,

$$C_{\alpha} = \inf_{Q} \int D_{\alpha} (P_{\theta} || Q) d\pi_{\text{opt}}(\theta)$$

$$\leq \int D_{\alpha} (P_{\theta} || Q_{\text{opt}}) d\pi_{\text{opt}}(\theta)$$

$$\leq \int R_{\alpha} d\pi_{\text{opt}}(\theta) = R_{\alpha} = C_{\alpha}.$$

The result follows because both inequalities must be equalities.

Three orders  $\alpha$  for the channel capacity  $C_{\alpha}$  and minimax redundancy  $R_{\alpha}$  are of particular interest. The classical ones are  $\alpha=1$ , because it corresponds to the original definition of channel capacity by Shannon, and  $\alpha=0$  because  $C_0$  gives an upper bound on the zero error capacity, which also dates back to Shannon.

Now let us look at the case  $\alpha = \infty$ , assuming for simplicity that  $\mathcal{X}$  is countable. We find that

$$\sup_{\theta} D_{\infty}(P_{\theta} || Q) = \sup_{\theta} \ln \sup_{x} \frac{P_{\theta}(x)}{Q(x)}$$

$$= \sup_{x} \ln \frac{\sup_{\theta} P_{\theta}(x)}{Q(x)}$$
(65)

is the worst-case regret of Q relative to  $\{P_{\theta} \mid \theta \in \Theta\}$  [3]. As is well known [3], [58], the distribution that minimizes the worst-case regret is uniquely given by the normalized maximum likelihood or Shtarkov distribution

<span id="page-19-4"></span>
$$S(x) = \frac{\sup_{\theta} P_{\theta}(x)}{\sum_{x} \sup_{\theta} P_{\theta}(x)},$$
 (66)

provided that the normalizing sum is finite, so that S is well defined.

<span id="page-19-1"></span>**Theorem 37.** Suppose that  $\mathcal{X}$  is countable and that the minimax redundancy  $R_{\infty}$  is finite. Then S is well defined and the worst-case regret of any distribution Q satisfies

<span id="page-19-5"></span>
$$\sup_{\theta} D_{\infty}(P_{\theta} \| Q) = R_{\infty} + D_{\infty}(S \| Q). \tag{67}$$

In particular,  $Q_{opt} = S$  is unique and

<span id="page-19-6"></span>
$$R_{\infty} = \ln \sum_{x} \sup_{\theta} P_{\theta}(x) < \infty.$$
 (68)

*Proof:* Since  $R_{\infty}<\infty$ , for any finite  $C>R_{\infty}$  there must exist a distribution  $Q_C$  such that  $\sup_x \ln \frac{\sup_{\theta} P_{\theta}(x)}{Q_C(x)} \leq C$ . Hence

$$\sum_{x} \sup_{\theta} P_{\theta}(x) \le \sum_{x} Q_{C}(x) e^{C} = e^{C} < \infty,$$

so that S is well defined.

Now for any arbitrary distribution Q, we have

$$\begin{split} \sup_{x} \ln \frac{\sup_{\theta} P_{\theta}(x)}{Q(x)} &= \sup_{x} \left( \ln \frac{\sup_{\theta} P_{\theta}(x)}{S(x)} + \ln \frac{S(x)}{Q(x)} \right) \\ &= \ln \sum_{x} \sup_{\theta} P_{\theta}(x) + \sup_{x} \ln \frac{S(x)}{Q(x)} \\ &= \sup_{x} \ln \frac{\sup_{\theta} P_{\theta}(x)}{S(x)} + \sup_{x} \ln \frac{S(x)}{Q(x)}. \end{split}$$

Since  $\sup_x \ln \frac{S(x)}{Q(x)} = D_{\infty}(S||Q) \ge 0$ , with strict inequality unless Q = S, this establishes (67) and  $Q_{\text{opt}} = S$ . Finally, (68) follows by evaluating  $\sup_x \ln \frac{\sup_\theta P_{\theta}(x)}{S(x)}$ .

We conjecture that the previous result generalizes to any positive order  $\alpha$  as a one-sided inequality:

<span id="page-19-3"></span>**Conjecture 1.** Let  $\alpha \in (0, \infty]$  and suppose that  $R_{\alpha} < \infty$ . Then we conjecture that there exists a unique redundancy achieving distribution

$$Q_{\text{opt}} = \arg\min_{Q} \sup_{\theta} D_{\alpha}(P_{\theta} || Q), \tag{69}$$

and that for all Q

<span id="page-19-8"></span>
$$\sup_{\theta} D_{\alpha}(P_{\theta} \| Q) \ge R_{\alpha} + D_{\alpha}(Q_{\text{opt}} \| Q). \tag{70}$$

This conjecture is reminiscent of Sibson's identity [4], [59]. It would imply that any distribution Q that is close to achieving the minimax redundancy in the sense that

$$\sup_{\theta} D_{\alpha}(P_{\theta} \| Q) \le R_{\alpha} + \delta, \tag{71}$$

must be close to  $Q_{\mathrm{opt}}$  in the sense that

$$D_{\alpha}(Q_{\text{opt}}||Q) \le \delta. \tag{72}$$

As shown in Example 4 below, Conjecture 1 does not hold for  $\alpha=0$ . For  $\alpha>0$ , it can be expressed as a minimax identity for the function

$$\phi_{\alpha}(R,Q) = \sup_{\theta \in \Theta} D_{\alpha}(P_{\theta}||Q) - D_{\alpha}(R||Q), \tag{73}$$

where we adopt the convention that  $\phi_{\alpha}(R,Q) = \infty$  if both  $\sup_{\theta \in \Theta} D_{\alpha}(P_{\theta} \| Q)$  and  $D_{\alpha}(R \| Q)$  are infinite. However, we cannot use Sion's minimax theorem (Theorem 35) to prove the conjecture, because in general  $\phi_{\alpha}$  is not quasi-convex in its second argument<sup>2</sup>.

A distribution  $\pi$  on the parameter space  $\Theta$  is called a barycentric input distribution if

$$Q_{\text{opt}} = \int P_{\theta} \, \mathrm{d}\pi(\theta). \tag{74}$$

<span id="page-19-7"></span><sup>2</sup>We mistakenly claimed this in an earlier draft of this paper.

<span id="page-20-2"></span>**Example 4.** Take  $\alpha \in (0, \infty]$  and consider the distributions

$$P_1 = (1/2, 0, 1/2), P_2 = (0, 1/2, 1/2) (75)$$

on a three-element set. Then by symmetry and convexity of Rényi divergence in its second argument, there must exist a redundancy achieving distribution of the form

$$Q_{\text{opt}(\alpha)} = (q, q, 1 - 2q).$$
 (76)

If  $\alpha$  is a simple order, then for  $\theta \in \{1, 2\}$  the divergence is

$$D_{\alpha}(P_{\theta}||Q_{\text{opt}(\alpha)}) = \frac{1}{\alpha - 1} \ln\left(\left(\frac{1}{2}\right)^{\alpha} q^{1 - \alpha} + \left(\frac{1}{2}\right)^{\alpha} (1 - 2q)^{1 - \alpha}\right) = \frac{\alpha \ln 2}{1 - \alpha} + \frac{1}{\alpha - 1} \ln\left(q^{1 - \alpha} + (1 - 2q)^{1 - \alpha}\right).$$
(77)

To find q, we therefore we have to extremize

$$f(q) = q^{1-\alpha} + (1 - 2q)^{1-\alpha}, \tag{78}$$

which leads to

<span id="page-20-3"></span>
$$q = \frac{1}{2 + 2^{1/\alpha}}. (79)$$

The reader may verify that (79) also holds for  $\alpha=1$ , giving  $Q_{\mathrm{opt}(1)}=(\frac{1}{4},\frac{1}{4},\frac{1}{2})$ , and for  $\alpha=\infty$ , leading to  $Q_{\mathrm{opt}(\infty)}=(\frac{1}{3},\frac{1}{3},\frac{1}{3})$ . Note that only for  $\alpha=1$  is  $Q_{\mathrm{opt}(\alpha)}$  a convex combination of  $P_1$  and  $P_2$ , with unique barycentric input distribution  $\pi=(1/2,1/2)$ .

Finally, consider  $\alpha=0$ . In this case (79) still holds, giving  $Q_{\text{opt}(0)}=(0,0,1)$ . Now let Q=(1/2,1/2,0). Then, for  $\theta\in\{1,2\}$ , we see that the first two terms in (70) are well behaved:

$$\begin{split} \lim_{\alpha \downarrow 0} \sup_{\theta} D_{\alpha}(P_{\theta} \| Q) &= \sup_{\theta} D_{0}(P_{\theta} \| Q) = \ln 2, \\ \lim_{\alpha \downarrow 0} \sup_{\theta} D_{\alpha}(P_{\theta} \| Q_{\text{opt}(\alpha)}) &= 0 = \sup_{\theta} D_{0}(P_{\theta} \| Q_{\text{opt}(0)}). \end{split}$$

The last term, however, evaluates to  $D_0(Q_{\text{opt}(0)}\|Q) = \infty$ , so we obtain a counterexample to (70). The difference in behaviour between  $\alpha = 0$  and  $\alpha > 0$  may be understood by observing that  $\lim_{\alpha \downarrow 0} D_{\alpha}(Q_{\text{opt}(\alpha)}\|Q) = \ln 2 \neq D_0(Q_{\text{opt}(0)}\|Q)$ .

<span id="page-20-1"></span>**Theorem 38.** Suppose that  $\mathcal{X}$  is finite and that there exists a maximum likelihood function  $\hat{\theta} \colon \mathcal{X} \to \Theta$  (that is,  $P_{\theta}(x) \leq P_{\hat{\theta}(x)}(x)$  for all  $x \in \mathcal{X}$ ). Then, for  $\alpha = \infty$ , the distribution

$$\pi_{\text{opt}}(\theta) = S(\{x \mid \hat{\theta}(x) = \theta\}) \tag{80}$$

is a capacity achieving input distribution, where S is as defined in (66).

*Proof:* As  $\mathcal{X}$  is finite, there can be at most a finite set

 $\Theta_{\mathcal{X}} \subset \Theta$  of  $\theta$  on which  $\pi_{\text{opt}}(\theta) > 0$ . Hence, for any Q,

$$\int D_{\infty}(P_{\theta}||Q) d\pi_{\text{opt}}(\theta) = \sum_{\theta \in \Theta_{\mathcal{X}}} D_{\infty}(P_{\theta}||Q) \pi_{\text{opt}}(\theta)$$

$$= \sum_{\theta \in \Theta_{\mathcal{X}}} D_{\infty}(P_{\theta}||Q) \sum_{x} S(x) \mathbf{1}_{\{\hat{\theta}(x) = \theta\}}$$

$$= \sum_{x} S(x) D_{\infty}(P_{\hat{\theta}(x)}||Q)$$

$$= \sum_{x} S(x) \max_{y} \ln \frac{P_{\hat{\theta}(x)}(y)}{Q(y)}$$

$$\geq \sum_{x} S(x) \ln \frac{P_{\hat{\theta}(x)}(x)}{Q(x)}$$

$$= D(S||Q) + \sum_{x} S(x) \ln \frac{P_{\hat{\theta}(x)}(x)}{S(x)}$$

$$= D(S||Q) + \sum_{x} S(x) R_{\infty}$$

$$= D(S||Q) + R_{\infty}.$$

By taking the infimum over Q on both sides we get

$$\inf_{Q} \int D_{\infty}(P_{\theta} || Q) d\pi_{\text{opt}}(\theta) \ge R_{\infty}.$$

Since the reverse inequality is trivial and  $R_{\infty} = C_{\infty}$ , we find that  $\pi_{\text{opt}}$  is a capacity achieving input distribution, as required.

**Example 5.** Let  $\theta \in [0,1]$  denote the success probability of a binomial distribution  $P_{\theta} = \operatorname{Bin}(2,\theta)$  on  $\mathcal{X} = \{0,1,2\}$ . Then for  $\alpha = \infty$  the redundancy achieving distribution is  $S = (\frac{2}{5}, \frac{1}{5}, \frac{2}{5})$  and the minimax redundancy is  $R_{\infty} = \ln \frac{5}{2}$ .

In this case there are many barycentric input distributions. For example, the distribution  $\pi=\frac{1}{5}M_0+\frac{3}{5}U+\frac{1}{5}M_1$  is a barycentric input distribution, where  $M_\theta$  is a point-mass on  $\theta$  and U is the uniform distribution on [0,1]. Another example is the distribution  $\pi=(\frac{3}{10},\frac{2}{5},\frac{3}{10})$  on the maximum likelihood parameters  $\Psi=\{0,\frac{1}{2},1\}$  for the elements of  $\mathcal{X}$ . By Theorem 38, there also exists a capacity achieving input distribution  $\pi_{\text{opt}}$ , and it is supported on  $\Psi$ , with probabilities

$$\left(\pi_{\text{opt}}(0), \pi_{\text{opt}}(\frac{1}{2}), \pi_{\text{opt}}(1)\right) = \left(S(0), S(1), S(2)\right) = \left(\frac{2}{5}, \frac{1}{5}, \frac{2}{5}\right).$$

## V. NEGATIVE ORDERS

<span id="page-20-0"></span>Until now we have only discussed Rényi divergence of non-negative orders. However, using formula (9) for  $\alpha \in (-\infty,0)$  (reading  $\frac{q^{1-\alpha}}{p^{-\alpha}}$  for  $p^{\alpha}q^{1-\alpha}$ ), it may also be defined for these negative orders. This definition extends to  $\alpha = -\infty$  by

$$D_{-\infty}(P||Q) = \lim_{\alpha, 1 \to \infty} D_{\alpha}(P||Q). \tag{81}$$

According to Rényi [1], only positive orders can be regarded as measures of information, and negative orders indeed seem to be hardly used in applications. Nevertheless, for completeness we will also study Rényi divergence of negative orders. As will be seen below, our results for positive orders carry over to the negative orders, but most properties are reversed. People may have avoided negative orders because of these reversed

properties. Avoiding negative orders is always possible, because they are related to orders  $\alpha>1$  by an extension of skew symmetry:

<span id="page-21-1"></span>**Lemma 10** (Skew Symmetry). For any  $\alpha \in (-\infty, \infty)$ ,  $\alpha \notin \{0, 1\}$ 

<span id="page-21-5"></span>
$$D_{\alpha}(P||Q) = \frac{\alpha}{1-\alpha} D_{1-\alpha}(Q||P). \tag{82}$$

Furthermore

$$D_{-\infty}(P||Q) = -D_{\infty}(Q||P)$$

$$= \ln \inf_{A \in \mathcal{F}} \frac{P(A)}{Q(A)} = \ln \left( \operatorname{ess inf} \frac{p}{q} \right), \quad (83)$$

with the conventions that 0/0 = 0 and  $x/0 = \infty$  for x > 0.

*Proof:* The identity (82) follows directly from definitions. It implies  $D_{-\infty}(P\|Q) = -D_{\infty}(Q\|P)$ , because  $\frac{\alpha}{1-\alpha}$  tends to -1 as  $\alpha \to -\infty$ . The remaining identities follow from the closed-form expressions for  $D_{\infty}(Q\|P)$  in Theorem 6.

Skew symmetry gives a kind of symmetry between the orders  $1/2 + \alpha$  and  $1/2 - \alpha$ . In applications in physics this symmetry is related to the use of so-called *escort probabilities* [60].

Whereas the nonnegative orders generally satisfy the same or similar properties for different values of  $\alpha$ , the fact that  $\frac{\alpha}{1-\alpha} < 0$  for  $\alpha < 0$ , implies that properties for negative orders are often inverted. For example, Rényi divergence for negative orders is nonpositive, concave in its first argument and upper semi-continuous in the topology of setwise convergence. In addition, the data processing inequality holds with its inequality reversed and for  $\alpha \in (-\infty,0)$  Theorem 2 applies with an infimum instead of a supremum.

Not all properties are inverted, however. Most notably, it does remain true that Rényi divergence is nondecreasing and continuous in  $\alpha$  (see also Figure 1):

<span id="page-21-2"></span>**Theorem 39.** For  $\alpha \in [-\infty, \infty]$ , the Rényi divergence  $D_{\alpha}(P||Q)$  is nondecreasing in  $\alpha$ .

*Proof:* For  $\alpha < 0$ ,  $D_{\alpha}(P||Q) \leq 0$  and for  $\alpha \geq 0$ ,  $D_{\alpha}(P||Q) \geq 0$ , so the divergence for negative orders never exceeds the divergence for nonnegative orders. The remainder of the proof follows from Theorem 3 and skew symmetry.

<span id="page-21-3"></span>**Theorem 40.** The Rényi divergence  $D_{\alpha}(P||Q)$  is continuous in  $\alpha$  on  $\mathcal{A} = \{\alpha \in [-\infty, \infty] \mid 0 \le \alpha \le 1 \text{ or } |D_{\alpha}(P||Q)| < \infty\}.$ 

*Proof:* Rényi divergence is nondecreasing in  $\alpha$ , nonnegative for  $\alpha \geq 0$  and nonpositive for  $\alpha < 0$ . Therefore the required continuity follows directly from Theorem 7 and skew symmetry, except for the case

$$\lim_{\alpha \uparrow 0} D_{\alpha}(P \| Q) = D_0(P \| Q),$$

which is required to hold if there exists a value  $\beta < 0$  such that  $D_{\beta}(P\|Q) > -\infty$ . In this case  $D_{1-\beta}(Q\|P) = \frac{1-\beta}{\beta}D_{\beta}(P\|Q) < \infty$ , which implies: (a) that  $Q \ll P$ , so  $D_0(P\|Q) = 0$ ; and (b) that  $D(Q\|P) < \infty$  and by Theorem 5

$$\lim_{\alpha \uparrow 0} D_{\alpha}(P \| Q) = \lim_{\alpha \uparrow 0} \frac{\alpha}{1 - \alpha} D_{1-\alpha}(Q \| P) = 0 \cdot D(Q \| P) = 0.$$

#### VI. COUNTEREXAMPLES

<span id="page-21-0"></span>Some useful properties that are satisfied by other divergences, are not satisfied by Rényi divergence. Here we give counterexamples for a few important ones.

#### <span id="page-21-4"></span>A. Convexity in P does not hold for $\alpha > 1$

Rényi divergence for  $\alpha \in (1,\infty)$  is not convex in its first argument. Consider the following counterexample: let  $0 < p_0 < p_1 < 1$  be any two numbers, and let  $p_{1/2} = \frac{p_0 + p_1}{2}$ . Let  $\varepsilon > 0$  be arbitrary, and let 0 < q < 1 be small enough that

$$\max_{i \in \{0,1\}} \frac{(1-p_i)^{\alpha} (1-q)^{1-\alpha}}{p_i^{\alpha} q^{1-\alpha}} \le \varepsilon.$$

Then convexity of  $D_{\alpha}$  in its first argument would imply that

$$\frac{1}{2} \ln \left( p_0^{\alpha} q^{1-\alpha} + (1-p_0)^{\alpha} (1-q)^{1-\alpha} \right) 
+ \frac{1}{2} \ln \left( p_1^{\alpha} q^{1-\alpha} + (1-p_1)^{\alpha} (1-q)^{1-\alpha} \right) 
\ge \ln \left( p_{1/2}^{\alpha} q^{1-\alpha} + (1-p_{1/2})^{\alpha} (1-q)^{1-\alpha} \right),$$

which implies

$$\begin{split} \frac{1}{2} \ln \left( p_0^{\alpha} q^{1-\alpha} (1+\varepsilon) \right) + \frac{1}{2} \ln \left( p_1^{\alpha} q^{1-\alpha} (1+\varepsilon) \right) \\ & \geq \ln \left( p_{1/2}^{\alpha} q^{1-\alpha} \right) \\ \frac{1}{2} \ln \left( p_0^{\alpha} (1+\varepsilon) \right) + \frac{1}{2} \ln \left( p_1^{\alpha} (1+\varepsilon) \right) \geq \ln \left( p_{1/2}^{\alpha} \right). \end{split}$$

As this expression holds for all  $\varepsilon > 0$ , we get

$$\frac{1}{2} \ln p_0^{\alpha} + \frac{1}{2} \ln p_1^{\alpha} \ge \ln p_{1/2}^{\alpha}$$

$$\frac{1}{2} \ln p_0 + \frac{1}{2} \ln p_1 \ge \ln \frac{p_0 + p_1}{2}$$

which is a contradiction, because the natural logarithm is strictly concave.

#### B. Rényi divergence is not continuous

In general the Rényi divergence of order  $\alpha \in (0,1)$  is not continuous in the topology of setwise convergence. To construct a counterexample, let  $P_n$  denote the probability distribution on  $[0,2\pi]$  with density  $\frac{1+\sin(nx)}{2\pi}$  and let  $Q_n$  denote the probability distribution on  $[0,2\pi]$  with density  $\frac{1-\sin(nx)}{2\pi}$  for  $n=1,2,\ldots$  Then  $D_{\alpha}(P_n\|Q_n)>0$  does not depend on n, and both  $P_n$  and  $Q_n$  converge to the uniform distribution U on  $[0,2\pi]$  in the topology of setwise convergence. Consequently,  $\lim_{n\to\infty}D_{\alpha}\left(P_n\|Q_n\right)\neq 0=D_{\alpha}\left(U\|U\right)$ , so in general  $D_{\alpha}$  is not continuous in the topology of setwise convergence.

#### C. Not a metric

Except for the order  $\alpha=1/2$ , Rényi divergence is not symmetric and cannot be a metric. For  $\alpha=1/2$ , Rényi divergence is symmetric and by (5) it locally behaves like the square of a metric. Therefore one may wonder whether it actually is the square of a metric itself. Consider the following three distributions on two points:

$$P = (0,1), \qquad Q = (1/2, 1/2), \qquad R = (1,0).$$

Then

$$D_{1/2}(P||Q) = \ln 2$$
,  $D_{1/2}(Q||R) = \ln 2$ ,  $D_{1/2}(P||R) = \infty$ .

As the square roots of these divergences violate the triangle inequality, D1/<sup>2</sup> cannot be the square of a metric.

## VII. SUMMARY

We have reviewed and derived the most important properties of Renyi divergence and Kullback-Leibler divergence. These ´ include convexity and continuity properties, a generalization of the Pythagorean inequality to general orders, limits of σalgebras, additivity for product distributions on infinite sequences, and the relation of the special order 0 to absolute continuity and mutual singularity of such distributions.

We have also derived several key minimax identities. In particular, Theorems [30](#page-16-2) and [32](#page-17-0) illuminate the relation between Renyi divergence, Kullback-Leibler divergence and Chernoff ´ information in hypothesis testing. And Theorem [34](#page-18-0) extends the known equivalence of channel capacity and minimax redundancy to continuous channel inputs (for all orders).

## ACKNOWLEDGMENTS

The authors would like to thank Peter Grunwald, Wouter ¨ Koolen and two anonymous referees for useful comments. Part of the research was done while both authors were with the Centrum Wiskunde & Informatica in Amsterdam, the Netherlands, and while Tim van Erven was with the VU University, also in Amsterdam. This work was supported in part by NWO Rubicon grant 680-50-1112.

## REFERENCES

- <span id="page-22-0"></span>[1] A. Renyi, "On measures of entropy and information," in ´ *Proceedings of the Fourth Berkeley Symposium on Mathematical Statistics and Probability*, vol. 1, pp. 547–561, 1961.
- <span id="page-22-1"></span>[2] P. Harremoes, "Interpretations of R ¨ enyi entropies and divergences," ´ *Physica A: Statistical Mechanics and its Applications*, vol. 365, no. 1, pp. 57–62, 2006.
- <span id="page-22-2"></span>[3] P. D. Grunwald, ¨ *The Minimum Description Length Principle*. The MIT Press, 2007.
- <span id="page-22-3"></span>[4] I. Csiszar, "Generalized cutoff rates and R ´ enyi's information measures," ´ *IEEE Transactions on Information Theory*, vol. 41, no. 1, pp. 26–34, 1995.
- <span id="page-22-4"></span>[5] T. Zhang, "From -entropy to KL-entropy: Analysis of minimum information complexity density estimation," *The Annals of Statistics*, vol. 34, no. 5, pp. 2180–2210, 2006.
- <span id="page-22-5"></span>[6] D. Haussler and M. Opper, "Mutual information, metric entropy and cumulative relative entropy risk," *The Annals of Statistics*, vol. 25, no. 6, pp. 2451–2492, 1997.
- <span id="page-22-6"></span>[7] T. van Erven, *When Data Compression and Statistics Disagree: Two Frequentist Challenges for the Minimum Description Length Principle*. PhD thesis, Leiden University, 2010.
- <span id="page-22-7"></span>[8] L. Le Cam, "Convergence of estimates under dimensionality restrictions," *The Annals of Statistics*, vol. 1, no. 1, pp. 38–53, 1973.
- [9] L. Birge, "On estimating a density using Hellinger distance and some ´ other strange facts," *Probability Theory and Related Fields*, vol. 71, pp. 271–291, 1986.
- <span id="page-22-8"></span>[10] S. van de Geer, "Hellinger-consistency of certain nonparametric maximum likelihood estimators," *The Annals of Statistics*, vol. 21, no. 1, pp. 14–44, 1993.
- <span id="page-22-9"></span>[11] D. Morales, L. Pardo, and I. Vajda, "Renyi statistics in directed families ´ of exponential experiments," *Statistics*, vol. 34, pp. 151–174, 2000.
- <span id="page-22-10"></span>[12] Y. Mansour, M. Mohri, and A. Rostamizadeh, "Multiple source adaptation and the Renyi divergence," in ´ *Proceedings of the Twenty-Fifth Conference on Uncertainty in Artificial Intelligence (UAI)*, pp. 367–374, 2009.

- <span id="page-22-11"></span>[13] A. O. Hero, B. Ma, O. Michel, and J. D. Gorman, "Alpha-divergence for classification, indexing and retrieval (revised)," Tech. Rep. CSPL-334, Communications and Signal Processing Laboratory, The University of Michigan, 2003.
- <span id="page-22-12"></span>[14] J. Aczel and Z. Dar ´ oczy, ´ *On Measures of Information and Their Characterizations*. Academic Press, 1975.
- <span id="page-22-13"></span>[15] M. Ben-Bassat and J. Raviv, "Renyi's entropy and the probability of error," *IEEE Transactions on Information Theory*, vol. 24, no. 3, pp. 324–330, 1978.
- <span id="page-22-14"></span>[16] T. van Erven and P. Harremoes, "R ¨ enyi divergence and majorization," ´ in *Proceedings of the IEEE International Symposium on Information Theory (ISIT)*, 2010.
- <span id="page-22-15"></span>[17] O. Shayevitz, "A note on a characterization of Renyi measures and ´ its relation to composite hypothesis testing." arXiv:1012.4401v1, Dec. 2010.
- <span id="page-22-16"></span>[18] O. Shayevitz, "On Renyi measures and hypothesis testing," in ´ *IEEE International Symposium on Information Theory Proceedings*, pp. 800– 804, 2011.
- <span id="page-22-17"></span>[19] V. S. Huzurbazar, "Exact forms of some invariants for distributions admitting sufficient statistics," *Biometrika*, vol. 42, no. 3/4, pp. pp. 533– 537, 1955.
- <span id="page-22-18"></span>[20] F. Liese and I. Vajda, *Convex Statistical Distances*. Leipzig: Teubner, 1987.
- <span id="page-22-19"></span>[21] M. Gil, "On Renyi divergence measures for continuous alphabet ´ sources," Master's thesis, Queen's University, 2011.
- <span id="page-22-20"></span>[22] M. Gil, F. Alajaji, and T. Linder, "Renyi divergence measures for com- ´ monly used univariate continuous distributions," *Information Sciences*, vol. 249, pp. 124–131, 2013.
- <span id="page-22-21"></span>[23] D. Aldous and P. Diaconis, "Strong uniform times and finite random walks," *Advances in Applied Mathematics*, vol. 8, pp. 69–97, 1987.
- <span id="page-22-22"></span>[24] A. L. Gibbs and F. E. Su, "On choosing and bounding probability metrics," *International Statistical Review*, vol. 70, pp. 419–435, 2002.
- <span id="page-22-23"></span>[25] G. L. Gilardoni, "On Pinsker's and Vajda's type inequalities for Csiszar's ´ f-divergences," *IEEE Transactions on Information Theory*, vol. 56, no. 11, pp. 5377–5386, 2010.
- <span id="page-22-25"></span>[26] D. Pollard, *A User's Guide to Measure Theoretic Probability*. Cambridge University Press, 2002.
- <span id="page-22-24"></span>[27] F. Liese and I. Vajda, "On divergences and informations in statistics and information theory," *IEEE Transactions on Information Theory*, vol. 52, no. 10, pp. 4394–4412, 2006.
- <span id="page-22-26"></span>[28] A. N. Shiryaev, *Probability*. Springer-Verlag, 1996.
- <span id="page-22-27"></span>[29] S. M. Ali and S. D. Silvey, "A general class of coefficients of divergence of one distribution from another," *Journal of the Royal Statistical Society, series B*, vol. 28, no. 1, pp. 131–142, 1966.
- <span id="page-22-28"></span>[30] T. M. Cover and J. A. Thomas, *Elements of Information Theory*. Wiley, 1991.
- [31] I. Csiszar, "I-divergence geometry of probability distributions and min- ´ imization problems," *The Annals of Probability*, vol. 3, no. 1, pp. 146– 158, 1975.
- <span id="page-22-29"></span>[32] F. Topsøe, *Entropy, Search, Complexity*, vol. 16 of *Bolyai Society Mathematical Studies*, ch. 8, Information Theory at the Service of Science, pp. 179–207. Springer, 2007.
- <span id="page-22-30"></span>[33] R. Sundaresan, "A measure of discrimination and its geometric properties," in *Proceedings of the IEEE International Symposium on Information Theory (ISIT)*, 2002.
- <span id="page-22-31"></span>[34] R. Sundaresan, "Guessing under source uncertainty with side information," in *Proceedings of the IEEE International Symposium on Information Theory (ISIT)*, 2006.
- <span id="page-22-32"></span>[35] Y. V. Prokhorov, "Convergence of random processes and limit theorems in probability theory," *Theory of Probability and Its Applications*, vol. I, no. 2, pp. 157–214, 1956.
- <span id="page-22-33"></span>[36] E. C. Posner, "Random coding strategies for minimum entropy," *IEEE Transactions on Information Theory*, vol. 21, no. 4, pp. 388–391, 1975.
- <span id="page-22-34"></span>[37] A. W. van der Vaart and J. A. Wellner, *Weak Convergence and Empirical Processes: With Applications to Statistics*. Springer, 1996. (Corrected second printing, 2000).
- <span id="page-22-35"></span>[38] M. S. Pinsker, *Information and Information Stability of Random Variables and Processes*. Holden-Day, 1964. Translated by A. Feinstein.
- <span id="page-22-36"></span>[39] A. R. Barron, "Limits of information, Markov chains and projections," in *Proceedings of the IEEE International Symposium on Information Theory (ISIT)*, p. 25, 2000.
- <span id="page-22-37"></span>[40] P. Harremoes and K. K. Holst, "Convergence of Markov chains in ¨ information divergence," *Journal of Theoretical Probability*, vol. 22, pp. 186–202, 2009.
- <span id="page-22-38"></span>[41] O. Kallenberg, *Foundations of Modern Probability*. Springer, 1997.
- <span id="page-22-39"></span>[42] A. W. van der Vaart, *Asymptotic Statistics*. Cambridge University Press, 1998.

- <span id="page-23-0"></span>[43] J. Feldman, "Equivalence and perpendicularity of Gaussian processes," *Pacific Journal of Mathematics*, vol. 8, no. 4, pp. 699–708, 1958.
- [44] J. Hajek, "On a property of normal distributions of any stochastic ´ process," *Czechoslovak Mathematical Journal*, vol. 8, no. 4, pp. 610– 618, 1958. In Russian with English summary.
- <span id="page-23-1"></span>[45] B. J. Thelen, "Fisher information and dichotomies in equivalence/contiguity," *The Annals of Probability*, vol. 17, no. 4, pp. 1664– 1690, 1989.
- <span id="page-23-2"></span>[46] S. Kakutani, "On equivalence of infinite product measures," *The Annals of Mathematics*, vol. 49, no. 1, pp. 214–224, 1948.
- <span id="page-23-3"></span>[47] A. Renyi, "On some basic problems of statistics from the point of view ´ of information theory," in *Proceedings of the Fifth Berkeley Symposium on Mathematical Statistics and Probability*, vol. 1: Statistics, pp. 531– 543, 1967.
- <span id="page-23-4"></span>[48] S. Kullback, *Information theory and statistics*. Wiley, 1959.
- <span id="page-23-5"></span>[49] T. Nemetz, "On the α-divergence rate for Markov-dependent hypotheses," *Problems of Control and Information Theory*, vol. 3, no. 2, pp. 147– 155, 1974.
- <span id="page-23-6"></span>[50] Z. Rached, F. Alajaji, and L. L. Campbell, "Renyi's divergence and ´ entropy rates for finite alphabet Markov sources," *IEEE Transactions on Information Theory*, vol. 47, no. 4, pp. 1553–1561, 2001.
- <span id="page-23-7"></span>[51] I. Csiszar, "Information projections revisited," ´ *IEEE Transactions on Information Theory*, vol. 49, no. 6, pp. 1474–1490, 2003.
- <span id="page-23-8"></span>[52] A. A. Fedotov, P. Harremoes, and F. Topsøe, "Refinements of Pinsker's ¨ inequality," *IEEE Transactions on Information Theory*, vol. 49, no. 6, pp. 1491–1498, 2003.
- <span id="page-23-9"></span>[53] R. T. Rockafellar, *Convex Analysis*. Princeton University Press, 1970.
- <span id="page-23-10"></span>[54] B. Ryabko, "Comments on "a source matching approach to finding minimax codes" by Davisson, L. D. and Leon-Garcia, A.," *IEEE Transactions on Information Theory*, vol. 27, no. 6, pp. 780–781, 1981. Including also the ensuing Editor's Note.
- <span id="page-23-11"></span>[55] D. Haussler, "A general minimax result for relative entropy," *IEEE Transactions on Information Theory*, vol. 43, no. 4, pp. 1276–1280, 1997.
- <span id="page-23-12"></span>[56] M. Sion, "On general minimax theorems," *Pacific Journal of Mathematics*, vol. 8, no. 1, pp. 171–176, 1958.
- <span id="page-23-13"></span>[57] H. Komiya, "Elementary proof for Sion's minimax theorem," *Kodai Mathematical Journal*, vol. 11, no. 1, pp. 5–7, 1988.
- <span id="page-23-14"></span>[58] Y. M. Shtar'kov, "Universal sequential coding of single messages," *Problems of Information Transmission*, vol. 23, no. 3, pp. 175–186, 1987.
- <span id="page-23-15"></span>[59] R. Sibson, "Information radius," *Z. Warscheinlichkeitstheorie verw. Geb.*, vol. 14, pp. 149–160, 1969.
- <span id="page-23-16"></span>[60] J. Naudts, "Estimators, escort probabilities, and φ-exponential families in statistical physics," *Journal of Inequalities in Pure and Applied Mathematics*, vol. 5, no. 4, 102, 2004.

![](_page_23_Picture_20.jpeg)

Tim van Erven is originally from the Netherlands. He performed his PhD research at the Centrum Wiskunde & Informatica (CWI) in Amsterdam, and received his PhD degree from Leiden University in 2010. After postdoc positions at the CWI and the Vrije Universiteit in Amsterdam, he obtained a Rubicon grant from the Netherlands Organisation for Scientific Research (NWO) to do a two-year postdoc at the Universite Paris-Sud in France. ´

His interests are in topics related to information theory and statistics, including minimum descrip-

tion length (MDL) learning, sequential prediction with individual sequences (online learning), and statistical learning theory. The present paper was partially motivated by the importance of Renyi divergence in stating sufficient ´ conditions for convergence of the MDL estimator, which he studied in his PhD thesis [\[7,](#page-22-6) Chapter 5].

![](_page_23_Picture_24.jpeg)

Peter Harremoes¨ Peter Harremoes (M'00) received ¨ the BSc degree in mathematics in 1984, the Exam. Art. degree in archaeology in 1985, and the MSc degree in mathematics in 1988, all from the University of Copenhagen, Denmark. In 1993 he received his PhD degree in the natural sciences from Roskilde University, Denmark.

From 1993 to 1998, he worked as a mountaineer. From 1998 to 2000, he held various teaching positions in mathematics. From 2001 to 2006, he was Postdoctoral Fellow with the University of Copen-

hagen, with an extended visit to the Zentrum fur Interdisziplin ¨ are Forschung, ¨ Bielefeld, Germany in 2003. From 2006 to 2009, he was affiliated with the Centrum Wiskunde & Informatica, Amsterdam, The Netherlands, under the European Pascal Network of Excellence. Since then he has been affiliated with Niels Brock, Copenhagen Business College, in Denmark.

From 2007 to 2011 Peter Harremoes has been Editor-in-Chief of the journal ¨ *Entropy*. He is currently an editor for that journal.