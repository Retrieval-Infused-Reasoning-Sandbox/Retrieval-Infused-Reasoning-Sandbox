# Elliptic stable envelopes

## Mina Aganagic and Andrei Okounkov

To Igor Krichever, with gratitude for inspiration and friendship.

#### Abstract

We construct stable envelopes in equivariant elliptic cohomology of Nakajima quiver varieties. In particular, this gives an elliptic generalization of the results of [\[49\]](#page-66-0). We apply them to the computation of the monodromy of q-difference equations arising in the enumerative K-theory of rational curves in Nakajima varieties, including the quantum Knizhnik-Zamolodchikov equations.

# Contents

| 1 | Introduction |                                          |        |  |  |
|---|--------------|------------------------------------------|--------|--|--|
|   | 1.1          | Different levels of stable envelopes     | 2<br>2 |  |  |
|   | 1.2          | Pole subtraction and monodromy<br>       | 4      |  |  |
|   | 1.3          | Further directions                       | 8      |  |  |
|   | 1.4          | Acknowledgments                          | 9      |  |  |
| 2 |              | Equivariant elliptic cohomology<br>10    |        |  |  |
|   | 2.1          | The curve<br>E.<br><br>10                |        |  |  |
|   | 2.2          | Basics<br><br>11                         |        |  |  |
|   | 2.3          | Equivariant formality<br>12              |        |  |  |
|   | 2.4          | Tautological generation<br>13            |        |  |  |
|   | 2.5          | Characteristic classes<br><br>15         |        |  |  |
|   | 2.6          | Pushforwards<br><br>15                   |        |  |  |
|   | 2.7          | U<br>Universal line bundle<br><br>16     |        |  |  |
|   | 2.8          | Shifts of K¨ahler variables<br>18        |        |  |  |
| 3 |              | Elliptic stable envelopes<br>19          |        |  |  |
|   | 3.1          | Attracting manifolds<br><br>19           |        |  |  |
|   | 3.2          | Polarization<br><br>20                   |        |  |  |
|   | 3.3          | Definition of stable envelopes<br><br>21 |        |  |  |
|   | 3.4          | ∗P(W)<br>Example:<br>T<br><br>24         |        |  |  |

|   | 3.5 | Uniqueness<br>                            | 26 |
|---|-----|-------------------------------------------|----|
|   | 3.6 | Triangle lemma<br>                        | 28 |
|   | 3.7 | Duality                                   | 29 |
| 4 |     | Existence of stable envelopes<br>30       |    |
|   | 4.1 | Hypertoric varieties                      | 30 |
|   | 4.2 | Nakajima varieties<br>                    | 32 |
|   | 4.3 | Proof of Theorem 3                        | 32 |
|   | 4.4 | ∗Gr(k, n)<br>Example:<br>T<br>            | 36 |
|   | 4.5 | K-theory limit                            | 38 |
| 5 |     | R-matrices<br>40                          |    |
|   | 5.1 | Definition<br>                            | 40 |
|   | 5.2 | Tensor products of Nakajima varieties<br> | 41 |
| 6 |     | Difference equations<br>45                |    |
|   | 6.1 | Vertex functions                          | 45 |
|   | 6.2 | ∗P(W)<br>Example: quasimaps to<br>T       | 48 |
|   |     |                                           |    |
|   | 6.3 | Pole subtraction and monodromy<br>        | 51 |

# <span id="page-1-1"></span><span id="page-1-0"></span>1 Introduction

## 1.1 Different levels of stable envelopes

### 1.1.1

Given an action of a torus A on an algebraic variety X, one can define the attracting correspondence

<span id="page-1-2"></span>
$$Attr = \left\{ (x, y), \lim_{a \to 0} a \cdot x = y \right\} \subset X \times X^{\mathsf{A}}, \tag{1}$$

where 0 is a point at infinity of A, or more precisely a fixed point of a certain toric compactification of A. Cycles of the form [\(1\)](#page-1-2) appear often in geometry and its applications to mathematical physics. Elementary examples are Schubert cells in the Grassmannian Gr(k, n), or their conormals in X = T <sup>∗</sup>Gr(k, n).

A disadvantage of the cycles [\(1\)](#page-1-2) is that they may become unstable against small perturbation of the action: torus orbits, like gradient lines etc., can break under specialization, and the attracting set becomes smaller. One can improve the cycles [\(1\)](#page-1-2) by taking the limit of attracting cycles for a small perturbation. This will be an Aut(X) A -invariant cycle supported on the full attracting set, which is the set of pairs (x, y) that belong to a chain of closures of A-orbits.

In practice, it is much more useful to have a characterization of improved cycles in terms that refer only to the original, unperturbed action, and not to a small perturbation which may not be explicit, may break some symmetries, or may not be available altogether. The goal of stable envelopes is to provide just that.

#### 1.1.2

Stable envelopes work best when X is an equivariant symplectic resolution [44] and the action of A preserves the symplectic form. In this case, among the deformations of X one may also consider the noncommutative ones, that is, *quantizations*, for which (1) becomes the parabolic induction functor.

Nakajima varieties [53, 54] form the largest and richest family of equivariant symplectic resolutions known to date. In [49], the authors use stable envelopes to construct geometric actions of certain quantum groups, called Yangians  $Y(\mathfrak{g})$ , on the cohomology of Nakajima varieties. This extends and generalizes earlier work of Nakajima [55], Varagnolo [67], and others, in which certain smaller algebras  $Y(\mathfrak{g}_{Kac\text{-}Moody}) \subset Y(\mathfrak{g})$  were made to act by an explicit assignment on generators.

One of the main applications in [49] is a description of the quantum cohomology of all Nakajima varieties in terms of this Yangian action. This extends, in particular, earlier results of [48, 58] on quantum cohomology of the Hilbert schemes of points of ADE surfaces. This theory finds important applications in enumerative geometry of sheaves on threefolds.

#### 1.1.3

It is natural to ask whether stable envelopes may be lifted to equivariant K-theory classes on  $X \times X^{\mathsf{A}}$  enjoying similar properties. Here, one wants to work T-equivariantly, where  $\mathsf{T} \subset \mathsf{A}$  is a maximal torus in  $\mathrm{Aut}(X)^{\mathsf{A}}$ . In particular, T scales the symplectic form by a nontrivial character which we denote  $\hbar$ . Note that a limit argument does *not* produce a well-defined T-equivariant K-class, because there is no T-equivariant deformation of the action.

Reflecting this, in K-theory stable envelopes acquire an additional parameter — a fractional line bundle  $\mathscr{L} \in \operatorname{Pic}(X) \otimes_{\mathbb{Z}} \mathbb{R}$ , called the *slope*, see [57]. The dependence on  $\mathscr{L}$  is piecewise constant, with walls forming a certain locally finite  $\operatorname{Pic}(X)$ -periodic arrangement of rational hyperplanes in  $\operatorname{Pic}(X) \otimes_{\mathbb{Z}} \mathbb{R}$ . The intricacies of this arrangement reflect, among other things, the intricacies of quantizations of X, especially over a field of prime characteristic, as in the work of Bezrukavnikov and his collaborators, see e.g. [7–10, 43].

From the representation-theoretic viewpoint,

$$\mathfrak{h} = \operatorname{Pic}(X) \otimes_{\mathbb{Z}} \operatorname{field}$$

is the Cartan subalgebra of  $\mathfrak{g}$  and the walls correspond to roots of the loop algebra  $\widehat{\mathfrak{g}} = \mathfrak{g}[u^{\pm 1}]$ . The K-theoretic lift of the construction of the Yangian gives an action of  $\mathscr{U}_{\hbar}(\widehat{\mathfrak{g}})$ , which is a Hopf algebra deformation of the universal enveloping algebra  $\mathscr{U}(\widehat{\mathfrak{g}})$ .

In particular, quantum difference equations in the K-theory of Nakajima varieties have been determined in terms of this action, see [59]. As before, this has direct application to K-theoretic enumeration of sheaves on threefolds or, more precisely, to K-theoretic Donaldson-Thomas theory.

#### <span id="page-3-2"></span>1.1.4

One natural direction for further generalizations is to lift stable envelopes to Fourier-Mukai functor, that is, to a T-equivariant complex of coherent sheaves on  $X \times X^{\mathsf{A}}$ . This is pursued in [38] and one is hoping, in particular, to categorify the  $\mathscr{U}_{\hbar}(\widehat{\mathfrak{g}})$ -action along these lines. The dependence of stable envelopes on the slope  $\mathscr{L}$  remains the same piecewise constant dependence.

In this paper, we go in a different direction, and construct stable envelopes in equivariant elliptic cohomology over  $\mathbb{C}$ . Perhaps the most striking new feature of the theory is that the piecewise constant dependence on  $\mathscr{L}$  is replaced by a meromorphic dependence on

$$z \in \operatorname{Pic}(X) \otimes_{\mathbb{Z}} E$$

where  $E = \mathbb{C}^{\times}/q^{\mathbb{Z}}$  is the elliptic curve of the cohomology theory. The piecewise constant dependence is recovered in the limit when one of the periods  $-\ln(q)$  goes to  $+\infty$ , so that

$$-\Re \frac{\ln z}{\ln q} \to \mathscr{L}.$$

It is, of course, well known that in such limit elliptic functions have a piecewise analytic limit, as exemplified by

<span id="page-3-1"></span>
$$\lim \left( -\Re \frac{\ln z}{\ln q} \right) \in (k, k+1) \quad \Rightarrow \quad \lim \frac{\vartheta(az)}{\vartheta(z)} = a^{k+\frac{1}{2}}, \tag{2}$$

where  $\vartheta$  is the classical odd, that is, the one with  $\vartheta(x^{-1}) = -\vartheta(x)$ , theta function. It is given explicitly by (8), from which (2) is immediate. In particular, the poles of elliptic stable envelopes in z form a certain refinement of the roots of  $\widehat{\mathfrak{g}}$ .

Our main result is the construction of elliptic stable envelopes for Nakajima varieties given in Theorem 3. As a consequence, we lift the  $\mathscr{U}_{\hbar}(\widehat{\mathfrak{g}})$ -action to an elliptic quantum group.

## <span id="page-3-0"></span>1.2 Pole subtraction and monodromy

Elliptic stable envelopes solve a certain connection problem for difference equations in  $K_{\mathsf{T}}(X)$ , which we call the *pole subtraction* problem.

#### 1.2.1

Enumerative K-theory of rational curves in Nakajima varieties is a source of interesting and important linear difference equations with regular singularities for a  $K_{\mathsf{T}}(X)$ -valued function of

$$z \in \mathsf{Z} = \mathrm{Pic}(X) \otimes \mathbb{C}^{\times}$$
,

see [57]. The shifts in these difference equations are  $z \mapsto q^{\mathscr{L}}z$ , where  $\mathscr{L} \in \operatorname{Pic}(X)$ . There are commuting difference equations that shift equivariant variables by  $q^{\operatorname{cochar}\mathsf{T}}$ , among which the shifts by  $q^{\operatorname{cochar}\mathsf{A}}$  give equations with regular singularities. For brevity, we call these equations

quantum difference equations. These flat difference connections include many important difference equations of mathematical physics, including the quantum Knizhnik-Zamolodchikov equations [\[26\]](#page-65-1).

A central question about linear difference, or differential, equations is their monodromy. In particular, in the more traditional theory of quantum groups, one links the monodromy of qKZ equations associated to quantum affine Lie algebras to representations of elliptic quantum groups, see e.g. [\[20,](#page-64-2)[21,](#page-64-3)[24–](#page-65-2)[26,](#page-65-1)[46,](#page-66-10)[52,](#page-66-11)[66\]](#page-67-1). This is a difference analog of the description of the monodromy of the classical Knizhnik-Zamolodchikov equations given by Kohno and Drinfeld.

It is not too surprising that our elliptic stable envelopes enter the monodromy computations. In fact, one can identify precisely the difference equation problem that elliptic stable envelopes solve.

### <span id="page-4-0"></span>1.2.2

By a theorem of Deligne [\[18\]](#page-64-4), a flat differential connection has regular singularities if it has regular singularities along any curve intersecting the singular locus generically and transversally. In stark contrast to this, it is very easy for a difference equation to have regular singularities in each group of variables, but not jointly. Indeed, it suffices to look at the function

$$f(z, a) = \exp \frac{\ln z \ln a}{\ln q}$$

which solves

$$f(qz, a) = af(z, a), \quad f(z, qa) = zf(z, a).$$

This is regular for z → 0, a 6= 0 and also for z 6= 0, a → 0, but not regular at the point (z, a) = (0, 0).

The quantum difference equations have precisely this feature: they have regular singularities in K¨ahler variables z and equivariant variables a ∈ A, but not jointly. Rather than a bug, this will turn out to be a very important feature of the theory.

### 1.2.3

Let (z, a) = (0, 0) be an irregular point as above. More precisely, both z and a vary in certain toric varieties and a choice of a fixed point (0, 0) in the product of those varieties has the following geometric meaning.

The difference equation in z has regular singularities on a toric compactification Z ⊃ Z given by the fan of ample cones of all flops of X. So, a choice of the point z = 0 is the choice of X among all possible flops. Similarly, a choice of the point a = 0 ∈ A is a choice of attracting manifolds as in [\(1\)](#page-1-2). To this data, we associate elliptic stable envelopes and we show in Theorem [5](#page-52-0) that they can be interpreted as the following connection matrices for quantum difference equations.

In a neighborhood of the point (z, a) = (0, 0) we have two kinds of solutions to our difference equations: there are z-solutions, which are holomorphic for z 6= 0 and meromorphic in a, and there are a-solutions, for which it is the other way around. Enumerative geometry naturally provides a basis of z-solutions which we call vertex functions or vertices for short.

A basis of z-solutions can be transformed, by a certain triangular q-periodic matrix  $\mathfrak{P}$ , to a basis of a-solutions. We call this transition matrix the pole subtraction matrix because, in principle, it can be computed by quite literally subtracting poles, see Section 6.3. In Theorem 5 we show that, with suitable normalization, this pole subtraction matrix is given by the elliptic stable envelopes.

#### 1.2.4

The resulting a-solutions are uniquely determined by their appropriately interpreted initial conditions at a = 0. It is easy to identify those with the vertex functions, that is, z-solutions, for the fixed locus  $X^{A}$ , with a certain shift of Kähler variables, see Proposition 6.3. We get the following diagram of meromorphic isomorphisms

<span id="page-5-0"></span>![](_page_5_Figure_4.jpeg)

in which we defined the bottom arrow so that it commutes and the superscript in "vertices<sup> $\triangleleft$ </sup>" indicates the shift of Kähler variables. Solutions of quantum difference equations naturally define a sheaf on the product of  $\mathrm{Ell}_{\mathsf{T}}(X)$  with  $\mathrm{Pic}(X) \otimes_{\mathbb{Z}} E$ . Theorem 5 specifies the identification of the meromorphic bottom map in (3) with elliptic stable envelopes.

It follows at once that the monodromy of the difference equations in a is given by elliptic R-matrices. As to the monodromy in Kähler variables, it fits into the following commutative square

<span id="page-5-2"></span>![](_page_5_Figure_7.jpeg)

In particular, in the case when A acts on the framing spaces of Nakajima quiver varieties as in Section 5.2, this becomes an equation for the coproduct of the monodromy. Such equations play the decisive role in all known ways to compute the monodromy.

#### 1.2.5

A more categorical way to talk about the diagrams above is the following<sup>1</sup>. For a fixed quiver, let  $\mathscr{C}$  be the category of  $\mathscr{U}_{\hbar}(\widehat{\mathfrak{g}})$ -modules given by the equivariant K-theories of Naka-jima varieties X. Extending the scalars, we can make it linear over q-periodic functions of

<span id="page-5-1"></span><sup>&</sup>lt;sup>1</sup>This was taught to us by Pavel Etingof.

equivariant and Kähler variables. The vertex functions define a functor

<span id="page-6-0"></span>
$$Sol: K_{\mathsf{T}}(X) \mapsto \mathsf{V}(X) \,, \tag{5}$$

from  $\mathscr{U}_{\hbar}(\widehat{\mathfrak{g}})$ -modules to modules over q-periodic functions of a and z given by solutions of the quantum difference equations. A tensor structure on  $\mathscr{C}$  comes from K-theoretic stable envelopes for the action of the framing torus as in Section 5.2 and [49,59]. To make (5) a fiber functor, we need to give it a tensor structure, and it follows from the diagram (3) that

<span id="page-6-1"></span>
$$\mathfrak{P}^{-1} \circ \mathfrak{J} : (\operatorname{Sol}(X_1) \otimes \operatorname{Sol}(X_2))^{\triangleleft} \to \operatorname{Sol}(X_1 \otimes X_2)$$
(6)

is the required structure, where  $\mathfrak{J}$  is the inverse of the isomorphism with initial conditions at a=0 in (3). This operator is essentially the fundamental solution to quantum Knizhnik-Zamolodchikov equation and, up to normalizations, is the fusion operator discussed in [21–23, 42] and many other papers. It is given by a universal element in a completion of  $\mathscr{U}_{\hbar}(\widehat{\mathfrak{g}}) \otimes \mathscr{U}_{\hbar}(\widehat{\mathfrak{g}})$ , and so one can do the twist (6) in stages, by first twisting the category  $\mathscr{C}$  by  $\mathfrak{J}$  to another tensor category  $\mathscr{C}'$  as in [21,22,42] and leaving  $\mathfrak{P}^{-1}$  to be the tensor structure on the resulting functor

 $\operatorname{Sol}':\mathscr{C}'\to\operatorname{solutions}$  of the quantum difference equations .

By construction, the braiding in the category  $\mathscr{C}'$  is the monodromy of qKZ, which Corollary 6.2 below identifies, up to an explicit gauge transformation, with the elliptic R-matrix; see also the above cited papers for prior results in this direction. Thus  $\mathscr{C}'$  may be identified with the category of modules over the elliptic quantum group provided by elliptic cohomology of Nakajima quiver varieties.

The square (4) then means that the monodromy of the quantum difference equations gives a tensor isomorphism between the functors Sol' for X and its flop X. Since Sol' has essentially no tensor automorphisms, this is a very strong constraint on the monodromy, which will be more fully explored in a separate paper.

#### 1.2.6

In this paper, we work with q-difference equations originating in the K-theoretic counts of rational curves in a Nakajima variety X and we describe their monodromy in the language of elliptic cohomology of X, where q is the modulus of the elliptic curve  $E = \mathbb{C}^{\times}/q^{\mathbb{Z}}$ . One can specialize  $q \to 1$ , and thus connect the monodromy of the quantum differential equation for X to K-theoretic stable envelopes for X.

A detailed and powerful link between the monodromy of the quantum differential equation for a symplectic resolution X and the properties of the quantization of X in characteristic  $p \gg 0$  has been proposed by Bezrukavnikov and his collaborators.<sup>2</sup> Our results here allow to make a very substantial progress towards these conjectures. For quivers of finite type, this is directly related to a conjecture of V. Toledano-Laredo which identifies the monodromy of the trigonometric Casimir connection for a Lie algebra  $\mathfrak{g}$  with the quantum Weyl group in  $\mathcal{U}_{\hbar}(\widehat{\mathfrak{g}})$ . See [31] for recent progress towards that conjecture.

<span id="page-6-2"></span><sup>&</sup>lt;sup>2</sup>It appears, no published account of these conjectures is available at the time of writing, hopefully this will change soon [11].

## <span id="page-7-0"></span>1.3 Further directions

Other areas where we expect elliptic stable envelopes to be very useful include:

- correspondences of boundary conditions of supersymmetric gauge theories in three dimensions,
- knot theory and categorification.

We will return to these elsewhere, see e.g. [4], here we only sketch some salient aspects.

#### 1.3.1

In this paper, we work with X which is a Nakajima variety or a hypertoric variety. Then, X has a physical interpretation as a moduli space of Higgs vacua, or Higgs branch, of a supersymmetric gauge theory in a certain class. The relevant class of theories are 3d gauge theories with  $\mathcal{N}=4$  supersymmetry, studied for example in [15,27,39,41]. In this context, vertex functions of X have a physical interpretation as well: they are the supersymmetric partition functions of the gauge theory on  $\mathbb{C} \times S^1$ , with a choice of a vacuum state at infinity. The supersymmetric partition function is an appropriate supertrace in the Hilbert space of the theory on  $\mathbb{C}$ . (The manifold is a twisted product, where in going around the  $S^1$  one twists  $\mathbb{C}$  by q.)

Gauge theories in this class have an important duality called 3d mirror symmetry, which is closely related to the symplectic duality (see [56] for review). The duality relates pairs of 3d theories, exchanging their equivariant and Kähler parameters, and Higgs and Coulomb branches. The Higgs branch of the mirror theory, which we will denote by  $X^{\vee}$ , is expected to coincide with the Coulomb branch of the original theory, and vice versa. See [14, 27, 56] for recent progress.

Exchanging the roles of Kähler and equivariant parameters in Theorem 4, we get a set of difference equations satisfied by vertex functions of  $X^{\vee}$ . Recall that, by construction, vertices are holomorphic in Kähler parameters. The physical content of Theorem 5 is the correspondence

$$\underbrace{\text{vertices for } X} \xrightarrow{\text{Stab}} \underbrace{\text{vertices for } X^{\vee}}, \tag{7}$$

between vertex functions of a pair of dual theories. This diagram highlights how stable envelopes for X and  $X^{\vee}$  are fundamentally the same objects. In fact, there exists [3] an elliptic class on the product of X and  $X^{\vee}$  that specializes to elliptic stable envelopes for both X and  $X^{\vee}$ . Note it is essential for this to treat Kähler variable on the same footing as the equivariant variables in the definition of elliptic stable envelopes.

#### 1.3.2

Instead of working with gauge theories on  $\mathbb{C} \times S^1$ , one can replace  $\mathbb{C}$  with a disk D with suitable conditions imposed on the  $T^2$  boundary. From this perspective, the elliptic stable envelope may be interpreted as a certain operator defined in terms of the gauge theory on  $L \times T^2$ , where L is an interval, with boundary conditions imposed on each end. Nothing

depends on the size of the interval L, and taking it to be zero, we get in effect a 2d theory on  $T^2$ . The graded index of the Hilbert space of the 2d theory, or more precisely, its elliptic genus, computes the matrix elements of stable envelopes.

This suggests one should be able to promote the elliptic stable envelopes to a functor between categories of boundary conditions for  $X^{\mathsf{A}}$  and X. For 3-dimensional gauge theories, one is interested in the category (in fact, 2-category) of boundary conditions. Objects of this category, i.e. different boundary conditions, can be obtained by coupling the bulk 3d gauge theory to a  $\mathcal{N}=(2,2)$ -supersymmetric theory on the 2-dimensional boundary, see e.g. [45] for a general discussion of such categories.

This will be further explored in a companion paper, which will also discuss a common generalization of the elliptic stable envelopes and categorification of the K-theoretic stable envelopes mentioned above in Section 1.1.4.

#### 1.3.3

Applications to knot theory arise in the special case of Nakajima quivers based on ADE-type Dynkin diagrams. In this case, the difference equations of Theorem 4 include the quantum Kniznik-Zamolodchikov equations of [26].

The vertex functions in this context can be related to supersymmetric partition functions of a variant of a certain 6d "little string theory" of ADE-type, together with codimension 4 defects, see [2] for a review. The 6d theory string reduces to 6d  $\mathcal{N}=(0,2)$  conformal field theory in the point particle limit. The gauge theory of the previous subsection is the theory on defects of the 6d theory. The Kähler parameters of the quiver are moduli of the 6d theory; the equivariant parameters describe positions of defects on a Riemann surface  $\mathcal{C}=\mathbb{C}^*$  on which 6d theory is supported<sup>3</sup>. The elliptic R matrices of section 5 describe braiding of defects on  $\mathcal{C}$ .

In the limit in which the qKZ equation reduces to the KZ equation, the little string theory reduces to the more familiar 6d CFT. The relation of this theory to knot theory and invariants of quantum groups has long been predicted by physicists [28, 60, 68]. In a sense, this paper provides a significant step forward in realizing the physics prediction by providing a derivation of *R*-matrices from quantum field theory and string theory. It should be noted that to establish this result, one has to work with quantum K-theory, quantum affine algebras and the little string theory.

## <span id="page-8-0"></span>1.4 Acknowledgments

Our work on this paper was greatly facilitated by discussions with Andrey Smirnov, Tudor Dimofte, Davide Gaiotto, Nikita Nekrasov, and Davesh Maulik. We are especially grateful to Nora Ganter for giving us the courage to work in equivariant elliptic cohomology and to Pavel Etingof for his involvement and guidance on many occasions.

AO thanks the Simons foundation for being financially supported as a Simons investigator and NSF for supporting enumerative geometry at Columbia as a part of FRG 1159416. MA

<span id="page-8-1"></span><sup>&</sup>lt;sup>3</sup> The full 6d geometry setting is very similar to that in [2].

is supported, in part, by the NSF grant #1521446.

As if by magic, many threads of our narrative, including elliptic cohomology, integrable systems, and difference equations, all converge in one person: Igor Krichever. Of course, the scientific explanation for this apparent magic is Igor's ability to see what is really deep and important long before others catch up. The writing and the publication of this paper has been a long process indeed, perhaps the fate had in mind that the paper should appear in time for Igor's 70th birthday. We are very happy to use this chance to dedicate the paper to Igor as a birthday present and thank him for the influence he had on this paper, on us, and on the mathematical physics as a whole.

# <span id="page-9-1"></span><span id="page-9-0"></span>2 Equivariant elliptic cohomology

### 2.1 The curve E.

#### 2.1.1

We set  $E = \mathbb{C}^{\times}/q^{\mathbb{Z}}$ . This is a family of complex elliptic curves over the punctured disc 0 < |q| < 1. While in the general development of elliptic cohomology it is very important to work with more general families of elliptic curves, the above choice suffices for our purposes. Note, in particular, that E has no nontrivial endomorphisms and, more generally,

$$\operatorname{Hom}(E^n, E^m) \cong \operatorname{Hom}(\mathbb{Z}^n, \mathbb{Z}^m)$$
.

#### 2.1.2

The theta function

<span id="page-9-2"></span>
$$\vartheta(x) = (x^{1/2} - x^{-1/2}) \prod_{n>0} (1 - q^n x)(1 - q^n / x)$$
(8)

satisfies

<span id="page-9-3"></span>
$$\vartheta(q^k x) = (-1)^k q^{-k^2/2} x^{-k} \vartheta(x) , \quad k \in \mathbb{Z} ,$$
(9)

and thus defines a section of a degree 1 line bundle on E with the unique zero at x = 1. Translates of this line bundle form  $\operatorname{Pic}_1(E) \cong E$ , where  $\operatorname{Pic}_1(E)$  denotes line bundles of degree 1. Similarly, meromorphic sections s(x) of line bundles of degree d on E satisfy

$$s(qx) = cx^{-d}s(x), \quad c \in \mathbb{C}^{\times},$$

see e.g. [13] for a systematic discusion of how line bundles on abelian varieties are described by their factors of automorphy.

#### 2.1.3

A long-standing tradition in the theory of elliptic functions is to use additive notation in abstract formulas involving the group operation on abelian varieties. At the same time, one

uses E = C <sup>×</sup>/q<sup>Z</sup> with its multiplicative group law in concrete computations. We follow this tradition, which is particularly convenient in the geometric context.

Indeed, in the world of complex-oriented cohomology theories, the group law on E comes from the tensor product on line bundles, and so from the group operation in GL(1). We believe the reader will appreciate the convenience of translating vector bundles into elliptic functions with this choice of notation.

## <span id="page-10-0"></span>2.2 Basics

### 2.2.1

In this paper, we work with torus-equivariant elliptic cohomology over C; this is sufficiently general to cover all applications that we have in mind.

With one important exception in Section [4.3.2,](#page-32-0) our setting will be algebraic, that is, we will consider an algebraic torus T ∼= (C ×) <sup>n</sup> and regular equivariant maps f : X → Y between complex quasiprojective T-varieties.

We also assume the T-action on X is linearized which, by definition, means that the quasi-projective embedding of X may be taken of the form

<span id="page-10-1"></span>
$$X \hookrightarrow \mathbb{P}(\mathsf{T}\text{-module})$$
. (10)

### 2.2.2

Equivariant elliptic cohomology, developed in [\[30,](#page-65-8) [32,](#page-65-9) [33,](#page-65-10) [37,](#page-65-11) [47,](#page-66-17) [62\]](#page-67-3) and other papers, defines a functor

$$\operatorname{Ell}_{\mathsf{T}}(X): \big\{\mathsf{T}\text{-spaces } \mathsf{X}\big\} \to \{\mathsf{schemes}\}$$

covariant in both T and X, such that

$$\mathrm{Ell}_{(\mathbb{C}^{\times})^n}(\mathrm{pt}) \cong E^n$$

for an elliptic curve E. Strictly speaking, one should consider supercommutative schemes for varieties with odd cohomology, but Nakajima varieties and symplectic resolutions in general have only even cohomology [\[44\]](#page-66-1).

For a torus T, its characters and cocharacters are dual lattices defined by

$$\operatorname{char}(\mathsf{T}) = \operatorname{Hom}(\mathsf{T}, \mathbb{C}^{\times}), \quad \operatorname{cochar}(\mathsf{T}) = \operatorname{Hom}(\mathbb{C}^{\times}, \mathsf{T}).$$

For the dual torus T ∨ , these are exchanged. Covariance in T implies

$$\mathrm{Ell}_{\mathsf{T}}(\mathrm{pt}) = \mathsf{T}/q^{\mathrm{cochar}(\mathsf{T})} =: \mathscr{E}_{\mathsf{T}} ,$$

canonically.

#### 2.2.3

To the projection  $X \to \text{pt}$  the functor  $\text{Ell}_T$  associates the map

$$\pi: \mathrm{Ell}_{\mathsf{T}}(X) \to \mathscr{E}_{\mathsf{T}}$$

that looks as follows in a small analytic neighborhood U of a point  $t \in T$ :

<span id="page-11-2"></span>
$$\operatorname{Spec} H_{\mathsf{T}}^{*}(X^{\mathsf{T}_{t}}, \mathbb{C}) \longleftrightarrow \pi^{-1}(U) \longrightarrow \operatorname{Ell}_{\mathsf{T}}(X)$$

$$\downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow$$

$$\operatorname{Lie} \mathsf{T} \overset{\ln(\cdot) - \ln(t)}{\longleftrightarrow} U \longrightarrow \mathscr{E}_{\mathsf{T}}.$$

$$(11)$$

Here both squares are pullbacks and the subgroup

$$\mathsf{T}_t = \bigcap_{\chi(t) \in q^{\mathbb{Z}}} \operatorname{Ker} \chi \subset \mathsf{T} \,,$$

is the intersection of kernels of all characters

$$\chi \in \operatorname{char}(\mathsf{T}) \cong \operatorname{Hom}(\mathscr{E}_{\mathsf{T}}, E)$$

<span id="page-11-0"></span>that are trivial on the image of t in  $\mathcal{E}_{\mathsf{T}}$ .

## 2.3 Equivariant formality

#### 2.3.1

Let a torus T act on a Nakajima variety X so that is scales its canonical symplectic form nontrivially. The fixed locus  $X^{\mathsf{T}}$  is then a smooth projective variety, which is a union of finitely many components  $\{F_i\}$ . A generic one-parameter subgroup

$$\mathbb{C}^{\times} \ni s \mapsto \mathsf{T}$$

may be chosen so that the limit  $\lim_{s\to 0} s \cdot x \in X^{\mathsf{T}}$  exists for all  $x \in X$ . For any subgroup  $\mathsf{T}' \subset \mathsf{T}$ , the terms in the corresponding Białynicki-Birula decomposition

<span id="page-11-1"></span>
$$X^{\mathsf{T}'} = \bigcup_{F_i} \left\{ x \in X^{\mathsf{T}'} \mid \lim_{s \to 0} s \cdot x \in F_i \right\}$$
 (12)

are bundles of affine spaces over  $F_i$  by (10) and the classical result of [12]. The terms in the decomposition (12) are naturally partially ordered by containment in the closure.

<span id="page-12-3"></span>The flatness of the left vertical arrow in (11), equivalently, the freenees of  $H_{\mathsf{T}}^*(X^{\mathsf{T}_t})$  over  $H_{\mathsf{T}}^*(\mathrm{pt})$  is a property known as equivariant formality, see [36] for a comprehensive discussion. Formality implies that

$$H_{\mathsf{T}}^*(X^{\mathsf{T}_t}) \cong H^*(X^{\mathsf{T}_t}) \otimes H_{\mathsf{T}}^*(\mathrm{pt})$$

and therefore

$$\pi^{-1}(t) \cong \operatorname{Spec} H^*(X^{\mathsf{T}_t}).$$

**Lemma 2.1.** For any Nakajima variety X and any subgroup  $\mathsf{T}' \subset \mathsf{T}$ , the fixed locus  $X^{\mathsf{T}'}$  is equivariantly formal.

*Proof.* By Corollary 1.3.2 By part (8) of Theorem 14.1 in [36], it suffices to see that the homology  $H_*(X^{\mathsf{T}'})$  is generated by T-invariant cycles. This follows from the Białynicki-Birula decomposition (12) by induction on the partial order and the long exact sequence of a pair.

<span id="page-12-1"></span>**Corollary 2.2.** For any subgroup  $\mathsf{T}' \subset \mathsf{T}$ , the cohomology  $H^*(X^{\mathsf{T}'})$  is even and  $H^*(X^{\mathsf{T}'}, \mathbb{Q}) \cong K^{\mathrm{top}}(X^{\mathsf{T}'}) \otimes \mathbb{Q}$ .

*Proof.* By equivariant localization and formality,  $H^*(X^{\mathsf{T}})$  is a localization of  $H^*_{\mathsf{T}}(X) \cong H^*(X) \otimes H^*_{\mathsf{T}}(\mathrm{pt})$ , which is even. The Białynicki-Birula decomposition then implies  $H^*(X^{\mathsf{T}})$  is even for any subgroup  $\mathsf{T}'$ . The comparison with the topological K-theory  $K^{\mathrm{top}}(X^{\mathsf{T}'})$  follows from the corresponding degeneration of the Atiyah-Hirzebruch spectral sequence.

## <span id="page-12-0"></span>2.4 Tautological generation

#### 2.4.1

In this revised version of the paper, we can take advantage of the following powerful result of K. McGerty and T. Nevins which was not yet available at the time of the writing.

<span id="page-12-2"></span>**Theorem 1** ([50]). If X is a Nakajima variety then  $K_{\mathsf{T}}^{\mathrm{alg}}(X) = K_{\mathsf{T}}^{\mathrm{top}}(X)$  is generated by tautological bundles and  $H_{\mathsf{T}}^*(X,\mathbb{Z})$  is generated by the Chern classes of the tautological bundles.

As a corollary, Pic(X) and  $Pic_T(X)$  are lattices generated by tautological line bundles. They fit into an exact sequence

$$0 \to \operatorname{char}(\mathsf{T}) \to \operatorname{Pic}_{\mathsf{T}}(X) \to \operatorname{Pic}(X) \to 0 \tag{13}$$

of free abelian groups.

For completeness, we recall the proof of the following well-known fact, see e.g. [16,51].

<span id="page-13-3"></span>**Lemma 2.3.** In both algebraic and topological equivariant K-theory, we have the following pullback diagram

<span id="page-13-2"></span>
$$\operatorname{Spec} K(X^{t}) \longrightarrow \operatorname{Spec} K_{\mathsf{T}}(X)$$

$$\downarrow \qquad \qquad \downarrow$$

$$\{t\} \longrightarrow \mathsf{T}.$$

$$(14)$$

*Proof.* Let  $\chi$  be a character of T. Let  $\mathbb{C}_{\chi}$  be 1-dimensional T-module with character  $\chi$  and

$$\mathbb{C}_{\chi}^{\times} = \mathbb{C}_{\chi} \setminus \{0\} = \operatorname{Im} \chi \cong \mathsf{T} / \operatorname{Ker} \chi.$$

We conclude

$$K_{\operatorname{Ker}\chi}(X) = K_{\mathsf{T}}(X \times \mathbb{C}_{\chi}^{\times})$$

$$= \operatorname{Coker}\left(K_{\mathsf{T}}(X) \xrightarrow{1-\chi} K_{\mathsf{T}}(X)\right), \qquad (15)$$

where the first line is Corollary 5 in [51], and the second line follows from the localization long exact sequence applied to the inclusion

$$X \to X \times \mathbb{C}_{\chi}$$
,

compare with Corollary 27 in [51].

Since every subgroup  $\mathsf{T}'\subset\mathsf{T}$  is a complete intersection kernels of characters, we have the following pullback diagram

<span id="page-13-0"></span>
$$\operatorname{Spec} K_{\mathsf{T}'}(X) \longrightarrow \operatorname{Spec} K_{\mathsf{T}}(X) \tag{16}$$

$$\downarrow \qquad \qquad \downarrow$$

$$\uparrow \qquad \qquad \downarrow \qquad \qquad \downarrow$$

On the other hand, by equivariant localization

<span id="page-13-1"></span>
$$U \times \operatorname{Spec} K(X^{\mathsf{T}'}) \longrightarrow \operatorname{Spec} K_{\mathsf{T}'}(X)$$

$$\downarrow \qquad \qquad \downarrow$$

$$U \longrightarrow \mathsf{T}'$$

$$(17)$$

where  $U = \mathsf{T}' \setminus \bigcup_{\mathsf{T}'' \subseteq \mathsf{T}'} \mathsf{T}''$  is the open set of elements that generate a Zariski dense subgroup of  $\mathsf{T}'$ . Applying (16) and (17) to the Zariski closed subgroup  $\mathsf{T}'$  generated by t, we obtain (14).

As a corollary,  $K_{\mathsf{T}}^{\mathrm{alg}}(X^t) = K_{\mathsf{T}}^{\mathrm{top}}(X^t)$  for all  $t \in \mathsf{T}$ , and we do not distinguish between these groups in what follows.

## <span id="page-14-0"></span>2.5 Characteristic classes

### 2.5.1

An equivariant rank r complex vector bundle V over X defines a map

<span id="page-14-2"></span>
$$c: \operatorname{Ell}_{\mathsf{T}}(X) \to \operatorname{Ell}_{GL(r)}(\operatorname{pt}) = S^r E,$$
 (18)

see Section (1.8) in [\[33\]](#page-65-10) and Section 5 in [\[30\]](#page-65-8). The coordinates in the target of [\(18\)](#page-14-2) are symmetric functions on E<sup>r</sup> — symmetric functions in elliptic Chern roots.

## 2.5.2

Let X be a Nakajima quiver variety, which is the case of main interest for us in this paper. By construction, X is a quotient by G = Q GL(vi). This gives a collection of tautological vector bundles {Vi} of rank rk V<sup>i</sup> = v<sup>i</sup> and the map

<span id="page-14-4"></span>
$$\operatorname{Ell}_{\mathsf{T}}(X) \to \mathscr{E}_{\mathsf{T}} \times \prod S^{\mathbf{v}_i} E$$
 (19)

By Corollary [2.2](#page-12-1) and Lemma [2.3,](#page-13-3) locally on ET, this map may be modeled by the map

<span id="page-14-3"></span>
$$K_{\mathsf{T}}(X) \to \mathsf{T} \times \prod S^{\mathbf{v}_i} \mathbb{C}^{\times}$$
 (20)

given by the K-theoretic Chern roots.

Theorem [1](#page-12-2) implies [\(20\)](#page-14-3) is an embedding, therefore [\(19\)](#page-14-4) is also an embedding.

## <span id="page-14-1"></span>2.6 Pushforwards

### 2.6.1

Pullback in elliptic cohomology are the functorial maps

$$\mathrm{Ell}(f):\mathrm{Ell}_{\mathsf{T}}(X)\to\mathrm{Ell}_{\mathsf{T}}(Y)$$

associated to a map f : X → Y of T-spaces. Pushforwards are defined for complex oriented maps and are sheaf homomorphisms

$$f_*: \operatorname{Ell}(f)_* \Theta(-N_f) \to \mathscr{O}_{\operatorname{Ell}_{\mathsf{T}}(Y)}$$
 (21)

where N<sup>f</sup> ∈ KT(X) is the normal bundle to f and

<span id="page-14-5"></span>
$$\Theta: K_{\mathsf{T}}(X) \to \operatorname{Pic}\left(\operatorname{Ell}_{\mathsf{T}}(X)\right)$$
 (22)

is the Thom class map defined as follows.

#### 2.6.2

Let V be a complex vector bundle over X. Its Thom class is, by definition

$$\Theta(V) = c^* \mathscr{O}(D)$$

where c is the map (18) and the divisor

$$D = \{0\} + S^{r-1}E \subset S^rE$$

is formed by those r-tuples that contain 0. Since clearly

$$\Theta_{V_1 \oplus V_2} = \Theta_{V_1} \otimes \Theta_{V_2}$$

this extends to a group homomorphism (22).

#### 2.6.3

In English, the need to introduce the twist by the Thom class may be explained as follows. As we progress from equivariant cohomology to equivariant elliptic cohomology, the Euler class of the normal bundle becomes replaced by  $\prod \vartheta(x_i)$ , where  $(x_1, \ldots, x_r) \in S^r E$  are the Chern roots of the normal bundle. This product of  $\vartheta$ -functions is a section of a nontrivial line bundle over  $S^r E$ , which this very section identifies with  $\mathscr{O}(D)$ .

Also note that by construction of Chern classes, any bundle V of rank r, whether it splits into line bundles or not, defines a map from  $\mathrm{Ell}_{\mathsf{T}}(X)$  to  $S^rE$ . The Thom class  $\Theta(V)$  of V is the pull-back of  $\prod \vartheta(x_i)$  under this map. In general, computations with Chern roots of a vector bundle are computations with the coordinates  $x_i$  on  $S^rE$ , which may be pulled back to  $\mathrm{Ell}_{\mathsf{T}}(X)$  via the Chern class map.

## <span id="page-15-1"></span><span id="page-15-0"></span>2.7 Universal line bundle $\mathcal{U}$

### 2.7.1

For line bundles, the Chern class (18) gives a group homomorphism

$$\operatorname{Pic}_{\mathsf{T}}(X) \xrightarrow{c} \operatorname{Maps}(\operatorname{Ell}_{\mathsf{T}}(X) \to E)$$

where the group operation in the target is the pointwise addition in E. This can be viewed as a map

$$\tilde{c}: \mathrm{Ell}_{\mathsf{T}}(X) \to \mathscr{E}^{\vee}_{\mathrm{Pic}_{\mathsf{T}}(X)}$$

where

$$\mathcal{E}_{\mathrm{Pic}_{\mathsf{T}}(X)} = \mathrm{Pic}_{\mathsf{T}}(X) \otimes_{\mathbb{Z}} E,$$

$$\mathcal{E}_{\mathrm{Pic}_{\mathsf{T}}(X)}^{\vee} = \mathrm{Hom}(\mathrm{Pic}_{\mathsf{T}}(X), E)$$
(23)

is a pair of dual abelian varieties. The universal line bundle is a family of line bundles on  $\mathrm{Ell}_{\mathsf{T}}(X)$  pulled back via this map.

#### 2.7.2

On the product of two dual abelian varieties there is a universal line bundle  $\mathscr{U}_{Poincar\acute{e}}$ . In complex analytic terms, the sections of  $\mathscr{U}_{Poincar\acute{e}}$  on  $E^{\vee} \times E$  are analytic functions on the universal cover with the same factors of automorphy as

<span id="page-16-0"></span>
$$\frac{\vartheta(sz)}{\vartheta(s)\,\vartheta(z)}\,,\tag{24}$$

where we use the isomorphism  $E^{\vee} \cong E$  given by the divisor  $\{1\} = (\vartheta) \subset E$ . Note from (9) that the function  $\psi(z,s)$  as in (24) satisfies

$$\psi(qs, z) = z^{-1}\psi(s, z), \quad \psi(s, qz) = s^{-1}\psi(s, z).$$

Below, it will be convenient to consider pullbacks of  $\mathscr{U}_{Poincar\acute{e}}$  by the automorphism of the base. For example

<span id="page-16-4"></span>
$$(z \mapsto z^{-1})^* \mathscr{U}_{\text{Poincar\'e}} \cong \mathscr{U}_{\text{Poincar\'e}}^{\vee}.$$
 (25)

#### 2.7.3

We define

$$\mathscr{U} = (\tilde{c} \times 1)^* \, \mathscr{U}_{\text{Poincar\'e}} \,.$$

This is a line bundle on

<span id="page-16-2"></span>
$$\mathsf{E}_{\mathsf{T}}(X) = \mathrm{Ell}_{\mathsf{T}}(X) \times \mathscr{E}_{\mathrm{Pic}_{\mathsf{T}}(X)} \tag{26}$$

which is a scheme over

<span id="page-16-3"></span>
$$\mathscr{B}_{\mathsf{T},X} = \mathscr{E}_{\mathsf{T}} \times \mathscr{E}_{\mathsf{Pic}_{\mathsf{T}}(X)} \,. \tag{27}$$

We call the variables in the two factors of  $\mathcal{B}_{\mathsf{T},X}$  the equivariant and the Kähler parameters, respectively.

#### 2.7.4

The universal line bundle may be described very concretely using the map (19). The pullback under the addition map  $S^kE \to E$  induces the isomorphisms

<span id="page-16-1"></span>
$$\operatorname{Pic}_0(S^k E) \cong \operatorname{Pic}_0(E) \cong E$$
. (28)

Meromorphic sections of a line bundle corresponding to  $z \in E$  are symmetric meromorphic functions  $\psi(s_1, \ldots, s_k)$ ,  $s_i \in \mathbb{C}^{\times}$ , such that

$$\psi(qs_1, s_2, \dots, s_k) = z^{-1}\psi(s).$$

We get a factor of (28) for each factor in the right-hand side of (19), including rk T many factors in  $\mathcal{E}_{\mathsf{T}}$ . This gives a map

$$\mathscr{E}_{\operatorname{Pic}_{\mathsf{T}}(X)} \to \operatorname{Pic}_0(\mathscr{E}_{\mathsf{T}} \times \prod S^{\mathbf{v}_i} E),$$

and the bundle  $\mathscr{U}$  is pulled back from the corresponding bundle on the ambient space  $\mathscr{E}_{\mathrm{Pic}_{\mathsf{T}}(X)} \times \mathscr{E}_{\mathsf{T}} \times \prod S^{\mathbf{v}_i} E$ .

#### 2.7.5

Even more concretely, a Nakajima quiver variety is constructed as a GIT quotient a by

$$G_{\text{gauge}} = \prod GL(\mathbf{v}_i)$$
,

which is the complexified gauge group in the physical context. We have

$$\mathscr{E}_{\mathsf{T}} \times \prod S^{\mathbf{v}_i} E = \mathscr{E}_{\mathsf{T} \times \mathsf{T}_{\mathsf{gauge}}} / W_{\mathsf{gauge}} ,$$
 (29)

$$\mathscr{E}_{\operatorname{Pic}_{\mathsf{T}}(X)} = \left(\mathscr{E}_{\mathsf{T}\times\mathsf{T}_{\operatorname{gauge}}}^{\vee}\right)^{W_{\operatorname{gauge}}},\tag{30}$$

where

$$\mathsf{T}_{\mathrm{gauge}}, W_{\mathrm{gauge}} \subset G_{\mathrm{gauge}}$$

are the maximal torus and the Weyl group, respectively. Setting

$$\widetilde{T} = T \times T_{\text{gauge}}$$
,

we have the natural map

<span id="page-17-1"></span>
$$\left(\widetilde{\mathsf{T}}^{\vee}\right)^{W_{\mathrm{gauge}}} \times \left(\widetilde{\mathsf{T}}/W_{\mathrm{gauge}}\right) \to \mathscr{E}_{\mathrm{Pic}_{\mathsf{T}}(X)} \times \mathscr{E}_{\mathsf{T}} \times \prod S^{\mathbf{v}_{i}} E.$$
 (31)

Meromorphic sections of the universal bundle pull back under (31) to meromorphic functions of  $z \in (\widetilde{\mathsf{T}}^\vee)^{W_{\text{gauge}}}$  and  $s \in \widetilde{\mathsf{T}}$  that are  $W_{\text{gauge}}$ -invariant in s and satisfy

<span id="page-17-3"></span>
$$\psi(z, q^{\sigma}s) = \sigma(z)^{-1}\psi,$$
  

$$\psi(q^{\chi}z, s) = \chi(s)^{-1}\psi,$$
(32)

for any

$$\begin{split} & \sigma \in \operatorname{cochar} \widetilde{\mathsf{T}} = \operatorname{char} \widetilde{\mathsf{T}}^\vee \,, \\ & \chi \in \operatorname{cochar} \left( \widetilde{\mathsf{T}}^\vee \right)^{W_{\mathrm{gauge}}} = \operatorname{char} \left( \widetilde{\mathsf{T}} \right)^{W_{\mathrm{gauge}}} \,. \end{split}$$

## <span id="page-17-0"></span>2.8 Shifts of Kähler variables

#### 2.8.1

Observe that translations along the  $\mathscr{E}_{\operatorname{Pic}_{\mathsf{T}}(X)}$  factor in (26) preserve everything except the universal bundle  $\mathscr{U}$ . Note that we may translate by an amount that depends on where we are in  $\operatorname{Ell}_{\mathsf{T}}(X)$ . An example of such transformation is

<span id="page-17-2"></span>
$$z \xrightarrow{\tau(\lambda\mu)} z + \lambda(\mu(t)),$$
 (33)

which may be defined for every pair

$$\begin{split} \mu &\in \mathrm{char}(\mathsf{T}) = \mathrm{Hom}(\mathscr{E}_\mathsf{T}, E)\,, \\ \lambda &\in \mathrm{Pic}_\mathsf{T}(X) = \mathrm{Hom}(E, \mathscr{E}_{\mathrm{Pic}_\mathsf{T}(X)})\,. \end{split}$$

In (33), t is a coordinate on  $\mathscr{E}_{\mathsf{T}}$  and all coordinates in  $\mathrm{Ell}_{\mathsf{T}}(X)$  are unaffected by the transformation (33).

### 2.8.2

Let ψ be a function on Te<sup>∨</sup> × Te as in [\(32\)](#page-17-3) and consider

$$\psi'(z,s) = \frac{\psi(\lambda(\mu(s))z,s)}{\psi(z,s)},$$

where λ, µ ∈ char Te = cochar Te<sup>∨</sup> . Evidently, ψ ′ is q-periodic in z while

<span id="page-18-2"></span>
$$\frac{\psi'(z, q^{\sigma}s)}{\psi'(z, s)} = q^{-\langle \lambda, \sigma \rangle \langle \lambda, \mu \rangle} \, \mu(s)^{-\langle \lambda, \sigma \rangle} \, \lambda(s)^{-\langle \mu, \sigma \rangle} \,. \tag{34}$$

Clearly, the line bundle τ (λµ) <sup>∗</sup><sup>U</sup> <sup>⊗</sup> <sup>U</sup> <sup>−</sup><sup>1</sup> depends linearly on λµ. This follows either directly from [\(34\)](#page-18-2) or from basic general theorem about translates of line bundles on abelian varieties.

## 2.8.3

For ease of future reference, we note an immediate consequence of the formula [\(34\)](#page-18-2).

<span id="page-18-4"></span>Lemma 2.4. For λ, µ ∈ char Te = cochar Te<sup>∨</sup> as above, the ratio

$$\frac{\vartheta(\lambda \cdot \mu)}{\vartheta(\lambda)\,\vartheta(\mu)}$$

is a meromorphic section of τ (λµ) <sup>∗</sup><sup>U</sup> <sup>⊗</sup> <sup>U</sup> <sup>−</sup><sup>1</sup> .

Here, we had to distinguish between product λ · µ of functions on Te and the composition

$$\lambda \circ \mu \in \operatorname{Hom}(\widetilde{\mathsf{T}}, \widetilde{\mathsf{T}}^{\vee}),$$

which enters the definition of τ (λµ).

We will be particularly interested in the case when µ is the weight ~ of the symplectic form. In this case, we note the following

<span id="page-18-3"></span>Lemma 2.5. The ratio

$$\prod \frac{\vartheta(\hbar w_i)}{\vartheta(w_i)\,\vartheta(\hbar)}$$

is a meromorphic section of τ (λ~) <sup>∗</sup><sup>U</sup> <sup>⊗</sup> <sup>U</sup> <sup>−</sup><sup>1</sup> for λ = Q wi .

# <span id="page-18-0"></span>3 Elliptic stable envelopes

## <span id="page-18-1"></span>3.1 Attracting manifolds

## 3.1.1

The setup is the same as e.g. Section 3.2 of [\[49\]](#page-66-0). Let A ⊂ Ker ~ ⊂ T be a subtorus. The normal weights to <sup>X</sup><sup>A</sup> partition Lie <sup>A</sup> into finitely many chambers. Let <sup>A</sup> <sup>⊃</sup> <sup>A</sup> be the toric compactification of A defined by the fan of the chambers. A choice of a chamber  $\mathfrak C$  defines a point

<span id="page-19-2"></span>
$$0 = 0_{\mathfrak{C}} \in \overline{\mathsf{A}} \tag{35}$$

at infinity of A. For every  $S \subset X^A$  we can define its attracting set

$$Attr(S) = \{(x, s), s \in S, \lim_{a \to 0} a \cdot x = s\},\,$$

and the full attracting set  $\operatorname{Attr}^f(S)$  which is the minimal closed subset of X that contains S and is closed under taking  $\operatorname{Attr}(\cdot)$ . Here and below a choice of the chamber  $\mathfrak C$  is understood.

#### <span id="page-19-3"></span>3.1.2

Let  $F_i$  be the connected components of  $X^A$ . We define an ordering on the set of connected components by

$$F_1 \ge F_2 \quad \Leftrightarrow \quad \operatorname{Attr}^f(F_1) \cap F_2 \ne \emptyset$$
.

<span id="page-19-0"></span>This is well defined because we assume the action to be linearized as in (10).

### 3.2 Polarization

#### 3.2.1

A polarization of X, denoted  $T^{1/2}X$ , is an element of  $K_{\mathsf{T}}(X)$  such that

<span id="page-19-1"></span>
$$TX = T^{1/2}X + \hbar^{-1} \otimes (T^{1/2}X)^{\vee}$$
 (36)

where  $\hbar$  is a character of T. We use the shorthand  $T^{1/2}$  when X is clear from context.

Polarization is a somewhat auxiliary but important technical concept that keeps coming up in connection with stable envelopes. For instance, in the elliptic cohomology context, it is natural for elliptic classes associated to Lagrangian submanifolds of X to be sections of line bundles closely related to  $\Theta(T^{1/2}X)$ .

Cotangent bundles  $X = T^*M$  have polarizations given by either base or the fiber direction, so that  $\hbar$  is the weight of the natural symplectic structure on  $T^*M$ . Nakajima varieties come with natural polarizations (58), which may be traced to their embedding in the cotangent bundle to a stack of quiver representations.

With every polarization  $T^{1/2}$  comes the opposite polarization  $T_{\text{opp}}^{1/2}$ , which is the other term in the right-hand side of (36).

#### 3.2.2

Suppose  $\delta T^{1/2}$  is the difference of two polarizations in  $K_{\mathsf{T}}(X)$ . Then

$$\delta T^{1/2} = \sum_{i=1}^{l} \left( w_i - \frac{1}{\hbar w_i} \right)$$

for certain Chern roots  $w_i$ , where each  $w_i$  is a monomial in equivariant variables and Chern roots of the tautological bundles. Recall that  $K_T(X)$  is a subscheme is the product of T with  $S^{\mathbf{v}_i}\mathbb{C}^{\times}$  and here we compute with coordinates  $w_i$  on this ambient space. Denote

$$\lambda = \prod w_i = \sqrt{\hbar^{-l} \det \delta T^{1/2}} \in \operatorname{Pic}_T(X)$$
.

By Lemma 2.5, we have

<span id="page-20-3"></span>
$$\Theta\left(\delta T^{1/2}\right) \cong \frac{\tau\left(-\lambda\hbar\right)^* \mathscr{U}}{\mathscr{U}} \otimes \Theta(\hbar)^{-l}. \tag{37}$$

#### 3.2.3

The restriction of the polarization to  $X^{A}$  can be decomposed

$$T^{1/2}|_{X^{\mathsf{A}}} = T^{1/2}|_{X^{\mathsf{A}},>0} \oplus T^{1/2}|_{X^{\mathsf{A},\text{fixed}}} \oplus T^{1/2}|_{X^{\mathsf{A}},<0}$$
 (38)

into attracting, fixed, and repelling directions for the action of A.

The fixed part defines a polarization of  $X^{A}$  which we denote by  $T^{1/2}X^{A}$ . We denote by

<span id="page-20-2"></span>
$$\text{ind} = T^{1/2} \big|_{X^{\mathsf{A}} > 0} \in K_{\mathsf{T}}(X^{\mathsf{A}})$$
 (39)

the attracting part of polarization. This is an analog of the index of a fixed component. It is exactly the index if X is a cotangent bundle to some other manifold, the tangent bundle of which is given by  $T^{1/2}$ .

## <span id="page-20-0"></span>3.3 Definition of stable envelopes

#### 3.3.1

A T-equivariant map  $f: Y \to X$  induces a diagram

<span id="page-20-1"></span>
$$\mathsf{E}_{\mathsf{T}}(Y) \xleftarrow{1 \times f^{*}} \mathrm{Ell}_{\mathsf{T}}(Y) \times \mathscr{E}_{\mathrm{Pic}_{\mathsf{T}}(X)} \xrightarrow{\mathrm{Ell}(f) \times 1} \mathsf{E}_{\mathsf{T}}(X) \qquad (40)$$

$$\downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow$$

$$\mathscr{B}_{\mathsf{T},Y} \xleftarrow{1 \times f^{*}} \mathscr{B}_{\mathsf{T},X} \xrightarrow{1} \mathscr{B}_{\mathsf{T},X},$$

where  $f^*$  is the pull-back of line bundles from X to Y.

#### <span id="page-20-4"></span>3.3.2

Stable envelopes is a way to map, with some shifts and twists, the universal bundles in (40), as sheaves on the base, for the inclusion of the fixed locus

$$\iota: X^{\mathsf{A}} \to X \,, \quad \mathsf{A} \subset \mathsf{T} \,.$$

We have

$$\det \operatorname{ind} \in \operatorname{Pic}_{\mathsf{T}}(X^{\mathsf{A}})$$

and this defines a translation

$$\tau(-\hbar \det \mathrm{ind}) : \mathscr{B}_{\mathsf{T},X^\mathsf{A}} \to \mathscr{B}_{\mathsf{T},X^\mathsf{A}}$$
.

We denote

<span id="page-21-1"></span>
$$\mathscr{U}' = (1 \times \iota *)^* \tau(-\hbar \det \operatorname{ind})^* \mathscr{U}_{\mathsf{E}_T(X^\mathsf{A})}. \tag{41}$$

This is a line bundle on the top left space in the following diagram

$$\operatorname{Ell}_{\mathsf{T}}(X^{\mathsf{A}}) \times \mathscr{E}_{\operatorname{Pic}_{\mathsf{T}}(X)} \xrightarrow{\operatorname{Ell}(\iota) \times 1} \mathsf{E}_{\mathsf{T}}(X) \qquad (42)$$

$$\mathscr{B}_{\mathsf{T},X} \xrightarrow{1} \mathscr{B}_{\mathsf{T},X}.$$

Elliptic stable envelope is a map of  $\mathscr{O}_{\mathscr{B}_{\mathsf{T},X}}$ -modules

<span id="page-21-0"></span>
$$\Theta\left(T^{1/2}X^{\mathsf{A}}\right) \otimes \mathscr{U}' \xrightarrow{\operatorname{Stab}_{\mathfrak{C}}} \Theta\left(T^{1/2}X\right) \otimes \mathscr{U} \otimes \dots, \tag{43}$$

where dots stand for meromorphic sections of a certain line bundle pulled back from

$$\mathscr{B}' = \mathscr{B}_{\mathsf{T},X}/\mathscr{E}_{\mathsf{A}}$$
.

Equation (43) specifies the factors of automorphy in the variables  $a \in A$ . The variables in  $\mathscr{B}'$ , that is, the rest of the equivariant and all Kähler variables, enter as parameters into this specification. The dependence on those variables is uniquely determined by a certain triangularity and normalization of stable envelopes, see Proposition (3.1) below.

In the general spirit of stable envelopes, we constrain the A-dependence explicitly, and the rest is fixed by a certain uniqueness. In our personal experience, this is the productive way to think about stable envelopes and we ask those readers who feel uncomfortable about the ellipsis in (43) to read on until (46).

#### 3.3.3

Definition of stable envelopes involves supports, which means the following. Let s be a section of a coherent sheaf on  $\mathrm{Ell}_{\mathsf{T}}(X)$  over an open set in the base  $\mathscr{B}_{\mathsf{T},X}$  and let

$$f: Y \to X$$

be an inclusion of a T-invariant set. We say

$$\mathrm{supp}(s) \subset Y \quad \Leftrightarrow \quad f^*_{\mathrm{complement}}(s) = 0$$

where

$$f_{\text{complement}} : \text{Ell}_{\mathsf{T}}(X \setminus Y) \to \text{Ell}_{\mathsf{T}}(X)$$

is the functorial map.

<span id="page-22-2"></span>In X, we have a decreasing sequence of closed sets

<span id="page-22-3"></span>
$$Y_i = \bigcup_{F_j \le F_i} \text{Attr}(F_j), \quad Y_\infty = \emptyset,$$
 (44)

and a typical strategy of proving that s = 0 will be to show inductively that  $\operatorname{supp}(s) \subset Y_i$  for all i.

### <span id="page-22-0"></span>3.3.5

By definition, Stabe satisfies the following two conditions:

- (\*) The support of  $\operatorname{Stab}_{\mathfrak{C}}$  is triangular with respect to  $\mathfrak{C}$ , that is, if locally over  $\mathscr{B}_{\mathsf{T},X}$  an elliptic cohomology class s is supported on a component  $F_i$  of a fixed locus then  $\operatorname{Stab}_{\mathfrak{C}}(s)$  is supported on  $\operatorname{Attr}^f(F_i)$ .
- $(\star\star)$  Near the diagonal, we have

<span id="page-22-1"></span>
$$\operatorname{Stab}_{\mathfrak{C}} = (-1)^{\operatorname{rk}\operatorname{ind}} j_* \pi^*, \tag{45}$$

where

$$F_i \stackrel{\pi}{\longleftarrow} \operatorname{Attr}(F_i) \stackrel{j}{\longrightarrow} X$$

are the natural projection and inclusion maps. Here, near the diagonal means that we restrict to the complement of  $\bigcup_{F_j < F_i} \text{Attr}(F_j)$ .

#### 3.3.6

Note that the shift  $\tau(-\hbar \det \operatorname{ind})$  is necessary to make property  $(\star\star)$  agree with (43). Indeed, let  $N_{X^{\mathsf{A}},<0}$  be the repelling part of the normal bundle to  $X^{\mathsf{A}}$  so that

$$\Theta(-N_{X^{\mathsf{A}},<0}) \xrightarrow{j_*\pi^*} \mathscr{O}_{\mathrm{Ell}_{\mathsf{T}}(X)}.$$

We observe from Lemma 2.5 that

$$\Theta\left(T^{1/2}X - T^{1/2}X^{\mathsf{A}} - N_{X^{\mathsf{A}},<0} + (\operatorname{rk\,ind})\,\hbar\right)\Big|_{\mathscr{E}_{\mathsf{A}}\text{-orbits}} \cong \frac{\tau(-\hbar\,\det\operatorname{ind})^*\mathscr{U}}{\mathscr{U}}\,,$$

or, in other words, that the ratio of normal weights

$$\prod_{w \in \text{weights(ind)}} \frac{\vartheta(w)\,\vartheta(\hbar)}{\vartheta(\hbar^{-1}w^{-1})}$$

is a section of  $\mathcal{U}^{-1} \otimes \tau(-\hbar \det \operatorname{ind})^* \mathcal{U}$ . Here rk ind is the rank of (39).

Stable envelopes depend on the choice of polarization, but as (37) shows stable envelopes for different polarizations are related by a shift of Kähler parameters.

Also note that one of the factors of the base  $\mathscr{B}_{\mathsf{T},X}$  from (27) is naturally an extension

$$0 \to \mathscr{E}_{\mathsf{T}}^{\vee} \to \mathscr{E}_{\mathrm{Pic}_{\mathsf{T}}(X)} \to \mathscr{E}_{\mathrm{Pic}(X)} \to 0$$
.

As a simple corollary of the uniqueness of stable envelopes, see below, they are constant sections of trivial bundles along the  $\mathscr{E}_{\mathsf{T}}^{\vee}$ -orbits on the base  $\mathscr{B}_{\mathsf{T},X}$ . In particular, we don't introduce any special symbols to denote variables in  $\mathscr{E}_{\mathsf{T}}^{\vee}$  since nothing depends on them.

It is, however, convenient to keep these directions because the shifts (33) involve  $\lambda \in \operatorname{Pic}_{\mathsf{T}}(X)$  and really change if  $\lambda$  is twisted by a character of  $\mathsf{T}$ . A concrete form of this dependence is given by Lemma 2.4.

#### 3.3.8

In Theorem 2 in Section 3.5 below we will show that the properties required in Sections 3.3.2 and 3.3.5 determine stable envelopes uniquely. In particular, the dots in (43) mean certain automorphy factors in all variables other than those in  $\mathcal{E}_{A}$ . By uniqueness, these can be read off from the restriction (45) of stable envelopes to the diagonal.

<span id="page-23-1"></span>**Proposition 3.1.** Assuming uniqueness, elliptic stable envelopes give a map

<span id="page-23-2"></span>
$$\Theta\left(T^{1/2}X^{\mathsf{A}}\right) \otimes \mathscr{U}' \otimes \Theta(\hbar)^{-\operatorname{rk\,ind}} \xrightarrow{\operatorname{Stab}_{\mathfrak{C}}} \Theta\left(T^{1/2}X\right) \otimes \mathscr{U}, \tag{46}$$

where the shift  $\mathcal{U}'$  is a shift of the universal bundle as in (41) and rkind denotes the rank of (39).

<span id="page-23-0"></span>*Proof.* Follows from Lemma 2.5.

## 3.4 Example: $T^*\mathbb{P}(W)$

#### 3.4.1

Let W be a vector space and consider the  $GL(W) \times GL(1)$  module

<span id="page-23-3"></span>
$$M = W \otimes \mathbb{C} \,, \tag{47}$$

where  $\mathbb{C}$  denotes the defining representation of GL(1). We have

$$X = T^* \mathbb{P}(W)$$
  
=  $\{(v, \xi) \in M \oplus M^*, \langle \xi, v \rangle = 0, v \neq 0\} / GL(1)$ .

where

$$s \cdot (v, \xi) = (sv, s^{-1}\xi), \quad s \in GL(1).$$

In addition to GL(W), the group  $\mathbb{C}_{\hbar}^{\times}$  acts on  $M \oplus M^*$  and X by

$$hlineholdright holdsymbol{\hbar} \cdot (v, \xi) = (v, \hbar^{-1} \xi), \quad \hbar \in \mathbb{C}_{\hbar}^{\times}.$$

We denote  $G = GL(W) \times \mathbb{C}_{\hbar}^{\times}$ .

<span id="page-24-2"></span>The vector space M descends to a bundle  $\mathscr{M} \cong \mathscr{O}(1)^n$  on X and we take

<span id="page-24-0"></span>
$$T^{1/2}X = \mathcal{M} - \mathcal{O}_X \tag{48}$$

which is the pullback of the tangent bundle under  $X \to \mathbb{P}(W)$ .

#### 3.4.3

Let  $T \subset G$  be a maximal torus and  $A = T \cap GL(W)$ . The torus A acts diagonally in some basis  $\{e_i\} \subset W$  with weights  $a_i$ . Its fixed points are

$$F_i = {\mathbb{C}e_i} \in \mathbb{P}(W) \subset X$$
,

and we assume that  $\mathfrak{C}$  and the labeling of  $\{F_i\}$  are such that

$$F_1 > F_2 > \cdots > F_n$$
.

#### 3.4.4

The line bundle  $\mathcal{O}(1)$  associated to the fundamental weight s of GL(1) generates  $K_{\mathsf{T}}(X)$  and has weight  $a_i^{-1}$  at the ith fixed point. Hence

Spec 
$$K_{\mathsf{T}}(X) = \left\{ \prod (1 - sa_i) = 0 \right\} \subset \mathsf{T} \times GL(1)$$
.

The reduction of this modulo  $q^{\mathbb{Z}}$  is  $\mathrm{Ell}_{\mathsf{T}}(X)$ . We continue to use the product to denote the group operation on the quotient.

The coordinate s on  $GL(1)/q^{\mathbb{Z}} = E = E^{\vee}$  is the elliptic  $c_1(\mathcal{O}(1))$  and we denote by  $z \in E$  the dual Kähler parameter.

#### 3.4.5

We will now check that the function

<span id="page-24-1"></span>
$$\operatorname{Stab}(F_k) = \prod_{i < k} \vartheta(sa_i) \frac{\vartheta(sa_k z \hbar^{k-n})}{\vartheta(z \hbar^{k-n})} \prod_{i > k} \vartheta(sa_i \hbar)$$

$$\tag{49}$$

satisfies the definition for stable envelopes. Note a match between the terms in numerator and denominator of this expression to the terms in the polarization (48).

The first thing to check is that (49) is a section of a correct line bundle when restricted to  $\mathcal{E}_{A}$ -orbits in the base. This means that as function of  $a_i$ 's and s it has to have the same

factors of automorphy as the following product:

<span id="page-25-2"></span>
$$\prod_{i=1}^{n} \vartheta(sa_{i}) \times \qquad \text{from polarization}$$

$$\frac{\vartheta(sz)}{\vartheta(s)\vartheta(z)} \times \qquad \text{for } \mathscr{U} \text{ in the target}$$

$$\frac{\vartheta(a_{k}^{-1})\vartheta(z)}{\vartheta(a_{k}^{-1}z)} \times \qquad \text{for } \mathscr{U} \text{ in the source}$$

$$\frac{\vartheta(a_{k}^{k-n} \prod a_{i})\vartheta(\hbar)}{\vartheta(\hbar^{-1}a_{k}^{k-n} \prod a_{i})} \qquad \text{for } \tau(-\hbar \det \operatorname{ind}) \text{ in the source},$$

which is indeed the case. The factors in (50) have the following explanation.

Polarization in the target of Stab is given by (48) while the polarization in the source is trivial, thus the first line in (50). The variable s is defined as the dual to the coordinate z on  $\mathscr{E}_{\text{Pic}(X)}$ , which, in turn, corresponds to  $\mathscr{O}(1)$  with the chosen linearization. Thus the second line in (50) is obtained by copying (24). Restricted to  $F_k$ ,  $\mathscr{O}(1)$  becomes the trivial bundle with weight  $a_k^{-1}$ , thus the third line in (50) is the reciprocal of the second with the substitution  $s = a_k^{-1}$ . Finally

$$\operatorname{ind}(F_k) = \sum_{i>k} \frac{a_i}{a_k}$$

therefore

$$\det \operatorname{ind}(F_k) = a_k^{k-n} \prod_{i>k} a_i$$

which gives the fourth line in (50) as in Lemma (2.5).

#### 3.4.6

Evidently, the function (49) vanishes when restricted to  $F_i$  with i < k because of the factors  $\theta(sa_i)$ . When we restrict to  $F_k$ , we get precisely the product of  $\theta$ -functions of the repelling weights, with the correct sign.

## <span id="page-25-0"></span>3.5 Uniqueness

<span id="page-25-1"></span>Theorem 2. Elliptic stable envelopes are unique.

The key logical point in the argument below will be the following rigidity statement. If  $s \neq 0$  is a regular section of a degree zero line bundle  $\mathcal{L}$  on an abelian variety  $\mathcal{E}$  then  $\mathcal{L} = \mathcal{O}_{\mathcal{E}}$  is the trivial line bundle. For us,  $\mathcal{E}$  will be an  $\mathcal{E}_{A}$ -orbit in  $\mathcal{B}_{X,T}$  and  $\mathcal{L}$  a certain relative of the universal bundle  $\mathcal{U}$  restricted to  $\mathcal{E}$ . The latter has a nontrivial z-dependence, and in particular  $\mathcal{L} \ncong \mathcal{O}_{\mathcal{E}}$ . This rules out nonzero sections of  $\mathcal{L}$ .

*Proof.* Suppose for some  $\mathfrak{C}$  there are two different maps Stab and Stab' satisfying the above conditions. Let  $F_i$  be a component of the fixed locus and consider the map

$$\delta = \left(\left. \operatorname{Stab} - \operatorname{Stab}' \right. \right) \Big|_{F_i \text{ summand in the source}}.$$

By the normalization condition

$$\operatorname{supp}(\delta) \subset \bigcup_{F_j < F_i} \operatorname{Attr}(F_j),$$

and we will argue as in Section 3.3.4 that, in fact,  $supp(\delta) = \emptyset$ .

The closed sets  $Y_j$  in (44) form a partially ordered set and we fix a maximal element  $Y_k$  among those that intersect supp $(\delta)$ . We set

$$X' = X \setminus \bigcup_{F_j \not\geq F_k} \text{Attr}(F_j)$$
$$Y' = X' \cap Y_k.$$

The long exact sequence of the pair  $(X', X' \setminus Y')$  in elliptic cohomology starts out as

<span id="page-26-0"></span>
$$0 \to \Theta(-N_{X'/Y'}) \to \mathscr{O}_{\mathrm{Ell}_{\mathsf{T}}(X')} \to \mathscr{O}_{\mathrm{Ell}_{\mathsf{T}}(X'\setminus Y')} \to \dots$$
 (51)

and by our hypothesis  $\delta$  restricts to zero on  $X' \setminus Y'$ . Our goal is to show that  $\delta$  restricts to zero on X'. Since Y' is a vector bundle over the  $F_k$ , it is enough to show that the pullback of  $\delta$  under

$$\iota_k: F_k \to X$$

vanishes.

Let

$$s = \iota_k^* \, \delta \bigg|_{\mathscr{E}_{\mathsf{A}} b}$$

be the restriction of this pullback to a general  $\mathcal{E}_{A}$ -orbit

$$\mathscr{E}_{\mathsf{A}}b\subset\mathscr{B}_{\mathsf{T},X}\,,\quad b=(t,z)\in\mathscr{E}_{\mathsf{T}}\times\mathscr{E}_{\mathrm{Pic}_{\mathsf{T}}(X)}$$

in the base  $\mathscr{B}_{\mathsf{T},X}$ . Since A does not act on  $F_k$ , the restriction of  $\mathscr{O}_{\mathrm{Ell}_{\mathsf{T}}(F_k)}$  to  $\mathscr{E}_{\mathsf{A}}b$  is a trivial bundle with fiber  $H^{\bullet}(F_k^{\mathsf{T}_t},\mathbb{C})$ , where  $\mathsf{T}_t$  is as Section 2.3.2. Therefore, s is a regular section of a trivial bundle twisted by a line bundle.

From (51), we see that s is divisible by

$$\theta \in H^0\left(\Theta(TX\big|_{F_k,<0})\right)$$
,

where  $TX|_{F_k,<0}$  are the repelling directions in the normal bundle to  $F_k$ . The A-weights in  $TX|_{F_k,<0}$  are, up to a sign, the same as the A-weights of  $T^{1/2}X$ . Therefore

$$\theta^{-1}s \in H^0(\mathscr{E}_{\mathsf{A}}\,b,\mathscr{O}^{\mathrm{rk}}\otimes\mathscr{L}_{t,z})\,,\quad \deg\mathscr{L}_{t,z}=0\,,$$

where  $\mathcal{L}_{t,z}$  is a certain combination of Thom bundles and the universal bundle. Since it is a line bundle of degree zero

$$s \neq 0 \implies \mathcal{L}_{t,z}$$
 is trivial.

This is, however, impossible because  $\mathscr{U}|_{\mathscr{E}_{\mathsf{A}}}$ , and hence  $\mathscr{L}_{t,z}$ , depends nontrivially on the variable z. Indeed, since  $F_i > F_k$ , there exists a chain of A-invariant rational curves that flows from  $F_k$  to  $F_i$ . An ample line bundle on X will have a positive degree on this chain of curves, hence different A-weights on  $F_i$  and  $F_k$ . Since there is a line bundle with different weights on  $F_i$  and  $F_k$ , the dependence on z is nontrivial. So,

$$\mathscr{L}_{t,z}$$
 is nontrivial  $\Longrightarrow$   $s=0$   $\Longrightarrow$   $\iota_k^* \delta = 0$   $\Longrightarrow$   $\delta = 0$ .

<span id="page-27-2"></span>Corollary 3.2. Stable envelopes preserve support in the sense that

$$\operatorname{supp} \operatorname{Stab}(\,\cdot\,) \subset \operatorname{Attr}^f(\operatorname{supp}(\,\cdot\,)) \ .$$

*Proof.* Apply the logic above to  $X \setminus \operatorname{Attr}^f(\operatorname{supp}(\cdot))$ .

## <span id="page-27-3"></span><span id="page-27-0"></span>3.6 Triangle lemma

#### 3.6.1

Let  $\mathfrak{C}' \subset \mathfrak{C}$  be a face of some dimension, as in Section 3.6 in [49] and let  $A' \subset A$  be the subtorus associated to the span of  $\mathfrak{C}'$  in Lie A. We have a triangle of embeddings

![](_page_27_Picture_10.jpeg)

to each arrow in which we can associate a stable envelope map. In particular, we have the stable envelope map  $\operatorname{Stab}_{\mathfrak{C}/\mathfrak{C}'}$ , which we can pull back to  $\mathscr{B}_{\mathsf{T},X}$  using the composition of the maps

$$\boldsymbol{\tau}: \mathscr{B}_{\mathsf{T},X} \to \mathscr{B}_{\mathsf{T},X^{\mathsf{A}'}} \xrightarrow{\tau(-\hbar \det \mathrm{ind})} \mathscr{B}_{\mathsf{T},X^{\mathsf{A}}} \to \mathscr{B}_{\mathsf{T}/\mathsf{A},X^{\mathsf{A}}}$$

where the first and the last are the natural maps and the middle translates by

$$\det \operatorname{ind} \in \operatorname{Pic}_{\mathsf{T}}(X^{\mathsf{A}'})$$
.

Here the index is the index associated to the embedding  $X^{\mathsf{A}'} \to X$  by the given polarization of X. We denote

$$\operatorname{Stab}_{\mathfrak{C}/\mathfrak{C}'}(\,\cdot\,-\hbar\det\operatorname{ind}_{X^{\mathsf{A}'}}) = \boldsymbol{\tau}^*\operatorname{Stab}_{\mathfrak{C}/\mathfrak{C}'}$$
.

<span id="page-27-1"></span>**Proposition 3.3.** We have

$$\operatorname{Stab}_{\mathfrak{C}} = \operatorname{Stab}_{\mathfrak{C}'} \circ \operatorname{Stab}_{\mathfrak{C}/\mathfrak{C}'} (\cdot - \hbar \det \operatorname{ind}_{X^{\mathsf{A}'}}).$$

*Proof.* Immediate from the uniqueness of stable envelopes.

#### **3.6.2** Example

For  $T^*\mathbb{P}(W)$ , see section 3.4 we can take

$$W' = \bigoplus_{i=1}^{m} \mathbb{C}e_i \subset W$$

and  $A' \subset A$  the point-wise stabilizer of  $\mathbb{P}(W') \subset \mathbb{P}(W)$ , so that

$$X^{\mathsf{A}'} = T^* \mathbb{P}(W') \sqcup \{F_{m+1}, \dots, F_n\}.$$

Then

$$\operatorname{ind}_{T^*\mathbb{P}(W')} \cong \sum_{i=m+1}^n a_i \mathscr{O}(1)$$

and hence the shift of the stable envelope by  $-\hbar$  detind is the shift of the Kähler parameters by  $-\hbar \mathcal{O}(n-m)$ , which means  $z \mapsto z\hbar^{m-n}$ . These are precisely the shifts in the formula (49).

## <span id="page-28-0"></span>3.7 Duality

#### 3.7.1

Let  $f: X \to Y$  be a T-equivariant map between formal T-varieties and suppose that the restriction of f to  $X^{\mathsf{T}}$  is proper. Equivariant localization lets one define  $f_*$  as the unique map completing the diagram

$$\Theta_{X^{\mathsf{T}}} \left( TX^{\mathsf{T}} - f^*TY \right) \xrightarrow{\iota_*} \Theta_X \left( TX - f^*TY \right) . \tag{52}$$

$$\mathscr{O}_{\mathsf{Ell}_{\mathsf{T}}(Y)}$$

In particular, for the map  $f: X \to \operatorname{pt}$  we get the composite map

<span id="page-28-1"></span>
$$\Theta(T^{1/2}X) \otimes \Theta(T_{\text{opp}}^{1/2}X) \xrightarrow{\text{product}} \Theta(TX) \xrightarrow{f_*} \mathscr{O}_{\mathscr{E}_{\mathsf{T}}, \text{localized}},$$
 (53)

in which the first map is multiplication and the second pushforward.

#### 3.7.2

Define

$$\operatorname{Stab}_{\mathfrak{C},T^{1/2}X}^*(z) = \operatorname{Stab}_{-\mathfrak{C},T^{1/2}_{\operatorname{opp}}X}(-z)^\vee$$

where  $z \in \mathscr{E}_{\mathrm{Pic}_{\mathsf{T}}(X)}$  is the Kähler parameter and the dual means transpose with respect to dualities (25) and (53). This is a meromorphic map

$$\Theta\left(T^{1/2}X\right) \otimes \mathscr{U} \xrightarrow{\operatorname{Stab}^*} \Theta\left(T^{1/2}X^{\mathsf{A}}\right) \otimes \mathscr{U}' \otimes \dots, \tag{54}$$

where, again, dots stand for a certain line bundle pulled back from  $\mathscr{B}'=\mathscr{B}_{\mathsf{T},X}/\mathscr{E}_{\mathsf{A}}$ .

#### 3.7.3

Duality for stable envelopes is the following

#### <span id="page-29-2"></span>Proposition 3.4.

$$\operatorname{Stab}^* \circ \operatorname{Stab} = 1$$
.

*Proof.* Since the attracting and repelling manifolds intersect properly, the composition is regular.

Fix two components  $F_i$  and  $F_j$  and restrict  $\operatorname{Stab}^* \circ \operatorname{Stab}$  to the corresponding direct summands in the source and in the target. By the support condition, this restriction is only nonzero if  $F_i \geq F_j$ .

If  $F_i > F_j$  then the argument already used in the proof of Theorem 2 shows the universal bundle  $\mathscr{U}$  has different z-dependence in the source and in the target. It follows that  $\operatorname{Stab}^* \circ \operatorname{Stab}$  vanishes in this case also.

For  $F_i = F_j$ , condition  $(\star\star)$  in Section 3.3.5 implies Stab\*  $\circ$  Stab is the identity, which concludes the proof.

# <span id="page-29-0"></span>4 Existence of stable envelopes

## <span id="page-29-1"></span>4.1 Hypertoric varieties

#### 4.1.1

Hypertoric varieties X, see e.g. [61], are algebraic symplectic reductions of a vector space by an action of a torus S, that is,

$$X = T^* M / / / S = \mu^{-1}(0) / / S = \mu^{-1}(0)_{ss} / S$$

where M is a representation of S and

$$\mu: T^*M \to \mathrm{Lie}(S)^*$$

is the (holomorphic) moment map. As the torus T we can take a maximal torus

$$\mathsf{T} \subset \mathbb{C}_{\hbar}^{\times} \times GL(M)^{S}$$
,

where  $\mathbb{C}_{\hbar}^{\times}$  acts by rescaling the cotangent directions with weight  $\hbar^{-1}$ .

#### 4.1.2

An example of a hypertoric variety is  $T^*\mathbb{P}(M)$  discussed in Section 3.4. In this case  $S \cong \mathbb{C}^{\times}$  acts on M by scalars.

In this paper, we assume the S-action on  $\mu^{-1}(0)_{ss}$  is free and so X is smooth. This is a very strong restriction on the S-module M. Namely, if we think of weights of M as a matrix

$$\mathbb{Z}^{\dim M} \to \operatorname{char}(S) \cong \mathbb{Z}^{\operatorname{rk} S}$$

then this matrix is surjective and determinants of all its submatrices (in particular, all matrix elements) are in  $\{0, \pm 1\}$ .

#### 4.1.3

Generalizing the explicit formula (49), we have the following:

**Proposition 4.1.** Stable envelopes exist for hypertoric varieties.

*Proof.* We first deal with the case  $A = \operatorname{Ker} h$ , in which case  $X^A$  is a finite set. Let F be one of the fixed points. We may assume

$$F = T^* M_0 /\!\!/\!/ S$$

where the decomposition

<span id="page-30-0"></span>
$$M = M_0 \oplus M_1 \tag{55}$$

is such that

• S acts as a maximal torus on  $M_0$ 

$$S \cong \left\{ \begin{pmatrix} s_1 & & \\ & s_2 & \\ & & \ddots \end{pmatrix} \right\} \subset GL(M_0),$$

ullet A acts as a maximal torus in  $M_1$  and with weights  $\alpha_i$  on  $M_0$  .

Further we may assume that

$$T^{1/2}X = \mathcal{M} - \text{Lie}(S)$$

where  $\mathcal{M}$  is the bundle associated to the representation M and Lie(S) is the trivial bundle with this fiber. In accordance with (55),  $\mathcal{M} = \mathcal{M}_0 \oplus \mathcal{M}_1$  and we can further assume that

$$T^{1/2}\big|_{F,<0}=\mathscr{M}_1.$$

Then

<span id="page-30-1"></span>
$$\operatorname{Stab}(F) = \vartheta(\mathcal{M}_1) \prod_{i=1}^{\operatorname{rk} S} \frac{\vartheta(s_i z_i \alpha_i)}{\vartheta(z_i)}$$
(56)

where  $\vartheta(\mathcal{M}_1)$  is the product  $\vartheta(x_i)$  over the Chern roots  $x_i$  of  $\mathcal{M}_1$ . This generalizes formula (49).

For subtori  $A' \subset A$ , we can use Proposition 3.3 and duality from Proposition 3.4 to write

$$\operatorname{Stab}_{\mathfrak{C}'} = \operatorname{Stab}_{\mathfrak{C}} \circ \operatorname{Stab}_{\mathfrak{C}/\mathfrak{C}'} (\cdot - \hbar \det \operatorname{ind}_{X^{\mathsf{A}'}})^*.$$

The left-hand side of this formula defines stable envelopes for general subtori in Ker  $\hbar$ .  $\Box$ 

## <span id="page-31-0"></span>4.2 Nakajima varieties

#### 4.2.1

Now suppose

<span id="page-31-5"></span>
$$X = T^* M / / / G = \mu^{-1}(0) / / G$$
(57)

where  $G \subset GL(M)$  is reductive and

$$\mu: T^*M \to \mathfrak{g}^*, \quad \mathfrak{g} = \operatorname{Lie} G$$

is the moment map for the G-action. If we additionally assume that the G-action on  $\mu^{-1}(0)_{ss}$  is free and G is nonabelian, then the only examples of such quotients known to us are Nakajima varieties.

#### <span id="page-31-4"></span>4.2.2

As before, we take T to be the maximal torus

$$\mathsf{T} \subset \mathbb{C}_{\hbar}^{\times} \times GL(M)^G$$
,

and as a polarization we can take

<span id="page-31-3"></span>
$$T^{1/2}X = \mathscr{M} - \mathscr{G} \,, \tag{58}$$

where  $\mathscr{G}$  is the bundle on X associated to the adjoint action of G on  $\mathfrak{g}$ .

#### 4.2.3

<span id="page-31-1"></span>**Theorem 3.** Elliptic stable envelopes exist for Nakajima varieties.

The proof will reduce the statement to the existence of stable envelopes for hypertoric varieties. The general circle of ideas relating the cohomology of a *G*-quotient to the cohomology of the quotient by the maximal torus is known as *abelianization*, see in particular [40]. Abelianization of stable envelopes in the usual equivariant cohomology was developed by D. Shenfeld [63], see also the exposition in [64].

## <span id="page-31-2"></span>4.3 Proof of Theorem 3

#### 4.3.1

Let S be a maximal torus of G and let  $B \supset S$  be a Borel subgroup with Lie algebra  $\mathfrak{b}$ . Choose a maximal compact subgroup  $U \subset G$  and a U-invariant Hermitian metric  $\|\cdot\|$  on M. This defines a real moment map

$$\mu_{\mathbb{R}}: T^*M \to \mathfrak{u}^*, \quad \mathfrak{u} = \operatorname{Lie} U.$$

Consider the diagram

<span id="page-32-3"></span>
$$\begin{array}{ccc}
\mathsf{FI} & \xrightarrow{\mathsf{j}_{+}} & \mu^{-1}(\mathfrak{b}^{\perp}) /\!\!/ S & \xrightarrow{\mathsf{j}_{-}} & X_{S} \\
\downarrow^{\pi} & & & & & & & & & & & & & & & & & & &$$

in which

$$\mathsf{FI} = \mu_{\mathbb{R}}^{-1}(\eta) / (U \cap S) , \quad X_S = T^* M / \! / \! / \! / S,$$
 (60)

where the parameter  $\eta \in (\mathfrak{u}^*)^U$  corresponds to the choice of the stability condition for the GIT quotient<sup>4</sup>.

The fibers of  $\pi$  are flag varieties

<span id="page-32-2"></span>
$$U/(U \cap S) \cong G/B. \tag{61}$$

<span id="page-32-0"></span>The choice of B in this isomorphism will be important below.

#### 4.3.2

While FI is not a complex subvariety of  $X_S$ , the map  $\pi$  is a G/B-bundle and therefore is complex-oriented. The description of elliptic cohomology of G/B-bundles, see Section 1.9 in [33], shows:

- The cohomology of FI is generated as a module over the cohomology of the base by tautological line bundles. In particular, it is tautological if the cohomology of X is tautological.
- The map of sheaves

$$\pi_*: \Theta(\operatorname{Ker} d\pi) \to \mathscr{O}_{\operatorname{Ell}_{\mathsf{T}}(X)}$$

is surjective.

#### 4.3.3

Recall the polarization of X introduced in Section 4.2.2. We have

$$\pi^* \mathscr{G} = \mathscr{N} \oplus \mathscr{N}^{\vee} \oplus \mathrm{Lie}(S)$$
,

where  $\mathscr{N}$  is the bundle on  $X_S$  associated to the adjoint action of S on  $\mathfrak{n} = [\mathfrak{b}, \mathfrak{b}]$  and Lie(S) is a trivial bundle with this fiber.

The isomorphism (61) gives

<span id="page-32-5"></span>
$$\operatorname{Ker} d\pi \cong \mathscr{N}^{\vee}. \tag{62}$$

Therefore we may replace  $\pi^*\mathscr{G}$  by  $\operatorname{Ker} d\pi \oplus \hbar^{-1}\mathscr{N}^{\vee} \oplus \operatorname{Lie}(S)$  in a polarization. This gives a polarization of  $T^{1/2}X_S$  such that

<span id="page-32-4"></span>
$$j^* \left( T^{1/2} X_S - \hbar^{-1} \mathscr{N}^{\vee} \right) = \pi^* (T^{1/2} X) + \text{Ker } d\pi \,, \tag{63}$$

where  $j = j_{-} \circ j_{+}$ .

<span id="page-32-1"></span><sup>&</sup>lt;sup>4</sup>Nakajima denotes the parameter  $\eta$  by  $\theta$ .

Consider the following chain of maps

$$\Theta(T^{1/2}X) \longleftarrow^{\pi_*} \Theta(\pi^*(T^{1/2}X) + \operatorname{Ker} d\pi) \longleftarrow^{j_+^*} \longleftrightarrow \Theta(j_-^*(T^{1/2}X_S - \hbar^{-1}\mathcal{N}^{\vee})) \xrightarrow{j_{-,*}} \Theta(T^{1/2}X_S), \quad (64)$$

in which we used the identification

<span id="page-33-2"></span><span id="page-33-0"></span>
$$j_{-}^{*} \hbar^{-1} \mathcal{N}^{\vee} = \text{normal bundle to } j_{-}.$$
 (65)

We claim the map  $j_+^*$  in (64) is also surjective. Indeed any tautological class extends to a class on all of  $X_S$ .

#### 4.3.5

The map

$$\operatorname{Pic}(X) = \operatorname{char} G \to \operatorname{char} S = \operatorname{Pic}(X_S)$$

induces an embedding  $\mathscr{B}_{\mathsf{T},X} \hookrightarrow \mathscr{B}_{\mathsf{T},X_S}$  such that all maps in (64) are defined after tensoring with the universal bundle and restricting to the image of this embedding.

#### 4.3.6

Let A be a torus in the kernel of  $\hbar$  and let F be a component of  $X^A$ . The torus A acts on  $\pi^{-1}(F)$ . Let F' be a component of  $\pi^{-1}(F)^A$ . The composite map  $\pi'_*$  in the diagram

$$F' \xrightarrow{\pi^{-1}(F)} \pi$$

$$\downarrow^{\pi}$$

$$F$$

$$(66)$$

is still surjective on elliptic cohomology because it is still a fibration by flag varieties.

#### <span id="page-33-3"></span>4.3.7

Of all possible F' we pick the one for which the normal weights to F' in  $\pi^{-1}(F)$  are repelling for the action of A, or in other words

<span id="page-33-1"></span>
$$\left(\operatorname{Ker} d\pi\big|_{F'}\right)_{>0} = 0. \tag{67}$$

Recall that the fibers of  $\pi$  are smooth and connected, therefore there is exactly one component of the fixed locus for which all normal weights are repelling.

The points of F' are fixed by A on the quotient by S, which means that there is a map

$$\phi_F:\mathsf{A}\to S$$

so that the preimage of F' in  $T^*M$  is fixed point-wise under the action of  $(a, \phi(a)) \in A \times S$ . This induces an action of A on  $\mathfrak{g}$  and (67) means

<span id="page-34-3"></span>
$$(\mathfrak{n}^{\vee})_{>0} = 0 \tag{68}$$

or equivalently

<span id="page-34-0"></span>
$$\left(\mathscr{N}^{\vee}\big|_{F'}\right)_{>0} = 0. \tag{69}$$

### 4.3.9

Consider the following analog of (59)

$$F' \xrightarrow{j'_{+}} F_{S} \cap \mu^{-1}(\mathfrak{b}^{\perp}) /\!\!/ S \xrightarrow{j'_{-}} F_{S}$$

$$\downarrow F$$

$$(70)$$

where  $F_S$  is the component of  $X_S^A$  that contains F'. As before,  $(j'_+)^*$  is surjective and the equations (63), (67), and (69) imply that

<span id="page-34-1"></span>
$$\pi^*(\operatorname{ind} F) = (j')^*(\operatorname{ind} F_S) , \qquad (71)$$

where  $j' = j'_- \circ j'_+$ .

#### 4.3.10

We want to define the stable envelope as the composition

<span id="page-34-2"></span>
$$\Theta\left(T^{1/2}F\right) \otimes \mathscr{U}' \xrightarrow{\mathbf{j}'_{-,*}\left((\mathbf{j}'_{+})^{*}\right)^{-1}\left(\pi'_{*}\right)^{-1}} \Theta\left(T^{1/2}F_{S}\right) \otimes \mathscr{U}' 
\operatorname{Stab}_{\downarrow} \qquad \operatorname{Stab}_{S} \downarrow 
\Theta\left(T^{1/2}X\right) \otimes \mathscr{U} \xrightarrow{\pi_{*}\mathbf{j}_{+}^{*}\left(\mathbf{j}_{-,*}\right)^{-1}} \Theta\left(T^{1/2}X_{S}\right) \otimes \mathscr{U} \tag{72}$$

in which the index shifts agree by (71).

We need to check that the inverse maps that appear in both horizontal arrows on (72) are well defined.

The inverse in the top horizontal line of (72) means that we pick a tautological class on  $X_S$  that maps to the right class on X under  $\pi'_* \circ (j'_+)^*$ . While the corresponding map of sheaves is surjective, taking the preimage is by itself not a well-defined operation. However, A acts trivially on F and therefore the corresponding sheaves are *trivial* along the  $\mathscr{E}_A$ -orbits on the base  $\mathscr{B}_{X,\mathsf{T}}$ . Therefore, the preimage may be chosen locally on  $\mathscr{B}_{X,\mathsf{T}}/\mathscr{E}_A$ . The resulting stable envelope maps glue by the uniqueness proven in Theorem 2.

#### 4.3.12

It remains to check that the inverse in

$$(j_{-,*})^{-1} \circ \operatorname{Stab}_S \circ j'_{-,*}$$

is well-defined.

Since  $\mu$  is an equivariant map and the normal weights to  $\mathfrak{b}^{\perp} \subset \mathfrak{g}^*$  are non-attracting by (68) it follows that

$$\operatorname{Attr}^f(\mu^{-1}(\mathfrak{b}^{\perp})^{\mathsf{A}}) \subset \mu^{-1}(\mathfrak{b}^{\perp}).$$

From Corollary 3.2 we now conclude that  $\operatorname{Stab}_S \circ j'_{-,*}$  factors through  $j_{-,*}$  and hence the diagram (72) is well-defined.

#### 4.3.13

By construction, we get a section of the correct line bundle with the correct support as in the condition  $(\star)$  in Section 3.3.5. To finish the proof, we need to verify condition  $(\star\star)$  in the same section.

Consider the maps in the diagram (72) in the neighborhood of F'. The hypertoric map  $\operatorname{Stab}_S$  satisfies  $(\star\star)$  and, therefore, we need to analyze the difference between the vector bundles  $\pi^* \left( N_{X/F} \right)_{<0}$  and  $\left( N_{X_S/F'} \right)_{<0}$ . By our analysis, new repelling normal directions in  $X_S$  appear either in (62) or in (65). In the first case, they cancel out upon  $\pi_*$ . In second case, they cancel out upon  $(j_{-,*})^{-1} \circ \operatorname{Stab}_S \circ j'_{-,*}$ . This concludes the proof.

## <span id="page-35-0"></span>4.4 Example: $T^*Gr(k, n)$

#### 4.4.1

The cotangent bundle  $X = T^*\mathsf{Gr}(k,n)$  of the Grassmannian is obtained for

$$M=\mathbb{C}^n\otimes\mathbb{C}^k$$

with G = GL(k) and

$$\mathsf{A} = \begin{pmatrix} a_1 & & \\ & \ddots & \\ & & a_n \end{pmatrix} \subset GL(n) \, .$$

The abelianization of X is the product

$$X_S = T^* \mathbb{P}(\mathbb{C}^n)^{\times k}$$

of cotangent bundles of projective spaces discussed in Section 3.4. We choose the chamber  $\mathfrak{C}$  as in that example, which means that

$$a_j/a_i > 0 \quad \Leftrightarrow \quad i < j$$
.

#### 4.4.2

A particular simplifying feature of this example is that the A-fixed points on  $X_S$  are isolated. Concretely, the points in  $X^A$  correspond to coordinate subspaces in Gr(k, n) and are indexed by k-element subsets of  $\{1, \ldots, n\}$ . The fixed points above them correspond to injective maps

<span id="page-36-0"></span>
$$\mu: \{1, \dots, k\} \to \{1, \dots, n\}.$$
 (73)

Other points in  $X_S^{\mathsf{A}}$  are G-unstable.

#### 4.4.3

We identify coordinates in

$$S = \begin{pmatrix} s_1 & & \\ & \ddots & \\ & & s_k \end{pmatrix} \subset GL(k)$$

with the Chern roots of the tautological bundle over X, and with the Chern classes of the tautological line bundles over  $X_S$ . At fixed points of  $X_S^A$ 

$$s_i = a_{\mu(i)}^{-1}, \quad i = 1 \dots k.$$

We choose upper-triangular matrices as B. Then the special lift F' of the fixed point from Section 4.3.7 is such that

$$\mathscr{N}^{\vee}|_{F'} = \sum_{i < j} s_j / s_i = \sum_{i < j} a_{\mu(i)} / a_{\mu(j)} < 0$$

which means that the map (73) is increasing, that is,

<span id="page-36-1"></span>
$$1 \le \mu(1) < \mu(2) < \dots < \mu(k) \le n. \tag{74}$$

#### 4.4.4

The polarization  $T^{1/2}X_S$  in (63) differs from the standard polarization of  $X_S$  by

$$\delta T^{1/2} = \hbar^{-1} \mathscr{N}^{\vee} - \mathscr{N} ,$$

which by (37) shifts the Kähler parameters by  $2\hbar\rho$ , where

$$2\rho = (n-1, n-3, \dots, 1-n)$$

is the sum of positive roots.

Denote by

$$\mathsf{f}_{m}(s,z) = \prod_{i < m} \vartheta(sa_{i}) \frac{\vartheta(sza_{i}\hbar^{m-n})}{\vartheta(z\hbar^{m-n})} \prod_{i > k} \vartheta(sa_{i}\hbar)$$

the function from (49). Let  $F_{\mu} \in X^{A}$  be the fixed point below the point (74). We have

<span id="page-37-1"></span>
$$\operatorname{Stab}(F_{\mu}) = \operatorname{Symm} \frac{\prod_{i=1}^{k} \mathsf{f}_{\mu(i)}(s_{i}, z\hbar^{2\rho_{i}})}{\prod_{i < j} \vartheta(s_{i}/s_{j}) \vartheta(s_{j}/s_{i}/\hbar)}. \tag{75}$$

The numerator is the stable envelope on  $X_S$ , with the shift of the Kähler variables explained above. One of the terms in the denominator is  $\Theta(\hbar^{-1}\mathcal{N}^{\vee})$  that comes from inverting  $j_{-,*}$ . The other term in the denominator, together with the symmetrization in the variables  $s_i$ , is the push-forward  $\pi_*$ . We wrote  $\Theta(\mathcal{N}^{\vee})$  with a change of sign, so that the sign agrees with polarization.

Formula (75) is the elliptic analog of Proposition 5.3.1 from [63].

#### 4.4.6

When the fixed loci  $X_S^A$  are not isolated, abelianization formulas become more involved but can still be made reasonably explicit, see [65].

## <span id="page-37-0"></span>4.5 K-theory limit

#### 4.5.1

As  $q \to 0$ , the elliptic curve E converges to the nodal elliptic curve with smooth locus isomorphic to  $\mathbb{C}^{\times}$  and the group law given by  $(x,y) \mapsto x+y+xy$ . Correspondingly, the scheme  $\mathrm{Ell}_{\mathsf{T}}(X)$  converges to the spectrum of  $K_{\mathsf{T}}(X) \otimes \mathbb{C}$ . In analytic terms, one can see these flat limits of schemes very concretely, as  $\mathrm{Ell}_{\mathsf{T}}(X)$  are quotients of  $\mathrm{Spec}\,K_{\mathsf{T}}(X) \otimes \mathbb{C}$  with a fundamental domain that grows to become the whole space.

Sections of line bundles on  $\mathrm{Ell}_{\mathsf{T}}(X)$ , which are functions with a certain automorphy under multiplicative translations by q and  $e^{2\pi i}$ , converge to sections of line bundles on  $K_{\mathsf{T}}(X) \otimes \mathbb{C}$ , i.e. to function that may pick up sign under a multiplicative translation by  $e^{2\pi i}$ . Restricted to  $X^{\mathsf{A}}$ , these become Laurent polynomials on  $\mathsf{A}$  with integral or half-integral exponents.

In the  $q \to 0$  limit, the effect of shifts by q is replaces by the growth condition on the these Laurent polynomials at the infinity of A. This growth condition, which is the subject of this subsection, is formulated in terms of the Newton polygons, matching the definition of the K-theoretic stable envelope, see [57].

#### 4.5.2

Recall that the function (8) satisfies

$$\vartheta(e^{2\pi i}x) = -\vartheta(x) .$$

To avoid half-integer exponents, we define

$$\operatorname{Stab}_{\nabla} = \left(\det T^{1/2}\right)^{-1/2} \circ \operatorname{Stab} \circ \left(\det T_{X^{\mathbf{A}}}^{1/2}\right)^{1/2}.$$

From (45) we get

<span id="page-38-0"></span>
$$\operatorname{Stab}_{\nabla} \to (-1)^{\operatorname{rk} \operatorname{ind}} \left( \frac{\det N_{<0}}{\det N^{1/2}} \right)^{1/2} j_* \pi^*, \quad q \to 0,$$
 (76)

near the diagonal, where  $j_*$  and  $\pi^*$  are the corresponding operations in K-theory. The restriction of  $j_*\pi^*$  back to the fixed locus is given by tensor product with

$$\Lambda^{\bullet} N_{<0}^{\lor} = \sum_{k} (-1)^{k} \Lambda^{k} N_{<0}^{\lor}.$$

In particular, the A-weights in (76) are the same as those occurring in the expansion of  $\prod_{w \in N^{1/2}} (1 - w^{-1})$ .

#### 4.5.3

For a given component F of  $X^A$ , we denote

$$\Delta_F = \text{Convex hull}\left(\sup \prod_{w \in N^{1/2}} (1 - w^{-1})\right) \subset \mathsf{A}^{\wedge} \otimes_{\mathbb{Z}} \mathbb{R},$$

where support means the set of weights that occur in the expansion of the product, that is, the set of exponents that appear in a multivariate Laurent polynomial.

A convex hull like this is called a Newton polytope and it controls the growth of the polynomial at the infinity of a torus A. The  $q \to 0$  of elliptic stable envelopes will be characterized by a bound on their Newton polytopes in equivariant variables, in addition to the same triangularity and normalization as for the elliptic stable envelopes. This will precisely recover the definition of the K-theoretic stable envelopes, see [57].

#### 4.5.4

Let  $F_1$  and  $F_2$  be two components of  $X^A$  and consider the restriction

$$\operatorname{Stab}_{\nabla}\Big|_{F_2 \times F_1} \tag{77}$$

of the stable envelope of  $F_1$  to  $F_2$ . Suppose that  $\ln(q)$  and  $\ln(z)$  both go infinity so that

<span id="page-38-1"></span>
$$-\Re \frac{\ln z}{\ln q} \to \mathscr{L} \in \operatorname{Pic}(X) \otimes_{\mathbb{Z}} \mathbb{R},$$
 (78)

where  $\mathscr{L}$  is generic.

**Proposition 4.2.** If X is a hypertoric variety or a Nakajima quiver variety then

<span id="page-39-2"></span>
$$\operatorname{supp} \lim_{q \to 0} \operatorname{Stab}_{\nabla} \Big|_{F_2 \times F_1} \subset \Delta_{F_2} + \text{weight of } \mathscr{L}|_{F_2} - \text{weight of } \mathscr{L}|_{F_1}. \tag{79}$$

While the statement should not be specific to quiver varieties, we prove it here in the same generality as the existence of elliptic stable envelopes. Also note the multivariate statement (79) is equivalent to its pull-back by an arbitrary cocharacter  $\mathbb{C}^{\times} \to A$ . Therefore, it is enough to prove it when  $\mathrm{rk} A = 1$ .

*Proof.* For hypertoric varieties, the statement follows at once from (56) and (2). For Naka-jima quiver varieties, we follow the logic of the proof of Theorem 3.

Consider the bottom arrow in the diagram (72). In the composition of the three maps there, the middle map  $j_+^*$  is the functorial pull-back in elliptic cohomology and it does not change restriction to fixed points. The other two maps, give theta-functions in the denominators, as exemplified by the formula (75).

We have

$$x^{-1/2}\vartheta(x) \to 1 - x^{-1}, \quad q \to 0,$$

and thus both maps reduce the Newton polytope by precisely the difference between the polarizations of X and  $X_S$ . This concludes the proof.

We have shown the following

**Proposition 4.3.** In the limit when  $q \to 0$  and  $\ln z \to \infty$  so that the limit (78) is generic, the elliptic stable envelope  $\operatorname{Stab}_{\nabla}$  converges to the K-theoretic stable envelope with slope  $\mathscr{L}$ .

## <span id="page-39-1"></span><span id="page-39-0"></span>5 R-matrices

## 5.1 Definition

#### 5.1.1

Let  $\mathfrak{C}_1$  and  $\mathfrak{C}_2$  be two chambers in Lie A. We define

$$R_{\mathfrak{C}_2 \leftarrow \mathfrak{C}_1} = \operatorname{Stab}_{\mathfrak{C}_2}^{-1} \circ \operatorname{Stab}_{\mathfrak{C}_1},$$

where some fixed polarization is understood. Instead of the inverse, we can use the dual, as in Proposition 3.4. By construction,

$$\Theta\left(T^{1/2}X^{\mathsf{A}}\right)\otimes\tau(\hbar\det\delta\operatorname{ind})^*\mathscr{U}\xrightarrow{R_{\mathfrak{C}_2\leftarrow\mathfrak{C}_1}}\Theta\left(T^{1/2}X^{\mathsf{A}}\right)\otimes\mathscr{U},$$

restricted to Kähler variables of X. Here

$$\delta \operatorname{ind} = \operatorname{ind}_2 - \operatorname{ind}_1$$

where ind<sub>1</sub> and ind<sub>2</sub> are the attracting parts of the polarization according to the  $\mathfrak{C}_1$  and  $\mathfrak{C}_2$ , respectively.

#### 5.1.2

Suppose  $\mathfrak{C}_1$  and  $\mathfrak{C}_2$  are separated by a wall, that is, share a codimension one subcone  $\mathfrak{C}'$ . Using the notations of Section 3.6.1, we write  $X' = X^{\mathsf{A}'}$  and note that the decomposition

$$N_{X/X^{\mathsf{A}}} = N_{X/X'} \oplus N_{X'/X^{\mathsf{A}}}$$

of normal bundles separates the weights into those that have the same (respectively, opposite) sign with respect to  $\mathfrak{C}_1$  and  $\mathfrak{C}_2$ . Let

$$R_{\text{wall}} = R_{\mathfrak{C}_2/\mathfrak{C}' \leftarrow \mathfrak{C}_1/\mathfrak{C}'}$$

be the R-matrix for X'. Proposition 3.3 implies

<span id="page-40-1"></span>
$$R_{\mathfrak{C}_2 \leftarrow \mathfrak{C}_1}(z) = R_{\text{wall}}(z - \hbar \det \operatorname{ind}_{X',\mathfrak{C}'}),$$
 (80)

where

$$\operatorname{ind}_{X',\mathfrak{C}'} = \left(T^{1/2}X\big|_{X'}\right)_{\geq_{\mathfrak{C}'^0}}.$$

#### 5.1.3

If  $\mathfrak{C}_{n+1} = \mathfrak{C}_1$  then evidently

<span id="page-40-2"></span>
$$R_{\mathfrak{C}_{n+1} \leftarrow \mathfrak{C}_n} \cdot \dots \cdot R_{\mathfrak{C}_3 \leftarrow \mathfrak{C}_2} R_{\mathfrak{C}_2 \leftarrow \mathfrak{C}_1} = 1, \tag{81}$$

which written in terms of (80) is a form of Coxeter relation for the wall R-matrices.

For example, for n=2 we get the unitarity relation

$$R_{21}(a^{-1}) R(a) = 1$$

satisfied by wall R-matrices, where  $a \in E = \mathscr{E}_{\mathsf{A}}$  is the equivariant parameter. An example of a braid relation is the dynamical Yang-Baxter equation for tensor products of Nakajima varieties.

## <span id="page-40-0"></span>5.2 Tensor products of Nakajima varieties

#### 5.2.1

The setup is the same as in 4.1.5 of [49]. A very special, but very important special case of the above construction is

$$A \subset G_W$$
,  $G_W = \prod GL(W_i)$ ,

where  $W_i$  are the framing spaces of a Nakajima variety X. The fixed points  $X^A$  in this case are products of smaller Nakajima varieties associated to the same quiver.

#### 5.2.2

Concretely, let  $a \in A \cong \mathbb{C}^{\times}$  act on the framing spaces with the character

$$W_i = a W_i' + W_i''.$$

Over the fixed loci the tautological bundles  $\mathcal{V}_i$  split

$$\mathscr{V}_i = a\mathscr{V}_i' + \mathscr{V}_i''$$

and the components of the fixed loci are parametrized by the corresponding splitting v = v' + v'' of the dimension vector.

### <span id="page-41-2"></span>5.2.3

Choosing a polarization of the Nakajima variety requires a choice of the orientation of the quiver. Let Q be the adjacency matrix of the oriented quiver. We take

$$T^{1/2}X = \sum_{i} \operatorname{Hom}(W_i, \mathscr{V}_i) + \sum_{i,j} (\mathsf{Q}_{ij} - \delta_{ij}) \operatorname{Hom}(\mathscr{V}_i, \mathscr{V}_j).$$

In principle, since T acts on the multiplicity spaces, the matrix  $Q_{ij}$  takes values in  $K_T(pt)$ . By our assumption, A acts only on the framing spaces and hence

$$\operatorname{ind} X^{\mathsf{A}} = \sum_{i} \operatorname{Hom}(W_i'', \mathscr{V}_i') + \sum_{i,j} (\mathsf{Q}_{ij} - \delta_{ij}) \operatorname{Hom}(\mathscr{V}_i'', \mathscr{V}_j'),$$

assuming that a is an attracting weight.

#### 5.2.4

In particular,

<span id="page-41-0"></span>
$$c_1(\det \operatorname{ind}) = \langle w'' + (\mathsf{Q}^t - 1) \cdot v'', c_1(\mathscr{V}') \rangle + \langle (1 - \mathsf{Q}) \cdot v', c_1(\mathscr{V}'') \rangle . \tag{82}$$

where

$$c_1(\mathscr{V}) = (c_1(\mathscr{V}_1), c_1(\mathscr{V}_2), \dots)$$

is a vector of generators of  $\operatorname{Pic}(X)$  and  $\langle \cdot, \cdot \rangle$  is the coordinate pairing. We identify  $\operatorname{Pic}(X)$  with the coordinate lattice accordingly.

#### 5.2.5

Now suppose  $\mathsf{A} \cong (\mathbb{C}^{\times})^3$  acts on W so that

<span id="page-41-1"></span>
$$W_i = a_1 W_i^{(1)} + a_2 W_i^{(2)} + a_3 W_i^{(3)}$$
(83)

and that the weights  $a_1/a_2$  and  $a_2/a_3$  are attracting for  $\mathfrak{C}$ . In this case, there is a total of 6 chambers, and going around them as in (81) using (80) and (82) we get the dynamical Yang-Baxter equation.

To write it more concisely, introduce the Cartan matrix

$$C = 2 - Q - Q^t$$
.

and write  $\mu = w - \mathsf{C} \cdot v$ . With dynamical variables written additively, the dynamical Yang-Baxter equation for the matrix

$$R(z) = R_{\text{wall}}(z + \hbar(1 - Q)v)$$

reads as follows.

**Proposition 5.1.** The matrix R(z) satisfies the equation (dynamical parameters written additively):

$$\mathsf{R}_{12}(z)\,\mathsf{R}_{13}(z-\hbar\,\mu^{(2)})\,\mathsf{R}_{23}(z) = \\ = \mathsf{R}_{23}(z-\hbar\,\mu^{(1)})\,\mathsf{R}_{13}(z)\,\mathsf{R}_{12}(z-\hbar\,\mu^{(3)})\,. \tag{84}$$

*Proof.* For A as in (83), there are two ways to cross from the chamber

<span id="page-42-0"></span>
$$\mathfrak{C}_{123} = \{a_1 > a_2 > a_3\}$$

to the opposite chamber  $\mathfrak{C}_{321}$ . Consider the one that goes through  $\mathfrak{C}_{132}$  and  $\mathfrak{C}_{312}$ , that is, crosses the walls  $a_2 = a_3$ ,  $a_1 = a_3$ , and  $a_1 = a_2$  in this order.

On the wall  $a_2 = a_3$ , we have, in the notation of Section 5.2.3,

$$W' = W_1, \quad W'' = W_2 + W_3,$$

and similarly for  $\mathcal{V}'$  and  $\mathcal{V}''$  and the Kähler variables z of the matrix (80) correspond to the bundles  $\mathcal{V}''$ . Therefore, from (82) we have

$$R_{\mathfrak{C}_{132} \leftarrow \mathfrak{C}_{123}}(z) = R_{\text{wall}}(z - \hbar(1 - Q)\mathbf{v}_1).$$

On the next wall  $a_1 = a_3$ , we have

$$W' = W_1 + W_3$$
,  $W'' = W_2$ , etc.,

while the Kähler variables correspond to  $\mathscr{V}'$ . Therefore

$$R_{\mathfrak{C}_{312} \leftarrow \mathfrak{C}_{132}}(z) = R_{\text{wall}}(z - \hbar(w_2 + (Q^t - 1)\mathbf{v}_2))$$
  
=  $R_{\text{wall}}(z - \hbar\mu^{(2)} - \hbar(1 - Q)\mathbf{v}_2)$ .

Similarly,

$$R_{\mathfrak{C}_{321} \leftarrow \mathfrak{C}_{312}}(z) = R_{\text{wall}}(z - \hbar(1 - Q)\mathbf{v}_3)$$

and so

$$R_{\mathfrak{C}_{321} \leftarrow \mathfrak{C}_{312}} R_{\mathfrak{C}_{312} \leftarrow \mathfrak{C}_{132}} R_{\mathfrak{C}_{132} \leftarrow \mathfrak{C}_{123}} \Big|_{z \mapsto z + \hbar(1 - Q)(\mathbf{v}_1 + \mathbf{v}_2 + \mathbf{v}_3)} = \\ \mathsf{R}_{12}(z) \, \mathsf{R}_{13}(z - \hbar \, \mu^{(2)}) \, \mathsf{R}_{23}(z) \, .$$

Doing the same computation for the other way to cross gives the equation stated.  $\Box$ 

#### 5.2.6 Example: $\mathfrak{sl}_2$

For the  $A_1$  quiver we have

$$Q = (0), C = (2).$$

The tensor product  $\mathbb{C}^2(a_1) \otimes \mathbb{C}^2(a_2)$  is identified with the cohomology of the w = 2 Nakajima varieties

$$X = \operatorname{pt} \ \sqcup \ T^* \mathbb{P}^1 \ \sqcup \ \operatorname{pt} .$$

The nontrivial  $2 \times 2$  block of this matrix is readily computed using the results of Section 3.4. For comparison with that section, one should substitute the representation (47) by the  $GL(W) \times GL(1)$  module

$$\operatorname{Hom}(W,V) = W^{\vee} \otimes \operatorname{defining} \mathbb{C},$$

which in practical terms means inverting the equivariant parameters for  $A \subset GL(W)$ . With this, one computes the nontrivial  $2 \times 2$  block of the R-matrix as follows:

$$R = \begin{pmatrix} \vartheta(u) & \frac{\vartheta(\hbar)\,\vartheta(zu)}{\vartheta(z)} \\ & \vartheta(\hbar/u) \end{pmatrix}^{-1} \begin{pmatrix} \vartheta(u\hbar) \\ \frac{\vartheta(\hbar)\,\vartheta(z/u)}{\vartheta(z)} & \vartheta(1/u) \end{pmatrix}$$
$$= \frac{1}{\vartheta(u/\hbar)} \begin{pmatrix} \frac{\vartheta(z\hbar)\,\vartheta(z/\hbar)\vartheta(u)}{\vartheta(z)^2} & -\frac{\vartheta(\hbar)\vartheta(zu)}{\vartheta(z)} \\ -\frac{\vartheta(\hbar)\vartheta(z/u)}{\vartheta(z)} & \vartheta(u) \end{pmatrix}$$
(85)

where  $u = a_1/a_2 \in \text{char}(A)$  and the top left matrix element is simplified using

$$\vartheta(A+B) \vartheta(A-B) \vartheta(C)^2 + \text{cyclic} = 0$$

with  $(A, B, C) = (z, u, \hbar)$ .

This differs by a gauge transformation from Felder's R-matrix [24] which reads, in current notation,

$$\mathsf{R}_{\mathrm{standard}} = \frac{1}{\vartheta(\hbar/u)\vartheta(z)} \begin{pmatrix} \vartheta(z\hbar)\vartheta(1/u) & \vartheta(zu)\vartheta(\hbar) \\ \vartheta(z/u)\vartheta(\hbar) & \vartheta(\hbar/z)\vartheta(u) \end{pmatrix} \,.$$

Recall that gauge transformations of the form

$$\begin{pmatrix} * & * \\ * & * \end{pmatrix} \mapsto \begin{pmatrix} f(z)* & * \\ * & f(z)^{-1}* \end{pmatrix},$$

where f(z) is arbitrary, preserve solutions of (84).

### 5.2.7

Similarly, the tensor square of the defining representation of  $\mathfrak{gl}_n$  is geometrically realized in a union of points and  $T^*\mathbb{P}^1$ , thus recovering the basic elliptic solution of the dynamical Yang-Baxter equation.

# <span id="page-44-0"></span>6 Difference equations

## <span id="page-44-1"></span>6.1 Vertex functions

## 6.1.1

Elliptic stable envelopes may be used to determine the monodromy of certain difference equations that play a key role in K-theoretic counting of rational curves in a Nakajima variety, see [\[57\]](#page-66-7).

In the precise technical sense, this counting refers to computation in K-theory of the moduli spaces of quasimaps from P 1 to X. This is closely related to computations in 3 dimensional supersymmetric gauge theories, with N = 4 supersymmetry, on real threefolds of the form

Disk 
$$\times S^1$$
.

Nakajima varieties appear in this context as Higgs branches of the moduli spaces of supersymmetric vacua.

In spirit, such curve counting is not far from the subject of quantum K-theory, which is defined by K-theoretic computation on the moduli spaces M0,n(X) and M0,n(X × P 1 ) of stable pointed rational maps to respective targets. Givental and his collaborators studied difference equations in quantum K-theory [\[34,](#page-65-14)[35\]](#page-65-15), and their theory is very general — X can be an arbitrary nonsingular algebraic variety, or even an orbifold, as long as rational curves in X satisfy certain properness assumptions.[5](#page-44-2)

By contrast, the development of the theory explained in [\[57\]](#page-66-7) crucially uses certain specific features of Nakajima varieties and of moduli spaces of quasimaps in order to get a better control over the difference equations. Eventually, this allows for an explicit identification of difference equations in terms of a geometric action of a certain quantum group on K(X), see [\[59\]](#page-66-9).

### 6.1.2

In this paper, we unwrap the complexities of K-theoretic curve counting only to the extent required to state and prove our results. We denote by

$$\mathsf{QM}(X) = \{ \mathrm{stable} \ f : \mathbb{P}^1 \dashrightarrow X \} \big/ \cong$$

the moduli space of stable quasimaps to X as defined in [\[17\]](#page-64-12). This is a countable union of algebraic varieties indexed by

$$\deg f \in H_2(X,\mathbb{Z})_{\text{effective}}$$
.

The standard action of C <sup>×</sup> on P <sup>1</sup> with

$$\left(\mathbb{P}^1\right)^{\mathbb{C}^\times} = \{0, \infty\}$$

induces an action of C <sup>×</sup> on QM(X). We denote by q the weight of T0P <sup>1</sup> and denote this C × by C × q in what follows.

<span id="page-44-2"></span><sup>5</sup>Difference equations arising from supersymmetric gauge theories are actively studied by physicists, see for example [\[29\]](#page-65-16).

#### 6.1.3

We denote by

$$\mathsf{QM}(X)_{\mathrm{nonsing at} \infty} \subset \mathsf{QM}(X)$$

the open set formed by quasimaps nonsingular at  $\infty \in \mathbb{P}^1$ . Evaluation at this nonsingular point gives a map

$$\operatorname{ev}: \mathsf{QM}(X)_{\operatorname{nonsing at} \infty} \to X$$
.

This map is not proper, but its restriction to the  $\mathbb{C}_q^{\times}$ -fixed locus is proper.

#### 6.1.4

The vertex function is a multivariate formal power series

$$\mathbf{V} \in (K(X) \otimes \mathbb{C}[\mathbb{C}_q^\times])_{\mathrm{localized}}[[z]]$$

defined by

$$\mathbf{V} = \mathrm{ev}_* \left( \mathrm{symmetrized\ virtual\ structure\ sheaf} \,\cdot\, z^{\mathrm{deg}} \right),$$

where the pushforward is defined using  $\mathbb{C}_q^{\times}$ -localization and  $z^{\text{deg}}$  is an element of the semi-group algebra of  $H_2(X,\mathbb{Z})_{\text{effective}}$ .

#### 6.1.5

To talk about difference equations, we need to introduce two transcendental functions. The first function is related to the operators

$$\ln \left( \mathscr{L} \otimes - \right) \in \operatorname{End} K_{\mathsf{T}}(X)_{\operatorname{localized}} \otimes \left( \operatorname{Lie} \mathsf{T} \right)^* \,.$$

Localization and extension of scalars is needed because:

- generalized eigenspaces of  $\mathcal{L} \otimes$  are  $K(F_i)$ , where  $F_i$  are the components of the fixed point locus  $X^{\mathsf{T}}$ ,
- the eigenvalues are the weights of  $\mathscr{L}|_{F_i}$ ,
- the logarithms of the eigenvalues lie in  $(\text{Lie}\,\mathsf{T})^*$ .

We define the map

$$\lambda: H^2(X, \mathbb{C}) \otimes \operatorname{Lie} \mathsf{T} \to \operatorname{End} K(X^\mathsf{T}) \otimes \mathbb{C}$$

which extends the map

$$\mathscr{L} \mapsto \ln(\mathscr{L} \otimes -)$$

by linearity to  $H^2(X,\mathbb{C}) = \operatorname{Pic}(X) \otimes_{\mathbb{Z}} \mathbb{C}$ . This is a close relative of the maps from Section 2.7.1 and the function

$$\mathbf{e}(z) = \exp\left(\frac{\lambda(\ln z, \ln t)}{\ln q}\right)$$

is a section of  $\mathcal{U}^{-1}$ .

#### 6.1.6

The other transcendental function we need is related to reciprocal

$$\phi(x) = \prod_{i>0} (1 - q^i x)$$

of the q-Gamma function, also known under various other names such "quantum dilogarithm". It is a half of the theta-function in the sense that

$$\vartheta(x) = (x^{1/2} - x^{-1/2}) \,\phi(qx) \,\phi(q/x) \,. \tag{86}$$

Given  $\mathscr{G} \in K(X)$  we define

$$\Phi(\mathscr{G}) = \prod \phi(\gamma_i) \in K(X)[[q]]$$

where  $\gamma_i$  are the Chern roots of  $\mathscr{G}$ .

#### 6.1.7

We have the following

<span id="page-46-0"></span>**Theorem 4** ([57, 59]). The  $K(X^{\mathsf{T}})$ -valued function

<span id="page-46-1"></span>
$$\widetilde{\mathbf{V}} = \mathbf{e}(z_{\#}) \,\Phi((q - \hbar) T^{1/2}) \,\mathbf{V} \tag{87}$$

where

<span id="page-46-3"></span>
$$z_{\#} = z(-\hbar^{1/2})^{-\det T^{1/2}} \tag{88}$$

generates a holonomic module of rank  $\operatorname{rk} K(X)$  under the action of q-difference operators in both Kähler and equivariant variables  $a \in A$ . This q-difference module has regular singularities in z and a separately.

The part about regular singularities in A is shown in [57], regular singularities in z follow from [59]. The existence of *some* difference equation in z should be also a corollary of Givental's theory. The main point of [59] is a specific representation-theoretic identification of a difference connection in the Kähler variables. Since (87) has a prefactor of the very shape discussed in Section 1.2.2, the equation for  $\tilde{\mathbf{V}}$  will not be regular jointly in z and a.

If dim  $X^{\mathsf{T}} > 0$ , the subbundle of invariants

$$I = \left( \hbar T^{1/2} \big|_{X^{\mathsf{T}}} \right)^{\mathsf{T}}$$

may be nontrivial. The corresponding term

<span id="page-46-2"></span>
$$\Phi(-I) = \Phi(-qI) \prod_{\text{Chern roots } \gamma_i} \frac{1}{1 - \gamma_i}$$
(89)

in the prefactor of (87) is independent of any equivariant or Kähler variables and thus, from the point of difference equations, can be simply dropped. It is convenient, however, to keep it and interpret the singular part in (89) as a section of an analog of Thom bundle  $\Theta(-I)$  in K-theory.

## <span id="page-47-0"></span>**6.2** Example: quasimaps to $T^*\mathbb{P}(W)$

We compute the vertex functions in the simplest example, using notations of Section 3.4.

#### 6.2.1

In brief, quasimaps to a quotient are sections of a bundle of prequotients, up to isomorphism, that is,

$$\mathsf{QM}\left(\mathbb{P}^1 \dashrightarrow Y/G\right) = \left\{\mathbb{P}^1 \to Y \times_G \mathscr{P}\right\}_{\mathsf{stable}} / \cong$$

where  $\mathscr{P}$  is a principal G-bundle over  $\mathbb{P}^1$ . In particular, a principal GL(1)-bundle over  $\mathbb{P}^1$  is the same as a line bundle  $\mathscr{L} \cong \mathscr{O}(d)$  where  $d = \deg \mathscr{L}$ . We define

$$\widetilde{\mathscr{M}} = W \otimes \mathscr{L}$$
,

and study sections

$$(v,\xi) \in H^0(\mathbb{P}^1, \widetilde{\mathscr{M}} \oplus \hbar^{-1} \widetilde{\mathscr{M}}^*)$$

satisfying  $\langle \xi, v \rangle = 0$ , modulo  $\operatorname{Aut}(\mathscr{L}) = \mathbb{C}^{\times}$ . The twist by  $\hbar$  here is to record the equivariance with respect to the group

$$GL(W) \times \mathbb{C}_{\hbar}^{\times} \times \mathbb{C}_{q}^{\times}$$

where  $\mathbb{C}_q^{\times}$  acts by automorphisms of the domain  $\mathbb{P}^1$ .

#### 6.2.2

If v is a nowhere vanishing section, then  $(v,\xi)$  defines a map  $f:\mathbb{P}^1\to X$  of degree  $d=\deg\mathscr{L}$  such that

<span id="page-47-1"></span>
$$\widetilde{\mathscr{M}} = f^* \mathscr{M}$$
,

where  $\mathcal{M}$  is the bundle on X from Section 3.4.2. Quasimaps relax this condition on v by allowing v to be nonzero as a section. This is the stability condition. The points  $p \in \mathbb{P}^1$  where v(p) = 0 are called the singularities of the quasimap. At all nonsingular points, a quasimap has a well-defined value in X.

#### 6.2.3

The moduli space of quasimaps has a perfect obstruction theory with

$$T_{\text{vir}} = \text{Deformations} - \text{Obstructions}$$
  
=  $H^{\bullet}(\widetilde{\mathcal{M}} + \hbar^{-1}\widetilde{\mathcal{M}}^* - (1 + \hbar^{-1}) \text{ End } \mathcal{L}),$  (90)

where the term with End  $\mathscr{L}$  accounts for deformation theory of  $\mathscr{L}$  and the moment map equation  $\langle \xi, v \rangle = 0$ . Of course, for a line bundle, End  $\mathscr{L}$  is canonically trivial, but in the case of GL(k)-quotients this term will be replaced by the endomorphisms of a rank k vector bundle — a nontrivial bundle of rank  $k^2$ .

#### 6.2.4

Quasimaps fixed under  $A \times \mathbb{C}_q^{\times}$ , where

$$A = \{ \operatorname{diag}(a_1, a_2, \dots) \} \subset GL(W),$$

are the following. Let  $F_k = \mathbb{C}e_k \subset \mathbb{P}(W)$  be a fixed point in X. We take

$$\mathscr{L} = a_k^{-1} \otimes \mathscr{O}_{\mathbb{P}^1}(d[0])$$

that is, the sheaf of functions with pole of order  $\leq d$  at  $0 \in \mathbb{P}^1$ , twisted by a character  $a_k^{-1}$  of A. This twisting is because A-fixed point on a quotient by  $\operatorname{Aut}(\mathscr{L})$  defines a map  $\mathsf{A} \to \operatorname{Aut}(\mathscr{L})$ . The fixed quasimap is the unique  $\mathsf{A} \times \mathbb{C}_q^{\times}$ -equivariant inclusion

$$f: \mathscr{O} \hookrightarrow \mathscr{O}(d[0]) \hookrightarrow W \otimes \mathscr{L}$$
.

It is singular at  $0 \in \mathbb{P}^1$  and evaluates to  $F_k$  under  $\operatorname{ev}_{\infty}$ . The virtual tangent space at this point is easily computed from (90). The result is that the virtual tangent space, minus  $\operatorname{ev}^* TX$ , equals

$$T_{\text{vir}}(f) - T_{F_k}X =$$

$$= (q + \dots + q^d) \sum_{i} \frac{a_i}{a_k} - \hbar^{-1}(1 + q^{-1} + \dots + q^{1-d}) \sum_{i} \frac{a_k}{a_i}.$$
 (91)

#### 6.2.5

The symmetrized virtual structure sheaf is defined by

$$\widehat{\mathcal{O}}_{\text{vir}} = \mathscr{O}_{\text{vir}} \otimes \left( \mathscr{K}_{\text{vir}} \frac{\det \mathscr{T}^{1/2} \Big|_{\infty}}{\det \mathscr{T}^{1/2} \Big|_{0}} \right)^{1/2} 
= q^{-\frac{1}{2} \deg \mathscr{T}^{1/2}} \mathscr{O}_{\text{vir}} \otimes \mathscr{K}_{\text{vir}}^{1/2},$$
(92)

see [57], where  $\mathcal{T}^{1/2}$  is the bundle of polarizations. It will be convenient to choose the polarization *opposite* to the polarization in (48). This gives

<span id="page-48-0"></span>
$$\deg \mathscr{T}^{1/2} = -nd\,, \quad n = \dim W\,,$$

and

$$z_{\#} = z(-\hbar^{1/2})^{-\det T^{1/2}} = (-1)^n \, \hbar^{n/2} \, z$$
.

To save on constant factors, we forget the contribution of  $\mathcal{K}_X = \hbar^{1-n}$ . With this convention, the vertex function is the hypergeometric function

$$\mathbf{V} \big|_{F_k} = \sum_{d \ge 0} z^d \left( -\frac{q}{\hbar^{1/2}} \right)^{dn} \prod_i \frac{(\hbar a_i / a_k)_d}{(q a_i / a_k)_d}$$

$$= \mathbf{F} \begin{bmatrix} \hbar a_1 / a_k, & \hbar a_2 / a_k, & \dots \\ q a_1 / a_k, & q a_2 / a_k, & \dots \end{bmatrix} \left( \frac{q}{\hbar} \right)^n z_\# \right] . \tag{93}$$

The notation inside F refers to numerators and denominators in a hypergeometric series. Readers not familiar with these conventions may treat the second line in (93) as the definition of F. Further

<span id="page-49-0"></span>
$$\widetilde{\mathbf{V}}\big|_{F_k} = e^{-\frac{\ln z_\# \ln a_k}{\ln q}} \prod_{i \neq k} \frac{\phi(q\hbar^{-1}a_k/a_i)}{\phi(a_k/a_i)} \mathsf{F}\left[\frac{\hbar a_i/a_k}{qa_i/a_k} \middle| \left(\frac{q}{\hbar}\right)^n z_\#\right], \tag{94}$$

because the weight of  $\mathcal{O}(1)$  on the kth fixed point is  $a_k^{-1}$ .

#### 6.2.6

To see directly that the function (94) satisfies a difference equation in all variables, we can write it as follows

<span id="page-49-1"></span>
$$\widetilde{\mathbf{V}} \Big|_{F_k} = \frac{1}{2\pi i} \int \frac{ds}{s} e^{\frac{\ln z_\# \ln s}{\ln q}} \Phi'((q - \hbar) \text{ Polarization}), \tag{95}$$

where

<span id="page-49-3"></span>Polarization = 
$$-\frac{1}{\hbar} + \sum_{i} \frac{1}{\hbar a_i s}$$
, (96)

the contour of integration enclosed the poles

$$s = \frac{q^d}{a_k}, \quad q = 0, 1, 2, \dots,$$

and prime in (95) means we drop the zero factor, that is, we define

$$\Phi'(1) = \phi(q) .$$

The integrand in (95) obviously satisfies difference equations in s and  $a_i$ . The integration as in (95) acts by Fourier transforms on difference equations, whence the conclusion.

Integral representations of vertex functions, of the form (95), are commonplace in the literature on supersymmetric gauge theories. They may be interpreted using heuristic presentation

<span id="page-49-2"></span>
$$QM(X)_{\text{ns at }\infty} \approx QM(T^*M)_{\text{ns at }\infty} /\!\!/\!\!/ \text{gauge transformations}$$
 (97)

of quasimaps to an algebraic symplectic reduction  $X = T^*M/\!\!/\!\!/\!/ G$ , as in (57). The formula (97) lands on the solid ground of algebraic geometry once one takes fixed points of the  $\mathbb{C}_q^{\times}$ -action and this enough to produce integral representations, see the Appendix in [1].

While hypergeometric functions such as those in (93) are well known to have both the series and integral representations, the underlying physics is interesting. The function  $\tilde{\mathbf{V}}$  computes the partition function of the 3d gauge theory whose Higgs branch is X. The series representation of  $\tilde{\mathbf{V}}$ , in terms of summing up quasi maps to X, arises when one computes the partition function as a sum over vortex instanton contributions, on the Higgs branch.

The same partition function has an integral representation tied to the Coulomb branch of the 3d gauge theory instead (the Chern roots of vector bundles one ends up integrating over are related to the Coulomb moduli). The later is much simpler in physics terms, since it is a result of a one loop computation.<sup>6</sup>

## <span id="page-50-0"></span>6.3 Pole subtraction and monodromy

#### 6.3.1

As already stressed in Section 1.2.2, the difference equations satisfied by the vertex functions (87) have regular singularities in Kähler variables and, separately, in equivariant variables  $a \in A$ .

The solutions  $\tilde{\mathbf{V}}$  favor Kähler variables – they are given by a convergent power series in z and are therefore holomorphic in some punctured neighborhood of the point z=0. Here and below, we allow functions not to be single-valued in this punctured neighborhood, as their monodromy around the origin is an integral part of the story.

Instead of solutions holomorphic in  $z \to 0$ , one can fix a point  $0 = 0_{\mathfrak{C}} \in \overline{\mathsf{A}}$  as in (35) and ask for a basis  $\mathbf{V}_{\mathfrak{C}}$  of solutions holomorphic as  $a \to 0$ . We call the transition matrix  $\mathfrak{P}$  between these two bases of solutions the *pole subtraction matrix*.

Evidently, matrix elements of  $\mathfrak{P}$  are sections of certain line bundles on  $\mathscr{E}_{\text{Pic}(X)} \times \mathscr{E}_{\mathsf{A}}$  as functions of z and a invariant under  $q^{\text{Pic}(X) \oplus \text{cochar A}}$ , whose transformation under

$$2\pi i(\operatorname{Pic}(X) \oplus \operatorname{cochar} \mathsf{A}) \hookrightarrow H^2(X,\mathbb{C}) \oplus \operatorname{Lie} \mathsf{A} \ni (\ln z, \ln a)$$

is dictated by the exponential in (87).

#### 6.3.2

A choice of  $\mathfrak{C}$  defines a partial order of the components  $F_i$  of  $X^{\mathsf{T}}$ , called the *ample* partial order in [49]. This order is by the order of vanishing of the A-weight of an ample bundle as  $a \to 0$ . The order is coarser than the order from Section 3.1.2.

<span id="page-50-2"></span>**Proposition 6.1.** The matrix  $\mathfrak{P}$  is block-triangular with respect to the ordering of components of  $X^{\mathsf{T}}$  which is <u>opposite</u> to ample.

*Proof.* With the exception of the exponential prefactor, all terms in (87) grow at most polynomially as  $(z, a) \to (0, 0)$ . Indeed, for instance

<span id="page-50-3"></span>
$$\frac{\phi(b/a)}{\phi(c/a)} \sim \text{const } a^{\log_q(b/c)}$$
 (98)

along any geometric progression of the form  $a = q^n x$ ,  $x \neq q^n c$ , because of the difference equation that this function satisfies.

<span id="page-50-1"></span><sup>&</sup>lt;sup>6</sup>See [5] for a fairly accessible review, [6] for more details. See also [69] for an early manifestation of the same phenomenon.

The exponential prefactor thus determines the rate of growth of the solution as  $(z, a) \rightarrow (0, 0)$  and it filters the space of solutions by subspaces where this rate of growth is bounded above. This means bounds from above on the A-weight of an ample bundle, whence the conclusion.

#### 6.3.3

The matrix  $\mathfrak{P}$  may, in principle, be computed algorithmically as follows. We first transform the basis  $\widetilde{\mathbf{V}}$  into a basis of solutions which has no poles in the  $\Phi$ -prefactor and for which the pole subtraction matrix may be chosen unitriangular with respect to the ordering in Proposition 6.1.

This first step is accomplished by exchanging the terms

$$\frac{\phi(q\hbar^{-1}a^{-1})}{\phi(a^{-1})} \longleftrightarrow \frac{\phi(qa)}{\phi(\hbar a)} a^{1-\log_q \hbar}$$

which solve the same difference equation in a. This exchange may be interpreted as switching between a and the opposite weight  $\hbar^{-1}a^{-1}$  in a polarization.

On the next step, one considers the poles in the series in (87) at divisors of the form  $w = q^n$ , where w is a weight of T, positive on  $\mathfrak{C}$  and  $n \gg 0$ . One observes that such poles occur only in terms of degree  $\geq d(n)$ , where d(n) grows linearly with n. The singular terms in the  $w \to q^n$  expansion solve the same q-difference equation in z, specialized at  $w = q^n$ . However, their order of vanishing as  $z \to 0$  is higher by at least d(n). Therefore, they are linear combinations of slower growing solutions and adding a suitable linear combination of slower growing solutions makes the given solution pole-free at  $w = q^n$ ,  $n \gg 0$ . The matrix coefficients of  $\mathfrak{P}$  are thus determined as the unique section of a certain line nontrivial line bundle on  $\mathscr{E}_A$  with prescribed singularities.

#### 6.3.4

The main point of this Section is that elliptic stable envelopes give the pole subtraction matrix  $\mathfrak{P}$ . To put elliptic cohomology and K-theory on the same footing, we will work in analytic completion of K-theory, that is, with analytic functions on

$$\mathfrak{K}_T(X) = \operatorname{Spec} K_{\mathsf{T}}(X) \otimes \mathbb{C}$$
.

Localization introduces meromorphic functions with poles in specified locations.

For consistency with elliptic cohomology, we think of pushforward under  $f: X \to Y$  as

$$f_*: \operatorname{Thom}(-N_f) \to \mathscr{O}_{\mathfrak{K}(Y)}$$

even though in K-theory we have Thom isomorphism  $\operatorname{Thom}(-N_f) \cong \mathscr{O}_{\mathfrak{K}(X)}$ . Then, in particular, the transpose of a map g in K-theory acquires an additional twist by the Thom class of the tangent bundle, as in Section 3.7.

The transpose in K theory and elliptic cohomology are related by

$$g^{\text{transpose,K}} = \boldsymbol{\varphi}^{-1} g^{\vee} \boldsymbol{\varphi}$$

where  $g^{\vee}$  is the elliptic transpose as in Section 3.7 and

$$\varphi = \mathscr{K}_X^{1/2} \Phi(q(TX + T^{\vee}X)). \tag{99}$$

#### 6.3.5

Define

$$\operatorname{Stab}^{\#} = \left(\operatorname{Stab}_{-\mathfrak{C},T^{1/2}}(z_{\#}^{-1})\right)^{\operatorname{transpose},K} \tag{100}$$

<span id="page-52-2"></span>
$$= \boldsymbol{\varphi}^{-1} \operatorname{Stab}_{\mathfrak{C}, T_{\operatorname{opp}}^{1/2}} (z_{\#})^{-1} \boldsymbol{\varphi}$$
 (101)

where  $\mathfrak{C}$  is the cone corresponding to the point  $0 = 0_{\mathfrak{C}} \in \overline{\mathsf{A}}$  at which we subtract the poles, and  $z_{\#}$  was defined in (88). The equality in (101) is the content of Proposition 3.4.

We define

<span id="page-52-1"></span>
$$z_{\#,\mathfrak{C}} = z_{\#} \, \hbar^{\det T_{<0}^{1/2}} \,,$$
 (102)

where  $T_{<0}^{1/2}$  stands for the repelling part of the polarization with respect to the cone  $\mathfrak{C}$ . The difference with standard shift by  $\hbar^{\text{ind}} = \hbar^{\det T_{>0}^{1/2}}$  from the earlier sections is due to the appearance of the opposite cone in (100), or the opposite polarization in (101).

From the definition of elliptic stable envelopes the operator

<span id="page-52-3"></span>
$$\mathfrak{P}_{\mathfrak{C}} = \mathbf{e}(z_{\#,\mathfrak{C}}) \,\Theta(T^{1/2}X^{\mathsf{A}}) \,\operatorname{Stab}^{\#} \,\Theta(T^{1/2})^{-1} \,\mathbf{e}(z_{\#})^{-1} \tag{103}$$

commutes with shifts of both z and a. Here  $T^{1/2}X^{\mathsf{A}}$  is the polarization of  $X^{\mathsf{A}}$  induced by  $T^{1/2}$ . The term  $\Theta(T^{1/2}X^{\mathsf{A}})$  is independent of the variables in  $\mathsf{A}$  and is inserted here only for the event that a larger torus is acting preserving the symplectic form.

As we will see, the operator (103) subtracts the poles as follows

#### <span id="page-52-0"></span>Theorem 5. The function

<span id="page-52-4"></span>
$$\mathbf{V}_{\mathfrak{C}} = \mathfrak{P}_{\mathfrak{C}} \ \widetilde{\mathbf{V}} \tag{104}$$

solves the same scalar difference equations as (87) and is holomorphic in a punctured neighborhood of  $0_{\mathfrak{C}} \in \overline{A}$ . Equivalently, the function

<span id="page-52-5"></span>
$$Stab^{\#} \frac{(\det T^{1/2})^{-1/2}}{\Phi(T^{\vee})} \mathbf{V}$$
 (105)

has no poles in a as  $a \to 0_{\mathfrak{C}}$ . The exact same pole cancellation property is true for vertex functions with <u>descendents</u>.

The proof of Theorem 5 will be given in Section 6.4. For a discussion of vertex functions with descendents, see [57].

The equivalence of pole cancellation in (104) and (105) follows from

<span id="page-52-6"></span>
$$\frac{\Phi((q-\hbar)T^{1/2})}{\Theta(T^{1/2})} = \frac{(\det T^{1/2})^{-1/2}}{\Phi(T^{\vee})}.$$
 (106)

As before, the  $\Phi(T^{\vee})$ -term here is interpreted using

$$\frac{\Phi(qT^{\vee})}{\Phi(T^{\vee})}: \mathscr{O}_{\mathfrak{K}} \xrightarrow{\sim} \operatorname{Thom}(-T).$$

To check the truth of Theorem 5 in the simplest example of  $T^*\mathbb{P}^{n-1}$ , we change the integrand in (95) as in (105), which gives

<span id="page-53-0"></span>
$$\mathbf{V}_{\mathfrak{C}}\big|_{F_k} = \frac{1}{2\pi i} e^{\frac{\boldsymbol{\lambda}(\ln z_{\#,\mathfrak{C}}, \ln t)}{\ln q}} \int_{|s| \approx 1} \frac{ds}{s} \frac{(\det T^{1/2})^{-1/2} \operatorname{Stab}_{\#}}{\Phi'(T^{\vee})}, \tag{107}$$

where

$$T^{1/2} = -\frac{1}{\hbar} + \sum_{i} \frac{1}{\hbar a_{i} s} \,,$$

is the polarization on the prequotient as in (96),

$$\operatorname{Stab}_{\#} = \prod_{i < k} \vartheta(sa_i\hbar) \frac{\vartheta(sz_{\#}^{-1}a_k\hbar^{n-k+1})}{\vartheta(z_{\#}^{-1}\hbar^{n-k+1})} \prod_{i > k} \vartheta(sa_i)$$

is the replacement of (49) for the opposite polarization and the opposite ordering, and the difference between  $\Phi(qT^{\vee})$  and  $\Phi(T^{\vee})$  corresponds to the pushforward  $K_{\mathsf{T}}(X) \to K_{\mathsf{T}}(\mathsf{pt})$ . The contour of integration in (107) is roughly the compact torus in  $\mathbb{C}^{\times}$ , it will be specified precisely in a moment.

Neglecting irrelevant factors, the integrand in (107) simplifies to

Integrand 
$$\propto \prod_{i < k} \frac{\phi(\frac{q}{\hbar} a_i^{-1} s^{-1})}{\phi(a_i^{-1} s^{-1})} \prod_{i > k} s a_i \frac{\phi(q a_i s)}{\phi(\hbar a_i s)} \times$$

$$(s a_k)^{1/2} \frac{\vartheta(s z_{\#}^{-1} a_k \hbar^{n-k+1})}{\vartheta(z_{\#}^{-1} \hbar^{n-k+1})} \frac{1}{\phi(a_k^{-1} s^{-1}) \phi(\hbar a_k s)}, \quad (108)$$

which has poles at

$$s = q^n a_i^{-1}, i \le k, n = 0, 1, \dots (109)$$

$$s = q^{-n}\hbar^{-1}a_i^{-1}, \qquad i \ge k, \quad n = 0, 1, \dots$$
 (110)

The poles in (109) accumulate to s = 0 while the poles in (110) accumulate to  $s = \infty$ . The contour of the integration in (107) separates (109) from (110).

A contour integral becomes singular when the poles on opposite sides of the contour coalesce, which means

<span id="page-53-2"></span><span id="page-53-1"></span>
$$\frac{q^{n_1}}{a_i} = \frac{q^{-n_2}}{\hbar \, a_i} \quad \Rightarrow \quad \frac{a_i}{a_i} = \hbar \, q^{n_1 + n_2} \,,$$

with  $i \leq k \leq j$  and  $n_1, n_2 \geq 0$ . By our conventions  $a \to 0_{\mathfrak{C}}$  means that  $a_i/a_j \to \infty$  for i < j and so the integral is pole-free in this region.

The general statement of Theorem 5 may, in principle, be approached from a similar angle. We will use other, more geometric, tools in what follows.

Theorem 5 determines the monodromy of the difference equations in a and constraints the monodromy of the difference equations in Kähler variables in terms of the analogous monodromy for  $X^{A}$ . The following is immediate

<span id="page-54-1"></span>Corollary 6.2. Let  $V_{\mathfrak{C}_1}$  and  $V_{\mathfrak{C}_2}$  be functions (104) for two different points

$$0_{\mathfrak{C}_1}, 0_{\mathfrak{C}_2} \in \overline{\mathsf{A}}$$

then

$$\mathbf{V}_{\mathfrak{C}_2} = \mathfrak{P}_{\mathfrak{C}_2} \, \mathfrak{P}_{\mathfrak{C}_1}^{-1} \, \, \mathbf{V}_{\mathfrak{C}_1}$$

where the matrices

$$\mathfrak{P}_{\mathfrak{C}_2} \mathfrak{P}_{\mathfrak{C}_1}^{-1} = U_2 \left( R_{\mathfrak{C}_2 \leftarrow \mathfrak{C}_1, T_{\text{opp}}^{1/2}}(z_\#) \right) U_1^{-1}$$
(111)

with  $U_i = \mathbf{e}(z_{\#,\mathfrak{C}_i}) \frac{\Theta(T^{1/2}X^{\mathsf{A}})}{\varphi(X^{\mathsf{A}})}$  are gauge transformations of the elliptic R-matrices from Section 5

#### 6.3.8

Let  $\widetilde{\mathbf{V}}_{X^{\mathsf{A}}}$  denote the function (87) for the A-fixed locus. Note, in particular, that the prefactor in  $\widetilde{\mathbf{V}}_{X^{\mathsf{A}}}$  has the form  $\mathbf{e}(z_{\#,X^{\mathsf{A}}})$  with

$$z_{\#,X^{\mathsf{A}}} = z_{\#}(-\hbar^{1/2})^{\det N^{1/2}},$$
 (112)

where  $N^{1/2}$  is the normal part of the polarization. We have the following

<span id="page-54-0"></span>**Proposition 6.3.** As  $a \to 0_{\mathfrak{C}}$ , we have

<span id="page-54-3"></span>
$$\mathbf{V}_{\mathfrak{C}} \sim \dots \widetilde{\mathbf{V}}_{X^{\mathsf{A}}} \Big|_{z \mapsto z \left(-\hbar^{-1/2}\right)^{\deg N} > 0} \, q^{-\deg T_{<0}^{1/2}} \,, \tag{113}$$

where dots stand for a factor of the form  $\pm \hbar^{k/2}$  which depends on the component of the fixed locus.

In the proof, we will need some generalities about the behavior of the solutions of q-difference equations at a regular singular point.

Let  $f_1(x)$  be analytic in a universal cover of a punctured neighborhood of x = 0 and solve a regular q-difference equation. A scalar equation may be replaced by an equivalent first order vector equation

<span id="page-54-2"></span>
$$f(qx) = M(x)f(x), \quad M(0) \in GL(n, \mathbb{C})$$
(114)

for a vector-valued function, in which  $f_1(x)$  is the first entry. In fact, from both geometric and representation-theoretic viewpoints, it is the matrix equations that arise naturally [57]. We can make a further nonresonance assumption that  $\mu_i/\mu_j \neq q^k$ ,  $k \neq 0$ , where  $\mu_i$  are

the eigenvalues of M(0). This assumption is satisfied in our case. In fact, for the shifts of equivariant variables the operator M(0) is semisimple, with eigenspaces given by

<span id="page-55-0"></span>
$$K_{\mathsf{T}}(X^{\mathsf{A}}) = \bigoplus_{\text{components } F \text{ of } X^{\mathsf{A}}} K_{\mathsf{T}}(F)$$
 (115)

and exponents at  $a \to 0_{\mathfrak{C}}$  are the following

exponents = 
$$\left\{ \left( z_{\#,\mathfrak{C}} q^{-\det T_{<0}^{1/2}} \right)^{\lambda(\cdot,\sigma)} \right\}, \qquad (116)$$

where  $\sigma \in \operatorname{cochar} A$  is the direction of the shift. This is clear from (87) and (98).

With this nonresonance assumption, the solution to (114) has the form exemplified by (87)

$$f(x) = e^{\ln M(0) \frac{\ln x}{\ln q}} \times \text{convergent power series in } x,$$
(117)

see for example [19] for a modern discussion of this classical result. In particular, generalized eigenspaces of M(0), given by (115) in our situation, correspond to generalized eigenspaces of the monodromy around the origin. By construction, the solutions (104) are precisely grouped according to the components of  $X^{A}$ , which gives the following

<span id="page-55-1"></span>**Lemma 6.4.** The function 
$$\mathbf{e}\left(z_{\#,\mathfrak{C}}q^{-\det T_{<0}^{1/2}}\right)^{-1}\mathbf{V}_{\mathfrak{C}}$$
 is analytic in a near  $0_{\mathfrak{C}}$ .

Proof of Proposition 6.3. As explained in the proof of Proposition 6.1, the solutions  $\mathbf{V}_{\mathfrak{C}}$  are linear combinations of solutions with different order of growth as  $(z, a) \to (0, 0)$ . The function in Lemma 6.4 is meromorphic in z, it is therefore uniquely determined by its values for  $|z| < \varepsilon$  for any  $\varepsilon$ . We are free to choose  $\varepsilon$  so small that the diagonal term in stable envelopes dominates the  $a \to 0$  asymptotics.

On the diagonal, we weights along the fixed locus cancel out in the operator (103). For the weights normal to the fixed locus we get, using (106), the following contribution

$$(\det N^{1/2})^{-1/2} \prod_{w \in N_{>0}} \frac{\vartheta(w)}{\phi(w^{-1})\phi(\hbar w)} \sim \hbar^{\cdots} \left( \det T_{<0}^{1/2} \right)^{-1} , \quad a \to 0_{\mathfrak{C}} ,$$

and this is absorbed by the power of a that comes from the q-shift in the  $\mathbf{e}$ -factor in Lemma 6.4

The asymptotics of the vertex function  ${\bf V}$  as  $a\to 0$  is given by Section 7.3 of [57] as follows

$$\mathbf{V} 
ightarrow \cdots \mathbf{V}_{X^{\mathsf{A}}} \left|_{z \mapsto z \left(-\hbar^{-1/2}
ight)^{\deg N} > 0} \, q^{-\deg T^{1/2}_{<0}} 
ight.$$

Since

$$z_{\#,\mathfrak{C}} = z_{\#} h^{\det T_{<0}^{1/2}} = z_{\#,X^{\mathsf{A}}} (-\hbar^{-1/2})^{\det N_{>0}},$$

the proposition follows.

Proposition 6.3 constrains the monodromy of the difference equations in Kähler variables as follows.

All flops of Nakajima varieties are the same Nakajima varieties with a different choice of stability parameter. We identify  $\operatorname{Pic}(X)$  with  $\operatorname{Pic}(X_{\operatorname{flop}})$  by sending  $\det V_i$  to the same line bundle on  $X_{\operatorname{flop}}$ . The decomposition of  $H^2(X,\mathbb{R})$  into ample cones of different flops is the chamber decomposition for a certain finite collection of rational hyperplanes. The toric variety associated to the fan of ample cone is the Kähler moduli space, the base of the difference equations in the Kähler variables. Its fixed points, denoted by  $0_X$ ,  $0_{X_{\operatorname{flop}}}$ ,..., correspond to all possible flops of X.

One can compare the solution  $\mathbf{V}_X$  which is holomorphic as  $z \to 0_X$  with the solution  $\widetilde{\mathbf{V}}_{X_{\text{flop}}}$  holomorphic as  $z \to 0_{X_{\text{flop}}}$ . The comparison is given by the monodromy operator

$$\widetilde{\mathbf{V}}_{X_{\text{flop}}} = \text{Mon}_{X_{\text{flop}} \leftarrow X} \ \widetilde{\mathbf{V}}_{X},$$

which is meromorphic and invariant under the shifts of variables by q.

**Proposition 6.5.** For any chamber  $\mathfrak{C}$ , the diagram

![](_page_56_Figure_7.jpeg)

commutes.

*Proof.* The connection matrix between the solutions  $\mathbf{V}_{X,\mathfrak{C}}$  and  $\mathbf{V}_{X_{\text{flop}},\mathfrak{C}}$  is invariant under q-shifts of a and has a limit as  $a \to 0_{\mathfrak{C}}$  by Proposition 6.3. Therefore, it is constant equal to its value at  $a \to 0_{\mathfrak{C}}$ . Since it is q-periodic in z, we may ignore shift by q in (113).

## <span id="page-56-2"></span><span id="page-56-0"></span>6.4 Proof of Theorem 5

#### 6.4.1

Consider the pole of the vertex function at an irreducible divisor of the form

<span id="page-56-1"></span>
$$w^l q^m = \zeta, \quad \zeta^n = 1, \quad w \in (\mathsf{T}^\wedge)_{\text{indivisible}},$$
 (119)

where we can assume that

$$gcd(l, m) = 1$$
,  $m > 0$ , order  $(\zeta) = n$ .

Consider the subgroup

$$\mathsf{T}\supset\mathsf{T}'=\mathrm{Ker}\,w^{nl}\cong(\mathbb{C}^{\times})^{\mathrm{rk}\,\mathsf{T}-1}\times\mu_{nl}$$

where  $\mu_{nl} \subset \mathbb{C}^{\times}$  is the group of roots of unity. Equivariant localization on QM(X) with respect to T', introduces poles at divisors of the form

<span id="page-57-0"></span>
$$w'q^{m'} = 1 \tag{120}$$

where w' is a weight of T which is nontrivial on T'.

Since the poles (120) are distinct from (119) and localization contributes

$$\begin{pmatrix} \text{virtual normal} \\ \text{bundle terms} \end{pmatrix} \in K_{\mathsf{T}}(\mathsf{QM}(X))_{\text{localized at (120)}},$$

we can replace the T action on QM(X) by the action of

$$\mathsf{T}_{\mathrm{new}} = \mathsf{T}/\mathsf{T}' \cong \mathbb{C}^{\times} \ni t$$

on

$$\mathsf{QM}(X)^{\mathsf{T}'} = \mathsf{QM}\left(X^{\mathsf{T}'}\right) = \mathsf{QM}(X_{\mathrm{new}}).$$

in the analysis that follows. By construction, the weight  $w^{nl}$  becomes the coordinate on  $\mathsf{T}_{\text{new}}$ . Therefore, the poles of interest now have the form

<span id="page-57-1"></span>
$$t q^m = 1, \quad m = m_{\text{new}} = n m_{\text{old}} > 0.$$
 (121)

#### 6.4.2

Now suppose  $\mathsf{T} = \mathbb{C}_t^{\times}$  and let

$$\mathsf{T}'' \subset \mathbb{C}_t^{\times} \times \mathbb{C}_a^{\times}$$

be the subtorus defined by (121). Again, equivariant localization with respect to  $\mathsf{T}''$  introduces poles that are distinct from (121), therefore it is important to understand the  $\mathsf{T}''$ -fixed loci in the moduli spaces of quasimaps.

Recall that vertex functions are computed using  $\mathbb{C}_q^{\times}$ -equivariant localization. As a scheme,  $\mathbb{C}_q^{\times}$ -fixed loci in  $\mathsf{QM}(X)_{\mathrm{nonsing at}} \propto$  are identical to  $\mathbb{C}_q^{\times}$ -fixed loci in the moduli spaces of twisted quasimaps, see [57]. There is a small but important difference in their obstruction theory, see below.

Quasimaps from  $\mathbb{P}^1$  to a GIT-quotient are sections of a bundle of prequotients, and one can twist that bundle further by using a homomorphism

$$\mathbb{C}_q^{\times} \to \operatorname{Aut}(X)$$

as a clutching function. This has the effect of allowing  $\mathbb{C}_q^{\times}$  to act nontrivially in the fibers over  $0, \infty \in \mathbb{P}^1$ . In particular, there is a unique twist such that

- $\mathbb{C}_q^{\times}$  acts trivially in the fiber over 0,
- T'' acts trivially in the fiber over  $\infty$ .

We denote by  $QM(X)_{tw}$  the corresponding moduli space.

We have the following

<span id="page-58-2"></span>Theorem 6. The map

<span id="page-58-0"></span>
$$\operatorname{ev}_{\infty} : \operatorname{QM}(X)^{\mathsf{T}''}_{\operatorname{tw, nonsing at } \infty} \to X$$
 (122)

is proper for quasimaps of fixed degree and its image lies in

$$X_{\text{repelling}} = \{x, \lim_{t \to \infty} tx \text{ exists}\}.$$
 (123)

Proof. Singularities of a T ′′-fixed quasimap form a T ′′-invariant finite subset of P <sup>1</sup> \ {∞} and, therefore, they are all confined to the origin. Thus, away from the origin, we have a T ′′-invariant parametrized curve in X. In local coordinates at ∞ ∈ P 1 this curve is constant, and therefore uniquely determined by the point in which it meets the fiber at infinity. Given this curve and degree of the quasimap, all possible singularities at the origin form a proper set, whence the properness of the map [\(122\)](#page-58-0).

We have proper maps

$$X \xrightarrow{\pi} X_0 \hookrightarrow V$$

where X<sup>0</sup> is the affine quotient, that is, the spectrum of the algebra of G-invariants, and the T-equivariant embedding X<sup>0</sup> → V is obtained from a choice of generators of this algebra. This induces proper maps

$$\mathsf{QM}(X)_{\mathrm{tw}} \to \mathsf{QM}(X_0)_{\mathrm{tw}} \hookrightarrow H^0(\mathbb{P}^1, \mathscr{V}).$$

We can split V and V by their t-weights

$$V = V_{\leq 0} \oplus V_{>0}$$

and then

$$X_{\text{repelling}} = \pi^{-1} \left( V_{\leq 0} \right)$$

while V><sup>0</sup> consists of line bundles of negative degree and hence has no sections. This shows the evaluation map lands in Xrepelling.

### 6.4.4

In a discussion of regularity of functions along a divisor, it is natural to pass to completion of K-theories at that divisor. For example, we may consider

$$K_{\mathbb{C}_t^{\times} \times \mathbb{C}_q^{\times}}(\mathrm{pt})_{\mathrm{completed \ at \ (121)}} = \mathbb{Q}(q)[[t-q^{-m}]] \, .$$

This is the completion of rational functions in t and q regular at tq<sup>m</sup> = 1 in the topology of formal power series in t − q <sup>−</sup><sup>m</sup>.

Further, since elliptic cohomology classes give elements of KT(X)[[q]], it is natural to additionally pass to the completion of the local ring at q = 0 and define

<span id="page-58-1"></span>
$$\widehat{K}_{\mathbb{C}_t^{\times} \times \mathbb{C}_q^{\times}}(\mathrm{pt}) = \mathbb{Q}((q))[[t - q^{-m}]]. \tag{124}$$

It is important to note the order of completions. For the opposite order, we have

$$\frac{1}{1 - q^m t} = \sum_{k>0} t^k q^{km} \in \mathbb{Q}[[t - q^{-m}]][[q]],$$

and so it is meaningless to talk about the order of pole at  $t = q^{-m}$ .

#### 6.4.5

To return to the general setup of Section 6.4.1, we consider an exact sequence

$$1 \to \mathsf{T}' \to \mathsf{T} \xrightarrow{t} \mathbb{C}_{t}^{\times} \to 1 \tag{125}$$

and the corresponding action of  $\mathbb{C}_t^{\times}$  on

$$X' = X^{\mathsf{T}'}$$
.

We are interested in poles at the components of

<span id="page-59-0"></span>
$$tq^m = 1. (126)$$

Associated to this divisor (126), there is the moduli space

$$\widetilde{\mathsf{QM}}' = \mathsf{QM}(X')_{\mathrm{tw, nonsingular at } \infty}$$

of twisted quasimaps to X', with an evaluation map

$$\operatorname{ev}_{\operatorname{tw}}^* : \widehat{K}_{\mathbb{C}_t^{\times} \times \mathbb{C}_q^{\times}}(X')_{\operatorname{completed at } t = 1} \to \widehat{K}_{\mathbb{C}_t^{\times} \times \mathbb{C}_q^{\times}}\left(\widetilde{\mathsf{QM}}'\right)_{\operatorname{completed at } q^m t = 1}$$
(127)

covering the homomorphism of tori

$$(t,q)\mapsto (tq^m,q)$$
.

Here the completions of K-theories are as in (124), with a difference of divisors indicated.

Since  $X^{\mathsf{T}} = (X')^{\mathbb{C}^{\times}}$  is proper, attracting and repelling sets intersect properly. Therefore, from Theorem 6 we deduce the following

#### Corollary 6.6. Let

$$\mathscr{F} \in \widehat{K}_{\mathbb{C}_t^{\times} \times \mathbb{C}_q^{\times}}(X'), \quad \mathscr{G} \in \widehat{K}_{\mathbb{C}_t^{\times} \times \mathbb{C}_q^{\times}}(\widetilde{\mathsf{QM}}')$$
 (128)

be such that

$$\operatorname{supp} \mathscr{F} \subset X'_{\operatorname{attracting}} = \{x, \lim_{t \to 0} tx \text{ exists}\}.$$

Then

<span id="page-59-1"></span>
$$\chi(\widetilde{\mathsf{QM}}', \mathscr{G} \otimes \mathrm{ev}_{\mathrm{tw}}^* \mathscr{F}) \in \widehat{K}_{\mathsf{T} \times \mathbb{C}_a^{\times}}(\mathrm{pt}).$$
 (129)

Our next goal is to find  $\mathscr{F}$  and  $\mathscr{G}$  so that the  $\mathbb{C}_q^{\times}$ -equivariant localization of (129) reproduces (105). We first consider the case when there is a map

$$\sigma: \mathbb{C}_q^{\times} \to \mathsf{A} \subset \mathsf{T}$$

such that

<span id="page-60-2"></span>
$$t(\sigma(q)) = q^m. (130)$$

Using  $\sigma$ , we can twist quasimaps to X so that

<span id="page-60-1"></span><span id="page-60-0"></span>
$$\widetilde{QM}^{T'} = \widetilde{QM}' \, .$$

And we take in (129) the restrictions of

$$\mathscr{G} = \widehat{\mathcal{O}}_{\text{vir}} \otimes \text{Tautological at 0}, \tag{131}$$

$$\mathscr{F} = \frac{\operatorname{Stab}_{\#} \otimes \left(\det T^{1/2}\right)^{-1/2}}{\Phi(qT^{\vee})}, \tag{132}$$

where the tautological term in (131) denotes an arbitrary Schur functor of the fibers of the tautological bundles at the origin in the domain of the quasimap. (For example, this term can be the identity.) Note that the twist by the square root of det  $T^{1/2}$  makes stable envelope an element of  $K_T(X)[[q]]$  and that the fraction in (132) has no pole at t=1.

#### <span id="page-60-3"></span>6.4.7

We now compare the  $\mathbb{C}_q^{\times}$ -equivariant localization of (129) with the corresponding computations for untwisted quasimaps. The contributions of  $\mathscr{G}$  to two localization formulas are almost identical, the only difference comes from

$$T_{\text{vir,tw}} - T_{\text{vir}} = \frac{(TX)_{\text{tw}} - TX}{1 - q},$$

where  $(TX)_{tw}$  is the tangent bundle of X with the action of  $\mathsf{T} \times \mathbb{C}_q^{\times}$  induced by  $\sigma$ . This gives

$$\mathscr{O}_{\mathrm{vir,tw}} = \mathscr{O}_{\mathrm{vir}} \Phi \left( q T_{\mathrm{tw}}^{\vee} - q T^{\vee} \right) ,$$

which means

$$\mathscr{O}_{\mathrm{vir,tw}} \otimes \mathrm{ev}_{\mathrm{tw}}^* \left( \frac{1}{\Phi(qT^\vee)} \right)$$
 is twist-invariant .

<span id="page-61-1"></span>The difference between  $\mathcal{O}_{\text{vir,tw}}$  further includes the weight of  $\mathcal{K}_{\text{vir}}^{1/2}$  and the contribution from the polarization. For the latter we have the evident relation

$$\left(\frac{\det T_{\infty,\text{tw}}^{1/2}}{\det T_0^{1/2}}\right)^{1/2} \otimes \text{ev}_{\text{tw}}^* \left(\det T^{1/2}\right)^{-1/2} \text{ is twist-invariant}.$$
(133)

For the former, we have the following

#### Lemma 6.7.

$$\frac{\mathscr{K}_{\text{vir,tw}}^{1/2}}{\mathscr{K}_{\text{vir}}^{1/2}} = \left(-\hbar^{1/2}\right)^{\left\langle \det T^{1/2}, \sigma \right\rangle} \frac{\Theta(T^{1/2})}{\Theta(T_{\text{tw}}^{1/2})}.$$
(134)

*Proof.* This is equivalent to the identity

$$\det\left(\frac{aq^k + \frac{1}{\hbar aq^k} - a - \frac{1}{\hbar a}}{1 - q}\right)^{-1/2} = \hbar^{k/2} a^k q^{\frac{k^2}{2}} = \left(-\hbar^{1/2}\right)^k \frac{\vartheta(a)}{\vartheta(q^k a)}.$$

#### 6.4.9

Let  $\operatorname{Stab}(F)$  denote the restriction of elliptic stable envelopes to a component  $F \subset X^{\mathsf{A}}$ . By definition of stable envelopes,

<span id="page-61-0"></span>
$$\left(\frac{\operatorname{Stab}_{\#}(F)}{\Theta(T^{1/2})}\right)_{\operatorname{tw}} / \frac{\operatorname{Stab}_{\#}(F)}{\Theta(T^{1/2})} = \dots \ z_{\#}^{\lambda(\cdot,\sigma)} \tag{135}$$

where dots stand for a scalar factor that depends on the component F. Degrees of the "constant" twisted quasimaps to  $X^{\sigma}$  are computed as follows

$$\deg_{\mathrm{tw}} - \deg = -\boldsymbol{\lambda}(\cdot, \sigma).$$

This gives the following

**Lemma 6.8.** The localization of

$$z^{\deg_{\mathrm{tw}}} \mathscr{K}_{\mathrm{vir,tw}}^{1/2} \operatorname{ev}_{\mathrm{tw}}^* (\operatorname{Stab}_{\#}(F))$$

depends on the twist only through a scalar factor that depends on F.

Putting it all together, we obtain the following

<span id="page-61-2"></span>**Proposition 6.9.** Under the assumption (130), the  $\mathbb{C}_q^{\times}$ -localization of

$$z^{\deg_{\operatorname{tw}}} \mathscr{G} \otimes \operatorname{ev}_{\operatorname{tw}}^*(\mathscr{F})$$
,

for  $\mathscr{G}$  and  $\mathscr{F}$  as in (131) and (132), depends on the twist only through a scalar function of the component of the fixed locus in the domain of stable envelope. Therefore, the sum of such localization contributions for untwisted quasimaps is regular at (126).

We now consider the general case, when the required twist of quasimaps to X' cannot be obtained by twisting the quasimaps to the ambient X.

By our assumption, A is not in the kernel of t, therefore we can find  $\mathbb{C}_a^\times\subset\mathsf{A}$  such that

$$t(a) = a^m, \quad m \neq 0.$$

Restricted to X', the tautological bundles of  $\mathcal{V}_i$  of X will split according to characters of T'

$$\mathscr{V}_i\Big|_{X'} = \bigoplus_{\eta \in (\mathsf{T}')^{\wedge}} \mathscr{V}_{i,\eta}\,,$$

and we can take a coarser decomposition

$$\mathscr{V}_i\Big|_{X'} = \bigoplus_{k=0}^{m-1} \mathscr{V}_{i,k}$$

by the characters of

$$\Gamma = \mathbb{C}_a^{\times} \cap \mathsf{T}' \cong \mathbb{Z}/m$$
.

The torus  $\mathbb{C}_q^{\times}$  has a well-defined action on

<span id="page-62-0"></span>
$$\mathcal{V}_{i,k,\text{shift}} = q^{-k/m} \, \mathcal{V}_{i,k} \tag{136}$$

via the multivalued map

$$\sigma: \mathbb{C}_q^{\times} \ni q \mapsto q^{1/m} \in \mathbb{C}_a^{\times}$$
.

Using this map, we can define the shifted and twisted tautological bundles over  $QM(X')_{tw}$ , and similarly for the framing bundles  $\mathcal{W}_{i,k,\text{shift}}$ .

Note that shifts  $q^{-k/m}$  for all these bundles lie in (-1,0]. Therefore, the shifts for the tangent bundle, which is a sesquilinear expression in  $\mathcal{V}_i$  and  $\mathcal{W}_i$ , lie in (-1,1) and the shift is zero precisely on  $\Gamma$ -invariants. This means that:

- shifts occur only in the virtual normal directions to QM(X'),
- a polarization of

$$N^{1/2} = \left(T^{1/2}\big|_{X'}\right)_{\mathsf{T'} \text{ moving}}$$

separates the shifts into opposite pairs.

We may consider  $\mathsf{QM}(X')$  with a new obstruction theory, which is its own obstruction theory together with the contribution of shifted virtual normal bundle. This will define the sheaf  $\widehat{\mathscr{O}}_{\text{vir,shift}}$ .

Consider the diagram of maps

$$\operatorname{Ell}_{\mathsf{T}}(X) \xrightarrow{\iota^{*}} \operatorname{Ell}_{\mathsf{T}}(X') \xrightarrow{t^{*}} \operatorname{Ell}_{\mathbb{C}_{t}^{\times}}(X')$$

$$\downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad$$

in which  $\iota^*$  is the functorial map induced by the inclusion

$$\iota: X' \to X$$
.

The shifts in (136) induce an automorphism of  $\mathrm{Ell}_{\mathsf{T}}(X')$  which covers translation by  $\sigma(q)$  on the base

$$\operatorname{Ell}_{\mathsf{T}}(X') \xrightarrow{\operatorname{shift}} \operatorname{Ell}_{\mathsf{T}}(X') . \tag{138}$$

$$\downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow$$

$$\mathscr{E}_{\mathsf{T}} \xrightarrow{t \mapsto \sigma(q)t} \mathscr{E}_{\mathsf{T}}$$

We define

$$\mathscr{G} = \widehat{\mathcal{O}}_{\text{vir,shift}} \otimes \text{Tautological at 0}, \tag{139}$$

$$\mathscr{F} = \left(\frac{\operatorname{Stab}_{\#} \otimes \left(\det T^{1/2}\right)^{-1/2}}{\Phi(qT^{\vee})}\right)_{\text{shift}},\tag{140}$$

where the shift of the stable envelope is the pullback under  $(\iota \circ \text{shift})$ .

After the shifts, the relation (135) is unchanged, as it concerns the degrees of curves in X', which are not affected by a shift in equivariant structure. The shift of polarization affects  $\Theta(T^{1/2})$  in the obvious way. Namely, it becomes  $\Theta\left(T_{\text{shift}}^{1/2}\right)$ , and its transformation under  $\sigma$  precisely matches the transformation of  $\widehat{\mathcal{O}}_{\text{vir,shift}}$ . This is the computation we did in Sections 6.4.7 and 6.4.8.

This proves the conclusion of Proposition 6.9 without the assumption (130) and concludes the proof of Theorem 5.

## References

- <span id="page-63-3"></span>[1] M. Aganagic, E. Frenkel, and A. Okounkov, Quantum q-Langlands correspondence, Trans. Moscow Math. Soc. **79** (2018), 1–83.  $\uparrow$ 50
- <span id="page-63-2"></span>[2] M. Aganagic and N. Haouzi, "ADE Little String Theory on a Riemann Surface (and Triality)," arXiv:1506.04183 [hep-th]. pages 9
- <span id="page-63-1"></span>[3] M. Aganagic and A. Okounkov, in preparation. pages 8
- <span id="page-63-0"></span>[4] M. Aganagic and A. Okounkov, *Duality interfaces in 3-dimensional theories*, talks at StringMath2019, available from https://www.stringmath2019.se/scientific-talks-2/. pages 8

- <span id="page-64-13"></span>[5] C. Beem, T. Dimofte and S. Pasquetti, "Holomorphic Blocks in Three Dimensions," JHEP 1412, 177 (2014) doi:10.1007/JHEP12(2014)177 [arXiv:1211.1986 [hep-th]]. pages 51
- <span id="page-64-14"></span>[6] F. Benini and W. Peelaers, "Higgs branch localization in three dimensions," JHEP **1405**, 030 (2014) doi:10.1007/JHEP05(2014)030 [arXiv:1312.6078 [hep-th]]. M. Fujitsuka, M. Honda and Y. Yoshida, "Higgs branch localization of 3d N=2 theories," PTEP **2014**, no. 12, 123B02 (2014) doi:10.1093/ptep/ptu158 [arXiv:1312.3627 [hep-th]]. Y. Yoshida and K. Sugiyama, "Localization of 3d  $\mathcal{N}=2$  Supersymmetric Theories on  $S^1\times D^2$ ," arXiv:1409.6713 [hep-th]. pages 51
- <span id="page-64-0"></span>[7] Roman Bezrukavnikov and Michael Finkelberg, Wreath Macdonald polynomials and the categorical McKay correspondence, Camb. J. Math. 2 (2014), no. 2, 163–190, DOI 10.4310/CJM.2014.v2.n2.a1. With an appendix by Vadim Vologodsky. MR3295916 ↑3
- [8] R. Bezrukavnikov and D. Kaledin, Fedosov quantization in positive characteristic, J. Amer. Math. Soc. **21** (2008), no. 2, 409–438, DOI 10.1090/S0894-0347-07-00585-1. MR2373355 (2008i:14079) ↑3
- [9] R. Bezrukavnikov and I. Losev, Etingof conjecture for quantized quiver varieties, arXiv:1309.1716. pages 3
- <span id="page-64-1"></span>[10] Roman Bezrukavnikov and Ivan Mirković, Representations of semisimple Lie algebras in prime characteristic and the noncommutative Springer resolution, Ann. of Math. (2) 178 (2013), no. 3, 835–919, DOI 10.4007/annals.2013.178.3.2. MR3092472 ↑3
- <span id="page-64-6"></span>[11] R. Bezrukavnikov and A. Okounkov, in preparation. pages 7
- <span id="page-64-10"></span>[12] A. Białynicki-Birula, Some theorems on actions of algebraic groups, Ann. of Math. (2) 98 (1973), 480–497. ↑12
- <span id="page-64-9"></span>[13] Christina Birkenhake and Herbert Lange, Complex abelian varieties, Grundlehren der Mathematischen Wissenschaften [Fundamental Principles of Mathematical Sciences], vol. 302, Springer-Verlag, Berlin, 2004. ↑10
- <span id="page-64-8"></span>[14] Alexander Braverman, Michael Finkelberg, and Hiraku Nakajima, Towards a mathematical definition of Coulomb branches of 3-dimensional N = 4 gauge theories, II, Adv. Theor. Math. Phys. 22 (2018), no. 5, 1071–1147. ↑8
- <span id="page-64-7"></span>[15] M. Bullimore, T. Dimofte and D. Gaiotto, "The Coulomb Branch of 3d  $\mathcal{N}=4$  Theories," arXiv:1503.04817 [hep-th]. pages 8
- <span id="page-64-11"></span>[16] Neil Chriss and Victor Ginzburg, Representation theory and complex geometry, Birkhäuser Boston, Inc., Boston, MA, 1997. ↑14
- <span id="page-64-12"></span>[17] Ionuţ Ciocan-Fontanine, Bumsig Kim, and Davesh Maulik, Stable quasimaps to GIT quotients, J. Geom. Phys. **75** (2014), 17–47. ↑45
- <span id="page-64-4"></span>[18] P. Deligne, Équations différentielles à points singuliers réguliers, Lecture Notes in Mathematics, Vol. 163, Springer-Verlag, Berlin, 1970. pages 5
- <span id="page-64-15"></span>[19] L. Di Vizio, J.-P. Ramis, J. Sauloy, and C. Zhang, Équations aux q-différences, Gaz. Math. **96** (2003), 20-49 (French). MR1988639 (2004e:39023)  $\uparrow 56$
- <span id="page-64-2"></span>[20] Pavel I. Etingof, Igor B. Frenkel, and Alexander A. Kirillov Jr., Lectures on representation theory and Knizhnik-Zamolodchikov equations, Mathematical Surveys and Monographs, vol. 58, American Mathematical Society, Providence, RI, 1998. ↑5
- <span id="page-64-3"></span>[21] Pavel I. Etingof and Adriano A. Moura, On the quantum Kazhdan-Lusztig functor, Math. Res. Lett. 9 (2002), no. 4, 449–463. ↑5, 7
- <span id="page-64-5"></span>[22] Pavel Etingof and Olivier Schiffmann, Lectures on the dynamical Yang-Baxter equations, Quantum groups and Lie theory (Durham, 1999), London Math. Soc. Lecture Note Ser., vol. 290, Cambridge Univ. Press, Cambridge, 2001, pp. 89–129. ↑7

- <span id="page-65-3"></span>[23] P. Etingof and A. Varchenko, Exchange dynamical quantum groups, Comm. Math. Phys. 205 (1999), no. 1, 19–52. ↑7
- <span id="page-65-2"></span>[24] Giovanni Felder, Conformal field theory and integrable systems associated to elliptic curves, Proceedings of the International Congress of Mathematicians, Vol. 1, 2 (Z¨urich, 1994), Birkh¨auser, Basel, 1995, pp. 1247–1255. ↑5, 44
- [25] G. Felder, V. Tarasov, and A. Varchenko, Monodromy of solutions of the elliptic quantum Knizhnik-Zamolodchikov-Bernard difference equations, Internat. J. Math. <sup>10</sup> (1999), no. 8, 943–975. <sup>↑</sup><sup>5</sup>
- <span id="page-65-1"></span>[26] I. B. Frenkel and N. Yu. Reshetikhin, Quantum affine algebras and holonomic difference equations, Comm. Math. Phys. <sup>146</sup> (1992), no. 1, 1–60. <sup>↑</sup>5, 9
- <span id="page-65-5"></span>[27] D. Gaiotto and E. Witten, "S-Duality of Boundary Conditions In N=4 Super Yang-Mills Theory," Adv. Theor. Math. Phys. 13, no. 3, 721 (2009) doi:10.4310/ATMP.2009.v13.n3.a5 [\[arXiv:0807.3720](http://arxiv.org/abs/0807.3720) [hep-th]]. pages 8
- <span id="page-65-7"></span>[28] D. Gaiotto and E. Witten, "Knot Invariants from Four-Dimensional Gauge Theory," Adv. Theor. Math. Phys. 16, no. 3, 935 (2012) doi:10.4310/ATMP.2012.v16.n3.a5 [\[arXiv:1106.4789](http://arxiv.org/abs/1106.4789) [hep-th]]. pages 9
- <span id="page-65-16"></span>[29] D. Gaiotto, L. Rastelli and S. S. Razamat, "Bootstrapping the superconformal index with surface defects," JHEP 1301, 022 (2013) doi:10.1007/JHEP01(2013)022 [\[arXiv:1207.3577](http://arxiv.org/abs/1207.3577) [hep-th]]; D. Gaiotto and H. C. Kim, "Surface defects and instanton partition functions," [arXiv:1412.2781](http://arxiv.org/abs/1412.2781) [hep-th]; M. Bullimore, H. C. Kim and P. Koroteev, "Defects and Quantum Seiberg-Witten Geometry," JHEP 1505, 095 (2015) doi:10.1007/JHEP05(2015)095 [\[arXiv:1412.6081](http://arxiv.org/abs/1412.6081) [hep-th]]. pages 45
- <span id="page-65-8"></span>[30] Nora Ganter, The elliptic Weyl character formula, Compos. Math. <sup>150</sup> (2014), no. 7, 1196–1234. <sup>↑</sup>11, 15
- <span id="page-65-4"></span>[31] Sachin Gautam and Valerio Toledano Laredo, Monodromy of the trigonometric Casimir connection for sl2, Noncommutative birational geometry, representations and combinatorics, Contemp. Math., vol. 592, Amer. Math. Soc., Providence, RI, 2013, pp. 137–176. ↑7
- <span id="page-65-9"></span>[32] David J. Gepner, Homotopy topoi and equivariant elliptic cohomology, ProQuest LLC, Ann Arbor, MI, 2006. Thesis (Ph.D.)–University of Illinois at Urbana-Champaign. ↑11
- <span id="page-65-10"></span>[33] V. Ginzburg, M. Kapranov, and E. Vasserot, Elliptic Algebras and Equivariant Elliptic Cohomology, arXiv:q-alg/9505012. pages 11, 15, 33
- <span id="page-65-14"></span>[34] Alexander Givental and Yuan-Pin Lee, Quantum K-theory on flag manifolds, finite-difference Toda lattices and quantum groups, Invent. Math. <sup>151</sup> (2003), no. 1, 193–219. <sup>↑</sup><sup>45</sup>
- <span id="page-65-15"></span>[35] Alexander Givental and Valentin Tonita, The Hirzebruch-Riemann-Roch theorem in true genus-0 quantum K-theory, Symplectic, Poisson, and noncommutative geometry, Math. Sci. Res. Inst. Publ., vol. 62, Cambridge Univ. Press, New York, 2014, pp. 43–91. ↑45
- <span id="page-65-12"></span>[36] M. Goresky, R. Kottwitz, and R. MacPherson, Equivariant cohomology, Koszul duality, and the localization theorem, Invent. Math. 131 (1998), no. 1, 25–83. pages 13
- <span id="page-65-11"></span>[37] I. Grojnowski, Delocalised equivariant elliptic cohomology, Elliptic cohomology, London Math. Soc. Lecture Note Ser., vol. 342, Cambridge Univ. Press, Cambridge, 2007, pp. 114–121. ↑11
- <span id="page-65-0"></span>[38] D. Halpern-Leistner, D. Maulik, A. Okounkov, Catergorical stable envelopes and magic windows, in preraration. pages 4
- <span id="page-65-6"></span>[39] A. Hanany and E. Witten, "Type IIB superstrings, BPS monopoles, and three-dimensional gauge dynamics," Nucl. Phys. B 492, 152 (1997) doi:10.1016/S0550-3213(97)00157-0 [\[hep-th/9611230\]](http://arxiv.org/abs/hep-th/9611230). pages 8
- <span id="page-65-13"></span>[40] Tam´as Hausel and Nicholas Proudfoot, Abelianization for hyperk¨ahler quotients, Topology 44 (2005), no. 1, 231–248. ↑32

- <span id="page-66-13"></span>[41] K. A. Intriligator and N. Seiberg, "Mirror symmetry in three-dimensional gauge theories," Phys. Lett. B 387, 513 (1996) doi:10.1016/0370-2693(96)01088-X [\[hep-th/9607207\]](http://arxiv.org/abs/hep-th/9607207). pages 8
- <span id="page-66-12"></span>[42] M. Jimbo, H. Konno, S. Odake, and J. Shiraishi, Quasi-Hopf twistors for elliptic quantum groups, Transform. Groups <sup>4</sup> (1999), no. 4, 303–327. <sup>↑</sup><sup>7</sup>
- <span id="page-66-8"></span>[43] Dmitry Kaledin, Derived equivalences by quantization, Geom. Funct. Anal. 17 (2008), no. 6, 1968–2004. ↑3
- <span id="page-66-1"></span>[44] , Geometry and topology of symplectic resolutions, Algebraic geometry—Seattle 2005. Part 2, Proc. Sympos. Pure Math., vol. 80, Amer. Math. Soc., Providence, RI, 2009, pp. 595–628. ↑3, 11
- <span id="page-66-15"></span>[45] Anton Kapustin, Topological field theory, higher categories, and their applications, Proceedings of the International Congress of Mathematicians. Volume III, Hindustan Book Agency, New Delhi, 2010, pp. 2021–2043. ↑9
- <span id="page-66-10"></span>[46] Hitoshi Konno, Dynamical R matrices of elliptic quantum groups and connection matrices for the q-KZ equations, SIGMA Symmetry Integrability Geom. Methods Appl. <sup>2</sup> (2006), Paper 091, 25. <sup>↑</sup><sup>5</sup>
- <span id="page-66-17"></span>[47] J. Lurie, A survey of elliptic cohomology, Algebraic topology, Abel Symp., vol. 4, Springer, Berlin, 2009, pp. 219–277. ↑11
- <span id="page-66-5"></span>[48] Davesh Maulik and Alexei Oblomkov, Quantum cohomology of the Hilbert scheme of points on Anresolutions, J. Amer. Math. Soc. <sup>22</sup> (2009), no. 4, 1055–1091. <sup>↑</sup><sup>3</sup>
- <span id="page-66-0"></span>[49] Davesh Maulik and Andrei Okounkov, Quantum groups and quantum cohomology, Ast´erisque 408 (2019), ix+209 (English, with English and French summaries). ↑1, 3, 7, 19, 28, 41, 51
- <span id="page-66-18"></span>[50] Kevin McGerty and Thomas Nevins, Kirwan surjectivity for quiver varieties, Invent. Math. 212 (2018), no. 1, 161–187. ↑13
- <span id="page-66-19"></span>[51] Alexander S. Merkurjev, Equivariant K-theory, Handbook of K-theory. Vol. 1, 2, Springer, Berlin, 2005, pp. 925–954. ↑14
- <span id="page-66-11"></span>[52] Adriano Adrega de Moura, Elliptic dynamical R-matrices from the monodromy of the q-Knizhnik-Zamolodchikov equations for the standard representation of <sup>U</sup>q(slen+1), Asian J. Math. <sup>7</sup> (2003), no. 1, 91–114. ↑5
- <span id="page-66-2"></span>[53] Hiraku Nakajima, Instantons on ALE spaces, quiver varieties, and Kac-Moody algebras, Duke Math. J. <sup>76</sup> (1994), no. 2, 365–416. <sup>↑</sup><sup>3</sup>
- <span id="page-66-3"></span>[54] , Quiver varieties and Kac-Moody algebras, Duke Math. J. <sup>91</sup> (1998), no. 3, 515–560. <sup>↑</sup><sup>3</sup>
- <span id="page-66-4"></span>[55] , Quiver varieties and finite-dimensional representations of quantum affine algebras, J. Amer. Math. Soc. <sup>14</sup> (2001), no. 1, 145–238. <sup>↑</sup><sup>3</sup>
- <span id="page-66-14"></span>[56] , Towards a mathematical definition of Coulomb branches of 3-dimensional N = 4 gauge theories, <sup>I</sup>, Adv. Theor. Math. Phys. <sup>20</sup> (2016), no. 3, 595–669. <sup>↑</sup><sup>8</sup>
- <span id="page-66-7"></span>[57] Andrei Okounkov, Lectures on K-theoretic computations in enumerative geometry, Geometry of moduli spaces and representation theory, IAS/Park City Math. Ser., vol. 24, Amer. Math. Soc., Providence, RI, 2017, pp. 251–380. ↑3, 4, 38, 39, 45, 47, 49, 53, 55, 56, 58
- <span id="page-66-6"></span>[58] A. Okounkov and R. Pandharipande, Quantum cohomology of the Hilbert scheme of points in the plane, Invent. Math. <sup>179</sup> (2010), no. 3, 523–557. <sup>↑</sup><sup>3</sup>
- <span id="page-66-9"></span>[59] A. Okounkov and A. Smirnov, Quantum difference equations for Nakajima varieties, preprint. pages 3, 7, 45, 47
- <span id="page-66-16"></span>[60] H. Ooguri and C. Vafa, "Knot invariants and topological strings," Nucl. Phys. B 577, 419 (2000) doi:10.1016/S0550-3213(00)00118-8 [\[hep-th/9912123\]](http://arxiv.org/abs/hep-th/9912123). pages 9

- <span id="page-67-4"></span>[61] Nicholas J. Proudfoot, A survey of hypertoric geometry and topology, Toric topology, Contemp. Math., vol. 460, Amer. Math. Soc., Providence, RI, 2008, pp. 323–338. ↑30
- <span id="page-67-3"></span>[62] Ioanid Rosu, Equivariant elliptic cohomology and rigidity, Amer. J. Math. 123 (2001), no. 4, 647–677. ↑11
- <span id="page-67-5"></span>[63] Daniel Shenfeld, Abelianization of stable envelopes in symplectic resolutions, ProQuest LLC, Ann Arbor, MI, 2013. Thesis (Ph.D.)–Princeton University. ↑32, 38
- <span id="page-67-6"></span>[64] A. Smirnov, Polynomials associated with fixed points on the instanton moduli space, arXiv:1404.5304. pages 32
- <span id="page-67-7"></span>[65] Andrey Smirnov, Elliptic stable envelope for Hilbert scheme of points in the plane, Selecta Math. (N.S.) <sup>26</sup> (2020), no. 1, Art. 3, 57. <sup>↑</sup><sup>38</sup>
- <span id="page-67-1"></span>[66] Jasper V. Stokman, Connection problems for quantum affine KZ equations and integrable lattice models, Comm. Math. Phys. <sup>338</sup> (2015), no. 3, 1363–1409. <sup>↑</sup><sup>5</sup>
- <span id="page-67-0"></span>[67] Michela Varagnolo, Quiver varieties and Yangians, Lett. Math. Phys. <sup>53</sup> (2000), no. 4, 273–283. <sup>↑</sup><sup>3</sup>
- <span id="page-67-2"></span>[68] E. Witten, "Fivebranes and Knots," [arXiv:1101.3216](http://arxiv.org/abs/1101.3216) [hep-th]. pages 9
- <span id="page-67-8"></span>[69] E. Witten, "Phases of N=2 theories in two-dimensions," Nucl. Phys. B 403, 159 (1993) doi:10.1016/0550- 3213(93)90033-L [\[hep-th/9301042\]](http://arxiv.org/abs/hep-th/9301042). pages 51