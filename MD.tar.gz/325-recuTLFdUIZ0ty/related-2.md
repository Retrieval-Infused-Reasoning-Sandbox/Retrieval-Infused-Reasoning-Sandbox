# Interfaces and Quantum Algebras, I: Stable Envelopes

Mykola Dedushenko and Nikita Nekrasov

Simons Center for Geometry and Physics, Stony Brook University, Stony Brook, NY 11794-3636, USA

#### Abstract

The stable envelopes of Okounkov et al. realize some representations of quantum algebras associated to quivers, using geometry. We relate these geometric considerations to quantum field theory. The main ingredients are the supersymmetric interfaces in gauge theories with four supercharges, relation of supersymmetric vacua to generalized cohomology theories, and Berry connections. We mainly consider softly broken compactified three dimensional N = 4 theories. The companion papers will discuss applications of this construction to symplectic duality, Bethe/gauge correspondence, generalizations to higher dimensional theories, and other topics.

### Contents

| 1 |     | Introduction                                          |    |  |  |
|---|-----|-------------------------------------------------------|----|--|--|
|   | 1.1 | Overview                                              | 6  |  |  |
| 2 |     | Preliminaries                                         | 9  |  |  |
|   | 2.1 | Gauge theories with eight and four supercharges       | 9  |  |  |
|   | 2.2 | Quiver theories and quiver varieties<br>              | 21 |  |  |
|   | 2.3 | Brane construction<br>                                | 22 |  |  |
| 3 |     | Vacua and Q-cohomology                                | 27 |  |  |
|   | 3.1 | The choice of supercharges                            | 27 |  |  |
|   | 3.2 | Properties of<br>Q,<br>QA<br>and their cohomology<br> | 30 |  |  |
|   | 3.3 | Vacua and generalized cohomology<br>                  | 33 |  |  |
|   | 3.4 | The bundle of vacua in the elliptic case              | 39 |  |  |
| 4 |     | Janus interfaces                                      | 53 |  |  |
|   | 4.1 | FI Janus in 3d<br>N<br>= 2                            | 54 |  |  |
|   | 4.2 | N<br>Mass Janus in 3d<br>= 2<br>                      | 56 |  |  |
| 5 |     | Analysis via supersymmetric quantum mechanics         | 60 |  |  |
|   | 5.1 | Time-dependent Morse function<br>                     | 60 |  |  |
|   |     | 5.1.1<br>A toy example                                | 63 |  |  |
|   | 5.2 | Equivariant extension                                 | 65 |  |  |
|   |     | 5.2.1<br>Toy example continued                        | 65 |  |  |
|   | 5.3 | Including holomorphic superpotential<br>              | 68 |  |  |
|   | 5.4 | Gauged quantum mechanics<br>                          | 69 |  |  |
|   | 5.5 | General setting<br>                                   | 70 |  |  |
|   | 5.6 | Localization and gradient trajectories                | 71 |  |  |
|   |     | 5.6.1<br>Example of a solution<br>                    | 73 |  |  |
|   |     | 5.6.2<br>Broken, or concatenated, trajectories<br>    | 74 |  |  |
|   |     | 5.6.3<br>Flavor equivariant parameters<br>            | 75 |  |  |

| 6 |     |                  | Relation to stable envelopes                     | 77  |
|---|-----|------------------|--------------------------------------------------|-----|
|   | 6.1 |                  | Janus background and gradient flows<br>          | 77  |
|   | 6.2 |                  | Effective description<br>                        | 82  |
|   |     | 6.2.1            | C<br>Theory<br>T<br><br>p                        | 83  |
|   |     | 6.2.2            | C<br>T<br>T<br>Interface between<br>and<br><br>p | 86  |
|   | 6.3 |                  | Boundary conditions for vacua                    | 92  |
|   | 6.4 |                  | Computation of matrix elements                   | 98  |
|   | 6.5 | Examples         |                                                  | 101 |
|   |     | 6.5.1<br>T       | ∗CP<br>n−1<br>                                   | 101 |
|   |     | 6.5.2            | An−1<br>ALE space<br>                            | 105 |
|   |     | 6.5.3<br>T       | ∗Gr(N, L)<br>                                    | 112 |
|   |     | 6.5.4            | Hilbert scheme of points<br>                     | 117 |
| 7 |     | Outlook          |                                                  | 121 |
| A | 3d  | N<br>= 2         | conventions                                      | 124 |
|   | A.1 | Flat space       |                                                  | 124 |
|   | A.2 |                  | Localizing deformations in flat space<br>        | 126 |
|   | A.3 |                  | Interval partition function<br>                  | 127 |
| B |     |                  | Boundary conditions and boundary states          | 130 |
|   | B.1 | Bosonic fields   |                                                  | 130 |
|   | B.2 | Fermionic fields |                                                  | 133 |

## <span id="page-2-0"></span>1 Introduction

The study of quantum field theory in recent decades has been enriched by the appreciation of the rˆole of extended observables, associated to surfaces, domain walls, boundaries and interfaces. Traditional gauge theory has, naturally, electric line observables and codimension three magnetic observables, better known as Wilson loops, and 't Hooft loops, in four dimensions. There is a growing sense of the need to include all kinds of defects, boundaries and corners, in order to have a real understanding of what quantim field theory is, and what is it good for, cf. [\[1](#page-137-0)[–4\]](#page-137-1), and [\[5](#page-137-2)[–7\]](#page-137-3).

Quantum field theory is, in many respects, an infinite-dimensional version of quantum mechanics. In quantum mechanics observables form a noncommutative algebra A, as expectation values of products of observables depends on the time ordering,

$$\langle \mathcal{O}_1(t_1)\mathcal{O}_2(t_2)\rangle \neq \langle \mathcal{O}_2(t_1)\mathcal{O}_1(t_2)\rangle, \ \mathcal{O}_{1,2} \in \mathcal{A}.$$

The noncommutativity makes geometric considerations blurred. Recall that algebraically, topological spaces are identified with the commutative algebras (algebras of continuous functions, say)

$$x \in X \leftrightarrow f \mapsto f(x),$$

while geometry can be encoded in additional restrictions and structures. Occasionally, the noncommutative algebra A of observables of some quantum mechanical system contains a large enough commutative subalgebra C ⊂ A. One possible source of such emergence of ("the target space") geometry within the framework of the quantum mechanics is a topological, or vacuum, sector of a quantum field theory with a mass gap, compactified so as to look macroscopically as a one dimensional theory.

![](_page_3_Picture_6.jpeg)

If the gapped theory can be endowed with the nilpotent symmetry Q, Q<sup>2</sup> = 0, such that the stress-tensor is a homotopy of the Hilbert space to the subspace of vacua,

$$T_{\mu\nu} = \{ \mathcal{Q}, G_{\mu\nu} \},$$

with some operator-valued tensor Gµν, then local operators O (0) i (x), annihilated by Q are independent of their spacetime position, up to Q-exact terms:

<span id="page-3-0"></span>
$$d\mathcal{O}^{(0)} = \{\mathcal{Q}, \mathcal{O}^{(1)}\}. \tag{1.1}$$

This relation implies the commutativity of the corresponding quantum mechanical operators, as points in two and higher dimensions can be moved around each other. Meanwhile, interfaces represented by a purple circle in the picture above, do not commute and descend to noncommutative quantum mechanical operators. A large class of quantum integrable systems, whose integrability is explained by the use of the structure [\(1.1\)](#page-3-0), corresponds to supersymmetric gauge theories.

The connection between integrability and gauge theories has a long history. The projection method of Olshanetsky and Perelomov [\[8\]](#page-137-4), Kazhdan-Kostant-Sternberg construction of Calogero-Moser-Sutherland systems of particles can be viewed as the examples of onedimensional gauge theories equivalent to quantum integrable systems. The discovery [\[9\]](#page-137-5) of the connection between Jones polynomial and Chern-Simons theory in three dimensions made possible an embedding [\[10–](#page-137-6)[12\]](#page-138-0) of a large class of soluble models of statistical physics into the realm of topological field theories.

The paper [\[13\]](#page-138-1) raised the question of a possibility of connecting the exact results, e.g. [\[14,](#page-138-2) [15\]](#page-138-3) in supersymmetric gauge theories to quantum integrable systems. The construction of [\[13\]](#page-138-1) related the Sutherland model to the two-dimensional Yang-Mills theory, which, thanks to [\[15\]](#page-138-3) can be viewed as a subsector of a deformation of the two dimensional N = (2, 2) super Yang-Mills theory. The relativistic generalization of the Sutherland model embeds [\[16\]](#page-138-4) to three dimensional Chern-Simons theory which, in turn, admits an interpretation as the vacuum subsector of a twisted supersymmetric theory [\[17–](#page-138-5)[20\]](#page-138-6). A close cousin of these many-body models, Lieb-Liniger system describing the N-particle sector of a one-dimensional Bose gas [\[21\]](#page-138-7), also known as the quantum non-linear Schr¨odinger system was found [\[22\]](#page-138-8) to be related, perhaps in a similar [\[23\]](#page-138-9) way, to a deformation of the N = 2<sup>∗</sup> theory in two dimensions, a close cousin of the two dimensional Yang-Mills theory. The analogous elliptic models required somewhat more exotic generalizations of gauge theories, involving non-Lorentz invariant deformations by Chern-Simons terms multiplied by holomorphic differentials (see p.5 of [\[24\]](#page-139-0), pp. 88-89 of [\[17\]](#page-138-5)), a hybrid version of the holomorphic Chern-Simons theory introduced in [\[25\]](#page-139-1), motivated, among other things, by [\[26,](#page-139-2) [27\]](#page-139-3), and used, implicitly, in [\[28\]](#page-139-4).

In a somewhat parallel way a connection between the quantum integrability and topological sigma models was found in [\[29,](#page-139-5) [30\]](#page-139-6), see [\[31\]](#page-139-7) for a mathematical physicist's perspective. The paper [\[22\]](#page-138-8), in the hindsight, gave an important example of such connection (the models found in [\[29\]](#page-139-5) had continuum spectrum, so the Bethe equations could not be detected), which was further expanded to the Bethe/gauge correspondence between the vacua of supersymmetric gauge theories with two dimensional N = 2 super-Poincare invariance and quantum integrable systems amenable to Bethe ansatz in [\[32–](#page-139-8)[34\]](#page-139-9). In the approach of Faddeev's school [\[35](#page-139-10)[–37\]](#page-140-0) the latter is a consequence of a (hidden) noncommutative algebraic structure of the system: the presence of a spectrum generating quantum algebra whose commutative subalgebra is the set of quantum integrals of motion.

In the context of supersymmetric (gauge) theory, such commutative algebra is typically the algebra of local operators, commuting with some (equivariantly) nilpotent supercharge, more precisely its cohomology. More generally, these operators could be local in two dimensions where the translational part of the N = 2 super-Poincare algebra acts, while extended in other dimensions. For example, a three dimensional theory compactified on a circle S 1 may have the line operators wrapped on S 1 , forming such a subalgebra.

The question of recovering the full quantum algebra, e.g. the Yangian or quantum loop algebra, has been asked in [\[34\]](#page-139-9). In [\[38\]](#page-140-1) it was proposed that the answer should involve some sort of supersymmetric interfaces, i.e. boundary conditions compatible with a fraction of supersymmetry, connecting two, possibly different, quantum field theories.

The proposal of [\[17\]](#page-138-5) was left unnoticed until the similar proposal was independently made in [\[39,](#page-140-2) [40\]](#page-140-3), and greatly developed in [\[41–](#page-140-4)[43\]](#page-140-5). In this approach, the main ingredient of the algebraic Bethe ansatz [\[35\]](#page-139-10) approach to integrability, an R-matrix depending on a spectral parameter, is derived from the perturbative analysis of the four dimensional Chern-Simons theory, just like the finite dimensional quantum group constant R-matrix can be derived, to some extent, from the three dimensional Chern-Simons theory [\[44–](#page-140-6)[50\]](#page-141-0).

In a completely parallel development, partly inspired by the ideas of [\[32\]](#page-139-8), but also by completely independent discoveries of R. Bezrukavnikov, the geometric approach to the construction of R-matrices and the associated quantum algebras was initiated in [\[51\]](#page-141-1), followed by [\[52\]](#page-141-2). The representations of quantum loop algebras and Yangians in equivariant K-theory and cohomology of Nakajima quiver varieties were constructed earlier [\[53,](#page-141-3)[54\]](#page-141-4). A generalization to a singular "higher spin" A<sup>1</sup> quiver variety in the rational case has appeared in [\[55\]](#page-141-5).

This is the part I of a series of three papers, which aim to bridge several proposals, relating quantum algebras and quantum field theory. Our main tool is the use of supersymmetric backgrounds in gauge theories with N = 4 supersymmetry in three dimensions, compactified on a two-torus, with soft breaking of supersymmetry by background gauge fields. Sometimes we make the backgrounds nearly singular, thereby creating interface operators. This is somewhat similar in spirit to the definition of local fermionic operators through singular gauge transformations applied to background vector fields, gauging some global symmetry [\[56,](#page-141-6) [57\]](#page-141-7). In our work we mostly activate the scalar superpartners, e.g. masses, of these background vector fields. Of course, backgrounds with varying masses are well-studied in the context of applications of quantum field theory to condensed matter physics, cf. [\[58\]](#page-141-8), but here we dress them with the supersymmetric background allowing, in principle, to perform exact evaluations of certain correlation functions. More generally, backgrounds with spacetimedependent parameters (and the resulting monodromies) have been previously used in the literature to realize various algebraic and geometric structures, e.g., see [\[2,](#page-137-7) [59–](#page-141-9)[63\]](#page-142-0).

In this paper we are going to relate the stable envelope construction of [\[51,](#page-141-1) [52\]](#page-141-2) to supersymmetric gauge theory interfaces. In part II we will study cigar partition functions, how they are acted on by the duality interface built from the stable envelopes, and use the Ωdeformed theories (cigar backgrounds) to relate correlators of operators extended in different number of dimensions. In part III we will study the R-matrices, establish the Bethe/gauge correspondence and the connection to the four dimensional Chern-Simons theory.

#### <span id="page-6-0"></span>1.1 Overview

Let us provide a brief overview of this paper. Our work is founded on two main ideas, which are simple enough to be described in one paragraph. The first idea is that the supersymmetric ground states of a supersymmetric quantum field theory compactified to 0 + 1 dimension, in the presence of flavor symmetry backgrounds, are described by an equivariant cohomology theory of the moduli space of vacua (its Higgs branch in simple cases). Precisely which cohomology theory it is depends on spacetime dimensionality and on the choice of supercharge. The second idea is that there exist supersymmetric Janus interfaces interpolating between the large real masses in one half-space and zero real masses in another. Treating the normal direction to the interface as time, such interfaces are certain BPS operators acting in the Hilbert space of the theory, whose restrictions to the vacuum sector give maps in the corresponding cohomology theories. If X is the Higgs branch of the theory with zero masses, the massive theory has X<sup>A</sup> for its Higgs branch, i.e., the fixed point locus of the flavor symmetry torus A corresponding to the masses we switched on. Thus one gets maps going in both directions between the equivariant cohomology theories of X and X<sup>A</sup>. The main claim of the current paper is that this is the physical realization of the stable envelopes of [\[51,](#page-141-1)[52\]](#page-141-2). Despite the simplicity of these ideas, making them even relatively precise involves understanding a lot of technical details, which is partly responsible for the length of this paper.

After reviewing the background material, such as the theories with eight supercharges in three, two, and one spacetime dimensions, in the Section [2,](#page-9-0) we scrutinize the first idea in the Section [3.](#page-27-0) In this work, we deal with de Rham cohomology, K-theory, and elliptic cohomology in parallel. This corresposponds to studying the vacua of a 1d theory on R, 2d theory on R×S 1 , or 3d theory on R×E<sup>τ</sup> (where E<sup>τ</sup> is an elliptic curve of complex structure τ ), with the supercharge Q we introduce in Section [3.1.](#page-27-1) Somewhat similarly, in studies of Bethe/Gauge correspondence, one works with the cohomology of a different supercharge QA. Our setup in 1d and 2d can be seen as dimensional reduction of the Bethe/Gauge setup, replacing the quantum cohomology/K-theory by their classical analogs. The 3d story is more subtle.

At any rate, our setup is rich enough to see the constructions of stable envelopes and the corresponding quantum spectrum-generating algebras. We lift this setting to the full Bethe/Gauge correspondence and quantum cohomology/K-theory in the future work [\[64\]](#page-142-1).

In Section [4](#page-53-0) we construct the second main ingredient: the supersymmetric Janus interfaces. One can do this both for real masses and real Fayet-Iliopoulus (FI) parameters. The mass Janus plays central role in this paper, while the FI Janus, though not used here, will be featured more in part II. Both Janus interfaces have the property, which we refer to as the universality, that modulo Q-commutators they do not depend on the shape of the mass or FI profiles, they only depend on their asymptotic values. Furthermore, the dependence on the latter, when such asymptotic values are really large, is only captured by the chambers. Namely, the mass Janus depends on the chamber C in the space of real masses, along which they are sent to infinity. The FI Janus similarly depends on the chamber C 0 in the space of real FI parameters. When we choose different chambers C<sup>1</sup> and C<sup>2</sup> at y = +∞ and y = −∞ (throughout this paper, y denotes the Euclidean time), this engineers the chamber R-matrices of [\[51,](#page-141-1) [52\]](#page-141-2), which will be the subject of part III. Here, we choose chamber C on one side of the interface only, while the real masses vanish on the other. There are other interfaces, including those connecting Higgs and Coulomb branches, which we shall study later.

In Section [5](#page-60-0) we proceed to analyze the mass Janus in one-dimensional theories using the standard tools of the supersymmetric quantum mechanics [\[65\]](#page-142-2). We show that the flows of the complexified flavor torus A<sup>C</sup> on X, which are involved in the construction of stable envelopes, are gradient flows for the Morse function typical to theories with four supercharges. This Morse function depends on the real masses m, which can be intuitively thought of as the external "force" fueling the flow. In case of theories with eight supercharges, the critical points of the Morse function all have the zero index. The corresponding flows do not lift the approximate vacua [\[65\]](#page-142-2). However, if we let masses (and f) change over time, the gradient flows do play important role. In order to make the mass (and, more generally, the Morse function f) change with time in a supersymmetric fashion, one adds a term ∼ ∂f ∂y to the action.

Then, something interesting happens. The supersymmetric ground states, whose wave functions are, in the WKB approximation, peaked at the isolated classical massive vacua/critical points of f, become, actually, supported on the full repelling manifolds of those critical points/descending manifolds/Morse cells (cf. [\[66–](#page-142-3)[68\]](#page-142-4)). The latter are the unions of the trajectories (i.e. unparametrized images) of all the gradient flows starting at a given critical point of f. The subtle part of this definition concerns the contribution of the so-called broken flows. Another subtlety comes from the non-compact nature of the repelling/attracting manifolds. We make the problem well defined by turning on the equivariant parameters. Indeed, one finds non-trivial transition ampltiudes between the isolated vacua, transitions, induced by the changing mass.

In Section [6](#page-77-0) we study the relation to stable envelopes in more detail. In particular, we argue that it is easier to compute them in the language of gauge theory (often referred to as the gauged linear sigma-model, or GLSM), rather than in the language of a non-linear sigma model. To this end, we show that in the limit of infinite large masses (in the chamber C), some degrees of freedom in the original GLSM T freeze. What remains is called T C , which breaks into a direct sum of quantum field theories ⊕pT C p , labeled by the connected components p ⊂ X<sup>A</sup> (i.e., isolated massive vacua when X<sup>A</sup> is discrete). Each T C p is itself a GLSM, whose Lagrangian description is canonically obtained from T . The T C is the theory whose Higgs branch is X<sup>A</sup>, and T C <sup>p</sup> has the Higgs branch p ⊂ X<sup>A</sup>. The Janus interface construction leads to an interface between T and each T C p , which also admits a simple Lagrangian description. We then proceed to compute matrix elements of such interfaces between vacua of T and the single vacuum of T C p . This is done by replacing vacua with boundary conditions and computing the resulting interval partition functions on (y−, y+) × E<sup>τ</sup> . We then describe several examples and compare them to the known results in the literature, when available.

Acknowledgements We are grateful to M. Aganagic, C. Closset, K. Costello, E. Frenkel, D. Gaiotto, S. Gukov, N. Haouzi, S. Jeong, Z. Komargodski, N. Lee, A. Losev, G. Moore, A. Okounkov, A. Smirnov, E. Witten for discussions. MD is also grateful to A. Okounkov for patience during the online course [\[69\]](#page-142-5) on Enumerative Geometry and Geometric Representation Theory.

Note added: in the process of completing this project we became aware of a related ongoing work of Mathew Bullimore and Daniel Zhang [\[70\]](#page-142-6), and we are grateful to them for agreeing to coordinate the release.

### <span id="page-9-0"></span>2 Preliminaries

### <span id="page-9-1"></span>2.1 Gauge theories with eight and four supercharges

We start by briefly reviewing the necessary facts about supersymmetric theories with eight supercharges [\[71–](#page-142-7)[76\]](#page-143-0) in three, two, and one spacetime dimensions, commonly referred to as 3d N = 4, 2d N = (4, 4) and 1d N = 8 theories. We often view them as 3d N = 2, 2d N = (2, 2), and 1d N = 4 theories, respectively, with the other four supercharges possibly broken by (twisted) masses and/or background flat connections for a special symmetry denoted by U(1)~. It is a flavor symmetry of the theory with four supercharges, which is a part of the group of R-symmetry from the viewpoint of the theory with eight supercharges. Thus it commutes with four out of eight supercharges.

The structure of theories in question is rather uniform across the dimensions, so we start here by reviewing the three-dimensional theories, from which the 2d and 1d cases follow by the dimensional reduction. They are built from a 3d N = 4 g-valued vector multiplet V for some Lie group G, and a hypermultiplet H valued in a quaternionic representation R of G. We only consider the theories of cotangent type, for which R = R⊕R, where R is a complex representation of G. From the 3d N = 2 point of view, the vector multiplet V decomposes into an N = 2 vector V , and an adjoint-valued chiral multiplet Φ; the hypermultiplet H decomposes into an <sup>R</sup>-valued chiral multiplet <sup>Q</sup>, and a <sup>R</sup>-valued chiral multiplet <sup>Q</sup>e. The superpotential is:

$$W = \widetilde{Q}\Phi Q. \tag{2.1}$$

Global bosonic symmetries of the system include a flavor symmetry group G<sup>H</sup> ("H" stands for Higgs), a Coulomb symmetry group GC, and the R-symmetry group SU(2)<sup>H</sup> × SU(2)C. The flavor group is defined as G<sup>H</sup> = NUSp(R)(G)/G, where NUSp(R)(G) is the normalizer of G in the group of hyperkahler isometries of free R-valued hypermultiplets. In all the theories that we study, G<sup>H</sup> acts on R in some complex representation. Thus, throughout this paper, when we write

$$w \in \mathcal{R},\tag{2.2}$$

we refer to the weights of the G × G<sup>H</sup> action. When we need to emphasize the distinction between gauge and flavor weights, we write

$$(w, f) \in \mathcal{R}, \tag{2.3}$$

with w being the G-weight and f – the GH-weight.

Only the maximal torus of G<sup>C</sup> is visible in the UV: in 3d, each abelian gauge field A gives rise to the current J = ∗dA generating the "topological" U(1), such topological symmetries form the maximal torus of GC. Thus, the rank of G<sup>C</sup> equals the dimension of the center Z(G) of G. The SU(2)<sup>H</sup> and SU(2)<sup>C</sup> R-symmetries rotate complex structures of the Higgs and Coulomb branches respectively (they are hyper-K¨ahler). In the 3d N = 2 language, there is only a U(1)<sup>R</sup> R-symmetry, which can be conveniently chosen as a diagonal subgroup of the product of the maximal tori:

$$U(1)_R = \text{Diag}[U(1)_H \times U(1)_C] \subset SU(2)_H \times SU(2)_C,$$
 (2.4)

while the anti-diagonal is what we denote as U(1)~:

$$U(1)_{\hbar} = \text{ADiag}[U(1)_H \times U(1)_C].$$
 (2.5)

To be more specific, if R<sup>H</sup> and R<sup>C</sup> are the Cartan generators, such that Q has R<sup>H</sup> = 1 2 and Φ has R<sup>C</sup> = 1, we define the U(1)<sup>R</sup> generator to be R<sup>H</sup> + RC, and the U(1)<sup>~</sup> generator is defined as R<sup>H</sup> − RC.

The chiral multiplets (Q, <sup>Q</sup>e) transform in some representation of the flavor group <sup>G</sup>H, while none of the elementary fields transform under GC. The only objects charged under G<sup>C</sup> are the disorder-type monopole operators [\[77–](#page-143-1)[80\]](#page-143-2). We summarize charges under global symmetries in the following table:

| N<br>3d<br>= 2 multiplet | ×<br>G<br>GH | GC | U(1)~  | U(1)R  |
|--------------------------|--------------|----|--------|--------|
| Vector<br>V              | Adj<br>×1    | 0  | 0      | 0      |
| Chiral Φ                 | Adj<br>×1    | 0  | −1     | 1      |
| Chiral<br>Q              | R            | 0  | 1<br>2 | 1<br>2 |
| Chiral<br>Qe             | R            | 0  | 1<br>2 | 1<br>2 |

Table 1: Symmetry content.

The vector multiplet V contains (Aµ, σ, λ, λ, D) – a gauge field, a real scalar, a Dirac spinor, and a real auxiliary field. The chiral Φ contains (φ, λφ, λφ, DC) – a complex scalar, a Dirac spinor, and a complex auxiliary field; the chirals <sup>Q</sup> and <sup>Q</sup><sup>e</sup> have analogous components. The flat space SUSY transformations and actions are summarized in the Appendix [A.](#page-124-0) We will use the following notations for the maximal tori and Cartan subalgebras:

G<sup>H</sup> : Maximal torus A, Cartan aubalgebra a = Lie(A),

G<sup>C</sup> : Maximal torus A<sup>0</sup> , Cartan aubalgebra a <sup>0</sup> = Lie(A<sup>0</sup> ),

G : Maximal torus H, Cartan aubalgebra h = Lie(H).

(2.6)

Additionally, the torus of N = 2 flavor symmetry group is denoted as

$$\mathbf{T} = \mathbf{A} \times U(1)_{\hbar}, \quad \mathfrak{t} = \operatorname{Lie}(\mathbf{T}).$$
 (2.7)

Masses, FI, and CS couplings. The standard way to generate masses is to give vevs to background vector multiplets. In 3d N = 4 theories, this results in an SU(2)<sup>C</sup> triplet of masses ~m (valued in the Cartan of GH) and an SU(2)<sup>H</sup> triplet of Fayet-Iliopoulos (FI) parameters ~ζ (valued in the Cartan of GC). From the N = 2 point of view, the masses break into a real mass M<sup>R</sup> and a complex mass MC: the real mass is a diagonal vev of σ in the background vector multiplet gauging GH, and the complex mass is realized via a superpotential term

$$W_M = \widetilde{Q}M_{\mathbb{C}}Q, \tag{2.8}$$

where M<sup>C</sup> now is a complex mass matrix acting in the flavor group representation F.

Likewise, from the N = 2 point of view, FI parameters break into a real parameter ζR, and a complex one ζC. The real parameter analogously comes from the background vector multiplet for the topological symmetry, and is usually written in flat space as a Lagrangian coupling

$$\mathcal{L}_{FI} = i \operatorname{Tr} (\zeta_{\mathbb{R}} D), \tag{2.9}$$

where "Tr" only picks up components in the center of the gauge group. The complex FI term is another superpotential coupling:

$$W_{\rm FI} = i \text{Tr } (\zeta_{\mathbb{C}} \Phi). \tag{2.10}$$

Notice that both complex masses M<sup>C</sup> and complex FI parameters ζ<sup>C</sup> are charged under

 $U(1)_{\hbar}$ . Since we are going to use this symmetry, we never turn on the complex parameters:

<span id="page-12-0"></span>
$$M_{\mathbb{C}} = \zeta_{\mathbb{C}} = 0. \tag{2.11}$$

As we said before, none of the fields in the Lagrangian are charged under the Coulomb branch symmetry  $G_C$ . Therefore, the ordinary couplings to the  $G_C$  background vector multiplet, i.e. through the covariant derivatives of charged fields, are absent. Nonetheless, the  $G_C$ -vectors couple to the dynamical gauge multiplets via mixed  $\mathcal{N}=2$  Chern-Simons (CS), or BF, term. This term is of course responsible for the real FI parameter. Denote fields in the vector multiplet gauging the topological symmetry by  $(A_{\mu}^{\text{top}}, \sigma^{\text{top}}, \lambda^{\text{top}}, \overline{\lambda}^{\text{top}}, D^{\text{top}})$ . Recall that the topological symmetry current is J=\*F, where F is an abelian field strength. The usual gauging procedure involves the current coupling  $A_{\mu}^{\text{top}}J^{\mu}=\frac{1}{2}A_{\mu}^{\text{top}}\varepsilon^{\mu\nu\rho}F_{\nu\rho}$ , thus producing the mixed CS term, whose  $\mathcal{N}=2$  SUSY completion, really a truncation of the full  $\mathcal{N}=4$  BF coupling [76, 81], is

$$S_{\rm BF} = \frac{i}{2\pi} \int A^{\rm top} \wedge F + \frac{i}{2\pi} \int d^3x \left( \sigma^{\rm top} D + D^{\rm top} \sigma - \frac{1}{2} \overline{\lambda}^{\rm top} \lambda - \frac{1}{2} \overline{\lambda} \lambda^{\rm top} \right). \tag{2.12}$$

We see from this action that giving a vev to  $\sigma^{\text{top}}$  generates a real FI term for the dynamical vector multiplet, as stated earlier. The coupling to  $A^{\text{top}}$  will also play an important role later in this paper. The bare 3d action does not include any other CS terms. While they are certainly possible [82], they go beyond the class of theories considered here.

Reduction to 2d and 1d. The lower dimensional versions of the above theories can be obtained by reduction. In general, the reduction of a 3d  $\mathcal{N}=2$  theory to two dimension is very subtle, giving different 2d theories depending on how one scales parameters [83]. It was also argued in [83] that there exists a special scaling resulting in the "same" theory in 2d, i.e. the one admitting a UV completion by a purely 2d gauge theory, whose content is determined by a classical dimensional reduction. In principle, this is the only type of scaling we need, since we are only interested in purely 2d and purely 1d gauge theories constructed from the same gauge group and matter content as in 3d.

Furthermore, we study 3d  $\mathcal{N}=4$  theories and their reductions to 2d and 1d. Before turning on the  $U(1)_{\hbar}$  background, such theories preserve all eight supercharges, and do not allow for arbitrary superpotentials or twisted superpotentials in 2d and 1d. For such theories, the existence of scaling that preserves the structure of the gauge theory is even

more clear, and we always assume it. One could only worry that once we turn on the  $U(1)_{\hbar}$  background that breaks four supercharges, a non-trivial twisted superpotential is generated. Such a twisted superpotential can be made arbitrarily small by tuning the  $U(1)_{\hbar}$  deformation parameter to sufficiently small values, and so its effect on the 2d and 1d physics is under control. Furthermore, we will see that there exists a proper scaling of the  $U(1)_{\hbar}$  parameter (that will be introduced shortly), which allows to obtain the purely 2d (and purely 1d) answer out of the 3d computation.

Thus we can study the structure of 2d and 1d theories relying on the classical dimensional reduction. The general structure of multiplets is preserved, the only major difference being that the vector multiplet gains one more real adjoint-valued scalar  $\sigma_1$  in 2d, and yet another one, denoted  $\sigma_2$ , after passing to 1d. The BF coupling (2.12) becomes an FI-Theta term in the twisted superpotential in 2d,

$$\widetilde{W}_t = t\Sigma, \tag{2.13}$$

where  $\Sigma$  is the twisted chiral multiplet of the 2d vector multiplet, and  $t = \frac{\Theta}{2\pi} + i\zeta$ , where the theta-angle comes from the holonomy of  $A^{\text{top}}$  along the circle. If we further classically reduce to 1d, the theta-angle term disappears in the strict 1d limit, and only the real FI term survives. This can be summarized as follows:

$$\boxed{3D: S_{BF}} \longrightarrow \boxed{2D: \widetilde{W}_t} \longrightarrow \boxed{1D: \mathcal{L}_{FI}}$$

$$(2.14)$$

In our applications, we will be studying three-dimensional theories on the space

$$\mathbb{R} \times \mathbb{E}_{\tau},$$
 (2.15)

where  $\mathbb{E}_{\tau}$  is an elliptic curve with the complex structure  $\tau$  and Ramond spin structure along both circles (to preserve SUSY). We identify  $\mathbb{E}_{\tau} = \mathbb{C}^{\times}/\widetilde{q}^{\mathbb{Z}}$ , where  $\widetilde{q} = e^{2\pi i \tau}$ . The A and B cycles are chosen so that for a constant differential dz, we have

$$\int_{\Lambda} dz = 1, \quad \int_{B} dz = \tau. \tag{2.16}$$

We always define the 2d limit as  $\tau \to 0$ , i.e., by shrinking the B cycle. In this limit,  $\tilde{q} \to 1$ , or alternatively  $q = e^{-\frac{2\pi i}{\tau}} \to 0$ .

For a non-degenerate elliptic curve, we turn on flat connections in the maximal tori of the global symmetry groups  $G_H \times U(1)_{\hbar}$  and  $G_C$ . The flat connection  $A^f$  for the maximal torus T = A × U(1)<sup>~</sup> of the flavor group G<sup>H</sup> × U(1)<sup>~</sup> is characterized by

$$\widetilde{a} = \oint_B A^{f} - \tau \oint_A A^{f}. \tag{2.17}$$

This is a doubly-periodic variable valued in t<sup>C</sup> mod Q<sup>∨</sup>⊕τQ<sup>∨</sup> , where Q<sup>∨</sup> denotes the co-root lattice of T, and t<sup>C</sup> ≡ t ⊗ C.

In the 2d limit τ → 0, the elliptic curve E<sup>τ</sup> degenerates to a circle. We would like to take the limit in such a way that the low energy description coincides with that of the corresponding 2d gauge theory [\[83\]](#page-143-5). In particular, the kinetic term normalization implies that R <sup>B</sup> A ∝ τ σ1, R <sup>B</sup> A<sup>f</sup> ∝ τm1, where σ<sup>1</sup> is the new vector multiplet scalar, and m<sup>1</sup> is a mass. It is convenient to introduce a variable a = ea τ ∈ t<sup>C</sup> mod Q<sup>∨</sup> ⊕ 1 <sup>τ</sup> Q<sup>∨</sup> that remains finite in this limit, so

$$a = \frac{1}{\tau} \oint_B A^{\mathbf{f}} - \oint_A A^{\mathbf{f}}.$$
 (2.18)

Such rescaled variables are associated with the S-transformed elliptic curve E<sup>−</sup> <sup>1</sup> τ , whose complex structure is − 1 τ . We also identify it as

$$\mathbb{E}_{-\frac{1}{\tau}} = \mathbb{C}^{\times}/q^{\mathbb{Z}}, \quad \text{where } q = e^{-\frac{2\pi i}{\tau}}.$$
 (2.19)

The corresponding exponentiated elliptic variable is

$$X = e^{2\pi i a}. (2.20)$$

We prefer to work with X (or a) and q variables, as they are more convenient for addressing the 2d limit, which now becomes q → 0.

The variables X will be interpreted as elliptic equivariant parameters for the action of T, but for now they are simly T-valued flat connections on the elliptic curve. Because T = A × U(1)~, we will split X = (x, ~), and work only with such variables in what follows. They can be seen to parameterize the abelian variety of equivariant parameters:

$$\mathcal{E}_{\mathbf{T}} = \left(\mathbb{E}_{-\frac{1}{\tau}}\right)^{\mathrm{rk}(\mathbf{T})}.$$
 (2.21)

In the 2d limit τ → 0, we can drop the second direct summand in the lattice Q<sup>∨</sup> ⊕ 1 <sup>τ</sup> Q<sup>∨</sup> , and the variable a, or equivalently X = (~, x), becomes effectively cylindrical

$$(\hbar, x) \in (\mathbb{C}^{\times})^{\text{rk}(\mathbf{T})}$$
 in the 2d limit. (2.22)

Further reduction to 1d corresponds to shrinking the remaining circle, which also requires an analogous rescaling of variables. With a slight abuse of notations, the  $\mathbb{C}^{\times}$ -valued equivariant parameters  $(x, \hbar)$  in this case should be replaced by  $(e^{\epsilon x}, e^{\epsilon \hbar})$ , where  $\epsilon \to 0$  is the 1d limit, and the exponents are interpreted as the  $\mathbb{C}$ -values equivariant parameters in 1d:

$$(\hbar, x) \in \mathbb{C}^{\text{rk}(\mathbf{T})}$$
 in the 1d limit. (2.23)

In complete analogy, we also turn on a flat connection  $A^{\text{top}}$  along  $\mathbb{E}_{\tau}$  for the topological symmetry, i.e., the maximal torus  $\mathbf{A}'$  of  $G_C$ . It is characterized by

$$\widetilde{\xi} = \oint_B A^{\text{top}} - \tau \oint_A A^{\text{top}},$$
(2.24)

which is a doubly-periodic variable in  $\mathfrak{a}'_{\mathbb{C}}$ , with periods  $Q_C^{\vee} \oplus \tau Q_C^{\vee}$ , where  $Q_C^{\vee}$  is a co-root lattice of  $\mathbf{A}'$ . Again, the rescaled variable associated to the curve  $\mathbb{E}_{-\frac{1}{\tau}}$  is

$$\xi = \frac{\widetilde{\xi}}{\tau} \in \mathfrak{a}_{\mathbb{C}}' \mod Q_C^{\vee} \oplus \frac{1}{\tau} Q_C^{\vee}, \tag{2.25}$$

and the exponentiated elliptic parameter is denoted

$$z = e^{2\pi i \xi},\tag{2.26}$$

which parameterizes  $\mathcal{E}_{\mathbf{A}'} = \left(\mathbb{E}_{-\frac{1}{\tau}}\right)^{\operatorname{rk}(\mathbf{A}')}$ . These z will be identified with the elliptic  $K\ddot{a}hler$  parameters later. As we can see, holonomies z for the topological symmetries are analogous to flavor holonomies X in most ways.

However, there is a distinction between the X and z holonomies in how we take the 2d and 1d limits. Recall that for flavor symmetries,  $\int_B A^{\rm f}$  had to scale as  $\tau$  in the limit  $\tau \to 0$ , while  $\int_A A^{\rm f}$  was kept constant (recall that in our conventions, in the 2d limit B is the vanishing cycle). For the topological symmetry  $\mathbf{A}'$ , it is  $\int_B A^{\rm top}$  that is kept constant, while the dependence on  $\int_A A^{\rm top}$  disappears, and we can simply put it to zero. Let us elucidate this point.

Unlike the flavor gauge field, which explicitly enters covariant derivatives, the topological gauge field enters the action only through the BF term (2.12), namely  $\frac{i}{2\pi} \int A^{\text{top}} \wedge F$ . In the 2d limit, without any unusual scaling, the BF term becomes the  $\Theta$ -angle coupling for the abelian gauge field, with  $\Theta = \int_B A^{\text{top}}$ . Thus,  $\int_B A^{\text{top}}$  is kept constant in the 2d limit. Naively, we get an additional term in 2d originating from  $\int_{\mathbb{R}\times B} (\int_A A^{\text{top}}) F$ . However, as  $\int_B A \propto \tau \sigma_1$ ,

we get the coupling  $\tau \int_{\mathbb{R}\times A} A^{\text{top}} \wedge d\sigma_1$ . Such a term is negligible in the  $\tau \to 0$  limit.

If we simply put  $\int_A A^{\text{top}} = c$ , then  $\xi = \frac{1}{\tau} \int_B A^{\text{top}} - \int_A A^{\text{top}} = \frac{\Theta}{\tau} - c$ , and the Kähler parameter becomes

$$z = e^{2\pi i \xi} = q^{-\frac{\Theta}{2\pi}} e^{-2\pi i c}. \tag{2.27}$$

The expressions we will be getting involve ratios of the form  $\frac{\vartheta(xz)}{\vartheta(z)}$ , and in the  $q \to 0$  limit with  $z = q^{-\Theta}e^{-2\pi ic}$ , the c-dependence drops out. Therefore, we just put c = 0, and choose the definition of the 2d limit as tending  $q \to 0$ , with the substitution

$$z = q^{-\frac{\Theta}{2\pi}},\tag{2.28}$$

as well as scaling of the equivariant parameters explained earlier. This is exactly the kind of scaling that is used in the mathematical literature [84,85], where the Theta-angle is denoted by  $s = \Theta$  and called a slope.

If we further take the 1d limit by shrinking the size of the remaining circle to zero, we again see a distinction from the case of flat connections for flavor symmetries. The parameter z, which starts its life in 3d as a flat connection for the topological symmetry, and reduces to a theta-angle in 2d, completely disappears in 1d. The 1d limit of the theta-term

$$\frac{\Theta}{2\pi} \int F \tag{2.29}$$

is  $\frac{\Theta}{2\pi} \int_{\mathbb{R}} \partial_y \sigma_2$ , where  $\sigma_2$  is the new real scalar that the 1d vector multiplet gains from the dimensional reduction. Again, proper normalization of its kinetic term eliminates this theta-like interaction in the 1d limit.

Finally, let us note that in the discussion above, there was no urgent need to consider both the  $\mathbb{E}_{\tau}$  and  $\mathbb{E}_{-\frac{1}{\tau}}$  elliptic curves: it is enough to formulate everything in terms of the  $\mathbb{E}_{\tau}$ , and study the  $\tau \to 0$  limit. However, this corresponds to the hard  $\widetilde{q} \to 1$  limit, which is simplified by passing to the curve  $\mathbb{E}_{-\frac{1}{\tau}}$ , leading to a much better behaved  $q \to 0$  limit. This also makes contact with the conventions in the mathematical literature [52,84,85].

Boundary conditions. 3d  $\mathcal{N}=4$  theories admit rich classes of half-BPS boundary conditions preserving either  $\mathcal{N}=(2,2)$  or  $\mathcal{N}=(0,4)$  supersymmetry at the boundary [62,86–89]. In the presence of a softly-breaking  $U(1)_{\hbar}$  background, when only the  $\mathcal{N}=2$  subalgebra is left unbroken in the bulk, both classes of boundary conditions preserve  $\mathcal{N}=(0,2)$ . Three-dimensional  $\mathcal{N}=2$  theories also admit  $\mathcal{N}=(1,1)$  boundary conditions, which break

R-symmetry at the boundary. Depending on how one decomposes 3d N = 4 multiplets into 3d N = 2 multiplets, a given N = (2, 2) boundary condition can be understood both as an N = (1, 1) and N = (0, 2) boundary condition (the two interpretations related by the R-symmetry rotation in the bulk). However, the N = (1, 1) language makes certain symmetries (such as U(1)<sup>R</sup> and U(1)~) non-manifest at the boundary. As those symmetries are quite important to us, we have to work with the N = (0, 2) boundary conditions.

To describe (0, 2) boundary conditions, it is quite convenient, like in [\[89\]](#page-144-1), to reformulate 3d N = 2 multiplets as 2d N = (0, 2) multiplets valued in the infinite-dimensional target of the type Maps(R, . . .). Here ellipsis represents the target of the original 3d multiplet, which is a gauge algebra for the vector multiplet, and its representation in the case of matter multiplets. In the 2d description, each 3d N = 2 multiplet decomposes into a pair of 2d N = (0, 2) multiplets, and we concisely summarize this data in the following table:

| 3d<br>N<br>= 2 multiplet | 1st 2d multiplet | 2nd 2d multiplet | special interactions                       |
|--------------------------|------------------|------------------|--------------------------------------------|
| Vector<br>V              | vector<br>V2d    | adjoint chiral S | FI for V = FI for<br>V2d                   |
| Chiral Φ                 | 2d chiral Φ      | Fermi ΨΦ         | superpotential<br>J<br>= ΨΦ(∂y<br>−<br>S)Φ |
|                          |                  |                  | ∂W<br>superpotential<br>E<br>=<br>∂Φ       |

Table 2: 2d N = (0, 2) description of 3d N = 2 multiplets.

We used the standard notations for superpotentials: W for the 3d N = 2 and J, E for the two superpotentials of the 2d N = (0, 2) theory [\[90\]](#page-144-2).

The description of boundary conditions is especially convenient in this language: for each 3d N = 2 multiplet, one simply has to choose one of the two constituent (0, 2) multiplets, and make it vanish entirely at the boundary. Often a generalization is possible, where certain fields in this multiplet are instead set to some fixed non-zero values at the boundary. Such boundary deformations should be treated in the same sense as couplings in the Lagrangians: they may be given certain values in the UV, and then be subject to a nontrivial RG-flow on the way to the IR.

The basic N = (0, 2) boundary conditions are constructed as follows:

(0,2) Dirichlet for 
$$V \equiv \{V_{2d} | = 0\},$$
 (2.30)

(0,2) Neumann for 
$$V \equiv \{S | = 0\},$$
 (2.31)

(0,2) Dirichlet for 
$$\Phi \equiv \{\Phi | = 0\},$$
 (2.32)

(0,2) Neumann for 
$$\Phi \equiv \{\Psi_{\Phi} | = 0\}.$$
 (2.33)

The Dirichlet boundary condition for V admits a generalization where the gauge field is fixed to be some non-trivial flat connection at the boundary. Similarly, the Dirichlet boundary condition for a chiral multiplet Φ admits a natural generalization, where the complex scalar is fixed to some covariantly constant value at the boundary. One can also contemplate the generalization of the Neumann boundary condition for V , in which the real scalar σ in the vector multiplet, instead of zero, is given a covariantly constant value at the boundary. In non-abelian case, such a boundary vev "Higgses" the gauge group along the boundary.

The N = (2, 2) boundary conditions for a 3d N = 4 vector multiplet V = (V, Φ) are constructed as follows:

(2,2) Dirichlet for 
$$\mathcal{V} \equiv \{(0,2) \text{ Dirichlet for } V_{2d} \text{ and } (0,2) \text{ Dirichlet for } \Phi\},$$
 (2.34)

(2,2) Neumann for 
$$\mathcal{V} \equiv \{(0,2) \text{ Neumann for } V_{2d} \text{ and } (0,2) \text{ Neumann for } \Phi\}.$$
 (2.35)

The N = (2, 2) boundary conditions for a 3d N = 4 hypermultiplet H are defined with the help of the complex symplectic geometry of the vector space V where H takes values (there are also non-linear generalizations). Representing <sup>H</sup> as a pair of chirals (Q, <sup>Q</sup>e), the corresponding holomorphic symplectic form is

<span id="page-18-0"></span>
$$dQ \wedge d\widetilde{Q} \tag{2.36}$$

with the understood natural pairing of vector spaces R and R, s.t. V = R ⊕ R. Choose a Lagrangian splitting L ⊕ L <sup>⊥</sup> of this complex symplectic space, for example L = R, L <sup>⊥</sup> = R, and denote the corresponding chiral multiplets by (QL, <sup>Q</sup>e<sup>L</sup>). There are two basic (2, 2) boundary conditions associated with that splitting [\[88\]](#page-144-3):

$$\mathcal{B}_{Q_L} \equiv \{(0,2) \text{ Neumann for } Q_L \text{ and } (0,2) \text{ Dirichlet for } \widetilde{Q}_L\},$$
 (2.37)

$$\mathcal{B}_{\widetilde{Q}_L} \equiv \{(0,2) \text{ Dirichlet for } Q_L \text{ and } (0,2) \text{ Neumann for } \widetilde{Q}_L\}.$$
 (2.38)

These boundary conditions can also be generalized by giving non-trivial boundary vevs to scalars.

In this paper we study 3d theories on E<sup>τ</sup> × I, where I is an interval, subject to boundary conditions of the type described above. Although we only need N = (2, 2) boundary conditions and their N = (0, 2) versions, we also describe N = (0, 4) boundary conditions now, for the sake of completeness. The regular N = (0, 4) boundary conditions are constructed as follows:

$$(0,4)$$
 Dirichlet for  $\mathcal{V} \equiv \{(0,2)$  Dirichlet for  $V_{2d}$  and  $(0,2)$  Neumann for  $\Phi\},$  (2.39)

(0,4) Neumann for 
$$\mathcal{V} \equiv \{(0,2) \text{ Neumann for } V_{2d} \text{ and } (0,2) \text{ Dirichlet for } \Phi\},$$
 (2.40)

(0,4) Dirichlet for 
$$\mathcal{H} \equiv \{(0,2) \text{ Dirichlet for both } Q \text{ and } \widetilde{Q}\},$$
 (2.41)

(0,4) Neumann for 
$$\mathcal{H} \equiv \{(0,2) \text{ Neumann for both } Q \text{ and } \widetilde{Q}\}.$$
 (2.42)

The N = (0, 4) Dirichlet boundary conditions for the vector multiplet V admit a generalization by the Nahm pole.

Moduli of vacua. Three-dimensional supersymmetric theories have non-trivial moduli spaces of vacua that are not lifted quantum mechanically. They are stratified by the amount of unbroken gauge symmetry, which can be a maximal torus of the gauge group G or less. The stratum that preserves the maximal torus of G is called the Coulomb branch, and the stratum that breaks the gauge group entirely (up to, perhaps, a finite subgroup) is the Higgs branch. In between, there are mixed branches that preserve some portion of the maximal torus of G.

The Higgs branch can be described in the classical theory, as it is known to receive no quantum corrections. In gauge theory, the Higgs branch is the hyperK¨ahler quotient [\[91\]](#page-144-4),, i.e. the space of G-equivalence classes of the space of solutions to the real and complex moment map equations, µ<sup>R</sup> = 0, µ<sup>C</sup> = 0:

$$\mu_{\mathbb{R}} = QQ^{\dagger} - \widetilde{Q}^{\dagger}\widetilde{Q} - \zeta_{\mathbb{R}},$$
  

$$\mu_{\mathbb{C}} = Q\widetilde{Q} - \zeta_{\mathbb{C}}.$$
(2.43)

Thus, the Higgs branch is M<sup>H</sup> = {µ<sup>R</sup> = 0, µ<sup>C</sup> = 0}/G. At ζ<sup>R</sup> = ζ<sup>C</sup> = 0, it is singular; the real FI parameter ζ<sup>R</sup> resolves, the complex FI parameter ζ<sup>C</sup> deforms this singularity (this is of course relative to a specific complex structure of MH). Solving the real moment map equation and dividing by G can be traded for quotient by a complexified gauge group G<sup>C</sup> of the stable locus in the space of fields. On the smooth locus M<sup>H</sup> is also the K¨ahler quotient of the critical set of the superpotential W:

<span id="page-19-0"></span>
$$\mathcal{M}_{H} = \left(m^{-1}(0) \cap CritW\right)/G,$$

$$m = \mu_{\mathbb{R}} + \left[\Phi, \Phi^{\dagger}\right], \quad W = \text{tr}\Phi\mu_{\mathbb{C}}$$
(2.44)

where Φ is the complex adjoint scalar which belongs to the vector multiplet in the N = 4 formalism. The description [\(2.44\)](#page-19-0) is natural in the N = 2 language (theory with four supercharges).

In what follows we will keep ζ<sup>C</sup> = 0. The above description of the Higgs branch also applies to 2d N = (4, 4) and 1d N = 8 theories (and to higher-dimensional theories with eight supercharges, but we do not consider them here). However, the physical meaning of the "space of vacua" is quite different in 2d and 1d. In three and higher dimensions, fixing the vevs of fields at infinity forces the theory to sit in a specific vacuum corresponding to a point of the moduli space. In one and two dimensions it is not so. Instead, the "moduli space of vacua" only makes sense as a target space for an effective low energy nonlinear sigma model (NLSM). The wave functions of the true vacua spread over this space.

If we study a 3d theory on E<sup>τ</sup> × R (or 2d theory on S <sup>1</sup> × R), we can think of R as time, and the theory is one-dimensional macroscopically. Then the vacua behave as in 1d: instead of fixing a vev, we talk about the space of ground states. If at low energies the theory is described by an NLSM into some space X, then the space of vacua is an analog of harmonic forms on X (in a proper sense that will be discussed later).

The "branches of the moduli space of vacua" now have the meaning of phases. The theory flows to an NLSM with the effective target space being a certain branch of the moduli space. Specifically which branch is selected is determined by what values the parameters (such as the FI parameters and masses) take. Changing the parameters may induce a change of branch, i.e., a phase transition. We will work with the theories that have the property that once the real FI parameters ζ<sup>R</sup> are generic enough, the theory is in the Higgs phase. Additionally turning on real masses m<sup>R</sup> for a certain flavor symmetry from A ⊂ G<sup>H</sup> reduces us to a submanifold of the Higgs branch, which is characterized as a fixed locus of that flavor symmetry.

If we turn off the FI parameters ζ<sup>R</sup> while turning on the generic real masses mR, the theory is pushed onto the Coulomb branch (or Coulomb phase). When masses are nongeneric or even zero (more generally, if both ζ<sup>R</sup> and m<sup>R</sup> are non-generic), the theory can explore various mixed branches. The Coulomb branch of vacua is quite interesting on its own in that its classical description receives significant quantum corrections. Classically, it is parameterized by the triplet of commuting adjoint-valued scalars (from the vector multiplet), and the dual photon of the maximal torus of G. This allows to identify the classical Coulomb branch as h<sup>C</sup> × H<sup>∨</sup> C /W = T <sup>∗</sup>H<sup>∨</sup> C /W, where W is the Weyl group, and H<sup>∨</sup> C is the complexified dual torus of the maximal torus of G. Quantum-mechanical Coulomb branch is birational to this, but otherwise is quite different due to the quantum correction to its metric [\[71–](#page-142-7)[73\]](#page-142-9). Mathematically, its construction is rather different from the Higgs branch. In the m<sup>R</sup> = 0 case, the Coulomb branch is an affine variety defined as Spec(RC), where R<sup>C</sup> is the Coulomb branch chiral ring. Turning on m<sup>R</sup> corresponds to resolving singularities of this variety. The most non-trivial part in constructing the Coulomb branch is to identify the ring RC, and there exists a few approaches to this problem, both in math [\[92–](#page-144-5)[94\]](#page-144-6) and in physics [\[95–](#page-144-7)[97\]](#page-145-0). This of course only describes the complex structure the Coulomb branch. Of course, the Coulomb branch is lifted once the U(1)<sup>~</sup> mass is turned on, producing an effective twisted superpotential, which can be computed exactly at one-loop [\[32,](#page-139-8) [90,](#page-144-2) [98\]](#page-145-1).

Notice that in general, both Higgs and Coulomb branches are singular, and there might be not enough FI and real mass parameters in the theory to resolve one or another. In special classes of theories, however, they both admit smooth symplectic resolutions.

When the theory is in a Higgs phase in two dimensions, its low energy dynamics is that of a non-linear sigma model. The instantons of the latter are the holomorphic maps of the worldsheet into the effective target space, the Higgs branch. It is well-known that the point-like instanton singularities of the moduli space of holomorphic maps are resolved, in the gauge linear sigma model formulation, by the vortex-like solutions of the BPS equations, "freckled" instantons, where the instanton charge can be absorbed by a gauge flux [\[90,](#page-144-2)[99,](#page-145-2)[100\]](#page-145-3). Mathematically, these generalizations of holomorphic maps are called the "quasi-maps" [\[101\]](#page-145-4). Their count [\[102\]](#page-145-5), i.e. the computation of the partition function of the Ω-deformed theory, is an alternative way of looking at the effective twisted superpotential, and the associated Bethe equations. We shall return to this problem in the part II of this series.

### <span id="page-21-0"></span>2.2 Quiver theories and quiver varieties

An interesting class of 3d N = 4 theories are quiver gauge theories (for unitary gauge groups), which we now review. Their properties, especially in the context of Bethe/Gauge correspondence, are intimately connected to the Kac-Moody algebras encoded by the corresponding quivers.

Let Q be a finite oriented graph with I a set of vertices and E a set of edges. For e ∈ E let s(e), t(e) ∈ I denote the source and the target of the edge e, respectively. For k, l ∈ I, let us denote the number of oriented edges joining k and l by Qkl = #s −1 (k) ∩ t −1 (l).

Take two collections of complex finite dimensional vector spaces labelled by the vertices:

(Vk)k∈I and (Wk)k∈I. The gauge group of the quiver theory is taken to be

<span id="page-22-1"></span>
$$G = \prod_{k \in \mathcal{I}} U(V_k), \tag{2.45}$$

and the complex representation R is chosen as

$$\mathcal{R} = \bigoplus_{k \in \mathcal{I}} \operatorname{Hom}(W_k, V_k) \oplus \bigoplus_{e \in E} \operatorname{Hom}(V_{s(e)}, V_{t(e)}) \otimes \mathbb{C}^{Q_{s(e), t(e)}}. \tag{2.46}$$

The quaternionic representation is then T <sup>∗</sup>R = R ⊕ R. We see that such theories have w<sup>k</sup> hypermultiplets in the fundamental representation of U(Vk) for each k, also Qkk – in the adjoint representation, and Qkl hypers – in the bi-fundamental of U(Vk) × U(Vl) for each pair k 6= l of vertices connected by an edge. The flavor symmetry group G<sup>H</sup> is a normalizer of G in USp(R) modulo G,

$$G_H = \left(\prod_{k,l \in \mathcal{I}} U(Q_{kl}) \times \prod_{k \in \mathcal{I}} U(W_k)\right) / \prod_{k \in \mathcal{I}} U(1)$$
 (2.47)

and it contains factors like

$$G_H \supset \prod_{k \in \mathcal{I}} SU(W_k), \quad \prod_{k \in \mathcal{I}} U(Q_{kk}), \quad \prod_{k < l} SU(Q_{kl}).$$
 (2.48)

In the case of quivers of ADE type, the flavor symmetry G<sup>H</sup> is precisely given by Q <sup>k</sup>∈I U(Wk)/U(1)<sup>I</sup> . More generally, e.g. for affine ADE quivers, G<sup>H</sup> = Q <sup>k</sup>∈I U(Wk) × Q <sup>e</sup>∈<sup>E</sup> U(1)/U(1)<sup>I</sup> . The topological symmetry, i.e., the maximal torus A<sup>0</sup> of the Coulomb branch symmetry group G<sup>C</sup> is

$$\mathbf{A}' = \prod_{k \in \mathcal{I}} U(1),\tag{2.49}$$

and may be enhanced to some non-abelian G<sup>C</sup> in the IR.

#### <span id="page-22-0"></span>2.3 Brane construction

The gauge theories described above arise on the worldvolumes of D-branes in various string constructions [\[103–](#page-145-6)[105\]](#page-145-7). More specifically, the three dimensional N = 4 supersymmetric quiver gauge theory, with the underlying graph being the affine Dynkin diagram of the A, D, E type, with color is realized on the worldvolume of a stack of fractional D2 branes probing an ADE singularity C <sup>2</sup>/Γ with Γ a finite subgroup of SU(2), McKay dual to the A, D, E simple Lie algebra. The group Γ defines the quiver, whose vertices are the irreducible representations R<sup>i</sup> of Γ, I ∼= Γ ∨ . The vertices i and j are connected by aij edges, where aij is the multiplicity

$$\mathbb{C}^2 \otimes \mathcal{R}_i = \bigoplus_j \mathbb{C}^{a_{ij}} \otimes \mathcal{R}_j. \tag{2.50}$$

We consider the IIA string background with the spacetime of the form

$$M = Y \times N \times S,\tag{2.51}$$

with Y ∼= R 1,2 the three dimensional Minkowski space or its compactified versions R <sup>1</sup>,<sup>1</sup> × S 1 or R × T 2 , N ∼= R 3 , and S = C <sup>2</sup>/Γ or its resolution <sup>S</sup><sup>e</sup> of singularities.

The D2 branes are spanning the submanifold Y × 0 × 0 ⊂ M of the ten dimensional spacetime. The gauge group G is given by [\(2.45\)](#page-22-1) with v<sup>k</sup> being the number of fractional D2 branes corresponding to the irrep R<sup>k</sup> of Γ. In other words, the Chan-Paton space living on the stack of D2 branes is a representation of Γ

$$\widehat{V} = \bigoplus_{k \in \mathcal{I}} \mathbb{C}^{v_k} \otimes \mathcal{R}_k. \tag{2.52}$$

In addition to the color D2 branes we have the flavor D6 branes, wrapping Y × 0 × S. Since S at infinity looks like the lens space L = S <sup>3</sup>/Γ, the gauge group U(W) of the D6 brane theory is broken down to a subgroup by the choice of asymptotic flat connection ρ : Γ = π1(L) → U(W). The choice of the flat connection is the decomposition

$$\widehat{W} = \bigoplus_{k \in \mathcal{I}} \mathbb{C}^{w_k} \otimes \mathcal{R}_k \tag{2.53}$$

of the Chan-Paton space of the D6 brane theory. The gauge group is, therefore, broken down to

$$G_f = \prod_{k \in \mathcal{I}} U(w_k), \tag{2.54}$$

which is perceived by the degrees of freedom on the D2 branes as the flavour symmetry. There might be additional global symmetries, as well as R-symmetries, of geometric origin.

Indeed, the spin cover SU(2) of the rotational symmetry of N acts as the R-symmetry of the quiver theory. At the orbifold point, C <sup>2</sup>/Γ has another SU(2) isometry for general Γ, and SU(2) × U(1) for the A-type Γ = Zr+1.

Resolution of singularities <sup>S</sup><sup>e</sup> is a hyperk¨ahler manifold. Passing from <sup>S</sup> to <sup>S</sup><sup>e</sup> is accompanied by turning on the Fayet-Illiopoulos terms on the D2 worldvolume. The geometric resolution of singularities can be measured by the periods

$$\vec{\zeta_i} = \int_{C_i} \vec{\omega} \tag{2.55}$$

of the triplet of symplectic forms integrated over the compact two-cycles C<sup>i</sup> ≈ S 2 , which correspond to the vertices i ∈ I\{0} of a finite ADE graph. The string background is characterized not only by the geometric parameters ~ζ<sup>i</sup> , but also by the periods

$$\theta_i = \int_{C_i} B \tag{2.56}$$

of the NSNS B-field, as well as the parameters ~ζ<sup>0</sup> corresponding to the trivial representation R0. It appears to correspond to the unnormalized mode of the B-field

$$B \sim \vec{\zeta}_0 \cdot \vec{\omega}. \tag{2.57}$$

The normalizable modes of the RR 3-form C ∼ A~top ∧ ~ω produce the photons of the topological symmetry A<sup>0</sup> ⊂ GC. String theory realizes G<sup>C</sup> as the enhancement of the gauge symmetry in six dimensions, which occurs in the limit of orbifold <sup>S</sup><sup>e</sup> with vanishing <sup>B</sup>-field periods.

In what follows we shall restrict the choices of <sup>S</sup><sup>e</sup> to those having a <sup>U</sup>(1) isometry preserving one of the K¨ahler forms ω<sup>R</sup> and rotating the other two into each other, in other words, phase-rotating <sup>ω</sup>C. In the <sup>A</sup>-type case we have an additional <sup>U</sup>(1)-isometry of <sup>S</sup>e, preserving all three symplectic forms. It corresponds to the nontrivial H<sup>1</sup> of the quiver.

The supersymmetric interfaces we study in this paper correspond to more general supersymmetric profiles of the stacks of D2 and D6 branes.

D-branes wrapping a special Lagrangian submanifold in a Calabi-Yau threefold lead to a supersymmetric theory. Suppose S is a function on Y . It defines a Lagrangian submanifold L in Y × N by:

<span id="page-24-0"></span>
$$x_{\mu} = \frac{\partial S}{\partial y_{\mu}}, \ \mu = 1, 2, 3,$$
 (2.58)

where ~x ∈ N, ~y ∈ Y . Then D(p + 3)-branes wrapping L carry supersymmetric gauge theory in p + 1 dimensions, which can be thought of as hybrid topological-supersymmetric theory in p + 4 spacetime dimensions. The "internal" three dimensional theory is topologically twisted so that the adjoint scalars Xµ, µ = 1, 2, 3 describing the normal bundle to the brane worldvolume inside Y × N are one-forms on L, combining with the gauge fields A<sup>µ</sup> into a complexfied gauge field A + iX. One can actually view the (p + 4)-dimensional theory on L×R p,<sup>1</sup> as the (p+1)-dimensional supersymmetric theory with an infinite dimensional gauge group G = Maps(L, G). The choice of S in [\(2.58\)](#page-24-0) is akin to a D-term condition for the group of volume preserving diffeomorphisms of L.

Starting with the affine A, D, E quiver theory, we can Higgs one of the nodes, in particular 0, to produce the theory corresponding to a finite A, D, E Dynkin diagram. The fate of Dbranes engineering this theory can be guessed by using various string dualities. The fractional <sup>D</sup>2 branes become the ordinary <sup>D</sup>4 branes wrapping the compact cycles <sup>C</sup><sup>i</sup> <sup>⊂</sup> <sup>S</sup>e. The flavor D6 branes become the D4 branes, wrapping non-compact 2-cycles Cˇ<sup>i</sup> , as in [\[104\]](#page-145-8) obeying

$$\check{C}^i \cap C_j = \delta^i_j, \ C_i \cap C_j = a_{ij} - 2\delta_{ij}. \tag{2.59}$$

It is possible to describe these cycles and the corresponding couplings rather explicitly in the <sup>A</sup>r-case. The <sup>A</sup>r-type ALE space <sup>S</sup>e<sup>r</sup> is a Gibbons-Hawking manifold with the metric

$$ds_r^2 = V^{-1} (d\tau + \theta)^2 . + V d\vec{r}^2, \qquad (2.60)$$

with

$$V(\vec{r}) = \sum_{i=0}^{r} \frac{1}{|\vec{r} - \vec{r_i}|}, \ dV = \star_{\mathbb{R}^3} d\theta.$$
 (2.61)

The map ~r : <sup>S</sup>e<sup>r</sup> <sup>→</sup> <sup>R</sup> 3 is the hyperk¨ahler moment map, associated with the U(1) HK isometry, generated by the vector field ∂<sup>τ</sup> .

The compact two-cycles C<sup>i</sup> , i = 1, . . . , r, are the preimages under this map of the straight intervals connecting the poles ~ri−<sup>1</sup> and ~r<sup>i</sup> ,

$$\vec{r}(C_i) = \ell_i = \{ (1-t)\vec{r}_{i-1} + t\vec{r}_i \mid 0 \le t \le 1 \} , \qquad (2.62)$$

while the non-compact 2-cycles Cˇ<sup>i</sup> are the preimages of the semi-axis

$$L_i = \{ \vec{r_i} + (\vec{r_i} - \vec{r_0})t \mid t \ge 0 \} . \tag{2.63}$$

The normalizable 2-forms B<sup>i</sup> ∈ H<sup>2</sup> <sup>L</sup><sup>2</sup> (Se<sup>r</sup>) are given by:

$$\omega_i = da_i, \ a_i = V^{-1}V_i(d\tau + \theta) - \theta_i,$$
(2.64)

where

$$V_i = \frac{1}{|\vec{r} - \vec{r_i}|}, \ dV_i = \star_{\mathbb{R}^3} d\theta_i, \tag{2.65}$$

and the Dirac string for θ<sup>i</sup> is chosen, e.g., along L<sup>i</sup> . The B-field is given by

$$B = \sum_{i=1}^{r} b_i \omega_i \tag{2.66}$$

In wrapping D4-brane on C<sup>i</sup> we generate the effective 2 + 1-dimensional theory with the gauge coupling

<span id="page-26-0"></span>
$$\frac{1}{g_i^2} = \sqrt{|\vec{r}_{i-1} - \vec{r}_i|^2 + b_i^2} \tag{2.67}$$

String theory gives some perspective on the relations between the quiver theories in various dimensions. Compactifying Y and performing T-duality along the compact directions moves us down in spacetime dimension of gauge theory, see the Figure [1](#page-26-0) below.

![](_page_26_Picture_7.jpeg)

Figure 1: Artistic vision of the dual Type IIB setup.

### <span id="page-27-0"></span>3 Vacua and Q-cohomology

In this section we describe the choice of supercharge in the 3d N = 2 algebra, the connection between the Q-cohomology and the space of vacua, and how it is related to the generalized cohomology theories of the target space (in particular, the Higgs branch). There are three interesting supercharges, which can be seen as dimensional uplifts (from 2d N = (2, 2)) of the A model supercharge QA, the B model supercharge QB, and the Ω-deformed A or B model supercharge Q. The latter plays central role in this paper, but the A-type supercharge will also makes appearance in the follow-up work. Also note that while in general Omegabackground deforms the action, the deformation vanishes if we study our theory on the cylinder, with the U(1) isometry being just the cylinder rotation. In this case the action is the flat space one, and the "Omega-deformation" supercharge is simply a special linear combination of the Poincare supercharges. This is precisely our context.

#### <span id="page-27-1"></span>3.1 The choice of supercharges

Consider again our 3d theory on T <sup>2</sup> × R with Euclidean metric, along with its 2d and 1d versions. The tower of reductions 3d → 2d → 1d accompanies our choice of the vector fields V<sup>A</sup> and V<sup>B</sup> on T 2 , generating the action of U(1) × U(1) by isometries. The basis of A and B 1-cycles in H1(T 2 , Z) is represented by the closed orbits of V<sup>A</sup> and VB, respectively. The 2d theory on S 1 <sup>A</sup> × R is obtained by the dimensional reduction along VB, so that S 1 <sup>A</sup> = T <sup>2</sup>/exp RVB, while further reduction along V<sup>A</sup> leads to the definition of the 1d theory on R. The complex structure of T 2 is determined by the parameter τ , so that V<sup>B</sup> − τV<sup>A</sup> is an antiholomorphic vector field (it annihilates the holomorphic coordinate z), so that T <sup>2</sup> ≈ E<sup>τ</sup> = C/ (Z + τZ) .

Choose a basis Q+, Q−, Q+, Q<sup>−</sup> of 3d N = 2 supercharges, such that a pair (Q+, Q+) anticommutes to V<sup>B</sup> −τVA. We say that this basis is adapted to the complex structure of E<sup>τ</sup> . In terms of the adapted basis, a (0, 2) boundary condition along E<sup>τ</sup> (at some fixed y ∈ R) preserves (Q+, Q+). If we reduce to two dimensions, we are left with S 1 <sup>A</sup> ×R. In this context, a complex structure on S 1 <sup>A</sup> ×R, canonically determined by its Euclidean metric and a choice of orientation, becomes important. Thus we might also choose a different basis of 3d N = 2 supercharges, (q+, q−, q+, q−) adapted to the complex structure on S 1 <sup>A</sup> × R, meaning (q+, q+) anticommute to the antiholomorphic vector field along S 1 <sup>A</sup> × R. Its relation to the basis

(Q±, Q±) is a simple <sup>π</sup> 2 rotation:

$$q_{\pm} = \frac{1}{\sqrt{2}}(Q_{+} \pm Q_{-}),$$
  
 $\overline{q}_{\pm} = \frac{1}{\sqrt{2}}(\overline{Q}_{+} \pm \overline{Q}_{-}).$  (3.1)

This basis conveniently matches the standard 2d conventions on S 1 <sup>A</sup> × R, in terms of which the definitions of the A and B model supercharges [\[106,](#page-145-9) [107\]](#page-145-10) are easily lifted to 3d:

$$Q_A = \overline{q}_+ + q_-,$$

$$Q_B = \overline{q}_+ + \overline{q}_-.$$
(3.2)

In terms of (Q±, Q±), the supercharge Q<sup>A</sup> looks rather generic, while the B supercharge is fairly simple,

$$Q_B = \sqrt{2}\,\overline{Q}_+. \tag{3.3}$$

This one is part of the 2d N = (0, 2) subalgebra that preserves E<sup>τ</sup> × {y} ⊂ E<sup>τ</sup> × R, and can be identified with the supercharge of the holomorphic-topological twist in 3d, as considered in [\[108\]](#page-145-11). It was considered earlier in [\[17\]](#page-138-5) in the studies of partially twisted N = 1 four dimensional theories on E<sup>τ</sup> × Σ.

The 3d A-type supercharge is also known in the literature in the context of 3d A-twist [\[109–](#page-145-12)[112\]](#page-146-0), and was also considered earlier in [\[18\]](#page-138-10) in the framework of the general d, d+1, d+2 towers of mixed topological/holomorphic theories.

The Euclidean path integral does not care about which coordinate is called time. However, once we pick a direction and Wick rotate it to the Minkowski signature, we gain extra structure. In fact, the physical unitary QFT is defined in Minkowski signature with a Hilbert space (carrying a unitary inner product) assigned to a space-like slice. With respect to its unitary inner product, there is a notion of conjugation, so that the supercharges obey the following relation

$$B^{-1}Q^{\dagger} = \overline{Q},\tag{3.4}$$

where we suppressed spinor indices, and B is a matrix encoding how gamma matrices behave under the complex conjugation. The choice of B depends on which direction is regarded as timelike, the standard relation being B = iCγ<sup>0</sup> (here C is a charge conjugation matrix, see [\[113\]](#page-146-1) for more details).

In our case, if we Wick rotate the y coordinate into time t, then the space of states on

the spatial slice  $\mathbb{E}_{\tau}$  becomes a Hilbert space which we denote by

$$\mathcal{H}[\mathbb{E}_{\tau}]. \tag{3.5}$$

In our conventions, denoting the corresponding conjugation operation by  $(...)^{\dagger}$ , this choice results in the following relation among the supercharges:

$$Q_{\pm}^{\dagger} = \overline{Q}_{\pm}. \tag{3.6}$$

This can be easily understood: the  $\pm$  notation here refers to the chirality along  $\mathbb{E}_{\tau}$ , and since it has Euclidean signature, the chirality changes sign under the complex conjugation. Notice that with  $\mathbb{E}_{\tau}$  interpreted as a spatial slice, the boundary conditions along  $\mathbb{E}_{\tau}$  coincide with the *initial conditions* in the path integral.

Another choice is to declare  $V_A$  as the vector field generating the Euclidean time translations. By cutting  $T^2$  open along  $S_B^1$  and Wick rotating into Minkowski signature, we get a Hilbert space associated to the spatial cylinder  $S_B^1 \times \mathbb{R}$ . The conjugation following from this choice will be denoted as  $(\dots)^{\tilde{\dagger}}$ . We find the following relation:

<span id="page-29-0"></span>
$$Q_{+}^{\tilde{\dagger}} = \overline{Q}_{+} . \tag{3.7}$$

The  $\pm$  notation here still refers to the 2d chirality along the plane corresponding to the  $\mathbb{E}_{\tau}$  directions. However, now it has Minkowski signature, so the chirality does not change under the conjugation, confirming (3.7). With this choice of time direction, the boundary conditions along  $\mathbb{E}_{\tau}$  have the more conventional meaning of actual boundary conditions on a timelike slice, as opposed to initial conditions.

The latter interpretation is more familiar in the literature [114,115]. In the 2d context, one usually defines A and B branes as those preserving the corresponding supercharges:

A-branes preserve: 
$$Q_A$$
 and  $(Q_A)^{\tilde{\dagger}} = q_+ + \overline{q}_-,$   
B-branes preserve:  $Q_B$  and  $(Q_B)^{\tilde{\dagger}} = q_+ + q_-.$  (3.8)

In particular, we see that in 3d notations,  $\left(\mathcal{Q}_{B}, \left(\mathcal{Q}_{B}\right)^{\tilde{\dagger}}\right)$  correspond to  $(\overline{Q}_{+}, Q_{+})$ . Hence, the B-branes lift to the  $\mathcal{N}=(0,2)$  boundary conditions in 3d  $\mathcal{N}=2$ . It is easy to check that  $\left(\mathcal{Q}_{A}, \left(\mathcal{Q}_{A}\right)^{\tilde{\dagger}}\right)$  correspond to the  $\mathcal{N}=(1,1)$  subalgebra, i.e., A-branes lift to the  $\mathcal{N}=(1,1)$ 

boundary conditions in 3d  $\mathcal{N} = 2$ .

Yet another interesting supercharge, simply denoted by Q, is preserved by both A and B branes:

$$Q = \frac{1}{\sqrt{2}}(Q_A + (Q_A)^{\tilde{\dagger}}) = \frac{1}{\sqrt{2}}(Q_B + (Q_B)^{\tilde{\dagger}}). \tag{3.9}$$

In 3d notation, this supercharge is identified with

$$Q = Q_+ + \overline{Q}_+. \tag{3.10}$$

It indeed belongs to both the  $\mathcal{N}=(0,2)$  and  $\mathcal{N}=(1,1)$  subalgebras. In three dimensions, when acting on fields, it squares to the covariant antiholomorphic derivative in the  $\mathbb{E}_{\tau}$  direction:

$$Q^2 = 2iD_{\overline{z}} . (3.11)$$

Note that this supercharge depends on the choice of complex structure of  $E_{\tau}$ . Since  $\mathcal{Q}$  squares to a spacetime symmetry we shall call it an  $\Omega$ -deformed supercharge. After passing to two dimensions,  $D_{\overline{z}}$  becomes the sum of an infinitesimal isometry of  $S_A^1 \times \mathbb{R}$  plus a central charge. Indeed, such supercharge is used to define the  $\Omega$ -deformed theory in 2d.

To summarize, we have three interesting supercharges in 3d  $\mathcal{N}=2$ : the lift of an Amodel supercharge  $\mathcal{Q}_A$ , the lift of a B-model supercharge  $\mathcal{Q}_B$ , and the lift of the  $\Omega$ -deformed
supercharge  $\mathcal{Q}$ . We mostly work with  $\mathcal{Q}$ , but also occasionally use  $\mathcal{Q}_A$ . Although  $\mathcal{Q}$  is
consistent with both A and B branes, we will only use the B branes, as the A branes break
the  $U(1)_{\hbar}$ .

### <span id="page-30-0"></span>3.2 Properties of Q, $Q_A$ and their cohomology

We are going to act on the Hilbert space  $\mathcal{H}[\mathbb{E}_{\tau}]$  with operators, dressed by the Euclidean time evolution operators, i.e. compressors, as opposed to the unitaries.

Pick a complex supercharge Q. If it is nilpotent,  $Q^2 = 0$ , we may study its cohomology in  $\mathcal{H}[\mathbb{E}_{\tau}]$ , or, more generally, if  $Q^2 = \mathcal{Z} \neq 0$ , the cohomology of Q on  $\ker \mathcal{Z}$ , as is done mathematically in the context of equivariant cohomology. By the usual Hodge theory argument, each Q-cohomology class has a harmonic representative, i.e. an element of  $\ker \{Q, Q^{\dagger}\}$ , where  $\dagger$  uses the Hilbert space structure on  $\mathcal{H}[\mathbb{E}_{\tau}]$ . We may want to find a harmonic representative uniformly across spacetime dimensions, namely also in the Hilbert space  $\mathcal{H}[S^1]$  of the 2d theory, and  $\mathcal{H}[\cdot]$ , or simply  $\mathcal{H}$ , of the 1d theory, with the corresponding supercharges Q

descending from the one in 3d. What is the interpretation of Q-cohomology? Let us first recall how this works in the most basic case of the N = 2 quantum mechanics. There are only two supercharges, which can be taken as conjugates of each other:[1](#page-31-0)

$$\{Q, Q^{\dagger}\} \sim H,\tag{3.12}$$

where H is the Hamiltonian. Thus the cohomology is identified with the space of ground states of H [\[65\]](#page-142-2). If the theory is formulated as an NLSM into some manifold, then it is identified with the usual de Rham cohomology of that manifold when Z = 0, and with the equivariant de Rham cohomology when Z is a nontrivial isometry of the target .

We wish to apply this to our two supercharges, Q and QA. First of all, we check that

$$\{\mathcal{Q}, \mathcal{Q}^{\dagger}\} = \{\mathcal{Q}_A, (\mathcal{Q}_A)^{\dagger}\} = 2H, \tag{3.13}$$

where H is the Hamiltonian acting on H[E<sup>τ</sup> ], i.e., the generator of time translations along R. Thus, the cohomology with respect to either of the two supercharges is identified with the space of supersymmetric vacua in H[E<sup>τ</sup> ]. We can express this fact as the isomorphism of vector spaces

$$H_{\mathcal{Q}}(\mathcal{H}[\mathbb{E}_{\tau}]) \cong H_{\mathcal{Q}_A}(\mathcal{H}[\mathbb{E}_{\tau}]) \cong \mathscr{V}_0,$$
 (3.14)

where V<sup>0</sup> is the space of ground states. However, as we will see, there are additional structures on HQ(. . .) and H<sup>Q</sup><sup>A</sup> (. . .), which are not quite the same. Yet, they turn out to be completely equivalent upon the reduction to 1d.

As already mentioned earlier, the Q supercharge, when acting on various fields, squares to the anti-holomorphic covariant derivative along E<sup>τ</sup> :

<span id="page-31-2"></span>
$$Q^2 = 2iD_{\overline{z}}. (3.15)$$

Thus Q-cohomology should be understood in the equivariant sense, meaning taking the Q-cohomology on the space of states, covariantly holomorphic with respect to both global and local symmetries[2](#page-31-1) . Let us now introduce a background flat flavor connection A<sup>f</sup> on E<sup>τ</sup> . It is gauge equivalent to a connection represented by a constant 1-form valued in the maximal torus of the flavor group. Since it appears in the covariant derivative, it shifts the

<span id="page-31-0"></span><sup>1</sup>More precisely, this is N = (1, 1) quantum mechanics. In the N = (0, 2) quantum mechanics, a central charge may appear.

<span id="page-31-1"></span><sup>2</sup>Physically, setting Z to zero is forced on us by the BPS inequality, since the eigenvalues of H are bounded below by some multiple of the norm kZk.

above equation by −A<sup>f</sup> z . This A<sup>f</sup> z should be thought of as the flavor symmetry equivariant parameter. Notice that, being a flat connection on E<sup>τ</sup> , this parameter is an elliptic variable, as was already discussed in Section [2.1.](#page-9-1) There, we characterized it by

$$a = \frac{1}{\tau} \oint_B A^{\mathbf{f}} - \oint_A A^{\mathbf{f}}.$$
 (3.16)

The exponentiated variable was denoted X, and then separated into x, corresponding to the N = 4 flavor group GH, and ~, corresponding to U(1)~. So indeed, these variables play the role of equivariant parameters.

As a vector space, the Q-cohomology is the space of vacua, but working over the family of backgrounds parametrized by A<sup>f</sup> corresponds to the mathematical equivariant elliptic cohomology. Passing to 2d or 1d does not affect this isomorphism, but it affects the periodicity of equivariant parameters; the equation [\(3.15\)](#page-31-2) gets modified upon reduction to two and one dimensions. In 2d it becomes:

<span id="page-32-1"></span>
$$Q^2 = -(\sigma_1 + D_{\varphi}), \tag{3.17}$$

where ϕ parameterizes the remaining S 1 <sup>A</sup> circle, and like in Section [2.1,](#page-9-1) σ<sup>1</sup> is an extra real scalar in 2d. In 1d we earn another scalar σ2, and the equation [\(3.15\)](#page-31-2) becomes[3](#page-32-0) :

<span id="page-32-2"></span>
$$Q^2 = -(\sigma_1 + i\sigma_2). \tag{3.18}$$

When we turn on the background for flavor symmetries, these σ<sup>1</sup> and σ<sup>2</sup> get shifted by the masses m<sup>1</sup> and m2. In the two-dimensional case [\(3.17\)](#page-32-1), we have a flavor flat connection A<sup>f</sup> ϕ instead of m2. Altogether, we find a (C ×) rk(T) -valued equivariant parameter exp m<sup>1</sup> + i H <sup>A</sup> A<sup>f</sup> in two dimensions, and a C rk(T) -valued equivariant parameter m<sup>1</sup> + im<sup>2</sup> in one dimension. They originate from the (E<sup>−</sup>1/τ ) rk(T) -valued equivariant parameters (x, ~) in 3d. The reader might compare it to the discussion of Section [2.1.](#page-9-1)

As for the Q<sup>A</sup> supercharge, its equivariant parameter is slightly different. In three dimensions, we find:

<span id="page-32-3"></span>
$$Q_A^2 = -i(\sigma_3 + D_\alpha), \tag{3.19}$$

where σ<sup>3</sup> is the real scalar from 3d N = 2 vector multiplet, D<sup>α</sup> is a covariant derivative along the B-cycle (which shrinks in the 2d limit), and we slightly abuse the notation (again) by simply writing σ3, which really means the action by σ<sup>3</sup> in the appropriate representation. Turning on the flavor background corresponds to shifting σ<sup>3</sup> by the real mass m3, and turning

<span id="page-32-0"></span><sup>3</sup>Not to be confused with Pauli matrices

on a flavor holonomy H <sup>B</sup> A<sup>f</sup> . As a result, we obtain a (C ×) rk(T) -valued equivariant parameter exp m<sup>3</sup> + i H <sup>B</sup> A<sup>f</sup> , but now in the context of 3d theory, unlike for the Q supercharge.

Passing to two dimensions, we get:

<span id="page-33-1"></span>
$$(\mathcal{Q}_A)^2 = -i(\sigma_3 + i\sigma_1), \tag{3.20}$$

which is a familiar property of the A-model supercharge. The corresponding equivariant parameter for flavor symmetry m<sup>3</sup> + im<sup>1</sup> is C rk(T) -valued.

Descending further to 1d does not change the Eq. [\(3.20\)](#page-33-1), as it already contains affine equivariant parameters. However, it becomes similar to the equation [\(3.18\)](#page-32-2), which is also written in the 1d context: we see that the R-symmetry rotation in the (σ2, σ3) plane of the (σ1, σ2, σ3) space relates the two supercharges. Therefore, the distinction between Q and Q<sup>A</sup> disappears in 1d, as claimed before.

For completeness, let us briefly mention what observables can be found in the cohomology of the space of local operators for each of the three supercharges in 3d. For QB, there are local observables that form the VOA [\[108\]](#page-145-11), as well as possibly extended operators (Wilson and vortex lines, surface operators). The cohomology of Q<sup>A</sup> contains line operators wrapping the S 1 <sup>B</sup>, as follows from [\(3.19\)](#page-32-3). The basic such line is a Wilson loop (in the representation R):

<span id="page-33-2"></span>
$$\operatorname{Tr}_{R} \operatorname{Pexp} \oint_{S_{B}^{1}} (\sigma \, d\alpha + iA),$$
 (3.21)

but more complicated lines (in general defined by coupling to the worldline quantum mechanics [\[116,](#page-146-4)[117\]](#page-146-5)) also exist. One can also consider QA-invariant surfaces (interfaces) defined by coupling to some 2d N = (1, 1) theory. Finally, because Q<sup>2</sup> = 2iDz, observables in the Q-cohomology must be invariant under the z-translations, which means they can only be surfaces (interfaces) wrapping the E<sup>τ</sup> . A large class of such observables is defined by coupling some 2d N = (0, 2) degrees of freedom on the interface to the bulk. As we will see very soon, other ways to build Q-closed interfaces also exist, and we will explore relations between different constructions in the future work.

### <span id="page-33-0"></span>3.3 Vacua and generalized cohomology

Let us clarify the geometric meaning of the Q and Q<sup>A</sup> cohomology. We start with the simplest case – that of the 1d theory. There, Q and Q<sup>A</sup> are equivalent (related by an Rsymmetry rotation), while the corresponding equivariant parameters are C-valued. This is an N = 8 quantum mechanics, broken to N = 4 by the U(1)<sup>~</sup> twisted mass. Its low-energy description is given by the quantum mechanics on the Higgs branch X, sometimes called a 1d non-linear sigma model (NLSM). Thinking of it as of the N = 2 theory, its Hilbert space is identified with the de Rham complex Ω• (X). Thinking of the family of theories parametrized by the twisted masses and/or background flat connections for flavor symmetries, the space of states can be viewed as Ω• (X) ⊗ S • t, more natural space in the equivariant setting. Were X compact, its Q-cohomology would be identified with the de Rham cohomology H• (X) [\[65\]](#page-142-2). In our story X is never compact, yet, thanks to the equivariant setting, the Q-cohomology is identified with the equivariant de Rham cohomology H• <sup>T</sup>(X), assuming the fixed point set X<sup>T</sup> is compact (it is compact for generic flavor equivariant parameters).

Moving up in dimension, we already know Q and Q<sup>A</sup> are not equivalent in 2d. In particular, Q<sup>A</sup> is the ordinary A-model supercharge. Its equivariant parameter is still C-valued, and its cohomology is interpreted mathematically as quantum equivariant cohomology of X, which is simply H• <sup>T</sup>(X) with the deformed ring structure. The QA-cohomology of local operators is the twisted chiral ring, or the quantum cohomology ring of X. The QA-cohomology of states is just the space of Ramond vacua on the circle. We can generate the QA-cohomology classes in H[S 1 ] by starting with the boundary states |Bi for A-branes B, then evolving them in Euclidean time T > 0, thus regularizing the otherwise unphysical states |Bi that initially do not belong to H[S 1 ] (see Appendix [B](#page-130-0) for a discussion). If one generates boundary conditions by coupling to the Chan-Paton vector bundles, one obtains a map from the equivariant K-theory into the QA-cohomology of H[S 1 ], i.e., ch : KT(X) → HT(X).

The Q supercharge, however, has C <sup>×</sup>-valued equivariant parameters in 2d. It is thus more natural to think of its cohomology as KT(X). There is a map from KT(X), thought of as classifying boundary conditions in 2d, to the Q-cohomology of states. Both this map and ch above involve quotient by the torsion, as the space of vacua is simply the C-vector space. When the fixed points X<sup>T</sup> of the T-action on X are isolated, one trivially sees that the space of vacua is isomorphic to KT(X) ⊗ C. Indeed, on the one hand, the fixed points are in one-to-one correspondence with the massive vacua (that exist when we turn on generic large equivariant parameters). On the other hand, the equivariant localization ensures that fixed points provide a basis in KT(X) ⊗ C. Thus the isolated massive vacua can be thought of as the basis in KT(X) ⊗ C. This argument also applies to HT(X), the only apparent distinction between the two cases being the C or C <sup>×</sup> valuedness of the equivariant parameter. HT(X) and KT(X) also differ in the structure of pushforward, which is especially transparent in the "sigma-model" view on K-theory, where we interpret KT(X) as the S 1 -equivariant cohomology of the loop space, HT×S<sup>1</sup> (LX). Here the circle group acts by rotating the loops, its equivariant parameter naturally identified with <sup>1</sup> R , the KK mass. Then pushforward of a K-theory class with respect to a map X → Y corresponds to the pushforward of the cohomology class via the map LX → LY . The latter means integrating over the loop space <sup>L</sup>( a fiber of <sup>X</sup> <sup>→</sup> <sup>Y</sup> ), which produces the relative <sup>A</sup>b-genus.

The explanation via the fixed points does not quite work when the fixed locus X<sup>T</sup> is positive-dimensional. However, we assume that the space of vacua is still KT(X) ⊗ C in such cases, at least when X<sup>T</sup> is compact. This assumption follows from the sigma-model viewpoint sketched earlier. Also, shrinking the circle corresponds to the 1d limit, in which we know rigorously that the space of vacua is HT(X). The K-theory, intuitively, degenerates to the cohomology in the limit.

Now move to three dimensions. In fact, we could start there and argue that the rest follows by reduction. In 3d, the supercharge Q<sup>A</sup> has C <sup>×</sup>-valued equivariant parameters, and its operator cohomology contains line operators, such as Wilson loops [\(3.21\)](#page-33-2). Their product gives rise to the quantum equivariant K-theory of X, which is the same as KT(X) with the deformed product. It appears that this suggestion was first made in [\[118\]](#page-146-6). It was studied in [\[119\]](#page-146-7) (see also [\[120\]](#page-146-8)), where the main idea was to compute the cigar index C ×<sup>ε</sup> S 1 in 3d, write the difference operators that insert QA-closed Wilson loops (like [\(3.21\)](#page-33-2)) at the tip of the cigar, and identify this whole structure with what is found in the quantum (permutationsymmetric) K-theory of [\[121\]](#page-146-9). Observables are inserted at the tip of the cigar due to the twist by ε, the analog of Ω-deformation [\[122\]](#page-146-10). Furthermore, the A-twisted 3d theory is the setting for the K-theoretic count of quasimaps in [\[123\]](#page-147-0).

We could also look at the QA-cohomology of states. By analogy with the 2d case, we can generate it by the appropriate set of boundary states (regularized by the Euclidean evolution), coming from the A-branes on T 2 , which is the boundary of C ×<sup>ε</sup> S 1 . Again by analogy with the 2d case, such boundary conditions can be thought of as generated by couplings to the Chan-Paton bundles on LX, the free loop space of X. The boundary degrees of freedom living on T <sup>2</sup> are like the quantum mechanics into LX. Thus one expects to find that the boundary conditions are classified by

<span id="page-35-0"></span>
$$K_{\mathbf{T}\times S^1}(LX)\otimes_{\mathbb{Z}[q^{\pm 1}]}\mathbb{C}(q)\cong K_{\mathbf{T}}(X)\otimes\mathbb{C}(q),$$
 (3.22)

the equivariant K-theory of LX, additionally equivariant with respect to the loop rotations S 1 . By localization, it is related to the right hand side in [\(3.22\)](#page-35-0): everything is expected to localize on constant loops, and an additional factor of C(q) contains the equivariant parameter for loop rotations, which is, basically, the exponential of ε (up to a constant factor). This supports identifying the QA-cohomology, or the space of vacua, with the equivariant K-theory. Additionally, when X<sup>T</sup> is a discrete set of points, the argument about isolated massive vacua provides extra support for this claim.

It has been long suspected that the S 1 -equivariant K-theory on the loop space is related to the elliptic cohomology [\[124,](#page-147-1) [125\]](#page-147-2). See for example [\[126,](#page-147-3) [127\]](#page-147-4), where the left hand side of [\(3.22\)](#page-35-0) (with C(q) replaced by Z[q −1 ][[q]]) is used to define the completed version of S 1 equivariant K-theory on LX, which is then connected to the elliptic cohomology (with the Tate curve taken as the elliptic curve in their case). Presumably, such understanding is more general than presented here (see e.g. [\[128\]](#page-147-5) and [\[129\]](#page-147-6)). In the case of the Q<sup>A</sup> supercharge in three dimensions, we nevertheless prefer the interpretation in terms of KT(X), which is heuristically dictated by the fact that the equivariant parameters are C <sup>×</sup>-valued. One could however argue that the boundary conditions in 3d are naturally labeled by the elliptic cohomology, in the sense of KS<sup>1</sup> (LX), and [\[119\]](#page-146-7) coin the term elliptic or "E-branes" for this very reason.

Finally, for the supercharge Q in three dimensions, the equivariant parameters are elliptic, associated to a fixed elliptic curve E<sup>−</sup>1/τ in the notations of Section [2.1.](#page-9-1) In this case a natural interpretation for the Q-cohomology is in terms of the equivariant elliptic cohomology EllT(X). We follow the approach of [\[52\]](#page-141-2) (see also references therein), in which EllT(X) is a scheme. Since the Q-cohomology (of states) is just a vector space, we have to explain in what sense it is related to this scheme. As it turns out, this vector space is related to fibers of a certain line bundle over EllT(X). In the rest of this subsection, we will discuss this question in greater detail.

Spectral manifolds and cohomology. Consider the simple case where the generic equivariant parameters correspond to a symmetry subgroup leaving only the isolated fixed points in X. Ordinary equivariant cohomology HT(X), considered as a ring, defines an affine scheme Spec HT(X), with fixed points in X corresponding to irreducible components in Spec HT(X). Passing to C <sup>×</sup>-valued variables via the exponentiation map, one obtains Spec KT(X), also an affine scheme. In the elliptic case, EllT(X) is defined as a scheme itself, which is seen as a reduction of Spec KT(X) mod q. It is not affine, however, so there is no ring whose Spec it would be. It is still true that its irreducible components correspond to the points in X fixed by T.

What is the meaning of the schemes we mention above? Suppose we are interested in  $H_{\mathbf{T}}(X)$  in the context of a 2d theory, i.e., in the  $\mathcal{Q}_A$  cohomology. The ring relations encoded in the effective twisted superpotential  $\widetilde{W}(\Sigma)$  of the 2d theory are known to be

$$\exp\left(\frac{\partial \widetilde{W}}{\partial \Sigma}\right) = 1. \tag{3.23}$$

These are solved, roughly, by  $\Sigma^{(i)} = F_i(x,t)$ , i = 1..n, expressing complex Cartan-valued scalars in the 2d  $\mathcal{N} = (2,2)$  gauge multiplets in terms of equivariant and Kähler parameters, x and t. The number n of solutions is precisely the number of massive vacua. If we want to consider "ordinary" (not quantum) cohomology, then we simply send  $t \to +i\infty$ , i.e., take the large-volume limit of X. The scheme  $\operatorname{Spec} H_{\mathbf{T}}(X)$  can be seen as the graph of these solutions. The 3d case (compactified on a finite circle), with the same supercharge  $Q_A$ , is not very different. Now the same equation  $\exp(\partial \widetilde{W}/\partial \Sigma) = 1$  encodes relations in the appropriate quantum K-theory of X, and  $\Sigma$  are the  $\mathbb{C}^\times$ -valued variables containing real scalars and gauge holonomies along  $S^1$ . Again, taking the FI parameters to infinity, one gets back the classical relations. These relations determine  $\operatorname{Spec} K_{\mathbf{T}}(X)$ , which is an n-component scheme. Schematically, this looks as follows:

<span id="page-37-0"></span>![](_page_37_Figure_3.jpeg)

Figure 2: The horizontal axis here represents background equivariant parameters. The vertical axis represents gauge parameters of the similar nature, e.g., gauge holonomies on  $\mathbb{E}_{\tau}$  in the elliptic case. The collection of lines represents either Spec  $H_{\mathbf{T}}(X)$ , or Spec  $K_T(X)$ , or  $\mathrm{Ell}_{\mathbf{T}}(X)$ . Each line corresponds to a massive vacuum, i.e., a fixed point in  $X^{\mathbf{T}}$ .

The collection of lines in this picture represents a scheme over the base parameterized by the equivariant parameters for the torus T of global symmetries.

We want to have a similar understanding of the  $\mathcal{Q}$ -cohomology. In 1d, as we know, it is isomorphic to the  $\mathcal{Q}_A$  case, and we simply get the ordinary equivariant cohomology  $H_{\mathbf{T}}(X)$ . Indeed, any possible instanton corrections represented by holomorphic curves in 2d, do not exist in 1d. The equations that determine the spectral manifold are the same as in the large-volume limit in 2d. They describe the classical Spec  $H_T(X)$  illustrated in Figure 2.

Physically, these equations simply determine classical values of the vector multiplet scalars in various vacua. In other words, Spec  $H_{\mathbf{T}}(X)$  describes the classical vacua in 1d.

**Example:** consider  $X = T^*\mathbb{C}P^{n-1}$ . The flavor equivariant parameters are  $x_i$ ,  $i = 1, \ldots, n$ , such that  $\sum_i x_i = 0$ . Additionally, we have an equivariant parameter  $\hbar$  for  $U(1)_{\hbar}$  that rotates the fiber. Denoting the gauge parameter by s, we get that  $\operatorname{Spec} H_{\mathbf{T}}(X)$  is described by

$$\prod_{i=1}^{n} (s+x_i) = 0. (3.24)$$

Physically, it is more natural to write this as

$$\prod_{i=1}^{n} \left( s + x_i + \frac{\hbar}{2} \right) = 0, \tag{3.25}$$

which differs by a shift of s. The reason is that in this case s has a meaning of the complex scalar in the 1d  $\mathcal{N}=4$  dynamical vector multiplet (which also has a real scalar). The corresponding theory has hypermultiplets  $(I_i, J_i)$ , i=1..n, and  $U(1)_{\hbar}$  rotates both  $I_i$  and  $J_i$  with charge  $\frac{1}{2}$ . The i-th fixed point in the base of  $T^*\mathbb{C}P^{n-1}$  is characterized by the vev  $I_j = \sqrt{\zeta}\delta_{ij}$ , and the total (gauge + flavor +  $U(1)_{\hbar}$ ) weight of the field getting a vev must vanish. The total weight of  $I_i$  is  $(s+x_i+\frac{\hbar}{2})$ , which is indeed what we find in the above product. We see that the equation describes n irreducible components,  $s=-x_i-\hbar/2$ ,  $i=1,\ldots,n$ , which correspond to the n fixed points.

Moving up to 2d, equivariant parameters become multiplicative. The classical description can be obtained from the 1d answer given above simply by rewriting equations in the multiplicative way. For example, in the  $T^*\mathbb{C}P^{n-1}$  case, Spec  $K_{\mathbf{T}}(X)$  is simply

$$\prod_{i=1}^{n} (sx_i \hbar^{\frac{1}{2}} - 1) = 0. \tag{3.26}$$

This again describes the classical vacua: equations like  $sx_i\hbar^{1/2}=1$  are the classical conditions saying that s cancels the effect of  $x_i\hbar^{1/2}$  in the i-th vacuum. In two dimensions on  $\mathbb{R} \times S^1$ , these parameters are  $\mathbb{C}^\times$ -valued, combining the holonomy around the circle and the imaginary part of the vector multiplet scalar (the one descending from the gauge field in 3d). Again, like on the Figure 2, for a chosen point in the base, i.e., for given equivariant parameters, there are n points above it corresponding to the massive vacua  $s=x_i^{-1}\hbar^{-1/2}$ . This also describes massive vacua quantum mechanically, because the action is  $\mathcal{Q}$ -exact, including the superpotentials, so the  $\mathcal{Q}$ -cohomology can be analyzed in the UV. The i<sup>th</sup>

vacuum is given by a wave functional peaked around the i th irreducible component s = x −1 <sup>i</sup> ~ −1/2 . We can say that the corresponding vector in KT(X) is the class of the structure sheaf of this irreducible component.

Moving up to 3d, the story repeats itself, except that now we should take all variables mod q, reflecting that E<sup>−</sup>1/τ is C <sup>×</sup>/q. Now the base in Figure [2](#page-37-0) is identified with ET, the space of elliptic equivariant parameters. We still have n points in the fiber over a point in the base, corresponding to n isolated massive vacua. As we vary the base point, they assemble into the scheme EllT(X). Each irreducible component of it is just a copy of ET, and this whole picture encodes the classical description of vacua. In the quantum 3d theory, however, due to non-perturbative effects, it is natural and necessary to also include the K¨ahler parameters z ∈ EA<sup>0</sup> that couple to the topological symmetry. Therefore, one considers

$$E_{\mathbf{T}}(X) = Ell_{\mathbf{T}}(X) \times \mathcal{E}_{\mathbf{A}'}$$
(3.27)

as a scheme over E<sup>T</sup> × EA<sup>0</sup>. Because neither EllT(X) nor ET(X) are affine, there is no usual "cohomology ring", whose spectrum would be EllT(X) or ET(X). Rather, one looks at sheaves or bundles on these schemes.

In fact, there is a natural way to obtains such bundles in quantum theory, where each massive ground state is associated with a one-dimensional vector space C. This works similarly in all three cases: elliptic, K-theoretic, and cohomological. The vector space of supersymmetric vacua has a fixed dimension n, and changing equivariant (and K¨ahler in the 3d case) parameters, we obtain a rank-n bundle over the parameter space. In the Figure [2,](#page-37-0) this bundle is over the base. In the cohomological or K-theoretic cases, the bundle can be identified with the pushforward of the structure sheaf upstairs (i.e., on the scheme Spec HT(X) or Spec KT(X)) to the base. The resulting fiber is just HT(X) or KT(X), which we know to be the space of vacua. The elliptic case is similar: The bundle of vacua on E<sup>T</sup> × EA<sup>0</sup> can be understood as the pushforward of a certain line bundle L from ET(X). This line bundle, when pulled back to an irreducible component j of ET(X), becomes the massive vacuum number j fibered over the space of parameters E<sup>T</sup> × EA<sup>0</sup>.

### <span id="page-39-0"></span>3.4 The bundle of vacua in the elliptic case

Let us understand the bundle of vacua over E<sup>T</sup> × EA<sup>0</sup> slightly better, relying on [\[130\]](#page-147-7). For fixed equivariant parameters, the fiber of this bundle is the subspace of ground states in the Hilbert space H[E<sup>τ</sup> ]. Suppose |Ψi is an abstract state corresponding to a vacuum. We can formally characterize it by its wave functional. To do that, choose a polarization of the classical phase space P[E<sup>τ</sup> ] associated to the spatial slice E<sup>τ</sup> . The wave functional for a state |Ψi "written in the polarization" can be understood as an overlap hB|Ψi ≡ Ψ[B] with the boundary state engineered by the boundary condition B that fixes values of the fields, or their normal derivatives, according to the polarization. As we will see, we can characterize ground states by evaluating their wave functionals against the special SUSY boundary conditions.

Both |Ψi and hB| carry topological data, meaning they are sections of some bundles over E<sup>T</sup> × EA<sup>0</sup>. Hence one could say that |Ψi is a section of an abstract bundle of vacua, while hB|Ψi is a section relative to the polarization. The latter is what we need for our applications, so both pieces of topological data are necessary.

Ground state |Ψi. To determine the topological data in |Ψi, we need to know what happens as we go around the cycles of E<sup>T</sup> × EA<sup>0</sup>, i.e., under the large T × A<sup>0</sup> -gauge transformations which shift the 1-forms representing the background flat connections by periods of the elliptic curve E<sup>τ</sup> :

<span id="page-40-0"></span>
$$x_i \mapsto qx_i, \quad \text{or} \quad \hbar \mapsto q\hbar, \quad \text{or} \quad z_k \mapsto qz_k.$$
 (3.28)

Here (x<sup>i</sup> , ~) are the monodromy parameters of flavor flat connections on E<sup>τ</sup> , which are elliptic equivariant variables and also coordinates on ET. Likewise, z<sup>k</sup> are topological flat connections on E<sup>τ</sup> (K¨ahler variables), which are also coordinates on EA<sup>0</sup>.

Assume that there are n isolated massive vacua |Ψ1i, . . . , |Ψni. Upon the transport [\(3.28\)](#page-40-0), the complex lines C|Ψ<sup>j</sup> i are preserved. The basis state |Ψ<sup>j</sup> i is multiplied by a phase:

$$|\Psi_j\rangle \mapsto e^{i\theta_j}|\Psi_j\rangle$$
 (3.29)

However, the unitary transformation above would not preserve the holomorphy in x<sup>i</sup> 's. There is a choice of counterterms enforcing holomorphy, which would make θ<sup>j</sup> 's complex. We would like to determine them.

Start with |Ψ<sup>j</sup> i at time t = 0, and let x, z, ~ change adiabatically, such that |Ψ<sup>j</sup> (t))i is the ground state at each instance of time. In the process, the Berry phase may be generated. At some large time t = β, we assume

$$x_i(\beta) = q^{n_i} x_i(0) ,$$

$$z_a(\beta) = q^{m_a} z_a(0) ,$$

$$\hbar(\beta) = q^{n_h} \hbar(0)$$
(3.30)

with integer n's, m's and n~. Let us denote the transported state |Ψ<sup>j</sup> i by |Ψ q j i. We close the Euclidean time to S 1 β and compute the E<sup>τ</sup> × S 1 <sup>β</sup> partition function in the large-β limit. The leading contribution in this limit comes from the isolated ground states, and is given by:

$$Z_{\mathbb{E}_{\tau} \times S_{\beta}^{1}} = \sum_{j=1}^{n} \langle \Psi_{j}^{q} | \Psi_{j} \rangle + O(e^{-\beta \times \#}). \tag{3.31}$$

From the point of view of effective field theory, each gapped vacuum contributes to the E<sup>τ</sup> × S 1 <sup>β</sup> partition function via its effective Chern-Simons (CS) term (generated by massive degrees of freedom). Indeed, only topological terms survive in the large-β limit. Hence we obtain

$$e^{i\theta_j} = \langle \Psi_j^q | \Psi_j \rangle = e^{-S_{\text{CS}}^{(j)}}, \tag{3.32}$$

where we also assume vacua to be normalized. So the effective CS term in the j-th vacuum characterizes the topology of |Ψ<sup>j</sup> i. More precisely, it was shown in [\[130\]](#page-147-7) that the effective CS term determines the Berry connection for |Ψ<sup>j</sup> i, such that the Chern class of the vacuum bundle is equal to the effective CS level. To read off the Berry connection, all we need to do is evaluate S (j) CS on the background field configuration that consists of flat connections za, ~, x<sup>i</sup> on E<sup>τ</sup> that change slowly from these values to q <sup>m</sup>aza, q<sup>n</sup><sup>~</sup> ~, q<sup>n</sup>ix<sup>i</sup> as we go around S 1 β , generating a nontrivial flux.

The specific formula for Berry connection coincides with the standard family index formula [\[131\]](#page-147-8). In terms of holonomy of the global symmetry flat connection along the A and B cycles of E<sup>τ</sup> , denoted a i <sup>A</sup> and a i <sup>B</sup>, and the effective CS levels kij , i, j = 1, . . . , f, the Berry connection local one-form reads

$$B = \frac{k_{rs}}{4\pi} \left( \log \left( a_A^r \right) \operatorname{dlog} \left( a_B^s \right) - \log \left( a_B^r \right) \operatorname{dlog} \left( a_A^s \right) \right). \tag{3.33}$$

In agreement with the family index theory, the curvature of B is a pushforward of the the anomaly polynomial four-form <sup>1</sup> 4π krsF <sup>r</sup> ∧ F s .

The (0, 1)-part of B determines a holomorphic structure (has curvature of type (1, 1)),

and the holomorphic sections were described in [\[130\]](#page-147-7) as

$$e^{\frac{i}{4\pi(\overline{\tau}-\tau)}k_{rs}\log(a^r)\log(a^s\overline{a}^s)}\Theta(a), \qquad (3.34)$$

where

$$a_r = a_B^r \left( a_A^r \right)^\tau \,,$$

are holomorphic coordinates on E<sup>T</sup> × EA<sup>0</sup>. The transformation properties of Θ are

<span id="page-42-0"></span>
$$\Theta(qa_r) = q^{-\frac{k_{rr}}{2}} \prod_s a_s^{-k_{rs}} \Theta(a), \qquad (3.35)$$

where only the r'th variable is shifted. One can easily construct such Θ(a)'s from the familiar theta functions. Holomorphic sections naturally appear in 3d as supersymmetric partition functions in the presence of a boundary E<sup>τ</sup> with N = (0, 2) boundary conditions (such as overlaps hB|Ψi, interval partition functions, or half-indices). They also appear as elliptic genera of 2d theories [\[132\]](#page-147-9). The state |Ψpi can also be mimicked by a half-BPS elliptic boundary condition Dp, at least for the purposes of BPS computations. It creates a boundary state |Dpi, which is not normalizable, yet the finite Euclidean evolution turns it into a normalizable half-BPS state e <sup>−</sup>T H|Dpi (see Appendix [B\)](#page-130-0) that is Q-cohomologous to the vacuum |Ψpi. The states |Ψpi and e <sup>−</sup>T H|Dpi should have "the same topology", i.e., be sections of the isomorphic line bundles over E<sup>T</sup> ×EA<sup>0</sup>. For e <sup>−</sup>T H|Dpi, the topology is captured by the boundary 't Hooft anomalies of D<sup>p</sup> [\[130\]](#page-147-7). This means that the Chern class of the line bundle spanned by e <sup>−</sup>T H|Dpi agrees with the anomaly polynomial of Dp. Thus the latter must agree with the effective CS term in the vacuum |Ψpi (this can also be understood via the inflow).

When the vacuum |Ψpi is fully gapped via the real masses, such boundary conditions can be easily constructed. They are sometimes called thimble boundary conditions [\[88,](#page-144-3)[114\]](#page-146-2) and are realized via the exceptional Dirichlet boundary conditions in gauge theory [\[88\]](#page-144-3) (they have also played role in the recent papers [\[133,](#page-147-10) [134\]](#page-147-11)). Since the state |Ψpi is an "in" state, the corresponding boundary conditions have to be imposed at the past boundary at some y = y<sup>−</sup> < 0. In this case, the boundary conditions are constructed as follows. The matter representation R is split into

$$\mathcal{R} = \mathcal{R}_{+}(p) \oplus \mathcal{R}_{-}(p) \oplus \mathcal{R}_{0}(p), \tag{3.36}$$

where  $\mathcal{R}_{\pm}(p)$  receive positive/negative real masses in the vacuum p respectively. Then the corresponding chiral multiplets are given boundary conditions according to:<sup>4</sup>

$$\mathcal{R}_{+}(p), \quad \overline{\mathcal{R}}_{-}(p): \qquad (0,2) \text{ Dirichlet},$$

$$\mathcal{R}_{-}(p), \quad \overline{\mathcal{R}}_{+}(p): \qquad (0,2) \text{ Neumann}.$$
(3.37)

As for  $\mathcal{R}_0(p) \oplus \overline{\mathcal{R}}_0(p)$ , they are the matter fields that can receive vevs in the vacuum p. More precisely, we split

$$\mathcal{R}_0(p) = \mathcal{R}_0^D(p) \oplus \mathcal{R}_0^N(p), \tag{3.38}$$

such that  $\mathcal{R}_0^D(p) \oplus \overline{\mathcal{R}}_0^N(p)$  contains all chirals that receive vevs.<sup>5</sup> Then we assign boundary conditions:

 $\mathcal{R}_0^D(p), \quad \overline{\mathcal{R}}_0^N(p): \qquad (0,2)$  Dirichlet with boundary values given by the vevs,  $\mathcal{R}_0^N(p), \quad \overline{\mathcal{R}}_0^D(p): \qquad (0,2)$  Neumann.

(3.39)

Finally, the vector multiplets are assigned Dirichlet boundary conditions, with the boundary flat connection corresponding to the vacuum p (i.e., the one consistent with the vevs of matter fields):

$$s = s^{(p)}(x,\hbar). \tag{3.40}$$

In Section 6.2 we will discuss such boundary conditions in greater detail. For now, let us compute the boundary 't Hooft anomalies and read off the topology of  $|\Psi_p\rangle$ .

Since 't Hooft anomalies are RG invariants, it is most convenient to determine them in the UV description. As reviewed in Section 2.1, there is only one CS term present in the UV: The BF coupling (2.12) between the center of the gauge group and the topological symmetry  $\mathbf{A}'$ . It contributes to the boundary anomaly via the inflow. The rest of boundary anomalies are computed as in [89,133]. Denote the (boundary) gauge field strength by  $\mathbf{f}$ , the 3d  $\mathcal{N}=2$  R-symmetry gauge field strength by  $\mathbf{r}$ , the  $U(1)_{\hbar}$ , flavor, and topological field strengths by  $\mathbf{f}_{\hbar}$ 

<span id="page-43-0"></span><sup>&</sup>lt;sup>4</sup>It is important that we are working with the "past" boundary here, i.e., at  $y = y_{-}$  of, say,  $(y_{-}, \infty)$ . For the thimble boundary conditions defined at the "future" boundary, the Dirichlet and Neumann boundary conditions on  $\mathcal{R}_{\pm}(p)$  must be swapped.

<span id="page-43-1"></span><sup>&</sup>lt;sup>5</sup>It might happen that some of the hypermultiplets in  $\mathcal{R}_0(p)$  do not get vevs at all, in which case they are distributed among  $\mathcal{R}_0^D(p)$  and  $\mathcal{R}_0^N(p)$  arbitrarily, as a matter of choice. We will ignore this possibility for now.

fx, and fz, respectively. Three-dimensional chirals in L<sup>p</sup> = R+(p) ⊕ R−(p) ⊕ R<sup>D</sup> 0 (p) ⊕ R N 0 (p) obey (0, 2) Dirichlet boundary conditions and contribute <sup>1</sup> <sup>2</sup>Tr <sup>L</sup><sup>p</sup> (f + f<sup>x</sup> + 1 2 f<sup>~</sup> − 1 2 r) 2 to the anomaly polynomial, while the remaining ones in the conjugate representation L<sup>p</sup> obey Neumann, and contribute − 1 <sup>2</sup>Tr <sup>L</sup><sup>p</sup> (f + f<sup>x</sup> + 1 2 f<sup>~</sup> − 1 2 r) 2 , where the weights in L<sup>p</sup> are opposite of those in Lp. The notation Tr <sup>L</sup><sup>p</sup> means summation both over the gauge and flavor weights in Lp. Together, these almost cancel each other, leaving behind only

$$(\mathbf{f}_{\hbar} - \mathbf{r}) \operatorname{Tr}_{\mathcal{L}_p} (\mathbf{f} + \mathbf{f}_x).$$
 (3.41)

The adjoint chiral Φ obeys Dirichlet boundary conditions, and contributes <sup>1</sup> <sup>2</sup>Tr adj(f + f~) 2 . Finally, the 3d N = 2 vector multiplet with Dirichlet boundary conditions contributes − 1 <sup>2</sup>Tr adjf <sup>2</sup> − |G| 2 r 2 .

Also note that the G symmetry is completely broken at the boundary. First, Dirichlet boundary conditions on the gauge fields only leave G as a global symmetry at the boundary. Second, the boundary vevs (corresponding to the isolated vacuum) further break this global G symmetry. Thus f should not be present in the anomaly polynomial as the corresponding global symmetry is absent. It should instead be expressed through f<sup>x</sup> and f~, which we write as f = f (p) (fx,f~) (see, e.g., the Appendix of [\[133\]](#page-147-10) for such a computation)[6](#page-44-0) . This expression is found by solving the system of linear equations of the form:

$$w(\mathbf{f} + \mathbf{f}_x + \mathbf{f}_{\hbar}) = 0, \quad w \in \mathcal{R}_0^D(p) \oplus \overline{\mathcal{R}}_0^N(p),$$
 (3.42)

where w are the matter weights that receive vevs in the vacuum p. In other words, the total field strength must vanish for such weights, which determines f in terms of f<sup>x</sup> and f~.

Altogether, the boundary anomaly polynomial is

$$P[\mathscr{D}_p] = (\mathbf{f}_{\hbar} - \mathbf{r}) \operatorname{Tr}_{\mathcal{L}_p} (\mathbf{f} + \mathbf{f}_x) + \frac{|G|}{2} \mathbf{f}_{\hbar}^2 - \frac{|G|}{2} \mathbf{r}^2 - 2 \operatorname{Tr} (\mathbf{f} \mathbf{f}_z), \quad \text{with } \mathbf{f} = f^{(p)}(\mathbf{f}_x, \mathbf{f}_{\hbar}), \quad (3.43)$$

where the last term in P[Dp] is the inflow effect due to the BF action [\(2.12\)](#page-12-0). The full anomaly polynomial also contains mixed global-gravitational anomalies, which can be deduced from [\[135\]](#page-147-12), but we do not need them for our purposes.

The four-form P[Dp] agrees (via P = d(CS)) with the effective background CS term in the vacuum p (such CS terms can be found in [\[130\]](#page-147-7)). Thus, using the effective CS levels encoded in P[Dp], we can use our recipe [\(3.35\)](#page-42-0) and find how |Ψpi transforms under [\(3.28\)](#page-40-0).

<span id="page-44-0"></span><sup>6</sup>The functional forms of f (p) (fx,f~) and s (p) (x, ~) coincide, i.e., this is the same function.

To write the result, let us first introduce some notations. Let us temporarily treat the gauge fugacity (flat connection) s ∈ Hom(π1(E<sup>τ</sup> ), H)/W as an independent variable (even though in the vacuum p we have s = s (p) (x, ~)). It is an elliptic variable as well, s = e 2πih , h ∈ h<sup>C</sup> mod Q<sup>∨</sup>⊕τQ<sup>∨</sup> . Let v = (v1, . . . , vrk(G)) be some gauge coweight and w = (w1, . . . , wrk(GH)) be a flavor coweight. Also let ca, a = 1..rk(A<sup>0</sup> ) be gauge group characters picking out the U(1) factors in the gauge group, such that s ca is a fugacity for the a-th abelian factor in G. Then the transformation properties are written as:

<span id="page-45-0"></span>
$$z_{a} \mapsto q z_{a} : \quad \Psi_{p} \mapsto s^{c_{a}} \Psi_{p}$$

$$s \mapsto q^{\mathbf{v}} s : \quad \Psi_{p} \mapsto \hbar^{-\frac{1}{2} \sum_{\mathcal{L}_{p}} \langle \mathbf{v}, w \rangle} \prod_{a=1}^{\operatorname{rk}(\mathbf{A}')} z_{a}^{\langle \mathbf{v}, c_{a} \rangle} \Psi_{p}$$

$$x \mapsto q^{\mathbf{w}} x : \quad \Psi_{p} \mapsto \hbar^{-\frac{1}{2} \sum_{\mathcal{L}_{p}} \langle \mathbf{w}, f \rangle} \Psi_{p}$$

$$\hbar \mapsto q^{2} \hbar : \quad \Psi_{p} \mapsto \hbar^{-|G|} q^{-|G|} \prod_{(w, f) \in \mathcal{L}_{p}} \left( s^{-w} x^{-f} \right) \Psi_{p}, \tag{3.44}$$

from which the true transformations of |Ψpi follow simply by the specialization s = s (p) (x, ~).

It is also not hard to write a model meromorphic section that transforms as [\(3.44\)](#page-45-0). For that, define (following the conventions of [\[52\]](#page-141-2))

<span id="page-45-1"></span>
$$\vartheta(x) = (x^{1/2} - x^{-1/2}) \prod_{n>0} (1 - q^n x)(1 - q^n / x), \tag{3.45}$$

which obeys

$$\vartheta(q^k x) = (-1)^k q^{-k^2/2} x^{-k} \vartheta(x), \quad k \in \mathbb{Z}. \tag{3.46}$$

Then the following

<span id="page-45-2"></span>
$$\prod_{(w,f)\in\mathcal{L}_p} \frac{\vartheta(s^w x^f \hbar^{1/2})}{\vartheta(s^w x^f)\vartheta(\hbar^{1/2})} \times \vartheta(\hbar^{1/2})^{2|G|} \times \prod_{a=1}^{\operatorname{rk}(\mathbf{A}')} \frac{\vartheta(s^{c_a})\vartheta(z_a)}{\vartheta(s^{c_a} z_a)}$$
(3.47)

transforms as [\(3.44\)](#page-45-0). This is an example of Θ as in [\(3.35\)](#page-42-0). It is a section of a certain line bundle L on ET(X) = EllT(X)× EA<sup>0</sup>. Specialization s = s (p) (x, ~) means taking its pullback to the p-th irreducible component of ET(X), where we obtain a line bundle that the state |Ψpi is valued in.

An alternative way to derive the same result [\(3.44\)](#page-45-0) is to construct a 2d (0, 2) theory that has the same anomaly polynomial P[Dp], write its elliptic genus, and see how it transforms. Below we will outline this alternative derivation for the contribution of  $\langle \mathcal{B}|$ .

**Polarization.** Now let us discuss the contribution of  $\langle \mathcal{B}|$ . We choose an  $\mathcal{N}=(2,2)$ -preserving polarization on the phase space, in the sense of [136].<sup>7</sup> With the description of  $\mathcal{N}=(2,2)$  boundary conditions reviewed in Section 2.1, it is also clear how to obtain  $\mathcal{N}=(2,2)$  invariant polarizations in gauge theory. For the hypermultiplets, to define such polarization on the (infinite-dimensional) phase space, we first choose a polarization on the (finite-dimensional) holomorphic symplectic manifold  $T^*\mathcal{R}$  they are valued in. For simplicity, let us start with a linear polarization, i.e., a Lagrangian splitting  $T^*\mathcal{R}=\mathbb{L}\oplus\mathbb{L}^\perp$  (though we will be more general later):

$$(Q_{\mathbb{L}}, \widetilde{Q}_{\mathbb{L}}),$$
 (3.48)

where  $Q_{\mathbb{L}}$  and  $\widetilde{Q}_{\mathbb{L}}$  can be conveniently viewed as 2d  $\mathcal{N}=(2,2)$  chiral multiplets valued in Maps( $\mathbb{R},\mathbb{L}$ ) and Maps( $\mathbb{R},\mathbb{L}^{\perp}$ ). We then use this splitting to define the polarization on the phase space: pick the "position" polarization for  $Q_{\mathbb{L}}$ , forcing the "momentum" polarization for  $\widetilde{Q}_{\mathbb{L}}$  (which is slightly deformed by the contribution of  $\sigma_3 + iA_y$  to covariant derivatives). Modeling the polarization by a boundary condition at y=0 means the lowest components of these superfields obey:

$$q_{\mathbb{L}}\big|_{y=0} = q_{\partial}, \quad (D_y + \sigma)\widetilde{q}_{\mathbb{L}}\big|_{y=0} = \widetilde{p}_{\partial},$$
 (3.49)

where  $\widetilde{p}_{\partial}$  and  $q_{\partial}$  are some scalar functions on  $\mathbb{E}_{\tau}$ . The rest (i.e., boundary conditions for the hypermultiplet fermions) are completed by SUSY. In particular, fermions residing in  $Q_{\mathbb{L}}$  and  $\widetilde{Q}_{\mathbb{L}}$  are canonically conjugate to each other, so the natural SUSY completion of the above is to fix boundary values of all fermions in  $Q_{\mathbb{L}}$ . That such boundary conditions on fermions are elliptic and make sense quantum mechanically is not obvious, and we discuss it in the Appendix B.

One thus obtains a "boundary multiplet"  $Q_{\partial}$ , which contains boundary restrictions of those fields whose boundary values are kept fixed in the path integral. This  $Q_{\partial}$  is in fact the restriction  $Q_{\mathbb{L}}|_{y=0}$ , so it is an  $\mathcal{N}=(2,2)$  chiral multiplet. The auxiliary field of this chiral multiplet is equal on-shell to

$$F_{\partial} = (D_y + \sigma)\widetilde{q}_{\mathbb{L}},\tag{3.50}$$

thus encoding the boundary conditions for  $\widetilde{q}_{\mathbb{L}}$ . So we conclude that the polarization for

<span id="page-46-0"></span><sup>&</sup>lt;sup>7</sup>A polarization Π on the phase space is invariant under a symmetry V if the symplectic vector field V obeys  $[V, \Pi] \subset \Pi$ . In the case of SUSY, V is an odd vector field.

hypermultiplets, corresponding to the Lagrangian splitting L ⊕ L <sup>⊥</sup>, is implemented by the boundary conditions

$$Q_{\mathbb{L}} \big| = Q_{\partial}, \tag{3.51}$$

where Q<sup>∂</sup> is a background chiral multiplet at the boundary.

We can consider more general polarizations on T <sup>∗</sup>R, for which the above treatment of L ⊕ L <sup>⊥</sup> is a local model. To make contact with [\[51,](#page-141-1) [52\]](#page-141-2), the proper choice should be a polarization on the Higgs branch X (viewed as a holomorphic symplectic manifold), which is then lifted to some polarization on T <sup>∗</sup>R. In practice, we will be concerned with yet another set of boundary conditions hBp| labeled by the fixed points p (massive vacua) on X and a choice of polarization. It is always possible to lift the polarization of X in the vicinity of p to some linear polarization on the hypermultiplets:

$$\mathbb{L}(p) \oplus \mathbb{L}^{\perp}(p), \tag{3.52}$$

and this is what we do. In general, L(p) may be different for different p, in which case we denote the boundary conditions as B<sup>L</sup>(p),p.

For 3d N = 4 vector multipelts, we will choose the "Dirichlet" polarization. We think of a 3d N = 4 vector as a pair of a 2d N = (2, 2) vector V (2,2) (with the gauge group Maps(R, G)), and a 2d N = (2, 2) chiral S (2,2) in the adjoint of this group. The fermions in S (2,2) are canonically conjugate variables to the fermions in V (2,2). We pick the boundary conditions that prescribe the boundary value of V (2,2) ,

$$V^{(2,2)} = V_{\partial}, \tag{3.53}$$

to be the background multipelt V∂, the "boundary vector multiplet". Since the Fermi fields in S (2,2) are canonically conjugate to those in V (2,2), they should stay unconstrained once the entire multiplet V (2,2) is fixed at the boundary. That this leads to sensible elliptic boundary conditions in the quantum theory is again discussed in the Appendix [B.](#page-130-0) The lowest component of S (2,2) is σ + iAy, and it appears in the auxiliary field of V<sup>∂</sup> as [\[137\]](#page-148-1)

$$iD_{\partial} = D_y \sigma + iD. \tag{3.54}$$

Therefore, the deformed Neumann boundary condition on σ follows from V (2,2) <sup>=</sup> <sup>V</sup><sup>∂</sup> (note that D, being an auxiliary field, does not receive an independent boundary condition).

Altogether, the states are described as functionals Ψ[B] ≡ Ψ[V∂, Q∂] of the boundary multiplets. If there are n isolated vacua, the corresponding functionals Ψ1, . . . , Ψ<sup>n</sup> span the kernel of the Hamiltonian <sup>H</sup>b, which is a certain functional differential operator. Such a description is quite formal and hard to make precise in general, but we could certainly imagine computing Ψ<sup>i</sup> [B] in perturbation theory, either as a solution to <sup>H</sup>bΨ = 0, or as a partition function on E<sup>τ</sup> × R<, with a chosen vacuum fixed at y = −∞ and a boundary conditions B at y = 0.

If B is a supersymmetric boundary condition (picking special values of V<sup>∂</sup> and Q∂), then hB|Ψ<sup>j</sup> i can often be computed exactly, especially if |Ψ<sup>j</sup> i is replaced by a thimble boundary condition D<sup>j</sup> discussed earlier.

Now we define another set of SUSY boundary conditions labeled by the vacua,

$$\mathscr{B}_{\mathbb{L}(p),p},$$
 (3.55)

which additionally depends on the choice of polarization. While the thimble boundary conditions D<sup>p</sup> were natural in a theory with generic real masses, we use B<sup>L</sup>(p),p in the case when real masses are zero, while the vacua are still massive thanks to the equivariant parameters. The main difference between D<sup>p</sup> and B<sup>L</sup>(p),p is what we do to the hypermultiplets that do not develop vev in the vacuum p. In the presence of real masses, such hypers receive natural boundary conditions dictated by the sign of their real mass, which was part of the D<sup>p</sup> definition. In the absence of real masses, there are no such preferred boundary conditions, and it is a choice labeled by the polarization.

Hence, we define B<sup>L</sup>(p),p as follows. As before, hypermultiplets in the subspace R0(p) ⊂ R are the ones that get vevs.[8](#page-48-0) More specifically, chirals in R<sup>D</sup> 0 (p)⊕R N 0 (p) have nontrivial vevs. Thus, just like before we assign

$$\mathcal{R}_0^D(p)$$
,  $\overline{\mathcal{R}}_0^N(p)$ : (0,2) Dirichlet with boundary values given by the vevs,  $\mathcal{R}_0^N(p)$ ,  $\overline{\mathcal{R}}_0^D(p)$ : (0,2) Neumann.

(3.56)

In the absence of real masses, it does not make sense to split the remaining hypers into R+(p) and R−(p). Instead, we use a polarization L(p) ⊕ L <sup>⊥</sup>(p) to define a split. Only polarization

<span id="page-48-0"></span><sup>8</sup>Here, it makes sense to define R0(p) as the subspace of hypermultiplets that develop vevs. If the situation of the footnote [5](#page-43-1) occurs, then this R0(p) will be slightly different from the one discussed there in the context of thimble boundary conditions.

along the complement of R0(p) ⊕ R0(p) matters at this point, so we define:

$$\widetilde{\mathbb{L}}(p) = \mathbb{L}(p) \setminus T^* \mathcal{R}_0(p), \qquad \widetilde{\mathbb{L}}^{\perp}(p) = \mathbb{L}^{\perp}(p) \setminus T^* \mathcal{R}_0(p),$$
 (3.57)

such that

$$\mathcal{R} \oplus \overline{\mathcal{R}} = \mathcal{R}_0(p) \oplus \overline{\mathcal{R}}_0(p) \oplus \widetilde{\mathbb{L}}(p) \oplus \widetilde{\mathbb{L}}^{\perp}(p),$$
 (3.58)

or more concisely T <sup>∗</sup>R ∼= T <sup>∗</sup>R0(p) ⊕ T <sup>∗</sup>Le(p), and assign boundary conditions according to

<span id="page-49-1"></span>
$$\widetilde{\mathbb{L}}(p)$$
: Dirichlet,  
 $\widetilde{\mathbb{L}}^{\perp}(p)$ : Neumann. (3.59)

On vector multiplets, like in the D<sup>p</sup> case, we impose the (2, 2) Dirichlet boundary conditions with the boundary flat connection s = s (p) (x, ~). Such boundary conditions are also of the "exceptional Dirichlet" type [\[88\]](#page-144-3) since they fully break the boundary G symmetry. In particular, they lift the zero modes that otherwise make (2, 2) Dirichlet boundary conditions on vector multiplets a bit subtle. Thus we expect that B<sup>L</sup>(p),p are elliptic boundary conditions giving rise to reasonably well-behaved boundary states upon any finite Euclidean evolution.

Let us compute the boundary 't Hooft anomalies for B<sup>L</sup>(p),p, which will determine the first Chern class of the associated line bundle whose section is hB<sup>L</sup>(p),p|. The computation is very similar to the one we did before, except that now hB<sup>L</sup>(p),p| is the "out" state, so it is imposed at the "future" boundary y = y<sup>+</sup> > 0, hence the inflow term will have an opposite sign.

Three-dimensional chirals in

<span id="page-49-2"></span>
$$\widehat{\mathbb{L}}(p) = \widetilde{\mathbb{L}}(p) \oplus \mathcal{R}_0^D(p) \oplus \overline{\mathcal{R}}_0^N(p)$$
(3.60)

obey Dirichlet boundary conditions and contribute <sup>1</sup> <sup>2</sup>Tr <sup>L</sup>b(p) (f +fx+ 1 2 f~− 1 2 r) 2 to the anomaly polynomial, while those in the dual representation obey Neumann. Again they almost cancel each other, leaving

$$(\mathbf{f}_{\hbar} - \mathbf{r}) \operatorname{Tr}_{\widehat{\mathbb{L}}(p)} (\mathbf{f} + \mathbf{f}_x).$$
 (3.61)

Vector multiplets obey (2, 2) Dirichlet, so their contribution is the same as before. The inflow term has an opposite sign, so the total boundary anomaly polynomial is

<span id="page-49-0"></span>
$$P[\mathscr{B}_{\mathbb{L}(p),p}] = (\mathbf{f}_{\hbar} - \mathbf{r}) \operatorname{Tr}_{\widehat{\mathbb{L}}(p)} (\mathbf{f} + \mathbf{f}_x) + \frac{|G|}{2} \mathbf{f}_{\hbar}^2 - \frac{|G|}{2} \mathbf{r}^2 + 2 \operatorname{Tr} (\mathbf{f} \mathbf{f}_z), \tag{3.62}$$

where, as before, one should substitute  $\mathbf{f} = f(\mathbf{f}_x, \mathbf{f}_h)$  as G is fully broken.

Using (3.62), we can recover the behavior of  $\langle \mathcal{B}_{\mathbb{L}(p),p}|$  under the flavor and topological large gauge transformations. For illustrative and pedagogical reasons, we will employ a different method here than before. Namely, we use the fact that  $\langle \mathcal{B}_{\mathbb{L}(p),p}|$  transforms in the same way as the  $\mathbb{T}^2$  partition function of a purely 2d system with the same anomaly polynomial  $P[\mathcal{B}_{\mathbb{L}(p),p}]$ . It is easier to construct an auxiliary 2d system with the anomaly polynomial 2P first, for example we can build it from:

- a Fermi multiplet with weights in  $-\widehat{\mathbb{L}}(p)$ ,  $\hbar$ -charge  $-\frac{1}{2}$  and R-charge  $+\frac{1}{2}$ ;
- a chiral multiplet with weights in  $-\widehat{\mathbb{L}}(p)$ ,  $\hbar$ -charge  $+\frac{1}{2}$  and R-charge  $+\frac{1}{2}$ ;
- a Fermi multiplet of R-charge 0 and  $\hbar$ -charge 1 valued in the adjoint of gauge group;
- a chiral multiplet of zero R and  $\hbar$ -charges in the adjoint of gauge group;
- for each U(1) factor in the gauge group, add: (1) a Fermi multiplet (of zero R and ħ charges) of charge +1 under this U(1) and charge +1 under the dual topological U(1)<sub>top</sub>; (2) a chiral multiplet (of zero R and ħ charges) of charge +1 under this U(1) and charge -1 under the dual topological U(1)<sub>top</sub>.

The first two items form together a  $-\widehat{\mathbb{L}}(p)$ -valued (2,2) chiral multiplet; the first four items on the list form the matter content of the interval reduction of a 3d theory with the same boundary conditions  $\mathscr{B}_{\mathbb{L}(p),p}$  on the two ends; the last item was cooked up to have the anomaly polynomial  $4\text{Tr}(\mathbf{ff}_z)$ . We write down the flavored elliptic genus of this system following the standard techniques [138–140].

According to [138], the Ramond sector one-loop determinants of a chiral and a Fermi multiplet of weight x are, respectively:

<span id="page-50-0"></span>
$$Z_{\rm Ch}(x,q) = \frac{1}{q^{\frac{1}{12}}\vartheta(x)}, \qquad Z_{\rm F}(x,q) = q^{\frac{1}{12}}\vartheta(x),$$
 (3.63)

where we used the theta function defined in (3.45).

One can also find slightly different expressions for  $Z_{\text{Ch}}$  and  $Z_{\text{F}}$  in the literature [141], the difference originating from the choice of regularization in the infinite products computing the one-loop determinants ([141] use the zeta-function regularization):

$$\widetilde{Z}_{Ch}(x,q) = \frac{1}{q^{\frac{1}{12}} e^{\frac{(\log x)^2}{2 \log q}} \vartheta(x)}, \qquad \widetilde{Z}_{F}(x,q) = q^{\frac{1}{12}} e^{\frac{(\log x)^2}{2 \log q}} \vartheta(x).$$
(3.64)

Notice that the  $\widetilde{Z}_{Ch}$ ,  $\widetilde{Z}_{F}$  and  $Z_{Ch}$ ,  $Z_{F}$  are related by the modular transformation. Indeed, if we first rewrite in the Jacobi's notations:

$$q^{\frac{1}{12}}\vartheta(x) = \frac{i\theta_1(a;\widetilde{\tau})}{\eta(\widetilde{\tau})},\tag{3.65}$$

where  $x = e^{2\pi i a}$  and  $q = e^{2\pi i \tilde{\tau}}$ , then we observe:

<span id="page-51-0"></span>
$$\frac{\theta_1(\frac{a}{\tilde{\tau}}; -\frac{1}{\tilde{\tau}})}{\eta(-\frac{1}{\tilde{\tau}})} = -ie^{\frac{i\pi a^2}{\tilde{\tau}}} \frac{\theta_1(a; \tilde{\tau})}{\eta(\tilde{\tau})},\tag{3.66}$$

where  $\frac{i\pi a^2}{\tilde{\tau}} = \frac{(\log x)^2}{2\log q}$  is exactly the factor that distinguishes Z and  $\tilde{Z}$ . While in the purely 2d theories one could attempt to argue for one expression over the other, (since the two 1-cycles of  $\mathbb{T}^2$  are not entirely equivalent: one is thought of as the spatial circle and another is the temporal circle), in our case it is not so. Our  $\mathbb{T}^2$  is the spatial torus, and there is no reason to choose say  $Z_{\text{Ch}}$  over  $\tilde{Z}_{\text{Ch}}$ . This is of course a manifestation of mixed global-gravitational anomaly. We can just make a choice to work with  $Z_{\text{Ch}}$  and  $Z_{\text{F}}$ , and proceed to compute the partition function of an auxiliary system described above as:

$$\prod_{\substack{(w,f)\in\widehat{\mathbb{L}}(p)}} \frac{\vartheta(s^w x^f \hbar^{1/2})}{\vartheta(s^w x^f \hbar^{-1/2})} \times \prod_{\alpha \in \mathbf{adj}(G)} \frac{\vartheta(s^\alpha \hbar)}{\vartheta(s^\alpha)} \times \prod_{a=1}^{\mathrm{rk}(\mathbf{A}')} \frac{\vartheta(s^{c_a} z_a)}{\vartheta(s^{c_a} z_a^{-1})}.$$
(3.67)

Here  $(w, f) \in \widehat{\mathbb{L}}(p)$  denotes gauge and flavor weights, so s and x are gauge and flavor fugacities (flat connections on  $\mathbb{T}^2$ ). The last product is over the U(1) factors in the gauge group, and  $s^{c_a}$  are the corresponding fugacities as before.

As written, the expression (3.67) is divergent, since the second product includes a factor of  $\left(\frac{\vartheta(\hbar)}{\vartheta(1)}\right)^{\operatorname{rk}(G)}$ , and  $\vartheta(1)=0$ . This problem is resolved once we substitute  $s=s^{(p)}(x,\hbar)$ , after which the numerators in the first product in (3.67) include precisely  $\operatorname{rk}(G)$  factors of  $\vartheta(1)$  that cancel the divergence. This precise cancellation may be traced back to the vacua being isolated and massive. Thus we can safely use the expression (3.67) with  $s=s^{(p)}(x,\hbar)$ , and the state  $\langle \mathscr{B}_{\mathbb{L}(p),p}|$  transforms as its square root. We write down the transformation rules

like before:

<span id="page-52-0"></span>
$$z_{a} \mapsto q z_{a} : \quad \Psi \mapsto s^{-c_{a}} \Psi$$

$$s \mapsto q^{\mathbf{v}} s : \quad \Psi \mapsto \hbar^{-\frac{1}{2} \sum_{\widehat{\mathbb{L}}(p)} \langle \mathbf{v}, w \rangle} \prod_{a=1}^{\operatorname{rk}(\mathbf{A}')} z_{a}^{-\langle \mathbf{v}, c_{a} \rangle} \Psi$$

$$x \mapsto q^{\mathbf{w}} x : \quad \Psi \mapsto \hbar^{-\frac{1}{2} \sum_{\widehat{\mathbb{L}}(p)} \langle \mathbf{w}, f \rangle} \Psi$$

$$\hbar \mapsto q^{2} \hbar : \quad \Psi \mapsto \hbar^{-|G|} q^{-|G|} \prod_{(w,f) \in \widehat{\mathbb{L}}(p)} \left( s^{-w} x^{-f} \right) \Psi, \tag{3.68}$$

from which the transformation rules of hB<sup>L</sup>(p),p| follow simply by the specialization s = s (p) (x, ~). In equation [\(3.68\)](#page-52-0), v = (v1, . . . , vrk(G)) is some gauge coweight and w = (w1, . . . , wrk(GH)) is a flavor coweight.

The Ψ in [\(3.68\)](#page-52-0) is a section of some line bundle F on ET(X) = EllT(X) × EA<sup>0</sup>. Specialization s = s (p) (x, ~) means taking its pullback to the p-th irreducible component of ET(X), where we find a line bundle that the state hB<sup>L</sup>(p),p| is valued in. We can easily construct an explicit model expression for Ψ that is meromorphic and transforms as in [\(3.68\)](#page-52-0):

<span id="page-52-1"></span>
$$\Psi = \Xi \times \prod_{(w,f)\in\widehat{\mathbb{L}}(p)} \frac{\vartheta\left(s^w x^f \hbar^{\frac{1}{2}}\right)}{\vartheta(s^w x^f)\vartheta(\hbar^{\frac{1}{2}})} \times \vartheta\left(\hbar^{\frac{1}{2}}\right)^{2|G|} \times \prod_{a=1}^{\operatorname{rk}(\mathbf{A}')} \frac{\vartheta\left(s^{c_a} z_a\right)}{\vartheta(s^{c_a})\vartheta(z_a)},\tag{3.69}$$

where Ξ is an undetermined meromorphic function (section of a trivial line bundle) on ET(X), which is thus invariant under [\(3.68\)](#page-52-0). Any meromorphic section of F has the form [\(3.69\)](#page-52-1) with some meromorphic function[9](#page-52-2) Ξ. Note that for Ψ to be meromorphic with respect to its arguments, we treat ~ 1 <sup>2</sup> as a symbol denoting a coordinate on the double cover, which is natural, given that the fields with half-integral U(1)<sup>~</sup> charges are present in the theory.

Now we know that states |Ψpi are sections of the line bundle characterized by a model section [\(3.47\)](#page-45-2), while the bundle that hB<sup>L</sup>(p),p| is valued in is characterized by a model section [\(3.69\)](#page-52-1). The overlap hB<sup>L</sup>(p1),p<sup>1</sup> |Ψ<sup>p</sup><sup>2</sup> i is thus characterized by the product of [\(3.47\)](#page-45-2) and [\(3.69\)](#page-52-1), with s = s (p2) (x, ~) in the former and s = s (p1) (x, ~) in the latter. We see that if p<sup>1</sup> = p2, the terms of the form <sup>ϑ</sup>(sz) ϑ(s)ϑ(z) containing topological fugacities z<sup>a</sup> cancel. If p<sup>1</sup> 6= p2, they do not cancel, leading to a nontrivial dependence on the z<sup>a</sup> (and thus nontrivial monodromies along the cycles of EA<sup>0</sup>).

<span id="page-52-2"></span><sup>9</sup>The same statement about the elliptic meromorphic ambiguity Ξ also applies to the earlier expression [\(3.47\)](#page-45-2).

### <span id="page-53-0"></span>4 Janus interfaces

A family of quantum field theories depending on a continuous parameter g can often be studied in a (d+1)-dimensional background, in which g varies along a chosen spatial direction y ∈ R. Such backgrounds break part of the Poincare group, preserving the d-dimensional translations and Lorentz transformations. Of special interest are the configurations where g stays constant in most of the spacetime, and only changes in a small or finite region y ∈ (a, b). Following [\[142\]](#page-148-5), such a region is often referred to as a "Janus interface," and we will adopt this nomenclature. Janus interfaces for the gauge coupling (and their AdS gravity dual solutions) were first studied in the 4d N = 4 SYM. The non-supersymmetric interface appeared in [\[142–](#page-148-5)[144\]](#page-148-6), and the SUSY-preserving generalization was studied in [\[145–](#page-148-7)[148\]](#page-149-0). A generalization that includes a spatially varying theta angle was introduced in [\[82\]](#page-143-4), which is an important ingredient in the construction of the S-duality kernel T[G] [\[79\]](#page-143-8).

One can of course consider varying parameters other than the gauge coupling. For example, [\[149\]](#page-149-1) constructs Janus interfaces for twisted chiral couplings in 2d N = (2, 2) theories, and [\[150\]](#page-149-2) studies such interfaces in 2d N = (2, 2) gauged linear sigma models (GLSM), where the coupling of interest is the complexified FI parameter. The latter type is closely related to one of the interfaces we discuss below. Much more central to our story is an interface implementing the change of mass parameters, more precisely, real masses in 3d N = 2 gauge theories. Such interfaces, or more generally, backgrounds with spatially modulated masses, have recently attracted attention in the literature as well, see [\[151–](#page-149-3)[158\]](#page-149-4), and [\[159,](#page-150-0) [160\]](#page-150-1) for Janus solutions in M-theory on AdS4. Mass Janus in the context closely related to the current paper has also played role in [\[161\]](#page-150-2).

By adjusting one or several parameters of a given quantum field theory, we can land in different phases. This naturally leads to a special class of Janus interfaces that can be called phase interfaces, or phase walls. They interpolate between distinct phases in different spacetime regions, and understanding their properties allows to establish mapping of various objects across the phases (e.g., study the brane transport, see [\[162–](#page-150-3)[165\]](#page-150-4), especially the recent work [\[166\]](#page-150-5)). The interfaces we study in this paper will be of such type: they will interpolate between Higgs, Coulomb, mixed, as well as the CFT phases of the given quiver gauge theory.

Before proceeding with concrete constructions, note that in a Euclidean theory, the interface can be oriented in an arbitrary way due to the rotational symmetry of spacetime. In Lorentzian signature, however, as is always the case for extended objects, there exist physically distinct configurations depending on whether some of the interface directions are time-like, space-like, or null. The standard physical treatment of interfaces assumes that they are time-like, i.e., bound spatial regions. We do not consider null interfaces here (which can be thought of as infinite-boost limits of either time-like or space-like cases). The spacelike interfaces, on the other hand, are more commonly understood as making couplings of the theory time-dependent. We can consider the limiting case, where the parameters of the theory change abruptly at a given moment of time, and stay constant afterwards. Such a discontinuous change of parameters, — known as a quench, — is actually under a better analytical control than a continuous change. The reason is that the wave function of the system cannot change immediately, and stays constant across the quench (or jumps in a controllable way if the Hamiltonian contains delta-functions), so the wave function right after the quench is known and serves as an initial condition for the Schr¨odinger equation with the new values of parameters. This defines a codimension-one operator (interface) acting between the spaces of states of theories before and after the quench.

### <span id="page-54-0"></span>4.1 FI Janus in 3d N = 2

We start with the simplest case of Janus interface corresponding to a y-dependent FI parameter ζ(y) in a 3d N = 2 gauge theory. We can define it by a term in the Lagrangian:

<span id="page-54-1"></span>
$$\mathcal{L}_{\text{FI}} = \text{Tr} \left( i\zeta(y)D - \zeta'(y)\sigma \right),$$
 (4.1)

which only differs from the usual real FI coupling by a derivative term ζ 0 (y)σ. This coupling is consistent with 2d N = (0, 2) SUSY, and in the case of N = 4 theories, – with the entire 2d N = (2, 2) subalgebra. After we act with SUSY, to see that [\(4.1\)](#page-54-1) is indeed invariant, we must integrate by parts and assume that fermions vanish at infinity.

We could imagine integrating by parts before acting with SUSY, to replace −ζ 0 (y)σ by ζ(y)Dyσ. However, this produces a boundary term at y = ±∞, unless ζ(y)σ takes the same vale at both infinities. The latter does not have to be the case in general, as the vacua at y → ±∞ might be different. We could of course contemplate defining the y-dependent FI coupling as Tr (iζ(y)D + ζ(y)Dyσ), in which case it is supersymmetric on the nose, without any extra integration by parts. We do not do so, because [\(4.1\)](#page-54-1) has a more natural property that it coincides with the standard FI term whenever ζ(y) is constant.

Let us vary ζ(y) 7→ ζ(y)+δζ(y), while keeping its asymptotic values intact, δζ(±∞) = 0.

The variation of the action is

$$\delta S_{\rm FI} = \int d^3x \, \text{Tr} \left( i\delta\zeta(y)D - \delta\zeta'(y)\sigma \right) = \int d^3x \, \text{Tr} \, i\delta\zeta(y)(D - iD_y\sigma), \tag{4.2}$$

where now we integrate by parts without earning a boundary term. Furthermore, using our definition of the elliptic supercharge Q (and conventions in the Appendix [A\)](#page-124-0), we find that

$$D - iD_y \sigma = \mathcal{Q} \left[ \frac{1}{2} (\lambda_- - \overline{\lambda}_-) \right]. \tag{4.3}$$

In other words, δSFI is Q-exact, showing that we can vary ζ(y) arbitrarily, as long as the asymptotic (or boundary) values are fixed.

One could worry whether this naive argument might fail due to some sort of singularities and monodromies in the space Lie Z <sup>L</sup>G of FI parameters, such that the partition function would depend on the homotopy class of ζ(y) (viewed as a map from R to the space of FI parameters). After all, such things do happen in 2d, for example in the space of twisted chiral couplings, such as the FI-theta terms (see, e.g., [\[150\]](#page-149-2) and references therein). Such phenomena would be relevant for computations of the QA-invariant quantities, since they are meromorphic in the C <sup>×</sup>-valued "K¨ahler" parameter in 3d (which reduces to the usual complex FI-theta parameter in 2d). This is a complex combination of the 3d FI parameter with the topological symmetry holonomy along the B-cycle, and in the space of such complex parameters, one naturally finds singularities and monodromies (they are important to the story of [\[52,](#page-141-2) [84\]](#page-143-6)).

In the case of Q-invariant observables, however, the real FI parameters do not admit a natural complexification. As explained in Section [2,](#page-9-0) the holonomies on E<sup>τ</sup> for topological symmetries combine to form the elliptic K¨ahler parameter z in 3d, while the FI term remains real. More precisely, the Q-invariant quantities are meromorphic in the elliptic equivariant and K¨ahler parameters, but they are locally constant in the real FI parameter (the local constancy remains true after reduction to 2d and 1d as well). We observe quite a different phenomenon: the space of real FI parameters is subdivided by the walls into chambers. Generically, FI parameters land inside some chamber, but we can adjust them to be on the wall. What matters is in what chamber (or on what wall) ζ(y) starts at y = −∞, and where it ends at y = +∞.

One can understand walls physically as those values of parameters, at which the mixed branches open up. For generic values of the FI parameters, the Coulomb branch is often lifted,<sup>10</sup> except for a discrete set of points where it intersects the Higgs branch (they all sit at the origin when the masses vanish). From the Coulomb branch point of view, the FI parameters  $\zeta$  are seen as generators of the topological symmetries, i.e. the maximal torus  $\mathbf{A}'$  of  $G_C$ . These unlifted points are simply the fixed points, denoted by  $\mathcal{M}_C^{\mathbf{A}'}$ , of the torus  $\mathbf{A}'$  acting on the Coulomb branch  $\mathcal{M}_C$ . By tuning the FI parameters  $\zeta$  to non-generic values, we may un-lift certain directions of the Coulomb branch. In other words, we pass to a sub-torus of  $\mathbf{A}'$ , which leaves a larger subset of  $\mathcal{M}_C$  fixed, which we may call  $\mathcal{M}_C^{\zeta}$ , to indicate its dependence on  $\zeta$ . Assuming that we do not turn on masses, we end up with a mixed branch: we can explore both the subset of Coulomb branch that is not lifted, and the corresponding Higgs branch (partly resolved by the non-generic FI parameters).

We thus see how to determine the walls. Thinking of  $\zeta$  as the generators of topological symmetries, the walls correspond to those non-generic values, at which the fixed locus  $\mathcal{M}_C^{\zeta}$  becomes larger. In the absence of masses,  $\mathcal{M}_C = \operatorname{Spec}(R_C)$ , and we can find an ideal in  $R_C$ , which we denote as  $(\zeta R_C)$ , generated by the images of elements in  $R_C$  under the action of  $\zeta$ . This is the ideal of functions vanishing along  $\mathcal{M}_C^{\zeta}$ , and  $R_C/(\zeta R_C) \cong \mathbb{C}[\mathcal{M}_C^{\zeta}]$ . Therefore, simply looking at how the generators of  $R_C$  are acted on by  $\zeta$ , is enough to determine  $\mathcal{M}_C^{\zeta} = \operatorname{Spec}(R_C/(\zeta R_C))$ . Again, the walls are located at those values of  $\zeta$ , at which  $R_C/(\zeta R_C)$  jumps up in size. More formally, this can be described in a way similar to the Higgs branch case in [51]. Namely, the Coulomb analog of Definition 3.2.1 from [51] is: the  $\mathbf{A}'$ -roots are the  $\mathbf{A}'$ -weights  $\{\alpha'_i\}$  occurring in the normal bundle to  $\mathcal{M}_C^{\mathbf{A}'}$  inside  $\mathcal{M}_C$ . Then the walls are just the root hyperplanes  $(\alpha'_i)^{\perp}$ , defined by the vanishing of  $\alpha'_i$ . The space of FI parameters Lie Z (LG)  $\mathcal{A}_C$  (where  $\mathfrak{a}_R$  is the Cartan subalgebra of  $G_C$ , or equivalently a Lie algebra of  $\mathbf{A}'$ ) is partitioned into the chambers:

$$\mathfrak{a}_{\mathbb{R}}' \setminus \bigcup (\alpha_i')^{\perp} = \bigsqcup \mathfrak{C}_i'. \tag{4.4}$$

#### <span id="page-56-0"></span>4.2 Mass Janus in 3d $\mathcal{N}=2$

The FI Janus described above can be understood as a supersymmetric background for the vector multiplets gauging the topological symmetry. We can turn on precisely the same SUSY configuration for the background vector multiplets gauging flavor symmetries. This results in a solution that we call a mass Janus. More precisely, it is characterized by the

<span id="page-56-1"></span> $<sup>^{10}</sup>$ At least this is true in the class of theories we study. One can easily imagine theories that do not have enough FI parameters, for example if we replace some U(N) gauge groups by SU(N). In that case one can still consider turning on the available FI parameter as generic as possible, thus lifting some part of the Coulomb branch.

following vevs for the flavor vector multiplet:

$$\sigma^{\mathrm{f}} = m(y), \quad D_{\mathbb{R}}^{\mathrm{f}} = \mathrm{i} \frac{\mathrm{d}m(y)}{\mathrm{d}y}.$$
 (4.5)

In other words, we make real masses y-dependent, and also turn on the auxiliary field  $D_{\mathbb{R}}^{\mathrm{f}}$  in the background vector multiplet. Position dependent masses alone completely break SUSY, while the presence of  $D_{\mathbb{R}}^{\mathrm{f}}$  vev allows to preserve half of supersymmetry.

If we only consider  $\mathcal{N}=4$  real masses, this background preserves 2d  $\mathcal{N}=(2,2)$  SUSY, which is then broken down to  $\mathcal{N}=(0,2)$  by the  $\hbar$  equivariant parameter. We never turn on the  $U(1)_{\hbar}$  real mass, but if we did, it would also preserve  $\mathcal{N}=(0,2)$ .

Let us explicitly write down the extra terms that appear in the Lagrangian due to this deformation. They form a supersymmetric mass term for the chiral multiplets:

$$\mathcal{L}_{m} = \overline{\phi}m(y)^{2}\phi + 2\overline{\phi}\sigma m(y)\phi - \overline{\phi}\frac{\mathrm{d}m(y)}{\mathrm{d}y}\phi + i\overline{\psi}m(y)\psi, \tag{4.6}$$

where the dynamical vector multiplet scalar  $\sigma$  appears due to the term  $\overline{\phi}(m+\sigma)^2\phi$  in the full action. Note that  $\sigma$  acts in the gauge group representation, while m(y) acts in the flavor group representation. Now let us vary the mass profile, while keeping the asymptotic values intact:

$$m(y) \mapsto m(y) + \delta m(y), \quad \delta m(\pm \infty) = 0.$$
 (4.7)

The latter condition allows integration by parts, and we find:

$$\delta S_m = \int d^3x \, \delta \mathcal{L}_m = \int d^3x \, \delta m^a(y) \left( 2\overline{\phi}(m(y) + \sigma) f^a \phi + \frac{d}{dy} (\overline{\phi} f^a \phi) + i\overline{\psi} f^a \psi \right), \quad (4.8)$$

where we write  $f^a$  for the generators of the flavor symmetry maximal torus, so  $\delta m = \delta m^a f^a$ . Once we attempt to check whether this expression is  $\mathcal{Q}$ -exact, we find:

<span id="page-57-0"></span>
$$\delta S_m = \int d^3x \, \delta m^a(y) \mathcal{Q}(\overline{\phi} f^a \overline{\rho} \psi + \rho \overline{\psi} f^a \phi) + i \int d^3x \, \delta m^a(y) (\overline{F} f^a \phi + \overline{\phi} f^a F), \tag{4.9}$$

where  $(\overline{\rho}, \rho)$  parameterize the two supersymmetries of the 3d  $\mathcal{N} = 2$  algebra that are broken by the background, and  $(F, \overline{F})$  are auxiliary fields in the chiral multiplets. So we see that  $\delta S_m$  is not  $\mathcal{Q}$ -exact off shell.

To improve the situation, we can put the auxiliary field on shell in the path integral. Let

us see why it is legal to do so. Suppose we study some partition or correlation function:

$$Z = \int \mathcal{D}[\text{fields}] e^{-S}(\dots), \tag{4.10}$$

and we want to understand how it depends on the mass profile m(y). Assuming that the insertions (. . .) do not depend on masses, the variation δm(y) only affects the action. If we are off shell, we can drop the Q-exact term in [\(4.9\)](#page-57-0) without affecting the answer, and take the other term down from the exponent:

$$\delta_m Z = -i \int \mathcal{D}[\text{fields}] e^{-S}(\dots) \int d^3 x \, \delta m^a(y) (\overline{\phi} f^a F + \overline{F} f^a \phi). \tag{4.11}$$

Let us assume that the insertions (. . .) do not include fields (F, F). We integrate out (F, F) by replacing them with their on shell values, simply because the action is quadratic in (F, F), so they cannot pick up any extra contractions with (. . .). In other words, we apply the Dyson-Schwinger equations following from R DFDF δ δF (. . .) = R DFDF δ δF (. . .) = 0. As we know, the on shell values are expressed in terms of the superpotential: F = ∂W ∂φ and F = − ∂W ∂φ . Thus we find:

$$\delta_m Z = -i \int \mathcal{D}[\text{fields}] e^{-S}(\dots) \int d^3 x \, \delta m^a(y) \left( \overline{\phi} f^a \frac{\partial \overline{W}}{\partial \overline{\phi}} - \frac{\partial W}{\partial \phi} f^a \phi \right). \tag{4.12}$$

This expression vanishes for arbitrary insertions (. . .), since the superpotential W is invariant under the flavor symmetry, in particular:

$$\delta m^a \frac{\partial W}{\partial \phi} f^a \phi = \delta m \circ W = 0, \tag{4.13}$$

where δm◦ denotes action by the flavor algebra element δm = δm<sup>a</sup> f a .

We thus obtain that δmZ = 0 under the variation m(y) 7→ m(y) +δm(y) of the real mass profile. Therefore, the Janus interface for real masses has the same universality property as the Janus for real FI parameters: The precise shape of m(y) does not matter in the Q-cohomology, only the asymptotic values are relevant for the Q-invariant computations. We could anticipate this from the mirror symmetry, given that the same property holds for the FI Janus, but that, strictly speaking, would apply to the N = 4 case only, while here we clearly see that the 3d N = 2 SUSY is enough to prove this. There is a caveat, though, related to the fact that the mass Janus background violates unitarity if y is treated as (Euclidean) time, and violates positivity of the Hamiltonian if y is treated as space (the violation occurs in the region where m<sup>0</sup> (y) 6= 0). We will get back to this in the next section.

Just like in the FI case, we do not expect to encounter any monodromies as we vary the real mass profile m(y), at least when we study Q-invariant observables. Instead, there are real codimension-1 walls, again as in the FI case. At generic values of masses, the Higgs branch X of the theory is lifted, except for a certain locus X<sup>A</sup> fixed by the flavor torus A. Its A-roots {αi} are defined as the A-weights that occur in the normal bundle to X<sup>A</sup> in X, which is the content of Definition 3.2.1 from [\[51\]](#page-141-1). Then the walls are the root hyperplanes α ⊥ i , and the space a<sup>R</sup> of real masses (which is the Cartan of the N = 4 flavor symmetry group GH) is partitioned into chambers:

$$\mathfrak{a}_{\mathbb{R}} \setminus \bigcup \alpha_i^{\perp} = \bigsqcup \mathfrak{C}_i. \tag{4.14}$$

Inside the chambers, the Higgs branch is lifted, except for the fixed locus X<sup>A</sup>, which often is a discrete set of points corresponding to massive vacua. Specializing real masses to the walls makes some of the matter multiplets massless, partially unlifting the Higgs branch and restoring some of its flat directions. The full Higgs branch is restored at the origin of the mass space, where all the walls intersect. If we specialize to the walls both in the real mass and real FI parameter spaces, the mixed branches (involving the Higgs and Coulomb directions) open up.

Therefore, the mass Janus is also determined (in the Q-cohomology, or, equivalently, up to a quasi-isomorphism) by the choice of masses at y = ±∞. At each of the two infinities, or boundaries, we either pick a chamber or a particular component of the wall in the space of real masses. In the relation to stable envelopes later in this paper, we will often take masses to infinity, which really means taking them to infinity within a chosen chamber.

To finish this subsection, let us summarize what we have so far. There are two classes of half-BPS interfaces in 3d N = 2 theories preserving 2d N = (0, 2) SUSY. They are given by Janus interfaces for real masses and real FI parameters. We will wrap these interfaces on the elliptic curve E<sup>τ</sup> , and view them as operators acting in the Hilbert space H[E<sup>τ</sup> ] on E<sup>τ</sup> . When working in the Q-cohomology of H[E<sup>τ</sup> ], both interfaces become "canonical", in the sense that they do not depend on the profiles of masses/FI parameters, and at most depend on their asymptotic values. We will denote these operators as

$$\mathcal{J}_m(m_1, m_2), \quad \mathcal{J}_{\zeta}(\zeta_1, \zeta_2),$$
 (4.15)

for the mass and FI cases respectively, where the arguments represent values of the cor-

responding parameters at y = −∞ and +∞. In fact, the operators will only capture the chamber or wall in which the asymptotic values lie. Thus they provide certain chamberdependent linear maps acting between the spaces of vacua on E<sup>τ</sup> . Reducing from 3d to 2d and 1d preserves all these statements, and only changes the periodicity of equivariant and K¨ahler parameters, (x, ~) and z, respectively. Janus interfaces, considered as operators in the Q-cohomology, obey the following natural identities:

<span id="page-60-2"></span>
$$\mathcal{J}_m(m_1, m_2)\mathcal{J}_m(m_2, m_3) = \mathcal{J}_m(m_1, m_3),$$

$$\mathcal{J}_{\zeta}(\zeta_1, \zeta_2)\mathcal{J}_{\zeta}(\zeta_2, \zeta_3) = \mathcal{J}_{\zeta}(\zeta_1, \zeta_3),$$
(4.16)

which are proved by stacking the interfaces one after another, and using their independence of the intermediate values of masses or FI parameters.

### <span id="page-60-0"></span>5 Analysis via supersymmetric quantum mechanics

It is illuminating to have an alternative approach to the mass Janus based on the operator formulation. In this section, we develop it in the case of quantum mechanics only, as generalizations to higher dimensions are conceptually straightforward. Passing to 2d corresponds to replacing the target space by its loop space, and working equivariantly with respect to the loop rotations (i.e., treating them as part of flavor symmetries). Passing to 3d, likewise, corresponds to working with the double loops.

### <span id="page-60-1"></span>5.1 Time-dependent Morse function

Let us start with a system of free chiral multiplets φ <sup>i</sup> with the real mass matrix m(y) = diag(m1(y), . . . , mn(y)) that depends on the Euclidean time y. We switch off the equivariant parameters first for simplicity, so the action is:

$$L = |\dot{\phi}^i|^2 + \overline{\phi}^i(m^2 - \dot{m})\phi^i - i\overline{\psi}^i\gamma^3\dot{\psi}^i + i\overline{\psi}^i m\psi^i + \overline{F}^i F^i, \tag{5.1}$$

where the dot denotes the y derivative. This action preserves two supercharges, and their sum is our Q. Let us rewrite this in terms of the real coordinates X<sup>µ</sup> , µ = 1, . . . , 2n on the target, such that φ <sup>j</sup> = <sup>√</sup> 1 2 (X<sup>j</sup> + iX<sup>n</sup>+<sup>j</sup> ). For the fermions (ψ i α , ψ i α ), the components ψ i 2 and ψ i 2 are relabeled as the tangent fermion ψ µ , while the components ψ i 1 , ψ i 1 are relabeled as the cotangent fermion χµ. The action becomes:

$$L = \frac{1}{2}g_{\mu\nu}\dot{X}^{\mu}\dot{X}^{\nu} + \frac{1}{2}g^{\mu\nu}\partial_{\mu}f\partial_{\nu}f + \frac{1}{2}g^{\mu\nu}F_{\mu}F_{\nu} + i\chi_{\mu}(\dot{\psi}^{\mu} + g^{\mu\nu}D_{\nu}\partial_{\lambda}f\psi^{\lambda}) - \frac{\partial f}{\partial y}, \tag{5.2}$$

where gµν = δµν, and

$$f(X^{\mu}, y) = \frac{1}{2} X m(y) X = \frac{1}{2} \sum_{j} m_{j}(y) (X^{j} X^{j} + X^{n+j} X^{n+j}), \tag{5.3}$$

and ∂f ∂y = 1 <sup>2</sup>XmX˙ only includes the derivative of m(y) due to its explicit y-dependence. The supercharge Q acts as follows:

$$QX^{\mu} = \psi^{\mu}, \qquad Q\chi_{\mu} = i\dot{X}_{\mu} + F_{\mu} + i\partial_{\mu}f,$$

$$Q\psi^{\mu} = 0, \qquad QF_{\mu} = -i\dot{\psi}_{\mu} - iD_{\mu}\partial_{\nu}f\psi^{\nu}.$$
(5.4)

The action can also be written as:

<span id="page-61-1"></span>
$$L = \mathcal{Q}\left[-\frac{\mathrm{i}}{2}\chi_{\mu}(\dot{X}^{\mu} + \partial^{\mu}f + \mathrm{i}F^{\mu})\right] - \frac{\mathrm{d}f}{\mathrm{d}y}.$$
 (5.5)

If the mass is constant, i.e., ∂f/∂y = 0, then this is just the well-known quantum mechanics of [\[65\]](#page-142-2), with f playing the role of Morse function. The essence of our problem is, therefore, in making the Morse function time-dependent. We could also be slightly more general, and instead of starting with chiral multiplets in a theory with four supercharges, simply consider a general N = (1, 1) quantum mechanics with time-dependent Morse function f.

It is straightforward to find expressions for the Hamiltonian H and the supercharge Q:

$$H = \frac{1}{2}p^{\mu}p_{\mu} + \frac{1}{2}\partial^{\mu}f\partial_{\mu}f + i\chi_{\mu}D^{\mu}\partial_{\nu}f\psi^{\nu} - i\frac{\partial f}{\partial t},$$
  

$$Q = -i\psi^{\mu}p_{\mu} + \psi^{\mu}\partial_{\mu}f.$$
(5.6)

Here p<sup>µ</sup> is a conjugate momentum to X<sup>µ</sup> , and χ<sup>µ</sup> is canonically conjugate to ψ µ . We also temporarily Wick-rotated to the real time t = −iy. After quantization, as usual identifying ψ <sup>µ</sup> = dx µ , χ<sup>µ</sup> = iι<sup>∂</sup><sup>µ</sup> , and choosing an ordering, we get:

$$H = \frac{1}{2} \left( \{ \mathbf{d}, \mathbf{d}^* \} + \partial^{\mu} f \partial_{\mu} f - D^{\mu} \partial_{\nu} f \left[ \iota_{\partial_{\mu}}, \mathbf{d} x^{\nu} \right] \right) - i \frac{\partial f}{\partial t}, \tag{5.7}$$

<span id="page-61-0"></span>
$$Q = d + df \wedge . (5.8)$$

If f were time-independent, there would be one more conserved supercharge Q† given by

$$Q^{\dagger} = d^* + \iota_{\nabla f}. \tag{5.9}$$

Using this expression as the definition of Q† even in the time-dependent case, we have:

<span id="page-62-0"></span>
$$H = \frac{1}{2} \{ \mathcal{Q}, \mathcal{Q}^{\dagger} \} - i \frac{\partial f}{\partial t}.$$
 (5.10)

The operator Q as written in [\(5.8\)](#page-61-0) explicitly depends on time through f. Therefore, when we say that Q is conserved, we mean that the following equation holds:

$$\frac{\mathrm{d}\mathcal{Q}}{\mathrm{d}t} \equiv \mathrm{i}[H,\mathcal{Q}] + \frac{\partial\mathcal{Q}}{\partial t} = 0. \tag{5.11}$$

In general, we let the Morse function interpolate between two asymptotics:

$$f(X,t) \longrightarrow \begin{cases} f_{-}(X), \text{ as } t \to -\infty, \\ f_{+}(X), \text{ as } t \to +\infty, \end{cases}$$
 (5.12)

which determines a Q-closed "interface" between the two quantum mechanics with Morse functions f<sup>−</sup> and f+. This operator is clearly not unitary (we do not expect a generic operator to be unitary anyways), which is manifested in our construction by H in [\(5.10\)](#page-62-0) being non-Hermitian. Hermiticity of the Hamiltonian is violated precisely in the region where ∂f ∂t 6= 0.

We can perform a non-unitary "canonical transformation" on wave functions:

$$\Psi \mapsto \Omega = e^f \Psi, \tag{5.13}$$

after which we obtain:[11](#page-62-1)

$$\mathbb{Q} = e^f \mathcal{Q} e^{-f} = \mathbf{d}, \qquad \mathbb{G} = e^f \mathcal{Q}^{\dagger} e^{-f} = \mathbf{d}^* + 2\iota_{\nabla f},$$

$$\mathbb{H} = \frac{1}{2} \{ \mathbb{Q}, \mathbb{G} \} = \frac{1}{2} \{ \mathbf{d}, \mathbf{d}^* \} + \mathcal{L}_{\nabla f}, \tag{5.14}$$

<span id="page-62-1"></span><sup>11</sup>Here one has to take into account that H transforms as connection, i.e., it gets shifted by i ∂f ∂t , in addition to the conjugation by e f .

and the inner product becomes:

<span id="page-63-2"></span><span id="page-63-1"></span>
$$\langle \Omega_1, \Omega_2 \rangle = \int e^{-2f} \star \overline{\Omega}_1 \wedge \Omega_2,$$
 (5.15)

This transformation corresponds to dropping the "topological term" in the Lagrangian [\(5.5\)](#page-61-1):

$$L = \mathcal{Q}\left[-\frac{i}{2}\chi_{\mu}(\dot{X}^{\mu} + \partial^{\mu}f + iF^{\mu})\right]$$
$$= \frac{1}{2}g_{\mu\nu}(\dot{X}^{\mu} + \partial^{\mu}f)(\dot{X}^{\nu} + \partial^{\nu}f) + \frac{1}{2}g^{\mu\nu}F_{\mu}F_{\nu} + i\chi_{\mu}(\dot{\psi}^{\mu} + g^{\mu\nu}D_{\nu}\partial_{\lambda}f\psi^{\lambda}).$$
(5.16)

In such a formulation, Q = d is a time-independent operator, and the Hamiltonian H is Q -exact. Because of that, the de Rham cohomology class of the state Ω does not change under the time evolution (and in particular is not sensitive to how exactly f interpolates between f<sup>−</sup> and f+). This seems like a bad news: The interface between f<sup>−</sup> and f<sup>+</sup> appears transparent (i.e., equal to the identity) in the cohomology.

This argument is totally true when the target space of quantum mechanics is compact. When it is non-compact, however, there is a caveat. Our interface is defined via a non-unitary deformation of the theory, and under such a non-unitary evolution, an L 2 -normalizable wave function on the non-compact space may turn unnormalizable. Then we conclude that the corresponding state "quits" the Hilbert space.

#### <span id="page-63-0"></span>5.1.1 A toy example

This can be illustrated in a simple example of the target space C, with the Morse function f = 1 <sup>2</sup>m|z| 2 , where m is a real coefficient that may depend on time. For time-independent m, we can write two states annihilated by the Hamiltonian:

$$\psi_0 = e^{-f}, \qquad \psi_2 = e^f dz \wedge d\overline{z},$$

$$(5.17)$$

where ψ<sup>0</sup> is L 2 for m > 0, and ψ<sup>2</sup> is L 2 for m < 0.

Now if the mass m depends on time, the function ψ<sup>0</sup> still solves the Schr¨odinger equation (with our non-unitary deformation), while ψ<sup>2</sup> does not. We can thus start with m > 0 and the normalizable vacuum ψ<sup>0</sup> in the far past, and change the mass to a negative value −m in the far future. The state ψ0, still being a solution, will remain equal to e −f , which is not L 2 for the negative mass in the far future. Thus the quantum state ψ<sup>0</sup> "quits" the Hilbert space

due to the non-unitary evolution, while ψ<sup>2</sup> "enters" it. What does make sense, however, is to compute the overlap of ψ<sup>0</sup> with an L 2 state ψ<sup>2</sup> in the future. In the case at hands, we simply get zero,

$$\langle \psi_2 | \psi_0 \rangle = 0, \tag{5.18}$$

as ψ<sup>0</sup> and ψ<sup>2</sup> have fermion numbers zero and two, respectively (and the fermion number is conserved).

Despite the appearance of unnormalizable states, the path integral computing the (possibly non-unitary) evolution is perfectly well-defined, since the Hilbert space norm plays no role in such computations. Let us elaborate this in slightly more detail. The initial state ψ<sup>0</sup> = e −f , after the similarity transformation, corresponds to a form

$$\Omega = 1, \tag{5.19}$$

which in the path integral (with the "topological term" dropped),

$$\int \mathcal{D}X \mathcal{D}F \mathcal{D}\psi \mathcal{D}\chi \, e^{-\int dy \frac{1}{2} (\dot{X} + \nabla f)^2 + \dots} \tag{5.20}$$

can be taken as the initial condition, realized via the supersymmetric Neumann boundary:

<span id="page-64-0"></span>
$$\chi_{\mu} | = 0, \quad (\dot{X} + \nabla f) | = 0.$$
 (5.21)

To compute the wave function that is produced at the output, we need to impose Dirichlet boundary conditions at the other end (in the far future):

<span id="page-64-1"></span>
$$|\psi^{\mu}| = 0, \quad X^{\mu}| = x^{\mu}.$$
 (5.22)

This will compute the super wave function Ω(x, θ) at the output. In principle, it only gives Ω(x, θ) <sup>θ</sup>=0, but the conservation of the fermion number (and because Ω = 1 in the far past) guarantees that there are no terms proportional to θ <sup>µ</sup> ≡ dx µ . One can easily perform localization with [\(5.21\)](#page-64-0) and [\(5.22\)](#page-64-1) at the two ends: All the Fermi zero modes are eliminated; the BPS equation X˙ + ∇f = 0, subject to X<sup>µ</sup> <sup>=</sup> <sup>x</sup> µ in the far future, has a unique solution; and the one-loop determinants cancel. One finds the expected answer Ω(x, θ) = 1. Note that this computation does not depend on the normalizability of state at any point in time, and in fact the norm simply plays no role.

Using the inner product [\(5.15\)](#page-63-1) written in terms of Ω, we indeed see that 1 has zero

overlap with Ω<sup>2</sup> = e <sup>2</sup><sup>f</sup>dz ∧ dz corresponding to ψ2:

$$\langle 1, \Omega_2 \rangle = \int e^{-2f} \star 1 \wedge \Omega_2 = 0. \tag{5.23}$$

If we want to have a non-zero overlap, i.e., a non-trivial vacuum-vacuum transition, turning on equivariant parameters helps.

#### <span id="page-65-0"></span>5.2 Equivariant extension

It is straightforward to reintroduced equivariance into the problem, which we neglected at first. Namely, suppose that V () generates an isometry of the target (with an equivariant parameter), and that f is invariant, L<sup>V</sup> ()f = 0. Then the conserved supercharge is extended in the usual way:

$$Q = d + df \wedge + \iota_{V(\epsilon)}, \tag{5.24}$$

so that Q<sup>2</sup> = L<sup>V</sup> () . The conjugate supercharge (broken by the time-dependence of f) is

$$Q^{\dagger} = d^* + \iota_{\nabla f} + V^{\flat}(\bar{\epsilon}) \wedge, \tag{5.25}$$

where V [ is the one-form dual to V via the metric. The Hamiltonian is still given by the same formula:

$$H = \frac{1}{2} \{ \mathcal{Q}, \mathcal{Q}^{\dagger} \} - i \frac{\partial f}{\partial t}, \tag{5.26}$$

so that Q is indeed conserved,

$$i[H,Q] + \frac{\partial Q}{\partial t} = 0.$$
 (5.27)

We can still perform the similarity transformation and obtain:

$$\mathbb{Q} = e^f \mathcal{Q} e^{-f} = d + \iota_{V(\epsilon)}, \quad \mathbb{G} = e^f \mathcal{Q}^{\dagger} e^{-f} = d^* + 2\iota_{\nabla f} + V^{\flat}(\overline{\epsilon}) \wedge, \quad \mathbb{H} = \frac{1}{2} \{ \mathbb{Q}, \mathbb{G} \}.$$
 (5.28)

The variation of f(X, t) by δf(X, t) is still a Q -exact deformation, therefore, everything we said about the interpolation between f<sup>−</sup> and f<sup>+</sup> defining the interface is still true.

#### <span id="page-65-1"></span>5.2.1 Toy example continued

We can now resume discussing the toy example with C as a target and f = 1 <sup>2</sup>m|z| 2 , but now also including the equivariant parameter for the U(1) rotation of the complex plane. With some work, we can identify the unique normalizable ground state of this system:

$$\Psi = e^{-f}\Omega^{(m)}, \quad \Omega^{(m)} = \frac{\epsilon}{\sqrt{2\pi(\omega - m)}} e^{-\frac{1}{2}(\omega - m)|z|^2 - i\frac{\omega - m}{2\epsilon} dz \wedge d\overline{z}}, \text{ where } \omega = \sqrt{m^2 + |\epsilon|^2}.$$
(5.29)

This solution is L 2 -normalizable for any m ∈ R, circumventing the problem we had before.

We can use this solution to compute the transition amplitude across the mass-changing interface. However, the explicit solution Ω(m) as presented above does not solve the Schrodinger equation with time-dependent mass. Instead of finding such a more general solution, we may simply use the independence on the precise mass profile, and assume that it behaves as a step function, remaining constant most of the time and experiencing a jump at t = 0:

<span id="page-66-0"></span>
$$m(t) = \begin{cases} m_1, & t < 0 \\ m_2, & t > 0 \end{cases}$$
 (5.30)

This jump, due to the term −i ∂f ∂t , adds a delta-function potential in H, while the Hamiltonian H remains finite at all times. Thus the wave function Ω, which evolves according to H , stays continuous across the jump, while Ψ jumps. Suppose the system was in the vacuum state Ω (m1) for t < 0. Right after the jump, it still is described by the wave function Ω(m1) , but it is no longer a vacuum. We have to compute its overlap with the new vacuum Ω(m2) , using the inner product as in [\(5.15\)](#page-63-1), with f corresponding to the region t > 0:

$$R[m_1 \to m_2] = \int e^{-m_2|z|^2} \star \overline{\Omega^{(m_2)}} \wedge \Omega^{(m_1)}.$$
 (5.31)

Where we denoted by R[m<sup>1</sup> → m2] the overlap that computes the vacuum-vacuum transition amplitude across the mass-changing Janus interface, with the mass m<sup>1</sup> at the input and m<sup>2</sup> at the output. It is straightforward to compute the integral:

$$R[m_1 \to m_2] = \sqrt{\frac{\omega_2 - m_2}{\omega_1 - m_1}}.$$
 (5.32)

Notice that the transitivity property R[m<sup>2</sup> → m3] ◦ R[m<sup>1</sup> → m2] = R[m<sup>1</sup> → m3] is obeyed, which confirms the expectation that only the asymptotic values of masses are important.

The object like R[m → −m] is the prototype of R-matrices in our future applications, while R[m → 0] is the prototype of stable envelopes.

Another observation is that Ω(m) from [\(5.29\)](#page-66-0) reduces to 1 as m → +∞, up to a divergent factor of √ 2π(ω−m) . The support of 1 is the entire C, which happens to be the attractor of the origin for m > 0. Likewise, if we send m → −∞ (and ignore the same pre-factor √ 2π(ω−m) that now vanishes in this limit), Ω(m) tends to δ 2 (z)dz ∧ dz. Its support is just the origin of C, which is the only point in the attractor for m < 0. The singular pre-factors appear as an irrelevant nuisance, but they might become more problematic in higher-dimensional QFT. However, if we have twice as many supercharges, we are talking about the hypermultiplet that consists of a chiral I of mass m (and equivariant parameter ) and a chiral J of mass <sup>−</sup><sup>m</sup> (and equivariant parameter <sup>e</sup>). In this case, the problematic prefactors combine into:

$$\frac{\epsilon \widetilde{\epsilon}}{2\pi \sqrt{(\omega - m)(\widetilde{\omega} + m)}} \to \begin{cases}
\frac{\epsilon \widetilde{\epsilon}}{2\pi |\epsilon|} & \text{if } m \to +\infty \\
\frac{\epsilon \widetilde{\epsilon}}{2\pi |\widetilde{\epsilon}|} & \text{if } m \to -\infty
\end{cases}$$
(5.33)

and have finite limits. Thus in the m → ±∞ limits, the product of two wave functions Ω (m)Ωe(−m) has a reasonable behavior:[12](#page-67-0) it simply becomes proportional to the delta-form supported on the attractor of the origin.

It is also instructive to look at the R-matrix of one hypermultiplet, which is given by <sup>R</sup>[<sup>m</sup> → −m] · <sup>R</sup>e[−<sup>m</sup> <sup>→</sup> <sup>m</sup>] (with tilde signifying that the second factor contains the equivariant parameter <sup>e</sup>). It equals:

$$\sqrt{\frac{\omega - m}{\omega + m}} \sqrt{\frac{\widetilde{\omega} + m}{\widetilde{\omega} - m}} \approx \frac{|\epsilon|}{|\widetilde{\epsilon}|} \quad \text{as } m \to \infty.$$
 (5.34)

Of course, this computation only produces the answer up to a phase (as the wave function [\(5.29\)](#page-66-0) was only defined up to a phase), hence we might as well write

$$\frac{\epsilon}{\tilde{\epsilon}} \tag{5.35}$$

as an answer. To get such a simple result, it was important to take the limit m → ∞.

In this limit, the vacuum wave functions Ω(m)Ωe(−m) become delta-forms, as we now know, and can be mimicked by the appropriate boundary conditions given by the complex Lagrangian submanifolds (on which the delta-form was supported). If we factorize the Rmatrix as

$$R[0 \to -m] \cdot \widetilde{R}[0 \to m] \times R[m \to 0] \cdot \widetilde{R}[-m \to 0],$$
 (5.36)

<span id="page-67-0"></span><sup>12</sup>Here Ω is the same as Ω with the equivariant parameter <sup>e</sup> replaced by <sup>e</sup>.

the factor  $R[m \to 0] \cdot \widetilde{R}[-m \to 0]$  corresponds to the jump of masses from (m, -m) to (0, 0). This jump is where the state  $\Omega^{(m)}\widetilde{\Omega}^{(-m)}$  enters the massless region, and in the limit  $m \to +\infty$ , it can be replaced by the  $\frac{1}{2}$ -BPS boundary conditions for the pair (I, J) of chirals:<sup>13</sup>

<span id="page-68-2"></span>
$$I| = 0, \quad \partial_y J| = 0. \tag{5.37}$$

Likewise, the jump  $R[0 \to -m] \cdot \tilde{R}[0 \to m]$  can be replaced by exactly the same boundary conditions at the location were masses jump from (0,0) to (-m,m) (in the limit  $m \to +\infty$ ). Hence, we end up with an interval partition function with the same boundary conditions (5.37) on both ends. Such a partition function is computed by identifying zero modes: the chiral multiplet I subject to I|=0 on both ends leads to one Fermi zero mode, while I leads to one bosonic zero mode, and together they give the expected answer  $\epsilon/\tilde{\epsilon}$ . The interval non-zero modes completely cancel out in the one-loop determinants (see, e.g., [167]), which is an expected features of theories that do not break SUSY dynamically: Changing the size of the interval is realized via the Hamiltonian evolution, which is Q-exact and does not affect BPS observables. Thus SUSY computations should not depend on the length of the interval, and, consequently, can only capture the contribution of the interval zero modes.

One of the many lessons we learned from this example is the importance of  $m \to \infty$  limit. Without it, the answer is a complicated function of m, which is not what we want. We are interested in quantities that have natural interpretation in the equivariant cohomology, and thus only contain equivariant parameters (and Kähler parameters in the higher-dimensional generalizations).

### <span id="page-68-0"></span>5.3 Including holomorphic superpotential

In the case of Kähler target space, it is straightforward to also include the holomorphic superpotential. Namely, suppose we pick a holomorphic function of chiral multiplets W, which is invariant with respect to the gradient flow,

$$g^{\mu\nu}\partial_{\mu}f\partial_{\nu}W = 0, \tag{5.38}$$

and preserves the symmetry,  $\mathcal{L}_{V(\epsilon)}W = 0$ . More generally, one may allow W to be multivalued, while  $\partial W$  must be a globally defined (1,0)-form. Then the theory admits a deformation  $f \mapsto f + \text{Re}(\kappa W)$  that preserves all the symmetries, where  $\kappa$  is a complex number.

<span id="page-68-1"></span><sup>&</sup>lt;sup>13</sup>Such boundary conditions will be justified in Section 6.2.

In our conventions κ = −2i, and the preserved supercharge becomes:

$$Q = d + df \wedge + \iota_{V(\epsilon)} + 2d(\operatorname{Im} W) \wedge, \tag{5.39}$$

while the supercharge that is broken by the time-dependence of f is:

$$Q^{\dagger} = d^* + \iota_{\nabla f} + V^{\flat}(\overline{\epsilon}) \wedge + 2\iota_{\nabla \operatorname{Im}(W)}. \tag{5.40}$$

As expected, we still have

$$H = \frac{1}{2} \{ \mathcal{Q}, \mathcal{Q}^{\dagger} \} - i \frac{\partial f}{\partial t}, \tag{5.41}$$

ensuring that the conservation equation i[H, Q] + <sup>∂</sup><sup>Q</sup> ∂t = 0 holds.

#### <span id="page-69-0"></span>5.4 Gauged quantum mechanics

In the general setting of N = (1, 1) quantum mechanics, gauging is performed by adding vector multiplets in the adjoint of g. The appropriate vector multiplet contains a gauge field, a complex scalar, and a pair of fermions, (A<sup>t</sup> , σC, σC, λ, λ), with the SUSY:

<span id="page-69-1"></span>
$$Q\sigma_{\mathbb{C}} = 0, \quad Q\overline{\sigma}_{\mathbb{C}} = \overline{\lambda}, \quad QA_t = i\lambda,$$

$$Q\lambda = iD_t\sigma_{\mathbb{C}}, \quad Q\overline{\lambda} = i[\sigma, \overline{\sigma}], \qquad (5.42)$$

and the action:

$$\mathcal{L} = \frac{1}{e^2} \mathcal{Q} \operatorname{Tr} \left( -i\lambda D_t \overline{\sigma}_{\mathbb{C}} - i\overline{\lambda} [\overline{\sigma}_{\mathbb{C}}, \sigma_{\mathbb{C}}] \right) 
= \frac{1}{e^2} \operatorname{Tr} \left( D_t \overline{\sigma}_{\mathbb{C}} D_t \sigma_{\mathbb{C}} + i\lambda D_t \overline{\lambda} - [\sigma_{\mathbb{C}}, \overline{\sigma}_{\mathbb{C}}]^2 + i[\lambda, \overline{\sigma}_{\mathbb{C}}] \lambda - i[\overline{\lambda}, \sigma_{\mathbb{C}}] \overline{\lambda} \right).$$
(5.43)

The SUSY Noether current for the vector multiplet is Q<sup>g</sup> = λDtσ+[σC, σC]λ, which quantum mechanically becomes

$$Q_{\mathfrak{g}} = \overline{\partial} + \operatorname{Tr}\left[\sigma_{\mathbb{C}}, \overline{\sigma}_{\mathbb{C}}\right] \iota_{\partial/\partial \overline{\sigma}_{\mathbb{C}}} \quad \text{acting on } \Omega^{(0,\cdot)}(\mathfrak{g} \otimes \mathbb{C}). \tag{5.44}$$

This immediately tells us how to gauge some symmetry G of a general quantum-mechanical sigma model with target X. For that, we simply promote the equivariant parameter to a complex coordinate σ<sup>C</sup> on g<sup>C</sup> ≡ g ⊗ C. Now the Hilbert space is identified with (the square-integrable part of)

$$\left[\Omega^{\cdot}(X) \otimes \Omega^{(0,\cdot)}(\mathfrak{g}_{\mathbb{C}})\right]^{\mathfrak{g}},\tag{5.45}$$

where we take the  $\mathfrak{g}$ -invariant subspace, due to the Gauss law constraint enforced by the gauge field  $A_t$ . The total  $\mathcal{Q}$  operator is:

$$Q = d_X + df \wedge + \iota_{V(\sigma_{\mathbb{C}})} + \overline{\partial}_{\mathfrak{g}} + \operatorname{Tr}\left[\sigma_{\mathbb{C}}, \overline{\sigma}_{\mathbb{C}}\right] \iota_{\partial/\partial \overline{\sigma}_{\mathbb{C}}}, \tag{5.46}$$

where  $V(\sigma_{\mathbb{C}})$  generates the G-action on X, and we ignored the obvious possibility of additional (ungauged) flavor symmetries. We used  $d_X$  to denote the de Rham differential on X, and  $\overline{\partial}_{\mathfrak{g}}$  – the Dolbeault differential on  $\mathfrak{g}_{\mathbb{C}}$ .

One can then identify:

$$Q^{\dagger} = d_X^* + \iota_{\nabla f} + V^{\flat}(\overline{\sigma}_{\mathbb{C}}) \wedge + \overline{\partial}_{\mathfrak{q}}^* + \operatorname{Tr}\left[\sigma_{\mathbb{C}}, \overline{\sigma}_{\mathbb{C}}\right] d\overline{\sigma}_{\mathbb{C}}$$

$$(5.47)$$

The Hamiltonian is still given by  $H = \frac{1}{2} \{ \mathcal{Q}, \mathcal{Q}^{\dagger} \} - i \frac{\partial f}{\partial t}$ .

#### <span id="page-70-0"></span>5.5 General setting

Our general setup in 1d is a gauged quantum mechanics with  $X = \mathcal{R} \times \overline{\mathcal{R}} \times \mathfrak{g}_{\mathbb{C}} \times \mathfrak{g}$ , where the  $\mathcal{R} \times \overline{\mathcal{R}}$  factor describes hypermultiplets,  $\mathfrak{g}_{\mathbb{C}}$  corresponds to the adjoint-valued chiral  $\Phi$ , and  $\mathfrak{g}$  – to the real scalar  $\sigma$ . As usual,  $\mathcal{R}$  is a complex representation of the gauge group G, so that X admits an action of G. Note that, in addition to  $\mathfrak{g}_{\mathbb{C}} \times \mathfrak{g}$ , we add yet another factor of  $\mathfrak{g}_{\mathbb{C}}$  to the target space in the process of gauging, as explained earlier.

Then we include the Morse function (real superpotential)

$$f = \overline{\phi}(\sigma + m(y))\phi - \zeta_{\mathbb{R}} \cdot \sigma \equiv m(y) \cdot \mu_{\mathbb{R}}^{f} + \sigma \cdot \widetilde{\mu}_{\mathbb{R}}^{g}, \tag{5.48}$$

where  $\phi$  runs over all chiral multiplets,  $\zeta_{\mathbb{R}}$  is the real FI parameter, and  $\mu_{\mathbb{R}}^{f}$ ,  $\widetilde{\mu}_{\mathbb{R}}^{g}$  are the real flavor and gauge moment maps, with the latter including the real FI term. In theories with eight supercharges, it is customary to separate the contributions of  $\zeta_{\mathbb{R}}$  and the adjoint chiral  $\Phi$  in  $\widetilde{\mu}_{\mathbb{R}}^{g}$ :

$$\widetilde{\mu}_{\mathbb{R}}^{g} = \mu_{\mathbb{R}}^{g} + \frac{1}{e^{2}} [\Phi, \overline{\Phi}] - \zeta_{\mathbb{R}}. \tag{5.49}$$

Finally, the holomorphic superpotential is as in the 3d theory:

$$W = \widetilde{Q}\Phi Q, \quad Q \in \mathcal{R}, \quad \widetilde{Q} \in \overline{\mathcal{R}}, \tag{5.50}$$

and we include the equivariant deformation by  $V(\epsilon)$  for all flavor symmetries that were not gauged.

At low energies, assuming  $\zeta_{\mathbb{R}}$  is generic enough, the theory is effectively described as a nonlinear sigma model (NLSM) into the Higgs branch, with the Morse potential and the equivariant deformation present. The Morse potential simply follows from the Morse potential of the gauge theory by setting  $\sigma = 0$ :

<span id="page-71-1"></span>
$$f = m(y) \cdot \mu_{\mathbb{R}}^{f} = \overline{\phi}m(y)\phi, \tag{5.51}$$

where the latter expression is restricted to the zero level of the real and complex gauge moment maps, which then naturally descends to the quotient  $\mathcal{M}_H$ . The equivariant deformation is still encoded in a vector field  $V(\epsilon)$  on  $\mathcal{M}_H$ .

#### <span id="page-71-0"></span>5.6 Localization and gradient trajectories

The quantum mechanics described above localizes to the gradient flows for f, either in the gauge description or in the NLSM description, which is already manifested by the first term in (5.16).

In the gauge theory description, the metric of the target space is  $\frac{1}{e^2} \text{Tr } d\sigma^2 + \sum_{\phi \in \text{chirals}} |d\phi|^2$ , and the corresponding gradient flow is

$$D_y \phi = -(\sigma + m(y))\phi$$
, for each chiral  $\phi$ ,  
 $D_y \sigma = -e^2 \widetilde{\mu}_{\mathbb{R}}^{\mathrm{g}}$ . (5.52)

In the NLSM description (cf. [66, 67]), one instead finds gradient flow equations for the Morse function on the Higgs branch (5.51),

<span id="page-71-3"></span><span id="page-71-2"></span>
$$\partial_y X^\mu = -g^{\mu\nu} \partial_\nu f, \tag{5.53}$$

where g is the classical metric on the Higgs branch (which is known to receive no quantum corrections).

Both types of equations admit solutions that connect **A**-fixed points on the Higgs branch. Suppose  $p_1$  and  $p_2$  are two such points. In the NLSM description, the solution to (5.53) is a flow from  $p_1$  to  $p_2$  that manifestly belongs to a single  $\mathbf{A}_{\mathbb{C}}$ -orbit on the Higgs branch. Gradient flows that solve the gauge-theoretic BPS equations (5.52), however, do not remain on the Higgs branch: While at the end points  $D_y \sigma = 0$ , so the real moment map equation  $\widetilde{\mu}_{\mathbb{R}}^g = 0$  is obeyed, the intermediate region has  $D_y \sigma \neq 0$ , so  $\widetilde{\mu}_{\mathbb{R}}^g \neq 0$  and the trajectory gets off the Higgs branch, viewed as a subquotient inside some bigger space. More precisely, it leaves the Higgs branch corresponding to the fixed value of the FI parameter  $\zeta_{\mathbb{R}}$ , but still remains within the union of complexified gauge orbits of the Higgs branch points, at least if the value of  $D_y \sigma$  is generic (so the trajectory stays away from the unstable locus). At some non-generic moments of time, the trajectory could, in principle, pass through the unstable region. In truth, however, this does not happen, because the first equation in (5.52) simply describes the flow as the complexified gauge and flavor transformation that depends on y. We can illustrate the relationship between the gauge and NLSM descriptions in the following pictorial way:

![](_page_72_Picture_1.jpeg)

Figure 3: The blue curve represents the gradient trajectory on the Higgs branch solving (5.53), the red curve represents the gauge-theoretic gradient trajectory that solves (5.52), and the orange arrows represent the complexified gauge transformation that relates the two. Since all points along the blue curve are stable, so are the points of the red curve.

It is therefore clear that the gauge theoretic and NLSM gradient trajectories are in one to one correspondence with each other. It could be more intuitive to work with the latter (especially since in both approaches trajectories start and end on the Higgs branch), but the gauge theoretic description is more useful for explicit computations of the matrix elements.

#### <span id="page-73-0"></span>5.6.1 Example of a solution

It is instructive to write down an explicit solution of the GLSM gradient flow equations in at least one example. To this end, consider a U(1) gauge theory with a pair of charge +1 hypers,  $(I_1, J_1)$  and  $(I_2, J_2)$ , where the chirals  $I_i$  both have gauge charge +1, while their flavor charges are opposite and taken to be  $\pm 1$ . For a non-zero FI parameter  $\zeta$  (chosen to be positive), the theory has  $T^*\mathbb{C}P^1$  as its Higgs branch. The U(1) flavor symmetry has two fixed points given by the North and South poles of the zero section  $\mathbb{C}P^1$ . We turn on a real mass m > 0 for the flavor symmetry. Let us assume that it takes the special value obeying

$$e^2\zeta = 2m^2. (5.54)$$

In this case we can write an elementary analytic solution to the flow equations (the solution also exists for general m, but takes a more complicated form). It has  $J_1 = J_2 = 0$ , as well as  $\Phi = 0$  for the adjoint chiral. The non-zero fields are given by:

$$I_{1} = \frac{\sqrt{\zeta}}{1 + e^{2my}},$$

$$I_{2} = \frac{\sqrt{\zeta}}{1 + e^{-2my}},$$

$$\sigma = m \tanh(my).$$
(5.55)

We see that at  $y = -\infty$ ,  $(I_1, I_2) = (\sqrt{\zeta}, 0)$ , while at  $y = +\infty$ ,  $(I_1, I_2) = (0, \sqrt{\zeta})$ . At the same time,  $\sigma$  interpolates between -m and m. Thus, the trajectory connects the two fixed points in the base of the Higgs branch, which obeys  $|I_1|^2 + |I_2|^2 = \zeta$ . At the intermediate times we have

$$0 < |I_1|^2 + |I_2|^2 < \zeta, \tag{5.56}$$

clearly showing that the trajectory gets off the Higgs branch without leaving the stable locus. This solution demonstrates some of the key features of the gradient trajectories: (1) it takes infinite time to complete the transition between two critical points; (2) the trajectory stays close to the critical points most of the time, only significantly diverging from them in a time interval of order 1/m; (3) the transition is effectively instantaneous in the  $m \to \infty$  limit.

#### <span id="page-74-0"></span>5.6.2 Broken, or concatenated, trajectories

Back to the general discussion, an important phenomenon is that of "broken trajectories": in addition to simple one-component flows connecting two fixed points, there exist composite trajectories obtained by concatenating several simple segments. They must be taken into account due to the following reason. The leading term in the localizing action is given by:

$$s \int \mathrm{d}y (D_y X + \nabla f)^2. \tag{5.57}$$

As we take s → ∞, the path integral localizes to integration over those trajectories, on which R dy(DyX +∇f) 2 is vanishingly small. The space of such trajectories has many components: (1) they can be either of the form X0(y)+δX(y), where δX(y) is a small fluctuation around a simple gradient trajectory X0(y) (obeying DyX<sup>0</sup> +∇f(X0) = 0) that connects just two fixed points p<sup>1</sup> and p2; (2) or they can be trajectories that approximate the concatenated gradient flows going through multiple fixed points, p<sup>1</sup> → p<sup>2</sup> → · · · → pn. Now, the concatenated gradient trajectories are not, strictly speaking, solutions: Passing from p<sup>1</sup> to p<sup>2</sup> requires an infinite amount of time, so a solution that goes from p<sup>1</sup> to p2, and then to p3, already requires "twice-infinite" amount of time, and cannot be written as a single function X : R → Target. However, there exist approximate solutions X(y), which get arbitrarily close to the concatenated trajectory p<sup>1</sup> → · · · → pn, and on which the action R dy(DyX + ∇f) 2 , therefore, is arbitrarily small:[14](#page-74-1)

![](_page_74_Picture_4.jpeg)

Figure 4: A concatenated gradient trajectory (in black) and an approximate solution (in blue), which is described by a continuous function of time y ∈ R.

<span id="page-74-1"></span><sup>14</sup>To construct an example of an approximate solution, consider n gradient trajectories X<sup>i</sup> : R → Target, such that Xi(+∞) = Xi+1(−∞). Let us cut off the domain of X1(y) to y ∈ (−∞, T), the domain of X<sup>n</sup> – to y ∈ (−T, ∞), and the domains of X2(y), . . . , Xn−1(y) – to y ∈ (−T, T). Next we glue trajectories together in a smooth way, such that Xi(T) and Xi+1(−T) are connected by a small curve s<sup>i</sup> (minimal in some convenient sense). In the T → ∞ limit, this glued trajectory becomes an exact solution, while at finite T, the interpolating curves s<sup>i</sup> can be interpreted as Brownian motion in the vicinity of the fixed points that allows us to jump between different components of the concatenated trajectory.

Integration over such approximate solutions is expected to produce the one-loop determinant over the fluctuations around the concatenated trajectory, even though such a trajectory itself does not belong to the field space of the theory. This suggests that we may also consider a partial compactification of the field space that includes the concatenated trajectories as "points at infinity". Then the path integral over such a space admits the usual localization, both on simple and concatenated gradient trajectories. The multi-component instantons, also known as "multi-instantons", are long-known in the literature, see for example [\[168\]](#page-150-7) for a similar claim that they lie at infinity. A point of view advocated in [\[169\]](#page-150-8) is that they should be thought of as complex saddle points of the analytically continued theory. In the current work, we will not directly address these issues. Instead we will develop an effective description of the mass Janus in the next section, where this question does not even arise, yet the effect of "broken trajectories" is clearly present.

The necessity to include contributions from the concatenated trajectories is, in a sense, forced upon us by the non-compactness of spacetime: There exist smooth field configurations on R that are close to such trajectories, on which the action is vanishingly small, implying that they contribute in the supersymmetric localization. Other subtleties of similar nature might arise, which also require some sort of compactification of the field space. Rather than trying to plow through all these technical difficulties, one may take an alternatively route, where we cut off the non-compact ends of spacetime, replacing them by the appropriate boundary conditions that mimic the removed non-compact pieces. After this, we are left with compact spacetime, albeit with boundaries. Such a system is more straightforward to analyze.

Another way to argue for the need to take the broken trajectories into account, is to deform the theory by turning on an infinitesimally small complex FI parameter ζC. The ordinary gradient trajectories would limit, as ζ<sup>C</sup> → 0, to a union of trajectories, broken at the intermediate critical points.

#### <span id="page-75-0"></span>5.6.3 Flavor equivariant parameters

In the above discussion, we have been temporarily ignoring equivariant parameters, so now we turn them on. In the NLSM description, the equivariant deformation enforces almost everywhere the fixed point condition:

<span id="page-75-1"></span>
$$V(\epsilon) = 0, (5.58)$$

where collectively denotes equivariant parameters for flavor and U(1)<sup>~</sup> symmetries, and V () is the corresponding vector field on the NLSM target.

Saying that [\(5.58\)](#page-75-1) holds almost everywhere means that it can in fact be violated for very short periods of time. This is crucial for transitions between different fixed points to be possible, for otherwise, if [\(5.58\)](#page-75-1) holds identically, it simply freezes us into a chosen fixed point. Fortunately, this equation is enforced via a term s R dy |V ()| 2 in the localizing action, which only has to vanish in the s → ∞ limit. Thus it is enough to demand R dy |V ()| <sup>2</sup> = o(s −1 ), which is a weaker condition than being identically zero. Suppose the Morse function f on the Higgs branch corresponds to a real mass m. The transition between two consecutive fixed points takes an infinite amount of time, but most of that time the trajectory lingers close to one of the two fixed points. It only spends time of order <sup>1</sup> m significantly far from the fixed point. Therefore, on such a trajectory:

$$\int dy |V(\epsilon)|^2 \sim \frac{1}{m} \times \text{const} \to 0, \quad \text{as } m \to \infty.$$
 (5.59)

Since we indeed take the m → ∞ limit, the localization condition is obeyed, but the equation [\(5.58\)](#page-75-1) is violated at time instances at which jumps between the critical points happen. We see that this is the order of limits issue: it is important to take m → ∞ first (or at least much faster than s → ∞). This reflects the fact that m → ∞ is not just a computational trick: We really are interested in sending the real mass to infinity, such that the physical theory produces a delta-form state supported on the attractor of the fixed point.

If we try to include equivariant deformation in the GLSM description, however, we start running into all sorts of issues that ultimately have to do with the attempts to perform SUSY localization on the non-compact spacetime. Indeed, the equation [\(5.58\)](#page-75-1) gets replaced by its linear version:

$$(\epsilon + \sigma_{\mathbb{C}})\phi = 0, \tag{5.60}$$

where the quantum-mechanical gauge equivariant parameter σ<sup>C</sup> gets replaced by flat connections in higher dimensions, in particular, the flat connection A<sup>z</sup> on E<sup>τ</sup> in the 3d case. It follows from this equation that at the different fixed points, σ<sup>C</sup> takes different values, partly screening and allowing for φ to develop a vev. So σ<sup>C</sup> has to change its values along the gradient flow to allow transitions between the fixed points, but is it possible under the BPS equations? If we use the gauge kinetic term [\(5.43\)](#page-69-1) for the localization (in the e <sup>2</sup> → 0 limit), it appears that σ<sup>C</sup> must be constant. The trick that allowed to relax the condition [\(5.58\)](#page-75-1) does not work here: if σ<sup>C</sup> changes by ∆σ<sup>C</sup> over time m<sup>−</sup><sup>1</sup> , it leads to the action of order R |DyσC| <sup>2</sup>dy ∼ m|∆σC| 2 , which is large in the m → ∞ limit. On the other hand, one can find field configurations "at infinity" of the field space, such that R <sup>∞</sup> −∞ |DyσC| <sup>2</sup>dy = 0, yet R <sup>∞</sup> −∞ Dyσ<sup>C</sup> 6= 0. An easy example is

$$\sigma_{\mathbb{C}} = A \tanh \frac{y}{T},$$
(5.61)

which is very slowly-changing for large values of T, and R |∂yσC| <sup>2</sup>dy vanishes in the T → ∞ limit, yet R <sup>∞</sup> −∞ dy ∂yσ<sup>C</sup> = 2A. This suggests that it is possible to change σ<sup>C</sup> with time, as long as ∂yσ<sup>C</sup> is small enough. Again, this phenomenon clearly has its roots in the non-compactness of the time direction R.

It is expected that the detailed analysis of localization in GLSM on a non-compact spacetime would eventually resolve all the aforementioned problems. For example, it is conceivable that proper compactification of the field space contains BPS solutions that connect different fixed points, which we saw to be the case in the NLSM description. While it would be interesting to clarify this point, we instead describe a simpler approach in Section [6.2.](#page-82-0)

### <span id="page-77-0"></span>6 Relation to stable envelopes

As alluded to earlier, the Janus interface interpolating between zero and non-zero masses,

$$\mathcal{J}_m(0,m), \tag{6.1}$$

plays the role of a building block in our story, especially due to the relations [\(4.16\)](#page-60-2), Jm(m1, m2) = Jm(m1, 0)Jm(0, m2)+{Q, . . . }. We would like to have a more quantitative understanding of its properties, in particular, compute its matrix elements between the supersymmetric vacua in the limit of infinite masses. This will allow to make contact with the ideas of [\[51,](#page-141-1) [52\]](#page-141-2). A preview of what we find is: the stable envelopes introduced in those references (or, more precisely, the "pole subtraction matrix", which is proportional to stable envelopes) are realized via such mass Janus interfaces. In the following we focus primarily on the 3d case, with the 2d and 1d specializations following by the dimensional reduction as explained in Section [2.1.](#page-9-1)

### <span id="page-77-1"></span>6.1 Janus background and gradient flows

Consider the mass Janus Jm(m, 0) wrapped on E<sup>τ</sup> in the E<sup>τ</sup> × R geometry, where the real mass changes from 0 to m in a small neighborhood of y = 0. At y = −∞ and y = +∞ we fix the Higgs branch vacua (the FI terms ζ are taken to be y-independent), which may be different, and we would like to compute the transition amplitude as m → ∞.

Even though we do not perform a full localization analysis of such transition amplitudes, in this subsection we provide a qualitative discussion, relating it to some ideas in the math literature. The path integral localizes onto the BPS configurations, identified in the previous section with (concatenated) gradient trajectories. In the terminology often used in the literature on SUSY gauge theories, we use the Higgs branch localization scheme. Let us list all the BPS equations here for convenience:

$$\partial W = \overline{\partial W} = 0, \tag{6.2}$$

$$D_{\alpha}\phi = D_{\varphi}\phi = 0, \tag{6.3}$$

$$D_{\alpha}\sigma = D_{\varphi}\sigma = 0, \tag{6.4}$$

<span id="page-78-3"></span><span id="page-78-2"></span><span id="page-78-1"></span><span id="page-78-0"></span>
$$F_{\mu\nu} = 0, \tag{6.5}$$

$$(D_y + \sigma + m(y))\phi = 0, (6.6)$$

$$D_y \sigma - e^2 \mu_{\mathbb{R}} = 0. ag{6.7}$$

The most important equations here are written in the last two lines. They are our familiar gradient flow equations describing an AC-flow on the Higgs branch, which were extensively discussed earlier. Equations [\(6.4\)](#page-78-0) play just a technical role, ensuring that σ is constant along E<sup>τ</sup> , and equations [\(6.2\)](#page-78-1) contain the complex moment map constraint. Equations [\(6.3\)](#page-78-2) seem to imply that the chirals φ are convariantly constant along E<sup>τ</sup> , while [\(6.5\)](#page-78-3) says that the gauge connection is flat. Both of the latter two are problematic on the noncompact space, as we already explained in the previous section, and lead to the wrong conclusion that transitions between fixed points are impossible. For that reason, we will develop an approach that avoids the noncompactness issues in the next subsection. For now, let us focus on the gradient flow part once more.

To each fixed point p ∈ X<sup>A</sup><sup>C</sup> of the A<sup>C</sup> action on the Higgs branch X, one associates an attracting submanifold

$$Attr(p) \subset X,$$
 (6.8)

swept by the simple gradient trajectories that end at p. One also introduces the full attractor

$$\overline{\text{Attr}}(p) \subset X, \tag{6.9}$$

swept by all the gradient flows, including the concatenated, or "broken", trajectories. The latter means that for a point x ∈ Attr(p), there is a sequence of fixed points (p1, . . . , pn), with each p<sup>i</sup> ∈ X<sup>A</sup><sup>C</sup> , such that there exists a concatenated flow

$$x \to p_1 \to p_2 \dots \to p_n \to p, \tag{6.10}$$

where "a → b" means that the points a and b are connected by the gradient flow. By analogy, we can consider trajectories that start at p and define the repelling and the full repelling submanifolds:

$$\operatorname{Rep}(p) \subset X, \qquad \overline{\operatorname{Rep}}(p) \subset X.$$
 (6.11)

The attracting and repelling submanifolds depend on the choice of chamber C in the space of real masses, which determines the pattern of gradient flows. It is clear that Attr(p) (or Attr(p)) for C is the same as Rep(p) (or Rep(p), respectively) for the chamber −C.

Attr(p) and Attr(p) play important role in the construction of stable envelopes [\[51\]](#page-141-1), and they also show up in the description of Janus interfaces due to the presence of gradient flow equations. If we fix a massive vacuum hp| (the "out" state) corresponding to p ∈ X<sup>A</sup><sup>C</sup> in the far future y = +∞, where the real masses m are present, then the corresponding state in the far past at y = −∞, where masses are zero, is by definition captured in the Q-cohomology by:

$$\langle p|\mathcal{J}_m(m,0).$$
 (6.12)

This state is supported, in the appropriate sense, on the full attractor Attr(p). Likewise, if the real masses are turned on in the past and are zero in the future, and we fix a state |pi in the past, then at y = +∞ we find the state

$$\mathcal{J}_m(0,m)|p\rangle,\tag{6.13}$$

which is supported, in the appropriate sense, on the full repellent Rep(p).

The sense in which these states have a certain support has already been worked out in the previous section. There we saw (in the case of quantum mechanics) that a vacuum wave function was Ψ = e <sup>−</sup><sup>f</sup>Ω, with the equivariant differential form Ω given by the path integral that admits localization to the gradient trajectories. In the limit of infinite masses (that enter the Morse function f), this Ω becomes, up to a normalization factor, a delta-form supported on the union of gradient trajectories. Hence we claim that in the m → ∞ limit, hp|Jm(m, 0) with e −f stripped off becomes a distribution supported on Attr(p) (representing class in the appropriate cohomology theory). Likewise, Jm(0, m)|pi, with the pre-factor e −f removed, becomes a distribution supported on Rep(p).

We see from the above discussion that the matrix of Jm(0, m) is upper-triangular, with the matrix elements

<span id="page-80-1"></span><span id="page-80-0"></span>
$$\langle p_2 | \mathcal{J}_m(0,m) | p_1 \rangle \tag{6.14}$$

being non-zero when p<sup>2</sup> ∈ Rep(p1). The off-diagonal elements in this matrix are attributed to the flows that connect different fixed points, and the matrix elements that are at a distance more than 1 from the diagonal are due to the "broken trajectories". We will see that the same exact structure emerges from the effective description of the next subsection.

Figures [5](#page-80-0) and [6](#page-81-0) below illustrate our setups. In general, we pick an arbitrary Higgs phase vacuum state |ψi in the massless region and a fixed point p at infinity of the massive region. The path integral then computes overlaps, either hp|Jm(m, 0)|ψi or hψ|Jm(0, m)|pi.

![](_page_80_Picture_5.jpeg)

Figure 5: The setup defining hp|Jm(m, 0). Here hp| is a massive vacuum taken as an "out" state in the far future y → +∞. In the region with zero masses, we start with an arbitrary Higgs phase vacuum wave function ψ. The overlap is computed by counting flows that start somewhere in the support of ψ and end at the fixed point p.

In the equation [\(6.14\)](#page-80-1), we also used the fixed point basis hp| on the left (that is, in the massless region). This is understood in the sense of equivariant localization: even though general vacuum wave functions in the massless region are not localized at the fixed points p, they can still be decomposed in a "fixed point basis". The latter consists of special smooth wave functions that are appropriately centered at the fixed points. They can be made more sharply localized there if we start increasing the equivariant parameters (flavor holonomies on E<sup>τ</sup> ). They also admit certain delta-function-like representatives in the Q-cohomology

![](_page_81_Picture_0.jpeg)

Figure 6: The setup defining Jm(0, m)|pi. Here |pi is a massive vacuum taken as an "in" state in the far past y → −∞. In the massless region, it is capped off with an arbitrary Higgs phase vacuum wave function ψ. The overlap is computed by counting flows that start at the fixed point p and end somewhere in the support of ψ.

(the analogs of de Rham currents in differential geometry), as we will discuss later.

The above clearly suggests an interpretation of Jm(0, m) as the map:

<span id="page-81-0"></span>
$$\mathcal{J}_m(0,m): \{ \text{Vacua at } m \neq 0 \} \to \{ \text{Vacua at } m = 0 \}.$$
(6.15)

According to Section [3,](#page-27-0) the space of vacua is identified with the appropriate equivariant cohomology theory of the vacuum manifold. The latter refers to the whole Higgs branch if m = 0, or the fixed locus X<sup>A</sup> if masses m 6= 0 are generic. In 1d, we study our theory on R, and Jm(0, m) gives a map in the T-equivariant cohomology:

$$H_{\mathbf{T}}^{\bullet}(X^{\mathbf{A}}) \to H_{\mathbf{T}}^{\bullet}(X)$$
 (1D case.) (6.16)

In two dimensions, we study the theory on R × S 1 , and Jm(0, m) realizes a map in the equivariant complex K-theory:

$$K_{\mathbf{T}}(X^{\mathbf{A}}) \to K_{\mathbf{T}}(X)$$
 (2D case.) (6.17)

In our main three-dimensional setting on R × E<sup>τ</sup> , the operator Jm(0, m) realizes

$$\Gamma(\mathcal{E}_{\mathbf{T}}(X^{\mathbf{A}}), \mathcal{L}) \to \Gamma(\mathcal{E}_{\mathbf{T}}(X), \mathcal{L}), \quad (3D \text{ case,})$$
 (6.18)

which is a map between the spaces of sections of sheaves on ET(·) = EllT(·) × EA<sup>0</sup>. Here

EllT(·) is the scheme representing equivariant elliptic cohomology, and EA<sup>0</sup> is the Abelian variety of K¨ahler parameters. The line bundle L describing the topology of vacua in the elliptic case was introduced in Section [3.4.](#page-39-0)

#### <span id="page-82-0"></span>6.2 Effective description

We will now explain how to compute matrix elements like [\(6.14\)](#page-80-1) using an effective gaugetheoretic description. The main idea is that as we send masses m in the settings of Figures [5](#page-80-0) and [6](#page-81-0) to infinity (in the chamber C), certain C-dependent boundary conditions emerge at the interface where masses change. On the massless side, we have our full gauge theory, let us call it T . On the massive side, we obtain the theory T C , which we now describe.

As real masses m increase, the theory T decomposes into light and heavy degrees of freedom. The light ones are either massless or have masses of order e √ ζ generated on the Higgs branch (here ζ represents FI parameters), and they describe low-energy excitations around each massive vacuum. The heavy degrees of freedom have masses of order m, they describe high-energy processes such as tunneling between vacua, and they effectively go away (are integrated out) as m → ∞. In this limit, we are left exactly with T C , which by definition describes light degrees of freedom. It clearly decomposes into sectors labeled by the massive vacua, which do not talk to each other:

$$\mathcal{T}^{\mathfrak{C}} = \bigoplus_{p \in \{\substack{\text{massive} \\ \text{vacua}}\}} \mathcal{T}_p^{\mathfrak{C}}.$$
(6.19)

One can think of T C p as an effective QFT describing the tower of light excitations above the vacuum p. This notation is better suited to the situation when p are isolated vacua, and it is the case in all our examples, but it does not have to be so: in general p labels components of the fixed locus on the Higgs branch that remain unlifted in the presence of masses m.

To be specific, suppose we work in the setting of Figure [5.](#page-80-0) In the massless region, we start with a state |ψi as the input data. After the masses m are turned on at y = 0, the state ψ gets quickly projected to the light sectors, and then slowly gets further projected to the vacuum subspace, both projections happening due to the Euclidean evolution:

<span id="page-82-1"></span>
$$|\psi\rangle \longmapsto \sum_{p \in \{\substack{\text{massive} \\ \text{vacua}}\}} |\psi_p\rangle \longmapsto \sum_{p \in \{\substack{\text{massive} \\ \text{vacua}}\}} c_p |p\rangle, \text{ where } |\psi_p\rangle \in \mathcal{H}[\mathcal{T}_p^{\mathfrak{C}}].$$
 (6.20)

The relaxation time of the first process is of order 1/m, which becomes effectively instantaneous in the infinite mass limit. The relaxation time of the second process is determined by masses of the light modes, and can be quite long.

We want to pick out the term corresponding to the vacuum  $|p\rangle$  in the above sum. This is done by fixing the vacuum at  $y \to +\infty$  or, equivalently, by imposing the appropriate boundary conditions at a finite distance  $y = y_+$ . Assuming this has been done, in most of the massive region (except a vanishingly thin layer at y = 0) the system is described by the theory  $\mathcal{T}_p^{\mathfrak{C}}$ . Hence we effectively obtain the interface between  $\mathcal{T}$  and  $\mathcal{T}_p^{\mathfrak{C}}$ :

$$\mathcal{T}_p^{\mathfrak{C}} \mid \mathcal{T}.$$
 (6.21)

We claim that this interface admits a simple description in gauge theory. By further computing interval partition functions with such interfaces inserted, we are able to extract the coefficients of  $|p\rangle$  in (6.20) and henceforth produce matrix elements of the Janus interface.

Before proceeding, let us also note that we will be often switching between the viewpoints of Figure 5 and Figure 6. They are conceptually and computationally similar, and we construct the  $\mathcal{T}_p^{\mathfrak{C}} | \mathcal{T}$  interface in both cases. They are both related to stable envelopes, the only difference being that in the Figure 6 one works with the repelling subspaces of fixed points, rather than attractors in the setting of Figure 5.

### <span id="page-83-0"></span>6.2.1 Theory $\mathcal{T}_{n}^{\mathfrak{C}}$

First, let us determine the effective theory labeled by the vacuum p. In this vacuum, the real scalars  $\sigma$  from the vector multipelt "adjust" themselves to the special values  $\sigma^{(p)}$ , which partly screen real masses, such that the hypermultiplets developing vevs have zero effective real masses. Note that we study theories on  $\mathbb{R}_y \times \mathbb{E}_\tau$ , which are macroscopically one-dimensional. Therefore the statements about fields developing vevs should be understood in terms of the wave function being centered around the corresponding value. For example, when we say that the fields  $\sigma$  take special values  $\sigma^{(p)}$ , we really mean that the vacuum wave function on the field space of the theory, considered as a functional of  $\sigma$ , is centered around  $\sigma^{(p)}$ . The corresponding probability distribution around  $\sigma^{(p)}$  has some finite width, even in the  $m \to \infty$  limit: The field  $\sigma$  can still fluctuate around  $\sigma^{(p)}$ . However, in the  $m \to \infty$  limit, different values corresponding to different massive vacua, say  $\sigma^{(p_1)}$  and  $\sigma^{(p_2)}$ , become infinitely separated. As a result, the overlap between vacua, and in fact between the whole light sectors  $\mathcal{T}_{p_1}^{\mathfrak{C}}$  and  $\mathcal{T}_{p_2}^{\mathfrak{C}}$ , clearly vanishes. This is the sense in which we single out the theory  $\mathcal{T}_p^{\mathfrak{C}}$ .

If the theory T has a non-abelian gauge group G, the vev σ = σ (p) Higgses it to a certain subgroup

$$G_p \subset G$$
 (6.22)

by giving large masses to the roots that do not commute with σ (p) (it is reasonable to refer to them as W-bosons). Assuming that σ (p) is a generic element of a torus S ⊂ H, which does not necessarily coincide with the maximal torus H, we may say that

$$G_p = C_G(\mathbb{S}) \tag{6.23}$$

is a centralizer of S. While G<sup>p</sup> contains the maximal torus, H ⊂ G<sup>p</sup> ⊂ G, it does not necessarily coincide with it if S is strictly smaller than H. This G<sup>p</sup> is identified as the gauge group of T C p . Note that in the abelian case, we simply have G<sup>p</sup> = G = H.

As is usual in the Higgs mechanism, the group G is not truly broken: The wave functional is still G-invariant, i.e., constant along the G-orbit of σ (p) . Expanding around the chosen value of σ (p) and "breaking" G is just a repackaging of degrees of freedom, with G<sup>p</sup> being the new gauge group. As a remnant of the full G gauge symmetry, the wave functional is not an arbitrary function of σ (p) . It is invariant under the action of the Weyl group relative to S:

$$W(G, \mathbb{S}) := N_G(\mathbb{S})/C_G(\mathbb{S}), \tag{6.24}$$

where NG(S) is the normalizer of S in G, and CG(S) is the centralizer of S. In many interesting examples, S coincides with the maximal torus H, in which case G<sup>p</sup> = H, and W(G, H) is the ordinary Weyl group. Working with the gauge group H instead of G and the same matter content is referred to as the abelianization [\[52,](#page-141-2) [170\]](#page-150-9). Note that our theory T C p is not the abelianization, since we truncate both the gauge group (not always to the maximal torus) and the matter content, as will be explained shortly. Also, it will be enough to work with a given σ (p) , leaving Weyl-averaging to the very end of most computations.

Now let us determine the matter content of T C p . Recall that the hypers of T are valued in R ⊕ R, where R is a complex representation of gauge and flavor groups. As discussed in Section [3.4,](#page-39-0) R splits into vector subspaces (and, in fact, Gp-subrepresentations) according to the value of the effective real mass:

$$\mathcal{R} \cong \mathcal{R}_0(p) \oplus \mathcal{R}_+(p) \oplus \mathcal{R}_-(p),$$
 (6.25)

where R0(p) contains components (viewed as Gp-weights) with vanishing effective real masses,

which can develop vevs in the vacuum p. They may still obtain small masses on the Higgs branch, but such masses are not controlled by the large parameters m. In other words, the hypermultipelts in R0(p) are light degrees of freedom, and hence part of the theory T C p . The rest of the hypers, valued in R+(p) and R−(p), have very large positive and negative effective real masses, respectively, and ought to be integrated out.

We have to take care of the Chern-Simons (CS) terms generated in the process.[15](#page-85-0) Integrating out a 3d N = 2 chiral of real mass m produces a CS term at the level <sup>1</sup> 2 Sign(m) for the corresponding symmetry (this is really the contribution of the Dirac fermion that is part of the multiplet). Since a hyper consists of two chirals of opposite flavor/gauge charges (and hence opposite masses), their respective CS terms cancel, at least when the full N = 4 SUSY is preserved. In our case, we break N = 4 down to N = 2 by the U(1)<sup>~</sup> holonomy, which leaves a possibility to generate a mixed CS term between the U(1)<sup>~</sup> and flavor/gauge symmetries. Such a CS term plays role in the anomaly inflow, so let us write it as a fourform term in the anomaly polynomial. Consider a hyper (I, J), with the gauge field strength coupled to I written as f, the flavor field strength – as fx, and the U(1)<sup>~</sup> field strength – as 2 f~. Assuming the real mass of I is positive, the contribution of (I, J) is

$$\frac{1}{2}(\mathbf{f} + \mathbf{f}_x + \frac{1}{2}\mathbf{f}_{\hbar} - \frac{1}{2}\mathbf{r})^2 - \frac{1}{2}(-\mathbf{f} - \mathbf{f}_x + \frac{1}{2}\mathbf{f}_{\hbar} - \frac{1}{2}\mathbf{r})^2 = (\mathbf{f} + \mathbf{f}_x)(\mathbf{f}_{\hbar} - \mathbf{r}), \tag{6.26}$$

where we also included the contribution of the R-symmetry field strength r, for better comparison with the boundary anomalies, even though we do not turn on any U(1)<sup>R</sup> background. More generally, the extremely massive hypers in R+(p) ⊕ R−(p) contribute

<span id="page-85-1"></span>
$$\left(\mathbf{f}_{\hbar} - \mathbf{r}\right) \left[ \operatorname{Tr}_{\mathcal{R}_{+}(p)} (\mathbf{f} + \mathbf{f}_{x}) - \operatorname{Tr}_{\mathcal{R}_{-}(p)} (\mathbf{f} + \mathbf{f}_{x}) \right]. \tag{6.27}$$

The corresponding CS term can be written as

$$\frac{1}{4\pi} \int (A_{\hbar} - A_R) \wedge \left[ \operatorname{Tr}_{\mathcal{R}_+(p)}(F + F_x) - \operatorname{Tr}_{\mathcal{R}_-(p)}(F + F_x) \right] + \dots, \tag{6.28}$$

where the ellipsis represents the N = 2 completion.

Now that we have determined the fate of hypermultiplets, — those in R0(p) give the matter content of T C p , and those in R+(p) ⊕ R−(p) generate the effective CS terms, — it remains to understand what happens to the massive components of vector multiplets, that is W-bosons. In abelian theory there are no W-bosons, so we are done.

<span id="page-85-0"></span><sup>15</sup>Other possibly generated terms vanish in the m → ∞ limit.

In a non-abelian theory, integrating out the massive W-bosons and their superpartners valued in g\g<sup>p</sup> (here g<sup>p</sup> = Lie(Gp)) also contributes to the effective CS term. More precisely, 3d N = 2 vector multipelts do not contribute: Their massive components come in pairs of roots α and −α, which receive opposite masses hα, σ(p) i and −hα, σ(p) i. Integrating out the corresponding gaugini results in opposite effective CS terms that cancel each other. The adjoint chiral Φ, however, avoids this cancellation, which is again due to the nonzero U(1)<sup>~</sup> charge of Φ. Let ∆+(p) denote the "positive roots" α, such that the corresponding components hα, Φi have positive real masses in the vacuum p. Note that ∆+(p) ∪ (−∆+(p)) is the set of all massive roots, which are in bijection with a basis of g \ gp. Then we can write down the contribution of Φ as

$$\sum_{\alpha \in \Delta_{+}(p)} \frac{1}{2} \left[ (\langle \alpha, \mathbf{f} \rangle + \mathbf{f}_{\hbar})^{2} - (-\langle \alpha, \mathbf{f} \rangle + \mathbf{f}_{\hbar})^{2} \right] = 2\mathbf{f}_{\hbar} \sum_{\alpha \in \Delta_{+}(p)} \langle \alpha, \mathbf{f} \rangle.$$
 (6.29)

The corresponding effective N = 2 CS term is then

<span id="page-86-2"></span>
$$\frac{1}{2\pi} \int A_{\hbar} \wedge \sum_{\alpha \in \Delta_{+}(p)} \langle \alpha, F \rangle + \dots \tag{6.30}$$

#### <span id="page-86-0"></span>6.2.2 Interface between T and T C p

As real masses are sent to infinity, a certain natural interface emerges between T and T C p . Since the field content of T C p is identified with the light fields in T (up to a Weyl permutation), the interface must be transparent for such fields. Their masses do not change across the interface, except in a thin layer of size 1/m where the relaxation takes place (and σ does not properly screen m just yet). This layer has vanishingly small size and simply cannot be probed by the low-energy modes. Hence the statement that the light fields do not see the interface.

To be more precise, the low-energy excitations of the light fields do not sense the interface. Indeed, some of the light fields develop a vev across the interface, like the gp-valued part of σ, which is 0 for y < 0 and σ (p) for y > 0 (more precisely, for y & m<sup>−</sup><sup>1</sup> ). In this case, a more accurate statement is that the low-energy excitations of σ above the σ (p)Θ(y) background[16](#page-86-1) cannot resolve distances as short as m<sup>−</sup><sup>1</sup> , hence they see the interface as transparent. Every time we say "low-energy" here, we mean compared to m, so this restriction goes away in the m → ∞ limit.

<span id="page-86-1"></span><sup>16</sup>Here Θ(y) is the Heaviside theta function, such that Θ(y > 0) = 1 and Θ(y < 0) = 0.

The comment about Weyl permutations briefly made above means the following. A state of T C p , as a function of σ ∈ t, has to be averaged over W(G, S) to give a state from the lowenergy sector of T with large masses. Hence the definition of the interface secretly involves the Weyl-averaging (which would take place anyways on the T side due to the non-abelian gauge symmetry). For example if G = U(N) and G<sup>p</sup> = U(1)<sup>N</sup> , then a sate of T C p , as a function of σ ∈ t = R <sup>N</sup> , has no symmetry properties, while on the T side it has to be permutation-symmetric. Thus the fields of T C p are identified with the light fields of T only up to Weyl permutations. This is one of the ways to see why in the computations of matrix elements of interfaces we will have to perform Weyl-symmetrization.

Heavy fields, on the other hand, are not part of the T C p theory. Therefore, they ought to terminate at the interface, subject to certain boundary conditions. Such boundary conditions are naturally induced by the mass jumping from 0 to a very large value in the supersymmetric way. Also note that boundary conditions are part of the UV data of the theory, and all our theories are UV-free. Therefore, it is enough to analyze the problem in the free case.

Scalar boson with jumping mass. We start by analyzing a free complex scalar (in a chiral multiplet) with spatially modulated mass that is part of the half-BPS Janus profile. Suppose the mass is zero for y < 0 and m for y > 0, and do not forget about the −φm<sup>0</sup> (y)φ term required by the SUSY.

There are several ways to proceed with the analysis. Let us start in the Euclidean signature, thinking of the system as defined by the path integral

$$\int \mathcal{D}\phi \ e^{-\int d^3x \,\overline{\phi} \left[-\partial^{\mu}\partial_{\mu} + m^2\Theta(y) - m\delta(y)\right]\phi}, \tag{6.31}$$

where Θ(y) is the Heaviside theta (step) function, and the delta function comes from the φm<sup>0</sup> (y)φ term. Definition of such a path integral involves expanding in the eigenfunctions of the kinetic operator, such that the fields behave reasonably at infinity (do not blow up). Thus we look at

$$\left[ -\partial^{\mu}\partial_{\mu} + m^{2}\Theta(y) - m\delta(y) \right] \phi = E\phi, \tag{6.32}$$

where E is real since the operator is Hermitian. At this point we may use the unbroken translation invariance in the plane parallel to the interface, and Fourier transform in those directions. This replaces ∂ <sup>µ</sup>∂<sup>µ</sup> by ∂ 2 <sup>y</sup> −p 2 , where p is the momentum parallel to the interface:

$$\left[-\partial_y^2 + p^2 + m^2\Theta(y) - m\delta(y)\right]\phi = E\phi. \tag{6.33}$$

Equivalently, we get equations in the two regions:

<span id="page-88-0"></span>
$$\begin{cases} (p^2 - \partial_y^2)\phi^{<} = E\phi^{<}, & y < 0\\ (p^2 + m^2 - \partial_y^2)\phi^{>} = E\phi^{>}, & y > 0 \end{cases}$$
 (6.34)

subject to the sewing conditions:

<span id="page-88-1"></span>
$$\phi^{<}|_{y=0} = \phi^{>}|_{y=0}, \qquad \partial_{y}\phi^{<}|_{y=0} - \partial_{y}\phi^{>}|_{y=0} = m\phi|_{y=0}.$$
 (6.35)

It is easy to see that [\(6.34\)](#page-88-0), [\(6.35\)](#page-88-1) have no solutions for E < p<sup>2</sup> , while for E ≥ p 2 solutions exist and fall in two classes:

1. For p <sup>2</sup> ≤ E < p<sup>2</sup> + m<sup>2</sup> , the solution is

$$\phi^{<} = Ae^{iy\sqrt{E-p^2}} + Be^{-iy\sqrt{E-p^2}}, \qquad \phi^{>} = Ce^{-y\sqrt{p^2+m^2-E}},$$
 (6.36)

where C = A + B, and

<span id="page-88-3"></span><span id="page-88-2"></span>
$$B = A \frac{i\sqrt{E - p^2} + \sqrt{p^2 + m^2 - E} - m}{i\sqrt{E - p^2} - \sqrt{p^2 + m^2 - E} + m}.$$
(6.37)

In the y > 0 region we picked the solution that does not blow up as y → +∞. Note that the coefficients A, B, C are of course functions of p and E, which was suppressed in the notations to reduce clutter.

2. For E ≥ p <sup>2</sup> + m<sup>2</sup> , the solution is

$$\phi^{<} = Ae^{iy\sqrt{E-p^2}} + Be^{-iy\sqrt{E-p^2}}, \qquad \phi^{>} = Ce^{iy\sqrt{E-p^2-m^2}} + De^{-iy\sqrt{E-p^2-m^2}}, \quad (6.38)$$

where 
$$A + B = C + D$$
 and  $i\sqrt{E - p^2}(A - B) - i\sqrt{E - p^2 - m^2}(C - D) = m(A + B)$ .

As we tend m<sup>2</sup> → ∞, all solutions fall into the class 1, while those in the class 2 go away to infinity. Focusing on the class 1, it immediately follows from [\(6.37\)](#page-88-2) that we get B = ±A in this limit, depending on the sign of m:

$$m \to +\infty \Rightarrow B = A,$$
  
 $m \to -\infty \Rightarrow B = -A.$  (6.39)

Solution φ <sup>&</sup>lt; with B = A obeys Neumann boundary condition at y = 0, while B = −A implies that φ <sup>&</sup>lt; obeys Dirichlet boundary condition at y = 0. Solution for φ <sup>&</sup>gt; from [\(6.36\)](#page-88-3) decays fast: It has a relaxation time of order 1/|m|, which tends to zero in the m<sup>2</sup> → ∞ limit. Thus we confirm that the field φ lives in the y < 0 half-space in the m → ∞ limit, with the boundary conditions at y = 0 determined by the mass sign:

<span id="page-89-0"></span>
$$\boxed{m \to +\infty \Rightarrow \partial_y \phi^{<}|_{y=0} = 0,} \qquad \boxed{m \to -\infty \Rightarrow \phi^{<}|_{y=0} = 0.}$$
(6.40)

We could reach the same conclusion in several other ways. For example, we could work in the Mikowski signature instead, thinking about the field φ in the on-shell operator formalism, i.e., subject to the equation of motion [−∂ <sup>µ</sup>∂<sup>µ</sup> + m<sup>2</sup>Θ(y) − mδ(y)] φ = 0. Then we solve the scattering problem, with an incoming and reflected plane waves in the region y < 0, and some solution in the region y > 0. These solutions are subjected to the same sewing conditions [\(6.35\)](#page-88-1), and the answer we get from such an analysis is the same as in [\(6.40\)](#page-89-0). Another way to derive [\(6.40\)](#page-89-0) is by using supersymmetry. The BPS equation in the y > 0 region reads ∂yφ = −mφ. For m > 0 this gives a decaying solution, which thus admits an arbitrary initial value at y = 0, consistent with the Neumann boundary conditions. For m < 0, the BPS equation gives a solution that blows up, which can only be avoided by the Dirichlet boundary condition at y = 0, again consistent with [\(6.40\)](#page-89-0).

Finally, let us comment that if we consider the mirror-reflected configuration, with m 6= 0 for y < 0 and m = 0 for y > 0, then the relation between the sign of mass and the boundary conditions gets flipped:

$$m \to -\infty \Rightarrow \partial_y \phi^> |_{y=0} = 0,$$
  $m \to +\infty \Rightarrow \phi^> |_{y=0} = 0.$  (6.41)

Fermion with jumping mass. Supersymmetry preserved by the Janus interface allows to determine the fermionic boundary conditions for free. We could, however, run the same analysis and see how the boundary conditions for the fermions emerge in the m → ∞ limit. Such an analysis is even simpler than in the bosonic case due to the absence of the delta-function term in the equations of motion, which are simply the Dirac equation with y-dependent mass. In the massive region, one gets solutions that either decay or blow up:

$$\psi_{+} \sim e^{-my}, \quad \psi_{-} \sim e^{+my},$$
 (6.42)

and we have to kill the solution that blows up at infinity. Depending on the sign of m, that would be either ψ<sup>+</sup> or ψ−, providing exactly the SUSY completion of the boundary conditions obeyed by the bosons.

In principle, the most economic way to derive boundary conditions would be to start with the fermionic equations of motion as above, and then argue that bosonic boundary conditions follow by the SUSY. We chose a different path and started with the bosons here, as it is somewhat interesting and pedagogical to see explicitly how the Dirichlet/Neumann boundary conditions for the bosons emerge.

W-bosons. In the case of non-abelian gauge group, as mentioned earlies, non-zero vevs σ (p) give masses to the W-bosons. Thus components of the vector multipelt corresponding to the root α have their masses jump from 0 to hα, σ(p) i at y = 0. This, likewise, generates certain boundary conditions for such components. We could study them by analyzing the Proca equation, similar to our analysis of the Klein-Gordon equation above. To save some time, though, we take a shortcut based on supersymmetry now. A 3d N = 4 vector multiplet consists of the 3d N = 2 vector V and the adjoint chiral Φ. As reviewed in Section [2.1,](#page-9-1) the 2d N = (2, 2) SUSY preserved at the boundary relates the boundary conditions on Φ to those on V . Namely, 2d N = (0, 2) Dirichlet boundary conditions on Φ imply (0, 2) Dirichlet on V , and Neumann on Φ imply Neumann on V .

Since we already understand the case of chiral multiplets, we know that the components of Φ receive Dirichlet/Neumann boundary conditions depending on the sign of mass. This then implies boundary conditions on the whole N = 4 vector multiplet as summarized below. Denoting the mass of root α by m<sup>α</sup> = hα, σi, we have:

<span id="page-90-0"></span>
$$m_{\alpha}(y < 0) = 0, \quad m_{\alpha}(y > 0) \to +\infty \implies \text{Neumann},$$
 $m_{\alpha}(y < 0) = 0, \quad m_{\alpha}(y > 0) \to -\infty \implies \text{Dirichlet},$ 
 $m_{\alpha}(y < 0) \to +\infty, \quad m_{\alpha}(y > 0) = 0 \implies \text{Dirichlet},$ 
 $m_{\alpha}(y < 0) \to -\infty, \quad m_{\alpha}(y > 0) = 0 \implies \text{Neumann},$ 
 $(6.43)$ 

where Neumann/Dirichlet refers to the N = (2, 2) boundary conditions on the N = 4 vector multiplet.

Anomalies. By construction, our interface between T and T C p is not expected to carry any 2d anomalies, since it is defined simply as a limit of a certain mass profile in 3d. The effective boundary conditions described earlier, however, look like they could support boundary anomalies. Here we note that such anomalies indeed cancel, via the inflow, against the effective CS terms discussed earlier. Assuming we have the theory T for y < 0 and T C p for y > 0, the hypers in (R+(p), R+(p)) and (R−(p), R−(p)) receive (Neumann, Dirichlet) and (Dirichlet, Neumann) boundary conditions, respectively.[17](#page-91-0) Boundary anomaly of each hyper with the (D,N) boundary conditions reads <sup>1</sup> 2 (f + f<sup>x</sup> + 1 2 f<sup>~</sup> − 1 2 r) <sup>2</sup> − 1 2 (−f − f<sup>x</sup> + 1 2 f<sup>~</sup> − 1 2 r) <sup>2</sup> = (f<sup>~</sup> −r)(f +fx), and the opposite for the (N,D) case. In total, we have the boundary anomaly of hypers,

$$(\mathbf{f}_{\hbar} - \mathbf{r}) \operatorname{Tr}_{\mathcal{R}_{-}(p)} (\mathbf{f} + \mathbf{f}_{x}) - (\mathbf{f}_{\hbar} - \mathbf{r}) \operatorname{Tr}_{\mathcal{R}_{+}(p)} (\mathbf{f} + \mathbf{f}_{x}), \tag{6.44}$$

which is clearly canceled by the inflow term [\(6.27\)](#page-85-1).

The 3d N = 4 vector multiplet contribution to the boundary anomaly, for our boundary conditions, is completely due to the adjoint chiral Φ, and given by:

$$\sum_{\alpha \in \Delta_{+}(p)} \left[ \frac{1}{2} (-\langle \alpha, \mathbf{f} \rangle + \mathbf{f}_{\hbar})^{2} - \frac{1}{2} (\langle \alpha, \mathbf{f} \rangle + \mathbf{f}_{\hbar})^{2} \right] = -2\mathbf{f}_{\hbar} \sum_{\alpha \in \Delta_{+}(p)} \langle \alpha, \mathbf{f} \rangle, \tag{6.45}$$

which also clearly cancels against the inflow term [\(6.29\)](#page-86-2). Thus we see that the effective CS terms present on the massive side cancel the boundary anomalies, in a sense transporting them to the opposite end of the massive region, which might be important when we have another boundary at y = y+.

Mini summary. Let us briefly summarize our description of the interface between T and T C p . Recall that T is a gauge theory with the gauge group G and hypermultiplets (I, J), where the chiral multiplet I is valued in a unitary G×GH-representation R, and J – in its conjugate R. The gauge group of T C p is G<sup>p</sup> = CG(S), the subgroup of G that commutes with σ = σ (p) in the massive vacuum p. The matter content of T C p is given by the hypermultiplets valued in the Gp-submodule R0(p) ⊂ R determined as follows. Under the embedding G<sup>p</sup> ⊂ G, the representation R breaks into Gp-submodules, R = R0(p) ⊕ R+(p) ⊕ R−(p), where R0(p) is singled out as the subspace of hypers that remain light in the vacuum p as m → ∞ in the chanber C.

Hypers valued in R±(p) receive large positive/negative real masses in the vacuum p, respectively (here we refer to the signs of masses of the R±(p)-valued components of the chiral I). These hypers are not present in the T C p theory, thus they terminate at the interface via the boundary conditions, which in the case when T C p occupies the y > 0 half-space are constructed as follows: R+(p)-valued and R−(p)-valued chirals are given (0, 2) Neu-

<span id="page-91-0"></span><sup>17</sup>In the following, we will often abbreviate such boundary conditions as (N,D) or (D,N).

mann boundary conditions; R+(p)-valued and R−(p)-valued chirals are given (0, 2) Dirichlet boundary conditions. Together these define (2, 2) boundary conditions for the R±(p)-valued hypermultiplets. The R0(p)-valued part of the hypermultiplets in T are simply identified (up to Weyl permutations) with the hypermultipelts of the theory T C p along the interface. That is, for the R0(p)-valued hypers the interface is transparent.

As for the gauge multiplets, the gp-valued vector multiplets of T C p are identified at the interface with the gp-valued part of the vectors in T (up to the same Weyl permutations). The remaining g \ gp-valued components of the vector multiplets in T are given (2, 2) boundary conditions, Dirichlet or Neumann, depending on whether the massive W-boson multiplets receive negative or positive masses respectively. We denote the set of roots that have positive masses in the vacuum p by ∆+(p).

If the theory T C p lives in the y < 0 half-space instead, then all the Dirichlet and Neumann boundary conditions must be swapped. Finally, the theory T C p also contains some mixed Chern-Simons terms generated by the very massive multiplets that have been integrated out, as explained around [\(6.27\)](#page-85-1) and [\(6.29\)](#page-86-2).

#### <span id="page-92-0"></span>6.3 Boundary conditions for vacua

Now that we have a detailed description of the interface between T and T C p that emerges in the m → ∞ limit of the Janus J , we would like to compute its vacuum matrix elements. The interface is wrapped on E<sup>τ</sup> × {0} in the E<sup>τ</sup> × R<sup>y</sup> Euclidean geometry, with the vacua α and β fixed at y = −∞ and y = +∞, respectively. Recall that we also turn on flat connections for the flavor, U(1)<sup>~</sup> and topological symmetries along E<sup>τ</sup> , denoted as x, ~, and z, respectively. With R<sup>y</sup> treated as the Euclidean time, this setup computes the equivariant overlap hβ|J |αi that we are after. Treating one of the cycles in E<sup>τ</sup> as the Euclidean time instead, the same quantity can be interpreted as a BPS index in the αβ soliton sector, with the flat connections playing the role of fugacities.

Of course one would like to compute such indices exactly using the supersymmetric localization. Non-compactness of Ry, however, leads to some technical issues that were mentioned earlier. It is convenient, therefore, to replace R<sup>y</sup> by an interval (y−, y+), with y<sup>+</sup> > 0 and y<sup>−</sup> < 0, such that the boundary conditions at its endpoints are Q-cohomologous to the vacua α and β, thus mimicking them for the purposes of BPS computations. We already discussed some aspects of such boundary conditions in Section [3.4.](#page-39-0) The interface is still located at 0 ∈ (y−, y+).

As in the Section [3.4,](#page-39-0) such boundary conditions are more straightforward to construct if in the presence of generic masses, T only has isolated massive vacua corresponding to the isolated A-fixed points on the Higgs branch. Let us start with the boundary conditions in the theory T C p that governs light excitations above an isolated vacuum p. By definition, T C p has only one SUSY vacuum, namely p itself. Recall from Section [3.4](#page-39-0) that it can be identified with a Q-cohomology class in H[E<sup>τ</sup> ]. Since there is only one vacuum, any normalizable state of T C p that is Q-closed and not Q-exact can serve as a proxy for it, at least in the BPS computations. According to the proposal of the Appendix [B,](#page-130-0) an elliptic boundary condition creates a boundary state |Bi, which after finite Euclidean evolution becomes a normalizable state e <sup>−</sup>T H|Bi. If such a boundary condition preserves Q, then the corresponding state will be Q-closed, as we want. Therefore, in principle, any reasonable Q-invariant boundary condition can be used to generate a Q-closed state that mimics the vacuum.

To check that it is not Q-exact, it is enough to compute its inner product with some Q-closed covector hB<sup>0</sup> | and get a non-zero answer (which would also imply that the covector is not Q-exact):

$$\langle \mathcal{B}' | e^{-TH} | \mathcal{B} \rangle \neq 0 \Rightarrow \left[ e^{-TH} | \mathcal{B} \rangle \right] \neq 0 \text{ in the cohomology.}$$
 (6.46)

In practice, however, we will construct certain special classes of boundary conditions that better fit our applications. To construct a vacuum boundary condition in T C p , first observe how the R0(p)-valued hypers get vevs. For every weight w ∈ R0(p), denote the corresponding hypermultiplet as (Iw, Jw). In the vacuum p, either the chiral I<sup>w</sup> or the chiral J<sup>w</sup> develops a vev (or neither), but not the two simultaneously. This can be easily proven[18](#page-93-0) using the following steps: (1) every isolated A-fixed point is also fixed by U(1)~, for otherwise one would find a continuous family of A-fixed points; (2) I<sup>w</sup> and J<sup>w</sup> have opposite gauge and flavor charges but the same U(1)<sup>~</sup> charge, thus if both of them had a nonzero vev in an A-fixed point, acting by U(1)<sup>~</sup> would again generate a continuous family of A-fixed points.

Now define the following two types of boundary conditions on the R0(p)-valued hypers:

1. The boundary conditions Dp. For a hyper (Iw, Jw), the chiral that develops a vev in the vacuum p is given (0, 2) Dirichlet boundary conditions (with the boundary value equal to the vacuum value), while the other one is given (0, 2) Neumann. If neither develops vev, which one is given Dirichlet and which one is Neumann is an arbitrary

<span id="page-93-0"></span><sup>18</sup>One might notice that in the Section [3.4](#page-39-0) we have already used this statement a few times without a proof.

choice.

2. The boundary conditions Np. In each pair (Iw, Jw), the chiral that develops a vev in the vacuum p is given (0, 2) Neumann boundary conditions, while the other one is given (0, 2) Dirichlet with zero boundary vev.

It is also convenient to further split R0(p) (which of course was already anticipated in Section [3.4\)](#page-39-0):

$$\mathcal{R}_0(p) \cong \mathcal{R}_0^D(p) \oplus \mathcal{R}_0^N(p), \tag{6.47}$$

according to the type of boundary conditions that chirals in R0(p) ⊕ R0(p) receive. Namely, we use the following convention. For the D<sup>p</sup> type boundary conditions, chirals in R<sup>D</sup> 0 (p) ⊕ R N 0 (p) receive Dirichlet boundary conditions (because they contain components that develop vevs in the vacuum p), and those in R<sup>N</sup> 0 (p)⊕R D 0 (p) are given Neumann boundary conditions. For the N<sup>p</sup> type, the Dirichlet and Neumann are swapped.

The N = 4 vector multiplets in T C p are also given either (2, 2) Neumann (Np) or (2, 2) Dirichlet (Dp) boundary conditions. In the Dirichlet case, a flat connection s ∈ Hom(E<sup>τ</sup> , H)/W is fixed along the boundary. When all boundary vevs of the hypers vanish, s can be arbitrary. However, if the hypers are given boundary vevs, as in the boundary conditions of type D<sup>p</sup> above, then s should take a specific value,

$$s = s^{(p)}(x,\hbar), \tag{6.48}$$

which screens flavor and U(1)<sup>~</sup> flat connections and allows for non-trivial vevs of the matter fields.[19](#page-94-0) This condition originates from the equations

$$D_{\alpha}\phi = D_{\varphi}\phi = 0, \tag{6.49}$$

obeyed by every chiral multiplet scalar φ in the vacuum. A non-trivial vev for such a φ requires that the gauge flat connection cancels the flavor and U(1)<sup>~</sup> flat connections (when acting on φ), resulting in the condition s = s (p) (x, ~).

One more requirement on the boundary conditions mimicking massive vacua pertains to anomalies. As we explored in detail in Section [3.4,](#page-39-0) boundary 't Hooft anomalies must match the effective CS terms generated in the massive vacuum. Additionally, if the gauge fields obey Neumann boundary conditions, gauge and chiral anomalies should be absent at the

<span id="page-94-0"></span><sup>19</sup>This is the same s (p) (x, ~) that was introduced in Section [3.4.](#page-39-0)

boundary. The absence of gauge anomalies is the usual consistency requirement. The chiral anomalies should vanish because the vacuum does not break (the maximal torus of) flavor, U(1)~, or topological symmetries, hence the boundary conditions should not either.

Define the following two types of boundary conditions in T C p : [20](#page-95-0)

$$\mathcal{D}_p = \left\{ \begin{array}{c} D_p \text{ boundary conditions on the hypers} \\ \mathcal{D}_p \text{ boundayr conditions on the vectors, with } s = s^{(p)} \end{array} \right\}, \tag{6.50}$$

$$\mathcal{N}_p = \begin{cases}
N_p \text{ boundary conditions on the hypers} \\
\mathcal{N}_p \text{ boundary conditions on the vectors} \\
\text{Boundary theory } \Upsilon_p
\end{cases} .$$
(6.51)

As the notation suggests, D<sup>p</sup> is just the thimble boundary condition discussed in Section [3.4.](#page-39-0) We noted there that its 't Hooft anomaly agrees with the effective CS terms, so there is no need to add any degrees of freedom at the boundary. To be more precise, here we define it for T C p , but if we collide it with the interface between T and T C p , we will get precisely the thimble boundary conditions in T .

The N<sup>p</sup> boundary conditions, unlike Dp, support dynamical gauge fields and might require extra boundary degrees of freedom Υp. They are necessary to cancel the chiral anomalies (gauge anomalies are absent due to (2, 2) SUSY), and help adjust the boundary 't Hooft anomaly to the desired value. Instead of (perhaps naively) asking that N<sup>p</sup> had the same 't Hooft anomaly as Dp, we would like the following conditions to hold:

<span id="page-95-1"></span>
$$\langle \mathcal{D}_p | \mathcal{N}_p \rangle = \langle \mathcal{D}_p | e^{-TH} | \mathcal{N}_p \rangle = 1,$$
  
$$\langle \mathcal{N}_p | \mathcal{D}_p \rangle = \langle \mathcal{N}_p | e^{-TH} | \mathcal{D}_p \rangle = 1.$$
 (6.52)

This will ensure that |DpihNp| and |NpihDp| act as projectors on the p-th vacuum (up to a Q-exact piece). In particular, if we have a vacuum state Ψ described by a collection of overlaps hDp|Ψi, then we can write J |Ψi = P <sup>p</sup> J |NpihDp|Ψi in the Q-cohomology, showing that it is enough to know how J acts on |Npi.

Equations [\(6.52\)](#page-95-1) imply that the left D<sup>p</sup> and the right N<sup>p</sup> boundary conditions (or the left N<sup>p</sup> and the right Dp) have opposite 't Hooft anomalies. Notice that if we omitted Υ<sup>p</sup> from the definition of |Npi, the relations [\(6.52\)](#page-95-1) would still hold,[21](#page-95-2) however, such N<sup>p</sup> carries

<span id="page-95-2"></span><span id="page-95-0"></span><sup>20</sup>Such N<sup>p</sup> can be problematic in non-abelian gauge theories, as we will explain later.

<sup>21</sup>Overlaps are computed by the interval partition functions. The non-zero modes cancel out in such computations [\[167\]](#page-150-6). Because D<sup>p</sup> and N<sup>p</sup> impose opposite boundary conditions on each field, there are no

chiral anomalies breaking the U(1)<sup>~</sup> and topological symmetries. Therefore, Υ<sup>p</sup> should have the property that it cancels the unwanted anomalies, but does not contribute in the overlaps like hDp|Npi. Thus, the elliptic genus of Υ<sup>p</sup> should be a non-trivial meromorphic non-elliptic function of s, x, ~, z (non-ellipticity is what cancels the anomaly), such that at s = s (p) (x, ~) it becomes 1.

It is relatively easy to achieve this. Suppose the future boundary that engineers hDp| has the anomaly polynomial P+[Dp](f,fx,f~, r), in which we substitute f = fp(fx,f~). The anomaly polynomial associated with |Dpi is likewise denoted P Dp <sup>−</sup> . What is the anomaly of |Npi? If we allow ourselves to abuse the notations and formally include the chiral anomalies (to be canceled) in the polynomial, then we associate the following with |Npi:

<span id="page-96-0"></span>
$$-P_{+}[\mathscr{D}_{p}](\mathbf{f},\mathbf{f}_{x},\mathbf{f}_{\hbar},\mathbf{r}) + P[\Upsilon_{p}](\mathbf{f},\mathbf{f}_{x},\mathbf{f}_{\hbar},\mathbf{r}). \tag{6.53}$$

The first term is −P+[Dp] because in |Npi, all the Dirichlet/Neumann boundary conditions have been flipped compared to hDp|, and the inflow terms have opposite signs as well. Cancellation of chiral anomalies implies that all the terms proportional to f must cancel in [\(6.53\)](#page-96-0), and we would like to obtain −P+[Dp] f=fp(fx,f~) in the end. Thus, the role of P[Υp] is to replace f by fp(fx,f~), and we want:

<span id="page-96-1"></span>
$$P[\Upsilon_p] \sim \text{Tr}\left(\mathbf{f} - f_p(\mathbf{f}_x, \mathbf{f}_{\hbar})\right)(\dots),$$
 (6.54)

where (. . .) is the linear expression in fx, f~, and r that enters the chiral anomaly.

To make this more concrete, let us evaluate the boundary anomalies of Dp, which are the 't Hooft anomalies. The anomaly polynomials consist of two terms:

$$P_{\pm}^{\mathscr{D}_p} = \pm P_{\rm CS} + P_{\partial},\tag{6.55}$$

where ±PCS is the inflow term due to the CS terms [\(6.27\)](#page-85-1), [\(6.29\)](#page-86-2), and the BF term [\(2.12\)](#page-12-0), all of which are present in T C p . The sign in front of ±PCS depends on whether the boundary conditions are "left" or "right", i.e., which end of the interval (0, y+) we are looking at. At

zero modes on the interval with D<sup>p</sup> and N<sup>p</sup> at the opposite ends. Thus the overlap is simply 1. Cancellation of non-zero modes also guarantees that the partition function is independent of the length of the interval, which is only true in theories that do not break SUSY spontaneously. This is why we were free to insert e <sup>−</sup>TH in [\(6.52\)](#page-95-1) regularizing the otherwise singular boundary states.

y = y+, the inflow term is +PCS, and it can be read off from [\(6.27\)](#page-85-1), [\(6.29\)](#page-86-2), [\(2.12\)](#page-12-0) as

$$P_{\text{CS}} = (\mathbf{f}_{\hbar} - \mathbf{r}) \left[ \text{Tr}_{\mathcal{R}_{-}(p)} - \text{Tr}_{\mathcal{R}_{+}(p)} \right] (\mathbf{f} + \mathbf{f}_{x}) - 2\mathbf{f}_{\hbar} \sum_{\alpha \in \Delta_{+}(p)} \langle \alpha, \mathbf{f} \rangle + 2 \text{Tr} (\mathbf{f} \mathbf{f}_{z}).$$
 (6.56)

At y = 0, the inflow term is −PCS. As for the term P∂, it is the contribution of boundary conditions alone, and is given by:

$$P_{\partial} = \underbrace{\left(\mathbf{f}_{\hbar} - \mathbf{r}\right) \left[\operatorname{Tr}_{\mathcal{R}_{0}^{D}(p)} - \operatorname{Tr}_{\mathcal{R}_{0}^{N}(p)}\right] \left(\mathbf{f} + \mathbf{f}_{x}\right)}_{\text{hypers in } \mathcal{R}_{0}(p)} + \underbrace{\frac{\left|G_{p}\right|}{2} \left(\mathbf{f}_{\hbar}^{2} - \mathbf{r}^{2}\right)}_{G_{p} \text{ vector multiplet}}.$$
(6.57)

We have to collect the coefficients in front of f in −P+[Dp], which will give the expression for (. . .) in [\(6.54\)](#page-96-1). With [\(6.54\)](#page-96-1) known, it is fairly easy to construct Υ<sup>p</sup> meeting our requirements. Its general structure can be cumbersome (and is not unique), so we will rather construct it in examples.

Note that here we do not assume hDp| and hNp| to be the conjugates of |Dpi and |Npi, and in fact they are not. For example, |Dpi is Q-closed, but, unlike the exact vacuum |pi, is not Q† -closed. The conjugate of |Dpi is thus some Q† -closed covector that we never use. What we call hDp| is a different covector that is Q-closed and works as a proxy for hp|. For the same reason, the overlaps like hDp|Dpi and hNp|Npi are not the norms of |Dpi and |Npi. It is possible to compute them via localization. In particular, hNp|Npi admits an expression in terms of the Jeffrey-Kirwan residues obtained in [\[167\]](#page-150-6). The expression for hDp|Dpi then follows by the relation 1 = <sup>|</sup>NpihNp<sup>|</sup> hNp|Npi in the cohomology:

$$\langle \mathcal{D}_p | \mathcal{D}_p \rangle = \langle \mathcal{D}_p | \frac{|\mathcal{N}_p \rangle \langle \mathcal{N}_p |}{\langle \mathcal{N}_p | \mathcal{N}_p \rangle} | \rangle \mathcal{D}_p \rangle = \frac{\langle \mathcal{D}_p | \mathcal{N}_p \rangle \langle \mathcal{N}_p | \mathcal{D}_p \rangle}{\langle \mathcal{N}_p | \mathcal{N}_p \rangle} = \frac{1}{\langle \mathcal{N}_p | \mathcal{N}_p \rangle}. \tag{6.58}$$

Remark: The N<sup>p</sup> boundary conditions may be problematic in some non-abelian gauge theories. They involve the N<sup>p</sup> boundary conditions on the hypermultiplets, which may explicitly break gauge symmetry by giving the Dirichlet and Neumann boundary conditions to components of the same irreducible representation of the non-abelian G. In such cases, a modification is required. Instead of using the N<sup>p</sup> boundary conditions, we simply give the Neumann boundary conditions to all chiral multiplets in R0(p)⊕R0(p). This introduces the gauge anomaly, which should be further cancelled by the boundary theory Υp.

Now, after describing the vacuum boundary conditions in T C p , let us move to T . The corresponding boundary conditions B<sup>L</sup>(p),p were constructed in Section [3.4,](#page-39-0) so we briefly remind their definition here. The weight subspace R0(p) still contains the hypermultiplets that develop vevs in the vacuum p. The remaining weights are split according to the polarization T <sup>∗</sup>R = L(p) ⊕ L <sup>⊥</sup>(p) (which can be chosen separately for each fixed point). Namely, we induce polarization <sup>L</sup>e(p) <sup>⊕</sup> <sup>L</sup>e<sup>⊥</sup>(p) on the complement of <sup>T</sup> <sup>∗</sup>R0(p) as in [\(3.57\)](#page-49-1), and obtain:

$$\mathcal{R} \oplus \overline{\mathcal{R}} = \mathcal{R}_0(p) \oplus \overline{\mathcal{R}}_0(p) \oplus \widetilde{\mathbb{L}}(p) \oplus \widetilde{\mathbb{L}}^{\perp}(p).$$
 (6.59)

It is still true that for every weight w ∈ R0(p), only one of the two chirals in the hyper (Iw, Jw) develops a vev. Thus the definition of D<sup>p</sup> boundary conditions for the hypermultiplets in R0(p) still makes sense, and we have:

$$\mathcal{B}_{\mathbb{L}(p),p} = \left\{ \begin{array}{c} D_p \text{ boundary conditions on the hypers in } \mathcal{R}_0(p) \\ \text{Dirichlet boundary conditions on the chirals in } \widetilde{\mathbb{L}}(p) \\ \text{Neumann boundary conditions on the chirals in } \widetilde{\mathbb{L}}^{\perp}(p) \\ \text{Dirichlet boundayr conditions on the vector multiplets, with } s = s^{(p)} \end{array} \right\}.$$

$$(6.60)$$

We will be interested in the overlaps of the sort Ψ[B<sup>L</sup>(p),p] = hB<sup>L</sup>(p),p|Ψi. Note that the line bundle that hB<sup>L</sup>(p),p| is valued in was studied, among other things, in Section [3.4.](#page-39-0)

Our main object of interest in the following is

<span id="page-98-1"></span>
$$\langle \mathscr{B}_{\mathbb{L}(p_2),p_2} | \mathcal{J}(0,m \to \infty_{\mathfrak{C}}) | \mathscr{N}_{p_1} \rangle,$$
 (6.61)

where the notation ∞<sup>C</sup> means that we take the infinite mass limit within the chamber C. The main statement is that this object, up to normalization, coincides with the matrix element of the elliptic stable envelope.

### <span id="page-98-0"></span>6.4 Computation of matrix elements

Now we can put all the ingredients together. Using the effective description of the interface between T and T C <sup>p</sup> developed in Section [6.2,](#page-82-0) and the boundary conditions defined in Sections [3.4](#page-39-0) and [6.3,](#page-92-0) we are able to compute the matrix elements [\(6.61\)](#page-98-1).

According to Section [6.2,](#page-82-0) to compute [\(6.61\)](#page-98-1) we consider the theory T for y > 0 and T C p1 for y < 0, with the natural interface in between. The boundary conditions N<sup>p</sup><sup>1</sup> are imposed at y = y<sup>−</sup> < 0 ("in the past"), and B<sup>L</sup>(p2),p<sup>2</sup> – at y = y<sup>+</sup> > 0 ("in the future"). Because the gauge fields obey Dirichlet boundary conditions at y = y+, the flat connection is not integrated over, and is simply fixed to s = s (p2) everywhere on the interval. As usual, it is enough to assume that it belongs to the maximal torus, s ∈ H. Since H ⊂ G<sup>p</sup><sup>1</sup> , this flat connection is unchanged as we cross the interface.

Now, some vector multiplets have no interval zero modes as they obey Dirichlet boundary conditions on one end and Neumann on another. All the g<sup>p</sup><sup>1</sup> -valued components are like that: they live on the entire interval, obey (2, 2) Dirichlet boundary conditions at y = y<sup>+</sup> and (2, 2) Neumann at y = y−. The remaining components in g \ g<sup>p</sup><sup>1</sup> only live on (0, y+) and obey (2, 2) Dirichlet boundary conditions at y = y+, while their boundary conditions at y = 0 are determined according to [\(6.43\)](#page-90-0). We see that components corresponding to the roots α ∈ −∆+(p1) obey Neumann boundary conditions at y = 0 and thus have no zero modes. Components in ∆+(p1), on the other hand, obey Dirichlet boundary conditions at y = 0 and do have interval zero modes.

Recall how the (2, 2) Dirichlet boundary conditions for a 3d N = 4 vector multiplet V = (V, Φ) work [\(2.34\)](#page-18-0). They leave unfixed the adjoint (0, 2) chiral S and the adjoint (0, 2) Fermi Ψ<sup>Φ</sup> at the boundary. When (2, 2) Dirichlet boundary conditions are imposed on both ends, these multiplets become the interval zero modes. Together, (S, ΨΦ) form a (2, 2) chiral, which is broken up into the (0, 2) multiplets S and Ψ<sup>Φ</sup> by the U(1)<sup>~</sup> background, as S has zero U(1)<sup>~</sup> charge while Ψ<sup>Φ</sup> has charge +1. The interval zero mode multiplets (S, ΨΦ) are labeled by the roots ∆+(p1), and we can easily compute their contribution to the partition function:

<span id="page-99-0"></span>
$$\mathbb{V}_{p_1}(s,\hbar) := \prod_{\alpha \in \Delta_+(p_1)} \frac{\vartheta(s^{-\alpha}\hbar)}{\vartheta(s^{\alpha})}.$$
(6.62)

To find the contribution of hypermultiplets, we identify boundary conditions on their constituent chiral multiplets. At the B<sup>L</sup>(p2),p<sup>2</sup> boundary, the ones that obey Dirichlet boundary conditions have weights in [\(3.60\)](#page-49-2),

$$\widehat{\mathbb{L}}(p_2) = \mathcal{R}_0^D(p_2) \oplus \overline{\mathcal{R}}_0^N(p_2) \oplus \widetilde{\mathbb{L}}(p_2), \tag{6.63}$$

and the complementary weights in R<sup>N</sup> 0 (p2)⊕R D 0 (p2)⊕Le<sup>⊥</sup>(p2) obey Neumann. At the interface between T and T C p1 , the ones obeying Dirichlet are (since T lives on the y > 0 side):

$$\mathcal{R}_{+}(p_1) \oplus \overline{\mathcal{R}}_{-}(p_1),$$
 (6.64)

with R−(p1) ⊕ R+(p1) obeying the Neumann. Finally, at the N<sup>p</sup><sup>1</sup> boundary, the remaining

hypers are broken into

$$\mathcal{R}_0^N(p_1) \oplus \overline{\mathcal{R}}_0^D(p_1) \tag{6.65}$$

obeying Dirichlet, and R<sup>D</sup> 0 (p1) ⊕ R N 0 (p1) obeying Neumann.

For the purpose of this computation, the T |T <sup>C</sup> p1 interface and the N<sup>p</sup><sup>1</sup> boundary conditions in the theory T C p1 can be collided together to give a single set of boundary conditions in T (that could be called stable boundary conditions). Identifying the interval zero modes (i.e., those originating from the fields obeying identical boundary conditions on the two ends), we then straightforwardly compute the elliptic genus contribution from the matter fields:

$$\mathbb{M}_{p_1, p_2}(s, \hbar, x) := \prod_{(w, f) \in Z_{p_1, p_2}} \frac{\vartheta(s^w x^f \hbar^{1/2})}{\vartheta(s^w x^f \hbar^{-1/2})}, \tag{6.66}$$

where w and f denote gauge and flavor weights, respectively, and

$$Z_{p_1,p_2} := \widehat{\mathbb{L}}(p_2) \cap \left( \mathcal{R}_0^N(p_1) \oplus \overline{\mathcal{R}}_0^D(p_1) \oplus \mathcal{R}_+(p_1) \oplus \overline{\mathcal{R}}_-(p_1) \right). \tag{6.67}$$

The final contribution that must be included is the elliptic genus of the boundary degrees of freedom Υ<sup>p</sup><sup>1</sup> , which may be denoted as

$$\mathbb{W}[\Upsilon_{p_1}](s, x, \hbar, z). \tag{6.68}$$

We will write it explicitly in the examples. The final answer for the overlap is obtained by multiplying these three factors and averaging them over the relative Weyl group W(G, S). We define what may be called an off-shell overlap:

$$\mathbf{S}_{p_1}(s, x, \hbar, z) := \operatorname{Sym}_{\mathcal{W}(G, \mathbb{S})} \Big( \mathbb{V}_{p_1}(s, \hbar) \mathbb{M}_{p_1, p_2}(s, \hbar, x) \mathbb{W}[\Upsilon_{p_1}](s, x, \hbar, z) \Big). \tag{6.69}$$

This expression is a section of a line bundle on ET(X). The overlap is obtained by specializing s = s (p2) (x, ~):

<span id="page-100-0"></span>
$$\langle \mathscr{B}_{\mathbb{L}(p_2),p_2} | \mathcal{J}(0, m \to \infty_{\mathfrak{C}}) | \mathscr{N}_{p_1} \rangle = \mathbf{S}_{p_1}(s^{(p_2)}(x, \hbar), x, \hbar, z).$$

$$(6.70)$$

Ambiguity. Note that our approach contains a fundamental ambiguity related to the choice of boundary theory Υ<sup>p</sup><sup>1</sup> , which is not unique. We can easily cook up a boundary 2d (0, 2) theory that is completely anomaly-free, and whose elliptic genus is a nontrivial meromorphic (fully elliptic) function of (s, x, ~, z), which furthermore evaluates to 1 after the specialization s = s (p1) (x, ~). Adding such a theory to Υ<sup>p</sup><sup>1</sup> is not prohibited by anything, and results in the ambiguity. It does not affect the line bundle that S<sup>p</sup><sup>1</sup> (s, x, ~, z) is valued in, but simply multiples the latter by a meromorphic section of the trivial line bundle. It can be viewed as the normalization ambiguity of the vacuum states. One would need to impose some further conditions to remove it, e.g., that |N<sup>p</sup><sup>1</sup> i is cohomologous to the normalized vacuum.

#### <span id="page-101-0"></span>6.5 Examples

Let us evaluate Sp(s, x, ~, z) explicitly in several examples and compare it to the stable envelopes. We find that they are proportional, with s playing the role of elliptic Chern roots, (x, ~) – equivariant, and z – K¨ahler parameters. The proportionality coefficient is such that S<sup>p</sup> is better interpreted as the pole-subtraction matrix of [\[52\]](#page-141-2).

#### <span id="page-101-1"></span>6.5.1 T <sup>∗</sup>CP n−1

The most basic example is the U(1) gauge theory with n charge-1 hypermultiplets denoted (Ii , Ji), i = 1..n. The Higgs branch for a positive FI parameter ζ<sup>R</sup> > 0 is X = T <sup>∗</sup>CP n−1 , with the base parameterized by I<sup>i</sup> and the fibers – by J<sup>i</sup> .

The flavor symmetry group is P SU(n). We define the equivariant parameters x1, . . . , x<sup>n</sup> and the real masses m1, . . . , mn, subject to

$$x_1 x_2 \dots x_n = 1,$$
  
 $m_1 + m_2 + \dots + m_n = 0,$  (6.71)

such that the chiral I<sup>i</sup> has the equivariant parmeter xi~ <sup>1</sup>/<sup>2</sup> and the real mass m<sup>i</sup> . In addition to the choice of chamber ζ<sup>R</sup> > 0 in the real FI space, choose the following chamber in the real mass space:

<span id="page-101-2"></span>
$$\mathfrak{C} = \{ m_1 > m_2 > \dots > m_n \}. \tag{6.72}$$

Other chambers can be accessed by the action of the permutation group Sn, the Weyl group of P SU(n).

There are precisely n fixed points corresponding to the massive vacua, all of which sit in the base of T <sup>∗</sup>CP n−1 :

$$p^{\text{th}}$$
 fixed point:  $I_i = \delta_{i,p} \sqrt{\zeta_{\mathbb{R}}}, \quad J_i = 0, \quad \sigma = -m_p.$  (6.73)

In this vacuum, (Ip, Jp) has no real mass, (I<sup>i</sup> , Ji) with i < p receive large positive real masses m<sup>i</sup> − mp, and those with i > p receive large negative real masses. Slightly abusing the notations, we can write:

$$\mathcal{R}_0(p)$$
 is spanned by  $I_p$ ,  
 $\mathcal{R}_+(p)$  is spanned by  $I_i, i < p$ ,  
 $\mathcal{R}_-(p)$  is spanned by  $I_i, i > p$ . (6.74)

Furthermore, in the splitting R0(p) = R<sup>D</sup> 0 (p) ⊕ R<sup>N</sup> 0 (p), R<sup>N</sup> 0 (p) is empty, so R<sup>D</sup> 0 (p) = R0(p) (because I<sup>p</sup> gets a vev and J<sup>p</sup> does not).

We see that G<sup>p</sup> = G = U(1), so the theory T C p1 corresponding to the vacuum p<sup>1</sup> is just a U(1) gauge theory with one hypermultiplet (I<sup>p</sup><sup>1</sup> , J<sup>p</sup><sup>1</sup> ). The boundary conditions between T at y > 0 and T C p1 at y < 0 are

$$I_i = \partial_y J_i = 0, i < p_1,$$

$$J_i = \partial_y I_i = 0, i > p_1.$$

$$(6.75)$$

To define the future boundary conditions, we pick a polarization. It is most convenient to choose a polarization on T <sup>∗</sup>CP n−1 that corresponds to leaves along the base (the pull-back of the tangent bundle under the projection T <sup>∗</sup>CP <sup>n</sup>−<sup>1</sup> → CP n−1 ). It lifts to the following linear polarization on the hypermultipelts:

$$\mathbb{L}$$
 is spanned by  $I_i, i = 1..n$ ,  $\mathbb{L}^{\perp}$  is spanned by  $J_i, i = 1..n$ . (6.76)

Thus the B<sup>L</sup>,p<sup>2</sup> boundary conditions imposed at the future boundary (where we pick the vacuum p2) are simply the Dirichlet boundary conditions on the hypers:[22](#page-102-0)

$$I_i = \delta_{i,p_2} \sqrt{\zeta_{\mathbb{R}}}, \quad \partial_y J_i = 0,$$
 (6.77)

and the Dirichlet boundary conditions on the vectors, with the boundary flat connection

$$s = s^{(p_2)}(x,\hbar) = x_{p_2}^{-1}\hbar^{-1/2}. (6.78)$$

<span id="page-102-0"></span><sup>22</sup>The precise boundary value of I<sup>p</sup><sup>2</sup> is not important as it undergoes a non-trivial RG flow. In any case, it never appears in our formulas.

The latter equation follows from the I<sup>p</sup><sup>2</sup> having the weight sx<sup>p</sup><sup>2</sup> ~ 1/2 .

The boundary conditions N<sup>p</sup><sup>1</sup> at the past boundary are:

$$\partial_y I_{p_1} | = J_{p_1} | = 0$$
, and (2,2) Neumann boundary conditions on the vector multipelt. (6.79)

Additionally, we have to choose a boundary theory Υ<sup>p</sup><sup>1</sup> there. The boundary chiral anomaly of N<sup>p</sup><sup>1</sup> is easily found to be

$$[(2p_1 - 2 - n)(\mathbf{f}_{\hbar} - \mathbf{r}) - 2\mathbf{f}_z]\mathbf{f}. \tag{6.80}$$

This tells us, according to our rules, that the anomaly of Υ<sup>p</sup><sup>1</sup> must be:

$$P[\Upsilon_{p_1}] = 2\left(\mathbf{f} + \mathbf{f}_{p_1} + \frac{1}{2}\mathbf{f}_{\hbar} - \frac{1}{2}\mathbf{r}\right)\left(\mathbf{f}_z - \left(p_1 - 1 - \frac{n}{2}\right)\left(\mathbf{f}_{\hbar} - \mathbf{r}\right)\right),\tag{6.81}$$

where f<sup>p</sup><sup>1</sup> is the field strength for the flavor symmetry U(1) ⊂ A whose fugacity is x<sup>p</sup><sup>1</sup> . We need to construct a 2d system with such an anomaly, which also has the property that its torus partition function (elliptic genus) is 1 at s = s (p1) (x, ~). It is not hard to just write the elliptic genus which satisfies such conditions:

$$W[\Upsilon_{p_1}] = \frac{\vartheta(sx_{p_1}\hbar^{1/2} \times z\hbar^{-(p_1-n/2)})\vartheta(\hbar^{-1})}{\vartheta(sx_{p_1}\hbar^{1/2} \times \hbar^{-1})\vartheta(z\hbar^{-(p_1-n/2)})},$$
(6.82)

where we organized factors in a way that makes anomalies manifest. This elliptic genus can be realized via the following set of multiplets:

| Multiplet | weight under<br>U(1)<br>×<br>SU(n)<br>×<br>U(1)~<br>×<br>U(1)top |
|-----------|------------------------------------------------------------------|
| Fermi     | ~<br>1<br>(n+1)−p1 z<br>sxp1<br>2                                |
| Fermi     | ~<br>−1                                                          |
| Chiral    | ~<br>−1/2<br>sxp1                                                |
| Chiral    | 1<br>~<br>n−p1 z<br>2                                            |

where instead of explicitly writing out charges of each multiplet, we wrote the corresponding weight (fugacity).

It is straightforward to compute the remaining ingredients of the interval partition function. Since the gauge group is abelian, there is no V<sup>p</sup><sup>1</sup> . The factor M<sup>p</sup>1,p<sup>2</sup> only receives contributions from (I<sup>i</sup> , Ji), i < p1, since they obey identical boundary conditions on the two ends. We thus find:

$$\mathbf{S}_{p_1}(s, x, \hbar, z) = \frac{\vartheta(sx_{p_1}\hbar^{1/2}z\hbar^{-(p_1-n/2)})\vartheta(\hbar^{-1})}{\vartheta(sx_{p_1}\hbar^{-1/2})\vartheta(z\hbar^{-(p_1-n/2)})} \prod_{i < p_1} \frac{\vartheta(sx_i\hbar^{1/2})}{\vartheta(sx_i\hbar^{-1/2})}.$$
 (6.83)

To make contact with the math literature, we have to redefine some variables. First, it makes sense to replace:

$$s\hbar^{1/2} \mapsto s,\tag{6.84}$$

such that at the p'th vacuum one has  $sx_p = 1$ , which is more common in the literature on this subject [52,85]. Second, let us rescale:<sup>23</sup>

$$z\hbar^{-n/2} \mapsto z. \tag{6.85}$$

This gives:

<span id="page-104-1"></span>
$$\widetilde{\mathbf{S}}_{p_1}(s, x, \hbar, z) = \frac{\vartheta(\hbar^{-1})}{\prod_{i=1}^n \vartheta(sx_i\hbar^{-1})} \times \underbrace{\prod_{i < p_1} \vartheta(sx_i) \frac{\vartheta(sx_{p_1}z\hbar^{-(p_1-n)})}{\vartheta(z\hbar^{-(p_1-n)})} \prod_{i > p_1} \vartheta(sx_i\hbar^{-1})}_{\text{Stab}(p_1)}, \tag{6.86}$$

where in the second factor, upon comparison with [52], we clearly recognize the elliptic stable envelope of a point  $p_1$  (after an insignificant replacement  $\hbar \mapsto \hbar^{-1}$ , due to an unfortunate mismatch of conventions). The first factor in (6.86), which in the language of [52] would be written as a section of  $\Theta((T^{1/2}X)^{\vee} - \hbar)^{-1}$ , makes  $\mathbf{\tilde{S}}_{p_1}$  look more like the pole-subtraction matrix  $\mathfrak{P}_{\mathfrak{C}}$  (compare with the Section 5.4.1 of [105]). The pole-subtraction matrix is indeed just a differently normalized elliptic stable envelope. The reason we find such a normalization here is that our Janus interfaces can be used to construct a natural interface between the Coulomb and Higgs phases, as we will explore more fully in the upcoming paper.

Finally, the matrix elements of the interface are given by (6.70), and they are

$$\mathbf{S}_{p_1}(s^{(p_2)}(x,\hbar), x, \hbar, z) \neq 0 \Leftrightarrow p_1 \leq p_2. \tag{6.87}$$

Components with  $p_2 < p_1$  vanish because  $\vartheta(1) = 0$ . Hence the transition between vacua across the interface is possible if  $p_1 \leq p_2$ . We can write it as the following ordering of

<span id="page-104-0"></span><sup>&</sup>lt;sup>23</sup>This, most likely, has to do with the fact that z counts BPS monopoles, and, since monopoles transform under  $SU(2)_C$ , they have non-zero  $U(1)_{\hbar}$  charge. Thus the natural expansion parameter, in our conventions, is not z but rather  $z\hbar^{-n/2}$ .

<span id="page-104-2"></span><sup>&</sup>lt;sup>24</sup>Here  $T^{1/2}X$  is the polarization of X that we chose,  $(T^{1/2}X)^{\vee}$  is the dual polarization,  $\hbar$  is the trivial line bundle acted on by  $U(1)_{\hbar}$ , and  $\Theta(\cdot)$  is the elliptic Thom class.

massive vacua:

$$1 \to 2 \to \dots \to n,\tag{6.88}$$

where arrows denote possible gradient flows. This is the ordering of fixed points corresponding to the choice of chamber in [\(6.72\)](#page-101-2).

Note that our conventions differ from [\[52\]](#page-141-2) in one more little detail: our stable envelope is supported on the full repellent Rep(p1) of a fixed point, while theirs is supported on the full attractor Attr(p1). Thus, our answer for the chamber C equals their answer for −C.

We studied J (0, m → ∞C)|pi (or rather J (0, m → ∞C)|Npi), in which case we naturally obtain Rep(p1). We could of course consider a reflected configuration, when T occupies the y < 0 side, and T C p – the y > 0 side of the interface, which would compute hp|J (m → ∞C, 0). Such a setup would produce stable envelopes supported on the attractor, like in [\[52\]](#page-141-2). The choice made in the current text was motivated by the intention to contrast/compare the two approaches.

#### <span id="page-105-0"></span>6.5.2 An−<sup>1</sup> ALE space

In the T <sup>∗</sup>CP n−1 example of the previous section, we were able to choose a linear polarization L on the hypermultipelts, such that at all fixed points, only the chirals I ∈ L were getting vevs. Such a global L does not exist in general, and the simplest example to illustrate this is the A<sup>N</sup> ALE space, which we will simply denote A<sup>N</sup> . The gauge theory that has A<sup>N</sup> for its Higgs branch is the circular abelian quiver with N + 1 U(1) gauge nodes connected to each other by the bi-fundamental hypers Hi,i+1. In fact, this theory is 3d mirror to the SQED<sup>n</sup> considered in the previous subsection, with N = n − 1, which makes it even more appropriate to study now.

In the circular quiver, the diagonal U(1) vector multipelt decouples and is usually remover from the theory, so it is better to consider an equivalent linear quiver, which is more transparent to study:

![](_page_105_Picture_8.jpeg)

There are N gauge nodes, and this is a 3d N = 4 quiver, meaning that each (unoriented)

line denotes a bifundamental hypermultiplet. Let us denote the hypermultiplets by

$$(I_{i,i+1}, J_{i,i+1}), i = 0 \dots N,$$
 (6.89)

where each Ii,i+1 has charges (1, −1) with respect to the i'th and (i + 1)'th U(1) factor. In this notation, the 0'th and the (N + 1)'th copies of U(1) are not gauged, while those labeled by 1, 2, . . . , N are gauged. Despite appearance of two U(1) flavor nodes, the flavor symmetry group here is

$$G_H = U(1)_f,$$
 (6.90)

and correspondingly, there is only one real mass m, which has two chambers, m > 0 and m < 0 (like the FI parameter in the mirror SQED). We choose

$$\mathfrak{C} = \{m > 0\}. \tag{6.91}$$

We incorporate this mass in the Lagrangian by giving it to the left-most hyper:

$$(I_{0,1}, J_{0,1})$$
 are given real masses  $(m, -m)$ . 
$$(6.92)$$

We can identify it with the real scalar in the 0'th, i.e. non-dynamical, vector multiplet:

$$\sigma_0 = m. (6.93)$$

There are N real FI parameters (ζ1, . . . , ζ<sup>N</sup> ) corresponding to the gauge nodes. One usually introduces parameters ω0, . . . , ω<sup>N</sup> , such that

$$\zeta_i = \omega_{i-1} - \omega_i, \quad \text{and} \quad \sum_{i=0}^N \omega_i = 0.$$
(6.94)

These ω<sup>i</sup> 's are mapped to masses in SQEDN+1 under the mirror symmetry. The FI chambers correspond to different orderings of the ω<sup>i</sup> 's, and we choose to work in the chamber:

$$\omega_0 > \omega_1 > \dots > \omega_N, \tag{6.95}$$

or in other words, all the FI parameters are positive ζ<sup>i</sup> > 0. The Higgs branch is described

by XY = Z <sup>N</sup>+1, with

$$X = \prod_{i=0}^{N} I_{i,i+1}, \quad Y = \prod_{i=0}^{N} J_{i,i+1}, \quad Z = I_{i,i+1} J_{i,i+1}, \tag{6.96}$$

where in the last equation i is any number from 0 to N, since the complex moment map constraints ensure

<span id="page-107-0"></span>
$$I_{0,1}J_{0,1} = I_{1,2}J_{1,2} = \dots = I_{N,N+1}J_{N,N+1}. \tag{6.97}$$

The singularity of XY = Z <sup>N</sup>+1 is resolved by the FI parameters, with the real moment map constraints given by

<span id="page-107-1"></span>
$$|I_{i,i+1}|^2 - |J_{i,i+1}|^2 - |I_{i-1,i}|^2 + |J_{i-1,i}|^2 = \zeta_i, \ i = 1 \dots N.$$

$$(6.98)$$

There are N + 1 massive vacua, i.e. fixed points of U(1)<sup>f</sup> , which we label by k = 0, . . . , N. In the k'th massive vacuum, the dynamical real scalars in the vector multiplet take values:

$$\sigma_1 = \sigma_2 = \dots \sigma_k = m,$$
  

$$\sigma_{k+1} = \sigma_{k+2} = \dots \sigma_N = 0,$$
(6.99)

and in the k = 0 vacuum, they simply all vanish. The effective real masses of all the hypermultiplets vanish, except for the k'th hyper (Ik,k+1, Jk,k+1), which obtains effective real mass

<span id="page-107-2"></span>
$$(m_{\text{eff}}, -m_{\text{eff}}), \qquad m_{\text{eff}} = \sigma_k - \sigma_{k+1} = m.$$
 (6.100)

The k'th hyper thus has zero expectation value. The vevs of others are fixed by the equations [\(6.97\)](#page-107-0) and [\(6.98\)](#page-107-1), and we find:

For 
$$i < k$$
:  $I_{i,i+1} = 0$ ,  $|J_{i,i+1}| = \sqrt{\zeta_{i+1} + \zeta_{i+2} + \dots + \zeta_k}$ ,  
For  $i > k$ :  $J_{i,i+1} = 0$ ,  $|I_{i,i+1}| = \sqrt{\zeta_{k+1} + \zeta_{k+2} + \dots + \zeta_i}$ . (6.101)

It is clear that the equivariant parameters basically repeat this pattern, up to a modification by ~. Namely, there is one flavor parameter x (in addition to ~), which is assigned to the 0'th hypermultiplet. There are N gauge equivariant parameters (Chern roots) s1, . . . , s<sup>N</sup> , and at the k'th vacuum they adjust to:

<span id="page-108-0"></span>
$$s_i^{(k)} = x\hbar^{-i/2}, \ i = 1...k$$
  

$$s_i^{(k)} = \hbar^{-\frac{N+1-i}{2}}, \ i = k+1...N.$$
(6.102)

As we send m → +∞, the k'th hyper freezes and disappears from the spectrum. What remains is our theory T C k , which is now seen to be described by a disconnected pair of quivers:

![](_page_108_Picture_3.jpeg)

where the left quiver has k gauge nodes, and the right one has N − k gauge nodes. Each of these two theories has no flavor symmetries (as expected) and only one isolated vacuum described exactly as before (which is automatically massive), confirming that T C <sup>k</sup> has only one massive vacuum.

We see from [\(6.101\)](#page-107-2) that which chiral in a pair (Ii,i+1, Ji,i+1) receives a vev depends on the vacuum k. Thus there is no one single polarization L such that only chirals in L receive vevs. We still have to choose polarization, however, because (Ik,k+1, Jk,k+1) does not have a vev in the vacuum k. Let us pick polarization spanned by Ii,i+1, so in the vacuum k, Ik,k+1 is given Dirichlet boundary conditions.

Now we can define B<sup>L</sup>,p boundary conditions. On the hypers we impose:

$$I_{p,p+1} = \partial_y J_{p,p+1} = 0,$$
  
For  $i 
For  $i > p : \partial_y J_{i,i+1} = 0, \quad I_{i,i+1} = c_i,$  (6.103)$ 

where c<sup>i</sup> are the vevs as in [\(6.101\)](#page-107-2). On the vectors we impose the usual (2, 2) Dirichlet boundary conditions with the boundary flat connection s = s (p) (x, ~).

If we have T in the y > 0 half-space and T C k in the y < 0, then the hyper (Ik,k+1, Jk,k+1) only lives on the y > 0 side. For m → +∞, at the interface it obeys:

$$I_{k,k+1} = \partial_y J_{k,k+1} = 0.$$
 (6.104)

We also have to describe N<sup>k</sup> boundary conditions in the T C k theory defined by the disconnected quiver shown earlier. The gauge fields obey (2, 2) Neumann boundary conditions. Hypermultiplets, as it follows from [\(6.101\)](#page-107-2), obey:

For 
$$i < k$$
:  $I_{i,i+1} = 0$ ,  $\partial_y J_{i,i+1} = 0$ ,  
For  $i > k$ :  $J_{i,i+1} = 0$ ,  $\partial_y I_{i,i+1} = 0$ . (6.105)

Finally, we need to include the boundary theory Υk. For that, we have to compute the boundary chiral anomaly of Nk. First we note that R−(k) is 0, R+(k) only contains Ik,k+1, and R<sup>D</sup> 0 (k) spans {Ik+1,k+2, Ik+2,k+3, . . . , IN,N+1}, while R<sup>N</sup> 0 (k) spans {I0,1, I1,2, . . . , Ik−1,k}. With the help of this data, we find the boundary chiral anomaly of N<sup>k</sup> to be:

$$-2\left[\sum_{i=1}^{N}\mathbf{f}_{i}\mathbf{f}_{z}^{(i)}+(\mathbf{f}_{\hbar}-\mathbf{r})\mathbf{f}_{k+1}\right],$$
(6.106)

where f<sup>i</sup> denote the gauge field strengths, and f (i) <sup>z</sup> – the corresponding topological symmetries. The last term here must be dropped for k = N, since fN+1 does not correspond to the gauge symmetry.

From equations [\(6.102\)](#page-108-0), we know that f<sup>i</sup> − f<sup>x</sup> + i 2 f<sup>~</sup> for i ≤ k and f<sup>i</sup> + N+1−i 2 f<sup>~</sup> for i > k are set to zero in the k'th vacuum. We thus find that the anomaly polynomial of Υ<sup>k</sup> must be:

$$P[\Upsilon_k] = 2 \left[ \sum_{j=1}^k \left( \mathbf{f}_j - \mathbf{f}_x + \frac{j}{2} \mathbf{f}_\hbar \right) \mathbf{f}_z^{(j)} + \sum_{j=k+1}^N \left( \mathbf{f}_j + \frac{N+1-j}{2} \mathbf{f}_\hbar \right) \mathbf{f}_z^{(j)} + (\mathbf{f}_\hbar - \mathbf{r}) \left( \mathbf{f}_{k+1} + \frac{N-k}{2} \mathbf{f}_\hbar \right) \right],$$
(6.107)

where the last term should also be dropped for k = N. This anomaly polynomial can be engineered by N copies of the system, which, like in the T <sup>∗</sup>CP n−1 case, contains two Fermi and two chiral multiplets in each copy. We can just directly write (a non-unique) elliptic genus corresponding to the anomaly polynomial P[Υk]:

$$\mathbb{W}[\Upsilon_{k}] = \frac{\vartheta(s_{k+1}\hbar^{(N-k)/2+1}z_{k+1}\xi_{k+1})\vartheta(\xi_{k+1})}{\vartheta(s_{k+1}\hbar^{(N-k)/2}\xi_{k+1})\vartheta(z_{k+1}\hbar\xi_{k+1})} 
\times \prod_{j=1}^{k} \frac{\vartheta(s_{j}x^{-1}\hbar^{j/2}z_{j}\xi_{j})\vartheta(\xi_{j})}{\vartheta(s_{j}x^{-1}\hbar^{j/2}\xi_{j})\vartheta(z_{j}\xi_{j})} \prod_{j=k+2}^{N} \frac{\vartheta(s_{j}\hbar^{(N+1-j)/2}z_{j}\xi_{j})\vartheta(\xi_{j})}{\vartheta(s_{j}\hbar^{(N+1-j)/2}\xi_{j})\vartheta(z_{j}\xi_{j})},$$
(6.108)

and it is straightforward, though tedious, to describe charges of the corresponding multiplets. Notice that we have incorporated undefined variables ξ1, . . . , ξ<sup>N</sup> , which can be some products of powers of the fugacities (s, x, ~, z). Their presence does not change the anomaly polynomial or spoil the fact that at s = s (k) (x, ~), W[Υk] evaluates to 1. We just have to make sure that we do not introduce unwanted poles or zeros, for example ξ<sup>j</sup> = 1 would be a bad choice. This is of course part of the previously mentioned ambiguity of multiplication by a fully elliptic meromorphic function.

Let us look at the remaining ingredients. Again, there is no V<sup>k</sup> because the gauge group is abelian. The factor Mk,p receives contributions from the hypermultiplets. At the B<sup>L</sup>,p boundary (say at y = y<sup>+</sup> > 0), (Ii,i+1, Ji,i+1) obey (D,N) for i ≥ p and (N,D) for i < p. At the interface (say at y = 0), (Ik,k+1, Jk,k+1) obey (D, N), and at the opposite end (say at y = y<sup>−</sup> < 0), (Ii,i+1, Ji,i+1) obey (D,N) for i < k and (N,D) for i > k. We see that when p > k, only the multiplets (Ii,i+1, Ji,i+1) with k < i < p have interval zero modes, while for p ≤ k, only those with p ≤ i ≤ k have them. We can thus write the elliptic genus of zero modes:

<span id="page-110-2"></span>
$$p > k: \quad \mathbb{M}_{k,p} = \prod_{k < i < p} \frac{\vartheta(s_{i+1}s_i^{-1}\hbar^{1/2})}{\vartheta(s_is_{i+1}^{-1}\hbar^{1/2})},$$

$$p \le k: \quad \mathbb{M}_{k,p} = \prod_{p \le i \le k} \frac{\vartheta(s_is_{i+1}^{-1}\hbar^{1/2})}{\vartheta(s_{i+1}s_i^{-1}\hbar^{1/2})}.$$
(6.109)

These expressions are to be evaluated at s = s (p) (x, ~), as usual. One can notice that this gives zero, unless p = k or p = k + 1. This is not the expected answer: rather, the vacuum k should be able to flow to any vacuum p ≥ k.

This can be seen, first of all, from the gradient flow equations. One can see that for m > 0, the flow goes to the right in the quiver, and the vacua are ordered according to:

<span id="page-110-1"></span><span id="page-110-0"></span>
$$0 \to 1 \to 2 \to \dots \to N. \tag{6.110}$$

An illustration of this is given on Figure [7.](#page-110-0)

![](_page_110_Picture_7.jpeg)

Figure 7: Schematic illustration of the A<sup>5</sup> space. The arrow denotes direction of the "wind", i.e., the gradient flow. The fixed points are where the segments touch each other.

In our effective approach, the direction of the flow is determined by the boundary conditions on the hypers that terminate at the  $\mathcal{T}|\mathcal{T}_k^{\mathfrak{C}}$  interface. Indeed, these boundary conditions are chosen in accordance with the direction of the flow on the massive side. In the current example, only  $(I_{k,k+1}, J_{k,k+1})$  ends there and obeys (D, N) boundary conditions. If p < k, then  $(I_{k,k+1}, J_{k,k+1})$  also obeys the (D, N) boundary conditions on the other end, and furthermore  $I_{k,k+1}$  is given a boundary vev there, which implies that the partition function of this multiplet is zero.<sup>25</sup> For  $p \geq k$  this does not happen, so one naturally expects to have transitions from k to all possible vacua on the right in (6.110).

The fact that the answer (6.109) vanishes at  $s^{(p)}(x,\hbar)$  for  $p \geq k+2$  does therefore look like a problem. However, we can use the ambiguity in  $\mathbb{W}[\Upsilon_k]$  to cancel the unwanted zeroes in  $\mathbb{M}_{k,p}$ . For example, we may pick:

$$\xi_j = s_{j-1}^{-1} \hbar^{(j-N)/2}, \quad \text{For } j \ge k+2,$$
 (6.111)

while  $\xi_j = \hbar^{-1}$  for  $j \le k + 1$ . This gives:

$$\mathbb{W}[\Upsilon_{k}] = \frac{\vartheta(s_{k+1}\hbar^{(N-k)/2}z_{k+1})\vartheta(\hbar^{-1})}{\vartheta(s_{k+1}\hbar^{(N-k)/2-1})\vartheta(z_{k+1})} \times \prod_{j=1}^{k} \frac{\vartheta(s_{j}x^{-1}\hbar^{j/2-1}z_{j})\vartheta(\hbar^{-1})}{\vartheta(s_{j}x^{-1}\hbar^{j/2-1})\vartheta(z_{j}\hbar^{-1})} \prod_{j=k+2}^{N} \frac{\vartheta(s_{j}s_{j-1}^{-1}\hbar^{1/2}z_{j})\vartheta(s_{j-1}^{-1}\hbar^{(j-N)/2})}{\vartheta(s_{j}s_{j-1}^{-1}\hbar^{1/2})\vartheta(z_{j}s_{j-1}^{-1}\hbar^{(j-N)/2})}.$$
(6.112)

We thus find:

$$\mathbf{S}_{k}(s^{(k)}(x,\hbar), x, \hbar, z) = \mathbb{W}[\Upsilon_{k}]\big|_{s=s^{(k)}(x,\hbar)} = 1,$$

$$\mathbf{S}_{k}(s^{(k+1)}(x,\hbar), x, \hbar, z) = \mathbb{W}[\Upsilon_{k}]\big|_{s=s^{(k+1)}(x,\hbar)} = \frac{\vartheta(xz_{k+1}\hbar^{(N-1)/2-k})\vartheta(\hbar^{-1})}{\vartheta(x\hbar^{(N-1)/2-k-1})\vartheta(z_{k+1})},$$
(6.113)

while for  $p \ge k + 2$ :

$$\mathbf{S}_{k}(s^{(p)}, x, \hbar, z) = \mathbb{W}[\Upsilon_{k}] \mathbb{M}_{k, p} \Big|_{s=s^{(p)}(x, \hbar)}$$

$$= \frac{\vartheta(x z_{k+1} \hbar^{(N-1)/2-k}) \vartheta(\hbar^{-1})}{\vartheta(x \hbar^{(N-1)/2-k-1}) \vartheta(z_{k+1})} \prod_{j=k+2}^{p} \frac{\vartheta(z_{j}) \vartheta(x^{-1} \hbar^{j-(N+1)/2})}{\vartheta(\hbar) \vartheta(z_{j} x^{-1} \hbar^{j-(N+1)/2})}. \quad (6.114)$$

<span id="page-111-0"></span><sup>&</sup>lt;sup>25</sup>BPS, or gradient flow, equation does not have a solution that connects  $I_{k,k+1}|_{y=0} = 0$  to  $I_{k,k+1}|_{y=y_+} = c_k$  in finite time. Even if we could find such a solution somewhere in field space (say at infinite  $\sigma_k$ ), there would be a fermion zero mode that at  $s = s^{(p)}$  does not have a fugacity and forces the path interval to vanish.

The normalization obtained here is different from the normalization of stable envelopes in the mathematical literature [51,52]. Namely, their normalization condition is that Stab(p) restricted to Attr(p) (not the full attractor!) is equal to  $i_*j^*$ , where  $j^*$  is the pullback from p to Attr(p), and  $i_*$  is the pushforward from Attr(p) into the ambient space X. If one restricts this back to the point p, one simply obtains the Euler class of the repelling subspace  $TX_>$ , which in the elliptic case is  $\Theta(TX_>)$ . Since in our treatment attractors and repellants are swapped, the proper normalization of the elliptic stable envelope (in the current conventions) involves the attractor, which corresponds to the  $I_{k,k+1}$  direction at the fixed point k:

$$\operatorname{Stab}(k)\big|_{k} = \Theta(T_{p}X_{<}) = \vartheta(s_{k}s_{k+1}^{-1}\hbar^{1/2})\big|_{s=s^{(k)}} = \vartheta(x\hbar^{(N+1)/2-k})$$
(6.115)

It would be interesting to compare our formulas to known results in the literature, e.g., [171].

#### <span id="page-112-0"></span>**6.5.3** $T^*Gr(N, L)$

This space is realized as the Higgs branch of the U(N) gauge theory with L fundamental hypermultiplets  $(I_i^a, J_a^i)$ , a = 1, ..., N, i = 1, ..., L, with the flavor group  $U(1)_{\hbar} \times PSU(L)$ . The topological symmetry is just  $\mathbf{A}' = U(1)_{\text{top}}$ .

The F-term equation is

<span id="page-112-1"></span>
$$\sum_{i=1}^{L} I_i^a J_b^i = 0, \ a, b = 1, \dots, N,$$
(6.116)

while the D-term equation reads:

<span id="page-112-2"></span>
$$\sum_{i=1}^{L} I_i^a \overline{I}_i^b - \overline{J}_a^i J_b^i = \zeta \delta_b^a, \quad a, b = 1, \dots, N.$$
 (6.117)

As in the previous example, we have the equivariant parameters  $x_1, \ldots, x_L$  obeying

$$\prod_{i} x_i = 1 , \qquad (6.118)$$

and  $\hbar$ , as well as L real masses  $m_i$ , obeying

$$m_1 + \ldots + m_L = 0, (6.119)$$

and, when generic enough, breaking the flavor group to its maximal torus A.

The **A**-fixed points  $p \in T^*Gr(N, L)$  are the solutions to (6.116) and (6.117), which, additionally, solve:

$$(m_i - \sigma_a) I_i^a = 0, \ (\sigma_a - m_i) J_a^i = 0,$$
 (6.120)

for some  $\sigma^{(p)} = \operatorname{diag}(\sigma_1, \dots, \sigma_N) \in \mathfrak{u}(N)$ .

Let us denote the color and flavor spaces  $\mathbb{C}^N$ ,  $\mathbb{C}^L$  by  $\mathbf{N}$  and  $\mathbf{L}$ , respectively. Then  $||I_i^a||$  is a matrix of an operator  $I: \mathbf{L} \to \mathbf{N}$ , while  $||J_a^i||$  is a matrix of an operator  $J: \mathbf{N} \to \mathbf{L}$ .

For masses, we again choose the chamber:

$$\mathfrak{C} = \{ m_1 > m_2 > \dots > m_L \}. \tag{6.121}$$

The FI parameters are taken from the chamber  $\mathfrak{C}' = \{\zeta > 0\}$  (for  $\zeta < 0$  exchange I with  $J^{\dagger}$ ), so I has to have a rank N by virtue of (6.117), implying

$$J_a^i = 0 \,, \ I_i^a = \sqrt{\zeta} \delta_i^{l(a)} \,, \ \sigma_a = m_{l(a)}$$
 (6.122)

for some injective map  $l:\{1,\ldots,N\}\to\{1,\ldots,L\}$ , modulo the permutation group  $S_N$  (the Weyl group of U(N)) acting on the domain. In other words, two such maps that differ by a permutation in the domain give gauge-equivalent vacua, and in total we obtain  $\binom{L}{N}$  isolated vacua.

The choice of the function l modulo  $S_N$  determines the fixed point  $p_l \in T^*Gr(N, L)^{\mathbf{A}}$ . Now let us look at the tangent space and its transformations under  $\mathbf{A}$ , as well as the gauge group  $G_{p_l} \subset U(N)$  left unbroken by  $\sigma^{(p_l)}$ . The latter consists of gauge transformations  $g \in U(N)$ , such that  $g^{-1}\sigma^{(p_l)}g = \sigma^{(p_l)}$ . For generic  $m_i$ 's, meaning  $m_i \neq m_i$  for  $i \neq j$  (which is the case inside the chamber  $\mathfrak{C}$ ,) this means  $g = \operatorname{diag}\left(e^{\mathrm{i}\varphi_a}\right)_{a=1}^N \in U(1)^N \subset U(N)$ , i.e. the maximal torus of the gauge group. So in this case the gauge group of the theory  $\mathcal{T}_{p_l}^{\mathfrak{C}}$  coincides with the maximal torus:

$$G_{p_l} = U(1)^N = \mathbf{H}.$$
 (6.123)

The roots  $e_a - e_b$ ,  $a \neq b$  of U(N) receive large masses  $m_{l(a)} - m_{l(b)}$ , so the W-boson multiplets are integrated out. Given the ordering in  $\mathfrak{C}$ , the positive mass roots are:

$$\Delta_{+}(p_l) = \{e_a - e_b : l(a) < l(b)\}. \tag{6.124}$$

The tangent space  $T_{p_l}T^*Gr(N,L)$  is parametrized by the fluctuations  $\delta I, \delta J$ , obeying the linearized Eqs. (6.116), (6.117), modulo the linearized gauge transformations. In the gauge  $\delta II^{\dagger} - J^{\dagger}\delta J - I\delta I^{\dagger} + \delta J^{\dagger}J = 0$ , these are the arbitrary fluctations  $\delta I_i^a, \delta J_a^i$ , with  $i \in \{1, \dots, L\} \setminus \{l(1), \dots, l(N)\}$ , in other words:

$$\delta I_{l(b)}^a = 0, \ \delta J_a^{l(b)} = 0, \ a, b = 1, \dots, N.$$
 (6.125)

The corresponding equivariant weights of  $\delta I_i^a$ ,  $\delta J_a^i$  are  $x_i x_{l(a)}^{-1}$ ,  $x_i^{-1} x_{l(a)} \hbar$ , as follows from the flat gauge field in the vacuum  $p_l$ :

<span id="page-114-0"></span>
$$s_a^{(p_l)} = x_{l(a)}^{-1} \hbar^{-1/2}. (6.126)$$

The real mass of the hypermultiplet  $(I_i^a, J_a^i)$  in the vacuum l is equal to  $m_i - m_{l(a)}$ . It is nonzero and large if  $i \neq l(a)$ , hence such hypermultiplets are integrated out. In the chamber  $\mathfrak{C}$ , the mass is positive for i < l(a), so the positive and negative weight subspaces are:

$$\mathcal{R}_{+}(p_{l}) = \text{ span of the weights of } I_{i}^{a}, \ i < l(a),$$

$$\mathcal{R}_{-}(p_{l}) = \text{ span of the weights of } I_{i}^{a}, \ i > l(a). \tag{6.127}$$

The remaining hypermultiplets form the matter content of  $\mathcal{T}_{p_l}^{\mathfrak{C}}$ :

$$\mathcal{R}_0(p_l) = \text{ span of the weights of } I^a_{l(a)}, \ a = 1 \dots N.$$
 (6.128)

Furthermore, because only  $I_i^{a}$ 's get vevs,  $\mathcal{R}_0^D(p_l) = \mathcal{R}_0(p_l)$ , and  $\mathcal{R}_0^N(p_l) = 0$ .

We thus see that  $\mathcal{T}_{p_l}^{\mathfrak{C}}$  is a tensor product of N copies of the SQED<sub>1</sub> (U(1) gauge theory with one hyper). All of its N FI parameters are equal to  $\zeta > 0$ , and there is only one vacuum. To avoid clumsy notations in the following, let us denote  $\mathcal{T}_{p_l}^{\mathfrak{C}}$  as  $\mathcal{T}_l^{\mathfrak{C}}$ , and in general simply label fixed points  $p_l$  as l.

To define the  $\mathscr{B}_{\mathbb{L},p_l} \equiv \mathscr{B}_{\mathbb{L},l}$  boundary conditions, it is most convenient to choose the global linear polarization  $\mathbb{L}$  spanned by the  $I_i^a$ 's. Then the  $\mathscr{B}_{\mathbb{L},l}$  is

$$I_i^a = \sqrt{\zeta} \delta_i^{l(a)}, \quad \partial_y J_a^i = 0, \tag{6.129}$$

accompanied by the usual Dirichlet boundary conditions on the vector multiplets, with the boundary flat connection (6.126).

Consider the interface  $\mathcal{T}|\mathcal{T}_l^{\mathfrak{C}}$ , such that on the massive side (which is y < 0) we pick the vacuum l. The boundary conditions on the  $\mathcal{R}_+(l) \oplus \mathcal{R}_-(l)$ -valued hypermultiplets (living on

the y > 0 side) at the interface are:

$$I_i^a = \partial_y J_a^i = 0, \quad \text{for } i < l(a),$$
  
 $J_a^i = \partial_u I_i^a = 0, \quad \text{for } i > l(a).$  (6.130)

The W-boson vector multiplets also terminate at y = 0, and obey the Dirichlet and Neumann boundary conditions for the roots in ∆+(l) and −∆+(l), respectively.

The N<sup>l</sup> boundary conditions in the theory T C l are imposed at y = y<sup>−</sup> < 0. All the vector multiplets are given Neumann boundary conditions, and the R0(l)-valued hypermultiplets obey:

$$J_a^{l(a)}| = \partial_y I_{l(a)}^a| = 0.$$
 (6.131)

The boundary chiral anomaly of N<sup>l</sup> is:

<span id="page-115-0"></span>
$$-2\mathbf{f}_{z}\operatorname{Tr}\mathbf{f} + 2\mathbf{f}_{\hbar}\sum_{\alpha \in \Delta_{+}(l)} \langle \alpha, \mathbf{f} \rangle + (\mathbf{f}_{\hbar} - \mathbf{r}) \left[ \operatorname{Tr}_{\mathcal{R}_{+}(l)} - \operatorname{Tr}_{\mathcal{R}_{-}(l)} - \operatorname{Tr}_{\mathcal{R}_{0}^{D}(l)} \right] \mathbf{f}.$$
 (6.132)

Note that the sum over positive roots evaluates to:

$$\sum_{\alpha \in \Delta_{+}(l)} \alpha = 2\rho_{l}, \tag{6.133}$$

where ρ<sup>l</sup> is a permutation of the standard Weyl vector ρ,

$$2\rho = (N - 1, N - 3, \dots, 1 - N). \tag{6.134}$$

Since we are going to Weyl-average in the end anyways, we may assume without loss of generality that l(1) < l(2) < · · · < l(N), in which case ρ<sup>l</sup> = ρ. Then [\(6.132\)](#page-115-0) evaluates to:

$$\sum_{a=1}^{N} \left[ -2\mathbf{f}_z \mathbf{f}_{aa} + 4\rho_a \mathbf{f}_{\hbar} \mathbf{f}_{aa} + (2l(a) - 2 - L)(\mathbf{f}_{\hbar} - \mathbf{r}) \mathbf{f}_{aa} \right], \tag{6.135}$$

where faa are the gauge fields corresponding to the maximal torus H = G<sup>l</sup> . To cancel this anomaly, we add the boundary theory Υ<sup>l</sup> with the anomaly polynomial:

$$P[\Upsilon_l] = 2\sum_{a=1}^N \left( \mathbf{f}_{aa} + (\mathbf{f}_x)_{l_1(a)} + \frac{1}{2}\mathbf{f}_{\hbar} - \frac{1}{2}\mathbf{r} \right) \left( \mathbf{f}_z + \left( \frac{L}{2} + 1 - l(a) - 2\rho_a \right) (\mathbf{f}_{\hbar} - \mathbf{r}) - 2\rho_a \mathbf{r} \right).$$

$$(6.136)$$

We again build Υ<sup>l</sup> from N systems of two Fermi and two chiral multiplets, whose charges can be read off from their elliptic genus:

$$W[\Upsilon_{l}] = \prod_{a=1}^{N} \frac{\vartheta(s_{a}x_{l(a)}\hbar^{1/2} \times z\hbar^{\frac{L}{2}-l(a)-2\rho_{a}})\vartheta(\hbar^{-1})}{\vartheta(s_{a}x_{l(a)}\hbar^{1/2} \times \hbar^{-1})\vartheta(z\hbar^{\frac{L}{2}-l(a)-2\rho_{a}})}.$$
(6.137)

Now we compute other contributions to the interval index. In this example, there is a non-trivial effect from the W-boson multiplets expressed as a product over α ∈ ∆+(l) [\(6.62\)](#page-99-0):

$$V_{l} = \prod_{\substack{a, b \\ l(a) < l(b)}} \frac{\vartheta(s_{b}s_{a}^{-1}\hbar)}{\vartheta(s_{a}s_{b}^{-1})} = \prod_{a < b} \frac{\vartheta(s_{b}s_{a}^{-1}\hbar)}{\vartheta(s_{a}s_{b}^{-1})}, \tag{6.138}$$

where we used the ordering l(1) < l(2) < · · · < l(N). Finally, the matter index M<sup>l</sup> receives contributions from (I a i , J<sup>i</sup> a ) with i < l(a), as these are the only hypers that have the interval zero modes (one Fermi multiplet for I a i and one chiral for J i a ). Their effect is captured by:

$$\mathbb{M}_{l} = \prod_{\substack{i, \ a \ i < l(a)}} \frac{\vartheta(s_{a}x_{i}\hbar^{1/2})}{\vartheta(s_{a}x_{i}\hbar^{-1/2})}.$$
(6.139)

Then the final answer is

$$\mathbf{S}_{l}(s, x, \hbar, z) = \operatorname{Symm}_{S_{N}} \left( \mathbb{V}_{l} \mathbb{M}_{l} \mathbb{W}[\Upsilon_{l}] \right), \tag{6.140}$$

where the symmetrization is performed over the gauge variables s<sup>a</sup> (elliptic Chern roots).

To compare this to the answer for Stab(l) given in [\[52\]](#page-141-2), let us introduce

$$f_k(S, Z) = \prod_{i < k} \vartheta(Sx_i) \frac{\vartheta(Sx_k Z \hbar^{L-k})}{\vartheta(Z \hbar^{L-k})} \prod_{i > k} \vartheta(Sx_i \hbar^{-1}), \tag{6.141}$$

and rewrite S<sup>l</sup> as

$$\mathbf{S}_{l} = \frac{\prod_{a \neq b} \vartheta(s_{b} s_{a}^{-1} \hbar)}{\prod_{i,a} \vartheta(s_{a} x_{i} \hbar^{-1/2})} \times \operatorname{Symm}_{S_{N}} \frac{\prod_{a=1}^{N} f_{l(a)}(s_{a} \hbar^{1/2}, z \hbar^{-\frac{L}{2} - 2\rho_{a}})}{\prod_{a < b} \vartheta(s_{a} s_{b}^{-1}) \vartheta(s_{a} s_{b}^{-1} \hbar)}.$$
 (6.142)

The second factor exactly agrees with the elliptic stable envelope Stab(l) from [\[52\]](#page-141-2), once we perform the same rescalings as in the T <sup>∗</sup>CP n−1 case:

<span id="page-116-0"></span>
$$s_a \hbar^{1/2} \mapsto s_a, \quad z \hbar^{-\frac{L}{2}} \mapsto z,$$
 (6.143)

and then replace ~ by ~ −1 .

The first factor in [\(6.142\)](#page-116-0) is a Weyl-invariant combination that must be attributed to the difference in normalizations of the pole-subtraction matrix P<sup>C</sup> and Stab(l). To find the overlap [\(6.61\)](#page-98-1), i.e., the matrix element of the interface between the vacuum l on the massive side and l <sup>0</sup> on the massless, we have to substitute s = s (l 0 ) from [\(6.126\)](#page-114-0) into [\(6.142\)](#page-116-0).

#### <span id="page-117-0"></span>6.5.4 Hilbert scheme of points

In this section we use the notations W ∼= C 1 , N ∼= C <sup>N</sup> for the flavor and color spaces, respectively. The Hilbert scheme M<sup>N</sup> ≡ Hilb[N] (C 2 ) of N points on C 2 is the the Higgs branch of the U(N) gauge theory with 1 fundamental hypermultiplet (I, J), I : W → N, J : N → W, and one adjoint hypermultiplet (B1, B2), B1,<sup>2</sup> ∈ End(N):

![](_page_117_Picture_4.jpeg)

The N = 4 flavor group is A = U(1) acting on the adjoint hypermultiplet only, so the N = 2 flavor group is U(1)<sup>~</sup> × U(1). The F-term equation reads

<span id="page-117-1"></span>
$$IJ + [B_1, B_2] = 0, (6.144)$$

while the D-term equation reads:

<span id="page-117-2"></span>
$$II^{\dagger} - J^{\dagger}J + [B_1, B_1^{\dagger}] + [B_2, B_2^{\dagger}] = \zeta \mathbf{1_N},$$
 (6.145)

Unlike the previous example, we only have two equivariant parameters x and ~, and just one mass m. It is well-known [\[172\]](#page-150-11) that for ζ > 0 the Eqs. [\(6.144\)](#page-117-1), [\(6.145\)](#page-117-2) imply J = 0. We henceforth work in the chambers:

$$\mathfrak{C} = \{m > 0\}, \qquad \mathfrak{C}' = \{\zeta > 0\}. \tag{6.146}$$

The A-fixed points p<sup>λ</sup> ∈ M<sup>A</sup> <sup>N</sup> are in one-to-one correspondence with the partitions λ, of size |λ| = N, i.e.

$$\lambda = \left[ \lambda_1 \ge \lambda_2 \ge \dots \ge \lambda_{\ell(\lambda)} \right] , \tag{6.147}$$

with

$$N = \lambda_1 + \lambda_2 + \ldots + \lambda_{\ell(\lambda)} . \tag{6.148}$$

We shall also use the dual partition  $\lambda^t$ , with  $\lambda_j^t = \#\{i \mid 1 \leq i, \lambda_i \geq j\}$ . The fixed point equations read,

<span id="page-118-0"></span>
$$mB_1 = [\sigma_{\lambda}, B_1], -mB_2 = [\sigma_{\lambda}, B_2], \ \sigma_{\lambda}I = 0, \ J\sigma_{\lambda} = 0$$
 (6.149)

We cannot solve (6.144), (6.145), (6.149) modulo U(N), but we can solve (6.144) and (6.149) modulo GL(N), and here is the result: there is an orthonormal basis  $\mathbf{e}_{(i,j)}$  of  $\mathbf{N}$ , with  $(i,j) \in \lambda$ , i.e.  $1 \leq i \leq \ell(\lambda)$ ,  $1 \leq j \leq \lambda_i$ , in which

$$B_{1}\mathbf{e}_{(i,j)} = \sqrt{\zeta \frac{h_{i+1,j}}{h_{i,j}}} \mathbf{e}_{(i+1,j)}, \ B_{2}\mathbf{e}_{(i,j)} = \sqrt{\zeta \frac{h_{i,j+1}}{h_{i,j}}} \mathbf{e}_{(i,j+1)}, \ I(\mathbf{W}) = \sqrt{N\zeta} \mathbf{e}_{(1,1)} \quad (6.150)$$

where the real numbers  $h_{i,j}$  obey [173] the system of quadratic equations:

<span id="page-118-1"></span>
$$\frac{h_{i,j}}{h_{i-1,j}} - \frac{h_{i+1,j}}{h_{i,j}} + \frac{h_{i,j}}{h_{i,j-1}} - \frac{h_{i,j+1}}{h_{i,j}} + N\delta_{i,1}\delta_{j,1} = 1, \ (i,j) \in \lambda$$
 (6.151)

supplemented with the boundary conditions  $h_{i,j} = +\infty$  when either i = 0 or j = 0,  $h_{1,1} = 1$ , and  $h_{i,j} = 0$  when  $j > \lambda_i$ , or  $i > \lambda_j^t$ . The equations (6.151) have a unique solution, the critical point of a convex Morse function of  $h_{i,j}$ 's.

The scalar  $\sigma$  in the vector multiplet takes the value

<span id="page-118-2"></span>
$$\sigma^{(p_{\lambda})} = \sum_{(i,j)\in\lambda} m(i-j) \mathbf{e}_{i,j} \mathbf{e}_{i,j}^{\dagger}$$
(6.152)

The tangent space  $T_{p_{\lambda}}M_{N}$  has a basis  $\left(\delta_{i,j}^{\pm}B_{1},\delta_{i,j}^{\pm}B_{2},\delta_{i,j}^{\pm}I,\delta_{i,j}^{\pm}J\right)$ , where  $(i,j) \in \lambda$  with the corresponding hypermultiplets having the mass  $m\left(\lambda_{i}-j+\lambda_{j}^{t}-i+1\right)$  (the hook formula). The corresponding equivariant weights are (the arm-leg formula)

<span id="page-118-3"></span>
$$x^{\pm \left(\lambda_i - j + \lambda_j^t - i + 1\right)} \hbar^{\frac{1}{2} \pm \frac{\lambda_i - j - \lambda_j^t + i}{2}}, \tag{6.153}$$

which are computed from the character

<span id="page-118-4"></span>
$$\chi_{T_{p_{\lambda}}}(q_1, q_2) = K^* + q_1 q_2 K - (1 - q_1)(1 - q_2) K K^*$$
(6.154)

with

$$K(q_1, q_2) = \sum_{(i,j)\in\lambda} q_1^{i-1} q_2^{j-1}, \ K^*(q_1, q_2) = K(q_1^{-1}, q_2^{-1})$$
(6.155)

using the representation of the tangent space as a cohomology of a three-term equivariant complex [\[172\]](#page-150-11), or by direct examination of the linearized equations and symmetries. The unbroken gauge group G<sup>p</sup><sup>λ</sup> ⊂ U(N) is the centralizer of σ (pλ) in [\(6.152\)](#page-118-2), i.e.

<span id="page-119-1"></span>
$$G_{p_{\lambda}} = \prod_{h=-\infty}^{\infty} U(n_{h,\lambda}) \tag{6.156}$$

where

$$n_{h,\lambda} = \# \mathcal{I}_{h,\lambda}, \qquad \mathcal{I}_{h,\lambda} = \{ i \mid i - \lambda_i \le h \le i - 1 \}$$

$$(6.157)$$

The ranks nh,λ can be read off the reduced character

<span id="page-119-0"></span>
$$\kappa(x) = K(x, x^{-1}) = \sum_{h} n_{h,\lambda} x^{h}$$
(6.158)

It is easy to see that Ih,λ ⊂ Ih∓1,λ for ±h ≥ 1, hence the dimensions nh,λ are non-increasing in both positive and negative h directions.

It is also easy to see from [\(6.153\)](#page-118-3) that the reduced character of the tangent space

$$\tau_{\lambda}(x) = \chi_{T_{p_{\lambda}}}(x, x^{-1}) = \sum_{\Box \in \lambda} x^{h_{\Box}} + x^{-h_{\Box}}$$
(6.159)

does not have a constant term: [x 0 ]τλ(x) = 0. Therefore (cf. [\(6.154\)](#page-118-4)):

$$\left(\kappa(x) - \kappa(x)\kappa(x^{-1})(1-x)\right)_0 = -\left(\kappa(x^{-1}) - \kappa(x)\kappa(x^{-1})(1-x^{-1})\right)_0 = 0 \tag{6.160}$$

Now plug into this the relation [\(6.158\)](#page-119-0) to conclude

<span id="page-119-2"></span>
$$n_0 + \sum_h n_h n_{h+1} = \sum_h n_h^2 \tag{6.161}$$

In addition to the vector multiplets for the gauge group [\(6.156\)](#page-119-1), the light degrees of freedom associated to the vacuum λ include: A bunch of bi-fundamental hypermultiplets originating from the massless components of B<sup>1</sup> and B2, and a fundamental hypermultiplet for the group U(n0) originating from the (i, i) ∈ λ componenets of (I, J) (because (I, J) only get masses from the vev of σ (pλ) , whose (i, i) components vanish). The massless components of B<sup>1</sup> and B<sup>2</sup> only couple the adjacent blocks of the block-diagonal matrices in Q <sup>h</sup> U(nh) ⊂ U(N), and together, the light fields assemble into the quiver that defines T C λ :

![](_page_120_Picture_0.jpeg)

where we have indicated that the very first and last non-zero n<sup>h</sup> ≡ nh,λ are both 1. This theory has `(λ) + λ<sup>1</sup> − 1 FI parameters and the same number of topological symmetries, but due to its origin as a light subsector in the ADHM quiver, all FI parameters should be equal to ζ, and all the topological symmetries should have the same fugacity z. By construction, there is only one Higgs branch vacuum, and the equality [\(6.161\)](#page-119-2) confirms that the dimensionality counting is in agreement with that.

As per usual story, the massive matter is organized into the spaces R±(λ) depending on the sign of real mass, and given Dirichlet/Neumann boundary conditions at the T |T <sup>C</sup> λ interface. Defining the B<sup>L</sup>,λ boundary conditions follows the standard route, except the scenario mentioned in the footnote [5](#page-43-1) takes place in this case, with some of the massless hypermultiplets in the ADHM quiver remaining at zero vev. This is easiest to see for I: the whole n0-component subvector of I (fundamental under the U(n0)) remains massless, but in the description of fixed points given above, only the (1, 1) ∈ λ component of I is non-zero. The same occurs for B1,2. This is not really a problem, and it is still possible to choose boundary conditions for such components consistent with the requirement that the U(N) symmetry is fully broken at the B<sup>L</sup>,λ boundary.

The definition of N<sup>λ</sup> boundary conditions becomes more subtle. If we follow the standard route here, we will end up in the situation mentioned in the Remark towards the end of Section [6.3.](#page-92-0) Namely, the N<sup>p</sup> boundary conditions appear to explicitly break the gauge symmetry, even thought the Neumann boundary conditions on the gauge fields require its presence. As explained there, the way out is to impose the (0, 2) Neumann boundary conditions on all the chiral multiplets that constitute the matter content of our quiver theory T C λ . This, on the other hand, produces the boundary gauge anomaly, which has to be canceled by the boundary theory Υλ. As usual, we have to make sure that hNλ|Dλi = 1, which does not entirely fix the normalization, and leaves a meromorphic elliptic ambiguity.

We thus see that our method also works straightforwardly, with very minor adjustments, in the case of Hilbert scheme of points. This is unlike the abelianization approach [\[52\]](#page-141-2), which becomes significantly more involved, since the abelianization of Hilb[N] (C 2 ) is a hypertoric variety with non-isolated A-fixed points. These difficulties were overcome by Smirnov in [\[85\]](#page-143-7). We will complete the computations for Hilb[N] (C 2 ) elsewhere, but to make them really useful, we would have to come up with a way to fix the elliptic ambiguity in the definition of |Nλi. Only then it would be possible to compare results with the sum over trees in [\[85\]](#page-143-7).

### <span id="page-121-0"></span>7 Outlook

In this paper we gave a physical interpretation of the stable envelope StabC(X) constructions of [\[51,](#page-141-1) [52\]](#page-141-2). We realized them as the interfaces in softly broken N = 4 3d quiver gauge theories, which have X as their Higgs branches, which preserve a fraction of supersymmetry, while having some mass/FI parameters varying in time. One can also consider the domain walls, where the masses vary along some spatial direction. These are more familiar as the supersymmetric boundary conditions in the folded theories. The advantage of time varying masses is that they act as operators in the space of states. The supersymmetry preserving interfaces define operators acting on the space of supersymmetric vacua. In this paper we are only interested in the cohomology of one of the supercharges Q. So, at times, we take the limit, in which the masses change in a quench-like manner, which we relate to Dirichlet and Neumann boundary conditions on the supermultiplets at the interface wall. In string theory brane realizations, these limits correspond to taking some of the nearly parallel flavor branes and rotating them to nearly 90 degrees, obtaining essentially the intersecting branes configuration, with one stack of branes producing interfaces on the worldvolumes of another stack. Some representatives of the Q-cohomology might be more convenient to work with then others. In this respect it would be interesting to generalize the recent work [\[174\]](#page-151-1) on the renormalization group flows on line defects in conformal field theories to the case of supersymmetric interfaces (our theories flow to superconformal fixed points both for vanishing and infinite masses). Additionally, it would be interesting to put the study of supersymmetric interfaces and boundary conditions in perspective of the paper [\[175\]](#page-151-2), and understand whether there can exist any subtle obstructions for the SUSY at the boundary.

The equivariant cohomology (K-theory, elliptic cohomology) of the fixed point set X<sup>A</sup> in [\[51,](#page-141-1)[52\]](#page-141-2) corresponds to the space of supersymmetric vacua of the theory with real masses, which asymptote to infinity along a ray within a chamber C in Lie(A). The equivariance is achieved by turning on a flat flavor (including U(1)~) connection along the two-torus in the case of a compactified 3d theory, or the appropriate combination of a flat connection and a twisted mass in 2d or 1d reductions. The equivariant cohomology (K-theory, elliptic cohomology) of X is identified with the space of supersymmetric vacua of the theory with vanishing real masses, while keeping the same flat flavor (including U(1)~) connection along the two-torus in the case of a compactified 3d theory, or the appropriate combination of a flat connection and a twisted mass in 2d or 1d reductions. The stable envelope map is then the operator induced by the supersymmetric interface on the space of supersymmetric vacua. Mathematically, these are the harmonic representatives of Q-cohomology, for some of the nilpotent (up to the global symmetry corresponding to the equivariance) supercharges Q.

In the companion papers we shall be exploring the backgrounds changing the nature of Q, from the A-model supercharge to our supercharge, and their lifts to three dimensions, as well as their Ω-deformed versions. Namely, we will study the cigar background that is the 3d uplift of the Gomis-Lee [\[176\]](#page-151-3) squashed sphere background, which thus preserves two supercharges. This 3d background is the squashed version of the usual 3d N = 2 background used in the study of 3d index [\[177\]](#page-151-4) and half-index [\[62\]](#page-142-8). One can prove using the methods of [\[178–](#page-151-5) [180\]](#page-151-6) that the squashing parameter is a trivial deformation of the transversally holomorphic foliation (THF), thereby allowing to take the infinite squashing limit without affecting the BPS observables. Taking this limit connects the half-index to the topologically twisted half-index, known in the literature under a variety of names [\[123,](#page-147-0) [181–](#page-151-7)[186\]](#page-152-0). The tradition seems to be that each author comes up with a new name for this object, which we thus unconventionally called the "topologically twisted index" above (in the part II, however, we will mention all the known names). An interesting relation between this object and our interfaces is that one can change parameters of the theory on the cigar by acting with the Janus interface on its boundary, see Figure [7.](#page-121-0)

![](_page_122_Picture_2.jpeg)

Figure 8: Acting with an interface on the cigar partition function.

Thus, our interfaces encode the behavior of the cigar partition function under the transition between the Higgs and Coulomb phases (the duality interface), or in the massive case, under the wall-crossing between the chambers C<sup>1</sup> and C<sup>2</sup> (the chamber R-matrices [\[51,](#page-141-1) [52\]](#page-141-2), to be discussed in part III).

We shall also consider the generalizations of our interfaces where some of the masses are replaced by the flavor flat connection. It is in this compactified (or T-dualized) setup, that we shall find the connection between the twisted transfer matrices and the local operators of the twisted chiral ring, earlier observed as the Bethe/gauge correspondence. We shall also connect our interfaces to the arrangements of line operators in the four dimensional Chern-Simons theory, in the case of a finite ADE quiver gauge theory. Of course, our constructions work for more general quiver theories, for which the corresponding 4d Chern-Simons is not fully understood (but string theory considerations suggest a higher dimensional theory [\[187\]](#page-152-1)).

Another extension of our work is the study of the analogous interfaces in theories, which start their life as higher dimensional ones, 5d/4d/3d, subject to an Ω-deformation in two noncompact directions D<sup>2</sup> (which could be taken to have a cigar geometry). These theories are not sigma models with some finite dimensional target space X, rather they share many common features with a would-be sigma model with an infinite-dimensional target space. Thus, the quiver N = 2 theories in four dimensions and their five dimensional uplifts would be related to the spin chains with infinite dimensional representations of the Lie algebra of the MacKay dual group at the spin sites [\[188–](#page-152-2)[191\]](#page-152-3). The rˆole of the U(1)<sup>~</sup> symmetry is played by the rotations of D<sup>2</sup> , so the Planck constant of the quiver spin chain is the Ω-deformation parameter, in agreement with [\[34\]](#page-139-9). The novelty of this class of theories compared to the gauged linear sigma models considered in this paper is the complex spin of the associated representations of quantum algebras. In the A<sup>1</sup> case, considered in detail in the recent papers [\[190,](#page-152-4) [191\]](#page-152-3), the 2N masses of quarks in the N = 2 SU(N) gauge theory in four dimensions determine the N inhomogeneities, and N (complex) spins of the sl<sup>2</sup> XXX-spin chain, governing the BPS sector of the Ω-deformed theory.[26](#page-123-0) To compare to the construction of the present paper, we should start with the 3d reduction of that theory, and use the m<sup>R</sup> component of the mass vector ~m = (mR, mC, mC) to define the Janus interfaces, while keeping the "equivariant" masses m<sup>C</sup> constant across the defect. The 4d theory would correspond to the models with twisted transfer matrix (the twist determined by the complexified gauge coupling), to be analyzed in the part III of our series.

We should also point out that some of our models can be mirror mapped to the N = 2

<span id="page-123-0"></span><sup>26</sup>Transfer matrices labeled by the complex spins of sl2, but in the XXX spin chain with the usual spin 1/2 at each site, have also appeared in [\[192\]](#page-152-5), in a seemingly quite different context, but in exactly the same SU(N), N<sup>f</sup> = 2N gauge theory, this time with a codimension-one defect inserted. In that case, it is also true that inhomogeneities and the complex spins of representations of the auxiliary space are determined by the 2N masses. The physical space of the spin chain realized in gauge theory can also be the usual Verma modules of sl2, as in [\[193\]](#page-152-6), or the unbounded modules found in [\[190,](#page-152-4) [191\]](#page-152-3), which depend on the additional N Coulomb moduli.

Landau-Ginzburg theories in two dimensions. The interfaces in these theories and the ∞ structures they define were extensively studied in [\[194,](#page-152-7)[195\]](#page-152-8). It seems interesting to find the corresponding quantum algebra generalizing the Yangians and quantum loop algebras (for 3d uplifts of those models) for Landau-Ginzburg theories. Conversely, the Yangian might uplift to some L∞-structure, with the inclusion of junctions of Janus interfaces of our paper.

## <span id="page-124-0"></span>A 3d N = 2 conventions

#### <span id="page-124-1"></span>A.1 Flat space

We choose the Euclidean gamma matrices to be given by Pauli matrices τµ:

$$\gamma_{\mu} = \tau_{\mu}, \quad \mu = 1, 2, 3.$$
 (A.1)

Spinors are by default assumed to have lower indices, which can be raised according to

$$\psi^{\alpha} = \varepsilon^{\alpha\beta}\psi_{\beta},\tag{A.2}$$

where ε <sup>12</sup> = ε<sup>21</sup> = 1. As usual, the contractions work as

$$\psi \chi = \psi^{\alpha} \chi_{\alpha}. \tag{A.3}$$

A 3d N = 2 gauge theory is built from two types of multipelts: 1) A gauge or vector multiplet V = (Aµ, σ, λ, λ, D), where σ is a real scalar, (λ, λ) is a Dirac spinor, and D is a real auxiliary field; 2) A chiral multiplet Φ = (φ, ψ, ψ, F), where φ is a complex scalar, (ψ, ψ) a Dirac spinor, and F a complex auxiliary field. Note that Φ and φ are just generic names in this appendix, which should not be confused with the specific adjoint-valued chiral Φ that enters the construction of 3d N = 4 theories in the main text.

In flat Euclidean space, the SUSY transformations are parameterized by a pair

$$\epsilon = \begin{pmatrix} \epsilon_1 \\ \epsilon_2 \end{pmatrix}, \quad \overline{\epsilon} = \begin{pmatrix} \overline{\epsilon}_1 \\ \overline{\epsilon}_2 \end{pmatrix},$$
(A.4)

which contain four independent infinitesimal parameters. Upon Wick rotation to Minkowski signature, and should be thought of as complex spinors related to each other by a proper conjugation operation. We find it more convenient to treat , as commuting spinors. The SUSY variations of the vector multiplet are given by the following equations:

$$\delta A_{\mu} = \frac{\mathrm{i}}{2} (\overline{\epsilon} \gamma_{\mu} \lambda + \epsilon \gamma_{\mu} \overline{\lambda})$$

$$\delta \sigma = \frac{1}{2} (\overline{\epsilon} \lambda - \epsilon \overline{\lambda})$$

$$\delta \lambda = -\frac{1}{2} F_{\mu\nu} \gamma^{\mu\nu} \epsilon - D\epsilon + \mathrm{i} D_{\mu} \sigma \gamma^{\mu} \epsilon$$

$$\delta \overline{\lambda} = -\frac{1}{2} F_{\mu\nu} \gamma^{\mu\nu} \overline{\epsilon} + D\overline{\epsilon} - \mathrm{i} D_{\mu} \sigma \gamma^{\mu} \overline{\epsilon}$$

$$\delta D = \frac{\mathrm{i}}{2} \left( -\overline{\epsilon} \gamma^{\mu} D_{\mu} \lambda + \epsilon \gamma^{\mu} D_{\mu} \overline{\lambda} + \overline{\epsilon} [\lambda, \sigma] + \epsilon [\overline{\lambda}, \sigma] \right) ,$$
(A.5)

and for the chiral multiplet, they are:

$$\delta \phi = \overline{\epsilon} \psi 
\delta \overline{\phi} = \epsilon \overline{\psi} 
\delta \psi = i \gamma^{\mu} \epsilon D_{\mu} \phi + i \epsilon \sigma \phi + \overline{\epsilon} F 
\delta \overline{\psi} = i \gamma^{\mu} \overline{\epsilon} D_{\mu} \overline{\phi} + i \overline{\phi} \sigma \overline{\epsilon} + \overline{F} \epsilon 
\delta F = i \epsilon \left( \gamma^{\mu} D_{\mu} \psi - \sigma \psi - \lambda \phi \right) 
\delta \overline{F} = i \overline{\epsilon} \left( \gamma^{\mu} D_{\mu} \overline{\psi} - \overline{\psi} \sigma + \overline{\phi} \overline{\lambda} \right) .$$
(A.6)

The invariant actions are

$$\mathcal{L}_{v} = \operatorname{Tr}\left[\frac{1}{2}F^{\mu\nu}F_{\mu\nu} + D^{\mu}\sigma D_{\mu}\sigma + D^{2} - \epsilon^{\mu\nu\rho}F_{\mu\nu}D_{\rho}\sigma\right] + \operatorname{iTr}\left[\lambda\gamma^{\mu}D_{\mu}\overline{\lambda} + \lambda[\overline{\lambda},\sigma]\right], \quad (A.7)$$

$$\mathcal{L}_{c} = -\overline{\phi}D^{\mu}D_{\mu}\phi + \overline{\phi}\sigma^{2}\phi + i\overline{\phi}D\phi + \overline{F}F - i\overline{\psi}\gamma^{\mu}D_{\mu}\psi + i\overline{\psi}\sigma\psi + i\overline{\psi}\lambda\phi - i\overline{\phi}\overline{\lambda}\psi. \tag{A.8}$$

Additionally, one can have an FI term iTr (ζD), and a superpotential term:

$$\mathcal{L}_{W} = F \frac{\partial W(\phi)}{\partial \phi} - \overline{F} \frac{\partial \overline{W}(\overline{\phi})}{\partial \overline{\phi}} - \frac{\partial^{2} W(\phi)}{\partial \phi \partial \phi} \psi \psi + \frac{\partial^{2} \overline{W}(\overline{\phi})}{\partial \overline{\phi} \partial \overline{\phi}} \overline{\psi \psi}, \tag{A.9}$$

where we omitted the obvious index contractions.

#### <span id="page-126-0"></span>A.2 Localizing deformations in flat space

For references, we also list the flat space localization equations here. They follow from the various Q-exact deformations used in the literature, which we skip for brevity.

The Coulomb branch localization. The BPS equations for Q in the Coulomb branch localization scheme [\[177\]](#page-151-4) look as follows. The 3d N = 2 vector multiplet equations are:

<span id="page-126-1"></span>
$$D = 0, \quad D_{\mu}\sigma = 0, \quad F_{\mu\nu} = 0.$$
 (A.10)

The 3d N = 2 chiral multiplet equations depend on whether we include the superpotential into the localizing deformation. If we do not, we get:

<span id="page-126-2"></span>
$$F = \overline{F} = 0, \quad D_{\alpha}\phi = D_{\varphi}\phi = 0,$$
  

$$(D_y + \widehat{\sigma})\phi = 0,$$
(A.11)

where as before, <sup>σ</sup><sup>b</sup> <sup>=</sup> <sup>σ</sup> <sup>+</sup>m. If we include superpotential in the localization, we find instead:

$$F = e^{-i\nu} \overline{\partial W}, \quad \overline{F} = e^{i\nu} \partial W,$$

$$D_{\alpha} \phi = D_{\varphi} \phi = 0,$$

$$(D_y + \widehat{\sigma}) \phi - i e^{-i\nu} \overline{\partial W} = 0.$$
(A.12)

In the N = 4 case, it is possible to further simplify this, if we fix vacua at y = ±∞ (or the appropriate boundary conditions, if we are on a half-line or on the interval). In this case both ∂W and W vanish at the two infinities, and we can argue that the equations become:

$$F = \overline{F} = \partial W = \overline{\partial W} = 0,$$

$$D_{\alpha}\phi = D_{\varphi}\phi = 0,$$

$$(D_{y} + \widehat{\sigma})\phi = 0.$$
(A.13)

The Higgs branch localization. Working in the Higgs branch localization scheme [\[196\]](#page-152-9) does not affect the matter BPS equations: there are still two options described above. The vector multipelt equations do modify. As usual, we use the appropriate Q-exact deformation, integrate out the auxiliary field D, and find:

$$D_{\varphi}\sigma = D_{\alpha}\sigma = 0, \quad F_{\mu\nu} = 0,$$
  
 $H(\phi) = D_{y}\sigma,$  (A.14)

where one normally writes:

$$H(\phi) = e^2 \mu_{\mathbb{R}}.\tag{A.15}$$

#### <span id="page-127-0"></span>A.3 Interval partition function

In this paper, partition functions of 3d N = 2 theories on E<sup>τ</sup> × I play some role, where I = (0, y0) is an interval. At each boundary, we either fix Dirichlet or Neumann boundary conditions for the gauge fields, and the hypermultiplets are given some (2, 2) boundary conditions determined by the complex Lagrangian L, as in Section [2.1.](#page-9-1) The partition function can be computed using the localization.

• Neumann-Neumann case. Interval partition functions with the Neumann boundary conditions on the vector multiplets at both ends were discussed in [\[167\]](#page-150-6). In this case, we are not allowed to give any boundary vevs to the hypers, as they are inconsistent with gauge invariance. It is most convenient to use the Coulomb branch localization scheme that does not involve the superpotential, i.e., the BPS equations are [\(A.10\)](#page-126-1) and [\(A.11\)](#page-126-2). The gauge field is flat on the localization locus, and the A<sup>y</sup> components can be gauged away, so one simply obtains a flat connection on E<sup>τ</sup> . For each multiplet, the 1-loop determinants of non-zero modes on the interval cancel out between bosons and fermions. Only the interval zero modes contribute, which is of course consistent with the answer being independent of the length y<sup>0</sup> of the interval.

The problem thus effectively reduces to the 2d computation of [\[138,](#page-148-2) [140\]](#page-148-3). Chiral multiplets with Dirichlet boundary conditions on the one end and Neumann on the other have no zero modes. A chiral multiplet valued in R with Dirichlet on both ends leads to a 2d (0, 2) Fermi multiplet valued in R. In the case of Neumann boundary conditions on both ends, the zero mode is described by a 2d (0, 2) chiral in R. One simply multiplies the 2d one-loop determinants of these zero modes, and includes the one-loop determinants of the boundary matter, if present. After that, one computes the Jeffrey-Kirwan residues of the resulting expression. The reader should consult original papers mentioend above for more details on this.

• Neumann-Dirichlet. If one of the ends (let us say it is y = 0) supports Dirichlet boundary conditions for the gauge fields, the computation becomes somewhat simpler. At the same time, we are allowed to turn on non-trivial boundary vevs at the Dirichlet end, since this is not prohibited by gauge invariance. In general, we fix a boundary flat connection at the Dirichlet end:

$$A_{\parallel}\big|_{u=0} = s. \tag{A.16}$$

By the localization equations (A.10), the gauge field is flat everywhere, hence now we simply have a constant flat connection  $s \in \text{Hom}(\pi_1(\mathbb{E}_{\tau}), G)/G$  everywhere on  $\mathbb{E}_{\tau} \times I$ . In particular, there is no need to integrate over s and/or take JK residues. If a chiral multiplet obeys Dirichlet boundary conditions at y = 0, we can generalize it to

$$\phi\big|_{y=0} = c, \tag{A.17}$$

for some constant c. If it obeys Neumann conditions at the other end,

$$\partial_y \phi \big|_{y=y_0} = 0, \tag{A.18}$$

then the BPS equation  $(D_y + \hat{\sigma})\phi = 0$  has a solution. No interval zero modes survives (this is always the case when we have Neumann and Dirichlet on the opposite ends), and this multiplet does not contribute to the one-loop determinant. On the other hand, if it obeys Dirichlet boundary conditions at the other end,

$$\phi\big|_{y=y_0} = 0, \tag{A.19}$$

then the equation  $(D_y + \widehat{\sigma})\phi = 0$  has no solutions, as this is inconsistent with  $\phi|_{y=0} \neq 0$ . To be more precise, such solution could be found "at infinity", for infinite  $\widehat{\sigma}$ , but the value of  $\sigma$ , and hence also  $\widehat{\sigma} = \sigma + m$ , is fixed by the boundary conditions for the vector multiplet. Indeed, the (2,2) Neumann boundary conditions fix the boundary value of  $\sigma$ , and the BPS equations (A.10) further imply that in the Coulomb branch localization,  $\sigma$  is constant.

Thus we see that when  $\phi|_{y=0} \neq 0$  and  $\phi|_{y=y_0} = 0$ , the BPS equations have no solutions. This implies that the interval partition function simply vanishes, meaning that the inner product of the regularized boundary states is zero. This can also be phrased as a spontaneous SUSY breaking: the Hilbert space on  $S^1 \times I$  with chosen boundary

conditions at the endpoints has no SUSY vacuum.

In case the answer is non-zero (i.e. BPS equations have solutions,) to compute the interval partition function, we simply collect contributions of those multiplets that have zero modes, and also include contributions of the possible boundary matter. The vector multiplet leaves no zero modes, and simply provides a background flat connection s. Each  $\mathcal{R}$ -valued chiral obeying Dirichlet with zero boundary vevs,

$$\phi|_{y=0} = \phi|_{y=y_0} = 0,$$
 (A.20)

contributes a (0,2) Fermi multiplet in  $\overline{\mathcal{R}}$ , and its one-loop determinant is taken as in 2d, see equations (3.63) in the main text. If a chiral obeys Neumann boundary conditions on both ends, it contributes a (0,2) chiral in  $\mathcal{R}$ , and its one-loop determinant is again as in 2d, see (3.63). Including contributions of the boundary matter, we get schematically:

$$Z_{\mathbb{E}_{\tau} \times I} = \prod_{(w,f) \in L_1 \cap L_2} Z_{\mathcal{F}}(s^w x^f, q) \prod_{(w,f) \in L_1^{\perp} \cap L_2^{\perp}} Z_{\mathcal{C}h}(s^w x^f, q) \times Z_{\text{boundary}}, \tag{A.21}$$

where (w, f) are gauge and flavor weights,  $L_1 \cap L_2$  denotes those weights that obey Dirichlet conditions on both boundaries,  $L_1^{\perp} \cap L_2^{\perp}$  – Neumann; and  $Z_{\text{boundary}}$  denotes contributions from the boundary chiral and Fermi multiplets.

• Dirichlet-Dirichlet. If we impose the (2,2) Dirichlet boundary conditions on the gauge multiplets on both ends that involve no boundary vevs for matter, we get a bosonic zero mode from  $\sigma+iA_y$ . The corresponding partition function diverges. Turning on the appropriate boundary vevs for hypermultiplets can resolve this issue, and the minimal such vevs lead to the exceptional Dirichlet boundary conditions of [88].

Once the  $\sigma$  zero mode issue is resolved by the boundary vevs, we can attempt to compute the partition function. It has a perturbative part, whose computation is straightforward and follows the above recipe: the gauge field is flat on the localization locus (and thus  $A_{\parallel}|=s$  should be the same at both ends), and we simply quantify the interval zero modes and their one-loop determinants, whose functional form is again as in (3.63). In this case the gauge multipelt also contributes zero modes: an adjoint (0,2) chiral S and an adjoint Fermi  $\Psi_{\Phi}$ .

Additionally, there are non-perturbative contributions corresponding to the possibility that  $A_{\parallel}|_{y=0}$  and  $A_{\parallel}|_{y=y_0}$  differ by a large gauge transformation (and so there is no

global trivialization on E<sup>τ</sup> × I, throughout which the gauge field remains flat). We do not analyze this, and leave it as an open question for the future. For this reason, we make sure that explicit computations in this paper do not rely on precises expressions for the Dirichlet-Dirichlet partition functions.

### <span id="page-130-0"></span>B Boundary conditions and boundary states

When we are in the Euclidean signature, we do not distinguish boundary and initial conditions: one can always treat the direction normal to the boundary as time, and view the boundary condition B as the initial condition preparing some state |Bi. Local boundary conditions B and their corresponding boundary states |Bi play some role in this paper, so let us pause to discuss some of their properties.

The boundary conditions are generally required to be elliptic, meaning that the kinetic differential operators for various fields remain elliptic in their presence (or transversally elliptic in the gauged case). This allows to avoid various pathologies, such as infinite number of zero modes, that make perturbation theory ill defined. Such boundary conditions also correspond, in a certain sense, to "good" boundary states. Namely, while the state |Bi itself is usually highly singular and does not belong to the conventional Hilbert space (being an unnormalizable infinite linear combination of states of infinitely high energy), the "regularized state"

$$e^{-TH}|\mathcal{B}\rangle,$$
 (B.1)

where H is the Hamiltonian, sometimes lands in the physical Hilbert space. The unphysical (infinite-energy) part gets suppressed by the Euclidean evolution operator. In order for this to happen, roughly, two things must hold: the Hamiltonian must be sufficiently positive definite (so that e <sup>−</sup>T H is capable of killing the "bad" part of |Bi); and |Bi must have some "good" part in it, so that e <sup>−</sup>T H|Bi is not just zero. Let us briefly discuss this issue in a couple of examples, and make a semi-general proposal that elliptic boundary conditions lead to physically sensible regularized boundary states e <sup>−</sup>T H|Bi.

#### <span id="page-130-1"></span>B.1 Bosonic fields

We start with bosons, and in this case, the most important requirement is the positivity of H. The simplest case when it is not positive is the topological quantum mechanics with

$$H=0$$
:

$$S = \int p \mathrm{d}q. \tag{B.2}$$

Consider the boundary conditions q|=x in such a theory, and look at the interval partition function with  $q=x_1$  and  $q=x_2$  on the two ends. The Euclidean (or Lorentzian) interval partition function is  $\langle x_1|e^{-TH}|x_2\rangle=\langle x_1|x_2\rangle=\delta(x_1-x_2)$ . No matter what the length T of the interval is, the wave function  $\delta(x_1-x_2)$  is never  $L^2$ -normalizable. It is delta-function normalizable, of course, but this simple example illustrates what could go wrong in more general cases.

If we instead take  $H = \frac{1}{2}p^2$ , i.e., look at the free particle, then the boundary state  $|\mathcal{B}\rangle = |x\rangle$  is known to be better behaved. Indeed, the finite-time Euclidean evolution makes it  $L^2$ -normalizable:

$$\langle x|e^{-TH}|y\rangle \sim e^{-\frac{(x-y)^2}{2T}}.$$
 (B.3)

Notice that in the Lorentzian time, the exponential would be replaced by a pure phase, and would never become normalizable. Thus the contracting property of  $e^{-TH}$  is indeed crucial here. However, if we took a momentum-P "eigenstate" (a state from the continuous spectrum), that is a boundary state corresponding to the boundary condition

$$\dot{q}|=P,\tag{B.4}$$

then the corresponding boundary state  $|P\rangle$  would never become  $L^2$ -normalizable because

$$\langle x|e^{-TH}|P\rangle = e^{-T\frac{P^2}{2} + iPx}. ag{B.5}$$

The corresponding path integral on the interval, with P fixed at both ends, has a bosonic zero mode rendering the answer infinite. In this theory, the Neumann boundary condition is not as well-behaved: Even with  $e^{-TH}$ , it produces a non- $L^2$  state from the continuous spectrum.

Finally, let us look at the example of the harmonic oscillator. It is defined in terms of the creation-annihilation operators  $[a, a^+] = 1$ , such that the position and the momentum are

$$p = \frac{i}{\sqrt{2}}(a^+ - a), \quad x = \frac{1}{\sqrt{2}}(a^+ + a).$$
 (B.6)

In this case, H has a positive discrete spectrum, which guarantees that essentially any conceivable boundary condition produces a state that becomes  $L^2$  normalizable after a finite-

time Euclidean evolution. In particular, we can express the "position eigenstate" as

$$|x\rangle = e^{-\frac{1}{2}(a^{+})^{2} + x\sqrt{2}a^{+}}|0\rangle,$$
 (B.7)

which is a non-L 2 state. After a time T Euclidean evolution, the state

$$e^{-TH}|x\rangle = e^{-\frac{1}{2}e^{-2T}(a^+)^2 + x\sqrt{2}e^{-T}a^+}|0\rangle$$
 (B.8)

has a finite norm. For simplicity, we can just compute it at x = 0:

$$\left| e^{-TH} | x = 0 \right\rangle \right|^2 = \frac{1}{\sqrt{1 - e^{-4T}}},$$
 (B.9)

which is indeed finite for T > 0, but diverges at T = 0.

We could also work with the holomorphic quantization, in which case a and a <sup>+</sup> are viewed as complex conjugate variables in the path integral, and the a = 0 boundary condition, in fact, immediately produces the ground state |0i, without the need to act with the contraction operators e <sup>−</sup>T H.

The bottom line of this discussion is that for bosonic fields, the usual boundary conditions (such as Dirichlet or Neumann) produce a state (usually unphysical due to the excited infinite-energy modes), which after a finite-time Euclidean evolution, represented by e <sup>−</sup>T H, can become a valid state from the Hilbert space of the theory. This requires the Hamiltonian to be positive definite, and might fail if there is a continuous spectrum. A way to detect whether this property holds is to consider the finite interval partition function: if it diverges, it indicates that the corresponding state is non-L 2 . If the interval partition function is finite, it means the state, acted by e <sup>−</sup>T H, is normalizable. We might also ask whether the state has a non-zero projection onto the ground state (because ultimately, in this paper, we use boundary conditions to mimic ground states). This can be tested by taking the T → ∞ limit of the interval partition function: if it is non-vanishing (up to the zero point energy effect), it means that e <sup>−</sup>T H|Bi projects non-trivially onto the ground state.

In passing to quantum field theory, we assume that this property still holds, at least if the theory only has isolated massive vacua. More generally, if there are some non-isolated vacua with massless excitations, we have to study the interval partition function with the boundary conditions B and "B †" at the endpoints. If it is finite (which usually happens for the elliptic boundary conditions), then the state e <sup>−</sup>T H|Bi is physical. Furthermore, if it does not vanish in the T → ∞ limit (with the zero point energy effect subtracted), then the

boundary state contains a ground state in its expansion.

#### <span id="page-133-0"></span>B.2 Fermionic fields

Because we work with SUSY theories, fermions are always present, but the story we just sketched for bosons turns out to work quite differently for fermions. In quantum mechanics, we could just start with a complex fermion

$$S = \int dt \, \psi^* \dot{\psi}. \tag{B.10}$$

Fields ψ and ψ <sup>∗</sup> are canonically conjugate, so we could just impose a boundary condition:

$$\psi = 0 \implies \text{a boundary state with the wave function } \delta(\psi).$$
 (B.11)

Unlike in the bosonic case, this state is perfectly physical. After all, when we quantize this system, we write

$$[\psi, \psi^*]_+ = i,$$
 (B.12)

and either define a vacuum as ψ|0i = 0, which corresponds to the wave-function δ(ψ) above; or as ψ ∗ |0i = 0, which corresponds to δ(ψ ∗ ). The norm is defined as

$$\int d\psi d\psi^* \, \delta(\psi^*) \delta(\psi) = 1. \tag{B.13}$$

We could also note that the Hilbert space is finite-dimensional, so there is barely any room for the infinite-energy states that plagued the bosonic case.

That said, the trouble begins when we try to generalize this to fermions in d ≥ 2 spacetime dimensions, because such boundary conditions usually do not produce the Dirac's vacuum (in extreme cases, one might end up with a completely empty Dirac's sea). Therefore, the boundary state |Bi might include excitations that have infinite energy relative to the Dirac's state, and the regulator e <sup>−</sup>T H becomes necessary. It might also happen that e <sup>−</sup>T H|Bi is simply zero, – this is the case when |Bi only contains the infinite energy states, and is completely projected out. In the usual language, such boundary conditions are said to be non-elliptic, supporting infinitely many zero modes, and thus leading to zero answer for the path integral.

A sick example. As a simple example, we start with the case where nothing works: a 2d chiral fermion with the action

$$S = \int d^2x \,\overline{\psi}_-(\partial_1 + i\partial_2)\psi_-, \tag{B.14}$$

which is written in the Euclidean signature. For boundary conditions at x <sup>2</sup> = 0, we think of x <sup>2</sup> as the Euclidean time, and ψ−, ψ<sup>−</sup> are the canonically conjugate variables. Naively, one could attempt to impose, for example,

<span id="page-134-0"></span>
$$\psi_{-}\big| = 0. \tag{B.15}$$

This results in the state with the wave functional

$$\delta[\psi_{-}], \tag{B.16}$$

where square brackets signify that this is a "functional" delta, which imposes ψ<sup>−</sup> = 0 at every point of the boundary. One quantizes the Poisson bracket, resulting in:

$$[\psi_{-}(x^1), \overline{\psi}_{-}(y^1)]_{+} = i\delta(x^1 - y^1).$$
 (B.17)

Thinking of modes of ψ<sup>−</sup> as the creation operators, and those of ψ<sup>−</sup> as the annihilation operators, the state, which obviously obeys

$$\psi_{-}\delta[\psi_{-}] = 0, \tag{B.18}$$

is identified as the "wrong" vacuum, the one with the empty Dirac's sea. The excitations due to ψ<sup>−</sup> around this "vacuum" have both negative and positive energy, which is a well-known issue. The correct Dirac's vacuum has all the negative-energy modes filled, and the state δ[ψ−], from this point of view, has the infinite energy. If we define the quantum Hamiltonian H to be such that H = 0 for the Dirac's vacuum (ignoring the zero-point energy, which would cancel in SUSY theories anyways), then

$$e^{-TH}\delta[\psi_{-}] = 0. \tag{B.19}$$

In other words, nothing is left in the physical Hilbert space. This signifies that any partition function with the boundary conditions [\(B.15\)](#page-134-0) is automatically zero. This happens due to zero modes, and indicates that the boundary condition [\(B.15\)](#page-134-0) is not elliptic. This is of course a known issue: chiral fermions do not have any good boundary conditions on their own.

A healthy example. Now consider a Dirac fermion in two dimensions, the action being

$$S = \int d^2x \left[ \overline{\psi}_{-} (\partial_1 + i\partial_2)\psi_{-} - \overline{\psi}_{+} (\partial_1 - i\partial_2)\psi_{+} \right].$$
 (B.20)

The boundary conditions ψ<sup>±</sup>  = 0, or <sup>ψ</sup><sup>±</sup>  = 0, or <sup>ψ</sup><sup>−</sup> <sup>=</sup> <sup>ψ</sup><sup>+</sup>  = 0, or <sup>ψ</sup><sup>−</sup> <sup>=</sup> <sup>ψ</sup><sup>+</sup>  = 0, all would lead to the same pathology as we have just observed, the corresponding states |Bi being unphysical, and e <sup>−</sup>T H|Bi vanishing. But now we have more options, and we can choose instead:

$$(\psi_{+} + \psi_{-}) | = (\overline{\psi}_{+} - \overline{\psi}_{-}) | = 0 \qquad (B \text{ type})$$
(B.21)

or

$$(\psi_{+} + \overline{\psi}_{-})| = (\overline{\psi}_{+} - \psi_{-})| = 0 \qquad (A \text{ type}).$$
(B.22)

Both of these are known to be well-defined boundary conditions, so let us see how the boundary states work out. For simplicity, we will only consider the B case (the A type works the same way).

In Minkowski signature we have i∂<sup>2</sup> = ∂0, and it is straightforward to analyze the Dirac equations in the momentum space, to find the following dispersion relations:

For modes 
$$\psi_{-}(p)$$
,  $\overline{\psi}_{-}(p)$ :  $E=-p$ ,  
For modes  $\psi_{+}(p)$ ,  $\overline{\psi}_{+}(p)$ :  $E=p$ . (B.23)

The physical vacuum |0i is thus killed by the negative-energy modes:

$$\psi_{-}(p)|0\rangle = \overline{\psi}_{-}(p)|0\rangle = \psi_{+}(-p)|0\rangle = \overline{\psi}_{+}(-p)|0\rangle = 0, \text{ for } p > 0,$$
 (B.24)

where the anti-commutation relations are standard, [ψ+(p), ψ+(q)] ∼ δ(p+q), and [ψ−(p), ψ−(q)] ∼ δ(p + q). Now the state |Bi created by the B-type boundary conditions obeys:

$$(\psi_{+}(p) + \psi_{-}(p))|B\rangle = (\overline{\psi}_{+}(p) - \overline{\psi}_{-}(p))|B\rangle$$
$$= (\psi_{+}(-p) + \psi_{-}(-p))|B\rangle = (\overline{\psi}_{+}(-p) - \overline{\psi}_{-}(-p))|B\rangle = 0, \quad \text{for } p > 0.$$
 (B.25)

It is not too hard to find the Bogolyubov transformation that relates the two states:

$$|B\rangle = e^{\int_{p>0} dp \left[\psi_+(p)\overline{\psi}_-(-p) + \psi_-(-p)\overline{\psi}_+(p)\right]} |0\rangle.$$
(B.26)

Thus we see that, predictably, |Bi is an infinite linear combination of states with arbitrarily high energy. However, unlike the sick state δ[ψ−], this linear combination involves the low energy states, including the Dirac's vacuum:

$$|B\rangle = |0\rangle + \dots \tag{B.27}$$

Thus it makes sense to assume that e <sup>−</sup>T H|Bi is a proper physical state.

Ultimately, the test for a boundary state |Bi to give a physically sensible state e <sup>−</sup>T H|Bi is that the interval partition function with the boundary conditions B and B † be finite and non-vanishing (in Euclidean signature). Here the B † involves some proper notion of Hermitian conjugation, which we deliberately leave undefined. In this paper, we apply this to supersymmetric theories in three, two, and one dimensions, with the N = (0, 2) boundary conditions in 3d, and their reductions in 2d and 1d. All our boundary conditions have the nice properties describes above (in particular, are elliptic). Moreover, they do not depend on the interval length, as implied by the SUSY. This is consistent with the claim that such boundary conditions, at the level of Q-cohomology, mimic the SUSY vacua. We will work under the assumption that once elliptic, such boundary conditions, followed by the Euclidean evolution, prepare physically sensible states e <sup>−</sup>T H|Bi.

### References

- <span id="page-137-0"></span>[1] A. Braverman, "Instanton counting via affine Lie algebras. 1. Equivariant J functions of (affine) flag manifolds and Whittaker vectors," in CRM Workshop on Algebraic Structures and Moduli Spaces. 1, 2004. [arXiv:math/0401409](http://arxiv.org/abs/math/0401409).
- <span id="page-137-7"></span>[2] S. Gukov and E. Witten, "Gauge Theory, Ramification, And The Geometric Langlands Program," [arXiv:hep-th/0612073](http://arxiv.org/abs/hep-th/0612073).
- [3] J. Lurie, "On the Classification of Topological Field Theories," [arXiv:0905.0465](http://arxiv.org/abs/0905.0465) [\[math.CT\]](http://arxiv.org/abs/0905.0465).
- <span id="page-137-1"></span>[4] N. Drukker, D. Gaiotto, and J. Gomis, "The virtue of defects in 4d gauge theories and 2d cfts," [Journal of High Energy Physics](http://dx.doi.org/10.1007/jhep06(2011)025) 2011 no. 6, (Jun, 2011) . [http://dx.doi.org/10.1007/JHEP06\(2011\)025](http://dx.doi.org/10.1007/JHEP06(2011)025).
- <span id="page-137-2"></span>[5] N. Nekrasov, "2d CFT-type equations from 4d gauge theory," Lecture at the conference Langlands Program and Physics conference, IAS, Princeton, March 8-10 (2004) .
- [6] A. Losev, "Geometry, QFT, their deformations and their obstructions,". <https://irma.math.unistra.fr/article915.html>. 86e rencontre entre physiciens th´eoriciens et math´ematiciens : Moduli space and mathematical physics, Strasbourg, France, 2010.
- <span id="page-137-3"></span>[7] A. Neitzke, "Some uses of defects in quantum field theory,". <https://gauss.math.yale.edu/~an592/talks/html/defects-aspen/talk.html>. Aspen Center for Physics program "Boundaries and Defects in Quantum Field Theories", 2016.
- <span id="page-137-4"></span>[8] J. Hoppe, [\(1992\) The Projection Method of Olshanetsky and Perelomov. In: Lectures](http://dx.doi.org/https://doi.org/10.1007/978-3-540-47274-2_1) [on Integrable Systems](http://dx.doi.org/https://doi.org/10.1007/978-3-540-47274-2_1), vol. 10 of Lecture Notes in Physics Monographs. Springer, Berlin, Heidelberg.
- <span id="page-137-5"></span>[9] E. Witten, "Quantum Field Theory and the Jones Polynomial," [Commun. Math.](http://dx.doi.org/10.1007/BF01217730) Phys. 121 [\(1989\) 351–399.](http://dx.doi.org/10.1007/BF01217730)
- <span id="page-137-6"></span>[10] E. Witten, "Gauge Theories, Vertex Models and Quantum Groups," [Nucl. Phys. B](http://dx.doi.org/10.1016/0550-3213(90)90115-T) 330 [\(1990\) 285–346.](http://dx.doi.org/10.1016/0550-3213(90)90115-T)

- [11] E. Witten, "Gauge Theories and Integrable Lattice Models," [Nucl. Phys. B](http://dx.doi.org/10.1016/0550-3213(89)90232-0) 322 [\(1989\) 629–697.](http://dx.doi.org/10.1016/0550-3213(89)90232-0)
- <span id="page-138-0"></span>[12] E. Witten, "Searching for integrability," [J. Geom. Phys.](http://dx.doi.org/10.1016/0393-0440(92)90055-6) 8 (1992) 327–334.
- <span id="page-138-1"></span>[13] A. Gorsky and N. Nekrasov, "Hamiltonian systems of Calogero type and two-dimensional Yang-Mills theory," Nucl. Phys. B 414 [\(1994\) 213–238,](http://dx.doi.org/10.1016/0550-3213(94)90429-4) [arXiv:hep-th/9304047](http://arxiv.org/abs/hep-th/9304047).
- <span id="page-138-2"></span>[14] V. A. Novikov, M. A. Shifman, A. I. Vainshtein, and V. I. Zakharov, "Exact Gell-Mann-Low Function of Supersymmetric Yang-Mills Theories from Instanton Calculus," Nucl. Phys. B 229 [\(1983\) 381–393.](http://dx.doi.org/10.1016/0550-3213(83)90338-3)
- <span id="page-138-3"></span>[15] E. Witten, "Two-dimensional gauge theories revisited," [J. Geom. Phys.](http://dx.doi.org/10.1016/0393-0440(92)90034-X) 9 (1992) [303–368,](http://dx.doi.org/10.1016/0393-0440(92)90034-X) [arXiv:hep-th/9204083](http://arxiv.org/abs/hep-th/9204083).
- <span id="page-138-4"></span>[16] A. Gorsky and N. Nekrasov, "Relativistic Calogero-Moser model as gauged WZW theory," Nucl. Phys. B 436 [\(1995\) 582–608,](http://dx.doi.org/10.1016/0550-3213(94)00499-5) [arXiv:hep-th/9401017](http://arxiv.org/abs/hep-th/9401017).
- <span id="page-138-5"></span>[17] N. Nekrasov, Four Dimensional Holomorphic Theories. PhD thesis, Princeton University, 1996. <http://media.scgp.stonybrook.edu/papers/prdiss96.pdf>.
- <span id="page-138-10"></span>[18] L. Baulieu, A. Losev, and N. Nekrasov, "Chern-Simons and twisted supersymmetry in various dimensions," Nucl. Phys. B 522 [\(1998\) 82–104,](http://dx.doi.org/10.1016/S0550-3213(98)00096-0) [arXiv:hep-th/9707174](http://arxiv.org/abs/hep-th/9707174).
- [19] C. Beasley and E. Witten, "Non-Abelian localization for Chern-Simons theory," J. Diff. Geom. 70 no. 2, (2005) 183–323, [arXiv:hep-th/0503126](http://arxiv.org/abs/hep-th/0503126).
- <span id="page-138-6"></span>[20] A. Nedelin, F. Nieri, and M. Zabzine, "q-Virasoro modular double and 3d partition functions," Commun. Math. Phys. 353 [no. 3, \(2017\) 1059–1102,](http://dx.doi.org/10.1007/s00220-017-2882-1) [arXiv:1605.07029](http://arxiv.org/abs/1605.07029) [\[hep-th\]](http://arxiv.org/abs/1605.07029).
- <span id="page-138-7"></span>[21] E. Lieb and W. Liniger, "Exact Analysis of an Interacting Bose Gas. I. The General Solution and the Ground State," Physical Review 130 (1963) 1605?1616.
- <span id="page-138-8"></span>[22] G. W. Moore, N. Nekrasov, and S. Shatashvili, "Integrating over Higgs branches," [Commun. Math. Phys.](http://dx.doi.org/10.1007/PL00005525) 209 (2000) 97–121, [arXiv:hep-th/9712241](http://arxiv.org/abs/hep-th/9712241).
- <span id="page-138-9"></span>[23] A. A. Gerasimov and S. L. Shatashvili, "Two-dimensional gauge theories and quantum integrable systems," Proc. Symp. Pure Math. 78 (2008) 239–262, [arXiv:0711.1472 \[hep-th\]](http://arxiv.org/abs/0711.1472).

- <span id="page-139-0"></span>[24] A. Gorsky and N. Nekrasov, "Elliptic Calogero-Moser system from two-dimensional current algebra," [arXiv:hep-th/9401021](http://arxiv.org/abs/hep-th/9401021).
- <span id="page-139-1"></span>[25] E. Witten, "Chern-Simons gauge theory as a string theory," Prog. Math. 133 (1995) 637–678, [arXiv:hep-th/9207094](http://arxiv.org/abs/hep-th/9207094).
- <span id="page-139-2"></span>[26] A. Gerasimov, D. Lebedev, and A. Morozov, "On Possible Implications of Integrable Systems for String Theory," [Sov. J. Nucl. Phys.](http://dx.doi.org/10.1142/S0217751X91000538) 52 (1990) 1091–1095.
- <span id="page-139-3"></span>[27] P. I. Etingof and I. B. Frenkel, "Central extensions of current groups in two-dimensions," [Commun. Math. Phys.](http://dx.doi.org/10.1007/BF02099419) 165 (1994) 429–444, [arXiv:hep-th/9303047](http://arxiv.org/abs/hep-th/9303047).
- <span id="page-139-4"></span>[28] G. E. Arutyunov, S. A. Frolov, and P. B. Medvedev, "Elliptic Ruijsenaars-Schneider model from the cotangent bundle over the two-dimensional current group," [J. Math.](http://dx.doi.org/10.1063/1.532160) Phys. 38 [\(1997\) 5682–5689,](http://dx.doi.org/10.1063/1.532160) [arXiv:hep-th/9608013](http://arxiv.org/abs/hep-th/9608013).
- <span id="page-139-5"></span>[29] A. Givental and B.-s. Kim, "Quantum cohomology of flag manifolds and Toda lattices," [Commun. Math. Phys.](http://dx.doi.org/10.1007/BF02101846) 168 (1995) 609–642, [arXiv:hep-th/9312096](http://arxiv.org/abs/hep-th/9312096).
- <span id="page-139-6"></span>[30] A. B. Givental, "Equivariant Gromov - Witten Invariants," arXiv e-prints (Mar., 1996) alg–geom/9603021, [arXiv:alg-geom/9603021 \[math.AG\]](http://arxiv.org/abs/alg-geom/9603021).
- <span id="page-139-7"></span>[31] A. Losev, [TQFT, homological algebra and elements of K. Saito's theory of Primitive](http://dx.doi.org/https://doi.org/10.2969/aspm/08310269) [form: an attempt of mathematical text written by mathematical physicist](http://dx.doi.org/https://doi.org/10.2969/aspm/08310269), vol. 83 of Advanced Studies in Pure Mathematics. 2019.
- <span id="page-139-8"></span>[32] N. A. Nekrasov and S. L. Shatashvili, "Supersymmetric vacua and Bethe ansatz," [Nucl. Phys. B Proc. Suppl.](http://dx.doi.org/10.1016/j.nuclphysbps.2009.07.047) 192-193 (2009) 91–112, [arXiv:0901.4744 \[hep-th\]](http://arxiv.org/abs/0901.4744).
- [33] N. A. Nekrasov and S. L. Shatashvili, "Quantum integrability and supersymmetric vacua," [Prog. Theor. Phys. Suppl.](http://dx.doi.org/10.1143/PTPS.177.105) 177 (2009) 105–119, [arXiv:0901.4748 \[hep-th\]](http://arxiv.org/abs/0901.4748).
- <span id="page-139-9"></span>[34] N. A. Nekrasov and S. L. Shatashvili, ["Quantization of Integrable Systems and Four](http://dx.doi.org/10.1142/9789814304634_0015) [Dimensional Gauge Theories,"](http://dx.doi.org/10.1142/9789814304634_0015) in 16th International Congress on Mathematical Physics, pp. 265–289. 8, 2009. [arXiv:0908.4052 \[hep-th\]](http://arxiv.org/abs/0908.4052).
- <span id="page-139-10"></span>[35] L. D. Faddeev, "Algebraic aspects of Bethe Ansatz," [Int. J. Mod. Phys. A](http://dx.doi.org/10.1142/S0217751X95000905) 10 (1995) [1845–1878,](http://dx.doi.org/10.1142/S0217751X95000905) [arXiv:hep-th/9404013](http://arxiv.org/abs/hep-th/9404013).

- [36] L. D. Faddeev, "How algebraic Bethe ansatz works for integrable model," in Les Houches School of Physics: Astrophysical Sources of Gravitational Radiation. 5, 1996. [arXiv:hep-th/9605187](http://arxiv.org/abs/hep-th/9605187).
- <span id="page-140-0"></span>[37] L. Takhtajan and L. Faddeev, "The Quantum method of the inverse problem and the Heisenberg XYZ model," Russ. Math. Surveys 34 no. 5, (1979) 11–68.
- <span id="page-140-1"></span>[38] N. Nekrasov, "Supersymmetric gauge theories and quantization of integrable systems," lecture given at Strings ?2009, Rome (22?26 June 2009) .
- <span id="page-140-2"></span>[39] K. Costello, "Supersymmetric gauge theory and the Yangian," [arXiv:1303.2632](http://arxiv.org/abs/1303.2632) [\[hep-th\]](http://arxiv.org/abs/1303.2632).
- <span id="page-140-3"></span>[40] K. Costello, "Integrable lattice models from four-dimensional field theories," [Proc.](http://dx.doi.org/10.1090/pspum/088/01483) [Symp. Pure Math.](http://dx.doi.org/10.1090/pspum/088/01483) 88 (2014) 3–24, [arXiv:1308.0370 \[hep-th\]](http://arxiv.org/abs/1308.0370).
- <span id="page-140-4"></span>[41] K. Costello, E. Witten, and M. Yamazaki, "Gauge Theory and Integrability, I," [arXiv:1709.09993 \[hep-th\]](http://arxiv.org/abs/1709.09993).
- [42] K. Costello, E. Witten, and M. Yamazaki, "Gauge Theory and Integrability, II," [arXiv:1802.01579 \[hep-th\]](http://arxiv.org/abs/1802.01579).
- <span id="page-140-5"></span>[43] K. Costello and J. Yagi, "Unification of integrability in supersymmetric gauge theories," [arXiv:1810.01970 \[hep-th\]](http://arxiv.org/abs/1810.01970).
- <span id="page-140-6"></span>[44] A. M. Polyakov, "One physical problem with possible mathematical significance," [J.](http://dx.doi.org/10.1016/0393-0440(88)90021-6) Geom. Phys. 5 [\(1988\) 595–600.](http://dx.doi.org/10.1016/0393-0440(88)90021-6)
- [45] A. M. Polyakov, "Fermi-Bose Transmutations Induced by Gauge Fields," [Mod. Phys.](http://dx.doi.org/10.1142/S0217732388000398) Lett. A 3 [\(1988\) 325.](http://dx.doi.org/10.1142/S0217732388000398)
- [46] E. Guadagnini, M. Martellini, and M. Mintchev, "Chern-Simons Holonomies and the Appearance of Quantum Groups," Phys. Lett. B 235 [\(1990\) 275–281.](http://dx.doi.org/10.1016/0370-2693(90)91963-C)
- [47] E. Guadagnini, M. Martellini, and M. Mintchev, "Wilson Lines in Chern-Simons Theory and Link Invariants," Nucl. Phys. B 330 [\(1990\) 575–607.](http://dx.doi.org/10.1016/0550-3213(90)90124-V)
- [48] M. Kontsevich, "Vassiliev's Knot Invariants," Advances in Soviet Mathematics 16 (1993) 137–150. <https://www.ihes.fr/~maxim/TEXTS/VassilievKnot.pdf>.

- [49] V. V. Fock and A. A. Rosly, "Poisson structure on moduli of flat connections on Riemann surfaces and r matrix," Am. Math. Soc. Transl. 191 (1999) 67–86, [arXiv:math/9802054](http://arxiv.org/abs/math/9802054).
- <span id="page-141-0"></span>[50] A. Morozov and A. Smirnov, "Chern-Simons Theory in the Temporal Gauge and Knot Invariants through the Universal Quantum R-Matrix," [Nucl. Phys. B](http://dx.doi.org/10.1016/j.nuclphysb.2010.03.012) 835 [\(2010\) 284–313,](http://dx.doi.org/10.1016/j.nuclphysb.2010.03.012) [arXiv:1001.2003 \[hep-th\]](http://arxiv.org/abs/1001.2003).
- <span id="page-141-1"></span>[51] D. Maulik and A. Okounkov, "Quantum Groups and Quantum Cohomology," [arXiv:1211.1287 \[math.AG\]](http://arxiv.org/abs/1211.1287).
- <span id="page-141-2"></span>[52] M. Aganagic and A. Okounkov, "Elliptic stable envelopes," [arXiv:1604.00423](http://arxiv.org/abs/1604.00423) [\[math.AG\]](http://arxiv.org/abs/1604.00423).
- <span id="page-141-3"></span>[53] H. Nakajima, "Quiver varieties and finite-dimensional representations of quantum affine algebras," [J. Amer. Math. Soc. 14](http://dx.doi.org/10.1090/S0894-0347-00-00353-2) no. 1, (2001) 145–238.
- <span id="page-141-4"></span>[54] M. Varagnolo, "Quiver Varieties and Yangians," arXiv Mathematics e-prints (May, 2000) math/0005277, [arXiv:math/0005277 \[math.QA\]](http://arxiv.org/abs/math/0005277).
- <span id="page-141-5"></span>[55] D. Bykov and P. Zinn-Justin, "Higher spin sl2R-matrix from equivariant (co)homology," Lett. Math. Phys. 110 [\(2020\) 2435–2470,](http://dx.doi.org/10.1007/s11005-020-01302-z) [arXiv:1904.11107](http://arxiv.org/abs/1904.11107) [\[math-ph\]](http://arxiv.org/abs/1904.11107).
- <span id="page-141-6"></span>[56] E. Witten, "Quantum Field Theory, Grassmannians, and Algebraic Curves," [Commun. Math. Phys.](http://dx.doi.org/10.1007/BF01223238) 113 (1988) 529.
- <span id="page-141-7"></span>[57] A. Losev, G. W. Moore, N. Nekrasov, and S. Shatashvili, "Four-dimensional avatars of two-dimensional RCFT," [Nucl. Phys. B Proc. Suppl.](http://dx.doi.org/10.1016/0920-5632(96)00015-1) 46 (1996) 130–145, [arXiv:hep-th/9509151](http://arxiv.org/abs/hep-th/9509151).
- <span id="page-141-8"></span>[58] E. Witten, "Three lectures on topological phases of matter," [Riv. Nuovo Cim.](http://dx.doi.org/10.1393/ncr/i2016-10125-3) 39 [no. 7, \(2016\) 313–370,](http://dx.doi.org/10.1393/ncr/i2016-10125-3) [arXiv:1510.07698 \[cond-mat.mes-hall\]](http://arxiv.org/abs/1510.07698).
- <span id="page-141-9"></span>[59] S. Cecotti and C. Vafa, "Topological antitopological fusion," [Nucl. Phys. B](http://dx.doi.org/10.1016/0550-3213(91)90021-O) 367 [\(1991\) 359–461.](http://dx.doi.org/10.1016/0550-3213(91)90021-O)
- [60] S. Cecotti and C. Vafa, "2d Wall-Crossing, R-Twisting, and a Supersymmetric Index," [arXiv:1002.3638 \[hep-th\]](http://arxiv.org/abs/1002.3638).

- [61] S. Cecotti, C. Cordova, and C. Vafa, "Braids, Walls, and Mirrors," [arXiv:1110.2115](http://arxiv.org/abs/1110.2115) [\[hep-th\]](http://arxiv.org/abs/1110.2115).
- <span id="page-142-8"></span>[62] A. Gadde, S. Gukov, and P. Putrov, "Walls, Lines, and Spectral Dualities in 3d Gauge Theories," JHEP 05 [\(2014\) 047,](http://dx.doi.org/10.1007/JHEP05(2014)047) [arXiv:1302.0015 \[hep-th\]](http://arxiv.org/abs/1302.0015).
- <span id="page-142-0"></span>[63] S. Gukov, Surface Operators, [pp. 223–259.](http://dx.doi.org/10.1007/978-3-319-18769-3_8) 2016. [arXiv:1412.7127 \[hep-th\]](http://arxiv.org/abs/1412.7127).
- <span id="page-142-1"></span>[64] M. Dedushenko and N. Nekrasov, "Interfaces and Quantum Algebras, III: Bethe/Gauge Correspondence," to appear.
- <span id="page-142-2"></span>[65] E. Witten, "Supersymmetry and Morse theory," J. Diff. Geom. 17 no. 4, (1982) 661–692.
- <span id="page-142-3"></span>[66] E. Frenkel, A. Losev, and N. Nekrasov, "Instantons beyond topological theory. I," [arXiv:hep-th/0610149](http://arxiv.org/abs/hep-th/0610149).
- <span id="page-142-10"></span>[67] E. Frenkel, A. Losev, and N. Nekrasov, "Notes on instantons in topological field theory and beyond," [Nucl. Phys. B Proc. Suppl.](http://dx.doi.org/10.1016/j.nuclphysbps.2007.06.013) 171 (2007) 215–230, [arXiv:hep-th/0702137](http://arxiv.org/abs/hep-th/0702137).
- <span id="page-142-4"></span>[68] E. Frenkel, A. Losev, and N. Nekrasov, "Instantons beyond topological theory II," [arXiv:0803.3302 \[hep-th\]](http://arxiv.org/abs/0803.3302).
- <span id="page-142-5"></span>[69] A. Okounkov, "Enumerative geometry and geometric representation theory." [https://crei.skoltech.ru/cas/calendar/okounkov\\_lect20/](https://crei.skoltech.ru/cas/calendar/okounkov_lect20/).
- <span id="page-142-6"></span>[70] M. Bullimore and D. Zhang, "3d N = 4 Gauge Theories on an Elliptic Curve," SciPost Phys. 13 [no. 1, \(2022\) 005,](http://dx.doi.org/10.21468/SciPostPhys.13.1.005) [arXiv:2109.10907 \[hep-th\]](http://arxiv.org/abs/2109.10907).
- <span id="page-142-7"></span>[71] N. Seiberg, "IR dynamics on branes and space-time geometry," [Phys. Lett. B](http://dx.doi.org/10.1016/0370-2693(96)00819-2) 384 [\(1996\) 81–85,](http://dx.doi.org/10.1016/0370-2693(96)00819-2) [arXiv:hep-th/9606017](http://arxiv.org/abs/hep-th/9606017).
- [72] N. Seiberg and E. Witten, "Gauge dynamics and compactification to three-dimensions," in The mathematical beauty of physics: A memorial volume for Claude Itzykson. Proceedings, Conference, Saclay, France, June 5-7, 1996, pp. 333–366. 1996. [arXiv:hep-th/9607163 \[hep-th\]](http://arxiv.org/abs/hep-th/9607163).
- <span id="page-142-9"></span>[73] K. A. Intriligator and N. Seiberg, "Mirror symmetry in three-dimensional gauge theories," Phys. Lett. B 387 [\(1996\) 513–519,](http://dx.doi.org/10.1016/0370-2693(96)01088-X) [arXiv:hep-th/9607207](http://arxiv.org/abs/hep-th/9607207).

- [74] A. Hanany and E. Witten, "Type IIB superstrings, BPS monopoles, and three-dimensional gauge dynamics," Nucl. Phys. B 492 [\(1997\) 152–190,](http://dx.doi.org/10.1016/S0550-3213(97)00157-0) [arXiv:hep-th/9611230](http://arxiv.org/abs/hep-th/9611230).
- [75] J. de Boer, K. Hori, H. Ooguri, Y. Oz, and Z. Yin, "Mirror symmetry in three-dimensional theories, SL(2,Z) and D-brane moduli spaces," [Nucl. Phys. B](http://dx.doi.org/10.1016/S0550-3213(97)00115-6) 493 [\(1997\) 148–176,](http://dx.doi.org/10.1016/S0550-3213(97)00115-6) [arXiv:hep-th/9612131](http://arxiv.org/abs/hep-th/9612131).
- <span id="page-143-0"></span>[76] A. Kapustin and M. J. Strassler, "On mirror symmetry in three-dimensional Abelian gauge theories," JHEP 04 [\(1999\) 021,](http://dx.doi.org/10.1088/1126-6708/1999/04/021) [arXiv:hep-th/9902033](http://arxiv.org/abs/hep-th/9902033).
- <span id="page-143-1"></span>[77] V. Borokhov, A. Kapustin, and X.-k. Wu, "Monopole operators and mirror symmetry in three-dimensions," JHEP 12 [\(2002\) 044,](http://dx.doi.org/10.1088/1126-6708/2002/12/044) [arXiv:hep-th/0207074](http://arxiv.org/abs/hep-th/0207074).
- [78] V. Borokhov, "Monopole operators in three-dimensional N=4 SYM and mirror symmetry," JHEP 03 [\(2004\) 008,](http://dx.doi.org/10.1088/1126-6708/2004/03/008) [arXiv:hep-th/0310254](http://arxiv.org/abs/hep-th/0310254).
- <span id="page-143-8"></span>[79] D. Gaiotto and E. Witten, "S-Duality of Boundary Conditions In N=4 Super Yang-Mills Theory," [Adv. Theor. Math. Phys.](http://dx.doi.org/10.4310/ATMP.2009.v13.n3.a5) 13 no. 3, (2009) 721–896, [arXiv:0807.3720 \[hep-th\]](http://arxiv.org/abs/0807.3720).
- <span id="page-143-2"></span>[80] S. Cremonesi, A. Hanany, and A. Zaffaroni, "Monopole operators and Hilbert series of Coulomb branches of 3d N = 4 gauge theories," JHEP 01 [\(2014\) 005,](http://dx.doi.org/10.1007/JHEP01(2014)005) [arXiv:1309.2657 \[hep-th\]](http://arxiv.org/abs/1309.2657).
- <span id="page-143-3"></span>[81] R. Brooks and S. J. Gates, Jr., "Extended supersymmetry and superBF gauge theories," Nucl. Phys. B 432 [\(1994\) 205–224,](http://dx.doi.org/10.1016/0550-3213(94)90600-9) [arXiv:hep-th/9407147](http://arxiv.org/abs/hep-th/9407147).
- <span id="page-143-4"></span>[82] D. Gaiotto and E. Witten, "Janus Configurations, Chern-Simons Couplings, And The theta-Angle in N=4 Super Yang-Mills Theory," JHEP 06 [\(2010\) 097,](http://dx.doi.org/10.1007/JHEP06(2010)097) [arXiv:0804.2907 \[hep-th\]](http://arxiv.org/abs/0804.2907).
- <span id="page-143-5"></span>[83] O. Aharony, S. S. Razamat, and B. Willett, "From 3d duality to 2d duality," [JHEP](http://dx.doi.org/10.1007/JHEP11(2017)090) 11 [\(2017\) 090,](http://dx.doi.org/10.1007/JHEP11(2017)090) [arXiv:1710.00926 \[hep-th\]](http://arxiv.org/abs/1710.00926).
- <span id="page-143-6"></span>[84] A. Okounkov and A. Smirnov, "Quantum difference equation for Nakajima varieties," [arXiv:1602.09007 \[math-ph\]](http://arxiv.org/abs/1602.09007).
- <span id="page-143-7"></span>[85] A. Smirnov, "Elliptic stable envelope for Hilbert scheme of points in the plane," [arXiv:1804.08779 \[math.AG\]](http://arxiv.org/abs/1804.08779).

- <span id="page-144-0"></span>[86] T. Okazaki and S. Yamaguchi, "Supersymmetric boundary conditions in three-dimensional N=2 theories," Phys. Rev. D 87 [no. 12, \(2013\) 125005,](http://dx.doi.org/10.1103/PhysRevD.87.125005) [arXiv:1302.6593 \[hep-th\]](http://arxiv.org/abs/1302.6593).
- [87] H.-J. Chung and T. Okazaki, "(2,2) and (0,4) supersymmetric boundary conditions in 3d N = 4 theories and type IIB branes," Phys. Rev. D 96 [no. 8, \(2017\) 086005,](http://dx.doi.org/10.1103/PhysRevD.96.086005) [arXiv:1608.05363 \[hep-th\]](http://arxiv.org/abs/1608.05363).
- <span id="page-144-3"></span>[88] M. Bullimore, T. Dimofte, D. Gaiotto, and J. Hilburn, "Boundaries, Mirror Symmetry, and Symplectic Duality in 3d N = 4 Gauge Theory," JHEP 10 [\(2016\)](http://dx.doi.org/10.1007/JHEP10(2016)108) [108,](http://dx.doi.org/10.1007/JHEP10(2016)108) [arXiv:1603.08382 \[hep-th\]](http://arxiv.org/abs/1603.08382).
- <span id="page-144-1"></span>[89] T. Dimofte, D. Gaiotto, and N. M. Paquette, "Dual boundary conditions in 3d SCFT's," JHEP 05 [\(2018\) 060,](http://dx.doi.org/10.1007/JHEP05(2018)060) [arXiv:1712.07654 \[hep-th\]](http://arxiv.org/abs/1712.07654).
- <span id="page-144-2"></span>[90] E. Witten, "Phases of N=2 theories in two-dimensions," [AMS/IP Stud. Adv. Math.](http://dx.doi.org/10.1016/0550-3213(93)90033-L) 1 [\(1996\) 143–211,](http://dx.doi.org/10.1016/0550-3213(93)90033-L) [arXiv:hep-th/9301042](http://arxiv.org/abs/hep-th/9301042).
- <span id="page-144-4"></span>[91] N. J. Hitchin, A. Karlhede, U. Lindstrom, and M. Rocek, "Hyperkahler Metrics and Supersymmetry," [Commun. Math. Phys.](http://dx.doi.org/10.1007/BF01214418) 108 (1987) 535.
- <span id="page-144-5"></span>[92] H. Nakajima, "Towards a mathematical definition of Coulomb branches of 3-dimensional N = 4 gauge theories, I," [Adv. Theor. Math. Phys.](http://dx.doi.org/10.4310/ATMP.2016.v20.n3.a4) 20 (2016) 595–669, [arXiv:1503.03676 \[math-ph\]](http://arxiv.org/abs/1503.03676).
- [93] A. Braverman, M. Finkelberg, and H. Nakajima, "Towards a mathematical definition of Coulomb branches of 3-dimensional N = 4 gauge theories, II," [Adv. Theor. Math.](http://dx.doi.org/10.4310/ATMP.2018.v22.n5.a1) Phys. 22 [\(2018\) 1071–1147,](http://dx.doi.org/10.4310/ATMP.2018.v22.n5.a1) [arXiv:1601.03586 \[math.RT\]](http://arxiv.org/abs/1601.03586).
- <span id="page-144-6"></span>[94] A. Braverman, M. Finkelberg, and H. Nakajima, "Coulomb branches of 3d N = 4 quiver gauge theories and slices in the affine Grassmannian," [Adv. Theor. Math.](http://dx.doi.org/10.4310/ATMP.2019.v23.n1.a3) Phys. 23 [\(2019\) 75–166,](http://dx.doi.org/10.4310/ATMP.2019.v23.n1.a3) [arXiv:1604.03625 \[math.RT\]](http://arxiv.org/abs/1604.03625).
- <span id="page-144-7"></span>[95] M. Bullimore, T. Dimofte, and D. Gaiotto, "The Coulomb Branch of 3d N = 4 Theories," [Commun. Math. Phys.](http://dx.doi.org/10.1007/s00220-017-2903-0) 354 no. 2, (2017) 671–751, [arXiv:1503.04817](http://arxiv.org/abs/1503.04817) [\[hep-th\]](http://arxiv.org/abs/1503.04817).
- [96] M. Dedushenko, Y. Fan, S. S. Pufu, and R. Yacoby, "Coulomb Branch Operators and Mirror Symmetry in Three Dimensions," JHEP 04 [\(2018\) 037,](http://dx.doi.org/10.1007/JHEP04(2018)037) [arXiv:1712.09384](http://arxiv.org/abs/1712.09384) [\[hep-th\]](http://arxiv.org/abs/1712.09384).

- <span id="page-145-0"></span>[97] M. Dedushenko, Y. Fan, S. S. Pufu, and R. Yacoby, "Coulomb Branch Quantization and Abelianized Monopole Bubbling," JHEP 10 [\(2019\) 179,](http://dx.doi.org/10.1007/JHEP10(2019)179) [arXiv:1812.08788](http://arxiv.org/abs/1812.08788) [\[hep-th\]](http://arxiv.org/abs/1812.08788).
- <span id="page-145-1"></span>[98] A. D'Adda, M. Luscher, and P. Di Vecchia, "A 1/n Expandable Series of Nonlinear Sigma Models with Instantons," [Nucl. Phys. B](http://dx.doi.org/10.1016/0550-3213(78)90432-7) 146 (1978) 63–76.
- <span id="page-145-2"></span>[99] E. Witten, "The Verlinde algebra and the cohomology of the Grassmannian," [arXiv:hep-th/9312104](http://arxiv.org/abs/hep-th/9312104).
- <span id="page-145-3"></span>[100] A. Losev, N. Nekrasov, and S. L. Shatashvili, "The Freckled instantons," [arXiv:hep-th/9908204](http://arxiv.org/abs/hep-th/9908204).
- <span id="page-145-4"></span>[101] I. Ciocan-Fontanine, B. Kim, and D. Maulik, "Stable quasimaps to GIT quotients," [Journal of Geometry and Physics](http://dx.doi.org/https://doi.org/10.1016/j.geomphys.2013.08.019) 75 (2014) 17–47, [arXiv:1106.3724 \[math.AG\]](http://arxiv.org/abs/1106.3724).
- <span id="page-145-5"></span>[102] M. Aganagic and A. Okounkov, "Quasimap counts and Bethe eigenfunctions," Moscow Math. J. 17 no. 4, (2017) 565–600, [arXiv:1704.08746 \[math-ph\]](http://arxiv.org/abs/1704.08746).
- <span id="page-145-6"></span>[103] M. R. Douglas and G. W. Moore, "D-branes, quivers, and ALE instantons," [arXiv:hep-th/9603167](http://arxiv.org/abs/hep-th/9603167).
- <span id="page-145-8"></span>[104] M. Aganagic and N. Haouzi, "ADE Little String Theory on a Riemann Surface (and Triality)," [arXiv:1506.04183 \[hep-th\]](http://arxiv.org/abs/1506.04183).
- <span id="page-145-7"></span>[105] M. Aganagic, E. Frenkel, and A. Okounkov, "Quantum q-Langlands Correspondence," [Trans. Moscow Math. Soc.](http://dx.doi.org/10.1090/mosc/278) 79 (2018) 1–83, [arXiv:1701.03146](http://arxiv.org/abs/1701.03146) [\[hep-th\]](http://arxiv.org/abs/1701.03146).
- <span id="page-145-9"></span>[106] E. Witten, "Topological Quantum Field Theory," [Commun. Math. Phys.](http://dx.doi.org/10.1007/BF01223371) 117 (1988) [353.](http://dx.doi.org/10.1007/BF01223371)
- <span id="page-145-10"></span>[107] E. Witten, "Mirror manifolds and topological field theory," AMS/IP Stud. Adv. Math. 9 (1998) 121–160, [arXiv:hep-th/9112056](http://arxiv.org/abs/hep-th/9112056).
- <span id="page-145-11"></span>[108] K. Costello, T. Dimofte, and D. Gaiotto, "Boundary Chiral Algebras and Holomorphic Twists," [arXiv:2005.00083 \[hep-th\]](http://arxiv.org/abs/2005.00083).
- <span id="page-145-12"></span>[109] F. Benini and A. Zaffaroni, "A topologically twisted index for three-dimensional supersymmetric theories," JHEP 07 [\(2015\) 127,](http://dx.doi.org/10.1007/JHEP07(2015)127) [arXiv:1504.03698 \[hep-th\]](http://arxiv.org/abs/1504.03698).

- [110] F. Benini and A. Zaffaroni, "Supersymmetric partition functions on Riemann surfaces," Proc. Symp. Pure Math. 96 (2017) 13–46, [arXiv:1605.06120 \[hep-th\]](http://arxiv.org/abs/1605.06120).
- [111] C. Closset and H. Kim, "Comments on twisted indices in 3d supersymmetric gauge theories," JHEP 08 [\(2016\) 059,](http://dx.doi.org/10.1007/JHEP08(2016)059) [arXiv:1605.06531 \[hep-th\]](http://arxiv.org/abs/1605.06531).
- <span id="page-146-0"></span>[112] C. Closset, H. Kim, and B. Willett, "Supersymmetric partition functions and the three-dimensional A-twist," JHEP 03 [\(2017\) 074,](http://dx.doi.org/10.1007/JHEP03(2017)074) [arXiv:1701.03171 \[hep-th\]](http://arxiv.org/abs/1701.03171).
- <span id="page-146-1"></span>[113] D. Z. Freedman and A. Van Proeyen, Supergravity. Cambridge Univ. Press, Cambridge, UK, 5, 2012.
- <span id="page-146-2"></span>[114] K. Hori, A. Iqbal, and C. Vafa, "D-branes and mirror symmetry," [arXiv:hep-th/0005247](http://arxiv.org/abs/hep-th/0005247).
- <span id="page-146-3"></span>[115] A. Kapustin and D. Orlov, "Remarks on A branes, mirror symmetry, and the Fukaya category," [J. Geom. Phys.](http://dx.doi.org/10.1016/S0393-0440(03)00026-3) 48 (2003) 84, [arXiv:hep-th/0109098](http://arxiv.org/abs/hep-th/0109098).
- <span id="page-146-4"></span>[116] B. Assel and J. Gomis, "Mirror Symmetry And Loop Operators," JHEP 11 [\(2015\)](http://dx.doi.org/10.1007/JHEP11(2015)055) [055,](http://dx.doi.org/10.1007/JHEP11(2015)055) [arXiv:1506.01718 \[hep-th\]](http://arxiv.org/abs/1506.01718).
- <span id="page-146-5"></span>[117] A. Dey, "Line Defects in Three Dimensional Mirror Symmetry beyond Linear Quivers," [arXiv:2103.01243 \[hep-th\]](http://arxiv.org/abs/2103.01243).
- <span id="page-146-6"></span>[118] A. Kapustin and B. Willett, "Wilson loops in supersymmetric Chern-Simons-matter theories and duality," [arXiv:1302.2164 \[hep-th\]](http://arxiv.org/abs/1302.2164).
- <span id="page-146-7"></span>[119] H. Jockers and P. Mayr, "A 3d Gauge Theory/Quantum K-Theory Correspondence," [Adv. Theor. Math. Phys.](http://dx.doi.org/10.4310/ATMP.2020.v24.n2.a4) 24 no. 2, (2020) 327–457, [arXiv:1808.02040 \[hep-th\]](http://arxiv.org/abs/1808.02040).
- <span id="page-146-8"></span>[120] H. Jockers, P. Mayr, U. Ninad, and A. Tabler, "BPS Indices, Modularity and Perturbations in Quantum K-theory," [arXiv:2106.07670 \[hep-th\]](http://arxiv.org/abs/2106.07670).
- <span id="page-146-9"></span>[121] A. Givental, "Permutation-equivariant quantum K-theory I-XI," [arXiv:1508.02690,](http://arxiv.org/abs/1508.02690, 1508.04374, 1508.06697, 1509.00830, 1509.03903, 1509.07852, 1510.03076, 1510.06116, 1709.03180, 1710.02376, 1711.04201) [1508.04374, 1508.06697, 1509.00830, 1509.03903, 1509.07852, 1510.03076,](http://arxiv.org/abs/1508.02690, 1508.04374, 1508.06697, 1509.00830, 1509.03903, 1509.07852, 1510.03076, 1510.06116, 1709.03180, 1710.02376, 1711.04201) [1510.06116, 1709.03180, 1710.02376, 1711.04201](http://arxiv.org/abs/1508.02690, 1508.04374, 1508.06697, 1509.00830, 1509.03903, 1509.07852, 1510.03076, 1510.06116, 1709.03180, 1710.02376, 1711.04201). <https://math.berkeley.edu/~giventh/perm/perm.html>.
- <span id="page-146-10"></span>[122] N. A. Nekrasov, "Seiberg-Witten prepotential from instanton counting," [Adv. Theor.](http://dx.doi.org/10.4310/ATMP.2003.v7.n5.a4) Math. Phys. 7 [no. 5, \(2003\) 831–864,](http://dx.doi.org/10.4310/ATMP.2003.v7.n5.a4) [arXiv:hep-th/0206161 \[hep-th\]](http://arxiv.org/abs/hep-th/0206161).

- <span id="page-147-0"></span>[123] A. Okounkov, "Lectures on K-theoretic computations in enumerative geometry," [arXiv:1512.07363 \[math.AG\]](http://arxiv.org/abs/1512.07363).
- <span id="page-147-1"></span>[124] E. Witten, "Elliptic Genera and Quantum Field Theory," [Commun. Math. Phys.](http://dx.doi.org/10.1007/BF01208956) 109 [\(1987\) 525.](http://dx.doi.org/10.1007/BF01208956)
- <span id="page-147-2"></span>[125] E. Witten, "The index of the Dirac operator in loop space," [Lect. Notes Math.](http://dx.doi.org/10.1007/BFb0078045) 1326 [\(1988\) 161–181.](http://dx.doi.org/10.1007/BFb0078045)
- <span id="page-147-3"></span>[126] N. Kitchloo and J. Morava, Thom prospectra for loop group representations, [pp. 214–238.](http://dx.doi.org/10.1017/CBO9780511721489.011) London Mathematical Society Lecture Note Series. Cambridge University Press, 2007. [arXiv:math/0404541 \[math.AT\]](http://arxiv.org/abs/math/0404541).
- <span id="page-147-4"></span>[127] K. Luecke, "Completed K-theory and Equivariant Elliptic Cohomology," 2019.
- <span id="page-147-5"></span>[128] I. Grojnowski, Delocalised equivariant elliptic cohomology (with an introduction by Matthew Ando and Haynes Miller), [pp. 114–121.](http://dx.doi.org/10.1017/CBO9780511721489.007) London Mathematical Society Lecture Note Series. Cambridge University Press, 2007.
- <span id="page-147-6"></span>[129] D. Berwick-Evans and A. Tripathy, "A model for complex analytic equivariant elliptic cohomology from quantum field theory," [arXiv:1805.04146 \[math.AT\]](http://arxiv.org/abs/1805.04146).
- <span id="page-147-7"></span>[130] M. Dedushenko, "Remarks on Berry Connection in QFT, Anomalies, and Applications," [arXiv:2211.15680 \[hep-th\]](http://arxiv.org/abs/2211.15680).
- <span id="page-147-8"></span>[131] J. M. Bismut, H. Gillet, and C. Soul´e, "Analytic torsion and holomorphic determinant bundles," [Commun.Math. Phys.](http://dx.doi.org/10.1007/BF01466774) 115 (1988) 301?351.
- <span id="page-147-9"></span>[132] C. Closset, L. Di Pietro, and H. Kim, "'t Hooft anomalies and the holomorphy of supersymmetric partition functions," JHEP 08 [\(2019\) 035,](http://dx.doi.org/10.1007/JHEP08(2019)035) [arXiv:1905.05722](http://arxiv.org/abs/1905.05722) [\[hep-th\]](http://arxiv.org/abs/1905.05722).
- <span id="page-147-10"></span>[133] M. Bullimore, S. Crew, and D. Zhang, "Boundaries, Vermas, and Factorisation," [arXiv:2010.09741 \[hep-th\]](http://arxiv.org/abs/2010.09741).
- <span id="page-147-11"></span>[134] T. Okazaki, "Abelian mirror symmetry of N = (2, 2) boundary conditions," [JHEP](http://dx.doi.org/10.1007/JHEP03(2021)163) 03 [\(2021\) 163,](http://dx.doi.org/10.1007/JHEP03(2021)163) [arXiv:2010.13177 \[hep-th\]](http://arxiv.org/abs/2010.13177).
- <span id="page-147-12"></span>[135] N. A. Nekrasov and S. L. Shatashvili, "Bethe/Gauge correspondence on curved spaces," JHEP 01 [\(2015\) 100,](http://dx.doi.org/10.1007/JHEP01(2015)100) [arXiv:1405.6046 \[hep-th\]](http://arxiv.org/abs/1405.6046).

- <span id="page-148-0"></span>[136] M. Dedushenko, "Gluing. Part I. Integrals and symmetries," JHEP 04 [\(2020\) 175,](http://dx.doi.org/10.1007/JHEP04(2020)175) [arXiv:1807.04274 \[hep-th\]](http://arxiv.org/abs/1807.04274).
- <span id="page-148-1"></span>[137] M. Dedushenko, "Gluing II: Boundary Localization and Gluing Formulas," [arXiv:1807.04278 \[hep-th\]](http://arxiv.org/abs/1807.04278).
- <span id="page-148-2"></span>[138] F. Benini, R. Eager, K. Hori, and Y. Tachikawa, "Elliptic genera of two-dimensional N=2 gauge theories with rank-one gauge groups," [Lett. Math. Phys.](http://dx.doi.org/10.1007/s11005-013-0673-y) 104 (2014) [465–493,](http://dx.doi.org/10.1007/s11005-013-0673-y) [arXiv:1305.0533 \[hep-th\]](http://arxiv.org/abs/1305.0533).
- [139] A. Gadde and S. Gukov, "2d Index and Surface operators," JHEP 03 [\(2014\) 080,](http://dx.doi.org/10.1007/JHEP03(2014)080) [arXiv:1305.0266 \[hep-th\]](http://arxiv.org/abs/1305.0266).
- <span id="page-148-3"></span>[140] F. Benini, R. Eager, K. Hori, and Y. Tachikawa, "Elliptic Genera of 2d N = 2 Gauge Theories," Commun. Math. Phys. 333 [no. 3, \(2015\) 1241–1286,](http://dx.doi.org/10.1007/s00220-014-2210-y) [arXiv:1308.4896](http://arxiv.org/abs/1308.4896) [\[hep-th\]](http://arxiv.org/abs/1308.4896).
- <span id="page-148-4"></span>[141] N. Bobev, M. Bullimore, and H.-C. Kim, "Supersymmetric Casimir Energy and the Anomaly Polynomial," JHEP 09 [\(2015\) 142,](http://dx.doi.org/10.1007/JHEP09(2015)142) [arXiv:1507.08553 \[hep-th\]](http://arxiv.org/abs/1507.08553).
- <span id="page-148-5"></span>[142] D. Bak, M. Gutperle, and S. Hirano, "A Dilatonic deformation of AdS(5) and its field theory dual," JHEP 05 [\(2003\) 072,](http://dx.doi.org/10.1088/1126-6708/2003/05/072) [arXiv:hep-th/0304129](http://arxiv.org/abs/hep-th/0304129).
- [143] D. Z. Freedman, C. Nunez, M. Schnabl, and K. Skenderis, "Fake supergravity and domain wall stability," Phys. Rev. D 69 [\(2004\) 104027,](http://dx.doi.org/10.1103/PhysRevD.69.104027) [arXiv:hep-th/0312055](http://arxiv.org/abs/hep-th/0312055).
- <span id="page-148-6"></span>[144] A. B. Clark, D. Z. Freedman, A. Karch, and M. Schnabl, "Dual of the Janus solution: An interface conformal field theory," Phys. Rev. D 71 [\(2005\) 066003,](http://dx.doi.org/10.1103/PhysRevD.71.066003) [arXiv:hep-th/0407073](http://arxiv.org/abs/hep-th/0407073).
- <span id="page-148-7"></span>[145] A. Clark and A. Karch, "Super Janus," JHEP 10 [\(2005\) 094,](http://dx.doi.org/10.1088/1126-6708/2005/10/094) [arXiv:hep-th/0506265](http://arxiv.org/abs/hep-th/0506265).
- [146] E. D'Hoker, J. Estes, and M. Gutperle, "Ten-dimensional supersymmetric Janus solutions," Nucl. Phys. B 757 [\(2006\) 79–116,](http://dx.doi.org/10.1016/j.nuclphysb.2006.08.017) [arXiv:hep-th/0603012](http://arxiv.org/abs/hep-th/0603012).
- [147] E. D'Hoker, J. Estes, and M. Gutperle, "Interface Yang-Mills, supersymmetry, and Janus," [Nucl. Phys. B](http://dx.doi.org/10.1016/j.nuclphysb.2006.07.001) 753 (2006) 16–41, [arXiv:hep-th/0603013](http://arxiv.org/abs/hep-th/0603013).

- <span id="page-149-0"></span>[148] E. D'Hoker, J. Estes, and M. Gutperle, "Exact half-BPS Type IIB interface solutions. I. Local solution and supersymmetric Janus," JHEP 06 [\(2007\) 021,](http://dx.doi.org/10.1088/1126-6708/2007/06/021) [arXiv:0705.0022 \[hep-th\]](http://arxiv.org/abs/0705.0022).
- <span id="page-149-1"></span>[149] D. Gaiotto, "Surface Operators in N = 2 4d Gauge Theories," JHEP 11 [\(2012\) 090,](http://dx.doi.org/10.1007/JHEP11(2012)090) [arXiv:0911.1316 \[hep-th\]](http://arxiv.org/abs/0911.1316).
- <span id="page-149-2"></span>[150] K. Goto and T. Okuda, "Janus interface in two-dimensional supersymmetric gauge theories," JHEP 10 [\(2019\) 045,](http://dx.doi.org/10.1007/JHEP10(2019)045) [arXiv:1810.03247 \[hep-th\]](http://arxiv.org/abs/1810.03247).
- <span id="page-149-3"></span>[151] L. Anderson and M. M. Roberts, "Supersymmetric space-time symmetry breaking sources," JHEP 01 [\(2021\) 050,](http://dx.doi.org/10.1007/JHEP01(2021)050) [arXiv:1912.08961 \[hep-th\]](http://arxiv.org/abs/1912.08961).
- [152] U. Gran, J. Gutowski, and G. Papadopoulos, "Geometry of all supersymmetric four-dimensional N = 1 supergravity backgrounds," JHEP 06 [\(2008\) 102,](http://dx.doi.org/10.1088/1126-6708/2008/06/102) [arXiv:0802.1779 \[hep-th\]](http://arxiv.org/abs/0802.1779).
- [153] I. Arav, J. P. Gauntlett, M. Roberts, and C. Rosen, "Spatially modulated and supersymmetric deformations of ABJM theory," JHEP 04 [\(2019\) 099,](http://dx.doi.org/10.1007/JHEP04(2019)099) [arXiv:1812.11159 \[hep-th\]](http://arxiv.org/abs/1812.11159).
- [154] K. K. Kim and O.-K. Kwon, "Janus ABJM Models with Mass Deformation," [JHEP](http://dx.doi.org/10.1007/JHEP08(2018)082) 08 [\(2018\) 082,](http://dx.doi.org/10.1007/JHEP08(2018)082) [arXiv:1806.06963 \[hep-th\]](http://arxiv.org/abs/1806.06963).
- [155] K. K. Kim, Y. Kim, O.-K. Kwon, and C. Kim, "Aspects of Massive ABJM Models with Inhomogeneous Mass Parameters," JHEP 12 [\(2019\) 153,](http://dx.doi.org/10.1007/JHEP12(2019)153) [arXiv:1910.05044](http://arxiv.org/abs/1910.05044) [\[hep-th\]](http://arxiv.org/abs/1910.05044).
- [156] I. Arav, K. C. M. Cheung, J. P. Gauntlett, M. M. Roberts, and C. Rosen, "Superconformal RG interfaces in holography," JHEP 11 [\(2020\) 168,](http://dx.doi.org/10.1007/JHEP11(2020)168) [arXiv:2007.07891 \[hep-th\]](http://arxiv.org/abs/2007.07891).
- [157] I. Arav, K. C. M. Cheung, J. P. Gauntlett, M. M. Roberts, and C. Rosen, "Spatially modulated and supersymmetric mass deformations of N = 4 SYM," JHEP 11 [\(2020\)](http://dx.doi.org/10.1007/JHEP11(2020)156) [156,](http://dx.doi.org/10.1007/JHEP11(2020)156) [arXiv:2007.15095 \[hep-th\]](http://arxiv.org/abs/2007.15095).
- <span id="page-149-4"></span>[158] I. Arav, K. C. M. Cheung, J. P. Gauntlett, M. M. Roberts, and C. Rosen, "A new family of AdS<sup>4</sup> S-folds in type IIB string theory," JHEP 05 [\(2021\) 222,](http://dx.doi.org/10.1007/JHEP05(2021)222) [arXiv:2101.07264 \[hep-th\]](http://arxiv.org/abs/2101.07264).

- <span id="page-150-0"></span>[159] E. D'Hoker, J. Estes, M. Gutperle, and D. Krym, "Janus solutions in M-theory," JHEP 06 [\(2009\) 018,](http://dx.doi.org/10.1088/1126-6708/2009/06/018) [arXiv:0904.3313 \[hep-th\]](http://arxiv.org/abs/0904.3313).
- <span id="page-150-1"></span>[160] N. Bobev, K. Pilch, and N. P. Warner, "Supersymmetric Janus Solutions in Four Dimensions," JHEP 06 [\(2014\) 058,](http://dx.doi.org/10.1007/JHEP06(2014)058) [arXiv:1311.4883 \[hep-th\]](http://arxiv.org/abs/1311.4883).
- <span id="page-150-2"></span>[161] M. Bullimore, H.-C. Kim, and T. Lukowski, "Expanding the Bethe/Gauge Dictionary," JHEP 11 [\(2017\) 055,](http://dx.doi.org/10.1007/JHEP11(2017)055) [arXiv:1708.00445 \[hep-th\]](http://arxiv.org/abs/1708.00445).
- <span id="page-150-3"></span>[162] M. Herbst, K. Hori, and D. Page, "Phases Of N=2 Theories In 1+1 Dimensions With Boundary," [arXiv:0803.2045 \[hep-th\]](http://arxiv.org/abs/0803.2045).
- [163] J. Clingempeel, B. Le Floch, and M. Romo, "Brane transport in anomalous (2,2) models and localization," [arXiv:1811.12385 \[hep-th\]](http://arxiv.org/abs/1811.12385).
- [164] I. Brunner, F. Klos, and D. Roggenkamp, "Phase transitions in GLSMs and defects," [arXiv:2101.12315 \[hep-th\]](http://arxiv.org/abs/2101.12315).
- <span id="page-150-4"></span>[165] I. Brunner, L. Krumpeck, and D. Roggenkamp, "Defects and phase transitions to geometric phases of abelian GLSMs," [arXiv:2109.04124 \[hep-th\]](http://arxiv.org/abs/2109.04124).
- <span id="page-150-5"></span>[166] D. Galakhov, "On Supersymmetric Interface Defects, Brane Parallel Transport, Order-Disorder Transition and Homological Mirror Symmetry," [arXiv:2105.07602](http://arxiv.org/abs/2105.07602) [\[hep-th\]](http://arxiv.org/abs/2105.07602).
- <span id="page-150-6"></span>[167] K. Sugiyama and Y. Yoshida, "Supersymmetric indices on I × T 2 , elliptic genera and dualities with boundaries," Nucl. Phys. B 960 [\(2020\) 115168,](http://dx.doi.org/10.1016/j.nuclphysb.2020.115168) [arXiv:2007.07664](http://arxiv.org/abs/2007.07664) [\[hep-th\]](http://arxiv.org/abs/2007.07664).
- <span id="page-150-7"></span>[168] S. R. Coleman, "The Uses of Instantons," Subnucl. Ser. 15 (1979) 805.
- <span id="page-150-8"></span>[169] N. Nekrasov, Tying up instantons with anti-instantons, [pp. 351–388.](http://dx.doi.org/10.1142/9789813233867_0018) 2018. [arXiv:1802.04202 \[hep-th\]](http://arxiv.org/abs/1802.04202).
- <span id="page-150-9"></span>[170] D. Shenfeld, Abelianization of Stable Envelopes in Symplectic Resolutions. PhD thesis, Princeton University, 2013.
- <span id="page-150-10"></span>[171] H. Dinkins, "Elliptic stable envelopes of affine type A quiver varieties," 2021.
- <span id="page-150-11"></span>[172] H. Nakajima, "Lectures on Hilbert Schemes of Points on Surfaces," AMS, University Lecture Series 18 (1999) 132 pp.

- <span id="page-151-0"></span>[173] H. W. Braden and N. A. Nekrasov, "Space-time foam from noncommutative instantons," [Commun. Math. Phys.](http://dx.doi.org/10.1007/s00220-004-1127-2) 249 (2004) 431–448, [arXiv:hep-th/9912019](http://arxiv.org/abs/hep-th/9912019).
- <span id="page-151-1"></span>[174] G. Cuomo, Z. Komargodski, and A. Raviv-Moshe, "Renormalization Group Flows on Line Defects," [arXiv:2108.01117 \[hep-th\]](http://arxiv.org/abs/2108.01117).
- <span id="page-151-2"></span>[175] R. Thorngren and Y. Wang, "Anomalous symmetries end at the boundary," [JHEP](http://dx.doi.org/10.1007/JHEP09(2021)017) 09 [\(2021\) 017,](http://dx.doi.org/10.1007/JHEP09(2021)017) [arXiv:2012.15861 \[hep-th\]](http://arxiv.org/abs/2012.15861).
- <span id="page-151-3"></span>[176] J. Gomis and S. Lee, "Exact Kahler Potential from Gauge Theory and Mirror Symmetry," JHEP 04 [\(2013\) 019,](http://dx.doi.org/10.1007/JHEP04(2013)019) [arXiv:1210.6022 \[hep-th\]](http://arxiv.org/abs/1210.6022).
- <span id="page-151-4"></span>[177] Y. Imamura and S. Yokoyama, "Index for three dimensional superconformal field theories with general R-charge assignments," JHEP 04 [\(2011\) 007,](http://dx.doi.org/10.1007/JHEP04(2011)007) [arXiv:1101.0557](http://arxiv.org/abs/1101.0557) [\[hep-th\]](http://arxiv.org/abs/1101.0557).
- <span id="page-151-5"></span>[178] C. Closset, T. T. Dumitrescu, G. Festuccia, and Z. Komargodski, "Supersymmetric Field Theories on Three-Manifolds," JHEP 05 [\(2013\) 017,](http://dx.doi.org/10.1007/JHEP05(2013)017) [arXiv:1212.3388](http://arxiv.org/abs/1212.3388) [\[hep-th\]](http://arxiv.org/abs/1212.3388).
- [179] C. Closset, T. T. Dumitrescu, G. Festuccia, and Z. Komargodski, "The Geometry of Supersymmetric Partition Functions," JHEP 01 [\(2014\) 124,](http://dx.doi.org/10.1007/JHEP01(2014)124) [arXiv:1309.5876](http://arxiv.org/abs/1309.5876) [\[hep-th\]](http://arxiv.org/abs/1309.5876).
- <span id="page-151-6"></span>[180] C. Closset, T. T. Dumitrescu, G. Festuccia, and Z. Komargodski, "From Rigid Supersymmetry to Twisted Holomorphic Theories," [Phys. Rev. D](http://dx.doi.org/10.1103/PhysRevD.90.085006) 90 no. 8, (2014) [085006,](http://dx.doi.org/10.1103/PhysRevD.90.085006) [arXiv:1407.2598 \[hep-th\]](http://arxiv.org/abs/1407.2598).
- <span id="page-151-7"></span>[181] S. Shadchin, "On F-term contribution to effective action," JHEP 08 [\(2007\) 052,](http://dx.doi.org/10.1088/1126-6708/2007/08/052) [arXiv:hep-th/0611278](http://arxiv.org/abs/hep-th/0611278).
- [182] T. Dimofte, S. Gukov, and L. Hollands, "Vortex Counting and Lagrangian 3-manifolds," [Lett. Math. Phys.](http://dx.doi.org/10.1007/s11005-011-0531-8) 98 (2011) 225–287, [arXiv:1006.0977 \[hep-th\]](http://arxiv.org/abs/1006.0977).
- [183] G. Bonelli, A. Tanzini, and J. Zhao, "Vertices, Vortices and Interacting Surface Operators," JHEP 06 [\(2012\) 178,](http://dx.doi.org/10.1007/JHEP06(2012)178) [arXiv:1102.0184 \[hep-th\]](http://arxiv.org/abs/1102.0184).
- [184] G. Bonelli, A. Sciarappa, A. Tanzini, and P. Vasko, "Vortex partition functions, wall crossing and equivariant Gromov-Witten invariants," [Commun. Math. Phys.](http://dx.doi.org/10.1007/s00220-014-2193-8) 333 [no. 2, \(2015\) 717–760,](http://dx.doi.org/10.1007/s00220-014-2193-8) [arXiv:1307.5997 \[hep-th\]](http://arxiv.org/abs/1307.5997).

- [185] C. Beem, T. Dimofte, and S. Pasquetti, "Holomorphic Blocks in Three Dimensions," JHEP 12 [\(2014\) 177,](http://dx.doi.org/10.1007/JHEP12(2014)177) [arXiv:1211.1986 \[hep-th\]](http://arxiv.org/abs/1211.1986).
- <span id="page-152-0"></span>[186] S. Gukov, D. Pei, P. Putrov, and C. Vafa, "BPS spectra and 3-manifold invariants," [J. Knot Theor. Ramifications](http://dx.doi.org/10.1142/S0218216520400039) 29 no. 02, (2020) 2040003, [arXiv:1701.06567](http://arxiv.org/abs/1701.06567) [\[hep-th\]](http://arxiv.org/abs/1701.06567).
- <span id="page-152-1"></span>[187] N. Nekrasov, "Open-closed (little) string duality and Chern-Simons-Bethe/gauge correspondence," lecture given at Strings-Math ?2017, Hamburg (24?28 July 2017) . [https://stringmath2017.desy.de/sites/sites\\_conferences/site\\_](https://stringmath2017.desy.de/sites/sites_conferences/site_stringmath2017/content/e45470/e56510/e56566/SM-Nekrasov.pdf) [stringmath2017/content/e45470/e56510/e56566/SM-Nekrasov.pdf](https://stringmath2017.desy.de/sites/sites_conferences/site_stringmath2017/content/e45470/e56510/e56566/SM-Nekrasov.pdf).
- <span id="page-152-2"></span>[188] N. Nekrasov and V. Pestun, "Seiberg-Witten geometry of four dimensional N=2 quiver gauge theories," [arXiv:1211.2240 \[hep-th\]](http://arxiv.org/abs/1211.2240).
- [189] N. Nekrasov, V. Pestun, and S. Shatashvili, "Quantum geometry and quiver gauge theories," [Commun. Math. Phys.](http://dx.doi.org/10.1007/s00220-017-3071-y) 357 no. 2, (2018) 519–567, [arXiv:1312.6689](http://arxiv.org/abs/1312.6689) [\[hep-th\]](http://arxiv.org/abs/1312.6689).
- <span id="page-152-4"></span>[190] N. Lee and N. Nekrasov, "Quantum spin systems and supersymmetric gauge theories. Part I," JHEP 03 [\(2021\) 093,](http://dx.doi.org/10.1007/JHEP03(2021)093) [arXiv:2009.11199 \[hep-th\]](http://arxiv.org/abs/2009.11199).
- <span id="page-152-3"></span>[191] S. Jeong, N. Lee, and N. Nekrasov, "Intersecting defects in gauge theory, quantum spin chains, and Knizhnik-Zamolodchikov equations," [arXiv:2103.17186 \[hep-th\]](http://arxiv.org/abs/2103.17186).
- <span id="page-152-5"></span>[192] M. Dedushenko and D. Gaiotto, "Correlators on the wall and sl<sup>n</sup> spin chain," [arXiv:2009.11198 \[hep-th\]](http://arxiv.org/abs/2009.11198).
- <span id="page-152-6"></span>[193] N. Dorey, S. Lee, and T. J. Hollowood, "Quantization of Integrable Systems and a 2d/4d Duality," JHEP 10 [\(2011\) 077,](http://dx.doi.org/10.1007/JHEP10(2011)077) [arXiv:1103.5726 \[hep-th\]](http://arxiv.org/abs/1103.5726).
- <span id="page-152-7"></span>[194] D. Gaiotto, G. W. Moore, and E. Witten, "An Introduction To The Web-Based Formalism," [arXiv:1506.04086 \[hep-th\]](http://arxiv.org/abs/1506.04086).
- <span id="page-152-8"></span>[195] D. Gaiotto, G. W. Moore, and E. Witten, "Algebra of the Infrared: String Field Theoretic Structures in Massive N = (2, 2) Field Theory In Two Dimensions," [arXiv:1506.04087 \[hep-th\]](http://arxiv.org/abs/1506.04087).
- <span id="page-152-9"></span>[196] F. Benini and W. Peelaers, "Higgs branch localization in three dimensions," [JHEP](http://dx.doi.org/10.1007/JHEP05(2014)030) 05 [\(2014\) 030,](http://dx.doi.org/10.1007/JHEP05(2014)030) [arXiv:1312.6078 \[hep-th\]](http://arxiv.org/abs/1312.6078).