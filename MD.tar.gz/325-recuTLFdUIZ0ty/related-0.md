## **Lectures on K-theoretic computations in enumerative geometry**

# Andrei Okounkov

## **Contents**

| 1 | Aims & Scope       | 2                                          |    |
|---|--------------------|--------------------------------------------|----|
|   | 1.1                | K-theoretic enumerative geometry           | 2  |
|   | 1.2                | Quantum K-theory of Nakajima varieties     | 4  |
|   | 1.3                | K-theoretic Donaldson-Thomas theory        | 7  |
|   | 1.4                | Old vs. new                                | 11 |
|   | 1.5                | Acknowledgements                           | 12 |
| 2 | Before we begin    | 13                                         |    |
|   | 2.1                | Symmetric and exterior algebras            | 13 |
|   | 2.2                | ˝<br>KGpXq and K<br>GpXq                   | 16 |
|   | 2.3                | Localization                               | 19 |
|   | 2.4                | Rigidity                                   | 22 |
| 3 |                    | The Hilbert scheme of points of 3-folds    | 23 |
|   | 3.1                | Our very first DT moduli space             | 23 |
|   | 3.2                | vir and<br>Opvir<br>O                      | 25 |
|   | 3.3                | Nekrasov's formula                         | 29 |
|   | 3.4                | Tangent bundle and localization            | 34 |
|   | 3.5                | Proof of Nekrasov's formula                | 41 |
| 4 | Nakajima varieties | 49                                         |    |
|   | 4.1                | Algebraic symplectic reduction             | 49 |
|   | 4.2                | Nakajima quiver varieties [35, 62, 63]     | 50 |
|   | 4.3                | Quasimaps to Nakajima varieties            | 51 |
| 5 | Symmetric powers   | 55                                         |    |
|   | 5.1                | PT theory for smooth curves                | 55 |
|   | 5.2                | Proof of Theorem 5.1.16                    | 59 |
|   | 5.3                | Hilbert schemes of surfaces and threefolds | 60 |
| 6 | More on quasimaps  | 65                                         |    |
|   | 6.1                | Balanced classes and square roots          | 65 |
|   | 6.2                | Relative quasimaps in an example           | 68 |
|   | 6.3                | Stable reduction for relative quasimaps    | 73 |

Received by the editors Spring and Summer 2015. *Key words and phrases.* Park City Mathematics Institute.

|    | 6.4                                                 | Moduli of relative quasimaps               | 78  |
|----|-----------------------------------------------------|--------------------------------------------|-----|
|    | 6.5                                                 | Degeneration formula and the glue operator | 81  |
| 7  | Nuts and bolts                                      | 86                                         |     |
|    | 7.1                                                 | The Tube                                   | 86  |
|    | 7.2                                                 | The Vertex                                 | 89  |
|    | 7.3                                                 | The index limit                            | 92  |
|    | 7.4                                                 | Cap and capping                            | 93  |
|    | 7.5                                                 | Large framing vanishing                    | 94  |
| 8  | Difference equations                                | 97                                         |     |
|    | 8.1                                                 | Shifts of Kähler variables                 | 97  |
|    | 8.2                                                 | Shifts of equivariant variables            | 99  |
|    | 8.3                                                 | Difference equations for vertices          | 103 |
| 9  | Stable envelopes and quantum groups                 | 106                                        |     |
|    | 9.1                                                 | K-theoretic stable envelopes               | 106 |
|    | 9.2                                                 | Triangle lemma and braid relations         | 110 |
|    | 9.3                                                 | Actions of quantum group                   | 115 |
| 10 | Quantum Knizhnik-Zamolodchikov equations            |                                            |     |
|    | 10.1 Commuting difference operators from R-matrices | 118                                        |     |
|    | 10.2 Minuscule shifts and qKZ                       |                                            |     |
|    | 10.3 Glue operator in the stable basis              |                                            |     |
|    | 10.4 Proof of Theorem 10.2.11                       | 126                                        |     |

## **1. Aims & Scope**

## **1.1. K-theoretic enumerative geometry**

**1.1.1.** These lectures are for graduate students who want to learn how to do the *computations* from the title. Here I put emphasis on computations because I think it is very important to keep a connection between abstract notions of algebraic geometry, which can be very abstract indeed, and something we can see, feel, or test with code.

While it is a challenge to adequately illustrate a modern algebraic geometry narrative, one can become familiar with main characters of these notes by working out examples, and my hope is that these notes will be placed alongside a pad of paper, a pencil, an eraser, and a symbolic computation interface.

**1.1.2.** Modern enumerative geometry is not so much about numbers as it is about deeper properties of the moduli spaces that parametrize the geometric objects being enumerated.

Of course, once a relevant moduli space **M** is constructed one can study it as one would study any other algebraic scheme (or stack, depending on the context). Doing this in any generality would appear to be seriously challenging, as even

the dimension of some of the simplest moduli spaces considered here (namely, the Hilbert scheme of points of 3-folds) is not known.

**1.1.3.** A productive middle ground is to compute the Euler characteristics χpFq of naturally defined coherent sheaves F on **M**, as representations of a group G of automorphisms of the problem. This goes beyond intersecting natural cycles in **M**, which is the realm of the traditional enumerative geometry, and is a nutshell description of equivariant K-theoretic enumerative geometry.

The group G will typically be connected and reductive, and the G-character of χpFq will be a Laurent polynomial on the maximal torus T Ă G provided χpFq is a finite-dimensional virtual G-module. Otherwise, it will be a rational function on T. In either case, it is a very concrete mathematical object, which can be turned and spun to be seen from many different angles.

**1.1.4.** Enumerative geometry has received a very significant impetus from modern high energy physics, and this is even more true of its K-theoretic version. From its very origins, K-theory has been inseparable from indices of differential operators and related questions in mathematical quantum mechanics. For a mathematical physicist, the challenge is to study quantum systems with infinitely many degrees of freedom, systems that describe fluctuating objects that have some spatial extent.

While the dynamics of such systems is, obviously, very complex, their vacua, especially supersymmetric vacua, i.e. the quantum states in the kernel of a certain infinite-dimensional Dirac operator

$$\mathcal{H}_{\text{even}} \xrightarrow{\overline{\mathcal{D}}} \mathcal{H}_{\text{odd}}$$

may often be understood in finite-dimensional terms. In particular, the computations of supertraces

$$\operatorname{str} e^{-\beta \not \!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!$$

of natural operators A commuting with D{ may be equated with the kind of computations that is done in these notes.

Theoretical physicists developed very powerful and insightful ways of thinking about such problems and theoretical physics serves as a very important source of both inspiration and applications for the mathematics pursued here. We will see many examples of this below.

**1.1.7.** What was said so far encompasses a whole universe of physical and enumerative contexts. While resting on certain common principles, this universe is much too rich and diverse to be reasonably discussed here.

These lectures are written with a particular goal in mind, which is to introduce a student to computations in two intertwined subjects, namely:

- K-theoretic Donaldson-Thomas theory, and
- quantum K-theory of Nakajima varieties.

Some key features of these theories, and of the relationship between them, may be summarized as follows.

### **1.2. Quantum K-theory of Nakajima varieties**

**1.2.1.** Nakajima varieties [62,63] are associated to a quiver (that is, a finite graph with possibly parallel edges and loops), a pair of dimension vectors, and a choice of stability chamber. They form a remarkable family of *equivariant symplectic resolutions* [44] and have found many geometric and representation-theoretic applications. Their construction will be recalled in Section 4.

For quivers of affine ADE type, and a suitable choice of stability, Nakajima varieties are the moduli spaces of framed coherent sheaves on the corresponding ADE surfaces, e.g. on **C** 2 for a quiver with one vertex and one loop. These moduli spaces play a very important role in supersymmetric gauge theories and algebraic geometry.

For general quivers, Nakajima varieties share many properties of the moduli spaces of sheaves on a symplectic surface. In fact, from their construction, they may be interpreted as moduli spaces of stable objects in certain abelian categories which have the same duality properties as coherent sheaves on a symplectic surface.

**1.2.2.** From many different perspectives, rational curves in Nakajima varieties are of particular interest. Geometrically, a map

curve 
$$C \rightarrow Moduli$$
 of sheaves on a surface S

produces a coherent sheaf on a threefold C ˆ S. One thus expects a relation between enumerative geometry of sheaves on threefolds fibered in ADE surfaces and enumerative geometry of maps from a fixed curve to affine ADE Nakajima varieties.

Such a relation indeed exists and has been already profitably used in cohomology [57,58,71,72]. For it to work well, it is important that the fibers are symplectic. Also, because the source C of the map is fixed and doesn't vary in moduli, it can be taken to be a rational curve, or a union of rational curves.

Rational curves in other Nakajima varieties lead to enumerative problems of similar 3-dimensional flavor, even when they are lacking a direct geometric interpretations as counting sheaves on some threefold.

**1.2.3.** In cohomology, counts of rational curves in a Nakajima variety X are conveniently packaged in terms of equivariant *quantum cohomology*, which is a certain deformation of the cup product in H ' <sup>G</sup>pX<sup>q</sup> with deformation base <sup>H</sup><sup>2</sup> pXq. A related structure is the equivariant *quantum connection*, or Dubrovin connection, on the trivial  $H_G^{\bullet}(X)$  bundle with base  $H^2(X)$ .

While such packaging of enumerative information may be performed for an abstract algebraic variety X, for Nakajima varieties these structures are described in the language of geometric representation theory, and namely in terms of an action of a certain Yangian  $Y(\mathfrak{g})$  on  $H_G^{\bullet}(X)$ . In particular, the quantum connection is identified with the trigonometric Casimir connection for  $Y(\mathfrak{g})$ , studied in [82] for finite-dimensional Lie algebras, see also [81].

The construction of the required Yangian  $Y(\mathfrak{g})$ , and the identification of quantum structures in terms of  $Y(\mathfrak{g})$ , are the main results of [59]. That work was inspired by conjectures put forward by Nekrasov and Shatashvili [68,69], on the one hand, and by Bezrukavnikov and his collaborators (see e.g. [25]), on the other.

A similar geometric representation theory description of quantum cohomology is expected for all equivariant symplectic resolutions, and perhaps a little bit beyond, see for example [31]. Further, there are conjectural links, due to Bezrukavnikov and his collaborators, between quantum connections for symplectic resolutions X and representation theory of their quantizations (see, for example, [8,10–12,43]), their derived autoequivalences etc.

**1.2.4.** The extension [60] of our work [59] with D. Maulik to K-theory requires several new ideas, as certain arguments that are used again and again in [59] are simply not available in K-theory. For instance, in equivariant cohomology, a proper integral of correct dimension is a nonequivariant constant, which may be computed using an arbitrary specialization of the equivariant parameters (it is typically very convenient to set the weight h of the symplectic form to 0 and send all other equivariant variables to infinity).

By contrast, in equivariant K-theory, the only automatic conclusion about a proper pushforward to a point is that it is a Laurent polynomial in the equivariant variables, and, most of the time, this cannot be improved. If this Laurent polynomial does not involve some equivariant variable variable  $\alpha$  then this is called *rigidity*, and is typically shown by a careful study of the  $\alpha^{\pm 1} \to \infty$  limit. We will see many variations on this theme below.

Also, very seldom there is rigidity with respect to the weight ħ of the symplectic form and nothing can be learned from making that weight trivial. Any argument that involves such step in cohomology needs to be modified, most notably the proof of the commutation of quantum connection with the difference Knizhnik-Zamolodchikov connection, see Sections 1.4 and 9 of [59]. In the logic of [59], quantum connection is characterized by this commutation property, so it is very important to lift the argument to K-theory.

One of the goals of these notes is to serve as an introduction to the additional techniques required for working in K-theory. In particular, the quantum Knizhnik-Zamolodchikov connection appears in Section 10.4 as the computation

of the shift operator corresponding to a minuscule cocharacter. Previously in Section 8.2 we construct a difference connection which shifts equivariant variables by cocharacters of the maximal torus and show it commutes with the K-theoretic upgrade of the quantum connection. That upgrade is a difference connection that shifts the Kähler variables

$$z \in H^2(X, \mathbb{C})/2\pi i H^2(X, \mathbb{Z})$$

by cocharacters of this torus, that is, by a lattice isomorphic to PicpXq. This quantum difference connection is constructed in Section 8.1.

**1.2.5.** Technical differences notwithstanding, the eventual description of quantum K-theory of Nakajima varieties is exactly what one might have guessed recognizing a general pattern in geometric representation theory. The Yangian Ypgq, which is a Hopf algebra deformation of Upg b **C**rtsq, is a first member of a hierarchy in which the Lie algebra

$$\mathfrak{g} \otimes \mathbb{C}[\mathfrak{t}] = \operatorname{Maps}(\mathbb{C}, \mathfrak{g})$$

is replaced, in turn, by a central extension of maps from

- the multiplicative group **C** <sup>ˆ</sup>, or
- an elliptic curve.

Geometric realizations of the corresponding quantum groups are constructed in equivariant cohomology, equivariant K-theory, and equivariant elliptic cohomology, respectively, see [60, 75] and also [1] for the construction of an elliptic quantum group from Nakajima varieties.

Here we are on the middle level of the hierarchy, where the quantum group is denoted Uh¯ pgˆq. The variable q is the deformation parameter; its geometric meaning is the equivariant weight of the symplectic form. For quivers of finite type, these are identical to Drinfeld-Jimbo quantum groups from textbooks. For other quivers, Uh¯ pgˆq is constructed in the style of Faddeev, Reshetikhin, and Takhtajan from geometrically constructed R-matrices, see [59]. In turn, the construction of R-matrices, that is, solutions of the Yang-Baxter equations with a spectral parameter, rests on the K-theoretic version of stable envelopes of [60]. We discuss those in Section 9.1.

Stable envelopes in K-theory differ from their cohomological ancestors in one important feature: they depend on an additional parameter, called *slope*, which is a choice of an alcove of a certain periodic hyperplane arrangement in PicpXq b**<sup>Z</sup> R**. This is the same data as appears, for instance, in the study of quantization of X over a field of large positive characteristic. A technical advantage of such slope dependence is a factorization of R-matrices into infinite product of certain *root* R*-matrices*, which generalizes the classical results obtained by Khoroshkin and Tolstoy in the case when the Lie algebra g is of finite dimension.

**1.2.6.** The identification of the quantum difference connection in term of Uh¯ pgˆq was long expected to be the lattice part of the quantum dynamical Weyl group action on KGpXq. For finite-dimensional Lie algebras, this object was studied by Etingof and Varchenko in [28] and many related papers, and it was shown in [5] to correctly degenerate to the Casimir connection in the suitable limit.

Intertwining operators between Verma modules, which is the main technical tool of [28], are only available for real simple roots and so don't yield a large enough dynamical Weyl group as soon as the quiver is not of finite type. However, using root R-matrices, one can define and study the quantum dynamical Weyl group for arbitrary quivers. This is done in [75]. Once available, a representationtheoretic identification of the quantum difference connections gives an essentially full control over the theory.

In these notes we stop where the analysis of [75] starts: we show that quantum connection commutes with qKZ, which is one of the key features of dynamical Weyl groups.

- **1.2.7.** The monodromy of the quantum difference connection is characterized in [1] in terms of an elliptic analog of Uh¯ pgˆq. The categorical meaning of the corresponding operators is an area of active current research.
- **1.2.8.** These notes are meant to be a partial sample of basic techniques and results, and this is not an attempt to write an A to Z technical manual on the subject, nor to present a panorama of geometric applications that these techniques have.

For instance, one of the most exciting topics in quantum K-theory of symplectic resolutions is the duality, known under many different names including "symplectic duality" or "3-dimensional mirror symmetry", see [65] for an introduction. Nakajima varieties may be interpreted as the moduli space of Higgs vacua in certain supersymmetric gauge theories, and the computations in their quantum K-theory may be interpreted as indices of the corresponding gauge theories on real 3-folds of the form C ˆ S 1 . A physical duality equates these indices for certain pairs of theories, exchanging the Kähler parameters on one side with the equivariant parameters on the other.

In the context of these notes, this means that an exchange of the Kähler and equivariant difference equations of Section 8, which may be studied as such and generalizes various dualities known in representation theory. This is just one example of a very interesting phenomenon that lies outside of the scope of these lectures.

### **1.3. K-theoretic Donaldson-Thomas theory**

**1.3.1.** Donaldson-Thomas theory, or DT theory for short, is an enumerative theory of sheaves on a fixed smooth quasiprojective threefold Y, which need not be Calabi-Yau to point out one frequent misconception. There are many categories similar to the category of coherent sheaves on a smooth threefold, and one can profitably study DT-style questions in that larger context. In fact, we already met

with such generalizations in the form of quantum K-theory of general Nakajima quiver varieties. Still, I consider sheaves on threefolds to be the core object of study in DT theories.

An example of a sheaf to have in mind could be the structure sheaf  $\mathcal{O}_C$  of a curve, or more precisely, a 1-dimensional subscheme,  $C \subset Y$ . The corresponding DT moduli space  $\mathbb{M}$  is the Hilbert scheme of curves in Y and what we want to compute from them is the K-theoretic version of counting curves in Y of given degree and arithmetic genus satisfying some further geometric constraints like incidence to a given point or tangency to a given divisor.

There exist other enumerative theories of curves, notably the Gromov-Witten theory, and, in cohomology, there is a rather nontrivial equivalence between the DT and GW counts, first conjectured in [55,56] and explored in many papers since. At present, it is not known whether the GW/DT correspondence may be lifted to K-theory, as one stumbles early on trying to mimic the DT computations on the GW side <sup>1</sup>, see for example the discussion in Section 6.1.13.

**1.3.2.** Instead, in K-theory there is a different set of challenging conjectures [67] which may serve as one of the goalposts for the development of the theory.

This time the conjectures relate DT counts of curves in Y to a very different kind of curve counts in a Calabi-Yau 5-fold Z which is a total space

(1.3.3) 
$$Z = \bigcup_{Y} , \quad \mathcal{L}_4 \otimes \mathcal{L}_5 = \mathcal{K}_Y,$$

of a direct sum of two line bundles on Y. One interesting feature of this correspondence is the following. One the DT side, one forms a generating function over all arithmetic genera and then its argument z becomes an element  $z \in \operatorname{Aut}(\mathsf{Z},\Omega^5)$  which acts by  $\operatorname{diag}(z,z^{-1})$  in the fibers of  $\mathcal{L}_4 \oplus \mathcal{L}_5$ . Here  $\Omega^5$  is the canonical holomorphic 5-form on Z.

A K-theoretic curve count in Z is naturally a virtual representation of the group  $\operatorname{Aut}(Z,\Omega^5)$  and, in particular, z has a trace in it which is a rational function. This rational function is then equated to something one computes on the DT side by summing over all arithmetic genera. We see it is a nontrivial operation and, also, that equivariant K-theory is the natural setting in which such operations make sense. More general conjectures proposed in [67] similarly identify certain equivariant variables for Y with variables that keep track of those curve degree for 5-folds that are lost in Y.

For various DT computations below, we will point out their 5-dimensional interpretation, but this will be the extent of our discussion of 5-dimensional curve counting. It is still in its infancy and not ready to be presented in an introductory

<sup>&</sup>lt;sup>1</sup>Clearly, the subject of these note has not even begun to settle, and our present view of many key phenomena throughout the paper may easily change overnight.

lecture series. It is quite different from either the DT or GW curve counting in that it lacks a parameter that keeps track of the curve genus. Curves of any genus are counted equally, but the notion of stability is set up so that that only finitely many genera contribute to any given count.

**1.3.4.** When faced with a general threefold Y, a natural instinct is to try to cut Y into simpler pieces from which the curve counts in Y may be reconstructed. There are two special scenarios in which this works really well, they can be labeled *degeneration* and *localization*.

In the first scenario, we put Y in a 1-parameter family  $\widetilde{Y}$  with a smooth total space

$$\begin{array}{cccc}
Y & & \widetilde{Y} & & & Y_1 \cup_D Y_2 \\
\downarrow & & & \downarrow & & \downarrow \\
1 & & & C & & & 0
\end{array}$$

so that a special fiber of this family is a union  $Y_1 \cup_D Y_2$  of two smooth 3-folds along a smooth divisor D. In this case the curve counts in Y may be reconstructed from certain refined curve counts in each of the  $Y_i$ 's. These refined counts keep track of the intersection of the curve with the divisor D and are called *relative* DT counts. The technical foundations of the subject are laid in [53]. We will get a sense how this works in Section 6.5.

The work of Levine and Pandharipande [50] supports the idea that using degenerations one should be able to reduce curve counting in general 3-folds to that in *toric* 3-folds. Papers by Maulik and Pandharipande [61] and by Pandharipande and Pixton [77] offer spectacular examples of this idea being put into action.

**1.3.5.** Curve counting in toric 3-folds may be broken into further pieces using equivariant localization. Localization is a general principle by which all computations in G-equivariant K-theory of  $\mathbb M$  depend only on the formal neighborhood of the T-fixed locus  $\mathbb M^T$ , where  $\mathbb T \subset \mathbb G$  is a maximal torus in a connected group  $\mathbb G$ . We will rely on localization again and again in these notes. Localization is particularly powerful when used in *both* directions, that is, going from the global geometry to the localized one and back, because each point of view has its own advantages and limitations.

A threefold Y is toric if  $T \cong (\mathbb{C}^{\times})^3$  acts with an open orbit on Y. It then follows that Y has finitely many orbits and, in particular, finitely many orbits of dimension  $\leq 1$ . Those are the fixed points and the T-invariant curves, and they correspond to the 1-skeleton of the toric polyhedron of Y. From the localization viewpoint, Y may very well be replaced by this 1-skeleton. All nonrelative curve counts in Y may be done in terms of certain 3- and 2-valent tensors, called vertices and edges, associated to fixed points and T-invariant curves, respectively. See, for example, [70] for a pictorial introduction.

The underlying vector space for these tensors is

- the equivariant K-theory of  $Hilb(\mathbb{C}^2, points)$ , or equivalently
- the standard Fock space, or the algebra of symmetric functions,

with an extension of scalars to include all equivariant variables as well as the variable z that keeps track of the arithmetic genus. Natural bases of this vector space are indexed by partitions and curve counts are obtained by contracting all indices, in great similarity to many TQFT computations.

In the basis of torus-fixed points of the Hilbert scheme, edges are simple diagonal tensors, while vertices are something complicated. More sophisticated bases spread the complexity more evenly.

**1.3.6.** These vertices and edges, and related objects, are the nuts and bolts of the theory and the ability to compute with them is a certain measure of professional skill in the subject.

A simple, but crucial observation is that the geometry of ADE surface fibrations captures all these vertices and edges <sup>2</sup>. This bridges DT theory with topics discussed in Section 1.2, and was already put to a very good use in [57].

In [57], there are two kind of vertices: *bare*, or standard, and *capped*. It is convenient to extend such taxonomy to general Nakajima varieties (or to general quasimap problems, for that matter). For general Nakajima varieties, in cohomology, the notion of a bare 1-leg vertex coincides with Givental's notion of I-function, and there is no real analog of two- or three-legged vertex for general Nakajima varieties <sup>3</sup>.

Bare and capped vertices are the same tensors expressed in two different bases, and which have different geometric meaning and different properties. In particular, capped 1-leg vertices are trivial, in that the contributions of all subscheme of nonminimal Euler characteristic cancel out. One can thus determine all vertices if one knows the transition matrix from bare vertices to the capped ones, commonly called the capping operator. The theory is built so that this operator is the fundamental solution of the quantum differential equation and this is how [57] works.

**1.3.7.** All these notions have a direct analog in K-theory and are the subject of Section 7. In fact, in the lift from cohomology to K-theory there is always at least a line bundle worth of natural ambiguities, and here we work with a certain specific twist  $\hat{\mathbb{O}}_{\text{vir}}$  of the virtual structure sheaf  $\mathbb{O}_{\text{vir}}$ . This object, which we call the symmetrized virtual structure sheaf, is discussed at many points in these lectures and has many advantages over the ordinary virtual structure sheaf. From the point of view of mathematical physics,  $\hat{\mathbb{O}}_{\text{vir}}$  rather than  $\mathbb{O}_{\text{vir}}$  is related to the index

<sup>&</sup>lt;sup>2</sup>In fact, formally, it suffices to understand  $A_n$ -surface fibrations with  $n \le 2$ .

<sup>&</sup>lt;sup>3</sup>The Hilbert scheme  $\operatorname{Hilb}(A_{n-1})$  of the  $A_{n-1}$ -surface is dual, in the sense of Section 1.2.8, to the moduli space M(n) of framed sheaves of rank n of  $A_0 \cong \mathbb{C}^2$ , which is a Nakajima variety for the quiver with one vertex and one loop. The splitting of the 1-leg vertex for the  $A_{n-1}$ -surface into n simpler vertices is a phenomenon which is dual to M(n) being an n-fold tensor product of  $\operatorname{Hilb}(\mathbb{C}^2)$  in the sense of [65]. For a general Nakajima variety, there is no direct analog of this.

of the relevant Dirac operator, and the roof over it is put to remind us of that. The importance of working with Op vir was emphasized already by Nekrasov in [66].

With this, one defines the bare and capped vertices as before and sees that the capping operator is the fundamental solution of the quantum difference equation. The specific choice of Op vir becomes important in the proof of triviality of 1-leg capped vertices, as this turns out to be a rigidity result which uses a certain selfduality of Op vir in a very essential way.

The same argument, in fact, proves more, it proves a similar triviality of capped vertices with descendents (an object also discussed in Section 7), once the framing is taken sufficiently large with respect to the descendent insertion. This makes it possible to determine bare vertices with descendents as well as the explicit correspondence between the descendents and relative insertions and is an area of active current research. The latter correspondence plays a very important role, in particular, in reducing DT counts in general threefolds to those in toric varieties as in [77] and it would be very desirable to have an explicit description of it.

## **1.4. Old vs. new**

**1.4.1.** These lectures are written for graduate students in the field and many of the pages that follow discuss topics that have become classical or at least standard in the subject. I tried to present them from an angle that is best suited for the applications I had in mind, but there is no way I could have achieved an improvement over several existing treatments in the literature.

In particular, my favorite introduction to equivariant K-theory is Chapter 5 of the book [22] by Chriss and Ginzburg. For a better introduction to Nakajima quiver varieties, see the lectures [35] by Ginzburg and, of course, the original papers [62, 63] by Nakajima. For a discussion of moduli spaces of quasimaps, I recommend the reader opens the paper [20]. For a general introduction to enumerative geometry, my favorite source are the lectures by Pandharipande in [40], even though those lectures discuss topics that are essentially disjoint from our goals here.

**1.4.2.** There is also a number of results in these notes that are new or, at least, not available in the existing literature. Among them are the following.

In Theorem 3.3.6, we prove a conjecture of Nekrasov [66] on the K-theoretic degree 0 DT invariants of smooth projective threefolds. This generalizes the cohomological result of [50, 56].

In Theorem 5.1.16, we prove the main conjecture of [67] for reduced smooth curves in threefolds. This is, of course, a very special case of the general conjectures made in [67], but perhaps adds to their credibility. In fact, we prove a statement on the level of derived categories of coherent sheaves and it would be extremely interesting to see if there is a similar upgrade of the K-theoretic conjectures made in [67].

In Theorem 7.5.23, we prove what we call the *large framing vanishing*, which is the absence of quantum corrections to the capped vertex with descendents once the framing (and polarization) is chose sufficiently large with respect to the given descendent. This has direct applications to an effective description of the correspondence between relative and absolute insertions in K-theoretic DT theory and is an area of active current research.

In Theorems 8.1.16 and 8.2.20 we give a simple construction of the difference operators that shift the Kähler and equivariant variables in certain building blocks of the theory. Many yeas ago, Givental initiated a very broad program of developing quantum K-theory and, in particular, the paper [37] gives a very general proof of the existence of quantum difference equations in quantum K-theory. In this paper, we work with quasimaps instead of the moduli spaces of stable maps, but it is entirely possible that the methods of [37] can be adapted to work in our situation. However, our situation is much more special than that in [37] because the classes Op vir in the K-theory of the moduli spaces that we consider behave much better than the virtual structure sheaves. This opens the door to many arguments that would not be available in general. Most importantly, we make a systematic use of self-dual features of Op vir, which often result in rigidity. In particular, the large framing vanishing is fundamentally a rigidity result.

Also, the special features of the theory presented here allow for an *explicit* determination of the corresponding difference equations in the language of representation theory. In particular, among the operators that shift the equivariant variables we find the quantum Knizhnik-Zamolodchikov equations, while the shifts of the Kähler variables are shown in [75] to come from the corresponding quantum dynamical Weyl group. The quantum Knizhnik-Zamolodchikov equations appear for a shift by a *minuscule* cocharacter of the torus. This is a direct K-theoretic analog of the computation in [59], although it requires a significantly more involved argument to be shown. This is done in Theorem 10.2.11.

## **1.5. Acknowledgements**

**1.5.1.** Both the old and the new parts of these notes owe a lot to many people. In the exposition of the fundamentals, I have been influenced by the sources cited above as well by countless other papers, lectures, and conversations. Evidently, I lack both the space and the qualification to make a detailed spectral analysis of these influences. For the same reason, I have made no attempt to put the material into anything resembling a historical perspective.

In the new part, I discuss bits of a rather large research project, various parts of which are joint with M. Aganagic, R. Bezrukavnikov, D. Maulik, N. Nekrasov, A. Smirnov, and others. It is hard to overestimate the influence this collaboration had on me and on my thinking about the subject. I must add P. Etingof to this list of major inspirations.

**1.5.2.** I am very grateful to the Simons foundation for being financially supported as a Simons investigator and to the Clay foundation for supporting me as a Clay Senior Scholar during PCMI 2015.

These note are based on the lectures I gave at Columbia in Spring of 2015 and at the Park City Mathematical Institute in Summer of 2015. I am very grateful to the participants of these lectures and to PCMI for its warm hospitality and intense intellectual atmosphere. Special thanks are to Rafe Mazzeo, Catherine Giesbrecht, Ian Morrison, and the anonymous referee.

## 2. Before we begin

The goal of this section is to have a brief abstract discussion of several construction in equivariant K-theory which will appear and reappear in more concrete situations below. This section is not meant to be an introduction to equivariant K-theory; Chapter 5 of [22] is highly recommended for that.

## 2.1. Symmetric and exterior algebras

**2.1.1.** Let T be a torus and V a finite dimensional T-module. Clearly, V is a direct sum of 1-dimensional T-modules, which are called the *weights* of V. The weights  $\mu$  are recorded by the character of V

$$\chi_V(t)=tr_V\,t=\sum t^\mu\,,\quad t\in T\,,$$

where repetitions are allowed among the  $\mu$ 's.

We denote by  $K_T$  or  $K_T(pt)$  the K-group of the category of T-modules. Of course, any exact sequence

$$0 \rightarrow V' \rightarrow V \rightarrow V'' \rightarrow 0$$

is anyhow split, so there is no need to impose the relation [V] = [V'] + [V''] in this case. The map  $V \mapsto \chi_V$  gives an isomorphism

$$K_T \cong \mathbb{Z}[t^{\mu}],$$

with the group algebra of the character lattice of the torus T. Multiplication in  $\mathbb{Z}[t^{\mu}]$  corresponds to  $\otimes$ -product in  $K_T$ .

**2.1.2.** For V as above, we can form its symmetric powers  $S^2V$ ,  $S^3V$ , ..., including  $S^0V=\mathbb{C}$ . These are GL(V)-modules and hence also T modules.

### Exercise 2.1.3. Prove that

(2.1.4) 
$$\sum_{k\geqslant 0} s^k \chi_{S^k V}(t) = \prod \frac{1}{1-s t^{\mu}}$$
$$= \exp \sum_{n>0} \frac{1}{n} s^n \chi_{V}(t^n).$$

We can view the functions in (2.1.4) as an element of  $K_T[[s]]$  or as a character of an infinite-dimensional graded T-module  $S^{\bullet}V$  with finite-dimensional graded subspaces, where s keeps track of the degree.

For the exterior powers we have, similarly,

### **Exercise 2.1.5.** Prove that

$$\sum_{k\geqslant 0} \left(-s\right)^k \chi_{\Lambda^k V}(t) = \prod \left(1-s\,t^\mu\right)$$

$$= \exp\left(-\sum_{n>0} \frac{1}{n} s^n \chi_V(t^n)\right).$$

The functions in (2.1.4) and (2.1.6) are reciprocal of each other. The representation-theoretic object behind this simple observation is known as the *Koszul complex*.

**Exercise 2.1.7.** Construct an GL(V)-equivariant exact sequence

$$(2.1.8) \cdots \to \Lambda^2 V \otimes S^{\bullet} V \to \Lambda^1 V \otimes S^{\bullet} V \to S^{\bullet} V \to \mathbb{C} \to 0$$

where  $\mathbb{C}$  is the trivial representation.

**Exercise 2.1.9.** Consider V as an algebraic variety on which GL(V) acts. Construct a GL(V)-equivariant resolution of the structure sheaf of  $0 \in V$  by vector bundles on V. Be careful not to get (2.1.8) as your answer.

**2.1.10.** Suppose  $\mu = 0$  is not a weight of V, which means that (2.1.4) does not have a pole at s = 1. Then we can set s = 1 in (2.1.4) and define

(2.1.11) 
$$\chi_{S^{\bullet}V} = \prod \frac{1}{1 - t^{\mu}} = \exp \sum_{n} \frac{1}{n} \chi_{V} t^{n},$$

This is a well-defined element of completed K-theory of T provided

$$||t^{\mu}|| < 1$$

for all weights of V with respect to some norm K<sub>T</sub>.

Alternatively, and with only the  $\mu \neq 0$  assumption on weights, (2.1.11) is a well-defined element of the *localized* K-theory of T

$$K_{T,localized} = \mathbb{Z}\left[t^{\nu}, \frac{1}{1-t^{\mu}}\right]$$

where we invert some or all elements  $1 - t^{\mu} \in K_T$ .

Since

$$K_T \hookrightarrow K_{T,localized}$$

characters of finite-dimensional modules may be computed in localization without loss of information. However, certain different infinite-dimensional modules become the same in localization, for example

Exercise 2.1.12. For V as above, check that

$$(2.1.13) S^{\bullet}V = (-1)^{rk} \operatorname{V} \det V^{\vee} \otimes S^{\bullet}V^{\vee}$$

in localization of  $K_T$ .

We will see, however, that this is a feature rather than a bug.

Exercise 2.1.14. Show that S<sup>•</sup> extends to a map

$$(2.1.15) K_{\mathsf{T}} \xrightarrow{\mathsf{S}^{\bullet}} K_{\mathsf{T,localized}}$$

where prime means that there is no zero weight, which satisfies

$$S^{\bullet}(V_1 \oplus V_2) = S^{\bullet}V_1 \otimes S^{\bullet}V_2$$

and, in particular,

(2.1.16) 
$$S^{\bullet}(-V) = \Lambda^{\bullet}V = \sum_{i} (-1)^{i} \Lambda^{i} V.$$

Here and in what follows, the symbol  $\Lambda^{\bullet}V$  is defined by (2.1.16) as the alternating sum of exterior powers.

**2.1.17.** The map (2.1.15) may be extended by continuity to a completion of  $K_T$  with respect to a suitable norm. This gives a compact way to write infinite products, for example

$$S^{\bullet} \frac{a-b}{1-q} = \prod_{n>0} \frac{1-q^n b}{1-q^n a},$$

which converges in any norm  $\|\cdot\|$  such that  $\|q\| < 1$ .

Exercise 2.1.18. Check that

$$S^{\bullet}\frac{\mathfrak{a}}{(1-\mathfrak{q})^{k+1}} = \prod_{n\geqslant 0} (1-\mathfrak{q}^n\mathfrak{a})^{-\binom{k+n}{n}}\,.$$

**2.1.19.** The map S<sup>•</sup> is also known under many aliases, including *plethystic exponential*. Its inverse is known, correspondingly, as the plethystic logarithm.

Exercise 2.1.20. Prove that the inverse to S° is given by the formula

$$\chi_V(t) = \sum_{n>0} \frac{\mu(n)}{n} \ln \chi_{S^{\bullet}V}(t^n)$$

where  $\mu$  is the *Möbius function* 

$$\mu(n) = \begin{cases} (-1)^{\text{\# of prime factors}}, & n \text{ squarefree} \\ 0, & \text{otherwise}. \end{cases}$$

The relevant property of the Möbius function is that it gives the matrix elements of  $C^{-1}$  where the matrix  $C=(C_{ij})_{i,j\in\mathbb{N}}$  is defined by

$$C_{ij} = \begin{cases} 1, & i|j \\ 0, & \text{otherwise} . \end{cases}$$

In other words,  $\mu$  is the Möbius function of the set  $\mathbb N$  partially ordered by divisibility, see [80].

**2.1.21.** If the determinant of V is a square as a character of T, we define

(2.1.22) 
$$\hat{S}^{\bullet}V = (\det V)^{1/2} S^{\bullet}$$

which by (2.1.13) satisfies

$$\widehat{\mathsf{S}}^{\bullet}\mathsf{V}^{\vee} = (-1)^{\operatorname{rk}\mathsf{V}}\,\widehat{\mathsf{S}}^{\bullet}\mathsf{V}.$$

Somewhat repetitively, it may be called the symmetrized symmetric algebra.

2.2. 
$$K_G(X)$$
 and  $K_G^{\circ}(X)$ 

**2.2.1.** Let a reductive group G act on a scheme X. We denote by  $K_G(X)$  the K-group of the category of G-equivariant coherent sheaves on X. Replacing general coherent sheaves by locally free ones, that is, by G-equivariant vector bundles on X, gives another group  $K_G^{\circ}(X)$  with a natural homomorphism

$$(2.2.2) K_{G}^{\circ}(X) \rightarrow K_{G}(X).$$

Remarkably and conveniently, (2.2.2) is is an isomorphism if X is nonsingular. In other words, every coherent sheaf on a nonsingular variety is *perfect*, which means it admits a locally free resolution of finite length, see for example Section B.8 in [33].

**Exercise 2.2.3.** Consider  $X=\{x_1x_2=0\}\subset \mathbb{C}^2$  with the action of the maximal torus

$$\mathsf{T} = \left\{ \begin{pmatrix} \mathsf{t}_1 & \\ & \mathsf{t}_2 \end{pmatrix} \right\} \subset \mathsf{GL}(2)\,.$$

Let  $\mathcal{F}=\mathfrak{O}_0$  be the structure sheaf of the origin  $0\in X$ . Compute the minimal T-equivariant resolution

$$\cdots \rightarrow \mathbb{R}^{-2} \rightarrow \mathbb{R}^{-1} \rightarrow \mathbb{R}^0 \rightarrow \mathfrak{F} \rightarrow 0$$

of  $\mathcal{F}$  by sheaves of the form

$$\mathcal{R}^{-i} = \mathcal{O}_{\mathbf{X}} \otimes \mathbf{R}_{i}$$
,

where  $R_{\mathfrak{i}}$  is a finite-dimensional T-module. Observe from the resolution that the groups

$$(2.2.4) \hspace{1cm} \text{Tor}_{\mathfrak{i}}(\mathfrak{F},\mathfrak{F}) \stackrel{\text{def}}{=} H^{-\mathfrak{i}}(\mathfrak{R}^{\bullet} \otimes \mathfrak{F}) = R_{\mathfrak{i}}$$

are nonzero for all  $i \ge 0$  and conclude that  $\mathcal F$  is not in the image of  $K_T^\circ(X)$ . Also observe that

(2.2.5) 
$$\sum (-1)^{i} \chi_{\text{Tor}_{i}(\mathcal{F},\mathcal{F})} = \frac{\chi(\mathcal{F})^{2}}{\chi(\mathcal{O}_{X})} = \frac{(1 - t_{1}^{-1})(1 - t_{2}^{-1})}{1 - t_{1}^{-1}t_{2}^{-1}}$$

expanded in inverse powers of  $t_1$  and  $t_2$ .

Exercise 2.2.6. Generalize (2.2.5) to the case

$$X = \operatorname{Spec} \mathbb{C}[x_1, \dots, x_d] / I,$$
  
$$\mathcal{F} = \mathbb{C}[x_1, \dots, x_d] / I',$$

where  $I \subset I'$  are monomial ideals, that is, ideals generated by monomials in the variables  $x_i$ .

**2.2.7.** The domain and the source of the map (2.2.2) have different functorial properties with respect to G-equivariant morphisms

$$(2.2.8) f: X \to Y$$

of schemes.

The pushforward of a K-theory class  $[\mathfrak{G}]$  represented by a coherent sheaf  $\mathfrak{G}$  is defined as

$$f_*\left[\mathfrak{G}\right] = \sum_i (-1)^i \left[R^i f_* \mathfrak{G}\right].$$

We abbreviate  $f_*\mathcal{G} = f_*[\mathcal{G}]$  in what follows.

The length of the sum in (2.2.9) is bounded, e.g. by the dimension of X, but the terms, in general, are only quasicoherent sheaves on Y. If f is proper on the support of  $\mathcal G$  then this ensures  $f_*\mathcal G$  is coherent and thus lies in  $K_G(Y)$ . Additional hypotheses are required to conclude  $f_*\mathcal G$  is perfect. For an example, take  $\iota_*\mathcal O_0$  where

$$\iota: \{0\} \hookrightarrow \{x_1x_2 = 0\}$$

is the inclusion in Exercise 2.2.3.

**Exercise 2.2.10.** The group GL(2) acts naturally on  $\mathbb{P}^1 = \mathbb{P}(\mathbb{C}^2)$  and on line bundles  $\mathfrak{O}(k)$  over it. Push forward these line bundles under  $\mathbb{P}^1 \to \operatorname{pt}$  using an explicit T-invariant Čech covering of  $\mathbb{P}^1$ . Generalize to  $\mathbb{P}^n$ .

**2.2.11.** The pull-back of  $[\mathcal{E}] \in K_G(Y)$  is defined by

$$f^*\left[\boldsymbol{\xi}\right] = \sum (-1)^i \left[ \mathfrak{T}\! or_i^{\mathfrak{O}_Y}\! (\mathfrak{O}_X,\boldsymbol{\xi}) \right].$$

Here the terms are coherent, but there may be infinitely many of them, as is the case for  $\iota^* \mathcal{O}_0$  in our running example. To ensure the sum terminates we need some flatness assumptions, such as  $\mathcal{E}$  being locally free. In particular,

$$f^*: K_G^{\circ}(Y) \to K_G^{\circ}(X)$$

is defined for arbitrary f by simply pulling back vector bundles.

**Exercise 2.2.12.** Globalize the computation in Exercise 2.1.9 to compute  $\iota^* \mathcal{O}_X \in K_G(\mathcal{O}_X)$  for a G-equivariant inclusion

$$\iota: X \hookrightarrow Y$$

of a nonsingular subvariety X in a nonsingular variety Y.

**2.2.13.** Tensor product makes  $K_G^{\circ}(X)$  a ring and  $K_G(X)$  is a module over it. The projection formula

$$(2.2.14) f_*(\mathcal{F} \otimes f^* \mathcal{E}) = f_*(\mathcal{F}) \otimes \mathcal{E}$$

expresses the covariance of this module structure with respect to morphisms f.

**Exercise 2.2.15.** Write a proof of the projection formula.

Projection formula can be used to prove that a proper pushforward  $f_*\mathcal{G}$  is perfect if  $\mathcal{G}$  is flat over Y, see Theorem 8.3.8 in [30].

**2.2.16.** Let X be a scheme and  $X' \subset X$  a closed G-invariant subscheme. Then the sequence

$$(2.2.17) K_G(X') \to K_G(X) \to K_G(X \setminus X') \to 0$$

where all maps are the natural pushforwards, is exact, see e.g. Proposition 7 in [13] for a classical discussion. This is the beginning of a long exact sequence of higher K-groups.

**Exercise 2.2.18.** For  $X = \mathbb{C}^n$ ,  $X' = \{0\}$ , and  $T \subset GL(n)$  the maximal torus, fill in the question marks in the following diagram

$$\begin{array}{cccccccccccccccccccccccccccccccccccc$$

in which the vertical arrows send the structure sheaves to  $1 \in \mathbb{Z}[t^{\mu}]$ .

In particular, since  $X \setminus X_{red} = \emptyset$ , the sequence (2.2.17) implies

$$K_G(X_{red}) \cong K_G(X)$$

where  $X_{\text{red}} \subset X$  is the reduced subscheme, whose sheaf of ideals  $\mathfrak{I} \subset \mathfrak{O}_X$  is formed by nilpotent elements. Concretely, any coherent sheaf  $\mathfrak{F}$  has a finite filtration

$$\mathcal{F} \supset \mathcal{I} \cdot \mathcal{F} \supset \mathcal{I}^2 \cdot \mathcal{F} \supset \dots$$

with quotients pushed forward from  $X_{red}$ .

**2.2.19.** One can think about the sequence (2.2.17) like this. Let  $\mathcal{F}_1$  and  $\mathcal{F}_2$  be two coherent sheaves on X, together with an isomorphism

$$s: \mathcal{F}_2|_{\mathfrak{U}} \xrightarrow{\sim} \mathcal{F}_1|_{\mathfrak{U}}$$

of their restriction to the open set  $U = X \setminus X'$ . Let  $\iota : U \to X$  denote the inclusion and let

$$\hat{\mathcal{F}} \subset \iota_* \iota^* \mathcal{F}_1$$

be the subsheaf generated by the natural maps

$$\mathcal{F}_1 \to \iota_* \iota^* \mathcal{F}_1$$
,  $\mathcal{F}_2 \xrightarrow{s} \iota_* \iota^* \mathcal{F}_1$ .

Of course,  $\iota_*\iota^*\mathcal{F}_1$  is only a quasicoherent sheaf on X, which is evident in the simplest example  $X=\mathbb{A}^1$ , X'= point,  $\mathcal{F}_1=\mathcal{O}_X$ . However, the sheaf  $\widehat{\mathcal{F}}$  is generated by the generators of  $\mathcal{F}_1$  and  $\mathcal{F}_2$ , and hence coherent.

By construction, the kernels and cokernels of the natural maps

$$f_{\hat{\iota}}: \mathcal{F}_{\hat{\iota}} \to \hat{\mathcal{F}}$$

are supported on X'. Thus

$$\mathcal{F}_1 - \mathcal{F}_2 = Coker f_1 - Ker f_1 + Ker f_2 - Coker f_2$$

is in the image of  $K(X') \rightarrow K(X)$ .

#### 2.2.20.

**Exercise 2.2.21.** Let G be trivial and let  $\mathcal{F}$  be a coherent sheaf on X with support  $Y \subset X$ . Let  $\mathcal{E}$  be a vector bundle on X of rank r. Prove that there exists  $Y' \subset Y$  of codimension 1 such that

$$\mathcal{E} \otimes \mathcal{F} - r \mathcal{F}$$

is in the image of  $K(Y') \rightarrow K(X)$ .

This exercise illustrates a very useful finite filtration on K(X) formed by the images of  $K(Y) \rightarrow K(X)$  over all subvarieties of given codimension.

**Exercise 2.2.22.** Let G be trivial and  $\mathcal{E}$  be a vector bundle on X of rank r. Prove that  $(\mathcal{E} - r) \otimes$  is nilpotent as an operator on K(X).

**Exercise 2.2.23.** Take  $X = \mathbb{P}^1$  and G = GL(2). Compute the minimal polynomial of the operator  $\mathcal{O}(1)\otimes$  and see, in particular, that it is not unipotent.

**Exercise 2.2.24.** In general, if G is connected and  $\mathcal{L}$  is a line bundle on X, then all eigenvalues of  $\mathcal{L}\otimes$  on  $K_G(X)$  are the weights of  $\mathcal{L}$  at the fixed points of a maximal torus of G.

### 2.3. Localization

**2.3.1.** Let a torus T act on a scheme X and let  $X^T$  be subscheme of T-fixed points, that is, let

$$\mathcal{O}_X \to \mathcal{O}_{X^T} \to 0$$

be the largest quotient on which T acts trivially. For what follows, both X and  $X^T$  may be replaced by their reduced subschemes.

Consider the kernel and cokernel of the map

$$\iota_*: K_T(X^T) \to K_T(X)\,.$$

This kernel and cokernel are  $K_T(pt)$ -modules and have some support in the torus T. A very general localization theorem of Thomason [83] states

$$(2.3.2) \qquad supp \, Coker \, \iota_* \subset \bigcup_{\mu} \{t^{\mu} = 1\}$$

where the union over finitely many nontrivial characters  $\mu$ . The same is true of Ker  $\iota_*$ , but since

$$(2.3.3) K_{\mathsf{T}}(\mathsf{X}^{\mathsf{T}}) = \mathsf{K}(\mathsf{X}) \otimes_{\mathbb{Z}} \mathsf{K}_{\mathsf{T}}(\mathsf{pt})$$

has no such torsion, this forces Ker  $\iota_*=0$ . To summarize,  $\iota_*$  becomes an isomorphism after inverting finitely many coefficients of the form  $t^\mu-1$ .

This localization theorem is an algebraic analog of the classical localization theorems in topological K-theory that go back to [3,79].

**Exercise 2.3.4.** Compute Coker  $\iota_*$  for  $X = \mathbb{P}^1$  and  $T \subset GL(2)$  the maximal torus. Compare your answer with what you computed in Exercise 2.2.18.

**2.3.5.** For general X, it is not so easy to make the localization theorem explicit, but a very nice formula exists if X is nonsingular. This forces  $X^T$  to be also nonsingular.

Let  $N=N_{X/X^T}$  denote the normal bundle to  $X^T$  in X. The total space of N has a natural action of  $s\in \mathbb{C}^\times$  by scaling the normal directions. Using this scaling action, we may define

(2.3.6) 
$$\mathcal{O}_{N,\text{graded}} = \sum_{k=0} s^{-k} S^k N^{\vee} = \bigotimes_{\mathfrak{u}} \frac{1}{\Lambda^{\bullet} (s^{-1} t^{-\mu} N_{\mathfrak{u}}^{\vee})} \in K_{\mathsf{T}}(X^{\mathsf{T}})[[s^{-1}]],$$

where

$$N=\bigoplus t^\mu N_\mu$$

is the decomposition of N into eigenspaces of T-action according to (2.3.3).

Exercise 2.3.7. Using Exercise 2.2.22 prove that

$$\mathfrak{O}_{N} = \mathfrak{O}_{N,graded} \Big|_{s=1} = S^{\bullet} N^{\vee} \in K_{T}^{\circ}(X^{T}) \left[ \frac{1}{1-t^{\mu}} \right]$$

where  $\mu$  are the weights of T in N.

**Exercise 2.3.8.** Prove that

$$\iota^*\iota_*\mathfrak{g} = \mathfrak{g} \otimes \Lambda^{\bullet} N^{\vee}$$

for any  $\mathcal{G} \in K_T(X^T)$  and that the operator  $\Lambda^{\bullet} N^{\vee} \otimes$  becomes an isomorphism after inverting  $1-t^{\mu}$  for all weights of N. Conclude the localization theorem (2.3.2) implies

$$(2.3.9)$$

for any F in localized equivariant K-theory.

**2.3.10.** A T-equivariant map  $f: X \to Y$  induces a diagram

$$(2.3.11) X^{\mathsf{T}} \xrightarrow{\iota_{\mathsf{X}}} X \\ \downarrow_{\mathsf{f}}^{\mathsf{T}} \downarrow \qquad \qquad \downarrow_{\mathsf{f}}^{\mathsf{T}} \\ Y^{\mathsf{T}} \xrightarrow{\iota_{\mathsf{Y}}} Y$$

with

$$(2.3.12) f_* \circ \iota_{X_{\prime}*} = \iota_{Y_{\prime}*} \circ f_*^{\mathsf{T}}.$$

Normally, we don't care much about torsion, or we may know ahead of time that there is no torsion in  $f_*$ , like when f is a proper map to a point, or some other trivial T-variety. Then, we can write

(2.3.13) 
$$f_* = \iota_{Y,*} \circ f_*^{\mathsf{T}} \circ \iota_{X,*}^{-1}.$$

This is what it means to compute the pushforward by localization.

**Exercise 2.3.14.** Redo Exercise 2.2.10, that is, compute  $\chi(\mathbb{P}^n, \mathcal{O}(k))$  by localization.

**Exercise 2.3.15.** Let G be a reductive group and X = G/B the corresponding flag variety. Every character  $\lambda$  of the maximal torus T gives a character of B and hence a line bundle

$$\mathcal{L}_{\lambda}: (G \times \mathbb{C}_{\lambda}) / B \to X$$

over X. Compute  $\chi(X,\mathcal{L}_{\lambda})$  by localization. A theorem of Bott, see e.g. [23] states that at most one cohomology group  $H^i(X,\mathcal{L}_{\lambda})$  is nonvanishing, in which case it is an irreducible representation of G. So be prepared to rederive Weyl character formula from your computation.

**Exercise 2.3.16.** Explain how Exercise 2.3.14 is a special case of Exercise 2.3.15.

**2.3.17.** Using (2.3.13), one may *define* pushforward  $f_*\mathcal{F}$  in localized equivariant cohomology as long as  $f^T$  is proper on  $(\operatorname{supp} \mathcal{F})^T$ . This satisfies all usual properties and leads to meaningful results, like

$$\chi(\mathbb{C}^{n},0) = \prod_{i} \frac{1}{1 - t_{i}^{-1}}$$

as a module over the maximal torus  $T \subset GL(n)$ .

**2.3.18.** The statement of the localization theorem goes over with little or no change to certain more general X, for example, to orbifolds. Those are modelled locally on  $\widetilde{X}/\Gamma$ , where  $\widetilde{X}$  is nonsingular and  $\Gamma$  is finite. By definition, coherent sheaves on  $\widetilde{X}/\Gamma$  are  $\Gamma$ -equivariant coherent sheaves on  $\widetilde{X}$ .

A torus action on  $\widetilde{X}/\Gamma$  is a  $T \times \Gamma$  action on  $\widetilde{X}$  and, in particular, the normal bundle  $N_{\widetilde{X}/\widetilde{X}^T}$  is  $\Gamma$ -equivariant, which means it descends to to an orbifold normal bundle to  $\left[\widetilde{X}/\Gamma\right]^T$ .

**Exercise 2.3.19.** For a, b > 0, consider the weighted projective line

$$X_{a,b} = \mathbb{C}^2 \setminus \{0\} \left/ \begin{pmatrix} z^a \\ z^b \end{pmatrix}, \quad z \in \mathbb{C}^{\times}.$$

Show it can be covered by two orbifold charts. Like any  $\mathbb{C}^{\times}$ -quotient, it inherits an orbifold line bundle  $\mathfrak{O}(1)$  whose sections are functions  $\varphi$  on the prequotient such that

$$\phi(z \cdot x) = z \phi(x).$$

Show that

(2.3.20) 
$$\sum_{k \ge 0} \chi(X_{a,b}, \mathcal{O}(k)) s^k = \frac{1}{(1 - t_1^{-1} s^a)(1 - t_2^{-1} s^b)}$$

as a module over diagonal matrices. Compute  $\chi(X_{\alpha,b}, O(k))$  by localization. Compare your answer to the computation of the  $s^k$ -coefficient in (2.3.20) by residues.

**2.3.21.** What we will really need in these lectures is the *virtual localization formula* from [19,38]. It will be discussed after we get some familiarity with virtual classes.

In particular, in this greater generality the normal bundle N to the fixed locus is a virtual vector bundle, that is, an element of  $K^{\circ}_{\mathsf{T}}(X^{\mathsf{T}})$  of the form

$$N = N_{Def} - N_{Obs}$$
,

where the  $N_{Def}$  is responsible for first-order deformations, while  $N_{Obs}$  contains obstructions to extending those. Naturally,

$$S^{\bullet}N^{\vee} = S^{\bullet}N_{Def}^{\vee} \otimes \Lambda^{\bullet}N_{Obs}^{\vee}$$
,

so a virtual localization formula has both denominators and numerators.

## 2.4. Rigidity

**2.4.1.** If the support of a T-equivariant sheaf  $\mathcal F$  is proper then  $\chi(\mathcal F)$  is an element of  $K_T(pt)$  and so a Laurent polynomial in  $t\in T$ . In general, this polynomial is nontrivial which, of course, is precisely what makes equivariant K-theory interesting.

However, for the development of the theory, one would like its certain building blocks to depend on few or no equivariant variables. This phenomenon is known as rigidity. A classical [4,47,48] and surprisingly effective way to show rigidity is to use the following elementary observation:

$$p(z)$$
 is bounded as  $z^{\pm 1} \to \infty \Leftrightarrow p = const$ 

for any  $p \in \mathbb{C}[z^{\pm 1}]$ . The behavior of  $\chi(\mathcal{F})$  at the infinity of the torus T can be often read off directly from the localization formula.

**Exercise 2.4.2.** Let X be proper and smooth with an action of a connected reductive group G. Write a localization formula for the action of  $T \subset G$  on

$$\sum_{p} (-m)^{p} \chi(X, \Omega^{p})$$

and conclude that every term in this sum is a trivial G-module.

Of course, Hodge theory gives the triviality of G-action on each

$$H^{q}(X, \Omega^{p}) \subset H^{p+q}(X, \mathbb{C})$$

for a compact Kähler X and a connected group G.

**2.4.3.** When the above approach works it also means that the localization formula may be simplified by sending the equivariant variable to a suitable infinity of the torus.

Exercise 2.4.4. In Exercise 2.4.2, pick a generic 1-parameter subgroup

$$z \in \mathbb{C}^{\times} \to \mathsf{T}$$

and compute the asymptotics of your localization formula as  $z \rightarrow 0$ .

It is instructive to compare the result of Exercise 2.4.4 with the Białynicki-Birula decomposition, which goes as follows. Assume  $X \subset \mathbb{P}(\mathbb{C}^N)$  is smooth and invariant under the action of a 1-parameter subgroup  $\mathbb{C}^\times \to GL(N)$ . Let

$$X^{\mathbb{C}^{\times}} = \bigsqcup_{i} F_{i}$$

be the decomposition of the fixed locus into connected components. It induces a decomposition of X

(2.4.5) 
$$X = \bigsqcup X_i, \quad X_i = \left\{ x \left| \lim_{z \to 0} z \cdot x \in F_i \right. \right\}$$

into locally closed sets. The key property of this decomposition is that the natural map

$$X_i \xrightarrow{\lim} F_i$$

is a fibration by affine spaces of dimension

$$d_i = \operatorname{rk}\left(N_{X/F_i}\right)_+$$

where plus denotes the subbundle spanned by vectors of positive *z*-weight, see for example [14] for a recent discussion. As also explained there, the decomposition (2.4.5) is, in fact, motivic, and in particular the Hodge structure of X is that sum of those for  $F_i$  shifted by  $(d_i, d_i)$ .

The same decomposition of X can be obtained from Morse theory applied to the Hamiltonian H that generated the action of  $U(1) \subset \mathbb{C}^{\times}$  on the (real) symplectic manifold X. Concretely, if z acts by

$$[x_1:x_2:\cdots:x_n] \xrightarrow{z} [z^{m_1} x_1:z^{m_2} x_2:\cdots:z^{m_n} x_n]$$

then

$$H(x) = \sum m_i |x_i|^2 / \sum |x_i|^2 .$$

**2.4.6.** In certain instances, the same argument gives more.

**Exercise 2.4.7.** Let X be proper nonsingular variety with a nontrivial action of  $T \cong \mathbb{C}^{\times}$ . Assume that a fractional power  $\mathcal{K}^p$  for  $0 of the canonical bundle <math>\mathcal{K}_X$  exists in Pic(X). Replacing T by a finite cover, we can make it act on  $\mathcal{K}^p$ . Show that

$$\chi(X, \mathcal{K}^p) = 0 \,.$$

What does this say about projective spaces? Concretely, which are the bundles  $\mathfrak{K}^p$ ,  $0 , for <math>X = \mathbb{P}^n$  and what do we know about their cohomology?

## 3. The Hilbert scheme of points of 3-folds

### 3.1. Our very first DT moduli space

**3.1.1.** For a moment, let X be a nonsingular quasiprojective 3-fold; very soon we will specialize the discussion to the case  $X = \mathbb{C}^3$ . Our interest is in the enumerative geometry of subschemes in X, and usually we will want these subscheme projective and 1-dimensional.

A subscheme  $Z \subset X$  is defined by a sheaf of ideals  $\mathfrak{I}_Z \subset \mathfrak{O}_X$  in the sheaf  $\mathfrak{O}_X$  of functions on X and, by construction, there is an exact sequence

$$(3.1.2) 0 \rightarrow \Im_{\mathsf{Z}} \rightarrow \Im_{\mathsf{X}} \rightarrow \Im_{\mathsf{Z}} \rightarrow 0$$

of coherent sheaves on X. Either the injection  $\mathfrak{I}_Z \hookrightarrow \mathfrak{O}_X$ , or the surjection  $\mathfrak{O}_X \twoheadrightarrow \mathfrak{O}_Z$  determines Z and can be used to parametrize subschemes of X. The result, known as the Hilbert scheme, is a countable union of quasiprojective algebraic varieties, one for each possible topological K-theory class of  $O_Z$ . The construction of the Hilbert scheme goes back to A. Grothendieck and is explained, for example, in [30,45].

In particular, for 1-dimensional Z, the class  $[O_Z]$  is specified by

$$deg \, Z = -c_2(\mathfrak{O}_Z) \in H_2(X,\mathbb{Z})_{effective}$$

and by the Euler characteristic  $\chi(\mathcal{O}_Z) \in \mathbb{Z}$ . In this section, we consider the case deg Z = 0, that is, the case of the Hilbert scheme of points.

**3.1.3.** If X is affine then the Hilbert scheme of points parametrizes modules M over the ring  $\mathcal{O}_X$  such that

$$\dim_{\mathbb{C}} M = \mathfrak{n}$$
,  $\mathfrak{n} = \chi(\mathfrak{O}_{\mathbb{Z}})$ ,

together with a surjection from a free module. Such Hilbert schemes Hilb(R, n) may, in fact, be defined for an arbitrary finitely-generated algebra

$$R = \mathbb{C}\langle x_1, \dots, x_k \rangle / \text{relations}$$

and consists of k-tuples of  $n \times n$  matrices

$$(3.1.4) X_1 \dots, X_k \in \operatorname{End}(\mathbb{C}^n)$$

satisfying the relations of R, together with a cyclic vector  $v \in \mathbb{C}^n$ , all modulo the action of GL(n) by conjugation. Here, a vector is called cyclic if it generates  $\mathbb{C}^n$  under the action of  $X_i$ 's. Clearly, a surjection  $R_1 \to R_2$  leads to inclusion  $Hilb(R_2,n) \hookrightarrow Hilb(R_1,n)$  and, in particular,

$$Hilb(R, n) \subset Hilb(Free_k, n)$$

if R is generated by k elements.

**Exercise 3.1.5.** Prove that  $Hilb(Free_k, n)$  is a smooth algebraic variety of dimension  $(k-1)n^2 + n$ . Show that  $Hilb(Free_1, n)$  is isomorphic to  $S^n\mathbb{C} \cong \mathbb{C}^n$  by the map that takes  $x_1$  to its eigenvalues.

By contrast,  $Hilb(\mathbb{C}^3, \mathfrak{n})$  is a very singular variety of unknown dimension.

**Exercise 3.1.6.** Let  $m \subset \mathcal{O}_{\mathbb{C}^d}$  be the ideal of the origin. Following Iarrobino, observe, that any linear linear subspace I such that  $m^r \supset I \supset m^{r+1}$  for some r is

an ideal in  $\mathcal{O}_{\mathbb{C}^d}$ . Conclude that the dimension of  $Hilb(\mathbb{C}^d, n)$  grows at least like a constant times  $n^{2-2/d}$  as  $n \to \infty$ . This is, of course, consistent with

$$\dim \operatorname{Hilb}(\mathbb{C}^1, \mathfrak{n}) = \mathfrak{n}, \quad \dim \operatorname{Hilb}(\mathbb{C}^2, \mathfrak{n}) = 2\mathfrak{n}$$

but shows that  $Hilb(\mathbb{C}^d, n)$  is not the closure of the locus of n distinct points for  $d \ge 3$  and large enough n.

## **3.1.7.** Consider the embedding

$$\operatorname{Hilb}(\mathbb{C}^3, \mathfrak{n}) \subset \operatorname{Hilb}(\operatorname{Free}_3, \mathfrak{n})$$

as the locus of matrices that commute, that is  $X_iX_j = X_jX_i$ . For 3 matrices, and only for 3 matrices, these relations can be written as equations for a critical point:

$$d\phi = 0$$
,  $\phi(X) = tr(X_1X_2X_3 - X_1X_3X_2)$ .

Note that  $\phi$  is a well-defined function on Hilb(Free<sub>3</sub>, n) which transforms in the 1-dimensional representation  $\kappa^{-1}$ , where

$$\kappa = \Lambda^3 \mathbb{C}^3 = \det_{\mathsf{GL}(3)},$$

under the natural action of GL(3) on  $Hilb(Free_3, n)$ . Here we have to remind ourselves that the action of a group G on functions is *dual* to its action on coordinates.

This means that our moduli space  $\mathbb{M} = \operatorname{Hilb}(\mathbb{C}^3, \mathfrak{n})$  is cut out inside an ambient smooth space  $\widetilde{\mathbb{M}} = \operatorname{Hilb}(\mathsf{Free}_3, \mathfrak{n})$  by a section

$$\mathcal{O}_{\widetilde{\mathbb{M}}} \xrightarrow{d \Phi \otimes \kappa} \kappa \otimes T_{\widetilde{\mathbb{M}}}^*$$
,

of a vector bundle on  $\widehat{\mathbb{M}}$ . The twist by  $\kappa$  is necessary to make this section GL(3)-equivariant.

This illustrates two important points about moduli problems in general, and moduli of coherent sheaves on nonsingular threefolds in particular. First, locally near any point, deformation theory describes many moduli spaces in a similar way:

(3.1.8) 
$$\mathbb{M} = s^{-1}(0) \subset \widetilde{\mathbb{M}}, \quad s \in \Gamma(\widetilde{\mathbb{M}}, \mathcal{E}),$$

for a certain obstruction bundle  $\mathcal{E}$ . Second, for coherent sheaves on 3-folds, there is a certain kinship between the obstruction bundle  $\mathcal{E}$  and the cotangent bundle of  $\widetilde{\mathbb{M}}$ , stemming from Serre duality beween the groups  $\operatorname{Ext}^1$ , which control deformations, and the groups  $\operatorname{Ext}^2$ , which control obstructions. The kinship is only approximate, unless the canonical class  $\mathcal{K}_X$  is equivariantly trivial, which is not the case even for  $X = \mathbb{C}^3$  and leads to the twist by  $\kappa$  above.

## 3.2. $\bigcirc^{\text{vir}}$ and $\widehat{\bigcirc}^{\text{vir}}$

**3.2.1.** The description (3.1.8) means that  $\mathcal{O}_{\mathbb{M}}$  is the 0th cohomology of the Koszul complex

$$(3.2.2) 0 \to \Lambda^{\operatorname{rk} \mathcal{E}} \mathcal{E}^{\vee} \xrightarrow{\operatorname{d}} \cdots \to \Lambda^{2} \mathcal{E}^{\vee} \xrightarrow{\operatorname{d}} \mathcal{E}^{\vee} \xrightarrow{\operatorname{d}} \mathcal{O}_{\widetilde{\mathbb{M}}} \to 0$$

in which  $\mathfrak{O}_{\widetilde{M}}$  is placed in cohomological degree 0 and the differential is the contraction with the section s of  $\mathcal{E}$ .

The Koszul complex is an example of a sheaf of differential graded algebras, which by definition is a sheaf  $A^{\bullet}$  of graded algebras with the differential

$$(3.2.3) \dots \xrightarrow{d} \mathcal{A}^{-2} \xrightarrow{d} \mathcal{A}^{-1} \xrightarrow{d} \mathcal{A}^{0} \to 0$$

satisfying the Leibniz rule

$$d(\alpha \cdot b) = d\alpha \cdot b + (-1)^{deg \, \alpha} \alpha \cdot db.$$

The notion of a DGA has become one of the cornerstone notions in deformation theory, see for example how it used in the papers [6,17–19] for a very incomplete set of references.

In particular, the structure sheaves  $0_{\mathbb{M}}$  of great many moduli spaces are described as  $H^0(A^{\bullet})$  of a certain natural DGAs.

**3.2.4.** Central to K-theoretic enumerative geometry is the concept of the *virtual structure sheaf* denoted  $\mathcal{O}_{\mathbb{M}}^{\mathrm{vir}}$ . While  $\mathcal{O}_{\mathbb{M}}$  is the 0th cohomology of a complex (3.2.3), the virtual structure sheaf is its Euler characteristic

$$\mathcal{O}_{\mathbb{M}}^{\text{vir}} = \sum_{i} (-1)^{i} \mathcal{A}^{i}$$
 
$$= \sum_{i} (-1)^{i} H^{i} (\mathcal{A}^{\bullet}),$$

see [19,46]. By Leibniz rule, each  $H^i(\mathcal{A}^{\bullet})$  is acted upon by  $\mathcal{A}^0$  and annihilated by  $d\mathcal{A}^{-1}$ , hence defines a quasicoherent sheaf on

$$\mathbb{M} = \operatorname{Spec} A^0 / dA^{-1}$$
.

If cohomology groups are coherent  $\mathcal{A}^0$ -modules and vanish for  $\mathfrak{i}\ll 0$  then the second line in (3.2.5) gives a well-defined element of  $K(\mathbb{M})$ , or of  $K_G(\mathbb{M})$  if all constructions are equivariant with respect to a group G.

The definition of  $\mathcal{O}_{\mathbb{M}}^{\text{vir}}$  is, in several respects, simpler than the definition [7] of the virtual fundamental cycle in cohomology. The agreement between the two is explained in Section 3 of [19].

**3.2.6.** There are many reasons to prefer  $\mathcal{O}_{\mathbb{M}}^{\mathrm{vir}}$  over  $\mathcal{O}_{\mathbb{M}}$ , and one of them is the invariance of virtual counts under deformations.

For instance, in a family  $X_t$  of threefolds, special fibers may have many more curves than a generic fiber, and even the dimensions of the Hilbert scheme of curves in  $X_t$  may be jumping wildly. This is reflected by the fact that in a family of complexes  $\mathcal{A}_t^{\bullet}$  each individual cohomology group is only semicontinuous and can jump up for special values of t. However, in a flat family of complexes the (equivariant) Euler characteristic is constant, and equivariant virtual counts are invariants of equivariant deformations.

**3.2.7.** Also, not the actual but rather the virtual counts are usually of interest in mathematical physics.

A supersymmetric physical theory starts out as a Hilbert space and an operator of the form (1.1.5), where at the beginning the Hilbert space  ${\mathfrak H}$  is something enormous, as it describes the fluctuations of many fields extended over many spatial dimensions. However, all those infinitely many degrees of freedom that correspond to nonzero eigenvalues of the operator  ${\mathbb D}^2$  pair off and make no contribution to supertraces (1.1.6). What remains, in cases of interest to us, may be identified with a direct sum (over various topological data) of complexes of finite-dimensional  $C^\infty$  vector bundles over finite-dimensional Kähler manifolds. These complexes combine the features of

- (a) a Koszul complex for a section s of a certain vector bundle,
- (b) a Lie algebra, or BSRT cohomology complex when a certain symmetry needs to be quotiented out, and
- (c) a Dolbeault cohomology, or more precisely a related Dirac cohomology complex, which turns the supertraces into *holomorphic* Euler characteristics of K-theory classes defined by (a) and (b).

If M is a Kähler manifold, then spinor bundles of M are the bundles

$$S_{\pm} = \mathcal{K}_{M}^{1/2} \otimes \bigoplus_{\text{n even/odd}} \Omega_{M}^{0,n}$$

with the Dirac operator  $\not D = \partial + \partial^*$ . Here  $\mathcal{K}_M$  is the canonical line bundle of M, which needs to be a square in order for M to be spin.

In item (c) above, the difference between Dolbeault and Dirac cohomology is precisely the extra factor of  $\mathcal{K}_{\mathrm{M}}^{1/2}$ . While this detail may look insignificant compared to many other layers of complexity in the problem, it will prove to be of fundamental importance in what follows and will make many computations work. The basic reason for this was already discussed in Section 2.4, and will be revisited shortly: the twist by  $\mathcal{K}_{\mathrm{M}}^{1/2}$  makes formulas more self-dual and, thereby, more rigid than otherwise.

**3.2.8.** Back in the Hilbert scheme context, the distinction between Dolbeault and Dirac is the distinction between  $\mathbb{O}_{M}^{vir}$  and

$$\widehat{\mathcal{O}}_{\mathbb{M}}^{\mathrm{vir}} = (-1)^{n} \, \mathcal{K}_{\mathrm{vir}}^{1/2} \otimes \mathcal{O}_{\mathbb{M}}^{\mathrm{vir}}$$

where the sign will be explained below and the virtual canonical bundle  $\mathcal{K}_{vir}^{1/2}$  is constructed as the dual of the determinant of the virtual tangent bundle

$$\begin{aligned} \text{(3.2.9)} \qquad \qquad & \mathsf{T}_{\mathbb{M}}^{\text{vir}} = \mathsf{Def} - \mathsf{Obs} \\ \text{(3.2.10)} \qquad & = \left(\mathsf{T}_{\widetilde{\mathbb{M}}} - \kappa \otimes \mathsf{T}_{\widetilde{\mathbb{M}}}^*\right)\Big|_{\mathbb{M}} \,. \end{aligned}$$

From (3.2.10) we conclude

$$\mathfrak{K}_{\mathrm{vir}}^{1/2} = \left. \kappa^{\frac{\mathrm{dim}}{2}} \otimes \mathfrak{K}_{\widetilde{\mathbb{M}}} \right|_{\mathbb{M}}$$

where dim = dim $\widetilde{\mathbb{M}}$ . This illustrates a general result of [67] that for DT moduli spaces the virtual canonical line bundle  $\mathcal{K}_{vir}$  is a square in the equivariant Picard group up to a character of Aut(X) and certain additional twists which will be discussed presently.

From the canonical isomorphism

$$\Lambda^k T_{\widetilde{\mathbb{M}}} \otimes \mathfrak{K}_{\widetilde{\mathbb{M}}} \; \cong \; \Omega^{\dim - k}_{\widetilde{\mathbb{M}}}$$

and the congruence

$$\dim \widetilde{\mathbb{M}} \equiv \mathfrak{n} \mod 2$$

we conclude that

$$\widehat{\mathbb{O}}_{\mathbf{M}}^{\text{vir}} = \kappa^{-\frac{\text{dim}}{2}} \sum_{i} (-\kappa)^{i} \, \Omega_{\widetilde{\mathbf{M}}}^{i} \, .$$

We call  $\hat{\mathbb{O}}_{M}^{vir}$  the *modified* or the *symmetrized* virtual structure sheaf. The hat which this K-class is wearing should remind the reader of the  $\hat{A}$ -genus and hence of the Dirac operator.

**3.2.12.** Formula (3.2.11) merits a few remarks. As discussed before, Serre duality between Ext<sup>1</sup> and Ext<sup>2</sup> groups on threefolds yields a certain kinship between the deformations and the *dual* of the obstructions. This makes the terms of the complex (3.2.2) and hence of the virtual structure sheaf  $\mathbb{O}_{\mathbb{M}}^{\mathrm{vir}}$  look like polyvector fields  $\Lambda^i T_{\widetilde{\mathbb{M}}}$  on the ambient space  $\widetilde{\mathbb{M}}$ . The twist by  $\mathcal{K}_{\widetilde{\mathbb{M}}} \approx \mathcal{K}_{\mathrm{vir}}^{1/2}$  turns polyvector fields into differential forms, and

The twist by  $\mathcal{K}_{\widetilde{M}} \approx \mathcal{K}_{\mathrm{vir}}^{1/2}$  turns polyvector fields into differential forms, and differential forms are everybody's favorite sheaves for cohomological computations. For example, if  $\widetilde{M}$  is a compact Kähler manifold then  $H^q(\Omega_{\widetilde{M}}^q)$  is a piece of the Hodge decomposition of  $H^{\bullet}(\widetilde{M},\mathbb{C})$ , and in particular, rigid for any connected group of automorphisms. But even when these cohomology groups are not rigid, or when the terms of  $\widehat{\mathcal{O}}^{\mathrm{vir}}$  are not exactly differential forms, they still prove to be much more manageable than  $\mathcal{O}^{\mathrm{vir}}$ .

**3.2.13.** The general definition of  $\widehat{\mathbb{O}}^{\text{vir}}$  from [67] involves, in addition to  $\mathbb{O}^{\text{vir}}$  and  $\mathcal{K}_{\text{vir}}$ , a certain *tautological* class on the DT moduli spaces.

The vector space  $\mathbb{C}^n$  in which the matrices (3.1.4) operate, descends to a rank n vector bundle over the quotient Hilb(Free, n). Its fiber over  $Z \in \text{Hilb}(\mathbb{C}^3, n)$  is naturally identified with global sections of  $\mathbb{O}_Z$ , that is, the pushforward of the *universal sheaf*  $\mathbb{O}_3$  along X, where

$$\mathfrak{Z} \subset \operatorname{Hilb}(X,\mathfrak{n}) \times X$$

is the universal subscheme.

Analogous universal sheaves exists for Hilbert schemes of subschemes of any dimension. In particular, for the Hilbert scheme of curves, and other DT moduli spaces  $\mathbb{M}$ , there exists a universal 1-dimensional sheaf  $\mathfrak{F}$  on  $\mathbb{M} \times X$  such that

$$\mathfrak{F}\big|_{m\times X}=\mathfrak{F}$$

where  $m = (\mathcal{F},...) \in \mathbb{M}$  is the moduli point representing a 1-dimensional sheaf  $\mathcal{F}$  on X with possibly some extra data.

By construction, the sheaf  $\mathfrak F$  is *flat* over  $\mathbb M$ , therefore *perfect*, that is, has a finite resolution by vector bundles on  $\mathbb M \times X$ . This is a nontrivial property, since  $\mathbb M$  is highly singular and for singular schemes  $K^\circ \subsetneq K$ , where  $K^\circ$  is the subgroup generated by vector bundles. From elements of  $K^\circ$  one can form tensor polynomials, for example

$$(3.2.14) P = S^2 \mathfrak{F} \otimes \gamma_1 + \Lambda^3 \mathfrak{F} \otimes \gamma_2 \in K^{\circ}(\mathbb{M} \times X),$$

for any  $\gamma_i \in K(X) = K^{\circ}(X)$ . The support of any tensor polynomial like (3.2.14) is proper over  $\mathbb{M}$  and therefore

$$\pi_{\mathbb{M},*}P \in \mathsf{K}^{\circ}(\mathbb{M})$$
,

where  $\pi_{\mathbf{M}}$  is the projection along X. This is because a proper pushforward of a flat sheaf is perfect, see for example Theorem 8.3.8 in [30]. It makes sense to apply further tensor operations to  $\pi_{\mathbf{M},*}\mathsf{P}$ , or to take it determinant.

In this way one can manufacture a large supply of classes in  $K^{\circ}(\mathbb{M})$  which are, in their totality, called *tautological*. One should think of them as K-theoretic version of imposing various geometric conditions on curves, like meeting a cycle in X specified by  $\gamma \in K(X)$ .

**3.2.15.** An example of the tautological class is the determinant term in the following definition

$$\widehat{\mathfrak{O}}^{vir} = prefactor \ \mathfrak{O}^{vir} \otimes (\mathfrak{K}_{vir} \otimes det \ \pi_{\mathbb{M},*}(\mathfrak{F} \otimes (\mathcal{L}_4 - \mathcal{L}_5)))^{1/2} \ ,$$

where  $\mathcal{L}_4 \in \text{Pic}(X)$  is an arbitrary line bundle and  $\mathcal{L}_5$  is a line bundle determined from the equation

$$\mathcal{L}_4 \otimes \mathcal{L}_5 = \mathcal{K}_X$$
.

These are the same  $\mathcal{L}_4$  and  $\mathcal{L}_5$  as in Section 1.3.2. The prefactor in (3.2.16) contains the *z*-dependence

(3.2.17) prefactor = 
$$(-1)^{(\mathcal{L}_4,\beta)+n} z^{n-(\mathcal{K}_X,\beta)/2}$$

where

$$\beta = \deg \mathcal{F} \in H_2(X, \mathbb{Z}), \quad n = \chi(\mathcal{F}) \in \mathbb{Z}$$

are locally constant functions of a 1-dimensional sheaf  $\mathcal{F}$  on X.

The existence of square root in (3.2.16) is shown in [67]. With this definition, the general problem of computing the K-theoretic DT invariants may be phrased as

$$\chi\left(\mathbb{M},\widehat{\mathbb{O}}^{vir}\otimes tautological\right)=?,$$

where  $\mathbb{M}$  is one of the many possible DT moduli spaces. In a relative situation, one can put further insertions in (3.2.18).

### 3.3. Nekrasov's formula

**3.3.1.** Let X be a nonsingular quasiprojective threefold and consider its Hilbert scheme of points

$$\mathbb{M} = \bigsqcup_{n>0} \operatorname{Hilb}(X, n).$$

In the prefactor (3.2.17) we have  $\beta = 0$  and therefore

$$(3.3.2) prefactor = (-z)^n$$

In [66], Nekrasov conjectured a formula for

$$Z_{X,points} = \chi\left(\mathbb{M}, \widehat{\mathbb{O}}^{vir}\right).$$

Because of the prefactor, this is well-defined as a formal power series in z, as long as  $\chi\left(\text{Hilb}(n),\widehat{\mathbb{O}}^{vir}\right)$  is well-defined for each n. For that we need to assume that either X is proper or, more generally, that there exists  $g \in \text{Aut}(X)_0$  such that it fixed point set  $X^g$  is proper (if X is already proper we can always take g=1). Then

$$Z_{X,points} \in \begin{cases} K_{Aut(X)}(pt)[[z]], & g = 1 \\ K_{Aut(X)}(pt)_{loc}[[z]], & \text{otherwise}. \end{cases}$$

To be precise, [66] considers the case  $X = \mathbb{C}^3$ , but the generalization to arbitrary X is immediate.

**3.3.4.** Nekrasov's formula computes  $Z_{X,points}$  in the form

$$\mathsf{Z}_{\mathsf{X},\mathsf{points}} = \mathsf{S}^{\bullet} \chi(\mathsf{X},\star) \,, \quad \star \in \mathsf{K}_{\mathsf{T}}(\mathsf{X})[[z]]$$

where S<sup>•</sup> is the symmetric algebra from Section 2.1.

Here, and this is very important, the boxcounting variable z is viewed as a part of the torus T, that is, it is also raised to the power n in the formula (2.1.11). This is very natural from the 5-dimensional perspective, since the z really acts on the 5-fold (1.3.3), with the fixed point set X, as discussed in Section 1.3.2.

Now we are ready to state the following result, conjectured by Nekrasov in [66]

Theorem 3.3.6. We have

(3.3.7) 
$$Z_{X,points} = S^{\bullet}\chi\left(X, \frac{z\mathcal{L}_4\left(T_X + \mathcal{K}_X - T_X^{\vee} - \mathcal{K}_X^{-1}\right)}{(1 - z\mathcal{L}_4)(1 - z\mathcal{L}_5^{-1})}\right).$$

- **3.3.8.** In [66], this conjecture appeared together with an important physical interpretation, as the supertrace of  $\operatorname{Aut}(\mathsf{Z},\Omega^5)$ -action on the fields of *M-theory* on (1.3.3). M-theory is a supergravity theory in 10+1 real spacetime dimensions. Its fields are:
  - the metric, also known as the graviton,
  - its fermionic superpartner, gravitino, which is a field of spin 3/2, and
  - one more bosonic field, a 3-form analogous to a connection, or a gauge boson, in gauge theories such as electromagnetism.

These are considered up to a gauge equivalence that includes: diffeomorphisms, changing the 3-form by an exact form, and changing gravitino by a derivative of a spinor.

In addition to these fields, M-theory has extended objects, namely:

- membranes, which have a 3-dimensional worldvolume and hence are naturally charged under the 3-form, and also
- magnetically dual M5-branes.

While membranes naturally appear in connection with DT invariants of positive degree [67], see for example Section 5.1.6 below, possible algebro-geometric interpretations of M5-branes are still very much in the initial exploration stage.

In Hamiltonian description, the field sector of the Hilbert space of M-theory is, formally, the  $L^2$  space of functions on a very infinite-dimensional configuration supermanifold, namely

(3.3.9) 
$$\mathcal{H} \stackrel{f}{=} L^2 \left( bosons \oplus \frac{1}{2} \text{ fermions on } Z / gauge \right),$$

where

- Z is a fixed time slice of the 11-dimensional spacetime,
- $-\frac{1}{2}$  of the fermions denotes a choice of polarization, that is, a splitting of fermionic operators into operators of creation and annihilation,
- the = sign denotes an equality which is formal, ignores key analytic and dynamical questions, but may be suitable for equivariant K-theory which is often insensitive to finer details.

As a time slice, one is allowed to take a Calabi-Yau 5-fold, for example the one in (1.3.3). Automorphisms of Z preserving the 5-form  $\Omega^5$  are symmetries of the theory and hence act on its Hilbert space.

Since the configuration space is a linear representation of  $\operatorname{Aut}(\mathsf{Z},\Omega^5)$ , we have

$$\mathcal{H} \stackrel{f}{=} S^{\bullet}$$
Configuration space

in K-theory of  $\operatorname{Aut}(Z, \Omega^5)$ . The character of the latter may be computed, see [66], the exposition of the results of [66] in Section 2.4 of [67], and below, with the result that

(3.3.10) 
$$\mathcal{H} \stackrel{f}{=} \Lambda^{\bullet}_{\chi}(\mathsf{Z},\mathsf{T}_{\mathsf{Z}}),$$

or its dual

$$\overline{\Lambda^{\bullet}\!\chi(Z,T_Z)}=S^{\bullet}\chi(Z,T_Z^*)\,,$$

depending on the choice of the polarization in (3.3.9).

Note that

$$\chi(\mathsf{Z},\mathsf{T}_\mathsf{Z}^*-\mathsf{T}_\mathsf{Z}) = \chi\left(\mathsf{X},\mathcal{K}_\mathsf{X} - \mathsf{O}_\mathsf{X} + \frac{z\mathcal{L}_4\left(\mathsf{T}_\mathsf{X} + \mathcal{K}_\mathsf{X} - \mathsf{T}_\mathsf{X}^* - \mathcal{K}_\mathsf{X}^{-1}\right)}{(1-z\mathcal{L}_4)(1-z\mathcal{L}_5^{-1})}\right)\,.$$

This implies

$$(3.3.11) S^{\bullet}\chi(X, \mathcal{K}_{X} - \mathcal{O}_{X}) \otimes \mathsf{Z}_{X, points} \stackrel{f}{=} \mathcal{H} \otimes \overline{\mathcal{H}},$$

which is a formula with at least two issues, one minor and the other more interesting. The minor issue is the prefactor in the LHS, which is ill-defined as written. We will see below how this prefactor appears in DT computations and why in the natural regularization it is simply removed.

The interesting issue in (3.3.11) is the doubling the contribution of  $\mathcal{H}$ . As already pointed out by Nekrasov, it should be reexamined with a more careful analysis of the physical Hilbert space of M-theory.

**3.3.12.** The following exercises will guide the reader through the proof of (3.3.10). Since this computation is about finite-dimensional representations of reductive groups, we may complexify problem and consider

$$V=Z\otimes_{\mathbb{R}}\mathbb{C}\cong\mathbb{C}^{10}\,.$$

This is a vector space with a nondegenerate quadratic form. We may assume the form is given by

$$\|(x_1,\ldots,x_{10})\|^2 = \sum_{i=1}^k x_i x_{11-i}$$

in which case

$$B = SO(V) \cap \{\text{upper triangular matrices}\}\$$

is a Borel subgroup with a maximal torus

$$T = \left\{ diag(t_1, \dots, t_5, t_5^{-1}, \dots, t_1^{-1}) \right\} \cong \left( \mathbb{C}^{\times} \right)^5.$$

By definition, the spinor representations  $S_{\pm}$  of SO(V) have the highest weight

$$\left(\frac{1}{2}, \frac{1}{2}, \frac{1}{2}, \frac{1}{2}, \frac{1}{2}, \pm \frac{1}{2}\right)$$
.

**Exercise 3.3.13.** Show that the character of  $S_{\pm}$  is given by

$$\operatorname{tr}_{S_+} t - \operatorname{tr}_{S_-} t = (t_1 \cdots t_5)^{1/2} \prod_{i=1}^5 (1 - t_i^{-1}).$$

**Exercise 3.3.14.** Prove that the dual of one spinor representation is the other.

**Exercise 3.3.15.** Show there exists a nonzero SO(V) intertwiner

$$V \otimes S_{\pm} \to S_{\mp}$$
.

Exercise 3.3.16. Using e.g. Weyl dimension formula, show

$$V \otimes S_+ = S_{\mp} \oplus RS_+$$
,

where  $RS_{\pm}$  is an irreducible SO(V) module with highest weight

$$\left(\frac{3}{2},\frac{1}{2},\frac{1}{2},\frac{1}{2},\pm\frac{1}{2}\right)$$
.

Fields transforming in this representation of the orthogonal group are called *Rarita-Schwinger* fields.

Viewed as SO(V) module, the configuration superspace in (3.3.10) is the space of functions on V with values in the following virtual representation of SO(V)

$$\begin{array}{lll} \text{(3.3.17)} & \textbf{M}_{\pm} = S^2V - 1 & \text{traceless metric} \\ & -V & \text{modulo diffeomorphism} \\ & \Lambda^3V & \text{a 3-form} \\ & -\Lambda^2V + V - 1 & \text{modulo exact forms} \\ & -RS_{\pm} & \text{a Rarita-Schwinger field} \\ & +S_{\pm} & \text{modulo derivative of a spinor} \, . \end{array}$$

Note the change of sign in the last two lines in (3.3.17). This is because fields of half-integer spin are fermions, and thus count with the minus sign in the supertrace.

Also note that the dual of  $M_{\pm}$  is  $M_{\mp}$ . This is the place where the choice of polarization in (3.3.9) makes a difference.

**3.3.18.** The span  $W \subset V$  of the first 5 coordinate lines is isotropic, and we can write

$$V = W \oplus W^* \cong T^{1,0}Z \oplus T^{0,1}Z$$

where

$$TZ \otimes_{\mathbb{R}} \mathbb{C} = T^{1,0}Z \oplus T^{0,1}Z$$

is the decomposition of tangent vectors by their Hodge type. As a result, we have an embedding

$$GL(W) \subset SO(V)$$
.

The subgroup  $SL(W) \subset GL(W)$  corresponds to those operators that act complex-linearly on  $Z \cong \mathbb{C}^5$  and preserve a nondegenerate 5-form.

Exercise 3.3.19. Prove that

(3.3.20) 
$$\mathbf{M}_{+} = -W \otimes \Lambda^{\bullet} W,$$
$$\mathbf{M}_{-} = W^{*} \otimes \Lambda^{\bullet} W.$$

as SL(W) modules. By duality, it is enough to prove either of those.

Since  $W \cong T^{1,0}Z \cong \Omega^{0,1}Z$  as SL(W)-modules, we have

Configuration (super)space = 
$$\chi(Z, C^{\infty}(\mathbf{M}_{+}))$$
  
=  $-\chi(Dolbeault(TZ))$   
=  $-\chi(Z, TZ)$ 

where  $C^{\infty}(\mathbf{M}_{+})$  is the sheaf of smooth functions with values in  $\mathbf{M}_{+}$ , and in the second line we have the Dolbeault complex of the holomorphic tangent bundle of Z. This completes the proof of (3.3.10).

**3.3.21.** Below we will see how (3.3.7) reproduces an earlier result in cohomology proven in [56] for X toric varieties and in [50] for general 3-folds. The cohomological version of (3.3.3) is

(3.3.22) 
$$Z_{X,points,coh} = \sum_{n \ge 0} (-z)^n \int_{[Hilb(X,n)]_{vir}} 1,$$

where  $[Hilb(X,n)]_{vir}$  is the virtual fundamental cycle [7]. It may be defined as the cycle corresponding to the K-theory class  $0^{vir}$  which, as [19] prove, has the expected dimension of support.

In general, for DT moduli spaces, the expected dimension is

vir dim = 
$$-(\deg \mathcal{F}, \mathcal{K}_X)$$
,

where  $\mathcal{F}$  is the 1-dimensional sheaf on X. For Hilbert schemes of points this vanishes and  $[Hilb(X,n)]_{vir}$  is an equivariant 0-cycle. For  $Hilb(\mathbb{C}^3)$  this cycle is the Euler class of the obstruction bundle.

The following result was conjectured in [56] and proven there for toric 3-folds. The general algebraic cobordism approach of Levine and Pandharipande reduces the case of a general 3-fold to the special case of toric varieties.

**Theorem 3.3.23** ([50, 56]). We have

$$Z_{X,points,coh} = M(z)^{\int_X c_3(T_X \otimes \mathcal{K}_X)}$$

where

$$M(z) = S^{\bullet} \frac{z}{(1-z)^2} = \prod_{n>0} (1-z^n)^{-n},$$

is McMahon's generating function for 3-dimensional partitions.

The appearance of 3-dimensional partitions here is very natural — they index the torus fixed points in  $Hilb(\mathbb{C}^3, n)$ . These appear naturally in equivariant virtual localization, which is the subject to which we turn next.

## 3.4. Tangent bundle and localization

## **3.4.1.** Consider the action of the maximal torus

$$\mathsf{T} = \left\{ egin{pmatrix} \mathsf{t}_1 & & & & \\ & \mathsf{t}_2 & & & \\ & & \ddots & & \\ & & & \mathsf{t}_d \end{pmatrix} 
ight\} \subset \mathsf{GL}(\mathsf{d})$$

on Hilb( $\mathbb{C}^d$ , points), that is, on ideals of finite codimension in the ring  $\mathbb{C}[x_1,\ldots,x_d]$ .

**Exercise 3.4.2.** Prove that the fixed points set  $Hilb(\mathbb{C}^d, points)^T$  is 0-dimensional and formed by *monomial ideals*, that is, ideals generated by monomials in the variables  $x_i$ . In particular, the points of  $Hilb(\mathbb{C}^d, n)^T$  are in natural bijection with d-dimensional partitions  $\pi$  of the number n.

**3.4.3.** For d = 1, 2, Hilbert schemes are smooth and our next goal is to compute the character of the torus action on  $T_{\pi}$  Hilb. This will be later generalized to the computation of the torus character of the *virtual* tangent space for d = 3.

By construction or by the functorial definition of the Hilbert scheme, its Zariski tangent space at any subscheme  $Z \subset X$  is given by

$$T_7$$
 Hilb = Hom $(\mathfrak{I}_7, \mathfrak{O}_7)$ 

where  $\mathcal{I}_Z$  is the sheaf of ideals of Z and  $\mathcal{O}_Z = \mathcal{O}_X/\mathcal{I}_Z$  is its structure sheaf. Indeed, the functorial description of Hilbert scheme says that

$$Maps(B,Hilb(X)) = \begin{cases} subschemes \text{ of } B \times X \\ flat \text{ and proper over } B \end{cases}$$

for any scheme B. In particular, a map from

$$B = \operatorname{Spec} \mathbb{C}[\varepsilon]/\varepsilon^2$$

is a point of Hilb(X) together with a tangent vector, and this leads to the formula above.

Exercise 3.4.4. Check this.

**Exercise 3.4.5.** Let X be a smooth curve and  $Z \subset X$  a 0-dimensional subscheme. Prove that

$$T_Z \operatorname{Hilb} = H^0(T^*X \otimes \mathcal{O}_Z)^*$$
.

In particular, for  $X = \mathbb{C}^1$  and the torus-fixed ideal  $I = (x_1^n)$  we have

$$\mathsf{T}_{(\mathsf{x}_1^n)}=\mathsf{t}_1+\cdots+\mathsf{t}_1^n\,,$$

in agreement with global coordinates on  $Hilb(\mathbb{C}^1, \mathfrak{n}) \cong \mathbb{C}^n$  given by

$$I=(f),\quad f=x^n+\alpha_1\,x^{n-1}+\cdots+\alpha_n\,.$$

**3.4.6.** Now let X be a nonsingular surface and  $Z \subset X$  a 0-dimensional subscheme. By construction, we have a short exact sequence

$$0 \rightarrow \mathcal{I}_{7} \rightarrow \mathcal{O}_{X} \rightarrow \mathcal{O}_{7} \rightarrow 0$$

which we can apply in the first argument to get the following long exact sequence of Ext-groups

$$(3.4.7) \qquad 0 \longrightarrow \operatorname{Hom}(\mathcal{O}_{Z}, \mathcal{O}_{Z}) \xrightarrow{\sim} \operatorname{Hom}(\mathcal{O}_{X}, \mathcal{O}_{Z}) \xrightarrow{0} \operatorname{Hom}(\mathcal{I}_{Z}, \mathcal{O}_{Z}) \longrightarrow$$

$$\longrightarrow \operatorname{Ext}^{1}(\mathcal{O}_{Z}, \mathcal{O}_{Z}) \longrightarrow \operatorname{Ext}^{1}(\mathcal{O}_{X}, \mathcal{O}_{Z}) \longrightarrow \operatorname{Ext}^{1}(\mathcal{I}_{Z}, \mathcal{O}_{Z}) \longrightarrow$$

$$\longrightarrow \operatorname{Ext}^{2}(\mathcal{O}_{Z}, \mathcal{O}_{Z}) \longrightarrow \operatorname{Ext}^{2}(\mathcal{O}_{X}, \mathcal{O}_{Z}) \longrightarrow \operatorname{Ext}^{2}(\mathcal{I}_{Z}, \mathcal{O}_{Z}) \longrightarrow 0,$$

all vanishing and isomorphisms in which follow from

$$\operatorname{Ext}^{\mathfrak{i}}(\mathfrak{O}_{\mathsf{X}},\mathfrak{O}_{\mathsf{Z}})=\operatorname{H}^{\mathfrak{i}}(\mathfrak{O}_{\mathsf{Z}})=\begin{cases} \operatorname{H}^{0}(\mathfrak{O}_{\mathsf{Z}})=\operatorname{Hom}(\mathfrak{O}_{\mathsf{Z}},\mathfrak{O}_{\mathsf{Z}})\,, & \mathfrak{i}=0\,,\\ 0\,, & \mathfrak{i}>0\,, \end{cases}$$

because Z is affine.

Since the support of Z is proper, we can use Serre duality, which gives

$$\begin{split} \text{(3.4.8)} \quad & \text{Ext}^2(\mathfrak{O}_{\text{Z}},\mathfrak{O}_{\text{Z}}) = \text{Hom}(\mathfrak{O}_{\text{Z}},\mathfrak{O}_{\text{Z}}\otimes \mathfrak{K}_{\text{X}})^* = \\ & = \text{H}^0(\mathfrak{O}_{\text{Z}}\otimes \mathfrak{K}_{\text{X}})^* = \chi(\mathfrak{O}_{\text{Z}}\otimes \mathfrak{K}_{\text{X}})^* = \chi(\mathfrak{O}_{\text{Z}},\mathfrak{O}_{\text{X}})\,, \end{split}$$

where

(3.4.9) 
$$\chi(\mathcal{A}, \mathcal{B}) = \sum (-1)^{i} \operatorname{Ext}^{i}(\mathcal{A}, \mathcal{B}).$$

This is an sesquilinear pairing on the equivariant K-theory of X satisfying

$$\chi(\mathcal{A}, \mathcal{B})^* = (-1)^{\dim X} \chi(\mathcal{B}, \mathcal{A} \otimes \mathcal{K}_X).$$

Putting (3.4.7) and (3.4.8) together, we obtain the following

**Proposition 3.4.10.** *If* X *is a nonsingular surface then* 

$$\begin{aligned} \mathsf{T}_{\mathsf{Z}} \, \mathsf{Hilb}(\mathsf{X},\mathsf{points}) &= \chi(\mathbb{O}_{\mathsf{Z}}) + \chi(\mathbb{O}_{\mathsf{Z}},\mathbb{O}_{\mathsf{X}}) - \chi(\mathbb{O}_{\mathsf{Z}},\mathbb{O}_{\mathsf{Z}}) \\ &= \chi(\mathbb{O}_{\mathsf{X}}) - \chi(\mathbb{I}_{\mathsf{Z}},\mathbb{I}_{\mathsf{Z}}) \,. \end{aligned}$$

**3.4.12.** Proposition 3.4.10 lets us easily compute the characters of the tangent spaces to the Hilbert scheme at monomial ideals. To any  $\mathcal{F} \in K_T(\mathbb{C}^2)$  we can naturally associate two T-modules:  $\chi(\mathcal{F})$  and the K-theoretic stalk of  $\mathcal{F}$  at  $0 \in \mathbb{C}^2$ , which we can write as  $\chi(\mathcal{F} \otimes \mathcal{O}_0)$ . They are related by

$$\chi(\mathfrak{F}) = \chi(\mathfrak{F} \otimes \mathfrak{O}_0) \chi(\mathfrak{O}_{\mathbb{C}^2})$$

where, keeping in mind that linear functions on  $\mathbb{C}^2$  form a GL(2)-module *dual* to  $\mathbb{C}^2$  itself,

$$\chi(\mathcal{O}_{\mathbb{C}^2}) = S^{\bullet} \left(\mathbb{C}^2\right)^* = \frac{1}{(1 - t_1^{-1})(1 - t_2^{-1})}.$$

The formula

$$(3.4.14) \hspace{1cm} \chi(\mathfrak{F},\mathfrak{G}) = \chi(\mathfrak{F}\otimes \mathfrak{O}_0)^*\chi(\mathfrak{G}\otimes \mathfrak{O}_0)\,\chi(\mathfrak{O}_{\mathbb{C}^2}) = \frac{\chi(\mathfrak{F})^*\chi(\mathfrak{G})}{\chi(\mathfrak{O})^*}$$
 generalizes (3.4.13).

Let  $I_{\lambda}$  be a monomial ideal and let  $\lambda$  be the corresponding partition with diagram

$$diagram(\lambda) = \left\{ (i,j) \middle| x_1^i x_2^j \notin I_{\lambda} \right\} \subset \mathbb{Z}_{\geqslant 0}^2,$$

see Figure 3.4.15. More traditionally, the boxes or the dots in the diagram of  $\lambda$  are indexed by pairs  $(i,j) \in \mathbb{Z}^2_{>0}$ , but this, certainly, a minor detail. In what follows, we don't make a distinction between a partition and its diagram.

![](_page_36_Picture_2.jpeg)

Figure 3.4.15. Diagram of the partition  $\lambda = (8, 5, 4, 2, 1)$ .

Let  $\mathcal{V} = \chi(\mathcal{O}_Z)$  denote the tautological rank n vector bundle over  $Hilb(\mathbb{C}^2, n)$  as in Section 3.2.13, and let

$$(3.4.16) V_{\lambda} = \chi(\mathcal{O}_{Z_{\lambda}})$$

$$= \sum_{(i,j)\in\lambda} t_1^{-i} t_2^{-j}$$

be the character of its stalk at  $I_{\lambda}$ . Clearly, this is nothing but the generating function for the diagram  $\lambda$ . From (3.4.11) and (3.4.14) we deduce the following

**Proposition 3.4.17.** *Let*  $I_{\lambda} \subset \mathbb{C}[x_1, x_2]$  *be a monomial ideal and let* V *denote the generating function* (3.4.16) *for the diagram of*  $\lambda$ . *We have* 

$$\text{(3.4.18)} \qquad \qquad \text{$T_{I_{\lambda}}$ Hilb} = V + \overline{V}\,t_{1}t_{2} - V\overline{V}\,(1-t_{1})(1-t_{2})\,.$$

as a T-module, where  $\overline{V} = V^*$  denotes the dual.

For example, take

$$\lambda = \Box$$
,  $I_{\lambda} = m = (x_1, x_2)$ ,  $V = 1$ 

then

$$T_{\Box}$$
 Hilb = 1 +  $t_1t_2$  -  $(1 - t_1)(1 - t_2)$  =  $t_1 + t_2 = \mathbb{C}^2$ 

in agreement with  $Hilb(X, 1) \cong X$ .

**3.4.19.** Formula (3.4.18) may be given the following combinatorial polish. For a square = (i, j) in the diagram of  $\lambda$  define its arm-length and leg-length by

$$\begin{split} a(\textbf{q}) = &\#\{j' > j \, \middle| \, (i,j') \in \lambda \} \,, \\ l(\textbf{q}) = &\#\{i' > i \, \middle| \, (i',j) \in \lambda \} \,, \end{split}$$

see Figure 3.4.21.

Exercise 3.4.22. Prove that

$$(3.4.23) \hspace{1cm} T_{I_{\lambda}} \, Hilb = \sum_{\square \subseteq \lambda} t_{1}^{-l(\square)} t_{2}^{\alpha(\square)+1} + t_{1}^{l(\square)+1} t_{2}^{-\alpha(\square)} \, .$$

**Exercise 3.4.24.** Prove a generalization of (3.4.18) and (3.4.23) for the character of  $\chi(\mathcal{O}_X) - \chi(I_{\lambda}, I_{\mu})$ . If in need of a hint, open [16].

![](_page_37_Picture_2.jpeg)

Figure 3.4.21. For the box  $\square = (1,1)$  in this diagram, we have  $\mathfrak{a}(\square) = 3$  and  $\mathfrak{l}(\square) = 2$ .

**Exercise 3.4.25.** Using the formulas for  $T_{I_{\lambda}}$  Hilb and equivariant localization, write a code for the computation of the series

$$\mathsf{Z}_{\mathsf{Hilb}(\mathbb{C}^2)} = \sum_{\mathfrak{n},\mathfrak{i}\geqslant 0} z^{\mathfrak{n}} (-\mathfrak{m})^{\mathfrak{i}} \, \chi(\mathsf{Hilb}(\mathbb{C}^2,\mathfrak{n}),\Omega^{\mathfrak{i}})$$

and check experimentally that is  $S^{\bullet}$  of a nice rational function of the variables z, m,  $t_1$ ,  $t_2$ . We will compute this function theoretically in Section 5.3.10.

**3.4.26.** We now advance to the discussion of the case when X is a nonsingular threefold and  $Z \subset X$  is a 1-dimensional subscheme and  $\mathcal{I}_Z$  is its sheaf of ideals. The sheaf  $\mathcal{I}_Z$  is clearly torsion-free, as a subsheaf of  $\mathcal{O}_X$ , and

$$\det \mathfrak{I}_{\mathsf{Z}} = \mathfrak{O}_{\mathsf{X}}$$

because the two sheaves differ in codimension  $\geq 2$ .

Donaldson-Thomas theory views Hilb(X, curves) as the moduli space of torsion-free sheaves rank 1 sheaves  $\mathbb{I}$  with trivial determinant. For any such sheaf we have

$$\mathfrak{I} \hookrightarrow \mathfrak{I}^{\vee \vee} = \det \mathfrak{I} = \mathfrak{O}_{X}$$

and so  $\mathbb{J}$  is the ideal sheaf of a subscheme  $\mathbb{Z} \subset \mathbb{X}$ . We have

$$0 = c_1(\det \mathfrak{I}) = c_1(\mathfrak{I}) = [\mathsf{Z}] \in \mathsf{H}_4(\mathsf{X}, \mathbb{Z})$$

and therefore  $\dim Z = 1$ . The deformation theory of sheaves gives

$$\begin{split} \mathsf{T}^{vir}_{\mathtt{J}}\,\mathsf{Hilb} &= \mathsf{Def}(\mathtt{I}) - \mathsf{Obs}(\mathtt{I}) = \chi(\mathtt{O}_X) - \chi(\mathtt{I},\mathtt{I})\,,\\ &= \chi(\mathtt{O}_Z) + \chi(\mathtt{O}_Z,\mathtt{O}_X) - \chi(\mathtt{O}_Z,\mathtt{O}_Z) \end{split}$$

just like in Proposition 3.4.10.

The group  $\text{Ext}^1(\mathfrak{I},\mathfrak{I})$  which enters (3.4.27) parametrizes sheaves on  $B\times X$  flat over B for  $B=\mathbb{C}[\epsilon]/\epsilon^2$ , just like in Exercise 3.4.4. It describes the deformations of the sheaf  $\mathfrak{I}$ . The obstructions to these deformations lie in  $\text{Ext}^2(\mathfrak{I},\mathfrak{I})$ .

We now examine how this works for the Hilbert scheme of points in  $\mathbb{C}^3$ .

**3.4.28.** Let  $\pi$  be a 3-dimensional partition and let  $I_{\pi} \subset \mathbb{C}[x_1, x_2, x_3]$  be the corresponding monomial ideal. The passage from (3.4.11) to (3.4.18) is exactly the same as before, with the correction for

$$\chi(\mathcal{O}_{\mathbb{C}^3}) = \frac{1}{(1-t_1^{-1})(1-t_2^{-1})(1-t_3^{-1})} \, .$$

We obtain the following

**Proposition 3.4.29.** *Let*  $I_{\pi} \subset \mathbb{C}[x_1, x_2, x_3]$  *be a monomial ideal and let* V *denote the generating function for*  $\pi$ *, that is, the character of*  $\mathfrak{O}_{Z_{\pi}}$ *. We have* 

$$(3.4.30) \hspace{1cm} T_{I_\pi}^{vir} \, Hilb = V - \overline{V} \, t_1 t_2 t_3 - V \overline{V} \, \prod_1^3 (1-t_\mathfrak{i}) \, .$$

as a T-module.

As an example, take

$$\pi = \square$$
,  $I_{\pi} = m = (x_1, x_2, x_2)$ ,  $V = 1$ 

then

$$T^{vir}_{\square} \ Hilb = t_1 + t_2 + t_3 - t_1t_2 - t_1t_3 - t_2t_3 = C^3 - det \ C^3 \otimes \left(C^3\right)^*$$

in agreement with the identification

$$\mathbb{M}(1) = \operatorname{Hilb}(X, 1) \cong X \cong \operatorname{Hilb}(\mathsf{Free}_3, 1) = \widetilde{\mathbb{M}}(1)$$

for the Hilbert schemes of 1 point in  $X = \mathbb{C}^3$  and the description of the obstruction bundle as

$$Obs = \kappa \otimes T^*_{\widetilde{\mathbf{M}}} = \kappa \otimes \left(\mathbb{C}^3\right)^*$$

where  $\kappa = \det \mathbb{C}^3$ .

In general, for  $\widetilde{M} = Hilb(\mathsf{Free}_3, \mathfrak{n})$  we have

$$T_{\widetilde{\mathbb{M}}} = (\mathbb{C}^3 - 1) \otimes \overline{V} \otimes V + V$$

by the construction of  $\widetilde{\mathbb{M}}$  as the space of 3 operators and a vector in V modulo the action of GL(V). Therefore

$$\begin{split} \mathsf{T}^{\mathrm{vir}} &= \mathsf{T}_{\widetilde{\mathbb{M}}} - \kappa^{-1} \otimes \mathsf{T}^*_{\widetilde{\mathbb{M}}} \\ &= V - \det \mathbb{C}^3 \otimes \overline{V} - \overline{V} \otimes V \otimes \sum (-1)^i \Lambda^i \mathbb{C}^3 \,, \end{split}$$

which gives a different and more direct proof of (3.4.30).

**Exercise 3.4.32.** ... or, rather, a combinatorial challenge. Is there a combinatorial formula for the character of  $T_{\widetilde{M}}$  at torus-fixed points and can one find some systematic cancellations in the first line of (3.4.31)?

**3.4.33.** Let

$$\tilde{\iota}: \mathbb{M} \hookrightarrow \widetilde{\mathbb{M}}$$

be the inclusion of  $M = Hilb(\mathbb{C}^3, points)$  into the Hilbert scheme of a free algebra. By our earlier discussion,

$$\tilde{\iota}_* O^{vir} = \Lambda^{\bullet} Obs^*$$

and therefore we can use equivariant localization on the smooth ambient space  $\widetilde{\mathbb{M}}$  to compute  $\chi(\mathbb{M}, \mathbb{O}^{vir})$ .

Let  $\pi$  be 3-dimensional partition and  $I_{\pi} \in Hilb \subset \widetilde{\mathbb{M}}$  the corresponding fixed point. Since

 $T_{\pi}^{vir} = T_{\pi}\widetilde{\mathbb{M}} - \kappa \otimes \left(T_{\pi}\widetilde{\mathbb{M}}\right)^*$  ,

we have

$$\mathsf{T}_{\pi}^{\mathrm{vir}} = \sum_{\mathbf{w}} \left( w - \frac{\kappa}{w} \right)$$

where the sum is over the weights w of  $T_{\pi}\widetilde{M}$ . Therefore

$$\mathcal{O}_{\text{Hilb}(\mathbb{C}^3,\mathfrak{n})}^{\text{vir}} = \sum_{|\pi|=\mathfrak{n}} \mathcal{O}_{\mathrm{I}_{\pi}} \prod \frac{1-w/\kappa}{1-w^{-1}}$$

in localized equivariant K-theory. This formula illustrates a very important notion of *virtual localization*, see in particular [19,29,38], which we now discuss.

**3.4.35.** Let a torus T act on a scheme  $\mathbb{M}$  with a T-equivariant perfect obstruction theory. For example,  $\mathbb{M}$  be DT moduli space for a nonsingular threefold X on which a torus T act. Let  $\mathbb{M}^T \subset \mathbb{M}$  be the subscheme of fixed points. We can decompose

$$\begin{aligned} \left( Def - Obs \right)|_{\mathbb{M}^{\mathsf{T}}} &= Def^{fixed} - Obs^{fixed} \\ &+ Def^{moving} - Obs^{moving} \end{aligned}$$

in which the fixed part is formed by trivial T-modules and the moving part by nontrivial ones.

**Exercise 3.4.37.** Check that for  $Hilb(\mathbb{C}^3, points)$  and the maximal torus  $T \subset GL(3)$  the fixed part of the obstruction theory vanishes.

By a result of [38], the fixed part of the obstruction theory is perfect obstruction theory for  $\mathbb{M}^T$  and defines  $\mathcal{O}_{\mathbb{M}^T}^{\text{vir}}$ . The virtual localization theorem of [19], see also [38] for a cohomological version, states that

$$(3.4.38) \hspace{1cm} \mathbb{O}_{\mathbb{M}}^{vir} = \iota_* \left( \mathbb{O}_{\mathbb{M}^T}^{vir} \otimes S^{\bullet} \left( Def^{moving} - Obs^{moving} \right)^* \right)$$

where

$$\iota: \mathbb{M}^\mathsf{T} \hookrightarrow \mathbb{M}$$

is the inclusion. Since, by construction, the moving part of the obstruction theory contains only nonzero T-weights, its symmetric algebra  $S^{\bullet}$  is well defined.

**Exercise 3.4.39.** Let f(V) be a Schur functor of the tautological bundle V over  $Hilb(\mathbb{C}^3, n)$ , for example

$$f(\mathcal{V}) = S^2 \mathcal{V}, \Lambda^3 \mathcal{V}, \dots$$

Write a localization formula for  $\chi(\text{Hilb}(\mathbb{C}^3, \mathfrak{n}), \mathcal{O}^{\text{vir}} \otimes f(\mathcal{V}))$ .

**3.4.40.** It remains to twist (3.4.34) by

$$\mathcal{K}_{vir}^{1/2} = det^{-1/2} \, T^{vir}$$

to deduce a virtual localization formula for  $\widehat{\mathbb{O}}^{vir}$ . It is convenient to define the transformation  $\widehat{a}(...)$ , a version of the  $\widehat{A}$ -genus, by

$$\widehat{a}(x+y) = \widehat{a}(x)\,\widehat{a}(y)$$
,  $\widehat{a}(w) = \frac{1}{w^{1/2} - w^{-1/2}}$ 

where w is a monomial, that is, a weight of T. For example

$$\widehat{\mathsf{a}}\left(\mathsf{T}_{\pi}^{vir}\right) = \prod_{w} \frac{(\kappa/w)^{1/2} - (w/\kappa)^{1/2}}{w^{1/2} - w^{-1/2}} \, ,$$

where the product is over the same weights w as in (3.4.34).

With this notation, we can state the following

Proposition 3.4.42. We have

$$\widehat{\mathfrak{O}}^{vir}_{Hilb(\mathbb{C}^3,\mathfrak{n})} = (-1)^{\mathfrak{n}} \sum_{|\pi| = \mathfrak{n}} \widehat{\mathsf{a}} \left(\mathsf{T}^{vir}_{\pi}\right) \, \mathfrak{O}_{\mathrm{I}_{\pi}}$$

in localized equivariant K-theory.

**Exercise 3.4.44.** Write a code to check a few first terms in z of Nekrasov's formula (3.3.7).

**Exercise 3.4.45.** Take the limit  $t_1, t_2, t_3 \to 1$  in Nekrasov's formula for  $\mathbb{C}^3$  and show that it correctly reproduces the formula for  $Z_{\mathbb{C}^3,points,coh}$  from Theorem 3.3.23.

## 3.5. Proof of Nekrasov's formula

**3.5.1.** Our next goal is to prove Nekrasov's formula for  $X = \mathbb{C}^3$ . By localization, this immediately generalizes to nonsingular toric threefolds. Later, when we discuss relative invariants, we will see the generalization to the relative setting. The path from there to general threefolds is the same as in [50].

Our proof of Theorem (3.3.6) will have two parts. In the first step, we prove

(3.5.2) 
$$Z_{\text{C}^3,\text{points}} = S^{\bullet} \frac{\star}{(1 - t_1^{-1})(1 - t_2^{-1})(1 - t_3^{-1})}$$

where

$$\star \in \mathbb{Z}\left[t_1^{\pm 1}, t_2^{\pm 1}, t_3^{\pm 1}, (t_1t_2t_3)^{1/2}\right][[z]]$$

is a formal power series in z, without a constant term, with coefficients in Laurent polynomials. In the second step, we identify the series  $\star$  by a combinatorial argument involving equivariant localization.

The first step is geometric and, in fact, we prove that

$$Z_{\mathbb{C}^3, points} = S^{\bullet}\chi(\mathbb{C}^3, \mathcal{G}), \quad \mathcal{G} = \sum_{i=1}^{\infty} z^i \mathcal{G}_i, \quad \mathcal{G}_i \in K_{GL(3)}(\mathbb{C}^3),$$

where each  $g_i$  is constructed iteratively starting from

$$\mathfrak{G}_1 = -\widehat{\mathfrak{O}}^{\mathrm{vir}}_{\mathrm{Hilb}(\mathbb{C},1)}$$
.

The same argument applies to many similar sheaves and moduli spaces, including, for example, the generating function

(3.5.4) 
$$\sum_{n} z^{n} \chi(\text{Hilb}(\mathbb{C}^{3}, n), \mathcal{O}^{\text{vir}})$$

in which we have  $z^n$  instead of  $(-z)^n$  and plain  $\mathfrak{O}^{\text{vir}}$  instead of the symmetrized virtual structure sheaf. The second part of the proof, however, doesn't work for  $\mathfrak{O}^{\text{vir}}$  and I don't know a reasonable formula for the series (3.5.4).

It is natural to prove (3.5.3) in that greater generality and this will be done in Proposition 5.3.19 in Section 5.3.18 below. For now, we assume (3.5.3) and proceed to the second part of the proof, that is, to the identification of the polynomial  $\star$  in (3.5.2).

**3.5.5.** For Hilb( $\mathbb{C}^3$ , n), the line bundles  $\mathcal{L}_4$  and  $\mathcal{L}_5$  in (3.2.16) are necessarily trivial with, perhaps, a nontrivial equivariant weight. Hence the determinant term in (3.2.16) is a trivial bundle with weight

(3.5.6) 
$$\det^{1/2} \pi_{\mathbf{M},*} (\mathfrak{F} \otimes (\mathcal{L}_4 - \mathcal{L}_5)) = \left( \frac{\text{weight}(\mathcal{L}_4)}{\text{weight}(\mathcal{L}_5)} \right)^{n/2},$$

which can be absorbed in the variable *z*. Therefore, without loss of generality, we can assume that

$$\mathcal{L}_4 = \mathcal{L}_5 = \kappa^{-1/2} = \frac{1}{(t_1 t_2 t_3)^{1/2}}$$
 ,

where  $t_i$ 's are the weights of the GL(3) action on  $\mathbb{C}^3$ , in which case the term (3.5.6) is absent.

We define

$$t_4 = \frac{z}{\kappa^{1/2}}, \quad t_5 = \frac{1}{z \, \kappa^{1/2}},$$

so that  $t_1, \ldots, t_5$  may be interpreted as the weights of the action of  $SL(5) \supset \mathbb{C}_z^{\times}$  on  $Z \cong \mathbb{C}^5$ . With this notation, what needs to be proven is

$$\begin{split} Z_{C^3,points} &= S^{\bullet} \ \widehat{a} \left( \sum_{i=1}^5 t_i - \sum_{i < j \leqslant 3} t_i t_j \right) \\ &= S^{\bullet} \ \frac{\prod_{i < j \leqslant 3} ((t_i t_j)^{1/2} - (t_i t_j)^{-1/2})}{\prod_{i \leqslant 5} (t_i^{1/2} - t_i^{-1/2})} \,. \end{split}$$

3.5.8.

**Exercise 3.5.9.** Prove that the localization weight (3.4.41) of any nonempty 3-dimensional partition is divisible by  $t_1t_2 - 1$ . In fact, the order of vanishing of this weight at  $t_1t_2 = 1$  is computed in Section 4.5 of [72].

By symmetry, the same is clearly true for all  $t_it_j-1$  with  $i< j \leqslant 3$ . Note that plethystic substitutions  $\{t_i\} \mapsto \{t_i^k\}$  preserve vanishing at  $t_it_j=1$ . Therefore,

using (3.5.2), we may define

$$\Rightarrow \in \mathbb{Z}[t_1^{\pm 1/2}, t_2^{\pm 1/2}, t_3^{\pm 1/2}][[z]]$$

so that

$$Z_{\mathbb{C}^3,points} = S^{\bullet} \left( \text{tr} \prod_{i=1}^3 \frac{(\kappa/t_i)^{1/2} - (t_i/\kappa)^{1/2}}{t_i^{1/2} - t_i^{-1/2}} \right).$$

**Proposition 3.5.11.** We have

$$\Leftrightarrow \in \mathbb{Z}[\kappa^{\pm 1}][[z]],$$

that is, this polynomial depends only on the product  $t_1t_2t_3$ , and not on the individual  $t_i$ 's.

Proof. A fraction of the form

$$\frac{(\kappa/w)^{1/2} - (w/\kappa)^{1/2}}{w^{1/2} - w^{-1/2}}$$

remains bounded and nonzero as  $w^{\pm 1} \to \infty$  with  $\kappa$  fixed. Therefore, both the localization contributions (3.4.41) and the fraction in (3.5.10) remain bounded as  $t_i^{\pm 1} \to \infty$  in such a way that  $\kappa$  remains fixed. We conclude that the Laurent polynomial  $\hat{\kappa}$  is bounded at all such infinities and this means it depends on  $\kappa$  only.

This is our first real example of rigidity.

**3.5.12.** The proof of Nekrasov's formula for  $\mathbb{C}^3$  will be complete if we show the following

## Proposition 3.5.13.

$$\label{eq:tau_state} \mbox{$\stackrel{\ \ \, :}{\ \ \, :}$} = \frac{1}{(t_4^{1/2} - t_4^{-1/2})(t_5^{1/2} - t_5^{-1/2})} = -\frac{z}{(1 - \kappa^{1/2}\,z)(1 - \kappa^{-1/2}\,z)}$$

To compute  $\, \, \! \! \! \! \! \! \! \! \! \! \! \! \! \! \! \! \!$ 

$$\frac{(\kappa/w)^{1/2} - (w/\kappa)^{1/2}}{w^{1/2} - w^{-1/2}} \to \begin{cases} -\kappa^{-1/2}, & w \to \infty, \\ -\kappa^{1/2}, & w \to 0, \end{cases}$$

we conclude that

$$\widehat{\mathsf{a}}\left(\sum w_{\mathfrak{i}} - \kappa \sum w_{\mathfrak{i}}^{-1}\right) \to (-\kappa^{1/2})^{index}$$

where

$$index = \# \left\{ i \left| w_i \to 0 \right\} - \# \left\{ i \left| w_i \to \infty \right\} \right. \right.$$

For the computation of  $\, \stackrel{\cdot}{\approx} \,$  we are free to send  $t_i$  to infinity in any way we like, as long as their product stays fixed. As we will see, a particularly nice choice is

(3.5.14) 
$$t_1, t_3 \to 0, |t_1| \ll |t_3|, \kappa = \text{fixed}.$$

For the fraction in (3.5.10) we have

$$\prod_{i=1}^3 \frac{(\kappa/t_i)^{1/2} - (t_i/\kappa)^{1/2}}{t_i^{1/2} - t_i^{-1/2}} \to (-\kappa^{1/2})^{index(C^3)} = -\kappa^{1/2} \,.$$

Thus Proposition 3.5.13 becomes a corollary of the following

**Proposition 3.5.15.** Let the variables  $t_i$  go to infinity of the torus as in (3.5.14). Then

(3.5.16) 
$$Z_{X,points} \to S^{\bullet} \frac{\kappa^{1/2} z}{(1 - \kappa^{1/2} z)(1 - \kappa^{-1/2} z)}$$
.

This is a special case of the computations of *index vertices* from Section 7 of [67] and the special case of the limit (3.5.14) corresponds to the *refined vertex* of Iqbal, Kozcaz, and Vafa in [41]. We will now show how this works in the example at hand.

### 3.5.17. Recall the formula

$$T_{I_{\pi}}\widetilde{\mathbb{M}} = (\mathbb{C}^3 - 1) \otimes \overline{V} \otimes V + V$$

for tangent space to  $\widetilde{\mathbb{M}}$  at a point corresponding to a 3-dimensional partition  $\pi$  with the generating function V. For a partition of size n, this is a sum of  $2n^2+n$  terms and, in principle, we need to compute the index of this very large torus module to know the asymptotics of  $\widehat{\mathfrak{a}}(T_\pi^{vir})$  as  $t\to\infty$ .

A special feature of the limit (3.5.14) is that one can see a cancellation of  $2n^2$  terms in the index, with the following result

**Lemma 3.5.18.** *In the limit* (3.5.14),

$$index\left(T_{I_{\pi}}\widetilde{\mathbb{M}}\right) = index\left(t_{3}^{k}V\right)$$
,

for any k is such that  $k > |\pi|$  but  $|t_1| \ll |t_3|^k$ .

This Lemma is proven in the Appendix to [67]. Clearly

$$index\left(t_{3}^{k}\,V\right) = \sum_{\square = \left(\mathfrak{i}_{1},\mathfrak{i}_{2},\mathfrak{i}_{3}\right)\in\pi}sgn\left(\mathfrak{i}_{2} - \mathfrak{i}_{1} + 0\right)$$

and therefore Proposition 3.5.15 becomes the

(3.5.19) 
$$z\kappa^{1/2} = q_0 = q_1 = q_2 = \dots$$
$$z\kappa^{-1/2} = q_{-1} = q_{-2} = \dots$$

case of the following generalization of McMahon's enumeration

Theorem 3.5.20 ([73,74]).

(3.5.21) 
$$\sum_{\pi} \prod_{\square = (i_1, i_2, i_3) \in \pi} q_{i_2 - i_1} = S^{\bullet} \sum_{\alpha \leqslant 0 \leqslant b} q_{\alpha} q_{\alpha+1} \cdots q_{b-1} q_b$$

With the specialization (3.5.19) the sum under  $S^{\bullet}$  in (3.5.21) become the series expansion of the fraction in (3.5.16).

**3.5.22.** We conclude with a sequence of exercises that will lead the reader through the proof of Theorem 3.5.20. It is based on introducing a *transfer matrix*, a very much tried-and-true tool in statistical mechanics and combinatorics.

A textbook example of transfer matrix arises in 2-dimensional Ising model on a torus. The configuration space in that model are assignments of  $\pm 1$  spins to sites x of a rectangular grid, that is, functions

$$\sigma: \{1, ..., M\} \times \{1, ..., N\} \rightarrow \{\pm 1\}$$

Each is weighted with

$$\operatorname{Prob}(\sigma) \propto W(\sigma) = \exp(-\beta E(\sigma))$$
,

where  $\beta$  is the inverse temperature and the energy E is defined by

$$E(\sigma) = -\sum_{\text{nearest neighbors } x \text{ and } x'} \sigma(x)\sigma(x'),$$

with periodic boundary conditions.

Now introduce a vector space

$$V \cong (\mathbb{C}^2)^N$$

with a basis formed by all possible spin configurations  $\vec{\sigma}$  in one column of our grid. Define a diagonal matrix  $W^v$  and a dense matrix  $W^h$  by

(3.5.23) 
$$W_{\vec{\sigma},\vec{\sigma}}^{v} = exp \left( -\beta \sum_{\substack{\text{vertical neighbors} \\ \text{in column } \vec{\sigma}}} \sigma(x) \sigma(x') \right)$$

(3.5.24) 
$$W_{\vec{\sigma}_{1},\vec{\sigma}_{2}}^{h} = exp \left( -\beta \sum_{\substack{\text{horizontal neighbors} \\ \text{in columns } \vec{\sigma}_{1} \text{ and } \vec{\sigma}_{2}}} \sigma_{1}(x) \sigma_{2}(x') \right),$$

see Figure 3.5.26.

Exercise 3.5.25. Prove that

$$\sum_{\{\sigma\}} W(\sigma) = tr(W^v W^h)^M$$

where the summation is over all  $2^{MN}$  spin configurations  $\{\sigma\}$ .

The matrix  $W^vW^h$  is an example of a transfer matrix. Onsager's great discovery was the diagonalization of this matrix. Essentially, he has shown that the transfer matrix is in the image of a certain matrix  $g \in O(2N)$  in the spinor representation of this group.

**3.5.27.** Now in place of the spinor representation of O(2N) we will have the action of the Heisenberg algebra  $\widehat{\mathfrak{gl}}(1)$  on

![](_page_45_Picture_2.jpeg)

FIGURE 3.5.26. The transfer matrix W<sup>v</sup>W<sup>h</sup> of the Ising model captures the interactions of the spins in two adjacent columns along the highlighted edges. Iterations of the transfer matrix cover all spins and all edges.

= polynomial representations of  $GL(\infty)$ .

This space has an orthonormal basis  $\{s_{\lambda}\}$  of Schur functions, that is, the characters of the Schur functors  $S^{\lambda}\mathbb{C}^{\infty}$  of the defining representation of  $GL(\infty)$ . It is indexed by 2-dimensional partitions  $\lambda$  which will arise as slices of 3-dimensional partitions  $\pi$  by planes  $i_2-i_1=$  const.

The diagonal operator W<sup>v</sup> will be replaced by the operator

$$q^{|\cdot|} s_{\lambda} = q^{|\lambda|} s_{\lambda}$$
.

In place of the nondiagonal operator Wh, we will use the operators

$$\Gamma_{-}(z) = \left(\sum_{k\geqslant 0} z^k \, \mathsf{S}^k \mathbb{C}^{\infty}\right) \otimes$$

and its transpose  $\Gamma_+$ . The character of  $S^kC^\infty$  is the Schur function  $s_k$ . It is well known that

$$\Gamma_{-}(z) s_{\lambda} = \sum_{\mu} z^{|\mu| - |\lambda|} s_{\mu}$$

where the summation is over all partitions  $\mu$  such that  $\mu$  and  $\lambda$  interlace, which means that

$$\mu_1 \geqslant \lambda_1 \geqslant \mu_2 \geqslant \lambda_2 \geqslant \dots$$

Exercise 3.5.28. Prove that

$$\begin{split} \sum_{\pi} \prod_{\square = (i_1, i_2, i_3) \in \pi} q_{i_2 - i_1} &= \\ &= \left( \cdots \Gamma_{\!+}(1) \, q_{-1}^{|\cdot|} \, \Gamma_{\!+}(1) \, q_0^{|\cdot|} \, \Gamma_{\!-}(1) \, q_1^{|\cdot|} \, \Gamma_{\!-}(1) \, q_2^{|\cdot|} \cdots s_\varnothing, s_\varnothing \right) \,. \end{split}$$

**Exercise 3.5.29.** Prove that  $q^{|\cdot|}\Gamma_{-}(z) = \Gamma_{-}(qz) q^{|\cdot|}$  and that

$$\Gamma_{+}(z) \Gamma_{-}(w) = \frac{1}{1 - zw} \Gamma_{-}(w) \Gamma_{+}(z)$$

if |zw| < 1. Deduce Theorem 3.5.20.

**3.5.30.** Ultimately, the idea of transfer matrix rests on certain fundamental principles of mathematical physics which may be applied both in the discrete and continuous situations.

The first such principle is *gluing* local field theories, which in the discrete situation means the following. Suppose we want to compute a partition function of the form

$$Z = \sum_{\varphi \in \Phi^\Omega} e^{-E(\varphi)}$$

where Ω is a graph, Φ<sup>Ω</sup> is the space of functions

$$\phi:\Omega\to\Phi$$

and

$$\mathsf{E}(\varphi) = \sum_{x,y \in \Omega} V_2(x,y,\varphi(x),\varphi(y)) + \sum_{x \in \Omega} V_1(x,\varphi(x)) \,.$$

For example, for the Ising model we have Φ " t˘1u,

$$V_2(x,y,\varphi(x),\varphi(y)) = \begin{cases} -\beta\varphi(x)\varphi(y)\,, & \text{$x$ and $y$ are neighbors ,} \\ 0 & \text{otherwise ,} \end{cases}$$

and V<sup>1</sup> " 0 if there is no external magnetic field.

Suppose the pair potential V<sup>2</sup> has finite range, that is, suppose there exists a constant R such that

$$distance(x,y) > R \Rightarrow V_2(x,y,...) = 0.$$

For example, for the Ising model R " 1. Suppose

$$\Omega = \Omega_1 \sqcup B \sqcup \Omega_2$$

where the boundary region B disconnects Ω<sup>1</sup> from Ω<sup>2</sup> in the sense that

$$distance(\Omega_1, \Omega_2) > R$$

as in Figure 3.5.33. Then

$$Z = \sum_{\varphi_B \in \Phi^B} e^{-E(\varphi_B)} \, Z(\Omega_1 \big| \varphi_B) \, Z(\Omega_2 \big| \varphi_B) \, , \label{eq:Z}$$

where the partition functions ZpΩ<sup>1</sup> ˇ ˇφBq with boundary conditions imposed on B are defined by

$$Z(\Omega_i \big| \varphi_B) = \sum_{\varphi_{\Omega_i} \in \Phi^{\Omega_i}} e^{-E(\varphi_{\Omega_i}) - E(\varphi_{\Omega_i} \big| \varphi_B)}$$

with

$$\mathsf{E}(\varphi_{\Omega_{\mathfrak{i}}}\big|\varphi_{B}) = \sum_{x \in \Omega_{\mathfrak{i}}, y \in B} V_{2}(x,y,\varphi(x),\varphi(y))\,.$$

Effectively, fixing the boundary conditions on B modifies the 1-particle potential V1 in an tube of radius R around B.

If V<sup>1</sup> and V<sup>2</sup> are real, then clearly (3.5.31) may be written as

$$Z = \left( Z(\Omega_1 | \cdot), Z(\Omega_2 | \cdot) \right)_{L^2(\Phi^B, e^{-E(\Phi_B)})}$$

.

In any event, it may be more prudent to interpret (3.5.31) as a pairing between a pair of dual vector spaces, as in the continuous limit the two partition functions paired in (3.5.31) may turn out to be objects of rather different nature. In this very abstract form, gluing says that if B disconnects Ω, then partition functions ZpΩ<sup>1</sup> ¨ q give a pair of vectors in dual vector spaces so that

(3.5.32) 
$$Z = \langle Z(\Omega_1 | \cdot), Z(\Omega_2 | \cdot) \rangle.$$

This is probably very familiar to most readers from TQFT context, but is not restricted to topological theories.

![](_page_47_Picture_7.jpeg)

Figure 3.5.33. If the domain Ω is glued from two pieces then the partition function is a pairing of a vector and a covector.

The second principle on which transfer matrices rest is that if B itself is disconnected

$$B = B_1 \sqcup B_2$$
, distance $(B_1, B_2) > R$ ,

then

$$\mathsf{L}^2(\Phi^B) = \mathsf{L}^2(\Phi^{B_1}) \otimes \mathsf{L}^2(\Phi^{B_2}) \, ,$$

as inner product spaces. Again, in continuous limit, it may be better to talk about operators from one functional space to another — the transfer matrix, or the evolution operator. Multiplying such operators, we can build larger domains from small pieces (e.g. a long cylinder from a short one) like we did in the two examples above.

![](_page_47_Picture_14.jpeg)

Figure 3.5.34. If the boundary has two components then the partition function is an operator.

A larger supply of operators may be obtained by modifying the partition function ZpΩ ˇ ˇB<sup>1</sup> Y B2q by, for example, inserting a local observable.

**3.5.35.** The purpose of this abstract discussion of transfer matrices is that our goals in these notes may be directly compared to understanding the transfer matrix of the Ising model or 3-dimensional partitions in terms of representation theory of a certain algebra.

For a mathematical physicist, the study of quasimaps to Nakajima varieties appears as a low energy limit in the study of supersymmetric gauge theories. A gauge theory is specified by a choice of a gauge group G and a representation in which the matter fields of theory transform. If the choices are made like in the next section, then a Nakajima variety X appears as the one of the components (the Higgs branch) of the moduli spaces of vacua. In the low energy limit (also known as the thermodynamic, or infrared limit), the state of the system is described as a modulated vacuum state, or as a map from the spacetime to the moduli spaces of vacua.

K-theory of quasimaps f : C 99K X, where C is a Riemann surface, is relevant for the study of 3-dimensional supersymmetric gauge theories on manifold of the form C ˆ S 1 . General ideas about cutting and gluing apply to the surface C. In particular, KpXq will be the vector space associated to a puncture in C and various vectors and operators in this space that will occupy us below may be interpreted as partition functions with given boundary conditions. The eventual goal will be to understand these operators in terms of representation theory of a certain quantum loop algebra Uh¯ pgˆq acting on KpXq, see Sections 9, 10, and [75].

This quantum loop algebra action extends the actions constructed by Nakajima [64]. Nekrasov and Shatashvili [68, 69] were the first to realize this connection between supersymmetric gauge theories, quantum integrable systems, and Nakajima theory.

## **4. Nakajima varieties**

## **4.1. Algebraic symplectic reduction**

**4.1.1.** Symplectic reduction was invented in classical mechanics [2] to deal with the following situation. Let M be the configuration space of a mechanical system and T ˚M — the corresponding phase space. A function H, called Hamiltonian, generates dynamics by

$$\frac{\mathrm{d}}{\mathrm{d}t}\mathsf{f} = \{\mathsf{H},\mathsf{f}\}$$

where f is an arbitrary function on T ˚<sup>M</sup> and t ¨ , ¨ u is the Poisson bracket. If this dynamics commutes with a Hamiltonian action of a Lie group G, it descends to a certain reduced phase space T ˚M{{{{G. The reduced space could be a more complicated variety but of smaller dimension, namely

$$dim\,T^*M/\!\!/\!\!/G=2\,dim\,M-2\,dim\,G\,.$$

**4.1.2.** In the algebraic context, let a reductive group G act on a smooth algebraic variety M. The induced action on T ˚M, which is a algebraic symplectic variety, is Hamiltonian: the function

$$(4.1.3) \hspace{1cm} \mu_{\xi}(p,q) = \left\langle p, \xi \cdot q \right\rangle, \quad q \in M, p \in T_{\alpha}^{*}M,$$

generates the vector field  $\xi \in \text{Lie}(G)$ . This gives a map

$$\mu: T^*M \to Lie(G)^*$$
,

known as the *moment* map, because in its mechanical origins G typically included translational or rotational symmetry.

**4.1.4.** We can form the algebraic symplectic reduction

(4.1.5) 
$$X = T^*M /\!\!/ G = \mu^{-1}(0) /\!\!/ G = \mu^{-1}(0)_{semistable} / G ,$$

where a certain choice of stability is understood.

**4.1.6.** The zero section  $M \subset T^*M$  is automatically inside  $\mu^{-1}(0)$  and

$$T^*(M_{\text{free}}/G) \subset X$$

is an open, but possibly empty, subset. Here  $M_{free} \subset M$  is the set of semistable points with trivial stabilizer. Thus algebraic symplectic reduction is an improved version of the cotangent bundle to a G-quotient.

**4.1.7.** The Poisson bracket on  $T^*M$  induces a Poisson bracket on X, which is symplectic on the open set of points with trivial stabilizer. In general, however, there will be other, singular, points in X.

Finite stabilizers are particularly hard to avoid. Algebraic symplectic reduction is a source of great many Poisson orbifolds, but it very rarely outputs an algebraic symplectic variety.

## 4.2. Nakajima quiver varieties [35,62,63]

**4.2.1.** Nakajima varieties are a remarkable class of symplectic reductions for which finite stabilizers can be avoided. For them,

$$G = \prod GL(V_i)$$

and M is a linear representation of the form

$$(4.2.2) \hspace{1cm} \mathsf{M} = \bigoplus_{i,j} \mathsf{Hom}(V_i,V_j) \otimes Q_{ij} \oplus \bigoplus_i \mathsf{Hom}(W_i,V_i) \,.$$

Here  $Q_{ij}$  and  $W_i$  are multiplicity spaces, so that

$$(4.2.3) \qquad \qquad \prod \operatorname{GL}(Q_{ij}) \times \prod \operatorname{GL}(W_i) \times \mathbb{C}_h^{\times} \to \operatorname{Aut}(X),$$

where the  $C_{\hbar}^{\times}$ -factor scales the cotangent directions with weight  $\hbar^{-1}$ , and hence scales the symplectic form on X with weight  $\hbar$ .

- **4.2.4.** In English, the only representations allowed in M are
  - the defining representations  $V_i$  of the  $GL(V_i)$ -factors,
  - the adjoint representations of the same factors,
  - representations of the form  $Hom(V_i, V_i)$  with  $i \neq j$ .

Latter are customary called bifundamental representations in gauge theory context. Note that  $T^*M$  will also include the duals  $V_i^*$  of the defining representations.

What is special about these representation is that the stabilizer  $G_y$  of any point  $y \in T^*M$  is the set of invertible elements in a certain associative algebra

$$E_y \subset \bigoplus End(V_i)$$

over the base field C, and hence cannot be a nontrivial finite group.

**4.2.5.** The data of the representation (4.2.2) is conveniently encoded by a graph, also called a quiver, in which we join the ith vertex with the jth vertex by dim  $Q_{ij}$  arrows. After passing to T\*M, the orientation of these arrows doesn't matter because

$$\text{Hom}(V_i,V_j)^* = \text{Hom}(V_j,V_i).$$

Therefore, it is convenient to assume that only one of the spaces  $Q_{ij}$  and  $Q_{ji}$  is nonzero for  $i \neq j$ .

To the vertices of the quiver, one associates two dimension vectors

$$v = (\dim V_i)$$
,  $w = (\dim W_i) \in \mathbb{Z}_{\geq 0}^I$ ,

where  $I = \{i\}$  is the set of vertices.

**4.2.6.** The quotient in (4.1.3) is a GIT quotient and choice of stability condition is a choice of a character of G, that is, a choice of vector  $\theta = \mathbb{Z}^I$ , up to positive proportionality. For  $\theta$  away from certain hyperplanes, there are no strictly semistable points and Nakajima varieties are holomorphic symplectic varieties.

**Exercise 4.2.7.** Let Q be a quiver with one vertex and no arrows. Show that, for either choice of the stability condition, the corresponding Nakajima varieties are the cotangent bundles of Grassmannians.

**Exercise 4.2.8.** Let Q be a quiver with one vertex and one loop. For w=1, identify the Nakajima varieties with  $Hilb(\mathbb{C}^2, \mathfrak{n})$  where  $\mathfrak{n}=v$ .

## 4.3. Quasimaps to Nakajima varieties

**4.3.1.** The general notion of a quasimap to a GIT quotient is discussed in detail in [20], here we specialize it to the case of Nakajima varieties X. Twisted quasimaps, which will play an important technical role below, are a slight variation on the theme.

Let T be the maximal torus of the group (4.2.3) and A = Kerħ the subtorus preserving the symplectic form. Let

$$(4.3.2) \sigma: \mathbb{C}^{\times} \to \mathsf{A}$$

be a cocharacter of A, it will determine how the quasimap to X is twisted. In principle, nothing prevents one from similarly twisting by a cocharacter of T, but this will not be done in what follows.

- **4.3.3.** Let  $C \cong \mathbb{P}^1$  denote the domain of the quasimap. Since A acts on multiplicity spaces  $W_i$  and  $Q_{ij}$ , a choice of  $\sigma$  determines bundles  $W_i$  and  $Q_{ij}$  over C as bundles associated to  $\mathcal{O}(1)$ . To fix equivariant structure we need to linearize  $\mathcal{O}(1)$  and the natural choice is  $\mathcal{O}(p_1)$ , where  $p_1 \in C$  is a fixed point of the torus action.
- **4.3.4.** By definition, a twisted quasimap

$$f: C \longrightarrow X$$

is a collection of vector bundles  $V_i$  on C of ranks v and a section

$$f \in H^0(C, \mathcal{M} \oplus \mathcal{M}^* \otimes h^{-1})$$

satisfying  $\mu = 0$ , where

$$(4.3.5) \hspace{1cm} \mathcal{M} = \bigoplus_{i,j} \mathcal{H}\!\mathit{om}(\mathcal{V}_i,\mathcal{V}_j) \otimes \mathcal{Q}_{ij} \oplus \bigoplus_i \mathcal{H}\!\mathit{om}(\mathcal{W}_i,\mathcal{V}_i) \,.$$

Here  $\hbar^{-1}$  is a trivial line bundle with weight  $\hbar^{-1}$ , inserted to record the T-action on quasimaps (in general, the centralizer of  $\sigma$  in  $\operatorname{Aut}(X)$  acts on twisted quasimaps). One can replace  $\hbar^{-1}$  by an arbitrary line bundle and that will correspond to T-twisted quasimaps.

**4.3.6.** Let  $p \in C$  be a point in the domain of f and fix a local trivialization of  $Q_{ij}$  and  $W_i$  at p.

The value f(p) of a quasimap at a point  $p \in C$  gives a well-defined G-orbit in  $\mu^{-1}(0) \in T^*M$  or, in a more precise language, it defines a map

$$(4.3.7) \hspace{1cm} ev_{\mathfrak{p}}(f) = f(\mathfrak{p}) \in \left[\mu^{-1}(0)/G\right] \supset X$$

to the quotient stack, which contains  $X = \mu^{-1}(0)_{stable}/G$  as an open set. By definition, a quasimap is *stable* if

$$f(p) \in X$$

for all but finitely many points of C. These exceptional points are called the *singularities* of the quasimap.

**4.3.8.** We consider twisted quasimaps up to isomorphism that is required to be an identity on C and on the multiplicity bundles  $Q_{ij}$  and  $W_i$ . In other words, we consider quasimaps from parametrized domains, and twisted in a fixed way. We define

(4.3.9) 
$$QM(X) = \{\text{stable twisted quasimaps to } X\}/\cong$$

with the understanding that it is the data of the bundles  $\mathcal{V}_i$  and of the section f that varies in these moduli spaces, while the curve C and the twisting bundles  $\mathcal{Q}_{ij}$  and  $\mathcal{W}_i$  are fixed<sup>4</sup>.

$$\pi: C' \to C$$

collapses some chains of  $\mathbb{P}^1$ s. The bundles  $\mathcal{Q}_{ij}$  and  $\mathcal{W}_i$  are then pulled back by  $\pi$ .

 $<sup>^4</sup>$  More precisely, for relative quasimaps, to be discussed below, the curve C is allowed to change to  $C^\prime$  where

As defined, QM(X) is a union of countably many moduli spaces of quasimaps of given degree, see below.

**4.3.10.** The degree of a quasimap is the vector

$$(4.3.11) deg f = (deg \mathcal{V}_i) \in \mathbb{Z}^I.$$

For nonsingular quasimaps, this agrees with the usual notion of degree modulo the expected generation of  $H^2(X,\mathbb{Z})$  by first Chern classes of the tautological bundles.

The graph of a nonsingular twisted quasimap is a curve in a nontrivial X bundle over C, the cycles of effective curves in which lie in an extension of  $H_2(C,\mathbb{Z})$  by  $H_2(X,\mathbb{Z})$ . Formula (4.3.11) is a particular way to split this extension<sup>5</sup>.

**4.3.12.** Every fixed point  $x \in X^{\sigma}$  defines a "constant" twisted quasimap with f(c) = x for all  $c \in C$ . The degree of this constant map, which is nontrivial, is computed as follows.

A fixed point of  $a \in A$  in a quiver variety means a acts in the vector spaces  $V_i$  so that all arrow maps are a-equivariant. This gives the i-tautological line bundle

$$(4.3.13) \mathcal{L}_{i} = \det V_{i}$$

an action of a, producing a locally constant map

$$(4.3.14) \mu: X^{\mathsf{A}} \to \operatorname{Pic}(X)^{\vee} \otimes \mathsf{A}^{\vee},$$

compatible with restriction to subgroups of A. We have

(4.3.15) 
$$\deg (f \equiv x) = \langle \mu(x), -\infty \sigma \rangle$$

where we used the pairing of characters with cocharacters.

The map (4.3.14) can be seen as the universal *real* moment map: the moment maps for different Kähler forms

$$\omega_{\mathbb{R}} \in H^{1,1}(X) = Pic(X) \otimes_{\mathbb{Z}} \mathbb{R}$$

map fixed points to different points of

$$\operatorname{Lie}(\mathsf{A}_{compact})^{\vee} \cong \mathsf{A}^{\vee} \otimes_{\mathbb{Z}} \mathbb{R} \,.$$

**4.3.16.** Moduli spaces of stable quasimaps have a perfect obstruction theory with

$$(4.3.17) T_{vir} = H^{\bullet}(\mathcal{M} \oplus \hbar^{-1}\mathcal{M}^{*}) - (1 + \hbar^{-1}) \sum Ext^{\bullet}(\mathcal{V}_{i}, \mathcal{V}_{i}).$$

The second term accounts for the moment map equations as well as for

$$\begin{aligned} -\operatorname{Hom}(\mathcal{V}_{i},\mathcal{V}_{i}) &= -\operatorname{Lie}\operatorname{Aut}(\mathcal{V}_{i}) \\ &\operatorname{Ext}^{1}(\mathcal{V}_{i},\mathcal{V}_{i}) &= \operatorname{deformations} \text{ of } \mathcal{V}_{i} \,. \end{aligned}$$

<sup>&</sup>lt;sup>5</sup> There is no truly canonical notion of a degree zero twisted quasimap and the prescription (4.3.11) depends on previously made choices. Concretely, if  $\sigma$  and  $\sigma'$  differ by something in the kernel of (4.2.3) then the corresponding twisted quasimap moduli spaces are naturally isomorphic. This isomorphism, however, may not preserve degree.

With our assumptions on the twist, the degree terms vanish in the Riemann-Roch formula, and we get

$$\operatorname{rk} T_{\operatorname{vir}} = \dim X$$
,

as the virtual dimension.

**4.3.18.** In general, [20] consider quasimaps to quotients  $X = Y/\!\!/ G$  where Y is an affine algebraic variety with an action of a reductive group G such that

$$\emptyset \neq Y_{G\text{-stable}} = Y_{G\text{-semistable}} \subset Y_{nonsingular}$$
.

Deformation theory of a quasimap  $f: C \longrightarrow X$  may be studied by

- first, deforming the quasimap in affine charts of C, and then
- patching these deformations together.

Global deformations and obstructions arise in the second step as cohomology of a certain complex constructed in first step. For the obstruction theory of quasimaps to be perfect, it is thus crucial that the local deformation theory is perfect, and this is achieved by requiring that Y is a *local complete intersection*. Further, to insure that  $H^1(C, local obstructions) = 0$ , we need

$$\dim \text{supp local obstructions} = 0$$

and this follows from stability of f, by which the generic point of C is mapped to the smooth orbifold  $Y_{G-stable}/\!\!/ G$ .

**4.3.19.** Let C be a smooth curve of arbitrary genus and

$$(4.3.20) Y =$$

the total space of two line bundles over C. We can use  $\mathcal{L}_1$  and  $\mathcal{L}_2$  to define T-twisted quasimaps from C to Hilb( $\mathbb{C}^2$ , n) as follows. By definition

$$f: C \dashrightarrow Hilb(\mathbb{C}^2, n)$$

is a vector bundle V on C of rank n together with a section

$$f = (v, v^{\vee}, X_1, X_2)$$

of the bundles

$$\mathbf{v} \in \mathbf{H}^{0}(\mathcal{V}),$$

$$\mathbf{v}^{\vee} \in \mathbf{H}^{0}(\mathcal{L}_{1}^{-1} \otimes \mathcal{L}_{2}^{-1} \otimes \mathcal{V}^{\vee}),$$

$$\mathbf{X}_{i} \in \mathbf{H}^{0}(\mathrm{End}(\mathcal{V}) \otimes \mathcal{L}_{i}^{-1}),$$

satisfying the equation

$$[X_1, X_2] + v v^{\vee} = 0$$

of the Hilbert scheme and the stability condition. The stability condition forces

$$[\mathsf{X}_1,\mathsf{X}_2]=0\,,$$

as in Exercise 4.2.8.

**Exercise 4.3.21.** Show this data defines a coherent sheaf F on the threefold Y, together with a section

$$s: \mathcal{O}_{\mathsf{Y}} \to \mathcal{F}.$$

**Exercise 4.3.22.** Show the quasimap data is in bijection with complexes

$$\mathcal{O}_{\mathsf{Y}} \xrightarrow{s} \mathcal{F},$$

of sheaves on Y such that:

- the sheaf F is 1-dimensional and *pure*, that is, has no 0-dimensional subsheaves, and
- the cokernel of the section s is 0-dimensional.

By definition, such complexes are parametrized by the Pandharipande-Thomas (PT) moduli spaces for Y.

**Exercise 4.3.23.** Compute the virtual dimension of the quasimap/PT moduli spaces.

## **5. Symmetric powers**

## **5.1. PT theory for smooth curves**

**5.1.1.** Let X be a nonsingular threefold. By definition, a point in the Pandharipande-Thomas moduli space is a pure 1-dimensional sheaf with a section

$$(5.1.2) 0_X \xrightarrow{s} \mathfrak{F}$$

such that dim Coker s " 0. Here pure means that F has no 0-dimensional subsheaves.

**Exercise 5.1.3.** Consider the the structure sheaf

$$\mathfrak{O}_{\mathbf{C}} = \mathfrak{O}_{\mathbf{X}} / \operatorname{Ann}(\mathfrak{F})$$

of the scheme-theoretic support of F. Show it is also pure 1-dimensional.

Another way of saying the conclusion of Exercise 5.1.3 is that C is a 1-dimensional Cohen-Macaulay subscheme of X, a scheme that for any point c P C has a function that vanishes at c but is not a zero divisor.

**5.1.4.** In this section, we consider the simplest case when C is a reduced smooth curve in X. This forces (5.1.2) to have the form

$$\mathfrak{O}_X \to \mathfrak{O}_C \to \mathfrak{O}_C(D) = \mathfrak{F}$$

where  $D \subset C$  is a divisor, or equivalently, a zero-dimensional subscheme, and the maps are the canonical ones. The moduli space, for fixed C, is thus

$$\mathbb{M} = \bigsqcup_{n \geqslant 0} S^n C = \bigsqcup_{n \geqslant 0} Hilb(C, n).$$

The full PT moduli space also has directions that correspond to deforming the curve C inside X, with deformation theory given by

$$Def(C) - Obs(C) = H^{\bullet}(C, N_{X/C}),$$

where  $N_{X/C}$  is the normal bundle to C in X.

Here we fix C and focus on (5.1.5). Our goal is to relate

$$Z_C = \chi(\mathbb{M}, \widehat{\mathbb{O}}^{vir})$$

to deformations of the curve *C* in the 4th and 5th directions in (1.3.3), that is, to  $H^{\bullet}(C, z\mathcal{L}_4 \oplus z^{-1}\mathcal{L}_5)$ .

**5.1.6.** Remarkably, we will see that all 4 directions of

$$(5.1.7) N_{Z/C} = N_{X/C} \oplus z \mathcal{L}_4 \oplus z^{-1} \mathcal{L}_5$$

enter the full PT computation completely symmetrically.

This finds a natural explanation in the conjectural correspondence [67] between K-theoretic DT counts and K-theoretic counting of membranes in M-theory. From the perspective of M-theory, the curve  $C \subset Z$  is a supersymmetric membrane and its bosonic degrees of freedom are simply motions in the transverse directions. All directions of  $N_{Z/C}$  contribute equally to those.

While Theorem 5.1.16 below is a very basic check of the conjectures made in [67], it does count as a nontrivial evidence in their favor.

**5.1.8.** As already discussed in Exercise 3.4.5, the moduli space  $\mathbb{M}$  is smooth with the cotangent bundle

$$\Omega^1 \mathbb{M} = H^0(\mathfrak{O}_D \otimes \mathfrak{K}_C)$$
.

Pandharipande-Thomas moduli spaces have a perfect obstruction theory which is essentially the same as the deformation theory from Section 3.4.26, that is, the deformation theory of complexes

$$\mathcal{O}_X \twoheadrightarrow \mathcal{F}$$

with a *surjective* map to  $\mathcal{F} \cong \mathcal{O}_{Z}$ . In particular,

(5.1.9) 
$$\operatorname{Def} - \operatorname{Obs} = \chi(\mathcal{F}) + \chi(\mathcal{F}, \mathcal{O}_X) - \chi(\mathcal{F}, \mathcal{F}).$$

**Exercise 5.1.10.** Prove that the part of the obstruction in (5.1.9) that corresponds to keeping the curve *C* fixed is given by

$$\begin{aligned} \text{Obs}\,\mathbb{M} &= \mathsf{H}^0(\mathsf{C}, \mathfrak{O}_\mathsf{D} \otimes \det \mathsf{N}_{\mathsf{X}/\mathsf{C}}) \\ &= \mathsf{H}^0(\mathsf{C}, \mathfrak{O}_\mathsf{D} \otimes \mathcal{K}_\mathsf{C} \, \mathcal{L}_4^{-1} \, \mathcal{L}_5^{-1}) \end{aligned}$$

and, in particular, is the cotangent bundle of  $\mathbb{M}$  if  $\mathfrak{K}_X \cong \mathfrak{O}_X$ .

Since M is smooth and the obstruction bundle has constant rank, we conclude

$$\mathcal{O}^{\mathrm{vir}}_{\mathbb{M}} = \Lambda^{\bullet} \mathrm{Obs}^{\vee}$$
.

Define the integers

$$h_i = \dim H^{\bullet}(C, \mathcal{L}_i) = \deg \mathcal{L}_i + 1 - \mathfrak{q}(C)$$

as the numbers from the Riemann-Roch theorem for  $\mathcal{L}_i$ .

### Lemma 5.1.12. We have

$$\begin{array}{ll} \left. (5.1.13) \quad \left. \widehat{\mathbb{O}}^{vir} \right|_{S^n \, C} \ = \ (-1)^{h_4} z^{\frac{h_4 + h_5}{2} + n} \left( \det H^\bullet(C, \mathcal{L}_4 - \mathcal{L}_5) \right)^{1/2} \otimes \Lambda^\bullet Obs \otimes \mathcal{L}_4^{\boxtimes n} \, . \\ \text{where } \mathcal{L}_4^{\boxtimes n} \text{ is an } S(n)\text{-invariant line bundle on } C^n \text{ which descends to a line bundle on } S^n C. \end{array}$$

Proof. We start the discussion of

$$\widehat{\mathbb{O}}^{vir} = \operatorname{prefactor} \, \mathbb{O}^{vir} \otimes \left( \mathfrak{K}_{vir} \otimes \operatorname{det} \, H^{\bullet}(\mathbb{O}_{\mathbb{C}}(\mathbb{D}) \otimes (\mathcal{L}_4 - \mathcal{L}_5)) \right)^{1/2}$$

with the prefactor. Since

$$\dim \chi(\mathcal{F}) = 1 - g(C) + \deg D$$

formula (3.2.17) specializes to

Since rk Obs = n, we have

$$0^{vir} = (-1)^n \Lambda^{\bullet} Obs \otimes (det Obs)^{-1} .$$

This proves (5.1.13) modulo

$$\mathcal{L}_{4}^{\boxtimes n} \stackrel{?}{=} \det H^{\bullet} (C, \mathcal{O}_{D} \otimes \mathcal{G})^{1/2}$$

where

$$\mathfrak{G} = \mathfrak{K}_C - \mathfrak{K}_C \, \mathcal{L}_4^{-1} \, \mathcal{L}_5^{-1} + \mathcal{L}_4 - \mathcal{L}_5 \, .$$

We observe <sup>6</sup> that for any two line bundles  $\mathcal{B}_1$ ,  $\mathcal{B}_2$  on C

$$det\, H^{\bullet}\left(C, \mathfrak{O}_D\otimes (\mathfrak{B}_1-\mathfrak{B}_2)\right) = (\mathfrak{B}_1/\mathfrak{B}_2)^{\boxtimes n}\,\text{,}$$

whence the conclusion.

**5.1.15.** In these notes, we focus on equivariant K-theory, that is, we compute equivariant Euler characteristics of coherent sheaves. This can be already quite challenging, but still much, much easier than computing individual cohomology groups of the same sheaves.

Our next result is a rare exception to this rule. Here we get the individual cohomology groups of  $\widehat{\mathbb{O}}^{vir}$  on  $S^nC$  as symmetric powers of  $H^{\bullet}(C,...)$ . When computing  $S^{\bullet}H^{\bullet}$ , one should keep in mind the sign rule — a product of two

<sup>&</sup>lt;sup>6</sup>It suffices to check this for  $\mathcal{B}_1 = \mathcal{B}_2(p)$  where  $p \in C$ . In this case  $(\mathcal{B}_1/\mathcal{B}_2)^{\boxtimes n}$  is the line bundles corresponding to the divisor  $\{D \ni p\} \subset S^nC$ .

odd cohomology classes picks up a sign when transposed. More generally, in a symmetric power of a complex

$$e^{\bullet} = \dots \xrightarrow{d} e^{i} \xrightarrow{d} e^{i+1} \xrightarrow{d} \dots$$

the odd terms are antisymmetric with respect to permutations.

The virtual structure sheaf  $\mathcal{O}^{vir}$  is defined on the level of derived category of coherent sheaves as the complex (3.2.3) itself. Lemma 5.1.12 shows that up to a shift and tensoring with a certain 1-dimensional vector space, the symmetrized virtual structure sheaf  $\hat{\mathcal{O}}^{vir}$  is represented by the complex

$$\begin{split} O_n^{\bullet} &= \Lambda^{\bullet} Obs \otimes \mathcal{L}_4^{\boxtimes n} \\ &= \mathcal{L}_4^{\boxtimes n} \stackrel{0}{\longrightarrow} \mathcal{L}_4^{\boxtimes n} \otimes Obs \stackrel{0}{\longrightarrow} \mathcal{L}_4^{\boxtimes n} \otimes \Lambda^2 Obs \stackrel{0}{\longrightarrow} \dots \end{split}$$

with zero differential. The differential is zero because our moduli space is cut out by the zero section of the obstruction bundle over  $S^nC$ .

In particular,

$$\mathbb{O}_1^{\bullet} = \mathcal{L}_4 \xrightarrow{0} \mathfrak{K}_C \otimes \mathcal{L}_5^{-1}$$
,

and hence by Serre duality

$$H^i(\mathbb{O}_1^\bullet) = \begin{cases} H^0(\mathcal{L}_4)\,, & i=0\,,\\ H^1(\mathcal{L}_4) \oplus H^1(\mathcal{L}_5)^\vee\,, & i=1\,,\\ H^0(\mathcal{L}_5)^\vee\,, & i=2\,,\\ 0\,, & \text{otherwise}\,. \end{cases}$$

In other words

$$\operatorname{H}^{\:\raisebox{3.5pt}{\text{\circle*{1.5}}}}(\mathbb{O}_1^{\:\raisebox{3.5pt}{\text{\circle*{1.5}}}}) = \operatorname{H}^{\:\raisebox{3.5pt}{\text{\circle*{1.5}}}}(\mathcal{L}_4) \oplus \operatorname{H}^{\:\raisebox{3.5pt}{\text{\circle*{1.5}}}}(\mathcal{L}_5)^{\vee}[-2]$$

where

$${\mathfrak C}[k]^{\mathfrak i}={\mathfrak C}^{k+\mathfrak i}$$

denotes the shift of a complex  $C^{\bullet}$  by k steps to the left.

#### Theorem 5.1.16.

(5.1.17) 
$$\sum_{n} z^{n} \operatorname{H}^{\bullet}(O_{n}^{\bullet}) = \operatorname{S}^{\bullet} z \operatorname{H}^{\bullet}(O_{1}^{\bullet}) .$$

It would be naturally very interesting to know to what extent our other formulas can be upgraded to the level of the derived category of coherent sheaves.

**5.1.18.** Recall the definition of the symmetrized symmetric algebra from Section 2.1.21 . Working again in K-theory, we have

$$(-1)^{h_4}z^{\frac{h_4}{2}}\left(\det \mathsf{H}^{\bullet}(\mathcal{L}_4)\right)^{1/2}\,\mathsf{S}^{\bullet}z\mathsf{H}^{\bullet}(\mathsf{C},\mathcal{L}_4)=\widehat{\mathsf{S}}^{\bullet}\mathsf{H}^{\bullet}(\mathsf{C},z\mathcal{L}_4)^{\vee}\;.$$

With this notation, Theorem 5.1.16 gives the following

## Corollary 5.1.19.

(5.1.20) 
$$\chi(\mathbb{M}, \widehat{\mathbb{O}}^{\text{vir}}) = \widehat{\mathsf{S}}^{\bullet}\mathsf{H}^{\bullet}(\mathsf{C}, z\mathcal{L}_4 \oplus z^{-1}\mathcal{L}_5)^{\vee}.$$

Since deformations of the curve C inside X contribute  $\hat{S}^{\bullet}H^{\bullet}(C, N_{X/C})^{\vee}$ , we see that, indeed, all directions (5.1.7) normal to C in Z contribute equally to the K-theoretic PT count.

**5.1.21.** As an example, let us take  $C = \mathbb{C}^1$  and work equivariantly. We have  $S^nC \cong \mathbb{C}^n$ , so there is no higher cohomology anywhere.

**Exercise 5.1.22.** Show Theorem 5.1.16 for  $C = \mathbb{C}^1$  is equivalent to the following identity, known as the q-binomial theorem

(5.1.23) 
$$\sum_{n\geq 0} z^n \prod_{i=1}^n \frac{1-m\,t^i}{1-t^i} = S^{\bullet} z \frac{1-m\,t}{1-t} = \prod_{k=0}^{\infty} \frac{1-z\,m\,t^{k+1}}{1-z\,t^k}.$$

**Exercise 5.1.24.** Prove (5.1.23) by proving a 1st order difference equation with respect to  $z \mapsto tz$  for both sides. This is a baby version of some quite a bit more involved difference equations to come.

#### **5.2. Proof of Theorem 5.1.16**

**5.2.1.** As a warm-up, let us start with the case

$$\mathcal{L}_4 = \mathcal{L}_5 = 0$$
,

in which case the theorem reduces to a classical formula, going back to Macdonald, for  $H^{\bullet}(\Omega^{\bullet}_{S^nC})$  and, in particular, for Hodge numbers of  $S^nC$ . It says that

(5.2.2) 
$$\sum_{n} z^{n} H^{\bullet} \left( S^{n} C, \Omega^{\bullet}_{S^{n} C} \right) = S^{\bullet} z H^{\bullet} (C, \Omega^{\bullet}_{C}),$$

and this equality is canonical, in particular gives an isomorphism of orbifold vector bundles over moduli of C.

Here  $\Omega^{\bullet}$  is not the de Rham complex, but rather the complex

$$\Omega^{\bullet} = 0 \xrightarrow{0} \Omega^{1} \xrightarrow{0} \Omega^{2} \xrightarrow{0} \dots$$

with zero differential, as above.

**5.2.3.** Let M be a manifold of some dimension and consider the orbifold

$$e^{M} = \bigsqcup_{n \geqslant 0} S^{n} M.$$

It has a natural sheaf of orbifold differential forms  $\Omega^{\bullet}_{\text{orb}}$ , which are the differential forms on  $M^{n}$  invariant under the action of S(n).

By definition, this means that

(5.2.4) 
$$\Omega_{\text{orb}}^{\bullet} = \pi_{*,\text{orb}} (\Omega^{\bullet})^{\boxtimes n}$$

where

$$\pi: M^n \to S^n M$$

is the natural projection and  $\pi_{*,orb}$  is the usual direct image of an S(n)-equivariant coherent sheaf followed by taking the S(n)-invariants. Since the map  $\pi$  is finite,

there are no higher direct images and from the triangle

$$M^n \xrightarrow{\pi} S^n M$$
point

we conclude that

$$H^{\bullet}(S^{n}M, \Omega_{orb}^{\bullet}) = p_{*.orb}(\Omega^{\bullet})^{\boxtimes n} = S^{n}H^{\bullet}(M, \Omega^{\bullet}).$$

If dim M = 1 then  $\Omega_{orb}^{\bullet} = \Omega_{S^nM}^{\bullet}$  and we obtain (5.2.2).

**5.2.5.** Now let  $\mathcal{E}$  be an arbitrary line bundle on a curve C and define rank n vector bundles  $\mathcal{E}_n$  on  $S^nC$  by

$$\mathcal{E}_n = H^{\bullet}(\mathcal{O}_D \otimes \mathcal{E}).$$

This is precisely our obstruction bundle, with the substitution

$$\mathcal{E} = \mathcal{K}_C \, \mathcal{L}_4^{-1} \, \mathcal{L}_5^{-1} \, .$$

As before, we form a complex  $\Lambda^{\bullet}\mathcal{E}_n$  with zero differential and claim that

(5.2.6) 
$$\Lambda^{\bullet} \mathcal{E}_{n} = \pi_{*,\text{orb}} \left( \Lambda^{\bullet} \mathcal{E}_{1} \right)^{\boxtimes n}$$

in similarity to (5.2.4). In fact, locally on C there is no difference between  $\mathcal{E}$  and  $\mathcal{K}_C$ , so these are really the same statements. See for example [24,85] for places in the literature where a much more powerful calculus of this kind is explained and used.

By the projection formula

$$\begin{split} \mathsf{H}^{\bullet}\big(S^{\mathfrak{n}}C, \Lambda^{\bullet}\mathcal{E}_{\mathfrak{n}}\otimes \mathcal{L}_{4}^{\boxtimes \mathfrak{n}}\big) &= \mathsf{H}^{\bullet}\Big(C^{\mathfrak{n}}, \big(\Lambda^{\bullet}\mathcal{E}_{1}\big)^{\boxtimes \mathfrak{n}}\otimes \mathcal{L}_{4}^{\boxtimes \mathfrak{n}}\Big)^{S(\mathfrak{n})} \\ &= S^{\mathfrak{n}}\mathsf{H}^{\bullet}(C, O_{1}^{\bullet}) \ , \end{split}$$

as was to be shown.

### 5.3. Hilbert schemes of surfaces and threefolds

**5.3.1.** Now let Y be a nonsingular surface. In this case S<sup>n</sup>Y is singular and

$$\pi_{Hilb}: Hilb(Y, n) \rightarrow S^n Y$$

is a resolution of singularities. The sheaves  $\pi_{Hilb,*}\Omega^{\bullet}$  and  $\Omega^{\bullet}_{orb}$  on Y are not equal, but they share one important property known as *factorization*. It is a very important property, much discussed in the literature, with slightly different definitions in different contexts, see for example [9,34]. Here we will need only a very weak version of factorization, which may be described as follows.

A point in  $S^nY$  is an unordered n-tuple  $\{y_1, ..., y_n\}$  of points from Y. Imagine we partition the points  $\{y_i\}$  into groups and let  $m_k$  be the number of groups of

size k. In other words, consider the natural map

$$\prod_k S^{m_k} S^k Y \stackrel{f}{-\!\!-\!\!-\!\!-\!\!-\!\!-\!\!-\!\!-\!\!-\!\!-\!\!-\!\!\!-\!\!-\!$$

Let U be the open set of in the domain of f formed by

$$y_i \neq y_i$$

for all y<sub>i</sub> and y<sub>i</sub> which belong to different groups.

Fix a sheaf, of a K-theory class  $\mathcal{F}_n$  on each  $S^nY$ . A factorization of this family of sheaves is a collection of isomorphisms

$$(5.3.2) \mathfrak{F}_{\mathfrak{n}}|_{\mathfrak{U}} \cong \bigotimes \mathsf{S}^{\mathfrak{m}_{k}} \mathfrak{F}_{k}$$

for all U as above. Here  $S^{m_k}\mathcal{F}_k$  is the orbifold pushforward of  $(\mathcal{F}_k)^{\boxtimes m_k}$  and the isomorphisms (5.3.2) must be compatible with subdivision into smaller groups.

For example,  $\Omega^{\bullet}_{\text{orb}}$  has a factorization by construction and it is easy to see  $\pi_{\text{Hilb},*}\Omega^{\bullet}$  similarly factors.

**5.3.3.** The following lemma is a geometric version of the well-known combinatorial principle of inclusion-exclusion.

**Lemma 5.3.4.** For any scheme Y and any factorizable sequence  $\mathfrak{F}_n \in K_G(S^nY)$  there exists

(5.3.5) 
$$\mathcal{G} = z \mathcal{G}_1 + z^2 \mathcal{G}_2 + \dots \in K_G(Y)[[z]]$$

such that

$$(5.3.6) 1 + \sum_{n>0} z^n \chi(\mathcal{F}_n) = S^{\bullet} \chi(\mathcal{G}).$$

Concretely, formula (5.3.6) means that

$$\chi(\mathfrak{F}_n) = \sum_{\sum k \, m_k = n} \bigotimes S^{m_k} \chi(\mathfrak{G}_k) \,,$$

where the summations here over all solutions  $(m_1, m_2, ...)$  of the equation  $\sum k m_k = n$  or, equivalently, over all partitions

$$\mu = (...3^{m_3} 2^{m_2} 1^{m_1})$$

of the number n. For example

$$\begin{split} \chi(\mathcal{F}_2) &= \mathsf{S}^2\chi(\mathcal{G}_1) + \chi(\mathcal{G}_2)\,,\\ \chi(\mathcal{F}_3) &= \mathsf{S}^3\chi(\mathcal{G}_1) + \chi(\mathcal{G}_2)\chi(\mathcal{G}_1) + \chi(\mathcal{G}_3)\,. \end{split}$$

### 5.3.8.

*Proof of Lemma 5.3.4.* The sheaves  $g_i$  in (5.3.5) are constructed inductively, starting with

$$\mathfrak{G}_1=\mathfrak{F}_1$$
 .

and using the exact sequence (2.2.17). Consider  $X = S^2Y$  and let

$$Y \cong X' \subset X$$

be the diagonal. Factorization gives

$$\mathcal{F}_2\big|_U\cong S^2\mathcal{G}_1$$
,  $U=X\backslash X'$ ,

and so from (2.2.17) we obtain

$$\mathfrak{G}_2=\mathfrak{F}_2-\mathsf{S}^2\mathfrak{G}_1\in\mathsf{K}(\mathsf{X'})=\mathsf{K}(\mathsf{Y})$$

which solves (5.3.5) modulo  $O(z^3)$ .

Now take  $X = S^3Y$  and let  $X' = p(Y^2)$  where

$$p(y_1, y_2) = 2y_1 + y_2 \in X$$
.

Consider

$$\mathfrak{F}_3'=\mathfrak{F}_3-\mathsf{S}^3\mathfrak{G}_1\in\mathsf{K}(\mathsf{X}')$$
 ,

and denote

$$X'' = \{y_1 = y_2 = y_3\} = p(diagonal_{Y^2}) \cong Y.$$

By compatibility of factorization with respect to further refinements

$$\mathfrak{F}_3'\big|_{X'\setminus X''}=\mathfrak{p}_*(\mathfrak{G}_2\boxtimes \mathfrak{G}_1)\,.$$

Using the exact sequence (2.2.17) again, we construct

$$\mathfrak{G}_3=\mathfrak{F}_3''=\mathfrak{F}_3'-\mathfrak{p}_*(\mathfrak{G}_2\boxtimes\mathfrak{G}_1)\in K(Y)$$

which solves (5.3.5) modulo  $O(z^4)$ .

For general n, we consider closed subvarieties

$$S^nY = X_n \supset X_{n-1} \supset \cdots \supset X_1 = Y$$

where  $X_k$  is the locus of n-tuples  $\{y_1,\ldots,y_n\}$  among which at most k are distinct. In formula (5.3.7),  $X_k$  will correspond to partitions  $\mu$  with

$$\ell(\mu) = length(\mu) = \sum m_i = k.$$

We construct

$$\mathfrak{F}_n'\in \mathsf{K}(\mathsf{X}_{n-1})\,,\quad \mathfrak{F}_n''\in \mathsf{K}(\mathsf{X}_{n-2})\,,\quad \dots$$

inductively, starting with  $\mathcal{F}_n$  on  $X_n$ . For each k < n - 1, the set

$$U_{n-k} = X_{n-k} \backslash X_{n-k-1}$$

is a union of sets to which factorization applies, and this gives

$$(5.3.9) \qquad \mathcal{F}^{(k)}\Big|_{X_{n-k}\setminus X_{n-k-1}} = \sum_{\ell(\mu)=n-k} p_{\mu,*} \left( \bigotimes \mathsf{S}^{\mathfrak{m}_k} \mathcal{G}_k \right) \Big|_{X_{n-k}\setminus X_{n-k-1}}$$

where

$$p_{\mu}(y_1,y_2,\ldots,y_\ell) = \sum \mu_i\,y_i \in S^n Y.$$

We let  $\mathfrak{F}^{(k+1)}$  be the difference between two sheaves in (5.3.9), which is thus a sheaf supported on  $X_{n-k-1}$ . Once we get to  $X_1 \cong Y$ , this gives

$$\mathfrak{G}_{\mathfrak{n}} = \mathfrak{F}_{\mathfrak{n}}^{(\mathfrak{n}-1)}$$
.

**5.3.10.** Now we go back to Y being a nonsingular suface. Recall that the Hilbert scheme of points in Y is nonsingular and that Proposition 3.4.10 expresses its tangent bundle in terms of the universal ideal sheaf.

For symmetric powers of the curves in Section 5.1, the obstruction bundle was a certain twisted version of the cotangent bundle. One can similarly twist the tangent bundle of the Hilbert scheme of a surface, namely we define

(5.3.11) 
$$\mathsf{T}_{\mathsf{Hilb},\mathcal{L}} = \chi(\mathcal{L}) - \chi(\mathfrak{I}_{\mathsf{Z}},\mathfrak{I}_{\mathsf{Z}} \otimes \mathcal{L}) \,.$$

for a line bundle  $\mathcal{L}$  on Y. Let  $\Omega^{\bullet}_{Hilb,\mathcal{L}}$  be the exterior algebra of the dual vector bundle. It is clear that its pushforward to  $S^nY$  factors just like the pushforward of  $\Omega^{\bullet}_{Hilb}$  and therefore

(5.3.12) 
$$\sum_{n} z^{n} \chi(\operatorname{Hilb}(Y, n), \Omega^{\bullet}_{\mathcal{L}}) = S^{\bullet} \chi(Y, \mathcal{G})$$

for a certain  $\mathcal{G}$  as in (5.3.5). The analog of Nekrasov's formula in this case is the following

Theorem 5.3.13.

$$(5.3.14) \qquad \sum_{n} z^{n} \chi(\operatorname{Hilb}(Y, n), \Omega^{\bullet}_{\mathcal{L}}) = S^{\bullet} \chi\left(Y, \Omega^{\bullet}_{\mathcal{L}} \frac{z}{1 - z\mathcal{L}^{-1}}\right).$$

See [15] for how to place this formula in a much more general mathematical and physical context. As with Nekrasov's formula, it is in fact enough to prove (5.3.14) for a toric surface, and hence for  $Y = \mathbb{C}^2$ , in which case it becomes a corollary of the main result of [15].

Here we discuss an alternative approach, based on (5.3.12), which we format as a sequence of exercises.

**Exercise 5.3.15.** Check that for  $Y = \mathbb{C}^2$ , the LHS in (5.3.14) becomes the function

$$Z_{Hilb(\mathbb{C}^2)} = \sum_{\mathfrak{n},\mathfrak{i}\geqslant 0} z^{\mathfrak{n}} (-\mathfrak{m})^{\mathfrak{i}} \, \chi(Hilb(\mathbb{C}^2,\mathfrak{n}),\Omega^{\mathfrak{i}})$$

investigated in Exercise 3.4.25, where  $\mathcal{L}^{-1}$  is a trivial bundle with weight m.

Exercise 5.3.16. Arguing as in Section 3.5.8, prove that

$$\mathsf{Z}_{\mathsf{Hilb}(\mathsf{C}^2)} = \mathsf{S}^{\bullet} \left( \frac{(1 - \mathsf{m} \, \mathsf{t}_1^{-1})(1 - \mathsf{m} \, \mathsf{t}_2^{-1})}{(1 - \mathsf{t}_1^{-1})(1 - \mathsf{t}_2^{-1})} \right)$$

for a certain series

$$\Leftrightarrow \mathbb{Z}[\mathfrak{m}][[z]].$$

Exercise 5.3.17. Arguing as in Section 3.5.12, prove that

$$\Rightarrow = \frac{z}{1 - mz} .$$

What is the best limit to consider for the parameters  $t_1$  and  $t_2$ ?

**5.3.18.** Now let X be a nonsingular threefold and let

$$\pi: Hilb(X, n) \to S^n$$

be the Hilbert-Chow map. To complete the proof of Nekrasov's formula given in Section 3.5, we need to show (3.5.3), which follows from the following

**Proposition 5.3.19.** *The sequence* 

$$\mathcal{F}_n = \pi_* \, \widehat{\mathcal{O}}^{vir} \in \mathsf{K}(\mathsf{S}^n \mathsf{X})$$

factors.

There is, clearly, something to check here, because, for example, this sequence would not factor without the minus sign in (3.3.2).

*Proof.* Recall from Section 3 that

$$\widehat{\mathbb{O}}^{vir} = \dots \xrightarrow{d} \kappa^{-\frac{dim}{2} + i} \, \Omega^i_{\widetilde{\mathbb{M}}} \xrightarrow{d} \kappa^{-\frac{dim}{2} + i + 1} \Omega^{i+1}_{\widetilde{\mathbb{M}}} \xrightarrow{d}$$

where i is also the cohomological dimension and

$$d\omega = \kappa d\phi \wedge \omega$$
.

Here

$$\phi(X) = \text{tr}(X_1X_2X_3 - X_1X_3X_2)$$

is the function whose critical locus in  $\widetilde{\mathbb{M}}$  is the Hilbert scheme.

Let U be the locus where the spectrum of  $X_1$  can be decomposed into two mutually disjoint blocks of sizes  $\mathfrak{n}'$  and  $\mathfrak{n}''$ , respectively. This means  $X_1$  can be put it in the form

$$\mathsf{X}_1 = \begin{pmatrix} \mathsf{X}_1' & 0 \\ 0 & \mathsf{X}_1'' \end{pmatrix}$$

up-to conjugation by  $GL(n') \times GL(n'')$  or  $S(2) \ltimes GL(n')^2$  if n' = n''. Thus block off-diagonal elements of  $X_1$  and of the gauge group are eliminated simultaneously.

If  $\lambda_i'$  and  $\lambda_j''$  are the eigenvalues of  $X_1'$  and  $X_1''$  respectively, then as a function of the off-diagonal elements of  $X_2$  and  $X_3$  the function  $\varphi$  can be brought to the form

$$\varphi = \sum_{i,j} (\lambda_i' - \lambda_j'') \, X_{2,ij} X_{3,j\,i} + \ldots \, , \label{eq:phi_spectrum}$$

and thus has many Morse terms of the form

$$\phi_2(u,v) = uv$$

where the weights of u and v multiply to  $\kappa^{-1}$ . For the Morse critical point on  $\mathbb{C}^2$ , the complex

$$\kappa^{-1} 0 \xrightarrow{\kappa d\varphi_2 \wedge} \Omega^1 \xrightarrow{\kappa d\varphi_2 \wedge} \kappa \Omega^2$$

is exact, except at the last term, where its cohomology is  $\mathfrak{O}_{\mathfrak{u}=\nu=0}$ . This is also true if we replace  $\mathbb{C}^2$  by a vector bundle over some base because the existence of a Morse function forces the determinant of this bundle to be trivial, up to a twist by  $\kappa$ .

Therefore, all off-diagonal matrix elements of  $X_2$  and  $X_3$  are eliminated and  $\widehat{\mathbb{O}}^{\mathrm{vir}}$ , restricted to U, is, up to an even shift, the tensor product of the corresponding complexes for  $\mathrm{Hilb}(X, \mathfrak{n}')$  and  $\mathrm{Hilb}(X, \mathfrak{n}'')$ .

## 6. More on quasimaps

## 6.1. Balanced classes and square roots

**6.1.1.** Let  $\mathcal{K}_C$  be the canonical bundle of the domain C. For our specific domain  $C \cong \mathbb{P}^1$ , we have, equivariantly,

$$\mathcal{K}_{C} - \mathcal{O}_{C} = -\mathcal{O}_{p_1} - \mathcal{O}_{p_2}$$

where  $p_1, p_2 \in C$  are the fixed points of a torus in Aut(C). It is customary to choose  $\{p_1, p_2\} = \{0, \infty\}$ .

**6.1.2.** The choice of a Lagrangian subspace M, namely (4.2.2), inside the symplectic representation  $T^*M$  of G determines a *polarization* 

(6.1.3) 
$$T^{1/2}X = M - \sum_{i} End(V_i)$$

which, by definition, is an equivariant K-theory class such that

$$TX = T^{1/2}X + \hbar^{-1} \left(T^{1/2}X\right)^{\vee}$$

in K(X). The chosen polarization induces a virtual bundle

$$\mathfrak{I}^{1/2} = \mathfrak{M} - \sum_{i} \mathfrak{Hom}(\mathcal{V}_{i}, \mathcal{V}_{i})$$

over  $C \times QM(X)$ .

Lemma 6.1.4. We have

(6.1.5) 
$$T_{\text{vir}} = \sum_{i=1}^{2} \mathfrak{I}^{1/2} |_{p_i} + H - \hbar^{-1} H^{\vee},$$

where  $H = H^{\bullet}(\mathfrak{I}^{1/2} \otimes \mathfrak{K}_{\mathbb{C}})$ , equivariantly with respect all automorphisms of  $\mathbb{C}$  and  $\mathbb{X}$  that preserve  $\mathfrak{p}_1$ ,  $\mathfrak{p}_2$ , and the symplectic form.

Proof. Serre duality gives

$$H^{\bullet}(\mathcal{M} \otimes \mathcal{K}_{C})^{*} = -H^{\bullet}(\mathcal{M}^{*}),$$

whence the conclusion.

Naturally, a formula similar to (6.1.5) exists for an arbitrary curve C with the canonical divisor replacing  $-p_1 - p_2$ .

### 6.1.6.

**Definition 6.1.7.** We say that a K-theory class  $\mathcal{F}$  is *balanced* if

$$\mathfrak{F}=\mathfrak{G}-\hbar^{-1}\mathfrak{G}^{\vee}$$

for some K-theory class 9.

Lemma 6.1.4 may be rephrased to say that  $T_{\rm vir}$  equals the polarization at the marked points modulo balanced classes.

**6.1.8.** Lemma 6.1.4 implies

$$\frac{\det \mathsf{T}_{vir}}{\det \mathfrak{I}^{1/2}\big|_{p_1} \det \mathfrak{I}^{1/2}\big|_{p_2}} = \hbar^{rk\,\mathsf{H}} (\det \mathsf{H}^{\bullet}(\mathfrak{I}^{1/2} \otimes \mathfrak{K}_C))^2 \, ,$$

which is a square if we replace  $C_h^{\times}$  by its double cover. We define

$$\widehat{\mathcal{O}}_{vir} = \mathcal{O}_{vir} \otimes \left( \mathcal{K}_{vir} \frac{\det \mathfrak{I}^{1/2} \big|_{p_2}}{\det \mathfrak{I}^{1/2} \big|_{p_1}} \right)^{1/2}.$$

where  $\mathfrak{K}_{vir} = det^{-1} \mathsf{T}_{vir}$ .

**6.1.10.** From 3.4.40, recall the function

$$\widehat{\mathsf{a}}(x) = \frac{1}{x^{1/2} - x^{-1/2}} \, \text{,}$$

which we extended to  $\mathcal{G} \in K(X)$  by the rule

$$\widehat{\mathsf{a}}(\mathfrak{G}) = \prod_{\text{Chern roots } x_\mathfrak{i} \text{ of } \mathfrak{G}} \widehat{\mathsf{a}}(x_\mathfrak{i})$$
 ,

assuming a square root of det  $\mathfrak{G}$  exists and has been fixed. As we already saw e.g. in (3.4.43), the contribution of  $\widehat{\mathfrak{O}}_{vir}$  to localization formulas is, up to small details,  $\widehat{\mathfrak{a}}(T_{vir})$ .

The key technical point about Lemma 6.1.4 is that for any balanced K-theory class we have

$$\widehat{\mathsf{a}}\left(\mathsf{H}-\mathsf{\hbar}^{-1}\mathsf{H}^{\vee}\right) = (-\mathsf{\hbar}^{-1/2})^{\mathsf{rk}\,\mathsf{H}} \prod_{x_{\mathfrak{i}}} \frac{1-\mathsf{\hbar}x_{\mathfrak{i}}}{1-x_{\mathfrak{i}}}\,,$$

where  $x_i$  are the Chern roots of H. This rational function remains *bounded* as  $x_i^{\pm} \to \infty$ , which will be the essential step of several rigidity arguments below.

**6.1.11.** This technical point is the reason we work with  $\widehat{\mathbb{O}}_{vir}$  and not  $\mathbb{O}_{vir}$ . It is also the reason we work with quasimaps and not with other moduli spaces of rational curves in X.

For  $\mathcal{O}_{vir}$ , without the square root of the virtual canonical, the rigidity arguments used e.g. in the proof of Nekrasov's formula breaks down, and it is a

challenge to derive a reasonable formula for the series (3.5.4). In fact, even the analog of Exercise 5.1.22 for  $\mathcal{O}_{vir}$  in place of  $\widehat{\mathcal{O}}_{vir}$  appears problematic.

**6.1.12.** In particular, it is important in Lemma 6.1.4 that the duality holds not just with respect to the automorphisms of the target X of the quasimaps, but also with respect to the automorphisms of the domain C that preserve the two marked points. This is because later, when we talk about relative quasimaps, we will need to take quotients with respect to  $Aut(C, p_1, p_2)$ . For duality to descend to the quotient, it needs to hold  $Aut(C, p_1, p_2)$ -equivariantly for ordinary quasimaps.

**6.1.13.** Now suppose that instead of quasimaps to a Nakajima variety X we take the moduli space  $\overline{M}_{0,2}(X)$  of stable maps

$$f: C \to X$$

where C is a 2-pointed rational curve. The essential component of its deformation theory is again  $H^{\bullet}(C, f^*TX)$  and following the argument of Lemma 6.1.4 we can write

$$H^{\bullet}(C, f^*TX) = \text{like in } (6.1.5) + \Delta$$

where

$$\Delta = H^{\bullet}(C, f^{*}\mathfrak{I}^{1/2} \otimes (\mathfrak{O}(-\mathfrak{p}_{1} - \mathfrak{p}_{2}) - \mathfrak{K}_{C})).$$

This discrepancy class  $\Delta$  is nontrivial K-theory class on  $\overline{M}_{0,2}(X)$  supported on the divisor D where  $\mathcal{K}_C \ncong \mathcal{O}(-\mathfrak{p}_1 - \mathfrak{p}_2)$ . This divisor is formed by curves of the form

$$C = C' \cup C''$$

where C' is the minimal chain of rational curves containing  $p_1$  and  $p_2$  and  $C'' \neq \emptyset$ . For example, we have the following

**Lemma 6.1.14.** The multiplicity of det  $\Delta$  along a component of D equals minus the degree of the polarization  $\mathfrak{T}^{1/2}$  on the component  $\mathfrak{C}''$ .

*Proof.* We may compute this multiplicity on the stack of 2-pointed rational curves with a vector bundle V. The vector bundle V will generalize the pull-back of polarization  $\mathfrak{T}^{1/2}$  to C.

To write a curve in this stack that intersects D transversally, we take a trivial family  $C \times B$  with base B and blow up a point in the fiber  $C \times \{b\}$  away from  $p_1$  and  $p_2$ , see Figure 6.1.15. We denote by

$$\pi: \mathbf{C} \to \mathbf{B}$$

the corresponding family of 2-pointed rational curves. The dualizing sheaves of the fibers are obtained by restricting

$$\mathfrak{K}_{\boldsymbol{C}} \otimes \pi^* \mathfrak{K}_B^{-1} \cong \mathfrak{O}_{\boldsymbol{C}} (-\mathfrak{p}_1 - \mathfrak{p}_2 + \boldsymbol{C}'')$$

to the fibers, where  $p_i$  denote the sections of  $\pi$  given by marked points and  $C'' \subset C$  is the exceptional divisor. We have

$$\mathfrak{O}_{\boldsymbol{C}}(-\mathfrak{p}_1-\mathfrak{p}_2)-\mathfrak{O}_{\boldsymbol{C}}(-\mathfrak{p}_1-\mathfrak{p}_2+\boldsymbol{C''})=-\mathfrak{O}_{\boldsymbol{C''}}(-1)$$

![](_page_67_Picture_2.jpeg)

FIGURE 6.1.15. A curve C sprouts off a tail C".

and

$$\pi_* (V \otimes \mathcal{O}_{C''}(-1)) = (\deg V|_{C''}) \cdot \mathcal{O}_b$$

by Riemann-Roch. This equals the degree of the bundle  $\det \pi_* (V \otimes \mathcal{O}_{C''}(-1))$  on B, and hence minus the multiplicity of the corresponding component.

**Exercise 6.1.16.** What will happen in the above computation if we blow up one the points  $p_1$  or  $p_2$ ?

While det  $\mathfrak{T}^{1/2}$  may be a square in  $\operatorname{Pic}(X)$  which will make det  $\Delta$  also a square by Lemma 6.1.14, there is nothing selfdual about the class  $\Delta$  which would allow the rigidity arguments to go through. A further modification of the enumerative problem is required for that.

## 6.2. Relative quasimaps in an example

**6.2.1.** The evaluation at  $p \in C$  in (4.3.7) is a rational map

$$ev_p : QM \longrightarrow X$$

defined on the open set  $QM_{nonsing\ p}$  of quasimaps nonsingular at p. Moduli spaces of relative quasimaps is a resolution of this map, that is, they fit into a diagram

(6.2.2) 
$$QM_{\text{relative } p}$$

$$QM_{\text{nonsing } p} \xrightarrow{ev} X$$

with a *proper* evaluation map to X. Their construction follows an established path in Gromov-Witten theory [51,52] and, later, DT theory [53].

**6.2.3.** The basic idea behind relative quasimaps may be explained in the most basic example of quasimaps to

$$X = \mathbb{C}/\mathbb{C}^{\times}$$
.

From definitions

$$QM(C \to \mathbb{C}/\mathbb{C}^{\times}) = \{(\mathcal{L}, s)\},\$$

where L is a line bundle on C and

$$s: \mathcal{O}_C \to \mathcal{L}$$

is a section which is not identically zero. This gives

$$\mathcal{L} = \mathcal{O}(\mathsf{D})$$

where D " psq P S <sup>d</sup><sup>C</sup> is the divisor of <sup>s</sup> and <sup>d</sup> " deg <sup>L</sup>. Thus

$$\mathsf{QM}(\mathsf{C} \to \mathbb{C}/\mathbb{C}^{\times}) = \bigsqcup_{d \geqslant 0} \mathsf{S}^{d} \mathsf{C} \,.$$

**6.2.4.** The set QMnonsing <sup>p</sup> is formed by divisors D disjoint from p P C. Relative quasimaps compactify this set by allowing the curve C to break when the support of D approaches p. In the language of algebraic geometry this means the following.

Let D<sup>t</sup> be a flat 1-parameter family of divisors parametrized by t P B – **C**, such that

$$p\in D_0\,,\quad p\notin D_t,\quad \text{for $t$ generic}\,.$$

We may assume that p " 0 P C – **C**, in which case

$$D_t = \{f(x, t) = 0\}$$

with

(6.2.5) 
$$f(0,0) = 0, \quad f(0,t) \neq 0, \quad f(x,0) \neq 0.$$

We will now replace the surface **C** " B ˆ C by a blow-up

$$\mathbf{C}^{\diamond} \to \mathbf{C}$$

such that the proper transform of D<sup>t</sup> is disjoint from the proper transform of tx " 0u and from the nodes of the exceptional divisor.

**6.2.6.** Let

$$f = \sum_{n,m} f_{n,m} x^n t^m$$

be the (finite) Taylor expansion of f at px, tq " 0. Consider the Newton diagram

Newton(f) = Conv (
$$\{(n, m), f_{n,m} \neq 0\} \cup \{(\infty, 0), (0, \infty)\}$$
)

of the polynomial f, see Figure 6.2.7. Let I be the monomial ideal

$$I = (x^{\alpha}t^{b})_{(\alpha,b) \in Newton(f)}$$

,

which by (6.2.5) is nontrivial zero-dimensional ideal. As **C** ˛ , we take the blowup

$$\mathbf{C}^{\diamond} = \operatorname{Bl}_{\mathrm{I}} \mathbf{C}$$

of **C** in the ideal I, that is, the closure of the graph of the map

$$\mathbf{C} \dashrightarrow \mathbb{P}^{\# \text{ of generators}-1}$$

![](_page_69_Picture_2.jpeg)

FIGURE 6.2.7. The Newton diagram of a polynomial of the form  $x^5 + \star tx^2 + \star t^2x + \star t^4 + \ldots$ , where dots stand for monomials in the shaded area and stars for nonzero numbers. The bounded edges have (minus) slopes  $\{\frac{1}{2},1,3\}$ .

given by the generators of I. This is a toric surface whose toric diagram is the Newton diagram. The bounded edges in this diagram correspond to components of the exceptional divisor.

**6.2.8.** It is easy to see that, by construction, that the proper transform of  $D_t$  in  $C^{\diamond}$  satisfies the following properties:

- it is disjoint from the proper transform of  $\{x = 0\}$ ,
- it intersects every component of the exceptional divisor,
- it is disjoint from the nodes of the exceptional divisor.

### **Exercise 6.2.9.** Check this.

The only shortcoming of  $\mathbb{C}^{\diamond}$  is that fiber  $\mathbb{C}^{\diamond}$  over 0 of the induced map

![](_page_69_Picture_11.jpeg)

may have multiple components and hence cannot serve as a degeneration of C. Indeed, we have the following

**Exercise 6.2.10.** If  $I = (x^a, t^b)$  then the multiplicity of the exceptional divisor in  $C^{\diamond}$  is  $\alpha/\gcd(a,b)$ . More generally, if an compact edge in Figure 6.2.7 has slope  $\alpha/b$  with  $\gcd(a,b)=1$  then the corresponding component of the exceptional divisor has multiplicity  $\alpha$  in  $C^{\diamond}$ .

This is remedied by a passing to a degree m branched cover, also known as base change,

$$C' \longrightarrow C^{\diamond}$$

$$\downarrow \qquad \qquad \downarrow$$

$$B' \longrightarrow B$$

where  $t = (t')^m$  and

$$m = lcm \, \left\{ \frac{\alpha_i}{gcd(\alpha_i,b_i)} \right\}_{slopes \, \frac{\alpha_i}{b_i}}.$$

The central fiber C' in the resulting family

$$C' \longrightarrow C'$$

$$\downarrow \qquad \qquad \downarrow$$

$$0 \longrightarrow B'$$

is the curve C with a chain of rational curves (the exceptional divisor) attached, all with multiplicity one.

**6.2.11.** We denote by  $p' \in C'$  the intersection of C' with the proper transform of  $\{x=0\}$  and by  $D'_0$  the intersection of C' with the proper transform of  $D_t$ .

**Exercise 6.2.12.** Show  $D'_0$  is disjoint from p' and the nodes of C'. What is the degree of this divisor on each component of C'?

**6.2.13.** In simple English, the blowup  $C^{\diamond}$  and its branched cover C' serve the following purpose.

One can write the solutions  $x_i(t)$  of the equation f(x, t) = 0 as Puiseux series

(6.2.14) 
$$x_{i}(t) = c_{i}t^{r_{i}} + o(t^{r_{i}}), \quad r_{i} = \frac{b_{i}}{a_{i}}, \quad c_{i} \neq 0,$$

where  $i=1,\ldots, deg_x$  f. We can assume them ordered in the decreasing order of the rates  $r_i$  at which they approach 0 as  $t\to 0$ .

These rates are the reciprocals of the slopes in Figure 6.2.7 and the solutions  $x_i(t)$  that go to zero at the same rate will end up on the same component of the exceptional divisor, see Figure 6.2.15. Suppose, for example, that

$$r_1=r_2=r_3>r_4\geqslant \cdots \geqslant 0$$

Then the component  $C'_{p'}$  of C' that contains p' will contain 3 points of  $D'_{0}$ , with coordinates  $c_1, c_2, c_3$ , up to proportionality. The up-to-proportionality business appears here because there is no canonical identification  $C'_{p'} \cong \mathbb{P}$  as the only distinguished points of this component are p' and the node of C'.

Put it in a different way, the rescaling

![](_page_71_Figure_2.jpeg)

Figure 6.2.15. Logarithmic plot of  $|x_i(t)|$  for a polynomial from Figure 6.2.7 as  $(x,t) \rightarrow (0,0)$ . The slopes in this figure are dual, or perpendicular, to the slopes in Figure 6.2.7

acts on the leading coefficients in (6.2.14) by

$$(c_1, c_2, c_3) \mapsto \lambda^{-r_1}(c_1, c_2, c_3),$$

and so acts nontrivially even on the central fiber.

**6.2.16.** This is an important point, and so worth repeating one more time. In the central fiber, we have

- a chain of rational curves C', one end of which is identified with C while the other contains the point p',
- a divisor disjoint from p' and the nodes of C', and such that its degree on any components other than C is positive,
- this data is considered up to isomorphism which must be identity on C.

A pointed nodal curve C' is called stable if it automorphism group is finite. If the automorphism group is reductive, the curve is called *semistable*. Semistability means some components of C' contain only 2 special (that is, marked or nodal) points and the sequence

$$1 \to \left(\mathbb{C}^\times\right)^{\# \ \text{such components}} \to Aut(C') \to \text{finite group} \to 1$$

is exact.

We extend this terminology to cover cases when one or more components of C' are considered as rigid, equivalently, parametrized. In our example, the component  $C \subset C'$  is rigid. This may be reduced to the usual case by adding enough marked points to rigid components.

There is a stabilization map which collapses nonrigid components with only 2 special points. In the case at hand, (C,p) is the stabilization of (C',p').

**6.2.17.** Instead of constructing  $C^{\diamond}$  and then C' all at once, we could have constructed them in stages as follows. Let  $r_1$  be the maximal rate at which  $x_i(t) \to 0$ , which means that  $1/r_1$  is the minimal slope in Figure 6.2.7. Write  $r_1 = b_1/a_1$ ,  $gcd(a_1,b_1)=1$ , blow up the ideal  $(x^{a_1},t^{b_1})$ , and pass to a branched cover of degree  $a_1$ . This takes care of the points that were approaching p the fastest. Now they all land on the component of C' that contains p', while all other points of  $D_t$  approach some point of C as  $t\to 0$ , including the node of the central fiber.

Obviously, we can deal with points approaching the node inductively, by looking at those that approach the fastest, doing the corresponding blowup, etc.

**6.2.18.** Looking at the list in Section 6.2.16, one can make the following important observation. The data of the divisor in central fiber is taken modulo the action of

$$\operatorname{Aut}(C', \{C, p\}) = (\mathbb{C}^{\times})^{\# \text{ of bubbles}}$$

where bubbles refer to components of C' other than C. The action of this group on divisor can and will have finite stabilizers, so moduli space of objects in Section 6.2.16 is an orbifold.

In fact, the need to go to branched covers precisely correlates with these orbifold singularities.

**Exercise 6.2.19.** Let a/b with gcd(a,b) = 1 be the slope of one of the edges in Figure 6.2.7. Show that the restriction of  $D_0'$  to the corresponding component of C' is invariant under the group

$$\mu_\alpha = \{\zeta \, \big| \, \zeta^\alpha = 1\} \subset \mathbb{C}^\times \, .$$

Conversely, if a divisor  $D_0'$  has a nontrivial group of automorphisms, then there exists a family a 1-parameter family  $D_t$  producing it for which base change is necessary.

### 6.3. Stable reduction for relative quasimaps

**6.3.1.** We now generalize the discussion of Section 6.2 to quasimaps to a Nakajima variety X. A stable quasimap

$$f: C \longrightarrow X$$

relative  $p \in C$  is defined as a diagram

$$\begin{array}{cccc}
p' &\longmapsto C' & - & -\frac{f'}{-} & - & > X \\
\downarrow & & \downarrow & \pi \\
p &\longmapsto C
\end{array}$$

in which

- $\pi$  is the stabilization of a semistable curve (C', p'),
- f' is nonsingular at p and the nodes of C',
- the automorphism group of f' is finite.

Figure 6.3.3 is a pictorial representation of this data. Note that nonsingularity at

![](_page_73_Picture_3.jpeg)

Figure 6.3.3. A quasimap relative a point  $p \in C$  is a quasimap from a semistable curve C' whose stabilization collapses a chain of rational curves to p.

p and the nodes implies f' takes the generic point of each component of C' to X. Two quasimaps are isomorphic, if they fit into a diagram of the form

![](_page_73_Picture_6.jpeg)

where  $\phi$  is an isomorphism which preserves the marked point. Since

Aut(C',
$$\pi$$
, $p$ ) =  $(\mathbb{C}^{\times})^{\# \text{ of new components}}$ 

a quasimap has a finite group of automorphism if and only if each component of C' is either mapped nonconstantly to X or has at least one singular point.

**6.3.4.** A quasimap to X may be composed pointwise with the projection to the affine quotient

$$X_0 = \mu^{-1}(0)/G = Spec\left(G\text{-invariants}\right)$$
 ,

which has to be constant since  $X_0$  is affine. This gives a map  $QM(X) \to X_0$ , and similarly for relative quasimaps.

By a general result of [20], the moduli space of both ordinary and relative quasimaps is proper over  $X_0$ . Our goal in this section is to get a feeling for how this works and, in particular, to explain the logic behind the definition of a relative quasimap.

**6.3.5.** The key issue here is that of completeness, which means that we should be able to fill in central fibers for maps

$$g: B^{\times} \to QM(X)_{\text{relative } p}$$

where  $B^{\times} = B \setminus \{0\}$  and B is a smooth affine curve with a point 0, under the assumption that the corresponding map to  $X_0$  extends to B.

**6.3.6.** By definition, a map

$$g:B^{\times}\to \mathsf{QM}(f:C\to X)$$

is given by the bundles tg ˚Vi<sup>u</sup> and the section <sup>f</sup> ˝ <sup>g</sup> defined on

$$\mathbf{C}^{\times} = \mathbf{C} \times \mathbf{B}^{\times}.$$

The first step to find *some* extension of the bundles and the section to **C**. This preliminary extension will satisfy stability on the central fiber, but may fail nonsingularity at p.

For simplicity, assume that C is irreducible (otherwise, consider each component of C separately and use nonsingularity of quasimaps at the nodes). The map g yields a rational map in the following diagram

![](_page_74_Picture_8.jpeg)

Since X is projective over X0, the locus of indeterminacy of grational has codimension ě 2, which means it consists of finitely many points. After shrinking the curve B, we may assume all points of indeterminacy lie in the central fiber. This extends the bundles and the section to the generic point of the central fiber.

On a smooth surface **C**, one can extend a vector bundle from a complement U of a finite set of points by just pushing forward the sheaf of sections under U Ñ **C** (e.g. because such push-forward is reflexive and thus has to be locally free). This procedure automatically extends sections of any associated vector bundle. One usually talks about Hartogs-type theorems when discussing such extensions.

In summary, we have extended the quasimap to the central fiber, except it may be singular at p.

**6.3.7.** One may consider quasimaps to general quotients of the form

$$X = W/\!\!/G$$

and for properness [20] need to assume that W is affine and G is reductive. Both assumptions are essential for the ability to extend a G-bundle and the section of the associated W-bundle to **C**.

Indeed, suppose W is not affine. Then it may not be possible to extend a map to W in codimension 2, as examples W " **C** 2 zt0u or W " **P** 1 clearly show. The geometric reason the extension will fail for any W that contains a rational curve is that rational curves in W, parametrized or not, will break in families like the curves in Figures 6.1.15 or 6.4.3. Indeed, take a parametrized curve, precompose with an automorphism, and send the automorphism to infinity. Or, take a double cover of a rational curve and make the branch points collide, etc. Special fibers of the corresponding map **C** Ñ W are thus forced to be reducible.

On the other hand, suppose G is not reductive. After choosing a faithful linear representation, a G-bundle may be seen as rank n vector bundle together with its reduction to  $G \subset GL(n)$ . Such reduction is a section of the associated GL(n)/G-bundle and by Matsushima and Onishchik

G is reductive 
$$\Leftrightarrow$$
 GL(n)/G is affine,

see e.g. Section 4.7 in [84]. And so if G were not reductive, there would be G bundles that cannot be extended in codimension 2.

Stable reduction for moduli spaces  $\overline{M}_{0,n}(X)$  of stable pointed maps deals with these issues by doing enough blowups, in the course of which the central fiber may become an arbitrary tree of rational curves. As explained in Section 6.1.13, having an arbitrary tree of rational curves is precisely what we are trying to avoid. We need to keep the central fiber a chain of rational curves.

**6.3.8.** Also note that for a normal but singular surface S there may be no way to extend a vector bundle on nonsingular locus to a vector bundle on all of S.

For instance, the singularities of the surface from Figure 6.2.7 are the 2-dimensional *toric* singularities, which may be described as follows

$$\begin{array}{ll} \text{(6.3.9)} & S = Spec\,\mathbb{C}\,\text{C}\,\,, \quad C = cone \text{ in }\Lambda \cong \mathbb{Z}^2\,,\\ & = \mathbb{C}^2/\text{finite abelian subgroup }\Gamma \subset \text{GL}(2)\,,\\ & = \mathbb{C}^2/\operatorname{diag}(\zeta,\zeta^\alpha)\,, \quad \zeta^n = 1, \gcd(n,\alpha) = 1\,, \end{array}$$

where  $\mathbb{C}C$  in (6.3.9) denotes the semigroup algebra of a cone  $\mathbb{C}$  and (6.3.10) is the explicit description of  $\Gamma/\Gamma'$  where  $\Gamma' \subset \Gamma$  is the subgroup generated by complex reflections, i.e. elements with codimension 1 fixed loci. The invariant ring in (6.3.10) is of the form  $\mathbb{C}C$  where

(6.3.11) 
$$\Lambda = \langle (\mathfrak{n}, 0), (-\mathfrak{a}, 1) \rangle \subset \mathbb{Z}^2, \quad C = \Lambda \cap \mathbb{Z}^2_{\geq 0}$$

and any cone in a rank 2 lattice can be written like that.

**Exercise 6.3.12.** Check the claim about the singularities and find Weil divisors on these surfaces which are not Cartier divisors, that is, cannot be defined by one equation near the singularity. Conclude that there are line bundles on the nonsingular locus such that their pushforward to all of S is not locally free.

Another way to state the content of the above exercise is the following. Any bundle on  $\mathbb{C}^2\setminus\{0\}$  is trivial as the restriction of its extension to  $\mathbb{C}^2$ . For the singularity (6.3.10), we have

$$S\backslash\{0\} = \left(\mathbb{C}^2\backslash\{0\}\right)\big/\mu_n \text{ , } \quad \mu_n = \left\{diag(\zeta,\zeta^\alpha)\right\}.$$

Therefore, a vector bundle on  $S\setminus\{0\}$  may be seen as a representation of  $\mu_n$ , and it extends to a vector bundle on the singular surface if and only if this representation is trivial.

**6.3.13.** After these remarks, we return to our task of making the quasimap in the central fiber nonsingular at the marked point p by pulling it back under a well-chosen map

$$\mathbf{C}_1 \to \mathbf{C}$$
,

which will be a combination of a (weighted) blowup, that is, the blowup of an ideal of the form

$$I = (x^a, t^b), \quad \gcd(a, b) = 1,$$

and a degree a branched cover  $t = (t')^a$ , as in Section 6.2. The central fiber

$$C_1 = E_1 \cup_{p_1} C$$

is the union of the exceptional divisor and the component isomorphic to C. We denote by  $p_1$  the node of the central fiber. The marked point  $p \in C_1$  lies on  $E_1$ , it is the intersection of  $E_1$  with the proper transform of  $\{x = 0\}$ , see Figure 6.3.14.

![](_page_76_Picture_9.jpeg)

FIGURE 6.3.14. A weighted blowup at slope 3/2 followed by a base change: we blow up of the ideal  $I = (x^3, t^2)$  and set  $t = (t')^3$ .

Since the vertical map in

![](_page_76_Picture_12.jpeg)

is projective, the rational map  $g_{1,rational}$  is defined at the generic point of  $E_1$ . In English, the restriction  $g_{1,rational}$  to  $E_1$  is obtained by taking the lowest degree terms with respect to the grading defined by

$$\deg t' = 1$$
,  $\deg x = b$ .

These lowest degree terms are then a function of the coordinate  $x/(t')^b$  on  $E_1$ . If the slope  $\mathfrak{a}/\mathfrak{b}$  is too small, then the map

$$(6.3.15) E_1 \longrightarrow X$$

is a constant map which contracts  $E_1$  to  $\lim_{t\to 0} g(0,t)$ . (Why does this limit exist?) Moreover, this map is nonsingular away from the node  $p_1$ . We choose s to be

the minimal slope for which this doesn't happen, that is, the map (6.3.15) is either nonconstant or singular at some point of E1ztp1u. It can be seen that

- a minimal slope exists,
- the minimality of the slope implies g<sup>1</sup> is nonsingular at p.

Indeed, if g<sup>1</sup> were singular at p, we could get something nontrivial with a further blowup, which would then have a smaller slope, etc.

Picking a minimal slope means focusing on singularities that approach the marked point the fastest as t Ñ 0, like in Section 6.2.13.

**6.3.16.** With the singularities of g<sup>1</sup> at E1ztp1u we deal as in Section 6.3.6 to get a quasimap defined on all of E1ztp1u.

What remains is the singularity at p<sup>1</sup> . We deal with it inductively, by blowing up this point at the smallest nontrivial slope, and so on. As the degree of the map is consumed at each step, the process will terminate in finitely many steps.

The inductive step in this process is the data of a quasimap on **C**nztpnu, where p<sup>n</sup> is the nth node of the central fiber. The point p<sup>n</sup> is a singularity of **C**<sup>n</sup> and, in light of the discussion in Section 6.3.8, we don't attempt to extend the bundles V<sup>i</sup> to pn. Eventually, the quasimap will be nonsingular at all nodes and the bundles V<sup>i</sup> will be extended by pull-back from X.

- **6.3.17.** Note that unnecessary blowups, like blowing up at too small a slope, or blowing up a node which is already nonsingular, precisely produce quasimaps which are constant and nonsingular along one of the components. Such quasimaps have continuous automorphims and so violate the definition of a stable relative quasimap from Section 6.3.1
- **6.3.18.** It is also clear that stable reduction, in the form described above, involves no arbitrary choices and its final result is forced on us by the geometry of the quasimap in a punctured neighborhood of px, tq " p0, 0q. This can be easily formalized to show that the moduli space of stable relative quasimaps is separated, which means that the limits in 1-parameter families are unique.

The existence and uniqueness of limits in 1-parameter families is equivalent, by what is known as the valuative criterion of properness, to QMpXqrelative <sup>p</sup> being proper over X0. To make this stament precise, we need an actual moduli space for quasimaps, and this is where we turn our attention now.

### **6.4. Moduli of relative quasimaps**

**6.4.1.** The construction of the moduli space of stable relative quasimaps may be done, in some sense, by doing stable reduction in reverse, starting with a universal deformation of the curve C 1 .

The local model for a deformation of a node is

$$(6.4.2) xy = \varepsilon$$

where the precise flavor of the deformation problem depends on how much we rigidify the two coordinate axes. If we rigidify them both completely by adding 2 marked points to each like in Figure 6.4.3, then

$$\epsilon \propto crossratio(x_1,x_2;\frac{\epsilon}{y_1},\frac{\epsilon}{y_2}) - 1 \,, \quad \epsilon \to 0 \,,$$

is the local coordinate on the moduli space M0,4.

![](_page_78_Figure_5.jpeg)

Figure 6.4.3. Degeneration of a 4-pointed curve to a stable nodal curve.

If we remove one marked point on one of the axes, then the nodal curve gets a **C** <sup>ˆ</sup> worth of automorphisms, while all <sup>ε</sup> ‰ 0 curves are become isomorphic. We thus get a moduli stack of the form **C**{**C** <sup>ˆ</sup>, where ε is the coordinate on **C**. We will indicate this by **C**<sup>ε</sup> to keep track of the name of the coordinate.

The domain C <sup>1</sup> of a quasimap relative one point p may be exactly this sort of curve, with one rigid component, and the other component with a marked point and **C** <sup>ˆ</sup> acting by automorphims. A more uniform way to write its universal deformation is to take the trivial family C ˆ **C**<sup>ε</sup> and blow up the point p in the central fiber.

**6.4.4.** The universal deformation of the domain C <sup>1</sup> of a general relative quasimap may be written analogously. For concreteness, assume C <sup>1</sup> has two nodes. Consider

$$\widetilde{\textbf{C}} = \text{Bl}_{\substack{\text{strict transform} \\ \text{of } \{\epsilon_2 = 0\} \times \{p\}}} \text{Bl}_{\{\epsilon_1 = 0\} \times \{p\}} \, \mathbb{C}^2_{\epsilon_1, \epsilon_2} \times \textbf{C}$$

The toric picture of this 3-fold may be seen in Figure 6.4.5. An informal, but accurate way to describe this geometry is to compare with an accordion, in which various sections of the bellows open over the divisors tε<sup>i</sup> " 0u.

The fibers of the map ε in the diagram

(6.4.6) 
$$C' \xrightarrow{\sim} \widetilde{C} \xrightarrow{\pi} C$$

$$\downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow \qquad$$

![](_page_79_Picture_2.jpeg)

Figure 6.4.5. Universal deformation of a curve with two bubbles. The ith node remains intact over  $\varepsilon_i = 0$ .

are deformations of the central fiber C' and the group  $(\mathbb{C}^{\times})^2$  acts on the base and on the fibers by isomorphisms. This exhibits the stack of deformations of C' as

$$\operatorname{Def}(C') = \mathbb{C}^2_{\varepsilon_1, \varepsilon_2} / (\mathbb{C}^{\times})^2$$

and  $\widetilde{\mathbf{C}}$  as the universal family over it.

The divisors  $\varepsilon_i = 0$  are the loci where the ith node remains intact. The strict transform of  $\pi^{-1}(p)$  defines a marked point p' in the fibers of  $\varepsilon$ .

**6.4.7.** Assume we already have a construction of ordinary, nonrelative quasimap moduli spaces<sup>7</sup>. Like any good moduli space, quasimaps moduli are defined not just for an individual source curve C, but for families of those, that is, for curves over some base scheme.

An example of such family is the universal curve  $\widetilde{C}$  over the base  $\mathbb{C}^2_{\epsilon_1,\epsilon_2}$  in (6.4.6). The quasimaps from the fibers of  $\epsilon$  fit together in one variety over  $\mathbb{C}^2_{\epsilon_1,\epsilon_2}$  and we can form the quotient

$$\mathsf{QM}_{\substack{\text{relative } p \\ \leqslant 2 \text{ nodes}}} = \left\{ \begin{array}{l} \text{stable quasimaps} \\ \text{from fibers of } \epsilon \text{ to } X \end{array} \right\} \bigg/ \left(\mathbb{C}^{\times}\right)^2.$$

Here stable means:

- nonsingular at p' and at the nodes,
- the  $(\mathbb{C}^{\times})^2$ -stabilizer is finite.

The quotient (6.4.8) is an open set in the moduli spaces of quasimaps relative  $p \in C$ . It contains those quasimaps for which the domain breaks at most twice.

**6.4.9.** By construction, relative quasimaps come with an evaluation map  $ev_p$  at the relative point  $p' \in C'$ .

**Lemma 6.4.10.** The map ev<sub>p</sub> is proper for quasimaps of fixed degree.

<sup>&</sup>lt;sup>7</sup> In reality, [20] construct quasimap moduli, relative or not, in one stroke over the moduli stack of pointed curves with a principal G-bundle.

*Proof.* Follows from the properness of the map  $\pi$  in the diagram

![](_page_80_Picture_3.jpeg)

shown in [20] and explained in Section 6.3.

**6.4.11.** The deformation theory of the prequotient in (6.4.8) is given by the deformation theory (4.3.17) of quasimaps from a fixed domain plus the lateral movements along the base  $\mathbb{C}^2_{\epsilon_1,\epsilon_2}$ , see [20]. Here it is important that the total space  $\widetilde{\mathbb{C}}$  is smooth and stable quasimaps are nonsingular at the nodes.

Taking the quotient, we get

(6.4.12) 
$$T_{vir} QM_{relative} = T_{vir}^{fixed domain C'} + T Def(C'),$$

where the first term<sup>8</sup> is given by (4.3.17) and

$$\operatorname{Def}(C') \cong \mathbb{C}^{\# \text{ of nodes}} / (\mathbb{C}^{\times})^{\# \text{ of nodes}}$$

with

$$T\, Def(C') = \sum_{\text{nodes } p_i \, \in \, C'} N_{\{\epsilon_i = 0\}} - Lie\, Aut(C', \pi, p') \, .$$

Here  $\{\varepsilon_i = 0\}$  is the Cartier divisor of domains with ith node  $p_i$  intacts.

**6.4.13.** If  $p_i$  is the intersection of components  $C_{i-1}$  and  $C_i$  of C' then (6.4.2) shows

(6.4.14) 
$$N_{\{\epsilon_{i}=0\}} = T_{p_{i}} C_{i-1} \otimes T_{p_{i}} C_{i}.$$

Since the group Lie Aut(C',  $\pi$ ,  $\mathfrak{p}'$ ) acts on these tangent lines, they descend to line bundles on the quotient, typically nontrivial. We will also need the line bundle

$$\psi_{p} = T_{p'}^{*}C'$$

in what follows.

**6.4.16.** After this discussion of the deformation theory for relative quasimaps, we define

$$\widehat{\mathcal{O}}_{\text{vir}} = \mathcal{O}_{\text{vir}} \otimes \left( \mathcal{K}_{\text{vir}}^{\text{fixed domain}} \otimes \frac{\det \mathfrak{I}^{1/2}|_{p_2}}{\det \mathfrak{I}^{1/2}|_{p_1}} \right)^{1/2}.$$

The existence of the square root follows from Lemma 6.1.4.

## 6.5. Degeneration formula and the glue operator

<sup>&</sup>lt;sup>8</sup>The standard name for this term in algebraic geometry is the *relative* virtual tangent space, where the adjective relative refers to the map to the stack of domain deformations. Since the world relative is already infused with a very specific and different meaning for us, we avoid using it here.

**6.5.1.** Degeneration formula in Gromov-Witten theory was proven in [51, 52], see also [53] for corresponding constructions in Donaldson-Thomas theory. In K-theoretic GW computations, there is a correction to gluing, discovered in [36] and discussed in detail in [49]. All these ideas are immediately applicable to quasimaps.

The setting of the degeneration formula is the following. Let a smooth curve C<sup>ε</sup> degenerate to a nodal curve

$$C_0 = C_{0,1} \cup_{p} C_{0,2}$$
.

like in (6.4.2). Degeneration formula counts quasimaps from C<sup>ε</sup> in terms of *relative* quasimaps from C0,1 and C0,2, where in both cases relative conditions are imposed at the gluing point p.

**6.5.2.** The basic idea behind the degeneration formula is that as C<sup>ε</sup> degenerates, the quasimaps QMpC<sup>ε</sup> Ñ Xq degenerate to quasimaps whose domain is a certain destabilization of C0, in which the gluing point p is replaced by a chain of rational curves, like in Figure 6.5.3. This is because we require quasimaps to be nonsingular at the nodes and letting the domain curve develop new components is a way to keep the singularities from getting into the node.

![](_page_81_Picture_7.jpeg)

Figure 6.5.3. A semistable curve whose stabilization is the nodal curve C0. Components with **C** <sup>ˆ</sup> automorphisms are indicated by springs.

**6.5.4.** For a concrete example, take the family (6.4.2) and consider quasimaps to **C**{**C** <sup>ˆ</sup>, as in Section 6.2. A quasimap to **<sup>C</sup>**{**<sup>C</sup>** <sup>ˆ</sup> is a divisor and a family of such is given by a polynomial

$$f(x,y)=0$$

which is not divisible by either x or y. The problem could be that fp0, 0q " 0, meaning that a part of the divisor got into the node of C0, or that the resulting quasimap C<sup>0</sup> 99K X is singular at the node.

From Section 6.2.6, we know exactly what to do. We take the toric blowup of the plane corresponding to the Newton diagram of f, as in Figure 6.2.7. This sends the points which were approaching the origin from different directions to different components of the exceptional divisor.

While the procedure is exactly the same, its interpretation is different: the limiting curve is the exceptional divisor together with *both* coordinate axes. Those are the two components of C<sup>0</sup> and the exceptional curves are the new components the domain had to develop so as to keep the singularities away from the nodes.

**6.5.5.** This motivates defining  $QM(C_0 \rightarrow X)$  in spirit of Section 6.3.1 as the moduli spaces of quasimaps of the form

(6.5.6) 
$$C'_{0} - - \stackrel{f'}{-} - > X$$

$$\downarrow^{\pi}$$

$$C_{0}$$

in which

- the map  $\pi$  collapses a chain of rational curves to the node of  $C_0$ ,
- f' is nonsingular at the nodes of  $C'_0$ ,
- the automorphism group of f' is finite.

Here the source of automorphisms is the group

$$\operatorname{Aut}(C_0',\pi) = (\mathbb{C}^{\times})^{\# \text{ of new components}}$$
 .

**6.5.7.** Domain curves of the form  $C'_0$ , and quasimaps from those curves, are commonly known as *accordions*, see Figure 6.5.8. Indeed, they have two rigid components, and a chain of components rescaled by automorphisms. One may call those nonrigid components bellows, bubbles, etc.

![](_page_82_Figure_11.jpeg)

FIGURE 6.5.8. A poetic representation of a semistable curve which stabilizes to a nodal curve.

**6.5.9.** The obstruction theory is defined on the total space of the family

$$\epsilon: \mathsf{QM}(\mathsf{C}_{\varepsilon} \to \mathsf{X}) \to \mathbb{C}$$

and gives a sheaf whose restriction to fibers is the virtual structure sheaf of the fiber. We thus can do K-theoretic counts on any fiber by pulling back the corresponding point class from  $\mathbb{C}$ . In particular, the counts for  $\epsilon=1$  and  $\epsilon=0$  are equal.

This is very close to what we wanted, in that it gives the counts of quasimaps from the generic fiber in terms of quasimaps from the special fiber. What remains is to separate the quasimaps from the special fibers into contributions of the two components. This is done as follows.

**6.5.10.** Suppose the curve  $C'_0$  has n nodes and let  $\varepsilon_1, \ldots, \varepsilon_n$  be smoothing parameters for each of these nodes. In the corresponding chart on quasimap moduli, we have the equality of divisors

$$(\varepsilon) = (\varepsilon_1 \varepsilon_2 \cdots \varepsilon_n).$$

Exercise 6.5.11. See how this works in the concrete case of Section 6.5.4.

Geometrically,  $\varepsilon_1 \varepsilon_2 \cdots \varepsilon_n = 0$  is the union of coordinate hyperplanes, and we have an inclusion-exclusion formula for the K-theory class of this union, namely

$$(6.5.12) \qquad \mathcal{O}_{\varepsilon_1 \varepsilon_2 \cdots \varepsilon_n = 0} = \sum_{\varnothing \neq S \subset \{1, \dots, n\}} (-1)^{|S| - 1} \mathcal{O}_{\bigcap_{i \in S} \{\varepsilon_i = 0\}},$$

where the summation is over all nonempty subsets S of hyperplanes, that is, to a nonempty subset of nodes of  $C'_0$ .

## Exercise 6.5.13. Prove (6.5.12).

Geometrically, the term in (6.5.12) that corresponds to a given collection of k = |S| nodes computes the contribution of quasimaps whose domain has those k nodes intact. The sum over all S such that |S| = k may be interpreted as the count of quasimaps from domains with k marked nodes.

These quasimaps counts can be glued out of k + 1 pieces as follows.

**6.5.14.** Let C be a curve with a marked node obtained by gluing two curves at marked points

$$C = (C_1, p_1) \sqcup (C_2, p_2) / p_1 \sim p_2.$$

A quasimap from C is a quasimap from each component plus the requirement that it has takes well-defined and equal values at  $p_1$  and  $p_2$ . In other words, we have a product over the evaluation maps to X

$$\begin{aligned} (6.5.15) \quad \mathsf{QM}(\mathsf{C} \to \mathsf{X})_{marked \ node} &= \\ &= \mathsf{QM}(\mathsf{C}_1 \to \mathsf{X})_{relative \ p_1} \times_{\mathsf{X}} \mathsf{QM}(\mathsf{C}_2 \to \mathsf{X})_{relative \ p_2} \end{aligned}$$

and an inspection of the obstruction theory shows

$$(6.5.16) \qquad \chi(\mathsf{QM}(\mathsf{C} \to \mathsf{X})_{\mathsf{marked node}}, \mathcal{O}_{\mathsf{vir}}) = \chi\left(\mathsf{X}, \mathsf{ev}_{\mathsf{p}_1, *}(\mathcal{O}_{\mathsf{vir}}) \otimes \mathsf{ev}_{\mathsf{p}_2, *}(\mathcal{O}_{\mathsf{vir}})\right) \ .$$

The corresponding formula for the symmetrized virtual class  $\widehat{\mathbb{O}}_{vir}$  from (6.1.9) is the following.

Note that fibers of the polarization at marked points enter asymmetrically in the formula (6.1.9). This is very convenient when dealing with chains of rational curves. If the choices are made consistently, the polarization terms for two marked points glued at a node cancel. We assume this is the case, and so we are left with the contribution of  $\mathcal{K}_X$  to  $\mathcal{K}_{vir}$ . We define

(6.5.17) 
$$(\mathfrak{F}, \mathfrak{G})_{X} = \chi(X, \mathfrak{F} \otimes \mathfrak{G} \otimes \mathfrak{K}_{X}^{-1/2}).$$

Then

$$(6.5.18) \qquad \chi(\mathsf{QM}(\mathsf{C} \to \mathsf{X})_{\mathsf{marked node}}, \widehat{\mathcal{O}}_{\mathsf{vir}}) = \chi\left(\mathsf{ev}_{\mathsf{p}_1,*}(\widehat{\mathcal{O}}_{\mathsf{vir}}), \mathsf{ev}_{\mathsf{p}_2,*}(\widehat{\mathcal{O}}_{\mathsf{vir}})\right)_{\mathsf{X}}.$$

**6.5.19.** There is a parallel gluing formula for curves with k marked nodes, except it involves a novel kind of quasimaps whose domains are pure accordion bellows, without rigid components.

We define  $QM_{relative\ p_1,\ p_2}^{\sim}$  as the moduli space of stable quasimaps with whose domain C is a chain of rational curves joining  $p_1$  and  $p_2$ . By definition, stability means nonsingularity at  $p_1$ ,  $p_2$ , and the nodes, together with being stabilized by a finite subgroup in

$$\operatorname{Aut}(C, \mathfrak{p}_1, \mathfrak{p}_2) = (\mathbb{C}^{\times})^{\# \text{ of components}}$$
.

Since a constant quasimap from a nonrigid two-pointed curve is unstable, we make a separate definition

$$QM_{\text{relative }p_1,p_2,\text{degree }0}^{\sim} = QM(point \rightarrow X) = X$$
.

In other words, when bellows don't open, we define C to be a point.

We define

(6.5.20) 
$$\mathbf{G} = (\operatorname{ev}_{p_1} \times \operatorname{ev}_{p_2})_* \, \widehat{\mathbb{O}}_{\operatorname{vir}} \, z^{\operatorname{deg} f}$$
$$= \operatorname{diag} \mathcal{K}_X^{1/2} + \operatorname{O}(z) \,,$$

where O(z) stands for the contribution of nontrivial quasimaps. Clearly, the counts of curves with k marked nodes may be expressed as a certain multiple convolution of relative curve counts like in (6.5.18) with this tensor. It is convenient to have an operator notation to express this convolution.

### **6.5.21.** We have a natural convolution action

$$K(X \times X) \otimes_{K(pt)} K(X) \to K(X)_{localized}$$
.

given by

$$(\mathcal{E}, \mathcal{F}) \mapsto \mathfrak{p}_{1,*} (\mathcal{E} \otimes \mathfrak{p}_2^* \mathcal{F})$$
.

For decomposable classes

$$K(X)^{\textstyle \otimes 2} \subset K(X\times X)$$

this action corresponds to the bilinear form  $(\mathcal{E}, \mathcal{F}) \mapsto \chi(\mathcal{E} \otimes \mathcal{F})$ .

In our situation, the form is twisted by  $\mathcal{K}_X^{-1/2}$  (which is a pure equivariant weight, to be sure) as in (6.5.17), and we similarly twist the convolution action to

$$(\mathcal{E}, \mathcal{F}) \mapsto \mathfrak{p}_{1,*} \left( \mathcal{E} \otimes \mathfrak{p}_2^* \mathcal{F} \otimes \mathcal{K}_X^{-1/2} \right) \,.$$

With this convention (we will see in a moment that localization is not required)

(6.5.23) 
$$\mathbf{G} = 1 + \mathcal{O}(z) \in \text{End } \mathsf{K}(\mathsf{X})[[z]]$$

as an operator on K(X). We call it the *gluing operator*. From (6.5.23) we see it is invertible in End K(X)[[z]].

Exercise 6.5.24. Generalizing (6.5.18) prove

$$\begin{split} (6.5.25) \quad \chi(\mathsf{QM}(\mathsf{C} \to \mathsf{X})_{k \text{ marked nodes}}, \widehat{\mathbb{O}}_{\mathrm{vir}} \, z^{\deg \, \mathsf{f}}) = \\ &= \chi\left( (\mathbf{G} - 1)^{k-1} \, \mathrm{ev}_{\mathsf{p}_1, *}(\widehat{\mathbb{O}}_{\mathrm{vir}} \, z^{\deg \, \mathsf{f}}), \mathrm{ev}_{\mathsf{p}_2, *}(\widehat{\mathbb{O}}_{\mathrm{vir}} \, z^{\deg \, \mathsf{f}}) \right)_{\mathsf{X}} \, . \end{split}$$

**6.5.26.** From formulas (6.5.12) and (6.5.25) we deduce the following

**Proposition 6.5.27** ([36, 49])**.** *We have*

$$\begin{split} (6.5.28) \quad \chi(\mathsf{QM}(\mathsf{C}_0 \to \mathsf{X}), \widehat{\mathbb{O}}_{vir} \, z^{\text{deg } f}) = \\ &= \left( \mathbf{G}^{-1} \, \text{ev}_{1,*}(\widehat{\mathbb{O}}_{vir} \, z^{\text{deg } f}), \text{ev}_{2,*}(\widehat{\mathbb{O}}_{vir} \, z^{\text{deg } f}) \right)_{\mathsf{X}} \, , \end{split}$$

*where*

$$ev_{\mathfrak{i}}:\mathsf{QM}(C_{0,\mathfrak{i}}\to X)_{relative\ gluing\ point}\to X$$

*are the evaluation maps.*

*Proof.* Follows from

$$\sum_{k\geqslant 1} (-1)^{k-1} (\mathbf{G} - 1)^{k-1} = \mathbf{G}^{-1}.$$

## **6.5.29.** We also have the following

**Proposition 6.5.30.** *The glue operator* **G** *acts in nonlocalized* K*-theory of* X*.*

*Proof.* Recall that X<sup>0</sup> denotes the affinization of the Nakajima variety X. Since every quasimap is contracted by the map to X0, the evaluation map in (6.5.20) is a proper map to

(6.5.31) Steinberg variety := 
$$X \times_{X_0} X \subset X \times X$$
.

Since the map X Ñ X<sup>0</sup> is proper, any class supported on the Steinberg variety acts in nonlocalized K-theory.

## **7. Nuts and bolts**

## **7.1. The Tube**

## **7.1.1.** We define

$$(7.1.2) \qquad \qquad \mathsf{Tube} = \mathrm{ev}_* \left( \mathsf{QM}_{\mathrm{relative} \ p_1, \, p_2} \,, \, \widehat{\mathfrak{O}}_{\mathrm{vir}} \, z^{\mathrm{deg} \, \mathrm{f}} \right) \in \mathsf{K}(X)^{\otimes 2} \otimes \mathbb{Q}[[z]] \,,$$

and make it an operator acting from the second copy of KpXq to the first using the bilinear form (6.5.17) or, more precisely, the formula (6.5.22).

Just like in the case of the gluing matrix **G** considered in Proposition 6.5.30, the operator Tube acts in nonlocalized K-theory of X.

## **7.1.3.**

## **Theorem 7.1.4.** *We have*

$$(7.1.5) Tube = G$$

It will be instructive to go through two very different proofs of this statement. The first one is very short.

*First proof.* The degeneration formula (6.5.28) gives

Tube = Tube 
$$\mathbf{G}^{-1}$$
 Tube.

Therefore, the operator  $P = \text{Tube } \mathbf{G}^{-1}$  satisfies

$$P^2 = P$$

Since P = 1 + O(z), this projector is invertible, whence P = 1.

**7.1.6.** Let  $\mathbb{C}^{\times}$  act on  $\mathbb{C} \cong \mathbb{P}^1$  with fixed points  $\mathfrak{p}_1$  and  $\mathfrak{p}_2$ . Denote

$$q = weight of T_{p_1}C$$
.

We will denote this group  $C_q^{\times}$  to distinguish it from other tori present.

For our second proof of Theorem 7.1.4, we will use  $\mathbb{C}_q^{\times}$ -equivariant localization. For this, we need a description of the  $\mathbb{C}_q^{\times}$ -fixed quasimaps.

**7.1.7.** Let f be a  $\mathbb{C}_q^{\times}$ -fixed quasimap. By stability, its singularities in  $C\setminus\{p_1,p_2\}$  form a set which is

finite and 
$$\mathbb{C}_q^{\times}$$
-invariant  $\Rightarrow$  empty.

For maps relative  $\{p_1, p_2\}$ , this means that all singularities appear in the accordions and  $f|_C$  is constant map to a point in X. In particular, all bundles  $\mathcal{V}_i|_C$  are trivial.

In general, for the  $\mathbb{C}_q^{\times}$ -fixed quasimaps there is a unique  $\mathbb{C}_q^{\times}$ -equivariant structure on the bundles  $\mathcal{V}_i$  compatible with the quiver maps and the trivial equivariant structure on the bundles  $\mathcal{W}_i$  and  $\mathfrak{Q}_{ij}$ . In our case,  $\mathbb{C}_q^{\times}$  acts trivially on the trivial bundles  $\mathcal{V}_i|_{\mathbb{C}}$ .

**7.1.8.** We conclude the only part of the deformation theory on which  $\mathbb{C}_q^{\times}$  acts are the normal direction to the fixed locus. These correspond to the smoothing of the nodes at  $p_i \in C$ , when the nodes are present. For example, the contribution of the accordions at  $p_1$  is

$$(7.1.9) \quad \text{ev}_*\left(\mathsf{QM}^{\sim}_{\text{relative }\mathfrak{p}'_1,\,\mathfrak{p}_1},z^{\text{deg }\widehat{\mathbb{O}}_{\text{vir}}}\,\frac{1}{1-\mathsf{q}^{-1}\psi_{\mathfrak{p}_1}}\right) \in \mathsf{K}(\mathsf{X})^{\otimes 2}\otimes \mathbb{Q}[[\mathsf{q}^{-1}]][[z]]$$

because by (6.4.14)

$$N_{\exists \ node \ at \ p_1 \in \ C^{\,\prime}} = \psi_{p_1}^{\,\vee} \otimes \mathfrak{q} \,.$$

**7.1.10.** Each z-coefficient in (7.1.9) is a rational function of q by the following

**Lemma 7.1.11.** Let Y be a projective scheme and  $\mathcal{L}$  an orbifold line bundle on Y. Then for any coherent sheaf  $\mathcal{F}$  the series

$$\chi(q) = \chi\left(Y, \frac{\mathfrak{F}}{1 - q^{-1}\mathcal{L}}\right) = \sum_{k \geq 0} q^{-k} \chi(Y, \mathfrak{F} \otimes \mathcal{L}^k)$$

is a rational function of q such that

$$\chi(0) = 0$$
,  $\chi(\infty) = \chi(Y, \mathcal{F})$ .

<sup>&</sup>lt;sup>9</sup>or chosen, in the twisted situation

*Proof.* By orbifold Riemann-Roch (or by the theory of Hilbert polynomial), we have

$$\chi(Y, \mathcal{F} \otimes \mathcal{L}^k) = \text{polynomial in } \{k, \zeta_i^k\}$$

for some roots of unity  $\zeta_i$  (and, in equivariant situation, also in  $w_i^k$ , where  $w_i$ 's are certain weights of Aut(X)). For any function of the form  $f(k) = k^m t^k$  we have

$$\sum_{k\geqslant 0} f(k)\,q^{-k} = \left(q\frac{d}{dq}\right)^m \frac{1}{1-t/q} \to \begin{cases} 0\,, & q\to 0\\ f(0)\,, & q\to \infty\,, \end{cases}$$

the lemma follows.

#### 7.1.12.

Second proof of Theorem 7.1.4. Since the pushforward in (7.1.2) is proper, the result is a Laurent polynomial in q. From Lemma 7.1.11 we conclude that

operator defined by (7.1.9) 
$$\rightarrow \begin{cases} 1, & q \to 0 \\ G, & q \to \infty, \end{cases}$$

where 1 is the contributions of the degree 0, that is, empty accordions.

For the accordions at  $p_2$ , the analysis is the same with q replaced by  $q^{-1}$ , therefore

Tube 
$$\rightarrow$$
 **G**,  $q \rightarrow \{0, \infty\}$ 

and the theorem follows.

**7.1.13.** It is convenient to use the following shorthand script for the kind of computations that we will be doing in this section. We compute with quasimaps from chains of rational curves, with two or one marked points at the ends, and the corresponding K-theoretic counts are naturally interpreted as operators or vectors in K(X)[[z]], compare with the discussion in Section 3.5.35. To denote these operators, and the order in which they compose, we can simply draw the quasimap domains, with the marked points, nodes, etc.

In our chain of rational curves, we can have two kinds of components: the rigid (or parametrized) ones, and those with only two special points and  $\mathbb{C}^{\times}$  worth of automorphisms. We call the latter *elastic* and denote

![](_page_87_Picture_16.jpeg)

We can have several kinds of marked points, depending on the constraints we put on quasimaps at that marked point. The basic marked points, with no constraints, is denoted by

If we require the quasimap to be nonsingular at a marked point, we draw an open circle:

.

Quasimaps relative to a point will be denoted

a relative point .

Also, nodes count among the special points

a node .

**7.1.14.** For example, in this shorthand, the degeneration and gluing formulas say

$$(7.1.15) \qquad = \qquad \qquad = \qquad \qquad \qquad = \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad$$

where

$$G = ($$

is the gluing matrix.

Similarly, we have

Tube "

and the argument in Section 7.1.3 can be drawn as follows

$$(7.1.16) \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad \qquad = \qquad =$$

# **7.2. The Vertex**

**7.2.1.** As in (6.2.2), consider the open set

$$QM_{nonsing p_2} \subset QM$$

of quasimaps nonsingular at p<sup>2</sup> and define

$$(7.2.2) \qquad \mathsf{Vertex} = \mathrm{ev}_{\mathfrak{p}_2,*} \left( \mathsf{QM}_{\mathrm{nonsing} \ \mathfrak{p}_2} \, , \widehat{\mathfrak{O}}_{\mathrm{vir}} \, z^{\mathrm{deg} \ \mathrm{f}} \right) \in \mathsf{K}(\mathsf{X})_{\mathrm{localized}} \otimes \mathbb{Q}[[z]] \, .$$

This object may also be called K-theoretic Givental's I-function.

While the pushforward in (7.2.2) is not proper, we will see the fixed loci of the **C** ˆ <sup>q</sup> -action are proper, so the pushforward is defined in localized K-theory.

**7.2.3.** More generally, let

$$\lambda \in K_G(pt)$$

be a virtual representation of the group G in (4.1.5). It is a tensor polynomial in the defining representations V<sup>i</sup> , something like <sup>λ</sup> " <sup>V</sup><sup>1</sup> <sup>b</sup> <sup>V</sup><sup>2</sup> ´ <sup>Λ</sup>3V2.

The polynomial  $\lambda$  may be evaluated on the fibers  $v_i|_{p_1}$  over the point  $p_1$ . We can define the vertex *with descendents* by

$$\langle \lambda | = ev_{p_2,*} \left( \mathsf{QM}_{nonsing \; p_2} \, , \widehat{\mathbb{O}}_{vir} \, z^{deg \; f} \, \lambda \left( \mathcal{V} \big|_{p_1} \right) \right) \, .$$

In particular

$$\langle 1| = \text{Vertex}$$
.

Also note that by (4.3.11)

$$\langle \det V_i \otimes \lambda | = \det V_i \otimes \langle \lambda | \Big|_{z_i \mapsto qz_i},$$

which is essential point behind the difference equations for the vertex that will be discussed at length below.

**7.2.6.** Let f be a  $\mathbb{C}_q^{\times}$ -fixed quasimap in  $\mathsf{QM}_{\mathsf{nonsing}\; p_2}$ . As in Section 7.1.7, this implies that  $\mathsf{f}\big|_{\mathbb{C}\setminus\{p_1\}}$  is a map to a point  $x\in X$ . We can identify the trivial bundles  $\mathcal{V}_{\mathfrak{i}}\big|_{\mathbb{C}\setminus\{p_1\}}$  and quiver maps between them with the quiver data for the point  $x\in X$ . Define

$$\mathbb{V}_i = \bigoplus_{k \in \mathbb{Z}} \mathbb{V}_i[k] = H^0(\mathcal{V}_i \big|_{C \setminus \{p_2\}}),$$

where  $V_i[k]$  is the subspace of weight k with respect to  $\mathbb{C}_q^{\times}$ . By invariance, all quiver maps preserve this weight decomposition. We define the framing spaces W[k] in the same way and obtain

(7.2.7) 
$$W_{i}[k] = \begin{cases} W_{i}, & k \leq 0, \\ 0, & k > 0, \end{cases}$$

because the bundles  $W_i$  are trivial.

Multiplication by the coordinate induces an embedding

$$V_i[k] \hookrightarrow V_i[k-1] \hookrightarrow \ldots \hookrightarrow V_i[-\infty] = V_i$$
,

compatible with quiver maps, where  $V_i$  is the quiver data for x. Thus

(7.2.8) 
$$\left( \mathsf{QM}_{\mathsf{nonsing} \; \mathsf{p}_2} \right)^{\mathsf{C}_{\mathsf{q}}^{\times}} = \left\{ \begin{array}{l} \mathsf{flags} \; \mathsf{of} \; \mathsf{quiver} \; \mathsf{subrepresentations} \\ \mathsf{satisfying} \; \mathsf{(7.2.7)} \end{array} \right\} \; .$$

In particular, the space of flags (7.2.8) inherits a perfect obstruction theory from the ambient space of quasimaps  $^{10}$ .

**7.2.9.** Recall that  $\theta$  denotes the stability parameter for the quiver.

Lemma 7.2.10. We have

$$\begin{split} \mathbb{V}[k] &= 0 \quad \text{or} \quad \theta \cdot \dim \mathbb{V}[k] > 0 \,, & k > 0 \,, \\ (7.2.11) \qquad & \mathbb{V}[k] &= V \quad \text{or} \quad \theta \cdot \dim \mathbb{V}[k] > \theta \cdot \dim V \,, & k \leqslant 0 \,. \end{split}$$

$$0 \to \mathrm{Obs}_{\mathrm{reduced}} \to \mathrm{Obs} \to \hbar^{-1} \otimes \mathbb{C}^{\# \, \mathrm{steps}} \to 0$$
,

where the exponent is the number of nontrivial steps in the flag.

 $<sup>^{10}</sup>$  By analogy with the Hilbert scheme, it should be the case that this obstruction theory may be further reduced by

*Proof.* It is convenient to use the reformulation of quiver stability given by Crawley-Boevey, see in particular Section 3.2 in [35]. In this reformulation, one trades the framing spaces for an extra vertex  $\{\infty\}$ , with

$$\dim V_{\infty} = 1$$

and  $\dim W_i$  arrows to every other vertex i.

The stability parameter is extended by

$$\theta_{\infty} = -\theta \cdot dim \, V$$

and the stability condition reads

$$(\theta, \theta_{\infty}) \cdot (\dim V', \dim V'_{\infty}) > 0$$

for every nontrivial subrepresentation  $V^{\prime} \subset V.$  Since

(7.2.12) 
$$\dim \mathbb{V}_{\infty}[k] = \begin{cases} 1, & k \leq 0, \\ 0, & k > 0, \end{cases}$$

the lemma follows.

**7.2.13.** We have

$$(7.2.14) \qquad \qquad \text{deg } f = (\text{deg } \mathcal{V}_i) = \sum_{k \in \mathbb{Z}} \left( \text{dim } \mathbb{V}_i[k] - \delta_{\{k \leqslant 0\}} \text{ dim } V_i \right).$$

Let

$$C_{ample} \subset H^2(X, \mathbb{R})$$

be the closed ample cone of X. It is the closure of a neighborhood of  $\mathbb{R}_{>0}$   $\theta$  formed by those  $\theta'$  which give an isomorphic GIT quotient. By Lemma 7.2.10,

$$\left(\, dim \, V_i \big[ k \big] - \delta_{\{k \leqslant 0\}} \, \, dim \, V_i \right) \in C_{ample}^{\,\vee} \, , \quad \forall k \, .$$

This bounds the dimensions of  $V_i[k]$  for fixed degree and gives the following

**Corollary 7.2.15.** *The map* 

$$ev_{\mathfrak{p}_2}: \left(\mathsf{QM}_{nonsing\ \mathfrak{p}_2}\right)^{\mathbb{C}_{\mathfrak{q}}^{\times}} \to X$$

is proper for quasimaps of fixed degree. The moduli space is empty for degrees outside  $C_{ample}^{\vee}$ .

**7.2.16.** In many instances, one can use equivariant localization with respect to an additional torus may be used to compute the vertex. If a torus T acts on X then  $\mathbb{C}_q^\times \times \mathsf{T}$  fixed quasimaps are given in terms of flags  $\mathbb{V}_i[k]$  that are additionally graded by the weights of T.

The quiver maps are required to be T-equivariant, in particular, to shift the weight if the T-action on the corresponding arrow is nontrivial. Similarly, the framing spaces  $W_i$  acquire an additional grading.

The characters of all these spaces are uniquely reconstructed by

(7.2.17) 
$$\mathbb{V}[k] \cong \left(\mathcal{V}\big|_{\mathfrak{p}_1}\right)_{q\text{-weight}} \geqslant k$$

from the character of  $\mathbb{C}_q^{\times} \times T$  on the fiber of  $\mathcal{V}$  at  $p_1$ . Similarly, the character of the deformation theory (4.3.17) is directly computable from the character of  $\mathcal{V}\big|_{p_1}$  by localization.

**Exercise 7.2.18.** Spell out the localization formula for the vertex for  $X = T^* Gr(k, n)$ .

**Exercise 7.2.19.** Write a code that computes the vertex function for the Hilbert scheme of points in  $\mathbb{C}^2$ .

**7.2.20.** While localization, especially in the case of isolated fixed points, gives a certain computational handle on the vertex, a much more powerful way to compute to compute the vertex is to identify a q-difference equation that it satisfies. This identification will require a certain development of the theory.

### 7.3. The index limit

**7.3.1.** Let a torus A act on X preserving the symplectic form. A dramatic simplification occurs in the localization formulas if we let the equivariant variable  $a \in A$  go to one of the infinities of the torus.

Very abstractly, suppose

$$X = T^*M /\!\!/ G$$

and let a torus A act on M commuting with G. For every component  $F \subset X^A$  we can assume that A acts so that

$$F = T^*(M^A) /\!\!/ G.$$

Because we consider quasimaps from a fixed domain, on which A is not allowed to act, we conclude that

$$\iota_{QM}: QM(F) \to QM(X)^A$$

is an inclusion of a component. Its virtual normal bundle is

$$(7.3.2) N_{vir} = H^{\bullet} \left( \mathfrak{I}_{moving}^{1/2} \oplus \hbar^{-1} \left( \mathfrak{I}_{moving}^{1/2} \right)^{\vee} \right),$$

where the subscript refers to the A-moving part of the restriction of the polarization to  $X^A$ .

As in Lemma 6.1.4, we conclude

(7.3.3) 
$$N_{vir} = \sum_{i=1}^{2} \mathfrak{I}_{moving}^{1/2}|_{p_i} + H - \hbar^{-1}H^{\vee}, \quad H = H^{\bullet}\left(\mathfrak{I}_{moving}^{1/2} \otimes \mathfrak{K}_{C}\right).$$

**7.3.4.** Consider a balanced virtual A-module  $H - \hbar^{-1}H^{\vee}$ . Its contribution to  $\mathfrak{O}_{vir} \otimes \mathcal{K}_{vir}^{1/2}$  is

$$\widehat{\mathsf{a}}\left(\mathsf{H}-\hbar^{-1}\mathsf{H}^{\vee}\right) \to (-\hbar^{-1/2})^{rk\,\mathsf{H}_{+}-rk\,\mathsf{H}_{-}}\,,\quad \alpha \to 0\,,$$

where

$$H = H_+ \oplus H_-$$

is the decomposition of H into attracting and repelling subspaces as  $a \rightarrow 0$ . By Riemann-Roch,

$$rk\,H_+ = deg\, \mathfrak{T}_{>0}^{1/2} - rk\, \mathfrak{T}_{>0}^{1/2} \, ,$$

and similarly for H\_.

Taking into account the asymmetry between marked points in (6.1.9), the contribution of the first term in (7.3.3) to  $\hat{O}_{vir}$  equals

$$\left(\frac{\det \mathfrak{T}_{\text{moving},\mathfrak{p}_2}^{1/2}}{\det \mathfrak{T}_{\text{moving},\mathfrak{p}_1}^{1/2}}\right)^{1/2} \bigotimes_{\mathfrak{i}=1}^{2} \widehat{\mathsf{S}}^{\bullet} \left(\mathfrak{T}_{\text{moving}}^{1/2}\big|_{\mathfrak{p}_{\mathfrak{i}}}\right)^{\vee},$$

where the symmetric algebra with a hat was defined in (2.1.22). Note that this has a nontrivial q-weight. Its analysis leads to q-dependence in the following

**Lemma 7.3.5.** *As*  $a \rightarrow 0$ ,

$$(7.3.6) \qquad \text{Vertex}_{X} \to \hbar^{\frac{codim}{4}} (-\hbar^{-1/2})^{\deg \mathcal{N}_{>0}} q^{-\deg \mathcal{I}_{<0}^{1/2}} \text{Vertex}_{X^{A}} \,,$$

where

$$\mathcal{N}_{>0} = \mathcal{T}_{>0}^{1/2} + \hbar^{-1} \left( \mathcal{T}_{<0}^{1/2} \right)^{\vee}$$

is the attracting part of the normal bundle to  $X^A$ .

For the full vertex, that is, the sum over all degrees with weight  $z^{\text{deg}}$ , the relationship (7.3.6) means a shift of the argument z by a monomial in  $(-\hbar^{-1/2})$  and q.

### 7.4. Cap and capping

**7.4.1.** In parallel to (7.2.4), we define the *capped descendents* 

$$(7.4.2) \qquad \left\langle \lambda \right\| = ev_{p_2,*} \left( \mathsf{QM}_{relative \; p_2} \,, \widehat{\mathfrak{O}}_{vir} \, z^{deg \, f} \, \lambda \left( \mathcal{V} \big|_{p_1} \right) \right) \in \mathsf{K}(\mathsf{X}) \otimes \mathbb{Q}[[z]] \,.$$

Note that in contrast to the vertex, this is a proper pushforward, hence an element of nonlocalized K-theory. Precisely because it is a element of nonlocalized K-theory, it is in many ways a simpler object than the vertex.

By construction,

$$\langle \lambda \| = \lambda(V) \, \mathcal{K}_X^{1/2} + \mathrm{O}(z)$$

where O(z) stands for contribution of nonconstant maps. We will see that for many insertions  $\lambda$  the cap (7.4.2) is purely classical, that is, the O(z) term in (7.4.3) vanishes.

**7.4.4.** In the shorthand of Section 7.1.13, we have

![](_page_92_Picture_22.jpeg)

As in Section 7.1.8, localization gives

$$(7.4.5) \qquad \qquad \bullet \qquad \qquad O ( \swarrow ),$$

where the subscript  $\psi$  in the

$$|\text{capping operator}| = (7.4.6)$$

indicates the insertion of the cotangent line in the accordion count as in (7.1.9).

**7.4.7.** One can view (7.4.5) as a linear equation for the vertex. The matrix (7.4.6) of this linear equation is invertible and, in fact, will be identified with the fundamental solution of a certain q-difference equation in what follows.

The constant term, or the left-hand side, of this linear equation will be computed using the vanishing of quantum terms in (7.4.3) once the dimensions of the framing spaces are sufficiently large and the polarization is chosen accordingly.

### 7.5. Large framing vanishing

**7.5.1.** Our proof of vanishing of the quantum terms in (7.4.3) will follow the logic of the second proof of Theorem 7.1.4, namely, it will be based on the analysis of the integrand in the  $q \to \{0,\infty\}$  limits. In contrast to the situation considered in Section 7.1.12 , the group  $\mathbb{C}_q^\times$  may now act nontrivially in the fiber  $\mathcal{V}\big|_{p_1}$  over its fixed point  $p_1$  and the weights of this action have to be analyzed.

Concretely, suppose

$$V_i \cong \bigoplus_k O(d_{ik})$$

then we get the weights  $\{q^{d_{ik}}\}$  in the fiber of  $\mathcal{V}_i$  over  $\mathfrak{p}_1$  and hence a crude bound of the form

$$\left. \begin{array}{ll} \left( 7.5.2 \right) & & tr_{\mathcal{V}_i \big|_{p_1}} \, q^m = \begin{cases} O \left( q^{m \deg \mathcal{V}_{i,n}} \right) & q \to 0 \\ O \left( q^{m \deg \mathcal{V}_{i,p}} \right) & q \to \infty \,, \end{cases}$$

where

$$(7.5.3) \hspace{1cm} \mathcal{V}_{i,\mathbf{n}} \cong \bigoplus_{d_{ik} < 0} \mathfrak{O}(d_{ik}) \,, \quad \mathcal{V}_{i,\mathbf{p}} \cong \bigoplus_{d_{ik} > 0} \mathfrak{O}(d_{ik}) \,.$$

The extension of (7.5.2) to a general  $\lambda \in K_G(pt)$ , with  $\mathfrak{m}$  replaced by the degree of the symmetric function  $\lambda$ , will be used in what follows.

**7.5.4.** It is clear from (7.5.2) that the key to bounding the degree in q is to bound the degrees of  $V_{i,n}$  and  $V_{i,p}$ . This is done in the following

**Lemma 7.5.5.** Both terms in the decomposition

$$deg\,\mathcal{V} = deg\,\mathcal{V}_n + deg\,\mathcal{V}_p$$

belong to  $C_{ample}^{\vee}$ .

*Proof.* From (7.2.17), we have

$$\begin{split} \text{deg}\, \mathcal{V}_p &= \sum_{k>0} \text{dim}\, \mathbb{V}[\mathtt{k}]\,,\\ \text{deg}\, \mathcal{V}_n &= \sum_{k<0} \left(\text{dim}\, \mathbb{V}[\mathtt{k}] - \text{dim}\, V\right)\,, \end{split}$$

and so we conclude by Lemma 7.2.10.

**Corollary 7.5.6.** For a given ample cone  $C_{ample}$ , there exists  $\theta_{\star} \in C_{ample}$  such that

$$\begin{array}{ll} (7.5.7) & \left|\log_q \operatorname{tr}_{\lambda(\mathcal{V}|_{p_1})} q\right| = O\left((\theta_{\star}, deg\,\mathcal{V})\,deg\,\lambda\right)\,, \quad q \to \{0,\infty\}\,, \\ \text{for all } \lambda \in K_G(pt). \end{array}$$

Recall from Section 6.1.2 that a polarization of X is an equivariant Ktheory class  $T^{1/2}X$  satisfying

(7.5.9) 
$$TX = T^{1/2}X + \hbar^{-1} \left( T^{1/2}X \right)^{\vee} .$$

A polarization of X is unique up to adding a balanced class

(7.5.10) 
$$T^{1/2}X \mapsto T^{1/2}X + \mathcal{G} - \hbar^{-1}\mathcal{G}^{\vee}, \quad \mathcal{G} \in K(X),$$

which affects the modified virtual canonical class (6.1.9) by

$$\widehat{\mathcal{O}}_{\text{vir}} \mapsto \widehat{\mathcal{O}}_{\text{vir}} \frac{\det \mathcal{G}_2}{\det \mathcal{G}_1},$$

where  $g_1$  is corresponding polynomial in  $v_i|_{p_1}$ . Note that by (7.2.5) this also means

$$(7.5.12) \left\langle \lambda \right| \mapsto \left\langle \lambda \right|_{z \to q^{\det g} z'}$$

and so all polarizations are equally good for computing the vertex or for determining the vertex from the computation of the cap.

The contribution of the polarization at  $p_1$  to  $\hat{O}_{vir}$  in localization formulas is

$$(7.5.14) \qquad \qquad (-1)^{rk\,\mathfrak{T}^{1/2}}\mathsf{S}^{\bullet}\mathfrak{T}_{p_1}^{1/2} = \begin{cases} O\left(\mathsf{q}^{-\deg\mathfrak{T}_{\mathbf{n}}^{1/2}}\right) & \mathsf{q}\to0\,,\\ O\left(\mathsf{q}^{-\deg\mathfrak{T}_{\mathbf{p}}^{1/2}}\right) & \mathsf{q}\to\infty\,, \end{cases}$$

where  $\mathfrak{T}_{\mathfrak{p}}^{1/2}$  and  $\mathfrak{T}_{\mathfrak{n}}^{1/2}$  are defined as in (7.5.3).

**Definition 7.5.15.** We say that the polarization  $T^{1/2}$  is large with respect to  $\theta \in$ C<sub>ample</sub> if

$$(7.5.16) \qquad \qquad \deg \mathfrak{T}_{\mathbf{p}}^{1/2} > \theta \cdot \deg f,$$
 
$$(7.5.17) \qquad \qquad -\deg \mathfrak{T}_{\mathbf{n}}^{1/2} \geqslant \theta \cdot \deg f.$$

$$-\deg \mathfrak{I}_{\mathbf{n}}^{1/2} \geqslant \theta \cdot \deg f.$$

for any nonconstant stable quasimap f with stability parameter  $\theta$ .

It is important to note that  $\mathfrak{T}^{1/2}$  is a virtual vector bundle and so the degree of  $\mathfrak{T}_n^{1/2}$  need *not* be negative. For an example of this phenomenon, one can take quasimaps to  $\mathsf{T}^*\operatorname{Gr}(\mathfrak{n},\mathfrak{n})$ , for  $\mathfrak{n}>1$ .

**7.5.18.** Let

$$v = \dim V$$
,  $w = \dim W$ ,

be the dimension vectors corresponding to  $X = X_{v,w}$  and recall that any Nakajima variety may be embedded

$$(7.5.19) X_{V,W} \hookrightarrow X_{V,W'}, \quad W' > W,$$

into a larger Nakajima variety as a fixed point of the action of the framing torus. The ample cones stabilize with respect to these embeddings.

**Proposition 7.5.20.** For any  $\theta$ , there exists w' and a polarization of  $X_{v,w'}$  which is large with respect to  $\theta$ .

*Proof.* We take

(7.5.21) 
$$T^{1/2}X_{v,w'} = \mathcal{F} + \mathcal{L} - \hbar^{-1}\mathcal{L}^{-1} + \dots,$$

where

$$\mathfrak{F} = \bigoplus_{\theta_{\mathfrak{i}} > 0} \text{Hom}(W_{\mathfrak{i}}', V_{\mathfrak{i}}) + \bigoplus_{\theta_{\mathfrak{i}} < 0} \hbar^{-1} \, \text{Hom}(V_{\mathfrak{i}}, W_{\mathfrak{i}}') \, ,$$

 $\mathcal{L}$  is a line bundle of the form

$$\mathcal{L} = \bigotimes \left( det \, V_i \right)^{-C \, \theta_i} \; , \quad C \gg 0$$

and dots in (7.5.21) stand for terms with  $Q_{ij}$  from (4.2.2). The degrees of all line bundles appearing in those omitted terms are bounded in terms of  $\theta \cdot \text{deg } f$  by Lemma 7.5.5.

Since  $\mathcal{L}$  can be made arbitrarily negative by choosing C large enough, it can be used to make the polarization (7.5.21) satisfy (7.5.17). Now take

$$w_i' \approx C' |\theta_i| \quad C' \gg C \gg 0$$
.

Since  $\mathcal{F}$  for an actual, that is, not a virtual vector bundle  $\mathcal{F}$  we have

$$deg \mathcal{F}_{\mathbf{p}} \geqslant deg \mathcal{F} \approx \left( \bigotimes \left( det V_{i} \right)^{C'\theta_{i}} \right)$$

and this can be made arbitrarily large so that to satisfy (7.5.16).

**7.5.22.** Let  $\theta_{\star}$  be as in Corollary 7.5.6.

**Theorem 7.5.23.** If the polarization  $T^{1/2}X$  is large with respect to  $(\deg \lambda)\theta_{\star}$  then

$$\langle \lambda \| = \lambda(V) \, \mathcal{K}_X^{1/2}$$

*Proof.* We argue as in Section 7.1.12. Localization may be phrased as

(7.5.25) 
$$\langle \lambda | = \langle \lambda | | \text{capping operator} \rangle$$

where the capping operator is the same as already discussed in Section 7.1.8. The matrix elements of this operator are given by

$$(7.5.26) \qquad \text{ev}_*\left(\mathsf{QM}^\sim_{\text{relative }\mathfrak{p}_2,\mathfrak{p}_2'},z^{\text{deg}}\,\widehat{\mathfrak{O}}_{\text{vir}}\,\frac{1}{1-q\psi_{\mathfrak{p}_2}}\right) \in \mathsf{K}(X)^{\bigotimes 2}\otimes \mathbb{Q}[[\mathfrak{q}]][[z]]\,.$$

Therefore

(7.5.27) 
$$|\text{capping operator}| \rightarrow \begin{cases} 1, & q \to \infty \\ O(1), & q \to 0. \end{cases}$$

On the other hand, by Corollary 7.5.6, (7.5.14), and the definition of a large polarization

(7.5.28) 
$$\langle \lambda | \to \begin{cases} \lambda(V) \, \mathcal{K}_X^{1/2}, & q \to \infty \\ O(1), & q \to 0. \end{cases}$$

The Theorem follows.

Observe that very crude estimates were used in the proof and sharper results on vanishing of quantum corrections in (7.4.3) can be obtained along the same lines.

**7.5.29.** Recall we view (7.5.25) as a system of linear equations that lets one determine the vertex if the cap and the capping operator are known. The capping operator will be computed as the fundamental solutions of a certain q-difference equation below.

For any given  $\lambda$ , one can thus compute  $\langle \lambda |$  for all Nakajima varieties with sufficiently large framing vector w', as in Proposition 7.5.20.

From this, one can go to all Nakajima varieties using Lemma 7.3.5.

## 8. Difference equations

## 8.1. Shifts of Kähler variables

**8.1.1.** Let  $\mathcal{F}$  be a  $\mathbb{C}_q^{\times}$ -equivariant coherent sheaf on C. We have

$$(8.1.2) \hspace{1cm} \text{det}\, H^{\bullet}(\mathfrak{F} \otimes (\mathfrak{O}_{\mathfrak{p}_{1}} - \mathfrak{O}_{\mathfrak{p}_{2}})) = q^{\text{deg}\,\mathfrak{F}} \text{,}$$

and this equality is  $Aut(\mathfrak{F})$ -equivariant. It suffices to check (8.1.2) for  $\mathfrak{F} \in \{0, 0_{p_1}\}$ , which is immediate

**8.1.3.** Recall that for relative quasimaps, the tautological bundles  $V_i$  are defined on a certain destabilization

$$\pi: C' \to C$$

of the original curve C. Since

$$\deg \mathcal{V}_{i} = \deg \pi_{*} \mathcal{V}_{i},$$

we have

(8.1.4) 
$$q^{\text{deg } \mathcal{V}_i} = \det H^{\bullet}(\mathcal{V}_i \otimes \pi^*(\mathcal{O}_{\mathfrak{p}_1} - \mathcal{O}_{\mathfrak{p}_2})).$$

This means that for any K-theoretic count of quasimaps, we have

$$(8.1.5) \qquad \left\langle \dots z^{\text{deg}} \right\rangle \bigg|_{z_i \mapsto q z_i} = \left\langle \dots z^{\text{deg}} \det H^{\bullet}(\mathcal{V}_i \otimes \pi^*(\mathcal{O}_{p_1} - \mathcal{O}_{p_2})) \right\rangle,$$

where dots stand for arbitrary additional insertions. The basic relation (8.1.5) turns into q-difference equations as follows.

**8.1.6.** To illustrate different possibilities, consider the following setup that mixes relative and absolute conditions.

We can define

$$(8.1.7) J = ev_* \left( QM_{\substack{\text{relative } p_1 \\ \text{nonsing at } p_2}}, \widehat{\mathcal{O}}_{\text{vir }} z^{\text{deg } f} \right) \in K(X)_{\substack{\text{localized}}}^{\otimes 2} \otimes \mathbb{Q}[[z]]$$

by equivariant localization. Using the bilinear pairing (6.5.17) on K(X), one can turn J into an operator acting from the second copy of K(X) to the first. We have seen this operator previously, namely

$$J = |\text{capping at } p_1|.$$

By our conventions,

$$(8.1.9) J = 1 + O(z).$$

**8.1.10.** Since  $\pi$  is an isomorphism over  $p_2$ , we have

$$\det H^{\bullet}(\mathcal{V}_{\mathfrak{i}} \otimes \pi^{*}(\mathcal{O}_{\mathfrak{p}_{2}})) = \operatorname{ev}_{2}^{*} \mathcal{L}_{\mathfrak{i}}$$

where  $\mathcal{L}_i$  is the ith tautological line bundle (4.3.13) on X.

Over  $p_1$ ,  $\pi$  is usually not an isomorphism, which allows room for nontrivial enumerative geometry of rational curves in X. This geometry can be conveniently packaged using degeneration formula.

**8.1.11.** Introduce the operator

$$\mathbf{M}_{\mathcal{L}_{i}} = ev_{*} \left( \widehat{\mathbb{O}}_{vir} z^{deg f} \det H^{\bullet} \left( \mathcal{V}_{i} \otimes \pi^{*}(\mathbb{O}_{p_{1}}) \right) \right) \mathbf{G}^{-1}$$

in which the first factor is defined using the moduli spaces of quasimaps relative to *both* points  $p_1$  and  $p_2$  and the second is the gluing operator. As in Proposition 6.5.30, we see that the operator (8.1.12) is defined in nonlocalized K-theory.

By construction,

$$\mathbf{M}_{\mathcal{L}_{i}} = \mathcal{L}_{i} + \mathcal{O}(z),$$

where  $\mathcal{L}_i$  is viewed as an operator of tensor multiplication.

**8.1.14.** The curve C may be equivariantly degenerated to a union

$$C \leadsto C_1 \cup C_2$$
,  $p_i \in C_i$ 

of two  $\mathbb{P}^{1}$ 's. The degeneration formula for (8.1.5) gives the following formula

(8.1.15) 
$$J(q^{\mathcal{L}_i}z) = \mathbf{M}_{\mathcal{L}_i} J(z) \mathcal{L}_i^{-1}$$

where

$$(q^{\mathcal{L}}z)^d = q^{\left<\mathcal{L},d\right>}z^d \,, \quad d \in H_2(X,\mathbb{Z}) \,, \mathcal{L} \in Pic(X) \,.$$

This immediately extends to the whole Picard group to give the following

### Theorem 8.1.16.

(8.1.17) 
$$J(q^{\mathcal{L}}z) \mathcal{L} = \mathbf{M}_{\mathcal{L}} J(z)$$

From (8.1.9) and (8.1.13), we see that the difference equations

$$\Psi(q^{\mathcal{L}}z) = \mathbf{M}_{\mathcal{L}} \Psi(z)$$

have a regular singularity at z = 0 and that J is the fundamental solution.

**8.1.18.** Recall from Section 7.1.12 that

$$\mathsf{J} \to \begin{cases} 1, & \mathsf{q} \to 0 \\ \mathbf{G}, & \mathsf{q} \to \infty \end{cases}$$

Substituting this into (8.1.17), we obtain the following

**Corollary 8.1.19.** *If*  $\mathcal{L}$  *is ample then* 

(8.1.20) 
$$\mathbf{M}_{\mathcal{L}}(z,q) \to \mathcal{L}, \quad q \to 0,$$

(8.1.21) 
$$\mathbf{M}_{\mathcal{L}}(\mathbf{q}^{-\mathcal{L}}z,\mathbf{q}) \to \mathbf{G}\,\mathcal{L}\,, \quad \mathbf{q} \to \infty\,.$$

### 8.2. Shifts of equivariant variables

- **8.2.1.** Let  $\sigma$  be a cocharacter as in (4.3.2). We will consider  $\sigma$ -twisted quasimaps to X and we fix the equivariant structure so that  $\mathbb{C}_q^{\times}$  acts trivially in the fiber over  $\mathfrak{p}_2$ .
- **8.2.2.** We define the operator

(8.2.3) 
$$J^{\sigma}: K_{\mathsf{T}}(X) \to K_{\mathsf{T} \times \mathbb{C}_{\mathfrak{a}}^{\times}}(X)_{\text{localized}} \otimes \mathbb{Q}[[z]]$$

as in (8.1.7) but for twisted quasimaps. Here  $\mathbb{C}_q^\times$  acts on X via  $\sigma.$ 

**8.2.4.** The operator  $J^{\sigma}$  may be computed by localization with respect to  $\mathbb{C}_{q}^{\times}$ . The localization formula has accordions opening at  $p_{1}$  and an edge term associated to a "constant" map to  $\sigma$ -fixed point x

$$f_{\sigma}: C \to x \in X^{\sigma}$$

as in Section 4.3.12.

The accordion terms are identical to the accordion terms for J, with equivariant variables  $\alpha \in A$  replaced by  $q^{\sigma}\alpha$ , where  $q^{\sigma}=\sigma(q)$ , and therefore

(8.2.5) 
$$J^{\sigma} = J(\alpha q^{\sigma}) E(x, \sigma),$$

where

$$\mathsf{E}(x,\sigma) = \frac{edge \ term \ for \ f_\sigma}{\left(edge \ term \ for \ f_0\right)\big|_{\alpha \mapsto q^\sigma\alpha}} \,.$$

This ration of edge terms may be analyzed as follows.

**8.2.6.** Let  $\mathcal{T}_x$  be the vector bundle over C associated to the action of  $\mathbb{C}_q^{\times}$  on  $T_xX$ . We have

$$T_{vir}(f_{\sigma}) = H^{\bullet}(\mathfrak{T}_{x}) = \frac{T_{x}^{\sigma}}{1 - q^{-1}} + \frac{T_{x}^{0}}{1 - q},$$

where  $T_x^0$  means we take this vector space with a trivial  $\mathbb{C}_q^\times$  action. Therefore

$$(8.2.7) \qquad \qquad \mathsf{T}_{\text{vir}}(\mathsf{f}_\sigma) - \mathsf{T}_{\text{vir}}(\mathsf{f}_0)\big|_{\alpha \mapsto \mathfrak{q}^\sigma \alpha} = \frac{\mathsf{T}_{\mathsf{x}}^0 - \mathsf{T}_{\mathsf{x}}^\sigma}{1 - \alpha} \, .$$

The polarization terms in (6.1.9) give

polarization contribution =  $q^{-\frac{1}{2} \operatorname{deg} \operatorname{det} \mathfrak{T}_x^{1/2}}$ .

for the twisted map and 1 for the untwisted.

**8.2.8.** The entire function

$$(8.2.9) \qquad \qquad (\alpha)_{\infty} = \prod_{i=0}^{\infty} (1 - q^{i}\alpha)$$

is a q-analog of the reciprocal of the  $\Gamma$ -function. We extend it to a map

$$\Phi: \mathsf{K}(\mathsf{X}) \to \mathsf{K}(\mathsf{X}) \otimes \mathbb{Z}[[\mathfrak{q}]]$$

by

$$\Phi(\mathfrak{G}) = \prod (\mathfrak{g}_{\mathfrak{i}})_{\infty} = \Lambda^{\bullet} \left( \mathfrak{G} \otimes \sum_{\mathfrak{i} \geqslant 0} \mathfrak{q}^{\mathfrak{i}} \right)$$

where the product is over Chern roots  $g_i$  of g. Similar  $\Gamma$ -function terms are ubiquitous in quantum cohomology, see for example Chapter 16 in [59] and have been conceptually investigated by Iritani, see e.g. [42]. We have

$$T_{vir} = \frac{g}{1-q^{-1}} \Rightarrow \mathfrak{O}_{vir} = \frac{1}{\Phi(\mathfrak{G}^{\vee})} \,,$$

which, in particular, applies to (8.2.7)

**Exercise 8.2.10.** If  $T_{vir} = H - cH^{\vee}$  where c is a character, then

$$\mathcal{O}_{vir} \otimes \mathcal{K}_{vir}^{1/2} = (-c^{1/2})^{rk} \, {}^{\mathsf{H}} \mathsf{S}^{\bullet} ((1-c^{-1})\mathsf{H}) \, .$$

In particular, if  $T=T^{1/2}+\hbar^{-1}\left(T^{1/2}\right)^{\vee}$  and  $T_{vir}$  is given by (8.2.7) then

$$T_{\rm vir} = H - c H^{\vee}$$
,  $H = \frac{T_{x,0}^{1/2} - T_{x,\sigma}^{1/2}}{1 - q}$ ,  $c = \frac{1}{\hbar q}$ ,

and the rank of H is the degree of the bundle  $\mathfrak{T}_x^{1/2}$  formed by polarizations.

Here we denote by  $T_{x,\sigma}^{1/2}$  the polarization at x with the action of  $\mathbb{C}_q^{\times}$  induced by  $\sigma$ . The same virtual vector space with the trivial  $\mathbb{C}_q^{\times}$ -action is denoted by  $T_{x,0}^{1/2}$ .

**8.2.11.** Including the contributions from  $\mathcal{K}_{vir}^{1/2}$ , the polarization, and  $z^{deg}$ , we obtain the following

Lemma 8.2.12. We have

(8.2.13) 
$$\mathsf{E}(\mathsf{x},\sigma) = (z_{\mathsf{shifted}})^{\langle \boldsymbol{\mu}(\mathsf{x}), -\otimes \sigma \rangle} \Phi\left((1-\mathsf{qh})\left(\mathsf{T}_{\mathsf{x},\sigma}^{1/2} - \mathsf{T}_{\mathsf{x},0}^{1/2}\right)\right),$$

where

$$(8.2.14) z_{\text{shifted}}^d = z^d (-\hbar^{1/2} q)^{-\left\langle \det \mathsf{T}^{1/2}, d \right\rangle}, \quad d \in \mathsf{H}_2(\mathsf{X}, \mathbb{Z}) \, .$$

*Proof.* From Exercise (8.2.10), we compute

$$\mathfrak{O}_{\mathrm{vir}} \otimes \mathfrak{K}_{\mathrm{vir}}^{1/2} = \left(-\frac{1}{\sqrt{\hbar q}}\right)^{\deg \Upsilon_{x}^{1/2}} \; \Phi \left((1-q\hbar) \left(T_{x,\sigma}^{1/2} - T_{x,0}^{1/2}\right)\right).$$

Together with the  $q^{-\deg \mathcal{T}_x^{1/2}/2}$  contribution of the polarization in (6.1.9), the prefactor becomes

$$(-\hbar^{1/2}q)^{-\deg \mathfrak{T}_{x}^{1/2}}$$
.

This is equivalent to shifting the degree variable as in (8.2.14).

**8.2.15.** The shift of the Kähler variables, as in (8.2.14), by an amount proportional to the determinant of the polarization also appears in quantum cohomology, see for example the discussion in Section 1.2.4 of [59].

**8.2.16.** We define an operator

$$\mathsf{E}(\sigma): \mathsf{K}_\mathsf{T}(\mathsf{X}) \to \big(\mathsf{K}_\mathsf{T}(\mathsf{X}) \otimes \mathbb{Q}[\mathfrak{q}]\big)_{\mathsf{localized}} \otimes \mathbb{Q}[z^{\pm 1}]$$

by formula (8.2.13) in  $\sigma$ -fixed points. Note that multiplication by  $\Phi$  is defined without localization, but the degree term is not. Also note that once we go to  $\sigma$ -fixed points, there is no difference between the domain and the source of the map (8.2.3). So, localization gives

$$J^{\sigma} = J(q^{\sigma}a) E(\sigma)$$
.

**8.2.17.** On the other hand, we can argue as in Section 8.1.11 and introduce the following *shift operator* 

(8.2.18) 
$$\mathbf{S}_{\sigma} = \operatorname{ev}_{*} \left( \text{twisted quasimaps, } \widehat{\mathbb{O}}_{\text{vir}} z^{\deg f} \right) \mathbf{G}^{-1}$$

in which the first factor is defined using the moduli spaces of quasimaps relative to *both* points  $p_1$  and  $p_2$ .

Note that in contrast to the operator (8.1.12),  $C_q^{\times}$ -localization is *required* to define the operator (8.2.18). This is because a twisted rational curve in X may run off to infinity even with two fixed marked points<sup>11</sup>.

**8.2.19.** Degeneration formula for  $J^{\sigma}$  gives the following

Theorem 8.2.20.

$$\label{eq:J-def} \mathsf{J}(\mathsf{q}^\sigma\mathfrak{a})\,\mathsf{E}(\sigma) = \mathbf{S}_\sigma\,\mathsf{J}(\mathfrak{a})\,.$$

<sup>&</sup>lt;sup>11</sup>This happens already for  $X = \mathbb{C}$ , twisted rational curves in which are nothing but sections of line bundles on  $\mathbb{P}^1$ .

8.2.22. It is convenient to introduce the following operator

(8.2.23) 
$$J_{\Phi} = J \Phi((1 - q\hbar) T^{1/2} X).$$

It conjugates both the Kahler and equivariant shifts into constant q-difference equations

## Corollary 8.2.24.

$$\begin{aligned} \mathbf{M}_{\mathcal{L}} \; \mathsf{J}_{\Phi}(z) &= \mathsf{J}_{\Phi}(\mathsf{q}^{\mathcal{L}}z) \, \mathcal{L} \; , \\ \mathbf{S}_{\sigma} \, \mathsf{J}_{\Phi}(\mathfrak{a}) &= \mathsf{J}_{\Phi}(\mathsf{q}^{\sigma}\mathfrak{a}) \; (z_{shifted})^{\langle \mu(\,\cdot\,), -\!\!\!-\!\!\!\otimes \sigma \rangle} \; . \end{aligned}$$

Recall that (8.1.13) implies the difference equation in Kähler variables has a regular singularity at z = 0. It follows from the results of [75] that, in fact, it has regular singularities on the whole Kähler moduli space, which is the toric variety associated to the fan of ample cones in  $H^2(X, \mathbb{Z})$ .

Similarly, the difference equations in the equivariant variables  $a \in A$  have regular singularities on a toric compactification of A defined by the fan of the chambers from Section 9.1.2 below. Below in Corollary 10.3.16 we will see an explicit basis in which the operators  $\mathbf{S}_{\sigma}$  are bounded and invertible on the infinities of the torus A.

Note that a similar shift operator may be defined for any cocharacter of the full torus T, but it will lead to a difference equation with irregular singularities.

**8.2.26.** Conjugation to an equation with constant coefficients as in (8.2.25) is as good as a solution of difference equation, and, in some sense, even better as it involves no multivalued functions in z and a. A solution of the constant coefficient equation, which does involve multivalued functions and, specifically, logarithms of Kähler and equivariant variables, can be written as follows.

**8.2.27.** A solution of a constant coefficient matrix difference equation of the form

$$F(qz) = BF(z)$$

is given by  $F(z) = \exp\left(\frac{\ln z}{\ln q} \ln B\right)$ , where the function

$$\log_{\mathfrak{q}} z = \frac{\ln z}{\ln \mathfrak{q}}$$

solves the equation  $\log_q(qz) = 1 + \log_q z$ . Therefore, we need the logarithm of the operator  $\mathcal{L} \otimes$  acting on  $K_T(X)$ . Here the equivariance will be important, which is why we indicate it explicitly.

**8.2.28.** Let R be an integral domain and B :  $R^n \to R^n$  an operator in a free R-module. Even if all eigenvalues  $\{\lambda_i\}$  of B lie in R, most functions f(B) of the operator B, such as projectors on generalized eigenspaces, are only defined after

localization at  $\lambda_i - \lambda_j$ , and so

$$f(B) \in End(R^n) \left[ \frac{1}{\lambda_i - \lambda_i}, f(\lambda_i) \right]$$
,

as illustrated by

$$ln\begin{pmatrix} \alpha & 1 \\ 0 & b \end{pmatrix} = \begin{pmatrix} ln(\alpha) & \frac{ln(\alpha) - ln(b)}{\alpha - b} \\ 0 & ln(b) \end{pmatrix} \,.$$

**8.2.29.** This applies, in particular, to the operator  $B = \mathcal{L} \otimes$  of tensor multiplication by a line bundle in  $K_T(X)$ . Recall from Exercise 2.2.24 that the eigenvalues of this operators are the T-weights of  $\mathcal{L}$  at the different components of  $X^T$ . In particular, for  $f(x) = \ln x$ , we need the logarithm of a weight, which is an element of (Lie T)\*.

We thus can define a map

$$\xi: H^2(X, \mathbb{C}) \otimes \text{Lie } T \to \text{End } K(X^T) \otimes \mathbb{C}$$

which extends the map

$$\mathcal{L} \mapsto \ln(\mathcal{L} \otimes --)$$

by linearity to  $H^2(X,\mathbb{C}) = \operatorname{Pic}(X) \otimes_{\mathbb{Z}} \mathbb{C}$ . This is refinement of the transpose of the map  $\mu$  from (4.3.14) and it coincides with it in the case of isolated T-fixed points.

**8.2.30.** The operator

(8.2.31) 
$$\Xi = \exp \frac{\xi(\ln z_{\text{shifted}}, \ln t)}{\ln q}$$

solves the equations

$$(8.2.32) \hspace{1cm} \Xi(\mathfrak{q}^{\mathcal{L}}z) = \mathcal{L} \otimes \Xi \,, \quad \Xi(\mathfrak{q}^{\sigma}\mathfrak{a}) = (z_{shifted})^{\left\langle \mu(\,\cdot\,\,), -\!\!-\!\!\otimes\sigma\right\rangle} \,\Xi \,.$$

Therefore, we have the following

**Corollary 8.2.33.** The operator  $J_{\Phi}(z) \Xi$  is a solution of the difference equations defined by  $\mathbf{M}_{\mathcal{L}}$  and  $\mathbf{S}_{\sigma}$ .

### 8.3. Difference equations for vertices

**8.3.1.** Exchanging the roles of  $0, \infty \in \mathbb{P}^1$ , we get

$$\left| |\lambda \rangle = \mathsf{J} \left| \lambda \right\rangle ,$$

where

$$\left|\lambda\right\rangle = ev_{p_{1},*}\left(\mathsf{QM}_{nonsing\;p_{1}}\,,\widehat{\mathbb{O}}_{vir}\,z^{deg\;f}\,\lambda\left(\mathcal{V}\big|_{p_{2}}\right)\right)\,,$$

and similarly for the capped vertices.

**8.3.4.** Clearly, equation (8.3.2) can be restated as

$$\left(\mathsf{J}_{\Phi}\,\Xi\right)^{-1}\,\|\lambda\rangle = \Xi^{-1}\,\Phi(\left(\mathsf{q}\hbar-1\right)\mathsf{T}^{1/2}X)\,\left|\lambda\right\rangle\,\text{,}$$

We have the following

**Proposition 8.3.6.** The vector (8.3.5) satisfies a scalar q-difference equation of order rk K(X) in variables z with regular singularity at z = 0 and a scalar q-difference equation with regular singularities in variables  $a \in A$ .

We warm up for the proof with the following sequence of exercises.

**Exercise 8.3.7.** Let  $B(\alpha) \in GL(n, \mathbb{C}(\alpha))$  be a matrix of rational functions of  $\alpha$  and let  $0 \neq \nu(\alpha) \in \mathbb{C}(\alpha)^n$  be a nonzero vector of rational functions. If a covector  $\eta(\alpha)$  solves the equation

(8.3.8) 
$$\eta(q\alpha) = B(\alpha)^{\mathsf{T}} \eta(\alpha)$$

then the function

$$f_n(a) = \langle \eta(a), \nu(a) \rangle$$

solves a difference equation

(8.3.9) 
$$\sum_{i=0}^{d} c_i(\alpha) f(q^i \alpha) = 0, \quad c_i(\alpha) \in \mathbb{C}(\alpha),$$

of order  $d \le n$  which depends on B(a) and v(a), but not on a choice of  $\eta(a)$  solving (8.3.8).

Exercise 8.3.10. In the setting of the previous exercise, consider the C-linear map

$$\begin{cases}
solutions \\
of (8.3.8)
\end{cases} \ni \eta \mapsto f_{\eta} \in \begin{cases}
solutions \\
of (8.3.9)
\end{cases}.$$

Show that if this map has kernel then the difference operator

$$(8.3.12) v(a) \mapsto B(a) v(qa)$$

is reducible, that is, preserves a nontrivial  $\mathbb{C}(\mathfrak{a})$ -linear subspace

$$v(a) \in V \neq \mathbb{C}(a)^n$$
.

In this case, we can choose  $d \leq \dim_{\mathbb{C}(\mathfrak{a})} V$  in (8.3.9) and we can always choose d so that the map (8.3.11) is surjective.

**Exercise 8.3.13.** If d is minimal and (8.3.8) has regular singularities in a then so does (8.3.9).

*Proof.* We first assume that the framing is sufficiently large and the polarization is chosen so that Theorem 7.5.23 applies. In this case,

$$||\lambda\rangle \in K(X)$$

is independent of the Kähler parameters and depends rationally on  $\alpha \in A$  via the identification  $K(X) \otimes_{\mathbb{C}[A]} \mathbb{C}(A) \cong K(X^A) \otimes \mathbb{C}(A)$ . Therefore the claim follows from the above Exercises.

For arbitrary framing, we argue as in Section 7.5.29 by embedding X as

$$X = a$$
 component of  $(X')^{A'}$ ,

where X' is a larger Nakajima variety and the torus A' acts on framing spaces. Using Lemma 7.3.5 we can get the vertices for X from vertices for X'. The operator  $\Xi$  in (8.3.5) makes the solutions associated to different components of  $(X')^{A'}$ grow at different exponential rates at the infinity of A'. Correspondingly, the differential module breaks up into a direct sum over the components of  $(X')^{A'}$  in the limit. 

- The differences between the vertices  $|\lambda\rangle$  and  $\langle\lambda|$  are the following:
  - polarization at  $0, \infty$  contributes differently to the symmetrized virtual structure sheaf in (6.1.9), and
  - exchanging 0 and  $\infty$  sends q to q<sup>-1</sup>.

Therefore

(8.3.15) 
$$\langle \lambda | (z, q) = | \lambda \rangle (zq^{-\det T^{1/2}}, q^{-1}).$$

There is no way to replace q by  $q^{-1}$  in (8.2.9), but the functions 8.3.16.

$$(\alpha; q^{-1})_{\infty} = \prod_{i=0}^{\infty} (1 - q^{-i}\alpha)$$
$$\frac{1}{(q\alpha; q)_{\infty}} = \prod_{i=1}^{\infty} (1 - q^{i}\alpha)^{-1}$$

solve the same difference equation

$$f(qa) = (1 - qa)f(a),$$

reflecting the rational function identity

$$\frac{\alpha}{1-\mathfrak{q}^{-1}} = -\frac{\mathfrak{q}\alpha}{1-\mathfrak{q}}\,.$$

Similarly

$$\frac{q\hbar-1}{1-q}\Big|_{q\mapsto q^{-1}}=\frac{q-\hbar}{1-q}\,,$$
 and therefore, from the point of view of difference equations,

$$\Phi((\mathfrak{q}\mathfrak{h}-1)\,\mathsf{T}^{1/2}\mathsf{X})\Big|_{\mathfrak{q}\mapsto\mathfrak{q}^{-1}}\equiv\Phi((\mathfrak{q}-\mathfrak{h})\,\mathsf{T}^{1/2}\mathsf{X})\,.$$

Substitution 8.3.15 takes 8.3.17.

$$z_{\text{shifted}} \mapsto z_{\#} = z \left(-\hbar^{1/2}\right)^{-\det \mathsf{T}^{1/2}}$$

Putting it all together, we obtain the following

**Theorem 8.3.18.** *The vector* 

(8.3.19) 
$$\widetilde{\text{Vertex}}(\lambda, \mathsf{T}^{1/2}) = \langle \lambda | \ \Phi((\mathsf{q} - \hbar) \ \mathsf{T}^{1/2} \mathsf{X}) \ \exp \frac{\xi(\ln z_\#, \ln t)}{\ln \mathsf{q}}$$

satisfies a scalar q-difference equation of order rk K(X) in variables z with regular singularity at z = 0 and a scalar q-difference equation with regular singularities in variables  $\alpha \in A.$ 

Formally speaking, the function  $\Phi((q - \hbar) T^{1/2}X)$  may have a pole in the denominator if the T-fixed points are not isolated. To fix this, it may be replaced by any solution of the same difference equation, we can replace the polarization  $T^{1/2}X$  by its normal directions to  $X^T$ . It is however, better, to interpret the whole thing as a section of a certain line bundle on the spectrum of  $K_T(X) \otimes \mathbb{C}$ , see [1].

**8.3.20.** As written, the function (8.3.19) and the difference equations that it solves depends on the choice of polarization  $\mathsf{T}^{1/2}$ . However, as we will check presently, a difference choice of polarization affects the difference equations via a shift of the variable z only.

Indeed, any other polarization may we written as  $T^{1/2} + 9 - \hbar^{-1} 9^{\vee}$  for some  $9 \in K(X)$  and we have the following

### Exercise 8.3.21. Show that

(8.3.22) 
$$\widetilde{\text{Vertex}}(\lambda, \mathsf{T}^{1/2} + \mathcal{G} - \hbar^{-1}\mathcal{G}^{\vee}) =$$

$$\widetilde{\mathsf{Vertex}}(\lambda,\mathsf{T}^{1/2})\Big|_{z\mapsto z\,q^{-\det \S}}\Phi((q-\hbar)(\mathfrak{G}-\hbar^{-1}\mathfrak{G}^{\vee}))\,\exp\frac{\xi\left(\ln\left(\frac{q}{h}\right)^{\det \S},\ln t\right)}{\ln q}\,.$$

Exercise 8.3.23. Show that

$$(8.3.24) \qquad \Phi((q-\hbar)(\mathcal{G}-\hbar^{-1}\mathcal{G}^{\vee})) \, \exp\frac{\xi\left(\ln\left(\frac{q}{h}\right)^{\det\mathcal{G}}, \ln t\right)}{\ln q}$$

is invariant under q-shifts of variables in A. The  $\Phi$ -term here is a ratio of theta functions because

$$\Phi((q-h)(\alpha-1/\alpha/h)) = \frac{q^{1/2}}{\hbar^{1/2}} \frac{\vartheta(q\alpha)}{\vartheta(\hbar\alpha)},$$

where

$$\vartheta(x)=(x^{1/2}-x^{-1/2})(qx)_{\infty}(q/x)_{\infty}$$

is the odd theta function.

## 9. Stable envelopes and quantum groups

### 9.1. K-theoretic stable envelopes

- **9.1.1.** At the heart of many computations done in these notes lies the basic principle outlined in Section 2.4. To use it effectively, it is very convenient to have a supply of equivariant K-classes which have both
  - small support (to help with properness), and
  - small weights of their restriction to fixed points.

Obviously, there is a tension between these two desirable features as exemplified, on the one hand, by the structure sheaf  $\mathcal{O}_X$  which has zero weights but is supported everywhere and, on the other hand, by the structure sheaves  $\mathcal{O}_X$  of torus fixed points. Those have minimal possible support, but their weights will exactly match the denominators in the localization formula.

**9.1.2.** A productive middle ground is formed by classes supported on the attracting set of a subtorus

$$A \subset Aut(X, \omega)$$

where  $\omega$  is the holomorphic symplectic form. Let  $\xi \in \text{Lie A}$  be generic and consider

 $Attr_{\xi} = \left\{ x \in X \,\middle|\, \lim_{t \to \infty} e^{-t\,\xi} x \text{ exists} \right\} \,.$  This is a closed set which is a union of locally closed sets

$$Attr_{\xi}(F_{\mathfrak{i}}) = \left\{ x \in X \, \middle| \, \lim_{t \to \infty} e^{-t \, \xi} x \in F_{\mathfrak{i}} \, \right\} \, ,$$

where  $X^A = \bigsqcup F_i$  is the decomposition of the fixed-point set into connected components. The natural embedding

$$Attr_{\xi}(F_{i}) \subset X \times F_{i}$$

is Lagrangian with respect to the form  $\omega_X - \omega_{F_i}$ .

A small variation of  $\xi$  doesn't change the attracting manifolds, they change only if one of the weights of the normal bundle to  $X^A$  in X changes sign on  $\xi$ . These weights partition Lie A into finitely many *chambers*. We denote by  $\mathfrak{C} \ni \xi$  the chamber that contains  $\xi$  and write  $Attr_{\mathfrak{C}}(F_{\mathfrak{t}})$  is what follows, or simply  $Attr(F_{\mathfrak{t}})$ if the choice of a chamber is understood.

#### 9.1.3. Let

$$Attr^f \subset X \times X^A$$

be full attracting set for given & which, by definition, is the smallest closed set that contains the diagonal in  $X^A \times X^A \subset X \times X^A$  and is closed under taking Attr(·). The stable envelope in K-theory

$$Stab \in K(X \times X^{A})$$

will be a certain improved version of  $O_{Attrf}$ , such that

- (1) supp Stab  $\subset$  Attr<sup>f</sup>,
- (2) we will have

$$(9.1.4) Stab = O_{Attr} \otimes line bundle$$

near the diagonal in  $X \times X^A$ , which is a normalization condition,

(3) the weights of the restriction of Stab to off-diagonal components of  $X^A \times$ X<sup>A</sup> will be smaller than what can be expected of a general Lagrangian subvariety and smaller than half of the denominators in the localization formula.

Since A preserves the symplectic form  $\omega$ , the A-weights in the normal bundle to X<sup>A</sup> appear in opposite pairs, and half of denominators above refers to a choice of one from each pair.

We first discuss the normalization, that is, the line bundle in (9.1.4). This 9.1.5. will require a choice of polarization  $T^{1/2}X$ . The eventual formula will make sense for a polarization of any kind, but to start let us assume that we are really given a half  $T^{1/2}X$  of the tangent bundle TX, and thus a half  $N^{1/2}$  of the normal bundle  $N_F$ , near a component F of  $X^A$ .

Since A preserves  $\omega$ , all normal weights to  $X^A$  come in pairs

$$w + h^{-1}w^{-1}$$

which we can now break according to positivity on  $\mathfrak C$  or which of those belongs to  $N^{1/2}$ . We view  ${\mathfrak C}$  as something that will be changing depending on circumstances, whereas the polarization is a choice that we are free to make and keep. The idea is thus to make Stab to be more like  $\Lambda_{-}^{\bullet}(N^{1/2})^{\vee}$  and less like  $\mathfrak{O}_{Attr}$ .

The prescription for doing this is illustrated in the following table, where we assumed that weight w appears in  $N^{1/2}$  but may be attracting or repelling

$$\begin{array}{c|ccccccccccccccccccccccccccccccccccc$$

The general formula

$$(9.1.6) \hspace{1cm} \text{Stab} \, \big|_{\mathsf{F} \times \mathsf{F}} = (-1)^{rk} \, N_{>0}^{1/2} \, \left( \frac{\det \mathsf{N}_{<0}}{\det \mathsf{N}^{1/2}} \right)^{1/2} \, \mathfrak{O}_{\mathsf{Attr}}$$

makes sense for an arbitrary polarization.

One can explain this formula also from a different perspective, namely, one would have liked to make a self-dual choice

(9.1.7) Stab 
$$\Big|_{F \times F} \approx \pm \left( \det N_{<0} \right)^{1/2} \, \mathcal{O}_{Attr}$$
,

except there is no reason for this square root to exist. The correction by polarization in (9.1.6) makes the square root well defined.

The third property of stable envelopes in Section 9.1.3 means the following. We would like a condition of the kind

$$\label{eq:continuous} \left. \text{deg}_{A} \, \text{Stab} \, \right|_{F_{2} \times F_{1}} < \left. \text{deg}_{A} \, \text{Stab} \, \right|_{F_{2} \times F_{2}}.$$
 The degree of Laurent polynomial is its Newton polygon

$$deg_{A}\sum f_{\mu}z^{\mu}=Convex\;hull\;(\{\mu,f_{\mu}\neq0\})\subset A^{\wedge}\otimes_{\mathbb{Z}}\mathbb{Q}\,,$$

considered up to translation. The up-to-translation ambiguity corresponds to multiplication by invertible functions  $z^{\nu}$ ,  $\nu \in A^{\wedge}$ . The natural partial ordering on Newton polygons is inclusion, again up to translation. This is compatible with multiplication in  $\mathbb{C}[A]$ .

The translation ambiguity for inclusion of Newton polygons leads to an additional degree of freedom  $\mathcal{L}$ , called *slope*, in the following definition.

Let  $\mathcal{L}$  be an equivariant line bundle on X. Its restriction  $\mathcal{L}|_F$  has a well-defined equivariant weight, already discussed in Section 4.3.12. A fractional line bundle

$$\mathcal{L} \in \operatorname{Pic}_{\Delta}(X) \otimes_{\mathbb{Z}} \mathbb{Q}$$

has a well-defined fractional weight at all fixed points.

We fix a sufficiently general fractional line bundle  $\mathcal L$  and require that

$$(9.1.10) \qquad \qquad \deg_{\mathsf{A}}\operatorname{Stab}_{\mathcal{L}}\Big|_{\mathsf{F}_2\times\mathsf{F}_1}\otimes\mathcal{L}\Big|_{\mathsf{F}_1} \;\subset\; \deg_{\mathsf{A}}\operatorname{Stab}\Big|_{\mathsf{F}_2\times\mathsf{F}_2}\otimes\mathcal{L}\Big|_{\mathsf{F}_2}\,.$$

Observe that (9.1.10) is independent on the A-linearization of  $\mathcal{L}$ .

Also observe the inclusion in (9.1.10) is necessarily strict, because it is an inclusion of a fractional shift of an integral polygon inside an integral polygon.

**9.1.11.** It is easy to see the K-theory class Stab satisfying the three conditions of Section 9.1.3, made precise in equations (9.1.6) and (9.1.10), is unique if it exists, see below. Existence of stable envelopes for Nakajima varieties is a nontrivial geometric fact, see [60] and also [1].

**Exercise 9.1.12.** Show that stable envelopes corresponding to different polarizations are related by a shift of slope.

**9.1.13.** Let X be a hypertoric variety, that is, an algebraic symplectic reduction of the form

$$X = T^*\mathbb{C}^n /\!\!/ \text{Torus}$$
.

We may assume that

Torus 
$$\cong$$
 diag $(s_1, \ldots, s_k) \in GL(k)$ 

acts on  $\mathbb{C}^n=\mathbb{C}^k\oplus\mathbb{C}^{n-k}$  via the defining representation on  $\mathbb{C}^k$  and with some weights on the remaining coordinates. The action of

$$A = diag(\alpha_{k+1}, \dots, \alpha_n) \in GL(n-k)$$

descends to X. The point

$$x = T^*\mathbb{C}^k /\!\!/ Torus \in X$$

is fixed by A.

To compute Stab(x) we may assume that

- the weights a<sub>i</sub> are attracting,
- the polarization is given by the cotangent directions, that is,

$$T^{1/2} = T^*C^n - \hbar^{-1}$$
 Lie Torus.

Indeed, if one of the weights  $a_i$  is repelling, we can replace it in the module  $\mathbb{C}^{n-k}$  by the corresponding cotangent direction. Using Exercise 9.1.12, we can do the same with polarization.

Let  $w_{k+1},...,w_n$  denote the coordinates in cotangent directions of  $T^*\mathbb{C}^{n-k}$ . They descend to section of line bundles on X and define divisors  $w_i = 0$  on X. **Exercise 9.1.14.** Show that the structure sheaf Owk`1"¨¨¨"wn"<sup>0</sup> is the stable envelope of x for L " 0.

**Exercise 9.1.15.** Show that StabLpxq for any other slope is given by a twist of Owk`1"¨¨¨"wn"<sup>0</sup> by an integral line bundle.

**9.1.16.** A typical computation with stable envelopes proceeds as follows. One uses the support condition to argue the result in a Laurent polynomial in a P A. One then computes this polynomial by taking the a Ñ 8 asymptotics in localization formula. The strict inclusion in (9.1.10) often implies that the contribution of many fixed points may be discarded.

## **Exercise 9.1.17.** Show that

$$(9.1.18) \hspace{1cm} Stab_{-\mathfrak{C},\,\mathsf{T}_{\mathsf{opp}}^{\mathsf{transp}},\,-\mathcal{L}}^{\mathsf{1/2}} \circ Stab_{\mathfrak{C},\,\mathsf{T}^{1/2},\,\mathcal{L}} = \mathfrak{O}_{\mathsf{diag}\,\mathsf{X}^\mathsf{A}}\,,$$

where

$$Stab^{transp} \in K(X^{A} \times X)$$

is the transposed correspondence. It follows that the composition of the other order is also the identity

$$(9.1.19) \hspace{1cm} Stab_{\mathfrak{C}, \, \mathsf{T}^{1/2}, \, \mathcal{L}} \circ Stab^{transp}_{-\mathfrak{C}, \, \mathsf{T}^{1/2}_{opp}, \, -\mathcal{L}} = \mathfrak{O}_{diag \, X} \, .$$

This gives a decomposition of the diagonal for X if one for X <sup>A</sup> is known.

### **9.2. Triangle lemma and braid relations**

**9.2.1.** Let A <sup>1</sup> <sup>Ă</sup> <sup>A</sup> be a subtorus such that <sup>X</sup> A1 " X <sup>A</sup>, which is satisfied generically. Evidently,

> Stable envelopes for A " Stable envelopes for A 1 ,

where

chambers in Lie A 
$$'=\left(\text{Lie}\,A'\right)\cap\text{chambers}$$
 in Lie A .

In particular, A 1 can be a generic 1-parameter subgroup, and therefore for uniqueness of stable envelopes it is enough, in principle, to consider the case dim A " 1.

**Proposition 9.2.2** ([59])**.** *Stable envelopes are unique.*

*Proof.* Let F<sup>i</sup> be a component of the fixed locus and suppose there are two classes S and S 1 that satisfy the definition of the stable envelope

$$Stab \, \big|_{F_{\mathfrak{i}}} \subset X \times F_{\mathfrak{i}} \, .$$

We write F<sup>j</sup> ă F<sup>i</sup> if the full attracting set of F<sup>i</sup> contains F<sup>j</sup> ; this is a partial order on components of the fixed locus. By the normalization condition,

$$S|_{Attr(F_{\mathfrak{i}})} = S'|_{Attr(F_{\mathfrak{i}})}$$

and hence S ´ S 1 is supported on Ť <sup>j</sup>ă<sup>i</sup> AttrpFjq. Therefore, there exist a maximal F<sup>j</sup> ă F<sup>i</sup> such that

$$(S - S')|_{Attr(F_j)} \neq 0$$
.

The restriction of S - S' to  $F_i$  factors through the map

$$K(Attr^{f}(F_{j})) \xrightarrow{pushforward} K(X)$$

$$\downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow$$

$$K(F_{j}) \xrightarrow{\otimes \Lambda^{\bullet}N^{\vee}_{\leq 0}} K(F_{j}),$$

in which the vertical maps are restrictions. Therefore the Newton polygon of  $S - S'|_{F_j}$  is at least as big as the Newton polygon of  $\operatorname{Stab}_{F_j \times F_j}$ , in contradiction with the degree bound.

**9.2.3.** If dim A = 1 then one can construct stable envelopes inductively with respect to the above partial order on the set of fixed components. This is essentially a version of the Gram-Schmidt process. In fact, instead of (9.1.10) one can require

$$(9.2.4) \hspace{1cm} \text{deg}_{A} \, \text{Stab} \, \Big|_{F_{2} \times F_{1}} \, \subset \, \text{deg}_{A} \, \text{Stab} \, \Big|_{F_{2} \times F_{2}} + \text{shift}_{\, i,j} \, .$$

for generic shifts

shift 
$$i, i \in \mathbb{Q}$$
.

Remarkably, a similar Gram-Schmidt process may be carried out not in K(X), but in the derived category of coherent sheaves on X. This is a special case of the theory developed in [39], where many applications of these techniques can also be found.

In that setting, Stab is a bounded complex of coherent sheaves on  $X \times X^A$  and the degree bound applies to all terms of its derived restriction to  $X^A \times X^A$ , that is, to all groups  $\mathrm{Tor}_k(\mathrm{Stab}, \mathcal{O}_{F_i})$ .

For dim A > 1, in general, it will be impossible to satisfy the condition (9.2.4) with generic shifts. Put it differently, we can still define  $\operatorname{Stab}_{\xi}$  for a 1-parameter subgroup generated by  $\xi$  using (9.2.4). However, as a function of  $\xi$ , these will jump across some new walls in Lie A and these new walls will subdivide our old chambers  $\mathfrak{C}$ .

These is where the importance of shifts by a weight of a line bundle as in (9.1.10) comes in. Lifting (9.1.10) to derived category of coherent sheaves is an active area of current research. It overlaps, among other things, with the study of quantizations, that is, noncommutative deformations of the algebraic symplectic manifold X. A fractional line bundle in that context becomes a parameter of quantization.

**9.2.5.** Now consider a subtorus  $A' \subset A$  such that  $X^{A'} \neq X^A$ , which means that Lie A' lies inside one of the walls in Lie A. A chamber  $\mathfrak{C}_A \subset \text{Lie } A$  determines a pair of chambers

$$\begin{split} \mathfrak{C}_{A'} &= \mathfrak{C}_A \cap Lie\,A' &\in Lie\,A'\,, \\ \mathfrak{C}_{A/A'} &= Image\,\left(\mathfrak{C}_A\right) &\in Lie\,A/A'\,, \end{split}$$

see Figure 9.2.6. Correspondingly, we have a diagram of maps

![](_page_111_Picture_2.jpeg)

FIGURE 9.2.6. A cone  $\mathfrak{C} \subset \text{Lie A}$  induces a cone for each subtorus A' and quotient torus A/A'.

(9.2.7) 
$$K(X^{A}) \xrightarrow{\operatorname{Stab}_{\mathfrak{C}_{A}}} K(X)$$

$$K(X^{A'}) \xrightarrow{\operatorname{Stab}_{\mathfrak{C}_{A'}}} K(X)$$

The shape of this diagram explains why the following statement is known as the *triangle lemma*.

**Proposition 9.2.8.** *The diagram* (9.2.7) *commutes.* 

*Proof.* Consider the composition

$$(9.2.9) Stab_{\mathfrak{C}_{A'}} \circ Stab_{\mathfrak{C}_{A/A'}} \subset X \times X^{A}.$$

It clearly satisfies the support and the normalization conditions, and so it is the degree condition (9.1.10) that needs to be checked. Further, by uniqueness of stable envelopes, it is enough to check the degree condition for a generic 1-parameter subgroup with generator

$$\xi = \xi' + \delta \xi$$
,  $\xi' \in \mathfrak{C}_{A'}$ ,  $\delta \xi \in \mathfrak{C}_{A/A'}$ ,

where  $\xi'$  is generic and the perturbation

(9.2.10) 
$$\|\delta\xi\| \ll \|\xi'\|$$

is small.

In order to check (9.1.10), we need to consider two cases. The first case is when  $F_2$  and  $F_1$  belong to different components of  $X^{A'}$ . In this case, the inequalities (9.1.10) are strict for the stable envelope  $\operatorname{Stab}_{\mathfrak{C}_{A'}}$ . In particular, they are strict for the 1-parameter subgroup generated by  $\xi'$ , and therefore still satisfied for a small perturbation  $\xi$ .

The second case is when  $F_2$  and  $F_1$  belong to the same component of  $X^{A'}$ . In this case,  $\operatorname{Stab}_{\mathfrak{C}_{A'}}$  is multiplication by  $\Lambda^{\bullet}\left(N_{X^{A'},<0}\right)^{\vee}$ , twisted by polarization terms. The corresponding terms cancel from both sides of (9.1.10), as does the A'-weight of the line bundle  $\mathcal{L}$ . The degree bounds thus follows from the degree bounds for  $\operatorname{Stab}_{\mathfrak{C}_{A/A'}}$ .

**9.2.11.** Let two chambers  $\mathfrak{C}_\pm$  share a face, that is, let them be separated by a codimension 1 wall

$$w = \operatorname{Lie} A' \subset \operatorname{Lie} A$$
.

For fixed slope  $\mathcal{L}$ , we define the following *R-matrix* 

$$\begin{array}{ll} \mathsf{R}_{w} = \mathsf{Stab}_{\mathfrak{C}_{-}}^{-1} \, \circ \, \mathsf{Stab}_{\mathfrak{C}_{+}} & \in \mathsf{End} \, \mathsf{K}(\mathsf{X}^{\mathsf{A}})_{localized} \\ \\ = \, \mathsf{Stab}_{w,-}^{-1} \, \circ \, \mathsf{Stab}_{w,+} \, , \end{array}$$

where

$$\operatorname{Stab}_{w,+}: \mathsf{K}(\mathsf{X}^\mathsf{A}) \to \mathsf{K}(\mathsf{X}^\mathsf{A'})$$

are the stable envelopes for the quotient  $A/A' \cong \mathbb{C}^{\times}$ . The equality of two lines in (9.2.12) follows from the triangle lemma. Note from (9.1.18) that the inverse of a stable envelope is the transpose of another stable envelope.

From (9.2.12) we observe:

- the operator  $R_w$  depends only on  $X^A \hookrightarrow X^{A'}$  and, in particular,
- as a function of equivariant parameters in A, it factors through A/A'.
- **9.2.13.** Let  $w_1, w_2,...$  be the walls intersecting in a given codimension 2 subspace of Lie A. We may put them in the natural cyclic ordering as in Figure 9.2.14 and then we have the following obvious

![](_page_112_Picture_13.jpeg)

FIGURE 9.2.14. Product of wall R-matrices around a codimension 2 subspace is the identity

## Proposition 9.2.15.

$$(9.2.16) \qquad \qquad \stackrel{\leftarrow}{\prod} R_{w_i} = 1.$$

In other words, R-matrices satisfy relations of the *fundamental groupoid* of the complement of the walls in Lie A.

**9.2.17.** Fix a quiver, a framing vector w and define

$$X(w) = \bigsqcup_{v} Nakajima \ variety(v,w)$$

where  $v = (\dim V_i)$  is the vector of ranks of tautological vector bundles and some choice of the stability parameter is understood. Let

$$\mathsf{A} = \{(\mathfrak{a}_1, \mathfrak{a}_2, \mathfrak{a}_3)\} \cong (\mathbb{C}^{\times})^3$$

act on the framing spaces and hence on X so that

$$w = \sum \alpha_{\mathfrak{i}} \otimes w^{(\mathfrak{i})}$$

is the equivariant dimension vector.

**Exercise 9.2.18.** Describe  $X^A$ , the walls in Lie A, and the corresponding fixed loci.

**Exercise 9.2.19.** Show that the braid relation (9.2.16) becomes the following equation

$$(9.2.20) \qquad R_{12}(\alpha_1/\alpha_2)R_{13}(\alpha_1/\alpha_3)R_{23}(\alpha_2/\alpha_3) = R_{23}(\alpha_2/\alpha_3)R_{13}(\alpha_1/\alpha_3)R_{12}(\alpha_1/\alpha_2)$$

known as the Yang-Baxter equation with spectral parameter. This is an equation for operators

$$R_{ij}(\alpha_i/\alpha_j) \in \text{End} \ K(X(w^{(i)})) \otimes K(X(w^{(j)}))_{localized}$$

acting in the respective factors of

$$K(X(w^{(1)})) \otimes K(X(w^{(2)})) \otimes K(X(w^{(3)}))_{localized} .$$

Exercise 9.2.21. Show the following property

(9.2.22) 
$$R_{12}(\alpha_1/\alpha_2) R_{21}(\alpha_2/\alpha_1) = 1,$$

known as the unitarity of R-matrices.

9.2.23. In particular, take

$$(9.2.24) X = X(2) = pt \sqcup T^*\mathbb{P}^1 \sqcup pt$$

for the quiver with one vertex and no loops. Stable envelopes for  $T^*\mathbb{P}^1$  are a special case of the computation from Exercise 9.1.14, with the following result.

$$A = diag(a_1, a_2) \subset GL(2)$$

act on  $\mathbb{P}^1 = \mathbb{P}(\mathbb{C}^2)$  in the natural way. In particular, it acts with weights  $a_i$  on the fibers of  $\mathcal{O}(-1)$  over the fixed point  $p_i \in X$ .

Exercise 9.2.25. Choose the parameters of stable envelopes as follows:

- the polarization  $T^{1/2}$  is given by cotangent directions,
- the slope is  $\mathcal{L} = \mathcal{O}(-\varepsilon)$ , where  $0 < \varepsilon < 1$ ,
- the chamber  $\mathfrak{C}$  is such that  $a_1/a_2 \to 0$ .

Then

Let

$$\operatorname{Stab}_{\mathfrak{G}}(\mathfrak{p}_{1}) = (1 - \mathfrak{a}_{2}\mathfrak{O}(1))\,\hbar^{1/2}$$
,  $\operatorname{Stab}_{\mathfrak{G}}(\mathfrak{p}_{2}) = 1 - \hbar\mathfrak{a}_{1}\mathfrak{O}(1)$ ,

while

$$Stab_{-\mathfrak{C}}(p_1) = 1 - \hbar\alpha_2\mathfrak{O}(1)\,, \quad Stab_{-\mathfrak{C}}(p_2) = (1 - \alpha_1\mathfrak{O}(1))\,\hbar^{1/2}\,,$$

is obtained by permuting the roles of  $p_1$  and  $p_2$ .

**Exercise 9.2.26.** Check that the computation of the R-matrix in the previous example gives

$$R_{T^*\mathbb{P}^1}(u) = \operatorname{Stab}_{-\mathfrak{C}}^{-1} \circ \operatorname{Stab}_{-\mathfrak{C}} = \begin{pmatrix} \hbar^{1/2} \, \frac{1-u}{\hbar-u} & u \, \frac{1-h}{u-h} \\ \\ \frac{1-h}{u-h} & \hbar^{1/2} \, \frac{1-u}{h-u} \end{pmatrix}$$

where  $u = a_1/a_2$ . Together with the trivial blocks

$$R_{X(2)} = \begin{pmatrix} 1 & & \\ & R_{T*\mathbb{P}^1} & \\ & & 1 \end{pmatrix}$$

for the points in (9.2.24), this equates the R-matrix for X(2) with the standard R-matrix for  $\mathcal{U}_h(\widehat{\mathfrak{gl}}(2))$ , see [21,27].

## 9.3. Actions of quantum group

**9.3.1.** Let  $\{F_i\}$  be a collection of vector spaces (or free modules over some more general rings) and

$$(9.3.2) R_{F_i,F_i}(\mathfrak{u}) \in End(F_i \otimes F_j) \otimes \mathbb{C}(\mathfrak{u})$$

a collection of invertible operators satisfying the Yang-Baxter equation (9.2.20). From this data, one can make a certain  $Hopf algebra \mathcal{U}$  act on modules of the form

$$(9.3.3) F_{i_1}(a_1) \otimes \cdots \otimes F_{i_n}(a_n)$$

where  $F_i(a)$  is a shorthand for  $F_i \otimes \mathbb{C}[a^{\pm 1}]$  and the order of factors in (9.3.3) is important.

The variables  $\alpha_i$  here are simply new indeterminates, unrelated to the structure of the algebra  $\mathcal U$ . The action of  $\mathcal U$  in (9.3.3) is linear over functions of  $\alpha_i$ . One should think of  $\alpha_i$  as points of  $\mathbb C^\times$  at which the modules  $F_i$  are inserted, and think of  $\mathcal U$  as a deformation of a gauge Lie algebra

$$\mathcal{U} \approx \text{Univ. enveloping} \left( \text{Maps}(\mathbb{C}^{\times} \to \mathfrak{g}) \right)$$
,

where each F<sub>i</sub> is a module over the Lie algebra g.

**9.3.4.** The definition of a Hopf algebra includes a coproduct, that is a coassociative homomorphism of algebras

$$\Delta: \mathcal{U} \mapsto \mathcal{U} \otimes \mathcal{U}$$
.

A coproduct makes modules over  $\mathcal{U}$  a tensor category. Familiar examples are a group algebra  $\mathbb{C}G$  of a group G or the universal enveloping algebra of a Lie algebra G. A group acts in tensor products via the diagonal homomorphism, meaning

$$\Delta: \mathbb{C}G \ni \mathfrak{q} \mapsto \mathfrak{q} \otimes \mathfrak{q} \in \mathbb{C}G \otimes \mathbb{C}G$$
,

which by Leibniz rule gives

$$\Delta(\xi) = \xi \otimes 1 + 1 \otimes \xi \quad \xi \in \text{Lie } G.$$

In categories related to motives, in which

b " Cartesian product of varieties ,

tensor product is similarly commutative.

By contrast, the coproduct for U will not be cocommutative, meaning that

$$\Delta^{\mathrm{opp}}=(12)\circ\Delta\neq\Delta$$
,

and so the order of factors in the tensor product will be important.

**9.3.5.** The coproduct will be not entirely noncommutative: after localization in a, tensor products in either order become isomorphic, that is

$$F_1(\alpha_1) \otimes F_2(\alpha_2) \otimes \mathbb{C}(\alpha_1/\alpha_2) \cong F_2(\alpha_2) \otimes F_1(\alpha_1) \otimes \mathbb{C}(\alpha_1/\alpha_2)$$

as U modules. In fact, the isomorphism is given by

$$(9.3.6) \hspace{3.1em} R_{F_1(\alpha_1),F_2(\alpha_2)}^{\vee} = (12) \circ R_{F_1,F_2}(\alpha_1/\alpha_2) \, .$$

The same formula will work for general modules of the form (9.3.3), if we extend the definition of R-matrices as follows

$$R_{F_1(\alpha_1),F_2(\alpha_2)\otimes F_3(\alpha_3)} = R_{F_1(\alpha_1),F_3(\alpha_3)} R_{F_1(\alpha_1),F_2(\alpha_2)}$$

and so on, see Figure 9.3.7 which illustrates the order in which the R-matrices should be multiplied.

![](_page_115_Picture_17.jpeg)

Figure 9.3.7. To write an R-matrix for two modules of the form (9.3.3), one multiplies R-matrices for factors in the order of crossings in the above diagram. Here, we get R<sup>18</sup> ¨ ¨ ¨ R24R35R34, where R<sup>24</sup> and R<sup>35</sup> can be places in arbitrary order.

**Exercise 9.3.8.** Prove that so defined R-matrices satisfy the same braid relations of the form

$$R_{12}R_{13}R_{23} = R_{23}R_{13}R_{12},$$

and the Yang-Baxter equation

$$R_{12}(u_1/u_2)R_{13}(u_1/u_3)R_{23}(u_2/u_3) = R_{23}(u_2/u_3)R_{13}(u_1/u_3)R_{12}(u_1/u_2)$$

if we make u P Autp**C** <sup>ˆ</sup><sup>q</sup> act on modules (9.3.3) by shifting all variables <sup>a</sup><sup>i</sup> ÞÑ ua<sup>i</sup> .

**9.3.9.** Let **F** be a module of the form (9.3.3). The algebra U may be defined in a very down-to-earth way as the subalgebra

$$(9.3.10) \mathcal{U} \subset \prod_{\mathbf{F}} \text{End}(\mathbf{F})$$

generated by matrix elements of

$$R_{F,F_i(u)} \in End(F) \otimes End(F_i) \otimes \mathbb{C}(u)$$

in the auxiliary space F<sup>i</sup> for all i. Such matrix element is a rational function of u with values in Endp**F**q and we add to U the coefficients of the expansion of this rational function as both u Ñ 0 and u Ñ 8. As the degrees of these rational functions are unbounded, there is no universal relations between these coefficients.

The natural projection

$$\prod_F \text{End}(F) \mapsto \prod_{F_1, F_2} \text{End}(F_1 \otimes F_2)$$

restricts to a map

$$\Delta: \mathcal{U} \mapsto \mathcal{U} \widehat{\otimes} \mathcal{U}$$

where the completion is required if the auxiliary spaces are infinite-dimensional, see the discussion in Section 5 of [59]. It is clear that ∆ is a coassociative coproduct.

**Exercise 9.3.11.** Show that (9.3.6) intertwines U action.

Geometrically defined R-matrices have an additional parameter, namely the slope. It can be shown [75] that the resulting algebra U does not depend on the slope. However, the ability to vary the slope is of significant help in analysis of the structure of U.

**9.3.12.** Among **F** in (9.3.10) we include the trivial representation **C** such that R**C**,<sup>F</sup> " 1 for any F.

**Exercise 9.3.13.** Show that the induced map U Ñ **C** is a counit for ∆.

**9.3.14.** In addition to a coproduct, a Hopf algebra has an anti-automorphism

$$S:\mathcal{U}\to\mathcal{U}$$

called the *antipode*, see [21, 27]. It satisfies

$$(9.3.15) m \circ (1 \otimes S) \circ \Delta = m \circ (S \otimes 1) \circ \Delta = \text{unit} \circ \text{counit}$$

where m : U b U Ñ U is the multiplication.

In applications, S is invertible, even though invertibility of the antipode is not a part of the standard axioms. For the category of modules, the existence of the antipode means existence of *dual* modules.

For noncommutative  $\otimes$ , one has to distinguish between the *left* duals, with canonical maps

$$(9.3.16) F^* \otimes F \to \mathbb{C}, \quad \mathbb{C} \to F \otimes F^*,$$

and and the *right* duals, in which the order of tensor factors in (9.3.16) is reversed.

## Exercise 9.3.17. Show that the assignment

$$\mathcal{U} \ni \mathbf{x} \mapsto \mathbf{S}(\mathbf{x})^* \in \mathrm{End}(\mathsf{F}^*)$$
,

where start denotes the transpose operator, makes vector space dual  $F^*$  into a left-dual module for a Hopf algebra  $\mathcal{U}$ . Show that the inverse of S is needed to make it a right-dual module.

**9.3.18.** Following [78], one can extend the collection (9.3.2) to dual spaces  $F_i^*$  by the following rules

(9.3.19) 
$$R_{F_{1}^{*},F_{2}} = \left(R_{F_{1},F_{2}}^{-1}\right)^{*1}$$

$$R_{F_{1},F_{2}^{*}} = \left(R_{F_{1},F_{2}}^{*2}\right)^{-1}$$

$$R_{F_{1}^{*},F_{2}^{*}} = \left(R_{F_{1},F_{2}}\right)^{*12},$$

where \*1 means taking the transpose with respect to the first tensor factor, etc.

Exercise 9.3.20. Show that the matrices (9.3.19) satisfy Yang-Baxter equations.

We can thus assume that the set F in (9.3.10) is closed under duals and define

$$S: \mathcal{U} \to \widehat{\mathcal{U}}$$

as the restriction of

$$\operatorname{End}(\mathbf{F}) \xrightarrow{\quad * \quad} \operatorname{End}(\mathbf{F}^*).$$

**Exercise 9.3.21.** Show this map satisfies the antipode axiom and that  $F^*$  is the left-dual module for  $\mathcal{U}$ .

### 10. Quantum Knizhnik-Zamolodchikov equations

## 10.1. Commuting difference operators from R-matrices

## **10.1.1.** Consider the group

$$\overline{W} = S(n) \ltimes \mathbb{Z}^n \subset Aut(\mathbb{Z}^n)$$

generated by shifts and permutation of the coordinates. It contains the affine Weyl group

$$W_{\mathsf{aff}} \subset \overline{W}$$

of type  $A_{n-1}$  generated by S(n) and the reflection

$$s_0 \cdot (x_1, \ldots, x_n) = (x_n + 1, x_2, \ldots, x_1 - 1)$$

in the affine root

$$x_1 - x_n = 1.$$

Together with the simple positive roots of  $A_{n-1}$ , it delimits the fundamental alcove

$$(10.1.2) \cdots \geqslant x_n + 1 \geqslant x_1 \geqslant x_2 \geqslant \cdots \geqslant x_n \geqslant x_1 - 1 \geqslant \cdots$$

This stabilizer of (10.1.2) in  $\overline{W}$  is generated by the transformation

$$\pi \cdot (x_1, \ldots, x_n) = (x_n + 1, x_1, \ldots, x_{n-1})$$

that shifts all entries in (10.1.2) by one. Projected along the  $(1,1,\ldots,1)$ -direction, this becomes the order n outer symmetry of the Dynkin diagram of  $\hat{A}_{n-1}$ . The group  $\overline{W}$  is generated by  $W_{\text{aff}}$  and  $\pi$  with the relations

(10.1.3) 
$$\pi s_i = s_{i+1}\pi, \quad i \in \mathbb{Z}/n.$$

In particular, we have the following expression for the shifts of the coordinates

$$(10.1.4) (1,0,\ldots,0) = \pi s_{n-1}\ldots s_2 s_1,$$

(10.1.5) 
$$(0,1,\ldots,0) = s_1\pi s_{n-1}\ldots s_2$$
, etc.

**10.1.6.** Let  $F_i$  be as in Section 9.3 and define

$$P = \bigoplus_{w \in S(n)} F_{w(1)}(a_{w(1)}) \otimes \cdots \otimes F_{w(n)}(a_{w(n)}).$$

Consider the U-intertwiners in P as in (9.3.6)

(10.1.7) 
$$s_{k} = R_{k}^{\vee}$$
$$= (k, k+1) R_{F_{w(k)}, F_{w(k+1)}} (a_{w(k)} / a_{w(k+1)})$$

where (k, k + 1) permutes the kth and (k + 1)st factors.

**Exercise 10.1.8.** Deduce from (9.2.22) that the operators (10.1.7) form a representation of the symmetric group.

Let

$$G: F_i(\alpha) \to F_i(\alpha)$$

be an invertible operator such that

$$[G \otimes G, R] = 0.$$

Define

$$\pi = G_1(1,2,3,4...n)$$

where  $G_1$  means it acts in the first tensor factor.

**Exercise 10.1.10.** Check this operator satisfies relations (10.1.3).

By analogy with (10.1.2), one can think of infinite quasi-periodic tensors of the form

$$\cdots \otimes \mathsf{Gf}_n(\mathfrak{a}_n) \otimes \mathsf{f}_1(\mathfrak{a}_1) \otimes \mathsf{f}_2(\mathfrak{a}_2) \otimes \cdots \otimes \mathsf{f}_n(\mathfrak{a}_n) \otimes \mathsf{G}^{-1} \mathsf{f}_1(\mathfrak{a}_1) \otimes \mathsf{G}^{-1} \mathsf{f}_2(\mathfrak{a}_2) \otimes \cdots.$$

The operator  $\pi$  shifts this infinite tensor by one step. This operation occurs naturally in the study of spin chains with quasi-periodic boundary condition.

It follows that we get a representation of the group  $S(n) \ltimes \mathbb{Z}^n$  and, in particular, n commuting operators of the form

(10.1.11) 
$$(10.1.4) = G_1 R_{1,n} \dots R_{12},$$
 
$$(10.1.5) = R_{2,1} G_2 R_{2,n} \dots R_{23}, \text{ etc.}$$

**10.1.12.** There are two ways to obtain an operator G satisfying (10.1.9). The first is to take an element of  $\mathcal{U}$  which is primitive, that is, satisfies

$$\Delta(G) = G \otimes G$$
.

Quantum affine algebras have very few primitive elements. For Nakajima varieties the only nontrivial choice is an exponentials of linear functions of v, which can be written as  $z^v$  in multiindex notation.

The other option is to introduce a shift operator,

$$\tau_{\alpha,q} f(\alpha) = f(q\alpha)$$

which satisfies (10.1.9) because the R-matrix depends only on the ratio  $a_1/a_2$  of evaluation parameters. Combining  $z^{v}$  with a shift operator in the form

$$Gf(\alpha) = z^{V} f(q^{-1}\alpha),$$

we get an action of  $\mathbb{Z}^n$  by commuting difference operators.

The corresponding difference equations were introduced in [32] and are known as the quantum Knizhnik-Zamolodchikov equations. In the  $q \to 1$  limit, they become the Knizhnik-Zamolodchikov differential equations for conformal blocks of WZW conformal field theories. See the book [26] for an introduction.

## 10.2. Minuscule shifts and qKZ

**10.2.1.** We will identify the shifts of equivariant variable from Section 8.2 with qKZ operators in the case when the cocharacter  $\sigma$  is *minuscule*. The parameters in the primitive element  $z^{v}$  will be identified, up to a shift, with Kähler variables.

Being minuscule is an important technical notion, and one of the equivalent ways to define a minuscule cocharacter is the following. Let  $X_0$  be the affinization of X, that is, the spectrum of global functions on X. The ring  $\mathbb{C}[X_0] = H^0(\mathfrak{O}_X)$  is  $\mathbb{Z}$ -graded by the characters of A and one can look for generators of minimal degree with respect to  $\sigma$ . By definition,  $\sigma$  is minuscule if  $\mathbb{C}[X_0]$  is generated by elements of degree  $\{\pm 1, 0\}$  with respect to  $\sigma$ .

For Nakajima varieties,  $\mathbb{C}[X_0]$  is generated by invariant functions on the prequotient, and the first fundamental theorem of invariant theory provides a set of generators for it. It is shown in Section 2.6 of [59] that actions

$$\sigma: \mathbb{C}^{\times} \to \prod \mathsf{GL}(W_{\mathfrak{i}})$$

with the character

$$w = aw' + w''$$
,  $a \in \mathbb{C}^{\times}$ 

are minuscule.

Exercise 10.2.2. Check this.

**Exercise 10.2.3.** Prove that the weights of a minuscule cocharacter  $\sigma$  in the normal bundle to  $X^{\sigma}$  are  $\pm 1$ .

**10.2.4.** It is clear that the cocharacter  $\sigma$  has to be very special for the shift operator to have the qKZ form. Indeed, the constructions of Section 8 produce difference operators as a formal series in z. For the shifts of Kähler variables it is shown in [75], as a consequence of commutation with qKZ, that the corresponding series converges to a rational function of z, up to an overall scalar.

By contrast, the qKZ operator are polynomial in z and, in fact, they involve the variables z only through the diagonal operator  $z^{v}$  acting in one of the tensor factors. The possibility to factor out the entire degree dependence in such a strong way is very special and is destroyed, for example, if we replace a difference operator by its square. Of course,  $\sigma^{2}$  is never minuscule for  $\sigma \neq 1$ .

**10.2.5.** Let  $\sigma$  be a minuscule cocharacter and let  $X^{\sigma}$  be the fixed locus on the corresponding 1-parameter subgroup. The identification of geometric structures with structures from quantum groups happens in the basis of stable envelopes and, in particular, the shift operator  $\mathbf{S}_{\sigma}$  will be identified with qKZ after conjugation by

$$(10.2.6) \hspace{1cm} \mathsf{Stab}_{+,\mathsf{T}^{1/2},\mathcal{L}} : \mathsf{K}_\mathsf{T}(\mathsf{X}^\sigma) \to \mathsf{K}_\mathsf{T}(\mathsf{X})$$

where plus means σ-attracting directions and

(10.2.7) 
$$\mathcal{L} \in \{\text{neighborhood of } 0\} \cap (-C_{\text{ample}}) \subset \text{Pic}(X) \otimes \mathbb{R} .$$

We will see the importance of this particular choice of the slope  $\mathcal{L}$  later.

**10.2.8.** The conjugation of the shift operator to qKZ is summarized in the following diagram:

$$(10.2.9) \qquad K_{\mathsf{T}}(X^{\sigma}) \xrightarrow{\tau_{\sigma}^{-1}(-1)^{\operatorname{codim}/2}z^{\operatorname{deg}}\,\mathsf{R}} K_{\mathsf{T}}(X^{\sigma})_{\operatorname{localized}}$$

$$\downarrow \mathsf{Res} \circ \operatorname{Stab}_{+} \qquad \qquad \downarrow \mathsf{Res} \circ \operatorname{Stab}_{+}$$

$$\downarrow \mathsf{K}_{\mathsf{T}}(X^{\sigma}) \xrightarrow{\tau_{\sigma}^{-1}\,\mathsf{S}_{\sigma}} \mathsf{K}_{\mathsf{T}}(X^{\sigma})_{\operatorname{localized}}$$

where  $Stab_{+}$  is the operator (10.2.6), followed by the restriction Res to fixed points,  $R = Stab_{-}^{-1} Stab_{+}$  is the R-matrix, and

$$\tau_{\sigma} f(\alpha) = f(q^{\sigma} \alpha)$$
.

Recall that the operators that shift equivariant variables are only defined after localization. In particular, to define the shift  $\tau_{\sigma}$  we need to trivialize  $K_{T}(X)$  as a  $K_{C_{\infty}^{\times}}(pt)$ -module. This is achieved by restriction to  $K_{T}(X^{\sigma})$ .

In what follows, we will often drop the restriction to fixed points for brevity. To simplify notation, we will also denote by a the coordinate in the image of  $\sigma$  so that

$$\tau_{\sigma}f(\alpha) = f(\alpha)$$
.

**10.2.10.** The inverse of the stable envelope may be replaced, as in Exercise 9.1.17, by the transposed correspondence with the opposite polarization, cone, and slope. Therefore, the diagram (10.2.9) is equivalent to the following

**Theorem 10.2.11.** *If*  $\sigma$  *is a minuscule cocharacter then* 

$$(10.2.12) \hspace{1cm} Stab^{transp}_{-,\,\mathsf{T}^{1/2}_{opp},\,-\mathcal{L}} \left|_{\alpha \mapsto \,q^{\,\sigma}\alpha} \; \mathbf{S}_{\sigma} \; Stab_{-,\,\mathsf{T}^{1/2},\,\mathcal{L}} \right. = (-1)^{\frac{1}{2}\,codim\,\mathsf{X}^{\,\sigma}} \, z^{deg}$$

for all

$$\mathcal{L} \in \{ \text{neighborhood of } 0 \} \cap (-C_{ample}) \subset Pic(X) \otimes \mathbb{R} .$$

The proof of this theorem will be given in Section 10.4

**10.2.13.** For the following exercises we do not need to assume  $\sigma$  minuscule.

**Exercise 10.2.14.** Let the slope  $\mathcal{L}$  be as (10.2.7). Show that the following limit exists and is a block-diagonal operator

$$\lim_{\alpha \to 0} a^{\left\langle \text{det } \mathsf{T}^{1/2}_{>0}, \sigma \right\rangle} \mathsf{Stab}_{+} = \mathsf{block\text{-}diagonal}\,.$$

As explained before, here Stab<sub>+</sub> really means Res ∘ Stab<sub>+</sub>. Meanwhile,

$$\lim_{\alpha \to 0} a^{\left\langle \det \mathsf{T}_{>0}^{1/2}, \sigma \right\rangle} \mathsf{Stab}_{-} = \mathsf{block\text{-}triangular},$$

where the triangularity is the same as for Stab\_.

Exercise 10.2.15. Prove that

$$Stab_{+}^{-1} \ \tau_{\sigma}^{-1} \ Stab_{+} \rightarrow q^{\left\langle det \, T_{>0}^{1/2}, \sigma \right\rangle} \tau_{\sigma}^{-1} \ \text{,} \quad \alpha \rightarrow 0 \, .$$

Exercise 10.2.16. Prove that

(10.2.17) 
$$R \to \hbar^{-\operatorname{codim}/4} \operatorname{block-unitriangular}, \quad \alpha \to 0,$$

where the triangularity is the same as for Stab\_.

**10.2.18.** We will see in Section 10.3 that the following limit

(10.2.19) 
$$J_{0,+} = \lim_{\alpha \to 0} Stab_{+}^{-1} J(\alpha) Stab_{+}$$

exists, as does the limit of the operator  $S_{\sigma}$  in the stable basis. Again, this does not require the minuscule assumption. Granted this, we deduce from (8.2.25) the following analog of (8.1.13).

Proposition 10.2.20. We have

$$(10.2.21) \qquad J_{0,+}^{-1} \; Stab_{+}^{-1} \; \mathbf{S}_{\sigma} \; Stab_{+} \; J_{0,+} \to (-\hbar^{1/2})^{\left< \det N_{<0},\sigma \right>} \, q^{-\left< \det T_{>0}^{1/2},\sigma \right>} z^{\deg} \, ,$$

as  $a \to 0$ , where  $N_{<0}$  is the subspace of the normal bundle to  $X^{\sigma}$  spanned by weights that go to  $\infty$  as  $a \to 0$ .

Proof. Since

$$\Phi\big((1-q\hbar)\big(\mathsf{T}_{\mathsf{x},\sigma}^{1/2}-\mathsf{T}_{\mathsf{x},0}^{1/2}\big)\big)\to (q\hbar)^{\left\langle\det\mathsf{T}_{<0}^{1/2},\sigma\right\rangle},\quad \alpha\to0\,,$$

we see that the operator  $E(\sigma)$  in (8.2.21) becomes

$$E(\sigma) \rightarrow RHS \text{ of } (10.2.21)$$

in the  $a \rightarrow 0$  limit. From Exercise 10.2.14,

$$\begin{split} \text{Stab}_{+}^{-1} \ &\mathsf{E}(\sigma) \ \text{Stab}_{+} = \text{Stab}_{+}^{-1} \ \alpha^{-\left\langle \mathsf{det} \, \mathsf{T}_{>0}^{1/2}, \sigma \right\rangle} \mathsf{E}(\sigma) \ \alpha^{\left\langle \mathsf{det} \, \mathsf{T}_{>0}^{1/2}, \sigma \right\rangle} \mathsf{Stab}_{+} \to \mathsf{E}(\sigma) \,, \\ \text{as } \alpha \to 0 \text{, and so the conclusion follows from (8.2.21).} \end{split}$$

**Exercise 10.2.22.** Check that with the minuscule condition on  $\sigma$  Corollary 10.2.20 specializes to

$$(10.2.23) \quad \mathsf{J}_{0,+}^{-1} \ \mathsf{Stab}_{+}^{-1} \ \mathbf{S}_{\sigma} \ \mathsf{Stab}_{+} \ \mathsf{J}_{0,+} \to (-\hbar^{1/2})^{- \, codim/2} \ q^{- \, rk \, T_{>0}^{1/2}} \, z^{deg} \quad \ \alpha \to 0 \, .$$

10.2.24. From the above exercises we conclude that

$$Stab_+^{-1} \ \tau_\sigma^{-1} \ \textbf{S}_\sigma \ Stab_+ \rightarrow \tau_\sigma^{-1} \ \textbf{J}_{0,+} \ (-h)^{codim/2} z^{deg} \ \textbf{J}_{0,+}^{-1} \ ,$$

and thus the diagram (10.2.9) implies the following

**Corollary 10.2.25.** The operator  $J_{0,+}$  diagonalizes  $(-1)^{\text{codim}/2}z^{\text{deg}}R(0)$  and, in particular, is triangular with the same triangularity as  $Stab_{-}$ .

### 10.3. Glue operator in the stable basis

**10.3.1.** Let  $T^{1/2}X$  be a polarization of X and assume that the sheaf  $\widehat{\mathbb{O}}_{vir}$ , and all K-theoretic curve counts, are defined using this polarization as in (6.1.9). Our next goal is to prove the following

**Theorem 10.3.2.** The operator

$$\begin{aligned} \mathbf{G}_{Stab} &= Stab^{-1} \ \mathbf{G} \ Stab \\ &= Stab_{-\mathfrak{C}, \mathsf{T}_{Opp, -\mathcal{L}}^{1/2}}^{transp} \ \mathbf{G} \ Stab_{\mathfrak{C}, \mathsf{T}^{1/2}, \mathcal{L}} \end{aligned}$$

is independent of the equivariant parameters in A for any C and for

(10.3.4) 
$$\mathcal{L} \in \{\text{neighborhood of } 0\} \subset \text{Pic}(X) \otimes \mathbb{R}.$$

The proof takes several steps.

**10.3.5.** As in Section 6.5.29, we see that the convolution in (10.3.3) is proper, thus a Laurent polynomial in  $a \in A$ . To prove it is a constant, it suffices to check it has a finite limit as we send a to infinity in any direction.

This can be done by equivariant localization.

## **10.3.6.** Suppose

$$f \in \left(QM_{\text{relative }p_1,\,p_2}^{\sim}\right)^A$$
 ,

and let C' be the domain of f. The curve C' a chain of  $C'_{\mathfrak{i}}\cong \mathbb{P}^1$ . Since f is fixed, there exists

(10.3.7) 
$$\gamma: A \to \operatorname{Aut}(C', \mathfrak{p}'_1, \mathfrak{p}'_2) \cong \prod_{C_i} \mathbb{C}^{\times}$$

such that

$$af = f\gamma(a), \quad \forall a \in A.$$

Let  $p = C'_i \cap C'_{i+1}$  be a node of C'. We say that f is *broken* at p if

(10.3.8) weight, 
$$\left(\mathsf{T}_{\mathsf{p}}\mathsf{C}'_{\mathsf{i}}\otimes\mathsf{T}_{\mathsf{p}}\mathsf{C}'_{\mathsf{i}+1}\right)\neq 1$$
.

This terminology comes from [71]. Since the space in (10.3.8) corresponds to the smoothing of node p in Def(C'), this means that broken nodes contribute to the virtual normal bundle in (6.4.12), and namely

$$(10.3.9) \hspace{1cm} N_{vir} = N_{vir}^{fixed\ domain} + \bigoplus_{\substack{b \text{troken} \\ prodes\ p}} T_p C_i' \otimes T_p C_{i+1}'.$$

In localization formulas, this will give

contribution of broken nodes 
$$= \frac{1}{\prod (1 - weight \otimes line \ bundle)}$$

and this remains bounded as a goes to any infinity of the torus avoiding the poles.

**10.3.10.** By Lemma 6.1.4, we have

(10.3.11) 
$$N_{\text{vir}}^{\text{fixed domain}} = T_{f(p_1),\text{moving}}^{1/2} + T_{f(p_2),\text{moving}}^{1/2} + \dots$$

where

$$T_{f(p_1),moving}^{1/2} = T_{f(p_1),\neq 0}^{1/2}$$

is the part of the polarization with nontrivial A-weights and dots stand for balanced K-theory class as in Definition 6.1.7. These omitted term will contribute

$$\hat{a}(...) = O(1), \quad \alpha \to \infty,$$

to the localization formulas, so it remains to deal with the polarization.

**10.3.12.** By definition (6.4.17), we have

(10.3.13) 
$$\frac{\text{contribution of}}{\text{polarization}} = \frac{1}{\Lambda_{-}^{\bullet} T_{f(p_{1}),\text{moving}}^{1/2} \left(\Lambda_{-}^{\bullet} T_{f(p_{2}),\text{moving}}^{1/2}\right)^{\vee}}.$$

While a polarization is only a virtual vector space, we have

$$T_{f(p_2),moving}^{1/2} = \left(T_{f(p_2)}X\right)_{repelling} + \dots$$

where dots stand for a balanced class which will shift the asymptotics of (10.3.13) by an overall weight.

**10.3.14.** To find this overall shift by a weight, we may normalize the exterior algebras so that they are self-dual. This gives

$$\frac{1}{\left(\Lambda_{-}^{\bullet}\mathsf{T}_{\mathsf{f}(p_2),\mathsf{mov}}^{1/2}\right)^{\vee}} \propto \left(\frac{\det\mathsf{T}_{\mathsf{f}(p_2),\mathsf{mov}}^{1/2}}{\det\mathsf{T}_{\mathsf{f}(p_2),\mathsf{rep}}}\right)^{1/2} \frac{1}{\left(\Lambda_{-}^{\bullet}\left(\mathsf{T}_{\mathsf{f}(p_2),\mathsf{rep}}\right)\right)^{\vee}}$$

as  $a \to \infty$ , which precisely compensates the weights (9.1.10) of the restriction of a stable envelope to the fixed component containing  $f(p_2)$  for all slopes  $\mathcal L$  sufficiently close to 0.

For the contribution of polarization at  $f(p_1)$ , the conclusion is the same, with the replacement

$$det \, T_{f(p_2),mov}^{1/2} \mapsto det \, T_{f(p_1),mov}^{-1/2} = det \, T_{f(p_1),mov}^{1/2,opp} \, .$$

This concludes the proof of Theorem 10.3.2.

**10.3.15.** Recall the shift operator  $S_{\sigma}$  defined in (8.2.18). One of its factors is the glue operator that was just discussed. As before, we assume that  $\sigma$  is a cocharacter of A, that is, the shift of equivariant weights is in a direction that *preserves* the symplectic form.

**Corollary 10.3.16.** *The operator* 

$$(10.3.17) Stab_{\mathfrak{C},\mathsf{T}^{1/2},\mathcal{L}}^{-1} \Big|_{\mathfrak{a}\mapsto\mathfrak{a}^{\sigma}\mathfrak{a}} \mathbf{S}_{\sigma} Stab_{\mathfrak{C},\mathsf{T}^{1/2},\mathcal{L}} \in End \mathsf{K}(\mathsf{X}^{\mathsf{A}})_{localized}$$

is bounded and invertible at any infinity of the torus A for any  $\mathfrak C$  and for  $\mathcal L$  as in (10.3.4).

The first factor in (8.2.18) is only defined using localization, and so (10.3.17) is really a rational function of the equivariant parameters. This Corollary implies the q-difference equation in the variables  $a \in A$  has regular singularities.

Also, since  $\mathbf{S}_{\sigma}$  is really an operator in  $K(X^A)$ , the stable envelopes are really the compositions

$$K(X^A) \xrightarrow{Stab} K(X) \xrightarrow{restriction} K(X^A)$$

and, in particular, it makes sense to shift the equivariant variables in stable envelopes. We have already seen this in in (10.2.12) above.

*Proof.* Bounding the A-weights is done as in the above argument. The key point is that as in Lemma 6.1.4 we have

$$T_{vir} = H^{\bullet}\left(\mathfrak{T}^{1/2} + \hbar^{-1}\left(\mathfrak{T}^{1/2}\right)^{\vee}\right)$$

even for twisted quasimaps as long as σ preserves the symplectic form.

The inverse of  $S_{\sigma}$  may be computed from  $S_{\sigma}$ , therefore the shift operators are both bounded and invertible at infinities of A.

### 10.3.18.

**Exercise 10.3.19.** Prove the existence of the limit (10.2.19).

**Exercise 10.3.20.** Show the triangularity of the operator  $J_{0,+}$  from Corollary 10.2.25 directly, by examining the contribution of the broken nodes in the  $a \rightarrow 0$  limit.

### 10.4. Proof of Theorem 10.2.11

We may assume that A is a 1-dimensional torus with coordinate a and that

$$\sigma: \mathbb{C}_{\mathfrak{q}}^{\times} \xrightarrow{\sim} \mathsf{A}$$

is an isomorphism. We write qa in place of  $\mathfrak{q}^\sigma a.$ 

The two-dimensional torus  $\mathbb{C}_q^{\times} \times A$  acts on the moduli spaces of twisted quasimaps. By construction, the group  $\mathbb{C}_q^{\times}$  acts in the fiber of  $\mathbb{V}$  at  $\mathfrak{p}_1'$  and does not act in the fiber of V at  $p_2'$ , see Section 4.3.3.

As discussed before, the pushforward in (10.2.12) is proper, therefore the left-hand side is a Laurent polynomial in q and a. We analyze the behavior of this polynomial as (q, a) go to different infinities of the torus  $\mathbb{C}_q^{\times} \times A$ .

In order to prove (10.2.12), it suffices to show that the left-hand side remains bounded at all infinities and limits to the right-hand side as

$$(10.4.3) a \rightarrow \infty, qa \rightarrow 0.$$

Localization with respect to the  $\mathbb{C}_q^{\times}$ -action gives the following schematic 10.4.4. formula

$$\mathbf{S}_{\sigma} = \mathsf{J}\big|_{\alpha \mapsto q \, \alpha} \circ |edge| \circ \mathsf{J}^{transp} \circ \mathbf{G}^{-1}$$
,

where the edge operator is the operator associated with constant twisted quasimaps and

$$J^{transp} = |capping operator|$$

is the operator with matrix coefficients (7.5.26).

We can thus factor the LHS of (10.2.12) as follows

(10.4.5) LHS of (10.2.12) = 
$$\left( \operatorname{Stab}_{-,\mathsf{T}_{\mathrm{opp}}^{1/2},-\mathcal{L}}^{\mathrm{transp}} \right) \left| \operatorname{Stab}_{+,\mathsf{T}^{1/2},\mathcal{L}} \right) \right|_{\alpha \mapsto q \alpha} \times$$

$$\left( \operatorname{Stab}_{-,\mathsf{T}_{\mathrm{opp}}^{1/2},-\mathcal{L}}^{\mathrm{transp}} \right) \left| \operatorname{adge} \right| \left| \operatorname{Stab}_{-,\mathsf{T}^{1/2},\mathcal{L}}^{\mathrm{transp}} \right| \times$$

(10.4.6) 
$$\left( \operatorname{Stab}^{\operatorname{transp}}_{-,\mathsf{T}_{\mathsf{Opp}}^{1/2},-\mathcal{L}} \right) \Big|_{\mathbf{a} \mapsto \mathsf{q} \, \mathbf{a}} |\operatorname{edge}| \operatorname{Stab}_{-,\mathsf{T}^{1/2},\mathcal{L}} \times$$

(10.4.7) 
$$\operatorname{Stab}_{+,\mathsf{T}_{\mathrm{opp}}^{1/2},-\mathcal{L}}^{\operatorname{transp}} \mathbf{G}^{-1} \operatorname{Stab}_{-,\mathsf{T}^{1/2},\mathcal{L}}.$$

We deal with each factor separately.

10.4.8.

**Lemma 10.4.9.** The operator in the RHS of (10.4.5) is bounded at all infinities of  $\mathbb{C}_q^{\times} \times \mathbb{A}$  and goes to 1 at the point (10.4.3).

*Proof.* We argue as in the proof of Theorem 10.3.2, now with the additional insertion of  $\left(1-q^{-1}\psi_{p_1}\right)^{-1}$ . Since A acts on tangents spaces to all fixed points with weights  $0,\pm 1$ , we conclude

weight(
$$\psi_{p_1}$$
)  $\in \{1, (qa)^{\pm 1}\}$ .

In every case,

$$\frac{1}{1-q^{-1}\, weight(\psi_{p_1})} \to 0$$

at the point (10.4.3) and remains bounded at all other infinities. Thus in the limit (10.4.3) the accordions at  $p_1$  are suppressed and the result follows.

10.4.10.

**Lemma 10.4.11.** *The operator in* (10.4.7) *is bounded at all infinities of*  $\mathbb{C}_q^{\times} \times A$  *and goes to* 1 *at the point* (10.4.3).

*Proof.* We argue as in the previous lemma, now with the insertion of  $(1 - q\psi_{p_2})^{-1}$ . We have

$$q \text{ weight}(\psi_{\mathfrak{p}_2}) \in \{q, q \mathfrak{a}^{\pm 1}\},$$

which goes to zero in the limit (10.4.3). Thus  $\psi_{p_2}$  plays no role in this limit and

$$J^{transp} \mathbf{G}^{-1} \rightarrow \mathbf{G} \mathbf{G}^{-1} = 1.$$

as was to be shown.

**10.4.12.** It remains to deal with the operator in (10.4.6). Let  $f \equiv x$  be a constant map to  $x \in F$ . Since the weights of A in  $T_x X$  are  $\{0, \pm 1\}$ , the virtual normal bundle at f to the space of A-fixed quasimaps is

(10.4.13) 
$$N_{vir} = H^0(T_{x,>0}) = (T_{x,>0}X) \big|_{\alpha \mapsto q\alpha} + T_{x,>0}X,$$

where  $T_{x,>0}X$  denotes the A-attracting part of  $T_xX$  and  $T_{x,>0}$  is the bundle of these spaces over the domain of the quasimap.

Therefore, the normal bundle contribution to  $0_{vir} \otimes \mathcal{K}_{vir}^{1/2}$ , which appears in the denominator of the localization formula, precisely cancels with the contributions (9.1.7) from the diagonal part of stable envelopes, which appears in the numerators. The remaining factors in (9.1.6) combine with the polarization factors in (6.1.9) to give

$$(10.4.14) \quad (-1)^{rk \, N_{>0}^{1/2, opp} + rk \, N_{>0}^{1/2}} \frac{1}{(\det N^{1/2, opp})\big|_{a \mapsto aa} \det N^{1/2}} \times$$

$$\left(\frac{\det \mathsf{N}^{1/2}}{\det \mathsf{N}^{1/2}\big|_{\alpha\mapsto q\,\alpha}}\right)^{1/2} = (-1)^{\frac{1}{2}\operatorname{codim}\mathsf{F}}\mathsf{h}^{\frac{1}{2}\operatorname{codim}\mathsf{F}}$$

as the normal bundle contribution of the diagonal parts of stable envelopes. The factor with  $\hbar$  disappears when we convert two-point invariants to operators as in (6.5.22). Together with the degree weight, this gives

$$\begin{array}{ll} \text{diagonal} & = (-1)^{\frac{1}{2}\operatorname{codim}\mathsf{F}}z^{\text{deg}}\,, \\ \text{contributions} & \end{array}$$

where the degree of the constant map was computed in (4.3.15).

To suppress the off-diagonal contributions, we need that

(10.4.15) 
$$\operatorname{weight}_{qa} \frac{\mathcal{L}^{-1}|_{F_2}}{\mathcal{L}^{-1}|_{F_1}} \operatorname{weight}_a \frac{\mathcal{L}|_{F_2}}{\mathcal{L}|_{F_1'}} \to 0,$$

in the limit (10.4.3) for any triple of components  $F_1$ ,  $F_1'$ ,  $F_2$  of the fixed locus such that

(10.4.16) 
$$F_2 \subset Attr_{-\mathfrak{C}}^f(F_1), Attr_{-\mathfrak{C}}^f(F_1')$$

and

$$(F_1, F_1') \neq (F_2, F_2)$$
.

The condition (10.4.16) means there is a chain of torus orbits from  $F_1$  and  $F_1'$  to  $F_2$  and computing the degree of that chain of curves with respect to  $\mathcal{L}^{-1}$  we see that (10.4.15) is satisfied if  $\mathcal{L}^{-1}$  is ample.

This concludes the proof of Theorem 10.2.11.

- [1] M. Aganagic and A. Okounkov, Elliptic stable envelopes, arXiv:1604.00423. 6, 7, 106, 109
- [2] V. I. Arnol'd, Mathematical methods of classical mechanics, Graduate Texts in Mathematics, vol. 60, Springer-Verlag, New York, 199?. Translated from the 1974 Russian original by K. Vogtmann and A. Weinstein; Corrected reprint of the second (1989) edition. ←49
- [3] M. F. Atiyah and R. Bott, A Lefschetz fixed point formula for elliptic complexes. I, Ann. of Math. (2) 86 (1967), 374–407. ←20
- [4] Michael Atiyah and Friedrich Hirzebruch, *Spin-manifolds and group actions*, Essays on Topology and Related Topics (Mémoires dédiés à Georges de Rham), Springer, New York, 1970, pp. 18−28. ←22
- [5] Martina Balagović, Degeneration of trigonometric dynamical difference equations for quantum loop algebras to trigonometric Casimir equations for Yangians, Comm. Math. Phys. 334 (2015), no. 2, 629–659.
  —7
- [6] Kai Behrend, Ionut Ciocan-Fontanine, Junho Hwang, and Michael Rose, The derived moduli space of stable sheaves, Algebra Number Theory 8 (2014), no. 4, 781–812. ←26
- [7] K. Behrend and B. Fantechi, The intrinsic normal cone, Invent. Math. 128 (1997), no. 1, 45–88. ←26, 34
- [8] Roman Bezrukavnikov and Michael Finkelberg, Wreath Macdonald polynomials and the categorical McKay correspondence, Camb. J. Math. 2 (2014), no. 2, 163–190. With an appendix by Vadim Vologodsky. ←5
- [9] Roman Bezrukavnikov, Michael Finkelberg, and Vadim Schechtman, *Factorizable sheaves and quantum groups*, Lecture Notes in Mathematics, vol. 1691, Springer-Verlag, Berlin, 1998. ←60

- [10] R. Bezrukavnikov and D. Kaledin, *Fedosov quantization in positive characteristic*, J. Amer. Math. Soc. **21** (2008), no. 2, 409–438. Ð5
- [11] R. Bezrukavnikov and I. Losev, *Etingof conjecture for quantized quiver varieties*, arXiv:1309.1716. 5
- [12] Roman Bezrukavnikov and Ivan Mirkovi´c, *Representations of semisimple Lie algebras in prime characteristic and the noncommutative Springer resolution*, Ann. of Math. (2) **178** (2013), no. 3, 835–919. Ð5
- [13] Armand Borel and Jean-Pierre Serre, *Le théorème de Riemann-Roch*, Bull. Soc. Math. France **86** (1958), 97–136 (French). Ð18
- [14] Patrick Brosnan, *On motivic decompositions arising from the method of Białynicki-Birula*, Invent. Math. **161** (2005), no. 1, 91–111. Ð23
- [15] Erik Carlsson, Nikita Nekrasov, and Andrei Okounkov, *Five dimensional gauge theories and vertex operators*, Mosc. Math. J. **14** (2014), no. 1, 39–61, 170 (English, with English and Russian summaries). Ð63
- [16] Erik Carlsson and Andrei Okounkov, *Exts and vertex operators*, Duke Math. J. **161** (2012), no. 9, 1797–1815. Ð37
- [17] Ionu¸t Ciocan-Fontanine and Mikhail Kapranov, *Derived Quot schemes*, Ann. Sci. École Norm. Sup. (4) **34** (2001), no. 3, 403–440 (English, with English and French summaries). Ð26
- [18] Ionu¸t Ciocan-Fontanine and Mikhail M. Kapranov, *Derived Hilbert schemes*, J. Amer. Math. Soc. **15** (2002), no. 4, 787–815. Ð26
- [19] Ionu¸t Ciocan-Fontanine and Mikhail Kapranov, *Virtual fundamental classes via dg-manifolds*, Geom. Topol. **13** (2009), no. 3, 1779–1804. Ð22, 26, 34, 40
- [20] Ionu¸t Ciocan-Fontanine, Bumsig Kim, and Davesh Maulik, *Stable quasimaps to GIT quotients*, J. Geom. Phys. **75** (2014), 17–47. Ð11, 51, 54, 74, 75, 80, 81
- [21] Vyjayanthi Chari and Andrew Pressley, *A guide to quantum groups*, Cambridge University Press, Cambridge, 1994. Ð115, 117
- [22] Neil Chriss and Victor Ginzburg, *Representation theory and complex geometry*, Modern Birkhäuser Classics, Birkhäuser Boston, Inc., Boston, MA, 2010. Reprint of the 1997 edition. Ð11, 13
- [23] Michel Demazure, *A very simple proof of Bott's theorem*, Invent. Math. **33** (1976), no. 3, 271–272. Ð21
- [24] Lawrence Ein and Robert Lazarsfeld, *The gonality conjecture on syzygies of algebraic curves of large degree*, Publ. Math. Inst. Hautes Études Sci. **122** (2015), 301–313. Ð60
- [25] Pavel Etingof, *Symplectic reflection algebras and affine Lie algebras*, Mosc. Math. J. **12** (2012), no. 3, 543–565, 668–669 (English, with English and Russian summaries). Ð5
- [26] Pavel I. Etingof, Igor B. Frenkel, and Alexander A. Kirillov Jr., *Lectures on representation theory and Knizhnik-Zamolodchikov equations*, Mathematical Surveys and Monographs, vol. 58, American Mathematical Society, Providence, RI, 1998. Ð120
- [27] Pavel Etingof and Olivier Schiffmann, *Lectures on quantum groups*, 2nd ed., Lectures in Mathematical Physics, International Press, Somerville, MA, 2002. Ð115, 117
- [28] P. Etingof and A. Varchenko, *Dynamical Weyl groups and applications*, Adv. Math. **167** (2002), no. 1, 74–127. Ð7
- [29] Barbara Fantechi and Lothar Göttsche, *Riemann-Roch theorems and elliptic genus for virtually smooth schemes*, Geom. Topol. **14** (2010), no. 1, 83–115. Ð40
- [30] Barbara Fantechi, Lothar Göttsche, Luc Illusie, Steven L. Kleiman, Nitin Nitsure, and Angelo Vistoli, *Fundamental algebraic geometry*, Mathematical Surveys and Monographs, vol. 123, American Mathematical Society, Providence, RI, 2005. Grothendieck's FGA explained. Ð18, 24, 29
- [31] Boris Feigin, Michael Finkelberg, Igor Frenkel, and Leonid Rybnikov, *Gelfand-Tsetlin algebras and cohomology rings of Laumon spaces*, Selecta Math. (N.S.) **17** (2011), no. 2, 337–361. Ð5
- [32] I. B. Frenkel and N. Yu. Reshetikhin, *Quantum affine algebras and holonomic difference equations*, Comm. Math. Phys. **146** (1992), no. 1, 1–60. Ð120
- [33] William Fulton, *Intersection theory*, 2nd ed., Ergebnisse der Mathematik und ihrer Grenzgebiete. 3. Folge. A Series of Modern Surveys in Mathematics [Results in Mathematics and Related Areas. 3rd Series. A Series of Modern Surveys in Mathematics], vol. 2, Springer-Verlag, Berlin, 1998. Ð16
- [34] D. Gaitsgory, *Twisted Whittaker model and factorizable sheaves*, Selecta Math. (N.S.) **13** (2008), no. 4, 617–659. Ð60

- [35] Victor Ginzburg, *Lectures on Nakajima's quiver varieties*, Geometric methods in representation theory. I, Sémin. Congr., vol. 24, Soc. Math. France, Paris, 2012, pp. 145–219 (English, with English and French summaries). Ð1, 11, 50, 91
- [36] Alexander Givental, *On the WDVV equation in quantum* K*-theory*, Michigan Math. J. **48** (2000), 295–304. Dedicated to William Fulton on the occasion of his 60th birthday. Ð82, 86
- [37] Alexander Givental and Valentin Tonita, *The Hirzebruch-Riemann-Roch theorem in true genus-0 quantum K-theory*, Symplectic, Poisson, and noncommutative geometry, Math. Sci. Res. Inst. Publ., vol. 62, Cambridge Univ. Press, New York, 2014, pp. 43–91. Ð12
- [38] T. Graber and R. Pandharipande, *Localization of virtual classes*, Invent. Math. **135** (1999), no. 2, 487–518. Ð22, 40
- [39] Daniel Halpern-Leistner, *The derived category of a GIT quotient*, J. Amer. Math. Soc. **28** (2015), no. 3, 871–912. Ð111
- [40] Kentaro Hori, Sheldon Katz, Albrecht Klemm, Rahul Pandharipande, Richard Thomas, Cumrun Vafa, Ravi Vakil, and Eric Zaslow, *Mirror symmetry*, Clay Mathematics Monographs, vol. 1, American Mathematical Society, Providence, RI; Clay Mathematics Institute, Cambridge, MA, 2003. With a preface by Vafa. Ð11
- [41] Amer Iqbal, Can Kozçaz, and Cumrun Vafa, *The refined topological vertex*, J. High Energy Phys. **10** (2009), 069, 58. Ð44
- [42] Hiroshi Iritani, *An integral structure in quantum cohomology and mirror symmetry for toric orbifolds*, Adv. Math. **222** (2009), no. 3, 1016–1079. Ð100
- [43] Dmitry Kaledin, *Derived equivalences by quantization*, Geom. Funct. Anal. **17** (2008), no. 6, 1968– 2004. Ð5
- [44] Dmitry Kaledin, *Geometry and topology of symplectic resolutions*, Algebraic geometry—Seattle 2005. Part 2, Proc. Sympos. Pure Math., vol. 80, Amer. Math. Soc., Providence, RI, 2009, pp. 595–628. Ð4
- [45] János Kollár, *Rational curves on algebraic varieties*, Ergebnisse der Mathematik und ihrer Grenzgebiete. 3. Folge. A Series of Modern Surveys in Mathematics [Results in Mathematics and Related Areas. 3rd Series. A Series of Modern Surveys in Mathematics], vol. 32, Springer-Verlag, Berlin, 1996. Ð24
- [46] Maxim Kontsevich, *Enumeration of rational curves via torus actions*, The moduli space of curves (Texel Island, 1994), Progr. Math., vol. 129, Birkhäuser Boston, Boston, MA, 1995, pp. 335–368. Ð26
- [47] Igor Krichever, *Obstructions to the existence of* S 1 *-actions. Bordisms of branched coverings*, Izv. Akad. Nauk SSSR Ser. Mat. **40** (1976), no. 4, 828–844, 950 (Russian). Ð22
- [48] Igor Krichever, *Generalized elliptic genera and Baker-Akhiezer functions*, Mat. Zametki **47** (1990), no. 2, 34–45, 158 (Russian); English transl., Math. Notes **47** (1990), no. 1-2, 132–142. Ð22
- [49] Y.-P. Lee, *Quantum* K*-theory. I. Foundations*, Duke Math. J. **121** (2004), no. 3, 389–424. Ð82, 86
- [50] M. Levine and R. Pandharipande, *Algebraic cobordism revisited*, Invent. Math. **176** (2009), no. 1, 63–130. Ð9, 11, 34, 41
- [51] Jun Li, *Stable morphisms to singular schemes and relative stable morphisms*, J. Differential Geom. **57** (2001), no. 3, 509–578. Ð68, 82
- [52] Jun Li, *A degeneration formula of GW-invariants*, J. Differential Geom. **60** (2002), no. 2, 199–293. Ð68, 82
- [53] Jun Li and Baosen Wu, *Good degeneration of Quot-schemes and coherent systems*, Comm. Anal. Geom. **23** (2015), no. 4, 841–921. Ð9, 68, 82
- [54] Marco Manetti, *Lectures on deformations of complex manifolds (deformations from differential graded viewpoint)*, Rend. Mat. Appl. (7) **24** (2004), no. 1, 1–183. Ð
- [55] D. Maulik, N. Nekrasov, A. Okounkov, and R. Pandharipande, *Gromov-Witten theory and Donaldson-Thomas theory. I*, Compos. Math. **142** (2006), no. 5, 1263–1285. Ð8
- [56] D. Maulik, N. Nekrasov, A. Okounkov, and R. Pandharipande, *Gromov-Witten theory and Donaldson-Thomas theory. II*, Compos. Math. **142** (2006), no. 5, 1286–1304. Ð8, 11, 34
- [57] D. Maulik, A. Oblomkov, A. Okounkov, and R. Pandharipande, *Gromov-Witten/Donaldson-Thomas correspondence for toric 3-folds*, Invent. Math. **186** (2011), no. 2, 435–479. Ð4, 10
- [58] Davesh Maulik and Alexei Oblomkov, *Quantum cohomology of the Hilbert scheme of points on* An*resolutions*, J. Amer. Math. Soc. **22** (2009), no. 4, 1055–1091. Ð4
- [59] D. Maulik and A. Okounkov, *Quantum groups and quantum cohomology*, arXiv:1211.1287. 5, 6, 12, 100, 101, 110, 117, 120

- [60] D. Maulik and A. Okounkov, in preparation. 5, 6, 109
- [61] D. Maulik and R. Pandharipande, *A topological view of Gromov-Witten theory*, Topology **45** (2006), no. 5, 887–918. Ð9
- [62] Hiraku Nakajima, *Instantons on ALE spaces, quiver varieties, and Kac-Moody algebras*, Duke Math. J. **76** (1994), no. 2, 365–416. Ð1, 4, 11, 50
- [63] Hiraku Nakajima, *Quiver varieties and Kac-Moody algebras*, Duke Math. J. **91** (1998), no. 3, 515–560. Ð1, 4, 11, 50
- [64] Hiraku Nakajima, *Quiver varieties and finite-dimensional representations of quantum affine algebras*, J. Amer. Math. Soc. **14** (2001), no. 1, 145–238. Ð49
- [65] Hiraku Nakajima, *Towards a mathematical definition of Coulomb branches of* 3*-dimensional* N " 4 *gauge theories, I* arXiv:1503.03676. 7, 10
- [66] Nikita Nekrasov, **Z***-theory: chasing* m{f *theory*, C. R. Phys. **6** (2005), no. 2, 261–269 (English, with English and French summaries). Strings 04. Part II. Ð11, 30, 31
- [67] N. Nekrasov and A. Okounkov, *Membranes and Sheaves*, arXiv:1404.2323. 8, 11, 28, 29, 31, 44, 56
- [68] Nikita A. Nekrasov and Samson L. Shatashvili, *Supersymmetric vacua and Bethe ansatz*, Nuclear Phys. B Proc. Suppl. **192/193** (2009), 91–112. Ð5, 49
- [69] Nikita A. Nekrasov and Samson L. Shatashvili, *Quantization of integrable systems and four dimensional gauge theories*, XVIth International Congress on Mathematical Physics, World Sci. Publ., Hackensack, NJ, 2010, pp. 265–289. Ð5, 49
- [70] Andrei Okounkov, *Random surfaces enumerating algebraic curves*, European Congress of Mathematics, Eur. Math. Soc., Zürich, 2005, pp. 751–768. Ð9
- [71] A. Okounkov and R. Pandharipande, *Quantum cohomology of the Hilbert scheme of points in the plane*, Invent. Math. **179** (2010), no. 3, 523–557. Ð4, 124
- [72] A. Okounkov and R. Pandharipande, *The local Donaldson-Thomas theory of curves*, Geom. Topol. **14** (2010), no. 3, 1503–1567. Ð4, 42
- [73] Andrei Okounkov and Nikolai Reshetikhin, *Correlation function of Schur process with application to local geometry of a random 3-dimensional Young diagram*, J. Amer. Math. Soc. **16** (2003), no. 3, 581–603 (electronic). Ð44
- [74] Andrei Okounkov and Nicolai Reshetikhin, *Random skew plane partitions and the Pearcey process*, Comm. Math. Phys. **269** (2007), no. 3, 571–609. Ð44
- [75] A. Okounkov and A. Smirnov, *Quantum difference equations for Nakajima varieties*, arXiv:1602.09007. 6, 7, 12, 49, 102, 117, 121
- [76] V. P. Palamodov, *Deformations of complex spaces*, Current problems in mathematics. Fundamental directions, Vol. 10 (Russian), Itogi Nauki i Tekhniki, Akad. Nauk SSSR, Vsesoyuz. Inst. Nauchn. i Tekhn. Inform., Moscow, 1986, pp. 123–221, 283 (Russian). Ð
- [77] R. Pandharipande and A. Pixton, *Gromov-Witten/Pairs correspondence for the quintic 3-fold*, arXiv:1206.5490. 9, 11
- [78] N. Yu. Reshetikhin, *Quasitriangular Hopf algebras and invariants of links*, Algebra i Analiz **1** (1989), no. 2, 169–188 (Russian); English transl., Leningrad Math. J. **1** (1990), no. 2, 491–513. Ð118
- [79] Graeme Segal, *The representation ring of a compact Lie group*, Inst. Hautes Études Sci. Publ. Math. **34** (1968), 113–128. Ð20
- [80] Richard P. Stanley, *Enumerative combinatorics. Volume 1*, 2nd ed., Cambridge Studies in Advanced Mathematics, vol. 49, Cambridge University Press, Cambridge, 2012. Ð15
- [81] V. Tarasov and A. Varchenko, *Dynamical differential equations compatible with rational* qKZ *equations*, Lett. Math. Phys. **71** (2005), no. 2, 101–108. Ð5
- [82] Valerio Toledano Laredo, *The trigonometric Casimir connection of a simple Lie algebra*, J. Algebra **329** (2011), 286–327. Ð5
- [83] R. W. Thomason, *Une formule de Lefschetz en* K*-théorie équivariante algébrique*, Duke Math. J. **68** (1992), no. 3, 447–462 (French). Ð19
- [84] È. B. Vinberg and V. L. Popov, *Invariant theory*, Algebraic geometry, 4 (Russian), Itogi Nauki i Tekhniki, Akad. Nauk SSSR, Vsesoyuz. Inst. Nauchn. i Tekhn. Inform., Moscow, 1989, pp. 137– 314, 315 (Russian). Ð76
- [85] Claire Voisin, *Green's generic syzygy conjecture for curves of even genus lying on a* K3 *surface*, J. Eur. Math. Soc. (JEMS) **4** (2002), no. 4, 363–404. Ð60

Department of Mathematics, Columbia University, New York, NY 10027, Institute for Problems of Information Transmission Bolshoy Karetny 19, Moscow 127994, Russia Laboratory of Representation Theory and Mathematical Physics Higher School of Economics Myasnitskaya 20, Moscow 101000, Russia

*E-mail address*: okounkov@math.columbia.edu