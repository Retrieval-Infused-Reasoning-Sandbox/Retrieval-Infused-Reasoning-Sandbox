# D-branes and the planar limit of Chern-Simons theory I: Link invariants

## Davide Gaiotto,<sup>1</sup> Suriyah Rajalingam Kannagi,<sup>1</sup> Sergio Sanjurjo<sup>1</sup>

<sup>1</sup>Perimeter Institute for Theoretical Physics, 31 Caroline Street North, Waterloo, ON N2L 2Y5, Canada

E-mail: [dgaiotto@perimeterinstitute.ca](mailto:dgaiotto@perimeterinstitute.ca), [srajalingamkannagi@perimeterinstitute.ca](mailto:srajalingamkannagi@perimeterinstitute.ca), [ssanjurjo@perimeterinstitute.ca](mailto:ssanjurjo@perimeterinstitute.ca)

Abstract: We revisit the Holographic duality between SU(N)<sup>κ</sup> Chern-Simons theory and the A-model Topological String Theory. We develop a strategy to systematically compute the large N saddles for correlation functions of Wilson lines in antisymmetric powers Λ•C <sup>N</sup> of the fundamental representation. The mathematical structures which appear in the calculation match in detail the data of dual A-model D-branes.

## Contents

| 1 |                                                | Introduction                                                           | 2  |
|---|------------------------------------------------|------------------------------------------------------------------------|----|
|   | 1.1                                            | Closed Strings and large<br>N<br>saddles                               | 3  |
|   | 1.2                                            | Heavy Wilson lines and D-branes                                        | 4  |
|   | 1.3                                            | Elongated knots and the phase space of D-branes                        | 6  |
|   | 1.4                                            | Other constructions and knot presentations                             | 8  |
|   | 1.5                                            | D-branes and symplectic geometry                                       | 9  |
|   | 1.6                                            | Structure of the Paper                                                 | 10 |
| 2 | Chern-Simons theory and the 't Hooft expansion |                                                                        |    |
|   | 2.1                                            | Fundamental Wilson loops                                               | 11 |
|   | 2.2                                            | Heavy Wilson lines                                                     | 12 |
|   | 2.3                                            | Mesonic operators and recursion relations                              | 14 |
|   | 2.4                                            | Planar tree-level                                                      | 16 |
| 3 | The rung algebra as a quantum group            |                                                                        |    |
|   | 3.1                                            | Casimir operators and charge at infinity                               | 21 |
|   | 3.2                                            | The<br>P2,1<br>phase space                                             | 23 |
|   | 3.3                                            | The<br>P3,1<br>phase space                                             | 26 |
|   | 3.4                                            | The<br>P4,2<br>phase space                                             | 29 |
| 4 | From rung vevs to character varieties          |                                                                        |    |
|   | 4.1                                            | The geometric braid group action                                       | 34 |
|   | 4.2                                            | Pm,n, cups and caps<br>An alternative perspective on                   | 36 |
|   | 4.3                                            | The trefoil augmentation variety as a family of GL(2) flat connections | 38 |
|   | 4.4                                            | 2 ×<br>1<br>Closed braids in<br>S<br>S                                 | 39 |
| 5 | Holography and Chern-Simons theory             |                                                                        | 40 |
|   | 5.1                                            | ∗R<br>3 back-reaction<br>T                                             | 41 |
|   | 5.2                                            | ∗R<br>∗S<br>2 ×<br>T<br>T<br>back-reaction                             | 42 |
|   | 5.3                                            | Wilson lines, strings and D-branes                                     | 43 |
|   | 5.4                                            | Holomorphic tricks                                                     | 45 |
|   | 5.5                                            | ∗R<br>Branes in<br>Mt<br>×<br>T                                        | 46 |
|   | 5.6                                            | R<br>3\{0}<br>Twisted connections on<br>and endpoints.                 | 47 |
|   | 5.7                                            | Branes without end                                                     | 48 |

| 6 |                                              | Conclusions and open directions                                    | 49 |
|---|----------------------------------------------|--------------------------------------------------------------------|----|
|   | 6.1                                          | A surprising formula                                               | 50 |
| A | Some auxiliary SQFTs                         |                                                                    |    |
|   | A.1                                          | Classical representations from three-dimensional SCFTs             | 52 |
|   | A.2                                          | Classical representations from Coulomb branches                    | 53 |
|   | A.3                                          | Quantum group representations from Coulomb branches and multiplica |    |
|   |                                              | tive Higgs branches                                                | 55 |
|   | A.4                                          | Brane engineering                                                  | 55 |
|   | A.5                                          | Translating between descriptions                                   | 58 |
|   | A.6                                          | More about the D-brane interpretation                              | 61 |
|   | A.7                                          | Quantization                                                       | 62 |
|   | A.8                                          | Real loci and Hilbert spaces                                       | 62 |
|   | A.9                                          | P2,1<br>Example:                                                   | 63 |
| B | Geometric correspondences and BPS interfaces |                                                                    |    |
|   | B.1                                          | Correspondences and half-BPS interfaces                            | 65 |
|   | B.2                                          | Preparing a cup                                                    | 67 |
| C | The                                          | Uq(glm)<br>rung algebra and the braid group                        | 68 |
|   | C.1                                          | The rung algebra as a representation of<br>Uq(glm)                 | 68 |
|   | C.2                                          | Rungs and braids                                                   | 69 |
|   | C.3                                          | Long rungs and a PBW basis                                         | 70 |
|   | C.4                                          | Cups and caps                                                      | 72 |
|   | C.5                                          | Junctions                                                          | 73 |
|   | C.6                                          | Endpoints                                                          | 75 |
| D |                                              | The planar quantum group as a character variety                    | 76 |
|   | D.1                                          | Framing strands                                                    | 76 |
|   | D.2                                          | The bilinear parameterization                                      | 79 |
|   | D.3                                          | Planar junctions and ends                                          | 81 |
| E | Diagrammatic rules                           |                                                                    | 81 |
|   | E.1                                          | Planar limit of rungs, braids, caps, and cups                      | 88 |
| F |                                              | Examples of augmentation varieties                                 | 93 |
|   | F.1                                          | Additional considerations                                          | 97 |

## <span id="page-3-0"></span>1 Introduction

The 't Hooft expansion of SU(N)<sup>κ</sup> Chern-Simons theory is expected to be holographically dual to the perturbative expansion of the A-model Topological String Theory [\[1,](#page-104-0) [2\]](#page-104-1). This is a beautiful and potentially very explicit example of holography: the partition function and correlation functions of Wilson loop operators can be computed exactly with TFT techniques, and the A-model also allows for exact calculations. Ultimately, one may hope to prove the duality in full mathematical rigor.

This goal is still out of reach for many observables, even in the planar limit. For example, we expect the partition function Z<sup>M</sup><sup>3</sup> [SU(N)κ] of the CS theory on a closed three-manifold M<sup>3</sup> to admit large N saddles, which should be matched to A-model backgrounds which approach T <sup>∗</sup>M<sup>3</sup> near the boundary at infinity. For generic M3, though, we do not know how to characterize the large N saddles or the A-model backgrounds, nor how to match the two. The best understood example is M<sup>3</sup> = S 3 , believed to be dual to the A-model on the resolved conifold geometry. Quotients of S 3 and Lens Spaces are also well-studied, sometimes with the help of Mirror Symmetry [\[3–](#page-104-2)[5\]](#page-104-3).

The simplest observables in Chern-Simons theory are Wilson loop operators Wℓ,R, labeled by a closed framed path ℓ and an SU(N) representation.[1](#page-3-1) Their correlation functions are of great mathematical interest as a source of knot and link invariants. "Compact" SU(N)<sup>κ</sup> Wilson loops supported within a 3-ball, for example, give rise to the colored HOMFLY polynomials. Correlation functions of Wilson loops along nontrivial loops in M3, possibly enriched by gauge-invariant three-way junctions, can be organized into the "Skein module" Sk<sup>M</sup><sup>3</sup> [SU(N)κ] of M<sup>3</sup> [\[6,](#page-104-4) [7\]](#page-104-5).

The role of Wilson loops in the 't Hooft expansion depends sensitively on the choice of representation. Schematically, specific tensor products of fundamental and/or antifundamental representations are associated to closed strings, while representations with order N indices are associated to D-branes. Representations with order N<sup>2</sup> indices could potentially modify the asymptotic shape of the holographic dual geometry. In this paper we will focus on Wilson loops dual to strings and D-branes.

<span id="page-3-1"></span><sup>1</sup>The height and width of the Young Tableau labeling R are bounded respectively by N and κ, the latter due to quantum effects.

## <span id="page-4-0"></span>1.1 Closed Strings and large N saddles

Wilson loop operators  $W_{\ell,\square}$  in the fundamental representation of  $SU(N)_{\kappa}$  have a well-studied holographic interpretation in terms of extended string worldsheets [8]. In a large N analysis, vevs  $w_{\ell}$  of the  $(\mathfrak{q} - \mathfrak{q}^{-1})W_{\ell,\square}$  operators are constrained by "loop equations", which are the planar limit of the framed HOMFLY skein relations:<sup>2</sup>

with  $\mathfrak{q} = e^{i\pi \frac{1}{\kappa + N}}$ .

The planar limit is defined as  $\mathfrak{q} \to 1$  with constant  $g = \mathfrak{q}^N = e^{i\pi \frac{N}{\kappa + N}}$ , the exponentiated 't Hooft coupling. In the planar limit, fundamental Wilson loops turn out to be transparent to each other and insensitive to being knotted, up to overall powers of g arising from changes of framing of the loop.<sup>3</sup> In particular, compact fundamental Wilson loops are only "interesting" beyond the planar approximation.

On a general manifold  $M_3$ , the planar limit  $w_{\ell}$  of the vevs of fundamental Wilson loops thus only depends on the homotopy class of a framed loop  $\ell$ . It should be possible to define a planar version  $\operatorname{Sk}_{M_3}^p[g]$  of the Skein module restricted to (anti)fundamental Wilson lines and finite tensor products thereof.<sup>4</sup> As correlation functions of fundamental Wilson lines factor to a product of  $w_{\ell}$ 's in the planar limit,  $\operatorname{Sk}_{M_3}^p[g]$  will be a commutative algebra rather than a vector space.

In this language, a large N saddle for  $Z_{M_3}[SU(N)_{\kappa}]$  is labeled by a consistent collection of vevs  $w_{\ell}$ , i.e. a point in the spectrum of  $\operatorname{Sk}_{M_3}^p[g]$ . Ideally, one would like to compute  $\operatorname{Sk}_{M_3}^p[g]$  and match it to the equations of motion of the dual A-model, so that any large N saddle would correspond to an A-model background and vice versa.<sup>5</sup>

As a simple example of this relation, we can take a further  $g \to 1$  "tree-level planar" limit. This limit eliminates the framing dependence and makes the planar skein relations classical. It also eliminates the back-reaction in the holographic dual geometry. The vevs  $w_{\ell}$  satisfy the same relations as the traces of the holonomy of a flat connection on  $M_3$  along a path  $\ell$ .

<span id="page-4-1"></span><sup>&</sup>lt;sup>2</sup>Here we are not being mindful of the (minor) differences between skein relations for  $U(N)_{\kappa}$  and  $SU(N)_{\kappa}$  Wilson loops, which anyway drop away in the planar limit.

<span id="page-4-2"></span> $<sup>^3</sup>$ Even for compact Wilson loops and the associated HOMFLY polynomials, this statement appears to be somewhat non-trivial. It follows, though, from the standard large N combinatorics of multi-trace correlation functions.

<span id="page-4-4"></span><span id="page-4-3"></span><sup>&</sup>lt;sup>4</sup>Perhaps in terms of a Deligne category of  $U_{\mathfrak{q}}(\mathfrak{sl}_N)$  representations [9].

<sup>&</sup>lt;sup>5</sup>Although this structure is a standard expected feature of the 't Hooft expansion, we have not seen it stated in this form in the literature devoted to the large N analysis of Chern-Simons theory. It seems a natural starting point for a mathematical analysis of the problem.

Accordingly, any 3d GL(M) flat connection on M<sup>3</sup> for any non-negative integer M provides a potential tree-level planar saddle: it can be embedded in SU(N) to provide a classical solution of the Chern-Simons equations of motion. These saddles have an intuitive holographic interpretation: a (possibly large) collection of M D-branes in T <sup>∗</sup>M<sup>3</sup> fibered non-trivially over the base. We will not pursue here a further analysis of Sk<sup>p</sup> M<sup>3</sup> [g]. Closed strings are a somewhat rough tool to probe the dual geometry. Instead, we will focus on D-brane probes.

## <span id="page-5-0"></span>1.2 Heavy Wilson lines and D-branes

In this paper we would like to test a "categorical" approach to the 't Hooft expansion [\[10,](#page-104-8) [11\]](#page-104-9), where a large N QFT is probed by additional degrees of freedom transforming in the fundamental representation of the gauge group. Each addition, together with a choice of large N saddle for the vev of mesonic operators, is expected to be dual to a specific D-brane in a tentative String Theory dual description of the system. We dub this a "fundamental modification" of the large N QFT.

If we add multiple fundamental modifications to the large N QFT, we get access to new mesonic operators which are dual to the open string sectors between pairs of D-branes. This data can be compiled into a category of D-branes. This is a physically and mathematically rich object which can be employed to identify or perhaps even define the dual String Theory background.

In 3d Chern-Simons theory, additional degrees of freedom can be supported in one, two or three dimensions. We will focus on the first option: an auxiliary system of N complex fermions supported on a closed loop K in space-time.[6](#page-5-1) This system can be recast as a direct sum W<sup>K</sup> of Wilson loop operators WK,k labeled by the exterior powers Λ <sup>k</sup>C <sup>N</sup> of the fundamental representation of SU(N) and studied with 3d TFT methods [\[14\]](#page-104-10) as colored HOMFLY knot and link invariants [\[15\]](#page-104-11). See Figure [1.](#page-6-0)

A fundamental modification of the CS theory thus takes the form of a Wilson loop W<sup>K</sup> wrapping a knot K (or a collection W<sup>L</sup> of Wilson loops forming a link L), together with a choice of large N saddle for the 't Hooft expansion in the presence of the loop. For compact knots, correlation functions of WK,k satisfy difference equations in k which have a non-trivial planar limit, the augmentation variety of the knot/link [\[16,](#page-104-12) [17\]](#page-104-13), and characterize the possible large N "D-brane" saddles.[7](#page-5-2)

<span id="page-5-1"></span><sup>6</sup>Non-topological modifications in two- and three- will be the subject of two separate publications, embedding large N vector model holography [\[12,](#page-104-14) [13\]](#page-104-15) in the A-model Topological String Theory.

<span id="page-5-2"></span><sup>7</sup>The augmentation variety is usually associated to the planar limit of HOMFLY polynomials colored by symmetric power representations S •C <sup>N</sup> . We prefer to work with Λ•C <sup>N</sup> , but the two options are expected to give rise to the same augmentation variety, up to a minor redefinition of variables. See Appendix [G](#page-101-0) for a detailed comparison.

<span id="page-6-0"></span>![](_page_6_Picture_0.jpeg)

**Figure 1**: Left: the Wilson loop in the shape of a trefoil knot, decorated by the  $\Lambda^k \mathbb{C}^N$  representation. Right: The same knot, decorated by additional meson operators. The meson operators consist of two 1d fermions connected by a fundamental Wilson line (thin line in the Figure). The fermion number k jumps across the fermion insertions, allowing one to derive recursion relations by manipulating the mesons.

The meson operators available to a  $\Lambda^{\bullet}\mathbb{C}^N$  Wilson line take the form of 1d fermion bilinears connected by open Wilson lines in the  $\mathbb{C}^N$  fundamental representation. See Figure 1. We can denote such operators ("rungs") as  $R_{\ell}^{p,p'}$ , with p and p' the starting and ending points on K of the framed open path  $\ell$ . We observe that these operators satisfy skein relations, which imply the above-mentioned difference equations. In the planar limit, these become a collection of "open loop equations" for the vevs  $r_{\ell}^{p,p'}$  of mesons  $(\mathfrak{q} - \mathfrak{q}^{-1})R_{\ell}^{p,p'}$ , which imply and enrich the augmentation variety of the knot.

Mathematically, the open loop equations describe a planar limit  $\operatorname{Sk}_{M_3;K}^p[g;\mu]$  of  $\operatorname{Sk}_{M_3}[SU(N)_{\kappa}]$  where one focuses on the interaction between a  $W_{K;k}$  Wilson loop with fixed  $\mu = \mathfrak{q}^k$  and any number of fundamental Wilson lines.<sup>8</sup>

A general expectation which has been verified for several knots in  $S^3$  is that the augmentation variety as defined above matches the moduli space of D-branes in the resolved conifold which are holographically dual to the knot/link [17–25]. Our main goal is to verify this expectation systematically for arbitrary knots, links and more

<span id="page-6-1"></span>Recall that a Deligne category generalizes the category of finite-dimensional  $U_{\mathfrak{q}}(\mathfrak{sl}_N)$  representations to non-integer N [9]. We believe it should be possible to define a module category for the Deligne which contains a generalization of  $\Lambda^k \mathbb{C}^N$  to non-integer k. It may be an useful starting point for the construction.

general configurations of  $\Lambda^{\bullet}\mathbb{C}^N$  Wilson loops, providing a direct dictionary between the vevs of mesonic operators and the categorical data of dual D-branes. Mathematically, this sort of relation is sometimes referred to as an "augmentation-sheaf correspondence" [26].

Although our main focus will be compact knots, many of the techniques we employ should apply well to more general configurations which probe the geometry of  $M_3$ . The loop equations for the open vevs  $r_{\ell}^{p,p'}$  take the closed  $w_{\ell}$  vevs as an extra input and constrain them. They should determine a dual A-model background equipped with a category of D-branes.

We can briefly review the output of our strategy in the "tree-level planar limit"  $g \to 1$  [27, 28]. In this limit, the loop equations for  $r_{\ell}^{p,p'}$  simplify and reduce to the classical skein relations satisfied by the transport data

$$v_p^R \cdot \left[ \text{Pexp} \oint_{\ell} a \right] \cdot v_{p'}^L,$$
 (1.2)

for an auxiliary  $\operatorname{GL}(M)$  3d flat connection a on  $M_3$  for some positive integer M. The connection has a "minimal" regular singularity wrapping the knot K: the monodromy around the knot has a single non-trivial eigenvalue  $\mu^2 = \mathfrak{q}^{2k}$  which identifies left- and right-eigenlines  $v_p^{L,R}$  at each point p on the knot. The augmentation variety encodes the relation between  $\mu^2$  and the holonomy  $\lambda$  of  $v_p^L$  along the knot.

This monodromy defect can be understood as a Gukov-Witten-like [29] line defect, whose quantization reproduces the  $\Lambda^{\bullet}\mathbb{C}^N$  Wilson lines. The auxiliary 3d connection is simply a solution of the classical Chern-Simons theory equations of motion. Such 3d flat connections typically form a discrete collection. Furthermore, they are a well-known way to describe D-branes in  $T^*M_3$ , the expected dual geometry when the 't Hooft coupling is turned off, which have the expected asymptotic shape determined by the knot [30, 31].

As we turn on g, the skein relations are deformed and the meson vevs acquire an additional dependence on the framing of the open Wilson line. Abstractly, this gives a specific deformation of the category of D-branes in  $T^*M_3$ , which we take as the definition of the category of D-branes in the back-reacted geometry. Our goal is to make this deformation as explicit as possible, and relate it to the expected A-model back-reaction.

## <span id="page-7-0"></span>1.3 Elongated knots and the phase space of D-branes

We can give a rather explicit analysis for compact knots which only explore a local  $\mathbb{R}^3$  geometry. The basic idea is to start from a Schubert presentation of a generic knot, i.e.

<span id="page-8-0"></span>elongate it to a slowly evolving braid closed by cups and caps at the ends. See Figure [2.](#page-8-0)

![](_page_8_Picture_1.jpeg)

Figure 2: The trefoil knot in Schubert presentation.

As an intermediate step in the analysis, we study the properties of rungs attached to m = 2n parallel Λ•C <sup>N</sup> Wilson lines with the help of "quantum skew Howe duality" [\[32\]](#page-105-7). We find it useful to compactify the transverse directions to an S 2 . The planar open loop equations satisfied by the rung vevs then define a complex symplectic "phase space" Pm,n.

We analyze Pm,n in depth and identify it with a moduli space of 2d GL(n) flat connections with minimal regular singularities at the locations of the m strands and a constant monodromy g <sup>2</sup> at infinity. This is a non-trivial deformation of the characterization we gave in the tree-level planar limit, which had the same type of minimal regular singularities but monodromy 1 at infinity.

Furthermore, we also identify Pm,n as the phase space of D-branes with the expected asymptotic shape in the A-model geometry

$$\mathcal{M}_t \times T^* \mathbb{R} \,, \tag{1.3}$$

conjecturally dual to CS theory in S <sup>2</sup> × R, where M<sup>t</sup> is the deformed A<sup>1</sup> singularity. This makes the planar holographic dictionary fully explicit for time-independent configurations of Λ•C <sup>N</sup> Wilson lines and D-branes.

This dictionary survives when the Λ•C <sup>N</sup> strands are slowly braided, giving a slow evolution of the corresponding D-branes. In order to complete the analysis of a generic knot in the Schubert presentation, we also describe explicitly the constraints on the rung vevs enforced by the cups and caps.

With some extra work, the constraints can be formulated as a local "gluing" relation between the 2d local system data associated with the vertical strands before and after the fusion of two strands. The gluing relations are a peculiar deformation of the g → 1 relations which would assemble a sequence of 2d flat connections into a single 3d flat connection.[9](#page-9-1)

We expect the sequence of 2d local systems and gluing relations associated with a given open saddle to define some kind of three-dimensional "constructible sheaf" which could be used to describe a 3d D-brane in M<sup>t</sup> × T <sup>∗</sup>R from the data of 2d slices. A proof of this conjecture goes beyond our current expertise, but we provide all the local ingredients we expect to go into such a construction.

## <span id="page-9-0"></span>1.4 Other constructions and knot presentations

A knot or link K can be represented as a braid closure, i.e. a braid with the endpoints connected together. This can be seen as a special case of a Schubert presentation: we add to the r strands of the braid another set of r strands with opposite labels representing the original strands looping back, and connect the original strands and new strands pairwise by cups and caps. See Figure [3.](#page-9-2) Accordingly, the augmentation variety can be computed as described above, using P2r,r.

<span id="page-9-2"></span>![](_page_9_Picture_4.jpeg)

Figure 3: A schematic depiction of a knot presented as a braid closure.

The phase spaces Pm,n can be useful beyond the study of elongated knots. If we cut any compact knot or link by a plane cutting n strands, the rung vevs in the

<span id="page-9-1"></span><sup>9</sup> It is possible to decompose the cups and caps into a two-step process: the two strands are first fused into a single strand, which is then forced to be trivial. The first operation is the same as for g → 1, but the second is deformed.

neighborhood of the plane will determine a point in P2n,n. One can describe explicitly how the point varies as a function of the choice of plane. This should give some kind of "Radon transform" of the dual D-brane, capturing 2d sections of all possible orientations.

Our tools can also be specialized to the study of closed braids in M<sup>3</sup> = S <sup>2</sup> × S 1 . Quantum mechanically, the braid operations on m strands are implemented by unitary operators on the finite-dimensional Hilbert space of the CS theory on S <sup>2</sup> and the S <sup>2</sup>×S 1 correlation function computes the trace of these operators.

In the planar limit, the meson vevs evolve along S <sup>1</sup> by a combination of the braid group action and a certain rescaling parameterized by λ. A planar saddle is thus labelled by a point in Pm,n which comes back to itself under that transformation. Geometrically, we find an S 1 family of 2d GL(n) flat connections on the (m + 1)-punctured sphere, with holonomy g <sup>2</sup> at infinity and m extra minimal regular punctures, whose holonomy remains locally constant as the position of the punctures is braided continuously along S 1 .

This is the same as the data of a 3d GL(n) flat connection on S <sup>2</sup> × S <sup>1</sup> with appropriate co-dimension 1 regular singularities. It maps directly to the data of an A-model D-brane in

$$\mathcal{M}_t \times T^* S^1 \,, \tag{1.4}$$

with asymptotic shape controlled by the braid. We thus have a fully explicit match between open planar large N saddles and dual D-branes for this geometry as well.

Finally, it is interesting to observe that the phase spaces Pm,n which appear in our planar analysis have a reasonably canonical quantization [\[33\]](#page-105-8) as skein algebras Sk[U(n)] on the (m + 1)-punctured sphere, which reproduces the algebra of rung operators in the dual SU(N)<sup>κ</sup> CS theory. When N is an integer, we expect unitarity to constrain the possible representations of this algebra to coincide with the Hilbert space of the dual SU(N)<sup>κ</sup> CS theory. Accordingly, it seems plausible to conjecture that our planar holographic dictionary can be uniquely extended beyond the planar approximation. An important step would be to constrain the quantization of the Lagrangian submanifolds in Pm,n which encode the planar cup and cap constraints.

## <span id="page-10-0"></span>1.5 D-branes and symplectic geometry

The algebraic tools we employ in this paper lead us to describe A-model D-branes as flat connections/constructible sheaves, including the geometric back-reaction as a deformation of these notions. A more traditional approach is to describe A-branes in terms of symplectic geometry, Lagrangian submanifolds, and counting of pseudoholomorphic curves ending on them.

In particular, the "symplectic" version of the augmentation variety is defined in terms of a Differential Graded Algebra (DGA) associated with the knot, which has a curve-counting definition but also a combinatorial presentation involving the braid closure presentation of a knot. See [\[34\]](#page-105-9) for a review of the construction.

The ingredients of this combinatorial presentation closely resemble our computational tools, with auxiliary variables which behave under braiding in the same way as rung vevs. It should be possible to match the two presentations in detail and thus demonstrate that the planar limit of Λ•C <sup>N</sup> knot invariants matches the augmentation variety computed from symplectic geometry.

## <span id="page-11-0"></span>1.6 Structure of the Paper

Section [2](#page-11-1) discusses the large N expansion of Λ<sup>k</sup>C <sup>N</sup> Wilson line correlation functions in SU(N)<sup>κ</sup> Chern-Simons theory, aka colored HOMFLY polynomials. Section [3](#page-19-0) discusses the relation between elongated knots/links and Uq(glm) and its planar limit as a phase space. Section [4](#page-34-0) discusses how to assemble the rung vev data into the data of a 2d flat connection. Section [5](#page-41-0) discusses the A-model interpretation of the Uq(glm) constructions. Section [6](#page-50-0) reviews our conclusions and discusses some possible future research directions.

Appendix [A](#page-53-0) recalls constructions in Supersymmetric Quantum Field Theory with eight supercharges which help characterize Pm,n and its quantization. Appendix [B](#page-65-0) discusses SQFT interfaces which help characterize Lagrangian correspondences between Pm,n's. Appendix [C](#page-69-0) discusses the relation between the algebra of mesonic operators and quantum groups. Appendix [D](#page-77-0) discusses the planar limit of the algebraic results derived in Appendix [C.](#page-69-0) Appendix [E](#page-82-1) reviews some results of [\[32\]](#page-105-7) and their planar limit. Appendix [F](#page-94-0) lists the augmentation varieties we computed for several knots. Appendix [G](#page-101-0) compares our results with the recursion relations of HOMFLY polynomials and previous literature.

## <span id="page-11-1"></span>2 Chern-Simons theory and the 't Hooft expansion

Calculations in SU(N)<sup>κ</sup> Chern-Simons theory which employ TFT technology, such as partition functions on non-trivial manifolds and correlation functions of Wilson loop operators, are naturally expressed in terms of the parameter

$$\mathfrak{q} = e^{\frac{i\pi}{\kappa + N}} \,, \tag{2.1}$$

giving a useful re-summation of the standard perturbative expansion in κ −1 . [10](#page-11-2)

<span id="page-11-2"></span><sup>10</sup>In some situations, the fractional power q 1 <sup>N</sup> will appear. This can be avoided by working with an U(N)<sup>κ</sup> gauge group, but we prefer not to do so.

We will often encounter the combination

$$\mathfrak{q}^N = e^{i\pi \frac{N}{\kappa + N}} \equiv g. \tag{2.2}$$

This is a convenient repackaging of the 't Hooft coupling. In the planar limit, we send q → 1 while keeping g = q <sup>N</sup> fixed.

Wilson loop operators Wℓ,R compute the trace in some representation R of the holonomy of the gauge connection along a framed closed path ℓ:

$$W_{\ell,R} = \operatorname{Tr}_R \operatorname{Pexp} \oint_{\ell} A$$
. (2.3)

An important property of CS theory is that a collection of loop operators supported in a ball (whose boundary is not intersecting other defects) will contribute to a correlation function in a manner independent of the rest of the setup:

$$\langle W_{\ell,R} \rangle \equiv \frac{\langle W_{\ell,R} \rangle_{M_3}}{\langle 1 \rangle_{M_3}} \tag{2.4}$$

does not depend on the choice of space-time three-manifold M<sup>3</sup> and can be computed e.g. on S 3 . These correlation functions for a knotted Wilson loop or multiple linked loops will be our main topic of interest.

## <span id="page-12-0"></span>2.1 Fundamental Wilson loops

As an instructive example, consider a fundamental Wilson loop in the shape of an unknot (i.e. a circle):

$$\langle W_{\mathbf{O},\mathbb{C}^N} \rangle = [N]_{\mathfrak{q}} = \frac{\mathfrak{q}^N - \mathfrak{q}^{-N}}{\mathfrak{q} - \mathfrak{q}^{-1}}.$$
 (2.5)

This has a reasonable behavior in the planar limit: a fundamental Wilson line is a (somewhat peculiar) single-trace operator. In the 't Hooft expansion, such an operator scales as N. The rescaled operator (q − q −1 )W ,C<sup>N</sup> has a finite limit

$$w_{\mathbf{O}} = g - g^{-1}$$
. (2.6)

Although the expectation value of a fundamental Wilson loop depends non-trivially on its topology, giving rise to the HOMFLY knot and link invariants, much of the topology washes away in the planar limit: the expectation value of s loops rescaled by (q − q −1 ) <sup>s</sup> always limits to (g − g −1 ) s g f for some integer f. [11](#page-12-1)

<span id="page-12-1"></span><sup>11</sup>It is easy to see that two loops can be unlinked, as the skein relation for passing a loop through the other gives (q−q −1 ) times a term with a single loop, resulting in a total suppression of (q−q −1 ) 2 . Verifying that the vev of individual loops only depends on the shape through a power of g takes a bit more work. It must be true because of the combinatorics of the large N expansion.

In either case, the interesting topological content of the HOMFLY invariants is hidden in the subleading terms of the planar expansion. Verifying this aspect of the holographic duality for Chern-Simons theory thus requires an intricate analysis of higher genus amplitudes in the A-model topological string theory. We will not pursue that objective in this paper.

## <span id="page-13-0"></span>2.2 Heavy Wilson lines

The analogous quantity for a higher anti-symmetric power of the fundamental representation is

$$\langle W_{\mathbf{O},\Lambda^k\mathbb{C}^N} \rangle = \begin{bmatrix} N \\ k \end{bmatrix}_{\mathfrak{q}} = \frac{[N]_{\mathfrak{q}} \cdots [N-k+1]_{\mathfrak{q}}}{[k]_{\mathfrak{q}} \cdots [1]_{\mathfrak{q}}}.$$
 (2.7)

As mentioned in the Introduction, we are interested in Wilson loops defined via 1d free fermions, with action

$$\int_{\ell} \left[ \bar{\psi}\dot{\psi} - \bar{\psi}A\psi - a\bar{\psi}\psi \right] . \tag{2.8}$$

We included a U(1) background connection a with holonomy λ coupling to the fermion number to keep track of the irreducible pieces in the fermionic Fock space Λ•C N .

The resulting loop operator is a trace on Λ•C <sup>N</sup> , i.e. a sum of traces in Λ<sup>k</sup>C N weighted by (−λ) k . [12](#page-13-1) This gives a generating function of antisymmetric Wilson loop correlation functions:

$$\langle W_{\mathbf{O}}(\lambda) \rangle \equiv \sum_{k=0}^{N} (-\lambda)^{k} \langle W_{\mathbf{O},\Lambda^{k}\mathbb{C}^{N}} \rangle = \prod_{k=1}^{N} \left( 1 - \lambda \,\mathfrak{q}^{2k-N-1} \right) \,. \tag{2.9}$$

The definition in terms of auxiliary fundamental degrees of freedom makes it clear that W (λ) will behave in the planar limit as an open string partition function for some kind of D-brane:

<span id="page-13-2"></span>
$$\frac{i\pi}{\kappa + N} \log \langle W_{\mathbf{O}}(\lambda) \rangle \sim S_{\mathbf{O}}^{\text{open}}(\lambda).$$
 (2.10)

Here it is not difficult to compute the planar limit

$$S_{\mathbf{O}}^{\text{open}}(\lambda) = \int_0^{\log g} d\sigma \log \left(1 - \lambda g^{-1} e^{2\sigma}\right) = \frac{1}{2} \text{Li}_2(\lambda g^{-1}) - \frac{1}{2} \text{Li}_2(\lambda g). \tag{2.11}$$

The logarithmic derivative

<span id="page-13-3"></span>
$$\log \mu \equiv \lambda \partial_{\lambda} S_{\mathbf{O}}^{\text{open}}(\lambda) \tag{2.12}$$

<span id="page-13-1"></span><sup>12</sup>We use conventions where the fermions are periodic around the loop, so we include a factor of (−1)<sup>F</sup> in the trace.

is nicer:

$$\mu^2 = \frac{1 - \lambda g}{1 - \lambda g^{-1}} \,. \tag{2.13}$$

The inverse relation

$$\lambda = -\frac{\mu - \mu^{-1}}{g\mu^{-1} - g^{-1}\mu} \tag{2.14}$$

reflects the recursion relation:

$$\langle W_{\mathbf{O},\Lambda^k\mathbb{C}^N} \rangle = \frac{[N-k+1]_{\mathfrak{q}}}{[k]_{\mathfrak{q}}} \langle W_{\mathbf{O},\Lambda^{k-1}\mathbb{C}^N} \rangle = \frac{\mathfrak{q}^{N-k+1} - \mathfrak{q}^{k-N-1}}{\mathfrak{q}^k - \mathfrak{q}^{-k}} \langle W_{\mathbf{O},\Lambda^{k-1}\mathbb{C}^N} \rangle , \quad (2.15)$$

whose coefficients are nice functions of q, g = q <sup>N</sup> and µ = q k . We can also compute directly

$$\frac{i\pi}{\kappa + N} \log \langle W_{\mathbf{O}, \Lambda^k \mathbb{C}^N} \rangle \sim \int_0^{\log \mu} d\sigma \left( \log(ge^{-\sigma} - g^{-1}e^{\sigma}) - \log(e^{\sigma} - e^{-\sigma}) \right) . \tag{2.16}$$

We see that both ⟨W (λ)⟩ as a function of λ and ⟨W ,ΛkC<sup>N</sup> ⟩ as a function of µ = q k have good planar limits, related by a Legendre transform.

A particularly useful formulation [\[17\]](#page-104-13) of the planar limit expresses the relation between λ and µ as a Lagrangian submanifold L ⊂ C <sup>∗</sup> × C ∗ , with symplectic form d logλ d logµ:

$$g^{-1}\mu\lambda - \mu + \mu^{-1} - g\mu^{-1}\lambda = 0. {(2.17)}$$

We will call this the augmentation variety of the unknot.[13](#page-14-0)

One expects an analogous planar limit for correlation functions ⟨WK,ΛkC<sup>N</sup> ⟩ and ⟨WK(λ)⟩ associated with any knot K, leading to more intricate augmentation varieties L<sup>K</sup> ⊂ C <sup>∗</sup>×C ∗ . Experimentally, L<sup>K</sup> is always defined as the vanishing locus of a Laurent polynomial in µ, λ and g, with remarkable relations to the theory of cluster varieties and to spaces of vacua of 3d N = 2 gauge theories compactified on a circle [\[35\]](#page-105-10).

Similarly, the correlation function

$$\langle W_{L;\Lambda^{k_1}\mathbb{C}^N,\dots,\Lambda^{k_n}\mathbb{C}^N} \rangle \tag{2.18}$$

of a collection L of linked Wilson lines or the dual generating function

$$\langle W_L(\lambda_1, \dots, \lambda_n) \rangle$$
 (2.19)

<span id="page-14-0"></span><sup>13</sup>This is a slight abuse of language: strictly speaking the augmentation variety describes the result of a geometric calculation which should reproduce the moduli space of A-model D-branes dual to the large N saddles [\[17\]](#page-104-13). What is defined here is a QFT quantity which should conjecturally match the augmentation variety.

will have a planar limit controlled by the relation between  $\mu_i = \mathfrak{q}^{k_i}$  and  $\lambda_i$ , defining a complex Lagrangian augmentation variety  $\mathcal{L}_L \subset (\mathbb{C}^* \times \mathbb{C}^*)^n$ .

A general goal is to reproduce the augmentation variety of a generic knot/link from the classical geometry of D-branes in the dual String Theory description of the system, using tools which could be generalized to Wilson loops in a general  $M_3$ . Ideally, both sides should be described in a purely algebraic manner, to allow for further generalizations to non-geometric examples of Holography.

#### <span id="page-15-0"></span>2.3 Mesonic operators and recursion relations

We now recall an important aspect of the planar expansion, which was beautifully illustrated in the study of "giant graviton" D-branes [11, 36, 37]: the 't Hooft expansion in the presence of fundamental modifications depends on a choice of large N D-brane saddle described by the expectation values of meson operators.

In the case at hand, meson operators are bilinears of 1d fermions, possibly supported on different Wilson lines or at different locations of a single Wilson line. Gauge invariance requires the fermion insertions to be joined by open fundamental Wilson lines, supported on some path  $\ell$  in the complement of the original knot/link. This defines the mesonic operators  $R_{\ell}^{p,p'}$  mentioned in the introduction. To avoid confusion, we will refer to the original  $\Lambda^{\bullet}\mathbb{C}^N$  Wilson lines as "strands" and the ones appearing in mesonic operators as "rungs". Note that the  $k_i$  labels on the strands jump by  $\pm 1$  across fermion insertions.

At the leading order in the 't Hooft expansion, each mesonic operator insertion can be dressed by a factor of  $(\mathfrak{q} - \mathfrak{q}^{-1})$  and then replaced by a finite vev  $r_\ell^{p,p'}$ , which is independent of the presence of other mesonic insertions. The only subtlety is a "charge conservation" constraint: the total number of fermion and anti-fermion insertions along a strand must be 0 for the rule to apply, otherwise the correlation function vanishes. As a consequence, the  $r_\ell^{p,p'}$  rung vevs are only up to a collective rescaling

$$r_{\ell}^{p,p'} \to r_{\ell}^{p,p'} c_p c_{p'}^{-1}$$
 (2.20)

where  $c_p$  is an invertible locally constant function on K. It is convenient to treat the  $r_{\ell}^{p,p'}$  as sections of some flat line bundle on K with holonomy  $\lambda$ , promoting the rescaling to a local GL(1) gauge invariance along K.

We identify fermionic insertions (in some implicit renormalization scheme) with special cases of the

$$W_{\Lambda^k \mathbb{C}^N} \times W_{\Lambda^l \mathbb{C}^N} \leftrightarrow W_{\Lambda^{k+l} \mathbb{C}^N} \tag{2.21}$$

trivalent junctions defined and studied in [32] with the help of the representation theory of the  $U_{\mathfrak{q}}(\mathfrak{sl}_N)$  quantum group. The main difference between our setup and the reference

is that we will assign Grassmann parity k mod 2 to the representations Λ<sup>k</sup>C <sup>N</sup> , which results in some extra signs detailed below. From this point on, we will assume N is even, so that the trivial Λ<sup>N</sup> C <sup>N</sup> representation has the same Grassmann parity as Λ<sup>0</sup>C N .

The reference gives us a collection of local rules, which we can employ to reorganize the topology of a collection of mesonic insertions, say by moving endpoints across each other, passing a fundamental rung across other rungs or strands, and creating/removing contractible rungs. See Appendix [C](#page-69-0) for a detailed discussion.

<span id="page-16-0"></span>As a simple example, consider the unknot with a single contractible mesonic insertion. See Figure [4.](#page-16-0) This can be contracted in two inequivalent manners, using either of the two "bubble removal" rules from Figure [5.](#page-16-1) The result is the crucial recursion relation we encountered before:

$$[k]_{\mathfrak{q}}\langle W_{\mathbf{O},\Lambda^k\mathbb{C}^N}\rangle = [N-k+1]_{\mathfrak{q}}\langle W_{\mathbf{O},\Lambda^{k-1}\mathbb{C}^N}\rangle. \tag{2.22}$$

![](_page_16_Picture_4.jpeg)

Figure 4: Unknot with a mesonic insertion.

<span id="page-16-1"></span>![](_page_16_Picture_6.jpeg)

Figure 5: The "bubble removal" rules.

We can attempt a similar manipulation for any knot K, starting from a contractible meson insertion onto a loop with label k and deforming it to a contractible insertion on a loop with label k − 1. In the process, we will typically need to pass the rung across K or itself multiple times, producing additional terms with multiple rung insertions. We can then attempt to contract away the extra rungs, etc.

At finite N, this procedure will create an increasing collection of linear relations between correlation functions with multiple rung insertions ("open loop equations"). We will demonstrate later on that this procedure ends: all decorated correlation functions can be reduced to undecorated ones, and in the process they determine the ⟨WK;ΛkC<sup>N</sup> ⟩ correlation functions for all k.

We will learn how to take the planar limit of each elementary operation in the process, so that the planar open loop equations can be derived without any finite N intermediate step. The result is a collection of polynomial relations between rung vevs r p,p′ ℓ , with coefficients which are Laurent polynomials in µ, λ and g. Eliminating the rungs, we obtain relations which we expect to reproduce the augmentation variety LK. A similar strategy can be applied to links and even "networks" of Λ•C <sup>N</sup> Wilson lines joined at junctions.

## <span id="page-17-0"></span>2.4 Planar tree-level

As mentioned in the Introduction, the planar open loop equations simplify further in the g → 1 limit ("tree-level planar limit"). In that limit (adjusting some signs):

- 1. The framing of open fundamental lines is immaterial.
- 2. The difference between a rung over-crossing a strand from the right and undercrossing it is the combination of two rungs ending and starting on that strand:

$$\begin{array}{cccccccccccccccccccccccccccccccccccc$$

3. Rotating the endpoint of a rung by an angle of π around a strand costs a factor of µ associated to that strand.

The relations satisfied by the rung vevs precisely reproduce the relations satisfied by the transport coefficients of certain 3d flat connections defined on the complement of the knot.

Indeed, consider a 3d flat connection whose monodromy M<sup>p</sup> around the knot at a point p satisfies

$$M_p = 1 + v_p^L v_p^R \,, (2.25)$$

for a left eigenvector v L p and a right eigenvector v R p , normalized so that

$$v_p^R \cdot v_p^L = \mu^2 - 1, (2.26)$$

where µ 2 is the non-trivial monodromy eigenvalue. This is a "minimal regular" defect for a 3d flat connection.

Given such a connection, we can associate to each open path  $\ell$  between points p and p' on the knot the inner product  $t_{\ell} \equiv v_p^R \cdot v_{p'}^L$  computed along  $\ell$ .<sup>14</sup> We can also define traces of the holonomy along closed paths  $\ell$ . These quantities satisfy simple relations when  $\ell$  is carried across the knot. For example,  $t_{\ell}$  jumps by a product of two t's ending at the intersection point. They also get multiplied by  $\mu^2$  whenever the endpoints of  $\ell$  rotate around the knot.

These relations are identical to the tree-level planar skein relations, with the rung vev  $r_{\ell}^{p,p'}$  identified with  $t_{\ell}$ . We thus find a one-to-one correspondence between tree-level planar saddles for  $W_{K,\Lambda^{\bullet}\mathbb{C}^N}$  and representations of the knot group, i.e. the fundamental group of the knot complement  $M_3/K$ , with minimal regular holonomy around the knot. The  $\lambda$  parameter is read off as the holonomy of  $v^L$  along the knot.

As we also mentioned in the Introduction and we will review further in the second half of the paper, the holographic dual description of  $W_{K,\Lambda^{\bullet}\mathbb{C}^N}$  in the tree-level planar limit involves A-model D-branes in  $T^*M_3$  which go to infinity along the co-normal bundle to K. Such D-branes can be directly defined in terms of 3d flat connections on the knot complement, bypassing a geometric description.

The tree-level planar skein relations are sometimes organized into the definition of a "chord algebra" [28], which at least for  $M_3 = S^3$  is proven to match the construction of Lagrangian sub-manifolds in  $T^*S^3$  with appropriate asymptotics.

It is interesting to compare the considerable amount of mathematical effort required to obtain such geometric descriptions of the dual D-branes and the relatively straightforward presentation as 3d flat connections. Mathematically, the latter description uses implicitly some powerful theorems about A-branes [31]. Physically, it describes complicated configurations of D-branes as a systematic deformation of simpler ones.

As a simple example of this discussion, consider the trefoil knot from Figure 1. The fundamental group of the knot complement is well known. Define some generators a, b and c associated with loops that start above the figure and pass behind one of the three arcs in the picture, from right to left if the strand is pointing upwards. Then we have relations  $a = cbc^{-1}$ ,  $b = aca^{-1}$ , and  $c = bab^{-1}$  around the three crossings.

If we write  $M_a = 1 + v_a^L v_a^R$ , etcetera, as the corresponding monodromy matrices, the relations become

$$v_a^L \left[ v_a^R + (v_a^R \cdot v_c^L) v_c^R \right] = \left[ v_b^L + (v_c^R \cdot v_b^L) v_c^L \right] v_b^R, \tag{2.27}$$

and cyclic rotations thereof. Contracting these relations with all possible  $v^L$ 's and  $v^R$ 's gives cubic relations among inner products, which reproduce all the non-trivial skein relations available near each of the three crossings.

<span id="page-18-0"></span> $<sup>^{-14}</sup>$ In order to lighten the notation, we leave implicit the path-ordered exponential computing the holonomy from p' to p along  $\ell$ .

All three M's have the same non-trivial eigenvalue µ 2 . The monodromy λ of the eigenline can be computed by following a full loop, as the action of McMbM<sup>a</sup> on the eigenline vb. But that is the same as µ <sup>2</sup>M<sup>2</sup> c vb, so v<sup>b</sup> is an eigenvector of M<sup>2</sup> c . It is easy to see that unless µ <sup>2</sup> = 1, the only option is for all three vectors to be proportional to each other, and thus λ = µ 6 is the g → 1 augmentation variety. The 3d flat connection can be taken to have rank 1.

## <span id="page-19-0"></span>3 The rung algebra as a quantum group

In order to systematize the process further, we now "elongate" the knot/link along the x <sup>3</sup> direction to reduce it to a sequence of braiding and fusion operations on collections of parallel strands.

For most values of x 3 , we keep the strands close to the x <sup>2</sup> = 0 plane, well-separated along the x <sup>1</sup> direction and pointing towards positive x 3 . We braid individual pairs of strands at definite locations along x 3 . We end consecutive pairs of strands at large positive and negative x <sup>3</sup> by smooth "cups" and "caps". See Figures [6](#page-19-1) and [7.](#page-20-0)

<span id="page-19-1"></span>![](_page_19_Picture_4.jpeg)

Figure 6: Left: The elongated unknot. The "tags" on the semi-circles represent a fusion into the trivial Λ<sup>N</sup> C <sup>N</sup> representation, in the convention of [\[32\]](#page-105-7). They are useful in keeping track of some important signs. This convention produces the standard unknot times (−1)<sup>k</sup> . Middle and right: the two non-trivial rungs "E" and "F" which can be placed at some x 3 . Above the E rung, the left and right labels are k + 1 and N − k − 1 respectively.

The basic idea is to first characterize the behavior of rungs localized at some fixed generic x 3 , then relate rungs above and below braid operations, and then analyze the interaction between rungs and strands.

Accordingly, consider a collection of m parallel strands extended along the x <sup>3</sup> direction and placed at x <sup>2</sup> = 0 with a specific relative order along the x <sup>1</sup> direction, each defined from a set of N complex fermions. We can define a "rung algebra" over Z[q, q −1 ], whose elements are collections of fundamental rungs supported within a finite

<span id="page-20-0"></span>![](_page_20_Picture_0.jpeg)

Figure 7: Unknot with a twist. The choice of tags produces again an extra factor of (−1)<sup>k</sup> .

x 3 interval, modulo local manipulations. We add to the algebra the evaluation operators K<sup>±</sup><sup>1</sup> <sup>i</sup> = q ±k<sup>i</sup> , which read out the fermion number along each strand. The algebra operation is simply concatenation along the x <sup>3</sup> direction.

Following [\[32\]](#page-105-7), we can generate the whole algebra from rungs E<sup>i</sup> and F<sup>i</sup> stretched between consecutive strands, together with the K<sup>±</sup><sup>1</sup> i . As reviewed in Appendix [C,](#page-69-0) these generators satisfy relations independent of N which coincide with the standard definition of the quantum group Uq(glm). They also satisfy some extra relations depending on N, characteristic of the representation of Uq(glm) on the N-th power of Λ•C m.

<span id="page-20-1"></span>The quantum group Uq(glm) has a "PBW" linear basis consisting of normal-ordered products of K<sup>±</sup><sup>1</sup> i as well as m(m−1) generators E<sup>−</sup>;i,j and F<sup>−</sup>;i,j , which we can identify with rung operators that join any pair of strands while passing behind intermediate strands. See Figure [8.](#page-20-1)

![](_page_20_Figure_5.jpeg)

Figure 8: The F<sup>−</sup>;1,3E<sup>−</sup>;4,<sup>2</sup> operator.

The identification of basis elements with combinations of rungs allows us to formulate a simple proposal for the planar limit of the rung algebra: the rescaled rungs

$$e_{-;i,j} \equiv (\mathfrak{q} - \mathfrak{q}^{-1}) E_{-;i,j}$$
  $f_{-;i,j} \equiv (\mathfrak{q} - \mathfrak{q}^{-1}) F_{-;i,j}$ , (3.1)

and K<sup>i</sup> all have a good planar limit.

As commutators of the above generators are all proportional to (q − q −1 ), the planar limit is a classical limit of Uq(glm) in the sense of deformation quantization: we can define a Poisson algebra consisting of polynomials in e<sup>−</sup>;i,j , f<sup>−</sup>;i,j and K<sup>±</sup> i , with a Poisson bracket that captures the leading term in the commutators.

This is interpreted as the Poisson algebra of holomorphic functions on a complex phase space Pm, which is denoted in the mathematical literature as the dual Poisson Lie group GL<sup>∗</sup> <sup>m</sup>: the space of pairs of upper triangular and lower triangular matrices with equal diagonal. See Appendix [D](#page-77-0) for details. We will come back to reality conditions on rung vevs at a later stage.

This has the following implication. Take some knot or link L and slice it by a plane intersecting m strands, roughly ordered along a line. If the strands point in the wrong direction, we can flip them by the duality operation k → N −k at the price of inserting "tags" as detailed in [\[32\]](#page-105-7). Then the information contained in the planar vevs of all the possible rungs drawn in the neighborhood of the plane can be distilled into a point in Pm.

Using the rules of [\[32\]](#page-105-7), we can compute what happens when a rung operator is transported across a braid, as well as relations between rung operators which appear when they are brought to a collection of cups or caps. We do so in Appendix [C.](#page-69-0) The relations we find have a good planar limit. They give an action of the braid group on P<sup>m</sup> [\[38\]](#page-106-2) and constraints on rung vevs enforced by cups and caps. The relations define certain submanifolds

$$\mathcal{L}_{\text{cups}} \subset \mathcal{P}_m \times (\mathbb{C}^*)^{2s}$$
, (3.2)

and Lcaps ⊂ Pm. The (C ∗ ) 2s factor contains the information about µ and λ for the s connected components of the link. We find the augmentation variety L<sup>K</sup> by intersecting these constraints. Schematically:[15](#page-21-0)

<span id="page-21-1"></span>
$$\mathcal{L}_K = \mathcal{L}_{\text{caps}} \cap (B_{\text{braid}} \circ \mathcal{L}_{\text{cups}}) \subset (\mathbb{C}^*)^{2s} \,. \tag{3.3}$$

The braid group action on P<sup>m</sup> is rather intuitive: the rung endpoints are braided in the obvious way following the strands, we apply skein relations if needed to push the rungs behind the strands, and include some extra framing factors when the horizontal orientation of a rung is flipped. The cup and cap constraints are less intuitive. We will come back to them momentarily.

<span id="page-21-0"></span><sup>15</sup>Strictly speaking, the intersection contains a bit more information than the augmentation variety: a given point in L<sup>K</sup> may lift to multiple points in Pm. We have not seen this happen in examples, but it is a possibility.

At first sight, it is not obvious that this computational scheme should always produce the desired outcome. For example, one may wonder if skein relations involving non-horizontal rungs may impose further constraints. The Lagrangian nature of the augmentation variety for links is also not manifest.

We will now address these concerns by taking into account some extra constraints on rung vevs which hold for any compact knot, link or network.

## <span id="page-22-0"></span>3.1 Casimir operators and charge at infinity

The Uq(glm) has m Casimir elements which generate the center. With some work, it is possible to relate these Casimir elements to the vevs of circular Wilson loops which wrap around the whole collection of m strands. These can be expressed in terms of rungs via skein relations but also obviously commute with any other rung operators.

When the strands are part of a compact knot, these circular Wilson loops are contractible and have a vev equal to the quantum dimension of their representation label. This constrains the Casimir elements of Uq(glm) to specific values. There are also further constraints. For example, an E<sup>−</sup>;m,<sup>1</sup> generator could be passed below the rest of the knot to become a rung passing in front of all strands and then pushed across the strands with skein relations, giving an extra polynomial constraint. Or a circular Wilson loop surrounding the first s strands can be deformed to a loop surrounding the remaining m − s.

These constraints are most easily characterized by compactifying the directions transverse to the strands to an S 2 . This operation makes no difference for compact knots, as their vev would be the same in R <sup>3</sup> and in S <sup>2</sup> × R. It allows us to introduce a useful environment for our calculations: the Hilbert space of the system of m Wilson lines in S 2 .

The Hilbert space can be computed by borrowing another result from [\[32\]](#page-105-7), as the Uq(sl<sup>N</sup> )-invariant part of the tensor product Λ•C mN of representations associated with individual strands. This is the quantum-corrected version of the naive classical answer in Chern-Simons gauge theory: the SL(N)-invariant part of the Fock space for the system of 1d fermions.

Namely, "Quantum Skew Howe Duality" decomposes the exterior algebra Λ•C mN as a direct sum of products of irreducible representations of Uq(sl<sup>N</sup> ) and Uq(glm):

$$\Lambda^{\bullet} \mathbb{C}^{mN} = \bigoplus_{Y} R_{Y}[\mathfrak{sl}_{N}] \otimes R_{Y^{t}}[\mathfrak{gl}_{m}]$$
(3.4)

where Y is a Young Tableau fitting in an m × N rectangle, R<sup>Y</sup> [sl<sup>N</sup> ] is the irreducible representation of Uq(sl<sup>N</sup> ) labelled by Y and R<sup>Y</sup> <sup>t</sup> [glm] is the irreducible representation of Uq(glm) labeled by the transpose Young Tableau.

In order for R<sup>Y</sup> [sl<sup>N</sup> ] to be the trivial representation, Y must be a rectangle with height N. We will denote as n the number or columns. The Hilbert space is thus a direct sum of irreducible finite-dimensional unitary representations Hm,n of Uq(glm), labeled by rectangular Young Tableaux with N columns of height n ranging from 0 to m. The sum of the strands' labels in each sector is nN, so strands belonging to a knot or link have n = m/2. We will sometimes consider more general compact networks of Λ •C <sup>N</sup> Wilson lines, for which other values of n are possible. Extreme cases n = 0 and n = m correspond to setting all labels to 0 or N, which are configurations annihilated by all of the E<sup>i</sup> and F<sup>i</sup> rung operators.

A collection of "cups", or any other way to end a collection of m strands with total label nN, creates by definition a state in Hm,n. The braid operations also act as linear operators on Hm,n. The vev of an elongated knot, link or network K can be computed as the expectation value of a braid operator between states built by cups and caps. Schematically:

<span id="page-23-0"></span>
$$\langle K \rangle = \langle \text{caps} | B_{\text{braid}} | \text{cups} \rangle.$$
 (3.5)

As the Hilbert space Hm,n is an irreducible representation of Uq(glm), the inner products between any two states are uniquely determined by the Uq(glm) action on the states.

As we will illustrate in examples, this means that the norm of cup and cap states and the expectation values of braid operators between cup and cap states are uniquely determined by recursion relations produced by comparing the action of horizontal rung operators on the future and past of the knot, using the results of Appendix [C.](#page-69-0)

The planar computational strategy [\(3.3\)](#page-21-1) is thus the classical limit of the finite N computation [\(3.5\)](#page-23-0). Both the finite N and planar computations benefit from a further observation: the rung operators satisfy extra relations when acting on Hm,n. At finite N, the relations define a quotient Am,n of Uq(glm), a simpler algebra acting irreducibly on Hm,n.

More importantly for us, the planar relations cut out a complex symplectic slice Pm,n of P<sup>m</sup> (the planar limit of Am,n) and all of the ingredients of [\(3.3\)](#page-21-1) can be defined within Pm,n. Determining the explicit form of Am,n and Pm,n is an interesting exercise in representation theory. We bypass the exercise by invoking some Supersymmetric Quantum Field Theory technology in Appendix [A.](#page-53-0)

Namely, we identify Am,n and Pm,n with the fusion algebras of BPS line operators in certain theories of class S [\[39,](#page-106-3) [40\]](#page-106-4), which in turn gives us multiple interpretations of Pm,n as moduli spaces of 2d flat connections. We also identify Pm,n as the moduli space of certain A-model D-branes with a specific asymptotic shape in the deformed A<sup>1</sup> singularity M<sup>t</sup> , which is perfectly consistent with the holographic duality we are trying to establish.

We will not attempt to prove that  $\mathcal{P}_{m,n}$  precisely captures the constraints on  $\mathcal{P}_m$  arising in our context. Indeed, we do not need to do so: the cups and caps constraints on  $\mathcal{P}_{2n}$  land automatically in  $\mathcal{P}_{2n,n}$  and the braid group action on  $\mathcal{P}_{2n}$  preserves  $\mathcal{P}_{2n,n}$ . Accordingly, we do not lose any generality by a restriction to  $\mathcal{P}_{m,n}$ , and we gain a conjectural holographic interpretation of our calculations.

Furthermore,  $\mathcal{L}_{\text{caps}}$  and  $\mathcal{L}_{\text{cups}}$  are Lagrangian submanifolds, and the braid group acts by symplectomorphisms of  $\mathcal{P}_{m,n}$  (the classical limit of automorphisms on the quantum group). The augmentation variety is thus an intersection of Lagrangian correspondences, which is automatically a Lagrangian submanifold of  $(\mathbb{C}^*)^{2s}$ .

We will now work our way through some illustrative examples.

#### <span id="page-24-0"></span>3.2 The $\mathcal{P}_{2,1}$ phase space

We can illustrate first the case m=2, n=1. The generators of  $U_{\mathfrak{q}}(\mathfrak{gl}_2)$  here are  $K_1=\mathfrak{q}^{k_1},\ K_2=\mathfrak{q}^{k_2}$ , and the two rung operators E and F. The action of the rung operators shifts the  $k_i$ :

$$K_1 E = \mathfrak{q} E K_1$$

$$K_2 E = \mathfrak{q}^{-1} E K_2$$

$$K_1 F = \mathfrak{q}^{-1} F K_1$$

$$K_2 F = \mathfrak{q} F K_2.$$
(3.6)

The "square-switch" relation of Figure 9 is  $EF = FE + [k_1 - k_2]_{\mathfrak{q}}$  and gives the final  $U_{\mathfrak{q}}(\mathfrak{gl}_2)$  relation:

$$[E, F] = \frac{K_1 K_2^{-1} - K_1^{-1} K_2}{\mathfrak{q} - \mathfrak{q}^{-1}}.$$
(3.7)

<span id="page-24-1"></span>![](_page_24_Figure_8.jpeg)

**Figure 9**: The square-switch relation.

The rescaled rungs  $e = (\mathfrak{q} - \mathfrak{q}^{-1})E$  and  $f = (\mathfrak{q} - \mathfrak{q}^{-1})F$  have a good planar limit.

The space  $\mathcal{P}_2$  is parameterized by (the planar limits of)  $K_1$ ,  $K_2$ , e and f, with  $K_1$  and  $K_2$  invertible, and non-trivial Poisson brackets:

$$\{K_1, e\} = \frac{1}{2}K_1e$$

$$\{K_1, f\} = -\frac{1}{2}K_1f$$

$$\{K_2, e\} = -\frac{1}{2}K_2e$$

$$\{K_2, f\} = \frac{1}{2}K_2f$$

$$\{e, f\} = K_1K_2^{-1} - K_1^{-1}K_2.$$
(3.8)

If the strands are part of a knot or placed in a transverse  $S^2$ , the strand labels are forced to be both 0, both N, or to add up to N. We are interested here in the last case, relevant e.g. for the recursive computation of the unknot as in Figure 6. Then  $K_1K_2 = g$ .

The remaining relations are most easily seen from the action on cups and caps. See Appendix C for details. We denote a cup with label k on the left as  $|k\rangle$  and a cap with label k on the left as  $\langle k|$ , anticipating a vector space interpretation.

In this notation, the  $U_{\mathfrak{q}}(\mathfrak{gl}_2)$  acts on cups as

$$K_{1}|k\rangle = |k\rangle \mathfrak{q}^{k}$$

$$K_{2}|k\rangle = |k\rangle \mathfrak{q}^{N-k}$$

$$E|k\rangle = -|k+1\rangle [k+1]_{\mathfrak{q}}$$

$$F|k\rangle = -|k-1\rangle [N-k+1]_{\mathfrak{g}}.$$
(3.9)

These relations define the dimension N+1 irrep of  $U_{\mathfrak{q}}(\mathfrak{gl}_2)$ . Similarly,

$$\langle k|K_1 = \mathfrak{q}^k \langle k|$$

$$\langle k|K_2 = \mathfrak{q}^{N-k} \langle k|$$

$$\langle k|E = [N-k+1]_{\mathfrak{q}} \langle k-1|$$

$$\langle k|F = [k+1]_{\mathfrak{q}} \langle k+1|.$$
(3.10)

The Casimir operators of  $U_{\mathfrak{q}}(\mathfrak{gl}_2)$  act as constants:  $K_1K_2=g$  and

$$ef = (K_1 - K_1^{-1})(\mathfrak{q}K_2 - \mathfrak{q}^{-1}K_2^{-1})$$

$$fe = (\mathfrak{q}K_1 - \mathfrak{q}^{-1}K_1^{-1})(K_2 - K_2^{-1}).$$
(3.11)

as expected. This constraint defines a quotient of  $U_{\mathfrak{q}}(\mathfrak{gl}_2)$  we denote as  $A_{2,1}$ .

The recursive calculation of the unknot is the same as a recursive calculation of the Uq(gl<sup>2</sup> )-covariant inner products

$$[k+1]_{\mathfrak{q}}\langle k+1|k+1\rangle = \langle k|F|k+1\rangle = -[N-k]_{\mathfrak{q}}\langle k|k\rangle. \tag{3.12}$$

The braid transformation B is computed in Appendix [C:](#page-69-0)

$$K_1B = BK_2$$

$$K_2B = BK_1$$

$$K_1EB = BFK_1$$

$$K_2FB = BEK_2.$$
(3.13)

For example, the recursive computation of an unknot with a twist is the same as the recursive computation of non-zero matrix elements for B:

$$\mathfrak{q}^{N-k}[k+1]_{\mathfrak{q}}\langle N-k-1|B|k+1\rangle = \langle N-k|K_1EB|k+1\rangle = -\mathfrak{q}^{k+1}[N-k]_{\mathfrak{q}}\langle N-k|B|k\rangle,$$
(3.14)

i.e.

$$\mathfrak{q}^{N-k} \frac{\langle N-k-1|B|k+1\rangle}{\langle k+1|k+1\rangle} = -\mathfrak{q}^{k+1} \frac{\langle N-k|B|k\rangle}{\langle k|k\rangle}, \tag{3.15}$$

recovering the framing factor[16](#page-26-0) q k(N−k) for WΛkC<sup>N</sup> .

In the planar limit, the Casimir constraints cut out a two-dimensional symplectic submanifold P2,<sup>1</sup> of P2:

<span id="page-26-1"></span>
$$ef = (K_1 - K_1^{-1})(K_2 - K_2^{-1}), K_1 K_2 = g.$$
 (3.16)

The cap enforces constraints

$$f = K_1 - K_1^{-1}, e = K_2 - K_2^{-1}, (3.17)$$

which define a Lagrangian submanifold Lcap = C t 1 in P2,1.

We will "keep track" of the knot label k at a point in the cup, so the cup constraints can be thought of as a Lagrangian correspondence Lcup = C b <sup>1</sup> between P2,<sup>1</sup> and the C <sup>∗</sup> × C <sup>∗</sup> auxiliary space parameterized by µ and λ:

$$K_1 = \mu$$
  $f = -\lambda (K_2 - K_2^{-1})$   $e = -\lambda^{-1} (K_1 - K_1^{-1}).$  (3.18)

Intersecting the two constraints, we recover the augmentation variety L in C <sup>∗</sup> × C ∗ .

<span id="page-26-0"></span><sup>16</sup>The framing factor for SU(N)<sup>κ</sup> is really q k(N−k)(1+N−<sup>1</sup> , but we have stripped off some powers of q N−<sup>1</sup> from B to simplify the calculation. These will not affect the planar answers we are interested in.

A final observation is that the  $U_{\mathfrak{q}}(\mathfrak{gl}_2)$  representations we encounter here are unitary for positive integer N, with  $F = E^{\dagger}$  and  $K_1^{\dagger} = g^{-1}K_2$ , as well as  $|k\rangle^{\dagger} = \langle k|$ . This defines the Hilbert space  $\mathcal{H}_{2,1}$ . Recall that  $\mathfrak{q}^{\dagger} = \mathfrak{q}^{-1}$  for real level.

In the planar limit, these conditions define a real phase space  $\mathcal{P}_{2,1}^{\mathbb{R}}$  in  $\mathcal{P}_{2,1}$ :

$$|K_1|^2 = 1$$
  $|e|^2 = g^{-1}K_1^2 + gK_1^{-2} - g - g^{-1}.$  (3.19)

which is a deformed version of a round  $S^2$ . At finite N, the representations of  $U_{\mathfrak{q}}(\mathfrak{gl}_2)$  are a natural quantization of  $\mathcal{P}_{2,1}^{\mathbb{R}}$ , akin to the fuzzy sphere construction. See Appendix A for some more details.

## <span id="page-27-0"></span>3.3 The $\mathcal{P}_{3,1}$ phase space

A configuration of three strands would be relevant, say, to the recursive calculation of the expectation value of a simple network of Wilson lines, built with the help of the canonical junctions

$$W_{\Lambda^k \mathbb{C}^N} \times W_{\Lambda^l \mathbb{C}^N} \leftrightarrow W_{\Lambda^{k+l} \mathbb{C}^N}$$
, (3.20)

and the duality pairing between  $W_{\Lambda^k\mathbb{C}^N}$  and  $W_{\Lambda^{N-k}\mathbb{C}^N}$  ("tags" in [32]).

The simplest example of a network involves three strands with labels  $k_1$ ,  $k_2$ ,  $N - k_1 - k_2$  joined at trivalent vertices (see Figure 10). It has a correlation function which is a  $\mathfrak{q}$ -trinomial

$$\langle M_{\mathbf{O};k_1,k_2} \rangle = \begin{bmatrix} N \\ k_1 + k_2 \end{bmatrix}_{\mathfrak{q}} \begin{bmatrix} k_1 + k_2 \\ k_1 \end{bmatrix}_{\mathfrak{q}}, \tag{3.21}$$

which can be derived from the recursion

$$\langle M_{\mathbf{O};k_1-1,k_2} \rangle = \frac{[k_1]_{\mathfrak{q}}}{[N-k_1-k_2+1]_{\mathfrak{q}}} \langle M_{\mathbf{O};k_1,k_2} \rangle,$$
 (3.22)

and analogous for  $k_2$ . The recursion can be derived as before by adding fundamental rungs to the network and contracting them in multiple ways. We expect the planar limit of general networks to have the same structure as for links. Here we get the augmentation variety  $\mathcal{L}_{\mathbf{O}}$ :

$$\lambda_1 = \frac{\mu_1 - \mu_1^{-1}}{g\mu_1^{-1}\mu_2^{-1} - g^{-1}\mu_1\mu_2}$$

$$\lambda_2 = \frac{\mu_2 - \mu_2^{-1}}{g\mu_1^{-1}\mu_2^{-1} - g^{-1}\mu_1\mu_2}.$$
(3.23)

In an elongated setting, we have  $K_1$ ,  $K_2$  and  $K_3$  Cartan generators as well as elementary rung generators  $E_1$ ,  $E_2$ ,  $F_1$  and  $F_2$ . See Figure 11.

<span id="page-28-0"></span>![](_page_28_Picture_0.jpeg)

Figure 10: A network of three Wilson lines with trivalent junctions and tags.

<span id="page-28-1"></span>![](_page_28_Picture_2.jpeg)

Figure 11: The elementary rungs for m = 3 and the stretched rungs. From the bottom: E1, E2, F1, F2, E<sup>−</sup>;3,1, F<sup>−</sup>;1,3.

The relations defining Uq(gl<sup>3</sup> ) include two Uq(gl<sup>2</sup> ) sub-algebras associated with the consecutive pairs of strands, together with [E1, F2] = [E2, F1] = 0 and four Serre relations:

$$E_1^2 E_2 - (\mathfrak{q} + \mathfrak{q}^{-1}) E_1 E_2 E_1 + E_2 E_1^2 = 0, \qquad (3.24)$$

together with 1 ↔ 2 and E ↔ F permutations.

As a consequence, the algebra generated by E<sup>i</sup> rungs includes irreducible sequences (E1E2) n . It is convenient to introduce extra generators

$$E_{-;3,1} \equiv E_1 E_2 - \mathfrak{q} E_2 E_1$$
  $F_{-;1,3} \equiv F_2 F_1 - \mathfrak{q}^{-1} F_1 F_2$ , (3.25)

which have a graphical representation as rungs passing behind the second strand. See Figure [11.](#page-28-1) It is easy to check that Uq(gl<sup>3</sup> ) then admits a "PBW" linear basis consisting of normal-ordered products of K<sup>±</sup><sup>1</sup> i , E<sup>i</sup> , F<sup>i</sup> , E<sup>−</sup>;3,<sup>1</sup> and F<sup>−</sup>;3,1.

We expect all rescaled rung operators e• ≡ (q − q −1 )E• and f• ≡ (q − q −1 )F• and polynomials thereof to have a good planar limit. The PBW basis statement then implies that the planar limit of the Uq(gl<sup>3</sup> ) rung algebra consists of polynomials in K<sup>±</sup><sup>1</sup> i , ei , f<sup>i</sup> , e<sup>−</sup>;3,<sup>1</sup> and f<sup>−</sup>;3,1. We interpret them as holomorphic functions on a 9-dimensional Poisson manifold P3.

When the strands are part of a compact network or we work on a transverse S 2 , we will get extra constraints among the generators. The analogues of the cups and caps in the m = 2 case are now trivalent vertices |k1, k2⟩ and ⟨k1, k2| between strands of labels k1, k<sup>2</sup> and N − k<sup>1</sup> − k2.

With a bit of patience, one can recognize the action of Uq(gl<sup>3</sup> ) on trivalent vertices as an irreducible representation, the N-th symmetric power of the fundamental representation. Accordingly, the recursive calculation of

$$\langle k_1, k_2 | k_1, k_2 \rangle = \begin{bmatrix} N \\ k_1 + k_2 \end{bmatrix}_{\mathfrak{q}} \begin{bmatrix} k_1 + k_2 \\ k_1 \end{bmatrix}_{\mathfrak{q}}$$
 (3.26)

is simply reproducing the unique Uq(gl<sup>3</sup> )-covariant pairing between the irreducible representation and its dual.

We compute some simple extra constraints:

$$K_1 K_2 K_3 = g$$

$$e_1 f_1 = (K_1 - K_1^{-1}) (\mathfrak{q} K_2 - \mathfrak{q}^{-1} K_2^{-1})$$

$$e_2 f_2 = (K_2 - K_2^{-1}) (\mathfrak{q} K_3 - \mathfrak{q}^{-1} K_3^{-1}), \qquad (3.27)$$

etcetera. We denote the part of the rung algebra constrained to act on trivalent vertices as A3,1. See Appendix [A](#page-53-0) for a characterization of A3,<sup>1</sup> and of the 4-dimensional complex symplectic manifold P3,<sup>1</sup> which emerges in the planar limit. We will momentarily review a presentation as a space of 2d flat connections.

The finite-dimensional irrep of Uq(gl<sup>3</sup> ) is unitary, leading to natural hermiticity conditions relating E's and F's. In the planar limit, this defines a compact real locus P R 3,1 (essentially, a deformed CP<sup>2</sup> ) which is naturally quantized by the finite N irrep of Uq(gl<sup>3</sup> ).

The braid group action computed in Appendix [D](#page-77-0) is easy to describe once we define rung operators passing in front of the second strand:

$$E_{+;3,1} \equiv E_1 E_2 - \mathfrak{q}^{-1} E_2 E_1$$
  $F_{+;1,3} \equiv F_2 F_1 - \mathfrak{q} F_1 F_2$ . (3.28)

Then the action of B<sup>1</sup> (braiding the first two strands) and B<sup>2</sup> (braiding the last two strands) is completely geometric, up to the extra factor of K<sup>i</sup> in the relations between Ei , B<sup>i</sup> and F<sup>i</sup> . The planar limit of the braiding relations is defined in the same manner.

#### <span id="page-30-0"></span>3.4 The $\mathcal{P}_{4,2}$ phase space

The case m=4, n=2 is interesting as it allows for the calculation of augmentation varieties of some simple non-trivial knots and links. We will illustrate the procedure for the Hopf link and the trefoil knot.

Again,  $U_{\mathfrak{q}}(\mathfrak{gl}_4)$  admits a PBW linear basis consisting of normal-ordered products of  $K_i^{\pm 1}$ ,  $E_{-;i,j}$  and  $F_{-;i,j}$ . Their planar limit can be interpreted as holomorphic functions in a 16-dimensional complex Poisson manifold  $\mathcal{P}_4$ .

For clarity, we will use a superscript U for the planar vevs of the elements of the algebra at the cups, and a superscript A for their planar vevs at the caps. The shape of the braid determines the relation between the two sets. A pair of cups joining consecutive strands forces them to have labels  $k_1$ ,  $N - k_1$ ,  $k_2$  and  $N - k_2$ . Accordingly,

$$K_1^U = \mu_1$$

$$K_2^U = g\mu_1^{-1}$$

$$K_3^U = \mu_2$$

$$K_4^U = g\mu_2^{-1}.$$
(3.29)

Furthermore (see Appendix C for details)

$$e_{-;2,1}^{U} = -\lambda_{1}^{-1}(\mu_{1} - \mu_{1}^{-1})$$

$$e_{-;3,1}^{U} = \lambda_{1}^{-1}\mu_{1}e_{2}^{U}$$

$$e_{-;4,1}^{U} = -\mu_{1}\mu_{2}^{-1}\lambda_{1}^{-1}\lambda_{2}^{-1}e_{2}^{U}$$

$$e_{-;4,2}^{U} = -\lambda_{2}^{-1}\mu_{2}^{-1}e_{2}^{U}$$

$$e_{-;4,3}^{U} = -\lambda_{2}^{-1}(\mu_{2} - \mu_{2}^{-1}),$$
(3.30)

as well as

$$f_{-;1,2}^{U} = -\lambda_1 (g\mu_1^{-1} - g^{-1}\mu_1)$$

$$f_{-;1,3}^{U} = -\lambda_1 g\mu_1^{-1} f_2^{U}$$

$$f_{-;1,4}^{U} = -\lambda_1 \lambda_2 \mu_1^{-1} \mu_2 f_2^{U}$$

$$f_{-;2,4}^{U} = \lambda_2 g^{-1} \mu_2 f_2^{U}$$

$$f_{-;3,4}^{U} = -\lambda_2 (g\mu_2^{-1} - g^{-1}\mu_2).$$
(3.31)

For two caps with labels  $k_1$  and  $k_2$ , we get

$$K_1^A = \mu_1$$
  
 $K_2^A = g\mu_1^{-1}$   
 $K_3^A = \mu_2$   
 $K_4^A = g\mu_2^{-1}$ , (3.32)

as well as

$$e_{-;2,1}^{A} = (g\mu_{1}^{-1} - g^{-1}\mu_{1})$$

$$e_{-;3,1}^{A} = g^{-1}\mu_{1}e_{2}^{A}$$

$$e_{-;4,1}^{A} = -\mu_{1}\mu_{2}^{-1}e_{2}^{A}$$

$$e_{-;4,2}^{A} = -g\mu_{2}^{-1}e_{2}^{A}$$

$$e_{-;4,3}^{A} = (g\mu_{2}^{-1} - g^{-1}\mu_{2}),$$
(3.33)

and

$$f_{-;1,2}^{A} = (\mu_1 - \mu_1^{-1})$$

$$f_{-;1,3}^{A} = -\mu_1^{-1} f_2^{A}$$

$$f_{-;1,4}^{A} = -\mu_2 \mu_1^{-1} f_2^{A}$$

$$f_{-;2,4}^{A} = \mu_2 f_2^{A}$$

$$f_{-;3,4}^{A} = (\mu_2 - \mu_2^{-1}).$$
(3.34)

If we intersect the cup and cap constraints directly, we essentially recover two separate unknots. More precisely, the equations for  $e_{-;2,1}$  and  $e_{-;4,3}$  give the two separate augmentation varieties. The remaining equations force rungs stretched between the unknots to vanish for generic  $\lambda_i$ .

We can now insert some powers of  $B_2$  to produce interesting knots. A single power of  $B_2$  produces the twisted unknot of Figure 7. We immediately see that  $\mu_2 = g\mu_1^{-1}$ . We denote  $\mu_1 = \mu$ . We set  $\lambda_2 = 1$ ,  $\lambda_1 = \lambda$ , as we only need to keep track of k at one location. We can start from the cap constraint

$$e_{-;2,1}^{A} = (g\mu^{-1} - g^{-1}\mu),$$
 (3.35)

convert it across  $B_2$  to  $e_{-,3,1}^U$  and at the cup to

$$e_{-;4,2}^{U} = -\lambda g^{-1}(g\mu^{-1} - g^{-1}\mu).$$
 (3.36)

Next, we use

$$e_{+:4,2} = e_{-:4,2} + e_{-:4,3}e_2 (3.37)$$

to derive

$$e_{+,4,2}^{U} = -\lambda g \mu^{-2} (g \mu^{-1} - g^{-1} \mu)$$
(3.38)

and convert it across  $B_2$  to  $e_{-;4,3}^A$  to finally obtain

$$(\mu - \mu^{-1}) = -\lambda g \mu^{-2} (g \mu^{-1} - g^{-1} \mu). \tag{3.39}$$

The replacement  $\lambda \to \lambda g \mu^{-2}$  is due to the twisted framing of this unknot.

<span id="page-32-0"></span>Two powers of  $B_2$  give us the Hopf link of Figure 12. There are two types of solutions. If the rungs stretched between the two components of the link (in either direction) vanish, then the rungs for each component can be manipulated as if the other component were absent, reproducing the combination of two unknots ("disconnected saddle").

![](_page_32_Picture_2.jpeg)

Figure 12: The elongated Hopf link.

We thus explore the option that some rung vevs stretched between the two components may not vanish ("connected saddle"). An  $f_{-;1,3}^U$  rung can be brought across  $B_2^2$  and converted into  $f_2^A$  at the caps, but also first converted into  $f_2^U$  at the cups and then brought across  $B_2^2$ . This gives the relation

$$\lambda_1 f_2^A = g \mu_2^{-2} f_2^A \,. \tag{3.40}$$

Analogously, starting with  $f_{-:2,4}^A$ , we get

$$\lambda_2 f_2^A = g\mu_1^{-2} f_2^A \,. \tag{3.41}$$

Accordingly, off-diagonal rungs can be non-zero only if  $\lambda_1 = g\mu_2^{-2}$  and  $\lambda_2 = g\mu_1^{-2}$ . These relations are sufficient to satisfy all constraint equations. We compute the (charge-conserving combination of) off-diagonal vevs as well:

$$e_2^A f_2^A = (g^{-1} - g)\mu_2^{-1}\mu_1^{-1} - g^{-1}(\mu_1 - \mu_1^{-1})(\mu_2 - \mu_2^{-1}). \tag{3.42}$$

Finally, we can look at the right-handed trefoil knot of Figure 13 by inserting  $B_2^3$ . As in the twisted unknot example, we see that  $\mu_2 = g\mu_1^{-1}$  and denote  $\mu_1 = \mu$  and set  $\lambda_2 = 1$ ,  $\lambda_1 = \lambda$ . We will derive some equations constraining  $\lambda$ ,  $\mu$ ,  $e_2^A$  and  $f_2^A$ .

<span id="page-33-0"></span>![](_page_33_Picture_0.jpeg)

**Figure 13**: The elongated right-handed trefoil knot.

We start by noticing that  $B_2$  converts  $f_2$  to  $e_2$  and vice versa, without extra factors in this case. A rung  $f_2^U$  can then be brought to  $e_2^A$ , but can also be converted to  $f_{-;1,4}^U$  at the cups, passed across the braid, and converted back to  $f_2^A$ . This gives the relation

$$f_2^A = \lambda e_2^A \,. \tag{3.43}$$

We can also start with  $f_{-;1,3}^U$  and pass it across  $B_2^3$ :

$$f_{-;1,3}^{U} \to f_{1} \to f_{+;1,3} = f_{-;1,3} - f_{1}f_{2} \to f_{1}^{A} - f_{+;1,3}^{A}e_{2}^{A} = f_{1}^{A} - f_{-;1,3}^{A}e_{2}^{A} + f_{1}^{A}f_{2}^{A}e_{2}^{A}.$$

$$(3.44)$$

Analogously,  $f_1^U$  maps to  $f_{-;1,3}^A(1+e_2^Af_2^A)-f_1^Af_2^A(2+e_2^Af_2^A)$ . Applying the cups and caps, and converting the remaining  $f_2^U$  to  $e_2^A$ , we get

$$g\lambda e_2^A = 1 - \mu^2 (1 + e_2^A f_2^A)$$
  

$$\lambda (g^2 - \mu^2) = gf_2^A (-1 + \mu^2 (2 + e_2^A f_2^A)), \qquad (3.45)$$

and eliminating the vevs we obtain the augmentation variety

$$g^4(g^2-\mu^2)\lambda^2 + \left(g^4-g^4\mu^2 + 2g^4\mu^4 - 2g^2\mu^4 - g^2\mu^6 + \mu^8\right)\lambda + g^2\mu^6(\mu^2-1) = 0. \quad (3.46)$$

This matches the results in the literature after an appropriate redefinition of the variables. See the end of Appendix G for details.

Note also

$$e_2^A = \frac{g^2 - \mu^4}{g(\mu^4 + g^2\lambda)}, \qquad (3.47)$$

so in this case every point in the augmentation variety lifts to a single point in  $\mathcal{P}_{4,2}$ . This may not be true in more general examples.

## <span id="page-34-0"></span>4 From rung vevs to character varieties

In Appendix D we use some extra "spectator" strands to give a SU(N) Chern-Simons theory derivation of the relation between the planar limit  $\mathcal{P}_m$  of  $U_{\mathfrak{q}}(\mathfrak{gl}_m)$  and the Stokes data of an auxiliary 2d GL(m) flat connection on the plane, with a "rank 1" irregular singularity at infinity and a regular singularity at the origin. This is a well-known property of  $U_{\mathfrak{q}}(\mathfrak{gl}_m)$  [41–43], though it usually occurs in the study of (analytically continued) GL(m) Chern-Simons theory. Here the latter interpretation will be a manifestation of holography, with the GL(m) Chern-Simons theory being the world-volume theory of m D-branes.

Concretely, we assemble the  $-e_{-;i,j}$  generators into a triangular matrix  $\hat{e}_{-}$  with unit diagonal. This matrix is obviously invertible. Its inverse  $\hat{e}_{+}$  is a triangular matrix with off-diagonal elements  $e_{+;i,j}$  that contains the vevs of rungs that pass in front of intermediate strands, instead of behind. Analogously, we can form a matrix  $\hat{f}_{-}$  with unit diagonal and off-diagonal elements  $f_{-;i,j}$ . The inverse  $\hat{f}_{+}$  has entries  $-f_{+;i,j}$ , with  $f_{+;i,j}$  also being the vevs of rungs that pass in front of intermediate strands.

Finally, we can define a diagonal matrix  $\hat{K}$  with entries  $K_i$  and assemble a "monodromy matrix"

<span id="page-34-1"></span>
$$M = \hat{K}\hat{f}_{-}\hat{K}\hat{e}_{+}. \tag{4.1}$$

For example, for m=2 we have

$$M = \begin{pmatrix} K_1 & 0 \\ 0 & K_2 \end{pmatrix} \begin{pmatrix} 1 & f \\ 0 & 1 \end{pmatrix} \begin{pmatrix} K_1 & 0 \\ 0 & K_2 \end{pmatrix} \begin{pmatrix} 1 & 0 \\ e & 1 \end{pmatrix} = \begin{pmatrix} K_1^2 + K_1 K_2 f e & K_1 K_2 f \\ K_2^2 e & K_2^2 \end{pmatrix} . \tag{4.2}$$

The coefficients of the characteristic polynomial of this matrix

$$\det(x\mathbb{I} - M) = x^2 - K_1 K_2 (K_1 K_2^{-1} + K_2 K_1^{-1} + fe) x + K_1^2 K_2^2, \tag{4.3}$$

coincide with the planar limit of the first and second Casimirs of  $U_{\mathfrak{q}}(\mathfrak{gl}_2)$ . The constraints that define  $\mathcal{P}_{2,1}$ , i.e. the Casimirs fixed as in (3.16), give a characteristic equation

$$M^{2} - (1+g^{2})M + g^{2} = (M-1)(M-g^{2}) = 0,$$
 (4.4)

i.e. the m=2 monodromy matrix specialized to the cap or cup constraints has eigenvalues 1 and  $g^2$ .

We now make a more general claim which is supported by Appendix A, and direct calculations of cup and cap states: if the m strands are part of a compact knot or network or are placed in a transverse  $S^2$  geometry, the planar limit of the rung vevs is supported on the union of submanifolds defined by the equation

<span id="page-35-2"></span>
$$(M-1)(M-g^2) = 0, (4.5)$$

i.e. M has an n-dimensional eigenspace with eigenvalue  $g^2$  and an (m-n)-dimensional eigenspace with eigenvalue 1 for some n, which turns out to coincide with the "baryon number" of the system: the sum of the labels on strands is Nn.<sup>17</sup>

We identify the space of such matrices, which has dimension 2n(m-n), with  $\mathcal{P}_{m,n}$ . The  $\mathcal{P}_{m,n}$  manifolds are thus orbits of  $\mathrm{GL}(m)$  equipped with the symplectic form inherited from  $U_{\mathfrak{q}}(\mathfrak{gl}_m)$ . They are an example of "character varieties": they parameterize the Stokes/monodromy data of a 2d flat connection with specified singularities. Here we have a general rank 1 irregular singularity at infinity, so that the monodromy M is decomposed into Stokes data as in (4.1). See [44] for a review of Stokes phenomena and irregular character varieties. The constraint (4.5) is interpreted as the presence at the origin of a regular singularity labeled by the Levi subgroup  $\mathrm{GL}(n) \times \mathrm{GL}(m-n) \subset \mathrm{GL}(m)$ .

We should also observe the hermiticity conditions

$$K_{i}^{\dagger} = gK_{i}^{-1}$$
 $e_{+;ij}^{\dagger} = -f_{+;ij}$ 
 $f_{-;ij}^{\dagger} = -e_{-;ij}$ , (4.6)

which relate  $e_+$  matrix elements to  $f_-^{-1}$  matrix elements and thus set  $M^{\dagger} = g^2 M^{-1}$ . In other words,  $g^{-1}M$  is a unitary matrix. These reality conditions define the real symplectic manifolds  $\mathcal{P}_{m,n}^{\mathbb{R}}$ . We expect that the finite N irreps  $\mathcal{H}_{m,n}$  of  $U_{\mathfrak{q}}(\mathfrak{gl}_m)$  are a natural quantization of  $\mathcal{P}_{m,n}^{\mathbb{R}}$ .

#### <span id="page-35-0"></span>4.1 The geometric braid group action

The braid group generators  $B_i$  act on these matrices in a manner which is familiar from the theory of Stokes phenomena. Consider m complex numbers  $x_i$ , which can be understood as transverse positions  $x_i^1 + \sqrt{-1}x_i^2$  of the strands. We have phases  $\vartheta_{ij}$  of

<span id="page-35-1"></span><sup>&</sup>lt;sup>17</sup>Note that, unlike in the  $\mathcal{P}_{2,1}$  case, this constraint is stronger than just fixing the Casimirs, which would allow for more general Jordan blocks.

 $x_j - x_i$ , which are the slopes of straight ij rungs. We slightly perturb the original  $x_i^2$  positions of the strands so that the slopes are all distinct.

Denote the vevs of the straight rungs as  $e_{ij}$  and  $f_{ij}$  depending on the orientation with respect to the  $x^1$  direction. These will be typically different from the  $e_{\pm;i,j}$  and  $f_{\pm;i,j}$ . If the perturbation has a convex profile, so that all straight rungs pass behind intermediate strands, then obviously  $e_{ij} = e_{-;ij}$  and  $f_{ij} = f_{-;ij}$ .

Consider the product of  $m \times m$  matrices:

$$\hat{f} = \prod_{i < j} \left( 1 + f_{ij} b_{ij} \right), \tag{4.7}$$

where  $b_{ij}$  is the elementary matrix with a single element 1 at position ij and the product is taken in the order opposite to the order of the slopes. If we have a convex profile, there will not be any mixed terms in the product and  $\hat{f} = \hat{f}_{-}$ .

The skein relations satisfied by rungs are such that this remains true even when we perturb away from the convex profile. In particular, if we take a concave profile, we will have a maximal amount of mixed terms in the product. On the other hand,

$$\hat{f}^{-1} = \prod_{i < j}^{\rightarrow} (1 - f_{ij}b_{ij}) = \hat{f}_{+} \tag{4.8}$$

will have no mixed terms, and we see that indeed  $f_{ij} = f_{+;ij}$  in this configuration, as expected.

In the same manner, we can define

$$\hat{e}^{-1} = \prod_{i>j}^{\rightarrow} (1 - e_{ij}b_{ij}) \tag{4.9}$$

and match it with  $\hat{e}_{-}$  in the convex position,  $\hat{e}_{+}^{-1}$  in the concave position.

Then

$$M = \hat{K} \left[ \prod_{i < j}^{\leftarrow} (1 + f_{ij} b_{ij}) \right] \hat{K} \left[ \prod_{i > j}^{\leftarrow} (1 + e_{ij} b_{ij}) \right], \tag{4.10}$$

for any perturbed positions of the strands.

As we continuously braid two strands, the corresponding slope will progressively increase and the corresponding factors in M will move to the left in the product. The braid transformation "happens" when the slope hits the vertical and we reorganize the product: the leftmost elementary factor in  $\hat{e}$  is conjugated across  $\hat{K}$  and becomes the rightmost factor in  $\hat{f}$ , and vice versa.

This is precisely the behavior of the Stokes data for a GL(m) 2d flat connection which approaches a diagonal form at the rank 1 singularity, with eigenvalues  $x_i^1 dy_1 +$ 

 $x_i^2 dy_2$  [38]. Here we denote as  $y_i$  the 2d coordinates on the auxiliary plane the connection is defined on.

## <span id="page-37-0"></span>4.2 An alternative perspective on $\mathcal{P}_{m,n}$ , cups and caps

The construction of M in Appendix D employs an auxiliary strand, following the evolution of rungs stretched from it to the remaining strands as it is transported along a closed path at large x. There is no obstruction to doing the same along other paths in the x plane.

This procedure gives an alternative interpretation of the factorization of M: just as in the tree-level planar limit discussed earlier in the paper, the transport along different loops gives a GL(m) local system on the x plane with m minimal regular singularities  $x_i$ , with monodromies  $M_i$  such that

$$M_i = 1 + v_i^L v_i^R \,, (4.11)$$

for a left eigenvector  $v_i^L$  and a right eigenvector  $v_i^R$ , normalized so that

<span id="page-37-2"></span>
$$v_i^R \cdot v_i^L = K_i^2 - 1, (4.12)$$

and the rung vevs are expressed as

<span id="page-37-3"></span>
$$v_i^R \cdot v_j^L = \begin{cases} e_{-;i,j} & i > j \\ K_i K_j f_{-;i,j} & i < j \end{cases}$$
 (4.13)

computed along the appropriate open path joining i and j. The monodromy at infinity is

$$M = M_m \cdots M_1. \tag{4.14}$$

<span id="page-37-1"></span>Note that these formulae can be diagrammatically represented as in Figures 14 and 15.

$$\begin{array}{cccc}
\bullet & & & & & & & & & & \\
\bullet & & & & & & & & \\
i & & & & & & & & \\
& & & & & & & & \\
& & & &$$

Figure 14: Diagrammatic representation of (4.12). The small dot represents the start and end points of the path computing  $M_i$ .

This picture undergoes an important simplification when we restrict from  $\mathcal{P}_m$  to  $\mathcal{P}_{m,n}$ : the monodromies actually happen within an *n*-dimensional subspace of  $\mathbb{C}^m$ .

<span id="page-38-0"></span>![](_page_38_Picture_0.jpeg)

Figure 15: Diagrammatic representation of [\(4.13\)](#page-37-3).The small dot represents the location where the inner product of v R i and v L j is computed.

Accordingly, rung vevs in Pm,n map to 2d GL(n) local system on the plane with m minimal regular singularities and monodromy g <sup>2</sup> at infinity. In the above formulae, v R i and v L i are replaced by n-dimensional vectors ˜s<sup>i</sup> and s<sup>i</sup> , defined up to an overall GL(n) transformation. We refer the reader to Appendix [A](#page-53-0) for more details.

The main advantage of this presentation is the extreme simplicity of the action of the braid group and of the cups and caps constraints. Braiding operations act simply by braiding the punctures:

<span id="page-38-2"></span>
$$B_{i}s_{i} = M_{i}^{-1}s_{i+1}B_{i}$$

$$B_{i}s_{i+1} = s_{i}B_{i}$$

$$B_{i}\tilde{s}_{i} = \tilde{s}_{i+1}M_{i}B_{i}$$

$$B_{i}\tilde{s}_{i+1} = \tilde{s}_{i}B_{i},$$

$$(4.17)$$

<span id="page-38-1"></span>i.e. the data of the strand passing "above" at the braid is transformed by the monodromy associated with the strand passing "below" at the braid. See Figure [16](#page-38-1)

$$\begin{array}{cccc}
\bullet & \bullet & & \xrightarrow{B_i} & & & \\
i & i+1 & & & & & \\
& & & & & & \\
& & & & & & \\
& & & &$$

Figure 16: Diagrammatic representation of the first equation of [\(4.17\)](#page-38-2).

We can also express these relations in terms of the M<sup>i</sup> monodromy matrices:

$$B_i M_i = M_i^{-1} M_{i+1} M_i B_i$$
  

$$B_i M_{i+1} = M_i B_i,$$
(4.19)

fixing Mi+1M<sup>i</sup> , just as in the presentation of the fundamental group of a knot complement, with the difference that M would be the identity matrix in that case.[18](#page-39-1)

Half of the caps constraints give K2i−1K2<sup>i</sup> = g, s2<sup>i</sup> = K2is2i−1. We can take the matrix of s<sup>i</sup> vectors to be block-diagonal, with n blocks of size 2 × 1. The other half of the constraints are subsumed into M = g 2 , so these are enough to define Lcaps ⊂ Pm,n. The cup constraint Lcups is analogously K2i−<sup>1</sup> = µ<sup>i</sup> , K2i−1K2<sup>i</sup> = g, ˜s2i−<sup>1</sup> = −λiK2i−1s˜2<sup>i</sup> .

The cap constraints force

$$M_{2i}M_{2i-1} = 1 + s_{2i}(K_{2i}\tilde{s}_{2i-1} + \tilde{s}_{2i}), \qquad (4.20)$$

with a single non-trivial g 2 eigenvalue. This deforms the tree-level planar constraint M2iM2i−<sup>1</sup> = 1. The dual vector (K2is˜2i−<sup>1</sup> + ˜s2i) is constrained by the remaining cup relations, or by M = g 2 , to be orthogonal to s2<sup>j</sup> for j ̸= i. For cups,

$$M_{2i}M_{2i-1} = 1 + (s_{2i-1} - \lambda^{-1}K_{2i-1}s_{2i})\tilde{s}_{2i-1}. \tag{4.21}$$

It is not difficult to extend these considerations to other operations on strands, such as three-way junctions.

The simplification is both practical and conceptual. In practice, we can do calculations using the 2n(m−n)-dimensional space Pm,n instead of keeping track of m(m−1) rung vevs. Conceptually, the vevs at each horizontal "slice" of the elongated knot map to the data of a 2d flat connection, evolving naturally along the braid and constrained in a local way at cups and caps. We will momentarily map this data to the data of a dual D-brane.

## <span id="page-39-0"></span>4.3 The trefoil augmentation variety as a family of GL(2) flat connections

In the P4,<sup>2</sup> case of the trefoil knot, without loss of generality, we can write at the top the matrix of s's and ˜s's:

$$s = \begin{pmatrix} 1 & g\mu^{-1} & 0 & 0 \\ 0 & 0 & 1 & \mu \end{pmatrix}$$

$$\tilde{s} = \begin{pmatrix} \mu^{2} - 1 & g\mu^{-1}f_{2} \\ g\mu^{-1} - g^{-1}\mu & g^{2}\mu^{-2}f_{2} \\ \mu g^{-1}e_{2} & g^{2}\mu^{-2} - 1 \\ -\mu^{2}g^{-1}e_{2} & \mu - \mu^{-1} \end{pmatrix}, \tag{4.22}$$

<span id="page-39-1"></span><sup>18</sup>We apologize to the reader for landing on this convention, as opposed to the graphically more natural convention of the monodromy around the strand below jumping at the crossing, as in the introduction discussion for g → 1.

solving the cap constraints and  $M_4M_3M_2M_1 = g^2$ . The three powers of  $B_2$  produce new matrices  $M'_3$ ,  $M'_2$ ,  $M''_3$ , with

$$M_3 M_2 = M_2 M_3' = M_3' M_2' = M_2' M_3''. (4.23)$$

We should then impose the cup constraints on  $M_1$ ,  $M_3''$  and  $M_2'$  and  $M_4$ , i.e.  $\tilde{s}_1 + \lambda \mu \tilde{s}_3'' = 0$  and  $\tilde{s}_2' + g\mu^{-1}\tilde{s}_4 = 0$ .

Plugging in the expressions for the  $e_2$  and  $f_2$  rung vevs we derived in our previous analysis, the cup constraints all vanish on the augmentation variety as expected.

## <span id="page-40-0"></span>4.4 Closed braids in $S^2 \times S^1$

Although we have mostly employed our tools to study compact knots, there is another setup that can be analyzed in the same manner. Consider the manifold  $M_3 = S^2 \times S^1$  and a collection of m strands with  $\Lambda^{\bullet}\mathbb{C}^N$  labels that extend along the  $S^1$  direction while being slowly braided along  $S^2$ .

We can define rung operators as before. Instead of the cups and caps constraints, we now have the constraint that a rung operator above the braid must equal the same rung operator below the braid, up to factors of  $\lambda$  accrued when we pass by the location where we keep track of the strand labels.

Quantum mechanically, the correlation functions are computed as a trace over  $\bigoplus_n \mathcal{H}_{m,n}$ , twisted by the rescaling:

$$\lambda^K \equiv E_i \to \lambda_i^{-1} \lambda_{i+1} E_i \qquad F_i \to \lambda_i \lambda_{i+1}^{-1} F_i. \tag{4.24}$$

Recall that we will only need a non-trivial  $\lambda$  parameter for each of the connected components of the braid.

The trace on  $\mathcal{H}_{m,n}$  is unique. Denoting as B the braid operation, we expect  $\operatorname{Tr}B\lambda^K$  to be completely fixed by the relations  $\operatorname{Tr}B\lambda^KO = \operatorname{Tr}OB\lambda^K$  for all elements  $O \in A_{m,n}$ .

In the planar limit, the analogous statement is that we expect an open planar saddle to be completely determined as a point in  $\mathcal{P}_{m,n}$  which is fixed by the combination of braid operation and  $\lambda$  rescaling. As we vary  $\lambda$ , we obtain the augmentation variety for the closed braid in  $S^2 \times S^1$ .

At this point, we can map  $\mathcal{P}_{m,n}$  to the appropriate space of  $\mathrm{GL}(n)$  2d flat connections. The augmentation variety thus describes 2d flat connections on the punctures  $S^2$  which are fixed by the action of the braid group operation on the minimal regular singularities away from infinity, up to a rescaling  $\lambda$  of the non-trivial monodromy eigenvectors at the punctures.

This data can be immediately promoted to the data of a 3d GL(n) flat connection on  $S^2 \times S^1$ , with a minimal regular singularity wrapping the closed braid and a regular singularity with monodromy  $q^2$  at infinity on  $S^2$ .

As an example, we can study the m = 1 and m = 2 cases. In the presence of a single strand, the S <sup>2</sup> Hilbert space has two states H1,<sup>0</sup> and H1,<sup>1</sup> only, with labels k = 0 and k = N. Accordingly, the correlation function is just 1 + λ <sup>N</sup> . We see two saddles, and recalling [\(2.10\)](#page-13-2), they have action 0 and iπN κ+N log λ and thus by definition [\(2.12\)](#page-13-3) we see µ = 1 and µ = g, as expected. These correspond to a trivial connection and a GL(1) connection with constant holonomy g <sup>2</sup> around the origin in S 2 .

The Hilbert space is more interesting in the case of two strands. If we do not act with a braid operation, we have the correlation function

$$1 + \frac{\lambda_1^{N+1} - \lambda_2^{N+1}}{\lambda_1 - \lambda_2} + \lambda_1^N \lambda_2^N, \tag{4.25}$$

and as long as λ<sup>1</sup> ̸= λ2, the corresponding saddles are (µ 2 1 , µ<sup>2</sup> 2 ) being (1, 1), (1, g<sup>2</sup> ), (g 2 , 1), and (g 2 , g<sup>2</sup> ). This is the expected planar result, as in the n = 0 and n = 2 cases the labels have to add up to 0 and 2N so both are 0 and N, respectively. For n = 1, starting with an ef configuration and bringing e or f around the S <sup>1</sup> we get the constraint that either λ<sup>1</sup> = λ<sup>2</sup> or ef = 0. The latter implies that one of the labels is 0, as expected.

If we insert an odd power of B1, the knot has only one connected component, and thus the label must be 0, N/2 or N, which implies that µ <sup>2</sup> = g n for n = 0, 1, 2. The rung vevs can be found as a function of λ.

For an even power r of B1, the n = 0 and n = 2 cases are again easy, with both labels 0 or N and saddles given by (µ 2 1 , µ<sup>2</sup> 2 ) being (1, 1) or (g 2 , g<sup>2</sup> ), respectively. With n = 1, we can assume the labels to be related by k<sup>2</sup> = N − k1, and then applying B<sup>2</sup> 1 multiplies e and f by µ 4 1 g −2 . This means that either λ<sup>2</sup> = µ 2r 1 g <sup>−</sup><sup>r</sup>λ<sup>1</sup> or ef = 0. The latter makes one of the labels 0 and gives saddles in which (µ 2 1 , µ<sup>2</sup> 2 ) is (1, g<sup>2</sup> ) or (g 2 , 1).

## <span id="page-41-0"></span>5 Holography and Chern-Simons theory

A general strategy to "derive" holographic dualities from String Theory constructions is to embed them into open-closed duality: the principle that a theory of closed strings modified by a stack of N D-branes admits a 't Hooft expansion which effectively replaces the D-branes by their back-reaction. As long as the original closed string degrees of freedom can be decoupled, one can derive a perturbative relation between the field theory limit of the D-brane world-volume theory and a closed string theory [\[45\]](#page-106-8). In topological String Theory examples, the "decoupling limit" can be as simple as selecting judicious boundary conditions [\[46\]](#page-106-9).

A similar intuitive derivation of a holographic duality for SU(N)<sup>k</sup> Chern-Simons theory follows the identification of U(N)<sup>κ</sup> Chern-Simons theory as the world-volume theory on a stack of N three-dimensional D-branes in the A-model topological strings [\[1\]](#page-104-0). We will now discuss the A-model setup and the D-brane back-reaction.

Roughly, the closed string sector of the A-model String Theory describes the deformations of six-dimensional symplectic manifolds. Symplectic manifolds do not have any local data, as the symplectic form can always be brought to a canonical form, so the A-model does not have local degrees of freedom.

In order to engineer Chern-Simons theory on a 3-manifold M<sup>3</sup> one considers the A-model with target T <sup>∗</sup>M<sup>3</sup> and a stack of N three-dimensional D-branes supported on the base M3. In the presence of the D-branes, the equation of motion dω = 0 for the dynamical symplectic form is replaced by

$$d\omega = N\hbar\delta^{(3)}(y)dy_1dy_2dy_3, \qquad (5.1)$$

where y<sup>i</sup> are the local coordinates on the fiber of the cotangent bundle. Here ℏ is the topological string coupling. We will relate it to κ <sup>−</sup><sup>1</sup> momentarily.

#### <span id="page-42-0"></span>5.1 T <sup>∗</sup>R <sup>3</sup> back-reaction

If we take M<sup>3</sup> = R 3 , with local coordinates x <sup>i</sup> and y<sup>i</sup> and undeformed symplectic form

$$\omega_0 = dx^i dy_i \,, \tag{5.2}$$

we can easily solve for a back-reaction that preserves all symmetries of the problem: the monopole flux

$$\omega = dx^{i}dy_{i} + \frac{N\hbar}{4\pi} \frac{y_{1}dy_{2}dy_{3} + y_{2}dy_{3}dy_{1} + y_{3}dy_{1}dy_{2}}{|y|^{3}}.$$
(5.3)

We can locally reabsorb the shift in ω by a redefinition of the x i coordinates. Essentially, we shift x <sup>i</sup> by a primitive of ωS<sup>2</sup> . For example, we can do so away from the y<sup>1</sup> = y<sup>2</sup> = 0, y<sup>3</sup> < 0 ray or away from the opposite ray y<sup>1</sup> = y<sup>2</sup> = 0, y<sup>3</sup> > 0. More explicitly,

$$x_{\pm}^{1} = x^{1} - \frac{N\hbar}{4\pi} \frac{y_{2}}{y_{1}^{2} + y_{2}^{2}} \left(\frac{y_{3}}{|y|} \mp 1\right)$$

$$x_{\pm}^{2} = x^{2} + \frac{N\hbar}{4\pi} \frac{y_{1}}{y_{1}^{2} + y_{2}^{2}} \left(\frac{y_{3}}{|y|} \mp 1\right)$$

$$x_{\pm}^{3} = x^{3}.$$
(5.4)

The difference between the two primitives is the angular form

$$\frac{N\hbar}{2\pi} \frac{y_1 dy_2 - y_2 dy_1}{y_1^2 + y_2^2} \,. \tag{5.5}$$

The two coordinate patches x i <sup>±</sup> are thus related as

$$x_{+}^{1} = x_{-}^{1} + \frac{N\hbar}{2\pi} \frac{y_{2}}{y_{1}^{2} + y_{2}^{2}}$$

$$x_{+}^{2} = x_{-}^{2} - \frac{N\hbar}{2\pi} \frac{y_{1}}{y_{1}^{2} + y_{2}^{2}}$$

$$x_{+}^{3} = x_{-}^{3}.$$
(5.6)

If we exchange the role of the x and y coordinates, the back-reacted geometry can be seen as a twisted cotangent bundle of R <sup>3</sup>\{0}: the base R <sup>3</sup>\{0} is parameterized by the y<sup>i</sup> coordinates and the fiber coordinates x i in different patches on the base are glued affine-linearly.

If we use holomorphic coordinates in the x 1 , x<sup>2</sup> plane and the y1, y<sup>2</sup> plane, the coordinate transformation simplifies to

$$x_{+} = x_{-} + \frac{t}{y}$$

$$x_{+}^{3} = x_{-}^{3}.$$
(5.7)

We denoted t = Nℏ <sup>2</sup>πi.

The local deformation of T <sup>∗</sup>R 3 is not easily promoted to a deformation of a general T <sup>∗</sup>M3, as ω does not transform naturally when y<sup>i</sup> are multiplied by the Jacobian of a coordinate transformation. It would be interesting to identify the possible back-reacted geometries for general M3.

#### <span id="page-43-0"></span>5.2 T ∗S <sup>2</sup> × T <sup>∗</sup>R back-reaction

When studying elongated knots, we found it natural to embed them into a S <sup>2</sup> × R geometry by compactifying spatial infinity. In complex coordinates, we can cover S 2 by two patches with local coordinates x and ˜x related by xx˜ = 1 away from the origin. The cotangent bundle T ∗S 2 is described by (x, y) and (˜x, y˜) with ˜y = −x 2 y.

There is a simple way to deform this geometry so that the deformation matches the flat space back-reaction in both patches. We introduce four coordinate systems (x±, y) and (˜x±, y˜) with relations

$$x_{+}y = x_{-}y + t \tilde{x}_{+}x_{+} = 1 \tilde{x}_{-}x_{-} = 1$$
  

$$\tilde{y} = -x_{+}x_{-}y = -x_{-}^{2}y - tx_{-} = -x_{+}^{2}y + tx_{+}. (5.8)$$

With these definitions, we have

$$\tilde{x}_{+}\tilde{y} - \tilde{x}_{-}\tilde{y} = t, \qquad (5.9)$$

so the back-reaction of the two patches of T ∗S <sup>2</sup> matches correctly. The (x+, y) and (˜x+, y˜) coordinate systems available at y<sup>3</sup> > 0 define a well-known twisted cotangent bundle deformation of T <sup>∗</sup>CP<sup>1</sup> : the deformed A<sup>1</sup> singularity M<sup>t</sup> . We can make it manifest by defining the global coordinate z = x+y = −x˜+y˜ + t, so that

$$y\tilde{y} + z(z - t) = 0, \qquad (5.10)$$

with complex symplectic form

$$\omega_{\mathbb{C}} \equiv dz \frac{dy}{2\pi i y} \,, \tag{5.11}$$

whose real part enters ω. [19](#page-44-1)

The (x−, y) and (˜x−, y˜) available at y<sup>3</sup> < 0 also define the same complex symplectic manifold M<sup>t</sup> , giving a well-known alternative presentation as a twisted cotangent bundle. Now, z = x−y + t = −x˜−y˜.

The two manifolds are identified trivially away from the y<sup>3</sup> = 0 locus, so we identify the whole geometry with M<sup>t</sup> × T <sup>∗</sup>R.

## <span id="page-44-0"></span>5.3 Wilson lines, strings and D-branes

The standard holographic interpretation of a Wilson line in the fundamental representation C <sup>N</sup> involves an extended string worldsheet in the dual space-time, with a shape that approaches the support of the Wilson line at the boundary [\[8\]](#page-104-6). This perspective holds in the context of Chern-Simons theory as well. Furthermore, the non-renormalization properties of the A-model worldsheet theory allow for instanton calculations at all orders of the genus expansion, "counting" appropriately the contributions from extended worldsheets of given topology.

As we discussed before, the genus zero part of the calculation is not very sensitive to the topology of the boundary Wilson line. The two terms in the unknot vev can be ascribed to two classical worldsheets which differ in homology by the S 2 supporting the back-reaction. We thus identify g <sup>2</sup> with exp R <sup>S</sup><sup>2</sup> <sup>ω</sup> = exp <sup>N</sup><sup>ℏ</sup> and thus <sup>ℏ</sup> <sup>=</sup> 2πi κ+N . A more careful comparison with HOMFLY knot invariants requires careful calculations in higher genus.

Wilson lines associated to 1d fermions have a standard interpretation as D-branes [\[16,](#page-104-12) [47\]](#page-106-10). For the problem at hand, they are expected to be three-dimensional D-branes in the A-model, wrapping asymptotically the co-normal bundle N<sup>∗</sup>K ⊂ T <sup>∗</sup>M<sup>3</sup> to the support K of the Wilson loop.

<span id="page-44-1"></span><sup>19</sup>The M<sup>t</sup> geometry has a real Lagrangian cycle such that the period of the complex symplectic form is t: a circle in the y plane fibered over a segment from 0 to t in the z plane, shrinking smoothly at both ends.

We thus aim to match the large N saddles of the Wilson loop correlation functions to D-branes with the correct asymptotic shape. In practice, we need a way to map the rung vevs to the data which deforms N<sup>∗</sup>K ⊂ T <sup>∗</sup>M<sup>3</sup> to a D-brane in the back-reacted geometry.

D-branes in the A-model also do not have local degrees of freedom. A typical way to present a D-brane is to specify a Lagrangian submanifold equipped with a U(1) flat connection, but this data can be deformed without changing the actual D-brane. If we encode an infinitesimal deformation of the Lagrangian support into a 1-form on the Lagrangian, any exact form gives an equivalent D-brane.

Additionally, the A-model depends holomorphically on the complex combination of the 1-form describing shape deformations and the connection 1-form for the U(1) bundle, up to GL(1) gauge transformations. The world-volume theory of an A-model D-brane is really an analytically continued Chern-Simons theory in the sense of [\[48\]](#page-106-11).

There are two general complementary perspectives on D-branes:

- One can describe a collection of recipes to construct D-branes. The main challenge is to recognize different recipes giving the same D-brane. Furthermore, there may exist D-branes which cannot be realized by any recipe in the collection.
- One can describe a procedure to extract a mathematical signature from any Dbrane. The main challenge is to insure that no two D-branes have the same signature. Furthermore, certain signatures may not be associated to any Dbranes.

In an ideal situation, we can close the circle by building a D-brane with any given mathematical signature. A typical way to build D-branes is to deform some small collection of generating D-branes. A typical way to extract mathematical signatures is to look at the open string stretched from a generic D-brane to some small collection of probe D-branes.

In a cotangent bundle ambient space T <sup>∗</sup>M3, many D-branes can be built by deforming a stack of D-branes in the base by a GL(k) flat connection on M3. Intuitively, these represent Lagrangian submanifolds in T <sup>∗</sup>M<sup>3</sup> which intersect each fiber k times. Co-dimension 2 regular singularities can represent situations where some of the k sheets reach infinity along the cotangent fiber.

For example, minimal regular singularities supported on a knot K represent a single sheet extending to infinity along N<sup>∗</sup>K. This is precisely the data we extracted from the tree-level planar saddles in the QFT analysis, giving immediately a candidate dual D-brane in T <sup>∗</sup>M3.

## <span id="page-46-0"></span>5.4 Holomorphic tricks

We will first consider D-branes dual to a collection of m parallel Wilson lines, mimicking the QFT analysis. The S <sup>2</sup> × R setup is particularly promising, as the expected backreacted geometry M<sup>t</sup> × T <sup>∗</sup>R factors nicely and we can focus on D-branes of the form Σ × R defined from a 2d D-brane Σ in M<sup>t</sup> sitting at y<sup>3</sup> = 0 for all x 3 .

A further simplification arises from the fact that M<sup>t</sup> is a complex symplectic manifold (actually, hyperk¨ahler) and ω is the real part of the complex symplectic form ωC. This allows one to focus on complex Lagrangian submanifolds with no (expected) loss of generality. This statement is analogous to the observation that a 2d flat connection can be represented as a holomorphic bundle equipped with a meromorphic connection. See also [\[49\]](#page-106-12)

Consider first a single Wilson line placed at x = x1. Being on S 2 , the label of the Wilson line will ultimately have to be 0 or N unless some other Wilson line is present. Before back-reaction, we expect a D-brane dual with equation x = x1. After back-reaction, that may become something like x<sup>+</sup> = x<sup>1</sup> or x<sup>−</sup> = x1. Both options are nice complex submanifolds of M<sup>t</sup> :

$$L_{+}: x_{1}y - z = 0$$
  $x_{1}(z - t) + \tilde{y} = 0$   
 $L_{-}: x_{1}y - z + t = 0$   $x_{1}z + \tilde{y} = 0$ . (5.12)

Observe that from the point of view of L+, L<sup>−</sup> is obtained as a deformation by the GL(1) connection δz <sup>y</sup> = t y , which has holonomy g <sup>2</sup> around the origin in the y plane. The same is true in the ˜y plane. The reader should be reminded of the conditions we encountered on M for m = 1, n = 1. We tentatively identify L<sup>+</sup> and L<sup>−</sup> with the k = 0 and k = N Wilson lines.

These curves are remarkably rigid. For example, a deformation

$$z = x_1 y + a \tag{5.13}$$

naively interpolates between them, but has a secret problem: as y → 0, ˜y diverges:

$$\tilde{y} = x_1 \frac{z(z-t)}{z-a} \,. \tag{5.14}$$

Accordingly, this curve has an extra branch reaching infinity in M<sup>t</sup> along the ˜y direction.

On the other hand, consider the equation

$$\tilde{y} + x_1(z - t) + x_2 z - x_1 x_2 y = 0. (5.15)$$

Secretly, this is the union of L<sup>+</sup> and L−: if y ̸= 0 it is equivalent to (z−x1y)(z−t−x2y) = 0 and if ˜y ̸= 0 it is equivalent to (˜y + x1(z − t))(˜y + x2z) = 0. We can deform it to

$$L_{2,1}[a]: \tilde{y} + (x_1 + x_2)z - x_1x_2y - a = 0.$$
 (5.16)

If y ̸= 0, the equation

$$z(z-t) - (x_1 + x_2)zy + x_1x_2y^2 + ay = 0 (5.17)$$

reaches infinity along z = x1y and z = x2y. If ˜y ̸= 0, we get

$$\tilde{y}^2 - (x_1 + x_2)z\tilde{y} + x_1x_2z(z - t) - a\tilde{y} = 0, \qquad (5.18)$$

and still only reach infinity along the same directions ˜y = −x1z and ˜y = −x2z.

We thus get a one-parameter family of D-branes which are potentially dual to two parallel Λ•C <sup>N</sup> Wilson lines. To do better, we need to learn how to put coordinates on these families of D-branes: the a coordinate is not a complex coordinate on the space of D-branes. Instead, the real and imaginary parts of a should be combined with U(1) connection data into new holomorphic coordinates.

This process is well-understood for families of holomorphic Lagrangian branes in T <sup>∗</sup>C, where C is a Riemann surface. These are identified with moduli spaces of Higgs bundles via a spectral curve construction in C. A hyperk¨ahler rotation converts that into moduli spaces of flat connections on C, parameterized by monodromy data. This is the correct set of holomorphic coordinates to describe the D-brane moduli space [\[50,](#page-106-13) [51\]](#page-106-14).

Here, we can restrict the Lagrangian branes to T <sup>∗</sup>C patches in M<sup>t</sup> and apply the procedure to the patch. We do so in Appendix [A,](#page-53-0) with a simple result: the moduli space of D-branes in M<sup>t</sup> which deform the combination of (m − n) copies of the L<sup>+</sup> line and n copies of L<sup>−</sup> is precisely Pm,n. The restriction to a patch parameterized by x<sup>+</sup> or y gives respectively the two presentations of Pm,n as a GL(m) character variety on the y plane or as a GL(n) character variety on the x<sup>+</sup> plane.

In other words, Pm,n is the phase space for D-branes in Mt×T <sup>∗</sup>R with the expected asymptotics. This gives a direct proof of the relation between rung vevs on straight Wilson lines and the holographic dual D-branes.

#### <span id="page-47-0"></span>5.5 Branes in M<sup>t</sup> × T <sup>∗</sup>R

The relation extends readily to braids. A 3d flat connection on C × R is the same as a covariantly constant family of connections on C evolving along the x <sup>3</sup> direction. In the presence of singularities, "covariantly constant family" really means "isomonodromic family". In the case at hand, the braid group acts on Pm,n precisely by isomonodromic deformation of the x<sup>i</sup> parameters.

As a consequence, a sequence of rung vevs related by braid transformations is the same as the choice of a holomorphic D-brane evolving under the braiding of the x<sup>i</sup> asymptotic parameters.

In order to obtain a complete match with our augmentation variety calculations, we need to show that the cup and cap constraints match the requirements for a cylindrical D-brane with holomorphic cross section to be able to "end" at sufficiently large and positive or negative x 3 .

We expect the constraint to be "local" on C × R. Indeed, cups and caps impose a local constraint on the pair of left- or right-eigenvectors associated with the merging strands. Accordingly, the main question is how one can end a D-brane with crosssection L2,1[a].

We can gain some insight by decomposing a cup/cap into a "junction" merging the two strands, combined with an "endpoint" which forces the new strand to have label Λ <sup>N</sup> C <sup>N</sup> . These junctions and their planar limit are discussed in Appendices [C](#page-69-0) and [D.](#page-77-0)

Remarkably, the junctions impose constraints which are g-independent. They require either the left- or right-eigenvectors of the merging strands to have a specific proportionality and identify one of them with the eigenvector of the new strand. The monodromy around the pair of merging strands becomes the monodromy around the new strand. The left vs right choice is determined by the junction being 2 → 1 or 1 → 2.

The g-independence of the junction constraints suggests that the holographic interpretation of the junctions should involve properties of D-branes in T <sup>∗</sup>R 3 . On the other hand, the endpoints obviously depend on g <sup>2</sup> and should thus be sensitive to the back-reaction. On the other hand, they should not be sensitive to the S <sup>2</sup> vs R 2 choice of transverse geometry.

#### <span id="page-48-0"></span>5.6 Twisted connections on R <sup>3</sup>\{0} and endpoints.

As the local back-reacted geometry takes the form of a twisted cotangent bundle of R <sup>3</sup>\{0}, we can build D-branes as twisted connections on R <sup>3</sup>\{0}. In practice, this is just a connection with constant diagonal curvature tωS<sup>2</sup> .

The simplest option for a single D-brane is to just take the primitive of tωS<sup>2</sup> we discussed earlier in this Section to define x i <sup>−</sup>. This has a regular singularity at positive y3, y<sup>1</sup> = y<sup>2</sup> = 0, with holonomy g 2 . It tells us that this configuration has a "spike" which extends towards large positive y<sup>3</sup> and large x, with holonomy g <sup>2</sup> around the origin of the x plane. This looks like an L<sup>−</sup> brane combined with a ray in the positive y<sup>3</sup> direction.

Such a configuration could be modified to have a different shape at large y<sup>3</sup> in the x 3 , y<sup>3</sup> plane while keeping the same L<sup>−</sup> transverse shape. In particular, it could be bent to have asymptotically constant y<sup>3</sup> and extend towards large positive or negative x3. Then the asymptotic part of the D-brane would precisely look like the dual to a strand of label Λ<sup>N</sup> C N .

This is our conjectural realization of the future and past endpoints for individual strands, denoted as Π<sup>N</sup> and I<sup>N</sup> in Appendices [C](#page-69-0) and [D.](#page-77-0)

When the ending strands are part of a collection of m strands, these endpoints force the 2d connection to take a block triangular form, implemented by setting to zero the last component of all left- or right- eigenvectors except the one for the ending strand, with one block being the rank n − 1 connection associated with the surviving m − 1 strands.

This sort of triangular structure is a typical ingredient in the definition of constructible sheaves. It should fit into a general "microlocal" mathematical framework to build D-branes in the back-reacted geometry.

It seems possible to extend this discussion to directly deal with cups and caps. We can consider a primitive of tωS<sup>2</sup> which has regular singularities at both poles, with holonomies µ <sup>2</sup> and g 2µ −2 . This represents spikes with cross-section L<sup>−</sup> and L<sup>+</sup> projecting towards positive and negative y3.

If we "bend" the spikes towards, say, positive x3, the configuration can be used to end a pair of strands with labels adding up to N, i.e. to produce a cup. Again, we expect the cup constraints to describe how such a gadget can be glued to 2d flat connections associated to m and m − 2 strands to make a D-brane in the back-reacted geometry.

## <span id="page-49-0"></span>5.7 Branes without end

We can briefly discuss D-branes in a

$$\mathcal{M}_t \times T^* S^1 \tag{5.19}$$

geometry. Picking a convenient patch of M<sup>t</sup> , a D-brane can be built from a 3d GL(n) twisted flat connection on S <sup>2</sup>×S 1 , i.e. a 3d flat connection on R <sup>2</sup>×S <sup>1</sup> with a holonomy g <sup>2</sup> around infinity in the R 2 factor.

As discussed in the Introduction and in Section [4,](#page-34-0) this is precisely the data associated with an open planar saddle for a closed braid in S <sup>2</sup> ×S 1 . We thus have a complete holographic match.

## <span id="page-50-0"></span>6 Conclusions and open directions

In the main text and Appendices of this paper, we have given a detailed derivation of the following aspects of SU(N)<sup>κ</sup> Chern-Simons Holography:

- For any knot/link K with Λ•C <sup>N</sup> representations and 3d manifold M3, we have given a complete match between large N saddles and dual D-branes in a g → 1 limit.
- For any number m of parallel Λ•C <sup>N</sup> strands in S <sup>2</sup> × R (or R 3 ), we have matched the space of possible planar vevs of mesonic operators to the classical phase space of the dual D-branes. Both sides of the correspondence have a natural finite N "quantization", which also matches.
- Given the Schubert presentation of a knot/link K with Λ•C <sup>N</sup> representations as a capped braid, we give a geometric definition of the the space of large N saddles (augmentation variety) as a continuously evolving 2d flat connection jumping in a specific manner at the cups/caps where strands merge. This determines a continuously evolving dual D-brane, but we have not proven that the cups and caps conditions match the geometric constraints on the dual D-brane.
- The analysis of closed braids in M<sup>3</sup> = S <sup>2</sup> × S <sup>1</sup> does not require cups or caps. We can thus fully recover the dual D-branes.
- We have applied our construction to determine the augmentation variety of a large collection of knots. Reassuringly, different Schubert presentations of the same knot give consistent answers.

Our work leaves many open questions:

- It would be nice to show that a proper application of the theory of constructible sheaves as descriptions of three-dimensional A-model D-branes [\[30,](#page-105-5) [31\]](#page-105-6) to the back-reacted A-model geometry matches our cups and caps gluing rules for families of two-dimensional D-branes. This would complete the proof of planar holographic duality for compact knots/links with Λ•C <sup>N</sup> labels. A detailed comparison to the DGA construction in [\[22\]](#page-105-11) should also be straightforward.
- We have not explored the categorical structure of our construction. At the 2d level, there is a natural map

$$\mathcal{P}_{m_1,n_1} \times \mathcal{P}_{m_2,n_2} \to \mathcal{P}_{m_1+m_2,n_1+n_2}$$
 (6.1)

mapping a GL(n1) and a GL(n2) 2d flat connection to their direct sum. The normal bundle to the image describes infinitesimal deformations of the direct sum of two D-branes and thus describes spaces of open strings in ghost number 1. This construction plays a role in the description of gluing rules. It should be an ingredient in recovering the category of three-dimensional D-branes.

- As detailed in the introduction, it should be possible to characterize the large N saddles for the partition function on a general three-manifold M<sup>3</sup> in terms of a planar Skein module Sk<sup>p</sup> M<sup>3</sup> [g]. Extra Wilson lines labeled by Λ•C <sup>N</sup> may allow a characterization in terms of a dual category of D-branes.
- As a particular case, it would be interesting to study the holographic duality on Σ2×R for any Riemann surface Σ2, with or without extra Λ•C <sup>N</sup> strands placed at points in Σ2. Chern-Simons theory attaches to each such surface a Skein algebra, which should have a planar limit Sk<sup>p</sup> Σ<sup>2</sup> [g].
- Appendices [A](#page-53-0) and [B](#page-65-0) implicitly lift the geometric calculation of the augmentation variety to the calculation of the space of circle-compactified vacua of a certain 3d N = 2 SQFT. The SQFT is not the same as the SQFTs that appear in the 3d-3d correspondence [\[52–](#page-106-15)[54\]](#page-106-16), but we expect to reduce to these in a g → 1 limit. This observation could likely explain the knot-quiver correspondence [\[35\]](#page-105-10). The ellipsoid partition functions and superconformal indices of these 3d SQFTs may provide interesting knot invariants. Categorified knot invariants may also arise from the Holomorphic Topological twist of the 3d SQFTs [\[55,](#page-107-0) [56\]](#page-107-1).
- Our characterization of the moduli spaces of A-model D-branes in a deformed A<sup>1</sup> singularity can be generalized to deformed A<sup>k</sup> singularities and possibly to D and E type singularities. It would be interesting to give that a holographic interpretation as well.

As observed in the introduction, 1d defects barely scratch the surface of possible fundamental modifications of 3d CS theory, which include non-topological 2d and 3d modifications. We hope to report on these soon.

## <span id="page-51-0"></span>6.1 A surprising formula

Finally, we would like to comment on a surprising formula, Theorem 1.2 of [\[57\]](#page-107-2). This formula is interpreted in the reference as the mathematical manifestation of the holographic duality between the colored HOMFLY polynomials of a knot K and an A-model D-brane supported on a specific deformation L<sup>K</sup> of the knot conormal, which has the topology of a solid torus.

The formula is exact at finite N and does not involve any large N analysis. The left hand side of the formula collects all possible instanton corrections to a world-volume calculation on LK. It is presented as an element of a Skein algebra of LK, i.e. a direct sum of Wilson lines on L<sup>K</sup> which should be inserted in a GL(r) Chern-Simons correlation function on L<sup>K</sup> in order to produce a String Theory answer for r D-branes wrapping LK.

The correlation function will depend on a choice of r longitudinal holonomies ρa. Inserting the right hand side of the formula in GL(r) Chern-Simons theory, we will get a generating function of colored HOMFLY polynomials, weighed by certain functions of ρa, q and g.

This statement is clearly much stronger than the standard expectation from holography. It is also not immediately suited for a large N expansion, as the right-hand side includes HOMFLY polynomials labeled by Young Tableaux with any number of boxes. It thus includes objects which do not admit a 't Hooft expansion.

A preliminary step in a large N analysis would be to find a linear functional F on the Skein module of L<sup>K</sup> which selects a specific HOMFLY polynomial or linear combination thereof with a good 't Hooft expansion, such as our ⟨WK(λ) or a symmetric power analogue. Then the left hand side evaluated on F could be analyzed in a planar limit, and one may try to figure out how the expected augmentation variety of large N saddles will emerge from the calculation. See e.g. [\[58\]](#page-107-3) for the Hopf link.

This kind of result strongly reminds us of the "giant graviton expansion" proposed in [\[59\]](#page-107-4). That reference also offers a formula with a holographic flavour which is nevertheless exact at finite N and involves a sum over terms computed by an auxiliary GL(r) problem and interpreted as contributions from r copies of a specific dual D-brane.

In that situation, it is also the case that the D-brane which appears to contribute to the formula is only one of many possible large N saddles. A large N expansion of the formula must somehow reproduce the other D-brane saddles as well as non-trivial geometries, but the details are unclear.

In the case of the giant graviton expansion, the formula has the flavor of an equivariant localization result, with the relevant D-branes being the equivariant fixed points of a much more mysterious String Theory phase space. It would be interesting to explore a similar interpretation for the results of [\[58\]](#page-107-3).

## Acknowledgments

We would like to thank Mina Aganagic, Alexander Braverman, Kevin Costello, Joel Kamnitzer, David Nadler, Vivek Shende, and Ben Webster for useful conversations and feedback on the draft. This research was supported in part by a grant from the Krembil Foundation. DG is supported by the NSERC Discovery Grant program and by the Perimeter Institute for Theoretical Physics. Research at Perimeter Institute is supported in part by the Government of Canada through the Department of Innovation, Science and Economic Development and by the Province of Ontario through the Ministry of Colleges and Universities.

## <span id="page-53-0"></span>A Some auxiliary SQFTs

In the course of our analysis in the main text, we encounter complex symplectic manifolds Pm,n which admit multiple presentations as character varieties M[G, C], i.e. parameterize the monodromy/Stokes data of flat connections with structure group G on a surface C with prescribed singular behavior at marked points. We also need to identify Pm,n with a moduli space of A-model D-branes in a deformed A<sup>1</sup> singularity.

In this Appendix we provide an alternative interpretation of Pm,n in terms of auxiliary Supersymmetric Quantum Field Theories with eight supercharges, as well as auxiliary brane constructions in IIA String Theory and M-theory. This extra structure guarantees the equivalence of different characterizations of Pm,n and simplifies the detailed match between them.

As an extra bonus, the constructions also provide matching canonical quantizations of Pm,n in all of its presentations. This includes both the quantum algebras Am,n of observables, which admit multiple presentations as skein algebras Skq[G, C] that "quantize" the monodromy/Stokes data, and finite N Hilbert spaces. This gives a finite N holographic match for time-independent brane configurations.

## <span id="page-53-1"></span>A.1 Classical representations from three-dimensional SCFTs

The quantum group Uq(glm) and its representations play a key role in the main text. We will see that the quantization of Pm,n is a q-deformed analogue of the quantization of the Grassmannian Grm,n, which produces specific irreducible U(glm) representations. In turn, this is a generalization of the fuzzy sphere construction.

Accordingly, we start from an SQFT associated with the Grassmannian: the threedimensional N = 4 U(n) SQCD with m flavors. This theory is a special case of a class of 3d quiver gauge theories denoted as Tρ[U(m)] in [\[60\]](#page-107-5), which have a manifest U(m) symmetry and are labeled by a partition ρ of m. Here, ρ is the partition (n, m − n). Much of our discussion below can be extended in a straightforward way to a generic partition ρ.

The theory Tn,m−n[U(m)] has a hyperk¨ahler Higgs branch which can be presented as

$$\mathcal{P}_{m,n}^{3d} \equiv T^* \mathbb{C}^{nm} /\!\!/ \mathrm{GL}(n) , \qquad (A.1)$$

as a complex symplectic manifold: the Hamiltonian reduction of  $T^*\mathbb{C}^{nm}$  by the obvious GL(n) action. The reduction depends on a choice of FI parameter t and can be presented in two different ways as a twisted cotangent bundle of the Grassmannian  $Gr_n(\mathbb{C}^m)$ , with twist proportional to t.

If we denote the matter fields in  $T^*\mathbb{C}^{nm}$  as X,Y, the Hamiltonian reduction enforces the F-term relation

<span id="page-54-1"></span>
$$YX = t \, 1_{n \times n} \,, \tag{A.2}$$

and quotients by the GL(n) symmetry acting on X from the right and Y from the left. The gauge-invariant operators are generated by the  $m \times m$  GL(m) moment maps:

$$Z = XY. (A.3)$$

They satisfy the relation  $Z^2 = tZ$ , defining a special orbit in  $\mathfrak{gl}_m$ : the matrix Z has n eigenvalues "t" and m-n eigenvalues "0".

The presentation as a twisted cotangent bundle proceeds as follows. The moment map relations imply that X has rank n. We can define charts where a subset of n rows in X is linearly independent, and use the GL(n) symmetry to make it the identity. Then (A.2) can be solved in terms of the corresponding  $n \times n$  block in Y. The remaining components of X parameterize the base, and those of Y the fiber. Under a change of coordinates, the fiber coordinates transform affine-linearly. A second description switches the roles of X and Y.

The Higgs branch  $\mathcal{P}_{m,n}^{3d}$  has a natural and physically motivated quantization [61]: the quantum Hamiltonian reduction of the Weyl algebra associated to  $T^*\mathbb{C}^{nm}$ . The reduction still depends on a parameter t and can be also described (in two ways) in terms of twisted holomorphic differential operators on  $\operatorname{Gr}_n(\mathbb{C}^m)$ . The resulting algebra  $A_{m,n}^{3d}$  is generated by the quantum  $\operatorname{GL}(m)$  moment maps, which satisfy the relations of  $U(\mathfrak{gl}_m)$  but also extra relations deforming  $Z^2 = tZ$ . It is thus a quotient of  $U(\mathfrak{gl}_m)$ .

It is interesting to consider the unitary oscillator representation of the Weyl algebra, with  $Y = X^{\dagger}$ . This requires a quantization of  $t = N\hbar$ . The resulting Hilbert space involves  $\mathrm{SL}(n)$ -invariant states built from nN raising operators, giving an irreducible representation of  $\mathrm{GL}(m)$  labelled by a Young Tableau with N columns of height n. This is the natural quantization of the  $Y = X^{\dagger}$  real locus  $\mathcal{P}_{m,n}^{3\mathrm{d},\mathbb{R}} \subset \mathcal{P}_{m,n}^{3\mathrm{d}}$ , which is isomorphic to  $\mathrm{Gr}_n(\mathbb{C}^m)$  under a hyperkähler rotation.

The simplest case m=2, n=1 is the familiar "fuzzy sphere" quantization of  $S^2$ , giving the spin N/2 representation of  $U(\mathfrak{gl}_2)$ .

#### <span id="page-54-0"></span>A.2 Classical representations from Coulomb branches

Three-dimensional mirror symmetry gives an alternative presentation of  $\mathcal{P}_{m,n}^{3d}$  as a Coulomb branch of another quiver gauge theory  $T^{\rho}[U(m)]$  with m-1 gauge nodes.

From this point on, we pick 2n ≤ m without loss of generality, so n ≤ m − n. The nodes of the quiver have ranks which start with 1 at the leftmost node, increase by one at each subsequent node until they reach n−1, followed by m −2n+ 1 nodes of rank n and then a sequence with rank decreasing by one at each step, from n − 1 to 1. There is a single fundamental flavour at the leftmost and rightmost nodes of rank n, or two if these coincide. They have mass parameters 0 and t. See Figure [17.](#page-55-0)

<span id="page-55-0"></span>![](_page_55_Figure_1.jpeg)

Figure 17: The quiver for T (n,m−n) [U(m)]. There are m − 2n + 1 nodes with gauge group U(n).

The Coulomb branch description hides the GL(m) global symmetry of P 3d m,n and A3d m,n, but highlights a second hidden integrable structure. It presents them as BFN algebras [\[62–](#page-107-7)[64\]](#page-107-8). The base of the integrable system is parameterized by the coefficients of the m − 1 polynomials defined as the top left a × a minors of z − Z.

As the rank of Z is n, the polynomials for a > n have an overall factor of z a−n . Furthermore, as the rank of Z −t is m−n, there is an additional factor of (z −t) a−m+n . We thus recognize the structure of the quiver:

- 1. If a ≤ n the minors are generic monic degree a polynomials and have a independent coefficients.
- 2. If n ≤ a ≤ m−n the minors have a factor of z <sup>a</sup>−<sup>n</sup> and only contain n independent coefficients.
- 3. If m − n ≤ a the minors have a factor of z a−n (z − t) <sup>a</sup>−m+<sup>n</sup> and have m − a independent coefficients.

The total number of interesting coefficients in the polynomials is n(m − n), and they are known to Poisson-commute, giving P 3d m,n an integrable system structure. Upon quantization, these Hamiltonians become the Gelfand-Tsetlin basis: Casimirs of U(gl<sup>a</sup> ) blocks inside U(glm). The above truncation structure persists.

## <span id="page-56-0"></span>A.3 Quantum group representations from Coulomb branches and multiplicative Higgs branches

At this point we are ready to move to quantum groups. The Coulomb branch description of the 3d theory has a "K-theoretic" trigonometric deformation associated with the circle compactification of a 4d N = 2 gauge theory defined by the same quiver data. The K-theoretic Coulomb branch will be identified with Pm,n from the main text, and the K-theoretic algebra Am,n with the corresponding quotient of Uq(glm).

Classically, the relation to Uq(glm) will be expressed by parameterizing Pm,n in terms of an analogue to λ: an m × m matrix M such that M − 1 has rank n and M − g <sup>2</sup> has rank m − n, together with a decomposition of M into the product of an upper-triangular, a diagonal, and a lower-triangular matrix. We will also derive a "multiplicative Higgs branch" description, where the elements of the three sub-matrices are expressed as inner products of m vectors Y<sup>i</sup> and m co-vectors X<sup>i</sup> in C n , constrained by a multiplicative F-term relation:

$$(1_{n \times n} + Y_m X_m) \cdots (1_{n \times n} + Y_1 X_1) = g^2 1_{n \times m}.$$
 (A.4)

These descriptions identify Pm,n with two character varieties.

## <span id="page-56-1"></span>A.4 Brane engineering

The path to the character varieties descriptions passes through a remarkable String Theory construction [\[40,](#page-106-4) [65–](#page-107-9)[67\]](#page-107-10). Namely, the 4d N = 2 linear quiver gauge theories can be engineered by a brane construction in IIA string theory, involving a variable number of "D4 branes", m "NS5 branes" and 2 "D6 branes". An M-theory lift of the problem maps the system to a single "M5 brane" wrapping a family of complicated, non-compact holomorphic curves in a two-center Taub-NUT manifold.

As a complex symplectic manifold, the two-center Taub-NUT manifold is the same as the deformed A<sup>1</sup> singularity M<sup>t</sup> :

$$y\tilde{y} = z(z-t), \tag{A.5}$$

with complex symplectic form dz d log y±. In the main text, we encounter M<sup>t</sup> first as a factor in the A-model background which is holographically dual to Chern-Simons theory on S <sup>2</sup>×R. We also focus on A-model D-branes supported on certain holomorphic curves in M<sup>t</sup> . This is not a coincidence: the K-theoretic Coulomb branch of the 4d N = 2 quiver gauge theories is recovered from the family of holomorphic curves by the same sequence of operations which we employ in the main text to describe the moduli space of A-branes:

- 1. Restrict to a convenient  $T^*C$  patch.
- 2. Identify the holomorphic curves as spectral curves of Higgs bundles on C.
- 3. Hyperkähler rotate the moduli space of Higgs bundles on C to a moduli space of flat connections on C, parameterized by monodromy/Stokes data.

The choice of patch can be tracked back to the original IIA setup as different ways to organize the collection of D6 and NS5 branes, related by "Hanany-Witten" transitions [68].

The quiver data is converted into a polynomial equation for the spectral curve following [65]. The ranks of the gauge groups indicate the number of "D4 segments" between consecutive NS5 branes. Here they grow linearly from 1 to n, remain at n until the (m-n)-th interval and then decrease linearly to 1. The two D6 branes are placed in the intervals for the gauge nodes which carry a fundamental flavor: n-th and (m-n)-th.

If we use Hanany-Witten moves to bring the D6 branes all the way to the left or to the right of the NS5 branes, the number of D4 brane segments changes to grow linearly from 1 to m. The associated character variety description involves the Stokes/monodromy data of a GL(m) flat connection on the y (or  $\tilde{y}$ ) plane with a rank 1 irregular singularity at infinity and a regular singularity at the origin, with monodromy M which satisfies  $(M-1)(M-g^2)=0$  and has n eigenvalues  $g^2$  (or 1). This makes contact with the classical limit of  $U_{\mathfrak{g}}(\mathfrak{gl}_m)$ .

If we bring the D6 branes to opposite sides, the number of D4 brane segments becomes constant n. The associated character variety description involves the monodromy data of a GL(n) flat connection on the z/y plane, with minimal regular singularities at m points and monodromy  $g^2$  at infinity. This is the "multiplicative symplectic quotient" description.

The support of the M5 brane in  $\mathcal{M}_t$  is described by the polynomial equation

<span id="page-57-0"></span>
$$\tau_0(z-t)^n z^{m-n} + \tau_1(z-t)^{n-1} z^{m-n-1} P_{1,\ell}(z) y + \dots + \tau_n z^{m-2n} P_{n,1}(z) y^n + \dots + \tau_{m-n} P_{n,m-2n+1}(z) y^{m-n} + \dots + \tau_{m-1} P_{1,r}(z) y^{m-1} + \tau_m y^m = 0$$
(A.6)

in the (y, z) patch. We should supplement it with an equation for the  $(\tilde{y}, z)$  patch:

$$\tau_{0}\tilde{y}^{m} + \tau_{1}P_{1,\ell}(z)\tilde{y}^{m-1} + \dots + \tau_{n}P_{n,1}(z)\tilde{y}^{m-n} + \dots + \tau_{m-n}P_{n,m-2n+1}(z)(z-t)^{m-2n}\tilde{y}^{n} + \dots + \tau_{m-1}P_{1,r}(z)z^{n-1}(z-t)^{m-n-1}\tilde{y} + \tau_{m}z^{n}(z-t)^{m-n} = 0.$$
(A.7)

At large z and y, the equation (A.6) reduces to

$$\tau_0 z^m + \tau_1 z^{m-1} y + \ldots + \tau_m y^m = 0, \qquad (A.8)$$

with m roots for z/y we identify with the  $x_i$  parameters.

The equation gives an m-sheeted cover of the y plane, i.e. m possible values for the dual coordinate  $z/y = x_+$ . The coordinate goes to  $x_i$  at large y, giving the rank 1 irregular singularity whose Stokes data will be braided as we braid the  $x_i$ . At  $y \to 0$ , we have a regular singularity with n branches with  $x_+ \sim t/v$ , i.e. monodromy eigenvalue

$$g^2 = e^{2\pi it} \,. \tag{A.9}$$

If we replace  $x_+$  with  $x_- = (z - t)/y$ , we simply shift the whole connection by t/y, redefining the monodromy matrix M around the origin with  $g^{-2}M$ .

Because the gauge groups in the quiver theory are U instead of SU, the Stokes data which parametrizes  $\mathcal{P}_{m,n}$  consists of two triangular Stokes matrices, one upper triangular and one lower triangular, together with a diagonal formal monodromy which is part of the data. The formal monodromy parameters  $\mu_i^2$  are multiplicative moment maps for an  $U(1)^m$  global symmetry of  $\mathcal{P}_{m,n}$  which conjugates the Stokes data by a diagonal matrix.

Their product is M. For later convenience, we split the formal monodromy into two factors and write

$$M = \hat{K}\hat{f}_{-}\hat{K}\hat{e}_{+}, \tag{A.10}$$

constrained to have  $n g^2$  eigenvalues and m - n 1 eigenvalues.

In the  $x_+ = z/y$  plane, with fiber coordinate y, we write

$$\tau_{0}(yx_{+}-t)^{n}x_{+}^{m-n} + \tau_{1}(yx_{+}-t)^{n-1}x_{+}^{m-n-1}P_{1,\ell}(yx_{+}) + \dots + \tau_{n}x_{+}^{m-2n}P_{n,1}(yx_{+}) + \dots + \tau_{m-n}P_{n,m-2n+1}(yx_{+}) + \dots + \tau_{m-1}P_{1,r}(yx_{+})y^{n-1} + \tau_{m}y^{n} = 0,$$
(A.11)

and find an *n*-sheeted cover, leading to a GL(n) flat connection with minimal regular singularities at the locations  $x_i$  and a monodromy  $g^2$  at infinity.

Because the gauge groups in the quiver theory are U instead of SU, the monodromy data which parametrizes  $\mathcal{P}_{m,n}$  includes a choice of non-trivial left eigenvectors  $s_i$  at each singularity, and the monodromy eigenvalue  $\mu_i^2$  is part of the data. The monodromy parameters  $\mu_i^2$  are again multiplicative moment maps for an  $U(1)^m$  global symmetry of  $\mathcal{P}_{m,n}$  which acts on  $s_i$  multiplicatively.

We can package the monodromy eigenvalue information into a choice of non-trivial right eigenvectors  $\tilde{s}_i$ . The monodromy around the punctures can then be written as

$$M_i = 1 + s_i \tilde{s}_i \,. \tag{A.12}$$

This implies  $\tilde{s}_i \cdot s_i = \mu_i^2 - 1$ , where  $K_i^2$  is the monodromy eigenvalue. We see that the data of  $s_i$  and  $\tilde{s}_i$  completely specifies the monodromy data. The total monodromy is

constrained:

$$M_m M_{m-1} \cdots M_1 = g^2$$
. (A.13)

Such a connection can be equivalently interpreted as a *twisted* connection on  $\mathbb{CP}^1$  with m minimal regular singularities, which is precisely the natural description for an A-model D-brane in a twisted cotangent bundle of  $\mathbb{CP}^1$ , e.g.  $\mathcal{M}_t$ .

### <span id="page-59-0"></span>A.5 Translating between descriptions

Consider a 2d GL(n) flat connection with m minimal regular singularities placed roughly along the real axis. The monodromy eigenvalue is not fixed and a choice of non-trivial (left) eigenvector at each singularity is part of the definition of the moduli space. Denote as  $s_i$  the left eigenvectors transported to infinity along the positive y axis and  $\tilde{s}_i$  the right eigenvectors, normalized so that the monodromy  $M_i$  along a path which descends to the left of the i-th singularity goes around it counterclockwise once and goes back to infinity takes the form specified above:

$$M_i = 1 + s_i \tilde{s}_i \,, \tag{A.14}$$

with  $\tilde{s}_i \cdot s_i = K_i^2 - 1$ . This implies

$$M_i^{-1} = 1 - K_i^{-2} s_i \tilde{s}_i. (A.15)$$

We impose

$$M_m M_{m-1} \cdots M_1 = g^2 \,,$$
 (A.16)

and quotient by overall GL(n) conjugation, leaving  $2nm - 2n^2 = 2n(m-n)$  degrees of freedom. The monodromy condition for  $g^2 \neq 1$  implies that the matrix s with entries  $s_i$  has rank n.

Compare two sets of vectors:

$$s_{i}' = M_{1}^{-1} \cdots M_{i-1}^{-1} s_{i}$$

$$s_{i}'' = M_{m} \cdots M_{i+1} M_{i} s_{i}. \tag{A.17}$$

Clearly,  $g^2 s_i' = s_i''$ . We can expand

$$s'_{1} = s_{1}$$

$$s'_{2} = s_{2} - s_{1}(\tilde{s}_{1} \cdot s_{2})K_{1}^{-2}$$

$$s'_{3} = s_{3} - s_{1}(\tilde{s}_{1} \cdot s_{3})K_{1}^{-2} - s_{2}(\tilde{s}_{2} \cdot s_{3})K_{2}^{-2} + s_{1}(\tilde{s}_{1} \cdot s_{2})K_{1}^{-2}(\tilde{s}_{2} \cdot s_{3})K_{2}^{-2}$$

$$\cdots = \cdots \qquad (A.18)$$

Collecting the vectors into matrices, we can write that as

$$s' = s \left( 1 - K_1^{-2} (\tilde{s}_1 \cdot s_2) b_{12} \right) \left( 1 - K_1^{-2} (\tilde{s}_1 \cdot s_3) b_{13} \right) \left( 1 - K_2^{-2} (\tilde{s}_2 \cdot s_3) b_{23} \right) \cdots$$
 (A.19)

Similarly,

$$s''_{m} = s_{m} \mu_{m}^{2}$$

$$s''_{m-1} = s_{m-1} \mu_{m-1}^{2} + s_{m} (\tilde{s}_{m} \cdot s_{m-1}) \mu_{m-1}^{2}$$

$$s''_{m-2} = s_{m-2} \mu_{m-2}^{2} + s_{m-1} (\tilde{s}_{m-1} \cdot s_{m-2}) \mu_{m-2}^{2} - s_{m} (\tilde{s}_{m} \cdot s_{m-2}) \mu_{m-2}^{2}$$

$$+ s_{m} (\tilde{s}_{m} \cdot s_{m-1}) (\tilde{s}_{m-1} \cdot s_{m-2}) \mu_{m-2}^{2}$$

$$\cdots = \cdots, \tag{A.20}$$

i.e.

$$s'' = s \left( 1 + (\tilde{s}_m \cdot s_{m-1}) b_{m,m-1} \right) \left( 1 + (\tilde{s}_m \cdot s_{m-2}) b_{m,m-2} \right) \left( 1 + (\tilde{s}_{m-1} \cdot s_{m-2}) b_{m-1,m-2} \right) \cdots \hat{K}^2.$$
(A.21)

Accordingly,

$$g^{2}s = s\left(1 + (\tilde{s}_{m} \cdot s_{m-1})b_{m,m-1}\right)\left(1 + (\tilde{s}_{m} \cdot s_{m-2})b_{m,m-2}\right)\left(1 + (\tilde{s}_{m-1} \cdot s_{m-2})b_{m-1,m-2}\right) \cdots \hat{K} \cdots \left(1 + K_{2}^{-1}K_{3}^{-1}(\tilde{s}_{2} \cdot s_{3})b_{23}\right)\left(1 + K_{1}^{-1}K_{3}^{-1}(\tilde{s}_{1} \cdot s_{3})b_{13}\right)\left(1 + K_{1}^{-1}K_{2}^{-1}(\tilde{s}_{1} \cdot s_{2})b_{12}\right)\hat{K}.$$
(A.22)

The  $m \times m$  matrices on the right-hand side are identified with the Stokes data of a connection with a rank 1 irregular singularity. In the notation used elsewhere in the paper, we identify the matrices as  $\hat{e}_+ = \hat{e}_-^{-1}$  and  $\hat{f}_-$ . Accordingly,  $f_{-;i,j} = K_i^{-1}K_j^{-1}(\tilde{s}_i \cdot s_j)$  and  $e_{-;i,j} = (\tilde{s}_i \cdot s_j)$ .

As  $s\hat{e}_+\hat{K}\hat{f}_-\hat{K} = g^2s$ , the matrix s is identified with the matrix of right eigenvectors of  $\hat{e}_+\hat{K}\hat{f}_-\hat{K}$  with eigenvalues  $g^2$ . We can repeat the exercise for  $\tilde{s}$ . Namely, define

$$\tilde{s}_i' = \tilde{s}_i M_{i+1}^{-1} \cdots M_m^{-1} 
\tilde{s}_i'' = \tilde{s}_i M_i \cdots M_1,$$
(A.23)

so that  $g^2 \tilde{s}'_i = \tilde{s}''_i$ . We can expand

$$\tilde{s}'_{m} = \tilde{s}_{m}$$

$$\tilde{s}'_{m-1} = \tilde{s}_{m-1} - K_{m}^{-2} (\tilde{s}_{m-1} \cdot s_{m}) \tilde{s}_{m}$$

$$\cdots = \cdots$$
(A.24)

Collecting the vectors into matrices, we can write that as

$$\tilde{s}' = \cdots \left(1 - K_m^{-2} (\tilde{s}_{m-1} \cdot s_m) b_{m-1,m} \right) \tilde{s} .$$
 (A.25)

Similarly,

$$\tilde{s}_{1}'' = \mu_{1}^{2} \tilde{s}_{1} 
\tilde{s}_{2}'' = \mu_{2}^{2} \tilde{s}_{2} + (\tilde{s}_{2} \cdot s_{1}) \mu_{2}^{2} \tilde{s}_{1} 
\dots = \dots ,$$
(A.26)

i.e.

$$\tilde{s}'' = \hat{K}^2 \cdots (1 + (\tilde{s}_2 \cdot s_1)b_{2,1}) \,\tilde{s} \,.$$
 (A.27)

Accordingly,

$$\tilde{s}g^{2} = \hat{K} \left( 1 + K_{m-1}^{-1} K_{m}^{-1} (\tilde{s}_{m-1} \cdot s_{m}) b_{m-1,m} \right) \cdots \hat{K} \cdots \left( 1 + (\tilde{s}_{2} \cdot s_{1}) b_{2,1} \right) \tilde{s} . \tag{A.28}$$

As  $\hat{K}\hat{f}_{-}\hat{K}\hat{e}_{+}\tilde{s}=g^{2}\tilde{s}$ , the matrix  $\tilde{s}$  is identified with the matrix of left eigenvectors of  $\hat{K}\hat{f}_{-}\hat{K}\hat{e}_{+}$  with eigenvalues  $g^{2}$ .

In particular, this implies that  $M = \hat{K}\hat{f}_-\hat{K}\hat{e}_+$  has both n independent left eigenvectors and n independent right eigenvectors with eigenvalues  $g^2$ . In order to complete the match to the Stokes description of  $\mathcal{P}_{m,n}$ , we need to show that M acts as the identity from the right on the orthogonal complement to  $\tilde{s}$ .

In order to do so, be  $c_i$  a collection of numbers such that  $\sum_i c_i \tilde{s}_i = 0$ , i.e.  $c\tilde{s} = 0$ . We want to compare  $c\hat{K}\hat{f}_-\hat{K}$  and  $c\hat{e}_-$ . The former has entries

$$c_1 K_1^2$$

$$c_2 K_2^2 + c_1(\tilde{s}_1 \cdot s_2)$$

$$c_3 K_3^2 + c_2(\tilde{s}_2 \cdot s_3) + c_1(\tilde{s}_1 \cdot s_3)$$

$$\cdots$$
(A.29)

But this is the same as

$$c_1 - c_2(\tilde{s}_2 \cdot s_1) - c_3(\tilde{s}_3 \cdot s_1) - \dots$$
  
 $c_2 - c_3(\tilde{s}_3 \cdot s_2) - \dots$   
 $c_3 - \dots$   
 $\dots$ , (A.30)

i.e. the entries of  $c\hat{e}_{-}$ . This shows that cM=c, as desired.

This identification can be inverted. Starting from the Stokes data  $\hat{K}$ ,  $\hat{e}_+$ ,  $\hat{f}_-$  we can define s and  $\tilde{s}$  as matrices of eigenvectors, defined up to two separate  $\mathrm{GL}(m)$  actions. We can further rigidify that by constraining the entries of  $\tilde{s}s$  to have the above expressions in terms of  $\hat{K}$ ,  $\hat{f}_-$  and  $\hat{e}_-$ . This is an over-determined set of linear equations on  $n^2$ 

variables, but it should be possible to mirror the manipulations above in order to verify that it can be solved. It is a problem completely analogous to reconstructing X and Y from the data of  $\lambda$  in  $\mathcal{P}_{m,n}^{3d}$ .

The relation we proposed here between the two presentations of  $\mathcal{P}_{m,n}$  can be derived in a more rigorous fashion as a generalized Nahm transform [62]. One takes a family of auxiliary GL(1) flat connections, either  $y_0dx_+$  on the  $x_+$  plane or  $x_0dy$  on the yplane, and looks at the space of extensions between such GL(1) flat connections and the original GL(m) or GL(n) flat connections. The space of extensions fibered over the  $y_0$  or  $x_0$  planes gives the transformed connection, and vice versa.

The transform can be expressed in the language of monodromy data. For example, we can express the Nahm transform of the GL(m) connection in terms of the space  $\mathcal{P}_{m+1,n}/\!\!/ GL(1)$  of GL(m+1) connections with the same singularity structure and parameters  $x_i$ ,  $x_0$  at infinity, with fixed  $K_0 = 1$  and quotiented by the corresponding GL(1) symmetry. There is an obvious embedding  $\mathcal{P}_{m,n} \subset \mathcal{P}_{m+1,n}/\!\!/ GL(1)$  where the GL(m+1) connection is the combination of a GL(m) connection and a trivial GL(1) connection. The normal bundle to this embedding has dimension 2n and splits into the two types of extensions, e.g. the extra rows/columns in  $\hat{e}_+$  and  $\hat{f}_-$ . If we vary  $x_0$  and braid it around the  $x_i$ , the GL(m+1) Stokes data will be braided as well. This acts linearly on the extensions, giving the desired GL(m) flat connection on the  $x_0$  plane.

### <span id="page-62-0"></span>A.6 More about the D-brane interpretation

Recall the twisted cotangent bundle interpretation of  $\mathcal{M}_t$ : we take local coordinates  $x_+ = \frac{z}{y}$  and  $\tilde{x}_+ = x_+^{-1} = \frac{z-t}{\tilde{y}}$  on the base  $\mathbb{CP}^1$ , y and  $-\tilde{y}$  on the fiber. Then  $\tilde{y} = -x_+^2y + tx_+$ , an affine deformation of the usual cotangent bundle definition.

A twisted connection on  $\mathbb{CP}^1$  is modeled on the twisted cotangent bundle: it is considered trivial at infinity if it behaves as  $\frac{t}{x_+}$  in the  $x_+$  patch. Passing to the monodromy data, a twisted GL(n) connection on  $\mathbb{CP}^1$  is simply a GL(n) connection which has monodromy  $g^2$  around infinity.

A-model D-branes in  $\mathcal{M}_t$  are expected to be described precisely by the (derived category of) such twisted connections. We conclude that  $\mathcal{P}_{m,n}$  is a moduli space of A-model D-branes in  $\mathcal{M}_t$ . We will now sharpen the geometric characterization of these D-branes.

Consider the spectral curves for m = 1, n = 0 and m = 1, n = 1:

$$L_{+}[x]: \quad z - xy = 0 \qquad \qquad \tilde{y} - x(z - t) = 0$$
  
 $L_{-}[x]: \quad z - t - xy = 0 \qquad \qquad \tilde{y} - xz = 0.$  (A.31)

These are respectively a generic fiber of the above twisted cotangent bundle presentation of  $\mathcal{M}_t$ , and a generic fiber of the second twisted cotangent bundle presentation of  $\mathcal{M}_t$ .

They both reach to the same direction x at large z and y. These are the support of rigid D-branes  $D_+$  and  $D_-$ .

Next, consider the union of m-n copies of  $D_+$  for various x's and n copies of  $D_-$  at other x's, all distinct. This can be deformed to a more general D-brane with the same asymptotic shape.  $\mathcal{P}_{m,n}$  is the moduli space of such D-branes.

If we project the D-brane to the base of the twisted cotangent bundle presentation, then the  $D_+$  branes will be "vertical", while the  $D_-[x_i]$  branes will cover  $\mathbb{CP}^1$  while also spiking along the fiber at  $x_i$ . This is why the corresponding twisted connection on  $\mathbb{CP}^1$  has rank n and m minimal regular singularities. On the other hand, the  $\mathrm{GL}(m)$  description arises from a projection on the y plane.

#### <span id="page-63-0"></span>A.7 Quantization

Finally, we can comment on the quantization of these classical relations. The character variety descriptions of  $\mathcal{P}_{m,n}$  have a natural quantization as skein algebras. The quantization maps holonomies to Wilson loops in Chern-Simons theory. The different presentations are expected to give equivalent quantizations, as the resulting algebra  $A_{m,n}$  is an intrinsic property of the 4d  $\mathcal{N}=2$  SQFT: the fusion algebra of BPS line defects [40].

In the  $\mathrm{GL}(n)$  description, the rung vevs are mapped to open fundamental Wilson lines in a  $\mathrm{GL}(n)$  Chern-Simons theory, i.e. essentially to rung operators, albeit stretched between a different type of co-dimension 2 defects. The skein relations themselves do not really know about n, and so naturally reproduce the rung algebra from the original  $SU(N)_{\kappa}$  CS theory. This can be seen as a finite N (but not yet restricted to be integer) holographic match between the operator algebra on the m  $\Lambda^{\bullet}\mathbb{C}^{N}$  Wilson lines and the quantization of the phase space of the dual D-branes.

#### <span id="page-63-1"></span>A.8 Real loci and Hilbert spaces

In order to push the analysis to the actual Hilbert space  $\mathcal{H}_{m,n}$  of the system, we need to discuss reality/hermiticity conditions.

In the original  $SU(N)_{\kappa}$  CS theory, the adjoint of a rung operator is a rung in the opposite direction:  $E_{-;ij}^{\dagger} = F_{-;j,i}$ . We also have  $\mathfrak{q}^{\dagger} = \mathfrak{q}^{-1}$  and  $g^{\dagger} = g^{-1}$ . As  $\mathfrak{q} - \mathfrak{q}^{-1}$  is pure imaginary, we get  $e_{-;ij}^{\dagger} = -f_{-;j,i}$ .

Classically, we have  $\hat{f}_{-}^{\dagger} = \hat{e}_{-} = e_{+}^{-1}$  and  $\hat{K}^{\dagger} = K^{-1}$ . As a result,  $M^{\dagger} = M^{-1}$  and M is unitary. This characterizes the real locus  $\mathcal{P}_{m,n}^{\mathbb{R}}$  in the GL(m) character variety description. Notice that  $\mathcal{P}_{m,n}^{\mathbb{R}}$  is diffeomorphic to the Grassmannian  $Gr_{m,n}$  and is in particular compact.

The quantization of a compact real phase space is expected to produce a finitedimensional Hilbert space  $\mathcal{H}_{m,n}$ , which we identify with the irreducible unitary representation of  $U_{\mathfrak{q}}(\mathfrak{gl}_m)$  labeled by a rectangular Tableau of sides n and N, i.e. a summand in the Hilbert space of the  $SU(N)_{\kappa}$  CS theory on the two-sphere in the presence of m  $\Lambda^{\bullet}\mathbb{C}^{N}$  Wilson lines.

In the  $\mathrm{GL}(n)$  description, the reality condition seems compatible with the flat connection being unitary, i.e.  $M_i^{\dagger} = M_i^{-1}$ , i.e.  $s_i^{\dagger} = \sqrt{-1}K_i^{-1}\tilde{s}_i$ . Recall that  $K_i^{\dagger} = K_i^{-1}$ . In other words, we identify  $\mathcal{P}_{m,n}^{\mathbb{R}}$  with a space of twisted U(n) flat connections with m minimal regular singularities.

This is the phase space of a  $U(n)_{\kappa+N-n}$  Chern-Simons theory, in the presence of m vortex defects and with a total Abelian charge N at infinity. There is an obvious resemblance to the original  $SU(N)_{\kappa}$  CS theory setup: if we promoted the gauge group to  $U(N)_{\kappa}$ , we would need a total Abelian charge n at infinity. The holographic duality at the level of Hilbert spaces seems to be the composition of two Howe dualities: we map the  $SU(N)_{\kappa}$  CS theory Hilbert space in the presence of m defects with "total charge" n to a unitary irrep of  $U_{\mathfrak{q}}(\mathfrak{gl}_m)$  and then to the  $U(n)_{\kappa+N-n}$  CS theory Hilbert space in the presence of m defects with total charge N. This perspective could be further justified by identifying the vortex defects with U(n) Wilson lines transforming in the symmetric powers of the fundamental representation.

### <span id="page-64-0"></span>A.9 Example: $\mathcal{P}_{2,1}$

The 3d version of the manifold  $\mathcal{P}_{2,1}^{3d} = T^*\mathbb{C}^2/\!\!/\mathrm{GL}(1)$  is itself a deformed  $A_1$  singularity

$$\lambda_{12}\lambda_{21} = \lambda_{11}(\lambda_{11} - t). \tag{A.32}$$

The real locus  $\mathcal{P}_{2,1}^{3d,\mathbb{R}}$  is defined by

$$|\lambda_{12}|^2 = \lambda_{11}(\lambda_{11} - N\hbar),$$
 (A.33)

with real  $\lambda_{11}$ , and it is a sphere  $S^2$ . The Hilbert space  $\mathcal{H}^{3d}_{2,1} = \mathbb{C}^{2N+1}$  is the spin N/2 irrep of  $U(\mathfrak{gl}_2)$ , the natural "fuzzy sphere" quantization of  $S^2$ .

The 3d theory SQED<sub>2</sub> is self-mirror, so the manifold  $\mathcal{P}_{2,1}^{3d}$  is also presented as the Coulomb branch of SQED<sub>2</sub>.

The K-theoretic Coulomb branch  $\mathcal{P}_{2,1}$  of SQED<sub>2</sub> is a multiplicative version of the deformed  $A_1$  singularity:

$$ef = (K_1 - K_1^{-1})(g/K_1 - K_1/g).$$
 (A.34)

The multiplicative Higgs branch description is simple: we start from

$$(1 + s_1 \tilde{s}_1)(1 + s_2 \tilde{s}_2) = g^2, \tag{A.35}$$

and  $e = s_2 \tilde{s}_1$ ,  $f = K_1^{-1} K_2^{-1} s_1 \tilde{s}_2$ , and get

$$ef = K_1^{-1}K_2^{-1}(K_1^2 - 1)(K_2^2 - 1),$$
 (A.36)

as desired.

The real locus  $\mathcal{P}_{2,1}^{\mathbb{R}}$  is

$$|e|^2 + (K_1 - K_1^{-1})(g/K_1 - K_1/g) = 0.$$
 (A.37)

It consists of a circle fibered over an arc in the  $K_1$  plane, shrinking at the endpoints. Topologically, it is still a sphere.

Geometrically, the M5 brane support is

$$z(z-t) + (x_1 + x_2)(z-a)y + x_1x_2y^2 = 0$$
  

$$\tilde{y}^2 + (x_1 + x_2)(z-a)\tilde{y} + x_1x_2z(z-t) = 0,$$
(A.38)

but we can also write it as the affine-linear constraint

$$\tilde{y} + (x_1 + x_2)z + x_1x_2y = (x_1 + x_2)a. \tag{A.39}$$

## <span id="page-65-0"></span>B Geometric correspondences and BPS interfaces

We begin with some representation theory. Much as  $\mathcal{H}_{m,n}$ , the Hilbert space  $\mathcal{H}_{m,n}^{3d}$  can be described either as the U(N)-invariant part of a Fock space of mN fermionic oscillators with total fermion number nN, or as the part of a Fock space of mn bosonic oscillators which transform as the N-th power of the determinant representation of U(n). These statements are derived from general Howe duality statements:

$$\Lambda^{\bullet} \mathbb{C}^{mN} = \sum_{T} R_{T}[U(N)] \otimes R_{T^{t}}[U(m)]$$

$$S^{\bullet} \mathbb{C}^{mn} = \sum_{T} R_{T}[U(n)] \otimes R_{T}[U(m)], \qquad (B.1)$$

where both sums run over Young Tableaux T. In the first case we pick the rectangular T with n columns of height N, in the second the rectangular T with N columns of height n.

In the first description, we could split the m fermionic oscillators into groups of size  $m_1$  and  $m_2$ . This gives an obvious map

$$\mathcal{H}_{m_1,n_1}^{3d} \times \mathcal{H}_{m_2,n_2}^{3d} \to \mathcal{H}_{m,n}^{3d},$$
 (B.2)

for every  $n_1 + n_2 = n$ . We would like to describe this map in terms of bosonic oscillators. In order to do so, we need a stronger result. Write:

$$\Lambda^{\bullet} \mathbb{C}^{mN} = \sum_{T_1, T_2} R_{T_1}[U(N)] \otimes R_{T_2}[U(N)] \otimes R_{T_1^t}[U(m_1)] \otimes R_{T_2^t}[U(m_2)].$$
 (B.3)

Projection over SU(N) invariants requires  $T_1$  and  $T_2$  to be vertically complementary in the nN rectangle. So we can decompose  $\mathcal{H}_{m,n}^{3d}$  into a sum of products of  $U(m_1)$  and  $U(m_2)$  irreps labelled by  $T_1^t$  and  $T_2^t$  complementary horizontally in the Nn rectangle. In particular, we can find  $\mathcal{H}_{m_1,n_1}^{3d} \times \mathcal{H}_{m_2,n_2}^{3d}$  exactly once in  $\mathcal{H}_{m,n}^{3d}$ .

Accordingly, any non-zero map will do up to a scale. The bosonic oscillators decompose into four blocks each: lowering operators  $X_{11}$ ,  $X_{12}$ ,  $X_{21}$ ,  $X_{22}$  and raising operators  $Y_{11}$ , etc. Consider states in the bosonic Fock space which are annihilated by  $X_{12}$  and  $X_{21}$  and built from  $n_1N$  of the  $Y_{11}$  and  $n_2N$  of the  $Y_{22}$  raising operators, and are  $U(n_1) \times U(n_2)$  invariant. This is a copy of  $\mathcal{H}^{3d}_{m_1,n_1} \times \mathcal{H}^{3d}_{m_2,n_2}$ . We can then average over U(n) to get a map to  $\mathcal{H}_{m,n}^{3d}$ 

The goal of this Section is to identify a classical limit of this map as a Lagrangian correspondence between  $\mathcal{P}^{\text{3d}}_{m_1,n_1} \times \mathcal{P}^{\text{3d}}_{m_2,n_2}$  and  $\mathcal{P}^{\text{3d}}_{m,n}$  and then lift it to a Lagrangian correspondence between  $\mathcal{P}_{m_1,n_1} \times \mathcal{P}_{m_2,n_2}$  and  $\mathcal{P}_{m,n}$ . This is our candidate for the classical limit of a map

$$\mathcal{H}_{m_1,n_1} \times \mathcal{H}_{m_2,n_2} \to \mathcal{H}_{m,n}$$
, (B.4)

which plays the role of a "generalized cup" in the main text: it describes states for mstrands created by two disconnected networks ending the  $m_1$  and  $m_2$  groups of strands independently. We will verify this conjecture for actual cups and caps by explicit calculations.

#### <span id="page-66-0"></span>Correspondences and half-BPS interfaces

The above bosonic construction of the map

$$\mathcal{H}_{m_1,n_1}^{3d} \times \mathcal{H}_{m_2,n_2}^{3d} \to \mathcal{H}_{m,n}^{3d}$$
(B.5)

has a simple classical limit: we impose

$$X_{11} = X^{(1)}$$

$$X_{12} = 0$$

$$X_{21} = 0$$

$$X_{22} = X^{(2)}$$

$$Y_{11} = Y^{(1)}$$

$$Y_{22} = Y^{(2)},$$
(B.6)

where X and Y are the variables from  $\mathcal{P}_{m,n}^{3d}$ ,  $X^{(1)}$ ,  $Y^{(1)}$  from  $\mathcal{P}_{m_1,n_1}^{3d}$ , and  $X^{(2)}$  and  $Y^{(2)}$  from  $\mathcal{P}_{m_2,n_2}^{3d}$ . The F-term equations are compatible with this but further impose  $Y_{12}X^{(2)}=0$  and  $Y_{21}X^{(1)}=0$ .

We have

$$2n_1m_1 + 2n_2m_2 + n_1m_2 + n_2m_1 - 2n_1^2 - 2n_2^2 - 2n_1n_2 = n_1(m_1 - n_1) + n_2(m_2 - n_2) + (n_1 + n_2)(m_1 + m_2 - n_1 - n_2)$$
(B.7)

degrees of freedom, as appropriate for a Lagrangian correspondence. We denote this as  $C_{m_1,n_1;m_2,n_2}^{3d}$ .

In terms of gauge-invariant quantities, we have

$$\lambda_{11} = \lambda^{(1)}$$

$$\lambda_{12} = X^{(1)}Y_{12}$$

$$\lambda_{21} = X^{(2)}Y_{21}$$

$$\lambda_{22} = \lambda^{(2)}.$$
(B.8)

The above equations also work to define a supersymmetric, half-BPS interface between U(n) SQCD with m flavours and the product of  $U(n_1)$  SQCD with  $m_1$  flavours and  $U(n_2)$  SQCD with  $m_2$  flavours. We only need to specify in addition that the U(n) gauge group is broken to  $U(m_1) \times U(m_2)$  at the interface [69].

The interface formulation also gives a quantization  $C^{3d}_{m_1,n_1;m_2,n_2}$  as a bimodule  $B^{3d}_{m_1,n_1;m_2,n_2}$  between  $A^{3d}_{m,n}$  and  $A^{3d}_{m_1,n_1}\otimes A^{3d}_{m_2,n_2}$ . See [69] for the general recipe.

It would be interesting to identify a mirror description of the supersymmetric interfaces, which could then be lifted to an interface between 4d  $\mathcal{N}=2$  SQFTs. We do not know how to do so.

Instead, we can tentatively apply our strategy to the multiplicative Higgs branch description of  $\mathcal{P}_{m,n}$ : we constrain  $\tilde{s}$  in the same manner as X, leading to

$$\tilde{s}_{11} = \tilde{s}^{(1)}$$

$$\tilde{s}_{12} = 0$$

$$\tilde{s}_{21} = 0$$

$$\tilde{s}_{22} = X^{(2)}$$

$$s_{11} = s^{(1)}$$

$$s_{22} = s^{(2)}$$
(B.9)

More concretely,  $\tilde{s}_1 \cdots \tilde{s}_{m_1}$  annihilate the  $\mathbb{C}^{n_2}$  summand in  $\mathbb{C}^{n_1} \oplus \mathbb{C}^{n_2}$  and  $\tilde{s}_{m_1+1} \cdots \tilde{s}_{m_1+m_2}$  annihilate the first. This is enough to guarantee that the block-diagonal part of the

total monodromy  $M_{\infty}$  acting on a vector v in  $\mathbb{C}^{n_2}$  will map it to  $g^2$  times itself plus an extra term in  $\mathbb{C}^{n_1}$ , a bilinear which should be set to 0 in analogy with the  $Y_{12}X^{(2)}=0$  conditions above.

Similarly,  $M_{\infty}^{-1}$  acting on a vector in  $\mathbb{C}^{n_1}$  will map it to  $g^{-2}$  times itself plus an extra term in  $\mathbb{C}^{n_2}$ , a bilinear which should be set to 0 in analogy with the  $Y_{21}X^{(1)}=0$  conditions above.

The conditions imply that  $K_1 = K_1^{(1)}$ , etc. and  $K_{m_1+1} = K_1^{(2)}$ , etc. Also, e's and f's within each group of strands match. On the other hand,

$$f_{-;i,m_1+j} = K_1^{-1} K_{m_1+1}^{-1} \tilde{s}_j \cdot s_{m_1+j}$$

$$e_{-;m_1+i,j} = \tilde{s}_{m_1+i} \cdot s_j$$
(B.10)

are matrices of rank  $n_1$  and  $n_2$  respectively.

#### <span id="page-68-0"></span>B.2 Preparing a cup

Now we specialize to  $m_2 = 2$ ,  $n_2 = 1$ . Then the last component of  $\tilde{s}_1 \cdots \tilde{s}_{m-2}$  is zero and only the last component of  $\tilde{s}_{m-1}$  and  $\tilde{s}_m$  are non-zero. Accordingly, inner products of bilinears can be rearranged:

$$e_{-;m,m-1}f_{-;m-1,m} = (K_{m-1} - K_{m-1}^{-1})(K_m - K_m^{-1})$$

$$(K_m^2 - 1)e_{-;m-1,j} = K_{m-1}K_mf_{-;m-1,m}e_{-;m,j}$$

$$(K_{m-1}^2 - 1)e_{-;m,j} = e_{-;m,m-1}e_{-;m-1,j}$$

$$e_{-;m,j}e_{-;m-1,k} = e_{-;m-1,j}e_{-;m,k}.$$
(B.11)

We also have  $K_m K_{m-1} = g$  and

$$g^{2} = (1 + K_{m-1}^{2} s_{m} \tilde{s}_{m} + s_{m-1} \tilde{s}_{m-1}) M_{m-2} \cdots M_{1}.$$
 (B.12)

Acting on a unit vector  $b_m$  in the last component, that gives simply

$$(g^2 - 1)b_m = K_{m-1}^2 s_m \tilde{s}_m \cdot b_m + s_{m-1} \tilde{s}_{m-1} \cdot b_m,$$
(B.13)

constraining a linear combination of  $s_m$  and  $s_{m-1}$ . That gives

$$K_{m-1}K_m f_{-i\,m}\tilde{s}_m \cdot b_m + f_{-i\,m-1}\tilde{s}_{m-1} \cdot b_m = 0.$$
 (B.14)

On the other hand,

$$g^{-2} = M_1^{-1} \cdots M_{m-2}^{-1} (1 - K_{m-1}^{-2} K_m^{-2} s_{m-1} \tilde{s}_{m-1} - K_m^{-2} s_m \tilde{s}_m)$$
 (B.15)

acting on a vector orthogonal to  $\tilde{s}_m$  gives a constraint of the form  $\sum_i \tilde{s}_m \cdot s_i \tilde{s}_i = 0$ .

In order to specialize to a cup, we further define

$$e_{-;m,m-1} = \lambda (K_{m-1} - K_{m-1}^{-1})$$
  

$$f_{-;m-1,m} = \lambda^{-1} (K_m - K_m^{-1}),$$
(B.16)

so that

$$e_{-;m,j} = \lambda K_{m-1}^{-1} e_{-;m-1,j}$$

$$K_m f_{-;i,m} \lambda = -f_{-;i,m-1}.$$
(B.17)

## <span id="page-69-0"></span>C The Uq(glm) rung algebra and the braid group

The reference [\[32\]](#page-105-7) describes diagrammatic rules for the manipulation of tensor products of Λ•C <sup>N</sup> representations of Uq(sl<sup>N</sup> ). In particular, we can represent the tensor product

$$\Lambda^{k_1} \mathbb{C}^N \otimes \ldots \otimes \Lambda^{k_m} \mathbb{C}^N \tag{C.1}$$

as a collection of vertical lines with labels k1, . . . , km.

## <span id="page-69-1"></span>C.1 The rung algebra as a representation of Uq(glm)

"Rung" operators are defined by combining canonical "junction" maps Λ<sup>r</sup>+sC <sup>N</sup> ↔ Λ <sup>r</sup>C <sup>N</sup> ⊗ Λ <sup>s</sup>C <sup>N</sup> to maps:

$$E_i^{(r)}: \Lambda^{k_i} \mathbb{C}^N \otimes \Lambda^{k_{i+1}} \mathbb{C}^N \to \Lambda^{k_i+r} \mathbb{C}^N \otimes \Lambda^{k_{i+1}-r} \mathbb{C}^N$$

$$F_i^{(r)}: \Lambda^{k_i} \mathbb{C}^N \otimes \Lambda^{k_{i+1}} \mathbb{C}^N \to \Lambda^{k_i-r} \mathbb{C}^N \otimes \Lambda^{k_{i+1}+r} \mathbb{C}^N. \tag{C.2}$$

We will mostly use E<sup>i</sup> ≡ E (1) i and F<sup>i</sup> ≡ F (1) i .

Collections of rungs can be manipulated according to the rules reviewed in Appendix [E.](#page-82-1) For example,

$$E_i^{(r)} E_i^{(s)} = \begin{bmatrix} r+s \\ r \end{bmatrix}_{\mathfrak{q}} E_i^{(r+s)}$$

$$F_i^{(r)} F_i^{(s)} = \begin{bmatrix} r+s \\ r \end{bmatrix}_{\mathfrak{q}} F_i^{(r+s)}, \qquad (C.3)$$

so e.g. E s <sup>i</sup> = [s]q!E (s) i and F s <sup>i</sup> = [s]q!F (s) i .

These algebra of rung operators together with K<sup>i</sup> = q <sup>k</sup><sup>1</sup> gives a representation of Uq(glm). By definition,

$$K_i E_i = \mathfrak{q} E_i K_i$$

$$K_{i+1} E_i = \mathfrak{q}^{-1} E_i K_{i+1}$$

$$K_i F_i = \mathfrak{q}^{-1} F_i K_i$$

$$K_{i+1} F_i = \mathfrak{q} F_i K_{i+1}.$$
(C.4)

Furthermore, the square-switch relation gives

$$E_i F_i = F_i E_i + [k_i - k_{i+1}]_{\mathfrak{q}},$$
 (C.5)

e.g.

$$[E_i, F_i] = \frac{K_i K_{i+1}^{-1} - K_i^{-1} K_{i+1}}{\mathfrak{q} - \mathfrak{q}^{-1}}.$$
 (C.6)

All other pairs of symbols except  $(E_i, E_{i+1})$  and  $(F_i, F_{i+1})$  commute, and we have Serre relations

$$E_{i}^{2}E_{i+1} - [2]_{\mathfrak{q}}E_{i}E_{i+1}E_{i} + E_{i+1}E_{i}^{2} = 0$$

$$E_{i}E_{i+1}^{2} - [2]_{\mathfrak{q}}E_{i+1}E_{i}E_{i+1} + E_{i+1}^{2}E_{i} = 0$$

$$F_{i}^{2}F_{i+1} - [2]_{\mathfrak{q}}F_{i}F_{i+1}F_{i} + F_{i+1}F_{i}^{2} = 0$$

$$F_{i}F_{i+1}^{2} - [2]_{\mathfrak{q}}F_{i+1}F_{i}F_{i+1} + F_{i+1}^{2}F_{i} = 0,$$
(C.7)

which follow, say, from the partial fusion of the two  $E_i$  rungs in  $E_i E_{i+1} E_i$  followed by the square-switch rule producing  $E_i^{(2)} E_{i+1}$  and  $E_{i+1} E_i^{(2)}$ .

#### <span id="page-70-0"></span>C.2 Rungs and braids

The reference also provides a diagram  $\beta$  which represents the braiding of two consecutive strands with labels k and l. We will use a simplified expression B with

$$\beta = (-1)^{kl} \mathfrak{q}^{-\frac{kl}{N}} B, \qquad (C.8)$$

and denote as  $B_i$  the diagram inserted between strands i and i + 1.20

- In the physical setup, the fundamental  $\mathbb{C}^N$  representation is taken to be Grassmann odd. Hence  $\Lambda^k \mathbb{C}^N$  has Grassmann parity  $(-1)^k$  and we should add a Koszul sign  $(-1)^{kl}$  to the braiding. We can restrict to even N to ensure  $\Lambda^N \mathbb{C}^N$  is still a trivial representation.
- The factor  $\mathfrak{q}^{-\frac{kl}{N}}$  will not affect the commutation rules of B and rung generators in the planar level. It could also be eliminated by promoting the  $\mathrm{SL}(N)$  gauge group to  $\mathrm{GL}(N)$ .
- The two above statements could be combined by taking the gauge group to be a Spin version of  $\mathrm{GL}(N)$ .

<span id="page-70-1"></span> $<sup>^{20}</sup>$ The simplification is motivated as follows:

Commuting B<sup>i</sup> across rungs, we find relations

$$K_{i}B_{i} = B_{i}K_{i+1}$$

$$K_{i+1}B_{i} = B_{i}K_{i}$$

$$K_{i}E_{i}B_{i} = B_{i}F_{i}K_{i}$$

$$K_{i+1}F_{i}B_{i} = B_{i}E_{i}K_{i+1}$$

$$(E_{i}E_{i+1} - \mathfrak{q}E_{i+1}E_{i})B_{i} = B_{i}E_{i+1}$$

$$(E_{i-1}E_{i} - \mathfrak{q}^{-1}E_{i}E_{i-1})B_{i} = B_{i}E_{i-1}$$

$$(F_{i+1}F_{i} - \mathfrak{q}^{-1}F_{i}F_{i+1})B_{i} = B_{i}F_{i+1}$$

$$(F_{i}F_{i-1} - \mathfrak{q}F_{i-1}F_{i})B_{i} = B_{i}F_{i-1}$$

$$E_{i+1}B_{i} = B_{i}(E_{i}E_{i+1} - \mathfrak{q}^{-1}E_{i+1}E_{i})$$

$$E_{i-1}B_{i} = B_{i}(E_{i-1}E_{i} - \mathfrak{q}E_{i}E_{i-1})$$

$$F_{i+1}B_{i} = B_{i}(F_{i+1}F_{i} - \mathfrak{q}F_{i}F_{i+1})$$

$$F_{i-1}B_{i} = B_{i}(F_{i}F_{i-1} - \mathfrak{q}^{-1}F_{i-1}F_{i}).$$
(C.9)

## <span id="page-71-0"></span>C.3 Long rungs and a PBW basis

Inspired by these formulae and with the help of B specialized to k = 1 or l = 1, we recognize as

$$E_{-;i+2,i} \equiv E_i E_{i+1} - \mathfrak{q} E_{i+1} E_i \tag{C.10}$$

a left-pointing rung extending from the (i+2)-th strand to the 1-th strand while passing behind the (i + 1)-th strand,

$$E_{+;i+2,i} \equiv E_i E_{i+1} - \mathfrak{q}^{-1} E_{i+1} E_i \tag{C.11}$$

a similar rung passing in front and

$$F_{-;i,i+2} \equiv F_{i+1}F_i - \mathfrak{q}^{-1}F_iF_{i+1}$$

$$F_{+;i,i+2} \equiv F_{i+1}F_i - \mathfrak{q}F_iF_{i+1}$$
(C.12)

right-pointing rungs from the i-th strand to the (i + 2)-th strand passing behind and in front of the (i + 1)-th strand.

More generally, we define recursively rung operators between any pairs of strands:

$$E_{\pm;i+1,i} = E_{i}$$

$$E_{-;i+2,i} = E_{i}E_{i+1} - \mathfrak{q}E_{i+1}E_{i}$$

$$E_{+;i+2,i} = E_{i}E_{i+1} - \mathfrak{q}^{-1}E_{i+1}E_{i}$$

$$E_{-;j,i} = E_{i}E_{-;j,i+1} - \mathfrak{q}E_{-;j,i+1}E_{i} \qquad j > i+1$$

$$E_{+;j,i} = E_{i}E_{+;j,i+1} - \mathfrak{q}^{-1}E_{+;j,i+1}E_{i} \qquad j > i+1$$

$$F_{\pm;i,i+1} = F_{i}$$

$$F_{-;i,i+2} = F_{i+1}F_{i} - \mathfrak{q}^{-1}F_{i}F_{i+1}$$

$$F_{+;i,i+2} = F_{i+1}F_{i} - \mathfrak{q}F_{i}F_{i+1}$$

$$F_{-;i,j} = F_{-;i+1,j}F_{i} - \mathfrak{q}^{-1}F_{i}F_{-;i+1,j} \qquad j > i+1$$

$$F_{+;i,j} = F_{+;i+1,j}F_{i} - \mathfrak{q}F_{i}F_{+;i+1,j} \qquad j > i+1, \qquad (C.13)$$

passing behind or in front of intermediate strands.

The B<sup>i</sup> permutations act in the obvious way on the endpoints of these rung operators, except for the extra factors when acting on E<sup>i</sup> or F<sup>i</sup> , i.e. when the direction a rung points to is flipped. This defines an action of the braid group of m strands onto Uq(glm) as algebra automorphisms. It can be thought of as a q-deformed version of the Weyl group action on U(glm).

Lexicographically ordered monomials of K<sup>±</sup> i , E<sup>−</sup>;i,j and F<sup>−</sup>;i,j generators form a linear (PBW) basis for Uq(glm). Defining

$$e_{\pm;i,j} = (\mathfrak{q} - \mathfrak{q}^{-1})E_{\pm;i,j}$$
  
 $f_{\pm;i,j} = (\mathfrak{q} - \mathfrak{q}^{-1})f_{\pm;i,j}$ , (C.14)

etcetera, a crucial observation is that the rescaled operators will all have a good planar limit. This is expected from the large N combinatorics of the planar limit, but can also be verified by computing commutators. E.g.

$$[e_{i}, e_{-;i+2,i}] = (\mathfrak{q}^{-1} - 1)e_{-;i+2,i}e_{i}$$

$$[e_{-;i+2,i}, e_{i+1}] = (\mathfrak{q}^{-1} - 1)e_{i+1}e_{-;i+2,i}$$

$$[e_{-;i+2,i}, f_{i}] = -(\mathfrak{q} - \mathfrak{q}^{-1})K_{i}e_{i+1}K_{i+1}^{-1}$$

$$[e_{-;i+2,i}, f_{i+1}] = -(\mathfrak{q} - \mathfrak{q}^{-1})K_{i}e_{i}K_{i+1}^{-1}.$$
(C.15)

Accordingly, monomials of K<sup>±</sup> i , e<sup>−</sup>;i,j and f<sup>−</sup>;i,j generators form a linear basis for the planar limit of Uq(glm). They can be understood as holomorphic functions (polynomials) on an auxiliary Poisson complex manifold Pm. The manifold itself is a product of C and C ∗ factors, but the Poisson bracket is complicated.

The  $SU(N)_{\kappa}$  CS theory is unitary. The adjoint of a Wilson line is a Wilson line for the conjugate representation. We expect Hermiticity conditions  $\mathfrak{q}^{\dagger} = \mathfrak{q}^{-1}$ ,  $K_i^{\dagger} = K_i^{-1}$ , and  $E_{-;i,j}^{\dagger} = F_{-;j,i}$ . In the planar limit,  $e_{-;i,j}^{\dagger} = f_{-;j,i}$ . These reality conditions define a real submanifold  $\mathcal{P}_m^{\mathbb{R}}$  of  $\mathcal{P}_m$ .

The braid operations  $B_i$  have an obvious planar limit. They act as Poisson automorphisms of  $\mathcal{P}_m$ . The Hermiticity conditions are compatible with  $B_i^{\dagger} = B_i^{-1}$ .

### <span id="page-73-0"></span>C.4 Cups and caps

In the current setup, a "cup" or a "cap" joins smoothly consecutive strands of labels k and N-k with the help of a "tag". We will use conventions where cups have a down-pointing tag and caps an up-pointing tag. These conventions, together with the signs we included in the definition of  $B_i$ , ensure that a knot or link defined by a collection of cups, caps and braids has a vev which equals the standard  $SU(N)_{\kappa}$  Chern-Simons answer times a factor of  $(-1)^k$  for each closed loop of label k, at least for even N.

A cup  $\cup_i$  between the *i*-th and (i+1)-th strands constrains

$$K_{i+1}K_{i}\cup_{i} = g\cup_{i}$$

$$E_{i}\cup_{i} = -\frac{K_{i} - K_{i}^{-1}}{\mathfrak{q} - \mathfrak{q}^{-1}}\cup_{i}$$

$$F_{i}\cup_{i} = -\frac{gK_{i}^{-1} - g^{-1}K_{i}}{\mathfrak{q} - \mathfrak{q}^{-1}}\cup_{i}.$$
(C.16)

We also have

$$E_{-;j,i} \cup_{i} = K_{i} E_{-;j,i+1} \cup_{i}$$

$$E_{+;j,i} \cup_{i} = K_{i}^{-1} E_{+;j,i+1} \cup_{i}$$

$$F_{-;j,i+1} \cup_{i} = K_{i+1}^{-1} F_{-;j,i} \cup_{i}$$

$$F_{+;j,i+1} \cup_{i} = K_{i+1} F_{+;j,i} \cup_{i}$$

$$E_{-;i+1,j} \cup_{i} = -K_{i}^{-1} E_{-;i,j} \cup_{i}$$

$$E_{+;i+1,j} \cup_{i} = -K_{i} E_{+;i,j} \cup_{i}$$

$$F_{-;i,j} \cup_{i} = -K_{i+1} F_{-;i+1,j} \cup_{i}$$

$$F_{+;i,j} \cup_{i} = -K_{i+1}^{-1} F_{-;i+1,j} \cup_{i} . \qquad (C.17)$$

Analogously, a cap between the i-th and (i + 1)-th strands constrains

$$\bigcap_{i} K_{i+1} K_{i} = \bigcap_{i} g$$

$$\bigcap_{i} E_{i} = \bigcap_{i} \frac{g K_{i}^{-1} - g^{-1} K_{i}}{\mathfrak{q} - \mathfrak{q}^{-1}}$$

$$\bigcap_{i} F_{i} = \bigcap_{i} \frac{K_{i} - K_{i}^{-1}}{\mathfrak{q} - \mathfrak{q}^{-1}}.$$
(C.18)

We also have

$$\bigcap_{i} E_{-;j,i} = \bigcap_{i} E_{-;j,i+1} K_{i+1}^{-1} 
\bigcap_{i} E_{+;j,i} = \bigcap_{i} E_{+;j,i+1} K_{i+1} 
\bigcap_{i} F_{-;j,i+1} = \bigcap_{i} F_{-;j,i} K_{i} 
\bigcap_{i} F_{+;j,i+1} = \bigcap_{i} F_{-;j,i} K_{i}^{-1} \cup_{i} 
\bigcap_{i} E_{-;i+1,j} = -\bigcap_{i} E_{-;i,j} K_{i+1} 
\bigcap_{i} E_{+;i+1,j} = -\bigcap_{i} E_{+;i,j} K_{i+1}^{1} 
\bigcap_{i} F_{-;i,j} = -\bigcap_{i} F_{-;i+1,j} K_{i}^{-1} 
\bigcap_{i} F_{+;i,j} = -\bigcap_{i} F_{-;i+1,j} K_{i}.$$
(C.19)

The relations found above for cups and caps have a natural planar limit. They define Poisson correspondences L<sup>∪</sup><sup>i</sup> and L<sup>∩</sup><sup>i</sup> between P<sup>m</sup> and Pm−2, i.e. the difference of Poisson brackets acts on functions on P<sup>m</sup> ×Pm−<sup>2</sup> which vanish on the correspondences.

We will typically use one of the cups as the place where we keep track of the label k of a loop in the knot/link. This adds the extra constraint K<sup>i</sup> = µ and inserts factors of λ <sup>±</sup> in the remaining relations: operators which raise the k label by one must be multiplied by λ and operators which lower it by 1 must be multiplied by λ −1 . This promotes L<sup>∩</sup><sup>i</sup> to a correspondence between P<sup>m</sup> and Pm−<sup>2</sup> × (C ∗ ) 2 .

## <span id="page-74-0"></span>C.5 Junctions

We now have enough information for the analysis of knot and link invariants. For completeness, we will also discuss the effect of junctions, which can be employed to study the augmentation varieties of Wilson line networks.

We can list some natural relations, denoting as Y<sup>i</sup> a junction splitting the i-th

strand:

$$Y_{i}K_{i} = K_{i}K_{i+1}Y_{i}$$

$$Y_{i}K_{j} = K_{j}Y_{i} j < i$$

$$Y_{i}K_{j} = K_{j+1}Y_{i} j > i$$

$$Y_{i}E_{j} = E_{j}Y_{i} j < i$$

$$Y_{i}E_{j} = E_{j+1}Y_{i} j > i$$

$$Y_{i}F_{j} = F_{j}Y_{i} j < i - 1$$

$$Y_{i}F_{j} = F_{j+1}Y_{i} j > i - 1$$

$$E_{i}Y_{i} = \frac{K_{i} - K_{i}^{-1}}{\mathfrak{q} - \mathfrak{q}^{-1}}Y_{i}$$

$$F_{i}Y_{i} = \frac{K_{i+1} - K_{i+1}^{-1}}{\mathfrak{q} - \mathfrak{q}^{-1}}Y_{i}.$$
(C.20)

There are other Serre-like relations. It should be possible to express them in terms of longer rungs. E.g. we expect longer rungs which do not end on the legs of the junction to go through the junction in the obvious way. Some other relations:

$$(E_{-;i+1,j} - K_i^{-1}E_{-;i,j})Y_i = 0 j < i$$

$$(E_{+;i+1,j} - K_iE_{+;i,j})Y_i = 0 j < i$$

$$(F_{-;i,j} - K_{i+1}F_{-;i+1,j})Y_i = 0 j > i+1$$

$$(F_{+;i,j} - K_{i+1}^{-1}F_{+;i+1,j})Y_i = 0 j > i+1$$

$$(E_{-;j;i} + \mathfrak{q}K_iE_{-;j,i+1})Y_i = Y_iE_{-;j,i} j > i+1$$

$$(E_{+;j;i} + \mathfrak{q}^{-1}K_i^{-1}E_{+;j,i+1})Y_i = Y_iE_{+;j,i} j > i+1$$

$$(F_{-;j;i+1} + \mathfrak{q}^{-1}K_{i+1}^{-1}F_{-;j,i})Y_i = Y_iF_{-;j,i} j < i$$

$$(F_{+;j;i+1} + \mathfrak{q}K_{i+1}F_{+;j,i})Y_i = Y_iF_{+;j,i} j < i. (C.21)$$

In particular, we have enough relations to bring every element of Uq(glm−1) acting below the junction to some element of Uq(glm) above the junction.

We can denote the opposite junction merging consecutive strands as Λ<sup>i</sup> . We can derive very similar relations:

$$K_{i}\Lambda_{i} = \Lambda_{i}K_{i}K_{i+1}$$

$$K_{j}\Lambda_{i} = \Lambda_{i}K_{j}$$

All of these relations have an immediate planar limit. They define Poisson correspondences L<sup>Y</sup><sup>i</sup> and L<sup>Λ</sup><sup>i</sup> between P<sup>m</sup> and Pm−1.

## <span id="page-76-0"></span>C.6 Endpoints

Another simple way to reduce the number of strands is simply to set k<sup>i</sup> = 0 for a strand and forget it. We denote this operation as Π0;<sup>i</sup> or I0;<sup>i</sup> depending on the orientation. It sets K<sup>i</sup> = 1 and sets to 0 any rung starting at the i-th position. Rungs which do not end on i simply go through.

We can also set strand labels to N. We denote this operation as ΠN;<sup>i</sup> or IN;<sup>i</sup> depending on the orientation. Because of the overall factor we removed from the braiding, a strand with label N is not completely transparent. Instead, a rung which does not end on i will have to be multiplied by q <sup>±</sup><sup>1</sup> when brought across such an endpoint. Rungs ending at that position will be set to 0, and K<sup>i</sup> to q N .

Cups and caps are combinations of junctions and endpoints.

## <span id="page-77-0"></span>D The planar quantum group as a character variety

In this Appendix, we continue the planar analysis from the previous Appendix [C.](#page-69-0) We refer to it for notations. Recall that we expect K<sup>i</sup> to have a well-defined classical limit, as well as e<sup>−</sup>;i,j ≡ (q − q −1 )E<sup>−</sup>;i,j and f<sup>−</sup>;i,j ≡ (q − q −1 )F<sup>−</sup>;i,j . We define e<sup>i</sup> = e<sup>−</sup>;i+1,i = e+;i+1,i and f<sup>i</sup> = f<sup>−</sup>;i,i+1 = f+;i,i+1 as special cases.

The analogous e+;i,j ≡ (q − q −1 )E+;i,j and f+;i,j ≡ (q − q −1 )F+;i,j limits are not independent. For example, we compute

$$\begin{aligned} e_{+;i+2,i} - e_{-;i+2,i} &= e_i e_{i+1} \\ e_{+;i+3,i} - e_{-;i+3,i} &= e_{i+2} e_{-;i+2,i} + e_{+;i+3,i+1} e_i \\ e_{+;i+4,i} - e_{-;i+4,i} &= e_{+;i+4,i+1} e_i + e_{+;i+4,i+2} e_{-;i+2,i} + e_{i+3} e_{-;i+3,i} \,, \end{aligned} \tag{D.1}$$

which have a nice planar limit. More generally, we have

$$e_{+;j,i} - e_{-;j,i} = \sum_{k=i+1}^{j-1} e_{+;j,k} e_{-;k,i},$$
 (D.2)

which can be proven by bringing the rung across intermediate strands one at a time. Similarly,

$$f_{+;i,i+2} - f_{-;i,i+2} = -f_i f_{i+1}$$
  

$$f_{+;i,i+3} - f_{-;i,i+3} = -f_i f_{+;i+1,i+3} - f_{-;i,i+2} f_{i+2}.$$
 (D.3)

More generally,

$$f_{+;j,i} - f_{-;j,i} = -\sum_{k=i+1}^{j-1} f_{-;i,k} f_{+;k,j}$$
 (D.4)

If we define triangular matrices ˆe<sup>±</sup> with unit diagonal and ±e<sup>±</sup>;i,j off-diagonal elements, the equations take the form

$$\hat{e}_{+}\hat{e}_{-} = \hat{e}_{-}\hat{e}_{+} = 1. \tag{D.5}$$

Similarly, if we define ˆf<sup>±</sup> with unit diagonal and ∓f<sup>±</sup>;i,j off-diagonal elements,

$$\hat{f}_{+}\hat{f}_{-} = \hat{f}_{-}\hat{f}_{+} = 1. \tag{D.6}$$

## <span id="page-77-1"></span>D.1 Framing strands

We can improve our geometric understanding by adding two "spectator" strands at positions 0 and m + 1. This gives useful collections of auxiliary quantities: e<sup>±</sup>;i,0, e<sup>±</sup>;m+1,i, f<sup>±</sup>;0,i, f<sup>±</sup>;i,m+1.

Manipulations of the original set of strands will give us linear operations on these 8 collections of m quantities, which in turn will imply specific transformations of the  $\hat{e}_{\pm}$  and  $\hat{f}_{\pm}$  matrices.

As

$$e_{+;m+1,0} - e_{-;m+1,0} = \sum_{k=1}^{m} e_{+;m+1,k} e_{-;k,0} = \sum_{k=1}^{m} e_{-;m+1,k} e_{+;k,0},$$
 (D.7)

and this quantity is unaffected by various manipulations of the intermediate strands (see Figure 18), we can think about  $e_{-;i,0}$  and  $e_{+;m+1,i}$  as having a natural pairing, and  $e_{+;i,0}$  and  $e_{-;m+1,i}$  as well. Similarly for  $f_{-;0,m+1} - f_{+;0,m+1}$  giving a natural pairing on the f's.

<span id="page-78-0"></span>![](_page_78_Picture_4.jpeg)

**Figure 18**: Auxiliary strands 0 and m+1 with a  $f_{+;0,m+1}$  rung connecting them. We see that any braiding of the intermediate rungs does not affect this rung.

We will now define a monodromy matrix which encodes the transformation of, say,  $e_{-;i,0}$  as the two spectator strands are braided simultaneously around the original strands.

- The first step is to map them to a basis of  $e_{+;i,0}$  elements. This is implemented by the  $\hat{e}_+$  matrix.
- Next, we braid the extra strands from position 0 to position m+1 and vice versa, by applying the sequence  $B_0 \cdots B_{m-1} B_m B_{m-1} \cdots B_0$ . See Figure 19. This converts

$$e_{+;1,0} \to K_1 f_{+;0,1} K_0^{-1} \to K_{m+1} K_1^{-1} f_{+;1,m+1}$$

$$e_{+;2,0} \to e_{+;2,1} \to K_2 f_{+;1,2} K_1^{-1} \to K_{m+1} K_2^{-1} f_{+;2,m+1}$$

$$e_{+;i,0} \to K_{m+1} K_i^{-1} f_{+;i,m+1}. \tag{D.8}$$

So if we use a new basis  $K_{m+1}f_{+;i,m+1}$ , it is expressed in terms of the old one by multiplication by a diagonal matrix with entries  $K_i$ .

• Now we map this to a basis  $K_{m+1}f_{-i,m+1}$ . The change of basis is  $\hat{f}_{-i,m+1}$ .

• We finally braid again the extra strands by  $B_0 \cdots B_{m-1} B_m B_{m-1} \cdots B_0$ . E.g.  $f_{-;m,m+1} \to K_0 e_{-;m,0} K_m^{-1}$ . If we use a new basis  $K_0^2 e_{-;i,0}$ , this is implemented by a diagonal matrix with entries  $K_i$  again.

Overall, we build a monodromy matrix

$$M = \hat{K}\hat{f}_{-}\hat{K}\hat{e}_{+}, \tag{D.9}$$

decomposed into two half-monodromies  $\hat{K}\hat{e}_+$  and  $\hat{K}\hat{f}_-.$ 

This sheds some light on the geometric meaning of individual  $B_i$  transformations. They act in a very specific manner on the  $e_{-;j,0}$  elements:

$$e_{-;i+1,0} \to e_{-;i,0}$$
  
 $e_{-;i,0} \to e_{-;i+1,0} + e_i e_{-;i,0}$ , (D.10)

and all other unchanged. The entries of M must change by conjugation with this simple linear transformation. In the main text, we give a Stokes data interpretation of this transformation.

<span id="page-79-0"></span>![](_page_79_Picture_7.jpeg)

**Figure 19**: The half braid of strands at position 0 and m+1 illustrated for m=2.

## <span id="page-80-0"></span>D.2 The bilinear parameterization

We now introduce a redundant parameterization of  $\mathcal{P}_m$  which will be helpful in describing cups, caps, junctions and endpoints. The parameterization:

$$v_{i}^{R} \cdot v_{i}^{L} = K_{i}^{2} - 1$$

$$v_{i}^{R} \cdot v_{j}^{L} = e_{-;i,j} \qquad i > j$$

$$v_{i}^{R} \cdot v_{j}^{L} = K_{i}K_{j}f_{-;i,j} \qquad i < j \qquad (D.11)$$

involves m vectors  $v_i^L$  in some  $\mathbb{C}^r$  and m dual vectors  $v_i^R$ . It is invariant under the  $\mathrm{GL}(r)$  action on  $\mathbb{C}^r$ . Without loss of generality we can take r=m, though we will see that cups, junctions, etc. impose constraints which allow for smaller values of r to be employed.

We also define matrices

$$M_{i} = 1 + v_{i}^{L} v_{i}^{R}$$

$$M_{i}^{-1} = 1 - K_{i}^{-2} v_{i}^{L} v_{i}^{R}.$$
(D.12)

They appear in a natural lift of the action of  $B_i$ :

$$B_{i}v_{i}^{L} = M_{i}^{-1}v_{i+1}^{L}B_{i}$$

$$B_{i}v_{i+1}^{L} = v_{i}^{L}B_{i}$$

$$B_{i}v_{i}^{R} = v_{i+1}^{R}M_{i}B_{i}$$

$$B_{i}v_{i+1}^{R} = v_{i}^{R}B_{i}.$$
(D.13)

We can now look at the cap constraints in this language. We find in particular that

$$\cap_{i} v_{j}^{R} \cdot v_{i}^{L} = \cap_{i} K_{i+1}^{-1} v_{j}^{R} \cdot v_{i+1}^{L}, \qquad (D.14)$$

for all j, which we can solve without loss of generality by

$$\cap_i v_i^L = \cap_i K_{i+1}^{-1} v_{i+1}^L \,. \tag{D.15}$$

Most of the remaining relations assert

$$\bigcap_{i} v_{i}^{R} \cdot v_{j}^{L} = -\bigcap_{i} v_{i+1}^{R} \cdot v_{j}^{L} K_{i+1}^{-1} \qquad j \neq i, i+1,$$
 (D.16)

i.e. the cap forces  $v_i^R + K_{i+1}^{-1}v_{i+1}^R$  to be orthogonal to all  $v_j^L$  except for  $v_i^L$  and  $v_{i+1}^L$ , which we have just taken to be proportional to each other. We also have the usual  $\bigcap_i K_{i+1} K_i = \bigcap_i g$ .

Note that

$$\bigcap_{i} (v_i^R + K_{i+1}^{-1} v_{i+1}^R) \cdot v_i^L = \bigcap_{i} K_i^2 (1 - g^{-2}),$$
 (D.17)

so as long as  $g^2 \neq 1$ , neither  $v_i^L$  nor  $v_i^R + K_{i+1}^{-1} v_{i+1}^R$  can be non-zero. Without loss of generality, we could set them to be proportional to something like  $(0, \dots, 0, 1)$  and set to 0 the last components of all  $v_i^L$  except for  $v_i^L$  and  $v_{i+1}^L$ .

Accordingly, the cap constrains the matrix of  $v_i^L$ 's to have a block-diagonal form, with  $2 \times 1$  and  $(m-2) \times (r-1)$ -dimensional blocks. In order for remaining generators to pass through the cap, we simply need to identify the remaining m-2 vectors above the cap with the (r-1)-dimensional blocks in the  $v_i^L$  and  $v_i^R$  below the cap.

We can also compute

$$\bigcap_{i} M_{i+1} M_{i} = \bigcap_{i} (1 + K_{i+1}^{2} v_{i}^{L} (v_{i}^{R} + K_{i+1}^{-1} v_{i+1}^{R})), \qquad (D.18)$$

and thus

$$\bigcap_{i} M_{i+1} M_{i} (M_{i-1} \cdots M_{1}) (M_{m}^{-1} \cdots M_{i+2}) = \bigcap_{i} ((M_{i-1} \cdots M_{1}) (M_{m}^{-1} \cdots M_{i+2}) 
+ K_{i+1}^{2} v_{i}^{L} (v_{i}^{R} + K_{i+1}^{-1} v_{i+1}^{R})).$$
(D.19)

In particular,  $(v_i^R + K_{i+1}^{-1}v_{i+1}^R)$  is a right eigenvector with eigenvalue  $g^2$ .

This matrix also acts as  $(M_{i-1} \cdots M_1)(M_m^{-1} \cdots M_{i+2})$  on the  $v_j^L$  with j different from i and i+1. The matrix  $(M_{i-1} \cdots M_1)(M_m^{-1} \cdots M_{i+2})$  has a block-triangular form, with a block identified with the analogous matrix above the cap.

The cup analysis is analogous, with the roles of left- and right-eigenvectors permuted.

If we take m=2n and consider a full collection of caps joining consecutive pairs of strands, the above analysis can be done simultaneously for all. The  $v_{2i}^L$  and  $v_{2i-1}^L$  will be pairwise parallel and the  $v^L$  matrix will consist of a collection of  $2 \times 1$  blocks.

The "monodromy at infinity" matrix  $M_{2n} \cdots M_1$  takes the form

$$(1 + K_{2n}^2 v_{2n-1}^L (v_{2n-1}^R + K_{2n}^{-1} v_{2n}^R)) \cdots (1 + K_2^2 v_1^L (v_1^R + K_2^{-1} v_2^R),$$
 (D.20)

and the various factors act independently. It thus restricts to  $g^2$  times the identity matrix acting on the span of the  $v_{2i-1}^L$  and, dually, on the span of the  $v_{2i-1}^R + K_{2i}^{-1}v_{2i}^R$ .

Without loss of generality, we can set r = n and use the  $v_i^R$  to encode generic rung vevs compatible with the full cap state. The same is true for the full cup state. This makes contact with the discussion in Appendices A and B.

#### <span id="page-82-0"></span>D.3 Planar junctions and ends

Besides  $Y_iK_i = K_iK_{i+1}Y_i$ , etc., part of the relations can be satisfied by imposing

$$v_{i+1}^R Y_i = K_i^{-1} v_i^R Y_i \,, \tag{D.21}$$

as for the case of cups. The combination  $v_i^L + K_i v_{i+1}^L$  also plays an important role. Observe

$$v_i^R \cdot (v_i^L + K_i v_{i+1}^L) Y_i = (K_i^2 K_{i+1}^2 - 1) Y_i.$$
 (D.22)

The remaining relations are consistent with

$$\begin{aligned} v_{j}^{L,R}Y_{i} &= Y_{i}v_{j}^{L,R} & j < i \\ v_{j}^{L,R}Y_{i} &= Y_{i}v_{j-1}^{L,R} & j > i+1 \\ v_{i}^{R}Y_{i} &= Y_{i}v_{i}^{R} \\ (v_{i}^{L} + K_{i}v_{i+1}^{L})Y_{i} &= Y_{i}v_{i}^{L} \,. \end{aligned} \tag{D.23}$$

In other words, we align  $v_i^R$  and  $v_{i+1}^R$  above the  $Y_i$  junction with a specific ratio  $K_i$ , so that the combination

$$M_{i+1}M_i = 1 + (v_i^L + K_i v_{i+1}^L)v_i^R$$
(D.24)

is identified with the new  $M_i$ , while the rest of the data goes through unchanged.

The  $\Lambda_i$  junction has analogous effects, setting  $v_i^L = K_{i+1}^{-1} v_{i+1}^L$  and identifying  $v_{i+1}^R + K_{i+1} v_i^R$  as the new  $v_i^R$ ,  $v_{i+1}^L$  as the new  $v_i^L$ .

Endpoints are also easily reproduced. The  $I_{0;i}$  endpoint, for example, is annihilated by all rungs which emanate from the *i*-th strand. It can be reproduced by setting  $v_i^R = 0$  and leaving all other data unaffected. This is one way to make  $M_i = 0$ . The opposite endpoint  $\Pi_{0:i}$  instead sets  $v_i^L = 0$ .

The endpoint  $I_{N;i}$ , instead, sets to zero all rungs which end on the *i*-th strand, but requires  $v_i^R \cdot v_i^L = g^2 - 1 \neq 0$ . Accordingly, it can be implemented by making all  $v_j^R$  for  $j \neq i$  be orthogonal to  $v_i^L$ . Without loss of generality we can take  $v_i^{L,R}$  to be proportional to  $(0, \dots, 0, 1)$  and set to zero the last component of all  $v_j^R$  for  $j \neq i$ . Across the endpoint, we take the  $(r-1) \times (m-1)$  parts of the data as the new  $v^{L,R}$ 's.

The opposite happens for the  $\Pi_{N,i}$  endpoint.

## <span id="page-82-1"></span>E Diagrammatic rules

The diagrammatic rules for the fusing of antisymmetric powers of the fundamental representation of SU(N) are extracted from [32]. Below is a list of the rules relevant to our purposes.

<span id="page-83-2"></span>k = n k q (E.1)

$$\begin{array}{cccccccccccccccccccccccccccccccccccc$$

$$k + l + m$$

$$k + l$$

$$k + l$$

$$k + l$$

$$k + l$$

$$k + l$$

$$k + l$$

$$k + l$$

$$k + l$$

$$k + l$$

$$k + l$$

$$k + m$$

$$k + l$$

$$k + m$$

$$k + l$$

$$k + m$$

$$k + l$$

$$k + m$$

$$k + l$$

$$k + m$$

$$k + l$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k + m$$

$$k-s-r$$

$$k-s$$

$$l+s+r$$

$$l+s$$

$$l$$

$$l$$

$$k$$

$$l$$

$$l$$

$$l$$

$$l$$

$$l$$

$$l$$

$$l$$

$$l$$

$$l$$

$$l$$

$$k-s+r$$

$$k-s$$

$$l+s$$

$$l+s$$

$$l$$

$$l$$

$$k$$

$$l$$

$$l$$

$$k$$

$$l$$

$$l$$

$$l$$

$$l$$

$$l$$

$$l$$

$$l$$

$$l$$

$$l$$

$$l$$

<span id="page-83-1"></span><span id="page-83-0"></span>
$$k = (-1)^{k+kl} q^{k-\frac{kl}{n}} \sum_{\substack{a,b \ge 0 \\ b-a=k-l}} (-q)^{-b} k - b$$

$$k \qquad l \qquad (E.6)$$

In particular, [\(E.5\)](#page-83-0) has an important special case: if k − s + r = l and thus l + s − r = k, as on the right-hand side of [\(E.6\)](#page-83-1), the sum on the right-hand side has a single term t = 0. In particular, in [\(E.6\)](#page-83-1) we can permute the horizontal rungs.

![](_page_84_Picture_0.jpeg)

Figure 20: A special case of the square-switch rule.

Tags are introduced as convenient notation to represent the following vertices:

$$\begin{array}{cccc}
n \\
\downarrow \\
k & n-k \end{array} = \begin{array}{cccc}
\downarrow \\
k & n-k \end{array}$$
(E.7)

$$\begin{array}{cccc}
k & n-k & k & n-k \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & \\
 & & & &$$

They satisfy the following relations:

$$\sqrt{n-k} \qquad \sqrt{n-k}$$

$$= (-1)^{k(n-k)} \sqrt{k} \qquad (E.9)$$

$$n-k-l \qquad n-k-l$$

$$k+l =$$

$$\begin{array}{cccc}
n-l & n-l \\
\downarrow l & = n-k-l \\
k+l & k & k+l & k
\end{array}$$
(E.11)

$$\sqrt{n-k} = \sqrt{k}$$
(E.12)

Figures [21](#page-85-0) to [25](#page-88-0) include some important diagrammatic calculations.

<span id="page-85-0"></span>![](_page_85_Figure_1.jpeg)

Figure 21: Another special case of square-switch.

![](_page_85_Figure_3.jpeg)

Figure 22: A useful relation.

$$\sum_{b} (-\mathfrak{q})^{k-b-1} \times$$

Figure 23: Acting with E at the bottom of the braid.

$$\sum_{b} (-\mathfrak{q})^{k-b} \times \left( \begin{array}{c} a \\ b \\ l \end{array} \right) = \sum_{b} (-\mathfrak{q})^{k-b} [a+1]_{\mathfrak{q}} \times \left( \begin{array}{c} l+1 \\ b \\ l \end{array} \right) = \sum_{b} (-\mathfrak{q})^{k-b} [a+1]_{\mathfrak{q}} \times \left( \begin{array}{c} l+1 \\ k-1 \\ l \end{array} \right) = \sum_{b} (-\mathfrak{q})^{k-b} \left( [a+1]_{\mathfrak{q}} - \mathfrak{q}^{-1} [a+2]_{\mathfrak{q}} \right) \times \left( \begin{array}{c} l+1 \\ k-1 \\ l \end{array} \right) = \sum_{b} (-\mathfrak{q})^{k-b} \left( [a+1]_{\mathfrak{q}} - \mathfrak{q}^{-1} [a+2]_{\mathfrak{q}} \right) \times \left( \begin{array}{c} l+1 \\ a+1 \\ l \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ k-1 \\ l \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ k-1 \\ l \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ k-1 \\ l \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ k-1 \\ l \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ k-1 \\ l \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ k-1 \\ l \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1 \\ l+1 \end{array} \right) = \sum_{b} (-1)^{k+b+1} \mathfrak{q}^{2k-l-2b-2} \left( \begin{array}{c} l+1$$

Figure 24: Acting with F at the bottom of the braid.

<span id="page-88-0"></span>![](_page_88_Figure_0.jpeg)

Figure 25: The computation of the relation between braiding B<sup>2</sup> and F23. The last term vanishes after application of the square-switch.

## <span id="page-89-0"></span>E.1 Planar limit of rungs, braids, caps, and cups

In the planar limit, the fundamental rungs attached to heavy strands obey a specific set of relations. Here we give a three-dimensional "geometric" picture of those relations, which we use to manipulate the rungs and compute the augmentation variety. It is understood that the µ<sup>i</sup> and λ<sup>i</sup> in the formulae correspond to components of heavy strands in a knot/link.

To avoid labeling every heavy strand with its representation, we can consider knots with a basepoint. Keeping track of the labeling is equivalent to the following relations involving the basepoint:

$$\longrightarrow$$

$$= \lambda^{-1}$$
(E.14)

The relation converting over and under crossings into ladders simplifies into a skein relation. Similar to the previous section, we rescale the rungs by a factor of q − q −1 and define the rescaled rung operators, which have a good planar limit. Therefore, we perform the substitution,

$$F_{i,j} = \longrightarrow \frac{1}{\mathfrak{q} - \mathfrak{q}^{-1}} \longrightarrow \frac{f_{i,j}}{\mathfrak{q} - \mathfrak{q}^{-1}}$$
 (E.15)

This way, the skein relations of [E.6](#page-83-1) becomes,

<span id="page-89-1"></span>
$$-$$

The factor of ϵ changes depending on the direction of the rungs involved. We choose the convention for the heavy strand going up and the fundamental rung going to the right to have ϵ = 1, and the heavy strand going up and the fundamental rung going left to have ϵ = −1. If the heavy strand is going down, the signs accordingly flip. This corresponds to the algebraic skein relation satisfied by the fundamental rung in the planar limit given in Appendix [D.](#page-77-0)

$$e_{-;i+2,i} - e_{+;i+2,i} = -e_i e_{i+1}$$
 (E.17)

$$f_{-;i,i+2} - f_{+;i,i+2} = f_i f_{i+1}$$
. (E.18)

The bubble removal relations of Eqn. [E.1](#page-83-2) is also written in terms of the planar variables,

$$= \mu - \mu^{-1} \tag{E.19}$$

$$= g\mu^{-1} - g^{-1}\mu \tag{E.20}$$

When twisting fundamental rungs around heavy strands, we obtain factors due to the change in the framing of the involved lines. The relevant formulae are,

$$= -g \qquad (E.21)$$

$$\begin{array}{cccccccccccccccccccccccccccccccccccc$$

$$= -g^{-1}\mu \qquad = -g\mu^{-1} \qquad (E.23)$$

$$\begin{array}{cccccccccccccccccccccccccccccccccccc$$

$$= \mu^{-1} \qquad = \mu \qquad (E.25)$$

These relations allow us to determine how braids, cups, and caps act on the fundamental rungs. Consider the setup, a collection of heavy strands, labeled from 1 to m, parallel to each other and all pointing upwards. Consider the collection of fundamental rungs e<sup>−</sup>;ij and f<sup>−</sup>;ij , with 1 ≤ i ̸= j ≤ m between 1 and m. e<sup>−</sup>;ij and f<sup>−</sup>;ij represent left and right pointing rungs starting at the strand i and ending at the strand j respectively, and going below all intermediate heavy strands. This is analogous to the "PBW" basis of Uqglm, which we take as a basis to do our computation. We denote by B<sup>k</sup> the element of the braid group that braids the heavy strand k on top of k+1. The geometric process of sliding a fundamental rung across the braid from bottom to top can be expressed algebraically as an action of a braid-group element on the rung variables, expressing them as linear combinations and products of other fundamental rungs, with the help of the skein relation [E.16](#page-89-1) (see Figure [27\)](#page-93-0). This action of B<sup>k</sup> on the heavy strands is given by (we have used the notation Be = fB ⇐⇒ e 7→ f)

$$K_k \mapsto K_{k+1}$$

$$K_{k+1} \mapsto K_k ,$$
(E.26)

analogous to the algebraic relation in Appendix [D.](#page-77-0)

![](_page_91_Picture_4.jpeg)

Figure 26: Braiding action on heavy strands

The action of B<sup>k</sup> on the rungs in the planar limit is given by

<span id="page-92-0"></span>
$$i, j \neq k, k+1 : e_{-;i,j} \mapsto e_{-;i,j}$$

$$f_{-;i,j} \mapsto f_{-;i,j}$$

$$i < k, j = k : f_{-;i,k} \mapsto f_{-;i,k+1} - \epsilon_{k+1} f_{-;i,k} f_{-;k,k+1}$$

$$i = k, j < k : e_{-;k,j} \mapsto e_{-;k+1,j} + \epsilon_{k+1} e_{-;k+1,k} e_{-;k,j}$$

$$i = k+1, j \neq k : e_{-;k+1,j} \mapsto e_{-;k,j}$$

$$f_{-;k+1,j} \mapsto f_{-;k,j}$$

$$i \neq k, j = k+1 : e_{-;i,k+1} \mapsto e_{-;i,k}$$

$$f_{-;i,k+1} \mapsto f_{-;i,k}$$

$$i = k, j = k+1 : f_{-;k,k+1} \mapsto K_{k+1} K_k^{-1} e_{-;k+1,k}$$

$$i = k+1, j = k : e_{-;k+1,k} \mapsto K_{k+1}^{-1} K_k f_{-;k,k+1}$$

$$i = k, j > k+1 : f_{-;k,j} \mapsto f_{-;k+1,j} + \epsilon_{k+1} K_{k+1} K_k^{-1} e_{-;k+1,k} f_{-;k,j}$$

$$i > k+1, j = k : e_{-;i,k} \mapsto e_{-;i,k+1} - \epsilon_{k+1} K_{k+1}^{-1} K_k f_{-;k,k+1} e_{-;i,k},$$

where it is understood that K<sup>k</sup> corresponds to the eigenvalue of the evaluation operator K<sup>k</sup> associated with the strand k before the braiding is carried out. Therefore K<sup>k</sup> can be thought of as c-number when performing subsequent braiding.

It can be checked that the action described above is, in fact, a representation of the braid group, compatible with its defining relations. The factor ϵ keeps track of whether the heavy strands at k are going up or down, that is ϵup = 1 and ϵdown = −1. But, during most of our analysis, we will assume the strands are going only up. It can also be checked that these relations are, in fact, the planar limit of the braiding action defined in Appendix [C.](#page-69-0)

The cups and caps can be thought of geometrically as objects that reduce long rungs to the closest possible rung configuration (see Figure [28\)](#page-93-1). This reduces the number of independent rung vevs to keep track of in a knot/link. We assume the cups connect strands i and i + 1, with i odd.

The planar limit of the cup and cap relation in Appendix [D](#page-77-0) then becomes (again here we use the notation a 7→ b to indicate that a ∪<sup>i</sup> = b ∪<sup>i</sup> and we typically use them

<span id="page-93-0"></span>![](_page_93_Picture_0.jpeg)

Figure 27: An example of moving the rung up through a braid. In (a), we start with a e<sup>−</sup>;k,i and move it through braid Bk, which then decomposes into the rungs e<sup>−</sup>;k+1,i +ϵk+1 e<sup>−</sup>;k+1,k e<sup>−</sup>;k,i as given by Eq. [\(E.27\)](#page-92-0). We depicted on the right-hand side of the picture all the rungs that are in the final answer.

<span id="page-93-1"></span>![](_page_93_Picture_2.jpeg)

Figure 28: An example of cup constraints: In (a), We have the rung e<sup>−</sup>;4,<sup>1</sup> which, when applied to the cup constraints, can be expressed as −K<sup>1</sup> K<sup>−</sup><sup>1</sup> 3 e<sup>−</sup>;3,<sup>2</sup> as denoted in (b).

interchangeably)

$$i \text{ odd, } j = i+1: \quad f_{-;i,j} \mapsto -\left(gK_i^{-1} - g^{-1}K_i\right)$$

$$j \text{ odd, } i = j+1: \quad e_{-;i,j} \mapsto -\left(K_i - K_i^{-1}\right)$$

$$i < j, \quad \text{even } i, \text{ odd } j: \quad f_{-;i,j} \mapsto f_{-;i,j}$$

$$i > j, \quad \text{even } j, \text{ odd } i: \quad e_{-;i,j} \mapsto e_{-;i,j}$$

$$i > j, \quad \text{odd } i, \text{ odd } j: \quad e_{-;i,j} \mapsto K_j e_{-;i,j+1}$$

$$i < j, \quad \text{odd } i, \text{ odd } j: \quad f_{-;i,j} \mapsto -K_{i+1} f_{-;i+1,j}$$

$$i > j, \quad \text{even } i, \text{ even } j: \quad e_{-;i,j} \mapsto -K_{i-1}^{-1} e_{-;i-1,j}$$

$$i < j, \quad \text{even } i, \text{ even } j: \quad f_{-;i,j} \mapsto K_j^{-1} f_{-;i,j-1}$$

$$i > j, \quad \text{even } i, \text{ odd } j: \quad e_{-;i,j} \mapsto -K_j K_{i-1}^{-1} e_{-;i-1,j+1}$$

$$i < j, \quad \text{odd } i, \text{ even } j: \quad f_{-;i,j} \mapsto -K_{i+1} K_j^{-1} f_{-;i+1,j-1}.$$

Similarly, the cap constraints become

$$j = i + 1, \quad i \text{ odd}: \quad f_{-;i,j} \mapsto (K_i - K_i^{-1})$$

$$i = j + 1, \quad j \text{ odd}: \quad e_{-;i,j} \mapsto (gK_j^{-1} - g^{-1}K_j)$$

$$i < j, \quad i \text{ even}, \quad j \text{ odd}: \quad f_{-;i,j} \mapsto f_{-;i,j}$$

$$i > j, \quad i \text{ odd}, \quad j \text{ even}: \quad e_{-;i,j} \mapsto e_{-;i,j}$$

$$i > j, \quad i \text{ odd}, \quad j \text{ odd}: \quad e_{-;i,j} \mapsto K_{j+1}^{-1} e_{-;i,j+1}$$

$$i < j, \quad i \text{ odd}, \quad j \text{ odd}: \quad f_{-;i,j} \mapsto -K_i^{-1} f_{-;i+1,j}$$

$$i > j, \quad i \text{ even}, \quad j \text{ even}: \quad e_{-;i,j} \mapsto -K_i e_{-;i-1,j}$$

$$i < j, \quad i \text{ even}, \quad j \text{ odd}: \quad e_{-;i,j} \mapsto K_{j-1} f_{-;i,j-1}$$

$$i > j, \quad i \text{ even}, \quad j \text{ odd}: \quad e_{-;i,j} \mapsto -K_{j+1}^{-1} K_i e_{-;i-1,j+1}$$

$$i < j, \quad i \text{ odd}, \quad j \text{ even}: \quad f_{-;i,j} \mapsto -K_i^{-1} K_{j-1} f_{-;i+1,j-1}.$$

![](_page_94_Picture_2.jpeg)

![](_page_94_Picture_3.jpeg)

Figure 29: An example of cap constraints: In (a), we have the rung e<sup>−</sup>;3,<sup>1</sup> which, when applied to the cup constraints, can be expressed as K<sup>−</sup><sup>1</sup> 2 e<sup>−</sup>;3,<sup>2</sup> as in (b).

## <span id="page-94-0"></span>F Examples of augmentation varieties

Torus knot T(2, 2l + 1). Also labeled by (2l + 1)1, this knot has a Schubert presentation in terms of 4 strands and the insertion of the braiding B 2l+1 2 . Note that this knot is chiral and this is the right-handed version. Also, the vertical framing we are considering differs in 2l + 1 units with respect to the canonical framing, in which the self-linking number is 0.

We take the same conventions as for the trefoil T(2, 3) in section [3.4,](#page-30-0) and we use a superscript (i) for the value of the vevs after i braidings, starting from the bottom. For example, f (2l+1) −;1,2 is the vev of f<sup>−</sup>;1,<sup>2</sup> at the top of the braid, and e (1) 2 is the vev of e<sup>2</sup> located above the first braiding at the bottom.

Similarly to the case of the trefoil, braiding twice keeps the vevs of e<sup>2</sup> and f<sup>2</sup> invariant, so we will denote f<sup>2</sup> = f (2i+1) 2 and e<sup>2</sup> = e (2i+1) 2 . Note that this is also the value of the vevs at the top. Another similarity is the relation  $f_2 = \lambda e_2$ , which can be deduced in the same way as for the trefoil.

Taking now j odd, we can compute the braiding transformation

$$f_{-;1,3}^{(j)} = f_{-;1,3}^{(j+2)} - f_1^{(j+2)} f_2$$
  

$$f_1^{(j)} = f_1^{(j+2)} (1 + e_2 f_2) - f_{-;1,3}^{(j+2)} e_2.$$
 (F.1)

This is a recursion suitable to a nice matrix form

$$\begin{pmatrix} f_{-;1,3}^{(1)} \\ f_1^{(1)} \end{pmatrix} = \begin{pmatrix} 1 & -f_2 \\ -e_2 & 1 + e_2 f_2 \end{pmatrix}^l \begin{pmatrix} f_{-;1,3}^{(2l+1)} \\ f_1^{(2l+1)} \end{pmatrix}.$$
(F.2)

Braiding once more from (0) to (1), applying the cups and caps and using the relation between  $e_2$  and  $f_2$  to eliminate  $f_2$ , we get

$$\begin{pmatrix}
\lambda \left(g^2 \left(e_2^2 \lambda + 1\right) - \mu^2\right) \\
e_2 g^2 \lambda
\end{pmatrix} = \begin{pmatrix}
1 & -e_2 \lambda \\
-e_2 & e_2^2 \lambda + 1
\end{pmatrix}^l \begin{pmatrix}
e_2 g \lambda \\
-g \left(\mu^2 - 1\right)
\end{pmatrix}.$$
(F.3)

The augmentation variety is obtained by eliminating  $e_2$  from the system of equations. For the unknot T(1,1) we recover

$$A_{T(1,1)} = g^2 \lambda - \mu^2 \lambda + \mu^4 - \mu^2, \qquad (F.4)$$

with

$$e_2 = \frac{g}{\mu^2} - \frac{1}{g} \,. \tag{F.5}$$

For the trefoil T(2,3)

$$\mathcal{A}_{3_1} = g^6 \lambda^2 + 2g^4 \mu^4 \lambda - g^4 \mu^2 \lambda^2 - g^4 \mu^2 \lambda + g^4 \lambda + g^2 \mu^8 - g^2 \mu^6 \lambda - g^2 \mu^6 - 2g^2 \mu^4 \lambda + \mu^8 \lambda , \text{ (F.6)}$$
  
for  $T(2,5)$ 

$$\begin{split} \mathcal{A}_{5_{1}} &= g^{10}\lambda^{3} + 3g^{8}\mu^{4}\lambda^{2} - g^{8}\mu^{2}\lambda^{3} - g^{8}\mu^{2}\lambda^{2} + 2g^{8}\lambda^{2} + 3g^{6}\mu^{8}\lambda - 2g^{6}\mu^{6}\lambda^{2} - 2g^{6}\mu^{6}\lambda \\ &- 4g^{6}\mu^{4}\lambda^{2} + 2g^{6}\mu^{4}\lambda - g^{6}\mu^{2}\lambda^{2} - g^{6}\mu^{2}\lambda + g^{6}\lambda + g^{4}\mu^{12} - g^{4}\mu^{10}\lambda - g^{4}\mu^{10} \\ &+ 2g^{4}\mu^{8}\lambda^{2} - 4g^{4}\mu^{8}\lambda + 2g^{4}\mu^{6}\lambda^{2} + 2g^{4}\mu^{6}\lambda + g^{4}\mu^{4}\lambda^{2} - 2g^{4}\mu^{4}\lambda + 2g^{2}\mu^{12}\lambda \\ &- g^{2}\mu^{10}\lambda^{2} - g^{2}\mu^{10}\lambda - 2g^{2}\mu^{8}\lambda^{2} + g^{2}\mu^{8}\lambda + \mu^{12}\lambda^{2} \,, \end{split}$$
 (F.7)

and for T(2,7)

$$\begin{split} \mathcal{A}_{7_1} &= g^{14}\lambda^4 + 4g^{12}\mu^4\lambda^3 - g^{12}\mu^2\lambda^4 - g^{12}\mu^2\lambda^3 + 3g^{12}\lambda^3 + 6g^{10}\mu^8\lambda^2 - 3g^{10}\mu^6\lambda^3 \\ &- 3g^{10}\mu^6\lambda^2 - 6g^{10}\mu^4\lambda^3 + 6g^{10}\mu^4\lambda^2 - 2g^{10}\mu^2\lambda^3 - 2g^{10}\mu^2\lambda^2 + 3g^{10}\lambda^2 \\ &+ 4g^8\mu^{12}\lambda - 3g^8\mu^{10}\lambda^2 - 3g^8\mu^{10}\lambda + 3g^8\mu^8\lambda^3 - 12g^8\mu^8\lambda^2 + 3g^8\mu^8\lambda + 4g^8\mu^6\lambda^3 \\ &+ 2g^8\mu^6\lambda^2 - 2g^8\mu^6\lambda + 2g^8\mu^4\lambda^3 - 8g^8\mu^4\lambda^2 + 2g^8\mu^4\lambda - g^8\mu^2\lambda^2 - g^8\mu^2\lambda + g^8\lambda \\ &+ g^6\mu^{16} - g^6\mu^{14}\lambda - g^6\mu^{14} + 6g^6\mu^{12}\lambda^2 - 6g^6\mu^{12}\lambda - 2g^6\mu^{10}\lambda^3 + 2g^6\mu^{10}\lambda^2 \\ &+ 4g^6\mu^{10}\lambda - 4g^6\mu^8\lambda^3 + 10g^6\mu^8\lambda^2 - 4g^6\mu^8\lambda - g^6\mu^6\lambda^3 + g^6\mu^6\lambda^2 + 2g^6\mu^6\lambda \\ &+ 2g^6\mu^4\lambda^2 - 2g^6\mu^4\lambda + 3g^4\mu^{16}\lambda - 2g^4\mu^{14}\lambda^2 - 2g^4\mu^{14}\lambda + 2g^4\mu^{12}\lambda^3 - 8g^4\mu^{12}\lambda^2 \\ &+ 2g^4\mu^{12}\lambda + 2g^4\mu^{10}\lambda^3 + g^4\mu^{10}\lambda^2 - g^4\mu^{10}\lambda + g^4\mu^8\lambda^3 - 4g^4\mu^8\lambda^2 + g^4\mu^8\lambda \\ &+ 3g^2\mu^{16}\lambda^2 - g^2\mu^{14}\lambda^3 - g^2\mu^{14}\lambda^2 - 2g^2\mu^{12}\lambda^3 + 2g^2\mu^{12}\lambda^2 + \mu^{16}\lambda^3 \,. \end{split} \tag{F.8}$$

In the  $g \to 1$  limit, the tree-level augmentation variety of the torus knot T(2, 2l + 1) is

$$(\mu^2 - 1)(1 + \lambda)^l(\lambda - \mu^{2(2l+1)}) = 0.$$
 (F.9)

**Torus link** T(2,2l). This link has a Schubert presentation in terms of 4 strands and the insertion of the braiding  $B_2^{2l}$ . In this case, the braiding does not keep  $e_2$  and  $f_2$  invariant, but denoting  $e_2 = e_2^{(0)}$  and  $f_2 = f_2^{(0)}$ , it still leads to nice relations

$$f_2^{(2i)} = \left(\frac{g}{\mu_1 \mu_2}\right)^{2i} f_2$$

$$e_2^{(2i)} = \left(\frac{g}{\mu_1 \mu_2}\right)^{-2i} e_2.$$
(F.10)

We can get relations between vevs in a similar way as for T(2, 2l + 1). Keeping track of the new factors in various places, we obtain

$$\lambda_{1} \begin{pmatrix} g^{2} f_{2} \\ g^{2} - \mu_{1}^{2} \end{pmatrix} = M_{1} \cdots M_{l} \begin{pmatrix} g f_{2} \left( \frac{g}{\mu_{1} \mu_{2}} \right)^{2l} \\ -g \left( \mu_{1}^{2} - 1 \right) \end{pmatrix}$$

$$\lambda_{2} \begin{pmatrix} g^{2} f_{2} \\ g^{2} - \mu_{2}^{2} \end{pmatrix} = M_{1} \cdots M_{l} \begin{pmatrix} g f_{2} \left( \frac{g}{\mu_{1} \mu_{2}} \right)^{2l} \\ -g \left( \mu_{2}^{2} - 1 \right) \end{pmatrix}, \tag{F.11}$$

where the matrix  $M_i$  is

$$M_{i} = \begin{pmatrix} 1 & -f_{2} \left(\frac{g}{\mu_{1}\mu_{2}}\right)^{2i} \\ -e_{2} \left(\frac{g}{\mu_{1}\mu_{2}}\right)^{1-2i} & 1 + \frac{g}{\mu_{1}\mu_{2}}e_{2}f_{2} \end{pmatrix}.$$
 (F.12)

There is always a disconnected saddle in which the vev of  $e_2f_2$  is zero, and this part of the variety takes the same form as for two unknots. The interesting saddles are in the connected part of the augmentation variety.

For the Hopf link T(2,2)

$$\lambda_1 = \frac{g}{\mu_2^2} \qquad \lambda_2 = \frac{g}{\mu_1^2} \,, \tag{F.13}$$

For T(2,4)

$$-g^4 - g\mu_2^2(\mu_1^2 - \mu_2^2)\lambda_1 + \mu_1^2\mu_2^6\lambda_1^2 = 0$$
  
$$-g^4 + g\mu_1^2(\mu_1^2 - \mu_2^2)\lambda_2 + \mu_1^6\mu_2^2\lambda_2^2 = 0.$$
 (F.14)

In the  $g \to 1$  limit, the disconnected part of the tree-level augmentation variety of T(2,4) reduces to two solutions for  $(\lambda_1, \lambda_2)$ :

$$\lambda_1 = \frac{1}{\mu_2^4} \qquad \lambda_2 = \frac{1}{\mu_1^4},$$
(F.15)

and

$$\lambda_1 = \lambda_2 = -\frac{1}{\mu_1^2 \mu_2^2} \,. \tag{F.16}$$

Figure-eight knot (4<sub>1</sub>). This knot has a 4-strand Schubert presentation with braiding  $B_2B_1^{-1}B_2^2$ , see Figure 30.

$$\mathcal{A}_{4_1} = -g^3 \mu^4 + g^3 \mu^6 + g^6 \lambda - 2g^4 \mu^2 \lambda + 2g^2 \mu^8 \lambda - \mu^{10} \lambda - g^5 \lambda^2 + 2g^5 \mu^2 \lambda^2 - 2g \mu^8 \lambda^2 + g \mu^{10} \lambda^2 + g^4 \mu^4 \lambda^3 - g^2 \mu^6 \lambda^3.$$
 (F.17)

The bowstring knot (5<sub>2</sub>). This knot has a 4-strand Schubert presentation with braiding  $B_2B_1^{-2}B_2^2$ , see Figure 30.

$$\begin{split} \mathcal{A}_{5_2} &= g^2 \mu^{26} - g^2 \mu^{28} - 2g^6 \mu^{16} \lambda + 4g^6 \mu^{18} \lambda + 3g^4 \mu^{20} \lambda - 3g^6 \mu^{20} \lambda - 2g^4 \mu^{22} \lambda - g^4 \mu^{24} \lambda \\ &\quad + 2g^2 \mu^{26} \lambda - \mu^{28} \lambda + g^{10} \mu^6 \lambda^2 - 3g^{10} \mu^8 \lambda^2 - 4g^8 \mu^{10} \lambda^2 + 5g^{10} \mu^{10} \lambda^2 + 3g^8 \mu^{12} \lambda^2 \\ &\quad - 3g^{10} \mu^{12} \lambda^2 + 6g^6 \mu^{14} \lambda^2 - 4g^8 \mu^{14} \lambda^2 + 3g^6 \mu^{16} \lambda^2 - 3g^8 \mu^{16} \lambda^2 - 4g^4 \mu^{18} \lambda^2 \\ &\quad + 5g^6 \mu^{18} \lambda^2 - 3g^4 \mu^{20} \lambda^2 + g^2 \mu^{22} \lambda^2 - g^{14} \lambda^3 + 2g^{14} \mu^2 \lambda^3 - g^{14} \mu^4 \lambda^3 - 2g^{12} \mu^6 \lambda^3 \\ &\quad + 3g^{10} \mu^8 \lambda^3 - 3g^{12} \mu^8 \lambda^3 + 4g^{10} \mu^{10} \lambda^3 - 2g^8 \mu^{12} \lambda^3 - g^{16} \lambda^4 + g^{14} \mu^2 \lambda^4 \,. \end{split} \tag{F.18}$$

<span id="page-98-1"></span>![](_page_98_Picture_0.jpeg)

**Figure 30**: (a) The figure-eight knot  $(4_1)$  (b) The bowstring knot  $(5_2)$ 

Stevedore's knot (6<sub>1</sub>). This knot has a 4-strand Schubert presentation with braiding  $B_2^2 B_3^{-3} B_2$ , see Figure 31a.

$$\begin{split} \mathcal{A}_{6_{1}} &= g^{3}\mu^{24} - g^{3}\mu^{26} - 2g^{8}\mu^{16}\lambda + 4g^{6}\mu^{18}\lambda + g^{8}\mu^{18}\lambda - g^{6}\mu^{20}\lambda - 2g^{6}\mu^{22}\lambda + g^{4}\mu^{26}\lambda \\ &- 2g^{2}\mu^{28}\lambda + \mu^{30}\lambda + g^{13}\mu^{8}\lambda^{2} - 4g^{11}\mu^{10}\lambda^{2} + 6g^{9}\mu^{12}\lambda^{2} - 2g^{11}\mu^{12}\lambda^{2} \\ &- g^{9}\mu^{14}\lambda^{2} + 3g^{9}\mu^{16}\lambda^{2} - 4g^{7}\mu^{20}\lambda^{2} - 3g^{5}\mu^{22}\lambda^{2} + 4g^{3}\mu^{24}\lambda^{2} + 2g^{5}\mu^{24}\lambda^{2} \\ &- 2g^{3}\mu^{26}\lambda^{2} - 2g^{14}\mu^{4}\lambda^{3} + 4g^{12}\mu^{6}\lambda^{3} + 2g^{14}\mu^{6}\lambda^{3} - 3g^{12}\mu^{8}\lambda^{3} \\ &- 4g^{12}\mu^{10}\lambda^{3} + 3g^{10}\mu^{14}\lambda^{3} - g^{8}\mu^{16}\lambda^{3} + 6g^{6}\mu^{18}\lambda^{3} - 2g^{8}\mu^{18}\lambda^{3} + g^{15}\lambda^{4} \\ &- 2g^{15}\mu^{2}\lambda^{4} + g^{15}\mu^{4}\lambda^{4} - 2g^{13}\mu^{8}\lambda^{4} - g^{11}\mu^{10}\lambda^{4} + 4g^{9}\mu^{12}\lambda^{4} + g^{11}\mu^{12}\lambda^{4} \\ &- 2g^{9}\mu^{14}\lambda^{4} - g^{14}\mu^{4}\lambda^{5} + g^{12}\mu^{6}\lambda^{5} \,. \end{split} \tag{F.19}$$

#### <span id="page-98-0"></span>F.1 Additional considerations

**Mirrors.** For every chiral knot, one can associate a mirror knot, which is obtained by replacing all its braid group elements by their inverses. For example, the mirror of the Stevedore knot is given by  $B_2^{-2}B_3^3B_2^{-2}$ . See Figure 31b. One can easily compute the augmentation of a mirror knot by performing the following transformation

$$\mathcal{A}_{\text{mirror}}(\lambda, \mu, g) = \mathcal{A}\left(\frac{1}{\lambda}, \frac{\mu}{g}, \frac{1}{g}\right), \qquad (F.20)$$

<span id="page-99-0"></span>![](_page_99_Picture_0.jpeg)

Figure 31: Stevedore's knot (a) and its mirror (b).

which is consistent with the fact that the mirror of the mirror is the original knot.

Symmetric vs antisymmetric powers. The augmentation polynomial of symmetric powers of the fundamental representation can be obtained from the one of antisymmetric powers by replacing N with −N, i.e. q → −q, and vice versa. This means

$$\mathcal{A}_{S^{\bullet}\mathbb{C}^{N}}(\lambda,\mu,g) = \mathcal{A}_{\Lambda^{\bullet}\mathbb{C}^{N}}\left(\lambda,\frac{1}{\mu},\frac{1}{g}\right). \tag{F.21}$$

Symmetry. The augmentation variety has a k → N − k symmetry

$$\mathcal{A}(\lambda, \mu, g) = \mathcal{A}\left(\frac{1}{\lambda}, \frac{g}{\mu}, g\right).$$
 (F.22)

Framing. All our calculations are done in vertical framing. To change to canonical framing, we have to add the twisting factor to λ

$$\mathcal{A}_{\text{canonical}}(\lambda, \mu, g) = \mathcal{A}\left(\lambda\left(\frac{g}{\mu^2}\right)^x, \mu, g\right)$$
 (F.23)

where x is the self-linking number of the given presentation of the knot in vertical framing, which can be computed by counting crossings with signs given by Figure [32.](#page-100-0)

<span id="page-100-0"></span>![](_page_100_Picture_0.jpeg)

Figure 32: (a) Crossing number +1 (b) Crossing number −1

<span id="page-100-1"></span>![](_page_100_Picture_2.jpeg)

Figure 33: The unknot (left) and left-handed trefoil (right).

Different presentations. Our construction is consistent with three-dimensional manipulations of the strands and rungs (up to framing). To check this, we can present known knots in different ways and see that we recover the same augmentation varieties. We will illustrate it with the unknot and left-handed trefoil of Figure [33.](#page-100-1)

For the unknot we can start with f u <sup>1</sup> = −λ(gµ<sup>−</sup><sup>1</sup>−g <sup>−</sup><sup>1</sup>µ), braid it to obtain f a +;1,<sup>4</sup> = −f a 2 , and braid it back to −gµ<sup>−</sup><sup>2</sup> e u <sup>3</sup> = gµ<sup>−</sup><sup>2</sup> (µ − µ −1 ). This gives the augmentation variety of the unknot, accounting for the framing.

For the left-handed trefoil we can start with the rungs f u 1 , f u −;1,3 and f u −;1,4 , and perform the usual manipulations to obtain relations

$$-\lambda(g^{2} - \mu^{2}) = g\mu f_{2}^{a}(\mu^{2} - 2 + ge_{2}^{a}f_{2}^{a})$$

$$\lambda\mu e_{2}^{a} = \mu^{2} - 1 + ge_{2}^{a}f_{2}^{a}$$

$$g\lambda e_{2}^{a} = -\mu^{2}f_{2}^{a},$$
(F.24)

and obtain the augmentation variety

$$0 = g^6 \lambda - 2 g^4 \mu^4 \lambda - g^4 \mu^2 \lambda - g^4 \mu^2 + g^4 + g^2 \mu^8 \lambda - g^2 \mu^6 \lambda^2 - g^2 \mu^6 \lambda + 2 g^2 \mu^4 \lambda + \mu^8 \lambda^2 \; , \; (\text{F}.25)$$

which is mapped to the usual right-handed trefoil augmentation variety by the chirality reversal map λ → λ −1 , µ → µg<sup>−</sup><sup>1</sup> , g → g −1 .

## <span id="page-101-0"></span>G Augmentation variety from symmetric HOMFLY

In this section, we test the relationship between augmentation varieties and recursion relations for colored HOMFLY polynomials for several knots. As a source for the latter, we will employ [\[70\]](#page-107-13). This computes the HOMFLY polynomials for symmetric powers of the fundamental representation for an infinite sequence of "twist" knots, which include the trefoil and figure eight:

$$W_{3_1,S^n\mathbb{C}^N} = \sum_{i=0}^n (-1)^i a^{2i} q^{i(i-1)} \begin{bmatrix} n \\ i \end{bmatrix} \{n+i-1;a\}_i \{i-2;a\}_i$$
 (G.1)

$$W_{4_1,S^n\mathbb{C}^N} = \sum_{i=0}^n \begin{bmatrix} n \\ i \end{bmatrix} \{n+i-1;a\}_i \{i-2;a\}_i,$$
 (G.2)

with a = q <sup>N</sup> (Corollary 5.2 in the reference). Although our main interest is antisymmetric powers of the fundamental representation, we expect that the augmentation varieties for symmetric and anti-symmetric power knot invariants must be related by N → −N. This will indeed be the case, i.e. the two varieties are related by a = g −1 .

The reference [\[70\]](#page-107-13) expresses the answer as sums over one or two variables of products of q-integers. In order to find the large N saddles of such an expression, we do a saddle evaluation of the sums themselves. The sum is either dominated by an intermediate summand or by one of the endpoints. The first type of saddles we consider thus extremize the summand with respect to the summation variables, requiring the ratio of consecutive terms to be 1. The second just specializes the summand to the endpoints of the sum.

As an example, consider the trefoil invariant W<sup>3</sup>1,SnC<sup>N</sup> . We look for a value of s = q i such that the ratio

$$-a^{2}s^{2}\frac{\mu/s - s/\mu}{s - 1/s}(a\mu s - a^{-1}\mu^{-1}s^{-1})(as - a^{-1}s^{-1})$$
 (G.3)

of consecutive terms is 1. Here we denote q <sup>n</sup> = µ. The saddle for i is thus

$$(\mu^2 - s^2)(a^2\mu^2s^2 - 1)(a^2s^2 - 1) + \mu^2(s^2 - 1) = 0.$$
 (G.4)

We can expand it to

$$a^{4}\mu^{4}s^{4} - a^{2}\mu^{4}s^{2} - a^{2}\mu^{2}s^{2} + \mu^{2}s^{2} = (a^{4}\mu^{2}s^{4} - a^{2}\mu^{2}s^{2} - a^{2}s^{2} + 1)s^{2},$$
 (G.5)

and remove a factor of s 2 :

$$a^4\mu^2s^4 - a^4\mu^4s^2 - a^2\mu^2s^2 - a^2s^2 + a^2\mu^4 + a^2\mu^2 - \mu^2 + 1 = 0.$$
 (G.6)

After replacing the sum with the dominant term, we compute λ by taking the ratio of the dominant terms evaluated at n + 1 and n:

$$\frac{\mu - \mu^{-1}}{\mu s^{-1} - \mu^{-1} s} \frac{a\mu s - a^{-1}\mu^{-1} s^{-1}}{a\mu - a^{-1}\mu^{-1}}.$$
 (G.7)

We should include an extra factor of aµ−a−1µ−<sup>1</sup> <sup>µ</sup>−µ−<sup>1</sup> to go from HOMFLY to the knot correlation function. We get

$$\lambda = \frac{a\mu s - a^{-1}\mu^{-1}s^{-1}}{\mu s^{-1} - \mu^{-1}s},$$
(G.8)

i.e.

$$a(\mu^2 - s^2)\lambda = a^2\mu^2 s^2 - 1,$$
 (G.9)

and

$$s^2 = a^{-1} \frac{a\mu^2\lambda + 1}{a\mu^2 + \lambda} \,, \tag{G.10}$$

leading to

$$a^{2}\mu^{2}(a\mu^{2}\lambda+1)^{2} - a(a^{2}\mu^{4} + \mu^{2} + 1)(a\mu^{2}\lambda+1)(a\mu^{2} + \lambda) + (a^{2}\mu^{4} + a^{2}\mu^{2} - \mu^{2} + 1)(a\mu^{2} + \lambda)^{2} = 0.$$
(G.11)

Expanding out:

$$(1-\mu^2)\lambda^2 + (-a^4\mu^8 + a^2\mu^6 + 2(a^2-1)\mu^4 + \mu^2 - 1)a\lambda + a^2\mu^6(a^2\mu^2 - 1) = 0.$$
 (G.12)

This matches [\[16\]](#page-104-12) et al. under Q → a 2 , λ<sup>1</sup> → a/λ, µ<sup>1</sup> → µ 2a 2 . It also matches our answer under g → 1/a, λ → a 3µ <sup>6</sup>/λ. The former encodes N → −N, the latter is due to different framing conventions.

The "endpoint" saddles are a bit more confusing. The i = 0 endpoint gives λ = 1. The i = n endpoint gives λ = −a 2µ 2 (µ <sup>2</sup>a − µ <sup>−</sup><sup>2</sup>a −1 ) 2 aµ−a−1µ−<sup>1</sup> µ−µ−<sup>1</sup> . We do not understand the role of these saddles and we will disregard them from now on.

We can repeat the analysis for the figure eight knot answer. Now the intermediate saddle condition is

$$(\mu^2 - s^2)(a^2\mu^2s^2 - 1)(a^2s^2 - 1) + a^2\mu^2s^2(s^2 - 1) = 0,$$
 (G.13)

while

$$\lambda = \frac{a\mu s - a^{-1}\mu^{-1}s^{-1}}{\mu s^{-1} - \mu^{-1}s}$$
 (G.14)

gives again

$$s^2 = a^{-1} \frac{a\mu^2\lambda + 1}{a\mu^2 + \lambda} \,, \tag{G.15}$$

and thus the augmentation variety

$$a^{3}\mu^{4}(\mu^{2}-1)\lambda^{3} + \left(a^{6}\mu^{10} - 4a^{4}\mu^{6} + 4a^{2}\mu^{4} - 1\right)\lambda(\lambda - a) - a^{2}\mu^{4}(a^{2}\mu^{2} - 1). \tag{G.16}$$

Finally, we can extend the analysis to the infinite family of twist knots K<sup>p</sup> from Theorem 5.1 in the reference:

$$W_{K_p,S^n\mathbb{C}^N} = \sum_{i=0}^n a^i q^{\frac{i(i-1)}{2}} \{i\}! s_{i,p} \begin{bmatrix} n \\ i \end{bmatrix} \{n+i-1;a\}_i \{i-2;a\}_i,$$

where

$$s_{i,p} = \sum_{k=0}^{i} (-1)^k \frac{(a^k q^{k(k-1)})^{2p}}{\{k\}! \{i-k\}!} \cdot \frac{\{2k-1; a\}}{\{i+k-1; a\}_{i+1}}.$$

We need first to estimate si+1,p/si,p by a saddle evaluation of the second sum. If q <sup>k</sup> = u,

$$1 = -(au^2)^{2p} \frac{s/u - u/s}{u - 1/u} \frac{au - 1/a/u}{aus - 1/a/u/s},$$
 (G.17)

i.e.

$$(u^{2}-1)(a^{2}u^{2}s^{2}-1) = -(au^{2})^{2p}(s^{2}-u^{2})(a^{2}u^{2}-1).$$
 (G.18)

Then the ratio is

$$\frac{s^2u^2a}{(s^2-u^2)(a^2s^2u^2-1)}. (G.19)$$

The saddle equation for the i sum becomes

$$1 = as(s - 1/s) \frac{s^2 u^2 a}{(s^2 - u^2)(a^2 s^2 u^2 - 1)} \frac{\mu/s - s/\mu}{s - 1/s} (a\mu s - 1/a/\mu/s)(as - 1/a/s),$$
 (G.20)

i.e.

$$\mu^{2}(s^{2} - u^{2})(a^{2}s^{2}u^{2} - 1) = u^{2}(\mu^{2} - s^{2})(a^{2}\mu^{2}s^{2} - 1)(a^{2}s^{2} - 1).$$
 (G.21)

It reduces to

$$-a^{4}l^{2}s^{4}u^{2} - a^{2}l^{4}u^{2} + a^{2}l^{2}u^{4} - a^{2}l^{2}u^{2} + s^{2}\left(a^{4}l^{4}u^{2} + a^{2}u^{2}\right) + l^{2} - u^{2} = 0.$$
 (G.22)

Finally, the final answer is estimated:

$$\lambda = (a\mu s - 1/a/\mu/s)/(\mu/s - s/\mu),$$
 (G.23)

i.e.

$$s^2 = a^{-1} \frac{a\mu^2\lambda + 1}{a\mu^2 + \lambda} \,, \tag{G.24}$$

which we can plug back into the two previous equations to get two lengthy equations in λ, µ and u.

## References

- <span id="page-104-0"></span>[1] R. Gopakumar and C. Vafa, On the gauge theory / geometry correspondence, Adv. Theor. Math. Phys. 3 (1999) 1415–1443, [[hep-th/9811131](http://arxiv.org/abs/hep-th/9811131)].
- <span id="page-104-1"></span>[2] H. Ooguri and C. Vafa, Knot invariants and topological strings, Nucl. Phys. B 577 (2000) 419–438, [[hep-th/9912123](http://arxiv.org/abs/hep-th/9912123)].
- <span id="page-104-2"></span>[3] N. Halmagyi and V. Yasnov, The Spectral curve of the lens space matrix model, JHEP 11 (2009) 104, [[hep-th/0311117](http://arxiv.org/abs/hep-th/0311117)].
- [4] M. Marino, S. Pasquetti, and P. Putrov, Large N duality beyond the genus expansion, JHEP 07 (2010) 074, [[arXiv:0911.4692](http://arxiv.org/abs/0911.4692)].
- <span id="page-104-3"></span>[5] G. Borot and A. Brini, Chern-Simons theory on spherical Seifert manifolds, topological strings and integrable systems, Adv. Theor. Math. Phys. 22 (2018) 305–394, [[arXiv:1506.06887](http://arxiv.org/abs/1506.06887)].
- <span id="page-104-4"></span>[6] J. H. Przytycki, Skein modules, 2006.
- <span id="page-104-5"></span>[7] J. H. Przytycki, Skein modules of 3-manifolds, 2006.
- <span id="page-104-6"></span>[8] S.-J. Rey and J.-T. Yee, Macroscopic strings as heavy quarks in large N gauge theory and anti-de Sitter supergravity, Eur. Phys. J. C 22 (2001) 379–394, [[hep-th/9803001](http://arxiv.org/abs/hep-th/9803001)].
- <span id="page-104-7"></span>[9] P. Etingof, Representation theory in complex rank, ii, 2020.
- <span id="page-104-8"></span>[10] G. 't Hooft, A Planar Diagram Theory for Strong Interactions, Nucl. Phys. B 72 (1974) 461.
- <span id="page-104-9"></span>[11] D. Gaiotto, A. L´opez-Raven, H. Silverans, and K. Zeng, Categorical 't Hooft expansion and chiral algebras, [arXiv:2411.00760](http://arxiv.org/abs/2411.00760).
- <span id="page-104-14"></span>[12] I. R. Klebanov and A. M. Polyakov, AdS dual of the critical O(N) vector model, Phys. Lett. B 550 (2002) 213–219, [[hep-th/0210114](http://arxiv.org/abs/hep-th/0210114)].
- <span id="page-104-15"></span>[13] M. R. Gaberdiel and R. Gopakumar, An AdS<sup>3</sup> Dual for Minimal Model CFTs, Phys. Rev. D 83 (2011) 066007, [[arXiv:1011.2986](http://arxiv.org/abs/1011.2986)].
- <span id="page-104-10"></span>[14] E. Witten, Quantum Field Theory and the Jones Polynomial, Commun. Math. Phys. 121 (1989) 351–399.
- <span id="page-104-11"></span>[15] H. R. Morton, Invariants of Links and 3-Manifolds From Skein Theory and From Quantum Groups, pp. 107–155. Springer Netherlands, Dordrecht, 1993.
- <span id="page-104-12"></span>[16] M. Aganagic and C. Vafa, Large N Duality, Mirror Symmetry, and a Q-deformed A-polynomial for Knots, [arXiv:1204.4709](http://arxiv.org/abs/1204.4709).
- <span id="page-104-13"></span>[17] M. Aganagic, T. Ekholm, L. Ng, and C. Vafa, Topological Strings, D-Model, and Knot Contact Homology, Adv. Theor. Math. Phys. 18 (2014), no. 4 827–956, [[arXiv:1304.5778](http://arxiv.org/abs/1304.5778)].

- [18] M. Marino, Chern-Simons theory and topological strings, Rev. Mod. Phys. 77 (2005) 675–720, [[hep-th/0406005](http://arxiv.org/abs/hep-th/0406005)].
- [19] L. Ng, Knot and braid invariants from contact homology i, Geometry amp; Topology 9 (Jan., 2005) 247–297.
- [20] L. Ng, Knot and braid invariants from contact homology ii, Geometry amp; Topology 9 (Aug., 2005) 1603–1637.
- [21] D. E. Diaconescu, V. Shende, and C. Vafa, Large N duality, lagrangian cycles, and algebraic knots, Commun. Math. Phys. 319 (2013) 813–863, [[arXiv:1111.6533](http://arxiv.org/abs/1111.6533)].
- <span id="page-105-11"></span>[22] T. Ekholm, J. Etnyre, L. Ng, and M. Sullivan, Filtrations on the knot contact homology of transverse knots, Mathematische Annalen 355 (July, 2012) 1561–1591.
- [23] B. Fang and Z. Zong, Topological recursion for the conifold transition of a torus knot, 2017.
- [24] T. Ekholm and L. Ng, Higher genus knot contact homology and recursion for colored HOMFLY-PT polynomials, Adv. Theor. Math. Phys. 24 (2020), no. 8 2067–2145, [[arXiv:1803.04011](http://arxiv.org/abs/1803.04011)].
- <span id="page-105-0"></span>[25] T. Ekholm and V. Shende, Skeins on Branes, [arXiv:1901.08027](http://arxiv.org/abs/1901.08027).
- <span id="page-105-1"></span>[26] H. Gao, Augmentations and sheaves for links, 2021.
- <span id="page-105-2"></span>[27] L. Ng, A topological introduction to knot contact homology, arXiv e-prints (Oct., 2012) arXiv:1210.4803, [[arXiv:1210.4803](http://arxiv.org/abs/1210.4803)].
- <span id="page-105-3"></span>[28] K. Cieliebak, T. Ekholm, J. Latschev, and L. Ng, Knot contact homology, string topology, and the cord algebra, 2017.
- <span id="page-105-4"></span>[29] S. Gukov and E. Witten, Gauge Theory, Ramification, And The Geometric Langlands Program, [hep-th/0612073](http://arxiv.org/abs/hep-th/0612073).
- <span id="page-105-5"></span>[30] D. Nadler and E. Zaslow, Constructible sheaves and the fukaya category, 2008.
- <span id="page-105-6"></span>[31] D. Nadler, Microlocal branes are constructible sheaves, 2009.
- <span id="page-105-7"></span>[32] S. Cautis, J. Kamnitzer, and S. Morrison, Webs and quantum skew howe duality, Mathematische Annalen 360 (Apr., 2014) 351–390.
- <span id="page-105-8"></span>[33] D. Jordan, Quantum character varieties, 2023.
- <span id="page-105-9"></span>[34] L. Ng, A Topological Introduction to Knot Contact Homology, p. 485–530. Springer International Publishing, 2014.
- <span id="page-105-10"></span>[35] T. Ekholm, P. Kucharski, and P. Longhi, Physics and geometry of knots-quivers correspondence, Commun. Math. Phys. 379 (2020), no. 2 361–415, [[arXiv:1811.03110](http://arxiv.org/abs/1811.03110)].

- <span id="page-106-0"></span>[36] Y. Jiang, S. Komatsu, and E. Vescovi, Structure constants in N = 4 SYM at finite coupling as worldsheet g-function, JHEP 07 (2020), no. 07 037, [[arXiv:1906.07733](http://arxiv.org/abs/1906.07733)].
- <span id="page-106-1"></span>[37] K. Budzik and D. Gaiotto, Giant gravitons in twisted holography, JHEP 10 (2023) 131, [[arXiv:2106.14859](http://arxiv.org/abs/2106.14859)].
- <span id="page-106-2"></span>[38] P. Boalch, G-bundles, isomonodromy and quantum weyl groups, 2002.
- <span id="page-106-3"></span>[39] A. Kapustin and N. Saulina, The Algebra of Wilson-'t Hooft operators, Nucl. Phys. B 814 (2009) 327–365, [[arXiv:0710.2097](http://arxiv.org/abs/0710.2097)].
- <span id="page-106-4"></span>[40] D. Gaiotto, G. W. Moore, and A. Neitzke, Framed BPS States, Adv. Theor. Math. Phys. 17 (2013), no. 2 241–397, [[arXiv:1006.0146](http://arxiv.org/abs/1006.0146)].
- <span id="page-106-5"></span>[41] D. Gaiotto, Open Verlinde line operators, [arXiv:1404.0332](http://arxiv.org/abs/1404.0332).
- [42] G. Schrader and A. Shapiro, A cluster realization of uq(sln) from quantum character varieties, 2019.
- <span id="page-106-6"></span>[43] N. H. Aamand, Chern–Simons theory and the R-matrix, Lett. Math. Phys. 111 (2021), no. 6 146, [[arXiv:1905.03263](http://arxiv.org/abs/1905.03263)].
- <span id="page-106-7"></span>[44] E. Witten, Gauge theory and wild ramification, [arXiv:0710.0631](http://arxiv.org/abs/0710.0631).
- <span id="page-106-8"></span>[45] J. M. Maldacena, The Large N limit of superconformal field theories and supergravity, Adv. Theor. Math. Phys. 2 (1998) 231–252, [[hep-th/9711200](http://arxiv.org/abs/hep-th/9711200)].
- <span id="page-106-9"></span>[46] K. Costello and D. Gaiotto, Twisted holography, JHEP 01 (2025) 087, [[arXiv:1812.09257](http://arxiv.org/abs/1812.09257)].
- <span id="page-106-10"></span>[47] J. Gomis and F. Passerini, Holographic Wilson Loops, JHEP 08 (2006) 074, [[hep-th/0604007](http://arxiv.org/abs/hep-th/0604007)].
- <span id="page-106-11"></span>[48] E. Witten, Analytic Continuation Of Chern-Simons Theory, AMS/IP Stud. Adv. Math. 50 (2011) 347–446, [[arXiv:1001.2933](http://arxiv.org/abs/1001.2933)].
- <span id="page-106-12"></span>[49] D. Gaiotto, S-duality of boundary conditions and the geometric Langlands program., Proc. Symp. Pure Math. 98 (2018) 139–180, [[arXiv:1609.09030](http://arxiv.org/abs/1609.09030)].
- <span id="page-106-13"></span>[50] E. Witten, More On Gauge Theory And Geometric Langlands, [arXiv:1506.04293](http://arxiv.org/abs/1506.04293).
- <span id="page-106-14"></span>[51] M. Kontsevich and Y. Soibelman, Holomorphic Floer theory I: exponential integrals in finite and infinite dimensions, [arXiv:2402.07343](http://arxiv.org/abs/2402.07343).
- <span id="page-106-15"></span>[52] T. Dimofte, D. Gaiotto, and S. Gukov, Gauge Theories Labelled by Three-Manifolds, Commun. Math. Phys. 325 (2014) 367–419, [[arXiv:1108.4389](http://arxiv.org/abs/1108.4389)].
- [53] T. Dimofte, D. Gaiotto, and S. Gukov, 3-Manifolds and 3d Indices, Adv. Theor. Math. Phys. 17 (2013), no. 5 975–1076, [[arXiv:1112.5179](http://arxiv.org/abs/1112.5179)].
- <span id="page-106-16"></span>[54] T. Dimofte, M. Gabella, and A. B. Goncharov, K-Decompositions and 3d Gauge Theories, JHEP 11 (2016) 151, [[arXiv:1301.0192](http://arxiv.org/abs/1301.0192)].

- <span id="page-107-0"></span>[55] M. Aganagic, K. Costello, J. McNamara, and C. Vafa, Topological Chern-Simons/Matter Theories, [arXiv:1706.09977](http://arxiv.org/abs/1706.09977).
- <span id="page-107-1"></span>[56] K. Costello, T. Dimofte, and D. Gaiotto, Boundary Chiral Algebras and Holomorphic Twists, Commun. Math. Phys. 399 (2023), no. 2 1203–1290, [[arXiv:2005.00083](http://arxiv.org/abs/2005.00083)].
- <span id="page-107-2"></span>[57] T. Ekholm and V. Shende, Colored HOMFLYPT counts holomorphic curves, [arXiv:2101.00619](http://arxiv.org/abs/2101.00619).
- <span id="page-107-3"></span>[58] T. Ekholm, P. Longhi, and L. Nakamura, The worldsheet skein D-module and basic curves on Lagrangian fillings of the Hopf link conormal, [arXiv:2407.09836](http://arxiv.org/abs/2407.09836).
- <span id="page-107-4"></span>[59] D. Gaiotto and J. H. Lee, The giant graviton expansion, JHEP 08 (2024) 025, [[arXiv:2109.02545](http://arxiv.org/abs/2109.02545)].
- <span id="page-107-5"></span>[60] D. Gaiotto and E. Witten, S-Duality of Boundary Conditions In N=4 Super Yang-Mills Theory, Adv. Theor. Math. Phys. 13 (2009), no. 3 721–896, [[arXiv:0807.3720](http://arxiv.org/abs/0807.3720)].
- <span id="page-107-6"></span>[61] J. Yagi, Ω-deformation and quantization, JHEP 08 (2014) 112, [[arXiv:1405.6714](http://arxiv.org/abs/1405.6714)].
- <span id="page-107-7"></span>[62] M. Bullimore, T. Dimofte, and D. Gaiotto, The Coulomb Branch of 3d N = 4 Theories, Commun. Math. Phys. 354 (2017), no. 2 671–751, [[arXiv:1503.04817](http://arxiv.org/abs/1503.04817)].
- [63] A. Braverman, M. Finkelberg, and H. Nakajima, Towards a mathematical definition of Coulomb branches of 3-dimensional N = 4 gauge theories, II, Adv. Theor. Math. Phys. 22 (2018) 1071–1147, [[arXiv:1601.03586](http://arxiv.org/abs/1601.03586)].
- <span id="page-107-8"></span>[64] A. Braverman, M. Finkelberg, and H. Nakajima, Coulomb branches of 3d N = 4 quiver gauge theories and slices in the affine Grassmannian, Adv. Theor. Math. Phys. 23 (2019) 75–166, [[arXiv:1604.03625](http://arxiv.org/abs/1604.03625)].
- <span id="page-107-9"></span>[65] E. Witten, Solutions of four-dimensional field theories via M-theory, Nucl. Phys. B 500 (1997) 3–42, [[hep-th/9703166](http://arxiv.org/abs/hep-th/9703166)].
- [66] D. Gaiotto, G. W. Moore, and A. Neitzke, Wall-crossing, Hitchin systems, and the WKB approximation, Adv. Math. 234 (2013) 239–403, [[arXiv:0907.3987](http://arxiv.org/abs/0907.3987)].
- <span id="page-107-10"></span>[67] D. Gaiotto, N=2 dualities, JHEP 08 (2012) 034, [[arXiv:0904.2715](http://arxiv.org/abs/0904.2715)].
- <span id="page-107-11"></span>[68] A. Hanany and E. Witten, Type IIB superstrings, BPS monopoles, and three-dimensional gauge dynamics, Nucl. Phys. B 492 (1997) 152–190, [[hep-th/9611230](http://arxiv.org/abs/hep-th/9611230)].
- <span id="page-107-12"></span>[69] M. Bullimore, T. Dimofte, D. Gaiotto, and J. Hilburn, Boundaries, Mirror Symmetry, and Symplectic Duality in 3d N = 4 Gauge Theory, JHEP 10 (2016) 108, [[arXiv:1603.08382](http://arxiv.org/abs/1603.08382)].
- <span id="page-107-13"></span>[70] K. Kawagoe, The colored HOMFLY-PT polynomials of the trefoil knot, the figure-eight knot and twist knots, [arXiv:2107.08678](http://arxiv.org/abs/2107.08678).