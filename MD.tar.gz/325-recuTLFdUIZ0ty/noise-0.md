# Categorical 't Hooft expansion and chiral algebras

Davide Gaiotto,<sup>1</sup> Adri´an L´opez-Raven,<sup>1</sup>,<sup>2</sup> Hanne Silverans,<sup>1</sup>,<sup>2</sup> Keyou Zeng<sup>1</sup>,<sup>3</sup>

Abstract: Twisted holography captures protected aspects of well-known holographic dualities. We show how an holographic dual B-model background can be systematically derived from the 't Hooft expansion of the chiral algebras associated to fourdimensional N = 2 superconformal quiver gauge theories. A crucial tool is the match of planar BRST anomalies in the field theory and on the worldsheet, especially in the presence of probe D-branes. Our construction is very general and can be applied to chiral algebras which do not have a four-dimensional origin. The resulting holographic dual backgrounds are typically non-geometric and appear to be novel. We expect our strategy to have a wide range of applications to other examples of twisted holography and, potentially, weak coupling holography.

<sup>1</sup>Perimeter Institute for Theoretical Physics, Waterloo, ON N2L 2Y5, Canada

<sup>2</sup>Department of Physics & Astronomy, University of Waterloo, Waterloo, ON N2L 3G1, Canada

<sup>3</sup>Center of Mathematical Sciences and Applications, Harvard University, Massachusetts 02138, USA

### Contents

| 1 | Introduction                        |                                                                       |    |
|---|-------------------------------------|-----------------------------------------------------------------------|----|
|   | 1.1                                 | Homological Algebra and Beyond                                        | 5  |
|   | 1.2                                 | A fundamental enhancement                                             | 8  |
|   | 1.3                                 | Summary of main results                                               | 9  |
|   | 1.4                                 | Structure of the paper                                                | 10 |
| 2 | A rich example                      |                                                                       |    |
|   | 2.1                                 | The chiral algebra                                                    | 12 |
|   | 2.2                                 | Single-trace Local Operators and the Planar Limit                     | 14 |
|   | 2.3                                 | Single-trace BRST cohomology                                          | 16 |
|   | 2.4                                 | The Global Symmetry Algebra of sphere correlation functions           | 18 |
|   | 2.5                                 | Fundamental matter and space-filling branes                           | 21 |
|   | 2.6                                 | Mesonic GSA                                                           | 22 |
|   | 2.7                                 | Open vs Closed                                                        | 23 |
|   | 2.8                                 | Determinant operators                                                 | 24 |
|   | 2.9                                 | Determinant modifications                                             | 27 |
|   |                                     | 2.10 Open Modifications                                               | 30 |
|   |                                     | 2.11 Conclusions                                                      | 32 |
| 3 | Homological algebra and the B-model |                                                                       |    |
|   | 3.1                                 | C<br>The B-model with target                                          | 33 |
|   | 3.2                                 | Distributional local operators                                        | 35 |
|   | 3.3                                 | C<br>Boundary conditions in the B-model with target                   | 35 |
|   | 3.4                                 | Disc correlation functions                                            | 36 |
|   | 3.5                                 | Homological algebra and dg-TFT                                        | 37 |
|   | 3.6                                 | Bulk local operators as symmetries/deformations of the boundary data. | 37 |
|   | 3.7                                 | Hochschild cohomology and Dirichlet boundary conditions               | 40 |
|   | 3.8                                 | Hochschild cohomology and Neumann boundary conditions                 | 40 |
|   | 3.9                                 | Disc correlation functions and HH•<br>(A, A∨<br>)                     | 41 |
|   |                                     | 3.10 Equivariant bulk local operators and HC•<br>(A)                  | 42 |
|   |                                     | 3.11 Branes, modules and tensor products                              | 43 |
|   |                                     | 3.12 B-model probe branes                                             | 43 |
|   |                                     | C<br>n<br>3.13 B-model on                                             | 44 |
|   |                                     | C<br>2/Γ<br>3.14 B-model with target                                  | 45 |

| 4                                                |                                                     | Homological algebra in the<br>λ<br>→<br>0<br>limit.               | 47 |  |
|--------------------------------------------------|-----------------------------------------------------|-------------------------------------------------------------------|----|--|
|                                                  | 4.1                                                 | The Global Symmetry Algebra at tree-level                         | 49 |  |
|                                                  | 4.2                                                 | →<br>The mesons at<br>λ<br>0.                                     | 50 |  |
|                                                  | 4.3                                                 | →<br>Determinants at<br>λ<br>0.                                   | 51 |  |
| 5                                                | Two-dimensional chiral gauge theories at large<br>N |                                                                   | 52 |  |
|                                                  | 5.1                                                 | The large<br>N<br>expansion of 2d chiral gauge theories           | 53 |  |
|                                                  | 5.2                                                 | A hidden algebra                                                  | 54 |  |
|                                                  | 5.3                                                 | An algebra structure from the BRST differential                   | 56 |  |
|                                                  | 5.4                                                 | C<br>3<br>Back to                                                 | 57 |  |
|                                                  | 5.5                                                 | The ADE chiral algebra and the B-model                            | 57 |  |
|                                                  | 5.6                                                 | A small generalization                                            | 58 |  |
|                                                  | 5.7                                                 | Algebras and branes                                               | 58 |  |
| 6                                                | Local operators at tree level and cyclic cohomology |                                                                   | 59 |  |
|                                                  | 6.1                                                 | The first tower                                                   | 59 |  |
|                                                  | 6.2                                                 | The second tower                                                  | 60 |  |
|                                                  | 6.3                                                 | Operators with any number of derivatives                          | 63 |  |
|                                                  | 6.4                                                 | A cohomology computation                                          | 64 |  |
|                                                  | 6.5                                                 | A tree-level holographic dictionary for local operators           | 66 |  |
| 7                                                | The global symmetry algebra                         |                                                                   | 67 |  |
|                                                  | 7.1                                                 | The mode algebra                                                  | 69 |  |
|                                                  | 7.2                                                 | CP<br>1<br>Polyvector fields on                                   | 70 |  |
|                                                  | 7.3                                                 | The action of general local operators                             | 71 |  |
|                                                  | 7.4                                                 | A conformal-invariant presentation of the global symmetry algebra | 71 |  |
| 8                                                | Tree Level Flavour                                  |                                                                   | 73 |  |
|                                                  | 8.1                                                 | Mesonic local operators                                           | 73 |  |
|                                                  | 8.2                                                 | Space-filling probe branes                                        | 74 |  |
|                                                  | 8.3                                                 | Open symmetry algebra                                             | 75 |  |
| 9                                                | Determinant-like local operators                    |                                                                   | 76 |  |
|                                                  | 9.1                                                 | A BV algebra of mesons                                            | 77 |  |
|                                                  | 9.2                                                 | Open modifications                                                | 77 |  |
| 10 A non-commutative example at tree-level<br>77 |                                                     |                                                                   |    |  |

| 11           | Categorical Back-reaction                                            | 81  |  |
|--------------|----------------------------------------------------------------------|-----|--|
|              | 11.1 Adding (anti)fundamental chiral fields                          | 82  |  |
|              | 11.2 Tree level                                                      | 82  |  |
|              | 11.3 Planar transformations                                          | 84  |  |
|              | 11.4 Modules                                                         | 85  |  |
|              | 11.5 Planar modules                                                  | 86  |  |
| 12           | The Planar global symmetry algebra                                   | 87  |  |
|              | 12.1 The planar mode algebra                                         | 88  |  |
|              | 12.2 The planar fundamental algebra                                  | 88  |  |
| 13           | The non-commutative algebra at planar level                          | 89  |  |
|              | 13.1 The global algebra of meson modes.                              | 89  |  |
|              | 13.2 Single traces                                                   | 93  |  |
|              | 13.3 Determinants and modules                                        | 95  |  |
| 14           | Conclusion and open questions                                        | 96  |  |
| $\mathbf{A}$ | The Planar Mode Action: An Expression for the Contour Integral       | 98  |  |
| В            | Cyclic cohomology of a weighted algebra                              | 100 |  |
| $\mathbf{C}$ | Global symmetry algebra                                              | 101 |  |
| D            | Calabi-Yau algebra                                                   | 103 |  |
| ${f E}$      | A lightning review of Maurer-Cartan equations and BRST anomalies 105 |     |  |
| $\mathbf{F}$ | Non-commutative Algebra From OPEs                                    | 106 |  |
|              | F.1 A useful Q-exact relation                                        | 106 |  |
|              | F.2 $u_{n_1}^{a_1} \cdot u_{n_2}^{a_2}$ from OPEs                    | 106 |  |
|              | F.3 $u_{n_1 n_2}^{a_1 a_2} \cdot u_{n_3}^{a_3}$ from OPEs            | 108 |  |
| $\mathbf{G}$ | Generalizing to Symmetric and Anti-symmetric matrices                | 111 |  |
|              |                                                                      |     |  |

### Notation

| λ                                   | 't Hooft coupling                                        |
|-------------------------------------|----------------------------------------------------------|
| CC•<br>(A)                          | Connes' complex for the cyclic cohomology of<br>A        |
| HC•<br>(A)                          | cyclic cohomology of<br>A                                |
| CH•<br>(A, M)                       | Hochschild cochain complex of<br>A<br>valued in<br>M     |
| HH•<br>(A, M)                       | Hochschild cohomology of<br>A<br>valued in<br>M          |
| HH•<br>HC•<br>(A),<br>(A)<br>λ<br>λ | deformed Hochschild and cyclic cohomology                |
| Q<br>or<br>QBRST                    | full BRST differential                                   |
| Q0                                  | tree-level part of the BRST differential                 |
| ℏQ1                                 | 1-loop part of the BRST differential                     |
| λQl<br>1                            | linear (in<br>λ) part of the 1-loop BRST differential    |
| Aa,b,<br>Ba,b,<br>Ca,b,<br>Da,b     | four towers of single trace operators                    |
| Lλ                                  | global symmetry algebra of single-trace operators        |
| Pλ                                  | global symmetry algebra of mesonic operators             |
| Dλ                                  | global symmetry algebra of determinant operators         |
| Mλ                                  | bi-module associated to open determinant modifications   |
| L0,<br>P0,<br>D0,M0                 | →<br>tree-level limit (λ<br>0) of<br>Lλ,<br>Pλ,<br>Dλ,Mλ |
| BH•,•<br>(V, Q)                     | planar global symmetry algebra                           |
| PModV                               | category of planar<br>V<br>-modules                      |
| ⊗A                                  | ⊗L<br>will denote the derived tensor product<br>A        |

### <span id="page-5-0"></span>1 Introduction

Certain families of gauge theories with classical gauge groups admit a 't Hooft expansion [\[1\]](#page-117-0): a reorganization of the perturbative expansion where the rank N of the gauge group is treated as being of order ℏ −1 . The resulting expansion is in many way analogous to the genus expansion of a String Theory. In particular, it naturally includes the analogue of D-branes and open string sectors associated to pairs of D-branes.

The 't Hooft expansion is key to the holographic dictionary whenever the gravitational side of the duality involves String Theory [\[2,](#page-117-1) [3\]](#page-117-2). Standard weakly-curved tendimensional String Theories emerge at large values of the 't Hooft coupling λ ≡ ℏN. The duality is still expected to hold at small λ, but the dual String Theory background is strongly curved or perhaps non-geometric, i.e. described by a world-sheet theory which is not a sigma-model [\[4–](#page-117-3)[8,](#page-117-4) [8](#page-117-4)[–14\]](#page-118-0).

This "weak coupling" regime in holography is of great interest but poorly understood. More generally, our inability to define non-geometric String Theory backgrounds hampers many potential applications of the 't Hooft expansion, such as the formulation of a String Theory dual to SU(N) Yang-Mills theory.[1](#page-5-1)

A priori, it is not known if a generic quantum field theory which admits a 't Hooft expansion should always admit a String Theory dual description, in the sense of a specific world-sheet theory whose genus expansion matches the t'Hooft expansion of the QFT, with boundary conditions matching all possible D-brane-like objects in the QFT.

We would like to conjecture that this is indeed the case, and furthermore that there is a systematic way to translate the QFT data into the definition of a worldsheet theory. This conjecture is certainly implicit in much work on String Theory and holography, but we think it deserves an explicit formulation. We will refer to it as the conjecture that String Theory is "'t Hooft complete".[2](#page-5-2)

The notion of 't Hooft completeness poses a conceptual challenge: it requires the existence of world-sheet theories which can systematically reproduce the infinite variety of Feynman diagram expansions which may occur in large N QFTs. There have been several attempts to do so for specific theories [\[8,](#page-117-4) [15–](#page-118-1)[19\]](#page-118-2), sometimes with partial success, but no general prescription is known.

<span id="page-5-1"></span><sup>1</sup>Note that non-geometric backgrounds pose two challenges. The obvious one is to define a worldsheet theory for the String Theory. A more subtle one is to address IR divergences of String Theory without the guidance of a low energy effective QFT description in the target space.

<span id="page-5-2"></span><sup>2</sup>One could perhaps distinguish a strong and weak forms of the conjecture, requiring the λ expansion to always converge or allowing perturbative-in-λ constructions.

Typically, the constructions rely on a conformal gauge perspective: the worldsheet theory is described as the BRST reduction of a 2d CFT coupled to a ghost system. We suspect that this assumption may be problematic. At the very least, we find it hard to imagine how the combinatorial data of the Feynman diagrams could be universally reorganized into the data of 2d CFTs.

Strictly speaking, the standard String Theory formalism only requires the worldsheet theory to be a "dg-TQFT", i.e. a quantum field theory whose stress-tensor is BRST-exact (sometimes denoted as CohFT) [\[20\]](#page-118-3). Via descent relations, such a dg-TQFT can be used to define integrands for a consistent collection of String Theory amplitudes.[3](#page-6-0)

Unitary, non-cohomological TQFTs such as 3d Chern-Simons theory often admit alternative algebraic/categorical definitions which dispense with local degrees of freedom. For conciseness, we will refer to such definitions as "TFTs". The algebraic and categorical structures which can occur in a dg-TQFTs are more intricate and mathematically very rich, but a "dg-TFT" description or definition is still possible using tools from Homological Algebra [\[21–](#page-118-4)[25\]](#page-118-5).

A general theme in TFT is that a theory which admits a topological boundary condition can be (re)constructed from data associated to the boundary condition alone. For example, a 3d Turaev-Viro TFT [\[26,](#page-119-0) [27\]](#page-119-1) can be presented by giving a fusion category of boundary lines.

Crucially, 2d dg-TFT can be associated to an (A∞) category of dg-topological boundary conditions, aka D-branes [\[22\]](#page-118-6). For example, the B-model [\[28,](#page-119-2) [29\]](#page-119-3) with a target space X is associated to the derived category of coherent sheaves on X [\[30\]](#page-119-4). More general dg-categories have been proposed as descriptions of "non-commutative" target spaces or, more precisely, non-geometric 2d dg-TQFTs [\[31–](#page-119-5)[33\]](#page-119-6).

This suggests a general strategy: use the 't Hooft expansion of the QFT to build the category of D-branes for the conjectural dual String Theory and use that category to define or at least constrain the corresponding worldsheet theory as a dg-TFT. Such a construction may potentially lead to a universal dictionary for weak-coupling holography.

As a cautionary note, we should recall that IR divergences plague the integrals which define actual String Theory amplitudes. In Topological String Theory, it is not uncommon for important contributions to be pushed to the boundary of the integration region [\[34,](#page-119-7) [35\]](#page-119-8). A universal combinatorial description of the world-sheet correlation functions and integrands is thus not enough: we also need a universal combinatorial

<span id="page-6-0"></span><sup>3</sup>Assuming that a prescription can be found to deal with "IR" divergences from the boundaries of the integration region.

treatment of the IR divergences. In this paper we will focus on the planar (ℏ → 0) limit of the 't Hooft expansion and on the construction of a classical String Theory dual theory, which allows us to mostly ignore this aspect.

One of the main objectives of this paper is to test 't Hooft-completeness of String Theory in the context of two-dimensional chiral gauge theories, generalizing examples which arise as protected sub-sectors of four-dimensional N = 2 Superconformal Gauge Theories [\[36\]](#page-119-9).

In particular, we will learn how to build categories of D-branes from the 't Hooft expansion data, which in known twisted holography examples [\[37\]](#page-119-10) match the coherent sheaves in the dual B-model geometries. For general 2d chiral gauge theories, the resulting categories define novel dual non-commutative three-dimensional Calabi-Yau geometries.

Schematically, we show that any 2d chiral gauge theory which admits a 't Hooft expansion can always be associated to a "two-dimensional non-commutative (nc) Calabi Yau cone" X2. The cone can be promoted to a 3d nc Calabi-Yau geometry in the form of a fibration

$$X_3(0) \equiv X_2(-1) \to \mathbb{C}P^1$$
. (1.1)

A geometric transition gives a family of 3d nc Calabi-Yau geometries X3(λ) depending on the 't Hooft coupling λ. Intuitively, X<sup>2</sup> is a cone over a non-geometric "space" X2/R akin to S 3 , and X3(λ) is schematically AdS<sup>3</sup> × X2/R.

We claim that the 't Hooft expansion of the 2d chiral gauge theory matches Topological String Theory with target X3(λ). The nc-CY geometries are encoded in 3d Calabi-Yau dg-categories with a direct QFT definition.

#### <span id="page-7-0"></span>1.1 Homological Algebra and Beyond

A general principle of String Theory is that the classical equations of motion of the theory controls the deformations of the world-sheet theory (for closed strings) and of its boundary conditions (for open strings). In particular, the closed string fields are identified as worldsheet couplings and open string fields as (possibly matrix-valued) boundary couplings. See [\[38\]](#page-119-11) for a recent related discussion.

In the BRST/BV formalism for the world-sheet theory, the string-theory equations of motion can be concisely formulated as the cancellation of the BRST anomalies created by formal deformations of the theory [\[39\]](#page-119-12) or boundary conditions [\[40,](#page-119-13) [41\]](#page-119-14). This formulation naturally involves the language of Homological Algebra. In particular, the BRST anomalies which arise from matrix-valued deformations of boundary conditions are encoded in an A<sup>∞</sup> category of boundary conditions [\[42\]](#page-119-15).

![](_page_8_Picture_0.jpeg)

Figure 1. Top row: canonical twisted holography example, connecting a 2d gauged βγ system supported on a stack of D-branes and B-model topological strings on SL(2, C) [\[37\]](#page-119-10). Bottom row: generalization studied in this paper, connecting general 2d chiral algebras supported on branes in a 2d nc-CY cone target space and topological strings on a 3d nc-CY geometry.

We will use BRST anomalies as a guiding principle to analyze the 't Hooft expansion of the QFT. We can consider a deformation of the QFT by single-trace operators and of D-brane-like objects by mesonic operators. At the planar level, the cancellation of BRST anomalies produced by the deformations can be interpreted as the equations of motions of the tentative dual String Theory. In particular, this gives us a candidate A<sup>∞</sup> category of boundary conditions for the dual world-sheet theory.

We can describe briefly the "planar tree-level" λ → 0 limit of the general analysis.

A simple example is the computation of the space of gauge-invariant single trace local operators in the QFT. Concretely, a single-trace operator is some linear combination of terms of the form <sup>1</sup>

ℏ Tr ϕ i1 · · · ϕ in , (1.2)

where ϕ <sup>i</sup> denotes a collection of "letters" which can enter in the trace: fields in twoindex representations of the large N gauge group and their derivatives.

The planar BRST differential acts at the leading order in λ by replacing a letter by a sequence of letters:

$$Q: \qquad \phi^{i} \to Q^{i}_{j} \phi^{j} + Q^{i}_{j_{1}j_{2}} \phi^{j_{1}} \phi^{j_{2}} + \cdots$$
 (1.3)

Essentially by definition, a nilpotent transformation of this kind equips a dual space V of symbols v<sup>i</sup> with the structure of an A<sup>∞</sup> algebra.

If the QFT arises as the world-volume theory of some D-branes B in a formal λ → 0 limit, V controls boundary local operators on B and the BRST anomalies of matrix-valued deformations

$$\int_{\partial} \phi^i O_i^{\partial} \,, \tag{1.4}$$

of the direct sum of multiple (N) copies of B by boundary local operators O<sup>∂</sup> i .

In this language, the BRST cohomology of the space of single-trace operators is recognized as the cyclic cohomology HC• (V ) of V . This mathematical structure occurs naturally in the study of dg-TFTs, precisely as a tool to probe the coupling of closed string states to a dg-topological boundary condition via a disk worldsheet [\[43\]](#page-120-0). As a consequence, the λ → 0 limit of the holographic dictionary between single-trace operators and closed string states in a dg-TFT description is universal and essentially tautological.

Symmetries of the large N QFT can also be described at the leading planar level as transformations

$$L: \qquad \phi^{i} \to L^{i}_{j}\phi^{j} + L^{i}_{j_{1}j_{2}}\phi^{j_{1}}\phi^{j_{2}} + \cdots$$
 (1.5)

which commute with Q. Parsing through the definition, one can make contact with the Hochschild cohomology HH• (V ), which also describes the symmetries of the worldsheet theory in a dg-TFT language. The λ → 0 limit of the holographic dictionary for symmetries (and their action on operators) is thus also universal and tautological.

A simple and powerful slogan is that any gauge theory with a single-trace action can be interpreted classically as the world-volume theory of N D-branes B in a formal String Theory background with a dg-TFT description for the world-sheet theory.

Beyond the leading order in the planar expansion, both the action of Q and the action of symmetries on single-trace operators are deformed by terms which act on multiple consecutive letters at the time. These terms do not fit into a standard Homological Algebra dictionary.

Nevertheless, the planar corrections can be systematically organized in the form of a deformation HC• λ (V ) and HH• λ (V ) of the complexes defining HC• (V ) and HH• (V ), leading to a formal definition of the space of closed string states and of symmetries of a λ-dependent dg-TFT.

In order to produce a standard dg-TFT description of the deformed world-sheet theory, we need to express HC• λ (V ) and HH• λ (V ) as standard cyclic and Hochschild cohomology for some other algebraic object. We will do so with the help of D-branes.

#### <span id="page-10-0"></span>1.2 A fundamental enhancement

Any large N QFT can be modified in many different ways by adding some collection of fields transforming in vector representations of the large N gauge group. We will consider many types of D-brane probes, some arising from fundamental fields defined on the whole QFT space-time and some supported at defects. All of these modifications are expected to lead to the same closed String Theory dual, modified by some appropriate collection of probe D-branes.

In the λ → 0 limit, certain calculations organize themselves in a natural way as dg-TFT data. The first example is the computation of gauge-invariant linear combinations of mesonic operators:

<span id="page-10-2"></span><span id="page-10-1"></span>
$$\alpha^a \phi^{i_1} \cdots \phi^{i_n} \beta^b \tag{1.6}$$

where the α <sup>a</sup> and β b letters denote fields with a single gauge index and their derivatives.

The planar BRST differential acts at the leading order in λ by replacing a letter by a sequence of letters. The action on ϕ i is unchanged, but we have

$$Q: \qquad \alpha^{a} \to Q_{a'}^{a} \alpha^{a'} + Q_{a'j}^{a} \alpha^{a'} \phi^{j} + \cdots$$

$$Q: \qquad \beta^{b} \to Q_{b'}^{b} \beta^{b'} + Q_{jb'}^{b} \phi^{j} \beta^{b'} + \cdots$$

$$(1.7)$$

Essentially by definition, a nilpotent transformation of this kind equips dual spaces U and W with the structure of a right- or a left- A<sup>∞</sup> module for V .

This is the same mathematical structure as would arise in a dg-TFT to describe the interaction of B with a probe brane P0: U = Hom(B, P0) describes junctions from B to P<sup>0</sup> and W = Hom(P0, B) describes junctions from P<sup>0</sup> to B. The space of mesonic operators turns out to be dual to the derived tensor product U ⊗<sup>V</sup> W. We can check immediately that the space of operators [1.6,](#page-10-1) subject to the BRST differential [1.7,](#page-10-2) reproduces the standard bar construction of the derived tensor product U ⊗<sup>V</sup> W.

As a consequence, the λ → 0 limit of the holographic dictionary between mesonic operators and open string states in a dg-TFT description is universal and tautological. Symmetries of open strings are also nicely reproduced as endomorphisms of U and W as A<sup>∞</sup> V -modules.

As we vary and combine different choices of D-brane-like modifications, the resulting data can be assembled into a dg-category of V -modules which describes the λ → 0 limit of the category of branes of the conjectural dual String Theory. In other words, any consistent recipe to add (anti)fundamental fields via mesonic terms in the gauge-theory action can be classically understood as adding formal probe branes in the formal dg-TFT description.

Beyond the leading order, the planar corrections to these calculations can be systematically organized as a deformation Modλ(V ) of the category of V -modules, leading to a formal definition of the category of branes for a λ-dependent, back-reacted dual world-sheet theory. In particular, one finds that HH• λ (V ) acts as a symmetry of Modλ(V ) and HC• λ (V ) couples to it.

This category gives the desired dg-TFT description of the holographic dual String Theory, at least classically. Once the planar expansion has been organized in this categorical language, we arrive at a weakly-coupled holographic statement which involves two mathematically well-defined entities: the planar expansion of the QFT and the classical String Theory described by the back-reacted category Modλ(V ) of probe D-branes.

We expect that the identification between the two sides may be formulated as a rigorous theorem of broad applicability. Once the classical holographic statement has been proven, one may tackle the greater challenge of matching the full ℏ expansion. We will only briefly discuss the structure of that problem.

#### <span id="page-11-0"></span>1.3 Summary of main results

For families of two dimensional chiral gauge theories in the planar limit, we construct the following data of the putative worldsheet dual:

- We express the data of a 2d chiral gauge theory in terms of a 2d-cyclic, finitedimensional, graded associative super-algebra A. This formally defines a worldsheet theory with target X<sup>2</sup> such that the 2d theory is the world-volume theory of N D-branes supported on C ⊂ X<sup>2</sup> × C.
- We compute the tree-level cohomology of single-trace operators, as well as the "wedge" subalgebra of global symmetries on the sphere, in terms of the Hochschild and cyclic cohomology of A. This establishes the classical couplings between the original D-branes and closed strings.

- Using 2d chiral fundamental matter as a probe, we compute the tree-level cohomology of mesons and associated global symmetries in homological algebra terms and describe their planar deformation. We compute the deformation explicitly for a novel non-geometric example of Twisted Holography. These computations give a formal world-sheet description for space-filling probe D-branes in the backreacted geometry X3(λ). We expect the category of D-branes in X3(λ) to admit a description as a category of modules for the global symmetry algebra of spacefilling D-branes.
- Using determinant operators as a probe, we compute the tree-level cohomology of "determinant modifications" and describe their planar deformation. The action of the above global symmetry algebras on determinant modifications provides a description of the dual D-branes as modules. We compute the action explicitly in the non-geometric example.

An important assumption we make about string theory is its 't Hooft completeness, introduced at the beginning of the introduction. In other words, we do not know a priori whether the 't Hooft expansion of a chiral gauge theory is fully captured by a dual string theory; rather, we take this as a working assumption and demonstrate how the algebraic/categorical data of a 2d dg-TFT can be reconstructed.

Finally, we emphasize that we do not provide the dual worldsheet theory data in the "conventional" sense; we give no lagrangian for the dual worldsheet theory, much less a 2d CFT. Instead, we hope that by showcasing how dg TFT data captures universal features of the dual worldsheet in the form of algebraic dg-TFT data, we inspire a more general, albeit more abstract [\[22,](#page-118-6) [32,](#page-119-16) [33,](#page-119-6) [44–](#page-120-1)[46\]](#page-120-2), means of defining the dual String Theory for theories with a 't Hooft expansion.

#### <span id="page-12-0"></span>1.4 Structure of the paper

Section [2](#page-13-0) reviews the standard example of Twisted Holography for chiral algebras, a protected subsector of N = 4 SYM. Section [3](#page-35-0) reviews the Homological Algebra presentation of the B-model with flat target space. Section [4](#page-49-0) reviews and extends Homological Algebra calculations in the λ → 0 limit. Section [5](#page-54-0) introduces a general class of chiral gauge theories admitting a 't Hooft expansion and associates them to 2d Calabi-Yau algebras and dg-TFTs. Section [6](#page-61-0) introduces algebraic structures associated to single-trace operators. Section [7](#page-69-0) reviews and improves the notion of Global Symmetry Algebra of a chiral algebra. Section [8](#page-75-0) adds fundamental matter and algebraic structures associated to mesonic operators, including the analogue of the algebra of holomorphic functions on X3[0]. Section [9](#page-78-0) studies determinant-like operators and associated D-branes in an algebraic language. Section [10](#page-79-2) introduces the simplest noncommutative example. Section [11](#page-83-0) discusses in greater detail the structure of planar corrections. Section [12](#page-89-0) discusses explicit planar corrections various algebraic structures, including the algebra of holomorphic functions on X3[λ]. Section [13](#page-91-0) computes planar corrections and describes X3[λ] in the simplest non-commutative example. Section [14](#page-98-0) reviews our conclusions and presents various open questions.

## <span id="page-13-0"></span>2 A rich example

In this section, we will focus on the holographic duality studied in [\[37\]](#page-119-10), relating:

- The protected chiral algebra subsector of four-dimensional N = 4 SU(N) Supersymmetric Yang Mills theory [\[36\]](#page-119-9), aka supersymmetric chiral SU(N) gauge theory.
- The B-model topological string theory/BCOV theory [\[34,](#page-119-7) [47,](#page-120-3) [48\]](#page-120-4) with target SL(2, C). This theory is also conjectured to be a twist of the type IIB supergravity on AdS<sup>5</sup> × S 5 [\[49\]](#page-120-5).

We will review and extend the known holographic dictionary, including

- The match of single-trace operators and closed strings states, as well as the associated "global symmetry algebra" L<sup>λ</sup> [\[37\]](#page-119-10).
- The match of mesonic operators and open strings states associated to space-filling branes, as well as the associated "global symmetry algebra" P<sup>λ</sup> [\[37\]](#page-119-10). This algebra can also be identified with the algebra of functions on the backreacted geometry, thereby reproducing the category of D-branes as the category of Pλ-modules.
- The match of planar determinant correlation functions and "giant graviton" Dbranes [\[50\]](#page-120-6).

In each case, we will illustrate how algebraic aspects of the string worldsheet theory emerge from planar calculations in the chiral algebra. A summary of the relationship will be given in Section [2.11.](#page-34-0) The strategy will naturally generalize to known and novel examples of chiral algebras which admit a large N expansion. We will introduce our general construction of chiral algebra based on Calabi-Yau algebra/category in Section [5.](#page-54-0) The construction of the global symmetry algebra L<sup>λ</sup> will be generalized in Section [7.](#page-69-0) We will also discuss the global symmetry algebra P<sup>λ</sup> of mesonic operators in this generalized framework in Section [8,](#page-75-0) and the determinant modification in Section [9.](#page-78-0)

This Section is designed to give a review of known results [37, 50] in the standard example of Twisted Holography. The presentation anticipates some of the ideas and naming conventions introduced in the rest of the paper and in particular the homological algebra framework reviewed at greater length in Section 6. At the very end of the Section, we re-derive the "saddle equations" controlling the large N limit of determinant operators as a BRST anomaly cancellation and as the definition of a module for the global symmetry algebra of space-filling D-branes.

#### <span id="page-14-0"></span>2.1 The chiral algebra

The chiral algebra subsector of 4d SYM can be presented as a chiral 2d gauge theory, with action

$$\frac{1}{\hbar} \int d^2 z \operatorname{Tr} X(\bar{\partial} Y + [a_{\bar{z}}, Y]) \tag{2.1}$$

involving two adjoint bosonic fields X, Y of scaling dimension  $\frac{1}{2}$  and the (0,1) component  $a_{\bar{z}}$  of a 2d gauge connection. The overall factor of  $\hbar^{-1}$  will be helpful in setting up the 't Hooft expansion.

The  $a_{\bar{z}}$  connection can be gauge-fixed to 0, at least locally. The gauge-fixing introduces a set of bc ghosts which also transform in the adjoint representation of the gauge group.

In the following we will work with U(N)-valued fields for notational simplicity. The difference between SU(N) and U(N) gauge theories is the presence of a decoupled free U(1) factor in the latter. It will not affect planar calculations. Keeping track of gauge indices, the OPE of all the fields is

$$Y_j^i(z)X_t^k(w) \sim \hbar \frac{\delta_t^i \delta_j^k}{z - w}$$

$$b_j^i(z)c_t^k(w) \sim \hbar \frac{\delta_t^i \delta_j^k}{z - w}.$$
(2.2)

We will typically leave gauge indices implicit and use matrix notation for the fields. The BRST differential is the zero mode of the BRST current:

<span id="page-14-2"></span>
$$Q = \frac{1}{\hbar} \oint \frac{dz}{2\pi i} \operatorname{Tr} \left( \frac{1}{2} b[c, c] + c[X, Y] \right). \tag{2.3}$$

Up to a small subtlety concerning the removal of ghost zero modes,<sup>4</sup> the local operators of the 2d gauge theory are defined as elements in the BRST cohomology  $\mathcal{A}_N$  of the 2d free chiral algebra defined by the above OPE.

<span id="page-14-1"></span><sup>&</sup>lt;sup>4</sup>The subtlety is that we should take a *relative* BRST cohomology: c should only appear through its derivatives and U(N) invariance should be imposed by hand. Doing otherwise adds to the cohomology some spurious elements built from c only. In correlation functions, one saturates c zero modes by hand.

The action of the BRST differential on local operators is the sum of two terms involving respectively one or two Wick contractions:

$$Q = Q_0 + \hbar Q_1. \tag{2.4}$$

We refer to these as the tree-level and 1-loop parts of the BRST differential. Notice that  $Q_0^2 = 0$ ,  $\{Q_0, Q_1\} = 0$  and  $Q_1^2 = 0$ .

The space  $\mathcal{A}_N$  of local operators is also a chiral algebra. The OPE is computed by free OPE of cohomology representatives, up to shifts by BRST-exact operators. Alternatively, we can first compute unambiguous sphere correlation functions of cohomology representatives and then derive the OPE from these. The sphere correlation functions and OPEs will be the main observable of interest in this paper.<sup>5</sup>

We should recall some special properties of this model which simplify our analysis but will not generalize to other examples. In particular, the conformal symmetry of the model is enhanced to a "small"  $\mathcal{N}=4$  super-conformal algebra<sup>6</sup> with BRST-closed generators which include

• The stress tensor

<span id="page-15-2"></span>
$$T \equiv \frac{1}{2\hbar} \text{Tr} \left( -2b\partial c - X\partial Y + Y\partial X \right) \tag{2.5}$$

with central charge  $-3N^2$ .

• Level  $-N^2$  Kac-Moody currents for an  $SU(2)_R$  symmetry transforming X and Y as a doublet:

$$J^{++} \equiv \frac{1}{2\hbar} \operatorname{Tr} X^2 \qquad \qquad J^0 \equiv \frac{1}{2\hbar} \operatorname{Tr} XY \qquad \qquad J^{--} \equiv \frac{1}{2\hbar} \operatorname{Tr} Y^2. \qquad (2.6)$$

• Four super-currents

$$G^{+} \equiv \frac{1}{2\hbar} \operatorname{Tr} X b \qquad \qquad \widetilde{G}^{+} \equiv \frac{1}{2\hbar} \operatorname{Tr} X \partial c$$

$$G^{-} \equiv \frac{1}{2\hbar} \operatorname{Tr} Y b \qquad \qquad \widetilde{G}^{-} \equiv \frac{1}{2\hbar} \operatorname{Tr} Y \partial c \,. \tag{2.7}$$

<span id="page-15-0"></span><sup>&</sup>lt;sup>5</sup>It is also possible to define and compute  $\mathcal{A}_N$  conformal blocks on general Riemann surfaces. An important subtlety is that  $a_{\bar{z}}$  can only be gauge-fixed to an holomorphic bundle and conformal blocks will involve integrals over the space of holomorphic bundles. The details of the large N expansion and the holographic duality will be more complicated.

<span id="page-15-1"></span><sup>&</sup>lt;sup>6</sup>The chiral algebra defined by the BRST cohomology of local operators also has an SL(2) global symmetry which acts on cohomology representatives roughly as  $b \leftrightarrow \partial c$ . It will not play a role in this paper.

Twisted Holography concerns the 't Hooft expansion of the SU(N) gauge theory correlation functions: we trade the rank N for a 't Hooft coupling  $\lambda \equiv \hbar N$  and expand in powers of  $\hbar$  at fixed  $\lambda$ .<sup>7</sup> The expansion in powers of  $\hbar$  is expected to match the genus expansion of the dual string theory, while  $\lambda$  controls the period of the holomorphic three-form in the  $SL(2,\mathbb{C})$  target space. We will mostly focus on the planar limit, dual to tree-level string theory calculations.

The identification of the dual theory as a B-model with  $SL(2,\mathbb{C})$  target space can be justified by realizing the chiral algebra as the world-volume theory of N D-branes wrapping  $\mathbb{C} \subset \mathbb{C}^3$  and computing the branes back-reaction in the BCOV description of the topological string theory. One of our objectives is to describe this back-reaction in an algebraic manner, which can be generalized to non-geometric situations.

#### <span id="page-16-0"></span>2.2 Single-trace Local Operators and the Planar Limit

Operators built from less than N fields can be organized into polynomials of single-trace operators. A sphere correlation function of such operators is computed as a sum over double-line free Feynman diagrams which may have multiple connected components, each with a specific genus.

If we normalize traces by an  $\hbar^{-1}$  prefactor, as we saw e.g. in the stress tensor (2.5), and express everythign in terms of the 't Hooft coupling  $\lambda$  and  $\hbar$  by substuting  $N = \frac{\lambda}{\hbar}$ , we recover the standard String Theory-like form of the 't Hooft expansion: connected sphere correlation functions can be expanded as

$$f(\hbar, N) = \frac{1}{\hbar^2} f_0(\lambda) + f_1(\lambda) + \hbar^2 f_2(\lambda) + \cdots$$
 (2.8)

The first term is the "planar" part of the connected correlation function.<sup>8</sup>

The planar part of a correlation function is a sum of terms with different numbers of connected components, which appear with a different overall power of  $\hbar$ . This can be a source of confusion: the planar part of a correlation function is not simply defined as the leading contribution in the 't Hooft expansion! We will see in detail how this affects various 2d CFT structures.

In a dual String Theory, single-trace operators should be associated to vertex operator insertions on the world-sheet, representing specific closed string states approaching specific locations in the holographic boundary. The planar data should match a tree-level String Theory calculation and non-planar effects should arise from loops. In the case at hand, the dual calculations could in principle be done via Witten diagram in the

<span id="page-16-2"></span><span id="page-16-1"></span><sup>&</sup>lt;sup>7</sup>Therefore, we have a family of  $\hbar$ -adic vertex algebras [51].

<sup>&</sup>lt;sup>8</sup>Notice that correlation functions of specific single-trace operators are polynomials in N and thus in  $\lambda$ . They are also Laurent polynomials in  $\hbar$  and thus the genus expansion truncates.

BCOV theory on SL(2, C) with specific bulk-to-boundary propagators. Such a computational strategy, though, does not obviously generalize to non-geometric settings.[9](#page-17-0)

There are various "natural" normalizations one may choose for single- and multitrace local operators:

• In a CFT, it is natural to normalize operators so that two-point functions are of order 1 (or better, functions of λ). Polynomials in single-trace operators with no extra power of ℏ have such property:

$$O^{\text{CFT}} \equiv \text{Tr}\left(\cdots\right),$$
 (2.9)

where the ellipsis denotes a cyclic sequence of (derivatives of) adjoint fields. With this normalization, sphere correlation functions are finite and dominated by disconnected products of two-point functions of single-traces in the ℏ → 0 limit, as in a generalized free field theory.

• The structure of the OPE is best described in a "classical" normalization

$$O^{\rm cl} \equiv \hbar {\rm Tr} \left( \cdots \right),$$
 (2.10)

so that planar singular part of the OPE is of order ℏ <sup>2</sup> and the regular part of order 1:

$$O_{i}^{\text{cl}}(z)O_{j}^{\text{cl}}(0) \sim \left[O_{i}^{\text{cl}}(z)O_{j}^{\text{cl}}(w)\right] + \hbar^{2} \left[g_{ij}(\lambda)z^{\dots} + \sum_{i,j} c_{ij}^{k,n}(\lambda)z^{\dots}\partial^{n}O_{k}^{\text{cl}}(w) + \sum_{i,j} c_{ij}^{k_{1},k_{2},n_{1},n_{2}}(\lambda)z^{\dots}\partial^{n_{1}}O_{k_{1}}^{\text{cl}}(w)\partial^{n_{2}}O_{k_{2}}^{\text{cl}}(w)\right] + O(\hbar^{4}) + \cdots$$
(2.11)

This makes manifest that the planar limit of the OPE is captured by a (nonlinear) Poisson chiral algebra A∞[λ], i.e. a commutative algebra with a compatible derivative and associative[10](#page-17-1) λ-bracket[11](#page-17-2). This structure arises from the Fourier transform of the singular part of the OPE (see, e.g., [\[53\]](#page-120-8)). Obvious (and deceptively simple) examples are the OPE of the rescaled superconformal generators.

<span id="page-17-0"></span><sup>9</sup>The reference [\[52\]](#page-120-9) approaches the problem via a KK reduction of BCOV to a three-dimensional Holomorphic-Topological theory. It may be possible to study the non-geometric backgrounds we are interested in by some sort of KK reduction from a non-commutative Calabi-Yau Y3[λ] to a geometric 3d HT theory. We leave this approach for future work.

<span id="page-17-1"></span><sup>10</sup>The multi-trace terms in the Poisson chiral algebra OPE are important for associativity: the Jacobi identity of three single-trace operators receives non-trivial contributions from the combination of a central term and a double-trace term in the OPE.

<span id="page-17-2"></span><sup>11</sup>We apologize for denoting the 't Hooft coupling as λ in a situation where one may want to reserve the symbol for the notion of λ-bracket.

E.g.

$$T^{\rm cl}(z) T^{\rm cl}(w) \sim \hbar^2 \left[ -\frac{3\lambda^2}{2(z-w)^4} + \frac{2T^{\rm cl}(w)}{(z-w)^2} + \frac{\partial T^{\rm cl}(w)}{z-w} \right] + (T^{\rm cl}T^{\rm cl})(w) + \cdots,$$
(2.12)

is the Virasoro Poisson chiral algebra. This should be matched with an OPE calculation in the tree-level BCOV theory in SL(2, C), with an appropriate holographic dictionary [\[52\]](#page-120-9).[12](#page-18-1)

• In this paper, we will stick to the normalization

$$O \equiv \frac{1}{\hbar} \text{Tr} \left( \cdots \right), \tag{2.13}$$

which turns out to be most suitable for the formal deformation theory considerations we employ to study the world-sheet theory for the dual String Theory.

#### <span id="page-18-0"></span>2.3 Single-trace BRST cohomology

The notion of single-trace operator has a subtle interplay with the BRST cohomology. The tree level part Q<sup>0</sup> of the BRST differential involves a single Wick contraction and reproduces classical BRST transformations:

$$Q_{0} c = \frac{1}{2}[c, c]$$

$$Q_{0} X = [c, X]$$

$$Q_{0} Y = [c, Y]$$

$$Q_{0} b = [c, b] + [X, Y].$$
(2.14)

In particular, it maps a single-trace operator to a single-trace operator. It acts as a derivation on products of single-trace operators.

The 1-loop part ℏQ<sup>1</sup> of the BRST differential involves two Wick contractions and is a bit more complicated. When acting on a single-trace operator, the result includes:

• Single-trace which arise from the contraction of consecutive symbols. They scale as λ. We refer to this as the linear part λQ<sup>l</sup> 1 of the planar answer.

<span id="page-18-1"></span><sup>12</sup>From this perspective, the ℏ expansion of A<sup>N</sup> is thus a "deformation quantization" [\[54\]](#page-120-10) of the planar Poisson chiral algebra. If we could prove the planar limit of the holographic correspondence, extending the proof to the full 't Hooft/genus expansion would entail comparing two deformation quantizations of the same Poisson VOA. The 3d HT theory mentioned in the previous footnote is also a natural tool to study deformation quantization of Poisson VOA [\[54,](#page-120-10) [55\]](#page-120-11)

• Double-trace terms which arise from the contraction of non-consecutive symbols. These terms are still planar and contribute, say, to the definition of A∞[λ].

The linearized operator Q0+λQ<sup>l</sup> 1 is nilpotent and defines a complex Ops<sup>λ</sup> of single-trace operators which should match (in the sense of complexes) the space of vertex operators in the dual world-sheet theory.

In this particular chiral gauge theory, the analysis is simplified by the existence of a large collection of single-trace operators which are exactly BRST-closed. It is easy to see that Tr X<sup>n</sup> is BRST-closed: it is classically invariant and it does not admit two Wick contractions with the BRST current. The SU(2)<sup>R</sup> symmetry then implies that the whole "A" tower of symmetrized traces

$$\mathcal{A}_{a,b} \equiv \frac{1}{(a+b)\hbar} \operatorname{STr} X^a Y^b \tag{2.15}$$

is BRST-closed. Acting with super-conformal generators produces three more towers:

$$\mathcal{B}_{a,b} \equiv \frac{1}{\hbar} \operatorname{STr} X^a Y^b b$$

$$\mathcal{C}_{a,b} \equiv \frac{1}{\hbar} \operatorname{STr} X^a Y^b \partial c$$

$$\mathcal{D}_{a,b} \equiv \frac{1}{\hbar} \operatorname{STr} X^a Y^b b \partial c + \cdots$$
(2.16)

The operator D0,<sup>0</sup> is proportional to the stress tensor.

The full expression of the last tower is complicated, as the OPE with superconformal generators which produces it includes terms with two Wick contractions, producing both single-trace corrections proportional to λ and double-trace corrections. The planar single-trace parts define the corresponding element in the cohomology of Ops<sup>λ</sup> .

So far we have only considered the single-trace part of the BRST cohomology. As the BRST charge is a derivation of the OPE, a simple strategy to define BRST-closed multi-trace operators is to look at the regular part of an OPE of BRST-closed singletrace operators. The regular part of OPE is usually called the regularized product. The price to pay is that such regularized product is not associative in the standard sense. Hence the whole BRST cohomology can not be simply identified as polynomial functions of the single-trace cohomology. However, we still expect the BRST cohomology of local operators built from a number of fields which remains finite as N is increased to consist of regularized products of operators from the single-trace cohomology, namely the above four towers. This expectation has not been systematically tested and will not be needed in the following.

As Q<sup>0</sup> acts on individual traces in a product as a derivation, we can compute the Q<sup>0</sup> cohomology on the space of single-trace operators. This calculation is best done with the Homological Algebra tools reviewed in Section [5.](#page-54-0) The result is precisely given by the four towers above. Though the results given above are specific to the chiral gauge theory we considered, we will see in Section [6](#page-61-0) that a similar pattern holds for the single-trace cohomology in more general chiral gauge theories.

#### <span id="page-20-0"></span>2.4 The Global Symmetry Algebra of sphere correlation functions

Recall that any chiral algebra is associated to a Vertex Operator Algebra of Fourier modes. We will use a "math" labelling of the modes,

$$O_n \equiv \oint_{|z|=1} \frac{dz}{2\pi i} z^n \mathcal{O}(z). \qquad (2.17)$$

As an exception to this notation, we still denote the global conformal generators as L<sup>−</sup>1, L0, L1. The action of non-negative modes on local operators and the commutator of two modes are controlled by the singular part of the OPE.

Recall that a quasi-primary operator is an operator annihilated by the L<sup>1</sup> mode of the stress tensor. We are interested in the modes O<sup>n</sup> of quasi-primary single-trace operators O which annihilate the vacuum at 0 and ∞, i.e. such that 0 ≤ n ≤ 2∆ − 2 if the scaling dimension of O is ∆. These modes form an irreducible representation of dimension 2∆ − 1 under the global conformal group:

$$[L_{-1}, O_n] = -nO_{n-1}$$

$$[L_0, O_n] = (\Delta - 1 - n)O_n$$

$$[L_1, O_n] = (n + 2 - 2\Delta)O_{n+1}.$$
(2.18)

An important special property of these modes is that the action on local operators and their commutation relations do not receive contribution from the central terms in the OPE. For example, the Virasoro central charge does not contribute to the commutator of the global conformal generators. As a consequence, the Jacobi identities for three such modes do not receive contributions from non-linear terms in the planar OPE.

The linear terms in the planar OPE and the linear terms in the action of the BRST differential thus equip the modes with the structure of a dg-Lie algebra, which we denote as the Planar Global Symmetry Algebra[13](#page-20-1) Lλ.

<span id="page-20-1"></span><sup>13</sup>The name is a bit of a misnomer, as the non-linearities would still contribute to Ward identities for planar correlation functions. In particular, knowledge of L<sup>λ</sup> alone is not obviously sufficient to determine planar correlation functions or OPE.

The restriction on the mode number is crucial. The linear part of the commutators of general single-trace modes is not associative and does not define a Lie algebra. Because of the definition,  $\mathfrak{L}_{\lambda}$  is the mode algebra of  $\operatorname{Ops}_{\lambda}$ , and acts on it.

Another useful perspective is that modes  $\mathcal{I}$  in  $\mathfrak{L}_{\lambda}$  can be added formally to the BRST differential to deform the chiral algebra. The deformation creates a BRST anomaly  $(Q + \mathcal{I})^2$  and we can select the planar single-trace part

$${Q, \mathcal{I}} + \frac{1}{2} {\mathcal{I}, \mathcal{I}},$$
 (2.19)

where the bracket denotes the single-trace planar part of the commutator, e.g. the Lie algebra bracket of  $\mathfrak{L}_{\lambda}$ .

A basic ingredient of the Twisted Holography conjecture is that the dg Lie algebra  $\mathfrak{L}_{\lambda}$  is quasi-isomorphic to the Lie algebra of holomorphic, divergence free, polynomial polyvector fields on  $SL(2,\mathbb{C})$ . These are the global symmetries of B-model worldsheet theory and act on the vertex operators which represent  $\operatorname{Ops}_{\lambda}$  insertions. We will generalize this identification to other examples.

We should be careful to distinguish symmetries of the world-sheet theory and symmetries of the corresponding String Theory. Although the two naively coincide, in practice the symmetries can be broken or deformed in the String Theory due to IR divergences. In the case at hand, the subtleties concern the holographic boundary conditions: a polynomial vector field acting on a field configuration which decays at the boundary may produce components which do not decay at the boundary.

We expect these subtleties to be analogous to the non-linear corrections to the action of  $\mathfrak{L}_{\lambda}$  on single-trace local operators in the chiral algebra. It would be interesting to explore this point and the analogous statement about  $\operatorname{Ops}_{\lambda}$  further.

A direct comparison between modes in  $\mathfrak{L}_{\lambda}$  and polyvector fields is a bit laborious, especially for the action of modes from the  $\mathcal{D}$  tower. The comparison is facilitated by the PSU(2|2) global super-conformal symmetry group. The conformal generators and the zero modes of the SU(2) currents map to the vector fields for the left and right action of SL(2) on itself. The modes  $G_{\pm\frac{1}{2}}^{\pm}$  and  $\widetilde{G}_{\pm\frac{1}{2}}^{\pm}$  of the super-currents map are then identified respectively with the coordinate functions on  $SL(2,\mathbb{C})$  and with four bi-vectors.

The modes of the  $\mathcal{B}$  tower transform in representations with the same spin for the two bosonic SL(2)'s and are identified with polynomials in  $SL(2,\mathbb{C})$  up to an overall scale for each spin. The PSU(2|2) action completes the matching to the remaining three towers. We expect the Jacobi identities of the Lie algebra to essentially fix the unknown proportionality constants. We will propose an alternative computational strategy momentarily.

The λ → 0 limit L<sup>0</sup> of the global symmetry algebra is well-defined and gives and polynomial, divergence-free holomorphic poly-vectorfields on the resolved singular conifold geometry

$$\mathcal{O}(-1) \times \mathcal{O}(-1) \to \mathbb{C}P^1$$
. (2.20)

This is the natural "ambient" geometry for the original stack of N D-branes, which is deformed to SL(2, C) by the back-reaction [\[56\]](#page-120-12).

In a standard patch of CP 1 , L<sup>0</sup> maps to a sub-algebra of the Lie algebra of polynomial, divergence-free holomorphic poly-vectorfields on C × C 2 . The latter can be identified with the linearized algebra L C 0 of all non-negative single-trace modes[14](#page-22-0), which is well-defined in the λ → 0 as the central terms in the OPE vanish in the limit.[15](#page-22-1)

We will return to this comparison in Section [5](#page-54-0) with powerful homological algebra methods.

There is an important subtlety which we should mention here. In the discussion above, we have compared modes in the cohomology of L<sup>λ</sup> to holomorphic polyvectorfields. We should remember that the cohomology of a dg-Lie algebra is not just a Lie algebra: it also naturally gains higher operations making it into an L<sup>∞</sup> algebra built via Homotopy Transfer [\[57\]](#page-120-13). A good way to understand this fact is to consider again the quadratic BRST anomaly. When we add an element I in L<sup>λ</sup> to the BRST differential, the corresponding BRST anomaly is given by

$${Q, \mathcal{I}} + \frac{1}{2} {\mathcal{I}, \mathcal{I}}.$$
 (2.21)

However, when the cohomology is not just a Lie algebra but have non-vanishing higher operations, the BRST anomaly becomes a more complicated expression when we try to describe the deformation via canonical representatives of a cohomology class [I]:

$$\frac{1}{2}\{[\mathcal{I}], [\mathcal{I}]\} + \frac{1}{6}\{[\mathcal{I}], [\mathcal{I}], [\mathcal{I}]\}_3 + \cdots$$
 (2.22)

Essentially, this happens because {[I], [I]} = 0 does not imply that the BRST anomaly vanishes. The higher operations would vanish automatically if the cohomology was supported in ghost number 0, but that is not the case here.

The full physical identification between L<sup>λ</sup> and an algebra of poly-vectorfields thus requires that the higher operations vanish with appropriate choices of cohomology representatives (a "formality theorem"). This will be nicely accounted for in the D-brane based proof we discuss now.

<span id="page-22-0"></span><sup>14</sup>We emphasis that L C 0 is not the complexification of L0, but rather an extension of L<sup>0</sup> that includes all modes of the single trace operators. Their distinction is also explained in Appendix [C](#page-103-0)

<span id="page-22-1"></span><sup>15</sup>Instead, the analogous L C λ is not associative.

#### <span id="page-23-0"></span>2.5 Fundamental matter and space-filling branes

Next, we consider our first D-brane-like modification of the system. We add k bosonic and k fermionic (anti)-fundamental matter fields to the gauge theory and study the 't Hooft expansion of the resulting chiral algebra. Holographically, this modification is expected to add k space-filling "probe" D-branes and k space-filling ghost probe D-branes, i.e. a probe D-brane P dressed by an C <sup>k</sup>|<sup>k</sup> Chan-Paton bundle.

In a BCOV description, these D-branes support a U(k|k) holomorphic Chern-Simons theory coupled to the BCOV fields.

We can denote the extra chiral algebra fields collectively as I <sup>A</sup> and JA, with A running over k bosonic and k fermionic values. We normalize the OPE as

$$I_i^A(z)J_B^j(w) \sim \hbar \frac{\delta_i^j \delta_B^A}{z-w}$$
 (2.23)

Somewhat tediously, one sometimes needs to keep track of the Grassmann parity (−1)<sup>|</sup>A<sup>|</sup> of individual components of the fundamental fields, e.g.

$$J_A^i(z)I_j^B(w) \sim (-1)^{|A|+1}\hbar \frac{\delta_j^i \delta_A^B}{z-w}$$
 (2.24)

Operators of "small" size compared to N can be written as polynomials in singletrace operators and mesonic operators, i.e. open strings of adjoint symbols sandwiched between an anti-fundamental and a fundamental symbol. We will include a factor of ℏ −1 in front of mesons. For example, an important class of mesonic operators takes the form

$$\mathcal{M}_{a,0;B}^{A} \equiv \frac{1}{\hbar} I^{A} X^{a} J_{B} \tag{2.25}$$

together with their SU(2)<sup>R</sup> partners M<sup>A</sup> a,b;B [16](#page-23-1) Recall that X and Y transform as a doublet under the SU(2)<sup>R</sup> action. An explicit form of M<sup>A</sup> a,b;<sup>B</sup> can be obtained by expanding the generating function <sup>1</sup> ℏ I <sup>A</sup>(X + uY ) <sup>a</sup>+<sup>b</sup>J<sup>B</sup> and extracting the coefficient of u b .

If we keep k arbitrary, correlation functions containing mesonic operators can be decomposed into "flavour-ordered" pieces multiplying products of cyclic combinations of flavour Kronecker δ A <sup>B</sup> symbols. Flavour-ordered, connected correlation functions are the natural quantities appearing in the 't Hooft expansion, with each cycle of flavour indices corresponding to a boundary of the dual string world-sheet. The mesonic operators correspond to open strings.

<span id="page-23-1"></span><sup>16</sup>Again, one can consider a CFT normalization, which involves a factor of ℏ − <sup>1</sup> <sup>2</sup> , or a classical normalization with no factor of ℏ which leads to a Poisson chiral algebra of mesons with OPE singularities appearing at order ℏ. At this order, single-trace operators enter OPE but are central.

The leading order "planar" contribution to a connected correlation function of this form has a single boundary and the topology of a disk. It appears at order  $\hbar^{-1}$ .

The BRST charge of the flavoured theory includes an extra mesonic term

$$\frac{1}{\hbar} \oint \frac{dz}{2\pi i} I^A c J_A \,. \tag{2.26}$$

At tree-level, the action of  $Q_0$  on b is thus modified:

$$Q_0 b = [c, b] + [X, Y] + J_A I^A$$

$$Q_0 I^A = (-1)^{|A|+1} I^A c$$

$$Q_0 J_A = c J^A.$$
(2.27)

In particular,  $\mathcal{M}_{a,b;B}^A$  are  $Q_0$ -closed, but the trace  $\mathcal{M}_{a,b;A}^A$  is the  $Q_0$  image of  $\mathcal{B}_{a,b}$ . We will see later on that the traceless part of  $\mathcal{M}_{a,b;B}^A$  exhausts the mesonic part of the  $Q_0$  cohomology.

At one loop,  $\hbar Q_1$  maps  $\mathcal{M}_{a,b;B}^A$  to  $\hbar \delta_B^A \mathcal{C}_{a,b}$ . The introduction of flavour thus lifts both the  $\mathcal{B}$  and  $\mathcal{C}$  towers and the surviving mesons can be thought of as valued in  $\mathfrak{psu}_{k|k}$ .

In the following, we will focus on meson operators with  $A \neq B$ , so that we can ignore the mixing with single-trace operators. The action of  $\hbar Q_1$  can be restricted to a linear planar part  $\lambda Q_1^l$  which maps mesons to mesons by contracting the BRST current with consecutive symbols. The operator  $Q_0 + \lambda Q_1^l$  acting on mesons defines a complex  $\operatorname{Ops}_{\lambda}^P$  of mesonic operators which should match a space of boundary vertex operators in the dual world-sheet theory.

#### <span id="page-24-0"></span>2.6 Mesonic GSA

Following the same strategy as for single-trace operators, we can define the linearized global mode algebra of the mesons. In particular, the zero modes of the  $\mathcal{M}_{0,0;B}^A$  currents generate the global  $\mathfrak{u}_{k|k}$  flavour symmetry of the problem. The flavour structure in the meson-meson OPE is such that the algebra takes the form  $\mathfrak{u}_{k|k}[\mathfrak{P}_{\lambda}]$  for a unital algebra  $\mathfrak{P}_{\lambda}$  (neglecting the subtleties about the diagonal mixing with  $\mathfrak{L}_{\lambda}$ ), with unit given by the  $\mathcal{M}_{0,0;B}^A$  zero modes.

More precisely, we should define  $\mathfrak{P}_{\lambda}$  as a dg-algebra, using the modes of all mesonic operators, and then pass to cohomology as an  $A_{\infty}$  algebra via Homotopy Transfer. Assuming that the cohomology consists of the modes of  $\mathcal{M}_{a,b;B}^A$ , though, the higher operations vanish automatically because the cohomology is supported in ghost number 0. This allows us to treat  $\mathfrak{P}_{\lambda}$  as an algebra.

Another entry of the Twisted Holography dictionary identifies  $\mathfrak{P}_{\lambda}$  as the algebra of holomorphic functions on  $SL(2,\mathbb{C})$ , i.e. with the classical algebra of global gauge

transformations in the hCS theory which fixes the background connection. In the  $\bar{A}=0$  background, these are  $\delta_{\alpha}\bar{A}=\bar{\partial}\alpha+[\bar{A},\alpha]=\bar{\partial}\alpha=0$ . That is,  $\alpha$  is holomorphic. The Lie algebra of symmetries of hCS is then  $\mathfrak{u}_{k|k}[\mathcal{O}(SL_2(\mathbb{C})])$ , with  $\mathcal{O}(SL_2(\mathbb{C}))$  the unital algebra of holomorphic functions on  $SL_2(\mathbb{C})$ .

As for the single-trace symmetries, we identify  $\mathfrak{u}_{k|k}[\mathfrak{P}_{\lambda}]$  as the algebra of boundary symmetries of the world-sheet theory. In the hCS theory, subtleties in the holographic dictionary will introduce non-linearities which should match the non-linear planar terms in the mode algebra.

The explicit match is a bit easier to test than the analogous one for  $\mathfrak{L}_{\lambda}$ . The mesons  $\mathcal{M}_{1,0;B}^{A}$  and  $\mathcal{M}_{0,1;B}^{A}$  each contribute two modes. We get a total of four elements in  $\mathfrak{P}_{\lambda}$ , to be identified with the coordinate functions on  $SL(2,\mathbb{C})$ . We can denote them as (x,x') and (y,y') respectively.

A straightforward tree-level calculation shows that these generators commute and x'y-y'x=0 in  $\mathfrak{P}_0$ . A 1-loop correction deforms that relation to the generating relation for  $SL(2,\mathbb{C})$ :  $x'y-y'x=\lambda$  [37]. Composing these generators, specific polynomial holomorphic functions on  $SL(2,\mathbb{C})$  can be associated to modes in  $\mathfrak{P}_{\lambda}$ .

Of course, the  $SU(2)_R$  symmetry and SL(2) conformal symmetry fix most of the identification up to overall coefficients: if we denote as  $z_{\alpha} = (x, y)$  and  $z'_{\alpha} = (x', y')$  the two SU(2) doublets of generators, the symmetrization of  $SU(2)_R$  indices in

$$z_{\alpha_1} \cdots z_{\alpha_{n-m}} z'_{\alpha_{n-m+1}} \cdots z'_{\alpha_n} \tag{2.28}$$

gives the m-th mode of the meson of  $SU(2)_R$  spin n/2.

One should note that the back-reacted geometry  $SL(2,\mathbb{C})$  is an affine variety. We can therefore identify the category of coherent sheaves on  $SL(2,\mathbb{C})$  with the category of modules over the algebra of polynomial holomorphic functions on  $SL(2,\mathbb{C})$ . Thus in this example, we are able to reconstruct the D-branes category by studying the mesonic global symmetry algebra  $\mathfrak{P}_{\lambda}$ , realized simply as the category of modules over  $\mathfrak{P}_{\lambda}$ .

#### <span id="page-25-0"></span>2.7 Open vs Closed

We can probe the relation between  $\mathfrak{L}_{\lambda}$  and  $\mathfrak{P}_{\lambda}$  by looking at the interplay between single-trace operators and mesons. Operators with different ghost number play a slightly different role here, though ultimately all statements here can be formulated uniformly by looking at the BRST anomalies which occur when adding to the BRST charge modes in both algebras.

In the string theory dual, turning on a closed string mode which is a function creates a BRST anomaly on space-filling branes. The anomaly is the restriction of the function to the branes. In the QFT, this is dual to the observation that  $\mathcal{B}_{a,b}$  is

not closed anymore and rather maps to a diagonal meson. Accordingly, the action of Q maps modes of L<sup>λ</sup> associated to functions to modes of P<sup>λ</sup> associated to the same functions.

Closed string modes which are vectorfields act as symmetries on the open string modes by the standard action on functions. Accordingly, the linearized action of modes of the A and D towers map mesons to mesons and give an action of the ghost number 0 part of L<sup>λ</sup> as a derivation of Pλ.

Closed string modes which are bivectors can be turned on infinitesimally to give a non-commutative deformation of the gauge algebra on space-filling branes. In the QFT, we can imagine adding a mode of the C tower to the BRST differential. This means that [X, Y ] is not exact but rather equals some polynomial in X and Y . When we compute the planar OPE of two mesons, we generically produce an expression which is not symmetrized in X and Y . Normally, it would be symmetrized by adding BRSTexact terms. If the BRST charge is deformed, the product in P<sup>λ</sup> will be deformed accordingly.

These three cases can be unified by looking at the "Hochschild cohomology" HH• (Pλ, Pλ) of P<sup>λ</sup> , together with a map L<sup>λ</sup> → HH• (Pλ, Pλ). For exmaple, H<sup>0</sup> (Pλ, Pλ) is a copy of P<sup>λ</sup> corresponding to BRST anomalies, H<sup>1</sup> (Pλ, Pλ) corresponds to derivations of P<sup>λ</sup> and H<sup>2</sup> (Pλ, Pλ) corresponds to non-commutative deformations of Pλ. More generally, the entire HH• (Pλ, Pλ) can be interpreted as controlling the A<sup>∞</sup> deformation of Pλ. General considerations about the structure of BRST anomalies and open closed coupling tell us that there is an L<sup>∞</sup> morphism from L<sup>λ</sup> to the dg-Lie algebra HH• (Pλ, Pλ).

Once P<sup>λ</sup> is identified with the algebra of functions on SL(2, C), HH• (Pλ, Pλ) is known to be L<sup>∞</sup> quasi-isomorphic to the Lie-algebra of polynomial poly-vectorfields, without higher operation. As a consequence, we have an L<sup>∞</sup> morphism from L<sup>λ</sup> to polynomial poly-vectorfields.

However, the above morphism L<sup>λ</sup> → HH• (Pλ, Pλ) is not a quasi-isomorphism of commplexes. In order to complete the holographic dictionary, we should also characterize the image of L<sup>λ</sup> → HH• (Pλ, Pλ) as consisting of divergence-free polynomial poly-vectorfields, as in the B-model. It is not difficult to do so "by hand", by computing the action of a generating set of modes of Lλ.

It would be better to do so in an Homological Algebra language which can be generalized to the general examples discussed in Section [5.](#page-54-0) We leave this question as an open problem.

#### <span id="page-26-0"></span>2.8 Determinant operators

The prototypical determinant operator is det X. The same argument used for Tr X<sup>n</sup> shows that it is a BRST-closed local operator. It is a quasi-primary of dimension <sup>N</sup> 2 . Using SU(2)<sup>R</sup> rotations, one gets a whole family of BRST-closed determinant operators det(X + uY ) which are also quasi-primary operators of dimension <sup>N</sup> 2 .

The insertion of a det X operator in a correlation function requires order of N Wick contractions with Y fields in other operators. For example, a two-point function ⟨det X(z) det Y (w)⟩ involves an overall factor of (z − w) <sup>−</sup><sup>N</sup> . Accordingly, correlation functions of determinant operators tend to scale as e So in a 't Hooft expansion, with S<sup>o</sup> behaving as the action of a dual D-brane.

If we insert multiple determinants in a correlation function, we will add up contributions which have nij Wick contractions between the i-th and j-th determinants. In a 't Hooft expansion, we may encounter a variety of non-trivial saddles as we vary the order 1 parameters ℏnij . Holographically, each determinant insertion imposes the presence of a "giant graviton" D-brane with a specific asymptotic behaviour at the holographic boundary. These boundary conditions may be satisfied by D-branes with a variety of non-trivial shapes in any given correlation function. In this section we will review and improve the known correspondence between saddles in the 't Hooft expansion and D-branes in SL(2, C) with specified asymptotic behaviour.

It is useful to consider expressions such as det(m + X + uY ). These can be interpreted as generating functions for "shortened" determinant operators. i.e. traces of matrices of minors. Individual shortened determinants can be recovered by a contour integral

$$\oint_{|m|=1} \frac{dm}{m^{k+1}} \det(m + X + uY).$$
 (2.29)

All of these options are BRST-closed. These generating functions have a slightly counter-intuitive but useful behaviour in the large N expansion: the associated correlation functions admit saddles where the number of Wick contractions remains finite and the answer is dominated by an overall factor of

$$m^N = e^{\frac{1}{\hbar}\lambda \log m} \,. \tag{2.30}$$

Even though the saddle focuses on parts of the generating series with a finite number of X and Y fields, the 't Hooft expansion still includes surfaces with boundaries and the dual geometry includes a giant-graviton brane with a simple shape and action log m.

The D-brane-like properties of the determinant becomes more manifest if we express the determinant as an integral over auxiliary (anti)fundamental fermions:[17](#page-27-0)

$$\det(m+X) = \int \left(\frac{d\psi d\bar{\psi}}{\hbar}\right)^N e^{\frac{1}{\hbar}\bar{\psi}(m+X)\psi}. \tag{2.31}$$

<span id="page-27-0"></span><sup>17</sup>Replacing fermions with bosons gives inverse determinant operators. These are also interesting, but the analysis for the two cases is very similar.

A straightforward expansion in Feynman diagrams with an  $m^{-1}$  propagator for the auxiliary fermions leads to a 't Hooft expansion with an open string sector.

In [50], the saddles for correlation functions of multiple determinants were recovered by merging all determinants

$$\prod_{i=1}^{n} \det \left( m_i + X(z_i) + u_i Y(z_i) \right) = \int \prod_{i} \left( \frac{d\psi_i d\bar{\psi}^i}{\hbar} \right)^N e^{\sum_i \frac{1}{\hbar} \bar{\psi}^i (m_i + X(z_i) + u_i Y(z_i)) \psi_i} . \quad (2.32)$$

into a single normal-ordered expression within the auxiliary integrals:

$$e^{\sum_{i} \frac{1}{\hbar} \bar{\psi}^{i}(m_{i} + X(z_{i}) + u_{i}Y(z_{i}))\psi_{i}} = e^{\frac{1}{\hbar} \sum_{i < j} \frac{u_{i} - u_{j}}{z_{i} - z_{j}} \bar{\psi}_{i}\psi_{j} \bar{\psi}_{j}\psi_{i}} : e^{\sum_{i} \frac{1}{\hbar} \bar{\psi}^{i}(m_{i} + X(z_{i}) + u_{i}Y(z_{i}))\psi_{i}} : .$$
(2.33)

A Hubbard-Stratonovich transformation eliminates the quartic terms at the price of introducing auxiliary variables  $\rho_i^i$  for  $i \neq j$ . Setting  $\rho_i^i = m_i$ , the integrand becomes

$$e^{-\frac{1}{\hbar}\sum_{i< j}\frac{z_{i}-z_{j}}{u_{i}-u_{j}}\rho_{j}^{i}\rho_{i}^{j}}:e^{\frac{1}{\hbar}\sum_{i,j}\rho_{j}^{i}\bar{\psi}_{i}\psi_{j}+\sum_{i}\frac{1}{\hbar}\bar{\psi}^{i}(X(z_{i})+u_{i}Y(z_{i}))\psi_{i}}:. \tag{2.34}$$

As no other determinants are present and only a finite number of Wick contractions remain to be done, the  $\psi$  integral behaves as det  $\rho^N$  and one arrives at saddle equations

$$\frac{z_i - z_j}{u_i - u_j} \rho_j^i = \lambda(\rho^{-1})_j^i, \qquad i \neq j$$
 (2.35)

for the  $\rho_j^i$  integral. These equations were shown to determine the shape of a dual giant graviton D-brane in  $SL(2,\mathbb{C})$ . We will momentarily explain and extend that result.

There is a neat alternative way to arrive at these equations. We can just start from the normal-ordered exponent with a generic source  $\rho$ 

$$: e^{\frac{1}{\hbar} \sum_{i,j} \rho_j^i \bar{\psi}_i \psi_j + \sum_i \frac{1}{\hbar} \bar{\psi}^i (X(z_i) + u_i Y(z_i)) \psi_i} :$$
 (2.36)

and compute the BRST variation. The BRST operator here consists of the part that acts on the chiral algebra fields X, Y (2.3) and the part that acts on the auxiliary fermions  $\bar{\psi}^i, \psi_j$ , which is given by

$$\psi_i \to c(z_i)\psi_i$$

$$\bar{\psi}_i \to \bar{\psi}_i c(z_i) \tag{2.37}$$

We find that the BRST variation is proportional to

$$\sum_{i,j} \left[ \frac{u_i - u_j}{z_i - z_j} \bar{\psi}^i \psi_j - \rho_j^i \right] \bar{\psi}^j (c(z_i) - c(z_j)) \psi_i.$$
 (2.38)

The first term comes from the 1-loop part Q<sup>1</sup> of [\(2.3\)](#page-14-2) and the second the variation of the auxiliary fermions. At planar order we can replace ψ¯<sup>i</sup>ψ<sup>j</sup> in parentheses with the Wick contraction λ(ρ −1 ) i j and we recover the saddle equations

$$\sum_{i,j} \left[ \lambda(u_i - u_j)(\rho^{-1})_j^i - (z_i - z_j)\rho_j^i \right] \bar{\psi}^j \frac{c(z_i) - c(z_j)}{z_i - z_j} \psi_i.$$
 (2.39)

as conditions for planar BRST invariance of the combined operator.

### <span id="page-29-0"></span>2.9 Determinant modifications

The integral expression for determinant operators allows us to define a large class of "determinant modifications", in the form of insertions of mesonic operators ℏ <sup>−</sup><sup>1</sup>ψ¯ · · · ψ in the auxiliary integral, which replace one symbol in the determinant with some string of symbols. These modifications behave as open string states attached to the dual D-brane [\[58\]](#page-120-14).[18](#page-29-1)

It is also useful to formally add determinant modifications to the auxiliary action to define finite deformations. E.g.

$$\det(m+X+\epsilon Y^2) = \int \left(\frac{d\psi d\bar{\psi}}{\hbar}\right)^N e^{\frac{1}{\hbar}\bar{\psi}(m+X+\epsilon Y^2)\psi}.$$
 (2.40)

The algebraic structures we define below can all be understood in terms of the BRST anomaly (e.g. variation) of such formal expressions, possibly after deforming the bulk BRST charge as well.

Even at the planar level, determining which modifications preserve BRST invariance takes some work. An important subtlety is that an expression involving the auxiliary field may vanish upon integration. For example, the BRST variation of the integral expression for det m + X(z) is

$$\int \left(\frac{d\psi d\bar{\psi}}{\hbar}\right)^N e^{\frac{1}{\hbar}\bar{\psi}(m+X)\psi} \frac{1}{\hbar}\bar{\psi}[c,m+X]\psi \tag{2.41}$$

and only vanishes after integration by parts. We will discuss momentarily how to use the BV formalism for the auxiliary integral to systematically deal with integration by parts.

An important observation is that an insertion of ψψ¯ can be traded of for ℏ∂m. Because of the overall prefactor m<sup>N</sup> to the 't Hooft expansion, this takes the form of λm<sup>−</sup><sup>1</sup> up to corrections subleading in the planar approximation. This effect is important

<span id="page-29-1"></span><sup>18</sup>Several aspects of the construction and computation of open modifications described in this Section originally emerged in unpublished work with Kasia Budzik.

in computing the planar OPE between single-trace operators and (modified) determinants, as well as the planar BRST variations. The analysis for non-trivial saddles is completely parallel with m → ρ.

In order to set up a BV formalism for the auxiliary integral, we introduce anti-fields u and ¯u. To insure BRST invariance of the determinant, we can extend the auxiliary action to a BV action

<span id="page-30-1"></span>
$$S_{\rm BV} = m\bar{\psi}\psi - \bar{u}c\psi + \bar{\psi}X\psi - \bar{\psi}cu. \qquad (2.42)$$

The two extra terms insure that the tree-level BV differential {SBV, •} maps ψ → cψ and ψ¯ → ψc¯ and cancels the chiral algebra BRST variation.

More precisely, the consistency of the setup is constrained by a master equation:

$$(Q_{\text{BRST}} + \hbar \Delta_{\text{BV}}) e^{\frac{1}{\hbar} S_{\text{BV}}} = 0, \qquad (2.43)$$

where QBRST is the chiral algebra BRST variation and ∆BV the BV Laplacian

<span id="page-30-0"></span>
$$\Delta_{\rm BV} = \frac{\partial}{\partial u} \frac{\partial}{\partial \bar{\psi}} + \frac{\partial}{\partial \bar{u}} \frac{\partial}{\partial \psi} \,, \tag{2.44}$$

which guarantees that the BRST variation integrated by parts to zero inside the auxiliary integral.

Additionally, we may study space of deformations of such a BV action and the BRST anomalies they induce. These anomalies endow our space of deformations with a dg-Lie algebra structure:

$$(Q_{\text{BRST}} + \hbar \Delta_{\text{BV}}) e^{\frac{1}{\hbar} (S_{\text{BV}} + \sum_{i} \epsilon_{i} \mathcal{O}^{i})} =$$

$$= \frac{1}{\hbar} \left( \sum_{i} \epsilon_{i} Q_{\text{det}} \mathcal{O}^{i} + \sum_{i,j} \epsilon_{i} \epsilon_{j} \{ \mathcal{O}^{i}, \mathcal{O}^{j} \}_{\text{det}} + O(\hbar) \right) e^{\frac{1}{\hbar} (S_{\text{BV}} + \sum_{i} \epsilon_{i} \mathcal{O}^{i})}$$
(2.45)

The anomaly linear in the O's endows them with a differential which at tree level is given by

$$Q_{\det}\mathcal{O} := Q_0\mathcal{O} + \{S_{\text{BV}}, \mathcal{O}\}_{\det}$$
 (2.46)

with Q<sup>0</sup> the tree level BRST differential. The bracket can be read off from the anomaly that is quadratic in the O's which at tree level is given by the usual BV bracket associated to the BV laplacian [\(2.44\)](#page-30-0).

Determinant modifications should be thought of as being in correspondence with these formal modifications of the action and are thus also equipped by the modified differential and bracket with the structure of a dg-Lie algebra. As usual, we can include higher ℏ corrections restricted to a planar linear part which maps mesonic modifications to mesonic modifications.

It is natural to replace the determinant with a k-th power of the determinant, by taking k copies of all the auxiliary fields. This makes determinant modifications into k ×k matrices gl<sup>k</sup> [Dλ] for some unital dg-algebra Dλ. We will denote this as the global symmetry algebra of the determinant operator(s).

The algebra D<sup>λ</sup> should be identified with the algebra of global gauge transformations for the dual D-brane or, better, boundary world-sheet symmetries for the giant graviton brane D dual to the determinant insertions. Although our notation does not keep track of that, the algebra depends on the choice of saddle via ρ.

In Section [5](#page-54-0) we will compute D0.

Much as we saw for Pλ, there is an interplay between D<sup>λ</sup> and Lλ:

- A mode in L<sup>λ</sup> may create a modification out of an un-modified determinant. This gives a linear map L<sup>λ</sup> → Dλ.
- A mode in L<sup>λ</sup> may map a modification of a determinant to a different modification. This gives a bi-linear map L<sup>λ</sup> × D<sup>λ</sup> → Dλ.
- A mode in L<sup>λ</sup> acting on a determinant with two modification may merge them into a single modification. This gives a tri-linear map L<sup>λ</sup> × D<sup>λ</sup> × D<sup>λ</sup> → Dλ, etcetera.

As we did for Pλ, we can do the above calculations at generic k, acting on a determinant modified by a sequence of mesons with matching consecutive flavour indices.

The structure can be arranged into an L<sup>∞</sup> morphism from L<sup>λ</sup> and the Hochschild cohomology of HH• (Dλ, Dλ). It encodes the BRST anomalies which appear if we add a mode of L<sup>λ</sup> to QBRST and determinant modification to SBV.

Both the space-filling D-brane P and the giant graviton D-brane D thus capture the bulk symmetries of the back-reacted world-sheet theory. We will now see that the giant graviton branes do better than P in a different respect: they capture categorically the closed string states associated to single-trace local operators Ops<sup>λ</sup> .

There are two dual recipes: we either consider connected two-point functions of a modified determinant operator and a single-trace operator or expand a modified determinant operator at large m and pick the single-trace part. As usual, it is convenient to use multiple determinants in order to pick out disk diagrams more easily. For example,

$$(\det m + X)^k = \exp k \operatorname{Tr} \log(m + X) = m^N \exp k \sum_{i} (-1)^{i+1} m^{-i} \operatorname{Tr} X^i$$
 (2.47)

and we can take the part linear in k. When adding modifications, we can focus on a term where the flavour indices are contracted in a specific cyclic pattern.

The overall result is a collection of multi-linear cyclic maps from  $\mathfrak{D}_{\lambda}$  to  $\operatorname{Ops}_{\lambda}$ . With a bit of work, one can interpret this as a pairing between the cyclic cohomology  $\operatorname{HC}^{\bullet}(\mathfrak{D}_{\lambda})$  and the space of single-trace local operators. Giant graviton branes are thus a natural ingredient in a dg-TFT description of the deformed world-sheet theory.

#### <span id="page-32-0"></span>2.10 Open Modifications

We now focus on the interplay between the giant graviton brane(s) D and the spacefilling brane P. Accordingly, we add the I, J fields to the chiral algebra and consider "open" determinant modifications such as  $\frac{1}{\hbar}I^A\psi$  or  $\frac{1}{\hbar}\bar{\psi}J_B$ . Of course, such modifications will need to appear in pairs. The planar BRST complex of open modifications give two spaces  $\mathfrak{M}_{\lambda}$  and  $\widetilde{\mathfrak{M}}_{\lambda}$  respectively. We expect BRST-closed open modifications of the schematic form  $\frac{1}{\hbar}I^AY^n\psi$  and  $\frac{1}{\hbar}\bar{\psi}Y^nJ^A$ .

Open modifications correspond holographically to open strings stretched between the space-filling branes and the giant graviton. On the world-sheet, they correspond to specific boundary-changing vertex operators (see Figure 2). We can tentatively probe the action of boundary local operators on P onto this junctions by looking at the action of  $\mathfrak{P}_{\lambda}$  onto the open modifications. It is also possible to define an action of  $\mathfrak{D}_{\lambda}$  via the modified BV brackets, which should match the action of local operators on D.

<span id="page-32-1"></span>![](_page_32_Picture_5.jpeg)

Figure 2. Illustration of the algebra of operators associated to the junction between the P and D branes acting as a left  $\mathfrak{P}_{\lambda}$ -module and a right  $\mathfrak{D}_{\lambda}$ -module. Purple dots, aka boundary local operators on P, can combine with elements from the junction algebra from the left. Green dots, aka boundary local operators on D, can combine with elements from the junction algebra from the right.

We act with a meson on a determinant with open modifications. If our starting point is a determinant modified by  $\frac{1}{\hbar}I^A\psi$  and  $\frac{1}{\hbar}\bar{\psi}J_B$  and we act with a mode of  $\mathcal{M}_{a,b;D}^C$ , the planar part of the answer is the sum of an action on  $\frac{1}{\hbar}I^A\psi$  proportional to  $\delta_D^A$ , an action on  $\frac{1}{\hbar}\bar{\psi}J_B$  proportional to  $\delta_B^C$  and a 1-loop part which merges the two open modifications into a  $\bar{\psi}\psi$  modification.

The first two parts are our main focus. They equip  $\mathfrak{M}_{\lambda}$  and  $\mathfrak{M}_{\lambda}$  respectively with the structure of a left- and a right- module for  $\mathfrak{P}_{\lambda}$ .

Consider in particular the action of the four modes x, y, x' and y' in  $\mathfrak{P}_{\lambda}$ . The meson  $\frac{1}{\hbar}I^{C}XJ_{D}$  can only have one Wick contraction with  $\frac{1}{\hbar}I^{A}\psi$ . Accordingly, the action of x' vanishes and the action of x produces a  $\frac{1}{\hbar}I^{C}X\psi$  modification. Up to a total derivative, this gives back  $-m\frac{1}{\hbar}I^{C}\psi$ , i.e. x acts as multiplication by m.

On the other hand,  $\frac{1}{\hbar}I^CYJ_D$  can also have a simultaneous Wick contraction with the action in the auxiliary integral, producing the combination of fields  $\frac{1}{\hbar}I^C\psi\bar{\psi}\psi$  which at the planar level is equivalent to  $\lambda m^{-1}\frac{1}{\hbar}I^C\psi$ . We thus learn that y' acts as  $\frac{\lambda}{m}$ , as required by the algebra relation  $xy'-x'y=xy'=\lambda$ , and y produces a new modification

$$\frac{1}{\hbar}I^C Y \psi + (\bar{\psi}\psi)\frac{1}{\hbar}\partial I^C \psi. \tag{2.48}$$

The action of the generators of  $\mathfrak{P}_{\lambda}$  determines the action of the full algebra of holomorphic functions on  $SL(2,\mathbb{C})$ , which reproduces the expected answer for a D-brane D supported at x'=0, x+m=0. This is indeed the expected shape of the "basic" saddle for  $\det(m+X)$ . Similarly, the basic saddle of  $\det(m+X+uY)$  gives a brane supported on x'+uy'=0 and m+x+uy=0.

An analogous calculation can be done for non-trivial saddle of multiple determinants. We now have a vector  $\frac{1}{\hbar}I^A(z_i)\psi_i$  of modifications and the four generators act as matrices on this vector, built from  $\rho$ ,  $\rho^{-1}$  and diagonal matrices  $\mu$  and  $\zeta$  containing the parameters  $u_i$  and positions  $z_i$ . We have relations  $\rho + x + y\mu = 0$  and  $x' + y'\mu = \zeta \rho$ .

Remarkably, these two equations and the third implied relation below

$$x = -\mu y - \rho$$

$$x' = \zeta \rho - y' \mu$$

$$y' = y\zeta + \lambda \rho^{-1}$$
(2.49)

define an action of the commutative algebra  $\mathfrak{P}_{\lambda}$  iff the saddle equations for  $\rho$  are satisfied. These expressions match the commuting matrices which appear in the spectral curve presentation of the dual giant graviton saddle [50].

We have thus connected directly the giant graviton probe of the dual geometry and the  $\mathfrak{P}_{\lambda}$  probe and presented the dual brane in terms of a left- and right- module for the algebra of functions on  $SL(2,\mathbb{C})$ , corresponding to the boundary-changing local operators between P and D.

One could consider further deformations of the determinant/space filling brane system that are baryonic

$$\epsilon_{a_1 \cdots a_n} J^{a_1} \cdots J^{a_n} = \int \left( \frac{d\bar{\psi}}{\hbar} \right)^N e^{\bar{\psi}J} \tag{2.50}$$

or antibaryonic

$$\epsilon^{a_1 \cdots a_n} I_{a_1} \cdots I_{a_n} = \int \left(\frac{d\psi}{\hbar}\right)^N e^{I\psi}$$
 (2.51)

and combinations of these with the determinant insertion. In the large N limit these correspond to the presence of an instanton background in the bulk arising from the interaction between the space-filling and determinant branes. Such instantons are studied in [\[59\]](#page-120-15), and we leave it for future work to incorporate them within this dg-TFT framework.

#### <span id="page-34-0"></span>2.11 Conclusions

The main outcome of this section was an algorithmic proposal to extract certain algebras of world-sheet local operators from the 't Hooft expansion of OPE's between single-trace operators, mesons and determinant modifications.

In particular,

- 1. The linearized Global Symmetry Algebra L<sup>λ</sup> of single-trace operators reproduced global gauge symmetries in the dual closed string theory, aka the worldsheet bulk local operators.
- 2. The linearized Global Symmetry Algebra P<sup>λ</sup> of mesonic operators reproduced global gauge symmetries in the dual open string theory supported on space-filling branes, i.e. the corresponding boundary local operators.
- 3. Determinant modifications reproduced the algebra D<sup>λ</sup> of open string states on giant-graviton branes, i.e. the corresponding boundary local operators.
- 4. Open determinant modifications reproduced open string states stretched between giant-graviton branes and space-filling branes as a bi-module M<sup>λ</sup> for the associated algebras, i.e. the corresponding boundary-changing local operators.

There are also rich connections between the algebras Lλ, P<sup>λ</sup> and Dλ, as closed string modes can always be used to deform open string theories on branes. We have

- 1. As a result of open closed coupling, we have a L<sup>∞</sup> morphism from L<sup>λ</sup> to the Hochschild cohomology HH• (Pλ, Pλ), whose images lie in the kernel of divergence operator.
- 2. A mode in L<sup>λ</sup> can create a determinant modification, change a determinant modification, merge two modifications into one, and so on. Hence, we also have a L<sup>∞</sup> morphism from L<sup>λ</sup> to HH• (Dλ, Dλ).

We will next do some more explicit calculations in the λ → 0 limit and then extend the analysis to more-general chiral algebras.

### <span id="page-35-0"></span>3 Homological algebra and the B-model

It turns out that many of the Q0-cohomology calculations we encountered in the previous section have a neat Homological Algebra interpretation. This should not be surprising: many constructions in Homological Algebra effectively formalize aspects of 2d dg-TFT, possibly with boundaries. In the λ → 0 limit, the Q0-cohomology calculations reproduce dg-TFT aspects of the B-model with target C 3 , the original D-branes B wrapping C, space-filling branes P and branes D associated to determinants. Accordingly, we will review in this section Homological Algebra aspects of the B-model and in the next how Homological Algebra appears in λ → 0 calculations.

While this section mainly illustrates the cohomology calculation and how they reproduce the space of bulk local operators of the B-model, the algebraic structures on the Q0-complex are also of crucial importance. As will be discussed in Sections [3.1](#page-35-1)[,3.5](#page-39-0) and [3.6,](#page-39-1) the Lie algebra structure on the bulk local operators encodes information about symmetries and infinitesimal deformations of both the bulk and boundary theories on branes, and will be further elaborated in later sections. In general, one should expect an L<sup>∞</sup> structure, but in our main examples the higher operations vanish by virtue of the formality theorem [\[60\]](#page-120-16). One can also consider the whole E<sup>2</sup> algebra structure on the bulk local operators. Reproduction of this structure from the homological computations of the boundary algebra is a well established mathematical result know as the "Deligne conjecture" [\[61](#page-121-0)[–64\]](#page-121-1). However, this aspect 2d dg-TFT will not be pursued here, as our main approach and focus remain on the symmetry algebras derived from various boundary theories on branes.

### <span id="page-35-1"></span>3.1 The B-model with target C

The B-model with target C can be presented in a maximally simplified form [\[65\]](#page-121-2) as a 2d TFT with a first order action:

$$\int \theta \, \mathrm{d}\zeta \tag{3.1}$$

where both θ and ζ are super-fields consisting of formal sums of forms of all degrees on the worldsheet, with a BRST differential acting as the de Rham differential. Classically, the B-model is a theory of constant maps from the world-sheet to a target space.

The cohomology of the free BRST differential is built from the zero-form components of ζ and θ, with worldsheet derivatives being exact. In order to lighten the notation, we will use the same symbol below for the super-fields and for their zero-form component fields. Higher form components occur via descent relations when superfields are integrated over cycles on the world-sheet to define higher operations and integrated correlation functions. We refer to [\[28\]](#page-119-2) for a general review.

The field ζ is bosonic and has ghost number 0. It represents a holomorphic coordinate on C. The field θ is fermionic and has ghost number 1. Local operators built as polynomials in ζ and θ, i.e. elements of C[ζ, θ], are identified as polyvector fields on C, i.e. elements of C[ζ, ∂<sup>ζ</sup> ].

The identification is strengthened by considering natural algebraic structures on the space of local operators. First of all, polynomial local operators can be safely multiplied: the propagator of the theory pairs 0-form and 1-form components of the superfields.

There is also a "bracket" operation {•, •} where the first descendant of a local operator is integrated on a circle around the other [\[66\]](#page-121-3). In this free theory the bracket involves a single Wick contraction: it satisfies Leibniz rules and acts as

$$\{\theta, \zeta\} = 1 \tag{3.2}$$

It reproduces the Schouten bracket on poly-vector fields.

The field theory meaning of the bracket operation is that it controls the BRST anomalies which may arise when the theory is deformed by some interaction term I(ζ, θ). The anomaly is computed at tree level as

$$\{\mathcal{I}, \mathcal{I}\}\,,$$
 (3.3)

and in particular a deformation is non-anomalous if this vanishes. The product and the bracket define a Gerstenhaber algebra structure on polynomial local operators.

At loop order, one may have higher order perturbative corrections to this result. A "formality theorem" [\[60\]](#page-120-16) provides a scheme where the loop correction vanish and the product and bracket on local operators exactly matches the product and Schouten bracket on polyvector fields.

It is useful to elaborate on the idea that local operators which can be added to the action define the "global symmetry algebra" of the theory. Irrespectively of the BRST anomaly being cancelled or not, a deformation I of the action modifies the BRST differential on local operators to

$$\mathcal{O} \to \{\mathcal{I}, \mathcal{O}\} \tag{3.4}$$

and deforms similarly the action of the BRST charge on any other object in the theory: boundary conditions, defects, etc.

The deformation of the BRST charge is, essentially by definition, a symmetry of the system. If I is a vector field, this is precisely the standard action of the vector field on C.

#### <span id="page-37-0"></span>3.2 Distributional local operators

This simplified presentation of the B-model, as opposed to the full topological twist of a (2,2) sigma model with  $\mathbb{C}$  target, makes it tricky to talk about objects in  $\mathbb{C}$  which are not holomorphic. Some can be described as disorder vertex operators. In particular, we can introduce a family of vertex operators

$$\delta(\zeta - z) \tag{3.5}$$

playing the same role as a distributional vertex operator  $\delta^{(2)}(\zeta - z, \bar{\zeta} - \bar{z})d\bar{\zeta}$  in the twisted sigma model.<sup>19</sup> We assign ghost number 1 to this operator. It is the first member of a tower consisting of derivatives  $\partial_z^n \delta(\zeta - z)$  and of  $\theta \partial_z^n \delta(\zeta - z)$ .

Such distributional vertex operators are typically needed in order to get some sensible correlation functions on a compact Riemann surface, because  $\zeta$  has a zero mode which would make the path integral diverge unless it is soaked by a delta function. It seems reasonable to define the product and bracket of a polynomial local operator and a distributional one, but it does not seem natural to define the product or bracket between two distributional vertex operators.

Distributional local operators should be crucial in defining a holographic dictionary. For example, in a B-model with target space  $SL(2,\mathbb{C})$  we should consider local operators which correspond to the boundary-to-bulk propagators representing boundary insertions in holography. In a  $\lambda \to 0$  limit, we will recognize them as local operators which are distributional in the directions parallel to the original D-branes.

#### <span id="page-37-1"></span>3.3 Boundary conditions in the B-model with target $\mathbb{C}$

We will often employ two types of boundary conditions: Neumann b.c.  $\theta|_{\partial} = 0$  and Dirichlet  $\zeta|_{\partial} = 0$ , possibly deformed to  $\zeta|_{\partial} = z$ . Polynomial boundary local operators are respectively identified with polynomials  $\mathbb{C}[\zeta]$  or  $\mathbb{C}[\theta]$ , with the natural multiplication corresponding to the composition of the corresponding operators. For Neumann b.c. we may also want the boundary version of  $\partial_z^n \delta(\zeta - z)$ .

We should quickly elaborate on the relation between (polynomial) boundary local operators and boundary symmetries. Consider e.g. Neumann boundary conditions. We can modify such boundary conditions by adding a Chan-Paton factor M and a boundary interaction

$$\mathcal{I}^{\partial}(\zeta) \in \operatorname{End}(M)[\zeta].$$
 (3.6)

Such an interaction may give rise to a boundary BRST anomaly, which is precisely

$$\mathcal{I}^{\partial}(\zeta)^2 \tag{3.7}$$

<span id="page-37-2"></span><sup>&</sup>lt;sup>19</sup>Here z labels a point in the target space, not the worldsheet!

and thus "knows" about the algebra structure on the space C[ζ] of polynomial boundary local operators. Furthermore, the interaction induces a BRST differential, by using the commutator of C[ζ] valued matrices [−, −]:

$$\mathcal{O}^{\partial} \to [\mathcal{I}^{\partial}, \mathcal{O}^{\partial}]$$
 (3.8)

on bundary operators

$$\mathcal{O}^{\partial}(\zeta) \in \operatorname{End}(M)[\zeta],$$
 (3.9)

which is a symmetry of the boundary condition (holomorphic rotation of M).

#### <span id="page-38-0"></span>3.4 Disc correlation functions

Dirichlet b.c. give a fermionic zero mode on the disk D<sup>2</sup> , allowing for the definition and calculations of disk correlation functions involving bulk and boundary polynomial vertex operators. In particular, we normalize the disk 1pt function of θ to be 1. Similarly, we normalize the Neumann disk 1pt function of δ(ζ) to be also 1.

There are unique boundary-changing local operators OND and ODN intertwining Neumann and Dirichlet boundary conditions. They are annihilated by the action from the respective sides of θ or ζ boundary local operators. It is natural to normalize these junctions so that the disk correlation function

$$\langle \mathcal{O}_{ND} \, \mathcal{O}_{DN} \rangle_{N,D}^{D^2} = 1 \,, \tag{3.10}$$

with half Neumann and half Dirichlet b.c. is also normalized to 1. Then the fusion of the two junctions to a Dirichlet local operator must produce θ, while the fusion in the opposite direction must produce δ(ζ):

$$\mathcal{O}_{DN} \mathcal{O}_{ND} = \theta_{DD}$$
  $\mathcal{O}_{ND} \mathcal{O}_{DN} = \delta(\zeta)_{NN}$ . (3.11)

There is no BRST-invariant junction between Dirichlet boundary conditions placed at different positions in the target space. It is convenient, though, to represent the (absence of) junctions via a two-dimensional space with a constant z − z ′ differential mapping one summand onto the other. Then at z = z ′ we recover C[θ].

A good way to understand this setup is to describe the Dirichlet b.c. ζ = z as the deformation of the b.c. ζ = 0 by a boundary coupling zθ. Then the boundarychanging local operators between ζ = z and ζ = z ′ are presented as C[θ] equipped by a differential given by multiplication by zθ from the left and z ′ θ from the right, i.e. (z − z ′ )θ. The cohomology vanishes unless z = z ′ .

#### <span id="page-39-0"></span>3.5 Homological algebra and dg-TFT

Homological algebra emerges first in a dg-TFT as one probes the potential BRST anomalies which arise from a deformation of the theory or of a boundary condition. Bulk local operators which can be used to deform the theory are equipped with an L<sup>∞</sup> structure and a compatible product, such as the Gerstenhaber algebra of holomorphic polyvector fields for the B-model with some target space X. Boundary operators which can be used to deform the boundary condition are equipped with an A<sup>∞</sup> structure, such as the algebra of holomorphic functions for Neumann boundary conditions in the Bmodel.

A typical situation is that we are given a brane B and the corresponding A<sup>∞</sup> algebra A, sometimes equipped with the data of some disk correlation functions, and we want to learn information about the bulk local operators of the world-sheet theory it belongs to, or about other D-branes.

The simplest example could be the Dirichlet brane for the B-model with target C: A = C[θ] and the only non-zero disk correlation function is ⟨θ⟩D<sup>2</sup> = 1. The disc correlation function can be thought of as a trace on C[θ]. This is called an "onedimensional Calabi-Yau algebra", because the trace lowers ghost number by 1. It is a good blueprint for situations where we probe a target space by looking at point-like Dbranes, and for non-geometric generalizations of that notion. In general, n-dimensional Calabi-Yau algebras and their generalizations give a standard description of dg-TFTs [\[22,](#page-118-6) [45\]](#page-120-17). We also give a briefe review of various definition of Calabi-Yau algebras and their physical interpretation in Appendix [D.](#page-105-0)

Neumann b.c. provide a more intricate example: A is the algebra C[z], but non-zero disk correlation functions require the insertion of a single distributional boundary local operator. Distributions supported at ζ = 0 can be thought of as the dual space A<sup>∨</sup> , with disk two-point functions giving the duality pairing. We will see that recovering a dg-TFT description of the world-sheet theory from this data is a bit more laborious.

First of all, we can recall two distinct ways to recover bulk local operators from the data of a boundary condition.

#### <span id="page-39-1"></span>3.6 Bulk local operators as symmetries/deformations of the boundary data.

Bulk local operators can be employed to infinitesimally deform the worldsheet theory, which in turn will give an infinitesimal deformation of the boundary A<sup>∞</sup> structure.

There is a hierarchy of possible deformations:

0. The simplest possible effect is that the deformation causes a BRST anomaly on the brane, i.e. a curving of the A<sup>∞</sup> algebra. This is computed simply by bringing the bulk local operator to the boundary. A classic example is a superpotential deformation I(ζ), which generates an anomaly on Neumann b.c. and leads to the theory of matrix factorizations [\[67\]](#page-121-4), i.e. solutions of the boundary BRST anomaly cancellation condition:

$$\mathcal{I}(\zeta) + \mathcal{I}^{\partial}(\zeta)^2 = 0. \tag{3.12}$$

This effect is simply described as a map from bulk local operators to A which preserves ghost number.

- 1. The next simplest effect is that the deformation modifies the BRST differential on boundary local operators. For example, a bulk deformation by ζ will induce Qθ = 1 on Dirichlet b.c, while a bulk θ will induce Qζ = 1 on Neumann b.c. This effect is described as a map from bulk local operators to the space of maps A → A, which lowers the ghost number by 1.
- 2. Bulk deformations can also deform the multiplication of boundary local operators. For example, we will see that in the B-model with target C n , Poisson bivectors give a deformation quantization of the algebra of functions on Neumann bounary conditions. This effect is described at the leading order as a map from bulk local operators to the space of maps A ⊗ A → A, which lowers the ghost number by 2.
- 3. Deformations of boundary n-ary operations are described by a map from bulk local operators to the space of maps A<sup>⊗</sup><sup>n</sup> → A, which lowers the ghost number by n.

A collection h of maps A<sup>⊗</sup><sup>n</sup> → A for all n, lowering ghost number by n, is by definition an element of the Hochschild complex CH• (A, A). The complex is equipped with a differential QCH, such that the map from bulk local operators to CH• (A, A) intertwines the bulk BRST charge and QCH. [20](#page-40-0)

In other words, there is a chain map from the space of bulk local operators which can deform the theory (which we expect to include polynomial ones, but not distributional ones) to the Hochschild cohomology HH• (A, A) for the algebra of boundary operators. This chain map is often a quasi-isomorphism of complexes, and should also extend to a quasi-isomorphism of L<sup>∞</sup> algebras or E<sup>2</sup> algebras. Intuitively, we expect it to capture all bulk local operators which can act on the brane.

<span id="page-40-0"></span><sup>20</sup>A small subtlety which we will typically neglect is that A is unital and n-ary operations by definition act trivially on the identity. Physically, the identity operator has trivial descendants. Accordingly, one should employ the relative Hochschild complex CH• rel(A, A) of maps (A/C1)<sup>⊗</sup><sup>n</sup> → A here and elsewhere in the paper. Furthermore, if B is a direct sum of elementary D-branes and A is secretly a category, the definition of relative Hochschild complex should be further amended to remove identity operators for each individual D-brane. See a discussion in Section [6.](#page-61-0)

We will denote the maps associated to a local operator I as

$$\{\mathcal{I}|\bullet,\cdots,\bullet\}_n$$
. (3.13)

We can also push the deformation theory beyond the leading order. The Hochschild complex CH• (A, A) is equipped with a bracket, which is roughly defined by summing over all possible ways one map can be composed with the other and makes it into a dg-Lie algebra. Deformations satisfy a Maurer-Cartan equation QCHI + {I, I} = 0 which must be the image of the MC equation satisfied by the bulk local operators defining the deformations.

In other words, the map from bulk local operators to the Hochschild complex CH• (A, A) is a morphism of L<sup>∞</sup> algebras. This map can be rather non-trivial. For example, in the case of the B-model with target C <sup>n</sup> and Neumann b.c., a bulk deformation given by a Poisson bivector I modifies the boundary algebra in a way which is highy non-linear in I, giving the corresponding deformation-quantization star-product. The coefficients are the higher maps

$$\mathbb{C}[\zeta_i, \theta^i]^{\otimes k} \to \mathrm{CH}^2(\mathbb{C}[\zeta_i], \mathbb{C}[\zeta_i])$$
(3.14)

in the morphism of L<sup>∞</sup> algebras are computed by certain loop Feynman diagrams [\[60\]](#page-120-16).

In our analysis, we will often encounter situations where a theory and boundary conditions are assembled by stacking simpler theories and boundary conditions. For example, a B-model with target space C 3 can be obtained by stacking three copies of the B-model with target space C. A brane wrapping C ⊂ C 3 can be obtained by stacking a Neumann b.c. in one direction and Dirichlet b.c. in other directions.

If we are given two systems with boundary A<sup>∞</sup> algebras A<sup>1</sup> and A2, the algebra for the combined system will be a tensor product A<sup>1</sup> ⊗ A2. [21](#page-41-0) Bulk local operators should also be the tensor product of the operators in the two factors. It turns out that there is an isomorphism of Gerstenhaber algebra [\[68\]](#page-121-5):

$$\mathrm{HH}^{\bullet}(A_{1}\otimes A_{2},A_{1}\otimes A_{2})\simeq \mathrm{HH}^{\bullet}(A_{1},A_{1})\otimes \mathrm{HH}^{\bullet}(A_{2},A_{2}) \tag{3.15}$$

which should be compatible with the analogous statement for bulk local operators.

Notice that we only discussed brackets of bulk local operators for now, and not the product. This is because the product does not have an immediate interpretation as a BRST anomaly. Stacking offers a somewhat indirect interpretation: the bracket in a product system is the combination of the bracket in one of the two factors and

<span id="page-41-0"></span><sup>21</sup>The definition of tensor product for A<sup>∞</sup> algebras is typically scheme-dependent, but when at least one of two factors is a dg-algebra, we can take the standard tensor product.

the product in the other factor. Correspondingly, the Hochschild complex can be equipped with a product as well, making it into a Gerstenhaber algebra [\[69\]](#page-121-6) in a manner compatible with the bulk product.

#### <span id="page-42-0"></span>3.7 Hochschild cohomology and Dirichlet boundary conditions

We can illustrate these ideas for the case of the B-model with C target space and Dirichlet b.c., so that A = C[θ] and bulk local operators are C[ζ, θ]:

0. The "bulk to boundary" map is the obvious C[ζ, θ] → C[θ] given by setting ζ = 0:

$$\{1|\}_0 = 1$$
  $\{\theta|\}_0 = \theta$  (3.16)

and everything else vanishes.

1. The deformation of the differential arises from a Feynman diagram with a single Wick contraction, so it requires the presence of a single factor of ζ and removes a θ from the boundary operator:

$$\{\zeta|\theta\}_1 = 1 \qquad \{\theta\zeta|\theta\}_1 = \theta. \tag{3.17}$$

2. More generally (we are not careful here with overall non-zero coefficients),

$$\{\zeta^n|\theta,\cdots,\theta\}_n=1$$
  $\{\theta\zeta^n|\theta,\cdots,\theta\}_n=\theta$  (3.18)

and everything else vanishes.

The above physical considerations can be summarized as yielding a tower of maps C[ζ, θ] → Hom(C[θ] ⊗n , C[θ]). Simple computation shows that these maps preserve the Hochschild differential, and hence define a chain map C[ζ, θ] → CH• (C[θ], C[θ]). With a little bit more work one can show that it is a quasi-isomorphism [\[70\]](#page-121-7). Therefore, polynomial bulk local operators are thus fully accounted by the Hochschild cohomology, i.e.

$$\mathrm{HH}^{\bullet}(\mathbb{C}[\theta], \mathbb{C}[\theta]) \simeq \mathbb{C}[\zeta, \theta]. \tag{3.19}$$

#### <span id="page-42-1"></span>3.8 Hochschild cohomology and Neumann boundary conditions

In the case of the B-model with C target space and Neumann b.c., we have A = C[ζ] and bulk local operators are C[ζ, θ]:

0. The "bulk to boundary" map is the obvious C[ζ, θ] → C[ζ] given by setting θ = 0:

$$\{\zeta^n|\}_0 = \zeta^n \tag{3.20}$$

and everything else vanishes.

1. The deformation of the differential arises from a Feynman diagram with a single Wick contraction:

$$\{\zeta^n \theta | \zeta^m\}_1 = m \zeta^{n+m-1}. \tag{3.21}$$

2. Bulk interactions cannot give any higher deformations.

As in the discussion of the previous section, the above physical analysis gives rise to a chain map C[ζ, θ] → CH• (C[ζ], C[ζ]), which is in fact a quasi-isomorphism. Therefore, polynomial bulk local operators are thus fully accounted by the Hochschild cohomology, i.e.

$$\mathrm{HH}^{\bullet}(\mathbb{C}[\zeta], \mathbb{C}[\zeta]) \simeq \mathbb{C}[\zeta, \theta]. \tag{3.22}$$

#### <span id="page-43-0"></span>3.9 Disc correlation functions and HH• (A, A<sup>∨</sup> )

Another probe of bulk local operators are correlation functions on the disk, with one bulk insertion, one boundary insertion and possibly n integrated boundary insertions. Each bulk operator o thus gives maps

$$(o|\bullet;\bullet,\cdots,\bullet)_n$$
 (3.23)

from A<sup>⊗</sup>(n+1) to the complex numbers, or equivalently from A<sup>⊗</sup><sup>n</sup> to A<sup>∨</sup> .

A collection of such maps defines an element of the Hochschild complex CH• (A, A<sup>∨</sup> ). The complex is again equipped with a differential QCH, such that the map from bulk local operators to CH• (A, A) intertwines the bulk BRST charge and QCH.

Depending on the choice of D-brane, the bulk operators detected by CH• (A, A<sup>∨</sup> ) may be normalizable or distributional. For example, in the case of the B-model with target space C:

• For the Dirichlet boundary condition, C[θ] ∨ is essentially equivalent to C[θ] and CH• (C[θ], C[θ] ∨ ) reproduces the polynomial bulk operators C[ζ, θ]. For example,

$$(1|\theta;)_0 = 1$$
  $(\theta|1;)_0 = 1$   $(\zeta|\theta;\theta)_0 = 1$  (3.24)

etcetera.

• For Neumann b.c., disk correlation functions with boundary operators in C[ζ] detect distributional bulk states. For example,

$$(\delta(\zeta)|1;)_0 = 1 \qquad (\partial^n \delta(\zeta)|\zeta^n;)_0 = n! \qquad (\theta\delta(\zeta)|1;\zeta)_0 = 1 \qquad (3.25)$$

etcetera. Polynomial bulk operators can be detected if we use distributional boundary operators, but this brings us back to HH• (A, A).

The CH• (A, A<sup>∨</sup> ) complex is not equipped with a product or bracket, but there are mixed products and brackets with elements of CH• (A, A): intuitively, symmetries act on disk correlation functions.

#### <span id="page-44-0"></span>3.10 Equivariant bulk local operators and HC• (A)

It is also possible to consider disk correlation functions with a bulk local operator but without boundary insertions, or with all integrated boundary insertions. An important subtlety is that such configurations are rotationally invariant and thus involve rotationinvariant bulk local operators. In a BRST setting, this notion needs to be refined to rotation-equivariant bulk local operators. In String Theory, rotation-equivariant bulk local operators are precisely the building blocks of closed string states [\[39\]](#page-119-12)! [22](#page-44-1) For example, in the B-model, rotation-equivariant bulk local operators correspond to divergence-free polyvector fields, which are the building blocks of BCOV theory.

These disk correlation functions thus map rotation-equivariant bulk operators to cyclic (i.e. Zn-invariant) maps A<sup>⊗</sup><sup>n</sup> → C, which we denote as

$$(c|\bullet,\cdots,\bullet)_n$$
. (3.26)

This leads to the definition of the cyclic cohomology complex CC• (A), with cohomology HC• (A) [\[70\]](#page-121-7). This is roughly the cyclic-invariant part of HH•−<sup>1</sup> (A, A<sup>∨</sup> ). This intuition is made precise by the Connes construction, which involves a map B on HH• (A, A<sup>∨</sup> ) that is the analogue of the divergence operation on polyvector fields.

For the B-model on C, divergence-free polynomial polyvector fields consist of C[ζ]⊕ θC. Distributional divergence-free polyvector fields consist of C[∂]δ(ζ).

• For the Dirichlet boundary condition, we have disk correlation functions

$$(\theta|)_0 = 1$$
  $(\zeta^{n-1}|\theta, \dots, \theta)_n = \frac{1}{n}.$  (3.27)

An useful string theory intuition to understand these formulae is that a polyvector field nζ<sup>n</sup>−<sup>1</sup> can be identified with the 1-form nζ<sup>n</sup>−<sup>1</sup>dζ, whose primitive ζ n evaluated at the location z of a Dirichlet brane gives the disk correlation function deformed by a zθ boundary interaction.

• For Neumann b.c., we have disk correlation functions

$$(\partial^n \delta(\zeta) | \zeta^n)_1 = n! \,. \tag{3.28}$$

There is an action of CH• (A, A) on CC• (A), describing the action of symmetries on disc correlation functions.

<span id="page-44-1"></span><sup>22</sup>In conformal gauge, this is the statement that the BRST cohomology of string states is computed by removing the ghost zero mode c<sup>0</sup> − c¯<sup>0</sup> corresponding to rotations and imposing rotational symmetry/level matching by hand. It is a relative BRST cohomology, due to the fact that the rotation sub-group of the diffeomorphisms group is compact.

#### <span id="page-45-0"></span>3.11 Branes, modules and tensor products

We can also use a specific reference D-brane B to probe other D-branes B', through the properties of boundary-changing local operators. The spaces  $M_{BB'}$  and  $M_{B'B}$  of boundary-changing local operators are naturally left- and right-  $(A_{\infty})$  modules for A, by composition of local operators along the boundary. These modules encode many properties of B'.

Boundary local operators on B' can be probed in multiple ways:

- They can act on boundary-changing local operators. Parsing definitions, this gives a chain map from local operators on B' to endomorphisms of  $A_{\infty}$  modules for  $M_{BB'}$  and for  $M_{B'B}$ . This will typically capture normalizable operators on B'. We can also vary the choice of B', building a whole functor from the  $A_{\infty}$  category of branes to the dg-categories of left- and right- A-modules. <sup>23</sup>
- We can also compose boundary-changing local operators to produce (possibly distributional) operators on B'. Parsing definitions, this gives a chain map from the derived tensor product  $M_{B'B} \otimes_A M_{BB'}^{24}$  to a space of (possibly distributional) local operators on B'.
- If disk correlation functions are available, they will instead give a pairing between a space of (possibly distributional) local operators on B' and  $M_{B'B} \otimes_A M_{BB'}$ .

These maps and structures can be combined with the relations to bulk operators, and there are several Homological Algebra constructions which encode these combinations. They guarantee, say, that  $HH^{\bullet}(A, A)$  maps to the Hochschild cohomology of local operators on B', etc.

#### <span id="page-45-1"></span>3.12 B-model probe branes

As an illustration, we can describe branes in the B-model with target  $\mathbb{C}$  using the Dirichlet brane as a reference, with  $A = \mathbb{C}[\theta]$ . The Neumann brane is described by trivial one-dimensional modules. As the disk correlation functions in this B-model have a one unit of ghost number anomaly, if we set  $M_{DN} = \mathbb{C}$  in ghost number 0, then  $M_{ND} = \mathbb{C}[1]$  is supported on ghost number 1.

The  $A_{\infty}$  endomorphisms of  $\mathbb{C}$  as a  $\mathbb{C}[\theta]$ -module are a collection of maps  $\mathbb{C}[\theta]^{\otimes n} \to \mathbb{C}$  which lower the ghost number by n, deforming the module action. The maps  $\theta^{\otimes n} \to 1$  represent the  $\zeta^n$  local operators on the Neumann b.c.

<span id="page-45-2"></span> $<sup>^{23}</sup>$ As we briefly mentioned for the Hochschild cohomology, we should really consider notions of morphisms appropriate to *unital* algebras and modules.

<span id="page-45-3"></span><sup>&</sup>lt;sup>24</sup>We use the symbol  $\otimes_A$  to denote derived tensor product  $\otimes_A^{\mathbb{L}}$  throughout the paper

The derived tensor product MND⊗AMDN , on the other hand, includes summands of the form MND ⊗A<sup>⊗</sup><sup>n</sup>⊗MDN in ghost number shifted by −n, with a specific differential. Here the elements C[1] ⊗ θ <sup>⊗</sup><sup>n</sup> ⊗ C represent the distributional local operators ∂ n δ(z). For example, a local operator defined by going from Neumann to Dirichlet and back to Neumann b.c. clearly forces ζ → 0 and is identified with δ(z).

In general, a C[θ] A<sup>∞</sup> module MDB consists of some vector space V and a collection of maps V → V of ghost number 1 representing the action of n θ's. We can collect all the maps into a polynomial differential d(ζ) on V , which satisfies d(ζ) <sup>2</sup> = 0 by the module axioms. It is not hard to see that this coincides with the standard "tachyon condensation" presentation of B-model D-branes as a complex on C. We can think about that as an enriched Neumann brane, with Chan-Paton factor V and boundary interaction I ∂ (ζ) = d(ζ).

In this situation, the dual module MBD will coincide with V ∨ [1] with transpose differential. The derived tensor product should coincide with distributional maps on V with a [d(ζ), •] differential.

The case of reference Neumann boundary conditions can be analyzed in a similar fashion. Here we simply report the description of Dirichlet local operators:

$$M_{DN} \otimes_A M_{ND} = \mathbb{C} \otimes_{\mathbb{C}[\zeta]} \mathbb{C}[1] = \mathbb{C}[\theta].$$
 (3.29)

#### <span id="page-46-0"></span>3.13 B-model on C n

The B-model on C n can be presented in terms of (super)fields ζ<sup>i</sup> and θ i . Polynomial local operators form the algebra C[ζ<sup>i</sup> , θ<sup>i</sup> ] which is identified with holomorphic polyvectorfields on C n , with bracket induced from

$$\{\theta^i, \zeta_j\} = \delta^i_j. \tag{3.30}$$

Rotation-equivariant local operators are identified with divergence-free holomorphic polyvector fields. General branes can be presented as enriched Neumann b.c., in terms of a (graded super-)vector space V equipped with a nilpotent differential d(ζ).

These structures are all naturally recoverable by looking at a Dirichlet brane probe ζ<sup>i</sup> |<sup>∂</sup> = 0, with boundary local operators A = C[θ i ]. The Hochschild cohomology HH• (A, A) is well-behaved under tensor product and thus must be isomorphic to C[ζ<sup>i</sup> , θ<sup>i</sup> ], the polynomial local operators. The Hochschild cohomology HH• (A, A<sup>∨</sup> ) is isomorphic to HH• (A, A), via the pairing (ab) on A, with (θ 1 · · · θ n ) = 1 being the disk boundary 1-pt function. It is useful to think about HH• (A, A<sup>∨</sup> ) as holomorphic (•, 0) forms, by contracting the polyvector fields with the top form dζ<sup>1</sup> · · · dζn.

Cyclic cohomology HC• (A) can be recovered from Connes construction, the role of B being played by the ∂ operator acting on (•, 0) forms. The result is ∂-closed holomorphic (•, 0) forms, i.e. divergence-free polyvector fields. This computation is somewhat indirect, as it goes through the non-trivial tensor product quasi-isomorphism for CH• (A, A<sup>∨</sup> ) and Connes construction.

A useful perspective which we will explore further in the next section is that a ∂ closed holomorphic form α on C <sup>n</sup> has a primitive ∂ <sup>−</sup><sup>1</sup>α which is what enters a D-brane's action. In particular, a cyclic homology element such as

$$(c|\theta^{i_1},\cdots,\theta^{i_n}) = c^{(i_1\cdots i_n)} \tag{3.31}$$

with a totally symmetric right hand side and other entries being 0 represents a coupling of the Dirichlet brane to a function c (i1···in) ζi1 · · · ζ<sup>i</sup><sup>n</sup> and thus the ∂-closed holomorphic (1, 0) form

$$\partial(c^{(i_1\cdots i_n)}\zeta_{i_1}\cdots\zeta_{i_n}). \tag{3.32}$$

We can present (but not justify here) a neat generalization of this statement. Introduce the algebra C[θ i , dθ<sup>i</sup> ] equipped with the obvious differential d. It is easy to see that a form ∂ <sup>−</sup><sup>1</sup>α, which is defined up to ∂-exact forms, defines a linear function on d-closed elements of C[θ i , dθ<sup>i</sup> ], which pairs up θ <sup>i</sup> with dζ<sup>i</sup> and dθ<sup>i</sup> with ζ<sup>i</sup> . We can extend that to an element of HC• (C[θ i ]) as follows: act with d on all arguments, multiply them together and pair them with ∂ <sup>−</sup><sup>1</sup>α

Finally, other D-branes can be probed as A<sup>∞</sup> modules for C[θ i ], giving directly the data of V and d(ζ).

If we replace the Dirichlet branes in the analysis with some other probe branes, we may encounter various distributional local operators. The main actor in this paper will be D-branes wrapping a C factor in C 3 , which have an algebra A = C[θ 1 , θ<sup>2</sup> , ζ3]. While the Hochschild cohomology HH• (A, A) still recovers polynomial polyvector fields, HH• (A, A<sup>∨</sup> ) and HC• (A) involve polyvector fields which are distributional in the ζ<sup>3</sup> direction, interacting with the C D-brane at a specific point.

#### <span id="page-47-0"></span>3.14 B-model with target C <sup>2</sup>/Γ

Finally, we discuss an orbifold geometry which appears in generalizations of the Twisted Holography setup. The ADE singularities can be defined as the orbifold of C <sup>2</sup> by the action of a discrete subgroup Γ of SU(2) which fixes the origin. Correspondingly, the B-model on C <sup>2</sup>/Γ can be obtained from the B-model on C <sup>2</sup> by an orbifold by Γ.

It is particularly useful to think about the behaviour of Dirichlet branes under the orbifold:

• A Dirichlet brane in C 2 supported away from the origin combines with its Γ images and survives the orbifold to give a Dirichlet brane in C <sup>2</sup>/Γ supported away from the origin.

• A Dirichlet brane at the origin of C <sup>2</sup> decomposes under the orbifold to a collection of "exceptional branes" supported at the origin of C <sup>2</sup>/Γ.

A Dirichlet brane supported away from the origin will decompose to a collection of exceptional branes at the origin.

Denote as C[Γ] the vector space with a basis labelled by elements of Γ. The direct sum of Γ images of a Dirichlet brane away from the origin of C 2 , can be brought to the origin to give a Dirichlet brane with CP factor C[Γ]. The local operators on such a brane Dtot form the matrix algebra

$$\operatorname{End}(\mathbb{C}[\Gamma])[\theta^1, \theta^2] \tag{3.33}$$

with elements of the form eg,g′, eg,g′θ i , eg,g′θ 1 θ 2 , with

$$e_{g,g'}e_{g'',g'''} = \delta_{g',g''}e_{g,g'''}.$$
 (3.34)

The orbifold projects that algebra to the Γ-invariant part

$$A \equiv \operatorname{End}(\mathbb{C}[\Gamma])[\theta^1, \theta^2]^{\Gamma}, \qquad (3.35)$$

where Γ acts simultaneously on the θ <sup>i</sup> as an SU(2) rotation and on the basis element by group multiplication. The individual exceptional branes in Dtot are identified as idempotent elements in the ghost number 0 part End(C[Γ])<sup>Γ</sup> .

It is useful to identify C[Γ] as the group algebra. It contains every irreducible representation R<sup>i</sup> of Γ exactly dim R<sup>i</sup> times. Indeed, it is a know result (see e.g. [\[71\]](#page-121-8)) that C[Γ] decomposes as

$$\mathbb{C}[\Gamma] = \bigoplus_{i} R_i \otimes R_i^{\vee} \tag{3.36}$$

under the left- and right- actions of Γ.

Then by Schur's lemma, End(C[Γ])<sup>Γ</sup> coincides with

$$\operatorname{End}(\mathbb{C}[\Gamma])^{\Gamma} = \bigoplus_{i} 1_{R_i} \otimes \operatorname{End}(R_i). \tag{3.37}$$

We interpret this as giving a decomposition

$$D_{\text{tot}} = \bigoplus_{i} D_i \otimes R_i \,, \tag{3.38}$$

where the exceptional branes D<sup>i</sup> are labelled by irreducible representations of Γ and appear dimR<sup>i</sup> times in Dtot.

We can then decompose the whole algebra A into a category of exceptional branes Di :

$$\operatorname{End}(\mathbb{C}[\Gamma])[\theta^1, \theta^2]^{\Gamma} = \bigoplus_{i,j} \operatorname{Hom}(R_i, R_j)[\theta^1, \theta^2]^{\Gamma} \otimes \operatorname{Hom}(R_i, R_j). \tag{3.39}$$

The first factor can be computed by decomposing

$$R_j[\theta^1, \theta^2] = \bigoplus_i R_i \otimes \operatorname{Hom}(R_i, R_j)[\theta^1, \theta^2]^{\Gamma}$$
(3.40)

into irreducible representations of Γ, with coefficients Hom(R<sup>i</sup> , R<sup>j</sup> )[θ 1 , θ<sup>2</sup> ] Γ .

We learn that Hom(R<sup>i</sup> , R<sup>j</sup> )[θ 1 , θ<sup>2</sup> ] Γ contains the local operators from D<sup>i</sup> to D<sup>j</sup> . In particular, at ghost numbers 0 and 2 we have a single element between D<sup>i</sup> and D<sup>i</sup> , while at ghost number 1 we have a generator for every time R<sup>i</sup> enters in the tensor product of R<sup>j</sup> and the fundamental representation of Γ. This is the number of edges in the "affine ADE quiver" associated to Γ.

An orbifold has two effects on local operators: it projects to Γ-invariants but it can also add new twisted sectors, which in the original theory are local operators living at the end of topological line defects which implement the action of elements in Γ.

The Hochschild cohomology of A reproduces, non-trivially, this statement. It includes the Γ-invariant part of the Hochschild cohomology of C[θ 1 , θ<sup>2</sup> ], but also twisted sectors localized at the origin of the ADE singularity [\[72\]](#page-121-9).

Another useful perspective on branes in the orbifold theory is that they can be understood in terms of a vector space V equipped with a Γ action and a differential d(ζ) compatible with that action. In particular, setting d(ζ) = 0 gives us a variant N<sup>i</sup> of Neumann b.c. for every irreducible representation R<sup>i</sup> , which has a one-dimensional space of junctions with D<sup>i</sup> and zero-dimensional with other D<sup>j</sup> Dirichlet branes.

## <span id="page-49-0"></span>4 Homological algebra in the λ → 0 limit.

We are now equipped to review the computation of the tree-level (aka planar, λ → 0) BRST cohomology of single-trace operators. Recall that the chiral algebra describes the world-volume theory of N D1 branes in C 3 . Concretely, the D1 brane is a boundary condition B in the B-model which combines Dirichlet b.c. ζ1|<sup>∂</sup> = ζ2|<sup>∂</sup> = 0 in two directions and Neumann θ3|<sup>∂</sup> = 0 in the third. Boundary local operators on B form the algebra C[θ 1 , θ<sup>2</sup> , ζ3].

The chiral algebra fields are couplings for a general deformation of the stack of D-branes:

$$\Phi(\theta^1, \theta^2, \zeta_3) \equiv c(\zeta_3) + X(\zeta_3)\theta^1 + Y(\zeta_3)\theta^2 + b(\zeta_3)\theta^1\theta_2.$$
 (4.1)

We denote this sort of object, which pairs up the fields and their derivatives with the corresponding boundary vertex operators, a generating field. The tree-level BRST transformations of the generating field are neatly expressed in terms of algebra structure:

$$Q_0 \Phi = \Phi \Phi \,. \tag{4.2}$$

Conversely, any tree-level BRST differential for a gauge theory with single-trace action can be interpreted as arising from an  $A_{\infty}$  algebra and thus a world-sheet dg-TFT. The 2d chiral gauge theory arises from  $\mathbb{C}[\theta^1, \theta^2, \zeta_3]$ .

The deformation  $\Phi$  of the stack of D-branes changes the coupling of the closed string modes to the D-branes, i.e. the disk bulk 1-pt functions. In an Homological Algebra language, the disc 1-pt function of a bulk rotation-equivariant local operator  $\mathfrak c$  becomes

$$\mathcal{O}_{\mathfrak{c}} \equiv \frac{1}{n\hbar} \operatorname{Tr} (\mathfrak{c}|\Phi, \cdots, \Phi)_n.$$
 (4.3)

Here, the map  $\mathfrak{c}$  acts on the algebra elements and the fields are brought out of the map by linearity, up to Koszul signs. They are then composed as matrices and traced. We included a factor of  $\hbar^{-1}$  because of the disk topology.

Essentially by definition of the cyclic cohomology complex, the action of  $Q_0$  on  $\Phi$  is intertwined with the action of the differential  $Q_{\rm CC}$  on  $\mathfrak{c}$ . We have thus gained an immediate identification:

- The cohomology of single-trace local operators coincides with  $HC^{\bullet}(\mathbb{C}[\theta^1, \theta^2, \zeta_3])$ .
- The identification encodes the coupling of a closed string state to the stack of D-branes.

The closed string state is a divergence-free polyvector field which is distributional in the  $\zeta_3$  direction and couples to the stack of D1 branes at a point via a specific single-trace operator built from the world-volume fields on the D-brane.

In the BCOV description of the B-model string theory, the distributional holomorphic polyvector field is mapped to a form  $\alpha$  and  $\partial^{-1}\alpha$  is restricted to the D-brane world-volume and coupled to the fields there. The space of divergence-free polyvector fields in  $\mathrm{HC}[\mathbb{C}[\theta^1,\theta^2,\zeta_3]]$  reproduce the single-trace operators in the four towers together with their derivatives:

• An  $\mathcal{A}_{a,b}(z)$  single-trace operator is induced from

$$\partial^{-1}\alpha = \zeta_1^a \zeta_2^b \delta(\zeta_3 - z) d\zeta_3 \tag{4.4}$$

i.e. a divergence-free polyvector field

$$\beta = \delta(\zeta_3 - z)(a\zeta_1^{a-1}\zeta_2^b\partial_{\zeta_2} - b\zeta_1^a\zeta_2^{b-1}\partial_{\zeta_1}). \tag{4.5}$$

• An  $\mathcal{B}_{a,b}(z)$  single-trace operator is induced from

$$\alpha = \zeta_1^a \zeta_2^b \delta(\zeta_3 - z) d\zeta_1 d\zeta_2 d\zeta_3. \tag{4.6}$$

• An Ca,b(z) single-trace operator is induced from

$$\partial^{-1}\alpha = \zeta_1^a \zeta_2^b \delta(\zeta_3 - z). \tag{4.7}$$

• A Da,b(z) single-trace operator is induced from

$$\alpha = \zeta_1^a \zeta_2^b \delta(\zeta_3 - z) d\zeta_1 d\zeta_2 + (\cdots) \delta'(\zeta_3 - z) d\zeta_3, \qquad (4.8)$$

where the ellipses denotes an appropriate 1-form to make it ∂-closed. There is a mixing with ∂Aa,b(z) which can be resolved by imposing a quasi-primary condition.

In particular, this proves that the four towers exhaust the single-trace cohomology!

Another route to produce representatives of Q<sup>0</sup> cohomology classes is to define the extended algebra C[θ 1 , θ<sup>2</sup> , ζ3, dθ<sup>1</sup> , dθ<sup>2</sup> , dζ3], equipped with the de Rham operator d. We can thus define the generating field dΦ, which transforms as

$$Q_0 d\Phi = [\Phi, d\Phi]. \tag{4.9}$$

Accordingly,

$$\frac{1}{\hbar n} \operatorname{Tr} (d\Phi)^n \tag{4.10}$$

is Q0-closed. It is also d-closed, and we can expand it into a basis of closed forms in the θ 1 ,θ <sup>2</sup> and ζ<sup>3</sup> variables. The coefficients of the expansion will be a basis of HC• (C[θ 1 , θ<sup>2</sup> , ζ3]).

#### <span id="page-51-0"></span>4.1 The Global Symmetry Algebra at tree-level

At tree-level, the modes in the global symmetry algebra L<sup>0</sup> act on other single-trace operators by a single Wick contraction and thus by mapping an adjoint field to a sequence of adjoint fields:

$$o: \quad \Phi \to \{o|\}_0 + \{o|\Phi\}_1 + \{o|\Phi,\Phi\}_2 + \cdots.$$
 (4.11)

For example, the modes of <sup>1</sup> <sup>n</sup><sup>ℏ</sup>Tr X<sup>n</sup> acts as

$$\left(\frac{1}{n\hbar}\operatorname{Tr} X^{n}\right)_{k}: Y(\zeta_{3}) \to \zeta_{3}^{k} X(\zeta_{3})^{n-1}$$
(4.12)

i.e. the maps

$$\left\{ \left( \frac{1}{n\hbar} \operatorname{Tr} X^n \right)_k | \theta_1 \zeta_3^{k_1}, \cdots, \theta_1 \zeta_3^{k_{n-1}} \right\}_{n-1} = \theta_2 \zeta_3^{k_1 + \dots + k_{n-1} + k}.$$
(4.13)

This type of transformations define elements in the HH• (C[θ 1 , θ<sup>2</sup> , ζ3], C[θ 1 , θ<sup>2</sup> , ζ3]) and can thus be directly compared to normalizable local operators in the world-sheet theory (B-model on C 3 ), i.e. to polynomial polyvector field in C 3 .

A natural perspective on this is that a mode of L<sup>0</sup> could be added to the BRST charge of the chiral algebra, leading to a deformation of the BRST transformation of Φ and thus of the A∞-algebra structure on C[θ 1 , θ<sup>2</sup> , ζ3], which is an element of HH• (C[θ 1 , θ<sup>2</sup> , ζ3], C[θ 1 , θ<sup>2</sup> , ζ3]).

We expect L<sup>0</sup> to actually correspond to the λ → 0 limit of divergence-free holomorphic polynomial polyvector fields in SL(2, C). These are the same as divergence-free holomorphic polynomial polyvector fields in C <sup>3</sup> which satisfy a certain growth condition at large ζ3. The latter condition can be removed by looking at all non-negative modes of single-trace operators, which define a Lie algebra at λ → 0. The restriction to the modes to L<sup>0</sup> can be expressed geometrically by promoting ζ<sup>3</sup> to a CP 1 coordinate and the whole geometry to O(−1) ⊕ O(−1) → CP <sup>1</sup> with coordinates ζ1, ζ2, ζ1ζ<sup>3</sup> and ζ2ζ3. This is the natural geometry where N D1 branes would reproduce the chiral algebra on the sphere.

The divergence-free condition is trickier to understand. It must be associated to the fact that not all possible deformations of the BRST charge should be expressible as modes of single-trace operators. We do not have a good Homological Algebra understanding of this condition beyond checking that it is satisfied by the images of the maps

$$HC^{\bullet}(\mathbb{C}[\theta^1, \theta^2, \zeta_3]) \to HH^{\bullet}(\mathbb{C}[\theta^1, \theta^2, \zeta_3], \mathbb{C}[\theta^1, \theta^2, \zeta_3])$$

$$(4.14)$$

given by taking the modes of single-trace operators. We leave this question as an open problem.

#### <span id="page-52-0"></span>4.2 The mesons at λ → 0.

Neumann branes P in C <sup>3</sup> have junctions to B described by C[ζ3]. We identify the (anti)fundamental matter fields I(ζ3) and J(ζ3) we introduced before as world-volume fields associated to these boundary-changing local operators.

As discussed at greater length in the next section, the Q<sup>0</sup> cohomology of mesonic operators is dual to the derived tensor product

$$\mathbb{C}[\zeta_3] \otimes_{\mathbb{C}[\theta^1, \theta^2, \zeta_3]} \mathbb{C}[\zeta_3] \simeq \mathbb{C}[\zeta_1, \zeta_2, \zeta_3]. \tag{4.15}$$

It is identified with a space of local operators on P which can enter a disk correlation function with a B segment, i.e. functions of the form ζ a 1 ζ b 2∂ n δ(ζ3). This matches the M tower of mesons.

Modes of the open symmetry algebra P<sup>0</sup> map naturally into the (derived) endomorphisms of C[ζ3] as a C[θ 1 , θ<sup>2</sup> , ζ3] module, and coincide with polynomial vertex operators C[ζ1, ζ2, ζ3] on P. The restriction to modes in the correct range gives holomorphic functions which extend to O(−1) ⊕ O(−1) → CP 1 .

The action of L<sup>0</sup> onto P<sup>0</sup> gives a perspective on matching L<sup>0</sup> to polyvector fields which we have seen extends nicely to non-zero λ:

- 1. Modes of operators in the Ba,b tower are directly mapped by the mesonic part of the BRST differential to modes in P0.
- 2. Modes of operators in the Aa,b and Da,b towers act as derivations on P0.
- 3. Modes of operators in the Ba,b tower added to the BRST differential will modify the product structure constants of P0.

These three statements map L<sup>0</sup> into the Hochschild cohomology HH• (P0, P0).

#### <span id="page-53-0"></span>4.3 Determinants at λ → 0.

The basic giant graviton brane at λ → 0 is a probe brane D which has Dirichlet b.c. ζ1|<sup>∂</sup> = ζ3|<sup>∂</sup> = 0 and Neumann θ 2 |<sup>∂</sup> = 0. The junctions to B are controlled by C[θ 1 ]. The m parameter can be introduced by setting ζ1|<sup>∂</sup> = −m instead, and u by fixing a linear combination (ζ<sup>1</sup> + uζ2)|∂.

As we have seen, the integral defining determinant operators can be presented in a BV formalism. The auxiliary fermions ψ and ψ¯ and their anti-fields u and ¯u enter in a BV action [\(2.42\)](#page-30-1) which generalizes ψXψ ¯ . The BRST differential is consistent with the identification of ψ + θ <sup>1</sup>u and ψ¯ + θ <sup>1</sup>u¯ as the open string fields stretched between the branes. [25](#page-53-1)

The computation of the tree-level BRST cohomology of determinant modifications reduces to the computation of the dual to the derived tensor product

$$\mathbb{C}[\theta_1] \otimes_{\mathbb{C}[\theta^1, \theta^2, \zeta_3]} \mathbb{C}[\theta_1], \qquad (4.16)$$

which coincide with the space C[θ 1 , ζ<sup>2</sup> , θ3] of polynomial boundary local operators on D. The ζ <sup>2</sup> variable is clearly dual to Y insertions. An explicit description of the cohomology of determinant modifications goes beyond the scope of our discussion.

Open modifications, instead, are dual to

$$\mathbb{C}[\zeta_3] \otimes_{\mathbb{C}[\theta^1, \theta^2, \zeta_3]} \mathbb{C}[\theta_1], \qquad (4.17)$$

<span id="page-53-1"></span><sup>25</sup>Several aspects of the construction and computation of open modifications described in this Section originally emerged in unpublished work with Kasia Budzik.

which is the space C[ζ2] of junctions between P and D. These reproduce the IY <sup>n</sup>ψ open modifications of determinant operators we employed in explicit calculations. We now give a dg-TFT interpretation of these calculations.

In order to study a non-trivial saddle for a collection of determinant operators, we would start from a collection of branes

$$\zeta_3|_{\partial} = z_i$$
  

$$\zeta_1|_{\partial} + u_i\zeta_2|_{\partial} = 0.$$
(4.18)

We can describe each D-brane as a deformation of a basic D-brane D by

$$\mathcal{I}_{z,u}^{\partial} = z_i \theta_3 + u_i \zeta_2 \theta_1 \,. \tag{4.19}$$

Turning on a general ρ corresponds to a further boundary interaction I ∂ <sup>ρ</sup> = ρθ1. The separation of the D-branes in the ζ<sup>3</sup> direction obstructs that, via a BRST anomaly

$$\{\mathcal{I}_{z,u}^{\partial}, \mathcal{I}_{\rho}^{\partial}\} = (z_i - z_j)\rho_{ij}\theta_1\theta_3. \tag{4.20}$$

Once we turn on λ, we expect this anomaly will cancel against an extra λ(ui−u<sup>j</sup> )(ρ −1 )ij , leading to the saddle equations. This can be made concrete by computing the deformation of the C[θ 1 , ζ<sup>2</sup> , θ3] algebra due to the bulk back-reaction, e.g. by computing the planar corrections to the space of modifications or, more indirectly, as we did originally: compute the deformation of C[ζ2] to a P<sup>λ</sup> module and use it to describe the deformation of D.

## <span id="page-54-0"></span>5 Two-dimensional chiral gauge theories at large N

Formally, a two-dimensional chiral gauge theory is defined by coupling a matter chiral algebra with Kac-Moody symmetry G to a 2d chiral gauge field, i.e. a gauge field which only has a (0, 1) form component. Upon gauge-fixing, this definition results in a 2d chiral algebra presented as the cohomology of a certain BRST complex we discuss below. The BRST complex is well-defined only if the matter Kac-Moody currents have a specific level which cancels a one-loop gauge anomaly.

We have reviewed the supersymmetric chiral SU(N) gauge theory defined by taking bosonic matter in two copies of the adjoint representation. This is a protected subsector of four-dimensional N = 4 SU(N) gauge theory and also the world-volume theory of N D1 branes in the C <sup>3</sup> B-model, up to the decoupled U(1) center-of-mass degrees of freedom.

Four-dimensional N = 2 SCFTs also have protected subsectors [\[36,](#page-119-9) [73–](#page-121-10)[75\]](#page-121-11). Fourdimensional gauge theories with gauge group G and matter transforming in a symplectic representation R have a protected subsector consisting of a 2d chiral gauge theory with gauge group G and bosonic matter in representation R.

The anomaly cancellation condition for 4d SCFTs or 2d chiral gauge theories with bosonic matter only is rather restrictive. For example, quiver gauge theories with special unitary gauge group must be modelled on affine ADE quivers. The corresponding "ADE" chiral gauge theories appear on the world-volume of N D1 branes in a B-model with target space C × C2 Γ , up to U(1) factors in the gauge group. Twisted Holography relates such ADE chiral gauge theories to the B-model on SL(2, C)/Γ.

The definition of 2d chiral gauge theory allows the introduction of fermionic matter fields as well, transforming into an orthogonal representation R<sup>f</sup> of G. Fermions and bosons contribute to the anomaly with opposite signs and thus the choice of gauge group and matter representation is much less constrained. For example, we could (and will) consider an SU(N) gauge theory with 2n + 2 adjoint bosons and 2n adjoint fermions.

The theories with fermionic matter do not appear to be protected sectors of 4d SUSY theories. Any statement we may derive about the 't Hooft expansion of such theories will not encode a protected part of a standard holographic correspondence. We are also not aware of 3d CY geometries such that D1 branes would support such chiral theories. A 't Hooft analysis of general 2d chiral gauge theories will thus likely lead us to unexplored corners of String Theory, if 't Hooft completeness holds for this class of gauge theories.

### <span id="page-55-0"></span>5.1 The large N expansion of 2d chiral gauge theories

For conciseness, in the remainder of this section we will take the fields to be a collection of N × N matrices, which could be organized further into adjoint or bifundamental representations of one or more U(kiN) groups with k<sup>i</sup> ∈ Z. There are important differences between U(N) and SU(N), but they are immaterial in the planar limit. Anomaly cancellation may also require the addition of order 1 fields which transform as SU(N) scalars. These are also immaterial in the planar limit. (Anti)fundamental degrees of freedom will be discussed separately.

This assumption could be easily relaxed to allow for more general ranks N<sup>i</sup> , with minimal changes to our formulae below. Generalizations to SO(kiN) and Sp(2kiN) gauge groups are also possible, as well as matter in various two-index representations of the gauge groups, but require some considerations about unorientable worldsheets. In these cases, local operators are no longer computed by cyclic cohomology but instead by the so-called Dihedral cohomology [\[70,](#page-121-7) [76\]](#page-121-12). We briefly discuss these cases in Appendix [G.](#page-113-0)

We organize correlation functions, OPEs, etc. in a 't Hooft expansion just as we did in the standard example.

#### <span id="page-56-0"></span>5.2 A hidden algebra

We denote the Grassmann parity of a symbol x as |x| and its ghost number as gh[x]. In the absence of free fermions, the Grassmann parity of fields coincides with the ghost number modulo 2. If free fermions are present, we instead need to allow the Grassmann parity to be distinct from the ghost number and thus work with graded super vector spaces.

The free fields we work with include:

- A collection of bc systems with scaling dimensions  $\Delta_c = 0$  and  $\Delta_b = 1$  and ghost numbers 1 and -1 respectively. Both sets of fields are fermionic, c = |c| = |b| = 1.
- A collection of symplectic bosons and free fermions with scaling dimension  $\frac{1}{2}$  and ghost number 0. We denote them collectively as Z.

We now discuss a crucial observation: the entire field content and BRST symmetry of a 2d chiral gauge theory built from  $N \times N$  matrices of free fields can be encoded into a 2d-cyclic <sup>27</sup>, finite-dimensional, graded associative super-algebra A. Vice versa, any such algebra defines a 2d chiral gauge theory of  $N \times N$  matrices at tree level. An anomaly cancellation condition is required at one loop.

The super vector space A can be introduced as a way to package all of the fields into a single generating field  $\Phi$ , an  $N \times N$  matrix valued in A with  $|\Phi| = \text{gh}[\Phi] = 1$ :

$$\Phi(z) \equiv a_{0,u}c^{u}(z) + a_{1,\alpha}Z^{\alpha}(z) + a_{2}^{u}b_{u}(z).$$
(5.1)

Here the u and  $\alpha$  indices run over the collections of bc ghosts, symplectic bosons and free fermions defining the chiral algebra under consideration. Accordingly, we denoted as  $a_{0,u}, a_{1,\alpha}, a_2^u$  a basis of

$$A = A_0 \oplus A_1 \oplus A_2 \,, \tag{5.2}$$

where  $A_i$  are the components of A of ghost number i. The scaling dimension of different components of  $\Phi$  can be encoded in an operator  $\Delta$  acting on  $A_i$  as  $\frac{i}{2}$ .

We can also denote individual components of  $\Phi$  collectively as  $\phi^a \in \mathfrak{gl}(N)$  and the basis elements of A as  $a_a$ :

$$\Phi(z) = a_a \phi^a \,. \tag{5.3}$$

In practice, we will do our best to minimize any references to individual component of  $\Phi$  except in examples. Working with the generating field  $\Phi$  has considerable conceptual and practical advantages.

<span id="page-56-1"></span> $<sup>^{26}</sup>$ It may be possible to extend the formalism to include super-groups. The ghosts corresponding to fermionic generators in G would then be bosons.

<span id="page-56-2"></span><sup>&</sup>lt;sup>27</sup>Here, 2d refers to the degree of the cyclic pairing, not the dimension of the algebra

The OPE of elementary fields can be written concisely as

$$\Phi_j^i(z) \otimes \Phi_t^k(w) \sim \delta_t^i \delta_j^k \hbar \frac{\eta}{z - w} ,$$
 (5.4)

where we wrote explicitly the U(N) indices i, j, k, t. In the following we will leave U(N) indices implicit when possible.

The numerator η ∈ A⊗A is a graded-symmetric tensor which collects the two-point functions. It has non-zero components

$$\eta_u^v = \delta_u^v \qquad \qquad \eta^{\alpha\beta} = \omega^{\alpha\beta} \,.$$
(5.5)

Expanding out the concise OPE, we recover the familiar OPE of a collection of bc systems and symplectic bosons/free fermions:

$$b_u(z)c^v(w) \sim \hbar \frac{\delta_u^v}{z - w}$$

$$Z^{\alpha}(z)Z^{\beta}(w) \sim \hbar \frac{\omega^{\alpha\beta}}{z - w}.$$
(5.6)

We could also write

$$\phi^a(z)\phi^b(w) \sim \hbar \frac{\eta^{ab}}{z-w} \tag{5.7}$$

with η = η aba<sup>a</sup> ⊗ ab.

In concrete OPE calculations, we will encounter expressions where η ab is contracted with pairs of A basis elements scattered through the expression. We find it useful to borrow the Sweedler notation from the theory of Hopf algebras and write η = η (1)⊗η (2) as a stand-in for the full expansion in a basis for the tensor product. If l number of contractions occur, we use pairs η (1) <sup>i</sup> ⊗η (2) <sup>i</sup> with i = 1, · · · , l to keep track of the different contractions.

We denote the (graded symmetric) pairing dual to η simply as (aaab) ∈ C, so that

$$\eta^{(1)}(\eta^{(2)}a) = a$$

$$(a\eta^{(1)})\eta^{(2)} = a$$
(5.8)

for all a ∈ A.

We can now write concise expressions for the ghost number current and the stress tensor. Notice that Tr (ΦΦ) ≡ (−1)<sup>|</sup><sup>ϕ</sup> b ||aa<sup>|</sup> Tr ϕ aϕ b (aaab) = 0 because the symmetry properties of (aaab), when non-zero, are opposite to these of ϕ aϕ b .

The ghost number current can be written as

$$J_{\rm gh} = \frac{1}{\hbar} \text{Tr} \left( \Phi \Delta \Phi \right) = \frac{1}{\hbar} \text{Tr} c^u b_u . \tag{5.9}$$

In particular,

$$J_{\rm gh}(z)\Phi(w) \sim \frac{1-2\Delta}{z-w} \Phi(w). \tag{5.10}$$

We can also write the Stress Tensor T(z) as

$$T = \frac{1}{2\hbar} \text{Tr} \left( \partial \Phi \Phi \right) + \frac{1}{2} \partial J_{\text{gh}}(z) = \text{Tr} \left( \partial \Phi \Delta \Phi \right).$$
 (5.11)

### <span id="page-58-0"></span>5.3 An algebra structure from the BRST differential

We will discuss the BRST current momentarily. At first, we can focus on the tree level part Q<sup>0</sup> of the BRST transformations, i.e. the part involving a single Wick contraction. The action of Q<sup>0</sup> maps a field to a sum of (matrix) products of fields:

$$Q_0 c^u = f_{vw}^u c^v c^w$$

$$Q_0 Z^\alpha = f_{v\beta}^\alpha \left[ c^v Z^\beta - Z^\beta c^v \right]$$

$$Q_0 b_u = f_{vu}^w \left[ c^v b_w + b_w c^v \right] + f_{u\alpha\beta} Z^\alpha Z^\beta . \tag{5.12}$$

It is easy to see that the structure constants on the right hand side equip A with the structure of an associative algebra. The c ghost for the diagonal U(N) gauge action equips A with an unit.

The algebra structure preserves the weight and ghost number. It allows us to write a simple transformation rule

<span id="page-58-1"></span>
$$Q_0\Phi(z) = \Phi(z)\Phi(z) \tag{5.13}$$

extended by the Leibniz rule to products of fields. Associativity is closely related to Q<sup>2</sup> <sup>0</sup> = 0 (remember that Φ is fermionic):

$$Q_0^2 \Phi(z) = (\Phi(z)\Phi(z))\Phi(z) - \Phi(z)(\Phi(z)\Phi(z)).$$
 (5.14)

The BRST current is a cubic expression in the elementary fields. It has a very concise expression

$$J_{\text{BRST}} = \frac{1}{3\hbar} \text{Tr} \left( \Phi \Phi \Phi \right). \tag{5.15}$$

Here we denote as (•) a linear map A → C such that the composition (••) with the product on A coincides with the pairing dual to η. In particular, (•) is a graded trace supported on A2.

We will denote an associative algebra equipped with a trace with these properties as a 2d-cyclic algebra. Its relationship with the standard definition of Calabi-Yau algebra is reviewed in Appendix [D.](#page-105-0) Conversely, any such an algebra A can be used to define a free chiral algebra equipped with a BRST differential of this form.

The full BRST differential acting on general local operators includes both a Q<sup>0</sup> term with a single Wick contraction and a 1-loop term with two Wick contractions. There is a potential 1-loop BRST anomaly which further constrains the form of A.

#### <span id="page-59-0"></span>5.4 Back to C 3

As an example, we consider the case of the supersymmetric chiral gauge theory with gauge group U(N). The collection of matrix-valued fields consists of a single bc system and a single set of symplectic bosons X, Y . These can be collected into a generating field

$$\Phi(z) = c(z) + \theta_1 X(z) + \theta_2 Y(z) + \theta_1 \theta_2 b(z)$$
(5.16)

valued in the algebra A = C[θ1, θ2] of polynomials in two anti-commuting fermionic variables θα.

We have already encountered this parametrization in Section [5.](#page-54-0) It identifies Φ(z) with the open string field for the stack of D1 branes supported on C ∈ C 3 . In particular, the algebra A is simply the algebra of boundary local operators for the Dirichlet boundary conditions in the transverse directions.

The scaling dimension operator can be written as

$$\Delta = \frac{1}{2} \theta_{\alpha} \partial_{\theta_{\alpha}} \,. \tag{5.17}$$

We can write the pairing as

$$\eta = (\theta_1 - \theta_1')(\theta_2 - \theta_2'),$$
(5.18)

where the unprimed and primed variables denote the two factors in the tensor product A ⊗ A, i.e. we identified

$$\mathbb{C}[\theta_1, \theta_2] \otimes \mathbb{C}[\theta_1, \theta_2] = \mathbb{C}[\theta_1, \theta_2, \theta_1', \theta_2']. \tag{5.19}$$

The corresponding trace is

$$(\theta_1 \theta_2) = 1, \tag{5.20}$$

and 0 otherwise.

#### <span id="page-59-1"></span>5.5 The ADE chiral algebra and the B-model

Recall that the ADE quiver has nodes labelled by the representations of the discrete group Γ and edges controlled by the tensor product with the fundamental representation. For example, for Γ = Z<sup>k</sup> we have one-dimensional representations R<sup>i</sup> with 0 ≤ i < k modulo k and a necklace quiver.

The ADE gauge theory has ranks equal to the dimensions dimR<sup>i</sup> and matter fields (Xe, Ye) for each edge e. It is easy to recognize that

$$A = \operatorname{End}(\mathbb{C}[\Gamma])[\theta^1, \theta^2]^{\Gamma}$$
(5.21)

coincides with the algebra of local operators on Dtot.

Indeed, the ADE chiral algebra is the world-volume theory of N C × Dtot branes in the B-model with target

$$\mathbb{C} \times \frac{\mathbb{C}^2}{\Gamma} \,. \tag{5.22}$$

The trace on A is simply the matrix trace combined with the trace on C[θ 1 , θ<sup>2</sup> ].

#### <span id="page-60-0"></span>5.6 A small generalization

The notion of 2d-cyclic associative algebra can be generalized to that of 2d-cyclic A<sup>∞</sup> algebra. Schematically, we may imagine a very general tree-level BRST transformation rule:

$$Q_0 \Phi = \{\Phi\} + \{\Phi, \Phi\} + \{\Phi, \Phi, \Phi\} + \cdots$$
 (5.23)

where

$$\{\bullet, \cdots, \bullet\}: A^{\otimes n} \to A$$
 (5.24)

are multi-linear maps which change the overall ghost number by 2 − n. These maps generalize the associative product encountered in the rest of this section. Essentially by definition, they equip A with the structure of an A<sup>∞</sup> algebra. The existence of a BRST current

$$J_{\text{BRST}} = \frac{1}{2} \text{Tr} \left( \{ \Phi \} \Phi \right) + \frac{1}{3} \text{Tr} \left( \{ \Phi, \Phi \} \Phi \right) + \frac{1}{4} \text{Tr} \left( \{ \Phi, \Phi, \Phi \} \Phi \right) + \cdots$$
 (5.25)

such that structure constants are cyclic symmetric make A into a 2d-cyclic A<sup>∞</sup> algebra. We also note, following [\[32\]](#page-119-16), that a 2d-cyclic algebra is equivalent to a 2d Calabi-Yau algebra, which can be used to define an abstract dg-TFT.

#### <span id="page-60-1"></span>5.7 Algebras and branes

Suppose now that we are given some abstract dg-TFT T<sup>2</sup> with a ghost number anomaly of 2 and a D-brane B with a finite-dimensional boundary (possibly A∞) algebra A which admits a trace, i.e. gives finite disc correlation functions, and has the correct scaling properties. We have seen how such a D-brane can probe normalizable local operators and a category of D-branes in T<sup>2</sup> via Homological Algebra constructions applied to A.

We can combine T<sup>2</sup> and the B-model with target C to make a world-sheet theory suitable to define a B-model-like String Theory. We can consider a stack of N D-branes of the form B × C in that String Theory. By construction, the world-volume theory of such D-branes can be identified with the 2d chiral gauge theory we associated to A.

In such a situation, we would expect the 't Hooft expansion of the 2d chiral gauge theory to be dual to a modified String Theory, deformed by the back-reaction of the N branes.

The question we explore in the rest of the paper is: can we characterize this backreaction algebraically, even if T<sup>2</sup> does not have a sigma-model interpretation and BCOV theory is not available? Even better, can we somehow define the deformed String Theory if all we have is an algebra A with the correct properties, perhaps by giving a dg-TFT description of the corresponding world-sheet theory?

### <span id="page-61-0"></span>6 Local operators at tree level and cyclic cohomology

General local operators are built as normal-ordered polynomials in the fields and their derivatives. The action of the tree-level differential Q<sup>0</sup> [\(5.12\)](#page-58-1) does not change the number of derivatives present in a monomial. A useful warm-up is to consider the Q0 cohomology of single-trace local operators which do not contain derivatives, analogous to the A and B towers in the canonical example. We will then characterize the whole cohomology of Obs0.

#### <span id="page-61-1"></span>6.1 The first tower

We will now introduce a useful notation which allows us to express all calculations in terms of the 2d-cyclic algebra A. Consider an expression of the form

$$\mathcal{O}_{\mathfrak{c}}(z) \equiv \frac{1}{\hbar \ell(\mathfrak{c})} \operatorname{Tr} \left( \mathfrak{c} | \Phi(z), \cdots, \Phi(z) \right),$$
 (6.1)

where c denotes a cyclic-symmetric (with signs) multi-linear map

$$(\mathfrak{c}|\bullet,\cdots,\bullet): \left(A^{\otimes \ell(\mathfrak{c})}\right)^{\mathbb{Z}_{\ell(\mathfrak{c})}} \to \mathbb{C},$$

$$(6.2)$$

and ℓ(c) is the number of inputs in c. [28](#page-61-2) By linearity, we can expand

$$\mathcal{O}_{\mathfrak{c}}(z) \equiv \sum_{a_1, \dots a_{\ell(\mathfrak{c})}} \pm \frac{1}{\hbar |\mathfrak{c}|} (\mathfrak{c}|a_{a_1}, \dots, a_{\ell(\mathfrak{c})}) \operatorname{Tr} \phi^{a_1} \dots \phi^{a_{\ell(\mathfrak{c})}}(z)$$
(6.3)

and recognize the matrix elements of c as coefficients of a generic linear combination of single-trace local operators. The overall factor of (ℏℓ(c))<sup>−</sup><sup>1</sup> is introduced for later convenience. As these operators do not contain derivatives, they are manifestly quasiprimary operators in the chiral algebra.

<span id="page-61-2"></span><sup>28</sup>The signs insure compatibility with the cyclicity of the trace. If we rotate the trace and bring the last entry to the beginning, we pay a Koszul price from passing the fields ϕ <sup>a</sup> across each other. The Koszul parity of the ϕ a is opposite to the Koszul parity of the a<sup>a</sup> elements, so we get a −1 factor for each pair of bosonic elements in A[[s]].

We can easily compute the action of Q0:

$$\mathcal{O}_{Q_0 \mathfrak{c}}(z) \equiv Q_0 \mathcal{O}_{\mathfrak{c}}(z) = \frac{1}{\hbar} \text{Tr} \left( \mathfrak{c} | \Phi(z) \Phi(z), \cdots, \Phi(z) \right).$$
 (6.4)

Symmetrizing carefully,

$$(Q_0 \mathfrak{c}|a_1, \cdots, a_{n+1}) = (\mathfrak{c}|a_1 a_2, \cdots, a_{n+1}) - (\mathfrak{c}|a_1, a_2 a_3, \cdots, a_{n+1}) + (\mathfrak{c}|a_1, a_2, a_3 a_4, \cdots, a_{n+1}) + \cdots \pm (-1)^n (\mathfrak{c}|a_{n+1} a_1, a_2, \cdots, a_n).$$

$$(6.5)$$

We recognize the differential defining the cyclic cohomology complex CC• (A) for A. This tower of local operators is thus labelled by classes in the cyclic cohomology HC• (A).

There is a small subtlety which we should address here. The space of local operators in the gauge theory should be built as the relative BRST cohomology: the ghost c is only allowed to appear in local operators through its derivatives and G-invariance is imposed by hand. A naive calculation which ignores this point will produce some extra cohomology classes of scaling dimension 0 built as polynomials in the c ghosts, as well as the derivatives of these classes. That extra cohomology can be removed by hand, as it is the only cohomology in the sector with scaling dimension 0.[29](#page-62-1)

### <span id="page-62-0"></span>6.2 The second tower

Next, we can look at operators involving a single derivative, analogous to the C and D towers in the standard example (and first derivatives of the other two):

$$\mathcal{O}_{\mathfrak{h}}(z) \equiv \frac{1}{\hbar} \operatorname{Tr} \left( \mathfrak{h} | \partial \Phi(z); \Phi(z), \cdots, \Phi(z) \right), \tag{6.6}$$

where the multilinear map h is not cyclic symmetric. As

$$Q_0 \partial \Phi = \Phi \partial \Phi + \partial \Phi \Phi \tag{6.7}$$

we have

$$\mathcal{O}_{Q_0 \,\mathfrak{h}}(z) \equiv Q_0 \,\mathcal{O}_{\mathfrak{h}}(z) = \frac{1}{\hbar} \mathrm{Tr} \left( \mathfrak{h} | \Phi \partial \Phi, \cdots, \Phi(z) \right) + \frac{1}{\hbar} \mathrm{Tr} \left( \mathfrak{h} | \partial \Phi \Phi, \cdots, \Phi(z) \right) + \frac{1}{\hbar} \mathrm{Tr} \left( \mathfrak{h} | \partial \Phi, \Phi(z) \Phi(z), \cdots, \Phi(z) \right) + \cdots$$

$$(6.8)$$

<span id="page-62-1"></span><sup>29</sup>If A<sup>0</sup> consists of the identity 1<sup>A</sup> only, i.e. the gauge group is U(N), a relative cohomology calculation only requires us to restrict to functions c which vanish on 1A. This restriction defines the relative cyclic cohomology complex CC• rel(A). In a more general situation, the correct procedure would be to promote A from an algebra to a category whose objects label individual gauge groups, as we saw in the ADE example. Then the definition of relative cyclic cohomology for a category automatically keeps track of the requirement of G-invariance. We leave this generalization implicit for conciseness.

i.e.

$$(Q_0 \,\mathfrak{h}|a_1; \cdots, a_{n+1}) = (\mathfrak{h}|a_1 a_2; \cdots, a_{n+1}) - (\mathfrak{h}|a_1; a_2 a_3, \cdots, a_{n+1}) + (\mathfrak{h}|a_1, a_2, a_3 a_4, \cdots, a_{n+1}) + \cdots \pm (-1)^n (\mathfrak{h}|a_{n+1} a_1, a_2, \cdots, a_n).$$
(6.9)

Notice that this differential is identical in form to the one we wrote for the cyclic cohomology complex, but it acts here on maps which are not cyclic invariant. It defines the Hochschild cohomology complex CH• (A, A<sup>∨</sup> ) valued in the dual A<sup>∨</sup> of A. [30](#page-63-0) This tower of local operators is thus labelled by classes in the Hochschild cohomology HH• (A, A<sup>∨</sup> ). Again, we can avoid the issue of relative vs absolute BRST cohomology by restricting to cohomology classes of scaling dimension greater than 1.

Some of the operators we have identified are actually derivatives of operators in the first tower. The operation of taking a derivative, i.e. the L<sup>−</sup><sup>1</sup> Virasoro generator, gives a standard morphism I : CC• (A) → CH• (A, A<sup>∨</sup> ), which embeds the space of cyclic maps into all possible maps.

We can look for quasi-primary operators of the form Oh(z) by looking at the action of the L<sup>1</sup> Virasoro generator[31](#page-63-1). At tree level, L<sup>1</sup> simply maps ∂Φ → −2∆Φ (and Φ → 0). Accordingly,

$$L_1 \mathcal{O}_{\mathfrak{h}}(z) = -\frac{2}{\hbar} \operatorname{Tr} \left( \mathfrak{h} | \Delta \Phi(z); \Phi(z), \cdots, \Phi(z) \right). \tag{6.10}$$

We thus encounter a map CH• (A, A<sup>∨</sup> ) → CC• (A) which composes h with (−2∆) at the first argument and then applies a (graded) cyclic symmetrization to the result. The kernel of this map gives the space of quasi-primary operators in the second tower.

Operators of the form O<sup>h</sup> should either be a derivative of the first tower or generate a new Verma module (a quasi primary). We conclude that we have an equivalent characterization of the quasi-primary operators in the second tower, as the quotient HH• (A, A<sup>∨</sup> )/I(HC• (A)).

The morphism I is part of Connes Periodicity long exact sequence. The long exact sequence also involve certain "periodicity maps" S which controls the kernel of I. The map L<sup>1</sup> above certifies that S is trivial as long as we ignore operators of scaling weight 0 and thus the long exact sequence collapses to a collection of short exact sequences,

<span id="page-63-0"></span><sup>30</sup>As the pairing identifies A and A<sup>∨</sup>, this is essentially the same as the standard Hochschild cohomology complex CH• (A). The physical meaning of the latter, though, is slightly different.

<span id="page-63-1"></span><sup>31</sup>Here we mean the action of the L<sup>1</sup> centered at the location of the field, L1Φ(z) = H dw(w − z) <sup>2</sup>T(w)Φ(z), as is usual in determining if an operator is (quasi-)primary.

identifying the quotient HH<sup>n</sup> (A, A<sup>∨</sup> )/HC<sup>n</sup> (A) with HC<sup>n</sup>−<sup>1</sup> (A) by Connes B operator. [32](#page-64-0)

This identification suggests that we can map an element of the first tower of length n−1 to a quasi-primary in the second tower of length n. When a dual geometric picture is available, this corresponds to solving ∂ <sup>−</sup><sup>1</sup>α for a divergence free vector α. Here, we can solve it with the help of the stress tensor and the cup product on Hochschild cohomology. The stress tensor T is a canonical member of the second tower of quasiprimary local operators. It corresponds to a function

$$(T|a_{0,v}; a_2^u) = \delta_v^u$$
  
 $(T|a_1^\alpha; a_1^\beta) = \frac{1}{2}\omega_{\alpha\beta}$  (6.14)

i.e.

$$(T|a;b) = (a\Delta b). (6.15)$$

The cup product is conventionally defined on the Hochschild complex CH• (A, A) as follows

<span id="page-64-3"></span>
$$(f \cup g)(a_1, \dots, a_{n+m}) = f(a_1, \dots, a_n)g(a_{n+1}, \dots, a_{n+m})$$
(6.16)

for f ∈ CH<sup>n</sup> (A, A), g ∈ CH<sup>m</sup>(A, A). We can translate this operation to CH• (A, A<sup>∨</sup> ) through the identificatioin A ∼= A<sup>∨</sup> . We find that, given a cyclic map c ∈ HC<sup>n</sup> (A), its cup product with the stress tensor c ∪ T is given by

<span id="page-64-1"></span>
$$(\mathfrak{c} \cup T)(a_1, \dots, a_{n+1}) = (\mathfrak{c} \mid a_{n+1} \Delta a_1, a_2, \dots, a_n).$$
 (6.17)

$$HC^{\bullet}(A) = \bigoplus_{w \ge 0} HC^{\bullet}(A)^{(w)}. \tag{6.11}$$

In particular, the degree zero part HC• (A) (0) is the same as the cyclic cohomology for A0, HC• (A) (0) = HC• (A0).

We show in Appendix [B](#page-102-0) that the Connes' periodicity map S vanishes on the positive degree part of cyclic cohomology HC• (A) (≥1). Therefore, the Connes' long exact sequence reduces into a collection of short exact sequences

<span id="page-64-2"></span>
$$0 \longrightarrow HC^{n}(A)^{(\geq 1)} \stackrel{I}{\longrightarrow} HH^{n}(A, A^{\vee})^{(\geq 1)} \stackrel{B}{\longrightarrow} HC^{n-1}(A)^{(\geq 1)} \longrightarrow 0.$$
 (6.12)

As a result, we have the following isomorphism

$$\mathrm{HH}^{n}(A, A^{\vee})^{(\geq 1)} / \mathrm{HC}^{n}(A)^{(\geq 1)} \stackrel{B}{\cong} \mathrm{HC}^{n-1}(A)^{(\geq 1)}$$
. (6.13)

<span id="page-64-0"></span><sup>32</sup>More precisely, the degree (scaling dimension) of cyclic cochain induced from the degree of A is preserved by the differential. We can split the cyclic cohomology according to the degree

Using the expression for B [70], we can check that the following identity holds

$$B(\mathfrak{c} \cup T) = (-1)^{|\mathfrak{c}|} (\Delta_{\mathfrak{c}} + 1)\mathfrak{c}. \tag{6.18}$$

The above identity also follows from the fact that  $(HH^{\bullet}(A, A^{\vee}), B, \cup, \{,\}))$  forms a BV algebra [77], analogous to the BV structure on Polyvector fields. We have

$$B(\mathfrak{c} \cup T) = B(\mathfrak{c}) \cup T + (-1)^{|\mathfrak{c}|} \mathfrak{c} \cup BT + (-1)^{|\mathfrak{c}|} \{\mathfrak{c}, T\}. \tag{6.19}$$

Then (6.17) follows from  $\{\mathfrak{c}, T\} = \Delta_{\mathfrak{c}}\mathfrak{c}$ , B(T) = 1. The map  $\mathfrak{c} \to \mathfrak{c} \cup T$  provides for us the identification between cyclic cohomology element  $\mathrm{HC}^{\bullet-1}(A)$  and quasi-primary of the second tower  $\mathrm{HH}^{\bullet}(A, A^{\vee})/\mathrm{HC}^{\bullet}(A)$ . For example, the stress tensor T itself can be thought of as coming from the map  $(\bullet): A \to \mathbb{C}$  under this identification.

#### <span id="page-65-0"></span>6.3 Operators with any number of derivatives

Next, we will adopt a notation which allows us to deal transparently with derivatives of fields. The expression  $\Phi(z+s) \in A[[s]]$  is a useful generating function for derivatives of  $\Phi(z)$ :

$$\Phi(z+s) = \sum_{n=0}^{\infty} \frac{s^n}{n!} \partial_z^n \Phi(z).$$
 (6.20)

The super vector space A[[s]] plays the role of V from the general discussion in the Introduction: it is dual to the collection of "letters"  $\frac{1}{n!}\partial_z^n\phi^a$  which can occur in a single-trace local operator.

We can denote single-trace operators built from  $\Phi$  and its derivatives concisely as

$$\mathcal{O}_C(z) = \frac{1}{\hbar \ell(C)} \text{Tr} \left( C | \Phi(z+s), \cdots, \Phi(z+s) \right)$$
 (6.21)

with  $(C|\cdots)$  defined as a multi-linear map

$$(C|\bullet,\cdots,\bullet):(A[[s]]\otimes\cdots\otimes A[[s]])^{\mathbb{Z}_{\ell(C)}}\to\mathbb{C}.$$
 (6.22)

Explicitly,

$$\mathcal{O}_{C}(z) = \frac{1}{\hbar \ell(C)} \operatorname{Tr} \left( C \left| a_{a_{1}} \frac{s^{n_{1}}}{n_{1}!} \partial^{n_{1}} \phi^{a_{1}}(z), \cdots, a_{a_{|C|}} \frac{s^{n_{\ell(C)}}}{n_{\ell(C)}!} \partial^{n_{|C|}} \phi^{a_{|C|}}(z) \right) =$$

$$= \pm \frac{1}{\hbar \ell(C)} \left( C \left| a_{a_{1}} \frac{s^{n_{1}}}{n_{1}!}, \cdots, a_{a_{|C|}} \frac{s^{n_{\ell(C)}}}{n_{\ell(C)}!} \right) \operatorname{Tr} \partial^{n_{1}} \phi^{a_{1}}(z) \cdots \partial^{n_{\ell(C)}} \phi^{a_{\ell(C)}}(z) (6.23) \right)$$

Hence the matrix elements of C are essentially the coefficients in a general linear combination of single-trace operators built from  $\ell(C)$  fields.

For example, the stress tensor

$$T = -\frac{\omega_{\alpha\beta}}{2\hbar} \operatorname{Tr} Z^{\alpha} \partial Z^{\beta} - \frac{1}{\hbar} \operatorname{Tr} b_u \partial c^u$$
(6.24)

corresponds to a function (T|•, •) with several non-zero entries

$$(T|a_{0,v}s, a_{2}^{u}) = \delta_{v}^{u}$$

$$(T|a_{2}^{u}, a_{0,v}s) = -\delta_{v}^{u}$$

$$(T|a_{1}^{\alpha}s, a_{1}^{\beta}) = \frac{1}{2}\omega_{\alpha\beta}$$

$$(T|a_{1}^{\alpha}, a_{1}^{\beta}s) = -\frac{1}{2}\omega_{\alpha\beta}.$$
(6.25)

The single-trace local operators form a representation of the global conformal symmetry algebra. The global conformal generators L<sup>−</sup>1, L<sup>0</sup> and L<sup>1</sup> act as vector fields on Φ(z). The action on the functionals C follows from the action of the same vector fields on A[[s]]. For example, L<sup>−</sup><sup>1</sup> adds a derivative on Φ, i.e. acts as ∂<sup>s</sup> on the generating function. The other generators also use the information about the weight:

$$L_{-1} = \partial_s$$

$$L_0 = s\partial_s + \Delta$$

$$L_1 = -s^2\partial_s - 2s\Delta.$$
(6.26)

In particular, quasi-primary operators are described by functionals annihilated by L1.

As the scaling dimensions are non-negative half-integers (in particular, L<sup>0</sup> is diagonalizable) and the number of operators of a given dimension is finite, the SL(2) representation theory is quite restrictive. Quasi-primaries of positive dimension generate Verma modules consisting of their derivatives. Operators of dimension 0 generate Verma modules which can contain quasi-primaries of dimension 1. This only affects the spurious cohomology classes of dimension 0 built from c ghosts only.

The tree-level BRST differential is easily identified with the differential for the cyclic cohomology complex CC• (A[[s]]), which can be organized by the total number of derivatives appearing in the operator. We have already characterize the two towers of cohomology with 0 and 1 derivatives. We will now argue that all other cohomology consists of derivatives of operators in the two towers.

#### <span id="page-66-0"></span>6.4 A cohomology computation

It is useful to go back to our definition of the differential C → Q0C. As we saw in the analysis of the second tower, the explicit formula for Q<sup>0</sup> maps cyclic-invariant maps to cyclic-invariant maps, but also makes sense on generic maps and defines the Hochschild cohomology complex  $CH^{\bullet}(A[[s]], A[[s]]^{\vee})$ .

An important property of Hochschild cohomology complex is a good behaviour under tensor product: the complex  $CH^{\bullet}(A \otimes A', M \otimes M')$  is quasi-isomorphic to the complex  $CH^{\bullet}(A, M) \otimes CH^{\bullet}(A', M')$ . This quasi-isomorphism is non-trivial [68]. Applied to the case at hand, this gives a quasi-isomorphism of complexes

<span id="page-67-1"></span>
$$\operatorname{CH}^{\bullet}(A[[s]], A[[s]]^{\vee}) \simeq \operatorname{CH}^{\bullet}(A; A^{\vee}) \otimes \operatorname{CH}^{\bullet}(\mathbb{C}[[s]], \mathbb{C}[[s]]^{\vee}).$$
 (6.27)

In order to proceed further, we need to recall the Connes construction relating Hochschild cohomology and cyclic cohomology.

There is an odd map B which acts on  $CH^{\bullet}(A[[s]]; A[[s]]^{\vee})$  in the opposite direction as  $Q_0$ , roughly given by inserting the unit 1 to each slot of the map. It is nilpotent and anti-commutes with  $Q_0$ . The relationship between the cyclic and Hochschild cohomology can be made precise by considering a bi-complex defined using B [70]. This bi-complex can be written as follows

$$(CH^{\bullet}(A[[s]]; A[[s]]^{\vee})[v], Q_{CH} + vB),$$
 (6.28)

where v is a formal parameter of degree 2. Then  $CC^{\bullet}(A[[s]])$  is quasi-isomorphic to the above complex. The cohomology at order  $v^0$  is simply given by the kernel of B on the Hochschild cohomology. In general, cohomology at higher order of v are non-zero, but in our case, the algebra is assumed to have a scaling degree. According to the short exact sequence in (6.12), the positive degree part of cyclic cohomology<sup>33</sup>, which is the part we are interested in, is the kernel of Connes' operator B. This construction commutes with the action of global conformal transformations, so we expect an analogous relation for quasi-primaries.

We can combine this analysis with the fact the Hochschild cohomology factor with tensor product (6.27).

$$\operatorname{CH}^{\bullet}(A[[s]]; A[[s]]^{\vee}) \simeq \operatorname{CH}^{\bullet}(A; A^{\vee}) \otimes \operatorname{CH}^{\bullet}(\mathbb{C}[[s]]; \mathbb{C}[[s]]^{\vee}),$$
 (6.29)

with Connes operator  $B + \partial_{\mathbb{C}}$ , where  $\partial_{\mathbb{C}} = \frac{\partial}{\partial(\partial_s)} \frac{\partial}{\partial s}$  is the divergence operator on the s plane and B is the Connes' operator on  $CH^{\bullet}(A; A^{\vee})$ .

We thus have a quasi-isomorphism relating the cyclic complex  $\mathrm{CC}^{\bullet}(A[[s]])$  and the following complex

$$(\mathrm{CH}^{\bullet}(A; A^{\vee}) \otimes \mathrm{CH}^{\bullet}(\mathbb{C}[[s]]; \mathbb{C}[[s]]^{\vee})[v], Q_{\mathrm{CH}} + v(B + \partial)). \tag{6.30}$$

<span id="page-67-0"></span> $<sup>^{33}</sup>$ Here we give s degree 1, so only constant c modes are in the zero degree part.

Moreover, the relative cyclic cohomology can be identified with the (B + ∂)-invariant part of HH• (A, A<sup>∨</sup> ) ⊗ HH• (C[[s]]; C[[s]]<sup>∨</sup> ).

The tower of cohomology with no derivatives corresponds to elements of the form

$$\beta \delta(s) \in \mathrm{HH}^{\bullet}(A, A^{\vee}) \delta(s) \tag{6.31}$$

which are invariant under B, i.e. with the expected HC• (A, A<sup>∨</sup> )δ(s) from Section [6.1.](#page-61-1) Operators with one derivative correspond to elements of the form

$$\beta \delta'(s) - B\beta \delta(s) \partial_s \tag{6.32}$$

and are in correspondence with HH• (A, A<sup>∨</sup> )δ ′ (s). This is the answer we computed before in Section [6.2.](#page-62-0)

The novel step is a characterization of operators in Obs<sup>0</sup> containing more derivatives: they take the form

$$\beta \delta^{(k+1)}(s) - B\beta \delta^{(k)}(s)\partial_s \tag{6.33}$$

and are thus always derivatives of other operators.

#### <span id="page-68-0"></span>6.5 A tree-level holographic dictionary for local operators

The algebra A[[s]] has a straightforward dg-TFT interpretation if A does: it is the space of boundary local operators for a brane of the form B[A] × C in a world-sheet theory combining T[A] and the B-model with target C. Formally, these are the D-branes which support the chiral algebra as a world-volume theory.

The coupling of closed string states to a D-brane is controlled by disc amplitudes. The disk amplitudes take as an input a closed string vertex operator and a cyclic collection of open string vertex operators. Accordingly, a closed string vertex operator for which the B[A] × C disk amplitudes are well defined can be mapped to a cyclic multi-linear function on A[[s]]. It is easy to see that the BRST operator acting on the closed string vertex operator maps to the differential in the cyclic complex.

A standard entry of the dg-TFT dictionary is thus that there is chain complex from the space of such closed string vertex operators to CC• (A[[s]]). The latter is also identified the space of single-trace local operators, giving a natural entry in the tree level holographic dictionary.

Recall that closed string vertex operators are "rotation-equivariant" vertex operators in the dg-TFT. In a more conventional string theory setup, rotation-equivariant vertex operators are defined by a BRST complex restricted to rotationally-symmetric vertex operators. Standard vertex operators can also be inserted in disk correlation functions, but one of the boundary vertex operators remains unintegrated and cyclic symmetry may be absent. A standard entry of the dg-TFT dictionary is that there is chain complex from the space of standard bulk vertex operators to CH• (A[[s]], A[[s]]<sup>∨</sup> ). The Connes complex describes the relation between standard and rotation-equivariant vertex operators in the dg-TFT.

The quasi-isomorphism [\(6.27\)](#page-67-1) expresses the fact that the space of vertex operators in the product of two dg-TFTs should be equivalent to the product of the spaces of vertex operators for the individual theories. The same is not true for rotation-equivariant vertex operators, which can combine factors of opposite worldsheet spin. The vertex operators in the B-model with target C which are described by CH• (C[[s]], C[[s]]<sup>∨</sup> ) are distributional in nature, as appropriate for representing insertions of local operators in a tree-level holographic dictionary.

From a dg-TFT perspective, we can describe the tree-level holographic dictionary as follows:

• An operator Oc(z) in the first tower maps to a world-sheet operator of the form

$$\mathfrak{c} \otimes \delta(\zeta - z) \,. \tag{6.34}$$

This is a cyclic cohomology element in the full theory combining T[A] and the B-model with target C.

• An operator Oh(z) in the second tower maps to a (B+divergence)-closed worldsheet operator of the form

$$\mathfrak{h} \otimes \delta'(\zeta - z) - B\mathfrak{h} \otimes \delta(\zeta - z)\partial_{\zeta}$$
. (6.35)

Quasi-primaries correspond to h which vanish when acted upon by ∆ and mapped to cyclic cohomology.

As discussed in Section [6.2,](#page-62-0) we can also construct quasi-primaries of the second tower from a cyclic map c ′ . It takes the form

$$(\mathfrak{c}' \cup T) \otimes \delta'(\zeta - z) - (\Delta_{\mathfrak{c}'} + 1)\mathfrak{c}' \otimes \delta(\zeta - z)\partial_{\zeta}.$$

This generalizes the standard example.

### <span id="page-69-0"></span>7 The global symmetry algebra

In this section we will analyze the tree-level limit L<sup>0</sup> of the global symmetry algebra of single-trace operators. Our objective is to compare it with the global symmetry algebra of the dual λ → 0 worldsheet dg-TFT.

The algebra has a well-defined λ → 0 limit. Much as for the BRST generator, the tree-level action of L<sup>0</sup> generators on local operators is encoded in the transformation of individual fields:

$$[O, \Phi(s)] = \{O|\Phi(s), \cdots, \Phi(s)\},$$
 (7.1)

where we employ a multi-linear map

$$\{O|\bullet,\cdots,\bullet\}:A[[s]]^{\otimes \ell(O)}\to A[[s]]$$
 (7.2)

to describe the structure constants of the transformation. Such a map can only be a symmetry at tree level if it commutes with Q0.

In the homological algebra language, we can study the complex defined by these maps with a differential [Q0, O]. Essentially by definition, this is the Hochschild cohomology complex CH• (A[[s]]) ≡ CH• (A[[s]], A[[s]]). Recall that CH• (A[[s]]) is a dg-Lie algebra, with Lie bracket [O, O′ ] induced by the commutator of the corresponding transformations. Important examples of elements of CH• (A[[s]]) are the global conformal generators

$$L_{-1} = \partial_s$$

$$L_0 = s\partial_s + \Delta$$

$$L_1 = -s^2\partial_s - 2s\Delta.$$
(7.3)

Not all such transformations will arise as modes of single-trace operators! We thus only have a dg-Lie algebra map

$$\mathfrak{L}_0 \to \mathrm{CH}^{\bullet}(A[[s]])$$
. (7.4)

The tree-level action of symmetries on local operators follows directly from these definitions and matches a well-known action of CH• (A[[s]]) on CC• (A[[s]]). The complex CH• (A[[s]]) gives a standard dg-TFT description of the symmetries of the theory combining T[A] and the B-model on C.

We can use the nice properties of Hochschild cohomology under tensor product to produce another chain map:

$$\mathfrak{L}_0 \to \mathrm{CH}^{\bullet}(A)[[s, \partial_s]] \tag{7.5}$$

into polynomial polyvector fields on C valued in CH• (A). In order to make sense of this statement, we should recall another property of CH• (A): it is also endowed with a cup product ∪ (see Equation [6.16\)](#page-64-3) distinct from the bracket. This product allows one to express the Lie bracket on CH• (A)[[s, ∂s]] as a combination of Lie brackets and products on CH• (A) and on C[[s, ∂s]].

A piece of the quasi-isomorphism between the complexes CH• (A)[[s, ∂s]] and CH• (A[[s]]) can be made rather explicit. Denote as h an element of CH• (A). We can build a collection of elements of CH• (A[[s]]) as

$$\{\mathfrak{h}|\Phi(s),\cdots,\Phi(s)\}s^n$$
 (7.6)

i.e. as a map which acts on A[[s]] by acting on A and combining the powers of s in the arguments with s n to go in the output. This works essentially because translations commute with Q<sup>0</sup> and gives a map CH• (A)[[s]] → CH• (A[[s]]). We will recover the second half of the quasi-isomorphism momentarily.

#### <span id="page-71-0"></span>7.1 The mode algebra

We denote the Global Symmetry Algebra modes as

$$O_{n;C} \equiv \frac{1}{\hbar |C|} \oint_{|z|=1} \frac{dz}{2\pi i} z^n \operatorname{Tr} \left( C | \Phi(z+s), \cdots, \Phi(z+s) \right)$$
 (7.7)

with maximum n at 2∆<sup>C</sup> − 2, i.e. the weight of C minus 2. Notice that the map O<sup>C</sup> → O0;<sup>C</sup> annihilates descendants. These modes form an irreducible representation of dimension 2∆<sup>C</sup> − 1 under the global conformal group:

$$[L_{-1}, O_{n;C}] = -nO_{n-1;C}$$

$$[L_0, O_{n;C}] = (\Delta_C - 1 - n)O_{n;C}$$

$$[L_1, O_{n;C}] = (n + 2 - 2\Delta)O_{n+1;C}.$$
(7.8)

The tree-level action of modes On,<sup>c</sup> of the first tower of quasi-primary operators on Φ is easily described as the Wick contraction has a single pole:

$$[O_{n,\mathfrak{c}}, \Phi(s)] = (\mathfrak{c}|\Phi(s), \cdots, \eta^{(1)}) s^n \eta^{(2)}. \tag{7.9}$$

This is clearly the combination of the map CC• (A) → CH• (A) given by contraction with η and of the above-described collection of maps CH• (A) → CH• (A[[s]]).

The action of the modes of the second tower is a bit more complicated

$$[O_{n,\mathfrak{h}},\Phi(s)] = \partial_s \left( (\mathfrak{h}|\eta^{(1)};\cdots,\Phi(s))s^n \right) \eta^{(2)} - (\mathfrak{h}|\partial\Phi(s);\eta^{(1)},\cdots,\Phi(s))s^n \eta^{(2)} + \cdots \pm (\mathfrak{h}|\partial\Phi(s);\Phi(s),\cdots,\eta^{(1)})s^n \eta^{(2)}.$$

$$(7.10)$$

This expression must give a second collection of maps CH• (A)∂<sup>s</sup> → CH• (A[[s]]) which annihilate the image of I. Putting all together, we have identified the BRST cohomology in L C <sup>0</sup> with CC• (A)[[s, ∂s]] and given a chain map

$$\operatorname{CC}^{\bullet}(A)[[s, \partial_s]] \to \operatorname{CH}^{\bullet}(A[[s]]) \simeq \operatorname{CH}^{\bullet}(A)[[s, \partial_s]],$$
 (7.11)

which captures the image of L C 0 in CH• (A[[s]]). These should be analogues of divergencefree polynomial polyvector fields in C × X2.

The construction is compatible with the action of the global conformal algebra. We can start from a lowest weight element in CH• (A)[[∂s]] defined as a zero mode of a quasi-primary local operator with a given half-integral L<sup>0</sup> eigenvalue 1 − d. We can then build up a representation of dimension 2d − 1 by acting repeatedly with L<sup>1</sup> until we hit an element which is annihilated by L1.

For example, if we start from a lowest weight element of the form β ∈ CH• (A), we will build a sequence

$$\beta$$

$$(2d-2)s\beta$$

$$(2d-2)(2d-3)s^{2}\beta$$

$$\cdots$$
(7.12)

If we start from β∂<sup>s</sup> we will build a sequence

$$\beta \partial_s$$

$$(2d-2)s\partial_s \beta + 2\Delta \beta$$
... (7.13)

This gives the image of L<sup>0</sup> in CH• (A[[s]]).

#### <span id="page-72-0"></span>7.2 Polyvector fields on CP 1

There is another useful geometric perspective on the problem. The complex CH• (A)[[s, ∂s]] can be promoted to a complex of vector bundles on CP <sup>1</sup> by extending it over s = ∞ with the help of the scaling weight ∆, so that L<sup>1</sup> and L<sup>−</sup><sup>1</sup> are exchanged by s → s −1 .

Then the elements of CH• (A)[[s, ∂s]] which fit into finite-dimensional irreps of the global conformal group are simply globally-defined holomorphic polyvector fields on CP <sup>1</sup> valued in CH• (A).

In geometric situations, these are the global symmetries of a B-model defined on a 3d CY geometry

$$X_2(-1) \to \mathbb{C}P^1 \,, \tag{7.14}$$

which is related to the λ ̸= 0 dual geometry Y<sup>3</sup> by a conifold transition induced by N branes wrapping the CP <sup>1</sup> base. It is a natural way to engineer sphere correlation functions.

The planar corrections to the global symmetry algebra for a generic A should generalize this conifold transition to a non-geometric setting.

#### <span id="page-73-0"></span>7.3 The action of general local operators

For completeness, we can describe the action of the modes of a general  $\mathcal{O}_C$  local operator. The OPE of all derivatives can be organized in a generating function

$$\Phi(z_1 + s) \otimes \Phi(z_2 + s) \in A[[s]] \otimes A[[s]], \tag{7.15}$$

which is proportional to

$$\sum_{n,m} \binom{n}{m} (-1)^m \frac{s^m \eta^{(1)} \otimes s^{n-m} \eta^{(2)}}{(z_1 - z_2)^{n+1}}.$$
 (7.16)

We can now introduce some notation to lighten the complexity of this expression. The tensor product  $A[[s]] \otimes A[[s]]$  can be described naturally in terms of polynomials in two variables  $s_1$ ,  $s_2$  so that the sum collapses to the obvious

$$\frac{\eta}{z_1 - z_2 + s_1 - s_2} = \sum_{n} \frac{(s_2 - s_1)^n \eta}{(z_1 - z_2)^{n+1}}.$$
 (7.17)

Furthermore, the numerator  $E_n \equiv (s_2 - s_1)^n \eta$  can be written as  $E_n^{(1)} \otimes E_n^{(2)}$  just as we did with  $\eta$ , leaving implicit the sum over m and over summands in  $\eta$ .

In conclusion, we write

$$\Phi_j^i(z+s) \otimes \Phi_t^k(w+s) \sim \delta_t^i \delta_j^k \hbar \sum_n \frac{E_n}{(z-w)^{n+1}}$$
 (7.18)

and treat  $E_n$  as we would  $\eta$ .

We compute

$$[O_{n:C}, \Phi] = \text{Tr}(C|\Phi(s), \cdots, E_n^{(1)})E_n^{(2)},$$
 (7.19)

which gives the explicit dg-Lie algebra map from  $\mathfrak{L}_0^{\mathbb{C}}$  to  $\mathrm{CH}^{\bullet}(A[[s]])$ .

#### <span id="page-73-1"></span>7.4 A conformal-invariant presentation of the global symmetry algebra

The global conformal symmetry constrains the form of the global symmetry algebra  $\mathfrak{L}_{\lambda}$ .

For example, consider the zero modes  $O_{0,C_1}$  and  $O_{0,C_2}$  of quasi-primary operators  $\mathcal{O}_{C_i}$  of scaling dimensions  $\Delta_i$ . The commutator is also lowest weight and thus must be the zero mode of some quasi-primary operator  $\mathcal{O}_{[C_1,C_2]_0}$  of scaling dimension  $\Delta_{C_1} + \Delta_{C_2} - 1$ :

$$[O_{0;C_1}, O_{0;C_2}] = O_{0;[C_1, C_2]_0}. (7.20)$$

This relation determines the whole spin  $\Delta_{C_1} + \Delta_{C_2} - 2$  part of the  $[O_{n;C_1}, O_{m;C_2}]$  commutation relations.

Analogously, we can verify that [O1;C<sup>1</sup> , O0;C<sup>2</sup> ] − [O0;C<sup>1</sup> , O1;C<sup>2</sup> ] is also annihilated by L<sup>−</sup><sup>1</sup> and thus we can define

$$O_{0;[C_1,C_2]_1} = [O_{1;C_1}, O_{0;C_2}] - [O_{0;C_1}, O_{1;C_2}]. (7.21)$$

This determines the whole spin ∆<sup>C</sup><sup>1</sup> + ∆<sup>C</sup><sup>2</sup> − 3 part of the [On;C<sup>1</sup> , Om;C<sup>2</sup> ] commutation relations.

We can systematically define

$$\begin{split} O_{0;[C_1,C_2]_2} &= [O_{2;C_1},O_{0;C_2}] - 2[O_{1;C_1},O_{1;C_2}] + [O_{0;C_1},O_{2;C_2}] \\ O_{0;[C_1,C_2]_3} &= [O_{3;C_1},O_{0;C_2}] - 3[O_{2;C_1},O_{1;C_2}] + 3[O_{1;C_1},O_{2;C_2}] - [O_{0;C_1},O_{3;C_2}] \ (7.22) \end{split}$$

etcetera. These relations capture the spin ∆<sup>C</sup><sup>1</sup> + ∆<sup>C</sup><sup>2</sup> − n − 1 part of the [On;C<sup>1</sup> , Om;C<sup>2</sup> commutation relations. For example, with these notations we find [T, T]<sup>0</sup> = 0, [T, T]<sup>1</sup> = 2T.

This notation is useful because we can recover the full commutator [On,C<sup>1</sup> , Om,C<sup>2</sup> ] recursively from the SL(2) symmetry and the [C1, C2]<sup>n</sup> brackets. It also turns out to simplify explicit calculations. Indeed, consider the schematic contribution of a term in the OPE which scales as (z<sup>1</sup> − z2) −n−1 :

$$\oint_{|z_2|=1} \frac{dz_2}{2\pi i} z_2^{n_2} \oint_{|z_1-z_2|=\epsilon} \frac{dz_1}{2\pi i} \frac{z_1^{n_1}}{(z_1-z_2)^{n+1}} f(z_1) g(z_2) = \frac{1}{n!} \oint_{|z|=1} \frac{dz}{2\pi i} z^{n_2} g(z) \partial_z^n (z^{n_1} f(z)) .$$
(7.23)

Then the contributions to [•, •]<sup>k</sup> simplifies to

$$\frac{1}{(n-k)!}g(z)\partial_z^{n-k}f(z) \tag{7.24}$$

and in particular is only non-vanishing for n ≥ k.

The structure of L<sup>0</sup> in this presentation is thus rather simple:

- The tree-level OPE of two operators from the first tower involves a single Wick contraction and can only generate a simple pole. Only [c1,c2]<sup>0</sup> is thus nonvanishing.
- The tree-level OPE of operators from the two towers contain a simple pole and a double pole. The latter allows a non-vanishing [c, h]<sup>1</sup> contribution belonging to the first tower. Both contribute to an [c, h]<sup>0</sup> belonging to the second tower.
- The tree-level OPE of operators from the second tower contributes both an [h1, h2]<sup>2</sup> in the first tower and an [h1, h2]<sup>1</sup> in the second. The [h1, h2]<sup>0</sup> terms contains two derivatives and must thus vanish in cohomology

The tree-level OPE of two general operators is

$$\mathcal{O}_{C_1}(z_1)\mathcal{O}_{C_2}(z_2) \sim \sum_{n=0}^{\infty} \frac{1}{(z_1 - z_2)^{n+1}} \cdot \frac{1}{\hbar} \operatorname{Tr} \left( C_1 | \Phi(z_1 + s), \cdots, E_n^{(1)} \right) \left( C_2 | E_n^{(2)}, \cdots, \Phi(z_2 + s) \right). \tag{7.25}$$

We compute

$$\mathcal{O}_{[C_1, C_2]_k}(z) = \sum_{n=0}^{\infty} \frac{1}{n!} \frac{1}{\hbar} \operatorname{Tr} \left[ \partial_z^n (C_1 | \Phi(z+s), \cdots, E_{n+k}^{(1)}) \right] (C_2 | E_{n+k}^{(2)}, \cdots, \Phi(z+s))$$
(7.26)

up to total derivatives.

Somewhat implicitly, this expression defines the maps  $[C_1, C_2]_k$ . They are a collection of brackets on the quasi-primary part of  $CC^{\bullet}(A[[s]])$  which encode  $\mathfrak{L}_0$ . They provide a (poor) alternative computational method to mapping the quasi-primaries to the algebra of holomorphic polyvector fields on  $\mathbb{C}P^1$  valued in  $CH^{\bullet}(A)$ .

In order to be a bit more explicit, we can observe that away from dimension 0, the tree-level Q must pair up whole Verma modules. We can define a "quasi-primary complex"  $\mathrm{CC}^{\bullet}_{\mathrm{qp}\geq 1}(A[[s]])$  consisting of quasi-primaries in the cyclic cohomology complex.<sup>34</sup> We expect  $\mathrm{CC}^{\bullet}_{\mathrm{rel}}(A[[s]])$  and  $\mathrm{CC}^{\bullet}(A[[s]])$  to be quasi-isomorphic as chain complexes up to a collection of dimension 0 fields built from the c ghost only, without derivatives. If that is the case,  $\mathrm{CC}^{\bullet}_{\mathrm{rel},\mathrm{qp}}(A[[s]])$  and  $\mathrm{CC}^{\bullet}_{\mathrm{qp}>1}(A[[s]])$  will be equivalent.

The  $[C_1, C_2]_k$  operations must then be well-defined on the  $CC_{qp\geq 1}^{\bullet}(A[[s]])$  complex.

#### <span id="page-75-0"></span>8 Tree Level Flavour

In this section we enrich the chiral algebra by some extra (anti)fundamental fields. We will ignore for now anomaly cancellation issues. We can collect the (anti)fundamental fields into two generating fields I and J valued in auxiliary vector spaces  $\widetilde{M}$  and M. We can also include multiple copies of these fields, adding indices to get  $I^r$  and  $J_r$ .

#### <span id="page-75-1"></span>8.1 Mesonic local operators

In the planar approximation, the main actors are mesonic operators:

$$\mathcal{M}_{P}(z) \equiv \frac{1}{\hbar} (P|I(z+s); \Phi(z+s), \cdots, \Phi(z+s); J(z+s))$$
(8.1)

<span id="page-75-2"></span> $<sup>^{34}</sup>$ Quasi-primaries of dimension 1 which are total derivatives do not contribute zero modes and should be removed from  $CC^{\bullet}_{qp>1}(A[[s]])$ .

where  $(P|\cdots)$  is a map  $\widetilde{M}[[s]] \otimes A[[s]] \cdots \otimes \widetilde{M}[[s]] \to \mathbb{C}$ .

The tree-level BRST differential endows M with the structure of a right A-module and M with the structure of a left A-module, so that  $Q_0I = I\Phi$  and  $Q_0J = \Phi J$ . The action of  $Q_0$  on functionals

$$\mathcal{M}_{Q_0 P}(z) \equiv Q_0 \,\mathcal{M}_P(z) \tag{8.2}$$

receives contributions from both the variation of  $\Phi$  and the variation of I and J. Essentially by definition, it is dual to the bar complex for a (derived) tensor product  $\widetilde{M}[[s]] \otimes_{A[[s]]} M[[s]]$  and thus mesons are labelled by linear functionals on that tensor product.

The tensor product can be simplified drastically via a canonical quasi-isomorphism

$$\widetilde{M}[[s]] \otimes_{A[[s]]} M[[s]] \simeq (\widetilde{M} \otimes_A M)[[s]]$$
 (8.3)

so we expect quasi-primaries to be labelled by linear functionals on  $\widetilde{M} \otimes_A M$ . We can present them explicitly as

$$\mathcal{M}_{\mathfrak{p}}(z) \equiv \frac{1}{\hbar}(\mathfrak{p}|I(z); \Phi(z), \cdots, \Phi(z); J(z)) \tag{8.4}$$

where  $(\mathfrak{p}|\cdots)$  is a map  $\widetilde{M}\otimes A\cdots\otimes M\to\mathbb{C}$ .

In a dg-TFT setting, a probe brane P in T[A] can be encoded into the spaces of junctions from P to B[A] and vice versa. These are  $\widetilde{M}$  and M respectively. The brane P can be combined with a brane wrapping  $\mathbb C$  in the extra direction to produce junctions labelled by  $\widetilde{M}[[s]]$  and M[[s]] respectively. The dual to  $\widetilde{M}[[s]] \otimes_{A[[s]]} M[[s]]$  can be identified with a space of open string states attached to this brane, providing one entry of the tree-level holographic dictionary.

#### <span id="page-76-0"></span>8.2 Space-filling probe branes

In practice, the most typical option for fundamental matter is some symplectic bosons or fermions coupled to the overall gauge group. Then M and  $\widetilde{M}$  are supported in ghost number 1 and only  $A_0$  acts non-trivially, encoding the action of the gauge group on the matter fields.

In these situations, the derived tensor product  $\widetilde{M} \otimes_A M$  will be quite large. Roughly, it involves bosonic generators of ghost number 0 dual to  $A_1$  and should be comparable in size to cyclic cohomology. The corresponding probe branes should be thought of as space-filling and are useful probes of the holographic dual geometry.

A canonical possibility is to take  $M = A_0[1]$ , the algebra itself shifted to ghost number 1, and  $\widetilde{M} = A_0^{\vee}[1]$  to have a natural pairing. We can denote the corresponding canonical space-filling brane as O[A].

The mesons for that brane are dual to

$$A_0^{\vee} \otimes_A A_0 \tag{8.5}$$

and include IJ bilinears labelled by  $A_0$  itself.

Further deformations of the mesonic BRST differential, possibly allowing for fundamental fields of non-zero ghost number, will give more general modules to be interpreted as generic D-branes in the transverse geometry  $X_2$ .

#### <span id="page-77-0"></span>8.3 Open symmetry algebra

We can define the open version of the global symmetry algebra from the modes of mesons. Including multiple flavours, we get modes we can denote as

$$(O_{n;P})_s^r. (8.6)$$

The linearized commutators between these modes have an interesting index structure:

$$[(O_{n_1;P_1})_s^r, (O_{n_2;P_2})_v^u] = \delta_s^u (O_{n_1;P_1} \cdot O_{n_2;P_2})_v^r \pm \delta_v^r (O_{n_2;P_2} \cdot O_{n_1;P_1})_s^u, \tag{8.7}$$

which defines an algebra structure  $\mathfrak{P}_{\lambda}$  on the global  $O_{n;P}$  modes. In the presence of k copies of the fudamentals, the open global symmetry algebra is  $\mathfrak{gl}_k[\mathfrak{P}_{\lambda}]$  (up to a small mixing with  $\mathfrak{L}_{\lambda}$  we discuss momentarily).

We denote the OPE numerator pairing (anti)fundamental fields as  $\mu \in M \otimes \widetilde{M}$ , with the same  $\mu^{(1)} \otimes \mu^{(2)}$  notation used for  $\eta$ .

At tree level, the OPE between mesons only receives contributions from contractions of an fundamental and an anti-fundamental fields. Restricting to  $O_{n;p}$ , the OPE has only a simple pole and the mode algebra is controlled by the zero modes, reproducing the natural product

$$(\mathfrak{p}_{1}\mathfrak{p}_{2}|\widetilde{m}_{0}; a_{1}, \cdots, a_{n_{1}+n_{2}}; m_{n_{1}+n_{2}+1})$$

$$\equiv (\mathfrak{p}_{1}|\widetilde{m}_{0}; a_{1}, \cdots, a_{n_{1}}; \mu^{(1)})(\mathfrak{p}_{2}|\mu^{(2)}; a_{n_{1}+1}, \cdots, a_{n_{1}+n_{2}}; m_{n_{1}+n_{2}+1})$$
(8.8)

on  $(\widetilde{M} \otimes_A M)^{\vee}$ .

Alternatively, we can focus on the transformations of I and J induced by  $O_{n;P}$ . Parsing definitions, these coincide respectively with  $A_{\infty}$  endomorphisms of M[[s]] and  $\widetilde{M}[[s]]$  and compose accordingly. We thus get maps:

$$\mathfrak{P}_0 \to \operatorname{End}_{A[[s]]}(M[[s]]) \qquad \mathfrak{P}_0 \to \operatorname{End}_{A[[s]]}(\widetilde{M}[[s]])^{\operatorname{op}}.$$
 (8.9)

The spaces of endomorphisms are quasi-isomorphic to  $\operatorname{End}_A(M)[[s]]$ , etcetera

Effectively, we have mapped  $\mathfrak{P}_0^{\mathbb{C}}$  to functions on  $\mathbb{C}$  valued in  $\operatorname{End}_A(M)$ . We expect the part  $\mathfrak{P}_0$  of  $\operatorname{End}_A(M)[[s]]$  which consists of finite-dimensional representations of the global conformal algebra to be identified with global holomorphic sections of  $\operatorname{End}_A(M)$  as a vector bundle over  $\mathbb{C}P^1$ .

We can specialize to the case where M and  $\widetilde{M}$  are  $A_0$  modules, and in particular to O[A], i.e.  $M = A_0[1]$ . We can denote the corresponding mode algebra as  $\mathfrak{O}_{\lambda}[A]$ . It contains a copy of  $A_0$  from the zero modes of IJ mesons.

The algebra  $\operatorname{End}_A(A_0)$  is a kind of Koszul dual to A. It is analogous to an algebra of holomorphic functions on the transverse space  $X_2$ .

As we discussed in the standard example,  $\mathfrak{L}_{\lambda}$  maps naturally to the Hochschild cohomology of  $\mathfrak{P}_{\lambda}$ .

### <span id="page-78-0"></span>9 Determinant-like local operators

The analysis is completely parallel to our standard example: a determinant-like operator is defined by an auxiliary integral on some (anti)fundamental 0-dimensional fields. Fields and anti-fields alike can be assembled into generating fields  $\widetilde{\Psi}$  and  $\Psi$ .

A typical BV action will take the form

$$S_{\rm BV} = (\widetilde{\Psi}; m\Psi) + (\widetilde{\Psi}; \Phi(z)\Psi), \qquad (9.1)$$

where  $\widetilde{\Psi}$  and  $\Psi$  are valued in dg-modules  $\widetilde{M}$  and M for A equipped with a pairing  $(\bullet; \bullet)$  of ghost number 3.

If the auxiliary fields have a standard form, the modules will be supported in degree 1 and 2, with  $M_1$  being paired to fundamental fields and being dual to  $\widetilde{M}_2$  and vice versa. We denote the differential as m, as it gives rise to a quadratic mass term for the auxiliary fields.

These modules are promoted to A[[s]] modules with s acting as multiplication by z. Coupling to derivatives of fields can be implemented by more general A[[s]] modules. We can take multiple copies of the fields to describe powers or products of determinants.

The BV action must satisfy the master equation

$$(Q_{\rm BRST} + \hbar \Delta_{\rm BV}) e^{S_{\rm BV}} \,. \tag{9.2}$$

It is easy to see that the assumptions above ensure that this is the case at tree-level:  $Q_0$  produces a  $(\widetilde{\Psi}; \Phi(z)\Phi(z)\Psi)$  term which is cancelled by  $\{S_{\rm BV}, S_{\rm BV}\}_{\rm BV}$ .

A general example would have  $M = A_0[\theta]$ ,  $\widetilde{M} = A_0^{\vee}[\theta]$ . The module structure is given by specifying a linear function  $\mu$  on  $A_1$ , specifying how they map to a multiple of  $\theta$ . This selects which linear combination of the Z fields we are taking the determinant of and generalizes the "u" parameter in the standard example.

#### <span id="page-79-0"></span>9.1 A BV algebra of mesons

We can describe algebraically the space of "determinant modifications" at tree level, i.e.

 $\mathcal{M}_D \equiv \frac{1}{\hbar} (D|\widetilde{\Psi}; \Phi(z+s), \cdots, \Phi(z+s); \Psi)$  (9.3)

inserted in the zero-dimensional auxiliary integral to modify the local operator, leading to  $\mathfrak{D}_{\lambda}$  as in the canonical example.

The linear and bi-linear terms in the action of  $Q_{\text{BRST}} + \hbar \Delta_{\text{BV}}$  on a modified determinant equip  $\mathfrak{D}_{\lambda}$  with the structure of a dg-algebra.

At tree level, the tensor product computing the cohomology of  $\mathfrak{D}_{\lambda}$  simplifies to

$$\widetilde{M} \otimes_{A[[s]]} M = \left(\widetilde{M} \otimes_A M\right) [ds],$$
 (9.4)

so that we expect to have two towers of modifications.

The product should arise from the BV Laplacian contracting a field and an antifield in different modifications:

$$\mathcal{M}_{D}\mathcal{M}_{D'} \to \frac{1}{\hbar} (D|\widetilde{\Psi}; \Phi(z+s), \cdots, \Phi(z+s); \mu^{(1)}) (D'|\mu^{(2)}; \Phi(z+s), \cdots, \Phi(z+s); \Psi)$$
(9.5)

leading to the familiar product on  $\widetilde{M} \otimes_{A[[s]]} M$ .

#### <span id="page-79-1"></span>9.2 Open modifications

In the presence of both fundamental fields and determinants, there will be mixed mesonic operators  $\mathfrak{M}_{\lambda}$  and  $\widetilde{\mathfrak{M}}_{\lambda}$ .

At tree level, these are controlled by tensor products such as  $\widetilde{M}_D \otimes_{A[[s]]} M_P[[s]] \simeq \widetilde{M}_D \otimes_A M_P$ . For the simplest space-filling branes, that becomes  $\widetilde{M} \otimes_A A_0$ 

Geometrically, we have a giant graviton brane D which is Dirichlet in  $\mathbb{C}$  and a space-filling brane P which is Neumann in  $\mathbb{C}$ . At tree level, open strings stretched between the two are controlled by the boundary-changing local operators in the T[A] factor of the theory.

## <span id="page-79-2"></span>10 A non-commutative example at tree-level

Consider now the case of an U(N) gauge theory with 2n + 2 bosonic adjoint fields and 2n fermionic ones. This has an OSp(2n|2n + 2) global symmetry. We can denote the matter fields collectively as  $Z_a(z)$ , with an OPE proportional to the ortho-symplectic form  $\omega_{ab}$ .

The corresponding algebra A has ghost number 1 generators θ <sup>A</sup>, which satisfy

$$\theta^a \theta^b = \omega^{ab} u \tag{10.1}$$

for the only ghost number 2 generator u, dual to the b(z) field. To be more precise, our algebra A is defined as the quotient algebra

<span id="page-80-0"></span>
$$A = \mathbb{C}\langle \theta^a, u \rangle / (\theta^a \theta^b = \omega^{ab} u, \theta^a u = 0), \tag{10.2}$$

where the notation C⟨. . .⟩ represents the non-commutative algebra freely generated by the variables in the angle bracket.

The trace map (•) : A → C is simply defined by (u) = 1 and (others) = 0.

We would like to identify A as the algebra of boundary local operators for some "Dirichlet" brane in a dg-TFT T[A], but we do not have any alternative definition of the theory.

Standard fundamental matter gives mesons which are computed from

$$(\mathbb{C} \otimes_A \mathbb{C})^{\vee} \equiv A^! \,. \tag{10.3}$$

Through the presentation [\(10.2\)](#page-80-0) of A, we can view it as a quadratic-linear algebra. By the standard technique of the quadratic Koszul duality [\[57\]](#page-120-13), we find that its Koszul dual can be computed by the complex

<span id="page-80-1"></span>
$$(\mathbb{C}\langle \zeta_a, \nu \rangle, d), \qquad (10.4)$$

with dν = ω abζaζb, dζ<sup>a</sup> = 0. Computing the cohomology eliminates the variable ν and imposes the relation

<span id="page-80-2"></span>
$$\omega^{ab}\zeta_a\zeta_b = 0. (10.5)$$

Thus we obtain the Koszul dual algebra

$$A^! = \mathbb{C}\langle \zeta_a \rangle / (\omega^{ab} \zeta_a \zeta_b = 0), \qquad (10.6)$$

which is a non-commutative algebra for n > 0.

The interpretation of this result is intuitive: the meson operators

$$I^A Z_{a_1} \cdots Z_{a_n} J_B \tag{10.7}$$

are Q0-closed but a contraction of ω ab with a pair of consecutive indices gives an exact operator. The Q<sup>0</sup> image of an operator with an extra b insertion plays a role analogous to the d image of ν in [\(10.4\)](#page-80-1).

This nicely sets the stage for a computation of the Q<sup>0</sup> cohomology on single-trace operators. If A was commutative, the Hochschild cohomology would be given by the tensor product of the algebras C[θ a ] and C[ζa]. In the non-commutative case, the Hochschild cohomology HH• (A) can also be computed by the tensor product A ⊗ A! , but now equipped with a differential. We can write this complex (A ⊗ A! , QCH) as

$$0 \to A^! \stackrel{Q_{\rm CH}}{\to} \bigoplus_a A^! \theta^a \stackrel{Q_{\rm CH}}{\to} A^! u \to 0, \qquad (10.8)$$

where QCHf(ζ) = P[ζa, f(ζ)]θ a , and QCH(f(ζ)θ a ) = [ω abζb, f(ζ)]u. This complex can be understood as the analog of polyvector fields. For n = 0, we immediately see that QCH = 0, and the above complex reproduces the space of polyvector fields on C 2 . In the following, we focus on the case when n > 0.

To compute the cyclic cohomology, it will be convenient to use the trace pairing to dualize A in the above complex. We write it as

$$0 \to A^! u^* \stackrel{Q_{\text{CH}}}{\to} \bigoplus_a A^! d\zeta_a \stackrel{Q_{\text{CH}}}{\to} A^! \to 0.$$
 (10.9)

The differential now takes the following form

$$Q_{\text{CH}}(f(\zeta)u^*) = \sum \omega_{ab}[\zeta_a, f(\zeta)]d\zeta_b,$$

$$Q_{\text{CH}}(g(\zeta)d\zeta_a) = [\zeta_a, g(\zeta)].$$
(10.10)

After this identification, we can now write the Connes B operator as B = dζ<sup>a</sup> ∂ ∂ζa .

In general, the cyclic cohomology is computed as a bi-complex given by (A ⊗ A! [v], QCH + vB). However, our algebra has the important property that it carries a scaling degree. Then, according to our discussion around Equation [\(6.12\)](#page-64-2), the positive scaling degree part of the cyclic cohomology can be identified with the kernel of B.

We first find that the kernel of the map QCH : A!u <sup>∗</sup> → L <sup>a</sup> A!dζ<sup>a</sup> is the center Z(A! ) of the non-commutative algebra A! . In the commutative case, the center is the whole algebra, and they correspond to the B (n) tower in the standard example. In the non-commutative case, the center is much smaller. This implies that many of the original B (n) tower operators no longer exist. For example QTr bZ<sup>c</sup> = ω abTrZaZbZc, so that Tr bZ<sup>c</sup> is not BRST closed. The center Z(A! ) contains at least C, corresponding to

$$\mathcal{B}^{(0)} = \operatorname{Tr} b. \tag{10.11}$$

However, we do not know if there exists any other non-trivial element in the center Z(A! ).

The kernel of B on A! only gives C, which correspond to Tr c which we don't consider. This also exclude any possibility with Tr (cZ<sup>a</sup> . . .). We thus find that the remaining operators in the (relative) cyclic cohomology, or the first tower, is given by the A(n) tower <sup>1</sup>

nℏ c <sup>a</sup>1,··· ,a<sup>n</sup> TrZ<sup>a</sup><sup>1</sup> · · ·Z<sup>a</sup><sup>n</sup> . (10.12)

These are the cyclic words on ζ<sup>a</sup> modulo the relation [\(10.5\)](#page-80-2). The quotient by the relation can be realized by considering Q0Tr (bZ<sup>i</sup><sup>1</sup> . . . Z<sup>i</sup><sup>n</sup> ).

According to the discussion in Section [6.2,](#page-62-0) the cyclic cohomology HC• (A) also characterizes quasi-primaries in the second tower. For the same reason that the original B (n) tower collapses, most of the original D(n) tower operators are killed by BRST invariance. The C in the center Z(A! ) gives the stress tensor

$$\mathcal{D}^{(0)} = \frac{1}{2\hbar} \text{Tr} \left( \omega^{ab} Z_a \partial Z_b + 2b \partial c \right), \qquad (10.13)$$

which survives in the BRST cohomology. We also have the following C (n) tower

$$\frac{1}{n\hbar} \mathfrak{c}^{a_1,\dots,a_n} \operatorname{Tr} \partial c Z_{a_1} \dots Z_{a_n} , \qquad (10.14)$$

with the same condition on c <sup>a</sup>1,··· ,a<sup>n</sup> as before. Naively, we don't need the cyclic condition on c <sup>a</sup>1,··· ,a<sup>n</sup> . However, we can check that two operators Tr ∂cZ<sup>a</sup><sup>1</sup> · · ·Z<sup>a</sup><sup>n</sup> , (±)Tr ∂cZ<sup>a</sup><sup>2</sup> · · ·Z<sup>a</sup><sup>n</sup> Z<sup>a</sup><sup>1</sup> related by a cyclic permutation on Z<sup>a</sup><sup>i</sup> differ by a BRST exact element Q0Tr (∂Z<sup>a</sup>1Z<sup>a</sup><sup>2</sup> . . . Z<sup>a</sup><sup>n</sup> ).

Finally, we could consider some determinant operators det(m + u <sup>a</sup>Za). This leads to an A-module M<sup>u</sup> = C[θ], defined by mapping θ <sup>a</sup> → u a θ and u → 0, with differential mθ. We define an auxiliary linear map p(ζa) = u a θ on the subspace (A! )<sup>1</sup> = ⊕aCζa. Then ker p is a subspace of (A! )1. We define M! <sup>u</sup> = ⟨ker p⟩ as the subalgebra of A! generated by ker p.

We are particularly interested in the space of open modifications, computed from

$$(\mathbb{C} \otimes_A M_u)^{\vee} \equiv M_u! \qquad (10.15)$$

This can be derived using the standard Koszul resolution (A ⊗ A¡ , dKos) of C [35](#page-82-0). We find that (C ⊗<sup>A</sup> Mu) ∨ can be computed by the complex (A! [θ ∗ ], d) with differential dζ<sup>a</sup> = u a θ ∗ . Cohomology of this complex gives us M! u . This is an A! module defined by the left ideal generated from m + u a ζa, with a natural identification as IZ<sup>a</sup><sup>1</sup> · · ·Z<sup>a</sup><sup>n</sup> ψ modifications.

<span id="page-82-0"></span><sup>35</sup>Here, A¡ is the Koszul dual coalgebra of A, which is the linear dual of the Koszul dual algebra A! . We refer to [\[57\]](#page-120-13) for a general discussion of this and the Koszul complex.

### <span id="page-83-0"></span>11 Categorical Back-reaction

As long as a planar 1-loop anomaly cancellation condition holds, we can follow the canonical example and define a dg-Lie algebra  $\mathfrak{L}_{\lambda}$  from global modes of single-trace operators. Given choices P of fundamental chiral matter and D of determinant operators, we can define dg-algebras  $\mathfrak{P}_{\lambda}$  and  $\mathfrak{D}_{\lambda}$  from global modes of mesons and determinant modifications, as well as  $\mathfrak{M}_{\lambda}$  and  $\widetilde{\mathfrak{M}}_{\lambda}$  bimodules of open determinant modifications. Any anomalies introduced by the fundamental fields will at most curve some of the algebras.

Our general strategy is to tentatively define a dual world-sheet theory  $T_{\lambda}$  and D-branes  $P_{\lambda}$  and  $D_{\lambda}$  from this data. The definition of that data via BRST anomalies essentially guarantees the axiomatic properties expected from them. This includes maps from  $\mathfrak{L}_{\lambda}$  into the Hochschild cohomology of the algebras and modules, the module action themselves, etc.

In the remainder of the paper we will begin the work of making these constructions explicit.

We begin by reviewing the one-loop anomaly cancellation. Recall that the BRST differential is the zero mode of a BRST current, which we can concisely write as

$$J_{\text{BRST}} = \frac{1}{3\hbar} (\Phi \Phi \Phi). \tag{11.1}$$

The full action of Q on local operators has a tree-level  $Q_0$  and 1-loop  $\hbar Q_1$  parts, involving 1 or 2 Wick contractions with  $J_{\text{BRST}}$ . We would like  $Q_0^2 = 0$ ,  $\{Q_0, Q_1\} = 0$  and  $Q_1^2 = 0$  separately, so we have a BRST symmetry for all values of  $\hbar$ .

We can actually require the stronger condition that  $QJ_{BRST}=0$ . This condition has a tree-level part  $Q_0J_{BRST}=0$ , involving one Wick contraction, and a 1-loop part  $Q_1J_{BRST}=0$  involving two.

The tree-level condition is

$$\operatorname{Tr}(\Phi\Phi\eta^{(1)})(\eta^{(2)}\Phi\Phi) = \operatorname{Tr}(\Phi\Phi\Phi\Phi) = 0 \tag{11.2}$$

and is identically satisfied by cyclicity of ().

At 1-loop, we have a planar contribution

$$\operatorname{Tr}\left(\partial\Phi\eta_{1}^{(1)}\eta_{2}^{(1)}\right)\left(\eta_{2}^{(2)}\eta_{1}^{(2)}\Phi\right). \tag{11.3}$$

We named the two  $\eta$  tensors to avoid confusion. There is a second term involving a different relative order of Wick contractions, leading to a double trace. We will ignore it, as it does not obstruct the construction of the linearized planar structures we are interested in.

The "planar anomaly" cancellation condition on A is thus

$$(a\eta_1^{(1)}\eta_2^{(1)})(\eta_2^{(2)}\eta_1^{(2)}b) = 0, (11.4)$$

i.e.

$$(a\eta^{(1)}\eta^{(2)}b) = 0, (11.5)$$

i.e.

$$\eta^{(1)}\eta^{(2)} = 0. (11.6)$$

In the canonical example, this holds because of a cancellation between bosons and fermions.

#### <span id="page-84-0"></span>11.1 Adding (anti)fundamental chiral fields

The BRST current gains a second term in the presence of (anti)fundamental fields:

$$J_{\rm BRST}^{IJ} = \frac{1}{\hbar} (I\Phi J). \tag{11.7}$$

If we ignore non-planar contributions, the potential BRST anomaly comes from terms with two Wick contractions. This leads to something like

$$(\tilde{m}\eta^{(1)}\mu^{(1)})(\mu^{(2)}\eta^{(2)}m) = 0, \qquad (11.8)$$

which is guaranteed by again by η (1)η (2) = 0. We are thus free to add any fundamental matter at the planar level.

We now describe the general structure of linear planar corrections, in greater generality than the rest of the paper.

We will work with a matrix super-field Φ of ghost number 1, valued in an auxiliary space V which plays a role analogous to that of A[[s]] in the main text.

### <span id="page-84-1"></span>11.2 Tree level

The most general form of a tree-level differential acting via a Leibniz rule is

$$Q^{(0)}\Phi = \{Q|\Phi\} + \{Q|\Phi,\Phi\} + \{Q|\Phi,\Phi,\Phi\} + \cdots$$
(11.9)

where

$$\{Q|\bullet,\cdots,\bullet\}:V^{\otimes(n+1)}\to V$$
 (11.10)

is a collection of brackets on V . The condition Q<sup>2</sup> = 0 gives a set of quadratic relations which makes {Q|•, · · · , •} into an A<sup>∞</sup> algebra.

A collection L of maps V <sup>⊗</sup>(n+1) → V is, by definition, an element of the Hochschild cohomology complex HH• (V, V ). We can denote the transformation

$$L\Phi = \{L|\Phi\} + \{L|\Phi,\Phi\} + \{L|\Phi,\Phi,\Phi\} + \cdots$$
 (11.11)

by the same symbol. The bracket {•, •} on the Hochschild complex is defined in such a manner that

$$[L, L']\Phi = \{\{L, L'\}|\Phi\} + \{\{L, L'\}|\Phi, \Phi\} + \{\{L, L'\}|\Phi, \Phi, \Phi\} + \cdots$$
(11.12)

and is a sum over all possible ways of inserting a map into the other and vice versa. In this notation, the differential on the Hochschild cohomology complex is simply:

$$QL = \{Q, L\}$$
. (11.13)

The RHS of this equation corresponds diagrammatically to:

![](_page_85_Figure_7.jpeg)

Figure 3. Illustration of how the Hochschild differential Q acts on a generic L. Black lines represent Φ's.

It is reasonable to identify HH• (V, V ) as the "tree level symmetry algebra" of the underlying theory: classical field redefinitions which are compatible with the BRST differential.

Notice that deformations of the differential are controlled by a quadratic MC equation

$$QV + \{V, V\} = 0. (11.14)$$

The definitions can be extended to the case where QΦ includes a constant source term {Q|}, i.e. V is a curved A<sup>∞</sup> algebra.

#### <span id="page-86-0"></span>11.3 Planar transformations

At the planar level, the BRST differential is a sum of terms which act on m + 1 consecutive fields in a trace or meson and replaces them with a sum of products of n + 1 fields. We can write that as

$$Q^{(m)}\Phi^{\otimes (m+1)} = \{Q|\Phi\}_m + \{Q|\Phi,\Phi\}_m + \{Q|\Phi,\Phi,\Phi\}_m + \cdots$$
 (11.15)

where now

$$\{Q|\bullet,\cdots,\bullet\}_m:V^{\otimes(n+1)}\to V^{\otimes(m+1)}.$$
 (11.16)

Denote the space of collections of such maps as BC•,• (V ). This is equipped with an obvious bracket such that

$$\sum_{k=0}^{m} [L_1^{(k)}, L_2^{(m-k)}] \Phi = \{\{L, L'\} | \Phi\}_m + \{\{L, L'\} | \Phi, \Phi\}_m + \{\{L, L'\} | \Phi, \Phi\}_m + \cdots (11.17) \}$$

The bracket is a sum of terms where the output of one operation is inserted in a consecutive sequence of slots in the other operation in all possible ways, and vice versa (see for example Figure [4\)](#page-86-1).

![](_page_86_Picture_8.jpeg)

Figure 4. Illustration of the resulting combinations of two specific maps L<sup>1</sup> and L2. Black lines represent Φ's.

<span id="page-86-1"></span>We thus have quadratic relations {Q, Q} = 0. We denote this structure as a "planar algebra".

The BRST differential gives a differential on BC•,• (A):

$$QL = \{Q, L\}. \tag{11.18}$$

We denote the resulting complex as the "planar Hochschild cohomology complex" BH•,• (V, Q) for (V, Q).

Again, deformations of the planar algebra structure are controlled by a quadratic MC equation

$$QL + \{L, L\} = 0. (11.19)$$

On general grounds, a planar symmetry of the underlying theory should manifest itself as a deformation of the planar algebra and thus an element of BH•,• (V, Q). We are led to identify BH•,• (V, Q) as a "formal planar symmetry algebra" of the underlying theory/planar algebra. It is not obvious that BH•,• (V, Q) should coincide with the actual planar symmetry algebra, which e.g. could be a sub-algebra of BH•,• (V, Q). At first sight, BH•,• (V, Q) is "too big". Still, the ability to do algebra computations in BH•,• (V, Q) should be invaluable.

The definitions can be extended to the case where Q(m) includes a constant source term {Q|}m, i.e. V is a curved planar algebra.

#### <span id="page-87-0"></span>11.4 Modules

Fundamental flavours in a theory will transform at tree level as

$$Q_M^{(0)}J = \{Q_M|; J\} + \{Q_M|\Phi; J\} + \{Q_M|\Phi, \Phi; J\} + \cdots$$
 (11.20)

where

$${Q_M|\bullet, \cdots; \bullet}: V^{\otimes n} \otimes M \to M.$$
 (11.21)

Suppose we have a tree level BRST differential Q that defines a A<sup>∞</sup> algebra structure on V . The condition (Q + QM) <sup>2</sup> = 0 gives a set of quadratic relations which makes M equipped with {QM|•, · · · , •; •} into an A<sup>∞</sup> module of V .

Given two modules M<sup>1</sup> and M2, we can consider the collection L<sup>12</sup> of maps V <sup>⊗</sup><sup>n</sup> ⊗ M<sup>1</sup> → M2. We can denote the transformation

$$L_{12}J_2 = \{L_{12}|; J_1\} + \{L_{12}|\Phi; J_1\} + \{L_{12}|\Phi, \Phi; J_1\} + \cdots$$
 (11.22)

by the same symbol. The composition • ◦ • can be defined in such a manner that

<span id="page-87-1"></span>
$$L_{12}L_{23}J_3 = \{L_{12} \circ L_{23} | ; J_1\} + \{L_{12} \circ L_{23} | \Phi; J_1\} + \{L_{12} \circ L_{23} | \Phi, \Phi; J_1\} + \cdots$$
 (11.23)

and is given by inserting L<sup>12</sup> into the corresponding slot of L<sup>23</sup> (see Figure [5\)](#page-88-1).

![](_page_88_Picture_0.jpeg)

Figure 5. Diagrams corresponding to the RHS of Equation [\(11.23\)](#page-87-1). Solid lines represent Φ's, dashed lines represent J's.

<span id="page-88-1"></span>Note that we can also compose a map Q : V ⊗• → V with L<sup>12</sup> such that Q ◦ L<sup>12</sup> is a sum of over all possible ways of inserting Q into L12. Using this notation, we can define a differential on the space of maps {L12}

$$QL_{12} = (Q + Q_1) \circ L_{12} - (-1)^{\cdots} L_{12} \circ Q_2.$$
(11.24)

By definition, an A<sup>∞</sup> morphism from M<sup>1</sup> to M<sup>2</sup> is a map L<sup>12</sup> such that QL<sup>12</sup> = 0.

#### <span id="page-88-0"></span>11.5 Planar modules

At the planar level, the BRST symmetry will now act on a fundamental field J together with a collection of consecutive Φ fields before it:

$$Q_M^{(m)} \Phi^{\otimes m} \otimes J = \{Q_M | ; J\}_m + \{Q_M | \Phi; J\}_m + \{Q_M | \Phi, \Phi; J\}_m + \cdots$$
 (11.25)

encoded in maps

$${Q_M|\bullet, \cdots; \bullet}_m: V^{\otimes n} \otimes M \to V^{\otimes m} \otimes M.$$
 (11.26)

We call such a pair a (M, QM) a "planar module" for the planar algebra (V, Q) if it satisfy (Q + QM) 2 .

We get for free a category PMod<sup>V</sup> of planar modules. Given two planar modules M1, M2, we consider collections of maps

$$L_{12}: V^{\otimes n} \otimes M_1 \to V^{\otimes m} \otimes M_2. \tag{11.27}$$

These can be composed in an obvious manner (see for example Figure [6\)](#page-89-1).

Furthermore, we have a differential defined in the obvious way:

$$QL_{12} = (Q + Q_1)L_{12} - (-1)^{\cdots}L_{12}(Q + Q_2).$$
(11.28)

![](_page_89_Picture_0.jpeg)

Figure 6. Illustration of the resulting combinations of two specific maps L<sup>12</sup> and L23. Solid lines represent Φ's, dashed lines represent J's.

<span id="page-89-1"></span>Then a morphism in the category of planar modules is defined to be a map L<sup>12</sup> that QL<sup>12</sup> = 0 [36](#page-89-2) .

Again, PMod<sup>V</sup> seems to be a formal version of an actual category which describes planar calculations in the presence of fundamental fields: a consistent way to include fundamental fields will map to an object of PMod<sup>V</sup> and deformations of that will map to its morphisms. In other words, there should be an actual planar category which deforms the category of A<sup>∞</sup> modules which appear at tree level and which has a functor to PMod<sup>V</sup> which is likely not surjective.

The planar-level statement of open-closed duality is that there should be a backreacted world-sheet theory reproducing planar calculations. A category is a natural way to present a 2d TFT. It would be interesting to know if the formal category PMod<sup>V</sup> could give an algebraic description of the back-reacted world-sheet theory. As a test of this idea, we are led to the following conjectures:

- "Easy conjecture": the planar global symmetry algebra BH•,• (V ) acts on PMod<sup>V</sup> , i.e. there is a nice map from BH•,• (V ) to the Hochschild cohomology of PMod<sup>V</sup> .
- "Unlikely conjecture": the planar global symmetry algebra BH•,• (V ) is quasiisomorphic (in the category of L<sup>∞</sup> algebra) to the Hochschild cohomology of PMod<sup>V</sup> .

The first conjecture, if true, should follow from some careful diagram-chasing.

## <span id="page-89-0"></span>12 The Planar global symmetry algebra

We now specialize the general considerations to the case of the global symmetry algebras. We should first discuss planar corrections to the BRST cohomology of single-trace

<span id="page-89-2"></span><sup>36</sup>The derived category PMod<sup>V</sup> should be defined by a suitable localization with respect to the class of quasi-isomorphisms.

operators (ignoring multi-traces).

In this approximation, the BRST differential is the sum of two parts Q<sup>0</sup> and λQ1. The latter acts on two consecutive fields in the single-trace operator and maps it to a single field (with an extra derivative acting on it):

$$\Phi(s) \otimes \Phi(s') \to \left(\frac{\Phi(s) - \Phi(s')}{s - s'} \eta_1^{(1)} \eta_2^{(1)}\right) \eta_2^{(2)} \otimes \eta_1^{(2)} = \frac{\Phi(s) - \Phi(s')}{s - s'} \eta^{(1)} \otimes \eta^{(2)}. \quad (12.1)$$

Overall, we obtain a deformation CC• λ [A] of the cyclic cohomology complex CC• [A[[s]]]. We propose this as a dg-TFT description of the collection of distributional local operators in the back-reacted world-sheet theory.

(Planar, single trace) cohomology classes will be polynomials in λ, starting with a Q<sup>0</sup> cohomology class and continuing with corrections which compensate for the action of λQ<sup>1</sup> on the leading term. It may or not be possible to complete a Q<sup>0</sup> class to a full class. We can express the obstruction as the action of Q<sup>1</sup> on HC• [A[[s]]].

#### <span id="page-90-0"></span>12.1 The planar mode algebra

The modes in the planar algebra act on single-trace local operator at the linearized level as a sum of transformations which act on a sequence of consecutive symbols in the trace. We can thus represent them as elements in the planar algebra BC•,• (A[[s]]) and L<sup>λ</sup> as a dg-Lie sub-algebra of the planar algebra.

The planar part of the action of some On;<sup>C</sup> mode is computed by taking m + 1 Wick contractions of consecutive fields in O<sup>C</sup> and in the target. Concretely:

<span id="page-90-2"></span>
$$\Phi(s_1) \otimes \cdots \otimes \Phi(s_{m+1}) 
\to \oint \frac{dz}{2\pi i} z^n \left( C | \Phi(z+s), \cdots, \frac{\eta_{m+1}^{(1)}}{z+s-s_{m+1}}, \cdots, \frac{\eta_1^{(1)}}{z+s-s_1} \right) \eta_1^{(2)} \otimes \cdots \eta_{m+1}^{(2)},$$
(12.2)

i.e.

<span id="page-90-3"></span>
$$\Phi(s_1) \otimes \cdots \otimes \Phi(s_{m+1}) \to \sum_{n_i \mid n = m + \sum_i n_i} \left( C | \Phi(s), \cdots, E_{n_{m+1}}^{(1)}, \cdots, E_{n_1}^{(1)} \right) E_{n_1}^{(2)} \otimes \cdots E_{n_{m+1}}^{(2)}.$$
(12.3)

gives the action of O (m) n;C . In Appendix [A](#page-100-0) we provide a different expression for the planar action of the mode algera.

#### <span id="page-90-1"></span>12.2 The planar fundamental algebra

By the same token, we can define the action of the modes of mesons, collected into the planar algebras P<sup>λ</sup> and in particular Oλ(A). They are embedded into the category PModA[[s]].

Recall that the tree-level cohomology of mesonic operators is dual to A<sup>∨</sup> <sup>0</sup> ⊗<sup>A</sup> A<sup>0</sup> up to a ghost number shift. The mesons built from the c ghost only are computed by (A<sup>∨</sup> <sup>0</sup> ⊗<sup>A</sup><sup>0</sup> A0) <sup>∨</sup> = A<sup>0</sup> and are recognized as gauge-invariant bilinears of the schematic form IJ.

The mesons of the schematic form IZJ are roughly labelled by elements of A1. Each gives rise to two modes in Oλ(A), which are somewhat analogous to coordinates on the dual geometry. At tree level, the product of such elements lands on modes of mesons of the schematic form IZZJ. As in the canonical example, this leads to bilinear relations associated to the Q<sup>0</sup> image of IbJ mesons. These bilinear relations are deformed at order λ by IJ zero modes.

This is a non-commutative version of the geometric transition from the resolved conifold to SL(2, C).

### <span id="page-91-0"></span>13 The non-commutative algebra at planar level

We now go back to the example in Section [10](#page-79-2) of the U(N) gauge theory with OSp(2n|2n+ 2) flavour symmetry. Recall that in this example ω abωab = −2.

### <span id="page-91-1"></span>13.1 The global algebra of meson modes.

We introduce the notation

$$Z^{[a_1}Z^{a_2}\cdots Z^{a_m]} (13.1)$$

to denote a "non-commutative traceless part" of the product of Z's. This is a linear combination of products which vanishes when we contract ω with any consecutive pairs of indices. These elements provide us a basis of the non-commutative algebra A! = C⟨ζa⟩/(ω abζaζ<sup>b</sup> = 0) that we find in Section [10.](#page-79-2)

We can define it recursively:

$$Z^{[a}Z^{a_{1}}\cdots Z^{a_{m}]} \equiv Z^{a}Z^{[a_{1}}Z^{a_{2}}\cdots Z^{a_{m}]} + f_{1,m}\omega^{aa_{1}}\omega_{bc}Z^{b}Z^{[c}Z^{a_{2}}\cdots Z^{a_{m}]}$$

$$+ f_{2,m}\omega^{a_{1}a_{2}}\omega_{bc}Z^{b}Z^{[c}Z^{a}Z^{a_{3}}\cdots Z^{a_{m}]}$$

$$+ f_{3,m}\omega^{a_{2}a_{3}}\omega_{bc}Z^{b}Z^{[c}Z^{a}Z^{a_{1}}Z^{a_{4}}\cdots Z^{a_{m}]}$$

$$+\cdots$$

$$(13.2)$$

We need

<span id="page-91-2"></span>
$$1 - 2f_{1,m} + f_{2,m} = 0$$
  

$$f_{1,m} - 2f_{2,m} + f_{3,m} = 0$$
  
... (13.3)

i.e. 
$$f_{i,m} = 1 - \frac{i}{m+1}$$
. Explicitly,

$$Z^{[a_1}Z^{a_2]} = Z^{a_1}Z^{a_2} + \frac{1}{2}\omega^{a_1a_2}\omega_{b_1b_2}Z^{b_1}Z^{b_2}$$
(13.4)

$$Z^{[a_1}Z^{a_2}Z^{a_3]} = Z^{a_1}Z^{a_2}Z^{a_3} + \frac{2}{3}\omega^{a_2a_3}\omega_{b_1b_2}Z^{a_1}Z^{b_1}Z^{b_2} + \frac{2}{3}\omega^{a_1a_2}\omega_{b_1b_2}Z^{b_1}Z^{b_2}Z^{a_3} + \frac{1}{3}\omega^{a_1a_2}\omega_{b_1b_2}Z^{a_3}Z^{b_1}Z^{b_2} + \frac{1}{3}\omega^{a_2a_3}\omega_{b_1b_2}Z^{b_1}Z^{b_2}Z^{a_1}.$$

$$(13.5)$$

Etcetera.

Mesons built from this combinations:

<span id="page-92-2"></span><span id="page-92-1"></span><span id="page-92-0"></span>
$$\frac{1}{\hbar} I Z^{[a_1} \cdots Z^{a_k]} J \tag{13.6}$$

are Q-closed at the linearized planar level and not exact. They are explicit representatives for the abstract A! representatives in Q0-cohomology and we expect to exhaust Ops<sup>∂</sup> λ .

As explained in Section [8.3,](#page-77-0) the commutators between the modes of these mesons define the algebra of functions on the back-reacted non-commutative geometry. We denote them by

$$u_{n_1...n_k}^{a_1...a_k} = \oint dz \, z^{n_1 + ... + n_k} \frac{1}{\hbar} I Z^{[a_1} \cdots Z^{a_k]} J, \qquad (13.7)$$

where the bottom n<sup>i</sup> indices take value 0 or 1 and are symmetric, representing a spin k/2 representation of SL(2, C) global conformal symmetry, and the top indices are non-commutative traceless. The two conditions can be expressed as the vanishing of contractions of consecutive indices with either ω<sup>a</sup>iai+1 or ϵ nini+1 .

The algebra they form can be obtained following lengthy yet conceptually simple 2d CFT calculations. At tree level, one simply concatenates two strings of Z's and drops ω contractions as being Q<sup>0</sup> exact, so that

$$u_{n_1 \cdots n_r}^{a_1 \cdots a_r} \cdot u_{n_{r+1} \cdots n_{r+s}}^{a_{r+1} \cdots a_{r+s}} = u_{n_1 \cdots n_{r+s}}^{a_1 \cdots a_{r+s}} + O(\lambda).$$
(13.8)

Therefore, we can identify the tree level algebra as the subalgebra of A! [z] generated by u a <sup>0</sup> = ζ a , u<sup>a</sup> <sup>1</sup> = ζ a z. This is a non-commutative generalization to the algebra of functions on the singular conifold.

Now we discuss non-planar corrections, which deform the tree level algebra and play a role analogous to the conifold transition. Each power of λ reduces the number of Z's by two and thus multiplies u's with two fewer indices.

A straightforward calculation gives

$$u_{n_1}^{a_1} \cdot u_{n_2}^{a_2} = u_{n_1 n_2}^{a_1 a_2} - \frac{\lambda}{2} \epsilon_{n_1 n_2} \omega^{a_1 a_2} , \qquad (13.9)$$

and thus

$$\omega_{a_1 a_2} u_{n_1}^{a_1} \cdot u_{n_2}^{a_2} = \lambda \epsilon_{n_1 n_2}$$

$$\epsilon^{n_1 n_2} u_{n_1}^{a_1} \cdot u_{n_2}^{a_2} = \lambda \omega^{a_1 a_2}, \qquad (13.10)$$

which nicely generalize the equation defining SL(2, C) in the canonical example.

These equations and constraints essentially fix the whole algebra. For example, consider the triple product ansatz

$$u_{n_1}^{a_1} \cdot u_{n_2}^{a_2} \cdot u_{n_3}^{a_3} = u_{n_1 n_2 n_3}^{a_1 a_2 a_3} + \lambda \left[ A_{n_1}^{a_1 a_2 a_3} \epsilon_{n_2 n_3} + B_{n_3}^{a_1 a_2 a_3} \epsilon_{n_1 n_2} \right] . \tag{13.11}$$

We only need two terms on the right hand side because the tensor product of three fundamental representations of SL(2, C) contains two copies of the fundamental representation.

The ansatz must satisfy

$$\epsilon^{n_1 n_2} u_{n_1}^{a_1} \cdot u_{n_2}^{a_2} \cdot u_{n_3}^{a_3} = \lambda \left[ A_{n_3}^{a_1 a_2 a_3} - 2 B_{n_3}^{a_1 a_2 a_3} \right] = \lambda \omega^{a_1 a_2} u_{n_3}^{a_3} 
\epsilon^{n_2 n_3} u_{n_1}^{a_1} \cdot u_{n_2}^{a_2} \cdot u_{n_3}^{a_3} = \lambda \left[ -2 A_{n_1}^{a_1 a_2 a_3} + B_{n_1}^{a_1 a_2 a_3} \right] = \lambda \omega^{a_2 a_3} u_{n_1}^{a_1} ,$$
(13.12)

which implies

$$u_{n_1}^{a_1} \cdot u_{n_2}^{a_2} \cdot u_{n_3}^{a_3} = u_{n_1 n_2 n_3}^{a_1 a_2 a_3} - \frac{\lambda}{3} \left[ \epsilon_{n_1 n_2} (2\omega^{a_1 a_2} u_{n_3}^{a_3} + \omega^{a_2 a_3} u_{n_3}^{a_1}) + \epsilon_{n_2 n_3} (\omega^{a_1 a_2} u_{n_1}^{a_3} + 2\omega^{a_2 a_3} u_{n_1}^{a_1}) \right].$$
(13.13)

In turn, we derive

$$u_{n_{1}}^{a_{1}} \cdot u_{n_{2}n_{3}}^{a_{2}a_{3}} = u_{n_{1}n_{2}n_{3}}^{a_{1}a_{2}a_{3}} - \frac{\lambda}{6} \left[ 2\epsilon_{n_{1}n_{2}} (2\omega^{a_{1}a_{2}}u_{n_{3}}^{a_{3}} + \omega^{a_{2}a_{3}}u_{n_{3}}^{a_{1}}) + \epsilon_{n_{2}n_{3}} (2\omega^{a_{1}a_{2}}u_{n_{1}}^{a_{3}} + \omega^{a_{2}a_{3}}u_{n_{1}}^{a_{1}}) \right]$$

$$u_{n_{1}n_{2}}^{a_{1}a_{2}} \cdot u_{n_{3}}^{a_{3}} = u_{n_{1}n_{2}n_{3}}^{a_{1}a_{2}a_{3}} - \frac{\lambda}{6} \left[ \epsilon_{n_{1}n_{2}} (\omega^{a_{1}a_{2}}u_{n_{3}}^{a_{3}} + 2\omega^{a_{2}a_{3}}u_{n_{3}}^{a_{1}}) + 2\epsilon_{n_{2}n_{3}} (\omega^{a_{1}a_{2}}u_{n_{1}}^{a_{3}} + 2\omega^{a_{2}a_{3}}u_{n_{1}}^{a_{1}}) \right].$$

$$(13.14)$$

We can generalize these expressions, but it is useful to pick a different basis of fundamental representations in the tensor product, via the identity

<span id="page-93-0"></span>
$$\epsilon_{n_1 n_2} C_{n_3} + \epsilon_{n_2 n_3} C_{n_1} + \epsilon_{n_3 n_1} C_{n_2} = 0, \qquad (13.15)$$

so that

$$u_{n_{1}}^{a_{1}} \cdot u_{n_{2}n_{3}}^{a_{2}a_{3}} = u_{n_{1}n_{2}n_{3}}^{a_{1}a_{2}a_{3}} - \frac{\lambda}{6} \left[ \epsilon_{n_{1}n_{2}} (2\omega^{a_{1}a_{2}}u_{n_{3}}^{a_{3}} + \omega^{a_{2}a_{3}}u_{n_{3}}^{a_{1}}) + \epsilon_{n_{1}n_{3}} (2\omega^{a_{1}a_{2}}u_{n_{2}}^{a_{3}} + \omega^{a_{2}a_{3}}u_{n_{2}}^{a_{1}}) \right]$$

$$u_{n_{1}n_{2}}^{a_{1}a_{2}} \cdot u_{n_{3}}^{a_{3}} = u_{n_{1}n_{2}n_{3}}^{a_{1}a_{2}a_{3}} - \frac{\lambda}{6} \left[ \epsilon_{n_{1}n_{3}} (\omega^{a_{1}a_{2}}u_{n_{2}}^{a_{3}} + 2\omega^{a_{2}a_{3}}u_{n_{2}}^{a_{1}}) + \epsilon_{n_{2}n_{3}} (\omega^{a_{1}a_{2}}u_{n_{1}}^{a_{3}} + 2\omega^{a_{2}a_{3}}u_{n_{1}}^{a_{1}}) \right].$$

$$(13.16)$$

Next, we can write an ansatz for a general product at order  $O(\lambda^2)$ :

$$u_{n_1}^{a_1} \cdot \dots \cdot u_{n_k}^{a_k} = u_{n_1 \dots n_k}^{a_1 \dots a_k} + \lambda \sum_{i=1}^{k-1} \epsilon_{n_i n_{i+1}} C(i)_{n_1 \dots \hat{n}_i \hat{n}_{i+1} \dots n_k}^{a_1 \dots a_k} + O(\lambda^2)$$
(13.17)

and contract with  $\epsilon^{n_j n_{j+1}}$  to get (after some relabeling of indices):

$$\omega^{a_j a_{j+1}} u_{n_1 \cdots n_{k-2}}^{a_1 \cdots \hat{a_j} \hat{a_{j+1}} \cdots a_k} = C(j-1)_{n_1 \cdots n_{k-2}}^{a_1 \cdots a_k} - 2C(j)_{n_1 \cdots n_{k-2}}^{a_1 \cdots a_k} + C(j+1)_{n_1 \cdots n_{k-2}}^{a_1 \cdots a_k}, \quad (13.18)$$

which is solved by inverting the SU(k) Cartan matrix:

$$C(i)_{n_1\cdots n_{k-2}}^{a_1\cdots a_k} = \sum_{j} \left[ -\min(i,j) + \frac{ij}{k} \right] \omega^{a_j a_{j+1}} u_{n_1}^{a_1} \cdot \dots \cdot u_{n_{k-2}}^{a_k},$$
 (13.19)

so

$$u_{n_1}^{a_1} \cdots u_{n_k}^{a_k} = u_{n_1 \cdots n_k}^{a_1 \cdots a_k} + \lambda \sum_{i=1}^{k-1} \epsilon_{n_i n_{i+1}} \sum_{j=1}^{k-1} \left[ -\min(i,j) + \frac{ij}{k} \right] \omega^{a_j a_{j+1}} u_{n_1 \cdots \hat{n}_i \hat{n}_{i+1} \cdots n_k}^{a_1 \cdots \hat{a}_j \hat{a}_{j+1} \cdots a_k} + O(\lambda^2) .$$

$$(13.20)$$

With a bit of work, this expression is enough to derive a general formula for right multiplication

<span id="page-94-0"></span>
$$u_{n_1\cdots n_k}^{a_1\cdots a_k}u_{n_{k+1}}^{a_{k+1}} = u_{n_1\cdots n_{k+1}}^{a_1\cdots a_{k+1}} - \frac{\lambda}{k(k+1)} \sum_{i=1}^k \epsilon_{n_i n_{k+1}} \sum_{j=1}^k j\omega^{a_j a_{j+1}} u_{n_1\cdots \hat{n}_i \cdots n_k}^{a_1\cdots \hat{a}_j \hat{a}_{j+1}\cdots a_{k+1}}.$$
 (13.21)

We check in Appendix F that the above formula can also be verified by computing OPE of the mesonic operators.

The left multiplication is given by:

$$u_{n_0}^{a_0} \cdot u_{n_1 \cdots n_k}^{a_1 \cdots a_k} = u_{n_0 \cdots n_k}^{a_0 \cdots a_k} - \frac{\lambda}{k(k+1)} \sum_{i=1}^k \epsilon_{n_0 n_i} \sum_{j=1}^k (k-j+1) \omega^{a_{j-1} a_j} u_{n_1 \cdots \hat{n_i} \cdots n_k}^{a_0 \cdots \hat{a}_{j-1} \hat{a}_j \cdots a_k} . \quad (13.22)$$

We will also need

$$\epsilon^{n_k n_{k+1}} u_{n_1 \cdots n_k}^{a_1 \cdots a_k} u_{n_{k+1}}^{a_{k+1}} = \frac{\lambda}{k+1} \sum_{j=1}^k j \omega^{a_j a_{j+1}} u_{n_1 \cdots n_{k-1}}^{a_1 \cdots \hat{a}_j \hat{a}_{j+1} \cdots a_{k+1}} \\
\epsilon^{n_0 n_1} u_{n_0}^{a_0} \cdot u_{n_1 \cdots n_k}^{a_1 \cdots a_k} = \frac{\lambda}{k+1} \sum_{j=1}^k (k-j+1) \omega^{a_{j-1} a_j} u_{n_2 \cdots n_k}^{a_0 \cdots \hat{a}_{j-1} \hat{a}_j \cdots a_k}, \qquad (13.23)$$

as well as

$$\omega_{a_k a_{k+1}} u_{n_1 \cdots n_k}^{a_1 \cdots a_k} u_{n_{k+1}}^{a_{k+1}} = \frac{\lambda}{k} \sum_{i=1}^k \epsilon_{n_i n_{k+1}} u_{n_1 \cdots \hat{n}_i \cdots n_k}^{a_1 \cdots a_{k-1}}$$

$$\omega_{a_0 a_1} u_{n_0}^{a_0} \cdot u_{n_1 \cdots n_k}^{a_1 \cdots a_k} = \frac{\lambda}{k} \sum_{i=1}^k \epsilon_{n_0 n_i} u_{n_1 \cdots \hat{n}_i \cdots n_k}^{a_2 \cdots a_k}.$$
(13.24)

### <span id="page-95-0"></span>13.2 Single traces

According to our discussion in Section [10,](#page-79-2) the single-trace operators in this example also contain the four towers A, B, C, D, but with the B and D towers collapsed. For the A tower, one may attempt to build BRST-closed single-trace operators in a similar manner as for mesons, starting from a cyclic string of Z's and removing traces. The analogue of Equations [\(13.3\)](#page-91-2), though, is governed by the affine A-type Cartan matrix and cannot be solved. A single-trace operator which is closed at the linear planar level can be written as <sup>1</sup>

$$\frac{1}{m\hbar} A_{a_1 \cdots a_m} \operatorname{Tr} Z^{a_1} \cdots Z^{a_m} , \qquad (13.25)$$

where A<sup>a</sup>1···a<sup>m</sup> can be taken to be graded-cyclic symmetric and has to satisfy

$$\omega^{a_1 a_2} A_{a_1 \cdots a_m} = 0. (13.26)$$

We can compute the action of a mode L<sup>i</sup> [A] of such an operator on an IZJ meson. Only one Wick contraction is available, so only the zero mode acts non-trivially, giving

$$[L_0[A], IZ^b J] = A_{a_1 \cdots a_{m-1} a_m} \omega^{a_m b} IZ^{a_1} \cdots Z^{a_{m-1}} J, \qquad (13.27)$$

leading to

$$[L_{n_1\cdots n_{m-2}}[A], u_j^b] = A_{a_1\cdots a_{m-1}a_m} \omega^{a_m b} u_{n_1\cdots n_{m-2}j}^{a_1\cdots a_{m-1}}.$$
 (13.28)

We expect this to be an infinitesimal automorphism of Pλ, but an explicit check takes a bit of work. We need to verify that

$$[L_{n_1\cdots n_{m-2}}[A], \epsilon^{j_1j_2}u_{j_1}^{b_1} \cdot u_{j_2}^{b_2}] = 0$$

$$[L_{n_1\cdots n_{m-2}}[A], \omega_{b_1b_2}u_{j_1}^{b_1} \cdot u_{j_2}^{b_2}] = 0.$$
(13.29)

Most of the terms in the first line drop off due to contractions of A with ω. The two remaining terms cancel thanks to cyclic invariance of A.

For the second identity,

$$[L_{n_1\cdots n_{m-2}}[A], \omega_{b_1b_2}u_{j_1}^{b_1} \cdot u_{j_2}^{b_2}] =$$

$$= A_{a_1\cdots a_{m-1}a_m}u_{n_1\cdots n_{m-2}j_1}^{a_1\cdots a_{m-1}} \cdot u_{j_2}^{a_m} - A_{a_1\cdots a_{m-1}a_m}u_{j_1}^{a_m} \cdot u_{n_1\cdots n_{m-2}j_2}^{a_1\cdots a_{m-1}}, \qquad (13.30)$$

the part linear in lambda drops off due to contractions of A with ω, the rest due to cyclic invariance.

Commutators of such transformations will generate a large automorphism algebra, which may include modes from the second D tower of single-trace operators [37](#page-96-0). For example, consider the cubic generator

$$[L_{n_1}[A], u_j^b] = A_{a_1 a_2 a_3} \omega^{a_3 b} u_{n_1 j}^{a_1 a_2}$$

$$[L_{n_1}[A], u_{j_1 j_2}^{b_1 b_2}] = A_{a_1 a_2 a_3} \omega^{a_3 b_1} u_{n_1 j_1 j_2}^{a_1 a_2 b_2} + A_{a_1 a_2 a_3} \omega^{a_3 b_2} u_{j_1 j_2 n_1}^{b_1 a_1 a_2} +$$

$$- \frac{\lambda}{3} A_{a_1 a_2 a_3} \omega^{a_3 b_1} \omega^{a_2 b_2} \epsilon_{n_1 j_1} u_{j_2}^{a_1} - \frac{\lambda}{3} A_{a_1 a_2 a_3} \omega^{a_1 b_1} \omega^{a_3 b_2} \epsilon_{n_1 j_2} u_{j_1}^{a_2} . (13.31)$$

Then

$$[[L_{(n_1}[A], L_{n_2)}[A']], u_j^b] = [A, A'] \omega^{a_4 b} u_{n_1 n_2 j}^{a_1 a_2 a_3} - \frac{\lambda}{6} \omega^{b_3 b} (\epsilon_{n_1 j} u_{n_2}^{a_1} + \epsilon_{n_2 j} u_{n_1}^{a_1}) \cdot$$

$$\cdot [A_{a_1 a_2 a_3} \omega^{a_3 b_1} \omega^{a_2 b_2} A'_{b_1 b_2 b_3} - A'_{a_1 a_2 a_3} \omega^{a_3 b_1} \omega^{a_2 b_2} A_{b_1 b_2 b_3}], \qquad (13.32)$$

with

$$[A, A'] \equiv A_{a_1 a_2 b_1} \omega^{b_1 b_2} A'_{b_2 a_3 a_4} + A_{a_2 a_3 b_1} \omega^{b_1 b_2} A'_{b_2 a_4 a_1} + \omega^{b_1 b_2} A_{a_3 a_4 b_1} A'_{b_2 a_1 a_2} + \omega^{b_1 b_2} A_{a_4 a_1 b_1} A'_{b_2 a_2 a_3}$$

$$(13.33)$$

is cyclic invariant but not traceless and

$$\begin{aligned} &[\epsilon^{n_1 n_2}[L_{n_1}[A], L_{n_2}[A']], u_j^b] = \\ &= \lambda \left[ A_{a_1 a_2 a_3} \omega^{a_3 b_1} \omega^{a_2 b_2} A'_{b_1 b_2 b_3} + A'_{a_1 a_2 a_3} \omega^{a_3 b_1} \omega^{a_2 b_2} A_{b_1 b_2 b_3} \right] \omega^{b_3 b} u_j^{a_1} \end{aligned}$$
(13.34)

is an OSp infinitesimal rotation.

In order to process this expression further, notice that the BRST image of a Tr bZ[a<sup>1</sup> · · ·Z <sup>a</sup>m] operator gives the sum of a single-trace operator and a meson, traced over flavour indices. The single-trace operator would be exact in the absence of flavours.

<span id="page-96-0"></span><sup>37</sup>As we have discussed in Section [10,](#page-79-2) most of the D tower operators vanish. This leads to intricate constraints on the OPE/commutator of A tower operators,which would be interesting to explore further.

In the presence of flavours, its modes act on the meson BRST cohomology in the same way as the traced meson, i.e. by conjugation by the corresponding element of Pλ.

Accordingly, the single-trace cohomology in ghost number 0 acts on P<sup>λ</sup> as derivations of P<sup>λ</sup> modulo inner derivations. This is the map to HH<sup>0</sup> (Pλ, Pλ). For example, the inner derivations

$$[u_{n_1 n_2}^{a_1 a_2}, u_j^b] = u_{n_1 n_2 j}^{a_1 a_2 b} - u_{n_1 n_2 j}^{b a_1 a_2} - \frac{\lambda}{3} (\omega^{a_1 a_2} \delta_c^b + \omega^{a_2 b} \delta_c^{a_1} + \omega^{b a_1} \delta_c^{a_2}) (\epsilon_{n_1 j} u_{n_2}^c + \epsilon_{n_2 j} u_{n_1}^c)$$

$$(13.35)$$

can be added to the commutator of two cubic generators to simplify the answer and identify a global SL(2, C) generator from the stress tensor contribution.

We could continue the analysis further to map modes of the C tower Tr ∂cZ[a<sup>1</sup> · · ·Z am] to deformations of Pλ, etcetera.

#### <span id="page-97-0"></span>13.3 Determinants and modules

Consider next a determinant operator of the form

$$\det(m + \mu_a Z^a) \tag{13.36}$$

for some vector µ<sup>a</sup> and basic open modifications of the form Iψ.

If we act on the modified determinant with u a <sup>1</sup> we need a Wick contraction with the determinant itself, leading to the sort of term

$$\omega^{ab}\mu_b I\psi(\bar{\psi}\psi) \sim m^{-1}\omega^{ab}\mu_b I\psi, \qquad (13.37)$$

so that

$$u_1^a I \psi = m^{-1} \omega^{ab} \mu_b I \psi \,.$$
 (13.38)

The action of u a <sup>0</sup> produces more complicated modifications IZ<sup>a</sup>ψ + · · · , unless we contract with µ:

$$(\mu_a u_0^a) I \psi = -m I \psi. \tag{13.39}$$

This is compatible with the algebra:

$$u_1^a(\mu_b u_0^b) I \psi - u_0^a(\mu_b u_1^b) I \psi = \omega^{ab} \mu_b I \psi.$$
 (13.40)

Next, consider

$$u_{n_1 1}^{a_1 a_2} I \psi = m^{-1} \omega^{a_2 b} \mu_b u_{n_1}^{a_1} I \psi + \frac{\lambda}{2} \epsilon_{n_1 1} \omega^{a_1 a_2} I \psi.$$
 (13.41)

More generally, the action of any generator except u a1···a<sup>k</sup> 0···0 can be recursively expressed in terms of the collection of modifications

$$u_{0\cdots 0}^{a_1\cdots a_k}I\psi\,, (13.42)$$

which is traceless for consecutive indices and satisfies

$$\mu_{a_k} u_{0\cdots 0}^{a_1\cdots a_k} I\psi = -m u_{0\cdots 0}^{a_1\cdots a_{k-1}} I\psi.$$
 (13.43)

We expect this to be a basis of Mλ[µ, m].

If we move the determinant to a location z, we have Mλ[µ, m, z]:

$$u_1^a I \psi = m^{-1} \omega^{ab} \mu_b I \psi + z u_0^a I \psi . \tag{13.44}$$

The analysis is easily generalized to multiple determinants. We replace m with a matrix ρ and introduce diagonal matrices z and µ representing positions and orientations of the determinants. We promote ψ to a vector acted from the right by these matrices. We get

$$u_1^a I \psi = \omega^{ab} I \psi \mu_b \rho^{-1} + u_0^a I \psi z,$$
  

$$u_0^a I \psi \mu_a = -I \psi \rho.$$
 (13.45)

If we impose

$$u_1^a u_0^b I \psi \mu_b - u_0^a u_1^b I \psi \mu_b = \omega^{ab} I \psi \mu_b , \qquad (13.46)$$

we get

$$-(\omega^{ab}I\psi\mu_b\rho^{-1} + u_0^aI\psi z)\rho - u_0^a(\omega^{bc}I\psi\mu_c\rho^{-1} + u_0^bI\psi z)\mu_b = \omega^{ab}I\psi\mu_b, \qquad (13.47)$$

i.e. we recover the saddle equations

$$\omega^{bc}\mu_c\rho^{-1}\mu_b = [\rho, z] \tag{13.48}$$

as a condition for Mλ[µ, ρ, z] to exist. This module is the non-commutative analogue of the spectral curve.

## <span id="page-98-0"></span>14 Conclusion and open questions

We employed the global symmetry algebra P<sup>λ</sup> of mesonic operators as a way to generalize the notion of the algebra of holomorphic functions on SL(2, C) and ascribe an holographic dual nc-geometry to a generic chiral algebra which admits a 't Hooft expansion.

The category of  $\mathfrak{P}_{\lambda}$ -modules seems a good description of a category of D-branes in the dual nc-geometry. In particular, it contains modules  $\mathfrak{M}_{\lambda}$  associated to saddle points of correlation functions of determinant operators, i.e. D-branes which "reach the holographic boundary" at a collection of points.

We leave the following points unresolved:

- 1. We expect  $\mathfrak{P}_{\lambda}$  to be a smooth 3d Calabi-Yau algebra. A proof would require one to present an explicit class in  $HH_3(\mathfrak{P}_{\lambda})$  (and should be an element in the negative cyclic homology  $HC_3^-(\mathfrak{P}_{\lambda})$ ). This is a cyclic element with four entries valued in  $\mathfrak{P}_{\lambda}$ . It is not hard to write such a class for  $SL(2,\mathbb{C})$  from the volume form and guess a generalization. We do not know, though, how to derive it from the chiral algebra.
- 2. We expect the category of  $A_{\infty}$  modules of  $\mathfrak{P}_{\lambda}$  to capture the category of branes in the dual nc-geometry. Essentially by construction, we have an  $A_{\infty}$  morphism from the space of "determinant modifications" of a determinant operator in the chiral algebra to the space of  $A_{\infty}$  endomorphisms of the corresponding module  $\mathfrak{M}_{\lambda}$ . Ideally, we would like to show that this is a quasi-isomorphism and generalize the statement to any pairs of determinants.
- 3. We expect the divergence-free part of  $HH^{\bullet}(\mathfrak{P}_{\lambda},\mathfrak{P}_{\lambda})$  to match the global symmetry algebra  $\mathfrak{L}_{\lambda}$  of single-trace operators. We only have  $L_{\infty}$  morphisms from the latter to the former.

It seems a harder problem to derive from the data of  $\mathfrak{P}_{\lambda}$  the planar cohomology of single-trace operators or even the planar cohomology of mesons, i.e. the spaces of distributional vertex operators which build up the holographic dictionary. Indeed, quantities such as  $HC^{\bullet}(\mathfrak{P}_{\lambda})$  capture fully distributional closed string states rather than the ones we need.

Determinant operators and giant graviton branes may allow one to side-step this challenge in two related ways:

- The cyclic cohomology of the endomorphisms of a giant graviton brane, or of a category of giant graviton branes, has the correct properties to recover the closed string states which appear as boundary-to-bulk holographic propagators.
- If we take  $m \to \infty$  and expand a (possibly modified) determinant operator in inverse powers of m, the outcome is a sequence of BRST-closed multi-trace operators. In particular, the sub-leading term is single-trace. This is another way to relate closed string states to the cyclic homology of determinant modifications.

We leave these problems to future work.

Our general strategy can be readily applied to other examples of twisted holography [\[78,](#page-122-0) [79\]](#page-122-1). Low-hanging targets are gauged quantum-mechanical systems of large matrices [\[80\]](#page-122-2) and matrix models.

### Acknowledgements

We would like to thank Kasia Budzik, Kevin Costello, Victor Ginzburg, Yan Soibelman and Ben Webster for useful discussions. This research was supported in part by a grant from the Krembil Foundation. DG, ALR and HS are supported by the NSERC Discovery Grant program and by the Perimeter Institute for Theoretical Physics. KZ is supported by Harvard University CMSA. Research at Perimeter Institute is supported in part by the Government of Canada through the Department of Innovation, Science and Economic Development Canada and by the Province of Ontario through the Ministry of Colleges and Universities.

# <span id="page-100-0"></span>A The Planar Mode Action: An Expression for the Contour Integral

In Section [12](#page-89-0) we defined the expression for the planar-linear action of modes On;<sup>C</sup> on a tensor product of fields [\(12.2\)](#page-90-2), [\(12.3\)](#page-90-3). In this appendix we provide a different expression for the planar mode action after one performs the contour integral. Recall that the planar action of a mode[38](#page-100-1)

<span id="page-100-2"></span>
$$O_{n;C} = \oint dz \left( C | \Phi(z + l_{|C|}, ) \cdots, \Phi(z + l_1) \right)$$
(A.1)

is given by a polynomial in the 't Hooft coupling λ.

$$[O_{n;C}, \Phi(s_1) \otimes \cdots \Phi(s_k)] = O_{n;C}^{(0)}(\Phi(s_1) \otimes \cdots \Phi(s_k)) + \lambda O_{n;C}^{(1)}(\Phi(s_1) \otimes \cdots \Phi(s_k)) + \cdots + \lambda^m O_{n;C}^{(m)}(\Phi(s_1) \otimes \cdots \Phi(s_k)),$$
(A.2)

where the O (m) n;C contains m + 1 wick contractions and is given by

$$O_{n;C}^{(m)}, (\Phi(s_1) \otimes \cdots \otimes \Phi(s_{m+1})) =$$

$$\oint \frac{dz}{2\pi i} z^n \left( C|\Phi(z+l_{|C|}), \cdots, \frac{\eta_{m+1}^{(1)}}{z+l_{m+1}-s_{m+1}}, \cdots, \frac{\eta_1^{(1)}}{z+l_1-s_1} \right) \eta_1^{(2)} \otimes \cdots \eta_{m+1}^{(2)}.$$
(A.3)

<span id="page-100-1"></span><sup>38</sup>In this section we'll use l<sup>i</sup> to refer to some derivative counters as it simplifies OPE expressions below.

To provide an expression for this contour integral we note that integrals of the form

$$\oint dz \frac{f(z)}{(z-z_1)(z-z_2)\cdots(z-z_k)}, \tag{A.4}$$

where all poles are enclosed by the contour, can be expressed in terms of a ratio of Vandermonde-like determinants

$$\int dz \frac{f(z)}{(z-z_1)(z-z_2)\cdots(z-z_k)} = \frac{D_k(f(z))}{D_k(z^{k-1})},$$
(A.5)

with  $D_k(f(z))$  the determinant

$$D_{k}(f(z)) \equiv \begin{vmatrix} f(z_{k}) & z_{k}^{k-2} & z_{k}^{k-3} & \cdots & z_{k} & 1 \\ f(z_{k-1}) & z_{k-1}^{k-2} & z_{k-1}^{k-3} & \cdots & z_{k-1} & 1 \\ \vdots & \ddots & & \vdots \\ f(z_{1}) & z_{1}^{k-2} & z_{1}^{k-3} & \cdots & z_{1} & 1 \end{vmatrix} .$$
(A.6)

We will call this ratio  $R_k(f(z)) \equiv \frac{D_k(f(z))}{D_k(z^{k-1})}$ . In Equation (A.3) the corresponding f(z) is

$$f(z) = z^n \Phi(z + l_{|C|}) \otimes \cdots \otimes \Phi(z + l_{m+2}), \tag{A.7}$$

and the poles are at  $z_i = s_i - l_i$  for i = 1, ..., m + 1. Therefore, after performing the contour integral we get

$$O_{n;C}^{(m)}, (\Phi(s_1) \otimes \cdots \otimes \Phi(s_{m+1})) = \left(C|R_{m+1}\left(z^n \Phi(z+l_{|C|}) \otimes \cdots \otimes \Phi(z+l_{m+2})\right), \eta_{m+1}^{(1)}, \cdots, \eta_1^{(1)}\right) \eta_1^{(2)} \otimes \cdots \eta_{m+1}^{(2)}. \quad (A.8)$$

To give a more concrete idea of the meaning of this expression, let's write it explicitly for the case with two wick contractions and a C that takes three arguments, |C| = 3. In this case, the action is given by

$$O_{n;C}^{(1)}, (\Phi(s_1) \otimes \Phi(s_2)) = \left(C|R_2(z^n \Phi(z+l_3)), \eta_2^{(1)}, \eta_1^{(1)}\right) \eta_1^{(2)} \otimes \eta_2^{(2)}, \tag{A.9}$$

where  $R_2(z^n\Phi(z+l_3))$  is explicitly given as

$$R_2(z^n \Phi(z+l_3)) = \frac{\begin{vmatrix} (s_2 - l_2)^n \Phi(s_2 - l_2 + l_3) & 1 \\ (s_1 - l_1)^n \Phi(s_1 - l_1 + l_3) & 1 \end{vmatrix}}{\begin{vmatrix} s_2 - l_2 & 1 \\ s_1 - l_1 & 1 \end{vmatrix}}$$
(A.10)

$$=\frac{(s_2-l_2)^n\Phi(s_2-l_2+l_3)-(s_1-l_1)^n\Phi(s_1-l_1+l_3)}{(s_2-l_2)-(s_1-l_1)}.$$
 (A.11)

The planar action of single trace modes on mesons, and of mesons on mesons can be similarly expressed in terms of Rm. We'd find correspondingly

$$O_{n;C}^{(m)}(I(s_0) \otimes \Phi(s_1) \otimes \cdots \otimes J(s_{m+2})) = I(s_0) \otimes \left(C|R_{m+1}\left(z^n \Phi(z+l_{|C|}) \otimes \cdots \otimes \Phi(z+l_{m+2})\right), \eta_{m+1}^{(1)}, \cdots, \eta_1^{(1)}\right) \eta_1^{(2)} \otimes \cdots \eta_{m+1}^{(2)} \otimes J(s_{m+2}),$$
(A.12)

and

$$O_{n;P}^{(m)}(I(s_1) \otimes \Phi(s_2) \otimes \cdots \otimes J(s_{m+2})) = \left(C|R_{m+1}\left(z^n I(z+l_{|C|}) \otimes \cdots \otimes \Phi(z+l_{m+2})\right), \eta_{m+1}^{(1)}, \cdots, \mu_1^{(1)}\right) \mu_1^{(2)} \otimes \cdots \eta_{m+1}^{(2)} \otimes J(s_{m+1}).$$
(A.13)

### <span id="page-102-0"></span>B Cyclic cohomology of a weighted algebra

In this section, we discuss properties of cyclic cohomology of a weighted algebra. In this paper, the weight of the algebra is provided by their scaling dimension. In particular, we would like to prove the statement that the Connes' periodicity map S vanishes on the positive weight part of cyclic cohomology. We follow the discussion in [\[70\]](#page-121-7), where the homology version of this statement is proved.

First recall that a derivation (of degree 0) of an algebra A into itself is a map D : A → A such that D(ab) = D(a)b + aD(b). One can extend the derivation on A to Hochschild cochain CC• (A) := CC• (A, A<sup>∗</sup> ) via the formula

$$(L_D f)(a_0, a_1, \dots, a_n) = \sum_{i \ge 0} f(a_0, \dots, Da_i, \dots, a_n).$$
 (B.1)

We can check that the map L<sup>D</sup> commutes with the Hochschild differential and t. Therefore, it induce a map on the Hochschild cohomology and cyclic cohomology.

$$L_D: HC^{\bullet}(A) \to HC^{\bullet}(A)$$
. (B.2)

We further introduce operators e<sup>D</sup> : CC<sup>n</sup> (A) → CC<sup>n</sup>+1(A) and E<sup>D</sup> : CC<sup>n</sup> (A) → CC<sup>n</sup>−<sup>1</sup> (A) as follows

$$(e_D f)(a_0, \dots, a_n) = (-1)^{n+1} f(D(a_n) a_0, a_1, \dots, a_{n-1})$$

$$(E_D f)(a_0, \dots, a_{n-2}) = \sum_{1 \le i \le j \le n-2} (-1)^{in+1} f(1, a_i, \dots, a_{j-1}, D(a_j), a_{j+1}, \dots, a_{n-2}, a_0, \dots, a_{i-1}).$$
(B.3)

Then one can check the following identity

Theorem 1.

$$[e_D, Q_{\text{CH}}] = 0,$$
  
 $[e_D, B] + [E_D, Q_{\text{CH}}] = L_D,$  (B.4)  
 $[E_D, B] = 0.$ 

From the above identities, we have the following results

Theorem 2. The map L<sup>D</sup> ◦ S = 0 : HC• (A) → HC•+2(A).

Proof. We use the bicomplex B(A) = (CC• (A)[u], QCH+uB) for the cyclic cohomology. The periodicity map S = u in this case. Now we construct a homotopy map h : B(A) → B(A)[1] defined as

$$h = e_D + uE_D. (B.5)$$

Then we find

$$[h, Q_{\text{CH}} + uB] = [e_D, Q_{\text{CH}}] + u([e_D, B] + [E_D, Q_{\text{CH}}]) + u^2[E_D, B] = uL_D.$$
 (B.6)

Therefore, h is the homotopy between LD◦S and 0. Thus LD◦S = 0 on cohomology.

Now for a weighted algebra A, we define a derivation D on A by D(a) = wt(a)a. Then L<sup>D</sup> acting on a Hochschild cochain f is simply LDf = wt(f)f. The above results tells us that S must be 0 on positive weight part of the cyclic cohomology. As a corollary, we have

Theorem 3. Let A be a unital weighted algebra. Define

$$HC^{n}(A)^{(\geq 1)} = \bigoplus_{w \geq 1} HC^{n}(A)^{(w)} \cong HC^{n}(A)/HC^{n}(A_{0}).$$
 (B.7)

Then for HC• (A) (≥1), the Connes' long exact sequence reduces into a collection of short exact sequences

$$0 \longrightarrow HC^{n}(A)^{(\geq 1)} \stackrel{I}{\longrightarrow} HH^{n}(A)^{(\geq 1)} \stackrel{B}{\longrightarrow} HC^{n-1}(A)^{(\geq 1)} \longrightarrow 0.$$
 (B.8)

## <span id="page-103-0"></span>C Global symmetry algebra

In this section, we discuss the mathematical construction related to the global symmetry algebra of a vertex algebra. To simplify the discussion, we consider the case when our vertex algebra arises from the chiral envelope of a vertex Lie algebra. In our example of the large N chiral algebra, the tree-level planar limit defines a vertex Lie algebra structure on L = HC• (A[[s]]). However, the discussion in this appendix applies to any (conformal) vertex Lie algebra.

Let us first recall some construction of Lie algebra attached to a vertex Lie algebra. Given a vertex Lie algebra (L, T, Y−), we first have its Lie algebra of modes [\[81\]](#page-122-3)

$$\oint L := L \otimes \mathbb{C}((t))/\text{Im}(T \otimes \text{Id} + \text{Id} \otimes \partial_t).$$
(C.1)

Physically, H L consist of the modes O<sup>n</sup> of the fields O(z) = P <sup>n</sup>∈<sup>Z</sup> Onz −n−1 in the vertex algebra. We are particularly interested in the non negative modes in this Lie algebra. We denote

$$(\oint L)_{+} := \{ O_n \in \oint L \mid n \ge 0 \}. \tag{C.2}$$

This forms a Lie sub-algebra of the mode algebra H L. In the example L = HC• (A[[s]]), ( H L)<sup>+</sup> is the extended symmetry algebra L <sup>C</sup> defined in Section [2.4,](#page-20-0) [7.](#page-69-0)

We are interested in the case when our vertex algebra has a stress-energy tensor. In such cases, there is a general procedure that allows us to pass from a conformal vertex Lie algebra to a vertex algebra bundle on a curve, which is a D-module

$$L \leadsto \mathcal{L}$$
. (C.3)

Such a D-module L is called a (chiral) Lie\* algebra. Recall that we have the de Rham functor h that send a D-module to O-module, given by h(L) = L ⊗<sup>D</sup><sup>X</sup> OX. Then, according to [\[54,](#page-120-10) [81\]](#page-122-3), we have the following geometric description of the Lie algebra H L and (H L)+.

Theorem 4. Let D be the standard disc and D<sup>×</sup> = D − {0} the punctured disc. We have

$$\oint L \cong \Gamma(D^{\times}, h(\mathcal{L})), \qquad (\oint L)_{+} = \Gamma(D, h(\mathcal{L})).$$
(C.4)

Given the stress-energy tensor, we have, in particular, an sl<sup>2</sup> = {L<sup>−</sup>1, L0, L1} action on the Lie algebra H L and (H L)+. Given a sl<sup>2</sup> module M with bounded integer weights, we define a submodule Core(M)

$$Core(M) = \{ m \in M \mid L_1^N(m) = 0 \text{ for some } N \}.$$
 (C.5)

In our case Core((H L)+) is a Lie subalgebra. This Lie algebra is defined to be the global symmetry algebra of the vertex algebra. We have the following geometric description of Core((H L)+)

Theorem 5.

$$Core((\oint L)_{+}) = \Gamma(\mathbb{CP}^{1}, h(\mathcal{L})). \tag{C.6}$$

This Lie algebra  $\Gamma(\mathbb{CP}^1, h(\mathcal{L}))$  is defined to be the global symmetry algebra of the vertex Lie algebra L. It coincide with the physical definition as the Lie algebra of modes that annihilate both the vacuum at 0 and  $\infty$ . In the example  $L = \mathrm{HC}^{\bullet}(A[[s]])$ ,  $\Gamma(\mathbb{CP}^1, h(\mathcal{L}))$  is the global symmetry algebra  $\mathcal{L}$  we studied in this paper.

### <span id="page-105-0"></span>D Calabi-Yau algebra

In this appendix, we briefly review the mathematical definition of a Calabi-Yau algebra. There are two distinct notions of Calabi-Yau structures, called smooth Calabi-Yau [31] and compact Calabi-Yau [32], which are related by Koszul duality [82, 83]. Both of these notions give rise to (partially defined) 2d topological quantum field theories in the sense of [22, 45]. Typically, a compact Calabi-Yau structure defines a TQFT that assigns values to cobordisms with at least one input, while a smooth Calabi-Yau structure gives rise to a TQFT defined on cobordisms with at least one output [46]. Geometrically, these two notions of Calabi-Yau algebras correspond to a space-filling brane and a brane supported at a point, respectively.

We introduce some notation. For B an associative algebra, we denote  $B^{op}$  the opposite algebra. It has the same elements as B but equipped with a opposite multiplication  $a \cdot {}^{op} b = b \cdot a$ . We denote  $B^e = B \otimes B^{op}$  so that a B bimodule is the same as a  $B^e$  left module.

We first introduce the notion of a smooth Calabi-Yau algebra [31], as it is more commonly used in the literature.

Let B be a homologically smooth algebra. We denote  $B^D$  its (derived) dual bimodule, defined as

$$B^D := R \operatorname{Hom}_{B^e}(B, B^e) \,. \tag{D.1}$$

Recall that we have the following isomorphism in the derived category

$$R\mathrm{Hom}_{B^e}(B^D,B)\cong B\otimes_{B^e}^{\mathbb{L}}B$$
.

We call B a (weak) smooth d-Calabi-Yau algebra if there exists a map  $\varphi \in \mathbb{C}[d] \to \mathrm{CH}_{\bullet}(B)$  that induces an isomorphism

$$\varphi: B^D \cong B[-d] \tag{D.2}$$

in the derived category of  $B^e$  module.

The Hochschild complex  $CH_{\bullet}(B)$  carries a circle action, whose homotopy fixed points  $CH_{\bullet}^{hS^1}$  are calculated by the negative cyclic complex  $CC_{\bullet}^{-}(B)$ . A smooth Calabi-Yau structure is a lift of the Hochschild homology element  $\varphi \in CH_d(B)$  to the negative

cyclic homology element ˜φ ∈ CC<sup>−</sup> d (B). In the geometric context, the class [ ˜φ] corresponds to a choice of a (closed) Calabi-Yau volume form.

Now we introduce the dual notion of compact Calabi-Yau structure. Let A be a proper dg algebra. Recall that we have the following isomorphism

$$\operatorname{Hom}_{\mathbb{C}}(A \otimes^{\mathbb{L}}_{A^e} A, \mathbb{C}) \cong R \operatorname{Hom}_{A^e}(A, A^*)$$
.

We define a (weak) compact d-Calabi-Yau structure on A as a map η : CH•(A) → C[−d], such that it induces an isomorphism

$$\eta: A[d] \to A^*$$
.

The homotopy orbit of the Hochschild complex CH•(A)hS<sup>1</sup> with respect to the circle action is the cyclic complex CC•(A). A compact Calabi-Yau algebra is a lift of η into a cyclic chain ˜η : CC•(A) → C[−d].

The concept of compact Calabi-Yau algebra is closely related to cyclic A<sup>∞</sup> algebra. A cyclic A<sup>∞</sup> algebra is a A<sup>∞</sup> algebra (A, {mn}) equipped with a non-degenerate symmetric pairing ⟨·, ·⟩ : A⊗A → C, such that the expressions ⟨a0, mn(a1, . . . , an)⟩ are graded cyclically symmetric. Due to Kontsevich and Soibelman [\[32\]](#page-119-16), these two concepts are essentially equivalent. Any cyclic A<sup>∞</sup> algebra has a canonically defined compact Calabi-Yau strucutre, and any compact Calabi-Yau algebra is quasi-isomorphic to a cyclic A<sup>∞</sup> algebra.

In this paper, we adopt the notion of a "cyclic A<sup>∞</sup> algebra" as our definition of a Calabi-Yau algebra. This is exactly the structure we need to define the large N chiral gauge theory in Section [5.](#page-54-0) Additionally, we simplify by considering the A<sup>∞</sup> algebra to be a dg associative algebra.

Though we mainly used the compact CY algebra in our construction, the smooth CY algebra also appears in the chiral algebra, after we add the (anti-)fundamental matter fields. The mesonic operators naturally give rise to smooth Calabi-Yau algebra as they correspond to space filling branes in our system. To make the connection more clear, we recall that compact and smooth CY structure are related by Koszul duality [\[83\]](#page-122-5)

$$\operatorname{RHom}_{A^e}(\mathbb{K}, \mathbb{K}) = B, \quad \operatorname{RHom}_{B^e}(\mathbb{K}, \mathbb{K}) = A.$$
 (D.3)

Here K is not always the base field C, but could also be copies of C, each corresponds to an idempotent.

As commented in Section [8,](#page-75-0) in the mesonic example, its natural to choose fundamental matter that correspond to K and anti-fundamental to its dual. Then quasiprimary mesonic operators are given by the Koszul dual B = RHomA<sup>e</sup> (K, K) of A, which is a smooth Calabi-Yau algebra.

It would be important to show that the global symmetry algebra P<sup>λ</sup> defined in the main text is smooth 3d-CY, possibly using structures which arise in the chiral algebra. We do not know how to do so.

A great source of Calai-Yau algebra comes from quiver constructions. If we consider our A to be the compact CY algebra that correspond to a quiver Q, then its Koszul dual smooth CY algebra is the 2d-Ginzburg dg algebra [\[31,](#page-119-5) [84\]](#page-122-6) that correspond to the same quiver. It will be interesting to further explore the relation between P<sup>λ</sup> and the Ginzburg dg algebra in the quiver case.

# <span id="page-107-0"></span>E A lightning review of Maurer-Cartan equations and BRST anomalies

We refer the reader to [\[42\]](#page-119-15) for a detailed discussion.

In many QFT calculations, it is useful to define perturbatively a formal deformation of a reference theory, by regularizing in some scheme the exponential of an integrated interaction. We can denote that very schematically as

$$\left[e^{\int \Phi}\right]$$
 . (E.1)

Either the choice of interactions or the regularization scheme may introduce BRST anomalies. We can write schematically

$$e^{\epsilon Q} \left[ e^{\int \Phi} \right] = \left[ e^{\int \Phi + \epsilon MC(\Phi)} \right]$$
 (E.2)

by rewriting the effect of a BRST transformation as a further deformation of the theory. The expression MC(Φ) is a multi-linear map from the space of interactions to itself, or better an odd nilpotent vectorfield on the space of formal couplings. The condition for BRST anomalies to vanish is the Maurer-Cartan equation

$$MC(\Phi) = 0. (E.3)$$

By definition, this data equips the space of interactions with the structure of an L<sup>∞</sup> algebra.

Other structures can be produced by coupling the original theory to auxiliary fields, adding interactions to defects in the QFT, etc. For example, a Wilson-like line defect involving an auxiliary finite-dimensional quantum-mechanical system involves a pathordered interaction and a matrix-valued Maurer-Cartan equation, which by definition leads to an A<sup>∞</sup> algebra.

### <span id="page-108-0"></span>F Non-commutative Algebra From OPEs

The product rule [\(13.21\)](#page-94-0) for the algebra of meson modes in the chiral algebra with OSp symmetry, was originally gleaned by studying in detail the commutators between the meson modes. In this appendix we showcase said calculations which now serve as additional evidence of the final product rule [\(13.21\)](#page-94-0).

### <span id="page-108-1"></span>F.1 A useful Q-exact relation

Given that our mesons have ghost number 0, Q-exact relations between them arise from taking Q of mesons with ghost number -1, that is, with at least one b field. Take for example the operator IbZJ, where by Z we mean a field valued in the ghost number one part of the algebra Z = Z α θα, and similarly, I = I <sup>i</sup>m˜ <sup>i</sup> and J = Jim<sup>i</sup> are right and left module valued respectively, with the meson IbZJ living in the corresponding tensor product. Its Q is given by

$$QIbZJ = -I(Z, Z)ZJ + \lambda \partial IZJ - \lambda I\partial ZJ + \text{multi-meson terms}, \qquad (F.1)$$

with (·, ·) the usual algebra pairing (Z, Z) = ωabZ aZ b . Neglecting the multi-meson terms, we can read this equation to mean that

$$\lambda \partial IZJ \sim I(Z,Z)ZJ + I\partial ZJ$$
. (F.2)

Note this allowed us to move the partial derivative one symbol to the right at the price of adding a new term with an extra (Z, Z) in between the two symbols. Studying the Q of further mesons with one b we would find that this pattern holds more generally, so that Q-exact relations allow to move derivatives one symbol to the right, at the price of a new term with an extra (Z, Z). We may write this as

$$\lambda \overset{\leftarrow}{\partial} \sim \lambda \overset{\rightarrow}{\partial} + (Z, Z) \,.$$
 (F.3)

#### <span id="page-108-2"></span>F.2 u a1 n<sup>1</sup> · u a2 n<sup>2</sup> from OPEs

The first mesons in the cohomology are

<span id="page-108-3"></span>
$$I^i Z J_j$$
. (F.4)

We denote their modes by

$$(u_n^a)_j^i = \oint z^n I^i Z^a J_j \,. \tag{F.5}$$

As explained in Section 8.3, to determine their product we must study their commutator:

$$[(u_{n_1}^{a_1})_j^i, (u_{n_2}^{a_2})_l^k] = \delta_j^k (u_{n_1}^{a_1} \cdot u_{n_2}^{a_2})_l^i \pm \delta_l^i (u_{n_1}^{a_1} \cdot u_{n_2}^{a_2})_j^k.$$
 (F.6)

We set i > j = k > l to narrow in on the product

$$[(u_{n_1}^{a_1})_j^i, (u_{n_2}^{a_2})_l^j] = (u_{n_1}^{a_1} \cdot u_{n_2}^{a_2})_l^i.$$
 (F.7)

To determine this commutator, let's first go over the OPE between the corresponding mesons

$$I^{i}Z^{a_{1}}J_{j}(z)I^{j}Z^{a_{2}}J_{k}(w) \sim \frac{1}{z-w}(I^{i}Z^{a_{1}}Z^{a_{2}}J_{k}(w) + \lambda\omega^{a_{1}a_{2}}\partial I^{i}J_{k}(w)) + \frac{1}{(z-w)^{2}}\lambda\omega^{a_{1}a_{2}}I^{i}J_{k}(w)).$$
 (F.8)

The operators on the right hand side are guaranteed to be Q-closed. However, they are not expressed in terms of the more natural representatives (13.6)

<span id="page-109-1"></span><span id="page-109-0"></span>
$$IZ^{[a_1}\cdots Z^{a_k]}J. (F.9)$$

In particular, these representatives contain no derivatives, so one might suspect that if one could "get rid" of the meson with a derivative in (F.8) using Q-exact relations, one would find an expression in terms of our canonical representatives (F.9). Indeed, if for  $\lambda \partial I^i J_k$  we move "half of its derivative" to the right

$$\lambda \partial I^{i} J_{k} \sim \lambda \frac{1}{2} \partial I^{i} J_{k} + \lambda \frac{1}{2} I^{i} \partial J_{k} + \frac{1}{2} I^{i} (Z, Z) J_{k}$$

$$= \lambda \frac{1}{2} \partial (I^{i} J_{k}) + \frac{1}{2} I^{i} (Z, Z) J_{k}. \tag{F.10}$$

(Note  $\sim$  here means Q-equivalence class and not OPE; we'll freely alternate between the two meanings) one is left with a term with no derivatives plus a total derivative term. However, a mode of a total derivative can be expressed in terms of modes of mesons with no derivatives through integration by parts, so at this point one effectively has "removed" the derivative terms and indeed plugging back into the OPE

$$I^{i}Z^{a_{1}}J_{j}(z)I^{j}Z^{a_{2}}J_{k}(w) \sim \frac{1}{z-w} (I^{i}Z^{a_{1}}Z^{a_{2}}J_{k}(w) + \frac{1}{2}\omega^{a_{1}a_{2}}I^{i}(Z,Z)J_{k}(w) + \frac{1}{2}\lambda\omega^{a_{1}a_{2}}\partial(I^{i}J_{k})(w))$$

$$\frac{1}{(z-w)^{2}}\lambda\omega^{a_{1}a_{2}}I^{i}J_{k}(w)). \tag{F.11}$$

We find the traceless linear combination from [\(13.4\)](#page-92-1)

$$I^{i}Z^{[a_{1}}Z^{a_{2}]}J_{k} = I^{i}Z^{a_{1}}Z^{a_{2}}J_{k} + \frac{1}{2}\omega^{a_{1}a_{2}}I^{i}(Z,Z)J_{k}$$
 (F.12)

in the OPE, which is our canonical representative for the Q-closed meson with two Z's. Moving on to study the modes, we take the integral H z <sup>n</sup><sup>1</sup> of the OPE

$$[(u_{n_1}^{a_1})_j^i, I^j Z^{a_2} J_k(w)] = w^{n_1} (I^i Z^{[a_1} Z^{a_2]} J_k(w) + \frac{1}{2} \lambda \omega^{a_1 a_2} \partial (I^i J_k)(w)) + n_1 w^{n_1 - 1} \lambda \omega^{a_1 a_2} I^i J_k(w).$$
 (F.13)

Taking now the integral H w <sup>n</sup><sup>2</sup> of what is left and expressing in terms of the modes

$$u_{n_1 n_2}^{a_1 a_2} = \oint z^{n_1 + n_2} I^i Z^{[a} Z^{b]} J_k \tag{F.14}$$

$$u_{n_1+n_2-1} = \oint z^{n_1+n_2-1} I^i J_k , \qquad (F.15)$$

we find the product

$$u_{n_1}^{a_1} \cdot u_{n_2}^{a_2} = u_{n_1 n_2}^{a_1 a_2} + \lambda \frac{n_1 - n_2}{2} \omega^{a_1 a_2} u_{n_1 + n_2 - 1}^{a_1 a_2}$$

$$= u_{n_1 n_2}^{a_1 a_2} - \lambda \frac{1}{2} \epsilon_{n_1 n_2} \omega^{a_1 a_2} u_{n_1 + n_2 - 1}^{a_1 a_2}, \qquad (F.16)$$

with ϵ<sup>n</sup>1n<sup>2</sup> = 0 1 −1 0 n1n<sup>2</sup> = n<sup>2</sup> − n<sup>1</sup> for n1, n<sup>2</sup> ∈ {0, 1}. One can further simplify the expression using the fact that

$$\epsilon_{n_1 n_2} u_{n_1 + n_2 - 1} = \epsilon_{n_1 n_2} u_0 \,,$$
 (F.17)

since n<sup>1</sup> + n<sup>2</sup> must add up to 1 to have a non zero answer. Moreover, easy OPE calculations show u<sup>0</sup> behaves as a unit for the algebra, so we may set it to one henceforth. This leads to the final expression for product

$$u_{n_1}^{a_1} \cdot u_{n_2}^{a_2} = u_{n_1 n_2}^{a_1 a_2} - \lambda \frac{1}{2} \epsilon_{n_1 n_2} \omega^{a_1 a_2} . \tag{F.18}$$

#### <span id="page-110-0"></span>F.3 u a1a<sup>2</sup> n1n<sup>2</sup> · u a3 n<sup>3</sup> from OPEs

We move on to study the product

$$u_{n_1 n_2}^{a_1 a_2} \cdot u_{n_3}^{a_3} \tag{F.19}$$

by means of 2d CFT calculations. To do so we will need to study the OPE between

$$I^{i}Z^{[a_{1}}Z^{a_{2}]}J_{j} = I^{i}Z^{a_{1}}Z^{a_{2}}J_{j} + \frac{\omega^{a_{1}a_{2}}}{2}I^{i}(Z,Z)J_{j}, \qquad (F.20)$$

and

<span id="page-111-0"></span>
$$I^{j}Z^{a_3}J_k, (F.21)$$

Plowing forward:

$$\begin{split} I^{i}Z^{[a_{1}}Z^{a_{2}]}J_{j}(z)\,I^{j}Z^{a_{3}}J_{k}(w) \sim \\ &\frac{1}{z-w}\left(I^{i}Z^{a_{1}}Z^{a_{2}}Z^{a_{3}}J_{k} + \frac{1}{2}\omega^{a_{1}a_{2}}I^{i}(Z,Z)Z^{a_{3}}J_{k} + \right. \\ &\left. \lambda\omega^{a_{2}a_{3}}\partial(I^{i}Z^{a_{1}})J_{k} + \frac{\lambda}{2}\omega^{a_{1}a_{2}}\partial(I^{i}Z^{a_{3}})J_{k}\right) + \\ &\left. + \frac{\lambda}{(z-w)^{2}}\left(\omega^{a_{2}a_{3}}I^{i}Z^{a_{1}}J_{k} + \frac{1}{2}\omega^{a_{1}a_{2}}I^{i}Z^{a_{3}}J_{k}\right). \end{split} \tag{F.22}$$

Proceeding similarly as in the u a1 n<sup>1</sup> · u a2 n<sup>2</sup> product, one may turn the operators with derivatives into operators without derivatives plus total derivatives using the Q-exact relation [\(F.3\)](#page-108-3)

$$\lambda \partial (IZ)J = \lambda \partial IZJ + \lambda I\partial ZJ \tag{F.23}$$

$$\sim \lambda \frac{2}{3} \partial (IZJ) + \frac{1}{3} I(Z,Z)ZJ + \frac{2}{3} IZ(Z,Z)J.$$
 (F.24)

Substituting this back into the two terms with derivatives in the OPE [\(F.22\)](#page-111-0), we obtain

$$I^{i}Z^{[a_{1}}Z^{a_{2}]}J_{j}(z)I^{j}Z^{a_{3}}J_{k}(w) \sim \frac{1}{z-w}\left(I^{i}Z^{[a_{1}}Z^{a_{2}}Z^{a_{3}]}J_{k}+ \lambda \frac{2}{3}\omega^{a_{2}a_{3}}\partial(I^{i}Z^{a_{1}}J_{k}) + \lambda \frac{1}{3}\omega^{a_{1}a_{2}}\partial(I^{i}Z^{a_{3}}J_{k})\right) + \frac{\lambda}{(z-w)^{2}}\left(\omega^{a_{2}a_{3}}I^{i}Z^{a_{1}}J_{k} + \frac{1}{2}\omega^{a_{1}a_{2}}I^{i}Z^{a_{3}}J_{k}\right),$$
(F.25)

where it is a pleasant sanity check to find that this whole derivative business has generated precisely the traceless linear combination [\(13.5\)](#page-92-2) which we rewrite here for convenience:

$$I^{i}Z^{[a_{1}}Z^{a_{2}}Z^{a_{3}]}J_{k} = I^{i}Z^{a_{1}}Z^{a_{2}}Z^{a_{3}}J_{k} + \frac{2}{3}\omega^{a_{2}a_{3}}I^{i}Z^{a_{1}}(Z,Z)J_{k} + \frac{2}{3}\omega^{a_{1}a_{2}}I^{i}(Z,Z)Z^{a_{3}}J_{k} + \frac{1}{3}\omega^{a_{1}a_{2}}I^{i}Z^{a_{3}}(Z,Z)J_{k} + \frac{1}{3}\omega^{a_{2}a_{3}}I^{i}(Z,Z)Z^{a_{1}}J_{k}.$$
(F.26)

Integrating over H z <sup>n</sup>1+n<sup>2</sup> to get the first mode

$$\begin{split} [(u_{n_{1}n_{2}}^{a_{1}a_{2}})_{j}^{i},I^{j}Z^{a_{3}}J_{k}(w)] &= \\ z^{n_{1}+n_{2}}\bigg(I^{i}Z^{[a_{1}}Z^{a_{2}}Z^{a_{3}]}J_{k} + \\ \lambda \frac{2}{3}\omega^{a_{2}a_{3}}\partial(I^{i}Z^{a_{1}}J_{k}) + \lambda \frac{1}{3}\omega^{a_{1}a_{2}}\partial(I^{i}Z^{a_{3}}J_{k})\bigg) + \\ + \lambda(n_{1}+n_{2})z^{n_{1}+n_{2}-1}\left(\omega^{a_{2}a_{3}}I^{i}Z^{a_{1}}J_{k} + \frac{1}{2}\omega^{a_{1}a_{2}}I^{i}Z^{a_{3}}J_{k}\right). \end{split} \tag{F.27}$$

Finally, integrating over H w n<sup>3</sup>

$$u_{n_{1}n_{2}}^{a_{1}a_{2}} \cdot u_{n_{3}}^{a_{3}} = u_{n_{1}n_{2}n_{3}}^{a_{1}a_{2}a_{3}} + \lambda \left[ (n_{1} + n_{2} + n_{3}) \left( -\frac{2}{3} \omega^{a_{2}a_{3}} u_{n_{1}+n_{2}+n_{3}-1}^{a_{1}} - \frac{1}{3} \omega^{a_{1}a_{2}} u_{n_{1}+n_{2}+n_{3}-1}^{a_{3}} \right) \right]$$

$$(n_{1} + n_{2}) \left( \omega^{a_{2}a_{3}} u_{n_{1}+n_{2}+n_{3}-1}^{a_{1}} + \frac{1}{2} \omega^{a_{1}a_{2}} u_{n_{1}+n_{2}+n_{3}-1}^{a_{3}} \right),$$

which simplifies to

$$u_{n_1 n_2}^{a_1 a_2} \cdot u_{n_3}^{a_3} = u_{n_1 n_2 n_3}^{a_1 a_2 a_3} + \frac{\lambda}{6} (n_1 + n_2 - 2n_3) (\omega^{a_1 a_2} u_{n_1 + n_2 + n_3 - 1}^{a_3} + 2\omega^{a_2 a_3} u_{n_1 + n_2 + n_3 - 1}^{a_1}).$$
(F.28)

To bring it to the form of [\(13.14\)](#page-93-0), we just need to note that n<sup>1</sup> + n<sup>2</sup> − 2n<sup>3</sup> = −ϵ<sup>n</sup>1n<sup>3</sup> − ϵ<sup>n</sup>2n<sup>3</sup> in terms of the levi-civita symbols. Moreover

<span id="page-112-0"></span>
$$\epsilon_{n_1 n_3} u^a_{n_1 + n_2 + n_3 - 1} = \epsilon_{n_1 n_3} u^a_{n_2} \tag{F.29}$$

$$\epsilon_{n_2 n_3} u_{n_1 + n_2 + n_3 - 1}^a = \epsilon_{n_2 n_3} u_{n_1}^a \tag{F.30}$$

by the same argument as the one used for [\(F.29\)](#page-112-0).

This leads to our final expression which matches the one obtained through algebraic means:

$$u_{n_{1}n_{2}}^{a_{1}a_{2}} \cdot u_{n_{3}}^{a_{3}} = u_{n_{1}n_{2}n_{3}}^{a_{1}a_{2}a_{3}} - \frac{\lambda}{6} \left( \epsilon_{n_{1}n_{3}} (\omega^{a_{1}a_{2}} u_{n_{2}}^{a_{3}} + 2\omega^{a_{2}a_{3}} u_{n_{2}}^{a_{1}}) + \epsilon_{n_{2}n_{3}} (\omega^{a_{1}a_{2}} u_{n_{1}}^{a_{3}} + 2\omega^{a_{2}a_{3}} u_{n_{1}}^{a_{1}}) \right).$$
 (F.31)

### <span id="page-113-0"></span>G Generalizing to Symmetric and Anti-symmetric matrices

We wish to generalize the chiral algebra construction to the case where our fields are now valued in symmetric or anti-symmetric matrices.

It will prove useful to construct a Z<sup>2</sup> action that commutes with the tree level BRST charge Q0. A consistent Q<sup>0</sup> action amounts to a Lie subalgebra of the matrix Lie algebra gl<sup>N</sup> ⊗ A under the Z<sup>2</sup> action. Such a Z<sup>2</sup> action, consists of an involution a → a¯ on the algebra A and a Z<sup>2</sup> action on the matrices. Here are two possible choices of Lie subalgebras:

• Skew symmetric matrices so<sup>N</sup> (A):

<span id="page-113-1"></span>
$$\mathfrak{so}_N(A): \{\Phi \in \mathfrak{gl}(N) \otimes A \mid \bar{\Phi}_{ji} = -\Phi_{ij} \}.$$
 (G.1)

• Symplectic matrices sp<sup>N</sup> (A):

<span id="page-113-3"></span>
$$\mathfrak{sp}_N(A): \{\Phi \in \mathfrak{gl}(2N) \otimes A \mid \bar{\Phi}_{ji} = -(\Omega^{-1}\Phi\Omega)_{ij} \}.$$
 (G.2)

Depending on the symmetry properties of the matrices, the Z<sup>2</sup> action in question will be different. Let's explore the different cases.

• Φ(z) ∈ A ⊗ V<sup>2</sup> C <sup>N</sup> ∼= A ⊗ so(N)

This corresponds to [\(G.1\)](#page-113-1) with trivial involution ¯a = a. We interpret these fields as living in the adjoint representation of an SO(N) symmetry that has been gauged. Here, the transposition operation commutes with Q<sup>0</sup> for free:

$$Q_0 \Phi^T = Q_0(-\Phi) = -\Phi\Phi, \qquad (G.3)$$

while

<span id="page-113-2"></span>
$$(Q_0 \Phi)^T = (\Phi \Phi)^T = -(\Phi)^T (\Phi)^T = -\Phi \Phi,$$
 (G.4)

where the minus sign in equation [\(G.4\)](#page-113-2) arose from commuting one Φ past the other.

So we see:

$$Q_0(\Phi)^T = (Q_0\Phi)^T. (G.5)$$

• Φ(z) ∈ A ⊗ Sym<sup>2</sup>C <sup>N</sup> ∼= A ⊗ sp(N)

This corresponds to [\(G.2\)](#page-113-3) with trivial involution ¯a = a. We interpret these fields as living in the adjoint representation of an Sp(N) symmetry that has been gauged. If we define our field with one index up and one down, Φ<sup>a</sup> b , where the symplectic form Ωab was used to lower what naturally would've been two upper indices, then its transposition symmetry reads:

$$\Phi^T = -\Omega^{-1}\Phi\Omega. \tag{G.6}$$

In this case, Q<sup>0</sup> also commutes with transposition. The proof of this is completely analogous to the previous one but for some extra Ω's.

• Matter fields valued in symmetric matrices and ghosts in antisymmetric: Φ(z) ∈ A<sup>0</sup> ⊗ so(N) | {z } c ghosts ⊕ A<sup>1</sup> ⊗ Sym<sup>2</sup>C N | {z } Z fields ⊕ A<sup>2</sup> ⊗ so(N) | {z } b ghosts .

This corresponds to [\(G.1\)](#page-113-1) with involution ¯a = (−1)<sup>g</sup>a. Here we interpret the Z fields as living in the symmetric representation of an SO(N) gauge symmetry. In this case transposition is equivalent to multiplying ghost even elements by minus one:

$$\Phi^T = (-1)^{g+1}\Phi = -c + Z - b. \tag{G.7}$$

Again, transposition commutes with Q0:

$$Q_0(\Phi)^T = Q_0(-c + Z - b)$$
 (G.8)

$$= -cc + [c, Z] - [c, b] - ZZ$$
 (G.9)

$$= -(-c + Z - b)(-c + Z - b)$$
 (G.10)

$$= -(c+Z+b)^{T}(c+Z+b)^{T}$$
 (G.11)

$$= ((c+Z+b)(c+Z+b))^{T}$$
 (G.12)

$$= (Q_0 \Phi)^T. (G.13)$$

• Matter fields valued in antisymmetric matrices and ghosts in sp(N): Φ(z) ∈ A<sup>0</sup> ⊗ sp(N) | {z } c ghosts ⊕ A<sup>1</sup> ⊗ ∧<sup>2</sup>C 2N | {z } Z fields ⊕ A<sup>2</sup> ⊗ sp(N) | {z } b ghosts

This corresponds to [\(G.2\)](#page-113-3) with involution ¯a = (−1)<sup>g</sup>a. Using the same convention to raise and lower indices with the symplectic form, Ω as in the Sp case, the transposition operation reads:

$$\Phi^T = (-1)^{g+1} \Omega^{-1} \Phi \Omega. \tag{G.14}$$

Q<sup>0</sup> also commutes with this operation and the proof is identical to the previous one except for the extra Ω's.

In all of the examples above, single trace operators can be described by the so called Dihedral cohomology HD• (A[[s]]) [\[76\]](#page-121-12), depending on the choice of the involution. We now briefly describe this connection. The involution on A induces a Z<sup>2</sup> action on the Hochschild complex A<sup>⊗</sup><sup>n</sup> .

$$\omega(a_1, \dots, a_n) = (\pm 1)(\bar{a}_n, \bar{a}_{n-1}, \dots, \bar{a}_1). \tag{G.15}$$

This action, together with the cyclic Z<sup>n</sup> action on A<sup>⊗</sup><sup>n</sup> , forms an action of the Dihedral group D<sup>n</sup> = ⟨t, ω | t <sup>n</sup> = ω <sup>2</sup> = 1, ωtω<sup>−</sup><sup>1</sup> = t −1 ⟩ on A<sup>⊗</sup><sup>n</sup> . In both the so<sup>N</sup> (A) and sp<sup>N</sup> (A) cases, we consider D<sup>n</sup> invariant multilinear maps to build single trace operators

$$(C|\bullet,\ldots,\bullet):(A[[s]]\otimes\cdots\otimes A[[s]])^{D_n}\to\mathbb{C}.$$
 (G.16)

These identify the single trace operators with the Dihedral cohomology HD• (A[[s]]).

We can also consider a mixture of SO and Sp fields, half-hypermultiplet matter. This naturally leads to the generalized notion of a Calabi-Yau category. In fact, our chiral algebra construction for a 2 Calabi-Yau algebra A can be generalized to a (compact) 2 Calabi-Yau category C. Similar to our discussion in Appendix [D,](#page-105-0) a compact d-dimensional Calabi-Yau category C is the same as a cyclic A<sup>∞</sup> category. Here, to simplify the discussion we consider an ordinary category C equipped with a trace map:

$$\operatorname{Tr}_{a}: \operatorname{Hom}_{\mathcal{A}}(a, a) \to \mathbb{C}[d],$$
 (G.17)

for each object a ∈ A. The associated pairing

$$(\bullet, \bullet) : \operatorname{Hom}_{\mathcal{A}}(a, b) \otimes \operatorname{Hom}_{\mathcal{A}}(b, a) \to \mathbb{C}[d]$$
 (G.18)

given by (αβ) = Tr (αβ) is required to be symmetric and non-degenerate. For our construction, we require that there is only a finite number of objects in the category and each HomA(a, b) is finite dimensional.

More explicitly, a d-dimensional Calabi-Yau category C is the same as the following data

- A super algebra A<sup>a</sup> = Aaa = EndC(a) for each object a.
- A A<sup>a</sup> − A<sup>b</sup> bi-module Aab = HomC(a, b) for each pair of objects a, b.
- A collections of maps Aab ⊗ Abc → Aac satisfying some compatibility conditions.
- A trace map Tr : A<sup>a</sup> → C[d] for each object a, such that the pairing (•, •) : Aab ⊗ Aba → C[d] is symmetric and non-degenerate.

As before, we assign elements in HomC(a, b) both a super degree |α| and a ghost degree gh[α]. Then one can consider matrix fields Φ(z) valued in L a,b∈C Aab. We can define the OPE and BRST current as we did for a CY algebra. However, for SU(N) or GL(N) matrices, this "generalization" does not gives us anything new, as we can define the algebra

$$A[\mathcal{C}] = \bigoplus_{a,b} \operatorname{Hom}_{\mathcal{C}}(a,b).$$
 (G.19)

We can see that the chiral algebra construction for the Calabi-Yau category C is the same as the chiral algebra associated to the Calabi-Yau algebra A[C].

On the contrary, the generalization to a Calabi-Yau category does give us a nontrivial generalization when we consider a mixture of SO and Sp fields.

We first introduce the notion of an involution on a category. An involution on a category C is a collection of maps

$$\alpha \in \operatorname{Hom}_{\mathcal{C}}(a, b) \to \bar{\alpha} \in \operatorname{Hom}_{\mathcal{C}}(b, a)$$
 (G.20)

for each pair of objects a, b. It satisfies the condition that

$$\bar{\alpha} = \alpha, \quad \overline{\alpha\beta} = (-1)^{|\alpha||\beta|} \bar{\beta}\bar{\alpha}.$$
 (G.21)

Now we consider a chiral algebra with a mixture of SO and Sp fields. We divide the set of objects Obj C into two subsets Obj C = O ∪P, where an object in O corresponds to an SO field and an object in P corresponds to an Sp field.

We follow [\[85\]](#page-122-7) in their definition of the Lie superalgebra osp(n|m), and define the Lie algebra osp(C, O, P) as a Lie subalgebra of

$$\mathfrak{gl}(\mathcal{C}) := \operatorname{End}_{\mathcal{C}}((\bigoplus_{o \in \mathbf{O}} \mathbb{C}^N o) \oplus (\bigoplus_{p \in \mathbf{P}} \mathbb{C}^{2N} p)),$$
 (G.22)

given by

$$\mathfrak{osp}(\mathcal{C}, \mathbf{O}, \mathbf{P}) = \{ \Phi \in \mathfrak{gl}(\mathcal{C}) \mid \bar{\Phi}^T = -i^{\deg(\Phi)} B^{-1} \Phi B \}.$$
 (G.23)

Here B is the matrix

$$B = \left(\bigoplus_{o \in \mathbf{O}} iI_N\right) \oplus \left(\bigoplus_{p \in \mathbf{P}} \Omega_N\right). \tag{G.24}$$

The deg(Φ) here can be chosen as any degree compatible with the multiplication, e.g., |Φ|, gh(Φ), or |Φ| − gh(Φ). Different choices, of course, give rise to different theories. We can expand the definition explicitly. A field Φ valued in osp(C, O, P) consists of several components.

• We have a field  $\Phi_{\mathbf{O}}(z) \in \mathfrak{so}_N(A_{\mathbf{O}})$  in deg = 0. Here  $A_{\mathbf{O}} = \bigoplus_{a,b \in \mathbf{O}} \operatorname{Hom}_{\mathcal{C}}(a,b)$ , and  $\mathfrak{so}_N(A_{\mathbf{O}})$  is given by the condition

$$\bar{\Phi}_{\mathbf{O}}(z)^T = -\Phi_{\mathbf{O}}(z). \tag{G.25}$$

• We have a field  $\Phi_{\mathbf{P}}(z) \in \mathfrak{sp}_N(A_{\mathbf{P}})$  in deg = 0. Here  $A_{\mathbf{P}} = \bigoplus_{a,b \in \mathbf{P}} \operatorname{Hom}_{\mathcal{C}}(a,b)$ , and  $\mathfrak{sp}_N(A_{\mathbf{P}})$  is given by the condition

$$\bar{\Phi}_{\mathbf{P}}(z)^T = -\Omega^{-1}\Phi_{\mathbf{P}}(z)\Omega. \tag{G.26}$$

• We have a pair of fields  $\Phi_{\mathbf{OP}} \in \mathrm{Hom}(\mathbb{C}^N, \mathbb{C}^{2N}) \otimes A_{\mathbf{OP}}$  and  $\Phi_{\mathbf{PO}} \in \mathrm{Hom}(\mathbb{C}^{2N}, \mathbb{C}^N) \otimes A_{\mathbf{PO}}$  in deg = 1. This pair of fields is constrained by

$$\bar{\Phi}_{\mathbf{OP}}^T = \Omega^{-1} \Phi_{\mathbf{PO}}, \qquad \bar{\Phi}_{\mathbf{PO}}^T = -\Phi_{\mathbf{OP}} \Omega.$$
 (G.27)

It is straight forward to generalize the above construction to the case when each node (object) a corresponds to a distinct rank  $k_aN$ .

### References

- <span id="page-117-0"></span>[1] G. Hooft, A planar diagram theory for strong interactions, Nuclear Physics B 72 (1974), no. 3 461–473.
- <span id="page-117-1"></span>[2] J. Maldacena, The large-n limit of superconformal field theories and supergravity, International journal of theoretical physics 38 (1999), no. 4 1113–1133.
- <span id="page-117-2"></span>[3] E. Witten, Anti-de Sitter space and holography, Adv. Theor. Math. Phys. 2 (1998) 253–291, [hep-th/9802150].
- <span id="page-117-3"></span>[4] P. Haggi-Mani and B. Sundborg, Free large N supersymmetric Yang-Mills theory as a string theory, JHEP **04** (2000) 031, [hep-th/0002189].
- [5] A. Dhar, G. Mandal, and S. R. Wadia, String bits in small radius AdS and weakly coupled N=4 super Yang-Mills theory. 1., hep-th/0304062.
- [6] A. Clark, A. Karch, P. Kovtun, and D. Yamada, Construction of bosonic string theory on infinitely curved anti-de Sitter space, Phys. Rev. D 68 (2003) 066011, [hep-th/0304107].
- [7] A. Karch, Light cone quantization of string theory duals of free field theories, hep-th/0212041.
- <span id="page-117-4"></span>[8] R. Gopakumar, From free fields to AdS, Phys. Rev. D 70 (2004) 025009, [hep-th/0308184].

- [9] O. Aharony, Z. Komargodski, and S. S. Razamat, On the worldsheet theories of strings dual to free large N gauge theories, JHEP 05 (2006) 016, [[hep-th/0602226](http://arxiv.org/abs/hep-th/0602226)].
- [10] I. Yaakov, Open and closed string worldsheets from free large N gauge theories with adjoint and fundamental matter, JHEP 11 (2006) 065, [[hep-th/0607244](http://arxiv.org/abs/hep-th/0607244)].
- [11] O. Aharony, J. R. David, R. Gopakumar, Z. Komargodski, and S. S. Razamat, Comments on worldsheet theories dual to free large N gauge theories, Phys. Rev. D 75 (2007) 106006, [[hep-th/0703141](http://arxiv.org/abs/hep-th/0703141)].
- [12] N. Berkovits, Perturbative Super-Yang-Mills from the Topological AdS(5) x S\*\*5 Sigma Model, JHEP 09 (2008) 088, [[arXiv:0806.1960](http://arxiv.org/abs/0806.1960)].
- [13] N. Berkovits, Sketching a Proof of the Maldacena Conjecture at Small Radius, JHEP 06 (2019) 111, [[arXiv:1903.08264](http://arxiv.org/abs/1903.08264)].
- <span id="page-118-0"></span>[14] M. R. Gaberdiel and R. Gopakumar, The worldsheet dual of free super Yang-Mills in 4D, JHEP 11 (2021) 129, [[arXiv:2105.10496](http://arxiv.org/abs/2105.10496)].
- <span id="page-118-1"></span>[15] N. Itzhaki and J. McGreevy, The Large N harmonic oscillator as a string theory, Phys. Rev. D 71 (2005) 025003, [[hep-th/0408180](http://arxiv.org/abs/hep-th/0408180)].
- [16] S. S. Razamat, On a worldsheet dual of the Gaussian matrix model, JHEP 07 (2008) 026, [[arXiv:0803.2681](http://arxiv.org/abs/0803.2681)].
- [17] R. Gopakumar, What is the Simplest Gauge-String Duality?, [arXiv:1104.2386](http://arxiv.org/abs/1104.2386).
- [18] R. Gopakumar, From free fields to AdS. 2., Phys. Rev. D 70 (2004) 025010, [[hep-th/0402063](http://arxiv.org/abs/hep-th/0402063)].
- <span id="page-118-2"></span>[19] R. Gopakumar, From free fields to AdS: III, Phys. Rev. D 72 (2005) 066008, [[hep-th/0504229](http://arxiv.org/abs/hep-th/0504229)].
- <span id="page-118-3"></span>[20] E. Witten, Introduction to cohomological field theories, Int. J. Mod. Phys. A 6 (1991) 2775–2792.
- <span id="page-118-4"></span>[21] M. Kontsevich and Y. Manin, Gromov-Witten classes, quantum cohomology, and enumerative geometry, Commun. Math. Phys. 164 (1994) 525–562, [[hep-th/9402147](http://arxiv.org/abs/hep-th/9402147)].
- <span id="page-118-6"></span>[22] K. Costello, Topological conformal field theories and calabi–yau categories, Advances in Mathematics 210 (2007), no. 1 165–214.
- [23] K. J. Costello, The Gromov-Witten potential associated to a TCFT, arXiv Mathematics e-prints (Sept., 2005) math/0509264, [[math/0509264](http://arxiv.org/abs/math/0509264)].
- [24] K. J. Costello, A dual point of view on the ribbon graph decomposition of moduli space, arXiv Mathematics e-prints (Jan., 2006) math/0601130, [[math/0601130](http://arxiv.org/abs/math/0601130)].
- <span id="page-118-5"></span>[25] K. J. Costello, Topological conformal field theories and gauge theories, arXiv Mathematics e-prints (May, 2006) math/0605647, [[math/0605647](http://arxiv.org/abs/math/0605647)].

- <span id="page-119-0"></span>[26] V. G. Turaev, Quantum Invariants of Knots and 3-Manifolds. De Gruyter, Berlin, Boston, 2016.
- <span id="page-119-1"></span>[27] V. Turaev and O. Viro, State sum invariants of 3-manifolds and quantum 6j-symbols, Topology 31 (1992), no. 4 865–902.
- <span id="page-119-2"></span>[28] E. Witten, Topological sigma models, Communications in Mathematical Physics 118 (1988), no. 3 411–449.
- <span id="page-119-3"></span>[29] E. Witten, Mirror manifolds and topological field theory, arXiv preprint hep-th/9112056 (1991).
- <span id="page-119-4"></span>[30] M. Kontsevich, Homological algebra of mirror symmetry, in Proceedings of the International Congress of Mathematicians: August 3–11, 1994 Z¨urich, Switzerland, pp. 120–139, Springer, 1995.
- <span id="page-119-5"></span>[31] V. Ginzburg, Calabi-Yau algebras, [math/0612139](http://arxiv.org/abs/math/0612139).
- <span id="page-119-16"></span>[32] M. Kontsevich and Y. S. Soibelman, Notes on a-infinity algebras, a-infinity categories and non-commutative geometry, Lecture Notes in Physics 757 (2008) 153–220.
- <span id="page-119-6"></span>[33] M. Kontsevich, A. Takeda, and Y. Vlassopoulos, Pre-calabi-yau algebras and topological quantum field theories, arXiv preprint arXiv:2112.14667 (2021).
- <span id="page-119-7"></span>[34] M. Bershadsky, S. Cecotti, H. Ooguri, and C. Vafa, Kodaira-Spencer theory of gravity and exact results for quantum string amplitudes, Commun. Math. Phys. 165 (1994) 311–428, [[hep-th/9309140](http://arxiv.org/abs/hep-th/9309140)].
- <span id="page-119-8"></span>[35] M. Bershadsky, S. Cecotti, H. Ooguri, and C. Vafa, Holomorphic anomalies in topological field theories, Nuclear Physics B 405 (1993), no. 2-3 279–304.
- <span id="page-119-9"></span>[36] C. Beem, M. Lemos, P. Liendo, W. Peelaers, L. Rastelli, and B. C. van Rees, Infinite Chiral Symmetry in Four Dimensions, Commun. Math. Phys. 336 (2015), no. 3 1359–1433, [[arXiv:1312.5344](http://arxiv.org/abs/1312.5344)].
- <span id="page-119-10"></span>[37] K. Costello and D. Gaiotto, Twisted Holography, [arXiv:1812.09257](http://arxiv.org/abs/1812.09257).
- <span id="page-119-11"></span>[38] B. Mazel, J. Sandor, C. Wang, and X. Yin, Conformal Perturbation Theory and Tachyon-Dilaton Eschatology via String Fields, [arXiv:2403.14544](http://arxiv.org/abs/2403.14544).
- <span id="page-119-12"></span>[39] B. Zwiebach, Closed string field theory: Quantum action and the B-V master equation, Nucl. Phys. B 390 (1993) 33–152, [[hep-th/9206084](http://arxiv.org/abs/hep-th/9206084)].
- <span id="page-119-13"></span>[40] E. Witten, Non-commutative geometry and string field theory, Nuclear Physics B 268 (1986), no. 2 253–294.
- <span id="page-119-14"></span>[41] E. Witten, Chern-Simons gauge theory as a string theory, Prog. Math. 133 (1995) 637–678, [[hep-th/9207094](http://arxiv.org/abs/hep-th/9207094)].
- <span id="page-119-15"></span>[42] D. Gaiotto, J. Kulp, and J. Wu, Higher Operations in Perturbation Theory, [arXiv:2403.13049](http://arxiv.org/abs/2403.13049).

- <span id="page-120-0"></span>[43] A. Kapustin and L. Rozansky, On the relation between open and closed topological strings, Commun. Math. Phys. 252 (2004) 393–414, [[hep-th/0405232](http://arxiv.org/abs/hep-th/0405232)].
- <span id="page-120-1"></span>[44] G. B. Segal, The Definition of Conformal Field Theory, pp. 165–171. Springer Netherlands, Dordrecht, 1988.
- <span id="page-120-17"></span>[45] J. Lurie, On the classification of topological field theories, Current developments in mathematics 2008 (2008), no. 1 129–280.
- <span id="page-120-2"></span>[46] M. Kontsevich, A. Takeda, and Y. Vlassopoulos, Smooth calabi-yau structures and the noncommutative legendre transform, arXiv preprint arXiv:2301.01567 (2023).
- <span id="page-120-3"></span>[47] K. J. Costello and S. Li, Quantum BCOV theory on Calabi-Yau manifolds and the higher genus B-model, [arXiv:1201.4501](http://arxiv.org/abs/1201.4501).
- <span id="page-120-4"></span>[48] K. Costello and S. Li, Quantization of open-closed BCOV theory, I, [arXiv:1505.06703](http://arxiv.org/abs/1505.06703).
- <span id="page-120-5"></span>[49] K. Costello and S. Li, Twisted supergravity and its quantization, [arXiv:1606.00365](http://arxiv.org/abs/1606.00365).
- <span id="page-120-6"></span>[50] K. Budzik and D. Gaiotto, Giant gravitons in twisted holography, Journal of High Energy Physics 2023 (Oct., 2023).
- <span id="page-120-7"></span>[51] H. Li, Vertex algebras and vertex poisson algebras, Communications in Contemporary Mathematics 6 (2004), no. 01 61–110.
- <span id="page-120-9"></span>[52] K. Zeng, Twisted Holography and Celestial Holography from Boundary Chiral Algebra, Commun. Math. Phys. 405 (2024), no. 1 19, [[arXiv:2302.06693](http://arxiv.org/abs/2302.06693)].
- <span id="page-120-8"></span>[53] V. Kac, Introduction to vertex algebras, poisson vertex algebras, and integrable hamiltonian pde, in Perspectives in Lie theory, pp. 3–72. Springer, 2017.
- <span id="page-120-10"></span>[54] A. Beilinson and V. Drinfeld, Chiral Algebras. American Mathematical Society Colloquium publications. American Mathematical Society, 2004.
- <span id="page-120-11"></span>[55] D. Tamarkin, Deformations of chiral algebras, arXiv preprint math/0304211 (2003).
- <span id="page-120-12"></span>[56] R. Gopakumar and C. Vafa, On the gauge theory / geometry correspondence, Adv. Theor. Math. Phys. 3 (1999) 1415–1443, [[hep-th/9811131](http://arxiv.org/abs/hep-th/9811131)].
- <span id="page-120-13"></span>[57] J. Loday and B. Vallette, Algebraic Operads. Grundlehren der mathematischen Wissenschaften. Springer Berlin Heidelberg, 2012.
- <span id="page-120-14"></span>[58] V. Balasubramanian, M.-x. Huang, T. S. Levi, and A. Naqvi, Open strings from N=4 superYang-Mills, JHEP 08 (2002) 037, [[hep-th/0204196](http://arxiv.org/abs/hep-th/0204196)].
- <span id="page-120-15"></span>[59] A. L´opez-Raven, D-Brane Systems in Twisted Holography and SO/Sp Chiral Algebras, [arXiv:2412.01905](http://arxiv.org/abs/2412.01905).
- <span id="page-120-16"></span>[60] M. Kontsevich, Deformation quantization of Poisson manifolds. 1., Lett. Math. Phys. 66 (2003) 157–216, [[q-alg/9709040](http://arxiv.org/abs/q-alg/9709040)].

- <span id="page-121-0"></span>[61] A. A. Voronov and M. Gerstenhaber, Higher operations on the hochschild complex, Functional Analysis and Its Applications 29 (1995), no. 1 1–5.
- [62] D. E. Tamarkin, Another proof of m. kontsevich formality theorem, arXiv preprint math/9803025 (1998).
- [63] J. E. McClure and J. H. Smith, A solution of deligne's conjecture, arXiv preprint math/9910126 (1999).
- <span id="page-121-1"></span>[64] C. Brav and N. Rozenblyum, The cyclic deligne conjecture and calabi-yau structures, arXiv preprint arXiv:2305.10323 (2023).
- <span id="page-121-2"></span>[65] A. S. Cattaneo and G. Felder, A Path integral approach to the Kontsevich quantization formula, Commun. Math. Phys. 212 (2000) 591–611, [[math/9902090](http://arxiv.org/abs/math/9902090)].
- <span id="page-121-3"></span>[66] C. Beem, D. Ben-Zvi, M. Bullimore, T. Dimofte, and A. Neitzke, Secondary products in supersymmetric field theory, in Annales Henri Poincare, vol. 21, pp. 1235–1310, Springer, 2020.
- <span id="page-121-4"></span>[67] A. Kapustin and Y. Li, D branes in Landau-Ginzburg models and algebraic geometry, JHEP 12 (2003) 005, [[hep-th/0210296](http://arxiv.org/abs/hep-th/0210296)].
- <span id="page-121-5"></span>[68] J. Le and G. Zhou, On the hochschild cohomology ring of tensor products of algebras, Journal of Pure and Applied Algebra 218 (2014), no. 8 1463–1477.
- <span id="page-121-6"></span>[69] M. Gerstenhaber, The cohomology structure of an associative ring, Annals of Mathematics 78 (1963), no. 2 267–288.
- <span id="page-121-7"></span>[70] J. Loday, Cyclic Homology. Grundlehren der mathematischen Wissenschaften. Springer Berlin Heidelberg, 2013.
- <span id="page-121-8"></span>[71] J.-P. Serre et al., Linear representations of finite groups, vol. 42. Springer, 1977.
- <span id="page-121-9"></span>[72] M. Farinati, Hochschild duality, localization, and smash products, Journal of Algebra 284 (2005), no. 1 415–434.
- <span id="page-121-10"></span>[73] C. Beem and L. Rastelli, Vertex operator algebras, Higgs branches, and modular differential equations, JHEP 08 (2018) 114, [[arXiv:1707.07679](http://arxiv.org/abs/1707.07679)].
- [74] F. Bonetti and L. Rastelli, Supersymmetric localization in AdS<sup>5</sup> and the protected chiral algebra, JHEP 08 (2018) 098, [[arXiv:1612.06514](http://arxiv.org/abs/1612.06514)].
- <span id="page-121-11"></span>[75] M. Dedushenko and Y. Wang, 4d/2d ¡-¿ 3d/1d: A song of protected operator algebras, Adv. Theor. Math. Phys. 26 (2022), no. 7 2011–2075, [[arXiv:1912.01006](http://arxiv.org/abs/1912.01006)].
- <span id="page-121-12"></span>[76] J.-L. Loday and C. Procesi, Homology of symplectic and orthogonal algebras, Advances in Mathematics 69 (1988), no. 1 93–108.
- <span id="page-121-13"></span>[77] T. Tradler, The bv algebra on hochschild cohomology induced by infinity inner products, arXiv preprint math/0210150 (2002).

- <span id="page-122-0"></span>[78] K. Costello and N. M. Paquette, Twisted Supergravity and Koszul Duality: A case study in AdS3, Commun. Math. Phys. 384 (2021), no. 1 279–339, [[arXiv:2001.02177](http://arxiv.org/abs/2001.02177)].
- <span id="page-122-1"></span>[79] V. E. Fern´andez, N. M. Paquette, and B. R. Williams, Twisted holography on AdS<sup>3</sup> × S <sup>3</sup>× K3 & the planar chiral algebra, SciPost Phys. 17 (2024), no. 4 109, [[arXiv:2404.14318](http://arxiv.org/abs/2404.14318)].
- <span id="page-122-2"></span>[80] N. Ishtiaque, S. Faroogh Moosavian, and Y. Zhou, Topological holography: The example of the D2-D4 brane system, SciPost Phys. 9 (2020), no. 2 017, [[arXiv:1809.00372](http://arxiv.org/abs/1809.00372)].
- <span id="page-122-3"></span>[81] E. Frenkel and D. Ben-Zvi, Vertex Algebras and Algebraic Curves. Mathematical surveys and monographs. American Mathematical Society, 2001.
- <span id="page-122-4"></span>[82] M. V. d. Bergh, Calabi-yau algebras and superpotentials, arXiv preprint arXiv:1008.0599 (2010).
- <span id="page-122-5"></span>[83] R. L. Cohen and S. Ganatra, Calabi-yau categories, the floer theory of a cotangent bundle, and the string topology of the base, draft (2015).
- <span id="page-122-6"></span>[84] T. Etg¨u and Y. Lekili, Koszul duality patterns in floer theory, Geometry & Topology 21 (2017), no. 6 3313–3389.
- <span id="page-122-7"></span>[85] V. G. Kac, A sketch of Lie superalgebra theory, Communications in Mathematical Physics 53 (1977), no. 1 31 – 64.