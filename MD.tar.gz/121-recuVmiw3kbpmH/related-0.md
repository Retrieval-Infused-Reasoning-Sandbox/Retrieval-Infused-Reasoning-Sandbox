### Skip to main content

Thank you for visiting nature.com. You are using a browser version with limited support for CSS. To obtain the best experience, we recommend you use a more up to date browser (or turn off compatibility mode in Internet Explorer). In the meantime, to ensure continued support, we are displaying the site without styles and JavaScript.

#### Advertisement

#### Advertisement

### nature

### communications

- View all journals
- Q<sub>Search</sub>
- Log in
- Content Explore content
- About the journal ~
- Publish with us ~
- Sign up for alerts Q
- RSS feed
- 1. nature >
- 2. nature communications >
- 3. articles >
- 4. article

<span id="page-0-0"></span>Atomically dispersed nickel as coke-resistant active sites for methane dry reforming

Download PDF
Download PDF

- Article
- Open access
- Published: 15 November 2019

# Atomically dispersed nickel as coke-resistant active sites for methane dry reforming

- Mohcin Akri<sup>1</sup> na1
- Shu Zhao<sup>2</sup> na1
- Xiaoyu Li<sup>1,3</sup>
- Ketao Zang<sup>4</sup>,

- Adam F. Lee ORCID: orcid.org/0000-0002-2153-1391<sup>5</sup>
- Mark A. Isaacs<sup>6</sup>,
- <u>Wei Xi<sup>4</sup></u>,
- Yuvaraj Gangarajula<sup>1</sup>,
- <u>Jun Luo</u>4,
- Yujing Ren<sup>1</sup>,
- Yi-Tao Cui<sup>7</sup>.
- Lei Li<sup>8</sup>.
- Yang Su<sup>1</sup>,
- Xiaoli Pan<sup>1</sup>,
- <u>Wu Wen<sup>9</sup>,</u>
- Yang Pan<sup>9</sup>,
- Karen Wilson<sup>5</sup>,
- Lin Li<sup>1</sup>.
- Botao Qiao ORCID: orcid.org/0000-0001-6351-455X<sup>1,10</sup>,
- Hirofumi Ishii<sup>11</sup>
- Yen-Fa Liao<sup>11</sup>
- Aigin Wang<sup>1</sup>
- Xiaodong Wang<sup>1</sup> &
- ...
- Tao Zhang 1,3

### Show authors

*Nature Communications* **volume 10**, Article number: 5181 (2019) <u>Cite this</u> article

- 41k Accesses
- 560 Citations
- 29 Altmetric
- Metrics details

### **Subjects**

- Catalyst synthesis
- Heterogeneous catalysis
- Materials for energy and catalysis
- Nanoscale materials

# **Abstract**

Dry reforming of methane (DRM) is an attractive route to utilize CO<sup>2</sup> as a chemical feedstock with which to convert CH<sup>4</sup> into valuable syngas and simultaneously mitigate both greenhouse gases. Ni-based DRM catalysts are promising due to their high activity and low cost, but suffer from poor stability due to coke formation which has hindered their commercialization. Herein, we report that atomically dispersed Ni single atoms, stabilized by interaction with Ce-doped hydroxyapatite, are highly active and cokeresistant catalytic sites for DRM. Experimental and computational studies reveal that isolated Ni atoms are intrinsically coke-resistant due to their unique ability to only activate the first C-H bond in CH<sup>4</sup> , thus avoiding methane deep decomposition into carbon. This discovery offers new opportunities to develop large-scale DRM processes using earth abundant catalysts.

### **Similar content being viewed by others**

![](_page_2_Picture_3.jpeg)

**Enhanced CO[2](https://www.nature.com/articles/s41929-022-00870-8?fromPaywallRec=false)  [utilization in dry reforming of methane](https://www.nature.com/articles/s41929-022-00870-8?fromPaywallRec=false) [achieved through nickel-mediated hydrogen spillover in](https://www.nature.com/articles/s41929-022-00870-8?fromPaywallRec=false) [zeolite crystals](https://www.nature.com/articles/s41929-022-00870-8?fromPaywallRec=false)** 

![](_page_2_Figure_5.jpeg)

**[Experimental and computational investigation on](https://www.nature.com/articles/s41598-020-80287-0?fromPaywallRec=false) [underlying factors promoting high coke resistance in NiCo](https://www.nature.com/articles/s41598-020-80287-0?fromPaywallRec=false) [bimetallic catalysts during dry reforming of methane](https://www.nature.com/articles/s41598-020-80287-0?fromPaywallRec=false)** 

Article Open access 12 January 2021

![](_page_3_Figure_0.jpeg)

Tuning metal-support interactions in nickel-zeolite catalysts leads to enhanced stability during dry reforming of methane

Article Open access 03 October 2024

### Introduction

Dry reforming of methane (DRM) is the process of converting methane (CH $_4$ ) and carbon dioxide (CO $_2$ ) into synthesis gas (syngas, H $_2$  + CO) $^{1,2,3}$ , an important building block for world scale industrial processes and energy conversion such as Fischer-Tropsch (FT), carbonylation, hydroformylation, and for the syntheses of fuels and high value-added chemicals $^{3,4,5,6}$ . CO $_2$  and CH $_4$  are the two most important atmospheric greenhouse gases (GHGs) responsible for anthropogenic climate change $^7$ , but are also abundant and low-cost carbon sources; $^8$  the latter is regarded as a (relatively) clean energy source with which to realize a low-carbon economy $^9$ . Despite the emergence of DRM around 30 years ago $^{10}$ , its potential to mitigate rising GHG emissions and provide clean(er) fossil fuel utilization has sparked renewed interest in associated catalytic technologies $^{2,11,12,13,14,15,16}$ .

Almost 30 years' of intensive studies have identified Ni catalysts as the most promising candidate for DRM due to their low cost and high initial activity (comparable to noble metal catalysts)<sup>1,2,12,17</sup>. However, there are no commercial DRM processes to date due in large part to in situ catalyst deactivation by carbon deposition (coking) and/or sintering of Ni species<sup>12,18</sup>. Previous studies have shown that support acidity<sup>17,19</sup> and the dimensions of catalytically active components strongly influence carbon deposition<sup>12,20</sup>. Several studies have identified a threshold Ni nanoparticle size (2 nm<sup>21</sup> or 7-10 nm<sup>22</sup>) below which the carbon deposition significantly decreases. However, small Ni particles generally exhibit poor thermal stability and are prone to sintering under DRM reaction conditions, presenting an intractable problem.

Single-atom catalysts (SACs) comprising isolated, individual metal atoms dispersed on a solid support, have recently emerged as a new frontier in catalysis and materials science <sup>23,24,25,26,27,28,29</sup>. Although generally considered thermodynamically unstable, recent studies have revealed

instances wherein atomically dispersed metals can actually be much more thermally stable and durable than their nanocatalyst counterparts  $^{30,31,32,33}$ ,  $^{34}$ . Considering that Ni atoms in SACs are certainly below the threshold size to be coke-resistant in DRM, well-designed stable Ni SACs should be an ideal candidate for DRM provided that they are sufficiently active. Herein, we demonstrate that Ni atomically dispersed over hydroxyapatite (HAP) is highly active and completely coke-resistant during high temperature DRM.  ${\rm CeO}_{\rm X}$  doping of HAP traps isolated Ni atoms, preventing on-stream sintering and deactivation and resulting in an active and stable high-performance DRM catalyst. This finding provides a new route for the development of cokeresistant DRM catalysts.

### **Results**

### Structural characterization of Ni single-atom catalyst

HAP and Ce-substituted HAP with a Ce metal loading of 5 wt% (denoted as HAP-Ce) were prepared by a previously reported co-precipitation (CP) method  $^{35}$ . Ni atoms were subsequently deposited over the HAP support with a nominal loading of 0.5 wt% (denoted as  $0.5\mathrm{Ni}_1/\mathrm{HAP}$ ), and the HAP-Ce support with loadings of 0.5 wt%, 1 wt%, and 2 wt% (denoted as  $0.5\mathrm{Ni}_1/\mathrm{HAP}$ -Ce,  $1\mathrm{Ni}_1/\mathrm{HAP}$ -Ce, and  $2\mathrm{Ni}_1/\mathrm{HAP}$ -Ce), by strong electrostatic adsorption (SEA)  $^{30,36,37}$ . For comparison, Ni nanocatalysts with 10 wt% loading were prepared by the same method over HAP and HAP-Ce supports, denoted as  $10\mathrm{Ni}/\mathrm{HAP}$  and  $10\mathrm{Ni}/\mathrm{HAP}$ -Ce, respectively. Synthesis details are provided in the Methods section.

Actual Ni metal loadings of the as-prepared catalysts were determined by inductively coupled plasma atomic emission spectroscopy (ICP-AES), and were similar to the nominal values (Supplementary Table 1) except for 10Ni/HAP-Ce which contained 8.5 wt% Ni. Textural properties of Ce-doped HAP were similar to the undoped support (Supplementary Fig. 1a and Supplementary Table. 2). However,  $CO_2$  temperature-programed desorption (TPD, Supplementary Fig. 1b) showed that ceria addition decreased the density of both weak and strong base sites, indicating that  $CeO_x$  is less basic than HAP.

The X-ray diffraction (XRD) pattern of HAP-Ce evidenced no crystalline  ${\rm CeO}_2$  phases (Supplementary Fig. 2a), suggesting that cerium is either highly dispersed on the HAP external surface or doped into the lattice. Ni and NiO reflections were also absent from all unreduced samples (Supplementary Fig. 2b), suggesting that Ni/NiO were highly dispersed on both supports even following high temperature calcination (500 °C). For samples subsequently reduced under  ${\rm H}_2$  at 500 °C, only 10 wt% Ni samples show reflections

characteristic of fcc nickel metal at  $44.6^{\circ}$  (Supplementary Fig. 2c, indicated by arrows). Corresponding Ni particle sizes were calculated according to the Scherrer equation as 17.0 and 10.6 nm for 10Ni/HAP and 10Ni/HAP-Ce,

respectively, suggesting the introduction of Ce inhibited the sintering of Ni nanoparticles. For 0.5 wt% loadings, the absence of crystalline Ni and/or NiO phases may reflect the formation of highly dispersed Ni species, or instrumental detection limit due to the low Ni loading. All samples were therefore examined by (aberration corrected) high-angle annular dark-field scanning transmission electron microscopy (ac-HAADF-STEM) to identify the nature of supported Ni species. Neither Ni nanoparticles nor clusters were visible in relatively low magnification images for as-prepared 0.5Ni<sub>1</sub>/HAP and 0.5Ni<sub>1</sub>/HAP-Ce samples (Supplementary Fig. 3a, b), whereas higher magnification images (Supplementary Fig. 3c, d) clearly revealed the exclusive presence of isolated Ni atoms, confirming 0.5Ni<sub>1</sub>/HAP and 0.5Ni<sub>1</sub>/ HAP-Ce as SACs before reduction. Following 500  $^{\circ}$ C H $_2$  reduction the 0.5Ni $_1$ / HAP-Ce sample still predominantly comprised atomically dispersed Ni (Fig. 1a and Supplementary Fig. 4), in addition to a small number ( $\sim$ 7% frequency, Fig. 1d) of sub-1.5 nm Ni clusters. For 1Ni<sub>1</sub>/HAP-Ce and 2Ni<sub>1</sub>/HAP-Ce catalysts, low magnification images (Supplementary Figs. 5 and 6) showed the presence of a low density of ~1 nm nanoclusters, indicating that nickel predominantly existed as single atoms (Fig. 1b-d). In contrast, the asprepared, 10 wt% samples comprised small (~1-2 nm) NiO clusters/ nanoparticles over both supports (Supplementary Fig. 7a, b), which grew post-reduction to generate a distribution of small (1-3 nm) and large (5-10 nm) nanoparticles for 10Ni/HAP-Ce (Fig. 1c and Supplementary Fig. 7c) and a broad nanoparticle distribution (2-17 nm) for 10Ni/HAP (Supplementary Fig. 7d) in accordance with XRD.

# Fig. 1 figure 1

Electron microscopy images and size distribution of Ni/HAP-Ce samples. **a** HAADF-STEM images of  $0.5\mathrm{Ni}_1$ /HAP-Ce, **b**  $2\mathrm{Ni}_1$ /HAP-Ce, and **c**  $10\mathrm{Ni}$ /HAP-Ce samples after  $500\,^{\circ}\mathrm{C}$  H $_2$  reduction. **d** particle size distributions of **a-c**; yellow circles indicate atomically dispersed Ni and red squares indicate Ni metals nanoparticles. **e** EDX element maps of  $0.5\mathrm{Ni}_1$ /HAP-Ce

### Full size image

The coordination environment of Ni atoms was further determined by quasi in situ X-ray absorption spectroscopy (XAS) measurements. Ni K-edge X-ray near-edge absorption spectra (XANES) collected after 500 °C reduction show that  $2\mathrm{Ni_1}/\mathrm{HAP}$ -Ce possessed an intense white line reminiscent of NiO (Fig. 2a), whereas  $10\mathrm{Ni}/\mathrm{HAP}$ -Ce exhibited a weaker white line and strong pre-edge feature more closely resembling Ni foil, characteristic of oxidized and metallic chemical states respectively. Corresponding extended X-ray absorption fine structure (EXAFS) spectra confirmed the dominant presence of Ni-Ni scattering distances at ~2.50 Å (Fig. 2b) for  $10\mathrm{Ni}/\mathrm{HAP}$ -Ce. In contrast,  $2\mathrm{Ni_1}/\mathrm{HAP}$ -Ce exhibited strong Ni–O scattering at 2.05 Å, a significant 2.60 Å contribution attributed to Ni–Ce scattering, and only a weak Ni–Ni contribution (corresponding to a coordination number ~0.7); these

observations are consistent with atomically dispersed Ni (Supplementary Table  $\underline{3}$  and Supplementary Fig.  $\underline{8}$ ). XAS data are thus in good agreement with AC-HAADF-STEM imaging (Fig.  $\underline{1b}$ ).

# Fig. 2 figure 2

X-ray adsorption spectroscopy study of Ni/HAP-Ce catalysts. **a** Ni K-edge XANES spectra of 500 °C reduced HAP-Ce supported Ni catalysts and reference samples, and **b** corresponding phase shift corrected  $k^2$ -weighted Fourier transform

Full size image

### Ni SAC electronic structure

The surface oxidation state of Ni in the preceding as-prepared and reduced samples were studied by X-ray photoelectron spectroscopy (XPS). Since reduced Ni species are prone to ambient oxidation, 500 °C H<sub>2</sub> reduction was performed in situ within a quartz reaction cell prior to direct transfer into the spectrometer without air-exposure. As-prepared 0.5Ni<sub>1</sub>/HAP sample contained only Ni(OH)<sub>2</sub> species at 856.3 eV binding energy (Fig. 3a), consistent with isolated Ni atoms at the hydroxyapatite interface, whereas the as-prepared 10Ni/HAP sample possessed almost equal amounts of Ni(OH)<sub>2</sub> and NiO (853.7 eV), Fig. 3c. In situ reduction of the 10Ni/HAP sample transformed all surface Ni<sup>2+</sup> species to metallic Ni (853.0 eV, Fig. <u>3c</u>), indicating a relatively weak interaction with the HAP support, and in accordance with the observation of metallic Ni nanocluster/particles by STEM (Supplementary Fig.  $\overline{2}$ ). In contrast, only half of the initial Ni(OH)<sub>2</sub> species in 0.5Ni<sub>1</sub>/HAP underwent reduction to Ni metal (Fig. 3a), suggesting that isolated Ni adatoms experience a stronger support interaction. Figure 3d reveals that Ce doping had negligible impact on the Ni surface chemical state for high loadings, with equimolar Ni(OH)<sub>2</sub> and NiO species present in the asprepared material, and only metallic Ni observed following in situ reduction. In contrast, the 0.5Ni<sub>1</sub>/HAP-Ce differed significantly from its undoped counterpart, exhibiting both Ni(OH), and NiO in an almost equimolar ratio in the as-prepared sample, and being entirely resistant to in situ reduction (Fig. 3b). Note that the high binding energy Ni 2p peak in Fig. 3b at 856.3 eV can be assigned to isolated Ni atoms in a distinct Ni(OH), chemical environment, and not from Ni-O-Ni interactions in NiO nanoparticles. Nonlocal screening of photoexcited core holes only gives rise to peak splitting for the latter when NiO nanostructures exceed  $\sim$  2.4 nm $^{38,39}$ , of which there is no evidence in 0.5Ni<sub>1</sub>/HAP-Ce by either HRTEM (Fig. <u>1a</u> and Supplementary Figs. 3 and 4) or XRD (Supplementary Fig. 2). The surprising resistance  $0.5\mathrm{Ni}_1/\mathrm{HAP}$ -Ce to  $\mathrm{H}_2$  reduction was confirmed by temperature-programmed reduction (TPR, Supplementary Fig. 9): high loading 10Ni/HAP and 10Ni/HAP-Ce exhibit almost complete reduction <600 °C associated with Ni metal

formation (Supplementary Table. 4); in contrast,  $0.5\mathrm{Ni_1/HAP}$  sample exhibited a weak, broad reduction associated with loss of only  $\sim\!60\%$  of the initial  $\mathrm{Ni^{2+}}$  species, and  $0.5\mathrm{Ni_1/HAP-Ce}$  showed negligible reducibility. XPS and TPR unambiguously demonstrate that cerium doping of HAP stabilizes atomically dispersed Ni against reduction and sintering.

# Fig. 3 figure 3

In-Situ XPS analysis of Ni/HAP and Ni/HAP-Ce samples. **a** High resolution Ni 2p XP spectra of as-prepared and in situ reduced:  $0.5 \text{Ni}_1/\text{HAP}$ , **b**  $0.5 \text{Ni}_1/\text{HAP-Ce}$ , **c** 10 Ni/HAP, and **d** 10 Ni/HAP-Ce

Full size image

### **Catalytic performance in DRM**

The preceding Ni catalysts were evaluated for DRM using a 20 vol%  $CH_{4}$  + 20 vol% CO<sub>2</sub> feed gas (balanced with He) with a gas hourly space velocity (GHSV) of 60,000 mL  $\rm g_{cat}^{-1}\,h^{-1}$ . All samples were in situ reduced at 500 °C by 10 vol% H<sub>2</sub>/He for 1 h prior to catalytic testing. At 750 °C, both 0.5Ni<sub>1</sub>/HAP and 10Ni/HAP samples underwent rapid deactivation, with  ${\rm CO}_2$  conversions decreasing from 84 to 49% and 90 to 73% respectively over 7 h on-stream (Fig.  $\underline{4a}$ ), mirroring corresponding  $CH_{\underline{a}}$  conversions (Supplementary Fig.  $\underline{10a}$ ). However, characterization of post-reaction catalysts indicates that they deactivate by different mechanisms. Temperature-programmed oxidation revealed significant carbon deposition over the deactivated 10Ni/HAP (Fig. 4b), evidenced by a large weight loss associated with reactively formed CO<sub>2</sub> desorption between 400 and 600 °C. The nature of carbon species was analyzed by Raman spectroscopy (Fig.  $\frac{4a}{2}$  inset). The peak at  $\sim 1328\,\mathrm{cm}^{-1}$  (D band) corresponds to  $sp^3$  carbon atoms at defects and disordered sites  $\frac{40}{3}$ , while that  $\sim$ 1585 cm<sup>-1</sup> (G band) corresponds to sp<sup>2</sup> carbon atoms in graphitic rings $^{41}$ . In contrast, the  $0.5Ni_1/HAP$  sample exhibited negligible carbon deposition (Fig. 4b), albeit large nanoparticles (Fig. 4a inset) emerged from sintering of isolated Ni atoms, apparent from a 44.55° reflection in the post-reaction XRD pattern characteristic of fcc Ni metal (Supplementary Fig. 2d). It is important to note that the 0.5Ni<sub>1</sub>/HAP SAC shows comparable initial activity to the 10Ni/HAP despite possessing twenty times less active component. HAP supported isolated Ni atoms are therefore highly active and resistant to coking, albeit susceptible to sintering during high temperature DRM.

Fig. 4 figure 4

DRM performance and carbon deposition analysis over Ni/HAP and Ni/HAP-Ce samples. **a**  $CO_2$  conversion during DRM over HAP and **c** HAP-Ce supported different Ni catalysts. Conditions:  $T=750\,^{\circ}\text{C}$ ,  $CH_4/CO_2/He=10/10/30$ , total flow =  $50\,\text{mL}\,\text{min}^{-1}$  (GHSV =  $60,000\,\text{mL}\,\text{h}^{-1}\,\text{g}_{\text{cat}}^{\phantom{\text{cat}}}$ ), inset is Raman spectra of spent  $0.5\text{Ni}_1/\text{HAP}$  and 10Ni/HAP after reaction at  $750\,^{\circ}\text{C}$  and STEM image of  $0.5\text{Ni}_1/\text{HAP}$  after 7 h reaction; **b**-**d** TGA-MS and TGA profiles of various catalysts after different reaction times on-stream at  $750\,^{\circ}\text{C}$ 

### Full size image

HAADF-STEM (Fig. 1a, b), H2-TPR (Supplementary Fig. 9) and in situ XPS (Fig. 3b) demonstrate that cerium doping of the HAP support stabilizes atomically dispersed Ni to high temperature reduction. This results in a striking performance enhancement for the 0.5Ni<sub>1</sub>/HAP-Ce catalyst, for which  $CO_2$  (Fig.  $\underline{4c}$ ) and  $CH_4$  (Supplementary Fig.  $\underline{10b}$ ) conversions show only a modest decrease from initial ~90% levels over 65 h reaction. Increasing the Ni loading over the Ce-doped support to 1 wt% and 2 wt% further improved the long-term stability, with such catalysts of 1Ni<sub>1</sub>/HAP-Ce and 2Ni<sub>1</sub>/HAP-Ce (mainly composed of single atoms as revealed by Fig. 1b-d, Supplementary Figs. 5 and 6) able to continuously operate at 95% CO<sub>2</sub> conversion for almost 65 and 100 h, respectively, with a H<sub>2</sub>/CO ratio around unity (Supplementary Fig. 10c). These Ni<sub>1</sub>/HAP-Ce SACs showed negligible coking (Fig. 4d) and theoretical carbon balance equal to 100% (Supplementary Fig. 10c). By comparison, the 10Ni/HAP-Ce rapidly deactivated within 15 h on-stream (Fig. <u>4c</u>) due to severe coking (Fig. <u>4d</u>) along with a decrease in carbon balance and H<sub>2</sub>/CO ratio (Supplementary Fig. 10c). The principal role of Ce therefore appears to be to stabilize atomically dispersed Ni, rather than to suppress carbon deposition. In addition, a control experimental shows that HAP-Ce itself is almost inactive for DRM (Fig. 4c), suggesting that activity predominantly originates from the atomically dispersed Ni. It could be argued that the catalyst reduction temperature is quite low compared with the DRM reaction temperature, even though H<sub>2</sub>-TPR result suggests that our Ni SAC would not be significantly reduced even at 750  $^{\circ}\text{C}.$  To confirm the sinter resistance of our catalysts, the DRM performance of 0.5Ni<sub>1</sub>/HAP-Ce and 2Ni<sub>1</sub>/ HAP-Ce pre-reduced at 750 °C was also examined (Supplementary Fig. 11); there was no deterioration relative to 500 °C pre-reduced catalysts.

Recent elegant work by Tang et al.  $^{42}$  reported a synergy between single-atom Ru $_1$  and Ni $_1$  sites resulting in very high activity for DRM even at 600 °C. Significant performance benefits accrued for our catalytic system under identical reaction conditions, even for loadings that do not exclusively give rise to single atoms: the 2 wt% Ni $_1$ /HAP-Ce catalyst delivered similar activity and superior stability (Supplementary Fig. 11c) without recourse to precious metals.

The faster deactivation of 0.5Ni<sub>1</sub>/HAP-Ce versus 2Ni<sub>1</sub>/HAP-Ce merits consideration. In theory, all active sites within single-atom catalysts are identical and homogenously distributed. However, in practice the fabrication of a completely homogenous dispersion of single-atom sites is extremely difficult, and there is likely a distribution of coordination numbers and microenvironments $\frac{43}{1}$ . For  $0.5\mathrm{Ni}_1/\mathrm{HAP-Ce}$ , we suggest that some single atoms initially present in lower coordination environments (e.g. the edges of HAP crystals) aggregate during reaction to lower their surface energies, resulting in the (albeit very slow) observed deactivation (Fig. 4c and Supplementary Fig. 10b). In contrast, unstable Ni single atoms present in the as-prepared 2Ni<sub>1</sub>/HAP-Ce likely sintered during subsequent reduction to form the small clusters and nanoparticles seen in Fig. 1b. Hence the reduced 2Ni<sub>1</sub>/HAP-Ce catalyst may possess a smaller proportion of unstable single atoms than the reduced 0.5Ni<sub>1</sub>/HAP-Ce catalyst. Note that nanoclusters and nanoparticles also eventually sinter during reaction, but with slower kinetics than isolated atoms (reflecting the higher surface energy and hence instability of the latter). Moreover, even if all isolated Ni atoms in 0.5Ni<sub>1</sub>/HAP-Ce initially occupy low energy surface sites, provided that their interaction with the support is weaker than the cohesive energy between Ni atoms then thermodynamics will always drive sintering for a sufficiently high energy input, at high temperature.

measured under differential reactor operation at much higher GHSV  $(528,000-1,056,000 \,\mathrm{mL}\,\mathrm{h}^{-1}\,\mathrm{g}_{\mathrm{cat}}^{}^{}-1)$  and low CH<sub>4</sub>/CO<sub>2</sub> conversions (≤25%) to eliminate possible mass- and heat-transfer limitations. Ni/HAP-Ce SACs exhibited much higher specific activity (2-4 times), but an almost identical turnover frequency (TOF), to the nickel nanoclusters and nanoparticles present for 10Ni/HAP-Ce. The latter suggests a common Ni<sup>2+</sup> active site (likely  $Ni(OH)_2$ ), and the former more efficient Ni utilization in the  $SACs^{30,44}$ , 45,46 (a common feature and key advantage of SACs, although less important for earth abundant metal catalysts). Alternatively, the similar TOFs may be a simple coincidence of common energy barriers for different rate-limiting steps over Ni single atoms and nanoparticles. CH<sub>1</sub> activation is generally regarded as rate-limiting for overall DRM $^{14,47}$ , with a barrier of  $\sim 0.9$  eV over Ni(111), representative of the surface of Ni nanoparticles in 2Ni<sub>1</sub>/HAP-Ce, and 10Ni/HAP-Ce<sup>14</sup>. This barrier is very similar to that calculated for activation of the first C-H bond in CH<sub>3</sub>O dehydrogenation over Ni single atoms in 0.5Ni<sub>1</sub>/ HAP-Ce (the proposed rate-limiting step, see below). The specific activity of the Ni<sub>1</sub>/HAP-Ce SAC is comparable or superior to that of literature Ni DRM catalysts (Table 1).

The specific activity of our HAP-Ce supported Ni catalysts was subsequently

**Table 1 Reaction rate of Ni/HAP and Ni/HAP-Ce catalysts Full size table** 

### Origin of Ni SAC coke resistance

DRM usually proceeds according to the following steps:  ${\rm CH_4}$  decomposes over Ni active sites to form carbon and  $H_2$  (Supplementary Fig.  $\underline{12}$ ) and the resulting carbon is then oxidized by O adatoms liberated by CO2 dissociation either over the support or at the metal-support interface 13,14,48. High temperature (>700 °C) coke deposits thus predominantly arise from unoxidized carbon bound to Ni. The coke resistance of Ni SACs may be either intrinsic (i.e. they do not produce carbon from methane) or extrinsic (carbon formed is immediately oxidized by CO<sub>2</sub>); the latter implies superior CO<sub>2</sub> activation. To distinguish between these two mechanisms, carbon deposition in the presence of  $CH_{\Delta}$  alone was studied at the reaction temperature (750 °C) over  $2Ni_1/HAP$ -Ce and 10Ni/HAP-Ce catalysts (Fig. 5a, b). In both cases  ${\rm CH_4}$  decomposition occurred, however the resulting products were different. For 10Ni/HAP-Ce, significant coking was evidenced by a color change (Supplementary Fig. 13a, b) and the large weight loss (8.67%) following TPO post-reaction (Fig. 5c), accompanied by H<sub>2</sub> and ethylene formation (Fig. 5b). In contrast, 2Ni<sub>1</sub>/HAP-Ce produced almost no coke (Supplementary Fig. <u>13c</u>, d, Fig. 5c), but hydrogen, ethylene. It should be noted that on 2Ni<sub>1</sub>/HAP-Ce much greater C-C coupling occurred, but the H<sub>2</sub> yield was much lower compared with 10Ni/HAP-Ce (Fig. 5d). The Ni SAC therefore favors partial  $CH_{\Delta}$ dehydrogenation and C-C coupling versus complete decomposition to C (step (4) in Supplementary Fig. 12). This observation is in good agreement with Fe single site catalysts, wherein non-oxidative coupling of  $\operatorname{CH}_4$  to ethene and aromatics without attendant coke formation was recently reported 49. Theoretical calculations also suggest that oxide supported Pt SAC catalysts only efficiently activate the first C-H bond in  $CH_4$ , consistent with our present observations 50.

# Fig. 5 figure 5

CH $_4$  decomposition and products distribution over Ni/HAP-Ce catalysts. **a** Mass spectrometer signals during CH $_4$  decomposition at 750 °C of 2Ni $_1$ /HAP-Ce and **b** 10Ni/HAP-Ce, **c** TGA analysis of both catalysts after 1 h of reaction, and **d** product ratios for non-oxidative methane decomposition. H $_2$ /CH $_4$  and C $_2$ H $_4$ /CH $_4$  represent the mass spectrometer product ratio of H $_2$  and C $_2$ H $_4$  relative to the amount of CH $_4$  reacted

### Full size image

To understand the intrinsic coke resistance of our Ni SACs, underpinned by their selective activation of the first C-H bond, we undertook DFT calculations

to investigate the first two steps of  $CH_4$  dissociation over a  $Ni_1/CeO_2$  surface (Fig. 6a) and subsequent transformation of CH2 species (Fig. 6b, c). CH4 adsorption on Ni<sub>1</sub>/CeO<sub>2</sub> (111) is a physisorption process with a small adsorption energy of  $-0.11\,\mathrm{eV}$ , in which the carbon atom of  $\mathrm{CH}_4$  is located 2.56 Å above the Ni atom. The first C-H bond cleavage is exothermic by 0.65 eV with an activation barrier of 0.63 eV (TS1). This barrier is considerably lower than that over a Ni(111) surface  $(0.9 \text{ eV})^{51}$ , and hence activation of the first C-H bond in CH<sub>4</sub> is extremely efficient over ceria-bound isolated Ni atoms. The resulting CH<sub>3</sub> species binds atop the Ni atom while the H adatom moves to a neighboring O. The next dehydrogenation step,  $CH_3 \rightarrow CH_2 + H$ , is thermodynamically unfavorable (endothermic by  $0.80\,\mathrm{eV}$ ) with a high activation barrier of  $1.54\,\mathrm{eV}$  (**TS2**), and hence CH<sub>3</sub> dissociation is strongly disfavored over Ni<sub>1</sub>/CeO<sub>2</sub>, in excellent agreement with the preceding experiments. In light of the thermodynamic stability of CH<sub>3</sub> to subsequent C-H cleavage over our catalysts, the appearance of CO as a major product in our catalytic system appears paradoxical. However, a recent report of DRM over  $Ni_A$  clusters (which also show good carbon deposition resistance<sup>52</sup>) identified the oxidation of CH<sub>3</sub> to CH<sub>3</sub>O as an alternative route to CO following initial methane activation, as also proposed for  $Ni_1-Ru_1/CeO_2^{42}$ . We therefore considered this alternative route for transforming reactively formed CH<sub>3</sub> to CO without carbon deposition (Fig. 6b, c). Unlike CH<sub>3</sub> dehydrogenation, the oxidation of CH<sub>3</sub> to CH<sub>3</sub>O on Ni<sub>1</sub>/CeO<sub>2</sub> is exothermic with a relatively lower barrier of 0.69 eV. Subsequent CH<sub>3</sub>O dehydrogenation to CHO is highly exothermic, and the rate-determining step (C-H bond activation in CH<sub>3</sub>O proceeds with a barrier of 0.90 eV) to the final CO product (which is only slightly endothermic by 0.39 eV). The oxidation of CH<sub>3</sub> to CH<sub>3</sub>O is hence plausible as the dominant (indirect) pathway for CH<sub>3</sub> dehydrogenation to CO. Overall, DFT calculations suggest that Ni<sub>1</sub>/CeO<sub>2</sub> should be an active catalyst for  $CH_4$  reforming to CO.

# Fig. 6 figure 6

DFT calculation of  ${\rm CH_4}$  decomposition. **a** Potential energy diagram from DFT calculations of  ${\rm CH_4}$  dissociation over  ${\rm Ni_1/CeO_2}$ . **b** Potential energy diagram from DFT calculations of  ${\rm CH_3}$  oxidation and  ${\rm CH_3O}$  dehydrogenation, and **c** corresponding geometries over  ${\rm Ni_1/CeO_2}$ . Numbers in parentheses indicate the activation barriers for elementary steps in eV. Optimized structures for reaction intermediates are shown inset (Ce: yellow, Ni: blue, O: red, C: black, H: white)

### Full size image

In summary, this work demonstrates that Ni atoms atomically dispersed over HAP are highly resistant to coking during DRM, but prone to on-stream deactivation through sintering. Ce doping of HAP induces strong metal-support interactions which stabilize Ni single atoms towards sintering, and favor selective activation of only the first C-H bond in methane, resulting in a high activity and stability for 100 h DRM with negligible carbon deposition. The excellent performance and stability of Ni single-atom catalysts offers a low-cost route to commercial dry methane reforming. Of broader significance, the findings in this work may provide a new approach for the development of highly coke-resistant Ni-based catalysts.

### **Methods**

#### **Chemicals**

Calcium nitrate (99%), cerium nitrate (99%), nickel nitrate (98.5%), ammonium dihydrogen phosphate (99%), and ammonia solution (25 vol% aqueous) were purchased from Sigma-Aldrich and used without pretreatment.

### Synthesis of hydroxyapatite and Ce-substituted HAP

Stoichiometric hydroxyapatite (Ca:P = 1.67 molar ratio) and Ce substituted hydroxyapatite nanoparticles (5 wt% Ce loading), denoted as HAP and HAP-Ce respectively, were synthesized by co-precipitation of calcium nitrate (Ca(NO $_3$ ) $_2$ .4H $_2$ O) and ammonium dihydrogen phosphate ((NH $_4$ ) $_2$ HPO $_4$ ), with or without cerium nitrate (Ce(NO $_3$ ) $_2$ .6H $_2$ O). Typically, 7.54 g of Ca(NO $_3$ ) $_2$ .

 $4\rm{H}_2\rm{O}$ , and 2.54 g of  $(\rm{NH}_4\rm{)}_2\rm{HPO}_4$  were separately dissolved in 80 cm  $^3$  of doubly distilled water, and the pH adjusted to 10.5 with 25 vol% ammonia solution. Ammonium dihydrogen phosphate was added dropwise to the calcium nitrate solution at room temperature, and the resulting milky suspension stirred at 90 °C and 600 rpm for 2 h. The precipitate was rinsed with demineralized water three times prior to drying in air at 80 °C overnight.

The dried sample was subsequently calcined at 400 °C (ramp rate 10 °C min-

### Ni deposition on HAP and HAP-Ce

A range of nominal Ni loadings (0.5, 1, 2, and 10 wt%) were deposited on the preceding supports by strong electrostatic adsorption at room temperature. An appropriate amount of nickel nitrate (Ni  $(NO_3)_2$ ),

 $6H_2O$ ) was dissolved in 50 mL deionized water, and the solution pH adjusted to 10 with 25 vol% ammonia solution. The appropriate mass of HAP or HAP-Ce was then added to the nickel nitrate solution, and stirred at 600 rpm for 3 h at room temperature. The resulting impregnated solids were filtered, washed

<sup>&</sup>lt;sup>1</sup>) in muffle furnace for 4 h. Ce-substituted hydroxyapatite was synthesized identically except for the addition of the appropriate amount of cerium nitrate to calcium nitrate prior to pH adjustment.

repeatedly with deionized water, and dried at 80 °C overnight prior to calcination at 500 °C (ramp rate 10 °C min<sup>-1</sup>) for 4 h.

### Characterization

Actual Ni loadings were determined by inductively coupled plasma spectrometry-atomic emission spectrometry (ICP-AES) on an IRIS Intrepid II XSP instrument (Thermo Electron Corporation). Specific surface areas (S<sub>RET</sub>) were measured by  $N_2$  porosimetry on a Micromeritics ASAP 2010 apparatus with adsorption-desorption isotherms recorded at 77 K. Samples were outgassed at 523 K prior to analysis. Surface areas were calculated from the adsorption branch using the Brunauer-Emmett-Teller method, with pore diameters determined from the desorption branch using the BJH method. Xray diffraction (XRD) patterns were collected on a PW3040/60 × ' Pert PRO (PANnalytical) diffractometer with Cu  $\rm K_{\alpha}$  radiation (0.15432 nm) operating at 40 kV and 40 mA. Patterns were collected between  $2\theta = 10-80^{\circ}$  at a scan speed of  $10^{\circ}\,\mathrm{min^{-1}}$ .  $\mathrm{CO_{2}}$  temperature-programmed desorption (TPD) was performed on a Micromeritics AutoChem II 2920 instrument. HAP and HAP-Ce supports were first loaded into a U-shaped quartz reactor, pretreated at 300 °C in He for 0.5 h to remove physisorbed water and surface carbonates, and cooled to 50 °C. Base sites were subsequently saturated with CO2 under flowing 10 vol%  ${\rm CO_2}$  in He at room temperature. Samples were then purged under He for 30 min prior to heating at 10 °C min $^{-1}$  to 900 °C under flowing He and desorbing CO $_2$  detected by TCD. Temperature-programmed reduction (H<sub>2</sub>-TPR) was also carried out on a Micromeritics AutoChem II 2920 instrument. Samples (100 mg) were placed in a U-shaped quartz reactor and pretreated in flowing Ar  $(30\,\mathrm{mL\,min}^{-1})$  at 573 K for 30 min, and then ramped to 1073 K at  $10\,\mathrm{C\,min^{-1}}$  in flowing 10 vol%  $\mathrm{H_2/Ar}$  (50 mL min<sup>-1</sup>) and reacted H<sub>2</sub> detected by TCD

High-angle annular dark-field scanning transmission electron microscopy (HAADF-STEM) was performed on a JEOL JEM-2100F instrument. Aberration-corrected HAADF-STEM was performed on a JEOL JEM-ARM200F equipped with a CEOS probe corrector with a guaranteed resolution of 0.08 nm. Samples were dispersed by ultrasonication in ethanol, and the resulting solution dropped on to carbon films supported on copper grids.

In situ X-ray photoelectron spectroscopy was performed using a Kratos Axis Ultra-DLD fitted with an electron flood gun neutralizer and a monochromated aluminum X-ray source (1486.8 eV). As-prepared samples were analyzed under UHV conditions (<10 $^{-9}$  Torr) at 40 eV pass energy, and then transferred in vacuo to a quartz high-pressure reaction chamber where they were exposed to a 1 bar static atmosphere of 2 vol%  $\rm H_2$  in  $\rm N_2$  and heated to 500 °C

at a ramp rate of  $10\,^{\circ}\text{C}\,\text{min}^{-1}$  for 1 h. Reduced samples were then cooled to room temperature and transferred in vacuo back to the analysis chamber for re-measurement. Spectra were energy referenced to adventitious carbon

(284.8 eV), and Shirley background subtracted and fitted using CasaXPS v2.3.19PR1.0. Ni 2p XP spectra were fitted using a Doniach-Sunjic lineshape convoluted with a Gaussian-Lorentz function.

The X-ray absorption fine structure (XAFS) experiment was performed at the bending magnet beamline BL12B of SPring-8 (8 GeV, 100 mA) belong to National Synchotron Radiation Research Center, in which the X-ray beam was monochromatized with water-cooled Si (111) double-crystal monochromator and focused with two Rh coated focusing mirrors with the beam size of 2.0 mm in the horizontal direction and 0.5 mm in the vertical direction around sample position. The samples were filled in a phi10 stainless tube for XAFS measurements. All of the samples were measured by both transmission and fluorescence modes at Ni K-edge. The samples were also measured at BL14W1 of the Shanghai Synchrotron Radiation Facility (SSRF) light sources and similar results were obtained. The spectra were analyzed and fitted using an analysis program Demeter 53. For EXAFS fittings, the crystal structures of Ni foil and NiO are from Materials Project (https://materialsproject.org). For 2Ni<sub>1</sub>/HAP-Ce sample the structure from DFT calculation is used.

### **DFT** calculations

All calculations were performed using periodic DFT methods as implemented in the Vienna ab-initio simulation package  $(VASP)^{\frac{1}{54,55}}$ . The projector augmented wave (PAW) method was used for the interaction between atomic cores and valence electrons. Valence orbitals of Ce (4f. 5s. 6s. 5p. 5d), Ni (3d. 4s), O (2s, 2p), C (2s, 2p), and H (1s) were described by plane-wave basis sets with cutoff energies of 400 eV, whereas the Brillouin zone was sampled at the Γ-point. Exchange-correlation energies were calculated via the generalized gradient approximation (GGA) with the PBE functional  $\frac{56}{1}$ . Spin-polarized DFT + U calculations with a value of  $U_{\rm eff} = 5.0 \, \rm eV$  for the Ce 4f state were applied to correct the strong electron-correlation properties of CeO<sub>2</sub>. Convergence criteria for the electronic self-consistent iteration and force were set to  $10^{-4}$  eV and 0.03 eV/Å respectively. For evaluating the energy barriers, transition states and pathways were computed using the climbing image nudged elastic band (CI-NEB) method $^{57}$ . The CeO $_2$  (111) surface was modeled by  $p(3 \times 3)$  9 atomic layer supercells with the bottom three layers fixed. Ni<sub>1</sub>/CeO<sub>2</sub> was established by supporting one Ni atom on a CeO<sub>2</sub> (111) surface (Supplementary Fig. 14). The vacuum gap was set as ~15 Å to avoid the interaction between periodic images. Reaction energies and barriers were calculated by  $E_r = E(FS) - E(IS)$  and  $E_a = E(TS) - E(IS)$ , where E(IS), E(FS) and E(TS) are the energies of the corresponding initial state (IS), final state (FS), and transition state (TS), respectively.

### **Catalytic testing**

Catalytic activity tests were performed in a fixed-bed quartz reactor (5 mm i.d.) under atmospheric pressure. Prior to each reaction, 50 mg of catalyst was placed in the reactor tube between quartz wool plugs and reduced in situ

```
at 500 °C or 750 °C under flowing 10 vol% H_2/He (60 mL min<sup>-1</sup>) for 1 h, and
then purged with He for 30 min. Dry reforming was then undertaken using a
mixture of 20 vol% CO_2 + 20 vol% CH_4 in He (50 mL min<sup>-1</sup> total flow rate) to
generate a gas hourly space velocity (GHSV) of 60,000 \, \text{mLg}_{\text{cat}}^{-1} \, \text{h}^{-1}. Specific
activities for CH_4 and CO_2 conversion were measured at much higher GHSV
(using 2.5–5 mg of catalyst, wherein the \mathrm{CH_4} and \mathrm{CO_2} conversions were
<25%) during the first 60 min of reaction. Reactant and product
concentrations were analyzed by an Agilent 6890 online gas chromatograph
equipped with a TDX-01 column and a thermal conductivity detector, using
He as a carrier gas. CH<sub>4</sub> and CO<sub>2</sub> conversions were calculated respectively
according to the following Eqs. 1 and 2:
SC {{\mathbf{F}^{{\mathbf{H}}} {\mathbf{H}}} = \frac{F^{{\mathbf{H}}}}
\times \left[ {{\mathrm{CH}} {\mathrm{4}}} \right] -
F^{{\mathrm{outlet}}} \times \left[ {{\mathrm{CH}}_{\mathrm{4}}}
\right]^{{\mathrm{outlet}}}}{{F^{{\mathrm{inlet}}}}\times
\left\{ \left( \left( \left( \left( \left( \left( \left( \left( \left( \left( \left( \left( \left( 
(1)
SC {{\mathbb{C}}} {\mathbb{C}} = \frac{F^{{\mathbb{C}}}} 
\times \left[ {{\mathrm{CO}}} {\mathrm{2}}} \right] -
F^{{\mathrm{outlet}}} \times \left[ {{\mathrm{CO}}} {\mathrm{2}}}
\right]^{{\mathrm{outlet}}}}{{F^{{\mathrm{inlet}}}}\times
\left[ {\mathbf{CO}} {\mathbf{2}} \right]^{{\mathbf{CO}}} 
(2)
Where [{\rm CH_4}] and [{\rm CO_2}] are the respective mole fractions of {\rm CH_4} and {\rm CO_2} in
the feedstream, and F^{\text{inlet}} and F^{\text{outlet}} represents the total gas flow rate (ml
\min^{-1}) of inlet and outlet, respectively. Specific activities for CH_4 and CO_2
(\text{mol g}_{\text{Ni}}^{-1} \text{ h}^{-1}) were calculated from Eqs. 3 and 4:
${\mathrm{Rate}}\,{\mathrm{CH}} {\mathrm{4}} =
\frac{\{n_{\mathbf{H}}\}_{\mathbf{H}}}{\mathbf{H}}_{\mathbf{H}}}
{\mathrm{of}}\,{\mathrm{catalyst}} \times W {{\mathrm{Ni}}}} \times
60$$
(3)
$\{\mathbf{CO}\}_{\mathbf{CO}} =
\frac{n{\mathrm{CO}}} {\mathrm{CO}} 
{\mathrm{of}}\,{\mathrm{catalyst}} \times W {{\mathrm{Ni}}}} \times
60$$
(4)
where.
\scriptstyle $\begin{array}{I}n{\mathrm{CH}} {\mathrm{4}} =
\frac{{\left( {F^{{\mathrm{inlet}}}} \times \left[ {{\mathrm{CH}}}
{\mathrm{4}}} \right] \times C {{\mathrm{CH}} {\mathrm{4}}}}
\tilde{10^3} \left( \frac{22.4 \times 10^3}{(\mathbf{22.4 \times 10^3})} (\mathbf{mathrm{mol}}) \right)
```

and  $F^{\rm inlet}$  represents the total flow (ml min<sup>-1</sup>),[CH<sub>4</sub>], [CO<sub>2</sub>],  $C_{\rm CH4}$ , and  $C_{\rm CO2}$  denote the concentration (vol%) and conversion of CH<sub>4</sub> and CO<sub>2</sub>, respectively; and  $W_{\rm Ni}$  the nickel metal loading (wt%). Turnover frequencies (s<sup>-1</sup>) were calculated from Eq. 5:

assuming a dispersion of 100% for  $0.5\mathrm{Ni}_1$ /HAP-Ce, and values calculated for  $2\mathrm{Ni}_1$ /HAP-Ce and  $10\mathrm{Ni}$ /HAP-Ce according to the following Eq.  $\underline{6}$ .

```
D(\%) = \frac{1.0092}}{\{d_{V_A}\}}
```

where  $d_{V\!A}$  represent the mean diameter of nickel particles (nm).

# **Data availability**

The data that support the findings of this study are available within the paper and its Supplementary Information, and all data are available from the authors on reasonable request.

### References

<span id="page-16-0"></span> Bradford, M. C. J. & Vannice, M. A. CO<sub>2</sub> reforming of CH<sub>4</sub>. Catal. Rev. Sci. Eng. 41, 1-42 (1999).

Article CAS Google Scholar

<span id="page-16-1"></span>2. Pakhare, D. & Spivey, J. A review of dry (CO<sub>2</sub>) reforming of methane over noble metal catalysts. *Chem. Soc. Rev.* **43**, 7813–7837 (2014).

Article CAS PubMed Google Scholar

<span id="page-16-2"></span>3. Shi, L. et al. An introduction of  $CO_2$  conversion by dry reforming with methane and new route of low-temperature methanol synthesis. *Acc. Chem. Res.* **46**, 1838–1847 (2013).

Article CAS PubMed Google Scholar

<span id="page-17-0"></span>4. Zhong, L. et al. Cobalt carbide nanoprisms for direct production of lower olefins from syngas. *Nature* **538**, 84 (2016).

### Article ADS CAS PubMed Google Scholar

<span id="page-17-1"></span>5. Cheng, K. et al. Direct and highly selective conversion of synthesis gas into lower olefins: design of a bifunctional catalyst combining methanol synthesis and carbon-carbon coupling. *Angew. Chem. Int. Ed.* **55**, 4725–4728 (2016).

### Article CAS Google Scholar

- 6. Gao, P. et al. Direct conversion of CO<sub>2</sub> into liquid fuels with high selectivity over a bifunctional catalyst. *Nat. Chem.* **9**, 1019–1024 (2017).
- 7. Hu, Y. H. CO<sub>2</sub> Conversion and Utilization Chunshan Song, Anne F. Gaffney, and Kaoru Fujimoto, Editors. American Chemical Society: Washington, D.C. 2002. xiii + 428 pp. *Energy Fuels* **16**, 1329–1329 (2002).
- 8. Sun, Z., Ma, T., Tao, H., Fan, Q. & Han, B. Fundamentals and challenges of electrochemical CO<sub>2</sub> reduction using two-dimensional. *Mater. Chem.* **3**, 560–587 (2017).

#### CAS Google Scholar

9. He, M., Sun, Y. & Han, B. Green carbon science: scientific basis for integrating carbon resource processing, utilization, and recycling. *Angew. Chem. Int. Ed.* **52**, 9620–9633 (2013).

### Article CAS Google Scholar

10. Ashcroft, A. T., Cheetham, A. K., Green, M. L. H. & Vernon, P. D. F. Partial oxidation of methane to synthesis gas using carbon dioxide. *Nature* **352**, 225–226 (1991).

### Article ADS CAS Google Scholar

<span id="page-17-2"></span>11. Akri, M. et al. Development of nickel supported La and Ce-natural illite clay for autothermal dry reforming of methane: Toward a better resistance to deactivation. *Appl. Catal. B* **205**, 519–531 (2017).

### Article CAS Google Scholar

- <span id="page-17-3"></span>12. Lavoie, J.-M. Review on dry reforming of methane, a potentially more environmentally-friendly approach to the increasing natural gas exploitation. *Front. Chem.* **2**, 81 (2014).
- <span id="page-17-4"></span>13. Foppa, L. et al. Contrasting the role of  $Ni/Al_2O_3$  interfaces in water-gas shift and dry reforming of methane. *J. Am. Chem. Soc.* **139**, 17128–17139 (2017).

### Article CAS PubMed Google Scholar

<span id="page-18-0"></span>Liu, Z. et al. Dry reforming of methane on a highly-active Ni-CeO<sup>2</sup> catalyst: effects of metal-support interactions on C-H bond breaking. Angew. Chem. Int. Ed. **55**, 7455–7459 (2016). 14.

[Article](https://doi.org/10.1002%2Fanie.201602489) [CAS](file:///articles/cas-redirect/1:CAS:528:DC%2BC28XntFGhsLc%3D) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Dry%20reforming%20of%20methane%20on%20a%20highly-active%20Ni-CeO2%20catalyst%3A%20effects%20of%20metal-support%20interactions%20on%20C-H%20bond%20breaking&journal=Angew.%20Chem.%20Int.%20Ed.&doi=10.1002%2Fanie.201602489&volume=55&pages=7455-7459&publication_year=2016&author=Liu%2CZ)

<span id="page-18-1"></span>Buelens, L. C., Galvita, V. V., Poelman, H., Detavernier, C. & Marin, G. B. Super-dry reforming of methane intensifies CO<sup>2</sup> utilization via Le Chatelier's principle. Science **354**, 449 (2016). 15.

[Article](https://doi.org/10.1126%2Fscience.aah7161) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2016Sci...354..449B) [CAS](file:///articles/cas-redirect/1:CAS:528:DC%2BC28Xhslamt7vN) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=27738013) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Super-dry%20reforming%20of%20methane%20intensifies%20CO2%20utilization%20via%20Le%20Chatelier%E2%80%99s%20principle&journal=Science&doi=10.1126%2Fscience.aah7161&volume=354&publication_year=2016&author=Buelens%2CLC&author=Galvita%2CVV&author=Poelman%2CH&author=Detavernier%2CC&author=Marin%2CGB)

Akri, M., Chafik, T., Granger, P., Ayrault, P. & Batiot-Dupeyrat, C. Novel nickel promoted illite clay based catalyst for autothermal dry reforming of methane. Fuel **178**, 139–147 (2016). 16.

[Article](https://doi.org/10.1016%2Fj.fuel.2016.03.018) [CAS](file:///articles/cas-redirect/1:CAS:528:DC%2BC28XkslKntrk%3D) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Novel%20nickel%20promoted%20illite%20clay%20based%20catalyst%20for%20autothermal%20dry%20reforming%20of%20methane&journal=Fuel&doi=10.1016%2Fj.fuel.2016.03.018&volume=178&pages=139-147&publication_year=2016&author=Akri%2CM&author=Chafik%2CT&author=Granger%2CP&author=Ayrault%2CP&author=Batiot-Dupeyrat%2CC)

Abdullah, B., Abd Ghani, N. A. & Vo, D.-V. N. Recent advances in dry reforming of methane over Ni-based catalysts. J. Clean. Prod. **162**, 170– 185 (2017). 17.

[Article](https://doi.org/10.1016%2Fj.jclepro.2017.05.176) [CAS](file:///articles/cas-redirect/1:CAS:528:DC%2BC2sXhtVKgt7zO) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Recent%20advances%20in%20dry%20reforming%20of%20methane%20over%20Ni-based%20catalysts&journal=J.%20Clean.%20Prod.&doi=10.1016%2Fj.jclepro.2017.05.176&volume=162&pages=170-185&publication_year=2017&author=Abdullah%2CB&author=Abd%20Ghani%2CNA&author=Vo%2CD-VN)

Pawar, V., Ray, D., Subrahmanyam, C. & Janardhanan, V. M. Study of short-term catalyst deactivation due to carbon deposition during biogas dry reforming on supported Ni catalyst. Energy Fuels **29**, 8047–8052 (2015). 18.

[Article](https://doi.org/10.1021%2Facs.energyfuels.5b01862) [CAS](file:///articles/cas-redirect/1:CAS:528:DC%2BC2MXhvF2ht7fL) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Study%20of%20short-term%20catalyst%20deactivation%20due%20to%20carbon%20deposition%20during%20biogas%20dry%20reforming%20on%20supported%20Ni%20catalyst&journal=Energy%20Fuels&doi=10.1021%2Facs.energyfuels.5b01862&volume=29&pages=8047-8052&publication_year=2015&author=Pawar%2CV&author=Ray%2CD&author=Subrahmanyam%2CC&author=Janardhanan%2CVM)

Theofanidis, S. A., Galvita, V. V., Poelman, H. & Marin, G. B. Enhanced carbon-resistant dry reforming Fe-Ni catalyst: role of Fe. ACS Catal. **5**, 3028–3039 (2015). 19.

[Article](https://doi.org/10.1021%2Facscatal.5b00357) [CAS](file:///articles/cas-redirect/1:CAS:528:DC%2BC2MXmtVajsL4%3D) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Enhanced%20carbon-resistant%20dry%20reforming%20Fe-Ni%20catalyst%3A%20role%20of%20Fe&journal=ACS%20Catal.&doi=10.1021%2Facscatal.5b00357&volume=5&pages=3028-3039&publication_year=2015&author=Theofanidis%2CSA&author=Galvita%2CVV&author=Poelman%2CH&author=Marin%2CGB)

Han, J. W., Park, J. S., Choi, M. S. & Lee, H. Uncoupling the size and support effects of Ni catalysts for dry reforming of methane. Appl. Catal. B **203**, 625–632 (2017). 20.

[Article](https://doi.org/10.1016%2Fj.apcatb.2016.10.069) [CAS](file:///articles/cas-redirect/1:CAS:528:DC%2BC28XhslOht7vO) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Uncoupling%20the%20size%20and%20support%20effects%20of%20Ni%20catalysts%20for%20dry%20reforming%20of%20methane&journal=Appl.%20Catal.%20B&doi=10.1016%2Fj.apcatb.2016.10.069&volume=203&pages=625-632&publication_year=2017&author=Han%2CJW&author=Park%2CJS&author=Choi%2CMS&author=Lee%2CH)

- Lercher, J. A., Bitter, J. H., Hally, W., Niessen, W. & Seshan, K. Studies in Surface Science and Catalysis, Vol. 101, 463-472 (Elsevier, 1996). 21.
- Tang, S. et al. CO<sup>2</sup> reforming of methane to synthesis gas over sol–gelmade Ni/γ-Al2O<sup>3</sup> catalysts from organometallic precursors. J. Catal. **194**, 424–430 (2000). 22.

[Article](https://doi.org/10.1006%2Fjcat.2000.2957) [CAS](file:///articles/cas-redirect/1:CAS:528:DC%2BD3cXmtVygsLg%3D) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=CO2%20reforming%20of%20methane%20to%20synthesis%20gas%20over%20sol%E2%80%93gel-made%20Ni%2F%CE%B3-Al2O3%20catalysts%20from%20organometallic%20precursors&journal=J.%20Catal.&doi=10.1006%2Fjcat.2000.2957&volume=194&pages=424-430&publication_year=2000&author=Tang%2CS)

<span id="page-19-0"></span>23. Qiao, B. et al. Single-atom catalysis of CO oxidation using  $Pt_1/FeO_X$ . *Nat. Chem.* **3**, 634–641 (2011).

Article CAS PubMed Google Scholar

<span id="page-19-1"></span>24. Flytzani-Stephanopoulos, M. & Gates, B. C. Atomically dispersed supported metal catalysts. *Annu. Rev. Chem. Biomol. Eng.* **3**, 545–574 (2012).

Article CAS PubMed Google Scholar

<span id="page-19-2"></span>25. Wang, A., Li, J. & Zhang, T. Heterogeneous single-atom catalysis. *Nat. Rev. Chem.* **2**, 65–81 (2018).

Article ADS CAS Google Scholar

<span id="page-19-3"></span>26. Yang, H. B. et al. Atomically dispersed Ni(i) as the active site for electrochemical CO<sub>2</sub> reduction. *Nat. Energy* **3**, 140–147 (2018).

Article ADS CAS Google Scholar

<span id="page-19-4"></span>27. Lin, L. et al. Low-temperature hydrogen production from water and methanol using  $Pt/\alpha$ -MoC catalysts. *Nature* **544**, 80 (2017).

Article ADS CAS PubMed Google Scholar

<span id="page-19-5"></span>28. Lin, L. et al. A highly CO-tolerant atomically dispersed Pt catalyst for chemoselective hydrogenation. *Nat. Nanotechnol.* **14**, 354–361 (2019).

Article ADS CAS PubMed Google Scholar

29. Zhang, Z. et al. Thermally stable single atom  $Pt/m-Al_2O_3$  for selective hydrogenation and CO oxidation. *Nat. Commun.* **8**, 16100 (2017).

Article ADS CAS PubMed PubMed Central Google Scholar

<span id="page-19-6"></span>30. Qiao, B. et al. Ultrastable single-atom gold catalysts with strong covalent metal-support interaction (CMSI). *Nano Res.* **8**, 2913–2924 (2015).

Article CAS Google Scholar

<span id="page-19-7"></span>31. Jones, J. et al. Thermally stable single-atom platinum-on-ceria catalysts via atom trapping. *Science* **353**, 150–154 (2016).

Article ADS CAS PubMed Google Scholar

<span id="page-19-8"></span>32. Lang, R. et al. Non defect-stabilized thermally stable single-atom catalyst. *Nat. Commun.* **10**, 234 (2019).

Article ADS PubMed PubMed Central CAS Google Scholar

<span id="page-19-9"></span>33. Ren, G.-Q. et al. Exceptional antisintering gold nanocatalyst for diesel exhaust oxidation. *Nano. Lett.* **18**, 6489–6493 (2018).

### Article ADS CAS PubMed Google Scholar

34. Xie, P. et al. Nanoceria-supported single-atom platinum catalysts for direct methane conversion. *ACS Catal.* **8**, 4044–4048 (2018).

### Article CAS Google Scholar

35. Tang, H. et al. Strong metal-support interactions between gold nanoparticles and nonoxides. *J. Am. Chem. Soc.* **138**, 56–59 (2016).

### Article PubMed CAS Google Scholar

36. Li, T. et al. Maximizing the number of interfacial sites in single-atom catalysts for the highly selective, solvent-free oxidation of primary alcohols. *Angew. Chem. Int. Ed. Engl.* **57**, 7795–7799 (2018).

### Article CAS PubMed Google Scholar

37. DeRita, L. et al. Catalyst architecture for stable single atom dispersion enables site-specific spectroscopic and reactivity measurements of CO adsorbed to Pt atoms, oxidized Pt clusters, and metallic Pt clusters on TiO<sub>2</sub>. *J. Am. Chem. Soc.* **139**, 14150–14165 (2017).

### Article CAS PubMed Google Scholar

38. Alders, D., Voogt, F. C., Hibma, T. & Sawatzky, G. A. Nonlocal screening effects in 2p x-ray photoemission spectroscopy of NiO (100). *Phys. Rev. B* **54**, 7716–7719 (1996).

### Article ADS CAS Google Scholar

- 39. Yamauchi, R. et al. Layer matching epitaxy of NiO thin films on atomically stepped sapphire (0001) substrates. *Sci. Rep.* **5**, 14385 (2015).
- 40. Xie, Z. et al. Dry reforming of methane over CeO<sub>2</sub>-supported Pt-Co catalysts with enhanced activity. *Appl. Catal. B* **236**, 280–293 (2018).

### Article CAS Google Scholar

41. Bokobza, L., Bruneel, J.-L. & Couzi, M. Raman spectroscopy as a tool for the analysis of carbon-based materials (highly oriented pyrolitic graphite, multilayer graphene and multiwall carbon nanotubes) and of some of their elastomeric composites. *Vib. Spectrosc.* **74**, 57–63 (2014).

### Article CAS Google Scholar

42. Tang, Y. et al. Synergy of single-atom  $Ni_1$  and  $Ru_1$  sites on  $CeO_2$  for dry reforming of CH4. J. Am. Chem. Soc. **141**, 7283–7293 (2019).

### Article CAS PubMed Google Scholar

43. Liu, W. et al. Discriminating catalytically active FeNx species of atomically dispersed Fe-N-C catalyst for selective oxidation of the C-H bond. *J. Am. Chem. Soc.* **139**, 10790–10798 (2017).

Article CAS PubMed Google Scholar

<span id="page-21-0"></span>44. Qiao, B. et al. Highly efficient catalysis of preferential oxidation of CO in  $H_2$ -rich stream by gold single-atom catalysts. *ACS Catal.* **5**, 6249–6254 (2015).

Article CAS Google Scholar

<span id="page-21-1"></span>45. Cao, L. et al. Atomically dispersed iron hydroxide anchored on Pt for preferential oxidation of CO in H2. *Nature* **565**, 631–635 (2019).

Article ADS CAS PubMed Google Scholar

46. Yan, H. et al. Single-atom Pd<sub>1</sub>/graphene catalyst achieved by atomic layer deposition: remarkable performance in selective hydrogenation of 1,3-butadiene. *J. Am. Chem. Soc.* **137**, 10484–10487 (2015).

Article CAS PubMed Google Scholar

- 47. Wei, J. & Iglesia, E. Mechanism and site requirements for activation and chemical conversion of methane on supported Pt clusters and turnover rate comparisons among noble metals. *J. Phys. Chem. B* **108**, 4094–4103 (2004).
- 48. Bradford, M. C. J. & Albert Vannice, M. The role of metal-support interactions in CO<sub>2</sub> reforming of CH<sub>4</sub>. *Catal. Today* **50**, 87-96 (1999).

Article CAS Google Scholar

49. Guo, X. et al. Direct, nonoxidative conversion of methane to ethylene, aromatics, and hydrogen. *Science* **344**, 616–619 (2014).

Article ADS CAS PubMed Google Scholar

50. Zhang, C. J. & Hu, P. The possibility of single C-H bond activation in  $CH_4$  on a  $MoO_3$ -supported Pt catalyst: a density functional theory study. *J. Chem. Phys.* **116**, 4281–4285 (2002).

Article ADS CAS Google Scholar

51. Zhu, Y.-A., Chen, D., Zhou, X.-G. & Yuan, W.-K. DFT studies of dry reforming of methane on Ni catalyst. *Catal. Today* **148**, 260–267 (2009).

Article CAS Google Scholar

52. Zuo, Z. et al. Dry reforming of methane on single-site Ni/MgO catalysts: importance of site confinement. *ACS Catal.* **8**, 9821–9835 (2018).

### Article CAS Google Scholar

53. Ravel, B. & Newville, M. ATHENA, ARTEMIS, HEPHAESTUS: data analysis for X-ray absorption spectroscopy using IFEFFIT. *J. Synchrotron Radiat.* **12**, 537–541 (2005).

### Article CAS PubMed Google Scholar

54. Kresse, G. & Furthmüller, J. Efficiency of ab-initio total energy calculations for metals and semiconductors using a plane-wave basis set. *Comput. Mater. Sci.* **6**, 15–50 (1996).

### Article CAS Google Scholar

- 55. Kresse, G. & Furthmüller, J. Efficient iterative schemes for ab initio totalenergy calculations using a plane-wave basis set. *Phys. Rev. B Condens. Mater.* **54**, 11169–11186 (1996).
- 56. Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. *Phys. Rev. Lett.* **77**, 3865–3868 (1996).

### Article ADS CAS PubMed Google Scholar

57. Henkelman, G., Uberuaga, B. P. & Jónsson, H. A climbing image nudged elastic band method for finding saddle points and minimum energy paths. *J. Chem. Phys.* **113**, 9901–9904 (2000).

### Article ADS CAS Google Scholar

58. Wang, F. et al. CO<sub>2</sub> reforming with methane over small-sized Ni@SiO<sub>2</sub> catalysts with unique features of sintering-free and low carbon. *Appl. Catal. B* **235**, 26–35 (2018).

### Article CAS Google Scholar

- 59. Li, X. et al. Dry reforming of methane over Ni/La<sub>2</sub>O<sub>3</sub> nanorod catalysts with stabilized Ni nanoparticles. *Appl. Catal. B Environ.* **202**, 683–694 (2017).
- 60. Wang, Y. et al. Low-temperature catalytic  ${\rm CO_2}$  dry reforming of methane on Ni-Si/ZrO $_2$  catalyst. ACS Catal. **8**, 6495–6506 (2018).

Article CAS Google Scholar

#### Download references

### **Acknowledgements**

This paper is dedicated to the 70th anniversary of the Dalian Institute of Chemical Physics, Chinese Academy of Sciences. This work was supported by the National Key R&D Program of China (2016YFA0202801, 2017YFA0700104, and 2017YFA0402800): National Natural Science Foundation of China

(21776270, 21606222, and 51761165012), Strategic Priority Research Program of the Chinese Academy of Sciences (XDB17020000), DNL Cooperation Fund, CAS (DNL180403) and LiaoNing Revitalization Talents Program (XLYC1807068). DFT calculations were supported by Beijing Natural Science Foundation (2184097). J.L. thanks National Program for Thousand Young Talents of China.

# **Author information**

### Author notes

<span id="page-23-1"></span>These authors contributed equally: Mochin Akri and Shu Zhao. 1.

### **Authors and Affiliations**

<span id="page-23-0"></span>CAS Key Laboratory of Science and Technology on Applied Catalysis, Dalian Institute of Chemical Physics, Chinese Academy Sciences, 116023, Dalian, China 1.

Mohcin Akri, Xiaoyu Li, Yuvaraj Gangarajula, Yujing Ren, Yang Su, Xiaoli Pan, Lin Li, Botao Qiao, Aiqin Wang, Xiaodong Wang & Tao Zhang

<span id="page-23-2"></span>Beijing Guyue New Materials Research Institute, Beijing University of Technology, 100124, Beijing, China 2.

Shu Zhao

<span id="page-23-3"></span>University of Chinese Academy of Sciences, 100049, Beijing, China 3.

Xiaoyu Li & Tao Zhang

<span id="page-23-4"></span>Center for Electron Microscopy and Tianjin Key Lab of Advanced Functional Porous Materials, Institute for New Energy Materials, School of Materials Science and Engineering, Tianjin University of Technology, 300384, Tianjin, China 4.

Ketao Zang, Wei Xi & Jun Luo

<span id="page-23-5"></span>Applied Chemistry & Environmental Science, RMIT University, Melbourne, 3000, Australia 5.

Adam F. Lee & Karen Wilson

<span id="page-23-6"></span>Department of Chemistry, University College London, London, UK 6.

Mark A. Isaacs

<span id="page-23-7"></span>Synchrotron Radiation Laboratory, Laser and Synchrotron Research Center (LASOR), The Institute for Solid State Physics, The University of Tokyo, 1-490-2 Kouto, Shingu-cho Tatsuno, Hyogo, 679-5165, Japan 7.

Yi-Tao Cui

<span id="page-24-7"></span>Synchrotron Radiation Research Center, Hyogo Science and Technology Association, Hyogo, 679-5165, Japan 8.

Lei Li

<span id="page-24-8"></span>National Synchrotron Radiation Laboratory, University of Science and Technology of China, Hefei, 230029, China 9.

Wu Wen & Yang Pan

<span id="page-24-9"></span>Dalian National Laboratory for Clean Energy, 116023, Dalian, China 10.

Botao Qiao

<span id="page-24-10"></span>National Synchrotron Radiation Research Center, Hsinchu, 30076, Taiwan (ROC) 11.

Hirofumi Ishii & Yen-Fa Liao

### Authors

<span id="page-24-0"></span>Mohcin Akri [View author publications](file:///search?author=Mohcin%20Akri) 1.

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Mohcin%20Akri) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Mohcin%20Akri%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-24-1"></span>Shu Zhao 2.

[View author publications](file:///search?author=Shu%20Zhao)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Shu%20Zhao) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Shu%20Zhao%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-24-2"></span>Xiaoyu Li 3.

[View author publications](file:///search?author=Xiaoyu%20Li)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Xiaoyu%20Li) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Xiaoyu%20Li%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-24-3"></span>Ketao Zang 4.

[View author publications](file:///search?author=Ketao%20Zang)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Ketao%20Zang) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Ketao%20Zang%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-24-4"></span>Adam F. Lee 5.

[View author publications](file:///search?author=Adam%20F.%20Lee)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Adam%20F.%20Lee) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Adam%20F.%20Lee%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-24-5"></span>Mark A. Isaacs 6.

[View author publications](file:///search?author=Mark%20A.%20Isaacs)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Mark%20A.%20Isaacs) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Mark%20A.%20Isaacs%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-24-6"></span>Wei Xi 7.

[View author publications](file:///search?author=Wei%20Xi)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Wei%20Xi) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Wei%20Xi%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### <span id="page-25-0"></span>Yuvaraj Gangarajula [View author publications](file:///search?author=Yuvaraj%20Gangarajula) 8.

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Yuvaraj%20Gangarajula) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Yuvaraj%20Gangarajula%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### <span id="page-25-1"></span>Jun Luo 9.

[View author publications](file:///search?author=Jun%20Luo)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Jun%20Luo) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Jun%20Luo%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### Yujing Ren 10.

<span id="page-25-2"></span>[View author publications](file:///search?author=Yujing%20Ren)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Yujing%20Ren) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Yujing%20Ren%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### Yi-Tao Cui 11.

<span id="page-25-3"></span>[View author publications](file:///search?author=Yi-Tao%20Cui)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Yi-Tao%20Cui) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Yi-Tao%20Cui%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### Lei Li 12.

<span id="page-25-4"></span>[View author publications](file:///search?author=Lei%20Li)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Lei%20Li) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Lei%20Li%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### Yang Su 13.

<span id="page-25-5"></span>[View author publications](file:///search?author=Yang%20Su)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Yang%20Su) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Yang%20Su%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### Xiaoli Pan 14.

<span id="page-25-6"></span>[View author publications](file:///search?author=Xiaoli%20Pan)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Xiaoli%20Pan) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Xiaoli%20Pan%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### Wu Wen 15.

<span id="page-25-7"></span>[View author publications](file:///search?author=Wu%20Wen)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Wu%20Wen) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Wu%20Wen%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### Yang Pan 16.

<span id="page-25-8"></span>[View author publications](file:///search?author=Yang%20Pan)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Yang%20Pan) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Yang%20Pan%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### Karen Wilson 17.

<span id="page-25-9"></span>[View author publications](file:///search?author=Karen%20Wilson)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Karen%20Wilson) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Karen%20Wilson%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### Lin Li 18.

<span id="page-25-10"></span>[View author publications](file:///search?author=Lin%20Li)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Lin%20Li) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Lin%20Li%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### Botao Qiao 19.

<span id="page-26-0"></span>[View author publications](file:///search?author=Botao%20Qiao)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Botao%20Qiao) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Botao%20Qiao%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### Hirofumi Ishii 20.

<span id="page-26-1"></span>[View author publications](file:///search?author=Hirofumi%20Ishii)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Hirofumi%20Ishii) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Hirofumi%20Ishii%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### Yen-Fa Liao 21.

<span id="page-26-2"></span>[View author publications](file:///search?author=Yen-Fa%20Liao)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Yen-Fa%20Liao) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Yen-Fa%20Liao%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### Aiqin Wang 22.

<span id="page-26-3"></span>[View author publications](file:///search?author=Aiqin%20Wang)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Aiqin%20Wang) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Aiqin%20Wang%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### Xiaodong Wang 23.

<span id="page-26-4"></span>[View author publications](file:///search?author=Xiaodong%20Wang)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Xiaodong%20Wang) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Xiaodong%20Wang%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### Tao Zhang 24.

<span id="page-26-5"></span>[View author publications](file:///search?author=Tao%20Zhang)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Tao%20Zhang) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Tao%20Zhang%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

### **Contributions**

M.A. performed the catalyst preparation, catalytic tests, and routine characterizations. S.Z. performed the DFT calculations. K.Z., W.X., and J.L. performed AC HAADF-STEM measurements. Y.S., X.P., X.L., and Lin.L. performed HRTEM measurements. A.F.L., M.A.I., and K.W. conducted in situ XPS measurements and data analysis. Y.R., Y.C., Lei.L., H.I., and Y.L. performed the EXAFS measurement and corresponding data analysis. W.W., Y.G., and Y.P. performed the MS detection. B.Q., A.W., X.W., and T.Z. designed the study, analyzed the data, and co-wrote the paper with input from A.F.L. All the authors discussed the results and commented on the manuscript and contributed to writing the STEM sections.

### **Corresponding authors**

Correspondence to [Botao Qiao](mailto:bqiao@dicp.ac.cn) or [Tao Zhang](mailto:taozhang@dicp.ac.cn).

# **Ethics declarations**

### **Competing interests**

The authors declare no competing interests.

# **Additional information**

**Peer review information** Nature Communications thank Changwei Hu and other anonymous reviewers for their contributions to the peer review of this work. Peer review reports are available.

**Publisher's note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

# **Supplementary information**

**[Peer Review File](https://static-content.springer.com/esm/art%3A10.1038%2Fs41467-019-12843-w/MediaObjects/41467_2019_12843_MOESM1_ESM.pdf)**

**[Supplementary material](https://static-content.springer.com/esm/art%3A10.1038%2Fs41467-019-12843-w/MediaObjects/41467_2019_12843_MOESM2_ESM.pdf)**

## **Rights and permissions**

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article's Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article's Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit [http://creativecommons.org/](http://creativecommons.org/licenses/by/4.0/) [licenses/by/4.0/](http://creativecommons.org/licenses/by/4.0/).

[Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?title=Atomically%20dispersed%20nickel%20as%20coke-resistant%20active%20sites%20for%20methane%20dry%20reforming&author=Mohcin%20Akri%20et%20al&contentID=10.1038%2Fs41467-019-12843-w©right=The%20Author%28s%29&publication=2041-1723&publicationDate=2019-11-15&publisherName=SpringerNature&orderBeanReset=true&oa=CC%20BY)

# **About this article**

![](_page_27_Picture_10.jpeg)

### <span id="page-27-0"></span>**Cite this article**

Akri, M., Zhao, S., Li, X. et al. Atomically dispersed nickel as coke-resistant active sites for methane dry reforming. Nat Commun **10**, 5181 (2019). https://doi.org/10.1038/s41467-019-12843-w

### [Download citation](https://citation-needed.springer.com/v2/references/10.1038/s41467-019-12843-w?format=refman&flavour=citation)

• Received: 18 April 2019

- Accepted: 01 October 2019 •
- Published: 15 November 2019 •
- DOI: https://doi.org/10.1038/s41467-019-12843-w •

## **This article is cited by**

- **[Concerted catalysis of single atom and nanocluster](https://doi.org/10.1038/s41467-025-59127-0) [enhances bio-ethanol activation and dehydrogenation](https://doi.org/10.1038/s41467-025-59127-0)**  •
  - Zhao Sun ◦
  - Weizhi Shi ◦
  - Graham J. Hutchings ◦

Nature Communications (2025)

- **[Effect of Rare Earth Metal Oxides \(CeO2, La2O3\) on the](https://doi.org/10.1007/s11237-025-09853-9) [Properties of NI-AL2O3 Catalysts for Biogas Reforming](https://doi.org/10.1007/s11237-025-09853-9)**  •
  - S. O. Soloviev ◦
  - Ya.P. Kurilets ◦
  - Y. M. Nychiporuk ◦

Theoretical and Experimental Chemistry (2025)

- **[Unveiling the dynamic structure evolution of](https://doi.org/10.1007/s40843-024-3308-x) [In2O3\(110\) in the direct oxidation of methane to](https://doi.org/10.1007/s40843-024-3308-x) [methanol](https://doi.org/10.1007/s40843-024-3308-x)**  •
  - Yanjun Chen ◦
  - Mengyao Sun ◦
  - Zhen Zhao ◦

Science China Materials (2025)

- **[Single-atom nanozymes shines diagnostics of](https://doi.org/10.1186/s12951-024-02569-3) [gastrointestinal diseases](https://doi.org/10.1186/s12951-024-02569-3)**  •
  - Sijia Hua ◦
  - Xiulin Dong ◦
  - Jianfeng Yang ◦

Journal of Nanobiotechnology (2024)

- **[Simultaneous production of syngas and carbon](https://doi.org/10.1038/s41598-024-66938-6) [nanotubes from CO2/CH4 mixture over high](https://doi.org/10.1038/s41598-024-66938-6)[performance NiMo/MgO catalyst](https://doi.org/10.1038/s41598-024-66938-6)**  •
  - Nonthicha Sae-tang ◦

- Supanida Saconsint ◦
- Sakhon Ratchahat ◦

Scientific Reports (2024)

[Download PDF](file:///articles/s41467-019-12843-w.pdf)

# **Associated content**

Collection

### **[Top 50 Chemistry and Materials Sciences Articles](https://www.nature.com/collections/giacagiaca)**

Advertisement

[Advertisement](file://pubads.g.doubleclick.net/gampad/jump?iu=/285/nature_communications/article&sz=300x250&c=-231562755&t=pos%3Dright%26type%3Darticle%26artid%3Ds41467-019-12843-w%26doi%3D10.1038/s41467-019-12843-w%26techmeta%3D118,119,128,133,137,139,140,145,146,147%26subjmeta%3D299,301,357,638,639,77,884,887,925%26kwrd%3DCatalyst+synthesis,Heterogeneous+catalysis,Materials+for+energy+and+catalysis,Nanoscale+materials)

### <span id="page-29-0"></span>**Explore content**

- [Research articles](file:///ncomms/research-articles) •
- [Reviews & Analysis](file:///ncomms/reviews-and-analysis)  •
- [News & Comment](file:///ncomms/news-and-comment) •
- [Videos](file:///ncomms/video) •
- [Collections](file:///ncomms/collections)  •
- [Subjects](file:///ncomms/browse-subjects) •
- [Follow us on Facebook](https://www.facebook.com/NatureCommunications)  •
- [Follow us on Twitter](https://twitter.com/NatureComms) •
- [Sign up for alerts](https://journal-alerts.springernature.com/subscribe?journal_id=41467) •
- [RSS feed](https://www.nature.com/ncomms.rss) •

# <span id="page-29-1"></span>**About the journal**

- [Aims & Scope](file:///ncomms/aims) •
- [Editors](file:///ncomms/editors) •
- [Journal Information](file:///ncomms/journal-information) •
- [Open Access Fees and Funding](file:///ncomms/open-access) •
- [Calls for Papers](file:///ncomms/calls-for-papers) •
- [Editorial Values Statement](file:///ncomms/editorial-values-statement)  •
- [Journal Metrics](file:///ncomms/journal-impact) •
- [Editors' Highlights](file:///ncomms/editorshighlights)  •
- [Contact](file:///ncomms/contact)  •
- [Editorial policies](file:///ncomms/editorial-policies)  •
- [Top Articles](file:///ncomms/top-articles) •

# <span id="page-29-2"></span>**Publish with us**

- [For authors](file:///ncomms/submit)  •
- [For Reviewers](file:///ncomms/for-reviewers) •

- [Language editing services](https://authorservices.springernature.com/go/sn/?utm_source=For+Authors&utm_medium=Website_Nature&utm_campaign=Platform+Experimentation+2022&utm_id=PE2022)  •
- [Open access funding](file:///ncomms/open-access-funding) •
- [Submit manuscript](https://mts-ncomms.nature.com/) •

# <span id="page-30-0"></span>**Search**

Search articles by subject, keyword or author Show results from All journals ˅

Search

[Advanced search](file:///search/advanced)

### **Quick links**

- [Explore articles by subject](file:///subjects) •
- [Find a job](file:///naturecareers) •
- [Guide to authors](file:///authors/index.html) •
- [Editorial policies](file:///authors/editorial_policies/) •

Nature Communications (Nat Commun)

ISSN 2041-1723 (online)

### **nature.com sitemap**

### **About Nature Portfolio**

- [About us](https://www.nature.com/npg_/company_info/index.html) •
- [Press releases](https://www.nature.com/npg_/press_room/press_releases.html) •
- [Press office](https://press.nature.com/) •
- [Contact us](https://support.nature.com/support/home) •

### **Discover content**

- [Journals A-Z](https://www.nature.com/siteindex) •
- [Articles by subject](https://www.nature.com/subjects) •
- [protocols.io](https://www.protocols.io/) •
- [Nature Index](https://www.natureindex.com/) •

### **Publishing policies**

- [Nature portfolio policies](https://www.nature.com/authors/editorial_policies) •
- [Open access](https://www.nature.com/nature-research/open-access) •

### **Author & Researcher services**

- [Reprints & permissions](https://www.nature.com/reprints) •
- [Research data](https://www.springernature.com/gp/authors/research-data) •
- [Language editing](https://authorservices.springernature.com/language-editing/) •

- [Scientific editing](https://authorservices.springernature.com/scientific-editing/) •
- [Nature Masterclasses](https://masterclasses.nature.com/) •
- [Research Solutions](https://solutions.springernature.com/) •

### **Libraries & institutions**

- [Librarian service & tools](https://www.springernature.com/gp/librarians/tools-services) •
- [Librarian portal](https://www.springernature.com/gp/librarians/manage-your-account/librarianportal) •
- [Open research](https://www.nature.com/openresearch/about-open-access/information-for-institutions) •
- [Recommend to library](https://www.springernature.com/gp/librarians/recommend-to-your-library) •

### **Advertising & partnerships**

- [Advertising](https://partnerships.nature.com/product/digital-advertising/) •
- [Partnerships & Services](https://partnerships.nature.com/) •
- [Media kits](https://partnerships.nature.com/media-kits/) •
- [Branded content](https://partnerships.nature.com/product/branded-content-native-advertising/) •

### **Professional development**

- [Nature Awards](https://www.nature.com/immersive/natureawards/index.html) •
- [Nature Careers](https://www.nature.com/naturecareers/) •
- Nature [Conferences](https://conferences.nature.com) •

### **Regional websites**

- [Nature Africa](https://www.nature.com/natafrica) •
- [Nature China](http://www.naturechina.com) •
- [Nature India](https://www.nature.com/nindia) •
- [Nature Japan](https://www.natureasia.com/ja-jp) •
- [Nature Middle East](https://www.nature.com/nmiddleeast) •
- [Privacy Policy](https://www.nature.com/info/privacy) •
- [Use of cookies](https://www.nature.com/info/cookies) •
- Your privacy choices/Manage cookies •
- [Legal notice](https://www.nature.com/info/legal-notice) •
- [Accessibility statement](https://www.nature.com/info/accessibility-statement) •
- [Terms & Conditions](https://www.nature.com/info/terms-and-conditions) •
- [Your US state privacy rights](https://www.springernature.com/ccpa) •

### [Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature Limited

| Close                                   |                                                                               |
|-----------------------------------------|-------------------------------------------------------------------------------|
| Nature Briefing                         |                                                                               |
| your inbox daily.                       | Sign up for the Nature Briefing newsletter — what matters in science, free to |
| MainBriefingBanner                      |                                                                               |
| DirectEmailBanner                       |                                                                               |
| false                                   |                                                                               |
| false                                   |                                                                               |
| false                                   |                                                                               |
| MainBriefingBanner                      |                                                                               |
| Email address                           |                                                                               |
| true<br>Sign up                         |                                                                               |
| Springer Nature Limited Privacy Policy. | I agree my information will be processed in accordance with the Nature and    |

Get the most important science stories of the day, free in your inbox. [Sign up](https://www.nature.com/briefing/signup/?brieferEntryPoint=MainBriefingBanner)

Close

[for Nature Briefing](https://www.nature.com/briefing/signup/?brieferEntryPoint=MainBriefingBanner)