pubs.acs.org/JPCC

# Morphology Dependence of Catalytic Properties of Ni/CeO<sub>2</sub> Nanostructures for Carbon Dioxide Reforming of Methane

Xianjun Du, Dengsong Zhang,\* Liyi Shi, Ruihua Gao, and Jianping Zhang

Research Center of Nano Science and Technology, Department of Chemistry, Shanghai University, Shanghai 200444, China

Supporting Information

ABSTRACT: The comparative catalytic activity and coke resistance are examined in carbon dioxide reforming of methane over Ni/CeO2 nanorods (NR) and nanopolyhedra (NP). The Ni/CeO<sub>2</sub>-NR catalysts display more excellent catalytic activity and higher coke resistance compared with the Ni/CeO2-NP. The high resolution transmission electron microscope reveals that the predominantly exposed planes are the unusually reactive {110} and {100} planes on the CeO<sub>2</sub>-NR rather than the stable  $\{111\}$  one on the CeO<sub>2</sub>-NP. The prepared samples were also characterized by X-ray diffraction,

![](_page_0_Figure_9.jpeg)

transmission electron microscopy, hydrogen temperature-programmed reduction, X-ray photoelectron spectroscopy, UV and visible Raman spectra, and oxygen temperature-programmed oxidation. The {110} and {100} planes show great superiority for the anchoring of Ni nanoparticles, which results in the existence of strong metal-support interaction effect (SMSI). The SMSI effect can be helpful to prevent sintering of Ni particles, which benefits to reduce the deactivation of catalytic activity. Besides, the oxygen vacancies and the mobility of lattice oxygen also show the morphology dependence. They can participate into the catalytic reaction and be beneficial to the activation of carbon deposition. In conclusion, the excellent catalytic activity and coke resistance of the Ni/CeO2-NR should be attributed to the SMSI effect and abundant oxygen vacancies.

### 1. INTRODUCTION

Syngas, a gas mixture that contains carbon monoxide and hydrogen, can be used as fuel or an intermediate in the production of other chemicals. There are three major processes for producing syngas via the conversion of methane: steam reforming, partial oxidation, and carbon dioxide reforming. 1-5 Carbon dioxide reforming of methane can produce the low  $H_2$ / CO ratio syngas, which is more desirable for the subsequent chemical synthesis. Besides, the comprehensive utilization of carbon dioxide and methane can not only reduce greenhouse gases and protect environment, but also bring considerable economic benefits. So the CO2 reforming of methane reaction has attracted much attention in recent years. 6-8 At present, the catalysts for carbon dioxide reforming of methane mainly consist of supported noble metal catalysts and Fe-, Co-, and Nibased catalysts. 9 Though the supported noble metal catalysts have the high catalytic activity, selectivity, stability, and excellent carbon deposit resistance, they are unlikely to be largely used in industrial applications due to their high cost. By contrast, non-noble metal based catalysts, especially Ni-based catalysts, have been expected to be the extensively used catalysts in industry as a result of their high catalytic activity, low cost, and extensive availability. However, the Ni-based catalysts tend to deactivate after a long-term catalytic process because of carbon deposition and sintering of nickel particles. 10 Therefore, how to improve the resistance of carbon deposition and prevent the sintering of nickel particles is still a hot topic in the CO<sub>2</sub> reforming of methane catalytic reactions.

As one of the most important rare earth oxides, ceria can uptake and release oxygen via the transformation between Ce<sup>3+</sup> and Ce4+, thus it can be widely used as active component or support in many catalytic reactions. 11 Previously, many lowdimension ceria nanomaterials, such as ceria nanorods (NR), nanopolyhedra (NP), nanocubes, nanotubes, and so on, have been synthesized by us and other research groups. 12-14 Generally, different ceria shapes may expose different lattice planes in CeO2 crystal structure. For example, the CeO2-NR tends to preferentially expose four  $\{110\}$  and two  $\{100\}$  planes, while the  $CeO_2$ -NP exposes eight {111} planes or eight {111} and six {110} planes. <sup>12</sup> On the basis of density functional theory, 15-17 the formation energy of oxygen vacancy on the different planes follows the sequence  $\{110\} < \{100\} < \{111\}$ , while the chemical activity of these planes follows the opposite sequence. So far there are many publications about the shape effects of ceria in CO oxidation, water-gas shift reaction,<sup>22,23</sup> and NO reduction by CO.<sup>24</sup> Typically, Wu et al.20 studied the surface structure dependence of CO oxidation over CeO<sub>2</sub> nanomaterials with well-defined planes and the results showed that carbonate species are more strongly bonded on {110} and {100} after the CO absorbed on ceria. The majority of carbonate species are possibly the reaction intermediates in CO oxidation, so the CeO2-NR displays an

Received: January 17, 2012 Revised: April 19, 2012 Published: April 19, 2012

excellent catalytic activity in the CO oxidation. Similarly, Huang et al. <sup>19</sup> found that  $Au/CeO_2-NR$  has a remarkable low-temperature activity for CO oxidation compared with the Au-ceria nanoparticles. They attributed the superiority to the influence of surface structure and morphology of ceria. Specifically, the active planes favor the high dispersion of Au nanoclusters, which results in the strong metal-support interaction (SMSI) between Au and ceria support. Liu et al. <sup>24</sup> discussed NO reduction by CO on CuO-supported different  $CeO_2$  nanoshapes and owed the different reactive activities to the intensity of interaction between CuO and  $CeO_2$  supports.

Previous reports revealed that Ni/CeO2 catalysts also exhibited an excellent catalytic performance in the CO<sub>2</sub> reforming of methane reaction. <sup>25–28</sup> However, until recently, few papers focused on the morphology dependence of ceria nanomaterials in Ni-based CeO2 for carbon dioxide reforming of methane. Moreover, ceria supports with different morphologies may exhibit different oxygen mobility and intensity of interaction with active metal particles, <sup>29,30</sup> which can influence the gasification of deposited carbon species and thermal sintering of nickel particles. On the basis of these ideas, Ni species were deposited on the CeO<sub>2</sub>-NR and CeO<sub>2</sub>-NP by an impregnation method. The catalytic activity of the Ni/CeO<sub>2</sub> nanomaterials was examined in CO2 reforming of methane. The possible morphology effects were elucidated in accordance with studies of X-ray diffraction (XRD), transmission electron microscopy (TEM), X-ray photoelectron spectroscopy (XPS), Raman spectra, hydrogen temperature-programmed reduction (H<sub>2</sub>-TPR), and temperature-programmed oxidation (TPO).

# 2. EXPERIMENT SECTION

**2.1. Synthesis of Ni/CeO<sub>2</sub> Nanomaterials.** All the chemicals were purchased from Sinopharm Chemical Regent Company and were used without further purification.

The CeO<sub>2</sub>–NR and CeO<sub>2</sub>–NP were synthesized by a hydrothermal method varying the amount of reactants and the hydrothermal temperature.<sup>12</sup> Typically, 1.74 g of Ce-(NO<sub>3</sub>)<sub>3</sub>·6H<sub>2</sub>O and an appropriate amount of NaOH (19.2 g for NR, 0.32 g for NP) were dissolved in 40 mL of distilled water, respectively. The solution was mixed together and kept stirring for 30 min. The mixture was then transferred to a stainless steel autoclave with PTFE lining (100 mL) and maintained at an appropriate temperature (100 °C for NR, 180 °C for NP) for 24 h. After the autoclave was cooled to room temperature naturally, the resulting slurry was collected by centrifugation, washed with water and ethanol, and then dried at 80 °C for 12 h. Finally the resulting powders were calcined at 400 °C for 5 h in air.

The catalysts were prepared by the impregnation method: 0.1304 g of  $Ni(NO_3)_2$ · $6H_2O$  was dissolved into 5 mL of distilled water, then  $CeO_2$  nanomaterials (0.5 g) were impregnated into the solution. After being stirred for 3 h at 60 °C, the mixture was transferred into an oven at 80 °C. The obtained samples were calcined at 400 °C for 90 min. The calcined materials in the form of  $NiO/CeO_2$  were reduced in a mixture of 10% H<sub>2</sub> and 90% N<sub>2</sub> before the catalytic test. The  $NiO/CeO_2$  materials were put into a quartz tube, heated from room temperature to 600 °C with a rate of 3 deg/min, and kept at 600 °C for 1 h. Finally, the mixture gas was withdrawn until the temperature cooled naturally to room temperature. The  $Ni/CeO_2$  nanomaterials were obtained with a nickel content of 5 wt %.

**2.2. Catalyst Characterization.** The XRD measurements were performed with a Rigaku D/MAX-RB X-ray diffractometer by using Cu K $\alpha$  (40 kV, 40 mA) radiation and a secondary beam graphite monochromator. The morphologies were observed by a TEM (JEOL JEM-200CX) and a HRTEM (JEOL JEM-2010F). The surface composition and chemical states were examined by XPS on a PHI-5000C ESCA system (Perkin-Elmer) with Mg K $\alpha$  radiation. The binding energies were calibrated by using the containment carbon (C1s = 284.6 eV). The data analysis was carried out by using the RBD AugerScan 3.21 software. The surface and bulk defects were justified by UV ( $\lambda_{\rm ex}$  = 325 nm) and visible ( $\lambda_{\rm ex}$  = 514 nm) Raman spectra, respectively. They were carried out on a Jobin Yvon HR 800 Raman spectrometer.

The  $\rm H_2$ -TPR measurements were carried out in a quartz tube reactor equipped with a thermal conductivity detector (TCD). First of all, NiO/CeO<sub>2</sub> catalysts (0.10 g) were pretreated at 300 °C for 30 min in a flowing stream of high-purity nitrogen. After cooling to room temperature, a 10%  $\rm H_2$  of  $\rm N_2$  gas mixture (30 mL/min) was introduced and the programing temperature was controlled from room temperature to 700 °C with a rate of 10 deg/min. The TPO measurements were carried out with the same procedure of  $\rm H_2$ -TPR. The difference was that the amount of the used Ni/CeO<sub>2</sub> catalysts was 20 mg and a 10% O<sub>2</sub> of N<sub>2</sub> gas mixture was applied.

**2.3. Catalyst Evaluation.** The  $CO_2$  reforming of methane reactions was carried out in a fixed bed reactor with a quartz tube (inner diameter of 8 mm). The quartz tube was loosely filled with 0.10 g of Ni/CeO<sub>2</sub> catalysts and fed a mixture of  $CH_4$  and  $CO_2$  ( $CH_4$ : $CO_2$  = 1:1, 15 mL/min per reactor). The catalytic tests were carried out from 450 to 800 °C with a heating rate of 5 deg/min. The effluent product gases were cooled in an ice—water bath and analyzed by online gas chromatography with a TCD, using a TDX-01 packed column. The durability tests were also carried out at 700 °C for 30 h.

# 3. RESULT AND DISCUSSION

**3.1. Morphology and Structure.** The XRD patterns of assynthesized materials (Figure 1) show the existence of the distinct fluorite-type oxide structure of  $CeO_2$  (JCPDS 34–0394, space group Fm3m). The diffraction peaks at  $28.5^{\circ}$ ,  $33.1^{\circ}$ ,  $47.5^{\circ}$ ,  $56.3^{\circ}$ ,  $59.1^{\circ}$ ,  $69.4^{\circ}$ ,  $76.7^{\circ}$ , and  $79.1^{\circ}$  can be attributed to (111), (200), (220), (311), (222), (400), (331), (420), and (422) of the face-centered cubic (fcc) structure, respectively. Besides, very weak diffraction peaks of Ni crystallite phase can

![](_page_1_Figure_13.jpeg)

Figure 1. XRD patterns of  $CeO_2$ -NR (a),  $CeO_2$ -NP (b), Ni/CeO<sub>2</sub>-NR (c), and Ni/CeO<sub>2</sub>-NP (d).

be observed after the deposition of Ni, which may suggest a good dispersion of Ni on both of the  $CeO_2$  nanomaterials. Because Ni crystallite phase peaks are weak and close to the background noise, it is not possible to determine their crystallite size based on the Scherrer formula.

The TEM images in Figure 2a,b show that two different CeO<sub>2</sub> nanomaterials maintain their original crystal shapes after

![](_page_2_Figure_4.jpeg)

**Figure 2.** TEM images of Ni/CeO<sub>2</sub>–NR (a) and Ni/CeO<sub>2</sub>–NP (b); HRTEM images of Ni/CeO<sub>2</sub>–NR (c) and Ni/CeO<sub>2</sub>–NP (d); and EDS patterns (e) of the red circle region in panels c and d, respectively.

the deposition of Ni. The Ni/CeO<sub>2</sub>–NR has a uniform diameter in  $(13 \pm 3.2)$  nm and a less-uniform length within 30-100 nm while the Ni/CeO<sub>2</sub>–NP has a size of  $(10.3 \pm 2.1)$  nm. The HRTEM images (Figure 2c,d) of Ni/CeO<sub>2</sub> nanomaterials show that the Ni/CeO<sub>2</sub>–NR exposes the well-defined  $\{100\}$  and  $\{110\}$  planes and the Ni/CeO<sub>2</sub>–NP exposes  $\{111\}$ 

and {100} planes. Besides, the HRTEM image of the Ni/ CeO<sub>2</sub>-NR does not reveal the evidence of Ni nanoparticles. Whereas, the image is not consistent in brightness and some bright spots can be found on the surface. The EDS spectra of region 1 also confirm the presence of Ni element, which suggests Ni species anchor on the surface. However, on the Ni/ CeO<sub>2</sub>-NP, about 10 nm Ni particles with exposed {111} planes can be found in the HRTEM image. Besides, the EDS spectra of region 2 also confirm the existence of Ni element and the surface of region 2 is smooth. According to the previous literature, 31,32 an SMSI effect should be responsible for the disappearance of Ni nanoparticles on the Ni/CeO<sub>2</sub>-NR. Oxygen vacancies are important for anchoring of metal particles<sup>33</sup> and the CeO<sub>2</sub>-NR has more oxygen vacancies, so the SMSI effect exists between the Ni and the CeO2-NR. A part of the CeO<sub>2</sub> substrate would be reduced because of hydrogen spillover and it covers the Ni particles at the same time, which would appear again on the surface after the evacuation of the  $H_2$  stream. These can account for why the surface of CeO2-NR is rough. However, on the CeO2-NP, some part of Ni particles may enter into the CeO<sub>2</sub> crystal,<sup>34</sup> so the surface of region 2 is smooth.

**3.2. Surface Oxygen Vacancies.** The XPS analysis is performed to clarify the surface composition and chemical states. The Ce 3d electron core level XPS spectra of CeO<sub>2</sub> and Ni/CeO<sub>2</sub> nanomaterials are shown in Figure 3. The labels are

![](_page_2_Figure_9.jpeg)

Figure 3. Ce 3d XPS patterns of  $CeO_2$ -NR (a),  $CeO_2$ -NP (b), Ni/ $CeO_2$ -NR (c), and Ni/ $CeO_2$ -NP (d).

used to identify Ce 3d peaks in Figure 3, where "v" and "u" indicate the spin—orbit coupling 3d3/2 and 3d5/2, respectively. The peaks referred to as u (~880.6 eV), u" (~884.4 eV), v (~899.3 eV), and v" (~903.9 eV) are assigned to Ce³+ and the other six peaks (u': ~882.2 eV; u'': ~888.6 eV, u''': ~898 eV; v': ~900.7 eV; v''' ~907.2 eV; v''': ~916.2 eV) represent the presence of Ce⁴+. The surface Ce³+ concentration of total Ce on the CeO₂–NR and CeO₂–NP is 10.8% and 6.9%, respectively; while that of the Ni/CeO₂–NR and Ni/CeO₂–NP is 27.6% and 12%, respectively.

Oxygen vacancies can be produced via the transformation between  $Ce^{3+}$  and  $Ce^{4+}$ ,  $4Ce^{4+} + O^{2-} \rightarrow 4Ce^{4+} + 2e^{-}/\square + 0.5O_2 \rightarrow 2Ce^{4+} + 2Ce^{3+} + \square + 0.5O_2$ , (where " $\square$ " represents an empty position).<sup>36</sup> The higher  $Ce^{3+}$  concentration of total Ce that exists, the more oxygen vacancies form. On the basis of density-functional theory calculations, <sup>16,37,38</sup> oxygen vacancies are more likely to be formed on the  $CeO_2$ –NR. After the

<span id="page-3-0"></span>deposition of Ni particles on CeO<sub>2</sub> supports, the Ce<sup>3+</sup> concentration increases significantly. It can be explained that the SMSI effects change the surface electronic states.<sup>39</sup> The existence of Ni particles weakens the bond energy between Ni particles and oxygen atoms closed to Ni particles in the CeO<sub>2</sub> crystal lattice, which makes this kind of oxygen atom more easily to be reduced, so the number of oxygen vacancies increases. Moreover, the SMSI effects and active planes make the surface oxygen atoms of the CeO<sub>2</sub>–NR easy to reduce, which can be used to explain why the number of increased oxygen vacancies on the Ni/CeO<sub>2</sub>–NR is more than that of the Ni/CeO<sub>2</sub>–NP.

**3.3. Bulk and Surface Defects.** The Raman spectra are applied to clarify the bulk and surface defects. Figure 4 displays

![](_page_3_Figure_4.jpeg)

Figure 4. Visible (A) and UV (B) Raman spectra of  $CeO_2$ -NR (a),  $CeO_2$ -NP (b),  $Ni/CeO_2$ -NR (c), and  $Ni/CeO_2$ -NP (d).

Raman shift (cm<sup>-1</sup>)

800

1000

1200

600

200

400

the visible (514 nm) and UV (325 nm) Raman spectra of  $CeO_2$  and  $Ni/CeO_2$  nanomaterials. A distinct  $F_{2g}$  symmetry mode of  $CeO_2$  phase centered at about 462 cm<sup>-1</sup> can be found in the visible Raman spectra of  $CeO_2$  nanometrials (Figure 4A). The shift to 448 cm<sup>-1</sup> of this mode on  $Ni/CeO_2$  nanomaterials indicates that the presence of Ni lowers the symmetry of the Ce-O bond.

Figure 4B shows the UV Raman spectra of the samples under an excitation wavelength of 325 nm. The Raman shifts at 460, 588, and 1180 cm $^{-1}$  belong to the  $\rm F_{2g}$  symmetry mode, defect-induced mode (D bond), and second-order longitudinal optical mode (2LO bond), respectively. The relative intensity ratio of  $\rm I_D/\rm I_{F_{2g}}$  implies the degree of defect sites on CeO<sub>2</sub>. The intensity ratio follows the sequence Ni/CeO<sub>2</sub>–NP > Ni/CeO<sub>2</sub>–NR > CeO<sub>2</sub>–NR > CeO<sub>2</sub>–NP. We consider that the surface defects of Ni/CeO<sub>2</sub> nanomaterials mainly result from

the increase of oxygen vacancies after the deposition of Ni. Besides, the Ce–Ni–O bond can be found at about 566 cm $^{-1}$  on the Ni/CeO $_2$ –NP. $^{42}$  So, although relatively few oxygen vacancies exist on the Ni/CeO $_2$ –NP, the degree of defects is higher than that of the Ni/CeO $_2$ –NR due to the formation of more Ce $_{1-x}$ Ni $_x$ O $_2$  solid solution.  $^{43}$ 

**3.4. Redox Properties of NiO/CeO<sub>2</sub>.** To clarify the NiO species on the CeO<sub>2</sub> supports after the impregnation, the H<sub>2</sub>-TPR measurements are also performed (Figure 5). Obviously,

![](_page_3_Figure_10.jpeg)

Figure 5.  $H_2$ -TPR profiles of NiO/CeO $_2$ -NR (a) and NiO/CeO $_2$ -NP (b).

both of the profiles have two peaks. The first reduction peak ranging from 265 to 285 °C is due to the reduction of weakly interactive NiO species with CeO<sub>2</sub> supports. The second peak at 360-380 °C can be attributed to the reduction of strongly interactive NiO species with CeO<sub>2</sub> supports.<sup>44</sup> The second reduction peak of the NiO/CeO<sub>2</sub>-NP is at 365 °C, while the peak of NiO/CeO<sub>2</sub>-NR shifts to 375 °C, indicating a stronger interaction between NiO and the CeO<sub>2</sub>-NR. Besides, the H<sub>2</sub> consumption of the second peak on the NiO/CeO2-NR is more than on the NiO/CeO2-NP, which suggests a larger number of stronger interactive NiO species exist on the CeO<sub>2</sub>-NR. Shan et al. divided the NiO species on Ce<sub>1-x</sub>Ni<sub>x</sub>O<sub>2</sub> catalysts into three types:<sup>45</sup> aggregated NiO species, highly dispersed NiO with strong interaction with CeO2, and Ni incorporated into CeO2 lattice. However, the third type of Ni species is difficult to reduce, so the peaks that belong to the third Ni species do not appear in the profiles. The first two types have been displayed in the profiles. If the two profiles of H<sub>2</sub>-TPR are overlayed, we will find the peak area of the NiO/  $CeO_2$ -NR is far greater than that of the NiO/CeO<sub>2</sub>-NP. Considering that the total amount of Ni deposited is kept the same (5%), we think that the NiO/CeO<sub>2</sub>-NP has more Ce<sub>1-x</sub>Ni<sub>x</sub>O<sub>2</sub> solid solution than the NiO/CeO<sub>2</sub>-NR. This result is in accordance with TEM images and Raman spectra.

**3.5.** Ni Species. Ni element analysis of Ni/CeO<sub>2</sub> nanomaterials from the XPS analysis is also given in Table 1. The surface Ni content of the Ni/CeO<sub>2</sub>–NR is 7.4%, which is higher than the theoretical one (5%), indicating that Ni particles tend to disperse on the surface. While the surface Ni content of the Ni/CeO<sub>2</sub>–NP is 4.3%, which suggests the Ni particles are mainly dispersed into the bulk phases. The exposed {110} and {100} planes of the Ni/CeO<sub>2</sub>–NR have more oxygen vacancies and higher oxygen mobility, so Ni particles tend to be dispersed near the oxygen vacancies on the surface of the Ni/CeO<sub>2</sub>–NR. The oxygen vacancies on {111}

b

1600

<span id="page-4-0"></span>Table 1. Surface Chemical and States Based on XPS Analysis

|                                 |                                               |                                 | composition of Ni (%)          |                                 |
|---------------------------------|-----------------------------------------------|---------------------------------|--------------------------------|---------------------------------|
|                                 | surface content of<br>Ce <sup>3+</sup> (wt %) | surface content of<br>Ni (wt %) | 852.6 eV<br>(Ni <sup>0</sup> ) | 855.5 eV<br>(Ni <sup>2+</sup> ) |
| Ni/<br>CeO <sub>2</sub> -<br>NR | 27.6                                          | 7.4                             | 37.1                           | 62.9                            |
| Ni/<br>CeO <sub>2</sub> –<br>NP | 12                                            | 4.3                             | 22.8                           | 77.2                            |
| CeO <sub>2</sub> –<br>NR        | 10.8                                          |                                 |                                |                                 |
| CeO <sub>2</sub> –<br>NP        | 6.9                                           |                                 |                                |                                 |

planes are immobile at room temperature, but these oxygen vacancies will aggregate in line at a higher temperature.  $^{46,47}$  Consequently, some very small NiO particles have the chance to enter the inside of the  $CeO_2$  crystal lattice, leading to the formation of  $Ce_{1-x}Ni_xO_2$  solid solution. The data of Ni species composition and their content are also obtained (Table 1). The binding energy at about 852.6 eV represents the existence of metal Ni, while that at about 855.5 eV is assigned to an oxidation state close to  $Ni^{2+}$ . The content of metal Ni of the  $CeO_2$ -NR is higher than that of the  $CeO_2$ -NP. This is mainly because the formed  $Ce_{1-x}Ni_xO_2$  solid solution is difficult to reduce. After the reduction of the  $NiO/CeO_2$  with  $H_2$ , Ni species exist in three types: aggregated Ni particles, highly dispersed Ni species with strong interaction with  $CeO_2$ , and Ni

incorporated into  $CeO_2$  lattice. As discussed above, the Ni species on the Ni/CeO<sub>2</sub>–NR exist mainly as the highly dispersed Ni with an SMSI effect. The main form of Ni species on the Ni/CeO<sub>2</sub>–NP is the third type Ni incorporated into the CeO<sub>2</sub> lattice.

**3.6. Catalytic Performance.** The catalytic activity of Ni/CeO<sub>2</sub> is tested in carbon dioxide reforming of methane. As shown in Figure 6a,b, both of the Ni/CeO<sub>2</sub> catalysts display more excellent catalytic performance than the Ni/commercial CeO<sub>2</sub>. This performance is caused by the surface effects and small size effects of nanocrystalline. The comparison of the conversion reveals that the two Ni/CeO<sub>2</sub> catalysts display similar conversion of methane below 550 °C, but the Ni/CeO<sub>2</sub>–NR shows higher conversion of methane than the Ni/CeO<sub>2</sub>–NP at 550–750 °C (Figure 6a). The conversion of carbon dioxide on the Ni/CeO<sub>2</sub>–NR is higher than that of the Ni/CeO<sub>2</sub>–NP at 450 –750 °C (Figure 6b).

At a relatively lower temperature range (450-550 °C), the conversion of methane is mainly from its dissociation on active metal nickel particles, which may not be covered by carbon deposition at the initial reaction time, so the conversion of methane performs similarly at this temperature range. As the temperature increases, the oxygen mobility enhances and the lattice oxygen atoms are also involved in the conversion of methane, so the Ni/CeO<sub>2</sub>–NR has higher conversion of methane at 550-750 °C. However, the conversion of carbon dioxide has two ways: one is the conversion of CO<sub>2</sub> adsorbed on Ni particles; the other is the dissociation of CO<sub>2</sub> adsorbed on oxygen vacancies, which can provide the supplement of

![](_page_4_Figure_8.jpeg)

Figure 6.  $CH_4$  (a) and  $CO_2$  (b) conversions at different temperatures ( $CH_4$ : $CO_2 = 1:1$ , GHSV = 18,000 mL/h·gcat); catalyst conversions (c) and  $H_2/CO$  (d) versus reaction time (reaction conditions: T = 700 °C,  $CH_4$ : $CO_2 = 1:1$ , GHSV = 18,000 mL/h·gcat).

oxygen and be helpful to the oxygen mobility. The high oxygen mobility not only ensures the high catalytic performance, <sup>49</sup> but also suppresses the carbon deposition and helps maintain the morphology of  $CeO_2$  nanomaterials. Besides, there are more active Ni species on the surface of the  $CeO_2$ –NR. So the conversion of carbon dioxide on the Ni/ $CeO_2$ –NR is higher compared with that of the Ni/ $CeO_2$ –NP.

**3.7.** Long Time Stability Tests of Ni/CeO<sub>2</sub> Catalysts. The long-term stability of the Ni/CeO<sub>2</sub> catalysts is examined under the same reaction conditions:  $CH_4/CO_2 = 1:1$ ,  $700\,^{\circ}C$ , and  $GHSV = 18\,000\,\text{mL/h\cdot gcat}$ . As shown in Figure 6c, the two Ni/CeO<sub>2</sub> catalysts undergo slight deactivation during 30 h on stream. However, the degree of deactivation is different. The conversion of methane is reduced by 21.9% and 26.2% for the Ni/CeO<sub>2</sub>–NR and Ni/CeO<sub>2</sub>–NP, respectively, while the conversion of carbon dioxide experiences deactivation of 12.1% and 15.1% for the Ni/CeO<sub>2</sub>–NR and Ni/CeO<sub>2</sub>–NP, respectively. The  $H_2/CO$  ratio also decreases (Figure 5d), indicating the water-gas shift reaction enhances as time goes on.<sup>4</sup>

It is well-known that the deactivation of Ni-based catalysts for the CO<sub>2</sub> reforming of methane reaction mainly results from the carbon deposition and the sintering of active Ni particles.<sup>50</sup> From TEM images and XPS analysis, we can find there are more active metal Ni particles anchoring on the surface of the CeO<sub>2</sub>-NR. Besides, more oxygen vacancies and higher oxygen mobility exist on the CeO<sub>2</sub>-NR. However, there are some larger aggregated Ni particles on the Ni/CeO2-NP, which are likely to sinter at the higher temperature. The oxygen vacancies on {111} planes would aggregate in a line at the higher temperature, which may aggravate the difficulty of oxygen mobility and supplement lattice oxygen in time. These all can be used to explain why the Ni/CeO2-NR displays more excellent catalytic activity and higher coke resistance than the Ni/CeO<sub>2</sub>-NP. Therefore it can be concluded that the excellent catalytic activity and the high coke resistance should be attributed to the high dispersion of active Ni particles and the high oxygen mobility.

**3.8.** Characteristics of the Used Catalysts. The XRD patterns of the Ni/CeO<sub>2</sub> catalysts after 30 h of reaction have been given in Figure 7A. As shown in the XRD pattern of the Ni/CeO<sub>2</sub>–NP, an obvious diffraction peak assigned to the graphite phase is found at about 26°, indicating that large amounts of coke deposited on the surface of the Ni/CeO<sub>2</sub>–NP. However, the diffraction peak of the graphite phase for the used the Ni/CeO<sub>2</sub>–NR is weak, which may be due to the good coke resistance of the catalysts. Besides, the diffraction peak of the used Ni/CeO<sub>2</sub>–NP at 44.5° belonging to Ni becomes sharper and narrower, which suggests the sintering of Ni particles after a long-term catalytic test, while that of the used Ni/CeO<sub>2</sub>–NR at 44.5° does not change much at all, indicating that the size of Ni particles does not change too much after a long-term duration test.

The morphology of Ni/CeO<sub>2</sub> nanomaterials is also observed on TEM images (Figure S1, Supporting Information). Ni/CeO<sub>2</sub> nanomaterials basically keep their morphology after 30 h of reaction. The carbon deposition on the used catalysts mainly exists in the form of carbon nanotubes. The difference is that there are larger amounts of carbon nanotubes on the Ni/CeO<sub>2</sub>–NP. This is also the reason why the catalytic activity of the Ni/CeO<sub>2</sub>–NP decreases more than that of the Ni/CeO<sub>2</sub>–NR.

![](_page_5_Figure_7.jpeg)

![](_page_5_Figure_8.jpeg)

![](_page_5_Figure_9.jpeg)

Figure 7. XRD patterns (A), Ce 3d XPS patterns (B), and TPO profiles (C) of the used catalysts: a,  $Ni/CeO_2$ -NR; b,  $Ni/CeO_2$ -NP.

The XPS spectra are also performed to study the number of oxygen vacancies of the used catalysts. As shown in Figure 7B, the peaks of the Ce 3d core level region are also fitted as before. The surface Ce<sup>3+</sup> concentration of total Ce on the used Ni/CeO<sub>2</sub>–NR is 17.9% and that of Ni/CeO<sub>2</sub>–NP is 10.4%, which is a bit lower than that of the fresh Ni/CeO<sub>2</sub> nanomaterials. This is mainly because a part of Ce<sup>3+</sup> is oxidized by the oxygen provided by the dissociation of carbon dioxide in the catalytic reaction. However, there are still more oxygen vacancies on the Ni/CeO<sub>2</sub>–NR. It can be concluded that the high catalytic activity is due to the in time supplemented oxygen vacancies.

The TPO measurements are performed to measure the types and the amount of carbon deposited on the used Ni/CeO<sub>2</sub> nanomaterials. As shown in Figure 7C, three peaks  $(\alpha, \beta, \text{ and } \gamma)$  can be observed on the used Ni/CeO<sub>2</sub>–NP. The  $\alpha$  peak at about 310 °C might be the amorphous carbon species on the

<span id="page-6-0"></span>nickel sites, which might be from the decomposition of methane and the active species for the formation of syngas.8 The  $\beta$  peak centered at 485 °C might be attributable to graphite carbon, which would cover the surface of Ni/CeO2 nanometerials. The  $\gamma$  peak is identified as the carbon nanotubes, which have the lowest reactivity compared to other carbon deposition species.<sup>51</sup> The carbon nanotubes encapsulate Ni particles at the tail end, so they should be responsible for the catalytic deactivation. On the used Ni/ CeO<sub>2</sub>-NR, there are only two types of coke deposition: the amorphous carbon and carbon nanotubes. The disappearance of graphite carbon may be caused by the high oxygen vacancies. which can gasify the graphite carbon covered on the surface immediately. On the other hand, as compared with the Ni/ CeO<sub>2</sub>-NP, the Ni/CeO<sub>2</sub>-NR display a smaller area of TPO profile, indicating their good coke resistance. This result is consistent with the TEM images and XRD patterns of the used catalysts.

**3.9.** Possible Catalytic Mechanism of Ni/CeO<sub>2</sub>-NR. According to the previous literature, 50,52-54 the possible mechanism for carbon dioxide reforming of methane over the Ni/CeO<sub>2</sub> nanomaterials is proposed. As shown in Figure 8, the

![](_page_6_Figure_4.jpeg)

**Figure 8.** Catalytic mechanism diagram for reforming of methane by carbon dioxide over Ni/CeO<sub>2</sub>-NR.

methane first absorbs on the active metal Ni particles and then decomposes into  $CH_x$ , while the carbon dioxide absorbs on the Ni particles and decomposes into carbon monoxide and  $O^*$ . The active intermediates, including  $CH_x$  and  $O^*$ , can react with each other and produce carbon monoxide and hydrogen. Besides, the lattice oxygen can transfer to the nearby Ni particles and react with  $CH_x$ . The supplement of lattice oxygen comes from the dissociation of  $CO_2$  and the oxygen mobility.

The active metal sites in carbon dioxide reforming of methane are Ni particles which have a strong metal–support interaction with CeO<sub>2</sub> supports. The exposed {110} and {100} planes of the CeO<sub>2</sub>–NR have more oxygen vacancies. Oxygen vacancies not only help to improve the dispersion of Ni particles, but also enhance the bonding strength between Ni particles and CeO<sub>2</sub> supports. However, the CeO<sub>2</sub>–NP exposes less active {111} planes, which makes a weak interaction between Ni and the CeO<sub>2</sub>–NP. These parts of Ni particles are easily sintered during the carbon dioxide reforming of methane, which is responsible for the deactivation of the Ni/ CeO<sub>2</sub>–NP.

The oxygen vacancies and oxygen mobility play a significant role on catalytic performance during the  $\mathrm{CO}_2$  reforming of methane. According to the literature, the C–H bond activation is the kinetically relevant step in the reforming reaction of methane. The lattice oxygen atoms contribute to the gasification of  $\mathrm{CH}_x$ , which is helpful to the catalytic activity and the resistance of coke deposition. There are a larger number of oxygen vacancies and higher oxygen mobility on the Ni/CeO<sub>2</sub>–NR. So the Ni/CeO<sub>2</sub>–NR displays better coke resistance than the Ni/CeO<sub>2</sub>–NP.

# 4. CONCLUSION

The Ni/CeO<sub>2</sub>–NR catalysts display more excellent catalytic activity and higher coke resistance compared with Ni/CeO<sub>2</sub>–NP for the CO<sub>2</sub> reforming of methane. The predominantly exposed planes are the unusually reactive  $\{110\}$  and  $\{100\}$  planes in the CeO<sub>2</sub>–NR rather than the stable  $\{111\}$  one in the CeO<sub>2</sub>–NP. The  $\{110\}$  and  $\{100\}$  planes show great superiority for the dispersion of Ni nanoparticles, which results in the existence of the SMSI effect. Besides, the oxygen vacancies and the mobility of lattice oxygen also show the morphology dependence, and benefit the catalytic activity and the gasification of the coke deposition. Due to these favorable properties, the Ni/CeO<sub>2</sub>–NR could be considered as excellent catalysts for the CO<sub>2</sub> reforming of methane.

# ASSOCIATED CONTENT

# **S** Supporting Information

TEM images of Ni/CeO<sub>2</sub>–NR and Ni/CeO<sub>2</sub>–NP after 30 h of reaction. This material is available free of charge via the Internet at http://pubs.acs.org.

# AUTHOR INFORMATION

### **Corresponding Author**

\*Tel: +86-21-66134852. Fax: +86-21-66136038. E-mail: dszhang@shu.edu.cn.

#### **Notes**

The authors declare no competing financial interest.

#### ACKNOWLEDGMENTS

The authors acknowledge the support of the National Natural Science Foundation of China (Grant No. 51108258), Shanghai Rising-Star Program (Grant No. 10QA1402400), Science and Technology Commission of Shanghai Municipality (11nm0502200 and 10540500100), and Key Subject of Shanghai Municipal Education Commission (J50102). The authors would like to thank Mr. W. J. Yu and Mr. P. F. Hu for help with the TEM and HRTEM measurements.

# **■** REFERENCES

- (1) Jens R, R. N. J. Catal. 1972, 27, 343.
- (2) Pruett, R. L. Science 1981, 211, 11.
- (3) Norskov, J. K.; Christensen, C. H. Science 2006, 312, 1322.
- (4) Choudhary, T. V.; Choudhary, V. R. Angew. Chem., Int. Ed. 2008, 47, 1828.
- (5) Hickman, D. A.; Schmidt, L. D. Science 1993, 259, 343.
- (6) J. Gamman, J.; Millar, G.; Rose, G.; Drennan, J. J. Chem. Soc., Faraday Trans. 1998, 94, 701.
- (7) Hu Yun, H. Advances in Catalysts for CO<sub>2</sub> Reforming of Methane. In *Advances in CO<sub>2</sub> Conversion and Utilization*; American Chemical Society: Washington, DC, 2010; Vol. 1056, p 155.
- (8) Xu, L.; Song, H.; Chou, L. Appl. Catal., B 2011, 108-109, 177.
- (9) Shamsi, A. Methane Dry Reforming over Carbide, Nickel-Based, and Noble Metal Catalysts. In  $CO_2$  Conversion and Utilization; American Chemical Society: Washington, DC, 2002; Vol. 809, p 182.
- (10) Liu, C. j.; Ye, J.; Jiang, J.; Pan, Y. ChemCatChem 2011, 3, 529.
- (11) Zhou, H. P.; Wu, H. S.; Shen, J.; Yin, A. X.; Sun, L. D.; Yan, C. H. J. Am. Chem. Soc. **2010**, 132, 4998.
- (12) Mai, H. X.; Sun, L. D.; Zhang, Y. W.; Si, R.; Feng, W.; Zhang, H. P.; Liu, H. C.; Yan, C. H. J. Phys. Chem. B 2005, 109, 24380.
- (13) Zhang, D.; Fu, H.; Shi, L.; Pan, C.; Li, Q.; Chu, Y.; Yu, W. Inorg. Chem. 2007, 46, 2446.
- (14) Godinho, M.; de F. Gonçalves, R.; Leite, E.; Raubach, C.; Carreño, N.; Probst, L.; Longo, E.; Fajardo, H. *J. Mater. Sci.* **2010**, *45*, 593.

- <span id="page-7-0"></span>(15) Wang, Z. L.; Feng, X. J. Phys. Chem. B 2003, 107, 13563.
- (16) van Houselt, A.; Gnielka, T.; Aan de Brugh, J. M. J.; Oncel, N.; Kockmann, D.; Heid, R.; Bohnen, K. P.; Poelsema, B.; Zandvliet, H. J. W. Surf. Sci. 2008, 602, 1731.
- (17) Sayle, T. X. T.; Parker, S. C.; Sayle, D. C. Phys. Chem. Chem. Phys. 2005, 7, 2936.
- (18) Zhou, K. B.; Wang, X.; Sun, X. M.; Peng, Q.; Li, Y. D. J. Catal. 2005, 229, 206.
- (19) Huang, X. S.; Sun, H.; Wang, L. C.; Liu, Y. M.; Fan, K. N.; Cao, Y. Appl. Catal., B 2009, 90, 224.
- (20) Wu, Z.; Li, M.; Overbury, S. H. J. Catal. 2012, 285, 61.
- (21) Gawade, P.; Mirkelamoglu, B.; Ozkan, U. S. J. Phys. Chem. C 2010, 114, 18173.
- (22) Si, R.; Flytzani-Stephanopoulos, M. Angew. Chem., Int. Ed. 2008, 47, 2884.
- (23) Yi, N.; Si, R.; Saltsburg, H.; Flytzani-Stephanopoulos, M. Energy Environ. Sci. 2010, 3, 831.
- (24) Liu, L.; Yao, Z.; Deng, Y.; Gao, F.; Liu, B.; Dong, L. ChemCatChem 2011, 3, 978.
- (25) Laosiripojana, N.; Assabumrungrat, S. Appl. Catal., B 2005, 60, 107.
- (26) Kim, D. K.; Stöwe, K.; Müller, F.; Maier, W. F. J. Catal. 2007, 247, 101.
- (27) Asami, K.; Li, X.; Fujimoto, K.; Koyama, Y.; Sakurama, A.; Kometani, N.; Yonezawa, Y. Catal. Today 2003, 84, 27.
- (28) Xu, S.; Yan, X.; Wang, X. Fuel 2006, 85, 2243.
- (29) Yeung, C. M. Y.; Yu, K. M. K.; Fu, Q. J.; Thompsett, D.; Petch, M. I.; Tsang, S. C. J. Am. Chem. Soc. 2005, 127, 18010.
- (30) Farmer, J. A.; Campbell, C. T. Science 2010, 329, 933.
- (31) Gonzalez-DelaCruz, V. M.; Holgado, J. P.; Pereñíguez, R.; Caballero, A. J. Catal. 2008, 257, 307.
- (32) Caballero, A.; Holgado, J. P.; Gonzalez-delaCruz, V. M.; Habas, S. E.; Herranz, T.; Salmeron, M. Chem. Commun. 2010, 46, 1097.
- (33) Weststrate, C. J.; Westerström, R.; Lundgren, E.; Mikkelsen, A.; Andersen, J. N.; Resta, A. J. Phys. Chem. C 2008, 113, 724.
- (34) Lin, J.; Li, L.; Huang, Y.; Zhang, W.; Wang, X.; Wang, A.; Zhang, T. J. Phys. Chem. C 2011, 115, 16509.
- (35) Watanabe, S.; Ma, X.; Song, C. J. Phys. Chem. C 2009, 113, 14249.
- (36) Liu, X.; Zhou, K.; Wang, L.; Wang, B.; Li, Y. J. Am. Chem. Soc. 2009, 131, 3140.
- (37) Nolan, M. J. Mater. Chem. 2011, 21, 9160.
- (38) Shapovalov, V.; Metiu, H. J. Catal. 2007, 245, 205.
- (39) Tang, W.; Hu, Z.; Wang, M.; Stucky, G. D.; Metiu, H.; McFarland, E. W. J. Catal. 2010, 273, 125.
- (40) Yuan, Q.; Liu, Q.; Song, W.-G.; Feng, W.; Pu, W.-L.; Sun, L.-D.; Zhang, Y.-W.; Yan, C.-H. J. Am. Chem. Soc. 2007, 129, 6698.
- (41) Lee, Y.; He, G.; Akey, A. J.; Si, R.; Flytzani-Stephanopoulos, M.; Herman, I. P. J. Am. Chem. Soc. 2011, 133, 12952.
- (42) Liu, Y. M.; Wang, L. C.; Chen, M.; Xu, J.; Cao, Y.; He, H. Y.; Fan, K. N. Catal. Lett. 2009, 130, 350.
- (43) Li, G.; Smith, R. L.; Inomata, H. J. Am. Chem. Soc. 2001, 123, 11091.
- (44) Kugai, J.; Subramani, V.; Song, C.; Engelhard, M. H.; Chin, Y.- H. J. Catal. 2006, 238, 430.
- (45) Shan, W.; Luo, M.; Ying, P.; Shen, W.; Li, C. Appl. Catal., A 2003, 246, 1.
- (46) Esch, F.; Fabris, S.; Zhou, L.; Montini, T.; Africh, C.; Fornasiero, P.; Comelli, G.; Rosei, R. Science 2005, 309, 752.
- (47) Campbell, C. T.; Peden, C. H. F. Science 2005, 309, 713.
- (48) Velu, S.; Suzuki, K.; Vijayaraj, M.; Barman, S.; Gopinath, C. S. Appl. Catal., B 2005, 55, 287.
- (49) Song, H.; Ozkan, U. S. J. Catal. 2009, 261, 66.
- (50) de Lima, S. M.; da Silva, A. M.; da Costa, L. O. O.; Graham, U. M.; Jacobs, G.; Davis, B. H.; Mattos, L. V.; Noronha, F. B. J. Catal. 2009, 268, 268.
- (51) Ocsachoque, M.; Pompeo, F.; Gonzalez, G. Catal. Today 2011, 172, 226.

- (52) Kado, S.; Imagawa, K. i.; Kiryu, A.; Yagi, F.; Minami, T.; Kawai, H.; Kawazuishi, K.-i.; Tomishige, K.; Nakamura, A.; Suehiro, Y. Catal. Today 2011, 171, 97.
- (53) Dong, W. S.; Jun, K. W.; Roh, H. S.; Liu, Z. W.; Park, S. E. Catal. Lett. 2002, 78, 215.
- (54) Pino, L.; Vita, A.; Cipitì, F.; Lagana, M.; Recupero, V. ̀ Appl. Catal., B 2011, 104, 64.
- (55) Huang, T.-J.; Lin, H. J.; Yu, T. C. Catal. Lett. 2005, 105, 239.
- (56) Wei, J.; Iglesia, E. J. Catal. 2004, 224, 370.