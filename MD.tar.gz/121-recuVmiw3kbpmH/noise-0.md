![](_page_0_Picture_3.jpeg)

# Room-Temperature Activation of Methane and Dry Re-forming with CO<sub>2</sub> on Ni-CeO<sub>2</sub>(111) Surfaces: Effect of Ce<sup>3+</sup> Sites and Metal—Support Interactions on C—H Bond Cleavage

Pablo G. Lustemberg,<sup>†</sup> Pedro J. Ramírez,<sup>‡</sup> Zongyuan Liu,<sup>§</sup> Ramón A. Gutiérrez,<sup>‡</sup> David G. Grinter,<sup>§</sup> Javier Carrasco, <sup>||</sup> Sanjaya D. Senanayake, <sup>||</sup> José A. Rodriguez,<sup>\*,§,⊥</sup> and M. Verónica Ganduglia-Pirovano<sup>\*,#</sup>

<sup>\*</sup>Instituto de Catálisis y Petroleoquímica (ICP-CSIC), C/Marie Curie 2, 28049 Madrid, Spain

![](_page_0_Picture_12.jpeg)

**ABSTRACT:** The results of core-level photoemission indicate that Ni-CeO<sub>2</sub>(111) surfaces with small or medium coverages of nickel are able to activate methane at 300 K, producing adsorbed  $CH_x$  and  $CO_x$  (x = 2, 3) groups. Calculations based on density functional theory predict a relatively low activation energy of 0.6–0.7 eV for the cleavage of the first C–H bond in the adsorbed methane molecule. Ni and O centers of ceria work in a cooperative way in the dissociation of the C–H bond at room temperature, where a low Ni loading is crucial for the catalyst activity and stability. The strong electronic perturbations in the Ni nanoparticles produced by the ceria supports of varying natures, such as stoichiometric and

![](_page_0_Picture_14.jpeg)

reduced, result in a drastic change in their chemical properties toward methane adsorption and dissociation as well as the dry reforming of methane reaction. The coverage of Ni has a drastic effect on the ability of the system to dissociate methane and catalyze the dry re-forming process.

8184

KEYWORDS: methane activation, dry re-forming, ceria, nickel, supported catalysts, support effect, XPS, DFT

#### **■ INTRODUCTION**

Methane is the main component of natural gas and biogas produced by the decomposition of waste in many landfills. The activation of methane by heterogeneous catalysts will therefore play a key role in solving future energy needs and as a carbon source for the production of chemicals.<sup>2</sup> In principle, the activation of methane is difficult due to the high stability of its C-H bonds. Enabling low-temperature activation of methane is a major technological objective. It is known that enzymes such as the methane monooxygenase<sup>4</sup> and some copper- and zinc-based inorganic compounds<sup>5-7</sup> can activate C-H bonds near room temperature. In a previous study, we found that a Ni-CeO2 highsurface-area powder catalyst was very efficient for performing the dry re-forming of methane reaction (DRM;  $CH_4 + CO_2 \rightarrow 2CO$  $+ 2H_2$ ) at a relatively low temperature of 700 K.<sup>8</sup> In this article, we show that a small coverage of Ni dispersed on ceria can actually activate the methane molecule at 300 K. We investigate at a molecular level the phenomena responsible for the observed low barrier for C-H bond cleavage on this metal/oxide system. It is shown that they are associated with metal-support interactions which are extremely sensitive to the coverage of Ni on the ceria substrate.

In general, pure metal surfaces display a low reactivity toward methane. They need high temperatures to activate the molecule

and are deactivated by the deposition of carbon and coke formation. The dispersion of metal nanoparticles on oxide surfaces is of great interest for developing novel catalytic materials, because the assembly could be more reactive than the individual components. 10,11 In heterogeneous catalysis, ceria (CeO<sub>2</sub>)-supported noble and late transition metals have attracted much attention, particularly due to their excellent catalytic activity in carbon monoxide oxidation and lowtemperature water-gas shift reactions. 12-15 Among the factors which are assumed to be influencing the activity such as the metal oxide contact structure and the particle size, the first has typically been considered the most important, because the perimeter interfaces around the metal particles are expected to be part of the active site where reactions take place. Moreover, ceria, with its capability for easy conversion between Ce4+ and Ce3+ oxidation states, often stabilizes oxidic  $M^{\delta+}$  cations by accommodating electrons transferred from the metal to the support in localized f states. 16-22 The change in the oxidation state of the adsorbed metallic species, resulting from strong metal-ceria interactions, has also been considered crucial to the

Received: August 17, 2016 Revised: October 18, 2016 Published: October 27, 2016

![](_page_0_Picture_22.jpeg)

<sup>†</sup>Instituto de Física Rosario (IFIR, CONICET-UNR), Bv 27 de Febrero 210bis, S2000EZP Rosario, Santa Fe, Argentina

<sup>&</sup>lt;sup>‡</sup>Facultad de Ciencias, Universidad Central de Venezuela, Caracas 1020-A, Venezuela

<sup>§</sup>Department of Chemistry, State University of New York, Stony Brook, New York 11749, United States

<sup>&</sup>quot;CIC Energigune, Albert Einstein 48, 01510 Miñano, Álava, Spain

<sup>&</sup>lt;sup>1</sup>Chemistry Department, Brookhaven National Laboratory, Upton, New York 11973, United States

systems' reactivity. <sup>12,13,22–25</sup> A good anchoring of the metal to the ceria favors catalytic activity and stability as a consequence of strong metal—support interactions. <sup>26–29</sup> In addition, the morphology of the ceria support has an important impact on the performance of the catalyst. <sup>26,27</sup> The Ni-CeO<sub>2</sub> system has received a great deal of attention in the area of methane dry reforming. <sup>8,26,27,30–32</sup> Previous works were mainly focused on studies at temperatures above 750 K, where significant activity is seen for DRM, and no attention was paid to the effects of nickel coverage or the nature of the interactions between nickel and ceria. <sup>8,26,27</sup>

Here, we investigate the activation of methane at room temperature on a series of Ni-CeO<sub>2</sub>(111) model catalysts using X-ray photoelectron spectroscopy (XPS) and density functional theory (DFT) based modeling.

We compare with results on the bare Ni(111) surface and studies reported in the literature 4-7 for the dissociation of methane on different types of inorganic compounds. At small nickel coverages, the atoms in a Ni-CeO<sub>2</sub> interface work in a cooperative way and are able to break C–H bonds at room temperature. These model Ni-CeO<sub>2</sub> systems are also very good catalysts for methane dry re-forming at the low temperature of 650 K, as has been observed for the real powder catalysts at similar temperatures.<sup>8</sup>

#### **■ EXPERIMENTAL AND THEORETICAL METHODS**

**Experimental Methods.** We investigated the effect of Ni coverage on the performance of Ni-CeO<sub>2</sub>(111) surfaces for methane activation and the re-forming of the molecule with CO<sub>2</sub>. The experimental data for these well-defined catalysts were collected in a setup that combined an ultrahigh-vacuum (UHV) chamber for surface characterization and a microreactor for catalytic tests.  $^{13,15,28,33}$  The UHV chamber was equipped with instrumentation for X-ray photoelectron spectroscopy (XPS), low-energy electron diffraction (LEED), ion-scattering spectroscopy (ISS), and thermal-desorption mass spectroscopy (TDS).  $^{13,15,28,33}$ 

The methodology followed for the preparation of the Ni- $CeO_2(111)$  surfaces is described in detail in refs 15 and 33. Ni was vapor-deposited on the ceria substrate at 300 K, and the system was characterized with core and/or valence photoemission. 15,33 In the studies of methane activation, the sample was transferred to the reactor at ~300 K, and then the reactant gas at 1 Torr of pressure was introduced. In experiments testing the activity of the Ni-CeO<sub>2</sub>(111) catalysts for the DRM process, the samples were exposed to a mixture of  $CH_4$  (1 Torr) and  $CO_2$ (1 Torr) at 300 K and were rapidly heated to the reaction temperature of 650 K. Product yields were analyzed by mass spectroscopy or gas chromatography. 15,33 In our experiments data were collected at intervals of 5 min. The amount of molecules (CO or H<sub>2</sub>) produced in the catalytic tests was normalized by the active area exposed by the sample and the total reaction time. The kinetic experiments were done in the limit of low conversion (<10%).

The near-ambient-pressure (NAP) XPS studies with the Ni-CeO<sub>2</sub>(111) catalysts were performed at the Advanced Light Source in Berkeley, CA (beamline 9.3.2). The C 1s and Ce 4d regions were probed with a photon energy of 490 eV and a resolution of  $\sim$ 0.2 eV. The Ce 4d photoemission lines were used for binding energy calibration on the basis of the 122.8 eV satellite features.

**Models and Computational Details.** We modeled the interaction of individual Ni atoms, exploring several adsorption

sites and different spin multiplets, on ceria supports of varying natures such as stoichiometric ( $CeO_2(111)$ ) and reduced ( $CeO_{2-x}(111)$ ) and  $Ce_2O_3(0001)$ ). Moreover, we considered three-dimensional (3D) pyramidal Ni<sub>4</sub> clusters on the stoichiometric and fully reduced ceria supports. The adsorption and dissociation of methane,  $CH_4 \rightarrow CH_3 + H$ , was investigated on selected Ni-ceria systems and compared with those of Ni(111).

Spin-polarized DFT and supercell periodic models were used within the Vienna ab initio simulation package (vasp site, http://www.vasp.at; version vasp.5.3.5).  $^{34,35}$  We treated explicitly the Ce (4f, 5s, 5p, 5d, 6s), O (2s, 2p), and Ni (4s, 3d) electrons as valence states expanded in plane waves with a cutoff energy of 415 eV, whereas the remaining electrons were kept frozen as core states in the projector-augmented wave (PAW) method. Strong correlation effects due to charge localization are modeled by adding a Hubbard *U*-like term ( $U_{\rm eff} = U - J$ ; that is, the difference between the Coulomb *U* and exchange *J* parameters, hereinafter referred to as simply *U*) to the Perdew, Burke, and Ernzerhof (PBE) generalized gradient approximation (GGA) functional. We used a value of U = 4.5 eV for the Ce 4f states.  $U_{\rm eff} = U - J$ 

The  $CeO_2(111)$  and  $Ce_2O_3(0001)$  surfaces were modeled by  $(2 \times 2)$  unit cells, with calculated ceria bulk equilibrium lattice parameters ( $a_0 = 5.485 \text{ Å (CeO}_2$ );  $a_0/c_0 = 3.92/6.18 \text{ Å and}$ internal parameters  $u_{\rm Ce}/u_{\rm O} = 0.2471/0.6448$  (hexagonal A-type, ferromagnetic,  ${\rm Ce_2O_3}$ ). In the case of  ${\rm CeO_2(111)}$ , we have considered 9 atomic layers (three O-Ce-O trilayers, TL), whereas Ce<sub>2</sub>O<sub>3</sub>(0001) was modeled with 15 atomic layers (three O-Ce-O-Ce-O quintuple layers, QL). The models for the defective  $CeO_{2-x}(111)$  surfaces  $(\Theta = 1/4, 1/2, 3/4, 1)$ correspond to the most stable structures in ref 42 with one surface or subsurface oxygen vacancy, as well as with two, three, and four subsurface vacancies (cf. Figure S1b-f in the Supporting Information). Interestingly, we found that the removal of all subsurface O atoms ( $\Theta = 1$ ) is stabilized by  $\sim$ 0.3 eV upon reconstruction with a change in the stacking of the second O layer. The resulting structure corresponds to 1 QL of hexagonal (A-type)  $Ce_2O_3$  on  $CeO_2(111)$  (cf. Figure S1g). We also considered 2 QL/2 TL Ce<sub>2</sub>O<sub>3</sub>/CeO<sub>2</sub>(111) (Figure S1h). The Ni(111) surface was modeled by a  $(3 \times 3)$  unit cell (bulk lattice constant of 3.52 Å) and five Ni layers. In all models, consecutive slabs were separated by at least 12 Å of vacuum space to avoid interaction with periodic images. Monkhorst-Pack grids with  $(3 \times 3 \times 1)$  and  $(5 \times 5 \times 1)$  k-point sampling were used for the ceria-based systems and Ni(111) surface, respectively.

In all geometry optimizations, all atoms in the bottom  $CeO_2$  TL or  $Ce_2O_3$  QL were fixed at their optimized bulk positions, whereas the rest of the atoms were allowed to fully relax. For the case of Ni(111), the two bottom atomic layers were kept fixed. Calculated local densities of states and magnetic moments were inspected in order to determine oxidation states.

The adsorption of molecular and dissociated methane and the  $CH_4 \rightarrow CH_3 + H$  reaction were studied on the most stable  $Ni_n/CeO_2(111)$  and  $Ni_n/Ce_2O_3(0001)$  systems (n=1,4), and on Ni(111). All of the reaction energies were referenced to  $CH_4$  as gas-phase species for which  $\Gamma$ -point calculations were performed in a  $12 \times 12 \times 12$  ų box. To locate the transition state (TS) structures, we employed the climbing image nudged elastic band method (CI-NEB)<sup>43</sup> with nine images for each reaction pathway. For all the TSs reported in this work, we have found only one imaginary frequency.

#### <span id="page-2-0"></span>RESULTS AND DISCUSSIONS

Interaction of Methane with Ni-CeO<sub>2</sub>(111) at Room Temperature. Ni and ceria can form solid solutions of  $Ce_{1-x}Ni_xO_{2-y}$  (x < 0.15) which exhibit a fluorite structure with Ni in a 2+ oxidation state. Scanning tunneling microscopy (STM) and XPS have been used to study the growth mode of nickel on  $CeO_2(111)$ . At 300 K and coverages below 0.2 ML, there is a large dispersion of Ni on ceria with small particles that exhibit an average height of 0.23 nm and an average diameter of 1.80 nm. XPS indicates that most of the Ni is in a +2 oxidation state. Upon annealing to 500 K, some of the Ni migrates into the ceria substrate to form a  $Ce_{1-x}Ni_xO_{2-y}$  solid solution. At Ni coverages above 0.3 ML, there is still a tendency toward intermixing but now Ni grows, forming 3D particles on the ceria substrate. As we will see below, these two different morphologies of the Ni-CeO<sub>2</sub>(111) surface have a strong effect on the chemical and catalytic properties.

Figure 1 shows C 1s XPS spectra collected after exposing the clean  $CeO_2(111)$  and  $Ni/CeO_2(111)$  surfaces with admetal

![](_page_2_Figure_4.jpeg)

**Figure 1.** C 1s XPS spectra collected after exposing  $CeO_2(111)$  and  $Ni/CeO_2(111)$  surfaces with coverages of 0.15 and 0.4 monolayer (ML) to 1 Torr of methane at 300 K for 5 min.

coverages of 0.15 and 0.4 ML to methane at 300 K. On the clean oxide surface weak features appear near 290 eV, which can be assigned to emissions from a Ce 4s level. There is also some signal in the 284–286 eV region which could come from the dissociation of a few methane molecules on defect sites of the oxide substrate. After the surface was precovered with 0.15 ML of Ni, exposure to methane at 300 K led to clear peaks near 290 and 285.5 eV. These peaks have also been detected after the reaction of alcohols with nickel-ceria and can be assigned to  $\mathrm{CO}_x$  and  $\mathrm{CH}_x$  species. The features near 285.5 eV are the products of the partial dissociation of methane into  $\mathrm{CH}_3$  and/or  $\mathrm{CH}_2$  groups. The features near 285.5 eV are the products of the partial dissociation of methane into  $\mathrm{CH}_3$  and/or  $\mathrm{CH}_2$  groups.

On highly active sites of the nickel-ceria surface, the methane undergoes complete decomposition,  $CH_4 \rightarrow CH_3 \rightarrow CH_2 \rightarrow CH$   $\rightarrow$  C, and the formed C reacts with O centers of ceria to yield adsorbed  $CO_2$  or  $CO_3$  species. The compounds that produced the features near 290 and 285.5 eV were weakly bound to the nickel-ceria surface and disappeared upon heating to temper-

atures above 400 K (Figure S2 in the Supporting Information). The oxidation state of the nickel in  $Ni_{0.15}/CeO_2(111)$  before and after adsorbing methane at room temperature was  $Ni^{2+}$  (Figure S3 in the Supporting Information).

The surface with 0.4 ML of nickel (cf. Figure 1) exhibits a significant reduction in the intensity of the features for  $CO_x$  and  $CH_x$  species, whereas a new peak appears near 282.5 eV which denotes the formation of  $NiC_x$  on the surface. <sup>45–47</sup> At coverages above 0.5 ML, the feature for  $NiC_x$  was dominant in the C 1s region. Figure 2 shows the effect of nickel coverage on the C 1s signal for  $NiC_x$  and on the total signal, including  $CH_x$ ,  $CO_x$ , and  $NiC_x$  species.

![](_page_2_Figure_10.jpeg)

**Figure 2.** Effect of Ni coverage on the total C 1s intensity for  $CH_{\omega}$   $CO_{\omega}$  and  $NiC_x$  species. The C 1s intensities were normalized by the coverage of Ni on the surface. At the bottom of the figure is shown the normalized C 1s intensity for the  $NiC_x$  species only. The  $Ni/CeO_2(111)$  surfaces were exposed to 1 Torr of methane at 300 K for 5 min.

The most important insight from Figure 1 is the presence of  $\mathrm{CH}_x$  fragments on the surface of the catalyst at Ni coverages below 0.2 ML, when the Ni is present in the form of atoms or small particles in close contact with the ceria substrate. A drastic drop in the activation of methane is seen at Ni coverages above 0.2 ML. As the coverage of Ni increases, large 3D particles are formed on ceria and most of the admetal atoms are not able to activate methane at room temperature. They behave like atoms in extended surfaces of nickel. The Ni-CeO<sub>2</sub>(111) system shares with a few inorganic compounds  $^{5-7}$  the ability to activate the C-H bonds of methane at room temperature. This gives us the possibility of doing chemical transformations using the adsorbed  $\mathrm{CH}_x$  fragments.

In a set of additional experiments, we explored the DRM process on the Ni-CeO<sub>2</sub>(111) systems at room temperature. We found activation of methane and plain chemisorption of CO<sub>2</sub> without achieving a catalytic cycle for the production of H<sub>2</sub> and CO. Catalytic activity for DRM was found at a temperature of 650 K (Figure 3). CeO<sub>2</sub>(111) did not display catalytic activity. The catalytic activity of the surface increased when nickel was added, reaching a maximum at an admetal coverage of 0.15 ML. These are the systems that display the highest activity in Figures 1 and 2 for the cleavage of C–H bonds in methane. At Ni coverages above 0.2 ML, there is a steady decline in the chemical and catalytic activity. At the same time postreaction characterization of the catalysts with XPS showed an increase on the

<span id="page-3-0"></span>![](_page_3_Figure_1.jpeg)

**Figure 3.** Catalytic activity for methane dry re-forming of Ni-ceria surfaces as a function of nickel coverage. The figure reports the amount of  $H_2$  and CO formed after exposing the nickel-ceria surfaces to 1 Torr of methane and 1 Torr of  $CO_2$  at 650 K for 5 min.

amount of  $NiC_x$  present on the surface (Figure 4). This is a bad sign, because the  $NiC_x$  species is not active for the re-forming of hydrocarbons and can lead to coke formation.<sup>45</sup>

![](_page_3_Figure_4.jpeg)

**Figure 4.** Effect of Ni coverage on the amount of  $NiC_x$  formed after exposing Ni-CeO<sub>2</sub>(111) surfaces to 1 Torr of methane and 1 Torr of CO<sub>2</sub> at 650 K for 5 min. The C 1s intensity NiC<sub>x</sub> was normalized by the coverage of Ni on the surface.

To gain a better understanding of the mechanism for DRM, we performed XPS experiments under near-ambient pressure. The study was done in a system with a low content of Ni,  $\Theta_{\rm Ni} \approx 0.1$  ML, to avoid NiC<sub>x</sub> formation. The bottom of Figure 5 displays C 1s and Ce 4d photoemission spectra collected for a Ni-CeO<sub>2</sub>(111) sample under a pressure of 100 mTorr of methane at 700 K. At this elevated temperature, there are no signals for CO<sub>x</sub> or CH<sub>x</sub> species on the surface. The C atoms produced by the full dissociation of methane react with O centers of the sample to produce CO that desorbs into the gas phase. An analysis of the corresponding Ce 4d spectrum shows clear features for a reduced CeO<sub>2-x</sub>(111) support. On the O vacancies

![](_page_3_Figure_7.jpeg)

**Figure 5.** C 1s and Ce 4d NAP-XPS data collected while exposing a Ni-CeO $_2$ (111) surface to 100 mTorr of methane at 700 K (bottom spectra) and after adding 100 mTorr of CO $_2$  (top spectra). The Ni coverage on the ceria substrate was  $\sim$ 0.1 ML.

of the system, the CO<sub>2</sub> molecules adsorb and dissociate, yielding adsorbed O and CO gas to close a catalytic cycle:

$$CH_4(gas)$$
  $\rightarrow$   $C(ads) + 2H_2(gas)$   
 $C(ads) + O(oxide)$   $\rightarrow$   $CO(gas) + O_{vac}(oxide)$   
 $CO_2(gas) + O_{vac}(oxide)$   $\rightarrow$   $CO(gas) + O(oxide)$ 

In Figure 5, the adding of 100 mTorr of  $CO_2$  to the reaction chamber produces a partial reoxidation in the Ce 4d region with the appearance of CO gas and an adsorbed  $CO_x$  species peak at 291 eV, in the C 1s region.

Thus, from the results in Figures 5 and 6, we can conclude that the active phase in the DRM catalysts contained small particles of metallic Ni dispersed on partially reduced ceria. This nickel-ceria system operates as a DRM catalyst at a temperature which is much lower than that typically reported for metal oxide catalysts. In its high-surface area powder form, it is highly active

![](_page_3_Figure_13.jpeg)

**Figure 6.** Ni  $2p_{3/2}$  XPS spectra for a fresh, as-prepared Ni-CeO<sub>2</sub>(111) catalyst and the same system after exposure to a mixture of 1 Torr of CH<sub>4</sub> and 1 Torr of CO<sub>2</sub> at 650 K under DRM reaction conditions.

<span id="page-4-0"></span>and stable (80 h test).<sup>8</sup> This is a consequence of synergistic interactions between the metal and oxide components of the system. In the next section, we use DFT-based calculations to study the nature of these interactions and how they facilitate the activation of methane.

Effect of Metal–Support Interactions on C–H Bond Cleavage. Interaction of Ni Species with  $CeO_2(111)$ ,  $CeO_{2-x}(111)$ , and  $Ce_2O_3(0001)$ . An isolated Ni atom exhibits a  $4s^23d^8$  electronic configuration. From the different possible adsorption sites on  $CeO_2(111)$  (on-top, bridge, hollow) with varying total magnetizations (M=0,2,4) considered, we found that the O-hollow site where two Ni 4s electrons are transferred from Ni to the ceria support, yielding  $Ni^{2+}$  ( $4s^03d^8$ ) and two  $Ce^{3+}$  species (M=4), is the most stable site ( $Ni^{2+}$ @O-hollow), with -3.76 eV adsorption energy with respect to a  $Ni^0$  atom in the gas phase (Figures 7 and 8), in agreement with previous work.

![](_page_4_Figure_3.jpeg)

**Figure 7.** Adsorbed Ni atoms and pyramidal Ni<sub>4</sub> clusters on the  $CeO_2(111)$  (a) and  $Ce_2O_3(0001)$  (b) surfaces. Surface/subsurface oxygen atoms are depicted in red/green,  $Ce^{4+}$  in white, and  $Ce^{3+}$  in gray. The oxygen atoms in deeper layers are shown in blue.

Forcing an M=0 state at this site results in the spin flip of the transferred electrons with a negligible change in the adsorption energy (about 0.01 eV). The change in energy accompanying spin flips will be consistently small in all Ni-ceria systems considered. However, the location of the  $Ce^{3+}$  centers with respect to the Ni site in the Ni-CeO<sub>2</sub> systems will have in general a larger effect (up to  $\sim$ 0.9 eV) (Table S2 and Figure S4 in the Supporting Information).

In addition, we found that Ni<sup>1+</sup> (4s<sup>0</sup>3d<sup>9</sup>, M = 2) species at the O-bridge site, resulting from the transfer of only one electron from Ni to the support, and neutral Ni<sup>0</sup> (4s<sup>0</sup>3d<sup>10</sup>, M = 0) species at the O-top, Ce-bridge, and Ce-top sites as well as Ni<sup>0</sup> (4s<sup>2</sup>3d<sup>8</sup>, M = 2) species at the Ce-top site, are less stable than the Ni<sup>2+</sup>@ O-hollow site by about 0.4, 1.7, 1.7, 2.8, and 3.2 eV, respectively (Figure 8 and Table S2 in the Supporting Information).

Thus, the electronic influence the CeO<sub>2</sub>(111) support exerts on highly dispersed Ni atoms results in oxidized Ni species with

![](_page_4_Figure_8.jpeg)

**Figure 8.** Adsorption energy of a Ni adatom at various sites on the  $CeO_2(111)$  surface,  $CeO_{2-x}(111)$  with subsurface oxygen vacancies ( $\Theta$  = 1/4, 1/2, and 3/4) 1 and 2 QL  $Ce_2O_3/2$  TL  $CeO_2(111)$  and  $Ce_2O_3(0001)$ . The Ni oxidation state is color coded ( $0 < \delta < 1$ ).

their most common oxidation state, +2. This is in line with the experimental observations that, at 300 K and coverages below 0.2 ML, there is a large dispersion of Ni on  $CeO_2(111)$  with most of the Ni in the +2 oxidation state.

Figure 8 shows that Ni adatoms gradually recover their metallic state, Ni $^{2+} \rightarrow Ni^{1+} \rightarrow Ni^{0+} \rightarrow Ni^{0}$ , upon increasing oxygen removal from the ceria support, CeO<sub>2</sub>(111)  $\rightarrow$  CeO<sub>2-x</sub>(111)  $\rightarrow$  CeO<sub>2-x</sub>(0001). This clearly reflects the synergistic interactions between nickel and the ceria support.

It is on the fully reduced  $Ce_2O_3(0001)$  surface where no metal  $\rightarrow$  ceria charge transfer can take place and the most stable atomic Ni<sup>0</sup> (4s<sup>0</sup>3d<sup>10</sup>, M = 0) species sit on a O-bridge site (Figure 7), with -1.95 eV adsorption energy (Figure 8). The O-top and O-hollow sites are less stable than the Ni<sup>0</sup>@O-bridge site by about 0.2 and 0.8 eV, respectively (Figure 8 and Table S6 in the Supporting Information).

Increasing the size of Ni nanoparticles to Ni<sub>4</sub> clusters with a pyramidal shape on the  $CeO_2(111)$  and  $Ce_2O_3(0001)$  surfaces enables us to investigate the extent of the electronic influence of the ceria support in cases in which particles comprise atoms not in direct contact with it. The most stable site of a Ni<sub>4</sub> cluster on the stoichiometric  $CeO_2(111)$  surface is on-top of a subsurface oxygen with −3.67 eV adsorption energy with respect to Ni<sup>0</sup> atoms in the gas phase (Figure 7), in agreement with previous work.<sup>21</sup> These Ni<sub>4</sub> species also reduce the ceria support upon adsorption with the formation of two Ce3+ ions. These two electrons are transferred from the three Ni atoms forming the pyramid base, which are partially oxidized  $(3 \times Ni^{0.66+})$ , whereas that at the top remains unaffected (Ni<sup>0</sup>), reflecting a rapid decay of the metal-ceria interactions. Indeed, for a planar rhombohedral Ni<sub>4</sub> species, <sup>21</sup> two electrons are also transferred, but all Ni atoms are oxidized  $(4 \times Ni^{0.5+})$ . Hence, at Ni coverages above 0.3 ML on CeO<sub>2</sub>(111), the 3D particles that are found to form<sup>30</sup> comprise a large fraction of metal (Ni<sup>0</sup>) atoms. Moreover, as in the case of the Ni adatoms, fully metallic pyramidal Ni<sub>4</sub> species (4  $\times$  Ni<sup>0</sup>, Figure 7) are stabilized on the reduced Ce<sub>2</sub>O<sub>3</sub>(0001)

Adsorption and Activation of Methane. The chemical bonding and associated charge transfer at the interface between the metal particles and the  $CeO_2(111)$  support change the chemical properties of the sites on the metal particles so that

![](_page_5_Figure_1.jpeg)

Figure 9. Top and side views of the most stable structures for methane adsorption on single Ni atoms (a-c) and Ni<sub>4</sub> clusters (d-f) on  $CeO_2(111)$  as well as Ni atoms (g,h) and Ni<sub>4</sub> clusters (i,j) on  $Ce_2O_3(0001)$  and on Ni(111) (k-m). Adsorption energies are given with respect to gas-phase molecules in eV. Selected interatomic distances are also given in pm.

better catalytic effects toward methane activation can be achieved.

Figure 9a,d shows the molecular binding of methane to isolated  $\mathrm{Ni}^{2+}$  and partially oxidized larger  $\mathrm{Ni}_4$  species on the  $\mathrm{CeO}_2(111)$  surface with adsorption energies of approximately -0.2 eV. On  $\mathrm{Ni}^{2+}/\mathrm{CeO}_2(111)$  the distance between Ni and the closest H atoms is increased by about 0.1 Å in comparison to that on the  $\mathrm{Ni}_4$  species. On both Ni-ceria systems, methane dissociation is hindered by a relatively low activation energy of 0.7–0.8 eV (Figure 10a). In contrast, the molecular binding of methane to  $\mathrm{Ni}(111)$  is extremely weak, decreasing the reaction probability, and dissociation is also difficult due to a larger energy barrier of about 0.9–1.1 eV.  $^{8,49-52}$  Therefore, the energy barriers of small Ni nanoparticles on  $\mathrm{CeO}_2(111)$  are more accessible at room temperature than that of  $\mathrm{Ni}(111)$ , and methane dissociation is expected to occur, in agreement with the experiments shown in Figure 1.

The dissociation products shown in Figure 10a indicate that, for the dispersed  $\mathrm{Ni}^{2+}$  species, Ni and O centers of ceria work in a cooperative way in the dissociation of the C–H bond. Methane adsorption sites with adjacent  $\mathrm{Ni}^{2+}$  and surface O species do exist for low Ni loadings (below 0.2 ML), for which a large dispersion of small Ni particles in direct contact with the  $\mathrm{CeO}_2(111)$  support are observed.

Note that the final states shown in Figure 10a do not necessarily correspond to the lowest energy structures of the dissociated methane but to stable states that are geometrically close to the transition state structures. For instance, on the Ni<sup>2+</sup>-

CeO<sub>2</sub> system, a configuration with both the CH<sub>3</sub> methyl and the H atom adsorbed on-top of surface oxygen atoms is more stable by 0.6 eV than that with the CH<sub>3</sub> group on nickel and H forming a hydroxyl species (cf. Figure 9b,c). Also, on the Ni<sub>4</sub>-CeO<sub>2</sub> system, diffusion of H to the ceria support further stabilizes the dissociated state by 0.7 eV (cf. Figure 9e,f).

Once CH<sub>3</sub> is formed, sequential decomposition of the methyl species into C should occur very quickly. 50-52 Indeed, after exposure of the Ni-CeO<sub>2</sub>(111) systems to methane at 300 K, the formation of CO<sub>x</sub> species is observed (Figure 1). Yet, it is further observed that for low Ni loadings, below 0.2 ML, NiC<sub>x</sub> does not form, whereas for higher loadings, for which 3D particles form, NiC<sub>x</sub> also forms and the activity toward methane dissociation drastically drops (Figure 2). The dependence on Ni loading of the ease with which NiCx forms on Ni sites in the Ni-CeO2 systems is consistent with the calculated trend in the exothermicity of the nonoxidative adsorption of C atoms, namely  $\mathrm{Ni^{2+}/CeO_{2}(111)}$  (-4.12) <  $\mathrm{Ni_{4}/CeO_{2}(111)}$  (-6.54)  $\approx$ Ni(111) (-6.78 eV), in agreement with previous work. That is, the 3D Ni<sub>4</sub> clusters behave like the extended surface with respect to the stabilization of C atoms, namely strongly bound C species will stick to the surface of the existing 3D Ni particles at high Ni loading on  $CeO_2(111)$ , resulting in activity loss and ultimately in coke formation.

The strong electronic nickel-ceria interaction that is present at low nickel loadings yields not only active but also stable Ni-CeO $_2$  catalysts for methane activation at room temperature, enabling the use of the adsorbed  $\mathrm{CH}_x$  compounds for chemical reactions.

<span id="page-6-0"></span>![](_page_6_Figure_1.jpeg)

**Figure 10.** Reaction energy profile for the  $CH_4 \rightarrow CH_3 + H$  reaction on isolated Ni atoms and Ni<sub>4</sub> clusters on the  $CeO_2(111)$  (a) and  $Ce_2O_3(0001)$  surfaces (b), in comparison to Ni(111). The structures shown to the left and right of the reaction pathways correspond to the side views of the optimized molecularly adsorbed and dissociated states used in the search of the transition state structure. All energies are relative to  $CH_4$  in the gas phase.

In addition, such nickel-ceria systems were also found to be active for CH<sub>4</sub> dry re-forming with CO<sub>2</sub> at a relatively low temperature of ~700 K.<sup>8</sup> At this temperature, as mentioned above, the C atoms resulting from the complete CH<sub>4</sub> dissociation combine with lattice oxygen atoms, producing CO that desorbs in the gas phase, leaving an oxygen vacancy behind. These vacancies help in the activation and dissociation of CO<sub>2</sub>. Consistently, we find that the C/Ni<sup>2+</sup>-CeO<sub>2</sub>(111)  $\rightarrow$  CO/Ni<sup>2+</sup>-CeO<sub>2-x</sub>(111) reaction on the Ni<sup>2+</sup>-CeO<sub>2</sub>(111) system is highly exothermic:  $\Delta E = -3.58$  eV.<sup>21</sup>

Figures 5 and 6 show that, under DRM reaction conditions, the  $\mathrm{Ni^{2+}\text{-}CeO_2} \rightarrow \mathrm{Ni^0\text{-}CeO_{2-x}}$  change occurs. In the previous section, we have shown that undoubtedly, as the reduction of the ceria support increases (Figure 8), the oxidation state of Ni particles in contact with the support changes from +2 to 0. The question arises of knowing what is the effect of this change on the methane activation barrier.

Figure 10b shows that the  $\mathrm{Ni^0\text{-}Ce_2O_3(0001)}$  systems have barriers comparable to those of  $\mathrm{Ni^{2+}\text{-}CeO_2(111)}$  (Figure 10a). This means that the catalyst modifications induced by changing from room temperature to DRM operating conditions cannot result in an alteration of the activity toward C–H bond cleavage, in agreement with the experimental observations. Moreover, we notice that the chemisorbed methane molecules are more stable on  $\mathrm{Ni^0\text{-}Ce_2O_3(0001)}$  than on  $\mathrm{Ni^{2+}\text{-}CeO_2}$  by about 0.35 eV, which increases the probability for reaction on the actual DRM active system.

To gain insight into the change in the activity and stability of the active Ni<sup>0</sup>-CeO<sub>2-x</sub> DRM catalysts with nickel loading (Figures 4 and 5), we newly calculated the binding of C atoms on the Ni<sup>0</sup>-Ce<sub>2</sub>O<sub>3</sub>(0001) model systems with highly dispersed Ni atoms and larger 3D Ni<sub>4</sub> clusters. As for the Ni<sup>2+</sup>-CeO<sub>2</sub>(111) discussed above, we found a similar trend, Ni/Ce<sub>2</sub>O<sub>3</sub>(0001) (-4.91) < Ni<sub>4</sub>/Ce<sub>2</sub>O<sub>3</sub>(0001) (-5.92)  $\approx$  Ni(111) (-6.78 eV), in line with the observation that keeping low nickel loadings is crucial to avoid NiC<sub>x</sub> formation that leads to deactivation during the DRM reaction.

#### CONCLUSIONS

The experimental and theoretical results described above show that Ni-ceria catalysts with Ni atoms and small particles in direct contact with the ceria support are able to activate methane at room temperature. In this aspect, they match the activity reported for the methane monooxygenase enzyme<sup>4</sup> and some copper- and zinc-based inorganic compounds. The Ni-ceria systems are also active for methane dry re-forming with  $\rm CO_2$  at temperatures as low as 650 K. The systems that involved the smallest highly dispersed particles are the most efficient for methane activation and re-forming as well as the most resistant to deactivation by  $\rm NiC_x$  formation. Thus, selecting an appropriate Ni loading is vital when it comes to having a stable performance of the catalysts.

The activity and stability of the catalyst are associated with strong metal—support interactions that are more effective when Ni particles are small. The metal—support interactions affect the charge transferred between the Ni and the ceria support, which has a strong effect on the chemical and catalytic properties of the Ni-ceria systems. Small Ni particles on stoichiometric ceria experience large electronic perturbations, which result in a significant binding energy and a relatively low activation barrier for the cleavage of the first C—H bond in adsorbed methane molecules in comparison to extended Ni surfaces, enabling methane activation at room temperature and the use of adsorbed  $CH_x$  species in chemical reactions. The nature of the support on which the Ni particles are fixed is important, as Ni and O centers of ceria work in a cooperative way in the dissociation of the C—H bond at room temperature.

The methane C–H cleavage barrier also remains low upon changing the operating conditions from room temperature to those of methane dry re-forming with  $CO_2$ . This change produces a modification of the catalyst,  $Ni^{2+}$ - $CeO_2 \rightarrow Ni^0$ - $CeO_{2-x}$ , that does not affect the activation of methane but that of  $CO_2$ . Oxygen vacancies formed on the reducible support strongly enhance the ability of the system to dissociate C–O bonds. Thus, combining well-dispersed small Ni particles that promote C–H activation with a support that allows for oxygen removal appears to be a winning approach for the DRM reaction.

### ASSOCIATED CONTENT

#### Supporting Information

The Supporting Information is available free of charge on the ACS Publications website at DOI: 10.1021/acscatal.6b02360.

Reduced ceria and Ni-ceria models and Ni adsorption energies as well as Ni 2p XPS spectra (PDF)

### AUTHOR INFORMATION

# **Corresponding Authors**

\*E-mail for J.A.R.: rodrigez@bnl.gov.

\*E-mail for M.V.G.-P.: vgp@icp.csic.es.

## <span id="page-7-0"></span>Notes

The authors declare no competing financial interest.

# ■ ACKNOWLEDGMENTS

The work carried out at Brookhaven National Laboratory was supported by the U.S. Department of Energy (Chemical Sciences Division, DE-SC0012704). Parts of these studies were done at the Advanced Light Source (ALS), which is supported by the U.S. Department of Energy. The theoretical work was supported by the MINECO-Spain (CTQ2012-32928 and CTQ2015- 71823-R). P.G.L. thanks CONICET for an external postdoctoral fellowship. J.C. acknowledges support by the Ramon y Cajal ́ Fellowship, the Marie Curie Career Integration Grant FP7- PEOPLE-2011-CIG: Project NanoWGS, and the Royal Society through the Newton Alumnus scheme. The COST action CM1104 is gratefully acknowledged. Computer time provided by the BIFI-ZCAM, and the Spanish Supercomputing Network (RES) at BSC, UMA, UV, and FCSCL is acknowledged. J.Z. acknowledges support by the National Science Foundation (Award No. CHE1151846) and Wyoming NASA EPSCoR (NASA Grant No. NNX13AB13A).

# ■ REFERENCES

- (1) Pakhare, D.; Spivey, J. Chem. Soc. Rev. 2014, 43, 7813−7837.
- (2) Lavoie, J.-M. Front. Chem. 2014, 2, 81.
- (3) Wei, J.; Iglesia, E. J. Phys. Chem. B 2004, 108, 4094−4103.
- (4) Chan, S. I.; Yu, S. S.-F. Acc. Chem. Res. 2008, 41, 969−979.
- (5) Chan, S. I.; Lu, Y.-J.; Nagababu, P.; Maji, S.; Hung, M.-C.; Lee, M. M.; Hsu, I.-J.; Minh, P. D.; Lai, J. C.-H.; Ng, K. Y.; Ramalingam, S.; Yu, S. S.-F.; Chan, M. K. Angew. Chem., Int. Ed. 2013, 52, 3731−3735.
- (6) Xu, J.; Zheng, A.; Wang, X.; Qi, G.; Su, J.; Du, J.; Gan, Z.; Wu, J.; Wang, W.; Deng, F. Chem. Sci. 2012, 3, 2932−2940.
- (7) Grundner, S.; Markovits, M. A.; Li, G.; Tromp, M.; Pidko, E. A.; Hensen, E. J.; Jentys, A.; Sanchez-Sanchez, M.; Lercher, J. A. Nat. Commun. 2015, 6, 7546.
- (8) Liu, Z.; Grinter, D. C.; Lustemberg, P. G.; Nguyen-Phan, T.-D.; Zhou, Y.; Luo, S.; Waluyo, I.; Crumlin, E. J.; Stacchiola, D. J.; Zhou, J.; Carrasco, J.; Busnengo, H. F.; Ganduglia-Pirovano, M. V.; Senanayake, S. D.; Rodriguez, J. A. Angew. Chem., Int. Ed. 2016, 55, 7455−7459.
- (9) Choudhary, T. V.; Aksoylu, E.; Goodman, D. W. Catal. Rev.: Sci. Eng. 2003, 45, 151−203.
- (10) Freund, H.-J.; Pacchioni, G. Chem. Soc. Rev. 2008, 37, 2224−2242.
- (11) Haruta, M. CATTECH 2002, 6, 102−115.
- (12) Flytzani-Stephanopoulos, M.; Saltsburg, H.; Fu, Q. Science 2003, 301, 935−938.
- (13) Rodriguez, J.; Liu, P.; Hrbek, J.; Evans, J.; Perez, M. ́ Angew. Chem., Int. Ed. 2007, 46, 1329−1332.
- (14) Cargnello, M.; Doan-Nguyen, V. V. T.; Gordon, T. R.; Diaz, R. E.; Stach, E. A.; Gorte, R. J.; Fornasiero, P.; Murray, C. B. Science 2013, 341, 771−773.
- (15) Senanayake, S. D.; Evans, J.; Agnoli, S.; Barrio, L.; Chen, T.-L.; Hrbek, J.; Rodriguez, J. A. Top. Catal. 2011, 54, 34−41.
- (16) Hernandez, N. C.; Grau-Crespo, R.; de Leeuw, N. H.; Sanz, J. F. Phys. Chem. Chem. Phys. 2009, 11, 5246−5252.
- (17) Camellone, M. F.; Fabris, S. J. J. Am. Chem. Soc. 2009, 131, 10473−10483.
- (18) Zhang, C.; Michaelides, A.; Jenkins, S. J. Phys. Chem. Chem. Phys. 2011, 13, 22−33.
- (19) Nolan, M. J. Chem. Phys. 2012, 136, 134703.
- (20) Bruix, A.; Neyman, K. M.; Illas, F. J. Phys. Chem. C 2010, 114, 14202−14207.
- (21) Carrasco, J.; Barrio, L.; Liu, P.; Rodriguez, J. A.; Ganduglia-Pirovano, M. V. J. Phys. Chem. C 2013, 117, 8241−8250.
- (22) Bruix, A.; et al. Angew. Chem., Int. Ed. 2014, 53, 10525−10530.
- (23) Rodriguez, J. A.; Ma, S.; Liu, P.; Hrbek, J.; Evans, M.; Perez, J. ́ Science 2007, 318, 1757−1760.

(24) Rodriguez, J.; Graciani, J.; Evans, J.; Park, J.; Yang, F.; Stacchiola, D.; Senanayake, S.; Ma, S.; Perez, M.; Liu, P.; Sanz, J.; Hrbek, J. ́ Angew. Chem., Int. Ed. 2009, 48, 8047−8050.

- (25) Park, J. B.; Graciani, J.; Evans, J.; Stacchiola, D.; Ma, S.; Liu, P.; Nambu, A.; Sanz, J. F.; Hrbek, J.; Rodriguez, J. A. Proc. Natl. Acad. Sci. U. S. A. 2009, 106, 4975−4980.
- (26) Wang, N.; Qian, W.; Chu, W.; Wei, F. Catal. Sci. Technol. 2016, 6, 3594−3605.
- (27) Du, X.; Zhang, D.; Shi, L.; Gao, R.; Zhang, J. J. Phys. Chem. C 2012, 116, 10009−10016.
- (28) Carrasco, J.; Lopez-Dura ́ n, D.; Liu, Z.; Duchon ́ ̌, T.; Evans, J.; Senanayake, S. D.; Crumlin, E. J.; Matolín, V.; Rodríguez, J. A.; Ganduglia-Pirovano, M. V. Angew. Chem., Int. Ed. 2015, 54, 3917−3921.
- (29) Bruix, A.; Rodriguez, J. A.; Ramírez, P. J.; Senanayake, S. D.; Evans, J.; Park, J. B.; Stacchiola, D.; Liu, P.; Hrbek, J.; Illas, F. J. Am. Chem. Soc. 2012, 134, 8968−8974.
- (30) Hahn, K. R.; Seitsonen, A. P.; Iannuzzi, M.; Hutter, J. ChemCatChem 2015, 7, 625−634.
- (31) Xie, T.; Zhao, X.; Zhang, J.; Shi, L.; Zhang, D. Int. J. Hydrogen Energy 2015, 40, 9685−9695.
- (32) Zhao, X.; Li, H.; Zhang, J.; Shi, L.; Zhang, D. Int. J. Hydrogen Energy 2016, 41, 2447−2456.
- (33) Xu, W.; Liu, Z.; Johnston-Peck, A. C.; Senanayake, S. D.; Zhou, G.; Stacchiola, D.; Stach, E. A.; Rodriguez, J. A. ACS Catal. 2013, 3, 975− 984.
- (34) Kresse, G.; Hafner, J. Phys. Rev. B: Condens. Matter Mater. Phys. 1993, 47, 558−561.
- (35) Kresse, G.; Furthmüller, J. Phys. Rev. B: Condens. Matter Mater. Phys. 1996, 54, 11169−11186.
- (36) Kresse, G.; Joubert, D. Phys. Rev. B: Condens. Matter Mater. Phys. 1999, 59, 1758−1775.
- (37) Dudarev, S.; Botton, G.; Savrasov, S.; Humphreys, C.; Sutton, A. Phys. Rev. B: Condens. Matter Mater. Phys. 1998, 57, 1505−1509.
- (38) Perdew, J.; Burke, K.; Ernzerhof, M. Phys. Rev. Lett. 1996, 77, 3865−3868.
- (39) Fabris, S.; deGironcoli, S.; Baroni, S.; Vicario, G.; Balducci, G. Phys. Rev. B: Condens. Matter Mater. Phys. 2005, 71, 041102.
- (40) Cococcioni, M.; de Gironcoli, S. Phys. Rev. B: Condens. Matter Mater. Phys. 2005, 71, 035105.
- (41) Da Silva, J.; Ganduglia-Pirovano, M.; Sauer, J.; Bayer, V.; Kresse, G. Phys. Rev. B: Condens. Matter Mater. Phys. 2007, 75, 045121.
- (42) Murgida, G. E.; Ganduglia-Pirovano, M. V. Phys. Rev. Lett. 2013, 110, 246101.
- (43) Henkelman, G.; Uberuaga, B. P.; Jonsson, H. ́ J. Chem. Phys. 2000, 113, 9901−9904.
- (44) Zhou, Y.; Zhou, J. J. Phys. Chem. C 2012, 116, 9544−9549.
- (45) Liu, Z.; Duchoň, T.; Wang, H.; Peterson, E. W.; Zhou, Y.; Luo, S.; Zhou, J.; Matolín, V.; Stacchiola, D. J.; Rodriguez, J. A.; Senanayake, S. D. J. Phys. Chem. C 2015, 119, 18248−18256.
- (46) Kovacs, G.; Berto ́ ti, I.; Radno ́ czi, G. ́ Thin Solid Films 2008, 516, 7942−7946.
- (47) Czekaj, I.; Loviat, F.; Raimondi, F.; Wambach, J.; Biollaz, S.; Wokaun, A. Appl. Catal., A 2007, 329, 68−78.
- (48) Yuan, K.; Zhong, J.-Q.; Zhou, X.; Xu, L.; Bergman, S. L.; Wu, K.; Xu, G. Q.; Bernasek, S. L.; Li, H. X.; Chen, W. ACS Catal. 2016, 6, 4330−4339.
- (49) Abild-Pedersen, F.; Lytken, O.; Engbæk, J.; Nielsen, G.; Chorkendorff, I.; Nørskov, J. K. Surf. Sci. 2005, 590, 127−137.
- (50) Nave, S.; Tiwari, A. K.; Jackson, B. J. Chem. Phys. 2010, 132, 054705.
- (51) Jiang, B.; Liu, R.; Li, J.; Xie, D.; Yang, M.; Guo, H. Chem. Sci. 2013, 4, 3249−3254.
- (52) Li, J.; Croiset, E.; Ricardez-Sandoval, L. Chem. Phys. Lett. 2015, 639, 205−210.