# A TRUNCATED REAL INTERPOLATION METHOD AND CHARACTERIZATIONS OF SCREENED SOBOLEV SPACES

#### NOAH STEVENSON AND IAN TICE

ABSTRACT. In this paper we prove structural and topological characterizations of the screened Sobolev spaces with screening functions bounded below and above by positive constants. We generalize a method of interpolation to the case of seminormed spaces. This method, which we call the truncated method, generates the screened Sobolev subfamily and a more general screened Besov scale. We then prove that the screened Besov spaces are equivalent to the sum of a Lebesgue space and a homogeneous Sobolev space and provide a Littlewood-Paley frequency space characterization.

#### 1. Introduction

1.1. **Background.** The study of partial differential equations on unbounded domains is a catalyst for the development of new analytical tools and spaces of functions. One reason for this is that the classical scale of inhomogeneous Sobolev spaces fails to provide a suitable functional setting for PDEs on these domains. This is evident in the basic exterior Dirichlet problem in  $\mathbb{R}^2$ , where  $u(x) = \log |x|$  solves

$$\begin{cases}
-\Delta u = 0 & \text{in } \mathbb{R}^2 \setminus \overline{B(0, e)} \\
u = 1 & \text{on } \partial B(0, e).
\end{cases}$$
(1.1)

While we have that  $u \in \dot{W}^{1,p}(\mathbb{R}^2 \setminus \overline{B(0,e)}) \cap \dot{W}^{2,q}(\mathbb{R}^2 \setminus \overline{B(0,e)})$  for all  $2 and <math>1 < q \le \infty$ , u does not belong to  $L^r(\mathbb{R}^2 \setminus \overline{B(0,e)})$  for any  $1 \le r \le \infty$ .

One approach for dealing with this problem is to switch to weighted inhomogeneous Sobolev spaces: see, for instance [BF79, BS72, EE73, Kuf85, MMS10, Tha02]. An alternative approach is to directly utilize homogeneous Sobolev spaces, but for this to be fruitful in the study of boundary value problems it is essential to know their associated trace spaces. The trace spaces associated to homogeneous Sobolev spaces on infinite strip-like domains of the form  $\{x \in \mathbb{R}^{n+1} : \eta^-(x') < x_{n+1} < \eta^+(x')\}$ , for  $\eta^{\pm} : \mathbb{R}^n \to \mathbb{R}$  Lipschitz with  $\eta^- < \eta^+$ , were recently characterized by Leoni and Tice [LT19]. They used this to characterize the solvability of certain quasilinear elliptic boundary value problems in these domains. This trace theory has also been used in recent studies of the Muskat problem by Nguyen and Pausader [NP20], Nguyen [Ngu19], and Flynn and Nguyen [FN20].

A curious feature of this trace theory is that regularity of the trace function is measured with a fractional Sobolev seminorm involving a screening effect. These screened Sobolev seminorms were first studied by Strichartz [Str16], who proved that the fractional regularity associated to traces of  $\dot{H}^1(\mathbb{R} \times (0,1))$  is characterized by the seminorm

<span id="page-0-0"></span>
$$[f]_{\tilde{H}^{\frac{1}{2}}(\mathbb{R})} = \left( \int_{\mathbb{R}} \int_{(x-1,x+1)} |f(x) - f(y)|^2 |x - y|^{-2} dy dx \right)^{1/2} \text{ for } f \in L^1_{loc}(\mathbb{R}).$$
 (1.2)

Comparing the expression in (1.2) to the seminorm on a homogeneous Sobolev-Slobodeckij space  $\dot{H}^{\frac{1}{2}}(\mathbb{R})$ , one sees that the moniker 'screening' is justified since in the former only small difference quotients are allowed, and larger ones are screened away.

The generalization of this result in [LT19] required the introduction more general seminorms. For an open set  $\emptyset \neq U \subseteq \mathbb{R}^n$ , a lower semicontinuous function  $\sigma: U \to (0, \infty], s \in (0, 1)$  (called the screening

<sup>2010</sup> Mathematics Subject Classification. Primary 46M35, 46E35; Secondary 46A04, 46F05, 46N20.

Key words and phrases. Interpolation of seminormed spaces, screened Sobolev and Besov spaces, Littlewood-Paley.

I. Tice was supported by an NSF CAREER Grant (DMS #1653161). N. Stevenson was supported by the summer research support provided by this grant.

function), and  $1 \leq p < \infty$ , [LT19] defines the screened Sobolev space  $\tilde{W}_{(\sigma)}^{s,p}(U)$  as the collection of locally integrable functions f, defined on U, for which

<span id="page-1-4"></span>
$$[f]_{\tilde{W}_{(\sigma)}^{s,p}} = \left( \int_{U} \int_{B(x,\sigma(x)) \cap U} |f(x) - f(y)|^{p} |x - y|^{-n - sp} \, dy \, dx \right)^{1/p} < \infty.$$
 (1.3)

Variants of these screened spaces have appeared in recent work on fractional Sobolev-type seminorms [BBM01, BBM02, BN18, Pon04, PS17] and in weak formulations of nonlocal elliptic equations [DGLZ12, FKV15, ZD10]. However, the space  $\tilde{W}_{(\sigma)}^{s,p}$  above did not appear in previous literature, so [LT19] established its basic properties: completeness, strict inclusion of  $\dot{W}^{1,p}$ , and a partial frequency space characterization in the case that  $p=2, \sigma=1$ : for  $f \in \mathscr{S}(\mathbb{R}^n; \mathbb{R})$  we have the equivalence

<span id="page-1-0"></span>
$$[f]_{\tilde{W}_{(1)}^{s,2}} \simeq \left( \int_{\mathbb{R}^n} \min\{|\xi|^2, |\xi|^{2s}\} \left| \hat{f}(\xi) \right|^2 d\xi \right)^{1/2}.$$
 (1.4)

Deeper questions related to density, embeddings, traces, a more robust frequency space characterization, and interpolation were left open in [LT19], and a central goal of this paper is to fill that gap.

The key to unlocking these deeper properties is the characterization of the screened spaces in terms of interpolation theory, specifically the real method of abstract interpolation (see [BL76, Lun18, Pee68]). One expects such a characterization, as this is the case for the Sobolev-Slobodeckij and Besov spaces. We refer to the works [AF03, BL76, BIN78, BIN79, Bur98, DNPV12, Gri11, Leo17, Maz11, Neč12, Pee76, Tri78] and their references for a thorough study of these spaces and their interpolation properties. However, the standard methods of abstract interpolation only generate Banach interpolation spaces intermediate to an appropriately compatible pair of Banach spaces. The screened Sobolev spaces are only seminormed spaces with non-Hausdorff topologies and thus, without appropriate modification, interpolation methods cannot generate these spaces. Literature regarding the theory of interpolation of seminormed spaces appears to be sparse, aside from a technical report of Gustavsson [Gus70], which is difficult to find in print.

1.2. **Primary results and discussion.** We survey the principle new results regarding the screened spaces obtained in this paper. For brevity's sake, we do not provide fully detailed statements and only record their abbreviated forms. The proper statements can be found later in the indicated theorems.

In order to study the screened Sobolev spaces, we actually introduce a more general scale of screened Besov spaces,  $\tilde{B}_q^{s,p}(\mathbb{R}^n)$ , for  $s \in (0,1)$  and  $1 \leq p,q \leq \infty$ . See Definition 4.1 for the precise definition. Our first result finds sufficient conditions that identify the screened Sobolev spaces within the screened Besov scale.

**Theorem 1** (Proved in Corollary 4.5). If  $\sigma: \mathbb{R}^n \to \mathbb{R}^+$  is a lower semicontinuous screening function bounded above and below by positive constants,  $s \in (0,1)$ , and  $1 \leq p < \infty$ , then the screened Sobolev space  $\tilde{W}^{s,p}_{(\sigma)}(\mathbb{R}^n)$  is equivalent to the screened Besov space  $\tilde{B}^{s,p}_p(\mathbb{R}^n)$ .

With the established connection between the scales of screened Sobolev and screened Besov spaces, we move to structurally and topologically characterize the latter. We find that there is a method of interpolation of seminormed spaces that generates the screened Besov spaces.

<span id="page-1-1"></span>**Theorem 2** (Proved in Theorem 4.4). There is a method of interpolation of seminormed spaces, called the truncated real-method, that generates the screened Besov spaces as interpolation spaces with respect to a Lebesgue space and a homogeneous Sobolev space.

<span id="page-1-2"></span>The interpolation characterization of the screened Besov spaces leads to the following characterization.

**Theorem 3** (Proved in Theorem 4.9). For  $s \in (0,1)$  and  $1 \leq p, q \leq \infty$ , the screened Besov space  $\tilde{B}_q^{s,p}(\mathbb{R}^n)$  is equivalent to the sum of the inhomogeneous Besov space  $B_q^{s,p}(\mathbb{R}^n)$  and the homogeneous Sobolev space  $\dot{W}^{1,p}(\mathbb{R}^n)$ .

<span id="page-1-3"></span>The sum characterization from the previous theorem allows us to characterize when the subspace of compactly supported smooth functions is dense.

**Theorem 4** (Proved in Corollaries 4.6 and 4.10). For  $1 \leq p, q < \infty$  and  $s \in (0,1)$  the set  $C_c^{\infty}(\mathbb{R}^n)$  is dense in the screened Besov space  $\tilde{B}_q^{s,p}(\mathbb{R}^n)$  if and only if 1 < p or  $2 \leq n$ .

<span id="page-2-0"></span>We next generalize (1.4) by giving a Littlewood-Paley characterization of the screened spaces.

**Theorem 5** (Proved in Corollary 4.14). Let  $1 , <math>1 \le q \le \infty$ ,  $s \in (0,1)$ . For all functions  $f \in \tilde{B}_{g}^{s,p}(\mathbb{R}^{n})$  we have that f is a tempered distribution and that the following equivalence holds:

$$[f]_{\tilde{B}_{q}^{s,p}} \simeq \left\| \left( \sum_{j \in \mathbb{Z} \setminus \mathbb{N}} \left( 2^{j} | \pi_{j} f | \right)^{2} \right)^{1/2} \right\|_{L^{p}} + \left\| \left\{ 2^{sj} \| \pi_{j} f \|_{L^{p}} \right\}_{j \in \mathbb{N}} \right\|_{\ell^{q}(\mathbb{N})}, \tag{1.5}$$

where  $\{\pi_j\}_{j\in\mathbb{Z}}$  are a family of dyadic localization operators, as in Definition 3.2.

<span id="page-2-1"></span>Theorem 5 follows from a somewhat more general result that provides a Littlewood-Paley characterization of the interpolant between two Riesz potential spaces,  $\dot{H}^{r_i,p}(\mathbb{R}^n)$  for  $i \in \{1,2\}$  (see Definition 3.11).

**Theorem 6** (Proved in Theorem 4.12). Let  $1 , <math>1 \le q \le \infty$ ,  $\alpha \in (0,1)$ ,  $\sigma \in \mathbb{R}^+$ , and  $r,s \in \mathbb{R}$  with r < s. Set  $t = (1 - \alpha)r + \alpha s$ . Then the interpolation space  $(\dot{H}^{r,p}(\mathbb{R}^n), \dot{H}^{s,p}(\mathbb{R}^n))_{\alpha,q}^{(\sigma)}$  is characterized by the Littlewood-Paley seminorm

$$f \mapsto \left\| \left( \sum_{j \in \mathbb{Z} \setminus \mathbb{N}} \left( 2^{sj} | \pi_j f | \right)^2 \right)^{1/2} \right\|_{L^p} + \left\| \left\{ 2^{tj} \| \pi_j f \|_{L^p} \right\}_{j \in \mathbb{N}} \right\|_{\ell^q(\mathbb{N}; \mathbb{R})}. \tag{1.6}$$

The interesting feature of Theorems 5 and 6 is that the Littlewood-Paley characterization changes form between low frequencies and high frequencies. For low frequencies, a Triebel-Lizorkin type of seminorm arises, but for high frequencies it is of Besov type. Note also that the power  $2^{sj}$  in the low frequencies is inherited from the second factor in the interpolation. This explains why the low frequency Fourier multiplier in (1.4),  $|\xi|^2$ , matches that associated to  $\dot{H}^1(\mathbb{R}^n)$ .

Our final result concerns embedding and restriction (trace) results for these spaces.

**Theorem 7** (Proved in Section 4.5 and Theorem 4.20). The screened Besov spaces enjoy various embeddings, and, provided that  $n \ge 2$ ,  $1 , <math>1 \le q \le \infty$ , and  $p^{-1} < s < 1$ , they admit well-defined restriction operators with continuous right-inverses.

Broadly speaking, our strategy for proving the above results is to take the analytical high road: these results are consequences of our development of a more general abstract theory. We begin the paper, in Section 2, with the development of interpolation methods of seminormed spaces in the abstract. Recall that the K-method for Banach spaces takes a pair of spaces  $X_0$  and  $X_1$  and constructs their intermediate s,q-interpolation space,  $(X_0,X_1)_{s,q}$ , as the collection of all elements x belonging to the sum of  $X_0$  and  $X_1$  for which the map  $\mathbb{R}^+ \ni t \mapsto t^{-s}K(t,x) \in \mathbb{R}$  belongs to  $L^q(\mathbb{R}^+;\mu)$ , were  $\mu$  is the Haar measure associated to the multiplicative group on  $\mathbb{R}^+$  (see Section 1.3). We find that this K-method is not quite right to produce the screened spaces as interpolation spaces. However, it is nearly correct. We need only consider a slight generalization to seminormed spaces and allow for a larger family of domains of integration.

For a parameter  $\sigma \in (0, \infty]$  we study the 'truncated' interpolation space  $(Y_0, Y_1)_{s,q}^{(\sigma)}$  with respect to seminormed spaces  $Y_0$  and  $Y_1$ . The truncated spaces are characterized as the set of y belonging to the sum of  $Y_0$  and  $Y_1$  for which the map  $(0, \sigma) \ni t \mapsto t^{-s}K(t, y) \in \mathbb{R}$  belongs to  $L^q((0, \sigma), \mu)$ . We find that for  $\sigma = \infty$  the seminormed interpolation mirrors that of the interpolation theory of Banach spaces, with only a few more subtleties regarding notions of compatibility. On the other hand, when  $\sigma < \infty$  the truncated method does give interpolation spaces; however it is interestingly asymmetric in the roles of  $Y_0$  and  $Y_1$ . The upshot of studying these methods of abstract seminormed interpolation is that we obtain a general relationship between the methods for  $\sigma < \infty$  and  $\sigma = \infty$ . More precisely, in Theorem 2.26 we find an abstract sum characterization: for  $\sigma < \infty$  the truncated interpolation space  $(Y_0, Y_1)_{s,q}^{(\sigma)}$  is equivalent to the sum of  $(Y_0, Y_1)_{s,q}^{(\infty)}$  and the second factor,  $Y_1$ .

Section 3 is a three-fold development of vital analytical tools utilized in the later study of screened Sobolev and screened Besov spaces. The inspiration for this section is the Littlewood-Paley theory in Chapter 6 of [Gra14a], the applications of harmonic analysis to study smoothness in Chapter 1 of [Gra14b], and the interpolation of Sobolev and Besov spaces in Chapter 6 of [BL76]. First, we define the homogeneous Sobolev spaces and the Riesz potential spaces. The latter is a two parameter space,  $\dot{H}^{s,p}(\mathbb{R}^n)$ , for  $s \in \mathbb{R}$  and 1 (see Definition 3.11) where, roughly speaking, a tempered distribution <math>f belongs to  $\dot{H}^{s,p}(\mathbb{R}^n)$  if  $[|\cdot|^s \hat{f}]^\vee$  defines a function in  $L^p(\mathbb{R}^n)$ . Note that this scale is intimately related to the homogeneous

Sobolev spaces; however, we work directly with seminorms rather than quotient by polynomials to obtain a normed space. We prove a frequency space characterization of  $\dot{W}^{1,p}(\mathbb{R}^n)$  that says that the former space is essentially equivalent to the Riesz potential space  $\dot{H}^{1,p}(\mathbb{R}^n)$ . We then pair this with a Littlewood-Paley decomposition of the Riesz potential spaces to deduce a Littlewood-Paley characterization of the homogeneous Sobolev space  $\dot{W}^{1,p}(\mathbb{R}^n)$ .

Next, we study the  $L^p$ -modulus of continuity and its relationship with the K-functional on the sum of  $L^p(\mathbb{R}^n)$  and  $\dot{W}^{1,p}(\mathbb{R}^n)$ . Having established this, we use the interpolation of seminormed spaces developed in Section 2 to show that the homogeneous Besov spaces (see Definition 3.15),  $\dot{B}_q^{s,p}(\mathbb{R}^n)$ , are generated via  $\left(L^p(\mathbb{R}^n), \dot{W}^{1,p}(\mathbb{R}^n)\right)_{s,q}^{(\infty)}$  for  $s \in (0,1)$  and  $1 \leqslant q \leqslant \infty$ .

As a final development in Section 3, we explore the homogeneous Besov-Lipschitz scale of spaces,

As a final development in Section 3, we explore the homogeneous Besov-Lipschitz scale of spaces,  $\wedge \dot{B}_{q}^{s,p}(\mathbb{R}^{n})$  with parameters  $s \in \mathbb{R}$ ,  $1 , and <math>1 \le q \le \infty$  (see Definition 3.19). With the Littlewood-Paley decomposition of the Riesz-Potential spaces, we see that the theory of seminorm interpolation realizes the equivalence:  $\wedge \dot{B}_{q}^{r,p}(\mathbb{R}^{n}) = (\dot{H}^{s,p}(\mathbb{R}^{n}), \dot{H}^{t,p}(\mathbb{R}^{n}))_{\alpha,q}^{(\infty)}$  for  $r = (1 - \alpha)s + \alpha t$ . This interpolation result, supplemented with the interpolation characterization of the homogeneous Besov spaces, reveals a Littlewood-Paley characterization of the latter scale.

Section 4 synthesizes the abstract seminormed space interpolation of Section 2 and the analysis of Section 3 to obtain a deeper understanding of the screened Sobolev spaces. First we generalize the scale of screened Sobolev spaces by defining the screened Besov spaces in Definition 4.1. Having already developed the homogeneous Besov spaces and the connection between the  $L^p$  modulus of continuity and the K-functional associated to the sum of  $L^p(\mathbb{R}^n)$  and  $\dot{W}^{1,p}(\mathbb{R}^n)$ , the claims in Theorem 2 above are now immediate. Then the abstract sum characterization of the truncated interpolation method gives, with a little more work, Theorems 3 and 4. We next apply the truncated interpolation method to general pairs of Riesz potential spaces and from this analysis we obtain the claims of Theorem 5. Finally, we use the sum characterization of the screened Besov spaces to quickly read off some results on embeddings and traces.

<span id="page-3-1"></span>1.3. Conventions of notation. We record our conventions of notation used throughout this paper. The number sets  $\mathbb{N}$ ,  $\mathbb{Z}$ ,  $\mathbb{R}$ , and  $\mathbb{C}$  are the natural numbers, integers, reals, and complex numbers, respectively. We assume that  $0 \in \mathbb{N}$  and write  $\mathbb{N}^+ = \mathbb{N} \setminus \{0\}$  and  $\mathbb{R}^+ = (0, \infty)$ . In writing  $\mathbb{R}^n$  we always assume  $n \in \mathbb{N}^+$ .

Throughout the paper we denote the field  $\mathbb{K} \in \{\mathbb{R}, \mathbb{C}\}$ . The spaces of rapidly decreasing and analytic functions taking values in  $\mathbb{K}$  are denoted by  $\mathscr{S}(\mathbb{R}^n;\mathbb{K})$  and  $C^\omega(\mathbb{R}^n;\mathbb{K})$ , respectively. The space of tempered distributions valued in  $\mathbb{K}$  is denoted  $\mathscr{S}^*(\mathbb{R}^n;\mathbb{K})$ . The Fourier transform is denoted either as  $\hat{\cdot}$  or  $\mathscr{F}$ . For  $0 < \alpha \leqslant 1$ , the homogeneous Hölder space (homogeneous Lipschitz space when  $\alpha = 1$ )  $\dot{C}^{0,\alpha}(\mathbb{R}^n;\mathbb{K})$  is the space of functions  $f: \mathbb{R}^n \to \mathbb{K}$  such that  $[f]_{\dot{C}^{0,\alpha}} = \sup\{|f(x) - f(y)| / |x - y|^\alpha : x, y \in \mathbb{R}^n, x \neq y\} < \infty$ .

We let  $\mu$  denote the standard Haar measure with respect to the multiplicative structure on  $\mathbb{R}^+$ , i.e.  $\mu(E) = \int_{\mathbb{R}^+} \chi_E(t) t^{-1} dt$  for Lebesgue measurable sets  $E \subseteq \mathbb{R}^+$ . The *n*-dimensional Lebesgue measures and *s*-dimensional Hausdorff measures are denoted  $\mathfrak{L}^n$  and  $\mathcal{H}^s$ , respectively. Moreover we choose the normalization of  $\mathcal{H}^s$  so that when s = n we have  $\mathcal{H}^n = \mathfrak{L}^n$ .

Finally, whenever the expression  $a \lesssim b$  appears in a proof of a result, it means that there is a constant  $C \in \mathbb{R}^+$ , depending only on the parameters quantified in the statement of the result such that  $a \leqslant Cb$ . We may sharpen this by occasionally writing the explicit dependence of the constant C as a subscript on  $\lesssim$ , i.e.  $a \lesssim_{s,p,q} b$ . We write  $a \asymp b$  to mean  $a \lesssim b$  and  $b \lesssim a$ .

## 2. Interpolation of seminormed spaces

<span id="page-3-0"></span>In this section we present two distinct methods of generating interpolation spaces intermediate to a pair of seminormed spaces satisfying certain compatibility conditions. Both generalize known methods of interpolating between couples of Banach spaces. The first method is a seminorm generalization of the well-known 'real method of interpolation' (see for instance, the paper [Pee68], Chapter 3 in [BL76], or Chapter 1 in [Tri78, Lun18]), and as such we refer to this method as the real method of interpolation of seminormed spaces. The real seminorm method has its origins in the work of Gustavsson [Gus70], and here we essentially follow his approach, with a few embellishments.

The second method, which we call the truncated real method, generates spaces in a seemingly similar way to the real method; however, it is bizarrely asymmetric and generates larger spaces than the non-truncated

method. The truncated method has its origins in the work of Gomez and Milman [GM86], who employed it to study the extreme parameter regime of Peetre's interpolation theory for nested Banach spaces, with the aim of proving certain estimates for singular integral operators. A more thorough study of the interpolation properties of the limiting spaces in the nested case commenced with the paper of Cobos, Fernández-Cabrera, Kühn, and Ullrich [CFCKU09]. Recent work of Astashkin, Lykov, and Milman [ALM19] removed the nested assumption, considered a more general parameter regime, and uncovered a deep connection between extrapolation theory (see the book of Jawerth and Milman [JM91]) and the limiting case of the real method. We were led to consider a seminorm version of this theory in studying the trace theory of homogeneous Sobolev spaces on certain unbounded domains.

The spaces obtained from the non-truncated method appear crucially at a few points in the truncated theory, so it is important for us to have a careful enumeration of their properties. The technical report [Gus70] is not available in journals or online, so we have recorded a number of its results below and indicated how to obtain the proofs from the arguments used in the second method.

A concise review of relevant topological notions in seminormed spaces is presented in Appendix A. Throughout the following section all generic seminormed spaces are over a fixed common field - either real or complex.

2.1. **Topology of compatible couples.** We begin by exploring notions of compatibility of seminormed spaces. In this first subsection we consider what happens when two seminormed spaces are simultaneously contained within some larger vector space. We can then consider their sum and intersection and give each of those a seminorm in a natural way.

<span id="page-4-0"></span>**Definition 2.1** (Compatibility of seminormed spaces). Suppose that  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  are seminormed spaces.

- (1) We say that they are a strongly compatible pair if there exists a topological vector space (Y, τ) such that X<sub>i</sub> → Y for i ∈ {0,1}, and 𝔄(Y) = 𝔄(X<sub>0</sub>) ∪ 𝔄(X<sub>1</sub>), where the annihilator 𝔄 is defined in Definition A.1. Note that, due to Proposition A.4, the second condition implies that either 𝔄(X<sub>0</sub>) ⊆ 𝔄(X<sub>1</sub>) or 𝔇(X<sub>1</sub>) ⊆ 𝔇(X<sub>0</sub>).
- (2) We say that  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  are a weakly compatible pair if there is a vector space Y with  $X_0, X_1 \subseteq Y$ . Note that every strongly compatible pair is automatically a weakly compatible pair.
- (3) In the case that  $X_0$  and  $X_1$  are either a strong or weak compatible pair of seminormed spaces we form their sum and their intersection in the usual way:

$$\Sigma(X_0, X_1) = \{x \in Y : \exists (x_0, x_1) \in X_0 \times X_1, \ x = x_0 + x_1\} \ \text{and} \ \Delta(X_0, X_1) = X_0 \cap X_1.$$

$$\text{We endow these spaces with the seminorms } [\cdot]_{\Sigma} : \Sigma(X_0, X_1) \to \mathbb{R} \ \text{and } [\cdot]_{\Delta} : \Delta(X_0, X_1) \to \mathbb{R} \ \text{defined has}$$

$$[x]_{\Sigma} = \inf \left\{ [x_0]_0 + [x_1]_1 \ : \ (x_0, x_1) \in X_0 \times X_1, \ x = x_0 + x_1 \right\} \ \ and \ \ [x]_{\Delta} = \max \left\{ [x]_0 \, , [x]_1 \right\}. \tag{2.2}$$

Observe that we have the continuous embeddings  $\Delta(X_0, X_1) \hookrightarrow X_i \hookrightarrow \Sigma(X_0, X_1)$  for each  $i \in \{0, 1\}$ .

<span id="page-4-1"></span>**Definition 2.2** (Intermediate and interpolation spaces). Suppose that  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  are a weakly compatible couple of seminormed spaces.

- (1) We say that a seminormed space  $(Y, [\cdot])$  is intermediate with respect to the couple  $(X_0, [\cdot]_0)$ ,  $(X_1, [\cdot]_1)$  if it holds that  $\Delta(X_0, X_1) \hookrightarrow Y \hookrightarrow \Sigma(X_0, X_1)$ .
- (2) Suppose that  $(Y_0, [\cdot]_0)$  and  $(Y_1, [\cdot]_1)$  are another weakly compatible couple of seminormed spaces, and that  $(X, [\cdot]_X)$  and  $(Y, [\cdot]_Y)$  are another pair seminormed spaces, with  $X \subseteq \Sigma(X_0, X_1)$  and  $Y \subseteq \Sigma(Y_0, Y_1)$ . We say that X and Y are a pair of interpolation spaces if for every linear map  $T: \Sigma(X_0, X_1) \to \Sigma(Y_0, Y_1)$  that is continuous with values in  $Y_i$  when restricted to  $X_i$ ,  $i \in \{0, 1\}$ , it holds that  $TX \subseteq Y$  and  $T: X \to Y$  is continuous.

<span id="page-4-2"></span>The definition of strong compatibility that we give ensures that the intersection of a compatible couple behaves well with respect to completeness.

**Proposition 2.3.** Suppose that  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  are a weakly compatible pair of semi-Banach spaces. Then the space  $(\Sigma(X_0, X_1), [\cdot]_{\Sigma})$  is semi-Banach. If we assume that the pair is strongly compatible, then  $(\Delta(X_0, X_1), [\cdot]_{\Lambda})$  is semi-Banach.

*Proof.* If  $\{x_k\}_{k=0}^{\infty} \subset \Delta(X_0, X_1)$  is Cauchy, then the continuous embedding  $\Delta(X_0, X_1) \hookrightarrow X_i$  for  $i \in \{0, 1\}$  paired with completeness of  $X_i$  implies that there are  $(a, b) \in X_0 \times X_1$  such that

<span id="page-5-1"></span>
$$\lim_{k \to \infty} ([x_k - a]_0 + [x_k - b]_1) = 0.$$
(2.3)

By definition of strongly admissible pair, there is some topological vector space Y such that  $X_0, X_1 \hookrightarrow Y$  and  $\mathfrak{A}(Y) = \mathfrak{A}(X_0) \cup \mathfrak{A}(X_1)$ . Hence  $x_k \to a, b$  as  $k \to \infty$  in Y as  $k \to \infty$ . Thus, by Proposition A.2,  $a - b \in \mathfrak{A}(Y) = \mathfrak{A}(X_0) \cup \mathfrak{A}(X_1)$ . Let's handle the case that  $a - b \in \mathfrak{A}(X_0)$  (the other case is similar). Then,  $b = a + (b - a) \in X_0 + \mathfrak{A}(X_0) \subseteq X_0$ , and hence  $b \in \Delta(X_0, X_1)$ . Moreover for any  $k \in \mathbb{N}$  we have the bound

<span id="page-5-0"></span>
$$[x_k - b]_{\Delta} \leqslant [x_k - b]_0 + [x_k - b]_1 \leqslant [b - a]_0 + [x_k - a]_0 + [x_k - b]_1 = [x_k - a]_0 + [x_k - b]_1. \tag{2.4}$$

Thus (2.4) paired with (2.3) shows that  $x_k \to b$  in  $\Delta(X_0, X_1)$ , showing this space to be complete.

To prove completeness of  $\Sigma(X_0, X_1)$ , we use Lemma A.7. Suppose that  $\{x_k\}_{k=0}^{\infty} \subset \Sigma(X_0, X_1)$  is a sequence such that  $\sum_{k=0}^{\infty} [x_k]_{\Sigma} < \infty$ . For each  $k \in \mathbb{N}$ , we can find, by the definition of the seminorm on  $\Sigma(X_0, X_1)$ , a pair  $(a_k, b_k) \in X_0 \times X_1$  for which  $a_k + b_k = x_k$  and  $[a_k]_0 + [b_k]_1 \leqslant 2^{-k} + [x_k]_{\Sigma}$ . Summing over k in the inequality reveals that  $-2 + \sum_{k=0}^{\infty} [a_k]_0 + \sum_{k=0}^{\infty} [b_k]_1 \leqslant \sum_{k=0}^{\infty} [x_k]_{\Sigma} < \infty$ . Consequently, there are  $(a, b) \in X_0 \times X_1$  for which  $\lim_{K \to \infty} \left[ -a + \sum_{k=0}^K a_k \right]_0 = 0$  and  $\lim_{K \to \infty} \left[ -b + \sum_{k=0}^K b_k \right]_1 = 0$ . Set  $x = a + b \in \Sigma(X_0, X_1)$ . For any  $K \in \mathbb{N}$  we may then estimate  $\left[ -x + \sum_{k=0}^K x_k \right]_{\Sigma} \leqslant \left[ -a + \sum_{k=0}^K a_k \right]_0 + \left[ -b + \sum_{k=0}^K b_k \right]_1$ . As  $K \to \infty$ , the previous right hand side vanishes, completing the proof.

<span id="page-5-2"></span>We can also say something about the annihilators of the sum and intersection.

**Proposition 2.4** (Annihilators of sum and intersection). Suppose that  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  are a pair of weakly admissible seminormed spaces. Then  $\mathfrak{A}(\Delta(X_0, X_1)) = \Delta(\mathfrak{A}(X_0), \mathfrak{A}(X_1))$ . Also, we have the inclusion  $\Sigma(\mathfrak{A}(X_0), \mathfrak{A}(X_1)) \subseteq \mathfrak{A}(\Sigma(X_0, X_1))$ , and if if we additionally assume that  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  are strongly compatible or  $\Delta(X_0, X_1)$  is semi-Banach, then equality holds.

*Proof.* The first assertion is trivial, so we only prove the second. If  $x \in \Sigma(\mathfrak{A}(X_0), \mathfrak{A}(X_1))$ , then there are  $(x_0, x_1) \in \mathfrak{A}(X_0) \times \mathfrak{A}(X_1)$  such that  $x = x_0 + x_1$ . Hence  $0 \leq [x]_{\Sigma} \leq [x_0]_0 + [x_1]_1 = 0$ , and the inclusion is shown.

Suppose first that the pair of seminormed spaces are strongly admissible. Thus we may find  $(Y,\tau)$  a topological vector space such that  $\forall i \in \{0,1\}$  we have  $X_i \hookrightarrow Y$ , and  $\mathfrak{A}(Y) = \mathfrak{A}(X_0) \cup \mathfrak{A}(X_1)$ . Thus, if  $x \in \mathfrak{A}(\Sigma(X_0, X_1))$ , then we may find sequences  $\{y_m\}_{m \in \mathbb{N}} \subset X_0$  and  $\{z_m\}_{m \in \mathbb{N}} \subset X_1$  such that  $x = y_m + z_m$  for all  $m \in \mathbb{N}$ , and  $[y_m]_0 + [z_m]_1 \leq 2^{-m}$  for  $m \in \mathbb{N}$ . The continuous embeddings  $X_0, X_1 \hookrightarrow Y$  imply that  $y_m, z_m \to 0$  in Y as  $m \to \infty$ , and hence  $x \in \mathfrak{A}(Y) \subseteq \Sigma(\mathfrak{A}(X_0), \mathfrak{A}(X_1))$ .

Suppose next that  $\Delta(X_0, X_1)$  is semi-Banach, in which case we employ an argument from [Gus70]. Let  $x \in \mathfrak{A}(\Sigma(X_0, X_1))$ . Then for each  $n \in \mathbb{N}$ , we can find a decomposition of x with the following property:

$$x = y_n + z_n, (y_n, z_n) \in X_0 \times X_1, [y_n]_0 + [z_n]_1 \le 2^{-n}.$$
 (2.5)

Observe that for  $n \in \mathbb{N}$  we have  $w_n = y_n - y_0 = z_0 - z_n \in \Delta(X_0, X_1)$ . Hence, for  $m, n \in \mathbb{N}$  we may estimate:

$$[w_n - w_m]_{\Delta} = [(y_n - y_0) - (y_m - y_0)]_{\Delta} = \max\{[y_n - y_m]_0, [z_n - z_m]_1\} \leqslant 2^{-m} + 2^{-n}.$$
 (2.6)

Then  $\{w_n\}_{n\in\mathbb{N}}\subseteq \Delta\left(X_0,X_1\right)$  is Cauchy. Since  $\Delta\left(X_0,X_1\right)$  is semi-Banach by hypothesis, there is  $w\in\Delta\left(X_0,X_1\right)$  such that  $w_n\to w$  as  $n\to\infty$  in  $\Delta\left(X_0,X_1\right)$ . Now we observe that  $y_0+w\in X_0,\,z_0-w\in X_1,$  and  $(y_0+w)+(z_0-w)=x$ . For  $n\in\mathbb{N}$  it holds that

$$\begin{cases} [y_0 + w]_0 \leqslant [y_0 + w_n]_0 + [w - w_n]_{\Delta} \leqslant 2^{-n} + [w - w_n]_{\Delta} \\ [z_0 - w]_1 \leqslant [z_0 - w_n]_1 + [w_n - w]_{\Delta} \leqslant 2^{-n} + [w - w_n]_{\Delta} \end{cases} \to 0 \quad \text{as} \quad n \to \infty.$$
 (2.7)

Hence  $x \in \Sigma (\mathfrak{A}(X_0), \mathfrak{A}(X_1))$ , as desired.

This result tells us that one of the downsides to having a weak, but not strong, compatible pair is that the annihilator of the sum may grow larger than one desires.

<span id="page-6-0"></span>2.2. The K-methods. We define the K-functional in the same way as the normed space theory.

**Definition 2.5** (K-functional). Given  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$ , a weakly compatible pair of seminormed spaces (see Definition 2.1), we define the functional  $\mathscr{K}: \mathbb{R}^+ \times \Sigma(X_0, X_1) \to \mathbb{R}$  via

$$\mathcal{K}(t,x) = \inf\left\{ [x_0]_0 + t [x_1]_1 : (x_0, x_1) \in X_0 \times X_1, \ x = x_0 + x_1 \right\}. \tag{2.8}$$

<span id="page-6-1"></span>The following proposition contains the most basic properties of the K-functional from Definition 2.5.

**Proposition 2.6.** Given a weakly compatible pair of seminormed spaces  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$ , the following hold:

- (1)  $\forall t \in \mathbb{R}^+$ ,  $\mathscr{K}(t,\cdot)$  is a seminorm on  $\Sigma(X_0,X_1)$ , and  $\mathscr{K}(1,\cdot) = [\cdot]_{\Sigma}$ .
- (2) For all  $x \in \Sigma(X_0, X_1)$  and for all  $t, s \in \mathbb{R}^+$  we have the estimates

$$\min\left\{1, t/s\right\} \mathcal{K}\left(s, x\right) \leqslant \mathcal{K}\left(t, x\right) \leqslant \max\left\{1, t/s\right\} \mathcal{K}\left(s, x\right). \tag{2.9}$$

(3)  $\forall x \in \Sigma(X_0, X_1)$ , the mapping  $\mathbb{R}^+ \ni t \mapsto \mathscr{K}(t, x) \in \mathbb{R}$  is concave, increasing, and measurable.

*Proof.* These three items are immediate from the definition of  $\mathcal{K}$ .

Using the K-functional, we can define the following families of extended seminorms on the sum.

**Definition 2.7** (K-methods' interpolation spaces). Let  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  be a weakly compatible pair of seminormed spaces,  $s \in (0,1), \ 1 \leqslant q \leqslant \infty, \ \sigma \in (0,\infty]$ . We define  $[\cdot]_{s,q}^{(\sigma)} : \Sigma(X_0,X_1) \to [0,\infty]$  via

$$[x]_{s,q}^{(\sigma)} = \left(\int_{(0,\sigma)} \left(t^{-s} \mathcal{K}(t,x)\right)^q t^{-1} dt\right)^{1/q} \text{ if } q < \infty, \text{ and } \sup\left\{t^{-s} \mathcal{K}(t,x) : t \in (0,\sigma)\right\} \text{ when } q = \infty.$$
(2.10)

We define the K-methods' interpolation spaces to be the sets  $(X_0, X_1)_{s,q}^{(\sigma)} = \{x \in \Sigma (X_0, X_1) : [x]_{s,q}^{(\sigma)} < \infty \}$ , which are a vector spaces thanks to Proposition 2.6 and Minkowski's inequality on  $L^q((0,\sigma),\mu)$  ( $\mu$  is as in Section 1.3). Moreover, we equip the space  $(X_0, X_1)_{s,q}^{(\sigma)}$  with the seminorm  $[\cdot]_{s,q}^{(\sigma)}$ .

In the case that  $\sigma = \infty$ , we often write  $(X_0, X_1)_{s,q}$  and  $[\cdot]_{s,q}$  in place of  $(X_0, X_1)_{s,q}^{(\infty)}$  and  $[\cdot]_{s,q}^{(\infty)}$ . This is in agreement with the existing notation for the usual K-method on normed vector spaces. In the case that  $\sigma < \infty$ , we also refer to this method of generating spaces as the truncated method of interpolation.

2.3. Basic properties. We now study basic properties of the K-methods of interpolation. In particular, we will prove that they are intermediate and interpolation spaces in the sense of Definition 2.2, then we study various inclusion, embedding, and completeness properties, and finally we exhibit equivalent discrete seminorms. Along the way, we will see that for fixed s and q, the K-methods' interpolation spaces are only topologically distinct for  $\sigma$  finite and  $\sigma$  infinite.

<span id="page-6-2"></span>**Proposition 2.8** (K-method spaces are intermediate). Suppose that  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  are a weakly compatible pair of seminormed spaces. Then for all  $s \in (0,1)$ ,  $\sigma \in (0,\infty]$ , and  $1 \leqslant q \leqslant \infty$ , we have continuous embeddings:  $\Delta(X_0, X_1) \hookrightarrow (X_0, X_1)_{s,q}^{(\sigma)} \hookrightarrow \Sigma(X_0, X_1)$ .

*Proof.* We only prove the case that  $\sigma < \infty$ , as the case  $\sigma = \infty$  is proved in the exact same way as the real method of interpolation of normed vector spaces.

First we consider the case when  $q = \infty$ . Then for any  $x \in \Delta(X_0, X_1)$  and any  $t \in (0, \sigma)$ , we have the estimate  $\mathscr{K}(t,x) \leqslant \min\{1,t\}[x]_{\Delta}$ . Hence  $[x]_{s,\infty}^{(\sigma)} \leqslant \min\{1,\sigma^{1-s}\}[x]_{\Delta}$ . If now  $x \in (X_0,X_1)_{s,\infty}^{(\sigma)}$ , we use the fact that for  $t \in (0, \sigma)$   $\mathcal{K}(t, x) \geqslant \min\{1, t\} [x]_{\Sigma}$ . Hence  $[x]_{s, \infty}^{(\sigma)} \geqslant \min\{1, \sigma^{1-s}\} [x]_{\Sigma}$ . Next, we handle  $1 \leqslant q < \infty$ . If  $x \in \Delta(X_0, X_1)$  we can use the same estimate as before:

$$[x]_{s,q}^{(\sigma)} = \left(\int_{(0,\sigma)} \left(t^{-s} \mathcal{K}(t,x)\right)^q t^{-1} dt\right)^{1/q} \leqslant [x]_{\Delta} \left(\int_{(0,\sigma)} \min\left\{t^{-sq}, t^{q(1-s)}\right\} t^{-1} dt\right)^{1/q} = C_{s,q,\sigma}[x]_{\Delta}. \tag{2.11}$$

And if  $x \in (X_0, X_1)_{s,a}^{(\sigma)}$  we obtain:

$$[x]_{s,q}^{(\sigma)} = \left(\int_{(0,\sigma)} \left(t^{-s} \mathcal{K}(t,x)\right)^q t^{-1} dt\right)^{1/q} \geqslant [x]_{\Sigma} \left(\int_{(0,\sigma)} \min\left\{t^{-sq}, t^{q(1-s)}\right\} t^{-1} dt\right)^{1/q} = C_{s,q,\sigma}[x]_{\Sigma}.$$
(2.12)

This completes the proof.

<span id="page-7-4"></span>Next, we show that the K-methods' interpolation spaces preserve completeness.

**Proposition 2.9.** Suppose that  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  are a weakly compatible pair of semi-Banach spaces. Then for all  $\sigma \in (0, \infty]$ ,  $s \in (0, 1)$ , and  $1 \leq q \leq \infty$  the seminormed space  $((X_0, X_1)_{s,q}^{(\sigma)}, [\cdot]_{s,q}^{(\sigma)})$  is semi-Banach.

Proof. We again only prove the case for  $\sigma < \infty$ , as the case for  $\sigma = \infty$  follows with a similar argument. We verify completeness through the series characterization in Lemma A.7. Let  $\{x_k\}_{k=0}^{\infty} \subset (X_0, X_1)_{s,q}^{(\sigma)}$  be a sequence such that  $\sum_{k=0}^{\infty} [x_k]_{s,q}^{(\sigma)} < \infty$ . By Proposition 2.8 it follows that  $\sum_{k=0}^{\infty} [x_k]_{\Sigma} < \infty$ . Then, Proposition 2.3 implies that there exists  $x \in \Sigma(X_0, X_1)$  such that  $\lim_{K \to \infty} \left[ -x + \sum_{k=0}^K x_k \right]_{\Sigma} = 0$ . For  $K, M \in \mathbb{N}$  with M > K we may use Proposition 2.6 to bound

<span id="page-7-0"></span>
$$\mathcal{K}\left(t, -x + \sum_{k=0}^{K} x_k\right) \leqslant \mathcal{K}\left(t, -x + \sum_{k=0}^{M} x_k\right) + \sum_{k=K+1}^{M} \mathcal{K}\left(t, x_k\right), \tag{2.13}$$

<span id="page-7-1"></span>

and since  $\mathcal{K}(t,\cdot)$  is an equivalent seminorm on  $\Sigma(X_0,X_1)$  we may send  $M\to\infty$  in (2.13) and then multiply by  $t^{-s}$  to deduce that  $t^{-s}\mathcal{K}(t,-x+\sum_{k=0}^K x_k)\leqslant \sum_{k=K+1}^\infty t^{-s}\mathcal{K}(t,x_k)$ , for all  $K\in\mathbb{N}$  and all  $t\in(0,\sigma)$ . In the case that  $q=\infty$  we deduce immediately that  $[-x+\sum_{k=0}^K x_k]_{s,\infty}^{(\sigma)}\leqslant \sum_{k=K+1}^\infty [x_k]_{s,\infty}^{(\sigma)}$ . Hence  $x\in(X_0,X_1)_{s,\infty}^{(\sigma)}$ . Since the right-hand-side tends to zero as  $K\to\infty$ , completeness is established in this case.

We now consider the case  $1 \leq q < \infty$ . For  $b \in \mathbb{N}^+$  with  $2^{-b} < \sigma$  we integrate (2.13), apply Minkowski's inequality, and employ the bound  $\mathscr{K}(t,\cdot) \leq \max\{1,t^{-1}\}$  [:]<sub> $\Sigma$ </sub> (see Proposition 2.6) to estimate:

$$\left(\int_{\left(2^{-b},\sigma\right)} \left(t^{-s} \mathcal{K}\left(t, -x + \sum_{k=0}^{K} x_{k}\right)\right)^{q} t^{-1} dt\right)^{1/q} \leqslant \left(\int_{\left(2^{-b},\sigma\right)} \left(t^{-s} \mathcal{K}\left(t, -x + \sum_{k=0}^{M} x_{k}\right)\right)^{q} t^{-1} dt\right)^{1/q} 
+ \sum_{k=K+1}^{M} \left(\int_{\left(2^{-b},\sigma\right)} \left(t^{-s} \mathcal{K}\left(t, x_{k}\right)\right)^{q} \frac{1}{t} dt\right)^{1/q} \leqslant C_{b} \left[-x + \sum_{k=0}^{M} x_{k}\right]_{\Sigma} + \sum_{k=K+1}^{\infty} \left[x_{k}\right]_{s,q}^{(\sigma)}. \quad (2.14)$$

The number  $C_b = \left(\int_{\left(2^{-b},\sigma\right)} \max\left\{t^{-qs},t^{q(1-s)}\right\}t^{-1} dt\right)^{1/q}$  is finite, so we may send  $M \to \infty$  in (2.14) and use the convergence in  $\Sigma(X_0,X_1)$  to see that

<span id="page-7-2"></span>
$$\left(\int_{\left(2^{-b},\sigma\right)} \left(t^{-s} \mathcal{K}\left(t, -x + \sum_{k=0}^{K} x_k\right)\right)^q t^{-1} dt\right)^{1/q} \leqslant \sum_{k=K+1}^{\infty} \left[x_k\right]_{s,q}^{(\sigma)}.$$
 (2.15)

Letting  $b \to \infty$  and using the monotone convergence theorem shows that (2.15) continues to hold with 0 in place of  $2^{-b}$ . Hence  $x \in (X_0, X_1)_{s,q}^{(\sigma)}$ . Finally, sending  $K \to \infty$  shows that  $[-x + \sum_{k=0}^K x_k]_{s,q}^{(\sigma)} \to 0$ , and we conclude that the space  $(X_0, X_1)_{s,q}^{(\sigma)}$  is complete.

<span id="page-7-3"></span>We now examine the inclusion relations among the interpolation and truncated interpolation spaces.

**Proposition 2.10** (Inclusions and embeddings of K-methods' spaces). Suppose that  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  are a weakly compatible pair of seminormed spaces,  $s \in (0,1)$ ,  $1 \le p,q \le \infty$ , and  $\sigma \in (0,\infty]$ ,  $\rho \in \mathbb{R}^+$ . The following hold:

- (1) We have the continuous embedding  $(X_0, X_1)_{s,q} = (X_0, X_1)_{s,q}^{(\infty)} \hookrightarrow (X_0, X_1)_{s,q}^{(\rho)}$ . Moreover, for all  $x \in (X_0, X_1)_{s,q}$  we have that  $[x]_{s,q}^{(\rho)} \leqslant [x]_{s,q}$ .
- (2) If  $\sigma < \infty$ , then we have the equality of spaces,  $(X_0, X_1)_{s,q}^{(\sigma)} = (X_0, X_1)_{s,q}^{(\rho)}$ , with equivalence of seminorms. In fact,  $\forall x \in \Sigma(X_0, X_1)$  it holds  $[x]_{s,q}^{(\sigma)} \leq \max\{\rho^s \sigma^{-s}, \sigma^{1-s} \rho^{s-1}\} [x]_{s,q}^{(\rho)}$ .
- (3) If  $\sigma < \infty$  and s < t, then we have the continuous embedding  $(X_0, X_1)_{t,q}^{(\sigma)} \hookrightarrow (X_0, X_1)_{s,q}^{(\sigma)}$ , with the following estimate for all  $x \in (X_0, X_1)_{t,q}^{(\sigma)}$ :  $[x]_{s,q}^{(\sigma)} \leqslant \sigma^{t-s}[x]_{t,q}^{(\sigma)}$ .

- (4) If  $\sigma < \infty$ , then we have the continuous embedding  $X_1 \hookrightarrow (X_0, X_1)_{s,q}^{(\sigma)}$ , with the following estimate for all  $x \in X_1$ :  $[x]_{s,q}^{(\sigma)} \leqslant D_{s,q,\sigma}[x]_1$  where  $D_{s,q,\sigma} = \sigma^{1-s}q^{-1/q}(1-s)^{-1/q}$  when  $q < \infty$  and  $D_{s,q,\infty} = \sigma^{1-s}$ .
- (5) If p < q, then we have the continuous embedding  $(X_0, X_1)_{s,p}^{(\sigma)} \hookrightarrow (X_0, X_1)_{s,a}^{(\sigma)}$ .

*Proof.* For the first four items we only prove the case for  $1 \leq q < \infty$ , as the case for  $q = \infty$  is proved analogously. The first item follows trivially from the definitions. Given  $x \in (X_0, X_1)_{s,q}^{(\sigma)}$ , we estimate via a change of variables and Proposition 2.6:

$$[x]_{s,q}^{(\sigma)} = \left(\rho^{qs}\sigma^{-qs}\int_{(0,\rho)} \left(t^{-s}\mathcal{K}(\sigma t/\rho, x)\right)^q t^{-1} dt\right)^{1/q} \leqslant \max\left\{\rho^s\sigma^{-s}, \sigma^{1-s}\rho^{s-1}\right\} [x]_{s,q}^{(\rho)}. \tag{2.16}$$

This proves the second item. Next, for  $x \in (X_0, X_1)_{t,q}^{(\sigma)}$  we bound

$$[x]_{s,q}^{(\sigma)} = \left(\int_{(0,\sigma)} \left(\tau^{-s} \mathcal{K}(\tau,x)\right)^q \tau^{-1} d\tau\right)^{1/q} \leqslant \sigma^{t-s} \left(\int_{(0,\sigma)} \left(\tau^{-t} \mathcal{K}(\tau,x)\right)^q \tau^{-1} d\tau\right)^{1/q} = \sigma^{t-s} [x]_{t,q}^{(\sigma)}, \quad (2.17)$$

which proves the third item. If  $x \in X_1$ , then  $x = 0 + x \in \Sigma(X_0, X_1)$  is a decomposition, and so for  $t \in (0, \sigma)$  we have  $\mathscr{K}(t, x) \leq t [x]_1$ . Thus if  $1 \leq q < \infty$ , then  $[x]_{s,q}^{(\sigma)} = \left(\int_{(0,\sigma)} \left(t^{-s}\mathscr{K}(t,x)\right)^q t^{-1} dt\right)^{1/q} \leq [x]_1 \left(\int_{(0,\sigma)} t^{q(1-s)-1} dt\right)^{1/q}$ , and the fourth item is proved.

We will only prove the fifth item in the case that  $\sigma < \infty$ , as the case  $\sigma = \infty$  follows similarly. Let  $x \in (X_0, X_1)_{s,q}^{(\sigma)}$ . We first consider  $q = \infty$ . For  $t, \tau \in (0, \sigma)$  we may use Proposition 2.6 to bound  $t^{-s}\mathcal{K}(\tau, x) \leq \max\{1, \tau t^{-1}\} t^{-s}\mathcal{K}(t, x)$ . In turn,

$$[x]_{s,p}^{(\sigma)} \geqslant \mathcal{K}(\tau, x) \left( \int_{(0,\sigma)} \left( t^{-s} \min \left\{ 1, t\tau^{-1} \right\} \right)^p t^{-1} dt \right)^{1/p}$$

$$\geqslant \mathcal{K}(\tau, x) \left( \int_{(0,\tau)} \left( t^{1-s}\tau^{-1} \right)^p t^{-1} dt \right)^{1/p} = \tau^{-s} \mathcal{K}(\tau, x) \left( (1-s)p \right)^{-1/p}. \quad (2.18)$$

Upon taking the supremum in  $\tau \in (0, \sigma)$ , we deduce that  $[x]_{s,\infty}^{(\sigma)} \leq (p(1-s))^{1/p} [x]_{s,p}^{(\sigma)}$ . On the other hand, if  $1 \leq p < q < \infty$ , then we can use estimate (2.18) to bound

<span id="page-8-1"></span><span id="page-8-0"></span>
$$[x]_{s,q}^{(\sigma)} \leqslant \left( [x]_{s,\infty}^{(\sigma)} \right)^{\frac{q-p}{q}} \left( [x]_{s,p}^{(\sigma)} \right)^{\frac{p}{q}} \leqslant \left( p (1-s) \right)^{1/p} [x]_{s,p}^{(\sigma)} \right)^{\frac{q-p}{q}} \left( [x]_{s,p}^{(\sigma)} \right)^{\frac{p}{q}} = \left( p (1-s) \right)^{\frac{q-p}{pq}} [x]_{s,p}^{(\sigma)}. \tag{2.19}$$

The fifth item is proved.

<span id="page-8-3"></span>The next theorem shows that the spaces  $(X_0, X_1)_{s,q}^{(\sigma)}$  and  $(X_0, X_1)_{s,q}$  are interpolation spaces in the sense of Definition 2.2.

**Theorem 2.11.** Suppose that  $(X_0, [\cdot]_{X_0})$ ,  $(X_1, [\cdot]_{X_1})$  and  $(Y_0, [\cdot]_{Y_0})$ ,  $(Y_1, [\cdot]_{Y_1})$  are two pairs of weakly compatible seminormed spaces. Suppose that  $T: \Sigma(X_0, X_1) \to \Sigma(Y_0, Y_1)$  is a linear mapping with the following property: for  $i \in \{0, 1\}$  there exist  $c_i \in \mathbb{R}^+$  such that for all  $x \in X_i$  we have  $Tx_i \in Y_i$  and  $[Tx]_{Y_i} \leq c_i [x]_{X_i}$ . Then for all  $s \in (0, 1)$ ,  $\sigma \in (0, \infty]$ , and  $1 \leq q \leq \infty$  we have that  $T(X_0, X_1)_{s,q}^{(\sigma)} \subseteq (Y_0, Y_1)_{s,q}^{(\sigma)}$ ; moreover, for  $x \in (X_0, X_1)_{s,q}^{(\sigma)}$  we have the estimate  $[Tx]_{s,q}^{(\sigma)} \leq c_0^{1-s} c_1^s [x]_{s,q}^{(\sigma c_1/c_0)}$ .

Proof. We only present the proof for  $\sigma < \infty$ , as the proof with  $\sigma = \infty$  follows similarly. Let  $x \in (X_0, X_1)_{s,q}^{(\sigma)}$ . Proposition 2.8 implies that  $x \in \Sigma(X_0, X_1)$ . Let  $(x_0, x_1) \in X_0 \times X_1$  be a decomposition of x, i.e.  $x = x_0 + x_1$ . Then for  $t \in (0, \sigma)$  we may bound  $\mathscr{K}(t, Tx) \leq c_0 [x_0]_0 + c_1 t [x_1]_1$ . Taking the infimium over all such decompositions and multiplying by  $t^{-s}$  yields the bound  $t^{-s}\mathscr{K}(t, Tx) \leq c_0 t^{-s}\mathscr{K}(tc_1c_0^{-1}, x)$ . In the case  $q = \infty$  we take the supremum over  $t \in (0, \sigma)$ , and in the case  $q < \infty$  we take the  $q^{\text{th}}$  power, integrate, and employ a change of variables; in either case we arrive at the bound:  $[Tx]_{s,q}^{(\sigma)} \leq c_0^{1-s} c_1^s [x]_{s,q}^{(\sigma c_1/c_0)}$ .

<span id="page-8-2"></span>We can also quantify the annihilators of the K-methods' interpolation spaces.

**Proposition 2.12** (Annihilators). Let  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  be a pair of weakly compatible seminormed spaces. Then the following hold for  $s \in (0,1), 1 \leq q \leq \infty$ , and  $\sigma \in (0,\infty]$ :

- $(1) \, \, \mathfrak{A}\left((X_0, X_1)_{s,q}^{(\sigma)}\right) = \mathfrak{A}\left(\Sigma\left(X_0, X_1\right)\right) \supseteq \Sigma\left(\mathfrak{A}\left(X_0\right), \mathfrak{A}\left(X_1\right)\right).$
- (2) If strong compatibility holds (see Definition 2.1) or  $\Delta(X_0, X_1)$  is semi-Banach, then the latter inclusion is an equality.

*Proof.* The first item follows from Propositions 2.6, 2.8, and 2.10. The second item follows from Proposition 2.4.

<span id="page-9-1"></span>Finally, we can characterize these spaces with discrete seminorms.

**Proposition 2.13** (Discrete seminorms). Suppose that  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  are a weakly compatible pair of seminormed spaces,  $\sigma \in \mathbb{R}^+$ ,  $s \in (0,1)$ ,  $1 < r < \infty$ , and  $1 \leqslant q \leqslant \infty$ . The following hold:

(1) For  $x \in \Sigma(X_0, X_1)$  we have that  $x \in (X_0, X_1)_{s,q}^{(\sigma)}$  if and only if  $\{r^{sk}\mathscr{K}(\sigma r^{-k}, x)\}_{k \in \mathbb{N}} \in \ell^q(\mathbb{N}; \mathbb{R})$ . In either case, we have the equivalence

$$\begin{cases}
\left(\frac{sq\sigma^{sq}}{r^{sq}-1}\right)^{1/q} [x]_{s,q}^{(\sigma)} \leqslant \left\| \left\{ r^{sk} \mathcal{K} \left( \sigma r^{-k}, x \right) \right\}_{k \in \mathbb{N}} \right\|_{\ell^{q}(\mathbb{N};\mathbb{R})} \leqslant r^{s} \left( \frac{sq\sigma^{sq}}{r^{sq}-1} \right)^{1/q} [x]_{s,q}^{(\sigma)} & 1 \leqslant q < \infty \\
\left(\frac{\sigma}{r}\right)^{s} [x]_{s,\infty}^{(\sigma)} \leqslant \left\| \left\{ r^{sk} \mathcal{K} \left( \sigma r^{-k}, x \right) \right\}_{k \in \mathbb{N}} \right\|_{\ell^{q}(\mathbb{N};\mathbb{R})} \leqslant \sigma^{s} [x]_{s,\infty}^{(\sigma)} & q = \infty.
\end{cases} \tag{2.20}$$

 $(2) \ \ For \ x \in \Sigma \left( X_0, X_1 \right) \ we \ have \ that \ x \in \left( X_0, X_1 \right)_{s,q} \ if \ and \ only \ if \left\{ r^{sk} \mathscr{K} \left( r^{-k}, x \right) \right\}_{k \in \mathbb{Z}} \in \ell^q \left( \mathbb{Z}; \mathbb{R} \right). \ In \ \ for \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ if \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ if \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ if \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ if \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ if \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q} \ \ for \ \ x \in \Sigma \left( X_0, X_1 \right)_{s,q}$ either case, we have the equivalence

$$\begin{cases}
\left(\frac{sq}{r^{sq}-1}\right)^{1/q} [x]_{s,q} \leqslant \left\| \left\{ r^{sk} \mathcal{K} \left( r^{-k}, x \right) \right\}_{k \in \mathbb{Z}} \right\|_{\ell^{q}(\mathbb{Z};\mathbb{R})} \leqslant r^{s} \left( \frac{sq}{r^{sq}-1} \right)^{1/q} [x]_{s,q} & 1 \leqslant q < \infty \\
r^{-s} [x]_{s,\infty} \leqslant \left\| \left\{ r^{sk} \mathcal{K} \left( r^{-k}, x \right) \right\}_{k \in \mathbb{Z}} \right\|_{\ell^{\infty}(\mathbb{Z};\mathbb{R})} \leqslant [x]_{s,\infty} & q = \infty.
\end{cases}$$
(2.21)

*Proof.* We write

$$\int_{(0,\sigma)} (t^{-s} \mathcal{K}(t,x))^q \frac{1}{t} dt = \sum_{k \in \mathbb{N}} \int_{(\sigma r^{-k-1}, \sigma r^{-k})} (t^{-s} \mathcal{K}(t,x))^q \frac{1}{t} dt =: \sum_{k \in \mathbb{N}} I_k.$$
 (2.22)

We then use Proposition 2.6 estimate

$$\frac{1}{sq\sigma^{sq}} [r^{sk} \mathcal{K}(\sigma r^{-k}, x)]^q [r^{sq} - 1] = \mathcal{K}(\sigma r^{-k}, x) \int_{(\sigma r^{-k-1}, \sigma r^{-k})} t^{-sq-1} dt \geqslant I_k$$

$$\geqslant \mathcal{K}(\sigma r^{-k-1}, x) \int_{(\sigma r^{-k-1}, \sigma r^{-k})} t^{-sq-1} dt = \frac{r^{-sq}}{sq\sigma^{sq}} [r^{s(k+1)} \mathcal{K}(\sigma r^{-k-1}, x)]^q [r^{sq} - 1]. \quad (2.23)$$

Plugging this in above then proves the first item when  $\sigma, q < \infty$ . The other cases follow similarly.

2.4. Integration into seminormed spaces. To study the J-method for interpolation of seminormed spaces, we develop the following variant of the Bochner integral for functions valued in seminormed spaces. Simple functions and their integrals are defined as usual.

**Definition 2.14** (Simple functions). Let  $(Y, \mathfrak{M}, \mu)$  be a measure space and  $(X, [\cdot])$  a seminormed space. We say that a function  $s: Y \to X$  is a simple function if:

- (1) s is measurable, i.e.  $s^{-1}(U) \in \mathfrak{M}$  for all  $U \subseteq X$  open.
- (2) card (s(Y)) is finite, and so there exist  $n \in \mathbb{N}^+$ ,  $\{a_j\}_{j=1}^n \subseteq X$ , and a pairwise disjoint collection  $\{E_j\}_{j=1}^n \subseteq \mathfrak{M} \text{ such that } s = \sum_{j=1}^n a_j \chi_{E_j}.$ (3) s has finite support, i.e.  $\forall j \in \{1, \ldots, n\} \text{ with } a_j \in X \setminus \{0\}, \ \mu(E_j) < \infty.$

The collection of X-valued simple functions over Y is denoted simp (Y;X). We define the functional  $\mathcal{I}: \operatorname{simp}(Y;X) \to X \ via \ \mathcal{I}(s) = \sum_{j=1}^{n} a_{j} \mu(E_{j}) \ for \ s = \sum_{j=1}^{n} a_{j} \chi_{E_{j}}.$ 

<span id="page-9-0"></span>With the functional  $\mathcal{I}$  in hand, we can define the integral as a set-valued map.

**Definition 2.15** (Strongly measurable and X-integrable). Let  $(X, [\cdot])$  be a seminormed space and  $(Y, \mathfrak{M}, \nu)$ be a measure space. We say that a function  $f: Y \to X$  is strongly measurable if:

- (1) f is measurable in the sense that  $f^{-1}(U) \in \mathfrak{M}$  for all  $U \subseteq X$  open.
- (2) There exists a sequence  $\{s_n\}_{n\in\mathbb{N}}\subseteq \mathrm{simp}\,(Y;X)$  such that  $[s_n-f]\to 0$   $\nu-a.e.$  as  $n\to\infty$ .

We say that a strongly measurable function  $f: Y \to X$  is X-integrable if the sequence of simple functions from item (2) above satisfies, in addition,  $\int_Y [f-s_n] d\nu \to 0$  as  $n \to \infty$ . The collection of X-integrable functions over Y is denoted  $\mathfrak{L}^1(Y,\nu;X)$ . We define the set-valued mapping  $\int_Y (\cdot) d\nu : \mathfrak{L}^1(Y,\nu;X) \to 2^X$  via

$$\int_{Y} f \, d\nu = \left\{ \ell \in X : \exists \left\{ s_{n} \right\}_{n \in \mathbb{N}} \subset \operatorname{simp}\left(Y; X\right), \ s_{n} \to f \ a.e., \int_{Y} \left[ f - s_{n} \right] \, d\nu \to 0, \ \left[ \mathcal{I}\left(s_{n}\right) - \ell \right] \to 0 \right\}. \tag{2.24}$$

One of the benefits of defining the integral as a set-valued map is that it allows us to avoid invoking completeness to guarantee  $\{\mathcal{I}(s_n)\}_{n\in\mathbb{N}}$  converges. The trade-off is that it can be the case that  $\int_Y f d\nu = \emptyset$ . Note, though, that in the event that X is a Banach space, the integral is the singleton containing the usual Bochner integral of f.

<span id="page-10-0"></span>We next record some simple properties of the mapping  $\int_{V} (\cdot) d\nu$ .

**Proposition 2.16.** Let  $(Y, \mathfrak{M}, \nu)$  be a measure space and  $(X, [\cdot])$  be a seminormed space over  $\mathbb{K} \in \{\mathbb{R}, \mathbb{C}\}$ . Then, the following hold for all  $f, g \in \mathfrak{L}^1(Y, \nu; X)$  and  $\alpha \in \mathbb{K}$ :

- (1) If  $(X, [\cdot])$  is semi-Banach, then  $\int_{Y} f \, d\nu \neq \emptyset$ .
- (2) If  $\ell_0, \ell_1 \in \int_Y f \, d\nu$ , then  $\ell_0 \ell_1 \in \mathfrak{A}(X)$  and  $[\ell_0] = [\ell_1]$ .
- (3)  $\left[ \int_{V} f \, d\nu \right] = \left\{ [\ell] : \ell \in \int_{V} f \, d\nu \right\} \subseteq [0, \int_{V} [f] \, d\nu \right].$
- (4) If  $\varnothing \neq \int_{Y} f \, d\nu$  and  $\varnothing \neq \int_{Y} g \, d\nu$ , then  $\int_{Y} (f + \alpha g) \, d\nu = \int_{Y} f \, d\nu + \alpha \int_{Y} g \, d\nu$

Proof. To prove the first item note that if  $s \in \text{simp}(Y; X)$ , then  $[s] \in \text{simp}(Y; \mathbb{R})$  and  $[\mathcal{I}(s)] \leq \int_Y [s] d\nu$ . Then for  $\{s_n\}_{n \in \mathbb{N}} \subseteq \text{simp}(Y; X)$  such that  $[s_n - f] \to 0$  a.e. and  $\int_Y [s_n - f] d\nu \to 0$  as  $n \to \infty$  we have that  $\{\mathcal{I}(s_n)\}_{n \in \mathbb{N}}$  is Cauchy in X and so  $\int_Y f d\nu \neq \emptyset$  by Lemma A.7. This proves the first item. If  $\ell_0, \ell_1 \in \int_Y f d\nu$ , then there exist  $\{s_n^i\}_{n \in \mathbb{N}} \subseteq \text{simp}(Y; X)$  for  $i \in \{0, 1\}$  such that  $[s_n^i - f] \to 0$  a.e.,  $\int_Y [s_n^i - f] d\nu \to 0$ , and  $[\ell_i - \mathcal{I}(s_n^i)] \to 0$  as  $n \to \infty$ . Then

$$[\ell_{0} - \ell_{1}] \leq [\ell_{0} - \mathcal{I}(s_{n}^{0})] + [\mathcal{I}(s_{n}^{0}) - \mathcal{I}(s_{n}^{1})] + [\ell_{1} - \mathcal{I}(s_{n}^{1})]$$

$$\leq [\ell_{0} - \mathcal{I}(s_{n}^{0})] + \int_{Y} [f - s_{n}^{0}] + \int_{Y} [f - s_{n}^{1}] + [\ell_{1} - \mathcal{I}(s_{n}^{1})] \to 0 \quad (2.25)$$

as  $n \to \infty$ , and hence  $\ell_0 - \ell_1 \in \mathfrak{A}(X)$ , which proves the second item. For the third item consider  $\ell \in \int_Y f d\nu$  and pick the approximation sequence  $\{s_n\}_{n \in \mathbb{N}}$  as above. Then we may estimate

$$[\ell] \leqslant [\ell - \mathcal{I}(s_n)] + [\mathcal{I}(s_n)] \leqslant [\ell - \mathcal{I}(s_n)] + \int_Y [s_n] d\nu \leqslant [\ell - \mathcal{I}(s_n)] + \int_Y [s_n - f] d\nu + \int_Y [f] d\nu. \quad (2.26)$$

and send  $n \to \infty$  to arrive at the bound  $[\ell] \leqslant \int_Y [f] d\nu$ . This proves the third item. The fourth item is immediate from the second item and continuity of vector operators in a seminorm space.

2.5. J-method and equivalence with K-method. With a notion of seminorm integration in hand, we now turn our attention to the development of the J-method of interpolation for seminormed spaces.

**Definition 2.17** (*J*-functional). Suppose that  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  are a pair of weakly compatible semi-normed spaces. We define the following functional on their intersection:  $\mathscr{J}: \mathbb{R}^+ \times \Delta(X_0, X_1) \to \mathbb{R}$  via  $\mathscr{J}(t, x) = \max\{[x]_0, t[x]_1\}$ .

<span id="page-10-1"></span>Some simple properties of the J-functional are recorded in the next proposition.

**Proposition 2.18.** Suppose that  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  are a pair of weakly compatible seminormed spaces. The following hold:

- (1) For each  $x \in \Delta(X_0, X_1)$ , the mapping  $\mathbb{R}^+ \ni t \mapsto \mathcal{J}(t, x) \in \mathbb{R}$  is convex.
- (2) For any  $t, s \in \mathbb{R}^+$  we have the bounds  $\min\{1, t/s\}$   $\mathcal{J}(s, \cdot) \leqslant \mathcal{J}(t, \cdot) \leqslant \max\{1, t/s\}$   $\mathcal{J}(s, \cdot)$ .
- (3) For any  $t, s \in \mathbb{R}^+$  we have the inequality  $\mathcal{K}(t, \cdot) \leq \min\{1, t/s\}$   $\mathcal{J}(s, \cdot)$ .

*Proof.* These are immediate from the definition  $\mathcal{J}$ .

We now define the J-method of interpolation.

**Definition 2.19** (*J*-method of interpolation). Suppose that  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  are a pair of weakly compatible seminormed spaces. Recall that  $\mu$ , as defined in Section 1.3, denotes Haar measure on  $(0, \infty)$ . For  $x \in \Sigma(X_0, X_1)$  we define the decomposition set of x via

$$\mathcal{D}\left(x\right) = \left\{u \in \mathfrak{L}^{1}\left(\mathbb{R}^{+}, \mu; \Sigma\left(X_{0}, X_{1}\right)\right) : u\left(t\right) \in \Delta\left(X_{0}, X_{1}\right) \ x \in \int_{\mathbb{R}^{+}} u\left(t\right) t^{-1} dt\right\},\tag{2.27}$$

where  $\mathfrak{L}^1$  is as in Definition 2.15. For  $s \in (0,1)$  and  $1 \leqslant q \leqslant \infty$  we define  $[\cdot]_{s,q,\mathscr{J}} : \Sigma(X_0,X_1) \to [0,\infty]$  via

$$[x]_{s,q,\mathscr{J}} = \begin{cases} \inf\left\{ \left( \int_{\mathbb{R}^+} \left( t^{-s} \mathscr{J} \left( t, u\left( t \right) \right) \right)^q t^{-1} dt \right)^{1/q} : u \in \mathcal{D}\left( x \right) \right\} & 1 \leqslant q < \infty \\ \inf\left\{ \operatorname{esssup}_{t \in \mathbb{R}^+} t^{-s} \mathscr{J} \left( t, u\left( t \right) \right) : u \in \mathcal{D}\left( x \right) \right\} & q = \infty, \end{cases}$$

$$(2.28)$$

with the usual understanding that  $\inf \emptyset = \infty$ . The subspace of  $\Sigma(X_0, X_1)$  on which  $[\cdot]_{s,q,\mathscr{J}}$  is finite is denoted  $(X_0, X_1)_{s,q,\mathscr{J}}$ , and we endow this space with the seminorm  $[\cdot]_{s,q,\mathscr{J}}$ .

We will now show that the K-method and the J-method give the same interpolation spaces. We need a seminormed space version of the so called 'fundamental lemma of interpolation theory' (for the normed space version, see for instance Lemma 3.3.2 in [BL76]). The case for seminormed spaces is marginally more subtle, since  $[x]_{\Sigma} = 0$  need not imply that there is a decomposition of  $x = x_0 + x_1$  where  $[x_0]_0 = [x_1]_1 = 0$ . Our proof of the lemma is a slight generalization of the ideas in [Gus70].

<span id="page-11-4"></span>**Lemma 2.20** (Fundamental lemma of interpolation theory). Let  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  be a pair of weakly compatible seminormed spaces. Suppose that  $x \in \Sigma(X_0, X_1)$  satisfies

<span id="page-11-0"></span>
$$\lim_{t \to 0^+} \mathcal{K}(t, x) = 0 \quad and \quad \lim_{t \to \infty} t^{-1} \mathcal{K}(t, x) = 0. \tag{2.29}$$

Let  $\varepsilon \in \mathbb{R}^+$ ,  $1 < r < \infty$ , and suppose that  $\varphi : \mathbb{R}^+ \to \mathbb{R}^+$  is Lebesgue measurable and satisfies the following:

<span id="page-11-1"></span>
$$\lim_{t\to 0^+} \varphi\left(t\right) = 0, \quad \lim_{t\to \infty} t^{-1}\varphi\left(t\right) = 0, \quad and \quad \inf\left\{\varphi\left(t\right) : r^{k-1} \leqslant t \leqslant r^{k+1}\right\} = c_k \in \mathbb{R}^+ \text{ for } k \in \mathbb{Z}. \tag{2.30}$$

Then there exists a strongly measurable  $u: \mathbb{R}^+ \to \Delta(X_0, X_1)$  with the following properties:

- (1)  $u \in \bigcap_{k \in \mathbb{N}^+} \mathfrak{L}^1\left(\left(r^{-k}, r^k\right); \Sigma\left(X_0, X_1\right)\right)$ , and for each  $k \in \mathbb{N}^+$  we have that  $\emptyset \neq \int_{\left(r^{-k}, r^k\right)} u \ d\mu \subseteq \Delta\left(X_0, X_1\right) + \mathfrak{A}\left(\Sigma\left(X_0, X_1\right)\right)$ .
- (2) For every sequence  $\{\xi_k\}_{k\in\mathbb{Z}}$  such that  $\xi_k \in \int_{(r^{k-1},r^k)} u \, d\mu \neq \emptyset$  for  $k \in \mathbb{Z}$ , we have that as  $K \to \infty$  it holds  $[-x + \sum_{k=-K}^K \xi_k]_{\Sigma} \to 0$ .
- (3) For a.e.  $t \in \mathbb{R}^+$  it holds that  $\mathscr{J}(t, u(t)) \leqslant (\log(r))^{-1} r(1+r)(\mathscr{K}(t, x) + \varepsilon \varphi(t))$ .

*Proof.* Given  $k \in \mathbb{Z}$ , by the definition of the  $\mathscr{K}$  functional we can find a decomposition  $x = y_k + z_k$  with  $(y_k, z_k) \in X_0 \times X_1$  and

$$[y_k]_0 + r^k [z_k]_1 \leqslant \mathcal{K}(r^k, x) + \varepsilon c_k. \tag{2.31}$$

The assumptions (2.29) and (2.30) imply that

<span id="page-11-3"></span><span id="page-11-2"></span>
$$\lim_{k \to -\infty} [y_k]_0 = 0 \quad \text{and } \lim_{k \to \infty} [z_k]_1 = 0. \tag{2.32}$$

Note that for each  $k \in \mathbb{Z}$  we have that  $\zeta_{k+1} = y_{k+1} - y_k = -z_{k+1} + z_k \in \Delta\left(X_0, X_1\right)$ . This leads us to define  $v : \mathbb{R}^+ \to \Delta\left(X_0, X_1\right)$  via  $v\left(t\right) = \sum_{k \in \mathbb{Z}} \zeta_k \chi_{[r^{k-1}, r^k)}(t)$ . It is clear that v is strongly measurable, as it is a step function with countable image. For  $k \in \mathbb{N}$  we have that v restricted to  $\left(r^{-k}, r^k\right)$  is a simple function. Hence  $v \in \bigcap_{k \in \mathbb{N}^+} \mathfrak{L}^1\left(\left(r^{-k}, r^k\right), \mu; \Sigma\left(X_0, X_1\right)\right)$  and  $\varnothing \neq \int_{\left(r^{-k}, r^k\right)} v \, \mathrm{d}\mu \ni \mathcal{I}\left(v|_{\left(r^{-k}, r^k\right)}\right)$ . Moreover:

$$\mathcal{I}(v|_{(r^{-k},r^k)}) = \sum_{j=-k+1}^k \zeta_j \mu((r^{j-1},r^j)) 
= \log(r) \sum_{j=-k+1}^k (y_j - y_{j-1}) = \log(r) (y_k - y_{-k}) = \log(r) (x + y_{-k} - z_k).$$
(2.33)

Notice that (2.33) paired with item (2) of Proposition 2.16 reveal that

$$\int_{(r^{-k}, r^k)} v \, d\mu = \log(r) \left( x + y_{-k} - z_k \right) + \mathfrak{A} \left( \Sigma(X_0, X_1) \right) \subseteq \Delta(X_0, X_1) + \mathfrak{A} \left( \Sigma(X_0, X_1) \right). \tag{2.34}$$

Now, for  $k \in \mathbb{Z}$ , we have that  $v|_{(r^{k-1},r^k)}$  is a simple function. Hence,  $\int_{(r^{k-1},r^k)} v \ d\mu = \log(r) \zeta_k + \mathfrak{A}(\Sigma(X_0,X_1))$ . Pick any  $\{\xi_k\}_{k\in\mathbb{Z}} \subseteq \Sigma(X_0,X_1)$  with  $\xi_k \in \int_{(r^{k-1},r^k)} v \ d\mu$ . The previous fact paired with (2.32) yields

$$\left[ -\log(r) x + \sum_{j=-k}^{k} \xi_j \right]_{\Sigma} = \log(r) \left[ -x + \sum_{j=-k}^{k} \zeta_j \right]_{\Sigma} = \left[ -y_{-k-1} - z_k \right]_{\Sigma} \leqslant [y_{-k-1}]_0 + [z_k]_1 \to 0 \text{ as } k \to \infty.$$
(2.35)

Thus  $u = v/\log(r)$  satisfies items (1) and (2). To prove (3), we take  $t \in \mathbb{R}^+$  with  $r^{k-1} \leq t < r^k$ , for some  $k \in \mathbb{Z}$  and estimate (using again Proposition 2.6)

$$\mathcal{J}(t, u(t)) \leqslant \mathcal{J}\left(r^{k}, \zeta_{k}/\log(r)\right) = \log(r)^{-1} \max\left\{\left[y_{k} - y_{k-1}\right]_{0}, r^{k}\left[z_{k} - z_{k-1}\right]_{1}\right\}$$

$$\leqslant \log(r)^{-1} \max\left\{\mathcal{K}(r^{k}, x) + \mathcal{K}(r^{k-1}, x) + \varepsilon c_{k} + \varepsilon c_{k-1}, \mathcal{K}(r^{k}, x) + r\mathcal{K}(r^{k-1}, x) + \varepsilon c_{k} + r\varepsilon c_{k-1}\right\}$$

$$\leqslant \log r^{-1} \max\left\{2\mathcal{K}\left(r^{k}, x\right) + 2\varepsilon\varphi(t), (1+r)\mathcal{K}\left(r^{k}, x\right) + (1+r)\varepsilon\varphi(t)\right\}$$

$$\leqslant \log(r)^{-1} r(1+r)\left(\mathcal{K}(t, x) + \varepsilon\varphi(t)\right). (2.36)$$

<span id="page-12-0"></span>We now give important sufficient conditions for the satisfaction of the hypotheses of Lemma 2.20.

**Lemma 2.21.** Suppose that  $(X_i, [\cdot]_i)$ , for  $i \in \{0, 1\}$ , are a weakly compatible pair of seminormed spaces,  $s \in (0, 1)$ , and  $1 \leq q \leq \infty$ . If  $x \in (X_0, X_1)_{s,q}$ , then x satisfies equation (2.29).

*Proof.* We appeal to item (5) of Proposition 2.10; whence: 
$$\mathscr{K}(t,x) \leqslant t^s [x]_{s,\infty} \lesssim t^s [x]_{s,q} \to 0$$
 as  $t \to 0^+$  and  $t^{-1}\mathscr{K}(t,x) \leqslant t^{s-1} [x]_{s,\infty} \lesssim t^{s-1} [x]_{s,q} \to 0$  as  $t \to \infty$ .

<span id="page-12-2"></span>With the lemmas in hand, we are now ready to prove the equivalence theorem for the non-truncated interpolation spaces.

**Theorem 2.22** (Equivalence of K method with  $\sigma = \infty$  and the J method). Let  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  be a pair of weakly compatible seminormed spaces. Then for  $s \in (0,1)$  and  $1 \le q \le \infty$ , the spaces  $(X_0, X_1)_{s,q}$  and  $(X_0, X_1)_{s,q,\mathscr{J}}$  are identical as subspaces of  $\Sigma(X_0, X_1)$ , and the seminorms  $[\cdot]_{s,q} = [\cdot]_{s,q}^{(\infty)}$  and  $[\cdot]_{s,q,\mathscr{J}}$  are equivalent.

Proof. Suppose first that  $x \in (X_0, X_1)_{s,q}$ . Fix  $\varepsilon \in \mathbb{R}^+$ . Then, since  $\mathbb{R}^+ \ni t \mapsto t^{-s} \mathscr{K}(t, x) \in \mathbb{R}$  belongs to  $L^q(\mathbb{R}^+, \mu)$  (where again  $\mu$  is defined in Section 1.3), x satisfies (2.29) from Lemma 2.20, thanks to Lemma 2.21. Define  $\varphi : \mathbb{R}^+ \to \mathbb{R}^+$  via  $\varphi(t) = t^s (1 + (\log(t))^2)^{-1}$ . and observe that  $\varphi$  satisfies (2.30). Thus, we can apply Lemma 2.20 to obtain a strongly measurable function  $u : \mathbb{R}^+ \to \Delta(X_0, X_1)$  satisfying items (1), (2), and (3) from the lemma.

We first show that  $u \in \mathcal{D}(x)$ , which amounts to proving that  $u \in \mathfrak{L}^1(\mathbb{R}^+, \mu; X)$  and  $x \in \int_{\mathbb{R}^+} u \, d\mu$ . Since Lemma (2.20) tells us that we may take u a step function, there is a natural choice of simple functions to attempt to satisfy Definition 2.15. For  $k \in \mathbb{Z}$  and  $t \in [2^{k-1}, 2^k)$ , there is some  $\xi_k \in \Delta(X_0, X_1)$  such that  $u(t) = \xi_k$ . Then for each  $n \in \mathbb{N}^+$  we define  $s_n = \sum_{k=-n}^n \xi_k \chi_{[2^{k-1}, 2^k)} \in \text{simp}(\mathbb{R}^+; \Sigma(X_0, X_1))$ . It is clear that  $s_n \to u$  everywhere as  $n \to \infty$ . Also, according to Proposition 2.18 and item (3) from Lemma 2.20, we may bound

<span id="page-12-1"></span>
$$\int_{\mathbb{R}^{+}} [u(t) - s_{n}(t)]_{\Sigma} d\mu(t) = \int_{\mathbb{R}^{+} \setminus (2^{-n-1}, 2^{n})} [u(t)]_{\Sigma} \frac{1}{t} dt \leqslant \int_{\mathbb{R}^{+} \setminus (2^{-n-1}, 2^{n})} \min\{1, t^{-1}\} \mathscr{J}(t, u(t)) t^{-1} dt$$

$$\leqslant 6 (\log(2))^{-1} \left[ \int_{\mathbb{R}^{+} \setminus (2^{-n-1}, 2^{n})} \mathscr{K}(t, x) \min\{1, t^{-1}\} t^{-1} dt + \varepsilon \int_{\mathbb{R}^{+} \setminus (2^{-n-1}, 2^{n})} \min\{1, t^{-1}\} \varphi(t) t^{-1} dt \right].$$
(2.37)

To show that the right hand side of (2.37) tends to zero as  $n \to \infty$ , it suffices to show that both integrands are integrable over  $\mathbb{R}^+$ . This is clear for the latter term involving  $\varphi$ . To handle the former, we use Hölder's inequality to bound

$$\int_{\mathbb{R}^{+}} \mathcal{K}(t,x) \min\left\{1, t^{-1}\right\} t^{-1} dt \leqslant [x]_{s,q} \begin{cases} \left(\int_{\mathbb{R}^{+}} \min\left\{t^{sp}, t^{p(s-1)}\right\} t^{-1} dt\right)^{1/p} & 1 < q \leqslant \infty \\ \sup\left\{\min\left\{t^{s}, t^{s-1}\right\} : t \in \mathbb{R}^{+}\right\} & q = 1 \end{cases} < \infty, \quad (2.38)$$

where  $p = q (q-1)^{-1}$ . Hence, u is  $\Sigma(X_0, X_1)$ -integrable, with  $x \in \int_{\mathbb{R}^+} u \, d\mu$ ; indeed, item (2) in Lemma 2.20 implies the limit:  $[x - \mathcal{I}(s_n)]_{\Sigma} \to 0$  as  $n \to \infty$  holds. Finally, we check that  $x \in (X_0, X_1)_{s,q,\mathscr{J}}$ . If  $1 \le q < \infty$ , then again we use Lemma 2.20 to see that

$$[x]_{s,q,\mathscr{J}} \leqslant \left(\int_{\mathbb{R}^+} \left(t^{-s}\mathscr{J}(t,u(t))\right)^q t^{-1} dt\right)^{1/q} \leqslant 6\log\left(2\right)^{-1} \left[ [x]_{s,q} + \varepsilon \left(\int_{\mathbb{R}^+} \left(1 + \log^2(t)\right)^{-q} t^{-1} dt\right)^{1/q} \right]. \tag{2.39}$$

The integral on the right hand side is finite. As  $\varepsilon \in \mathbb{R}^+$  was chosen arbitrarily, we can let  $\varepsilon \to 0^+$  and see that  $(X_0, X_1)_{s,q} \hookrightarrow (X_0, X_1)_{s,q,\mathscr{J}}$ . The case for  $q = \infty$  is proved in the same way.

On the other hand, let  $x \in (X_0, X_1)_{s,q,\mathcal{J}}$ . Then, there is some  $u \in \mathcal{D}(x)$  by hypothesis. Then for  $t \in \mathbb{R}^+$  we use Proposition 2.18 to bound

<span id="page-13-0"></span>
$$\mathscr{K}(t,x) \leqslant \int_{\mathbb{R}^{+}} \mathscr{K}(t,u(\tau)) \tau^{-1} d\tau \leqslant \int_{\mathbb{R}^{+}} \min\left\{1, t\tau^{-1}\right\} \mathscr{J}(\tau,u(\tau)) \tau^{-1} d\tau. \tag{2.40}$$

In the case that  $1 \leq q < \infty$ , we use (2.40) and Hardy's inequalities (see Lemma B.2) to estimate

$$\begin{split} \left[x\right]_{s,q} &\leqslant \left(\int_{\mathbb{R}^{+}} \left(t^{-s} \int_{\mathbb{R}^{+}} \min\left\{1, t\tau^{-1}\right\} \mathscr{J}\left(\tau, u\left(\tau\right)\right) \tau^{-1} \, \mathrm{d}\tau\right)^{q} t^{-1} \, \mathrm{d}t\right)^{1/q} \\ &\leqslant \left(\int_{\mathbb{R}^{+}} \left(t^{-s} \int_{(0,t)} \mathscr{J}\left(\tau, u\left(\tau\right)\right) \tau^{-1} \, \mathrm{d}\tau\right)^{q} t^{-1} \, \mathrm{d}t\right)^{1/q} + \left(\int_{\mathbb{R}^{+}} \left(t^{-s} \int_{(t,\infty)} t\tau^{-1} \mathscr{J}\left(\tau, u\left(\tau\right)\right) \tau^{-1} \, \mathrm{d}\tau\right)^{q} t^{-1} \mathrm{d}t\right)^{1/q} \\ &\leqslant \left(s^{-1} + (1-s)^{-1}\right) \left(\int_{\mathbb{R}^{+}} \left(t^{-s} \mathscr{J}\left(t, u\left(t\right)\right)\right)^{q} t^{-1} \, \mathrm{d}t\right)^{1/q}. \end{split} \tag{2.41}$$

Taking the infimum over all  $u \in \mathcal{D}(x)$  gives the case for  $1 \leq q < \infty$ . For the case  $q = \infty$ , we consider some  $t \in \mathbb{R}^+$  and use (2.40):

$$t^{-s} \mathcal{K}(t, x) \leqslant \int_{\mathbb{R}^{+}} \min\left\{t^{-s}, t^{1-s} \tau^{-1}\right\} \tau^{-s} \mathcal{J}(\tau, u(\tau)) \tau^{s-1} d\tau$$

$$\leqslant \operatorname{esssup}_{\tau \in \mathbb{R}^{+}} \tau^{-s} \mathcal{J}(\tau, u(\tau)) \int_{\mathbb{R}^{+}} \min\left\{t^{-s} \tau^{s}, t^{1-s} \tau^{s-1}\right\} \tau^{-1} d\tau. \quad (2.42)$$

Notice first that  $\int_{\mathbb{R}^+} \min \left\{ t^{-s} \tau^s, t^{1-s} \tau^{s-1} \right\} \tau^{-1} d\tau = \int_{\mathbb{R}^+} \min \left\{ \tau^s, \tau^{s-1} \right\} \tau^{-1} d\tau < \infty$ . Taking the supremum over  $t \in \mathbb{R}^+$ , and then the infimum over all  $u \in \mathcal{D}(x)$  show that  $(X_0, X_1)_{s,\infty} \not\hookrightarrow (X_0, X_1)_{s,\infty}$ .  $\square$ 

<span id="page-13-2"></span>Next, we show that we have a discrete characterization of the seminorm on  $(X_0, X_1)_{s,q,\mathscr{J}}$ .

**Proposition 2.23** (Discrete characterization of the *J*-method). Let  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  be a pair of weakly compatible seminormed spaces. For  $x \in \Sigma(X_0, X_1)$  we define the discrete decomposition set of x as

<span id="page-13-3"></span>
$$\tilde{\mathcal{D}}\left(x\right) = \left\{ \left\{ \xi_{k} \right\}_{k \in \mathbb{Z}} \subseteq \Delta\left(X_{0}, X_{1}\right) : \sum_{k \in \mathbb{Z}} \left[ \xi_{k} \right]_{\Sigma} < \infty, \ \lim_{K \to \infty} \left[ -x + \sum_{k = -K}^{K} \xi_{k} \right]_{\Sigma} = 0 \right\}. \tag{2.43}$$

Then for each  $r \in (1, \infty)$  there is a constant  $c \in \mathbb{R}^+$  such that for all  $x \in \Sigma(X_0, X_1)$ ,

<span id="page-13-1"></span>
$$c^{-1}\left[x\right]_{s,q,\mathscr{J}} \leqslant \inf\left\{\left\|\left\{r^{sk}\mathscr{J}\left(r^{-k},\xi_{k}\right)\right\}_{k\in\mathbb{Z}}\right\|_{\ell^{q}\left(\mathbb{Z};\mathbb{R}\right)} : \left\{\xi_{k}\right\}_{k\in\mathbb{Z}} \in \tilde{\mathcal{D}}\left(x\right)\right\} \leqslant c\left[x\right]_{s,q,\mathscr{J}}.$$

$$(2.44)$$

*Proof.* Let  $x \in (X_0, X_1)_{s,q,\mathscr{J}}$  and  $\varepsilon \in \mathbb{R}^+$ . Again, we take  $\varphi : \mathbb{R}^+ \to \mathbb{R}^+$  to be defined as in the proof of Theorem 2.22. By Theorem 2.22 we have that  $x \in (X_0, X_1)_{s,q}$  with  $[x]_{s,q} \leqslant c[x]_{s,q\mathscr{J}}$  for some c depending

only on s and q. Thus, we can apply Lemma 2.20 and then Theorem 2.22 again to find a step function  $u: \mathbb{R}^+ \to \Delta(X_0, X_1)$  with  $u \in \mathcal{D}(x)$ , obeying the bound

<span id="page-14-0"></span>
$$\begin{cases}
\left(\int_{\mathbb{R}^{+}} \left(t^{-s} \mathcal{J}\left(t, u\left(t\right)\right)\right)^{q} t^{-1} dt\right)^{1/q} & 1 \leqslant q < \infty \\
\operatorname{esssup}_{t \in \mathbb{R}^{+}} \left\{t^{-s} \mathcal{J}\left(t, u\left(t\right)\right) : t \in \mathbb{R}^{+}\right\} & q = \infty
\end{cases} \leqslant r(1+r) \log (r)^{-1} \left[\left[x\right]_{s,q} + C\varepsilon\right], \tag{2.45}$$

where C is a constant depending on  $\varphi$ , s, and q. Moreover, there is a sequence  $\{\xi_k\}_{k\in\mathbb{Z}}\subseteq\Delta\left(X_0,X_1\right)$  such that  $u\left(t\right)=\xi_k$  for  $t\in[r^{k-1},r^k)$ , and

<span id="page-14-1"></span>
$$\int_{\mathbb{R}^+} [u(t)]_{\Sigma} d\mu = \log(r) \sum_{k \in \mathbb{Z}} [\xi_k]_{\Sigma} < \infty \quad \text{and} \quad x \in \int_{\mathbb{R}^+} u d\mu.$$
 (2.46)

Finally, item (2) in Lemma 2.20 implies that  $\lim_{K\to\infty} [-x + \log(r) \sum_{k=-K}^K \xi_k]_{\Sigma} = 0$ . Thus  $\{\log(r) \xi_k\}_{k\in\mathbb{Z}} \in \tilde{\mathcal{D}}(x)$ . Proposition 2.18 provides a constant  $\tilde{c}$ , depending on s, q, and r such that

<span id="page-14-2"></span>
$$\left\|\left\{r^{sk}\mathcal{J}(r^{-k},\log\left(r\right)\xi_{k})\right\}_{k\in\mathbb{Z}}\right\|_{\ell^{q}(\mathbb{Z})} \leqslant \tilde{c} \begin{cases} \left(\int_{\mathbb{R}^{+}} \left(t^{-s}\mathcal{J}\left(t,u\left(t\right)\right)\right)^{q} \frac{1}{t} dt\right)^{1/q} & 1 \leqslant q < \infty \\ \operatorname{essup}\left\{t^{-s}\mathcal{J}\left(t,u\left(t\right)\right) : t \in \mathbb{R}^{+}\right\} & q = \infty. \end{cases}$$

$$(2.47)$$

Together, (2.45), (2.46), and (2.47) imply

$$\inf \left\{ \left\| \left\{ r^{sk} \mathscr{J}(r^{-k}, \zeta_k) \right\}_{k \in \mathbb{Z}} \right\|_{\ell^q(\mathbb{Z}; \mathbb{R})} : \left\{ \zeta_k \right\}_{k \in \mathbb{Z}} \in \tilde{\mathcal{D}}(x) \right\} \leqslant c' \left[ x \right]_{s,q,\mathscr{J}} + C\varepsilon \tag{2.48}$$

for all  $\varepsilon \in \mathbb{R}^+$ . Hence, the second inequality of (2.44) is proved.

Now suppose that  $x \in \Sigma(X_0, X_1)$  is such that  $\varnothing \neq \tilde{\mathcal{D}}(x)$  and choose  $\{\xi_k\}_{k \in \mathbb{Z}} \in \tilde{\mathcal{D}}(x)$ . We define  $u : \mathbb{R}^+ \to \Delta(X_0, X_1)$  via  $u(t) = \log(r)^{-1} \sum_{k \in \mathbb{Z}} \xi_k \chi_{[r^{k-1}, r^k)}(t)$ . For  $n \in \mathbb{N}^+$  we take  $s_n = u|_{(r^{-n}, r^n)}$ . Then  $s_n \in \text{simp}(\mathbb{R}^+; \Sigma(X_0, X_1))$  and  $s_n \to u$  everywhere as  $n \to \infty$ , which shows u to be strongly measurable. The condition  $\sum_{k \in \mathbb{Z}} [\xi_k]_{\Sigma} < \infty$  easily implies that  $\int_{\mathbb{R}^+} [s_n - u]_{\Sigma} d\mu \to 0$  as  $n \to \infty$ . Then u is  $\Sigma(X_0, X_1)$ -integrable. Moreover,  $x \in \int_{\mathbb{R}^+} u d\mu$ , as the condition  $\lim_{K \to \infty} [-x + \sum_{k=-K}^K \xi_k]_{\Sigma} = 0$  implies that  $\lim_{n \to \infty} [-x + \mathcal{I}(s_n)] = 0$ . Hence,  $\mathcal{D}(x) \neq \varnothing$ . Using Proposition 2.18 once more, we see that

$$\left\|\left\{r^{sk}\mathcal{J}(r^{-k},\xi_k)\right\}_{k\in\mathbb{Z}}\right\|_{\ell^q(\mathbb{Z})} \geqslant c \begin{cases} \left(\int_{\mathbb{R}^+} \left(t^{-s}\mathcal{J}\left(t,u\left(t\right)\right)\right)^q \frac{1}{t} \, \mathrm{d}t\right)^{1/q} & 1 \leqslant q < \infty \\ \mathrm{esssup}\left\{t^{-s}\mathcal{J}\left(t,u\left(t\right)\right) : t \in \mathbb{R}^+\right\} & q = \infty \end{cases} = c \left[x\right]_{s,q,\mathcal{J}}, \quad (2.49)$$

for some constant c depending on r, s, q. This implies the first inequality in (2.44), and the proof is complete.

As a corollary to the results in this subsection we will prove that the well-known reiteration theorem also holds in this seminormed setting under additional hypotheses. First, we require a brief quantitative lemma.

<span id="page-14-3"></span>**Lemma 2.24.** Let  $(X_0, [\cdot]_0)$ ,  $(X_1, [\cdot]_1)$  be a pair of weakly compatible pair of seminormed spaces,  $s \in (0, 1)$ , and  $1 \leq q \leq \infty$ . If  $t \in \mathbb{R}^+$  and  $x \in \Delta(X_0, X_1)$  then we have the bound

$$[x]_{s,q} \le (1-s)^{1-1/q} (1/s + 1/(1-s))t^{-s} \mathscr{J}(t,x).$$
(2.50)

*Proof.* Using the bound from equation (2.19) and then item (3) of Proposition 2.18, we simply compute:

$$(1-s)^{-1+1/q} [x]_{s,q} \leqslant [x]_{s,1} = \int_{\mathbb{R}^+} \tau^{-s} \mathscr{K}(\tau, x) \tau^{-1} d\tau \leqslant \mathscr{J}(t, x) \int_{\mathbb{R}^+} \tau^{-s-1} \min\{1, \tau t^{-1}\} d\tau. \tag{2.51}$$

<span id="page-14-4"></span>We now present the proof of the reiteration theorem. The justification is marginally more subtle than perhaps one would initially expect: we use crucially that the spaces are complete and are compatible in a sense stronger than the weak compatibility condition.

**Theorem 2.25** (Reiteration). Let  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  be a pair of complete seminormed spaces such that either  $\Delta(X_0, X_1)$  is complete or strong compatibility is satisfied. Set also  $0 \le s_0, s_1 \le 1, 0 < r < 1, s = (1-r)s_0 + rs_1$ , and  $1 \le q, q_0, q_1 \le \infty$ . We then have the following reiteration formula:

$$(X_{s_0,q_0}, X_{s_1,q_1})_{r,q} = (X_0, X_1)_{s,q} \text{ for } X_{s_i,q_i} = \begin{cases} (X_0, X_1)_{s_i,q_i} & \text{if } s_i \notin \{0,1\} \\ X_{s_i} & \text{if } s_i \in \{0,1\} \end{cases}, i \in \{0,1\}.$$
 (2.52)

*Proof.* By the symmetry  $(A_0, A_1)_{\vartheta,p} = (A_1, A_0)_{1-\vartheta,p}$  for  $A_0$ ,  $A_1$  weakly compatible seminormed spaces,  $0 < \vartheta < 1, 1 \le p \le \infty$ , it is sufficient to consider the case  $0 \le s_0 < s_1 < 1$ .

Let  $\mathcal{K}$ ,  $\mathcal{J}$  and  $\overline{\mathcal{K}}$ ,  $\overline{\mathcal{J}}$  denote the K and J functionals associated to the weakly compatible couples  $X_0, X_1$  and  $X_{s_0,q_0}, X_{s_1,q_1}$ , respectively.  $[\cdot]_{s,q}$  will denote the seminorm on  $(X_0, X_1)_{s,q}$  and  $[\cdot]_{r,q}^-$  will denote the seminorm on  $(X_{s_0,q_0}, X_{s_1,q_1})_{r,q}$ .

Suppose that  $x \in (X_{s_0,q_0}, X_{s_1,q_1})_{r,q}$  and decompose  $x = x_0 + x_1$  for  $x_i \in X_{s_i,q_i}$ . In the event that  $0 < s_0$  we use the inclusion estimate after equation (2.18) to bound for  $t \in \mathbb{R}^+$ :

$$\mathcal{K}(t,x) \leqslant \mathcal{K}(t,x_0) + \mathcal{K}(t,x_1) \leqslant t^{s_0} \left[ x_0 \right]_{s_0,\infty} + t^{s_1} \left[ x_1 \right]_{s_1,\infty}$$

$$\leqslant \max_{i \in \{0,1\}} \{ (q_i(1-s_i))^{1/q_i} \} t^{s_0} (\left[ x_0 \right]_{s_0,q_0} + t^{s_1-s_0} \left[ x_1 \right]_{s_1,q_1}), \quad (2.53)$$

with the modification  $(q_i(1-s_i))^{1/q_i}=1$  when  $q_i=\infty$ . On the other hand, if  $s_0=0$  then we modify the above estimate with  $\mathcal{K}(t,x_0) \leq [x_0]_0$ . In either case we find there is a constant  $c \in \mathbb{R}^+$  depending on  $s_i$ ,  $q_i$  for  $i \in \{0,1\}$  such that

$$[x]_{s,q} \leqslant c \left( \int_{\mathbb{R}^+} (t^{-r(s_1 - s_0)} \overline{\mathcal{K}}(t^{s_1 - s_0}, x))^q t^{-1} dt \right)^{1/q} = c(s_1 - s_0)^{-1/q} [x]_{r,q}^-, \tag{2.54}$$

with the obvious modification for  $q = \infty$ . This argument justifies the inclusion  $(X_{s_0,q_0}, X_{s_1,q_1})_{r,q} \hookrightarrow (X_0, X_1)_{s,q}$ .

Conversely, suppose that  $x \in (X_0, X_1)_{s,q}$ . By Proposition 2.23 there is at least one  $\{\xi_k\}_{k \in \mathbb{Z}} \in \tilde{\mathcal{D}}(x)$  (this latter set is defined in (2.43)). For  $t \in \mathbb{R}^+$  we claim that  $\overline{\mathcal{K}}(t,x) \leqslant \sum_{k \in \mathbb{Z}} \overline{\mathcal{K}}(t,\xi_k)$ . It suffices to prove this claim under the assumption that the right hand side is finite. If this holds then we use the completeness of  $\Sigma(X_{s_0,q_0}, X_{s_1,q_1})$  (justified by Propositions 2.3 and 2.9): there is  $y \in \Sigma(X_{s_0,q_0}, X_{s_1,q_1})$  such that  $\overline{\mathcal{K}}(t,y-\sum_{k=-K}^K \xi_k) \to 0$  as  $K \to \infty$ . As  $\Sigma(X_{s_0,q_0}, X_{s_1,q_1}) \hookrightarrow \Sigma(X_0,X_1)$ , we find  $\sum_{k=-K}^K \xi_k \to x,y$  in  $\Sigma(X_0,X_1)$ , so  $x-y \in \mathfrak{A}(\Sigma(X_0,X_1))$ . By Propositions 2.4 and 2.12 we may equate

<span id="page-15-0"></span>
$$\mathfrak{A}(\Sigma(X_0, X_1)) = \Sigma(\mathfrak{A}(X_0), \mathfrak{A}(X_1)) = \mathfrak{A}(\Sigma(X_{s_0, q_0}, X_{s_1, q_1})). \tag{2.55}$$

Hence  $\overline{\mathcal{K}}(t, x - y) = 0$ . For  $K \in \mathbb{N}$  we then estimate:

$$\overline{\mathcal{K}}(t,x) \leqslant \overline{\mathcal{K}}(t,x-y) + \overline{\mathcal{K}}(t,y-\sum_{k=-K}^{K} \xi_k) + \sum_{k=-K}^{K} \overline{\mathcal{K}}(t,\xi_k).$$
 (2.56)

Sending  $K \to \infty$  completes the proof of the claim.

With the claim in hand, we estimate the seminorm of x in the space  $(X_{s_0,q_0}, X_{s_1,q_1})_{r,q}$  using first the discrete characterization of Proposition 2.13:

$$\begin{aligned} [x]_{r,q}^{-} \lesssim & \left\| \left\{ 2^{-rm} \overline{\mathcal{K}} \left( 2^{m}, x \right) \right\}_{m \in \mathbb{Z}} \right\|_{\ell^{q}} \leqslant & \left\| \left\{ \sum_{k \in \mathbb{Z}} 2^{-rm} \overline{\mathcal{K}} \left( 2^{m}, \xi_{k} \right) \right\}_{m \in \mathbb{Z}} \right\|_{\ell^{q}} \\ & \leqslant & \left\| \left\{ \sum_{k \in \mathbb{Z}} \min \{ 2^{-rm}, 2^{(1-r)m-k} \} \overline{\mathcal{J}} \left( 2^{k}, \xi_{k} \right) \right\}_{m \in \mathbb{Z}} \right\|_{\ell^{q}}. \end{aligned}$$
 (2.57)

To each term in the innermost sum we next apply Lemma 2.24 with  $t = 2^{k/(s_1 - s_0)}$ . After a straightforward computation we arrive at the following inequality in the case  $s_0 > 0$ :

$$\overline{\mathcal{J}}(2^k, \xi_k) = \max\{ [\xi_k]_{s_0, q_0}, 2^k [\xi_k]_{s_1, q_1} \} 
\leq \max_{i \in \{0, 1\}} \{ (1 - s_i)^{1 - 1/q_i} (1/s_i + 1/(1 - s_i)) \} 2^{-s_0 k/(s_1 - s_0)} \mathcal{J}(2^{k/(s_1 - s_0)}, \xi_k) 
= c 2^{-s_0 k/(s_1 - s_0)} \mathcal{J}(2^{k/(s_1 - s_0)}, \xi_k).$$
(2.58)

In the case that  $s_0 = 0$  the same argument gives the above inequality with  $c = \max\{1, (1-s_1)^{1-1/q_1}(1/s_1 + 1/(1-s_1))\}$ . In either case, we then incorporate this information into (2.57) and recall that  $r = (s - 1)^{1-1/q_1}(1/s_1 + 1/(1-s_1))$ 

 $(s_0)/(s_1-s_0)$  in order to estimate

$$\begin{split} \left\| \left\{ \sum_{k \in \mathbb{Z}} \min\{2^{-rm}, 2^{(1-r)m-k}\} \overline{\mathcal{J}}(2^k, \xi_k) \right\}_{m \in \mathbb{Z}} \right\|_{\ell^q} \\ & \leq c \left\| \left\{ \sum_{k \in \mathbb{Z}} \min\{2^{-rm}, 2^{(1-r)m-k}\} 2^{rk} 2^{-sk/(s_1-s_0)} \mathcal{J}(2^{k/(s_1-s_0)}, \xi_k) \right\}_{m \in \mathbb{Z}} \right\|_{\ell^q} \\ & = c \left\| \left\{ \sum_{j \in \mathbb{Z}} \min\{2^{-rj}, 2^{(1-r)j}\} 2^{-s(m-j)/(s_1-s_0)} \mathcal{J}(2^{(m-j)/(s_1-s_0)}, \xi_{m-j}) \right\}_{m \in \mathbb{Z}} \right\|_{\ell^q} \\ & \leq c \left( \sum_{j \in \mathbb{Z}} \min\{2^{-rj}, 2^{(1-r)j}\} \right) \left\| \left\{ 2^{-sm/(s_1-s_0)} \mathcal{J}(2^{m/(s_1-s_0)}) \right\}_{m \in \mathbb{Z}} \right\|_{\ell^q}. \end{split}$$
 (2.59)

Taking the infimum over all  $\{\xi_k\}_{k\in\mathbb{Z}}\in\tilde{\mathcal{D}}(x)$  and using finally Proposition 2.23 gives the remaining embedding.

2.6. Sum characterization of the truncated K-method. The following theorem shows that the truncated spaces are the sum of the second factor and the K-method with  $\sigma = \infty$  space between the two factors.

<span id="page-16-0"></span>**Theorem 2.26** (Sum characterization for truncated method). Let  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  be a pair of weakly compatible seminormed spaces. Suppose that  $s \in (0,1)$ ,  $\sigma \in \mathbb{R}^+$ , and  $1 \leq q \leq \infty$ . Then we have the following equality of spaces and equivalence of seminorms:  $(X_0, X_1)_{s,q}^{(\sigma)} = \Sigma((X_0, X_1)_{s,q}, X_1)$ .

*Proof.* We begin by defining the functional  $\tilde{\mathscr{K}}: \mathbb{R}^+ \times \Sigma((X_0, X_1)_{s,q}, X_1) \to \mathbb{R}$  via

$$\tilde{\mathscr{K}}(t,x) = \inf \{ [\eta]_{s,q} + t [\xi]_1 : x = \eta + \xi, (\eta, \xi) \in (X_0, X_1)_{s,q} \times X_1 \}.$$
 (2.60)

Note that for all  $t \in \mathbb{R}^+$ , the map  $\tilde{\mathcal{K}}(t,\cdot)$  is an equivalent seminorm on  $\Sigma((X_0,X_1)_{s,q},X_1)$ .

First suppose that  $x \in \Sigma((X_0, X_1)_{s,q}, X_1) \subseteq \Sigma(X_0, X_1)$ , where the latter inclusion follows from Proposition 2.8. Pick  $y \in (X_0, X_1)_{s,q}$  and  $z \in X_1$  such that x = y + z. By Proposition 2.10 we have the bound

$$[x]_{s,q}^{(\sigma)} \leqslant [y]_{s,q}^{(\sigma)} + [z]_{s,q}^{(\sigma)} \leqslant [y]_{s,q} + c_{s,q}\sigma^{1-s}[z]_1, \text{ for } c_{s,q} = \begin{cases} q^{-1/q} (1-s)^{-1/q} & 1 \leqslant q < \infty \\ 1 & q = \infty. \end{cases}$$
(2.61)

Thus, upon taking the infimum over all such decompositions of x, we arrive at the estimate

$$[x]_{s,q}^{(\sigma)} \leqslant \max\{1, c_{s,q}\} \,\tilde{\mathcal{K}}\left(\sigma^{1-s}, x\right). \tag{2.62}$$

In particular, this implies that  $\Sigma((X_0, X_1)_{s,q}, X_1) \subseteq (X_0, X_1)_{s,q}^{(\sigma)}$ .

On the other hand, suppose  $x \in (X_0, X_1)_{s,q}^{(\sigma)}$ . Let  $\varepsilon \in \mathbb{R}^+$ . For each  $k \in \mathbb{N}$  we may then find  $(a_k, b_k) \in X_0 \times X_1$  with the following properties:

<span id="page-16-1"></span>
$$x = a_k + b_k$$
, and  $[a_k]_0 + \sigma 2^{-k} [b_k]_1 \le \mathcal{K}(\sigma 2^{-k}, x) + \varepsilon 2^{-k}$ . (2.63)

Set  $\eta \in X_1$  via  $\eta = b_0$ . Proposition 2.8 gives the bound

<span id="page-16-3"></span>
$$[\eta]_1 = [b_0]_1 \leqslant \sigma^{-1} \mathcal{K}(\sigma, x) \leqslant c \left[x\right]_{s,q}^{(\sigma)}$$

$$(2.64)$$

for some c depending on s, q, and  $\sigma$ . Note that (2.63) implies that for all  $k \in \mathbb{N}$  we have  $\xi_k = a_k - a_{k+1} = b_{k+1} - b_k \in \Delta(X_0, X_1)$ . Hence, for  $m \in \mathbb{N}$ , we may use telescoping sums to compute  $\eta + \sum_{k=0}^m \xi_k = \eta + a_0 - a_{m+1} = x - a_{m+1}$ . Proposition 2.13 provides a constant  $c \in \mathbb{R}^+$  such that  $\left\|\left\{2^{sk}\mathscr{K}(\sigma 2^{-k}, x)\right\}_{k \in \mathbb{N}}\right\|_{\ell^q(\mathbb{N})} \le c\left[x\right]_{s,q}^{(\sigma)} < \infty$ , which means that  $\lim_{k \to \infty} \mathscr{K}\left(\sigma 2^{-k}, x\right) = 0$ . This and (2.63) imply that  $[a_{m+1}]_0 \to 0$  as  $m \to \infty$ , and hence

<span id="page-16-2"></span>
$$\lim_{m \to \infty} \left[ x - \eta - \sum_{k=0}^{m} \xi_k \right]_{\Sigma} \leqslant \lim_{m \to \infty} \left[ a_{m+1} \right]_0 = 0.$$
 (2.65)

For  $k \in \mathbb{Z} \setminus \mathbb{N}$  we set  $\xi_k = 0$ . Then (2.63) implies that

$$\sum_{k \in \mathbb{Z}} [\xi_k]_{\Sigma} \leqslant \sum_{k \in \mathbb{N}} [a_k - a_{k+1}]_0 \leqslant 2 \sum_{k \in \mathbb{N}} [a_k]_0 \leqslant 2 \sum_{k \in \mathbb{N}} \mathscr{K}(\sigma 2^{-k}, x) + 4\varepsilon < \infty, \tag{2.66}$$

where finiteness follows from the inclusion  $x \in (X_0, X_1)_{s,q}$  thanks to Proposition 2.13 and Hölder's inequality (see the proof of Theorem 2.22). We deduce from this and (2.65) that  $\{\xi_k\}_{k\in\mathbb{Z}} \in \tilde{\mathcal{D}}(x-\eta)$ , where the latter set is defined in Proposition 2.23.

Next we again use (2.63) and the fact that  $\mathcal{K}(\cdot,x)$  is increasing to bound

$$\mathcal{J}(\sigma 2^{-k}, \xi_k) = \max\left\{ \left[ a_k - a_{k+1} \right], \sigma 2^{-k} \left[ b_{k+1} - b_k \right] \right\} \leqslant 2\mathcal{K}(\sigma 2^{-k}, x) + 2^{-k+1} \varepsilon \tag{2.67}$$

for  $k \in \mathbb{N}$ . Since  $\xi_k = 0$  for  $k \in \mathbb{Z} \setminus \mathbb{N}$  we have  $\mathscr{J}(\sigma 2^{-k}, \xi_k) = 0$  in this case. Combining these and using Proposition 2.23, we arrive at the bound

<span id="page-17-0"></span>
$$[x-\eta]_{s,q} \leqslant c \left\| \left\{ 2^{sk} \mathscr{J}(\sigma 2^{-k}, \xi_k) \right\}_{k \in \mathbb{Z}} \right\|_{\ell^q(\mathbb{Z})} \leqslant c \left\| \left\{ 2^{sk} \mathscr{K}(\sigma 2^{-k}, x) \right\}_{k \in \mathbb{N}} \right\|_{\ell^q(\mathbb{N})} + 2c\varepsilon \leqslant c \left( [x]_{s,q}^{(\sigma)} + 2\varepsilon \right)$$
(2.68)

for a constant  $c \in \mathbb{R}^+$  depending on s,q and  $\sigma$ , and possibly increasing from line to line. Combining (2.64) and (2.68) then yields the estimate  $\tilde{\mathcal{K}}(1,x) \leq [x-\eta]_{s,q} + [\eta]_1 \leq C([x]_{s,q}^{(\sigma)} + 2\varepsilon)$  for every  $\varepsilon \in \mathbb{R}^+$  and some  $C \in \mathbb{R}^+$  depending only on s,q, and  $\sigma$ . Letting  $\varepsilon \to 0^+$ , we find that  $(X_0,X_1)_{s,q}^{(\sigma)} \hookrightarrow \Sigma((X_0,X_1)_{s,q},X_1)$ .  $\square$ 

<span id="page-17-1"></span>As a corollary, we have the following useful density result.

**Proposition 2.27** (Dense subspaces). Let  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  be a pair of weakly compatible semi-normed spaces. The following hold for  $s \in (0, 1)$ ,  $\sigma \in \mathbb{R}^+$ , and  $1 \leq q < \infty$ :

- (1)  $\Delta(X_0, X_1)$  is dense in  $(X_0, X_1)_{s,q}$ .
- (2)  $X_1$  is dense in  $(X_0, X_1)_{s,q}^{(\sigma)}$ .

*Proof.* For the first item we use the equivalence of the K and J methods from Theorem 2.22 and then the discrete characterization from Proposition 2.23. Indeed, for  $x \in (X_0, X_1)_{s,q}$ , the discrete decomposition set  $\tilde{\mathcal{D}}(x)$  is nonempty, and we may find  $\{\xi_k\}_{k\in\mathbb{Z}}\subseteq \Delta(X_0,X_1)$  such that

$$\|\{2^{sk} \mathscr{J}(2^{-k}, \xi_k)\}_{k \in \mathbb{Z}}\|_{\ell^q(\mathbb{Z})} < \infty \text{ and } \lim_{n \to \infty} \left[ -x + \sum_{k=-n}^n \xi_k \right]_{\Sigma} = 0.$$
 (2.69)

Applying the discrete J method to  $-x + \sum_{k=-n}^{n} \xi_k$ , we find that

$$\left[-x + \sum_{k=-n}^{n} \xi_{k}\right]_{s,q} \leqslant C \left\| \left\{ 2^{sk} \mathscr{J}(2^{-k}, \xi_{k}) \right\}_{k \in \mathbb{Z} \setminus \{-n, \dots, n\}} \right\|_{\ell^{q}(\mathbb{Z} \setminus \{-n, \dots, n\})}$$
(2.70)

for some  $C \in \mathbb{R}^+$  some constant depending on s,q. Since  $q < \infty$ , the right side of this inequality vanishes as  $n \to \infty$ . As it is the case  $\sum_{k=-n}^n \xi_k \in \Delta(X_0, X_1)$ , the first item is shown.

To prove the second item we recall from Theorem 2.26 that  $(X_0, X_1)_{s,q}^{(\sigma)} = \Sigma((X_0, X_1)_{s,q}, X_1)$ . Since  $X_1$  is dense in  $X_1$  and  $\Delta(X_0, X_1)$  is dense in  $(X_0, X_1)_{s,q}$  by the first item, the density of  $X_1$  in  $(X_0, X_1)_{s,q}^{(\sigma)}$  follows, and the second item is proved.

2.7. Examples of seminorm interpolation spaces. Here we record a few examples of spaces obtained via seminorm interpolation.

**Example 2.28** (Nesting of factors). Suppose that  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  are a pair of weakly compatible seminormed spaces, and let  $\sigma \in \mathbb{R}^+$ ,  $s \in (0,1)$ , and  $1 \leq q \leq \infty$ .

(1) If  $X_0 \hookrightarrow X_1$ , then  $(X_0, X_1)_{s,q}^{(\sigma)} = X_1$  (equivalent seminorms). Indeed, by item (4) in Proposition 2.10:

$$X_1 \hookrightarrow (X_0, X_1)_{s,q}^{(\sigma)} \hookrightarrow \Sigma(X_0, X_1) \hookrightarrow X_1.$$
 (2.71)

(2) On the other hand, if  $X_1 \hookrightarrow X_0$ , then  $(X_0, X_1)_{s,q}^{(\sigma)} = (X_0, X_1)_{s,q}$  (equivalent seminorm). Indeed, by Theorem 2.26:

$$(X_0, X_1)_{s,q} \hookrightarrow (X_0, X_1)_{s,q}^{(\sigma)} = \Sigma((X_0, X_1)_{s,q}, X_1) \hookrightarrow \Sigma((X_0, X_1)_{s,q}, \Delta(X_0, X_1)) \hookrightarrow (X_0, X_1)_{s,q}. \quad (2.72)$$

<span id="page-17-2"></span>**Example 2.29** (Lebesgue spaces). Let  $(Y, \mathfrak{M}, \mu)$  be a measure space,  $(X, \|\cdot\|)$  be a Banach space, and take  $1 \leq p, q, r \leq \infty$  and  $\sigma \in \mathbb{R}^+$ ,  $s \in (0, 1)$ . Then

$$(L^{p}(Y;X);L^{r}(Y;X))_{s,q}^{(\sigma)} = \Sigma(L^{t,q}(Y;X),L^{r}(Y;X)),$$
 (2.73)

where the left factor on the right-hand-side sum is a Lorentz space and  $1 \le t \le \infty$  satisfies  $\frac{1}{t} = \frac{1-s}{p} + \frac{s}{r}$ . This follows from the sum characterization in Theorem 2.26 and the well-known characterization of Lorentz spaces as interpolation spaces (see, for instance, Theorem 1.18.6.1 in [Tri78]).

Our next example, which is a slight modification of the previous one, introduces seminormed versions of Lebesgue and Lorentz spaces. These spaces essentially consist of the classical spaces plus constants. Our motivation for introducing this somewhat odd variant is that they appear naturally in several places later in the paper.

<span id="page-18-0"></span>**Example 2.30** (Seminormed Lorentz spaces). Let  $(X, \|\cdot\|)$  be a Banach space and  $(Y, \mathfrak{M}, \mu)$  be a measure space such that  $\mu(Y) = \infty$ . Let  $1 \leq p < \infty$  and  $1 \leq q \leq \infty$  be such that if p = 1 then q = 1. In this range, the Lorentz spaces  $L^{p,q}(Y;X)$  are Banach spaces (when  $p = 1, 1 < q \leq \infty$  they only have quasinorms), and contain only the trivial constant function. We define the seminormed Lorentz space

$$\dot{L}^{p,q}(Y;X) = \{ f \in L^1_{loc}(Y;X) : \exists c \in X, f - c \in L^{p,q}(Y;X) \}$$
(2.74)

with seminorm  $[f]_{\dot{L}^{p,q}} = \inf\{\|f - c\|_{L^{p,q}} : c \in X\}$ . Note that for each  $f \in \dot{L}^{p,q}(Y;X)$  the constant  $c \in X$  such that  $f - c \in \dot{L}^{p,q}(Y;X)$  is uniquely determined since the only constant in  $L^{p,q}(Y;X)$  is 0, and as such we have that  $[f]_{\dot{L}^{p,q}} = \|f - c\|_{L^{p,q}}$ . If p = q we write  $\dot{L}^p(Y;X)$  in place of  $\dot{L}^{p,p}(Y;X)$  for the seminormed Lebesgue spaces.

Suppose now that  $1 \leq p_0, p_1 < \infty$  and  $1 \leq q_0, q_1 \leq \infty$  are such that  $q_i = 1$  if  $p_i = 1$ . We claim that for  $s \in (0,1), \ \sigma \in \mathbb{R}^+, \ 1/p = (1-s)/p_0 + s/p_1$ , and  $1 \leq q \leq \infty$  we have the seminormed interpolation identities:

$$(\dot{L}^{p_0,q_0}(Y;X),\dot{L}^{p_1,q_1}(Y;X))_{s,q} = \dot{L}^{p,q}(Y;X)$$
 with equality of seminorms, and  $(\dot{L}^{p_0,q_0}(Y;X),\dot{L}^{p_1,q_1}(Y;X))_{s,q}^{(\sigma)} = \Sigma(\dot{L}^{p,q}(Y;X),\dot{L}^{p_1,q_1}(Y;X)).$  (2.75)

The latter formula follows from the former and the sum characterization in Theorem 2.26, so we will only prove the former. The proof of the former for standard Lorentz spaces can be found, for instance, in Theorems 1.18.6.1/2 of [Tri78]. In proving this we let  $\mathcal{K}$ ,  $\dot{\mathcal{K}}$  denote the K-functionals associated to the couples  $L^{p_0,q_0}(Y;X)$ ,  $L^{p_1,q_1}(Y;X)$  and  $\dot{L}^{p_0,q_0}(Y;X)$ ,  $\dot{L}^{p_1,q_1}(Y;X)$ , respectively. The seminorm on  $(L^{p_0,q_0}(Y;X),L^{p_1,q_1}(Y;X))_{s,q}$  will be denoted  $[\cdot]_{s,q}$ .

Let  $f \in \dot{L}^{p,q}(Y;X)$ ,  $t \in \mathbb{R}^+$ , and choose the unique  $c \in X$  such that  $f-c \in L^{p,q}(Y;X)$ . If  $f-c = g_0 + g_1$  for  $g_i \in L^{p_i,q_i}(Y;X)$ , then  $\dot{g}_i \in \dot{L}^{p_i,q_i}(Y;X)$  and  $[g_i]_{\dot{L}^{p_i,q_i}} = \|g_i\|_{L^{p_i,q_i}}$ , and hence

$$\dot{\mathscr{K}}(t,f) \leqslant [g_0 + c]_{\dot{L}^{p_0,q_0}} + t [g_1]_{\dot{L}^{p_1,q_1}} = \|g_0\|_{L^{p_0,q_0}} + t \|g_1\|_{L^{p_1,q_1}} \Rightarrow \dot{\mathscr{K}}(t,f) \leqslant \mathscr{K}(t,f-c). \tag{2.76}$$

Similarly, if  $f = g_0 + g_1$  for  $g_i \in \dot{L}^{p_i,q_i}(Y;X)$ , then there exist unique  $c_i \in X$  such that  $g_i - c_i \in L^{p_i,q_i}(Y;X)$  and  $c_0 + c_1 = c$ , which means that  $f - c = (g_0 - c_0) + (g_1 - c_1)$  and

$$\mathscr{K}(t, f - c) \leqslant \|g_0 - c_0\|_{L^{p_0, q_0}} + t \|g_1 - c_1\|_{L^{p_1, q_1}} = [g_0]_{\dot{L}^{p_0, q_0}} + t [g_1]_{\dot{L}^{p_1, q_1}} \Rightarrow \mathscr{K}(t, f - c) \leqslant \dot{\mathscr{K}}(t, f). \tag{2.77}$$

Thus, for  $t \in \mathbb{R}^+$  we have that  $\mathscr{K}(t,f-c) = \dot{\mathscr{K}}(t,f)$ , and we deduce from this and the usual interpolation properties of Lebesgue and Lorentz spaces that  $[f]_{s,q}^{\cdot} = [f-c]_{s,q} = \|f-c\|_{L^{p,q}} = [f]_{\dot{L}^{p,q}}$ . A similar argument proves the same identity for each  $f \in (\dot{L}^{p_0,q_0}(Y;X),\dot{L}^{p_1,q_1}(Y;X))_{s,q}$ , from which the claim follows.

<span id="page-18-2"></span>In our last example of this subsection we quantify a sense in which the space of functions of bounded mean oscillation is a substitute for the space of essentially bounded functions.

**Example 2.31** (BMO and Lebesgue spaces). Recall that the space BMO  $(\mathbb{R}^n; \mathbb{K})$  consists of  $f \in L^1_{loc}(\mathbb{R}^n; \mathbb{K})$  such that

$$[f]_{\text{BMO}} = \sup_{Q} \frac{1}{\mathfrak{L}^{n}(Q)} \int_{Q} \left| f - \frac{1}{\mathfrak{L}^{n}(Q)} \int_{Q} f \right| < \infty, \tag{2.78}$$

where the supremum is taken over cubes of the form  $Q = \prod_{j=1}^{n} [a_j, a_j + \ell]$ . This only defines a seminormed space, as it is readily verified that the annihilator consists of all constant functions.

Let  $1 \leq p < \infty$  and  $\mathbb{K} \in \{\mathbb{R}, \mathbb{C}\}$ . We claim that for all  $s \in (0,1)$ ,  $\sigma \in \mathbb{R}^+$ , and  $1 \leq q \leq \infty$  we have the formulae:

<span id="page-18-1"></span>
$$(L^p(\mathbb{R}^n; \mathbb{K}); BMO(\mathbb{R}^n; \mathbb{K}))_{s,q} = \dot{L}^{r,q}(\mathbb{R}^n; \mathbb{K})$$
 (2.79)

and

<span id="page-19-0"></span>
$$\left(L^{p}\left(\mathbb{R}^{n};\mathbb{K}\right),\mathrm{BMO}\left(\mathbb{R}^{n};\mathbb{K}\right)\right)_{s,q}^{(\sigma)}=\Sigma(\dot{L}^{r,q}\left(\mathbb{R}^{n};\mathbb{K}\right);\mathrm{BMO}\left(\mathbb{R}^{n};\mathbb{K}\right))=\Sigma\left(L^{r,q}\left(\mathbb{R}^{n};\mathbb{K}\right),\mathrm{BMO}\left(\mathbb{R}^{n};\mathbb{K}\right)\right),\ \ (2.80)$$

for  $r = p/(1-s) \in (1, \infty)$  and the dotted spaces as in Example 2.30.

We first remark how (2.80) will follow from (2.79). Given formula (2.79) we may apply the sum characterization (Theorem 2.26) to obtain the first equality of equation (2.80). The second equality then follows from the following constant shifting argument. For each  $f \in \dot{L}^{r,q}(\mathbb{R}^n;\mathbb{K})$  there is a unique  $c \in \mathbb{K}$  such that  $f - c \in L^{r,q}(\mathbb{R}^n;\mathbb{K})$  and  $[f]_{\dot{L}^{r,q}} = ||f - c||_{L^{r,q}}$ ; if, in addition,  $g \in \text{BMO}(\mathbb{R}^n;\mathbb{K})$  then  $[g]_{\text{BMO}} = [g + c]_{\text{BMO}}$ . Thus f + g = (f - c) + (g + c) belongs to the right most space in (2.80), and its seminorm is no more than  $[f]_{\dot{L}^{r,q}} + [g]_{\text{BMO}}$ . This argument shows the embedding of the middle space within the rightmost. The opposite embedding is clear, as  $L^{r,q}(\mathbb{R}^n;\mathbb{K}) \hookrightarrow \dot{L}^{r,q}(\mathbb{R}^n;\mathbb{K})$ .

The space on the left side of (2.79) was asserted to be  $L^{r,q}(\mathbb{R}^n;\mathbb{K})$  in the paper [Han77]. However, there is a subtle error in the proof of this, Theorem 1 in [Han77], caused by failing to recognize that  $(L^p(\mathbb{R}^n;\mathbb{K});\mathrm{BMO}(\mathbb{R}^n;\mathbb{K}))_{s,q}$  is not Hausdorff due to a nontrivial annihilator (see Proposition 2.12), and so limits in the interpolation space are not unique, nor is the standard quasi-Banach reiteration theorem available for use. Here we will give a variant of the argument used in [Han77] to correctly identify the missing constants now present in the right side of (2.79). Note, though, that [Han77] also seeks to identify the left side of (2.79) with 0 , but we are unable to address this question without further generalizing our work to spaces defined with semiquasinorms.

We first prove (2.79) in the special case q = r. Since  $L^{\infty}(\mathbb{R}^n; \mathbb{K}) \hookrightarrow \text{BMO}(\mathbb{R}^n; \mathbb{K})$  it follows immediately that  $L^r(\mathbb{R}^n; \mathbb{K}) = (L^p(\mathbb{R}^n; \mathbb{K}), L^{\infty}(\mathbb{R}^n; \mathbb{K}))_{s,p} \hookrightarrow (L^p(\mathbb{R}^n; \mathbb{K}), \text{BMO}(\mathbb{R}^n; \mathbb{K}))_{s,r}$ . The right hand space has an annihilator consisting of exactly the constant functions (Proposition 2.12 applies since the intersection of the factors is Banach). Thus, the same embedding holds for  $\dot{L}^r(\mathbb{R}^n; \mathbb{K})$ .

To prove the reverse embedding we need two tools from harmonic analysis. The first is the decreasing rearrangement of a measurable function  $g: \mathbb{R}^n \to \mathbb{K}$ , which we denote by  $g^*: \mathbb{R}^+ \to [0, \infty]$ . We refer, for instance, to Chapter 1.4 of [Gra14a] for a thorough discussion of rearrangements and their relation to Lorentz spaces. The main features we will need here are the estimates  $(g_0 + g_1)^*(t) \leq g_0^*(t/2) + g_1^*(t/2)$  for  $g_0, g_1: \mathbb{R}^n \to \mathbb{K}$  measurable, and

$$|||g||_{L^{p,\infty}} = \sup_{t \in \mathbb{R}^+} t^{1/p} g^{\star}(t) \leqslant \left( \int_{\mathbb{R}^+} (g^{\star}(t))^p dt \right)^{1/p} = ||g||_{L^p}$$
(2.81)

for  $1 \leq p < \infty$  and  $g \in L^p(\mathbb{R}^n; \mathbb{K})$ , where on the left  $\|\|\cdot\|\|_{L^{p,\infty}}$  is the quasinorm on  $L^{p,\infty}(\mathbb{R}^n; \mathbb{K})$  that is equivalent to the interpolation norm when p > 1. The second tool is the 'sharp' function: given  $f \in L^1_{loc}(\mathbb{R}^n; \mathbb{K})$  we define  $f^{\sharp}: \mathbb{R}^n \to [0, \infty]$  via

$$f^{\sharp}(x) = \sup_{Q \ni x} \frac{1}{\mathfrak{L}^{n}(Q)} \int_{Q} \left| f - \frac{1}{\mathfrak{L}^{n}(Q)} \int_{Q} f \right|, \tag{2.82}$$

where the supremum is taken over all cubes of the form  $Q = \prod_{j=1}^{n} [a_j, a_j + \ell] \subset \mathbb{R}^n$  containing x. We will employ two essential facts about the sharp function. First, if  $1 < \rho_0, \rho < \infty$  then there is  $c_\rho \in \mathbb{R}^+$  such that we have the control:

<span id="page-19-1"></span>
$$c_{\rho}^{-1} \|f\|_{L^{\rho}} \leqslant \|f^{\sharp}\|_{L^{\rho}}, \text{ for all } f \in L^{\rho_0}(\mathbb{R}^n; \mathbb{K}).$$
 (2.83)

In other words, provided that f belongs to some  $L^{\rho_0}$ , the above inequality holds in any  $L^{\rho}$ . A proof can be found in Chapter IV of [Ste93]. Second,  $(\cdot)^{\sharp}$  has the same boundedness properties as the Hardy-Littlewood maximal functions (see, for instance, Chapter I of [Ste93]). That is, the sharp map is weak type (1,1) and strong type (p,p). This follows since the sublinear operators are related pointwise via  $(\cdot)^{\sharp} \leq 2M(\cdot)$ , where M is the cubic maximal operator.

With these tools in hand, we can prove prove the reverse inclusion. Suppose initially that

$$g \in \Delta(L^p(\mathbb{R}^n; \mathbb{K}); BMO(\mathbb{R}^n; \mathbb{K})) \subset (L^p(\mathbb{R}^n; \mathbb{K}), BMO(\mathbb{R}^n; \mathbb{K}))_{s,r}$$
 (2.84)

and decompose  $g = g_0 + g_1$  for  $g_0 \in L^p(\mathbb{R}^n; \mathbb{K})$  and  $g_1 \in BMO(\mathbb{R}^n; \mathbb{K})$ . Using the subadditivity of  $(\cdot)^{\sharp}$  with the weak-type (p, p) boundedness of  $(\cdot)^{\sharp}$  and the definition of  $[\cdot]_{BMO}$ , we may estimate for  $t \in \mathbb{R}^+$ :

$$t^{1/p}(g^{\sharp})^{\star}(t) \leqslant t^{1/p}(g_{0}^{\sharp} + g_{1}^{\sharp})^{\star}(t) \leqslant t^{1/p}(g_{0}^{\sharp})^{\star}(t/2) + t^{1/p}(g_{1}^{\sharp})^{\star}(t/2) \leqslant 2^{1/p} \left\| \left\| g_{0}^{\sharp} \right\| \right\|_{L^{p,\infty}} + t^{1/p} \left\| \left( g_{1}^{\sharp} \right)^{\star} \right\|_{L^{\infty}}$$

$$\leqslant c \left( \left\| \left\| g_{0}^{\sharp} \right\| \right\|_{L^{p,\infty}} + t^{1/p} \left\| g_{1}^{\sharp} \right\|_{L^{\infty}} \right) \leqslant c \left( \left\| g_{0} \right\|_{L^{p}} + t^{1/p} \left[ g_{1} \right]_{\text{BMO}} \right), \quad (2.85)$$

where  $c \in \mathbb{R}^+$  is a constant independent of g. Taking the infimum over all decompositions of g shows that  $t^{1/p}(g^{\sharp})^{\star}(t) \leq c \mathcal{K}(t^{1/p},g)$  for  $t \in \mathbb{R}^+$ . This, the identity  $r = \frac{p}{1-s}$ , and (2.83) then allow us to estimate

$$\begin{aligned} c_r^{-1} \|g\|_{L^r} &\leqslant \|g^{\sharp}\|_{L^r} = \left(\int_{\mathbb{R}^+} t \left((g^{\sharp})^{\star}(t)\right)^r t^{-1} \, \mathrm{d}t\right)^{1/r} = \left(\int_{\mathbb{R}^+} \left(t^{(1-s)/p} (g^{\sharp})^{\star}(t)\right)^r t^{-1} \, \mathrm{d}t\right)^{1/r} \\ &\leqslant c \left(\int_{\mathbb{R}^+} \left(t^{-s/p} \mathcal{K}(t^{1/p}, g)\right)^r t^{-1} \, \mathrm{d}t\right)^{1/r} \leqslant c p^{1/r} \left(\int_{\mathbb{R}^+} (\tau^{-s} \mathcal{K}(\tau, g))^r \tau^{-1} \, \mathrm{d}\tau\right)^{1/r} = c \left[g\right]_{s,r}. \end{aligned} (2.86)$$

We now use (2.86) to deduce the general case via a limiting argument. Given  $f \in (L^p(\mathbb{R}^n; \mathbb{K}); BMO(\mathbb{R}^n; \mathbb{K}))_{s,r}$ , Proposition 2.27 asserts that there is a sequence  $\{f_k\}_{k\in\mathbb{N}} \subset \Delta(L^p(\mathbb{R}^n; \mathbb{K}); BMO(\mathbb{R}^n; \mathbb{K}))$  for which  $f_k \to f$  in  $(L^p(\mathbb{R}^n; \mathbb{K}); BMO(\mathbb{R}^n; \mathbb{K}))_{s,r}$  as  $k \to \infty$ . For  $m, k \in \mathbb{N}$  taking  $g = f_k - f_m$  in (2.86) shows  $\{f_k\}_{k\in\mathbb{N}}$  is a Cauchy sequence in  $L^r(\mathbb{R}^n; \mathbb{K})$ . Let  $\tilde{f}$  denote its  $L^r$ -limit. By Proposition 2.12 the annihilator of  $(L^p(\mathbb{R}^n; \mathbb{K}); BMO(\mathbb{R}^n; \mathbb{K}))_{s,r}$  is the subspace of constant functions. As  $L^r(\mathbb{R}^n; \mathbb{K})$  is embedded within this former space we conclude that  $f - \tilde{f}$  is a constant function (note that it's precisely at this point where the error appears in [Han77]). Hence  $f \in \dot{L}^r(\mathbb{R}^n; \mathbb{K})$ , and we can estimate:

$$[f]_{\dot{L}^r} \le \|\tilde{f}\|_{L^r} \le \|\tilde{f} - f_k\|_{L^r} + cc_r [f_k]_{s,r} \to cc_r [f]_{s,r} \text{ as } k \to \infty.$$
 (2.87)

This completes the proof of (2.79) in the special case q = r.

To prove (2.79) in the general case we will use reiteration, and for this we need the fact that the intersection of  $L^p(\mathbb{R}^n;\mathbb{K})$  and BMO  $(\mathbb{R}^n;\mathbb{K})$  is complete, which follows easily from the fact that convergence in  $L^p$  implies convergence in  $L^1$  of every cube. Let  $u,v\in\mathbb{R}$  satisfy  $1\leqslant p< u< r< v<\infty$  and set  $\vartheta=(1/r-1/u)/(1/v-1/u)\in(0,1)$ . The above special case shows that

$$((L^p(\mathbb{R}^n;\mathbb{K}),\mathrm{BMO}(\mathbb{R}^n;\mathbb{K}))_{1-p/u,u},(L^p(\mathbb{R}^n;\mathbb{K}),\mathrm{BMO}(\mathbb{R}^n;\mathbb{K}))_{1-p/v,v})_{\vartheta,q}=(\dot{L}^u(\mathbb{R}^n;\mathbb{K}),\dot{L}^v(\mathbb{R}^n;\mathbb{K}))_{\vartheta,q}.$$
(2.88)

Example (2.29) informs us that the right hand side is the Lorentz-like space  $\dot{L}^{r,q}(\mathbb{R}^n;\mathbb{K})$ , while Theorem 2.25 tells us the left hand side is equal to  $(L^p(\mathbb{R}^n;\mathbb{K}), BMO(\mathbb{R}^n;\mathbb{K}))_{\sigma,q}$  for  $\sigma = (1-\vartheta)(1-p/u) + \vartheta(1-p/v)$ . Using that  $p = (1-s)((1-\vartheta)/u + \vartheta/v)^{-1}$  we compute that  $\sigma = s$ . Thus (2.79) is shown in all cases.

## 3. Homogeneous Sobolev and Homogeneous Besov spaces

<span id="page-20-0"></span>We now use the interpolation theory developed in the previous section to realize the homogeneous Besov spaces as intermediate interpolation spaces with respect to members of the scale of homogeneous Sobolev spaces. Along the way we will also develop frequency space characterizations used later in the paper. Many of the results we present in this section are essentially already known in the literature, and we have attempted to omit as many proofs as possible. The proofs we have included are meant to highlight the direct use of seminorms rather techniques employing spaces of distributions modulo polynomials. The precise statements of the results in our notation will also be essential in the following section, where we develop the theory of screened Sobolev and screened Besov spaces. The reader already fluent in analysis of homogeneous function spaces could skip to Section 4.

3.1. **Dyadic localization.** Here, for convenience of the reader, we recall the essentials of dyadic localization and Littlewood-Paley theory. We refer the reader to Appendix B.2 for the relevant notions of real valued tempered distributions and multipliers.

<span id="page-20-2"></span>**Lemma 3.1** (Dyadic Partition of Unity). There exists a radial  $\psi \in C_c^{\infty}(\mathbb{R}^n; \mathbb{R})$  with supp  $\psi = \overline{B(0,2)} \setminus B(0,2^{-1})$ ,  $\psi(\xi) \in \mathbb{R}^+$  for  $\xi \in B(0,2) \setminus \overline{B(0,2^{-1})}$ , and  $\sum_{k \in \mathbb{Z}} \delta_{2^k} \psi = 1$  on  $\mathbb{R}^n \setminus \{0\}$ . Note that the  $\delta_{2^k}$  are the isotropic dilation operators, as in Lemma B.5.

<span id="page-20-1"></span> $\triangle$ 

*Proof.* See, for instance, Proposition 2.10 in [BCD11].

<span id="page-21-0"></span>This dyadic partition of unity leads to the creation of 'projection-like' operators that localize a given distribution at a certain dyadic annulus of frequencies.

**Definition 3.2** (Dyadic localization). Let  $\psi$  be the special function from Lemma 3.1. To each  $j \in \mathbb{Z}$  we define the operator  $\pi_j : \mathscr{S}^*(\mathbb{R}^n; \mathbb{K}) \to C^{\omega}(\mathbb{R}^n; \mathbb{K}) \cap \mathscr{S}^*(\mathbb{R}^n; \mathbb{K})$  via  $\pi_j f = [(\delta_{2^j} \psi) \hat{f}]^{\vee}$ . This is well-defined by the Paley-Wiener-Schwartz theorem (see Chapter 6, Section 4 in [Yos95]) and Lemma B.7.

<span id="page-21-3"></span>The following lemmas record some basic properties of these operators.

## Lemma 3.3. The following hold:

- (1) Suppose that  $\varphi \in \mathscr{S}(\mathbb{R}^n; \mathbb{K})$  is such that  $0 \notin \operatorname{supp} \hat{\varphi}$ . Then  $\sum_{j=-m}^m \pi_j \varphi \to \varphi$  in  $\mathscr{S}(\mathbb{R}^n; \mathbb{K})$  as  $m \to \infty$ .
- (2) If  $f \in \mathscr{S}^*(\mathbb{R}^n; \mathbb{K})$ , then for each  $\ell \in \mathbb{Z}$  the sequence  $\left\{\sum_{j=0}^m \pi_{j+\ell} f\right\}_{m \in \mathbb{N}}$  converges in  $\mathscr{S}^*(\mathbb{R}^n; \mathbb{C})$  to  $g \in \mathscr{S}^*(\mathbb{R}^n; \mathbb{K})$  with the property that for all  $\varphi \in \mathscr{S}(\mathbb{R}^n; \mathbb{C})$  with  $0 \notin \operatorname{supp} \hat{\varphi}$

$$\langle f - g, \varphi \rangle = \left\langle \sum_{j=-\infty}^{\ell-1} \pi_j f, \varphi \right\rangle$$
 (3.1)

where the right-hand-side is well defined since  $\langle \pi_j f, \varphi \rangle = 0$  for all but finitely many  $j \in \mathbb{Z}$ ,  $j < \ell$ .

(3) Suppose that  $f, g \in \mathscr{S}^*(\mathbb{R}^n, \mathbb{K})$  satisfy  $\pi_j f = \pi_j g$  for all  $j \in \mathbb{Z}$ . Then there exists a polynomial  $Q : \mathbb{R}^n \to \mathbb{K}$  such that f + Q = g.

*Proof.* The first item follows from standard properties of the Schwartz class, and the second item follows from the first. We now prove the third item. If  $\varphi \in \mathscr{S}(\mathbb{R}^n; \mathbb{K})$  is such that  $0 \notin \operatorname{supp} \hat{\varphi}$ , by the first item  $\varphi = \sum_{j \in \mathbb{Z}} \pi_j \varphi$ , with convergence in  $\mathscr{S}(\mathbb{R}^n; \mathbb{K})$ . Consequently:

$$\langle g - f, \varphi \rangle = \sum_{j \in \mathbb{Z}} \langle g - f, \pi_j \varphi \rangle = \sum_{j \in \mathbb{Z}} \langle \pi_j (g - f), \varphi \rangle = 0.$$
 (3.2)

Then  $\hat{g} - \hat{f}$  is a tempered distribution supported at the origin, and hence g - f is a K-valued polynomial by, for instance, Corollary 2.4.2 in [Gra14a].

<span id="page-21-2"></span>The next lemma shows that the operators are almost idempotent and almost orthogonal.

**Lemma 3.4** (Almost idempotence and almost orthogonality of dyadic localization). The operators  $\{\pi_j\}_{j\in\mathbb{Z}}$  from Definition 3.2 are 'almost idempotent': if  $j\in\mathbb{Z}$  and  $f\in\mathscr{S}^*(\mathbb{R}^n;\mathbb{K})$ , then for all  $m,k\in\mathbb{N}^+$  we have that

$$\pi_j f = \left(\sum_{\ell=-m}^k \pi_{j+\ell}\right) \pi_j f = \pi_j \left(\sum_{\ell=-m}^k \pi_{j+\ell}\right) f. \tag{3.3}$$

They are also 'almost orthogonal': if  $j, k \in \mathbb{Z}$  and |j - k| > 1, then  $\pi_j \pi_k f = 0$ .

*Proof.* These follow immediately from the properties of  $\psi$  from Lemma 3.1.

<span id="page-21-1"></span>Next we recall the Littlewood-Paley characterizations of  $L^p$ .

**Theorem 3.5** (Littlewood-Paley inequalities in  $L^p$ ). Let 1 . The following hold:

(1) Frequency characterization of  $L^p(\mathbb{R}^n;\mathbb{K})$ : For  $f \in \mathscr{S}^*(\mathbb{R}^n;\mathbb{K})$  write

$$[f]_{L^{p}_{\sim}} = \left\| \left( \sum_{j \in \mathbb{Z}} |\pi_{j} f|^{2} \right)^{1/2} \right\|_{L^{p}} \in [0, \infty].$$
 (3.4)

There exists a constant  $c \in \mathbb{R}^+$ , depending only on n and p, such that the following hold:

- (a) If  $f \in L^p(\mathbb{R}^n; \mathbb{K})$ , then  $c^{-1}[f]_{L^p} \leq ||f||_{L^p}$ .
- (b) If  $f \in \mathscr{S}^*(\mathbb{R}^n; \mathbb{K})$  is such that  $[f]_{L^p_{\infty}} < \infty$ , then there exists a unique polynomial  $Q : \mathbb{R}^n \to \mathbb{K}$  such that f Q can be identified with an  $L^p(\mathbb{R}^n; \mathbb{K})$  function, and  $||f Q||_{L^p} \le c[f]_{L^p}$ .
- (2) Vector-valued inequality: Let  $\phi \in L^1(\mathbb{R}^n; \mathbb{C}) \cap C^1(\mathbb{R}^n; \mathbb{C})$  satisfy

$$0 = \int_{\mathbb{R}^n} \phi \ and \ \sup_{x \in \mathbb{R}^n} (1 + |x|)^{n+1} \left( |\phi(x)| + |\nabla \phi(x)| \right) < \infty. \tag{3.5}$$

For  $f \in L^p(\mathbb{R}^n;\mathbb{C})$  and  $j \in \mathbb{Z}$  we write  $\pi_j^{\phi} f = (\delta_{2^j}\phi)^{\vee} * f$ . Let  $1 < r < \infty$ . There is a constant  $c \in \mathbb{R}^+$ , depending only on n, p, r, and  $\phi$ , such that for any sequence  $\{f_k\}_{k \in \mathbb{Z}} \subset L^p(\mathbb{R}^n;\mathbb{C})$  we have the bound

$$\left\| \left( \sum_{j \in \mathbb{Z}} \left( \sum_{k \in \mathbb{Z}} \left| \pi_k^{\phi} f_j \right|^2 \right)^{r/2} \right)^{1/r} \right\|_{L^p} \leqslant c \left\| \left( \sum_{j \in \mathbb{Z}} \left| f_j \right|^r \right)^{1/r} \right\|_{L^p}. \tag{3.6}$$

*Proof.* See Theorem 6.1.2 and Proposition 6.1.4 in [Gra14a].

3.2. **Homogeneous Sobolev spaces.** Our primary goal in this subsection is to develop frequency-space characterizations of the homogeneous Sobolev spaces.

**Definition 3.6** (Homogeneous Sobolev spaces). Let  $1 \le p \le \infty$  and define the homogeneous Sobolev space

$$\dot{W}^{1,p}\left(\mathbb{R}^{n};\mathbb{K}\right) = \left\{ f \in L^{1}_{loc}\left(\mathbb{R}^{n};\mathbb{K}\right) : \forall j \in \left\{1,\dots,n\right\}, \ \partial_{j}f \in L^{p}\left(\mathbb{R}^{n};\mathbb{K}\right) \right\}. \tag{3.7}$$

This vector space is endowed with the seminorm  $[\cdot]_{\dot{W}^{1,p}}: \dot{W}^{1,p}\left(\mathbb{R}^n; \mathbb{K}\right) \to \mathbb{R}$  given by  $[f]_{\dot{W}^{1,p}} = \sum_{j=1}^{n} \|\partial_j f\|_{L^p}$ .

<span id="page-22-2"></span>Next we recall some useful facts about homogeneous Sobolev spaces. The first fact is a density result.

**Lemma 3.7** (Density of compactly supported smooth functions in the homogeneous Sobolev spaces). For  $1 \le p < \infty$  the following are equivalent:

- (1)  $C_c^{\infty}(\mathbb{R}^n;\mathbb{K}) \subset \dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$  is dense: for every  $u \in \dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$  and  $\varepsilon \in \mathbb{R}^+$  there exists  $w \in C_c^{\infty}(\mathbb{R}^n;\mathbb{K})$  such that  $[u-w]_{\dot{W}^{1,p}} < \varepsilon$ .
- (2) 1

*Proof.* See Theorem 4 in [HaKa95].

The second shows that functions in  $\dot{W}^{1,p}$  define tempered distributions.

**Lemma 3.8** (Members of homogeneous Sobolev spaces are tempered). Let  $1 \leq p \leq \infty$ . Then the inclusion  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}) \subset \mathscr{S}^*(\mathbb{R}^n;\mathbb{K})$  holds. More precisely, if  $f \in \dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$ , then the mapping

$$\mathscr{S}(\mathbb{R}^n; \mathbb{C}) \ni \varphi \mapsto \int_{\mathbb{R}^n} f\varphi \in \mathbb{C}$$
(3.8)

is well defined, continuous on  $\mathscr{S}(\mathbb{R}^n;\mathbb{C})$ , and defines a  $\mathbb{K}$ -valued distribution.

Proof. If  $1 \leq p < n$ , then the Gagliardo-Nirenberg-Sobolev embedding (see, for instance, Theorem 12.9 in [Leo17]) implies that each member of  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$  is the sum of a constant function and an  $L^q$ -integrable function with  $q = \frac{np}{n-p}$ , and thus defines a tempered distribution. If p = n, then  $\dot{W}^{1,n}(\mathbb{R}^n;\mathbb{K}) \hookrightarrow \mathrm{BMO}(\mathbb{R}^n;\mathbb{K})$  by, for instance, Theorem 12.31 in [Leo17]. The fact that functions of bounded mean oscillation are tempered is a consequence of item (ii) in Proposition 3.1.5 in [Gra14b]. Next if  $n , then <math>\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}) \hookrightarrow \dot{C}^{0,1-n/p}(\mathbb{R}^n;\mathbb{K})$  (the latter space is the homogeneous Hölder space defined in Section 1.3) thanks to Morrey's embedding (see Theorem 12.48 and Remark 12.49 in [Leo17]). The Hölder space is tempered since its members grow at most linearly. Finally  $\dot{W}^{1,\infty}(\mathbb{R}^n;\mathbb{K})$  is tempered since its elements may be modified on a null set to obtain a Lipschitz map - and hence tempered distribution (see the proof of Lemma 3.17 below).

<span id="page-22-0"></span>The third result concerns the completeness of this space.

**Lemma 3.9** (Completeness and annihilators of homogeneous Sobolev spaces). Suppose that  $1 \leq p \leq \infty$ . Then, the space  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$  is semi-Banach. Moreover,  $\mathfrak{A}(\dot{W}^{1,p}) = \{constant \ functions\}.$ 

*Proof.* This follows from the completeness of the Lebesgue spaces paired with Poincaré inequalities on cubes.  $\Box$ 

<span id="page-22-1"></span>We now prove a strong compatibility result.

**Lemma 3.10** (Strong compatibility). For  $1 \leq p \leq \infty$ , the seminormed spaces  $L^p(\mathbb{R}^n;\mathbb{K})$  and  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$  are strongly compatible in the sense of definition 2.1.

Proof. This result is an easy consequence of Proposition 2.4. We view  $L^p(\mathbb{R}^n;\mathbb{K})$  and  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$  as simultaneously belonging to  $L^1_{\text{loc}}(\mathbb{R}^n;\mathbb{K})$ . Let X denote the vector subspace consisting of their sum. Notice that  $\Delta(L^p(\mathbb{R}^n;\mathbb{K}),\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}))=W^{1,p}(\mathbb{R}^n;\mathbb{K})$  is a Banach space. Hence the annihilator of X,  $\mathfrak{A}(X)$ , is the sum of the annihilators of each factor. This is exactly the collection of constant functions. Therefore  $L^p(\mathbb{R}^n;\mathbb{K}),\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})\hookrightarrow X$ , and  $\mathfrak{A}(X)=\mathfrak{A}(L^p(\mathbb{R}^n;\mathbb{K}))\cup\mathfrak{A}(\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}))$ . This shows that the pair  $L^p(\mathbb{R}^n;\mathbb{K})$  and  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$  are strongly compatible.

<span id="page-23-0"></span>Now we explore the precise relation between the scales of homogeneous Sobolev spaces and the Riesz potential spaces. This yields a Fourier characterization of the former.

**Definition 3.11** (Riesz potentials and spaces). Let  $s \in \mathbb{R}$ . If  $f \in \mathscr{S}^*(\mathbb{R}^n; \mathbb{K})$  is such that  $0 \notin \operatorname{supp} \hat{f}$ , then we define  $\Lambda^s f \in \mathscr{S}^*(\mathbb{R}^n; \mathbb{K})$  via:  $\langle \Lambda^s f, \varphi \rangle = \langle \hat{f}, \varrho | \cdot |^s \check{\varphi} \rangle \in \mathbb{C}$ , where  $\varrho \in C^{\infty}(\mathbb{R}^n)$  is any radial function satisfying  $\varrho = 1$  on  $\operatorname{supp} \hat{f}$ , and  $\varrho = 0$  on  $B(0, \kappa)$ ,  $\kappa = \min \{1, \operatorname{dist}(\operatorname{supp} \hat{f}, 0)\} \in \mathbb{R}^+$ . The purpose of the cutoff function  $\varrho$  is to guarantee that  $\varrho | \cdot |^s \hat{\varphi} \in \mathscr{S}(\mathbb{R}^n; \mathbb{C})$ . It's straightforward to verify that this definition of  $\Lambda^s$  is independent of  $\varrho$ ; hence,  $\Lambda^s$  defines a linear map on its domain that preserves the property of being  $\mathbb{K}$ -valued. For 1 we define the Riesz potential space

$$\dot{H}^{s,p}\left(\mathbb{R}^{n};\mathbb{K}\right) = \left\{ f \in \mathscr{S}^{*}\left(\mathbb{R}^{n};\mathbb{K}\right) : \left\{ \sum_{k=-j}^{j} \Lambda^{s} \pi_{k} f \right\}_{j \in \mathbb{N}} \subset L^{p}\left(\mathbb{R}^{n};\mathbb{K}\right) \text{ is convergent } \right\}. \tag{3.9}$$

We equip this space with the seminorm  $[\cdot]_{\dot{H}^{s,p}} \to [0,\infty)$  defined by

$$[f]_{\dot{H}^{s,p}} = \lim_{j \to \infty} \left\| \sum_{k=-j}^{j} \Lambda^{s} \pi_{k} f \right\|_{L^{p}} = \left\| \lim_{j \to \infty} \sum_{k=-j}^{j} \Lambda^{s} \pi_{k} f \right\|_{L^{p}}. \tag{3.10}$$

We first present a Littlewood-Paley characterization of  $\dot{H}^{s,p}$  that gives a more useful seminorm to work with. The proof is similar to that of Theorem 1.3.8 in [Gra14b], but here we work directly with the seminorms and avoid the technique of quotienting by polynomials.

<span id="page-23-2"></span>**Theorem 3.12** (Littlewood-Paley characterization of the Riesz potential spaces). Let  $1 and <math>s \in \mathbb{R}$ . Define the extended seminorm  $[\cdot]_{\dot{H}^{s,p}}^{\sim} : \mathscr{S}^*(\mathbb{R}^n; \mathbb{K}) \to [0, \infty]$  via

$$[f]_{\dot{H}^{s,p}}^{\sim} = \left\| \left( \sum_{j \in \mathbb{Z}} \left( 2^{sj} | \pi_j f | \right)^2 \right)^{1/2} \right\|_{L^p}. \tag{3.11}$$

Then there exists  $c \in \mathbb{R}^+$ , depending on s, n, p, such that following hold:

- (1) If  $f \in \dot{H}^{s,p}(\mathbb{R}^n; \mathbb{K})$ , then  $[f]_{\dot{H}^{s,p}}^{\sim} \leqslant c [f]_{\dot{H}^{s,p}}$ .
- (2) If  $f \in \mathscr{S}^*(\mathbb{R}^n; \mathbb{K})$  satisfies  $[f]_{\dot{H}^{s,p}}^{\sim} < \infty$ , then  $f \in \dot{H}^{s,p}(\mathbb{R}^n; \mathbb{K})$  and  $\frac{1}{c}[f]_{\dot{H}^{s,p}} \leqslant [f]_{\dot{H}^{s,p}}^{\sim}$

Proof. Suppose first that  $f \in \dot{H}^{s,p}(\mathbb{R}^n;\mathbb{K})$ . By hypothesis, there exists  $f_s \in L^p(\mathbb{R}^n;\mathbb{K})$  such that  $\sum_{j=-m}^m \Lambda^s \pi_j f \to f_s$  as  $m \to \infty$  in  $L^p(\mathbb{R}^n;\mathbb{K})$ . Consider  $\phi \in C_c^{\infty}(\mathbb{R}^n;\mathbb{R}) \subset \mathscr{S}(\mathbb{R}^n;\mathbb{C})$  defined via  $\phi(\xi) = |\xi|^{-s} \psi(\xi)$  (recall that  $\psi$  is the special function from Lemma 3.1). Observe this function is radial and that for  $j \in \mathbb{Z}$  it holds that

$$2^{sj}\pi_{j}f = 2^{sj} \left( \delta_{2^{j}} \left[ \left( |\cdot|^{-s} \psi |\cdot|^{s} \right) \right] \hat{f} \right)^{\vee} = 2^{sj} \left( \delta_{2^{j}} \left[ \left( |\cdot|^{-s} \psi |\cdot|^{s} \right) \right] \left( \sum_{\ell=-1}^{1} \delta_{2^{j+\ell}} \psi \right) \hat{f} \right)^{\vee}$$

$$= \left( \delta_{2^{j}} \phi |\cdot|^{s} \left( \sum_{\ell=-1}^{1} \delta_{2^{j+\ell}} \psi \right) \hat{f} \right)^{\vee} = \pi_{j}^{\phi} \Lambda^{s} \left( \sum_{\ell=-1}^{1} \pi_{j+\ell} \right) f = \pi_{j}^{\phi} f_{s}. \quad (3.12)$$

Hence by item (2) from Theorem 3.5 we obtain the bound

<span id="page-23-1"></span>
$$[f]_{\dot{H}^{s,p}}^{\sim} = \left\| \left( \sum_{j \in \mathbb{Z}} \left| \pi_j^{\phi} f_s \right|^2 \right)^{1/2} \right\|_{L^p} \lesssim \|f_s\|_{L^p} = [f]_{\dot{H}^{s,p}}. \tag{3.13}$$

On the other hand, suppose that  $f \in \mathscr{S}^*(\mathbb{R}^n; \mathbb{K})$  satisfies  $[f]_{\dot{H}^{s,p}}^{\sim} < \infty$ . We again use Theorem 3.5 to show that the sequence  $\{\sum_{j=-m}^m \Lambda^s \pi_j f\}_{j\in\mathbb{N}}$  is  $L^p(\mathbb{R}^n; \mathbb{K})$ -Cauchy. To begin, we claim that the sequence is actually contained within  $L^p(\mathbb{R}^n; \mathbb{K})$ . Indeed, the bound  $[f]_{\dot{H}^{s,p}}^{\sim} < \infty$  implies that  $\pi_j f \in L^p(\mathbb{R}^n; \mathbb{K})$  for all  $j \in \mathbb{Z}$ . Then the annular frequency support of  $\pi_j f$  implies that the multiplier defining  $\Lambda^s$  can be taken to be smooth and compactly supported, and thus satisfying the hypotheses of Theorem B.6. The theorem then guarantees that  $\Lambda^s \pi_j f \in L^p(\mathbb{R}^n; \mathbb{C})$ . To complete the proof of the claim note that this sequence is

 $\mathbb{K}$ -valued by the results in Appendix B.2. Let  $m, k \in \mathbb{N}$  with m < k. Using Lemma 3.4 shows that for  $j \in \mathbb{Z}$  we have

$$\pi_{j} \left( \sum_{\ell=-k}^{k} \Lambda^{s} \pi_{\ell} f - \sum_{\ell=-m}^{m} \Lambda^{s} \pi_{\ell} f \right) = \begin{cases} \Lambda^{s} \pi_{j} f & m+1 < |j| \leqslant k-1 \\ 0 & |j| \geqslant k+2, \ |j| < m \\ \pi_{k+1} \Lambda^{s} \pi_{k} f & j=k+1 \\ \pi_{-k-1} \Lambda^{s} \pi_{-k} f & j=-k-1 \\ \pi_{m} \Lambda^{s} \pi_{m+1} f & j=m \\ (\pi_{m} \Lambda^{s} \pi_{m+1} f & j=-m \\ (\pi_{k-1} + \pi_{k}) \Lambda^{s} \pi_{k} f & j=k \\ (\pi_{-k+1} + \pi_{-k}) \Lambda^{s} \pi_{-k} f & j=-k \\ (\pi_{m+1} + \pi_{m+2}) \Lambda^{s} \pi_{m+1} f & j=m+1 \\ (\pi_{-m-1} + \pi_{-m-2}) \Lambda^{s} \pi_{-m-1} f & j=-m-1. \end{cases}$$

$$(3.14)$$

Hence, by item (1) from Theorem 3.5 (due to  $L^p$  inclusion, there does not appear a polynomial) we may bound

$$\begin{split} \left\| \sum_{\ell=-k}^{k} \Lambda^{s} \pi_{\ell} f - \sum_{\ell=-m}^{m} \Lambda^{s} \pi_{\ell} f \right\|_{L^{p}} &\lesssim \left\| \left( \sum_{m+1 < |j| \leqslant k-1} |\Lambda^{s} \pi_{j} f|^{2} \right)^{1/2} \right\|_{L^{p}} + \left\| \pi_{k+1} \Lambda^{s} \pi_{k} f \right\|_{L^{p}} \\ &+ \left\| \pi_{-k-1} \Lambda^{s} \pi_{-k} f \right\|_{L^{p}} + \left\| \pi_{m} \Lambda^{s} \pi_{m+1} f \right\|_{L^{p}} + \left\| \pi_{-m} \Lambda^{s} \pi_{-m-1} \right\|_{L^{p}} + \left\| \left( \pi_{k-1} + \pi_{k} \right) \Lambda^{s} \pi_{k} f \right\|_{L^{p}} \\ &+ \left\| \left( \pi_{-k+1} + \pi_{-k} \right) \Lambda^{s} \pi_{-k} f \right\|_{L^{p}} + \left\| \left( \pi_{m+1} + \pi_{m+2} \right) \Lambda^{s} \pi_{m+1} f \right\|_{L^{p}} + \left\| \left( \pi_{-m-1} + \pi_{-m-2} \right) \Lambda^{s} \pi_{-m-1} f \right\|_{L^{p}}. \end{split}$$

$$(3.15)$$

By Theorem B.6 applied to  $\psi$  and then Lemma B.5, there is a constant  $c \in \mathbb{R}^+$ , depending only on  $\psi$ , n, and p, such that for all  $j \in \mathbb{Z}$  it holds that  $\|\delta_{2^j}\psi\|_{\mathscr{M}_p} = c$ . Therefore the bound (3.15) implies that

<span id="page-24-1"></span><span id="page-24-0"></span>
$$\left\| \sum_{\ell=-k}^{k} \Lambda^s \pi_{\ell} f - \sum_{\ell=-m}^{m} \Lambda^s \pi_{\ell} f \right\|_{L^p} \lesssim \left\| \left( \sum_{m < |j| \leqslant k} |\Lambda^s \pi_j f|^2 \right)^{1/2} \right\|_{L^p}. \tag{3.16}$$

Now let  $\nu \in C_c^{\infty}(\mathbb{R}^n;\mathbb{R}) \subset \mathscr{S}(\mathbb{R}^n;\mathbb{C})$  be the radial function defined via  $\nu(\xi) = |\xi|^s \psi(\xi)$ ; the properties of  $\psi$  guarantee that  $\int_{\mathbb{R}^n} \nu = 0$ . Arguing as in (3.12) shows that  $\Lambda^s \pi_j f = 2^{sj} \pi_j^{\nu} f$ ; moreover, Lemma 3.4 implies that  $\pi_j^{\nu} = \pi_j^{\nu} \sum_{\ell=-1}^{1} \pi_{j+\ell}$  for each  $j \in \mathbb{Z}$ . Hence, (3.16) paired with item (2) of Theorem 3.5 yield the bounds

$$\begin{split} \left\| \sum_{\ell=-k}^{k} \Lambda^{s} \pi_{\ell} f - \sum_{\ell=-m}^{m} \Lambda^{s} \pi_{\ell} f \right\|_{L^{p}} &\lesssim \left\| \left( \sum_{m < |j| \leqslant k} \left( 2^{sj} \left| \pi_{j}^{\nu} f \right| \right)^{2} \right) \right\|_{L^{p}}^{1/2} \\ &\leqslant \sum_{\ell=-1}^{1} \left\| \left( \sum_{m < |j| \leqslant k} \left( 2^{sj} \left| \pi_{j}^{\nu} \pi_{j+\ell} f \right| \right)^{2} \right)^{1/2} \right\|_{L^{p}} = \sum_{\ell=-1}^{1} 2^{-s\ell} \left\| \left( \sum_{m < |j| \leqslant k} \left| \pi_{j}^{\nu} \pi_{j+\ell} 2^{s(j+\ell)} f \right|^{2} \right)^{1/2} \right\|_{L^{p}} \\ &\leqslant \sum_{\ell=-1}^{1} 2^{-s\ell} \left\| \left( \sum_{m-1 < |r| \leqslant k+1} \sum_{m < |j| \leqslant k} \left| \pi_{j}^{\nu} \pi_{r} 2^{sr} f \right|^{2} \right)^{1/2} \right\|_{L^{p}} \lesssim \left\| \left( \sum_{m-1 < |r| \leqslant k+1} \left( 2^{sr} \left| \pi_{r} f \right| \right)^{2} \right)^{1/2} \right\|_{L^{p}}. \end{split}$$

$$(3.17)$$

Since  $[f]_{\dot{H}^{s,p}}^{\sim} < \infty$ , we can now show that as  $m \to \infty$  the final expression in (3.17) tends to zero. Indeed, for a.e.  $x \in \mathbb{R}^n$  the sum  $\sum_{r \in \mathbb{Z}} (2^{sr} |\pi_r f(x)|)^2$  is finite. For such x we have that

<span id="page-24-2"></span>
$$\left(\sum_{m-1 < |r| \leqslant k+1} (2^{sr} |\pi_r f(x)|)^2\right)^{1/2} \to 0 \text{ as } m < k \to \infty.$$
 (3.18)

The limit in  $L^p(\mathbb{R}^n; \mathbb{K})$  follows now from the dominated convergence theorem. We deduce then that the sequence  $\left\{\sum_{j=-m}^m \Lambda^s \pi_j f\right\}_{j\in\mathbb{N}}$  is Cauchy in  $L^p(\mathbb{R}^n; \mathbb{K})$ , and hence  $f \in \dot{H}^{s,p}(\mathbb{R}^n; \mathbb{K})$ . We can now argue exactly as above to deduce that for each  $m \in \mathbb{N}$  it holds that

$$\left\| \sum_{j=-m}^{m} \Lambda^{s} \pi_{j} f \right\|_{L_{p}} \lesssim_{s,n,p,\psi} \left\| \left( \sum_{j \in \mathbb{Z}} \left( 2^{sj} | \pi_{j} f | \right)^{2} \right)^{1/2} \right\|_{L_{p}}. \tag{3.19}$$

Using the Littlewood-Paley characterization of the Riesz potential spaces, we are now able to see that the spaces  $\dot{H}^{1,p}$  and  $\dot{W}^{1,p}$  essentially coincide. The proof of the following result is technical refinement of Theorem 6.3.1 in [BL76] in the sense that we do not require the Fourier transform of f to vanish near the origin.

<span id="page-25-0"></span>**Theorem 3.13** (Frequency space characterization of  $\dot{W}^{1,p}$ ). Let  $1 . There exists a constant <math>c \in \mathbb{R}^+$ , depending only on n, p, and  $\psi$ , such that the following hold:

- (1) If  $f \in \dot{W}^{1,p}(\mathbb{R}^n; \mathbb{K})$ , then  $c^{-1}[f]_{\dot{H}^{1,p}} \leq [f]_{\dot{W}^{1,p}}$
- (2) If  $f \in \dot{H}^{1,p}(\mathbb{R}^n;\mathbb{K})$ , then there exists a  $\mathbb{K}$ -valued polynomial Q with the property that f Q can be identified with an  $\dot{W}^{1,p}$ -function and  $[f Q]_{\dot{W}^{1,p}} \leq c[f]_{\dot{H}^{1,p}}$ . Moreover, the coefficients of terms of degree 1 and higher of Q are uniquely determined.

Proof. Suppose first that  $f \in \dot{H}^{1,p}(\mathbb{R}^n;\mathbb{K})$ . Let us first show that the sequence  $\left\{\sum_{j=-m}^m \pi_j f\right\}_{m\in\mathbb{N}}$  is Cauchy in  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$ . This sequence of tempered distributions is identified with a sequence of locally integrable functions since each member has compactly supported Fourier transform (see the Paley-Wiener-Schwartz theorem in, for instance, Chapter 6, Section 4 of [Yos95]). If  $k \in \{1,\ldots,n\}$  the mapping  $\mathbb{R}^n \ni \xi \mapsto i\xi_k \, |\xi|^{-1}$  (a scalar multiple of the usual Riesz transform) belongs to  $\mathscr{M}_p(\mathbb{R}^n;\mathbb{K})$  by Theorem B.6 and Lemma B.7; therefore, since  $\sum_{j=-m}^m \Lambda^1 \pi_j f \in L^p(\mathbb{R}^n;\mathbb{K})$  it then holds that

$$\left\| \sum_{j=-m}^{m} \partial_k \pi_j f \right\|_{L^p} \lesssim_{n,p} \left\| \sum_{j=-m}^{m} \Lambda^1 \pi_j f \right\|_{L^p} < \infty \text{ for } m \in \mathbb{N} \implies \left\{ \sum_{j=-m}^{m} \pi_j f \right\}_{m \in \mathbb{N}} \subset \dot{W}^{1,p} \left( \mathbb{R}^n; \mathbb{K} \right). \tag{3.20}$$

The above argument, supplemented with ideas from the latter half of the proof of Theorem 3.12, yields for  $m, k \in \mathbb{N}$  with m < k:

$$\sum_{\ell=1}^{n} \left\| \sum_{j=-k}^{k} \partial_{\ell} \pi_{j} f - \sum_{j=-m}^{m} \partial_{\ell} \pi_{j} f \right\|_{L^{p}} \lesssim_{n,p} \left\| \sum_{j=-k}^{k} \Lambda^{1} \pi_{j} f - \sum_{j=-m}^{m} \Lambda^{1} \pi_{j} f \right\|_{L^{p}} \\
\lesssim_{n,p,\psi} \left\| \left( \sum_{m-1<|r|\leqslant k+1} \left( 2^{sr} |\pi_{r} f| \right)^{2} \right)^{1/2} \right\|_{L^{p}}. \tag{3.21}$$

This estimate paired with Theorem 3.12 shows that the sequence in question is indeed Cauchy in the space  $\dot{W}^{1,p}$ . As this seminormed space is semi-Banach thanks to Lemma 3.9, we are assured of the existence of  $g \in \dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$  with the property that for each  $\ell \in \{1,\ldots,n\}$ 

$$\partial_{\ell} \sum_{j=-m}^{m} \pi_{j} f \to \partial_{\ell} g \text{ in } L^{p}(\mathbb{R}^{n}; \mathbb{K}) \text{ as } m \to \infty.$$
 (3.22)

Theorem B.6 assures us that for all  $j \in \mathbb{Z}$ ,  $\pi_j \in \mathcal{L}(L^p(\mathbb{R}^n;\mathbb{K});L^p(\mathbb{R}^n;\mathbb{K}))$ . This fact, paired with Lemma 3.4, shows that

$$\pi_j \partial_\ell g = \pi_j \partial_\ell f \text{ for all } j \in \mathbb{Z} \text{ and for all } \ell \in \{1, \dots, n\}.$$
 (3.23)

Hence Lemma 3.3 implies that  $\nabla f = \nabla g + P$  for a  $\mathbb{K}^n$ -valued polynomial P. By Poincaré's lemma there is  $\mathbb{K}$ -valued polynomial Q such that  $\nabla Q = P$ . We are free to adjust the constant term of Q so that f = g + Q. If  $\tilde{Q}$  were another polynomial with the property that  $f - \tilde{Q} \in \dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$ . Then  $\tilde{Q} - Q$  would also belong to the space  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$ . Hence  $\nabla(\tilde{Q} - Q)$  is necessarily zero.

We now estimate  $[f-Q]_{\dot{W}^{1,p}}$  using again the fact that  $\xi \mapsto i\xi_{\ell} |\xi|^{-1}$  belongs to  $\mathscr{M}_p(\mathbb{R}^n;\mathbb{K})$  for all  $\ell \in \{1,\ldots,n\}$ :

$$[f - Q]_{\dot{W}^{1,p}} \lesssim_n \lim_{m \to \infty} \left\| \sum_{j=-m}^m \nabla \pi_j f \right\|_{L^p} \lesssim_{n,p} \limsup_{m \to \infty} \left\| \sum_{j=-m}^m \Lambda^1 \pi_j f \right\|_{L^p}. \tag{3.24}$$

The proof of Theorem 3.12 shows that for each  $m \in \mathbb{N}$  we may bound

$$\left\| \sum_{j=-m}^{m} \Lambda^{1} \pi_{j} f \right\|_{L^{p}} \lesssim_{n,p,\psi} \left\| \left( \sum_{j \in \mathbb{Z}} \left( 2^{j} | \pi_{j} f | \right)^{2} \right)^{1/2} \right\|_{L^{p}}. \tag{3.25}$$

Thus, the proof of the second item is now complete.

On the other hand, suppose that  $f \in \dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$ . Let  $\rho \in C^{\infty}(\mathbb{R};\mathbb{R})$  be an even function that vanishes in the interval  $\left[-\frac{1}{2}n^{-1/2},\frac{1}{2}n^{-1/2}\right]$  and is identically 1 outside of  $\left(-n^{-1/2},n^{1/2}\right)$ . Consider the multipliers

 $\mathbf{m}_0, \mathbf{m}_1 : \mathbb{R}^n \to \mathbb{R}$  defined via

$$\mathbf{m}_{0}(\xi) = \rho(|\xi| n^{-1/2}) |\xi| \left( \sum_{\ell=1}^{n} \rho(\xi_{\ell}) |\xi_{\ell}| \right)^{-1} \text{ and } \mathbf{m}_{1}(\xi) = \sum_{\ell=1}^{n} \rho(\xi_{\ell}) |\xi_{\ell}|.$$
 (3.26)

Observe that  $\mathbf{m}_0$  is smooth, vanishes in  $B(0,1/2) \subset \mathbb{R}^n$ , and agrees with  $\xi \mapsto |\xi| \left(\sum_{\ell=1}^n \rho(\xi_\ell) |\xi_\ell|\right)^{-1}$  for  $|\xi| \geqslant 1$ . One can verify that  $\mathbf{m}_0 \in \mathscr{M}_p(\mathbb{R}^n; \mathbb{K})$ . Now if  $m \in \mathbb{N}$ , then  $B(0, \kappa_m) \subset \mathbb{R}^n \setminus \operatorname{supp} \mathscr{F}\left(\sum_{j=-m}^m \pi_j f\right)$ where  $\kappa_m = 2^{-m-2}$ . This tells us that

<span id="page-26-3"></span>
$$\Lambda^{1} \sum_{j=-m}^{m} \pi_{j} f = \kappa_{m} \left( \delta_{\kappa_{m}} \mathbf{m}_{0} \delta_{\kappa_{m}} \mathbf{m}_{1} \right)^{\vee} * \sum_{j=-m}^{m} \pi_{j} f.$$

$$(3.27)$$

In turn, by Lemma B.5 we can bound

<span id="page-26-1"></span>
$$\left\| \Lambda^{1} \sum_{j=-m}^{m} \pi_{j} f \right\|_{L^{p}} \leqslant \kappa_{m} \left\| \delta_{\kappa_{m}} \mathbf{m}_{0} \right\|_{\mathscr{M}_{p}} \left\| \delta_{\kappa_{m}} \mathbf{m}_{1} \sum_{j=-m}^{m} \pi_{j} f \right\|_{L^{p}} = \kappa_{m} \left\| \mathbf{m}_{0} \right\|_{\mathscr{M}_{p}} \left\| \left( \delta_{\kappa_{m}} \mathbf{m}_{1} \right)^{\vee} * \sum_{j=-m}^{m} \pi_{j} f \right\|_{L^{p}}.$$

$$(3.28)$$

Finally, the fact that for each  $\ell \in \{1, \dots, n\}$  the map (and its dilates)  $\xi \mapsto i \frac{|\xi_{\ell}|}{\xi_{\ell}} \rho(\xi_{\ell})$  belong to  $\mathscr{M}_{p}(\mathbb{R}^{n}; \mathbb{K})$ yields the bound

<span id="page-26-2"></span>
$$\left\| \left( \delta_{\kappa_m} \mathbf{m}_1 \right)^{\vee} * \sum_{j=-m}^{m} \pi_j f \right\|_{L^p} \lesssim_{n,p} \kappa_m^{-1} \sum_{\ell=1}^{n} \left\| \partial_{\ell} \sum_{j=-m}^{m} \pi_j f \right\|_{L^p} = \kappa_m^{-1} \sum_{\ell=1}^{n} \left\| \sum_{j=-m}^{m} \pi_j \partial_{\ell} f \right\|_{L^p}.$$
 (3.29)

Since  $\pi_j \in \mathcal{L}(L^p(\mathbb{R}^n;\mathbb{K});L^p(\mathbb{R}^n;\mathbb{K}))$  for each  $j \in \mathbb{Z}$ , the estimates (3.28) and (3.29) imply the inclusion

 $\left\{\sum_{j=-m}^{m} \Lambda^{1} \pi_{j} f\right\}_{m \in \mathbb{N}} \subset L^{p}(\mathbb{R}^{n}; \mathbb{K}).$  To see that this sequence is also Cauchy, we apply the argument in (3.27), (3.28), and (3.29) to the function  $\sum_{j=-k}^k \Lambda^1 \pi_j f - \sum_{j=-m}^m \Lambda^1 \pi_j f$  for  $k > m, m, k \in \mathbb{N}$ . This shows that

<span id="page-26-4"></span>
$$\left\| \sum_{j=-k}^{k} \Lambda^1 \pi_j f - \sum_{j=-m}^{m} \Lambda^1 \pi_j f \right\|_{L^p} \lesssim_{n,p} \sum_{\ell=1}^{n} \left\| \sum_{m<|j|\leqslant k} \pi_j \partial_\ell f \right\|_{L^p}. \tag{3.30}$$

The term above on the right can be universally estimated using item (1) of Theorem 3.5 (due to  $L^p$  inclusion, there does not appear a polynomial) and Theorem B.6:

<span id="page-26-5"></span>
$$\sum_{\ell=1}^{n} \left\| \sum_{m < |j| \leqslant k} \pi_{j} \partial_{\ell} f \right\|_{L^{p}} \lesssim_{n,p,\psi} \sum_{\ell=1}^{n} \left\| \left( \sum_{m < |j| \leqslant k} |\pi_{j} \partial_{\ell} f|^{2} \right)^{1/2} \right\|_{L^{p}}. \tag{3.31}$$

As a consequence of item (1) in Theorem 3.5, we have the equivalence for each  $\ell \in \{1, \ldots, n\}$ :

$$\left\| \left( \sum_{j \in \mathbb{Z}} |\pi_j \partial_\ell f|^2 \right)^{1/2} \right\|_{L^p} \asymp_{n,p,\psi} \left\| \partial_\ell f \right\|_{L^p} < \infty. \tag{3.32}$$

Therefore equations (3.30) and (3.31) show the sequence  $\left\{\sum_{j=-m}^{m} \Lambda^{1} \pi_{j} f\right\}_{m \in \mathbb{N}}$  to be  $L^{p}(\mathbb{R}^{n}; \mathbb{K})$ -Cauchy. Finally, (3.28), (3.29), and Theorem 3.5 imply that

$$\lim_{m \to \infty} \left\| \sum_{j=-m}^{m} \Lambda^{1} \pi_{j} f \right\|_{L^{p}} \lesssim_{n,p,\psi} \lim_{m \to \infty} \sum_{\ell=1}^{n} \left\| \left( \sum_{j=-m}^{m} |\pi_{j} \partial_{\ell} f|^{2} \right)^{1/2} \right\|_{L^{p}} \asymp_{n,p,\psi} \sum_{\ell=1}^{n} \|\partial_{\ell} f\|_{L^{p}}. \tag{3.33}$$

The generalizations of Theorem 3.13 for the pairs of spaces  $\dot{H}^{m,p}(\mathbb{R}^n;\mathbb{K})$  and  $\dot{W}^{m,p}(\mathbb{R}^n;\mathbb{K})$  hold for  $m \in \mathbb{N} \setminus \{0,1\}$  and 1 and are proven in essentially the same way as above.

<span id="page-26-6"></span>3.3. Homogeneous Besov spaces. We now turn our attention to the scale of homogeneous Besov spaces.

**Definition 3.14** (Translations, difference quotients, moduli of continuity). Let  $1 \le p \le \infty$ .

- (1) For  $h \in \mathbb{R}^n$  we define the h-translation operator,  $\tau_h$ , and the h-forward difference operator,  $\Delta_h$ , as follows. Given  $f: \mathbb{R}^n \to \mathbb{K}$ , we let  $\tau_h f, \Delta_h f: \mathbb{R}^n \to \mathbb{K}$  be given by  $\tau_h f(x) = f(x-h)$  and  $\Delta_h f(x) = (\tau_{-h} - 1) f(x).$
- <span id="page-26-0"></span>(2) We define the  $L^p$ -modulus of continuity as the functional  $\omega_p: \mathbb{R}^+ \times L^1_{loc}(\mathbb{R}^n; \mathbb{K}) \to [0, \infty]$  with action  $\omega_p(t, f) = \sup \{ \|\Delta_h f\|_{L^p} : h \in \overline{B(0, t)} \subset \mathbb{R}^n \}.$

**Definition 3.15** (Homogeneous Besov spaces). Let  $s \in (0,1)$  and  $1 \leq p,q \leq \infty$ . We define the homogeneous Besov space  $\dot{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K}) = \{f \in L^1_{\text{loc}}(\mathbb{R}^n;\mathbb{K}) : [f]_{\dot{B}_q^{s,p}} < \infty\}$ , where  $[\cdot]_{\dot{B}_q^{s,p}} : L^1_{\text{loc}}(\mathbb{R}^n;\mathbb{K}) \to [0,\infty]$  is defined by

$$[f]_{\dot{B}_{q}^{s,p}} = \begin{cases} \left( \int_{\mathbb{R}^{+}} \left( t^{-s} \omega_{p} \left( t, f \right) \right)^{q} t^{-1} dt \right)^{1/q} & 1 \leqslant q < \infty \\ \sup \left\{ t^{-s} \omega_{p} \left( t, f \right) : t \in \mathbb{R}^{+} \right\} & q = \infty. \end{cases}$$
(3.34)

<span id="page-27-3"></span>The following equivalent seminorm is occasionally useful.

**Definition 3.16.** Let  $n \in \mathbb{N}^+$ ,  $s \in (0,1)$ ,  $1 \leqslant p,q \leqslant \infty$ . We define  $[\cdot]_{\dot{B}_{a}^{s,p}}^{\sim} : L_{\text{loc}}^{1}(\mathbb{R}^n;\mathbb{K}) \to [0,\infty]$  via

$$[f]_{\dot{B}_{q}^{s,p}}^{\sim} = \begin{cases} \left( \int_{\mathbb{R}^{n}} \left( |h|^{-s} \|\Delta_{h} f\|_{L^{p}} \right)^{q} |h|^{-n} dh \right)^{1/q} & 1 \leqslant q < \infty \\ \operatorname{esssup} \left\{ |h|^{-s} \|\Delta_{h} f\|_{L^{p}} : h \in \mathbb{R}^{n} \right\} & q = \infty \end{cases}$$
(3.35)

Proposition 17.21 in [Leo17] shows that  $[\cdot]_{\dot{B}_{a}^{s,p}}^{\sim}$  is equivalent to  $[\cdot]_{\dot{B}_{a}^{s,p}}$ .

The proof of the following lemma is a slightly modified excerpt from the proof of Theorem 17.24 in [Leo17]. We include it to emphasize the connection between the K-functional on the sum of  $L^p$  and  $\dot{W}^{1,p}$  and the  $L^p$  modulus of continuity on  $L^1_{\rm loc}$ .

<span id="page-27-0"></span>**Lemma 3.17** (Relation between K-functional and moduli of continuity). Fix  $1 \leq p \leq \infty$ . Let  $\mathcal{K}$  denote the K-functional, from Definition 2.5, corresponding to the space  $L^p(\mathbb{R}^n;\mathbb{K})$  and  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$ . Then for all  $(t,u) \in \mathbb{R}^+ \times L^1_{loc}(\mathbb{R}^n;\mathbb{K})$  we have the equivalence:

<span id="page-27-1"></span>
$$2^{-1}\omega_p(t,u) \leqslant \mathcal{K}(t,u) \leqslant (1+n^{3/2})\omega_p(t,u). \tag{3.36}$$

Proof. First, we prove the left inequality in (3.36). We may reduce to proving this under the extra assumption that  $u \in \Sigma(L^p(\mathbb{R}^n;\mathbb{K});\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}))$  since otherwise the right-hand-side is infinite, and there is nothing to prove. Assume this and let  $t \in \mathbb{R}^+$ . Suppose that  $(v,w) \in L^p(\mathbb{R}^n;\mathbb{K}) \times \dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$  are a decomposition of u, that is: u = v + w. For any  $h \in \overline{B(0,t)}$  the estimate  $\|\Delta_h v\|_{L^p} \leqslant 2 \|v\|_{L^p}$  is clear by the triangle inequality and invariance of the  $L^p$ -norm under translations. On the other hand, we have that  $\|\Delta_h w\|_{L^p} \leqslant |h| [w]_{\dot{W}^{1,p}}$ . In the case that  $1 \leqslant p < \infty$  we let  $\{\varphi_{\varepsilon}\}_{\varepsilon \in (0,1)} \subset C_c^{\infty}(B(0,1))$  be a standard mollifier. Then for  $\varepsilon \in (0,1)$  we can use the fundamental theorem of calculus and Minkowski's integral inequality to bound:

$$\left(\int_{\mathbb{R}^n} |w * \varphi_{\varepsilon}(x+h) - w * \varphi_{\varepsilon}(x)|^p \, dx\right)^{1/p} = \left(\int_{\mathbb{R}^n} \left| \int_{(0,1)} \nabla (w * \varphi_{\varepsilon}) (x+\sigma h) \cdot h \, d\sigma \right|^p \, dx\right)^{1/p} \\
\leqslant |h| \int_{(0,1)} \left( \int_{\mathbb{R}^n} |\nabla (w * \varphi_{\varepsilon}) (x+\sigma h)|^p \, dx \right)^{1/p} \, d\sigma = |h| [w * \varphi_{\varepsilon}]_{\dot{W}^{1,p}} \leqslant |h| [w]_{\dot{W}^{1,p}}.$$
(3.37)

Letting  $\varepsilon \to 0^+$  and using Fatou's lemma gives the claim. On the other hand if  $p=\infty$  we repeat the same argument and use lower semicontinuity of weak-\* convergence in  $L^\infty = (L^1)^*$  of the mollified functions in place of Fatou's lemma. Note that since the sequence of mollified functions converge pointwise a.e. the argument also shows  $\dot{W}^{1,\infty}(\mathbb{R}^n;\mathbb{K}) \hookrightarrow \dot{C}^{0,1}(\mathbb{R}^n;\mathbb{K})$ .

Now we take the supremum over  $h \in \overline{B(0,t)}$ :  $\|\Delta_h u\|_{L^p} \leq 2(\|v\|_{L^p} + t[w]_{\dot{W}^{1,p}}) \Rightarrow \omega_p(t,u) \leq 2(\|v\|_{L^p} + t\|\nabla w\|_{L^p})$ . We then take the infimum over all such decompositions of u to see that  $\omega_p(t,u) \leq 2\mathcal{K}(t,u)$ .

Next, we prove the first inequality in (3.36) in the case that  $1 \leq p < \infty$ . Suppose that  $t \in \mathbb{R}^+$ , and  $u \in L^1_{loc}(\mathbb{R}^n;\mathbb{K})$  is such that  $\omega_p(t,u) < \infty$  (if this is infinite, then there is, again, nothing to prove). Let  $Q(0, n^{-\frac{1}{2}}t)$  denote the cube centered at the origin with sides of length  $n^{-\frac{1}{2}}t$  which are parallel to the coordinate axes. Consider  $v, w : \mathbb{R}^n \to \mathbb{K}$  given by

<span id="page-27-2"></span>
$$v(x) = -\frac{n^{\frac{n}{2}}}{t^n} \int_{Q(0, n^{-\frac{1}{2}}t)} \Delta_y u(x) \, dy \text{ and } w(x) = \frac{n^{\frac{n}{2}}}{t^n} \int_{Q(0, n^{-\frac{1}{2}}t)} \tau_{-y} u(x) \, dy.$$
 (3.38)

By construction we have that u = v + w. We estimate v with the Minkowski integral inequality:

<span id="page-28-1"></span>
$$\|v\|_{L^{p}} = \left(\int_{\mathbb{R}^{n}} \left| \frac{n^{\frac{n}{2}}}{t^{n}} \int_{Q(0, n^{-\frac{1}{2}}t)} \Delta_{y} u(x) \, dy \right|^{p} dx \right)^{\frac{1}{p}} \leqslant \frac{n^{\frac{n}{2}}}{t^{n}} \int_{Q(0, n^{-\frac{1}{2}}t)} \|\Delta_{y} u\|_{L^{p}} \, dy \leqslant \omega_{p}(t, u), \qquad (3.39)$$

where in the last inequality we used that  $Q(0, n^{-\frac{1}{2}}t) \subseteq \overline{B(0,t)}$ . Next we estimate w in  $\dot{W}^{1,p}(\mathbb{R}^n; \mathbb{K})$  (see also Lemma B.1). Let  $j \in \{1, \ldots, n\}$ . For  $z \in \mathbb{R}^n$  we adopt the following notation: the canonical basis of  $\mathbb{R}^n$  is the set  $\{e_1, \ldots, e_n\}$  and  $z = \left(z'_j, z_j\right), z_j \in \mathbb{R}, z'_j \in \mathbb{R}^{n-1}$ , and  $z'_j = (z_1, \ldots, z_{j-1}, z_{j+1}, \ldots, z_n)$ . By a change of coordinates we have that

$$\int_{\left(-\frac{1}{2}n^{-\frac{1}{2}}t,\frac{1}{2}n^{-\frac{1}{2}}t\right)} u\left(x_j' + y_j', x_j + y_j\right) dy_j = \int_{\left(-\frac{1}{2}n^{-\frac{1}{2}}t + x_j, \frac{1}{2}n^{-\frac{1}{2}}t + x_j\right)} u\left(x_j' + y_j', \tau\right) d\tau.$$
(3.40)

Then for a.e.  $x \in \mathbb{R}^n$  we have that

$$\partial_{j} \int_{\left(-n^{-\frac{1}{2}}t, n^{-\frac{1}{2}}t\right)} u\left(x'_{j} + y'_{j}, x_{j} + y_{j}\right) dy_{j} = \Delta_{n^{-\frac{1}{2}}te_{j}} u\left(x'_{j} + y'_{j}, x_{j} - n^{-\frac{1}{2}}t/2\right). \tag{3.41}$$

Thus, upon differentiating under the integral and applying Fubini's theorem, we find that for a.e.  $x \in \mathbb{R}^n$ 

$$\partial_{j}w\left(x\right) = \frac{n^{\frac{n}{2}}}{t^{n}} \int_{\tilde{Q}\left(0, n^{-\frac{1}{2}t}\right)} \Delta_{n^{-\frac{1}{2}te_{j}}} u\left(x'_{j} + y'_{j}, x_{j} - \frac{1}{2}n^{-\frac{1}{2}t}\right) dy'_{j}. \tag{3.42}$$

Where  $\tilde{Q}(0, n^{-\frac{1}{2}}t) \subset \mathbb{R}^{n-1}$  is the cube centered at zero with sides parallel to the coordinate axes of length  $n^{-\frac{1}{2}}t$ . Again Minkowski's integral inequality and the fact that  $\omega_p(\cdot, u)$  is increasing show that

<span id="page-28-2"></span>
$$\|\partial_{j}w\|_{L^{p}} \leqslant \frac{n^{\frac{n}{2}}}{t^{n}} \int_{\tilde{Q}\left(0, n^{-\frac{1}{2}}t\right)} \left\|\Delta_{n^{-\frac{1}{2}}te_{j}}u\left(\cdot_{j}' + y_{j}', \cdot_{j} - \frac{1}{2}n^{-\frac{1}{2}}t\right)\right\|_{L^{p}} dy_{j}' \leqslant n^{1/2}t^{-1}\omega_{p}\left(t, u\right). \tag{3.43}$$

Synthesizing (3.39) and (3.43), we deduce that

<span id="page-28-3"></span>
$$\mathcal{K}(t,u) \leqslant \|v\|_{L^p} + t \sum_{j=1}^n \|\partial_j w\|_{L^p} \leqslant (1 + n^{3/2})\omega_p(t,u). \tag{3.44}$$

With the first bound and the estimate (3.44) in hand, the proof is complete when  $p < \infty$ .

On the other hand, if  $p = \infty$  we again decompose u = v + w as in equation (3.38). In this case it is straightforward to see that  $||v||_{L^{\infty}} \leq \omega_{\infty}(t, u)$  and for all  $j \in \{1, \ldots, n\}$ ,  $||\partial_{j}w||_{L^{\infty}} \leq n^{1/2}t^{-1}\omega_{\infty}(t, u)$ .  $\square$ 

<span id="page-28-5"></span>From this equivalence we can characterize the homogeneous Besov spaces as seminorm interpolation spaces.

**Corollary 3.18** (Interpolation characterization of homogeneous Besov spaces). For all  $s \in (0,1)$  and  $1 \le p, q \le \infty$  we have the equality of seminormed spaces with equivalence of seminorms:

<span id="page-28-4"></span>
$$(L^p(\mathbb{R}^n; \mathbb{K}); \dot{W}^{1,p}(\mathbb{R}^n; \mathbb{K}))_{s,q} = \dot{B}_q^{s,p}(\mathbb{R}^n; \mathbb{K}). \tag{3.45}$$

Consequently, the following hold:  $\dot{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K})$  is semi-Banach and  $\mathfrak{A}(\dot{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K})) = \{constants\}; if <math>p,q < \infty$ , then  $C_{c}^{\infty}(\mathbb{R}^{n};\mathbb{K})$  is dense in  $\dot{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K})$ , we have the inclusion  $\dot{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K}) \subset \mathscr{S}^{*}(\mathbb{R}^{n};\mathbb{K})$ , and finally the reiteration formulae

$$(L^{p}(\mathbb{R}^{n};\mathbb{K}),\dot{B}_{r}^{t,p}(\mathbb{R}^{n};\mathbb{K}))_{s,q} = \dot{B}_{q}^{u_{0},p}(\mathbb{R}^{n};\mathbb{K}) \text{ and } (\dot{B}_{r}^{t,p}(\mathbb{R}^{n};\mathbb{K}),\dot{W}^{1,p}(\mathbb{R}^{n};\mathbb{K}))_{s,q} = \dot{B}_{q}^{u_{1},p}(\mathbb{R}^{n};\mathbb{K})$$
(3.46)

and

$$(\dot{B}_{r_0}^{t_0,p}(\mathbb{R}^n;\mathbb{K}),\dot{B}_{r_1}^{t_1,p}(\mathbb{R}^n;\mathbb{K}))_{s,q} = \dot{B}_{q}^{u_2,p}(\mathbb{R}^n;\mathbb{K})$$
(3.47)

hold for 
$$0 < t, t_0, t_1 < 1, \ 1 \leqslant r, r_0, r_1 \leqslant \infty, \ u_0 = (1 - s)t, \ u_1 = (1 - s)t + s, \ and \ u_2 = (1 - s)t_0 + st_1.$$

*Proof.* Equation 3.45 is an immediate consequence of Lemma 3.17 and the definition of the seminorm on  $\dot{B}_q^{s,p}$ . The several consequences follow from the results on interpolation of seminormed spaces from Section 2.

<span id="page-28-0"></span>We now explore frequency space characterizations of the homogeneous Besov spaces.

**Definition 3.19** (Homogeneous Besov-Lipschitz spaces). Let  $s \in \mathbb{R}$ ,  $1 , and <math>1 \le q \le \infty$ . Then we define the space  $\wedge \dot{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K}) = \{f \in \mathscr{S}^*(\mathbb{R}^n;\mathbb{K}) : [f]_{\wedge \dot{B}_q^{s,p}} < \infty\}$ , where  $[\cdot]_{\wedge \dot{B}_q^{s,p}} : \mathscr{S}^*(\mathbb{R}^n;\mathbb{C}) \to [0,\infty]$  is given by

$$[f]_{\wedge \dot{B}_{q}^{s,p}} = \left\| \left\{ 2^{sj} \left\| \pi_{j} f \right\|_{L^{p}} \right\}_{j \in \mathbb{Z}} \right\|_{\ell^{q}(\mathbb{Z})}. \tag{3.48}$$

The following theorem shows that the theory of seminormed space interpolation applied to pairs of Riesz potential spaces yields the homogeneous Besov-Lipschitz spaces. We note that the following result appears as Theorem 6.3.1 in [BL76], where the proof is abbreviated.

<span id="page-29-1"></span>**Theorem 3.20.** Let  $1 and <math>s_0, s_1 \in \mathbb{R}$  with  $s_0 < s_1$ . Then for  $\alpha \in (0,1)$  and  $1 \leqslant q \leqslant \infty$  we have the equality of seminormed spaces with equivalence of seminorms:

$$(\dot{H}^{s_0,p}(\mathbb{R}^n;\mathbb{K}),\dot{H}^{s_1,p}(\mathbb{R}^n;\mathbb{K}))_{\alpha,q} = {}_{\wedge}\dot{B}_{a}^{s,p}(\mathbb{R}^n;\mathbb{K}), \text{ where } s = (1-\alpha)s_0 + \alpha s_1. \tag{3.49}$$

*Proof.* The pair of seminormed spaces  $\dot{H}^{s_0,p}(\mathbb{R}^n;\mathbb{K})$  and  $\dot{H}^{s_1,p}(\mathbb{R}^n;\mathbb{K})$  are weakly compatible as witnessed by the space of tempered distributions. Suppose that  $f \in (\dot{H}^{s_0,p}(\mathbb{R}^n;\mathbb{K}),\dot{H}^{s_1,p}(\mathbb{R}^n;\mathbb{K}))_{\alpha,q}$ . Let  $f = f_0 + f_1$  be a decomposition with  $f_\ell \in \dot{H}^{s_\ell,p}(\mathbb{R}^n;\mathbb{K})$  for  $\ell \in \{0,1\}$ . We first claim that we have the universal bound

$$\|\pi_j f_\ell\|_{L^p} \lesssim_{n,p,\psi} 2^{-s_\ell j} [f_\ell]_{\dot{H}^{s_\ell,p}}, \text{ for } j \in \mathbb{Z} \text{ and } \ell \in \{0,1\}.$$
 (3.50)

This follows from the Littlewood-Paley characterization of the Riesz potential spaces from Theorem 3.12. Thus,

$$\|\pi_{j}f\|_{L^{p}} \lesssim_{n,p,\psi} \sum_{\ell=0}^{1} 2^{-s_{\ell}j} [f_{\ell}]_{\dot{H}^{s_{\ell},p}} \Rightarrow 2^{sj} \|\pi_{j}f\|_{L^{p}} \lesssim_{n,p,\psi} 2^{\alpha(s_{1}-s_{0})j} \mathscr{K}\left(2^{-(s_{1}-s_{0})j},f\right). \tag{3.51}$$

Therefore by Proposition 2.6 and Proposition 2.13,

$$[f]_{\wedge \dot{B}_{q}^{s,p}} \lesssim_{n,p,\psi} \| \{ 2^{\alpha(s_{1}-s_{0})j} \mathcal{K} (2^{-(s_{1}-s_{0})j}, f) \}_{j \in \mathbb{Z}} \|_{\ell^{q}(\mathbb{Z})} \lesssim_{n,p,\psi,s_{0},s_{1}} [f]_{\alpha,q}.$$
 (3.52)

On the other hand, suppose that  $f \in {}_{\wedge}\dot{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K})$ . Then, we will see that for all  $j \in \mathbb{Z}$  it holds that  $\pi_{j}f \in \Delta(\dot{H}^{s_{0},p}(\mathbb{R}^{n};\mathbb{K}),\dot{H}^{s_{1},p}(\mathbb{R}^{n};\mathbb{K}))$ . In fact, we claim that the sequence  $\{\pi_{j}f\}_{j\in\mathbb{Z}}$  belongs to the discrete decomposition set of f,  $\tilde{\mathcal{D}}(f)$ . For  $j \in \mathbb{Z}$  and  $k \in \{0,1\}$  we estimate via Lemma 3.4 and Theorem 3.12:

$$\|\pi_{j}f\|_{\dot{H}^{s_{k},p}} \lesssim_{n,p,\psi} \sum_{\ell=-1}^{1} 2^{s_{k}(j+\ell)} \|\pi_{j+\ell}\pi_{j}f\|_{L^{p}} \lesssim_{n,p,\psi,s_{k}} 2^{s_{k}j} \|\pi_{j}f\|_{L^{p}}.$$

$$(3.53)$$

In turn, we have that

<span id="page-29-0"></span>
$$\mathscr{J}\left(2^{-j(s_1-s_0)}, \pi_j f\right) = \max\left\{ \|\pi_j f\|_{\dot{H}^{s_0,p}}, 2^{-j(s_1-s_0)} \|\pi_j f\|_{\dot{H}^{s_1,p}} \right\} \lesssim_{n,p,\psi,s_0,s_1} 2^{js_0} \|\pi_j f\|_{L^p}. \tag{3.54}$$

Then (3.54) and Proposition 2.18 imply that the following series converges absolutely:

$$\sum_{j \in \mathbb{Z}} \left[ \pi_{j} f \right]_{\Sigma} \leq \sum_{j \in \mathbb{Z}} \min \left\{ 1, 2^{j(s_{1} - s_{0})} \right\} \mathscr{J} \left( 2^{-j(s_{1} - s_{0})}, f \right) \\
\leq \sum_{n, p, \psi, s_{0}, s_{1}} \sum_{j \in \mathbb{Z}} \min \left\{ 2^{j(s_{0} - s)}, 2^{j(s_{1} - s)} \right\} 2^{sj} \left\| \pi_{j} f \right\|_{L^{p}} \\
\leq \left\| \left\{ \min \left\{ 2^{j(s_{0} - s)}, 2^{j(s_{1} - s)} \right\} \right\}_{j \in \mathbb{Z}} \right\|_{\ell^{q'}(\mathbb{N})} \left\| \left\{ 2^{sj} \left\| \pi_{j} f \right\|_{L^{p}} \right\}_{j \in \mathbb{Z}} \right\|_{\ell^{q}(\mathbb{N})}. \tag{3.55}$$

Next we show that  $\lim_{m\to\infty} \left[\sum_{j=-m}^m \pi_j f - f\right]_{\Sigma} = 0$ . We decompose  $f = f^- + f^+$  where  $f^+ = \sum_{j\in\mathbb{N}} \pi_j f$  (and  $f^- = f - f^+$ ) with the series converging in  $\mathscr{S}^*(\mathbb{R}^n;\mathbb{C})$  by virtue of Lemma 3.3. Both factors in this decomposition are  $\mathbb{K}$ -valued, thanks to Lemma B.3. Then for  $m \in \mathbb{N} \setminus \{0,1\}$  we have the bound

$$\left[\sum_{j=-m}^{m} \pi_{j} f - f\right]_{\Sigma} \leqslant \left[\sum_{j=-m}^{-1} \pi_{j} f - f^{-}\right]_{\dot{H}^{s_{1},p}} + \left[\sum_{j=0}^{m} \pi_{j} f - f^{+}\right]_{\dot{H}^{s_{0},p}} =: \mathbf{I}_{m} + \mathbf{I} \mathbf{I}_{m}. \tag{3.56}$$

We prove that  $\lim_{m\to\infty} \mathbf{I}_m = 0$ . The argument that  $\mathbf{II}_m \to 0$  as  $m \to \infty$  follows similarly. With the aide of Lemma 3.3 and Lemma 3.4, we compute the action of the family  $\{\pi_k\}_{k\in\mathbb{Z}}$  on the expression appearing in  $\mathbf{I}_m$ :

$$\pi_k \Big( \sum_{j=-m}^{-1} \pi_j f - f^- \Big) = \pi_k \Big( \sum_{j=-m}^{\infty} \pi_j f - f \Big) = \begin{cases} 0 & k > -m \\ -\pi_{-m} \pi_{-m-1} f & k = -m \\ -\left(\pi_{-m-2} + \pi_{-m-1}\right) \pi_{-m-1} f & k = -m - 1 \\ -\pi_k f & k < -m - 1 \end{cases}$$
(3.57)

Thus by Theorem 3.12, Theorem B.6, and Lemma B.5

<span id="page-30-0"></span>
$$\mathbf{I}_{m} \lesssim_{n,p,\psi} \left[ \sum_{j=-m}^{-1} \pi_{j} f - f^{-} \right]_{\dot{H}^{s_{1},p}}^{\sim} \leqslant 2^{-s_{1}m} \| \pi_{-m} \pi_{-m-1} f \|_{L^{p}} + 2^{-s_{1}(m+1)} \| (\pi_{-m-2} + \pi_{-m-1}) \pi_{-m-1} f \|_{L^{p}} + \left\| \left( \sum_{j=-\infty}^{-m-2} \left( 2^{s_{1}j} | \pi_{j} f | \right)^{2} \right)^{1/2} \right\|_{L^{p}} \lesssim_{n,p,\psi} \left\| \left( \sum_{j=-\infty}^{-m-1} \left( 2^{s_{1}j} | \pi_{j} f | \right)^{2} \right)^{1/2} \right\|_{L^{p}}. \tag{3.58}$$

To obtain good bounds on the last expression in (3.58) we break to cases on the size of p. Suppose first that  $1 . In this case the mapping <math>\mathbb{R}^+ \cup \{0\} \ni \eta \mapsto \eta^{\frac{p}{2}} \in \mathbb{R}^+ \cup \{0\}$  is subadditive. Therefore since  $s_0 < s < s_1$  we may use the inclusion  $\ell^q \hookrightarrow \ell^p$  for  $q \le p$  and Hölder's inequality otherwise to deduce that

<span id="page-30-1"></span>
$$\left\| \left( \sum_{j=-\infty}^{-m-1} \left( 2^{s_1 j} | \pi_j f | \right)^2 \right)^{1/2} \right\|_{L^p} \leqslant \left( \int_{\mathbb{R}^n} \sum_{j=-\infty}^{-m-1} \left( 2^{s_1 j} | \pi_j f | \right)^p \right)^{1/p} \\
\leqslant \begin{cases} 2^{(s_1-s)(m-1)} \left( \sum_{j=-\infty}^{-m-1} \left( 2^{s j} | | \pi_j f | |_{L^p} \right)^q \right)^{1/q} & q \leqslant p \\
\left\| \left\{ 2^{j(s_1-s)} \right\}_{j=-\infty}^{-m-1} \right\|_{\ell^r} \left\| \left\{ 2^{s j} | | \pi_j f | |_{L^p} \right\}_{j=-\infty}^{-m-1} \right\|_{\ell^q} & p < q, \ \frac{1}{p} = \frac{1}{q} + \frac{1}{r} \end{cases} < \infty. \tag{3.59}$$

The finiteness follows from the hypothesis that  $f \in {}_{\wedge}\dot{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K})$ . Notice also that the final expression in (3.59) tends to zero as  $m \to \infty$ . Thus  $\mathbf{I}_{m} \to 0$  as  $m \to \infty$  in the case 1 .

On the other hand, in the case that 2 , we bound via Minkowski's integral inequality:

$$\left\| \left( \sum_{j=-\infty}^{-m-1} \left( 2^{s_1 j} | \pi_j f | \right)^2 \right)^{1/2} \right\|_{L^p} \leq \left( \sum_{j=-\infty}^{-m-1} \left( 2^{s_1 j} \| \pi_j f \|_{L^p} \right)^2 \right)^{1/2} \\
\leq \sum_{j=-\infty}^{-m-1} 2^{s_1 j} \| \pi_j f \|_{L^p} \leq \left\| \left\{ 2^{s j} \| \pi_j f \|_{L^p} \right\}_{j=-\infty}^{-m-1} \left\|_{\ell^q} \left\| \left\{ 2^{j(s_1-s)} \right\}_{j=-\infty}^{-m-1} \right\|_{\ell^{q'}}. \tag{3.60}$$

This bound again implies that  $\mathbf{I}_m \to 0$  as  $m \to \infty$ .

Thus, we learn that  $\{\pi_j f\}_{j\in\mathbb{Z}} \in \tilde{\mathcal{D}}(f)$ . Using the discrete characterization of the *J*-method in Proposition 2.23 and equation (3.54) we obtain the estimate that completes the proof:

$$[f]_{\alpha,q} \lesssim_{\alpha,q} \| \{ 2^{\alpha(s_1 - s_0)j} \mathscr{J}(2^{-j(s_1 - s_0)}, \pi_j f) \}_{j \in \mathbb{Z}} \|_{\ell^q(\mathbb{Z})} \lesssim_{n,p,s_0,s_1,\psi} \| \{ 2^{sj} \| \pi_j f \|_{L^p} \}_{j \in \mathbb{Z}} \|_{\ell^q(\mathbb{Z})} = [f]_{\wedge \dot{B}_q^{s,p}}.$$

$$(3.61)$$

<span id="page-30-3"></span>We can now relate  $\dot{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K})$  and  $\dot{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K})$ .

**Corollary 3.21.** For each  $s \in (0,1)$ ,  $1 , <math>1 \leqslant q \leqslant \infty$ , there exists  $c \in \mathbb{R}^+$  with the following properties:

- (1) If  $f \in \dot{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})$ , then  $f \in \dot{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})$ , and  $[f]_{\dot{B}_q^{s,p}} \leqslant c[f]_{\dot{B}_q^{s,p}}$ .
- (2) On the other hand if  $f \in {}_{\wedge}\dot{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K})$ , then there exists a  $\mathbb{K}$ -valued polynomial Q such that f-Q is identifiable with a member of  $\dot{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K})$  and  $c^{-1}[f-Q]_{\dot{B}_{q}^{s,p}} \leqslant [f]_{{}_{\wedge}\dot{B}_{q}^{s,p}}$ . Moreover, the coefficients of Q, aside from the constant term, are uniquely determined.

*Proof.* The first item follows at once from the embeddings  $L^p(\mathbb{R}^n;\mathbb{K}) \hookrightarrow \dot{H}^{0,p}(\mathbb{R}^n;\mathbb{K})$  and  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}) \hookrightarrow \dot{H}^{1,p}(\mathbb{R}^n;\mathbb{K})$  (see Theorems 3.5 and 3.13) and the interpolation characterizations of  $\dot{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})$  (Corollary 3.18) and  $\wedge \dot{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})$  (Theorem 3.20).

For the second item, we let  $f \in {}_{\wedge}\dot{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K})$ . The finiteness of  $[f]_{{}_{\wedge}\dot{B}_{q}^{s,p}}$  implies that for each  $j \in \mathbb{Z}$  we have  $\pi_{j}f \in L^{p}(\mathbb{R}^{n};\mathbb{K})$ , and so then Theorem B.6 implies that  $\pi_{j}f \in \dot{W}^{1,p}(\mathbb{R}^{n};\mathbb{K})$ . Using the Littlewood-Paley characterization of  $\dot{W}^{1,p}(\mathbb{R}^{n};\mathbb{K})$  (Theorem 3.13) and the almost orthogonality of  $\{\pi_{j}\}_{j\in\mathbb{Z}}$  (see Lemma 3.4) we learn that

<span id="page-30-2"></span>
$$[\pi_{j}f]_{\dot{W}^{1,p}} \lesssim_{n,p,\psi} \left\| \left( \sum_{k \in \mathbb{Z}} \left( 2^{k} | \pi_{k}\pi_{j}f| \right)^{2} \right)^{1/2} \right\|_{L^{p}} \lesssim_{n,p,\psi} 2^{j} \|\pi_{j}f\|_{L^{p}}, \tag{3.62}$$

where here we can neglect any polynomial terms on the left when using Theorem 3.13 since  $\pi_j f \in \dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$ . Consequently we have the absolute convergence:

$$\sum_{j \in \mathbb{Z}} [\pi_{j} f]_{\Sigma(L^{p}, \dot{W}^{1,p})} \leq \sum_{j \in \mathbb{Z}} \min \{1, 2^{j}\} \max \{\|\pi_{j} f\|_{L^{p}}, 2^{-j} [\pi_{j} f]_{\dot{W}^{1,p}}\}$$

$$\lesssim_{n, p, \psi} \sum_{j \in \mathbb{Z}} \min \{1, 2^{j}\} \|\pi_{j} f\|_{L^{p}} \leq \|\{\min\{2^{-sj}, 2^{(1-s)j}\}\}_{j \in \mathbb{Z}} \|_{\ell^{q'}(\mathbb{Z})} [f]_{\wedge \dot{B}_{q}^{s,p}} < \infty. \quad (3.63)$$

Proposition 2.3 ensures that  $\Sigma(L^p(\mathbb{R}^n;\mathbb{K}),\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}))$  is semi-Banach. Hence, there exists  $\tilde{f}$  belonging to this sum such that  $\left[\sum_{j=-m}^m \pi_j f - \tilde{f}\right]_{\Sigma(L^p,\dot{W}^{1,p})} \to 0$  as  $m \to \infty$ . Moreover,  $\{\pi_j f\}_{j\in\mathbb{Z}}$  belongs to the discrete decomposition set of  $\tilde{f}$ , so we are free to estimate the seminorm of  $\tilde{f}$  in the interpolation space  $\dot{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K}) = \left(L^p(\mathbb{R}^n;\mathbb{K}),\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})\right)_{s,q}$  via the discrete characterization of the J-method (see Proposition 2.23) and (3.62):

$$\left[ \tilde{f} \right]_{\dot{B}_{q}^{s,p}} \lesssim_{s,q} \left\| \left\{ 2^{sj} \mathscr{J} \left( 2^{-j}, \pi_{j} f \right) \right\}_{j \in \mathbb{Z}} \right\|_{\ell^{q}(\mathbb{N})} \lesssim_{n,p,\psi} \left\| \left\{ 2^{sj} \left\| \pi_{j} f \right\|_{L^{p}} \right\}_{j \in \mathbb{Z}} \right\|_{\ell^{q}(\mathbb{N};\mathbb{R})} = [f]_{\wedge \dot{B}_{q}^{s,p}}.$$
 (3.64)

It remains to show that f and  $\tilde{f}$  differ by a polynomial. As the family of operators  $\{\pi_j\}_{j\in\mathbb{Z}}$  are continuous on both  $L^p(\mathbb{R}^n;\mathbb{K})$  and  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$  (and hence their sum) we find that  $\left[\pi_j\sum_{k=-m}^m\pi_jf-\pi_j\tilde{f}\right]_{\Sigma(L^p,\dot{W}^{1,p})}\to 0$  as  $m\to\infty$  for each  $j\in\mathbb{Z}$ . But if m>|j| then Lemma 3.4 tells us that  $\pi_j\sum_{k=-m}^m\pi_kf=\pi_jf$ . Therefore

$$\pi_{j}(f - \tilde{f}) \in \mathfrak{A}\left(\Sigma\left(L^{p}\left(\mathbb{R}^{n}; \mathbb{K}\right), \dot{W}^{1,p}\left(\mathbb{R}^{n}; \mathbb{K}\right)\right)\right) = \{\text{constant functions}\} \text{ for all } j \in \mathbb{Z}.$$
(3.65)

Since supp  $\mathscr{F}\pi_j\left(f-\tilde{f}\right)\subset\mathbb{R}^n\setminus\overline{B\left(0,2^{j-2}\right)}$  and constant functions are supported at the origin on the Fourier side, we must have  $\pi_jf=\pi_j\tilde{f}$  for all  $j\in\mathbb{Z}$ . Thus Lemma 3.3 provides us a  $\mathbb{K}$ -valued polynomial Q such that  $f-Q=\tilde{f}\in\dot{B}_q^{s,p}\left(\mathbb{R}^n;\mathbb{K}\right)$ .

If P,Q are two polynomials such that  $f-Q,f-P\in \dot{B}^{s,p}_q(\mathbb{R}^n;\mathbb{K})$ , then  $P-Q\in \dot{B}^{s,p}_q(\mathbb{R}^n;\mathbb{K})$  is a polynomial which implies that  $P-Q\in \dot{B}^{s,p}_q(\mathbb{R}^n;\mathbb{K})$  is a constant.

## 4. Screened Sobolev and screened Besov spaces

<span id="page-31-1"></span>Recall from the introduction that [LT19] defines the screened Sobolev space  $\tilde{W}^{s,p}_{(\sigma)}(U)$  as the collection of locally integrable functions  $f:U\to\mathbb{R}$  for which (1.3) holds. In this section we introduce a generalized scale of spaces, the screened Besov spaces, and use our previous seminorm interpolation theory to study their properties.

<span id="page-31-0"></span>4.1. Motivation, definitions, and basic properties. In an effort to better understand the screened Sobolev spaces, we introduce the following scale of screened Besov spaces with constant screening function.

**Definition 4.1** (Screened Besov spaces). Let  $\mathbb{K} \in \{\mathbb{R}, \mathbb{C}\}$ ,  $1 \leq p, q \leq \infty$ ,  $s \in (0,1)$ ,  $\sigma \in \mathbb{R}^+$ , and let  $\emptyset \neq U \subseteq \mathbb{R}^n$  be open. For  $h \in \mathbb{R}^n$  write  $U_h = U \cap \tau_{-h}U$ . We define the extended seminorm  $[\cdot]_{\tilde{B}_q^{s,p}}^{(\sigma)} : L^1_{\text{loc}}(\mathbb{R}^n; \mathbb{K}) \to [0, \infty]$  via

$$[f]_{\tilde{B}_{q}^{s,p}}^{(\sigma)} = \begin{cases} \left( \int_{B(0,\sigma)} \left( |h|^{-s} \|\Delta_{h} f\|_{L^{p}(U_{h};\mathbb{K})} \right)^{q} |h|^{-n} dh \right)^{1/q} & 1 \leqslant q < \infty \\ \operatorname{esssup} \left\{ |h|^{-s} \|\Delta_{h} f\|_{L^{p}(U_{h};\mathbb{K})} : h \in B(0,\sigma) \right\} & q < \infty \end{cases}$$
(4.1)

The screened Besov space,  $_{(\sigma)}\tilde{B}_{q}^{s,p}\left(U;\mathbb{K}\right)$ , is the subspace of  $L_{\mathrm{loc}}^{1}\left(U;\mathbb{K}\right)$  on which the above seminorm is finite. When  $\sigma=1$  we write  $\tilde{B}_{q}^{s,p}\left(U;\mathbb{K}\right)$  and  $[\cdot]_{\tilde{B}_{q}^{s,p}}^{s,p}$  in place of  $_{(1)}\tilde{B}_{q}^{s,p}\left(U;\mathbb{K}\right)$  and  $[\cdot]_{\tilde{B}_{s}^{s,p}}^{(1)}$ .

<span id="page-31-3"></span>We begin by providing an equivalent seminorm that utilizes the  $L^p$ -modulus of continuity.

**Proposition 4.2.** Let  $1 \leq p, q \leq \infty$  and  $\omega_p$  be the  $L^p$ -modulus of continuity from Definition 3.14. Then for all  $f \in L^1_{loc}(\mathbb{R}^n; \mathbb{K})$  and all  $s \in (0,1), \sigma \in \mathbb{R}^+$  we have the equivalence

<span id="page-31-2"></span>
$$[f]_{\tilde{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K})}^{(\sigma)} \simeq_{n,s} \begin{cases} \left( \int_{(0,\sigma)} \left( t^{-s} \omega_{p}\left(t,f\right) \right)^{q} t^{-1} dt \right)^{1/q} & 1 \leqslant q < \infty \\ \sup \left\{ t^{-s} \omega_{p}\left(t,f\right) : t \in [0,\sigma] \right\} & q = \infty \end{cases}$$

$$(4.2)$$

*Proof.* The result is trivial when  $q = \infty$ , so we only prove the case  $1 \le q < \infty$ . Using spherical coordinates we write:

<span id="page-32-1"></span>
$$[f]_{\tilde{B}_{q}^{s,p}}^{(\sigma)} = \left(\int_{B(0,\sigma)} \left(|h|^{-s} \|\Delta_{h}f\|_{L^{p}}\right)^{q} |h|^{-n} dh\right)^{1/q} = \left(\int_{(0,\sigma)} \int_{\partial B(0,1)} \|\Delta_{tz}f\|_{L^{p}}^{q} d\mathcal{H}^{n-1}(z)t^{-1-sq} dt\right)^{\frac{1}{q}}.$$

$$(4.3)$$

The ' $\lesssim$ ' inequality in (4.2) then follows from (4.3) and the simple bound

$$\int_{(0,\sigma)} \int_{\partial B(0,1)} \|\Delta_{tz} f\|_{L^{p}}^{q} d\mathcal{H}^{n-1}(z) t^{-1-sq} dt \leqslant \mathcal{H}^{n-1}(\partial B(0,1)) \int_{(0,\sigma)} (t^{-s}\omega_{p}(t,f))^{q} t^{-1} dt.$$
 (4.4)

For the ' $\gtrsim$ ' inequality in (4.2), we pick  $t \in (0, \sigma)$  and let  $h \in B(0, t) \setminus \{0\}$  and  $\xi \in B(h/2, |h|/2)$ . Observe that  $\Delta_h f = \Delta_{\xi} f + \tau_{-\xi} \Delta_{h-\xi} f$ , and hence  $\|\Delta_h f\|_{L^p} \leq \|\Delta_{\xi} f\|_{L^p} + \|\Delta_{h-\xi} f\|_{L^p}$ . We then average over  $\xi \in B(h/2, |h|/2)$  and use a change of variables to arrive at the bounds

$$\|\Delta_{h}f\|_{L^{p}} \leq 2^{n} \mathfrak{L}^{n} (B(0,1)) |h|^{-n} \int_{B(h/2,|h|/2)} (\|\Delta_{\xi}f\|_{L^{p}} + \|\Delta_{h-\xi}f\|_{L^{p}}) d\xi$$

$$\leq 2^{n+1} \mathfrak{L}^{n} (B(0,1)) |h|^{-n} \int_{B(0,|h|)} \|\Delta_{\xi}f\|_{L^{p}} d\xi \leq 2^{n+1} \mathfrak{L}^{n} (B(0,1)) \int_{B(0,|h|)} \|\Delta_{\xi}f\|_{L^{p}} |\xi|^{-n} d\xi$$

$$\leq 2^{n+1} \mathfrak{L}^{n} (B(0,1)) \int_{B(0,t)} \|\Delta_{\xi}f\|_{L^{p}} |\xi|^{-n} d\xi. \quad (4.5)$$

In this expression we take the supremum over  $h \in B(0,t)$ , raise the result to the  $q^{\text{th}}$  power, then multiply by  $t^{-1-sq}$ , and finally integrate over  $(0,\sigma)$ ; this results in the following chain of inequalities, in which we also employ Lemma B.2, Hölder's inequality, and (4.3):

$$\int_{(0,\sigma)} \left( t^{-s} \omega_{p}(t,f) \right)^{q} t^{-1} dt \leqslant \left( 2^{n+1} \mathfrak{L}^{n} \left( B \left( 0,1 \right) \right) \right)^{q} \int_{(0,\sigma)} \left( \int_{B(0,t)} \| \Delta_{\xi} f \|_{L^{p}} |\xi|^{-n} d\xi \right)^{q} t^{-1-sq} dt 
= \left( 2^{n+1} \mathfrak{L}^{n} \left( B \left( 0,1 \right) \right) \right)^{q} \int_{(0,\sigma)} \left( \int_{(0,t)} \int_{\partial B(0,1)} \| \Delta_{\rho z} f \|_{L^{p}} d\mathcal{H}^{n-1}(z) \rho^{-1} d\rho \right)^{q} t^{-1-sq} dt 
\leqslant \left( s^{-1} 2^{n+1} \mathfrak{L}^{n} \left( B \left( 0,1 \right) \right) \right)^{q} \int_{(0,\sigma)} \left( \int_{\partial B(0,1)} \| \Delta_{tz} f \|_{L^{p}} d\mathcal{H}^{n-1}(z) \right)^{q} t^{-1-sq} dt 
\leqslant \left( s^{-1} 2^{n+1} \mathfrak{L}^{n} \left( B \left( 0,1 \right) \right) \right)^{q} \left( \mathcal{H}^{n-1} \left( \partial B \left( 0,1 \right) \right) \right)^{q-1} \left( [f]_{\tilde{B}_{q}^{s,p}}^{(\sigma)} \right)^{q}. \tag{4.6}$$

<span id="page-32-2"></span>Proposition 4.2 leads us to define the following equivalent extended seminorm.

**Definition 4.3.** Let  $1 \leqslant p, q \leqslant \infty$ ,  $\sigma \in \mathbb{R}^+$ , and  $s \in (0,1)$ . We define  $\circ [\cdot]_{\tilde{B}^{s,p}_{a}}^{(\sigma)} : L^{1}_{loc}(\mathbb{R}^n; \mathbb{K}) \to [0,\infty]$  via

$${}^{\circ}[f]_{\tilde{B}_{q}^{s,p}}^{(\sigma)} = \begin{cases} \left( \int_{(0,\sigma)} (t^{-s}\omega_{p}(t,f))^{q} t^{-1} dt \right)^{1/q} & 1 \leq q < \infty \\ \sup \{ t^{-s}\omega_{p}(t,f) : t \in [0,\sigma] \} & q = \infty \end{cases}$$
(4.7)

Note that Proposition 4.2 ensures that this seminorm is equivalent to the one from Definition 4.1.

4.2. Interpolation characterization of screened Besov spaces. Using the equivalent seminorm on the space  $_{(\sigma)}\tilde{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})$  from Definition 4.3, we can realize that the  $s,q,\sigma$ -truncated interpolation space between  $L^p(\mathbb{R}^n;\mathbb{K})$  and  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$  is equal to the screened space  $_{(\sigma)}\tilde{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})$ . Precisely, we have the following theorem.

<span id="page-32-0"></span>**Theorem 4.4** (Interpolation characterization of screened spaces). Let  $1 \leq p, q \leq \infty$ ,  $s \in (0,1)$ , and  $\sigma \in \mathbb{R}^+$ . Then we have the equality of vector spaces with equivalent seminorms:

$${}_{(\sigma)}\tilde{B}_{q}^{s,p}\left(\mathbb{R}^{n};\mathbb{K}\right) = \left(L^{p}\left(\mathbb{R}^{n};\mathbb{K}\right),\dot{W}^{1,p}\left(\mathbb{R}^{n};\mathbb{K}\right)\right)_{s,q}^{(\sigma)}.$$
(4.8)

In fact, for all  $f \in \Sigma(L^p(\mathbb{R}^n; \mathbb{K}), \dot{W}^{1,p}(\mathbb{R}^n; \mathbb{K}))$  we have the equivalence

$$2^{-1\circ} [f]_{\tilde{B}_{q}^{s,p}}^{(\sigma)} \leqslant [f]_{s,q}^{(\sigma)} \leqslant (1+n^{3/2})^{\circ} [f]_{\tilde{B}_{q}^{s,p}}^{(\sigma)}. \tag{4.9}$$

*Proof.* Let  $\mathscr{K}$  denote the K-functional on the sum of  $L^p(\mathbb{R}^n;\mathbb{K})$  and  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$  and note that the strong compatibility of these spaces is shown in Lemma 3.10. It is sufficient to observe that for all  $t \in (0,\sigma)$  and all  $f \in \Sigma(L^p(\mathbb{R}^n;\mathbb{K}),\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}))$  we have the equivalence

$$2^{-1}\omega_{p}(t,f) \leqslant \mathcal{K}(t,f) \leqslant (1+n^{3/2})\omega_{p}(t,f). \tag{4.10}$$

This is a consequence of Lemma 3.17.

This interpolation characterization has numerous important and useful corollaries that we can read off from the abstract theory of seminorm interpolation presented previously. The first is that we can now can build an explicit bridge to well-studied function spaces.

<span id="page-33-0"></span>Corollary 4.5 (Sum characterization of screened spaces). Let  $s \in (0,1)$  and  $1 \le p,q \le \infty$ . The following hold:

(1) If  $\sigma, \tau \in \mathbb{R}^+$ , then we have the equality of vector spaces with equivalence of seminorms:

$$_{(\sigma)}\tilde{B}_{q}^{s,p}\left(\mathbb{R}^{n};\mathbb{K}\right)=\Sigma\left(\dot{B}_{q}^{s,p}\left(\mathbb{R}^{n};\mathbb{K}\right);\dot{W}^{1,p}\left(\mathbb{R}^{n};\mathbb{K}\right)\right)={}_{(\tau)}\tilde{B}_{q}^{s,p}\left(\mathbb{R}^{n};\mathbb{K}\right).$$

$$(4.11)$$

(2) If  $p < \infty$  and  $\sigma : \mathbb{R}^n \to \mathbb{R}^+$  is a screening function with  $\log \sigma$  a bounded function, then we have the equality of spaces with equivalence of seminorms:

$$\tilde{W}_{(\sigma)}^{s,p}(\mathbb{R}^n;\mathbb{R}) = \Sigma\left(\dot{B}_p^{s,p}(\mathbb{R}^n;\mathbb{R}), \dot{W}^{1,p}(\mathbb{R}^n;\mathbb{R})\right). \tag{4.12}$$

*Proof.* Given Corollary 4.4, the first item is immediate from Theorem 2.26. For the second item we set  $\sigma_{+} = \sup \sigma$  and  $\sigma_{-} = \inf \sigma$ . By hypothesis, these are both positive. It is a simple matter to observe that:

$$(\sigma_{+})\tilde{B}_{p}^{s,p}(\mathbb{R}^{n};\mathbb{R}) = \tilde{W}_{(\sigma_{+})}^{s,p}(\mathbb{R}^{n};\mathbb{R}) \hookrightarrow \tilde{W}_{(\sigma)}^{s,p}(\mathbb{R}^{n};\mathbb{R}) \hookrightarrow \tilde{W}_{(\sigma_{-})}^{s,p}(\mathbb{R}^{n};\mathbb{R}) = (\sigma_{-})\tilde{B}_{p}^{s,p}(\mathbb{R}^{n};\mathbb{R}). \tag{4.13}$$

Thus the second item follows from the first.

<span id="page-33-1"></span>The next corollary shows us when we have density of smooth and compactly supported functions in the screened spaces. This result is, in fact, sharp, as we will see in the next section.

Corollary 4.6. Let  $s \in (0,1)$  and  $1 \leq p,q < \infty$ . Then  $C^{\infty}(\mathbb{R}^n;\mathbb{K}) \cap \tilde{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})$  is dense in  $\tilde{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})$ . Moreover, if  $n \geq 2$  or 1 < p, then  $C_c^{\infty}(\mathbb{R}^n;\mathbb{K})$  is dense in  $\tilde{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})$ .

*Proof.* This is a consequence of Corollary 4.5, Lemma 3.7, and Corollary 2.27.  $\Box$ 

<span id="page-33-2"></span>We also learn that the screened spaces are semi-Banach and their annihilator is nothing more than the space of constant functions.

**Corollary 4.7.** Let  $s \in (0,1)$  and  $1 \leqslant p,q \leqslant \infty$ . Then  $\tilde{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})$  is semi-Banach with annihilator  $\mathfrak{A}(\tilde{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})) = \{constant\ functions\}.$ 

*Proof.* This follows from Theorem 4.4, Propositions 2.9 and 2.12, and finally Lemma 3.10.  $\Box$ 

We note that Corollary 4.7 appears in [LT19] for the scale of screened Sobolev spaces with general screening functions.

4.3. A concrete decomposition. The previous subsection shows that the screened Besov spaces coincide with the sum of a homogeneous Sobolev and a homogeneous Besov space. In either case the seminorms are, at best, tedious to work with. The purpose of this subsection is to show that we achieve a nearly optimal decomposition into the summands in a simple way. We then use this decomposition to show that compactly supported smooth functions are not dense in the space  $\tilde{B}_q^{s,1}(\mathbb{R};\mathbb{K})$  for any  $s \in (0,1)$ ,  $1 \leq q \leq \infty$ .

**Definition 4.8.** Let  $Q = (-1/2, 1/2)^n \subset \mathbb{R}^n$  and define the operators  $\mathbb{H}, \mathbb{L} : L^1_{loc}(\mathbb{R}^n; \mathbb{K}) \to L^1_{loc}(\mathbb{R}^n; \mathbb{K})$  via

$$\mathbb{H}f(x) = \int_{Q} (f(x) - f(x+y)) \, dy \, and \, \mathbb{L}f(x) = \int_{Q} f(x+y) \, dy. \tag{4.14}$$

Notice that the sum of  $\mathbb{H}$  and  $\mathbb{L}$  is the identity.

<span id="page-34-0"></span>The following theorem utilizes these to arrive at another equivalent seminorm.

**Theorem 4.9** (Fundamental decomposition of screened Besov spaces). Let  $1 \leq p, q \leq \infty$  and  $s \in (0,1)$ . There exists a constant  $c \in \mathbb{R}^+$  such that for all  $f \in L^1_{loc}(\mathbb{R}^n; \mathbb{K})$ 

<span id="page-34-2"></span>
$$c^{-1}[f]_{\tilde{B}_{a}^{s,p}} \leqslant \|\mathbb{H}f\|_{B_{a}^{s,p}} + [\mathbb{L}f]_{\dot{W}^{1,p}} \leqslant c[f]_{\tilde{B}_{a}^{s,p}}. \tag{4.15}$$

In particular, we have the equality of seminormed spaces  $\tilde{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K}) = \Sigma(B_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K});\dot{W}^{1,p}(\mathbb{R}^{n};\mathbb{K}))$  with equivalence of seminorms.

*Proof.* By the sum characterization of Corollary 4.5 and the embedding  $B_q^{s,p}(\mathbb{R}^n;\mathbb{K}) \hookrightarrow \dot{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})$ , it is sufficient to prove the second inequality in (4.15). Suppose that  $f \in \tilde{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})$ . By Lemma B.1, we have that  $\mathbb{L}f \in W^{1,1}_{loc}(\mathbb{R}^n;\mathbb{K})$  and for  $j \in \{1,\ldots,n\}$  and a.e.  $x \in \mathbb{R}^n$  it holds that

$$\partial_j \mathbb{L} f(x) = \int_{\Pi_j Q(x)} \Delta_{e_j} f(y_j', x_j - 1/2) \, \mathrm{d}y_i', \tag{4.16}$$

where  $Q(x) = \prod_{k=1}^{n} (-1/2 + x_k, 1/2 + x_k)$  and  $\Pi_j = (I - e_j \otimes e_j)$ . Then when  $1 \leq p < \infty$  an application of Minkowski's integral inequality, Proposition 4.2, and Proposition 2.8 show that

$$\|\partial_{j}\mathbb{L}f\|_{L^{p}} \leq \left(\int_{\mathbb{R}^{n}} \left|\Delta_{e_{j}}f(x)\right|^{p} dx\right)^{1/p} \leq \omega_{p}(1, f) \leq 2\mathscr{K}(1, f) \leq 2q^{-1/q}(1 - s)^{-1/q} [f]_{s, q}^{(1)}. \tag{4.17}$$

When  $p = \infty$  it is similarly clear that  $\|\partial_j \mathbb{L} f\|_{L^{\infty}} \leq 2 [f]_{s,\infty}^{(1)}$ . Note that  $\mathscr{K}$  is the K-functional associated to the sum  $\Sigma \left( L^p(\mathbb{R}^n; \mathbb{K}), \dot{W}^{1,p}(\mathbb{R}^n; \mathbb{K}) \right)$  and that  $[\cdot]_{s,q}^{(1)}$  is the seminorm on the truncated interpolation space  $\left( L^p(\mathbb{R}^n; \mathbb{K}), \dot{W}^{1,p}(\mathbb{R}^n; \mathbb{K}) \right)_{s,q}^{(1)}$ . Theorem 4.4 and Corollary 4.5 ensure us that  $[\cdot]_{s,q}^{(1)} \lesssim [\cdot]_{\tilde{B}_q^{s,p}}$ . Hence,  $[\mathbb{L} f]_{\dot{W}^{1,p}} \leq c [f]_{\tilde{B}_q^{s,p}}$  for some  $c \in \mathbb{R}^+$  depending only on s, p, and n.

With another application of Minkowski's integral inequality, we find that

<span id="page-34-4"></span><span id="page-34-3"></span>
$$\left\| \mathbb{H}f \right\|_{L^{p}} \leqslant \omega_{p} \left( 1, f \right) \lesssim [f]_{\tilde{B}_{a}^{s,p}}. \tag{4.18}$$

Thus, to show that  $\mathbb{H}f \in B_q^{s,p}(\mathbb{R}^n;\mathbb{K})$ , with a good estimate, it remains to bound  $[\mathbb{H}f]_{\dot{B}_q^{s,p}}^{\sim}$ . Note that this seminorm is defined in Definition 3.16. First we note that for all  $h \in \mathbb{R}^n$  (4.18) implies  $\|\Delta_h \mathbb{H}f\|_{L^p} \leq 2 \|\mathbb{H}f\|_{L^p} \lesssim [f]_{\tilde{B}_q^{s,p}}$ . Hence,

$$\Delta_{h} \mathbb{H} f(x) = \int_{Q} (f(x+h) - f(x+h+y) - f(x) + f(x+y)) \, dy$$

$$\Rightarrow \|\Delta_{h} \mathbb{H} f\|_{L^{p}} \lesssim \min \{ [f]_{\tilde{B}_{q}^{s,p}}, \|\Delta_{h} f\|_{L^{p}} \}. \quad (4.19)$$

Now, if  $1 \leqslant q < \infty$  we use (4.19) to estimate

$$[\mathbb{H}f]_{\tilde{B}_{q}^{s,p}}^{\sim} \leqslant \left( \int_{\mathbb{R}^{n}} \left( |h|^{-s} \|\Delta_{h} \mathbb{H}f\|_{L^{p}} \right)^{q} |h|^{-n} dh \right)^{1/q}$$

$$\lesssim [f]_{\tilde{B}_{q}^{s,p}} \left( \int_{\mathbb{R}^{n} \backslash B(0,1)} |h|^{-n-sq} dh \right)^{1/q} + \left( \int_{B(0,1)} \left( |h|^{-s} \|\Delta_{h}f\|_{L^{p}} \right)^{q} |h|^{-n} dh \right)^{1/q} \lesssim [f]_{\tilde{B}_{q}^{s,p}}. \quad (4.20)$$

The same estimates work when  $q = \infty$  as well.

Now that (4.15) is established, the embedding  $\tilde{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K}) \hookrightarrow \Sigma(B_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K});\dot{W}^{1,p}(\mathbb{R}^{n};\mathbb{K}))$  is clear. The opposite embedding is a consequence of Corollary 4.5 item (1) and the embedding  $B_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K}) \hookrightarrow \dot{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K})$ .

<span id="page-34-1"></span>As a corollary, we show that the density of compactly supported continuous functions fails in the cases not covered by Corollary 4.6.

Corollary 4.10. Let  $s \in (0,1)$  and  $1 \leq q \leq \infty$ . Then

$$\tilde{B}_{q}^{s,1}\left(\mathbb{R};\mathbb{K}\right) \setminus \overline{C_{c}^{0}\left(\mathbb{R};\mathbb{K}\right) \cap \tilde{B}_{q}^{s,1}\left(\mathbb{R};\mathbb{K}\right)}^{\tilde{B}_{q}^{s,1}} \neq \varnothing. \tag{4.21}$$

Proof. Take  $\chi \in L^1(\mathbb{R}; \mathbb{K})$  with  $\int_{\mathbb{R}} \chi = 1$  and let  $u : \mathbb{R} \to \mathbb{K}$  be defined via  $u(x) = \int_{(-\infty,x)} \chi(t) dt$ . Notice that  $u \in \dot{W}^{1,1}(\mathbb{R}; \mathbb{K})$  and hence  $u \in \tilde{B}_q^{s,1}(\mathbb{R}; \mathbb{K})$  by Corollary 4.5. Suppose, for the sake of contradiction, that there exists a sequence  $\{u_m\}_{m \in \mathbb{N}} \subset C_c^0(\mathbb{R}; \mathbb{K}) \cap \tilde{B}_q^{s,1}(\mathbb{R}; \mathbb{K})$  with the property that  $\lim_{m \to \infty} [u_m - u]_{\tilde{B}_q^{s,1}} = 0$ . Theorem 4.9 then implies that  $\lim_{m \to \infty} [\mathbb{L}u_m - \mathbb{L}u]_{\dot{W}^{1,1}} = 0$ . The compact support of each  $u_m$  would then tell us that  $\mathbb{L}u_m \in C_c^1(\mathbb{R}; \mathbb{K})$ . Hence, the fundamental theorem of calculus implies that

$$1 = \int_{\mathbb{R}} (\mathbb{L}u)' = \lim_{m \to \infty} \int_{\mathbb{R}} (\mathbb{L}u_m)' = 0, \tag{4.22}$$

a contradiction. This shows that u cannot belong to the closure of  $C_c^0\left(\mathbb{R};\mathbb{K}\right)\cap \tilde{B}_q^{s,1}\left(\mathbb{R};\mathbb{K}\right)$ .

4.4. Frequency space characterizations. Our goal in this subsection is to synthesize the sum characterization of the screened Besov spaces and the frequency characterizations of the Riesz potential and Besov-Lipschitz spaces. We find that the 'low mode' part of the function behaves no worse than a general  $\dot{W}^{1,p}$  function while the 'high mode' part behaves like a general  $B_q^{s,p}$  function. To achieve this we will generalize yet again and characterize the frequency behavior of truncated interpolation spaces between certain pairs of Riesz potential space pairs. We then read off the specifics for the screened Besov spaces.

**Definition 4.11.** Recall that for  $j \in \mathbb{Z}$  the operators  $\{\pi_j\}_{j \in \mathbb{Z}}$  are given in Definition 3.2. Let  $1 , <math>1 \leqslant q \leqslant \infty$ , and  $r, s \in \mathbb{R}$ . We define  $[\cdot]_{\tilde{B}^{r,s}_{p,q}}, [\cdot]_{\tilde{H}^{r,s}_{p,q}}: \mathscr{S}^*(\mathbb{R}^n; \mathbb{K}) \to [0, \infty]$  via

$$[f]_{\tilde{B}_{p,q}^{r,s}} = \left\| \left( \sum_{j \in \mathbb{Z} \setminus \mathbb{N}} \left( 2^{sj} | \pi_j f | \right)^2 \right)^{1/2} \right\|_{L^p} + \left\| \left\{ 2^{rj} \| \pi_j f \|_{L^p} \right\}_{j \in \mathbb{N}} \right\|_{\ell^q(\mathbb{N};\mathbb{R})}$$
(4.23)

and

$$[f]_{\tilde{H}_{p,q}^{r,s}} = \| \left\{ 2^{rj} \| \pi_j f \|_{L^p} \right\}_{j \in \mathbb{Z} \setminus \mathbb{N}} \|_{\ell^q(\mathbb{Z} \setminus \mathbb{N}; \mathbb{R})} + \| \left( \sum_{j \in \mathbb{N}} \left( 2^{sj} | \pi_j f | \right)^2 \right)^{1/2} \|_{L^p}. \tag{4.24}$$

We define  $\tilde{B}^{r,s}_{p,q}(\mathbb{R}^n;\mathbb{K})$  and  $\tilde{H}^{r,s}_{p,q}(\mathbb{R}^n;\mathbb{K})$  to be the subspaces of  $\mathscr{S}^*(\mathbb{R}^n;\mathbb{K})$  on which  $[\cdot]_{\tilde{B}^{r,s}_{p,q}}$  and  $[\cdot]_{\tilde{H}^{r,s}_{p,q}}$  are finite, respectively. We refer to these scales as the generalized screened Besov spaces and the generalized screened Riesz-potential spaces.

<span id="page-35-0"></span>The following theorem characterizes these spaces as interpolation spaces.

**Theorem 4.12** (Truncated interpolation of Riesz potential spaces). Let  $1 , <math>1 \le q \le \infty$ ,  $\alpha \in (0,1)$ ,  $\sigma \in \mathbb{R}^+$ , and  $r, s \in \mathbb{R}$  with r < s. Then we have the equality of spaces with equivalence of seminorms:

<span id="page-35-1"></span>
$$\left(\dot{H}^{r,p}\left(\mathbb{R}^{n};\mathbb{K}\right),\dot{H}^{s,p}\left(\mathbb{R}^{n};\mathbb{K}\right)\right)_{\alpha,q}^{(\sigma)} = \tilde{B}_{p,q}^{t,s}\left(\mathbb{R}^{n};\mathbb{K}\right), \text{ where } t = (1-\alpha)r + \alpha s. \tag{4.25}$$

If, on the other hand, we suppose that s < r, then we have the equality of spaces with equivalence of seminorms:

<span id="page-35-2"></span>
$$\left(\dot{H}^{r,p}\left(\mathbb{R}^{n};\mathbb{K}\right);\dot{H}^{s,p}\left(\mathbb{R}^{n};\mathbb{K}\right)\right)_{\alpha,q}^{(\sigma)} = \tilde{H}_{p,q}^{t,s}\left(\mathbb{R}^{n};\mathbb{K}\right), \text{ where } t = (1-\alpha)\,r + \alpha s. \tag{4.26}$$

*Proof.* We will prove only (4.25), as (4.26) follows from similar arguments.

Let  $[\cdot]_{\Sigma} : \Sigma(\wedge \dot{B}_q^{t,p}(\mathbb{R}^n; \mathbb{K}), \dot{H}^{s,p}(\mathbb{R}^n; \mathbb{K})) \to [0, \infty]$  via

$$[f]_{\Sigma} = \inf \left\{ [f_0]_{\dot{B}_q^{t,p}} + [f_1]_{\dot{H}^{s,p}} : f = f_0 + f_1, \ (f_0, f_1) \in {}_{\wedge}\dot{B}_q^{t,p} \left(\mathbb{R}^n; \mathbb{K}\right) \times \dot{H}^{s,p} \left(\mathbb{R}^n; \mathbb{K}\right) \right\}. \tag{4.27}$$

The sum characterization of the truncated interpolation spaces, Theorem 2.26, and the interpolation theorem of Riesz potential spaces, Theorem 3.20, ensure the equality of seminormed spaces with equivalence of seminorms:

<span id="page-35-3"></span>
$$\left(\dot{H}^{r,p}\left(\mathbb{R}^{n};\mathbb{K}\right);\dot{H}^{s,p}\left(\mathbb{R}^{n};\mathbb{K}\right)\right)_{\alpha,q}^{(\sigma)} = \Sigma\left(\wedge\dot{B}_{q}^{t,p}\left(\mathbb{R}^{n};\mathbb{K}\right),\dot{H}^{s,p}\left(\mathbb{R}^{n};\mathbb{K}\right)\right). \tag{4.28}$$

Therefore,  $[\cdot]_{\Sigma}$  is an equivalent seminorm on the truncated interpolation space on the left side of (4.28).

Now let  $f \in (\dot{H}^{r,p}(\mathbb{R}^n; \mathbb{K}), \dot{H}^{s,p}(\mathbb{R}^n; \mathbb{K}))^{(\sigma)}_{\alpha,q}$  and decompose f = g + h with  $g \in {}_{\wedge}\dot{B}^{t,p}_q(\mathbb{R}^n; \mathbb{K})$  and  $h \in \dot{H}^{s,p}(\mathbb{R}^n; \mathbb{K})$ . We estimate each factor in the space  $\tilde{B}^{t,s}_{p,q}(\mathbb{R}^n; \mathbb{K})$ , beginning with g:

$$[g]_{\tilde{B}_{p,q}^{t,s}} = \left\| \left( \sum_{j \in \mathbb{Z} \setminus \mathbb{N}} \left( 2^{sj} | \pi_{j} g | \right)^{2} \right)^{1/2} \right\|_{L^{p}} + \left\| \left\{ 2^{tj} \| \pi_{j} g \|_{L^{p}} \right\}_{j \in \mathbb{N}} \right\|_{\ell^{q}(\mathbb{N})}$$

$$\leq \left\| \left( \sum_{j \in \mathbb{Z} \setminus \mathbb{N}} \left( 2^{sj} | \pi_{j} g | \right)^{2} \right)^{1/2} \right\|_{L^{p}} + [g]_{\wedge \dot{B}_{q}^{t,p}}. \quad (4.29)$$

To handle the remaining term controlling the low modes, we can break into cases on the size of p. First, suppose that  $1 . Then the mapping <math>\mathbb{R}^+ \cup \{0\} \ni \eta \to \eta^{p/2} \in \mathbb{R}^+ \cup \{0\}$  is subadditive, and hence t < s implies that

$$\left\| \left( \sum_{j \in \mathbb{Z} \setminus \mathbb{N}} \left( 2^{sj} | \pi_{j} g | \right)^{2} \right)^{1/2} \right\|_{L^{p}} = \left( \int_{\mathbb{R}^{n}} \left( \sum_{j \in \mathbb{Z} \setminus \mathbb{N}} \left( 2^{js} | \pi_{j} g | \right)^{2} \right)^{p/2} \right)^{1/p} \leqslant \left( \sum_{j \in \mathbb{Z} \setminus \mathbb{N}} \left( 2^{js} | \pi_{j} g | \right)^{p} \right)^{1/p}$$

$$\leqslant \begin{cases} \left( \sum_{j \in \mathbb{Z} \setminus \mathbb{N}} \left( 2^{tj} | \pi_{j} g | \right)^{q} \right)^{1/q} & q \leqslant p \\ \left\| \left\{ 2^{j(s-t)} \right\}_{j \in \mathbb{Z} \setminus \mathbb{N}} \left\|_{\ell^{u}(\mathbb{Z} \setminus \mathbb{N})} \right\| \left\{ 2^{jt} | \pi_{j} g | \right\|_{L^{p}} \right\}_{j \in \mathbb{Z} \setminus \mathbb{N}} \left\|_{\ell^{q}(\mathbb{Z} \setminus \mathbb{N})} & p < q, \ 1/p = 1/q + 1/u \end{cases} \lesssim [g]_{\wedge \dot{B}_{q}^{t,p}}. \tag{4.30}$$
on the other hand, in the case that  $2 \leqslant n \leqslant \infty$ , we can apply Minkowski's integral inequality to switch

On the other hand, in the case that 2 , we can apply Minkowski's integral inequality to switch the sum and integral:

$$\left\| \left( \sum_{j \in \mathbb{Z} \setminus \mathbb{N}} \left( 2^{sj} | \pi_{j} g | \right)^{2} \right)^{1/2} \right\|_{L^{p}} \leq \left( \sum_{j \in \mathbb{Z} \setminus \mathbb{N}} \left( 2^{(s-t)j} \| 2^{tj} \pi_{j} g \|_{L^{p}} \right)^{2} \right)^{1/2} \\
\leq \begin{cases} \left( \sum_{j \in \mathbb{Z} \setminus \mathbb{N}} \left( 2^{tj} \| \pi_{j} g \|_{L^{p}} \right)^{q} \right)^{1/q} & q \leq 2 \\ \| \left\{ 2^{j(s-t)} \right\}_{j \in \mathbb{Z} \setminus \mathbb{N}} \|_{\ell^{u}(\mathbb{Z} \setminus \mathbb{N})} \| \left\{ 2^{jt} \| \pi_{j} g \|_{L^{p}} \right\}_{j \in \mathbb{Z} \setminus \mathbb{N}} \|_{\ell^{q}(\mathbb{Z} \setminus \mathbb{N})} & 2 < q, \ 1/2 = 1/q + 1/u \end{cases} \lesssim [g]_{\wedge \dot{B}_{q}^{t,p}}. \tag{4.31}$$

Next, let us show the estimates of h

$$[h]_{\tilde{B}_{p,q}^{t,s}} = \left\| \left( \sum_{j \in \mathbb{Z} \setminus \mathbb{N}} \left( 2^{sj} | \pi_j h | \right)^2 \right)^{1/2} \right\|_{L^p} + \left\| \left\{ 2^{tj} \| \pi_j h \|_{L^p} \right\}_{j \in \mathbb{N}} \right\|_{\ell^q(\mathbb{N})} \leq [h]_{\dot{H}^{s,p}}^{\sim} + \left\| \left\{ 2^{tj} \| \pi_j h \|_{L^p} \right\}_{j \in \mathbb{N}} \right\|_{\ell^q(\mathbb{N})}. \tag{4.32}$$

Again, we break into cases based on the size of p to control the high mode term. Let  $w \in \mathbb{R}$  satisfy t < w < s. If 1 , then

$$\begin{aligned}
&\|\left\{2^{tj}\|\pi_{j}h\|_{L^{p}}\right\}_{j\in\mathbb{N}}\|_{\ell^{q}(\mathbb{N})} \leqslant \sum_{j\in\mathbb{N}} 2^{tj}\|\pi_{j}h\|_{L^{p}} \leqslant \left(\sum_{j\in\mathbb{N}} 2^{\frac{p}{p-1}(t-w)j}\right)^{(p-1)/p} \left(\int_{\mathbb{R}^{n}} \sum_{j\in\mathbb{N}} |2^{wj}\pi_{j}h|^{p}\right)^{1/p} \\
&= \left(\sum_{j\in\mathbb{N}} 2^{\frac{p}{p-1}(t-w)j}\right)^{(p-1)/p} \left(\int_{\mathbb{R}^{n}} \sum_{j\in\mathbb{N}} 2^{p(w-s)j} |2^{js}\pi_{j}h|^{p}\right)^{1/p} \\
&\leqslant \left(\sum_{j\in\mathbb{N}} 2^{\frac{p}{p-1}(t-w)j}\right)^{(p-1)/p} \left(\sum_{j\in\mathbb{N}} \left(2^{p(w-s)j}\right)^{\frac{2}{2-p}}\right)^{(2-p)/2p} \left(\int_{\mathbb{R}^{n}} \left(\sum_{j\in\mathbb{N}} \left(2^{js}|\pi_{j}h|\right)^{2}\right)^{p/2}\right)^{1/p} \lesssim [h]_{\dot{H}^{s,p}}^{\sim}.
\end{aligned} \tag{4.33}$$

In the case that  $2 \leq p < \infty$  we bound

$$\left\| \left\{ 2^{tj} \| \pi_{j} h \|_{L^{p}} \right\}_{j \in \mathbb{N}} \|_{\ell^{q}(\mathbb{N})} \leqslant \sum_{j \in \mathbb{N}} 2^{tj} \| \pi_{j} h \|_{L^{p}} \leqslant \left( \sum_{j \in \mathbb{N}} 2^{\frac{p}{p-1}(t-s)j} \right)^{(p-1)/p} \left( \int_{\mathbb{R}^{n}} \sum_{j \in \mathbb{N}} \left| 2^{sj} \pi_{j} h \right|^{p} \right)^{1/p} \right. \\
\leqslant \left( \sum_{j \in \mathbb{N}} 2^{\frac{p}{p-1}(t-s)j} \right)^{(p-1)/p} \left( \int_{\mathbb{R}^{n}} \left( \sum_{j \in \mathbb{N}} \left( 2^{sj} | \pi_{j} h | \right)^{2} \right)^{p/2} \right)^{1/p} \lesssim [h]_{\dot{H}^{s,p}}^{\sim}. (4.34)$$

Thus we have shown that there exists a constant  $C \in \mathbb{R}^+$  depending on  $\alpha$ , r, s, n, q and p such that

$$[f]_{\tilde{B}_{p,q}^{t,s}} \leq [g]_{\tilde{B}_{p,q}^{t,s}} + [h]_{\tilde{B}_{p,q}^{t,s}} \leq C([g]_{\wedge \dot{B}_{q}^{t,p}} + [h]_{\dot{H}^{s,p}}). \tag{4.35}$$

Upon taking the infimum over all decompositions of f, we arrive at the embedding

$$\left(\dot{H}^{r,p}\left(\mathbb{R}^{n};\mathbb{K}\right),\dot{H}^{s,p}\left(\mathbb{R}^{n};\mathbb{K}\right)\right)_{\alpha,q}^{(\sigma)}\hookrightarrow\tilde{B}_{p,q}^{t,s}\left(\mathbb{R}^{n};\mathbb{K}\right).$$
(4.36)

On the other hand, let  $f \in \tilde{B}^{t,s}_{p,q}(\mathbb{R}^n;\mathbb{K})$ . Set  $h = \sum_{j \in \mathbb{N}} \pi_j f$  and g = f - h. We will prove that  $h \in \dot{B}^{t,p}_q(\mathbb{R}^n;\mathbb{K})$  and  $g \in \dot{H}^{s,p}(\mathbb{R}^n;\mathbb{K})$ . Note first that the series defining h is a well-defined tempered distribution, thanks to Lemma 3.3. We now compute the action of the family  $\{\pi_j\}_{j \in \mathbb{Z}}$  on h using almost orthogonality, see Lemma 3.4. For  $j \in \mathbb{N}^+$  it holds  $\pi_j h = \pi_j f$ ,  $\pi_0 h = \pi_0^2 f + \pi_0 \pi_1 f$ ,  $\pi_{-1} h = \pi_{-1} \pi_0 f$ , and finally if  $\mathbb{Z} \ni j < -1$  then  $\pi_j h = 0$ . This allows us to then estimate

<span id="page-37-1"></span>
$$[h]_{\wedge B_q^{t,p}} = \| \left\{ 2^{tj} \| \pi_j h \|_{L^p} \right\}_{j \in \mathbb{Z}} \|_{\ell^q(\mathbb{Z})} \leqslant 2^{-t} \| \pi_{-1} \pi_0 f \|_{L^p} + \| (\pi_0 + \pi_1) \pi_0 f \|_{L^p} + \| \left\{ 2^{tj} \| \pi_j f \|_{L^p} \right\}_{j \in \mathbb{N}^+} \|_{\ell^q(\mathbb{N}^+)}. \tag{4.37}$$

We apply Theorem B.6 and Lemma B.5 to the first two terms on the right hand side to find a constant  $\overline{c}$ , depending only on n, p, and  $\psi$ , such that for  $\ell \in \{-1,0,1\}$ ,  $\|\pi_{\ell}\pi_{0}f\|_{L^{p}} \leq \overline{c} \|\pi_{0}f\|_{L^{p}}$ . Plugging this into (4.37) yields the bound

<span id="page-37-3"></span><span id="page-37-2"></span>
$$[h]_{\wedge \dot{B}_{q}^{t,p}} \lesssim \|\pi_{0}f\|_{L^{p}} + \|\left\{2^{tj}\|\pi_{j}f\|_{L^{p}}\right\}_{j\in\mathbb{N}^{+}}\|_{\ell^{q}(\mathbb{N}^{+})} \leqslant 2[f]_{\tilde{B}_{p,q}^{t,s}}.$$

$$(4.38)$$

We now handle the estimates of g. Again we use Lemma 3.3 to see that for  $j \in \mathbb{N}^+$  we have  $\pi_j g = 0$ ,  $\pi_0 g = \pi_{-1} \pi_0 f$ ,  $\pi_{-1} g = \pi_{-1}^2 f + \pi_{-2} \pi_{-1} f$ , while for  $j \in \mathbb{Z} \setminus (\mathbb{N} \cup \{-1\})$  we have  $\pi_j g = \pi_j f$ . Thus with  $\overline{c}$  as before, we find that

$$[g]_{\dot{H}^{s,p}} = \left\| \left( \sum_{j \in \mathbb{Z}} \left( 2^{js} | \pi_{j} g | \right)^{2} \right)^{1/2} \right\|_{L^{p}} \leqslant \left\| \pi_{0} \pi_{-1} f \right\|_{L^{p}} + 2^{-s} \left\| \left( \pi_{-2} + \pi_{-1} \right) \pi_{-1} f \right\|_{L^{p}} + \left\| \left( \sum_{j=-\infty}^{-1} \left( 2^{sj} | \pi_{j} f | \right)^{2} \right)^{1/2} \right\|_{L^{p}} \leqslant \left( 1 + \left( 1 + 2^{-s+1} \right) \overline{c} \right) [f]_{\tilde{B}_{p,q}^{t,s}}$$
(4.39)

Together, estimates (4.38) and (4.39) prove the other embedding:  $\tilde{B}_{p,q}^{t,s}\left(\mathbb{R}^{n};\mathbb{K}\right) \hookrightarrow \left(\dot{H}^{r,p}\left(\mathbb{R}^{n};\mathbb{K}\right),\dot{H}^{s,p}\right)_{\alpha,q}^{(\sigma)}$ 

<span id="page-37-5"></span>The following result should be contrasted with Theorem 4.9

**Corollary 4.13** (Fundamental decomposition of generalized screened Besov and Riesz potential spaces). Let  $r, s \in \mathbb{R}$ ,  $1 , and <math>1 \leqslant q \leqslant \infty$ . Consider the high and low pass filters  $\mathbb{P}^+, \mathbb{P}^- : \mathscr{S}^*(\mathbb{R}^n; \mathbb{K}) \to \mathscr{S}^*(\mathbb{R}^n; \mathbb{K})$  defined by  $\mathbb{P}^+ f = \sum_{j \in \mathbb{N}} \pi_j f$  and  $\mathbb{P}^- f = f - \mathbb{P}^+ f = (I - \mathbb{P}^+) f = (I - \sum_{j \in \mathbb{N}} \pi_j) f$ . These are well defined thanks to Lemmas 3.3 and B.7. The following hold:

<span id="page-37-4"></span>(1) If 
$$r < s$$
, then for all  $f \in \tilde{B}^{r,s}_{p,q}(\mathbb{R}^n;\mathbb{K})$  we have  $\mathbb{P}^+ f \in \dot{B}^{r,p}_q(\mathbb{R}^n;\mathbb{K})$ ,  $\mathbb{P}^- f \in \dot{H}^{s,p}(\mathbb{R}^n;\mathbb{K})$ , and
$$[f]_{\tilde{B}^{r,s}_{p,q}} \times [\mathbb{P}^+ f]_{\dot{A}\dot{B}^{r,p}_q} + [\mathbb{P}^- f]_{\dot{H}^{s,p}}.$$
(4.40)

(2) If 
$$s < r$$
, then for all  $f \in \tilde{H}^{r,s}_{p,q}(\mathbb{R}^n;\mathbb{K})$  we have  $\mathbb{P}^+ f \in \dot{H}^{s,p}(\mathbb{R}^n;\mathbb{K})$  and  $\mathbb{P}^- f \in \dot{B}^{r,p}_q(\mathbb{R}^n;\mathbb{K})$ , and  $[f]_{\check{H}^{r,s}_{p,q}} \times [\mathbb{P}^+ f]_{\dot{H}^{s,p}} + [\mathbb{P}^- f]_{\dot{B}^{r,p}_q}$  (4.41)

*Proof.* Again we only prove the first item, as the second item follows from similar arguments. A consequence of Theorem 4.12 is the sum characterization:  $\Sigma(\land \dot{B}_q^{r,p}(\mathbb{R}^n;\mathbb{K}),\dot{H}^{s,p}(\mathbb{R}^n;\mathbb{K})) = \tilde{B}_{p,q}^{r,s}(\mathbb{R}^n;\mathbb{K})$ . Therefore the ' $\lesssim$ ' inequality in (4.40) is handled. As for the ' $\gtrsim$ ' inequality, we see that this is covered in the latter half of the proof of Theorem 4.12. There we showed that for  $f \in \tilde{B}_{p,q}^{r,s}(\mathbb{R}^n;\mathbb{K})$  we can decompose  $f = \mathbb{P}^+ f + \mathbb{P}^- f$ , and the seminorms of the factors in  $\land \dot{B}_q^{r,p}(\mathbb{R}^n;\mathbb{K})$  and  $\dot{H}^{s,p}(\mathbb{R}^n;\mathbb{K})$ , respectively, can be bounded above by a universal constant times  $[f]_{\tilde{B}_{p,q}^{r,s}}$ .

<span id="page-37-0"></span>Next we obtain another characterization of the screened Besov spaces.

**Corollary 4.14** (Frequency space characterization of screened Besov spaces). Let  $s \in (0,1)$ ,  $1 , and <math>1 \le q \le \infty$ . The following hold:

- (1)  $\tilde{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K}) \hookrightarrow \tilde{B}_{p,q}^{s,1}(\mathbb{R}^{n};\mathbb{K})$ , where the latter space is from Definition 4.1.
- (2) If  $f \in \tilde{B}_{p,q}^{s,1}(\mathbb{R}^n;\mathbb{K})$ , then f is identified with a locally integrable function and there exists a polynomial Q whose coefficients, aside from the constant term, are uniquely determined, with the property that  $f Q \in \tilde{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})$ . Moreover, there exists a constant  $c \in \mathbb{R}^+$  depending only on s, p, q, and n such that:  $[f Q]_{\tilde{B}_q^{s,p}} \leq c[f]_{\tilde{B}_{p,q}^{s,1}}$ .

*Proof.* Corollary 4.5 and Theorem 4.12 gave us the identities:

$$\left(L^{p}(\mathbb{R}^{n};\mathbb{K});\dot{W}^{1,p}(\mathbb{R}^{n};\mathbb{K})\right)_{s,q}^{(1)} = \tilde{B}_{q}^{s,p}(\mathbb{R}^{n};\mathbb{K}) \text{ and } \left(\dot{H}^{0,p}(\mathbb{R}^{n};\mathbb{K});\dot{H}^{1,p}(\mathbb{R}^{n};\mathbb{K})\right)_{s,q}^{(1)} = \tilde{B}_{p,q}^{s,1}(\mathbb{R}^{n};\mathbb{K}). \tag{4.42}$$

Theorem 3.5 shows that  $L^p(\mathbb{R}^n;\mathbb{K}) \hookrightarrow \dot{H}^{0,p}(\mathbb{R}^n;\mathbb{K})$ , and Theorem 3.13 shows  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}) \hookrightarrow \dot{H}^{1,p}(\mathbb{R}^n;\mathbb{K})$ . These combine to prove the first item.

On the other hand, if  $f \in \tilde{B}^{s,1}_{p,q}(\mathbb{R}^n;\mathbb{K})$ , then Corollary 4.13 tells us that  $\mathbb{P}^+f \in {}_{\wedge}\dot{B}^{s,p}_q(\mathbb{R}^n;\mathbb{K})$  and  $\mathbb{P}^-f \in \dot{H}^{1,p}(\mathbb{R}^n;\mathbb{K})$ . The former has Fourier transform supported away from the origin and hence (by Corollary 3.21)  $\mathbb{P}^+f \in \dot{B}^{s,p}_q(\mathbb{R}^n;\mathbb{K})$ . The second conclusion of Theorem 3.13 gives us a polynomial Q such that  $\mathbb{P}^-f - Q \in \dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$ , and hence  $f - Q \in \tilde{B}^{s,p}_q(\mathbb{R}^n;\mathbb{K})$ . Moreover, from Corollary 3.21, Theorem 3.13, and Corollary 4.13 we obtain the universal bound

$$[f - Q]_{\tilde{B}_{a}^{s,p}} \leqslant [\mathbb{P}^{-}f - Q]_{\dot{W}^{1,p}} + [\mathbb{P}^{+}f]_{\dot{B}_{a}^{s,p}} \lesssim [\mathbb{P}^{-}f]_{\dot{H}^{1,p}} + [\mathbb{P}^{+}f]_{\wedge \dot{B}_{a}^{s,p}} \lesssim [f]_{\tilde{B}_{p,a}^{s,1}}. \tag{4.43}$$

Finally, if P, Q are both polynomials such that f - Q,  $f - P \in \tilde{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})$ , then  $P - Q \in \tilde{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})$ , which then implies that P - Q is a constant.

<span id="page-38-0"></span>4.5. **Embeddings.** In this subsection we shed some light on the nature of the Sobolev embeddings for the screened Besov spaces. Recall the notation for the homogeneous Hölder spaces,  $\dot{C}^{0,\alpha}$ , defined in Section 1.3. We start in the subcritical case.

**Proposition 4.15** (Subcritical embedding). Suppose that  $n \in \mathbb{N} \setminus \{0,1\}$ ,  $1 \leq p < n$ ,  $1 \leq u \leq \infty$ , and  $s \in (0,1)$ . Set  $q = \frac{np}{n-p}$  and  $r = \frac{np}{n-sp}$ . Then there is a constant  $c \in \mathbb{R}^+$  such that for all  $f \in \tilde{B}^{s,p}_u(\mathbb{R}^n; \mathbb{K})$  there exists  $a \in \mathbb{K}$  such that  $f - a \in \Sigma(L^q(\mathbb{R}^n; \mathbb{K}), L^{r,u}(\mathbb{R}^n; \mathbb{K}))$ , with the estimate  $||f - a||_{\Sigma(L^q, L^{r,u})} \leq c[f]_{\tilde{B}^{s,p}_u}$ .

Proof. First, we claim that if  $f \in \Sigma(L^p(\mathbb{R}^n;\mathbb{K});\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}))$  there is a unique  $a(f) \in \mathbb{K}$  such that  $f-a(f) \in \Sigma(L^p(\mathbb{R}^n;\mathbb{K}),L^q(\mathbb{R}^n;\mathbb{K}))$ . Uniqueness is clear since if  $f-a,f-b \in \Sigma(L^p(\mathbb{R}^n;\mathbb{K}),L^q(\mathbb{R}^n;\mathbb{K}))$ , for  $a,b \in \mathbb{K}$ , then  $a-b \in \Sigma(L^p(\mathbb{R}^n;\mathbb{K}),L^q(\mathbb{R}^n;\mathbb{K}))$ , which can only happen if a=b. Existence is a consequence of the Gagliardo-Nirenberg-Sobolev inequality (see, for instance, Theorem 12.9 in [Leo17]): there is a constant  $c \in \mathbb{R}^+$  such that for all  $w \in \dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$  there exists  $a(w) \in \mathbb{K}$  such that  $w-a(w) \in L^q(\mathbb{R}^n;\mathbb{K})$  and  $\|w-a(w)\|_{L^q} \leqslant c[w]_{\dot{W}^{1,p}}$ . Thus, if  $u \in \Sigma(L^p(\mathbb{R}^n;\mathbb{K}),\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}))$ , then we can take a(u) = a(w) for any decomposition u = v + w, with  $v \in L^p(\mathbb{R}^n;\mathbb{K})$  and  $w \in \dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$ .

Next we define  $\iota : \Sigma(L^p(\mathbb{R}^n;\mathbb{K}),\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})) \to \Sigma(L^p(\mathbb{R}^n;\mathbb{K}),L^q(\mathbb{R}^n;\mathbb{K}))$  via  $\iota f = f-a(f)$ . The dependence of a(f) on f is linear, so  $\iota$  is linear. It is also the case that  $\iota$  is continuous. Indeed, for any  $f \in \Sigma(L^p(\mathbb{R}^n;\mathbb{K});\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}))$  and any decomposition f = v + w for  $v \in L^p(\mathbb{R}^n;\mathbb{K})$  and  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$ , we may estimate

$$\|\iota f\|_{\Sigma(L^p, L^q)} \leq \|v\|_{L^p} + \|w - a(w)\|_{L^q} \leq (1+c) [f]_{\Sigma(L^p, \dot{W}^{1,p})}. \tag{4.44}$$

Similar arguments show that  $\iota$  continuously maps  $L^p(\mathbb{R}^n;\mathbb{K})$  to itself (and, in fact, equals the identity mapping) and continuously maps  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$  to  $L^q(\mathbb{R}^n;\mathbb{K})$ .

Now we use the fact that the screened spaces are interpolation spaces (see Theorem 2.11). This implies, by the abstract sum characterization in Theorem 2.26, that

$$\iota: \tilde{B}_{u}^{s,p}(\mathbb{R}^{n}; \mathbb{K}) \to (L^{p}(\mathbb{R}^{n}; \mathbb{K}), L^{q}(\mathbb{R}^{n}; \mathbb{K}))_{s,u}^{(1)} = \Sigma \left(L^{q}(\mathbb{R}^{n}; \mathbb{K}), L^{r,u}(\mathbb{R}^{n}; \mathbb{K})\right) \tag{4.45}$$

is a continuous linear mapping. Here we have used the fact that  $\tilde{B}^{s,p}_{u}(\mathbb{R}^{n}\mathbb{K}) = \left(L^{p}(\mathbb{R}^{n};\mathbb{K}), \dot{W}^{1,p}(\mathbb{R}^{n};\mathbb{K})\right)_{s,u}^{(1)}$  by Corollary 4.5 and Theorem 4.4, and that  $(L^{p}(\mathbb{R}^{n};\mathbb{K}), L^{q}(\mathbb{R}^{n};\mathbb{K}))_{s,u}^{(1)} = \Sigma\left(L^{q}(\mathbb{R}^{n};\mathbb{K}), L^{r,u}(\mathbb{R}^{n};\mathbb{K})\right)$  by Theorem 2.26 and Example 2.29.

Next we consider a first mixed case.

**Proposition 4.16** (Mixed subcritical/critical embedding). Let  $1 \leqslant q \leqslant \infty$  and  $s \in (0,1)$ . Then there exists  $c \in \mathbb{R}^+$  such that for all  $f \in \tilde{B}_q^{s,n}(\mathbb{R}^n;\mathbb{K})$  we have the bound  $[f]_X \leqslant c[f]_{\tilde{B}_q^{s,n}}$ , where  $X = \Sigma(L^{r,q}(\mathbb{R}^n;\mathbb{K}), BMO(\mathbb{R}^n;\mathbb{K}))$  and r = n/(1-s).

*Proof.* By Theorem 12.31 in [Leo17] we have the continuous embedding  $\dot{W}^{1,n}(\mathbb{R}^n;\mathbb{K}) \hookrightarrow \text{BMO}(\mathbb{R}^n;\mathbb{K})$ . Example 2.31 shows that  $(L^p(\mathbb{R}^n;\mathbb{K}),\text{BMO}(\mathbb{R}^n;\mathbb{K}))_{s,q}^{(1)} = \Sigma(L^{r,q}(\mathbb{R}^n;\mathbb{K}),\text{BMO}(\mathbb{R}^n;\mathbb{K}))$ . The result now follows from Theorem 2.11 applied to the inclusion mapping from  $\Sigma(L^p(\mathbb{R}^n;\mathbb{K});\dot{W}^{1,n}(\mathbb{R}^n;\mathbb{K}))$  to  $\Sigma(L^p(\mathbb{R}^n;\mathbb{K}),\text{BMO}(\mathbb{R}^n;\mathbb{K}))$ .

The next mixed case follows.

**Proposition 4.17** (Mixed super/subcritical embedding). Let  $s \in (0,1)$  and n < p, but sp < n, and  $1 \le q \le \infty$ . Set  $r = \frac{np}{n-sp}$  and  $\alpha = 1 - \frac{n}{p}$ . Then we have the continuous embedding

$$\tilde{B}_{a}^{s,p}\left(\mathbb{R}^{n};\mathbb{K}\right) \hookrightarrow \Sigma\left(L^{r,q}\left(\mathbb{R}^{n};\mathbb{K}\right),\dot{C}^{0,\alpha}\left(\mathbb{R}^{n};\mathbb{K}\right)\right). \tag{4.46}$$

*Proof.* Theorem 4.9 tells us that we have the equality of spaces with equivalence of seminorms:

$$\tilde{B}_{q}^{s,p}\left(\mathbb{R}^{n};\mathbb{K}\right) = \Sigma\left(\dot{W}^{1,p}\left(\mathbb{R}^{n};\mathbb{K}\right), B_{q}^{s,p}\left(\mathbb{R}^{n};\mathbb{K}\right)\right). \tag{4.47}$$

The Morrey embedding yields  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}) \hookrightarrow \dot{C}^{0,\alpha}(\mathbb{R}^n;\mathbb{K})$  and the subcritical embedding of the Besov space yields  $B_q^{s,p}(\mathbb{R}^n;\mathbb{K}) \hookrightarrow L^{r,q}(\mathbb{R}^n;\mathbb{K})$  (see Lemma 12.47 and Theorem 17.49 in [Leo17]).

We now handle the final mixed case.

**Proposition 4.18** (Mixed critical, supercritical embedding). Let  $s \in (0,1)$ , n < p, with sp = n, and  $1 \le q \le \infty$ . Set  $p \le r < \infty$  and  $\alpha = 1 - \frac{n}{p}$ . Then we have the continuous embedding

$$\tilde{B}_{q}^{s,p}\left(\mathbb{R}^{n};\mathbb{K}\right) \hookrightarrow \Sigma\left(L^{r}\left(\mathbb{R}^{n};\mathbb{K}\right),\dot{C}^{0,\alpha}\left(\mathbb{R}^{n};\mathbb{K}\right)\right). \tag{4.48}$$

*Proof.* Again Morrey's embedding implies that  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}) \hookrightarrow \dot{C}^{0,\alpha}(\mathbb{R}^n;\mathbb{K})$ . The critical embedding of Besov spaces (see Theorem 17.55 in [Leo17]) implies that  $B_q^{s,p}(\mathbb{R}^n;\mathbb{K}) \hookrightarrow L^r(\mathbb{R}^n;\mathbb{K})$ .

Finally, we consider the supercritical case.

**Proposition 4.19** (Supercritical embedding). Let  $s \in (0,1)$ , n < p with n < sp, and  $1 \le q \le \infty$ . Set  $\alpha = 1 - \frac{n}{p}$  and  $\beta = s - \frac{n}{p}$ . Then we have the continuous embedding

$$\tilde{B}_{q}^{s,p}\left(\mathbb{R}^{n};\mathbb{K}\right) \hookrightarrow \Sigma\left(\dot{C}^{0,\alpha}\left(\mathbb{R}^{n};\mathbb{K}\right),C^{0,\beta}\left(\mathbb{R}^{n};\mathbb{K}\right)\right). \tag{4.49}$$

*Proof.* The hypothesis on s and p ensure that  $\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}) \hookrightarrow \dot{C}^{0,\alpha}(\mathbb{R}^n;\mathbb{K})$  and  $B_q^{s,p}(\mathbb{R}^n;\mathbb{K}) \hookrightarrow C^{0,\beta}(\mathbb{R}^n;\mathbb{K})$ , thanks to Morrey's embedding and Theorem 17.52 in [Leo17].

<span id="page-39-0"></span>4.6. Behavior on spaces of codimension 1. We now prove a a result characterizing how restriction to codimension 1 subspaces behaves in screened Besov spaces.

**Theorem 4.20** (Restriction). Let  $n \ge 2$ ,  $1 , <math>1 \le q \le \infty$ , and  $s \in (0,1)$ . Suppose that  $p^{-1} < s$  and set

$$X = \Sigma \left( B_q^{s-1/p,p} \left( \mathbb{R}^{n-1}; \mathbb{K} \right), \dot{B}_p^{1-1/p,p} \left( \mathbb{R}^{n-1}; \mathbb{K} \right) \right). \tag{4.50}$$

Define the restriction map  $R: \mathscr{S}(\mathbb{R}^n; \mathbb{K}) \to \mathscr{S}(\mathbb{R}^{n-1}; \mathbb{K})$  via Rf(y) = f(y,0) for  $y \in \mathbb{R}^{n-1}$ . Then there exists a continuous linear map  $\mathcal{R}: \tilde{B}_q^{s,p}(\mathbb{R}^n; \mathbb{K}) \to X$  with the property that  $\mathcal{R} = R$  on  $\mathscr{S}(\mathbb{R}^n; \mathbb{K})$ . Moreover, there exists a continuous linear lifting map  $\mathcal{E}: X \to \tilde{B}_q^{s,p}(\mathbb{R}^n; \mathbb{K})$  such that  $\mathcal{R}\mathcal{E} = I$  on X.

Proof. The trace theory in Section 2.7.2 of [Tri10] and Chapter 18 of [Leo17] provides continuous linear maps  $\mathcal{R}^+: B_q^{s,p}(\mathbb{R}^n;\mathbb{K}) \to B_p^{s-1/p,p}(\mathbb{R}^{n-1};\mathbb{K})$  and  $\mathcal{R}^-: \dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}) \to \dot{B}_p^{1-1/p,p}(\mathbb{R}^{n-1};\mathbb{K})$  such that  $\mathcal{R}^+u = Ru = \mathcal{R}^-u$  for all  $u \in \mathscr{S}(\mathbb{R}^n;\mathbb{K})$ . Moreover, the restriction of  $\mathcal{R}^-$  to  $W^{1,p}(\mathbb{R}^n;\mathbb{K})$  maps continuously into  $B_p^{1-1/p,p}(\mathbb{R}^{n-1};\mathbb{K})$ .

We claim that  $\mathcal{R}^+ = \mathcal{R}^-$  on  $\Delta(B_q^{s,p}(\mathbb{R}^n;\mathbb{K}), \dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})) = W^{1,p}(\mathbb{R}^n;\mathbb{K})$ . Let  $u \in W^{1,p}(\mathbb{R}^n)$  and take  $\{u_m\}_{m\in\mathbb{N}} \subset \mathscr{S}(\mathbb{R}^n;\mathbb{K})$  such that  $u_m \to u$  in  $W^{1,p}(\mathbb{R}^n;\mathbb{K})$  as  $m \to \infty$ . Then  $\mathcal{R}^+u_m = Ru_m = \mathcal{R}^-u_m$  converges to both  $\mathcal{R}^+u$  in  $B_q^{s-1/p,p}(\mathbb{R}^{n-1};\mathbb{K})$  and  $\mathcal{R}^-u$  in  $B_p^{1-1/p,p}(\mathbb{R}^n;\mathbb{K})$  as  $m \to \infty$ . These are strongly compatible Hausdorff vector spaces, so  $\mathcal{R}^+u = \mathcal{R}^-u$ , and the claim is proved.

Corollary 4.5 showed that  $\tilde{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K}) = \Sigma(\dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K}), B_q^{s,p}(\mathbb{R}^n;\mathbb{K}))$ , so if  $u \in \tilde{B}_q^{s,p}(\mathbb{R}^n;\mathbb{K})$  we may decompose it as u = v + w for  $v \in \dot{W}^{1,p}(\mathbb{R}^n;\mathbb{K})$  and  $w \in B_q^{s,p}(\mathbb{R}^n;\mathbb{K})$  as above. Given two such

decompositions,  $u = v + w = \tilde{v} + \tilde{w}$ , we have that  $v - \tilde{v} = \tilde{w} - w \in \Delta(\dot{W}^{1,p}(\mathbb{R}^n; \mathbb{K}), B_q^{s,p}(\mathbb{R}^n; \mathbb{K}))$ , and so the above claim shows that  $\mathcal{R}^-(v - \tilde{v}) = \mathcal{R}^+(\tilde{w} - w)$ , and hence  $\mathcal{R}^-\tilde{v} + \mathcal{R}^+\tilde{w} = \mathcal{R}^-v + \mathcal{R}^+w$ . This allows us to define the linear map  $\mathcal{R}: \tilde{B}_q^{s,p}(\mathbb{R}^n; \mathbb{K}) \to X$  via  $\mathcal{R}u = \mathcal{R}^-v + \mathcal{R}^+w$  where u = v + w is a decomposition as above. This map takes values in X and is continuous due to the mapping properties of  $\mathcal{R}^{\pm}$ . Clearly,  $\mathcal{R} = R$  on the Schwartz class.

We now construct  $\mathcal{E}$ . The results in Chapter 18 of [Leo17] and Section 2.7.2 in [Tri10] provide continuous linear maps  $\mathcal{E}^-: \dot{B}_p^{1-1/p,p}\left(\mathbb{R}^{n-1};\mathbb{K}\right) \to \dot{W}^{1,p}\left(\mathbb{R}^n;\mathbb{K}\right)$  and  $\mathcal{E}^+: B_q^{s-1/p,p}\left(\mathbb{R}^{n-1};\mathbb{K}\right) \to B_q^{s,p}\left(\mathbb{R}^n;\mathbb{K}\right)$  with the property that for all  $v \in \dot{B}_p^{1-1/p,p}\left(\mathbb{R}^{n-1};\mathbb{K}\right)$  and  $w \in B_q^{s-1/p,p}\left(\mathbb{R}^{n-1};\mathbb{K}\right)$  we have  $\mathcal{R}^-\mathcal{E}^-v = v$  and  $\mathcal{R}^+\mathcal{E}^+w = w$ . We paste  $\mathcal{L}^\pm$  together with the use of the high and low pass filters  $\mathbb{P}^\pm$  from Corollary 4.13. Indeed, we define  $\mathcal{E}: X \to \tilde{B}_q^{s,p}\left(\mathbb{R}^n;\mathbb{K}\right)$  via  $\mathcal{E}f = \mathcal{L}^-\mathbb{P}^-f + \mathcal{L}^+\mathbb{P}^+f$ .

Arguing as in the Corollary 4.13, we have that  $\mathbb{P}^+: X \to B_q^{s-1/p,p}(\mathbb{R}^n; \mathbb{K})$  and  $\mathbb{P}^-: X \to \dot{B}_p^{1-1/p,p}(\mathbb{R}^n; \mathbb{K})$  are continuous linear maps. Hence,  $\mathcal{E}$  is as well. Moreover, for any  $w \in X$  we can compute

$$\mathcal{R}\mathcal{L}w = \mathcal{R}^{-}\mathcal{L}^{-}\mathbb{P}^{-}w + \mathcal{R}^{+}\mathcal{L}^{+}\mathbb{P}^{+}w = (\mathbb{P}^{-} + \mathbb{P}^{+})w = w, \tag{4.51}$$

<span id="page-40-0"></span>and so  $\mathcal{E}$  is the desired right inverse for  $\mathcal{R}$ .

# APPENDIX A. VECTOR TOPOLOGIES

In this appendix we recall notions of topology in vector spaces with a particular interest in seminormed spaces. We will state several elementary facts and not attempt to provide proofs. The interested reader is referred to Taylor's book [TL80] or to Section 2.4 of [LT19].

<span id="page-40-1"></span>**Definition A.1** (Topological vector spaces and annihilators). Suppose that X is a vector space over  $\mathbb{K} \in \{\mathbb{R}, \mathbb{C}\}$  equipped with a topology  $\tau$ .

- (1) We say that  $(X,\tau)$  is a topological vector space if the vector operations,  $+: X \times X \to X$  and  $\cdot: \mathbb{K} \times X \to X$ , are continuous.
- (2) We define the annihilator of  $\tau$  to be the set  $\mathfrak{A}(X) = \overline{\{0\}}^{\tau}$ , i.e. the  $\tau$ -closure of 0.

Note that some authors enforce that topological vector spaces are a priori Hausdorff. We do not build this into our definition since our interests include vector spaces topologized by seminorms. The annihilator of a topological vector space measures how far away the space is from being Hausdorff. The following proposition quantifies this precisely.

<span id="page-40-3"></span>**Proposition A.2.** Suppose that  $(X, \tau)$  is a topological vector space in the sense of Definition A.1. Then  $\mathfrak{A}(X)$  is a closed vector subspace of X that measures the failure of  $(X, \tau)$  to be a Hausdorff space in the following sense. If  $(Y, \tilde{\tau})$  is a topological space,  $f: Y \to X$ ,  $y \in Y$ ,  $x_0, x_1 \in X$ , and  $f(z) \to x_0$  and  $f(z) \to x_1$  as  $z \to y$ , then  $x_0 - x_1 \in \mathfrak{A}(X)$ .

<span id="page-40-4"></span>A topological vector space may be equipped with various notions of size. On way of doing this is through a seminorm.

**Definition A.3** (Seminormed spaces). Suppose that  $\mathbb{K} \in \{\mathbb{R}, \mathbb{C}\}$  and X is a vector space over  $\mathbb{K}$ . We say that a function  $[\cdot]: X \to \mathbb{R}$  is a seminorm if the following properties hold: nonnegativity:  $[x] \ge 0$  for all  $x \in X$ ; subadditivity:  $\forall x, y \in X$ ,  $[x+y] \le [x] + [y]$ ; homogeneity:  $\forall \alpha \in \mathbb{K}$  and  $\forall x \in X$ ,  $[\alpha x] = |\alpha|[x]$ . We say that the pair  $(X, [\cdot])$  is a seminormed space. This space is endowed with the topology  $\tau = \{ [\cdot]^{-1}(U) : U \subseteq \mathbb{R} \text{ is open} \}$ . Note that this is the smallest topology in which  $[\cdot]$  is a continuous mapping.

<span id="page-40-2"></span>Seminormed spaces are topological vector spaces and we have the following realization of their annihilators.

**Proposition A.4.** If  $(X, [\cdot])$  is a seminormed space, then the topology  $\tau$  from Definition A.3 makes  $(X, \tau)$  a topological vector space in the sense of Definition A.1. Moreover,  $\mathfrak{A}(X) = \{x \in X : [x] = 0\}$  is a closed vector subspace.

Note that seminormed spaces are, in particular, semimetric spaces. Hence, we can quotient out be the annihilator of the seminorm and the resulting structure is, at the least, a metric space; but actually, this quotient space results in a normed vector space.

**Proposition A.5** (Quotient by annihilator). Let  $(X, [\cdot])$  be a seminormed space. We make the following definitions:

- (1) For  $x, y \in X$  we say that  $x \sim y$  if  $x y \in \mathfrak{A}(X)$ . This obviously defines an equivalence relation on X. Let  $X/\mathfrak{A}(X)$  denote the resulting set of equivalence classes.
- (2) We define the function  $|[\cdot]|: X/\mathfrak{A}(X) \to \mathbb{R}$  via |[Y]| = [y], where  $y \in Y \in X/\mathfrak{A}(X)$ .

Then, it holds that  $|[\cdot]|$  is well-defined and equipping  $X/\mathfrak{A}(X)$  with  $|[\cdot]|$  results in a normed vector space.

This leads us to a natural notion of completeness in seminormed spaces.

**Definition A.6** (Semi-Banach spaces). We say that a seminormed space  $(X, [\cdot])$  is semi-Banach or complete if the normed quotient space  $(X/\mathfrak{A}(X), |[\cdot]|)$  is complete or Banach as a normed vector space.

<span id="page-41-0"></span>The following characterization of completeness in seminormed spaces spaces is often useful.

**Lemma A.7.** Suppose that  $(X, [\cdot])$  is a seminormed space. Then,  $(X, [\cdot])$  is semi-Banach if and only if  $\forall \{x_k\}_{k=0}^{\infty} \subset X$  Cauchy, there exists  $x \in X$  such that  $\lim_{k \to \infty} [x - x_k] = 0$  if and only if  $\forall \{x_k\}_{k=0}^{\infty} \subset X$  such that  $\sum_{k=0}^{\infty} [x_k] < \infty$  there exists  $x \in X$  such that  $[x - \sum_{k=0}^{M} x_k] \to 0$  as  $M \to \infty$ .

<span id="page-41-3"></span>We now turn our attention to linear mappings between seminormed spaces.

**Proposition A.8** (Properties of linear mappings). Let  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  be seminormed spaces, and  $T: X_0 \to X_1$  be a linear mapping. Then T is continuous if and only if there is a constant  $c \in \mathbb{R}^+$  such that for all  $x \in X_0$  we have the bound  $[Tx]_1 \leq c[x]_0$ . If either condition holds, then  $T\mathfrak{A}(X_0) \subseteq \mathfrak{A}(X_1)$ .

A particularly common linear mapping between seminormed spaces is an embedding.

**Definition A.9** (Continuous embeddings and equivalent seminormed spaces). Let  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  be seminormed spaces related via the inclusion  $X_0 \subseteq X_1$ . We say that  $X_0$  is continuously embedded into  $X_1$  if the inclusion mapping  $\iota: X_0 \to X_1$  is continuous; we write  $X_0 \to X_1$  in this case. If, in addition, we assume that  $X_1 \subseteq X_0$  and the opposite inclusion  $X_1 \to X_0$  is continuous, we say that  $X_0$  and  $X_1$  are equivalent as seminormed spaces.

Note that Proposition A.8 implies that if  $X_0 \hookrightarrow X_1$ , then the annihilator of  $X_1$  must be at least as large as the annihilator of  $X_0$ ; in particular, a non-Hausdorff space cannot be continuously embedded into a Hausdorff space.

Lastly, we note that seminormed spaces are equivalent if and only if their seminormed are uniformly comparable.

**Proposition A.10** (Equivalent seminormed spaces have the same topology). Let  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  be seminormed spaces with  $X_0 \subseteq X_1 \subseteq X_0$ . Then  $(X_0, [\cdot]_0)$  and  $(X_1, [\cdot]_1)$  are equivalent as seminormed spaces if and only if the seminorms  $[\cdot]_0$  and  $[\cdot]_1$  are equivalent in the sense that there is  $c \in \mathbb{R}^+$  such that

$$c^{-1}[x]_0 \leqslant [x]_1 \leqslant c[x]_0 \text{ for all } x \in X_0 = X_1.$$
 (A.1)

#### APPENDIX B. MISCELLANEOUS FACTS FROM ANALYSIS

This appendix serves to collect some analysis results used in this paper.

## <span id="page-41-2"></span>B.1. Integral inequalities and identities.

**Lemma B.1** (Averaging on cubes). Let  $\emptyset \neq Q \subset \mathbb{R}^n$  be an open cube. If  $f : \mathbb{R}^n \to \mathbb{K}$  is a locally integrable function, we define  $f_Q : \mathbb{R}^n \to \mathbb{K}$  via  $f_Q(x) = \int_Q f(x+y) \, dy$ . Then  $f_Q \in W^{1,1}_{loc}(\mathbb{R}^n;\mathbb{K})$ , with the distributional gradient identified with the (a.e. defined) function  $\nabla f_Q(x) = \int_{\partial Q} f(x+y) \nu(y) \, d\mathcal{H}^{n-1}(y)$ , where  $\nu : \partial Q \to \mathbb{R}^n$  is the outward unit normal.

<span id="page-41-1"></span>*Proof.* This follows from Fubini's theorem, differentiation under the integral, and the fundamental theorem of calculus.  $\Box$ 

**Lemma B.2** (Hardy's inequalities). Suppose that  $s \in \mathbb{R}^+$ ,  $\sigma \in (0, \infty]$ , and  $1 \leq p < \infty$ . Then for all measurable functions  $\Omega:(0,\sigma)\to[0,\infty]$  we have the estimates

<span id="page-42-5"></span>
$$\left(\int_{(0,\sigma)} \left(t^{-s} \int_{(0,t)} \Omega\left(\rho\right) \rho^{-1} \, \mathrm{d}\rho\right)^p t^{-1} \, \mathrm{d}t\right)^{1/p} \leqslant s^{-1} \left(\int_{(0,\sigma)} \left(t^{-s} \Omega\left(t\right)\right)^p t^{-1} \, \mathrm{d}t\right)^{1/p} \tag{B.1}$$

and

$$\left(\int_{\mathbb{R}^{+}} \left(t^{s} \int_{(t,\infty)} \Omega\left(\rho\right) \rho^{-1} d\rho\right)^{p} t^{-1} dt\right)^{1/p} \leqslant s^{-1} \left(\int_{\mathbb{R}^{+}} \left(t^{s} \Omega\left(t\right)\right)^{p} t^{-1} dt\right)^{1/p}$$
(B.2)

*Proof.* When  $\sigma = \infty$ , these are the classical Hardy inequalities: see, for instance, Theorem C.41 in [Leo 17]. To prove (B.1) when  $\sigma < \infty$ , we apply (B.1) on  $\mathbb{R}^+$  to the function  $\Omega \chi_{(0,\sigma)}$ .

<span id="page-42-4"></span><span id="page-42-0"></span>B.2. Harmonic Analysis. Here are some important notions from the theory of real and complex valued tempered distributions.

**Lemma B.3** (Real valued distributions). For tempered distributions  $f \in \mathcal{S}^*(\mathbb{R}^n; \mathbb{C})$  we define the complex conjugate distribution,  $\overline{f} \in \mathscr{S}^*(\mathbb{R}^n; \mathbb{C})$  via  $\langle \overline{f}, \varphi \rangle = \overline{\langle f, \overline{\varphi} \rangle}$ ,  $\varphi \in \mathscr{S}(\mathbb{R}^n; \mathbb{C})$ . We say that f is  $\mathbb{R}$ -valued if  $f = \overline{f}$  and write  $f \in \mathscr{S}^*(\mathbb{R}^n; \mathbb{R})$ . The following hold.

- (1) For f∈ ℒ\* (ℝ<sup>n</sup>; ℂ) we have that f∈ ℒ\* (ℝ<sup>n</sup>; ℝ) if and only if f = δ<sub>-1</sub>f̂.
  (2) For f∈ L<sup>1</sup><sub>loc</sub> (ℝ<sup>n</sup>; ℂ) ∩ ℒ\* (ℝ<sup>n</sup>; ℂ) we have that f∈ ℒ\* (ℝ<sup>n</sup>; ℝ) if and only if f (x) ∈ ℝ for ℒ<sup>n</sup>-a.e.

*Proof.* If  $f \in \mathscr{S}^*(\mathbb{R}^n; \mathbb{R})$  and  $\varphi \in \mathscr{S}(\mathbb{R}^n; \mathbb{C})$ , then we equate

$$\langle f, \varphi \rangle = \langle \overline{f}, \varphi \rangle \iff \left\langle \delta_{-1} \hat{f}, \hat{\varphi} \right\rangle = \overline{\left\langle \hat{f}, \delta_{-1} \hat{\overline{\varphi}} \right\rangle} = \overline{\left\langle \hat{f}, \overline{\hat{\varphi}} \right\rangle} = \overline{\left\langle \hat{f}, \hat{\varphi} \right\rangle}.$$
 (B.3)

This gives the first item. If f is in  $L^1_{loc}(\mathbb{R}^n;\mathbb{C})$  as in the second item, then

$$\langle f - \overline{f}, \varphi \rangle = \int_{\mathbb{R}^n} (f - \overline{f}) \varphi = 0, \ \forall \ \varphi \in \mathscr{S}^* (\mathbb{R}^n; \mathbb{C}) \iff f(x) \in \mathbb{R} \text{ for a.e } x \in \mathbb{R}^n.$$
 (B.4)

**Definition B.4** (Space of Fourier Multipliers). Given  $1 \leq p < \infty$ , the space of  $L^p(\mathbb{R}^n; \mathbb{K})$ -Fourier multipliers, denoted  $\mathscr{M}_p(\mathbb{R}^n;\mathbb{K})$ , is the set of all  $m \in L^{\infty}(\mathbb{R}^n;\mathbb{C})$  such that

$$||m||_{\mathcal{M}_p} = \sup\left\{ \left| |\mathscr{F}^{-1}\left(m\mathscr{F}f\right)| \right|_{L^p} : f \in \mathscr{S}\left(\mathbb{R}^n; \mathbb{K}\right), ||f||_{L^p} = 1 \right\} < \infty$$
(B.5)

and for all  $f \in \mathcal{S}(\mathbb{R}^n; \mathbb{K})$  we have that  $\mathcal{F}^{-1}(m\mathcal{F}) f$  is  $\mathbb{K}$ -valued.

<span id="page-42-1"></span>We will need a few facts about Fourier multipliers.

**Lemma B.5** (Invariance under scaling). Let  $1 \leq p < \infty$ . If  $m \in \mathscr{M}_p(\mathbb{R}^n; \mathbb{K})$ , then for all  $\xi \in \mathbb{R} \setminus \{0\}$  it holds that  $\delta_{\xi}m \in \mathscr{M}_p(\mathbb{R}^n;\mathbb{K})$  with the equality  $\|\delta_{\xi}m\|_{\mathscr{M}_p} = \|m\|_{\mathscr{M}_p}$ ; note that  $\delta_{\xi}m$  is the isotropic  $\xi$ -dilate of m, defined via  $\delta_{\xi} m(\zeta) = m(\zeta \xi^{-1})$ .

<span id="page-42-3"></span>Next we state sufficient conditions for an essentially bounded function to be a Fourier multiplier.

**Theorem B.6** (Hörmander-Mihlin Multiplier Theorem). Suppose that  $m \in L^{\infty}(\mathbb{R}^n; \mathbb{C})$  is a function whose distributional derivatives on  $\mathbb{R}^n \setminus \{0\}$  of orders less than  $\lfloor n/2 \rfloor + 1$  can be identified with locally integrable functions on  $\mathbb{R}^n \setminus \{0\}$ . Define the number  $A \in [0, \infty]$  via

$$A = \max \left\{ \operatorname{esssup} \left\{ |\xi|^{|\alpha|} \left| \partial^{\alpha} m\left( \xi \right) \right| : \xi \in \mathbb{R}^n \setminus \{0\} \right\} : \alpha \in \mathbb{N}^n, \ |\alpha| \leqslant \lfloor n/2 \rfloor + 1 \right\}. \tag{B.6}$$

It holds that for all  $1 there exists a constant <math>C_{n,p} \in \mathbb{R}^+$ , independent of m, such that  $||m||_{\mathscr{M}_p} \leqslant$  $C_{n,p}A$ .

<span id="page-42-2"></span>We can also use Lemma B.3 to characterize which multipliers preserve the property being R-valued.

**Lemma B.7.** Let  $1 . Then <math>m \in \mathscr{M}_p(\mathbb{R}^n; \mathbb{R})$  if and only if  $m \in \mathscr{M}_p(\mathbb{R}^n; \mathbb{C})$  and  $\delta_{-1}m = \overline{m}$ . Moreover, for each  $\varphi \in \mathscr{S}(\mathbb{R}^n; \mathbb{C})$  we have that  $(\varphi \hat{f})^{\vee} \in \mathscr{S}^*(\mathbb{R}^n; \mathbb{R})$  for all  $f \in \mathscr{S}^*(\mathbb{R}^n; \mathbb{R})$  if and only if  $\delta_{-1}\varphi = \overline{\varphi}$ .

*Proof.* This is clear given Lemma B.3.

### Acknowledgments

The authors would like to express their gratitude to the anonymous referee for their thorough reading of the first draft and for the many helpful suggestions.

### References

- <span id="page-43-10"></span>[AF03] Robert A. Adams and John J. F. Fournier. Sobolev Spaces, volume 140 of Pure and Applied Mathematics. Elsevier/Academic Press, Amsterdam, second edition, 2003.
- <span id="page-43-21"></span>[ALM19] Sergey V. Astashkin, Konstantin V. Lykov, and Mario Milman. Limiting interpolation spaces via extrapolation. J. Approx. Theory, 240:16-70, 2019.
- <span id="page-43-4"></span>[BBM01] Jean Bourgain, H. Brezis, and Petru Mironescu. Another look at Sobolev spaces. In *Optimal control and partial differential equations*, pages 439–455. IOS, Amsterdam, 2001.
- <span id="page-43-5"></span>[BBM02] J. Bourgain, H. Brezis, and P. Mironescu. Limiting embedding theorems for  $W^{s,p}$  when  $s \uparrow 1$  and applications. J. Anal. Math., 87:77–101, 2002. Dedicated to the memory of Thomas H. Wolff.
- <span id="page-43-22"></span>[BCD11] Hajer Bahouri, Jean-Yves Chemin, and Raphaël Danchin. Fourier analysis and nonlinear partial differential equations, volume 343 of Grundlehren der Mathematischen Wissenschaften [Fundamental Principles of Mathematical Sciences]. Springer, Heidelberg, 2011.
- <span id="page-43-0"></span>[BF79] V. Benci and D. Fortunato. Weighted Sobolev spaces and the nonlinear Dirichlet problem in unbounded domains. Ann. Mat. Pura Appl. (4), 121:319–336, 1979.
- <span id="page-43-11"></span>[BIN78] Oleg V. Besov, Valentin P. Il'in, and Sergey M. Nikol'skiĭ. Integral Representations of Functions and Imbedding Theorems. Vol. I. V. H. Winston & Sons, Washington, D.C.; Halsted Press [John Wiley & Sons], New York-Toronto, Ont.-London, 1978. Translated from the Russian, Scripta Series in Mathematics, Edited by Mitchell H. Taibleson.
- <span id="page-43-12"></span>[BIN79] Oleg V. Besov, Valentin P. Il'in, and Sergey M. Nikol'skii. Integral Representations of Functions and Imbedding Theorems. Vol. II. V. H. Winston & Sons, Washington, D.C.; Halsted Press [John Wiley & Sons], New York-Toronto, Ont.-London, 1979. Scripta Series in Mathematics, Edited by Mitchell H. Taibleson.
- <span id="page-43-9"></span>[BL76] Jöran Bergh and Jörgen Löfström. Interpolation spaces. An introduction. Springer-Verlag, Berlin-New York, 1976. Grundlehren der Mathematischen Wissenschaften, No. 223.
- <span id="page-43-6"></span>[BN18] H. Brezis and Hoai-Minh Nguyen. Non-local functionals related to the total variation and connections with image processing. Ann. PDE, 4(1):Art. 9, 77, 2018.
- <span id="page-43-1"></span>[BS72] Melvyn S. Berger and Martin Schechter. Embedding theorems and quasi-linear elliptic boundary value problems for unbounded domains. *Trans. Amer. Math. Soc.*, 172:261–278, 1972.
- <span id="page-43-13"></span>[Bur98] Victor I. Burenkov. Sobolev Spaces on Domains, volume 137 of Teubner-Texte zur Mathematik [Teubner Texts in Mathematics]. B. G. Teubner Verlagsgesellschaft mbH, Stuttgart, 1998.
- <span id="page-43-20"></span>[CFCKU09] Fernando Cobos, Luz M. Fernández-Cabrera, Thomas Kühn, and Tino Ullrich. On an extreme class of real interpolation spaces. J. Funct. Anal., 256(7):2321–2366, 2009.
- <span id="page-43-7"></span>[DGLZ12] Qiang Du, Max Gunzburger, R. B. Lehoucq, and Kun Zhou. Analysis and approximation of nonlocal diffusion problems with volume constraints. SIAM Rev., 54(4):667–696, 2012.
- <span id="page-43-14"></span>[DNPV12] Eleonora Di Nezza, Giampiero Palatucci, and Enrico Valdinoci. Hitchhiker's guide to the fractional Sobolev spaces. Bull. Sci. Math., 136(5):521–573, 2012.
- <span id="page-43-2"></span>[EE73] D. E. Edmunds and W. D. Evans. Elliptic and degenerate-elliptic operators in unbounded domains. *Ann. Scuola Norm. Sup. Pisa Cl. Sci.* (3), 27:591–640 (1974), 1973.
- <span id="page-43-8"></span>[FKV15] Matthieu Felsinger, Moritz Kassmann, and Paul Voigt. The Dirichlet problem for nonlocal operators. *Math. Z.*, 279(3-4):779–809, 2015.
- <span id="page-43-3"></span>[FN20] Patrick T. Flynn and Huy Q. Nguyen. The vanishing surface tension limit of the Muskat problem. arXiv e-prints, page arXiv:2001.10473, January 2020.
- <span id="page-43-19"></span>[GM86] M. E. Gomez and M. Milman. Extrapolation spaces and almost-everywhere convergence of singular integrals. J. London Math. Soc. (2), 34(2):305–316, 1986.
- <span id="page-43-17"></span>[Gra14a] Loukas Grafakos. Classical Fourier analysis, volume 249 of Graduate Texts in Mathematics. Springer, New York, third edition, 2014.
- <span id="page-43-18"></span>[Gra14b] Loukas Grafakos. Modern Fourier analysis, volume 250 of Graduate Texts in Mathematics. Springer, New York, third edition, 2014.
- <span id="page-43-15"></span>[Gri11] Pierre Grisvard. Elliptic Problems in Nonsmooth Domains, volume 69 of Classics in Applied Mathematics. Society for Industrial and Applied Mathematics (SIAM), Philadelphia, PA, 2011. Reprint of the 1985 original.
- <span id="page-43-16"></span>[Gus70] Jan Gustavsson. Interpolation of semi-norms. Technical report, Lund University, 1970.

- <span id="page-44-21"></span>[HaKa95] Piotr Haj l asz and Agnieszka Ka l amajska. Polynomial asymptotics and approximation of Sobolev functions. Studia Math., 113(1):55–64, 1995.
- <span id="page-44-18"></span>[Han77] R. Hanks. Interpolation by the real method between BMO, L α (0 < α < ∞) and H α (0 < α < ∞). Indiana Univ. Math. J., 26(4):679–689, 1977.
- <span id="page-44-17"></span>[JM91] Bj¨orn Jawerth and Mario Milman. Extrapolation theory with applications. Mem. Amer. Math. Soc., 89(440):iv+82, 1991.
- <span id="page-44-0"></span>[Kuf85] Alois Kufner. Weighted Sobolev spaces. A Wiley-Interscience Publication. John Wiley & Sons, Inc., New York, 1985. Translated from the Czech.
- <span id="page-44-12"></span>[Leo17] Giovanni Leoni. A first course in Sobolev spaces, volume 181 of Graduate Studies in Mathematics. American Mathematical Society, Providence, RI, second edition, 2017.
- <span id="page-44-3"></span>[LT19] Giovanni Leoni and Ian Tice. Traces for homogeneous sobolev spaces in infinite strip-like domains. Journal of Functional Analysis, 277(7):2288–2380, 2019.
- <span id="page-44-10"></span>[Lun18] Alessandra Lunardi. Interpolation theory, volume 16 of Appunti. Scuola Normale Superiore di Pisa (Nuova Serie) [Lecture Notes. Scuola Normale Superiore di Pisa (New Series)]. Edizioni della Normale, Pisa, 2018. Third edition [of MR2523200].
- <span id="page-44-13"></span>[Maz11] Vladimir Maz'ya. Sobolev Spaces with Applications to Elliptic Partial Differential Equations, volume 342 of Grundlehren der Mathematischen Wissenschaften [Fundamental Principles of Mathematical Sciences]. Springer, Heidelberg, augmented edition, 2011.
- <span id="page-44-1"></span>[MMS10] V. Maz'ya, M. Mitrea, and T. Shaposhnikova. The Dirichlet problem in Lipschitz domains for higher order elliptic systems with rough coefficients. J. Anal. Math., 110:167–239, 2010.
- <span id="page-44-14"></span>[Neˇc12] Jindˇrich Neˇcas. Direct Methods in the Theory of Elliptic Equations. Springer Monographs in Mathematics. Springer, Heidelberg, 2012. Translated from the 1967 French original.
- <span id="page-44-5"></span>[Ngu19] Huy Q. Nguyen. On well-posedness of the Muskat problem with surface tension. arXiv e-prints, page arXiv:1907.11552, July 2019.
- <span id="page-44-4"></span>[NP20] Huy Q. Nguyen and Benot Pausader. A paradifferential approach for well-posedness of the muskat problem. Archive for Rational Mechanics and Analysis, Feb 2020.
- <span id="page-44-11"></span>[Pee68] J. Peetre. A theory of interpolation of normed spaces. Notas de Matem´atica, No. 39. Instituto de Matem´atica Pura e Aplicada, Conselho Nacional de Pesquisas, Rio de Janeiro, 1968.
- <span id="page-44-15"></span>[Pee76] Jaak Peetre. New thoughts on Besov spaces. Mathematics Department, Duke University, Durham, N.C., 1976. Duke University Mathematics Series, No. 1.
- <span id="page-44-7"></span>[Pon04] Augusto C. Ponce. A new approach to Sobolev spaces and connections to Γ-convergence. Calc. Var. Partial Differential Equations, 19(3):229–255, 2004.
- <span id="page-44-8"></span>[PS17] Augusto C. Ponce and Daniel Spector. On formulae decoupling the total variation of BV functions. Nonlinear Anal., 154:241–257, 2017.
- <span id="page-44-19"></span>[Ste93] Elias M. Stein. Harmonic analysis: real-variable methods, orthogonality, and oscillatory integrals, volume 43 of Princeton Mathematical Series. Princeton University Press, Princeton, NJ, 1993. With the assistance of Timothy S. Murphy, Monographs in Harmonic Analysis, III.
- <span id="page-44-6"></span>[Str16] Robert S. Strichartz. "Graph paper" trace characterizations of functions of finite energy. J. Anal. Math., 128:239– 260, 2016.
- <span id="page-44-2"></span>[Tha02] Gudrun Thater. Neumann problem in domains with outlets of bounded diameter. Acta Appl. Math., 73(3):251– 274, 2002.
- <span id="page-44-23"></span>[TL80] Angus Ellis Taylor and David C. Lay. Introduction to functional analysis. John Wiley & Sons, New York-Chichester-Brisbane, second edition, 1980.
- <span id="page-44-16"></span>[Tri78] Hans Triebel. Interpolation theory, function spaces, differential operators, volume 18 of North-Holland Mathematical Library. North-Holland Publishing Co., Amsterdam-New York, 1978.
- <span id="page-44-22"></span>[Tri10] Hans Triebel. Theory of function spaces. Modern Birkh¨auser Classics. Birkh¨auser/Springer Basel AG, Basel, 2010. Reprint of 1983 edition [MR0730762], Also published in 1983 by Birkh¨auser Verlag [MR0781540].
- <span id="page-44-20"></span>[Yos95] Kosaku Yosida. Functional analysis. Classics in Mathematics. Springer-Verlag, Berlin, 1995. Reprint of the sixth (1980) edition.
- <span id="page-44-9"></span>[ZD10] Kun Zhou and Qiang Du. Mathematical and numerical analysis of linear peridynamic models with nonlocal boundary conditions. SIAM J. Numer. Anal., 48(5):1759–1780, 2010.

Department of Mathematical Sciences, Carnegie Mellon University, Pittsburgh, PA 15213, USA E-mail address, N. Stevenson: nwsteven@andrew.cmu.edu

Department of Mathematical Sciences, Carnegie Mellon University, Pittsburgh, PA 15213, USA E-mail address, I. Tice: iantice@andrew.cmu.edu