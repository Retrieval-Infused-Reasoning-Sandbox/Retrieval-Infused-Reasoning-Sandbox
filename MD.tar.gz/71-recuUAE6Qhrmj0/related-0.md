# ANNALES DE L'INSTITUT FOURIER

## JACQUES DENY JACQUES-LOUIS LIONS

## Les espaces du type de Beppo Levi

*Annales de l'institut Fourier*, tome 5 (1954), p. 305-370

<[http://www.numdam.org/item?id=AIF\\_1954\\_\\_5\\_\\_305\\_0](http://www.numdam.org/item?id=AIF_1954__5__305_0)>

© Annales de l'institut Fourier, 1954, tous droits réservés.

L'accès aux archives de la revue « Annales de l'institut Fourier » (<http://annalif.ujf-grenoble.fr/>) implique l'accord avec les conditions générales d'utilisation (<http://www.numdam.org/conditions>). Toute utilisation commerciale ou impression systématique est constitutive d'une infraction pénale. Toute copie ou impression de ce fichier doit contenir la présente mention de copyright.

![](_page_0_Picture_7.jpeg)

*Article numérisé dans le cadre du programme Numérisation de documents anciens mathématiques* <http://www.numdam.org/>

## LES ESPACES DU TYPE DE BEPPO LEVI

par J. DENY et J. L. LIONS.

On sait que Beppo Levi a introduit une classe de fonctions qui jouent un rôle important dans la théorie du problème de Dirichlet (¹): les fonctions définies dans un ouvert  $\Omega$  de R<sup>n</sup>, qui sont absolument continues sur presque toute parallèle aux axes de coordonnées, et dont les dérivées partielles du premier ordre, qui existent presque partout dans  $\Omega$ , sont de carré sommable dans  $\Omega$ . Nikodym, qui les a étudiées systématiquement, les appelle fonctions (BL)(²).

La définition précédente a l'inconvénient de dépendre du choix des axes de coordonnées (³) et n'est pas toujours d'un usage très commode; il semble avantageux soit d'élargir la classe des fonctions de Beppo Levi (en considérant les fonctions dont les dérivées généralisées sont de carré sommable dans Ω), soit au contraire de la restreindre. On obtient ainsi d'une part les fonctions que nous appellerons (BL) (\*): ce sont elles qui s'introduisent naturellement dans certains énoncés d'analyse fonctionnelle, et nous les étudierons tout d'abord; d'autre part les fonctions (BL) « précisées » (⁵): elles intervien-

<sup>(1)</sup> Beppo Levi [1]. En réalité, Levi considère seulement des fonctions définies continues sur l'adhérence d'un ouvert plan assez régulier. La définition plus générale du texte est dûe à Nikodym.

<sup>(2)</sup> Nikodym [1].

<sup>(3)</sup> La fonction égale à 1 sur le produit cartésien K de deux ensembles de Cantor portés par les axes Ox et Oy, égale à 0 partout ailleurs, satisfait à la définition de Beppo Levi (ou plutôt de Nikodym) relativement au système d'axes Ox, Oy, mais n'y satisfait plus si on prend pour axes les bissectrices des précédents (car la projection de K sur une telle bissectrice n'est pas de mesure linéaire nulle).

<sup>(\*)</sup> Nous nous écartons ainsi de la terminologie de Nikodym, mais d'une façon qui n'est pas essentielle (voir chap. I, théorème 3. 1).

<sup>(5)</sup> Ces fonctions sont appelées (BLD) par Brelot [6] et [7].

nent dans la théorie fine du potentiel newtonien, et leur étude fera l'objet de la seconde partie de ce travail.

Plus généralement nous étudierons, sous le nom d'espaces du type de Beppo Levi, des espaces constitués par des distributions ou des classes de distributions définies dans un ouvert  $\Omega$  de  $\mathbb{R}^n$  et dont les dérivées du premier ordre appartiennent à un espace E de distributions dans  $\Omega$  (les fonctions (BL) étant obtenues pour  $E = L^2(\Omega)$ ); un court troisième chapitre est même consacré au cas où ce sont les dérivées d'ordre m qui sont dans E.

De nombreuses propriétés des fonctions (BL) se trouvent dans la littérature (6); nous reviendrons sur les plus importantes pour y apporter des précisions et des compléments, et surtout pour obtenir des résultats nouveaux sur des problèmes simples concernant les dérivées généralisées de fonctions définies dans un ouvert : ainsi les relations entre ouverts de Soboleff. de Nikodym et de Poincaré (chap. 1, § 5); une caractérisation simple des ouverts connexes pour lesquels le problème de Neumann (7) relatif à l'équation  $\Delta u = 0$  admet une solution quelle que soit la « donnée-frontière » satisfaisant à la classique condition nécessaire d'orthogonalité (chap. 1, théorème 10. 2); la caractérisation des ouverts connexes  $\Omega$  tels que l'espace complété de l'espace des fonctions indéfiniment dérivables à support compact dans  $\Omega$ , normé par la racine carrée de l'intégrale de Dirichlet, soit un espace de distributions (chap. 11, théorème 2.1), etc.

Nous nous plaçons toujours dans un ouvert de R<sup>n</sup>, laissant de côté des extensions possibles aux « espaces de Green » (\*) et même aux espaces de Riemann.

On trouvera à la fin de l'article un tableau des principales notations et définitions.

L'essentiel de ce travail a été résumé dans une note aux Comptes Rendus (Deny-Lions [1]).

<sup>(6)</sup> Voir entre autres: Nidokym [1], Morray [1], Calkin [1] Fuglede [1]: pour les fonctions « précisées »: Deny [1], Aronszajn et Smith [1] Brelot [6], Lelong-Ferrand [1]; pour des propriétés semblables d'espaces fonctionnels voisins: Soboleff [2], Nikolsky [1].

<sup>(7)</sup> Tel qu'il est posé, par exemple, dans Courant et Hilbert [1].

<sup>(8)</sup> Brelot et Choquet [1], Brelot [7].

#### **SOMMAIRE**

#### CHAPITRE I. — Étude générale des espaces BL(E).

- 1. Espaces BL(E), BL\*(E).
- 2. Propriétés locales, avec  $E = L^{\rho}_{loc}(\Omega)$ ; théorème de densité.
- 3. Propriétés d'absolue continuité, avec  $E = L^{\rho}_{loc}(\Omega)$ ; applications.
- 4. Décomposition canonique de l'espace BL<sup>•</sup>(Ω).
- 5. Ouverts de Soboleff et de Nikodym.
- 6. Exemples d'ouverts de Soboleff et de Nikodym.
- 7. Prolongement des distributions  $BL(\Omega)$  sur la frontière de  $\Omega$ .
- 8. Prolongement des distributions  $BL(\Omega)$  à  $R^n$ .
- 9. Un théorème de complète continuité.
- Ouverts de Nikodym, constante de Poincaré, problème de Neumann.

### CHAPITRE II. — Propriétés fines des fonctions (BL).

- 1. Capacité, énérgie, fonction de Green.
- 2. Retour sur l'espace  $\widehat{\mathfrak{D}}^{1}(\Omega)$ .
- 3. Fonctions (BL) précisées.
- 4. Un théorème de complétion.
- 5. Le problème de Dirichlet fin.
- 6. Représentation intégrale canonique des fonctions (BL) précisées.

#### CHAPITRE III. — Espace BL<sub>m</sub>(E).

- 1. Un lemme.
- 2. Espace  $BL_m^{\bullet}(E)$ .

## I. — ÉTUDE GÉNÉRALE DES ESPACES BL(E)

1. Espaces BL(E), BL'(E). — On désigne par  $\Omega$  un ouvert connexe quelconque de  $\mathbb{R}^n$ ; on désigne par  $\mathfrak{D}_{\Omega}$  l'espace des fonctions indéfiniment différentiables sur  $\Omega$ , à valeurs complexes, à supports compacts, muni de la topologie de Schwartz (Cf. Schwartz [1] et [2]). Soit  $\mathfrak{D}'_{\Omega}$  son dual, espace des distributions sur  $\Omega$ .

On désigne par E un espace vectoriel topologique localement convexe séparé et *complet*, contenu dans  $\mathfrak{D}'_{\Omega}$  avec une topologie plus fine.

DÉFINITION 1.1. — On appelle espace de Beppo Levi attaché à E, et l'on note BL(E), l'espace des distributions T sur  $\Omega$  telles que  $\frac{\delta}{\delta x_i}$  T soit dans E pour tout i, muni de la topologie la moins fine telle que les applications  $T \to \frac{\delta}{\delta x_i}$  T soient continues de BL(E) dans E.

Cet espace n'est pas séparé; cherchons l'adhérence de 0, soit  $\mathcal{H}$ , dans cet espace:  $T \in \mathcal{H}$  équivaut à  $\frac{\delta}{\delta x_i}T = 0$  pour tout i (car E est séparé), donc T est localement constante, et  $\Omega$  étant connexe par hypothèse, T est constante dans  $\Omega$ . Donc:  $\mathcal{H}$  = sous espace des constantes.

On désigne par BL'(E) l'espace vectoriel topologique séparé associé à BL(E), *i.e.* le quotient de BL(E) par %. On désigne par T' un élément de BL'(E); si T est quelconque dans T',  $\in \mathfrak{D}'_{\Omega}$ , T' est l'ensemble des distributions  $\{T+c\}$ , c= constante quelconque.

On va montrer le

Théorème 1. 1. — L'ouvert  $\Omega$  étant connexe, et l'espace E séparé et complet, l'espace BL'(E) est complet.

Démonstration. — Soit  $T^{\bullet}_{\alpha}$  un filtre de Cauchy dans  $BL^{\bullet}(E)$ ; pour  $T_{\alpha} \in T^{\bullet}_{\alpha}$  quelconque,  $\frac{\delta}{\delta x_i} T_{\alpha}$  est un filtre de Cauchy dans E, donc, E étant complet,  $\frac{\delta}{\delta x_i} T_{\alpha} \to S_i$  dans E, et il reste à montrer qu'il existe T dans  $\mathfrak{D}'_{\Omega}$ , telle que  $\frac{\delta}{\delta x_i} T = S_i$  pour tout i.

Si  $\Omega = \mathbb{R}^n$ , c'est le théorème VI, de Schwartz [1], p. 60. Dans le cas général, c'est une conséquence immédiate du 3e théorème de Rham (cf. de Rham-Kodaira [1], Th. C, p. 40): il faut montrer en effet que le courant  $\omega = \sum_{i=1}^n S_i dx_i$  est un d-bord (d = différentielle extérieure); or  $\omega$  est limite dans l'espace des courants de degré 1, des courants  $\omega_{\alpha}$ :

$$\omega_{\alpha} = \sum_{i=1}^{n} \frac{\partial}{\partial x_{i}} T_{\alpha} dx_{i} = dT_{\alpha},$$

qui sont donc des d-bords; l'espace des d-bords étant fermé,  $\omega$  est un d-bord. c.q.f.d.

Exemples. — 1) L'exemple le plus important est celui où E est l'espace  $L^2(\Omega)$  des (classes de) fonctions de carré sommable sur  $\Omega$  (pour la mesure de Lebesgue ordinaire dx). On pose alors s'il n'y a pas ambiguïté:  $BL(L^2(\Omega)) = BL$  ou  $BL(\Omega)$ . Si  $T \in BL(\Omega)$ , on pose

$$||\mathbf{T}||_{1}^{2} = \sum_{i=1}^{n} \left\| \frac{\partial}{\partial x_{i}} \mathbf{T} \right\|_{\mathbf{L}^{2}}^{2}$$

ce qui définit sur  $BL(\Omega)$  une structure préhilbertienne. On pose  $BL^{\bullet}(L^{2}(\Omega)) = BL^{\bullet}$  ou  $BL^{\bullet}(\Omega)$ . On a :

COROLLAIRE 1.1. — L'espace  $BL^{\bullet}(\Omega)$  est un espace de  $Hilbert({}^{\bullet})$ .

2) On prend  $E = L^p(\Omega)$ , espace des (classes) de fonctions de puissance  $p^{\text{ième}}$  intégrale sur  $\Omega$ ,  $1 \leq p < \infty$  (si  $p = \infty$ ,  $L^p(\Omega)$  est l'espace des fonctions essentiellement bornées sur  $\Omega$ ). On a alors:

Corollaire 1.2. — L'espace  $\mathrm{BL}^{\:\raisebox{3.5pt}{\text{\circle*{1.5}}}}(\mathrm{L}^p(\Omega))$  est un espace de Banach.

(9) Ce théorème est dû pour l'essentiel à Nikodym [1].

3) On prend:

 $E = L_{loc}^p(\Omega)$ , espace des fonctions sur  $\Omega$  qui sont localement dans  $L^p$ ; si  $\Omega_k$  est une suite croissante d'ouverts bornés, de réunion  $\Omega$ ,  $L_{loc}^p(\Omega)$  est muni de la suite de semi-normes:

$$\left(\int_{\Omega_k} |u|^p dx\right)^{1/p}$$
.

L'espace  $L^p_{loc}(\Omega)$  est alors un espace de Fréchet (i.e. métrisable et complet) et

Corollaire 1. 3. — L'espace  $\mathrm{BL}^{\:\raisebox{3.5pt}{\text{\circle*{1.5}}}}(\mathrm{L}^{\:\raisebox{3.5pt}{\text{oc}}}(\Omega))$  est un espace de Fréchet.

2. Propriétés locales, avec  $E=L^p_{loc}(\Omega)$ ; théorème de densité. — On va montrer le

Théorème 2.1. — Si  $T \in BL(E)$ ,  $E = L^p_{loc}(\Omega)$ , alors T est presque partout égale à une fonction (notée encore T) de l'espace  $L^q_{loc}$  où  $1/q = \sup(1/q_i, 0)$ ,  $1/q_i = 1/p - 1/n$ , sauf a) si p = 1, auquel cas on peut seulement prendre q avec  $1/q < 1/q_i$  (mais alors la propriété reste valable en remplaçant  $L^p_{loc}$  par un espace de mesures sur  $\Omega$ ); b) si  $p = n \neq 1$ , auquel cas  $T \in L^p_{loc}(\Omega)$  pour tout r fini. Si p > n, T est continue.

Démonstration. — Soit  $\omega$  un ouvert borné, avec  $\omega \subset \overline{\omega} \subset \Omega$ . Appelons voisinage régulier de  $\omega$  un ouvert borné, contenu dans  $\Omega$ , et contenant tous les points à distance  $\varepsilon$  de  $\omega$ ,  $\varepsilon$  assez petit. Soit alors  $\omega \subset \Omega_1 \subset \Omega_2 \subset \Omega$ , chaque ensemble étant ouvert, et étant un voisinage régulier du précédent. Soit  $\varphi \in \mathcal{D}_{\Omega}$ , = 1 sur  $\Omega_1$ , = 0 hors de  $\Omega_2$ . Soit  $T \in BL(E)$ , et posons  $S = \varphi T$ . On peut considérer S comme distribution à support compact dans  $\mathbb{R}^n$ .

Soit maintenant  $\gamma \in \mathfrak{D}_{\mathbb{R}^n}$ , = 1 au voisinage de l'origine dans  $\mathbb{R}^n$ . On a (cf. Schwartz [2] p. 39):

$$\Delta(-1/a_n \cdot \gamma r^{2-n}) = \zeta + \delta, \qquad \zeta \in \mathfrak{D},$$

 $\delta = \text{mesure de Dirac}(^{10}).$ 

Il en résulte:

(2, 1) 
$$S + \zeta * S = \sum_{i=1}^{n} \frac{\partial}{\partial x_i} (-1/a_n \gamma r^{2-n}) * \frac{\partial}{\partial x_i} S.$$

(10)  $\Delta$  désigne le Laplacien; le coefficient  $a_n$  ne dépend que de n.

La fonction  $\zeta_*S$  est indéfiniment différentiable. Tout est donc ramené à l'étude locale du 2e membre de (2, 1), i.e. à

$$\frac{\partial}{\partial x_i} (\gamma r^{2-n}) * \frac{\partial}{\partial x_i} S.$$

Or  $\frac{\partial}{\partial x_i}$ S =  $\left(\frac{\partial}{\partial x_i}\varphi\right)$ T +  $\varphi\frac{\partial}{\partial x_i}$ T, et comme  $\varphi$  vaut 1 sur  $\Omega_1$ , il

en résulte que  $\left(\frac{\delta}{\delta x_i}\varphi\right)$ T est nulle sur  $\Omega_i$ , donc le produit de composition :

$$\frac{\partial}{\partial x_i} (\gamma r^{2-n}) * \left( \frac{\partial}{\partial x_i} \varphi \right) \mathbf{T}$$

est nul sur  $\omega$  si l'on prend le support de  $\gamma$  assez petit. Finalement on est ramené à l'étude sur  $\omega$  de

$$\frac{\partial}{\partial x_i} (\gamma r^{2-n}) * \left( \varphi \frac{\partial}{\partial x_i} T \right) \cdot$$

Le théorème résulte alors d'un théorème de Soboleff (cf. Soboleff [1] et Schwartz [2]).

Remarque 2. 1. — Il est commode de retenir le cas particulier suivant du théorème précédent, dont la démonstration n'utilise pas d'ailleurs le théorème de Soboleff:

COROLLAIRE 2. 1. — Si  $E = L^{p}_{loc}(\Omega)$ , toute distribution T de BL(E) est localement dans  $L^{p}$ .

Remarque 2. 2. — Si dans le théorème 2. 1, on prend  $E = L^p(\Omega)$ , le théorème est évidemment valable, mais on prendra garde que, en général, il n'est pas vrai que T soit dans  $L^q(\Omega)$ ; le Théorème 2. 1 est essentiellement un théorème local (11).

Démontrons maintenant le

Théorème 2. 2. — Soit  $E = L^p_{loc}(\Omega)$ ,  $T_k$  une suite de distributions de BL(E) tendant vers  $T_0$  dans cet espace; il existe alors une suite de constantes  $c_k$  telles que  $T_k + c_k$  tende vers  $T_0$  dans  $L^q_{loc}(\Omega)$ , ou  $L^r_{loc}(\Omega)$  pour tout r fini si  $p = n \neq 1$ .

<sup>(11)</sup> Pour l'étude des propriétés globales, problème bien naturel, voir les nos 5 et 6.

Démonstration. — Désignons par F l'espace des fonctions  $u \in L^q_{loc}(\Omega)$ , telles que  $\frac{\partial}{\partial x_i} u \in E$  pour tout i, muni de la topologie la moins fine telle que les applications  $u \to u$  et  $u \to \frac{\delta}{\lambda_x} u$ soient continues de F dans L<sub>loc</sub> et E respectivement. Cet espace est complet (immédiat), c'est donc un espace de Fréchet. Considérons l'espace quotient F' de F par le sous-espace vectoriel fermé des constantes; F' est encore un espace de Fréchet; cet espace coïncide algébriquement avec BL'(Ω) (théorème 2. 1) et il est muni d'une topologie à priori plus fine que la topologie de  $BL'(\Omega)$ . Donc, d'après le théorème de Banach sur les isomorphismes (Cf. Bourbaki [1], p. 34) ces topologies coincident. Donc si T's est la suite de l'énoncé,  $T_k \rightarrow T_0$  dans F'; comme F' est le quotient de F par le sousespace vectoriel des constantes, il existe une suite  $c_k$  de constantes telles que  $T_k + c_k \rightarrow T_0$  dans F, d'où le théorème. Même démonstration pour le cas p = n.

Théorème de densité. — On désigne par  $\mathcal{E}_{\Omega}$  l'espace des fonctions indéfiniment différentiables sur  $\Omega$ , de support quelconque, muni de la topologie habituelle et par  $\mathcal{E}'_{\Omega}$  l'espace dual des distributions à support compact sur  $\Omega$ . On va démontrer le théorème de densité:

Théorème 2. 3. —  $Si \to L^p(\Omega)$  ou  $L^p_{loc}(\Omega)$ , l'espace  $\mathcal{E}_{\Omega} \cap BL(E)$  est dense dans BL(E).

Démonstration. — Soit  $\{a_k\}$  une partition de l'unité sur  $\Omega$ :  $1 = \sum_{k=1}^{\infty} a_k \text{ sur } \Omega$ ,  $a_k \in \mathcal{D}_{\Omega}$ , telle que si  $S_k$  est le support de  $a_k$ , alors parmi les  $S_i$ ,  $S_k$  rencontre seulement  $S_{k-1}$ ,  $S_k$  et  $S_{k+1}$ . Soit  $T \in BL(E)$  donnée, ainsi que  $\varepsilon > 0$ . On va construire f, élément de  $\mathcal{E}_{\Omega} \cap BL(E)$ , tel que  $\frac{\partial T}{\partial x_i} - \frac{\partial f}{\partial x_i} \in L^p(\Omega)$  pout tout i, et vérifie:

(2, 2) 
$$\left\| \frac{\partial}{\partial x_i} \mathbf{T} - \frac{\partial}{\partial x_i} f \right\|_{\mathbf{L}^{\mathbf{p}}(\Omega)} \leq \varepsilon, \quad \text{pour tout } i,$$

ce qui évidemment entraîne le théorème.

Pour cela, on écrit d'abord:  $T = \sum_{k} T_{k}$ ,  $T_{k} = a_{k}T$ , série convergente dans  $\mathfrak{D}'_{\Omega}$ . On considère alors  $b_{k} \in \mathfrak{D}_{\mathbb{R}^{n}}$ ,  $b_{k} \rightarrow \delta$ 

dans  $\mathscr{E}'_{\mathbf{R}^n}$  lorsque  $k \to \infty$ , et le support de  $b_k$  étant contenu dans une boule de rayon assez petit pour que les supports de  $\mathbf{T}_k * b_k$  aient la même propriété que les  $\mathbf{S}_k$ . Il en résulte que la série :  $f = \Sigma \mathbf{T}_k * b_k$  converge dans  $\mathscr{E}_{\Omega}$ . En outre, on a dans  $\mathbf{D}'_{\Omega}$ :

(2, 3) 
$$\frac{\partial}{\partial x_i} \mathbf{T} - \frac{\partial}{\partial x_i} f = \sum \frac{\partial}{\partial x_i} \mathbf{T}_k * (\partial - b_k).$$

Or, d'après le théorème 2.1,  $\frac{\delta}{\delta x_i} T_k$  est dans  $L^p(\mathbb{R}^n)$  (on prolonge par 0 hors de  $\Omega$ ), donc on peut choisir  $b_k$  de sorte que la norme de  $\frac{\delta}{\delta x_i} T_k * (\delta - b_k)$  dans  $L^p(\mathbb{R}^n)$  soit  $\leqslant \varepsilon_k$ , avec:  $\varepsilon = \Sigma \varepsilon_k$ ,  $\varepsilon_k > 0$ .

Il en résulte qu'avec ce choix des  $b_k$ , la série dans (2, 3) converge dans  $L^p(\Omega)$  vers un élément de norme  $\leq \varepsilon$ . On a donc (2, 2), et  $\frac{\delta}{\delta x_i} f$  est dans E pour tout i, donc f est dans  $\mathrm{BL}(\mathrm{E})$ , et aussi dans  $\mathscr{E}_{\Omega}$ ; le théorème est donc démontré.

- 3. Propriétés d'absolue continuité, avec  $E = L^p_{loc}(\Omega)$ . Applications. Voici tout d'abord un énoncé emprunté à L. Schwartz ([1], p. 58); nous disons qu'une fonction F(x), définie dans un ouvert  $\Omega$ , est absolument continue sur une droite D si la restriction de F à tout intervalle fermé contenu dans  $D \cap \Omega$  est absolument continue:
- Lemme 3. 1. a) Si une fonction F(x), localement sommable dans un ouvert  $\Omega$ , est absolument continue sur presque toute parallèle à l'axe des  $x_1$  et admet presque partout pour dérivée (au sens usuel) une fonction localement sommable  $\left[\frac{\delta F}{\delta x_1}\right] = g_1$ , on a aussi  $\frac{\delta}{\delta x_1} F = g_1$  au sens des distributions.
- b) Si une fonction F(x) admet pour dérivée  $\frac{\delta}{\delta x_i}$  F, au sens des distributions, une fonction  $g_i$ , F est presque partout égale à une fonction  $F_i$  absolument continue sur presque toute parallèle à l'axe des  $x_i$  qui admet presque partout pour dérivée au sens usuel  $\left[\frac{\delta F}{\delta x_i}\right]$  la fonction  $g_i$ .

Ce lemme simple nous suffira pour les applications que nous avons en vue; cependant, pour faire le rapprochement entre les définitions adoptées dans ce travail, et l'ancienne définition de Beppo Levi et Nikodym rappelée dans l'introduction (cas  $E = L^2(\Omega)$ ), nous allons préciser quelque peu ce résultat.

Définition 3.1. — Une fonction F(x) possède la propriété (AC) dans  $\Omega$  si elle est absolument continue sur presque toute parallèle à *chacun* des axes de coordonnées.

Lemme 3. 2. — Si une fonction F(x) admet pour dérivées au sens des distributions dans  $\Omega$  des fonctions  $g_i (i = 1, ..., n)$ , F est presque partout égale à une fonction  $F^*$  possédant la propriété (AC) dans  $\Omega$  (12).

Démonstration. — Il suffit de montrer que la propriété a lieu sur tout compact K de  $\Omega$ ; or, sur un tel compact K, F coı̈ncide avec une fonction de même nature, nulle hors d'un autre compact : le produit de F par une fonction de  $\mathfrak{D}_{\Omega}$  égale à 1 sur K; on supposera donc F définie dans  $R^n$  tout entier et nulle hors d'un compact.

Posons:

$$\mathbf{F}_{i} = \int_{-\infty}^{x_{i}} \mathbf{g}_{i}(t, x_{2}, ..., x_{n}) dt$$

et définissons de même  $F_2$ , ...  $F_n$ . La fonction  $F_i$  est absolument continue sur presque toute parallèle à l'axe des  $x_i$ , et  $F_i = F$  presque partout (i = 1, ..., n).

Considérons maintenant la régularisée  $f_k = F * \alpha_k$  de F par une fonction  $\alpha_k \in \mathfrak{D}(\mathbb{R}^n)$ , avec  $\alpha_k \geqslant 0$ ,  $|\alpha_k = 0$  pour  $|x| \geqslant 1/k$ ,  $\int \alpha_k dx = 1$ ; il est bien connu que, pour  $k \to \infty$ ,  $f_k$  converge fortement vers F dans  $L^1(\mathbb{R}^n)$ ; de même

$$\frac{\partial}{\partial x_i} f_k = \left(\frac{\partial}{\partial x_i} \mathbf{F}\right) * \alpha_k \xrightarrow{\sim} \frac{\partial}{\partial x_i} \mathbf{F}$$

dans L'(R"); on a donc:

$$\int \left| \frac{\partial f_k}{\partial x_i} - \frac{\partial F}{\partial x_i} \right| dx = \int \cdots \int \left| \int \left| \frac{\partial f_k}{\partial x_i} - g_i \right| dx_i \right| dx_2 \cdots dx_n \to 0.$$

(12) On trouvera un énoncé équivalent (au langage près) dans Calkin [1] (théorème 4. 1).

Il existe donc une suite partielle, notée aussi $\{f_k\}$ , telle que

$$\int \left| \frac{\partial f_k}{\partial x_1} - g_1 \right| dx_1 \to 0$$

pour presque tous les systèmes de nombres  $(x_2, ..., x_n)$ , c'est-àdire sur presque toute parallèle à l'axe des  $x_1$ . Sur une telle droite,  $f_k$  converge uniformément vers  $F_1$ , car

$$|f_k - F_1| \leqslant \int_{-\infty}^{x} \left| \frac{\partial f_k}{\partial x_1} - g_1 \right| dx_1 \leqslant \int_{-\infty}^{+\infty} \left| \frac{\partial f_k}{\partial x_1} - g_1 \right| dx_1 \to 0.$$

Par nouvelles extractions de suites partielles, on voit qu'on peut supposer que  $f_k$  converge uniformément vers  $F_i$  sur presque toute parallèle à l'axe des  $x_i$ , et ceci pour  $i=1,\ldots,n$ . Soit  $F^*(x)=\lim f_k(x)$ ; cette limite existe en presque tout point x et vaut F(x) presque partout. Sur presque toute parallèle à l'axe des  $x_i$ ,  $F^*$  est identique à  $F_i(i=1,\ldots,n)$ , donc est absolument continue, d'où le résultat.

Remarque. — On peut aller plus loin, et choisir la fonction F\* de façon qu'elle possède la propriété (AC) quel que soit le système de coordonnées (voir C.B. Morray [1], th. 6.3).

De l'étude précédente résulte aussitôt le

Théorème 3. 1. — Pour qu'une distribution soit dans BL(E), avec E =  $L^{\rho}_{loc}(\Omega)$  il faut et il suffit que ce soit une fonction (presque partout) égale à une fonction F possédant la propriété (AC), et dont les dérivées au sens usuel  $\left[\frac{\delta F}{\delta x_i}\right]$  sont dans  $L^{\rho}_{loc}(\Omega)$ ; ces fonctions  $\left[\frac{\delta F}{\delta x_i}\right]$  sont alors les dérivées de F au sens des distributions.

Démonstration. — En effet toute fonction F possédant la propriété (AC) est sommable sur tout compact de  $\Omega$  (13); la condition est donc suffisante (lemme 3. 1 a); elle est aussi nécessaire (théorème 2. 1 et lemme 3. 2).

(13) Démonstration sommaire (avec n=2 pour simplifier): supposons F absolument continue sur  $x_2=a_2$ . Dans un voisinage du point  $A(a_1,a_2)$  de  $\Omega$ , on a presque partout F=G+H, où

$$\mathrm{G}\left(x_{1}\right)=\int_{a_{1}}^{x_{1}}\frac{\mathrm{d}\mathrm{F}}{\mathrm{d}x_{1}}\left(t,\;a_{2}\right)\,dt\quad\mathrm{et}\quad\mathrm{H}\left(x_{1},\;x_{2}\right)=\int_{a_{2}}^{x_{2}}\frac{\mathrm{d}\mathrm{F}}{\mathrm{d}x_{2}}\left(x_{1},\;t\right)dt$$

sont évidemment sommables (au voisinage de A).

Nous allons maintenant donner quelques applications du lemme 3.1; signalons auparavant un lemme tout à fait élémentaire:

Lemme 3.3. — Soit u(t) une fonction à valeurs réelles de la variable réelle t, absolument continue dans l'intervalle  $(\alpha, \beta)$ ; les fonctions  $\bar{u} = \sup(u, 0)$ ,  $\bar{u} = \sup(-u, 0)$ ,  $|u| = \bar{u} + \bar{u}$  sont absolument continues dans  $(\alpha, \beta)$ ; si  $\psi(t)$  est la fonction caractéristique de l'ensemble  $E_t(u(t) > 0)$ , on a, presque partout dans  $(\alpha, \beta)$ :

$$\frac{d\dot{u}}{dt} = \frac{du}{dt} \psi(t), \qquad \left| \frac{d|u|}{dt} \right| = \left| \frac{du}{dt} \right|.$$

Démonstration. — La première partie de l'énoncé est une conséquence immédiate de la définition de l'absolue continuité; les dérivées au sens usuel  $d\bar{u}/dt$ ,  $d\bar{u}/dt$ , d|u|/dt existent donc en presque tout point t de l'intervalle  $(\alpha, \beta)$ ; si  $u(t) \neq 0$ , les relations à démontrer ont évidemment lieu pourvu que du/dt existe; enfin  $d\bar{u}/dt = d|u|/dt = du/dt = 0$  presque partout sur l'ensemble  $e = E_t(u(t) = 0)$  (d'une façon précise: en tout point limite de e en lequel ces trois dérivées existent).

Théorème 3. 2. — Soit F une fonction à valeurs réelles dans BL(E), avec  $E = L^{r}_{loc}(\Omega)$ ; les fonctions F, F et |F| sont dans BL(E); si  $\psi(x)$  est la fonction caractéristique de l'ensemble  $E_x(F(x) > 0)$ , on a, presque partout dans  $\Omega$ :

$$\overrightarrow{\operatorname{grad}} \stackrel{.}{\operatorname{F}} = \psi(x) \overrightarrow{\operatorname{grad}} \operatorname{F}, \qquad |\overrightarrow{\operatorname{grad}}| \operatorname{F}| = |\overrightarrow{\operatorname{grad}} \operatorname{F}|.$$

C'est une conséquence immédiate des lemmes 3. 1 et 3. 3;  $\overline{\text{grad}}$  F désigne le vecteur dont les composantes sont les fonctions  $\frac{\delta}{\delta x_i}$  F.

Remarque 3. 2. — Si F et G sont des fonctions à valeurs réelles de BL(E), avec  $E=L^r_{loc}(\Omega)$ , il en est de même de  $\sup (F,G)=\frac{1}{2}(F+G+|F-G|)$  et de  $\inf (F,G)$ .

Remarque 3. 3. — Si  $F \in BL(E)$ , avec  $E = L^{\rho}_{loc}(\Omega)$  est à valeurs complexes, on a encore  $|F| \in BL(E)$ , mais on ne peut

plus affirmer l'égalité presque partout des modules des gradients; on a seulement:

presque partout dans  $\Omega$ , l'égalité n'ayant lieu (presque partout) que si F est le produit d'une fonction  $\in BL(E)$  à valeurs réelles par une constante réelle ou complexe (vérification facile).

Proposition 3.1. — Soit  $F \in BL(E)$  à valeurs réelles  $(E = L^{\rho}_{loc}(\Omega))$ ; soit N un entier > 0; la fonction  $F_{N}(x) = F(x)$  si  $|F(x)| \leq N$ , = N si  $F(x) \geq N$ , = -N si  $F(x) \leq -N$  est dans BL(E); de plus, si K est un compact de  $\Omega$ , on a:

$$\lim_{N\to\infty}\int_{K}\left|\overline{\operatorname{grad}}\left(\mathbf{F}-\mathbf{F}_{\mathbf{N}}\right)\right|^{p}dx=0.$$

Démonstration. — La première partie de l'énoncé résulte de la remarque 3. 2 appliquée à  $F_N = \inf (\sup (F, -N), N)$ ; d'autre part on a presque partout dans  $\Omega$ :

$$\overrightarrow{\operatorname{grad}} F_{N} = \psi_{N} \overrightarrow{\operatorname{grad}} F,$$

où  $\psi_N$  est la fonction caractéristique de l'ensemble  $E_x(F(x) \leqslant N)$ ; donc

$$\int_{K} |\overrightarrow{\operatorname{grad}} (F - F_{N})|^{p} dx = \int_{K} |\overrightarrow{\operatorname{grad}} F|^{p} (1 - \psi_{N})^{p} dx$$

tend bien vers 0 avec 1/N (théorème de Lebesgue).

On peut mettre la proposition 3. 1 sous la forme:

Lorsque  $N \to \infty$ ,  $F_N \to F$  dans BL(E),  $E = Ll_{loc}(\Omega)$  (et en outre  $F_N \to F$  dans  $Ll_{loc}(\Omega)$ , donc dans  $\mathfrak{D}'_{\Omega}$ ).

De la même façon on a la

Proposition 3. 2. — Si  $E = L^p(\Omega)$ , la fonction  $F_N$  définie comme à la proposition 3. 1 à partir de F élément quelconque de BL(E), tend, lorsque  $N \to \infty$ , vers F dans BL(E).

4. Décomposition canonique de l'espace  $BL^{\bullet}(\Omega)$ . — Rappelons que  $BL^{\bullet}(\Omega)$  désigne l'espace  $BL^{\bullet}(E)$ , avec  $E=L^{2}(\Omega)$ . On va maintenant utiliser de façon essentielle la structure d'espace de Hilbert de cet espace.

Considérons l'image  $\mathfrak{D}_{\Omega}$  de  $\mathfrak{D}_{\Omega}$  dans BL', dans l'application canonique BL  $\rightarrow$  BL'.

Définition 4. 1. — On désigne par  $BL_{\mathfrak{o}}(\Omega)$  l'adhérence de  $\mathfrak{D}_{\Omega}$  dans  $BL^{\bullet}(\Omega)$ .

On a alors le

Théorème 4. 1. — Si l'on décompose l'espace de Hilbert  $\mathrm{BL}^{\boldsymbol{\cdot}}(\Omega)$  en somme directe de deux espaces orthogonaux:

$$(4, 1) BL^{\bullet}(\Omega) = BL^{\bullet}(\Omega) \oplus \mathcal{H}^{\bullet}(\Omega),$$

 $\mathcal{H}^{\bullet}(\Omega)$  est l'espace des classes  $T^{\bullet}$  de distributions  $T \in BL(\Omega)$  telles que  $\Delta T = 0$ .

Démonstration. — En effet  $T \in \mathcal{H}^{\bullet}(\Omega)$  équivaut à  $(T, \varphi)_{\bullet} = 0$  pour tout  $\varphi$  dans  $\mathfrak{D}_{\Omega}$ ,  $T \in T^{\bullet}$  quelconque, i.e.  $\langle \Delta T, \overline{\varphi} \rangle = 0$  pour tout  $\varphi$  dans  $\mathfrak{D}_{\Omega}$ , donc  $\Delta T = 0$ , c.q.f.d.

On va maintenant interpréter l'espace BL<sub>0</sub>(Ω).

Pour cela on considère comme il est naturel, l'espace  $\mathfrak{D}_{\Omega}$  muni de la  $norme \ ||\varphi||_{l}$ ,  $\varphi \in \mathfrak{D}_{\Omega}$ , et l'on introduit l'espace  $\widehat{\mathfrak{D}}^{1}(\Omega)$  complété de  $\mathfrak{D}_{\Omega}$  pour cette norme;  $\widehat{\mathfrak{D}}^{1}(\Omega)$  est un espace de Hilbert. Cet espace n'est utilisable que s'il est contenu dans l'espace  $\mathfrak{D}'_{\Omega}$  des distributions sur  $\Omega$ ; pour voir s'il en est ainsi, il faut distinguer deux cas selon que  $\Omega$  est borné ou non. Si  $\Omega$  est borné, il est utile d'introduire  $l'espace \, \mathfrak{E}^{\iota}_{L^{2}}(\Omega)$  des fonctions

 $u \in L^2(\Omega)$  telles que  $\frac{\delta}{\delta x}$ ,  $u \in L^2(\Omega)$  pour tout i, muni de la norme :

$$|||u|||_1 = (||u||_{L^2}^2 + ||u||_1^2)^{1/2}.$$

C'est un espace de Hilbert. On a alors le

Théorème 4. 2. — Lorsque  $\Omega$  est un ouvert connexe borné, l'espace  $\widehat{\mathfrak{D}}^{1}(\Omega)$  coïncide avec l'adhérence  $\mathfrak{D}^{1}_{L^{2}}(\Omega)$  de  $\mathfrak{D}_{\Omega}$  dans  $\mathfrak{E}^{1}_{L^{2}}(\Omega)$ .

Démonstration. — Comme  $\Omega$  est borné, il existe une constante  $C(\Omega)$  ne dépendant que de  $\Omega$  telle que pour tout  $\varphi \in \mathcal{D}_{\Omega}$  on ait :

$$||\phi||_{L^2} \leqslant C(\Omega)||\phi||_{\scriptscriptstyle 1}$$
 (14).

(14) Cf. Gårding [1]. Voici la démonstration, en bref: soit  $\tilde{\phi}$  la prolongée de  $\phi$  à  $R^n$  par 0 hors de  $\Omega$ ; on a par exemple:

$$(\star) \qquad \qquad \tilde{\varphi}(x) = \int_{-\infty}^{\infty} \frac{\partial \varphi}{\partial x_1}(t, x_2, \ldots, x_n) dt$$

d'où:

$$||\varphi||_{L^2}^2 \leqslant (\text{diamètre }\Omega) ||\varphi||_1^2.$$

Evidemment on peut améliorer cette majoration. De façon précise : si  $\Omega$  est borné, on montre (Gårding) que l'injection de  $\mathfrak{D}^1_{L^2}(\Omega)$  dans  $L^2(\Omega)$  est complètement continue, de sorte que —  $\Delta$  —  $\lambda$  est un isomorphisme de  $\mathfrak{D}^1_{L^2}(\Omega)$  sur l'espace dual  $\mathfrak{D}'^1_{L^2}(\Omega)$  sauf pour un ensemble dénombrable de valeurs de  $\lambda > 0$ ; soient  $0 < \chi_1 \leqslant \chi_2...$  ces

Il en résulte que sur  $\mathfrak{D}_{\Omega}$ , les normes  $||\varphi||_{\iota}$  et  $|||\varphi|||_{\iota}$  sont équivalentes, d'où le résultat.

Remarque 4. 1. — On aura un résultat analogue chaque fois que l'on aura une majoration :  $||\varphi||_{L^2} \leq C(\Omega) ||\varphi||_1$ . Exemple :  $\Omega$  est dans  $\mathbb{R}^2$  contenu dans une bande  $a < x_1 < b$ , a, b finis.

La situation est moins simple si Ω n'est pas borné. On va d'abord signaler deux résultats négatifs:

a) pour n=1, on prend  $\Omega=\mathbb{R}$ , axe entier,  $x_1=x$ . Alors le complété  $\widehat{\mathfrak{D}}^1$  de  $\mathfrak{D}$  pour  $||\varphi||$  n'est pas un espace de distributions. Voici un contre-exemple. On considère, pour chaque entier k, une fonction  $f_k$ , nulle pour  $|x| \geqslant k^3$ , = k pour x=0, = 0 pour  $x=\pm k^3$ , linéaire, et  $\varphi_k=f_k*\rho$ ,  $\rho\in\mathfrak{D}$ .

On voit aussitôt que  $\frac{d}{dx}\varphi_k \rightarrow 0$  dans L<sup>2</sup>(R), et néanmoins  $\varphi_k$  ne converge pas dans  $\mathfrak{D}'$ .

b) pour n=2, on prend  $\Omega=\mathbb{R}^2$ , plan entier; ici encore le complété  $\widehat{D}^1$  n'est pas un espace de distributions. Voici un contre exemple. On prend des coordonnées polaires  $(r, \theta)$ , et on va construire une suite  $\varphi_k$  de fonctions de  $\mathfrak{D}$ , ne dépendant que de r, telles que  $\sqrt{r} \frac{d}{dr} \varphi_k(r)$  converge dans  $L^2(0, +\infty)$  et que  $\varphi_k$  ne converge pas dans  $\mathfrak{D}'$ . Pour cela on prend une fonction a(r), indéfiniment dérivable dans  $r \geqslant 0$ , = 1 pour r > 3,  $\geqslant 0$ , et de sorte que  $(r \log r)^{-1} a(r)$  soit nulle pour r=2 ainsi que toutes ses dérivées. On considère ensuite  $a_k(r)=a(r)$  pour  $r \leqslant k$ , = 0 pour r > k+1, indéfiniment dérivable,  $\geqslant 0$ , et on pose:  $\varphi_k(r)=-\int_r^\infty (t\log t)^{-1}a_i(t)\,dt.$ 

On a là une fonction indéfiniment dérivable dans  $r \ge 0$ , nulle pour r > k+1 et dont toutes les dérivées d'ordre  $\ge 1$  sont nulles pour r=0; donc on peut considérer  $\varphi_k$  comme élément de  $\mathfrak{D}$ ;  $\frac{d}{dr}\varphi_k(r) = + (r\log r)^{-1}a_k(r)$ , donc

$$\sqrt{r} \frac{d}{dr} \varphi_k(r) \rightarrow + (\sqrt{r} \log r)^{-1} a(r)$$
 dans  $L^2(0, +\infty)$ 

valeurs propres. Si alors  $\|\phi\|_{L^2} \leqslant C(\Omega) \|\phi\|_1$ ,  $C(\Omega)$  désignant la meilleure constante possible, on voit facilement que:  $C(\Omega) = 1/\sqrt{\chi_1}$ .

Par ailleurs on voit, à partir de (\*), que pour obtenir une inégalité du type (\*\*),

Par ailleurs on voit, à partir de (\*), que pour obtenir une inégalité du type (\*\*), il suffit que  $\Omega$  soit « d'épaisseur bornée » dans une direction (cf. alors l'exemple de la remarque 4. 1 ci-après).

lorsque  $k \to \infty$ , et néanmoins,  $\varphi_k$  ne converge pas dans  $\mathfrak{D}'$ ; en effet, pour r > 3,  $|\varphi_k(r)| \ge \int_r^k (t \log t)^{-1} dt$  qui tend vers l'infini avec k.

Considérons maintenant sur R, un ouvert  $\Omega$  égal à un demi axe, soit x > 0, pour fixer les idées. Alors, le complété de  $\mathfrak{D}_{\Omega}$  pour  $||\varphi||_{\iota}$  est cette fois contenu dans  $\mathfrak{D}'$ . En effet, pour toute fonction  $\varphi \in \mathfrak{D}$ , on a:

$$\varphi(x) = \int_0^x \frac{d\varphi}{dt}(t) dt \quad \text{donc} \quad |\varphi(x)|^2 \leqslant x \int_0^x \left| \frac{d\varphi}{dt} \right|^2 dt,$$

et donc si  $\varphi_k$  est une suite de Cauchy dans  $\mathfrak{D}_{\Omega}$  pour  $||\varphi||_i$ , alors  $\varphi_k$  converge uniformément sur tout compact, d'où le résultat.

Pour  $\Omega$  contenu dans  $\mathbb{R}^2$ , on a le

Théorème 4. 3. — Si  $\Omega$  est un ouvert connexe de  $R^2$  dont le complémentaire a un intérieur non vide, alors  $\widehat{\mathfrak{D}}^1(\Omega)$  est contenu dans l'espace  $L^2_{loc}(\Omega)$  des (classes de) fonctions localement de carré sommable dans  $\Omega$  (muni de la topologie naturelle d'espace de Fréchet) (15).

Démonstration. — On peut supposer que le disque de centre 0, et de rayon  $\rho$  est contenu dans  $\bigcap \Omega$ . Soit  $\varphi \in \mathfrak{D}_{\Omega}$ ; on a :

$$\varphi(x) = \int_0^1 \left( x_1 \frac{\delta \varphi}{\delta x_1}(tx) + x_2 \frac{\delta \varphi}{\delta x_2}(tx) \right) dt,$$

d'où, en désignant par  $c_i$  des constantes diverses,

$$|arphi\left(x
ight)|^{2} \leqslant c_{1} \int_{0}^{1} \left(\left|rac{\deltaarphi}{\delta x_{1}}\left(tx
ight)
ight|^{2} + \left|rac{\deltaarphi}{\delta x_{2}}\left(tx
ight)
ight|^{2}
ight)dt,$$

lorsque x demeure dans un ensemble compact contenu dans  $\Omega$ , soit K. Lorsque x parcourt K, tx parcourt tK, et comme  $\varphi$  est nulle pour  $|x| \leqslant \rho$ , tK rencontre le support de  $\varphi$  lorsque t varie dans un intervalle  $[\varepsilon(K), 1]$ ,  $\varepsilon(K) > 0$ , donc:

$$\int_{\mathbf{K}} \left| \varphi(x) \right|^{2} dx \leqslant c_{1} \int_{\epsilon(\mathbf{K})}^{1} t^{-2} dt \int_{\epsilon(\mathbf{K})} \left( \left| \frac{\partial \varphi}{\partial x_{1}}(x) \right|^{2} + \left| \frac{\partial \varphi}{\partial x_{2}}(x) \right|^{2} \right) dx \leqslant c_{2}(\mathbf{K}) ||\varphi||_{1}^{2}.$$

(15) On déterminera plus loin, en utilisant les méthodes de la théorie du potentiel, les ouverts connexes de R<sup>2</sup> pour lesquels ce résultat est encore vrai. (chap. II, théorème 2. 1).

Il en résulte que si  $\varphi_i$  est une suite de Cauchy dans  $\mathfrak{D}_{\Omega}$  pour  $||\varphi||_i$ , alors  $\varphi_i$  est une suite de Cauchy dans l'espace  $L^2_{loc}(\Omega)$ , d'où le théorème (16).

Notons également la

Proposition 4. 1. — Soit  $\Omega$  un ouvert connexe de R<sup>2</sup> tel que  $\widehat{\mathfrak{D}}^{\mathbf{1}}(\Omega)$  soit un espace de distributions. Dans ces conditions, si  $F_k$  est une suite de  $\widehat{\mathfrak{D}}^*(\Omega)$  qui tend vers F dans cet espace, alors  $F_k \to F$  dans  $L'_{loc}(\Omega)$  pour tout r fini.

Démonstration. — Désignons par A, l'espace des fonctions  $u \in L^{r}_{loc}(\Omega)$ , r fixé quelconque, telles que  $\frac{\delta}{\delta x}$ ,  $u \in L^{2}(\Omega)$ tout i, muni de sa topologie naturelle d'espace de Fréchet. Si  $\widehat{\mathfrak{D}}^{1}(\Omega)$  est un espace de distributions, alors :  $\widehat{\mathfrak{D}}^{1}(\Omega) \subset BL(\Omega)$ , algébriquement, donc, par le théorème 2.1, cas exceptionnel b),  $\mathfrak{D}^{1}(\Omega)$  est contenu dans A, (algébriquement). Mais il résulte du théorème du graphe fermé que l'injection  $u \to u$  de  $\widehat{\mathfrak{D}}^{i}(\Omega)$ dans A, est continue, d'où la proposition.

Remarque 4. 2. — Un raisonnement analogue à celui du théorème 4. 3 vaut évidemment pour  $\Omega$  contenu dans  $\mathbb{R}^n$ , n quelconque, mais pour  $n \geqslant 3$ , on a un résultat meilleur comme on va voir. On introduit une fois pour toutes le nombre q donné par:

 $1/q = 1/2 - 1/n, \quad (n \geqslant 3),$ 

et l'espace  $\mathcal{E}_{q,2}^1(\Omega)$  des fonctions  $u \in L^q(\Omega)$  telles que  $\frac{\delta}{\delta x_i} u \in L^2(\Omega)$  pour tout i, espace que l'on munit de la norme

$$||u||_{\mathcal{E}_{q,2(\Omega)}^1} = ||u||_{L^q} + ||u||_{_1}.$$

L'espace  $\mathcal{E}_{q,2}^1(\Omega)$  est un espace de Banach (17). Ceci posé, on a le

(16) Il faut encore montrer que l'injection de  $\widehat{\mathfrak{D}}^1(\Omega)$  dans  $L^2_{loc}(\Omega)$  (ou dans  $\mathfrak{D}'_{\Omega}$ ) est biunivoque, i.e.: soit  $u \in \widehat{\mathfrak{D}}^1(\Omega)$ , avec  $\langle u, \overline{\varphi} \rangle = 0$  pour toute  $\varphi \in \mathfrak{D}_{\Omega}$ ; alors u doit être nulle dans  $\widehat{\mathfrak{D}}^1(\Omega)$ ; or  $(u, \varphi)_1 = \langle u, -\Delta \overline{\varphi} \rangle$ , donc  $(u, \varphi)_1 = 0$  pour toute  $\varphi \in \mathfrak{D}_{\Omega}$ , donc u = 0 dans  $\widehat{\mathfrak{D}}^{1}(\Omega)$ .

(17) On démontre exactement comme au théorème 2. 3 que l'espace  $\mathcal{E} \cap \mathcal{E}_{d,2}^1(\Omega)$ est dense dans  $\mathcal{E}_{q,2}^1(\Omega)$ . Si  $T \in \mathcal{E}_{q,2}$ , on a, avec les mêmes notations:  $T_k \in L^q(\Omega)$ ; on choisit donc  $b_k$  tel que  $||T_k*(\delta-b_k)||_{L^q} \leqslant \varepsilon_k$  et  $\left\|\frac{\delta}{\delta x_i}T_k*(\delta-b_k)\right\|_{L^2} \leqslant \varepsilon$  pour tout  $\iota$ 

d'où le résultat; même chose pour l'espace εί. (Ω).

Théorème 4. 4. — Si  $\Omega$  est un ouvert connexe quelconque (borné ou non) de  $\mathbb{R}^n$ , avec  $n \geqslant 3$ , alors le complété  $\widehat{\mathfrak{D}}^1(\Omega)$  de  $\mathfrak{D}_{\Omega}$  pour la norme  $||\varphi||_{\mathfrak{l}}$ , est identique à l'adhérence  $\mathfrak{D}^{\mathfrak{l}}_{\mathfrak{q},2}(\Omega)$  de  $\mathfrak{D}_{\Omega}$  dans  $\mathcal{E}^{\mathfrak{l}}_{\mathfrak{q},2}(\Omega)$ .

Démonstration. — Si  $\Omega$  n'est pas borné, il n'existe pas de constante  $C(\Omega)$  telle que  $||\varphi||_{L^2} \leqslant C(\Omega)||\varphi||_{\iota}$ , mais d'après le théorème de Soboleff, déjà utilisé au théorème 2. 1, il existe une constante  $S(\Omega)$  telle que pour tout  $\varphi$  dans  $\mathfrak{D}_{\Omega}$  on ait:

$$||\phi||_{L^q} \leqslant S(\Omega)||\phi||_1$$

(et ceci vaut pour  $\Omega$  borné ou non), d'où le théorème.

Ce théorème améliore le théorème 4. 2, si  $n \ge 3$ , (et si  $\Omega$  est borné), mais l'intérêt du théorème 4. 2 est qu'il est très élémentaire, alors que le théorème 4. 4 utilise le théorème de Soboleff.

Interprétons maintenant l'espace  $BL_0^{\bullet}(\Omega)$ ; l'application  $\varphi \to \varphi^{\bullet}$  de  $\mathfrak{D}_{\Omega}$  dans  $\mathfrak{D}_{\Omega}^{\bullet}$  définit par prolongement un isomorphisme de  $\widehat{\mathfrak{D}}^{\bullet}(\Omega)$  sur  $BL_0^{\bullet}(\Omega)$ , soit  $X \to X^{\bullet}$ , avec :  $||X^{\bullet}||_{\mathfrak{l}} = ||X||_{\mathfrak{l}}$ . On va en déduire le

Théorème 4. 5. —  $Si \ \widehat{\mathfrak{D}}^{\scriptscriptstyle 1}(\Omega)$  est un espace de distributions, toute distribution  $T \in BL(\Omega)$  admet une décomposition unique:

$$(4, 2) T = u + h,$$

où  $u \in \widehat{\mathfrak{D}}^{1}(\Omega)$ ,  $h \in \operatorname{BL}(\Omega)$  avec  $\Delta h = 0$ , et:

$$(4, 3) ||T||_{1}^{2} = ||u||_{1}^{2} + ||h||_{1}^{2}.$$

Démonstration. — On considère la classe T' définie dans  $\mathrm{BL}^{\:\raisebox{3.5pt}{\text{\circle*{1.5}}}}(\Omega)$  par T; par le théorème 4.1, T' se décompose de façon unique en :

$$T' = u' + h', \quad u' \in BL_0(\Omega), \quad \text{et} \quad h' \in \mathcal{H}'.$$

Soit alors u l'élément unique de  $\widehat{\mathfrak{D}}^{1}(\Omega)$ , d'image u dans l'isomorphisme de  $\widehat{\mathfrak{D}}^{1}(\Omega)$  sur  $\mathrm{BL}_{0}^{1}(\Omega)$ ; alors  $h=\mathrm{T}-u$  est dans h, donc  $\Delta h=0$ , d'où (4, 2). En outre  $||\mathrm{T}^{1}||_{1}^{2}=||u^{1}||_{1}^{2}+||h^{1}||_{1}^{2}$  donne (4, 3), d'où le théorème.

Remarque 4. 3. — Le théorème 4. 5 redonne, si  $n \ge 3$  et  $E = L^2(\Omega)$  le théorème 2. 1 en le précisant.

Remarque 4. 4. — Insistons dès maintenant sur l'intérêt de la formule (4. 3): on verra qu'en général les éléments de  $\widehat{\mathcal{D}}^{1}(\Omega)$ 

sont les fonctions de la classe  $\mathrm{BL}(\Omega)$  que l'on peut considérer comme « nulles » sur la frontière de  $\Omega$  (cf. chapitre 11, nº 5); la décomposition (4, 2) fournit alors la fonction harmonique h ( $\Delta h=0$ ) prenant sur la frontière de  $\Omega$  « les mêmes valeurs que T », ce qui résout le problème de Dirichlet. Cette résolution du problème de Dirichlet ne diffère d'ailleurs qu'en apparence de la résolution de Gårding (cf. Gårding [1]), du moins si  $\Omega$  est borné. Voir aussi Browder [1].

Remarque 4. 5. — On peut munir  $BL(\Omega)$  d'autres structures préhilbertiennes équivalentes à la structure  $(u, v)_i$ . Voici un exemple important : on donne des fonctions  $g_{ij}(i, j = 1, ..., n)$  sur  $\Omega$ , mesurables et essentiellement bornées, avec  $g_{ij} = \overline{g}_{ji}$  pour tout couple (i, j), et telles que, pour tout système de n nombres complexes  $\zeta_1, ..., \zeta_n$ , on ait

$$\sum_{i,j=1}^n g_{ij}(x)\zeta_j\overline{\zeta}_i \geqslant a|\zeta|^2,$$

avec a > 0, presque partout dans  $\Omega$ .

On pose alors, pour u et  $v \in BL(\Omega)$ :

$$(u, v)_g = \sum \int_{\Omega} g_{ij} \frac{\partial u}{\partial x_j} \frac{\overline{\partial v}}{\partial x_i} dx,$$

ce qui définit sur  $\mathrm{BL}(\Omega)$  une structure préhilbertienne équivalente à  $(u, \, v)_i$ . Dans ces conditions on a, sous les hypothèses du théorème 4. 5, la décomposition unique:  $T = u_i + h_i$ ,  $T \in \mathrm{BL}(\Omega)$ ,  $u_i \in \widehat{\mathfrak{D}}^i(\Omega)$ , et  $h_i \in \mathrm{BL}(\Omega)$  avec:  $\mathrm{D}h_i = 0$ , où, pour  $S \in \mathrm{BL}(\Omega)$ , on a:

$$DS = -\sum_{i,j=1}^{n} \frac{\partial}{\partial x_{i}} \left( g_{ij} \frac{\partial}{\partial x_{j}} S \right).$$

Cette décomposition résout le problème de Dirichlet relatif à l'opérateur elliptique D, à coefficients non continus. On peut encore généraliser:

- a) en remplaçant les  $g_{ij}$  par des éléments de  $\mathcal{L}(L^2, L^2)$ ; on obtient alors pour D un opérateur intégro-différentiel.
  - b) en prenant un opérateur D non auto-adjoint (cf. Lions [3]). Etude de la stabilité du problème de Dirichlet.

Lemme 4. 1. — Soit  $\Omega'$  un ouvert contenu dans  $\Omega$ . Si  $\widehat{\mathfrak{D}}^{\scriptscriptstyle{1}}(\Omega)$  est un espace de distributions sur  $\Omega$ , alors  $\widehat{\mathfrak{D}}^{\scriptscriptstyle{1}}(\Omega')$  est un espace

de distributions sur  $\Omega'$ . Il existe une application linéaire continue  $u \to \tilde{u}$  de  $\widehat{\mathfrak{D}}^{_1}(\Omega')$  dans  $\widehat{\mathfrak{D}}^{_1}(\Omega)$  telle que  $\tilde{u} = u$  dans  $\Omega'$  et  $\tilde{u} = 0$  dans  $\Omega'$ . On  $a: ||\tilde{u}||_1 = ||u||_1$ .

Démonstration. — Soit  $\varphi_k$  une suite de Cauchy dans  $\mathfrak{D}_{\Omega'}$  pour la norme  $||\varphi||_{\iota}$ . Soit de façon générale, si  $\varphi \in \mathfrak{D}_{\Omega'}$ ,  $\tilde{\varphi}$  la fonction de  $\mathfrak{D}_{\Omega}$  prolongée de  $\varphi$  par 0 hors de  $\Omega'$ . Alors  $\tilde{\varphi}_k$  est une suite de Cauchy dans  $\mathfrak{D}_{\Omega}$  pour  $||\varphi||_{\iota}$ , donc, par hypothèse, converge dans  $\mathfrak{D}'_{\Omega}$  vers T. Soit T' la restriction de T à  $\Omega'$ ; la suite  $\varphi_k$  tend vers T' dans  $\mathfrak{D}'_{\Omega}$ , donc  $\mathfrak{D}_{\Omega'}$ , muni de la topologie induite par  $\widehat{\mathfrak{D}}_{\iota}(\Omega')$ , a une topologie plus fine que la topologie induite par  $\mathfrak{D}'_{\Omega}$ , d'où la première partie du lemme (18).

En outre l'application  $\varphi \to \tilde{\varphi}$  est une isométrie de  $\mathfrak{D}_{\Omega'}$  muni de la topologie induite par  $\widehat{\mathfrak{D}}^1(\Omega')$  dans  $\mathfrak{D}_{\Omega}$  muni de la topologie induite par  $\widehat{\mathfrak{D}}^1(\Omega)$ , et se prolonge donc en l'isométrie  $u \to \tilde{u}$  de  $\widehat{\mathfrak{D}}^1(\Omega')$  dans  $\widehat{\mathfrak{D}}^1(\Omega)$ , d'où le lemme.

On va alors démontrer le

Théorème 4. 6. — Soit  $\Omega$  un ouvert de  $\mathbb{R}^n$  tel que  $\widehat{\mathfrak{D}}^1(\Omega)$  soit un espace de distributions sur  $\Omega$ . Soit  $\Omega_k$  une suite croissante d'ouverts contenus dans  $\Omega$ , de réunion  $\Omega$ . Soit  $T \in \operatorname{BL}(\Omega)$  que l'on décompose suivant (4, 2). Soit  $T_k$  la restriction de T à  $\Omega_k$  ( $\in \operatorname{BL}(\Omega_k)$ ) et soit:

(4, 4) 
$$T_k = u_k + h_k$$
,  $u_k \in \widehat{\mathfrak{D}}^1(\Omega_k), \Delta$   $h_k = 0$  dans  $\Omega_k$ ,

la décomposition canonique de  $T_k$ . Alors  $\tilde{u}_k$ , élément de  $\widehat{\mathfrak{D}}^1(\Omega)$  (défini comme au lemme 4. 1) tend vers u dans  $\widehat{\mathfrak{D}}^1(\Omega)$ .

Démonstration. — Soit  $\varphi \to (\tilde{\varphi})^*$  l'application canonique de  $\mathfrak{D}_{\Omega}$  dans  $\mathrm{BL}_0^*(\tilde{\varphi} = \mathrm{prolong\acute{e}e}\ \grave{a}\ \Omega$  par 0 hors de  $\Omega_k$ , et  $(\tilde{\varphi})^* = \mathrm{classe}$  de  $\tilde{\varphi}$  dans  $\mathrm{BL}^*(\Omega)$ ; on a:  $||\tilde{\varphi}||_i = ||\varphi||_i$  donc cette application se prolonge en une isométrie  $u \to \tilde{u}$  de  $\widehat{\mathfrak{D}}^*(\Omega_k)$  dans  $\mathrm{BL}_0^*(\Omega)$ . Soit  $\mathfrak{V}_k^*$  l'image de  $\widehat{\mathfrak{D}}^*(\Omega_k)$  dans cette isométrie, c'est un sous-espace vectoriel fermé de  $\mathrm{BL}_0^*(\Omega)$ , et:

$$\mathrm{BL}_{\scriptscriptstyle{0}}^{\scriptscriptstyle{\bullet}}(\Omega) = \big(\overline{\bigcup_{k} v_{k}^{\scriptscriptstyle{\bullet}}}\big).$$

(18) L'injection de  $\widehat{\mathfrak{D}}^{1}(\Omega)$  dans  $\widehat{\mathfrak{D}}'(\Omega)$  est biunivoque (voir note (16).

Soit alors T' l'image de T dans BL', et  $\nu_k$  la projection de T' sur  $\mathfrak{V}_k$ ; on a:

$$(4, 5) T' = \varphi_k' + f_k' ,$$

où  $f_k^*$  est dans l'espace orthogonal de  $\mathfrak{V}_k^*$ . On a donc :  $(f_k^*, \tilde{\varphi}^*)_1 = 0$  pour tout  $\varphi$  dans  $\mathfrak{D}_{\Omega_k}$ , et donc soit  $f_k$  quelconque dans la classe  $f_k^*$ , et soit  $g_k$  la restriction de  $f_k$  à  $\Omega_k$ ; on a :  $(g_k, \varphi)_1 = 0$  pour tout  $\varphi \in \mathfrak{D}_{\Omega_k}$ , donc  $\Delta g_k = 0$ , autrement dit :

$$(4, 6) \Delta f_k = 0 dans \Omega_k.$$

D'après la théorie élémentaire des projections dans un espace de Hilbert,  $\nu_k$ , projection de T' sur  $\mathfrak{V}_k$ , converge vers u, projection de T' sur  $\mathrm{BL}_0(\Omega) = \left(\overline{\bigcup_k \mathfrak{V}_k}\right) \mathrm{lorsque} k \to \infty$ , dans  $\mathrm{BL}^*(\Omega)$ .

Soit  $\widetilde{v}_k$  (resp. u) l'inverse de  $v_k^*$  (resp.  $u^*$ ) dans les isomorphismes canoniques de  $\widehat{\mathfrak{D}}^{\mathfrak{s}}(\Omega_k)$  sur  $\mathfrak{V}_k^*$  et  $\widehat{\mathfrak{D}}^{\mathfrak{s}}(\Omega)$  sur  $\mathrm{BL}_{\mathfrak{o}}^{\bullet}(\Omega)$ . On a donc (19):

(4, 7) 
$$\tilde{\nu}_k \rightarrow u$$
 dans  $\widehat{\mathfrak{D}}^i(\Omega)$  fort.

Or de (4, 5) et (4, 6) on déduit:

 $T_k = \tilde{\nu}_k + f_k$ ,  $\Delta f_k = 0$  dans  $\Omega_k$ , donc par restriction à  $\Omega_k$ :

 $T_k = \rho_k + \text{(restriction de } f_k)$ , et en vertu de l'unicité de la décomposition (4, 2), on a :  $u_k = \rho_k$ , de sorte que (4, 7) démontre le théorème.

Théorème sur la partie harmonique d'une fonction  $BL(\Omega)$ . — On va maintenant démontrer le

Théorème 4. 7. — Soit  $\Omega$  un ouvert de  $\mathbb{R}^n$ , n quelconque, tel que  $\widehat{\mathfrak{D}}^1(\Omega)$  soit un espace de distributions sur  $\Omega$ . Soit T donné dans  $\mathrm{BL}(\Omega)$ , à valeurs réelles et positives (presque partout). On décompose T suivant (4,2). Alors h (partie harmonique de T) est positive dans  $\Omega(^{20})$ .

(19) Soit  $u \to u^{\bullet}$  l'isomorphisme canonique de  $\widehat{\mathfrak{D}}^{1}(\Omega)$  sur  $\mathrm{BL}_{0}^{\bullet}(\Omega)$ . Cet isomorphisme applique  $\widehat{\widehat{\mathfrak{D}}^{1}}(\Omega_{\mathbf{K}})$  (image de  $\widehat{\mathfrak{D}}^{1}(\Omega_{\mathbf{K}})$ ) sur  $\mathfrak{V}_{\mathbf{K}}^{\bullet}$ .

<sup>(20)</sup> Etant donné qu'on ne sait rien pour l'instant sur le comportement des fonctions T, u, h, à la frontière, et que d'autre part il n'est fait aucune hypothèse sur cette frontière (puisque  $\widehat{\Omega}^1(\Omega)$  est par exemple un espace de distributions sur un ouvert  $\Omega$  quelconque de  $\mathbb{R}^n$  si  $n \geq 3$ ), ce théorème n'est pas évident.

Démonstration. — a) Supposons T continue dans  $\Omega$  (et même indéfiniment différentiable, si l'on veut).

Soit  $\Omega_k$  une suite croissante d'ouverts relativement compacts, contenus dans  $\Omega$ , de réunion  $\Omega$ , chaque  $\Omega_k$  ayant en outre une frontière régulière (par exemple, les  $\Omega_k$  sont des réunions de cubes de côtés de plus en plus petits, et contenus dans l'intersection de  $\Omega$  avec des boules de rayon  $R \to \infty$ ).

Soit encore  $T_k$  la restriction de T à  $\Omega_k$ . On effectue la décomposition canonique de  $T_k$  dans  $\Omega_k$ :  $T_k = u_k + h_k$ . La fonction  $h_k$ , harmonique dans  $\Omega_k$ , est la solution du problème de Dirichlet au sens classique, pour la donnée frontière continue  $T_k$ , de sorte que le principe du maximum sous sa forme élémentaire donne:

$$h_k \geqslant 0$$
 dans  $\Omega_k$ .

Or, par le théorème 4.6,  $\tilde{u}_k \to u$  dans  $\widehat{\mathfrak{D}}^1(\Omega)$ ;  $T_k$  est dans  $L^2(\Omega)$ , on peut donc considérer  $\tilde{T}_k$ , élément de  $L^2(\Omega)$ , et  $\tilde{h}_k = \tilde{T}_k - \tilde{u}_k$  (prolongement par 0 hors de  $\Omega_k$ ) tend donc vers h = T - u dans  $\mathfrak{D}'_{\Omega}$ ; comme  $\tilde{h}_k$  est  $\geqslant 0$  pour tout k, on  $a: k \geqslant 0$  dans  $\Omega$ , d'où le théorème dans ce cas.

b) Soit maintenant T quelconque dans  $BL(\Omega)$  (à valeurs  $\geqslant 0$ ). On approche T par une suite  $T^{\alpha}$  de fonctions de  $BL(\Omega)$ , continues (ou même indéfiniment différentiables) dans  $\Omega$ ,  $\geqslant 0$ , avec  $T^{\alpha} \rightarrow T$  dans  $\mathfrak{D}'_{\Omega}(^{21})$ . On décompose canoniquement  $T^{\alpha}$ ; sa partie harmonique  $h^{\alpha}$  est d'après le a), positive :  $h^{\alpha} \geqslant 0$ .

Or  $(T^{\alpha}) \to T$  dans  $BL^{\bullet}(\Omega)$ , donc  $(u^{\alpha}) \to u$ , donc  $u^{\alpha} \to u$  dans  $\widehat{\mathfrak{D}}^{\bullet}(\Omega)$ , et donc  $h^{\alpha} \to h$  dans  $\mathfrak{D}'_{\Omega}$ , d'où le théorème.

5. Ouverts de Soboleff et de Nikodym. — On se borne pour simplifier au cas  $n \geqslant 3$ .

Comme on a déjà remarqué (note (11) un problème naturel à partir du théorème 2. 1 est le suivant : soit T donnée dans  $BL(\Omega)$ ; pour quels ouverts  $\Omega$ , T est-elle dans  $L^q(\Omega)$ ? Si  $\Omega$  est de mesure infinie, les constantes, qui sont dans  $BL(\Omega)$  ne sont pas dans  $L^q(\Omega)$ ; il faut modifier la question comme suit : pour quels ouverts  $\Omega$  existe-t-il une constante C(T) dépendant de T telle que T + C(T) soit dans  $L^q(\Omega)$ ? La réponse est

<sup>(21)</sup> Il est clair que c'est possible; on utilise à cet effet le procédé du théorème 2. 3.

affirmative si  $\Omega = \mathbb{R}^n$ , et peut être négative (22) sur certains ouverts. On est donc conduit à poser les définitions suivantes (cf. Lions, [2]):

DÉFINITION 5. 1. — Soit  $\Omega$  un ouvert connexe de  $\mathbb{R}^n$ ,  $n \geq 3$ . On dira que  $\Omega$  est un ouvert de Soboleff (en abrégé, ouvert (S)) si pour toute distribution T de  $\mathrm{BL}(\Omega)$ , T est dans  $\mathrm{L}^q(\Omega)$  si  $\Omega$  est de mesure finie, ou s'il existe une constante  $\mathrm{C}(T)$  telle que  $\mathrm{T} + \mathrm{C}(T)$  soit dans  $\mathrm{L}^q(\Omega)$  si  $\Omega$  est de mesure infinie, q étant donné par : 1/q = 1/2 - 1/n.

Avant de donner des exemples d'ouverts de Soboleff (cf. Nº 6) donnons des inégalités intéressantes auxquelles ils donnent lieu.

Théorème 5. 1. — La condition nécessaire et suffisante pour qu'un ouvert  $\Omega$  connexe de mesure finie, soit un ouvert de Soboleff est qu'il existe une constante  $S(\Omega)$  ne dépendant que de  $\Omega$ , telle que, pour tout u dans  $\mathcal{E}_{q,2}^{\epsilon}(\Omega)$  (définition 4. 3) on ait:

$$(5, 1) \quad \text{inf.} ||u+c||_{\mathbb{L}^q} \leqslant \mathrm{S}(\Omega)||u||_{\scriptscriptstyle 1}, \quad c = \text{constante.}$$

Démonstration. — a) La condition est nécessaire.

Considérons l'espace de Banach  $(\mathcal{E}_{q,2}^{\bullet}(\Omega))^{\bullet}$  quotient de  $\mathcal{E}_{q,2}^{\bullet}(\Omega)$  par le sous-espace des constantes  $(\Omega$  étant de mesure finie, les constantes non nulles sont dans  $\mathcal{E}_{q,2}^{\bullet}(\Omega)$ ). La norme quotient est

$$||u^{\cdot}|| = \inf_{c} ||u + c||_{L^{q}} + ||u||_{1}, \quad u^{\cdot} = \{u + c\}.$$

Considérons alors l'application identique:

(5, 2) 
$$u \rightarrow u$$
 de  $(\mathcal{E}_{q,2}(\Omega))$  dans  $BL^{\bullet}(\Omega)$ .

Cette application est linéaire continue biunivoque, et,  $\Omega$  étant un ouvert Soboleff, elle est sur; c'est donc un isomorphisme d'après le théorème de Banach (cf. Bourbaki [1]), d'où l'on déduit l'inégalité (5, 1).

b) La condition est suffisante.

Supposons donc que (5, 1) ait lieu, et considérons l'application identique (5, 2). Tout revient à montrer que cette application est *sur*. Or (5, 1) entraîne que l'image de  $(\mathcal{E}_{q,2}^1(\Omega))$  dans

<sup>(22)</sup> Voir Courant-Hilbert [1], Chap. vii, § 8, No 2, et Nikodym, [1].

BL'( $\Omega$ ) est fermée. Il suffit donc de montrer que l'image de  $(\mathcal{E}_{q,2}^i)$  est dense dans BL'( $\Omega$ ). Or soit u dans BL( $\Omega$ ); il suffit de montrer qu'il existe une suite  $u_k$  de fonctions de  $\mathcal{E}_{q,2}^i(\Omega)$  telles que  $||u_k - u||_i \to 0$ . On se ramène au cas où u est une fonction à valeurs réelles; on prend alors:

$$u_k(x) = u(x)$$
 si  $|u(x)| \leq k$ ,  
  $k$  si  $u(x) > k$ ,  $-k$  si  $u(x) < -k$ .

On a alors le résultat d'après la proposition 3. 1.

Théorème 5. 2. — Si  $\Omega$  est un ouvert de Soboleff de mesure infinie, il existe une constante  $S'(\Omega)$  ne dépendant que de  $\Omega$ , telle que, pour tout u dans  $\mathcal{E}_{q,2}^{\dagger}(\Omega)$  on ait:

$$(5, 3) ||u||_{\mathbf{L}^q} \leqslant S'(\Omega)||u||_{\iota}.$$

Démonstration. — On considère cette fois l'application

(5, 4) 
$$u \rightarrow u$$
 de  $\mathcal{E}_{q,2}^{1}(\Omega)$  dans  $BL^{\bullet}(\Omega)$ ,

qui à u dans  $\mathcal{E}_{q,2}^1(\Omega)$  fait correspondre la classe  $\{u+c\}$ . Cette application est linéaire continue, biunivoque (car  $\Omega$  est de mesure infinie) et sur (car  $\Omega$  est un ouvert de Soboleff), donc par le théorème de Banach déjà cité, c'est un isomorphisme, d'où le théorème.

Problème non résolu. — Nous ignorons si, réciproquement, un ouvert connexe de mesure infinie, donnant lieu à (5, 3), est un ouvert de Soboleff. La question se ramène à ceci : l'image de  $\mathcal{E}_{q,2}^{\mathsf{t}}(\Omega)$  par (5, 4) est-elle dense dans  $\mathrm{BL}^{\bullet}(\Omega)$ ?

Dans le cas des ouverts  $\Omega$  de mesure finie, une notion utile moins restrictive que celle d'ouvert de Soboleff est la suivante :

DÉFINITION 5. 2. — Un ouvert  $\Omega$  connexe de mesure finie est dit ouvert de Nikodym si toute distribution T de BL  $(\Omega)$  est dans  $L^2(\Omega)$ .

Il est évident qu'un ouvert de Soboleff de mesure finie est un ouvert de Nikodym; la réciproque peut être inexacte.

Au sujet des ouverts de Nikodym on a le

Théorème 5. 3. — La condition nécessaire et suffisante pour qu'un ouvert  $\Omega$  connexe de mesure finie soit un ouvert de

Nikodym est qu'il existe une constante  $P(\Omega)$  telle que pour tout u dans  $\mathcal{E}_{L^{z}}^{1}(\Omega)$  (23) on ait:

$$(5, 5) \qquad ||u||_{L^2}^2 - \frac{1}{\operatorname{mes}(\Omega)} \left| \int_{\Omega} u(x) \, dx \right|^2 \leqslant P(\Omega) ||u||_{L^2}^2 (24).$$

Démonstration. — On opère comme pour le théorème 5. 1, en remplaçant  $(\mathcal{E}_{q,2}^{1}(\Omega))$  par  $(\mathcal{E}_{L_{2}}^{1}(\Omega))$ , le carré de la norme sur cet espace étant donné par:

$$||u^{\bullet}||^{2} = ||u||_{\mathrm{L}^{2}}^{2} - \frac{1}{\mathrm{mes}(\Omega)} \left| \int_{\Omega} u(x) \, dx \right|^{2} + ||u||_{1}^{2}$$

d'où le théorème.

Définition 5. 5. — L'inégalité (5, 5) est dite: inégalité de Poincaré (25). La meilleure constante possible dans (5, 5) est dite la constante de Poincaré de Ω. On en donnera plus loin une interprétation. D'après le théorème 5. 5, l'inégalité de Poincaré caractérise les ouverts de Nikodym.

6. Exemples d'ouverts de Soboleff et de Nykodym. — Donnons maintenant un exemple d'ouvert de Soboleff; la démonstration ci-après est adaptée de Soboleff [1]. On considère un ouvert  $\Omega$  connexe borné de frontière  $\Omega^*$ . On désigne par  $\Omega_{\varepsilon}$  l'ensemble des  $x \in \Omega$ , à distance  $< \varepsilon$  de  $\Omega^*$ . On considère une fois pour toutes le secteur conique C(O) que voici : on rapporte l'espace  $R^n(n \geqslant 3)$  (coordonnées  $x_1, \ldots, x_n$ ) à un système de coordonnées polaires (r, 0),  $\theta = (\theta_1, \ldots, \theta_{n-1})$ ; C(O) est l'ensemble des (r, 0) avec :  $0 < r \leqslant a$  et  $\theta_i \in [0, \alpha_i]$  où  $0 < \alpha_i < \pi$ ; on désigne par  $C_1(O)$  la portion  $a/3 \leqslant r \leqslant 2a/3$  de C(O).

Hypothèse (H). — On dira que l'ouvert  $\Omega$  vérifie (H) lorsque les conditions suivantes ont lieu: pour tout  $x \in \Omega$  on peut placer dans  $\Omega$  un secteur C(x) égal à C(O), de sommet x, dans une orientation arbitraire (C(x) est déduit de C(O) par un déplacement quelconque). On désigne par  $C_1(x)$  la portion

<sup>(23)</sup> Cet espace est défini p. 318.

<sup>(24)</sup> mes  $(\Omega)$  = mesure de  $\Omega$ . De façon générale il semble plus facile de montrer directement qu'un ouvert  $\Omega$  est un ouvert de Soboleff ou de Nikodym et d'en *déduire* les inégalités (5, 1) (5, 2) et (5, 3), que de démontrer directement ces inégalités. L'inconvénient est que ce procédé ne donne aucune évaluation des constantes  $S(\Omega)$  et  $P(\Omega)$ ; pour cette dernière quantité, voir toutefois le N° 10.

<sup>(25)</sup> Voir Poincaré [1], Courant-Hilbert [1]. On trouve des variantes de cette inégalité dans Friedrichs [1].

de C(x) correspondant à  $C_1(O)$ . On suppose que lorsque x parcourt  $\Omega$  on peut choisir les C(x) et  $\varepsilon > 0$  de sorte que  $C_1(x)$  demeure dans  $\Omega_{\varepsilon}$ .

Il est clair que tout ouvert suffisamment « régulier » vérifie (H). Il en est ainsi des ouverts bornés limités par un nombre fini de surfaces à courbure bornée, ou domaines de De La Vallée Poussin; ils sont définis par la propriété suivante : il existe un nombre  $\rho > 0$  tel qu'à tout point frontière x on peut associer deux boules ouvertes de rayon  $\rho$ , tangentes en x, l'une étant intérieure et l'autre extérieure à  $\Omega$ .

Théorème 6. 1. — Si  $\Omega$  est un ouvert connexe borné qui vérifie (H), dans  $\mathbb{R}^n$ ,  $n \geqslant 3$ , c'est un ouvert de Soboleff.

Démonstration. — Soit  $\Omega$  vérifiant (H); on supposera a=1 (ce qui est loisible en faisant une homothétie).

Soit  $F \in BL(\Omega)$ ; on peut la décomposer suivant (4,2) (Théorème 4. 5) comme suit: F = f + g,  $f \in BL(\Omega)$ ,  $\Delta f = 0$ , et  $g \in \widehat{\mathfrak{D}}^1(\Omega)$ . Par le théorème 4. 4, la fonction g est dans  $L^q(\Omega)$ ; on veut montrer que  $F \in L^q(\Omega)$ ; on est donc ramené à montrer que f est dans  $L^q(\Omega)$  si  $f \in BL(\Omega)$  et est indéfiniment différentiable dans  $\Omega$  (on peut supposer aussi f harmonique, mais ceci ne nous servira pas  $\binom{26}{3}$ ).

Considérons pour un  $x \in \Omega$  donné, le secteur C(x); soit y un point de C(x); on pose: r = |y - x|; on désigne par  $(r, \theta)$  les coordonnées polaires de  $R^n$ , l'origine étant x; lorsque y parcourt C(x), alors r parcourt [0, 1], et  $\theta_i$  parcourt  $[\beta_i, \gamma_i]$ , avec  $\gamma_i - \beta_i = \alpha_i$ .

On prend une fois pour toutes une fonction  $r \to a(r)$ , indéfiniment différentiable dans [0, 1], = 1 dans [0,1/3], = 0 dans [2/3,1].

Exprimons f(y) dans le système de coordonnées  $(r, \theta)$ :  $f(y) = F(r, \theta)$ . On a :  $F(0, \theta) = f(x)$ , d'où :

(6, 1) 
$$f(x) = -\int_0^1 \frac{d}{dr} (a(r) F(r, \theta)) dr.$$

(26) L'usage fait ici de la décomposition canonique (4, 2) est commode mais un peu artificiel. On peut prendre à priori f dans  $BL(\Omega)$  indéfiniment différentiable; on effectue les majorations qui suivent; on passe alors au cas général en utilisant le théorème de densité 2. 3. De cette façon il n'est pas fait usage de la structure hilbertienne de  $BL^0(\Omega)$ , ce qui permet des généralisations utiles.

L'élément de volume dy vaut :

 $dy = r^{n-1} s(\theta) dr \cdot d\theta$ ,  $s(\theta)$  fonction continue bornée de  $\theta$ .

Multiplions les 2 membres de (6,1) par  $s(\theta)$   $d\theta$  et intégrons en  $\theta$ ,  $\theta_i \in [\beta_i, \gamma_i]$ :

$$\int f(x) s(\theta) d\theta = c_1 f(x) = - \int_{C(x)} \frac{d}{dr} (a(r) F(r, \theta)) r^{1-n} dy.$$

(on désigne par c<sub>1</sub>, c<sub>2</sub>, ... des constantes diverses)

Or, calculé au point y,  $\frac{d}{dr}(a(r) F(r, \theta))$  vaut:

$$\frac{d}{dr}(a(r)F(r, \theta)) = a'(r)f(y) + \sum_{i=1}^{n} a_i(y)\frac{\partial}{\partial y_i}f(y),$$

où a' est la dérivée de a (donc nulle hors de [1/3, 2/3]) et où les  $a_i$  sont des fonctions bornées continues. Donc :

$$f(x) = c_2 \int_{G_1(x)} a'(r) f(y) \frac{1}{|x - y|^{n-1}} dy + c_2 \sum_{i=1}^n \int_{G(x)} a_i(y) \frac{\delta}{\delta y_i} f(y) \frac{1}{|x - y|^{n-1}} dy$$

d'où:

(6, 2) 
$$|f(x)| \leq c_3 h(x) + c_4 \sum_{i=1}^n k_i(x)$$

avec

$$\begin{split} h(x) &= \int |f(y)| \frac{1}{|x-y|^{n-1}} dy, \quad 1/3 \leqslant |x-y| \leqslant 2/3, \quad y \in \Omega_{\varepsilon}, \\ k_i(x) &= \int \left| \frac{\delta}{\delta u_i} f(y) \right| \frac{1}{|x-y|^{n-1}} dy, \quad |x-y| \leqslant 1, \quad y \in \Omega. \end{split}$$

Soit  $\chi_1$  (resp.  $\chi_2$ ) la fonction caractéristique de  $1/3 \leqslant |x| \leqslant 2/3$  (resp. de  $|x| \leqslant 1$ ). Soit  $|\tilde{f}_{\varepsilon}|$  la fonction définie dans  $R^n$  égale à |f| dans  $\Omega_{\varepsilon}$ , à 0 ailleurs; cette fonction est dans  $L^q(R^n)$ , et on peut écrire:

$$h = \frac{\chi_1}{|x|^{n-1}} * |\tilde{f}_{\varepsilon}|.$$

Comme  $\chi_i |x|^{i-n}$  est sommable, on voit que h est dans  $L^q(\mathbb{R}^n)$ . De même soit  $g_i$  la fonction définie dans  $\mathbb{R}^n$ , égale à  $\left|\frac{\partial}{\partial x_i}f\right|$ 

dans  $\Omega$ , 0 ailleurs; cette fonction est dans  $L^2(\mathbb{R}^n)$ ; on peut écrire:

$$k_i = \frac{\chi_2}{|x|^{n-1}} * g_i,$$

et il résulte du lemme de Soboleff que cette fonction est dans  $L^q(\mathbb{R}^n)$ . Donc f est une fonction indéfiniment différentiable dans  $\Omega$ , majorée (à l'aide de (6, 1) par une fonction appartenant à  $L^q(\Omega)$ , donc f est dans  $L^q(\Omega)$  ce qui démontre le théorème.

Remarque 6. 1. — On peut améliorer le théorème 6. 1 dans le sens suivant : on suppose Ω non borné, et on suppose avoir trouvé  $\Omega_{\varepsilon}$  (défini comme précédemment) tel que pour toute  $T \in BL(\Omega)$  on puisse trouver une constante C telle que T + Csoit dans  $L^q(\Omega_s)$ . On suppose ensuite que l'hypothèse (H) a lieu (ce qui est indépendant de Ω borné ou non). Dans ces conditions  $\Omega$  est un ouvert de Soboleff. En effet soit  $T \in BL^{\bullet}(\Omega)$ ; on choisit le représentant F de la classe T' qui est dans  $L^q(\Omega_s)$ ; on décompose F comme ci-dessus: F = f + g; comme g est dans  $L^q(\Omega)$ , on voit que f est dans  $L^q(\Omega_{\epsilon})$  et on termine comme précédemment. Exemple:  $\Omega = \text{complémentaire d'un compact}$ K;  $\Omega_{\varepsilon}$  = ensemble des x à distance  $> \varepsilon$  de  $\Omega^*$ , l'hypothèse (H) ayant lieu. Soit  $a \in \mathcal{E}_{\Omega}$ , = 1 sur  $\Omega_{\epsilon}$ , nulle au voisinage de  $\Omega^{*}$ . Soit  $T \in BL(\Omega)$ , posons S = aT. Comme  $\frac{\partial}{\partial x_i}a$  est à support compact dans  $\Omega$ , et comme T est dans Lq sur tout compact (en particulier dans L<sup>2</sup> sur tout compact) la distribution S est dans BL(Ω), et peut être considérée comme élément de BL(R<sup>n</sup>); comme R<sup>n</sup> est un ouvert de Soboleff on peut trouver C constante de sorte que  $S + C \in L^q(\mathbb{R}^n)$ , donc  $\hat{T} + C \in L^q(\Omega_{\varepsilon})$ . L'ouvert considéré est de type (S) (27).

Remarque 6. 2. — Il est souvent beaucoup plus élémentaire de donner des exemples d'ouverts de Nikodym que des ouverts (S). Exemple:

Théorème 6. 2. — Soit Ω un ouvert borné, étoilé par rapport

(27) Il est bon de donner le contre-exemple suivant : dans R³ la bande  $0 < x_3 < 1$  n'est pas un ouvert de Soboleff. On prend en effet :  $F = \frac{1}{(1+x_1^2+x_2^2)^{\alpha}}$ ,  $0 < \alpha < 1/6$ . Cette fonction est dans BL( $\Omega$ ), n'appartient pas à L<sup>q</sup>( $\Omega$ ), et est nulle à l'infini; il n'existe donc pas de constante c telle que  $F + c \in L^q$ .

à l'origine de R<sup>n</sup>; c'est un ouvert de Nikodym. (Étoilé par rapport à l'origine signifie :  $t\Omega \subset \Omega$  pour tout t < 1; évidemment le résultat vaut pour  $\Omega$  borné étoilé par rapport à l'un quelconque de ses points)

Démonstration. — Soit  $F \in BL(\Omega)$ ; on la décompose canoniquement en :

$$F = f + g$$
,  $f \in BL(\Omega)$  avec  $\Delta f = 0$ , et  $g \in \widehat{\mathfrak{D}}^{1}(\Omega)$ .

Comme g est dans  $L^2(\Omega)$ , on est donc ramené à montrer que si f, indéfiniment différentiable, est dans  $BL(\Omega)$ , alors elle est dans  $L^2(\Omega)$ . Or prenons  $t_0 < 1$  assez petit pour que  $t_0\overline{\Omega} \subset \Omega$ . On peut écrire :

$$f(x) = f(t_0 x) + \int_{t_0}^1 \frac{d}{dt} (f(tx)) dt$$
soit: 
$$f(x) = f(t_0 x) + \sum_{i=1}^n \int_{t_0}^1 x_i \frac{\delta}{\delta x_i} f(tx) dt$$
d'où: 
$$|f(x)|^2 \leqslant c_1 \left( |f(t_0 x)|^2 + \sum_{i=1}^n \int_{t_0}^1 \left| \frac{\delta}{\delta x_i} f(tx) \right|^2 dt \right).$$

Soit  $\epsilon > 0$  fixé quelconque et  $\Omega_{\epsilon}$  l'ensemble des points de  $\Omega$  à distance  $> \epsilon$  de  $\Omega^*$ . Intégrons l'inégalité ci-dessus sur  $\Omega_{\epsilon}$ ; on a:

 $\int_{\Omega_{\epsilon}} |f(t_0x)|^2 dx = t_0^{-n} \int_{\Omega} |f(y)|^2 dy;$ 

comme  $\overline{t_0}\Omega_{\varepsilon} \subset t_0\Omega \subset \Omega$  ceci est majoré par une constante indépendante de ε. Résultat analogue pour  $\int_{\Omega_{\varepsilon}} dx \int_{t_0}^{t} \left| \frac{\partial}{\partial x_i} f(tx) \right|^2 dt$ ; donc  $\int_{\Omega_{\varepsilon}} |f(x)|^2 dx$  est majorée par une constante indépendante de ε d'où le résultat.

7. Prolongement des distributions  $BL(\Omega)$  sur la frontière de  $\Omega$ . — On veut définir, dans un sens raisonnable, un prolongement des distributions  $T \in BL(\Omega)$  sur la frontière  $\Gamma$  de  $\Omega$ . On suppose pour cela que la frontière de  $\Omega$  est assez « régulière ». On peut donc déjà supposer que l'hypothèse suivante a lieu :

(7, 1) 
$$\Omega$$
 est un ouvert de Soboleff,  $n \geqslant 3 - {28 \choose 2}$ .

<sup>(28)</sup> Si n=2, on pourra supposer que  $\Omega$  est un ouvert de Nikodym au voisinage de chaque point de sa frontière. On est ramené (localement) à prolonger les fonctions de  $\mathcal{E}_{1,2}(\Omega)$ .

Il s'agit alors d'effectuer le prolongement sur  $\Gamma$  des fonctions de l'espace  $\mathcal{E}_{q,2}^1(\Omega)$ .

On introduit les notations suivantes : si  $x = (x_1, ..., x_n)$  est le point générique de  $\mathbb{R}^n$ , on pose :

$$x^* = (x_1, \ldots, x_{n-1}), \quad x = (x^*, x_n), dx = dx^* dx_n, \quad dx^* = dx_1 \ldots dx_{n-1}.$$

On pose ensuite:

(7, 2) 
$$\begin{cases} W = \text{ensemble des } x \text{ avec } |x^*| < 1, |x_n| < 1, \\ W_+ = \text{ensemble des } x \in W, \text{ avec } x_n > 0, W_0 \text{ ensemble des } x \in W \text{ avec } x_n = 0. \end{cases}$$

On fait maintenant sur  $\Omega$  l'hypothèse suivante :

Pour tout  $a \in \Gamma$ , il existe un voisinage U(a) de a dans  $R^n$  et une application  $x \to A(x) = (A_i(x))$  de W dans U(a) qui est biunivoque, sur, une fois continuement différentiable, d'inverse  $x \to A^{-1}(x) = B(x) = (B_i(x))$  ayant les mêmes propriétés, les fonctions  $A_i$  et  $B_i$  ayant des dérivées d'ordre 1 bornées, et de sorte que  $U(a) \cap \Omega$  (resp.  $U(a) \cap \Gamma$ ) soit l'image de  $W_+$  (resp.  $W_0$ ).

On suppose enfin:

(Pr. 2)  $\begin{cases} \text{Il existe un recouvrement de } \Gamma \text{ par des } U(a_i), \\ \text{qui est localement fini, } i. e. \text{ tout compact de } \mathbb{R}^n \\ \text{rencontre seulement un nombre fini de } U(a_i). \end{cases}$ 

On pose:

$$(7, 3) q^* = 2 \frac{n-1}{n-2}.$$

Soit s le point générique de  $\Gamma$ , ds la mesure superficielle. On désigne par  $L^{q*}_{loc}(\Gamma)$  l'espace des fonctions sur  $\Gamma$  qui sont localement de puissance  $q^*$  intégrable, avec la topologie habituelle. Ceci posé on a le

Théorème 7. 1. — On suppose que  $\Omega$  est un ouvert de Soboleff et que les hypothèses (Pr 1), (Pr 2) ont lieu. Alors il existe une application linéaire continue et une seule,  $u \to \gamma u$ , de  $\mathcal{E}_{q,2}^1(\Omega)$  dans l'espace  $L_{loc}^{q*}(\Gamma)$ , telle que  $\gamma u$  coïncide avec la valeur de u sur  $\Gamma$  si u est continue dans  $\Omega$ .

Démonstration.

- 1. Notons tout de suite que l'unicité est évidente. En effet, on peut supposer  $\Omega$  borné; alors pour toute  $u\varepsilon \mathcal{E}_{q,2}^1$   $(\Omega)$  il existe une suite  $u_k$  de fonctions continues dans  $\overline{\Omega}$ , tendant vers u dans  $\mathcal{E}_{q,2}^1(\Omega)$ , d'où l'unicité.
- 2. Prenons un recouvrement  $U(a_i)$ . Soit U' un ouvert  $\subset \Omega$ , tel que les  $U(a_i)$  et U' recouvrent  $\Omega$  (on prend U' avec  $U' \subset \Omega$ ). On construit alors des fonctions  $F_i$ , F', ayant les propriétés suivantes :

(7, 4) 
$$\begin{cases} F' \in \mathcal{E}_{\Omega}, \text{ de support dans } U', \\ F_i \in \mathcal{D}_{\mathbb{R}^n}, \text{ de support dans } U(a_i), 0 \leqslant F \leqslant 1 \text{ partout,} \\ F'(x) + \sum_i F_i(x) = 1 \text{ si } x \in \Omega. \end{cases}$$

On désigne par f' et  $f_i$  les restrictions à  $\Omega$  des fonctions F' et  $F_i$ . Soit u dans  $\mathcal{E}^i_{q,2}(\Omega)$ . On peut écrire :

$$(7, 5) u = f'u + \sum f_i u.$$

La fonction f'u est nulle au voisinage de  $\Gamma$ , et  $f_iu$  est dans l'espace  $\mathcal{E}_{q,2}^1(U(a_i) \cap \Omega)$ .

Supposons que l'on montre ceci:

(7, 6)  $\begin{cases} \text{Pour tout } i, \text{ il existe une application linéaire} \\ \text{continue (et une seule) de } \mathcal{E}_{q,2}^{i}(\mathrm{U}(a_i) \cap \Omega) \text{ dans} \\ \mathrm{L}^{q^*}(\mathrm{U}(a_i) \cap \Gamma), \text{ soit } u \to \gamma_i u, \text{ coïncidant avec le} \\ \text{prolongement par continuité sur } \Gamma \text{ si } u \text{ est} \\ \text{continue dans } \overline{\mathrm{U}(a_i) \cap \Omega}. \end{cases}$ 

On aura le théorème. En effet, posons :

$$(7, 7) \gamma u = \Sigma \gamma_i(f_i u).$$

La somme a un sens (car le recouvrement  $U(a_i)$  est localement fini) et converge dans  $L^{q*}_{loc}(\Gamma)$ . L'application  $u \to \gamma u$  est continue, on a le théorème. Reste donc à montrer (7, 6).

3. Or grâce à (Pr 1), les fonctions de  $\mathcal{E}_{q,2}^1(U(a) \cap \Omega)$  (on supprime l'indice i dans  $a_i$ ) correspondent biunivoquement et bicontinûment aux fonctions de  $\mathcal{E}_{q,2}^1(W_+)$  (29).

(29) En effet: soit 
$$\varphi \in \mathcal{E}_{q, 2}^{1}(W_{+}) \cap \mathcal{E}$$
, et soit: 
$$\varphi_{1}(x) = \varphi(A^{-1}(x)), \qquad x \in U(a) \cap \Omega.$$

On définit ainsi une fonction une fois continuement différentiable dans  $U(a) \cap \Omega$ , et grâce aux hypothèses faites sur les fonctions  $A_i$  et  $B_i$ , l'application  $\varphi \to \varphi_1$  est continue pour les topologies induites par  $\mathcal{E}^1_{q,2}(W_+)$  et  $\mathcal{E}^1_{q,2}(U(a) \cap \Omega)$ . Comme d'après

Soit alors u dans  $\mathcal{E}_{q,2}^1(W_+)$ . Elle définit une fonction de  $\mathcal{E}_{q,2}^1(W)$ , soit  $\tilde{u}$ , par:

(7, 8) 
$$\tilde{u}(x) = \begin{cases} u(x) & \text{si } x \in W_+ \\ u(x^*, -x_n) & \text{si } x \in W, x_n < 0. \end{cases}$$

Or l'espace F des fonctions de  $\mathcal{E}_{q,2}^1(W)$  qui sont indéfiniment différentiables dans W, est dense dans  $\mathcal{E}_{q,2}^1(W)$ . Si  $\varphi$  est dans F, on a la majoration:

(7, 9) 
$$\int_{\mathbf{w}_0} |\varphi(x^*, 0)|^{q^*} dx^* \leqslant C||\varphi||_{L^q(\mathbf{w})}^{q/2} [||\varphi||_{1, \mathbf{w}} + ||\varphi||_{0}],$$

$$c = \text{constante}.$$

On part pour cela de:

$$|\varphi(x^*, 0)|^{2\alpha} = -\int_0^1 \frac{d}{dt} \left[ (1-t)|\varphi(x^*, t)|^{2\alpha} \right] dt,$$

et l'on prend  $2\alpha = (q+2)/2 = q^*$ .

Désignons par  $\omega(\varphi)$  la fonction  $x^* \to \varphi(x^*, 0)$ ; (7, 9) montre que l'application  $\varphi \to \omega(\varphi)$  est linéaire continue de  $\mathcal{E}_{q,2}^i(W)$  dans  $L^{q^*}(W_0)$ , et comme F est dense, cette application se prolonge en  $v \to \omega(v)$ , continue de  $\mathcal{E}_{q,2}^i(W)$  dans  $L^{q^*}(W_0)$ , et finalement on a obtenu une application:

$$(7, 10) u \rightarrow w(u)$$

linéaire continue de  $\mathcal{E}_{q,2}^{i}(W_{+})$  dans  $L^{r}(W_{0})$ , coı̈ncidant avec le prolongement par continuité pour les fonctions continues dans  $\overline{W}_{+}$ .

Comme  $\mathcal{E}_{q,2}^{i}(W_{+})$  (resp.  $L^{q^{*}}(W_{0})$ ) est isomorphe à l'espace  $\mathcal{E}_{q,2}^{i}(U(a) \cap \Omega)$  (resp.  $L^{q^{*}}(U(a) \cap \Gamma)$  (à l'aide des A, A<sup>-1</sup>), à l'application  $\mathscr{W}$  correspond une application  $\gamma = \gamma_{i}$  donnant lieu à (7,6), ce qui achève la démonstration du théorème (30).

Remarque 7. 1. — L'application  $\gamma$  est dans et non sur.

la note (17), l'espace  $\mathcal{E} \cap \mathcal{E}_{q,2}^1(W_+)$  est dense dans  $\mathcal{E}_{q,2}^1(W_+)$ , cette application se prolonge en une application  $u \to u_1$  de  $\mathcal{E}_{q,2}^1(W_+)$  dans  $\mathcal{E}_{q,2}^1(U(a) \cap \Omega)$ .

Réciproquement, si  $\varphi_1$  est dans  $\mathcal{E} \cap \mathcal{E}_{q,2}^1(U(a) \cap \Omega)$ , on définit  $\varphi$  dans  $W_+$  par  $\varphi(x) = \varphi_1(A(x))$ , et l'application se prolonge en  $u_1 \to u$  continue de  $\mathcal{E}_{q,2}^1(U(a) \cap \Omega)$  dans  $\mathcal{E}_{q,2}^1(W_+)$ ; cette application est l'inverse de  $u \to u_1$ , qui est donc un isomorphisme de  $\mathcal{E}_{q,2}^1(W_+)$  sur  $\mathcal{E}_{q,2}^1(U(a) \cap \Omega)$ .

(30) On démontre, par une méthode analogue, que la condition nécessaire et suffisante pour que u, élément de  $\mathcal{E}_{q,2}^1(\Omega)$ , soit dans  $\mathfrak{D}_{q,2}^1(\Omega)$ , est que  $\gamma$  u=0 (presque partout) (sous les hypothèses du thèorème 7.1)

Remarque 7. 2. — On peut évidemment obtenir des résultats globaux, i.e. un prolongement  $u \to \gamma u$  de  $\mathcal{E}_{q,2}^1(\Omega)$  dans  $L^{q^*}(\Gamma)$  (et non plus  $L_{loc}^{q^*}(\Gamma)$ ) avec  $\Gamma$  non compact; en effet il en est par exemple ainsi lorsque  $\Omega$  est le demi-espace  $x_n > 0$  et on fait des hypothèses sur  $\Omega$  permettant de se ramener à ce cas (comme dans le théorème 7. 1).

On peut également, dans le théorème 7. 1, prendre pour  $\Gamma$  un morceau de la frontière (au lieu de toute la frontière).

Remarque 7. 3. — Notons également ceci, utile dans les problèmes aux limites (Lions [3]): si l'on veut prolonger dans l'espace  $L^2_{loc}(\Gamma)$  on peut remplacer (7, 9) par:

$$\int_{W_0} |\varphi(x^*, 0)|^2 dx^* \leqslant c_1' \int_{W} |\varphi|^2 dx + c_2' ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L^2(W)} ||\varphi||_{L$$

(c'<sub>i</sub> = constante) d'où la propriété:

(7, 11) 
$$||\gamma u||_{L^2(\Gamma_k)} \leqslant c_1 ||u||_0^2 + c_2 ||u||_0 ||u||_1$$
,  $\Gamma_k$  compact de  $\Gamma$ .

8. Prolongement des distributions  $BL(\Omega)$  à  $R^n$ . — On suppose encore que  $\Omega$  est un ouvert de Soboleff. On désigne par E l'espace  $L^2_{loc}(R^n)$ . On a le

Théorème 8. 1. — Sous les hypothèses (Pr 1) et (Pr 2) (N° 7) il existe une application linéaire continue (évidemment non unique) de  $\mathcal{E}_{q,2}^1(\Omega)$  dans BL(E), soit  $u \to R(u)$ , telle que (8, 1) R(u) = u presque partout (p.p.) dans  $\Omega$ .

Démonstration. — On prend le recouvrement  $U(a_i)$ , U', les fonctions  $F_i$ ,  $f_i$  etc. comme au No 7. Toute fonction u de  $\mathcal{E}^1_{a,2}(\Omega)$  s'écrit:

$$u = f'u + \Sigma f_i u.$$

On peut considérer f'u dans  $R^n$ ; c'est un élément de BL(E) et l'application  $u \to f'u$  est continue de  $\mathcal{E}^1_{q,\,2}(\Omega)$  dans BL(E). Supposons alors que l'on ait montré ceci :

(8, 2) 
$$\begin{cases} \text{pour tout } i, \text{ il existe une application linéaire} \\ \text{continue } u \to R_i(u) \text{ (non unique) de } \mathcal{E}^1_{q,2}(\mathrm{U}(a_i) \cap \Omega) \\ \text{dans } \mathcal{E}^1_{q,2}(\mathrm{U}(a_i)) \text{ telle que } R_i(u) = u \text{ p. p. dans} \\ \mathrm{U}(a_i) \cap \Omega. \end{cases}$$

On aura alors le théorème en prenant :

(8, 3) 
$$R(u) = \sum \sqrt{F_i} R_i (\sqrt{f_i} u) + f' u.$$

En effet on peut supposer que  $\sqrt{F_i}$  est dans  $\mathfrak{D}_{\mathbb{R}^n}$  (31), de sorte que  $\sqrt{F_i}R_i(\sqrt{f_i}u)$  soit dans BL(E); alors la somme (8, 3) converge et l'application  $u \to R(u)$  est continue de  $\mathcal{E}_{q,\,2}^i(\Omega)$  dans BL(E). En outre, pour x dans  $\Omega$  (ce qui suit a un sens p.p.):  $R_i(\sqrt{f_i}u)(x) = \sqrt{f_i}u(x)$  d'où Ru(x) = u(x), on a donc le théorème si l'on a (8, 2). Tout revient donc à montrer (8, 2). Or c'est immédiat: en effet, comme on a vu dans le théorème 7. 1,  $\mathcal{E}_{q,\,2}^i(U(a_i)\cap\Omega)$  est isomorphe à  $\mathcal{E}_{q,\,2}^i(W_+)$  et on a défini au théorème 7. 1 l'application  $v\to \tilde{v}$  de  $\mathcal{E}_{q,\,2}^i(W_+)$  dans  $\mathcal{E}_{q,\,2}^i(W)$ , qui vérifie:  $v=\tilde{v}$  p.p. dans  $W_+$ . A cette application  $v\to \tilde{v}$  correspond une application  $u\to R_i(u)$  donnant lieu à (8,2), d'où le théorème.

Remarque 8. 1. — Si  $\Omega$  est un ouvert borné vérifiant (Pr 1) et (Pr 2), c'est un ouvert de Soboleff.

C'est un cas particulier du théorème 6. 1, mais aussi une conséquence immédiate du théorème 8.1. En effet si  $u \in BL(\Omega)$ , soit R(u) le prolongement à  $R^n$  défini par ce théorème. Alors si  $\varphi \in \mathfrak{D}_{R^n}$ ,  $\varphi = 1$  sur  $\overline{\Omega}$ , on a :  $\varphi R(u) \in BL(R^n)$ , donc  $\varphi R(u) \in L^q(R^n)$  et par suite  $u \in L^q(\Omega)$ .

9. Un théorème de complète continuité. — Le théorème qui suit n'est pas lié directement à l'étude des fonctions  $BL(\Omega)$ , mais il sera utile au Nº suivant. Voir aussi pour le théorème ci-après: Courant et Hilbert [1], Soboleff [2], Kondrachoff [1], Koudriavzeff [1].

Théorème 9. 1. — Soit  $\Omega$  un ouvert borné quelconque de  $\mathbb{R}^n$  (de frontière quelconque,  $\Omega$  connexe ou non). Pour tout  $\varepsilon > 0$ , l'injection de  $\mathcal{E}_{q,2}^{\iota}(\Omega)$  dans  $\mathbb{L}^{q-\varepsilon}(\Omega)$  est complètement continue.

Démonstration. — Soit B la boule unité de  $\mathcal{E}_{q,2}^{\iota}(\Omega)$ ; il faut montrer qu'elle est relativement compacte dans  $L^{q-\varepsilon}(\Omega)$ , donc, d'après A. Weil [1], p. 53, 54, il faut montrer:

a) pour tout  $\varepsilon_1 > 0$ , il existe K compact de  $\Omega$ , tel que pour tout  $f \in B$  on ait:

$$\int_{(K)} |f(x)|^{q-\varepsilon} dx \leqslant \varepsilon_{i}.$$

(31) Si G',  $G_i$  est une partition de l'unité indéfiniment différentiable positive associée au recouvrement U', U  $(a_i)$ , on prendra :

$$\mathbf{F}' = \frac{\mathbf{G}'^2}{\mathbf{G}'^2 + \Sigma \mathbf{G}_i^2}, \qquad \quad \mathbf{F}_i = \frac{\mathbf{G}_i^2}{\mathbf{G}'^2 + \Sigma \mathbf{G}_i^2}.$$

b) Pour tout  $\varepsilon_1 > 0$  il existe  $\eta$  tel que

$$\| \tau_h \tilde{f} - \tilde{f} \|_{L^{q-\epsilon}(\mathbb{R}^n)} \leqslant \epsilon_1$$

pour tout  $f \in B$ ,  $|h| \leq \eta$ , où  $\tilde{f}$  désigne la fonction dans  $R^n$  égale à  $f \operatorname{sur} \Omega$ , 0 ailleurs, et  $\tau_h \tilde{f}$  la translatée de  $\tilde{f}$  de  $h = (h_1, ..., h_n)$ 

Démonstration de a). — On déduit aussitôt de l'inégalité de Hölder, K étant un compact quelconque de  $\Omega$ ,

$$\int_{\mathbb{C}^K} |f(x)|^{q-\varepsilon} dx \leqslant (\operatorname{mes} \mathbb{C}^K)^{\varepsilon/q}, \quad \text{pour tout } f \in \mathcal{B};$$

or ceci est majoré par ε, pour K convenable.

Démonstration de b). — On choisit d'abord K de sorte que

$$\|\tilde{f}\|_{L^{q-\epsilon}}((\kappa) \leqslant \epsilon_1/3. \text{ pour tout } f \in B.$$

On prend ensuite  $K_1$  avec  $\mathring{K}_1 \supset K$ , et l'on choisit  $\eta_1$  tel que  $x \in \int K_1$ , et  $|h| \leq \eta_1$ , entraînent  $x - h \in \int K$ . Alors on a, pour  $|h| \leq \eta$  et pour tout  $f \in B$ :

$$\|\tau_h \tilde{f}\|_{L^{q-\epsilon}([K_1])} \leq \epsilon_1/3.$$

Soit alors  $a \in \mathcal{D}_{\Omega}$ , = 1 sur K<sub>1</sub>, et b = 1 - a,  $\in \mathcal{E}_{\Omega}$ . On a:

Mais on applique à (af) Schwartz [2] p. 41, 42; il vient:

$$\|\tau_h(af) - af\|_{L^{q-\epsilon}(\mathbb{R}^n)} \leqslant \mathbb{C}|h|^s$$

où C est une constante indépendante de  $f \in B$ , et s est donné par :  $1/s = 1/(q - \epsilon) - 1/q$ . Ceci est majoré par  $\epsilon_1/3$  pour  $|h| \leq \eta_2$ , d'où le résultat en prenant  $\eta = \inf(\eta_1, \eta_2)$ .

COROLLAIRE 9. 1. — Si  $\Omega$  est un ouvert de Soboleff borné, l'injection de  $\mathcal{E}^{1}_{L^{2}}(\Omega)$  dans  $L^{2}(\Omega)$  est complètement continue.

Démonstration. — Si  $\Omega$  est (S),  $\mathcal{E}_{L^2}^1(\Omega)$  est identique à  $\mathcal{E}_{q,\,2}^1(\Omega)$  algébriquement et topologiquement (ce dernier point parce que 2 espaces de Banach algébriquement identiques dont l'un a une norme plus grande ont nécessairement des normes équivalentes) et  $L^2$  contient  $L^{q-\varepsilon}$ ,  $\varepsilon$  tel que  $q-\varepsilon\geqslant 2$  avec une topologie moins fine, d'où le résultat par le théorème 6. 1.

10. Ouverts de Nikodym, constante de Poincaré, problème de Neumann. — Soit  $\Omega$  un ouvert de  $\mathbb{R}^n$ , pour l'instant quelconque. On rappelle que  $\mathcal{E}^i_{L^*}(\Omega)$  est l'espace de Hilbert des fonctions  $u \in L^2(\Omega)$ , telles que  $\frac{\partial}{\partial x_i} u \in L^2$  pour tout i, avec la norme :

$$|||u|||_1 = (||u||_{L^2}^2 + ||u||_1^2)^{1/2}.$$

On désigne par N (cf. Lions [1]) l'espace des fonctions  $u \in \mathcal{E}_{L^2}(\Omega)$  telles que  $\Delta u$  soit dans  $L^2(\Omega)$ , et telles que l'on ait:

(10, 1) 
$$(-\Delta u, \nu)_{L^2} = (u, \nu)$$
, pour tout  $\nu \in \mathcal{E}_{L^2}^1(\Omega)$ .

Cet espace contient D; muni du produit scalaire:

$$(u, \nu)_{N} = (u, \nu)g_{L^{2}}^{1} + (\Delta u, \Delta \nu)_{L^{2}}$$

c'est un espace de Hilbert. Si la frontière de  $\Omega$  est « régulière » toute fonction de  $\mathcal{E}_{L^*}$ , de laplacien de carré sommable et de dérivée normale nulle sur la frontière de  $\Omega$ , est dans N. Les fonctions de N sont des fonctions de dérivée normale nulle sur la frontière de  $\Omega$  dans un sens généralisé, et valable quelle que soit la frontière de  $\Omega$ .

Ceci posé on a le

Théorème 10. 1. — L'opérateur —  $\Delta$  —  $\lambda$ , est un isomorphisme de N sur L<sup>2</sup> pour tout  $\lambda$  < 0.

Démonstration (32). — On veut résoudre l'équation :

$$(10, 2) -\Delta u - \lambda u = f,$$

f donné dans L<sup>2</sup>, u cherché dans N. Pour  $\varrho$  quelconque dans  $\mathcal{E}_{L^2}^1$ , on a :

$$(10, 3) (u, v)_{\mathcal{E}_{\mathbf{r}^2}^1} - (\lambda + 1)(u, v)_{\mathbf{L}^2} = (f, v)_{\mathbf{L}^2}$$

et réciproquement si u est dans  $\mathcal{E}_{L^*}^1(\Omega)$ , et vérifie (10, 3) pour tout  $\nu$  dans  $\mathcal{E}_{L^*}^1(\Omega)$ , u est dans N et vérifie (10, 2). Donc (10, 2) équivaut à (10, 3).

Or pour f donné dans  $L^2$ ,  $\rho \to (f, \rho)_{L^2}$  est une forme semi linéaire continue sur  $\mathcal{E}^1_{L^2}(\Omega)$ , donc  $\mathcal{E}^1_{L^2}(\Omega)$  étant un espace de Hilbert,

$$(f, v)_{L^2} = (Gf, v)_{g_{L^2}^1},$$

<sup>(32)</sup> Voir aussi Lions [3]. Ce théorème se généralise par le même procédé de démonstration aux opérateurs elliptiques à coefficients variables.

ce qui définit G, élément de l'espace  $\mathcal{L}(L^2; \mathcal{E}_{L^2})(^{33})$ . Si l'on désigne par G, la restriction de G à  $\mathcal{L}(\mathcal{E}_{L^2}; \mathcal{E}_{L^2})$ , on a là un opérateur hermitien positif, et (10, 3) équivaut à :

$$(10, 4) (1 - (\lambda + 1)G_1)u = Gf.$$

Or  $(G_1u, u)g_{2}^{1} = ||u||_{L^2}^2$ , d'où résulte facilement que  $1 - (\lambda + 1)G$  est inversible pour  $\lambda < 0$ , d'où le théorème.

Par définition, on appellera problème de Neumann, relativement à l'opérateur —  $\Delta$  —  $\lambda$ , le

Problème 10.1. — Trouver U dans  $L^2$ , avec  $\Delta U \in L^2$ , solution de

$$(10, 5) -\Delta U - \lambda U = F,$$

F donné dans L<sup>2</sup>, avec la condition aux limites

$$(10, 6) h - U \in N,$$

h donné dans L<sup>2</sup> avec  $\Delta h \in L^2$ .

En posant u = h — U, il résulte aussitôt du théorème 10. 1 le

Corollaire 10. 1. — Le problème 10. 1 admet une solution unique pour tout  $\lambda < 0$ .

DÉFINITION 10. 1. — On appelle spectre de  $\Delta$  pour le problème de Neumann, l'ensemble des  $\lambda$  tels que —  $\Delta$  —  $\lambda$  ne soit pas un isomorphisme de N sur L², ou encore, l'ensemble des  $\lambda$  tels que : 1 —  $(\lambda + 1)G_1$  ne soit pas inversible dans  $\mathfrak{L}(\mathcal{E}_{L^2}^i; \mathcal{E}_{L^2}^i)$ .

Ce spectre est réel, et porté par le demi axe  $\lambda \geqslant 0$ , ceci par le théorème 10. 1.

On va l'étudier de façon plus précise moyennant l'hypothèse supplémentaire :

 $(10,\ 7) \quad \left\{ \begin{matrix} \Omega \text{ est un ouvert connexe born\'e tel que l'injection} \\ \text{ de } \pounds_{L^{2}}^{1}(\Omega) \text{ dans } L^{2}(\Omega) \text{ soit complètement continue.} \end{matrix} \right.$ 

Exemple. —  $\Omega$  est un ouvert de Soboleff borné; on a bien alors (10, 7), par le théorème 9. 1.

Sous l'hypothèse (10, 7), l'opérateur  $G_i$ , composé de l'injection de  $\mathcal{E}_L^i$  dans  $L^2$  et de  $G_i$ , est complètement continu, donc le spectre est dénombrable;  $\lambda_i = 0$  est valeur propre de dimen-

<sup>(33)</sup> De façon générale, si E et F sont 2 espaces vectoriels topologiques,  $\mathcal{L}(E; F)$  désigne l'espace des applications linéaires continues de E dans F.

sion 1, car  $\Delta u = 0$ ,  $u \in \mathbb{N}$ , équivaut à  $||u||_1 = 0$ , *i.e.* à u = constante, donc si l'on range les valeurs propres par ordre de grandeur croissante, on a :

$$\lambda_1 = 0 < \lambda_2 \leqslant \lambda_3 \leqslant \cdots$$

On va étudier maintenant de façon plus précise le problème pour  $\lambda = 0$  et  $\lambda = \lambda_2$ .

Le problème de Neumann pour l'opérateur —  $\Delta(\lambda = 0)$ . — Pour étudier le problème de Neumann relativement à —  $\Delta$ , il n'est pas nécessaire de supposer que l'on a (10, 7). On supposera seulement que  $\Omega$  est un ouvert connexe borné. On cherche alors u dans N, solution de

(10, 8) 
$$-\Delta u = f, \quad f \text{ donné dans } L^2.$$

Comme la fonction 1 est dans  $\mathcal{E}_{L^2}^1(\Omega)$ , si (10, 8) a une solution on a:  $(-\Delta u, 1)_{L^2} = (u, 1)_1 = 0$  donc:

$$(10, 9) \qquad \int_{\Omega} f(x) dx = 0.$$

On désigne par  $L_0^2$  le sous-espace vectoriel fermé de  $L^2(\Omega)$  formé des fonctions f qui vérifient (10, 9).

On a alors la

d'où:

Proposition 10. 1. — Soit  $\Omega$  un ouvert connexe borné. Si  $\Delta$  applique N sur  $L_0^2$ , alors  $\Omega$  est un ouvert de Nikodym.

Démonstration. — On va démontrer que sous les hypothèses de la proposition,  $\Omega$  donne lieu à l'inégalité de Poincaré; on a alors le résultat par application du théorème 5. 3.

Soit donc A l'ensemble des fonctions  $u \in \mathcal{E}_{L^*}^1$  telles que

$$\int_{\Omega} u(x) dx = 0 \quad \text{et} \quad ||u||_{1} \leqslant 1.$$

On aura l'inégalité de Poincaré si l'on montre que A est borné dans  $L^2_{\mathfrak{o}}$ .

Or soit f donné quelconque dans  $L_0^2$ ; il existe par hypothèse au moins une fonction  $u_0$  dans N telle que  $-\Delta u_0 = f$ ; on a alors

$$(-\Delta u_0, u)_{L^2} = (u_0, u)_1 = (f, u)_{L^2}$$
  
 $|(f, u)_{L^2}| \leq ||u_0||,$ 

pour tout  $u \in A$ , ce qui montre que A est faiblement borné dans  $L_0^2$ , donc est borné, c.q.f.d.

On a réciproquement la

Proposition 10. 2. — Si  $\Omega$  est un ouvert de Nikodym, le problème (10, 8), avec la condition (10, 9), admet une solution, déterminée à une constante additive près.

Démonstration. — Puisque l'on a (10, 9), pour tout  $v \in BL(\Omega)$  (donc à  $\mathcal{E}_{L^2}^i(\Omega)$ , vu que  $\Omega$  est un ouvert de Nikodym), on a :

$$(f, \varphi)_{L^2} = (f, \varphi + c)_{L^2}, \quad c = \text{constante quelconque}.$$

Donc:

$$(10, 10) \qquad \qquad \rho^{\bullet} \rightarrow (f, \varphi)_{L^{2}}$$

est une forme semi-linéaire sur BL<sup>•</sup>(Ω). En outre :

$$|(f, o)_{L^2}| \leq ||f||_{L^2} \inf_{c} ||o + c||_{L^2} \leq C||f||_{L^2}||o||_{t}$$

puisque sur  $\Omega$  on a l'inégalité de Poincaré. Donc (10, 10) est une forme continue sur BL'( $\Omega$ ), donc :

$$(10, 11) (f, \varphi)_{L^2} = (Hf, \varphi^*)_1,$$

ce qui définit Hf dans  $BL^{\bullet}(\Omega)$  et H est élément de  $\mathcal{L}(L_0^2; BL^{\bullet}(\Omega))$ . Il est maintenant immédiat que  $Hf = u^{\bullet}$  donne lieu à (10, 8) pour tout u dans  $u^{\bullet}$ , d'où la proposition.

On peut résumer les 2 propositions précédentes dans le

Théorème 10. 2. — Pour que le problème de Neumann homogène (10, 8), avec la condition (10, 9), admette une solution (unique à une constante additive près), il faut et il suffit que l'ouvert  $\Omega$  soit un ouvert de Nikodym(34).

La  $2^e$  valeur propre  $\lambda_2$  et la constante de Poincaré. — On a à ce sujet le

Théorème 10. 3. — Si l'ouvert  $\Omega$  vérifie (10, 7), alors c'est un ouvert de Nikodym, et la constante de Poincaré  $P(\Omega)$  est égale à  $1/\lambda_2$ ,  $\lambda_2$  étant la  $2^e$  valeur propre du problème de Neumann.

Démonstration. — On a (Cf. par exemple Courant et Hilbert), en désignant par  $\mu_2$  la  $2^e$  valeur propre de l'opérateur  $G_1$ , la suite  $\mu_1, \mu_2, ...$  des valeurs propres de  $G_1$  étant non croissante,

$$\mu_2 = \max_{\mathbf{u}} (G_1 \mathbf{u} \ \mathbf{u})_{g_1^{12}}, \quad \mathbf{u} \in \mathcal{E}_{L^2}, \quad ||\mathbf{u}||_{g_1^{12}} = 1, \quad \int_{\Omega} \mathbf{u}(x) \, dx = 0.$$

<sup>(34)</sup> On a, par la même méthode, un théorème analogue pour des opérateurs elliptiques à coefficients variables.

**Mais :**

$$(G_1u, u)_{\mathcal{B}_{L^2}^1} = ||u||_{L^2}^2$$
 et  $\mu_2 = 1/(\lambda_2 + 1)$ .

Donc pour tout *u* dans EL»? avec*<sup>f</sup> ^ u{x) dx* == 0 on a :

$$\lambda_2 ||u||_{L^2}^2 \leq ||u||_1^2$$
.

**Si maintenant** *f* **est quelconque dans** *ê^* **on pose :**

$$u = f - \frac{1}{\text{mes }\Omega} \int_{\Omega} f(x) \, dx;$$

on peut appliquer à *u* l'inégalité ci-dessus, d'où :

$$\int_{\Omega} |f(x)|^2 dx - \frac{1}{\operatorname{mes} \Omega} \left| \int_{\Omega} f(x) dx \right|^2 \leq \frac{1}{\lambda_2} ||f||_1^2$$

et dans cette inégalité, l/Xg est la meilleure constante possible d'où le théorème.

## II. — PROPRIÉTÉS FINES DES FONCTIONS (BL)

1. Capacité, énergie, fonction de Green. — Nous allons rassembler dans ce paragraphe les notions de théorie du potentiel indispensables pour l'étude approfondie des fonctions de Beppo Levi.

Notations. — Nous désignerons par :

h(x) le noyau newtonien dans  $R^n(|x|^{2-n}$  si n > 2,  $-\log |x|$  si n = 2).

 $\mathrm{U}^{\mu}(x)=\int h(x-t)\,d\mu\left(t
ight)$  la valeur en x du potentiel newtonien engendré par la mesure  $\mu$ .

 $U^{f}(x)$  ce même potentiel lorsque  $\mu = f dx$  est la mesure de densité f.

 $a_n$  le « flux élémentaire » dans  $\mathbb{R}^n$ , c'est-à-dire  $(n-2)s_n$  si n>2  $(s_n=$  aire de la sphère unité),  $2\pi$  si n=2.

Nous appellerons domaine (de  $\mathbb{R}^n$ ) tout ouvert connexe  $\Omega$ ; la frontière et l'adhérence de  $\Omega$  seront notées respectivement  $\tilde{\Omega}$  et  $\Omega$ .

Capacité. — Nous utiliserons exclusivement la capacité de Wiener. La capacité d'un compact e de  $R^n(n > 2)$ , notée cap (e), est la borne supérieure des masses totales des mesures  $\mu \geqslant 0$  portées par e, avec  $U^{\mu}(x) \leqslant 1$  partout; on définit ensuite la capacité d'un ouvert  $\omega$  (borne supérieure des capacités des compacts contenus dans  $\omega$ ), puis la capacité extérieure d'un ensemble quelconque e, notée aussi cap (e). Un ensemble de capacité extérieure nulle sera dit polaire; on dira « quasipartout » au lieu de « sauf sur un ensemble polaire ». La capacité extérieure de la réunion dénombrable d'ensembles  $e_k$  satisfait à la relation fondamentale :

(1, 1) 
$$\operatorname{cap}\left(\bigcup_{k=1}^{\infty} e_{k}\right) \leqslant \sum_{k=1}^{\infty} \operatorname{cap}\left(e_{k}\right).$$

La situation est moins simple pour n=2; les définitions précédentes s'appliquent encore si on se borne à considérer des ensembles contenus dans un cercle de rayon 1, mais encore faut-il prendre garde que la relation (1, 1) n'a pas toujours lieu si les  $e_k$  ne sont pas tous contenus dans un ensemble de diamètre 1.

On pourrait chercher à utiliser d'autres procédés: introduction de capacités négatives, du noyau  $\log (a/|x|)$  (a>1), de la capacité logarithmique; tous ont leurs inconvénients, c'est pourquoi nous nous contenterons des définitions précédentes; elles nous suffiront, jointes à celle-ci: un ensemble plan e est dit polaire si cap  $(e \cap K) = 0$ , quel que soit le compact K de diamètre  $\leq 1$ .

Energie. — Une mesure de Radon  $\mu$  dans  $R^n(n \ge 2)$  est dite d'énergie finie si l'intégrale

$$\mathrm{I}(\mu) = \iint h(x-y)\,d\mu(x)\,d\overline{\mu}(y) = \int \mathrm{U}^{\mu}(x)\,d\overline{\mu}(x)$$

est absolument convergente. Le nombre  $I(\mu)$ , appelé énergie de  $\mu$ , est réel.

Pour n > 2,  $I(\mu)$  est positif, nul seulement si  $\mu = 0$ ; sa racine carrée est donc une norme hilbertienne sur l'ensemble des mesures d'énergie finie.

Pour n = 2,  $I(\mu)$  peut être < 0; cependant c'est encore le carré d'une norme hilbertienne sur chacun des ensembles suivants:

- a) les mesures d'énergie finie portées par un même cercle de rayon < 1.
  - b) les mesures d'énergie finie de masse totale nulle.

Le produit scalaire associé est l'intégrale

$$J(\mu, \nu) = \iint h(x-y) d\mu(x) d\bar{\nu}(y) = \int U^{\mu}(x) d\bar{\nu}(x),$$

appelée énergie mutuelle de  $\mu$  et  $\nu$ .

Si  $\mu$  est de la forme  $\psi dx$ , avec  $\psi \in \mathfrak{D}(\mathbb{R}^n)$  (ou même seulement continue à support compact), on a la formule élémentaire :

(1, 2) 
$$I(\psi) = \frac{1}{a_n} \int \left| \overrightarrow{\operatorname{grad}} \ \mathrm{U}^{\psi}(x) \right|^2 dx = \frac{1}{a_n} ||\mathrm{U}^{\psi}||_i^2,$$

valable même pour n=2, mais en supposant alors  $\psi$  de masse totale nulle  $(\int \psi dx = 0)$ .

Une autre formule élémentaire, mais moins connue, et que nous n'utiliserons qu'au paragraphe 6, est la suivante: si  $\vec{i} = (\varphi_i, ..., \varphi_n) \in [\mathfrak{D}(\mathbf{R}^n)]^n$  et si  $\psi = \sum_{k=1}^n \delta \varphi_k / \delta x_k = \text{div } \vec{i}$  (ce qui suppose  $\psi$  de masse totale nulle), on a :

$$(1, 3) I(\psi) \leqslant a_n \int \left| \overrightarrow{i}(x) \right|^2 dx (35),$$

l'égalité n'ayant lieu que si i est un vecteur gradient; à noter que le potentiel U $^{\psi}$  peut alors s'écrire:

$$\mathbf{U}^{\psi}(x) = \int \overrightarrow{\operatorname{grad}}_x h(x-t) \cdot \overrightarrow{i}(t) dt.$$

Nous allons maintenant établir, dans un cas simple, un résultat souvent utilisé en théorie du potentiel : (36)

Lemme 1. 1. — Soit  $\varphi \in \mathfrak{D}(\mathbb{R}^n)$ ; si n=2, on suppose  $\varphi$  nulle hors d'un cercle de rayon < 1; soit  $\to$  l'ensemble des points x en lesquels on  $a: |\varphi(x)| > \alpha$ , nombre positif donné; alors:

(1, 4) 
$$\operatorname{cap}(E) \leqslant \frac{1}{a_n \alpha^2} \int \left| \overrightarrow{\operatorname{grad}} \varphi \right|^2 dx = \frac{\|\varphi\|_1^2}{a_n \alpha^2}.$$

Démonstration. — Supposons d'abord  $\varphi$  réelle  $\geqslant 0$ ; d'après la formule élémentaire de Poisson on  $a: \varphi = U^{\psi}$ , avec  $\psi = -\Delta \varphi/a_n$ . Soit e un compact contenu dans E; si la capacité de e n'est pas nulle il existe par définition, pour tout  $\varepsilon$  compris entre 0 et cap (e), une mesure positive portée par e, telle que

$$\int d\mu > {
m cap}\,(e) - arepsilon, \qquad {
m et} \qquad {
m U}^{\mu}(x) \leqslant 1$$

pour tout  $x \in \mathbb{R}^n$  (37); l'énergie mutuelle des mesures  $\psi dx$  et  $\mu$  est :

$$J(\psi, \mu) = \int U^{\psi} d\mu = \int \varphi d\mu \geqslant \alpha [cap(e) - \epsilon];$$

(35) Cette formule est établie dans un cas plus général (vecteur  $\tilde{t}$  de carré sommable dans  $\mathbb{R}^n$ , à support compact si n=2) dans Deny [1], en utilisant la transformation de Fourier; on peut évidemment l'obtenir directement; dans  $\mathbb{R}^3$ , par exemple, elle résulte de l'identité connue:

$$\int |\overrightarrow{\operatorname{grad}} \ \mathrm{U}^{\frac{1}{2}}|^2 dx + \int |\overrightarrow{\operatorname{rot}} \ \overrightarrow{\mathrm{V}}|^2 dx = 16 \pi^2 \int |\overrightarrow{i}|^2 dx,$$

où  $\overrightarrow{V}(x) = \int \overrightarrow{\operatorname{grad}} h(x-t) \wedge \overrightarrow{i}(t) dt$ ; cette identité admet d'intéressantes généralisations.

(36) Voir un énoncé voisin, nommé « principe de Dirichlet », dans Polya et Szegö [1] (chapitre II); la démonstration rapide que nous en donnons s'appuie sur une idée de Cartan [1].

 $(^{37})$  On pourrait aller un peu plus vite en utilisant la distribution capacitaire de e.

mais l'inégalité de Schwarz s'applique à  $J(\psi, \mu)$ , même pour n=2, car  $\psi dx$  et  $\mu$  sont portées par un même cercle de rayon <1 (cas a); d'où:

$$[J(\psi, \mu)]^2 \leqslant I(\psi) I(\mu) \leqslant [\operatorname{cap}(e) - \varepsilon] \frac{||\varphi||_1^2}{a_n}$$

(d'après (1. 2), valable même pour n=2, car  $\psi$  est de masse totale nulle). En rapprochant il vient: cap (e)—  $\varepsilon \leq ||\varphi||_1^2/a_n\alpha^2$ , d'où (1. 4) en faisant  $\varepsilon \to 0$  (car cap (E) est la borne supérieure des nombres cap (e)).

Supposons maintenant  $\varphi$  à valeurs complexes;  $|\varphi|$  est continue; c'est une fonction de  $\operatorname{BL}(\mathbf{R}^n)$ , et  $||(|\varphi|)||_1 \leqslant ||\varphi||_1$  (voir I, remarque 3. 3 dans un cas simple). Soit  $\varphi_k = |\varphi| * \rho_k$  la régularisée de  $|\varphi|$  par  $\rho_k \in \mathfrak{D}(\mathbf{R}^n)$ , à valeurs réelles  $\geqslant 0$ , nulle pour |x| > 1/k, de masse totale 1(k=1, 2...);  $\varphi_k(x)$  converge uniformément vers  $|\varphi(x)|$ , et  $\varphi_k$  converge vers  $|\varphi|$  dans  $\operatorname{BL}(\mathbf{R}^n)$ . Soit alors  $\varepsilon$ ,  $0 < \varepsilon < \alpha$ ; pour k assez grand, E est contenu dans l'ensemble  $\operatorname{E}_x(\varphi_k(x) > \alpha - \varepsilon)$  (en vertu de la convergence uniforme), donc d'après la première partie de la démonstration  $\operatorname{cap}(E) \leqslant ||\varphi_k||_1^2/a_n(\alpha - \varepsilon)^2$ , d'où (1. 4), en faisant tendre k vers  $+\infty$  et  $\varepsilon$  vers 0. Ce raisonnement est encore valable pour n=2, car, pour k assez grand, les  $\varphi_k$  sont nulles hors d'un cercle de rayon < 1.

Fonction de Green. — Tout domaine  $\Omega$  de  $\mathbb{R}^n$  avec n > 2, tout domaine plan  $\Omega$  de complémentaire non polaire, admet une fonction de Green et une seule, notée  $\mathcal{G}(x, y)(x, y \in \Omega)$ , caractérisée par :

- a) G(x, y) > 0.
- b) Pour x fixe,  $\mathcal{G}(x, y)$  est harmonique en tout  $y \neq x$ , et est équivalente à h(x-y) au voisinage de x.
  c) Pour x fixe,  $\lim_{x \to a} \mathcal{G}(x, y) = 0$  pour « quasi » tout point-
- c) Pour x fixe,  $\lim_{y \to y_0} G(x, y) = 0$  pour « quasi » tout point-frontière  $y_0$  (d'une façon précise: en tout point-frontière régulier).

Cette fonction est symétrique:  $\mathcal{G}(x, y) = \mathcal{G}(y, x)(x, y \in \Omega)$ ; on peut la définir pour x et  $y \in \mathbb{R}^n$  en lui attribuant la valeur 0 dès que l'un au moins des points x ou y est extérieur à  $\Omega$ , ou point-frontière régulier. Pour être complet, il resterait à la définir lorsque l'un au moins des points x ou y est point-frontière irrégulier, mais ce raffinement est sans importance pour notre objet (38).

Il est possible de développer une théorie du potentiel par rapport à la fonction de Green en tout point semblable à la théorie newtonienne, ces deux théories étant identiques pour  $\Omega = \mathbb{R}^n$  avec n > 2 (dans ce cas on en a en effet  $\mathcal{G}(x, y) = h(x - y)$ ). Dans cette nouvelle théorie le cas n = 2 ne se distinguera pas des autres.

On définira ainsi des potentiels de Green  $U^{\mu}_{\Omega}(x) = \int \mathcal{G}(x,t) d\mu(t)$ , et des mesures d'énergie finie « relativement à la fonction de Green », c'est-à-dire les mesures  $\mu$  dans  $\Omega$ , pour lesquelles l'intégrale

 $I_{\Omega}(\mu) = \iint \mathcal{G}(x, y) \, d\mu(x) \, d\overline{\mu}(y) = \int U_{\Omega}^{\mu} \, d\mu$ 

est absolument convergente. La racine carrée de  $I_{\Omega}(\mu)$  est une norme hilbertienne sur l'ensemble de ces mesures.

On a encore des formules élémentaires analogues à (1, 2) et (1, 3); si  $\psi \in \mathfrak{D}(\Omega)$ , on a :

$$(1, 5) \quad I_{\Omega}(\psi) = \frac{1}{a_n} \int |\overrightarrow{\text{grad}} \ U_{\Omega}^{\psi}(x)|^2 dx = \frac{1}{a_n} ||U_{\Omega}^{\psi}||_1^2 (39).$$

Si d'autre part  $\psi = \operatorname{div} \hat{i}$ , avec  $\hat{i} = (\varphi_1, ..., \varphi_n) \in \widehat{\mathcal{D}}(\Omega)$ , on a:

$$(1, 6) I_{\Omega}(\psi) \leqslant a_n \int |\widetilde{i}(x)|^2 dx (40);$$

(38) Si  $x \in \Omega$ ,  $\mathcal{C}_{f}(x, y)$ , déjà définie quasi-partout, peut être prolongée de façon à être sousharmonique en  $y \neq x$  dans  $\mathbb{R}^n$  tout entier; finalement, grâce à la symétrie,  $\mathcal{C}_{f}(x, y)$  est encore définie quasi-partout si x est point-frontière irrégulier, et on peut la prolonger aux y qui sont points-frontière irréguliers par un procédé analogue. Ceci résulte immédiatement de Brelot [3] (p. 326-327), où un cas plus général est envisagé, celui d'un ouvert de l'espace  $\mathbb{R}^n$  rendu compact par adjonction d'un point à l'infini. Rappeions ici un résultat utile: si  $\Omega_k$  tend en croissant vers  $\Omega$ , la fonction de Green correspondante  $\mathcal{C}_{fk}(x, y)$  tend en croissant vers  $\mathcal{C}_{fk}(x, y)$  (voir par exemple Brelot [3] p. 327).

(39) Si  $\Omega$  est assez régulier (par exemple borné et limité par un nombre fini de surfaces à courbure bornée), cela résulte de la formule élémentaire de Green appliquée à  $U = U_0^{\dagger}$ :

 $\int_{\Omega} U \overline{\Delta U} + \int_{\Omega} |\overrightarrow{grad} U|^2 = \int_{\Omega} U \frac{d\overline{U}}{dv} = 0$ 

car U=0 sur  $\Omega$  et les hypothèses de régularité entraînent que les dérivées du premier ordre de U sont continues et bornées dans  $\Omega$ . Le cas général s'en déduit par passage à la limite, à l'aide du théorème rappelé à la fin de la note précédente.

(\*0) Cette formule se déduit de (1. 3) et de l'inégalité  $I_{\Omega}(\psi) \leqslant I$  ( $\psi$ ), qui suppose  $\psi$  de masse totale nulle si n=2; cette dernière inégalité est une conséquence connue de la théorie du balayage, le seul cas délicat étant celui où n=2 et  $\Omega$  non borné (on utilise alors le passage à la limite signalé dans la note précédente).

U<sub>O</sub> peut alors s'écrire:

$$\mathrm{U}^{\mu}_{\Omega}(x) = \int \overrightarrow{\mathrm{grad}} \, \mathcal{G}_x(x, t) . \, \overrightarrow{i}(t) \, dt.$$

Pour achever ces préliminaires, observons encore que, de même que  $\mathcal{G}(x, y)$  peut être définie pour x et  $y \in \Omega$ , on peut donner un sens à  $I_{\Omega}(\mu)$  pour certaines mesures de  $\mathbb{R}^n$ . En particulier  $I_{\Omega}(\psi)$  est fini et  $\geqslant 0$  pour toute  $\psi \in \mathfrak{D}(\mathbb{R}^n)$ ; on a d'ailleurs  $I_{\Omega}(\psi) \leqslant I(\psi)$ , même si n=2, mais en supposant alors  $\psi$  de masse totale nulle.

La racine carrée de  $I_{\Omega}(\psi)$  est donc une *semi-norme* hilbertienne sur  $\mathfrak{D}(R^n)$  (mais non en général une norme); la forme bilinéaire associée  $J_{\Omega}(\varphi,\psi)$  satisfait à l'inégalité de Schwarz:

$$|J_{\Omega}(\varphi, \psi)|^2 \leqslant I_{\Omega}(\varphi) I_{\Omega}(\psi).$$

2. Retour sur l'espace  $\widehat{\mathfrak{D}}^{1}(\Omega)$ . — Les méthodes de la théorie du potentiel vont nous permettre d'améliorer le théorème 4. 3 du chapitre I en caractérisant les domaines plans non bornés  $\Omega$  tels que  $\widehat{\mathfrak{D}}^{1}(\Omega)$  soit un espace de distributions.

Théorème 2.1. — Soit un domaine plan  $\Omega$ ; pour que  $\widehat{\mathfrak{D}}'(\Omega)$  soit un espace de distributions, il faut et il suffit que le complémentaire  $\bigcap \Omega$  soit non polaire; les éléments de  $\widehat{\mathfrak{D}}'(\Omega)$  sont alors des fonctions qui, prolongées par 0 hors de  $\Omega$ , sont dans  $L^r_{loc}(R^2)$  pour tout r fini.

Démonstration. — La condition est suffisante : soit en effet  $\Omega$  un domaine plan de complémentaire non polaire, et soit  $\{\varphi_k\}$  une suite de Cauchy dans  $\mathfrak{D}(\Omega)$ , normé par  $||\varphi||_1 = (\int |\overline{\operatorname{grad}} \varphi|^2 dx)^{1/2}$ ; on va montrer que  $\varphi_k$  converge dans  $\mathfrak{D}'(\Omega)$  et même que, si  $\tilde{\varphi}_k$  est le prolongement de  $\varphi$  par 0 hors de  $\Omega$ ,  $\tilde{\varphi}_k$  converge dans  $\mathfrak{D}'(\mathbf{R}^2)$ ; à cet effet il suffit de vérifier que  $\int \tilde{\varphi}_k \psi dx$  converge (Schwartz [1], p. 75) quel que soit  $\psi \in \mathfrak{D}(\mathbf{R}^2)$ ; or si on pose  $\psi_k = -\Delta \tilde{\varphi}_k/2\pi$ , on a  $\tilde{\varphi}_k = U^{\psi_k} = U^{\psi_k}_{\Omega}(^{*1})$ , d'où, d'après (1, 2) et (1, 7):

(i) Conséquence simple de la propriété suivante : tout potentiel de Green engendré par une mesure à support compact dans  $\Omega$  admet la pseudo-limite 0 quasipartout à la frontière de  $\Omega$  (voir au paragraphe suivant les définitions et références relatives à la notion de pseudo-limite). Il est plus élémentaire d'observer que si  $\Omega$  est régulier,  $\mathbf{U}_{\Omega}^{\psi} k = 0$  partout à la frontière, donc la fonction harmonique bornée  $\mathbf{U}_{\Omega}^{\psi} k = \mathbf{U}^{\psi}$  est identiquement nulle dans  $\Omega$ ; le cas où  $\Omega$  est quelconque (de complémentaire non polaire si n=2) s'en déduit par passage à la limite (voir les notes précédentes).

$$\begin{split} \left| \int (\tilde{\varphi}_{k+h} - \tilde{\varphi}_k) \psi \, dx \right|^2 &= \left| \int (\mathbf{U}_{\Omega}^{\psi_{k+h}} - \mathbf{U}_{\Omega}^{\psi_k}) \psi \, dx \right|^2 = |\mathbf{J}_{\Omega}(\psi_{k+h} - \psi_k, \psi)|^2 \\ &\leqslant \mathbf{I}_{\Omega}(\psi_{k+h} - \psi_k) \mathbf{I}_{\Omega}(\psi) = \frac{1}{2\pi} ||\varphi_{k+h} - \varphi_k||_1^2 \mathbf{I}_{\Omega}(\psi) \end{split}$$

d'où le résultat; pour montrer que  $\widehat{\mathfrak{D}}^{1}(\Omega)$  est bien un espace de distributions, il reste à vérifier que l'injection de  $\widehat{\mathfrak{D}}^{1}(\Omega)$  dans  $\mathfrak{D}'(\Omega)$  est biunivoque, ce qui est facile (42).

Soit  $\tilde{T}$  la distribution dans  $R^2$ , limite de la suite  $\{\tilde{\varphi}_k\}$ ; évidemment  $\tilde{T} \in BL(R^2)$ , donc  $\tilde{T} \in L^r_{loc}(R^2)$  pour tout r fini (I, théorème 2. 1); la restriction T de  $\tilde{T}$  à  $\Omega$  est la distribution de  $\mathfrak{D}'(\Omega)$  associé canoniquement à l'élément de  $\widehat{\mathfrak{D}}^1(\Omega)$  défini par la suite  $\{\varphi_k\}$ .

Il reste à montrer que la condition est nécessaire; cela résulte immédiatement (\*2 bis) du contre-exemple b (I, remarque 4. 1) et du théorème suivant, intéressant par lui-même et valable quel que soit  $n \ge 2$ ; la démonstration que nous en donnerons fait appel à la théorie du « balayage », et on pourra la laisser de côté en première lecture:

Théorème 2. 2. — Soit  $\Omega$  un domaine de  $\mathbb{R}^n$ ,  $n \geqslant 2$ , de complémentaire polaire;  $\mathfrak{D}(\Omega)$  est dense dans  $\mathfrak{D}(\mathbb{R}^n)$ , normé  $par ||\varphi||_1 = \left(\int |\operatorname{grad} \varphi|^2 dx\right)^{1/2}$ .

Démonstration. — Soit en effet  $\varphi \in \mathfrak{D}(\mathbf{R}^n)$ ; on va voir qu'il existe  $\psi \in \mathfrak{D}(\mathbf{R}^n)$ , nulle hors d'un compact de  $\Omega$  avec  $||\varphi - \psi||$ , arbitrairement petit. Soit B une boule hors de laquelle  $\varphi = 0$  (si n = 2, on supposera le diamètre de  $\mathbf{B} < 1$ ; cela ne restreint en rien la généralité puisque toute  $\varphi \in \mathfrak{D}(\mathbf{R}^n)$  est somme finie de fonctions indéfiniment dérivables, nulles hors de telles boules).

Soit  $\{\omega_k\}$  une suite d'ouverts tels que  $\bar{\omega}_{k+1} \subset \omega_k$ ,  $\bigcap \omega_k = \mathring{\Omega}$ , et cap  $(\bar{\omega}_k \cap \bar{B}) \rightarrow 0$  (une telle suite existe, car  $\mathring{\Omega}$  est polaire).

<sup>(42)</sup> Voir note (2) p. 321. (42) bis) Soit  $\varphi_k$  une suite de Cauchy dans  $\mathfrak{D}_{\Omega}$  pour la norme  $\|\varphi\|_1$ ,  $\Omega \subset \mathbb{R}^2$ . Si  $\varphi_k$ , converge dans  $\mathfrak{D}'_{\Omega}$ , alors  $\tilde{\varphi}_k$  converge dans  $\mathfrak{D}'_{R^2}$ . En effet, si  $\psi \in \mathfrak{D}_{R^2}$ ,  $\int \psi(x) dx = 0$ , alors  $\int \tilde{\varphi}_k \psi dx$  converge. Si maintenant  $\psi$  est quelconque dans  $\mathfrak{D}_R^2$ , on prend  $\alpha \in \mathfrak{D}_{\Omega}$ , de masse totale 1, et on introduit  $\theta = \psi - \tilde{\alpha} \int \psi dx$ ; alors  $\int \tilde{\varphi}_k \theta dx$  converge, donc  $\int \tilde{\varphi}_k \psi dx$  converge, c. q. f. d.

Soit  $\mu$  la mesure de densité  $-\Delta \varphi/a_n$ ;  $\mu$  est portée par  $\overline{B}$ , et  $\varphi = U^{\mu}$ . Désignons par  $\mu_k$  la restriction de  $\mu$  à  $\int_{a}^{b} \omega_k$ , par  $\nu_k$  et  $\nu_{k,h}$  les mesures « balayées » de  $\mu$  et  $\mu_k$  sur  $\overline{\omega}_h \cup \int_{a}^{b} \overline{B}$  ou, ce qui revient au même, sur  $(\overline{\omega}_h \cap \overline{B}) \cup \overline{B}$ , pour h > k (\*3).

Nous noterons ici  $||\lambda||$  la norme-énergie  $(I(\lambda))^{1/2}$  de la mesure d'énergie finie  $\lambda$ ; il résulte aisément de la théorie du

balayage des mesures d'énergie finie que

$$||\mathbf{v}_{\mathbf{h}} - \mathbf{v}_{\mathbf{k}, \mathbf{h}}|| \leq ||\mu - \mu_{\mathbf{k}}|| \rightarrow 0$$

avec 1/k, et que  $||v_k|| \rightarrow 0$  avec 1/h ("); donc

$$||\mathbf{v}_{k,h}|| \leqslant ||\mathbf{v}_{h} - \mathbf{v}_{k,h}|| + ||\mathbf{v}_{h}||$$

est arbitrairement petit pour k et h assez grands. Considérons maintenant le potentiel d'énergie finie

$$u=\mathrm{U}^{\mu_k}-\mathrm{U}^{\nu_{k,h}};$$

par définition du balayage, il est nul dans  $\omega_h$  et hors de B; sa régularisée  $\psi = u * \rho$  par une  $\rho \in \mathfrak{D}(\mathbb{R}^n)$  convenable est dans  $\mathfrak{D}(\Omega)$ , car le support de u est à distance positive de  $\tilde{\Omega}$ , et c'est le potentiel engendré par la mesure  $(\mu_k - \nu_{k,h}) * \rho$ , qui converge fortement (au sens de la norme-énergie) vers  $\mu_k - \mu_{k,h}$  lorsque  $\rho$  converge vers  $\delta$  en un sens convenable (\*5).

Finalement on a, d'après (1, 2):

$$\begin{array}{l} \alpha_n^{1/2} || \phi - - \psi ||_1 = || \mu - (\mu_k - \nu_{k, h}) * \rho || \\ \leqslant || \mu - \mu_k || + || \nu_{k, h} || + || \mu_k - \nu_{k, h} - (\mu_k - \nu_{k, h}) * \rho || \end{array}$$

- (43) Voir Cartan [2] pour la théorie du balayage; on ne considère ici que des mesures d'énergie finie; si  $\lambda'$  est la balayée de  $\lambda \geqslant 0$ ,  $\lambda'$  et  $i\lambda'$  sont par définition les balayées de  $\lambda$  et de  $i\lambda$ ; la théorie de Cartan est valable pour n=2, si on se place dans un compact de diamètre  $\leq 1$ .
- (44) Pour montrer que  $\mu_k \to \mu$  fortement (au sens de la norme-énergie), on peut supposer  $\mu \geqslant 0$ ; les potentiels  $U^{\mu_k}$  forment alors une suite croissante, majorée par un potentiel d'énergie finie; il en résulte (Cartan [1]) que  $\mu_k$  converge fortement, donc vaguement, vers une mesure qui n'est autre que  $\mu$ . Démonstration analogue pour  $\nu_h \to 0$  (on utilise le théorème de Cartan sur les suites décroissantes de potentiels). Enfin la relation  $\|\nu_h \nu_{h_h} k\| \leqslant \|\mu \mu_k\|$  exprime que le balayage d'une mesure n'augmente pas l'énergie.
- (45) Si  $\lambda$  est une mesure d'énergie finie, et si  $\alpha_k$  est une mesure positive de masse 1, portée par la boule de centre O et de rayon 1/k,  $\lambda * \alpha_k$  converge fortement vers  $\lambda$ ; c'est bien connu si  $\alpha_k$  est la distribution homogène de la masse 1; le cas général n'est pas difficile à démontrer (on trouvera une démonstration, faisant appel à la transformation de Fourier, dans Deny (1)).

quantité qui peut être rendue arbitrairement petite en prenant k et h assez grands, puis  $\rho$  suffisamment « voisine » de  $\delta$ ; le théorème est donc établi.

Remarque 2. 1. — Nous verrons plus loin (§ 5) que toute fonction continue de  $\widehat{\mathfrak{D}}^i(\Omega)$ , prolongée par 0 hors de  $\Omega$ , admet la « pseudo-limite » 0 quasi-partout sur  $\Omega$ ; il en résultera que la condition «  $\Omega$  polaire », qui est déjà suffisante, est également nécessaire pour que  $\mathfrak{D}(\Omega)$  soit dense dans  $\mathfrak{D}(R^n)$ , normé par  $\|\varphi\|_i$ .

## 3. Fonctions (BL) précisées.

Définition 3. 1. — Une fonction F, définie quasi-partout dans un domaine  $\Omega$  de  $\mathbb{R}^n$ , n > 2, possède la propriété (P) si, quel que soit  $\varepsilon > 0$ , il existe un ouvert  $\omega$  de capacité  $< \varepsilon$  tel que la restriction de F à  $\Omega - \omega$  soit continue; si n = 2, F possède la propriété (P) dans  $\Omega$  si F satisfait à la condition précédente dans tout domaine  $\Omega_1 \subset \Omega$  de diamètre  $\leq 1$ .

Les résultats suivants sont des conséquences immédiates de la définition :

Proposition 3. 1. — Si F est quasi-partout égale à une fonction possédant la propriété (P), F possède la propriété (P).

Proposition 3. 2. — Deux fonctions possédant la propriété (P), qui sont presque-partout égales, sont quasi-partout égales.

Proposition 3. 3. — Si F et G possèdent la propriété (P), il en est de même de F + G, FG, |F| et, si F xi G sont réelles, de sup (F, G) et inf (F, G).

Proposition 3. 4. — Si F possède la propriété (P) dans  $\Omega$ , « quasi toute droite » parallèle à une direction  $\Delta$  arbitraire découpe sur  $\Omega$  des intervalles tels que la restriction de F à chacun d'eux soit continue.

Autrement dit: les traces des droites exceptionnelles sur un hyperplan Il perpendiculaire à  $\Delta$  constituent un ensemble polaire (dans  $\mathbb{R}^n$ ); en effet, d'après un théorème connu de M. Brelot [1] sur les transformations minorant les distances, la capacité de la projection sur II de l'ensemble  $\omega$  de la définition 3.1 est  $< \varepsilon$ .

Définition 3. 2. — Une fonction F, définie quasi-partout. dans  $\Omega$ , est dite fonction (BL) précisée dans  $\Omega$  si :

(a)  $F \in BL(\Omega)$ ;

(b) F possède la propriété (P) dans  $\Omega$ .

Cette définition est indépendante du choix des axes de coordonnées. D'après la proposition 3. 4 et I, lemme 3. 2, toute fonction (BL) précisée possède la propriété (AC) dans  $\Omega$ , et ceci quel que soit le choix des axes.

Théorème 3. 1. — Toute fonction  $F \in BL(\Omega)$  est presque partout égale à une fonction (BL) précisée dans  $\Omega$  (46).

Démonstration. — Il suffit de montrer qu'il en est ainsi dans tout domaine borné de  $\Omega$ ; si n=2, on supposera donc  $\Omega$  borné et de diamètre  $\leq 1$ . En outre, d'après le théorème de décomposition (I, th. 4. 5), F est la somme d'une fonction harmonique et d'une fonction de  $\widehat{\mathfrak{D}}^{1}(\Omega)$ ; on peut donc supposer  $F \in \widehat{\mathfrak{D}}^{1}(\Omega)$ .

Soit une suite de fonctions  $\varphi_k$  convergeant vers F dans  $\widehat{\mathfrak{D}}^1(\Omega)$ ; on peut supposer, en prenant une suite partielle, que la série  $\Sigma 4^k ||\varphi_{k+1} - \varphi_k||_1^2$  converge. Appelons  $\widetilde{\varphi}_k$  le prolongement de  $\varphi_k$  par 0 hors de  $\Omega$  et posons

$$e_k = \mathrm{E}_x(|\tilde{\varphi}_{k+1}(x) - \tilde{\varphi}_k(x)| > 1/2^k), \qquad \omega_j = \bigcup_{k=1}^{\infty} e_k;$$

d'après (1. 1) et (1. 4) on a :

$$\operatorname{cap}(\omega_j) \leqslant \sum_{k=j}^{\infty} \operatorname{cap}(e_k) \leqslant \frac{1}{a_n} \sum_{k=j}^{\infty} 4^k ||\varphi_{k+1} - \varphi_k||_1^2$$

donc cap  $(\omega_j)$  tend vers 0 avec 1/j. Mais dans  $\mathbb{R}^n - \omega_j$  la suite  $\{\tilde{\varphi}_k\}$  est uniformément convergente; donc  $\tilde{\varphi}_k$  converge quasi-partout vers une fonction  $F^*$ , dont la restriction à  $\mathbb{R}^n - \omega_j$  est continue;  $F^*$  possède donc la propriété (P).

Il reste à montrer que  $F^* = F$  presque partout dans  $\Omega$ ; or  $\varphi_k \to F$  dans  $\mathcal{E}^*_{4,2}(\Omega)$  si  $\Omega$  est borné (I, théorème 4. 2),  $\varphi_k \to F$  dans  $\mathcal{E}^*_{4,2}(\Omega)$  si n > 2 (I, théorème 4. 3); dans tous les cas considérés, si  $\psi$  est une fonction mesurable bornée à support compact,  $\int \varphi_k \psi \, dx \to \int F \psi \, dx$ ; mais si  $\psi$  est nulle dans  $\omega_j$  on a, d'après la convergence uniforme:

$$\int F^* \psi \, dx = \lim_{k \to \infty} \int \varphi_k \psi \, dx = \int F \psi \, dx;$$

(46) Deny [1] chap. IV; nous reproduisons, à quelques variantes près, la démonstration de cet article.

on a donc  $F^* = F$  presque partout sur  $\int \omega_j$  quel que soit j, et par suite presque partout dans  $\Omega$  (l'intersection des  $\omega_j$  étant polaire, donc de mesure nulle).

Remarque 3. 1. — La démonstration donne plus; la fonction  $F^*$  qui vient d'être construite possède la propriété (P) dans  $R^n$  tout entier; on peut donc énoncer, compte-tenu de la proposition 3. 1:

Si F est une fonction (BL) précisée de  $\widehat{\mathfrak{D}}_{i}^{\bullet}(\Omega)$ , avec  $\Omega$  borné si n=2, le prolongement de F par 0 est une fonction (BL) précisée dans  $\mathbb{R}^{n}$ .

Nous reviendrons plus loin (§ 5) sur ce résultat que nous étendrons facilement aux domaines plans non bornés.

Pseudo-limite et continuité fine. — La définition 3. 2 a le mérite de faire appel au minimum de notions de théorie du potentiel, mais pour une étude approfondie, notamment à la frontière, il nous sera utile de donner une définition équivalente mettant en jeu des propriétés plus subtiles.

A cet effet, rappelons qu'une fonction F(x), définie quasi-partout au voisinage de  $x_0$ , admet la pseudo-limite l en  $x_0$  s'il existe un ensemble e effilé en  $x_0$ , tel que  $\lim_{} F(x) = l(x \to x_0, x \notin e)$  (47). Si de plus  $F(x_0) = l \neq \infty$ , F est finement continue en  $x_0$  (48).

Nous renvoyons à M. Brelot [2] pour la définition et les principales propriétés des ensembles effilés. Rappelons simplement qu'un ensemble effilé en  $x_0$  est très rare, au point de vue métrique, au voisinage de  $x_0$ : pour l'instant les deux propriétés suivantes nous suffiront (\*9):

Proposition 3. 5. — Deux fonctions finement continues en  $x_0$  et presque partout égales au voisinage de  $x_0$  ont la même valeur en  $x_0$ .

Proposition 3. 6. — Toute fonction possédant la propriété (P) est quasi-partout finement continue.

Voici la caractérisation des fonctions (BL) précisées que nous avions en vue:

(47) Brelot [2]

<sup>(48)</sup> On trouvera dans Cartan [2] une étude détaillée de la « topologie fine ».
(49) La proposition 3.5 est une conséquence immédiate de la définition; la proposition 3. 6 est établie dans Deny [1] (chap IV, lemme 3).

Théorème 3. 2. — Pour qu'une fonction  $F \in BL(\Omega)$  soit une fonction (BL) précisée, il faut et il suffit qu'elle soit finement continue quasi-partout dans  $\Omega$ .

Démonstration. — La condition est nécessaire, d'après la proposition 3. 6. Soit inversement  $F \in BL(\Omega)$ , quasi-partout finement continue; soit  $F^*$  une fonction (BL) précisée égale à F presque partout dans  $\Omega$  (théorème 3. 1); on a  $F = F^*$  quasi-partout (proposition 3. 5), donc F est une fonction (BL) précisée (proposition 3. 1).

4. Un théorème de complétion. — Nous allons d'abord étendre le lemme 1. 1 aux fonctions (BL) précisées de  $\widehat{\mathfrak{D}}^{1}(\mathbb{R}^{n})$ :

Lemme 4. 1. — Soit F une fonction (BL) précisée de  $\widehat{\mathfrak{D}}^1(\mathbf{R}^n)$  nulle hors d'un compact de diamètre < 1 si n=2; soit e l'ensemble  $\mathbf{E}_x(|\mathbf{F}(x)| > \alpha > 0)$ ; on a:

(4, 1) 
$$\operatorname{cap}(e) \leqslant \frac{||\mathbf{F}||_{i}^{2}}{a_{n}\alpha^{2}}$$

Démonstration. — Soit  $\tilde{\mathbf{F}}$  le prolongement de  $\mathbf{F}$  par 0 hors de  $\Omega$ . D'après la démonstration du théorème 3. 1 et la proposition 3. 1, il existe une suite de fonctions  $\varphi_k \in \mathfrak{D}$ , nulles hors d'un même compact de diamètre < 1 si n = 2, telles que  $\varphi_k$  converge vers  $\tilde{\mathbf{F}}$  dans  $\widehat{\mathfrak{D}}^1(\mathbf{R}^n)$ , et que  $\varphi_k(x)$  converge uniformément vers  $\tilde{\mathbf{F}}(x)$  sur le complémentaire d'un ouvert  $\omega$  de capacité arbitrairement petite (cap  $(\omega) < \varepsilon$ ). Soit alors  $\varepsilon_1$ ,  $0 < \varepsilon_1 < \alpha$ ; soit  $e_k = \mathbf{E}_x(|\varphi_k(x)| > \alpha - \varepsilon_1)$ ; pour k assez grand, on a, d'après la convergence uniforme :  $e \in e_k \cup \omega$ , d'où, d'après (1, 1):

$$\operatorname{cap}(e) \leqslant \operatorname{cap}(\omega) + \operatorname{cap}(e_k) \leqslant \varepsilon + \frac{||\varphi_k||_1^2}{a_n(\alpha - \varepsilon_1)^2}$$

d'où (4, 1), en faisant tendre k vers  $+\infty$ ,  $\epsilon$  et  $\epsilon$ , vers 0.

Le théorème suivant montre que si  $\widehat{\mathfrak{D}}^{\mathfrak{l}}(\Omega)$  est un espace de distributions, l'ensemble des fonctions (BL) précisées de  $\widehat{\mathfrak{D}}^{\mathfrak{l}}(\Omega)$  constitue une classe hilbertienne *hypernormale* au sens de N. Aronszajn (50); l'introduction de ces fonctions résout donc

<sup>(50)</sup> Voir Aronszajn [1], Aronszajn et Smith [1].

le problème de la « complétion fonctionnelle parfaite » de  $\mathfrak{D}(\Omega)$ , normé par  $||\varphi||_{\mathfrak{l}} = \left(\int |\operatorname{grad} \varphi|^2 \, dx\right)^{\mathfrak{l}/2}$ .

Théorème 4.1. — Soit  $\Omega$  un domaine quelconque de  $R^n(n \ge 2)$ , de complémentaire non polaire si n=2; soit  $\{F_k\}$  une suite de fonctions (BL) précisées de  $\widehat{\mathfrak{D}}^1(\Omega)$  convergeant, au sens de la norme, vers une telle fonction F; on peut en extraire une suite partielle  $\{F_{kp}\}$  telle que  $F_{kp}(x)$  converge quasi-partout vers F(x) dans  $\Omega$ .

Démonstration. — Supposons d'abord que, si n=2,  $\Omega$  est borné et de diamètre < 1. En utilisant le lemme 4. 1 au lieu du lemme 1. 1, on voit, en suivant la méthode de démonstration du théorème 3. 1, qu'on peut extraire une suite partielle  $\{F_{kp}\}$  convergeant quasi-partout vers une fonction  $F^*$ , la convergence étant uniforme hors d'un ouvert  $\omega_1$  de capacité arbitrairement petite (il en est ainsi dès que  $\Sigma 4^p ||F_{kp+1} - F_{kp}||^2 < \infty$ ). Comme les  $F_k$  possèdent la propriété (P), il existe un ouvert  $\omega_2$  de capacité arbitrairement petite hors duquel toutes ces fonctions sont continues (d'après (1. 1)); en vertu de la convergence uniforme, F est continue hors de  $\omega_1 \cup \omega_2$ , qui est de capacité arbitrairement petite;  $F^*$  possède donc la propriété (P). Or on a  $F^* = F$  presque partout dans  $\Omega$  (comme pour la deuxième partie de la démonstration du théorème 3. 1), donc quasi-partout (proposition 3. 2), d'où le résultat.

Il reste à examiner le cas où  $\Omega$  est un domaine plan quelconque, de complémentaire non polaire; on sait que  $F_k$  converge
encore vers F dans  $\mathfrak{D}'(\Omega)$  (I, proposition 4. 1). L'ouvert  $\Omega$  est
réunion dénombrable de domaines  $\omega_i$  de diamètres < 1. A chaque  $\omega_i$  associons des domaines  $\omega_i'$  et  $\omega_i''$  tels que  $\bar{\omega}_i \subset \omega_i' \subset \bar{\omega}_i' \subset \omega_i''$ , le diamètre de  $\omega_i''$  étant < 1. Soit  $\rho \in \mathfrak{D}(\omega')$ , = 1 dans  $\omega$ . On a:  $F_k \rho_i \in \widehat{\mathfrak{D}}^1(\omega_i'')$ ; en effet  $\overline{\operatorname{grad}}(F_k \rho_i) = F_k \overline{\operatorname{grad}} \rho_i + \rho_i \overline{\operatorname{grad}} F_k \in L^2$ ,
car  $F_k \in L^2_{loc}(\mathbb{R}^2)$ , et on peut construire, par régularisation, une
suite de fonctions de  $\mathfrak{D}(\omega_i'')$  convergeant vers  $F_k$  dans  $BL(\mathbb{R}^2)$ .

De même  $F \rho_i \in \widehat{\mathfrak{D}}^1(\omega_i'')$ ;  $F_k \rho_i \to F \rho_i$  dans cet espace lorsque  $k \to +\infty$ , car

$$||F_k\rho_i - F\rho_i||_1 \le ||F_k - F||_1 \sup |\rho_i| + ||F_k - F_i||_{L^2(\omega_i^p)} \sup |\overline{\operatorname{grad}} \rho_i|$$
  
tend vers 0 avec  $1/k$ . D'après la première partie de la démonstration, on peut extraire, pour tout  $i$ , une suite partielle  $F_{k\rho}$  telle

que  $F_{kp}\rho_i \rightarrow F\rho_i$  quasi-partout dans  $\omega_i''$ , donc  $F_{kp} \rightarrow F$  quasi-partout dans  $\omega_i$ ; par le procédé diagonal, on obtient finalement une suite partielle convergente quasi-partout vers F.

Voici une application aux suites convergentes de fonctions (BL) précisées dans un domaine quelconque:

Théorème 4. 2. — Soit  $\{F_k\}$  une suite de fonctions (BL) précisées dans  $\Omega$ , domaine quelconque de  $R^n(n \ge 2)$ , convergente au sens de la semi-norme de  $BL(\Omega)$ ; si  $F_k(x)$  converge quasipartout, la limite F(x) est une fonction (BL) précisée dans  $\Omega$ , et de plus  $||F - F_k||_1 \to 0$ .

Démonstration. — Soit G une fonction (BL) précisée telle que  $||F_k - G||$ , tende vers 0 avec 1/k; il existe une constante  $C_k$  telle que  $F_k + C_k \rightarrow G$  dans  $L^2_{loc}(\Omega)$  (I, th. 2. 2). Soient  $\omega$ ,  $\omega'$ ,  $\omega''$  trois domaines bornés, contenant chacun l'adhérence du précédent, avec  $\omega'' \subset \Omega$ ; soit  $\rho \in \mathcal{D}(\omega')$ ,  $\rho = 1$  dans  $\omega$ . Comme on a déjà vu,  $(F_k + C_k)\rho$  et  $G\rho$  sont dans  $\widehat{\mathcal{D}}^1(\omega'')$ , et  $(F_k + C_k)\rho \rightarrow G\rho$  dans cet espace. D'après le théorème 4. 1, on peut trouver une suite partielle convergeant quasi-partout vers  $G\rho$  dans  $\omega''$ ; les  $F_k + C_k$  correspondantes convergent quasi-partout vers G dans  $\omega$ ; comme par hypothèse  $F_k$  converge quasi-partout (vers F),  $C_k$  admet une limite finie C; donc F, qui est quasi-partout égale à G-C dans  $\omega$  est (BL) précisée dans  $\omega$ , d'où le résultat,  $\omega$  étant un domaine relativement compact arbitraire de  $\Omega$ .

5. Le problème de Dirichlet fin. — Pour obtenir des énoncés de topologie fine, valables dans le cas de domaines non bornés, il nous est indispensable de faire appel à la notion d'ensemble effilé à l'infini et de pseudo-limite à l'infini. Nous renvoyons encore à M. Brelot [3] pour les définitions, d'où il résulte que, dans  $\mathbb{R}^n$  avec  $n \geq 3$ , tout ensemble de capacité extérieure finie est effilé à l'infini (50 bis); cette remarque jet le lemme 4. 1 conduisent au résultat suivant:

Lemme 5. 1. — Toute fonction (BL) précisée de  $\widehat{\mathfrak{D}}^{1}(\Omega)$ , avec  $n \geqslant 3$ , admet la pseudo-limite 0 à l'infini.

<sup>(50</sup> bis) On peut même montrer que, pour  $n \ge 3$ , il y a identité entre les ensembles effilés à l'infini et les ensembles de capacité extérieure finie.

Voici maintenant une caractérisation des fonctions précisées de  $\widehat{\mathfrak{D}}^{\iota}(\Omega)$ , valable sauf si  $\Omega$  est un domaine plan de complémentaire polaire :

Théorème 5. 1. — Soit  $\Omega$  un domaine quelconque de  $\mathbb{R}^n$ ,  $n \geqslant 2$ , de complémentaire non polaire si n=2; pour qu'une fonction précisée de  $\mathrm{BL}(\Omega)$  soit dans  $\widehat{\mathfrak{D}}^1(\Omega)$ , il faut et il suffit qu'elle admette la pseudo-limite 0 quasi-partout à la frontière, et à l'infini si  $n \geqslant 3$  (51).

Seuls les points-frontière où  $\Omega$  n'est pas effilé interviennent dans cet énoncé; l'ensemble de ces points est non polaire si la frontière est non polaire (mais l'ensemble des points-frontière où  $\Omega$  est effilé peut aussi être non polaire, et même de mesure positive). De même la partie de l'énoncé relative au point à l'infini est vide de contenu si  $\Omega$  est borné ou effilé à l'infini.

Démonstration. — On a déjà vu que la condition est nécessaire si  $n \geqslant 3$  ou si  $\Omega$  est un domaine plan de diamètre < 1: cela résulte de la remarque 3. 1 et du théorème 3. 2 pour les points à distance finie, et du lemme 5. 1 pour le point à l'infini. Il reste à examiner le cas d'un domaine plan quelconque (de complémentaire non polaire). Soit F une fonction précisée de  $\widehat{\mathfrak{D}}^1(\Omega)$ ; considérons trois domaines  $\omega$ ,  $\omega'$  et  $\omega''$ , chacun contenant l'adhérence du précédent,  $\omega''$  étant de diamètre < 1; si  $\rho \in \mathfrak{D}(\omega')$ , on a  $F\rho \in \widehat{\mathfrak{D}}^1(\Omega \cap \omega'')$  ( $^{52}$ ); on est alors ramené au cas déjà connu :  $F\rho$  admet la pseudo-limite 0 quasi-partout à la frontière de  $\Omega \cap \omega''$ ; en prenant  $\rho = 1$  dans  $\omega$ , on voit que F admet la pseudo-limite 0 quasi-partout sur  $\widehat{\Omega} \cap \omega$ , et par suite sur  $\widehat{\Omega}$  tout-entier.

Soit inversement F une fonction précisée de BL  $(\Omega)$ , admettant la pseudo-limite 0 quasi-partout à la frontière et à l'infini (pour  $n \geqslant 3$  et  $\Omega$  non borné ni effilé à l'infini). On va voir que  $F \in \widehat{\mathcal{D}}^{1}(\Omega)$ ; on peut évidemment supposer F réelle. Supposons

<sup>(51)</sup> Une autre caractérisation des fonctions précisées de  $\widehat{\mathfrak{D}}^1(\Omega)$  est la suivante : ce sont les fonctions précisées de  $\mathrm{BL}(\Omega)$  dont la radiale est nulle (voir Brelot [5] [6] et [7]); d'autre part on peut interpréter ces fonctions comme des « potentiels d'énergie finie par rapport à la fonction de Green » (voir Deny [1], où le cas  $n=2,\Omega$  non borné n'est pas traité).

<sup>(52)</sup> Fo est dans  $BL(\Omega \cap \omega'')$  et est nulle hors d'un compact de  $\Omega \cap \omega''$ ; elle est donc limite dans  $BL(\Omega \cap \omega'')$  de régularisées qui, étant nulles hors d'un compact de  $\Omega \cap \omega''$ , sont dans  $\mathfrak{D}(\Omega \cap \omega'')$ .

d'abord F bornée; alors (I, théorème 4. 5), F = u + H, avec  $u \in \widehat{\mathfrak{D}}^1(\Omega)$  et H harmonique dans  $\Omega$ ; mais H est bornée (d'après I, théorème 4. 7); d'après la première partie de la démonstration (nécessité), H = F - u admet la pseudo-limite 0 quasi-partout à la frontière (et éventuellement à l'infini); un théorème récent de M. Brelot (53) entraîne que H = 0, d'où  $F = u \in \widehat{\mathfrak{D}}^1(\Omega)$ . Si F est non borné, considérons  $F_N(x) = F(x)$  si |F(x)| > N, = N si F(x) > N, = -N si F(x) < -N; c'est une fonction précisée de  $BL(\Omega)$  (d'après I, proposition 3. 1 et II, proposition 3. 3), bornée et satisfaisant aux conditions de l'énoncé; donc  $F_N \in \widehat{\mathfrak{D}}^1(\Omega)$ , et il en est de même de F, puisque  $||F - F_N||_1 \to 0$  avec 1/N (I, proposition 3. 2).

Le théorème 5. 1 montre que la « partie harmonique » H d'une fonction précisée  $F \in BL(\Omega)$  a même comportement à la frontière (au point de vue de la topologie fine) que la fonction F, puisque la différence F — H admet quasi-partout à la frontière la pseudo-limite 0. En particulier, si F admet en quasi-tout point frontière x une pseudo-limite f(x), on voit que F est la fonction harmonique (unique) qui résout ce qu'on peut appeler le « problème de Dirichlet fin » pour F0 avec donnée-frontière F1.

Un cas particulier intéressant où on peut affirmer que toute fonction précisée de  $BL(\Omega)$  admet une pseudo-limite quasipartout à la frontière est celui d'un domaine suffisamment régulier:

Théorème 5. 2. — Si le domaine borné  $\Omega$  vérifie les hypothèses  $(\Pr. 1)$  et  $(\Pr. 2)$  (voir  $I, \S 7$ ) toute fonction précisée de  $BL(\Omega)$  admet une pseudo-limite finie quasi-partout à la frontière.

Démonstration. — En effet une telle fonction F peut être prolongée par une fonction  $\tilde{F} \in BL(R^n)$ , qu'on peut supposer précisée (I, théorème 8. 1);  $\tilde{F}$  admet donc une pseudo-limite finie quasi-partout dans  $R^n$  (théorème 3. 2), en particulier quasi-partout sur la frontière de  $\Omega$ , et il en est de même de F, restriction de  $\tilde{F}$  à  $\Omega$ .

En particulier:

Remarque 5. 1. — Toute fonction (BL) précisée dans une boule de R<sup>n</sup> admet une limite radiale finie le long de tout rayon,

<sup>(53)</sup> Brelot [4] (lemme 1).

sauf le long de certains rayons découpant sur la frontière un ensemble polaire (54).

6. Représentation intégrale canonique des fonctions (BL) précisées. — Etant donné un domaine  $\Omega$  (de complémentaire non polaire si n=2), nous allons former une intégrale convergeant quasipartout, dont la valeur est une fonction (BL) précisée représentant la «projection» de F sur  $\widehat{\mathfrak{D}}^1(\Omega)$ . A F on pourra donc associer canoniquement une fonction précisée presque partout égale à F: la somme de l'intégrale précédente et de la partie harmonique de F.

Lemme 6. 1. — Soit  $\vec{i} \in [L^2(\mathbb{R}^n)]^n$  un vecteur dont les composantes sont des fonctions de carré sommable dans  $\mathbb{R}^n$ , nulles hors d'un compact si n=2; l'intégrale:

$$f(x) = \int \overrightarrow{\operatorname{grad}}_x h(x-t) \cdot \overrightarrow{i}(t) dt$$

est quasi-partout absolument convergente; elle représente une fonction possédant la propriété (P) dans  $R^n$ .

On trouvera la démonstration d'un énoncé plus général, concernant le cas où  $\tilde{i} \in [L^p(\mathbb{R}^n)]^n$ , avec  $1 \le p \le 2$ , dans Deny [2]; par contre le cas n = p = 2, qui demande une adaptation, d'ailleurs facile, n'est pas traité; nous ne reviendrons pas ici sur la démonstration.

Théorème 6. 1. — Soit  $\hat{i} \in [L^2(\Omega)]^n$ ,  $\Omega$  étant un domaine quelconque de  $\mathbb{R}^n$ , de complémentaire non polaire si n=2; l'intégrale:

$$f(x) = \int \overrightarrow{\operatorname{grad}}_x \mathcal{C}_i(x, t) \cdot \overrightarrow{i}(t) dt$$

converge quasi-partout; c'est une fonction précisée de  $\widehat{\mathfrak{D}}^{i}(\Omega)$ .

Démonstration. — Supposons d'abord  $\hat{i}$  à support compact dans  $\Omega$ ; en observant que la fonction de Green  $\mathcal{G}(x, y)$  est de la forme  $\mathcal{G}(x, y) = h(x - y) - g(x, y)$ , où g(x, y) est harmonique régulière en  $y \in \Omega$  (pour x fixe), on voit que f(x) est la somme d'une fonction harmonique et d'une intégrale du type

<sup>(54)</sup> Lorsque la fonction BL est harmonique dans un cercle on retrouve un théorème connu de Beurling [1]; pour le cas plus général d'une fonction (BL) continue, voir Deny [1].

considéré dans le lemme 6. 1; f(x) possède donc la propriété (P). Soit d'autre part  $\vec{i}_k \in [\mathfrak{D}(\Omega)]^n$ , convergeant vers  $\vec{i}$  dans  $[L^2(\Omega)]^n$ ; considérons la fonction indéfiniment dérivable

$$f_k(x) = \int \overrightarrow{\operatorname{grad}}_x \mathcal{C}_{\ell}(x, t) \cdot \overrightarrow{i_k}(t) dt;$$

d'après (1, 5) et (1, 6),  $f_k$  est dans  $\operatorname{BL}(\Omega)$ , et même dans  $\widehat{\mathfrak{D}}^1(\Omega)$ , d'après le théorème 5. 1 (elle admet la pseudo-limite 0 quasipartout à la frontière, comme tout potentiel de Green engendré par une mesure à support compact dans  $\Omega$ ); or  $f_k$  converge dans  $\widehat{\mathfrak{D}}^1(\Omega)$  (toujours d'après (1, 5) et (1, 6),  $\{f_k\}$  est une suite de Cauchy dans cet espace), et par suite dans  $\mathfrak{D}'(\Omega)$ , vers un élément de  $\widehat{\mathfrak{D}}^1(\Omega)$  qui n'est autre que f, car il est évident que  $f_k$  converge vers f dans  $\mathfrak{D}'(\Omega)$ ; on a donc bien  $f \in \widehat{\mathfrak{D}}^1(\Omega)$  et de plus  $||f||_1 = \lim ||f_k||_1$ , d'où:

$$(6, 1) \qquad ||f||_{\mathfrak{s}}^{2} \leqslant a_{n}^{2} \int |\hat{i}(t)|^{2} dt.$$

Dans le cas général, on pose  $\tilde{i} = \Sigma \tilde{i}_k$ , où  $\tilde{i}_k$  est à support compact et disjoint de tout compact  $K \subset \Omega$  pour  $k \geqslant k_0 = k_0(K)$  assez grand. D'après (6, 1) la série  $\Sigma f_k = \Sigma \int \overline{\operatorname{grad}}_x \mathcal{G}(x, t) \cdot \tilde{i}_k(t) dt$  converge dans  $\widehat{\mathfrak{D}}^i(\Omega)$  donc  $\sum_{k=k_0}^\infty f_k(x)$  converge uniformément sur K (les  $f_k(x)$  étant harmoniques au voisinage de K, et convergeant au sens des distributions dans un tel voisinage). Finalement on voit que la série  $\Sigma f_k(x)$  converge quasi-partout dans  $\Omega$  (en tout point x où les intégrales  $f_k(x)$  sont absolument convergentes); la somme f(x) est une fonction précisée de  $\widehat{\mathfrak{D}}^i(\Omega)$ , satisfaisant à l'inégalité (6, 1).

Voici maintenant la représentation de la fonction précisée associée canoniquement à une fonction  $F \in BL(\Omega)$ :

Théorème 6. 2. — Soit  $F \in BL(\Omega)$ ,  $\Omega$  domaine quelconque de  $R^n$ , de complémentaire non polaire si n=2; si H est la partie harmonique de F, la fonction

$$F^*(x) = H(x) - \frac{1}{a_n} \int \overrightarrow{grad}_x \mathcal{G}(x, t) \cdot \overrightarrow{grad} F(t) dt,$$

qui est définie quasi-partout dans  $\Omega$ , est une fonction (BL) précisée presque partout égale à F.

Démonstration. — La fonction

$$f(x) = -\frac{1}{a_x} \int \overrightarrow{\operatorname{grad}}_x \mathcal{C}(x, t) \cdot \overrightarrow{\operatorname{grad}} F(t) dt$$

est une fonction précisée de  $\widehat{\mathfrak{D}}^{1}(\Omega)$  (théorème 6. 1); tout revient donc à montrer que F - f est presque partout égale à une fonction harmonique (unicité de la décomposition I (4, 2)), ou encore que les distributions  $\Delta F$  et  $\Delta f$  sont identiques. Pour cela considérons  $\overrightarrow{i_k} \in [\mathfrak{D}(\Omega)]^n$ ,  $\overrightarrow{i_k} \to \overline{\operatorname{grad}} F$  dans  $[L^2(\Omega)]^n$ , et posons:

$$f_{\mathbf{k}}(x) = -\frac{1}{a_n} \int \overrightarrow{\operatorname{grad}}_x \, \mathcal{G}(x, t) \cdot \overrightarrow{i_k}(t) \, dt = -\frac{1}{a_n} \operatorname{U}^{\operatorname{div} \, \overrightarrow{i_k}}(x)$$

D'après  $(6, 1), f_k \to f$  dans  $\widehat{\mathfrak{D}}^1(\Omega)$ , donc dans  $\widehat{\mathfrak{D}}'(\Omega)$ , et par suite  $\Delta f_k \to \Delta f$  dans  $\widehat{\mathfrak{D}}'(\Omega)$ ; or  $\Delta f_k = \operatorname{div} \widehat{i_k} \to \operatorname{div} \left( \overline{\operatorname{grad}} \ F \right) = \Delta F$ , d'où le résultat.

Remarque 6. 1. — Lorsque  $\Omega = \mathbb{R}^n$  avec  $n \geqslant 3$ , la fonction (BL) précisée canoniquement associée à F est

$$F^*(x) = C - \frac{1}{a_n} \int \overrightarrow{\operatorname{grad}}_x h(x-t) \cdot \overrightarrow{\operatorname{grad}} F(t) dt,$$

où la constante C est la pseudo-limite à l'infini de n'importe quelle fonction précisée presque partout égale à F ( $^{55}$ ); il n'y a pas de résultat analogue pour n=2, une fonction précisée de BL ( $\mathbb{R}^2$ ) n'admettant pas toujours de pseudo-limite à l'infini.

<sup>(55)</sup> C est la constante telle que  $F - C \in L^q(\mathbb{R}^n)$  (voir I, no 5).

## III. — ESPACE $BL_m^{\bullet}(E)$ .

#### 1. Lemme.

Lemme 1. 1. — Soit  $T_{\alpha}$  un filtre de distributions sur  $\Omega$ , ouvert connexe quelconque de  $R^n$ , tel que  $\frac{\delta}{\delta x_i}T_{\alpha}$  soit convergent dans  $\mathfrak{D}'_{\Omega}$  pour tout i (alors par le théorème 1. 1,  $\S 1$ ,  $\frac{\delta}{\delta x_i}T_{\alpha}$  converge vers  $\frac{\delta}{\delta x_i}T$ ,  $T \in \mathfrak{D}'_{\Omega}$ ). Dans ces conditions il existe une famille de constantes  $c_{\alpha}$  telles que  $T_{\alpha} + c_{\alpha}$  converge dans  $\mathfrak{D}'_{\Omega}$ .

Démonstration. — a) Soit K un cube ouvert contenu dans  $\Omega$ . Pour fixer les idées on suppose que  $K = (]0, 1[)^n$ . On introduit n fonctions  $a_1, a_2, \ldots, a_n$ , où  $a_i$  est une fonction indéfiniment différentiable sur ]0, 1[, à support compact, de masse totale 1, i.e.

$$\int_0^1 a_i(t) dt = 1.$$

Soit alors f un élément quelconque de  $\mathfrak{D}_{K}$ . On désigne par  $f_{i}$  la fonction :

$$(x_2,\ldots,x_n) \longrightarrow f_1(x_2,\ldots,x_n) = \int_0^1 f(t,x_2,\ldots,x_n) dt.$$

Cette fonction est dans l'espace  $\mathfrak{D}_{K_1}$ ,  $K_1 = (]0, 1[)^{n-1}$ , les variables étant  $x_2, \ldots, x_n$ . Si alors l'on considère la fonction  $g_1 = f - a_1 f_1$ , elle est dans  $\mathfrak{D}_K$  et vérifie :

$$\int_0^1 g_1(t, x_2, \ldots, x_n) dt = 0.$$

Si donc l'on pose:

$$h_{\scriptscriptstyle 1}(x) = \int_{\scriptscriptstyle 0}^{x_{\scriptscriptstyle 1}} g_{\scriptscriptstyle 1}(t, x_{\scriptscriptstyle 2}, \ldots, x_{\scriptscriptstyle n}) dt,$$

on définit ainsi un élément de DK, donc:

$$(1, 1) f = a_1 f_1 + \frac{\delta}{\delta x_1} (h_1), \quad h_1 \in \mathfrak{D}_K.$$

On considère maintenant  $f_i$  dans  $\mathfrak{D}_{\kappa_i}$ ; elle admet une décomposition du type (1, 1):

$$f_1 = a_1 f_2 + \frac{\delta}{\delta x_2} (h_2), \quad h_2 \in \mathfrak{D}_{K_1}, \quad f_2 \in \mathfrak{D}_{K_2}, \quad \text{où}: \quad K_2 = (]0,1[)^{n-2},$$

les variables étant  $x_3, \ldots, x_n$ 

On a donc:

$$f = a_1 a_2 f_2 + \frac{\delta}{\delta x_2} (a_1 h_2) + \frac{\delta}{\delta x_1} (h_1),$$

et ainsi de suite. Finalement :

$$(1, 2) \quad f = a_1 a_2 \dots a_n f_n + \frac{\delta}{\delta x_n} (a_1 \dots a_{n-1} h_n) + \dots + \frac{\delta}{\delta x_i} (h_i),$$

$$\text{avec}: \qquad \qquad f_n = \int f(x) \, dx.$$

b) Considérons alors la famille  $T_{\alpha}$  et considérons les restrictions (encore notées  $T_{\alpha}$ ) de  $T_{\alpha}$  à K. Si  $f \in \mathfrak{D}_{K}$ , on a :

$$\frac{\partial}{\partial x_i} T_{\alpha}(f) \rightarrow \frac{\partial}{\partial x_i} T(f)$$
, pour tout  $i = 1, ..., n$ .

Décomposons f suivant (1, 2). On a alors :

$$T_{\alpha}(f) = f_n T_{\alpha}(a_1 a_2 \dots a_n) - \sum_{i=1}^n \frac{\partial}{\partial x_i} T_{\alpha}(a_1 \dots a_{i-1} h_i).$$

Si l'on pose:

$$T_{\alpha}(a_1a_2\ldots a_n)=-c_{\alpha}(K), \qquad T(a_1\ldots a_n)=-c(K),$$

on a:

$$\langle T_{\alpha} + c_{\alpha}(K), f \rangle = -\sum_{i=1}^{n} \frac{\delta}{\delta x_{i}} T_{\alpha}(a_{1} \dots a_{i-1}h_{i})$$

tend vers

$$-\sum_{i=1}^{n} \frac{\partial}{\partial x_i} \mathbf{T}(a_1 \dots a_{i-1}h_i) = \langle \mathbf{T} + c(\mathbf{K}), f \rangle,$$

et ceci pour f dans  $\mathfrak{D}_{\kappa}$ , uniformément lorsque f parcourt un ensemble borné de cet espace.

Donc 
$$T_{\alpha} + (c_{\alpha}(K) - c(K)) \rightarrow T$$
 dans  $\mathfrak{D}'_{\kappa}$ ,

donc: pour tout cube ouvert K contenu dans  $\Omega$ , il existe une famille de constantes  $d_{\alpha}(K)$ , dépendant de K, telles que

$$T_{\alpha} + d_{\alpha}(K) \rightarrow T$$
 dans  $\mathfrak{D}'_{K}$ .

c) Soit alors K et K' deux cubes ouverts de  $\Omega$ , d'intersection non vide. Il existe, d'après b), une famille  $c_{\alpha}$  (resp.  $c'_{\alpha}$ ) telle que:

$$T_{\alpha} + c_{\alpha} \rightarrow T$$
 dans  $\mathfrak{D}'_{K}$  (resp.  $T_{\alpha} + c'_{\alpha} \rightarrow T$  dans  $\mathfrak{D}'_{K'}$ ).

On en déduit par restriction à  $K \cap K'$ , et en faisant la différence:  $c_{\alpha} - c'_{\alpha} \rightarrow 0$  (dans le corps des complexes), donc  $T_{\alpha} + c_{\alpha} \rightarrow T$  dans  $\mathfrak{D}'_{KUK'}$ ; on en déduit aussitôt le lemme.

2. Espace  $BL_m(E)$ . — On donne sur  $\Omega$ , ouvert connexe quelconque de  $R^n$ , un espace E, comme au § 1, No 1, séparé et complet. On désigne par  $BL_m(E)$  l'espace des distributions  $T \in \mathcal{D}'_{\Omega}$  telles que  $D^pT \in E$  pour tout p avec |p| = m, muni de la topologie la moins fine telle que les applications  $T \to D^pT$  soient continues de  $BL_m(E)$  dans E. Cet espace coı̈ncide avec BL(E) si  $m = 1 : BL_1(E) = BL(E)$ .

L'espace  $\operatorname{BL}_m(E)$   $(m \geqslant 1)$  n'est pas séparé. Soit  $\operatorname{W}$  l'adhérence de 0 dans cet espace;  $T \in \operatorname{W}$  équivaut à  $\operatorname{D}^p T = 0$  pour tout p avec |p| = m, donc équivaut à  $T = \operatorname{polynome}$  de degré m-1. Donc:  $\operatorname{W} = \operatorname{sous-espace}$  des polynomes de degré m-1.

Définition 2.1. — L'espace  $\operatorname{BL}_m(E)$  est dit espace de Beppo-Levi d'ordre m attaché à E. On désigne par  $\operatorname{BL}_m$  (E) l'espace quotient de  $\operatorname{BL}_m(E)$  par % (espace séparé associé).

On va maintenant démontrer le

Théorème 2. 1. — L'espace BL<sub>m</sub> (E) est complet.

Démonstration. — a) Soit  $T^{\bullet}_{\alpha}$  un filtre de Cauchy sur  $BL^{\bullet}_{m}$  (E), et prenons  $T_{\alpha}$  quelconque dans la classe  $T_{\alpha}$ . On pose:

$$D^q T_\alpha = S_{\alpha, q}$$

Pour q avec |q| = m - 1,  $S_{\alpha, q}$  est dans  $BL_{\iota}(E)$  et

$$S_{\alpha,q}^{\bullet} \in BL_{1}^{\bullet}(E) = BL^{\bullet}(E)$$

est un filtre de Cauchy dans cet espace qui est complet (I, Théorème 1. 1), donc :

$$S_{\alpha,q}^{\bullet} \rightarrow S_q^{\bullet}$$
 dans  $BL^{\bullet}(E)$ .

Il en résulte, grâce au lemme 1. 1, qu'il existe une famille de constantes  $c_{\alpha, q}$  telles que

$$S_{\alpha,q} + c_{\alpha,q} \rightarrow S_q$$
 dans  $\mathfrak{D}'_{\Omega}$ .

Désignons maintenant par (q) le nombre tel que  $\mathrm{D}^q((q)\ x^q)=1$ , et posons :

(2, 1) 
$$T_{\alpha}^{1} = T_{\alpha} + \sum_{|q|=m-1} c_{\alpha,q}(q)x_{q}$$

On a:

$$(2, 2) D^{q}(\mathbf{T}_{\alpha}^{1}) \rightarrow \mathbf{S}_{q} dans \, \mathfrak{D}_{\Omega}^{\prime},$$

q quelconque tel que |q| = m - 1.

(b) Démonstration du théorème dans le cas:  $E=\mathfrak{D}'_{\Omega}$ .

On opère par récurrence sur m. Le théorème est vrai pour m = 1. Admettons le pour 2, ..., m - 1, et démontrons le pour m.

Soit  $T^{\bullet}_{\alpha}$  un filtre de Cauchy dans  $BL^{\bullet}_{m}(\mathfrak{D}'_{\Omega})$ ; on a (2,1) et (2, 2);  $T^{\bullet}_{\alpha}$  est dans  $BL_{m-1}(\mathfrak{D}'_{\Omega})$ , et (2, 2) signifie que  $(T^{\bullet}_{\alpha})^{\bullet}$  est un filtre de Cauchy dans  $BL_{m-1}(\mathfrak{D}'_{\Omega})$ , donc, grâce à l'hypothèse de récurrence:  $(T^{\bullet}_{\alpha})^{\bullet} \to T^{\bullet}$  dans  $BL_{m-1}(\mathfrak{D}'_{\Omega})$ , donc:  $D^{q}(T^{\bullet}_{\alpha}) \to D^{q}(T)$  dans  $\mathfrak{D}'_{\Omega}$  pour tout q, |q| = m-1.

Si maintenant p est quelconque avec |p| = m, il existe q avec

$$|q| = m - 1$$
 tel que  $D^p = \frac{\delta}{\delta x_i} D^q$ , donc:

$$\mathrm{D}^p(\mathrm{T}_{\mathbf{z}}) = \frac{\mathrm{d}}{\mathrm{d}x_i}(\mathrm{D}^q\mathrm{T}_{\mathbf{z}}) = \frac{\mathrm{d}}{\mathrm{d}x_i}(\mathrm{D}^q\mathrm{T}_{\mathbf{z}}^{\scriptscriptstyle (i)}) \to \frac{\mathrm{d}}{\mathrm{d}x_i}\mathrm{D}^q\mathrm{T} = \mathrm{D}^p\mathrm{T},$$

 $\mathbf{donc}\ T_{\alpha}^{\raisebox{0.1ex}{$\scriptscriptstyle\bullet$}} \to T^{\raisebox{0.1ex}{$\scriptscriptstyle\bullet$}}\ \mathrm{dans}\ \mathrm{BL}_{m}^{\raisebox{0.1ex}{$\scriptscriptstyle\bullet$}}(\mathfrak{T}_{\Omega}')\ c.\ q.\ f.\ d.$ 

c) Cas général.

Soit  $T^{\bullet}_{\alpha}$  un filtre de Cauchy dans  $BL^{\bullet}_{m}(E)$ . On a (2,1) et (2,2). Comme par le b),  $BL^{\bullet}_{m-1}(\mathfrak{D}'_{\Omega})$  est complet, il résulte de (2,2) que :  $D^{q}(T^{\bullet}_{\alpha}) \to D^{q}(T)$  dans  $\mathfrak{D}'^{\bullet}_{\Omega}$ , |q| = m - 1, donc, comme dans le cas b,  $D^{p}T_{\alpha} \to D^{p}T$  dans  $\mathfrak{D}'_{\Omega}$ , p quelconque avec |p| = m. Or,  $T^{\bullet}_{\alpha}$  étant un filtre de Cauchy dans  $BL^{\bullet}_{m}(E)$ , on a :  $D^{p}T \to f_{p}$  dans E, |p| = m, donc  $f_{p} = D^{p}T$  et finalement :  $D^{p}T_{\alpha} \to D^{p}T$  dans E, ce qui démontre le théorème.

Remarque finale. — Le cas  $E = L^2(\Omega)$  est particulièrement intéressant (on posera alors  $BL_m(L^2(\Omega)) = BL_m(\Omega)$ ); introduisons  $\widehat{\mathfrak{D}}^m(\Omega)$  espace complété de  $\mathfrak{D}_{\Omega}$  pour la norme  $||\varphi||_m$ ; il est facile d'étendre le théorème de décomposition 4. 5 (chap. I):

 $Si \widehat{\mathfrak{D}}^m(\Omega)$  est un espace de distributions, toute distribution  $T \in BL_m(\Omega)$  admet une décomposition unique: T = u + h, où  $u \in \widehat{\mathfrak{D}}^m(\Omega)$ ,  $\Delta^m h = 0$ .

Le problème important est donc de caractériser les ouverts connexes  $\Omega$  tels que  $\widehat{\mathfrak{D}}^m(\Omega)$  soit un espace de distributions; il est facile de voir qu'il en est ainsi lorsque  $\Omega$  est borné, ou lorsque  $n \geq 2m+1$ ; pour atteindre le cas n < 2m+1,  $\Omega$  non borné, il faut introduire une définition appropriée des ensembles polaires (d'ordre m) et des méthodes différentes de celles utilisées au chapitre II; cela nécessite quelques développements, sur lesquels nous nous proposons de revenir dans un prochain travail.

#### TABLEAU DES PRINCIPALES NOTATIONS ET DÉFINITIONS

```
\mathfrak{D} \subset E \subset \mathfrak{D}', E complet, \mathfrak{D} = \mathfrak{D}_{\Omega}, \mathfrak{D}' = \mathfrak{D}'_{\Omega}, \Omega \subset \mathbb{R}^n.
\mathrm{BL}(\mathrm{E}): \mathrm{T} \in \mathfrak{D}', \ \frac{\mathrm{d}}{\mathrm{d}x_i} \mathrm{T} \in \mathrm{E} \ \mathrm{pour} \ \mathrm{tout} \ i=1,...,n.
BL*(E): espace séparé associé à BL(E).
BL(\Omega) ou BL: espace BL(E), avec E = L^2(\Omega).
\mathrm{BL}_0^{\:\raisebox{3.5pt}{\text{\circle*{1.5}}}}(\Omega) : adhérence de \mathfrak{D}_\Omega^{\:\raisebox{3.5pt}{\text{\circle*{1.5}}}} dans \mathrm{BL}^{\:\raisebox{3.5pt}{\text{\circle*{1.5}}}}(\Omega).
\widehat{\mathfrak{D}}^1(\Omega): \text{complété de } \mathfrak{D}_\Omega \text{ pour } \|\phi\|_1 = \bigg(\Sigma \bigg\|\frac{\delta \phi}{\delta x_i}\bigg\|^2\bigg)^{1/2}.
\mathcal{E}^{1}_{L^{2}}(\Omega): u \in L^{2}(\Omega), \ \frac{\partial}{\partial x_{i}} u \in L^{2}(\Omega) \text{ pour tout } i.
\mathcal{E}^1_{q,\,2}(\Omega): u \in \mathrm{L}^q(\Omega), \, \frac{\partial}{\partial x_i} u \in \mathrm{L}^2(\Omega), \, 1/q = 1/2 - 1/n, \, n \geqslant 3.
\mathfrak{D}^{1}_{L^{2}}(\Omega): adhérence de \mathfrak{D}_{\Omega} dans \mathfrak{E}^{1}_{L^{2}}(\Omega).
\mathfrak{D}_{q,2}^{1}(\Omega): adhérence de D_{\Omega} dans \mathcal{E}_{q,2}^{1}(\Omega).
Propriété (AC): p. 314; propriété (P): p. 353.
Problème de Dirichlet (fin): p. 323 (p. 342); problème de Neumann: p. 360.
Ouvert de Soboleff: p. 327; ouvert de Nikodym: p. 328.
 Inégalité de Poincaré: p. 329.
h(x) (noyau newtonien): |x|^{2-n} si n > 2, -\log |x| si n = 2.
U^{\mu}, U^{f}: potentiels newtoniens.
a_n (flux élémentaire) : p. 345.
Ensembles polaires, quasi-partout: p. 345.
 I(\mu), J(\mu, \nu) (énergie, énergie mutuelle) : p. 346.
\mathcal{G}(x, y) (function de Green): p. 348.
 I_{\Omega}(\mu), J_{\Omega}(\mu, \nu) : p. 349.
Fonction (BL) précisée : p. 354.
Pseudo-limite: p. 355.
```

#### BIBLIOGRAPHIE

- [1] Aronszajn, Noyaux pseudo-reproduisants et complétion des classes hilbertiennes, C.R. Acad. des Sciences 226, 1948, p. 537-539.
- [1] Aronszajn et Smith, Functional spaces and functional completion Studies in eigenvalue problems no 10, Lawrence, 1954.
- [1] Beurling, Ensembles exceptionnels, Acta Math, 72, 1940, p. 1-13.
- [1] BOURBAKI, Espaces vectoriels topologiques, Paris, Hermann 1953.
- [1] Brelot, Points irréguliers et transformations continues en théorie du potentiel, Journal de Math; 19, 1940, p. 319-337.
- [2] Brelot, Sur les ensembles effilés, Bull. Sc. Math. 68, 1944, p. 1-32.
- [3] Brelot, Sur le rôle du point à l'infini dans la théorie des fonctions harmoniques, Ann. E.N.S., 61, 1944, p. 301-332.
- [4] Brelot, Sur l'allure des fonctions harmoniques et sousharmoniques à la frontière, Math. Nachr., 4, 1951, p. 298-307.
- [5] Brelot, Principe et problème de Dirichlet dans les espaces de Green, C.R. Ac. des Sc., 235-1952, p. 598-600.
- [6] Brelot, La théorie moderne du potentiel, Ann. Inst. Fourier, 4, 1952, p. 113-133.
- [7] Brelot, Étude et extensions du principe de Dirichlet, Ann. Inst. Fourier, 5, 1953-54, p. 371-419.
- [1] Brelot et Choquet, Espaces et lignes de Green, Ann. Inst. Fourier, 3, 1951, p. 199-263.
- [1] Browder, The Dirichlet and vibration problem..., Proc. Acad. of Sc. 38, 1952, p. 230-235.
- [1] CALKIN, Functions of several variables and absolute continuity I, Duke Math. J. 6, 1940, p. 176-186.
- [1] Cartan, Théorie du potentiel newtonien..., Bull. Soc. Math. de France 73, 1945, p. 74-106.
- [2] Cartan, Théorie générale du balayage en potentiel newtonien, Ann. Univ. Grenoble, 22, 1946, p. 221-280.
- [1] COURANT ET HILBERT, Methoden der mathematischen Physik, Berlin, Springer 1937.
- [1] Deny, Les potentiels d'énergie finie, Acta Math. 82, 1950, p. 107-183.
- [2] Deny, Sur la convergence de certaines intégrales de la théorie du potentiel, Ark. der Math. 5, 1954, p. 367-370.
- [1] Deny-Lions, Espaces de Beppo Levi et applications, C. R. Acad. des Sc. 239, 1954, p. 1174-1177.
- [1] FRIEDRICHS, On the boundary values problems of the theory of elasticity and Korn's inequality, Ann. of Math. 48, 1947, p. 441-471.
- [1] Fuglede, Closed extensions of partial differential operators, Proc. Intern. Math. Congress, Amsterdam 1954.
- [1] GARDING, Dirichlet's problem for linear elliptic partial differential equations, *Math. Scand.* 1, 1953, p. 55-72.
- [1] Kondrachoff, Sur certaines propriétés des fonctions de l'espace L<sup>p</sup>, Doklady 48, 1945, p. 563-566.

- [1] KOUDRIAVZEFF, Sur certaines généralisations des théorèmes de Nikolsky sur la compacité des classes de fonctions différentiables, Ycp. Mat. Nauk, 9, 1954, p. 111-118.
- [1] Lelong-Ferrand, Représentation conforme et transformations à intérale de Dirichlet finie, *Paris*, *Gauthier-Villars* (à paraître prochainement).
- [1] (Beppo) Levi, Sul principio di Dirichlet, Rend. Palermo, 22. 1906, p. 293-359.
- [1] Lions, Problèmes aux limites I, C.R. Ac. des Sc. 236, 1953, p. 2373-2375.
- [2] Lions, Problèmes aux limites II, Id. p. 2470-2472.
- [3] Lions, Problèmes aux limites en théorie des distributions, à paraître aux Acta Math.
- [1] Michlin, Problèmes de minimum de fonctionnelles quadratiques, *Moscou* 1952.
- [1] Morray, Functions of several variables and absolute continuity, II, Duke Math. J., 6, 1940, p. 187-215.
- [1] Nikodym, Sur une classe de fonctions considérées dans le problème de Dirichlet, Fund. Math. 21, 1933, p. 129-150.
- [1] Nikolsky, Propriétés de certaines classes de fonctions de plusieurs variables, *Mat. Sbornik* 33 (75), p. 261-326.
- [1] Poincaré, Sur les équations de la Physique mathématique, Rend. Palermo 8, 1894, p. 57-155.
- [1] Polya et Szegö, Isoperimetric inequalities in mathematical Physics, Ann. of math. Studies no 27.
- [1] de Rham et Kodaira, Harmonic integrals, Princeton 1950.
- [1] Schwarz, Théorie des distributions I, Paris, Hermann 1950.
- [2] Schwartz, Théorie des distributions II, Id. 1951.
- [3] Schwartz, Exposé sur les travaux de Garding, Séminaire Bourbaki, mai 1952.
- [1] Soboleff, Sur un théorème d'analyse fonctionnelle, *Mat. Sbornik* 4 (46), 1938, p. 471-477.
- [2] Soboleff, Sur certaines applications de l'analyse fonctionnelle à l'analyse mathématique, *Léningrad* 1950.
- [1] Weil, L'intégration dans les groupes topologiques et ses applications-Paris, Hermann 1940.