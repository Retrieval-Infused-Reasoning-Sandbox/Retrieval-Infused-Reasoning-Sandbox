![](_page_0_Picture_1.jpeg)

Contents lists available at ScienceDirect

# Journal of Functional Analysis

www.elsevier.com/locate/jfa

![](_page_0_Picture_5.jpeg)

# Traces for homogeneous Sobolev spaces in infinite strip-like domains

![](_page_0_Picture_7.jpeg)

Giovanni Leoni <sup>1</sup>, Ian Tice <sup>∗</sup>*,*<sup>2</sup>

*Department of Mathematical Sciences, Carnegie Mel lon University, Pittsburgh, PA 15213, USA*

#### a r t i c l e i n f o a b s t r a c t

#### *Article history:*

Received 28 August 2018 Accepted 16 January 2019 Available online 1 February 2019 Communicated by Guido De Philippis

# *MSC:*

primary 46E35, 46F05 secondary 35J20, 35J25, 35J62

#### *Keywords:*

Homogeneous Sobolev spaces Trace theory Elliptic PDEs in unbounded domains

In this paper we construct a trace operator for homogeneous Sobolev spaces defined on infinite strip-like domains. We identify an intrinsic seminorm on the resulting trace space that makes the trace operator bounded and allows us to construct a bounded right inverse. The intrinsic seminorm involves two features not encountered in the trace theory of bounded Lipschitz domains or half-spaces. First, due to the strip-like structure of the domain, the boundary splits into two infinite disconnected components. The traces onto each component are not completely independent, and the intrinsic seminorm contains a term that measures the difference between the two traces. Second, as in the usual trace theory, there is a term in the seminorm measuring the fractional Sobolev regularity of the trace functions with a difference quotient integral. However, the finite width of the strip-like domain gives rise to a screening effect that bounds the range of the difference quotient perturbation. The screened homogeneous fractional Sobolev spaces defined by this screened seminorm on arbitrary open sets are of independent interest, and we study their basic properties.

<sup>\*</sup> Corresponding author.

*E-mail addresses:* giovanni@andrew.cmu.edu (G. Leoni), iantice@andrew.cmu.edu (I. Tice).

<sup>1</sup> G. Leoni was supported by an National Science Foundation Grant (DMS #1714098).

<sup>2</sup> I. Tice was supported by a National Science Foundation CAREER Grant (DMS #1653161).

We conclude the paper with applications of the trace theory to partial differential equations.

© 2019 Elsevier Inc. All rights reserved.

#### 1. Introduction

#### 1.1. Motivation

For an open set  $\Omega \subseteq \mathbb{R}^N$ ,  $m \in \mathbb{N}$ , and  $1 \leq p \leq \infty$ , the homogeneous Sobolev space  $\dot{W}^{m,p}(\Omega)$  consists of all real-valued functions  $u \in L^1_{loc}(\Omega)$  such that all the weak derivatives of order m belong to  $L^p(\Omega)$ . The goal of this paper is to characterize the trace operators associated to  $\dot{W}^{m,p}(\Omega)$  in infinite strip-like domains of the form

$$\Omega = \{ x \in \mathbb{R}^N \, | \, \eta^-(x') < x_N < \eta^+(x') \} \,, \tag{1.1}$$

where  $\eta^{\pm}: \mathbb{R}^{N-1} \to \mathbb{R}$  are given Lipschitz functions such that  $\eta^{-} < \eta^{+}$ . Note that we do not require  $\eta^{\pm}$  to be bounded, which allows the domain  $\Omega$  to be unbounded in the vertical  $x_{N}$  direction in addition to the horizontal x' directions.

It is well-known (see, for example, [2], [4], [15], [19], [26], [33], [36] and the references therein) that the inhomogeneous Sobolev spaces  $W^{m,p}(\Omega)$  (which we recall require functions and all their weak derivatives up to order m to belong to  $L^p(\Omega)$ ) are ill-suited to study partial differential equations in unbounded domains. This is already seen at the level of the fundamental solution to Laplace's equation when  $N \geq 2$ . Indeed, if  $B[0,1] \subset \mathbb{R}^N$  denotes the closed unit ball, then the function  $u: \mathbb{R}^N \backslash B[0,1] \to \mathbb{R}$  given by

$$u(x) = \begin{cases} \log|x| & \text{if } N = 2\\ 1 - |x|^{2-N} & \text{if } N \ge 3 \end{cases}$$

is a solution of the homogeneous Dirichlet problem

$$\begin{cases} \Delta u = 0 & \text{in } \mathbb{R}^N \setminus B[0, 1] \\ u = 0 & \text{on } \partial B(0, 1), \end{cases}$$

and while we have the inclusions  $u \in \dot{W}^{1,p}(\mathbb{R}^N \setminus B[0,1]) \cap \dot{W}^{2,q}(\mathbb{R}^N \setminus B[0,1])$  for every  $N/(N-1) and <math>1 < q \le \infty$ , it is clear that  $u \notin L^r(\mathbb{R}^N \setminus B[0,1])$  for any  $1 \le r < \infty$ .

To overcome this problem, the standard approach in the literature is to use weighted Sobolev spaces (see, for example, [2], [4], [15], [22], [25], [36], [38] and the references therein). An alternate approach to solving boundary value problems on infinite domains is to have a better understanding of the trace operator associated to homogeneous spaces.

In the recent paper [34] Strichartz proved, among other things, a new characterization of the trace space associated to the homogeneous Sobolev space  $\dot{H}^1(\Omega) := \dot{W}^{1,2}(\Omega)$ , where  $\Omega = \mathbb{R} \times (0,\pi) \subseteq \mathbb{R}^2$  is a horizontal strip. More precisely, he defined the fractional-type Sobolev space  $\tilde{H}^{1/2}(\mathbb{R})$  of all functions  $f \in L^1_{loc}(\mathbb{R})$  such that

$$|f|_{\tilde{H}^{1/2}(\mathbb{R})} := \left( \iint_{|x-y| \le 1} \frac{|f(x) - f(y)|^2}{|x-y|^2} dx dy \right)^{1/2} < \infty$$
 (1.2)

and proved the following result.

**Theorem 1.1** (Strichartz [34]). Let  $\Omega = \mathbb{R} \times (0, \pi)$ . Then the following hold.

(1) There exists a constant c > 0 such that for all  $u \in \dot{H}^1(\Omega)$ ,

$$\int_{\mathbb{R}} |\operatorname{Tr}(u)(x_{1}, \pi) - \operatorname{Tr}(u)(x_{1}, 0)|^{2} dx_{1} \leq c \int_{\Omega} |\nabla u(x)|^{2} dx,$$
$$|\operatorname{Tr}(u)(\cdot, \pi)|_{\tilde{H}^{1/2}(\mathbb{R})}^{2} + |\operatorname{Tr}(u)(\cdot, 0)|_{\tilde{H}^{1/2}(\mathbb{R})}^{2} \leq c \int_{\Omega} |\nabla u(x)|^{2} dx.$$

(2) Given  $f, g \in \tilde{H}^{1/2}(\mathbb{R})$  such that  $f - g \in L^2(\mathbb{R})$ , there exists  $u \in \dot{H}^1(\Omega)$  such that  $\operatorname{Tr}(u)(\cdot, \pi) = f$ ,  $\operatorname{Tr}(u)(\cdot, 0) = g$ , and

$$\int_{\Omega} |\nabla u(x)|^2 dx \le c \int_{\mathbb{R}} |f(x_1) - g(x_1)|^2 dx_1 + c|f|_{\tilde{H}^{1/2}(\mathbb{R})}^2 + c|g|_{\tilde{H}^{1/2}(\mathbb{R})}^2$$

for some constant c > 0, independent of f and g.

The seminorm  $|\cdot|_{\tilde{H}^{1/2}(\mathbb{R})}$  defined in (1.2) has an interesting characterization in terms of the Fourier transform. Indeed, one can show that (see Theorem 2.2 in [34] and Proposition 3.16 below)

$$|f|_{\tilde{H}^{1/2}(\mathbb{R})}^2 \asymp \int_{\mathbb{R}} \min\{|\xi|, |\xi|^2\} |\hat{f}(\xi)|^2 d\xi,$$

where  $\hat{f}$  is the Fourier transform of f. This should be contrasted with the Fourier characterization of the seminorm defining the classical fractional homogeneous Sobolev space  $\dot{H}^{1/2}(\mathbb{R})$ :

$$|f|_{\dot{H}^{1/2}(\mathbb{R})}^2 := \iint_{\mathbb{R}^2} \frac{|f(x) - f(y)|^2}{|x - y|^2} dx dy = c \int_{\mathbb{R}} |\xi| |\hat{f}(\xi)|^2 d\xi,$$

for c>0 a constant independent of f. From these expressions we see that the difference between the seminorms is determined by the low frequencies on the Fourier side, with the seminorm on  $\tilde{H}^{1/2}(\mathbb{R})$  allowing for worse behavior of the low frequency modes. These expressions also suggests that  $\dot{H}^{1/2}(\mathbb{R}) \subsetneq \tilde{H}^{1/2}(\mathbb{R})$ , i.e. that the classical space is strictly smaller. This is indeed the case, as can be seen directly by considering a function  $f \in C^{\infty}(\mathbb{R})$  such that supp  $f' \subseteq [0,1]$ , f(x)=1 for  $x \geq 1$ , and f(x)=0 for all  $x \leq 0$ . An important consequence of the strict inclusion  $\dot{H}^{1/2}(\mathbb{R}) \subsetneq \tilde{H}^{1/2}(\mathbb{R})$  is that, in general, functions in  $\dot{H}^{1}(\Omega)$  may not be extended to functions in  $\dot{H}^{1}(\mathbb{R}^{2})$ .

A central component of this paper consists of extending Strichartz's theorem to the more general case of  $\dot{W}^{m,p}(\Omega)$  for  $m \in \mathbb{N}$  and  $1 \leq p < \infty$ , where  $\Omega \subset \mathbb{R}^N$  for  $N \geq 2$  is a horizontal strip of the form

$$\Omega := \left\{ x \in \mathbb{R}^N \, | \, b^- < x_N < b^+ \right\} \tag{1.3}$$

for constants  $b^- < b^+$ . In order to refer to the connected components of  $\partial\Omega$  individually, we will write

$$\Gamma^{\pm} = \{ x \in \mathbb{R}^N \, | \, x_N = b^{\pm} \} \,. \tag{1.4}$$

#### 1.2. Main results and discussion

The main thrust of the paper is to characterize the trace spaces associated to the homogeneous Sobolev space  $\dot{W}^{m,p}(\Omega)$  when  $\Omega$  is of the form (1.1) or (1.3). The trace spaces involve a generalization of the space  $\tilde{H}^{1/2}(\mathbb{R})$  from [34], which we call a screened homogeneous fractional Sobolev space. These spaces are important for our trace results but are of independent interest in a more general setting. As such, in Section 3 we define these spaces on general open sets  $U \subseteq \mathbb{R}^N$  for 0 < s < 1 and  $1 \le p < \infty$  through the seminorm

$$L^1_{\mathrm{loc}}(U)\ni f\mapsto |f|_{\tilde{W}^{s,p}_{(\sigma)}(U)}=\left(\int\limits_{U}\int\limits_{B(x,\sigma(x))\cap U}\frac{|f(y)-f(x)|^p}{|y-x|^{sp+N}}dyxy\right)^{1/p}\in [0,\infty],$$

where  $\sigma:U\to(0,\infty]$  is a lower semi-continuous function that we call a screening function, due to the fact that it screens the range of the difference quotient. The functions for which the seminorm is finite comprise the space  $\tilde{W}_{(\sigma)}^{s,p}(U)$ . When p=2 and  $\sigma$  is a finite constant, variants of the screened spaces have appeared in the analysis of weak formulations of various nonlocal elliptic equations (see [14], [16], [39]). For general p there has been much recent interest in inhomogeneous fractional-type Sobolev spaces with seminorms of the form

$$L^{p}(U)\ni f\mapsto \left(\int\limits_{U}\int\limits_{U}\frac{|f(y)-f(x)|^{p}}{|y-x|^{p}}\rho(|x-y|)dyxy\right)^{1/p}\in[0,\infty]$$

for a given kernel  $\rho:[0,\infty)\to[0,\infty)$ : we refer to the seminal papers [8] and [9] and to the papers [11], [31], [32] and the references therein for a more recent survey of this literature. When  $\rho(r)=\chi_{[0,b)}(r)r^{(1-s)p-N}$  these seminorms correspond to the screened homogeneous fractional seminorm for constant screening function  $\sigma=b$ , but our focus in this paper is the seminorm defined on  $L^1_{loc}(U)$  rather than  $L^p(U)$ . To the best of our knowledge the screened homogeneous fractional spaces for general p and  $\sigma$  have not been previously studied.

For the screened spaces we prove, among other things, Poincaré-type estimates, sequential completeness, and some basic interpolation and embedding results. We also construct some sets and choices of screening functions (see Theorems 3.11 for the precise forms) for which we have the strict inclusion

$$\dot{W}^{s,p}(U) \subsetneq \tilde{W}^{s,p}_{(\sigma)}(U),$$

which shows that the screened spaces are generally strictly bigger than the standard homogeneous fractional Sobolev spaces. We also consider the special case  $U = \mathbb{R}^N$ , which is the domain most relevant to our trace results when we swap  $N \mapsto N - 1$ . We prove that if  $\sigma_1, \sigma_2$  are both bounded above and below, then

$$\tilde{W}^{s,p}_{(\sigma_1)}(\mathbb{R}^N) = \tilde{W}^{s,p}_{(\sigma_2)}(\mathbb{R}^N), \tag{1.5}$$

which shows that the precise form of the bounded screening function is not important. We also establish density of smooth functions and prove a Fourier characterization when p=2. We have not attempted an exhaustive study of the screened spaces and have left many basic questions open. In particular, we believe it would be interesting to study these spaces using interpolation theory and to give an equivalent characterization in terms of the Littlewood–Paley theory (see [3], [5], [7], [6], [20], [30], [37]).

To state our trace results, we first need some notation. We will write points  $x \in \mathbb{R}^N$  as  $x = (x', x_N) \in \mathbb{R}^{N-1} \times \mathbb{R}$ , and we will let B'(x', r) denote the open ball in  $\mathbb{R}^{N-1}$ , centered at x', and of radius r. In  $\mathbb{R}^{N-1}$  with screening function given by the constant a > 0 and s = 1 - 1/p, the screened homogeneous fractional Sobolev seminorm can be rewritten as

$$|f|_{\tilde{W}^{1-1/p,p}_{(a)}(\mathbb{R}^{N-1})} := \left(\int\limits_{\mathbb{R}^{N-1}}\int\limits_{B'(0,a)} \frac{|f(x'+h')-f(x')|^p}{|h'|^{p+N-2}} \, dh' dx'\right)^{1/p}.$$

We can now state our trace results. We begin with the case m=1 and 1 .

**Theorem 1.2.** Let  $\Omega$  be as in (1.3) and let 1 . There exists a unique linear operator

$$\operatorname{Tr}: \dot{W}^{1,p}(\Omega) \to L^p_{\operatorname{loc}}(\partial\Omega)$$

satisfying the following.

- (1)  $\operatorname{Tr}(u) = u$  on  $\partial\Omega$  for all  $u \in \dot{W}^{1,p}(\Omega) \cap C^0(\overline{\Omega})$ .
- (2) There exists a constant c = c(N, p) > 0 such that

$$\int_{\mathbb{R}^{N-1}} |\operatorname{Tr}(u)(x', b^{+}) - \operatorname{Tr}(u)(x', b^{-})|^{p} dx' \le (b^{+} - b^{-})^{p-1} \int_{\Omega} |\partial_{N} u(x)|^{p} dx, \quad (1.6)$$

$$|\operatorname{Tr}(u)(\cdot, b^{\pm})|_{\tilde{W}_{(b^{+}-b^{-})}^{1-1/p, p}(\mathbb{R}^{N-1})}^{p} \le c \int_{\Omega} |\nabla u(x)|^{p} dx$$
 (1.7)

for all  $u \in \dot{W}^{1,p}(\Omega)$ . Here  $b^- < b^+$  are the constants defining  $\Omega$  in (1.3).

(3) The integration by parts formula

$$\int_{\Omega} u \partial_i \psi \, dx = -\int_{\Omega} \psi \partial_i u \, dx + \int_{\partial \Omega} \psi \operatorname{Tr}(u) \nu_i \, d\mathcal{H}^{N-1}$$

holds for all  $u \in \dot{W}^{1,p}(\Omega)$ , all  $\psi \in C_c^1(\mathbb{R}^N)$ , and all i = 1, ..., N.

Remark 1.3. In the event that either of the traces  $\operatorname{Tr}(u)(\cdot,b^+)$  or  $\operatorname{Tr}(u)(\cdot,b^-)$  belongs to  $L^p(\mathbb{R}^{N-1})$ , the second part of Theorem 1.2 guarantees that the other trace also belongs to  $L^p(\mathbb{R}^{N-1})$ . Since the vertical extent of  $\Omega$  is finite, this information can be coupled with a standard Poincaré-type inequality to guarantee that  $u \in W^{1,p}(\Omega)$ . Thus functions  $u \in \dot{W}^{1,p}(\Omega) \setminus W^{1,p}(\Omega)$  cannot have either trace belong to  $L^p(\mathbb{R}^{N-1})$ . In particular, we have the identity

$$Ker(Tr) = W_0^{1,p}(\Omega). \tag{1.8}$$

Theorem 1.2 is complemented by the following lifting result. We recall that  $\Gamma^{\pm}$  are defined in (1.4).

**Theorem 1.4.** Let  $\Omega$  be as in (1.3), a > 0, and  $1 . Suppose that <math>f^{\pm} \in L^1_{loc}(\mathbb{R}^{N-1})$  are such that

$$\int_{\mathbb{R}^{N-1}} |f^{+}(x') - f^{-}(x')|^{p} dx' < \infty, \tag{1.9}$$

$$|f^{-}|_{\tilde{W}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})} < \infty, \quad |f^{+}|_{\tilde{W}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})} < \infty.$$
 (1.10)

Then there exists  $u \in \dot{W}^{1,p}(\Omega)$  such that  $Tr(u) = f^{\pm}$  on  $\Gamma^{\pm}$  and

$$\int_{\Omega} |\nabla u(x)|^p dx \le c \int_{\mathbb{R}^{N-1}} |f^+(x') - f^-(x')|^p dx' + c|f^-|_{\tilde{W}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})}^p + c|f^+|_{\tilde{W}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})}^p$$

for some constant  $c = c(a, b^+ - b^-, N, p) > 0$ . Moreover, the map  $(f^-, f^+) \mapsto u$  is linear.

**Remark 1.5.** It is important to observe that in Theorem 1.4 the functions  $f^{\pm}$  are not assumed to be individually in  $L^p(\mathbb{R}^{N-1})$ , but their difference is.

**Remark 1.6.** Notice that in Theorem 1.2 the screening function is the constant  $b^+ - b^- > 0$ , but in Theorem 1.4 the screening function is any constant a > 0. This discrepancy is accounted for by (1.5) (see Theorem 3.13), which shows that these screening functions define the same space and give rise to equivalent seminorms.

Theorems 1.2 and 1.4 show that for horizontal strips the trace space of the homogeneous space  $\dot{W}^{1,p}(\Omega)$  is strictly larger than the trace space of the inhomogeneous space  $W^{1,p}(\Omega)$ . Indeed, by a classical result of Gagliardo [18], the trace space of  $W^{1,p}(\Omega)$  is given by the fractional Sobolev space  $W^{1-1/p,p}(\partial\Omega)$ , or equivalently, by the Besov space  $B_p^{1-1/p,p}(\partial\Omega)$  (see also [1], [12], [21], [23], [24], [29]). The norm defining  $W^{1-1/p,p}(\partial\Omega)$  is

$$||f||_{W^{1-1/p,p}(\partial\Omega)} := ||f||_{L^p(\partial\Omega)} + \left( \int_{\partial\Omega} \int_{\partial\Omega} \frac{|f(x) - f(y)|^p}{|x - y|^{p+N-2}} d\mathcal{H}^{N-1}(x) d\mathcal{H}^{N-1}(y) \right)^{1/p}.$$

The class of pairs satisfying (1.9) and (1.10) gives rise to a new interesting type of space. At the end of Section 3 we study some of its properties.

By synthesizing our trace and lifting results with our results about the screened spaces in  $\mathbb{R}^{N-1}$  we also prove Proposition 4.1, which shows that there exist functions  $u \in \dot{W}^{1,p}(\Omega)$  that do not admit extensions to  $\dot{W}^{1,p}(\mathbb{R}^N)$ . In particular, this shows that there is no bounded extension operator available for  $\dot{W}^{1,p}(\Omega)$ .

Theorems 1.2 and 1.4 can be extended to domains of the form (1.1), and we do so in Theorems 5.1 and 5.4 below. The main difference is that conditions (1.9) and (1.10) should now be replaced, respectively, by

$$\int_{\mathbb{R}^{N-1}} \frac{|f^{+}(x') - f^{-}(x')|^{p}}{(\eta^{+}(x') - \eta^{-}(x'))^{p-1}} dx' < \infty,$$

$$\int_{\mathbb{R}^{N-1}} \int_{B'(0,a(\eta^{+}(x') - \eta^{-}(x')))} \frac{|f^{\pm}(x' + h') - f^{\pm}(x')|^{p}}{|h'|^{p+N-2}} dh' dx' < \infty.$$

Note that we allow  $\eta^+ - \eta^-$  to be unbounded, and we do not assume that  $\eta^+ - \eta^-$  is bounded away from zero, so the extension from (1.3) to (1.1) is non-trivial.

Next we consider the case p=1 and m=1. In [18] (see also [12], [23]) Gagliardo proved that for open bounded domains  $\Omega \subset \mathbb{R}^N$  with Lipschitz continuous boundary the trace space of  $W^{1,1}(\Omega)$  is given by  $L^1(\partial\Omega)$  (see also the recent paper of Mironescu [27] for a simpler proof). We can prove the following analogous result.

**Theorem 1.7.** Let  $\Omega$  be as in (1.3). There exists a unique linear operator

$$\operatorname{Tr}: \dot{W}^{1,1}(\Omega) \to L^1_{\operatorname{loc}}(\partial\Omega)$$

satisfying the following.

- (1)  $\operatorname{Tr}(u) = u$  on  $\partial \Omega$  for all  $u \in \dot{W}^{1,1}(\Omega) \cap C^0(\overline{\Omega})$ .
- (2) There exists a constant c = c(N) > 0 such that for every  $0 < \varepsilon < b^+ b^-$  and every  $u \in \dot{W}^{1,1}(\Omega)$ ,

$$\int_{\mathbb{R}^{N-1}} |\operatorname{Tr}(u)(x', b^{+}) - \operatorname{Tr}(u)(x', b^{-})| dx' \le \int_{\Omega} |\partial_{N} u(x)| dx, \quad (1.11)$$

$$\sup_{|h'| \le \varepsilon} \int_{\mathbb{R}^{N-1}} |\operatorname{Tr}(u)(x'+h',b^{\pm}) - \operatorname{Tr}(u)(x',b^{\pm})| dx' \le \int_{\Omega_{\varepsilon}} |\nabla u(x)| dx', \quad (1.12)$$

where  $\Omega_{\varepsilon} := \mathbb{R}^{N-1} \times ((b^-, b^- + \varepsilon) \cup (b^+ - \varepsilon, b^+))$ . In particular,

$$\lim_{\varepsilon \to 0^+} \sup_{|h'| \le \varepsilon} \int_{\mathbb{D}^{N-1}} |\operatorname{Tr}(u)(x'+h',b^{\pm}) - \operatorname{Tr}(u)(x',b^{\pm})| \, dx' = 0.$$

(3) The integration by parts formula

$$\int_{\Omega} u \partial_i \psi \, dx = -\int_{\Omega} \psi \partial_i u \, dx + \int_{\partial \Omega} \psi \operatorname{Tr}(u) \nu_i \, d\mathcal{H}^{N-1}$$

holds for all  $u \in \dot{W}^{1,1}(\Omega)$ , all  $\psi \in C_c^1(\mathbb{R}^N)$ , and all  $i = 1, \dots, N$ .

Theorem 1.7 is complemented by the following lifting result.

**Theorem 1.8.** Let  $\Omega$  be as in (1.3). Suppose that  $f^{\pm} \in L^1_{loc}(\mathbb{R}^{N-1})$  are such that

$$\int_{\mathbb{R}^{N-1}} |f^{+}(x') - f^{-}(x')| \, dx' < \infty, \tag{1.13}$$

$$\lim_{\varepsilon \to 0^{+}} \sup_{|h'| \le \varepsilon_{\mathbb{D}}} \int_{N-1} |f^{\pm}(x'+h') - f^{\pm}(x')| \, dx' = 0. \tag{1.14}$$

Then there exists  $u \in \dot{W}^{1,1}(\Omega)$  such that  $Tr(u) = f^{\pm}$  on  $\Gamma^{\pm}$  (as defined in (1.4)), and

$$\int_{\Omega} |\nabla u(x)| \, dx \le c \int_{\mathbb{R}^{N-1}} |f^{+}(x') - f^{-}(x')| \, dx' 
+ c \sup_{|h'| \le \varepsilon_{0}} \int_{\mathbb{R}^{N-1}} |f^{-}(x'+h') - f^{-}(x')| \, dx' + c \sup_{|h'| \le \varepsilon_{0}} \int_{\mathbb{R}^{N-1}} |f^{+}(x'+h') - f^{+}(x')| \, dx'$$

for some  $\varepsilon_0 > 0$  and some constant  $c = c(a, b^+, b^-, N) > 0$ . Moreover, the map  $(f^-, f^+) \mapsto u$  is linear.

Observe that functions  $f^{\pm} \in L^1(\mathbb{R}^{N-1})$  satisfy (1.13) and (1.14) but one can construct non-integrable functions  $f^{\pm} \in L^1_{loc}(\mathbb{R}^{N-1})$  satisfying (1.13) and (1.14). We have not been able to extend Theorems 1.7 and 1.8 to more general domains of the form 1.1. In particular, it is not clear what would be the analog of condition (1.14).

Next we consider the case  $m \geq 2$  and 1 . For simplicity we present here only the case <math>m = 2 and refer to Section 4.4 for the general case  $m \geq 2$ . The main difference with the case m = 1 is that in the higher order case the difference  $\mathrm{Tr}(u)(\cdot,b^+) - \mathrm{Tr}(u)(\cdot,b^-)$  does not have to belong to  $L^p(\mathbb{R}^{N-1})$ . This makes the proof of the lifting theorems significantly more involved.

Given a function  $u \in \dot{W}^{2,p}(\Omega)$ , we have that  $\partial_i u \in \dot{W}^{1,p}(\Omega)$  for every  $i = 1, \ldots, N$  and thus by Theorem 1.2 there exists  $\text{Tr}(\partial_i u)$ . By a density argument, it can be shown that  $\text{Tr}(u)(\cdot, b^{\pm}) \in W^{1,p}_{\text{loc}}(\mathbb{R}^{N-1})$  and that for every  $i = 1, \ldots, N-1$ ,  $\partial_i \text{Tr}(u)(\cdot, b^{\pm}) = \text{Tr}(\partial_i u)(\cdot, b^{\pm})$ . Thus, to characterize the trace space of  $\dot{W}^{2,p}(\Omega)$ , it suffices to study Tr(u) and the trace of the normal derivative  $\text{Tr}(\partial_N u)$ .

**Theorem 1.9.** Let  $\Omega$  be as in (1.3) and let 1 . Then there exists a constant <math>c = c(N, p) > 0 such that for every  $u \in \dot{W}^{2,p}(\Omega)$  and for every  $i = 1, \ldots, N$ ,

$$\int_{\mathbb{R}^{N-1}} |\operatorname{Tr}(\partial_{i}u)(x',b^{+}) - \operatorname{Tr}(\partial_{i}u)(x',b^{-})|^{p} dx' \leq (b^{+} - b^{-})^{p-1} \int_{\Omega} |\partial_{i,N}^{2}u(x)|^{p} dx, \quad (1.15)$$

$$\int_{\mathbb{R}^{N-1}} \left| \operatorname{Tr}(u)(x',b^{+}) - \operatorname{Tr}(u)(x',b^{-}) - (\operatorname{Tr}(\partial_{N}u)(x',b^{+}) + \operatorname{Tr}(\partial_{N}u)(x',b^{-})) \frac{b^{+} - b^{-}}{2} \right|^{p} dx'$$

$$\leq (b^{+} - b^{-})^{2p-1} \int_{\Omega} |\partial_{N}^{2}u(x)|^{p} dx, \quad (1.16)$$

and

$$|\operatorname{Tr}(\partial_i u)(\cdot, b^{\pm})|_{\tilde{W}_{(b^+-b^-)}^{1-1/p,p}(\mathbb{R}^{N-1})}^p \le c \int_{\Omega} |\nabla^2 u(x)|^p dx.$$
 (1.17)

Theorems 1.9 can be extended to domains of the form (1.1): see Theorems 5.5 and 5.7 below for the cases m = 2 and  $m \ge 2$ , respectively.

The previous theorem is complemented by the following lifting result.

**Theorem 1.10.** Let  $\Omega$  be as in (1.3), a>0, and  $1< p<\infty$ . Suppose that  $f_0^{\pm}\in W^{1,p}_{\mathrm{loc}}(\mathbb{R}^{N-1})$  and  $f_1^{\pm}\in L^p_{\mathrm{loc}}(\mathbb{R}^{N-1})$  are such that

$$\int_{\mathbb{R}^{N-1}} \left| f_0^+(x') - f_0^-(x') - (f_1^+(x') + f_1^-(x')) \frac{b^+ - b^-}{2} \right|^p dx' < \infty,$$

$$\int_{\mathbb{R}^{N-1}} (|\nabla_{\shortparallel} f_0^+(x') - \nabla_{\shortparallel} f_0^-(x')|^p + |f_1^+(x') - f_1^-(x')|^p) dx' < \infty,$$

$$|\nabla_{\shortparallel} f_0^{\pm}|_{\tilde{W}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})} < \infty, \quad |f_1^{\pm}|_{\tilde{W}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})} < \infty,$$

where  $\nabla_{\shortparallel} := (\partial_1, \ldots, \partial_{N-1})$ . Then there exists  $u \in \dot{W}^{2,p}(\Omega)$  such that  $\operatorname{Tr}(u) = f_0^{\pm}$ ,  $\operatorname{Tr}(\partial_N u) = f_1^{\pm}$  on  $\Gamma^{\pm}$ , and

$$\begin{split} \int\limits_{\Omega} |\nabla^{2} u(x)|^{p} dx &\leq c \int\limits_{\mathbb{R}^{N-1}} \left| f_{0}^{+}(x') - f_{0}^{-}(x') - (f_{1}^{+}(x') + f_{1}^{-}(x')) \frac{b^{+} - b^{-}}{2} \right|^{p} dx' \\ &+ c \int\limits_{\mathbb{R}^{N-1}} (|\nabla_{\sqcap} f_{0}^{+}(x') - \nabla_{\sqcap} f_{0}^{-}(x')|^{p} + |f_{1}^{+}(x') - f_{1}^{-}(x')|^{p}) dx' \\ &+ c |\nabla_{\sqcap} f_{0}^{-}|_{\tilde{W}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})}^{p} + c |\nabla_{\sqcap} f_{0}^{+}|_{\tilde{W}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})}^{p} + c |f_{1}^{+}|_{\tilde{W}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})}^{p}, \end{split}$$

for some constant  $c = c(a, b^+ - b^-, N, p) > 0$ . Moreover, the map  $(f_0^-, f_0^+, f_1^-, f_1^+) \mapsto u$  is linear.

The extension of Theorem 1.10 to domains of the form (1.1) seems to be quite complicated. We refer to Remark 5.6 below for more details on the technical difficulties one encounters. We have also been unable to prove Theorems 1.9 and 1.10 in the case p = 1. For bounded Lipschitz domains  $\Omega \subset \mathbb{R}^N$  we have that the image of the trace operator

$$u \in W^{2,1}(\Omega) \mapsto \operatorname{Tr}_2(u) := \left(\operatorname{Tr}(u), \operatorname{Tr}\left(\frac{\partial u}{\partial \nu}\right)\right)$$

is the space  $B_1^{1,1}(\partial\Omega) \times L^1(\partial\Omega)$ , where the Besov space  $B_1^{1,1}$  is defined via second-order difference quotients in  $\mathbb{R}^N$  and via local coordinates on boundaries (see, for instance, [23]). We are aware of only two complete proofs of this result: one in a classical paper of Uspenskii [38], and one in a recent paper of Mironescu and Russ [28]. In

particular, in the latter the authors use an equivalent norm for  $B_1^{1,1}$ , which relies on the Littlewood–Paley decomposition (see [23]). The adaptation of the proofs in [38] and [28] to  $\dot{W}^{2,1}(\Omega)$  seems quite challenging.

We conclude this introduction with an application of our results to the existence of solutions to the Dirichlet problem for the p-Laplacian in unbounded domains of the form (1.3). In Section 6 we prove analogous results when  $\Omega$  is of the form (1.1) and study the Neumann problem and more general second-order quasilinear elliptic equations.

**Theorem 1.11.** Let  $\Omega$  be as in (1.3), let a > 0, let  $1 , and let <math>g \in L^{p'}(\Omega; \mathbb{R}^N)$  and  $f^{\pm} \in L^1_{loc}(\mathbb{R}^{N-1})$ . Then the Dirichlet problem

$$\begin{cases}
-\operatorname{div}(|\nabla u|^{p-2}\nabla u) = \operatorname{div} g & \text{in } \Omega, \\
u = f^{\pm} & \text{on } \Gamma^{\pm}
\end{cases}$$
(1.18)

admits a solution in  $\dot{W}^{1,p}(\Omega)$  if and only if  $f^{\pm}$  satisfy (1.9) and (1.10). In either case, there exists a constant c = c(a, N, p) > 0 such that

$$\int_{\Omega} |\nabla u(x)|^{p} dx \leq c \int_{\Omega} |g(x)|^{p'} dx + c \int_{\mathbb{R}^{N-1}} |f^{+}(x') - f^{-}(x')|^{p} dx' 
+ c|f^{-}|_{\tilde{W}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})}^{p} + c|f^{+}|_{\tilde{W}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})}^{p}.$$
(1.19)

# 1.3. Plan of paper

In Section 2 we record notational conventions used throughout the paper as well as prove some useful preliminary results. In Section 3 we define the general screened homogeneous fractional Sobolev spaces and study their basic properties. These spaces play a key role in our trace results, but they are of independent interest and have intriguing properties. In Section 4 we develop the trace and lifting results when  $\Omega$  is of the form (1.3). This section contains the proofs of Theorems 1.2, 1.4, 1.7, 1.8, 1.9, and 1.10. In Section 5 we study the trace and lifting results when  $\Omega$  is of the form (1.1). Section 6 contains a number of applications of our results to quasilinear partial differential equations, including the proof of Theorem 1.11.

#### 2. Preliminaries

In this section we collect a number of preliminary results that will be of use throughout the paper. We begin with some notational conventions, then we develop some facts about mollifiers, and then we develop an elementary calculus result that plays a key role in our trace spaces. We conclude with a discussion of seminormed spaces.

#### 2.1. Notational conventions

We now record our notational conventions.

Integers and multi-indices: We write  $\mathbb{N} = \{1, 2, ...\}$  for the set of positive integers and  $\mathbb{N}_0 = \mathbb{N} \cup \{0\}$  for the non-negative integers. For a multi-index  $\alpha \in \mathbb{N}_0^N$  we write  $|\alpha| = \alpha_1 + \cdots + \alpha_N$ . We often write  $\alpha \in \mathbb{N}_0^N$  as  $\alpha = (\alpha', \alpha_N) \in \mathbb{N}_0^{N-1} \times \mathbb{N}_0$  to distinguish the horizontal part,  $\alpha'$ , from the vertical part  $\alpha_N$ .

Measures: In what follows  $\mathcal{L}^N$  stands for the Lebesgue measure in  $\mathbb{R}^N$  and  $\mathcal{H}^k$  is the k-dimensional Hausdorff measure. We denote by B(x,r) and B[x,r] the open and closed balls in  $\mathbb{R}^N$  centered at x and radius r, respectively. We write  $\alpha_N$  for the Lebesgue measure of the N-dimensional unit ball B(0,1) and  $\beta_N$  for the  $\mathcal{H}^{N-1}$  measure of the unit sphere  $\mathbb{S}^{N-1} := \partial B(0,1)$ .

Derivatives: Given  $k \in \mathbb{N}$  we denote by  $\nabla^k$  the vector of all partial derivatives  $\partial^{\alpha}$  for multi-indices  $\alpha \in \mathbb{N}_0^N$  with  $|\alpha| = k$ . We also define

$$\nabla^0 u := u. \tag{2.1}$$

Horizontal and vertical variables: For  $x=(x_1,\ldots,x_N)\in\mathbb{R}^N,\ N\geq 2$ , we write  $x=(x',x_N)\in\mathbb{R}^{N-1}\times\mathbb{R}$ , where  $x':=(x_1,\ldots,x_{N-1})$ . We denote by B'(x',r) the (N-1)-dimensional open ball centered at  $x'\in\mathbb{R}^{N-1}$  and radius r>0, and we write

$$abla_{\shortparallel} := (\partial_1, \ldots, \partial_{N-1})$$

for the horizontal gradient. Similarly, given  $k \in \mathbb{N}$  we denote by  $\nabla_{\shortparallel}^k$  the vector of all partial derivatives  $\partial^{\alpha}$  for multi-indices  $\alpha = (\alpha', 0) \in \mathbb{N}_0^{N-1} \times \mathbb{N}_0$  with  $|\alpha| = k$ . We define

$$\nabla_{\shortparallel}^{0}u := u. \tag{2.2}$$

Mollifiers: Given a function  $\phi: \mathbb{R}^N \to \mathbb{R}$  and  $\varepsilon > 0$  we define

$$\phi_{\varepsilon}(x) := \frac{1}{\varepsilon^N} \phi\left(\frac{x}{\varepsilon}\right). \tag{2.3}$$

Note that if  $\phi$  is integrable, then a change of variables shows that

$$\int_{\mathbb{R}^N} \phi_{\varepsilon}(x) \, dx = \int_{\mathbb{R}^N} \phi(y) \, dy.$$

Lipschitz functions: Given a function  $\eta: \mathbb{R}^N \to \mathbb{R}$  we set

$$|\eta|_{0,1} := \sup \left\{ \frac{|\eta(x) - \eta(y)|}{|x - y|} \, | \, x, y \in \mathbb{R}^N, \, x \neq y \right\}$$

to be the Lipschitz seminorm of  $\eta$ . We say  $\eta$  is Lipschitz if and only if  $|\eta|_{0,1} < \infty$ .

# 2.2. Special mollifiers

In our analysis we will make heavy use of mollifiers. Here we construct a special family of mollifiers and develop some auxiliary results. We begin by constructing mollifiers satisfying special moment conditions. In what follows we assume that  $N \geq 2$ .

**Proposition 2.1.** Let  $k, m \in \mathbb{N}$  be given. There exists a function  $\varphi \in C_c^m(\mathbb{R}^{N-1})$  such that  $\operatorname{supp} \varphi \subseteq B'(0,1)$ ,

$$\int_{\mathbb{R}^{N-1}} \varphi(x') \, dx' = 1, \ and \int_{\mathbb{R}^{N-1}} (x')^{\alpha} \varphi(x') \, dx' = 0 \ for \ 1 \le |\alpha| \le k.$$
 (2.4)

**Proof.** Assume that  $\varphi: \mathbb{R}^{N-1} \to \mathbb{R}$  is given by

$$\varphi(x) = \begin{cases} \phi(|x'|) & \text{for } |x'| \le 1\\ 0 & \text{for } |x'| > 1, \end{cases}$$

for a function  $\phi \in C^m([0,1])$  to be chosen. Then, using spherical coordinates, we may compute

$$\int_{B'(0,1)} (x')^{\alpha} \varphi(x') dx' = \int_{0}^{1} r^{N-2+|\alpha|} \int_{\partial B'(0,1)} (z')^{\alpha} \varphi(rz') d\mathcal{H}^{N-2}(z') dr$$

$$= \left( \int_{\partial B'(0,1)} (z')^{\alpha} d\mathcal{H}^{N-2}(z') \right) \int_{0}^{1} r^{N-2+|\alpha|} \phi(r) dr =: Q_{\alpha} \int_{0}^{1} r^{N-2+|\alpha|} \phi(r) dr,$$

where here we note that if N=2 then  $\mathcal{H}^{N-2}=\mathcal{H}^0$  denotes counting measure and  $\partial B'(0,1)=\{-1,1\}$ . Note that  $Q_{\alpha}=0$  except when  $\alpha=2\beta$ , so we may reduce to studying the case when  $|\alpha|$  is even. Without loss of generality we can assume that k=2l.

Now we make the ansatz that  $\phi$  is given by

$$\phi(r) = (1 - r^2)^{m+1} \psi(r^2)$$

for  $\psi \in C^m([0,1])$ . This forces  $\phi^{(j)}(1) = 0$  for  $0 \le j \le m$ , and so our function  $\varphi$  has all derivatives up to order m vanish at  $\partial B'(0,1)$ , which guarantees that  $\varphi \in C_c^m(\mathbb{R}^{N-1})$ .

It remains to enforce the moment conditions. In terms of  $\phi$ , the first of these is

$$\int_{0}^{1} r^{N-2} \phi(r) \, dr = \frac{1}{\alpha_{N-1}},$$

and the second is

$$0 = \int_{0}^{1} r^{N-2+2j} \phi(r) dr \text{ for } j = 1, \dots, l.$$

Plugging in our ansatz for  $\phi$  and making a change of variable  $s=r^2$  then shows that our moment conditions for  $\psi$  reduce to

$$\frac{1}{\alpha_{N-1}} = \frac{1}{2} \int_{0}^{1} \psi(s) s^{(N-3)/2} (1-s)^{m+1} ds$$

and

$$0 = \frac{1}{2} \int_{0}^{1} \psi(s) s^{(N-3)/2+j} (1-s)^{m+1} ds \text{ for } 1 \le j \le l.$$

Let  $X = \text{span}(1, s, s^2, \dots, s^l)$  be the polynomials (restricted to [0, 1]) of degree at most l. Define  $Y = \text{span}(s, s^2, \dots, s^l)$ . We endow X with the inner product

$$\langle \zeta, \eta \rangle := \frac{1}{2} \int_{0}^{1} \zeta(s) \eta(s) s^{(N-3)/2} (1-s)^{m+1} ds,$$

which is an inner-product since the weight function  $s^{(N-3)/2}(1-s)^{m+1}$  is nonnegative and integrable (since  $N \geq 2$ ) on [0,1] and vanishes only at the endpoints.

We then rewrite our moment conditions as

$$\langle 1, \psi \rangle = \frac{1}{\alpha_{N-1}}$$
 and  $\langle s^j, \psi \rangle = 0$  for  $j = 1, \dots, l$ .

In order to enforce the latter condition we assume that  $\psi \in Y^{\perp}$ , which is possible since  $\dim(Y^{\perp}) = 1$ . We can then find  $\psi \in Y^{\perp}$  satisfying  $\langle 1, \psi \rangle = 1/\alpha_{N-1}$  if and only if  $1^{\perp} \neq 0$ , where  $1^{\perp} \in Y^{\perp}$  is the orthogonal projection of 1 onto  $Y^{\perp}$ . Now,  $1^{\perp} = 0$  is equivalent to  $1 \in Y$ , which is impossible since if this were to hold then Y = X. Thus  $1^{\perp} \neq 0$ , and we are guaranteed the existence of  $\psi \in X \subset C^m([0,1])$  satisfying all the moment conditions.  $\square$ 

Next we identify a special structure for derivatives of mollifiers.

**Proposition 2.2.** Let  $\varphi \in C_c^m(\mathbb{R}^{N-1})$ . Then for every multi-index  $\alpha \in \mathbb{N}_0^N$  with  $1 \leq |\alpha| \leq m$ , there exists a function  $\psi^{\alpha} \in C_c^{m-|\alpha|}(\mathbb{R}^{N-1})$ , with

$$\int_{\mathbb{R}^{N-1}} \psi^{\alpha}(y') \, dy' = 0, \tag{2.5}$$

such that for every  $x', y' \in \mathbb{R}^{N-1}$  and  $x_N > 0$ ,

$$\frac{\partial^{\alpha}}{\partial x^{\alpha}} \left( \frac{1}{x_N^{N-1}} \varphi \left( \frac{x' - y'}{x_N} \right) \right) = \frac{1}{x_N^{|\alpha| + N - 1}} \psi^{\alpha} \left( \frac{x' - y'}{x_N} \right). \tag{2.6}$$

**Proof.** We proceed by finite induction on  $|\alpha| \in \{1, ..., m\}$ . Throughout the proof we will use the notation (2.3) with  $\varepsilon = x_N$ .

We begin with the base case,  $|\alpha| = 1$ , which means that  $\alpha = e_i$  for some i = 1, ..., N. Then for i = 1, ..., N - 1,

$$\frac{\partial}{\partial x_i} \left( \varphi_{x_N} \left( x' - y' \right) \right) = \frac{1}{x_N^N} \partial_i \varphi \left( \frac{x' - y'}{x_N} \right) = \frac{1}{x_N} \psi_{x_N}^{e_i} (x' - y')$$

for  $\psi^{e_i}(y') := \partial_i \varphi(y')$ , while for i = N we have

$$\begin{split} \frac{\partial}{\partial x_{N}}\left(\varphi_{x_{N}}\left(x'-y'\right)\right) &= \frac{1}{x_{N}^{N}}\left[-(N-1)\varphi\left(\frac{x'-y'}{x_{N}}\right) - \nabla_{\shortparallel}\varphi\left(\frac{x'-y'}{x_{N}}\right) \cdot \frac{x'-y'}{x_{N}}\right] \\ &= \frac{1}{x_{N}}\psi_{x_{N}}^{e_{N}}(x'-y') \end{split}$$

for  $\psi^{e_N}(y') := -(N-1)\varphi(y') - \nabla_{\shortparallel}\varphi(y') \cdot y'$ . The change of variables  $z' := \frac{x'-y'}{x_N}$  reveals that for any  $f \in L^1(\mathbb{R}^{N-1})$  we have that

$$\int_{\mathbb{R}^{N-1}} f_{x_N}(x'-y') \, dy' = \int_{\mathbb{R}^{N-1}} f(z') \, dz',$$

and so for every i = 1, ..., N we have that

$$\frac{1}{x_N} \int_{\mathbb{R}^{N-1}} \psi^{e_i}(z') dz' = \frac{1}{x_N} \int_{\mathbb{R}^{N-1}} \psi^{e_i}_{x_N}(x' - y') dy' = \int_{\mathbb{R}^{N-1}} \frac{\partial}{\partial x_i} (\varphi_{x_N}(x' - y')) dy'$$

$$= \frac{\partial}{\partial x_i} \int_{\mathbb{R}^{N-1}} \varphi_{x_N}(x' - y') dy' = 0. \tag{2.7}$$

Consequently, (2.5) holds for  $|\alpha| = 1$ , which completes the proof of the base case.

Next assume that the result is true for all  $\beta \in \mathbb{N}_0^N$  with  $|\beta| = k, 1 \le k \le m-1$ , and let  $\alpha \in \mathbb{N}_0^N$  with  $|\alpha| = k+1$ . Write  $\alpha = \beta + e_i$ , where  $|\beta| = k$  and  $i \in \{1, ..., N\}$ . Then

$$\begin{split} \frac{\partial^{\alpha}}{\partial x^{\alpha}} \left( \varphi_{x_{N}} \left( x' - y' \right) \right) &= \frac{\partial}{\partial x_{i}} \frac{\partial^{\beta}}{\partial x^{\beta}} \left( \varphi_{x_{N}} \left( x' - y' \right) \right) \\ &= \frac{\partial}{\partial x_{i}} \left( \frac{1}{x_{N}^{|\beta| + N - 1}} \psi^{\beta} \left( \frac{x' - y'}{x_{N}} \right) \right), \end{split}$$

where in the last equality we have used the induction hypothesis. We now distinguish two cases. If  $i \in \{1, ..., N-1\}$ , then

$$\frac{\partial^{\alpha}}{\partial x^{\alpha}}\left(\varphi_{x_{N}}\left(x'-y'\right)\right) = \frac{1}{x_{N}^{|\beta|+N}}\partial_{i}\psi^{\beta}\left(\frac{x'-y'}{x_{N}}\right) = \frac{1}{x_{N}^{|\alpha|+N-1}}\psi^{\alpha}\left(\frac{x'-y'}{x_{N}}\right),$$

where  $\psi^{\alpha}(y') := \partial_i \psi^{\beta}(y')$ . Note that in this case we trivially have the identity  $\int_{\mathbb{R}^{N-1}} \psi^{\alpha}(y') dy' = 0$ . On the other hand, if i = N, then

$$\begin{split} \frac{\partial^{\alpha}}{\partial x^{\alpha}}\left(\varphi_{x_{N}}\left(x'-y'\right)\right) &= \frac{1}{x_{N}^{|\beta|+N}}\bigg[-(|\beta|+N-1)\psi^{\beta}\left(\frac{x'-y'}{x_{N}}\right) \\ &-\nabla_{\square}\psi^{\beta}\left(\frac{x'-y'}{x_{N}}\right)\cdot\frac{x'-y'}{x_{N}}\bigg] \\ &= \frac{1}{x_{N}^{|\alpha|}}\psi_{x_{N}}^{\alpha}(x'-y'), \end{split}$$

where  $\psi^{\alpha}(y') := -(|\beta| + N - 1)\psi^{\beta}(y') - \nabla_{\shortparallel}\psi^{\beta}(y') \cdot y'$ . Writing

$$\nabla_{\shortparallel}\psi^{\beta}\left(y'\right)\cdot y' = \operatorname{div}_{y'}(y'\psi^{\beta}) - (N-1)\psi^{\beta}$$

and using the induction hypothesis then shows that

$$\int_{\mathbb{D}^{N-1}} \psi^{\alpha}(y') \, dy' = \int_{\mathbb{D}^{N-1}} -|\beta| \psi^{\beta}(y') \, dy' = 0.$$

Thus, the result holds for  $\alpha$ , and so by finite induction this completes the proof.  $\Box$ 

Finally, we prove an estimate for a special type of convolution.

**Proposition 2.3.** Let 0 < a < b and let  $\phi \in L^{\infty}(\mathbb{R}^{N-1})$  be such that supp  $\phi \subseteq B'(0, ab^{-1})$  and

$$\int_{\mathbb{R}^{N-1}} \phi(y') \, dy' = 0. \tag{2.8}$$

Let  $1 and <math>f \in L^p_{loc}(\mathbb{R}^{N-1})$ , and consider the function  $v : \mathbb{R}^{N-1} \times (0,b) \to \mathbb{R}$  defined by

$$v(x) := \frac{1}{x_{N_{\hspace{0.05cm} \text{\tiny m}},N-1}^{N}} \int\limits_{N-1} f(y') \phi\left(\frac{x'-y'}{x_{N}}\right) \, dy'.$$

Then there exists a constant  $c = c(a, b, N, p, ||\phi||_{L^{\infty}}) > 0$  such that

$$\int\limits_{\mathbb{R}^{N-1}\times(0,b)} |v(x)|^p dx \leq c \int\limits_{\mathbb{R}^{N-1}} \int\limits_{B'(x',a)} \frac{|f(y') - f(x')|^p}{|x' - y'|^{N+p-2}} \, dy' dx'.$$

**Proof.** In view of (2.8), we can rewrite

$$v(x) = \frac{1}{x_N^N} \int_{\mathbb{R}^{N-1}} (f(y') - f(x')) \phi\left(\frac{x' - y'}{x_N}\right) dy'.$$

Since supp  $\phi \subseteq B'(0, ab^{-1})$ , we have

$$|v(x)| \le \frac{\|\phi\|_{L^{\infty}}}{x_N^N} \int_{B'(x',x_Nab^{-1})} |f(y') - f(x')| dy'.$$

Raising both sides to the power p and using Hölder's inequality, we obtain

$$|v(x)|^p \le \frac{cx_N^{(N-1)(p-1)}}{x_N^{Np}} \int_{B'(x',x_Nab^{-1})} |f(y') - f(x')|^p dy'$$

$$= \frac{c}{x_N^{N+p-1}} \int_{B'(x',x_Nab^{-1})} |f(y') - f(x')|^p dy'.$$

Integrating both sides over  $\mathbb{R}^{N-1} \times (0,b)$  and using Tonelli's theorem shows that

$$\int_{\mathbb{R}^{N-1}\times(0,b)} |v(x)|^p dx \leq c \int_{\mathbb{R}^{N-1}} \int_0^b \frac{c}{x_N^{N+p-1}} \int_{B'(x',x_Nab^{-1})} |f(y') - f(x')|^p dy' dx_N dx'$$

$$= c \int_{\mathbb{R}^{N-1}} \int_{B'(x',a)} |f(y') - f(x')|^p \int_{ba^{-1}|x'-y'|}^b \frac{1}{x_N^{N+p-1}} dx_N dy' dx'$$

$$\leq c \int_{\mathbb{R}^{N-1}} \int_{B'(x',a)} \frac{|f(y') - f(x')|^p}{|x' - y'|^{N+p-2}} dy' dx',$$

which is the desired bound.  $\Box$ 

#### 2.3. High-order integration by parts on intervals

We now record an elementary calculus result that will play a key role in our trace analysis.

**Proposition 2.4.** Given a function  $f \in C^m([0,b])$ , for b > 0 and  $m \in \mathbb{N}$ , we have that

$$\sum_{k=0}^{m-1} \frac{(-1)^k}{k!} (f^{(k)}(b) + (-1)^{k+1} f^{(k)}(0)) \left(\frac{b}{2}\right)^k = \frac{1}{(m-1)!} \int_0^b f^{(m)}(t) \left(\frac{b}{2} - t\right)^{m-1} dt.$$
(2.9)

In particular, for m=2,

$$f(b) - f(0) - (f'(b) + f'(0))\frac{b}{2} = \int_{0}^{b} f''(t) \left(\frac{b}{2} - t\right) dt.$$
 (2.10)

**Proof.** To prove the identity we simply apply the fundamental theorem of calculus and then integrate by parts m-times:

$$f(b) - f(0) = \int_{0}^{b} f'(t) dt = -\int_{0}^{b} f'(t) \left(\frac{b}{2} - t\right)' dt$$

$$= (f'(b) + f'(0)) \frac{b}{2} + \int_{0}^{b} f''(t) \left(\frac{b}{2} - t\right) dt$$

$$= (f'(b) + f'(0)) \frac{b}{2} - (f''(b) - f''(0)) \left(\frac{b}{2}\right)^{2} + \frac{1}{2} \int_{0}^{b} f'''(t) \left(\frac{b}{2} - t\right)^{2} dt = \cdots$$

$$= \sum_{k=1}^{m-1} \frac{(-1)^{k-1}}{k!} (f^{(k)}(b) + (-1)^{k+1} f^{(k)}(0)) \left(\frac{b}{2}\right)^{k}$$

$$+ \frac{1}{(m-1)!} \int_{0}^{b} f^{(m)}(t) \left(\frac{b}{2} - t\right)^{m-1} dt. \quad \Box$$

### 2.4. Seminormed spaces

Here we recall a few useful facts about seminormed spaces (we refer to Taylor's book [35] for a more thorough discussion). Given a real vector space X, a seminorm is a function  $q:X\to [0,\infty)$  with the properties that  $q(x+y)\le q(x)+q(y)$  for all  $x,y\in X$  and q(tx)=|t|q(x) for every  $t\in\mathbb{R}$  and  $x\in X$ . Note that q(0)=0, but in general the subspace  $K:=\{x\in X\,|\, q(x)=0\}$  may contain more than the zero vector. The family of balls  $\{x\in X\,|\, q(x)< r\}$ , for r>0, is a local base for a topology that turns X into a locally convex topological vector space. Note that, following [35], we do not require locally convex spaces to be Hausdorff.

A sequence  $\{x_n\}_{n\in\mathbb{N}}$  in X is a Cauchy sequence if for every  $\varepsilon > 0$ , there exists  $n_{\varepsilon} \in \mathbb{N}$  such that

$$q(x_n - x_m) < \varepsilon$$

for all  $n, m \geq n_{\varepsilon}$ . We say that X is sequentially complete if every Cauchy sequence converges in X, that is, if for every Cauchy sequence  $\{x_n\}_{n\in\mathbb{N}}$  there exists  $x\in X$  such that every  $\varepsilon>0$ , there exists  $n_{\varepsilon}\in\mathbb{N}$  such that

$$q(x_n - x) < \varepsilon$$

for all  $n \ge n_{\varepsilon}$ . Since X is not Hausdorff in general, the limit x will not be unique. Indeed, if  $x_n \to x$  and  $z \in K$ , then  $x_n \to x + z$  as well.

One can prove (see for instance Theorem 3.8-C in [35]) that a linear functional  $T: X \to \mathbb{R}$  is continuous if and only if there exists a constant c > 0 such that

$$|T(x)| \le cq(x) \text{ for all } x \in X.$$
 (2.11)

We write

$$X' = \{T : X \to \mathbb{R} \mid T \text{ is continuous}\}\$$

for the linear space of continuous linear functionals. For a linear map  $T:X\to\mathbb{R}$  we define

$$||T||_{X'} := \sup\{|T(x)| \mid q(x) \le 1\} \in [0, \infty]. \tag{2.12}$$

The following lemma records some essential properties of this map.

**Lemma 2.5.** The following hold.

(1) A linear map  $T: X \to \mathbb{R}$  is continuous if and only if  $||T||_{X'} < \infty$ . Moreover, if  $T \in X'$ , then

$$|T(x)| \le q(x) ||T||_{X'} \text{ for all } x \in X.$$
 (2.13)

(2)  $\|\cdot\|_{X'}$  defines a norm on X'.

**Proof.** We begin with the proof of the first item. The "only if" part is obvious thanks to (2.11). Suppose, then, that  $||T||_{X'} < \infty$ . By the positive homogeneity of q, for every  $x \in X \setminus K$  we have that y = x/q(x) satisfies q(y) = 1, and so the linearity of T implies that

$$|T(x)| = q(x)|T(y)| \le q(x)||T||_{X'}.$$

It remains to consider the case  $x \in K$ . In this case  $0 = q(sx) \le 1$  for every s > 0, and hence  $s|T(x)| = |T(sx)| \le ||T||_{X'}$  for every s > 0. Sending  $s \to \infty$  then shows that T(x) = 0, and thus that  $|T(x)| = 0 = q(x)||T||_{X'}$ . We have now shown that (2.13) holds, which in particular guarantees that T is continuous. This completes the proof of the first item.

To prove the second item, we first note that  $X' \ni T \mapsto ||T||_{X'}$  clearly defines a seminorm, so it suffices to prove that  $||T||_{X'} = 0$  implies that T = 0. If  $||T||_{X'} = 0$ , then (2.13) implies that T(x) = 0 for all  $x \in X$ , and so T = 0. This proves the second item.  $\square$ 

It is often convenient to use a seminormed space X to produce a normed space; to do so, we take the quotient over the subspace K. More precisely, we define an equivalence relation  $\sim$  on X by setting, for  $x,y\in X,\,x\sim y$  if  $x-y\in K$ . Then the quotient vector space X/K is defined to be the set

$$X/K = \{ [x] \mid x \in X \},\$$

where  $[x] := \{y \in X \mid x \sim y\}$ , endowed with the vector space structure  $\alpha[x] + \beta[y] := [\alpha x + \beta y]$ . The quotient space X/K is a normed space when endowed with the norm

$$||[x]||_{X/K} := q(x). \tag{2.14}$$

In view of (2.14), it follows that a sequence  $\{[x_n]\}_{n\in\mathbb{N}}$  in X/K is a Cauchy sequence if and only if  $\{x_n\}_{n\in\mathbb{N}}$  is a Cauchy sequence in X. Thus, the completeness of X/K is equivalent to the sequential completeness of X.

Observe that if  $T: X \to \mathbb{R}$  is continuous and if  $x \sim y$ , then x = y + z for some  $z \in K$ . The estimate (2.11) guarantees that T(z) = 0, and so T(x) = T(y). Thus, the functional  $T_1: X/K \to \mathbb{R}$  given by

$$T_1([x]) := T(x)$$

is well-defined, linear and continuous, and by (2.12) and (2.14),

$$||T_1||_{(X/K)'} = \sup\{|T_1([x])| \mid ||[x]||_{X/K} \le 1\}$$
$$= \sup\{|T(x)| \mid q(x) \le 1\} = ||T||_{X'} < \infty.$$

Conversely, if  $T_1: X/K \to \mathbb{R}$  is linear and continuous, then

$$|T_1([x])| \le ||T_1||_{(X/K)'}||[x]||_{X/K} = ||T_1||_{(X/K)'}q(x)$$

for all  $x \in X$ . Thus, if we define the functional  $T: X \to \mathbb{R}$  via  $T(x) := T_1([x])$ , then the previous inequality implies that

$$||T||_{X'} = \sup\{|T_1([x])| | q(x) \le 1\} \le ||T_1||_{(X/K)'},$$

and so Lemma 2.5 guarantees that T is continuous. This shows that

$$||T_1||_{(X/K)'} = ||T||_{X'},$$

that is, that there is an isometric isomorphism between the topological dual X' of X and the topological dual (X/K)' of X/K.

In particular, if X/K is reflexive and  $\{x_n\}_{n\in\mathbb{N}}$  is a bounded sequence in X, i.e. there exists c>0 such that  $q(x_n)\leq c$  for all  $n\in\mathbb{N}$ , then (2.14) tells us that  $\|[x_n]\|_{X/K}\leq c$  for all  $n\in\mathbb{N}$ . It follows by Kakutani's theorem (see, for instance, Theorem 3.17 of [10]) that there exists a subsequence  $\{[x_{n_k}]\}_{k\in\mathbb{N}}$  and  $[x]\in X/K$  such that  $[x_{n_k}] \rightharpoonup [x]$ . That is,

$$T_1([x_{n_k}]) \to T_1([x])$$

for every  $T_1 \in (X/K)'$ . In view of the previous discussion, this is equivalent to saying that

$$T(x_{n_k}) \to T(x)$$

for every  $T \in X'$ . By slight abuse of notation, we will write this as  $x_{n_k} \rightharpoonup x$ .

#### 3. Screened homogeneous fractional Sobolev spaces

In this section we introduce and study the properties of a class of screened homogeneous fractional Sobolev spaces. These spaces play an essential role in the main trace theory results of the paper, but they are interesting in their own right.

#### 3.1. Homogeneous Sobolev spaces

Before introducing the screened spaces we recall the usual homogeneous Sobolev spaces, starting with the spaces of integer order. Given an open set  $U \subseteq \mathbb{R}^N$ ,  $m \in \mathbb{N}$ , and  $1 \leq p \leq \infty$ , the homogeneous Sobolev space  $\dot{W}^{m,p}(U)$  is defined as the space of all real-valued functions  $u \in L^1_{loc}(U)$  whose distributional derivatives of order m belong to  $L^p(U)$ . The space  $\dot{W}^{m,p}(U)$  is endowed with the seminorm

$$u \mapsto \|\nabla^m u\|_{L^p(U)},\tag{3.1}$$

where we recall that  $\nabla^m$  is the vector of all partial derivatives  $\partial^{\alpha}$  for multi-indices  $\alpha \in \mathbb{N}_0^N$  with  $|\alpha| = m$ . In view of the discussion in Section 2.4, the seminorm (3.1) turns  $\dot{W}^{m,p}(U)$  into a locally convex topological vector space. Also, a linear functional  $T: \dot{W}^{m,p}(U) \to \mathbb{R}$  is continuous if and only if there exists a constant c > 0 such that

$$|T(u)| \le c \|\nabla^m u\|_{L^p(U)} \tag{3.2}$$

for all  $u \in \dot{W}^{m,p}(U)$ . Moreover,  $\|\nabla^m u\|_{L^p(U)} = 0$  if and only if u is a polynomial of degree less than or equal to m-1 in each connected component of U.

Let  $\mathcal{P}_{m-1}$  denote the set of functions on U that agree on each connected component of U with a polynomial from  $\mathbb{R}^N$  into  $\mathbb{R}$  of degree less than or equal to m-1. Then the quotient space  $\dot{W}^{m,p}(U)/\mathcal{P}_{m-1}$  is a Banach space with the norm

$$||[u]||_{\dot{W}^{m,p}(U)/\mathcal{P}_{m-1}} := ||\nabla^m u||_{L^p(U)}.$$

When m=1, the family  $\mathcal{P}_0$  is just the family of functions that are constant in each connected component of U, and by slight abuse of notation we write  $\dot{W}^{1,p}(U)/\mathbb{R}$  in place of  $\dot{W}^{1,p}(U)/\mathcal{P}_0$ .

The homogeneous spaces can be extended to non-integer order 0 < s < 1 by use of the seminorm

$$|u|_{\dot{W}^{s,p}(U)} := \left( \int_{U} \int_{U} \frac{|u(y) - u(x)|^{p}}{|y - x|^{sp+N}} dy dx \right)^{1/p}. \tag{3.3}$$

For  $1 \leq p < \infty$  and 0 < s < 1 the seminormed homogeneous fractional Sobolev space  $\dot{W}^{s,p}(U)$  consists of those functions  $u \in L^1_{\mathrm{loc}}(U)$  for which  $|u|_{\dot{W}^{s,p}(U)} < \infty$ . As above, we can use this space to generate a Banach space  $\dot{W}^{s,p}(U)/\mathbb{R}$  by quotienting out by the functions that are constant in each connected component. The inhomogeneous fractional Sobolev space  $W^{s,p}(U)$  is given by  $W^{s,p}(U) = L^p(U) \cap \dot{W}^{s,p}(U)$  with norm  $||f||_{W^{s,p}(U)} = ||f||_{L^p(U)} + |f|_{W^{s,p}(U)}$ , which makes the space Banach. We refer to [1], [5], [6], [7], [12], [13], [21], [23], [24], [29], [30], [37] for an exhaustive survey of what is known about these spaces.

In order to prove our trace results we will need to employ a version of the fundamental theorem of calculus. We now record a result that will allow us to employ such a tool in the spaces  $\dot{W}^{m,p}(U)$ .

**Theorem 3.1.** Let  $U \subseteq \mathbb{R}^N$  be an open set,  $m \in \mathbb{N}$ , and  $1 \leq p < \infty$ . If  $u \in \dot{W}^{m,p}(U)$ , then u has a representative  $\overline{u}$  that is absolutely continuous together with all its derivatives of order up to m-1 on  $\mathcal{L}^{N-1}$ -a.e. line segments of U that are parallel to the coordinate axes and whose classical partial derivatives of order m belong to  $L^p(U)$ . Moreover the classical partial derivatives of order m of  $\overline{u}$  agree  $\mathcal{L}^N$ -a.e. with the weak derivatives of u.

**Proof.** The proof is a modification of Theorem 11.45 from the book [23], and as such we will refer frequently to other results from the book. Throughout the proof we use the following notational convention: given  $x_i' \in \mathbb{R}^{N-1}$  and  $x_i \in \mathbb{R}$  we write  $(x_i', x_i) \in \mathbb{R}^N$  for the vector obtained by placing  $x_i$  in the *i*th component and the components of  $x_i'$  in the remaining N-1 components. Then for a set  $E \subseteq \mathbb{R}^N$ , we write

$$E_{x'_i} := \{ x_i \in \mathbb{R} : (x'_i, x_i) \in E \}.$$

Moreover, if  $v: U \to \mathbb{R}$  is Lebesgue integrable, with a slight abuse of notation, if  $U_{x'_i}$  is empty, we set

$$\int_{U_{x_i'}} v(x_i', x_i) \, dx_i := 0,$$

so that by Fubini's theorem

$$\int_{U} v(x) dx = \int_{\mathbb{R}^{N-1}} \left( \int_{U_{x'_{i}}} v(x'_{i}, x_{i}) dx_{i} \right) dx'_{i}.$$
 (3.4)

Assume now that  $u \in \dot{W}^{m,p}(U)$ . Consider a sequence of standard mollifiers  $\{\varphi_{\varepsilon}\}_{{\varepsilon}>0}$  and for every  ${\varepsilon}>0$  define  $u_{\varepsilon}:=u*\varphi_{\varepsilon}$  in  $U_{\varepsilon}:=\{x\in U: \operatorname{dist}(x,\partial U)>{\varepsilon}\}$ . By Lemma 11.25 in [23] we have that

$$\lim_{\varepsilon \to 0^+} \int_{U_{-}} \|\nabla^m u_{\varepsilon}(x) - \nabla^m u(x)\|^p dx = 0.$$

It follows by Fubini's theorem and (3.4) that for all i = 1, ..., N,

$$\lim_{\varepsilon \to 0^+} \int_{\mathbb{R}^{N-1}} \left( \int_{(U_{\varepsilon})_{x_i'}} \|\nabla^m u_{\varepsilon}(x_i', x_i) - \nabla^m u(x_i', x_i)\|^p dx_i \right) dx_i' = 0,$$

where  $(U_{\varepsilon})_{x_i'} := \{x_i \in \mathbb{R} : (x_i', x_i) \in U_{\varepsilon}\}$ , and so we may find a subsequence  $\{\varepsilon_n\}_{n \in \mathbb{N}}$  such that for all  $i = 1, \ldots, N$  and for  $\mathcal{L}^{N-1}$  a.e.  $x_i' \in \mathbb{R}^{N-1}$ ,

$$\lim_{n \to \infty} \int_{(U_{\varepsilon_n})_{x_i'}} \|\nabla^m u_{\varepsilon_n}(x_i', x_i) - \nabla^m u(x_i', x_i)\|^p dx_i = 0.$$
(3.5)

We set  $u_n := u_{\varepsilon_n}$  and define the sets

$$E := \{ x \in U : \lim_{n \to \infty} u_n(x) \text{ exists in } \mathbb{R} \},$$
  
$$E_{i,l} := \{ x \in U : \lim_{n \to \infty} \partial_i^l u_n(x) \text{ exists in } \mathbb{R} \}$$

for i = 1, ..., N and l = 1, ..., m - 1. We then define  $\bar{u}, v_{i,l} : U \to \mathbb{R}$  via

$$\overline{u}(x) := \begin{cases} \lim_{n \to \infty} u_n(x) & \text{if } x \in E, \\ 0 & \text{otherwise,} \end{cases}$$

$$v_{i,l}(x) := \begin{cases} \lim_{n \to \infty} \partial_i^l u_n(x) & \text{if } x \in E_{i,l}, \\ 0 & \text{otherwise.} \end{cases}$$

By standard properties of mollifiers (see for instance Theorem C.16 in [23]) we have that  $\{u_n\}_{n\in\mathbb{N}}$  converges pointwise to u at every Lebesgue point of u, so the set E contains every Lebesgue point of u. It follows from Corollary B.119 in [23] that  $\mathcal{L}^N(U\setminus E)=0$ , and so  $\overline{u}$  is a representative of u. Similarly,  $\{\partial_i^l u_n\}_{n\in\mathbb{N}}$  converges pointwise to  $\partial_i^l u$  at every Lebesgue point of  $\partial_i^l u$  and  $\mathcal{L}^N(U\setminus E_{i,l})=0$  for every  $n=1,\ldots,m-1$ .

It remains to prove that  $\overline{u}$  has the desired properties. To this end we define

$$F:=E\cap\bigcap_{i=1}^N\bigcap_{l=1}^{m-1}E_{i,l}.$$

By Fubini's theorem and (3.4) for every i = 1, ..., N we have that

$$\int\limits_{\mathbb{R}^{N-1}} \left( \int\limits_{U_{x'_i}} \|\nabla^m u(x'_i, x_i)\|^p dx_i \right) dx'_i < \infty$$

and

$$\int_{\mathbb{R}^{N-1}} \mathcal{L}^1(\{x_i \in U_{x_i'} : (x_i', x_i) \notin F\}) \, dx_i' = 0,$$

and so we may find a set  $N_i \subset \mathbb{R}^{N-1}$ , with  $\mathcal{L}^{N-1}(N_i) = 0$ , such that for all  $x_i' \in \mathbb{R}^{N-1} \setminus N_i$  for which  $U_{x_i'}$  is nonempty we have that

$$\int\limits_{U_{x'}}\|\nabla^m u(x_i',x_i)\|^p dx_i < \infty$$

and (3.5) holds for all i = 1, ..., N and  $(x'_i, x_i) \in F$  for  $\mathcal{L}^1$  a.e.  $x_i \in U_{x'_i}$ .

Fix any such  $x_i'$  and let  $I \subseteq U_{x_i'}$  be a maximal interval. Fix  $t_0 \in I$  such that  $(x_i', t_0) \in F$  and let  $t \in I$ . For all n large, the interval of endpoints t and  $t_0$  is contained in  $(U_{\varepsilon_n})_{x_i'}$  and so, since  $u_n \in C^{\infty}(U_{\varepsilon_n})$ , by Taylor's formula,

$$u_n(x_i',t) = u_n(x_i',t_0) + \sum_{k=1}^{m-1} \frac{1}{k!} \partial_i^k u_n(x_i',t_0) (t-t_0)^k + \frac{1}{(m-1)!} \int_{t_0}^t (t-s)^{m-1} \partial_i^m u_n(x_i',s) \, ds,$$

and

$$\partial_i^j u_n(x_i', t) = \partial_i^j u_n(x_i', t_0) + \sum_{k=1}^{m-j-1} \frac{1}{k!} \partial_i^{k+j} u_n(x_i', t_0) (t - t_0)^k + \frac{1}{(m-j-1)!} \int_{t_0}^t (t - s)^{m-j-1} \partial_i^m u_n(x_i', s) \, ds,$$

for all  $j=1,\ldots,m-1$ . Since  $(x_i',t_0) \in F$ , we have  $u_n(x_i',t_0) \to \overline{u}(x_i',t_0) \in \mathbb{R}$  and  $\partial_i^k u_n(x_i',t_0) \to v_{i,k}(x_i',t_0) \in \mathbb{R}$  for all  $k=1,\ldots,m-1$ . On the other hand, by (3.5),

$$\lim_{n\to\infty} \int_{t_0}^t |(t-s)^{m-1} (\partial_i^m u_n(x_i',s) - \partial_i^m u(x_i',s))| ds = 0.$$

Hence as  $n \to \infty$ .

$$u_n(x_i',t) \to \overline{u}(x_i',t_0) + \sum_{k=1}^{m-1} \frac{1}{k!} v_{i,k}(x_i',t_0) (t-t_0)^k + \frac{1}{(m-1)!} \int_{t_0}^t (t-s)^{m-1} \partial_i^m u(x_i',s) \, ds,$$

and

$$\partial_i^j u_n(x_i', t) \to v_{i,j}(x_i', t_0) + \sum_{k=1}^{m-j-1} \frac{1}{k!} v_{i,k+j}(x_i', t_0) (t - t_0)^k$$
$$+ \frac{1}{(m-j-1)!} \int_{t_0}^t (t - s)^{m-j-1} \partial_i^m u(x_i', s) \, ds$$

for all  $j=1,\ldots,m-1$ . Note that by the definition of E and  $\overline{u}$ , this implies, in particular, that  $(x_i',t)\in E\cap \bigcap_{l=1}^{m-1}E_{i,l}$  and

$$\overline{u}(x_i',t) = \overline{u}(x_i',t_0) + \sum_{k=1}^{m-1} \frac{1}{k!} v_{i,k}(x_i',t_0) (t-t_0)^k + \frac{1}{(m-1)!} \int_{t_0}^t (t-s)^{m-1} \partial_i^m u(x_i',s) \, ds,$$

and

$$v_{i,j(x'_i,t)} = v_{i,j}(x'_i,t_0) + \sum_{k=1}^{m-j-1} \frac{1}{k!} v_{i,k+j}(x'_i,t_0) (t-t_0)^k$$
$$+ \frac{1}{(m-j-1)!} \int_{t_0}^t (t-s)^{m-j-1} \partial_i^m u(x'_i,s) \, ds$$

for all  $t \in I$  and for all j = 1, ..., m-1. Hence, by Theorem 3.16 in [23], the function  $\overline{u}(x_i', \cdot)$  is of class  $C^{m-1}$  and its derivative of order m-1 is absolutely continuous in I with  $\partial_i^j \overline{u}(x_i', t) = v_{i,j}(x_i', t)$  for all  $t \in I$  and  $\partial_i^m \overline{u}(x_i', t) = \partial_i^m u(x_i', t)$  for  $\mathcal{L}^1$  a.e.  $t \in I$ .  $\square$ 

# 3.2. Screened homogeneous fractional Sobolev spaces: definitions and basic properties

In this subsection we define some new fractional Sobolev spaces and study their functional properties. We are primarily interested in these spaces due to their role in our trace results, but they are of independent interest due to their intriguing properties. As such, we have chosen to define them on general open sets in  $\mathbb{R}^N$  rather than on the set appropriate for the trace theory,  $\mathbb{R}^{N-1}$ .

We begin by defining the spaces. Let  $U \subseteq \mathbb{R}^N$  be open. We say that a function  $\sigma: U \to (0, \infty]$  is a *screening function* on U if  $\sigma$  is lower semi-continuous, in which case for each  $x \in U$  we define the measurable set

$$H(x) = B(0, \sigma(x)) \cap (-x + U),$$

where  $-x+U=\{z\in\mathbb{R}^N\mid z=-x+y \text{ for some }y\in U\}$ . Here we understand that  $B(x,\infty)=\mathbb{R}^N$ . Given a screening function  $\sigma:U\to(0,\infty],\ 1\leq p<\infty,$  and 0< s<1, we define the screened homogeneous fractional Sobolev space  $\tilde{W}^{s,p}_{(\sigma)}(U)$  to be the space of all functions  $f\in L^1_{\mathrm{loc}}(U)$  such that

$$|f|_{\tilde{W}^{s,p}_{(\sigma)}(U)} := \left( \int\limits_{U} \int\limits_{H(x)} \frac{|f(x+h) - f(x)|^p}{|h|^{sp+N}} \, dh dx \right)^{1/p} < \infty.$$

The quantity  $|\cdot|_{\tilde{W}^{s,p}_{(\sigma)}(U)}$  is only a seminorm since any constant function will have seminorm zero. Note that we can rewrite

$$|f|_{\tilde{W}^{s,p}_{(\sigma)}(U)} := \left( \int_{U} \int_{B(x,\sigma(x))\cap U} \frac{|f(y) - f(x)|^p}{|y - x|^{sp+N}} \, dy dx \right)^{1/p}.$$

Comparing this to (3.3) makes evident three important features. First, it justifies our choice of the moniker screening function:  $\sigma$  screens the difference quotient from values of y far away from x. Second, it shows that we recover the standard fractional Sobolev space for any screening function satisfying  $\sigma \geq \text{diam}(U)$  on U. In particular,  $\tilde{W}_{(\infty)}^{s,p}(U) = \dot{W}^{s,p}(U)$ . Third, this form of the seminorm establishes that  $|f|_{\tilde{W}_{(\sigma)}^{s,p}(U)} \leq |f|_{\dot{W}^{s,p}(U)}$  and hence that

$$\dot{W}^{s,p}(U) \subseteq \tilde{W}^{s,p}_{(\sigma)}(U).$$

We will show later in Theorem 3.11 that in general this inclusion may be strict.

We now begin our study of the screened spaces by proving that  $|f|_{\tilde{W}_{(\sigma)}^{s,p}(U)} = 0$  if and only if f is constant in each connected component.

**Proposition 3.2.** Suppose that  $U \subseteq \mathbb{R}^N$  is open. Let  $\sigma: U \to (0, \infty]$  be a screening function,  $1 \leq p < \infty$ , and 0 < s < 1. Given  $f \in L^p_{\text{loc}}(U)$ , we have that  $|f|_{\tilde{W}^{s,p}_{(\sigma)}(U)} = 0$  if and only if f is equivalent to a constant in each connected component of U.

**Proof.** Obviously, if f equals a constant almost everywhere in U, then  $|f|_{\tilde{W}^{s,p}_{(\sigma)}(U)} = 0$ . Suppose, then, that  $|f|_{\tilde{W}^{s,p}_{(\sigma)}(U)} = 0$ . We will prove that f is equivalent to a constant. Assume initially that U is connected.

Since  $|f|_{\tilde{W}^{s,p}_{(\sigma)}(U)} = 0$ , there exists a Lebesgue measurable set  $E \subset U$  with  $\mathcal{L}^N(E) = 0$  such that if  $x \in U \setminus E$ , then

$$\int_{H(x)} \frac{|f(x+h) - f(x)|^p}{|h|^{sp+N}} dh = 0.$$

In turn, f(x+h) - f(x) = 0 for  $\mathcal{L}^N$  a.e.  $h \in H(x)$ , which implies that f is equivalent to a constant in the set  $B(x, \sigma(x)) \cap U$  whenever  $x \in U \setminus E$ .

Fix  $x_0 \in U \setminus E$  and let c denote the constant that f is equivalent to in the set  $B(x_0, \sigma(x_0)) \cap U$ . Define the set

$$S = \{x \in U \mid \text{there exists } \delta > 0 \text{ s.t. } f = c \text{ a.e. in } B(x, \delta) \subseteq U\}.$$

By construction we have that  $x_0 \in S$ . We claim that, in fact, S = U. Once this is established, it follows that f = c a.e. in U, which completes the proof when U is connected.

Suppose that  $x \in S$ . Then there exists  $\delta > 0$  such that f = c a.e. in  $B(x, \delta) \subseteq U$ . If  $y \in B(x, \delta/2)$ , then  $B(y, \delta/2) \subseteq B(x, \delta)$ , and so f = c a.e. in  $B(y, \delta/2) \subset U$ . Thus  $B(x, \delta/2) \subseteq S$ , and we conclude that S is open.

Suppose now that  $\{x_n\}_{n\in\mathbb{N}}$  is a sequence in S such that  $x_n\to x\in U$  as  $n\to\infty$ . Set  $R\in(0,\infty)$  according to

$$R = \begin{cases} 1 & \text{if } \sigma(x) = \infty \\ \sigma(x)/2 & \text{if } \sigma(x) < \infty. \end{cases}$$
 (3.6)

Note that  $x \in \sigma^{-1}((R, \infty])$  by construction, but  $\sigma$  is lower semi-continuous, so the set  $\sigma^{-1}((R, \infty])$  is open. Consequently, we may choose 0 < r < R such that  $B(x, r) \subseteq \sigma^{-1}((R, \infty]) \subseteq U$ . Since E is a null set, there must exist  $y \in B(x, r) \setminus E$ . Then, by construction,  $|x - y| < r < R < \sigma(y)$ , and hence  $x \in B(y, \sigma(y)) \cap U$ . From the above analysis, we know that f is equivalent to a constant b in  $B(y, \sigma(y)) \cap U$ , and hence f is equivalent to b in  $B(x, \delta)$  for some  $\delta > 0$ . However, for  $n \in \mathbb{N}$  sufficiently large we have that  $x_n \in B(x, \delta)$ , and since  $x_n \in S$  we conclude that b = c. Hence  $x \in S$ , and we deduce that S is relatively closed in U.

We have now shown that  $S \subseteq U$  is nonempty, open, and relatively closed. Since U is connected, we conclude that S = U, which completes the proof of the claim. Now, in the general case when U is not connected, we let  $\{U_{\alpha}\}_{\alpha \in A}$  denote the connected components of U. Since  $|f|_{\tilde{W}^{s,p}_{(\sigma)}(U)} = 0$ , we also know that  $|f|_{\tilde{W}^{s,p}_{(\sigma)}(U_{\alpha})} = 0$  for each  $\alpha \in A$ . The above analysis then shows that f is equivalent to a constant in each  $U_{\alpha}$ , which completes the proof in the general case.  $\square$ 

We next turn our attention to proving a Poincaré-type inequality for the screened spaces. We refer to [9] and [31] for similar inequalities in the non-screened case. We begin with a lemma.

**Lemma 3.3.** Let  $U \subseteq \mathbb{R}^N$  be open and let  $\sigma: U \to (0, \infty]$  be a screening function. For each  $x \in U$  there exists  $0 < r_x < \sigma(x)$  such that  $B(x, 2r_x) \subseteq U$  and  $2r_x < \sigma(y)$  for all  $y \in B(x, r_x)$ .

**Proof.** Let  $R \in (0, \infty)$  be given by (3.6). Then  $x \in \sigma^{-1}((R, \infty])$ , and since  $\sigma$  is lower semi-continuous we can pick s > 0 such that  $B(x, s) \subseteq \sigma^{-1}((R, \infty])$ . Set  $r_x = \frac{1}{2} \min\{s, R\} \in (0, \sigma(x))$ . Clearly  $B(x, 2r_x) \subseteq U$ . For  $y \in B(x, r_x) \subseteq B(x, s) \subseteq \sigma^{-1}((R, \infty])$  we then have that  $2r_x \leq R < \sigma(y)$ , as desired.  $\square$ 

Next we prove a Poincaré inequality for small balls.

**Proposition 3.4** (Poincaré inequality on small balls). Suppose that  $U \subseteq \mathbb{R}^N$  is open,  $1 \leq p < \infty$ , and 0 < s < 1. Then there exists a constant c = c(N, s, p) > 0 such that if  $f \in L^1_{loc}(U)$ ,  $B(x, r) \subseteq U$ , and  $E \subseteq B(x, r)$  is a Lebesgue measurable set, compactly contained in U, such that  $\mathcal{L}^N(E) > 0$ , then

$$\int_{B(x,r)} |f(y) - f_E|^p dy \le c \frac{r^{sp+N}}{\mathcal{L}^N(E)} \int_{B(x,r)} \int_E \frac{|f(y) - f(z)|^p}{|y - z|^{sp+N}} dz dy,$$

where

$$f_E := \frac{1}{\mathcal{L}^N(E)} \int\limits_E f(z) \, dz.$$

In particular, given a screening function  $\sigma: U \to (0, \infty]$  and  $x \in U$ , if  $0 < r \le r_x$  for  $r_x$  given by Lemma 3.3, then

$$\int_{B(x,r)} |f(y) - f_E|^p dy \le c \frac{r^{sp+N}}{\mathcal{L}^N(E)} \int_{B(x,r)} \int_{H(y)} \frac{|f(y+h) - f(y)|^p}{|h|^{sp+N}} dh dy.$$

**Proof.** For every  $y \in B(x,r)$  we have that

$$f(y) - f_E = \frac{1}{\mathcal{L}^N(E)} \int_E (f(y) - f(z)) dz = \frac{1}{\mathcal{L}^N(E)} \int_E |y - z|^{(sp+N)/p} \frac{f(y) - f(z)}{|y - z|^{(sp+N)/p}} dz.$$

Hence, by Hölder's inequality,

$$|f(y) - f_E|^p \le \frac{1}{(\mathcal{L}^N(E))^p} \left( \int_E |y - z|^{(sp+N)/(p-1)} dz \right)^{p-1} \int_E \frac{|f(y) - f(z)|^p}{|y - z|^{sp+N}} dz$$

$$\le \frac{cr^{sp+N}}{\mathcal{L}^N(E)} \int_E \frac{|f(y) - f(z)|^p}{|y - z|^{sp+N}} dz.$$

Integrating both sides in y over B(x,r) then gives the bound

$$\int_{B(x,r)} |f(y) - f_E|^p dy \le \frac{cr^{sp+N}}{\mathcal{L}^N(E)} \int_{B(x,r)} \int_E \frac{|f(y) - f(z)|^p}{|y - z|^{sp+N}} dz dy,$$

which proves the first inequality.

To prove the second inequality we observe that if  $0 < r \le r_x$ , then Lemma 3.3 implies that  $2r \le 2r_x < \sigma(y)$  for all  $y \in B(x,r)$ . Then for each  $y \in B(x,r)$  we have the inclusions  $E \subseteq B(x,r) \subseteq B(y,2r) \cap U \subseteq B(y,\sigma(y)) \cap U$ , and we may thus estimate

$$\frac{cr^{sp+N}}{\mathcal{L}^{N}(E)} \int_{B(x,r)} \int_{E} \frac{|f(y) - f(z)|^{p}}{|y - z|^{sp+N}} dzdy \leq \frac{cr^{sp+N}}{\mathcal{L}^{N}(E)} \int_{B(x,r)} \int_{B(y,\sigma(y))\cap U} \frac{|f(y) - f(z)|^{p}}{|y - z|^{sp+N}} dzdy \\
\leq \frac{cr^{sp+N}}{\mathcal{L}^{N}(E)} \int_{B(x,r)} \int_{H(y)} \frac{|f(y) - f(y + h)|^{p}}{|h|^{sp+N}} dhdy.$$

The second inequality then follows from this and the first inequality.  $\Box$ 

With the small ball Poincaré inequality in hand, we can now prove a more general version. Although this estimate is interesting in its own right, it will play a key role in proving completeness of  $\tilde{W}_{(\sigma)}^{s,p}(U)/\mathbb{R}$ .

**Theorem 3.5** (Poincaré inequality on connected unions of small balls). Suppose that  $U \subseteq \mathbb{R}^N$  is open and connected,  $1 \leq p < \infty$ , and 0 < s < 1. Let  $\sigma: U \to (0, \infty]$  be a screening function. Further suppose that there exist  $x_n \in U$  and  $r_n > 0$  for  $n = 1, \ldots, m$  such that  $r_n = r_{x_n} > 0$  is given by Lemma 3.3 and

$$U = \bigcup_{n=1}^{m} B(x_n, r_n).$$

Then for every Lebesgue measurable set E compactly contained in U such that  $\mathcal{L}^N(E) > 0$ there exists a constant c = c(U, E, p, s) > 0 such that

$$||f - f_E||_{L^p(U)} \le c|f|_{\tilde{W}_{(\sigma)}^{s,p}(U)}$$
 (3.7)

for all  $f \in L^1_{loc}(U)$ , where

$$f_E = \frac{1}{\mathcal{L}^N(E)} \int\limits_E f(x) dx.$$

**Proof.** First note that the triangle and Hölder inequalities provide the estimates

$$||f - f_{E}||_{L^{p}(U)} \leq ||f - f_{U}||_{L^{p}(U)} + |f_{U} - f_{E}|(\mathcal{L}^{N}(U))^{1/p}$$

$$\leq ||f - f_{U}||_{L^{p}(U)} + \frac{(\mathcal{L}^{N}(U))^{1/p}}{\mathcal{L}^{N}(E)} ||f - f_{U}||_{L^{1}(E)}$$

$$\leq ||f - f_{U}||_{L^{p}(U)} + \frac{(\mathcal{L}^{N}(U))^{1/p}}{(\mathcal{L}^{N}(E))^{1/p}} ||f - f_{U}||_{L^{p}(E)}$$

$$\leq \left(1 + \frac{(\mathcal{L}^{N}(U))^{1/p}}{(\mathcal{L}^{N}(E))^{1/p}}\right) ||f - f_{U}||_{L^{p}(U)}.$$

Thus, in order to prove the estimate (3.7), it suffices to prove that

$$||f - f_U||_{L^p(U)} \le c|f|_{\tilde{W}^{s,p}_{(\sigma)}(U)}.$$
 (3.8)

For  $n=1,\ldots,m$  set  $B_n=B(x_n,r_n/2)\subset B(x_n,r_n)\subseteq U$ . The triangle and Hölder inequalities again allow us to estimate

$$||f - f_{U}||_{L^{p}(U)} \le ||f - f_{B_{1}}||_{L^{p}(U)} + |f_{U} - f_{B_{1}}|(\mathcal{L}^{N}(U))^{1/p}$$

$$\le 2||f - f_{B_{1}}||_{L^{p}(U)} \le 2\sum_{n=1}^{m} ||f - f_{B_{1}}||_{L^{p}(B(x_{n}, r_{n}))}.$$

From this we readily deduce that in order to prove (3.8) it suffices to prove that for n = 1, ..., m there exists a constant  $k_n = k_n(U, p, s) > 0$  such that

$$||f - f_{B_1}||_{L^p(B(x_n, r_n))} \le k_n |f|_{\tilde{W}_{(\sigma)}^{s, p}(U)}.$$
 (3.9)

Note that if n = 1 then this inequality is true by virtue of Proposition 3.4, so we may further reduce to proving (3.9) when  $n \neq 1$ .

Fix  $2 \leq n \leq m$ . Since U is open and connected, it is polygonally connected, and so we can choose a polygonal path in U starting at the center of  $B_1$  and ending at the center of  $B_n$ . Since the path is connected and compact, we can choose open balls  $B_k^* = B(z_k, s_k) \subseteq U$  for  $k = 1, \ldots, \ell_n$  such that  $B_1^* = B_1$ ,  $B_{\ell_n}^* = B_n$ ,  $s_k = r_{z_k}/2$  for  $r_{z_k} > 0$  given by Lemma 3.3, and  $V_k := B_k^* \cap B_{k+1}^* \neq \emptyset$  for each  $1 \leq k \leq \ell_n - 1$ . We then use the triangle inequality to estimate

$$||f - f_{B_1}||_{L^p(B(x_n, r_n))} \le ||f - f_{B_n}||_{L^p(B(x_n, r_n))} + \sum_{k=1}^{\ell_n - 1} |f_{B_k^*} - f_{B_{k+1}^*}| (\mathcal{L}^N(B(x_n, r_n)))^{1/p}.$$
(3.10)

For the first term on the right we can use Proposition 3.4 to bound

$$||f - f_{B_n}||_{L^p(B(x_n, r_n))} \le cr_n^{sp} |f|_{\tilde{W}_{(-)}^{s, p}(U)}.$$
 (3.11)

The remaining terms require more work.

Fix  $1 \leq k \leq \ell_n - 1$  and note that, by construction, the set  $V_k = B_k^* \cap B_{k+1}^*$  is nonempty and thus has positive measure. Then the triangle and Hölder inequalities once again allow us to estimate

$$|f_{B_k^*} - f_{B_{k+1}^*}|(\mathcal{L}^N(B(x_n, r_n)))^{1/p} \leq |f_{B_k^*} - f_{V_k}|(\mathcal{L}^N(B(x_n, r_n)))^{1/p}$$

$$+ |f_{V_k} - f_{B_{k+1}^*}|(\mathcal{L}^N(B(x_n, r_n)))^{1/p}$$

$$\leq ||f - f_{V_k}||_{L^p(B_k^*)} \frac{(\mathcal{L}^N(B(x_n, r_n)))^{1/p}}{(\mathcal{L}^N(B_k^*))^{1/p}}$$

$$+ ||f - f_{V_k}||_{L^p(B_{k+1}^*)} \frac{(\mathcal{L}^N(B(x_n, r_n)))^{1/p}}{(\mathcal{L}^N(B_{k+1}^*))^{1/p}}.$$

The radii of the balls  $\{B_k^*\}$  are such that we can apply Proposition 3.4. Doing so and chaining the estimate together with the last inequality then provides us with the bound

$$\sum_{k=1}^{\ell_n - 1} |f_{B_k^*} - f_{B_{k+1}^*}| (\mathcal{L}^N(B(x_n, r_n)))^{1/p} \le c_n |f|_{\tilde{W}_{(\sigma)}^{s, p}(U)}$$
(3.12)

for a constant  $c_n = c_n(U, p, s) > 0$ . Combining (3.10), (3.11), and (3.12) then proves that (3.9) holds for all  $2 \le n \le m$ , which in turn completes the proof of (3.8).  $\square$ 

Our next result is a technical lemma that will allow us to effectively use Theorem 3.5.

**Lemma 3.6.** Let  $U \subseteq \mathbb{R}^N$  be open and connected and  $\sigma: U \to (0, \infty]$  be a screening function. Then there exists  $\{V_n\}_{n=1}^{\infty}$  with the following properties.

- (1) For each  $n \in \mathbb{N}$  we have that  $V_n \subset U$  is nonempty, open, and connected.
- (2) For each  $n \in \mathbb{N}$  there exists  $\ell_n \in \mathbb{N}$ ,  $x_{1,n}, \dots x_{\ell_n,n} \in U$ , and  $r_{1,n}, \dots, r_{\ell_n,n} > 0$  such that  $r_{k,n} = r_{x_{k,n}}$  is given by Lemma 3.3 and

$$V_n = \bigcup_{k=1}^{\ell_n} B(x_{k,n}, r_{k,n}).$$

- (3) For each  $n \in \mathbb{N}$  we have that  $\overline{V}_n \subset V_{n+1}$ .
- (4) We have that

$$U = \bigcup_{n=1}^{\infty} V_n.$$

**Proof.** For each  $x \in U$  let  $r_x > 0$  be as given by Lemma 3.3, which in particular means that  $B[x, r_x] \subset B(x, 2r_x) \subseteq U$ . Then  $\{B(x, r_x)\}_{x \in U}$  is an open cover of U, and so by Lindelöf's theorem we can choose a countably infinite subcover  $\{B_k\}_{k=1}^{\infty}$ , where  $B_k = B(x_k, r_k)$ .

We now claim that if  $\varnothing \neq I \subset \mathbb{N}$  is a finite set and  $V = \bigcup_{k \in I} B_k$ , then there exists a finite set  $J \subset \mathbb{N}$  such that  $I \subset J$  and the set  $W = \bigcup_{k \in J} B_k$  is connected and satisfies  $\bar{V} \subset W$ . To prove the claim first note that  $\bar{V} \subset U$  is compact, so we can choose a finite set  $I \subset K \subset \mathbb{N}$  such that  $\bar{V} \subset \bigcup_{k \in K} B_k$ . Note in particular that K must contain at least two elements since I is nonempty, and we may then write  $K = \{k_1, \ldots, k_m\}$  for  $m \geq 2$ . Since U is open and connected, for  $j = 2, \ldots, m$  there exists a polygonal path between the centers of  $B_{k_1}$  and  $B_{k_j}$ . This path is connected and compact, so we can choose a finite set  $J_j \subset \mathbb{N}$  such that  $k_1, k_j \in J_j$  and the set

$$W_j = \bigcup_{k \in J_j} B_k$$

is connected. Set  $J = \bigcup_{j=2}^m J_j \subset \mathbb{N}$  and note that  $I \subset K \subseteq J$ . We have that  $B_{k_1} \subseteq W_j$  for  $j = 2, \ldots, m$ , so the set

$$W = \bigcup_{j=2}^{m} W_j = \bigcup_{k \in J} B_k$$

is connected. By construction we have that  $\bar{V} \subset W$ , so the claim is proved.

Now we define the sequence  $\{V_n\}_{n=1}^{\infty}$  inductively, starting with  $V_1 = B_1$ . Suppose now that  $V_n = \bigcup_{k \in J_n} B_k$  is given for some  $\emptyset \neq J_n \subset \mathbb{N}$ , and that  $V_n$  is connected. We set  $I_{n+1} = \{1, \ldots, \max(J_n)\} \subset \mathbb{N}$  and use the above claim to produce  $J_{n+1} \subset \mathbb{N}$  from  $I_{n+1}$ . Set  $V_{n+1} = \bigcup_{k \in J_{n+1}} B_k$ . The claim guarantees that  $I_{n+1} \subset J_{n+1}$ , that

$$V_n = \bigcup_{k \in J_n} B_k \subseteq \bigcup_{k \in I_{n+1}} B_k \subset \overline{\bigcup_{k \in I_{n+1}} B_k} \subset \bigcup_{k \in J_{n+1}} B_k = V_{n+1}, \tag{3.13}$$

and that  $V_{n+1}$  is connected. This inductively defines the sequence  $\{V_n\}_{n=1}^{\infty}$ , and it is clear that the sequence satisfies all of the stated properties by construction.  $\square$ 

In view of Proposition 3.2, to turn  $\tilde{W}^{s,p}_{(\sigma)}(U)$  into a normed space we consider the following equivalence relation: given  $f,g\in L^1_{\mathrm{loc}}(U)$ , we say that  $f\sim g$  if f-g is equivalent to a constant in each connected component of U. In the next proposition we show that the resulting quotient space  $\tilde{W}^{s,p}_{(\sigma)}(U)/\mathbb{R}$  is a Banach space.

**Theorem 3.7.** Suppose that  $U \subseteq \mathbb{R}^N$  is open,  $1 \leq p < \infty$ , and 0 < s < 1. Let  $\sigma : U \to (0, \infty]$  be a screening function. Then the space  $\tilde{W}^{s,p}_{(\sigma)}(U)/\mathbb{R}$  is a Banach space with the

norm

$$||[f]||_{\tilde{W}^{s,p}_{(\sigma)}(U)/\mathbb{R}} := |f|_{\tilde{W}^{s,p}_{(\sigma)}(U)}.$$

Moreover, if  $1 , then <math>\tilde{W}_{(\sigma)}^{s,p}(U)/\mathbb{R}$  is reflexive.

**Proof.** In view of Proposition 3.2, the homogeneity of  $|\cdot|_{\tilde{W}^{s,p}_{(\sigma)}(U)}$ , and Minkowski's inequality we have that  $\|\cdot\|_{\tilde{W}^{s,p}_{(\sigma)}(U)/\mathbb{R}}$  is a norm. According to the discussion in Section 2.4, in order to prove that  $\tilde{W}^{s,p}_{(\sigma)}(U)/\mathbb{R}$  is a Banach space, it is enough to show that  $\tilde{W}^{s,p}_{(\sigma)}(U)$  is sequentially complete. Suppose then that  $\{f_n\}_{n=1}^{\infty}$  is a Cauchy sequence in  $\tilde{W}^{s,p}_{(\sigma)}(U)$ .

Throughout the rest of the proof, which we divide into several steps, we will employ the notation

$$(f)_E = \frac{1}{\mathcal{L}^N(E)} \int\limits_E f(x) dx$$

whenever  $E \subseteq U$  is a measurable set of positive measure.

Step 1 – Consequences of Poincaré's inequality: Let  $\{U_{\alpha}\}_{{\alpha}\in A}$  denote the connected components of U and note that A is countable. For each  ${\alpha}\in A$  let  $\{V_k^{\alpha}\}_{k=1}^{\infty}$  be the sequence of open subsets of  $U_{\alpha}$  given by Lemma 3.6. The lemma allows us to apply Theorem 3.5 on each set  $V_k^{\alpha}$  with  $E=V_1^{\alpha}\subseteq V_k^{\alpha}$  in order to see that

$$\|(f_n - (f_n)_{V_1^{\alpha}}) - (f_m - (f_m)_{V_1^{\alpha}})\|_{L^p(V_k^{\alpha})} \le c_{k,\alpha}|f_n - f_m|_{\tilde{W}_{(\sigma)}^{s,p}(V_k^{\alpha})} \le c_{k,\alpha}|f_n - f_m|_{\tilde{W}_{(\sigma)}^{s,p}(U)}.$$

Consequently,  $\{f_n - (f_n)_{V_1^{\alpha}}\}_{n=1}^{\infty}$  is Cauchy in  $L^p(V_k^{\alpha})$  and hence convergent to some  $g_k^{\alpha} \in L^p(V_k^{\alpha})$ . We now aim to determine how  $g_j^{\alpha}$  and  $g_k^{\alpha}$  are related when  $j \neq k$ .

Let  $\alpha \in A$  and  $1 \leq j < k < \infty$ . Lemma 3.6 shows that  $V_j^{\alpha} \subset V_k^{\alpha}$  and so both  $g_j^{\alpha}$  and  $g_k^{\alpha}$  are defined on  $V_j^{\alpha}$ . On  $V_j^{\alpha}$  we have that

$$0 = (f_n - (f_n)_{V_1^{\alpha}}) - (f_n - (f_n)_{V_1^{\alpha}}) \to g_j^{\alpha} - g_k^{\alpha} \text{ in } L^p(V_j^{\alpha}) \text{ as } n \to \infty,$$

and hence

$$g_j^{\alpha} = g_k^{\alpha}$$
 almost everywhere in  $V_j^{\alpha}$ . (3.14)

Lemma 3.6 guarantees that  $U_{\alpha} = \bigcup_{k=1}^{\infty} V_k^{\alpha}$ , and so once we have the functions  $\{g_k^{\alpha}\}_{k=1}^{\infty}$  in hand, we may define the function  $f: U \to \mathbb{R}$  via

$$f(x) = g_k^{\alpha}(x)$$
 whenever  $x \in V_k^{\alpha}$  for some  $\alpha \in A$  and  $k \in \mathbb{N}$ . (3.15)

This is well-defined by virtue of (3.14). It's clear that f is measurable, and since any compact subset of U is contained in  $\bigcup_{\alpha \in B} V_k^{\alpha}$  for k large enough and  $B \subseteq A$  some finite set, we actually have that  $f \in L^p_{loc}(U)$ .

# Step 2 - Passing to the limit: We define the set

$$\Gamma = \{(x, h) \in U \times \mathbb{R}^N \mid h \in H(x)\} \subseteq \mathbb{R}^{2N}.$$

The function  $\Phi: U \times \mathbb{R}^N \to \mathbb{R} \times \mathbb{R}^N$  given by  $\Phi(x,h) = (\sigma(x) - |h|, x+h)$  is clearly measurable, and  $\Gamma = \Phi^{-1}((0,\infty) \times U)$ , so  $\Gamma$  is  $\mathcal{L}^{2N}$ -measurable.

Then we define the measure  $\mu: \mathcal{B}(\Gamma) \to [0, \infty]$  via

$$\mu(E) := \int_{U} \int_{H(x)} \chi_E(x, h) \frac{dh}{|h|^{sp+N}} dx$$
 (3.16)

and consider the space  $L^p(\Gamma; \mu)$ . Given  $F \in \tilde{W}^{s,p}_{(\sigma)}(U)$ , we define  $v_F \in L^p(\Gamma; \mu)$  via  $v_F(x,h) = F(x+h) - F(x)$  and note that

$$|F|_{\tilde{W}_{(\sigma)}^{s,p}(U)} = ||v_F||_{L^p(\Gamma;\mu)}.$$
 (3.17)

Consequently, for  $n, m \in \mathbb{N}$  we have the identity

$$|f_n - f_m|_{\tilde{W}_{(\sigma)}^{s,p}(U)} = ||v_{f_n} - v_{f_m}||_{L^p(\Gamma;\mu)},$$

and so  $\{v_{f_n}\}$  is a Cauchy sequence in  $L^p(\Gamma;\mu)$ . Hence,  $v_{f_n} \to v$  in  $L^p(\Gamma;\mu)$  as  $n \to \infty$ .

Step 3 – Identifying the limit: We will now show that  $v = v_f$  for the function  $f: U \to \mathbb{R}$  defined by (3.15). Once this is established we may use the equalities

$$|f - f_n|_{\tilde{W}_{(\sigma)}^{s,p}(U)} = ||v_f - v_{f_n}||_{L^p(\Gamma;\mu)} = ||v - v_{f_n}||_{L^p(\Gamma;\mu)}$$

to conclude that  $f_n \to f$  in  $\tilde{W}^{s,p}_{(\sigma)}(U)$  as  $n \to \infty$ , thereby proving the sequential completeness of  $\tilde{W}^{s,p}_{(\sigma)}(U)$ .

We know from Step 1 that for each  $k \in \mathbb{N}$  and  $\alpha \in A$  we have that  $f_n - (f_n)_{V_1^{\alpha}} \to g_k^{\alpha}$  in  $L^p(V_k^{\alpha})$  as  $n \to \infty$ . As such, we may iteratively extract subsequences and then choose a diagonal subsequence to produce a single subsequence  $\{f_{n_m}\}_{m=1}^{\infty}$  and a Lebesgue measurable set  $D \subset U$  with  $\mathcal{L}^N(D) = 0$  such that for all  $k \in \mathbb{N}$  and  $\alpha \in A$  we have that

$$f_{n_m} - (f_{n_m})_{V_i^{\alpha}} \to g_k^{\alpha}$$
 pointwise on  $V_k^{\alpha} \backslash D$  as  $m \to \infty$ . (3.18)

Next we use Fubini's theorem to find a Lebesgue measurable set  $E \subset U$  with  $\mathcal{L}^N(E) = 0$  and a further subsequence, which up to relabeling we can still refer to as  $\{f_{n_m}\}_{m=1}^{\infty}$ , such that if  $x \in U \setminus E$ , then

$$\lim_{m \to \infty} \int_{H(x)} \frac{|f_{n_m}(x+h) - f_{n_k}(x) - v(x,h)|^p}{|h|^{sp+N}} dh = 0.$$
 (3.19)

Fix  $x \in U \setminus (D \cup E)$ . According to (3.19), we can pick a measurable set  $G_x \subset H(x)$  with  $\mathcal{L}^N(G_x) = 0$  and a further subsequence  $\{f_{n_{m_\ell}}\}_{\ell=1}^{\infty}$  (both the set and the subsequence depend on the point x) such that if  $h \in H(x) \setminus G_x$ , then

$$f_{n_{m_{\ell}}}(x+h) - f_{n_{m_{\ell}}}(x) - v(x,h) \to 0 \text{ as } \ell \to \infty.$$
 (3.20)

Now let  $D_x = -x + D$  and note that for  $h \in H(x) \backslash D_x$  we have that  $x + h \in [B(x, \sigma(x)) \cap U] \backslash D \subseteq U \backslash D$ . By the translation invariance of Lebesgue measure we have that  $\mathcal{L}^N(D_x) = \mathcal{L}^N(D) = 0$ . In particular, this means that  $\mathcal{L}^N(D_x \cup G_x) = 0$  as well.

Fix  $h \in H(x) \setminus (D_x \cup G_x)$  and pick  $j, k \in \mathbb{N}$  and  $\alpha \in A$  such that  $x \in V_k^{\alpha}$  and  $x+h \in V_j^{\alpha}$ . We may then write

$$f_{n_{m_{\ell}}}(x+h) - f_{n_{m_{\ell}}}(x) = [f_{n_{m_{\ell}}}(x+h) - (f_{n_{m_{\ell}}})_{V_{1}^{\alpha}}] - [f_{n_{m_{\ell}}}(x) - (f_{n_{m_{\ell}}})_{V_{1}^{\alpha}}].$$

According to (3.18) and (3.20) we may then send  $\ell \to \infty$  and use the definition of f from (3.15) in order to deduce that

$$v(x,h) = g_i^{\alpha}(x+h) - g_k^{\alpha}(x) = f(x+h) - f(x).$$

Thus  $v = v_f$  for  $\mathcal{L}^{2N}$  a.e.  $(x, h) \in \Gamma$ , which completes the proof of sequential completeness.

Step 4 – Reflexivity: Now assume that  $1 . Since the space <math>L^p(\Gamma; \mu)$  is reflexive, and the mapping  $\tilde{W}^{s,p}_{(\sigma)}(U)/\mathbb{R} \ni [f] \mapsto v_f \in L^p(\Gamma; \mu)$  is an isometric isomorphism by (2.14) and (3.17), we can identify  $\tilde{W}^{s,p}_{(\sigma)}(U)/\mathbb{R}$  with a closed subspace of  $L^p(\Gamma; \mu)$ . It then suffices to observe that closed subspaces of reflexive spaces are reflexive.  $\square$ 

Now we show that the screened spaces possess the same interpolation properties as the usual Sobolev spaces.

**Proposition 3.8.** Suppose that  $U \subseteq \mathbb{R}^N$  is open,  $1 \leq p < \infty$ ,  $0 < s_1 < s_2 < 1$ , and  $\sigma: U \to (0, \infty]$  is a screening function. If  $f \in \tilde{W}^{s_1,p}_{(\sigma)}(U) \cap \tilde{W}^{s_2,p}_{(\sigma)}(U)$  and  $s = \theta s_1 + (1-\theta)s_2$  for some  $\theta \in (0,1)$ , then  $f \in \tilde{W}^{s,p}_{(\sigma)}(U)$  and

$$|f|_{\tilde{W}^{s,p}_{(\sigma)}(U)} \le \left(|f|_{\tilde{W}^{s_1,p}_{(\sigma)}(U)}\right)^{\theta} \left(|f|_{\tilde{W}^{s_1,p}_{(\sigma)}(U)}\right)^{1-\theta}. \tag{3.21}$$

**Proof.** For each  $x \in U$  we use Hölder's inequality to bound

$$\int_{H(x)} \frac{|f(x+h) - f(x)|^p}{|h|^{sp+N}} dh = \int_{H(x)} \left( \frac{|f(x+h) - f(x)|^p}{|h|^{N+s_1p}} \right)^{\theta} \left( \frac{|f(x+h) - f(x)|^p}{|h|^{N+s_2p}} \right)^{1-\theta} dh$$

$$\leq \left( \int_{H(x)} \frac{|f(x+h) - f(x)|^p}{|h|^{N+s_1p} dh} \right)^{\theta} \left( \int_{H(x)} \frac{|f(x+h) - f(x)|^p}{|h|^{N+s_2p}} dh \right)^{1-\theta} .$$

Then (3.21) follows by integrating over  $x \in U$  and applying Hölder's inequality again.  $\square$ 

Next, we show that spaces defined by different screening functions nest when the screening functions are ordered.

**Proposition 3.9.** Suppose that  $U \subseteq \mathbb{R}^N$  is open,  $1 \leq p < \infty$ , and 0 < s < 1. Suppose that  $\sigma_1, \sigma_2 : U \to (0, \infty]$  are two screening functions such that  $\sigma_1 \leq \sigma_2$  on U. Then for each  $f \in L^1_{loc}(U)$  we have that

$$|f|_{\tilde{W}_{(\sigma_1)}^{s,p}(U)} \le |f|_{\tilde{W}_{(\sigma_2)}^{s,p}(U)}.$$
 (3.22)

In particular, we have the subspace inclusion  $\tilde{W}^{s,p}_{(\sigma_2)}(U) \subseteq \tilde{W}^{s,p}_{(\sigma_1)}(U)$ .

**Proof.** If  $\sigma_1 \leq \sigma_2$  on U, then we have the obvious inequality

$$\int_{U} \int_{H_{\sigma_1}(x)} \frac{|f(x+h) - f(x)|^p}{|h|^{sp+N}} dh dx \le \int_{U} \int_{H_{\sigma_2}(x)} \frac{|f(x+h) - f(x)|^p}{|h|^{sp+N}} dh dx$$

for all  $f \in L^1_{loc}(U)$ , where  $H_{\sigma_i(x)} = (-x+U) \cap B(0, \sigma_i(x))$ . The result follows immediately from this.  $\square$ 

Inclusion in  $L^p(U)$  is not a requirement for inclusion in  $\tilde{W}_{(\sigma)}^{s,p}(U)$ . Our next result examines what happens when we require both inclusions in the case when the screening function is bounded below.

**Proposition 3.10.** Suppose that  $U \subseteq \mathbb{R}^N$  is open,  $1 \leq p < \infty$ , and 0 < s < 1. Suppose that  $\sigma: U \to (0, \infty]$  is a screening function such that  $0 < \sigma_- = \inf_U \sigma$ . Then there exists a constant  $c = c(N, s, p, \sigma_-) > 0$  such that for each  $f \in L^1_{loc}(U)$  we have that

$$||f||_{L^{p}(U)} + |f|_{\tilde{W}_{(\sigma)}^{s,p}(U)} \le ||f||_{L^{p}(U)} + |f|_{\dot{W}^{s,p}(U)} \le c \left( ||f||_{L^{p}(U)} + |f|_{\tilde{W}_{(\sigma)}^{s,p}(U)} \right). \tag{3.23}$$

In particular, we have the algebraic and topological equalities

$$W^{s,p}(U) = \dot{W}^{s,p}(U) \cap L^p(U) = \tilde{W}^{s,p}_{(\sigma)}(U) \cap L^p(U).$$

**Proof.** The first bound in (3.23) follows immediately from Proposition 3.9, so it suffices to only prove the second. To this end we first write

$$|f|_{\dot{W}^{s,p}(U)}^{p} = \int_{U} \int_{B(x,\sigma(x))\cap U} \frac{|f(y) - f(x)|^{p}}{|y - x|^{sp+N}} dy dx + \int_{U} \int_{U\setminus B(x,\sigma(x))} \frac{|f(y) - f(x)|^{p}}{|y - x|^{sp+N}} dy dx$$

$$= |f|_{\tilde{W}^{s,p}_{(\sigma)}(U)}^{p} + \int_{U} \int_{U\setminus B(x,\sigma(x))} \frac{|f(y) - f(x)|^{p}}{|y - x|^{sp+N}} dy dx.$$

Next we estimate

$$\int_{U} \int_{U \setminus B(x,\sigma(x))} \frac{|f(y) - f(x)|^{p}}{|y - x|^{sp+N}} dy dx 
\leq 2^{p-1} \int_{U} \int_{U \setminus B(x,\sigma(x))} \frac{|f(y)|^{p}}{|y - x|^{sp+N}} dy dx + 2^{p-1} \int_{U} \int_{U \setminus B(x,\sigma(x))} \frac{|f(x)|^{p}}{|y - x|^{sp+N}} dy dx 
=: 2^{p-1} (I + II).$$

We handle the first term with Tonelli's theorem, a change of variables, and spherical coordinates:

$$\begin{split} I &= \int\limits_{U} \int\limits_{U} \chi_{\{|y-x| \geq \sigma(x)\}}(x) \frac{|f(y)|^{p}}{|y-x|^{sp+N}} dx dy \leq \int\limits_{U} \int\limits_{U} \chi_{\{|y-x| \geq \sigma_{-}\}}(x) \frac{|f(y)|^{p}}{|y-x|^{sp+N}} dx dy \\ &\leq \int\limits_{U} \int\limits_{B(0,\sigma_{-})^{c}} \frac{|f(y)|^{p}}{|h|^{sp+N}} dh dy = \|f\|_{L^{p}(U)}^{p} \beta_{N} \int\limits_{\sigma_{-}}^{\infty} \frac{dr}{r^{1+sp}} = \frac{\beta_{N}}{sp\sigma_{-}^{sp}} \|f\|_{L^{p}(U)}^{p}. \end{split}$$

We may similarly bound the second term:

$$II \le \int_{U} \int_{B(0,\sigma_{-})^{c}} \frac{|f(x)|^{p}}{|h|^{sp+N}} dh dx = \frac{\beta_{N}}{sp\sigma_{-}^{sp}} ||f||_{L^{p}(U)}^{p}.$$

The second bound in (3.23) then follows directly from these estimates.  $\Box$ 

Our next result establishes that the screened homogeneous spaces are strictly bigger than the standard homogeneous spaces when the screening function is unity and the set U contains a ray in a set of directions of positive  $\mathcal{H}^{N-1}$  measure.

**Theorem 3.11.** Let  $1 \leq p < \infty$ . Let  $\Gamma \subseteq \mathbb{S}^{N-1}$  be such that  $\mathcal{H}^{N-1}(\Gamma) > 0$ ,  $\rho \geq 0$ , and define the infinite cone-like set

$$K_{\Gamma,\rho} = \{ x \in \mathbb{R}^N \mid \rho < |x| \text{ and } x/|x| \in \Gamma \}.$$

Suppose that  $U \subseteq \mathbb{R}^N$  is open and that  $K_{\Gamma,\rho} \subseteq U$ . Then there exists a function

$$u \in \bigcap_{0 \le s \le 1} \tilde{W}_{(1)}^{s,p}(U) \setminus \bigcup_{0 \le s \le 1} \dot{W}^{s,p}(U).$$

In particular, if 0 < s < 1, then

$$\dot{W}^{s,p}(U) \subsetneq \tilde{W}^{s,p}_{(1)}(U).$$

**Proof.** Define  $f \in C^{\infty}([0,\infty))$  via

$$f(r) = \int_{0}^{r} \frac{dt}{(2+t)^{N/p} (\log(2+t))^{2/p}},$$

and note that f is Lipschitz and satisfies

$$|f|_{0,1} = \frac{1}{2^{N/p}(\log 2)^{2/p}}.$$

We then let  $u \in C^{0,1}(\mathbb{R}^N)$  be given by u(x) = f(|x|). Let 0 < s < 1. We will prove that the restriction of u to U (which we continue to denote by u) is such that  $u \in \tilde{W}^{s,p}_{(1)}(U) \setminus \dot{W}^{s,p}(U)$ , from which the conclusions readily follow.

We begin by proving that  $u \in \tilde{W}^{s,p}_{(1)}(U)$ . Since u is actually defined on all of  $\mathbb{R}^N$  we may begin by estimating

$$\begin{split} |u|_{\tilde{W}_{(1)}^{s,p}(U)}^{p} &= \int\limits_{B(0,1)\cap U} \int\limits_{B(0,1)\cap (U-x)} \frac{|u(x+h)-u(x)|^{p}}{|h|^{sp+N}} dh dx \\ &+ \int\limits_{B(0,1)^{c}\cap U} \int\limits_{B(0,1)\cap (U-x)} \frac{|u(x+h)-u(x)|^{p}}{|h|^{sp+N}} dh dx \\ &\leq \int\limits_{B(0,1)\cap U} \int\limits_{B(0,1)} \frac{|f(|x+h|)-f(|x|)|^{p}}{|h|^{sp+N}} dh dx \\ &+ \int\limits_{B(0,1)^{c}\cap U} \int\limits_{B(0,1)} \frac{|f(|x+h|)-f(|x|)|^{p}}{|h|^{sp+N}} dh dx =: I + II. \end{split}$$

To estimate the term I we use the fact that f is Lipschitz together with Tonelli's theorem and a change to spherical coordinates:

$$I \leq \int\limits_{B(0,1)} \int\limits_{B(0,1)} \frac{|f|_{0,1}^{p}|h|^{p}}{|h|^{sp+N}} dh dx = \alpha_{N} \beta_{N} |f|_{0,1}^{p} \int\limits_{0}^{1} \frac{r^{N-1}}{r^{N-(1-s)p}} dr < \infty.$$

To handle the term II we observe that f' is positive and decreasing on  $[0, \infty)$ , so for  $a, b \in [0, \infty)$  we have that

$$|f(a) - f(b)| \le f'(\min\{a, b\})|a - b|.$$

On the other hand, for  $|x| \ge 1$  and |h| < 1 we have that

$$|x| - 1 = \min\{|x|, |x| - 1\} \le \min\{|x|, |x + h|\},\$$

SO

$$f'(\min\{|x|,|x+h|\}) \le f'(|x|-1) = \frac{1}{(1+|x|)^{N/p}(\log(1+|x|))^{2/p}}.$$

Combining these and using Tonelli's theorem and spherical coordinates then shows that

$$II \le \left( \int_{B(0,1)^c} \frac{dx}{(1+|x|)^N (\log(1+|x|))^2} \right) \left( \int_{B(0,1)} \frac{|h|^p}{|h|^{sp+N}} dh \right)$$

$$= \beta_N^2 \left( \int_1^\infty \frac{r^{N-1}}{(1+r)^N (\log(1+r))^2} dr \right) \left( \int_0^1 \frac{r^{N-1}}{r^{N-(1-s)p}} dr \right)$$

$$\le \beta_N^2 \left( \int_2^\infty \frac{1}{r (\log(r))^2} dr \right) \left( \int_0^1 \frac{1}{r^{1-(1-s)p}} dr \right) < \infty.$$

Assembling the above estimates, we see that

$$|u|_{\tilde{W}_{(1)}^{s,p}(U)}^{p} = I + II < \infty,$$

and thus  $u \in \tilde{W}_{(1)}^{s,p}(U)$ .

We now turn to the proof that  $u \notin \dot{W}^{s,p}(U)$ . Let  $0 < \varepsilon < 1-s$  be such that  $N/p+\varepsilon \neq 1$  and choose  $R_{\varepsilon} > \max\{2, \rho\}$  such that if  $t \geq R_{\varepsilon}$  then  $(\log(2+t))^{2/p} \leq (2+t)^{\varepsilon}$ . Then for  $|x| \geq R_{\varepsilon}$  and  $|h| \geq 3|x|$  we may estimate

$$|f(|x+h|) - f(|x|)|^p = \left(\int\limits_{|x|}^{|x+h|} \frac{dt}{(2+t)^{N/p}(\log(2+t))^{2/p}}\right)^p$$

$$\geq \left(\int\limits_{|x|}^{2|x|} \frac{dt}{(2+t)^{N/p+\varepsilon}}\right)^p \geq \left(\int\limits_{|x|}^{2|x|} \frac{dt}{(2t)^{N/p+\varepsilon}}\right)^p$$

$$= \frac{1}{2^{N+p\varepsilon}} |x|^{p-N-p\varepsilon} \left(\frac{2^{1-N/p-\varepsilon} - 1}{1 - N/p - \varepsilon}\right)^p =: c(N, p, \varepsilon)|x|^{p-N-p\varepsilon},$$

where  $c(N, p, \varepsilon) > 0$ . Hence

$$|u|_{W^{s,p}(U)}^{p} \ge \int_{B(0,R_{\varepsilon})^{c}\cap K_{\Gamma,\rho}} \int_{B(0,3|x|)^{c}\cap K_{\Gamma,\rho}} \frac{|f(|x+h|) - f(|x|)|^{p}}{|h|^{sp+N}} dh dx$$

$$\ge c(N,p,\varepsilon) \int_{B(0,R_{\varepsilon})^{c}\cap K_{\Gamma,\rho}} \int_{B(0,3|x|)^{c}\cap K_{\Gamma,\rho}} \frac{|x|^{p-N-p\varepsilon}}{|h|^{sp+N}} dh dx$$

$$= c(N,p,\varepsilon) (\mathcal{H}^{N-1}(\Gamma))^{2} \int_{R_{\varepsilon}}^{\infty} r^{N-1} r^{p-N-p\varepsilon} \int_{3r}^{\infty} \frac{t^{N-1}}{t^{sp+N}} dt dr$$

$$= \frac{c(N,p,\varepsilon)}{sp3^{sp}} (\mathcal{H}^{N-1}(\Gamma))^{2} \int_{R_{\varepsilon}}^{\infty} r^{p(1-s-\varepsilon)-1} dr = \infty$$

since  $p(1-s-\varepsilon)>0$ , and we conclude that  $u\notin \dot{W}^{s,p}(U)$ .  $\square$ 

**Remark 3.12.** The function u constructed in Theorem 3.11 clearly satisfies  $\lim_{|x|\to\infty} u(x) = \infty$  when p < N and when  $2 \le N = p$ . In these cases we deduce that for  $U \subseteq \mathbb{R}^N$  as in the theorem,

$$u \in \tilde{W}_{(1)}^{s,p}(U) \setminus \bigcup_{1 < q < \infty} L^q(U).$$

In particular, this means that the classical Sobolev embeddings do not hold for the screened spaces. However, it is possible that embeddings into other types of spaces may hold (for instance, weighted  $L^p$  spaces). We have not attempted an investigation of this interesting question in the present paper for the sake of brevity.

# 3.3. Screened homogeneous fractional Sobolev spaces: further properties in $\mathbb{R}^N$

In this subsection we restrict our attention to the special case  $U = \mathbb{R}^N$  and prove a number of interesting results about the screened spaces. One particular advantage of this case is that we have  $H(x) = B(0, \sigma(x))$  for all  $x \in \mathbb{R}^N$  whenever  $\sigma : \mathbb{R}^N \to (0, \infty]$  is a screening function.

Our first result shows that any two screening functions that are bounded above and below give rise to the same screened spaces. This should be compared to Proposition 3.9.

**Theorem 3.13.** Suppose that  $\sigma_1, \sigma_2 : \mathbb{R}^N \to (0, \infty]$  are two screening functions such that

$$0 < \inf_{\mathbb{R}^N} \sigma_i \le \sup_{\mathbb{R}^N} \sigma_i < \infty \text{ for } i = 1, 2.$$
 (3.24)

Then for 0 < s < 1 and  $1 \le p < \infty$  there exists a pair of constants  $c_0(s, p, N, \sup \sigma_1 / \inf \sigma_2) > 0$  and  $c_1(s, p, N, \sup \sigma_2 / \inf \sigma_1) > 0$  such that

$$c_0|f|_{\tilde{W}_{(\sigma_2)}^{s,p}(\mathbb{R}^N)} \le |f|_{\tilde{W}_{(\sigma_1)}^{s,p}(\mathbb{R}^N)} \le c_1|f|_{\tilde{W}_{(\sigma_2)}^{s,p}(\mathbb{R}^N)}$$
(3.25)

for all  $f \in L^1_{loc}(\mathbb{R}^N)$ , and consequently we have the algebraic and topological equality

$$\tilde{W}^{s,p}_{(\sigma_1)}(\mathbb{R}^N) = \tilde{W}^{s,p}_{(\sigma_2)}(\mathbb{R}^N).$$

**Proof.** We divide the proof into steps.

Step 1 – Doubled constants: We now prove the result when  $\sigma_1 = r$  and  $\sigma_2 = 2r$  for some constant  $r \in (0, \infty)$ . Let  $f \in L^1_{loc}(\mathbb{R}^N)$ . Then we may estimate

$$\int_{\mathbb{R}^{N}} \int_{B(0,2r)\backslash B(0,r)} \frac{|f(x+h)-f(x)|^{p}}{|h|^{sp+N}} dh dx$$

$$= \frac{1}{2^{sp}} \int_{\mathbb{R}^{N}} \int_{B(0,r)\backslash B(0,r/2)} \frac{|f(x+2h)-f(x)|^{p}}{|h|^{sp+N}} dh dx$$

$$\leq \frac{2^{p-1}}{2^{sp}} \int_{\mathbb{R}^{N}} \int_{B(0,r)\backslash B(0,r/2)} \frac{|f(x+2h)-f(x+h)|^{p}}{|h|^{sp+N}} dh dx$$

$$+ \frac{2^{p-1}}{2^{sp}} \int_{\mathbb{R}^{N}} \int_{B(0,r)\backslash B(0,r/2)} \frac{|f(x+h)-f(x)|^{p}}{|h|^{sp+N}} dh dx$$

$$\leq 2^{p(1-s)} \int_{\mathbb{R}^{N}} \int_{B(0,r)} \frac{|f(x+h)-f(x)|^{p}}{|h|^{sp+N}} dh dx,$$

where in the first equality we have made the change of variables  $h \mapsto 2h$  and in the last inequality we have changed  $x \mapsto x + h$  in the first integral. Thus we may decompose  $B(0,2r) = B(0,r) \cup [B(0,2r) \setminus B(0,r)]$  in order to see that

$$|f|_{\tilde{W}^{s,p}_{(2r)}(\mathbb{R}^N)}^p \leq (1+2^{p(1-s)}) \int\limits_{\mathbb{R}^N} \int\limits_{B(0,r)} \frac{|f(x+h)-f(x)|^p}{|h|^{sp+N}} dh dx = (1+2^{p(1-s)})|f|_{\tilde{W}^{s,p}_{(r)}(\mathbb{R}^N)}^p.$$

This and (3.22) then prove (3.25) in this special case.

Step 2 – Pairs of constants: We now prove the result when  $\sigma_1 = r_1$  and  $\sigma_2 = r_2$  for some constants  $0 < r_1 < r_2 < \infty$ . Choose  $k \in \mathbb{N}$  such that  $r_2 < 2^k r_1$ . The analysis from Step 1 provides us with a constant c = c(s, p) > 0 such that  $|f|_{\tilde{W}_{(2r)}^{s,p}(\mathbb{R}^N)} \leq c|f|_{\tilde{W}_{(r)}^{s,p}(\mathbb{R}^N)}$  whenever  $f \in L^1_{loc}(\mathbb{R}^n)$  and r > 0. Applying this iteratively then shows that

$$|f|_{\tilde{W}^{s,p}_{(2^k r)}(\mathbb{R}^N)} \le c^k |f|_{\tilde{W}^{s,p}_{(r)}(\mathbb{R}^N)}.$$

From this and (3.22) we then deduce that

$$|f|_{\tilde{W}_{(r_1)}^{s,p}(\mathbb{R}^N)} \le |f|_{\tilde{W}_{(r_2)}^{s,p}(\mathbb{R}^N)} \le |f|_{\tilde{W}_{(2^k r_1)}^{s,p}(\mathbb{R}^N)} \le c^k |f|_{\tilde{W}_{(r_1)}^{s,p}(\mathbb{R}^N)},$$

which is (3.25) in this special case.

Step 3 – The general case: Now consider general  $\sigma_1, \sigma_2$  satisfying (3.24). Write

$$0<\sigma_{i,-}:=\inf_{\mathbb{R}^N}\sigma_i\leq \sup_{\mathbb{D}^N}\sigma_i=:\sigma_{i,+}<\infty \text{ for } i=1,2.$$

Then from Step 2 we can find constants  $c_2, c_3 > 0$  such that

$$|f|_{\tilde{W}^{s,p}_{(\sigma_{1,+})}(\mathbb{R}^N)} \le c_2 |f|_{\tilde{W}^{s,p}_{(\sigma_{2,-})}(\mathbb{R}^N)} \text{ and } |f|_{\tilde{W}^{s,p}_{(\sigma_{2,+})}(\mathbb{R}^N)} \le c_3 |f|_{\tilde{W}^{s,p}_{(\sigma_{1,-})}(\mathbb{R}^N)}$$

for all  $f \in L^1_{loc}(\mathbb{R}^N)$ . Using this and (3.22) then shows that

$$|f|_{\tilde{W}_{(\sigma_{1})}^{s,p}(\mathbb{R}^{N})} \leq |f|_{\tilde{W}_{(\sigma_{1},+)}^{s,p}(\mathbb{R}^{N})} \leq c_{2}|f|_{\tilde{W}_{(\sigma_{2},-)}^{s,p}(\mathbb{R}^{N})} \leq c_{2}|f|_{\tilde{W}_{(\sigma_{2},+)}^{s,p}(\mathbb{R}^{N})} \leq c_{2}|f|_{\tilde{W}_{(\sigma_{2},+)}^{s,p}(\mathbb{R}^{N})} \leq c_{2}|f|_{\tilde{W}_{(\sigma_{1},-)}^{s,p}(\mathbb{R}^{N})} \leq c_{2}|f|_{\tilde{W}_{(\sigma_{1},-)}^{s,p}(\mathbb{R}^{N})},$$

which proves (3.25).

We can combine Theorems 3.11 and 3.13 to deduce the following interesting corollary.

**Corollary 3.14.** Let  $1 \leq p < \infty$ , 0 < s < 1, and suppose that  $\sigma : \mathbb{R}^N \to (0, \infty)$  is a screening function that is bounded above. Then

$$\dot{W}^{s,p}(\mathbb{R}^N) \subsetneq \tilde{W}^{s,p}_{(\sigma)}(\mathbb{R}^N).$$

**Proof.** Write  $\sigma_+ = \sup_{\mathbb{R}^N} \sigma \in (0, \infty)$ . Then Theorems 3.11 and 3.13 may be combined with Proposition 3.9 to see that

$$\dot{W}^{s,p}(\mathbb{R}^N) \subsetneqq \tilde{W}^{s,p}_{(1)}(\mathbb{R}^N) = \tilde{W}^{s,p}_{(\sigma_+)}(\mathbb{R}^N) \subseteq \tilde{W}^{s,p}_{(\sigma)}(\mathbb{R}^N). \quad \Box$$

We now turn our attention to the issue of the density of smooth functions in the screened spaces.

**Theorem 3.15.** Let  $1 \leq p < \infty$  and 0 < s < 1. Suppose that  $\sigma : \mathbb{R}^N \to (0, \infty)$  is a screening function such that  $0 < \inf_{\mathbb{R}^N} \sigma \leq \sup_{\mathbb{R}^N} \sigma < \infty$ . Then  $C^{\infty}(\mathbb{R}^N) \cap \tilde{W}^{s,p}_{(\sigma)}(\mathbb{R}^N)$  is dense in  $\tilde{W}^{s,p}_{(\sigma)}(\mathbb{R}^N)$  and  $C^{\infty}(\mathbb{R}^N) \cap \tilde{W}^{s,p}_{(\sigma)}(\mathbb{R}^N)/\mathbb{R}$  is dense in  $\tilde{W}^{s,p}_{(\sigma)}(\mathbb{R}^N)/\mathbb{R}$ .

**Proof.** In light of Theorem 3.13, it suffices to prove the result under the assumption that  $\sigma = 1$ . For  $h \in B(0,1)$  write  $\Delta_h g = g(\cdot + h) - g$  whenever  $g \in L^1_{loc}(\mathbb{R}^N)$ . Since  $\sigma = 1$  we may use Tonelli's theorem to write

$$|g|_{\tilde{W}_{(1)}^{s,p}(\mathbb{R}^{N})} = \left(\int\limits_{B(0,1)} \frac{1}{|h|^{sp+N}} \|\Delta_{h}g\|_{L^{p}(\mathbb{R}^{N})}^{p} dh\right)^{1/p}.$$

Let  $\varphi \in C_c^{\infty}(\mathbb{R}^N)$  be such that  $0 \leq \varphi$  and  $\int_{\mathbb{R}^N} \varphi \, dx = 1$ . For  $\varepsilon > 0$  write  $\varphi_{\varepsilon}(x) = \varepsilon^{-N} \varphi(x/\varepsilon)$ . Fix  $f \in \tilde{W}_{(\sigma)}^{s,p}(\mathbb{R}^N)$ . For  $\varepsilon > 0$  let  $f_{\varepsilon} = f * \varphi_{\varepsilon} \in C^{\infty}(\mathbb{R}^N)$  be the usual mollification of f. Clearly  $(\Delta_h f) * \varphi_{\varepsilon} = \Delta_h (f * \varphi_{\varepsilon}) = \Delta_h f_{\varepsilon}$ . Thus the usual properties of mollifiers show that

$$\|\Delta_h f_{\varepsilon}\|_{L^p(\mathbb{R}^N)} \le \|\Delta_h f\|_{L^p(\mathbb{R}^N)} \text{ and } \lim_{\varepsilon \to 0} \|\Delta_h f_{\varepsilon} - \Delta_h f\|_{L^p(\mathbb{R}^N)} = 0.$$
 (3.26)

For  $0 < \varepsilon$  set  $q_{\varepsilon}, q : B(0,1) \setminus \{0\} \to [0,\infty)$  via

$$q_{\varepsilon}(h) = \frac{1}{|h|^{sp+N}} \|\Delta_h f_{\varepsilon} - \Delta_h f\|_{L^p(\mathbb{R}^N)}^p \text{ and } q(h) = \frac{1}{|h|^{sp+N}} \|\Delta_h f\|_{L^p(\mathbb{R}^N)}^p.$$

Then (3.26) shows that if  $h \in B(0,1) \setminus \{0\}$  then  $q_{\varepsilon}(h) \leq 2^p q(h)$  and  $q_{\varepsilon}(h) \to 0$  as  $\varepsilon \to 0$ . Since

$$\int_{B(0,1)} q(h)dh = |f|_{\tilde{W}_{(1)}^{s,p}(\mathbb{R}^N)}^p < \infty$$

we can then apply the dominated convergence theorem to see that

$$0 = \lim_{\varepsilon \to 0} \int_{B(0,1)} q_{\varepsilon}(h) dx = \lim_{\varepsilon \to 0} |f_{\varepsilon} - f|_{\tilde{W}_{(1)}^{s,p}(\mathbb{R}^{N})}^{p}.$$

The stated density results then follow directly from this.  $\Box$ 

When the screening function is constant and p=2 we can use Fourier analysis techniques to arrive at another characterization of the seminorm on  $\tilde{W}_{(\sigma)}^{s,2}(\mathbb{R}^N)$ . The proof is essentially the same of the one given by Strichartz (see Theorem 2.2 in [34]) in the case N=2 and s=1/2. We present it here for the convenience of the reader.

**Proposition 3.16.** Let 0 < s < 1 and  $\sigma : \mathbb{R}^N \to (0, \infty)$  be a screening function such that  $0 < \inf_{\mathbb{R}^N} \sigma \le \sup_{\mathbb{R}^N} \sigma < \infty$ . Then there exists a constant  $c = c(N, s, \sigma) > 0$  such that if  $f : \mathbb{R}^N \to \mathbb{R}$  is in the Schwartz class, then

$$c^{-1} \int_{\mathbb{R}^N} \min\{|\xi|^{2s}, |\xi|^2\} |\hat{f}(\xi)|^2 d\xi \le |f|^2_{\tilde{W}^{s,2}_{(\sigma)}(\mathbb{R}^N)} \le c \int_{\mathbb{R}^N} \min\{|\xi|^{2s}, |\xi|^2\} |\hat{f}(\xi)|^2 d\xi,$$

where  $\hat{f}$  is the Fourier transform of f.

**Proof.** In light of Theorem 3.13, it suffices to prove the result under the assumption that  $\sigma = 1$ . By Tonelli's theorem, Plancherel's theorem, and standard properties of the Fourier transform, we may compute

$$|f|_{\hat{W}_{(\sigma)}^{s,2}(\mathbb{R}^{N})}^{2} = \int_{B(0,1)} \frac{1}{|h|^{N+2s}} \int_{\mathbb{R}^{N}} |f(x+h) - f(x)|^{2} dx dh$$

$$= \int_{B(0,1)} \frac{1}{|h|^{N+2s}} \int_{\mathbb{R}^{N}} |\hat{f}(\xi)|^{2} |e^{2\pi i h \cdot \xi} - 1|^{2} d\xi dh$$

$$= \int_{\mathbb{R}^{N}} |\hat{f}(\xi)|^{2} \int_{B(0,1)} \frac{|e^{2\pi i h \cdot \xi} - 1|^{2}}{|h|^{N+2s}} dh d\xi.$$

Define  $m:\mathbb{R}^N \to [0,\infty)$  via

$$m(\xi) = \int_{B(0,1)} \frac{|e^{2\pi i h \cdot \xi} - 1|^2}{|h|^{N+2s}} dh.$$

Note that if  $\lambda > 0$  and  $|\xi| = 1$ , then by the change of variables  $\zeta = \lambda h$  we get  $d\zeta = \lambda^N dh$  and

$$m(\lambda\xi) = \lambda^{2s} \int\limits_{B(0,\lambda)} \frac{|e^{2\pi i \zeta \cdot \xi} - 1|^2}{|\zeta|^{N+2s}} d\zeta = \lambda^{2s} \int\limits_{B(0,\lambda)} \frac{|e^{2\pi i \zeta_1} - 1|^2}{|\zeta|^{N+2s}} d\zeta,$$

where the second equality follows by invariance under rotation. It follows that for all  $\lambda \geq 1/2$ ,

$$c_1 := \int\limits_{B(0,1/2)} \frac{|e^{2\pi i \zeta_1} - 1|^2}{|\zeta|^{N+2s}} d\zeta \le \frac{m(\lambda \xi)}{\lambda^{2s}} \le \int\limits_{\mathbb{R}^N} \frac{|e^{2\pi i \zeta_1} - 1|^2}{|\zeta|^{N+2s}} d\zeta =: c_2 < \infty,$$

which shows that

$$c_1|\xi|^{2s} \le m(\xi) \le c_2|\xi|^{2s} \tag{3.27}$$

for all  $\xi \in \mathbb{R}^N$  with  $|\xi| \ge 1/2$ .

On the other hand, standard properties of the complex exponential show that

$$\pi |t| \le |e^{2\pi it} - 1| \le 2\pi |t|$$

for all  $|t| \leq 1/2$ , and so

$$c_3 \le \frac{m(\xi)}{|\xi|^2} \le 4c_3 \tag{3.28}$$

for all  $\xi \in \mathbb{R}^N \setminus \{0\}$  with  $|\xi| \leq 1/2$ , where, again by invariance under rotation,

$$c_3 := \frac{\pi^2}{|\xi|^2} \int_{B(0,1)} \frac{(h \cdot \xi)^2}{|h|^{N+2s}} dh = \pi^2 \int_{B(0,1)} \frac{h_1^2}{|h|^{N+2s}} dh < \infty.$$

Since  $m(\xi) > 0$  for all  $\xi \in \mathbb{R}^N \setminus \{0\}$  and m is continuous, it follows from (3.27) and (3.28) that there is a constant c = c(N, s) > 0 such that

$$c^{-1}\min\{|\xi|^{2s}, |\xi|^2\} \le m(\xi) \le c\min\{|\xi|^{2s}, |\xi|^2\}$$

for all  $\xi \in \mathbb{R}^N$ . The stated estimate follows directly from this.  $\square$ 

**Remark 3.17.** For 0 < s < 1 the Fourier version of the seminorm on  $\dot{W}^{s,2}(\mathbb{R}^N)$  is

$$\int\limits_{\mathbb{R}^N} |\xi|^{2s} |\hat{f}(\xi)|^2 d\xi \asymp |f|^2_{\dot{W}^{s,2}(\mathbb{R}^N)}.$$

Comparing this with Proposition 3.16 shows that in the screened spaces control is lost for low frequencies.

# 3.4. Trace spaces

We have seen in Theorems 1.2 and 1.4 that when  $\Omega$  has the form (1.3) the trace space of  $\dot{W}^{1,p}(\Omega)$  is given by pairs of functions in  $\tilde{W}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})$  whose difference is in  $L^p(\mathbb{R}^{N-1})$ , where  $\sigma \equiv a$  for some  $0 < a \le b$ . A similar result holds when  $\Omega$  is of the form 1.1 (see Theorems 5.1 and 5.4) Thus, we need to study these types of spaces.

**Definition 3.18.** Given a screening function  $\sigma: \mathbb{R}^{N-1} \to (0, \infty), 1 \leq p < \infty, 0 < s < 1$ , we define the space  $\dot{X}_{(\sigma)}^{s,p}(\mathbb{R}^{N-1})$  as the space of all pairs of functions  $(f^-, f^+)$  such that  $f^{\pm} \in \tilde{W}_{(\sigma)}^{s,p}(\mathbb{R}^{N-1})$  and

$$\int_{\mathbb{R}^{N-1}} \frac{|f^+(x') - f^-(x')|^p}{(\sigma(x'))^{p-1}} \, dx' < \infty.$$

We set

$$|(f^{-}, f^{+})|_{\dot{X}_{(\sigma)}^{s,p}(\mathbb{R}^{N-1})} := \left( \int_{\mathbb{R}^{N-1}} \frac{|f^{+}(x') - f^{-}(x')|^{p}}{(\sigma(x'))^{p-1}} dx' \right)^{1/p} + |f^{-}|_{\tilde{W}_{(\sigma)}^{s,p}(\mathbb{R}^{N-1})} + |f^{+}|_{\tilde{W}_{(\sigma)}^{s,p}(\mathbb{R}^{N-1})}.$$

Note that we do not allow the screening function to take the value  $+\infty$  in this definition in order to force  $1/\sigma^{p-1} > 0$ .

Thanks to Proposition 3.2 we know that if  $|(f^-, f^+)|_{\dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})} = 0$ , then there exist  $c^{\pm} \in \mathbb{R}$  such that  $f^{\pm}(x') = c^{\pm}$  for  $\mathcal{L}^{N-1}$  a.e.  $x' \in \mathbb{R}^{N-1}$ , but in view of the first term in  $|\cdot|_{\dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})}$ , it must then hold that  $c^+ = c^-$ . Thus,  $(f^-, f^+) \sim (g^-, g^+)$  if and only

if there exists  $c \in \mathbb{R}$  such that  $f^{\pm}(x') - g^{\pm}(x') = c$  for  $\mathcal{L}^{N-1}$  a.e.  $x' \in \mathbb{R}^{N-1}$ . With a slight abuse of notation we write the quotient space  $\dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})/K$  (see Section 2.4) as  $\dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})/\mathbb{R}$ . Our next result establishes that  $\dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})/\mathbb{R}$  is complete.

**Theorem 3.19.** Let  $\sigma: \mathbb{R}^{N-1} \to (0, \infty)$  be a screening function, let  $1 \leq p < \infty$ , and let 0 < s < 1. Then the space  $\dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})/\mathbb{R}$  is a Banach space with the norm

$$\|[(f^-, f^+)]\|_{\dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})/\mathbb{R}} := |(f^-, f^+)|_{\dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})}.$$

Moreover, if  $1 , then <math>\dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})/\mathbb{R}$  is reflexive.

**Proof.** We divide the proof into steps.

Step 1 – Limits of Cauchy sequences: According to the discussion in Section 2.4, in order to prove that  $\dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})/\mathbb{R}$  is a Banach space, it is enough to show that  $\dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})$  is sequentially complete. Let  $\{(f_n^-,f_n^+)\}_{n=1}^\infty$  be a Cauchy sequence in  $\dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})$ . We then know that  $\{f_n^-\}_{n=1}^\infty$  and  $\{f_n^+\}_{n=1}^\infty$  are Cauchy sequences in  $\tilde{W}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})$ . In addition, we know that  $\{f_n^+-f_n^-\}_{n=1}^\infty$  is a Cauchy sequence in  $L^1(\mathbb{R}^{N-1};\nu)$ , where  $\nu:\mathcal{B}(\mathbb{R}^{N-1})\to [0,\infty]$  is the measure given by

$$\nu(E) := \int_{E} \frac{1}{(\sigma(x'))^{p-1}} dx'.$$

Using Theorem 3.7 and the completeness of  $L^p(\mathbb{R}^{N-1};\nu)$ , we deduce that there exist a pair  $f^{\pm} \in \tilde{W}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})$  and a function  $g \in L^1(\mathbb{R}^{N-1};\nu)$  such that  $f_n^{\pm} \to f^{\pm}$  in  $\tilde{W}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})$  and  $f_n^+ - f_n^- \to g$  in  $L^1(\mathbb{R}^{N-1};\nu)$  as  $n \to \infty$ .

Step 2 – Identifying the limits: We will use the same notation for averages as in the proof of Theorem 3.7. Let  $\{V_k\}_{k=1}^{\infty}$  be the sequence of open sets given by Lemma 3.6 for  $\Omega = \mathbb{R}^{N-1}$ . The Lemma allows us to apply Theorem 3.5 on each set  $V_k$  in order to see that

$$\|(f_n^{\pm} - (f_n^{\pm})_{V_1}) - (f^{\pm} - (f^{\pm})_{V_1})\|_{L^p(V_k)} \le c_k |f_n^{\pm} - f^{\pm}|_{\tilde{W}_{(\sigma)}^{s,p}(V_k)} \le c_k |f_n^{\pm} - f^{\pm}|_{\tilde{W}_{(\sigma)}^{s,p}(\mathbb{R}^{N-1})}.$$

Consequently, for each  $k \in \mathbb{N}$  we have that  $f_n^{\pm} - (f_n^{\pm})_{V_1} \to f^{\pm} - (f^{\pm})_{V_1}$  in  $L^p(V_k)$  as  $n \to \infty$ .

Up to the extraction of a subsequence, which we continue to denote by  $\{f_n^{\pm}\}_{n=1}^{\infty}$  for the sake of brevity, we may assume that there exists a measurable set  $D \subseteq \mathbb{R}^{N-1}$  with  $\mathcal{L}^{N-1}(D) = 0$  such that

$$f_n^{\pm} - (f_n^{\pm})_{V_1} \to f^{\pm} - (f^{\pm})_{V_1}$$
 and  $f_n^+ - f_n^- \to g$  pointwise on  $\mathbb{R}^{N-1} \setminus D$  as  $n \to \infty$ .

Choosing any  $x \in \mathbb{R}^{N-1} \backslash D$ , we may then compute

$$(f_n^-)_{V_1} - (f_n^+)_{V_1} = [f_n^+(x) - (f_n^+)_{V_1}] - [f_n^-(x) - (f_n^-)_{V_1}] - [f_n^+(x) - f_n^-(x)]$$

$$\to [f^+(x) - (f^+)_{V_1}] - [f^-(x) - (f^-)_{V_1}] - g(x) \text{ as } n \to \infty.$$

From this we deduce that there exists a constant  $C \in \mathbb{R}$  such that

$$f^+ - f^- - g = C$$
 almost everywhere in  $\mathbb{R}^{N-1}$ .

Now, the fact that  $f_n^- \to f^-$  in  $\tilde{W}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})$  also implies that  $f_n^- \to f^- + C$  in  $\tilde{W}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})$ . This allows us to make the replacement  $f^- \mapsto f^- + C$  in order to see that

$$g = \lim_{n \to \infty} f_n^+ - \lim_{n \to \infty} f_n^- \in L^1(\mathbb{R}^{N-1}; \nu),$$

from which we then deduce that  $(f^-, f^+) \in \dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})$  and  $\dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})$  is sequentially complete.

**Step 3** – **Reflexivity:** Assume that 1 . Write

$$\Gamma = \{(x, h) \in \mathbb{R}^{N-1} \times \mathbb{R}^{N-1} \mid |h| < \sigma(x)\} \subseteq \mathbb{R}^{2(N-1)}.$$

Consider the mapping

$$\dot{X}_{(\sigma)}^{s,p}(\mathbb{R}^{N-1})/\mathbb{R} \ni [(f^-, f^+)] \mapsto (v_{f^-}, v_{f^+}, f^+ - f^-) \in L^p(\Gamma; \mu) \times L^p(\Gamma; \mu) \times L^p(\mathbb{R}^{N-1}; \nu),$$

where  $\mu$  is the measure defined in (3.16) and  $v_{f^{\pm}}(x',h') = f^{\pm}(x'+h') - f^{\pm}(x')$ . This map is an isometric embedding (see (3.17)), and by the previous two steps we can identify  $\dot{X}_{(\sigma)}^{s,p}(\mathbb{R}^{N-1})/\mathbb{R}$  with its image, which is a closed subspace of the Cartesian product of three reflexive spaces. Since the product of reflexive spaces is reflexive and closed subspaces of reflexive spaces are reflexive, it follows that  $\dot{X}_{(\sigma)}^{s,p}(\mathbb{R}^{N-1})/\mathbb{R}$  is reflexive.  $\square$ 

In view of the previous proposition and of the discussion in Section 2.4, when  $1 a bounded sequence in <math>\dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})$  admits a subsequence that converges weakly in  $\dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})$ . In the next theorem we study the relationship between this weak limit and the weak limit with respect to  $L^p_{\rm loc}(\mathbb{R}^{N-1})$  convergence.

**Theorem 3.20.** Let  $\sigma: \mathbb{R}^{N-1} \to (0,\infty)$  be a screening function, 1 , and <math>0 < s < 1. Let  $(f_n^-, f_n^+) \in \dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})$  for  $n \in \mathbb{N}$ , and let  $(f^-, f^+) \in \dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})$  be such that  $(f_n^-, f_n^+) \rightharpoonup (f^-, f^+)$  in  $\dot{X}^{s,p}_{(\sigma)}(\mathbb{R}^{N-1})$  and  $f_n^{\pm} \rightharpoonup g^{\pm}$  in  $L^p_{\text{loc}}(\mathbb{R}^{N-1})$  as  $n \to \infty$ . Then there exist  $c^{\pm} \in \mathbb{R}$  such that  $f^{\pm}(x') - g^{\pm}(x') = c^{\pm}$  for  $\mathcal{L}^{N-1}$  a.e.  $x' \in \mathbb{R}^{N-1}$ . Moreover, if

$$\int_{\mathbb{R}^{N-1}} \frac{1}{(\sigma(x'))^{p-1}} dx' = \infty, \tag{3.29}$$

then  $(f^-, f^+) \sim (g^-, g^+)$ .

**Proof.** Let  $\{V_k\}_{k=1}^{\infty}$  be the sequence of open subsets of  $\mathbb{R}^{N-1}$  given by Lemma 3.6. Fix  $k \in \mathbb{N}$  and suppose that  $\varphi^{\pm} \in C_c^{\infty}(\mathbb{R}^{N-1})$  are such that  $\sup \varphi^{\pm} \subset V_k$  and  $\int_{\mathbb{R}^{N-1}} \varphi^{\pm}(x') dx' = 0$ . Using these, we define the linear functional  $T : \dot{X}_{(\sigma)}^{s,p}(\mathbb{R}^{N-1}) \to \mathbb{R}$  via

$$T(h^-, h^+) := \int_{\mathbb{R}^{N-1}} h^-(x')\varphi^-(x') dx' + \int_{\mathbb{R}^{N-1}} h^+(x')\varphi^+(x') dx'. \tag{3.30}$$

By Hölder's inequality, the Poincaré inequality of Theorem 3.5 (which is applicable due to Lemma 3.6), and the fact that  $\int_{\mathbb{R}^{N-1}} \varphi^{\pm}(x') dx' = 0$ , we have the estimate

$$\begin{split} |T(h^{-},h^{+})| &\leq \int_{\mathbb{R}^{N-1}} |h^{-}(x') - h_{V_{1}}^{-}||\varphi^{-}(x')| \, dx' + \int_{\mathbb{R}^{N-1}} |h^{+}(x') - h_{V_{1}}^{+}||\varphi^{+}(x')| \, dx' \\ &\leq \|\varphi^{-}\|_{L^{p'}(\mathbb{R}^{N-1})} \|h^{-} - h_{V_{1}}^{-}\|_{L^{p}(V_{k}} + \|\varphi^{+}\|_{L^{p'}(\mathbb{R}^{N-1})} \|h^{+} - h_{V_{1}}^{+}\|_{L^{p}(V_{k})} \\ &\leq c|h^{-}|_{\tilde{W}_{(\sigma)}^{s,p}(\mathbb{R}^{N-1})} + c|h^{+}|_{\tilde{W}_{(\sigma)}^{s,p}(\mathbb{R}^{N-1})} \leq c|(h^{-},h^{+})|_{\dot{X}_{(\sigma)}^{s,p}(\mathbb{R}^{N-1})}. \end{split}$$

This shows that  $T \in (\dot{X}_{(\eta)}^{s,p}(\mathbb{R}^{N-1}))'$ , and it follows immediately that

$$T(f_n^-, f_n^+) \to T(f^-, f^+) \text{ as } n \to \infty.$$
 (3.31)

On the other hand, the functionals  $T^{\pm}: L^p(V_k) \to \mathbb{R}$  defined by

$$T^{\pm}(h^{\pm}) := \int_{V_k} h^{\pm}(x')\varphi^{\pm}(x') dx'$$

are continuous. Hence, by hypothesis  $T^{\pm}(f_n^{\pm}) \to T^{\pm}(g^{\pm})$  as  $n \to \infty$ . Comparing with (3.31), we arrive at the identity

$$\int_{V_L} (f^- - g^-)(x')\varphi^-(x') dx' + \int_{V_L} (f^+ - g^+)(x')\varphi^+(x') dx' = 0.$$

Given the arbitrariness of  $\varphi^{\pm}$ , we deduce that there exist  $c_k^{\pm} \in \mathbb{R}$  such that  $f^{\pm}(x') - g^{\pm}(x') = c_k^{\pm}$  for  $\mathcal{L}^{N-1}$  a.e.  $x' \in V_k$ . However, Lemma 3.6 guarantees that  $V_k \subset V_{k+1}$  for  $k \in \mathbb{N}$  and that  $\mathbb{R}^{N-1} = \bigcup_{k=1}^{\infty} V_K$ , so we deduce the existence of a single pair of constant  $c^{\pm} \in \mathbb{R}$  such that  $c_k^{\pm} = c^{\pm}$  for all  $k \in \mathbb{N}$ . Hence,  $f^{\pm}(x') - g^{\pm}(x') = c^{\pm}$  for  $\mathcal{L}^{N-1}$  a.e.  $x' \in \mathbb{R}^{N-1}$ . This proves the first assertion.

Now assume that (3.29) holds. Then since  $f_n^{\pm} \rightharpoonup g^{\pm}$  in  $L^p_{loc}(\mathbb{R}^{N-1})$  as  $n \to \infty$ , standard lower semicontinuity results imply that for each  $k \in \mathbb{N}$ 

$$\int_{V_k} \frac{|g^+(x') - g^-(x')|^p}{(\sigma(x'))^{p-1}} dx' \le \liminf_{n \to \infty} \int_{V_k} \frac{|f_n^+(x') - f_n^-(x')|^p}{(\sigma(x'))^{p-1}} dx' < \infty$$

$$\le \liminf_{n \to \infty} \int_{\mathbb{R}^{N-1}} \frac{|f_n^+(x') - f_n^-(x')|^p}{(\sigma(x'))^{p-1}} dx' := M^p < \infty.$$

Thus

$$|c^{+} - c^{-}| \|\sigma^{-(p-1)/p}\|_{L^{p}(V_{k})}$$

$$\leq \|((f^{+} - g^{+}) - (f^{-} - g^{-}))\sigma^{-(p-1)/p}\|_{L^{p}(V_{k})}$$

$$\leq \|(f^{+} - f^{-})\sigma^{-(p-1)/p}\|_{L^{p}(V_{k})} + \|(g^{+} - g^{-})\sigma^{-(p-1)/p}\|_{L^{p}(V_{k})}$$

$$\leq \|(f^{+} - f^{-})\sigma^{-(p-1)/p}\|_{L^{p}(\mathbb{R}^{N-1})} + M < \infty,$$

which implies, upon sending  $k \to \infty$ , that  $c^+ = c^-$ .  $\square$ 

# 4. Traces in the strip case

In this section we consider the special case in which  $\Omega$  is a horizontal strip of the form (1.3).

4.1. The case 
$$m = 1, p > 1$$

theorem of calculus to see that

In this subsection we prove Theorems 1.2 and 1.4 and then derive some extra information about homogeneous Sobolev spaces.

**Proof of Theorem 1.2.** For the sake of simplicity, we take  $b^- = 0$  and we set  $b := b^+$ . Due to the absolute continuity results of Theorem 3.1, we may apply the fundamental

$$u(x',b) - u(x',0) = \int_{0}^{b} \partial_N u(x',x_N) dx_N$$

for  $\mathcal{L}^{N-1}$  a.e.  $x' \in \mathbb{R}^{N-1}$ . It then follows by Hölder's inequality that

$$|u(x',b) - u(x',0)|^p \le b^{p-1} \int_0^b |\partial_N u(x',x_N)|^p dx_N.$$

We then integrate in x' over  $\mathbb{R}^{N-1}$  and using Tonelli's theorem to obtain the estimate

$$\int_{\mathbb{R}^{N-1}} |u(x',b) - u(x',0)|^p dx' \le b^{p-1} \int_{\Omega} |\partial_N u(x)|^p dx.$$

This proves (1.6).

We will prove (1.7) only for  $\Gamma^-$ , as a similar argument establishes the corresponding bound on  $\Gamma^+$ . We again use the fundamental theorem of calculus (due to Theorem 3.1) to see that for  $\mathcal{L}^{N-1}$  a.e.  $x' \in \mathbb{R}^{N-1}$ ,  $h' \in \mathbb{R}^{N-1}$  with |h'| < b, and  $0 < x_N < b$  we have that

$$u(x'+h',0) - u(x',0) = u(x'+h',x_N) - u(x',x_N) - \int_0^{x_N} \partial_N u(x'+h',s) \, ds$$
$$- \int_0^{x_N} \partial_N u(x',s) \, ds = \int_0^1 \nabla_{\shortparallel} u(x'+sh',x_N) \cdot h' ds$$
$$- \int_0^{x_N} \partial_N u(x'+h',s) \, ds - \int_0^{x_N} \partial_N u(x',s) \, ds.$$

From this we may estimate

$$\begin{split} |u(x'+h',0)-u(x',0)| & \leq |h'| \int\limits_0^1 |\nabla_{\shortparallel} u(x'+sh',x_N)| ds \\ & + \int\limits_0^{x_N} |\partial_N u(x'+h',s)| \, ds + \int\limits_0^{x_N} |\partial_N u(x',s)| \, ds. \end{split}$$

We now take the  $L^p$  norm in x' over  $\mathbb{R}^{N-1}$  on both sides of this inequality and apply Minkowksi's inequality for integrals (see, for instance, Corollary B.83 in [23]); using the change of variables y' = x' + sh' and y' = x' + h' in the first integral and second integral on the resulting right-hand-side, we then obtain the bound

$$||u(\cdot+h',0)-u(\cdot,0)||_{L^p(\mathbb{R}^{N-1})} \leq |h'|||\nabla_{\shortparallel}u(\cdot,x_N)||_{L^p(\mathbb{R}^{N-1})} + 2\int\limits_0^{x_N} ||\partial_N u(\cdot,s)||_{L^p(\mathbb{R}^{N-1})} ds.$$

Next, we average in  $x_N$  over the interval [0, |h'|] to see that

$$||u(\cdot + h', 0) - u(\cdot, 0)||_{L^{p}(\mathbb{R}^{N-1})} \le 3 \int_{0}^{|h'|} ||\nabla u(\cdot, x_{N})||_{L^{p}(\mathbb{R}^{N-1})} dx_{N}.$$

$$(4.1)$$

In turn, this implies that

$$\frac{\|u(\cdot+h',0)-u(\cdot,0)\|_{L^p(\mathbb{R}^{N-1})}^p}{|h'|^{p+N-2}} \leq \frac{3^p}{|h'|^{p+N-2}} \left( \int\limits_0^{|h'|} \|\nabla u(\cdot,x_N)\|_{L^p(\mathbb{R}^{N-1})} dx_N \right)^p.$$

We then integrate in h' over B'(0,b) and use spherical coordinates to estimate

$$\int_{B'(0,b)} \frac{\|u(\cdot+h',0)-u(\cdot,0)\|_{L^p(\mathbb{R}^{N-1})}^p}{|h'|^{p+N-2}} dh'$$

$$\leq \int_{B'(0,b)} \frac{3^p}{|h'|^{p+N-2}} \left( \int_0^{|h'|} \|\nabla u(\cdot,x_N)\|_{L^p(\mathbb{R}^{N-1})} dx_N \right)^p dh'$$

$$= 3^p \beta_{N-1} \int_0^b \frac{1}{r^p} \left( \int_0^r \|\nabla u(\cdot,x_N)\|_{L^p(\mathbb{R}^{N-1})} dx_N \right)^p dr.$$

Applying Hardy's inequality to the right-hand side (see, for instance, Theorem C.41 in [23]) and using Tonelli's theorem then yields the bound

$$\int_{B'(0,b)} \frac{\|u(\cdot+h',0)-u(\cdot,0)\|_{L^p(\mathbb{R}^{N-1})}^p}{|h'|^{p+N-2}} dh' \le \frac{3^p \beta_{N-1} p^p}{(p-1)^p} \int_{\Omega} |\nabla u(x)|^p dx,$$

which completes the proof of (1.7) and thus of the first two items of the theorem.

It remains to prove the integration-by-parts formula of the third item. For this it suffices to note that if  $u \in \dot{W}^{1,p}(\Omega)$  and  $\psi \in C_c^1(\mathbb{R}^N)$ , then  $u \in W^{1,p}(U)$  for any open set  $U \subseteq \Omega$  with Lipschitz boundary such that  $\operatorname{supp}(\psi) \cap \Omega \subset U$ . Thus the third item follows immediately from the usual trace theory in  $W^{1,p}(U)$ .  $\square$ 

Next we prove Theorem 1.4.

**Proof of Theorem 1.4.** For the sake of simplicity, we again take  $b^-=0$  and we set  $b:=b^+$ . Thanks to Theorem 3.13 we may assume without loss of generality that 0 < a < b, at the expense of having all constants depend on b. Let  $\varphi \in C_c^{\infty}(\mathbb{R}^{N-1})$  be a nonnegative function such that  $\int_{\mathbb{R}^{N-1}} \varphi(y') \, dy' = 1$  and  $\sup \varphi \subseteq B'(0, ab^{-1})$ . Define  $u^-: \Omega \to \mathbb{R}$  via

$$u^{-}(x) = (\varphi_{x_N} * f^{-})(x') = \int_{\mathbb{R}^{N-1}} f^{-}(y')\varphi_{x_N}(x' - y') dy',$$

where  $\varphi_{x_N}$  is given in (2.3). Then for i = 1, ..., N we have that

$$\partial_i u^-(x) = \int_{\mathbb{R}^{N-1}} f^-(y') \frac{\partial}{\partial x_i} (\varphi_{x_N} (x' - y')) dy'.$$

In view of Proposition 2.2, we are in a position to apply Proposition 2.3 to conclude that

$$\int_{\Omega} |\partial_i u^-(x)|^p dx \le c \int_{\mathbb{R}^{N-1}} \int_{B'(x',a)} \frac{|f^-(y') - f^-(x')|^p}{|x' - y'|^{N+p-2}} dy' dx'.$$

This shows that  $u^- \in \dot{W}^{1,p}(\Omega)$ . Moreover, since by standard properties of mollifiers  $\varphi_{x_N} * f^- \to f^-$  in  $L^p_{\text{loc}}(\mathbb{R}^{N-1})$  as  $x_N \to 0^+$ , we have that  $\text{Tr}(u^-) = f^-$  on  $\Gamma^-$ . Similarly, if we define  $u^+ : \Omega \to \mathbb{R}$  via

$$u^{+}(x) = (\varphi_{b-x_N} * f^{+})(x'),$$

then a similar argument shows that  $u^+ \in \dot{W}^{1,p}(\Omega)$  with  $\text{Tr}(u^+) = f^+$  on  $\Gamma^+$ .

Now let  $\theta \in C^{\infty}([0,b])$  be such that  $\theta = 1$  in a neighborhood of 0 and  $\theta = 0$  in a neighborhood of b, and define  $u: \Omega \to \mathbb{R}$  via

$$u(x) = \theta(x_N)u^{-}(x) + (1 - \theta(x_N))u^{+}(x).$$

It is clear by construction that  $\text{Tr}(u)=f^+$  on  $\Gamma^+$  and  $\text{Tr}(u)=f^-$  on  $\Gamma^-$  and that the map  $(f^+,f^-)\mapsto u$  is linear. For  $i=1,\ldots,N-1$  we compute

$$\partial_i u(x) = \theta(x_N) \partial_i u^-(x) + (1 - \theta(x_N)) \partial_i u^+(x),$$
  
$$\partial_N u(x) = \theta'(x_N) (u^-(x) - u^+(x)) + \theta(x_N) \partial_N u^-(x) + (1 - \theta(x_N)) \partial_N u^+(x).$$

Since  $\nabla u^{\pm} \in L^p(\Omega)$  and  $\theta$  is bounded, in order to prove that  $\nabla u \in L^p(\Omega)$  it remains only to show that  $\theta'(u^- - u^+) \in L^p(\Omega)$ .

By the fundamental theorem of calculus (which can be applied since  $u^-$  and  $u^+$  are absolutely continuous on  $\mathcal{L}^{N-1}$  a.e. line parallel to  $e_N$ ),

$$u^{-}(x) = f^{-}(x') + \int_{0}^{x_{N}} \partial_{N} u^{-}(x', s) ds,$$
$$u^{+}(x) = f^{+}(x') - \int_{0}^{b} \partial_{N} u^{+}(x', s) ds.$$

Hence,

$$|u^{+}(x) - u^{-}(x)| \le |f^{+}(x') - f^{-}(x')| + \int_{0}^{b} |\partial_{N}u^{-}(x',s)| \, ds + \int_{0}^{b} |\partial_{N}u^{+}(x',s)| \, ds.$$

We may then apply Hölder's inequality to see that

$$|u^{+}(x) - u^{-}(x)|^{p} \leq 2^{p-1}|f^{+}(x') - f^{-}(x')|^{p}$$
$$+ 2^{p-1}b^{p-1} \int_{0}^{b} (|\partial_{N}u^{-}(x',s)|^{p} + |\partial_{N}u^{+}(x',s)|^{p}) ds.$$

Since  $|\theta'(x_N)| \leq cb^{-1}$ , it follows that

$$|\theta'(x_N)(u^+(x) - u^-(x))|^p \le cb^{-p}|f^+(x') - f^-(x')|^p$$

$$+ cb^{-1} \int_0^b (|\partial_N u^-(x',s)|^p + |\partial_N u^+(x',s)|^p) ds.$$

Integrating both sides over  $\Omega$  and using Tonelli's theorem then shows that

$$\int_{\Omega} |\theta'(x_N)(u^+(x) - u^-(x))|^p dx \le cb^{-p+1} \int_{\mathbb{R}^{N-1}} |f^+(x') - f^-(x')|^p dx' 
+ c \int_{\Omega} (|\partial_N u^-(x)|^p + |\partial_N u^+(x)|^p) dx,$$

which completes the proof.  $\Box$ 

Our next result establishes the existence of functions in  $\dot{W}^{1,p}(\Omega)$  that cannot be extended to  $\dot{W}^{1,p}(\mathbb{R}^N)$ .

**Proposition 4.1.** Let  $\Omega$  be as in (1.3). Then there exists a function  $u \in \dot{W}^{1,p}(\Omega)$  such that u cannot be extended to a function in  $\dot{W}^{1,p}(\mathbb{R}^N)$ . In particular, there does not exist a bounded extension operator  $E: \dot{W}^{1,p}(\Omega) \to \dot{W}^{1,p}(\mathbb{R}^N)$ 

**Proof.** Write  $f \in \tilde{W}_{(1)}^{1-1/p,p}(\mathbb{R}^{N-1}) \backslash \dot{W}^{1-1/p,p}(\mathbb{R}^{N-1})$  for the function constructed in Theorem 3.11. According to Theorem 1.4 we can choose  $u \in \dot{W}^{1,p}(\Omega)$  such that Tr(u) = f on  $\Gamma^+$  and on  $\Gamma^-$  (i.e. we use  $f^+ = f^- = f$  in the theorem).

Suppose now, by way of contradiction, that there exists  $v \in \dot{W}^{1,p}(\mathbb{R}^N)$  such that v = u a.e. on  $\Omega$ . We may then use the trace theory for homogeneous Sobolev spaces on  $\mathbb{R}^N$  (see Theorem 18.57 and Remark 18.60 in [23]) to deduce that the trace of v onto  $\Gamma^-$  belongs to  $\dot{W}^{1-1/p,p}(\mathbb{R}^{N-1})$ . However, this trace must agree with f, and so we arrive at a contradiction. Thus, there is no such v.  $\square$ 

4.2. The case 
$$m = 1, p = 1$$

In this subsection we turn our attention to the proofs of Theorems 1.7 and 1.8.

**Proof of Theorem 1.7.** As in the proof of Theorem 1.2, we set  $b^- = 0$  and  $b := b^+$ . The inequality (1.11) follows as in the proof of Theorem 1.2. On the other hand, from (4.1) we get

$$\int_{\mathbb{R}^{N-1}} |u(x'+h',0) - u(x',0)| \, dx' \le 3 \int_{0}^{|h'|} \int_{\mathbb{R}^{N-1}} |\nabla u(x)| \, dx' dx_N$$
$$\le 3 \int_{0}^{\varepsilon} \int_{\mathbb{R}^{N-1}} |\nabla u(x)| \, dx' dx_N.$$

Hence,

$$\sup_{|h'| \le \varepsilon} \int_{\mathbb{R}^{N-1}} |u(x'+h',0) - u(x',0)| \, dx' \le 3 \int_{0}^{\varepsilon} \int_{\mathbb{R}^{N-1}} |\nabla u(x)| \, dx' dx_N \to 0$$

as  $\varepsilon \to 0^+$  by the Lebesgue dominated convergence theorem, which can be applied since by Fubini's theorem,

$$\int_{0}^{b} \left( \int_{\mathbb{R}^{N-1}} |\nabla u(x', x_N)| \, dx' \right) dx_N = \int_{\Omega} |\nabla u(x)| \, dx < \infty.$$

Similar holds on the upper surface  $\{x_N = b\}$ . This proves the first two items of the theorem, and the third follows as in the proof of Theorem 1.2.  $\square$ 

We next prove the corresponding lifting result.

**Proof of Theorem 1.8.** Once again we set  $b^- = 0$  and  $b := b^+$  for simplicity. Let  $\varepsilon_0 > 0$  be such that

$$||f^{\pm}||_1 := \sup_{|h'| \le \varepsilon_0} \int_{\mathbb{D}^{N-1}} |f^{\pm}(x'+h') - f^{\pm}(x')| dx' < \infty.$$

We construct a decreasing sequence  $\varepsilon_n \to 0^+$  such that

$$\sup_{|h'| \le \varepsilon_n} \int_{\mathbb{R}^{N-1}} |f^-(x'+h') - f^-(x')| \, dx' \le \frac{1}{2^n} ||f^-||_1 \tag{4.2}$$

and define  $f_n^- := \varphi_{\varepsilon_n} * f^-$ , where  $\varphi \in C_c^{\infty}(\mathbb{R}^{N-1})$  is a standard mollifier.

We claim that  $\partial_i f_n^- \in L^1(\mathbb{R}^{N-1})$ . Indeed, since  $\int_{\mathbb{R}^{N-1}} \partial_i \varphi(z') dz' = 0$ , we may compute

$$\partial_{i} f_{n}^{-}(x') = \frac{1}{\varepsilon_{n}^{N}} \int_{\mathbb{R}^{N-1}} f^{-}(y') \partial_{i} \varphi \left(\frac{x'-y'}{\varepsilon}\right) dy'$$

$$= \frac{1}{\varepsilon_{n}} \int_{\mathbb{R}^{N-1}} f^{-}(x'-\varepsilon_{n}z') \partial_{i} \varphi (z') dz'$$

$$= \frac{1}{\varepsilon_{n}} \int_{\mathbb{R}^{N-1}} [f^{-}(x'-\varepsilon_{n}z') - f^{-}(x')] \partial_{i} \varphi (z') dz',$$

and so Tonelli's theorem allows us to estimate

$$\int_{\mathbb{R}^{N-1}} \left| \partial_i f_n^-(x') \right| \, dx' \le \frac{1}{\varepsilon_n} \int_{B'(0,1)} \left| \partial_i \varphi \left( z' \right) \right| \int_{\mathbb{R}^{N-1}} \left| f^-(x' - \varepsilon_n z') - f^-(x') \right| \, dx' dz'$$

$$\le \frac{c}{\varepsilon_n} \sup_{|h'| \le \varepsilon_n} \int_{\mathbb{R}^{N-1}} \left| f^-(x' + h') - f^-(x') \right| \, dx' < \infty.$$

Next we construct a strictly decreasing sequence  $\{t_n\}_n$  in (0,1) such that  $t_n \to 0$  and

$$|t_{n+1} - t_n| \le \frac{1}{2^n} \frac{\|f^-\|_1}{\|\nabla_{\shortparallel} f_{n+1}^-\|_{L^1} + \|\nabla_{\shortparallel} f_n^-\|_{L^1} + 1},\tag{4.3}$$

and we then note that

$$t_1 = \sum_{n=1}^{\infty} t_n - t_{n+1}.$$

Using this sequence, we define the function  $v^-: \mathbb{R}^{N-1} \times (0, t_1) \to \mathbb{R}$  via

$$v^{-}(x) = \frac{t_n - x_N}{t_n - t_{n+1}} f_{n+1}^{-}(x') + \frac{x_N - t_{n+1}}{t_n - t_{n+1}} f_n^{-}(x') \text{ if } t_{n+1} \le x_N \le t_n.$$

Then for  $t_{n+1} < x_N < t_n$  we can bound

$$\left|\partial_{i}v^{-}(x)\right| \leq \left|\partial_{i}f_{n+1}^{-}(x')\right| + \left|\partial_{i}f_{n}^{-}(x')\right| \text{ for all } i = 1, \dots, N-1,$$

$$\left|\partial_{N}v^{-}(x)\right| \leq \left|\frac{f_{n+1}^{-}(x') - f_{n}^{-}(x')}{t_{n} - t_{n+1}}\right|.$$
(4.4)

Hence, for i = 1, ..., N - 1, we may use (4.3) and (4.4) to estimate

$$\int_{\mathbb{R}^{N-1} \times (0,t_1)} |\partial_i v^-| dx = \sum_{n=1}^{\infty} \int_{t_{n+1}}^{t_n} \int_{\mathbb{R}^{N-1}} |\partial_i v^-| dx' dx_N$$

$$\leq \sum_{n=1}^{\infty} |t_{n+1} - t_n| \int_{\mathbb{R}^{N-1}} (|\partial_i f_{n+1}^-(x')| + |\partial_i f_n^-(x')|) dx'$$

$$\leq ||f^-||_1 \sum_{n=1}^{\infty} \frac{1}{2^n}.$$

On the other hand, from (4.4) we know that

$$\int_{\mathbb{R}^{N-1} \times (0,t_1)} |\partial_N v^-| dx = \sum_{n=1}^{\infty} \int_{t_{n+1}}^{t_n} \int_{\mathbb{R}^{N-1}} |\partial_N v^-| dx' dx_N$$

$$\leq \sum_{n=1}^{\infty} \int_{\mathbb{R}^{N-1}} |f_{n+1}^-(x') - f_n^-(x')| dx'.$$

To estimate this final term, we use the identity

$$f_{n+1}^{-}(x') - f_{n}^{-}(x') = \int_{\mathbb{R}^{N-1}} [f^{-}(x' - \varepsilon_{n+1}z') - f^{-}(x' - \varepsilon_{n}z')]\varphi(z') dz'$$

in conjunction with Tonelli's theorem and (4.2) to see that

$$\int_{\mathbb{R}^{N-1}} \left| f_{n+1}^{-}(x') - f_{n}^{-}(x') \right| dx'$$

$$\leq \int_{B'(0,1)} \varphi(z') \int_{\mathbb{R}^{N-1}} \left| f^{-}(x' - \varepsilon_{n+1}z') - f^{-}(x' - \varepsilon_{n}z') \right| dx'dz'$$

$$\leq \int_{B'(0,1)} \varphi(z') \int_{\mathbb{R}^{N-1}} \left| f^{-}(x' - \varepsilon_{n+1}z') - f(x') \right| dx'dz'$$

$$+ \int_{B'(0,1)} \varphi(z') \int_{\mathbb{R}^{N-1}} \left| f^{-}(x' - \varepsilon_{n}z') - f(x') \right| dx'dz' \leq \frac{2}{2^{n}} \|f^{-}\|_{1}.$$

Combining these, we deduce that

$$\int_{\mathbb{R}^{N-1} \times (0,t_1)} |\partial_N v^-| dx \le 2||f^-||_1 \sum_{n=1}^{\infty} \frac{1}{2^n}.$$

Hence  $v^- \in \dot{W}^{1,1}(\mathbb{R}^{N-1} \times (0, t_1)).$ 

The function  $v^-$  is not defined in all of  $\Omega$ , but by scaling we can arrive at a function  $u^-:\Omega\to\mathbb{R}$ . Indeed, we set  $u^-(x)=v^-(x',x_Nt_1/b)$  for  $x\in\Omega$ . Clearly  $u^-\in\dot{W}^{1,1}(\Omega)$  and the trace of  $u^-$  on  $\Gamma^-$  is  $f^-$ . Similarly, we can construct a function  $u^+\in\dot{W}^{1,1}(\Omega)$  the trace of which is  $f^+$  on  $\Gamma^+$ . With  $u^-$  and  $u^+$  in hand, we can now proceed as in the second part of the proof of Theorem 1.4 to construct the desired function  $u^-$ 

4.3. The case 
$$m = 2, p > 1$$

In this subsection we study the traces of functions  $\dot{W}^{2,p}(\Omega)$  when p>1.

**Proof of Theorem 1.9.** As in the proof of Theorem 1.2, we take  $b^- = 0$ , set  $b := b^+$ . Applying Theorem 3.1 and Proposition 2.4 (see in particular (2.10)) to  $u(x',\cdot)$  for  $\mathcal{L}^{N-1}$  a.e.  $x' \in \mathbb{R}^{N-1}$ , we find that

$$u(x',b) - u(x',0) - (\partial_N u(x',b) + \partial_N u(x',0)) \frac{b}{2} = \int_0^b \partial_N^2 u(x',x_N) \left(b - \frac{x_N}{2}\right) dx_N.$$

Hence, by Hölder's inequality,

$$\left| u(x',b) - u(x',0) - (\partial_N u(x',b) + \partial_N u(x',0)) \frac{b}{2} \right|^p \le b^{2p-1} \int_0^b |\partial_N^2 u(x',x_N)|^p dx_N.$$

Integrating both sides with respect to  $x' \in \mathbb{R}^{N-1}$  and using Tonelli's theorem then shows that

$$\int_{\mathbb{R}^{N-1}} \left| u(x',b) - u(x',0) - (\partial_N u(x',b) + \partial_N u(x',0)) \frac{b}{2} \right|^p dx' \le b^{2p-1} \int_{\Omega} |\partial_N^2 u(x)|^p dx,$$

which proves (1.16).

On the other hand, for i = 1, ..., N,

$$\partial_i u(x',b) - \partial_i u(x',0) = \int\limits_0^b \partial_{i,N}^2 u(x',x_N) dx_N,$$

and so we may apply Hölder's inequality to see that

$$|\partial_i u(x',b) - \partial_i u(x',0)|^p \le b^{p-1} \int_0^b |\partial_{i,N}^2 u(x',x_N)|^p dx_N,$$

which upon integration in  $x' \in \mathbb{R}^{N-1}$  yields the bound

$$\int_{\mathbb{R}^{N-1}} |\partial_i u(x',b) - \partial_i u(x',0)|^p dx \le b^{p-1} \int_{\Omega} |\partial_{i,N}^2 u(x)|^p dx.$$

This is (1.15).

Finally, since  $\partial_i u \in \dot{W}^{1,p}(\Omega)$ , the inequality (1.17) follows by applying Theorem 1.2 to  $\partial_i u$ .  $\square$ 

Next we prove the corresponding lifting result.

**Proof of Theorem 1.10.** For simplicity we again take  $b^- = 0$  and set  $b := b^+$ . Without loss of generality we may assume that 0 < a < b. Let  $\varphi \in C_c^{\infty}(\mathbb{R}^{N-1})$  be a nonnegative even function such that  $\int_{\mathbb{R}^{N-1}} \varphi(y') \, dy' = 1$  and supp  $\varphi \subseteq B'(0, ab^{-1})$ . Define  $u^- : \Omega \to \mathbb{R}$  via

$$u^{-}(x) = \int_{\mathbb{R}^{N-1}} [f_{0}^{-}(y') + f_{1}^{-}(y')x_{N}]\varphi_{x_{N}}(x' - y') dy'$$
$$= \int_{\mathbb{R}^{N-1}} [f_{0}^{-}(x' - x_{N}z') + f_{1}^{-}(x' - x_{N}z')x_{N}]\varphi(z') dz',$$

where the second equality follows by the change of variables  $z' = \frac{x'-y'}{x_N}$ . Standard properties of mollifiers guarantee that for i=0,1 we have that  $\varphi_{x_N} * f_i^- \to f_i^-$  in  $L^p_{loc}(\mathbb{R}^{N-1})$  as  $x_N \to 0^+$ , so we deduce that  $\text{Tr}(u^-) = f_0^-$  on  $\Gamma^-$ .

For  $i = 1, \dots, N-1$  we compute

$$\partial_{i}u^{-}(x) = \int_{\mathbb{R}^{N-1}} \partial_{i}f_{0}^{-}(x' - x_{N}z')\varphi(z') dz' + \int_{\mathbb{R}^{N-1}} f_{1}^{-}(y')x_{N}\frac{\partial}{\partial x_{i}}(\varphi_{x_{N}}(x' - y')) dy'$$

$$= \int_{\mathbb{R}^{N-1}} \partial_{i}f_{0}^{-}(y')\varphi_{x_{N}}(x' - y') dy' + \int_{\mathbb{R}^{N-1}} f_{1}^{-}(y')x_{N}\frac{\partial}{\partial x_{i}}(\varphi_{x_{N}}(x' - y')) dy',$$
(4.5)

while for i = N

$$\begin{split} \partial_N u^-(x) &= \int\limits_{\mathbb{R}^{N-1}} -(\nabla_{\shortparallel} f_0^-(x'-x_N z') \cdot z') \varphi\left(z'\right) \, dz' \\ &+ \int\limits_{\mathbb{R}^{N-1}} f_1^-(y') \frac{\partial}{\partial x_N} (x_N \varphi_{x_N} \left(x'-y'\right)) \, dy' \end{split}$$

$$= \int_{\mathbb{R}^{N-1}} -\nabla_{\Pi} f_{0}^{-}(y') \cdot \frac{x' - y'}{x_{N}} \varphi_{x_{N}} (x' - y') dy'$$

$$+ \int_{\mathbb{R}^{N-1}} f_{1}^{-}(y') \left[ \varphi_{x_{N}} (x' - y') + x_{N} \frac{\partial}{\partial x_{N}} (\varphi_{x_{N}} (x' - y')) \right] dy' \qquad (4.6)$$

In turn, for j = 1, ..., N - 1 we may compute

$$\partial_{i,j}^{2} u^{-}(x) = \int_{\mathbb{R}^{N-1}} \partial_{i} f_{0}^{-}(y') \frac{\partial}{\partial x_{j}} (\varphi_{x_{N}} (x'-y')) dy'$$

$$+ \int_{\mathbb{R}^{N-1}} f_{1}^{-}(y') x_{N} \frac{\partial^{2}}{\partial x_{j} \partial x_{i}} (\varphi_{x_{N}} (x'-y')) dy', \tag{4.7}$$

while for j = N

$$\partial_{i,N}^{2} u^{-}(x) = \int_{\mathbb{R}^{N-1}} \partial_{i} f_{0}^{-}(y') \frac{\partial}{\partial x_{N}} (\varphi_{x_{N}} (x' - y')) dy'$$

$$+ \int_{\mathbb{R}^{N-1}} f_{1}^{-}(y') \left[ \frac{\partial}{\partial x_{i}} (\varphi_{x_{N}} (x' - y')) + x_{N} \frac{\partial^{2}}{\partial x_{i} \partial x_{N}} (\varphi_{x_{N}} (x' - y')) \right] dy'.$$

$$(4.8)$$

Finally, when i = j = N we have that

$$\partial_N^2 u^-(x) = \int_{\mathbb{R}^{N-1}} -\nabla_{\Pi} f_0^-(y') \cdot \frac{\partial}{\partial x_N} \left( \frac{x' - y'}{x_N} \varphi_{x_N} \left( x' - y' \right) \right) dy'$$

$$+ \int_{\mathbb{R}^{N-1}} f_1^-(y') \left[ 2 \frac{\partial}{\partial x_N} (\varphi_{x_N} \left( x' - y' \right)) + x_N \frac{\partial^2}{\partial x_N^2} (x_N \varphi_{x_N} \left( x' - y' \right)) \right] dy'. \tag{4.9}$$

Owing to Proposition 2.2, we are in a position to apply Proposition 2.3 to conclude that for i = 1, ..., N - 1 and j = 1, ..., N we have the bounds

$$\int_{\Omega} |\partial_{i,j}^{2} u^{-}(x)|^{p} dx \leq c \int_{\mathbb{R}^{N-1}} \int_{B'(x',a)} \frac{|\partial_{i} f_{0}^{-}(y') - \partial_{i} f_{0}^{-}(x')|^{p}}{|x' - y'|^{N+p-2}} dy' dx' 
+ c \int_{\mathbb{R}^{N-1}} \int_{B'(x',a)} \frac{|f_{1}^{-}(y') - f_{1}^{-}(x')|^{p}}{|x' - y'|^{N+p-2}} dy' dx'$$

while for two N derivatives we have that

$$\begin{split} \int\limits_{\Omega} |\partial_{N}^{2} u^{-}(x)|^{p} dx &\leq c \int\limits_{\mathbb{R}^{N-1}} \int\limits_{B'(x',a)} \frac{|\nabla_{\shortparallel} f_{0}^{-}(y') - \nabla_{\shortparallel} f_{0}^{-}(x')|^{p}}{|x' - y'|^{N+p-2}} \, dy' dx' \\ &+ c \int\limits_{\mathbb{R}^{N-1}} \int\limits_{B'(x',a)} \frac{|f_{1}^{-}(y') - f_{1}^{-}(x')|^{p}}{|x' - y'|^{N+p-2}} \, dy' dx', \end{split}$$

which shows that  $u^- \in \dot{W}^{2,p}(\Omega)$ .

Next we write

$$\begin{split} \partial_N u^-(x) &= \int\limits_{\mathbb{R}^{N-1}} -\nabla_{\shortparallel} f_0^-(y') \cdot \frac{x' - y'}{x_N} \varphi_{x_N} \left( x' - y' \right) \, dy' \\ &+ \int\limits_{\mathbb{R}^{N-1}} f_1^-(y') \left[ \varphi_{x_N} \left( x' - y' \right) + \frac{1}{x_N^{N-1}} \psi_N \left( \frac{x' - y'}{x_N} \right) \right] \, dy', \end{split}$$

where  $\psi_N$  is given in (2.6). Standard properties of mollifiers imply that as  $x_N \to 0^+$  we have that

$$\partial_N u^-(x) \to -\nabla_{\sqcap} f_0^-(x') \cdot \int_{\mathbb{R}^{N-1}} z' \varphi(z') \ dz' + f_1^-(x') \left[ 1 + \int_{\mathbb{R}^{N-1}} \psi_N(z') \, dz' \right] = f_1^-(x'),$$

where in the second equality we used the fact that  $\varphi$  is even to see that  $\int_{\mathbb{R}^{N-1}} z' \varphi(z') dz' = 0$  and Proposition 2.2 to see that  $\int_{\mathbb{R}^{N-1}} \psi_N(z') dz' = 0$ . Hence,  $\operatorname{Tr}(\partial_N u^-) = f_1^-$  on  $\Gamma^-$ . Similarly, if we define  $u^+: \Omega \to \mathbb{R}$  via

$$u^{+}(x) = \int_{\mathbb{R}^{N-1}} [f_0^{+}(y') + f_1^{+}(y')(b - x_N)] \varphi_{b-x_N}(x' - y') \ dy',$$

then we find that  $u^+ \in \dot{W}^{2,p}(\Omega)$  with estimates of the same form as above (with  $f_i^+$  replacing  $f_i^-$ ). Moreover,  $\text{Tr}(u^+) = f_0^+$  and  $\text{Tr}(\partial_N u^+) = f_1^+$  on  $\Gamma^+$ .

Let  $\theta \in C^{\infty}([0,b])$  be such that  $\theta = 1$  in a neighborhood of 0 and  $\theta = 0$  in a neighborhood of b and define  $u: \Omega \to \mathbb{R}$  via

$$u(x) = \theta(x_N)u^-(x) + (1 - \theta(x_N))u^+(x).$$

Then for i, j = 1, ..., N - 1,

$$\begin{split} \partial_{i,j}^{2} u(x) &= \theta(x_{N}) \partial_{i,j}^{2} u^{-}(x) + (1 - \theta(x_{N})) \partial_{i,j}^{2} u^{+}(x), \\ \partial_{i,N}^{2} u(x) &= \theta'(x_{N}) (\partial_{i} u^{-}(x) - \partial_{i} u^{+}(x)) + \theta(x_{N}) \partial_{i,N}^{2} u^{-}(x) + (1 - \theta(x_{N})) \partial_{i,N}^{2} u^{+}(x), \\ \partial_{N}^{2} u(x) &= \theta''(x_{N}) (u^{-}(x) - u^{+}(x)) + 2\theta'(x_{N}) (\partial_{N} u^{-}(x) - \partial_{N} u^{+}(x)) \\ &+ \theta(x_{N}) \partial_{N}^{2} u^{-}(x) + (1 - \theta(x_{N})) \partial_{N}^{2} u^{+}(x). \end{split}$$

From these calculations and the above bounds for  $u^{\pm} \in \dot{W}^{2,p}(\Omega)$ , we see that in order to prove the desired estimate for u it suffices to estimate  $\theta'(\nabla u^- - \nabla u^+)$  and  $\theta''(u^- - u^+)$ .

By Taylor's formula applied to  $u^-(x',\cdot)$  and  $u^+(x',\cdot)$ , respectively, we have that

$$u^{-}(x) = f_{0}^{-}(x') + f_{1}^{-}(x')x_{N} + \frac{1}{2} \int_{0}^{x_{N}} \partial_{N}^{2} u^{-}(x', s)(x_{N} - s) ds,$$
  
$$u^{+}(x) = f_{0}^{+}(x') - f_{1}^{+}(x')(b - x_{N}) - \frac{1}{2} \int_{x_{N}}^{b} \partial_{N}^{2} u^{+}(x', s)(x_{N} - s) ds,$$

where we used the fact that  $\text{Tr}(u^{\pm}) = f_0^{\pm}$  and  $\text{Tr}(\partial_N u^{\pm}) = f_1^{\pm}$  on  $\Gamma^{\pm}$ . Hence,

$$u^{+}(x) - u^{-}(x) = f_{0}^{+}(x') - f_{0}^{-}(x') - (f_{1}^{+}(x') + f_{1}^{-}(x'))\frac{b}{2} - (f_{1}^{+}(x') - f_{1}^{-}(x'))(\frac{b}{2} - x_{N})$$
$$-\frac{1}{2} \int_{x_{N}}^{b} \partial_{N}^{2} u^{+}(x', s)(x_{N} - s) ds - \frac{1}{2} \int_{0}^{x_{N}} \partial_{N}^{2} u^{-}(x', s)(x_{N} - s) ds.$$

From Hölder's inequality and the fact that  $|\theta''(x_N)| \leq cb^{-2}$  we see that

$$|\theta''(x_N)(u^+(x) - u^-(x))|^p \le cb^{-2p} \left| f_0^+(x') - f_0^-(x') - (f_1^+(x') + f_1^-(x')) \frac{b}{2} \right|^p$$

$$+ cb^{-p} |f_1^+(x') - f_1^-(x')|^p$$

$$+ cb^{-1} \int_{x_N}^b |\partial_N^2 u^+(x', s)|^p ds + cb^{-1} \int_0^{x_N} |\partial_N^2 u^-(x', s)|^p ds.$$

Integrating over  $x \in \Omega$  and using Tonelli's theorem then shows that

$$\int_{\Omega} |\theta''(x_N)(u^+(x) - u^-(x))|^p dx 
\leq cb^{-2p+1} \int_{\mathbb{R}^{N-1}} \left| f_0^+(x') - f_0^-(x') - (f_1^+(x') + f_1^-(x')) \frac{b}{2} \right|^p dx' 
+ cb^{-p+1} \int_{\mathbb{R}^{N-1}} |f_1^+(x') - f_1^-(x')|^p dx' 
+ c \int_{\Omega} |\partial_N^2 u^+(x)|^p dx + c \int_{\Omega} |\partial_N^2 u^-(x)|^p dx.$$

This is the desired estimate for  $\theta''(u^- - u^+)$ .

Finally, we derive the estimate for  $\theta'(\nabla u^- - \nabla u^+)$ . By the fundamental theorem of calculus for every i = 1, ..., N-1 we have that

$$\partial_i u^-(x) = \partial_i f_0^-(x') + \int_0^{x_N} \partial_{N,i}^2 u^-(x',s) \, ds,$$
$$\partial_i u^+(x) = \partial_i f_0^+(x') - \int_{x_N}^b \partial_{N,i}^2 u^+(x',s) \, ds.$$

Reasoning as above then shows that

$$\int_{\Omega} |\theta'(x_N)(\partial_i u^+(x) - \partial_i u^-(x))|^p dx \le cb^{-p+1} \int_{\mathbb{R}^{N-1}} |\partial_i f_0^+(x') - \partial_i f_0^-(x')|^p dx' 
+ c \int_{\Omega} (|\partial_{N,i}^2 u^-(x)|^p + |\partial_{N,i}^2 u^+(x)|^p) dx.$$

The term  $2\theta'(\partial_N u^- - \partial_N u^+)$  can be estimated in a similar way, which completes the proof.  $\Box$ 

# 4.4. The case $m \ge 2, p > 1$

Finally, in this subsection we treat the case in which  $m \geq 2$  and p > 1. Given a function  $u \in \dot{W}^{m,p}(\Omega)$ , we have that  $\nabla^k u \in \dot{W}^{m-k,p}(\Omega)$  for every  $k = 1, \ldots, m-1$  and thus by Theorem 1.2 there exists  $\text{Tr}(\nabla^k u)$ . By a density argument, it can be shown that  $\text{Tr}(\nabla^k u)(\cdot, b^{\pm}) \in W^{m-k-1,p}_{\text{loc}}(\mathbb{R}^{N-1})$  for every  $k = 1, \ldots, m-2$  and that for every  $j = 1, \ldots, m-k-1$ ,  $(\nabla_{\shortparallel})^j \text{Tr}(\nabla^k u)(\cdot, b^{\pm}) = \text{Tr}((\nabla_{\shortparallel})^j (\nabla^k u))(\cdot, b^{\pm})$ , where we recall that  $(\nabla_{\shortparallel})^j$  denotes the vector of all multi-indices  $\alpha = (\alpha', 0) \in \mathbb{N}_0^{N-1} \times \mathbb{N}_0$  with  $|\alpha| = j$ . Thus, to characterize the trace space of  $\dot{W}^{m,p}(\Omega)$ , it suffices to study Tr(u) and the trace of the normal derivatives  $\text{Tr}(\partial_N^k u)$  for  $k = 1, \ldots, m-1$ .

In what follows we use the notation established in (2.1) and (2.2).

**Theorem 4.2.** Let  $\Omega$  be as in (1.3),  $m \in \mathbb{N}$  with  $m \geq 2$ , and 1 . There exists a constant <math>c = c(m, N, p) > 0 such that for every  $u \in \dot{W}^{m,p}(\Omega)$  the following estimates hold: for every  $i, l \in \mathbb{N}_0$  with  $0 \leq i + l \leq m - 1$ ,

$$\int_{\mathbb{R}^{N-1}} \left| \sum_{k=0}^{m-l-i-1} \frac{(-1)^k}{k!} (\nabla_{\shortparallel}^i \operatorname{Tr}(\partial_N^{k+l} u)(x', b^+) + (-1)^{k+1} \nabla_{\shortparallel}^i \operatorname{Tr}(\partial_N^{k+l} u)(x', b^-)) \right| \\
\times \left( \frac{b^+ - b^-}{2} \right)^k \right|^p dx' \\
\leq (b^+ - b^-)^{(m-i-l)p-1} \int_{\Omega} |\nabla^m u(x)|^p dx, \tag{4.10}$$

and

$$\int_{\mathbb{R}^{N-1}} \int_{B'(0,b^{+}-b^{-})} \frac{|\operatorname{Tr}(\nabla^{m-1}u)(x'+h',b^{\pm}) - \operatorname{Tr}(\nabla^{m-1}u)(x',b^{\pm})|^{p}}{|h'|^{p+N-2}} dh' dx'$$

$$\leq c \int_{\Omega} |\nabla^{m}u(x)|^{p} dx. \tag{4.11}$$

**Proof.** As in the proof of Theorem 1.2 we take  $b^- = 0$ , set  $b := b^+$ . Let  $l, i \in \mathbb{N}_0$  with  $0 \le l + i \le m - 1$ . By Theorem 3.1 and Proposition 2.4 (in particular (2.10)) applied to  $\nabla^i_{ll} \partial^l_N u(x', \cdot)$  for  $\mathcal{L}^{N-1}$  a.e.  $x' \in \mathbb{R}^{N-1}$ , it follows that

$$\begin{split} \sum_{k=0}^{m-l-i-1} & \frac{(-1)^k}{k!} (\nabla^i_{\shortparallel} \partial^{k+l}_N u(x',b) + (-1)^{k+1} \nabla^i_{\shortparallel} \partial^{k+l}_N u(x',0)) \left(\frac{b}{2}\right)^k \\ & = \frac{1}{(m-l-i-1)!} \int\limits_0^b \nabla^i_{\shortparallel} \partial^{m-i}_N u(x',t) \left(b - \frac{t}{2}\right)^{m-l-i-1} dt, \end{split}$$

and so Hölder's inequality implies that

$$\left| \sum_{k=0}^{m-l-i-1} \frac{(-1)^k}{k!} (\nabla_{\shortparallel}^i \partial_N^{k+l} u(x',b) + (-1)^{k+1} \nabla_{\shortparallel}^i \partial_N^{k+l} u(x',0)) \left( \frac{b}{2} \right)^k \right|^p$$

$$\leq b^{(m-l-i)p-1} \int_0^b |\nabla^m u(x',x_N)|^p dx_N.$$

Integrating both sides with respect to  $x' \in \mathbb{R}^{N-1}$  and using Tonelli's theorem then shows that

$$\begin{split} \int\limits_{\mathbb{R}^{N-1}} \left| \sum_{k=0}^{m-l-i-1} \frac{(-1)^k}{k!} (\nabla^i_{\shortparallel} \partial^{k+l}_N u(x',b) + (-1)^{k+1} \nabla^i_{\shortparallel} \partial^{k+l}_N u(x',0)) \left(\frac{b}{2}\right)^k \right|^p dx' \\ & \leq b^{(m-l-i)p-1} \int\limits_{\Omega} |\nabla^m u(x)|^p dx, \end{split}$$

which is (4.10). On the other hand, since  $\nabla^m u \in \dot{W}^{1,p}(\Omega; \mathbb{R}^{M_m})$ , where  $M_m$  is the number of multi-indices of length m, inequality (4.11) follows by applying Theorem 1.2 to each component of  $\nabla^m u$ .  $\square$ 

Next we prove the corresponding lifting result. The proof is significantly more involved than the one for inhomogeneous Sobolev spaces (see, for example, [12], [25], or [29]) because we only have control of the screened homogeneous fractional seminorm of the

traces of the derivatives of order m-1 and we have no control of the seminorm of the traces of the derivatives of order less than m-1. Thus, we are forced to employ several integrations by parts, which makes the proof quite technical.

Before stating the result, we establish some notation. Given  $f_k^{\pm} \in W_{\text{loc}}^{m-1-k,p}(\mathbb{R}^{N-1})$  for  $k = 0, \dots, m-2$ , and  $f_{m-1}^{\pm} \in L_{\text{loc}}^p(\mathbb{R}^{N-1})$  we define

$$Q_{i,m,n}(x') := \sum_{k=0}^{m-i-n-1} \frac{(-1)^k}{k!} (\nabla^i_{\shortparallel} f^{\pm}_{k+n}(x') + (-1)^{k+1} \nabla^i_{\shortparallel} f^{\pm}_{k+n}(x')) \left(\frac{b^+ - b^-}{2}\right)^k.$$

**Theorem 4.3.** Let  $a>0,\ m\in\mathbb{N}$  with  $m\geq 2,\ and\ 1< p<\infty.$  Suppose that  $f_k^\pm\in W^{m-1-k,p}_{\mathrm{loc}}(\mathbb{R}^{N-1})$  for  $k=0,\ldots,m-2$  and  $f_{m-1}^\pm\in L^{p}_{\mathrm{loc}}(\mathbb{R}^{N-1})$  satisfy

$$\int_{\mathbb{R}^{N-1}} |Q_{i,m,n}(x')|^p dx' < \infty \tag{4.12}$$

for all  $n, i \in \mathbb{N}_0$  with  $0 \le n + i \le m - 1$  and

$$\int\limits_{\mathbb{R}^{N-1}} \int\limits_{B'(0,a)} \frac{|\nabla_{\shortparallel}^{m-k-1} f_k^{\pm}(x'+h') - \nabla_{\shortparallel}^{m-k-1} f_k^{\pm}(x')|^p}{|h'|^{p+N-2}} \, dh' dx' < \infty$$

for all k = 0, ..., m-1. Then there exists  $u \in \dot{W}^{m,p}(\Omega)$  such that  $\text{Tr}(u) = f_0^{\pm}$  and  $\text{Tr}(\partial_N^k u) = f_k^{\pm}$  on  $\Gamma^{\pm}$  for k = 1, ..., m-1, and

$$\int_{\Omega} |\nabla^{m} u(x)|^{p} dx \leq c \sum_{n=0}^{m-1} \sum_{i=0}^{m-1-n} (b^{+} - b^{-})^{(n+i-m)p+1} \int_{\mathbb{R}^{N-1}} |Q_{i,m,n}(x')|^{p} dx' 
+ c \sum_{k=0}^{m-1} \int_{\mathbb{R}^{N-1}} \int_{B'(0,a)} \frac{|\nabla_{\parallel}^{m-k-1} f_{k}^{-}(x'+h') - \nabla_{\parallel}^{m-k-1} f_{k}^{-}(x')|^{p}}{|h'|^{p+N-2}} dh' dx' 
+ c \sum_{k=0}^{m-1} \int_{\mathbb{R}^{N-1}} \int_{B'(0,a)} \frac{|\nabla_{\parallel}^{m-k-1} f_{k}^{+}(x'+h') - \nabla_{\parallel}^{m-k-1} f_{k}^{+}(x')|^{p}}{|h'|^{p+N-2}} dh' dx'$$

for some constant c = c(a, m, N, p) > 0. Moreover, the map  $(f_0^-, \dots, f_{m-1}^-, f_0^+, \dots, f_{m-1}^+) \mapsto u$  is linear.

**Proof.** For simplicity we again take  $b^- = 0$  and set  $b := b^+$ . Without loss of generality, we may assume that 0 < a < b. Proposition 2.1 provides us with a function  $\varphi \in C_c^m(\mathbb{R}^{N-1})$  such that supp  $\varphi \subseteq B'(0, ab^{-1})$  and

$$\int_{\mathbb{R}^{N-1}} \varphi(y') \, dy' = 1 \text{ and } \int_{\mathbb{R}^{N-1}} (y')^{\alpha} \varphi(y') \, dy' = 0$$

for all multi-indices  $\alpha \in \mathbb{N}_0^{N-1}$  with  $1 \leq |\alpha| \leq m$ . We define  $u^-: \Omega \to \mathbb{R}$  via

$$u^{-}(x) := \sum_{k=0}^{m-1} \frac{x_{N}^{k}}{k!} \int_{\mathbb{R}^{N-1}} f_{k}^{-}(y') \varphi_{x_{N}}(x'-y') dy'$$
$$= \sum_{k=0}^{m-1} \frac{x_{N}^{k}}{k!} \int_{\mathbb{R}^{N-1}} f_{k}^{-}(x'x_{N}z') \varphi(z') dz'.$$

We divide the remainder of the proof into several steps.

Step 1 – Computing traces: We claim that  $\operatorname{Tr}(u^-) = f_0^-$  on  $\Gamma^-$  and that  $\operatorname{Tr}(\partial_N^l u^-) = f_l^-$  on  $\Gamma^-$  for  $1 \leq l \leq m-1$ . By standard properties of mollifiers we have that  $\varphi_{x_N} * f_i^- \to f_i^-$  in  $L^p_{\operatorname{loc}}(\mathbb{R}^{N-1})$  as  $x_N \to 0^+$  for all  $i = 0, \ldots, m-1$ . Hence,  $\operatorname{Tr}(u^-) = f_0^-$  on  $\Gamma^-$ . Next we compute  $\partial_N^l u^-$  for  $1 \leq l \leq m$ . We have

$$\partial_{N}^{l} u^{-}(x) = \sum_{k=0}^{m-1} \frac{1}{k!} \sum_{i=0}^{l} {l \choose i} \partial_{N}^{l-i} (x_{N}^{k}) \partial_{N}^{i} \left( \int_{\mathbb{R}^{N-1}} f_{k}^{-}(x'-x_{N}z') \varphi(z') dz' \right)$$

$$= \sum_{k=0}^{m-1} \sum_{i=\max\{0,l-k\}}^{l} c_{i,k,l} x_{N}^{k-l+i} \partial_{N}^{i} \left( \int_{\mathbb{R}^{N-1}} f_{k}^{-}(x'-x_{N}z') \varphi(z') dz' \right),$$

$$(4.13)$$

where  $c_{i,k,l} := \frac{1}{k!} {l \choose i} \frac{k!}{(k-l+i)!}$ . Note that

$$c_{0,l,l} = 1. (4.14)$$

To compute  $\partial_N^i \left( \int_{\mathbb{R}^{N-1}} f_k^-(x'-x_N z') \varphi\left(z'\right) \, dz' \right)$  we distinguish two cases. Case 1: If  $1 \leq i \leq m-1-k$ , then we use the fact that  $f_k^- \in W_{\text{loc}}^{m-1-k,p}(\mathbb{R}^{N-1})$  to see that

$$\partial_{N}^{i} \int_{\mathbb{R}^{N-1}} f_{k}^{-}(x'-x_{N}z')\varphi(z') dz' = \int_{\mathbb{R}^{N-1}} \frac{\partial^{i}}{\partial x_{N}^{i}} \left( f_{k}^{-}(x'-x_{N}z') \right) \varphi(z') dz'$$

$$= \sum_{|\alpha|=i} c_{\alpha} \int_{\mathbb{R}^{N-1}} \partial^{\alpha} f_{k}(x'-x_{N}z')(z')^{\alpha} \varphi(z') dz' = \sum_{|\alpha|=i_{\mathbb{R}^{N-1}}} \int_{|\alpha|=i_{\mathbb{R}^{N-1}}} \partial^{\alpha} f_{k}(y') \psi_{x_{N}}^{\alpha}(x'-y') dy',$$

$$(4.15)$$

where  $\psi^{\alpha}(y') := c_{\alpha}(y')^{\alpha} \varphi(y')$  satisfies

$$\int_{\mathbb{R}^{N-1}} \psi^{\alpha}(y') \, dy' = 0. \tag{4.16}$$

Observe that since  $l-k \le i \le m-1-k$ , this first case only happens if  $l \le m-1$ .

Case 2: If i > m - 1 - k, then we write

$$\begin{split} \partial_{N}^{i} & \int_{\mathbb{R}^{N-1}} f_{k}^{-}(x'-x_{N}z')\varphi(z') \ dz' = \partial_{N}^{i-(m-1-k)} \int_{\mathbb{R}^{N-1}} \frac{\partial^{m-1-k}}{\partial x_{N}^{m-1-k}} \left( f_{k}^{-}(x'-x_{N}z') \right) \varphi(z') \ dz' \\ & = \partial_{N}^{i-(m-1-k)} \sum_{|\beta|=m-1-k} c_{\beta} \int_{\mathbb{R}^{N-1}} \partial^{\beta} f_{k}(x'-x_{N}z')(z')^{\beta} \varphi(z') \ dz' \\ & = \partial_{N}^{i-(m-1-k)} \sum_{|\beta|=m-1-k} c_{\beta} \int_{\mathbb{R}^{N-1}} \partial^{\beta} f_{k}(y') \left( \frac{x'-y'}{x_{N}} \right)^{\beta} \varphi_{x_{N}} (x'-y') \ dy' \\ & = \sum_{|\beta|=m-1-k} c_{\beta} \int_{\mathbb{R}^{N-1}} \partial^{\beta} f_{k}(y') \frac{\partial^{i-(m-1-k)}}{\partial x_{N}^{i-(m-1-k)}} \left[ \left( \frac{x'-y'}{x_{N}} \right)^{\beta} \varphi_{x_{N}} (x'-y') \right] \ dy' \\ & = \sum_{|\beta|=m-1-k} \frac{1}{x_{N}^{i-(m-1-k)}} \int_{\mathbb{R}^{N-1}} \partial^{\beta} f_{k}(y') \psi_{x_{N}}^{\beta,i}(x'-y') \ dy', \end{split}$$

where the last equality follows from Proposition 2.2, and where

$$\int_{\mathbb{D}^{N-1}} \psi^{\beta,i}(y') \, dy' = 0. \tag{4.17}$$

By combining the two cases we can write

$$\begin{split} \partial_N^l u^-(x) &= \sum_{k=0}^{m-1} \sum_{i=\max\{0,l-k\}}^{m-1-k} c_{i,k,l} x_N^{k-l+i} \sum_{|\alpha|=i_{\mathbb{R}^{N-1}}} \int_{0}^{\infty} \partial^{\alpha} f_k(y') \psi_{x_N}^{\alpha}(x'-y') \, dy' \\ &+ x_N^{m-l-1} \sum_{k=0}^{m-1} \sum_{|\beta|=m-1-k_{\mathbb{R}^{N-1}}} \partial^{\beta} f_k(y') \psi_{x_N}^{\beta,k,l}(x'-y') \, dy', \end{split}$$

where  $\psi^0 := \varphi$  and

$$\psi^{\beta,k,l}(y') := \sum_{i=\max\{0,m-k\}}^{l} c_{i,k,l} \psi^{\beta,i}(y').$$

Assume now that  $1 \leq l \leq m-1$ . Then by (4.16) and (4.17),  $\psi_{x_N}^{\alpha} * \partial^{\alpha} f_k \to 0$  if  $\alpha \neq 0$  and  $\psi_{x_N}^{\beta,k,l} * \partial^{\beta} f_k \to 0$  in  $L_{\text{loc}}^p(\mathbb{R}^{N-1})$  as  $x_N \to 0^+$ . On the other hand, if  $\alpha = 0$ , then  $x_N^{k-l} \to 0$  if k > l as  $x_N \to 0^+$ . Hence, the only term in the first term that does not converge to zero is k = l and i = 0. In view of (4.14) and of the fact that  $\psi^0 := \varphi$ , we have that  $\text{Tr}(\partial_N^l u^-) = f_l^-$  on  $\Gamma^-$ .

Step 2 – Derivative estimates: We claim that  $u^- \in \dot{W}^{m,p}(\Omega)$ . We begin by estimating  $\partial_N^m u^-$ . Since Case 1 in Step 1 does not happen when l=m, we can write

$$\partial_N^m u^-(x) = \sum_{k=0}^{m-1} \sum_{|\beta|=m-1-k_m} \int_{N-1} \partial^{\beta} f_k(y') \frac{1}{x_N^N} \psi^{\beta,k,l} \left( \frac{x'-y'}{x_N} \right) dy'.$$

Due to (4.17), we are in a position to apply Proposition 2.3 to conclude that  $\partial_N^m u^- \in L^p(\Omega)$ , with

$$\int\limits_{\Omega} |\partial_{N}^{m} u^{-}(x)|^{p} dx \leq c \int\limits_{\mathbb{R}^{N-1}} \int\limits_{B'(0,a)} \frac{|\nabla_{\parallel}^{m-k-1} f_{k}^{-}(x'+h') - \nabla_{\parallel}^{m-k-1} f_{k}^{-}(x')|^{p}}{|h'|^{p+N-2}} dh' dx'.$$

On the other hand, if  $0 \le l < m$  in Step 1, then for every multi-index  $\gamma = (\gamma', 0)$  with  $|\gamma'| = m - l$  we have

$$\partial^{\gamma} \partial_{N}^{l} u^{-}(x) = \sum_{k=0}^{m-1} \sum_{i=\max\{0,l-k\}}^{m-1-k} c_{i,k,l} x_{N}^{k-l+i} \sum_{|\alpha|=i_{\mathbb{R}^{N-1}}} \int_{\partial^{\alpha} f_{k}(y')} \frac{\partial^{\gamma}}{\partial x^{\gamma}} \left( \psi_{x_{N}}^{\alpha}(x'-y') \right) dy'$$
$$+ x_{N}^{m-l-1} \sum_{k=0}^{m-1} \sum_{|\beta|=m-1-k_{\mathbb{D}^{N-1}}} \int_{\partial^{\beta} f_{k}(y')} \frac{\partial^{\gamma}}{\partial x^{\gamma}} \left( \psi_{x_{N}}^{\beta,k,l}(x'-y') \right) dy'.$$

In the first term for every i < m-k-1 we write  $\gamma = s_i + t_i$ , where  $|s_i| = m-k-1-i$  and  $|t_i| = k-l+i+1$ , and integrate by parts m-k-1-i times to see that

$$\begin{split} \partial^{\gamma} \partial_{N}^{l} u^{-}(x) &= \sum_{k=0}^{m-1} \sum_{i=\max\{0,l-k\}}^{m-1-k} c_{i,k,l} x_{N}^{k-l+i} \sum_{|\alpha|=i_{\mathbb{R}^{N-1}}} \int_{\partial^{\alpha+s_{i}}} f_{k}(y') \frac{\partial^{t_{i}}}{\partial x^{t_{i}}} \left( \psi_{x_{N}}^{\alpha}(x'-y') \right) \, dy' \\ &+ x_{N}^{m-l-1} \sum_{k=0}^{m-1} \sum_{|\beta|=m-1-k_{\mathbb{R}^{N-1}}} \int_{\partial^{\beta}} f_{k}(y') \frac{\partial^{\gamma}}{\partial x^{\gamma}} \left( \psi_{x_{N}}^{\beta,k,l}(x'-y') \right) \, dy'. \end{split}$$

According to Proposition 2.2, we may write

$$\partial^{\gamma} \partial_{N}^{l} u^{-}(x) = \sum_{k=0}^{m-1} \sum_{i=\max\{0,l-k\}}^{m-1-k} c_{i,k,l} \sum_{|\alpha|=i_{\mathbb{R}^{N-1}}} \int_{\alpha^{\alpha+s_{i}}} d^{\alpha+s_{i}} f_{k}(y') \frac{1}{x_{N}^{N}} \psi^{\alpha,t_{i}} \left(\frac{x'-y'}{x_{N}}\right) dy'$$

$$+ \sum_{k=0}^{m-1} \sum_{|\beta|=m-1-k_{\mathbb{R}^{N-1}}} \int_{\alpha^{\alpha}} d^{\alpha} f_{k}(y') \frac{1}{x_{N}^{N}} \psi^{\beta,\gamma} \left(\frac{x'-y'}{x_{N}}\right) dy',$$

where  $\int_{\mathbb{R}^{N-1}} \psi^{\alpha,t_i}(y') dy' = \int_{\mathbb{R}^{N-1}} \psi^{\beta,\gamma}(y') dy' = 0$ . Hence, Proposition 2.3 tells us that  $\partial^{\gamma} \partial_N^l u^- \in L^p(\Omega)$  with

$$\int\limits_{\Omega} |\partial^{\gamma} \partial^{l}_{N} u^{-}(x)|^{p} dx \leq c \int\limits_{\mathbb{R}^{N-1}} \int\limits_{B'(0,a)} \frac{|\nabla^{m-k-1}_{\shortparallel} f^{-}_{k}(x'+h') - \nabla^{m-k-1}_{\shortparallel} f^{-}_{k}(x')|^{p}}{|h'|^{p+N-2}} \, dh' dx'.$$

Thus  $u^- \in \dot{W}^{m,p}(\Omega)$ , as claimed.

Step 3 – Defining  $u^+$  and u: Reasoning as in Steps 1 and 2, we can show that the function  $u^+:\Omega\to\mathbb{R}$  defined by

$$u^{+}(x) := \sum_{k=0}^{m-1} \frac{(b-x_N)^k}{k!} \int_{\mathbb{R}^{N-1}} f_k^{+}(y') \varphi_{b-x_N} (x'-y') dy'$$

belongs to  $\dot{W}^{m,p}(\Omega)$ , obeys the estimate

$$\int\limits_{\Omega} |\nabla^m u^+(x)|^p dx \leq c \sum_{k=0}^{m-1} \int\limits_{\mathbb{R}^{N-1}} \int\limits_{B'(0,a)} \frac{|\nabla^{m-k-1}_{\shortparallel} f^+_k(x'+h') - \nabla^{m-k-1}_{\shortparallel} f^+_k(x')|^p}{|h'|^{p+N-2}} \, dh' dx',$$

and satisfies  $\operatorname{Tr}(u^+) = f_0^+$  on  $\Gamma^+$  and  $\operatorname{Tr}(\partial_N^l u^+) = f_l^+$  on  $\Gamma^+$  for  $1 \le l \le m-1$ .

Now let  $\theta \in C^{\infty}([0,b])$  be such that  $\theta = 1$  in a neighborhood of 0 and  $\theta = 0$  in a neighborhood of b. We then define  $u: \Omega \to \mathbb{R}$  via

$$u(x) := \theta(x_N)u^{-}(x) + (1 - \theta(x_N))u^{+}(x).$$

For every  $1 \le l \le m$  we have that

$$\begin{split} \partial_{N}^{l} u(x) &= \theta(x_{N}) \partial_{N}^{l} u^{-}(x) + (1 - \theta(x_{N})) \partial_{N}^{l} u^{+}(x) \\ &+ \sum_{i=0}^{l} \binom{l}{i} \theta^{(l-i)}(x_{N}) (\partial_{N}^{i} u^{-}(x) - \partial_{N}^{i} u^{+}(x)). \end{split}$$

If  $0 \le l < m$ , then for every multi-index  $\gamma = (\gamma', 0)$  with  $|\gamma'| = m - l$  we have

$$\partial^{\gamma} \partial_{N}^{l} u(x) = \theta(x_{N}) \partial^{\gamma} \partial_{N}^{l} u^{-}(x) + (1 - \theta(x_{N})) \partial^{\gamma} \partial_{N}^{l} u^{+}(x)$$
$$+ \sum_{i=0}^{l} \binom{l}{i} \theta^{(l-i)}(x_{N}) (\partial^{\gamma} \partial_{N}^{i} u^{-}(x) - \partial^{\gamma} \partial_{N}^{i} u^{+}(x))$$

if  $l \geq 1$ , and

$$\partial^{\gamma} u(x) = \theta(x_N) \partial^{\gamma} u^{-}(x) + (1 - \theta(x_N)) \partial^{\gamma} u^{+}(x)$$

if l = 0. Since  $u^{\pm} \in \dot{W}^{m,p}(\Omega)$ , to prove that  $u \in \dot{W}^{m,p}(\Omega)$  it suffices to estimate the lower order terms  $\theta^{(l-i)}\partial^{\gamma}\partial_{N}^{i}(u^{-}-u^{+})$ .

By Taylor's formula applied to  $\partial_N^i u^-(x',\cdot)$  and  $\partial_N^i u^+(x',\cdot)$ , respectively, we may write

$$\partial_N^i u^-(x) = \sum_{k=i}^{l-1} \frac{1}{(k-i)!} f_k^-(x') x_N^{k-i} + \frac{1}{(l-i+1)!} \int_0^{x_N} \partial_N^l u^-(x',s) (x_N - s)^{l-i+1} ds$$

and

$$\partial_N^i u^+(x) = \sum_{k=i}^{l-1} \frac{(-1)^{k-i}}{(k-i)!} f_k^+(x') (b-x_N)^{k-i} - \frac{1}{(l-i+1)!} \int_{x_N}^b \partial_N^l u^+(x',s) (x_N-s)^{l-i+1} ds,$$

where we have used the fact that  $\operatorname{Tr}(u^{\pm}) = f_0^{\pm}$  and  $\operatorname{Tr}(\partial_N^k u^{\pm}) = f_k^{\pm}$  on  $\Gamma^{\pm}$ . Since  $f_k^{\pm} \in W_{\operatorname{loc}}^{m-1-k,p}(\mathbb{R}^{N-1})$  and  $\gamma = (\gamma',0)$  with  $|\gamma'| = m - l \leq m - 1 - k$  for  $k \leq l - 1$ , we can apply  $\partial^{\gamma}$  to both sides of the previous two identities to see that

$$\partial^{\gamma} \partial_{N}^{i} u^{-}(x) = \sum_{k=i}^{l-1} \frac{1}{(k-i)!} \partial^{\gamma} f_{k}^{-}(x') x_{N}^{k-i} + \frac{1}{(l-i+1)!} \int_{0}^{x_{N}} \partial^{\gamma} \partial_{N}^{l} u^{-}(x',s) (x_{N}-s)^{l-i+1} ds$$

and

$$\partial^{\gamma} \partial_{N}^{i} u^{+}(x) = \sum_{k=i}^{l-1} \frac{(-1)^{k-i}}{(k-i)!} \partial^{\gamma} f_{k}^{+}(x') (b-x_{N})^{k-i}$$
$$-\frac{1}{(l-i+1)!} \int_{x_{N}}^{b} \partial^{\gamma} \partial_{N}^{l} u^{+}(x',s) (x_{N}-s)^{l-i+1} ds.$$

Hence,

$$\partial^{\gamma} \partial_{N}^{i}(u^{+}(x) - u^{-}(x)) = \sum_{k=i}^{l-1} \frac{1}{(k-i)!} [(-1)^{k-i} \partial^{\gamma} f_{k}^{+}(x')(b-x_{N})^{k-i} - \partial^{\gamma} f_{k}^{-}(x') x_{N}^{k-i}]$$

$$- \frac{1}{(l-i+1)!} \int_{x_{N}}^{b} \partial^{\gamma} \partial_{N}^{l} u^{+}(x',s) (x_{N} - s)^{l-i+1} ds$$

$$- \frac{1}{(l-i+1)!} \int_{0}^{x_{N}} \partial^{\gamma} \partial_{N}^{l} u^{-}(x',s) (x_{N} - s)^{l-i+1} ds.$$

Now define

$$P_{i,l,\gamma}(x) := \sum_{k=-i}^{l-1} \frac{1}{(k-i)!} [(-1)^{k-i} \partial^{\gamma} f_k^+(x') (b-x_N)^{k-i} - \partial^{\gamma} f_k^-(x') x_N^{k-i}]$$

and

$$Q_{j,l,\gamma}(x') := \sum_{k=0}^{l-1-j} \frac{(-1)^k}{k!} (\partial^{\gamma} f_{k+j}^{\pm}(x') + (-1)^{k+1} \partial^{\gamma} f_{k+j}^{\pm}(x')) \left(\frac{b}{2}\right)^k$$

and note that (4.12) guarantees that  $Q_{j,l,\gamma} \in L^p(\mathbb{R}^{N-1})$ . Using the facts that for  $j = 1, \ldots, l-1$ , with  $j \leq k-i$ ,

$$\partial_N^j((b-x_N)^{k-i}) = (-1)^j \frac{(k-i)!}{(k-i-j)!} (b-x_N)^{k-i-j}, \quad \partial_N^j(x_N^{k-i}) = \frac{(k-i)!}{(k-i-j)!} x_N^{k-i-j},$$

we have that

$$\partial_{N}^{j} P_{i,l,\gamma} \left( x', \frac{b}{2} \right) = \sum_{k=j+i}^{l-1} \frac{1}{(k-i-j)!} [(-1)^{k-i-j} \partial^{\gamma} f_{k}^{+}(x') - \partial^{\gamma} f_{k}^{-}(x')] \left( \frac{b}{2} \right)^{k-i-j}$$

$$= \sum_{n=0}^{l-1-j-i} \frac{1}{n!} [(-1)^{n} \partial^{\gamma} f_{n+j+i}^{+}(x') - \partial^{\gamma} f_{n+j+i}^{-}(x')] \left( \frac{b}{2} \right)^{n} = Q_{j+i,l,\gamma}(x').$$

Also  $P_{i,l,\gamma}\left(x',\frac{b}{2}\right)=Q_{i,l,\gamma}(x')$ . Hence, if we fix  $x'\in\mathbb{R}^{N-1}$  and apply Taylor's formula centered at  $\frac{b}{2}$  to the function  $P_{i,l,\gamma}(x',\cdot)$ , we get

$$P_{i,l,\gamma}(x) = \sum_{j=0}^{k-1} \partial_N^j P_{i,l,\gamma} \left( x', \frac{b}{2} \right) \left( x_N - \frac{b}{2} \right)^j = \sum_{j=0}^{k-1} Q_{j+i,l,\gamma}(x') \left( x_N - \frac{b}{2} \right)^j.$$

In turn, Hölder's inequality and the fact that  $|\theta^{(l-i)}(x_N)| \leq cb^{-(l-i)}$  imply that

$$|\theta^{(l-1)}(x_N)\partial^{\gamma}\partial_N^i(u^+(x) - u^-(x))|^p \le c \sum_{j=0}^{k-1} b^{(j-l+i)p} |Q_{j+i,l,\gamma}(x')|^p$$

$$+ cb^{-1} \int_{x_N}^b |\partial^{\gamma}\partial_N^l u^+(x',s)|^p ds + cb^{-1} \int_0^{x_N} |\partial^{\gamma}\partial_N^l u^-(x',s)|^p ds.$$

Integrating over  $\Omega$  and using Tonelli's theorem then shows that

$$\int_{\Omega} |\theta^{(l-1)}(x_N)\partial^{\gamma}\partial_N^i (u^+(x) - u^-(x))|^p dx \le c \sum_{j=0}^{k-1} b^{(j-l+i)p+1} \int_{\mathbb{R}^{N-1}} |Q_{j+i,l,\gamma}(x')|^p dx' 
+ c \int_{\Omega} |\nabla^m u^+(x)|^p dx + c \int_{\Omega} |\nabla^m u^-(x)|^p dx.$$

This completes the proof.  $\Box$ 

# 5. Traces in general strip-like domains

In this section we consider the case in which  $\Omega$  is as in (1.1). We define

$$\Gamma^{\pm} := \left\{ x \in \mathbb{R}^N \,|\, x_N = \eta^{\pm}(x') \right\}.$$

# 5.1. The case m = 1, p > 1

We begin with the case m=1 and p>1. First we prove the trace estimate, the analog of Theorem 1.2.

**Theorem 5.1.** Let  $\Omega$  be as in (1.1), where  $\eta^{\pm}: \mathbb{R}^{N-1} \to \mathbb{R}$  are Lipschitz continuous functions such that  $\eta^- < \eta^+$ . Set  $L := |\eta^-|_{0,1} + |\eta^+|_{0,1}$ , and let 1 . There exists a unique linear operator

$$\operatorname{Tr}: \dot{W}^{1,p}(\Omega) \to L^p_{\operatorname{loc}}(\partial\Omega)$$

such that the following hold.

- (1)  $\operatorname{Tr}(u) = u \text{ on } \partial\Omega \text{ for all } u \in \dot{W}^{1,p}(\Omega) \cap C^0(\overline{\Omega})$
- (2) There exists a constant c = c(N, p) > 0 such that

$$\int_{\mathbb{R}^{N-1}} \frac{|\operatorname{Tr}(u)(x', \eta^{+}(x')) - \operatorname{Tr}(u)(x', \eta^{-}(x'))|^{p}}{(\eta^{+}(x') - \eta^{-}(x'))^{p-1}} dx' \le c \int_{\Omega} |\partial_{N} u(x)|^{p} dx, \tag{5.1}$$

$$|\operatorname{Tr}(u)(\cdot, \eta^{\pm}(\cdot))|_{\tilde{W}^{1-1/p,p}_{((\eta^{+}-\eta^{-})/(2L))}(\mathbb{R}^{N-1})} \le (1+L)^{p} c \int_{\Omega} |\nabla u(x)|^{p} dx$$
 (5.2)

for all  $u \in \dot{W}^{1,p}(\Omega)$ .

(3) The integration by parts formula

$$\int_{\Omega} u \partial_i \psi \, dx = -\int_{\Omega} \psi \partial_i u \, dx + \int_{\partial \Omega} \psi \operatorname{Tr}(u) \nu_i \, d\mathcal{H}^{N-1}$$

holds for all  $u \in \dot{W}^{1,p}(\Omega)$ , all  $\psi \in C_c^1(\mathbb{R}^N)$ , and all i = 1, ..., N.

**Proof.** We will only prove the second item. The proof of the first and third follow as in the proof of Theorem 1.2. We divide the proof into steps.

Step 1 – Special case of (5.1): Suppose for now that  $\eta^- = 0$  and  $\eta := \eta^+$  and consider  $u \in \dot{W}^{1,p}(\Omega)$ . By Theorem 3.1 and the fundamental theorem of calculus, for  $\mathcal{L}^{N-1}$  a.e.  $x' \in \mathbb{R}^{N-1}$  we have that

$$u(x',\eta(x')) - u(x',0) = \int_{0}^{\eta(x')} \partial_N u(x',x_N) dx_N.$$

It then follows from Hölder's inequality that

$$|u(x',\eta(x')) - u(x',0)|^p \le (\eta(x'))^{p-1} \int_0^{\eta(x')} |\partial_N u(x',x_N)|^p dx_N.$$

By integrating in x' over  $\mathbb{R}^{N-1}$  and using Tonelli's theorem, we then see that

$$\int_{\mathbb{R}^{N-1}} \frac{|u(x', \eta(x')) - u(x', 0)|^p}{(\eta(x'))^{p-1}} dx' \le \int_{U_P} |\partial_N u(x)|^p dx.$$

Hence,

$$\int_{\mathbb{R}^{N-1}} \frac{|\operatorname{Tr}(u)(x', \eta(x')) - \operatorname{Tr}(u)(x', 0)|^p}{(\eta(x'))^{p-1}} dx' \le \int_{\Omega} |\partial_N u(x)|^p dx,$$

which proves (5.1) in the special case in which  $\eta^- = 0$ .

Step 2 – Special case of (5.2): Again suppose  $\eta^- = 0$  and  $\eta = \eta^+$ . Let  $u \in \dot{W}^{1,p}(\Omega)$ . We may suppose, without loss of generality, that  $L := |\eta|_{0,1} \ge 1$ . Let R > 0 and  $M_R \ge 2R + \max_{\overline{B'(0,R)}} \eta$ .

For  $x' \in B'(0,R)$  we make two observations, both of which use the fact that  $L \geq 1$ . First,  $B'(x', \eta(x')/2L) \subset B'(0, M_R/2)$ . Second, if  $h' \in B'(0, \eta(x')/2L)$  and  $0 < x_N < \eta(x')/(2L)$ , then by the Lipschitz continuity of  $\eta$ ,

$$\eta(x'+h') \ge \eta(x') - L|h'| > \frac{1}{2}\eta(x') > x_N.$$

With these observations in hand, we may use Theorem 3.1 and the fundamental theorem of calculus for  $\mathcal{L}^{N-1}$  a.e.  $x' \in B'(0,R)$ ,  $h' \in B'(0,\eta(x')/2L)$  and  $0 < x_N < |h'| < \eta(x')/(2L)$  to see that

$$u(x' + h', 0) - u(x', 0) = u(x' + h', x_N) - u(x', x_N) - \int_0^{x_N} \partial_N u(x' + h', s) ds$$
$$- \int_0^{x_N} \partial_N u(x', s) ds$$

$$=\int\limits_0^1 \nabla_{\shortparallel} u(x'+sh',x_N) \cdot h' ds - \int\limits_0^{x_N} \partial_N u(x'+h',s) \, ds$$
 
$$-\int\limits_0^{x_N} \partial_N u(x',s) \, ds.$$

In turn, we may estimate

$$|u(x'+h',0) - u(x',0)| \le |h'| \int_{0}^{1} |\nabla u(x'+sh',x_N)| ds + \int_{0}^{|h'|} |\nabla u(x'+h',s)| ds$$
$$+ \int_{0}^{|h'|} |\nabla u(x',s)| ds.$$

By averaging both sides in  $x_N$  over the interval (0, |h'|) and raising to the power p we then find that

$$|u(x'+h',0) - u(x',0)|^p \le 3^{p-1} \left( \int_0^{|h'|} \int_0^1 |\nabla u(x'+sh',x_N)| \, ds dx_N \right)^p$$

$$+ 3^{p-1} \left( \int_0^{|h'|} |\nabla u(x'+h',s)| \, ds \right)^p + 3^{p-1} \left( \int_0^{|h'|} |\nabla u(x',s)| \, ds \right)^p.$$

We now divide both sides by  $|h'|^{p+N-2}$ , integrate in h' over  $B'(0, \eta(x')/2L)$  and in x' over B'(0, R), and use Tonelli's theorem to arrive at the estimate

$$\int_{B'(0,R)} \int_{B'(0,\eta(x')/2L)} \frac{|u(x'+h',0)-u(x',0)|^p}{|h'|^{p+N-2}} dh' dx'$$

$$\leq 3^{p-1} \int_{B'(0,R)} \int_{B'(0,\eta(x')/2L)} \frac{1}{|h'|^{p+N-2}} \left( \int_{0}^{1} \int_{0}^{|h'|} |\nabla u(x'+sh',x_N)| dx_N ds \right)^p dh' dx'$$

$$+ 3^{p-1} \int_{B'(0,R)} \int_{B'(0,\eta(x')/2L)} \frac{1}{|h'|^{p+N-2}} \left( \int_{0}^{|h'|} |\nabla u(x'+h',s)| ds \right)^p dh' dx'$$

$$+3^{p-1} \int\limits_{B'(0,R)} \int\limits_{B'(0,\eta(x')/2L)} \frac{1}{|h'|^{p+N-2}} \left( \int\limits_{0}^{|h'|} |\nabla u(x',s)| \, ds \right)^p dh' dx'$$

$$=: 3^{p-1}I + 3^{p-1}II + 3^{p-1}III.$$

By Hölder's inequality,

$$\int_{0}^{1} \int_{0}^{|h'|} |\nabla u(x'+sh',x_N)| \, dx_N ds \le \left( \int_{0}^{1} \left( \int_{0}^{|h'|} |\nabla u(x'+sh',x_N)| \, dx_N \right)^p ds \right)^{1/p}.$$

In turn, by Tonelli's theorem and using spherical coordinates  $h' = r\sigma'$ , where r > 0 and  $\sigma' \in \mathbb{S}^{N-2}$ , and the change of variables  $y' = x' + sr\sigma'$ , we may estimate the first term by

$$\begin{split} I &\leq \int\limits_{0}^{1} \int\limits_{\mathbb{S}^{N-2}} \int\limits_{B'(0,R)} \int\limits_{0}^{\eta(x')/2L} \frac{1}{r^{p}} \left( \int\limits_{0}^{r} |\nabla u(x'+sr\sigma',x_{N})| \, dx_{N} \right)^{p} dr dx' d\mathcal{H}^{N-2}(\sigma') ds \\ &= \int\limits_{0}^{1} \int\limits_{\mathbb{S}^{N-2}} \int\limits_{0}^{\infty} \int\limits_{B'(0,R)} \chi_{(0,\eta(x')/2L)}(r) \frac{1}{r^{p}} \\ &\times \left( \int\limits_{0}^{r} |\nabla u(x'+sr\sigma',x_{N})| \, dx_{N} \right)^{p} dx' dr d\mathcal{H}^{N-2}(\sigma') ds \\ &\leq \beta_{N-1} \int\limits_{0}^{\infty} \int\limits_{B'(0,M_{R})} \chi_{(0,\eta(y'))}(r) \frac{1}{r^{p}} \left( \int\limits_{0}^{r} |\nabla u(y',x_{N})| \, dx_{N} \right)^{p} dy' dr \\ &= \beta_{N-1} \int\limits_{B'(0,M_{R})} \int\limits_{0}^{\eta(y')} \frac{1}{r^{p}} \left( \int\limits_{0}^{r} |\nabla u(y',x_{N})| \, dx_{N} \right)^{p} dr dy', \end{split}$$

where here we used the facts that  $\eta(x')/2L < \eta(x'+sh')$  for  $x' \in B'(0,R)$  and  $|h'| \leq \eta(x')/2L$  and that  $|x'+sr\sigma'| < R+r \leq R+\eta(x')/2L \leq M_R$ . Applying Hardy's inequality (see, for instance, Theorem C.41 in [23]) to the right-hand side and using Tonelli's theorem yields the bound

$$I \leq \frac{\beta_{N-1}p^p}{(p-1)^p} \int_{B'(0,M_R)} \int_0^{\eta(y')} |\nabla u(y',x_N)|^p dx_N dy' \leq \frac{\beta_{N-1}p^p}{(p-1)^p} \int_{\Omega} |\nabla u(y)|^p dy.$$

Similarly,

$$\begin{split} II &= \int\limits_{\mathbb{S}^{N-2}} \int\limits_{B'(0,R)} \int\limits_{0}^{\eta(x')/2L} \frac{1}{r^{p}} \left( \int\limits_{0}^{r} |\nabla u(x'+r\sigma',s)| \, ds \right)^{p} dr dx' d\mathcal{H}^{N-2}(\sigma') \\ &= \int\limits_{\mathbb{S}^{N-2}} \int\limits_{0}^{\infty} \int\limits_{B'(0,R)} \chi_{(0,\eta(x')/2L)}(r) \frac{1}{r^{p}} \left( \int\limits_{0}^{r} |\nabla u(x'+r\sigma',s)| \, ds \right)^{p} dx' dr d\mathcal{H}^{N-2}(\sigma') \\ &\leq \beta_{N-1} \int\limits_{0}^{\infty} \int\limits_{B'(0,M_{R})} \chi_{(0,\eta(y'))}(r) \frac{1}{r^{p}} \left( \int\limits_{0}^{r} |\nabla u(y',s)| \, ds \right)^{p} dx' dr \\ &= \beta_{N-1} \int\limits_{0}^{\eta(y')} \int\limits_{0}^{\eta(y')} \frac{1}{r^{p}} \left( \int\limits_{0}^{r} |\nabla u(y',s)| \, ds \right)^{p} dr dx'. \end{split}$$

Again by Hardy's inequality and Tonelli's theorem, we get

$$II \le \frac{\beta_{N-1}p^p}{(p-1)^p} \int\limits_{\Omega} |\nabla u(y)|^p dy.$$

The term III is even simpler and can be bounded from above by the same expression. Hence, we arrive at the bound

$$\int_{B'(0,R)} \int_{B'(0,\eta(x')/2L)} \frac{|u(x'+h',0)-u(x',0)|^p}{|h'|^{p+N-2}} dh' dx' \le 3^p \frac{\beta_{N-1} p^p}{(p-1)^p} \int_{\Omega} |\nabla u(y)|^p dy.$$

Letting  $R \to \infty$  and using the Lebesgue monotone convergence theorem gives (5.2) in this special case.

**Step 3** – **General case:** Assume now that  $\Omega$  is as in (1.1) and let

$$U = \{ y \in \mathbb{R}^N \mid 0 < y_N < \eta^+(y') - \eta^-(y') \}.$$

Consider the Lipschitz transformation  $\Phi: \Omega \to U$  given by

$$\Phi(x) = (x', x_N - \eta^{-}(x')).$$

The function  $\Phi$  is invertible with Lipschitz inverse  $\Phi^{-1}: U \to \Omega$  given by

$$\Phi^{-1}(y) = (y', y_N + \eta^{-}(y')).$$

Moreover, det  $J_{\Phi^{-1}}(y) = 1$  at each point  $y \in U$  where  $\Phi^{-1}$  is differentiable. Given  $u \in \dot{W}^{1,p}(\Omega)$ , we define  $w : U \to \mathbb{R}$  via

$$w(y) = u(\Phi^{-1}(y)) = u(y', y_N + \eta^{-}(y')).$$

Then we compute

$$\frac{\partial w}{\partial y_i}(y) = \frac{\partial u}{\partial x_i}(y', y_N + \eta^-(y')) + \frac{\partial u}{\partial x_N}(y', y_N + \eta^-(y')) \frac{\partial \eta^-}{\partial y_i}(y')$$
for  $i = 1, \dots, N - 1$  and
$$\frac{\partial w}{\partial y_N}(y) = \frac{\partial u}{\partial x_N}(y', y_N + \eta^-(y')),$$

which shows that  $w \in \dot{W}^{1,p}(U)$ . Hence, by Step 1,

$$\int_{\mathbb{R}^{N-1}} \frac{|\operatorname{Tr}(u)(x', \eta^{+}(x')) - \operatorname{Tr}(u)(x', \eta^{-}(x'))|^{p}}{(\eta^{+}(x') - \eta^{-}(x'))^{p-1}} dx'$$

$$= \int_{\mathbb{R}^{N-1}} \frac{|\operatorname{Tr}(w)(x', \eta^{+}(x') - \eta^{-}(x')) - \operatorname{Tr}(w)(x', 0)|^{p}}{(\eta^{+}(x') - \eta^{-}(x'))^{p-1}} dx'$$

$$\leq \int_{U} |\partial_{N} w(y)|^{p} dy = \int_{U} |\partial_{N} u(\Phi^{-1}(y))|^{p} dy = \int_{\Omega} |\partial_{N} u(x)|^{p} dx,$$

where we used the fact that det  $J_{\Phi^{-1}}(y) = 1$ . This proves (5.1) in the general case. Similarly, Step 2 shows that

$$\int_{\mathbb{R}^{N-1}} \int_{B'(0,(\eta^{+}(x')-\eta^{-}(x'))/(2L))} \frac{|\operatorname{Tr}(u)(x'+h',\eta^{-}(x'+h)) - \operatorname{Tr}(u)(x',\eta^{-}(x'))|^{p}}{|h'|^{p+N-2}} dh' dx'$$

$$= \int_{\mathbb{R}^{N-1}} \int_{B'(0,(\eta^{+}(x')-\eta^{-}(x'))/(2L))} \frac{|\operatorname{Tr}(w)(x'+h',0) - \operatorname{Tr}(w)(x',0)|^{p}}{|h'|^{p+N-2}} dh' dx'$$

$$\leq 3^{p} \frac{\beta_{N-1}p^{p}}{(p-1)^{p}} \int_{U} |\nabla w(y)|^{p} dy \leq (1+L)^{p} (2N)^{1/2} \frac{\beta_{N-1}(3p)^{p}}{(p-1)^{p}} \int_{\Omega} |\nabla u(x)|^{p} dx.$$

This proves (5.2) in the general case for the lower trace. The analogous estimate for  $\text{Tr}(u)(\cdot, \eta^+(\cdot))$  can be obtained by flattening the top and arguing similarly. We omit the details for the sake of brevity.  $\square$ 

**Remark 5.2.** When  $\eta^+ - \eta^-$  is either unbounded or vanishes at infinity, we do not know if the identity (1.8) holds.

Remark 5.3. In Step 1 we could have written instead

$$v(x'+h',0) - v(x',0) = v(x'+h',0) - v(x',|h'|) + v(x',|h'|) - v(x',0)$$

$$= \int_{0}^{1} \nabla v((x',|h'|) + s(h',-|h'|)) \cdot (h',-|h'|) ds$$

$$+ \int_{0}^{|h'|} \partial_{N} v(x'+h',s) ds.$$

This would have led to the better estimate

$$\int\limits_{\mathbb{R}^{N-1}} \int\limits_{B'(0,\eta(x')/L)} \frac{|\operatorname{Tr}(u)(x'+h',0)-\operatorname{Tr}(u)(x',0)|^p}{|h'|^{p+N-2}} dh' dx' \leq c(N,p) \int\limits_{\Omega} |\nabla u(x)|^p dx.$$

However, the proof in Step 1 is simpler to extend to higher order Sobolev spaces.

Next we prove the corresponding lifting result, which is the analog of Theorem 1.4.

**Theorem 5.4.** Let  $\Omega$  be as in (1.1), where  $\eta^{\pm}: \mathbb{R}^{N-1} \to \mathbb{R}$  are Lipschitz continuous functions, with  $\eta^{-} < \eta^{+}$  and  $L := |\eta^{-}|_{0,1} + |\eta^{+}|_{0,1}$ . Let 0 < a < 1 and  $1 . Suppose that <math>f^{\pm} \in L^{p}_{loc}(\mathbb{R}^{N-1})$  satisfy

$$\int_{\mathbb{R}^{N-1}} \frac{|f^{+}(x') - f^{-}(x')|^{p}}{(\eta^{+}(x') - \eta^{-}(x'))^{p-1}} dx' < \infty$$
(5.3)

and

$$|f^{-}|_{\tilde{W}_{(a(\eta^{+}-\eta^{-}))}^{1-1/p,p}(\mathbb{R}^{N-1})} < \infty, \quad |f^{+}|_{\tilde{W}_{(a(\eta^{+}-\eta^{-}))}^{1-1/p,p}(\mathbb{R}^{N-1})} < \infty.$$
 (5.4)

Then there exists  $u \in \dot{W}^{1,p}(\Omega)$  such that  $\text{Tr}(u)(x', \eta^{\pm}(x')) = f^{\pm}(x')$  for  $x' \in \mathbb{R}^{N-1}$ , and

$$\int_{\Omega} |\nabla u(x)|^p dx \le c(1+L)^p \int_{\mathbb{R}^{N-1}} \frac{|f^+(x') - f^-(x')|^p}{(\eta^+(x') - \eta^-(x'))^{p-1}} dx' 
+ c(1+L)^p |f^-|_{\tilde{W}_{(a(n^+-n^-))}^{(n-1/p,p)}(\mathbb{R}^{N-1})} + c(1+L)^p |f^+|_{\tilde{W}_{(a(n^+-n^-))}^{(n-1/p,p)}(\mathbb{R}^{N-1})}^p$$

for some constant c = c(a, N, p) > 0. Moreover, the map  $(f^-, f^+) \mapsto u$  is linear.

**Proof.** We divide the proof into steps.

Step 1 – The case  $\eta^- = 0$ : Assume first that  $\eta^- = 0$  and  $\eta := \eta^+ > 0$ . Given  $0 < b \le a$ , let  $\varphi \in C_c^{\infty}(\mathbb{R}^{N-1})$  be a nonnegative function such that  $\int_{\mathbb{R}^{N-1}} \varphi(y') \, dy' = 1$  and supp  $\varphi \subseteq B'(0,b)$ . Define  $u^- : \Omega \to \mathbb{R}$  via

$$u^{-}(x) := (\varphi_{x_N} * f^{-})(x') = \frac{1}{x_N^{N-1}} \int_{\mathbb{R}^{N-1}} f^{-}(y') \varphi\left(\frac{x' - y'}{x_N}\right) dy'.$$

As in the proof of Theorem 1.4, for every i = 1, ..., N, we have that

$$|\partial_i u^-(x)|^p \le \frac{c}{x_N^{N+p-1}} \int_{B'(x',x_Nb)} |f^-(y') - f^-(x')|^p dy'.$$

Integrating both sides over  $\Omega$  and using Tonelli's theorem shows that

$$\int_{\Omega} |\partial_{i}u^{-}(x)|^{p} dx \leq c \int_{\mathbb{R}^{N-1}} \int_{0}^{\eta(x')} \frac{1}{x_{N}^{N+p-1}} \int_{B'(x',x_{N}b)} |f^{-}(y') - f^{-}(x')|^{p} dy' dx_{N} dx'$$

$$= c \int_{\mathbb{R}^{N-1}} \int_{B'(x',b\eta(x'))} |f^{-}(y') - f^{-}(x')|^{p} \int_{b^{-1}|x'-y'|}^{\eta(x')} \frac{1}{x_{N}^{N+p-1}} dx_{N} dy' dx'$$

$$\leq c \int_{\mathbb{R}^{N-1}} \int_{B'(x',b\eta(x'))} \frac{|f^{-}(y') - f^{-}(x')|^{p}}{|x' - y'|^{N+p-2}} dy' dx'.$$

This shows that  $u^- \in \dot{W}^{1,p}(\Omega)$ . Moreover, since by standard properties of mollifiers  $\varphi_{x_N} * f^- \to f^-$  in  $L^p_{loc}(\mathbb{R}^{N-1})$  as  $x_N \to 0^+$ , we have that  $Tr(u^-)(x',0) = f^-(x')$  for  $x' \in \mathbb{R}^{N-1}$ .

Step 2 – The general case Assume now that  $\Omega$  is as in (1.1) and let U and  $\Phi$  be as in Step 2 of the proof of Theorem 5.1. Let  $v^- \in W^{1,p}(U)$  be the function constructed in the previous step with  $\text{Tr}(v^-)(y',0) = f^-(y')$  for  $y' \in \mathbb{R}^{N-1}$ . Set  $u^- : \Omega \to \mathbb{R}$  via

$$u^{-}(x) := v^{-}(\Phi(x)) = v^{-}(x', x_N - \eta^{-}(x')).$$

Then  $\text{Tr}(u^-)(x', \eta^-(x')) = \text{Tr}(v^-)(x', 0) = f^-(x')$  for  $x' \in \mathbb{R}^{N-1}$ , and

$$\frac{\partial u^{-}}{\partial x_{i}}(x) = \frac{\partial v^{-}}{\partial y_{i}}(x', x_{N} - \eta^{-}(x')) - \frac{\partial v^{-}}{\partial y_{N}}(x', x_{N} - \eta^{-}(x'))\frac{\partial \eta^{-}}{\partial x_{i}}(x')$$

for 
$$i = 1, ..., N - 1$$
, and

$$\frac{\partial u^{-}}{\partial x_{N}}(x) = \frac{\partial v^{-}}{\partial y_{N}}(x', x_{N} - \eta^{-}(x')).$$

Then Step 1 allows us to bound

$$\int_{\Omega} |\partial_{i}u^{-}(x)|^{p} dx \leq c(1+L)^{p} \int_{\Omega} |\nabla_{y}v^{-}(\Phi(x))|^{p} dx = c(1+L)^{p} \int_{U} |\nabla_{y}v^{-}(y)|^{p} dy$$

$$\leq c(1+L)^{p} \int_{\mathbb{R}^{N-1}} \int_{B'(x',(p^{+}(x')-p^{-}(x'))b)} \frac{|f^{-}(y')-f^{-}(x')|^{p}}{|x'-y'|^{N+p-2}} dy' dx',$$

and

$$\int_{\Omega} |\partial_N u^-(x)|^p dx = \int_{\Omega} |\partial_N v^-(\Phi(x))|^p dx = \int_{U} |\partial_N v^-(y)|^p dy$$

$$\leq c \int_{\mathbb{R}^{N-1}} \int_{B'(x',(\eta^+(x')-\eta^-(x'))b)} \frac{|f^-(y')-f^-(x')|^p}{|x'-y'|^{N+p-2}} \, dy' dx',$$

which in particular means that  $u^- \in \dot{W}^{1,p}(\Omega)$ .

Arguing similarly, we can construct a function  $u^+ \in \dot{W}^{1,p}(\Omega)$  such that  $\operatorname{Tr} u^+(x',\eta^+(x')) = f^+(x')$  for  $x' \in \mathbb{R}^{N-1}$  and which obeys the estimates

$$\int_{\Omega} |\partial_i u^+(x)|^p dx \le c(1+L)^p \int_{\mathbb{R}^{N-1}} \int_{B'(x',(\eta^+(x')-\eta^-(x'))b)} \frac{|f^+(y')-f^+(x')|^p}{|x'-y'|^{N+p-2}} dy' dx'$$

and

$$\int_{\Omega} |\partial_N u^+(x)|^p dx \le c \int_{\mathbb{R}^{N-1}} \int_{B'(x',(\eta^+(x')-\eta^-(x'))b)} \frac{|f^+(y')-f^+(x')|^p}{|x'-y'|^{N+p-2}} dy' dx'.$$

Consider now a function  $\vartheta \in C^{\infty}([0,1])$  such that  $\vartheta = 1$  in  $[0,\delta]$  and  $\vartheta = 0$  in  $[1-\delta,1]$ , and define  $\theta : \Omega \to \mathbb{R}$  via

$$\theta(x) = \vartheta\left(\frac{x_N - \eta^-(x')}{\eta^+(x') - \eta^-(x')}\right).$$

We then define the function  $u:\Omega\to\mathbb{R}$  via

$$u(x) = \theta(x)u^{-}(x) + (1 - \theta(x))u^{+}(x).$$

Then for  $i = 1, \ldots, N$ ,

$$\partial_i u(x) = \partial_i \theta(x) (u^-(x) - u^+(x)) + \theta(x) \partial_i u^-(x) + (1 - \theta(x)) \partial_i u^+(x).$$

From this and the fact that  $u^{\pm} \in \dot{W}^{1,p}(\Omega)$  we see that in order to prove that  $u \in \dot{W}^{1,p}(\Omega)$  we must only prove that  $\partial_i \theta(u^- - u^+) \in L^p(\Omega)$ .

For  $i = 1, \ldots, N - 1$ , we compute

$$\partial_{i}\theta(x) = \vartheta'\left(\frac{x_{N} - \eta^{-}(x')}{\eta^{+}(x') - \eta^{-}(x')}\right) \times \left[\frac{-\partial_{i}\eta^{-}(x')}{\eta^{+}(x') - \eta^{-}(x')} - \frac{(x_{N} - \eta^{-}(x'))(\partial_{i}\eta^{+}(x') - \partial_{i}\eta^{-}(x'))}{(\eta^{+}(x') - \eta^{-}(x'))^{2}}\right],$$

while for i = N we compute

$$\partial_N \theta(x) = \vartheta' \left( \frac{x_N - \eta^-(x')}{\eta^+(x') - \eta^-(x')} \right) \frac{1}{\eta^+(x') - \eta^-(x')}.$$

Hence, for  $x \in \Omega$ ,

$$|\nabla \theta(x)| \le \frac{c(1+L)}{\eta^+(x') - \eta^-(x')}$$

for some constant  $c = c(N, \delta) > 0$ . By the fundamental theorem of calculus, which can be applied thanks to Theorem 3.1, we have that

$$u^{-}(x) = f^{-}(x') + \int_{\eta^{-}(x')}^{x_N} \partial_N u^{-}(x', s) ds$$

and

$$u^{+}(x) = f^{+}(x') - \int_{-T_{N}}^{\eta^{+}(x')} \partial_{N} u^{+}(x', s) ds.$$

Hence,

$$|u^{+}(x) - u^{-}(x)| \le |f^{+}(x') - f^{-}(x')| + \int_{\eta^{-}(x')}^{\eta^{+}(x')} |\partial_{N}u^{-}(x',s)| \, ds + \int_{\eta^{-}(x')}^{\eta^{+}(x')} |\partial_{N}u^{+}(x',s)| \, ds.$$

In turn, we may use Hölder's inequality to bound

$$|u^{+}(x) - u^{-}(x)|^{p} \leq c|f^{+}(x') - f^{-}(x')|^{p}$$

$$+ c(\eta^{+}(x') - \eta^{-}(x'))^{p-1} \int_{\eta^{-}(x')}^{\eta^{+}(x')} (|\partial_{N}u^{-}(x',s)|^{p} + |\partial_{N}u^{+}(x',s)|^{p}) ds,$$

and it follows that

$$\begin{aligned} |\partial_{i}\theta(x)(u^{+}(x) - u^{-}(x))|^{p} &\leq c(1+L)^{p} \frac{|(u^{+}(x) - u^{-}(x))|^{p}}{(\eta^{+}(x') - \eta^{-}(x'))^{p}} \\ &\leq c(1+L)^{p} \frac{|f^{+}(x') - f^{-}(x')|^{p}}{(\eta^{+}(x') - \eta^{-}(x'))^{p}} \\ &+ \frac{c(1+L)^{p}}{\eta^{+}(x') - \eta^{-}(x')} \int_{\eta^{-}(x')}^{\eta^{+}(x')} (|\partial_{N}u^{-}(x',s)|^{p} + |\partial_{N}u^{+}(x',s)|^{p}) ds. \end{aligned}$$

Integrating both sides over  $\Omega$  and using Tonelli's theorem gives

$$\int_{\Omega} |\partial_{i}\theta(x)(u^{+}(x) - u^{-}(x))|^{p} dx \leq c(1+L)^{p} \int_{\mathbb{R}^{N-1}} \frac{|f^{+}(x') - f^{-}(x')|^{p}}{(\eta^{+}(x') - \eta^{-}(x'))^{p-1}} dx' + c(1+L)^{p} \int_{\Omega} (|\partial_{N}u^{-}(x)|^{p} + |\partial_{N}u^{+}(x)|^{p}) dx.$$

Thus  $u \in \dot{W}^{1,p}(\Omega)$ , and the desired estimate follows readily from this and the above analysis.  $\square$ 

# 5.2. The case $m \ge 2, p > 1$

Finally, in this subsection we consider the case  $m \ge 2$  and p > 1. For  $1 \le n \le m-1$ , we define

$$\operatorname{Tr}\left(\frac{\partial^n u}{\partial \nu^n}\right) := \sum_{|\alpha|=n} \frac{1}{\alpha!} \operatorname{Tr}(\partial^\alpha u) \nu^\alpha.$$

We will study the linear mapping

$$u \in W^{m,p}(\Omega) \mapsto \operatorname{Tr}_m(u) := \left(\operatorname{Tr}(u), \operatorname{Tr}\left(\frac{\partial u}{\partial \nu}\right), \cdots, \operatorname{Tr}\left(\frac{\partial^{m-1} u}{\partial \nu^{m-1}}\right)\right).$$
 (5.5)

We begin with the case m=2.

**Theorem 5.5.** Let  $\Omega$  be as in (1.1), where  $\eta^{\pm}: \mathbb{R}^{N-1} \to \mathbb{R}$  are Lipschitz continuous functions, with  $\eta^{-} < \eta^{+}$  and  $L := |\eta^{-}|_{0,1} + |\eta^{+}|_{0,1}$ . Let 1 . Then there exists a constant <math>c = c(N, p) > 0 such that for every  $u \in \dot{W}^{2,p}(\Omega)$  we have the estimates

$$\sum_{i=1}^{N} \int_{\mathbb{R}^{N-1}} \frac{|\operatorname{Tr}(\partial_{i}u)(x', \eta^{+}(x')) - \operatorname{Tr}(\partial_{i}u)(x', \eta^{-}(x'))|^{p}}{(\eta^{+}(x') - \eta^{-}(x'))^{p-1}} dx \le c \int_{\Omega} |\nabla^{2}u(x)|^{p} dx,$$

$$\int_{\mathbb{R}^{N-1}} \frac{\left| \sum_{k=0}^{1} \left( \text{Tr}(\partial_{N}^{k} u)(x', \eta^{+}(x')) + (-1)^{k+1} \text{Tr}(\partial_{N}^{k} u)(x', \eta^{-}(x')) \right) \left( \frac{\eta^{+}(x') - \eta^{-}(x')}{2} \right)^{k} \right|^{p}}{(\eta^{+}(x') - \eta^{-}(x'))^{2p-1}} dx'$$

$$\leq c \int_{\Omega} |\nabla^{2} u(x)|^{p} dx,$$

and

$$\sum_{i=1}^{N} \int_{\mathbb{R}^{N-1}} \int_{B'(0,(\eta^{+}(x')-\eta^{-}(x'))/(2L))} \frac{|\operatorname{Tr}(\partial_{i}u)(x'+h',\eta^{\pm}(x'+h)) - \operatorname{Tr}(\partial_{i}u)(x',\eta^{\pm}(x'))|^{p}}{|h'|^{p+N-2}} dh' dx' \\
\leq (1+L)^{p} c \int_{\Omega} |\nabla^{2}u(x)|^{p} dx.$$

**Proof.** Since  $\partial_i u \in \dot{W}^{1,p}(\Omega)$ , the first and third inequalities follow by applying Theorem 5.1 to  $\partial_i u$ . It remains to prove the second inequality.

For  $\mathcal{L}^{N-1}$  a.e.  $x' \in \mathbb{R}^{N-1}$  Theorem 3.1 allows us to use the identity (2.10) applied to the function  $u(x', \cdot + \eta^-(x'))$  with  $b = \eta^+(x') - \eta^-(x')$  in order to compute

$$u(x', \eta^{+}(x')) - u(x', \eta^{-}(x')) - (\partial_{N}u(x', \eta^{+}(x')) + \partial_{N}u(x', \eta^{-}(x')))\frac{\eta^{+}(x') - \eta^{-}(x')}{2}$$

$$= \int_{0}^{\eta^{+}(x') - \eta^{-}(x')} \partial_{N}^{2}u(x', t + \eta^{-}(x')) \left(\frac{\eta^{+}(x') - \eta^{-}(x')}{2} - t\right) dt.$$

From this we estimate

$$|u(x', \eta^{+}(x')) - u(x', \eta^{-}(x')) - (\partial_{N}u(x', \eta^{+}(x')) + \partial_{N}u(x', \eta^{-}(x'))) \frac{\eta^{+}(x') - \eta^{-}(x')}{2}$$

$$\leq \frac{\eta^{+}(x') - \eta^{-}(x')}{2} \int_{0}^{\eta^{+}(x') - \eta^{-}(x')} |\partial_{N}^{2}u(x', t + \eta^{-}(x'))| dt$$

$$= \frac{\eta^{+}(x') - \eta^{-}(x')}{2} \int_{\eta^{-}(x')}^{\eta^{+}(x')} |\partial_{N}^{2}u(x', s)| ds,$$

where in the second equality we have made the change of variables  $s = t + \eta^{-}(x')$ . We then apply Hölder's inequality to see that

$$\left| u(x', \eta^{+}(x')) - u(x', \eta^{-}(x')) - (\partial_{N} u(x', \eta^{+}(x')) + \partial_{N} u(x', \eta^{-}(x'))) \frac{\eta^{+}(x') - \eta^{-}(x')}{2} \right|^{p}$$

$$\leq \frac{(\eta^{+}(x') - \eta^{-}(x'))^{2p-1}}{2} \int_{\eta^{-}(x')}^{\eta^{+}(x')} |\partial_{N}^{2} u(x', s)|^{p} ds.$$

We then divide by  $(\eta^+(x') - \eta^-(x'))^{2p-1}$ , integrate over  $x' \in \mathbb{R}^{N-1}$ , and use Tonelli's theorem to arrive at the bound

$$\int_{\mathbb{R}^{N-1}} \frac{\left| u(x', \eta^{+}(x')) - u(x', \eta^{-}(x')) - (\partial_{N} u(x', \eta^{+}(x')) + \partial_{N} u(x', \eta^{-}(x'))) \frac{\eta^{+}(x') - \eta^{-}(x')}{2} \right|^{p}}{(\eta^{+}(x') - \eta^{-}(x'))^{2p-1}} dx'$$

$$\leq \int_{U_{n}} |\partial_{N}^{2} u(x)|^{p} dx,$$

which is the desired second estimate.  $\Box$ 

Remark 5.6. We have not been able to prove the extension of Theorem 1.10 for domains of the form (1.1), even assuming that  $\eta^{\pm}$  are more regular. If we follow the strategy of our proof of Theorem 5.4 and consider first the case in which  $\eta^{-}=0$  and  $\eta=\eta^{+}$ , then the desired function  $v^{-}$  has the form (see the proof of Theorem 1.10)

$$v^{-}(x) := \int_{\mathbb{R}^{N-1}} [f_0^{-}(y') + f_1^{-}(y')x_N] \varphi_{x_N} (x' - y') dy'.$$

However, to return to the general case (1.1) one should define  $u^-:\Omega\to\mathbb{R}$  via

$$u^{-}(x) := v^{-}(x', x_N - \eta^{-}(x')).$$

Then for i, j = 1, ..., N - 1,

$$\begin{split} \frac{\partial^2 u^-}{\partial x_j \partial x_i}(x) &= \frac{\partial^2 v^-}{\partial y_j \partial y_i}(x', x_N - \eta^-(x')) - \frac{\partial^2 v^-}{\partial y_N \partial y_i}(x', x_N - \eta^-(x')) \frac{\partial \eta^-}{\partial x_j}(x') \\ &- \frac{\partial^2 v^-}{\partial y_j \partial y_N}(x', x_N + \eta^-(x')) \frac{\partial \eta^-}{\partial x_i}(x') + \frac{\partial^2 v^-}{\partial y_N^2}(x', x_N - \eta^-(x')) \frac{\partial \eta^-}{\partial x_i}(x') \frac{\partial \eta^-}{\partial x_j}(x') \\ &- \frac{\partial v^-}{\partial y_N}(x', x_N - \eta^-(x')) \frac{\partial^2 \eta^-}{\partial x_j \partial x_i}(x'), \end{split}$$

while

$$\begin{split} \frac{\partial^2 u^-}{\partial x_j \partial x_N}(x) &= \frac{\partial^2 v^-}{\partial y_j \partial y_N}(x', x_N - \eta^-(x')) - \frac{\partial^2 v^-}{\partial y_N^2}(x', x_N - \eta^-(x')) \frac{\partial \eta^-}{\partial x_j}(x'), \\ \frac{\partial^2 u^-}{\partial x_N^2}(x) &= \frac{\partial^2 v^-}{\partial y_N^2}(x', x_N - \eta^-(x')). \end{split}$$

These computations show that all the second derivatives of  $v^-$  are in  $L^p$ , but unfortunately  $\frac{\partial v^-}{\partial y_N}$  is not in general, so it is unclear if  $u^- \in \dot{W}^{2,p}(\Omega)$ . Other types of lifting arguments (see, for instance, Proposition 7.3 in [25]) seem to present the same pathology.

Next we present the trace estimate in the general case  $m \geq 2$ .

**Theorem 5.7.** Let  $\Omega$  be as in (1.1), where  $\eta^{\pm}: \mathbb{R}^{N-1} \to \mathbb{R}$  are Lipschitz continuous functions, with  $\eta^{-} < \eta^{+}$  and  $L := |\eta^{+}|_{0,1} + |\eta^{-}|_{0,1}$ . Let  $m \in \mathbb{N}$  with  $m \geq 2$  and 1 . Then there exists a constant <math>c = c(m, N, p) > 0 such that for every  $u \in \dot{W}^{m,p}(\Omega)$  and for every  $i, l \in \mathbb{N}_{0}$  with  $0 \leq i + l \leq m - 1$ ,

$$\int_{\mathbb{R}^{N-1}} \frac{\left|\sum_{k=0}^{m-l-i-1} \frac{(-1)^k}{k!} (\nabla_{\shortparallel}^i \operatorname{Tr}(\partial_N^{k+l} u)(x', \eta^+(x')) + (-1)^{k+1} \nabla_{\shortparallel}^i \operatorname{Tr}(\partial_N^{k+l} u)(x', \eta^-(x'))) \left(\frac{\eta^+(x') - \eta^-(x')}{2}\right)^k\right|^p}{(\eta^+(x') - \eta^-(x'))^{(m-i-l)p-1}} dx'$$

$$\leq c \int_{\Omega} |\nabla^m u(x)|^p dx,$$

$$\int_{\mathbb{R}^{N-1}} \int_{B'(0, (\eta^+(x') - \eta^-(x'))/(2L))} \frac{|\operatorname{Tr}(\nabla^{m-1} u)(x' + h', \eta^{\pm}(x' + h')) - \operatorname{Tr}(\nabla^{m-1} u)(x', \eta^{\pm}(x'))|^p}{|h'|^{p+N-2}} dh' dx'$$

$$\leq (1 + L)^p c \int_{\Omega} |\nabla^m u(x)|^p dx.$$

**Proof.** The proof is very similar to the that of Theorem 5.5, using (2.9) instead of (2.10). We omit the details for the sake of brevity.  $\Box$ 

#### 6. Applications

In this section we present some applications of the previous results to quasilinear elliptic PDEs in domains  $\Omega$  of the form (1.1) or (1.3).

#### 6.1. Lagrangians

We record here some properties of Lagrangians that will be used to define our quasilinear PDEs. We begin with a notion of admissibility.

**Definition 6.1.** Let  $\Omega \subseteq \mathbb{R}^N$  be open and  $1 . We say that a function <math>G : \Omega \times \mathbb{R}^N \to \mathbb{R}$  is a p-admissible Lagrangian if the following conditions are satisfied.

- (1) For each  $\xi \in \mathbb{R}^N$  the function  $G(\cdot, \xi)$  is measurable on  $\Omega$ , and for almost every  $x \in \Omega$  the function  $G(x, \cdot)$  is continuously differentiable on  $\mathbb{R}^N$ .
- (2) For almost every  $x \in \Omega$  the function  $G(x, \cdot)$  is convex on  $\mathbb{R}^N$ .

- (3) There exists a constant  $A_{-} \in (0, \infty)$  and a function  $\psi_{-} \in L^{1}(\Omega)$  such that  $A_{-}|\xi|^{p} \psi_{-}(x) \leq G(x, \xi) \text{ for almost every } x \in \Omega \text{ and every } \xi \in \mathbb{R}^{N}.$
- (4) There exists a constant  $A_+ \in (0, \infty)$  and a function  $\psi_+ \in L^{p'}(\Omega)$  such that  $|\nabla_{\xi} G(x, \xi)| \leq \psi_+(x) + A_+ |\xi|^{p-1} \text{ for almost every } x \in \Omega \text{ and every } \xi \in \mathbb{R}^N.$
- $(5) \ G(\cdot,0) \in L^1(\Omega).$

The next lemma records an upper bound that follows from the assumptions in Definition 6.1.

**Lemma 6.2.** Let  $\Omega \subseteq \mathbb{R}^N$  be open and  $1 . If <math>G : \Omega \times \mathbb{R}^N \to \mathbb{R}$  is a p-admissible Lagrangian in the sense of Definition 6.1, then

$$|G(x,\xi)| \le |G(x,0)| + \frac{|\psi_+(x)|^{p'}}{p'} + \frac{(1+A_+)}{p}|\xi|^p$$

for almost every  $x \in \Omega$  and each  $\xi \in \mathbb{R}^N$ .

**Proof.** The fundamental theorem of calculus and the fourth admissibility condition for G allow us to estimate

$$|G(x,\xi)| \le |G(x,0)| + \int_{0}^{1} |\xi| |\nabla_{\xi} G(x,t\xi)| dt \le |G(x,0)| + \int_{0}^{1} [|\xi| |\psi_{+}(x)| + A_{+}t^{p-1} |\xi|^{p}] dt$$

The stated estimate follows easily from this and Young's inequality.  $\Box$ 

#### 6.2. The Dirichlet problem

We now turn our attention to the Dirichlet problem associated to *p*-admissible Lagrangians. Our main result, which is more general than Theorem 1.11 stated in the introduction, establishes necessary and sufficient conditions for the solvability of the associated Dirichlet problem.

**Theorem 6.3.** Let  $\Omega \subset \mathbb{R}^N$  be as in (1.3), a > 0,  $1 , and <math>f^{\pm} \in L^1_{loc}(\mathbb{R}^{N-1})$ . Suppose that  $G: \Omega \times \mathbb{R}^N \to \mathbb{R}$  is a p-admissible Lagrangian in the sense of Definition 6.1. Then the quasilinear Dirichlet problem

$$\begin{cases}
-\operatorname{div}(\nabla_{\xi}G(\cdot,\nabla u)) = 0 & \text{in } \Omega, \\
u = f^{\pm} & \text{on } \Gamma^{\pm}
\end{cases}$$
(6.1)

admits a solution in  $\dot{W}^{1,p}(\Omega)$  if and only if  $f^{\pm}$  satisfy (1.9) and (1.10). In either case, there exists a constant  $c = c(a, N, p, A_-, A_+) > 0$  such that

$$\int_{\Omega} |\nabla u(x)|^{p} dx \leq c \int_{\Omega} [|G(x,0)| + |\psi_{-}(x)| + |\psi_{+}(x)|^{p'}] dx + c \int_{\mathbb{R}^{N-1}} |f^{+}(x') - f^{-}(x')|^{p} dx' 
+ c|f^{-}|_{\tilde{W}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})}^{p} + c|f^{+}|_{\tilde{W}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})}^{p},$$
(6.2)

where  $\psi_{\pm}$  are as in Definition 6.1, and u minimizes the energy functional  $F: \{v \in \dot{W}^{1,p}(\Omega) \mid \operatorname{Tr}(v) = f^{\pm} \text{ on } \Gamma^{\pm}\} \to \mathbb{R}$  given by

$$F(v) = \int_{\Omega} G(x, \nabla v(x)) dx. \tag{6.3}$$

**Proof.** The proof is a standard application of the direct method of the calculus of variations. We present it for the convenience of the reader.

Assume that  $f^{\pm}$  satisfy (1.9) and (1.10). Let  $X := \{v \in \dot{W}^{1,p}(\Omega) \mid \operatorname{Tr}(v) = f^{\pm} \text{ on } \Gamma^{\pm} \}$  and note that X is nonempty thanks to Theorem 1.4. Consider the functional  $F: X \to \mathbb{R}$  given by (6.3), which is well-defined in light of Lemma 6.2. Since G is p-admissible, we can bound

$$F(v) \ge \int_{\Omega} A_{-} |\nabla v(x)|^p dx - \int_{\Omega} \psi_{-}(x) dx.$$

It follows that

$$\ell := \inf_{v \in X} F(v) > -\infty$$

and that if  $\{u_n\}_{n\in\mathbb{N}}$  is a minimizing sequence in X, i.e.

$$\lim_{n \to \infty} F(u_n) = \ell,$$

then  $\{\nabla u_n\}_{n\in\mathbb{N}}$  is bounded in  $L^p(\Omega;\mathbb{R}^N)$ . By applying Poincaré's inequality on an increasing sequence of bounded Lipschitz domains and employing a diagonalization argument, we can find a subsequence, not relabeled, and  $u\in\dot{W}^{1,p}(\Omega)$  such that  $\nabla u_n\rightharpoonup\nabla u$  in  $L^p(\Omega;\mathbb{R}^N)$ . The p-admissibility conditions guarantee that F is sequentially weakly lower semicontinuous (see, for instance, Theorem 6.54 of [17]), so

$$F(u) \le \lim_{n \to \infty} F(u_n) = \ell.$$

On the other hand, by applying the Rellich–Kondrachov theorem on the increasing sequence of bounded Lipschitz domains  $\Omega_k = (-k, k)^{N-1} \times (b^-, b^+)$ , we can assume that  $u_n \to u$  in  $L^p(\Omega_k)$  as  $n \to \infty$  for every k. Hence,  $u_n \rightharpoonup u$  in  $W^{1,p}(\Omega_k)$ , which implies

that  $\operatorname{Tr}(u) = f^{\pm}$  on  $\Gamma^{\pm} \cap \partial \Omega_k$ . Since this is true for every k, we have that  $u \in X$  and so  $F(u) = \ell$ .

Since u is a minimizer of F we may take variations to see that u satisfies

$$\int\limits_{\Omega} \nabla_{\xi} G(x, \nabla u) \cdot \nabla v \, dx = 0$$

for every  $v \in \dot{W}^{1,p}(\Omega)$  with Tr(v) = 0 on  $\Gamma^{\pm}$ . This shows that u is a weak solution of (6.1).

Conversely, if  $u \in \dot{W}^{1,p}(\Omega)$  is a weak solution of (6.1), then since  $\text{Tr}(u) = f^{\pm}$  on  $\Gamma^{\pm}$ , it follows from Theorem 1.2 that  $f^{\pm}$  satisfies conditions (1.9) and (1.10).

It remains to prove (6.2) when either (and hence both) of the equivalent conditions is satisfied. By Theorem 1.4 there exists  $w \in \dot{W}^{1,p}(\Omega)$  with  $\text{Tr}(w) = f^{\pm}$  on  $\Gamma^{\pm}$  and

$$\|\nabla w\|_{L^p(\Omega)} \le c|(f^-, f^+)|_{\dot{X}_{(a)}^{1-1/p, p}(\mathbb{R}^{N-1})},$$

where we recall that  $\dot{X}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})$  is the space given in Definition 3.18, with  $\sigma=a$ . Then  $w\in X$ , and so by minimality, p-admissibility, and Lemma 6.2 we have that

$$\int_{\Omega} [A_{-}|\nabla u(x)|^{p} - \psi_{-}(x)]dx \le F(u) \le F(w)$$

$$\le \int_{\Omega} [|G(x,0)| + |\psi_{+}(x)|^{p} + (1+A_{+})|\nabla w(x)|^{p}]dx$$

Then (6.2) follows immediately by combining these bounds.  $\Box$ 

**Remark 6.4.** Theorem 6.3 continues to hold for domains of the type (1.1), provided we replace (1.9) and (1.10) with (5.3) and (5.4). The proof remains unchanged.

We can now present the proof of Theorem 1.11.

**Proof of Theorem 1.11.** We simply observe that the map  $G: \Omega \times \mathbb{R}^N \to \mathbb{R}$  given by  $G(x,\xi) = |\xi|^p/p + g(x) \cdot \xi$  satisfies the conditions of Definition 6.1, and so we may apply Theorem 6.3.  $\square$ 

# 6.3. The Neumann problem

We now turn our attention to the Neumann problem associated to an admissible Lagrangian G, i.e. the problem

$$\begin{cases} -\operatorname{div}(\nabla_{\xi}G(\cdot,\nabla u)) = \psi \text{ in } \Omega, \\ \nabla_{\xi}G(\cdot,\nabla u) \cdot \nu = h \text{ on } \partial\Omega. \end{cases}$$

Assuming for the moment that u,  $\psi$ , and h are sufficiently smooth and have the right decaying properties, by multiplying the equation by  $v \in C_c^{\infty}(\mathbb{R}^N)$  and integrating by parts we get

$$\int\limits_{\Omega} \nabla_{\xi} G(x, \nabla u(x)) \cdot \nabla v(x) \, dx = \int\limits_{\Omega} v(x) \psi(x) \, dx + \int\limits_{\partial \Omega} v(x) h(x) \, d\mathcal{H}^{N-1}(x).$$

More generally, we may replace the linear functionals

$$v \mapsto \int_{\Omega} v \psi \, dx \text{ and } v \mapsto \int_{\partial \Omega} v h \, d\mathcal{H}^{N-1}$$

with generic linear functionals

$$\Psi: \dot{W}^{1,p}(\Omega) \to \mathbb{R} \text{ and } \Lambda: \dot{X}_{(1)}^{1-1/p,p}(\mathbb{R}^{N-1}) = \operatorname{Tr}(\dot{W}^{1,p}(\Omega)) \to \mathbb{R}. \tag{6.4}$$

Thus a weak solution  $u \in \dot{W}^{1,p}(\Omega)$  of this generalized problem must satisfy

$$\int\limits_{\Omega} \nabla_{\xi} G(x, \nabla u(x)) \cdot \nabla v(x) \, dx = \Psi(v) + \Lambda(\text{Tr}(v)) \tag{6.5}$$

for all  $v \in \dot{W}^{1,p}(\Omega)$ . Note that since a constant function  $v \equiv c$  belongs to  $\dot{W}^{1,p}(\Omega)$ , from (6.5) we get the compatibility condition

$$\Psi(c) + \Lambda(c) = 0 \tag{6.6}$$

for every  $c \in \mathbb{R}$ . This is the natural generalization to our unbounded domain of the compatibility conditions for the solvability of the Neumann problem on bounded domains. Thus, if we define  $\Lambda_1 : \dot{W}^{1,p}(\Omega) \to \mathbb{R}$  via

$$\Lambda_1(v) := \Lambda(\operatorname{Tr}(v)), \tag{6.7}$$

then

$$\Psi(v+c) + \Lambda_1(v+c) = \Psi(v) + \Lambda_1(v)$$

for every  $v \in \dot{W}^{1,p}(\Omega)$  and every  $c \in \mathbb{R}$ , and so we can define  $\Psi + \Lambda_1$  on the quotient space  $\dot{W}^{1,p}(\Omega)/\mathbb{R}$ .

Given  $v \in \dot{W}^{1,p}(\Omega)$ , we set

$$\operatorname{Tr}^{\pm}(v) := \operatorname{Tr}(v)|_{\Gamma^{\pm}}.$$

In view of Theorem 1.2, the pair  $(\operatorname{Tr}^-(v), \operatorname{Tr}^+(v))$  belongs to  $\dot{X}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})$ , where  $\dot{X}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})$  is the space given in Definition 3.18 with  $\sigma=a$  for  $0< a\leq b$ . In

what follows, with a slight abuse of notation, we identify Tr(v) with  $(\text{Tr}^-(v), \text{Tr}^+(v))$ . Conversely, given  $(f^-, f^+) \in \dot{X}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})$  by Theorem 1.4 we have that there is  $v \in \dot{W}^{1,p}(\Omega)$  such that  $\text{Tr}^{\pm}(f) = f^{\pm}$ . If we set

$$f(x', x_N) := \begin{cases} f^-(x') & \text{if } x' \in \mathbb{R}^{N-1}, \ x_N = b^-, \\ f^+(x') & \text{if } x' \in \mathbb{R}^{N-1}, \ x_N = b^+, \end{cases}$$
(6.8)

then f = Tr(v).

We can now state our main result on the Neumann problem.

**Theorem 6.5.** Let  $\Omega \subset \mathbb{R}^n$  be as in (1.3),  $1 , and assume that <math>\Psi : \dot{W}^{1,p}(\Omega) \to \mathbb{R}$  and  $\Lambda : \dot{X}_{(1)}^{1-1/p,p}(\mathbb{R}^{N-1}) \to \mathbb{R}$  are linear functionals satisfying (6.6). Suppose that  $G : \Omega \times \mathbb{R}^N \to \mathbb{R}$  is a p-admissible Lagrangian in the sense of Definition 6.1. Then the quasilinear Neumann problem

$$\begin{cases}
-\operatorname{div}(\nabla_{\xi}G(\cdot,\nabla u)) = \Psi & \text{in } \Omega, \\
\nabla_{\xi}G(\cdot,\nabla u) \cdot \nu = \Lambda & \text{on } \partial\Omega
\end{cases}$$
(6.9)

admits a weak solution in  $\dot{W}^{1,p}(\Omega)$  if and only if there exists c>0 such that

$$|\Psi(v) + \Lambda_1(v)| \le c \|\nabla v\|_{L^p(\Omega)} \tag{6.10}$$

for every  $v \in \dot{W}^{1,p}(\Omega)$ , where  $\Lambda_1$  is given in (6.7). In either case, there exists a constant  $c = c(a, N, p, A_-)$  such that

$$\int_{\Omega} |\nabla u(x)|^p dx \le c \int_{\Omega} [|G(x,0)| + |\psi_{-}(x)|] dx + c \|\Psi + \Lambda_1\|_{(\dot{W}^{1,p}(\Omega))'}^{p'}, \tag{6.11}$$

and u minimizes of the energy functional  $F: \dot{W}^{1,p}(\Omega) \to \mathbb{R}$  given by

$$F(v) = \int_{\Omega} G(x, \nabla v(x)) dx - \Psi(v) - \Lambda_1(v).$$
 (6.12)

**Proof.** Assume that  $\Psi$  and  $\Lambda$  satisfy (6.10). Consider the functional (6.12) defined for  $v \in \dot{W}^{1,p}(\Omega)$ . By (6.10) and the *p*-admissibility conditions,

$$F(v) \ge \int_{\Omega} A_{-} |\nabla v(x)|^{p} dx - \int_{\Omega} \psi_{-}(x) dx - c ||\nabla v||_{L^{p}(\Omega)}.$$

We can now proceed as in the proof of Theorem 6.3 to show that there exists a minimizer  $u \in \dot{W}^{1,p}(\Omega)$  of F. Using the continuity and linearity of  $\Lambda_1$ , taking variations we get that (6.5) holds for every  $v \in \dot{W}^{1,p}(\Omega)$ , which shows that u is a weak solution of (6.9).

Conversely, assume that  $u \in \dot{W}^{1,p}(\Omega)$  satisfies (6.5). Since (p-1)p' = p, it follows from the *p*-admissibility conditions and Hölder's inequality that

$$|\Psi(v) + \Lambda_1(v)| \le \int_{\Omega} (|\psi_+(x)| + A_+ |\nabla u(x)|^{p-1}) |\nabla v(x)| dx \le c(\psi_+, u, A_+) ||\nabla v||_{L^p(\Omega)}$$

for every  $v \in \dot{W}^{1,p}(\Omega)$ .

To conclude the proof it remains to show (6.11). Using the p-admissibility conditions, we may bound

$$\int_{\Omega} [A_{-}|\nabla u(x)|^{p} - \psi_{-}(x)]dx - (\Psi(u) + \Lambda_{1}(u)) \le F(u) \le F(0) \le \int_{\Omega} |G(x,0)|dx.$$

Then (6.11) follows directly from this and (6.10).  $\square$ 

We next record a corollary about the Neumann problem with  $\Psi = 0$ .

**Corollary 6.6.** Let  $\Omega \subset \mathbb{R}^n$  be as in (1.3),  $0 < a \le b^+ - b^-$ ,  $1 , and assume that <math>\Lambda : \operatorname{Tr}(\dot{W}^{1,p}(\Omega)) \to \mathbb{R}$  is a linear functional satisfying  $\Lambda(1) = 0$ . Suppose that  $G : \Omega \times \mathbb{R}^N \to \mathbb{R}$  is a p-admissible Lagrangian in the sense of Definition 6.1. Then the quasilinear Neumann problem

$$\begin{cases}
-\operatorname{div}(\nabla_{\xi}G(\cdot,\nabla u)) = 0 & \text{in } \Omega, \\
\nabla_{\xi}G(\cdot,\nabla u) \cdot \nu = \Lambda & \text{on } \partial\Omega
\end{cases}$$
(6.13)

admits a weak solution in  $\dot{W}^{1,p}(\Omega)$  if and only if there exists c>0 such that

$$|\Lambda(f)| \le c|(f^-, f^+)|_{\dot{X}_{(a)}^{1-1/p, p}(\mathbb{R}^{N-1})}$$
(6.14)

for every  $(f^-, f^+) \in \dot{X}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})$ , where f is given in (6.8). In either case, there exists a constant  $c = c(a, N, p, A_-)$  such that

$$\|\nabla u\|_{L^{p}(\Omega)}^{p} \le c \int_{\Omega} [|G(x,0)| + |\psi_{-}(x)|] dx + c|\Lambda|_{(\dot{X}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1}))'}^{p'}, \tag{6.15}$$

where  $|\Lambda|_{(\dot{X}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1}))'}$  is defined in (2.12).

**Proof.** Since  $\Psi = 0$  Theorem 6.5 tells us that (6.13) admits a weak solution  $u \in \dot{W}^{1,p}(\Omega)$  if and only if

$$|\Lambda_1(v)| \le c \|\nabla v\|_{L^p(\Omega)} \tag{6.16}$$

for every  $v \in \dot{W}^{1,p}(\Omega)$ . Assume that (6.14) holds. By Theorem 1.2, given  $v \in \dot{W}^{1,p}(\Omega)$ , we have that  $(\operatorname{Tr}^-(v), \operatorname{Tr}^+(v)) \in \dot{X}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})$  with  $|(\operatorname{Tr}^-(v), \operatorname{Tr}^+(v))|_{\dot{X}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})} \le c \|\nabla v\|_{L^p(\Omega)}$ , and so by (6.14),

$$|\Lambda_1(v)| = |\Lambda(\mathrm{Tr}(v))| \le c|(\mathrm{Tr}^-(v), \mathrm{Tr}^+(v))|_{\dot{X}_{(a)}^{1-1/p, p}(\mathbb{R}^{N-1})} \le c||\nabla v||_{L^p(\Omega)}.$$

This shows that the functional  $\Lambda_1$  satisfies (6.16). Conversely, assume that (6.16) holds. Given  $(f^-, f^+) \in \dot{X}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})$  by Theorem 1.4 we can find  $v \in \dot{W}^{1,p}(\Omega)$  such that  $\mathrm{Tr}(v) = f$  and

$$\|\nabla v\|_{L^p(\Omega)} \le c|(f^-, f^+)|_{\dot{X}_{(a)}^{1-1/p, p}(\mathbb{R}^{N-1})}.$$

It follows from (6.16) that

$$|\Lambda(f)| = |\Lambda_1(v)| \le c \|\nabla w\|_{L^p(\Omega)} \le c |(f^-, f^+)|_{\dot{X}_{(a)}^{1-1/p, p}(\mathbb{R}^{N-1})},$$

which shows (6.14).

To conclude the proof it remains to show (6.15). This follows from (6.11) once we observe that

$$|\Lambda(\operatorname{Tr}(u))| \leq |\Lambda|_{(\dot{X}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1}))'} |(\operatorname{Tr}^{-}(u), \operatorname{Tr}^{+}(u))|_{\dot{X}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})}$$
$$\leq c|\Lambda|_{(\dot{X}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1}))'} ||\nabla u||_{L^{p}(\Omega)},$$

where the last inequality follows from Theorem 1.2.  $\Box$ 

**Remark 6.7.** In view of Theorems 5.1 and 5.4, the previous corollary continues to hold for domains of the type 1.1, provided we replace  $\dot{X}_{(a)}^{1-1/p,p}(\mathbb{R}^{N-1})$  with  $\dot{X}_{(\eta)}^{1-1/p,p}(\mathbb{R}^{N-1})$ , where  $\eta := (\eta^+ - \eta^-)/(2L)$ . The proof remains unchanged.

# Acknowledgments

The authors would like to extend their thanks to the anonymous referee for their careful reading of the first draft of the manuscript and for their very helpful suggestions.

#### References

- R.A. Adams, J.J.F. Fournier, Sobolev Spaces, second edition, Pure and Applied Mathematics, vol. 140, Elsevier/Academic Press, Amsterdam, 2003.
- [2] V. Benci, D. Fortunato, Weighted Sobolev spaces and the nonlinear Dirichlet problem in unbounded domains, Ann. Mat. Pura Appl. (4) 121 (1979) 319–336.
- [3] C. Bennett, R. Sharpley, Interpolation of Operators, Pure and Applied Mathematics, vol. 129, Academic Press, Inc., Boston, MA, 1988.
- [4] M.S. Berger, M. Schechter, Embedding theorems and quasi-linear elliptic boundary value problems for unbounded domains, Trans. Amer. Math. Soc. 172 (1972) 261–278.

- [5] J. Bergh, J. Löfström, Interpolation Spaces. An Introduction, Grundlehren der Mathematischen Wissenschaften, vol. 223, Springer-Verlag, Berlin–New York, 1976.
- [6] O.V. Besov, V.P. Il'in, S.M. Nikol'ski˘ı, Integral Representations of Functions and Imbedding Theorems, vol. I, in: Mitchell H. Taibleson (Ed.), Scripta Series in Mathematics, V. H. Winston & Sons/Halsted Press, John Wiley& Sons, Washington, D.C./New York–Toronto, Ont.–London, 1978. Translated from the Russian.
- [7] O.V. Besov, V.P. Il'in, S.M. Nikol'ski˘ı, Integral Representations of Functions and Imbedding Theorems, vol. II, in: Mitchell H. Taibleson (Ed.), Scripta Series in Mathematics, V. H. Winston & Sons/Halsted Press, John Wiley & Sons, Washington, D.C./New York–Toronto, Ont.–London, 1979.
- [8] J. Bourgain, H. Brezis, P. Mironescu, Another look at Sobolev spaces, in: Optimal Control and Partial Differential Equations, IOS, Amsterdam, 2001, pp. 439–455.
- [9] J. Bourgain, H. Brezis, P. Mironescu, Limiting embedding theorems for *<sup>W</sup>s,p* when *<sup>s</sup>* <sup>↑</sup> 1 and applications, J. Anal. Math. 87 (2002) 77–101, Dedicated to the memory of Thomas H. Wolff.
- [10] H. Brezis, Functional Analysis, Sobolev Spaces and Partial Differential Equations, Universitext, Springer, New York, 2011.
- [11] H. Brezis, H.-M. Nguyen, Non-local functionals related to the total variation and connections with image processing, Ann. PDE 4 (1) (2018) 9.
- [12] V.I. Burenkov, Sobolev Spaces on Domains, Teubner-Texte zur Mathematik (Teubner Texts in Mathematics), vol. 137, B. G. Teubner Verlagsgesellschaft mbH, Stuttgart, 1998.
- [13] E. Di Nezza, G. Palatucci, E. Valdinoci, Hitchhiker's guide to the fractional Sobolev spaces, Bull. Sci. Math. 136 (5) (2012) 521–573.
- [14] Q. Du, M. Gunzburger, R.B. Lehoucq, K. Zhou, Analysis and approximation of nonlocal diffusion problems with volume constraints, SIAM Rev. 54 (4) (2012) 667–696.
- [15] D.E. Edmunds, W.D. Evans, Elliptic and degenerate-elliptic operators in unbounded domains, Ann. Sc. Norm. Super. Pisa Cl. Sci. 3 (27) (1974) 591–640, 1973.
- [16] M. Felsinger, M. Kassmann, P. Voigt, The Dirichlet problem for nonlocal operators, Math. Z. 279 (3–4) (2015) 779–809.
- [17] I. Fonseca, G. Leoni, Modern Methods in the Calculus of Variations: *L<sup>p</sup>* Spaces, Springer Monographs in Mathematics, Springer, New York, 2007.
- [18] E. Gagliardo, Caratterizzazioni delle tracce sulla frontiera relative ad alcune classi di funzioni in *n* variabili, Rend. Semin. Mat. Univ. Padova 27 (1957) 284–305.
- [19] G.P. Galdi, C.G. Simader, Existence, uniqueness and *Lq*-estimates for the Stokes problem in an exterior domain, Arch. Ration. Mech. Anal. 112 (4) (1990) 291–318.
- [20] L. Grafakos, Modern Fourier Analysis, third edition, Graduate Texts in Mathematics, vol. 250, Springer, New York, 2014.
- [21] P. Grisvard, Elliptic Problems in Nonsmooth Domains, Classics in Applied Mathematics, vol. 69, Society for Industrial and Applied Mathematics (SIAM), Philadelphia, PA, 2011. Reprint of the 1985 original.
- [22] A. Kufner, Weighted Sobolev Spaces, A Wiley-Interscience Publication, John Wiley & Sons, Inc., New York, 1985. Translated from the Czech.
- [23] G. Leoni, A First Course in Sobolev Spaces, second edition, Graduate Studies in Mathematics, vol. 181, American Mathematical Society, Providence, RI, 2017.
- [24] V. Maz'ya, Sobolev Spaces with Applications to Elliptic Partial Differential Equations, augmented edition, Grundlehren der Mathematischen Wissenschaften (Fundamental Principles of Mathematical Sciences), vol. 342, Springer, Heidelberg, 2011.
- [25] V. Maz'ya, M. Mitrea, T. Shaposhnikova, The Dirichlet problem in Lipschitz domains for higher order elliptic systems with rough coefficients, J. Anal. Math. 110 (2010) 167–239.
- [26] N. Meyers, J. Serrin, The exterior Dirichlet problem for second order elliptic partial differential equations, J. Math. Mech. 9 (1960) 513–538.
- [27] P. Mironescu, Note on Gagliardo's theorem "tr*W*<sup>1</sup>*,*<sup>1</sup> = *L*<sup>1</sup>", Ann. Univ. Buchar. Math. Ser. 6(LXIV) (2015) 99–103.
- [28] P. Mironescu, E. Russ, Traces of weighted Sobolev spaces. Old and new, Nonlinear Anal. 119 (2015) 354–381.
- [29] J. Nečas, Direct Methods in the Theory of Elliptic Equations, Springer Monographs in Mathematics, Springer, Heidelberg, 2012. Translated from the 1967 French original.
- [30] J. Peetre, New Thoughts on Besov Spaces, Mathematics Department, Duke University, Durham, N.C., 1976. Duke University Mathematics Series, vol. 1.
- [31] A.C. Ponce, An estimate in the spirit of Poincaré's inequality, J. Eur. Math. Soc. (JEMS) 6 (1) (2004) 1–15.

- [32] A.C. Ponce, D. Spector, On formulae decoupling the total variation of BV functions, Nonlinear Anal. 154 (2017) 241–257.
- [33] C.G. Simader, H. Sohr, The Dirichlet problem for the Laplacian in bounded and unbounded domains, in: A New Approach to Weak, Strong and (2 + *k*)-Solutions in Sobolev-Type Spaces, in: Pitman Research Notes in Mathematics Series, vol. 360, Longman, Harlow, 1996.
- [34] R.S. Strichartz, "Graph paper" trace characterizations of functions of finite energy, J. Anal. Math. 128 (2016) 239–260.
- [35] A.E. Taylor, Introduction to Functional Analysis, John Wiley & Sons, Inc./Chapman & Hall, Ltd., New York/London, 1958.
- [36] G. Thäter, Neumann problem in domains with outlets of bounded diameter, Acta Appl. Math. 73 (3) (2002) 251–274.
- [37] H. Triebel, Interpolation Theory, Function Spaces, Differential Operators, second edition, Johann Ambrosius Barth, Heidelberg, 1995.
- [38] S.V. Uspenski˘ı, Imbedding theorems for weighted classes, Amer. Math. Soc. Transl. Ser. 2 87 (1970) 121–145, Translation from Trudy Mat. Inst. Steklov 60 (1961) 282–303.
- [39] K. Zhou, Q. Du, Mathematical and numerical analysis of linear peridynamic models with nonlocal boundary conditions, SIAM J. Numer. Anal. 48 (5) (2010) 1759–1780.