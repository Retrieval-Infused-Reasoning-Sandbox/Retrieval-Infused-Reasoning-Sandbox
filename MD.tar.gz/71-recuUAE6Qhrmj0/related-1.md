[Skip to main content](#page-0-0)

[Springer Nature Link](https://link.springer.com)

[Log in](https://idp.springer.com/auth/personal/springernature?redirect_uri=https://link.springer.com/article/10.1007/s11854-016-0008-x)

[Menu](#page-8-0)

[Find a journal](https://link.springer.com/journals/) [Publish with us](https://www.springernature.com/gp/authors) [Track your research](https://link.springernature.com/home/)

[Search](#page-8-1)

[Cart](https://order.springer.com/public/cart)

- <span id="page-0-0"></span>[Home](file:///) 1.
- [Journal d'Analyse Mathématique](file:///journal/11854) 2.
- Article 3.

# **"Graph paper" trace characterizations of functions of finite energy**

- Published: 17 March 2016 •
- Volume 128, pages 239–260, (2016) •
- [Cite this article](#page-6-0) •

![](_page_0_Picture_14.jpeg)

[Journal d'Analyse Mathématique](file:///journal/11854) [Aims and scope](file:///journal/11854/aims-and-scope) 

- [Robert S. Strichartz](#page-6-1) [1](#page-5-0) •
- 163 Accesses •
- 11 Citations •
- [Explore all metrics](file:///article/10.1007/s11854-016-0008-x/metrics)  •

# **Abstract**

We characterize functions of finite energy in the plane in terms of their traces on the lines that make up "graph paper" with squares of side length *m n* for all *n* and certain 1/2-order Sobolev norms on the graph paper lines. We also obtain analogous results for functions of finite energy on two classical fractals: the Sierpinski gasket and the Sierpinski carpet.

This is a preview of subscription content, [log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2Fs11854-016-0008-x) to check access.

## **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2Fs11854-016-0008-x)

### **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

### **Buy Now**

| article                                                                                                                          |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/s11854-016-0008-x                                                                                                        |
| 1565-8538                                                                                                                        |
| "Graph paper" trace characterizations of functions of finite energy                                                              |
| 2016                                                                                                                             |
| 2016                                                                                                                             |
| Robert S. Strichartz                                                                                                             |
| Journal d'Analyse Mathématique                                                                                                   |
| 6941a15ec8eced0b646b0855131f73732e6420b9b6e3c7852561f5e82870828827b7e6c725cc56b2724a5e96ae9f5ba9a00b4091fae98b597fc6dfe7fffcd53e |

Buy article PDF 39,95 €

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals) 

### **Similar content being viewed by others**

![](_page_2_Picture_5.jpeg)

# **[Remarks on the Bounds of Graph Energy in Terms of Vertex Cover](https://link.springer.com/10.21136/CMJ.2021.0190-19?fromPaywallRec=true) [Number or Matching Number](https://link.springer.com/10.21136/CMJ.2021.0190-19?fromPaywallRec=true)**

Article 05 March 2021

![](_page_2_Picture_8.jpeg)

### **[Energy and Laplacian of fractal interpolation functions](https://link.springer.com/10.1007/s11766-017-3482-8?fromPaywallRec=true)**

#### Article 06 June 2017

![](_page_2_Figure_11.jpeg)

### **[New method for determining paper surface energy per contact angle](https://link.springer.com/10.1007/s10570-019-02695-4?fromPaywallRec=true)**

Article 27 August 2019

### **Explore related subjects**

Discover the latest articles, books and news in related subjects, suggested using machine learning.

- [Graph Theory](file:///subjects/graph-theory) •
- [Graphemics](file:///subjects/graphemics) •
- [Real Functions](file:///subjects/real-functions) •
- [Special Functions](file:///subjects/special-functions) •
- [Topology](file:///subjects/topology) •
- [Functional Analysis](file:///subjects/functional-analysis) •

# **References**

T. Aougab, S. Dong, and R. Strichartz, *Laplacians on a family of quadratic Julia sets II*, Comm. Pure Appl. Anal. **12** (2013), 1–58. 1.

[Article](https://doi.org/10.3934%2Fcpaa.2013.12.1) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2972421) [MATH](http://www.emis.de/MATH-item?1264.28003) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Laplacians%20on%20a%20family%20of%20quadratic%20Julia%20sets%20II&journal=Comm.%20Pure%20Appl.%20Anal.&doi=10.3934%2Fcpaa.2013.12.1&volume=12&pages=1-58&publication_year=2013&author=Aougab%2CT.&author=Dong%2CS.&author=Strichartz%2CR.)

M. Barlow, *Diffusions on fractals*, in *Lectures on Probability Theory and Statistics*, LNM**1690**, Springer, Berlin, 1998, pp. 1–121. 2.

[Chapter](https://link.springer.com/doi/10.1007/BFb0092537) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Diffusions%20on%20fractals&doi=10.1007%2FBFb0092537&pages=1-121&publication_year=1998&author=Barlow%2CM.)

M. Barlow, R. Bass, T. Kumagai, and A. Teplyaev, *Uniqueness of Brownian motion on Sierpinski carpets*, J. Eur.Math. Soc. (JEMS) **12** (2010), 655–701. 3.

[MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2639315) [MATH](http://www.emis.de/MATH-item?1200.60070) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Uniqueness%20of%20Brownian%20motion%20on%20Sierpinski%20carpets&journal=J.%20Eur.Math.%20Soc.%20%28JEMS%29&volume=12&pages=655-701&publication_year=2010&author=Barlow%2CM.&author=Bass%2CR.&author=Kumagai%2CT.&author=Teplyaev%2CA.)

G. Berkolaiko and P. Kuchment, *Introduction to Quantum Graphs*, Amer.Math. Soc., Providence, RI, 2013. 4.

[MATH](http://www.emis.de/MATH-item?1318.81005) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Introduction%20to%20Quantum%20Graphs&publication_year=2013&author=Berkolaiko%2CG.&author=Kuchment%2CP.)

T. Flock and R. Strichartz, *Laplacians on a family of quadratic Julia sets I*, Trans. Amer. Math. Soc. **364** (2012), 3915–3965. 5.

[Article](https://doi.org/10.1090%2FS0002-9947-2012-05398-0) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2912440) [MATH](http://www.emis.de/MATH-item?1290.28011) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Laplacians%20on%20a%20family%20of%20quadratic%20Julia%20sets%20I&journal=Trans.%20Amer.%20Math.%20Soc.&doi=10.1090%2FS0002-9947-2012-05398-0&volume=364&pages=3915-3965&publication_year=2012&author=Flock%2CT.&author=Strichartz%2CR.)

M. Fukushima, Y. Oshima, and M. Takeda, *Dirichlet Forms and Symmetric Markov Processes*, Walter de Gruyter & Co, Berlin, 1994. 6.

[Book](https://doi.org/10.1515%2F9783110889741) [MATH](http://www.emis.de/MATH-item?0838.31001) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Dirichlet%20Forms%20and%20Symmetric%20Markov%20Processes&doi=10.1515%2F9783110889741&publication_year=1994&author=Fukushima%2CM.&author=Oshima%2CY.&author=Takeda%2CM.)

M. Hino and T. Kumagai, *A trace theorem for Dirichlet forms on fractals*, J. Funct. Anal. **238** (2006), 578–611. 7.

[Article](https://doi.org/10.1016%2Fj.jfa.2006.05.012) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2253734) [MATH](http://www.emis.de/MATH-item?1111.47005) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20trace%20theorem%20for%20Dirichlet%20forms%20on%20fractals&journal=J.%20Funct.%20Anal.&doi=10.1016%2Fj.jfa.2006.05.012&volume=238&pages=578-611&publication_year=2006&author=Hino%2CM.&author=Kumagai%2CT.)

A. Jonsson, *A trace theorem for the Dirichlet form on the Sierpinski gasket*, Math. Z. **250** (2005), 599–609. 8.

[Article](https://link.springer.com/doi/10.1007/s00209-005-0767-z) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2179613) [MATH](http://www.emis.de/MATH-item?1073.60078) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20trace%20theorem%20for%20the%20Dirichlet%20form%20on%20the%20Sierpinski%20gasket&journal=Math.%20Z.&doi=10.1007%2Fs00209-005-0767-z&volume=250&pages=599-609&publication_year=2005&author=Jonsson%2CA.)

A. Jonsson, *A Dirichlet form on the Sierpinski gasket, related function spaces, and traces*, in *Fractal Geometry and Stochastics III*, Birkhaüser, Basel, 2004, pp. 235– 244. 9.

[Chapter](https://link.springer.com/doi/10.1007/978-3-0348-7891-3_15) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20Dirichlet%20form%20on%20the%20Sierpinski%20gasket%2C%20related%20function%20spaces%2C%20and%20traces&doi=10.1007%2F978-3-0348-7891-3_15&pages=235-244&publication_year=2004&author=Jonsson%2CA.)

J. Kigami, *Analysis on Fractals*, Cambridge Univ. Press, Cambridge, 2001. 10.

[Book](https://doi.org/10.1017%2FCBO9780511470943) [MATH](http://www.emis.de/MATH-item?0998.28004) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Analysis%20on%20Fractals&doi=10.1017%2FCBO9780511470943&publication_year=2001&author=Kigami%2CJ.)

V. Mazýa, *Sobolev Spaces*, Springer-Verlag, Berlin, 1985. 11.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=Sobolev%20Spaces&publication_year=1985&author=Maz%C3%BDa%2CV.)

A. Poirier, *Critical portraits for postcritically finite polynomials*, Fund. Math. **203** (2009), 107–163. 12.

[Article](https://doi.org/10.4064%2Ffm203-2-2) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2496235) [MATH](http://www.emis.de/MATH-item?1179.37066) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Critical%20portraits%20for%20postcritically%20finite%20polynomials&journal=Fund.%20Math.&doi=10.4064%2Ffm203-2-2&volume=203&pages=107-163&publication_year=2009&author=Poirier%2CA.)

L. Rogers and A. Teplyaev, *Laplacians on the basilica Julia set*, Comm. Pure Appl. Anal. **9** (2010), 201–231. 13.

#### [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2556753) [MATH](http://www.emis.de/MATH-item?1194.28013) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Laplacians%20on%20the%20basilica%20Julia%20set&journal=Comm.%20Pure%20Appl.%20Anal.&volume=9&pages=201-231&publication_year=2010&author=Rogers%2CL.&author=Teplyaev%2CA.)

C. Spicer, R. Strichartz, and E. Totari, *Laplacians on Julia sets III: Cubic Julia sets and formal matings*, in *Fractal Geometry and Dynamical Systems in Pure and Applied Mathematics I: Fractals in Pure Mathematics*, Contemporary Math. **600** (2013), 327– 348. 14.

#### [Article](https://doi.org/10.1090%2Fconm%2F600%2F11952) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=3203408) [MATH](http://www.emis.de/MATH-item?1321.37047) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Laplacians%20on%20Julia%20sets%20III%3A%20Cubic%20Julia%20sets%20and%20formal%20matings&journal=Fractal%20Geometry%20and%20Dynamical%20Systems%20in%20Pure%20and%20Applied%20Mathematics%20I%3A%20Fractals%20in%20Pure%20Mathematics&doi=10.1090%2Fconm%2F600%2F11952&volume=600&pages=327-348&publication_year=2013&author=Spicer%2CC.&author=Strichartz%2CR.&author=Totari%2CE.)

E. Stein, *Singular Integrals and Differentiability Properties of Functions*, Princeton Univ. Press, Princeton, NJ, 1970. 15.

#### [MATH](http://www.emis.de/MATH-item?0207.13501) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Singular%20Integrals%20and%20Differentiability%20Properties%20of%20Functions&publication_year=1970&author=Stein%2CE.)

R. Strichartz, *Multipliers on fractional Sobolev spaces*, J. Math. Mech. **16** (1967), 1031–1060. 16.

#### [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=215084) [MATH](http://www.emis.de/MATH-item?0145.38301) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Multipliers%20on%20fractional%20Sobolev%20spaces&journal=J.%20Math.%20Mech.&volume=16&pages=1031-1060&publication_year=1967&author=Strichartz%2CR.)

R. Strichartz, *Differential Equations on Fractals, a Tutorial*, Princeton Univ. Press, Princeton, NJ, 2006. 17.

[MATH](http://www.emis.de/MATH-item?1190.35001) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Differential%20Equations%20on%20Fractals%2C%20a%20Tutorial&publication_year=2006&author=Strichartz%2CR.)

#### [Download references](https://citation-needed.springer.com/v2/references/10.1007/s11854-016-0008-x?format=refman&flavour=references)

### **Author information**

#### **Authors and Affiliations**

<span id="page-5-0"></span>Mathematics Department, Cornell University, Ithaca, NY, 14853, USA 1.

Robert S. Strichartz

#### Authors

<span id="page-6-1"></span>Robert S. Strichartz 1.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Robert%20S.%20Strichartz)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Robert%20S.%20Strichartz) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Robert%20S.%20Strichartz%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### **Corresponding author**

Correspondence to [Robert S. Strichartz.](mailto:str@math.cornell.edu)

### **Additional information**

Research supported in part by the National Science Foundation, grant DMS-1162045.

# **Rights and permissions**

[Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?title=%E2%80%9CGraph%20paper%E2%80%9D%20trace%20characterizations%20of%20functions%20of%20finite%20energy&author=Robert%20S.%20Strichartz&contentID=10.1007%2Fs11854-016-0008-x©right=Hebrew%20University%20Magnes%20Press&publication=0021-7670&publicationDate=2016-03-17&publisherName=SpringerNature&orderBeanReset=true)

# **About this article**

![](_page_6_Picture_11.jpeg)

#### <span id="page-6-0"></span>**Cite this article**

Strichartz, R.S. "Graph paper" trace characterizations of functions of finite energy. *JAMA* **128**, 239–260 (2016). https://doi.org/10.1007/s11854-016-0008-x

#### [Download citation](https://citation-needed.springer.com/v2/references/10.1007/s11854-016-0008-x?format=refman&flavour=citation)

Received: 10 June 2013 •

Published: 17 March 2016 •

Issue date: February 2016 •

DOI: https://doi.org/10.1007/s11854-016-0008-x •

#### **Keywords**

- [Sobolev Space](file:///search?query=Sobolev%20Space&facet-discipline=%22Mathematics%22) •
- [Dirichlet Form](file:///search?query=Dirichlet%20Form&facet-discipline=%22Mathematics%22) •
- [Graph Paper](file:///search?query=Graph%20Paper&facet-discipline=%22Mathematics%22) •
- [Sierpinski Gasket](file:///search?query=Sierpinski%20Gasket&facet-discipline=%22Mathematics%22) •
- [Trace Theorem](file:///search?query=Trace%20Theorem&facet-discipline=%22Mathematics%22) •

### **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2Fs11854-016-0008-x)

#### **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

### **Buy Now**

| article                                                             |  |
|---------------------------------------------------------------------|--|
| 10.1007/s11854-016-0008-x                                           |  |
| 1565-8538                                                           |  |
| "Graph paper" trace characterizations of functions of finite energy |  |
| 2016                                                                |  |
| 2016                                                                |  |
|                                                                     |  |

Robert S. Strichartz

Journal d'Analyse Mathématique

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals) 

Advertisement

# <span id="page-8-1"></span>**Search**

| Search by keyword or author |  |
|-----------------------------|--|
|                             |  |
|                             |  |
|                             |  |

Search

# <span id="page-8-0"></span>**Navigation**

- [Find a journal](https://link.springer.com/journals/)  •
- [Publish with us](https://www.springernature.com/gp/authors) •
- [Track your research](https://link.springernature.com/home/) •

#### **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

#### **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •

- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

#### **Products and services**

- [Our products](https://www.springernature.com/gp/products) •
- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

#### **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •
- [Accessibility statement](https://link.springer.com/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •
- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

[Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature