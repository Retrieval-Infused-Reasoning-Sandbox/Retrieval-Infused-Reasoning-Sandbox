# The Logic of Graph Neural Networks

Martin Grohe RWTH Aachen University, Germany

Email: grohe@informatik.rwth-aachen.de

*Abstract*—Graph neural networks (GNNs) are deep learning architectures for machine learning problems on graphs. It has recently been shown that the expressiveness of GNNs can be characterised precisely by the combinatorial Weisfeiler-Leman algorithms and by finite variable counting logics. The correspondence has even led to new, higher-order GNNs corresponding to the WL algorithm in higher dimensions.

The purpose of this paper is to explain these descriptive characterisations of GNNs.

#### I. INTRODUCTION

Graph neural networks (GNNs) are deep learning architectures for graph structured data that have developed into a method of choice for many graph learning problems in recent years. It is, therefore, important that we understand their power. One aspect of this is the expressiveness: which functions on graphs can be expressed by a GNN model? This may guide us in our choice for a suitable learning architecture for a learning problem we want to solve, and perhaps point to a suitable variant of GNNs.

Machine learning (statistical reasoning) and logic (symbolic reasoning) not always seem to be compatible. Therefore, it comes as a pleasant surprise that the expressive power of GNNs has a clean logical characterisations in terms of finite variable counting logics. These logics have been studied for a long time in finite model theory, and they play an important role in the field (see, e.g., [17, 25, 34, 45]). This is because of their role in analysing fixed-point logic with counting and the quest for a logic capturing polynomial time [20, 45], and because of their close relation to the Weisfeiler-Leman (WL) algorithm [11, 56]: the k-dimensional WL algorithm is an equivalence test for the (k + 1)-variable counting logic Ck+1.

The k-dimensional WL algorithm iteratively computes a colouring of the k-tuples of vertices of a graph by passing local information about the isomorphism type and the current colour between tuples. The goal is to detect differences; tuples that are structurally different (formally: belong to different orbits of the automorphism group) should eventually receive different colours. It has been shown by Cai, Furer and Immerman [ ¨ 11] that this goal cannot always be reached, but still, the WL algorithm gathers "most" structural information. For graph classes excluding some fixed graph as a minor, we can always find a k such that k-dimensional WL fully characterises the graphs in this class and the orbits of their automorphism groups [20], for planar graphs even k = 3 is enough [30] (see [31] for a recent survey). For most of this paper, we will focus on the 1-dimensional WL algorithm and a variant known as

978-1-6654-4895-6/21/\$31.00 ©2021 IEEE algorithms.

colour refinement.<sup>1</sup> On the logical side, they correspond to the 2-variable counting logic C<sup>2</sup> and its guarded fragment GC2, which is also known as graded modal logic.

Intuitively, the similarity between GNNs and the 1 dimensional WL algorithm is quite obvious. A GNN represents a message passing algorithm operating on graphs; just like the WL algorithm, a GNN works by iteratively passing local information along the edges of a graph. At each point during the computation, each vertex gets a real-valued vector as its state. Vertices exchange information by sending messages along the edges of the graph, and then they update their states based on their current state and the messages they receive. The message functions as well as the state update functions are represented by neural networks, and their parameters can be learned, either from labelled examples to learn a model of an unknown function defined on the vertices of a graph, or in an unsupervised fashion to learn a vector representation of the vertices of a graph. Crucially, all vertices use the same message passing and state update functions, that is, the parameters of the neural network are shared across the graph. This idea is inspired by convolutional neural networks, which have been applied extremely successfully in computer vision. It not only reduces the overall number of parameters that need to be learned, but it also guarantees that the learned function is isomorphism invariant (or equivariant), which is essential for learning functions on graphs.

It has been proved independently by Morris et al. [43] and Xu et al. [58] that the colour refinement algorithm precisely captures the expressiveness of GNNs in the sense that there is a GNN distinguishing two nodes of a graph if and only if colour refinement assigns different colours to these nodes. This implies a characterisation of the distinguishability of nodes by GNNs in terms of equivalence in the logic GC2. Barcelo et al. [7] extended this result and showed that every property of nodes definable by a GC2-formula is expressible by a GNN, uniformly over all graphs. Corresponding results hold for GNNs with an additional feature that allows vertices to access aggregate global information, the 1-dimensional WL algorithm, and the logic C2. It is the main purpose of this paper to explain these results, including all required background, all the fine-print in their statements, and their proofs.

The results have some interesting extensions. Based on the higher-order WL algorithm, Morris et al. [43] introduced

<sup>1</sup>Often, no distinction is made between 1-dimensional WL and colour refinement, because in some sense, they are equivalent (see Proposition V.4). However, it will be important here to emphasise the difference between the higher-order GNNs that lift the equivalence between WL and GNNs to a higher level. Another interesting extension is to let GNNs operate with a random initialisation of their states. This is often done in practice anyway. At first sight, this violates the isomorphism invariance, but as random variables, the functions computed by GNNs with random initialisation remain invariant. It turns out that random initialisation significantly affects the expressiveness; all invariant functions on graphs can be expressed using GNNs with random initialisation [1].

The paper is organised as follows. After giving the necessary preliminaries, we include background sections on finitevariable counting logics, invariant and equivariant functions defined on graphs, the Weisfeiler-Leman algorithm, and feedforward neural networks. We then introduce GNNs. In the subsequent sections, we state and prove the results outlined above as well as their consequences. We conclude with a brief discussion and a number of open questions.

#### II. PRELIMINARIES

We denote the set of real numbers by R and the set of nonnegative integers by N. For real numbers x ≤ y, by (x, y) and [x, y] we denote the open resp. closed interval between x and y. For every positive integer n, we let [n] = {1, . . . , n}.

We use bold-face letters to denote tuples (or vectors). The entries of a k-tuple x are x1, . . . , xk; the length k will usually be clear from the context. For a k-tuple x and an element y, by xy we denote the (k + 1)-tuple (x1, . . . , xk, y). Moreover, for every i ∈ [k], by x[y/i] we denote the k-tuple (x1, . . . , xi−1, y, xi+1, . . . , xk) and by x[/i] the (k − 1)-tuple (x1, . . . , xi−1, xi+1, . . . , xk).

A *multiset* is an unordered collection with repetition, which can formally be described as a function from a set to the positive integers. We use {{ . . . }} to denote multisets. We write M ⊆ X to denote that M is a multiset with elements from a set X and x ∈ M to denote that x appears at least once in M. The *order* of a multiset is the sum of the multiplicities of all elements of M.

By default, we assume *graphs* to be finite, undirected, simple, and vertex-labelled. Thus formally, a graph is a tuple G = (V (G), E(G), P1(G), . . . , P`(G)) consisting of a finite vertex set V (G), a binary edge relation E(G) ⊆ V (G) 2 that is symmetric and irreflexive, and unary relations P1(G), . . . , P`(G) ⊆ V (G) representing ` vertex labels. We usually denote edges without parenthesis, as in vw, with the understanding that vw = wv. We always use ` to denote the number of labels of a graph; if ` = 0, we speak of an *unlabelled graph*. Throughout this paper, we think of ` as being fixed and not part of the input of computational problems. We sometimes refer to the vector col(G, v) := (c1, . . . , c`) ∈ {0, 1} ` with c<sup>i</sup> = 1 if v ∈ Pi(G) and c<sup>i</sup> = 0 otherwise as the *colour* of vertex v ∈ V (G). Let me remark that col(G, v) is even defined for unlabelled graphs, where we simply have col(G, v) = () (the empty tuple) for all v.

An isomorphism from a graph G to a graph G<sup>0</sup> is a bijective mapping f : V (G) → V (G<sup>0</sup> ) that preserves edges as well as labels, that is, vw ∈ E(G) ⇐⇒ f(v)f(w) ∈ E(G<sup>0</sup> ) for all v, w ∈ V (G) and v ∈ Pi(G) ⇐⇒ f(v) ∈ Pi(G<sup>0</sup> ) for all i ∈ [`] and v ∈ V (G).

We use the usual graph theoretic terminology. In particular, the set of *neighbours* of a vertex v in a graph G is N <sup>G</sup>(v) := {w ∈ V (G) | vw ∈ E(G)}. For a set X ⊆ V (G), the *induced subgraph* G[X] is the graph with vertex set X, edge relation E(G) ∩ X<sup>2</sup> , and unary relations Pi(G) ∩ X. The *order* of a graph G is |G| := |V (G)|.

*Remark II.1.* To keep the presentation simple, in this paper we focus on undirected vertex-labelled graphs, but all the results can be extended to directed graphs with edge labels, that is, binary relational structures. Formally, a binary relational structure is a tuple A = (V (A), E1(A), . . . , Ek(A), P1(A), . . . , P`(A)) consisting of a finite vertex set V (A), binary relations Ei(A) ⊆ V (A) and unary relations P<sup>j</sup> (A). For such structures, we define the colour map col(A) : V (A) → {0, 1} <sup>k</sup>+` by col(A, v) := (c1, . . . , ck, d1, . . . , d`) with c<sup>i</sup> = 1 if (v, v) ∈ Ei(A) and d<sup>j</sup> = 1 if v ∈ P<sup>j</sup> (A).

We will get back to binary relational structures once in a while, mainly in a series of remarks. y

*Remark II.2.* Another common generalisation is to assign realvalued weights to vertices and possibly edges instead of the Boolean labels. Formally, instead of the subsets Pi(G) ⊆ V (G) we have functions Pi(G) : V (G) → R. Isomorphisms f are required to preserve these functions. Again, most results can be extended to this setting, but will not discuss these extensions here. y

## III. FINITE VARIABLE COUNTING LOGIC

The logics we are interested in are fragments of the extension C of first-order logic FO by *counting quantifiers* ∃ ≥p . That is, C-formulas are formed from *atomic formulas* of the form x = y, E(x, y), Pi(x) with the usual Boolean connectives, and the new counting quantifiers. Standard existential and universal quantifiers can easily be expressed using the counting quantifiers (∃x as ∃ <sup>≥</sup>1x and ∀x as ¬∃<sup>≥</sup>1x¬).

We interpret C-formulas over labelled graphs; variables range over the vertices. We use the notation ϕ(x1, . . . , xk) to indicate that the free variables of a formula ϕ are among x1, . . . , xk, and for a graph G and vertices v1, . . . , v<sup>k</sup> ∈ V (G) we write G |= ϕ(v1, . . . , vk) to denote that G satisfies ϕ if the variables x<sup>i</sup> are interpreted by the vertices v<sup>i</sup> . The semantics of the counting quantifiers is the obvious one: a labelled graph G together with vertices w1, . . . , w<sup>k</sup> ∈ V (G) satisfies a formula ∃ <sup>≥</sup><sup>p</sup>x ϕ(x, y1, . . . , yk) if there are at least p vertices v ∈ V (G) such that G |= ϕ(v, w1, . . . , wk).

*Remark III.1.* We can easily extend C from graphs to arbitrary (binary) relational structures; we only need to add additional atomic formulas Ei(x, y) for the binary relations E<sup>i</sup> . y

Note that while syntactically an extension of FO, the logic C has the same expressive power as FO, because the formula  $\exists^{\geq p} x \varphi(x)$  is equivalent to

$$\exists x_1 \dots \exists x_p \Big( \bigwedge_{1 \le i < j \le p} x_i \ne x_j \land \bigwedge_{i=1}^p \varphi(x_i) \Big).$$

However, the translation from C to FO incurs an increase in the number of variables as well as the quantifier rank (maximum number of nested quantifiers). For example, the C-formula  $\forall x \exists^{\geq d} y E(x,y)$  stating that the minimum degree of a graph is d uses 2 variables and has quantifier rank 2. It is easy to show that any equivalent FO-formula needs at least d+1 variables and has quantifier rank at least d+1.

By  $C_k$  we denote the fragment of C consisting of all formulas with at most k variables, and by  $C^{(q)}$ , we denote the fragment consisting of all formulas of quantifier rank at most q. We also combine the two, letting  $C_k^{(q)} := C_k \cap C^{(q)}$ . The fragments are still quite expressive.

**Example III.2.** For every  $\ell$  one can easily construct a  $C_3^{(\ell)}$ -formula stating that the diameter of a graph is at most  $2^{\ell}$  based on the inductive definition of distances:

$$\delta_{2n}(x,y) = \exists z (\delta_n(x,z) \wedge \delta_n(z,y)).$$

We need to consider one more fragment of the logic C, the *guarded fragment* GC. In this fragment, quantifiers are restricted to range over the neighbours of the current nodes. Formally, GC-formulas are formed from the atomic formulas by the Boolean connectives and quantification restricted to formulas of the form  $\exists^{\geq p}y(E(x,y)\wedge\psi)$ , where x and y are distinct variables and x appears in  $\psi$  as a free variable. Note that every formula of GC has at least one free variable. We are mainly interested in the 2-variable fragment  $\mathsf{GC}_2$ , also known as *graded modal logic* [7, 48]. Again we use a superscript to indicate the quantifier rank, that is,  $\mathsf{GC}_2^{(q)} \coloneqq \mathsf{GC}_2 \cap \mathsf{C}^{(q)}$ .

**Example III.3.** The following  $GC_2$ -formula  $\varphi(x)$  says that vertex x has at most 1 neighbour that has more than 10 neighbours with label  $P_1$ :

$$\varphi(x) \coloneqq \neg \exists^{\geq 2} y \Big( E(x,y) \wedge \exists^{\geq 11} x \big( E(y,x) \wedge P_1(x) \big) \Big). \quad \exists$$

#### IV. INVARIANTS AND COLOURINGS

In this paper, we study mappings defined on graphs or vertices of graphs. Crucially, we want these mappings to be isomorphism invariant. A graph invariant (or 0-ary graph invariant) is a function  $\xi$  defined on graphs such that  $\xi(G)=\xi(G')$  for isomorphic graphs G,G'. For  $k\geq 1$ , a k-ary graph invariant is a function  $\xi$  that associates with each graph G a function  $\xi(G)$  defined on  $V(G)^k$  in such a way that for all graphs G,G', all isomorphisms f from G to G', and all tuples  $v\in V(G)^k$  it holds that

$$\xi(G)(\mathbf{v}) = \xi(f(G))(f(\mathbf{v})).$$

Formally, such a mapping  $\xi$  is called *equivariant*. In the following, we just speak of k-ary invariants. Moreover, we

![](_page_2_Picture_14.jpeg)

![](_page_2_Picture_15.jpeg)

Fig. 1. Two graphs with the same degree sequence

call 0-ary invariants *graph invariants* and 1-ary invariants *vertex invariants*. To simplify the notation, for mappings  $\xi$  (equivariant or not) that associate a function on  $V(G)^k$  with every graph G, we usually write  $\xi(G, v)$  instead of  $\xi(G)(v)$ . We have already used this notation for the vertex invariant COI defined in Section II.

Let  $\xi$  be a k-ary invariant. If  $\xi(G, v) \neq \xi(G', v')$ , then we say that  $\xi$  distinguishes (G, v) and (G', v') (or just v and v' if the graphs are clear from the context). The equivariance condition implies that if  $\xi$  distinguishes (G, v) and (G', v') then there is no isomorphism from G to G' that maps v to v'. If the converse also holds, then  $\xi$  is a *complete* invariant.

From a k-ary invariant  $\xi$  we can derive a graph invariant  $\xi$  by mapping each graph G to the multiset

$$\widehat{\xi}(G) \coloneqq \{\!\!\{ \xi(G, \boldsymbol{v}) \mid \boldsymbol{v} \in V(G)^k \}\!\!\}.$$

We say that  $\xi$  distinguishes two graphs G, G' if  $\widehat{\xi}(G) \neq \widehat{\xi}(G')$ . Note that if  $\xi$  is a complete invariant then  $\widehat{\xi}$  is complete as well, that is,  $\xi$  distinguishes G, G' if and only if G, G' are non-isomorphic. The converse does not necessarily hold, that is, there are incomplete invariants  $\xi$  for which  $\widehat{\xi}$  is complete.

- **Example IV.1.** (1) The degree deg defined by  $deg(G, v) := |N^G(v)|$  is a vertex invariant. The graph invariant deg associates with each graph the multiset of vertex degrees appearing in the graph (or, equivalently, the *degree sequence*). Note that deg does not distinguish the two graphs shown in Figure 1.
- (2) The binary invariant dist is defined by letting  $\operatorname{dist}(G,v,w)$  be the length of the shortest path from v to w in G, or  $\infty$  if no such path exists. dist distinguishes the two graphs in Figure 1.
- (3) We define a ternary invariant tri by letting  $\operatorname{tri}(G,v_1,v_2,v_3)=1$  if G induces a triangle on  $\{v_1,v_2,v_3\}$  and  $\operatorname{tri}(G,v_1,v_2,v_3)=0$  otherwise. Then  $\widehat{\operatorname{tri}}$  is essentially the graph invariant "number of triangles". tri distinguishes the two graphs in Figure 1 as well.

We often think of mappings  $\chi$  defined on V(G) or  $V(G)^k$  as *colourings* of the vertices or k-tuples of vertices of a graph G (where "colour" is just an intuitive way of illustrating an abstract range). If the range of  $\chi$  is  $\mathbb{R}^n$ , we also call  $\chi$  a n-dimensional *feature map*, in particular in the context of graph neural networks. We refer to the elements in the range of a colouring (or feature map)  $\chi$  as *colours* and to the pre-images  $\chi^{-1}(c)$  for colours c as *colour classes*. Thus a colouring defined on  $V(G)^k$  induces a partition of  $V(G)^k$  into colour

<sup>&</sup>lt;sup>2</sup>This notation is slightly non-standard, but it aligns well with our notation for the WL algorithm and GNNs later.

classes. For colourings  $\chi, \chi': V(G)^k \to C$ , we say that  $\chi$  refines  $\chi'$  (we write  $\chi \preceq \chi'$ ) if for all  $v, w \in V(G)^k$ , if  $\chi(v) = \chi(w)$  then  $\chi'(v) = \chi'(w)$ . In other words: the partition of  $V(G)^k$  into the colour classes of  $\chi$  refines the partition into the colour classes of  $\chi'$ . We call colourings  $\chi, \chi'$  equivalent (we write  $\chi \equiv \chi'$ ) if  $\chi \preceq \chi'$  and  $\chi' \preceq \chi$ , that is, if  $\chi$  and  $\chi'$  induce the same partition. For k-ary invariants  $\xi, \xi'$  we say that  $\xi$  refines  $\xi'$  if  $\xi(G)$  refines  $\xi'(G)$  for every graph G, and similarly for equivalence.

The vertex colouring col is, in some sense, the most basic vertex invariant. We extend it to a k-ary invariant  $\operatorname{atp}_k$ . For a graph G with  $\ell$  labels and a tuple  $\boldsymbol{v} = (v_1, \dots, v_k) \in V(G)$ , we let  $\operatorname{atp}_k(G, \boldsymbol{v}) \in \{0,1\}^{2\binom{k}{2}+k\ell}$  be the vector which for  $1 \leq i < j \leq k$  has two entries indicating whether  $v_i = v_j$  and whether  $v_i v_j \in E(G)$  and for  $1 \leq i \leq k$  has  $\ell$  entries indicating whether  $v_i$  is in  $P_1(G), \dots, P_\ell(G)$ . Note that  $\operatorname{atp}_1 = \operatorname{col}$ . The vector  $\operatorname{atp}_k(G, \boldsymbol{v})$  is called the *atomic type* of  $\boldsymbol{v}$  in G. The crucial property of atomic types is that  $\operatorname{atp}_k(G, \boldsymbol{v}) = \operatorname{atp}_k(G', \boldsymbol{v}')$  if and only if the mapping  $v_i \mapsto v_i'$  is an isomorphism from the induced subgraph  $G[\{v_1, \dots, v_k\}]$  to the induced subgraph  $G'[\{v_1', \dots, v_k'\}]$ . In particular, this implies that the  $\operatorname{atp}_k$  is indeed an invariant.

**Example IV.2.** Recall the invariants dist and tri defined in Example IV.1. For all unlabelled graphs G (that is, graphs with  $\ell=0$  labels),  $\operatorname{dist}(G)$  refines  $\operatorname{atp}_2(G)$  and  $\operatorname{atp}_3(G)$  refines  $\operatorname{tri}(G)$ . In general, both refinements are strict.

Remark IV.3. If we want to extend atomic types to arbitrary relational structures, say with m binary and  $\ell$  unary relations, we extend the range to be  $\{0,1\}^{mk^2+\binom{k}{2}+\ell k}$ . For each binary relation, we reserve  $n^2$  bits storing which pairs it contains.  $\Box$ 

# V. THE WEISFEILER-LEMAN ALGORITHM

The Weisfeiler-Leman (WL) algorithm was originally introduced as an isomorphism test, and it served that purpose well. It is a key subroutine of individualisation-refinement algorithms on which all modern graph isomorphism tools build [13, 27, 35, 39, 40], and it has played an important role in theoretical research towards the graph isomorphism problem [5, 6, 11, 20]. It has long been recognised that the WL algorithm has a close connection with finite variable counting logics [11, 26]. Only recently, several remarkable connections of the WL algorithm to other areas have surfaced [2–4, 9, 15, 16, 29], and building on them applications ranging from linear optimisation to machine learning [22, 42, 43, 52, 58].

The 1-dimensional version of the WL algorithm, which is essentially the same as the *colour refinement algorithm*, has been re-invented several times; the oldest reference I am aware of is [41]. The 2-dimensional version, also known as the *classical* Weisfeiler-Leman algorithm, has been introduced by Weisfeiler and Leman [56], and the *k*-dimensional generalisation goes back to Babai and Mathon (see [11]).

Let us start by introducing the *colour refinement algorithm*, which is also known as *naive vertex classification*. As I said, it is essentially the same as the 1-dimensional WL algorithm, but there is a subtle difference that will be relevant for us

here. The basic idea is to label vertices of the graph with their iterated degree sequence. More precisely, the initial colouring given by the vertex labels in a graph is repeatedly refined by counting, for each colour, the number of neighbours of that colour. For every graph G, we define a sequence of vertex colourings  $\operatorname{Cr}^{(t)}(G)$  as follows: for every  $v \in V(G)$ , we let  $\operatorname{Cr}^{(0)}(G,v) := \operatorname{Col}(G,v)$  and

$$\mathrm{cr}^{(t+1)}(G,v) \coloneqq \Big(\mathrm{cr}^{(t)}(G,v), \big\{\!\!\big\{ \mathrm{cr}^{(t)}(G,w) \bigm| w \in N(v) \big\}\!\!\Big\} \Big).$$

Thus for vertices  $v,v' \in V(G)$  we have  $\operatorname{cr}^{(t+1)}(G,v) = \operatorname{cr}^{(t+1)}(G,v')$  if and only if for every colour c in the range of  $\operatorname{cr}^{(t)}(G)$  the vertices v and v' have the same number of neighbours w with  $\operatorname{cr}^{(t)}(G,w) = c$ .

In each round, the algorithm computes a colouring that is finer than the one computed in the previous round, that is,  $\operatorname{Cr}^{(t+1)}(G) \preceq \operatorname{Cr}^{(t)}(G)$ . For some t < n := |G|, this procedure stabilises, meaning the colouring does not become strictly finer anymore. Hence, there is a least  $t_\infty < n$  such that  $\operatorname{Cr}^{(t_\infty+1)}(G) \equiv \operatorname{Cr}^{(t_\infty)}(G)$ . We call  $\operatorname{Cr}^{(t_\infty)}(G)$  the *stable colouring* and denote it by  $\operatorname{Cr}^{(\infty)}(G)$ .

It is easy to see that for every  $t \in \mathbb{N} \cup \{\infty\}$ , the mapping  $\operatorname{cr}^{(t)}$  is equivariant; in other words:  $\operatorname{cr}^{(t)}$  is a vertex invariant.

**Example V.1.** The stable colouring  $Cr^{(\infty)}$  does not distinguish the two graphs in Figure 1. Neither does it distinguish a cycle of length 6 from a pair of triangles.

Thus the invariant  $cr^{(\infty)}$  is not complete.

The colour refinement algorithm is very efficient. The stable colouring of a graph can be computed in time  $O((n+m)\log n)$ , where n denotes the number of vertices and m the number of edges of the input graph [12] (also see [47])<sup>3</sup>. For a natural class of partitioning algorithms, this is best-possible [8].

Let us now turn to the k-dimensional Weisfeiler-Leman algorithm (k-WL). It defines a sequence of k-ary invariants  $\mathsf{Wl}_k^{(t)}$  for  $t \in \mathbb{N} \cup \{\infty\}$ . For every graph G and  $v \in V(G)^k$ , we let  $\mathsf{Wl}_k^{(0)}(G,v) \coloneqq \mathsf{atp}_k(G,v)$  and

$$\operatorname{Wl}_k^{(t+1)}(G, \boldsymbol{v}) \coloneqq \left(\operatorname{Wl}_k^{(t)}(G, \boldsymbol{v}), M\right)$$

with

$$\begin{split} M &= \Big\{\!\!\!\Big\{ \Big( \mathrm{atp}_{k+1}(G, \boldsymbol{v}w), \mathrm{WI}_k^{(t)} \big(G, \boldsymbol{v}[w/1] \big), \\ & \mathrm{WI}_k^{(t)} \big(G, \boldsymbol{v}[w/2] \big), \\ & \vdots \\ & \mathrm{WI}_k^{(t)} \big(G, \boldsymbol{v}[w/k] \big) \Big) \; \Big| \; w \in V(G) \Big\}\!\!\!\!\Big\}. \end{split}$$

Recall the notation  $v[w/i] = (v_1, \dots, v_{i-1}, w, v_{i+1}, \dots v_k)$ . Then there is a least  $t_\infty < n^k$  such that  $\operatorname{Wl}_k^{(t_\infty)}(G) \equiv \operatorname{Wl}_k^{(t_\infty+1)}(G)$ , and we call  $\operatorname{Wl}_k^{(\infty)}(G) \coloneqq \operatorname{Wl}_k^{(t_\infty)}(G)$  the k-stable

<sup>3</sup>To be precise, the algorithms computes the partition of the vertex set corresponding to the stable colouring, not the actual colours viewed as multisets.

![](_page_4_Figure_0.jpeg)

Fig. 2. Two non-isomorphic strongly regular graphs with parameters (16, 6, 2, 2): the line graph of  $K_{4,4}$  (left) and the Shrikhande Graph (right).

colouring. The k-stable colouring of an n-vertex graph can be computed in time  $O(k^2n^{k+1}\log n)$  [26].

Recall that an invariant is *complete* if two tuples receive the same colour if and only if there is an isomorphism mapping one to the other and that an invariant *distinguishes* two graphs if they get the same multiset of colours. If an invariant is complete, then it distinguishes any two non-isomorphic graphs. The following example shows that neither 1-WL nor 2-WL are complete.

- **Example V.2.** (1) Let G, G' be regular graphs of the same degree, for example a cycle of length 6 and the union of two triangles. Then  $\mathsf{Wl}_1^{(\infty)}$  does not distinguish G and G'.
- (2) Let G, G' be strongly regular graphs with the same parameters (see Figure 2). Then  $\operatorname{Wl}_2^{(\infty)}$  does not distinguish G and G'.

In a seminal paper, Cai, Fürer, and Immerman [11] proved that  $\operatorname{Wl}_k^{(\infty)}$  is incomplete for  $k \geq 3$ .

**Theorem V.3** ([11]). For every  $k \geq 3$  there are non-isomorphic 3-regular graphs of order O(k) that  $\operatorname{Wl}_k^{(\infty)}$  does not distinguish.

The next proposition and the following remark clarify the relation between colour refinement and 1-WL.

**Proposition V.4.** For all  $t \in \mathbb{N} \cup \{\infty\}$ , graphs G, G' are distinguished by  $\operatorname{cr}^{(t)}$  if and only if they are distinguished by  $\operatorname{Wl}_1^{(t)}$ .

Proof sketch. Observe that the difference between colour refinement and 1-WL is that  $\operatorname{cr}^{(t+1)}(G)$  only counts neighbours of a node v in each colour class of  $\operatorname{cr}^{(t)}(G)$  to determine  $\operatorname{cr}^{(t+1)}(G,v)$ , whereas  $\operatorname{Wl}_1^{(t+1)}(G)$  counts both neighbours and non-neighbours of v in each colour class of  $\operatorname{Wl}_1^{(t)}(G)$  to determine  $\operatorname{Wl}_1^{(t+1)}(G,v)$ .

Now the idea is that if we have a one-to-one correspondence between the colours in the range of  $\operatorname{cr}^{(t)}(G)$  and  $\operatorname{Wl}_1^{(t)}(G)$  and all corresponding colour classes have the same sizes in G and G', then it is enough to count neighbours in each colour class because the number of non-neighbours in a colour class is the size of the class minus the number of neighbours.

We can easily turn this intuition into an inductive proof.  $\Box$ 

Remark V.5. It can be proved similarly to Proposition V.4 that for all graphs G and all vertices v, v' of G we have

$$\operatorname{cr}^{(t)}(G, v) = \operatorname{cr}^{(t)}(G, v') \iff \operatorname{wl}_{1}^{(t)}(G, v) = \operatorname{wl}_{1}^{(t)}(G, v').$$

But note that  $\operatorname{Cr}^{(t)}(G,v) = \operatorname{Cr}^{(t)}(G',v')$  does not imply  $\operatorname{Wl}_1^{(t)}(G,v) = \operatorname{Wl}_1^{(t)}(G',v')$  for distinct graph G,G'. As an example, let G,G' be cycles of different lengths and v,v' arbitrary vertices. Then for all  $t \in \mathbb{N}$  it holds that  $\operatorname{Cr}^{(t)}(G,v) = \operatorname{Cr}^{(t)}(G,v')$ , but  $\operatorname{Wl}_1^{(t)}(G,v) \neq \operatorname{Wl}_1^{(t)}(G',v')$  for  $t \geq 1$ .

There is a variant of the WL algorithm that can also be found in the literature (for example, [21]). We call it *oblivious WL*. It is somewhat simpler, and it has the advantage of being closer to both the logical characterisation of WL and higher-order graph neural networks. Its main disadvantage is that it is less efficient. To reach the same expressive power as k-WL, oblivious WL needs to operate on on (k+1)-tuples and thus needs memory space  $\Omega(n^{k+1})$ , whereas k-WL only needs space  $O(n^k)$ .

Oblivious k-WL defines a sequence of k-ary invariants  $\mathsf{oWl}_k^{(t)}$  for  $t \in \mathbb{N} \cup \{\infty\}$ . For every graph G and  $v \in V(G)^k$ , we let  $\mathsf{oWl}_k^{(0)}(G, v) \coloneqq \mathsf{atp}_k(G, v)$  and

$$\begin{split} \operatorname{owl}_k^{(t+1)}(G, \boldsymbol{v}) \coloneqq \\ & \left( \operatorname{owl}_k^{(t)}(G, \boldsymbol{v}), \ \left\{ \operatorname{owl}_k^{(t)} \left( G, \boldsymbol{v}[w/1] \right) \;\middle|\; w \in V(G) \right\}, \\ & \left\{ \operatorname{owl}_k^{(t)} \left( G, \boldsymbol{v}[w/2] \right) \;\middle|\; w \in V(G) \right\}, \\ & \vdots \\ & \left\{ \operatorname{owl}_k^{(t)} \left( G, \boldsymbol{v}[w/k] \right) \;\middle|\; w \in V(G) \right\} \right). \end{split}$$

Then we can define the stable colouring  $\operatorname{owl}_k^{(\infty)}(G)$  in the same way as we did for colour refinement and standard WL.

The difference between oblivious WL and standard WL is that when we substitute a vertex w in the ith place of v in oblivious WL, we forget about the context, that is, the entry  $v_i$  we substitute as well as the colours that we obtain if we substitute other entries of v by w. Standard WL considers all these colours together, whereas oblivious WL is oblivious to the context (hence the name). It turns out that the price for obliviousness is an increase of the dimension by 1.

**Theorem V.6.** Let  $k \geq 1$ . Then for all  $t \in \mathbb{N}$  and all graphs G(G').

- (1) if G, G' are distinguished by  $\mathbf{Wl}_k^{(t)}$  then they are distinguished by  $\mathbf{OWl}_{k+1}^{(t)}$ ;
- (2) if G, G' are distinguished by  $\operatorname{owl}_{k+1}^{(t)}$  then they are distinguished by  $\operatorname{wl}_k^{(t+1)}$ .

This theorem follows from the logical characterisation of k-WL [11, 26], which we will discuss below, but I am not aware of an explicit reference or direct proof of the result. Therefore, I find it worthwhile to include a proof as an appendix.

**Corollary V.7.** Let  $k \geq 1$ . Then graphs G, G' are distinguished by  $\mathsf{Wl}_k^{(\infty)}$  if and only if they are distinguished by  $\mathsf{OWl}_{k+1}^{(\infty)}$ .

Let us now turn to the logical characterisation of the WLalgorithm.

**Theorem V.8** ([11]). Let  $k \ge 2$  and  $t \ge 0$ . Then for all graphs G, G' and tuples  $v \in V(G)^k, v' \in V(G')^k$  the following are equivalent:

- (i)  $\operatorname{owl}_{k}^{(t)}(G, \boldsymbol{v}) = \operatorname{owl}_{k}^{(t)}(G', \boldsymbol{v}');$
- (ii) for all formulas  $\varphi(x) \in \mathsf{C}_k^{(t)}$

$$G \models \varphi(\mathbf{v}) \iff G' \models \varphi(\mathbf{v}').$$

We omit the proof, of this result. Intuitively, a formula  $\varphi(x_1,\ldots,x_k)\in \mathsf{C}_k^{(t+1)}$  is a Boolean combination of atomic formulas and formulas of the form  $\exists^{\geq p} x_i \psi(x_1, \dots, x_k)$ , where  $\psi(x_1,\ldots,x_k)\in \mathsf{C}_k^{(t)}$ . The *i*th multiset in the definition of  $\mathsf{OWI}_{L}^{(t+1)}$  takes care of these formulas.

From the Theorem V.8 and Corollary V.7, we obtain the following characterisation of the the indistinguishability of graphs.

**Corollary V.9.** Let  $k \geq 1$ . The for all graphs G, G' the following are equivalent:

- (i)  $\operatorname{Wl}_{L}^{(\infty)}$  does not distinguish G and G';
- (ii)  $\operatorname{owl}_{k+1}^{(\infty)}$  does not distinguish G and G'; (iii) G and G' satisfy the same  $\mathsf{C}_{k+1}$ -sentences.

Combined with Proposition V.4, Corollary V.9 also yields a characterisation of distinguishability of graphs by colour refinement in terms of the logic  $C_2$ , but only on the levels of graphs. On the node level,  $C_2$  is not the correct logic to characterise colour refinement. Instead, it is the guarded fragment GC<sub>2</sub>. Intuitively, this is clear, because just like the guarded logic, colour refinement only has access to the neighbours of a node.

**Theorem V.10.** Let  $t \geq 0$ . Then for all graphs G, G' and vertices  $v \in V(G), v' \in V(G')$  the following are equivalent:

- (i)  $\operatorname{cr}^{(t)}(G, v) = \operatorname{cr}^{(t)}(G', v');$
- (ii) for all formulas  $\varphi(x) \in \mathsf{GC}_2^{(t)}$

$$G \models \varphi(v) \iff G' \models \varphi(v').$$

This theorem is obvious to researchers in the field, and it is implicit in [7], but for the reader's convenience I have included a proof in the appendix.

Remark V.11. The definitions of  $\mathbf{Wl}_k^{(t)}$  and  $\mathbf{OWl}_k^{(t)}$  remain valid without any changes for arbitrary relational structures if we adapt the definition of atomic types as described in Remark IV.3. Theorems V.6 and V.8 as well as their corollaries also hold in this more general setting.

There is one interesting observation that will be useful later: we can interpret  $\operatorname{owl}_k^{(t)}$  over a graph (or binary structure) Gas  $\mathsf{wl}_1^{(t)}$  over a structure  $A_G$  with

- vertex set  $V(A_G) := V(G)^k$ ,
- binary relations  $E_1(A_G), \ldots, E_k(A_G)$ , where  $E_i(A_G)$ contains all pairs (v, v') of tuples that differ exactly in the *i*-the component (that is  $v_i \neq v'_i$  and  $v_j = v'_j$  for  $j \neq i$ ),

• unary relations  $P_{\theta}(G)$  for all  $\theta \in \{0,1\}^{2\binom{k}{2}+k\ell}$ , where  $\ell$  is the number of labels of G, containing all v with  $atp_{\iota}(G, \boldsymbol{v}) = \theta.$ 

Then it is easy to prove that for all graphs G, G', all tuples  $v \in V(G)^k, v' \in V(G')^k$ , and all  $t \in \mathbb{N} \cup \{\infty\}$  it holds that  $\mathsf{owl}_k^{(t)}(G, oldsymbol{v}) = \mathsf{owl}_k^{(t)}(G', oldsymbol{v}')$  if and only if  $\mathsf{wl}_1^{(t)}(A_G, oldsymbol{v}) =$  $\mathsf{Wl}_1^{(t)}(A_{G'}, v')$ . This observation goes back to [45].

## VI. THE EXPRESSIVENESS OF FEED-FORWARD NEURAL **NETWORKS**

Before we discuss graph neural networks, we need to look into standard fully-connected feed-forward neural networks (FNNs). An FNN layer of input dimension m and output dimension n computes a function from  $\mathbb{R}^m$  to  $\mathbb{R}^n$  of the form

$$\sigma(Ax + b)$$

for a weight matrix  $A \in \mathbb{R}^{n \times m}$ , a bias vector  $\mathbf{b} \in \mathbb{R}^n$ , and an activation function  $\sigma: \mathbb{R} \to \mathbb{R}$  that is applied pointwise to the vector Ax + b.

An *FNN* is a tuple  $(L^{(1)}, \ldots, L^{(d)})$  of FNN layers, where the output dimension  $n^{(i)}$  of  $L^{(i)}$  matches the input dimension  $m^{(i+1)}$  of  $L^{(i+1)}$ . Then the FNN computes a function from  $\mathbb{R}^{m^{(1)}}$  to  $\mathbb{R}^{n^{(d)}}$ , the composition  $f^{(d)} \circ \cdots \circ f^{(1)}$  of the functions  $f^{(i)}$  computed by the d layers.

Typical activation functions used in practice are the logistic function  $sig(x) := \frac{1}{1+e^{-x}}$  (a.k.a. sigmoid function), the hyperbolic tangent  $\tanh(x) \coloneqq \frac{e^x - e^{-x}}{e^x + e^{-x}}$ , and the rectified linear unit  $relu(x) := max\{x, 0\}$ . For theoretical results, it is sometimes convenient to work with the linearised sigmoid lsig(x) := $\min\{\max\{x,0\},1\}$ . It is not important for us which activation function we use. We only assume the activation function to be continuous. This implies that functions computed by FNNs are continuous. Moreover, we want at least some layers of our FNNs to have activation functions that are not polynomial (in order for Theorem VI.1 to apply). Sometimes, we impose further restrictions.

In a machine learning setting, we only fix the shape or architecture of the neural network and learn the weights. Formally, we say that an FNN architecture is a tuple  $(n^{(0)},\ldots,n^{(d)},\sigma^{(1)},\ldots,\sigma^{(d)})$  for positive integers d and  $n^{(i)}$ and functions  $\sigma^{(i)}: \mathbb{R} \to \mathbb{R}$ . We can view an FNN architecture as a parametric model; the parameters are the entries of the weight matrices  $A^{(i)} \in \mathbb{R}^{n^{(i)} \times n^{(i-1)}}$  and bias vectors  $\boldsymbol{b}^{(i)} \in$ that turn the architecture into an FNN defining a function  $\mathbb{R}^{n^{(0)}} o \mathbb{R}^{n^{(d)}}$ . The learning task is to set the parameters in a way that the resulting FNN approximates an unknown target function  $f: \mathbb{R}^{n^{(0)}} \to \mathbb{R}^{n^{(d)}}$ . Access to this unknown function is provided through a set of labelled examples (x, f(x)). We cast the learning problem as a minimisation problem: we minimise a loss function that essentially measures the difference between the function computed by the FNN and the target function on the examples we are given. This is a difficult optimisation problem, non-linear and not even convex, but it can be solved remarkably well in practice using gradientdescent based algorithms.

So formally we distinguish between FNN architectures  $\mathcal{N}$ , FNNs N obtained from an FNN architecture by instantiating all the parameters (the weight matrices and bias vectors), and the functions  $f_N$  computed by FNNs N. For an FNN architecture  $\mathcal{N}$ , we let  $\mathcal{F}_{\mathcal{N}}$  be the class of all functions  $f_N$  computed by the FNNs N that we obtain by instantiating the parameters of  $\mathcal{N}$ . For an FNN or FNN architecture, we call d (the number of layers) the depth and  $\sum_{i=1}^d n^{(i)}$  the size. We call  $n^{(0)}$  the input dimension and  $n^{(d)}$  the output dimension, and for  $i \in [d]$  we call  $n^{(i)}$  the dimension of layer i. The width of the network or network architecture is  $\max_{i \in [d]} n^{(i)}$ .

Our focus in this paper is not on learning but on the *expressiveness* of FNNs and other neural network architectures, that is, on the question which functions can be computed by such neural networks in principle. A fundamental expressiveness result for FNNs is the following *universal approximation theorem*.

**Theorem VI.1** ([14, 24, 33]). Let  $\sigma : \mathbb{R} \to \mathbb{R}$  be continuous and not polynomial. Then for every continuous function  $f : \mathbb{R}^m \to \mathbb{R}^n$ , every compact set  $K \subseteq \mathbb{R}^m$ , and every  $\varepsilon > 0$  there is a depth-2 FNN N with activation function  $\sigma^{(1)} = \sigma$  on layer 1 and no activation function on layer 2 (that is,  $\sigma^{(2)}$  is the identity function) computing a function  $f_N$  such that

$$\sup_{\boldsymbol{x}\in K}\|f(\boldsymbol{x})-f_N(\boldsymbol{x})\|<\varepsilon.$$

This seems to make neural networks extremely expressive. However, the approximation of continuous functions on a compact domain implicitly comes with a finiteness condition. Also, note that we put no restriction on the dimension  $n^{(1)}$  of the first layer;  $n^{(1)}$  may depend on the function f, and it may do so in a way that is exponential in a description of f.

One way of formally capturing the limitations of FNNs is to look at the VC dimension of families of sets decided by such networks. Let  $\mathcal{C} \subseteq 2^{\mathbb{X}}$  be a set of subsets of some set  $\mathbb{X}$  (in the case of FNNs,  $\mathbb{X} = \mathbb{R}^n$ ). We say that  $X \subseteq \mathbb{X}$  is *shattered* by  $\mathcal{C}$  if for every subset  $Y \subseteq X$  there is a  $C \in \mathcal{C}$  such that  $C \cap X = Y$ . The *Vapnik Chervonenkis (VC) dimension* [55] of  $\mathcal{C}$  is the maximum size of a finite set shattered by  $\mathcal{C}$ , or  $\infty$  if this maximum does not exist. For an FNN architecture  $\mathcal{N}$  of input dimension n and output dimension 1, we let  $\mathcal{C}_{\mathcal{N}}$  be the set of all sets  $C_f := \{x \in \mathbb{R}^n \mid f(x) > 0\}$  for  $f \in \mathcal{F}_{\mathcal{N}}$ .

For a wide class of *Pfaffian functions* that includes all the activation functions discussed above, we have the following bound on the VC dimension of FNN architectures.

**Theorem VI.2** ([28]). Let  $\mathcal{N}$  be an FNN architecture (of output dimension 1) whose activation functions are Pfaffian functions. Then the VC dimension of  $\mathcal{C}_{\mathcal{N}}$  is polynomial in the size of  $\mathcal{N}$  (where the polynomial depends on the specific activation functions used).

While it limits the expressiveness of FNNs, from the perspective of machine learning, this theorem should be viewed as a positive result. The reason is that the number of labelled examples required to give statistical approximation guarantees

in the PAC model [54] for the FNN learned from the examples can be bounded linearly in terms of the VC dimension [10].

As a computation model, FNNs are similar to Boolean circuits, except that they do "analog" computations using arbitrary real numbers as weights. The question arises if such analog circuits are more expressive than Boolean circuits. In general, they are, but surprisingly they are not if we restrict the activation functions that can be used to be piecewise polynomial. It can be shown that properties decided by families of FNNs of bounded depth and polynomial size with piecewise polynomial activation functions belong to  $TC^0$  [36]. Recall that  $TC^0$  is the class of all properties decidable by a family of Boolean threshold circuits of bounded depths and polynomial size. In threshold circuits, we have threshold gates that output 1 if at least t of their inputs are 1, for some t.

## VII. GRAPH NEURAL NETWORKS

Let us consider a machine learning scenario on graphs where we want to learn a function defined on graphs, vertices, or tuples of vertices. We usually think of a supervised learning scenario, where we want to learn an unknown function from labelled examples, but an equally important scenario is that of learning a representation of graphs or their vertices. *Crucially, we want these functions to be invariants.*<sup>4</sup>

In both the supervised and representation learning scenarios we "learn" models representing the functions, and we want to guarantee that the functions represented by our models are invariants. We could train FNNs taking as inputs the adjacency matrices of graphs, but it would be difficult to ensure invariance. Graph neural networks (GNNs) are neural network architectures that guarantee invariance by their design.

Many different versions of the GNNs have been considered in the literature (see, for example, [18, 19, 23, 32, 50]). Here, we focus on what seems to be a standard, core model. It sometimes goes under the name "message passing neural network (MPNN)" [19] or "aggregate-combine graph neural network (AC-GNN)" [7].

#### A. GNNs as a Computation Model

A *GNN layer* of input dimension p and output dimension q is defined by specifying two functions: an *aggregation function* agg mapping finite multisets of vectors in  $\mathbb{R}^p$  to vectors in  $\mathbb{R}^{p'}$ , and a *combination function* comb:  $\mathbb{R}^{p+p'} \to \mathbb{R}^q$ . A GNN is a tuple  $(L^{(1)},\ldots,L^{(d)})$  of GNN layers, where the output dimension  $q^{(i)}$  of  $L^{(i)}$  matches the input dimension  $p^{(i+1)}$  of  $L^{(i+1)}$ . We call  $p^{(i)} := p^{(i)}$  the input dimension of the GNN and  $p^{(i)}$  the output dimension.

To define the semantics, recall that we call mappings  $\zeta: V(G) \to \mathbb{R}^p$  p-dimensional feature maps. Let L be a GNN layer of input dimension p and output dimension q with aggregation function agg and combination function comb.

 $^4$ To avoid confusion here with respect to the usage of invariant and equivariant neural networks in the machine learning literature, recall that we defined a *vertex invariant* to be an *equivariant* function that associates a function defined on V(G) with each graph G, and more generally a k-ary invariant to be an equivariant function that associates a function defined on  $V(G)^k$  with each graph G.

Applied to a graph G, it transforms a p-dimensional feature map  $\zeta$  to a q-dimensional feature map  $\eta$  defined by

$$\eta(v) \coloneqq \mathsf{comb}\Big(\zeta(v), \mathsf{agg}\big(\big\{\!\!\big\{\zeta(w) \bigm| w \in N^G(v)\big\}\!\!\big\}\big)\Big). \quad (\mathsf{A})$$

Computationally, it may be useful to think of the features  $\zeta(v)$  of the vertices as states. Then the feature transformation computed by the GNN layer is based on a simple distributed message passing protocol whose computation nodes are the vertices of our graph: each node v sends its state  $\zeta(v)$  to all its neighbours. Upon receiving the state  $\zeta(w)$  of its neighbours, node v applies the aggregation function agg to the multiset of these states, yielding a vector  $\alpha(v)$  and then uses the combination function comb to compute the new state  $\eta(v)$  from  $\zeta(v)$  and  $\alpha(v)$ .

Observe that this transformation is isomorphism invariant: for graphs G,G' and feature maps  $\zeta\in\mathcal{F}_p(G),\zeta'\in\mathcal{F}_p(G')$  transformed by L to feature maps  $\eta,\eta',$  if f is an isomorphism from G to G' satisfying  $\zeta(v)=\zeta'(f(v))$  for all  $v\in V(G)$ , then  $\eta(v)=\eta'(f(v))$  for all  $v\in V(G)$ .

A GNN consisting of layers  $L^{(1)},\ldots,L^{(d)}$  composes the feature transformations computed by all its layers. Thus if the input dimension of  $L^{(0)}$  is  $q^{(0)}$  and the output dimension of  $L^{(d)}$  is  $q^{(d)}$ , on a graph G it transforms  $q^{(0)}$ -dimensional feature maps  $\zeta^{(0)}$  to  $q^{(d)}$ -dimensional feature maps  $\zeta^{(d)}$ . We usually denote the intermediates feature maps obtained by applying the layers  $L^{(0)},\ldots,L^{(t)}$  to the initial feature map  $\zeta^{(0)}$  by  $\zeta^{(t)}$ . Then clearly, the transformation  $\zeta^{(0)}\mapsto \zeta^{(t)}$  is isomorphism invariant for all t.

There is an alternative mode of operation of GNNs where we do not have a fixed number of layers but repeatedly apply the same layer. A recurrent GNN consists of a single GNN layer with the same input and output dimension q. Applied to an initial q-dimensional feature map  $\zeta^{(0)}$ , it yields an infinite sequence  $\zeta^{(1)}, \zeta^{(2)}, \ldots$  of q-dimensional feature maps, where  $\zeta^{(t+1)}$  is obtained by applying the GNN layer to  $(G, \zeta^{(t)})$ . Again, the transformation  $\zeta^{(0)} \mapsto \zeta^{(t)}$  is isomorphism invariant for all t. Note that we do not impose any convergence requirements on the sequence  $\zeta^{(1)}, \zeta^{(2)}, \ldots$ ; typically, there will be no convergence.

In the end, we usually do not want to compute feature transformations but functions defined on graphs (graph invariants) or on the vertices of graphs (vertex invariants). The features are only supposed to be internal representations. Towards this end, we choose the initial feature map  $\zeta^{(0)}$  to represent the labelling of the input graph G. That is, we let  $\zeta^{(0)} \coloneqq \operatorname{col}(G)$  possibly padded by 0s to reach the input dimension of our GNN. We always assume that the input dimension  $q^{(0)}$  of the GNN is at least the label number  $\ell$  of the input graphs. In Section XI we shall discuss GNNs with random initialisation, where we pad the initial feature with random numbers.

If we want to define a vertex invariant with range  $\mathbb{Y}$ , we define a readout function  $\mathsf{ro}:\mathbb{R}^{q^{(d)}}\to\mathbb{Y}$  that we apply to the final feature  $\zeta^{(d)}(v)$  of every node. For recurrent GNNs, we need to fix the number d=d(G) of iterations we take; it may depend on the input graph. Then the (recurrent) GNN

maps a graph G to  $ro(\zeta^{(d)})$ . The readout function ro is part of the specification of a GNN (or GNN architecture), and for a recurrent GNN the function d also needs to be specified.

If we want to use our GNN to compute a graph invariant, say, also with range  $\mathbb{Y}$ , we need to specify an *aggregate* readout function aggro mapping finite multisets of vectors in  $\mathbb{R}^{q^{(d)}}$  to  $\mathbb{Y}$ , and we apply aggro to the multiset of all nodes' output features. So the GNN maps G to

$$\operatorname{aggro}\Big(\big\{\!\!\big\{\zeta^{(d)}(v) \bigm| v \in V(G)\big\}\!\!\big\}\Big).$$

Again, for recurrent GNNs we need to specify d = d(G).

# B. Learning GNNs

As defined so far, GNNs are just distributed algorithms. What turns them into neural network models is that the aggregation, combination, and readout functions are learned functions represented by neural networks.

It is clear how to do this for the combination and readout functions. For the theoretical analysis carried out in this paper it suffices to assume that comb and ro are computed by FNNs of depth 2 with a non-polynomial activation function on the interior layer. Then by Theorem VI.1, we can approximate arbitrary continuous functions by comb and ro. In the literature, it is sometimes assumed that comb is computed by a single FNN layer, for example, in the "simple GNNs" of [7]. We do not make this assumption here. Several FNN layers in comb can always be simulated by several "simple" GNN layers, so this does not change the expressiveness of the model. However, allowing several layers and thereby a direct application of the universal approximation property of FNNs makes our analysis simpler and cleaner.

Next, let us look at the aggregation function agg. Here we have the difficulty that it is not defined on vectors, but on multisets of vectors. In general, we can think of the aggregation function as being composed of three functions:

- a "message function"  $\operatorname{msg}: \mathbb{R}^p \to \mathbb{R}^{p''}$  that takes the states of the neighbours and distills from them the messages send,
- an actual aggregation function aa from finite multisets over  $\mathbb{R}^{p''}$  to  $\mathbb{R}^{p''}$  that combines the multiset of messages received into a single vector,
- a post-processing function  $pp : \mathbb{R}^{p''} \to \mathbb{R}^{p'}$ , which is passed on to the combination function.

The aggregation aa is usually a fixed function, typically the sum, maximum, or arithmetic mean of the elements of the multiset. We always use summation as aggregation. It has been proved in [58] that summation is more expressive than max or mean and sufficient to realise the full expressiveness of GNNs (at least from the perspective from which we analyse GNNs here). The message function msg and post-processing function pp can be learned functions; we could assume them to be represented by a FNNs. However, at least in theory we do not need the functions msg and pp at all, because we can merge msg into the combination function of the previous GNN-layer (formally, by writing the message to designated coordinates of

the feature vector), and we can merge pp into the combination function of the current layer. Thus, in the following, we assume that agg is simply the summation function. Then a single GNN layer (cf. (A)) maps a feature map ζ to the feature map η defined by

$$\eta(v) := \mathsf{comb}\Big(\zeta(v), \sum_{w \in N^G(v)} \zeta(w)\Big), \tag{B}$$

where comb is a function represented by an FNN.

Let me remark that in practice, one typically uses a learned linear messaging function msg, so the summation in (B) becomes P <sup>w</sup>∈NG(v) Aζ(w) for a weight matrix A.

Finally, if we need an aggregate readout function aggro, we take it to be the summation of the feature vectors in the multiset it receives followed by some post-processing function represented by an FNN.

Having specified the functions comb, agg, ro, aggro this way, we can now describe their FNN architectures, and we can combine these into a *GNN architecture*. Then we can learn the parameters of such a GNN architecture from labeled examples using the same techniques as for FNNs. However, as for FNNs, we are mainly concerned with expressiveness questions here.

# *C. Variants*

Numerous variants of our basic message passing GNN model have been suggested in the literature; I refer the reader to the recent survey [57]. Let me briefly discuss a few variants that will be useful later in this paper.

We can define GNNs not only for undirected vertex-labelled graphs, as we do here, but also for directed graphs with possibly labelled edges, that is, for arbitrary binary relational structures. The easiest way to adapt GNNs to this setting is by introducing an explicit (learned) message function msg that not only depends on the current state of the source node of the message, but also on the type of edges and the direction they are traversed (see, for example, [51, 53]).

A second addition to the basic model that will be relevant for us is that of a *global readout*. As defined, the information a node receives during a GNN computation is inherently local. For example, a node can never receive any information about a node in a different connected component of the input graph. What we can do to mitigate this weakness is to provide aggregate global information to each node. The easiest way to do this is by modifying the update function (B) to

$$\eta(v) \coloneqq \mathsf{comb}\Big(\zeta(v), \sum_{w \in N^G(v)} \zeta(w), \sum_{w \in V(G)} \zeta(w)\Big). \tag{C}$$

Following [7], we call GNNs with this form of updates *GNNs with global readout*. An essentially equivalent mechanism to distribute global information is adding a *virtual node* connected to all other nodes of the graph [19].

A third variant of basic GNNs, *higher order GNNs*, will be discussed in Section X.

#### VIII. WEISFEILER AND LEMAN GO NEURAL

In this section, we shall prove that GNNs have exactly the same expressiveness as colour refinement when it comes to distinguishing graphs or their vertices.

Theorem VIII.1 ([43],[58]). *Let* d ≥ 1*, and let* ξ *be a vertex invariant computed by an* d*-layer GNN. Then* cr(d) *refines* ξ*, that is, for all graphs* G, G<sup>0</sup> *and vertices* v ∈ V (G), v<sup>0</sup> ∈ V (G<sup>0</sup> )*,*

$$\operatorname{cr}^{(d)}(G,v) = \operatorname{cr}^{(d)}(G',v') \implies \xi(G,v) = \xi(G',v').$$

This theorem holds regardless of the choice of the aggregation function agg and the combination function comb.

*Proof.* For 0 ≤ t ≤ d, let ζ (t) be the feature map computed by the first t layers of the GNN on G and G<sup>0</sup> . We assume that V (G) and V (G<sup>0</sup> ) are disjoint and use ζ (t) to denote the union of the feature maps on the two graphs. To further simplify the notation, for v ∈ V (G) ∪ V (G<sup>0</sup> ) we write cr(t) (v) instead of cr(t) (G, v) or cr(t) (G<sup>0</sup> , v).

We shall prove by induction on t that cr(t) refines ζ (t) . As ξ(G, v) = ro(ζ (d) (v)), this will imply the theorem.

For the base step, recall that the initial feature map ζ (0) as well as cr(0) = col just encode the label information of the graph. So let us consider the inductive step t → t + 1. By the induction hypothesis, cr(t) refines ζ (t) . Let v ∈ V (G), v<sup>0</sup> ∈ V (G<sup>0</sup> ) such that cr(t+1)(v) = cr(t+1)(v 0 ). Then cr(t) (v) = cr(t) (v 0 ) and

$$\!\! \big\{ \operatorname{Cr}^{(t)}(w) \bigm| w \in N^G(v) \big\} \!\! \big\} = \!\! \big\{ \operatorname{Cr}^{(t)}(w') \bigm| w \in N^{G'}(v') \big\} \!\! \big\}.$$

Thus, by the induction hypothesis, ζ (t) (v) = ζ (t) (v 0 ) and

$$\underbrace{\!\!\left\{\!\!\left\{\zeta^{(t)}(w) \mid w \in N^G(v)\right\}\!\!\right\}}_{=:M} = \underbrace{\!\left\{\!\!\left\{\zeta^{(t)}(w') \mid w \in N^{G'}(v')\right\}\!\!\right\}}_{=:M'}.$$

It follows that

$$\begin{split} \zeta^{(t+1)}(v) &= \mathsf{comb}\big(\zeta^{(t)}(v), \mathsf{agg}(M)\big) \\ &= \mathsf{comb}\big(\zeta^{(t)}(v'), \mathsf{agg}(M')\big) = \zeta^{(t+1)}(v'). \quad \Box \end{split}$$

Corollary VIII.2. *Let* ξ *be a vertex invariant computed by a recurrent GNN. Then* cr(∞) *refines* ξ*.*

Corollary VIII.3. *Let* ξ *be a graph invariant computed by a GNN (recurrent or not). Then for all graphs* G, G<sup>0</sup> *, if* ξ(G) 6= ξ(G<sup>0</sup> ) *then* cr(∞) *distinguishes* G *and* G<sup>0</sup> *.*

Let us now turn to the converse. The following theorem is a slight strengthening of a theorem due to [43, 58] in that we find a single recurrent GNN that captures all colour refinement iterations. The result is still not uniform because we need GNNs depending on the size of the input graphs.

Theorem VIII.4 ([43, 58]). *Let* n ∈ N*. Then there is a recurrent GNN such that for all* t ≤ n*, the vertex invariant* ξ (t) *computed in the* t*-th iteration of the GNN refines* cr(t) *on all graphs of order at most* n*.*

That is, for all graph G, G' of order at most n, all vertices  $v \in V(G), v' \in V(G')$ , and all  $t \in [n]$ :

$$\xi^{(t)}(G,v) = \xi^{(t)}(G',v') \implies \operatorname{cr}^{(t)}(G,v) = \operatorname{cr}^{(t)}(G',v').$$

The theorem even holds for the restricted GNN model with sum-aggregation, that is, with (B) as update operation.

In the proof of the theorem, we follow [58]. We need the following lemma.

**Lemma VIII.5 ([58]).** Let  $m \in \mathbb{N}$ , and let  $X \subseteq (0,1)$  be a nonempty finite set. Then there is a function  $f: X \to (0,1)$  with the following two properties:

- (1) for all multisets  $M \subseteq X$  of order at most m-1 we have  $\sum_{x \in M} f(x) < \min X$ ;
- (2) for all multisets  $M, M' \subseteq X$  of order at most m-1, if  $M \neq M'$  then  $\sum_{x \in M} f(x) \neq \sum_{x \in M'} f(x)$ .

*Proof.* Let  $x_1, x_2, \ldots, x_n$  be an enumeration of X, and let  $\varepsilon \coloneqq \min X$ . Choose  $k \in \mathbb{N}$  such that  $m^{-k} \le \varepsilon$  and define f by  $f(x_i) \coloneqq m^{-k-i}$ .

Let  $M \subseteq X$  be a multiset of order at most m-1, and let  $a_i$  be the multiplicity of  $x_i$  in M. Then  $a_i < m$ . We have  $\sum_{x \in M} f(x) = \sum_{i=1}^n a_i m^{-k-i}$ , or

$$0.\underbrace{0\ldots0}_{k \text{ times}} a_1 a_2 \ldots a_n.$$

in m-ary representation. It is clear that these numbers are strictly between 0 and  $\varepsilon$ , which implies (1), and that they are distinct for distinct multisets M, M', which implies (2).

Proof of Theorem VIII.4. Without loss of generality, we assume that  $n \ge 1$ . In this proof, we assume all graphs to be of order at most n. Recall that the range of col(G) is  $\{0,1\}^{\ell}$ .

Let  $g_0$  be an arbitrary injective mapping from  $\{0,1\}^{\ell}$  to (0,1), and let  $X_0 := g_0(\{0,1\}^{\ell})$ .

Now suppose that for some  $t \geq 0$  we have defined a finite set  $X_t \subseteq (0,1)$ . We choose a mapping  $f_t: X_t \to (0,1)$  according to Lemma VIII.5 with m:=2n and  $X:=X_t$ , and we let  $X_{t+1}$  be the set of all numbers  $\sum_{x\in M} f_t(x)$ , where  $M\subseteq X_t$  is a multiset of order at most 2n-1. Note that  $X_{t+1}\cap X_t=\emptyset$  by Lemma VIII.5(1).

Let  $Z_0 := \{0,1\}^\ell$  and  $Z_t := X_t \times \{0\}^{\ell-1}$  for  $t \in [n]$ . Then the  $Z_t$  are mutually disjoint finite subsets of  $\mathbb{R}^\ell$ . Let  $g: \mathbb{R}^\ell \to \mathbb{R}^\ell$  be a continuous function such that  $g(z) = (f_0(g_0(z)), 0, \dots, 0)$  for  $z \in Z_0$  and  $g(z) = (f_t(z_1), 0, \dots, 0)$  for  $z = (z_1, \dots, z_\ell) \in Z_t$  and  $t \in [n]$ . (We can always find a continuous function with given values on a finite set of arguments.)

Suppose first we have a recurrent GNN of dimension  $\ell$  with sum-aggregation and a combination function

$$\mathsf{comb}(\boldsymbol{x}, \boldsymbol{y}) \coloneqq g\left(\boldsymbol{x} + 2\boldsymbol{y}\right).$$

(this combination function cannot necessarily be represented by an FNN, but we will fix that later). Let G be a graph, and let  $\zeta^{(0)} = \text{COl}(G)$ , and let  $\zeta^{(1)}, \zeta^{(2)}, \ldots$  be the the sequence

of feature maps computed by this GNN. Then for all  $t \in [n]$  and  $v \in V(G)$  we have

$$\zeta^{(t)}(v) = g\left(\zeta^{(t-1)}(v) + 2\sum_{w \in N^G(v)} \zeta^{(t-1)}(w)\right).$$

This can be written as  $g\left(\sum_{z\in M} z\right)$  for the multiset

$$M \coloneqq \{\!\!\{ \zeta^{(t-1)}(v) \}\!\!\} \cup \{\!\!\{ \zeta^{(t-1)}(w), \zeta^{(t-1)}(w) \mid w \in N^G(v) \}\!\!\},$$

where the union of multisets adds the multiplicities of the elements in the two sets. Note that  $\zeta^{(t-1)}(v)$  can be retrieved from M as the only elements of odd multiplicity.

Now a straightforward induction shows that for all  $t \in [n]$  and  $v \in V(G)$  we have  $\zeta^{(t)}(v) = (f_t(x), 0, \dots, 0)$  for some  $x \in X_t$ . This implies that  $\zeta^{(t)}(v) + 2 \sum_{w \in N^G(v)} \zeta^{(t)}(w) = \zeta^{(t)}(v') + 2 \sum_{w' \in N^G(v')} \zeta^{(t)}(w')$  if and only if  $\zeta^{(t)}(v) = \zeta^{(t)}(v')$  and  $\{\zeta^{(t)}(w) \mid w \in N^G(v)\} = \{\zeta^{(t)}(w') \mid w' \in N^G(v')\}$ . In fact, this equality holds across graphs, that is, even if v' is from a different graph G'. From this, we can derive

$$\zeta^{(t)}(v) = \zeta^{(t)}(v') \implies \operatorname{cr}^{(t)}(v) = \operatorname{cr}^{(t)}(v')$$

by another simple induction. (To simplify the notation, we omit an explicit reference to the graphs here.)

This does not yet prove the theorem, because in our GNN we used the function g in the definition of the the combination function comb, and in general g cannot be represented by an FNN. However, using Theorem VI.1, we can approximate g by a 2-layer FNN on the compact set  $[0,1]^\ell$ , which contains all the  $Z_t$  that are relevant for us. With a sufficiently close approximation and some  $\varepsilon$ - $\delta$  magic, the argument still goes through.

Remark VIII.6. Theorem VIII.4 (in slightly different versions) was proved independently in [43] and [58]. It is interesting to compare the two versions of the theorem and their proofs. In a nutshell, we observe a tradeoff between generality and efficiency.

The proof from [58], which we presented here, is simpler and applies to a larger class of activation functions. The proof in [43] constructs the FNNs involved in the combination function of the GNN explicitly and does not use the universal approximation theorem. For this reason, it allows for a better control of the complexity of the FNN: it only requires a single layer FNN that is guaranteed to be of polynomial size, whereas the FNN we get out of the universal approximation theorem needs two layers and may be exponentially large in n. This means that [43] constructs a GNN of polynomial size that computes the colour refinement partitions. (The proof of [58] does not yield this result.) As for the encoding of the colour information: [43] uses integer vectors of linear size with numbers of linear bit-length, the proof from [58] we present here uses rational numbers of exponential bit length.

The size of the GNNs and related parameters like depth and width, which directly affect the complexity of inference and learning, definitely require close attention; several of the open questions stated in Section XII revolve around these complexity theoretic issues.

**Corollary VIII.7.** Let  $n \ge 1$ . Then there is a recurrent GNN such that for all graphs G, G' of order at most n, if  $\operatorname{cr}^{(\infty)}$  distinguishes G and G' then  $\xi(G) \ne \xi(G')$ , where  $\xi$  is the graph invariant computed by the GNN in n iterations.

As  $\mathsf{Wl}_1^{(t)}$  refines  $\mathsf{Cr}^{(t)}$ , in Theorem VIII.1 and its corollaries, we can replace colour refinement with the 1-dimensional WL algorithm. We can also do this in Corollary VIII.7, because by Proposition V.4 there is no difference in the power of  $\mathsf{Wl}_1^{(t)}$  and  $\mathsf{Cr}^{(t)}$  on the graph level. However, Theorem VIII.4 needs to be modified for 1-WL.

**Theorem VIII.8.** Let  $n \ge 1$ . Then there is a recurrent GNN with global readout such that for all  $t \in [n]$ , the vertex invariant  $\xi^{(t)}$  computed in the t-th iteration of the GNN refines  $\operatorname{Cr}^{(t)}$  on all graphs of order at most n.

The proof of this Theorem is an easy modification of the proof of Theorem VIII.4.

There is also a corresponding version of Theorem VIII.1 with 1-WL and GNNs with global readout. While these results are not explicitly stated elsewhere, it is fair to say that the main insight underlying them is from [7].

#### IX. THE LOGICAL EXPRESSIVENESS OF GNNS

The previous section's results fully characterise the distinguishing power of GNNs, both on the graph level and on the vertex level. However, the results are non-uniform because the GNNs depend on the size of the input graphs. They do not tell us which functions defined globally on all graphs are expressible by GNNs. In this section, we take a first step towards characterising these functions: we obtain a characterisation of all first-order queries expressible by GNNs.

A k-ary query is a k-ary invariant with range  $\{0,1\}$ . We can view 0-ary queries, also called Boolean queries, as isomorphism closed classes of graphs and k-ary queries for  $k \geq 1$  as equivariant mappings Q that map each graph G to a set  $Q(G) \subseteq V(G)^k$ . A formula  $\varphi(x)$  for some logic L expresses a k-ary query Q if for all graphs G and  $v \in V(G)^k$  we have  $G \models \varphi(v) \iff v \in Q(G)$ . We are mainly concerned with unary queries expressible in first-order logic here.

We say that a GNN expresses a unary query if it approximates the corresponding vertex invariant. Let us make this precise as follows. Suppose that  $\xi$  is the vertex invariant computed by the GNN. Then we say that the GNN expresses Q if there is an  $\varepsilon < 1/2$  such that for all graphs G and vertices  $v \in V(G)$ ,

$$\begin{cases} \xi(G, v) \ge 1 - \varepsilon & \text{if } v \in Q(G), \\ \xi(G, v) \le \varepsilon & \text{if } v \notin Q(G). \end{cases}$$
 (D)

Similarly, we can define a GNN computing a graph invariant to express a Boolean query.

**Theorem IX.1** ([7]). Let  $\Omega$  be a unary query expressible in graded modal logic  $GC_2$ . Then there is a GNN that expresses

In [7], the theorem is only proved for GNNs that use a linearised sigmoid lsig as activation function. The proof can easily be adapted to other standard activation functions such as sig, tanh, relu. However, it is not clear how to prove it for arbitrary non-polynomial activation functions like the results in the previous section. The reason is that due to the non-uniformity, we do not have an obvious compact domain where we can apply the universal approximation property of FNNs. We sketch a proof of the theorem using lsig.

*Proof sketch.* Let  $\varphi(x)$  be a  $GC_2$ -formula expressing  $\mathfrak Q$ . Let  $\psi_1(x),\dots,\psi_d(x)=\varphi(x)$  be a list of all subformulas of  $\varphi(x)$ , where we view guarded quantification as a single operation, that is, for  $\psi(x)=\exists^{\geq i}y(E(x,y)\to\psi'(y))$  we only consider the subformula  $\psi'(y)$ . We assume that the  $\psi_i(x)$  are sorted in a way compatible with the subformula order, that is, if  $\psi_i$  is a proper subformula of  $\psi_j$  then i< j. Furthermore, we assume that the first  $\ell$  formulas in the list are the label atoms  $P_i(x)$ .

We design a GNN with  $d-\ell$  layers, where the t-th layer has input dimension  $q^{(t-1)} \coloneqq \ell + t - 1$  and output dimension  $\ell + t$ . During the evaluation of the GNN on a graph G, the feature map  $\zeta^{(t)}$  is supposed to map each vertex v to a vector  $\zeta^{(t)}(v) = (z_1, \dots, z_{\ell+t}) \in \{0,1\}^{\ell+t}$ , where  $z_i = 1$  if and only if  $G \models \psi_i(v)$ . It is easy to define a combination function  $\operatorname{comb}^{(t)}$  achieving this. For example, if  $\psi_t = \exists^{\geq p} y(E(x,y) \to \psi_s(y))$  for some s < t, we must define  $\operatorname{comb}^{(t)} : \mathbb{R}^{\ell+t-1} \times \mathbb{R}^{\ell+t-1} \to \mathbb{R}^{\ell+t}$  in such a way that it maps  $\left(\zeta^{(t-1)}(v), \sum_{w \in N^G(v)} \zeta^{(t-1)}(w)\right)$  to the vector  $(z_1, \dots, z_{\ell+1})$ , where  $z_i = (\zeta^{(t-1)}(v))_i$  for  $i \in [\ell+t-1]$  and

$$z_{\ell+t} = \begin{cases} 1 & \text{if } \sum_{w \in N^G(v)} \left(\zeta^{(t-1)}(w)\right)_s \ge p, \\ 0 & \text{otherwise.} \end{cases}$$

To achieve this, we can let  $comb^{(t)} = lsig(Ax + b)$ , where

- A is the  $(\ell+t) \times (2(\ell+t-1))$ -matrix with entries  $A_{ii} = 1$ ,  $A_{ij} = 0$  for  $i \in [\ell+t-1], j \in [2(\ell+t-1)] \setminus \{i\}$  and  $A_{(\ell+t)(\ell+t-1+s)} = 1$ ,  $A_{(\ell+t)j} = 0$  for  $j \in [2(\ell+t-1)] \setminus \{\ell+t-1+s\}$ ,
- **b** is the vector with entries  $b_i = 0$  for  $i \in [\ell + t 1]$  and  $b_{\ell+t} = -p + 1$ .

Clearly, the converse of the theorem does not hold. For example, we can use a GNN to express the unary query "vertex v has twice as many neighbours with label  $P_1$  as it has neighbours with label  $P_2$ ", which is not expressible in graded modal logic. However, the theorem has an interesting partial converse.

**Theorem IX.2** ([7]). Let Q be a unary query expressible by a GNN and also expressible in first-order logic. Then Q is expressible in  $GC_2$ .

The proof of this result is based on a characterisation of  $GC_2$  as the fragment of first-order logic invariant under counting bisimulation [46].

Unsurprisingly, GNNs with global readout can express all properties that are expressible in the logic  $C_2$ . This corresponds precisely to the transition from colour refinement to 1-WL enabled by global readout in the previous section.

**Theorem IX.3** ([7]). Let Q be a Boolean or unary query expressible in  $C_2$ . Then there is a GNN with global readout that expresses Q.

#### X. HIGHER ORDER GNNS

Inspired by the correspondence between 1-WL and GNNs, Morris et al. [43] proposed higher-order GNNs, a deep learning architecture with an expressiveness corresponding to k-WL. The idea is to use the oblivious WL-version because oblivious WL on a graph G essentially operates on a binary structure  $A_G$  with vertex set  $V(G)^k$  (as we have seen in Remark V.11). We can define a k-GNN operating on a graph G to be a GNN operating on  $A_G$ , using the extension of GNNs to binary structures described in Section VII-C. It is important to note that nodes of the message passing network carrying out the k-GNN computation are k-tuples of vertices. We obtain the following theorem directly as a corollary to our earlier results.

## **Theorem X.1** ([43, 44]). Let $k \ge 2$ .

- (1) Let  $d \ge 1$ , and let  $\xi$  be a k-ary invariant computed by an d-layer k-GNN. Then  $\mathsf{OWl}_k^{(d)}$  refines  $\xi$ .
- (2) For all  $n \ge 1$  there is a recurrent k-GNN such that for all  $t \le n$  the vertex invariant  $\xi^{(t)}$  computed by the t-th iteration of the GNN refines  $OW_k^{(t)}$ .

It is important to note that k-GNNs correspond to k-dimensional oblivious WL and hence to (k-1)-dimensional WL; this can easily lead to confusion.

The version of k-GNNs described in [43] is slightly different. In particular, there is also a version that operates on k-element sets rather than k-tuples (which saves some memory). While there may be practical considerations leading to these alternative approaches, I believe the theoretical essence of k-GNNs is most transparent in the version we describe here.

Remark X.2. Since n-dimensional Weisfeiler-Leman characterises graphs of order n up to isomorphism, we can use n-GNNs as a universal invariant neural network architecture that is able to approximate all invariant and equivariant functions defined on graphs of order at most n. In fact, the higher-order GNNs are closely related to the invariant and equivariant graph networks introduced in [37, 38].

Interestingly, for many restricted graph classes, for example, all classes of graphs excluding a fixed graph as a minor [20], a constant order is already sufficient for the universality. In particular, all planar graph invariants can be expressed by 4-GNNs. This follows from the fact that 3-WL characterises all planar graphs up to isomorphism [30].

#### XI. RANDOM INITIALISATION

Instead of going to higher-order networks, which come with a substantial computational cost, random initialisation is another simple idea for increasing the expressiveness of GNNs, actually without a steep computational cost.

Recall that the initial feature map  $\zeta^{(0)}$  of a GNN operating on a graph G is a  $q^{(0)}$ -dimensional vector whose first  $\ell$  entries encode the vertex-labelling of G and whose remaining components are set to 0. In the following, we always assume that  $q^{(0)} > \ell$ . Instead of initialising the entries above  $\ell$  to 0, we initialise them with random numbers, say, drawn uniformly from the interval [0,1]. (For our theoretical considerations, the exact distribution is not important. In practice, it has some effect, see [1]). In the following, we speak of GNNs with random node initialisation (RNI). To avoid cumbersome terminology, let us assume that GNNs with RNI always admit global readout.

The computation of a GNN with RNI is no longer deterministic but becomes a random variable. Note that this random variable is isomorphism invariant. To express a query or invariant, we must quantify the error probability. We say that that a GNN with RNI computing a vertex invariant  $\xi$  (formally a random variable) expresses a unary query Q if there are  $\varepsilon, \delta < 1/2$  such that

$$\begin{cases} \Pr(\xi(G, v) \ge 1 - \varepsilon) \ge 1 - \delta & \text{if } v \in Q(G), \\ \Pr(\xi(G, v) \le \varepsilon) \ge 1 - \delta & \text{if } v \notin Q(G). \end{cases}$$
(E)

A similar definition can be made for Boolean queries.

To understand why GNNs with RNI can be more expressive than plain GNNs, think of the query asking if a vertex is in a triangle. Since 1-WL cannot detect triangles (cf. Example V.1), neither can GNNs. Intuitively, the reason is that a GNN never detects the origin of a message because vertices have no identifiers. However, random initialisation with high probability provides each node v with a unique identifier (the entry in the  $(\ell+1)$ st position of the initial state  $\zeta^{(0)}(v)$ ). Thus the GNN can detect a sequence of messages from a node v to a neighbour w to a neighbour x of w and from there back to v.

Random node initialisation has often been used in practice as a default for GNNs. Sato et al. [49] were the first to demonstrate the theoretical strength of GNNs with RNI. It was shown by Abboud et al. [1] that GNNs with RNI have the following universal approximation property. For a unary query Q and a positive integer n, we say that a GNN with RNI expresses Q on graphs of order at most n if conditions (E) are satisfied for all graphs G of order at most n.

**Theorem XI.1** ([1]). For unary query Q and every  $n \ge 1$  there is a GNN with RNI that expresses Q on graphs of order at most n.

A similar theorem holds for Boolean queries, and even for graph invariants and vertex invariants (see [1]).

*Proof sketch.* We can use the random initialisation to create a vertex labelling that uniquely identifies each vertex, with high probability. With this labelling, the logic  $C_2$  and hence

GNNs can describe the graph up to isomorphism. We use this to describe the property, essentially as a big disjunction over all pairs (G, v) consisting of a graph G order at most n and a vertex v ∈ Q(G).

While the theorem is non-uniform and the proof pays no attention to computational efficiency in terms of the size n of the input graphs, various experiments [1, 49] have shown that random initialisation indeed increases the expressiveness. Yet a more careful complexity-theoretic analysis remains future work.

### XII. CONCLUSIONS AND OPEN PROBLEMS

We have seen that the expressiveness of graph neural networks has precise characterisations in terms of the Weisfeiler-Leman algorithm and 2-variable counting logic. Understanding the expressiveness of machine learning architectures is useful to guide us in the choice of an appropriate architecture for a problem at hand and to compare different architectures and approaches. Of course, expressiveness is only one aspect of a machine learning algorithm, other important aspects like the ability to generalise from the given data, and the computational efficiency of learning and inference are not considered in this paper.

The tight correspondence between the expressiveness of GNNs and logical expressiveness may open possibilities for neuro-symbolic integration, that is, the integration of logicbased and statistical reasoning in AI. The theorems presented describe which logical queries can be expressed using GNNs. Of course, that does not mean that we can actually learn GNN models representing these queries. With current techniques, I would regard the question of learnability mainly as an empirical question that can be studied experimentally. In various contexts, it has been demonstrated that GNNs for logical queries can be learned (for example, [1, 53]), but I believe a more systematic empirical investigation might be worthwhile.

There are also many interesting theoretical questions that remain open. Uniformity is an issue that comes up in several of the result presented here. Theorems VIII.4, VIII.8, X.1(2), and XI.1 are non-uniform expressiveness results: they state the existence of certain GNNs that depend on the size of the input graph. By comparison, Theorem IX.1 is uniform.

Question 1. *Is there a uniform version of Theorems VIII.4, that is, a recurrent GNN such that for all* t ≥ 0 *the vertex invariant* ξ (t) *computed by the* t*-th iteration of the GNN refines* cr(t)*? The same question can be asked for Theorems VIII.4 and VIII.8(2).*

The colouring obtained by 1-WL can be defined in 2 variable fixed-point logic, and presumably the same holds for colour refinement and a suitable modal fixed-point logic with counting. Thus, as a common generalisation of the previous question and Theorem IX.1, we may ask the following.

Question 2. *Let* Q *be a unary query expressible in a suitable modal (2-variable) fixed-point logic with counting. Is there a recurrent GNN (with global readout) expressing* Q*?*

So far, Theorem IX.1 has only been proved using the linearised sigmoid function as activation function. I have indicated that the proof can be generalised to other common activation functions, but the following question remains.

Question 3. *For which activation functions does Theorem IX.1 hold? Is there a general condition (similar to the "nonpolynomial" in Theorem VI.1)?*

A suggestion for such a general condition on the activation function might be "non-constant and bounded", which appears in [24].

With Theorem IX.2, we have a partial converse of Theorem IX.1 tightening the connection between the logic GC<sup>2</sup> and GNNs. It is an open question if a similar result holds for C<sup>2</sup> and GNNs with global readout.

Question 4. *Is every unary query expressible by a GNN with global readout and also expressible in first-order logic expressible in the logic* C2*?*

Of course, the uniformity question can also be asked for Theorem XI.1, but technically the situation is a bit different, and it seems very unlikely that we obtain a uniform version of that theorem. It should not be too hard to prove this.

Question 5. *Is there a Boolean query not expressible by a (possibly recurrent) GNN with random node initialisation.*

But still, there might be interesting uniform expressiveness results for GNNs with random node initialisation. Expressiveness of queries by GNNs with random node initialisation is related to logical expressiveness by order-invariant formulas (see, for example, [34, Chapter 5]).

Question 6. *Can we express all Boolean or unary queries expressible by an order-invariant* C 2 *-formula by a GNN with random node initialisation?*

Question 7. *Can we express all Boolean or unary queries expressible by an order-invariant 2-variable fixed-point formula with counting by a recurrent GNN with random node initialisation?*

Of course there is no need to only consider logical queries.

Question 8. *Can we express all Boolean or unary queries computable in polynomial time by a recurrent GNN with random node initialisation?*

The previous question also has an interesting non-uniform version.

Question 9. *Let* Q *be a Boolean query computable by a (nonuniform) family of Boolean threshold circuits of polynomial size. Is there a family* (Nn)n≥<sup>1</sup> *of polynomial size GNNs with random node initialisation such that* N<sup>n</sup> *expresses* Q *on input graphs of size* n*?*

#### REFERENCES

- [1] R. Abboud, I. I. Ceylan, M. Grohe, and T. Lukasiewicz. "The Surprising Power of Graph Neural Networks with Random Node Initialization". In: *Proceedings of the 30th International Joint Conference on Artificial Intelligence (IJCAI)*. Preprint arXiv:2010.01179. 2021.
- [2] S. Abramsky, A. Dawar, and P. Wang. "The pebbling comonad in Finite Model Theory". In: *2017 32nd Annual ACM/IEEE Symposium on Logic in Computer Science (LICS)*. 2017, pp. 1–12. DOI: 10.1109/LICS. 2017.8005129.
- [3] A. Atserias, L. Mancinska, D. Roberson, R. ˇ Sˇ amal, ´ S. Severini, and A. Varvitsiotis. "Quantum and nonsignalling graph isomorphisms". In: *Journal of Combinatorial Theory, Series B* 136 (2019), pp. 289–328.
- [4] A. Atserias and E. Maneva. "Sherali–Adams Relaxations and Indistinguishability in Counting Logics". In: *SIAM Journal on Computing* 42.1 (2013), pp. 112–137.
- [5] L. Babai. "Graph Isomorphism in Quasipolynomial Time". In: *Proceedings of the 48th Annual ACM Symposium on Theory of Computing (STOC)*. 2016, pp. 684– 697.
- [6] L. Babai. "Moderately exponential bound for graph isomorphism". In: *Fundamentals of Computation Theory, FCT'81*. Ed. by F. Gecseg. Vol. 117. Lecture Notes in ´ Computer Science. Springer, 1981, pp. 34–50.
- [7] P. Barcelo, E. V. Kostylev, M. Monet, J. P ´ erez, J. L. ´ Reutter, and J. P. Silva. "The Logical Expressiveness of Graph Neural Networks". In: *8th International Conference on Learning Representations, ICLR 2020, Addis Ababa, Ethiopia, April 26-30, 2020*. OpenReview.net, 2020.
- [8] C. Berkholz, P. Bonsma, and M. Grohe. "Tight Lower and Upper Bounds for the Complexity of Canonical Colour Refinement". In: *Theory of Computing Systems* 60.4 (2017), pp. 581–614.
- [9] C. Berkholz and M. Grohe. "Limitations of Algebraic Approaches to Graph Isomorphism Testing". In: *Proceedings of the 42nd International Colloquium on Automata, Languages and Programming, Part I*. Ed. by M. Halldorsson, K. Iwama, N. Kobayashi, and B. Speck- ´ mann. Vol. 9134. Lecture Notes in Computer Science. Springer Verlag, 2015, pp. 155–166. DOI: 10.1007/978- 3-662-47672-7 13.
- [10] A. Blumer, A. Ehrenfeucht, D. Haussler, and M. K. Warmuth. "Learnability and the Vapnik-Chervonenkis dimension". In: *J. ACM* 36.4 (1989), pp. 929–965. DOI: 10.1145/76359.76371.
- [11] J. Cai, M. Furer, and N. Immerman. "An optimal lower ¨ bound on the number of variables for graph identification". In: *Combinatorica* 12 (1992), pp. 389–410.
- [12] A. Cardon and M. Crochemore. "Partitioning a graph in O(|A| log<sup>2</sup> |V |)". In: *Theoretical Computer Science* 19.1 (1982), pp. 85 –98.

- [13] P. Codenotti, H. Katebi, K. A. Sakallah, and I. L. Markov. "Conflict Analysis and Branching Heuristics in the Search for Graph Automorphisms". In: *25th IEEE International Conference on Tools with Artificial Intelligence, ICTAI 2013, Herndon, VA, USA, November 4-6, 2013*. IEEE Computer Society, 2013, pp. 907–914. DOI: 10.1109/ICTAI.2013.139.
- [14] G. Cybenko. "Approximation by superpositions of a sigmoidal function". In: *Math. Control. Signals Syst.* 2.4 (1989), pp. 303–314. DOI: 10.1007/BF02551274.
- [15] H. Dell, M. Grohe, and G. Rattan. "Lovasz Meets ´ Weisfeiler and Leman". In: *Proceedings of the 45th International Colloquium on Automata, Languages and Programming (Track A)*. Ed. by I. Chatzigiannakis, C. Kaklamanis, D. Marx, and D. Sannella. Vol. 107. LIPIcs. Schloss Dagstuhl - Leibniz-Zentrum fur Infor- ¨ matik, 2018, 40:1–40:14.
- [16] Z. Dvorak. "On recognizing graphs by numbers of ´ homomorphisms". In: *Journal of Graph Theory* 64.4 (2010), pp. 330–342.
- [17] H.-D. Ebbinghaus and J. Flum. *Finite Model Theory*. 2nd. Springer Verlag, 1999.
- [18] C. Gallicchio and A. Micheli. "Graph echo state networks". In: *Proceedings of the IEEE International Joint Conference on Neural Networks*. 2010.
- [19] J. Gilmer, S. S. Schoenholz, P. F. Riley, O. Vinyals, and G. E. Dahl. "Neural Message Passing for Quantum Chemistry". In: *Proceedings of the 34th International Conference on Machine Learning, ICML 2017, Sydney, NSW, Australia, 6-11 August 2017*. Ed. by D. Precup and Y. W. Teh. Vol. 70. Proceedings of Machine Learning Research. PMLR, 2017, pp. 1263–1272.
- [20] M. Grohe. *Descriptive Complexity, Canonisation, and Definable Graph Structure Theory*. Vol. 47. Lecture Notes in Logic. Cambridge University Press, 2017.
- [21] M. Grohe. "Isomorphism testing for embeddable graphs through definability". In: *Proceedings of the 32nd ACM Symposium on Theory of Computing*. 2000, pp. 63–72.
- [22] M. Grohe, K. Kersting, M. Mladenov, and E. Selman. "Dimension Reduction via Colour Refinement". In: *Proceedings of the 22nd Annual European Symposium on Algorithms*. Ed. by A. Schulz and D. Wagner. Vol. 8737. Lecture Notes in Computer Science. Springer, 2014, pp. 505–516.
- [23] W. Hamilton, R. Ying, and J. Leskovec. "Inductive Representation Learning on Large Graphs". In: *Proceedings of the 30th Annual Conference on Neural Information Processing Systems*. 2017, pp. 1024–1034.
- [24] K. Hornik. "Approximation capabilities of multilayer feedforward networks". In: *Neural Networks* 4.2 (1991), pp. 251–257. DOI: 10.1016/0893-6080(91)90009-T.
- [25] N. Immerman. *Descriptive Complexity*. Springer Verlag, 1999.
- [26] N. Immerman and E. Lander. "Describing graphs: A first-order approach to graph canonization". In:

- *Complexity theory retrospective*. Ed. by A. Selman. Springer-Verlag, 1990, pp. 59–81.
- [27] T. A. Junttila and P. Kaski. "Conflict Propagation and Component Recursion for Canonical Labeling". In: *Theory and Practice of Algorithms in (Computer) Systems - First International ICST Conference, TAPAS 2011, Rome, Italy, April 18-20, 2011. Proceedings*. Ed. by A. Marchetti-Spaccamela and M. Segal. Vol. 6595. Lecture Notes in Computer Science. Springer, 2011, pp. 151–162. DOI: 10.1007/978-3-642-19754-3\ 16.
- [28] M. Karpinski and A. Macintyre. "Polynomial Bounds for VC Dimension of Sigmoidal and General Pfaffian Neural Networks". In: *J. Comput. Syst. Sci.* 54.1 (1997), pp. 169–176. DOI: 10.1006/jcss.1997.1477.
- [29] K. Kersting, M. Mladenov, R. Garnet, and M. Grohe. "Power Iterated Color Refinement". In: *Proceedings of the 28th AAAI Conference on Artificial Intelligence*. 2014, pp. 1904–1910.
- [30] S. Kiefer, I. Ponomarenko, and P. Schweitzer. "The Weisfeiler-Leman dimension of planar graphs is at most 3". In: *Proceedings of the 32nd ACM-IEEE Symposium on Logic in Computer Science*. 2017.
- [31] S. Kiefer. "The Weisfeiler-Leman Algorithm: An Exploration of its Power". In: *ACM SIGLOG News* 7.3 (2020), pp. 5–27.
- [32] T. N. Kipf and M. Welling. "Semi-supervised classification with graph convolutional networks". In: *Proceedings of the 5th International Conference on Learning Representations*. 2017.
- [33] M. Leshno, V. Y. Lin, A. Pinkus, and S. Schocken. "Multilayer feedforward networks with a nonpolynomial activation function can approximate any function". In: *Neural Networks* 6.6 (1993), pp. 861–867. DOI: 10. 1016/S0893-6080(05)80131-5.
- [34] L. Libkin. *Elements of Finite Model Theory*. Springer Verlag, 2004.
- [35] J. L. Lopez-Presa, L. F. Chiroque, and A. F. Anta. ´ "Novel Techniques to Speed Up the Computation of the Automorphism Group of a Graph". In: *J. Appl. Math.* 2014 (2014), 934637:1–934637:15. DOI: 10.1155/2014/ 934637.
- [36] W. Maass. "Bounds for the Computational Power and Learning Complexity of Analog Neural Nets". In: *SIAM J. Comput.* 26.3 (1997), pp. 708–732. DOI: 10. 1137/ S0097539793256041.
- [37] H. Maron, H. Ben-Hamu, H. Serviansky, and Y. Lipman. "Provably Powerful Graph Networks". In: *Advances in Neural Information Processing Systems 32: Annual Conference on Neural Information Processing Systems 2019, NeurIPS 2019, December 8-14, 2019, Vancouver, BC, Canada*. Ed. by H. M. Wallach, H. Larochelle, A. Beygelzimer, F. d'Alche-Buc, E. B. Fox, ´ and R. Garnett. 2019, pp. 2153–2164.
- [38] H. Maron, H. Ben-Hamu, N. Shamir, and Y. Lipman. "Invariant and Equivariant Graph Networks". In: *7th International Conference on Learning Representations,*

- *ICLR 2019, New Orleans, LA, USA, May 6-9, 2019*. OpenReview.net, 2019.
- [39] B. D. McKay. "Practical graph isomorphism". In: *Congr. Numer.* 30 (1981), pp. 45–87. ISSN: 0384-9864.
- [40] B. D. McKay and A. Piperno. "Practical graph isomorphism, II". In: *J. Symb. Comput.* 60 (2014), pp. 94–112. DOI: 10.1016/j.jsc.2013.09.003.
- [41] H. Morgan. "The generation of a unique machine description for chemical structures—a technique developed at chemical abstracts service". In: *Journal of Chemical Documentation* 5.2 (1965), pp. 107–113.
- [42] C. Morris, K. Kersting, and P. Mutzel. "Globalized Weisfeiler-Lehman Graph Kernels: Global-Local Feature Maps of Graphs". In: *Proceedings of the 2017 IEEE International Conference on Data Mining*. 2017, pp. 327–336.
- [43] C. Morris, M. Ritzert, M. Fey, W. Hamilton, J. Lenssen, G. Rattan, and M. Grohe. "Weisfeiler and Leman Go Neural: Higher-order Graph Neural Networks". In: *Proceedings of the 33rd AAAI Conference on Artificial Intelligence*. Vol. 4602-4609. AAAI Press, 2019.
- [44] C. Morris, G. Rattan, and P. Mutzel. "Weisfeiler and Leman go sparse: Towards scalable higher-order graph embeddings". In: *Advances in Neural Information Processing Systems 33: Annual Conference on Neural Information Processing Systems 2020, NeurIPS 2020, December 6-12, 2020, virtual*. Ed. by H. Larochelle, M. Ranzato, R. Hadsell, M. Balcan, and H. Lin. 2020.
- [45] M. Otto. *Bounded variable logics and counting A study in finite models*. Vol. 9. Lecture Notes in Logic. Springer Verlag, 1997.
- [46] M. Otto. "Graded modal logic and counting bisimulation". In: *CoRR* abs/1910.00039 (2019). arXiv: 1910. 00039.
- [47] R. Paige and R. Tarjan. "Three partition refinement algorithms". In: *SIAM Journal on Computing* 16.6 (1987), pp. 973–989.
- [48] M. de Rijke. "A Note on Graded Modal Logic". In: *Stud Logica* 64.2 (2000), pp. 271–283. DOI: 10.1023/A: 1005245900406.
- [49] R. Sato, M. Yamada, and H. Kashima. "Random Features Strengthen Graph Neural Networks". In: *CoRR* abs/2002.03155 (2020). arXiv: 2002.03155.
- [50] F. Scarselli, M. Gori, A. Tsoi, M. Hagenbuchner, and G. Monfardini. "The graph neural network model". In: *IEEE Transactions on Neural Networks* 20.1 (2009), pp. 61–80.
- [51] M. Schlichtkrull, T. Kipf, P. Bloem, R. V. D. Berg, I. Titov, and M. Welling. "Modeling relational data with graph convolutional networks". In: *Proceedings of the European Semantic Web Conference*. Ed. by A. Gangemi, R. Navigli, M.-E. Vidal, P. Hitzler, R. Troncy, L. Hollink, A. Tordai, and M. Alam. Vol. 10843. Lecture Notes in Computer Science. Springer Verlag, 2018, pp. 593–607.

- [52] N. Shervashidze, P. Schweitzer, E. van Leeuwen, K. Mehlhorn, and K. Borgwardt. "Weisfeiler-Lehman Graph Kernels". In: *Journal of Machine Learning Research* 12 (2011), pp. 2539–2561.
- [53] J. Tönshoff, M. Ritzert, H. Wolf, and M. Grohe. "Graph Neural Networks for Maximum Constraint Satisfaction". In: Frontiers in Artificial Intelligence 3 (2021). DOI: 10.3389/frai.2020.580607.
- [54] L. Valiant. "A theory of the learnable". In: *Communications of the ACM* 27.11 (1984), pp. 1134–1142.
- [55] V. Vapnik and A. Chervonenkis. "On the uniform convergence of relative frequencies of events to their probabilities". In: *Theory of Probability and its Applications* 16 (1971), pp. 264–280.
- [56] B. Weisfeiler and A. Leman. "The reduction of a graph to canonical form and the algebra which appears therein". In: NTI, Series 2 (1968). English translation by G. Ryabov available at https://www.iti.zcu.cz/wl2018/pdf/wl\_paper\_translation.pdf.
- [57] Z. Wu, S. Pan, F. Chen, G. Long, C. Zhang, and P. S. Yu.
  "A Comprehensive Survey on Graph Neural Networks".
  In: *IEEE Trans. Neural Networks Learn. Syst.* 32.1 (2021), pp. 4–24. DOI: 10.1109/TNNLS.2020.2978386.
- [58] K. Xu, W. Hu, J. Leskovec, and S. Jegelka. "How Powerful are Graph Neural Networks?" In: 7th International Conference on Learning Representations, ICLR 2019, New Orleans, LA, USA, May 6-9, 2019. OpenReview.net, 2019.

#### APPENDIX

### PROOF OF THEOREM V.6

The following lemma contains the essence of the proof.

**Lemma A.1.** let  $k \ge 1$ . Then for all graphs G, G', all  $v \in V(G)^{k+1}, v' \in V(G')^{k+1}$ , and all  $t \in \mathbb{N}$ , the following are equivalent:

- (i)  $\mathsf{owl}_{k+1}^{(t)}(G, v) = \mathsf{owl}_{k+1}^{(t)}(G', v');$
- $\begin{array}{ll} \textit{(ii)} \ \ & \mathsf{atp}_{k+1}(G, \boldsymbol{v}) \ = \ & \mathsf{atp}_{k+1}(G', \boldsymbol{v}') \ \ \textit{and} \ \ & \mathsf{wl}_k^{(t)}\big(G, \boldsymbol{v}[/i]\big) \ = \\ & \mathsf{wl}_k^{(t)}\big(G', \boldsymbol{v}'[/i]\big) \ \textit{for all} \ i \in [k+1]. \end{array}$

*Proof.* We fix the graphs G, G'. The proof is by induction on t. The base step t=0 is trivial. For the inductive step  $t \to t+1$ , let  $\mathbf{v} \in V(G)^{k+1}, \mathbf{v}' \in V(G')^{k+1}$ .

To prove the implication (i)  $\Longrightarrow$  (ii) we assume that  $\mathsf{owl}_{k+1}^{(t+1)}(G, \boldsymbol{v}) = \mathsf{owl}_{k+1}^{(t+1)}(G', \boldsymbol{v}'). \text{ Then } \mathsf{atp}_{k+1}(G, \boldsymbol{v}) = \mathsf{atp}_{k+1}(G', \boldsymbol{v}'), \text{ because } \mathsf{owl}_{k+1}^{(t+1)} \text{ refines } \mathsf{atp}_{k+1}.$ 

Let  $i \in [k+1]$ . We need to prove that  $\mathsf{Wl}_k^{(t+1)}(G, \boldsymbol{v}[/i]) = \mathsf{Wl}_k^{(t+1)}(G', \boldsymbol{v}'[/i])$ . By the definition of  $\mathsf{OWl}_{k+1}^{(t+1)}$  we have

$$\left\{ \operatorname{owl}_{k}^{(t)} \left( G, \boldsymbol{v}[w/i] \right) \; \middle| \; w \in V(G) \right\}$$

$$= \left\{ \operatorname{owl}_{k}^{(t)} \left( G', \boldsymbol{v}'[w'/i] \right) \; \middle| \; w' \in V(G') \right\}.$$
(F)

Thus there is a bijection  $h:V(G)\to V(G')$  such that  $\operatorname{OWI}_k^{(t)}\left(G,\boldsymbol{v}[w/i]\right)=\operatorname{OWI}_k^{(t)}\left(G',\boldsymbol{v}'[h(w)/i]\right)$  for all  $w\in V(G)$ . By the induction hypothesis, this implies  $\operatorname{atp}_{k+1}\left(G,\boldsymbol{v}[w/i]\right)=\operatorname{atp}_{k+1}\left(G',\boldsymbol{v}'[h(w)/i]\right)$  and  $\operatorname{WI}_k^{(t)}\left(G,\boldsymbol{v}[w/i][/j]\right)=\operatorname{WI}_k^{(t)}\left(G',\boldsymbol{v}'[h(w)/i][/j]\right)$  for all  $j\in [k+1]$ . For j=i, this implies  $\operatorname{WI}_k^{(t)}\left(G,\boldsymbol{v}[/i]\right)=\operatorname{WI}_k^{(t)}\left(G',\boldsymbol{v}'[/i]\right)$ . Moreover, for all  $j\in [k]$ , it implies  $\operatorname{WI}_k^{(t)}\left(G,\boldsymbol{v}[/i][w/j]\right)=\operatorname{WI}_k^{(t)}\left(G',\boldsymbol{v}'[/i][h(w)/j]\right)$ . Thus by the definition of  $\operatorname{WI}_k^{(t+1)}$ , it follows that  $\operatorname{WI}_k^{(t+1)}\left(G,\boldsymbol{v}[/i]\right)=\operatorname{WI}_k^{(t+1)}\left(G',\boldsymbol{v}'[/i]\right)$ .

It remains to prove (ii)  $\Longrightarrow$  (i). Suppose that  $\operatorname{atp}_{k+1}(G, \boldsymbol{v}) = \operatorname{atp}_{k+1}(G', \boldsymbol{v}')$  and  $\operatorname{wl}_k^{(t+1)}(G, \boldsymbol{v}[/i]) = \operatorname{wl}_k^{(t+1)}(G', \boldsymbol{v}'[/i])$  for all  $i \in [k+1]$ . As  $\operatorname{wl}_k^{(t+1)}$  refines  $\operatorname{wl}_k^{(t)}$ , by the inductive hypothesis this implies  $\operatorname{owl}_{k+1}^{(t)}(G, \boldsymbol{v}) = \operatorname{owl}_{k+1}^{(t)}(G', \boldsymbol{v}')$ . Thus by the definition of  $\operatorname{owl}_{k+1}^{(t+1)}$ , to prove that  $\operatorname{owl}_{k+1}^{(t+1)}(G, \boldsymbol{v}) = \operatorname{owl}_{k+1}^{(t+1)}(G', \boldsymbol{v}')$  we need to prove that for all  $i \in [k+1]$  we have (F).

So let  $i \in [k+1]$ . Since  $\operatorname{Wl}_k^{(t+1)}(G, \boldsymbol{v}[/i]) = \operatorname{Wl}_k^{(t+1)}(G', \boldsymbol{v}'[/i])$ , there is a bijection  $h: V(G) \to V(G')$  such that for all  $w \in V(G)$  we have  $\operatorname{atp}_{k+1}(G, \boldsymbol{v}[/i]w) = \operatorname{atp}_{k+1}(G', \boldsymbol{v}'[/i]h(w))$  and  $\operatorname{Wl}_k^{(t)}(G, \boldsymbol{v}[/i][w/j]) = \operatorname{Wl}_k^{(t)}(G', \boldsymbol{v}'[/i][h(w)/j])$  for all  $j \in [k]$ . This implies  $\operatorname{atp}_{k+1}(G, \boldsymbol{v}[w/i]) = \operatorname{atp}_{k+1}(G', \boldsymbol{v}'[h(w)/i])$  and  $\operatorname{Wl}_k^{(t)}(G, \boldsymbol{v}[w/i][/j]) = \operatorname{Wl}_k^{(t)}(G', \boldsymbol{v}'[h(w)/i]/j])$  for all  $j \in [k+1]$  (for j = i we use  $\operatorname{Wl}_k^{(t+1)}(G, \boldsymbol{v}[/i]) = \operatorname{Wl}_k^{(t+1)}(G', \boldsymbol{v}'[/i])$ ). Thus by the induction hypopthesis,  $\operatorname{OWl}_{k+1}^{(t)}(G, \boldsymbol{v}[w/i]) = \operatorname{OWl}_{k+1}^{(t)}(G, \boldsymbol{v}[w/i])$  for all  $w \in V(G)$ . As h is a bijection, (F) follows.

*Proof of Theorem V.6.* Let G, G' be a graphs and  $t \in \mathbb{N}$ .

To prove assertion (1), suppose that G,G' are not distinguished by  $\operatorname{oWl}_{k+1}^{(t)}$ . Then there is a bijection  $f:V(G)^{k+1} \to V(G')^{k+1}$  such that  $\operatorname{oWl}_{k+1}^{(t)}(G, \boldsymbol{v}) = \operatorname{oWl}_{k+1}^{(t)}(G', f(\boldsymbol{v}))$  for all  $\boldsymbol{v} \in V(G)^{k+1}$ .

We define a bijection  $g:V(G)^k\to V(G')^k$  as follows: for  $\mathbf{v}=(v_1,\ldots,v_k)$ , let  $\mathbf{v}_+:=(v_1,\ldots,v_k,v_k)$  and  $\mathbf{v}'_+=(v'_1,\ldots,v'_{k+1}):=f(\mathbf{v}_+)$ . Then  $v'_k=v'_{k+1}$ , because  $\mathrm{OWI}_{k+1}^{(t)}(G,\mathbf{v}_+)=\mathrm{OWI}_{k+1}^{(t)}(G',\mathbf{v}'_+)$  and thus  $\mathrm{atp}_{k+1}(G,\mathbf{v}_+)=\mathrm{atp}_{k+1}(G',\mathbf{v}'_+)$  by Lemma A.1. We let  $g(\mathbf{v}):=(v'_1,\ldots,v'_k)=:\mathbf{v}'$ . Then g is indeed a bijection from  $V(G)^k$  to  $V(G')^k$ , and since  $\mathbf{v}=\mathbf{v}_+[/k+1]$  and  $g(\mathbf{v})=\mathbf{v}'=\mathbf{v}'_+[/k+1]$ , we have  $\mathrm{WI}_k^{(t)}(G,\mathbf{v})=\mathrm{WI}_k^{(t)}(G',\mathbf{v}')$  by Lemma A.1. Thus g is a bijection from  $V(G)^k$  to  $V(G')^k$  that preerves  $\mathrm{WI}_k^{(t)}$ , and this implies that  $\mathrm{WI}_k^{(t)}$  does not distinguish G and G'.

To prove (2), assume that G and G' are not distinguished by  $\operatorname{Wl}_k^{(t+1)}$ . Then there is a bijection  $g:V(G)^k \to V(G')^k$  such that  $\operatorname{Wl}_k^{(t+1)}(G, \boldsymbol{v}) = \operatorname{Wl}_k^{(t+1)}(G', f(\boldsymbol{v}))$  for all  $\boldsymbol{v} \in V(G)^k$ .

Let  $v \in V(G)^k$  and  $v' \coloneqq f(v)$ . By the definition of  $\mathsf{Wl}_k^{(t+1)}$ , we have  $\mathsf{Wl}_k^{(t)}(G,v) = \mathsf{Wl}_k^{(t)}(G',v')$  and there is a bijection  $h_v: V(G) \to V(G')$  such that for all  $w \in V(G)$  we have  $\mathsf{atp}_{k+1}(G,vw) = \mathsf{atp}_{k+1}(G',v'h_v(w))$  and  $\mathsf{Wl}_k^{(t)}(G,v[w/i]) = \mathsf{Wl}_k^{(t)}(G',v'[h_v(w)/i])$  for all  $i \in [k]$ . This implies  $\mathsf{Wl}_k^{(t)}(G,vw[/i]) = \mathsf{Wl}_k^{(t)}(G',v'h_v(w)[/i])$  for all  $i \in [k]$ . Moreover, since v = vw[/k+1] we also have  $\mathsf{Wl}_k^{(t)}(G,vw[/k+1]) = \mathsf{Wl}_k^{(t)}(G',v'h_v(w)[/k+1])$ . Thus by Lemma A.1, it follows that  $\mathsf{oWl}_{k+1}^{(t)}(G,vw) = \mathsf{oWl}_{k+1}^{(t)}(G',v'h_v(w))$ .

We define a bijection  $f:V(G)^{k+1}\to V(G)^{k+1}$  by  $f(\boldsymbol{v}w):=g(\boldsymbol{v})h_{\boldsymbol{v}}(w)$  for all  $\boldsymbol{v}\in V(G)^k, w\in V(G)$ . Then f preserves  $\mathrm{OWl}_{k+1}^{(t)}$ , and thus  $\mathrm{OWl}_{k+1}^{(t)}$  does not distinguish G and G'.

#### PROOF OF THEOREM V.10

The proof is by induction on t. For the base case t=0, note that a  $\mathrm{GC}_2^{(0)}$  formula  $\varphi(x)$  is a Boolean combination of atomic "Label" formulas  $P_i(x)$ ; formulas E(x,x) (always false) and x=x (always true) are not needed. The colouring  $\mathrm{Cr}^{(0)}=\mathrm{Col}$  captures precisely the label information.

For the inductive step  $t \geq t+1$ , we first prove the implication (i)  $\Longrightarrow$  (ii). Assume that  $\operatorname{cr}^{(t+1)}(G,v) = \operatorname{cr}^{(t+1)}(G',v')$ . Let  $\varphi(x) \in \operatorname{GC}_2^{(t+1)}$ . Then  $\varphi$  is a Boolean combination of atomic formulas  $P_i(x)$  and formulas  $\exists^{\geq p}y\bigl(E(x,y) \land \psi(y)\bigr)$ , where  $\psi(y) \in \operatorname{GC}_2^{(t)}$ . We shall prove that G and G' satisfy the same formulas othe these types. As  $\operatorname{cr}^{(r+1)}$  refines  $\operatorname{col}$  and  $\operatorname{cr}^{(t+1)}(G,v) = \operatorname{cr}^{(t+1)}(G',v')$ , we have  $\operatorname{col}(G,v) = \operatorname{col}(G',v')$  and thus  $G \models P_i(v) \iff G' \models P_i(v')$  for all i. Consider a formula  $\varphi'(x) \coloneqq \exists^{\geq p}y\bigl(E(x,y) \land \psi(y)\bigr)$ , where  $\psi(y) \in \operatorname{GC}_2^{(t)}$ . By the induction hypothesis, for every colour c in the range of  $\operatorname{cr}^{(t)}$ , either all vertices of colour c or none of the vertices of colour c satistfy the formula  $\psi(y)$ . Let  $c_1,\ldots,c_q$  be the colours in the range of  $\operatorname{cr}^{(t+1)}(G,v) = \operatorname{cr}^{(t+1)}(G',v')$ , for each  $j \in [q]$  the number of vertices

 $w \in V(G)$  such that  $vw \in E(G)$  and  $\operatorname{cr}^{(t)}(G,w) = c_j$  equals the number of vertices  $w' \in V(G')$  such that  $v'w' \in E(G')$  and  $\operatorname{cr}^{(t)}(G',w') = c_j$ . Thus the the number of vertices  $w \in V(G)$  such that  $vw \in E(G)$  and  $G \models \psi(w)$  equals the number of vertices  $w' \in V(G')$  such that  $v'w' \in E(G')$  and  $G' \models \psi(v')$ . It follows that  $G \models \varphi'(v) \iff G' \models \varphi'(v')$ .

To prove the converse implication (ii)  $\Longrightarrow$  (i), we assume that for all formulas  $\varphi(x) \in \mathsf{GC}_2^{(t+1)}$  it holds that  $G' \models \varphi'(v')$ . Let  $c_1, \ldots, c_q$  be the (finite) list of colours in the range of  $\mathsf{cr}^{(t)}(G) \cup \mathsf{cr}^{(t)}(G')$ . By the induction hypothesis, for all distinct  $i, j \in [q]$  there is a formula  $\psi_{ij}(x) \in \mathsf{GC}_2^{(t)}$  that is satisfied by all vertices of colour  $c_i$ , but by no vertices of colour  $c_j$ . Thus the formula  $\varphi_i(x) \coloneqq \bigwedge_{j \neq i} \psi_{ij}(x)$  is satisfied exactly by the vertices of colour  $c_i$  and by no other vertices in  $V(G) \cup V(G')$ .

Suppose for contradiction that there is a colour  $c_i$  such that

$$\begin{split} p_i \coloneqq \left| \left\{ w \in N^G(v) \bigm| \mathbf{Cr}^{(t)}(G, w) = c_i \right\} \right| \\ & \neq \left| \left\{ w' \in N^{G'}(v') \bigm| \mathbf{Cr}^{(t)}(G', w') = c_i \right\} \right| =: p_i'. \end{split}$$

Without loss of generality we assume that  $p_i > p_i'$ . Let  $\varphi(x) := \exists^{\geq p_i} y \big( E(x,y) \land \varphi_i(y) \big)$ . Then  $\varphi(x) \in \mathsf{GC}_2^{(t+1)}$  and  $G \models \varphi(v)$ , but  $G' \not\models \varphi(v')$ . This is a contradiction.

Thus v and v' have the same numbers of neighbours of each colour in the range of  $\operatorname{cr}^{(t)}$ . By definition, this means that  $\operatorname{cr}^{(t+1)}(G,v)=\operatorname{cr}^{(t+1)}(G',v')$ .