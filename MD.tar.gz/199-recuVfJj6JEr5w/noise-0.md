## [Skip to main content](#page-9-0) [Accessibility help](file:///core/accessibility)

# **Login Alert**

| Cancel<br>Log in<br>×<br>×<br>Discover Content |        |
|------------------------------------------------|--------|
| Products and Services                          |        |
| Register<br>Log In<br>(0) Cart                 |        |
|                                                | Search |
|                                                |        |
| •<br>Browse                                    |        |
| •<br>Services                                  |        |
| •<br>Open research                             |        |
| Institution Login                              |        |
|                                                | Search |
|                                                |        |

## Menu links

- Browse 1.
  - Subjects 1.
    - Subjects (A-D) 1.
      - [Anthropology](file:///core/browse-subjects/anthropology) 1.
      - [Archaeology](file:///core/browse-subjects/archaeology) 2.
      - [Area Studies](file:///core/browse-subjects/area-studies) 3.
      - [Art](file:///core/browse-subjects/art) 4.

- [Chemistry](file:///core/browse-subjects/chemistry) 5.
- [Classical Studies](file:///core/browse-subjects/classical-studies) 6.
- [Computer Science](file:///core/browse-subjects/computer-science) 7.
- [Drama, Theatre, Performance Studies](file:///core/browse-subjects/drama-and-theatre) 8.
- Subjects (E-K) 9.
  - [Earth and Environmental Science](file:///core/browse-subjects/earth-and-environmental-sciences) 1.
  - [Economics](file:///core/browse-subjects/economics) 2.
  - [Education](file:///core/browse-subjects/education) 3.
  - [Engineering](file:///core/browse-subjects/engineering) 4.
  - [English Language Teaching Resources for Teachers](file:///core/browse-subjects/english-language-teaching-resources-for-teachers) 5.
  - [Film, Media, Mass Communication](file:///core/browse-subjects/film-media-mass-ommunication) 6.
  - [General Science](file:///core/browse-subjects/general-science) 7.
  - [Geography](file:///core/browse-subjects/geography) 8.
  - [History](file:///core/browse-subjects/history) 9.
- Subjects (L-O) 10.
  - [Language and Linguistics](file:///core/browse-subjects/language-and-linguistics) 1.
  - [Law](file:///core/browse-subjects/law) 2.
  - [Life Sciences](file:///core/browse-subjects/life-sciences) 3.
  - [Literature](file:///core/browse-subjects/literature) 4.
  - [Management](file:///core/browse-subjects/management) 5.
  - [Materials Science](file:///core/browse-subjects/materials-science) 6.
  - [Mathematics](file:///core/browse-subjects/mathematics) 7.
  - [Medicine](file:///core/browse-subjects/medicine) 8.
  - [Music](file:///core/browse-subjects/music) 9.
  - [Nutrition](file:///core/browse-subjects/nutrition) 10.
- Subjects (P-Z) 11.
  - [Philosophy](file:///core/browse-subjects/philosophy) 1.
  - [Physics and Astronomy](file:///core/browse-subjects/physics) 2.
  - [Politics and International Relations](file:///core/browse-subjects/politics-and-international-relations) 3.
  - [Psychiatry](file:///core/browse-subjects/psychiatry) 4.
  - [Psychology](file:///core/browse-subjects/psychology) 5.
  - [Religion](file:///core/browse-subjects/religion) 6.
  - [Social Science Research Methods](file:///core/browse-subjects/social-science-research-methods) 7.
  - [Sociology](file:///core/browse-subjects/sociology) 8.
  - [Statistics and Probability](file:///core/browse-subjects/statistics-and-probability) 9.
- Open access 2.
  - All open access publishing 1.
    - [Open access](file:///core/publications/open-access) 1.
    - [Open access journals](file:///core/publications/open-access/listing?aggs[productTypes][filters]=JOURNAL&statuses=PUBLISHED&sort=titleSort:asc) 2.
    - [Research open journals](file:///core/publications/open-access/research-open?aggs[productTypes][filters]=JOURNAL&statuses=PUBLISHED&sort=titleSort:asc) 3.
    - [Journals containing open access](file:///core/publications/open-access/hybrid-open-access-journals?aggs[productTypes][filters]=JOURNAL&statuses=PUBLISHED&sort=titleSort:asc) 4.
    - [Open access articles](file:///core/publications/open-access/listing?aggs[productTypes][filters]=JOURNAL_ARTICLE) 5.
    - [Open access books](file:///core/publications/open-access/listing?aggs[productTypes][filters]=BOOK&sort=canonical.date:desc) 6.
    - [Open access Elements](file:///core/publications/elements/published-elements?aggs%5BopenAccess%5D%5Bfilters%5D=7275BA1E84CA769210167A6A66523B47&aggs%5BproductTypes%5D%5Bfilters%5D=ELEMENT&searchWithinIds=ECFD8F5C64F47F3F5A3D395C15B7C493) 7.
- Journals 2.
  - Explore 1.
    - [All journal subjects](file:///core/publications/journals) 1.
    - [Search journals](file:///core/publications/journals) 2.
  - Open access 3.
    - [Open access journals](file:///core/publications/open-access/listing?aggs[productTypes][filters]=JOURNAL&statuses=PUBLISHED&sort=titleSort:asc) 1.
    - [Research open journals](file:///core/publications/open-access/research-open?aggs[productTypes][filters]=JOURNAL&statuses=PUBLISHED&sort=titleSort:asc) 2.
    - [Journals containing open access](file:///core/publications/open-access/hybrid-open-access-journals?aggs[productTypes][filters]=JOURNAL&statuses=PUBLISHED&sort=titleSort:asc) 3.

- [Open access articles](file:///core/publications/open-access/listing?aggs[productTypes][filters]=JOURNAL_ARTICLE) 4.
- Collections 5.
  - [Cambridge Forum](file:///core/publications/collections/cambridge-forum) 1.
  - [Cambridge Law Reports Collection](file:///core/publications/collections/cambridge-law-reports-collection) 2.
  - [Cambridge Prisms](file:///core/publications/collections/cambridge-prisms) 3.
  - [Research Directions](file:///core/publications/collections/research-directions) 4.
- Books 2.
  - Explore 1.
    - [Books](file:///core/publications/books) 1.
    - [Open access books](file:///core/publications/open-access/listing?aggs[productTypes][filters]=BOOK&sort=canonical.date:desc) 2.
    - [New books](file:///core/publications/books/listing?aggs[productDate][filters]=Last+3+months&aggs[productTypes][filters]=BOOK&sort=canonical.date:desc) 3.
    - [Flip it Open](file:///core/publications/collections/flip-it-open) 4.
  - Collections 5.
    - [Cambridge Companions](file:///core/publications/collections/cambridge-companions) 1.
    - [Cambridge Editions](file:///core/publications/collections/cambridge-editions) 2.
    - [Cambridge Histories](file:///core/publications/collections/cambridge-histories) 3.
    - [Cambridge Library Collection](file:///core/publications/collections/cambridge-library-collection) 4.
    - [Cambridge Shakespeare](file:///core/publications/collections/cambridge-shakespeare) 5.
    - [Cambridge Handbooks](file:///core/publications/collections/cambridgehandbooks) 6.
  - Collections (cont.) 7.
    - [Dispute Settlement Reports Online](file:///core/publications/collections/dispute-settlement-reports-online) 1.
    - [Flip it Open](file:///core/publications/collections/flip-it-open) 2.
    - [Hemingway Letters](file:///core/publications/collections/hemingway-letters) 3.
    - [Shakespeare Survey](file:///core/publications/collections/shakespeare-survey) 4.
    - [Stahl Online](file:///core/publications/collections/stahl-online) 5.
    - [The Correspondence of Isaac Newton](file:///core/publications/collections/the-correspondence-of-isaac-newton) 6.
- Elements 2.
  - Explore 1.
    - [About Elements](file:///core/publications/elements) 1.
    - [Elements series](file:///core/publications/elements/cambridge-elements-series) 2.
    - [Open access Elements](file:///core/publications/elements/published-elements?aggs%5BopenAccess%5D%5Bfilters%5D=7275BA1E84CA769210167A6A66523B47&aggs%5BproductTypes%5D%5Bfilters%5D=ELEMENT&searchWithinIds=ECFD8F5C64F47F3F5A3D395C15B7C493) 3.
    - [New Elements](file:///core/publications/elements/published-elements?aggs%5BproductTypes%5D%5Bfilters%5D=ELEMENT&aggs%5BproductDate%5D%5Bfilters%5D=Last%203%20months&searchWithinIds=ECFD8F5C64F47F3F5A3D395C15B7C493) 4.
  - Subjects (A-E) 5.
    - [Anthropology](file:///core/elements/subject/Anthropology/2E44A5AF2838E017617A26DD79FAEAEE) 1.
    - [Archaeology](file:///core/elements/subject/Archaeology/63A50B5368A9F97F8AA2D6AB965B5F4C) 2.
    - [Classical Studies](file:///core/elements/subject/Classical%20Studies/DDC63B7F5792FE2A95D1FB15F76E3F42) 3.
    - [Computer Science](file:///core/elements/subject/Computer%20Science/A57E10708F64FB69CE78C81A5C2A6555) 4.
    - [Drama, Theatre, Performance Studies](file:///core/elements/subject/Drama,%20Theatre,%20Performance%20Studies/2825E4E39F2D641B36543EE80FB1DEA3) 5.
    - [Earth and Environmental Sciences](file:///core/elements/subject/Earth%20and%20Environmental%20Sciences/F470FBF5683D93478C7CAE5A30EF9AE8) 6.
    - [Economics](file:///core/elements/subject/Economics/FA44491F1F55F917C43E9832715B9DE7) 7.
    - [Education](file:///core/elements/subject/Education/550D00F8DF590F2598CF7CC0038E24D1) 8.
    - [Engineering](file:///core/elements/subject/Engineering/CCC62FE56DCC1D050CA1340C1CCF46F5) 9.
  - Subjects (F-O) 10.
    - [Film, Media, Mass Communication](file:///core/elements/subject/Film,%20Media,%20Mass%20Communication/4B91F10E834814A90CE718E7831E492F) 1.
    - [History](file:///core/elements/subject/History/66BE42A30172E280FDE64F8EE2F485B0) 2.
    - [Language and Linguistics](file:///core/elements/subject/Language%20and%20Linguistics/140D314098408C26BDF3009F7FF858E9) 3.
    - [Law](file:///core/elements/subject/Law/7C9FB6788DD8D7E6696263BC774F4D5B) 4.
    - [Life Sciences](file:///core/elements/subject/Life%20Sciences/E044EF2F61B601378786E9EDA901B2D5) 5.
    - [Literature](file:///core/elements/subject/Literature/F2434ADC122145767C6C3B988A8E9BD5) 6.
    - [Management](file:///core/elements/subject/Management/0EDCC0540639B06A5669BDEEF50C4CBE) 7.
    - [Mathematics](file:///core/elements/subject/Mathematics/FA1467C44B5BD46BB8AA6E58C2252153) 8.
    - [Medicine](file:///core/elements/subject/Medicine/66FF02B2A4F83D9A645001545197F287) 9.

- [Music](file:///core/elements/subject/Music/A370B5604591CB3C7F9AFD892DDF7BD1) 10.
- Subjects (P-Z) 11.
  - [Philosophy](file:///core/elements/subject/Philosophy/2D1AC3C0E174F1F1A93F8C7DE19E0FAB) 1.
  - [Physics and Astronomy](file:///core/elements/subject/Physics%20and%20Astronomy/DBFB610E9FC5E012C011430C0573CC06) 2.
  - [Politics and International Relations](file:///core/elements/subject/Politics%20and%20International%20Relations/3BF83347E5E456DAC34F3FABFC8BBF4E) 3.
  - [Psychology](file:///core/elements/subject/Psychology/21B42A72BA3E4CB0E3315E5B1B71B07F) 4.
  - [Religion](file:///core/elements/subject/Religion/53E51D24FB488962B9364A2C4B45D1C3) 5.
  - [Sociology](file:///core/elements/subject/Sociology/0E2CD53A93003DF17E52D753F6E90683) 6.
  - [Statistics and Probability](file:///core/elements/subject/Statistics%20and%20Probability/3150B8B0D1B0B4E8DC17EC9EDFD9CA26) 7.
- Textbooks 2.
  - Explore 1.
    - [Cambridge Higher Education](file:///highereducation/) 1.
    - [Title list](file:///highereducation/services/librarians/title-list) 2.
    - [New titles](file:///highereducation/search?sortBy=publication_date&aggs=%24productDate%24Last%25206%2520months%3Atrue%26Last%252012%2520months%3Atrue%26Last%25203%2520years%3Atrue%26Over%25203%2520years%3Atrue%3B%3B&event=SE-AU_PREF) 3.
- Collections 2.
  - Book collections 1.
    - [Cambridge Companions](file:///core/publications/collections/cambridge-companions) 1.
    - [Cambridge Editions](file:///core/publications/collections/cambridge-editions) 2.
    - [Cambridge Histories](file:///core/publications/collections/cambridge-histories) 3.
    - [Cambridge Library Collection](file:///core/publications/collections/cambridge-library-collection) 4.
    - [Cambridge Shakespeare](file:///core/publications/collections/cambridge-shakespeare) 5.
    - [Cambridge Handbooks](file:///core/publications/collections/cambridgehandbooks) 6.
  - Book collections (cont.) 7.
    - [Dispute Settlement Reports Online](file:///core/publications/collections/dispute-settlement-reports-online) 1.
    - [Flip it Open](file:///core/publications/collections/flip-it-open) 2.
    - [Hemingway Letters](file:///core/publications/collections/hemingway-letters) 3.
    - [Shakespeare Survey](file:///core/publications/collections/shakespeare-survey) 4.
    - [Stahl Online](file:///core/publications/collections/stahl-online) 5.
    - [The Correspondence of Isaac Newton](file:///core/publications/collections/the-correspondence-of-isaac-newton) 6.
  - Journal collections 7.
    - [Cambridge Forum](file:///core/publications/collections/cambridge-forum) 1.
    - [Cambridge Law Reports Collection](file:///core/publications/collections/cambridge-law-reports-collection) 2.
    - [Cambridge Materials](file:///core/publications/collections/cambridge-materials) 3.
    - [Cambridge Prisms](file:///core/publications/collections/cambridge-prisms) 4.
  - Series 5.
    - [All series](file:///core/publications/collections/series) 1.
- Partners 2.
  - Partners 1.
    - [Agenda Publishing](file:///core/publications/publishing-partners/agenda-publishing) 1.
    - [Amsterdam University Press](file:///core/publications/publishing-partners/amsterdam-university-press) 2.
    - [Anthem Press](file:///core/publications/publishing-partners/anthem-press) 3.
    - [Boydell & Brewer](file:///core/publications/publishing-partners/boydell-brewer) 4.
    - [Bristol University Press](file:///core/publications/publishing-partners/bristol-university-press) 5.
    - [Edinburgh University Press](file:///core/publications/publishing-partners/edinburgh-university-press) 6.
    - [Emirates Center for Strategic Studies and Research](file:///core/publications/publishing-partners/emirates-center) 7.
    - [Facet Publishing](file:///core/publications/publishing-partners/facet-publishing) 8.
  - Partners (cont.) 9.
    - [Foundation Books](file:///core/publications/publishing-partners/foundation-books) 1.
    - [Intersentia](file:///core/publications/publishing-partners/intersentia) 2.
    - [ISEAS-Yusof Ishak Institute](file:///core/publications/publishing-partners/iseas) 3.
    - [Jagiellonian University Press](file:///core/publications/publishing-partners/jagiellonian-university-press) 4.
    - [Royal Economic Society](file:///core/publications/publishing-partners/royal-economic-society) 5.

- [Unisa Press](file:///core/publications/publishing-partners/unisa-press) 6.
- [The University of Adelaide Press](file:///core/publications/publishing-partners/university-adelaide-press) 7.
- [Wits University Press](file:///core/publications/publishing-partners/wits-university-press) 8.

### Services 2.

- About 1.
  - About Cambridge Core 1.
    - [About](file:///core/services/about/about) 1.
    - [Accessibility](file:///core/services/about/accessibility) 2.
    - [CrossMark policy](file:///core/services/about/crossmark-policy) 3.
    - [Ethical Standards](file:///core/services/about/ethical-standards) 4.
  - Environment and sustainability 5.
    - [Environment and sustainability](file:///core/services/about/environment-and-sustainability) 1.
    - [Reducing print](file:///core/services/about/reducing-print) 2.
    - [Journals moving to online only](file:///core/services/about/journals-moving-to-online-only) 3.
  - Guides 4.
    - [User guides](file:///core/services/about/user-guides) 1.
    - [User Guides and Videos](file:///core/services/about/user-guides-and-videos) 2.
    - [Support Videos](file:///core/services/about/support-videos) 3.
    - [Training](file:///core/services/about/training) 4.
  - Help 5.
    - [Cambridge Core help](https://corehelp.cambridge.org/) 1.
    - [Contact us](https://corehelp.cambridge.org/hc/en-gb/p/contact-information) 2.
    - [Technical support](https://corehelp.cambridge.org/hc/en-gb/requests/new) 3.
- Agents 2.
  - Services for agents 1.
    - [Services for agents](file:///core/services/agents/services-for-agents) 1.
    - [Journals for agents](file:///core/services/agents/journals-for-agents) 2.
    - [Books for agents](file:///core/services/agents/books-for-agents) 3.
    - [Price list](file:///core/services/agents/price-list) 4.
- Authors 2.
  - Journals 1.
    - [Journals](file:///core/services/authors/journals) 1.
    - [Journal publishing statistics](file:///core/services/authors/journal-publishing-statistics) 2.
    - [Corresponding author](file:///core/services/authors/corresponding-author) 3.
    - [Seeking permission to use copyrighted material](file:///core/services/authors/seeking-permission-to-use-copyrighted-material) 4.
    - [Publishing supplementary material](file:///core/services/authors/publishing-supplementary-material) 5.
    - [Writing an effective abstract](file:///core/services/authors/writing-an-effective-abstract) 6.
    - [Journal production FAQs](file:///core/services/authors/journal-production-faqs) 7.
  - Journals (cont.) 8.
    - [Author affiliations](file:///core/services/authors/author-affiliations) 1.
    - [Co-reviewing policy](file:///core/services/authors/co-reviewing-policy) 2.
    - [Anonymising your manuscript](file:///core/services/authors/anonymising-your-manuscript) 3.
    - [Publishing open access](file:///core/services/authors/publishing-open-access) 4.
    - [Convert your article to Gold Open Access](file:///core/services/authors/convert-your-article-to-open-access) 5.
    - [Publishing Open Access webinars](file:///core/services/authors/publishing-open-access-webinars) 6.
  - Journals (cont.) 7.
    - [Preparing and submitting your paper](file:///core/services/authors/preparing-and-submitting-your-paper) 1.
    - [Publication journey](file:///core/services/authors/publication-journey) 2.
    - [Publishing agreement FAQs for journal authors](file:///core/services/authors/digital-author-publishing-agreement-faqs) 3.
    - [Author Information Form FAQs](file:///core/services/authors/author-information-form-faqs) 4.
    - [Promoting your published paper](file:///core/services/authors/promoting-your-published-paper) 5.
    - [Measuring impact](file:///core/services/authors/measuring-impact) 6.

- [Journals artwork guide](file:///core/services/authors/journals-artwork-guide) 7.
- [Using ORCID](file:///core/services/authors/using-orcid) 8.
- Books 9.
  - [Books](file:///core/services/authors/books) 1.
  - [Marketing your book](file:///core/services/authors/marketing-your-book) 2.
  - [Author guides for Cambridge Elements](file:///core/services/authors/elements-user-guides) 3.
- Corporates 2.
  - Corporates 1.
    - [Commercial reprints](file:///core/services/corporates/commercial-reprints) 1.
    - [Advertising](file:///core/services/corporates/advertising) 2.
    - [Sponsorship](file:///core/services/corporates/sponsorship) 3.
    - [Book special sales](file:///core/services/corporates/book-special-sales) 4.
    - [Contact us](file:///core/services/corporates/contact-us) 5.
- Editors 2.
  - Information 1.
    - [Journal development](file:///core/services/editors/journal-development) 1.
    - [Peer review for editors](file:///core/services/editors/peer-review-for-editors) 2.
    - [Open access for editors](file:///core/services/editors/open-access-for-editors) 3.
    - [Policies and guidelines](file:///core/services/editors/policies-and-guidelines) 4.
  - Resources 5.
    - [The editor's role](file:///core/services/editors/the-editors-role) 1.
    - [Open research for editors](file:///core/services/editors/open-research-for-editors) 2.
    - [Engagement and promotion](file:///core/services/editors/engagement-and-promotion) 3.
    - [Blogging](file:///core/services/editors/blogging) 4.
    - [Social media](file:///core/services/editors/social-media) 5.
- Librarians 2.
  - Information 1.
    - [Open Access for Librarians](file:///core/services/librarians/open-access-for-librarians) 1.
    - [Transformative agreements](https://www.cambridge.org/core/services/open-access-policies/read-and-publish-agreements) 2.
    - [Transformative Agreements FAQs](file:///core/services/librarians/transformative-agreements-faqs) 3.
    - [Evidence based acquisition](file:///core/services/librarians/evidence-based-acquisition) 4.
    - [Cambridge libraries of the world podcast](file:///core/services/librarians/cambridge-libraries-of-the-world-podcast) 5.
    - [Purchasing models](file:///core/services/librarians/purchasing-models) 6.
    - [Journals Publishing Updates](file:///core/services/librarians/journals-publishing-updates) 7.
  - Products 8.
    - [Cambridge frontlist](file:///core/services/librarians/cambridge-frontlist) 1.
    - [Cambridge journals digital archive](file:///core/services/librarians/cambridge-journals-digital-archive) 2.
    - [Hot topics](file:///core/services/librarians/hot-topics) 3.
    - [Other digital products](file:///core/services/librarians/other-digital-products) 4.
    - [Perpetual access products](file:///core/services/librarians/perpetual-access-products) 5.
    - [Price list](file:///core/services/librarians/price-list) 6.
    - [Developing country programme](file:///core/services/librarians/developing-country-programme) 7.
    - [New content](file:///core/services/librarians/new-content) 8.
  - Tools 9.
    - [Eligibility checker](file:///core/eligibility-checker) 1.
    - [Transformative agreements](https://www.cambridge.org/core/services/open-access-policies/read-and-publish-agreements) 2.
    - [KBART](https://www.cambridge.org/core/services/librarians/kbart) 3.
    - [MARC records](https://www.cambridge.org/core/services/librarians/marc-records) 4.
    - [Using MARCEdit for MARC records](file:///core/services/librarians/using-marcedit-for-marc-records) 5.
    - [Inbound OpenURL specifications](file:///core/services/librarians/inbound-openurl-specifications) 6.
    - [COUNTER usage reporting](file:///core/services/librarians/counter-usage-reporting) 7.

### Resources 8.

- [Catalogues and resources](file:///core/services/librarians/catalogues-and-resources) 1.
- [Making the most of your EBA](file:///core/services/librarians/making-the-most-of-your-eba) 2.
- [Posters](file:///core/services/librarians/posters) 3.
- [Leaflets and brochures](file:///core/services/librarians/leaflets-and-brochures) 4.
- [Additional resources](file:///core/services/librarians/additional-resources) 5.
- [Find my sales contact](file:///core/services/librarians/find-my-sales-contact) 6.
- [Training](file:///core/services/librarians/training) 7.
- [Read and publish resources](file:///core/services/librarians/read-and-publish-resources) 8.

#### Peer review 2.

- Peer review 1.
  - [How to peer review journal articles](file:///core/services/peer-review/how-to-peer-review-journal-articles) 1.
  - [How to peer review book proposals](file:///core/services/peer-review/how-to-peer-review-book-proposals) 2.
  - [How to peer review Registered Reports](file:///core/services/peer-review/how-to-peer-review-registered-reports) 3.
  - [Peer review FAQs](file:///core/services/peer-review/peer-review-faqs) 4.
  - [Ethics in peer review](file:///core/services/peer-review/ethics-in-peer-review) 5.
  - [Online peer review systems](file:///core/services/peer-review/online-peer-review-systems) 6.
  - [A guide to Publons](file:///core/services/peer-review/a-guide-to-publons) 7.

## Publishing ethics 2.

- Journals 1.
  - [Publishing ethics guidelines for journals](file:///core/services/publishing-ethics/publishing-ethics-guidelines-journals) 1.
  - [Core editorial policies for journals](file:///core/services/publishing-ethics/core-editorial-policies-journals) 2.
  - [Authorship and contributorship for journals](file:///core/services/publishing-ethics/authorship-and-contributorship-journals) 3.
  - [Affiliations for journals](file:///core/services/publishing-ethics/affiliations-journals) 4.
  - [Research ethics for journals](file:///core/services/publishing-ethics/research-ethics-journals) 5.
  - [Competing interests and funding for journals](file:///core/services/publishing-ethics/competing-interests-and-funding-journals) 6.
- Journals (cont.) 7.
  - [Data and supporting evidence for journals](file:///core/services/publishing-ethics/data-and-supporting-evidence-for-journals) 1.
  - [Misconduct for journals](file:///core/services/publishing-ethics/misconduct-journals) 2.
  - [Corrections, retractions and removals for journals](file:///core/services/publishing-ethics/corrections-retractions-and-removals-journals) 3.
  - [Versions and adaptations for journals](file:///core/services/publishing-ethics/versions-and-adaptations-journals) 4.
  - [Libel, defamation and freedom of expression](file:///core/services/publishing-ethics/libel-defamation-and-freedom-of-expression) 5.
  - [Business ethics journals](file:///core/services/publishing-ethics/business-ethics-journals) 6.

#### Books 7.

- [Publishing ethics guidelines for books](file:///core/services/publishing-ethics/publishing-ethics-guidelines-books) 1.
- [Core editorial policies for books](file:///core/services/publishing-ethics/core-editorial-policies-books) 2.
- [Authorship and contributorship for books](file:///core/services/publishing-ethics/authorship-and-contributorship-books) 3.
- [Affiliations for books](file:///core/services/publishing-ethics/affiliations-books) 4.
- [Research ethics for books](file:///core/services/publishing-ethics/research-ethics-books) 5.
- [Competing interests and funding for books](file:///core/services/publishing-ethics/competing-interests-and-funding-books) 6.
- Books (cont.) 7.
  - [Data and supporting evidence for books](file:///core/services/publishing-ethics/data-and-supporting-evidence-books) 1.
  - [Misconduct for books](file:///core/services/publishing-ethics/misconduct-books) 2.
  - [Corrections, retractions and removals for books](file:///core/services/publishing-ethics/corrections-retractions-and-removals-books) 3.
  - [Versions and adaptations for books](file:///core/services/publishing-ethics/versions-and-adaptations-books) 4.
  - [Libel, defamation and freedom of expression](file:///core/services/publishing-ethics/libel-defamation-and-freedom-of-expression) 5.
  - [Business ethics books](file:///core/services/publishing-ethics/business-ethics-books) 6.

#### Publishing partners 2.

- Publishing partners 1.
  - [Publishing partnerships](file:///core/services/publishing-partners/publishing-partnerships) 1.
  - [Partner books](file:///core/services/publishing-partners/partner-books) 2.
  - [eBook publishing partnerships](file:///core/services/publishing-partners/ebook-publishing-partnerships) 3.

- [Journal publishing partnerships](file:///core/services/publishing-partners/journal-publishing-partnerships) 4.
- Publishing partners (cont.) 5.
  - [Journals publishing](file:///core/services/publishing-partners/journals-publishing) 1.
  - [Customer support](file:///core/services/publishing-partners/customer-support) 2.
  - [Membership Services](file:///core/services/publishing-partners/membership-services) 3.
  - [Our Team](file:///core/services/publishing-partners/our-team) 4.
- Open research 2.
  - Open access policies 1.
    - Open access policies 1.
      - [Open research](file:///core/services/open-research-policies/open-research) 1.
      - [Open access policies](file:///core/services/open-research-policies/open-access-policies) 2.
      - [Cambridge University Press and Plan S](file:///core/services/open-research-policies/cambridge-university-press-and-plan-s) 3.
      - [Text and data mining](file:///core/services/open-research-policies/text-and-data-mining) 4.
      - [Preprint policy](file:///core/services/open-research-policies/preprint-policy) 5.
      - [Social sharing](file:///core/services/open-research-policies/social-sharing) 6.
    - Journals 7.
      - [Open access journals](file:///core/services/open-research-policies/open-access-journals) 1.
      - [Gold Open Access journals](file:///core/services/open-research-policies/gold-open-access-journals) 2.
      - [Transformative journals](file:///core/services/open-research-policies/transformative-journals) 3.
      - [Green Open Access policy for journals](file:///core/services/open-research-policies/green-open-access-policy-for-journals) 4.
      - [Transparent pricing policy for journals](file:///core/services/open-research-policies/transparent-pricing-policy-for-journals) 5.
    - Books and Elements 6.
      - [Open access books](file:///core/services/open-research-policies/open-access-books) 1.
      - [Gold open access books](file:///core/services/open-research-policies/gold-open-access-books) 2.
      - [Green Open Access policy for books](file:///core/services/open-research-policies/green-open-access-policy-for-books) 3.
      - [Open access Elements](file:///core/services/open-research-policies/open-access-elements) 4.
  - Open access publishing 2.
    - About open access 1.
      - [Open research](file:///core/services/open-access-publishing/open-research) 1.
      - [Open Access Week](file:///core/services/open-access-publishing/open-access-week) 2.
      - [What is open access?](file:///core/services/open-access-publishing/open-access) 3.
      - [Open access glossary](file:///core/services/open-access-publishing/open-access-glossary) 4.
      - [Open access myths](file:///core/services/open-access-publishing/open-access-myths) 5.
      - [Hybrid Open Access FAQs](file:///core/services/open-access-publishing/hybrid-open-access-faqs) 6.
      - [Eligibility checker](file:///core/eligibility-checker) 7.
    - Open access resources 8.
      - [Open access resources](file:///core/services/open-access-publishing/open-access-resources) 1.
      - [Benefits of open access](file:///core/services/open-access-publishing/benefits-of-open-access) 2.
      - [Creative commons licences](file:///core/services/open-access-publishing/creative-commons-licenses) 3.
      - [Funder policies and mandates](file:///core/services/open-access-publishing/funder-policies-and-mandates) 4.
      - [Article type definitions](file:///core/services/open-access-publishing/article-type-definitions) 5.
      - [Convert your article to Gold Open Access](file:///core/services/open-access-publishing/convert-your-article-to-open-access) 6.
      - [Open access video resources](file:///core/services/open-access-publishing/open-access-video-resources) 7.
  - Open research initiatives 2.
    - Research transparency 1.
      - [Transparency and openness](file:///core/services/open-research-initiatives/transparency-and-openness) 1.
      - [Open Practice Badges](file:///core/services/open-research-initiatives/open-practice-badges) 2.
      - [OA organisations, initiatives & directories](file:///core/services/open-research-initiatives/oa-organisations-initiatives-and-directories) 3.
      - [Registered Reports](file:///core/services/open-research-initiatives/registered-reports) 4.
      - [Annotation for Transparent Inquiry \(ATI\)](file:///core/services/open-research-initiatives/annotation-for-transparent-inquiry-ati) 5.
    - Journal flips 6.
      - [Open access journal flips](file:///core/services/open-research-initiatives/open-access-journal-flips) 1.

- [OA Journal Flip FAQs](file:///core/services/open-research-initiatives/oa-journal-flip-faqs) 2.
- Flip it Open 3.
  - [Flip it Open](file:///core/services/open-research-initiatives/flip-it-open) 1.
  - [Flip it Open FAQs](file:///core/services/open-research-initiatives/flip-it-open-faqs) 2.
- Open access funding 2.
  - Open access funding 1.
    - [Funding open access publication](file:///core/services/open-access-funding/funding-open-access-publication) 1.
    - [Cambridge Open Equity Initiative](file:///core/services/open-access-funding/cambridge-open-equity-initiative) 2.
    - [Completing a RightsLink \(open access\) transaction](file:///core/services/open-access-funding/completing-a-rightslink-open-access-transaction) 3.
- Cambridge Open Engage 2.
  - Cambridge Open Engage 1.
    - [Cambridge Open Engage](file:///core/services/cambridge-open-engage/cambridge-open-engage) 1.
    - [Partner With Us](file:///core/services/cambridge-open-engage/engage-partner-with-us) 2.
    - [Branded Hubs](file:///core/services/cambridge-open-engage/engage-branded-hubs) 3.
    - [Event Workspaces](file:///core/services/cambridge-open-engage/engage-event-workspaces) 4.
    - [Partner Resources](file:///core/services/cambridge-open-engage/engage-partner-resources) 5.
    - [APSA Preprints](file:///core/services/cambridge-open-engage/engage-apsa-preprints) 6.
    - [APSA Preprints FAQs](file:///core/services/cambridge-open-engage/engage-apsa-preprints-faqs) 7.
- [Home](file:///core) •
- [>Journals](file:///core/publications/journals) •
- [>Canadian Journal of Mathematics](file:///core/journals/canadian-journal-of-mathematics) •
- [>Volume 17](file:///core/journals/canadian-journal-of-mathematics/volume/0ECF6F65585DA2D3FA958C1F7BCA0AD3) •
- >Paths, Trees, and Flowers •
- English •
- Français •

![](_page_8_Picture_25.jpeg)

[Canadian Journal of Mathematics](file:///core/journals/canadian-journal-of-mathematics) 

# **Article contents**

- [Extract](#page-9-1) •
- [References](#page-10-0) •

# <span id="page-9-0"></span>**Paths, Trees, and Flowers**

Published online by Cambridge University Press: **20 November 2018**

[Jack Edmonds](file:///core/search?filters%5BauthorTerms%5D=Jack%20Edmonds&eventCode=SE-AU) [Show author details](#page-9-2)

<span id="page-9-2"></span>Jack Edmonds\*

Affiliation: National Bureau of Standards and Princeton University

- [Article](#page-9-3)  •
- [Metrics](#page-10-1)  •

## <span id="page-9-3"></span>[Article contents](#page-9-4)

- <span id="page-9-4"></span>[Extract](#page-9-1) •
- [References](#page-10-0) •

Save PDF Share

Cite [Rights & Permissions \[Opens in a new](https://s100.copyright.com/AppDispatchServlet?publisherName=CUP&publication=CJM&title=Paths%2C%20Trees%2C%20and%20Flowers&publicationDate=20%20November%202018&author=Jack%20Edmonds©right=Canadian%20Mathematical%20Society%201965&contentID=10.4153%2FCJM-1965-045-4&startPage=449&endPage=467&orderBeanReset=True&volumeNum=17&issueNum=&oa=)

[window\]](https://s100.copyright.com/AppDispatchServlet?publisherName=CUP&publication=CJM&title=Paths%2C%20Trees%2C%20and%20Flowers&publicationDate=20%20November%202018&author=Jack%20Edmonds©right=Canadian%20Mathematical%20Society%201965&contentID=10.4153%2FCJM-1965-045-4&startPage=449&endPage=467&orderBeanReset=True&volumeNum=17&issueNum=&oa=)

## <span id="page-9-1"></span>**Extract**

Core share and HTML view are not available for this content. However, as you have access to this content, a full PDF is available via the 'Save PDF' action button.

A graph G for purposes here is a finite set of elements called vertices and a finite set of elements called edges such that each edge meets exactly two vertices, called the end-points of the edge. An edge is said to join its endpoints.

A matching in G is a subset of its edges such that no two meet the same vertex. We describe an efficient algorithm for finding in a given graph a matching of maximum cardinality. This problem was posed and partly solved by C. Berge; see Sections 3.7 and 3.8.

# **Information**

Type Research Article Information

[Canadian Journal of Mathematics ,](file:///core/journals/canadian-journal-of-mathematics) [Volume 17 ,](file:///core/journals/canadian-journal-of-mathematics/volume/0ECF6F65585DA2D3FA958C1F7BCA0AD3) 1965 , pp. 449 - 467 DOI: [https://doi.org/10.4153/CJM-1965-045-4 \[Opens in a new window\]](https://doi.org/10.4153/CJM-1965-045-4) Copyright

Copyright © Canadian Mathematical Society 1965

# <span id="page-10-0"></span>**References**

1 1. Berge, C., Two theorems in graph theory, Proc. Natl. Acad. Sci. U.S., 43 (1957), 842–4[.Google Scholar](https://scholar.google.com/scholar?q=Berge,+C.,+Two+theorems+in+graph+theory,+Proc.+Natl.+Acad.+Sci.+U.S.,+43+(1957),+842%E2%80%934.) 2 2. Berge, C., The theory of graphs and its applications (London, 1962).[Google](https://scholar.google.com/scholar?q=Berge,+C.,+The+theory+of+graphs+and+its+applications+(London,+1962).) [Scholar](https://scholar.google.com/scholar?q=Berge,+C.,+The+theory+of+graphs+and+its+applications+(London,+1962).) 3 3. Edmonds, J., Covers and packings in a family of sets, Bull. Amer. Math. Soc, 68 (1962), 494–9[.Google Scholar](https://scholar.google.com/scholar?q=Edmonds,+J.,+Covers+and+packings+in+a+family+of+sets,+Bull.+Amer.+Math.+Soc,+68+(1962),+494%E2%80%939.) 4 4. Edmonds, J., Maximum matching and a polyhedron with (0, 1) vertices, appearing in J. Res. Natl. Bureau Standards 69B (1965)[.Google Scholar](https://scholar.google.com/scholar?q=Edmonds,+J.,+Maximum+matching+and+a+polyhedron+with+(0,+1)+vertices,+appearing+in+J.+Res.+Natl.+Bureau+Standards+69B+(1965).) 5 5. Ford, L. R. Jr. and Fulkerson, D. R., Flows in networks (Princeton, 1962)[.Google Scholar](https://scholar.google.com/scholar?q=Ford,+L.+R.+Jr.+and+Fulkerson,+D.+R.,+Flows+in+networks+(Princeton,+1962).) 6 6. Hoffman, A. J., Some recent applications of the theory of linear inequalities to extremal combinatorial analysis, Proc. Symp. on Appl. Math., 10 (1960), 113–27[.Google Scholar](https://scholar.google.com/scholar?q=Hoffman,+A.+J.,+Some+recent+applications+of+the+theory+of+linear+inequalities+to+extremal+combinatorial+analysis,+Proc.+Symp.+on+Appl.+Math.,+10+(1960),+113%E2%80%9327.) 7 7. Norman, R. Z. and Rabin, M. O., An algorithm for a minimum cover of a graph, Proc. Amer. Math. Soc, 10 (1959), 315–19[.Google Scholar](https://scholar.google.com/scholar?q=Norman,+R.+Z.+and+Rabin,+M.+O.,+An+algorithm+for+a+minimum+cover+of+a+graph,+Proc.+Amer.+Math.+Soc,+10+(1959),+315%E2%80%9319.) 8 8. Tutte, W. T., The factorization of linear graphs, J. London Math. Soc, 22 (1947), 107–11.[Google Scholar](https://scholar.google.com/scholar?q=Tutte,+W.+T.,+The+factorization+of+linear+graphs,+J.+London+Math.+Soc,+22+(1947),+107%E2%80%9311.) 9 9. Witzgall, C. and Zahn, C. T. Jr., Modification of Edmonds﹜ algorithm for maximum matching of graphs, appearing in J. Res. Natl. Bureau Standards 69B (1965)[.Google Scholar](https://scholar.google.com/scholar?q=Witzgall,+C.+and+Zahn,+C.+T.+Jr.,+Modification+of+Edmonds%EF%B9%9C+algorithm+for+maximum+matching+of+graphs,+appearing+in+J.+Res.+Natl.+Bureau+Standards+69B+(1965).) You have Access

# **Cited by**

Cited by

Loading...

<span id="page-10-1"></span>1974

## Cited by

![](_page_11_Picture_1.jpeg)

Crossref Citations

![](_page_11_Picture_3.jpeg)

**This article has been cited by the following publications. This list is generated based on data provided by [Crossref.](http://www.crossref.org/citedby/index.html)**

Tutte, W. T. 1967. Antisymmetrical Digraphs. Canadian Journal of Mathematics, Vol. 19, Issue. , p. 1101.

- [CrossRef](https://doi.org/10.4153/CJM-1967-101-8) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Antisymmetrical+Digraphs&author=Tutte+W.+T.&publication_year=1967) •

Hakimi, S.L and Frank, H 1969. Maximum internally stable sets of a graph. Journal of Mathematical Analysis and Applications, Vol. 25, Issue. 2, p. 296.

- [CrossRef](https://doi.org/10.1016/0022-247X(69)90233-9) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Maximum+internally+stable+sets+of+a+graph&author=Hakimi+S.L&author=Frank+H&publication_year=1969) •

Montanari, Ugo 1970. Heuristically guided search and chromosome matching. Artificial Intelligence, Vol. 1, Issue. 3-4, p. 227.

- [CrossRef](https://doi.org/10.1016/0004-3702(70)90009-3) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Heuristically+guided+search+and+chromosome+matching&author=Montanari+Ugo&publication_year=1970) •

Edmonds, Jack and Fulkerson, D.R. 1970. Bottleneck extrema. Journal of Combinatorial Theory, Vol. 8, Issue. 3, p. 299.

- [CrossRef](https://doi.org/10.1016/S0021-9800(70)80083-7) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Bottleneck+extrema&author=Edmonds+Jack&author=Fulkerson+D.R.&publication_year=1970) •

Turner, James and Kautz, William H. 1970. A Survey of Progress in Graph Theory in the Soviet Union. SIAM Review, Vol. 12, Issue. S1, p. 1.

- [CrossRef](https://doi.org/10.1137/1012125) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=A+Survey+of+Progress+in+Graph+Theory+in+the+Soviet+Union&author=Turner+James&author=Kautz+William+H.&publication_year=1970) •

Fulkerson, D. R. 1971. Blocking and anti-blocking pairs of polyhedra. Mathematical Programming, Vol. 1, Issue. 1, p. 168.

[CrossRef](https://doi.org/10.1007/BF01584085) •

### [Google Scholar](https://scholar.google.com/scholar_lookup?title=Blocking+and+anti-blocking+pairs+of+polyhedra&author=Fulkerson+D.+R.&publication_year=1971) •

Hopcroft, John E. and Karp, Richard M. 1971. A n5/2 algorithm for maximum matchings in bipartite. p. 122.

- [CrossRef](https://doi.org/10.1109/SWAT.1971.1) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=A+n5/2+algorithm+for+maximum+matchings+in+bipartite&author=Hopcroft+John+E.&author=Karp+Richard+M.&publication_year=1971) •

Brualdi, R. A. 1971. Matchings in Arbitrary Graphs. Mathematical Proceedings of the Cambridge Philosophical Society, Vol. 69, Issue. 3, p. 401.

- [CrossRef](https://doi.org/10.1017/S0305004100046831) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Matchings+in+Arbitrary+Graphs&author=Brualdi+R.+A.&publication_year=1971) •

Fujii, M. Kasami, T. and Ninomiya, K. 1971. Erratum "Optimal Sequencing of Two Equivalent Processors". SIAM Journal on Applied Mathematics, Vol. 20, Issue. 1, p. 141.

- [CrossRef](https://doi.org/10.1137/0120018) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Erratum+%E2%80%9COptimal+Sequencing+of+Two+Equivalent+Processors%E2%80%9D&author=Fujii+M.&author=Kasami+T.&author=Ninomiya+K.&publication_year=1971) •

White, Lee J. 1971. Minimum Covers of Fixed Cardinality in Weighted Graphs. SIAM Journal on Applied Mathematics, Vol. 21, Issue. 1, p. 104.

- [CrossRef](https://doi.org/10.1137/0121014) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Minimum+Covers+of+Fixed+Cardinality+in+Weighted+Graphs&author=White+Lee+J.&publication_year=1971) •

1971. An account of some aspects of combinatorial mathematics. Vol. 75, Issue. , p. 236.

- [CrossRef](https://doi.org/10.1016/S0076-5392(08)63140-9) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=An+account+of+some+aspects+of+combinatorial+mathematics&&publication_year=1971) •

Lovász, L. 1972. The factorization of graphs. II. Acta Mathematica Academiae Scientiarum Hungaricae, Vol. 23, Issue. 1-2, p. 223.

- [CrossRef](https://doi.org/10.1007/BF01889919) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=The+factorization+of+graphs.+II&author=Lov%C3%A1sz+L.&publication_year=1972) •

Dörfler, W. and Mühlbacher, J. 1972. Bestimmung eines maximalen Matching in beliebigen Graphen. Computing, Vol. 9, Issue. 3, p. 251.

- [CrossRef](https://doi.org/10.1007/BF02246734) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Bestimmung+eines+maximalen+Matching+in+beliebigen+Graphen&author=D%C3%B6rfler+W.&author=M%C3%BChlbacher+J.&publication_year=1972) •

Balinski, M.L 1972. Establishing the matching polytope. Journal of Combinatorial Theory, Series B, Vol. 13, Issue. 1, p. 1.

- [CrossRef](https://doi.org/10.1016/0095-8956(72)90002-0) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Establishing+the+matching+polytope&author=Balinski+M.L&publication_year=1972) •

Berge, Claude 1972. Graph Theory and Computing. p. 1.

- [CrossRef](https://doi.org/10.1016/B978-1-4832-3187-7.50006-4) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Graph+Theory+and+Computing&author=Berge+Claude&publication_year=1972) •

Fulkerson, D.R 1972. Anti-blocking polyhedra. Journal of Combinatorial Theory, Series B, Vol. 12, Issue. 1, p. 50.

- [CrossRef](https://doi.org/10.1016/0095-8956(72)90032-9) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Anti-blocking+polyhedra&author=Fulkerson+D.R&publication_year=1972) •

Edmonds, Jack and Karp, Richard M. 1972. Theoretical Improvements in Algorithmic Efficiency for Network Flow Problems. Journal of the ACM, Vol. 19, Issue. 2, p. 248.

- [CrossRef](https://doi.org/10.1145/321694.321699) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Theoretical+Improvements+in+Algorithmic+Efficiency+for+Network+Flow+Problems&author=Edmonds+Jack&author=Karp+Richard+M.&publication_year=1972) •

Lawler, Eugene L. 1972. Periodic Optimization. p. 37.

- [CrossRef](https://doi.org/10.1007/978-3-7091-2652-3_3) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Periodic+Optimization&author=Lawler+Eugene+L.&publication_year=1972) •

Lovász, L. 1972. On the structure of factorizable graphs. II. Acta Mathematica Academiae Scientiarum Hungaricae, Vol. 23, Issue. 3-4, p. 465.

- [CrossRef](https://doi.org/10.1007/BF01896966) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=On+the+structure+of+factorizable+graphs.+II&author=Lov%C3%A1sz+L.&publication_year=1972) •

Lovász, L. 1972. On the structure of factorizable graphs. Acta Mathematica Academiae Scientiarum Hungaricae, Vol. 23, Issue. 1-2, p. 179.

- [CrossRef](https://doi.org/10.1007/BF01889914) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=On+the+structure+of+factorizable+graphs&author=Lov%C3%A1sz+L.&publication_year=1972) •

## [Download full list](file:///core/services/aop-cambridge-core/download/cited-by?doi=10.4153/CJM-1965-045-4&productType=JOURNAL_ARTICLE&productId=08B492B72322C4130AE800C0610E0E21)

![](_page_13_Picture_19.jpeg)

# **Our Site**

- [Accessibility](file:///core/accessibility) •
- [Contact & Help](file:///core/help/FAQs) •
- [Legal Notices](file:///core/legal-notices/terms) •
- Cookie Settings •

# **Quick Links**

- [Cambridge Core](https://www.cambridge.org/core/) •
- [Cambridge Open Engage](https://www.cambridge.org/engage/coe/public-dashboard) •
- [Cambridge Aspire website](https://www.cambridge.org/highereducation/) •

# **Our Products**

- [Journals](https://www.cambridge.org/core/publications/journals) •
- [Books](https://www.cambridge.org/core/search?aggs%5BproductTypes%5D%5Bfilters%5D=BOOK) •
- [Elements](https://www.cambridge.org/core/publications/elements) •
- [Textbooks](https://www.cambridge.org/highereducation/search?aggs=%24productTypes%24BOOK%3Atrue%3B%3B) •
- [Courseware](https://www.cambridge.org/highereducation/search?aggs=%24productTypes%24COURSEWARE%3Atrue%3B%3B) •

# **Join us online**

| •        |  |  |
|----------|--|--|
| Location |  |  |
| GBR      |  |  |
|          |  |  |

Please choose a valid location.

![](_page_14_Picture_13.jpeg)

- [Rights & Permissions](https://www.cambridge.org/about-us/rights-permissions/) •
- [Copyright](https://www.cambridge.org/about-us/legal-notices/copyright/) •
- [Privacy Notice](https://www.cambridge.org/about-us/legal-notices/privacy-policy/) •
- [Terms of Use](https://www.cambridge.org/about-us/legal-notices/terms-use) •
- [Cookies Policy](https://www.cambridge.org/about-us/legal-notices/cookies-policy/) •

Cambridge University Press 2025

[Cancel](file:///map-vepfs/shuang/EDR/PDF/199-recuVfJj6JEr5w/noise-0.pdf) [Confirm](file:///map-vepfs/shuang/EDR/PDF/199-recuVfJj6JEr5w/noise-0.pdf) [×](file:///map-vepfs/shuang/EDR/PDF/199-recuVfJj6JEr5w/noise-0.pdf)

# **Save article to Kindle**

To send this article to your Kindle, first ensure no-reply@cambridge.org is added to your Approved Personal Document E-mail List under your Personal Document Settings on the Manage Your Content and Devices page of your Amazon account. Then enter the 'name' part of your Kindle email address below. Find out more about sending to your Kindle. [Find out more about](file:///core/help) [saving to your Kindle](file:///core/help).

Note you can select to save to either the @free.kindle.com or @kindle.com variations. '@free.kindle.com' emails are free but can only be saved to your device when it is connected to wi-fi. '@kindle.com' emails can be delivered even when you are not connected to wi-fi, but note that service fees apply.

Find out more about the [Kindle Personal Document Service.](https://www.amazon.com/gp/help/customer/display.html/ref=kinw_myk_wl_ln?ie=UTF8&nodeId=200767340#fees)

Paths, Trees, and Flowers

- Volume 17 •
- [Jack Edmonds](file:///core/search?filters%5BauthorTerms%5D=Jack%20Edmonds&eventCode=SE-AU) (a1) •
- DOI:<https://doi.org/10.4153/CJM-1965-045-4> •

| Your Kindle email address            |                                                                                                                 |  |
|--------------------------------------|-----------------------------------------------------------------------------------------------------------------|--|
|                                      |                                                                                                                 |  |
| @free.kindle.com                     |                                                                                                                 |  |
| @kindle.com (service fees apply)     |                                                                                                                 |  |
|                                      |                                                                                                                 |  |
| Available formats                    |                                                                                                                 |  |
| PDF                                  |                                                                                                                 |  |
|                                      |                                                                                                                 |  |
|                                      | By using this service, you agree that you will only keep content for personal                                   |  |
|                                      | use, and will not openly distribute them via Dropbox, Google Drive or other                                     |  |
| file sharing services                |                                                                                                                 |  |
| false                                |                                                                                                                 |  |
| kindle                               |                                                                                                                 |  |
| 08B492B72322C4130AE800C0610E0E21     |                                                                                                                 |  |
|                                      | /core/journals/canadian-journal-of-mathematics/article/paths-trees-and-flowers/08B492B72322C4130AE800C0610E0E21 |  |
| ctqvj52d-xaII09CJYFxwPuBVrtAI5o6HVi4 |                                                                                                                 |  |
| Cancel                               |                                                                                                                 |  |
|                                      |                                                                                                                 |  |
| Save                                 |                                                                                                                 |  |

×

# **Save article to Dropbox**

To save this article to your Dropbox account, please select one or more formats and confirm that you agree to abide by our usage policies. If this is the first time you used this feature, you will be asked to authorise Cambridge Core to connect with your Dropbox account. [Find out more about saving](file:///core/help) [content to Dropbox](file:///core/help).

Paths, Trees, and Flowers

- Volume 17 •
- [Jack Edmonds](file:///core/search?filters%5BauthorTerms%5D=Jack%20Edmonds&eventCode=SE-AU) (a1) •
- DOI:<https://doi.org/10.4153/CJM-1965-045-4> •

| Available formats<br>PDF             |                                                                                                                                                              |  |
|--------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------|--|
| file sharing services                | By using this service, you agree that you will only keep content for personal<br>use, and will not openly distribute them via Dropbox, Google Drive or other |  |
| false                                |                                                                                                                                                              |  |
| dropbox                              |                                                                                                                                                              |  |
| 08B492B72322C4130AE800C0610E0E21     |                                                                                                                                                              |  |
|                                      | /core/journals/canadian-journal-of-mathematics/article/paths-trees-and-flowers/08B492B72322C4130AE800C0610E0E21                                              |  |
| ctqvj52d-xaII09CJYFxwPuBVrtAI5o6HVi4 |                                                                                                                                                              |  |
| Cancel                               |                                                                                                                                                              |  |
|                                      |                                                                                                                                                              |  |
| Save                                 |                                                                                                                                                              |  |

×

# **Save article to Google Drive**

To save this article to your Google Drive account, please select one or more formats and confirm that you agree to abide by our usage policies. If this is the first time you used this feature, you will be asked to authorise Cambridge Core to connect with your Google Drive account. [Find out more about saving](file:///core/help) [content to Google Drive.](file:///core/help)

Paths, Trees, and Flowers

- Volume 17 •
- [Jack Edmonds](file:///core/search?filters%5BauthorTerms%5D=Jack%20Edmonds&eventCode=SE-AU) (a1) •
- DOI:<https://doi.org/10.4153/CJM-1965-045-4> •

| Available formats<br>PDF |                                                                                                                                                              |
|--------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------|
| file sharing services    | By using this service, you agree that you will only keep content for personal<br>use, and will not openly distribute them via Dropbox, Google Drive or other |
| false                    |                                                                                                                                                              |
| googleDrive              |                                                                                                                                                              |

×

×

## **Reply to: Submit a response**

| ctqvj52d-xaII09CJYFxwPuBVrtAI5o6HVi4 |
|--------------------------------------|
|                                      |
|                                      |
| Title *                              |
|                                      |

Please enter a title for your response.

# Contents \* [Contents help](file:///map-vepfs/shuang/EDR/PDF/199-recuVfJj6JEr5w/noise-0.pdf) [Close Contents help](file:///map-vepfs/shuang/EDR/PDF/199-recuVfJj6JEr5w/noise-0.pdf) - No HTML tags allowed - Web page URLs will display as text only - Lines and paragraphs break automatically - Attachments, images or tables are not permitted Please enter your response.

| Your details                  |
|-------------------------------|
| First name *                  |
|                               |
| Please enter your first name. |

| Last name *                                                                                                                                                                                               |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Please enter your last name.<br>Email *<br>Email help                                                                                                                                                     |
|                                                                                                                                                                                                           |
| Close Email help                                                                                                                                                                                          |
| Your email address will be used in order to notify you when your comment<br>has been reviewed by the moderator and in case the author(s) of the article<br>or the moderator need to contact you directly. |
| Please enter a valid email address.                                                                                                                                                                       |
|                                                                                                                                                                                                           |

Occupation

Affiliation

Please enter your occupation.

Please enter any affiliation.

Add contributor

**You have entered the maximum number of contributors**

## **Conflicting interests**

Do you have any conflicting interests? \* [Conflicting interests help](file:///map-vepfs/shuang/EDR/PDF/199-recuVfJj6JEr5w/noise-0.pdf)

![](_page_20_Picture_5.jpeg)

Please list any fees and grants from, employment by, consultancy for, shared ownership in or any close relationship with, at any time over the preceding 36 months, any organisation whose interests may be affected by the publication of the response. Please also list any non-financial associations or interests

(personal, professional, political, institutional, religious or other) that a reasonable reader would want to know about in relation to the submitted