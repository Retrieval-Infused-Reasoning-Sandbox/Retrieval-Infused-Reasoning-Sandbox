# Compressing CFI Graphs and Lower Bounds for the Weisfeiler-Leman Refinements\*

Martin Grohe
RWTH Aachen University

Moritz Lichter RWTH Aachen University Daniel Neuen University of Bremen

Pascal Schweitzer
TU Darmstadt

**Abstract.** The k-dimensional Weisfeiler-Leman (k-WL) algorithm is a simple combinatorial algorithm that was originally designed as a graph isomorphism heuristic. It naturally finds applications in Babai's quasipolynomial-time isomorphism algorithm, practical isomorphism solvers, and algebraic graph theory. However, it also has surprising connections to other areas such as logic, proof complexity, combinatorial optimization, and machine learning.

The algorithm iteratively computes a coloring of the k-tuples of vertices of a graph. Since Fürer's linear lower bound [ICALP 2001], it has been an open question whether there is a super-linear lower bound for the iteration number for k-WL on graphs. We answer this question affirmatively, establishing an  $\Omega(n^{k/2})$ -lower bound for all k.

#### 1 Introduction

The Weisfeiler-Leman algorithm is a simple combinatorial algorithm that iteratively colors tuples of vertices of a graph, attempting to assign different colors to tuples that are structurally different (i.e., they belong to different orbits of the automorphism group). While it is known that this goal cannot be reached on all graphs [7], the algorithm still serves as a powerful heuristic for computing automorphisms and isomorphism of graphs. The 2-dimensional "classical" Weisfeiler-Leman algorithm [33], coloring pairs of vertices, is rooted in algebraic graph theory and closely linked to structures known as coherent configurations. The k-dimensional version, coloring k-tuples, was introduced later by Babai and Mathon (see [7]). It plays an important role in Babai's quasipolynomial-time isomorphism algorithm [3]. Remarkably, the Weisfeiler-Leman algorithm is not only relevant in the context of the graph isomorphism problem, but has surprising connections to important and seemingly unrelated concepts in logic [7, 17], combinatorics [10], combinatorial optimization [2, 13, 15, 23], proof complexity [1, 4], and machine learning [24, 25, 31, 34].

The k-dimensional Weisfeiler-Leman algorithm (k-WL) colors the k-tuples of vertices of a graph in a sequence of refinement rounds. Initially, each tuple is colored by the isomorphism type of the subgraph it induces. In each round the coloring (more precisely, the partition it induces) is refined by comparing the color patterns of the neighborhoods of tuples, where the neighborhood of a tuple consist of all tuples that only differ in one position. The algorithm stops once a stable coloring is reached, which means that the partition into color classes is no longer refined in subsequent steps.

The two main parameters of the algorithm are the dimension and the iteration number, which is the maximum number of refinement steps it needs as function of the number of vertices. Both parameters have been studied to great depth (see [18]). In this paper, we focus on the iteration number. A trivial upper bound on the iteration number of k-WL is  $n^k - 1$ , where n is the

<sup>\*</sup>The first author is funded by the European Union (ERC, SymSim, 101054974). The second and fourth author are also funded by the European Union (ERC, EngageS, 820148). Views and opinions expressed are however those of the author(s) only and do not necessarily reflect those of the European Union or the European Research Council. Neither the European Union nor the granting authority can be held responsible for them.

number of vertices. For 1-WL, this trivial upper bound (n-1) can actually be reached [19]. Maybe surprisingly, this is no longer the case for 2-WL [20]. In fact, the iteration number of 2-WL is in  $\mathcal{O}(n \log n)$  [22] and, more generally, the iteration number of k-WL is in  $\mathcal{O}(n^{k-1} \log n)$  for all  $k \geq 2$  [14]. Not much is known in terms of lower bounds, at least not on graphs. The WL algorithm can also be applied to arbitrary relational structures, and it was proved in [6] that the iteration number of k-WL on k-ary relational structures is  $n^{\Omega(\frac{k}{\log k})}$ . This was recently improved to  $n^{\Omega(k)}$  [14]. However, for k-WL on graphs the best-known lower bound so far has been  $\Omega(n)$  [11].

# <span id="page-1-0"></span>**Theorem 1.** The maximum iteration number of k-WL on graphs is in $\Omega(n^{k/2})$ .

Our lower bound is not only the first super-linear lower bound for the iteration number of k-WL on graphs, it even improves the lower bounds that have previously been known for k-ary relational structures (while using only the binary edge relation of graphs). We also remark that, similar to [6, 11, 14], our construction actually provides pairs of graphs which are only distinguished by k-WL after  $\Omega(n^{k/2})$  many rounds. Finally, we note that our lower bound essentially remains valid even if k depends on k. Indeed, our construction works for all  $k = \mathcal{O}(n^{1/2-\varepsilon})$  where k > 0 is some arbitrarily small constant. However, in this case the lower bound becomes a little weaker due to some factors depending on k (see Corollary 34 for the precise result).

**Techniques.** In a nutshell, our proof starts from the linear lower bound construction by Fürer [11] and applies a novel compression technique to reduce the size of the graphs. The lower bounds for k-ary relational structures [6, 14] follow a similar general strategy, but apply a different compression technique, introduced by Razborov [27] in the context of proof complexity. Our technique not only avoids the introduction of k-ary constraints and hence k-ary relations, but also leads to a stronger compression. We note that, after its first publication, our construction has already been used in proof complexity to show treelike-size vs. width trade-offs for resolution [5].

Let us highlight a few more details. Our lower bound construction starts with the classic CFI construction used in [11] to show a linear lower bound  $(\Omega(n))$  for the iteration number of k-WL. This construction uses a  $k \times n$  grid as a base graph, in which each vertex is replaced by a certain gadget. The central idea behind our construction, borrowed from another somewhat unrelated iterative process [29], is to reuse gadgets. We partition the vertices of the base graph into classes, and use for every class the same gadget instead of a new copy for each vertex in the original construction. At first sight this might seem absurd because the whole point of the gadgets in the CFI construction is that they can function independently as long as they originate from non-adjacent base vertices. The challenge is thus to partition the base vertices in such a manner that the iteration number remains largely unaffected, but the CFI graph shrinks. Our initial computer experiments showed that arbitrary reuse does not have the desired effect and instead the iteration number decreases dramatically. However, reusing gadgets for base vertices far apart showed promising behavior in the experimentally observed number of iterations. The actual partition must therefore be chosen carefully. Indeed, in our final theoretical construction, base vertices in each row are partitioned in a periodic manner. However we need to ensure that reused gadgets are conceptually "sufficiently far apart" to not interfere with gadgets of other rows. One way to achieve this is to ensure that periods for different rows are chosen to be mutually coprime. However, there is a complication, namely that choosing the periods to be mutually coprime leads to a type of "global dependency" among the gadgets. We fix this with a compromise of choosing the periods to be as coprime as possible while avoiding the global dependency. (The technical requirement is that every prime-power that appears in some period must appear in at least two of the periods.)

For a theoretical analysis of the iteration number, reusing gadgets for many base vertices leads to a significant increase in complexity. To handle this complexity, our arguments exploit a connection between cops and robber games and CFI graphs. For our purposes, we have to extend this connection to take into account the partitions we introduced. (In the new game rather than blocking a single vertex, a cop now blocks an entire class of the partition.)

## 2 Preliminaries

We denote by  $[\ell]$  the set  $\{1,\ldots,\ell\}$ , by  $[0,\ell]$  the set  $\{0,\ldots,\ell\}$ , and by  $\{\{a_1,\ldots,a_m\}\}$  the multiset containing the elements  $a_1,\ldots,a_m$ . A **colored graph** is a tuple G=(V,E,c), where  $c\colon V\to\mathbb{N}$  assigns colors to vertices. The vertex set V of G is denoted by V(G) and the edge set by E(G). We only consider simple graphs in this paper. The distance of two sets  $W,W'\subseteq V$  is the minimal distance of two vertices  $u\in W$  and  $u'\in W'$ . Isomorphisms of colored graphs have to be color-preserving, i.e., have to map vertices of color i to vertices of color i. We also consider (colored) graphs with an equivalence relation on the vertices, which we denote by  $(G,\equiv)$  or  $(V,E,c,\equiv)$ . The equivalence relation has to be preserved by isomorphisms.

The Weisfeiler-Leman Algorithm. We describe the k-dimensional Weisfeiler-Leman algorithm (k-WL). Fix  $k \geq 2$  and an arbitrary colored graph G = (V, E, c). The k-WL algorithm computes an isomorphism-invariant coloring of k-tuples of V. Such a coloring is a function  $\chi \colon V^k \to C$  for some finite set of colors C. For two such colorings  $\chi_i \colon V^k \to C_i$  for  $i \in [2]$ , the coloring  $\chi_1$  refines  $\chi_2$  if  $\chi_1(\bar{u}) = \chi_1(\bar{v})$  implies  $\chi_2(\bar{u}) = \chi_2(\bar{v})$  for all  $\bar{u}, \bar{v} \in V^k$ . The colorings are equivalent if  $\chi_1$  refines  $\chi_2$  and  $\chi_2$  refines  $\chi_1$ . In this case, both colorings induce the same partition of  $V^k$  into color classes.

In the **initial coloring**  $\chi_k^{(0)}$ , two k-tuples  $\bar{u} = (u_1, \ldots, u_k), \bar{v} = (v_1, \ldots, v_k) \in V^k$  get the same color  $\chi_k^{(0)}(\bar{u}) = \chi_k^{(0)}(\bar{v})$  if and only if the map defined via  $u_i \mapsto v_i$  for every  $i \in [k]$  is an isomorphism from the induced subgraph  $G[\{u_1, \ldots, u_k\}]$  to the induced subgraph  $G[\{v_1, \ldots, v_k\}]$ . The computed coloring is refined iteratively via

$$\chi_k^{(r+1)}(\bar{u}) := \left(\chi_k^{(r)}(\bar{u}), \left\{ \left(\chi_k^{(r)}(\bar{u}[w/1]), \dots, \chi_k^{(r)}(\bar{u}[w/k])\right) \mid w \in V \right\} \right)$$

for every  $\bar{u} \in V^k$ . Here,  $\bar{u}[w/i]$  denotes the tuple obtained from  $\bar{u}$  by replacing the *i*-th entry with the vertex w. Because  $\chi_k^{(r)}(\bar{u})$  is included in the new color of  $\bar{u}$ , the coloring  $\chi_k^{(r+1)}$  refines  $\chi_k^{(r)}$ . Because we color k-tuples, there is an  $r < |V|^k$  such that  $\chi_k^{(r)}$  is equivalent to  $\chi_k^{(r+1)}$ . We say that k-WL stabilizes after at most r iterations. The **iteration number** of k-WL on G is the minimal number r such that k-WL stabilizes after r iterations.

Let H be another colored graph with vertex set W. We now refer with  $\chi_k^{(r)}[G]$  and  $\chi_k^{(r)}[H]$  to the colorings computed by k-WL after r iterations on G and H, respectively. We say that k-WL distinguishes the colored graphs G and H after r rounds if there is a color q such that

$$\left|\left\{\,\bar{u}\in V^k\;\middle|\;\chi_k^{(r)}[G](\bar{u})=q\,\right\}\right|\neq \left|\left\{\,\bar{v}\in W^k\;\middle|\;\chi_k^{(r)}[H](\bar{v})=q\,\right\}\right|.$$

Note that if k-WL distinguishes G and H after r+1 rounds but not after r, then the iteration number of k-WL on G and on H is at least r+1.

We also apply the WL algorithm to pairs  $(G, \equiv)$  of a graph G extended by an equivalence relation  $\equiv$ . The only difference there is that in the initial coloring  $\chi_k^{(0)}$  the isomorphisms between the induced subgraphs of tuples also need to preserve the equivalence relation.

The Bijective Pebble Game. It is well-known that the distinguishing power of k-WL is captured by the following game. The bijective k-pebble game [16] is a game played by two players called Spoiler and Duplicator on two colored graphs G and H with vertex sets V and W,

respectively. There is a pair of pebbles  $p_i$  and  $q_i$  for every  $i \in [k]$ . The pebbles  $p_i$  can be placed on V and the pebbles  $q_i$  on W. When  $\ell$  pebble pairs are placed for some  $\ell \in [k]$ , then the **position** in the game is the pair  $\bar{u}, \bar{v}$  for  $\bar{u} = (u_1, \ldots, u_\ell) \in V^\ell$  and  $\bar{v} = (v_1, \ldots, v_\ell) \in W^\ell$ where corresponding pebbles are placed on  $u_i$  and  $v_i$  for every  $i \in [\ell]$ . Spoiler wins immediately if  $|V| \neq |W|$ . Otherwise, the pebbles are initially placed beside the graphs. A round of the game is played as follows:

- 1. Spoiler picks up a pair of pebbles  $p_i$  and  $q_i$ .
- 2. Duplicator chooses a bijection  $h: V \to W$ .
- 3. Spoiler chooses a vertex  $u \in V$  and places  $p_i$  on u in G and  $q_i$  on h(u) in H.

Spoiler wins in r rounds, if after at most r rounds the current position  $\bar{u}, \bar{v}$  does not induce a partial isomorphism. That is, the mapping  $u_i \mapsto v_i$  for every  $i \in [\ell]$  is not an isomorphism of the induced subgraphs  $G[\{u_1,\ldots,u_\ell\}]$  and  $H[\{v_1,\ldots,v_\ell\}]$ . Duplicator wins in r rounds if Spoiler does not win in r rounds. Spoiler wins a play if Spoiler wins after some round. Duplicator wins if Spoiler never wins. Spoiler (respectively, Duplicator) has a winning strategy in r rounds if they can force a win interdependently of the moves of the other player. We write  $G \simeq_k^r H$ if Duplicator has a winning strategy in r rounds and  $G, \bar{u} \simeq_k^r H, \bar{v}$  in case Duplicator has a winning strategy when starting in position  $\bar{u}, \bar{v}$ . When considering the game without a fixed number of rounds, we write  $G \simeq_k H$  if Duplicator has a winning strategy.

<span id="page-3-0"></span>**Lemma 2** ([16, 7]). For every  $k \geq 2$ , all colored graphs G and H, all  $\bar{u} \in V(G)^k$ ,  $\bar{v} \in V(H)^k$ , and  $r \in \mathbb{N}$ , we have  $G, \bar{u} \not\simeq_{k+1}^r H, \bar{v}$  if and only if  $\chi_k^{(r)}[G](\bar{u}) \neq \chi_k^{(r)}[H](\bar{v})$ . Furthermore,  $G \not\simeq_{k+1} H$  if and only if k-WL distinguishes G and H. The required round

number of Spoiler and the iteration number of k-WL differ by at most k.

We sometimes play the game on pairs  $(G, \equiv)$  of a graph G extended by an equivalence relation  $\equiv$ . The only difference there is that the partial isomorphisms in the winning condition have to preserve the equivalence relation as well. Lemma 2 remains true under this extension.

The Cops and Robber Game. We use the following game later to analyze the iteration number of the WL algorithm on a certain class of graphs. The k-Cops and Robber game [30] is played on a graph G between k many cops and a robber. Initially, the robber is placed on some edge of G and the cops are placed beside the graph (if G has no edge, the robber loses immediately). A round of the game is played as follows:

- <span id="page-3-2"></span>1. One cop is picked up, and a destination  $v \in V(G)$  for this cop is selected.
- 2. The robber moves to an edge reachable from the edge currently occupied by the robber via a path in G that does not use any vertex occupied by a cop.
- 3. The cop that was picked up in Step 1 is placed on v.

The robber is caught if cops are placed on both endpoints of the robber-occupied edge. If the robber is caught after at most r rounds, then the cops win in r rounds. Otherwise, the robber wins in r rounds. The cops (respectively, the robber) have a winning strategy in r rounds if they can force a win in r rounds independently of the action of the other player.

Note that in the original game the robber is also placed on a vertex and is caught if a cop is placed on the same vertex. The robber loses in one version of game exactly if the robber loses in the other and in exactly the same number of rounds. Placing the robber on edges is more suitable for our presentation.

<span id="page-3-1"></span> $<sup>^{1}</sup>$ This is often described as a cop entering a helicopter and flying to v. Before deciding on a move, the robber sees the helicopter approaching and knows that the cop will be moving to v.

## <span id="page-4-1"></span>3 CFI Graphs and the Linear Lower Bound for k-WL

We review the CFI construction [7] and the linear lower bound on the iteration number of k-WL [11].

**The CFI Construction.** The CFI construction starts with a so-called base graph. An **(ordered) base graph** is a connected, colored graph such that every vertex has a unique color. Note that if every vertex has a unique color (which is a natural number), the colors induce a linear order on the vertices. We make use of this linear order in later constructions. Also, when defining a base graph, we only specify the linear order on the vertices and implicitly assign colors from  $\{1, \ldots, n\}$  to the vertices according to the given linear order. We refer to the vertices and edges of a base graph as **base vertices** and **base edges**, respectively.

Let G = (V, E, c) be an ordered base graph and let  $f: E \to \mathbb{F}_2$  be some function. The **CFI** graph  $\mathsf{CFI}(G, f)$  is a colored graph and defined as follows. The vertices of the CFI gadget for a degree d base vertex  $u \in V$  are the pairs  $(u, \bar{a})$  for all d-tuples  $\bar{a} = (a_1, \ldots, a_d) \in \mathbb{F}_2^d$  with  $\sum \bar{a} = a_1 + \cdots + a_d = 0$ . We say that the vertex  $(u, \bar{a})$  has **origin** u. Vertices inherit the color of their origin. The vertices of the same origin form a gadget. Since every vertex of the base graph has a unique color, the vertices of each gadget form a color class of the CFI graph. For two adjacent base vertices  $u, v \in V$ , we add the following edges between the gadgets for u and v to  $\mathsf{CFI}(G, f)$ : Assume that u is the i-th neighbor of v and that v is the j-th neighbor of u (according to the order on v). An edge between vertices v and v is the v-th entry of v and only if v if v is the v-th entry of v and v is the v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-th entry of v-

**Isomorphisms of CFI Graphs.** Let  $g: E \to \mathbb{F}_2$  be another function. We say that a base edge  $e \in E$  is **twisted** with respect to f and g if  $f(e) \neq g(e)$ . Twisted edges can be moved by isomorphisms. We represent isomorphisms by sets of directed base edges.

**Definition 3** (Twisting). A set  $T \subseteq \{(u,v) \mid \{u,v\} \in E\}$  is called a G-twisting if, for every  $u \in V$ , the set  $T \cap (\{u\} \times V)$  is of even size. The twisting T

- twists an edge  $\{u,v\} \in E$  if the set T contains exactly one of (u,v) and (v,u) and
- fixes a vertex  $u \in V$  if  $T \cap (\{u\} \times V) = \emptyset$ .

With every G-twisting T, we associate the function  $g_T : E \to \mathbb{F}_2$  defined via  $g_T(\{u, v\}) = 1$  if and only if T twists  $\{u, v\}$ .

Twistings are one way to make typical arguments about isomorphisms between CFI graphs more explicit. These arguments all go back to [7] and have since been developed in [12, 16, 21]. We summarize them in the following lemma.

<span id="page-4-0"></span>**Lemma 4.** For every ordered base graph G, every  $f,g: E(G) \to \mathbb{F}_2$ , and every tuple  $\bar{u}$  of vertices of  $\mathsf{CFI}(G,f)$  (and thus of  $\mathsf{CFI}(G,g)$ ), we have  $(\mathsf{CFI}(G,f),\bar{u}) \cong (\mathsf{CFI}(G,g),\bar{u})$  if and only if there exists a G-twisting T such that  $f = g + g_T$  and T fixes all vertices in  $\bar{u}$ .

Intuitively, the simplest isomorphism of CFI graphs is one moving the twist between two base edges incident to the same base vertex. These isomorphisms can be composed to isomorphisms moving the twist along a path and in fact to all other isomorphisms: For every base vertex, for an even number of incident base edges it is changed whether the edge is twisted or not (which follows from the condition  $\sum \bar{a} = 0$  on the gadget vertices). Lemma 4 implies, in particular, that two CFI graphs  $\mathsf{CFI}(G, f)$  and  $\mathsf{CFI}(G, g)$  are isomorphic if and only if modulo 2 we have  $\sum f = \sum_{e \in E} f(e) = \sum_{e \in E} g(e) = \sum g$ .

![](_page_5_Picture_0.jpeg)

<span id="page-5-0"></span>![](_page_5_Picture_1.jpeg)

Figure 1: Two CFI graphs with the  $2 \times 4$  grid as base graph. The connection highlighted in red between the blue and pink gadget is twisted between the two CFI graphs.

CFI Graphs and the Cops and Robber Game. There is a close connection between the bijective k-pebble game played on non-isomorphic CFI graphs and the k-Cops and Robber game played on the base graph. Intuitively, Spoiler has to catch the twist with the pebbles. Placing a pebble in the bijective k-pebble game corresponds to placing a cop in the Cops and Robber game. Moving the twisted edge corresponds to moving the robber. In the bijective k-pebble game, the twistings have to fix the origins of the pebbled vertices. Analogously, the robber is not allowed to use vertices occupied by cops. The path the robber takes is exactly the path along which the twist is moved.

This leads to the following two lemmas. A proof of the first lemma is implicit in [8, Theorem 3].

<span id="page-5-1"></span>**Lemma 5.** Let  $k \geq 2$ ,  $r \in \mathbb{N}$ , G be an ordered base graph, and  $f, g \colon E(G) \to \mathbb{F}_2$ . If the robber has a winning strategy in the r-round k-Cops and Robber game played on G, then Duplicator has a winning strategy in the r-round bijective k-pebble game played on  $\mathsf{CFI}(G, f)$  and  $\mathsf{CFI}(G, g)$ .

The second lemma follows from combining [30], [28, Theorem 3.13], and [10, Theorem 7] (the lemma can also be proved more directly following the above intuition, but we are not aware of an explicit reference).

<span id="page-5-2"></span>**Lemma 6.** Let  $k \geq 2$ , G be an ordered base graph, and  $f, g: E(G) \to \mathbb{F}_2$  such that f and g twist an odd number of edges. If the cops have a winning strategy in the k-Cops and Robber game played on G, then Spoiler has a winning strategy in the bijective k-pebble game played on  $\mathsf{CFI}(G, f)$  and  $\mathsf{CFI}(G, g)$ .

The Linear Lower Bound. We recall the linear lower bound on the iteration number of k-WL by Fürer [11]. Fix some  $k \geq 2$  in this paragraph. Let  $n \geq k$  and define I := [0, k-1] and J := [0, n-1]. Let  $G_{I,J}$  denote the  $k \times n$  grid graph with row indices in I and column indices in J (i.e., k is the height and n is the width of the grid). Formally,  $V(G_{I,J}) := I \times J$  and

$$E(G_{I,J}) := \{\{(i,j), (i,j+1)\} \mid i \in I, j \in [0,n-2]\}$$
  
 
$$\cup \{\{(i,j), (i+1,j)\} \mid i \in [0,k-2], j \in J\}.$$

We remark that we choose indices starting from 0 because this turns out to be more convenient for later constructions.

First note that every vertex in  $G_{I,J}$  has degree at most 4. Thus, every CFI gadget contains at most 8 vertices and hence  $\mathsf{CFI}(G_{I,J},f)$  has  $\Theta(n)$  many vertices (for fixed k). We argue that k-WL needs  $\Omega(n)$  iterations to distinguish non-isomorphic CFI graphs  $\mathsf{CFI}(G_{I,J},f)$  and  $\mathsf{CFI}(G_{I,J},g)$  for  $f,g\colon E(G_{I,J})\to \mathbb{F}_2$  with  $\sum f\neq \sum g$  (cf. Figure 1 for k=2 and n=4). To do so, we can play the (k+1)-Cops and Robber game by Lemmas 2, 5, and 6.

The optimal strategy of the cops is to initially form a separator with k cops that cuts the grid into two halves. One of the two halves contains the robber. Using the one additional cop, the separator can slowly be moved to the border of the grid (by at most  $\mathcal{O}(1)$  columns per round). Thus, after  $\mathcal{O}(n)$  rounds, the robber is caught. To see that indeed  $\Omega(n)$  many rounds

are needed, we see that the cops cannot move the separator faster because there is only one additional cop. If the left border of the grid is not separated from the right border, then the robber can move between the two borders. If the cops form a separator again, the robber moves to the larger part of the grid. Because the cops can catch the robber, we obtain that k-WL distinguishes  $\mathsf{CFI}(G_{L,J},f)$  and  $\mathsf{CFI}(G_{L,J},g)$ , but only after  $\Omega(n)$  iterations.

## <span id="page-6-0"></span>4 Compressed CFI Graphs

In this section, we develop techniques to reduce the size of CFI graphs.

#### 4.1 Basic Construction

Our construction yields compressed CFI graphs. We describe isomorphisms of these compressed CFI graphs by twistings again. Fix an arbitrary ordered base graph G throughout this subsection.

**Definition 7** (Compression). An equivalence relation  $\equiv$  on V(G) is a G-compression if for all  $u, u', v, v' \in V(G)$  it satisfies the following two conditions:

- 1. If  $u \equiv v$ , then u and v are non-adjacent and of the same degree.
- 2. If  $\{u,v\}, \{u',v'\} \in E(G), u \equiv u', v \equiv v', \text{ and } v \text{ is the } i\text{-th neighbor of } u \text{ (according to the order on } G), \text{ then } v' \text{ is the } i\text{-th neighbor of } u'.$

Let  $\equiv \subseteq V^2$  be a G-compression. It induces an equivalence relation on  $\mathsf{CFI}(G,f)$  (independently of  $f\colon E(G)\to \mathbb{F}_2$ ), which we also denote by  $\equiv$ , as follows:  $(u,\bar{a})\equiv (v,\bar{b})$  if and only if  $u\equiv v$  and  $\bar{a}=\bar{b}$ . We denote by  $\mathsf{CFI}(G,f)/\equiv$  the colored graph obtained from  $\mathsf{CFI}(G,f)$  by contracting all  $\equiv$ -equivalence classes into a single vertex. Formally, the vertices of  $\mathsf{CFI}(G,f)/\equiv$  are the  $\equiv$ -equivalence classes  $u/\equiv := \{w\in V(\mathsf{CFI}(G,f))\mid w\equiv u\}$ , and there is an edge between  $u/\equiv$  and  $v/\equiv$  if there are  $u'\equiv u$  and  $v'\equiv v$  such that there is an edge between u' and u' in  $\mathsf{CFI}(G,f)$ . Observe that  $\mathsf{CFI}(G,f)/\equiv$  is loop-free by our condition on u that equivalent vertices of u are non-adjacent. The color of a u-equivalence class in  $\mathsf{CFI}(G,f)/\equiv$  is the minimal color of one of its members in  $\mathsf{CFI}(G,f)$ . We need to require that u is compatible with u in the following sense to obtain reasonable graphs.

**Definition 8.** A function  $f: E(G) \to \mathbb{F}_2$  is  $\equiv$ -compressible if, for all  $u, v, u', v' \in V$ , we have that if  $\{u, v\}, \{u', v'\} \in E(G), u \equiv u', \text{ and } v \equiv v', \text{ then } f(\{u, v\}) = f(\{u', v'\}).$ 

**Definition 9** (Compressed CFI). For a G-compression  $\equiv$  and a  $\equiv$ -compressible  $f: E(G) \to \mathbb{F}_2$ 

- the graph  $(\mathsf{CFI}(G,f),\equiv)$  obtained from extending the colored graph  $\mathsf{CFI}(G,f)$  with the relation  $\equiv$  is a **precompressed CFI graph** and
- the colored graph  $CFI(G, f)/_{\equiv}$  is a **compressed CFI graph**.

An example is given in Figure 2.

<span id="page-6-1"></span>**Lemma 10.** Let  $\equiv$  be a G-compression and  $f: E(G) \to \mathbb{F}_2$  be  $\equiv$ -compressible. If G is of maximum degree d and there are n many  $\equiv$ -equivalence classes, then  $\mathsf{CFI}(G,f)/_{\equiv}$  has at most  $2^{d-1}n$  vertices.

*Proof.* After contracting  $\equiv$  on  $(\mathsf{CFI}(G,f),\equiv)$ , there are exactly n gadgets in  $(\mathsf{CFI}(G,f),\equiv)$  whose vertices remain in  $\mathsf{CFI}(G,f)/_{\equiv}$ . For every base vertex of degree d', its gadget contains exactly  $2^{d'-1}$  vertices. Because every base vertex has degree at most d, the graph  $\mathsf{CFI}(G,f)/_{\equiv}$  has at most  $2^{d-1}n$  vertices.

<span id="page-7-0"></span>![](_page_7_Figure_0.jpeg)

![](_page_7_Figure_1.jpeg)

Figure 2: On the left, a precompressed CFI graph in which the vertices of two gadgets are identified by the compression (drawn by red lines). On the right, the obtained compressed CFI graph where identified vertices are contracted. Some edges are colored for the sake of visual distinguishability.

<span id="page-7-1"></span>**Lemma 11.** Let  $\equiv$  be a G-compression and let  $f: E(G) \to \mathbb{F}_2$  be  $\equiv$ -compressible. For all  $u, v \in V(\mathsf{CFI}(G, f))$ , the set  $\{u/\equiv, v/\equiv\}$  is an edge (or non-edge) in  $\mathsf{CFI}(G, f)/\equiv$  if and only if, for all (or equivalently some)  $u' \equiv u$  and  $v' \equiv v$  such that their origins are adjacent in G, the set  $\{u', v'\}$  is an edge (or non-edge, respectively) in  $(\mathsf{CFI}(G, f), \equiv)$ .

In particular, for all  $u, v \in V(\mathsf{CFI}(G, f))$  whose origins are adjacent in G, the set  $\{u/_{\equiv}, v/_{\equiv}\}$  is an edge in  $\mathsf{CFI}(G, f)/_{\equiv}$  if and only if  $\{u, v\}$  is an edge in  $(\mathsf{CFI}(G, f), \equiv)$ .

Proof. Let u and v be vertices of  $\mathsf{CFI}(G,f)$ , whose origins are adjacent in G. We first claim that  $\{u,v\}$  is an edge (or non-edge) in  $(\mathsf{CFI}(G,f),\equiv)$  if and only if, for all  $u'\equiv u$  and  $v'\equiv v$  such that their origins are adjacent in G, the set  $\{u',v'\}$  is an edge (or non-edge, respectively) in  $(\mathsf{CFI}(G,f),\equiv)$ . Let x and y be the origins of u and v, respectively, and  $u=(x,\bar{a})$  and  $v=(y,\bar{b})$  for tuples  $\bar{a}$  and  $\bar{b}$  over  $\mathbb{F}_2$  whose length is the degree of x and y, respectively. Assume that  $u'\equiv u$  and  $v'\equiv v$  and the origins x' and y' of u' and v', respectively, are adjacent in G. By the extension of the compression on the vertices of the CFI graphs, we have  $u'=(x',\bar{a})$  and  $v'=(y',\bar{b})$ . Let v be the i-th neighbor of u and u be the j-th neighbor of v. By the definition of CFI graphs and because  $\{x,y\}, \{x',y'\} \in E(G)$ , the set  $\{u,v\}$  is and edge in  $\mathsf{CFI}(G,f)$  if and only if u and u is an edge in  $\mathsf{CFI}(G,f)$ . The claim follows because  $\mathsf{CFI}(G,f),\equiv$  and  $\mathsf{CFI}(G,f)$  have the same edges.

We now prove the assertion of the lemma. By construction of the compressed CFI graphs,  $\{u/_{\equiv},v/_{\equiv}\}$  is an edge in  $\mathsf{CFI}(G,f)/_{\equiv}$  if and only if there are  $u'\equiv u$  and  $v'\equiv v$  such that  $\{u',v'\}$  is an edge in  $(\mathsf{CFI}(G,f),\equiv)$ . By the former claim, this is the case if and only if, for all  $u'\equiv u$  and  $v'\equiv v$  such that their origins are adjacent in G, the set  $\{u',v'\}$  is an edge in  $(\mathsf{CFI}(G,f),\equiv)$ . For the non-edge case,  $\{u/_{\equiv},v/_{\equiv}\}$  is not an edge in  $\mathsf{CFI}(G,f)/_{\equiv}$  if and only if for all  $u'\equiv u$  and  $v'\equiv v$ , the set  $\{u',v'\}$  is not edge in  $(\mathsf{CFI}(G,f),\equiv)$ . This is the case if and only if the same statement is true only for  $u'\equiv u$  and  $v'\equiv v$  whose origins are adjacent in G, because vertices whose origins are not adjacent in G are never adjacent in  $\mathsf{CFI}(G,f)$ .

For two compressed CFI graphs  $\mathsf{CFI}(G,f)/_{\equiv}$  and  $\mathsf{CFI}(G,g)/_{\equiv}$ , it is not obvious under which conditions on f, g, and  $\equiv$  they are isomorphic. In particular, the criterion of Lemma 4 does not extend to the compressed CFI graphs. To address this, we consider a restricted form of twistings, which respect isomorphisms of compressed CFI graphs.

**Definition 12** (Compressible Twisting). For a G-compression  $\equiv$ , a G-twisting T is called  $\equiv$ -compressible if the following holds for all  $u, u' \in V$  with  $u \equiv u'$ : Let u and u' be of degree d. Then for every  $i \in [d]$ , we have  $(u, v_i) \in T$  if and only if  $(u', v_i') \in T$ , where  $v_i$  is the i-th neighbor of u and  $v_i'$  is the i-th neighbor of u' (according to the order on G).

<span id="page-8-0"></span>**Lemma 13.** For every G-compression  $\equiv$ , every set of base vertices  $W \subseteq V$ , all  $\equiv$ -compressible  $f, g: E(G) \to \mathbb{F}_2$ , and every  $\ell$ -tuple  $\bar{u}$  of vertices in  $\mathsf{CFI}(G, f)$  (and hence of  $\mathsf{CFI}(G, g)$ ) such that the set of origins of all vertices in  $\bar{u}$  is W, the following are equivalent:

- 1.  $(\mathsf{CFI}(G, f)/_{\equiv}, \bar{u}/_{\equiv}) \cong (\mathsf{CFI}(G, g)/_{\equiv}, \bar{u}/_{\equiv})$ , where  $\bar{u}/_{\equiv}$  denotes the  $\ell$ -tuple whose i-th entry is the  $\equiv$ -equivalence class  $u_i/_{\equiv}$  of the i-th entry  $u_i$  of  $\bar{u}$  for every  $i \in [\ell]$ ,
- 2.  $(\mathsf{CFI}(G, f), \equiv, \bar{u}) \cong (\mathsf{CFI}(G, g), \equiv, \bar{u}), \ and$
- 3. there exists a  $\equiv$ -compressible G-twisting such that  $f = g + g_T$  and T fixes all vertices in W.

*Proof.* Let  $\equiv$  be a G-compression,  $W \subseteq V$ ,  $f,g \colon E(G) \to \mathbb{F}_2$  be  $\equiv$ -compressible, and  $\bar{u}$  be an  $\ell$ -tuple of vertices of  $\mathsf{CFI}(G,f)$  such that the set of origins of all vertices in  $\bar{u}$  is W. We show  $(1) \Rightarrow (2) \Rightarrow (3) \Rightarrow (1)$ .

Assume there is an isomorphism  $\varphi \colon \mathsf{CFI}(G,f)/_{\equiv} \to \mathsf{CFI}(G,g)/_{\equiv}$  such that  $\varphi(\bar{u}/_{\equiv}) = \bar{u}/_{\equiv}$ . We construct an isomorphism  $\psi \colon (\mathsf{CFI}(G,f),\equiv) \to (\mathsf{CFI}(G,g),\equiv)$ . Let w be an arbitrary vertex of  $(\mathsf{CFI}(G,f),\equiv)$  and  $w/_{\equiv}$  its  $\equiv$ -equivalence class, that itself is a vertex in  $\mathsf{CFI}(G,f)/_{\equiv}$ . The equivalence classes  $w/_{\equiv}$  and  $\varphi(w/_{\equiv})$  have the same color c. Let v be the unique base vertex of color c. By definition of the compressed CFI graphs,  $w/_{\equiv}$  and  $\varphi(w/_{\equiv})$  contain exactly one vertex with origin v' for every base vertex  $v' \equiv v$ . In particular,  $\varphi(w/_{\equiv})$  contains a vertex w' of the same origin as w. By construction, no  $\equiv$ -equivalence class contains two vertices of the same origin. Thus, w' is unique. We define  $\psi(w) \coloneqq w'$ . Again by construction,  $\psi$  is color preserving. Let v and w be vertices of  $\mathsf{CFI}(G,f)$  whose origins are adjacent. By Lemma 11,  $\{v,w\}$  is an edge in  $\mathsf{CFI}(G,f)$  if and only if  $\{v/_{\equiv}, w/_{\equiv}\}$  is an edge in  $\mathsf{CFI}(G,f)/_{\equiv}$  if and only if  $\{\varphi(v/_{\equiv}), \varphi(w/_{\equiv})\}$  is an edge in  $\mathsf{CFI}(G,g)/_{\equiv}$  if and only if  $\{\psi(v), \psi(w)\}$  is an edge in  $\mathsf{CFI}(G,g)$ . Two vertices, whose origins are not adjacent, are never adjacent themselves. Because  $\psi$  is color-preserving,  $\psi$  is indeed an isomorphism from  $(\mathsf{CFI}(G,f),\equiv)$  to  $(\mathsf{CFI}(G,g),\equiv)$ . It satisfies  $\psi(\bar{u})=\bar{u}$  because  $\varphi$  satisfies  $\varphi(\bar{u}/_{\equiv})=\bar{u}/_{\equiv}$  and no equivalence class contains two vertices of the same gadget.

Assume there is an isomorphism  $\varphi \colon (\mathsf{CFI}(G,f),\equiv) \to (\mathsf{CFI}(G,g),\equiv)$  with  $\varphi(\bar{u}) = \bar{u}$ . In particular,  $\varphi$  is an isomorphism  $\mathsf{CFI}(G,f) \to \mathsf{CFI}(G,g)$  corresponding to a G-twisting T by Lemma 4. We argue that the twisting T has to be  $\equiv$ -compressible. Let  $v \in V(G)$  be an arbitrary base vertex and  $\{v,w\} \in E(G)$  be an incident base edge. Also suppose that w is the i-th neighbor of v. If  $\varphi$  swaps the two sets  $\{(v,\bar{a}) \mid \sum \bar{a} = 0, a_i = 0\}$  and  $\{(v,\bar{a}) \mid \sum \bar{a} = 0, a_i = 1\}$ , then  $\varphi$  has to swap the corresponding sets for all  $v' \equiv v$ . This means that, if  $(v,w) \in T$ ,  $v' \equiv v$ , and w' is the i-th neighbor of v', then also  $(v',w') \in T$ . Hence, T is  $\equiv$ -compressible and satisfies  $f = g + g_T$ . Because we have  $\varphi(\bar{u}) = \bar{u}$ , the isomorphism  $\varphi$  is actually the identity on all vertices with origin W (every non-trivial automorphism of a gadget acts non-trivial on every vertex of that gadget). This means that T fixes W.

Assume there is a  $\equiv$ -compressible G-twisting T with  $f=g+g_T$  and that fixes W. We construct an isomorphism  $\psi\colon \mathsf{CFI}(G,f)/_{\equiv}\to \mathsf{CFI}(G,g)/_{\equiv}$ . Let  $\varphi\colon \mathsf{CFI}(G,f)\to \mathsf{CFI}(G,g)$  be the isomorphism corresponding to T from Lemma 4. Similarly to the case before, one verifies that  $\varphi$  preserves  $\equiv$ , that is,  $\varphi$  is an isomorphism from  $(\mathsf{CFI}(G,f),\equiv)$  to  $(\mathsf{CFI}(G,g),\equiv)$ . Hence,  $\varphi$  maps a  $\equiv$ -equivalence class to a  $\equiv$ -equivalence class. This induces a map  $\psi$  on the  $\equiv$ -equivalence classes for which one easily shows that it is an isomorphism  $\mathsf{CFI}(G,f)/_{\equiv}\to \mathsf{CFI}(G,g)/_{\equiv}$ . Because T fixes W, we have that  $\varphi(\bar{u})=\bar{u}$  and hence that  $\psi(\bar{u}/_{\equiv})=\bar{u}/_{\equiv}$ .

#### 4.2 The WL-Algorithm and Compressed CFI Graphs

We compare the expressiveness of k-WL (via the (k+1)-bijective pebble game) on CFI graphs, precompressed CFI graphs, and compressed CFI graphs. We again fix an arbitrary ordered base graph G.

<span id="page-9-3"></span>**Lemma 14.** For every  $k \geq 3$ , every  $r \in \mathbb{N}$ , every G-compression  $\equiv$ , and all  $\equiv$ -compressible functions  $f, g \colon E(G) \to \mathbb{F}_2$ ,

- 1.  $\mathsf{CFI}(G,f) \not\simeq_k^r \mathsf{CFI}(G,g) \text{ implies } (\mathsf{CFI}(G,f),\equiv) \not\simeq_k^r (\mathsf{CFI}(G,g),\equiv),$
- 2.  $(\mathsf{CFI}(G,f),\equiv) \not\simeq_k^r (\mathsf{CFI}(G,g),\equiv)$  implies  $\mathsf{CFI}(G,f)/\equiv \not\simeq_k^r \mathsf{CFI}(G,g)/\equiv$ , and
- 3.  $\mathsf{CFI}(G,f)/_{\equiv} \not\simeq_k^r \mathsf{CFI}(G,g)/_{\equiv} implies (\mathsf{CFI}(G,f),\equiv) \not\simeq_k^{r+2} (\mathsf{CFI}(G,g),\equiv).$

*Proof.* Let  $k \geq 3$ ,  $r \in \mathbb{N}$ ,  $\equiv$  be a G-compression, and  $f, g \colon E(G) \to \mathbb{F}_2$  be  $\equiv$ -compressible.

- 1. Because  $\mathsf{CFI}(G,f)$  and  $\mathsf{CFI}(G,g)$  are only extended by an additional relation, the claim directly follows.
- 2. Assume that  $(\mathsf{CFI}(G,f),\equiv) \not\simeq_k^r (\mathsf{CFI}(G,g),\equiv)$ , that is, Spoiler has a winning strategy in the r-round bijective k-pebble game played on  $(\mathsf{CFI}(G,f),\equiv)$  and  $(\mathsf{CFI}(G,g),\equiv)$ . We show that Spoiler also has a winning strategy in the r-round game on  $\mathsf{CFI}(G,f)/\equiv$  and  $\mathsf{CFI}(G,g)/\equiv$ .

We may assume without loss of generality that Duplicator always plays color-preserving in both games. This means that the bijections chosen by Duplicator always preserve colors. Observe that, if Duplicator does not do so, Spoiler wins immediately.

Consider a position  $\bar{u}/_{\equiv}$ ,  $\bar{v}/_{\equiv}$  of the game on  $\mathsf{CFI}(G,f)/_{\equiv}$  and  $\mathsf{CFI}(G,g)/_{\equiv}$ . That is, we have  $\bar{u}/_{\equiv} = (u_1/_{\equiv}, \dots, u_\ell/_{\equiv})$  and  $\bar{v}/_{\equiv} = (v_1/_{\equiv}, \dots, v_\ell/_{\equiv})$  for some  $\ell \leq k$  with pebbles  $p_{i_j}$  placed on  $u_j/_{\equiv}$  and the corresponding  $q_{i_j}$  placed on  $v_j/_{\equiv}$ . We say that a position  $\bar{u}', \bar{v}'$  of the game on  $(\mathsf{CFI}(G,f),\equiv)$  and  $(\mathsf{CFI}(G,g),\equiv)$  is an s-round witness for  $\bar{u}/_{\equiv}, \bar{v}/_{\equiv}$  if  $\bar{u}' = (u'_1, \dots, u'_\ell)$  and  $\bar{v}' = (v'_1, \dots, v'_\ell)$  such that the following conditions are satisfied:

- <span id="page-9-2"></span><span id="page-9-1"></span>(a)  $u_i' \equiv u_i$  and  $v_i' \equiv v_i$  for all  $i \in [\ell]$ ;
- <span id="page-9-0"></span>(b)  $u_i'$  has the same color in  $(\mathsf{CFI}(G, f), \equiv)$  as  $v_i'$  has in  $(\mathsf{CFI}(G, g), \equiv)$  for every  $i \in [\ell]$ ;
- (c)  $\bar{u}', \bar{v}'$  is a winning position for Spoiler in the s-round game on  $(\mathsf{CFI}(G, f), \equiv)$  and  $(\mathsf{CFI}(G, g), \equiv)$ .

We claim that if  $\bar{u}', \bar{v}'$  is a 0-round witness for  $\bar{u}/_{\equiv}, \bar{v}_{\equiv}$ , then Spoiler wins the game on  $\mathsf{CFI}(G,f)/_{\equiv}$  and  $\mathsf{CFI}(G,g)/_{\equiv}$ . Because  $\bar{u}', \bar{v}'$  is a winning position for Spoiler in the 0-round game on  $(\mathsf{CFI}(G,f),\equiv)$  and  $(\mathsf{CFI}(G,g),\equiv)$  by Condition (c), the mapping  $\bar{u}'\mapsto \bar{v}'$  is not a partial isomorphism. We show that the mapping  $\bar{u}/_{\equiv}\mapsto \bar{v}/_{\equiv}$  is not a partial isomorphism, either.

To see this, first note that  $u_i/\equiv$  has the same color as  $v_i/\equiv$  and  $u_i'$  has the same color as  $v_i'$  for every  $i \in [\ell]$  because Duplicator plays color-preserving and because of Condition (b). Suppose  $i, j \in [\ell]$ . If  $u_i' \equiv u_j'$  but  $v_i' \not\equiv v_j'$ , then by Condition (a),  $u_i/\equiv u_j/\equiv$  but  $v_i/\equiv v_j/\equiv$ . So Spoiler wins immediately. If  $u_i' = u_j'$  but  $v_i' \not= v_j'$ , then  $v_i'$  has the same color as  $v_j'$  (namely the one of  $u_i'$ ) and  $v_i' \not\equiv v_j'$  because distinct vertices of the same color are never  $\equiv$ -equivalent. Thus,  $u_i/\equiv u_j/\equiv$  but  $v_i/\equiv v_j/\equiv$  by Condition (a). Spoiler wins immediately again.

Lastly, suppose that  $\{u_i', u_j'\}$  is an edge in  $(\mathsf{CFI}(G, f), \equiv)$  but  $\{v_i', v_j'\}$  is not an edge in  $(\mathsf{CFI}(G, g), \equiv)$ . Then  $\{u_i/_{\equiv}, u_j/_{\equiv}\}$  is an edge in  $\mathsf{CFI}(G, f)/_{\equiv}$ . We prove that  $\{v_i/_{\equiv}, v_j/_{\equiv}\}$  is not an edge in  $\mathsf{CFI}(G, g)/_{\equiv}$  and hence Spoiler wins. Because  $\{u_i', u_j'\}$  is an edge, the origins of  $u_i'$  and  $u_j'$  are adjacent base vertices. Hence, the origins of  $v_i'$  and  $v_j'$  are also adjacent base vertices, because they have the same colors as  $u_i'$  and  $u_j'$ , respectively. So by Lemma 11, the set  $\{v_i', v_j'\}$  is not an edge in  $(\mathsf{CFI}(G, g), \equiv)$ .

The same arguments apply in the converse direction if the relations hold between the  $v'_i$ , but not the  $u'_i$ .

By induction on  $s \leq r$  we shall prove that Spoiler has a strategy for the r-round game on  $\mathsf{CFI}(G,f)/\equiv$  and  $\mathsf{CFI}(G,g)/\equiv$  such that the position in round s has an (r-s)-round witness. The base case s=0 holds because the empty position in the game on  $\mathsf{CFI}(G,f),\equiv$ ) and  $\mathsf{(CFI}(G,g),\equiv)$  is an r-round witness for the empty position in the game on  $\mathsf{CFI}(G,f)/\equiv$  and  $\mathsf{CFI}(G,g)/\equiv$ . For the inductive step, let s < r and suppose that the position  $\bar{u}/\equiv,\bar{v}\equiv$  in round s has an (r-s)-witness  $\bar{u}',\bar{v}'$ . If Spoiler removes a pair of pebbles, then we can remove the corresponding elements for the tuples, and the witness relation remains intact. Now suppose Spoiler wants to place a pair of pebbles  $p_{i_{\ell+1}},q_{i_{\ell+1}}$ . Duplicator picks a bijection h from  $V(\mathsf{CFI}(G,f)/\equiv)$  to  $V(\mathsf{CFI}(G,g)/\equiv)$ . Without loss of generality, we may assume that  $h(u_i/\equiv)=v_i/\equiv$  for all  $i\in[\ell]$ . Also recall that Duplicator plays color-preserving. This implies that h permutes each color class. Hence, we can lift h to a bijection h' from  $V((\mathsf{CFI}(G,f),\equiv))$  to  $V((\mathsf{CFI}(G,f),\equiv))$ : We set h'(u')=v' if and only if u' and v' are of the same origin and  $h(u'/\equiv)=v'\equiv$ . This, in particular, implies  $h'(u'_i)=v'$  for all  $i\in[\ell]$ .

Now suppose that in the (r-s)-round game on  $(\mathsf{CFI}(G,f),\equiv)$  and  $(\mathsf{CFI}(G,g),\equiv)$  in position  $\bar{u}',\bar{v}'$ , Duplicator picks the bijection h', and Spoiler answers (according to Spoiler's winning strategy) by placing the pebble  $p_{i_{\ell+1}}$  on the vertex  $u'_{\ell+1}$  and the pebble  $q_{i_{\ell+1}}$  on the vertex  $v'_{\ell+1} \coloneqq h'(u'_{\ell+1})$ . Then in the game on  $\mathsf{CFI}(G,f)/\equiv$  and  $\mathsf{CFI}(G,g)/\equiv$  with Duplicator choosing the bijection h, Spoiler places  $p_{i_{\ell+1}}$  on  $u'_{\ell+1}/\equiv$  and  $q_{i_{\ell+1}}$  on  $v'_{\ell+1}/\equiv$ . Then the pair  $(u'_1,\ldots,u'_{\ell+1}),(v'_1,\ldots,v'_{\ell+1})$  is an (r-s-1)-round witness for the new position  $(u_1/\equiv,\ldots,u_{\ell}/\equiv,u'_{\ell+1}/\equiv),(v_1/\equiv,\ldots,v_{\ell}/\equiv,v'_{\ell+1}/\equiv)$ .

3. Assume that  $\mathsf{CFI}(G,f)/_{\equiv} \not\simeq_k^r \mathsf{CFI}(G,g)/_{\equiv}$ . We turn a winning strategy of Spoiler in the r-round bijective k-pebble game played on  $\mathsf{CFI}(G,f)/_{\equiv}$  and  $\mathsf{CFI}(G,g)/_{\equiv}$  into a winning strategy of Spoiler in the (r+2)-round bijective k-pebble game played on  $(\mathsf{CFI}(G,f),\equiv)$  and  $(\mathsf{CFI}(G,g),\equiv)$ .

We call a position  $\bar{u}, \bar{v}$  of the game played on  $(\mathsf{CFI}(G, f), \equiv)$  and  $(\mathsf{CFI}(G, g), \equiv)$ , that is,  $\bar{u} = (u_1, \dots, u_\ell)$  and  $\bar{v} = (v_1, \dots, v_\ell)$  for some  $\ell \leq k$ , s-round witnessed if the position

$$\bar{u}/_{\equiv} = (u_1/_{\equiv}, \dots, u_{\ell}/_{\equiv}), \bar{v}/_{\equiv} = (v_1/_{\equiv}, \dots, v_{\ell}/_{\equiv})$$

of the game on  $\mathsf{CFI}(G,f)/_{\equiv}$  and  $\mathsf{CFI}(G,g)/_{\equiv}$  is a winning position for Spoiler in the s-round game on  $\mathsf{CFI}(G,f)/_{\equiv}$  and  $\mathsf{CFI}(G,g)/_{\equiv}$ .

We show that if  $\bar{u}, \bar{v}$  is 0-round witnessed, then Spoiler wins the game on  $(\mathsf{CFI}(G,f),\equiv)$  and  $(\mathsf{CFI}(G,g),\equiv)$  in at most 2 additional rounds. The position  $\bar{u}/\equiv,\bar{v}/\equiv$  in the game on  $\mathsf{CFI}(G,f)/\equiv$  and  $\mathsf{CFI}(G,g)/\equiv$  does not induce a partial isomorphism. Because  $u_i$  and  $v_i$  have the same color (Duplicator plays color-preserving),  $u_i/\equiv$  and  $v_i/\equiv$  have the same color for all  $i\in [\ell]$ . If  $u_i/\equiv u_j/\equiv$  but  $v_i/\equiv \neq v_j/\equiv$ , then  $u_i\equiv u_j$  but  $v_i\not\equiv v_j$  and Spoiler wins immediately. Suppose  $\{u_i/\equiv,u_j/\equiv\}$  is an edge in  $\mathsf{CFI}(G,f)/\equiv$  but  $\{v_i/\equiv,v_j/\equiv\}$  is not an edge in  $\mathsf{CFI}(G,g)/\equiv$ . On the one hand, there are vertices  $u_i'\equiv u_i$  and  $u_j'\equiv u_j$  such that  $\{u_i',u_j'\}$  is an edge in  $(\mathsf{CFI}(G,f),\equiv)$ . On the other hand, for every  $v_i'\equiv v_i$  and  $v_j'\equiv v_j$ , the set  $\{v_i',v_j'\}$  is not an edge in  $(\mathsf{CFI}(G,f),\equiv)$ . Spoiler picks up a pebble pair different from the two placed on  $u_i,v_i$  and  $u_j,v_j$  (such a pair exists because  $k\geq 3$ ). Spoiler places one pebble on  $u_i'$  and the other one on some vertex  $v_i'$  according to Duplicator's bijection. If  $v_i'\not\equiv v_i$ , then Spoiler wins. Otherwise, Spoiler picks up the pebble pair placed on  $u_j$  and  $v_j$ . Spoiler places one pebble on  $u_j'$  and the other one on some vertex  $v_j'$  according to Duplicator's bijection. If  $v_j'\not\equiv v_j$ , then Spoiler wins again. Otherwise, as already argued above,  $\{v_i',v_j'\}$  is not an edge, but  $\{u_i',u_j'\}$  is. Thus, Spoiler wins after 2 additional rounds.

The same arguments apply in the converse direction if the relations hold between the  $v_i$ , but not the  $u_i$ .

We prove by induction on  $s \leq r$  that Spoiler has a winning strategy in the (r+2)-round game on  $(CFI(G, f), \equiv)$  and  $(CFI(G, g), \equiv)$  such that the position reached in round s is (r-s)-round witnessed. Clearly, the initial position is r-round witnessed because Spoiler wins the r-round game  $CFI(G, f)/\equiv$  and  $CFI(G, g)/\equiv$ . Assume s < r and assume, by the induction hypothesis, that the position  $\bar{u}, \bar{v}$  of the game on  $(CFI(G, f), \equiv)$ and  $(CFI(G,g),\equiv)$  is (r-s)-round witnessed. If Spoiler removes a pair of pebbles, then we can remove the corresponding elements from the tuples, and the position is still witnessed. Now suppose Spoiler wants to place a pair of pebbles  $p_{i_{\ell+1}}, q_{i_{\ell+1}}$ . Duplicator picks a color-preserving bijection h from  $V((\mathsf{CFI}(G,f),\equiv))$  to  $V((\mathsf{CFI}(G,g),\equiv))$ . We construct a bijection h' from  $V(\mathsf{CFI}(G,f)/_{\equiv})$  to  $V(\mathsf{CFI}(G,g)/_{\equiv})$ . Assume  $w/_{\equiv}$  is an equivalence class such that w is the unique minimal vertex of that class (with respect to the colors). We define  $h'(w/\equiv) := h(w)/\equiv$ . Because minimal vertices in equivalence classes are unique, because vertices of the same gadget are never in the same equivalence class, and because h is color preserving, the map h' is indeed a bijection. Now suppose that in the (r-s)-round game on  $\mathsf{CFI}(G,f)/_{\equiv}$  and  $\mathsf{CFI}(G,g)/_{\equiv}$ , Duplicator plays h' as bijection. According to the winning strategy, Spoiler places the pebble  $p_{i_{\ell+1}}$  on  $u_{\ell+1}/\equiv$ and  $q_{i_{\ell+1}}$  on  $v_{\ell+1}/_{\equiv} = h'(u_{\ell+1}/_{\equiv})$ , where we assume without loss of generality that  $u_{\ell+1}$ and  $v_{\ell+1}$  are the minimal vertices of their classes. In the game on  $(\mathsf{CFI}(G,f),\equiv)$  and  $(\mathsf{CFI}(G,g),\equiv)$ , where Duplicator chooses the bijection h, Spoiler places  $p_{i_{\ell+1}}$  on  $u_{\ell+1}$ and  $q_{i_{\ell+1}}$  on  $v_{\ell+1} = h(u_{\ell+1})$ . Because Spoiler has a winning strategy on  $\mathsf{CFI}(G,f)/_{\equiv}$  and  $\mathsf{CFI}(G,g)/_{\equiv}$ , the position  $(u_1,\ldots,u_{\ell+1}),(v_1,\ldots,v_{\ell+1})$  is (r-s-1)-round witnessed.  $\square$ 

<span id="page-11-1"></span>**Corollary 15.** For every  $k \geq 3$ , every  $r \in \mathbb{N}$ , every G-compression  $\equiv$ , and all  $\equiv$ -compressible  $f, g \colon E(G) \to \mathbb{F}_2$ , we have

$$\begin{array}{lll} if & (\mathsf{CFI}(G,f),\equiv) \simeq_k^r (\mathsf{CFI}(G,g),\equiv) & \text{ and } & (\mathsf{CFI}(G,f),\equiv) \not \simeq_k^{r+1} (\mathsf{CFI}(G,g),\equiv), \\ then & \mathsf{CFI}(G,f)/_{\equiv} \simeq_k^{r-2} \mathsf{CFI}(G,g)/_{\equiv} & \text{ and } & \mathsf{CFI}(G,f)/_{\equiv} \not \simeq_k^{r+1} \mathsf{CFI}(G,g)/_{\equiv}. \end{array}$$

By the former corollary, we can study precompressed CFI graphs to obtain lower bounds on the iteration number of k-WL on compressed CFI graphs. To do so, we introduce a variant of the Cops and Robber game suitable for compressions.

#### 4.3 Cops and Robbers for Precompressed CFI Graphs

We describe a variant of the k-Cops and Robber game suitable for compressed CFI graphs. The **compressed** k-Cops and Robber game is played on an ordered base graph G and a G-compression  $\equiv$ . The cops player places cops on up to k many  $\equiv$ -equivalence classes and the robber is placed on one edge of G. Initially, only the robber is placed. The game proceeds as follows:

- <span id="page-11-0"></span>1. One cop is picked up, and a destination  $\equiv$ -equivalence class c for this cop is selected.
- 2. The robber moves. To move from the current edge  $e_1$  to another edge  $e_2$ , the robber has to provide a  $\equiv$ -compressible G-twisting that only twists the edges  $e_1$  and  $e_2$  and that fixes every vertex contained in a  $\equiv$ -equivalence class occupied by a cop.
- 3. The cop picked up in Step 1 is placed on c.

The robber is caught if the two endpoints of the robber-occupied edge are contained in copoccupied  $\equiv$ -equivalence classes. If the robber is caught after r rounds, then the cops win in r rounds. Otherwise, the robber wins in r rounds. Note that the initial position of the robber may matter to decide who wins in the compressed game.

<span id="page-12-4"></span>**Lemma 16.** Let  $k \geq 3$ ,  $\equiv$  be a G-compression, and  $f,g \colon E(G) \to \mathbb{F}_2$  such that there is exactly one twisted edge e with respect to f and g. If the robber has a winning strategy in the r-round compressed k-Cops and Robber game, where the robber is initially placed on e, then  $(\mathsf{CFI}(G,f),\equiv) \simeq_k^r (\mathsf{CFI}(G,g),\equiv)$ .

*Proof.* We show that Duplicator has a winning strategy in the r-round bijective k-pebble game. Duplicator maintains a function  $g' \colon E(G) \to \mathbb{F}_2$  and an edge  $e' \in E(G)$  such that after  $s \leq r$  rounds in position  $\bar{u}, \bar{v}$ ,

- <span id="page-12-0"></span>(a) there is an isomorphism  $\varphi \colon (\mathsf{CFI}(G,g),\equiv) \to (\mathsf{CFI}(G,g'),\equiv)$  such that  $\varphi(\bar{v}) = \bar{u}$  (recall that CFI graphs over the same base graph have the same vertex set),
- <span id="page-12-2"></span><span id="page-12-1"></span>(b) only the base edge e' is twisted with respect to f and g',
- <span id="page-12-3"></span>(c) at most one endpoint of e' is the origin of a vertex in  $\bar{u}$ , and
- (d) the robber has a winning strategy in the (r-s)-round compressed k-Cop and Robber game, where the robber is placed on e' and the cops on the equivalence classes of the origins of the vertices in  $\bar{u}$ .

Because initially no pebbles are placed, the invariant clearly holds for g' = g and e' = e. Assume, by the induction hypothesis, that after s < r many rounds the invariant holds. Spoiler picks up a pair of pebbles. By Condition (a), these pebbles were placed on vertices with the same origin. In the compressed Cop and Robber game, a cop is picked up from the equivalence class of this origin. Now assume that Spoiler wants to place a pair of pebbles  $p_{i_{\ell}+1}, q_{i_{\ell}+1}$ . Duplicator defines a bijection h from  $V((\mathsf{CFI}(G,f),\equiv))$  to  $V((\mathsf{CFI}(G,g),\equiv))$  as follows: Let w be a vertex of  $(CFI(G, f), \equiv)$  and we want to define the image h(w). Consider the compressed Cop and Robber game where a cop is placed on the equivalence class of the origin of w. Let  $T_w$  be the  $\equiv$ -compressible G-twisting by which the robber moves from e' to  $e'_w$  following the robber's winning strategy. Furthermore, let  $\psi_w : (\mathsf{CFI}(G, g'), \equiv) \to (\mathsf{CFI}(G, g'_w), \equiv)$  be the isomorphism corresponding to  $T_w$  by Lemma 13. The isomorphism  $\psi_w$  is the identity on all vertices whose origin is fixed by  $T_w$ . In particular,  $\psi_w$  is the identity on the pebbled vertices because their origins are occupied by the cops. Duplicator defines  $h(w) := \varphi^{-1}(\psi_w^{-1}(w))$ . The map h is clearly color-preserving. To prove that h is a bijection, it suffices to show that h permutes every color class. Because the move of the robber only depends on the origin of w, we actually have  $T_w = T_{w'}$  for all w, w' with the same origin or, equivalently, of the same color. Hence,  $\psi_w = \psi'_w$ for all w, w' of the same color and h is a bijection.

Now Spoiler picks a vertex w of  $(CFI(G, f), \equiv)$  and places the pebble  $p_{i_{\ell}+1}$  on w and the pebble  $q_{i_{\ell}+1}$  on  $h(w) = \varphi^{-1}(\psi_w^{-1}(w))$ . Set  $g'' := g'_w$  and  $e'' := e'_w$ . Because e' is the only edge twisted with respect to f and g' and  $T_w$  twists e' and  $e_w$ , the edge  $e'' = e'_w$  is the only edge twisted with respect to f and g''. So Condition (b) holds. Because  $\varphi$  is an isomorphism from  $(\mathsf{CFI}(G,g),\equiv)$  to  $(\mathsf{CFI}(G,g'),\equiv)$  and  $\psi_w$  is an isomorphism from  $(\mathsf{CFI}(G,g'),\equiv)$  to  $(\mathsf{CFI}(G, g''), \equiv)$ , the map  $\varphi' := \psi_w \circ \varphi$  is an isomorphism from  $(\mathsf{CFI}(G, g), \equiv)$  to  $(\mathsf{CFI}(G, g'), \equiv)$ . Hence,  $\varphi'(h(w)) = \psi_w(\varphi(\varphi^{-1}(\psi_w^{-1}(w)))) = w$ . Because  $T_w$  fixes the origins of all vertices in  $\bar{u}$ , the isomorphism  $\psi_w$  is the identity on  $\bar{u}$ . Thus, Condition (a) holds. Condition (c) holds because the twisting  $T_w$  was given by a strategy of the robber. By placing the cop on the equivalence class of w and moving the robber accordingly, the robber has a winning strategy in r-s-1rounds by Condition (d). So the invariant is satisfied after round s+1. To show that Duplicator has not lost in this round, we need to argue that the new position defines a partial isomorphism. Corresponding pebbles are placed on vertices of the same color, and if  $p_i$  and  $p_j$  are placed on the same vertex, then so are  $q_i$  and  $q_j$  by Condition (a). By Condition (c), edges between two adjacent origins of pebbled vertices are never twisted with respect to f and q''. So between  $(\mathsf{CFI}(G,f),\equiv)$  and  $(\mathsf{CFI}(G,g''),\equiv)$ , the identity map on the pebbled vertices in  $(\mathsf{CFI}(G,f),\equiv)$ is a partial isomorphism between  $(CFI(G, f), \equiv)$  and  $(CFI(G, g''), \equiv)$ . By Condition (a), the pebbled vertices also define a partial isomorphism between  $(\mathsf{CFI}(G, f), \equiv)$  and  $(\mathsf{CFI}(G, g), \equiv)$ . Duplicator updates  $g' \leftarrow g''$  and  $e' \leftarrow e''$ .

From now on, we focus on compressible twistings and the compressed Cops and Robber game and do not require the details of the CFI construction anymore.

#### 5 A Lower Bound for the Iteration Number

In this section, we give the proof of Theorem 1. We start by describing the base graphs and the equivalence relations that are used to construct the compressed CFI graphs. We also describe several auxiliary objects that are relevant for the analysis.

For the remainder of this section, let us fix an arbitrary integer  $k \geq 3$ . We define

$$f(k) := 2k + 2. \tag{1}$$

Also let w be an integer such that

<span id="page-13-1"></span>
$$w \ge \max\left(2 \cdot f(k), 4k \cdot \ln(4k)\right),\tag{2}$$

and let  $p_0, \ldots, p_{k-1}$  be pairwise coprime integers such that

$$\frac{w}{2} < p_i \le w \tag{3}$$

for all  $i \in [0, k-1]$ . Since w is sufficiently large, such a collection of coprime integers exists. In fact, we can even choose them to be distinct prime numbers [26]. More precisely, we can rely on the following result.

<span id="page-13-0"></span>**Lemma 17** ([32]). For all integers  $k' \ge 1$  and all integers  $w \ge 4k \ln(4k)$ , there are distinct primes  $p_0, \ldots, p_{k'-1}$  such that  $\frac{w}{2} < p_i \le w$  for all  $i \in [0, k'-1]$ .

Remark 18. At this point, one may wonder whether a better dependency between w and k can be achieved if, instead of prime numbers, we choose pairwise coprime numbers  $p_0, \ldots, p_{k-1}$ . Suppose that  $k \geq 2$  and  $w \geq k$  such that there are pairwise coprime integers  $p_0, \ldots, p_{k-1}$  with  $\frac{w}{2} < p_i \leq w$  for all  $i \in [0, k-1]$ . Since  $p_i \geq 2$  for all  $i \in [0, k-1]$ , we can pick an arbitrary prime factor  $q_i$  of  $p_i$  for every  $i \in [0, k-1]$ . Hence, we obtain distinct prime numbers  $q_0, \ldots, q_{k-1}$  with  $q_i \leq w$  for all  $i \in [0, k-1]$ . So  $\pi(w) \geq k$ , where  $\pi$  is the prime-counting function (i.e.,  $\pi(w)$  denotes the number of primes  $q \leq w$ ). By the Prime Number Theorem,  $\pi(w) \sim \frac{w}{\ln w}$ . While this leaves room for some small improvements (over the bound from Lemma 17), it is not possible to obtain a linear dependence between k and w.

We use cylindrical grids as base graphs. We fix

$$I := [0, k-1]$$

as the set of rows. Let  $\ell$  be a positive integer and suppose  $J = [0, \ell - 1]$ . We use I as set of rows and J as set of columns to construct the **cylindrical grid**  $C_{I,J}$  with vertex set  $V(C_{I,J}) := I \times J$ . Starting from the  $I \times J$  grid, we connect the top and bottom most vertex in every column, i.e., we add the edge  $\{(0,j), (k-1,j)\}$  for all  $j \in J$ . We also consider the **toroidal grid**  $C_{I,J}^*$  with the same vertex set  $V(C_{I,J}^*) := I \times J$ . Starting from the cylindrical grid  $C_{I,J}$ , we also connect the first and last vertex in every row, i.e., we add the edge  $\{(i,0), (i,\ell-1)\}$  for all  $i \in I$ . We turn  $C_{I,J}$  and  $C_{I,J}^*$  into ordered base graphs using the lexicographical order on  $I \times J$ .

We fix

$$J := [0, \frac{1}{2} \cdot f(k) \cdot p_1 \cdot p_2 \cdots p_k - 1] \text{ and}$$
$$J^* := [0, f(k) \cdot p_1 \cdot p_2 \cdots p_k - 1].$$

<span id="page-14-0"></span>![](_page_14_Picture_0.jpeg)

Figure 3: The cylindrical grid  $C = C_{I,J}$  is drawn in black. It is a subgraph of the toroidal grid  $C^* = C_{I,J^*}^*$  for which the additional vertices and edges are drawn in red. The blue regions mark the areas of C in which the robber can be located in the proof of Lemma 31.

<span id="page-14-1"></span>![](_page_14_Figure_2.jpeg)

Figure 4: Sketch of the compression  $\equiv$  and the additional equivalence  $\equiv^*$ . The figure shows the intervals of the rows of C (drawn in black) and  $C^*$  (additional intervals drawn in red as in Figure 3) that are identified by the equivalences. Some  $\equiv^*$ -equivalence classes are shown, each class in its own color. Vertices connected by lines are  $\equiv$ -equivalent and  $\equiv^*$ -equivalent. Dotted lines indicate  $\equiv^*$ -equivalence only. All vertices in gray areas of C form singleton  $\equiv$ -equivalence classes.

We consider the cylindrical grid  $C := C_{I,J}$  and the toroidal grid  $C^* := C_{I,J^*}^*$ . Note that C is a subgraph of  $C^*$  (see also Figure 3). We use the cylindrical grid C as the actual base graph whereas  $C^*$  serves as an auxiliary graph in the analysis.

We define multiple equivalence relations on V(C) and  $V(C^*)$ . For a graph G, an equivalence relation R on V(G), and a vertex  $u \in V(G)$ , we denote by u/R the R-equivalence class containing u. For a set  $W \subseteq V(G)$ , we define the R-class of W via  $W/R := \bigcup_{u \in W} u/R$ .

We start by defining an equivalence relation  $\equiv^*$  on  $V(C^*)$ . Vertices are only equivalent to vertices in the same row. In row i, the distance between equivalent vertices is a multiple of  $f(k) \cdot p_i \cdot p_{i+1}$ , where indices are taken modulo k. More formally, for all  $i, i' \in I$  and  $j, j' \in J^*$ , we set

$$(i,j) \equiv^* (i',j') \iff i=i' \text{ and } (j'-j) \text{ is divisible by } f(k) \cdot p_i \cdot p_{i+1}.$$

From the equivalence  $\equiv^*$  we obtain the equivalence  $\equiv$  on V(C), which is used for the compression (note that  $V(C) \subseteq V(C^*)$ ), as follows. In row i, we use the equivalence  $\equiv^*$  except that several vertices are made singleton equivalence classes. Specifically, all vertices in the complete first interval of length  $f(k) \cdot p_i \cdot p_{i+1}$  are singletons. Also vertices in the last uncropped repetition of this  $f(k) \cdot p_i \cdot p_{i+1}$  length interval, plus possibly the vertices in a subsequent cropped interval, are singletons. More formally, for all  $i, i' \in I$  and  $j \leq j' \in J$ , we set

$$(i,j) \equiv (i',j') \iff (i,i') \equiv^* (i',j') \text{ and } j \geq f(k) \cdot p_i \cdot p_{i+1} \text{ and } j' < \lambda_i \cdot f(k) \cdot p_i \cdot p_{i+1},$$

where  $\lambda_i$  is the largest integer such that  $(\lambda_i + 1) \cdot f(k) \cdot p_i \cdot p_{i+1} \leq |J|$ . A visualization is given in Figure 4. In particular, note that all vertices in the first and last f(k) columns of C form singleton  $\equiv$ -equivalence classes.

<span id="page-14-2"></span>**Lemma 19.** The cylindrical grid C has width  $(w/2)^k \le |J| \le (k+1) \cdot w^k$  and  $\equiv has \Theta(k^2 \cdot w^2)$  many equivalence classes.

*Proof.* We have  $|J| = \frac{1}{2} \cdot f(k) \cdot p_1 \cdot p_2 \cdots p_k$ . Since  $w/2 \le p_i \le w$  for every  $i \in I$ , it follows that  $(w/2)^k \le |J| \le (k+1) \cdot w^k$ .

To bound the number of equivalence classes, consider an arbitrary row  $i \in I$ . Then there are at least  $3 \cdot f(k) \cdot p_i \cdot p_{i+1}$  and at most  $4 \cdot f(k) \cdot p_i \cdot p_{i+1}$  equivalence classes in the *i*-th row. Using again that  $w/2 \le p_i \le w$  for every  $i \in I$ , we obtain  $\Theta(k^2 \cdot w^2)$  equivalence classes in total.  $\square$ 

<span id="page-15-1"></span>**Lemma 20.** The equivalence relation  $\equiv$  is a C-compression.

*Proof.* Let  $u, v \in V(C)$  such that  $u \equiv v$  and  $u \neq v$ . We first show that u and v are not adjacent and have the same degree. By construction, u and v have distance at least f(k), which in particular implies that they are not adjacent. Also, u and v are not in first or last column which implies that both have degree 4.

Next, let  $\{u, v\}, \{u', v'\} \in E(C)$  such that  $u \equiv u'$  and  $v \equiv v'$ . Then the two edges are either both horizontal edges in the same row or both vertical edges between the same rows. Also, u and u' are in the same row and v and v' are in the same row. Because the cylindrical grid is ordered lexicographically, if v is the i-th neighbor of u then v' is the i-th neighbor of u'.

Now that we established that  $\equiv$  is a compression, we can use all results from Section 4. The goal is to prove an  $\Omega(w^k)$  lower bound on the iteration number of k-WL on compressed CFI graphs over C. By Lemma 16, it suffices to show that the robber has a winning strategy in  $\Omega(w^k)$  rounds in the compressed (k+1)-Cops and Robber game played on  $(C, \equiv)$ . Towards this, we define twistings to move the robber.

**Definition 21** (End-to-End Twisting). For a set of vertices  $W \subseteq V(C)$ , an **end-to-end twisting avoiding** W is a  $\equiv$ -compressible C-twisting that

- 1. twists some edge  $e_1$  in the first column and some edge  $e_2$  in the last column of C,
- 2. twists no other edge, and
- 3. fixes every vertex in  $W/_{\equiv}$ .

We now consider situations in which there are end-to-end twistings avoiding a set  $W \subseteq V(C)$ . For  $\ell \geq 2$ , we define the equivalence relation  $\approx_{\ell}$  on  $V(C^*) = I \times J^*$  in such a way that, for all  $i, i' \in I$  and  $j \leq j' \in J^*$ , we have

$$(i,j) \approx_{\ell} (i',j') \iff i = i' \text{ and } (j'-j) \text{ is divisible by } \ell.$$

Note that we use the same period in every row for  $\approx_{\ell}$ . Slightly abusing notation, we also use  $\approx_{\ell}$  to denote the corresponding equivalence relation on V(C).

**Definition 22** (Pairwise-Separator). For a pair of consecutive rows i and i+1 (indices taken modulo k), a set  $W \subseteq V(C)$  is a **pairwise-separator for rows** i **and** i+1 if  $W/_{\approx_{f(k)p_{i+1}}}$  separates the first and last column in the subgraph of C induced by rows i and i+1. The set W is a **pairwise-separator** if W is a pairwise-separator for rows i and i+1 for every  $i \in I$ .

A path  $P = (u_1, \ldots, u_m)$  in C is  $\ell$ -periodic if  $u_1$  and  $u_m$  are in singleton  $\equiv$ -classes and, for every i < m and every  $v \in V(C)$  such that  $v \approx_{\ell} u_i$  and  $u_i/_{\equiv}$  and  $v/_{\equiv}$  are not singleton classes, there is a j < m such that  $u_j = v$  and  $u_{i+1} \approx_{\ell} u_{j+1}$ . The path induces the C-twisting

$$T_P := \{ (u_i, u_{i-1}), (u_i, u_{i+1}) \mid 1 < i < m \}.$$

<span id="page-15-0"></span>**Lemma 23.** Let  $I' \subseteq I$  be a set of rows and  $P = (u_1, \ldots, u_m)$  be a path in C that only uses vertices from rows in I'. Let q be the greatest common divisor of all  $f(k)p_ip_{i+1}$  for  $i \in I'$  (that is,  $q = f(k)p_ip_{i+1}$  if  $I' = \{i\}$ ,  $q = f(k)p_{i+1}$  if  $I' = \{i, i+1\}$ , and q = f(k) otherwise). If P is q-periodic, then the induced C-twisting  $T_P$  is q-compressible, twists the edges  $\{u_1, u_2\}$  and  $\{u_{m-1}, u_m\}$ , twists no other edges, and fixes all vertices apart from  $u_1, \ldots, u_m$ .

<span id="page-16-1"></span>![](_page_16_Picture_0.jpeg)

Figure 5: The figure shows the q-periodic path (highlighted in red) for  $q = f(k)p_{i+1}$  constructed in the proof of Lemma 24.

Proof. The C-twisting  $T_P$  twists exactly the edges  $\{u_1, u_2\}$  and  $\{u_{m-1}, u_m\}$  and fixes all vertices apart from  $u_1, \ldots, u_m$  by construction. To show that  $T_P$  is  $\equiv$ -compressible, we have to show that, for all  $u \equiv u'$  of degree d, we have  $(u, v_\ell) \in T_P$  if and only if  $(u', v'_\ell) \in T_P$  for every  $\ell \in [d]$ , where  $v_\ell$  respectively  $v'_\ell$  is the  $\ell$ -th neighbor of u respectively u'. It suffices to show one direction of the equivalence, the other one follows by swapping u and u'. So let  $u \equiv u'$  and  $v_\ell$  respectively  $v'_\ell$  be the  $\ell$ -th neighbor of u respectively u' for an arbitrary  $\ell$ . Assume  $(u, v_\ell) \in T_P$ . We show  $(u', v'_\ell) \in T_P$ . If  $u/\equiv$  is a singleton class, then u = u' and  $v_\ell = v'_\ell$ , and we are done. So suppose that  $u/\equiv$  is not a singleton class. In particular, u and u' are neither the first nor last vertex in P because P is q-periodic. Let u = (s, t) and u' = (s', t'). We have s = s' because  $u \equiv u'$ . Because  $f(k)p_sp_{s+1}$  is divisible by q, we also have  $u \approx_q u'$ . Recall that we ordered the vertices lexicographically. That is, if  $v_\ell$  is the right neighbor of u, then  $v'_\ell$  is the right neighbor of u' and similar for all other directions. Hence,  $v_\ell \approx_q v'_\ell$ . Because  $(u, v_\ell) \in T_P$ , there is an u such that  $u \in u$  and  $u' \in u$  and  $u' \in u$  is neither the first nor the last vertex in u we may assume without loss of generality that  $u = u_i$  and  $u' \in u$ . Since  $u \in u$  is  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$  and  $u' \in u$ 

We use periodic paths in Lemmas 24 and 28 to construct end-to-end twistings.

<span id="page-16-0"></span>**Lemma 24.** Let  $W \subseteq V(C)$  be a set of at most k vertices of C such that W is not a pairwise-separator. Then there is an end-to-end twisting avoiding W.

*Proof.* Suppose W is not a pairwise-separator. If W does not contain a vertex from every row, then there is a row i such that no vertices of row i are in W. Hence, there is a path from one end to the other that avoids W and only uses vertices of row i. This path is trivially  $(f(k)p_ip_{i+1})$ -periodic and thus induces the desired end-to-end twisting by Lemma 23.

So suppose otherwise. There is some  $i \in I$  such that W is not a pairwise-separator for rows i and i+1. The set W contains exactly one element from row i, say (i,j), and one from row i+1, say (i+1,j'). Since  $W/_{\approx_{f(k)p_{i+1}}}$  does not separate the ends of rows i and i+1, we conclude that (j-j') mod  $f(k)p_{i+1} \notin \{-1,0,1\}$ . Then the path that contains the vertices

$$\{ (i,\ell) \mid (j-\ell) \bmod f(k) p_{i+1} \neq 0 \} \text{ and }$$

$$\{ (i+1,\ell) \mid (j-\ell) \bmod f(k) p_{i+1} \in \{-1,0,1\} \}$$

is  $(f(k)p_{i+1})$ -periodic (see Figure 5) and induces the desired end-to-end twisting by Lemma 23.

In the cylindrical grid C, we are interested in k-vertex sets  $W \subseteq V(C)$  such that  $W/\equiv$  separates the first from the last column. To analyze how such separators can be moved, we consider the toroidal grid  $C^*$ . We say that the j-th and j'-th column  $(j, j' \in J^*)$  of  $C^*$  are **consecutive** if (j - j') mod  $|J^*| \in \{-1, 0, 1\}$ .

**Definition 25** (Vertical Separator). A set  $W \subseteq V(C)$  is a **vertical separator** if in the graph C-W the first column is separated from the last column. A set  $W \subseteq V(C^*)$  is a **toroidal vertical separator** if there is a number  $z \in \mathbb{Z}$  such that W shifted by z columns in  $C^*$ , i.e., the set  $\{(i, (j+z) \bmod |J^*|) \mid (i,j) \in W\} \cap V(C)$ , is a vertical separator of C.

In particular, every vertical separator is a toroidal vertical separator. We regularly rely on the following simple properties of k-vertex toroidal vertical separators.

<span id="page-17-4"></span><span id="page-17-1"></span>**Lemma 26.** Let  $S \subseteq V(C^*)$  be a k-vertex toroidal vertical separator.

- <span id="page-17-2"></span>(i) S contains exactly one vertex per row.
- (ii) If (i, j) and (i + 1, j') are the vertices in row i and i + 1 in S (row indices modulo k), then the j-th and j'-th column are consecutive in  $C^*$ .
- <span id="page-17-3"></span>(iii) S spans at most k consecutive columns of  $C^*$ , i.e., there is column  $j \in J^*$  such that  $S \subseteq \{(i, (j + \ell) \mod |J^*|) \mid i, \ell \in [0, k - 1]\}.$

Proof. Because there are k rows and S contains k vertices, Part (i) follows. For Part (ii), suppose  $(i,j), (i+1,j') \in S$  are the unique vertices in rows i and i+1 in S. Since S is a toroidal vertical separator, there is some  $z \in \mathbb{Z}$  such that  $S_z \coloneqq \{(i,(j+z) \bmod |J^*|) \mid (i,j) \in W\} \cap V(C)$  is a vertical separator of C. Suppose towards a contradiction that the j-th and j'-th columns are not consecutive. If one of  $(i,(j+z) \bmod |J^*|)$  and  $(i',(j'+z) \bmod |J^*|)$  is not contained in V(C), then there is clearly a path from the first to the last column in  $C - S_z$ . Otherwise, assume by symmetry  $(j+z) \bmod |J^*| \le (j'+z) \bmod |J^*|$ . Because the j-th and j'-th column are not consecutive, we have j+1 < j'. Hence,  $((i+1,0),\ldots,(i+1,j+1),(i,j+1),\ldots,(i,|J|-1))$  is a path in  $C - S_z$ . In both cases, we obtain a contradiction. Finally, Part (iii) immediately follows from Part (ii).

We define  $\approx := \approx_{f(k)}$  (as before, slightly abusing notation, we use  $\approx$  on both graphs C and  $C^*$ ).

**Definition 27** (Pseudo-Separator). A set  $W \subseteq V(C)$  is a **pseudo-separator** if W is a pairwise-separator and  $W/_{\approx}$  is a vertical separator.

<span id="page-17-0"></span>**Lemma 28.** Let  $W \subseteq V(C)$  be a set of at most k vertices such that W is not a pseudo-separator. Then there is an end-to-end twisting avoiding W.

*Proof.* If W is not a pairwise-separator, then there is an end-to-end twisting avoiding W by Lemma 24.

Otherwise,  $W/_{\approx}$  is not a vertical separator. In this case, there is a path P from a vertex in column 0 to a vertex in column 2f(k)-1 that avoids  $W/_{\approx}$ . Since W has at most k elements and f(k)>k, there is a column  $j\in[0,f(k)-1]$  that contains no element of  $W/_{\approx}$ . Let P' be a subpath of P containing exactly one vertex from column j, one vertex from column j+f(k) and otherwise only vertices in the columns between j and j+f(k). Such a subpath exists because P starts in column 0 and ends in column 2f(k)-1.

Suppose (i,j) is the one endpoint of P' and (i',j+f(k)) is the other. We extend P' to a path Q by adding as initial segment a path from (i',j) to (i,j) in column j (if i=i' then Q=P'). Note that Q is a path spanning f(k) columns which starts and ends in the same row. Also note that Q avoids  $W/_{\approx}$ .

Finally, we construct the path  $\widehat{Q}$  by shifting Q by multiples of f(k), that is, if Q uses vertices V(Q) and edges E(Q), then  $\widehat{Q}$  has vertices

$$V(\widehat{Q}) \coloneqq \big\{ \left. (i,j+z \cdot f(k)) \mid (i,j) \in V(Q), z \in \mathbb{Z} \right. \big\} \cap V(C)$$

and edges

$$E(\widehat{Q}) := \left\{ \left. \{ (i, j + z \cdot f(k)), (i', j' + z \cdot f(k)) \right\} \, \middle| \, \left\{ (i, j), (i', j') \right\} \in E(Q), z \in \mathbb{Z} \right. \right\} \cap E(C).$$

The path  $\widehat{Q}$  is f(k)-periodic by construction and induces the desired end-to-end twisting avoiding W by Lemma 23 (note that  $\widehat{Q}$  is trivially (f(k)p)-periodic for every positive  $p \in \mathbb{N}$ ).

If W is a pseudo-separator, we cannot construct end-to-end twistings avoiding W in general. In this case, the goal is to show that pseudo-separators not containing proper vertical separators cannot be used to catch the robber.

<span id="page-18-5"></span>**Lemma 29.** Let  $W \subseteq V(C)$  be a set of at most k vertices.

- 1. There is at most one k-vertex toroidal vertical separator  $S_W \subseteq W/_{\equiv^*}$  (and thus at most one vertical separator).
- 2. If  $W/_{\equiv^*}$  is a toroidal vertical separator, then there is a k-vertex toroidal vertical separator  $S_W \subseteq W/_{\equiv^*}$ .

*Proof.* We prove the first claim. If  $W/_{\equiv^*}$  contains some k-vertex toroidal vertical separator  $S_W$ , then W contains exactly one vertex from every row using Lemma 26(i). Suppose  $S'_W \subseteq W/_{\equiv^*}$  is a second k-vertex toroidal vertical separator. Note that  $S_W$  and  $S'_W$  also contain exactly one vertex from every row. Let us make three observations:

- <span id="page-18-1"></span>(a)  $S_W$  is contained in k consecutive columns of  $C^*$  by Lemma 26(iii). So, if  $(s,t), (i,j) \in S_W$ , then  $((t-j) \mod |J^*|) < k$ .
- <span id="page-18-2"></span><span id="page-18-0"></span>(b) Similarly, if  $(s, t'), (i, j') \in S'_W$ , then  $((t' - j') \mod |J^*|) < k$ .
- (c) Suppose (i, j) and (i, j') are vertices in row i in  $S_W$  and  $S_W'$ , respectively. Both vertices are in particular in  $W/_{\equiv^*}$ . Thus,  $(j j') \mod f(k) p_i p_{i+1} = 0$ .

We claim that, for all  $i \in I$ , all  $(s,t) \in S_W$ , and all  $(s,t') \in S_W'$ , we have

<span id="page-18-3"></span>
$$(t - t') \bmod f(k) p_i p_{i+1} \in \{-2k, \dots, 2k\}.$$
 (4)

To see this, let  $(i, t_i)$  be the vertex of row i in  $S_W$ , and let  $(i, t_i')$  be the vertex of row i in  $S_W'$ . By (c), we get  $(t_i - t_i')$  mod  $f(k)p_ip_{i+1} = 0$ , and by (a) and (b), we get  $((t - t_i))$  mod  $|J^*| < k$  and  $((t' - t_i'))$  mod  $|J^*| < k$ , respectively. This implies the claim since  $f(k)p_ip_{i+1}$  divides  $|J^*|$ . Furthermore, by (c) (using s in place of s) we get that

$$(t - t') \mod f(k) p_s p_{s+1} = 0$$

which in particular implies that

<span id="page-18-4"></span>
$$(t - t') \bmod f(k) = 0. \tag{5}$$

Since f(k) > 2k, we can combine Equations (4) and (5) and obtain that

$$(t - t') \bmod f(k)p_i p_{i+1} = 0$$

for all  $i \in [k]$ . It follows that

$$(t-t') \bmod f(k)p_1p_2\cdots p_k = 0$$

since all  $p_i$  are pairwise coprime. This implies t = t'. So overall, for all  $(s, t) \in S_W$  and all  $(s, t') \in S_W'$ , we have t = t'. This means that  $S_W = S_W'$ .

It remains to show the second claim. Suppose that  $W/_{\equiv^*}$  is a toroidal vertical separator. Note that  $W/_{\equiv^*}$  contains a vertex from every row. Because W is of size at most k, the set  $W/_{\equiv^*}$  consists of exactly one  $\equiv^*$ -equivalence class per row. Let  $S_W$  be a minimal toroidal vertical separator such that  $S_W \subseteq W/_{\equiv^*}$ . For the sake of contradiction suppose that  $|S_W| > k$ . Assume that  $S_W$  contains two vertices (i,j) and (i,j') of row i. Consider the columns  $j,\ldots,j+f(k)-1$  (column indices modulo  $|J^*|$ ). Then  $S_W$  contains at most k vertices of these columns because  $\equiv^*$ -equivalent vertices in the same row have distance at least f(k) and  $W/_{\equiv^*}$  contains at most

one  $\equiv$ -equivalence class per row. That is, there is a column between the j-th and the (j+f(k))-th column of which no vertex is contained in  $S_W$ . Similarly, there is also a column between the j'-th and the (j'+f(k))-th column of which no vertex is contained in  $S_W$ . So, for both horizontal directions between columns j and j' in the toroidal grid (one towards to the next larger column index and the other one towards the next smaller column index modulo  $|J^*|$ ), there is column of which no vertex is contained in  $S_W$ . Hence, at least one of (i, j) and (i, j') can be removed from  $S_W$  such that we still obtain a vertical toroidal separator. This contradicts  $S_W$  being minimal.

Using these unique k-vertex toroidal vertical separators, we show that a pseudo-separator W that is not a toroidal vertical separator cannot be turned into a toroidal vertical separator by exchanging a single vertex in W.

<span id="page-19-5"></span><span id="page-19-2"></span>**Lemma 30.** Let  $W, W' \subseteq V(C)$  be pseudo-separators each of size k differing by at most one vertex (i.e.,  $|W \cap W'| \ge k-1$ ). Suppose that  $W/_{\equiv^*}$  is a toroidal vertical separator. Then

- <span id="page-19-3"></span>1. there is a k-vertex toroidal separator  $S_{W'} \subseteq W'/_{\equiv^*}$ ,
- 2. the unique k-vertex toroidal vertical separators  $S_W \subseteq W/_{\equiv^*}$  and  $S_{W'} \subseteq W'/_{\equiv^*}$  (see Lemma 29) differ by at most one vertex (i.e.,  $|S_W \cap S_{W'}| \ge k-1$ ), and
- <span id="page-19-4"></span>3. every  $u \in S_{W'}$  has distance at most 2 to  $S_W$  in  $C^*$ .

*Proof.* Note that W and W' each contain exactly one vertex from every row. If  $W/_{\equiv^*} = W'/_{\equiv^*}$ , there is nothing to show, because the set  $S_W$  only depends on  $W/_{\equiv^*}$  (Lemma 29).

So assume that  $W/_{\equiv^*} \neq W'/_{\equiv^*}$  and let  $i \in I$  denote the unique row where W and W' differ. By Lemma 29, there is a unique k-vertex toroidal vertical separator  $S_W \subseteq W/_{\equiv^*}$ . Let  $v_i = (i, j_i)$  denote the vertex of  $S_W$  in row i.

<span id="page-19-0"></span>Claim 1. There is a vertex  $v_i^* = (i, j_i^*) \in W'/_{\approx}$  such that  $(S_W \setminus \{v_i\}) \cup \{v_i^*\}$  is a toroidal vertical separator.

*Proof.* Since W' is a pseudo-separator, the set  $W'/_{\approx}$  contains some k-vertex toroidal vertical separator S'. The elements in S' span at most k consecutive columns by Lemma 26(iii). This implies that the set  $W'/_{\approx}$  is a periodic set of k-vertex toroidal vertical separators that repeat every f(k) columns. More precisely, for every  $z \in \mathbb{Z}$ , we define

$$S_z' \coloneqq \big\{ \, (i, (j+z \cdot f(k)) \bmod |J^*|) \; \big| \; (i,j) \in S' \, \big\}.$$

Every  $S'_z$  is a k-vertex toroidal vertical separator because we just shifted S' by  $z \cdot f(k)$ .

When regarding the columns of elements from different toroidal vertical separators, the distance is at least f(k) - k. Conversely, elements of  $W'/_{\approx}$  whose columns are less than f(k) - k apart are in the same toroidal vertical separator. Thus, there exists an index  $z \in \mathbb{Z}$  such that  $S_W \setminus \{v_i\} \subseteq S'_z$ . Hence, there is a vertex  $v_i^* := (i, j_i^*) \in W'/_{\approx}$  in row i so that the set  $(S_W \setminus \{v_i\}) \cup \{v_i^*\} = S'_z$  is a toroidal vertical separator.

Let  $v_i^* = (i, j_i^*) \in W'/_{\approx}$  be the vertex from Claim 1 such that  $S_{W'} := (S_W \setminus \{v_i\}) \cup \{v_i^*\}$  is a toroidal vertical separator. In particular,  $v_i^*$  has distance at most 2 to  $v_i$  in  $C^*$  by Lemma 26(ii).

<span id="page-19-1"></span>Claim 2. 
$$S_{W'} \subseteq W'/_{\equiv^*}$$
.

*Proof.* First observe that  $S_W \setminus \{v_i\} \subseteq W'/_{\equiv^*}$  since W and W' only differ in row i. So it remains to argue that  $v_i^* \in W'/_{\equiv^*}$ . Let  $v_i' = (i, j_i')$  denote the unique vertex from W' in row i.

The sets  $S_W$  and  $(S_W \setminus \{v_i\}) \cup \{v_i'\}$  contain the same vertex  $(i+1, j_{i+1})$  in row (i+1) (row indices are modulo k). Since  $W, S_W \subseteq W/_{\equiv^*}$  are both k-element sets containing one vertex from each row, we conclude that  $W/_{\equiv^*} = S_W/_{\equiv^*}$ . Similarly,  $W'/_{\equiv^*} = ((S_W \setminus \{v_i\}) \cup \{v_i'\})/_{\equiv^*}$ .

Together with the fact that W and W' are pseudo-separators (and in particular pairwise-separators), this implies

$$(j_i - j_i') \mod f(k) p_{i+1} \in \{-2, \dots, 2\}.$$

Similarly,  $S_W$  and  $(S_W \setminus \{v_i\}) \cup \{v_i'\}$  contain the same element  $(i-1, j_{i-1})$  in row (i-1). Thus,

$$(j_i - j_i') \mod f(k) p_i \in \{-2, \dots, 2\}.$$

In fact, we have more strongly that

$$(j_i - j_i') \mod f(k)p_{i+1} = (j_i - j_i') \mod f(k)p_i.$$

Together these statements imply that

$$(j_i - j_i') \bmod f(k) p_i p_{i+1} \in \{-2, \dots, 2\}$$

by the Chinese Remainder Theorem. So there is some vertex  $v_i''=(i,j_i'')$  in row i in  $W'/_{\equiv^*}$  with  $((j_i''-j_i) \bmod |J^*|) \in \{-2,\ldots,2\}$ .

Now  $v_i^* = (i, j_i^*)$  and  $v_i'' = (i, j_i'')$  are both row i vertices in  $W'/_{\approx}$  in a column at most k away from  $v_i = (i, j_i)$  in  $C^*$ . This means  $v_i^* = v_i'' \in W'/_{\equiv^*}$  since distinct vertices in  $W'/_{\approx}$  that are in same row have distance at least f(k).

Hence,  $S_{W'} = (S_W \setminus \{v_i\}) \cup \{v_i^*\} \subseteq W'/_{\equiv^*}$  is a toroidal vertical separator by Claims 1 and 2. Together with Lemma 29, this proves Parts 1 and 2 of the lemma. To prove Part 3, let  $u \in S_{W'}$ . If  $u \in S_W$ , then u has distance 0 to  $S_W$ . Otherwise,  $u = v_i^*$  and  $v_i^*$  has distance at most 2 to  $v_i \in S_W$  in  $C^*$ .

We are finally ready to consider the compressed Cops and Robber game on the cylindrical grid C and the compression  $\equiv$  (see Lemma 20).

<span id="page-20-0"></span>**Lemma 31.** The robber has a winning strategy in the  $\Omega(|J|)$ -round compressed (k+1)-Cops and Robber game played on C and  $\equiv$  when the robber is initially placed on an edge in the first column.

*Proof.* We set  $\ell := |J|/6 - (k+2)$ . Since  $k \ge 3$  we conclude that  $(k+2) \le |J|/15$  and thus,  $\ell = \Omega(|J|)$ . We now show that the robber has a strategy to win the  $\ell$ -round game.

In the game, the cops can be placed onto at most k+1 many  $\equiv$ -equivalence classes. Instead of considering sets of  $\equiv$ -equivalence classes, we will consider sets of representatives of these classes: A set  $X \subseteq V(C)$  of size at most k+1 is called a **cop position**. Similarly, a set  $W \subseteq V(C)$  of size at most k is called an **intermediate cop position**. With these notions, the game is played as follows:

- 1. In the current cop position X, the cops player picks up one cop from a vertex  $\widehat{x} \in X$  (or a cop that is not placed if  $|X| \leq k$ ). This results in the intermediate cop position  $W = X \setminus \{\widehat{x}\}$  (or W = X if the cop was not placed). The cops player selects a destination  $x \in V(C)$  for this cop.
- 2. The robber moves using a  $\equiv$ -compressible C-twisting fixing all vertices in  $W/_{\equiv}$ .
- 3. The cop picked up is placed on x resulting in the next cop position  $\widehat{X} = W \cup \{x\}$ . If the robber is caught (with respect to  $\widehat{X}/_{\equiv}$ ), then the robber loses.

Since this process repeats, we can also consider the following as one round in this proof:

1. In the current intermediate cop position W, the cops player selects a destination  $x \in V(C)$  for the next cop to place.

- 2. The robber moves using a  $\equiv$ -compressible C-twisting fixing all vertices in  $W/_{\equiv}$ .
- 3. The cops player places a cop on x resulting in the cop position  $X = W \cup \{x\}$ . If the robber is caught (with respect to  $X/_{\equiv}$ ), then the robber loses. Otherwise, the cops player picks up a cop from a vertex  $\widehat{x} \in X$  (or a cop that is not placed if  $|X| \leq k$ ). This results in the next intermediate cop position  $\widehat{W} = X \setminus \{\widehat{x}\}$  (or  $\widehat{W} = X$  if the cop was not placed).

We say that in a cop position X (so in particular in an intermediate cop position) the robber is **located in a cop-free row**, if the robber is located in a row not containing any vertex of  $X/_{\equiv}$ . We prove by induction on the number of rounds  $r \leq \ell$  that the robber has a strategy such that the intermediate cop position W after r rounds satisfies the following two invariants:

- <span id="page-21-1"></span><span id="page-21-0"></span>(I.1) The robber is located at a cop-free column among the first k+2 or the last k+2 columns of the cylindrical grid C.
- (I.2) If  $W/_{\equiv^*}$  is a toroidal vertical separator, then the following holds:
  - If the robber is located within the first k+2 columns, then the distance in the toroidal grid  $C^*$  between column 0 (i.e., the set  $I \times \{0\}$ ) and the unique k-vertex toroidal vertical separator  $S_W \subseteq W/_{\equiv^*}$  (Lemma 29) is at least |J|/3 2r.
  - If the robber is located within the last k+2 columns, then the distance in the toroidal grid  $C^*$  between column |J|-1 (i.e., the set  $I \times \{|J|-1\}$ ) and the unique k-vertex toroidal vertical separator  $S_W \subseteq W/_{\equiv^*}$  (Lemma 29) is at least |J|/3-2r.

Note that the invariant is independent of the representative vertices chosen in the cop position because all vertices in the first and last k+2 columns of C are singleton  $\equiv$ -equivalence classes. Moreover,  $W/_{\equiv^*}$  is independent of the chosen cop position because  $\equiv$ -equivalent vertices are always  $\equiv^*$ -equivalent.

In the beginning of the game, the invariant clearly holds because no cop is placed. So assume  $r < \ell$ , let W be the current intermediate cop position, and let  $x \in V(C)$  be the chosen destination for the next cop to place, which will result in the cop position  $X := W \cup \{x\}$ . Now it is the robber's turn to move.

By Invariant (I.1), the robber is located within the first or last k+2 columns of C. Assume that the robber is located within the first k+2 columns (the argument for the last k+2 columns is analogous). We make the following case distinction:

<span id="page-21-2"></span>1. Assume  $W/_{\equiv^*}$  is a toroidal vertical separator. The robber picks a column among the first k+2 that does not contain a vertex of X. Such a column exists because X contains vertices from at most k+1 columns. By Invariant (I.2), every vertical separator has distance at least k+2 to the first column. Hence,  $W/_{\equiv^*}$  does not separate the first k+2 columns and so there is a path from the robber to the picked column within the first k+2 columns. Hence, this path only uses vertices in singleton  $\equiv$ -equivalence classes and thus induces a  $\equiv$ -compressible C-twisting avoiding  $W/_{\equiv}$ . The robber moves to this column. Now a cop is placed on x. By construction, the column of the robber is still cop-free in the cop position X. In particular, the robber does not lose in this round.

Now a cop is picked up again resulting in the intermediate cop position  $\widehat{W} \subseteq X$ . Because the robber was in a cop-free row in the cop position X, the robber is still in a cop-free row and hence Invariant (I.1) holds.

Let  $S_W \subseteq W/_{\equiv^*}$  be the unique k-vertex vertical separator contained in  $W/_{\equiv^*}$  (see Lemma 29). In particular, W is a pseudo-separator. Because k-vertex pseudo-separators have to contain exactly one vertex per row, there is at most one other k-vertex pseudo-separator  $W' \subseteq X$  distinct from W (W' contains x but not the vertex in the same row in W). We make another case distinction:

- Assume the other pseudo-separator W' exists. Then, by Lemma 30,  $W'/_{\equiv^*}$  contains a unique k-vertex toroidal vertical separator  $S_{W'} \subseteq W'/_{\equiv^*}$  differing by at most one vertex from  $S_W$ . This vertex has distance at most 2 to  $S_W$ . If  $\widehat{W}/_{\equiv^*}$  is a toroidal vertical separator, then  $\widehat{W} = W'$  or  $\widehat{W} = W$  (because  $\widehat{W}$  is in particular a pseudo-separator) and the unique k-vertex toroidal vertical separator contained in  $\widehat{W}/_{\equiv^*}$  is either  $S_W$  or  $S_{W'}$ . The distance between  $S_W$  and the first column is at least |J|/3 2(r-1) by the inductive hypothesis. Because the new vertex in  $S_{W'}$  has distance at most 2 to  $S_W$ , the distance between  $S_{W'}$  and the first column is at least |J|/3 2r. Hence, Invariant (I.2) holds. If otherwise  $\widehat{W}/_{\equiv^*}$  is not a toroidal vertical separator, then Invariant (I.2) trivially holds.
- Otherwise W is the only k-vertex pseudo-separator contained in X. If  $\widehat{W}/_{\equiv^*}$  is a toroidal vertical separator, then  $\widehat{W}=W$ . By the inductive hypothesis,  $S_W$  has distance  $|J|/3-2(r-1)\geq |J|/3-2r$  to the first column. Hence, Invariant (I.2) holds. If otherwise  $\widehat{W}/_{\equiv^*}$  is not a toroidal vertical separator, then Invariant (I.2) trivially holds.
- 2. Assume  $W/_{\equiv^*}$  is a pseudo-separator but not a toroidal vertical separator. In particular,  $W/_{\equiv}$  does not separate the first k+2 columns of C. The robber moves to a column among the first k+2 not containing a vertex of X exactly as in Case 1. A cop is placed on x. The robber is still in a cop-free column and does not lose in this round. A cop is picked up again resulting in the intermediate cop position  $\widehat{W} \subseteq X$ . Invariant (I.1) holds because the robber is still in a cop-free column.

As in Case 1, there can be at most one other k-vertex pseudo-separator  $W' \subseteq X$  distinct from W. If  $\widehat{W}$  is not a pseudo-separator, then in particular  $\widehat{W}/_{\equiv^*}$  is not a toroidal vertical separator and Invariant (I.2) trivially holds.

Otherwise,  $\widehat{W}$  is a pseudo-separator. Then, by Lemmas 29 and 30,  $\widehat{W}/_{\equiv^*}$  cannot be a toroidal vertical separator and Invariant (I.2) trivially holds.

- 3. Lastly, assume  $W/_{\equiv^*}$  is not a pseudo-separator. There can be at most one k-vertex pseudo-separator  $W' \subseteq X$  (because k-vertex pseudo-separators contain exactly one vertex per row and W is not a pseudo-separator). We make another case distinction:
  - (a) Assume this pseudo-separator W' exists and that  $W'/_{\equiv^*}$  is a toroidal vertical separator. Then  $W'/_{\equiv^*}$  contains a unique k-vertex toroidal vertical separator  $S_{W'} \subseteq W'/_{\equiv^*}$  by Lemma 29. We distinguish two more cases:
    - Assume the first column has distance at least |J|/3 to  $S_{W'}$  in the toroidal grid  $C^*$ . The robber moves to a column among the first k+2 not containing a vertex of X. A cop is placed on x. The robber does not lose in this round and Invariant (I.1) holds as before. After a cop is picked up, let  $\widehat{W} \subseteq X$  be the resulting intermediate cop position.
      - If  $\widehat{W}/_{\equiv^*}$  is a toroidal vertical separator, then  $\widehat{W}=W'$  and the first column has distance at least |J|/3 to  $S_{W'}$  satisfying Invariant (I.2). Otherwise,  $\widehat{W}/_{\equiv^*}$  is not a toroidal vertical separator and Invariant (I.2) trivially holds.
    - Otherwise, the first column has distance less than |J|/3 to  $S_{W'}$  in the toroidal grid  $C^*$ . By construction and Lemma 26, the last column of the cylindrical grid C has distance at least  $|J| |J|/3 3k 3 \ge |J|/3$  to  $S_{W'}$  in the toroidal grid  $C^*$  because  $S_{W'}$  spans at most k consecutive columns in  $C^*$  (see Figure 3). Recall that C is a subgraph of  $C^*$  and that C has length |J| and  $C^*$  has length  $|J^*| = 2 \cdot |J|$ .

Because W is not a pseudo-separator, there exists an end-to-end twisting avoiding W by Lemma 28 that twists two edges  $e_1$  and  $e_2$ . Assume that  $e_1$  is the edge

in the first column of C. Because the robber is in a cop-free column and this twisting exists, there is a W-avoiding path from the robber to  $e_1$  within the first k+2 columns. Via this path and the end-to-end twisting, the robber moves to the last column in C. From there, the robber moves to a column not containing a vertex of X among the last k+2 as seen earlier for the first k+2 columns. A cop is placed on x. Again, the robber does not lose and Invariant (I.1) holds. Next, a cop is picked up resulting in the intermediate cop position  $\widehat{W} \subseteq X$ . If  $\widehat{W}$  is a toroidal vertical separator, then  $\widehat{W} = W'$ , the robber has distance at least |J|/3 to  $S_{W'}$ , and thus Invariant (I.2) holds. Otherwise,  $\widehat{W}$  is not a toroidal vertical separator and Invariant (I.2) trivially holds.

(b) Otherwise, the robber moves to a column among the first k+2 not containing a vertex of X. This is done as in Case 1. A cop is placed on x. The robber does not lose in this round and Invariant (I.1) holds as before. After a cop is picked up, the resulting intermediate cop position  $\widehat{W} \subseteq X$  is not a toroidal vertical separator because, for no k-vertex subset  $W' \subseteq X$ , the set  $W'/_{\equiv^*}$  is a toroidal vertical separator. Thus, Invariant (I.2) trivially holds.

<span id="page-23-0"></span>**Lemma 32.** Let  $f,g: E \to \mathbb{F}_2$  twist a single edge contained in the first column. Spoiler wins the bijective (k+1)-pebble game played on  $\mathsf{CFI}(C,f)/_{\equiv}$  and  $\mathsf{CFI}(C,g)/_{\equiv}$  but not before  $\Omega(|J|)$  many rounds.

*Proof.* The equivalence relation  $\equiv$  is a compression by Lemma 20. Also, the functions f and g are  $\equiv$ -compressible because in the first column all vertices are in singleton  $\equiv$ -equivalence classes. By Lemma 6, Spoiler wins the bijective (k+1)-pebble game on non-isomorphic CFI graphs over cylindrical grids with k rows. So Spoiler also wins on the precompressed CFI graphs  $(\mathsf{CFI}(C,f),\equiv)$  and  $(\mathsf{CFI}(C,g),\equiv)$  and hence, on the compressed CFI graphs  $\mathsf{CFI}(C,f)/\equiv$  and  $\mathsf{CFI}(C,g)/\equiv$  by Lemma 14.

By Lemma 31, the robber wins the  $\Omega(|J|)$ -round (k+1)-Cops and Robber game on C and  $\equiv$  when the robber starts in the first column. So Duplicator wins the  $\Omega(|J|)$ -round bijective (k+1)-pebble game played on  $(\mathsf{CFI}(C,f),\equiv)$  and  $(\mathsf{CFI}(C,g),\equiv)$  (Lemma 16) and on  $\mathsf{CFI}(C,f)/\equiv$  and  $\mathsf{CFI}(C,g)/\equiv$  (Corollary 15).

We are now ready to prove the main result of this paper.

<span id="page-23-1"></span>**Theorem 33.** There is a constant  $c \in \mathbb{R}_{>0}$  such that, for all integers  $k \geq 2$  and  $n \geq c(k \log k)^2$ , there are graphs  $G_n, H_n$  such that

- (a)  $|V(G_n)| = |V(H_n)| \le c \cdot k^2 \cdot n$ ,
- (b)  $G_n \simeq_{k+1}^{n^{k/2}} H_n$ , and
- (c)  $G_n \not\simeq_{k+1} H_n$ .

*Proof.* The statement is already known for  $k \leq 2$  (see Section 3). Let  $1 > \varepsilon > 0$  be a sufficiently small constant and  $c \in \mathbb{R}_{>0}$  be sufficiently large (in particularly larger than the constant known for the case  $k \leq 2$ ). Also, let  $k \geq 2$  and  $n \geq c(k \log k)^2$  be arbitrary integers. We set  $w \coloneqq \frac{2}{\varepsilon} \cdot \lceil \sqrt{n} \rceil$ . Then  $w \geq \frac{2}{\varepsilon} \cdot \sqrt{c} \cdot k \cdot \log k$  which implies that Equation (2) is satisfied (since c is sufficiently large), and there are coprime numbers  $p_0, \ldots, p_{k-1}$  such that  $w/2 < p_i \leq w$  (see Lemma 17).

Let  $f,g: E \to \mathbb{F}_2$  twist a single edge contained in the first column of  $C_{I,J}$ , where I and J are defined as before with respect to the numbers  $p_0,\ldots,p_{k-1}$ . Consider  $G_n := \mathsf{CFI}(C_{I,J},f)/_{\equiv}$  and  $H_n := \mathsf{CFI}(C_{I,J},g)/_{\equiv}$ . Then  $|V(G_n)| = |V(H_n)| = \Theta(k^2 \cdot w^2) = \Theta(k^2 \cdot n)$  by Lemmas 10 and 19. In particular,  $|V(G_n)| = |V(H_n)| \le c \cdot k^2 \cdot n$  since c is sufficiently large.

By Lemma 32, Spoiler wins the bijective (k+1)-pebble game played on  $G_n$  and  $H_n$  but not before  $\Omega(|J|)$  many rounds. We have

$$|J| \ge (w/2)^k \ge \left(\frac{1}{\varepsilon} \cdot \sqrt{n}\right)^k \ge \frac{1}{\varepsilon} \cdot n^{k/2}.$$

which implies that

$$\varepsilon \cdot |J| \ge n^{k/2}$$
.

Since  $\varepsilon > 0$  is sufficiently small, Spoiler has no winning strategy in the  $n^{k/2}$ -round game, which implies that  $G_n \simeq_{k+1}^{n^{k/2}} H_n$ .

<span id="page-24-0"></span>**Corollary 34.** There is a constant  $c \in \mathbb{R}_{>0}$  such that, for all integers  $k \geq 2$  and  $n \geq c(k \log k)^2$ , there are graphs  $G_n, H_n$  such that

- (a)  $|V(G_n)| = |V(H_n)| \le c \cdot k^2 \cdot n$ ,
- (b) k-WL distinguishes  $G_n$  and  $H_n$ , and
- (c) k-WL requires at least  $n^{k/2}$  rounds to distinguish  $G_n$  and  $H_n$ .

*Proof.* This follows from Lemma 2 and Theorem 33.

Finally, Theorem 1 follows directly from Corollary 34.

#### 6 Conclusions

We prove a lower bound of  $\Omega(n^{k/2})$  for the iteration number of the k-dimensional Weisfeiler-Leman algorithm on graphs. This is the first improvement over Fürer's linear lower bound from 2001 [11]. Furthermore, our lower bound even improves the  $n^{\Omega(k)}$  lower bound for the iteration number of k-WL on k-ary relational structures [14] (by establishing the fixed constant k/2 for the exponent). Our lower bound is close to the upper bound of  $\mathcal{O}(n^{k-1}\log n)$ , but we leave it as an open problem where the exact bound is situated.

Our main technical contribution is a novel compression technique for CFI graphs. There is a well-known connection between the CFI graphs and Boolean XOR-formulas (see [6]). Hence, our construction can also be viewed as a new compression for XOR-formulas. Furthermore, the WL-algorithm is related to the polynomial calculus, where the dimension k corresponds to the degree of the polynomials in a derivation [4]. It will be interesting to explore further implications of our construction for proof complexity. Indeed, after its first publication, our construction has already been used in proof complexity to show treelike-size vs. width trade-offs for resolution on graph isomorphism formulas [5] and size vs. width and depth vs. width trade-offs for resolution and size vs. depth trade-offs for the cutting planes proof system [9].

By a known equivalence between the Weisfeiler-Leman algorithm and the finite-variable fragments of first-order logic [7] (also see [18]), our lower bound also yields an  $\Omega(n^{(k-1)/2})$ -lower bound on the quantifier depth of sentences in the k-variable fragment of first-order logic (with or without counting) needed to distinguish non-isomorphic graphs of order n.

Finally, we remark that (3k)-WL can distinguish between the constructed instances using only  $\mathcal{O}(\log n)$  many rounds (for every fixed  $k \geq 2$ ). Indeed, using the same "binary search" strategy already employed in [11], (3k)-WL only requires  $\mathcal{O}(\log n)$  rounds to distinguish between  $\mathsf{CFI}(C_{I,J},f)$  and  $\mathsf{CFI}(C_{I,J},g)$  (assuming  $\sum f \neq \sum g$ ). Using Lemma 14, the same bounds can be achieved for the compressed versions  $\mathsf{CFI}(C_{I,J},f)/_{\equiv}$  and  $\mathsf{CFI}(C_{I,J},g)/_{\equiv}$ . It is an interesting open question whether our construction can be modified so that the iteration number remains large even if the dimension increases.

# <span id="page-25-4"></span>**References**

- [1] Albert Atserias and Joanna Fijalkow. Definable ellipsoid method, sums-of-squares proofs, and the graph isomorphism problem. *SIAM J. Comput.*, 52(5):1193–1229, 2023. URL: <https://doi.org/10.1137/20m1338435>, [doi:10.1137/20M1338435](https://doi.org/10.1137/20M1338435).
- <span id="page-25-3"></span>[2] Albert Atserias and Elitza N. Maneva. Sherali-Adams relaxations and indistinguishability in counting logics. *SIAM J. Comput.*, 42(1):112–137, 2013. [doi:10.1137/120867834](https://doi.org/10.1137/120867834).
- <span id="page-25-1"></span>[3] L´aszl´o Babai. Graph isomorphism in quasipolynomial time [extended abstract]. In Daniel Wichs and Yishay Mansour, editors, *Proceedings of the 48th Annual ACM SIGACT Symposium on Theory of Computing, STOC 2016, Cambridge, MA, USA, June 18-21, 2016*, pages 684–697. ACM, 2016. [doi:10.1145/2897518.2897542](https://doi.org/10.1145/2897518.2897542).
- <span id="page-25-5"></span>[4] Christoph Berkholz and Martin Grohe. Limitations of algebraic approaches to graph isomorphism testing. In Magn´us M. Halld´orsson, Kazuo Iwama, Naoki Kobayashi, and Bettina Speckmann, editors, *Automata, Languages, and Programming - 42nd International Colloquium, ICALP 2015, Kyoto, Japan, July 6-10, 2015, Proceedings, Part I*, volume 9134 of *Lecture Notes in Computer Science*, pages 155–166. Springer, 2015. [doi:10.1007/978-3-662-47672-7\\\_13](https://doi.org/10.1007/978-3-662-47672-7_13).
- <span id="page-25-8"></span>[5] Christoph Berkholz, Moritz Lichter, and Harry Vinall-Smeeth. Supercritical size-width tree-like resolution trade-offs for graph isomorphism. *CoRR*, abs/2407.17947, 2024. arXiv preprint. [doi:10.48550/arXiv.2407.17947](https://doi.org/10.48550/arXiv.2407.17947).
- <span id="page-25-6"></span>[6] Christoph Berkholz and Jakob Nordstr¨om. Near-optimal lower bounds on quantifier depth and Weisfeiler-Leman refinement steps. *J. ACM*, 70(5):32:1–32:32, 2023. [doi:10.1145/3195257](https://doi.org/10.1145/3195257).
- <span id="page-25-10"></span><span id="page-25-0"></span>[7] Jin-yi Cai, Martin F¨urer, and Neil Immerman. An optimal lower bound on the number of variables for graph identification. *Comb.*, 12(4):389–410, 1992. [doi:10.1007/BF01305232](https://doi.org/10.1007/BF01305232).
- [8] Anuj Dawar and David Richerby. The power of counting logics on restricted classes of finite structures. In Jacques Duparc and Thomas A. Henzinger, editors, *Computer Science Logic, 21st International Workshop, CSL 2007, 16th Annual Conference of the EACSL, Lausanne, Switzerland, September 11-15, 2007, Proceedings*, volume 4646 of *Lecture Notes in Computer Science*, pages 84–98. Springer, 2007. [doi:10.1007/978-3-540-74915-8\\\_10](https://doi.org/10.1007/978-3-540-74915-8_10).
- <span id="page-25-11"></span>[9] Susanna F. de Rezende, Noah Fleming, Duri Andrea Janett, Jakob Nordstr¨om, and Shuo Pang. Truly supercritical trade-offs for resolution, cutting planes, monotone circuits, and Weisfeiler-Leman. *CoRR*, abs/2411.14267, 2024. arXiv preprint. [doi:10.48550/ARXIV.2411.14267](https://doi.org/10.48550/ARXIV.2411.14267).
- <span id="page-25-2"></span>[10] Zdenek Dvor´ak. On recognizing graphs by numbers of homomorphisms. *J. Graph Theory*, 64(4):330–342, 2010. [doi:10.1002/jgt.20461](https://doi.org/10.1002/jgt.20461).
- <span id="page-25-7"></span>[11] Martin F¨urer. Weisfeiler-Lehman refinement requires at least a linear number of iterations. In Fernando Orejas, Paul G. Spirakis, and Jan van Leeuwen, editors, *Automata, Languages and Programming, 28th International Colloquium, ICALP 2001, Crete, Greece, July 8-12, 2001, Proceedings*, volume 2076 of *Lecture Notes in Computer Science*, pages 322–333. Springer, 2001. [doi:10.1007/3-540-48224-5\\\_27](https://doi.org/10.1007/3-540-48224-5_27).
- <span id="page-25-9"></span>[12] Erich Gr¨adel and Wied Pakusa. Rank logic is dead, long live rank logic! *J. Symb. Log.*, 84(1):54–87, 2019. [doi:10.1017/jsl.2018.33](https://doi.org/10.1017/jsl.2018.33).

- <span id="page-26-1"></span>[13] Martin Grohe, Kristian Kersting, Martin Mladenov, and Erkal Selman. Dimension reduction via colour refinement. In Andreas S. Schulz and Dorothea Wagner, editors, *Algorithms - ESA 2014 - 22th Annual European Symposium, Wroclaw, Poland, September 8-10, 2014. Proceedings*, volume 8737 of *Lecture Notes in Computer Science*, pages 505–516. Springer, 2014. [doi:10.1007/978-3-662-44777-2\\\_42](https://doi.org/10.1007/978-3-662-44777-2_42).
- <span id="page-26-10"></span><span id="page-26-2"></span>[14] Martin Grohe, Moritz Lichter, and Daniel Neuen. The iteration number of the Weisfeiler-Leman algorithm. In *LICS*, pages 1–13, 2023. [doi:10.1109/LICS56636.2023.10175741](https://doi.org/10.1109/LICS56636.2023.10175741).
- [15] Martin Grohe and Martin Otto. Pebble games and linear equations. *J. Symb. Log.*, 80(3):797–844, 2015. [doi:10.1017/jsl.2015.28](https://doi.org/10.1017/jsl.2015.28).
- <span id="page-26-11"></span><span id="page-26-0"></span>[16] Lauri Hella. Logical hierarchies in PTIME. *Inf. Comput.*, 129(1):1–19, 1996. [doi:10.1006/inco.1996.0070](https://doi.org/10.1006/inco.1996.0070).
- [17] Neil Immerman and Eric Lander. Describing graphs: A first-order approach to graph canonization. In Alan L. Selman, editor, *Complexity Theory Retrospective: In Honor of Juris Hartmanis on the Occasion of His Sixtieth Birthday, July 5, 1988*, pages 59–81. Springer New York, New York, NY, 1990. [doi:10.1007/978-1-4612-4478-3\\_5](https://doi.org/10.1007/978-1-4612-4478-3_5).
- <span id="page-26-7"></span><span id="page-26-6"></span>[18] Sandra Kiefer. The Weisfeiler-Leman algorithm: an exploration of its power. *ACM SIGLOG News*, 7(3):5–27, 2020. [doi:10.1145/3436980.3436982](https://doi.org/10.1145/3436980.3436982).
- [19] Sandra Kiefer and Brendan D. McKay. The iteration number of colour refinement. In Artur Czumaj, Anuj Dawar, and Emanuela Merelli, editors, *47th International Colloquium on Automata, Languages, and Programming, ICALP 2020, July 8-11, 2020, Saarbr¨ucken, Germany (Virtual Conference)*, volume 168 of *LIPIcs*, pages 73:1–73:19. Schloss Dagstuhl - Leibniz-Zentrum f¨ur Informatik, 2020. [doi:10.4230/LIPIcs.ICALP.2020.73](https://doi.org/10.4230/LIPIcs.ICALP.2020.73).
- <span id="page-26-8"></span>[20] Sandra Kiefer and Pascal Schweitzer. Upper bounds on the quantifier depth for graph differentiation in first-order logic. *Log. Methods Comput. Sci.*, 15(2), 2019. [doi:10.23638/LMCS-15\(2:19\)2019](https://doi.org/10.23638/LMCS-15(2:19)2019).
- <span id="page-26-12"></span><span id="page-26-9"></span>[21] Moritz Lichter. Separating rank logic from polynomial time. *J. ACM*, 70(2):14:1–14:53, 2023. [doi:10.1145/3572918](https://doi.org/10.1145/3572918).
- [22] Moritz Lichter, Ilia Ponomarenko, and Pascal Schweitzer. Walk refinement, walk logic, and the iteration number of the Weisfeiler-Leman algorithm. In *34th Annual ACM/IEEE Symposium on Logic in Computer Science, LICS 2019, Vancouver, BC, Canada, June 24-27, 2019*, pages 1–13. IEEE, 2019. [doi:10.1109/LICS.2019.8785694](https://doi.org/10.1109/LICS.2019.8785694).
- <span id="page-26-3"></span>[23] Peter N. Malkin. Sherali-Adams relaxations of graph isomorphism polytopes. *Discret. Optim.*, 12:73–97, 2014. [doi:10.1016/j.disopt.2014.01.004](https://doi.org/10.1016/j.disopt.2014.01.004).
- <span id="page-26-4"></span>[24] Christopher Morris, Yaron Lipman, Haggai Maron, Bastian Rieck, Nils M. Kriege, Martin Grohe, Matthias Fey, and Karsten M. Borgwardt. Weisfeiler and Leman go machine learning: The story so far. *CoRR*, abs/2112.09992, 2021. URL: <https://arxiv.org/abs/2112.09992>, [arXiv:2112.09992](http://arxiv.org/abs/2112.09992).
- <span id="page-26-5"></span>[25] Christopher Morris, Martin Ritzert, Matthias Fey, William L. Hamilton, Jan Eric Lenssen, Gaurav Rattan, and Martin Grohe. Weisfeiler and Leman go neural: Higher-order graph neural networks. In *The Thirty-Third AAAI Conference on Artificial Intelligence, AAAI 2019, Honolulu, Hawaii, USA, January 27 - February 1, 2019*, pages 4602–4609. AAAI Press, 2019. [doi:10.1609/aaai.v33i01.33014602](https://doi.org/10.1609/aaai.v33i01.33014602).

- <span id="page-27-7"></span>[26] Srinivasa Ramanujan. A proof of Bertrand's postulate [J. Indian Math. Soc. **11** (1919), 181–182]. In *Collected papers of Srinivasa Ramanujan*, pages 208–209. AMS Chelsea Publ., Providence, RI, 2000.
- <span id="page-27-3"></span>[27] Alexander A. Razborov. A new kind of tradeoffs in propositional proof complexity. *J. ACM*, 63(2):16:1–16:14, 2016. [doi:10.1145/2858790](https://doi.org/10.1145/2858790).
- <span id="page-27-6"></span>[28] David E. Roberson. Oddomorphisms and homomorphism indistinguishability over graphs of bounded degree. *CoRR*, abs/2206.10321, 2022. [arXiv:2206.10321](http://arxiv.org/abs/2206.10321), [doi:10.48550/arXiv.2206.10321](https://doi.org/10.48550/arXiv.2206.10321).
- <span id="page-27-5"></span><span id="page-27-4"></span>[29] Pascal Schweitzer. Iterated open neighborhood graphs and generalizations. *Discret. Appl. Math.*, 161(10-11):1598–1609, 2013. [doi:10.1016/j.dam.2012.12.023](https://doi.org/10.1016/j.dam.2012.12.023).
- <span id="page-27-1"></span>[30] Paul D. Seymour and Robin Thomas. Graph searching and a min-max theorem for treewidth. *J. Comb. Theory, Ser. B*, 58(1):22–33, 1993. [doi:10.1006/jctb.1993.1027](https://doi.org/10.1006/jctb.1993.1027).
- [31] Nino Shervashidze, Pascal Schweitzer, Erik Jan van Leeuwen, Kurt Mehlhorn, and Karsten M. Borgwardt. Weisfeiler-Lehman graph kernels. *J. Mach. Learn. Res.*, 12:2539– 2561, 2011. URL: <https://dl.acm.org/doi/10.5555/1953048.2078187>.
- <span id="page-27-8"></span><span id="page-27-0"></span>[32] Jonathan Sondow. Ramanujan primes and Bertrand's postulate. *Amer. Math. Monthly*, 116(7):630–635, 2009. [doi:10.1080/00029890.2009.11920980](https://doi.org/10.1080/00029890.2009.11920980).
- [33] Boris Weisfeiler and Andrei Leman. The reduction of a graph to canonical form and the algebra which appears therein. *NTI, Series 2*, 1968. English translation by Grigory Ryabov available at [https://www.iti.zcu.cz/wl2018/pdf/wl\\_paper\\_translation.pdf](https://www.iti.zcu.cz/wl2018/pdf/wl_paper_translation.pdf).
- <span id="page-27-2"></span>[34] Keyulu Xu, Weihua Hu, Jure Leskovec, and Stefanie Jegelka. How powerful are graph neural networks? In *7th International Conference on Learning Representations, ICLR 2019, New Orleans, LA, USA, May 6-9, 2019*. OpenReview.net, 2019. URL: <https://openreview.net/forum?id=ryGs6iA5Km>.