![](_page_0_Picture_1.jpeg)

# **HOW RANDOM CSPS FOOL HIERARCHIES**

SIU ON CHAN*<sup>⋆</sup>* , HIU TSUN NG*†* , AND SIJIN PENG*‡*

Abstract. Relaxations for the constraint satisfaction problem (CSP) include bounded width, linear program (LP), semidefinite program (SDP), affine integer program (AIP), and the combined LP+AIP of Brakensiek, Guruswami, Wrochna, and Živný (SICOMP 2020). Tightening relaxations systematically leads to hierarchies and stronger algorithms. For the LP+AIP hierarchy, a constant level lower bound for approximate graph coloring was given by Ciardo and Živný (STOC 2023).

We prove the first linear (and hence optimal) level lower bound for LP+AIP and its stronger variant, SDP+AIP. For each hierarchy, our bound holds for random instances of a broad class of CSPs that we call *τ -wise neutral*. We extend to other hierarchies the LP lower bound techniques in Benabbas, Georgiou, Magen and Tulsiani (ToC 2012) and Kothari, Mori, O'Donnell, and Witmer (STOC 2017), and simplify the SDP solution construction in the latter.

# 1. Introduction

Promise constraint satisfaction problem (PCSP), originated from [[AGH17](#page--1-0)], is a variant of constraint satisfaction problem. In PCSP, given the promise that a CSP instance has a solution satisfying all the constraints, an algorithm is only required to find a solution satisfying all the constraints after each constraint is weakened; see [\[KO22](#page--1-1)] for a survey. An example is *C*-vs-*K* graph coloring (*C* ⩽ *K*), where an input graph *G* is guaranteed to have a proper *C*-coloring, and our algorithm only needs to find a proper *K*-coloring of *G*. The complexity of this problem when *C* = 3 and *K* = 6 is still open. 3-vs-*K* graph coloring was conjectured NP-hard for every constant *K* ⩾ 3. [1](#page-0-0) This conjecture holds under the *d*-to-1 conjecture [[GS20](#page--1-2)]. *C*-vs-*K* graph coloring is NP-hard for every constant *C* ⩾ 4 and *K* = *<sup>C</sup> bC/*2*c −* 1 [[KOWŽ23](#page--1-3)].

Brakensiek, Guruswami, Wrochna, and Živný [[BG19](#page--1-4), [BGWŽ20](#page--1-5)] proposed the combined linear and affine integer program (LP+AIP) to unify many algorithms for (P)CSP.[2](#page-0-1) LP+AIP solves all tractable Boolean CSPs and is quite powerful, leading [\[BGWŽ20](#page--1-5), [KO22\]](#page--1-1) to ask if LP+AIP strengthened into a hierarchy solves all tractable CSPs. A hierarchy is a relaxation systematically tightened based on small variable subsets of an instance; level *d* of a hierarchy is tightened by constraints induced on subsets of variables of size at most *d*. Hierarchies for LP and SDP include Sherali–Adams, Lovász–Schrijver, Grigoriev, Lasserre, and Parrilo (e.g. [\[Lau09\]](#page--1-6)).

For the LP+AIP hierarchy, Ciardo and Živný [[CŽ23b](#page--1-7)] showed that constant level fails to solve 3-vs-*K* graph coloring, for any constant *K*. This was the only lower bound known for the LP+AIP hierarchy, leaving open whether sublinear-level LP+AIP solves *C*-vs-*K* graph coloring for every *C* ⩽ *K*, or other (P)CSPs. Since the level-*d* hierarchy can be solved in time roughly *n O*(*d*) , sublinearlevel LP+AIP might still solve every (P)CSP in subexponential time.

In this paper, we give the first linear (and optimal) level lower bound for the LP+AIP hierarchy, as well as the first average case lower bound for LP+AIP (with or without the hierarchy). Our

*<sup>⋆</sup>* <sochan@gmail.com>.

*<sup>†</sup>*Chinese University of Hong Kong. <1155144015@link.cuhk.edu.hk>.

<span id="page-0-0"></span>*<sup>‡</sup>*Tsinghua University. <peng-sj21@mails.tsinghua.edu.cn>.

<sup>1</sup>This conjecture is a special case of [\[BG21](#page--1-8), Conjecture 1.2]. [\[CŽ23b\]](#page--1-7) attributed the former conjecture to [[GJ76](#page--1-9)], but [\[GJ76\]](#page--1-9) only conjectured hardness for *K/C* = *O*(1) without specifying *C*, already proved in [\[LY94](#page--1-10)].

<span id="page-0-1"></span><sup>2</sup>They called it BLP+AIP, where the B stands for "basic".

lower bound applies to a broad class of CSPs different from graph coloring, by generalizing lower bound techniques from other hierarchies. Here are some hierarchies of interest to us:

- *•* Bounded width hierarchy (BW) in the local consistency algorithm, which is "dual" to bounded-width resolution refutation.[3](#page-1-0)
- *•* Sherali–Adams linear programming (LP) hierarchy.
- *•* Lasserre semidefinite programming (SDP) hierarchy, which is the Lagrangian dual of the sum-of-squares SDP hierarchy.
- *•* Affine integer programming (AIP) hierarchy.

Barto, Bulín, Krokhin, and Opršal [\[BBKO21](#page-43-0), Section 7] pointed out the similarity of the BW, LP, and AIP relaxations in terms of minions (i.e. minor-closed families of functions) representing the relaxed values and their homomorphisms. Ciardo and Živný [\[CŽ23c\]](#page-43-1) gave a *common description* of the four hierarchies in terms of minions and tensors. This paper goes in a different direction, giving a framework to prove *lower bounds* for these hierarchies that are optimal in terms of level.

Previously, Benabbas, Georgiou, Magen and Tulsiani [[BGMT12](#page-43-2)] and Kothari, Mori, O'Donnell, and Witmer [[KMOW17\]](#page-44-0) gave (optimal) linear level lower bounds for the LP and SDP hierarchies respectively. We generalize their techniques to other hierarchies, including BW and AIP. They considered CSPs that are *τ -wise uniform*, a notion introduced by Austrin and Mossel [[AM09\]](#page-43-3) in the context of hardness of approximation. A CSP is *τ* -wise uniform if every constraint *C* has a distribution *η*(*C*) of satisfying assignments, such that the marginal given *η*(*C*) of every subset of *τ* variables is uniform. For example, the CSPs *k*-SAT and *k*-XOR are both (*k −* 1)-wise uniform, because the satisfying assignments of their constraints support the uniform distribution over assignments of even (or odd) parity, which is a (*k −* 1)-wise uniform distribution. Inspired by *τ* -wise uniformity, we introduce an analogous property for each hierarchy: *τ -wise neutrality* ([Definition 4.3\)](#page-11-0). Our first main result, proved in [Section 8.2,](#page-21-0) is that most instances of any *τ* -wise neutral CSP have linear-level hierarchy solutions.

<span id="page-1-1"></span>**Theorem 1.1.** *Let τ* ⩾ 2*. For each elementary hierarchy (BW, LP, SDP, and AIP), if a k-CSP is τ -wise neutral for the hierarchy, then except with probability on*;*k*(1)*, a random instance of the CSP with n variables and* ∆*n constraints has a hierarchy solution of level* Ω*k*(*n/*(∆2*/*(*τ−*1) log ∆))*.*

Most instances at large constraint density ∆ are far from satisfiable, unless the CSP is trivially satisfiable by a single value [\(Lemma B.3\)](#page-38-0). Yet [Theorem 1.1](#page-1-1) shows that many hierarchies fail to certify these instances as unsatisfiable and are thus *fooled*.

While the LP and SDP parts of [Theorem 1.1](#page-1-1) were already known, the BW and AIP parts are new. Previously BW/resolution hierarchy lower bounds for a broad class of CSPs were known only for *τ* = 2 as a special case of [[CM13](#page-43-4), Theorem 1.4(a)] but not for larger *τ* . The AIP part of [Theorem 1.1](#page-1-1) is also new. Part of our contribution is identifying a generalization of *τ* -wise uniformity to AIP. *τ* -wise neutrality for AIP turns out to be fairly general and has a simple sufficient condition: Satisfying assignments include a Hamming ball of radius *τ* ([Proposition 4.5\)](#page-12-0).

Consider LP+AIP lower bounds for *k*-SAT. Because *k*-SAT is (*k −* 2)-wise neutral for LP+AIP ([Theorem 8.21](#page-23-0)), [Theorem 1.1](#page-1-1) implies most *k*-SAT instances fool LP+AIP whenever *k* ⩾ 4. But not for 3-SAT, the most important CSP in complexity theory. The LP+AIP algorithm looks for distributions *η*(*C*) of satisfying assignments to constraints *C*, and affine integer weights *w*(*C*) : supp(*η*(*C*)) *→* Z supported on the support of *η*(*C*), so that they both have consistent marginals at variables. Previous works on LP and SDP hierarchies [\[Gri01](#page-44-1), [Sch08,](#page--1-11) [Tul09](#page--1-12), [BGMT12](#page-43-2), [TW13](#page--1-13), [Cha16](#page-43-5), [BCK15,](#page-43-6) [MW16,](#page-44-2) [KMOW17\]](#page-44-0) constructed solutions whose distribution *η*(*C*) in each constraint is the given *τ* -wise uniform distribution. The only pairwise uniform distribution supported on 3-SAT is the uniform distribution on 3-XOR. In other words, previous LP and SDP hierarchy

<span id="page-1-0"></span><sup>3</sup> "Dual" means that the BW hierarchy has no solution if and only if bounded-width resolution refutation exists [[AD08,](#page-43-7) Theorem 2].

solutions strengthen every 3-SAT constraint into 3-XOR. However, the AIP algorithm can refute every unsatisfiable 3-XOR instance[[BG19](#page-43-8), [BGWŽ20\]](#page-43-9).

We overcome this hurdle and construct new LP and SDP solutions that have *full support*. As explained in [Section 1.2](#page-5-0), this allows us to construct LP solution and AIP solution separately, which can be combined into an LP+AIP solution. Our second main result, proved in [Section 12,](#page-33-0) gives LP+AIP lower bounds for a broad class of CSPs that include 3-SAT. In fact our lower bounds also hold for the stronger SDP+AIP hierarchy, which we introduce to generalize all the aforementioned hierarchies.

<span id="page-2-0"></span>**Theorem 1.2.** *Let τ* ⩾ 2*. If a k-CSP is τ -wise neutral for both SDP and AIP (separately), then except with probability on*;*k*(1)*, a random instance of the CSP with n variables and* ∆*n constraints has an SDP+AIP hierarchy solution of level* Ω*k*(*n/*(∆2*/*(*τ−*1) log ∆))*.*

*Remark* 1.3*.* Our lower bound of level in [Theorems 1.1](#page-1-1) and [1.2](#page-2-0) has the same dependency on *n* and ∆ as in [\[KMOW17,](#page-44-0) Theorem 7.1]. In particular, our lower bound matches the SDP level upper bounds for CSPs of Boolean predicates [\[AOW15](#page-43-10), [RRS17](#page-44-3), [Ahn20](#page-43-11)] up to polylogarithmic factors in *n*, for every *τ* ⩾ 2 and every ∆ = ∆(*n*), provided either ∆(*n*) is at least polylogarithmic in *n* [\[RRS17](#page-44-3)] or *τ* + 1 is even [[Ahn20\]](#page-43-11). See [\[KMOW17](#page-44-0), Section 1.5] for a discussion on the optimality of this bound.

Feige's Hypothesis [[Fei02,](#page-44-4) Hypothesis 1] says no sound polynomial-time algorithm refutes most 3-SAT instances at any constant constraint density ∆ (a refutation algorithm is *sound* if declares every satisfiable instance to be satisfiable). Many such algorithms, such as constant-level resolution [\[BSW01\]](#page-43-12) and SDP [\[Sch08](#page--1-11)], cannot refute most 3-SAT instances for any ∆(*n*) ⩽ *n* <sup>1</sup>*/*2*−o*(1), let alone constant ∆. It was unknown whether LP+AIP (with or without the hierarchy) refutes most 3-SAT instances at constant ∆; [Theorem 1.2](#page-2-0) now rules out this possibility. A similar Random Exponential Time Hypothesis of Razenshteyn, Song, and Woodruff [\[RSW16](#page-44-5), Assumption 1.3] states that sound algorithms refuting at least half of 4-SAT instances at constant ∆ must take exp(Ω∆(*n*)) time. Again, [Theorem 1.2](#page-2-0) lends weight to RSW's Hypothesis, by ruling out sublinear-level LP+AIP that runs in subexponential time. See [[KMOW17](#page-44-0), Section 1.2] and [\[RSW16](#page-44-5)] for the importance of these hypotheses and their applications to cryptography and learning theory.

Surprisingly, Feige, Kim, and Ofek [[FKO06\]](#page-44-6) showed that polynomial-time-verifiable refutation exists for most 3-SAT instances when ∆(*n*) = *O*(*n* 0*.*4 ), even though no polynomial-time algorithm is known to find their refutation. They combined spectral strong refutation for 3-NAE and parity strong refutation for 3-XOR. Are there better combinations of spectral/SDP and parity argument that disprove Feige's Hypothesis? We consider such a refutation based on the SDP+AIP hierarchy. [Theorem 1.2](#page-2-0) shows that constant-level SDP+AIP poses no harm to Feige's Hypothesis, and is fooled by most 3-SAT instances whenever ∆(*n*) ⩽ *n* <sup>1</sup>*/*2*−o*(1), just like the SDP hierarchy. This shows Feige–Kim–Ofek refutation cannot be captured by constant-level SDP+AIP.

Algorithms for CSPs, independently by Bulatov [[Bul17](#page-43-13), [Bul20\]](#page-43-14) and by Zhuk [[Zhu20](#page--1-14)], are intricate combinations of local consistency and Gaussian elimination, the two main techniques for CSPs. LP+AIP is a much simpler combination.

<span id="page-2-1"></span>**Question 1.4.** Can constant-level LP+AIP solve all tractable (i.e. polynomial-time solvable) CSPs?

<span id="page-2-2"></span>[Question 1.4](#page-2-1) was asked in [\[BGWŽ20](#page-43-9), Section 6] and [\[KO22](#page-44-7), Section 3]. Similar questions were also asked for two related relaxations: CLAP in [[CŽ22](#page-43-15)] and cohomological *k*-consistency in [\[Con22](#page-43-16), Question 13]. See also a related conjecture [[DO23](#page-44-8), Conjecture 4.10] about Z-affine *k*-consistency. Little was known about the limitation of combined relaxations and hierarchies; the only LP+AIP hierarchy lower bound was [\[CŽ23b\]](#page-43-17) for approximate graph coloring, a likely intractable problem due to *d*-to-1 hardness. [Theorem 1.2](#page-2-0) may make progress on [Question 1.4](#page-2-1), by giving LP+AIP hierarchy lower bounds to many CSPs, including plausibly tractable ones:

**Question 1.5.** Is there a tractable CSP pairwise neutral for both SDP and AIP but not trivially satisfiable by a single value?

If the answer to [Question 1.5](#page-2-2) is Yes, then the answer to [Question 1.4](#page-2-1) is No, by [Theorem 1.2](#page-2-0) and [Lemma B.3](#page-38-0). Even if the answer to [Question 1.5](#page-2-2) turns out to be No, we believe the question itself is a step towards understanding the power and limitation of combined hierarchies.

*Remark* 1.6*.* Our results also apply to PCSP, including many cases whose computational complexity is open. Consider the PCSP(**A***,* **B**) with relational structures **A***,* **B** such that **A** *→* **B** (see [\[KO22\]](#page-44-7) for the definitions). Suppose CSP(**A**) is pairwise neutral for both SDP and AIP, and CSP(**B**) is not trivially satisfiable by a single value. Then most instances of this PCSP have a linear level SDP+AIP lower bound at large enough constant constraint density, by [Theorem 1.2](#page-2-0) and [Lemma B.3.](#page-38-0)

*Remark* 1.7*.* Concurrently, Ciardo and Živný[[CŽ24](#page-43-18)] propose a new hierarchy called SDA combining SDP and AIP. SDA is equivalent to the SDP+AIP hierarchy introduced in this paper, up to a factor of two in level. [[CŽ24](#page-43-18)] prove constant-level worst-case lower bounds for approximate graph coloring and approximate graph homomorphism. Their results and ours are incomparable:

- *•* Their lower bounds are for constant level only. Ours are for linear level, which is optimal.
- *•* Their lower bounds are for the worst case. Ours are average-case, and hence also worst-case.
- *•* Our lower bounds apply to a class of CSPs that excludes approximate graph coloring or approximate graph homomorphism. Via reduction ([Appendix C](#page-40-0)), [Theorem 1.2](#page-2-0) implicitly implies lower bounds for *C*-vs-*K* graph coloring at other parameter regimes than theirs.

# <span id="page-3-1"></span>1.1. **Proof overview: First main theorem.**

We lay a common framework for proving lower bounds for various hierarchies. The framework consists of the following high-level steps: For each hierarchy,

- (A) Identify a subinstance *W<sup>S</sup>* for each small subset *S* of variables. Further show that *W<sup>S</sup>* is sparse and small on random instances.
- (B) Identify a property shared by certain "nice" CSPs, so that when restricted to any subset of *τ* variables of a constraint *C*, *C* enforce no constraints.
- (C) Using the property in (B), construct a local relaxed solution to *W<sup>S</sup>* for every *S*.
- (D) Again using the property in (B), combine the local solutions in (C) into a hierarchy solution. We now illustrate the above four steps using LP as an example.

Building on [\[BGMT12](#page-43-2), [TW13](#page--1-13), [MW16\]](#page-44-2), Kothari, Mori, O'Donnell, and Witmer [[KMOW17\]](#page-44-0) used *closure* [\(Definitions 5.1](#page-13-0) and [5.5](#page-14-0)) to track constraints in an instance that may affect the local LP solution to a subset *S* of variables. The closure of *S* is the subinstance *W<sup>S</sup>* in step (A) above.

**Example 1.8.** Consider a 3-XOR instance *I* with two constraints: an even parity constraint *C*<sup>1</sup> on *{v*1*, v*2*, v*3*}* and an odd parity constraint *C*<sup>2</sup> on *{v*3*, v*4*, v*5*}*. Naturally, the local distribution *η*(*C*) on each constraint *C* is the uniform distribution conditioned satisfying the constraint, e.g. *η*(*C*1) is the uniform distribution over even parity assignments on *{v*1*, v*2*, v*3*}*. As in previous works, the local LP solution to a small and sparse subinstance *J* is the canonical distribution ([Definition 10.2](#page-25-0)), where an assignment is independently drawn from a distribution *η*(*C*) for each constraint *C* in *J*, conditioned on agreement at common variables. The canonical distribution on *{C*1*, C*2*}* induces a nonuniform marginal distribution on *S* def = *{v*1*, v*2*, v*4*, v*5*}*, namely the uniform distribution over odd assignments to *S*. Therefore *C*<sup>1</sup> and *C*<sup>2</sup> are included in the closure of *S*, as they affect the local distribution on *S*, even though they involve variable(s) outside *S*.

<span id="page-3-0"></span>**Example 1.9.** Continuing with the previous example, add an extra even parity constraint *C*<sup>3</sup> on *{v*5*, v*6*, v*7*}* to *I*. The canonical distribution on *{C*1*, C*2*, C*3*}* induces the same marginal distribution on *S* = *{v*1*, v*2*, v*4*, v*5*}* as before. Therefore *C*<sup>3</sup> plays no role in the local distribution on *S* and is excluded from the closure of *S*.

As in Example 1.9, if a subinstance J has a constraint C having too many boundary variables (i.e. variables belonging to C but not other constraints in J) outside S, C does not belong to the closure of S. [KMOW17] defined closure to capture this intuition.

For step (B), the property of shared by a class of nice CSPs was identified in [BGMT12] to be pairwise uniform (and generalized to  $\tau$ -wise uniform in [KMOW17]).

For steps (C) and (D), constructing a hierarchy solution amounts to a *scheme*  $\sigma$  of assigning a distribution of satisfying assignments to every small and sparse subinstance J, so that  $\sigma$  is "compatible with closure" (Definition 5.7), which means J and the closure  $\operatorname{cl}_S(J)$  of S in J receive distributions with identical marginals on S:

$$\pi_S(\sigma(J)) = \pi_S(\sigma(\operatorname{cl}_S(J)))$$
 for variable subset S of subinstance J.

Here  $\pi_S$  means taking the marginal on S given a joint distribution of assignments. We can easily build a hierarchy solution s from a scheme  $\sigma$  compatible with closure: When defining the local distribution s(S) on S, take into account the constraints and variables in the local closure  $\operatorname{cl}_S^t(I)$  for S, and finally take the marginal on S given the distribution  $\sigma(\operatorname{cl}_S^t(I))$  of satisfying assignments to the closure. Therefore  $s(S) \stackrel{\text{def}}{=} \pi_S(\sigma(\operatorname{cl}_S^t(I)))$ . Compatibility with closure ensures our hierarchy solution is consistent with projection (Proposition 8.15), which is crucial for step (D).

Provided the CSP is  $\tau$ -wise uniform, a scheme  $\sigma$  compatible with closure can be built as follows [BGMT12, Lemma 3.2]: Starting with the null subinstance  $J_0$  (that has no variable), keep adding a constraint  $C_i$  in J to the current subinstance  $J_i$  iteratively for  $i=0,\ldots,|\mathcal{C}(J)|-1$ , such that  $C_i$  has at most  $\tau$  variables shared with previous constraints. At the same time, starting with a local solution  $\sigma(J_0)$  for the null subinstance, extend our current local solution  $\sigma(J_i)$  iteratively, until we have constructed the local solution  $\sigma(J)$  for the whole subinstance J (assuming J has no isolated variables). This works as long as J is small and sparse enough so that J can be decomposed in the said manner (Definition 5.6), completing step (C).

We apply the same framework to BW and AIP. For each hierarchy, we identify a class of "nice" CSPs from which a scheme can be built as above. We call such CSPs  $\tau$ -neutral (Definition 4.3). For BW, the definition of  $\tau$ -wise neutrality is hinted at in [CM13]: the set satisfying assignments R of each constraint needs to have full projection on any subset of  $\tau$  variables. For AIP, on the other hand, the correct definition is less obvious. We propose the following definition of  $\tau$ -wise neutral CSP for AIP:

For every k-ary constraint of the CSP with satisfying assignments  $R \subseteq D^k$ , every  $a \in D^k$ , some AIP solution  $w : R \to \mathbb{Z}$  supported on R has  $\pi_T(w) = \pi_T(\mathbb{1}_a)$  for every subset  $T \subseteq [k]$  of size at most  $\tau$ .

(Here D is the domain of the CSP.) Our definition is fairly general: it holds for CSPs whose satisfying assignments contain a Hamming ball of radius  $\tau$  (Proposition 4.5). This completes step (B).

Steps (A) and (D) are the same for BW, AIP, and LP. It remains to complete step (C) and come up with a scheme for each hierarchy. Devising a scheme for AIP (Section 7) is more challenging and requires more ideas than for BW (Section 6) or LP (Section 10), in part due to AIP lacking the convenient probabilistic interpretation of LP solutions.

Not every hierarchy lower bound technique falls into our framework. Previous BW/resolution lower bounds often used the subadditive complexity measure technique [BSW01]; our framework instead uses the closure and sparsity technique of [KMOW17] that also works for other hierarchies.

The above, together with previous SDP lower bounds, yields Theorem 1.1. This also easily implies lower bounds for random 4-SAT, because there is a pairwise uniform distribution supported on all satisfying assignments of 4-SAT, making 4-SAT pairwise neutral for SDP+AIP (Theorem 8.21). However, this simple approach falls short of SDP+AIP lower bounds for random 3-SAT, which is pairwise neutral for SDP and AIP separately but not pairwise neutral for SDP+AIP.

#### <span id="page-5-0"></span>1.2. Proof overview: Second main theorem.

SDP+AIP lower bounds for random 3-SAT calls for our second main result, based on new LP and SDP solutions with full support on small closures. More precisely, for every small subset K of variables, we construct an LP solution that has full support on all satisfying assignments of the K-closure (Definition 8.19). Such an LP solution imposes no additional constraint on the AIP solution, apart from the existing constraints in the instance (Lemma 8.20). This cleanly decouples our LP/SDP construction from the AIP construction, and is a significant departure from the symmetry-based LP+AIP construction in [CŽ23b].

To ensure full support, to every constraint C in the K-closure  $\mathcal{E} \stackrel{\text{def}}{=} \operatorname{cl}_K^t(\mathcal{C})$ , its distribution  $\eta^{\mathcal{E}}(C)$  is planted to be the uniform distribution over all satisfying assignments of C; and to every constraint C outside  $\mathcal{E}$ , its distribution  $\eta^{\mathcal{E}}(C)$  is the given  $\tau$ -wise uniform distribution. This yields a family  $\eta^{\mathcal{E}}$  of distributions of satisfying assignments (Definition 12.1). Constructing LP and SDP solutions based on  $\eta^{\mathcal{E}}$  calls for subtle changes to [BGMT12, KMOW17]: Because constraints C in  $\mathcal{E}$  can have distributions  $\eta^{\mathcal{E}}(C)$  that are not  $\tau$ -wise uniform (and may as well be 0-wise uniform), these constraints can also affect the local distribution on any subset S. We have to augment the closure of every S to take into account the constraints in  $\mathcal{E}$  when constructing the local distribution of S (Definition 9.1).

To ensure the distribution on an augmented closure J is well defined, every constraint C in J has to be satisfied by an assignment in the support  $\operatorname{supp}(\eta^{\mathcal{E}}(C))$  of  $\eta^{\mathcal{E}}(C)$  (Definition 10.3). Why are augmented closures satisfiable like that? The simple but crucial observation is that  $\operatorname{supp}(\eta^{\mathcal{E}}(C))$  is  $\tau$ -wise neutral for BW. Augmented closures are sparse enough to have a BW hierarchy solution, so they must be  $\eta^{\mathcal{E}}$ -satisfiable (Lemma 12.4). Compared with [BGMT12, KMOW17], our LP and SDP solutions gain full support, with their level halved only.

Along the way, we also simplify the SDP construction of [KMOW17]. SDP construction is more challenging than BW/LP/AIP because SDP vectors are more "global", and S-closure alone does not account for all constraints affecting the SDP vectors on a subset S. [KMOW17, Theorem 6.20] defined the witness of S for this purpose, i.e.  $W_S$  in step (A) of the above framework. Its complete definition depends on a multi-stage Gram–Schmidt procedure and is complicated. We instead work with ancestor closure (Section 11.1), a vast simplification of witness. Ancestor closure depends only on the underlying hypergraph of the instance, and not on any Gram–Schmidt procedure, e.g. not on any total ordering of variable subsets, or the constraints, or previous stages of the procedure. We believe our definition ancestor closure is the "right" one concerning SDP vectors coming from  $\tau$ -wise uniform CSPs.

We also replace the global Gram–Schmidt procedures in [BCK15, KMOW17] with a new orthogonal decomposition (Section 11.2), distilling [KMOW17] into its essence. Our decomposition is inspired by the Efron–Stein decomposition of functions on a product space. Our decomposition is also inspired by previous SDP vector decompositions for k-XOR [Gri01, Sch08] and pairwise uniform subgroups [Tul09, Cha16], generalizing them to  $\tau$ -wise uniform CSPs. Previous decompositions are based on equivalence classes of linear equations coming from the abelian group structure of the CSP predicate. The equivalence classes  $\Gamma$  in our decomposition are instead based on ancestor closures and do not require the group structure.

# 1.3. Paper organization.

We define all the hierarchies in Section 3, and the  $\tau$ -wise neutral conditions for each hierarchy in Section 4. Section 5 discusses two important concepts for our lower bounds: closure and scheme. Each hierarchy has its own section on the solution construction: BW in Section 6; AIP in Section 7; LP in Section 10; SDP in Section 11. Section 8 combines the results of previous sections and proves Theorem 1.1. Section 9 introduces the concept of augmented closure that is crucial for Theorem 1.2. Section 12 constructs SDP solutions with full support and proves Theorem 1.2.

## 2. Preliminaries

A set is r-small if it has at most r elements.  $\mathbb{N} \stackrel{\text{def}}{=} \{0, 1, 2, \dots\}$  denotes the set of natural numbers, and  $[k] \stackrel{\text{def}}{=} \{1, 2, \dots, k\}$ .

The notation  $o_{n;k}(1)$  represents a function  $\varepsilon_k(n)$  that, for every fixed k,  $\varepsilon_k(n) \to 0$  as  $n \to \infty$ . Given a function  $a: S \to D$ ,  $a_T: T \to D$  denotes its restriction to  $T \subseteq S$ .

The notation  $f:(x \in X) \to Y_x$  means that f is a dependent function mapping every  $x \in X$  to  $f(x) \in Y_x$ , where the codomain  $Y_x$  varies with x.

Given a subset  $S \subseteq V$  and assignment  $a \in D^S$ , denote by  $\mathbb{1}_a : D^V \to \mathbb{Z}$  the indicator function of a, defined as  $\mathbb{1}_a(b) = 1$  if  $b_S = a_S$ , and  $\mathbb{1}_a(b) = 0$  otherwise.

Given functions  $a: S \to D$  and  $b: T \to D$  defined on subsets  $S, T \subseteq V$  such that  $a_{S \cap T} = b_{S \cap T}$ ,  $(a \cup b)$  denotes the combined function:  $(a \cup b)(v) = a(v)$  if  $v \in S$ , and  $(a \cup b)(v) = b(v)$  if  $v \in T$ .

For simplicity, we consider only constraint satisfaction problems with k distinct variables per constraint (k-CSP). A constraint satisfaction problem is a pair  $(D, \mathfrak{R})$ . Its domain D is a nonempty finite set.  $\mathfrak{R}$  is a nonempty family of k-ary relations over D, i.e.  $R \subseteq D^k$  for every  $R \in \mathfrak{R}$ . An instance  $I = (V, \mathcal{C})$  of the CSP  $(D, \mathfrak{R})$  consists of a finite set V of variables and a finite set  $\mathcal{C}$  of constraints over V. Every constraint  $C \in \mathcal{C}$  is of the form C = (S, R), where the scope  $S \in V^k$  of C is a sequence of k distinct variables, and  $R \in \mathfrak{R}$  is the set of accepting assignments of C. We also write  $v \in C$  if variable v belongs to the scope of C.

A partial assignment  $a \in D^{V(C)}$  on a constraint C = (S,R) with scope  $S = (v_1,\ldots,v_k) \in V^k$  naturally corresponds to an assignment  $a' \in D^k$  via  $a' \stackrel{\text{def}}{=} a \circ S$ , that is,  $a'(i) = a(S(i)) = a(v_i)$  for  $i \in [k]$ . The set of satisfying assignments for C is  $A_C \stackrel{\text{def}}{=} \left\{ a \in D^{V(C)} \mid a \circ S \in R \right\}$ . An assignment  $a \in D^V$  satisfies a constraint C = (S,R) if  $a_{V(C)} \in A_C$ ; otherwise a violates C. An assignment  $a \in D^V$  satisfies a constraint set C or an instance I = (V,C) if a satisfies every constraint  $C \in C$ ; otherwise a violates C and C.

 $k ext{-SAT}$  is the CSP  $\left(\{0,1\},\left\{R_a\mid a\in\{0,1\}^k\right\}\right)$  where the relation  $R_a\stackrel{\text{def}}{=}\{0,1\}^k\setminus\{a\}$  forbids only the assignment a.  $k ext{-XOR}$  is the CSP  $(\{0,1\},\{R_{\text{even}},R_{\text{odd}}\})$ , where  $R_{\text{even}}$  (resp.  $R_{\text{odd}}$ ) consists of strings  $a\in\{0,1\}^k$  of even (resp. odd) parity.  $k ext{-NAE}$  is the CSP  $\left(\mathbb{Z}_2,\left\{R_a\mid a\in\mathbb{Z}_2^k\right\}\right)$ , where the relation  $R_a\stackrel{\text{def}}{=}\mathbb{Z}_2^k\setminus\{a,\overline{a}\}$  forbids only the assignment a and its ones' complement  $\overline{a}\stackrel{\text{def}}{=}a\oplus\mathbb{I}$ , and  $\mathbb{I}\in\{1\}^k$  is the all-one string.

A predicate CSP is a CSP whose domain D is an abelian group, and there is a set  $Q \subseteq D^k$  of assignments satisfying a predicate, such that  $\mathfrak{R} = \{Q + z \mid z \in D^k\}$ , i.e. each constraint is formed from any other by a shift. Examples of such CSPs are k-SAT, k-XOR, and k-NAE.

#### 3. Hierarchy

<span id="page-6-0"></span>In this section, we formally define all the hierarchies in this paper.

#### 3.1. Relaxed domain.

Let us define a common generalization of the following four hierarchies: bounded width (BW), linear program (LP), semidefinite program (SDP), and affine integer program (AIP).

Given a CSP with domain D and an instance  $I = (V, \mathcal{C})$  of the CSP, a hierarchy is a collection  $(\mathcal{D}_S)_S$  of sets, one for each d-small variable subset  $S \subseteq V$ .  $\mathcal{D}_S$  is the relaxed domain or the set of relaxed assignments on S, and varies across hierarchies.

 $A_S \subseteq D^S$  denotes the set of partial assignments on S that satisfy all constraints in I contained in S, where a constraint  $C \in \mathcal{C}$  is contained in S if every variable of C belongs to S.

We now define the relaxed domain  $\mathcal{D}_S$  of each elementary hierarchy on a subset  $S \subseteq V$  of variables.

**BW:**  $\mathcal{D}_S^{\mathrm{BW}} \stackrel{\mathrm{def}}{=} \mathcal{P}(A_S) \setminus \{\emptyset\}$ , the family of nonempty subsets over  $A_S$ ; see e.g. [AD08, Definition 1]. The bounded width hierarchy is also called existential k-pebble game or k-strategy and is "dual" to bounded-width resolution refutation [AD08, Theorem 2].

**LP:**  $\mathcal{D}_S^{\mathrm{LP}} \stackrel{\mathrm{def}}{=} \Delta(A_S)$ , the set of distributions over  $A_S$  [BGMT12, Lemma 2.3]. The LP hierarchy is known as the Sherali–Adams hierarchy.

**SDP:**  $\mathcal{D}_S^{\text{SDP}} \stackrel{\text{def}}{=} \mathcal{X}^{A_S}$ , the set of functions from  $A_S$  to an arbitrary inner product space  $\mathcal{X}$ . Further, the SDP vectors induce distributions  $\mu_R \in \Delta(A_R)$  for 2d-smalls subsets  $R \subseteq V$ , so that for any d-small  $S, T \subseteq V$ , any  $\alpha_S \in \mathcal{D}_S^{\text{SDP}}$ ,  $\alpha_T \in \mathcal{D}_T^{\text{SDP}}$ ,  $a_S \in A_S$ ,  $a_T \in A_T$ ,

(1) 
$$\langle \alpha_S(a_S), \alpha_T(a_T) \rangle_{\mathcal{X}} = \underset{b \sim \mu_{S \cap T}}{\mathbb{P}} [b_S = a_S, b_T = a_T].$$

<span id="page-7-2"></span>This combined vector program and LP formulation is [Tul09, Section 2.3]. It is equivalent to the formulation of pseudo-expectation/moment matrix in [KMOW17, Definition 2.7]. The SDP hierarchy is also known as the Lasserre hierarchy and its Lagrangian dual as the sum-of-squares hierarchy; see e.g. [Lau09, Section 6].

**AIP:**  $\mathcal{D}_S^{\text{AIP}} \stackrel{\text{def}}{=} \left\{ w : A_S \to \mathbb{Z} \; \middle| \; \sum_{a \in A_S} w(a) = 1 \right\}$ , containing affine integer weights supported on  $A_S$ . Our definition here is different from [CŽ23a, CŽ23c]; see Remark 3.2.

## 3.2. Projection of relaxed assignment.

For each hierarchy, we consider a relaxed assignment  $\alpha_S \in \mathcal{D}_S$  to be a function from the set of satisfying assignments  $A_S$  on S to a commutative monoid  $\mathcal{M}$  (so that addition is defined). In each of the elementary hierarchy (BW/LP/AIP) except SDP,  $\mathcal{M}$  is additionally a commutative semiring (so that multiplication is also defined).

**BW:**  $\mathcal{M}_{\mathrm{BW}} \stackrel{\mathrm{def}}{=} \mathbb{B}$ . The Boolean algebra  $\mathbb{B}$  has join  $\vee$  as the addition and meet  $\wedge$  as the multiplication. A set  $\alpha_S \in \mathcal{P}(A_S)$  is represented by its indicator function  $\mathbb{1}_{\alpha_S} : A_S \to \mathbb{B}$ , so that  $\mathbb{1}_{\alpha_S}(a) = 1$  if  $a \in \alpha_S$ , and  $\mathbb{1}_{\alpha_S}(a) = 0$  otherwise.

**LP:**  $\mathcal{M}_{LP} \stackrel{\text{def}}{=} \mathbb{R}_+$ , the nonnegative reals.

SDP:  $\mathcal{M}_{\text{SDP}} \stackrel{\text{def}}{=} \mathcal{X}$ .
AIP:  $\mathcal{M}_{\text{AIP}} \stackrel{\text{def}}{=} \mathbb{Z}$ .

<span id="page-7-0"></span>

For any subsets  $T \subseteq S \subseteq V$ , there is a projection  $\pi_{S \to T} : \mathcal{M}^{D^S} \to \mathcal{M}^{D^T}$  of functions taking values in  $\mathcal{M}$ :

(2) 
$$\pi_{S \to T}(\alpha_S)(b) \stackrel{\text{def}}{=} \sum_{\substack{a \in D^S \\ a_T = b}} \alpha_S(a) \quad \text{for } \alpha_S \in \mathcal{M}^{D^S}, b \in D^T.$$

Here the sum is over  $\mathcal{M}$ .

If  $\alpha_S: A \to \mathcal{M}$  is a function from  $A \subseteq D^S$ , we also think of it as a function  $\alpha_S: D_S \to \mathcal{M}$  from  $D_S$  supported on A:

(3) 
$$\alpha_S(b) = 0 \quad \text{for } b \in D^S \setminus A.$$

Here 0 denotes the additive identity of the commutative monoid  $\mathcal{M}$ . Given any  $\alpha: X \to \mathcal{M}$ , denote by  $\operatorname{supp}(\alpha) \stackrel{\text{def}}{=} \{x \in X \mid \alpha(x) \neq 0\}$  the support of  $\alpha$ .

<span id="page-7-3"></span>Eq. (2) immediately implies that projection commutes with addition:

(4) 
$$\pi_{S \to T}(\alpha_S + \beta_S) = \pi_{S \to T}(\alpha_S) + \pi_{S \to T}(\beta_S) \quad \text{for any } \alpha_S, \beta_S \in \mathcal{M}^{D^S}.$$

It is also easy to verify that composition of compatible projections is a projection:

(5) 
$$\pi_{S \to R} = \pi_{T \to R} \circ \pi_{S \to T} \quad \text{for any } R \subseteq T \subseteq S.$$

We sometimes abbreviate  $\pi_{S\to T}$  as  $\pi_T$  when S is clear from the context.

<span id="page-7-4"></span><span id="page-7-1"></span>Let  $\mathcal{S}_d \stackrel{\text{def}}{=} \binom{V}{\leq d}$  be the family of d-small variable subsets.

**Definition 3.1.** A level-d hierarchy solution is a dependent function  $s:(S \in \mathcal{S}_d) \to \mathcal{D}_S$  that is consistent with projection:

$$s(T) = \pi_{S \to T}(s(S))$$
 for every  $T \subseteq S \subseteq V, |S| \leqslant d$ .

Every satisfiable instance has a level-|V| hierarchy solution in each of the elementary hierarchy. Indeed, if  $a:V\to D$  is a satisfying assignment, then  $S\mapsto \mathbb{1}_{a_S}$  is a hierarchy solution for BW, LP, and AIP. Fixing an arbitrary unit vector v in an inner product space  $\mathcal{X}$ , the functions  $\alpha_S(a) \stackrel{\text{def}}{=} \mathbb{1}_{a_S} v$  for  $S\subseteq V, a\in D^S$  also form an SDP hierarchy solution.

<span id="page-8-0"></span>Remark 3.2. Ciardo and Živný [CŽ23a, CŽ23c] initiated the study of the AIP hierarchy. They defined AIP hierarchy differently [CŽ23a, Section 2]: Their relaxed domain is

$$\mathcal{D}_S^{\mathrm{C}\check{\mathrm{Z}}} \stackrel{\mathrm{def}}{=} \left\{ w : D^S \to \mathbb{Z} \;\middle|\; \sum_{a \in D^S} w(a) = 1 \right\},$$

the set of affine integer weights on  $D^S$  that need not be supported on satisfying assignments in  $A_S$  for a general S. They only require that for every constraint  $C \in \mathcal{C}$ , every integer weight  $w \in \mathcal{D}_{V(C)}^{C\check{\mathbf{Z}}}$  on V(C) is supported on satisfying assignments of C.

Their AIP hierarchy is strictly weaker than ours when the level d is at least the arity k of the CSP, because any solution to our AIP hierarchy is also a solution to theirs, but not the other way round. All the hierarchies in this paper are refutation-complete at level d = |V|, so that every unsatisfiable instance has no level-|V| hierarchy solution. Their AIP hierarchy lacks refutation-completeness, even when  $d \ge |V|$  [CŽ23a, Theorem 1].

In the terminology of [CŽ23c, Definition 20], our hierarchies are all *conic*, while their AIP hierarchy is not [CŽ23c, Proposition 21]. For consistency with other hierarchies in this paper, our AIP hierarchy does not follow their definition. In any case, when  $d \ge k$ , lower bounds to our AIP hierarchy imply lower bounds to their AIP hierarchy.

The LP and SDP hierarchies are often expressed as a maximization problem with an objective value being the number or fraction of constraints satisfied; see e.g. [BGMT12, Section 2.3] and [Tul09, Section 2.3]. When the objective value is the fraction of constraints satisfied, having an LP or SDP hierarchy solution (Definition 3.1) is equivalent to the LP or SDP value being 1.

Our definitions of hierarchies may differ from those in other works when level d is less than constraint arity k, in which case our hierarchies are all trivial and need not satisfy any constraint. This difference is inessential because our focus is super-constant level lower bounds, in particular  $d \ge k$  and our definitions agree with (or is stronger than) other works'.

Each of the elementary hierarchy except SDP can be solved in  $(|V||D|)^{O(d)}$  time, which is polynomial when d is a constant:

**BW:** A solution can be found by the local consistency algorithm [BK09, paragraph after Definition 3.3].

**LP:** This corresponds to a linear program with  $(|V||D|)^{O(d)}$  variables and inequalities and can be solved in the aforementioned time. [Sch86, Theorem 13.4]

**AIP:** This corresponds to an integer program with  $(|V||D|)^{O(d)}$  variables and equalities and can be solved in the aforementioned time. [Sch86, Corollary 5.3b]

No polynomial-time algorithm is known to find an exact solution to the SDP hierarchy. Deciding the feasibility of the SDP hierarchy is a special case of the SDP feasibility problem, whose complexity is still open. Often an SDP solution that is approximately feasible (i.e. having small but positive probabilities on assignments that violate some constraints) and approximately optimal is enough for approximation algorithms. Such an approximate solution can be found in  $O(|V||D|)^{O(d)}$  time because the SDP hierarchy is a semidefinite program with  $(|V||D|)^{O(d)}$  variables and inequalities with the aforementioned bit-complexity [RW17, Theorem 4.1 and Corollary 3.5]; see also [O'D17] which points out the subtlety of bit-complexity. A few level-d SDP hierarchy approximation algorithms,

such as finding a large independent set in a 3-colorable graph with a certain spectral profile, can be implemented in  $poly(|V|, |D|)2^{O(d)}$  time [GS12], which is polynomial whenever  $d = O(\log |V|)$ .

## 3.3. Nontriviality.

Instead of taking values in  $\mathcal{D}_S$ , it is more convenient to define a hierarchy solution as a dependent function  $s:(S \in \mathcal{S}_d) \to \mathcal{M}^{A_S}$  taking values in the superset  $\mathcal{M}^{A_S} \supseteq \mathcal{D}_S$ , so that s satisfies an additional nontriviality condition. Note that when s(S) takes values in  $\mathcal{M}^{A_S}$ , the constant-zero function  $s(S)(a) \stackrel{\text{def}}{=} 0 \in \mathcal{M}$  for  $a \in A_S$ ,  $S \in \mathcal{S}_d$ , is trivially consistent with projection. The nontriviality condition is meant to rule out this invalid hierarchy solution.

Recall that the set  $D^{\emptyset}$  contains a unique assignment, known as the empty function, which we will denote by  $\mathbb{O}$ . Also  $A_{\emptyset} = D^{\emptyset} = \{\mathbb{O}\}$ , as there is no constraint contained in  $\emptyset$  that  $\mathbb{O}$  can violate.

The nontriviality condition says that  $s(\emptyset)(\mathbb{O})$  equals 1, the multiplicative identity of the commutative semiring  $\mathcal{M}$ . More explicitly, the nontriviality constraint for each elementary hierarchy is:

**BW:**  $s(\emptyset) = \{0\}.$ 

**LP:**  $s(\emptyset)(0) = 1$ .

**SDP:** SDP inherits the nontriviality condition from the induced LP solution. By Eq. (1), the LP nontriviality is equivalent to the unit length condition  $||s(\emptyset)(\mathbb{O})|| = 1$  in previous works such as [Tul09, Section 2.3].

**AIP:**  $s(\emptyset)(0) = 1$ .

The nontriviality condition can be written succinctly as  $s(\emptyset) = \mathbb{1}_{\mathbb{O}}$ .

<span id="page-9-0"></span>**Lemma 3.3.** For each elementary hierarchy except SDP, a dependent function  $s: (S \in \mathcal{S}_d) \to \mathcal{M}^{A_S}$  that is consistent with projection and satisfies the nontriviality condition is a hierarchy solution (i.e. takes values in  $\mathcal{D}_S$ ).

*Proof.* Since s is consistent with projection, for any  $S \in \mathcal{S}_d$ , s(S) sums to 1, i.e.,  $\sum_{a \in A_S} s(S)(a) = s(\emptyset)(0) = 1$ . This in turn is equivalent to the following statements:

**BW:** s(S) is the indicator function of a nonempty subset of  $A_S$ .

**LP:** s(S) is the probability mass function of a distribution over  $A_S$ .

**AIP:** s(S) satisfies the affine constraint  $\sum_{a \in A_S} s(S)(a) = 1$ .

## 3.4. Combined hierarchy.

Starting with [BGWŽ20], a number of hierarchies were proposed by combining the elementary ones (BW, LP, SDP, and AIP). Each combined hierarchy strengthens AIP by requiring its solution to be contained in the support of the solution of some other hierarchy.

**LP+AIP:** The LP+AIP relaxation was introduced in [BGWŽ20]; see also [BG19]. The LP+AIP hierarchy was formally defined in [CŽ23b, Section 3.2]. In this hierarchy, the relaxed domain for d-small  $S \subseteq V$  is

$$\mathcal{D}_S^{\mathrm{LP}+\mathrm{AIP}} \stackrel{\mathrm{def}}{=} \left\{ (\mu_S, w_S) \in \mathcal{D}_S^{\mathrm{LP}} \times \mathcal{D}_S^{\mathrm{AIP}} \; \middle| \; \mathrm{supp}(\mu_S) \supseteq \mathrm{supp}(w_S) \right\}.$$

The commutative semiring  $\mathcal{M}_{LP+AIP}$  is the direct product  $\mathcal{M}_{LP} \times \mathcal{M}_{AIP}$ .

**BW+AIP:** The BW+AIP hierarchy was introduced by Dalmau and Opršal [DO23] as the  $\mathbb{Z}$ -affine k-consistency hierarchy. In this hierarchy, the relaxed domain for d-small  $S \subseteq V$  is

$$\mathcal{D}_S^{\mathrm{BW} + \mathrm{AIP}} \stackrel{\mathrm{def}}{=} \left\{ (\alpha_S, w_S) \in \mathcal{D}_S^{\mathrm{BW}} \times \mathcal{D}_S^{\mathrm{AIP}} \; \middle| \; \mathrm{supp}(\alpha_S) \supseteq \mathrm{supp}(w_S) \right\}.$$

**SDP+AIP:** The SDP+AIP hierarchy is introduced in this paper, and is equivalent to the SDA hierarchy in [CŽ24]. For every d-small  $S \subseteq V$ , there is  $\alpha_S \in \mathcal{D}_S^{\text{SDP}}$ , and for every 2d-small  $R \subseteq V$ , there is  $(\mu_R, w_R) \in \mathcal{D}_R^{\text{LP+AIP}}$ , so that  $(\alpha_S)_S$  induces  $(\mu_R)_R$  as in Eq. (1).

Even though our AIP hierarchy is stronger than the AIP hierarchy in  $[C\check{Z}23a, C\check{Z}23c]$  when  $d \geqslant k$  (Remark 3.2), our LP+AIP hierarchy is equivalent to the LP+AIP hierarchy in  $[C\check{Z}23b, Section 3.2]$  when  $d \geqslant k$ . The LP+AIP hierarchy can be solved in  $O(|V||D|)^{O(d)}$  time  $[C\check{Z}23b, Section 3.2]$  by first finding a solution in the relative interior of the LP hierarchy, and then solving the AIP hierarchy with the support restricted to that of the LP solution.

By contrast, we do not know how to solve the SDP+AIP hierarchy efficiently, because finding an exact solution in the relative interior of an SDP is harder than the SDP feasibility problem. Even though a polynomial-time algorithm for SDP+AIP or finding a refutation is not known (due to the SDP feasibility obstacle), a refutation for SDP+AIP that can be verified in  $O(|V||D|)^{O(d)}$  time may sometimes exist.

One possible refutation consists of a certificate for the "support" Z of the SDP hierarchy. The "support"  $Z:(S \in \mathcal{S}_{2d}) \to A_S$  represents local assignments not ruled out by the SDP hierarchy, and is defined for 2d-small  $T \subseteq V$  to be

$$Z(T) \stackrel{\text{def}}{=} \left\{ a \in D^T \;\middle|\; \mu_T(a) > 0 \text{ for some LP solution } (\mu_R)_R \text{ induced by some SDP solution} \right\}.$$

A possible certificate for the support Z consists of, for each 2d-small  $T \subseteq V$  and  $a \in D^T \setminus Z(T)$ , a sum-of-squares proof showing  $\mu_T(a) \leq 0$  for every LP solution induced by any SDP solution. Finally, the AIP algorithm can further certify that no AIP solution supported on Z exists.

The SDP+AIP hierarchy is a common generalization of all other hierarchies in this section, and is at least as strong as any one of them. Lower bounds for SDP+AIP unify and imply lower bounds for all these hierarchies.

4. 
$$\tau$$
-WISE NEUTRAL CSP

<span id="page-10-0"></span>In this section, we define  $\tau$ -wise neutrality for each hierarchy. As mentioned in Section 1.1, this concept is meant the capture the notion that a constraint C appears to the hierarchy to enforce no constraints on subsets of at most  $\tau$  variables in C. In Section 4.3 we further discuss  $\tau$ -wise neutrality for AIP.

# 4.1. Neutral solution.

Each elementary hierarchy except SDP comes with a natural way to combine  $\alpha_S: D^S \to \mathcal{M}$  and  $\alpha_T: D^T \to \mathcal{M}$  defined on disjoint variable subsets S and T into their product  $\alpha_S \otimes \alpha_T: D^{S \cup T} \to \mathcal{M}$ . This is simply the tensor product  $\otimes: \mathcal{M}^{D^S} \times \mathcal{M}^{D^T} \to \mathcal{M}^{D^{S \cup T}}$  of appropriate functions taking values in a commutative semiring  $\mathcal{M}$ :

(6) 
$$(u \otimes v)(a,b) \stackrel{\text{def}}{=} u(a)v(b) \quad \text{for } (a,b) \in D^S \times D^T \cong D^{S \cup T}.$$

Here the multiplication is over  $\mathcal{M}$ . More explicitly, the tensor product for each hierarchy is:

<span id="page-10-2"></span>**BW:**  $\otimes_{\mathrm{BW}} \stackrel{\mathrm{def}}{=} \otimes_{\mathbb{B}}$ .

**LP:**  $\otimes_{\text{LP}} \stackrel{\text{def}}{=} \otimes_{\mathbb{R}_+}$ . Note that  $\alpha_S \otimes_{\mathbb{R}_+} \alpha_T$  is the product distribution of  $\alpha_S$  and  $\alpha_T$  in the usual sense of probability theory, i.e. sampling from  $\alpha_S$  and  $\alpha_T$  independently.

**AIP:**  $\otimes_{AIP} \stackrel{\text{def}}{=} \otimes_{\mathbb{Z}}$ .

To construct a solution fooling a hierarchy, first fix a neutral solution  $\nu$  mapping every  $v \in V$  to  $\nu(v) \in \mathcal{D}_{\{v\}}$ . Then lift  $\nu(v)$  to a relaxed assignment  $\nu^S$  on every subset  $S \subseteq V$  by

(7) 
$$\nu^S \stackrel{\text{def}}{=} \bigotimes_{v \in S} \nu(v).$$

We now define a neutral solution  $\nu:(v\in V)\to\mathcal{D}_{\{v\}}$  for each hierarchy except SDP.

<span id="page-10-1"></span>**BW:**  $\nu_{\text{BW}}(v) \stackrel{\text{def}}{=} D^{\{v\}}$ , the set of functions from  $\{v\}$  to D.

**LP:**  $\nu_{\text{LP}}(v)$  is the uniform distribution over  $D^{\{v\}}$ .

**AIP:** First fix an assignment  $a: V \to D$  (such as assigning an arbitrary fixed element  $0 \in D$  to every variable). Then  $\nu_{AIP}(v) = \mathbb{1}_{a_v}$ . In other words,  $\nu_{AIP}(v)$  assigns weight 1 to the partial assignment  $v \mapsto a(v)$  and weight 0 to every other partial assignment on  $\{v\}$ .

Consequently, the lifted relaxed assignment  $\nu^S$  for any  $S \subseteq V$  will be:

**BW:**  $\nu_{\rm BW}^S = D^S$ .

**LP:**  $\nu_{\text{LP}}^{S}$  is the uniform distribution over the set  $D^S$  of all assignments from S to D.

**AIP:** if  $\nu_{\text{AIP}}$  is the neutral solution with respect to  $a: V \to D$ , then  $\nu_{\text{AIP}}^S = \mathbb{1}_{a_S}$ , i.e.  $\nu_{\text{AIP}}^S$  assigns weight 1 to  $a_S$  and weight 0 to every other partial assignment on S.

The function  $S \mapsto \nu^S$  is a solution to the hierarchy if I is the empty instance containing no constraint, but not in general if I contains some constraints.

#### <span id="page-11-3"></span>4.2. $\tau$ -wise neutral CSP.

**Definition 4.1.** Given a neutral solution  $\nu: (v \in [k]) \to \mathcal{D}_{\{v\}}$  and a natural number  $\tau \in \mathbb{N}$ , a relaxed assignment  $\alpha: D^k \to \mathcal{M}$  is  $\tau$ -wise  $\nu$ -neutral if  $\tau \leqslant k$  and

(8) 
$$\pi_{V \to T}(\alpha) = \nu^T \text{ for every } \tau\text{-small } T \subseteq [k].$$

Note that a  $\tau$ -wise  $\nu$ -neutral relaxed assignment  $\alpha$  is necessarily nontrivial:

<span id="page-11-2"></span>
$$\pi_{[k]\to\emptyset}(\alpha) \stackrel{(8)}{=} \nu^{\emptyset} \stackrel{(7)}{=} \mathbb{1}_{\mathbb{0}}.$$

**Definition 4.2.** A k-CSP  $(D, \mathfrak{R})$  is  $\tau$ -wise  $\nu$ -neutral if every relation  $R \in \mathfrak{R}$  has a  $\tau$ -wise  $\nu$ -neutral relaxed assignment  $\alpha^R : D^k \to \mathcal{M}$  supported on R.

A  $\tau$ -wise  $\nu$ -neutral CSP is called as such because the neutral solution  $\nu$  is independent of (i.e. neutral to) the choice of the set R of satisfying assignments in a constraint.

<span id="page-11-0"></span>**Definition 4.3.** For each elementary hierarchy, a k-CSP is  $\tau$ -wise neutral if the CSP is:

**BW:**  $\tau$ -wise  $\nu$ -neutral for  $\nu = v \mapsto D^{\{v\}}$ .

**LP:**  $\tau$ -wise  $\nu$ -neutral, where  $\nu(v)$  is the uniform distribution on  $D^{\{v\}}$  for every v. Such a CSP is also known as  $\tau$ -wise uniform (or  $\tau$ -wise independent in some earlier works).

**SDP:**  $\tau$ -wise neutral in the LP sense.

**AIP:**  $\tau$ -wise  $\nu_a$ -neutral for every  $a \in D^k$ , where  $\nu_a \stackrel{\text{def}}{=} v \mapsto \mathbb{1}_{a_v}$ . (We also write  $\tau$ -wise  $\nu_a$ -neutral as  $\tau$ -wise  $\mathbb{1}_a$ -neutral.)

In the previous definition, AIP is somewhat unusual. For other hierarchies,  $\tau$ -wise neutrality means  $\tau$ -wise  $\nu$ -neutral for one specific  $\nu$ ; but for AIP, it requires a collection of  $\nu$ 's. We will need a full collection of  $\nu$ 's to construct the AIP solution later.

A CSP is  $\tau$ -wise neutral for LP+AIP if it is  $\tau$ -wise  $(\nu_{LP}, \mathbb{1}_a)$ -neutral for every  $a \in D^k$ . In other words, every relation R of the CSP supports a  $\tau$ -wise uniform distribution  $\mu^R$  of satisfying assignments, and there is a  $\tau$ -wise  $\mathbb{1}_a$ -neutral AIP relaxed assignment supported on supp $(\mu^R)$  for every  $a \in D^k$ . If a CSP is  $\tau$ -wise neutral for LP+AIP, we also say that it is  $\tau$ -wise neutral for SDP+AIP.

#### <span id="page-11-1"></span>4.3. $\tau$ -wise neutral CSP for AIP.

In this subsection, we give examples of CSPs that are  $\tau$ -wise neutral for AIP. We first show that k-SAT is  $\tau$ -wise neutral for AIP.

Given  $S \subseteq V$ , the parity function  $\chi_S : \{0,1\}^V \to \{+1,-1\} \subseteq \mathbb{Z}$  is defined as follows:  $\chi_S(x) = +1$  if  $x_S$  has an even number of 1's; and  $\chi_S(x) = -1$  if  $x_S$  has an odd number of 1's.

<span id="page-11-4"></span>**Proposition 4.4.** k-SAT is (k-1)-wise neutral for AIP for every  $k \ge 1$ .

*Proof.* Consider the set  $R = \{0,1\}^k \setminus \{b\}$  of satisfying assignments of a k-SAT constraint that forbids  $b \in \{0,1\}^k$ . We now show that every  $a \in \{0,1\}^k$  has a (k-1)-wise  $\mathbb{1}_a$ -neutral relaxed assignment  $\alpha_a : D^k \to \mathbb{Z}$  supported on R.

If  $a \neq b$ , then  $\alpha_a \stackrel{\text{def}}{=} \mathbb{1}_a$  works. Otherwise a = b, and the relaxed assignment  $\alpha_a \stackrel{\text{def}}{=} \mathbb{1}_b - \chi_{[k]}(b)\chi_{[k]}$  works. Indeed, this  $\alpha_a$  is supported on R because  $\alpha_a(b) = \mathbb{1}_b(b) - \chi_{[k]}(b)\chi_{[k]}(b) = 1 - 1 = 0$ . This  $\alpha_a$  is also (k-1)-wise  $\mathbb{1}_a$ -neutral, because  $\pi_T(\chi_{[k]}) \equiv 0$  for (k-1)-small  $T \subseteq [k]$  by Proposition A.2.  $\square$ 

Is there a simple sufficient condition for a CSP to be  $\tau$ -wise neutral for each hierarchy? For BW, the necessary and sufficient is easy to find (Proposition 6.1). For LP and SDP, the necessary and sufficient condition is well known [AH11, Lemma 3.1]. For AIP, we now give a simple sufficient condition for a CSP to be  $\tau$ -wise neutral: every relation contains a Hamming ball of radius  $\tau$ .

<span id="page-12-0"></span>**Proposition 4.5.** Suppose every  $R \in \mathfrak{R}$  contains some Hamming ball  $B(c_R, \tau)$  of radius  $\tau$  around  $c_R \in D^k$ , where  $B(a, \tau) \stackrel{\text{def}}{=} \{b \in D^k \mid d(a, b) \leqslant \tau\}$  and  $d(a, b) \stackrel{\text{def}}{=} |\{i \in [k] \mid a_i \neq b_i\}|$  is the Hamming distance. Then the k-CSP  $(D, \mathfrak{R})$  is  $\tau$ -wise neutral for AIP.

*Proof.* Fix any center  $c \in D^k$  of a Hamming ball  $B(c,\tau)$ . For  $a \in D^k$ , we construct by induction on d(c,a) a  $\tau$ -wise  $\mathbbm{1}_a$ -neutral relaxed assignment  $\alpha_a$  supported on  $B(c,\tau)$ .

Base Case:  $d(c,a) \leq \tau$ . Then  $\alpha_a \stackrel{\text{def}}{=} \mathbb{1}_a$  is supported on  $\{a\} \subseteq B(c,\tau)$  and is  $\tau$ -wise  $\mathbb{1}_a$ -neutral. Induction Step:  $d(c,a) > \tau$ . Let  $Q(c,a) \stackrel{\text{def}}{=} \{b \in D^k \mid b_i \in \{a_i,c_i\} \text{ for every } i \in [k]\}$ . Define the generalized parity function  $\underline{\chi}: Q(c,a) \to \{+1,-1\} \subseteq \mathbb{Z}$  as follows:  $\underline{\chi}(b) = +1$  if d(a,b) is even; and  $\chi(b) = -1$  if d(a,b) is odd. Consider the relaxed assignment

$$\alpha_a \stackrel{\text{def}}{=} -\sum_{b \in Q(c,a) \setminus \{a\}} \underline{\chi}(b) \alpha_b.$$

Every  $b \in Q(c, a) \setminus \{a\}$  has d(c, b) < d(c, a), so every  $\alpha_b$  is supported on  $B(c, \tau)$  by Induction Hypothesis, and therefore so is  $\alpha_a$ .

Finally, for any  $\tau$ -small  $T \subseteq [k]$ , we now verify that  $\pi_T(\alpha_a) = \mathbb{1}_{a_T}$ . Indeed,

$$\pi_T(\alpha_a) \stackrel{(4)}{=} - \sum_{b \in Q(c,a) \setminus \{a\}} \underline{\chi}(b) \pi_T(\alpha_b) \stackrel{\text{I.H.}}{=} - \sum_{b \in Q(c,a) \setminus \{a\}} \underline{\chi}(b) \mathbb{1}_{b_T}$$

$$\stackrel{(*)}{=} \mathbb{1}_{a_T} - \sum_{b \in Q(c,a)} \underline{\chi}(b) \mathbb{1}_{b_T} = \mathbb{1}_{a_T} - \sum_{b' \in \pi_T(Q(c,a))} \pi_T(\underline{\chi})(b') \mathbb{1}_{b'},$$

where (\*) uses  $\underline{\chi}(a) = 1$ . Let  $S \stackrel{\text{def}}{=} \{i \in [k] \mid a_i \neq c_i\}$ . Since  $|S| = d(c, a) > \tau$  and T is  $\tau$ -small,  $S \setminus T \neq \emptyset$ . It remains to show that  $\pi_T(\underline{\chi})(b') = 0$  for any  $b' \in \pi_T(Q(a, c))$ . This holds because extensions  $b \in Q(c, a)$  of b' correspond to choosing  $b_i \in \{a_i, c_i\}$  for  $i \in S \setminus T$ , and half of these extensions have even d(a, b) and  $\chi(b) = 1$ , while the other half have odd d(a, b) and  $\chi(b) = -1$ .  $\square$ 

How few satisfying assignments can there be in the relations R of a  $\tau$ -wise neutral CSP for each hierarchy? For LP and SDP, Austrin and Håstad [AH11, Theorems 1.1 and 1.2] showed that for every  $\tau \geqslant 2$ , most k-ary relations  $R \in \binom{D^k}{t}$  are  $\tau$ -wise uniform for some  $t \lesssim_{|D|,\tau} k^{\tau} \log k$ , and the  $\log k$  factor can be avoided when  $\tau = 2$ . For AIP, Proposition 4.5 above implies that some relation  $R \in \binom{D^k}{t}$  is  $\tau$ -wise neutral for AIP when  $t \lesssim_{|D|,\tau} k^{\tau}$ , similar to Austrin and Håstad's bound for LP and SDP.

We also have examples of CSPs over  $D = \{0,1\}$  that are pairwise neutral for AIP without containing any Hamming ball of radius 2, but not included in this paper.

#### 5. Closure and scheme

## <span id="page-13-1"></span>5.1. Closure.

Following [BGMT12, KMOW17], we define S-closure to track constraints affecting the relaxed assignment on a variable subset S. Our definition is almost identical to [KMOW17, Definition 5.3], which in turn is a simplification of advice set in [BGMT12, Section 3.1]. The closure as defined in [KMOW17] will be called *local closure* instead in this work (Definition 8.7).

Given a constraint set  $\mathcal{C}$ , denote by  $V(\mathcal{C}) \stackrel{\text{def}}{=} \{v \in V \mid v \in C \text{ for some } C \in \mathcal{C}\}$  its variable set. Its boundary  $B(\mathcal{C})$  is the set of its variables that belong to a unique constraint in  $\mathcal{C}$ :

$$B(\mathcal{C}) \stackrel{\text{def}}{=} \{ v \in V(\mathcal{C}) \mid v \text{ belongs to a unique } C \in \mathcal{C} \}.$$

Denote by  $\overline{B}(\mathcal{C}) \stackrel{\text{def}}{=} V(\mathcal{C}) \setminus B(\mathcal{C})$  the set of variables belonging to multiple constraints in  $\mathcal{C}$ .

<span id="page-13-0"></span>**Definition 5.1** (S-closure). Given  $S \subseteq V$ , constraint set  $\mathcal{C}$  over V, and  $\tau \in \mathbb{N}$ ,  $\mathcal{C}$  is S-closed if  $|V(C) \cap (S \cup \overline{B}(\mathcal{C}))| > \tau$  for every  $C \in \mathcal{C}$ . The S-closure  $\operatorname{cl}_S(\mathcal{C})$  of  $\mathcal{C}$  is the union of S-closed  $\mathcal{C}' \subseteq \mathcal{C}$ .

For our applications in subsequent sections, the parameter  $\tau$  in the definition of S-closure will be chosen so that the CSP is  $\tau$ -wise neutral.

<span id="page-13-2"></span>**Lemma 5.2.** The union  $\bigcup_i C_i$  of S-closed constraint sets  $C_i$  is S-closed. In particular, the S-closure  $\operatorname{cl}_S(\mathcal{C})$  is also S-closed.

*Proof.* Every  $C \in \bigcup_i C_i$  belongs to some  $C_i$ , whose S-closeness implies  $|V(C) \cap (S \cup \overline{B}(C_i))| > \tau$ . Now  $B(C_i) \cap V(C) \supseteq B(\bigcup_i C_i) \cap V(C)$  by Lemma A.1, so  $|V(C) \cap (S \cup \overline{B}(\bigcup_i C_i))| > \tau$  as well.  $\square$ 

<span id="page-13-6"></span>**Lemma 5.3.** For constraint sets  $C' \subseteq C$ ,  $\operatorname{cl}_S(C') \subseteq \operatorname{cl}_S(C)$ .

*Proof.* 
$$\operatorname{cl}_S(\mathcal{C}') \subseteq \mathcal{C}' \subseteq \mathcal{C}$$
 and  $\operatorname{cl}_S(\mathcal{C}')$  is S-closed by Lemma 5.2.

We now prove that S-closure admits an equivalent definition: Start with C; Remove  $C \in C$  from C if C violates the S-closeness property, i.e.  $|V(C) \cap (S \cup \overline{B}(C))| \leq \tau$ . Keep removing constraints this way until no more constraints can be removed. We will show that the resulting set coincides with the S-closure in Definition 5.1.

<span id="page-13-4"></span>Formally, define the set of "S-internal" constraints

(9) 
$$R_S(\mathcal{C}) \stackrel{\text{def}}{=} \{ C \in \mathcal{C} \mid |V(C) \cap (S \cup \overline{B}(\mathcal{C}))| > \tau \},$$

<span id="page-13-3"></span>and

(10) 
$$R_S^*(\mathcal{C}) \stackrel{\text{def}}{=} \begin{cases} \mathcal{C} & \text{if } R_S(\mathcal{C}) = \mathcal{C} \\ R_S^*(R_S(\mathcal{C})) & \text{if } R_S(\mathcal{C}) \subsetneq \mathcal{C} \end{cases}.$$

<span id="page-13-5"></span>Proposition 5.4.  $R_S^*(\mathcal{C}) = \operatorname{cl}_S(\mathcal{C})$ .

*Proof.* We first prove by induction on  $\mathcal{C}$  that  $\mathcal{C}' \subseteq R_S^*(\mathcal{C})$  for every S-closed  $\mathcal{C}' \subseteq \mathcal{C}$ .

Base Case: 
$$C = R_S(C)$$
. Then  $C' \subseteq C \stackrel{(10)}{=} R_S^*(C)$ .

**Induction Step:**  $C \supseteq R_S(\mathcal{C})$ . Consider any S-closed  $C' \subseteq \mathcal{C}$ . We now show that  $C' \subseteq R_S(\mathcal{C})$ . Indeed, every constraint  $C \in \mathcal{C}'$  satisfies  $|V(C) \cap (S \cup \overline{B}(\mathcal{C}'))| > \tau$ , which implies  $|V(C) \cap (S \cup \overline{B}(\mathcal{C}))| > \tau$  because  $V(C) \cap B(\mathcal{C}) \subseteq V(C) \cap B(\mathcal{C}')$  by Lemma A.1. This means  $C \in R_S(\mathcal{C})$  by Eq. (9). Thus  $C' \subseteq R_S(\mathcal{C})$ , which implies (by Induction Hypothesis for  $R_S(\mathcal{C})$ ) that  $C' \subseteq R_S^*(R_S(\mathcal{C})) \stackrel{(10)}{=} R_S^*(\mathcal{C})$ .

Having completed the induction proof, apply its conclusion to the S-closed set  $\mathcal{C}' = \operatorname{cl}_S(\mathcal{C})$ , and get  $\operatorname{cl}_S(\mathcal{C}) \subseteq R_S^*(\mathcal{C})$ .

For the converse inclusion, note that  $R_S(R_S^*(\mathcal{C})) = R_S^*(\mathcal{C})$  by Eq. (10), and hence  $R_S^*(\mathcal{C})$  is S-closed by Eq. (9), and therefore  $R_S^*(\mathcal{C}) \subseteq \operatorname{cl}_S(\mathcal{C})$ .

The equivalence in Proposition 5.4 does not appear in [KMOW17] or [BGMT12]. Both definitions of closure are useful: The removal viewpoint helps construct hierarchy solutions recursively (Lemma 5.11), while the union viewpoint helps show local closures to be small and sparse (Lemma 8.10).

Given any constraint set  $\mathcal{C}$ , any variable subset  $S \subseteq V$ , let  $\overline{R}_S(\mathcal{C}) \stackrel{\text{def}}{=} \mathcal{C} \setminus R_S(\mathcal{C})$  be the set of "S-exterior" constraints.

We also define the S-closure of an instance as the subinstance (i.e. variables and constraints) affecting the relaxed assignment on S.

<span id="page-14-0"></span>**Definition 5.5.** Given an instance  $I = (V, \mathcal{C})$  and a subset  $S \subseteq V$ , denote by  $\operatorname{cl}_S(I) \stackrel{\text{def}}{=} S \cup \operatorname{cl}_S(\mathcal{C})$  the subinstance with variable set  $S \cup V(\operatorname{cl}_S(\mathcal{C}))$  and constraint set  $\operatorname{cl}_S(\mathcal{C})$ .

As is well known, small subinstances of a random instance are sparse. Our next definition, implicit in [BGMT12, Lemma 3.2] and [KMOW17, Theorem 5.12], highlights the key combinatorial property enjoyed by these sparse subinstances.

<span id="page-14-2"></span>**Definition 5.6** (Dismissible). A constraint set  $\mathcal{C}$  is dismissible if  $\operatorname{cl}_{\emptyset}(\mathcal{C}) = \emptyset$ . An instance I is dismissible if its constraint set  $\mathcal{C}(I)$  is.

In other words, a dismissible constraint set can be completely removed by iteratively taking away  $\emptyset$ -exterior constraints.

#### 5.2. Scheme.

In this subsection, we lay a common framework to construct hierarchy solutions for each elementary hierarchy except SDP, generalizing previous LP constructions in [BGMT12, Lemma 3.2] and [KMOW17, Theorem 5.12]. The framework involves a *scheme* assigning a relaxed assignment to every (small and sparse) subinstance.

<span id="page-14-1"></span>**Definition 5.7.** A scheme  $\sigma$  for a family  $\mathcal{I}$  of instances is a function mapping  $I \in \mathcal{I}$  to  $\sigma(I) \in \mathcal{M}^{A_I}$ , where  $A_I$  is the set of assignments  $a \in D^{V(I)}$  that satisfy all constraints in I. A scheme is compatible with closure<sup>4</sup> if for every  $I = (U, \mathcal{C}) \in \mathcal{I}$  and  $S \subseteq U$ ,

<span id="page-14-5"></span>(11) 
$$\pi_{U \to S}(\sigma(I)) = \pi_{V(\operatorname{cl}_S(I)) \to S}(\sigma(\operatorname{cl}_S(I))).$$

A scheme  $\sigma$  for  $\mathcal{I}$  is nontrivial if  $\sigma(I_{\emptyset}) = \mathbb{1}_{\emptyset}$ , where  $I_{\emptyset} \stackrel{\text{def}}{=} (\emptyset, \emptyset)$  is the null instance without any variable or constraint. We will later turn a nontrivial scheme into a hierarchy solution (Proposition 8.15).

When assigning a relaxed assignment to a subinstance, what really matter are the constraints in the subinstance. The isolated variables play essentially no role. Our next definition focuses on the simpler setting of assigning a relaxed assignment to the constraints of the subinstance, and considers a scheme for a family of constraint sets (namely, the family of constraints appearing in the family of small subinstances). At the same time, we also simplify the "compatibility with closure" condition. Recall that the S-closure can be obtained by iteratively removing S-exterior constraints (Proposition 5.4). Instead of directly requiring every instance to share the same projection as its S-closure, we instead ask for the same projection with the subinstance obtained after removing any single S-exterior constraint.

**Definition 5.8.** Let  $\mathcal{C}$  be a family of constraint sets over a variable set V. A scheme  $\sigma$  for  $\mathcal{C}$  is a function mapping  $\mathcal{C} \in \mathcal{C}$  to  $\sigma(\mathcal{C}) \in \mathcal{M}^{A_{\mathcal{C}}}$ , where  $A_{\mathcal{C}}$  is the set of assignments  $a \in D^{V(\mathcal{C})}$  that satisfy all constraints in  $\mathcal{C}$ . A scheme  $\sigma$  for  $\mathcal{C}$  is compatible with a neutral solution  $\nu : (v \in V) \to \mathcal{D}_{\{v\}}$  if for every  $\mathcal{C} \in \mathcal{C}$ ,  $S \subseteq V(\mathcal{C})$ ,  $C \in \overline{R}_S(\mathcal{C})$ ,

(12) 
$$\pi_{V(\mathcal{C})\to S}(\sigma(\mathcal{C})) = \pi_{V(\mathcal{C})\to S}\left(\sigma(\mathcal{C}')\otimes \nu^{V(\mathcal{C})\setminus V(\mathcal{C}')}\right),$$

<span id="page-14-4"></span><span id="page-14-3"></span><sup>&</sup>lt;sup>4</sup>This definition only makes sense if  $\mathcal{I}$  is closed under closure, which is the case in our applications.

where  $\mathcal{C}' \stackrel{\text{def}}{=} \mathcal{C} \setminus \{C\}$ .

We will show in Lemma 5.11 below that, roughly speaking, the new compatible condition in Eq. (12) implies the original one in Eq. (11). The new condition is easier to verify in practice, because it only involves removing one constraint at a time.

Given a family  $\mathcal{C}$  of constraint sets over V, let  $\mathcal{I}(\mathcal{C})$  be the family of instances  $I = (U, \mathcal{C})$  with a constraint set in  $\mathcal{C}$ , that is,  $U \subseteq V$  and  $\mathcal{C} \in \mathcal{C}$ .

**Definition 5.9.** Given a scheme  $\sigma$  for  $\mathcal{C}$  compatible with a neutral solution  $\nu$ , its *extended scheme*  $\sigma^*$  for  $\mathcal{I}(\mathcal{C})$  is

(13) 
$$\sigma^*(I) \stackrel{\text{def}}{=} \sigma(\mathcal{C}) \otimes \nu^{U \setminus V(\mathcal{C})} \quad \text{for } I = (U, \mathcal{C}) \in \mathcal{I}(\mathcal{C}).$$

In the above definition, since  $\sigma$  is supported on satisfying assignments of  $\mathcal{C} = \mathcal{C}(I)$ ,  $\sigma^*$  is indeed supported on satisfying assignments of I.

<span id="page-15-3"></span>A scheme  $\sigma$  for  $\mathcal{C}$  is nontrivial if  $\sigma(\emptyset) = \mathbb{1}_{\mathbb{0}}$ .

<span id="page-15-5"></span>**Lemma 5.10.** Let  $\sigma$  be a scheme for a family  $\mathcal{C}$  of constraint sets compatible with a neutral solution. If  $\sigma$  is nontrivial, then so is its extended scheme  $\sigma^*$ .

Proof. 
$$\sigma^*(I_{\emptyset}) \stackrel{(13)}{=} \sigma(\emptyset) = \mathbb{1}_{\mathbb{0}}.$$

<span id="page-15-2"></span>**Lemma 5.11.** Let  $\sigma$  be a scheme for a family  $\mathcal{C}$  of constraint sets compatible with a neutral solution  $\nu$ . Then its extended scheme  $\sigma^*$  for  $\mathcal{I}(\mathcal{C})$  is compatible with closure.

*Proof.* We prove by induction on  $C \in C$  that for any instance I = (U, C), any  $S \subseteq U$ ,  $\pi_S(\sigma^*(I)) = \pi_S(\sigma^*(\operatorname{cl}_S(I)))$ .

**Base Case:**  $C = \operatorname{cl}_S(C)$ . The result follows because  $C = \operatorname{cl}_S(C)$ , so  $I = \operatorname{cl}_S(I)$ .

**Induction Step:**  $\mathcal{C} \supseteq \operatorname{cl}_S(\mathcal{C})$ . By Proposition 5.4 and Eq. (10),  $\mathcal{C} \supseteq R_S(\mathcal{C}) \supseteq \operatorname{cl}_S(\mathcal{C})$ . Fix an arbitrary  $C \in \overline{R}_S(\mathcal{C})$ . Let  $\mathcal{C}' \stackrel{\text{def}}{=} \mathcal{C} \setminus \{C\}$  and  $T \stackrel{\text{def}}{=} S \cap V(\mathcal{C})$ . Then  $C \in \overline{R}_T(\mathcal{C})$ . Since  $\sigma$  is compatible with  $\nu$ ,

$$\pi_{S}(\sigma^{*}(I)) \stackrel{(13)}{=} \pi_{S} \left( \sigma(\mathcal{C}) \otimes \nu^{U \setminus V(\mathcal{C})} \right) \stackrel{(51)}{=} \pi_{T}(\sigma(\mathcal{C})) \otimes \nu^{S \setminus V(\mathcal{C})}$$

$$\stackrel{(12)}{=} \pi_{T} \left( \sigma(\mathcal{C}') \otimes \nu^{V(\mathcal{C}) \setminus V(\mathcal{C}')} \right) \otimes \nu^{S \setminus V(\mathcal{C}')}$$

$$\stackrel{(51)}{=} \pi_{S} \left( \sigma(\mathcal{C}') \otimes \nu^{(S \cup V(\mathcal{C})) \setminus V(\mathcal{C}')} \right) \stackrel{(13)}{=} \pi_{S}(\sigma^{*}(I')) \stackrel{\text{I.H.}}{=} \pi_{S}(\sigma^{*}(\text{cl}_{S}(I'))),$$

where  $I' = (U, \mathcal{C}')$ . The desired result now follows from the fact that  $\operatorname{cl}_S(\mathcal{C}') = \operatorname{cl}_S(\mathcal{C})$  (and hence  $\operatorname{cl}_S(I') = \operatorname{cl}_S(I)$ ), which holds because (1)  $\mathcal{C}' \supseteq R_S(\mathcal{C}) \supseteq \operatorname{cl}_S(\mathcal{C})$  and  $\operatorname{cl}_S(\mathcal{C})$  is S-closed, so  $\operatorname{cl}_S(\mathcal{C}') \supseteq \operatorname{cl}_S(\mathcal{C})$ ; and (2) of Lemma 5.3.

#### <span id="page-15-4"></span>6. BW SCHEME

<span id="page-15-0"></span>This section concerns the bounded width hierarchy. Recall that the neutral solution  $\nu \stackrel{\text{def}}{=} \nu_{\text{BW}}$  maps every  $v \in V$  to  $D^{\{v\}}$ .

<span id="page-15-1"></span>**Proposition 6.1.** Let  $R \subseteq D^k$  be a relation. Consider an integer  $\tau$  such that  $0 \leqslant \tau \leqslant k$ . Then some  $\tau$ -wise neutral relaxed assignment  $\alpha \subseteq D^k$  is supported on R if and only if

(14) 
$$\pi_T(R) = D^T \quad \text{for } \tau\text{-small } T \subseteq [k].$$

*Proof.* If Eq. (14) holds, then the relaxed assignment  $\alpha \stackrel{\text{def}}{=} R$  is  $\tau$ -wise  $\nu$ -neutral because  $\pi_T(\alpha) = \pi_T(R) = D^T = \nu^T$  for  $\tau$ -small  $T \subseteq [k]$ . Also, this  $\alpha$  is supported on R, that is,  $\alpha \subseteq R$ .

Conversely, if some  $\tau$ -wise neutral relaxed assignment  $\alpha \subseteq R$  is supported on R, then  $\pi_T(R) \supseteq \pi_T(\alpha) = \nu^T = D^T$  for  $\tau$ -small  $T \subseteq [k]$ . But  $\pi_T(R)$  is trivially a subset of  $D^T$ . This implies Eq. (14).

Consequently, a CSP  $(D, \mathfrak{R})$  is  $\tau$ -wise neutral if and only if Eq. (14) holds for every  $R \in \mathfrak{R}$ . k-SAT, k-NAE, k-XOR are all examples of (k-1)-wise neutral CSPs for BW when  $k \ge 1$ .

When  $\tau=2$ , our pairwise neutral condition here is closely related to (but stronger than) the null-constraining condition in [CM13, Definition 2.6], which means some lower bounds in [CM13] do not follow from our lower bounds here. As an example, [AD22, Theorem 3] morally follows from [CM13, Theorem 1.4(a)] (and Lemma B.3) but not from Theorem 1.1.<sup>5</sup>

Consider the function  $\sigma$  mapping constraint sets  $\mathcal{C}$  to the set  $\sigma(\mathcal{C}) \stackrel{\text{def}}{=} A_{\mathcal{C}} \subseteq D^{V(\mathcal{C})}$  of satisfying assignments of  $\mathcal{C}$ .

<span id="page-16-2"></span>**Proposition 6.2.**  $\sigma$  is a nontrivial scheme for constraint sets and is compatible with  $\nu$ .

*Proof.*  $\sigma$  is supported on satisfying assignments of  $\mathcal C$  by definition.

 $\sigma$  is nontrivial, because  $\sigma(\emptyset) = A_{\emptyset} = \{0\}$ , which is nonempty.

We now prove that for any  $S \subseteq V(\mathcal{C})$ ,  $C \in \overline{R}_S(\mathcal{C})$ , if  $\mathcal{C}' \stackrel{\text{def}}{=} \mathcal{C} \setminus \{C\}$ ,  $U \stackrel{\text{def}}{=} V(\mathcal{C}')$ , then

$$\pi_S(\sigma(\mathcal{C})) = \pi_S\left(\sigma(\mathcal{C}') \otimes \nu^{V(C)\setminus U}\right).$$

For any  $b \in \pi_S(\sigma(\mathcal{C}))$ , some assignment  $a \in V(\mathcal{C})$  satisfies all constraints of  $\mathcal{C}$  and  $a_S = b$ . In particular  $a_U$  satisfies all constraints in  $\mathcal{C}'$  and  $a \in A_{\mathcal{C}'} \times D^{V(C)\setminus U} = \sigma(\mathcal{C}') \otimes \nu^{V(C)\setminus U}$ , so  $b \in \pi_S\left(\sigma(\mathcal{C}') \otimes \nu^{V(C)\setminus U}\right)$ .

Conversely, if  $b \in \pi_S\left(\sigma(\mathcal{C}') \otimes \nu^{V(C)\setminus U}\right)$ , then some  $a \in D^{V(\mathcal{C})}$  satisfies  $a_S = b$  and  $a_U$  satisfies all constraints in  $\mathcal{C}'$ . Let  $T \stackrel{\text{def}}{=} V(C) \cap (S \cup U) = V(C) \cap (S \cup \overline{B}(\mathcal{C}))$ . Since  $C \in \overline{R}_S(\mathcal{C})$ ,  $|T| \leqslant \tau$ . Since Eq. (14) holds for the relation R of C, some satisfying assignment  $c \in A_C$  has  $c_T = a_T$ . Then the combined assignment  $a' \stackrel{\text{def}}{=} a_{S \cup U} \cup c \in D^{V(\mathcal{C})}$  satisfies all constraints in  $\mathcal{C}$  and has projection  $a'_S = a_S = b$ , so  $b \in \pi_S(\sigma(\mathcal{C}))$ .

<span id="page-16-5"></span>Corollary 6.3. If a dismissible constraint set C is  $\tau$ -wise neutral, then C is satisfiable.

Proof. By Proposition 6.2 and Lemmas 5.10 and 5.11, the function  $\sigma \stackrel{\text{def}}{=} I \mapsto A_I$  is a nontrivial extended scheme for instances, and  $\sigma$  is compatible with closure. Let  $I \stackrel{\text{def}}{=} (V(\mathcal{C}), \mathcal{C})$  be the instance consisting of  $\mathcal{C}$  and  $I_{\emptyset} \stackrel{\text{def}}{=} (\emptyset, \emptyset)$  be the null instance. Then  $\pi_{\emptyset}(\sigma(I)) \stackrel{(11)}{=} \pi_{\emptyset}(\sigma(\operatorname{cl}_{\emptyset}(I))) = \pi_{\emptyset}(\sigma(I_{\emptyset})) \neq \emptyset$  because  $\sigma$  is nontrivial. Therefore  $\sigma(I) \neq \emptyset$  and any assignment  $a \in \sigma(I) = A_I$  satisfies  $\mathcal{C}$ .  $\square$ 

#### 7. AIP SCHEME

<span id="page-16-0"></span>This section concerns the AIP hierarchy. Given any  $\tau$ -wise neutral CSP and any  $a \in D^k$ , we wish to construct a scheme for constraint sets compatible with  $\mathbb{1}_a$  (or more precisely, compatible with  $\nu_a \stackrel{\text{def}}{=} v \mapsto \mathbb{1}_{a_v}$ ). To this end, we will recursively define a function  $M_a(\mathcal{C})$  that outputs an integer weight  $w: D^{V(C)} \to \mathbb{Z}$  by "mending" the integer weight  $\mathbb{1}_{a_{V(C)}}$  according to  $\mathcal{C}$ .

Call a family  $\{\alpha_a \in \mathbb{Z}^{D^k} \mid a \in D^k\}$  of relaxed assignments  $\tau$ -wise neutral if  $\alpha_a$  is  $\tau$ -wise  $\mathbb{1}_a$ -neutral for every  $a \in D^k$ .

<span id="page-16-3"></span>**Definition 7.1.** Given a family  $\{\alpha_a \mid a \in D^k\}$  of  $\tau$ -wise neutral relaxed assignments, the *derived* relaxed assignments are

$$\alpha_b \stackrel{\text{def}}{=} \sum_{\substack{a \in D^k \\ a_S = b}} \alpha_a \quad \text{for } b \in D^S, S \subseteq [k].$$

<span id="page-16-4"></span><span id="page-16-1"></span><sup>&</sup>lt;sup>5</sup>The reason is that for any relational structure **S** satisfying the condition " $U, V \in \mathcal{G}(S)$  implies  $U \circ V = S^2$ " of [AD22, Theorem 3], the CSP has no forbidding path of length at least 2 and its domain S is null-constraining. However, **S** is not necessarily pairwise neutral for BW, and an example is graph 3-coloring.

**Lemma 7.2.** The derived relaxed assignment  $\alpha_b$  in Definition 7.1 is  $\tau$ -wise  $\mathbb{1}_b$ -neutral:

$$\pi_{[k]\to U}(\alpha_b) = \pi_{[k]\to U}(\mathbb{1}_b)$$
 for  $\tau$ -small subset  $U\subseteq [k]$ .

Proof.

$$\pi_U(\alpha_b) \stackrel{(4)}{=} \sum_{\substack{a \in D^k \\ a_S = b}} \pi_U(\alpha_a) \stackrel{(*)}{=} \sum_{\substack{a \in D^k \\ a_S = b}} \pi_U(\mathbb{1}_a) \stackrel{(4)}{=} \pi_U(\mathbb{1}_b),$$

where (\*) is by Definition 4.1. (Here  $\mathbb{1}_b: D^k \to \mathbb{Z}$ .)

<span id="page-17-4"></span>**Lemma 7.3.** If the relaxed assignments  $\alpha_a$  in Definition 7.1 are all supported on  $R \subseteq D^k$ , then so is every derived relaxed assignment  $\alpha_b$ .

*Proof.* For every 
$$c \in D^k \setminus R$$
,  $\alpha_b(c) = \sum_{\substack{a \in D^k \\ a_S = b}} \alpha_a(c) = 0$ .

Given a  $\tau$ -wise neutral CSP  $(D,\mathfrak{R})$ , let  $\left\{\alpha_a^R \mid a \in D^k\right\}$  be a family of  $\tau$ -wise neutral relaxed assignments supported on R for every  $R \in \mathfrak{R}$ , and  $\left\{\alpha_b^R \mid b \in D^S, S \subseteq [k]\right\}$  be the derived  $\tau$ -wise neutral relaxed assignments for  $R \in \mathfrak{R}$ . They further yield relaxed assignments  $\left\{\alpha_b^C \in \mathbb{Z}^{A_C} \mid b \in D^S, S \subseteq V(C)\right\}$  on every constraint C of the CSP, where  $\alpha_b^C$  is  $\alpha_b^R$  transferred to C (Definition 7.4 below) and R is the k-ary relation of satisfying assignments of C:

<span id="page-17-0"></span>**Definition 7.4.** Given a relaxed assignment  $\alpha: D^k \to \mathcal{M}$  and a constraint C with scope S, the relaxed assignment  $\alpha^C: D^{V(C)} \to \mathcal{M}$  transferred to C is  $\alpha^C(a) \stackrel{\text{def}}{=} \alpha(a \circ S)$  for  $a \in D^{V(C)}$ .

Since we only consider constraints C having no repeated variables (i.e. its scope S consists of k distinct variables),  $\alpha_b^C$  inherits  $\tau$ -wise neutrality from  $\alpha_b^R$ .

**Definition 7.5.** Given subsets S, T of V, define the generalized tensor product  $\tilde{\otimes} : \mathbb{Z}^{D^S} \times \mathbb{Z}^{D^T} \to \mathbb{Z}^{D^{S \cup T}}$  by

<span id="page-17-1"></span>(15) 
$$(u \otimes v)(a) \stackrel{\text{def}}{=} u(a_S)v(a_T) \quad \text{for } a \in D^{S \cup T}, u \in \mathbb{Z}^{D^S}, v \in \mathbb{Z}^{D^T}.$$

It is easy to verify that  $\tilde{\otimes}$  is commutative and associative. In the above definition, the subsets S and T need not be disjoint. When they are, the generalized tensor product coincides with the usual tensor product in Eq. (6).

**Definition 7.6.** Given constraint sets  $C' \subseteq C$ ,  $b \in D^{V(C') \cap B(C)}$ , define

<span id="page-17-5"></span><span id="page-17-3"></span>
$$\alpha_b^{\mathcal{C}'} \stackrel{\text{def}}{=} \widetilde{\bigotimes}_{C \in \mathcal{C}'} \alpha_{b_{V(C) \cap B(\mathcal{C})}}^C.$$

We are now ready to define the mending function  $M_a: (\mathcal{C} \in \mathcal{C}) \to \mathbb{Z}^{D^{V(\mathcal{C})}}$  for the family of dismissible constraint sets  $\mathcal{C}$ . Define  $M_a(\emptyset) \stackrel{\text{def}}{=} \mathbb{1}_{\mathbb{Q}}$ . For a nonempty dismissible  $\mathcal{C}$ ,  $M_a(\mathcal{C})$  is defined recursively via inclusion-exclusion by

(16) 
$$M_{a}(\mathcal{C}) \stackrel{\text{def}}{=} \sum_{\substack{\mathcal{C}' \subseteq \overline{R}_{\emptyset}(\mathcal{C}) \\ \mathcal{C}' \neq \emptyset}} (-1)^{|\mathcal{C}'|+1} M'_{a}(\mathcal{C}, \mathcal{C}'),$$

where

(17) 
$$M'_{a}(\mathcal{C}, \mathcal{C}') \stackrel{\text{def}}{=} M_{a}(\mathcal{C} \setminus \mathcal{C}') \, \tilde{\otimes} \, \alpha^{\mathcal{C}'}_{a_{V(\mathcal{C}') \cap B(\mathcal{C})}}.$$

<span id="page-17-2"></span>**Lemma 7.7.** For variable subsets  $S, R \subseteq V$ , subset  $U \subseteq R$ , weights  $w \in \mathbb{Z}^{D^S}$ ,  $y \in \mathbb{Z}^{D^R}$ ,  $\pi_{S \cup U}$   $(w \tilde{\otimes} y) = w \tilde{\otimes} \pi_U(y)$ .

*Proof.* Let  $T \stackrel{\text{def}}{=} R \setminus (S \cup U)$ . For any  $b \in D^{S \cup U}$ ,

$$\pi_{S \cup U} (w \,\tilde{\otimes}\, y) (b) \stackrel{(2)}{=} \sum_{a \in D^T} (w \,\tilde{\otimes}\, y) (b \cup a) \stackrel{(15)}{=} \sum_{a \in D^T} w(b_S) y(b_U \cup a)$$

$$\stackrel{(*)}{=} w(b_S) \sum_{a \in D^T} y(b_U \cup a) \stackrel{(2)}{=} w(b_S) \pi_U(y) (b_U) \stackrel{(15)}{=} (w \,\tilde{\otimes}\, \pi_U(y)) (b),$$

where (\*) is due to the independence of  $w(b_S)$  from a.

<span id="page-18-2"></span>**Lemma 7.8.** For any constraint set C, variable subset  $T \subseteq V(C)$ , T-exterior constraint  $C \in \overline{R}_T(C)$ , let  $Q \stackrel{\text{def}}{=} V(C) \cap B(C)$  and  $S \stackrel{\text{def}}{=} V(C) \setminus Q$ . For any  $w : D^S \to \mathbb{Z}$ ,  $b \in D^Q$ ,

(18) 
$$\pi_T \left( w \,\tilde{\otimes} \, \alpha_b^C \right) = \pi_T (w \otimes \mathbb{1}_b).$$

*Proof.*  $U \stackrel{\text{def}}{=} T \cap V(C)$  is  $\tau$ -small because  $C \in \overline{R}_T(C)$ . Then

(19) 
$$\pi_{S \cup U} \left( w \, \tilde{\otimes} \, \alpha_b^C \right) = w \, \tilde{\otimes} \, \pi_U \left( \alpha_b^C \right) = w \, \tilde{\otimes} \, \pi_U(\mathbb{1}_b),$$

where the first equality is Lemma 7.7 (with  $R \stackrel{\text{def}}{=} V(C), y \stackrel{\text{def}}{=} \alpha_b^C$ ), and the second is Lemma 7.2. Further projecting to T,

<span id="page-18-3"></span><span id="page-18-1"></span><span id="page-18-0"></span>
$$\pi_T \left( w \,\tilde{\otimes}\, \alpha_b^C \right) \stackrel{(5)}{=} \pi_T \left( \pi_{S \cup U} \left( w \,\tilde{\otimes}\, \alpha_b^C \right) \right) \stackrel{(19)}{=} \pi_T (w \,\tilde{\otimes}\, \pi_U(\mathbb{1}_b))$$

$$= \pi_T (w \,\tilde{\otimes}\, \mathbb{1}_{b_{U \cap Q}}) \stackrel{(*)}{=} \pi_T (w \otimes \mathbb{1}_{b_{U \cap Q}}) \stackrel{(51),(5)}{=} \pi_T (w \otimes \mathbb{1}_b),$$

where (\*) uses the fact that  $U \cap Q$  is disjoint from S.

**Corollary 7.9.** For any constraint set C, variable subset  $T \subseteq V(C)$ , subset of T-exterior constraints  $C' \subseteq \overline{R}_T(C)$ , let  $U \stackrel{\text{def}}{=} V(C') \cap B(C)$ . For any  $y : D^{V(C) \setminus U} \to \mathbb{Z}$ ,  $b \in D^U$ ,

(20) 
$$\pi_T \left( y \, \tilde{\otimes} \, \alpha_b^{\mathcal{C}'} \right) = \pi_T (y \otimes \mathbb{1}_b).$$

*Proof.* We prove by induction on  $\mathcal{C}'$ .

Base Case:  $\mathcal{C}' = \emptyset$ . Then  $V(\mathcal{C}') = \emptyset$ . Both sides of Eq. (20) equal  $\pi_T(y)$ , since  $\alpha_b^{\mathcal{C}'} = \mathbb{1}_b = \mathbb{1}_{\mathbb{0}}$ . Induction Step:  $\mathcal{C}' \neq \emptyset$ . Fix any  $C \in \mathcal{C}'$ . Let  $\mathcal{C}'' \stackrel{\text{def}}{=} \mathcal{C}' \setminus \{C\}, Q \stackrel{\text{def}}{=} V(\mathcal{C}'') \cap B(\mathcal{C})$  and  $R \stackrel{\text{def}}{=} V(C) \cap B(\mathcal{C})$ . Then  $C \notin R_T(\mathcal{C})$ . Lemma 7.8 (with  $w \stackrel{\text{def}}{=} y \otimes \alpha_{b_O}^{\mathcal{C}''}$ ) implies

$$\pi_{T}\left(y\,\tilde{\otimes}\,\alpha_{b_{Q}}^{\mathcal{C}''}\,\tilde{\otimes}\,\alpha_{b_{R}}^{C}\right)\stackrel{(18)}{=}\pi_{T}\left(y\,\tilde{\otimes}\,\alpha_{b_{Q}}^{\mathcal{C}''}\otimes\mathbb{1}_{b_{R}}\right)\stackrel{\text{I.H.}}{=}\pi_{T}\left(y\otimes\mathbb{1}_{b_{Q}}\otimes\mathbb{1}_{b_{R}}\right)=\pi_{T}\left(y\otimes\mathbb{1}_{b}\right).$$

<span id="page-18-6"></span>**Proposition 7.10.**  $M_a$  is a nontrivial scheme for constraint sets.

*Proof.* Nontriviality follows by definition of  $M_a(\emptyset) = \mathbb{1}_{\mathbb{O}}$ .

We prove by induction on  $\mathcal{C}$  that  $M_a(\mathcal{C})$  is supported on satisfying assignments of  $\mathcal{C}$ .

**Base Case:**  $C = \emptyset$ . The result holds because no constraint can be violated.

**Induction Step:**  $\mathcal{C} \neq \emptyset$ . Then  $M_a(\mathcal{C})$  is a signed sum of  $M'_a(\mathcal{C}, \mathcal{C}')$  over nonempty  $\mathcal{C}' \subseteq \overline{R}_{\emptyset}(\mathcal{C})$ . For every such term, let  $\overline{\mathcal{C}'} \stackrel{\text{def}}{=} \mathcal{C} \setminus \mathcal{C}'$ . For any  $b \in D^{V(\mathcal{C})}$ ,

<span id="page-18-4"></span>
$$(21) M'_a(\mathcal{C}, \mathcal{C}')(b) \stackrel{(17)}{=} \left( M_a(\overline{\mathcal{C}'}) \, \tilde{\otimes} \, \alpha^{\mathcal{C}'}_{a_{V(C) \cap B(\mathcal{C})}} \right)(b) = M_a(\overline{\mathcal{C}'}) \left( b_{V(\overline{\mathcal{C}'})} \right) \prod_{C \in \mathcal{C}'} \alpha^{C}_{a_{V(C) \cap B(\mathcal{C})}} \left( b_{V(C)} \right).$$

If b violates some constraint in  $\overline{\mathcal{C}'} = \mathcal{C} \setminus \mathcal{C}'$ , Eq. (21) is zero by Induction Hypothesis for  $\overline{\mathcal{C}'} \subsetneq \mathcal{C}$ . If b violates  $C \in \mathcal{C}'$ , Eq. (21) is also zero by Lemma 7.3.

<span id="page-18-5"></span>**Lemma 7.11.** For any constraint sets  $C' \subseteq C$ , any  $S \subseteq V(C)$ ,  $\overline{R}_S(C) \cap C' \subseteq \overline{R}_{S \cap V(C')}(C')$ .

*Proof.* We have  $S \cap V(\mathcal{C}') \subseteq S \cap V(\mathcal{C}) = S$ . For any  $C \in \overline{R}_S(\mathcal{C}) \cap \mathcal{C}'$ , we have  $V(C) \cap \overline{B}(\mathcal{C}') \subseteq S$  $V(C) \cap \overline{B}(C)$  by Lemma A.1, so

<span id="page-19-1"></span>
$$|V(C) \cap ((S \cap V(C')) \cup \overline{B}(C'))| \leq |V(C) \cap (S \cup \overline{B}(C))| \leq \tau$$

thus 
$$C \in \overline{R}_{S \cap V(C')}(C')$$
.

<span id="page-19-6"></span>**Theorem 7.12.** The scheme  $M_a$  is compatible with  $\mathbb{1}_a$ : For any  $C, S \subseteq V(C), C \in \overline{R}_S(C)$ ,

(22) 
$$\pi_S(M_a(\mathcal{C})) = \pi_S\left(M_a(\mathcal{C} \setminus \{C\}) \otimes \mathbb{1}_{a_{V(C) \cap B(\mathcal{C})}}\right).$$

*Proof.* We prove by induction on  $\mathcal{C}$  that for every  $S \subseteq V(\mathcal{C})$ ,  $C \in \overline{R}_S(\mathcal{C})$ , Eq. (22) holds.

**Base Case:**  $C = \operatorname{cl}_S(C)$ . Eq. (22) holds vacuously because  $R_S(C) = C$  and no  $C \in \overline{R}_S(C)$  exists.

**Induction Step:** Fix any  $S \subseteq V(\mathcal{C})$  and any  $C \in \overline{R}_S(\mathcal{C})$ . Let  $\overline{C} \stackrel{\text{def}}{=} \mathcal{C} \setminus \{C\}$ . A summand in Eq. (16) is  $M'_a(\mathcal{C}, \{C\})$ . After projecting to S, this summand becomes (by Lemma 7.8)

$$\pi_S(M'_a(\mathcal{C}, \{C\})) \stackrel{(17)}{=} \pi_S\left(M_a(\overline{C}) \tilde{\otimes} \alpha^C_{a_{V(C) \cap B(\mathcal{C})}}\right) \stackrel{(18)}{=} \text{RHS of } (22).$$

It remains to show that all other terms in Eq. (16) cancel each other after projecting to S. These other terms can be paired: For every nonempty  $C_0 \subseteq \overline{R}_{\emptyset}(\mathcal{C}) \setminus \{C\}$ , pair up the term for  $C_0$  and the term for  $C_1 \stackrel{\text{def}}{=} C_0 \cup \{C\}$ . Let  $\overline{C}_i \stackrel{\text{def}}{=} C \setminus C_i$  for i = 0, 1. Ignoring the sign, and after projecting to S, the term for  $C_i$  contributes

<span id="page-19-2"></span>(23) 
$$\pi_{S}(M'_{a}(\mathcal{C}, \mathcal{C}_{i})) \stackrel{(17)}{=} \pi_{S} \left( M_{a}(\overline{\mathcal{C}}_{i}) \tilde{\otimes} \alpha^{\mathcal{C}_{i}}_{a_{V(\mathcal{C}_{i}) \cap B(\mathcal{C})}} \right) \stackrel{(20)}{=} \pi_{S} \left( M_{a}(\overline{\mathcal{C}}_{i}) \otimes \mathbb{1}_{a_{V(\mathcal{C}_{i}) \cap B(\mathcal{C})}} \right)$$

In particular,

(23) for 
$$C_0 \stackrel{\text{I.H.}}{=} \pi_{S \cap V(\overline{C}_0)} \left( M_a(\overline{C}_1) \otimes \mathbb{1}_{a_{V(C) \cap B(\overline{C}_0)}} \right) \otimes \mathbb{1}_{a_{S \setminus V(\overline{C}_0)}} \stackrel{(51)}{=} (23)$$
 for  $C_1$ .

We can apply the Induction Hypothesis (I.H.) because  $C \in \overline{R}_{S \cap V(\overline{C}_0)}(\overline{C}_0)$  by Lemma 7.11.

Since the terms for  $C_0$  and  $C_1$  have opposite signs in Eq. (16), their projections cancel each other.

#### 8. HIERARCHY SOLUTION ON EXPANDING INSTANCES

<span id="page-19-0"></span>Throughout this section, we consider a fixed  $\tau$ -wise neutral CSP for some  $\tau \in \mathbb{N}$ . We prove our first main theorem (Theorem 1.1) in Section 8.2. As an application, we also prove SDP+AIP lower bounds for k-SAT for  $k \ge 4$  in Section 8.3.

## 8.1. Expansion and local closure.

Following [KMOW17, Definition 4.8], we measure the sparsity of a subinstance as follows:<sup>6</sup>

<span id="page-19-5"></span>**Definition 8.1** (Sparsity). Given a subset  $S \subseteq V$  and an S-closed constraint set  $\mathcal{C}$  over V, their sparsity is

(24) 
$$\operatorname{sp}(\mathcal{C}, S) \stackrel{\text{def}}{=} 2|S \cup \overline{B}(\mathcal{C})| + (\tau + 1)|\mathcal{C}| - 2|J(\mathcal{C}, S)|,$$

where

<span id="page-19-4"></span>
$$J(\mathcal{C},S) \stackrel{\mathrm{def}}{=} \{(C,v) \in \mathcal{C} \times (S \cup \overline{B}(\mathcal{C})) \mid v \in C\}$$

denotes the constraint-variable incidences between  $\mathcal{C}$  and  $S \cup \overline{B}(\mathcal{C})$ .

<span id="page-19-3"></span><sup>&</sup>lt;sup>6</sup>Sparsity is called revenue in [KMOW17]. Eq. (24) has the factor  $\tau + 1$  in place of the factor  $\tau$  in the revenue. This is because our CSP is  $\tau$ -wise neutral, whereas [KMOW17, Notation 2.4] is  $(\tau - 1)$ -wise uniform.

The constraint set  $\mathcal{C}$  and variable subset S above represent a "subinstance"  $I = (S, \mathcal{C})$  of a  $\tau$ -wise neutral CSP, where  $\mathcal{C}$  is allowed to contain variables outside S in this definition. Definition 8.1 counts how much sparser (i.e. many fewer constraint-variable incidences) I is from being potentially non-dismissible. In other words, how far away from the impossibility of recursively constructing a hierarchy solution for I from scratch. Consider the case of k-XOR, which is  $\tau$ -wise neutral in the BW or LP hierarchy for  $\tau = k - 1$ . Consider a k-XOR subinstance  $I = (U, \mathcal{C})$  whose variables each participates in exactly two constraints and  $U = V(\mathcal{C})$ . Such a subinstance may be unsatisfiable, if the sum of parities of all the constraints is odd. And indeed  $\operatorname{sp}(\mathcal{C}, U) = 0$ , signifying I is not sparse enough to guarantee satisfiability, let alone having a hierarchy solution of level |U|. By contrast, any k-XOR instance I all of whose nonempty constraint subsets  $\mathcal{C}'$  have positive sparsity  $\operatorname{sp}(\mathcal{C}', V(\mathcal{C}'))$  is dismissible.

The sparsity can be equivalently decomposed as the sum

(25) 
$$\operatorname{sp}(\mathcal{C}, S) = \sum_{C \in \mathcal{C}} \operatorname{sp}_{S \cup \overline{B}(\mathcal{C})}(C) + \sum_{v \in S \cup \overline{B}(\mathcal{C})} \operatorname{sp}_{\mathcal{C}}(v),$$

where

<span id="page-20-1"></span>
$$\operatorname{sp}_T(C) \stackrel{\text{def}}{=} (\tau + 1) - |V(C) \cap T| \quad \text{for } T \subseteq V, \text{and}$$
$$\operatorname{sp}_{\mathcal{C}}(v) \stackrel{\text{def}}{=} 2 - |\{C \in \mathcal{C} \mid v \in C\}|.$$

Indeed, all the contributions to Eq. (24) and Eq. (25) are:

- Every  $v \in S \cup \overline{B}(\mathcal{C})$  contributes 2 to Eq. (24) and to Eq. (25).
- Every  $C \in \mathcal{C}$  contributes  $\tau + 1$  to Eq. (24) and to Eq. (25).
- Every incidence  $(C, v) \in J(\mathcal{C}, S)$  contributes -2 to Eq. (24). It also contributes -1 to  $\operatorname{sp}_{S \cup \overline{B}(\mathcal{C})}(C)$  and -1 to  $\operatorname{sp}_{\mathcal{C}}(v)$  in Eq. (25).

<span id="page-20-2"></span>Remark 8.2. Since sparsity  $\operatorname{sp}(\mathcal{C},S)$  is only defined for an S-closed constraint set  $\mathcal{C}$ , every term  $\operatorname{sp}_{S \cup \overline{B}(\mathcal{C})}(C)$  of Eq. (25) is nonpositive for  $C \in \mathcal{C}$ . Also, every term  $\operatorname{sp}_{\mathcal{C}}(v)$  is nonpositive if  $v \in \overline{B}(\mathcal{C})$ . The only positive terms are  $\operatorname{sp}_{\mathcal{C}}(v) = 1$  for  $v \in S \cap B(\mathcal{C})$ , and  $\operatorname{sp}_{\mathcal{C}}(v) = 2$  for  $v \in S \setminus V(\mathcal{C})$ .

<span id="page-20-3"></span>Remark 8.3. Any S-closed constraint set C has  $\operatorname{sp}(C,S) \leq 2|S|$  by the previous remark.

**Definition 8.4** (Sparsity expansion). Let  $t \ge 0$  and  $\gamma > 0$ . A constraint set  $\mathcal{C}$  over V is  $(t, \gamma)$ -expanding if  $\operatorname{sp}(\mathcal{C}', S) \ge \gamma |\mathcal{C}'|$  for any S-closed t-small constraint subset  $\mathcal{C}' \subseteq \mathcal{C}$  and any  $S \subseteq V$ . An instance I is  $(t, \gamma)$ -expanding if its constraint set is.

<span id="page-20-4"></span>Remark 8.5. Suppose  $\tau = k - 1$ . Remark 8.2 and  $|V(C)| = k = \tau + 1$  imply  $\operatorname{sp}(\mathcal{C}, V(\mathcal{C})) = |B(\mathcal{C})|$ . The expansion condition is then equivalent to  $|B(\mathcal{C}')| \ge \tau |\mathcal{C}'|$  for t-small constraint subsets  $\mathcal{C}'$ . That means the factor graph of the instance is a (one-sided) unique-neighbor expander, also known as a boundary expander, when  $\tau = k - 1$ .

Remark 8.6. Sparsity expansion was introduced by [KMOW17] as "Plausibility Assumption." More precisely,  $(t, \gamma)$ -expansion of an instance  $I = (V, \mathcal{C})$  is equivalent to the factor graph of I satisfying their "Plausibility Assumption", when their  $(2 \cdot \text{SMALL}, \zeta) = (t, \gamma)$ . See [KMOW17, Remark 4.10 and "Plausibility Assumption, Restated"] for relevant definitions. Indeed, if Plausibility Assumption holds, then any  $S \subseteq V$  and any S-closed t-small  $\mathcal{C}' \subseteq \mathcal{C}$  corresponds to the  $(\tau + 1)$ -factor graph  $(\mathcal{C}', V(\mathcal{C}') \cap S)$ , whose plausibility implies  $\operatorname{sp}(\mathcal{C}', S) \geqslant \operatorname{sp}(\mathcal{C}', V(\mathcal{C}') \cap S) \geqslant \gamma |\mathcal{C}'|$ . Conversely, if I is  $(t, \gamma)$ -expanding, then any  $(\tau + 1)$ -factor graph  $H \stackrel{\text{def}}{=} (\mathcal{C}', S)$  with t-small  $\mathcal{C}'$  satisfies  $\operatorname{sp}(\mathcal{C}', S) \geqslant \gamma |\mathcal{C}'|$  because  $\mathcal{C}'$  is S-closed, and hence H is plausible.

We now define local closure [KMOW17, Definition 5.3] and recall some results in [KMOW17].

<span id="page-20-0"></span>**Definition 8.7** (Local closure). Given a variable subset  $S \subseteq V$ , a constraint set  $\mathcal{C}$  over V and a real number  $t \geqslant 0$ , the *t-local S-closure*  $\operatorname{cl}_S^t(\mathcal{C})$  of  $\mathcal{C}$  is the union of *t*-small *S*-closed  $\mathcal{C}' \subseteq \mathcal{C}$ .

**Definition 8.8.** Given an instance  $I = (V, \mathcal{C})$ , denote by  $\operatorname{cl}_S^t(I) \stackrel{\text{def}}{=} S \cup \operatorname{cl}_S^t(\mathcal{C})$  the subinstance with variable set  $S \cup V(\operatorname{cl}_S^t(\mathcal{C}))$  and constraint set  $\operatorname{cl}_S^t(\mathcal{C})$ .

<span id="page-21-4"></span>**Lemma 8.9.** For any t, any variable subsets  $T \subseteq S$ , any constraint set  $\mathcal{C}$ ,  $\operatorname{cl}_T^t(\mathcal{C}) \subseteq \operatorname{cl}_S^t(\mathcal{C})$ .

*Proof.* For any t-small T-closed  $\mathcal{C}' \subseteq \mathcal{C}$ ,  $\mathcal{C}' \subseteq \operatorname{cl}_S^t(\mathcal{C})$  by definition of  $\operatorname{cl}_S^t(\mathcal{C})$  and S-closedness of  $\mathcal{C}'$ . Taking the union over all t-small T-closed  $\mathcal{C}' \subseteq \mathcal{C}$ , we get  $\operatorname{cl}_T^t(\mathcal{C}) \subseteq \operatorname{cl}_S^t(\mathcal{C})$ .

<span id="page-21-2"></span>**Lemma 8.10.** Let  $S \subseteq V$ , and  $\mathcal{C} \stackrel{\text{def}}{=} \mathcal{C}_1 \cup \mathcal{C}_2$  be the union of two t-small S-closed constraint sets  $\mathcal{C}_1$  and  $\mathcal{C}_2$ . If  $\mathcal{C}$  is  $(2t, 2\gamma)$ -expanding and  $\operatorname{sp}(\mathcal{C}, S) \leqslant 2r\gamma$  for some  $r \leqslant t$ , then  $\mathcal{C}$  is r-small.

*Proof.*  $C_1$  and  $C_2$  are t-small, so C is 2t-small. C is S-closed by Lemma 5.2.  $\operatorname{sp}(C, S) \geq 2\gamma |C|$  by  $(2t, 2\gamma)$ -expansion of C. Therefore  $2r\gamma \geq \operatorname{sp}(C, S) \geq 2\gamma |C|$ , implying  $|C| \leq r$ .

<span id="page-21-3"></span>**Lemma 8.11.** For any  $r \leqslant t$ ,  $\operatorname{cl}_S^t(\mathcal{C})$  is r-small if  $\mathcal{C}$  is  $(2t, 2\gamma)$ -expanding and S is  $r\gamma$ -small.

Proof. By Remark 8.3,  $\operatorname{sp}(\mathcal{C}', S) \leq 2|S| \leq 2r\gamma$  for any S-closed  $\mathcal{C}'$ . The local closure  $\operatorname{cl}_S^t(\mathcal{C})$  is a finite union of t-small S-closed constraint subsets, so an induction using Lemma 8.10 and Lemma 5.2 implies  $\operatorname{cl}_S^t(\mathcal{C})$  is r-small and S-closed.

<span id="page-21-6"></span>**Lemma 8.12.** For any  $(2t, 2\gamma)$ -expanding C and any t-small  $C' \subseteq C$ , C' is dismissible.

*Proof.*  $\operatorname{cl}_{\emptyset}^{t}(\mathcal{C}) = \emptyset$  by Lemma 8.11 (with  $r \stackrel{\operatorname{def}}{=} 0, S \stackrel{\operatorname{def}}{=} \emptyset$ ). The next lemma implies  $\operatorname{cl}_{\emptyset}(\mathcal{C}') \subseteq \operatorname{cl}_{\emptyset}^{t}(\mathcal{C}) = \emptyset$ .

We also relate closure to local closure.

<span id="page-21-5"></span>**Lemma 8.13.** For any constraint sets  $C' \subseteq C$ , any variable subset T, if C' is t-small, then

<span id="page-21-9"></span>
$$\operatorname{cl}_T(\mathcal{C}') \subseteq \operatorname{cl}_T^t(\mathcal{C}).$$

*Proof.*  $\operatorname{cl}_T(\mathcal{C}')$  is T-closed by Lemma 5.2.  $\operatorname{cl}_T(\mathcal{C}') \subseteq \mathcal{C}' \subseteq \mathcal{C}$  by Lemma 5.3. Since  $\mathcal{C}'$  is t-small, so is  $\operatorname{cl}_T(\mathcal{C}')$ . The result follows by definition of  $\operatorname{cl}_T^t(\mathcal{C})$ .

<span id="page-21-7"></span>**Lemma 8.14.** For any constraint set C, any variable subsets  $T \subseteq S$ , if  $\operatorname{cl}_S^t(C)$  is t-small, then

(26) 
$$\operatorname{cl}_T(\operatorname{cl}_S^t(\mathcal{C})) = \operatorname{cl}_T^t(\mathcal{C}).$$

As a result,  $\operatorname{cl}_T(\operatorname{cl}_S^t(I)) = \operatorname{cl}_T^t(I)$  if  $\operatorname{cl}_S^t(\mathcal{C})$  is t-small.

*Proof.*  $\operatorname{cl}_T^t(\mathcal{C}) \subseteq \operatorname{cl}_S^t(\mathcal{C})$  by Lemma 8.9. Further,  $\operatorname{cl}_T^t(\mathcal{C})$  is T-closed by Lemma 5.2, so  $\operatorname{cl}_T^t(\mathcal{C}) \subseteq \operatorname{cl}_T(\operatorname{cl}_S^t(\mathcal{C}))$  by definition of  $\operatorname{cl}_T(\operatorname{cl}_S^t(\mathcal{C}))$ .

The reverse inclusion is Lemma 8.13 (with  $\mathcal{C}' \stackrel{\text{def}}{=} \operatorname{cl}_S^t(\mathcal{C})$ ).

#### <span id="page-21-0"></span>8.2. Hierarchy solution.

<span id="page-21-1"></span>**Proposition 8.15.** Suppose  $\sigma$  is a nontrivial scheme for dismissible instances and is compatible with closure. Let  $d \stackrel{\text{def}}{=} t\gamma$ . Then any  $(2t, 2\gamma)$ -expanding instance I has a level-d hierarchy solution s given by

<span id="page-21-8"></span>(27) 
$$s(S) \stackrel{\text{def}}{=} \pi_S \circ \sigma \circ \operatorname{cl}_S^t(I) \quad \text{for d-small } S \subseteq V.$$

*Proof.* For any d-small subset  $S \in \mathcal{S}_d$ , its closure  $\operatorname{cl}_S^t(\mathcal{C})$  is t-small by Lemma 8.11 (with  $r \stackrel{\text{def}}{=} t$ ), therefore  $\operatorname{cl}_S^t(\mathcal{C})$  is dismissible by Lemma 8.12 and  $\sigma \circ \operatorname{cl}_S^t(I)$  is well defined.

Since  $\operatorname{cl}_{\emptyset}^{t}(I)$  is dismissible, Lemma 8.14 and Definition 5.6 imply that  $\operatorname{cl}_{\emptyset}^{t}(I)$  is the null instance  $I_{\emptyset} \stackrel{\text{def}}{=} (\emptyset, \emptyset)$  that has no variable or constraint. Therefore  $s(I_{\emptyset}) = \pi_{\emptyset} \circ \sigma \circ \operatorname{cl}_{\emptyset}^{t}(I) = \sigma(I_{\emptyset}) = \mathbb{1}_{\mathbb{0}}$  and s is nontrivial.

By Lemma 3.3, it remains to show that s is consistent with projection. Indeed, for any  $S \in \mathcal{S}_d$ ,  $T \subseteq S$ ,

$$\pi_{S \to T} \circ s(S) \stackrel{(27)}{=} \pi_{S \to T} \circ \pi_{S} \circ \sigma \circ \operatorname{cl}_{S}^{t}(I) \stackrel{(5)}{=} \pi_{T} \circ \sigma \circ \operatorname{cl}_{S}^{t}(I) \stackrel{(11)}{=} \pi_{T} \circ \sigma \circ \operatorname{cl}_{T} \circ \operatorname{cl}_{S}^{t}(I)$$

$$\stackrel{(26)}{=} \pi_{T} \circ \sigma \circ \operatorname{cl}_{T}^{t}(I) \stackrel{(27)}{=} s(T).$$

A random CSP instance is expanding with high probability. The following result will be proved in Appendix B.2 and is a variant of [KMOW17, Theorem 4.12].

<span id="page-22-1"></span>**Lemma 8.16.** Let  $\lambda \stackrel{\text{def}}{=} \tau - 1 \geqslant 1$ ,  $0 < \gamma \leqslant \lambda/2$ ,  $\zeta \stackrel{\text{def}}{=} \Delta^{2/(\lambda - \gamma)}/n$ . Except with probability  $o_{\zeta;k}(1)$ , a random k-CSP instance with n vertices and  $m \stackrel{\text{def}}{=} \Delta n$  constraints is  $(t, \gamma)$ -expanding, where

$$t = \frac{n}{\Delta^{2/(\lambda - \gamma)}} \cdot \frac{1}{2^{O(k)}}.$$

We are now ready to prove Theorem 1.1.

**Theorem 1.1.** Let  $\tau \geq 2$ . For each elementary hierarchy (BW, LP, SDP, and AIP), if a k-CSP is  $\tau$ -wise neutral for the hierarchy, then except with probability  $o_{n;k}(1)$ , a random instance of the CSP with n variables and  $\Delta n$  constraints has a hierarchy solution of level  $\Omega_k(n/(\Delta^{2/(\tau-1)}\log \Delta))$ .

Proof. Fix  $\gamma \stackrel{\text{def}}{=} 1/\log \Delta$ ,  $\lambda \stackrel{\text{def}}{=} \tau - 1 \geqslant 1$ . We may assume  $\Delta^{2/\lambda} \log \Delta \leqslant n$ , for otherwise the level lower bound is trivial, as every hierarchy has a solution of level 0. Since  $\Delta^{2/(\lambda - 3/\log \Delta)} = \Theta(\Delta)$  for  $\lambda \geqslant 1$ , we have  $\zeta \stackrel{\text{def}}{=} \Delta^{2/(\lambda - 3\gamma)}/n = o_n(1)$ . Lemma 8.16 implies that except with probability  $o_{n;k}(1)$ , a random instance I is  $(2t, 3\gamma)$ -expanding, where  $t = n/(\Delta^{2/(\lambda - 3\gamma)}2^{O(k)}) = \Omega_k(n/\Delta^{2/\lambda})$ .

Proposition 8.15 further turns any nontrivial scheme  $\sigma$  of a hierarchy for dismissible instances that is compatible with closure into a level  $d \stackrel{\text{def}}{=} t \gamma$  hierarchy solution for I. For each elementary hierarchy except SDP, any  $\tau$ -wise neutral k-CSP has such a scheme  $\sigma$ ; (See also Lemmas 5.10 and 5.11.)

**BW:** It follows from Proposition 6.2.

**LP:** This is essentially [BGMT12, Lemma 3.2] or [KMOW17, Theorem 5.12]. See Lemma 10.4 below (with  $K = \emptyset$  and  $\mathcal{E} = \emptyset$  so that  $\underline{\text{cl}} = \text{cl}$ ) for a self-contained proof.

**AIP:** It follows from Proposition 7.10 and Theorem 7.12.

The SDP hierarchy requires additional work due to the extra constraint in Eq. (1). The SDP solution can be constructed by [KMOW17, Theorem 1.2]. See Theorem 11.26 and Lemma 11.27 below for a self-contained proof.

#### <span id="page-22-0"></span>8.3. SDP+AIP hierarchy solution for 4-SAT.

Previous LP and SDP lower bounds for k-SAT, starting with [BGMT12, Sch08], were all based on the k-XOR distribution — the uniform distribution over all assignments of even (or odd) parity. As discussed in the Introduction, such a solution cannot fool the LP+AIP hierarchy, because it strengthens every constraint into k-XOR, and AIP can refute unsatisfiable k-XOR instances.

In this subsection, we give an easy workaround for k-SAT whenever  $k \ge 4$ , by constructing a (k-2)-wise uniform distribution supported on all satisfying assignments of a k-SAT constraint (Lemma 8.17). Such a distribution implies the SDP hierarchy solution constructed in Theorem 1.1 induces an LP hierarchy solution that has full support on small closures (Definition 8.19). Together with (k-1)-wise neutrality for AIP (Proposition 4.4), k-SAT is (k-2)-wise neutral for SDP+AIP. This easily implies k-SAT fools the SDP+AIP hierarchy whenever  $k \ge 4$ .

The main result of this subsection, Theorem 8.21, will be subsumed by Theorem 1.2, whose proof will make up the rest of this paper. We include a proof of Theorem 8.21 because it highlights an interesting distinction between 3-SAT and 4-SAT: the latter is pairwise neutral for SDP+AIP but

the former is not. This means LP+AIP and SDP+AIP lower bounds for 4-SAT follow rather easily from our results so far, while those for 3-SAT need significantly more effort.

<span id="page-23-3"></span>**Lemma 8.17.** For every integer  $k \ge 4$ , every k-SAT constraint C has a (k-2)-wise uniform distribution  $\eta_C$  supported precisely on all satisfying assignments of C. That is,  $supp(\eta_C) = A_C$ .

*Proof.* Suppose C forbids the assignment  $b \in \mathbb{Z}_2^{V(C)}$ . Let  $\eta_C$  be the distribution of sampling a random satisfying assignment  $a \in A_C$  as follows:

- (1) Pick S uniformly at random among all  $S \subseteq V(C)$  of size k-1. Let  $T \stackrel{\text{def}}{=} V(C) \setminus S$ .
- (2) Pick  $a_T \in \mathbb{Z}_2^T$  uniformly at random.
- (3) Pick  $a_S$  from  $\mathbb{Z}_2^S$  as follows:
  - (a) If  $(a \oplus b)_T \neq 0$ , then  $a_S$  is uniform from  $\mathbb{Z}_2^S$ .
- (b) If  $(a \oplus b)_T = 0$ , then  $a_S$  is uniform from  $\mathbb{Z}_2^{\tilde{S}}$  conditioned on  $(a \oplus b)_S$  having odd parity. Because  $(a \oplus b)_T \neq 0$  (in Case (a)) or  $(a \oplus b)_S \neq 0$  (in Case (b)), assignment a satisfies C with probability 1. Every  $a \in A_C$  belongs to the support of  $\eta_C$ , because such assignment a satisfies  $(a \oplus b)_v = 1$  for some  $v \in V(C)$ , and there is a positive probability of choosing  $S \not\ni v$  from Step (1),  $a_T$  from Step (2), and  $a_S$  from Step (3a). Finally, let  $\eta_{C|S_0}$  denote the distribution of  $\eta_C$  conditioned on  $S = S_0$  in Step (1). Claim 8.18 implies  $\eta_{C|S_0}$  is (k-2)-wise uniform for every  $S_0$ , and therefore so is  $\eta_C$ , being a mixture of such distributions.

<span id="page-23-4"></span>**Claim 8.18.** For every  $S_0 \subseteq V(C)$  of size k-1, the conditional distribution  $\eta_{C|S_0}$  is (k-2)-wise uniform.

*Proof.* Fix any  $R \subseteq V(C)$  of size k-2. When choosing  $a_T$  in Step (2),  $a_{T \cap R}$  is uniform. Conditioned on  $a_T$ ,  $a_{S \cap R}$  is uniform because  $|S \cap R| \leq k-2$ , and the distributions of both (a) and (b) are (k-2)-wise uniform on S.

Our next definition concerns hierarchy solutions that have full support on small closures.

<span id="page-23-1"></span>**Definition 8.19** (Full support). Fix  $t \in \mathbb{N}$ . A level-d hierarchy solution has full support if  $\operatorname{supp}(s(S)) \supseteq \pi_S(A_J)$  for every d-small  $S \subseteq V$ , where  $J \stackrel{\text{def}}{=} \operatorname{cl}_S^t(I)$ .

<span id="page-23-2"></span>**Lemma 8.20.** Let  $s_{LP}$  and  $s_{AIP}$  be level-d solutions for LP and AIP hierarchies respectively. Suppose  $s_{LP}$  has full support. If  $s_{AIP}$  is constructed by Proposition 8.15 from  $\sigma_{AIP}$ , then  $s \stackrel{\text{def}}{=} (s_{LP}, s_{AIP})$  is a level-d solution for the LP+AIP hierarchy.

*Proof.* Given any d-small  $S \subseteq V$ , consider  $J \stackrel{\text{def}}{=} \operatorname{cl}_S^t(I)$ . Then

 $\operatorname{supp} \circ s_{\operatorname{AIP}}(S) \stackrel{(27)}{=} \operatorname{supp} \circ \pi_S \circ \sigma_{\operatorname{AIP}}(J) \stackrel{(53)}{\subseteq} \pi_S \circ \operatorname{supp} \circ \sigma_{\operatorname{AIP}}(J) \stackrel{(52)}{\subseteq} \pi_S \circ A_J \stackrel{(*)}{\subseteq} \operatorname{supp} \circ s_{\operatorname{LP}}(S),$  where (\*) is due to  $s_{\operatorname{LP}}$  having full support.

<span id="page-23-0"></span>**Theorem 8.21.** For any  $k \ge 4$ , except with probability  $o_{n;k}(1)$ , a random instance of 4-SAT with n variables and  $\Delta n$  constraints has an SDP+AIP hierarchy solution of level  $\Omega_{k,\Delta}(n)$ .

*Proof.* Let  $d'(n, k, \tau, \Delta)$  denote the level guaranteed by Theorem 1.1 (with  $\tau \stackrel{\text{def}}{=} k - 2$ ), and let  $d \stackrel{\text{def}}{=} d'/2$  be half of that.

Every k-SAT constraint C has a (k-2)-wise uniform distribution  $\eta_C$  supported on all satisfying assignments by Lemma 8.17. From this, Theorem 1.1 constructs a level-d SDP solution  $(\alpha_S)_S$ . The proof of Theorem 1.1 assigns the canonical distribution  $\mu_J$  ([KMOW17, Definition 5.10], equivalently our Definition 10.2) to the closure  $J \stackrel{\text{def}}{=} \operatorname{cl}_S^t(I)$  of every 2d-small subset  $S \subseteq V$ . Since  $\eta_C$  is supported on all satisfying assignments, the canonical distribution is supported on all satisfying assignments of J (Lemma 12.3). Therefore the level-2d LP solution  $(\mu_R)_R$  induced by  $(\alpha_S)_S$  satisfies Definition 8.19 and has full support on small closures.

k-SAT is also (k-1)-wise neutral for AIP by Proposition 4.4. Theorem 1.1 constructs a level-2d AIP solution  $(w_R)_R$ , using Proposition 8.15. Lemma 8.20 implies  $(\mu_R, w_R)_R$  is a level-2d LP+AIP hierarchy solution such that  $(\mu_R)_R$  is induced by the level-d SDP hierarchy solution  $(\alpha_S)_S$ .

## 9. Augmented closure

<span id="page-24-1"></span>A key idea towards the proof of Theorem 1.2 is augmented closure, made precise in this section. Throughout this section,  $K \subseteq V$  is a fixed variable subset.

<span id="page-24-0"></span>**Definition 9.1.** Given  $S \subseteq V$ , the *K*-augmented *S*-closure is  $\underline{\operatorname{cl}}_S \stackrel{\text{def}}{=} \operatorname{cl}_{S \cup K}$ . Further, given also  $t \in \mathbb{N}$ , the *K*-augmented *t*-local *S*-closure is  $\underline{\operatorname{cl}}_S^t \stackrel{\text{def}}{=} \operatorname{cl}_{S \cup K}^t$ .

We now weaken the compatibility requirement for schemes, by restricting the removed S-exterior constraint to be outside a constraint subset  $\mathcal{E}$ .

**Definition 9.2.** Let  $\mathcal{E} \subseteq \bigcup \mathcal{C}$  be a constraint subset. A scheme  $\sigma$  for a family  $\mathcal{C}$  of constraint sets is compatible with a neutral solution  $\nu$  outside  $\mathcal{E}$  if for any  $\mathcal{C} \in \mathcal{C}$ , any  $S \subseteq V(\mathcal{C})$ , any  $C \in \overline{R}_S(\mathcal{C}) \setminus \mathcal{E}$ ,

<span id="page-24-2"></span>(28) 
$$\pi_{V(\mathcal{C})\to S}(\sigma(\mathcal{C})) = \pi_{V(\mathcal{C})\to S}\left(\sigma(\mathcal{C}')\otimes \nu^{V(\mathcal{C})\setminus V(\mathcal{C}')}\right),$$

where  $\mathcal{C}' \stackrel{\text{def}}{=} \mathcal{C} \setminus \{C\}$ .

Lemma 5.11 upgrades "compatibility with constraint removal" into "compatibility with closure", by iteratively removing S-exterior constraints C. The next lemma shows that as long as the removed constraints C are all outside  $\mathcal{E}$ , we get a similar compatibility with closure property.

<span id="page-24-3"></span>**Lemma 9.3.** Let  $\sigma$  be a scheme for  $\mathcal{C}$  compatible with  $\nu$  outside  $\mathcal{E}$ . Then its extended scheme  $\sigma^*$  for  $\mathcal{I}(\mathcal{C})$  is compatible with augmented closure containing  $\mathcal{E}$ . That is, for every  $I = (U, \mathcal{C}) \in \mathcal{I}$  and  $S \subseteq U$ , if  $\mathcal{E} \subseteq \underline{\operatorname{cl}}_S(\mathcal{C})$ , then

(29) 
$$\pi_{U \to S}(\sigma(I)) = \pi_{V(\underline{\operatorname{cl}}_S(I)) \to S}(\sigma(\underline{\operatorname{cl}}_S(I))).$$

*Proof.* We prove by induction on  $C \in \mathcal{C}$  that for any instance I = (U, C), any  $S \subseteq U$ , if  $\mathcal{E} \subseteq \underline{\operatorname{cl}}_S(C)$ , then  $\pi_S(\sigma^*(I)) = \pi_S(\sigma^*(\underline{\operatorname{cl}}_S(I)))$ .

<span id="page-24-4"></span>**Base Case:**  $C = \underline{\operatorname{cl}}_S(C)$ . The result follows because  $C = \underline{\operatorname{cl}}_S(C)$ , so  $I = \underline{\operatorname{cl}}_S(I)$ .

Induction Step:  $\mathcal{C} \supseteq \underline{\operatorname{cl}}_S(\mathcal{C})$ . Let  $S' \stackrel{\operatorname{def}}{=} S \cup K$ . By Proposition 5.4 and Eq. (10),  $\mathcal{C} \supseteq R_{S'}(\mathcal{C}) \supseteq \operatorname{cl}_{S'}(\mathcal{C}) = \underline{\operatorname{cl}}_S(\mathcal{C})$ . Fix an arbitrary  $C \in \overline{R}_{S'}(\mathcal{C})$ . Then  $C \notin \mathcal{E}$ . Let  $\mathcal{C}' \stackrel{\operatorname{def}}{=} \mathcal{C} \setminus \{C\}$  and  $T \stackrel{\operatorname{def}}{=} S' \cap V(\mathcal{C})$ . Then  $C \in \overline{R}_T(\mathcal{C}) \setminus \mathcal{E}$ . Since  $\sigma$  is compatible with  $\nu$  outside  $\mathcal{E}$ ,

$$\pi_{S}(\sigma^{*}(I)) \stackrel{\text{(13)}}{=} \pi_{S} \left( \sigma(\mathcal{C}) \otimes \nu^{U \setminus V(\mathcal{C})} \right) \stackrel{\text{(51)}}{=} \pi_{T}(\sigma(\mathcal{C})) \otimes \nu^{S \setminus V(\mathcal{C})}$$

$$\stackrel{\text{(28)}}{=} \pi_{T} \left( \sigma(\mathcal{C}') \otimes \nu^{V(\mathcal{C}) \setminus V(\mathcal{C}')} \right) \otimes \nu^{S \setminus V(\mathcal{C}')}$$

$$\stackrel{\text{(51)}}{=} \pi_{S} \left( \sigma(\mathcal{C}') \otimes \nu^{(S \cup V(\mathcal{C})) \setminus V(\mathcal{C}')} \right) \stackrel{\text{(13)}}{=} \pi_{S}(\sigma^{*}(I')) \stackrel{\text{I.H.}}{=} \pi_{S}(\sigma^{*}(\underline{cl}_{S}(I'))),$$

where  $I' = (U, \mathcal{C}')$ . The desired result now follows from the fact that  $\underline{\operatorname{cl}}_S(\mathcal{C}') = \underline{\operatorname{cl}}_S(\mathcal{C})$  (and hence  $\underline{\operatorname{cl}}_S(I') = \underline{\operatorname{cl}}_S(I)$ ), which holds because (1)  $\mathcal{C}' \supseteq R_{S'}(\mathcal{C}) \supseteq \underline{\operatorname{cl}}_S(\mathcal{C}) = \underline{\operatorname{cl}}_S(\mathcal{C})$  and  $\underline{\operatorname{cl}}_S(\mathcal{C})$  is S'-closed, so  $\underline{\operatorname{cl}}_S(\mathcal{C}') = \underline{\operatorname{cl}}_S(\mathcal{C}') \supseteq \underline{\operatorname{cl}}_S(\mathcal{C})$ ; and (2) of Lemma 5.3.

**Definition 9.4.** A constraint solution  $\eta: (C \in \mathcal{C}) \to \mathcal{M}^{A_C}$  is  $\tau$ -wise  $\nu$ -neutral outside  $\mathcal{E}$  if  $\eta(C)$  is  $\tau$ -wise  $\nu$ -neutral for every  $C \in \mathcal{C} \setminus \mathcal{E}$ .

<span id="page-24-6"></span><span id="page-24-5"></span>**Lemma 9.5.** For any constraint set C, any variable subsets  $T \subseteq S$ , if  $\underline{\operatorname{cl}}_S^t(C)$  is t-small, then

$$\underline{\operatorname{cl}}_T(\underline{\operatorname{cl}}_S^t(\mathcal{C})) = \underline{\operatorname{cl}}_T^t(\mathcal{C}).$$

As a result,  $\underline{\operatorname{cl}}_T(\underline{\operatorname{cl}}_S^t(I)) = \underline{\operatorname{cl}}_T^t(I)$  if  $\underline{\operatorname{cl}}_S^t(\mathcal{C})$  is t-small.

*Proof.* Let *S* def = *S ∪ K, T* def = *T ∪ K*. The desired equality now becomes

$$\operatorname{cl}_{\underline{T}}(\operatorname{cl}_{\underline{S}}^t(\mathcal{C})) = \operatorname{cl}_{\underline{T}}^t(\mathcal{C}),$$

which holds by [Lemma 8.14](#page-21-7) and our assumption that cl*<sup>t</sup> S* (*C*) = cl*<sup>t</sup> S* (*C*) is *t*-small. □

# 10. LP scheme

<span id="page-25-1"></span>Towards proving [Theorem 1.2,](#page-2-0) we construct LP solutions based on augmented closure defined in [Section 9](#page-24-1). Throughout this section, we consider a fixed *τ* -wise uniform CSP (*D,* R). Recall that the neutral solution *ν* = *ν*LP maps every *v ∈ V* to the uniform distribution over *D{v}* .

**Definition 10.1.** Given a constraint set *C*, a *family η of satisfying distributions for C* maps every *C ∈ C* to a distribution *η*(*C*) *∈* ∆(*AC*) of satisfying assignments of *C*.

Recall the following distribution of assignments on an instance *I*: ([[BGMT12,](#page-43-2) Section 3.2] and [\[KMOW17,](#page-44-0) Definition 5.10])

<span id="page-25-0"></span>**Definition 10.2** (Canonical distribution)**.** Suppose *I* = (*V, C*) is an instance and *η* a family of satisfying distributions for *C*. Define the *canonical distribution µ<sup>I</sup>* to be the following distribution over satisfying assignments *a ∈ A<sup>V</sup>* (*I*) :

- (1) Draw *a<sup>v</sup>* uniformly from *D{v}* independently for isolated variable *v ∈ V \ V* (*C*); and
- (2) Draw *a<sup>V</sup>* (*C*) from *η*(*C*) independently for *C ∈ C*, conditioned on agreeing at their common variables in *B*(*C*).

Given a constraint set *C*, define *µ<sup>C</sup>* def = *µ<sup>I</sup>* , where *I* def = (*V* (*C*)*, C*) is the instance consisting of *C*.

<span id="page-25-2"></span>**Definition 10.3** (*η*-satisfiable)**.** An assignment *a ∈ D<sup>V</sup>* (*C*) *η-satisfies* a constraint set *C* if *a<sup>V</sup>* (*C*) *∈* supp(*η*(*C*)) for every *C ∈ C*. *C* is *η-satisfiable* if some assignment *a η*-satisfies *C*. An instance *I* is *η-satisfiable* if its constraint set is.

The canonical distribution *µ<sup>I</sup>* in [Definition 10.2](#page-25-0) is well defined if (and only if) *I* is *η*-satisfiable. The next lemma generalizes [\[KMOW17](#page-44-0), Theorem 5.12] and [[BGMT12,](#page-43-2) Lemma 3.2], allowing *η* to be not *τ* -wise uniform on a constraint subset *E*, provided the augmented closure contains *E*.

<span id="page-25-3"></span>**Lemma 10.4.** *Suppose an instance I* = (*V, C*) *is η-satisfiable. Suppose η is τ -wise uniform outside E ⊆ C. For any S ⊆ V , if E ⊆* cl*S*(*C*)*, then the marginal of µ<sup>I</sup> on S equals the marginal of µ*cl*<sup>S</sup>* (*I*) *on S. That is, πS*(*µ<sup>I</sup>* ) = *π<sup>S</sup> µ*cl*<sup>S</sup>* (*I*) *.*

*Proof. C 0 7→ µ<sup>C</sup> <sup>0</sup>* is a scheme for constraint subsets *C <sup>0</sup> ⊆ C*. [Proposition 10.5](#page-25-4) below says that this scheme is compatible with the uniform neutral solution outside *E*.

By [Lemma 9.3,](#page-24-3) the extended scheme *J 7→ µ<sup>J</sup>* for subinstances *J ⊆ I* is compatible with augmented closure containing *E*. Then [Eq. \(29\)](#page-24-4) implies the desired result. □

<span id="page-25-4"></span>**Proposition 10.5.** *For any η-satisfiable constraint set C, any S ⊆ V* (*C*)*, any C ∈ RS*(*C*) *\ E, let V* def = *V* (*C*)*, C <sup>0</sup>* def = *C \ {C <sup>0</sup>}, T* def = *V* (*C 0* ) *∪ S. Then π<sup>T</sup>* (*µC*) = *µ<sup>C</sup> <sup>0</sup> ⊗ ν S\V* (*C 0* ) *.*

*Proof.* By [Definition 10.2,](#page-25-0) for every *a ∈ D<sup>V</sup>* ,

$$\mu_{\mathcal{C}}(a) = \frac{1}{Z_{\mathcal{C}}} \prod_{C' \in \mathcal{C}} \eta(C') \left( a_{V(C')} \right), \quad \text{where } Z_{\mathcal{C}} \stackrel{\text{def}}{=} \sum_{a \in D^{V}} \prod_{C' \in \mathcal{C}} \eta(C') \left( a_{V(C')} \right),$$

and *Z<sup>C</sup> >* 0 because *C* is *η*-satisfiable. Now for every *b ∈ D<sup>T</sup>* ,

(31) 
$$\pi_T(\mu_{\mathcal{C}})(b) = \sum_{\substack{a \in D^V \\ a_T = b}} \mu_{\mathcal{C}}(a) = \frac{1}{Z_{\mathcal{C}}} \prod_{C' \in \mathcal{C}'} \eta(C') \left( b_{V(C')} \right) \cdot \sum_{\substack{a \in D^V \\ a_T = b}} \eta(C) \left( a_{V(C)} \right).$$

Let  $U \stackrel{\text{def}}{=} V(C) \cap T = V(C) \cap (S \cup \overline{B}(C))$ . Since  $C \notin R_S(C)$ ,  $|U| \leqslant \tau$ . Also  $C \notin \mathcal{E}$  implies  $\eta(C)$  is  $\tau$ -wise uniform. Thus

(32) 
$$\sum_{\substack{a \in D^V \\ a_T = b}} \eta(C) \left( a_{V(C)} \right) = \pi_U(\eta(C))(b_U) = \frac{1}{|D^U|},$$

which is independent of b. Therefore  $\pi_T(\mu_{\mathcal{C}})(b)$  is proportional to  $\prod_{C' \in \mathcal{C}'} \eta(C') \left(b_{V(C')}\right)$ , to which

 $\mu'(b)$  is also proportional, where  $\mu' \stackrel{\text{def}}{=} \mu_{\mathcal{C}'} \otimes \nu^{S \setminus V(\mathcal{C}')}$ . Thus  $\pi_T(\mu_{\mathcal{C}}) = \mu'$ .

<span id="page-26-2"></span>**Proposition 10.6.** Let  $\eta$  be a family of satisfying distributions for a constraint set C. Suppose C is dismissible with respect to some  $\tau \in \mathbb{N}$ , and  $\operatorname{supp}(\eta(C))$  is  $\tau$ -wise neutral in the BW hierarchy for  $C \in C$ . Then C is  $\eta$ -satisfiable.

*Proof.* Strengthen every constraint C = (S, R) in  $\mathcal{C}$  to  $C' \stackrel{\text{def}}{=} (S, \text{supp}(\eta(C)))$  to get the new constraint set  $\mathcal{C}' \stackrel{\text{def}}{=} \{C' \mid C \in \mathcal{C}\}$ . Applying Corollary 6.3 to  $\mathcal{C}'$ , the desired conclusion follows, because any assignment that satisfies  $\mathcal{C}'$   $\eta$ -satisfies  $\mathcal{C}$ .

<span id="page-26-4"></span>**Proposition 10.7.** If  $\eta$  is a family of  $\tau$ -wise uniform satisfying distributions for a dismissible constraint set C then C is  $\eta$ -satisfiable.

*Proof.* For every  $C \in \mathcal{C}$ , since  $\eta(C)$  is  $\tau$ -wise uniform for LP,  $\operatorname{supp}(\eta(C))$  is  $\tau$ -wise neutral for BW. The result now follows from Proposition 10.6.

#### 11. SDP SOLUTION

<span id="page-26-1"></span>Towards proving Theorem 1.2, we construct SDP solutions for  $\tau$ -wise uniform CSP instances. Our SDP solution is heavily inspired by [KMOW17] and reuses many of their ideas. Our presentation is significantly different, more modular, and shorter.

Throughout this section, fix an instance  $I = (V, \mathcal{C}), \ \tau \in \mathbb{N}$  and  $\eta : (C \in \mathcal{C}) \to \Delta(A_C)$  so that  $\eta$  is  $\tau$ -wise uniform outside  $\mathcal{E} \subseteq \mathcal{C}$ . Also fix a constraint size bound  $t \in \mathbb{N}$  and a variable subset size bound  $d \in \mathbb{N}$ . Choose  $K \subseteq V$  so that the K-augmented local closure  $\underline{\operatorname{cl}}_{\emptyset}^t(\mathcal{C})$  contains  $\mathcal{E}$ , and therefore  $\emptyset \subseteq \underline{\operatorname{cl}}_{\emptyset}^t(\mathcal{C}) \subseteq \underline{\operatorname{cl}}_{S}^t(\mathcal{C})$  for any  $S \subseteq V$  by Lemma 8.9.

Readers interested only in SDP solutions without full support can take  $K = \emptyset$  and  $\mathcal{E} = \emptyset$ . In this special case K-augmented local closures  $\underline{\operatorname{cl}}_S^t$  are simply usual local closures  $\operatorname{cl}_S^t$ . The general case  $K \neq \emptyset$  is only needed for SDP solutions with full support.

#### <span id="page-26-0"></span>11.1. Ancestor closure.

Crucial to lower bounds in other hierarchies is the notion of closure that captures constraints (and variables) affecting the local solution on a subset S. Closure alone cannot capture all the constraints affecting the local SDP solution on S. [KMOW17] introduced witness for this reason. We now introduce a simplification of witness that we call ancestor closure  $\underline{\operatorname{cl}}_{A(S)}^t$ .

**Definition 11.1.** Given a family  $\mathcal{A} \subseteq \mathcal{P}(V)$  of subsets of variables, define the augmented local  $\mathcal{A}$ -closure  $\underline{\mathbf{cl}}_{\mathcal{A}}^t \stackrel{\text{def}}{=} \underline{\mathbf{cl}}_{\mathcal{U}}^t$ , where  $U \stackrel{\text{def}}{=} \bigcup \mathcal{A} \subseteq V$  is the union of the subsets in  $\mathcal{A}$ .

**Definition 11.2** (Embeddable). Given variable subsets  $S, T \subseteq V$  of an instance  $I = (V, \mathcal{C}), T$  is embeddable into S if there are |T| vertex-disjoint paths<sup>7</sup> from T to S in  $\underline{\operatorname{cl}}_{\{S,T\}}^t(I)$ . Write  $T \mapsto S$  if T is embeddable into S.

**Definition 11.3** (Ancestor). Let  $\leadsto$  be the transitive closure of the binary relation  $\rightarrowtail$ . Let  $\mathcal{A}(S) \stackrel{\text{def}}{=} \{T \mid T \leadsto S\}$  be the family of ancestors of S for  $S \subseteq V$ .

<span id="page-26-3"></span><sup>&</sup>lt;sup>7</sup>A path p in a hypergraph H is a sequence of distinct vertices such that every two consecutive vertices in p both belong to some common hyperedge in H.

 $\mathcal{A}(S)$  contains only subsets T no bigger than S, because only such T is embeddable into S. Also note that  $S \mapsto S$  for any  $S \subseteq V$ .

In other words, the ancestors  $\mathcal{A}(S)$  of S transitively include  $T \subseteq V$  maximally connected to S. And the ancestor closure  $\underline{\operatorname{cl}}_{\mathcal{A}(S)}^t$  is the (local augmented) closure of all ancestors of S combined.

Let  $\Gamma \stackrel{\text{def}}{=} \mathcal{S}_d / \sim$  be the collection of equivalence classes of d-small variable subsets, where subsets S and T are equivalent if  $\mathcal{A}(S) = \mathcal{A}(T)$ . For every  $\mathcal{Q} \in \Gamma$ , define  $\mathcal{A}(\mathcal{Q}) \stackrel{\text{def}}{=} \mathcal{A}(S)$  for any  $S \in \mathcal{Q}$ .

<span id="page-27-5"></span>Remark 11.4. Equivalently, given an instance I, define a directed graph  $G_d$  on node set  $S_d$  with directed edge set  $\mapsto \cap S_d^2$ . Then  $T \rightsquigarrow S$  if and only if  $G_d$  has a path from T to S, and  $\Gamma$  is the collection of strongly connected components of  $G_d$ .

## <span id="page-27-0"></span>11.2. Orthogonal decomposition.

Rather than using the global Gram–Schmidt procedures in [BCK15, KMOW17], we instead construct an explicit orthogonal decomposition for the vector space of small juntas.

**Definition 11.5.** Given  $S \subseteq V$ , let  $Y_S \subseteq \mathbb{R}^{D^V}$  be the vector space of S-juntas, consisting of functions  $f: D^V \to \mathbb{R}$  depending only on S (that is, there exists  $g: D^S \to \mathbb{R}$  such that  $f(a) = g(a_S)$  for  $a \in D^V$ ). Given a family  $\mathcal{Q} \subseteq \mathcal{P}(V)$  of subsets of variables, define  $Y_{\mathcal{Q}} \stackrel{\text{def}}{=} \sum_{S \in \mathcal{Q}} Y_S$  as the span of S-juntas over  $S \in \mathcal{Q}$ .

The subspace  $Y_S$  of S-juntas coincides with the span of indicators  $\mathbb{1}_a \in \mathbb{R}^{D^V}$  over partial assignments  $a \in D^S$  to S.

Our SDP solution builds upon an orthogonal decomposition for  $Y_{\mathcal{S}_d}$ . Our decomposition is inspired by Efron–Stein's, which we now recall.

Below when we consider the inner product, orthogonality, and orthogonal projection "under a distribution  $\mu$ ," we mean "in the real Hilbert space  $L^2(\mu)$  of (equivalence classes of square integrable) functions with respect to  $\mu$ ."

<span id="page-27-2"></span>**Definition 11.6** (Efron–Stein [Mos10, Definition 2.10 rephrased]). Let  $\nu^V$  be any product distribution over  $D^V$  as in Eq. (7). Given a subset  $S \subseteq V$ , define  $Z_S$  to be the subspace of  $Y_S$  orthogonal to all the subspaces of proper subsets of S:

<span id="page-27-4"></span>
$$Z_S \stackrel{\text{def}}{=} Y_S \cap Y_{\mathcal{P}^*(S)}^{\perp} \quad \text{under } \nu^S,$$

where  $\mathcal{P}^*(S) \stackrel{\text{def}}{=} \mathcal{P}(S) \setminus \{S\}$ . The subspaces  $\{Z_S \mid S \subseteq V\}$  are mutually orthogonal under  $\nu^V$  and together they span  $L^2(\nu^V)$ . The Efron–Stein decomposition is the orthogonal decomposition

(33) 
$$L^{2}(\nu^{V}) = \bigoplus_{S \subseteq V} Z_{S} \quad \text{under } \nu^{V}.$$

When  $D = \mathbb{Z}_2$  and  $\nu$  is uniform over D, the Efron–Stein decomposition coincides with the discrete Fourier decomposition for functions on the Boolean domain, and every  $Z_S$  is spanned by the Fourier character  $\chi_S$ .

**Definition 11.7.** Given a family  $\mathcal{A} \subseteq \mathcal{P}(V)$  of subsets of variables, define  $\mu_{\mathcal{A}} \stackrel{\text{def}}{=} \mu_{J}$  to be the canonical distribution on the  $\mathcal{A}$ -closure  $J \stackrel{\text{def}}{=} \underline{\operatorname{cl}}_{\mathcal{A}}^{t}(I)$  of I. Define the inner product

<span id="page-27-1"></span>(34) 
$$\langle f, g \rangle_{\mathcal{A}} \stackrel{\text{def}}{=} \underset{\mu_{\mathcal{A}}}{\mathbb{E}} [fg] \quad \text{for } f, g \in Y_{\mathcal{A}}.$$

Intuitively, the augmented local  $\mathcal{A}$ -closure  $\underline{\operatorname{cl}}_{\mathcal{A}}^{t}(I)$  of I is the smallest subinstance J whose canonical distribution  $\mu_{J}$  correctly defines an inner product on  $Y_{\mathcal{A}}$ , provided  $\underline{\operatorname{cl}}_{\mathcal{A}}^{t}(I)$  is  $\eta$ -satisfiable so that  $\mu_{\mathcal{A}}$  is well defined.

<span id="page-27-3"></span>We implicitly make the following assumption for the rest of this subsection:

**Assumption 11.8** (Small satisfiable closure).  $\underline{\operatorname{cl}}_{\mathcal{A}(S)}^t(\mathcal{C})$  is t-small and  $\eta$ -satisfiable for every  $S \in \mathcal{S}_{2d}$ .

This assumption ensures that all the distributions  $\mu_{\mathcal{A}(S)}$  and  $\mu_{\{S,T\}}$  considered below are well defined for  $S, T \in \mathcal{S}_d$ . As such, Eq. (34) is a genuine inner product on  $Y_{\mathcal{A}(S)} \subseteq L^2(\mu_{\mathcal{A}(S)})$ .

Analogous to Efron–Stein, we decompose  $Y_{\mathcal{S}_d}$  into orthogonal subspaces, replacing the inclusion relationship of subsets by that of ancestors.

**Definition 11.9.** Given  $Q \in \Gamma$ , define  $\mathcal{A}^*(Q) \stackrel{\text{def}}{=} \mathcal{A}(Q) \setminus Q$  to be the family of proper ancestors of Q. Also define  $X_Q$  to be the subspace of  $Y_Q$  orthogonal to the subspaces of proper ancestors:

<span id="page-28-1"></span>(35) 
$$X_{\mathcal{Q}} \stackrel{\text{def}}{=} Y_{\mathcal{Q}} \cap Y_{\mathcal{A}^*(\mathcal{Q})}^{\perp} \quad \text{under } \mu_{\mathcal{A}(\mathcal{Q})}.$$

Given  $Q \in \Gamma$ , let  $\Gamma(Q) \stackrel{\text{def}}{=} \{ \mathcal{R} \in \Gamma \mid \mathcal{A}(\mathcal{R}) \subseteq \mathcal{A}(Q) \}$  be the equivalence classes of ancestors contained in Q's ancestors. In the next subsection, we will construct the *local* orthogonal decomposition

<span id="page-28-5"></span>(36) 
$$Y_{\mathcal{A}(\mathcal{Q})} = \bigoplus_{\mathcal{R} \in \Gamma(\mathcal{Q})} X_{\mathcal{R}} \quad \text{under } \mu_{\mathcal{A}(\mathcal{Q})}.$$

We will also construct a *qlobal* orthogonal decomposition over *all* equivalence classes:

<span id="page-28-0"></span>(37) 
$$Y_{\mathcal{S}_d} = \bigoplus_{\mathcal{R} \in \Gamma} X_{\mathcal{R}} \quad \text{under } (\cdot, \cdot)_d,$$

where  $(\cdot,\cdot)_d$  is the bilinear extension of the local inner products  $\langle\cdot,\cdot\rangle_{\{S,T\}}$  to  $Y_{\mathcal{S}_d}$ . That is,

<span id="page-28-2"></span>(38) 
$$(f,g)_d = \langle f, g \rangle_{\{S,T\}} \stackrel{\text{(34)}}{=} \underset{\mu_{\{S,T\}}}{\mathbb{E}} [fg] \quad \text{for } f \in Y_S, g \in Y_T, S, T \in \mathcal{S}_d,$$

and  $(\cdot,\cdot)_d$  is extended to the span  $Y_{\mathcal{S}_d}$  of d-juntas via bilinearity:

<span id="page-28-3"></span>(39) 
$$\left(\sum_{P\in\mathcal{P}} f_P, \sum_{Q\in\mathcal{Q}} g_Q\right)_d = \sum_{P\in\mathcal{P}, Q\in\mathcal{Q}} (f_P, g_Q)_d \quad \text{for } f_P, g_Q\in Y_{\mathcal{S}_d}, \text{ any finite } \mathcal{P}, \mathcal{Q}.$$

The symmetric bilinear form  $(\cdot, \cdot)_d$  is called pseudo-expectation in [KMOW17, Definition 5.15]. We will justify Eq. (37) by showing that subspaces  $X_{\mathcal{R}}$  and  $X_{\mathcal{Q}}$  are orthogonal under  $(\cdot, \cdot)_d$  for distinct  $\mathcal{R}, \mathcal{Q} \in \Gamma$ . This in turn implies  $(\cdot, \cdot)_d$  is positive-semidefinite and hence a semi-inner product.

Remark 11.10. If  $I = (V, \emptyset)$  is an empty instance with no constraint, then our subspaces  $\{X_{\mathcal{Q}} \mid \mathcal{Q} \in \Gamma\}$  in Eq. (35) coincides with the Efron–Stein subspaces  $\{Z_S \mid S \subseteq V\}$  in Definition 11.6. Indeed, since I has no constraint, T is embeddable into S if and only if  $T \subseteq S$ . Every equivalence class  $\mathcal{Q}$  contains exactly one subset S, so that  $\mathcal{A}(\mathcal{Q}) = \mathcal{P}(S)$  and  $\mathcal{A}^*(\mathcal{Q}) = \mathcal{P}^*(S)$ . Assumption 11.8 holds even for d = |V|. Also,  $\mu_I = \nu^V$  is uniform over  $D^V$ , and  $(\cdot, \cdot)_d = \langle \cdot, \cdot \rangle_{\nu^V}$ . Our orthogonal decomposition of small juntas in Eq. (37) reduces to the Efron–Stein decomposition.

#### 11.3. Proof of orthogonal decomposition.

We continue to implicitly assume Assumption 11.8 in this subsection.

The next lemma ensures  $(\cdot, \cdot)_d$  is well defined.

**Lemma 11.11.** For any  $S \in \mathcal{S}_{2d}$ , any  $\mathcal{R} \subseteq \mathcal{Q} \stackrel{\text{def}}{=} \mathcal{A}(S)$ , any  $f, g \in Y_{\mathcal{R}}$ ,

$$\langle f, g \rangle_{\mathcal{R}} = \langle f, g \rangle_{\mathcal{Q}}.$$

*Proof.* Write  $\mu(J)$  to mean  $\mu_J$  for any instance J. Then

<span id="page-28-4"></span>
$$\langle f,g\rangle_{\mathcal{R}} \overset{(34)}{=} \underset{\mu(\underline{\operatorname{cl}}_{\mathcal{R}}^{t}(I))}{\mathbb{E}} [fg] \overset{(*)}{=} \underset{\mu(\underline{\operatorname{cl}}_{\mathcal{R}}^{t}(\underline{\operatorname{cl}}_{\mathcal{O}}^{t}(I)))}{\mathbb{E}} [fg] \overset{(\star)}{=} \underset{\mu(\underline{\operatorname{cl}}_{\mathcal{O}}^{t}(I))}{\mathbb{E}} [fg] \overset{(34)}{=} \langle f,g\rangle_{\mathcal{Q}},$$

where (\*) is Lemma 9.5 (with  $S \stackrel{\text{def}}{=} \bigcup \mathcal{Q}, T \stackrel{\text{def}}{=} \bigcup \mathcal{R}$ ) and (\*) is Lemma 10.4 (with  $S \stackrel{\text{def}}{=} \bigcup \mathcal{R}, I \stackrel{\text{def}}{=} \underbrace{\cup \mathcal{L}_{\mathcal{O}}^t(I)}$ , together with the assumption that  $\mathcal{E} \subseteq \underline{\operatorname{cl}}_{\mathcal{S}}^t(\mathcal{C})$ ).

**Lemma 11.12.** There is a bilinear form  $(\cdot, \cdot)_d$  satisfying (38) and (39).

*Proof.* Construct  $(\cdot, \cdot)_d$  using the Efron–Stein decomposition  $Y_{\mathcal{S}_d} = \bigoplus_{S \in \mathcal{S}_d} Z_S$  for the span of d-juntas.

For  $f, g \in Y_{\mathcal{S}_d}$ , using Eq. (33), expand  $f = \sum_{S \in \mathcal{S}_d} f_S$  and  $g = \sum_{T \in \mathcal{S}_d} g_T$  (where  $f_S \in Z_S, g_T \in Z_T$ ), and define

$$(41) (f,g)_d \stackrel{\text{def}}{=} \sum_{S,T \in \mathcal{S}_d} \langle f_S, g_T \rangle_{\{S,T\}}.$$

Bilinearity Eq. (39) follows because the definition of  $(\cdot, \cdot)_d$  in Eq. (41) is bilinear.

<span id="page-29-0"></span>For any 
$$S \in \mathcal{S}_{2d}$$
, any  $f, g \in Y_{\mathcal{A}(S)}$ , using Eq. (33), expand  $f = \sum_{R \in \mathcal{A}(S)} f_R$  and  $g = \sum_{T \in \mathcal{A}(S)} g_T$ 

(where  $f_R \in Z_R, g_T \in Z_T$ ), and

<span id="page-29-1"></span>
$$(42) (f,g)_d \stackrel{(41)}{=} \sum_{R,T \in \mathcal{A}(S)} \langle f_R, g_T \rangle_{\{R,T\}} \stackrel{(40)}{=} \sum_{R,T \in \mathcal{A}(S)} \langle f_R, g_T \rangle_{\mathcal{A}(S)} \stackrel{(*)}{=} \langle f, g \rangle_{\mathcal{A}(S)},$$

where (\*) uses bilinearity of  $\mathcal{A}(S)$ 's inner product. Eqs. (40) and (42) also imply Eq. (38).

<span id="page-29-4"></span><span id="page-29-2"></span>**Lemma 11.13.** For any  $Q \in \Gamma$ ,

(43) 
$$\sum_{\mathcal{R}\in\Gamma(\mathcal{Q})} X_{\mathcal{R}} = Y_{\mathcal{A}(\mathcal{Q})}.$$

*Proof.* For any  $\mathcal{R} \in \Gamma(\mathcal{Q})$ , we have  $X_{\mathcal{R}} \subseteq Y_{\mathcal{R}} \subseteq Y_{\mathcal{A}(\mathcal{Q})}$ . Taking the span of  $X_{\mathcal{R}}$  over all  $\mathcal{R} \in \Gamma(\mathcal{Q})$ , we get the " $\subseteq$ " inclusion of Eq. (43).

We now prove the " $\supseteq$ " inclusion by induction, assuming the result holds for every proper ancestor component of  $\mathcal{Q}$ . Note that  $\{\emptyset\} \in \Gamma(\mathcal{Q})$  for every  $\mathcal{Q} \in \Gamma$  because  $\emptyset \mapsto S$  for every  $S \subseteq V$ , and  $T \mapsto \emptyset$  implies  $T = \emptyset$ . Let  $\Gamma^*(\mathcal{Q}) \stackrel{\text{def}}{=} \Gamma(\mathcal{Q}) \setminus \{\mathcal{Q}\}$  be the proper ancestor components of  $\mathcal{Q}$ .

Base Case:  $Q = \{\emptyset\}$ . Then  $A(Q) = \{\emptyset\}$ ,  $A^*(Q) = \emptyset$ , and  $Y_{A^*(Q)} = \{0\}$ . Thus  $X_{\emptyset} = Y_{\emptyset} \cap Y_{A^*(Q)}^{\perp} = Y_{\emptyset} \cap \{0\}^{\perp} = Y_{\emptyset}$ .

**Induction Step:**  $Q \neq \{\emptyset\}$ . We have

$$Y_{\mathcal{A}(\mathcal{Q})} = Y_{\mathcal{Q}} + Y_{\mathcal{A}^*(\mathcal{Q})} \stackrel{(*)}{=} X_{\mathcal{Q}} + Y_{\mathcal{A}^*(\mathcal{Q})} = X_{\mathcal{Q}} + \sum_{S \in \mathcal{A}^*(\mathcal{Q})} Y_S \stackrel{(\star)}{\subseteq} X_{\mathcal{Q}} + \sum_{S \in \Gamma^*(\mathcal{Q})} Y_{\mathcal{A}(S)},$$

where (\*) uses the orthogonal decomposition  $Y_{\mathcal{Q}} = X_{\mathcal{Q}} \oplus Y_{\mathcal{A}^*(\mathcal{Q})}$  under  $\mu_{\mathcal{A}(\mathcal{Q})}$ , and (\*) uses the fact that every  $S \in \mathcal{A}^*(\mathcal{Q})$  belongs to a unique  $S \in \Gamma^*(\mathcal{Q})$ . By Induction Hypothesis for S, and using  $\Gamma(S) \subseteq \Gamma^*(\mathcal{Q})$ ,

$$Y_{\mathcal{A}(\mathcal{Q})} \subseteq X_{\mathcal{Q}} + \sum_{\mathcal{S} \in \Gamma^*(\mathcal{Q})} \sum_{\mathcal{R} \in \Gamma(\mathcal{S})} X_{\mathcal{R}} \subseteq X_{\mathcal{Q}} + \sum_{\mathcal{R} \in \Gamma^*(\mathcal{Q})} X_{\mathcal{R}} = \sum_{\mathcal{R} \in \Gamma(\mathcal{Q})} X_{\mathcal{R}}.$$

<span id="page-29-5"></span>Corollary 11.14.  $\sum_{\mathcal{R} \in \Gamma} X_{\mathcal{R}} = Y_{\mathcal{S}_d}$ .

Proof. 
$$Y_{\mathcal{S}_d} = \sum_{\mathcal{Q} \in \Gamma} Y_{\mathcal{Q}} \stackrel{(43)}{=} \sum_{\mathcal{Q} \in \Gamma} \sum_{\mathcal{R} \in \Gamma(\mathcal{Q})} X_{\mathcal{R}} = \sum_{\mathcal{R} \in \Gamma} X_{\mathcal{R}}.$$

<span id="page-29-3"></span>Recall that given vertex subsets R, S, T of a hypergraph H, R is an (S, T)-separator if every path in H from S to T contains some vertex in R.

**Lemma 11.15** (Implicit in [KMOW17, Lemma 6.14]). Let S, T be subsets of variables of an instance J = (V, C), and R be an (S, T)-separator in J. Consider picking a random assignment b from  $\mu_J$ . Then  $b_S$  and  $b_T$  are conditionally independent given  $b_R$ .

*Proof.* Let  $V_S$  be the set of vertices in  $J \setminus R$  reachable from S. Define  $V_T$  similarly.  $V_T$  is disjoint from  $V_S$  since R is a separator.

Further, no constraint  $C \in \mathcal{C}$  contains both  $u \in V_S$  and  $v \in V_T$ , for otherwise  $J \setminus R$  has a path from S to T (via u and v), contradicting the assumption that R is an (S, T)-separator.

Define  $C_T \stackrel{\text{def}}{=} \{C \in \mathcal{C} \mid C \ni v \text{ for some } v \in V_T\}$ . Then  $V_T \cup C_T$  contains no vertex in  $V_S$ .

Let  $\mu_R$  be the marginal distribution of  $b_R$  (and likewise for  $\mu_S, \mu_T$ ), and  $\mu_{S|R}$  be the conditional distribution of  $b_S$  given  $b_R$  (and likewise for  $\mu_{T|RS}, \mu_{ST|R}$ ). Then  $\mu_{ST|R} = \mu_{S|R}\mu_{T|RS}$ .

To sample from  $\mu_{T|RS}$ , it suffices to sample according to the subinstance  $V_T \cup \mathcal{C}_T$  given  $b_{RS}$ . Since  $V_T \cup \mathcal{C}_T$  contains no vertex in  $V_S$ ,  $\mu_{T|RS}$  depends only on  $b_R$  but not on  $b_{S\backslash R}$ . Therefore  $\mu_{T|RS} = \mu_{T|R}$  and hence  $\mu_{ST|R} = \mu_{S|R}\mu_{T|R}$ .

For  $Q \in \Gamma$ ,  $S \in Q$ , define  $X_S$  to be the subspace of  $Y_S$  orthogonal to those of proper ancestors:

$$X_S \stackrel{\text{def}}{=} Y_S \cap Y_{\mathcal{A}^*(\mathcal{Q})}^{\perp}$$
 under  $\mu_{\mathcal{A}(\mathcal{Q})}$ .

The next proposition is the main result of this subsection. It shows that if T is not embeddable into S, then  $X_T \perp Y_S$ . In order to prove this statement by induction, we also need to simultaneously prove an auxiliary statement.

<span id="page-30-1"></span>**Proposition 11.16.** For any integer c such that  $0 \le c \le d$ , the following statements hold:

A(c): If  $T \in \mathcal{S}_c$  is not embeddable into  $S \in \mathcal{S}_d$ , then  $X_T \perp Y_S$  under  $(\cdot, \cdot)_d$ .

B(c): If  $R \in \mathcal{S}_c, T \in \mathcal{S}_d$  and |R| < |T|, then  $Y_R \perp X_T$  under  $(\cdot, \cdot)_d$ .

*Proof.* We prove by induction on c that  $B(c-1) \Longrightarrow A(c)$  and  $A(c) \Longrightarrow B(c)$ .

 $B(c-1) \Longrightarrow A(c)$ :

**Base Case:** c = |T| = 0. Statement A(0) holds vacuously, because  $T = \emptyset$  is embeddable into any S.

**Induction Step:** c = |T| > 0. If T is not embeddable into S, Hypergraph Menger (Theorem A.11) implies  $\underline{\operatorname{cl}}_{\{S,T\}}^t(I)$  has an (S,T)-separator R of size strictly less than |T|. For any  $f \in X_T, g \in Y_S$ ,

$$(44) \qquad (f,g)_d \stackrel{(38)}{=} \underset{\mu_{\{S,T\}}}{\mathbb{E}} [fg] \stackrel{(*)}{=} \underset{\mu_R}{\mathbb{E}} \left[ \underset{\mu_{T|R}}{\mathbb{E}} [f] \cdot \underset{\mu_{S|R}}{\mathbb{E}} [g] \right] = \left\langle \underset{\mu_{T|R}}{\mathbb{E}} f, \underset{\mu_{S|R}}{\mathbb{E}} g \right\rangle_{\{R\}},$$

where (\*) is Lemma 11.15, and  $\mathbb{E}_{\mu_{T|R}}: Y_T \to Y_R$  denotes the conditional expectation operator, defined as

<span id="page-30-0"></span>
$$\left(\underset{\mu_{T|R}}{\mathbb{E}}[f]\right)(a) \stackrel{\text{def}}{=} \underset{b \sim \mu_{\{T,R\}}}{\mathbb{E}}[f(b_T) \mid b_R = a] \quad \text{for } a \in D^R, f \in Y_T, T \subseteq V, R \subseteq V.$$

The conditional expectation operator  $\mathbb{E}_{\mu_{T|R}}$  is well known to coincide with the orthogonal projection operator under  $\mu_{\{T,R\}}$  from  $Y_T$  to  $Y_R$ ; see e.g. [dSZ22, Theorem 2.5]. By Statement B(c-1) and Eq. (38), since  $R \in \mathcal{S}_{c-1}$  and |R| < |T|, we have  $Y_R \perp X_T$  under  $\mu_{\{T,R\}}$ , so  $\mathbb{E}_{\mu_{T|R}} f = 0$  after projecting from  $X_T$  to  $Y_R$ , and Eq. (44) vanishes. Since  $f \in X_T$  and  $g \in Y_S$  are arbitrary,  $X_T \perp Y_S$  under  $(\cdot, \cdot)_d$ .

 $A(c) \Longrightarrow B(c)$ :

Claim 11.17.  $X_Q \perp X_T$  under  $(\cdot, \cdot)_d$  for any  $Q \in \mathcal{S}_c$  and any  $T \in \mathcal{S}_d$  such that |Q| < |T|.

*Proof.* If Q is embeddable into T, then  $X_T \perp Y_{\mathcal{A}^*(\mathcal{T})}$  under  $\mu_{\mathcal{A}(T)}$  where  $\mathcal{T} \in \Gamma$  and  $T \in \mathcal{T}$ , which implies  $X_T \perp X_Q$  under  $(\cdot, \cdot)_d$  by Eq. (38) since  $Q \in \mathcal{A}^*(\mathcal{T})$  and  $X_Q \subseteq Y_Q \subseteq Y_{\mathcal{A}^*(\mathcal{T})}$ .

If Q is not embeddable into T, by Statement A(c),  $X_Q \perp Y_T \supseteq X_T$  under  $(\cdot, \cdot)_d$ .

R belongs to a unique component  $\mathcal{R} \in \Gamma$ . By Lemma 11.13,

$$(45) Y_R \subseteq Y_{\mathcal{A}(\mathcal{R})} \stackrel{(43)}{=} \sum_{\mathcal{Q} \in \Gamma(\mathcal{R})} X_{\mathcal{Q}} = \sum_{\mathcal{Q} \in \Gamma(\mathcal{R})} \sum_{Q \in \mathcal{Q}} X_Q = \sum_{Q \in \mathcal{A}(R)} X_Q.$$

For  $Q \in \mathcal{A}(R)$ ,  $|Q| \leq |R| < |T|$ , and the previous Claim implies

<span id="page-31-0"></span>
$$X_T \perp \left(\sum_{Q \in \mathcal{A}(R)} X_Q\right) \stackrel{(45)}{\supseteq} Y_R \quad \text{under } (\cdot, \cdot)_d.$$

<span id="page-31-1"></span>Corollary 11.18.  $X_{\mathcal{Q}} \perp X_{\mathcal{R}} \ under (\cdot, \cdot)_d \ for \ distinct \ \mathcal{Q}, \mathcal{R} \in \Gamma.$ 

*Proof.* Since  $\mathcal{Q}$  and  $\mathcal{R}$  are distinct, assume without loss of generality every  $T \in \mathcal{R}$  is not embeddable into any  $S \in \mathcal{Q}$ . For any  $S \in \mathcal{Q}$ ,  $T \in \mathcal{R}$ ,  $X_S \perp X_T$  under  $(\cdot, \cdot)_d$  by Proposition 11.16 (Statement A(d)). The desired result follows by taking the span over  $S \in \mathcal{Q}$  and  $T \in \mathcal{R}$ .

Our orthogonal decomposition Eq. (37) now follows from Corollaries 11.14 and 11.18. The local orthogonal decomposition Eq. (36) also follows from Lemma 11.13 and Corollary 11.18.

## 11.4. SDP solution.

By Eqs. (37), (40) and (42), the vector space  $Y_{\mathcal{S}_d}$  equipped with the bilinear form  $(\cdot, \cdot)_d$  equals the direct sum  $\mathcal{X} \stackrel{\text{def}}{=} \bigoplus_{\mathcal{O} \in \Gamma} X_{\mathcal{Q}}$  of inner product spaces, with the inner product

<span id="page-31-2"></span>(46) 
$$\langle F, G \rangle_{\mathcal{X}} \stackrel{\text{def}}{=} \sum_{\mathcal{Q} \in \Gamma} \langle F_{\mathcal{Q}}, G_{\mathcal{Q}} \rangle_{\mathcal{Q}} \stackrel{(34)}{=} \sum_{\mathcal{Q} \in \Gamma} \mathbb{E}_{\mu_{\mathcal{Q}}} [F_{\mathcal{Q}} G_{\mathcal{Q}}],$$

whenever 
$$F = \bigoplus_{Q \in \Gamma} F_Q$$
 and  $G = \bigoplus_{Q \in \Gamma} G_Q$ , where  $F_Q, G_Q \in X_Q$ .

Under Assumption 11.8,  $X_{\mathcal{Q}}$  is a genuine inner product space for every  $\mathcal{Q} \in \Gamma$  (after identifying functions whose difference have zero norm), and hence so is  $\mathcal{X}$ .

<span id="page-31-4"></span>**Theorem 11.19.** Under Assumption 11.8, for any  $S, T \in S_d$ , any  $f \in Y_S$ ,  $g \in Y_T$ ,

$$\langle f, g \rangle_{\mathcal{X}} = \underset{\mu_{\{S,T\}}}{\mathbb{E}} [fg].$$

*Proof.* Let  $\mathcal{Q}$  be the equivalence class of S, and similarly  $\mathcal{R}$  be that of T. By Eq. (36), expand  $f = \sum_{\mathcal{A} \in \Gamma(\mathcal{Q})} f_{\mathcal{A}}$  and  $g = \sum_{\mathcal{B} \in \Gamma(\mathcal{R})} g_{\mathcal{B}}$ , where  $f_{\mathcal{A}} \in X_{\mathcal{A}}$  and  $g_{\mathcal{B}} \in X_{\mathcal{B}}$ . Then

$$\langle f, g \rangle_{\mathcal{X}} \stackrel{(46)}{=} \sum_{\mathcal{A} \in \Gamma(\mathcal{Q}) \cap \Gamma(\mathcal{R})} \langle f_{\mathcal{A}}, g_{\mathcal{A}} \rangle_{\mathcal{A}} \stackrel{(40), (42)}{=} \sum_{\mathcal{A} \in \Gamma(\mathcal{Q}) \cap \Gamma(\mathcal{R})} (f_{\mathcal{A}}, g_{\mathcal{A}})_{d}$$

$$\stackrel{(37)}{=} \sum_{\substack{\mathcal{A} \in \Gamma(\mathcal{Q}) \\ \mathcal{B} \in \Gamma(\mathcal{R})}} (f_{\mathcal{A}}, g_{\mathcal{B}})_{d} \stackrel{(39)}{=} (f, g)_{d} \stackrel{(38)}{=} \underset{\mu_{\{S,T\}}}{\mathbb{E}} [fg].$$

#### 11.5. Small ancestor closure.

In this subsection, we justify Assumption 11.8 by Corollary 11.25. The next lemma ([KMOW17, Lemma 6.12] rephrased) says that if  $\mathcal{C}'$  is obtained by adding constraints to  $\mathcal{C}$ , then the sparsity can only increase by at most the number of new boundary variables in  $\mathcal{C}'$ .

<span id="page-31-3"></span>**Lemma 11.20.** Let  $C \subseteq C'$  be constraint sets, so that C is S-closed, C' is S'-closed, and  $S' \subseteq S \cup V(C')$ . Then  $\operatorname{sp}(C', S') \leqslant \operatorname{sp}(C, S) + |S' \cap B(C') \setminus (S \cup \overline{B}(C))|$ .

Proof. Expand  $\operatorname{sp}(\mathcal{C}, S)$  and  $\operatorname{sp}(\mathcal{C}', S')$  using Eq. (25). Every  $C \in \mathcal{C}$  or  $v \in S \cup \overline{B}(\mathcal{C})$  contributes no more to  $\operatorname{sp}(\mathcal{C}', S')$  than to  $\operatorname{sp}(\mathcal{C}, S)$ , because it belongs to no fewer incidences in  $J(\mathcal{C}', S')$  than in  $J(\mathcal{C}, S)$ . Since  $S' \subseteq S \cup V(\mathcal{C}')$ , only new boundary variables  $v \in S' \cap B(\mathcal{C}') \setminus (S \cup \overline{B}(\mathcal{C}))$  contribute more to  $\operatorname{sp}(\mathcal{C}', S')$  than to  $\operatorname{sp}(\mathcal{C}, S)$ , in which case  $\operatorname{sp}_{\mathcal{C}'}(v) = 1$  by Remark 8.2.

Given  $\mathcal{Q} \subseteq \mathcal{P}(V)$ , shorthand  $\mathcal{C}_{\mathcal{Q}} \stackrel{\text{def}}{=} \operatorname{cl}_{\mathcal{Q}}^{t}(\mathcal{C})$  and  $\operatorname{sp}(\mathcal{C}, \mathcal{Q}) \stackrel{\text{def}}{=} \operatorname{sp}(\mathcal{C}, \bigcup \mathcal{Q})$ . Also write  $\mathcal{C}_{S} \stackrel{\text{def}}{=} \operatorname{cl}_{S}^{t}(\mathcal{C})$  for  $S \subseteq V$ .

<span id="page-32-2"></span>**Lemma 11.21.** For any  $(2t, 3\gamma)$ -expanding constraint set C, any  $t\gamma$ -small  $S \subseteq V$ , we have  $C_{A(S)}$  is t-small and  $\operatorname{sp}(C_{A(S)}, A(S)) \leq 2|S|$ .

*Proof.* Denote by  $G_d[\mathcal{Q}]$  the directed subgraph of  $G_d$  induced by  $\mathcal{Q}$  (see Remark 11.4). Call a subfamily  $\mathcal{Q} \subseteq \mathcal{A}(S)$  S-connected if every  $R \in \mathcal{Q}$  has a path p to S in  $G_d[\mathcal{Q}]$  (i.e.  $p \subseteq G_d[\mathcal{Q}]$ ). Note that  $\mathcal{A}(S)$  is itself S-connected. For any S-connected  $\mathcal{Q}$  containing S, we prove by induction on  $\mathcal{Q}$  that  $\mathcal{C}_{\mathcal{Q}}$  is t-small and  $\operatorname{sp}(\mathcal{C}_{\mathcal{Q}}, \mathcal{Q}) \leqslant 2|S| \leqslant 2t\gamma$ .

Base Case:  $Q = \{S\}$ . Then  $\mathcal{C}_{\mathcal{Q}} = \operatorname{cl}_{S}^{t}(\mathcal{C})$ .  $\operatorname{sp}(\mathcal{C}_{\mathcal{Q}}, S) \leq 2|S|$  by Remark 8.3, and  $\mathcal{C}_{\mathcal{Q}}$  is t-small by Lemma 8.11 and  $t\gamma$ -smallness of S.

**Induction Step:**  $\mathcal{Q} \supseteq \{S\}$ . Fix any  $T \in \mathcal{Q}$  whose distance to S in  $G_d[\mathcal{Q}]$  is largest. Then  $\mathcal{R} \stackrel{\text{def}}{=} \mathcal{Q} \setminus \{T\}$  is also S-connected, because every node in  $\mathcal{R}$  has a path to S in  $G_d[\mathcal{Q}]$  without going through T. T also has a path to S in  $G_d[\mathcal{Q}]$ , and the node R after T on this path belongs to  $\mathcal{R}$ . Therefore  $T \rightarrowtail R \in \mathcal{R}$ .

By Induction Hypothesis and Lemma 11.22 (with its  $R \stackrel{\text{def}}{=} \bigcup \mathcal{R}$ ),  $\mathcal{C}_{\mathcal{Q}}$  is t-small. By Lemma 11.23 and Induction Hypothesis,  $\operatorname{sp}(\mathcal{C}_{\mathcal{Q}}, \mathcal{Q}) \leqslant \operatorname{sp}(\mathcal{C}_{\mathcal{R}}, \mathcal{R}) \leqslant 2|S|$ .

The next two lemmas are based on [KMOW17, Claims 6.15 and 6.17].

<span id="page-32-0"></span>**Lemma 11.22.** Suppose C is a  $(2t, 3\gamma)$ -expanding constraint set,  $R \subseteq V$  and  $T \in S_{t\gamma}$ . Let  $Q \stackrel{\text{def}}{=} R \cup T$ . If  $C_R$  is t-small and  $\operatorname{sp}(C_R, R) \leqslant 2t\gamma$ , then  $C_Q$  is also t-small.

*Proof.* Start with  $C'_0 \stackrel{\text{def}}{=} C_R$ . Keep adding Q-closed t-small  $C_i \subseteq C$  to  $C'_{i-1}$  to get  $C'_i \stackrel{\text{def}}{=} C'_{i-1} \cup C_i$ , until  $C'_r = C_Q$ . We prove by induction on i that  $C'_i$  is t-small.

**Base Case:** i = 0. Then  $C'_0 = C_R$  is t-small by assumption.

Induction Step: i > 0. Let  $R_i \stackrel{\text{def}}{=} R \cup (T \cap V(\mathcal{C}_i'))$ .  $\mathcal{C}_i'$  is  $R_i$ -closed because  $\mathcal{C}_i'$  is Q-closed and  $Q \cap V(\mathcal{C}_i') \subseteq R_i$ . By Lemma 11.20,  $\operatorname{sp}(\mathcal{C}_i', R_i) \leqslant \operatorname{sp}(\mathcal{C}_R, R) + |T \cap B(\mathcal{C}_i') \setminus (R \cup \overline{B}(\mathcal{C}_R))| \leqslant 3t\gamma$ . Further,  $\mathcal{C}_{i-1}'$  is t-small by Induction Hypothesis, so  $\mathcal{C}_i'$  is 2t-small. Thus  $\mathcal{C}_i'$  is t-small because  $\mathcal{C}$  is  $(2t, 3\gamma)$ -expanding.

<span id="page-32-1"></span>**Lemma 11.23.** Under the assumptions of the previous lemma, if T is embeddable into R, then  $\operatorname{sp}(\mathcal{C}_Q, Q) \leqslant \operatorname{sp}(\mathcal{C}_R, R)$ .

*Proof.* Let  $R' \stackrel{\text{def}}{=} R \cup \overline{B}(\mathcal{C}_R)$  be the old variables and  $T' \stackrel{\text{def}}{=} T \setminus R'$  be the new variables in T. Lemma 11.20 implies  $\operatorname{sp}(\mathcal{C}_Q, Q) \leqslant \operatorname{sp}(\mathcal{C}_R, R) + |T'|$ . Since  $T \rightarrowtail R$ , there are vertex-disjoint paths  $p_v$  from every  $v \in T$  to R in  $\operatorname{cl}_Q^t(I)$ .

Treat a path p from T' to R as a sequence  $(v_1, C_1, v_2, C_2, \ldots, v_s)$  of distinct vertices interleaved with constraints, so that consecutive variables  $v_i$  and  $v_{i+1}$  both belong to the constraint  $C_i$  between them, for every  $1 \leq i < s$ . The first variable  $v_1$  is new and the last  $v_s$  is old, so p contains a new element p whose successor p is old (i.e. p is a new constraint-variable incidence in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p in p

<span id="page-32-3"></span>Because the paths  $\{p_v \mid v \in T'\}$  are vertex-disjoint (i.e. variable-disjoint), the above pairs  $\{(y_v, z_v) \mid v \in T'\}$  from different paths are distinct new constraint-variable incidences to old constraints or old vertices. These |T'| new incidences cancel out the |T'| sparsity increase in Lemma 11.20, so  $\operatorname{sp}(\mathcal{C}_Q, Q) \leqslant \operatorname{sp}(\mathcal{C}_R, R)$ .

**Lemma 11.24.** For any t, any families of variable subsets  $A \subseteq B \subseteq P(V)$ , any constraint set C,  $\operatorname{cl}_A^t(C) \subseteq \operatorname{cl}_B^t(C)$ .

*Proof.* Apply Lemma 8.9 with its  $T \stackrel{\text{def}}{=} \bigcup \mathcal{A}$  and  $S \stackrel{\text{def}}{=} \bigcup \mathcal{B}$ .

<span id="page-33-4"></span>Corollary 11.25. For any  $(2t, 3\gamma)$ -expanding constraint set C, any  $S \subseteq V$  such that  $S \cup K$  is  $t\gamma$ -small, the K-augmented ancestor closure  $\underline{\operatorname{cl}}_{\mathcal{A}(S)}^t(\mathcal{C})$  is t-small.

*Proof.* Note that  $K \in \mathcal{A}(K)$ . Also  $\mathcal{A}(S) \subseteq \mathcal{A}(T)$  for any  $S \subseteq T \subseteq V$  because  $S \rightarrowtail T$  via paths with no edges. These two facts imply  $\{K\} \cup \mathcal{A}(S) \subseteq \mathcal{A}(K) \cup \mathcal{A}(S) \subseteq \mathcal{A}(K \cup S)$ . The desired result now follows by Lemma 11.21 (with its  $S \stackrel{\text{def}}{=} K \cup S$ ) and Lemma 11.24 (with its  $\mathcal{A} \stackrel{\text{def}}{=} \{K\} \cup \mathcal{A}(S)$  and  $\mathcal{B} \stackrel{\text{def}}{=} \mathcal{A}(K \cup S)$ ).

# 11.6. Wrapping up.

Our next theorem generalizes [KMOW17, Theorem 1.2] (which concerns  $K = \emptyset$  and  $\mathcal{E} = \emptyset$ ):

<span id="page-33-2"></span>**Theorem 11.26.** Suppose an instance  $I = (V, \mathcal{C})$  of a  $\tau$ -wise uniform CSP is  $(2t, 3\gamma)$ -expanding. Fix  $K \subseteq V$  and  $\mathcal{E} \subseteq \mathcal{C}$  so that  $\eta$  is  $\tau$ -wise uniform outside  $\mathcal{E}$ . Choose  $d \in \mathbb{N}$  so that Assumption 11.8 holds. Define

<span id="page-33-5"></span>(47) 
$$\mu_R \stackrel{\text{def}}{=} \pi_R \circ \mu \circ \underline{\operatorname{cl}}_R^t(I) \quad \text{for } R \in \mathcal{S}_{2d}; \text{ and}$$

<span id="page-33-6"></span>(48) 
$$\alpha_S(a_S) \stackrel{\text{def}}{=} \mathbb{1}_{a_S} \quad \text{for } S \in \mathcal{S}_d, a_S \in A_S.$$

Then  $(\alpha_S)_S$  is a level-d SDP hierarchy solution inducing the level-2d LP hierarchy solution  $(\mu_R)_R$ .

*Proof.*  $\mu_R$  is well defined because Assumption 11.8 implies  $\underline{\operatorname{cl}}_R^t(I)$  is  $\eta$ -satisfiable for  $R \in \mathcal{S}_{2d}$ . We now show that  $(\mu_R)_R$  is consistent with projection. For any  $R \in \mathcal{S}_{2d}$ ,  $U \subseteq R$ ,

$$\pi_{R \to U} \circ \mu_R \stackrel{(47)}{=} \pi_{R \to U} \circ \pi_R \circ \mu \circ \underline{\operatorname{cl}}_R^t(I) \stackrel{(5)}{=} \pi_U \circ \mu \circ \underline{\operatorname{cl}}_R^t(I)$$

$$\stackrel{(*)}{=} \pi_U \circ \mu \circ \underline{\operatorname{cl}}_U \circ \underline{\operatorname{cl}}_R^t(I) \stackrel{(30)}{=} \pi_U \circ \mu \circ \underline{\operatorname{cl}}_U^t(I) \stackrel{(47)}{=} \mu_U,$$

where (\*) is Lemma 10.4.

For any  $S, T \in \mathcal{S}_d$ , any  $a_S \in A_S$ ,  $a_T \in A_T$ , Theorem 11.19 implies Eq. (1) because

$$\langle \alpha_S(a_S), \alpha_T(a_T) \rangle_{\mathcal{X}} \stackrel{(48)}{=} \langle \mathbb{1}_{a_S}, \mathbb{1}_{a_T} \rangle_{\mathcal{X}} = \underset{\mu_{\{S,T\}}}{\mathbb{E}} [\mathbb{1}_{a_S} \mathbb{1}_{a_T}] = \underset{b \sim \mu_{S \cap T}}{\mathbb{P}} [b_S = a_S, b_T = a_T].$$

Finally,  $(\alpha_S)_S$  is consistent with projection, because for any  $S \in \mathcal{S}_d$ ,  $T \subseteq S$ ,  $b \in D^T$ ,

$$\pi_{S \to T}(\alpha_S)(b) \stackrel{(2)}{=} \sum_{\substack{a \in D^S \\ a_T = b}} \alpha_S(a) \stackrel{(48)}{=} \sum_{\substack{a \in D^S \\ a_T = b}} \mathbb{1}_a = \mathbb{1}_b \stackrel{(48)}{=} \alpha_T(b).$$

<span id="page-33-3"></span>**Lemma 11.27.** When  $K = \emptyset$  and  $\mathcal{E} = \emptyset$ , Assumption 11.8 holds for  $d \stackrel{\text{def}}{=} t\gamma/2$  and any  $(2t, 3\gamma)$ -expanding constraint set  $\mathcal{C}$ .

*Proof.* Lemma 11.21  $(\underline{\operatorname{cl}}_{\mathcal{A}(S)}^t(\mathcal{C})$  is t-small), Lemma 8.12  $(\underline{\operatorname{cl}}_{\mathcal{A}(S)}^t(\mathcal{C})$  is dismissible) and Proposition 10.7  $(\underline{\operatorname{cl}}_{\mathcal{A}(S)}^t(\mathcal{C})$  is  $\eta$ -satisfiable) imply Assumption 11.8.

#### 12. New SDP solution with full support

<span id="page-33-1"></span><span id="page-33-0"></span>We now construct a new SDP solution for a  $\tau$ -wise uniform CSP, completing the proof of Theorem 1.2. Our SDP solution induces an LP solution that has full support on all satisfying assignments of every small closure.

**Definition 12.1** ( $\mathcal{E}$ -planted solution). Given constraint sets  $\mathcal{E} \subseteq \mathcal{C}$ , define the constraint solution  $\eta^{\mathcal{E}}: (C \in \mathcal{C}) \to \Delta(A_C)$  as follows:  $\eta^{\mathcal{E}}(C)$  is the uniform distribution over  $A_C$  for  $C \in \mathcal{E}$ , and  $\eta^{\mathcal{E}}(C)$  is a  $\tau$ -wise uniform distribution supported on  $A_C$  for  $C \in \mathcal{C} \setminus \mathcal{E}$ .

**Definition 12.2.** A relaxed assignment  $\alpha: D^V \to \mathcal{M}$  has full support on  $A \subseteq D^V$  if  $\operatorname{supp}(\alpha) = A$ . A scheme  $\sigma$  for a family  $\mathcal{C}$  of constraints has full support if  $\operatorname{supp}(\sigma(\mathcal{C})) = A_{\mathcal{C}}$  for  $\mathcal{C} \in \mathcal{C}$ .

<span id="page-34-1"></span>**Lemma 12.3.** Let  $\eta: (C \in \mathcal{C}) \to \Delta(A_C)$  be a family of satisfying assignments for a constraint set  $\mathcal{C}$ . Suppose  $\eta(C)$  has full support on  $A_C$  for every  $C \in \mathcal{C}$ . Then the canonical distribution  $\mu_I$  derived from  $\eta$  has full support on  $A_J$  for any instance  $J = (U, \mathcal{C})$ .

Proof. For every  $C \in \mathcal{C}$ ,  $\eta(C)$  has full support on  $A_C$ , so  $\eta(C)(b) > 0$  for every  $b \in A_C$ . Now an assignment  $\alpha \in A_J$  satisfies all constraints in  $\mathcal{C}$ , so the canonical distribution  $\mu_{\mathcal{C}}$  has probability mass  $\mu_{\mathcal{C}}(a) = \frac{1}{Z} \prod_{C \in \mathcal{C}} \eta(C) \left( a_{V(C)} \right) > 0$ , where Z > 0 is the normalization factor to make  $\mu_{\mathcal{C}}$  sum to 1. This implies  $\sup(\mu_J) \supseteq A_J$ .

On the other hand, if an assignment  $a \in D^{V(J)} \setminus A_J$  violates some constraint  $C \in \mathcal{C}$ , then  $a_{V(C)} \notin A_C$  and  $\eta(C) \left(a_{V(C)}\right) = 0$ , so  $\mu_{\mathcal{C}}(a) = \frac{1}{Z} \prod_{C \in \mathcal{C}} \eta(C) \left(a_{V(C)}\right) = 0$ . Thus  $\operatorname{supp}(\mu_J) \subseteq A_J$ .  $\square$ 

<span id="page-34-0"></span>**Lemma 12.4.** Suppose an instance  $I = (V, \mathcal{C})$  of a  $\tau$ -wise uniform CSP is  $(2t, 3\gamma)$ -expanding. For any  $t\gamma/2$ -small  $K \subseteq V$ , let  $\mathcal{E} \stackrel{\text{def}}{=} \operatorname{cl}_K^t(\mathcal{C})$  and  $\eta^{\mathcal{E}}$  be the  $\mathcal{E}$ -planted solution. Then the K-augmented closure  $\operatorname{\underline{cl}}_{\mathcal{A}(S)}^t(\mathcal{C})$  is t-small and  $\eta^{\mathcal{E}}$ -satisfiable for every  $t\gamma/2$ -small  $S \subseteq V$ .

Proof. Corollary 11.25 implies  $\underline{\operatorname{cl}}_{\mathcal{A}(S)}^t(\mathcal{C})$  is t-small because  $(K \cup S)$  is t-small. By Lemma 8.12,  $\underline{\operatorname{cl}}_{\mathcal{A}(S)}^t(\mathcal{C})$  is dismissible with respect to  $\tau$ . Since the CSP is  $\tau$ -wise uniform, every  $C \in \mathcal{C}$  has a  $\tau$ -wise uniform distribution  $\eta^C$  supported on its satisfying assignments  $A_C$ , so  $\operatorname{supp}(\eta^{\mathcal{E}}(C)) \supseteq \operatorname{supp}(\eta^C)$  is  $\tau$ -wise neutral for BW. By Proposition 10.6 (with  $\mathcal{C} \stackrel{\text{def}}{=} \underline{\operatorname{cl}}_{\mathcal{A}(S)}^t(\mathcal{C}), \eta \stackrel{\text{def}}{=} \eta^{\mathcal{E}}), \ \underline{\operatorname{cl}}_{\mathcal{A}(S)}^t(\mathcal{C})$  is  $\eta^{\mathcal{E}}$ -satisfiable.

Given an instance I, denote by  $\Sigma_d^{\text{SDP}}$  the set of its SDP hierarchy solutions of level d. More precisely,  $\Sigma_d^{\text{SDP}}$  is the set of  $((\alpha_S)_S, (\mu_R)_R)$ , where  $(\alpha_S)_S$  is an SDP hierarchy solution for I of level d inducing the LP hierarchy solution  $(\mu_R)_R$  of level 2d.

<span id="page-34-4"></span>**Lemma 12.5.** Let I be an instance and  $d \in \mathbb{N}$ . Let  $\rho$  be a distribution over a finite set  $\Omega$ . Suppose for every  $\mathcal{E} \in \Omega$ , there is  $((\alpha_S^{\mathcal{E}})_S, (\mu_R^{\mathcal{E}})_R) \in \Sigma_d^{\mathrm{SDP}}$ . Then  $((\alpha_S)_S, (\mu_R)_R) \in \Sigma_d^{\mathrm{SDP}}$ , where

<span id="page-34-3"></span>(49) 
$$\mu_R \stackrel{\text{def}}{=} \mathop{\mathbb{E}}_{\mathcal{E} \sim \rho} \mu_R^{\mathcal{E}} \quad \text{for 2d-small } R \subseteq V; \text{ and}$$

<span id="page-34-2"></span>(50) 
$$\alpha_S \stackrel{\text{def}}{=} \bigoplus_{\mathcal{E} \in \Omega} \sqrt{\rho(\mathcal{E})} \cdot \alpha_S^{\mathcal{E}} \quad \text{for } d\text{-small } S \subseteq V.$$

Proof. For  $S, T \in \mathcal{S}_d$ ,  $a_S \in A_S$ ,  $a_T \in A_T$ ,

$$\langle \alpha_{S}(a_{S}), \alpha_{T}(a_{T}) \rangle_{\rho} \stackrel{(50)}{=} \sum_{\mathcal{E} \in \Omega} \left\langle \sqrt{\rho(\mathcal{E})} \alpha_{S}^{\mathcal{E}}(a_{S}), \sqrt{\rho(\mathcal{E})} \alpha_{T}^{\mathcal{E}}(a_{T}) \right\rangle_{\mathcal{X}^{\mathcal{E}}} \stackrel{(*)}{=} \underset{\mathcal{E} \sim \rho}{\mathbb{E}} \left\langle \alpha_{S}^{\mathcal{E}}(a_{S}), \alpha_{T}^{\mathcal{E}}(a_{T}) \right\rangle_{\mathcal{X}^{\mathcal{E}}} \stackrel{(*)}{=} \underset{\mathcal{E} \sim \rho}{\mathbb{E}} \left\langle \alpha_{S}^{\mathcal{E}}(a_{S}), \alpha_{T}^{\mathcal{E}}(a_{T}) \right\rangle_{\mathcal{X}^{\mathcal{E}}} \stackrel{(*)}{=} \underset{b \sim \mu_{\{S,T\}}}{\mathbb{E}} [b_{S} = a_{S}, b_{T} = a_{T}],$$

where (\*) uses bilinearity of  $\langle \cdot, \cdot \rangle_{\mathcal{X}^{\mathcal{E}}}$ , and (\*) is because  $(\alpha_S^{\mathcal{E}})_S$  induces  $(\mu_R^{\mathcal{E}})_R$  for  $\mathcal{E} \in \Omega$ . Therefore  $(\mu_R)_R$  and  $(\alpha_S)_S$  satisfy Eq. (1).

 $(\alpha_S)_S$  is consistent with projection, because for any  $T \subseteq S \subseteq V$ ,

$$\pi_T(\alpha_S) \stackrel{(50)}{=} \pi_T \left( \bigoplus_{\mathcal{E} \in \Omega} \sqrt{\rho(\mathcal{E})} \cdot \alpha_S^{\mathcal{E}} \right) \stackrel{(55)}{=} \bigoplus_{\mathcal{E} \in \Omega} \sqrt{\rho(\mathcal{E})} \cdot \pi_T \left( \alpha_S^{\mathcal{E}} \right) \stackrel{(\dagger)}{=} \bigoplus_{\mathcal{E} \in \Omega} \sqrt{\rho(\mathcal{E})} \cdot \alpha_T^{\mathcal{E}} \stackrel{(50)}{=} \alpha_T,$$

where  $(\dagger)$  is due to  $(\alpha_S^{\mathcal{E}})_S$  being consistent with projection for  $\mathcal{E} \in \Omega$ .

<span id="page-35-0"></span>**Theorem 12.6.** Suppose an instance  $I = (V, \mathcal{C})$  of a  $\tau$ -wise uniform CSP is  $(2t, 3\gamma)$ -expanding. Let  $d \stackrel{\text{def}}{=} t\gamma/4$ . Then there exists  $((\alpha_S)_S, (\mu_R)_R) \in \Sigma_d^{\text{SDP}}$  such that  $(\mu_R)_R$  has full support.

Proof. Let  $\Omega \stackrel{\text{def}}{=} \{\operatorname{cl}_K^t(\mathcal{C}) \mid K \in \mathcal{S}_{2d}\}$  be the family of closures of 2d-small variable subsets. For every  $K \in \mathcal{S}_{2d}, \mathcal{E} \stackrel{\text{def}}{=} \operatorname{cl}_K^t(\mathcal{C}) \in \Omega$ , the constraint solution  $\eta^{\mathcal{E}}$  is  $\tau$ -wise uniform outside  $\mathcal{E}$ , and the K-augmented closure  $\operatorname{cl}_{\emptyset}^t(\mathcal{C}) = \operatorname{cl}_K^t(\mathcal{C})$  contains (and in fact equals)  $\mathcal{E}$ . Theorem 11.26 yields  $((\alpha_S^{\mathcal{E}})_S, (\mu_R^{\mathcal{E}})_R) \in \Sigma_d^{\mathrm{SDP}}$ , where Assumption 11.8 is justified by Lemma 12.4.

Lemma 12.5 further constructs  $((\alpha_S)_S, (\mu_R)_R) \in \Sigma_d^{\text{SDP}}$ , with  $\rho$  being any distribution with full support on  $\Omega$ , such as the uniform distribution over  $\Omega$ .

For 2d-small  $R \subseteq V$ , consider the K-augmented closure with  $K \stackrel{\text{def}}{=} R$ . Let  $J \stackrel{\text{def}}{=} \operatorname{cl}_R^t(I) = \underline{\operatorname{cl}}_R^t(I)$ ,  $\mathcal{E} \stackrel{\text{def}}{=} \operatorname{cl}_R^t(\mathcal{C}) = \underline{\operatorname{cl}}_R^t(\mathcal{C})$  and  $\mu_J^{\mathcal{E}}$  be the canonical distribution on J derived from  $\eta^{\mathcal{E}}$ . Then

$$\operatorname{supp}(\mu_R) \stackrel{(49)}{=} \bigcup_{\mathcal{E}' \in \Omega} \operatorname{supp}\left(\mu_R^{\mathcal{E}'}\right) \supseteq \operatorname{supp}\left(\mu_R^{\mathcal{E}}\right) \stackrel{(47)}{=} \operatorname{supp}\left(\pi_R\left(\mu_J^{\mathcal{E}}\right)\right) \stackrel{(54)}{=} \pi_R\left(\operatorname{supp}\left(\mu_J^{\mathcal{E}}\right)\right) = \pi_R(A_J),$$

where the last equality is Lemma 12.3 (with its  $\mathcal{C} \stackrel{\text{def}}{=} \mathcal{E}, \eta \stackrel{\text{def}}{=} \eta^{\mathcal{E}}$ ). Therefore  $(\mu_R)_R$  satisfies Definition 8.19 and has full support on small closures.

We now prove Theorem 1.2.

**Theorem 1.2.** Let  $\tau \geq 2$ . If a k-CSP is  $\tau$ -wise neutral for both SDP and AIP (separately), then except with probability  $o_{n;k}(1)$ , a random instance of the CSP with n variables and  $\Delta n$  constraints has an SDP+AIP hierarchy solution of level  $\Omega_k(n/(\Delta^{2/(\tau-1)}\log \Delta))$ .

*Proof.* Fix  $\gamma \stackrel{\text{def}}{=} 1/\log \Delta$ ,  $\lambda \stackrel{\text{def}}{=} \tau - 1$ . We may assume  $\Delta^{2/\lambda} \log \Delta \leqslant n$ , for otherwise the level lower bound is trivial, as every hierarchy has a solution of level 0. Since  $\Delta^{2/(\lambda - 3/\log \Delta)} = \Theta(\Delta)$  for  $\lambda \geqslant 1$ , we have  $\zeta \stackrel{\text{def}}{=} \Delta^{2/(\lambda - 3\gamma)}/n = o_n(1)$ . Lemma 8.16 implies that except with probability  $o_{n;k}(1)$ , a random instance I is  $(2t, 3\gamma)$ -expanding, where  $t = n/(\Delta^{2/(\lambda - 3\gamma)}2^{O(k)}) = \Omega_k(n/\Delta^{2/\lambda})$ .

Theorem 12.6 yields a level-d SDP solution  $(\alpha_S)_S$  inducing the level-2d LP solution  $(\mu_R)_R$  such that  $(\mu_R)_R$  has full support, where  $d \stackrel{\text{def}}{=} t\gamma/4$ . Theorem 7.12 and Proposition 8.15 constructs a level-2d AIP solution  $(w_R)_R$ . Lemma 8.20 implies that  $(\mu_R, w_R)_R$  is a level-2d solution for the LP+AIP hierarchy.

Recent works constructed explicit (non-random) instances fooling the SDP hierarchy. A random CSP instance has two sources of randomness (Definition B.1):

- (A) Randomness of the underlying hypergraph
- (B) Randomness of the relation (set of satisfying assignments) of each constraint

To fool a hierarchy, randomness (A) ensures expansion, crucial for hierarchy solution. As explained in Remark 8.5, when  $\tau = k-1$  (e.g. k-SAT), hierarchy solutions can be constructed as long as an instance has a factor graph that is a boundary expander. Randomness (B) ensures every assignment is far from satisfying all constraints. Hopkins and Lin [HL22], building on [DFHT21], constructed explicit 3-XOR instances fooling linear-level SDP using high dimensional expanders known as quantum Tanner codes [LZ22]. They further showed that every assignment to their instances violates a fraction of 3-XOR constraints bounded away from zero. Their analysis crucially exploits the linear structure over  $\mathbb{F}_2$  that appears naturally for 3-XOR but not for 3-SAT. It is not

clear how to generalize their analysis to construct explicit 3-SAT instances fooling linear-level LP+AIP and SDP+AIP. This seems to call for constructing high dimensional expanders from non-linear codes.

**Acknowledgements**. We thank Thana Somsirivattana and Mehrshad Taziki for participating in part of this research project and their observations. We thank Jeff Xu and Sirawit Pongnakintr for helpful discussions. We thank anonymous STOC reviewers for their valuable feedback and suggestions.

# Appendix A. Omitted proofs

<span id="page-36-1"></span>**Lemma A.1.** *For any constraint sets C <sup>0</sup> ⊆ C, any C ∈ C<sup>0</sup> ,*

$$B(\mathcal{C}) \cap V(C) \subseteq B(\mathcal{C}') \cap V(C).$$

*Proof.* Every *v ∈ B*(*C*) *∩ V* (*C*) belongs to *C ∈ C<sup>0</sup>* but not to any *C <sup>0</sup> ∈ C \ {C}*, in particular no *C <sup>0</sup> ∈ C<sup>0</sup> \ {C} ⊆ C \ {C}* contains *v*. Since *C ∈ C<sup>0</sup>* , *v* is contained in a unique constraint in *C 0* . □

<span id="page-36-0"></span>**Proposition A.2.** *For any T* ⊊ *S, π<sup>T</sup>* (*χS*) *≡* 0*.*

*Proof.* For any *a ∈ {*0*,* 1*} T* ,

$$\pi_T(\chi_S)(a) = \sum_{b \in D^{S \setminus T}} \chi_S(a \cup b) = \chi_T(a) \sum_{b \in D^{S \setminus T}} \chi_{S \setminus T}(b) = 0,$$

as half of the assignments *b ∈ {*0*,* 1*} <sup>S</sup>\<sup>T</sup>* have even parity and the other half have odd parity. □

**Lemma A.3.** *Suppose M is a commutative semiring. For any disjoint S and T, α<sup>S</sup> ∈ MD<sup>S</sup> , α<sup>T</sup> ∈ MD<sup>T</sup> , R ⊆ S ∪ T,*

(51) 
$$\pi_{S \cup T \to R}(\alpha_S \otimes \alpha_T) = \pi_{S \to S \cap R}(\alpha_S) \otimes \pi_{T \to T \cap R}(\alpha_T).$$

*Proof.* For every *a ∈ DR*,

<span id="page-36-2"></span>
$$\pi_{S \cup T \to R}(\alpha_S \otimes \alpha_T)(a) \stackrel{(2)}{=} \sum_{\substack{b \in S, c \in T \\ (b \cup c)_R = a}} (\alpha_S \otimes \alpha_T)(b \cup c) \stackrel{(6)}{=} \sum_{\substack{b \in S, c \in T \\ (b \cup c)_R = a}} \alpha_S(b)\alpha_T(c)$$

$$\stackrel{(*)}{=} \sum_{\substack{b \in S \\ b_{R \cap S} = a_{R \cap S}}} \alpha_S(b) \sum_{\substack{c \in T \\ c_{R \cap T} = a_{R \cap T}}} \alpha_T(c)$$

$$\stackrel{(2)}{=} \pi_{S \to S \cap R}(\alpha_S)(a_{R \cap S})\pi_{T \to T \cap R}(\alpha_T)(a_{R \cap T})$$

$$\stackrel{(6)}{=} (\pi_{S \to S \cap R}(\alpha_S) \otimes \pi_{T \to T \cap R}(\alpha_T))(a),$$

where (*∗*) follows from the distributivity of multiplication over addition in *M*. □

**Lemma A.4.** *For any subsets T ⊆ S, any subsets B ⊆ A ⊆ D<sup>S</sup> ,*

(52) 
$$\pi_T(B) \subseteq \pi_T(A).$$

<span id="page-36-4"></span>*Proof.* If *c ∈ π<sup>T</sup>* (*B*), then *b<sup>T</sup>* = *c* for some *b ∈ B*, and hence *b ∈ A* and *c ∈ π<sup>T</sup>* (*A*). □

<span id="page-36-3"></span>**Lemma A.5.** *For any T ⊆ S, any relaxed assignment α* : *D<sup>S</sup> → M,*

(53) 
$$\operatorname{supp}(\pi_T(\alpha)) \subseteq \pi_T(\operatorname{supp}(\alpha)).$$

*Proof.* If *b ∈* supp(*π<sup>T</sup>* (*α*)), then 0 *6*= *π<sup>T</sup>* (*α*)(*b*) = P*{α*(*a*) *| a ∈ D<sup>S</sup> , a<sup>T</sup>* = *b}*, so *α*(*a*) *6*= 0 for some *a ∈ D<sup>S</sup> , a<sup>T</sup>* = *b*. This implies *a ∈* supp(*α*) and *b ∈ π<sup>T</sup>* (supp(*α*)). □

**Lemma A.6.** *For any T ⊆ S, any nonnegative-real-valued α* : *D<sup>S</sup> →* R+*,*

<span id="page-36-5"></span>(54) 
$$\operatorname{supp}(\pi_T(\alpha)) = \pi_T(\operatorname{supp}(\alpha)).$$

*Proof.* For any  $b \in D^T$ ,  $b \in \pi_T(\operatorname{supp}(\alpha))$  if and only if  $\alpha(a) > 0$  for some  $a \in D^S$  such that  $a_T = b$ , which is equivalent to  $\pi_T(\alpha)(b) > 0$ , that is,  $b \in \operatorname{supp}(\pi_T(\alpha))$ .

**Lemma A.7.** For any subsets  $T \subseteq S$  and family  $\{\alpha^{\mathcal{E}} : D^S \to \mathcal{M} \mid \mathcal{E} \in \Omega\}$  of relaxed assignments,

(55) 
$$\pi_T \left( \bigoplus_{\mathcal{E} \in \Omega} \alpha^{\mathcal{E}} \right) = \bigoplus_{\mathcal{E} \in \Omega} \pi_T \left( \alpha^{\mathcal{E}} \right).$$

*Proof.* For any  $b \in D^T$ ,

<span id="page-37-1"></span>
$$\pi_T \left( \bigoplus_{\mathcal{E} \in \Omega} \alpha^{\mathcal{E}} \right) (b) \stackrel{(2)}{=} \sum_{\substack{a \in D^S \\ a_T = b}} \left( \bigoplus_{\mathcal{E} \in \Omega} \alpha^{\mathcal{E}} \right) (a) \stackrel{(*)}{=} \bigoplus_{\mathcal{E} \in \Omega} \left( \sum_{\substack{a \in D^S \\ a_T = b}} \alpha^{\mathcal{E}} (a) \right) \stackrel{(2)}{=} \bigoplus_{\mathcal{E} \in \Omega} \pi_T \left( \alpha^{\mathcal{E}} \right) (b),$$

where (\*) is by definition of the direct sum construction, that is, coordinate-wise addition.

**Proposition A.8.** Let  $\mu$  be a (k-1)-wise uniform distribution over  $\{0,1\}^k$ . Then  $\mu = \lambda \mu_{even} + (1-\lambda)\mu_{odd}$  for some  $0 \le \lambda \le 1$ , where  $\mu_{even}$  ( $\mu_{odd}$ ) is the uniform distribution over  $\{0,1\}^k$  conditioned on even (odd) parity.

Proof. Let  $\chi_S$  be the parity function on S for  $S \subseteq [k]$ . (k-1)-wise uniformity is equivalent to the linear constraints that  $\mathbb{E}_{\mu}[\chi_S] = 0$  for  $\emptyset \subsetneq S \subsetneq [k]$ .  $\mu$  also satisfies the linear equality  $\mathbb{E}_{\mu}[\chi_{\emptyset}] = 1$  that holds for any distribution. Since the parity functions  $\{\chi_S \mid S \subseteq [k]\}$  form the Fourier basis of  $\{f : \{0,1\}^k \to \mathbb{R}\}$ , there is only one degree of freedom in  $\mu$ , namely the choice of  $\alpha \stackrel{\text{def}}{=} \mathbb{E}_{\mu}[\chi_{[k]}]$ . We have  $|\alpha| = |\mathbb{E}_{\mu}[\chi_{[k]}]| \leqslant \mathbb{E}_{\mu}[|\chi_{[k]}|] = 1$ . Of the two extremes,  $\alpha = 1$  is achieved by  $\mu_{\text{even}}$  and  $\alpha = -1$  by  $\mu_{\text{odd}}$ . Therefore  $\lambda \stackrel{\text{def}}{=} (1 + \alpha)/2$ .

**Proposition A.9.** For any  $a \in \{0,1\}^3$ , let  $R \stackrel{\text{def}}{=} \{0,1\}^3 \setminus \{a\}$  be the set of satisfying assignments to a 3-SAT constraint forbidding only a. If a distribution  $\mu \in \Delta(R)$  over R is pairwise uniform, then  $\mu$  is the uniform distribution over  $\{0,1\}^3$  conditioned on having opposite parity to a.

*Proof.* The previous Proposition implies  $\mu = \lambda \mu_{\text{even}} + (1 - \lambda) \mu_{\text{odd}}$  for some  $0 \le \lambda \le 1$ . If a has even parity, then  $\lambda = 0$ , because  $a \notin \text{supp}(\mu)$ . Likewise if a has odd parity, then  $\lambda = 1$ .

Let us recall (vertex) Menger's theorem for graphs, and then prove its counterpart for hypergraphs.

<span id="page-37-3"></span>**Theorem A.10** (Menger, e.g. [Gör02]). For any vertex subsets S and T in a multigraph G, the minimum size of an (S,T)-separator equals the maximum number of vertex-disjoint paths between S and T.

<span id="page-37-0"></span>**Theorem A.11** (Hypergraph Menger). For any vertex subsets S and T in a hypergraph H, the minimum size of an (S,T)-separator equals the maximum number of vertex-disjoint paths between S and T.

*Proof.* Define a multigraph G having the same vertex set as H, and G has an edge  $(u,v) \in V^2$  if some hyperedge in H contains both u and v. Apply Theorem A.10 to G. Note that for every sequence of vertices, it is a path in G if and only if it is a path in H.

#### APPENDIX B. RANDOM INSTANCE

Recall the natural distribution of random CSP instances, e.g. [BGMT12, KMOW17]:

<span id="page-37-2"></span>**Definition B.1** (Random instance). Fix a k-CSP  $(D, \mathfrak{R})$ , a finite set V of variables, and  $m \in \mathbb{N}$ .

(1) A random constraint C = (S, R) is chosen by picking a sequence  $S \in V^k$  of k distinct variables uniformly, and R uniformly from  $\Re$ .

(2) A random instance consists of choosing with replacement *m* random constraints.

Equivalently, a random instance consists of first picking a *k*-uniform hypergraph whose hyperedges are chosen independently, and then choosing the relation *R* of each hyperedge (i.e. constraint) independently and uniformly at random from R.

# B.1. **Unsatisfiability.**

As is well known, most instances of a predicate CSP (*D,* R) at high constraint density are unsatisfiable, if the predicate is violated by some assignment. This result generalizes to non-predicate CSPs, with a twist. Previous works on predicate CSPs (e.g. [\[Tul09](#page--1-12), Lemma A.1]) exploited the symmetry of R to argue that in a random instance, every assignment satisfies not many more constraints than a random assignment. The symmetry argument breaks down for a non-predicate CSP, as one can see from the following example.

A *k*-CSP (*D,* R) is *trivially satisfiable by a single value*[8](#page-38-2) if there is some value *a ∈ D* whose constant assignment *v ∈* [*k*] *7→ a* satisfies every relation in R. We also call it *trivially satisfiable* for short. Random instances of such a CSP are always satisfiable for a trivial reason, regardless of how unlikely a random assignment satisfies the relations in R. An extreme example is R def = *{R}, R* def = *{b}, b* def = *v ∈* [*k*] *7→ a* for some value *a ∈ D*, while *D* and *k* are large. Fortunately, trivial satisfiability turns out to be the only obstacle to unsatisfiability of random instances.

**Lemma B.2.** *Suppose a k-CSP* (*D,* R) *is not trivially satisfiable. Fix any assignment b* : *V → D from a variable set of size n* ⩾ 2*|D|k. Then b violates a random constraint over V with probability at least* 1*/*4 *|D| k .*

*Proof.* Some value *a ∈ D* must be assigned to at least 1*/|D|* fraction of the variables by *b*. Let *s* be the number of variables getting the value *a* under *b*. Since the CSP is not trivially satisfiable, the constant assignment *v ∈* [*k*] *7→ a* violates some relation *R ∈* R. A random constraint is violated if its scope is contained in *b −*1 (*a*) and its relation is *R*. A random constraint has its scope contained *b −*1 (*a*) with probability *p* def = *s k / n k* ⩾ (1*/*2*|D|*) *<sup>k</sup>* when *n* ⩾ 2*|D|k*. A random constraint has its relation being *R* with probability *q* def = 1*/|*R*|* ⩾ 1*/*2 *|D| k* . Therefore *b* violates a random constraint with probability at least *pq* ⩾ 1*/*(2*|D| k*2 *|D| k* ) ⩾ 1*/*4 *|D| k* . □

The rest of the proof is the standard Chernoff and union bounds.

<span id="page-38-0"></span>**Lemma B.3.** *If a k-CSP* (*D,* R) *is not trivially satisfiable. As long as* ∆ ⩾ exp(*O*(*|D| k* ))*, except with probability on*;*|D|,k*(1) *over a random instance of the CSP with n variables and m* def = ∆*n constraints, every assignment violates at least* 1*/*8 *|D| k fraction of the constraints.*

*Proof.* Let *p* be the minimum probability over all assignments *b* : *V → D* that a random constraint is violated by *b*. The previous Lemma implies *p* ⩾ 1*/*4 *|D| k* when *n* ⩾ 2*|D|k*.

Now fix any assignment *b* : *V → D*. In a random instance, violation of the *m* constraints are *m* independent events, each with probability *p<sup>b</sup>* ⩾ *p*. Chernoff inequality implies *b* violates at most 1*/*8 *|D| k* ⩽ *p/*2 fraction of constraints with probability at most exp(*−mp/*8). Taking a union bound over all assignments, some assignment violates fewer than *p/*2 fraction of constraints with probability at most exp(*n* log*|D| − mp/*8), which is at most exp(*−n* log*|D|*) whenever ∆ ⩾ 16(log*|D|*)*/p* = exp(*O*(*|D| k* )). □

# <span id="page-38-1"></span>B.2. **Expansion.**

<span id="page-38-3"></span>[[KMOW17\]](#page-44-0) proved the following result showing expansion of random instances:

<span id="page-38-2"></span><sup>8</sup>Such CSPs are called *reflexive* in [\[AD22](#page-43-22)].

**Lemma B.4** ([KMOW17, Theorem 4.12]<sup>9</sup>). Let  $\lambda \stackrel{\text{def}}{=} \tau - 1 \geqslant 1$ . Fix  $0 < \gamma \leqslant .99\lambda$  and  $0 < \beta < 1/2$ . Then except with probability  $\beta$ , a random instance I with  $m \stackrel{\text{def}}{=} \Delta n$  constraints is  $(t, \gamma)$ -expanding, provided

 $t = \frac{n}{\Delta^{2/(\lambda - \gamma)}} \cdot \frac{1}{k} \left(\frac{\beta}{2^k}\right)^{O(1/\lambda)}.$ 

We do not use their result as is, because their size bound t depends on the failure probability  $\beta$ . Had we used Lemma B.4 to prove Theorem 1.1, we could only conclude that random 3-SAT has a hierarchy solution of level  $\Omega_{\Delta,\beta}(n)$  except with probability  $\beta$ . The bound  $\Omega_{\Delta,\beta}(n)$  is linear in n when  $\beta$  is constant but not when  $\beta = o_n(1)$ . On the other hand, our Theorem 1.1 that uses Lemma 8.16 instead gives linear level lower bound even for subconstant failure probability, as long as  $\Delta$  is constant. Our proof of Lemma 8.16 below follows [KMOW17, Theorem 4.12], improved with a well known trick from [CS88, Lemma 1].

We now restate Lemma 8.16. Recall that  $o_{\zeta;k}(1)$  represents a function  $\varepsilon_k(\zeta)$  that, for every fixed choice of the parameter k,  $\varepsilon_k(\zeta) \to 0$  as  $\zeta \to 0$  from above.

**Lemma B.5.** Let  $\lambda \stackrel{\text{def}}{=} \tau - 1 \geqslant 1$ ,  $0 < \gamma \leqslant \lambda/2$ ,  $\zeta \stackrel{\text{def}}{=} \Delta^{2/(\lambda - \gamma)}/n$ . Except with probability  $o_{\zeta;k}(1)$ , a random k-CSP instance with n vertices and  $m \stackrel{\text{def}}{=} \Delta n$  constraints is  $(t, \gamma)$ -expanding, where

$$t = \frac{n}{\Delta^{2/(\lambda - \gamma)}} \cdot \frac{1}{2^{O(k)}}.$$

*Proof.* By Definition 8.1, the hypergraph not  $(t, \gamma)$ -expanding implies the following: Some constraint subset  $\mathcal{C}'$  of size u and some variable subset S of size s has at least q incidences, where  $q \stackrel{\text{def}}{=} s + \frac{\tau+1-\gamma}{2}u$  and  $1 \leq u \leq t$ . Call this latter event  $\mathcal{E}$ . We will bound its probability.

 $q \stackrel{\text{def}}{=} s + \frac{\tau + 1 - \gamma}{2}u$  and  $1 \leqslant u \leqslant t$ . Call this latter event  $\mathcal{E}$ . We will bound its probability. For fixed u and s, there are  $\binom{m}{u}$  choices of the constraint subset  $\mathcal{C}'$ , and  $\binom{n}{s}$  choices of the variables S. Out of the ku variable occurrences in  $\mathcal{C}'$ , there are  $\binom{ku}{q}$  choices for the q potential incidences.

Consider the event  $\mathcal{E}'$  that these q variable occurrences all belong to S. Suppose, instead of without replacement, we choose the k variables of a constraint with replacement, the probability of  $\mathcal{E}'$  can only increase. This is because a random constraint of k distinct variables has w incidences to S with probability  $\binom{s}{w}/\binom{n}{w}$ , while a constraint of k variables chosen with replacement has w incidences to S with probability  $(\frac{s}{n})^w \geqslant \binom{s}{w}/\binom{n}{w}$ . The probability of  $\mathcal{E}'$  is  $(\frac{s}{n})^q$  when choosing all variables of  $\mathcal{C}'$  independently with replacement.

<span id="page-39-1"></span>Therefore, for fixed u and s, their contribution to the probability of  $\mathcal{E}$  is at most

$$(56) \qquad \binom{m}{u} \binom{n}{s} \binom{ku}{q} \left(\frac{s}{n}\right)^q \leqslant \left(\frac{em}{u}\right)^u \left(\frac{en}{s}\right)^s 2^{ku} \left(\frac{s}{n}\right)^q = \left(e^{1+\frac{s}{u}} 2^k \frac{s}{u}\right)^u \Delta^u \left(\frac{s}{n}\right)^{\frac{\lambda-\gamma}{2}u}$$

where the inequality uses  $\binom{a}{b} \leqslant \left(\frac{ea}{b}\right)^b$  and  $\binom{a}{b} \leqslant 2^a$ , and the equality uses the definitions of m and q. Let  $A \stackrel{\text{def}}{=} \exp(1 + \frac{s}{u})2^k \frac{s}{u}$  and  $\delta \stackrel{\text{def}}{=} (\lambda - \gamma)/2$ . Then

$$(56) = \left(A\Delta \left(\frac{s}{n}\right)^{\delta}\right)^{u} \leqslant \left(A^{1/\delta}\Delta^{1/\delta}\frac{ku}{n}\right)^{\delta u} = (B\zeta ku)^{\delta u}$$

where the inequality uses  $s \leqslant ku$ , and we let  $B \stackrel{\text{def}}{=} A^{1/\delta}$  in the last equality. Summing over all choices of  $1 \leqslant s \leqslant ku$  and  $1 \leqslant u \leqslant t$ ,

$$\mathbb{P}[\mathcal{E}] \leqslant \sum_{1 \leqslant u \leqslant t} ku (B\zeta ku)^{\delta u}.$$

Following [CS88, Lemma 1], split this sum according to whether u is at most  $U \stackrel{\text{def}}{=} 1/(\sqrt{\zeta}kB)$ .

<span id="page-39-0"></span> $<sup>^9\</sup>tau$  in our restatement equals  $\tau + 1$  in [KMOW17, Theorem 4.12], because our CSP is  $\tau$ -wise neutral and theirs is  $(\tau - 1)$ -wise uniform.

Case  $u \leq U$ : We may assume  $\zeta < 1$  because the Lemma concerns  $\zeta$  approaching zero. Then

$$\sum_{1\leqslant u\leqslant U} ku(B\zeta ku)^{\delta u}\leqslant \sum_{1\leqslant u\leqslant U} ku\zeta^{\delta u/2}=O(k\zeta^{\delta/2})=o_{\zeta;k}(1),$$

using  $\delta \geqslant 1/2$ .

Case u > U: By choosing  $t \stackrel{\text{def}}{=} 1/(2\zeta Bk)$ ,

$$\sum_{U < u \leqslant t} ku(B\zeta ku)^{\delta u} \leqslant \sum_{U < u \leqslant t} kt 2^{-\delta u} \leqslant \frac{1}{2\zeta B} \frac{2^{-\delta U}}{1 - 2^{-\delta}} \lesssim_k \frac{2^{-\delta U}}{\zeta}$$

$$= \frac{1}{\zeta 2^{\delta/\left(\sqrt{\zeta} kB\right)}} = o_{\zeta;k}(1).$$

## APPENDIX C. REDUCTION

<span id="page-40-0"></span>Since [Tul09], it has been folkloric that hardness reductions preserve hierarchy lower bounds (Lemma C.1). In this section, we make explicit reduction-based SDP+AIP lower bounds for graph coloring in Corollaries C.7 and C.8, which are simple corollaries of Theorem 1.2 (to an expert in SDP hierarchy lower bound). As mentioned in the abstract of [Tul09], Corollary C.8 is stronger than the NP-hardness results of graph coloring known even under the Unique Games Conjecture and its variants. This section helps compare [CŽ24] with what may follow from Theorem 1.2. We did not include this section in our STOC submission. Chronologically, the results of this section appear after [CŽ24] first appeared.

Consider a hardness reduction B from a CSP  $(D, \mathfrak{R})$  to another  $(D', \mathfrak{R}')$ . Then B maps instances I of  $(D, \mathfrak{R})$  to instances I' of  $(D', \mathfrak{R}')$ . B also maps satisfying assignments  $a \in A_I$  of I to those  $a' \in A_{I'}$  of I'. Suppose every variable in a' depends on at most t variables in a. More precisely, B is t-local if for every variable v' in I', there is a subset  $W_{v'}$  of at most t variables in I and a function  $g_{v'}: A_{W_{v'}} \to D^{v'}$  mapping a satisfying assignment on  $W_{v'}$  to an assignment to v'.

For  $S' \subseteq V(I')$ , define  $W_{S'} \stackrel{\text{def}}{=} \bigcup_{v' \in S'} W_{v'}$ . Extend  $\{g_{v'}\}$  into functions  $g_{S'}: A_{W_{S'}} \to D^{S'}$  for  $S' \subseteq V(I')$ , where

<span id="page-40-3"></span>(57) 
$$g_{S'}(a)(v') \stackrel{\text{def}}{=} g_{v'}\left(a_{W_{v'}}\right) \quad \text{for } v' \in S', a \in A_{W_{S'}}.$$

B preserves local satisfiability if for every constraint C' in I' and local assignment  $a \in A_{W_{V(C')}}$ ,  $g_{V(C')}(a)$  satisfies C'.

The following lemma appeared frequently in the SDP hierarchy lower bound literature, albeit as special cases and not in this general form. For completeness, we include its proof. (The lemma also applies to general CSP, not just k-CSP.)

<span id="page-40-1"></span>**Lemma C.1** (Folklore, see e.g. [Tul09]). Suppose a t-local reduction B maps an instance I of  $(D, \mathfrak{R})$  to an instance I' of  $(D', \mathfrak{R}')$  and preserves local satisfiability. Then for each elementary hierarchy, any level-dt hierarchy solution on I yields a level-d hierarchy solution on I'.

*Proof.* Given a level-dt hierarchy solution s on I, define a dependent function  $s': \left(S' \in \binom{V(I')}{\leqslant d}\right) \to \mathcal{M}^{DS'}$ , where

<span id="page-40-2"></span>(58) 
$$s'(S')(a') \stackrel{\text{def}}{=} \sum_{a \in A_{W_{S'}}, g_{S'}(a) = a'} s(W_{S'})(a)$$
 for  $d$ -small  $S' \subseteq V(I'), a' \in D^{S'}$ .

 $s(W_{S'})$  is defined for d-small S' because  $|W_{S'}| \leq dt$ .

Further, s'(S') is in fact supported on  $A_{S'}$ . Indeed, every a in the sum in Eq. (58) belongs to  $A_{W_{S'}}$  in particular  $a_{V(C')} \in A_{W_{V(C')}}$  for constraints C' contained in S', so  $g_{S'}(a)_{V(C')} \stackrel{(60)}{=} g_{V(C')} \left(a_{W_{V(C')}}\right)$ 

satisfies C' because B preserves local satisfiability. Therefore  $a' = g_{S'}(a)$  satisfies every constraint C' contained in S' whenever a has non-zero contribution to Eq. (58).

s' inherits consistency with projection (Definition 3.1) from s, because for d-small subset  $S' \subseteq V(I')$ ,  $T' \subseteq S'$  and  $a' \in A_{T'}$ ,

$$s'(T')(a') \stackrel{(58)}{=} \sum_{a \in A_{W_{T'}}, g_{T'}(a) = a'} s(W_{T'})(a) \stackrel{(*)}{=} \sum_{b \in A_{W_{S'}}, b_{W_{T'}} = a, g_{T'}(a) = a'} s(W_{S'})(b)$$

$$\stackrel{(60)}{=} \sum_{b \in A_{W_{S'}}, g_{S'}(b) = b', b'_{T'} = a'} s(W_{S'})(b) \stackrel{(58)}{=} \sum_{b' \in A_{S'}, b'_{T'} = a'} s'(S')(b') \stackrel{(2)}{=} \pi_{T'}(s'(S'))(a').$$

In the above, (\*) is because s is a hierarchy solution consistent with projection.

Like s, s' also satisfies the nontriviality condition, because  $s'(\emptyset)(\mathbb{O}) \stackrel{(58)}{=} s(\emptyset)(\mathbb{O}) = 1$ . If the hierarchy is BW, LP, or AIP, then s' is a hierarchy solution by Lemma 3.3. For the SDP hierarchy, we need to verify Eq. (1). Indeed, given an SDP hierarchy solution  $s = ((\alpha_S)_S, (\mu_R)_R)$  of I, let  $s' = ((\alpha'_{S'})_{S'}, (\mu'_{R'})_{R'})$  be given by Eq. (58). Then for d-small  $S', T' \subseteq V(I'), a'_{S'} \in A_{S'}, a'_{T'} \in A_{T'}$ ,

<span id="page-41-1"></span>
$$\langle \alpha'_{S'}(a'_{S'}), \alpha'_{T'}(a'_{T'}) \rangle_{\mathcal{X}} \stackrel{(58)}{=} \sum_{\substack{(a_{S}, a_{T}) \in (A_{W_{S'}}, A_{W_{T'}}) \\ (g_{S'}(a_{S}), g_{T'}(a_{T})) = (a'_{S'}, a'_{T'})}} \sum_{\substack{(a_{S}, a_{T}) \in (A_{W_{S'}}, A_{W_{T'}}) \\ (g_{S'}(a_{S}), g_{T'}(a_{T})) = (a'_{S'}, a'_{T'})}} \mathbb{P}_{b \sim \mu_{W_{S'} \cup W_{T'}}} [b_{W_{S'}} = a_{S}, b_{W_{T'}} = a_{T}]$$

$$(59)$$

$$\stackrel{(\dagger)}{=} \sum_{\substack{a_{S \cup T} \in A_{W_{S' \cup T'}} \\ g_{S' \cup T'}(a_{S \cup T}) = a'_{S' \cup T'}}} \mathbb{P}_{b \sim \mu_{S \cup T}} [b = a_{S} \cup a_{T}],$$

$$\stackrel{(58)}{=} \mathbb{P}_{b' \sim \mu'_{S' \cup T'}} [b' = a'_{S'} \cup a'_{T'}], \stackrel{(\#)}{=} \mathbb{P}_{b' \sim \mu'_{S' \cup T'}} [b'_{S'} = a'_{S'}, b'_{T'} = a'_{T'}].$$

For (†), we write  $a_{S \cup T} \stackrel{\text{def}}{=} a_S \cup a_T$  (we may assume  $(a_S)_{W_{S'} \cap W_{T'}} = (a_T)_{W_{S'} \cap W_{T'}}$ , for otherwise  $(a_S, a_T)$  does not contribute).  $a'_{S' \cup T'} \stackrel{\text{def}}{=} g_{S' \cup T'} (a_S \cup a_T)$ , which coincides with  $g_{S'}(a_S) \cup g_{T'}(a_T)$  by Eq. (60), so  $a'_{S' \cup T'} = a'_{S'} \cup a'_{T'}$  (which also explains (#)).

Claim C.2. For any  $T' \subseteq S' \subseteq V(I')$ , any  $b \in A_{W_{S'}}$ ,

<span id="page-41-0"></span>(60) 
$$g_{T'}(b_{W_{T'}}) = g_{S'}(b)_{T'},$$

Proof. For 
$$v' \in T'$$
,  $g_{T'}\left(b_{W_{T'}}\right)\left(v'\right) \stackrel{(57)}{=} g_{v'}(b_{W_{v'}}) \stackrel{(57)}{=} g_{S'}(b)(v') = (g_{S'}(b))_{T'}(v').$ 

<span id="page-41-2"></span>**Lemma C.3.** Suppose a t-local reduction B maps an instance I of  $(D, \mathfrak{R})$  to an instance I' of  $(D', \mathfrak{R}')$  and preserves local satisfiability. Then for each combined hierarchy, any level-dt hierarchy solution on I yields a level-d hierarchy solution on I'.

*Proof.* Starting with a solution  $s = (s_1, s_2)$  to I in the combined hierarchy, define  $s' = (s'_1, s'_2)$  from s by Eq. (58). Then each  $s'_i$  is derived from  $s_i$  by Eq. (58). Lemma C.1 implies each  $s'_i$  is a hierarchy solution to I'.

Now consider either the LP+AIP or the BW+AIP hierarchy. Solutions are of the form  $s = (s_1, s_2)$ , where  $s_i : (S \in \mathcal{S}_d) \to \mathcal{M}_i^{A_S}$ . For LP+AIP or BW+AIP,  $\mathcal{M}_1 \in \{\mathbb{B}, \mathbb{R}_+\}$ . Then  $x \in \mathcal{M}_1 \setminus \{0\}$  implies  $x + y \neq 0$  for  $y \in \mathcal{M}_1$ . It remains to verify  $\sup(s_1'(S')) \supseteq \sup(s_2'(S'))$  for d-small

 $S' \subseteq V(I')$ . Eq. (58) implies  $\operatorname{supp}(s_i'(S')) \subseteq g_{S'}(\operatorname{supp}(s_i(W_{S'})))$  for each i.  $s_1'$  satisfies the stronger property  $\operatorname{supp}(s_1'(S')) = g_{S'}(\operatorname{supp}(s_1(W_{S'})))$ , thanks to the aforementioned property of  $\mathcal{M}_1$ . Thus

$$\operatorname{supp}(s_2'(S')) \subseteq g_{S'}(\operatorname{supp}(s_2(W_{S'}))) \stackrel{(*)}{\subseteq} g_{S'}(\operatorname{supp}(s_1(W_{S'}))) = \operatorname{supp}(s_1'(S')),$$

where (\*) is due to  $\operatorname{supp}(s_2(W_{S'})) \subseteq \operatorname{supp}(s_1(W_{S'}))$ , which holds because s is a solution to the combined hierarchy.

Finally consider the SDP+AIP hierarchy. Solutions are of the form  $s = (\alpha, r)$ , where  $r = (\mu, w)$  is a level-2d LP+AIP solution, and the level-d SDP vector solution  $\alpha$  induces  $\mu$ . Since s' is derived from s by Eq. (58),  $(\alpha', \mu')$  is derived from  $(\alpha, \mu)$  by Eq. (58), so  $\alpha'$  induces  $\mu'$  by Eq. (59).  $\square$ 

<span id="page-42-2"></span>**Lemma C.4.** Fix  $k \ge 3$ . There is a k-CSP such that except with probability  $o_{n;k}(1)$ , its random instance I with n variables and  $O_k(n)$  constraints has an SDP+AIP hierarchy solution of level  $\Omega_k(n)$ , but every assignment to I satisfies at most  $1/2^{\Omega(k)}$  fraction of constraints of I.

*Proof.* Apply Theorem 1.2 and [Tul09, Lemma A.1] to the k-CSP with the predicate Q, where  $Q \subseteq \{0,1\}^k$  is the union of the Hadamard predicate of the Max-k-CSP in [Tul09, Fact 2.4], which supports a pairwise uniform distribution, and any Hamming ball of radius 2, which supports a pairwise neutral AIP assignment (Proposition 4.5). Q contains only  $O(k^2)/2^k = 1/2^{\Omega(k)}$  fraction of all  $2^k$  assignments to a k-ary constraint.

A version of Lemma C.4 for SDP only appeared in [Tul09, Corollary 6.2], and was the starting point of the following SDP hierarchy lower bounds. A hierarchy lower bound for C-vs-K graph coloring means a hierarchy solution for C-coloring on a graph G, where G is not K-colorable.

**Theorem C.5** ([Tul09, Theorem 6.5]). There is a level- $\Omega_C(N)$  SDP hierarchy lower bound for C-vs- $2^{\Omega(C)}$  graph coloring on an N-vertex graph, for every large enough constant C.

**Theorem C.6** ([Tul09, Theorem 6.7]). There is a level-d SDP hierarchy lower bound for C-vs-K graph coloring on an N-vertex graph, where

$$C = 2^{O(\log N/\log\log N)} \qquad \qquad K = N/2^{O(\log N/\log\log N)} \qquad \qquad d = 2^{\Omega(\log N/\log\log N)}.$$

Apply Lemmas C.3 and C.4 to the reductions in these two theorems, we strengthen the results to SDP+AIP, with no loss in parameters. We can apply Lemma C.3 because Tulsiani implicitly verified that these reductions are t-local for an appropriate t and preserve local satisfiability.

<span id="page-42-0"></span>Corollary C.7. There is a level- $\Omega_C(N)$  SDP+AIP hierarchy lower bound for C-vs- $2^{\Omega(C)}$  graph coloring on an N-vertex graph, for every large enough constant C.

<span id="page-42-1"></span>**Corollary C.8.** There is a level-d SDP+AIP hierarchy lower bound for C-vs-K graph coloring on an N-vertex graph, where

$$C = 2^{O(\log N/\log\log N)} \qquad \qquad K = N/2^{O(\log N/\log\log N)} \qquad \qquad d = 2^{\Omega(\log N/\log\log N)}.$$

[KOWŽ23] showed that C-vs-K graph coloring is NP-hard for every constant  $C \geqslant 4$  and  $K = \binom{C}{\lfloor C/2 \rfloor}$ . It is possible to prove linear-level SDP+AIP lower bound for the same choices of C and K, sharpening Corollary C.7. We omit the details.

For comparison, [CŽ24] obtained the following lower bound for graph coloring:

**Theorem C.9** ([CŽ24]). For every constant  $d \ge 2$ , constant  $K \ge 3$ , there is a level-d SDP+AIP hierarchy lower bound for 3-vs-K graph coloring.

# References

- <span id="page-43-7"></span>[AD08] Albert Atserias and Víctor Dalmau. A Combinatorial Characterization of Resolution Width. *Journal of Computer and System Sciences*, 74(3):323–334, 2008. Computational Complexity 2003.
- <span id="page-43-22"></span>[AD22] Albert Atserias and Víctor Dalmau. Promise Constraint Satisfaction and Width. In *Proceedings of the 2022 Annual ACM-SIAM Symposium on Discrete Algorithms*, pages 1129–1153, 2022.
- [AGH17] Per Austrin, Venkatesan Guruswami, and Johan Håstad. (2 + *ε*)-Sat Is NP-hard. *SIAM Journal on Computing*, 46(5):1554–1573, 2017.
- <span id="page-43-21"></span>[AH11] Per Austrin and Johan Håstad. Randomly Supported Independence and Resistance. *SIAM Journal on Computing*, 40(1):1–27, 2011.
- <span id="page-43-11"></span>[Ahn20] Kwangjun Ahn. A Simpler Strong Refutation of Random *k*-XOR. In *Approximation, Randomization, and Combinatorial Optimization. Algorithms and Techniques*, pages 2:1–2:15, 2020.
- <span id="page-43-3"></span>[AM09] Per Austrin and Elchanan Mossel. Approximation Resistant Predicates from Pairwise Independence. *Computational Complexity*, 18:249–272, 2009.
- <span id="page-43-10"></span>[AOW15] Sarah R. Allen, Ryan O'Donnell, and David Witmer. How to Refute a Random CSP. In *2015 IEEE 56th Annual Symposium on Foundations of Computer Science*, pages 689–708, 2015.
- <span id="page-43-0"></span>[BBKO21] Libor Barto, Jakub Bulín, Andrei Krokhin, and Jakub Opršal. Algebraic Approach to Promise Constraint Satisfaction. *Journal of the ACM*, 68(4), 2021.
- <span id="page-43-6"></span>[BCK15] Boaz Barak, Siu On Chan, and Pravesh K. Kothari. Sum of Squares Lower Bounds from Pairwise Independence. In *Proceedings of the Forty-Seventh Annual ACM Symposium on Theory of Computing*, page 97–106. ACM, 2015.
- <span id="page-43-8"></span>[BG19] Joshua Brakensiek and Venkatesan Guruswami. An Algorithmic Blend of LPs and Ring Equations for Promise CSPs. In *Proceedings of the Thirtieth Annual ACM-SIAM Symposium on Discrete Algorithms*, page 436–455. SIAM, 2019.
- [BG21] Joshua Brakensiek and Venkatesan Guruswami. Promise Constraint Satisfaction: Algebraic Structure and a Symmetric Boolean Dichotomy. *SIAM Journal on Computing*, 50(6):1663–1700, 2021.
- <span id="page-43-2"></span>[BGMT12] Siavosh Benabbas, Konstantinos Georgiou, Avner Magen, and Madhur Tulsiani. SDP Gaps from Pairwise Independence. *Theory of Computing*, 8(12):269–289, 2012.
- <span id="page-43-9"></span>[BGWŽ20] Joshua Brakensiek, Venkatesan Guruswami, Marcin Wrochna, and Stanislav Živný. The Power of the Combined Basic Linear Programming and Affine Relaxation for Promise Constraint Satisfaction Problems. *SIAM Journal on Computing*, 49(6):1232–1248, 2020.
- <span id="page-43-20"></span>[BK09] Libor Barto and Marcin Kozik. Constraint Satisfaction Problems of Bounded Width. In *2009 50th Annual IEEE Symposium on Foundations of Computer Science*, pages 595–603, 2009.
- <span id="page-43-12"></span>[BSW01] Eli Ben-Sasson and Avi Wigderson. Short Proofs Are Narrow—Resolution Made Simple. *Journal of the ACM*, 48(2):149–169, 2001.
- <span id="page-43-13"></span>[Bul17] Andrei A. Bulatov. A Dichotomy Theorem for Nonuniform CSPs. In *2017 IEEE 58th Annual Symposium on Foundations of Computer Science*, pages 319–330, 2017.
- <span id="page-43-14"></span>[Bul20] Andrei A. Bulatov. A Dichotomy Theorem for Nonuniform CSPs Simplified. *CoRR*, abs/2007.09099, 2020.
- <span id="page-43-5"></span>[Cha16] Siu On Chan. Approximation Resistance from Pairwise-Independent Subgroups. *Journal of the ACM*, 63(3), 2016.
- <span id="page-43-4"></span>[CM13] Siu On Chan and Michael Molloy. A Dichotomy Theorem for the Resolution Complexity of Random Constraint Satisfaction Problems. *SIAM Journal on Computing*, 42(1):27–60, 2013.
- <span id="page-43-16"></span>[Con22] Adam Ó Conghaile. Cohomology in Constraint Satisfaction and Structure Isomorphism. In *47th International Symposium on Mathematical Foundations of Computer Science, 2022*, volume 241, pages 75:1–75:16, 2022.
- <span id="page-43-23"></span>[CS88] Vašek Chvátal and Endre Szemerédi. Many Hard Examples for Resolution. *Journal of the ACM*, 35(4):759–768, 1988.
- <span id="page-43-15"></span>[CŽ22] Lorenzo Ciardo and Stanislav Živný. CLAP: A New Algorithm for Promise CSPs. In *Proceedings of the 2022 Annual ACM-SIAM Symposium on Discrete Algorithms*, pages 1057–1068, 2022.
- <span id="page-43-19"></span>[CŽ23a] Lorenzo Ciardo and Stanislav Živný. Approximate Graph Colouring and Crystals. In *Proceedings of the 2023 Annual ACM-SIAM Symposium on Discrete Algorithms*, pages 2256–2267, 2023.
- <span id="page-43-17"></span>[CŽ23b] Lorenzo Ciardo and Stanislav Živný. Approximate Graph Colouring and the Hollow Shadow. In *Proceedings of the 55th Annual ACM Symposium on Theory of Computing*, page 623–631. ACM, 2023.
- <span id="page-43-1"></span>[CŽ23c] Lorenzo Ciardo and Stanislav Živný. Hierarchies of Minion Tests for PCSPs through Tensors. In *Proceedings of the 2023 Annual ACM-SIAM Symposium on Discrete Algorithms*, pages 568–580, 2023.
- <span id="page-43-18"></span>[CŽ24] Lorenzo Ciardo and Stanislav Živný. Semidefinite Programming and Linear Equations vs. Homomorphism Problems. In *Proceedings of the 56th Annual ACM Symposium on Theory of Computing*, 2024. To appear.

- <span id="page-44-17"></span>[DFHT21] Irit Dinur, Yuval Filmus, Prahladh Harsha, and Madhur Tulsiani. Explicit SoS Lower Bounds from High-Dimensional Expanders. In *12th Innovations in Theoretical Computer Science Conference, 2021*, volume 185, pages 38:1–38:16, 2021.
- <span id="page-44-8"></span>[DO23] Victor Dalmau and Jakub Opršal. Local Consistency as a Reduction Between Constraint Satisfaction Problems. *CoRR*, abs/2301.05084, 2023.
- <span id="page-44-15"></span>[dSZ22] Benoîte de Saporta and Mounir Zili. *Martingales and Financial Mathematics in Discrete Time*. Wiley-ISTE, 2022.
- <span id="page-44-4"></span>[Fei02] Uriel Feige. Relations between Average Case Complexity and Approximation Complexity. In *Proceedings of the Thiry-Fourth Annual ACM Symposium on Theory of Computing*, page 534–543. ACM, 2002.
- <span id="page-44-6"></span>[FKO06] Uriel Feige, Jeong Han Kim, and Eran Ofek. Witnesses for Non-Satisfiability of Dense Random 3CNF Formulas. In *2006 47th Annual IEEE Symposium on Foundations of Computer Science*, pages 497–508, 2006.
- [GJ76] M. R. Garey and D. S. Johnson. The Complexity of Near-Optimal Graph Coloring. *Journal of the ACM*, 23(1):43–49, Jan 1976.
- <span id="page-44-19"></span>[Gör02] Frank Göring. A Proof of Menger's Theorem by Contraction. *Discussiones mathematicae: Graph theory*, 22, 2002(1):111–112, 2002. Faculty of Mathematics, Computer Science and Econometrics, University of Zielona Góra.
- <span id="page-44-1"></span>[Gri01] Dima Grigoriev. Linear Lower Bound on Degrees of Positivstellensatz Calculus Proofs for the Parity. *Theoretical Computer Science*, 259(1):613–622, May 2001.
- <span id="page-44-13"></span>[GS12] Venkatesan Guruswami and Ali Kemal Sinop. Faster SDP Hierarchy Solvers for Local Rounding Algorithms. In *2012 IEEE 53rd Annual Symposium on Foundations of Computer Science*, pages 197–206, 2012.
- [GS20] Venkatesan Guruswami and Sai Sandeep. *d*-To-1 Hardness of Coloring 3-Colorable Graphs with *O*(1) Colors. In *47th International Colloquium on Automata, Languages, and Programming*, pages 62:1–62:12, 2020.
- <span id="page-44-16"></span>[HL22] Max Hopkins and Ting-Chun Lin. Explicit Lower Bounds Against Ω(*n*)-Rounds of Sum-of-Squares . In *2022 IEEE 63rd Annual Symposium on Foundations of Computer Science*, pages 662–673, 2022.
- <span id="page-44-0"></span>[KMOW17] Pravesh K. Kothari, Ryuhei Mori, Ryan O'Donnell, and David Witmer. Sum of Squares Lower Bounds for Refuting Any CSP. In *Proceedings of the 49th Annual ACM SIGACT Symposium on Theory of Computing*, page 132–145. ACM, 2017.
- <span id="page-44-7"></span>[KO22] Andrei Krokhin and Jakub Opršal. An Invitation to the Promise Constraint Satisfaction Problem. *ACM SIGLOG News*, 9(3):30–59, Aug 2022.
- <span id="page-44-20"></span>[KOWŽ23] Andrei Krokhin, Jakub Opršal, Marcin Wrochna, and Stanislav Živný. Topology and Adjunction in Promise Constraint Satisfaction. *SIAM Journal on Computing*, 52(1):38–79, 2023.
- <span id="page-44-9"></span>[Lau09] Monique Laurent. *Sums of Squares, Moment Matrices and Optimization Over Polynomials*, pages 157– 270. Springer, 2009.
- [LY94] Carsten Lund and Mihalis Yannakakis. On the Hardness of Approximating Minimization Problems. *Journal of the ACM*, 41(5):960–981, Sep 1994.
- <span id="page-44-18"></span>[LZ22] Anthony Leverrier and Gilles Zémor. Quantum Tanner Codes. In *2022 IEEE 63rd Annual Symposium on Foundations of Computer Science*, pages 872–883, 2022.
- <span id="page-44-14"></span>[Mos10] Elchanan Mossel. Gaussian Bounds for Noise Correlation of Functions. *Geometric and Functional Analysis*, 2010.
- <span id="page-44-2"></span>[MW16] Ryuhei Mori and David Witmer. Lower Bounds for CSP Refutation by SDP Hierarchies. In *Approximation, Randomization, and Combinatorial Optimization. Algorithms and Techniques*, volume 60, pages 41:1–41:30, 2016.
- <span id="page-44-12"></span>[O'D17] Ryan O'Donnell. SOS Is Not Obviously Automatizable, Even Approximately. In *8th Innovations in Theoretical Computer Science Conference*, volume 67, pages 59:1–59:10, 2017.
- <span id="page-44-3"></span>[RRS17] Prasad Raghavendra, Satish Rao, and Tselil Schramm. Strongly Refuting Random CSPs below the Spectral Threshold. In *Proceedings of the 49th Annual ACM SIGACT Symposium on Theory of Computing*, page 121–131. ACM, 2017.
- <span id="page-44-5"></span>[RSW16] Ilya Razenshteyn, Zhao Song, and David P. Woodruff. Weighted Low Rank Approximations with Provable Guarantees. In *Proceedings of the Forty-Eighth Annual ACM Symposium on Theory of Computing*, page 250–263. ACM, 2016.
- <span id="page-44-11"></span>[RW17] Prasad Raghavendra and Benjamin Weitz. On the Bit Complexity of Sum-of-Squares Proofs. In *44th International Colloquium on Automata, Languages, and Programming*, volume 80, pages 80:1–80:13, 2017.
- <span id="page-44-10"></span>[Sch86] Alexander Schrijver. *Theory of Linear and Integer Programming*. Wiley-Interscience series in discrete mathematics and optimization. 1986.

[Sch08] Grant Schoenebeck. Linear Level Lasserre Lower Bounds for Certain *k*-CSPs. In *Proceedings of the 2008 49th Annual IEEE Symposium on Foundations of Computer Science*, page 593–602, 2008.

[Tul09] Madhur Tulsiani. CSP Gaps and Reductions in the Lasserre Hierarchy. In *Proceedings of the Forty-First Annual ACM Symposium on Theory of Computing*, page 303–312. ACM, 2009.

[TW13] Madhur Tulsiani and Pratik Worah. LS+ Lower Bounds from Pairwise Independence. In *2013 IEEE Conference on Computational Complexity*, pages 121–132, 2013.

[Zhu20] Dmitriy Zhuk. A Proof of the CSP Dichotomy Conjecture. *Journal of the ACM*, 67(5), 2020.

ECCC ISSN 1433-8092

https://eccc.weizmann.ac.il