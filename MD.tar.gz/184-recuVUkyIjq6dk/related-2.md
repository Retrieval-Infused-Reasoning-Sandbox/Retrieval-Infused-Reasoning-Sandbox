ELSEVIER

Contents lists available at ScienceDirect

# Journal of Rare Earths

journal homepage: http://www.journals.elsevier.com/journal-of-rare-earths

![](_page_0_Picture_5.jpeg)

# A comparative DFT+U study of CO oxidation on Pd- and Zr-doped ceria\*

Lu Chen, Xinping Wu, Xueqing Gong\*

Key Laboratory for Advanced Materials and Joint International Research Laboratory for Precision Chemistry and Molecular Engineering, Feringa Nobel Prize Scientist Joint Research Center, Frontiers Science Center for Materiobiology and Dynamic Chemistry, Centre for Computational Chemistry and Research Institute of Industrial Catalysis, School of Chemistry and Molecular Engineering, East China University of Science and Technology, Shanghai 200237, China

#### ARTICLE INFO

Article history:
Received 22 February 2022
Received in revised form
13 May 2022
Accepted 17 May 2022
Available online 20 May 2022

Keywords: CeO<sub>2</sub> Metal doping CO oxidation Carbonate DFT+U Rare earths

#### ABSTRACT

Metal-doped ceria catalysts have been applied in many important catalytic processes. In this work, we performed density functional theory calculations corrected by on-site Coulomb interactions to study the Pd- and Zr-doped  $CeO_2(111)$  surfaces with the dopant at different locations. The formation of oxygen vacancies and CO oxidation were systematically calculated on the various doped surfaces. We find that both Pd and Zr doping can activate the surface lattice O and reduce the energy barriers of CO oxidation. However, the promotion effect of the Zr dopant is limited to its existence in the first surface layer, while for the Pd dopant, the surface activity can be greatly enhanced even it occurs far below the surface. Besides,  $CO_2$  can be generated directly on the Pd-doped surfaces through reaction between CO and surface O, while the surface intermediate  $CO_2^{b-}$  may readily form and restrict the releasing of  $CO_2$  by further oxidation to carbonates on the Zr-doped surfaces. Electronic analyses show that the doped Pd exists as  $Pd^{4+}$  and it has stronger electron affinity than other surface species during CO oxidation, contributing to the easy  $Pd^{4+}$  to  $Pd^{2+}$  transformation accompanied by direct  $CO_2$  formation at Pd-doped ceria.

© 2022 Chinese Society of Rare Earths. Published by Elsevier B.V. All rights reserved.

#### 1. Introduction

As one important reducible rare earth metal oxide, ceria (CeO<sub>2</sub>) is blossoming in catalysis largely due to its extraordinary oxygen storage capacity (OSC) which owes to the redox property of Ce cations as well as the mobility and reactivity of oxygen atoms.<sup>1–3</sup> A lot of efforts have been devoted to the preparation of improved ceria-based catalysts with better catalytic performance through metal doping and loading small particles of metal or metal-oxide.<sup>4–8</sup> Single-atom metal doped ceria is particularly important and has been well applied to a series of catalytic reactions.<sup>9–11</sup> Different types of metal atoms have been tried to be doped into ceria-based catalysts, including transition metals (Zr, Ru, Pd,

<span id="page-0-0"></span>\* Corresponding author. E-mail address: xgong@ecust.edu.cn (X. Gong). etc.)<sup>12–14</sup> and lanthanide metals (La, Pr, Gd, etc.),<sup>3,15,16</sup> and many of them were proved to be effective both experimentally and theoretically. For example, Zhang et al.<sup>17</sup> prepared Pr-doped CeO<sub>2</sub> by a coprecipitation method and revealed that the oxygen vacancy induced by the Pr dopant could contribute to the Prins condensation-hydrolysis of isobutene. Chitpakdee et al.<sup>13</sup> investigated the selective reduction of NO by NH<sub>3</sub> on the Ru-doped CeO<sub>2</sub>(111) surface by density functional theory (DFT) calculations, and they proposed that the Ru dopant can enhance the Lewis acidity of ceria and improve the formation of water.

Among the metal-doped ceria catalysts, the widely used Pd- and Zr-doped ones have attracted much attention. Pd-doped CeO<sub>2</sub> was reported to be beneficial in many fields, such as three-way catalytic reaction, <sup>18</sup> low-temperature CO oxidation, <sup>14</sup> methanol detection, <sup>19</sup> etc. Also, Zr-doped CeO<sub>2</sub> was determined to be highly active in photocatalytic reactions, <sup>12</sup> water splitting, <sup>20</sup> CO<sub>2</sub> conversion, <sup>21</sup> dry reforming of methane, <sup>22</sup> etc. The investigations into doped model systems have made some progresses in recent years, Su et al. <sup>23</sup> constructed two facile structures to model a series of transition metal doped ceria which showed high stability and reactivity through systematic theoretical calculations. In addition, multiple

<sup>\*</sup> Foundation item: Project supported by National Key R&D Program of China (2018YFA0208602), National Natural Science Foundation of China (21825301, 22003016, 92045303), the Fundamental Research Funds for the Central Universities (222201717003), Shanghai Municipal Science and Technology Major Project (2018SHZDZX03) and the Programme of Introducing Talents of Discipline to Universities (B16017).

synthesis methods were developed to prepare various doped ceria. Florea et al. <sup>24</sup> used wet impregnation to get doped ceria with a homogenous dopant distribution which was confirmed by multiple spectral methods. Bao et al. <sup>25</sup> obtained surface and bulk doped ceria samples by co-precipitation method and determined the location of the dopants with a selective chemisorption method. Liu et al. <sup>26</sup> even proposed a joint bulk and surface doping methodology for ceria to develop new oxide-ion conductors in solid oxide fuel cells. However, it remains to be challenging to understand the detailed configurations of doped structures as well as the positions and roles of the dopants during the reactions, which may also prevent the design and the application of doped ceria catalysts.

As the doped ceria has shown excellent activity and selectivity in many catalytic reactions, <sup>27,28</sup> the classical CO oxidation is still one of the most popular processes to evaluate the performance of catalysts, 3,29,30 It is well known that the formation of carbonate species may readily occur during CO oxidation at metal oxides, leading to the poisoning of the surface. 31,32 Therefore, to help avoid carbonates formation, it is necessary to understand the complete pathway of CO oxidation which has indeed been the key topics in many previous studies. Chen et al.<sup>33</sup> located a bent adsorbed CO<sub>2</sub> species at various CeO<sub>2</sub> surfaces which could give a clear dangling bond for the formation of carbonate. Song et al.<sup>34</sup> suggested that the oxygen vacancy at CeO2 may reduce the chance for the formation of such bent  $CO_2^{\delta-}$  intermediate, which then favors the desorption of CO<sub>2</sub> rather than its further oxidation. Wang et al.<sup>35</sup> reported that the surface oxygen with lower vacancy formation energies tends to react with CO to form CO2 directly under the influence of the metal dopants.

In this work, by performing density function theory (DFT) calculations, we systematically investigated a series of doped- $CeO_2(111)$  surfaces with the Pd and Zr single-atoms being incorporated into different surface layers. Our calculated results show that these surfaces can exhibit different structural and electronic properties, which can also be witnessed in the formation of oxygen vacancies and the oxidation of CO. We also compared the effects of these two types of dopants (i.e., Pd and Zr) on the catalysts and summarized the relationship between the depth of doping and its promoting effect.

#### 2. Computational methods

All calculations were carried out using the Vienna Ab initio Simulation Package (VASP).<sup>36,37</sup> The Perdew–Burke–Ernzerhof (PBE) functional  $^{38}$  with an effective U value of 5.0 eV (DFT+U) was employed to better describe the behavior of Ce 4f electrons, which was consistent with previous theoretical studies.<sup>39,40</sup> The projector-augmented wave (PAW) method<sup>41</sup> was used to describe the core-electron interaction with the C (2s, 2p), O (2s, 2p), and Ce (4f, 5s, 5p, 5d, 6s), Pd (4d, 5s) and Zr (4d, 5s) shells being treated as valence electrons and expanded in plane-waves with a cutoff energy of 400 eV. The calculated lattice parameter of bulk ceria (0.5450 nm) was in good agreement with the experimental value (0.5411 nm).<sup>42</sup> All calculations were converged until the Hellman-Feynman forces on each relaxed ion were less than 0.5 eV/nm. The doped  $CeO_2(111)$  surface was extended at a  $(3 \times 3)$  surface cell which contains fifteen atomic layers (five trilayers). The  $2 \times 2 \times 1$  kpoint mesh was used for the Brillouin-zone integration. A large vacuum gap (~1.2 nm) perpendicular to the surface was employed and the bottom three atomic layers (one trilayer) were fixed during structural optimizations. A constrained optimization scheme<sup>43</sup> was used to search for the transition state (TS) structures. Vibrational analysis was further used to confirm the TS with only one imaginary frequency.

The adsorption energies ( $E_{ads}$ ) of CO were calculated as follows:

$$E_{\rm ads} = E_{\rm CO} + E_{\rm sur} - E_{\rm CO/sur} \tag{1}$$

where  $E_{\rm CO}$ ,  $E_{\rm sur}$  and  $E_{\rm CO/sur}$  are the calculated total energies of the single CO, the bare surface and the adsorption complex, respectively. This equation indicates that the more positive the  $E_{\rm ads}$  is, the stronger the surface adsorption of CO is.

The formation energies of the oxygen vacancy on the surface  $(E_{OV})$  were calculated by

$$E_{\text{OV}} = E_{\text{surf-OV}} + \frac{1}{2}E_{\text{O}_2} - E_{\text{surf}}$$
 (2)

where  $E_{\rm surf-OV}$ ,  $E_{\rm O_2}$ , and  $E_{\rm surf}$  are the calculated total energies of the surface with one oxygen vacancy, an  $\rm O_2$  molecule, and the stoichiometric surface, respectively. This equation indicates that the more positive the  $E_{\rm OV}$  is, the more difficult the oxygen vacancy can form on the surface.

#### 3. Results and discussion

#### 3.1. Doped CeO<sub>2</sub>(111) surfaces

To better understand the single metal atom doping for ceria, we constructed a series of doped CeO<sub>2</sub>(111) surfaces by substituting one Ce at different locations (from the first to third Ce layer) with one Pd or Zr atom. For Pd doping, it is well known that there are two common configurations, i.e., the octahedral one and the planar square one, when the Pd dopant exists in the first Ce atomic layer as many studies reported recently.<sup>23,29</sup> Thus, we also tested the stabilities of the two configurations of Pd doping in different surface layers at first. We found that, when occurring at different positions, the octahedral configuration in which the Pd atom largely maintains the origin position of substituted Ce is always thermodynamically more favorable than the planar square one in which the Pd undergoes strong relaxation. Moreover, the stability of this configuration is obviously enhanced with the increase of the depth of doping (see Fig. S1 and Table S1). As for the Zr doping, there is no configuration variation since both CeO<sub>2</sub> and ZrO<sub>2</sub> prefer the facecentered cubic fluorite structures and it is unlikely for Zr to undergo large structural distortion in the CeO<sub>2</sub> matrix.<sup>30,44</sup> Hence, we mainly focused on the octahedral configuration in the following studies of Pd and Zr doping. The calculated formation energies of these doped surfaces are listed in the Supplementary data (see Table S2).

The calculated doped surface structures are shown in Fig. 1, which are denoted as  $Pd_{nL}$ -doped and  $Zr_{nL}$ -doped  $CeO_2(111)$  (n = 1, 2, 3 for the positions of the dopant). As we have mentioned, the Pd and Zr dopants almost stay in the original positions of the substituted Ce atoms. From Fig. 1(a), one may still notice that only the O atom directly below the Pd atom moves away from it with the O-Pd distance of ~0.287 nm which is significantly larger than those of other Pd–O bonds (~0.216 nm). For the second layer Pd doping in Fig. 1(b), the two O atoms directly above and below the Pd atom both get closer to it and form shorter bonds (~0.210 nm) than other Pd-O bonds (~0.236 nm). However, the same two O atoms relax away from the Pd atom with the distance of ~0.281 nm which is again longer than the other Pd-O bonds (~0.212 nm) for the third layer doping shown in Fig. 1(c). By contrast, as illustrated in Fig. 1(d-f), the surrounding O atoms of the doped Zr always move slightly closer to it by only ~0.006 nm when the dopant occurs at different lavers.

In addition, the calculated net Bader charges of the dopant are summarized in Table 1. The charges of Pd dopants were calculated

<span id="page-2-0"></span>![](_page_2_Figure_2.jpeg)

**Fig. 1.** Calculated structures (side view) of  $Pd_{1L^-}(a)$ ,  $Pd_{2L^-}(b)$ ,  $Pd_{3L^-}(c)$ ,  $Zr_{1L^-}(d)$ ,  $Zr_{2L^-}(e)$ , and  $Zr_{3L^-}(f)$  doped  $CeO_2(111)$  surfaces. Cerium, oxygen, palladium and zirconium atoms are represented by ivory, red, dark blue and light blue balls, respectively.

<span id="page-2-1"></span>**Table 1**Calculated net Bader charges (in |e|) of the dopants on doped CeO<sub>2</sub>(111) surfaces.

|                       | Pd <sub>nL</sub> -doped |                         | Zr <sub>nL</sub> -doped |                         |  |
|-----------------------|-------------------------|-------------------------|-------------------------|-------------------------|--|
|                       | Stoichiometric          | O <sub>v</sub>          | Stoichiometric          | O <sub>v</sub>          |  |
| n = 1 $n = 2$ $n = 3$ | 1.368<br>1.408<br>1.447 | 0.920<br>0.981<br>1.069 | 2.546<br>2.615<br>2.617 | 2.493<br>2.622<br>2.628 |  |

to be 1.368, 1.408 and 1.447 |e|, respectively, while those of Zr dopants are 2.546, 2.615 and 2.617 |e|, respectively, at the three different positions. These results gave the same trend that when the dopant goes deeper below the top surface, it becomes more positively charged. Also, both the doped Pd and Zr cations appear to have the formal oxidation state of +4, as proposed by other studies.  $^{12,45}$ 

#### <span id="page-2-4"></span>3.2. Oxygen vacancies

Previous studies have shown that the doping of heteroatoms at ceria surfaces can increase their reactivities by lowering the oxygen vacancy ( $O_v$ ) formation energies. <sup>27,29</sup> So it is necessary to learn how the formation of surface  $O_v$  will be affected by the metal doping at different layers. The calculated formation energies of  $O_v$  at  $Pd_{nL}$  and  $Zr_{nL}$ -doped  $CeO_2(111)$  surfaces are listed in Table 2 and the corresponding electronic structures are illustrated in Fig. 2.

As one can see, the calculated  $E_{\rm OV}$  values at Pd<sub>1L</sub>-, Pd<sub>2L</sub>-, Pd<sub>3L</sub>-doped CeO<sub>2</sub>(111) are 0.86, 1.20 and 2,44 eV, respectively. Though these values are lower than that at pristine CeO<sub>2</sub>(111) (2.52 eV), the introduced Pd at the first, second and third layer actually has

<span id="page-2-2"></span>**Table 2** Calculated  $O_V$  formation energies (in eV) at  $Pd_{nL}$ - and  $Zr_{nL}$ -doped  $CeO_2(111)$  surfaces.

|                         | n = 1 | n = 2 | n = 3 |
|-------------------------|-------|-------|-------|
| Pd <sub>nL</sub> -doped | 0.86  | 1.20  | 2.44  |
| Zr <sub>nL</sub> -doped | 1.77  | 2.62  | 2.55  |

<span id="page-2-3"></span>![](_page_2_Figure_12.jpeg)

**Fig. 2.** Calculated spin density isosurfaces (side view) of  $Pd_{1L^-}$  (a),  $Pd_{2L^-}$  (b),  $Pd_{3L^-}$  (c),  $Zr_{1L^-}$  (d),  $Zr_{2L^-}$  (e), and  $Zr_{3L^-}$  (f) doped  $CeO_2$ (111) surfaces with one surface  $O_v$ . Spin-up and down isosurfaces are plotted in yellow and blue, respectively. The positions of surface  $O_v$  are specified by purple dashed circles.

decreasing ability in activating the surface oxygen. Moreover, as we can see from Fig. 2(a–c), there is no Ce<sup>4+</sup> being reduced when  $O_v$  is formed on  $Pd_{nL}$ -doped  $CeO_2(111)$  surfaces, which is different from the case at pristine  $CeO_2(111)$  that two  $Ce^{4+}$  are reduced to two  $Ce^{3+}$  after  $O_v$  formation. Our calculations also showed that, once the surface  $O_v$  is formed, the charges of these Pd dopants generally become ~0.4 |e| less positive (see Table 1), indicating that they are reduced to  $Pd^{2+}$ .

For the Zr-doped surfaces, the  $O_{\rm V}$  formation energy was calculated to be 1.77 eV when the Zr dopant is introduced to the first layer, while the values are very close to that at pristine  ${\rm CeO_2(111)}$  when it occurs at lower layers. Besides, with the formation of  $O_{\rm V}$ , there always form two  ${\rm Ce^{3+}}$  no matter where the position of Zr dopant is (Fig. 2(d–f)), which is the clear evidence that only  ${\rm Ce^{4+}}$  are reduced in this process. From Table 1, we can also find that there is almost no change for the calculated charges of the Zr dopants. Therefore, we can conclude that the Pd dopant is generally more effective than Zr in activating the surface O at  ${\rm CeO_2(111)}$  since the formation energies of  ${\rm O_{\rm V}}$  at  ${\rm Pd}_{n\rm L}$ -doped surfaces are all much lower than those at  ${\rm Zr}_{n\rm L}$ -doped surfaces. Moreover, the order of electron-withdrawing capacity of the various cations in doped structures is:  ${\rm Pd^{4+}} > {\rm Ce^{4+}} > {\rm Zr^{4+}}$ .

## 3.3. CO oxidation

In this work, we also took CO oxidation as the probe reaction to illustrate the catalytic behaviors of the Pd- and Zr-doped CeO<sub>2</sub>. We began with the calculations of CO adsorption on Pd<sub>nL</sub>- and Zr<sub>nL</sub>-doped CeO<sub>2</sub>(111) surfaces. We found that the CO prefers to be adsorbed on the Ce site instead of the Pd, Zr or O sites with adsorption energies of ~0.28 eV (Table 3), close to that on clean surface. <sup>33</sup> As we have illustrated in Fig. 3, CO oxidation reactions on the various doped CeO<sub>2</sub>(111) surfaces were then systematically calculated. In general, we can find that the Pd and Zr dopants in different Ce layers can give rise to quite different performances in the reaction processes.

<span id="page-3-0"></span>Table 3 Calculated adsorption energies (Eads) of CO and energy barriers (Ea) of CO oxidation on CeO2(111) surfaces.

|           | Clean | Pd1L-doped | Pd2L-doped | Pd3L-doped | Zr1L-doped | Zr2L-doped | Zr3L-doped |
|-----------|-------|------------|------------|------------|------------|------------|------------|
| Eads (eV) | 0.36  | 0.28       | 0.25       | 0.28       | 0.26       | 0.26       | 0.26       |
| Ea (eV)   | 0.44  | 0.11       | 0.33       | 0.40       | 0.33       | 0.43       | 0.44       |

<span id="page-3-1"></span>![](_page_3_Figure_4.jpeg)

Fig. 3. Calculated reaction profiles of CO oxidation on the Pd1L- (a), Pd2L- (b), Pd3L- (c), Zr1L- (d), Zr2L- (e), and Zr3L- (f) doped CeO2(111) surfaces. The corresponding structures of key states are also illustrated. Carbon atoms are represented by gray balls, and the oxygen atoms of CO and the surface O involved in the reactions are in pink.

From the calculated reaction profiles, we found that there are two different pathways for the formation of CO2 on these doped CeO2(111) surfaces. The first pathway occurs on the various PdnLdoped CeO2(111) [\(Fig. 3](#page-3-1)(aec)), in which the adsorbed CO molecule in the initial state (IS) approaches a surface lattice O (Olattice) to form a straight CO2 molecule as the final state (FS) directly through a transition state (TS). It needs to be mentioned that, before the desorption of CO2 from the Pd1L-doped CeO2(111) surface, the surface complex would evolve to a new FS (FS') as a result of the structural transformation for the dopant site to evolve to the planar square configuration. By contrast, on the Zr-doped CeO2(111), the CO oxidation follows another pathway. As we have shown in [Fig. 3](#page-3-1)(def), after the IS and TS similar to those in the pathway at PdnL-doped CeO2(111), an intermediate state (IM) can be located, in which a bent CO2 species with the OeCeOlattice angle of ~135 and the CeOlattice distance of ~0.13 nm is formed on the surface. Then

<span id="page-4-0"></span>![](_page_4_Figure_2.jpeg)

Fig. 4. Calculated DOS plots of the FS states during CO oxidation on the Pd1L- (a), Pd2L- (b) and Pd3L- (c) doped CeO2(111) surfaces; IM states during CO oxidation on the Zr1L- (d), Zr2L- (e), and Zr3L- (f) doped CeO2(111) surfaces; FS1 states during CO oxidation on the Zr1L- (g), Zr2L- (h), and Zr3L- (i) doped CeO2(111) surfaces. Dashed lines indicate the Fermi energies.

the bent CO2 species can either continue to form a straight CO2 molecule (FS1) and leave the surface, or further react with another surface Olattice to generate a bidentate carbonate species (FS2). From the calculated energetics we can also see that the carbonate species is actually quite stable and hard to undergo decomposition for CO2 releasing, which then poses a great threat to poison the surface.

On the PdnL-doped CeO2(111) surfaces, the activation energies of CO oxidation were calculated to be 0.11, 0.33, and 0.40 eV (see [Table 3\)](#page-3-0) when the Pd is doped at the first, second and third layers, respectively, which are all lower than the calculated barrier of 0.44 eV at pristine CeO2(111). Therefore, the oxidation of CO at these Pd-doped CeO2(111) surfaces are kinetically more favorable than that at clean CeO2(111) surface, though with the increase of the depth of doping, the activation of CO oxidation on the Pd-doped surfaces declines gradually. On the other hand, the calculated barriers for CO oxidation were 0.43 and 0.44 eV at the Zr2L- and Zr3Ldoped CeO2(111), which are nearly identical to that at clean CeO2(111), while only the process at Zr1L-doped CeO2(111) gives a lower barrier of 0.33 eV (see [Table 3\)](#page-3-0). The results then suggest that only the Zr dopant in the first Ce layer can help the activation of CO and its effect quickly vanishes once goes into deeper layer. In fact, the determined trends of the various CO oxidation at Pd- and Zrdoped CeO2(111) are also largely in line with those of Ov formation discussed in section [3.2.](#page-2-4)

# 3.4. Electronic analyses

It is obvious that the main difference between these two pathways for the formation of CO2 at Pd- and Zr-doped CeO2(111) lies in the occurrence of the surface bent CO2 species. We then carried out electronic analyses in order to better understand such key states within the reaction processes. The calculated density values of states (DOS) are illustrated in [Fig. 4.](#page-4-0)

The adsorbed CO reacts with a Olattice to form a straight CO2 molecule without any intermediate on the Pd-doped CeO2(111), leaving two electrons on the surface inevitably. From the calculated DOS of the FS states [\(Fig. 4](#page-4-0)(aec)) we can see that there are split gap states corresponding to the electrons at 4d orbital of the Pd, which are missing from the DOS of the bare Pd-doped surfaces (Fig. S2). This is also in line with the calculated net Bader charges of the Pd dopants (Table S3) as well as the fact that there is no Ce4<sup>þ</sup> being reduced. Therefore, the two transferred electrons are accommodated by the Pd dopant rather than Ce or the CO2 species in this process, again showing the absolute strong capacity of the Pd dopant in capturing electrons.

For the Zr-doped CeO2(111) surfaces, there are always two separated gap states in the DOS of the IM states [\(Fig. 4](#page-4-0)(def)), corresponding to the localized electron at the 4f orbital of a nearby surface Ce and the p\* electron of the bent CO2 species, respectively. In fact, formation of  $Ce^{3+}$  is also obvious from the calculated spin electron densities (Fig. S3), and the calculated net Bader charge of the  $CO_2$  species is just  $\sim$  -0.8 |e| (Table S4), confirming the existence of  $CO_2^{5-}$ . So that the two electrons left by the leaving  $O_{lattice}$  are accommodated by one Ce atom and the  $CO_2$  species, indicating that they are equally capable of trapping electrons and both better than the Zr dopants. Furthermore, the DOS of FS1 shows the gap states which come from two  $Ce^{3+}$  (Fig. 4(g–i)), while the additional spin-paired gap states in the DOS of FS2 states (Fig. S4) corresponds to the  $\pi^*$  electron of the carbonate species ( $CO_2^{5-}$ ). The attribution of these gap states is also verified by further decomposing the total DOS (partial DOS), consistent with those reported in early studies.  $^{33,34}$ 

From the above results, we can conclude that the decisive factor influencing the pathways with or without the presence of IM, i.e., bent  $CO_2^{\delta}$ , mainly depends on the capacity of electronwithdrawing of the surface species. It is difficult to form bent  $CO_2^{\delta-}$  on  $Pd_{nL}$ -doped  $CeO_2(111)$  because of the strong electronwithdrawing capacity of the Pd dopants, so it tends to form CO<sub>2</sub> directly and desorb from the surfaces. Instead,  $CO_2^{\delta-}$  can exist as the  $Ce^{3+}$  occurs on the  $Zr_{nL}$ -doped  $CeO_2(111)$  which may limit the formation of  $CO_2$  by promoting its further oxidation to  $CO_3^{\delta-}$ . In short, it is the strong capacity of electron-withdrawing of the Pd dopants via the two-electron  $Pd^{4+} \rightarrow Pd^{2+}$  process that makes the Pd-doped ceria exhibit increased selectivity for CO oxidation. Such doped ceria catalysts also showed high activity in other reactions, including the activation of CH<sub>4</sub>, reduction of NO, etc. <sup>13,22,46</sup> We believe that the unique electronic and structural features of Pd doping disclosed in this work may also contribute to the catalytic performances in these processes.<sup>47–49</sup>

#### 4. Conclusions

In this work, DFT+U calculations were performed on a series of doped CeO<sub>2</sub>(111) surfaces with different locations of the Pd and Zr dopants. The formation of oxygen vacancies and the oxidation of CO taking place on these surfaces were investigated for comparison. Although Zr doping can reduce the formation energy of O<sub>v</sub> and the energy barrier of CO oxidation, the promotion effect is limited to the doping in the first surface layer. By contrast, the surface activity can be greatly enhanced at Pd-doped CeO<sub>2</sub>(111) even the Pd dopant is introduced into the third layer. More importantly, Pd doping can also favor the direct production of CO<sub>2</sub> by reducing the chance for the formation of intermediate  $CO_2^{0-}$  which can easily undergo further oxidation to carbonates. The electronic analyses show that this unique feature can be attributed to the strong electronwithdraw capacity of the Pd dopant. Our findings can provide useful insights into the design and preparation of doped ceria catalysts.

### Appendix A. Supplementary data

Supplementary data to this article can be found online at https://doi.org/10.1016/j.jre.2022.05.010.

# References

- <span id="page-5-0"></span> Paier J, Penschke C, Sauer J. Oxygen defects and surface chemistry of ceria: quantum chemical studies compared to experiment. Chem Rev. 2013;113:3949.
- Nolan M, Fearon J, Watson G. Oxygen vacancy formation and migration in ceria. Solid State Ionics. 2006;177:3069.
- <span id="page-5-4"></span>3. Mukherjee D, Rao BG, Reddy BM. CO and soot oxidation activity of doped ceria: influence of dopants. *Appl Catal, B.* 2016;197:105.
- <span id="page-5-1"></span> Wang LL, Diao JY, Peng M, Chen YL, Cai XB, Deng YC, et al. Cooperative sites in fully exposed Pd clusters for low-temperature direct dehydrogenation reaction. ACS Catal. 2021;11(18):11469.

- Danielis M, Betancourt LE, Orozco I, Divins NJ, Llorca J, Rodríguez JA, et al. Methane oxidation activity and nanoscale characterization of Pd/CeO<sub>2</sub> catalysts prepared by dry milling Pd acetate and ceria. Appl Catal, B. 2021:282.
- Riley C, Zhou SL, Kunwar D, De La Riva A, Peterson E, Payne R, et al. Design of
  effective catalysts for selective alkyne hydrogenation by doping of ceria with a
  single-atom promotor. J Am Chem Soc. 2018;140:12964.
- Wang CL, Gu X-K, Yan H, Lin Y, Li JJ, Liu DD, et al. Water-mediated mars-van krevelen mechanism for CO oxidation on ceria-supported single-atom Pt<sub>1</sub> catalyst. ACS Catal. 2016;7:887.
- Tang Y, Wang Y-G, Liang J-X, Li J. Investigation of water adsorption and dissociation on Au<sub>1</sub>/CeO<sub>2</sub> single-atom catalysts using density functional theory. Chin J Catal. 2017;38:1558.
- <span id="page-5-2"></span> Righi G, Magri R, Sellon A. H<sub>2</sub> dissociation on noble metal single atom catalysts adsorbed on and doped into CeO<sub>2</sub>(111). J Phys Chem C. 2019;123:9875.
- Maurer F, Jelic J, Wang JJ, Gänzler A, Dolcet P, Wöll C, et al. Tracking the formation, fate and consequence for catalytic activity of Pt single sites on CeO<sub>2</sub>. Nat Catal. 2020;3:824
- Kim Y, Collinge G, Lee MS, Khivantsev K, Cho SJ, Glezakou V-A, et al. Surface density dependent catalytic activity of single palladium atoms supported on ceria. Angew Chem Int Ed. 2021;60:22769.
- <span id="page-5-3"></span> Khan MAM, Khan W, Khan MN, Alhazaa AN. Enhanced visible light-driven photocatalytic performance of Zr doped CeO<sub>2</sub> nanoparticles. J Mater Sci Mater Electron. 2019:30:8291.
- <span id="page-5-8"></span> Chitpakdee C, Junkaew A, Maitarad P, Shi LY, Promarak V, Kungwan N, et al. Understanding the role of Ru dopant on selective catalytic reduction of NO with NH<sub>3</sub> over Ru-doped CeO<sub>2</sub> catalyst. Chem Eng J. 2019;369:124.
- <span id="page-5-10"></span> Muravev V, Spezzati G, Su Y-Q, Parastaev A, Chiang F-K, Longo A, et al. Interface dynamics of Pd-CeO<sub>2</sub> single-atom catalysts during CO oxidation. Nat Catal. 2021;4:469.
- <span id="page-5-5"></span> Cheng JH, Xu RH, Shi YC. A strategy for improving sinterability and electrical properties of gadolinium-doped ceria electrolyte using calcium oxide additive. *I Rare Earths*, 2021;39:728.
- <span id="page-5-6"></span> Salcedo A, Iglesias I, Mariño F, Irigoyen B. Promoted methane activation on doped ceria via occupation of Pr(4f) states. Appl Surf Sci. 2018;458:397.
- <span id="page-5-7"></span> Zhang ZX, Wang YH, Lu JM, Zhang J, Li MR, Liu XB, et al. Pr-doped CeO<sub>2</sub> catalyst in the Prins condensation-hydrolysis reaction: are all of the defect sites catalytically active? ACS Catal. 2018;8:2635.
- <span id="page-5-9"></span> Liu YN, Yang J, Yang J, Wang L, Wang YS, Zhan WC, et al. Understanding the three-way catalytic reaction on Pd/CeO<sub>2</sub> by tuning the chemical state of Pd. Appl Surf Sci. 2021;556, 149766.
- <span id="page-5-11"></span>19. Hu Q, Huang BY, Li Y, Zhang SM, Zhang YX, Hua XH, et al. Methanol gas detection of electrospun CeO<sub>2</sub> nanofibers by regulating Ce<sup>3+</sup>/Ce<sup>4+</sup> mole ratio via Pd doping. Sensor Actuator B Chem. 2020;307, 127638.
- <span id="page-5-12"></span>Arifin D, Ambrosini A, Wilson SA, Mandal B, Muhich CL, Weimer AW. Investigation of Zr, Gd/Zr, and Pr/Zr-doped ceria for the redox splitting of water. *Int J Hydrogen Energy*. 2020;45:160.
- <span id="page-5-13"></span> Takalkar G, Bhosale RR. Investigation of Zr-doped ceria for solar thermochemical valorization of CO<sub>2</sub>. Int J Energy Res. 2020;44:12284.
- <span id="page-5-14"></span>22. Zhang F, Liu ZY, Chen XB, Rui N, Betancourt LE, Lin LL, et al. Effects of Zr doping into ceria for the dry Reforming of methane over Ni/CeZrO<sub>2</sub> catalysts: *In situ* studies with XRD, XAFS, and AP-XPS. ACS Catal. 2020;10:3274.
- <span id="page-5-15"></span> Su Y-Q, Zhang L, Muravev V, Hensen EJM. Lattice oxygen activation in transition metal doped ceria. Chin J Catal. 2020;41:977.
- <span id="page-5-16"></span> Florea M, Avram D, Maraloiu VA, Cojocaru B, Tiseanu C. Heavy doping of ceria by wet impregnation: a viable alternative to bulk doping approaches. *Nano-scale*, 2018;10:18043.
- <span id="page-5-17"></span> Bao HZ, Qian K, Fang J, Huang WX. Fe-doped CeO<sub>2</sub> solid solutions: substitutingsite doping versus interstitial-site doping, bulk doping versus surface doping. *Appl Surf Sci.* 2017;414:131.
- <span id="page-5-18"></span>26. Liu YY, Fan LD, Cai YX, Zhang W, Wang BY, Zhu B. Superionic conductivity of Sm<sup>3+</sup>, Pr<sup>3+</sup>, and Nd<sup>3+</sup> triple-doped ceria through bulk and surface two-step doping approach. ACS Appl Mater Interfaces. 2017;9:23614.
- <span id="page-5-19"></span>Zhou SL, Gao LY, Wei FF, Lin S, Guo H. On the mechanism of alkyne hydrogenation catalyzed by Ga-doped ceria. J Catal. 2019;375:410.
- <span id="page-5-20"></span> Guerrero-Caballero J, Kane T, Haidar N, Jalowiecki-Duhamel L, Löfberg A. Ni, Co, Fe supported on ceria and Zr doped ceria as oxygen carriers for chemical looping dry reforming of methane. Catal Today. 2019;333:251.
- <span id="page-5-21"></span>29. Su Y-Q, Filot IAW, Liu J-X, Hensen EJM. Stable Pd-doped ceria structures for CH<sub>4</sub> activation and CO oxidation. ACS Catal. 2018;8:75.
- <span id="page-5-22"></span> Zhu LY, Lu YJ, Li F. Reactivity of Ni, Cr and Zr doped ceria in CO<sub>2</sub> splitting for CO production via two-step thermochemical cycle. Int J Hydrogen Energy. 2018;43: 13754
- <span id="page-5-23"></span> Jeong H, Bae J, Han JW, Lee H. Promoting effects of hydrothermal treatment on the activity and durability of Pd/CeO<sub>2</sub> catalysts for CO oxidation. ACS Catal. 2017;7:7097.
- <span id="page-5-24"></span> Stamatakis M, Christiansen MA, Vlachos DG, Mpourmpakis G. Multiscale modeling reveals poisoning mechanisms of MgO-supported Au clusters in CO oxidation. Nano Lett. 2012;12:3621.
- <span id="page-5-25"></span> Chen F, Liu D, Zhang J, Hu P, Gong X-Q, Lu GZ. A DFT+U study of the lattice oxygen reactivity toward direct CO oxidation on the CeO<sub>2</sub>(111) and (110) surfaces. *Phys Chem Chem Phys.* 2012;14:16573.
- <span id="page-5-26"></span>Song Y-L, Yin L-L, Zhang J, Hu P, Gong X-Q, Lu GZ. A DFT+U study of CO oxidation at CeO<sub>2</sub>(110) and (111) surfaces with oxygen vacancies. Surf Sci. 2013;618:140.

- <span id="page-6-0"></span> Wang J, Gong X-Q. A DFT + U study of V, Cr and Mn doped CeO<sub>2</sub>(111). Appl Surf Sci. 2018;428:377.
- <span id="page-6-1"></span> Kresse G, Furthmuller J. Efficiency of ab-initio total energy calculations for metals and semiconductors using a plane-wave basis set. Comput Mater Sci. 1996:6:15.
- <span id="page-6-2"></span>37. Kresse G, Hafner J. *Ab initio* molecular-dynamics simulation of the liquid-metal-amorphous-semiconductor transition in germanium. *Phys Rev B*. 1994;49:14251.
- <span id="page-6-3"></span>**38.** Perdew JP, Chevary JA, Vosko SH, Jackson KA, Pederson MR, Singh DJ, et al. Atoms, molecules, solids, and surfaces: applications of the generalized gradient approximation for exchange and correlation. *Phys Rev B*, 1992;46:6671.
- <span id="page-6-4"></span> Nolan M, Parker SC, Watson GW. The electronic structure of oxygen vacancy defects at the low index surfaces of ceria. Surf Sci. 2005;595:223.
- <span id="page-6-5"></span>**40.** Nolan M, Grigoleit S, Sayle DC, Parker SC, Watson GW. Density dunctional theory studies of the structure and electronic structure of pure and defective low index surfaces of ceria. *Surf Sci.* 2005:576:217.
- <span id="page-6-6"></span>41. Blöchl PE, Forst CJ, Schimpl J. Projector augmented wave method: *Ab initio* molecular dynamics with full wave functions. *Bull Mater Sci.* 2003;26:33.
- <span id="page-6-7"></span>**42.** Kummerle EA, Heger G. The structures of C-Ce<sub>2</sub>O<sub>3+ô</sub>, Ce<sub>7</sub>O<sub>12</sub>, and Ce<sub>11</sub>O<sub>20</sub>. *I Solid State Chem.* 1999;147:485.

- <span id="page-6-8"></span>**43.** Wang H-F, Liu Z-P. Comprehensive mechanism and structure-sensitivity of ethanol oxidation on platinum: new transition-state searching method for resolving the complex reaction network. *J Am Chem Soc.* 2008;130:10996.
- <span id="page-6-9"></span>**44.** Otero GS, Lustemberg PG, Prado F, Ganduglia-Pirovano MV. Relative stability of near-surface oxygen vacancies at the CeO<sub>2</sub>(111) surface upon zirconium doping. *J Phys Chem C*. 2019;124:625.
- <span id="page-6-10"></span>45. Ma XJ, Lu P, Wu P. Effect of structure distortion and oxygen vacancy on ferromagnetism in hydrothermally synthesized CeO<sub>2</sub> with isovalent Zr<sup>4+</sup> doping. Ceram Int. 2018:44:15989.
- <span id="page-6-11"></span> Ma YF, Zhang XH, Cao LN, Lu JL. Effects of the morphology and heteroatom doping of CeO<sub>2</sub> support on the hydrogenation activity of Pt single-atoms. Catal Sci Technol. 2021;11:2844.
- <span id="page-6-12"></span>47. Chen L, Wu X-P, Gong X-Q. Unique catalytic mechanisms of methanol dehydrogenation at Pd-doped ceria: a DFT+U study. J Chem Phys. 2022;156, 134701.
- 48. Su Y-Q. Liu J-X, Filot IAW, Zhang L, Hensen EJM. Highly active and stable CH<sub>4</sub> oxidation by substitution of Ce<sup>4+</sup> by two Pd<sup>2+</sup> ions in CeO<sub>2</sub>(111). ACS Catal. 2018;8:6552
- Nie L, Mei DH, Xiong HF, Peng B, Ren ZB, Hernandez XIP, et al. Activation of surface lattice oxygen in single-atom Pt/CeO<sub>2</sub> for low-temperature CO oxidation. Science. 2017;358:1419.