# **RSC Advances**

![](_page_0_Picture_2.jpeg)

**PAPER** 

View Article Online
View Journal | View Issue

![](_page_0_Picture_5.jpeg)

Cite this: RSC Adv., 2015, 5, 97528

Received 2nd September 2015 Accepted 4th November 2015

DOI: 10.1039/c5ra17825h

www.rsc.org/advances

# Initial reduction of CO<sub>2</sub> on perfect and O-defective CeO<sub>2</sub> (111) surfaces: towards CO or COOH?†

Xiaoqing Lu,\* Weili Wang, Shuxian Wei, Chen Guo, Yang Shao, Mingmin Zhang, Zhigang Deng, Houyu Zhu and Wenyue Guo\*

First-principle calculations were performed to explore the initial reduction of  $CO_2$  on perfect and O-defective  $CeO_2$  (111) surfaces via direct dissociation and hydrogenation, to elucidate the product selectivity towards CO, COOH, or HCOO. The results showed that  $CO_2$  prefers a bent configuration with the C atom of  $CO_2$  occupying the oxygen vacancy site. Reductive hydrogenation  $CO_2 + H \rightarrow COOH^*$  was more competitive than  $CO_2 + H \rightarrow HCOO^*$  on both perfect and O-defective  $CeO_2$  (111) surfaces. Comparatively,  $CO_2$  hydrogenation towards COOH was slightly more favorable on the perfect surface, whereas reductive dissociation of  $CO_2$  was predominant on the O-defective  $CeO_2$  (111) surface. Electronic localization function, charge density difference, and density of states were utilized to analyze the effect of charge accumulation and redistribution on the adsorption and reductive dissociation of  $CO_2$  caused by the presence of O vacancies. The results of this study provided detailed insight into the initial reduction mechanisms of  $CO_2$  towards different products on perfect and O-defective  $CeO_2$  (111) surfaces.

### 1. Introduction

Given that atmospheric CO<sub>2</sub> concentration has been increasing sharply over the last half-century, developing effective techniques to recycle the released CO2 and alleviate greenhouse effects is becoming more urgent than ever. 1-3 Direct catalytic synthesis of valuable chemicals or liquid fuels from CO2 provides one of the most promising approaches, e.g., activation of CO<sub>2</sub> and its hydrogenation to alcohols or other hydrocarbon compounds.4-6 However, highly efficient and selective CO2 conversion remains a challenge because of the inert nature of CO2.4 Therefore, understanding CO2 activation mechanism is a prerequisite in developing the efficient catalytic methods for CO<sub>2</sub> conversion. At present, extensive experimental and theoretical efforts are being initiated to explore adsorption and activation of CO2 on metal and metal oxide surfaces.7-13 The bent CO<sub>2</sub> configuration transformed from the linear CO<sub>2</sub> molecule is generally believed to be able to facilitate the reduction of  $CO_2$ , such as  $CO_2$  dissociation ( $CO_2 \rightarrow CO + O$ ),  $CO_2$  methanation  $(CO_2 + 4H_2 \rightarrow CH_4 + 2H_2O)$ , <sup>14</sup> and methanol synthesis (CO<sub>2</sub> + 3H<sub>2</sub>  $\rightarrow$  CH<sub>3</sub>OH + H<sub>2</sub>O). <sup>15-17</sup> In particular, based on the initial activation of CO2, three reaction mechanisms have been proposed, which involve the C-O bond breaking and C-H bond formation, as given by the following,

College of Science, China University of Petroleum, Qingdao, Shandong 266580, People's Republic of China. E-mail: luxq@upc.edu.cn; wyguo@upc.edu.cn; Fax: +86-532-86983363; Tel: +86-532-86983372

 $\dagger$  Electronic supplementary information (ESI) available: The spin polarized effect are presented. See DOI: 10.1039/c5ra17825h

$$CO_2 \rightarrow CO + O$$
 (1)

$$CO_2 + H \rightarrow COOH$$
 (2)

$$CO_2 + H \rightarrow HCOO$$
 (3)

Ceria (CeO<sub>2</sub>), a widely used rare earth oxide, is currently attracting extensive interest as an excellent catalyst for CO2 hydrogenation.18-20 The structure and property of the bulk and perfect/defective CeO2 surfaces have been explored on the basis of experimental kinetics and first-principle investigations. 21-24 Jin et al.25 observed CO2 adsorption on CeO2 with bent carbonate configuration by using IR and X-ray photoelectron spectroscopy. By investigating CO2 splitting on nonstoichiometric CeO2 via thermochemical redox reactions, Furler and co-workers26 reported that defective CeO2 was reoxidized by CO2 to generate CO at below 1000 °C. In methanol steam reforming reaction, Ferrizz et al.27 demonstrated that CO was produced only if O vacancies were present on CeO<sub>2</sub> (111) surface. For CO<sub>2</sub> hydrogenation, Sharma et al. 19 reported high CH<sub>4</sub> selectivity without CO impurity from CO<sub>2</sub> methanation reaction on a Ru-doped ceria catalyst, whereas CO is the only production on Pd-doped ceria catalyst. Jesús et al.20 observed that a copper-ceria interface was highly efficient for the synthesis of methanol. These results indicated that reduction of CO<sub>2</sub> would yield different products when occurring on different catalysts under certain conditions. In theory, most studies have focused on the physical properties of bulk CeO2 and CO2 adsorption processes on CeO2 because of the complicated electronic structure.24,28-30 For instance, three stable adsorption

Paper **RSC Advances** 

configurations of CO<sub>2</sub> on perfect CeO<sub>2</sub> (111) were observed by Konstanze et al., 31 whereas on O-defective CeO2 (111), two stable adsorption configurations of CO2 were observed by Reimers et al.32 However, details of CO2 reduction on perfect and Odefective CeO2 (111) surfaces, including stable adsorption configuration, electronic structural property, activation process, reaction thermodynamics and kinetics, and selectivity of production, etc., are not well elucidated yet.

In this study, we performed a periodic density functional corrected by on-site Coulomb interaction (DFT + U) investigation on CO2 reduction over CeO2 surface. Among the polymorphs of CeO2, CeO2 (111) surface was selected because of its excellent stability and catalytic property.33 Initial activation of CO<sub>2</sub> was proposed to be the rate limiting step due to its high thermodynamic stability,34 therefore, this study focused mainly on the initial reduction reaction mechanism of CO2 towards COOH, HCOO or CO. First, formation of O vacancy and the relevant structures and energies were described. Then, CO2 adsorption, reductive dissociation and hydrogenation on perfect and O-defective surfaces were comparatively analyzed to elucidate the initial reduction mechanisms of CO2.

#### 2. Computational methods

All calculations were performed by the DFT +  $U^{35-38}$  implemented in the Vienna Ab initio Simulation Package (VASP).39,40 The projector augmented wave method (PAW) was applied to interaction.41,42 core-valence  $5s^25p^66s^24f^15d^1$ ,  $O-2s^22p^4$ ,  $C-2s^22p^2$ , and H-1s states were considered explicitly as valence states within the PAW approach. The exchange correlation energy was evaluated using the Generalized Gradient Approximation (GGA) with the Perdew-Burke-Ernzerhof (PBE) functional. 43 A plane wave basis set with a cutoff energy of 400 eV and the Brillouin zone sampled with a  $(2 \times 2 \times 1)$  Monkhorst-Pack mesh k-points grid were set for the converged results. Due to the on-site Coulomb and exchange interactions of the strongly localized Ce 4f electrons for the reduced ceria, we used 5 eV value for U on the basis of the theoretical tests in the literature.44-46 This guaranteed that the redox chemistry was reproduced correctly. 47,48 Besides, the spin polarized effect was evaluated and no obvious influence was observed (see Table S1 in ESI†). By minimizing the forces on all unconstrained atoms within 0.02 eV  $\mathring{A}^{-1}$ , we obtained the bulk lattice parameter of 5.42 Å, in good agreement with the experimental value of 5.41 Å (ref. 49) and previously theoretical results of 5.38 Å (ref. 50) and 5.46 Å (ref. 51). Bader charge analyses were performed for the perfect and O-defective CeO2 (111) surfaces with CO<sub>2</sub> adsorption. Transition state (TS) searches were performed with the climbing image Nudge Elastic Band (CI-NBE) method,<sup>52</sup> implemented in VASP. A total of three images between the initial state (IS) and final state (FS) were used to locate the TSs. The TSs were further confirmed through frequency analysis, which only one imaginary frequency was identified for each TSs. The reaction energies and the energy barriers along the reaction pathways were calculated as the total energy differences between the TS and IS, and between the TS and IS, respectively.

The perfect  $CeO_2$  (111) surface was modeled via a p(2 × 2) supercell with a thickness of 9 atomic layers (12 Ce atoms and 24 O atoms overall). A dimension of 7.72  $\text{Å} \times$  7.72  $\text{Å} \times$  13.00 Åand the vacuum gap of 15 Å were established according to values previously used in the literature. 44,45,53 The bottom three atomic layers were frozen at their equilibrium bulk positions, whereas all the other atoms were unconstrained. The adsorption energy of adsorbate was estimated by the following equation:

$$E_{\rm ads} = E_{\rm M/S} - E_{\rm S} - E_{\rm M} \tag{4}$$

where  $E_{M/S}$  represented the total energy of a surface slab with the adsorbate,  $E_S$  was the energy of a perfect or O-defective CeO<sub>2</sub> (111) surface, and  $E_{\rm M}$  represented the energy of an adsorbate molecule. The dissociation and absorption energies for each species were calculated as the difference between the energy of the optimized structures of the initial and final states of the reactions. In this definition, the negative value indicated a stable adsorption and the process was exothermic, whereas positive value was endothermic.

#### 3. Results and discussion

#### 3.1 Perfect and O-defective CeO<sub>2</sub> (111) surfaces

Fig. 1a and b illustrate a perfect CeO<sub>2</sub> (111) surface. The optimized Ce-O bond length is 2.37 Å. The top layer contains unsaturated 3-fold coordinated O atoms (O<sub>3C</sub>) and unsaturated 7-fold coordinated Ce atoms (Ce<sub>7C</sub>), which originated from the 4-fold coordinated O atoms and the 8-fold coordinated Ce atoms in the bulk phase of CeO2. These unsaturated O and Ce atoms on the perfect CeO2 (111) provide active sites for adsorption and activation reaction of CO2. The surface energy of the perfect CeO<sub>2</sub> (111) is calculated to be 0.62 J m<sup>-2</sup>, which is consistent with previous DFT values that range from 0.61 J m<sup>-2</sup> to 0.68 J  $\mathrm{m}^{-2}$ .  $^{21,44,54}$ 

![](_page_1_Figure_14.jpeg)

Fig. 1 Structures of perfect CeO<sub>2</sub> (111) surface, (a) side view and (b) top view, (c) top view of O-defective CeO2 (111) surface; electronic localization function contours of perfect (d) and O-defective (e) CeO<sub>2</sub> (111) surfaces

Fig. 1c shows the O-defective CeO<sub>2</sub> (111) surface, which is formed via one surface O atom escaping from the perfect CeO<sub>2</sub> (111). The O vacancy formation energy is calculated to be 2.78 eV, comparable to recent DFT values of 2.65 eV (ref. 55) and 2.87 eV.56 Electronic properties of perfect and O-defective CeO<sub>2</sub> (111) surfaces are characterized by using the electronic localization function (ELF) contour maps, as shown in Fig. 1d and e. ELF maps clearly show that the ELF value is close to zero at the O<sub>v</sub> site on the O-defective CeO2 (111) surface, and the contour maps of three adjacent O and Ce<sub>1-3</sub> atoms exhibit significant deformation.

#### 3.2 CO<sub>2</sub> adsorption

Adsorption configurations of CO2 on perfect and O-defective CeO<sub>2</sub> (111) surfaces are shown in Fig. 2. For clarity, P and D are used to represent CO2 adsorption on perfect and O-defective CeO<sub>2</sub> (111) surfaces. In each adsorption configuration, the two O atoms of the adsorbed CO<sub>2</sub> are labeled as O<sub>a</sub> and O<sub>b</sub>, respectively. Structural parameters, variations of the total Bader charge, and adsorption energies of CO2 are summarized in Table 1. Net Bader charges of CO2 are all negative on both perfect and O-defective CeO<sub>2</sub> (111) surfaces; this finding indicates that electrons are transferred from the surface to the adsorbed CO2, which acts as a Lewis acid. The net Bader charges of the adsorbed CO<sub>2</sub> on O-defective surface are obviously larger than those on the perfect surface, which can be attributed to the enhanced electron-donating ability due to the O vacancy on the surface.

On the perfect CeO<sub>2</sub> (111) surface, three stable adsorption configurations, namely P-1, P-2, and P-3, are observed, as shown in Fig. 2. In P-1 configuration, the adsorbed CO2 is spontaneously bent, forming a monodentate carbonate species. The C atom is associated to the surface O<sub>3</sub> atom, O<sub>a</sub> to the Ce<sub>1</sub>, and O<sub>b</sub> to the Ce<sub>2</sub> atom with bond lengths of 1.37 Å, 2.54 Å, and 2.54 Å, respectively. The C-O<sub>a</sub> and C-O<sub>b</sub> bonds are elongated symmetrically to 1.27 Å, and the O<sub>a</sub>-C-O<sub>b</sub> angle is bent to 129°, relative to that of 1.18 Å and 180° in a gas-phase CO2 molecule. The corresponding adsorption energy of CO2 in P-1 configuration is calculated to be -0.54 eV. In P-2

Table 1 Structural parameters, charges, and adsorption energies of CO<sub>2</sub> on perfect and O-defective CeO<sub>2</sub> (111) surfaces

| Configurations  | $_{(\mathring{A})}^{C-O_{a}}$ | $^{\text{C-O}_{\text{b}}}_{(\mathring{A})}$ | $\angle O_a$ -C- $O_b$ (deg) | E <sub>ads</sub> (eV) | Charge $( e )$ |
|-----------------|-------------------------------|---------------------------------------------|------------------------------|-----------------------|----------------|
| CO <sub>2</sub> | 1.18                          | 1.18                                        | 180                          |                       |                |
| P-1             | 1.27                          | 1.27                                        | 129                          | -0.54                 | -0.350         |
| P-2             | 1.22                          | 1.30                                        | 130                          | -0.38                 | -0.300         |
| P-3             | 1.18                          | 1.17                                        | 180                          | -0.12                 | -0.003         |
| D-1             | 1.21                          | 1.43                                        | 122                          | -0.69                 | -0.830         |
| D-2             | 1.28                          | 1.25                                        | 128                          | -0.88                 | -0.400         |
| D-3             | 1.27                          | 1.27                                        | 129                          | -1.12                 | -0.670         |
|                 |                               |                                             |                              |                       |                |

configuration, the adsorbed CO2 is observed in the form of bidentate carbonate with an adsorption energy of -0.38 eV. The distances of the C-O<sub>3</sub> and O<sub>b</sub>-Ce<sub>3</sub> bonds are 1.43 Å and 2.35 Å, respectively. The C-O<sub>a</sub> and C-O<sub>b</sub> bonds are stretched to 1.22 Å and 1.30 Å with the  $O_a$ -C- $O_b$  angle of 130°. In P-3 configuration, the distance of the linear molecular CO2 from the surface is calculated to be 3.14 Å with an adsorption energy of -0.12 eV, indicating relatively weak interaction between CO<sub>2</sub> and the surface. Our results prove that the bent monodentate configuration is the most favorable mode for CO2 molecule adsorption on the perfect CeO2 (111) surface, according well with the previous reports.31

On the O-defective CeO<sub>2</sub> (111) surface, three stable adsorption configurations, namely D-1, D-2, and D-3, are observed, as shown in Fig. 2. In D-1 configuration, CO2 is observed at the O vacancy site by one of its O atoms, and the adsorption energy is calculated to be -0.69 eV. The  $O_b$  atom is associated to the  $Ce_1$ , Ce2, Ce3 atoms and the C atom is associated to the Ce1 atom. Bond lengths of O<sub>b</sub>-Ce<sub>1</sub>, O<sub>b</sub>-Ce<sub>2</sub>, O<sub>b</sub>-Ce<sub>3</sub>, and C-Ce<sub>1</sub> are 2.64 Å, 2.52 Å, 2.53 Å and 2.54 Å, respectively. The C-O<sub>a</sub> and C-O<sub>b</sub> bonds are stretched to 1.21 Å and 1.43 Å, and the O<sub>a</sub>-C-O<sub>b</sub> angle is 122° in D-1 configuration. Recent DFT studies have confirmed that CO2 tends to locate at the O vacancy site on the Znterminated ZnO (0001) surface by inserting one of the O atoms of CO2 into the vacancy, thereby forming a bent CO2 species.  $^{57,58}$  In D-2 configuration, the adsorbed  $\mathrm{CO}_2$  is associated

![](_page_2_Figure_13.jpeg)

Fig. 2 Optimized adsorption configurations of CO<sub>2</sub> on perfect and O-defective CeO<sub>2</sub> (111) surfaces. P-series and D-series denote the CO<sub>2</sub> adsorption on the perfect and O-defective CeO<sub>2</sub> (111) surfaces.

Paper

To deep understand the electronic nature of interaction between the CO<sub>2</sub> and CeO<sub>2</sub> surface, 2-dimension and 3-dimension charge density difference analyses are performed. As shown in Fig. 3a, excess electrons transfer from the O vacancy to the adjacent Ce atoms on the O-defective CeO<sub>2</sub> (111) surface. For the CO<sub>2</sub> adsorption on the perfect CeO<sub>2</sub> (111) surface in P-1 configuration, as shown in Fig. 3b, the charge density difference undergoes obvious redistribution, especially for the electron alteration in the middle region between C and the associated surface O atom. A similar case occurs for the CO2 adsorption in D-3 configuration on the O-defective CeO<sub>2</sub> (111) surface (Fig. 3c). However, more surface electron accumulation appears at the O vacancy site due to electron contribution from the adjacent Ce atoms. Hence, the presence of O vacancy can substantially promote charge accumulation and redistribution. Correspondingly, the CO<sub>2</sub> adsorption energy significantly increases from -0.54 eV on the perfect  $CeO_2$  (111) surface to -1.12 eV on the O-defective CeO<sub>2</sub> (111) surface.

Fig. 4 shows the results of the density of states (DOS) analyses of perfect and O-defective CeO<sub>2</sub> (111) surfaces, and the most stable CO<sub>2</sub> adsorption configurations. Fig. 4a presents the

![](_page_3_Figure_7.jpeg)

Fig. 3 (a) Charge density difference for the O-defective CeO<sub>2</sub> (111) surface, (b) CO<sub>2</sub> adsorption on the perfect CeO<sub>2</sub> (111) in P-1 configuration, and (c) CO<sub>2</sub> on the O-defective CeO<sub>2</sub> (111) in the D-3 structure; yellow and blue isosurfaces represent increasing and decreasing electron densities, respectively.

local DOS (LDOS) of the O atoms on the first layer and the Ce atoms on the second layer of the perfect CeO<sub>2</sub> (111) surface, in which the total DOS is mainly composed of Ce 4f orbitals with hybridized O 2p orbitals. Fig. 4b shows the LDOS of the O atoms on the first layer and Ce atoms on the second layer of the O-defective CeO<sub>2</sub> (111). A comparison between Fig. 4a and b indicates that the greatest differences lie in the decreased energy gap between the occupied O 2p and unoccupied Ce 4f states and an emerging gap state peak nearby the Fermi level, which represents excess electrons localized on surface Ce atoms. The differences make the O-defective surface more active compared with the perfect surface, which is consistent with the present results of charge density difference analyses and previous studies.21,55,59 Fig. 4c and d show the LDOS of CO2 adsorption on perfect and O-defective CeO<sub>2</sub> (111) surfaces, to evaluate the orbital hybridization and binding situation. In P-1 configuration, the surface Ce 4f orbital and O 2p orbital hybridize with CO<sub>2</sub> 2p orbital, thereby forming a bonding state nearby -1.0 eV. Because the hybridization occurs mainly at the unoccupied states, the bonding is rather weak with an adsorption energy of -0.54 eV. In D-3 configuration, the emerging peak composed of the hybridization of Ce 4f with CO<sub>2</sub> 2p orbitals is observed nearby the Fermi level together with the similar hybridization nearby -2.0 eV as that on the perfect CeO<sub>2</sub> (111) surface, which explains the larger CO<sub>2</sub> adsorption energy of -1.12 eV.

In summary, CO<sub>2</sub> adsorption on the O-defective CeO<sub>2</sub> (111) surface is more energetically stable compared with that on the perfect surface. The presence of O vacancy can substantially promote charge accumulation and redistribution, and thus strengthen the adsorption of CO2. This agrees well with previous observations that the presence of defects can promote CO<sub>2</sub> adsorption and activation on metal oxide surfaces.<sup>57,58</sup>

![](_page_3_Figure_11.jpeg)

Fig. 4 (a) LDOS of the O atoms on the first layer and Ce atoms on the second layer of perfect CeO<sub>2</sub> (111) surface, (b) LDOS of the O atoms on the first layer and Ce atoms on the second layer of O-defective CeO<sub>2</sub> (111) surface, (c) LDOS of the adsorbed CO2 and the first two layers of the O and Ce atoms in P-1 configuration, and (d) LDOS of the adsorbed CO<sub>2</sub> and the first two layers of O and Ce atoms in D-3 configuration.

#### 3.3 Reductive dissociation of CO<sub>2</sub>

**RSC Advances** 

As shown in Fig. 5, reductive dissociation of  $CO_2$  on the perfect  $CeO_2$  (111) surface can start with the monodentate carbonate configuration P-1 and the bidentate carbonate configuration P-2, and decompose into CO at the  $Ce_{7c}$  site and O at the  $O_{3c}$ – $Ce_{7c}$  site. Starting with the most stable P-1 configuration, the  $C-O_a$  bond is reduced to 0.97 Å, while the  $C-O_b$  bond of the adsorbed  $CO_2$  is elongated to 1.92 Å in TS1. This dissociation process is endothermic by 3.62 eV with a high energy barrier of 4.08 eV. Starting with P-2 configuration, the relevant  $C-O_b$  bond is elongated to 1.98 Å in TS2 from the initial 1.30 Å. This step is endothermic by 3.23 eV with a high energy barrier of 3.70 eV. The above results indicate the thermodynamic stability of inert  $CO_2$  on the perfect  $CeO_2$  (111) surface, in good agreement with the previous studies.

On the O-defective CeO<sub>2</sub> (111) surface, the O atom from CO<sub>2</sub> dissociation can "heal" the O vacancy to a perfect CeO<sub>2</sub> surface, as shown in Fig. 6. Reductive dissociation of CO2 on the Odefective CeO<sub>2</sub> (111) surface is observed to start with the D-1 and D-3 configurations. Starting with D-1 configuration, the C-O<sub>b</sub> bond of the adsorbed CO<sub>2</sub> is elongated to 2.83 Å at the FS with the adsorbed CO at the Ce<sub>1</sub> site and the O<sub>b</sub> atom at the O vacancy. The calculated adsorption energy of CO on the perfect CeO<sub>2</sub> (111) surface is -0.19 eV, which is consistent with the reported result of -0.18 eV.61 This dissociation process is exothermic by 0.52 eV without any activation barrier, according well with the recent studies that CO2 readily dissociated on the reduced ceria surface to generate CO.26,62,63 Starting with D-3 configuration, the C-Oa bond is reduced to 0.91 Å, while the C-O<sub>b</sub> distance is elongated to 1.66 Å in TS3, and the formed CO stays at the Ce<sub>1</sub> site with a C-Ce<sub>1</sub> bond of 2.56 Å. This step is slightly exothermic by 0.09 eV, and the energy barrier amounts to 0.27 eV. This indicates that the reductive dissociation of CO<sub>2</sub> starting with D-3 configuration is also favorable. A comparison between the reductive dissociation of CO<sub>2</sub> on the perfect surface

![](_page_4_Figure_6.jpeg)

Fig. 5 Potential energy profile for reductive dissociation of  $CO_2$  on the perfect  $CeO_2$  (111) surface.

![](_page_4_Figure_8.jpeg)

Fig. 6 Potential energy profile for reductive dissociation of  $CO_2$  on the O-defective  $CeO_2$  (111) surface.

and that on the O-defective  $CeO_2$  (111) surface indicates that the adsorbed  $CO_2$  on the O-defective  $CeO_2$  (111) surface is highly activated and easily dissociated to CO.

#### 3.4 Reductive hydrogenation of CO<sub>2</sub>

On the perfect CeO<sub>2</sub> (111) surface, two stable co-adsorption configurations of CH-1 and CH-2 are observed, as shown in Fig. 7. In CH-1 configuration, the H atom is adsorbed on the O<sub>1</sub> top site with the H-O<sub>1</sub> bond length of 0.98 Å. The co-adsorption energy is calculated to be -0.78 eV. Starting with CH-1 configuration, the hydrocarboxyl (COOH\*) species would be formed when the H atom approaching to the Ob atom of the adsorbed CO<sub>2</sub>, as shown in Fig. 7. This process is slightly endothermic by 0.23 eV with a low energy barrier of 0.36 eV. In TS4, the adatom H migrates from O<sub>1</sub> to O<sub>b</sub>, and the H-O<sub>b</sub> distance is reduced to 1.14 Å from the initial 2.12 Å together with the stretched H-O<sub>1</sub> distance of 2.93 Å. The COOH\* species is observed at the O<sub>3</sub> site through the C atom; the C-O<sub>3</sub> bond length is 1.32 Å, and the H-O<sub>b</sub> bond length is shortened to 0.99 Å. In CH-2 configuration, the H atom is observed at the O<sub>4</sub> top site, and the distance of the C atom and H atom is 3.97 Å. In TS5, the H atom approaches to the C atom with a distance of 1.34 Å, while the H-O<sub>4</sub> bond is elongated to 3.79 Å from the initial value of 0.98 Å. The formate (HCOO\*) species is generated in the FS with the O<sub>b</sub>-Ce<sub>3</sub> bond length elongated to 2.58 Å. This step is endothermic by 2.43 eV with a high activation barrier of 2.72 eV. Therefore,  $CO_2 + H \rightarrow$ COOH\* via CH-1 configuration is more competitive than CO<sub>2</sub> + H → HCOO\* via CH-2 configuration for reductive hydrogenation of  $CO_2$  on the perfect  $CeO_2$  (111) surface.

Reductive hydrogenation of  $CO_2$  is also performed on the O-defective  $CeO_2$  (111) surface. As shown in Fig. 8, CW-1 and CW-2 represent two stable co-adsorption configurations of adatom H and  $CO_2$ . In CW-1 configuration, the distance between the  $O_b$  atom and adatom H is 2.74 Å. Starting with CW-1 configuration, reductive hydrogenation of  $CO_2$  terminates with COOH\* species

Paper RSC Advances

![](_page_5_Figure_3.jpeg)

Fig. 7 Potential energy profile for reductive hydrogenation of  $CO_2$  on the perfect  $CeO_2$  (111) surface.

adsorbed on the O vacancy site. In TS6, the O–H distance is shortened to 1.76 Å. The C–Ce<sub>3</sub>,  $O_a$ –Ce<sub>1</sub>, and  $O_a$ –Ce<sub>2</sub> bond lengths are calculated to be 2.67 Å, 2.64 Å, and 2.64 Å in the

![](_page_5_Figure_6.jpeg)

Fig. 8 Potential energy profile for reductive hydrogenation of  $CO_2$  on the O-defective  $CeO_2$  (111) surface.

adsorbed COOH\* species, respectively. This step is endothermic by 0.53 eV, and the energy barrier is 0.68 eV, which is slightly higher than that of CO2 hydrogenation to COOH\* on the perfect CeO<sub>2</sub> (111) surface. In CW-2 configuration, CO<sub>2</sub> is adsorbed at the O vacancy site in a bidentate configuration and adatom H is observed at the O<sub>1</sub> site with the H-O<sub>1</sub> bond length of 0.98 Å. The distance between adatom H and C atom is 2.83 Å. Starting with CW-2 configuration, CO<sub>2</sub> hydrogenation can yield HCOO\* on the O vacancy site via TS7, in which the H-O<sub>1</sub> bond is elongated to 1.78 Å, while the H-C distance is reduced to 2.25 Å. In the FS, the HCOO\* species is observed at the O vacancy site, and the Oa-Ce3, Ob-Ce1, and Ob-Ce2 bond lengths are calculated to be 2.58 Å, 2.63 Å, and 2.63 Å, respectively. This process is exothermic by 1.27 eV but has a high energy barrier of 1.76 eV. From the kinetic viewpoint, CO<sub>2</sub> hydrogenation to COOH\* is more favorable than CO2 hydrogenation to HCOO\* on the Odefective CeO2 (111) surface.

#### 4. Conclusions

Initial reduction of CO<sub>2</sub> on perfect and O-defective CeO<sub>2</sub> (111) surfaces *via* direct dissociation and hydrogenation were investigated by using first-principle calculations to elucidate the product selectivity towards CO, COOH, or HCOO. The following are the findings of this study:

- (1) Activated  $CO_2$  forms carbonate species on the perfect surface with the participation of a surface O atom, whereas  $CO_2$  adsorption on the O-defective  $CeO_2$  (111) surface is energetically favorable, particularly for the configuration with the C atom occupying the O vacancy site.
- (2) Reductive hydrogenation  $CO_2 + H \rightarrow COOH^*$  is more competitive than  $CO_2 + H \rightarrow HCOO^*$  on both the perfect and Odefective  $CeO_2$  (111) surfaces. Comparatively,  $CO_2$  hydrogenation towards COOH is slightly more favorable on the perfect surface, whereas reductive dissociation of  $CO_2$  is predominant on the O-defective  $CeO_2$  (111) surface.
- (3) Electronic structure analyses confirm that the O vacancy leads to deformation of neighboring electrons, facilitates the charge accumulation to strengthen the  $CO_2$  adsorption, and therefore promotes direct reductive dissociation of  $CO_2$  on the O-defective  $CeO_2$  (111) surface.

Overall, this theoretical work elucidates that the surface H atom presenting on perfect and O-defective  $CeO_2$  (111) surfaces plays an active role in promoting  $CO_2$  reduction to form COOH, and the O-vacancy on  $CeO_2$  (111) surface assists the reductive dissociation of  $CO_2$  to CO. Therefore, the pretreatment of  $CeO_2$  (111) surface by H and/or O-vacancy would significantly improve the initial reduction of  $CO_2$  for subsequent reactions to  $CH_4$  and  $CH_3OH$ .

## Acknowledgements

This work was supported by NSFC (21303266), National Basic Research Program of China (2014CB239204), Promotive Research Fund for Excellent Young and Middle-aged Scientists of Shandong Province (BS2013CL031), and the Fundamental

Research Funds for the Central Universities (15CX05050A, 15CX08010A, 14CX02214A).

## Notes and references

- 1 C. S. Song, Catal. Today, 2006, 115, 2-32.
- 2 X. Q. Lu, D. L. Jin, S. X. Wei, Z. J. Wang, C. H. An and W. Y. Guo, *J. Mater. Chem. A*, 2015, 3, 12118–12132.
- 3 E. A. Quadrelli, G. Centi, J. L. Duplan and S. Perathoner, *ChemSusChem*, 2011, 4, 1194–1215.
- 4 M. Aresta, *Carbon dioxide as chemical feedstock*, John Wiley & Sons, 2010.
- 5 M. B. Ansari, B. H. Min, Y. H. Mo and S. E. Park, *Green Chem.*, 2011, 13, 1416–1421.
- 6 A. B. Vidal, L. Feria, J. Evans, Y. Takahashi, P. Liu, K. Nakamura, F. Illas and J. A. Rodriguez, *J. Phys. Chem. Lett.*, 2012, 3, 2275–2280.
- 7 C. Zinola, C. Gomis-Bas, G. Estiú, E. Castro and A. Arvia, *Langmuir*, 1998, 14, 3901–3908.
- 8 G. C. Wang, L. Jiang, Y. Morikawa, J. Nakamura, Z. S. Cai, Y. M. Pan and X. Z. Zhao, *Surf. Sci.*, 2004, **570**, 205–217.
- 9 S. G. Wang, X. Y. Liao, D. B. Cao, C. F. Huo, Y. W. Li, J. Wang and H. Jiao, *J. Phys. Chem. C*, 2007, 111, 16934–16940.
- 10 Y. Kohno, T. Tanaka, T. Funabiki and S. Yoshida, *Phys. Chem. Chem. Phys.*, 2000, **2**, 2635–2639.
- 11 K. Teramura, T. Tanaka, H. Ishikawa, Y. Kohno and T. Funabiki, *J. Phys. Chem. B*, 2003, **108**, 346–354.
- 12 Y. X. Pan, C. J. Liu, D. Mei and Q. Ge, *Langmuir*, 2010, 26, 5551–5558.
- 13 J. Y. Ye, C. J. Liu and Q. F. Ge, *J. Phys. Chem. C*, 2012, **116**, 7817–7825.
- 14 W. Wei and J. L. Gong, Front. Chem. Sci. Eng., 2011, 5, 2-10.
- 15 S. Fujita, M. Usui, H. Ito and N. Takezawa, *J. Catal.*, 1995, 157, 403–413.
- 16 Q. Zhang, Y. Z. Zuo, M. H. Han, J. F. Wang, Y. Jin and F. Wei, *Catal. Today*, 2010, **150**, 55–60.
- 17 F. Meshkini, M. Taghizadeh and M. Bahmani, *Fuel*, 2010, **89**, 170–175.
- 18 Y. Yoshida, Y. Arai, S. Kado, K. Kunimori and K. Tomishige, *Catal. Today*, 2006, **115**, 95–101.
- 19 S. Sharma, Z. P. Hu, P. Zhang, E. W. McFarland and H. Metiu, *J. Catal.*, 2011, **278**, 297–309.
- 20 J. Graciani, K. Mudiyanselage, F. Xu, A. E. Baber, J. Evans, S. D. Senanayake, D. J. Stacchiola, P. Liu, J. Hrbek and J. F. Sanz, *Science*, 2014, 345, 546–550.
- 21 Z. X. Yang, T. K. Woo, M. Baudin and K. Hermansson, *J. Chem. Phys.*, 2004, **120**, 7741–7749.
- 22 S. Fabris, S. de Gironcoli, S. Baroni, G. Vicario and G. Balducci, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 2005, 71, 041102.
- 23 M. Nolan, V. S. Verdugo and H. Metiu, *Surf. Sci.*, 2008, **602**, 2734–2742.
- 24 M. Burbano, D. Marrocchelli, B. Yildiz, H. L. Tuller, S. T. Norberg, S. Hull, P. A. Madden and G. W. Watson, *J. Phys.: Condens. Matter*, 2011, 23, 255402.
- 25 T. Jin, Y. Zhou, G. J. Mains and J. M. White, *J. Phys. Chem.*, 1987, **91**, 5931–5937.

- 26 P. Furler, J. Scheffe, M. Gorbar, L. Moes, U. Vogt and A. Steinfeld, *Energy Fuels*, 2012, **26**, 7051–7059.
- 27 R. M. Ferrizz, G. S. Wong, T. Egami and J. M. Vohs, *Langmuir*, 2001, 17, 2464–2470.
- 28 F. Marabelli and P. Wachter, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 1987, **36**, 1238.
- 29 J. F. Jerratsch, X. Shao, N. Nilius, H. J. Freund, C. Popa, M. V. Ganduglia-Pirovano, A. M. Burow and J. Sauer, *Phys. Rev. Lett.*, 2011, **106**, 246801.
- 30 S. Dudarev, G. Botton, S. Savrasov, C. Humphreys and A. Sutton, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 1998, 57, 1505.
- 31 K. R. Hahn, M. Iannuzzi, A. P. Seitsonen and J. Hutter, *J. Phys. Chem. C*, 2013, **117**, 1701–1711.
- 32 W. G. Reimers, M. A. Baltanás and M. M. Branda, *J. Mol. Model.*, 2014, **20**, 1–10.
- 33 N. V. Skorodumova, M. Baudin and K. Hermansson, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 2004, **69**, 075401.
- 34 G. Centi and S. Perathoner, *Catal. Today*, 2009, **148**, 191–205.
- 35 P. Hohenberg and W. Kohn, *Phys. Rev.*, 1964, **136**, B864–B871.
- 36 W. Kohn and L. J. Sham, Phys. Rev., 1965, 140, A1133-A1138.
- 37 S. R. Li, X. Q. Lu, W. Y. Guo, H. Y. Zhu, M. Li, L. M. Zhao, Y. Li and H. H. Shan, *J. Organomet. Chem.*, 2012, **704**, 38–48.
- 38 X. Q. Lu, Z. G. Deng, S. X. Wei, Q. Zhu, W. W. Wang, W. Y. Guo and C. M. L. Wu, *Catal. Sci. Technol.*, 2015, 5, 3246–3258.
- 39 G. Kresse and J. Hafner, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 1994, **49**, 14251–14269.
- 40 G. Kresse and J. Furthmüller, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 1996, **54**, 11169–11186.
- 41 P. E. Blöchl, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 1994, **50**, 17953–17979.
- 42 G. Kresse and D. Joubert, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 1999, **59**, 1758–1775.
- 43 J. P. Perdew, K. Burke and M. Ernzerhof, *Phys. Rev. Lett.*, 1996, 77, 3865–3868.
- 44 M. Nolan, S. Grigoleit, D. C. Sayle, S. C. Parker and G. W. Watson, *Surf. Sci.*, 2005, 576, 217–229.
- 45 M. Nolan, S. C. Parker and G. W. Watson, *Surf. Sci.*, 2005, 595, 223–232.
- 46 M. Nolan, S. C. Parker and G. W. Watson, *Phys. Chem. Chem. Phys.*, 2006, **8**, 216–218.
- 47 Z. Yang, G. Luo, Z. Lu and K. Hermansson, *J. Chem. Phys.*, 2007, **127**, 074704.
- 48 B. Liu, J. Liu, T. Li, Z. Zhao, X. Q. Gong, Y. Chen, A. J. Duan, G. Y. Jiang and Y. C. Wei, *J. Phys. Chem. C*, 2015, **119**, 12923–12934.
- 49 H. J. Whitfield, D. Roman and A. R. Palmer, *J. Inorg. Nucl. Chem.*, 1966, **28**, 2817–2825.
- 50 Y. Jiang, J. B. Adams and M. van Schilfgaarde, *J. Chem. Phys.*, 2005, **123**, 064701.
- 51 Z. Yang, T. K. Woo and K. Hermansson, *Chem. Phys. Lett.*, 2004, **396**, 384–392.
- 52 G. Henkelman, B. P. Uberuaga and H. Jónsson, *J. Chem. Phys.*, 2000, **113**, 9901–9904.

- 53 H. T. Chen, Y. Choi, M. Liu and M. C. Lin, *J. Phys. Chem. C*, 2007, 111, 11117–11122.
- 54 S. Fabris, G. Vicario, G. Balducci, S. de Gironcoli and S. Baroni, *J. Phys. Chem. B*, 2005, **109**, 22860–22867.
- 55 Z. X. Yang, Q. G. Wang, S. Y. Wei, D. W. Ma and Q. Sun, *J. Phys. Chem. C*, 2010, **114**, 14891–14899.
- 56 Z. X. Yang, Y. W. Wei, Z. M. Fu, Z. S. Lu and K. Hermansson, *Surf. Sci.*, 2008, **602**, 1199–1206.
- 57 S. A. French, A. A. Sokol, S. T. Bromley, C. R. A. Catlow, S. C. Rogers, F. King and P. Sherwood, *Angew. Chem., Int. Ed.*, 2001, 40, 4437–4440.
- 58 J. Tabatabaei, B. H. Sakakini and K. C. Waugh, *Catal. Lett.*, 2006, **110**, 77–84.
- 59 G. Liu, J. A. Rodriguez, J. Hrbek, J. Dvorak and C. H. F. Peden, J. Phys. Chem. B, 2001, 105, 7762–7770.
- 60 H. J. Freund and M. W. Roberts, Surf. Sci. Rep., 1996, 25, 225–273.
- 61 M. Huang and S. Fabris, J. Phys. Chem. C, 2008, 112, 8643-8648.
- 62 W. C. Chueh, C. Falter, M. Abbott, D. Scipio, P. Furler, S. M. Haile and A. Steinfeld, *Science*, 2010, 330, 1797–1801.
- 63 L. J. Venstrom, R. M. de Smith, Y. Hao, S. M. Haile and J. H. Davidson, *Energy Fuels*, 2014, 28, 2732–2742.