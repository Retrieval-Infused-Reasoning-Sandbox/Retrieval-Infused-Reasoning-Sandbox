# Angles Between Infinite Dimensional Subspaces with Applications to the Rayleigh-Ritz and Alternating Projectors Methods✩

Andrew Knyazeva,1,<sup>∗</sup> , Abram Jujunashvili<sup>a</sup> , Merico Argentati<sup>a</sup>

*<sup>a</sup>Department of Mathematical and Statistical Sciences University of Colorado Denver, P.O. Box 173364, Campus Box 170, Denver, CO 80217-3364*

### **Abstract**

We define angles from-to and between infinite dimensional subspaces of a Hilbert space, inspired by the work of E. J. Hannan, 1961/1962 for general canonical correlations of stochastic processes. The spectral theory of selfadjoint operators is used to investigate the properties of the angles, e.g., to establish connections between the angles corresponding to orthogonal complements. The classical gaps and angles of Dixmier and Friedrichs are characterized in terms of the angles. We introduce principal invariant subspaces and prove that they are connected by an isometry that appears in the polar decomposition of the product of corresponding orthogonal projectors. Point angles are defined by analogy with the point operator spectrum. We bound the Hausdorff distance between the sets of the squared cosines of the angles corresponding to the original subspaces and their perturbations. We show that the squared cosines of the angles from one subspace to another can be interpreted as Ritz values in the Rayleigh-Ritz method, where the former subspace serves as a trial subspace and the orthogonal projector of the latter subspace serves as an operator in the Rayleigh-Ritz method. The Hausdorff distance between the Ritz values, corresponding to different trial subspaces, is shown to be bounded by a constant times the gap between the trial subspaces. We prove a similar eigenvalue perturbation bound that involves the gap squared. Finally, we consider the classical alternating projectors method and propose its ultimate acceleration, using the conjugate gradient approach. The corresponding convergence rate estimate is obtained in terms of the angles. We illustrate a possible acceleration for the domain decomposition method with a small overlap for the 1D diffusion equation. c 2010 Knyazev, Jujunashvili, and Argentati. All rights reserved.

*Keywords:* Hilbert space, gap, canonical correlations, angles, isometry, polar decomposition, Rayleigh-Ritz method, alternating projectors, conjugate gradient, domain decomposition

<sup>✩</sup>A preliminary version is available at <http://arxiv.org/abs/0705.1023>

<sup>∗</sup>Corresponding author. Email: andrew[dot]knyazev[at]ucdenver[dot]edu

*Email addresses:* andrew[dot]knyazev[at]ucdenver[dot]edu (Andrew Knyazev ),

Abram[dot]Jujunashvili[at]na-net[dot]ornl[dot]gov (Abram Jujunashvili),

Merico[dot]Argentati[at]na-net[dot]ornl[dot]gov (Merico Argentati)

*URL:* http://math.ucdenver.edu/~aknyazev/ (Andrew Knyazev ),

http://math.ucdenver.edu/~margenta/ (Merico Argentati)

<sup>1</sup>This material is based upon work supported by the NSF DMS award 0612751.

#### 1. Introduction

Principal angles, also referred to as canonical angles, or simply as angles, between subspaces represent one of the classical mathematical tools with many applications. The cosines of the angles are related to canonical correlations which are widely used in statistics. Angles between finite dimensional subspaces have become so popular that they can be found even in linear algebra textbooks

The angles between subspaces  $\mathcal{F}$  and  $\mathcal{G}$  are defined as  $q = \min\{\dim \mathcal{F}, \dim \mathcal{G}\}$  values on  $[0, \pi/2]$  if  $q < \infty$ . In the case  $q = \infty$ , where both subspaces  $\mathcal{F}$  and  $\mathcal{G}$  are infinite dimensional, traditionally only single-valued angles are defined, which in the case  $q < \infty$  would correspond to the smallest (Dixmier [11]), smallest non-zero (Friedrichs [13]), or largest (Krein et al. [29]), angles. We define angles from-to and between (infinite) dimensional subspaces of a Hilbert space using the spectra of the product of corresponding orthogonal projectors. The definition is consistent with the finite dimensional case  $q < \infty$  and results in a *set*, possibly infinite, of angles.

Our definition is inspired by E.J. Hannan [16], where such an approach to canonical correlations of stochastic processes is suggested. Canonical correlations for stochastic processes and functional data often involve infinite dimensional subspaces. This paper is intended to revive the interest in angles between infinite dimensional subspaces.

In functional analysis, the gap and the minimum gap are important concepts used, e.g., in operator perturbation theory ([19]). The gap between infinite dimensional subspaces bounds the perturbation of a closed linear operator by measuring the change in its graph. We show in Theorem 2.12 that the gap is closely connected to the sine of the largest angle.

The minimum gap between infinite dimensional subspaces provides a necessary and sufficient condition to determine if the sum of two subspaces is closed. The minimum gap is applied, e.g., in [22] to prove wellposedness of degenerate saddle point problems. The minimum gap is precisely, see Theorem 2.15, the sine of the angle of Friedrichs, which, in its turn, as shown in Theorem 2.14, is the infimum of the set of nonzero angles. The Dixmier angle is simply the smallest of all angles in our definition.

We consider a (real or complex) Hilbert space equipped with an inner product (f,g) and a vector norm  $||f|| = (f,f)^{1/2}$ . The angle between two unit vectors f and g is  $\theta(f,g) = \arccos|(f,g)| \in [0,\pi/2]$ . In §2 of the present paper, we replace 1D subspaces spanned by the vectors f and g with (infinite dimensional) subspaces, and introduce the concept of principal angles from one subspace to another and between subspaces using the spectral theory of selfadjoint operators. We investigate the basic properties of the angles, which are already known for finite dimensional subspaces, see [23], e.g., we establish connections between the angles corresponding to subspaces and their orthogonal complements. We express classical quantities: the gap and the minimum gap between subspaces, in terms of the angles.

In § 2, we provide a foundation and give necessary tools for the rest of the paper, see also [5] and references there. In § 3, we introduce principal invariant subspaces and prove that they are connected by the isometry that appears in the polar decomposition of the product of corresponding orthogonal projectors. We define point angles by analogy with the point operator spectrum and consider peculiar properties of the invariant subspaces corresponding to a point angle. In § 4, the Hausdorff distance is used to measure the change in the principal angles, where one of the subspaces varies, extending some of our previous results of [23, 25] to infinite dimensional subspaces.

We consider two applications of the angles: to bound the change in Ritz values, where the Rayleigh-Ritz method is applied to different infinite dimensional trial subspaces, in §5; and to

analyze and accelerate the convergence of the classical alternating projectors method (e.g., [10, Chapter IX]) in the context of a specific example—a domain decomposition method (DDM) with an overlap, in §6. In computer simulations the subspaces involved are evidently finite dimensional; however, the assumption of the finite dimensionality is sometimes irrelevant in theoretical analysis of the methods.

In §5, we consider the Rayleigh-Ritz method for a bounded selfadjoint operator A on a trial subspace  $\mathcal{F}$  of a Hilbert space, where the spectrum  $\Sigma((P_{\mathcal{F}}A)|_{\mathcal{F}})$  of the restriction to the subspace  $\mathcal F$  of the product of the orthoprojector  $P_{\mathcal F}$  onto  $\mathcal F$  and the operator A is called the set of Ritz values, corresponding to A and  $\mathcal{F}$ . In the main result of §5, we bound the change in the Ritz values, where one trial subspace  $\mathcal{F}$  is replaced with another subspace  $\mathcal{G}$ , using the Hausdorff distance between the sets of Ritz values, by the spread of the spectrum times the gap between the subspaces. The proof of the general case is based on a specific case of one dimensional subspaces  $\mathcal{F}$  and  $\mathcal{G}$ , spanned by unit vectors f and g, correspondingly, where the estimate becomes particularly simple:  $|(f, Af) - (g, Ag)| \le (\lambda_{\text{max}} - \lambda_{\text{min}}) \sin(\theta(f, g))$ ; here  $\lambda_{\text{max}} - \lambda_{\text{min}}$  is the spread of the spectrum of A, cf. [24]. If in addition f or g is an eigenvector of A, the same bound holds but with the sine squared—similarly, our Hausdorff distance bound involves the gap squared, assuming that one of the trial subspaces is A-invariant. The material of §5 generalizes some of the earlier results of [25, 26] and [27] for the finite dimensional case. The Rayleigh-Ritz method with infinite dimensional trial subspaces is used in the method of intermediate problems for determining two-sided bounds for eigenvalues, e.g., [36, 37]. The results of §5 may be useful in obtaining a priori estimates of the accuracy of the method of intermediate problems, but this is outside of the scope of the present paper.

Our other application, in § 6, is the classical alternating projectors method:  $e^{(i+1)} = P_{\mathcal{F}} P_{\mathcal{G}} e^{(i)}$ ,  $e^{(0)} \in \mathcal{F}$ , where  $\mathcal{F}$  and  $\mathcal{G}$  are two given subspaces and  $P_{\mathcal{F}}$  and  $P_{\mathcal{G}}$  are the orthogonal projectors onto  $\mathcal{F}$  and  $\mathcal{G}$ , respectively. If  $\|(P_{\mathcal{F}} P_{\mathcal{G}})\|_{\mathcal{F}}\| < 1$  then the sequence of vectors  $e^{(i)}$  evidently converges to zero. Such a situation is typical if  $e^{(i)}$  represents an error of an iterative method, e.g., a multiplicative DDM, so that the alternating projectors method describes the error propagation in the DDM, e.g., [38, 4].

If the intersection  $\mathcal{F} \cap \mathcal{G}$  is nontrivial then the sequence of vectors  $e^{(i)}$  converges under reasonable assumptions to the orthogonal projection of  $e^{(0)}$  onto  $\mathcal{F} \cap \mathcal{G}$  as in the von Neumann-Halperin method, see [34, 15], and [2]. Several attempts to estimate and accelerate the convergence of alternating projectors method are made, e.g., [9, 2], and [39]. Here, we use a different approach, known in the DDM context, e.g., [38, 4], but apparently novel in the context of the von Neumann-Halperin method, and suggest the ultimate, conjugate gradient based, acceleration of the von Neumann-Halperin alternating projectors method.

Our idea of the acceleration is inspired by the following facts. On the one hand, every self-adjoint non-negative non-expansion A,  $0 \le A \le I$  in a Hilbert space  $\mathcal{H}$  can be extended to an orthogonal projector  $P_{\mathcal{G}}$  in the space  $\mathcal{H} \times \mathcal{H}$ , e.g., [14, 31], and, thus, is unitarily equivalent to a product of two orthogonal projectors  $P_{\mathcal{F}}P_{\mathcal{G}}$  restricted to the subspace  $\mathcal{F} = \mathcal{H} \times \{0\}$ . Any polynomial iterative method that involves as a main step a multiplication of a vector by A can thus be called an "alternating projectors" method. On the other hand, the conjugate gradient method is the optimal polynomial method for computing the null space of A, therefore the conjugate gradient approach provides the ultimate acceleration of the alternating projectors method.

We give in §6 the corresponding convergence rate estimate in terms of the angles. We illustrate a possible acceleration for the DDM with a small overlap for the 1D diffusion equation. The convergence of the classical alternating projectors method degrades when the overlap gets

smaller, but the conjugate gradient method we describe converges to the exact solution in two iterations. For a finite difference approximation of the 1D diffusion equation a similar result can be found in [12].

This paper is partially based on [18], where simple proofs that we skip here can be found.

## <span id="page-3-0"></span>2. Definition and Properties of the Angles

Here we define angles from one subspace to another and angles between subspaces, and investigate the properties of the (sets of) angles, such as the relationship concerning angles between the subspaces and their orthogonal complements. We express the gap and the minimum gap between subspaces in terms of angles. We introduce principal invariant subspaces and prove that they are connected by an isometry that appears in the polar decomposition of the product of corresponding orthogonal projectors. We define point angles and their multiplicities by analogy with the point operator spectrum, and consider peculiar properties of the invariant subspaces corresponding to a point angle.

#### <span id="page-3-1"></span>2.1. Preliminaries

Let  $\mathcal{H}$  be a (real or complex) Hilbert space and let  $\mathcal{F}$  and  $\mathcal{G}$  be proper nontrivial subspaces. A subspace is defined as a *closed* linear manifold. Let  $P_{\mathcal{F}}$  and  $P_{\mathcal{G}}$  be the orthogonal projectors onto  $\mathcal{F}$  and  $\mathcal{G}$ , respectively. We denote by  $\mathcal{B}(\mathcal{H})$  the Banach space of bounded linear operators defined on  $\mathcal{H}$  with the induced norm. We use the same notation  $\|\cdot\|$  for the vector norm on  $\mathcal{H}$ , associated with the inner product  $(\cdot,\cdot)$  on  $\mathcal{H}$ , as well as for the induced operator norm on  $\mathcal{B}(\mathcal{H})$ . For  $T \in \mathcal{B}(\mathcal{H})$  we define  $|T| = \sqrt{T^*T}$ , using the positive square root.  $T|_U$  denotes the restriction of the operator T to its invariant subspace U. By  $\mathfrak{D}(T)$ ,  $\mathfrak{R}(T)$ ,  $\mathfrak{N}(T)$ ,  $\mathfrak{D}(T)$ , and  $\mathfrak{D}_p(T)$  we denote the domain, range, null space, spectrum, and point spectrum, respectively, of the operator T. In this paper, we distinguish only between finite and infinite dimensions. If q is a finite number then we set by definition  $\min\{q,\infty\} = q$  and  $\max\{q,\infty\} = \infty$ , and assume that  $\infty \leq \infty$  holds. We use  $\oplus$  to highlight that the sum of subspaces is orthogonal and for the corresponding sum of operators. We denote the  $\Theta$  operation between subspaces  $\mathcal{F}$  and  $\mathcal{G}$  by  $\mathcal{F} \ominus \mathcal{G} = \mathcal{F} \cap \mathcal{G}^{\perp}$ .

Introducing an orthogonal decomposition  $\mathcal{H} = \mathfrak{M}_{00} \oplus \mathfrak{M}_{01} \oplus \mathfrak{M}_{10} \oplus \mathfrak{M}_{11} \oplus \mathfrak{M}$ , where

$$\mathfrak{M}_{00} = \mathcal{F} \cap \mathcal{G}, \ \mathfrak{M}_{01} = \mathcal{F} \cap \mathcal{G}^{\perp}, \ \mathfrak{M}_{10} = \mathcal{F}^{\perp} \cap \mathcal{G}, \ \mathfrak{M}_{11} = \mathcal{F}^{\perp} \cap \mathcal{G}^{\perp},$$

(see, e.g., [14, 6]), we note that every subspace in the decomposition is  $P_{\mathcal{F}}$  and  $P_{\mathcal{G}}$  invariant.

**Definition 2.1.** (See [14]). Two subspaces  $\mathcal{F} \subset \mathcal{H}$  and  $\mathcal{G} \subset \mathcal{H}$  are said to be in generic position within the space  $\mathcal{H}$ , if all four subspaces  $\mathfrak{M}_{00}$ ,  $\mathfrak{M}_{01}$ ,  $\mathfrak{M}_{10}$ , and  $\mathfrak{M}_{11}$  are null-dimensional.

Clearly, subspaces  $\mathcal{F} \subset \mathcal{H}$  and  $\mathcal{G} \subset \mathcal{H}$  are in generic position within the space  $\mathcal{H}$  iff any of the pairs of subspaces:  $\mathcal{F} \subset \mathcal{H}$  and  $\mathcal{G}^{\perp} \subset \mathcal{H}$ , or  $\mathcal{F}^{\perp} \subset \mathcal{H}$  and  $\mathcal{G} \subset \mathcal{H}$ , or  $\mathcal{F}^{\perp} \subset \mathcal{H}$  and  $\mathcal{G}^{\perp} \subset \mathcal{H}$ , is in generic position within the space  $\mathcal{H}$ .

The fifth part,  $\mathfrak{M}$ , can be further orthogonally split in two different ways as follows:

- $\mathfrak{M} = \mathfrak{M}_{\mathcal{F}} \oplus \mathfrak{M}_{\mathcal{F}^{\perp}}$  with  $\mathfrak{M}_{\mathcal{F}} = \mathcal{F} \ominus (\mathfrak{M}_{00} \oplus \mathfrak{M}_{01}), \ \mathfrak{M}_{\mathcal{F}^{\perp}} = \mathcal{F}^{\perp} \ominus (\mathfrak{M}_{10} \oplus \mathfrak{M}_{11}), \text{ or }$
- $\mathfrak{M} = \mathfrak{M}_G \oplus \mathfrak{M}_{G^{\perp}}$  with  $\mathfrak{M}_G = G \ominus (\mathfrak{M}_{00} \oplus \mathfrak{M}_{10}), \ \mathfrak{M}_{G^{\perp}} = G^{\perp} \ominus (\mathfrak{M}_{01} \oplus \mathfrak{M}_{11}).$

We obtain orthoprojectors' decompositions

$$P_{\mathcal{F}} = I_{\mathfrak{M}_{00}} \oplus I_{\mathfrak{M}_{01}} \oplus 0_{\mathfrak{M}_{10}} \oplus 0_{\mathfrak{M}_{11}} \oplus P_{\mathcal{F}}|_{\mathfrak{M}} \text{ and } P_{\mathcal{G}} = I_{\mathfrak{M}_{00}} \oplus 0_{\mathfrak{M}_{01}} \oplus I_{\mathfrak{M}_{10}} \oplus 0_{\mathfrak{M}_{11}} \oplus P_{\mathcal{G}}|_{\mathfrak{M}},$$

and decompositions of their products:

$$(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}} = I_{\mathfrak{M}_{00}} \oplus 0_{\mathfrak{M}_{01}} \oplus (P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathfrak{M}_{\mathcal{F}}}, \text{ and } (P_{\mathcal{G}}P_{\mathcal{F}})|_{\mathcal{G}} = I_{\mathfrak{M}_{00}} \oplus 0_{\mathfrak{M}_{10}} \oplus (P_{\mathcal{G}}P_{\mathcal{F}})|_{\mathfrak{M}_{\mathcal{G}}}.$$

These decompositions are very useful in the sequel. In the next theorem we apply them to prove the unitary equivalence of the operators  $P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}$  and  $P_{\mathcal{G}}P_{\mathcal{F}}P_{\mathcal{G}}$ .

<span id="page-4-0"></span>**Theorem 2.2.** Let  $\mathcal{F}$  and  $\mathcal{G}$  be subspaces of  $\mathcal{H}$ . Then there exists a unitary operator  $W \in \mathcal{B}(\mathcal{H})$  such that  $P_{\mathcal{F}}P_{G}P_{\mathcal{F}} = W^{*}P_{G}P_{\mathcal{F}}P_{G}W$ .

*Proof.* Denote  $T = P_{\mathcal{G}}P_{\mathcal{F}}$ . Then  $T^* = P_{\mathcal{F}}P_{\mathcal{G}}$  and  $T^*T = P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}$ . Using, e.g., [31, §110, p. 286] or [19, §VI.2.7, p. 334], we introduce the polar decomposition, T = U|T|, where  $|T| = \sqrt{T^*T} = \sqrt{P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}}$  is selfadjoint and nonnegative and  $U: \mathfrak{R}(|T|) \to \mathfrak{R}(T)$  is an isometry. We extend U by continuity, keeping the same notation, to the isometry  $U: \overline{\mathfrak{R}(|T|)} \to \overline{\mathfrak{R}(T)}$ . It is easy to check directly that  $\mathfrak{N}(|T|) = \mathfrak{N}(T)$ , so  $\overline{\mathfrak{R}(|T|)} = (\mathfrak{N}(T))^{\perp}$  since |T| is selfadjoint. Taking also into account that  $\overline{\mathfrak{R}(T)} = (\mathfrak{N}(T^*))^{\perp}$ , we have  $U: (\mathfrak{N}(T))^{\perp} \to (\mathfrak{N}(T^*))^{\perp}$ .

For a general operator  $T \in \mathcal{B}(\mathcal{H})$ , the isometry U is then typically extended to a partial isometry  $U \in \mathcal{B}(\mathcal{H})$  by setting U = 0 on  $\mathfrak{N}(T)$ . For our special  $T = P_{\mathcal{G}}P_{\mathcal{F}}$ , we can do better and extend U to a unitary operator  $W \in \mathcal{B}(\mathcal{H})$ . Indeed, we set W = U on  $(\mathfrak{N}(T))^{\perp}$  to make W an extension of U. To make W unitary, we set W = V on  $\mathfrak{N}(T)$ , where  $V : \mathfrak{N}(T) \to \mathfrak{N}(T^*)$  must be an isometry. The specific form of V is of no importance, since it evidently does not affect the validity of the formula  $P_{\mathcal{G}}P_{\mathcal{F}} = W\sqrt{P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}}$ , which implies  $P_{\mathcal{F}}P_{\mathcal{G}} = \sqrt{P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}}W^*$ . Multiplying these equalities we obtain the required  $P_{\mathcal{G}}P_{\mathcal{F}}P_{\mathcal{G}} = WP_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}W^*$ .

For the existence of such V, it is sufficient (and, in fact, necessary) that  $\mathfrak{N}(T^*) = \mathfrak{N}(P_{\mathcal{F}}P_{\mathcal{G}})$  and  $\mathfrak{N}(T) = \mathfrak{N}(P_{\mathcal{G}}P_{\mathcal{F}})$  be isomorphic. Using the five-parts decomposition, we get

$$\mathfrak{N}(P_{\mathcal{F}}P_G) = \mathfrak{M}_{01} \oplus \mathfrak{M}_{10} \oplus \mathfrak{M}_{11} \oplus \mathfrak{N}((P_{\mathcal{F}}P_G)|_{\mathfrak{M}}), \ \mathfrak{N}(P_GP_{\mathcal{F}}) = \mathfrak{M}_{01} \oplus \mathfrak{M}_{10} \oplus \mathfrak{M}_{11} \oplus \mathfrak{N}((P_GP_{\mathcal{F}})|_{\mathfrak{M}}).$$

The first three terms in the decompositions of  $\mathfrak{N}(P_{\mathcal{F}}P_{\mathcal{G}})$  and  $\mathfrak{N}(P_{\mathcal{G}}P_{\mathcal{F}})$  are the same, so  $\mathfrak{N}(P_{\mathcal{F}}P_{\mathcal{G}})$  and  $\mathfrak{N}(P_{\mathcal{G}}P_{\mathcal{F}})$  are isomorphic iff the last terms  $\mathfrak{N}((P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathfrak{M}})=\mathfrak{M}_{\mathcal{G}^{\perp}}$  and  $\mathfrak{N}((P_{\mathcal{G}}P_{\mathcal{F}})|_{\mathfrak{M}})=\mathfrak{M}_{\mathcal{F}^{\perp}}$  are isomorphic. The subspaces  $\mathfrak{M}_{\mathcal{F}}=P_{\mathcal{F}}\mathfrak{M}\subseteq\mathfrak{M}$  and  $\mathfrak{M}_{\mathcal{G}}=P_{\mathcal{G}}\mathfrak{M}\subseteq\mathfrak{M}$  are in generic position within the space  $\mathfrak{M}$ , see [14], as well as their orthogonal in  $\mathfrak{M}$  complements  $\mathfrak{M}_{\mathcal{F}^{\perp}}$  and  $\mathfrak{M}_{\mathcal{G}^{\perp}}$ . According to [14, Proof of Theorem 1, p. 382], any two subspaces in generic position are isomorphic, thus  $\mathfrak{N}(P_{\mathcal{F}}P_{\mathcal{G}})$  and  $\mathfrak{N}(P_{\mathcal{G}}P_{\mathcal{F}})$  are isomorphic.  $\square$ 

<span id="page-4-1"></span>**Corollary 2.3.** The operators  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathfrak{M}_{\mathcal{F}}}$  and  $(P_{\mathcal{G}}P_{\mathcal{F}})|_{\mathfrak{M}_{\mathcal{G}}}$  are unitarily equivalent.

*Proof.* We have that  $P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}} = (P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathfrak{M}_{\mathcal{F}}} \oplus I_{\mathfrak{M}_{00}} \oplus 0_{\mathcal{H} \ominus (\mathfrak{M}_{00} \oplus \mathfrak{M}_{\mathcal{F}})}$  and  $P_{\mathcal{G}}P_{\mathcal{F}}P_{\mathcal{G}} = (P_{\mathcal{G}}P_{\mathcal{F}})|_{\mathfrak{M}_{\mathcal{G}}} \oplus I_{\mathfrak{M}_{00}} \oplus 0_{\mathcal{H} \ominus (\mathfrak{M}_{00} \oplus \mathfrak{M}_{\mathcal{G}})}$ . The subspaces  $\mathfrak{M}_{\mathcal{F}}$  and  $\mathfrak{M}_{\mathcal{G}}$  are connected by  $\mathfrak{M}_{\mathcal{F}} = W\mathfrak{M}_{\mathcal{G}}$ ,  $\mathfrak{M}_{\mathcal{G}} = W^*\mathfrak{M}_{\mathcal{F}}$ , and  $P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}} = W^*P_{\mathcal{G}}P_{\mathcal{F}}P_{\mathcal{G}}W$ .

In the important particular case  $||P_{\mathcal{F}} - P_{\mathcal{G}}|| < 1$ , subspaces  $\mathcal{F}$  and  $\mathcal{G}$  are isometric and Riesz and Sz.-Nagy [31, §VII.105] explicitly describe a partial isometry

$$U = P_G[I + P_{\mathcal{F}}(P_G - P_{\mathcal{F}})P_{\mathcal{F}}]^{-1/2}P_{\mathcal{F}}$$

that maps  $\mathcal{F}$  one-to-one and onto  $\mathcal{G}$ . On  $\mathcal{F}$ , clearly  $I + P_{\mathcal{F}}(P_{\mathcal{G}} - P_{\mathcal{F}})P_{\mathcal{F}}$  is just the same as  $P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}$ , so this U represents the partial isometry in the polar decomposition in the proof of our Theorem 2.2, in this case. Let

$$V = (I - P_G)[I + (I - P_{\mathcal{F}})((I - P_G) - (I - P_{\mathcal{F}}))(I - P_{\mathcal{F}})]^{-1/2}(I - P_{\mathcal{F}})$$

be another partial isometry that maps  $\mathcal{F}^{\perp}$  one-to-one and onto  $\mathcal{G}^{\perp}$ , constructed in the same way as U. Setting W=U+V, we extend U from the subspace  $\mathcal{F}$  to a unitary operator W on the whole space. The sum W=U+V is the same as the unitary extension suggested in Kato [19, §I.4.6, §I.6.8] and Davis and Kahan [7]:

<span id="page-5-3"></span>
$$W = [P_{\mathcal{G}}P_{\mathcal{F}} + (I - P_{\mathcal{G}})(I - P_{\mathcal{F}})][I - (P_{\mathcal{F}} - P_{\mathcal{G}})^{2}]^{-1/2}$$

$$= [(I - P_{\mathcal{G}})(I - P_{\mathcal{F}}) + P_{\mathcal{F}}P_{\mathcal{G}}]^{-1/2}[P_{\mathcal{G}}P_{\mathcal{F}} + (I - P_{\mathcal{G}})(I - P_{\mathcal{F}})]$$
(2.1)

(the second equality holds since the corresponding terms in square brackets are the same and  $(P_{\mathcal{F}} - P_{\mathcal{G}})^2$  commutes both with  $P_{\mathcal{F}}$  and  $P_{\mathcal{G}}$ ), which is used there to prove the unitary equivalence  $P_{\mathcal{F}} = W^* P_{\mathcal{G}} W$ . It is easy to check directly that the operator W is unitary and that on  $\mathcal{F}$  it acts the same as the operator U, so it is indeed a unitary extension of U. If  $||P_{\mathcal{F}} - P_{\mathcal{G}}|| < 1$ , Theorem 2.2 holds with this choice of W.

In the next subsection we define angles from-to and between subspaces using the spectrum of the product of two orthogonal projectors. Our goal is to develop a theory of angles from-to and between subspaces based on the well-known spectral theory of selfadjoint bounded operators.

#### 2.2. Angles From-To and Angles Between Subspaces

<span id="page-5-1"></span>**Definition 2.4.**  $\hat{\Theta}(\mathcal{F},\mathcal{G}) = \{\theta : \theta = \arccos(\sigma), \sigma \geq 0, \sigma^2 \in \Sigma((P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}})\} \subseteq [0,\pi/2]$  is called the set of angles from the subspace  $\mathcal{F}$  to the subspace  $\mathcal{G}$ . Angles  $\Theta(\mathcal{F},\mathcal{G}) = \hat{\Theta}(\mathcal{F},\mathcal{G}) \cap \hat{\Theta}(\mathcal{G},\mathcal{F})$  are called angles between the subspaces  $\mathcal{F}$  and  $\mathcal{G}$ .

Let the operator  $T \in \mathcal{B}(\mathcal{H})$  be a selfadjoint nonnegative contraction. Using an extension of T to an orthogonal projector [31, §A.2, p. 461], there exist subspaces  $\mathcal{F}$  and  $\mathcal{G}$  in  $\mathcal{H}^2$  such that T is unitarily equivalent to  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}}$ , where  $P_{\mathcal{F}}$  and  $P_{\mathcal{G}}$  are the corresponding orthogonal projectors in  $\mathcal{H}^2$ . This implies that the spectrum of the product of two orthogonal projectors is as general a set as the spectrum of an arbitrary selfadjoint nonnegative contraction, so the set of angles between subspaces can be a sufficiently general subset of  $[0, \pi/2]$ .

<span id="page-5-2"></span>**Definition 2.5.** The angles  $\hat{\Theta}_p(\mathcal{F},\mathcal{G}) = \{\theta \in \hat{\Theta}(\mathcal{F},\mathcal{G}) : \cos^2(\theta) \in \Sigma_p((P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}})\}$  and  $\Theta_p(\mathcal{F},\mathcal{G}) = \hat{\Theta}_p(\mathcal{F},\mathcal{G}) \cap \hat{\Theta}_p(\mathcal{G},\mathcal{F})$  are called point angles. Angle  $\theta \in \hat{\Theta}_p(\mathcal{F},\mathcal{G})$  inherits its multiplicity from  $\cos^2(\theta) \in \Sigma_p((P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}})$ . Multiplicity of angle  $\theta \in \Theta_p(\mathcal{F},\mathcal{G})$  is the minimum of multiplicities of  $\theta \in \hat{\Theta}_p(\mathcal{F},\mathcal{G})$  and  $\theta \in \hat{\Theta}_p(\mathcal{G},\mathcal{F})$ .

For two vectors f and g in the plane, and their orthogonal counterparts  $f^{\perp}$  and  $g^{\perp}$  we evidently have that  $\theta(f,g)=\theta(f^{\perp},g^{\perp})$  and  $\theta(f,g)+\theta(f,g^{\perp})=\pi/2$ . We now describe relationships for angles, corresponding to subspaces  $\mathcal{F},\mathcal{G},\mathcal{F}^{\perp}$ , and  $\mathcal{G}^{\perp}$ . We first consider the angles from one subspace to another as they reveal the finer details and provide a foundation for statements on angles between subspaces.

<span id="page-5-0"></span>**Theorem 2.6.** For any pair of subspaces  $\mathcal{F}$  and  $\mathcal{G}$  of  $\mathcal{H}$ :

1. 
$$\hat{\Theta}(\mathcal{F}, \mathcal{G}^{\perp}) = \pi/2 - \hat{\Theta}(\mathcal{F}, \mathcal{G})$$
;

```
2. \hat{\Theta}(\mathcal{G}, \mathcal{F}) \setminus \{\pi/2\} = \hat{\Theta}(\mathcal{F}, \mathcal{G}) \setminus \{\pi/2\};
```

- 3.  $\hat{\Theta}(\mathcal{F}^{\perp},\mathcal{G}) \setminus (\{0\} \cup \{\pi/2\}) = \pi/2 \{\hat{\Theta}(\mathcal{F},\mathcal{G}) \setminus (\{0\} \cup \{\pi/2\})\};$
- 4.  $\hat{\Theta}(\mathcal{F}^{\perp}, \mathcal{G}^{\perp}) \setminus (\{0\} \cup \{\pi/2\}) = \hat{\Theta}(\mathcal{F}, \mathcal{G}) \setminus (\{0\} \cup \{\pi/2\});$
- 5.  $\hat{\Theta}(\mathcal{G}, \mathcal{F}^{\perp}) \setminus \{0\} = \pi/2 \{\hat{\Theta}(\mathcal{F}, \mathcal{G}) \setminus \{\pi/2\}\};$
- 6.  $\hat{\Theta}(\mathcal{G}^{\perp}, \mathcal{F}) \setminus \{\pi/2\} = \pi/2 \{\hat{\Theta}(\mathcal{F}, \mathcal{G}) \setminus \{0\}\};$
- 7.  $\hat{\Theta}(\mathcal{G}^{\perp}, \mathcal{F}^{\perp}) \setminus \{0\} = \hat{\Theta}(\mathcal{F}, \mathcal{G}) \setminus \{0\}.$

| rable 1. Wattiplieties of a and x/2 angles for afficient pairs of sabspaces |                          |                          |                                                         |                          |                          |
|-----------------------------------------------------------------------------|--------------------------|--------------------------|---------------------------------------------------------|--------------------------|--------------------------|
| Pair                                                                        | $\theta = 0$             | $\theta = \pi/2$         | Pair                                                    | $\theta = 0$             | $\theta = \pi/2$         |
| $\hat{\Theta}(\mathcal{F},\mathcal{G})$                                     | $\dim \mathfrak{M}_{00}$ | $\dim \mathfrak{M}_{01}$ | $\hat{\Theta}(\mathcal{G},\mathcal{F})$                 | $\dim \mathfrak{M}_{00}$ | $\dim\mathfrak{M}_{10}$  |
| $\hat{\Theta}(\mathcal{F},\mathcal{G}^\perp)$                               | $\dim \mathfrak{M}_{01}$ | $\dim \mathfrak{M}_{00}$ | $\hat{\Theta}(\mathcal{G},\mathcal{F}^\perp)$           | $\dim\mathfrak{M}_{10}$  | $\dim \mathfrak{M}_{00}$ |
| $\hat{\Theta}(\mathcal{F}^{\perp},\mathcal{G})$                             | $\dim \mathfrak{M}_{10}$ | $\dim \mathfrak{M}_{11}$ | $\hat{\Theta}(\mathcal{G}^{\perp},\mathcal{F})$         | $\dim \mathfrak{M}_{01}$ | $\dim \mathfrak{M}_{11}$ |
| $\hat{\Theta}(\mathcal{F}^\perp,\mathcal{G}^\perp)$                         | $\dim\mathfrak{M}_{11}$  | $\dim \mathfrak{M}_{10}$ | $\hat{\Theta}(\mathcal{G}^{\perp},\mathcal{F}^{\perp})$ | $\dim \mathfrak{M}_{11}$ | $\dim \mathfrak{M}_{01}$ |

<span id="page-6-0"></span>Table 1: Multiplicities of 0 and  $\pi/2$  angles for different pairs of subspaces

The multiplicities of the point angles  $\theta \in (0, \pi/2)$  in  $\hat{\Theta}(\mathcal{F}, \mathcal{G})$ ,  $\hat{\Theta}(\mathcal{F}^{\perp}, \mathcal{G}^{\perp})$ ,  $\hat{\Theta}(\mathcal{G}, \mathcal{F})$  and  $\hat{\Theta}(\mathcal{G}^{\perp}, \mathcal{F}^{\perp})$  are the same, and are equal to the multiplicities of the point angles  $\pi/2 - \theta \in (0, \pi/2)$  in  $\hat{\Theta}(\mathcal{F}, \mathcal{G}^{\perp})$ ,  $\hat{\Theta}(\mathcal{F}^{\perp}, \mathcal{G})$ ,  $\hat{\Theta}(\mathcal{G}, \mathcal{F}^{\perp})$  and  $\hat{\Theta}(\mathcal{G}^{\perp}, \mathcal{F})$ .

*Proof.* (1) Using the equalities  $(P_{\mathcal{F}}P_{\mathcal{G}^{\perp}})|_{\mathcal{F}} = P_{\mathcal{F}}|_{\mathcal{F}} - (P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}} = I|_{\mathcal{F}} - (P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}}$  and the spectral mapping theorem for f(T) = I - T we have  $\Sigma((P_{\mathcal{F}}P_{\mathcal{G}^{\perp}})|_{\mathcal{F}}) = 1 - \Sigma((P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}})$ . Next, using the identity  $\mathfrak{N}(T - \lambda I) = \mathfrak{N}((I - T) - (1 - \lambda)I)$ , we conclude that  $\lambda$  is an eigenvalue of  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}}$  if and only if  $1 - \lambda$  is an eigenvalue of  $(P_{\mathcal{F}}P_{\mathcal{G}^{\perp}})|_{\mathcal{F}}$ , and that their multiplicities are the same.

- (2) The statement on nonzero angles follows from Corollary 2.3. The part concerning the zero angles follows from the fact that  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathfrak{M}_{00}} = (P_{\mathcal{G}}P_{\mathcal{F}})|_{\mathfrak{M}_{00}} = I|_{\mathfrak{M}_{00}}$ .
- (3-7) All other statements can be obtained from the (1-2) by exchanging the subspaces. Table 1 entries are checked directly using the five-parts decomposition.

Theorem 2.7 and Table 2 relate the sets of angles between pairs of subspaces:

<span id="page-6-1"></span>**Theorem 2.7.** For any subspaces  $\mathcal{F}$  and  $\mathcal{G}$  of  $\mathcal{H}$  the following equalities hold:

- 1.  $\Theta(\mathcal{F}, \mathcal{G}) \setminus (\{0\} \cup \{\pi/2\}) = \{\pi/2 \Theta(\mathcal{F}, \mathcal{G}^{\perp})\} \setminus (\{0\} \cup \{\pi/2\});$
- 2.  $\Theta(\mathcal{F},\mathcal{G})\setminus\{0\}=\Theta(\mathcal{F}^{\perp},\mathcal{G}^{\perp})\setminus\{0\};$
- 3.  $\Theta(\mathcal{F}, \mathcal{G}^{\perp}) \setminus \{0\} = \Theta(\mathcal{F}^{\perp}, \mathcal{G}) \setminus \{0\}.$

The multiplicities of the point angles  $\theta$  in  $\Theta(\mathcal{F},\mathcal{G})$  and  $\Theta(\mathcal{F}^{\perp},\mathcal{G}^{\perp})$  satisfying  $0 < \theta < \pi/2$  are the same, and equal to the multiplicities of point angles  $0 < \pi/2 - \theta < \pi/2$  in  $\Theta(\mathcal{F},\mathcal{G}^{\perp})$  and  $\Theta(\mathcal{F}^{\perp},\mathcal{G})$ .

*Proof.* Statement (1) follows from Theorem 2.6 since

$$\Theta(\mathcal{F},\mathcal{G}) \setminus (\{0\} \cup \{\pi/2\}) = \hat{\Theta}(\mathcal{F},\mathcal{G}) \setminus (\{0\} \cup \{\pi/2\}) 
= \{\pi/2 - \hat{\Theta}(\mathcal{F},\mathcal{G}^{\perp})\} \setminus (\{0\} \cup \{\pi/2\}) 
= \{\pi/2 - \Theta(\mathcal{F},\mathcal{G}^{\perp})\} \setminus (\{0\} \cup \{\pi/2\}), 
7$$

<span id="page-7-0"></span>

| Table 2: Multiplicities of 0 and $\pi/2$ angles between subspace | Table 2: | Multiplicities | of 0 and $\pi$ / | 2 angles between | n subspaces |
|------------------------------------------------------------------|----------|----------------|------------------|------------------|-------------|
|------------------------------------------------------------------|----------|----------------|------------------|------------------|-------------|

| Tueste 2. Triansprientes et e una x/2 ungres eet een suesputes |                          |                                                       |  |  |  |  |
|----------------------------------------------------------------|--------------------------|-------------------------------------------------------|--|--|--|--|
| Pair                                                           | $\theta = 0$             | $\theta = \pi/2$                                      |  |  |  |  |
| $\Theta(\mathcal{F},\mathcal{G})$                              | $\dim \mathfrak{M}_{00}$ | $\min\{\dim\mathfrak{M}_{01},\dim\mathfrak{M}_{10}\}$ |  |  |  |  |
| $\Theta(\mathcal{F},\mathcal{G}^\perp)$                        | $\dim \mathfrak{M}_{01}$ | $\min\{\dim\mathfrak{M}_{00},\dim\mathfrak{M}_{11}\}$ |  |  |  |  |
| $\Theta(\mathcal{F}^{\perp},\mathcal{G})$                      | $\dim \mathfrak{M}_{10}$ | $\min\{\dim\mathfrak{M}_{00},\dim\mathfrak{M}_{11}\}$ |  |  |  |  |
| $\Theta(\mathcal{F}^\perp,\mathcal{G}^\perp)$                  | $\dim \mathfrak{M}_{11}$ | $\min\{\dim\mathfrak{M}_{01},\dim\mathfrak{M}_{10}\}$ |  |  |  |  |

Using Theorem 2.6(7) twice: first for  $\mathcal{F}$  and  $\mathcal{G}$ , next for  $\mathcal{G}$  and  $\mathcal{F}$ , and then intersecting them gives (2). Interchanging  $\mathcal{G}$  and  $\mathcal{G}^{\perp}$  in (2) leads to (3). The statements on multiplicities easily follow from Theorem 2.6 as the entries in Table 2 are just the minima between pairs of the corresponding entries in Table 1.

**Remark 2.8.** *Theorem 2.6(1) allows us to introduce an equivalent sine-based definition:* 

$$\hat{\Theta}(\mathcal{F},\mathcal{G}) = \{\theta: \ \theta = \arcsin(\mu), \ \mu \ge 0, \ \mu^2 \in \Sigma((P_{\mathcal{F}}P_{\mathcal{G}^{\perp}})|_{\mathcal{F}})\} \subseteq [0,\pi/2].$$

**Remark 2.9.** Theorem 2.6(2) implies  $\Theta(\mathcal{F},\mathcal{G}) \setminus \{\pi/2\} = \hat{\Theta}(\mathcal{F},\mathcal{G}) \setminus \{\pi/2\} = \hat{\Theta}(\mathcal{G},\mathcal{F}) \setminus \{\pi/2\}$ .

**Remark 2.10.** We have  $\overline{\Theta(\mathcal{F},\mathcal{G}) \setminus (\{0\} \cup \{\pi/2\})} = \Theta(P_{\mathfrak{M}}\mathcal{F}, P_{\mathfrak{M}}\mathcal{G})$ , in other words, the projections  $P_{\mathfrak{M}}\mathcal{F} = \mathfrak{M}_{\mathcal{F}}$  and  $P_{\mathfrak{M}}\mathcal{G} = \mathfrak{M}_{\mathcal{G}}$  of the initial subspaces  $\mathcal{F}$  and  $\mathcal{G}$  onto their "fifth part"  $\mathfrak{M}$  are in generic position within  $\mathfrak{M}$ , see [14], so the zero and right angles can not belong to the set of point angles  $\Theta_p(P_{\mathfrak{M}}\mathcal{F}, P_{\mathfrak{M}}\mathcal{G})$ , but apart from 0 and  $\pi/2$  the angles  $\Theta(\mathcal{F},\mathcal{G})$  and  $\Theta(P_{\mathfrak{M}}\mathcal{F}, P_{\mathfrak{M}}\mathcal{G})$  are the same.

Remark 2.11. Tables 1 and 2 give the absolute values of the multiplicities of 0 and  $\pi/2$ . If we need relative multiplicities, e.g., how many "extra" 0 and  $\pi/2$  values are in  $\Theta(\mathcal{F}^\perp,\mathcal{G}^\perp)$  compared to  $\Theta(\mathcal{F},\mathcal{G})$ , we can easily find the answers from Tables 1 and 2 by subtraction, assuming that we subtract finite numbers, and use identities such as  $\dim \mathfrak{M}_{00} - \dim \mathfrak{M}_{11} = \dim \mathcal{F} - \dim \mathcal{G}^\perp$  and  $\dim \mathfrak{M}_{01} - \dim \mathfrak{M}_{10} = \dim \mathcal{F} - \dim \mathcal{G}$ . Indeed, for the particular question asked above, we observe that the multiplicity of  $\pi/2$  is the same in  $\Theta(\mathcal{F}^\perp,\mathcal{G}^\perp)$  and in  $\Theta(\mathcal{F},\mathcal{G})$ , but the difference in the multiplicities of 0 in  $\Theta(\mathcal{F}^\perp,\mathcal{G}^\perp)$  compared to in  $\Theta(\mathcal{F},\mathcal{G})$  is equal to  $\dim \mathfrak{M}_{11} - \dim \mathfrak{M}_{00} = \dim \mathcal{G}^\perp - \dim \mathcal{F}$ , provided that the terms that participate in the subtractions are finite. Some comparisons require both the dimension and the codimension of a subspace to be finite, thus, effectively requiring  $\dim \mathcal{H} < \infty$ .

## 2.3. Known Quantities as Functions of Angles

The gap bounds the perturbation of a closed linear operator by measuring the change in its graph, while the minimum gap between two subspaces determines if the sum of the subspaces is closed. We connect the gap and the minimum gap to the largest and to the nontrivial smallest principal angles. E.g., for subspaces  $\mathcal{F}$  and  $\mathcal{G}$  in generic position, i.e., if  $\mathfrak{M} = \mathcal{H}$ , we show that the gap and the minimum gap are the supremum and the infimum, correspondingly, of the sine of the set of angles between  $\mathcal{F}$  and  $\mathcal{G}$ .

The gap (aperture) between subspaces  $\mathcal{F}$  and  $\mathcal{G}$  defined as, e.g., [19],

$$gap(\mathcal{F}, \mathcal{G}) = \left\| P_{\mathcal{F}} - P_{\mathcal{G}} \right\| = \max_{\mathcal{R}} \left\{ \left\| P_{\mathcal{F}} P_{\mathcal{G}^{\perp}} \right\|, \left\| P_{\mathcal{G}} P_{\mathcal{F}^{\perp}} \right\| \right\}$$

is used to measure the distance between subspaces. We now describe the gap in terms of the angles.

<span id="page-8-0"></span>**Theorem 2.12.** 
$$\min \{ \min \{ \cos^2(\hat{\Theta}(\mathcal{F}, \mathcal{G})) \}, \min \{ \cos^2(\hat{\Theta}(\mathcal{G}, \mathcal{F})) \} \} = 1 - \operatorname{gap}^2(\mathcal{F}, \mathcal{G}).$$

*Proof.* Let us consider both norms in the definition of the gap separately. Using Theorem 2.6, we have

$$\begin{split} \|P_{\mathcal{F}}P_{\mathcal{G}^{\perp}}\|^{2} &= \sup_{\substack{u \in \mathcal{H} \\ \|u\|=1}} \|P_{\mathcal{F}}P_{\mathcal{G}^{\perp}}u\|^{2} = \sup_{\substack{u \in \mathcal{H} \\ \|u\|=1}} (P_{\mathcal{F}}P_{\mathcal{G}^{\perp}}u, P_{\mathcal{F}}P_{\mathcal{G}^{\perp}}u) \\ &= \sup_{\substack{u \in \mathcal{H} \\ \|u\|=1}} (P_{\mathcal{G}^{\perp}}P_{\mathcal{F}}P_{\mathcal{G}^{\perp}}u, u) = \|(P_{\mathcal{G}^{\perp}}P_{\mathcal{F}})|_{\mathcal{G}^{\perp}}\| = \max\{\cos^{2}(\hat{\Theta}(\mathcal{G}^{\perp}, \mathcal{F}))\} \\ &= \max\{\sin^{2}(\hat{\Theta}(\mathcal{G}, \mathcal{F}))\} = 1 - \min\{\cos^{2}(\hat{\Theta}(\mathcal{G}, \mathcal{F}))\}. \end{split}$$

Similarly, 
$$||P_{\mathcal{G}}P_{\mathcal{F}^{\perp}}||^2 = \max\{\cos^2(\hat{\Theta}(\mathcal{F}^{\perp}, \mathcal{G}))\} = 1 - \min\{\cos^2(\hat{\Theta}(\mathcal{F}, \mathcal{G}))\}.$$

It follows directly from the above proof and the previous section that

<span id="page-8-3"></span>**Corollary 2.13.** If  $gap(\mathcal{F}, \mathcal{G}) < 1$  or if the subspaces are in generic position then both terms under the minimum are the same and so  $gap(\mathcal{F}, \mathcal{G}) = max\{sin(\Theta(\mathcal{F}, \mathcal{G}))\}$ .

Let  $c(\mathcal{F}, \mathcal{G}) = \sup\{|(f, g)| : f \in \mathcal{F} \ominus (\mathcal{F} \cap \mathcal{G}), ||f|| \le 1, g \in \mathcal{G} \ominus (\mathcal{F} \cap \mathcal{G}), ||g|| \le 1\}$ , as in [8], which is a definition of the cosine of the *angle of Friedrichs*.

<span id="page-8-2"></span>**Theorem 2.14.** *In terms of the angles,*  $c(\mathcal{F}, \mathcal{G}) = \cos\left(\inf\{\Theta(\mathcal{F}, \mathcal{G}) \setminus \{0\}\}\right)$ .

*Proof.* Replacing the vectors  $f = P_{\mathcal{F}}u$  and  $g = P_{\mathcal{G}}v$  in the definition of  $c(\mathcal{F}, \mathcal{G})$  with the vectors u and v and using the standard equality of induced norms of an operator and the corresponding bilinear form, we get

$$c(\mathcal{F},\mathcal{G}) = \sup_{\substack{u \in \mathcal{H} \ominus \mathfrak{M}_{00} \\ ||u|| = 1}} \sup_{\substack{v \in \mathcal{H} \ominus \mathfrak{M}_{00} \\ ||v|| = 1}} |(u, P_{\mathcal{F}} P_{\mathcal{G}} v)| = ||(P_{\mathcal{F}} P_{\mathcal{G}})|_{\mathcal{H} \ominus \mathfrak{M}_{00}}||.$$

Using the five-parts decomposition,  $P_{\mathcal{F}}P_{\mathcal{G}} = I_{\mathfrak{M}_{00}} \oplus 0_{\mathfrak{M}_{01}} \oplus 0_{\mathfrak{M}_{10}} \oplus 0_{\mathfrak{M}_{11}} \oplus (P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathfrak{M}}$ , thus "subtracting" the subspace  $\mathfrak{M}_{00}$  from the domain of  $P_{\mathcal{F}}P_{\mathcal{G}}$  excludes 1 from the point spectrum of  $P_{\mathcal{F}}P_{\mathcal{G}}$ , and, thus, 0 from the set of point angles from  $\mathcal{F}$  to  $\mathcal{G}$  and, by Theorem 2.6(2), from the set of point angles between  $\mathcal{F}$  and  $\mathcal{G}$ .

Let the minimum gap, see [19, § IV.4], be defined as

$$\gamma(\mathcal{F},\mathcal{G}) = \inf_{f \in \mathcal{F}, f \notin \mathcal{G}} \frac{\mathrm{dist}(f,\mathcal{G})}{\mathrm{dist}(f,\mathcal{F} \cap \mathcal{G})}.$$

<span id="page-8-1"></span>**Theorem 2.15.** In terms of the angles,  $\gamma(\mathcal{F}, \mathcal{G}) = \sin(\inf\{\Theta(\mathcal{F}, \mathcal{G}) \setminus \{0\}\})$ .

*Proof.* We have  $f \in \mathcal{F}$  and  $f \notin \mathcal{G}$ , so we can represent f in the form  $f = f_1 + f_2$ , where  $f_1 \in \mathcal{F} \ominus (\mathcal{F} \cap \mathcal{G})$ ,  $f_1 \neq 0$  and  $f_2 \in \mathcal{F} \cap \mathcal{G}$ . Then

$$\gamma(\mathcal{F}, \mathcal{G}) = \inf_{f \in \mathcal{F}, f \notin \mathcal{G}} \frac{\operatorname{dist}(f, \mathcal{G})}{\operatorname{dist}(f, \mathcal{F} \cap \mathcal{G})} \\
= \inf_{f_1 \in \mathcal{F} \in (\mathcal{F} \cap \mathcal{G}), f_2 \in \mathcal{F} \cap \mathcal{G}} \frac{\|f_1 + f_2 - P_{\mathcal{G}} f_1 - P_{\mathcal{G}} f_2\|}{\|f_1 + f_2 - P_{\mathcal{F} \cap \mathcal{G}} f_1 - P_{\mathcal{F} \cap \mathcal{G}} f_2\|} \\
= \inf_{f_1 \in \mathcal{F} \in (\mathcal{F} \cap \mathcal{G})} \frac{\|f_1 - P_{\mathcal{G}} f_1\|}{\|f_1 - P_{\mathcal{F} \cap \mathcal{G}} f_1\|} \\
= \inf_{f \in \mathcal{F} \in (\mathcal{F} \cap \mathcal{G})} \frac{\|f - P_{\mathcal{G}} f_1\|}{\|f - P_{\mathcal{F} \cap \mathcal{G}} f_1\|}.$$

But  $f \in (\mathcal{F} \cap \mathcal{G})^{\perp}$  and  $||f - P_{\mathcal{F} \cap \mathcal{G}}f|| = ||f||$ . Since  $||\kappa f - P_{\mathcal{G}}(\kappa f)|| = |\kappa|||f - P_{\mathcal{G}}f||$ , using the Pythagorean theorem we have

$$\gamma^{2}(\mathcal{F}, \mathcal{G}) = \inf_{f \in \mathcal{F} \ominus (\mathcal{F} \cap \mathcal{G}), } \frac{\|f - P_{\mathcal{G}}f\|^{2}}{\|f\|^{2}}$$

$$= \inf_{f \in \mathcal{F} \ominus (\mathcal{F} \cap \mathcal{G}), \|f\|=1} \|f - P_{\mathcal{G}}f\|^{2}$$

$$= \inf_{f \in \mathcal{F} \ominus (\mathcal{F} \cap \mathcal{G}), \|f\|=1} 1 - \|P_{\mathcal{G}}f\|^{2}.$$

Using the equality  $||P_{\mathcal{G}}f|| = \sup_{g \in \mathcal{G}, ||g||=1} |(f, g)|$  we get

$$\gamma^{2}(\mathcal{F}, \mathcal{G}) = 1 - \sup_{f \in \mathcal{F} \ominus (\mathcal{F} \cap \mathcal{G}), g \in \mathcal{G}, ||f|| = ||g|| = 1} |(f, g)|^{2}$$
$$= 1 - (c(\mathcal{F}, \mathcal{G}))^{2}$$

and finally we use Theorem 2.14.

Let us note that removing 0 from the set of angles in Theorems 2.14 and 2.15 changes the result after taking the inf, only if 0 is present as an isolated value in the set of angles, e.g., it has no effect for a pair of subspaces in generic position.

### 2.4. The Spectra of Sum and Difference of Orthogonal Projectors

Sums and differences of a pair of orthogonal projectors often appear in applications. Here, we describe their spectra in terms of the angles between the ranges of the projectors, which provides a geometrically intuitive and uniform framework to analyze the sums and differences of orthogonal projectors. First, we connect the spectra of the product and of the difference of two orthogonal projectors.

<span id="page-9-0"></span>**Lemma 2.16.** ([30, Theorem 1], [28, Lemma 2.4]). For proper subspaces  $\mathcal{F}$  and  $\mathcal{G}$  we have  $\Sigma(P_{\mathcal{F}}P_{\mathcal{G}}) = \Sigma(P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}) \subseteq [0,1]$  and

$$\Sigma(P_G - P_{\mathcal{F}}) \setminus (\{-1\} \cup \{0\} \cup \{1\}) = \{\pm (1 - \sigma^2)^{1/2} : \sigma^2 \in \Sigma(P_{\mathcal{F}}P_G) \setminus (\{0\} \cup \{1\})\}.$$

Using Lemma 2.16, we now characterize the spectrum of the differences of two orthogonal projectors in terms of the angles between the corresponding subspaces.

**Theorem 2.17.** The multiplicity of the eigenvalue 1 in  $\Sigma(P_{\mathcal{G}} - P_{\mathcal{T}})$  is equal to dim  $\mathfrak{M}_{10}$ , the multiplicity of the eigenvalue -1 is equal to dim  $\mathfrak{M}_{01}$ , and the multiplicity of the eigenvalue 0 is equal to dim  $\mathfrak{M}_{00}$  + dim  $\mathfrak{M}_{11}$ , where  $\mathfrak{M}_{00}$ ,  $\mathfrak{M}_{01}$ ,  $\mathfrak{M}_{10}$  and  $\mathfrak{M}_{11}$  are defined in § 2.1. For the rest of the spectrum, we have the following:

$$\Sigma(P_{\mathcal{F}} - P_{\mathcal{G}}) \setminus (\{-1\} \cup \{0\} \cup \{1\}) = \pm \sin(\Theta(\mathcal{F}, \mathcal{G})) \setminus (\{-1\} \cup \{0\} \cup \{1\}).$$

*Proof.* The last statement follows from Lemma 2.16 and Definition 2.4. To obtain the results concerning the multiplicity of eigenvalues 1, -1 and 0, it suffices to use the decomposition of these projectors into five parts, given in § 2.1.

In some applications, e.g., in domain decomposition methods, see §6, the distribution of the spectrum of the sum of projectors is important. We directly reformulate [3, Corollary 4.9, p. 86], see also [33, p. 298], in terms of the angles between subspaces:

<span id="page-10-2"></span>**Theorem 2.18.** For any nontrivial pair of orthogonal projectors  $P_{\mathcal{F}}$  and  $P_{\mathcal{G}}$  on  $\mathcal{H}$  the spectrum of the sum  $P_{\mathcal{F}} + P_{\mathcal{G}}$ , with the possible exception of the point 0, lies in the closed interval of the real line  $[1 - ||P_{\mathcal{F}}P_{\mathcal{G}}||, 1 + ||P_{\mathcal{F}}P_{\mathcal{G}}||]$ , and the following identity holds:

$$\Sigma(P_{\mathcal{F}} + P_{\mathcal{G}}) \setminus (\{0\} \cup \{1\}) = \{1 \pm \cos(\Theta(\mathcal{F}, \mathcal{G}))\} \setminus (\{0\} \cup \{1\}).$$

#### <span id="page-10-0"></span>3. Principal Vectors, Subspaces and Invariant Subspaces

In this section, we basically follow Jujunashvili [18, Section 2.8] to introduce principal invariant subspaces for a pair of subspaces by analogy with invariant subspaces of operators. Given the principal invariant subspaces (see Definition 3.1 below) of a pair of subspaces  $\mathcal{F}$  and  $\mathcal{G}$ , we construct the principal invariant subspaces for pairs  $\mathcal{F}$  and  $\mathcal{G}^{\perp}$ ,  $\mathcal{F}^{\perp}$  and  $\mathcal{G}^{\perp}$ . We describe relations between orthogonal projectors onto principal invariant subspaces. We show that, in particular cases, principal subspaces and principal vectors can be defined essentially as in the finite dimensional case, and we investigate their properties. Principal vectors, subspaces and principal invariant subspaces reveal the fine structure of the mutual position of a pair of subspaces in a Hilbert space. Except for Theorem 3.3, all other statements can be found in [18, sections 2.6-2.9], which we refer the reader to for detailed proofs and more facts.

### 3.1. Principal Invariant Subspaces

Principal invariant subspaces for a pair of subspaces generalize the already known notion of principal vectors, e.g., [35]. We give a geometrically intuitive definition of principal invariant subspaces and connect them with invariant subspaces of the product of the orthogonal projectors.

<span id="page-10-1"></span>**Definition 3.1.** A pair of subspaces  $\mathcal{U} \subseteq \mathcal{F}$  and  $\mathcal{V} \subseteq \mathcal{G}$  is called a pair of principal invariant subspaces for the subspaces  $\mathcal{F}$  and  $\mathcal{G}$ , if  $P_{\mathcal{F}}\mathcal{V} \subseteq \mathcal{U}$  and  $P_{\mathcal{G}}\mathcal{U} \subseteq \mathcal{V}$ . We call the pair  $\mathcal{U} \subseteq \mathcal{F}$  and  $\mathcal{V} \subseteq \mathcal{G}$  nondegenerate if  $P_{\mathcal{F}}\mathcal{V} = \mathcal{U} \neq \{0\}$  and  $P_{\mathcal{G}}\mathcal{U} = \mathcal{V} \neq \{0\}$  and strictly nondegenerate if  $P_{\mathcal{F}}\mathcal{V} = \mathcal{U} \neq \{0\}$  and  $P_{\mathcal{G}}\mathcal{U} = \mathcal{V} \neq \{0\}$ .

This definition is different from that used in [18, Section 2.8, p. 57], where only what we call here strictly nondegenerate principal invariant subspaces are defined.

The following simple theorem deals with enclosed principal invariant subspaces.

**Theorem 3.2.** Let  $\mathcal{U} \subset \mathcal{F}$  and  $\mathcal{V} \subset \mathcal{G}$  be a pair of principal invariant subspaces for subspaces  $\mathcal{F}$  and  $\mathcal{G}$ , and  $\underline{\mathcal{U}} \subset \mathcal{U}$ ,  $\underline{\mathcal{V}} \subset \mathcal{V}$  be a pair of principal invariant subspaces for subspaces  $\mathcal{U}$  and  $\mathcal{V}$ . Then  $\underline{\mathcal{U}}$ ,  $\underline{\mathcal{V}}$  form a pair of principal invariant subspaces for the subspaces  $\mathcal{F}$ ,  $\mathcal{G}$ , and  $\Theta(\mathcal{U}, \mathcal{V}) \subseteq \Theta(\mathcal{F}, \mathcal{G})$ .

Definition 3.1 resembles the notion of invariant subspaces. The next theorem completely clarifies this connection for general principal invariant subspaces.

<span id="page-11-0"></span>**Theorem 3.3.** The subspaces  $\mathcal{U} \subseteq \mathcal{F}$  and  $\mathcal{V} \subseteq \mathcal{G}$  form a pair of principal invariant subspaces for the subspaces  $\mathcal{F}$  and  $\mathcal{G}$  if and only if  $\mathcal{U} \subseteq \mathcal{F}$  is an invariant subspace of the operator  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}}$  and  $\mathcal{V} = \overline{P_{\mathcal{G}}\mathcal{U}} \oplus \mathcal{V}_0$ , where  $\mathcal{V}_0 \subseteq \mathfrak{M}_{10} = \mathcal{G} \cap \mathcal{F}^{\perp}$ .

*Proof.* Conditions  $P_{\mathcal{F}}\mathcal{V} \subseteq \mathcal{U}$  and  $P_{\mathcal{G}}\mathcal{U} \subseteq \mathcal{V}$  imply  $P_{\mathcal{F}}P_{\mathcal{G}}\mathcal{U} \subseteq P_{\mathcal{F}}\mathcal{V} \subseteq \mathcal{U}$ . Let us consider  $v_0 \in \mathcal{V} \ominus \overline{P_{\mathcal{G}}\mathcal{U}} = \mathcal{V} \cap \mathcal{U}^{\perp}$  (the latter equality follows from  $0 = (v_0, P_{\mathcal{G}}u) = (v_0, u), \forall u \in \mathcal{U}$ ). We have  $P_{\mathcal{F}}v_0 \in \mathcal{U}^{\perp}$  since  $\mathcal{U} \subseteq \mathcal{F}$ , but our assumption  $P_{\mathcal{F}}\mathcal{V} \subseteq \mathcal{U}$  assures that  $P_{\mathcal{F}}v_0 \in \mathcal{U}$ , so  $P_{\mathcal{F}}v_0 = 0$ , which means that  $\mathcal{V}_0 \subseteq \mathfrak{M}_{10}$ , as required.

To prove the converse, let  $P_{\mathcal{F}}P_{\mathcal{G}}\mathcal{U} \subseteq \mathcal{U}$  and  $\mathcal{V} = \overline{P_{\mathcal{G}}\mathcal{U}} \oplus \mathcal{V}_0$ . Then  $P_{\mathcal{F}}\mathcal{V} = P_{\mathcal{F}}\overline{P_{\mathcal{G}}\mathcal{U}} \subseteq \mathcal{U}$  since  $\mathcal{U}$  is closed.  $P_{\mathcal{G}}\mathcal{U} \subseteq \mathcal{V}$  follows from the formula for  $\mathcal{V}$ .

If the subspace  $\mathfrak{M}_{10}$  is trivial, the principal invariant subspace  $\mathcal V$  that corresponds to  $\mathcal U$  is clearly unique. The corresponding statement for  $\mathcal U$ , given  $\mathcal V$ , we get from Theorem 3.3 by swapping  $\mathcal F$  and  $\mathcal G$ . We now completely characterize (strictly) nondegenerate principal invariant subspaces using the corresponding angles.

<span id="page-11-1"></span>**Theorem 3.4.** The pair  $\mathcal{U} \subseteq \mathcal{F}$  and  $\mathcal{V} \subseteq \mathcal{G}$  of principal invariant subspaces for the subspaces  $\mathcal{F}$  and  $\mathcal{G}$  is nondegenerate if and only if both operators  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{U}}$  and  $(P_{\mathcal{G}}P_{\mathcal{F}})|_{\mathcal{V}}$  are invertible, i.e.,  $\pi/2 \notin \hat{\Theta}_p(\mathcal{U},\mathcal{V}) \cup \hat{\Theta}_p(\mathcal{V},\mathcal{U})$ , and strictly nondegenerate if and only if each of the inverses is bounded, i.e.,  $\pi/2 \notin \hat{\Theta}(\mathcal{U},\mathcal{V}) \cup \hat{\Theta}(\mathcal{V},\mathcal{U})$ , or equivalently in terms of the gap,  $\operatorname{gap}(\mathcal{U},\mathcal{V}) = \|P_{\mathcal{U}} - P_{\mathcal{V}}\| < 1$ .

*Proof.* We prove the claim for the operator  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{U}}$ , and the claim for the other operator follows by symmetry. Definition 3.1 uses  $\overline{P_{\mathcal{F}}\mathcal{V}} = \mathcal{U} \neq \{0\}$  for nondegenerate principal invariant subspaces. At the same time, Theorem 3.3 holds, so  $\mathcal{V} = \overline{P_{\mathcal{G}}\mathcal{U}} \oplus \mathcal{V}_0$ , where  $\mathcal{V}_0 \subseteq \mathfrak{M}_{10} = \mathcal{G} \cap \mathcal{F}^{\perp}$ . So  $\mathcal{U} = \overline{P_{\mathcal{F}}\mathcal{V}} = \overline{P_{\mathcal{F}}P_{\mathcal{G}}\mathcal{U}}$ . Also by Theorem 3.3,  $\mathcal{U} \subseteq \mathcal{F}$  is an invariant subspace of the operator  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}}$ , so  $\mathcal{U} = \overline{P_{\mathcal{F}}P_{\mathcal{G}}\mathcal{U}} = \overline{(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{U}}\mathcal{U}}$ . Since  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{U}}$  is Hermitian, its null-space is trivial (as the orthogonal in  $\mathcal{U}$  complement to its range which is dense in  $\mathcal{U}$ ), i.e., the operator  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{U}}$  is one-to-one and thus invertible. For strictly nondegenerate principal invariant subspaces,  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{U}}\mathcal{U} = \mathcal{U}$ , so the operator  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{U}}$  by the open mapping theorem has a continuous and thus bounded inverse.

Conversely, by Theorem 3.3  $\mathcal{U} \subseteq \mathcal{F}$  is an invariant subspace of the operator  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{U}}$  is correctly defined. The operator  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{U}}$  is invertible by assumption, thus its null-space is trivial, and so its range is dense:  $\mathcal{U} = \overline{(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{U}}}\mathcal{U}} = \overline{P_{\mathcal{F}}P_{\mathcal{G}}\mathcal{U}}$ . By Theorem 3.3,  $\mathcal{V} = \overline{P_{\mathcal{G}}\mathcal{U}} \oplus \mathcal{V}_0$ , therefore  $\overline{P_{\mathcal{F}}\mathcal{V}} = \overline{P_{\mathcal{F}}P_{\mathcal{G}}\mathcal{U}} = \mathcal{U}$ . The other equality,  $\overline{P_{\mathcal{G}}\mathcal{U}} = \mathcal{V} \neq \{0\}$ , of Definition 3.1 for nondegenerate principal invariant subspaces, is proved similarly using the assumption that  $(P_{\mathcal{G}}P_{\mathcal{F}})|_{\mathcal{G}}$  is invertible. If, in addition, each of the inverses is bounded, the corresponding ranges are closed,  $\mathcal{U} = P_{\mathcal{F}}P_{\mathcal{G}}\mathcal{U}$  and  $\mathcal{V} = P_{\mathcal{F}}P_{\mathcal{G}}\mathcal{V}$  and we obtain  $P_{\mathcal{F}}\mathcal{V} = \mathcal{U} \neq \{0\}$  and  $P_{\mathcal{G}}\mathcal{U} = \mathcal{V} \neq \{0\}$  as is needed in Definition 3.1 for strictly nondegenerate principal invariant subspaces.

The equivalent formulations of conditions of the theorem in terms of the angles and the gap follow directly from Definitions 2.4 and 2.5 and Theorem 2.12.

Theorem 2.2 introduces the unitary operator W that gives the unitary equivalence of  $P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}$  and  $P_{\mathcal{G}}P_{\mathcal{F}}P_{\mathcal{G}}$  and, if  $\mathrm{gap}(\mathcal{F},\mathcal{G})<1$ , the unitary equivalence by (2.1) of  $P_{\mathcal{F}}$  and  $P_{\mathcal{G}}$ . Now we state that the same W makes orthogonal projectors  $P_{\mathcal{U}}$  and  $P_{\mathcal{V}}$  unitarily equivalent for strictly nondegenerate principal invariant subspaces  $\mathcal{U}\subset\mathcal{F}$  and  $\mathcal{V}\subset\mathcal{G}$ , and we obtain expressions for the orthogonal projectors.

<span id="page-12-0"></span>**Theorem 3.5.** Let  $\mathcal{U} \subseteq \mathcal{F}$  and  $\mathcal{V} \subseteq \mathcal{G}$  be a pair of strictly nondegenerate principal invariant subspaces for the subspaces  $\mathcal{F}$  and  $\mathcal{G}$ , and  $\mathcal{W}$  be defined as in Theorem 2.2. Then  $\mathcal{V} = \mathcal{W}\mathcal{U}$  and  $\mathcal{U} = \mathcal{W}^*\mathcal{V}$ , while the orthoprojectors satisfy  $P_{\mathcal{V}} = \mathcal{W}P_{\mathcal{U}}\mathcal{W}^* = P_{\mathcal{G}}P_{\mathcal{U}}((P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{U}})^{-1}P_{\mathcal{U}}P_{\mathcal{G}}$  and  $P_{\mathcal{U}} = \mathcal{W}^*P_{\mathcal{V}}\mathcal{W} = P_{\mathcal{F}}P_{\mathcal{V}}((P_{\mathcal{G}}P_{\mathcal{F}})|_{\mathcal{V}})^{-1}P_{\mathcal{V}}P_{\mathcal{F}}$ .

The proof of Theorem 3.5 is straightforward and can be found in [18, §2.8]. Jujunashvili [18, §2.9] also develops the theory of principal invariant subspaces, using the spectral decompositions, e.g., below is [18, Theorem 2.108]:

**Theorem 3.6.** Let  $\{E_1\}$  and  $\{E_2\}$  be spectral measures of the operators  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}}$  and  $(P_{\mathcal{G}}P_{\mathcal{F}})|_{\mathcal{G}}$ , respectively. Let  $\Theta \subseteq \Theta(\mathcal{U},\mathcal{V}) \setminus \{\pi/2\}$  be a closed Borel set, and define  $P_{\mathcal{U}(\Theta)} = \int_{\cos(\Theta)} dE_1(\lambda)$  and  $P_{\mathcal{V}(\Theta)} = \int_{\cos(\Theta)} dE_2(\lambda)$ . Then  $\mathcal{U}(\Theta) \subset \mathcal{F}$  and  $\mathcal{V}(\Theta) \subset \mathcal{G}$  is a pair of strictly nondegenerate principal invariant subspaces and

$$P_{\mathcal{V}(\Theta)} = P_{\mathcal{G}} \left\{ \int_{\cos(\Theta)} \frac{1}{\lambda} dE_1(\lambda) \right\} P_{\mathcal{G}},$$

and  $\Theta = \hat{\Theta}(\mathcal{U}(\Theta), \mathcal{V}(\Theta)) = \hat{\Theta}(\mathcal{V}(\Theta), \mathcal{U}(\Theta)).$ 

*Proof.* We have  $\int_{\cos(\Theta)} \frac{1}{\lambda} dE_1(\lambda) = ((P_{\mathcal{F}}P_{\mathcal{U}})|_{\mathcal{U}})^{-1} = P_{\mathcal{U}} ((P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{U}})^{-1} P_{\mathcal{U}}$  (where we denote  $\mathcal{U} = \mathcal{U}(\Theta)$ ), which we plug into the expression for the orthogonal projector  $P_{\mathcal{V}}$  of Theorem 3.5.

For a pair of principal invariant subspaces  $\mathcal{U} \subset \mathcal{F}$  and  $\mathcal{V} \subset \mathcal{G}$ , using Theorems 3.3 and 3.4 we define the corresponding principal invariant subspaces in  $\mathcal{F}^{\perp}$  and  $\mathcal{G}^{\perp}$  as  $\mathcal{U}_{\perp} = P_{\mathcal{F}^{\perp}}\mathcal{V}$  and  $\mathcal{V}_{\perp} = P_{\mathcal{G}^{\perp}}\mathcal{U}$ , and describe their properties in the next theorem.

<span id="page-12-1"></span>**Theorem 3.7.** Let  $\mathcal{U}$  and  $\mathcal{V}$  be a pair of principal invariant subspaces for subspaces  $\mathcal{F}$  and  $\mathcal{G}$  and  $0, \pi/2 \notin \hat{\Theta}(\mathcal{U}, \mathcal{V}) \cup \hat{\Theta}(\mathcal{V}, \mathcal{U})$ . Then  $\mathcal{U}_{\perp} = P_{\mathcal{F}^{\perp}}\mathcal{V}$  and  $\mathcal{V}_{\perp} = P_{\mathcal{G}^{\perp}}\mathcal{U}$  are closed and

- $\mathcal{U}$  and  $\mathcal{V}$  is a pair of strictly nondegenerate principal invariant subspaces for subspaces  $\mathcal{F}$  and  $\mathcal{G}$ ;
- $\mathcal{U}_{\perp}$  and  $\mathcal{V}$  is a pair of strictly nondegenerate principal invariant subspaces for subspaces  $\mathcal{F}^{\perp}$  and  $\mathcal{G}$  and  $P_{\mathcal{U}_{\perp}}$  and  $P_{\mathcal{V}}$  are unitarily equivalent;
- $\mathcal{U}$  and  $\mathcal{V}_{\perp}$  is a pair of strictly nondegenerate principal invariant subspaces for subspaces  $\mathcal{F}$  and  $\mathcal{G}^{\perp}$  and  $\mathcal{P}_{\mathcal{U}}$  and  $\mathcal{P}_{\mathcal{V}_{\perp}}$  are unitarily equivalent;
- $\mathcal{U}_{\perp}$  and  $\mathcal{V}_{\perp}$  is a pair of strictly nondegenerate principal invariant subspaces for subspaces  $\mathcal{F}^{\perp}$  and  $\mathcal{G}^{\perp}$  and  $P_{\mathcal{U}_{\perp}}$  and  $P_{\mathcal{V}_{\perp}}$  are unitarily equivalent.

*Proof.* The statements follow directly from Theorems 3.3 and 3.4 applied to the corresponding pairs of subspaces. The closedness of  $\mathcal{U}_{\perp}$  and  $\mathcal{V}_{\perp}$  can be alternatively derived from Theorem 2.14 and [8, Theorem 22].

## 3.2. Principal Subspaces and Principal Vectors

For a pair of principal invariant subspaces  $\mathcal{U} \subset \mathcal{F}$  and  $\mathcal{V} \subset \mathcal{G}$ , if the spectrum  $\Sigma((P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{U}})$  consists of one number, which belongs to (0,1] and which we denote by  $\cos^2(\theta)$ , we can use Theorem 3.5 to define a pair of principal subspaces corresponding to an angle  $\theta$ :

<span id="page-13-0"></span>**Definition 3.8.** Let  $\theta \in \Theta(\mathcal{F}, \mathcal{G}) \setminus \{\pi/2\}$ . Nontrivial subspaces  $\mathcal{U} \subseteq \mathcal{F}$  and  $\mathcal{V} \subseteq \mathcal{G}$  define a pair of principal subspaces for subspaces  $\mathcal{F}$  and  $\mathcal{G}$  corresponding to the angle  $\theta$  if  $(P_{\mathcal{F}}P_{\mathcal{V}})|_{\mathcal{F}} = \cos^2(\theta)P_{\mathcal{U}}$  and  $(P_{\mathcal{G}}P_{\mathcal{U}})|_{\mathcal{G}} = \cos^2(\theta)P_{\mathcal{V}}$ . Normalized vectors  $u = u(\theta) \in \mathcal{F}$  and  $v = v(\theta) \in \mathcal{G}$  form a pair of principal vectors for subspaces  $\mathcal{F}$  and  $\mathcal{G}$  corresponding to the angle  $\theta$  if  $P_{\mathcal{F}}v = \cos(\theta)u$  and  $P_{\mathcal{G}}u = \cos(\theta)v$ .

We exclude  $\theta = \pi/2$  in Definition 3.8 so that principal subspaces belong to the class of strictly nondegenerate principal invariant subspaces. We describe the main properties of principal subspaces and principal vectors that can be checked directly (for details, see [18]). The first property characterizes principal subspaces as eigenspaces of the products of the corresponding projectors.

**Theorem 3.9.** Subspaces  $\mathcal{U} \subset \mathcal{F}$  and  $\mathcal{V} \subset \mathcal{G}$  form a pair of principal subspaces for subspaces  $\mathcal{F}$  and  $\mathcal{G}$  corresponding to the angle  $\theta \in \Theta(\mathcal{F}, \mathcal{G}) \setminus \{\pi/2\}$  if and only if  $\theta \in \Theta_p(\mathcal{F}, \mathcal{G}) \setminus \{\pi/2\}$  and  $\mathcal{U}$  and  $\mathcal{V}$  are the eigenspaces of the operators  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}}$  and  $(P_{\mathcal{G}}P_{\mathcal{F}})|_{\mathcal{G}}$ , respectively, corresponding to the eigenvalue  $\cos^2(\theta)$ . In such a case,  $\Theta(\mathcal{U}, \mathcal{V}) = \Theta_p(\mathcal{U}, \mathcal{V}) = \{\theta\}$ . All pairs of principal vectors u and v of subspaces  $\mathcal{F}$  and  $\mathcal{G}$  corresponding to the angle  $\theta$  generate the largest principal subspaces  $\mathcal{U}$  and  $\mathcal{V}$  corresponding to the angle  $\theta$ .

**Theorem 3.10.** Let  $\mathcal{U}(\theta)$ ,  $\mathcal{U}(\phi) \subset \mathcal{F}$ , and  $\mathcal{V}(\theta)$ ,  $\mathcal{V}(\phi) \subset \mathcal{G}$  be the principal subspaces for subspaces  $\mathcal{F}$  and  $\mathcal{G}$  corresponding to the angles  $\theta, \phi \in \Theta_p(\mathcal{F}, \mathcal{G}) \setminus \{\pi/2\}$ . Then  $P_{\mathcal{U}(\theta)}P_{\mathcal{U}(\phi)} = P_{\mathcal{U}(\theta)\cap\mathcal{V}(\phi)}$ ;  $P_{\mathcal{U}(\theta)}$  and  $P_{\mathcal{V}(\phi)}$  are mutually orthogonal if  $\theta \neq \phi$  (if  $\theta = \phi$  we can choose  $\mathcal{V}(\theta)$  such that  $P_{\mathcal{U}(\theta)}P_{\mathcal{V}(\theta)} = P_{\mathcal{U}(\theta)}P_{\mathcal{G}}$ ); for given  $\mathcal{U}(\theta)$  we can choose  $\mathcal{V}(\theta)$  such that  $P_{\mathcal{V}(\theta)}P_{\mathcal{U}(\theta)} = P_{\mathcal{V}(\theta)}P_{\mathcal{F}}$ .

**Corollary 3.11.** [of Theorem 3.7] Let  $\mathcal{U}$  and  $\mathcal{V}$  be the principal subspaces for subspaces  $\mathcal{F}$  and  $\mathcal{G}$ , corresponding to the angle  $\theta \in \Theta_p(\mathcal{F},\mathcal{G}) \setminus (\{0\} \cup \{\pi/2\})$ . Then  $\mathcal{U}_{\perp} = P_{\mathcal{F}^{\perp}}\mathcal{V}$  and  $\mathcal{V}_{\perp} = P_{\mathcal{G}^{\perp}}\mathcal{U}$  are closed and

- $\mathcal{U}_{\perp}$ , V are the principal subspaces for subspaces  $\mathcal{F}^{\perp}$  and  $\mathcal{G}$ , corresponding to the angle  $\pi/2 \theta$ ;
- $\mathcal{U}$ ,  $\mathcal{V}_{\perp}$  are the principal subspaces for subspaces  $\mathcal{F}$  and  $\mathcal{G}^{\perp}$ , corresponding to the angle  $\pi/2 \theta$ :
- $\mathcal{U}_{\perp}$ ,  $\mathcal{V}_{\perp}$  are the principal subspaces for subspaces  $\mathcal{F}^{\perp}$  and  $\mathcal{G}^{\perp}$ , corresponding to the angle  $\theta$ .

Let u and v form a pair of principal vectors for the subspaces  $\mathcal{F}$  and  $\mathcal{G}$ , corresponding to the angle  $\theta$ . Then  $u_{\perp} = (v - \cos(\theta)u)/\sin(\theta)$  and  $v_{\perp} = (u - \cos(\theta)v)/\sin(\theta)$  together with u and v describe the pairs of principal vectors.

## <span id="page-14-0"></span>4. Bounding the Changes in the Angles

Here we prove bounds on the change in the (squared cosines of the) angles from one subspace to another where the subspaces change. These bounds allow one to estimate the sensitivity of the angles with respect to the changes in the subspaces. For the finite dimensional case, such bounds are known, e.g., [23, 24]. To measure the distance between two bounded real sets  $S_1$  and  $S_2$  we use the Hausdorff distance, e.g., [19],  $\operatorname{dist}(S_1, S_2) = \max\{\sup_{u \in S_1} \operatorname{dist}(u, S_2), \sup_{v \in S_2} \operatorname{dist}(v, S_1)\}$ , where  $\operatorname{dist}(u, S) = \inf_{v \in S} |u - v|$  is the distance from the point u to the set S. The following theorem estimates the proximity of the set of squares of cosines of  $\hat{\Theta}(\mathcal{F}, \mathcal{G})$  and the set of squares of cosines of  $\hat{\Theta}(\mathcal{F}, \mathcal{G})$ , where  $\mathcal{F}, \mathcal{G}$  and  $\tilde{\mathcal{G}}$  are nontrivial subspaces of  $\mathcal{H}$ .

**Theorem 4.1.** dist( $\cos^2(\hat{\Theta}(\mathcal{F},\mathcal{G})), \cos^2(\hat{\Theta}(\mathcal{F},\tilde{\mathcal{G}}))$ )  $\leq \operatorname{gap}(\mathcal{G},\tilde{\mathcal{G}}).$ 

*Proof.*  $\cos^2(\hat{\Theta}(\mathcal{F},\mathcal{G})) = \Sigma((P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}})$  and  $\cos^2(\hat{\Theta}(\mathcal{F},\tilde{\mathcal{G}})) = \Sigma((P_{\mathcal{F}}P_{\tilde{\mathcal{G}}})|_{\mathcal{F}})$  by Definition 2.4. Both operators  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}}$  and  $(P_{\mathcal{F}}P_{\tilde{\mathcal{G}}})|_{\mathcal{F}}$  are selfadjoint. By [19, Theorem 4.10, p. 291],

$$\operatorname{dist}(\Sigma((P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}}),\Sigma((P_{\mathcal{F}}P_{\tilde{\mathcal{G}}})|_{\mathcal{F}})) \leq ||(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}} - (P_{\mathcal{F}}P_{\tilde{\mathcal{G}}})|_{\mathcal{F}}||.$$

Then, 
$$\|(P_{\mathcal{T}}P_G)|_{\mathcal{T}} - (P_{\mathcal{T}}P_{\tilde{G}})|_{\mathcal{T}}\| \le \|P_{\mathcal{T}}\|\|P_G - P_{\tilde{G}}\|\|P_{\mathcal{T}}\| \le \operatorname{gap}(G, \tilde{G}).$$

The same result holds also if the first subspace,  $\mathcal{F}$ , is changed in  $\hat{\Theta}(\mathcal{F},\mathcal{G})$ :

**Theorem 4.2.** dist(
$$\cos^2(\hat{\Theta}(\mathcal{F},\mathcal{G}))$$
,  $\cos^2(\hat{\Theta}(\tilde{\mathcal{F}},\mathcal{G}))) \leq \text{gap}(\mathcal{F},\tilde{\mathcal{F}})$ .

*Proof.* The statement of the theorem immediately follows from Theorem 5.2, which is independently proved in the next section, where one takes  $A = P_G$ .

We conjecture that similar generalizations to the case of infinite dimensional subspaces can be made for bounds involving changes in the sines and cosines (without squares) of the angles extending known bounds [23, 24] for the finite dimensional case.

## <span id="page-14-1"></span>5. Changes in the Ritz Values and Rayleigh-Ritz error bounds

Here we estimate how Ritz values of a selfadjoint operator change with the change of a vector, and then we extend this result to estimate the change of Ritz values with the change of a (infinite dimensional) trial subspace, using the gap between subspaces,  $\text{gap}(\mathcal{F},\mathcal{G}) = \|P_{\mathcal{F}} - P_{\mathcal{G}}\|$ . Such results are natural extensions of the results of the previous section that bound the change in the squared cosines or sines of the angles, since in the particular case where the selfadjoint operator is an orthogonal projector its Ritz values are exactly the squared cosines of the angles from the trial subspace of the Rayleigh-Ritz method to the range of the orthogonal projector. In addition, we prove a spectrum error bound that characterizes the change in the Ritz values for an invariant subspace, and naturally involves the gap squared; see [27, 1, 26] for similar finite dimensional results.

Let  $A \in \mathcal{B}(\mathcal{H})$  be a selfadjoint operator. Denote by  $\lambda(f) = (f,Af)/(f,f)$  the Rayleigh quotient of an operator A at a vector  $f \neq 0$ . In the following lemma, we estimate changes in the Rayleigh quotient with the change in a vector. This estimate has been previously proven only for real finite dimensional spaces [24]. Here, we give a new proof that works both for real and complex spaces.

<span id="page-15-1"></span>**Lemma 5.1.** Let  $A \in \mathcal{B}(\mathcal{H})$  be a selfadjoint operator on a Hilbert space  $\mathcal{H}$  and  $f, g \in \mathcal{H}$  with  $f, g \neq 0$ . Then

$$|\lambda(f) - \lambda(g)| \le (\max\{\Sigma(A)\} - \min\{\Sigma(A)\}) \sin(\theta(f, g)). \tag{5.1}$$

*Proof.* We use the so-called "mini-dimensional" analysis, e.g., [20, 21]. Let  $S = \text{span}\{f, g\} \subset \mathcal{H}$  be a two dimensional subspace (if f and g are linearly dependent then the Rayleigh quotients are the same and the assertion is trivial). Denote  $\tilde{A} = (P_S A)|_S$  and two eigenvalues of  $\tilde{A}$  by  $\lambda_1 \leq \lambda_2$ . By well known properties of the Rayleigh-Ritz method, we have  $\lambda(f), \lambda(g) \in [\lambda_1, \lambda_2] \subseteq [\max\{\Sigma(A)\}, \min\{\Sigma(A)\}]$ . In the nontrivial case  $\lambda(f) \neq \lambda(g)$ , we then have the strong inequality  $\lambda_1 \leq \lambda_2$ .

In this proof, we extend the notation of the Rayleigh quotient of an operator A at a vector f to  $\lambda(f;A)=(f,Af)/(f,f)$  to explicitly include A. It is easy to see that  $\lambda(f;A)=\lambda(f;\tilde{A})$  and that the same holds for vector g. Then, since  $[\lambda_1,\lambda_2]\subseteq[\max\{\Sigma(A)\},\min\{\Sigma(A)\}]$  the statement of the lemma would follow from the 2D estimate  $|\lambda(f;\tilde{A})-\lambda(g;\tilde{A})|\leq (\lambda_2-\lambda_1)\sin(\theta(f,g))$  that we now have to prove. The latter estimate is clearly invariant with respect to a shift and scaling of  $\tilde{A}$ . Let us use the transformation  $\bar{A}=(\tilde{A}-\lambda_1I)/(\lambda_2-\lambda_1)$  then the estimate we need to prove turns into  $|\lambda(f;\bar{A})-\lambda(g;\bar{A})|\leq\sin(\theta(f,g))$ , but the operator  $\bar{A}$  has two eigenvalues, zero and one, and thus is an orthoprojector on some one dimensional subspace span{h} \subset S. Finally,  $\lambda(f;\bar{A})=(f,P_hf)/(f,f)=\cos^2(\theta(h,f))$  and, similarly,  $\lambda(g;\bar{A})=(g,P_hg)/(g,g)=\cos^2(\theta(h,g))$ . But  $|\cos^2(\theta(h,f))-\cos^2(\theta(h,g))|=||P_hP_fP_h||-||P_hP_gP_h|||\leq||P_f-P_g||=\sin(\theta(f,g))$ .

In the Rayleigh-Ritz method for a selfadjoint operator  $A \in \mathcal{B}(\mathcal{H})$  on a trial subspace  $\mathcal{F}$  the spectrum  $\Sigma((P_{\mathcal{F}}A)|_{\mathcal{F}})$  is called the set of Ritz values, corresponding to A and  $\mathcal{F}$ . The next result of this section is an estimate of a change in the Ritz values, where one trial subspace,  $\mathcal{F}$ , is replaced with another,  $\mathcal{G}$ . For finite dimensional subspaces such a result is obtained in [24], where the maximal distance between pairs of individually ordered Ritz values is used to measure the change in the Ritz values. Here, the trial subspaces may be infinite dimensional, so the Ritz values may form rather general sets on the real interval  $[\min\{\Sigma(A)\}, \max\{\Sigma(A)\}]$  and we are limited to the use of the Hausdorff distance between the sets, which does not take into account the ordering and multiplicities.

<span id="page-15-0"></span>**Theorem 5.2.** Let  $A \in \mathcal{B}(\mathcal{H})$  be a selfadjoint operator and  $\mathcal{F}$  and  $\mathcal{G}$  be nontrivial subspaces of  $\mathcal{H}$ . Then a bound for the Hausdorff distance between the Ritz values of A, with respect to the trial subspaces  $\mathcal{F}$  and  $\mathcal{G}$ , is given by the following inequality

$$\operatorname{dist}(\Sigma((P_{\mathcal{F}}A)|_{\mathcal{F}}), \ \Sigma((P_{\mathcal{G}}A)|_{\mathcal{G}})) \leq (\max\{\Sigma(A)\} - \min\{\Sigma(A)\}) \operatorname{gap}(\mathcal{F}, \mathcal{G}).$$

*Proof.* If  $\operatorname{gap}(\mathcal{F},\mathcal{G})=1$  then the assertion holds since the both spectra are subsets of  $[\min\{\Sigma(A)\},\max\{\Sigma(A)\}]$ . Consequently we can assume without loss of generality that  $\operatorname{gap}(\mathcal{F},\mathcal{G})<1$ . Then we have  $\mathcal{G}=W\mathcal{F}$  with W defined by (2.1). Operators  $(P_{\mathcal{G}}A)|_{\mathcal{G}}$  and  $(W^*(P_{\mathcal{G}}A)|_{\mathcal{G}}W)|_{\mathcal{F}}$  are unitarily equivalent, since W is an isometry on  $\mathcal{F}$ , therefore, their spectra are the same. Operators  $(P_{\mathcal{F}}A)|_{\mathcal{F}}$  and  $(W^*(P_{\mathcal{G}}A)|_{\mathcal{G}}W)|_{\mathcal{F}}$  are selfadjoint on the space  $\mathcal{F}$  and using [19, Theorem 4.10, p. 291] we get

<span id="page-15-2"></span>
$$\operatorname{dist}(\Sigma((P_{\mathcal{F}}A)|_{\mathcal{F}}), \Sigma((P_{\mathcal{G}}A)|_{\mathcal{G}})) = \operatorname{dist}(\Sigma((P_{\mathcal{F}}A)|_{\mathcal{F}}), \Sigma((W^{*}(P_{\mathcal{G}}A)|_{\mathcal{G}}W)|_{\mathcal{F}}))$$

$$\leq ||(P_{\mathcal{F}}A - W^{*}(P_{\mathcal{G}}A)|_{\mathcal{G}}W)|_{\mathcal{F}}||. \tag{5.2}$$

Then

$$\begin{split} \| \left( P_{\mathcal{F}} A - W^*(P_{\mathcal{G}} A) |_{\mathcal{G}} W \right) |_{\mathcal{F}} \| &= \sup_{\| f \| = 1, \, f \in \mathcal{F}} |((P_{\mathcal{F}} A - W^*(P_{\mathcal{G}} A) |_{\mathcal{G}} W) f, \, f) | \\ &= \sup_{\| f \| = 1, \, f \in \mathcal{F}} |(Af, \, f) - (AWf, \, Wf)|. \end{split}$$

We have  $|(f, Af) - (Wf, AWf)| \le (\max\{\Sigma(A)\} - \min\{\Sigma(A)\}) \sqrt{1 - |(f, Wf)|^2}$ ,  $\forall f \in \mathcal{F}$ , ||f|| = 1 by Lemma 5.1. We need to estimate |(f, Wf)| from below. From the polar decomposition  $P_{\mathcal{G}}P_{\mathcal{F}} = W\sqrt{P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}}$ , we derive the equalities

$$(f, Wf) = (P_{\mathcal{G}}P_{\mathcal{F}}f, Wf) = (W^*P_{\mathcal{G}}P_{\mathcal{F}}f, f) = (\sqrt{P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}}f, f),$$

where we have  $\sqrt{P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}}|_{\mathcal{F}} = \sqrt{(P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}})|_{\mathcal{F}}} = \sqrt{(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}}}$ , since  $\mathcal{F}$  is an invariant subspace of the operator  $P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}$ . Thus,  $(f,Wf)=(\sqrt{(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}}}f,f)\geq \min\{\cos(\hat{\Theta}(\mathcal{F},\mathcal{G}))\}$  by Definition 2.4. Finally, by assumption,  $\operatorname{gap}(\mathcal{F},\mathcal{G})<1$ , thus Corollary 2.13 gives  $\min\{\cos^2(\hat{\Theta}(\mathcal{F},\mathcal{G}))\}=1-\operatorname{gap}^2(\mathcal{F},\mathcal{G})$ .

Finally, we assume that  $\mathcal{F}$  is A-invariant, which implies that the set of the values  $\Sigma((P_{\mathcal{F}}A)|_{\mathcal{F}})$  is a subset, namely  $\Sigma(A|_{\mathcal{F}})$ , of the spectrum of A. The change in the Ritz values, bounded in Theorem 5.2, can now be interpreted as a spectrum error in the Rayleigh-Ritz method. The result of Theorem 5.2 here is improved since the new bound involves the gap squared as in [1, 26].

<span id="page-16-2"></span>**Theorem 5.3.** Under the assumptions of Theorem 5.2 let in addition  $\mathcal{F}$  be an A-invariant subspace of  $\mathcal{H}$  corresponding to the top (or bottom) part of the spectrum of A. Then

$$\text{dist}(\Sigma(A|_{\mathcal{F}}),\,\Sigma((P_{\mathcal{G}}A)|_{\mathcal{G}})) \leq (\max\{\Sigma(A)\} - \min\{\Sigma(A)\})\,\text{gap}^2(\mathcal{F},\mathcal{G}).$$

*Proof.* As the subspace  $\mathcal{F}$  is A-invariant and A is selfadjoint, the subspace  $\mathcal{F}^{\perp}$  is also A-invariant, so  $A = P_{\mathcal{F}}AP_{\mathcal{F}} + P_{\mathcal{F}^{\perp}}AP_{\mathcal{F}^{\perp}}$  and, with a slight abuse of the notation,  $A = A|_{\mathcal{F}} + A|_{\mathcal{F}^{\perp}}$ , corresponding to the decomposition  $\mathcal{H} = \mathcal{F} \oplus \mathcal{F}^{\perp}$ , thus  $\Sigma(A) = \Sigma(A|_{\mathcal{F}}) \cup \Sigma(A|_{\mathcal{F}^{\perp}})$ . We assume that  $\mathcal{F}$  corresponds to the top part of the spectrum of A—the bottom part case can be treated by replacing A with -A. Under this assumption, we have  $\max\{\Sigma(A|_{\mathcal{F}^{\perp}})\} \leq \min\{\Sigma(A|_{\mathcal{F}})\}$ .

Let us also notice that the inequality we want to prove is unaltered by replacing A with  $A - \alpha I$  where  $\alpha$  is an arbitrary real constant. Later in the proof we need  $A|_{\mathcal{F}}$  to be nonnegative. We set  $\alpha = \min\{\Sigma(A|_{\mathcal{F}})\}$  and substitute A with  $A - \alpha I$ , so now  $\max\{\Sigma(A|_{\mathcal{F}})\} \le 0 = \min\{\Sigma(A|_{\mathcal{F}})\}$ , thus

$$||A|_{\mathcal{F}}|| = \max\{\Sigma(A|_{\mathcal{F}})\} = \max\{\Sigma(A)\}, \text{ and } ||A|_{\mathcal{F}^{\perp}}|| = -\min\{\Sigma(A|_{\mathcal{F}^{\perp}})\} = -\min\{\Sigma(A)\}.$$

The constant in the bound we are proving then takes the following form:

<span id="page-16-1"></span><span id="page-16-0"></span>
$$\max\{\Sigma(A)\} - \min\{\Sigma(A)\} = ||A|_{\mathcal{F}}|| + ||A|_{\mathcal{F}^{\perp}}||. \tag{5.3}$$

As in the proof of Theorem 5.2, if  $gap(\mathcal{F},\mathcal{G})=1$  then the assertion holds since the both spectra are subsets of  $[\min\{\Sigma(A)\}, \max\{\Sigma(A)\}]$ . Consequently we can assume without loss of generality that  $gap(\mathcal{F},\mathcal{G})<1$ . Then we have  $\mathcal{G}=W\mathcal{F}$  with W defined by (2.1). Operators  $(W^*(P_\mathcal{G}P_\mathcal{F}AP_\mathcal{F})|_\mathcal{G}W)|_\mathcal{F}$  and  $(P_\mathcal{G}P_\mathcal{F}AP_\mathcal{F})|_\mathcal{G}$  are unitarily equivalent, since W is an isometry on  $\mathcal{F}$ , thus their spectra are the same. Now, instead of (5.2), we use the triangle inequality for the Hausdorff distance:

$$\begin{aligned} \operatorname{dist}(\Sigma(\mathbf{A}|_{\mathcal{F}}), \ \Sigma((\mathbf{P}_{\mathcal{G}}\mathbf{A})|_{\mathcal{G}})) \\ & \leq \operatorname{dist}(\Sigma((\mathbf{A}|_{\mathcal{F}}), \ \Sigma((\mathbf{W}^*(\mathbf{P}_{\mathcal{G}}\mathbf{P}_{\mathcal{F}}\mathbf{A}\mathbf{P}_{\mathcal{F}})|_{\mathcal{G}}\mathbf{W})|_{\mathcal{F}})) \\ & + \operatorname{dist}(\Sigma((\mathbf{P}_{\mathcal{G}}\mathbf{P}_{\mathcal{F}}\mathbf{A}\mathbf{P}_{\mathcal{F}})|_{\mathcal{G}})), \ \Sigma((\mathbf{P}_{\mathcal{G}}\mathbf{A})|_{\mathcal{G}})). \end{aligned} \tag{5.4}$$

The operator  $\sqrt{P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}}|_{\mathcal{F}} = \sqrt{(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}}}$  is selfadjoint and its smallest point of the spectrum is min{cos( $\hat{\Theta}(\mathcal{F},\mathcal{G})$ )} by Definition 2.4, which is positive by Theorem 2.12 with gap( $\mathcal{F},\mathcal{G}$ ) < 1.

The operator  $\sqrt{P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}}|_{\mathcal{F}}$  is invertible, so from the polar decomposition  $P_{\mathcal{G}}P_{\mathcal{F}}=W\sqrt{P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}}$ , which gives  $P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}=P_{\mathcal{F}}P_{\mathcal{G}}W\sqrt{P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}}$ , we obtain by applying the inverse on the right that  $(P_{\mathcal{F}}P_{\mathcal{G}}W)|_{\mathcal{F}}=\sqrt{P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}}|_{\mathcal{F}}=(W^*P_{\mathcal{G}}P_{\mathcal{F}})|_{\mathcal{F}}$ . Thus,

$$(W^*(P_{\mathcal{G}}P_{\mathcal{F}}AP_{\mathcal{F}})|_{\mathcal{G}}W)|_{\mathcal{F}} = \left(\sqrt{P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}}A\sqrt{P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}}\right)|_{\mathcal{F}}$$

$$= \sqrt{P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}}|_{\mathcal{F}}\sqrt{A|_{\mathcal{F}}}\sqrt{A|_{\mathcal{F}}}\sqrt{A|_{\mathcal{F}}}\sqrt{P_{\mathcal{F}}P_{\mathcal{G}}P_{\mathcal{F}}}|_{\mathcal{F}}$$

where the operator  $A|_{\mathcal{F}}$  is already made nonnegative by applying the shift and the substitution.

The spectrum of the product of two bounded operators, one of which is bijective, does not depend on the order of the multipliers, since both products are similar to each other. One of our operators,  $\sqrt{P_{\mathcal{F}}P_{G}P_{\mathcal{F}}}|_{\mathcal{F}}$ , in the product is bijective, so

$$\Sigma((W^*(P_GP_{\mathcal{F}}AP_{\mathcal{F}})|_GW)|_{\mathcal{F}}) = \Sigma\left(\sqrt{A|_{\mathcal{F}}}(P_{\mathcal{F}}P_G)|_{\mathcal{F}}\sqrt{A|_{\mathcal{F}}}|_{\mathcal{F}}\right).$$

Then the first term in the triangle inequality (5.4) for the Hausdorff distance is estimated using [19, Theorem 4.10, p. 291]:

$$\begin{aligned} \operatorname{dist}(\Sigma(\mathbf{A}|_{\mathcal{F}}) \,, & \qquad \qquad \Sigma\left(\left(W^*\left(P_{\mathcal{G}}P_{\mathcal{F}}AP_{\mathcal{F}}\right)|_{\mathcal{G}}W\right)|_{\mathcal{F}}\right)\right) \\ &= & \operatorname{dist}\left(\Sigma\left(\mathbf{A}|_{\mathcal{F}}\right), \, \Sigma\left(\sqrt{A|_{\mathcal{F}}}\left(P_{\mathcal{F}}P_{\mathcal{G}}\right)|_{\mathcal{F}}\sqrt{A|_{\mathcal{F}}}\right)\right) \\ &\leq & \left\|A|_{\mathcal{F}} - \sqrt{A|_{\mathcal{F}}}\left(P_{\mathcal{F}}P_{\mathcal{G}}\right)|_{\mathcal{F}}\sqrt{A|_{\mathcal{F}}}\right\| \\ &= & \left\|\sqrt{A|_{\mathcal{F}}}\left(P_{\mathcal{F}} - P_{\mathcal{F}}P_{\mathcal{G}}\right)|_{\mathcal{F}}\sqrt{A|_{\mathcal{F}}}\right\| \\ &\leq & \|A|_{\mathcal{F}}\|\left\|\left(P_{\mathcal{F}}P_{\mathcal{G}^{\perp}}\right)|_{\mathcal{F}}\right\| = \|A|_{\mathcal{F}}\|\left\|P_{\mathcal{F}}P_{\mathcal{G}^{\perp}}\right\|^{2}. \end{aligned}$$

To estimate the second term in (5.4), we apply again [19, Theorem 4.10, p. 291]:

$$\begin{split} \operatorname{dist} \left( & \Sigma \left( (\mathsf{P}_{\mathcal{G}} \mathsf{P}_{\mathcal{F}} \mathsf{A} \mathsf{P}_{\mathcal{F}}) \big|_{\mathcal{G}} \right) \right), \, \Sigma ((\mathsf{P}_{\mathcal{G}} \mathsf{A}) |_{\mathcal{G}}) \right) \leq || (\mathsf{P}_{\mathcal{G}} \mathsf{P}_{\mathcal{F}} \mathsf{A} \mathsf{P}_{\mathcal{F}}) |_{\mathcal{G}} - (\mathsf{P}_{\mathcal{G}} \mathsf{A}) |_{\mathcal{G}} || \\ & = || (P_{\mathcal{G}} P_{\mathcal{F}^{\perp}} A P_{\mathcal{F}^{\perp}}) |_{\mathcal{G}} || = || P_{\mathcal{G}} P_{\mathcal{F}^{\perp}} A |_{\mathcal{F}^{\perp}} P_{\mathcal{F}^{\perp}} P_{\mathcal{G}} || \leq || A |_{\mathcal{F}^{\perp}} || || P_{\mathcal{G}} P_{\mathcal{F}^{\perp}} ||^2, \end{split}$$

where  $A = P_{\mathcal{F}}AP_{\mathcal{F}} + P_{\mathcal{F}^{\perp}}AP_{\mathcal{F}^{\perp}}$ . Plugging in bounds for both terms in (5.4) gives

$$dist\left(\Sigma(A|_{\mathcal{F}}),\ \Sigma((P_{\mathcal{G}}A)|_{\mathcal{G}})\right) \leq \|A|_{\mathcal{F}}\|\left\|P_{\mathcal{F}}P_{\mathcal{G}^\perp}\right\|^2 + \|A|_{\mathcal{F}^\perp}\|\left\|P_{\mathcal{G}}P_{\mathcal{F}^\perp}\right\|^2.$$

Assumption gap( $\mathcal{F},\mathcal{G}$ ) < 1 implies that  $\|P_{\mathcal{F}}P_{\mathcal{G}^{\perp}}\| = \|P_{\mathcal{G}}P_{\mathcal{F}^{\perp}}\| = \text{gap}(\mathcal{F},\mathcal{G})$ , e.g., see [19, §I.8, Theorem 6.34] and cf. Corollary 2.13. Thus we obtain

$$\operatorname{dist}\left(\Sigma((P_{\mathcal{F}}A)|_{\mathcal{F}}),\ \Sigma((P_{\mathcal{G}}A)|_{\mathcal{G}})\right) \leq (\|A|_{\mathcal{F}}\| + \|A|_{\mathcal{F}^{\perp}}\|)\operatorname{gap}^{2}(\mathcal{F},\mathcal{G}).$$

Taking into account (5.3) completes the proof.

We conjecture that our assumption on the invariant subspace representing a specific part of the spectrum of A is irrelevant, i.e., the statement of Theorem 5.3 holds without it as well, cf. Argentati et al. [1], Knyazev and Argentati [26].

## <span id="page-18-0"></span>6. The ultimate acceleration of the alternating projectors method

Every selfadjoint nonnegative non-expansion A,  $0 \le A \le I$  in a Hilbert space  $\mathcal{H}$  can be extended to an orthogonal projector in the space  $\mathcal{H} \times \mathcal{H}$ , e.g., [14, 31], and, thus, can be implicitly written as (strictly speaking is unitarily equivalent to) a product of two orthogonal projectors  $P_{\mathcal{F}}P_{\mathcal{G}}$  restricted to a subspace  $\mathcal{F} \subset \mathcal{H} \times \mathcal{H}$ . Any iterative method that involves as a main step a multiplication of a vector by A can thus be called "an alternating projectors" method.

In the classical alternating projectors method, it is assumed that the projectors are given explicitly and that the iterating procedure is trivially

<span id="page-18-1"></span>
$$e^{(i+1)} = P_{\mathcal{F}} P_G e^{(i)}, \ e^{(0)} \in \mathcal{F}.$$
 (6.1)

If  $\|(P_{\mathcal{F}}P_{\mathcal{G}})\|_{\mathcal{F}}\| < 1$  then the sequence of vectors  $e^{(i)}$  evidently converges to zero. Such a situation is typical when  $e^{(i)}$  represents an error of an iterative method, e.g., in a multiplicative DDM, and formula (6.1) describes the error propagation as in our DDM example below.

If the subspace  $\mathfrak{M}_{00} = \mathcal{F} \cap \mathcal{G}$  is nontrivial and  $\|(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F} \oplus \mathfrak{M}_{00}}\| < 1$  then the sequence of vectors  $e^{(i)}$  converges to the orthogonal projection e of  $e^{(0)}$  onto  $\mathfrak{M}_{00}$ . The latter is called a von Neumann-Halperin ([34, 15]) method in [2] of alternating projectors for determining the best approximation to  $e^{(0)}$  in  $\mathfrak{M}_{00}$ . We note that, despite the non-symmetric appearance of the error propagation operator  $P_{\mathcal{F}}P_{\mathcal{G}}$  in (6.1), it can be equivalently replaced with the selfadjoint operator  $(P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}}$  since  $e^{(0)} \in \mathcal{F}$  and thus all  $e^{(i)} \in \mathcal{F}$ .

Several attempts to estimate and accelerate the convergence of iterations (6.1) are made, e.g., [9, 2, 39]. Here, we use a different approach, cf., e.g., [38, 4], to suggest the ultimate acceleration of the alternating projectors method. First, we notice that the limit vector  $e \in \mathfrak{M}_{00}$  is a nontrivial solution of the following homogeneous equation

<span id="page-18-2"></span>
$$(I - P_{\mathcal{F}} P_{\mathcal{G}})|_{\mathcal{F}} e = 0, \quad e \in \mathcal{F}. \tag{6.2}$$

Second, we observe that the linear operator is selfadjoint and nonnegative in the equation above, therefore, a conjugate gradient (CG) method can be used to calculate approximations to the solution e in the null-space. The standard CG algorithm for linear systems Ax = b can be formulated as follows, see, e.g., [17]:

Initialization: set  $\gamma = 1$  and compute the initial residual r = b - Ax;

Loop until convergence:

 $\gamma_{old} = \gamma, \ \gamma = (r, r);$ 

on the first iteration: p = r; otherwise:

 $\beta = \gamma/\gamma_{old}$  (standard) or  $\beta = (r - r_{old}, r)/(r_{old}, r_{old})$ 

(the latter is recommended if an approximate application of A is used)

 $p = r + \beta p$ , r = Ap,  $\alpha = \gamma/(r, p)$ ,  $x = x + \alpha p$ ,  $r = r - \alpha r$ . End loop

It can be applied directly to the homogeneous equation Ae = 0 with  $A = A^* \ge 0$  by setting b = 0. We need  $A = (I - P_{\mathcal{F}}P_{\mathcal{G}})|_{\mathcal{F}}$  for equation (6.2). Finally, we note that CG acceleration can evidently be applied to the symmetrized alternating projectors method with more than two projectors.

The traditional theory of the CG method for non-homogeneous equations extends trivially to the computation of the null-space of a selfadjoint nonnegative operator A and gives the following

convergence rate estimate:

<span id="page-19-0"></span>
$$(e^{(k)}, Ae^{(k)}) \le \min_{\deg p_k = k, \ p_k(0) = 1} \sup_{\lambda \in \Sigma(A) \setminus \{0\}} |p_k(\lambda)|^2 \quad (e^{(0)}, Ae^{(0)}). \tag{6.3}$$

For equation (6.2),  $A = (I - P_{\mathcal{F}} P_{\mathcal{G}})|_{\mathcal{F}}$  and thus  $(e^{(k)}, Ae^{(k)}) = ||P_{\mathcal{G}^{\perp}} e^{(k)}||^2$  and by Definition 2.4 we have  $\Sigma(A) = 1 - \cos^2 \hat{\Theta}(\mathcal{F}, \mathcal{G})$ . Estimate (6.3) shows convergence if and only if zero is an isolated point of the spectrum of A, or, in terms of the angles, if and only if zero is an isolated point, or not present, in the set of angles  $\hat{\Theta}(\mathcal{F}, \mathcal{G})$ , which is the same as the condition for convergence of the original alternating projectors method (6.1), stated above.

Method (6.1) can be equivalently reformulated as a simple Richardson iteration

$$e^{(k)} = (I - A)^k e^{(0)}, e^{(0)} \in \mathcal{F}, \text{ where } A = (I - P_{\mathcal{F}} P_{\mathcal{G}})|_{\mathcal{F}},$$

and thus falls into the same class of polynomial methods as does the CG method. It is well known that the CG method provides the smallest value of the energy (semi-) norm of the error, in our case of  $||P_{G^{\perp}}e^{(k)}||$ , where  $e^{(k)} \in \mathcal{F}$ , which gives us an opportunity to call it the "ultimate acceleration" of the alternating projectors method.

A possible alternative to equation (6.2) is

<span id="page-19-1"></span>
$$(P_{\mathcal{F}^{\perp}} + P_{\mathcal{G}^{\perp}})e = 0, \tag{6.4}$$

so we can take  $A = P_{\mathcal{F}^{\perp}} + P_{\mathcal{G}^{\perp}}$  in the CG method for equation (6.4) and then  $\Sigma(A)$  is given by Theorem 2.18. Equation (6.4) appears in the so-called additive DDM method, e.g., [32]. A discussion of (6.4) can be found in [18, §7.1, p. 127].

Estimate (6.3) guarantees the finite convergence of the CG method if the spectrum of A consists of a finite number of points. At the same time, the convergence of the Richardson method can be slow in such a case, so that the CG acceleration is particularly noticeable. In the remainder of the section, we present a simple domain decomposition example for the one dimensional diffusion equation.

Consider the following one dimensional diffusion equation  $\int_0^1 u'v'dx = \int_0^1 fv'dx$ ,  $\forall v \in H_0^1([0,1])$  with the solution  $u \in H_0^1([0,1])$ , where  $H_0^1([0,1])$  is the usual Sobolev space of real-valued functions with the Lebesgue integrable squares of the first generalized derivatives and with zero values at the end points of the interval [0,1]. We use the bilinear form  $\int_0^1 u'v'dx$  as a scalar product on  $H_0^1([0,1])$ .

We consider DDM with an overlap, i.e., we split  $[0,1] = [0,\alpha] \cup [\beta,1]$ , with  $0 < \beta < \alpha < 1$  so that  $[\beta,\alpha]$  is an overlap. We directly define orthogonal complements:

$$\mathcal{F}^{\perp} = \{u \in H^1_0([0,1]) : u(x) = 0, x \in [\alpha,1] \} \text{ and } \mathcal{G}^{\perp} = \{v \in H^1_0([0,1]) : v(x) = 0, x \in [0,\beta] \}$$

of subspaces  $\mathcal{F} \subset H_0^1([0,1])$  and  $\mathcal{G} \subset H_0^1([0,1])$ . Evidently,  $\mathcal{H} = \mathcal{F}^\perp + \mathcal{G}^\perp$ , where the sum is not direct due to the overlap.

It can be checked easily that the subspace  $\mathcal{F}$  consists of functions, which are linear on the interval  $[0, \alpha]$  and the subspace  $\mathcal{G}$  consists of functions, which are linear on the interval  $[\beta, 1]$ . Because of the overlap  $[\beta, \alpha]$ , the intersection  $\mathfrak{M}_{00} = \mathcal{F} \cap \mathcal{G}$  is trivial and the only solution of (6.2) and (6.4) is e = 0.

We now completely characterize all angles between  $\mathcal{F}$  and  $\mathcal{G}$ . Let  $f \in \mathcal{F}$  be linear on intervals  $[0, \alpha]$  and  $[\alpha, 1]$ . Similarly, let  $g \in \mathcal{G}$  be linear on intervals  $[0, \beta]$  and  $[\beta, 1]$ . It is easy to see,

cf. [18, §7.2], that all functions in the subspace  $\mathcal{F} \ominus \operatorname{span}\{f\}$  vanish outside of the interval  $[\alpha, 1]$ , while all functions in the subspace  $\mathcal{G} \ominus \operatorname{span}\{g\}$  vanish outside of the interval  $[0,\beta]$ . Therefore, the subspaces  $\mathcal{F} \ominus \operatorname{span}\{f\}$  and  $\mathcal{G} \ominus \operatorname{span}\{g\}$  are orthogonal, since  $\beta < \alpha$ . We summarize these results in terms of the principal subspaces:  $\hat{\Theta}(\mathcal{F},\mathcal{G}) = \Theta(\mathcal{F},\mathcal{G}) = \Theta_p(\mathcal{F},\mathcal{G}) = \theta(f,g) \cup \pi/2$ , where  $\cos^2\theta(f,g) = (\beta(1-\alpha))/(\alpha(1-\beta))$ , (the latter equality can be derived by elementary calculations, see [18, Theorem 7.2, p. 131]);  $\operatorname{span}\{f\}$  and  $\operatorname{span}\{g\}$  is one pair of principal subspaces and  $\mathcal{F} \ominus \operatorname{span}\{f\}$  and  $\mathcal{G} \ominus \operatorname{span}\{g\}$  is the other, corresponding to the angle  $\pi/2$ .

In multiplicative Schwarz DDM with an overlap for two subdomains, the error propagation of a simple iteration is given by (6.1) and the convergence rate is determined by the quantity

$$\left\| (P_{\mathcal{F}} P_{\mathcal{G}}) \right|_{\mathcal{F}} \right\| = \cos^2 \theta(f, g) = (\beta(1 - \alpha))/(\alpha(1 - \beta)) < 1,$$

which approaches one when the overlap  $\alpha - \beta$  becomes small. At the same time, however, the CG method described, e.g., in [4, 38], converges at most in two iterations, since the spectrum of A in (6.2) consists of only two eigenvalues,  $1 - \cos^2 \theta(f, g) = \sin^2 \theta(f, g)$  and 1.

In the additive DDM the error is determined by (6.4) and the spectrum of A, the sum of two orthoprojectors, by analogy with Theorem 2.18 consists of four eigenvalues,

$$1 - \cos\theta(f, g) = 2\sin^2(\theta(f, g)/2), 1, 1 + \cos\theta(f, g) = 2\cos^2(\theta(f, g)/2), \text{ and } 2,$$

therefore the CG method converges at most in four iterations. Similar results for a finite difference discretization of the 1D diffusion equation can be found in [12].

#### Acknowledgements

We thank Ilya Lashuk for contributing to the proofs of Theorems 2.2 and 5.2.

#### References

- <span id="page-20-10"></span> M. E. Argentati, A. V. Knyazev, C. C. Paige, and I. Panayotov. Bounds on changes in Ritz values for a perturbed invariant subspace of a Hermitian matrix. SIAM J. Matr. Anal. Appl., 30(2):548–559, 2008. MR2421459 (2009e:15021)
- <span id="page-20-4"></span>[2] H. H. Bauschke, F. Deutsch, H. Hundal, and S.-H. Park. Accelerating the convergence of the method of alternating projections. Trans. Amer. Math. Soc., 355(9):3433–3461 (electronic), 2003. MR1990157 (2004d:41062)
- <span id="page-20-9"></span>[3] P. E. Bjørstad and J. Mandel. On the spectra of sums of orthogonal projections with applications to parallel computing. *BIT*, 31(1):76–88, 1991. MR1097483 (91m:65157)
- <span id="page-20-3"></span>[4] P. E. Bjørstad and O. B. Widlund. To overlap or not to overlap: a note on a domain decomposition method for elliptic problems. SIAM J. Sci. Statist. Comput., 10(5):1053–1061, 1989. MR1009556 (90g:65139)
- <span id="page-20-1"></span>[5] A. Bottcher, I.M. Spitkovsky. A gentle guide to the basics of two projections theory. Linear Algebra and its Applications, 432(6) 1412-1459, 2010. DOI: 10.1016/j.laa.2009.11.002.
- <span id="page-20-6"></span>[6] C. Davis. Separation of two linear subspaces. Acta Sci. Math. Szeged, 19:172–187, 1958. MR0098980 (20:5425)
- <span id="page-20-7"></span>[7] C. Davis and W. M. Kahan. The rotation of eigenvectors by a perturbation. III. SIAM J. Numer. Anal., 7:1–46, 1970. MR0264450 (41:9044)
- <span id="page-20-8"></span>[8] F. Deutsch. The angle between subspaces of a Hilbert space. In Approximation theory, wavelets and applications, pp. 107–130. Kluwer Acad. Publ., Dordrecht, 1995. MR1340886 (96e:46027)
- <span id="page-20-5"></span>[9] F. Deutsch. Accelerating the convergence of the method of alternating projections via a line search: a brief survey. In *Inherently parallel algorithms in feasibility and optimization and their applications*, v. 8 of *Stud. Comput. Math.*, pp. 203–217. North-Holland, Amsterdam, 2001. MR1853223 (2002g;90101)
- <span id="page-20-2"></span>[10] F. Deutsch. Best approximation in inner product spaces. CMS Books in Mathematics/Ouvrages de Mathématiques de la SMC, 7, Springer-Verlag, New York, 2001, 338 pp. ISBN = 0-387-95156-3. MR1823556 (2002c:41001).
- <span id="page-20-0"></span>[11] J. Dixmier Position relative de deux variétés linéaires fermées dans un espace de Hilbert. Revue Scientifique, 86: 387-399, 1948. MR0029095 (10,546e)

- <span id="page-21-18"></span>[12] E. Efstathiou and M. J. Gander. Why restricted additive Schwarz converges faster than additive Schwarz. *BIT*, 43: 945–959, 2003. MR2058877 (2005c:65092)
- <span id="page-21-0"></span>[13] K. Friedrichs On certain inequalities and characteristic value problems for analytic functions and for functions of two variables Trans. Amer. Math. Soc. 41 (1937), pp. 321364.
- <span id="page-21-16"></span>[14] P. R. Halmos. Two subspaces. *Trans. Amer. Math. Soc.*, 144:381–389, 1969. MR0251519 (40:4746)
- <span id="page-21-14"></span>[15] I. Halperin. The product of projection operators. *Acta Sci. Math. (Szeged)*, 23:96–99, 1962. MR0141978 (25:5373)
- <span id="page-21-2"></span>[16] E. J. Hannan. The general theory of canonical correlation and its relation to functional analysis. *J. Austral. Math. Soc.*, 2:229–242, 1961/1962. MR0166869 (29:4142)
- <span id="page-21-26"></span>[17] M. R. Hestenes. *Conjugate direction methods in optimization*. Springer-Verlag, New York, 1980. MR0561510 (81i:65052)
- <span id="page-21-19"></span>[18] A. Jujunashvili. *Angles Between Infinite Dimensional Subspaces*. PhD thesis, University of Colorado Denver, 2005.
- <span id="page-21-3"></span>[19] T. Kato. *Perturbation theory for linear operators*. Springer-Verlag, Berlin, 1995. MR1335452 (96a:47025)
- <span id="page-21-24"></span>[20] A. V. Knyazev. *Computation of eigenvalues and eigenvectors for mesh problems: algorithms and error estimates*. Dept. Numerical Math. USSR Academy of Sciences, Moscow, 1986. (In Russian). MR1111245 (92d:65005)
- <span id="page-21-25"></span>[21] A. V. Knyazev. Convergence rate estimates for iterative methods for mesh symmetric eigenvalue problem. *Soviet J. Numerical Analysis and Math. Modelling*, 2(5):371–396, 1987. MR0915330 (88i:65057)
- <span id="page-21-4"></span>[22] A. V. Knyazev, Observations on degenerate saddle point problems. *Comput. Methods Appl. Mech.Engrg.*. 196 (37-40), 3742–3749, 1997. MR2339999 (2008g:65164)
- <span id="page-21-5"></span>[23] A. V. Knyazev and M. E. Argentati. Principal angles between subspaces in an A-based scalar product: Algorithms and perturbation estimates. *SIAM J. Sci. Computing*, 23(6):2009–2041, 2002. MR1923723 (2003h:65060)
- <span id="page-21-7"></span>[24] A. V. Knyazev and M. E. Argentati. On proximity of Rayleigh quotients for different vectors and Ritz values generated by different trial subspaces. *Linear Algebra and its Applications*, 415:82–95, 2006. MR2214747 (2006m:65077)
- <span id="page-21-6"></span>[25] A. V. Knyazev and M. E. Argentati. Majorization for changes in angles between subspaces, Ritz values, and graph Laplacian spectra. *SIAM J. Matr. Anal. Appl.*, 29(1):15–32, 2006/07. MR2288011 (2008f:15069)
- <span id="page-21-8"></span>[26] A. V. Knyazev and M. E. Argentati. Rayleigh-Ritz majorization error bounds with applications to FEM. *SIAM J. Matr. Anal. Appl.*, 31(3):1521–1537, 2010 MR2587790
- <span id="page-21-9"></span>[27] A. V. Knyazev and J. Osborn. New A Priori FEM Error Estimates for Eigenvalues. *SIAM J. Numer. Anal.*, 43(6), 2647–2667, 2006. MR2206452 (2006k:65300)
- <span id="page-21-21"></span>[28] J. J. Koliha and V. Rakoˇcevi´c. On the norm of idempotents in *C* ∗ -algebras. *Rocky Mountain J. Math.*, 34(2): 685–697, 2004. MR2072801 (2005c:46077)
- <span id="page-21-1"></span>[29] M.G. Krein, M.A. Krasnoselski, and D.P. Milman. On the defect numbers of operators in Banach spaces and on some geometric questions, Trudy Inst. Mat. Akad. Nauk Ukrain. SSR 11 (1948), pp. 97112 (in Russian).
- <span id="page-21-20"></span>[30] M. Omladiˇc. Spectra of the difference and product of projections. *Proc. Amer. Math. Soc.*, 99(2):317–318, 1987. MR0870792 (88a:47001)
- <span id="page-21-17"></span>[31] F. Riesz and B. Sz.-Nagy. *Functional analysis*. Dover Publications Inc., New York, 1990. MR1068530 (91g:00002)
- <span id="page-21-27"></span>[32] A. Toselli and O. Widlund. *Domain decomposition methods—algorithms and theory*. Springer-Verlag, Berlin, 2005. MR2104179 (2005g:65006)
- <span id="page-21-22"></span>[33] I. Vidav. The norm of the sum of two projections. *Proc. Amer. Math. Soc.*, 65(2):297–298, 1977. MR0442703 (56:1084)
- <span id="page-21-13"></span>[34] J. von Neumann. *Functional Operators. II. The Geometry of Orthogonal Spaces.* Princeton Univ. Press, Princeton, N. J., 1950. MR0034514 (11,599e)
- <span id="page-21-23"></span>[35] P. A. Wedin. On angles between subspaces of a finite-dimensional inner product space. In *Matrix Pencils*, pp. 263–285. Springer-Verlag, Berlin, 1983.
- <span id="page-21-10"></span>[36] H. F. Weinberger. *Variational methods for eigenvalue approximation*. SIAM, Philadelphia, Pa., 1974. MR0400004 (53:3842)
- <span id="page-21-11"></span>[37] A. Weinstein and W. Stenger. *Methods of intermediate problems for eigenvalues*. Academic Press, New York, 1972. MR0477971 (57:17469)
- <span id="page-21-12"></span>[38] O. B. Widlund. Optimal iterative refinement methods. In *Domain decomposition methods*, pp. 114–125. SIAM, Philadelphia, PA, 1989. MR0992008 (90m:65205)
- <span id="page-21-15"></span>[39] J. Xu and L. Zikatanov. The method of alternating projections and the method of subspace corrections in Hilbert space. *J. Amer. Math. Soc.*, 15(3):573–597, 2002. MR1896233 (2003f:65095)