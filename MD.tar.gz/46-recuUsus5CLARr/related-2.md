# **Matrix** norm

Contributors to Wikimedia projects

In the field of <u>mathematics</u>, <u>norms</u> are defined for elements within a <u>vector space</u>. Specifically, when the vector space comprises matrices, such norms are referred to as **matrix norms**. Matrix norms differ from vector norms in that they must also interact with matrix multiplication.

Given a field

K

of either real or complex numbers (or any complete subset thereof), let

 $K^{m imes n}$ 

be the K-vector space of matrices with

m

rows and

n

columns and entries in the field

K.

A matrix norm is a norm on

$$K^{m imes n}$$

Norms are often expressed with double vertical bars (like so:

 $\|A\|$ 

). Thus, the matrix norm is a function

$$\|\cdot\|:K^{m imes n} o \mathbb{R}^{0+}$$

that must satisfy the following properties:

For all scalars

$$\alpha \in K$$

and matrices

$$A,B\in K^{m imes n}$$
 ,

The only feature distinguishing matrices from rearranged vectors is <u>multiplication</u>. Matrix norms are particularly useful if they are also **sub-multiplicative**:

$$\|AB\| \leq \|A\| \|B\|$$

Every norm on

$$K^{n imes n}$$

can be rescaled to be sub-multiplicative; in some books, the terminology *matrix norm* is reserved for sub-multiplicative norms.

A matrix norm is called unitarily invariant if for all unitary matrices

![](_page_1_Figure_0.jpeg)

and matrix

 $\boldsymbol{A}$ 

,

$$||UAV|| = ||A||$$

•

A symmetric gauge function is an absolute vector norm

$$\phi:\mathbb{C}^p o\mathbb{R}^+$$

such that

$$\phi(Px) = \phi(x)$$

for any permutation matrix

P

. That is:

A norm is a unitarily invariant matrix norm if and only if it is a symmetric gauge function on the vector of singular values.

# Matrix norms induced by vector norms

[edit]

Suppose a vector norm

 $\|\cdot\|_{\alpha}$ 

on

 $K^n$ 

and a vector norm

 $\|\cdot\|_{\beta}$ 

on

 $K^{m}$ 

are given. Any

 $m \times n$ 

matrix A induces a linear operator from

 $K^n$ 

to

 $K^{m}$ 

with respect to the standard basis, and one defines the corresponding *induced norm* or *operator norm* or *subordinate norm* on the space

 $\mathbf{w}^{m \times r}$ 

of all

 $m \times n$ 

matrices as follows:

$$\|A\|_{lpha,eta}=\sup\{\|Ax\|_eta:x\in K^n ext{ such that }\|x\|_lpha\leq 1\}$$

where

denotes the supremum. This norm measures how much the mapping induced by

 $\boldsymbol{A}$ 

can stretch vectors. Depending on the vector norms

 $\|\cdot\|_{\alpha}$ 

,

 $\|\cdot\|_{\beta}$ 

used, notation other than

$$\|\cdot\|_{\alpha,\beta}$$

can be used for the operator norm.

### Matrix norms induced by vector p-norms

[edit]

If the p-norm for vectors (

$$1 \le p \le \infty$$

) is used for both spaces

 $K^n$ 

and

$$K^m$$
,

then the corresponding operator norm is:

$$\|A\|_p = \sup\{\|Ax\|_p : x \in K^n \text{ such that } \|x\|_p \le 1\}.$$

These induced norms are different from the *p*-norms and the <u>Schatten *p*-norms</u> for matrices treated below, which are also usually denoted by

$$||A||_p$$
.

Geometrically speaking, one can imagine a p-norm unit ball

$$V_{p,n} = \{x \in K^n : \|x\|_p \le 1\}$$

in

$$K^n$$

, then apply the linear map

1

to the ball. It would end up becoming a distorted convex shape

$$AV_{p,n}\subset K^m$$

, and

$$||A||_p$$

measures the longest "radius" of the distorted convex shape. In other words, we must take a p-norm unit ball

 $V_{p,m}$ 

in

 $K^{m}$ 

, then multiply it by at least

 $||A||_p$ 

, in order for it to be large enough to contain

 $AV_{p,n}$ 

.

When

p = 1,

or

$$p=\infty$$
,

we have simple formulas.

$$\|A\|_1 = \max_{1 \leq j \leq n} \sum_{i=1}^m |a_{ij}| \,\,,$$

which is simply the maximum absolute column sum of the matrix.

$$\|A\|_{\infty} = \max_{1 \leq i \leq m} \sum_{j=1}^n |a_{ij}| \,\,,$$

which is simply the maximum absolute row sum of the matrix.

For example, for

$$A = egin{bmatrix} -3 & 5 & 7 \ 2 & 6 & 4 \ 0 & 2 & 8 \end{bmatrix},$$

we have that

$$\begin{split} \|A\|_1 &= \max \big\{ \; |-3| + 2 + 0 \;,\; 5 + 6 + 2 \;,\; 7 + 4 + 8 \; \big\} = \max \big\{ \; 5 \;,\; 13 \;,\; 19 \; \big\} = 19 \;,\\ \|A\|_\infty &= \max \big\{ \; |-3| + 5 + 7 \;,\; 2 + 6 + 4 \;,\; 0 + 2 + 8 \; \big\} = \max \big\{ \; 15 \;,\; 12 \;,\; 10 \; \big\} = 15 \;. \end{split}$$

#### Spectral norm (p = 2)

[edit]

When

$$p = 2$$

(the Euclidean norm or

$$\ell_2$$

-norm for vectors), the induced matrix norm is the *spectral norm*. The two values do *not* coincide in infinite dimensions — see <u>Spectral radius</u> for further discussion. The spectral radius should not be confused with the spectral norm. The spectral norm of a matrix

 $\boldsymbol{A}$ 

is the largest singular value of

 $\boldsymbol{A}$ 

, i.e., the square root of the largest eigenvalue of the matrix

$$A^*A$$
.

where

denotes the conjugate transpose of

 $\boldsymbol{A}$ 

:

$$\|A\|_2 = \sqrt{\lambda_{\max}\left(A^*A
ight)} = \sigma_{\max}(A).$$

where

$$\sigma_{\max}(A)$$

represents the largest singular value of matrix

A.

There are further properties:

 $\|A\|_2 = \sqrt{
ho(A^*A)} \le \sqrt{\|A^*A\|_\infty} \le \sqrt{\|A\|_1 \|A\|_\infty}$ 

## Matrix norms induced by vector $\alpha$ - and $\beta$ -norms

[edit]

We can generalize the above definition. Suppose we have vector norms

$$\|\cdot\|_{\alpha}$$

and

$$\|\cdot\|_{\beta}$$

for spaces

$$K^n$$

and

$$K^m$$

respectively; the corresponding operator norm is

$$\|A\|_{lpha,eta}=\sup\{\|Ax\|_eta:x\in K^n ext{ such that } \|x\|_lpha\leq 1\}$$

In particular, the

$$\|A\|_p$$

defined previously is the special case of

$$||A||_{p,p}$$

.

In the special cases of

$$\alpha = 2$$

and

$$\beta = \infty$$

, the induced matrix norms can be computed by

$$\|A\|_{2,\infty} = \max_{1 \leq i \leq m} \|A_{i:}\|_2,$$

where

 $\boldsymbol{A}$ 

.

In the special cases of

 $\alpha = 1$ 

and

$$\beta = 2$$

, the induced matrix norms can be computed by

$$\|A\|_{1,2} = \max_{1 \leq j \leq n} \|A_{:j}\|_2,$$

where

 $A_{:j}$ 

is the j-th column of matrix

 $\boldsymbol{A}$ 

•

Hence,

 $\|A\|_{2,\infty}$ 

and

$$||A||_{1,2}$$

are the maximum row and column 2-norm of the matrix, respectively.

Any operator norm is with the vector norms that induce it, giving

$$||Ax||_{eta} \leq ||A||_{lpha,eta} ||x||_{lpha}.$$

Suppose

 $\|\cdot\|_{lpha,eta}$ 

;

 $\|\cdot\|_{eta,\gamma}$ 

; and

$$\|\cdot\|_{\alpha,\gamma}$$

are operator norms induced by the respective pairs of vector norms

$$(\|\cdot\|_{lpha},\|\cdot\|_{eta})$$

;

$$(\|\cdot\|_{\beta},\|\cdot\|_{\gamma})$$

; and

$$(\|\cdot\|_{\alpha},\|\cdot\|_{\gamma})$$

. Then,

$$||AB||_{\alpha,\gamma} \leq ||A||_{\beta,\gamma} ||B||_{\alpha,\beta};$$

this follows from

$$\|ABx\|_{\gamma} \leq \|A\|_{eta,\gamma} \|Bx\|_{eta} \leq \|A\|_{eta,\gamma} \|B\|_{lpha,eta} \|x\|_{lpha}$$

and

$$\sup_{\|x\|_\alpha=1}\|ABx\|_\gamma=\|AB\|_{\alpha,\gamma}.$$

Suppose

$$\|\cdot\|_{\alpha,\alpha}$$

is an operator norm on the space of square matrices

$$K^{n \times n}$$

induced by vector norms

$$\|\cdot\|_{\alpha}$$

and

$$\|\cdot\|_{\alpha}$$

. Then, the operator norm is a sub-multiplicative matrix norm:

$$||AB||_{\alpha,\alpha} \leq ||A||_{\alpha,\alpha} ||B||_{\alpha,\alpha}.$$

Moreover, any such norm satisfies the inequality

$$(\|A^r\|_{lpha,lpha})^{1/r} \geq 
ho(A)$$

for all positive integers r, where  $\rho(A)$  is the <u>spectral radius</u> of A. For <u>symmetric</u> or <u>hermitian</u> A, we have equality in () for the 2-norm, since in this case the 2-norm is precisely the spectral radius of A. For an arbitrary matrix, we may not have equality for any norm; a counterexample would be

$$A = egin{bmatrix} 0 & 1 \ 0 & 0 \end{bmatrix},$$

which has vanishing spectral radius. In any case, for any matrix norm, we have the spectral radius formula:

$$\lim_{r o\infty}\|A^r\|^{1/r}=
ho(A).$$

If the vector norms

$$\|\cdot\|_{lpha}$$

and

$$\|\cdot\|_{\beta}$$

are given in terms of energy norms based on symmetric positive definite matrices

P

and

O

respectively, the resulting operator norm is given as

$$\|A\|_{P,Q} = \sup\{\|Ax\|_Q : \|x\|_P \le 1\}.$$

Using the symmetric matrix square roots of

P

and

respectively, the operator norm can be expressed as the spectral norm of a modified matrix:

$$\|A\|_{P,Q} = \|Q^{1/2}AP^{-1/2}\|_2.$$

## Consistent and compatible norms

#### [edit]

A matrix norm

 $\|\cdot\|$ 

on

 $K^{m imes n}$ 

is called *consistent* with a vector norm

 $\|\cdot\|_{\alpha}$ 

on

 $K^n$ 

and a vector norm

 $\|\cdot\|_{\beta}$ 

on

 $K^{m}$ 

, if:

 $\|Ax\|_{eta} \leq \|A\| \, \|x\|_{lpha}$ 

for all

 $A \in K^{m imes n}$ 

and all

 $x \in K^n$ 

. In the special case of m = n and

 $\alpha = \beta$ 

,

 $\|\cdot\|$ 

is also called compatible with

 $\|\cdot\|_{\alpha}$ 

•

All induced norms are consistent by definition. Also, any sub-multiplicative matrix norm on

 $K^{n imes n}$ 

induces a compatible vector norm on

 $K^n$ 

by defining

 $\|v\|:=\|(v,v,\ldots,v)\|$ 

•

# "Entry-wise" matrix norms

[edit]

These norms treat an

 $m \times n$ 

matrix as a vector of size

 $m \cdot n$ 

, and use one of the familiar vector norms. For example, using the p-norm for vectors,  $p \ge 1$ , we get:

$$\|A\|_{p,p} = \| ext{vec}(A)\|_p = \left(\sum_{i=1}^m \sum_{j=1}^n |a_{ij}|^p
ight)^{1/p}$$

This is a different norm from the induced p-norm (see above) and the Schatten p-norm (see below), but the notation is the same.

The special case p = 2 is the Frobenius norm, and  $p = \infty$  yields the maximum norm.

## $L_{2,1}$ and $L_{p,q}$ norms

[edit]

Let

$$(a_1,\ldots,a_n)$$

be the dimension m columns of matrix

 $\boldsymbol{A}$ 

. From the original definition, the matrix

A

presents n data points in an m-dimensional space. The

$$L_{2.1}$$

norm is the sum of the Euclidean norms of the columns of the matrix:

$$\|A\|_{2,1} = \sum_{j=1}^n \|a_j\|_2 = \sum_{j=1}^n \left(\sum_{i=1}^m |a_{ij}|^2
ight)^{1/2}$$

The

$$L_2$$

norm as an <u>error function</u> is more robust, since the error for each data point (a column) is not squared. It is used in <u>robust data analysis</u> and <u>sparse coding</u>.

For  $p, q \ge 1$ , the

norm can be generalized to the

 $L_{p,q}$ 

norm as follows:

$$\|A\|_{p,q} = \left(\sum_{j=1}^n \left(\sum_{i=1}^m \left|a_{ij}
ight|^p
ight)^{rac{q}{p}}
ight)^{rac{1}{q}}.$$

When p = q = 2 for the

$$L_{p,a}$$

norm, it is called the **Frobenius norm** or the **Hilbert–Schmidt norm**, though the latter term is used more frequently in the context of operators on (possibly infinite-dimensional) <u>Hilbert space</u>. This norm can be defined in various ways:

$$\|A\|_{ ext{F}} = \sqrt{\sum_i^m \sum_j^n \left|a_{ij}
ight|^2} = \sqrt{ ext{trace}(A^*A)} = \sqrt{\sum_{i=1}^{\min\{m,n\}} \sigma_i^2(A)},$$

where the trace is the sum of diagonal entries, and

$$\sigma_i(A)$$

are the singular values of

A

- . The second equality is proven by explicit computation of  $\operatorname{trace}(A^*A)$
- . The third equality is proven by  $\underline{\text{singular value decomposition}}$  of

, and the fact that the trace is invariant under circular shifts.

The Frobenius norm is an extension of the Euclidean norm to

$$K^{n \times n}$$

and comes from the Frobenius inner product on the space of all matrices.

The Frobenius norm is sub-multiplicative and is very useful for <u>numerical linear algebra</u>. The sub-multiplicativity of Frobenius norm can be proved using the <u>Cauchy-Schwarz</u> inequality. In fact, it is more than sub-multiplicative, as

$$||AB||_F \le ||A||_{op} ||B||_F$$

where the operator norm

$$\|\cdot\|_{op} \leq \|\cdot\|_F$$

.

Frobenius norm is often easier to compute than induced norms, and has the useful property of being invariant under rotations (and unitary operations in general). That is,

$$\|A\|_{\mathrm{F}}=\|AU\|_{\mathrm{F}}=\|UA\|_{\mathrm{F}}$$

for any unitary matrix

**T** 7

. This property follows from the cyclic nature of the trace (

$$trace(XYZ) = trace(YZX) = trace(ZXY)$$

):

$$\|AU\|_{\mathrm{F}}^2 = \operatorname{trace}((AU)^*AU) = \operatorname{trace}(U^*A^*AU) = \operatorname{trace}(UU^*A^*A) = \operatorname{trace}(A^*A) = \|A\|_{\mathrm{F}}^2,$$

and analogously:

$$\|UA\|_{\mathrm{F}}^2 = \operatorname{trace}((UA)^*UA) = \operatorname{trace}(A^*U^*UA) = \operatorname{trace}(A^*A) = \|A\|_{\mathrm{F}}^2,$$

where we have used the unitary nature of

**T** 7

(that is,

$$U^*U = UU^* = \mathbf{I}$$

).

It also satisfies

$$\|A^*A\|_{\mathrm{F}} = \|AA^*\|_{\mathrm{F}} \le \|A\|_{\mathrm{F}}^2$$

and

$$\|A+B\|_{
m F}^2 = \|A\|_{
m F}^2 + \|B\|_{
m F}^2 + 2\,{
m Re}(\langle A,B
angle_{
m F}),$$

where

$$\langle A,B 
angle_{
m F}$$

is the <u>Frobenius inner product</u>, and Re is the real part of a complex number (irrelevant for real matrices)

The **max norm** is the elementwise norm in the limit as p = q goes to infinity:

$$\|A\|_{\max} = \max_{i,j} |a_{ij}|.$$

This norm is not; but modifying the right-hand side to

$$\sqrt{mn} \max_{i,j} |a_{ij}|$$

makes it so.

Note that in some literature (such as <u>Communication complexity</u>), an alternative definition of max-norm, also called the

 $\gamma_2$ 

-norm, refers to the factorization norm:

$$\gamma_2(A) = \min_{U,V:A=UV^T} \|U\|_{2,\infty} \|V\|_{2,\infty} = \min_{U,V:A=UV^T} \max_{i,j} \|U_{i,:}\|_2 \|V_{j,:}\|_2$$

The Schotten n-norms arise when applying the n-norm to the vector of singular values of

The behatten p-norms arise when applying the p-norm to the vector of singular values of

a matrix. If the singular values of the

$$m \times n$$

matrix

#### $\boldsymbol{A}$

are denoted by  $\sigma_i$ , then the Schatten *p*-norm is defined by

$$\|A\|_p = \left(\sum_{i=1}^{\min\{m,n\}} \sigma_i^p(A)
ight)^{1/p}.$$

These norms again share the notation with the induced and entry-wise *p*-norms, but they are different.

All Schatten norms are sub-multiplicative. They are also unitarily invariant, which means that

$$\|A\| = \|UAV\|$$

for all matrices

 $\boldsymbol{A}$ 

and all unitary matrices

U

and

V

•

The most familiar cases are p = 1, 2,  $\infty$ . The case p = 2 yields the Frobenius norm, introduced before. The case  $p = \infty$  yields the spectral norm, which is the operator norm induced by the vector 2-norm (see above). Finally, p = 1 yields the **nuclear norm** (also known as the *trace norm*, or the <u>Ky Fan</u> 'n'-norm), defined as:

$$\|A\|_* = \operatorname{trace}ig(\sqrt{A^*A}ig) = \sum_{i=1}^{\min\{m,n\}} \sigma_i(A),$$

where

$$\sqrt{A^*A}$$

denotes a positive semidefinite matrix

B

such that

$$BB = A^*A$$

. More precisely, since

$$A^*A$$

is a <u>positive semidefinite matrix</u>, its <u>square root</u> is well defined. The nuclear norm

$$\|A\|_*$$

is a convex envelope of the rank function

, so it is often used in <u>mathematical optimization</u> to search for low-rank matrices.

Combining <u>von Neumann's trace inequality</u> with <u>Hölder's inequality</u> for Euclidean space yields a version of Hölder's inequality for Schatten norms for

$$1/p + 1/q = 1$$

:

$$|\operatorname{trace}(A^*B)| \le ||A||_p ||B||_q$$

In particular, this implies the Schatten norm inequality

$$||A||_F^2 \le ||A||_p ||A||_q.$$

A matrix norm

$$\|\cdot\|$$

is called *monotone* if it is monotonic with respect to the <u>Loewner order</u>. Thus, a matrix norm is increasing if

$$A \preccurlyeq B \Rightarrow ||A|| \leq ||B||$$
.

The Frobenius norm and spectral norm are examples of monotone norms.

Another source of inspiration for matrix norms arises from considering a matrix as the <u>adjacency matrix</u> of a <u>weighted</u>, <u>directed graph</u>. The so-called "cut norm" measures how close the associated graph is to being bipartite:

$$\|A\|_\square = \max_{S\subseteq [n], T\subseteq [m]} \left|\sum_{s\in S, t\in T} A_{t,s}
ight|$$

where  $A \in K^{m \times n}$ . Equivalent definitions (up to a constant factor) impose the conditions 2|S| > n & 2|T| > m; S = T; or  $S \cap T = \emptyset$ .

The cut-norm is equivalent to the induced operator norm  $\|\cdot\|_{\infty\to 1}$ , which is itself equivalent to another norm, called the Grothendieck norm.

To define the Grothendieck norm, first note that a linear operator  $K^1 \to K^1$  is just a scalar, and thus extends to a linear operator on any  $K^k \to K^k$ . Moreover, given any choice of basis for  $K^n$  and  $K^m$ , any linear operator  $K^n \to K^m$  extends to a linear operator  $(K^k)^n \to (K^k)^m$ , by letting each matrix element on elements of  $K^k$  via scalar multiplication. The Grothendieck norm is the norm of that extended operator; in symbols:

$$\|A\|_{G,k} = \sup_{ ext{each } u_j, v_j \in K^k; \|u_j\| = \|v_j\| = 1} \sum_{j \in [n], \ell \in [m]} (u_j \cdot v_j) A_{\ell,j}$$

The Grothendieck norm depends on choice of basis (usually taken to be the <u>standard</u> <u>basis</u>) and k.

## **Equivalence of norms**

#### [edit]

For any two matrix norms

 $\|\cdot\|_{\alpha}$ 

and

 $\|\cdot\|_{\beta}$ 

, we have that:

$$r\|A\|_{lpha} \leq \|A\|_{eta} \leq s\|A\|_{lpha}$$

for some positive numbers r and s, for all matrices

 $A \in K^{m imes n}$ 

. In other words, all norms on

 $K^{m imes n}$ 

are equivalent; they induce the same topology on

 $K^{m imes n}$ 

. This is true because the vector space

 $K^{m imes n}$ 

has the finite dimension

 $m \times n$ 

.

Moreover, for every matrix norm

 $\|\cdot\|$ 

on

 $\mathbb{R}^{n \times n}$ 

there exists a unique positive real number

k

such that

 $\ell \| \cdot \|$ 

is a sub-multiplicative matrix norm for every

 $\ell > k$ 

; to wit,

$$k = \sup\{\|AB\| \, : \, \|A\| \leq 1, \|B\| \leq 1\}.$$

A sub-multiplicative matrix norm

$$\|\cdot\|_{\alpha}$$

is said to be minimal, if there exists no other sub-multiplicative matrix norm

$$\|\cdot\|_{\beta}$$

satisfying

$$\|\cdot\|_{\beta} < \|\cdot\|_{\alpha}$$

### Examples of norm equivalence

[edit]

Let

$$\|A\|_p$$

once again refer to the norm induced by the vector p-norm (as above in the Induced norm section).

For matrix

$$A \in \mathbb{R}^{m imes n}$$

of rank

r

, the following inequalities hold:

- $$\begin{split} \|A\|_2 &\leq \|A\|_F \leq \sqrt{r} \|A\|_2 \\ \|A\|_F \leq \|A\|_* \leq \sqrt{r} \|A\|_F \\ \|A\|_{\max} &\leq \|A\|_2 \leq \sqrt{mn} \|A\|_{\max} \\ \frac{1}{\sqrt{n}} \|A\|_{\infty} \leq \|A\|_2 \leq \sqrt{m} \|A\|_{\infty} \\ \frac{1}{\sqrt{m}} \|A\|_1 \leq \|A\|_2 \leq \sqrt{n} \|A\|_1. \end{split}$$
- Dual norm
- \* Logarithmic norm
- Neisstein, Eric W. "Matrix norm". mathworld.wolfram.com. Retrieved 2020-08-24.
- <sup>2.</sup> ^ "Matrix norms". fourier.eng.hmc.edu. Retrieved 2020-08-24.
- <sup>3.</sup> Malek-Shahmirzadi, Massoud (1983). "A characterization of certain classes of matrix norms". Linear and Multilinear Algebra. 13 (2): 97–99. doi:10.1080/03081088308817508. ISSN 0308-1087.
- <sup>4.</sup> ^ Horn, Roger A. (2012). Matrix analysis. Johnson, Charles R. (2nd ed.). Cambridge, UK: Cambridge University Press. pp. 340–341. <u>ISBN</u> 978-1-139-77600-4. OCLC 817236655.
- <sup>5.</sup> Carl D. Meyer, Matrix Analysis and Applied Linear Algebra, §5.2, p.281, Society for Industrial & Applied Mathematics, June 2000.
- 6. Ding, Chris; Zhou, Ding; He, Xiaofeng; Zha, Hongyuan (June 2006). R1-PCA: Rotational invariant L1-norm principal component analysis for robust subspace factorization. 23rd International Conference on Machine Learning. ICML '06. Pittsburgh, PA: <u>Association for Computing Machinery</u>. pp. 281–288.

- doi:10.1145/1143844.1143880. ISBN 1-59593-383-2.
- 7. Fan, Ky. (1951). "Maximum properties and inequalities for the eigenvalues of completely continuous operators". Proceedings of the National Academy of Sciences of the United States of America. 37 (11): 760–766.
  Bibcode:1951PNAS...37..760F. doi:10.1073/pnas.37.11.760. PMC 1063464.
  PMID 16578416.
- 8. Ciarlet, Philippe G. (1989). Introduction to numerical linear algebra and optimisation. Cambridge, England: Cambridge University Press. p. 57. ISBN 0521327881.
- 9. ^ Frieze, Alan; Kannan, Ravi (1999-02-01). "Quick Approximation to Matrices and Applications". Combinatorica. 19 (2): 175-220. doi:10.1007/s004930050052. ISSN 1439-6912. S2CID 15231198.
- 10. ^ <u>Lovász László</u> (2012). "The cut distance". Large Networks and Graph Limits. AMS Colloquium Publications. Vol. 60. Providence, RI: American Mathematical Society. pp. 127–131. <u>ISBN</u> 978-0-8218-9085-1. Note that Lovász rescales |A|<sub>□</sub> to lie in [0, 1].
- <sup>11.</sup> ^ Alon, Noga; Naor, Assaf (2004-06-13). "Approximating the cut-norm via Grothendieck's inequality". Proceedings of the thirty-sixth annual ACM symposium on Theory of computing. STOC '04. Chicago, IL, USA: Association for Computing Machinery. pp. 72–80. doi:10.1145/1007352.1007371. ISBN 978-1-58113-852-8. S2CID 1667427.
- <sup>12.</sup> Golub, Gene; Charles F. Van Loan (1996). Matrix Computations Third Edition. Baltimore: The Johns Hopkins University Press, 56–57. <u>ISBN</u> 0-8018-5413-X.
- <sup>13.</sup> Roger Horn and Charles Johnson. *Matrix Analysis*, Chapter 5, Cambridge University Press, 1985. <u>ISBN</u> 0-521-38632-2.
  - <u>James W. Demmel</u>, Applied Numerical Linear Algebra, section 1.7, published by SIAM, 1997.
  - Carl D. Meyer, Matrix Analysis and Applied Linear Algebra, published by SIAM,
     2000. [1]
  - <u>John Watrous</u>, Theory of Quantum Information, <u>2.3 Norms of operators</u>, lecture notes, University of Waterloo, 2011.
  - Kendall Atkinson, An Introduction to Numerical Analysis, published by John Wiley & Sons, Inc 1989