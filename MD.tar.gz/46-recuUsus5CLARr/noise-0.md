# Quantum state testing with restricted measurements

Cornell University Cornell University

Yuhan Liu Jayadev Acharya yl2976@cornell.edu acharya@cornell.edu

September 2, 2024

#### **Abstract**

We study quantum state testing where the goal is to test whether *ρ* = *ρ*<sup>0</sup> ∈ C *d*×*d* or k*ρ* − *ρ*0k<sup>1</sup> *> ε*, given *n* copies of *ρ* and a known state description *ρ*0. In practice, not all measurements can be easily applied, even using unentangled measurements where each copy is measured separately. We develop an information-theoretic framework that yields unified copy complexity lower bounds for restricted families of non-adaptive measurements through a novel *measurement information channel*. Using this framework, we obtain the optimal bounds for a natural family of *k*-outcome measurements with fixed and randomized schemes. We demonstrate a separation between these two schemes, showing the power of randomized measurement schemes over fixed ones. Previously, little was known for fixed schemes, and tight bounds were only known for randomized schemes with *k* ≥ *d* and Pauli observables, a special class of 2-outcome measurements. Our work bridges this gap in the literature.

A part of this work was published in the Proceedings of Conference on Learning Theory 2024. This work was supported by NSF award 1846300 (CAREER), NSF CCF-1815893, and a research scholar grant from Google.

# **Contents**

| 1 | Introduction<br>4                                                    |        |  |  |  |  |  |  |
|---|----------------------------------------------------------------------|--------|--|--|--|--|--|--|
|   | 1.1<br>Problem setup<br><br>1.1.1<br>Quantum states and measurements | 5<br>5 |  |  |  |  |  |  |
|   | 1.1.2<br>Quantum state testing with unentangled measurements<br>     | 5      |  |  |  |  |  |  |
|   | 1.2<br>Prior results                                                 | 6      |  |  |  |  |  |  |
|   | 1.3<br>New results<br>                                               | 6      |  |  |  |  |  |  |
|   | 1.4<br>Related work<br>                                              | 7      |  |  |  |  |  |  |
| 2 | Our techniques                                                       | 8      |  |  |  |  |  |  |
|   | 2.1<br>Lower bound via measurement information channel               | 8      |  |  |  |  |  |  |
|   | 2.2<br>The disadvantages of fixed measurements<br>                   | 9      |  |  |  |  |  |  |
|   | 2.3<br>A novel lower bound construction                              | 9      |  |  |  |  |  |  |
| 3 | Preliminaries                                                        | 10     |  |  |  |  |  |  |
|   | 3.1<br>Classical distribution testing                                | 10     |  |  |  |  |  |  |
|   | 3.2<br>Hibert space over linear operators                            | 11     |  |  |  |  |  |  |
| 4 | The measurement information channel (MIC)                            | 12     |  |  |  |  |  |  |
|   | 4.1<br>Properties of MIC<br>                                         | 12     |  |  |  |  |  |  |
|   | 4.2<br>Special case: Lüders channel                                  | 13     |  |  |  |  |  |  |
|   | 4.3<br>MIC characterizes distinguishability: a toy example           | 13     |  |  |  |  |  |  |
| 5 | Lower bound framework using MIC                                      | 14     |  |  |  |  |  |  |
|   | 5.1<br>The min-max and max-min chi-square divergences<br>            | 14     |  |  |  |  |  |  |
|   | 5.2<br>Relating chi-squared divergence to the MIC<br>                | 16     |  |  |  |  |  |  |
|   | 5.3<br>The new lower bound construction<br>                          | 17     |  |  |  |  |  |  |
|   | 5.4<br>Bounding the min-max and max-min divergences                  | 18     |  |  |  |  |  |  |
| 6 | Algorithm for randomized k-outcome measurements                      | 19     |  |  |  |  |  |  |
| 7 | Algorithm for fixed Pauli measurements                               | 21     |  |  |  |  |  |  |
|   | 7.1<br>Pauli observables                                             | 21     |  |  |  |  |  |  |
|   | 7.2<br>Algorithm                                                     | 22     |  |  |  |  |  |  |
| 8 | Algorithm for k-outcome fixed measurements                           | 22     |  |  |  |  |  |  |
|   | 8.1<br>Quantum designs and mutually unbiased basis<br>               | 22     |  |  |  |  |  |  |
|   | 8.2<br>Algorithm for k = d<br>                                       | 23     |  |  |  |  |  |  |
|   | 8.3<br>Algorithm for k < d<br>                                       | 24     |  |  |  |  |  |  |
|   | 8.4<br>Remarks                                                       | 26     |  |  |  |  |  |  |
| A | Proof of MIC properties                                              | 30     |  |  |  |  |  |  |
|   | A.1<br>Proof of Lemma 4.1<br>                                        | 30     |  |  |  |  |  |  |
|   | A.2<br>Proof of Lemma 4.3<br>                                        | 30     |  |  |  |  |  |  |
|   | A.3<br>Proof of Lemma 4.4<br>                                        | 31     |  |  |  |  |  |  |
| B | Missing proofs in the lower bound                                    | 32     |  |  |  |  |  |  |
|   | B.1<br>Proof of Theorem 5.6                                          | 32     |  |  |  |  |  |  |
|   | B.2<br>Proof of Theorem 5.9                                          | 34     |  |  |  |  |  |  |
|   | B.2.1<br>Proof of Lemma B.8<br>                                      | 36     |  |  |  |  |  |  |

| J Pro | of of quantum domain compression                                     |
|-------|----------------------------------------------------------------------|
| C.1   | Weingarten calculus                                                  |
|       | C.1.1 Partitions and permutations                                    |
|       | C.1.2 Weingartun functions                                           |
|       | C.1.3 Computing Haar integrals                                       |
| C.2   | Proof of Lemma 6.1                                                   |
|       | C.2.1 Upper bounding $\ \mathbf{p}_{\varrho}\ _{2}$                  |
|       | C.2.2 Lower bounding $\ \mathbf{p}_{\rho} - \mathbf{p}_{\rho_0}\ _2$ |
| C.3   | Upper bounding the 4th order terms                                   |
|       | C.3.1 Proof of Lemma C.5                                             |
|       | C.3.2 Proof of Lemma C.6                                             |

# <span id="page-3-0"></span>1 Introduction

We consider the problem of quantum state testing/certification [OW15, Wri16, BOW19], where the objective is to verify whether the output of a quantum system is a desired quantum state. It is a special case of quantum property testing where the goal is to test if a quantum state has a certain property [MdW16]. Property testing [Gol17, Can20] in general has gained significant attention in information theory and theoretical computer science. Specifically, given n copies of an unknown state  $\rho \in \mathbb{C}^{d \times d}$  and a known state description of  $\rho_0$ , we wish to use quantum measurements to determine whether  $\rho = \rho_0$  or  $\|\rho - \rho_0\|_1 > \varepsilon$ , where  $\|\cdot\|_1$  is the trace norm<sup>1</sup>. When  $\rho_0 = \rho_{\text{mm}} := \mathbb{I}_d/d$ , the maximally mixed state, the problem is called mixedness testing.

Our goal is to characterize the *copy complexity*, the minimum number of copies of unknown states to solve the testing problem. Prior work of [OW15, BOW19] showed that  $n = \Theta(d/\varepsilon^2)$  copies are necessary and sufficient. The dimension of quantum states is  $\sim d^2$ , and thus the copy complexity is sublinear in the dimension. However, their result relies on *entangled measurements*, where we treat the n copies of  $\rho$  as one giant state  $\rho^{\otimes n}$  and apply arbitrary measurements to it. This is extremely difficult in practice even for moderate values of d and n as it requires a quantum computer with a lot of qubits that can sustain coherence for a long time.

Thus, it is reasonable to study the problem under *measurement restrictions*, namely measurements that are easier to implement than an entangled measurement. Naturally, weaker measurement means more copies are needed, and the copy complexity may not be sublinear anymore. This leaves an important question,

Given a measurement restriction, can sublinear copy complexity be achieved for state certification?

Several works have considered unentangled measurements<sup>2</sup> where measurements are performed on one copy of  $\rho$  at a time. They are easier to implement than entangled measurements, and thus will be the focus of our work. There are three types of unentangled measurement schemes which determine how the measurement for each copy is chosen: **fixed**, **randomized**, and **adaptive**, in the order of increasing generality and power, which can lead to lower copy complexity at the cost of increasing difficulty in implementation. We introduce the formal definitions of these measurement schemes in Section 1.1.

When no further measurement restrictions are present, previous works have established the optimal copy complexity for quantum state certification for the three types of unentangled measurements. For randomized non-adaptive and adaptive schemes, the optimal copy complexity is  $\Theta(d^{3/2}/\varepsilon^2)$  [BCL20, CLHL22]. However, for deterministic schemes, the optimal copy complexity is  $n = \Theta(d^2/\varepsilon^2)$  [Yu21, LA24]. In short, randomness is necessary to achieve sublinear copy complexity.

The unentangled measurement schemes proposed in the previous works allow for arbitrary measurements to be performed on each copy. However, we still may not be able to apply arbitrary measurements to each copy and can only choose each measurement from a subset  $\mathfrak{M}$ . Due to physical restrictions, the measurement instrument may only have a finite number of outcomes. For example, a single-photon detector may only detect a finite number of photons in a fixed timeframe due to limited temporal resolution. Another notable example is the  $Pauli\ observables$ , a class of 2-outcome measurements associated with the Pauli operators which are simple to implement on quantum computers. Thus, it is practically reasonable to consider measurements with only a limited number of outcomes.

In this work, we study quantum state certification with restricted unentangled measurements, particularly focusing on the case when the number of potential outcomes of measurements is limited to at most k. This is an important step in understanding quantum property testing with restricted measurements. We extend the lower bound techniques in [LA24] to restricted measurements and design optimal algorithms for finite outcome measurements.

Previous works also considered other measures such as fidelity and Bures  $\chi^2$ -divergence, e.g. [BOW19].

<span id="page-3-2"></span><span id="page-3-1"></span><sup>&</sup>lt;sup>2</sup>Also called *incoherent* and *independent* measurements in previous literature

#### <span id="page-4-1"></span><span id="page-4-0"></span>1.1 Problem setup

#### 1.1.1 Quantum states and measurements

We first introduce notations and basics of quantum computing. We use the Dirac notation  $|\psi\rangle$  to denote a vector in  $\mathbb{C}^d$ .  $\langle\psi|:=(|\psi\rangle)^{\dagger}$  is the conjugate transpose, which is a row vector.  $\langle\psi|\phi\rangle$  is the Hibert-Schmidt inner product of  $|\psi\rangle$  and  $|\phi\rangle$ . We denote the set of all  $d\times d$  Hermitian matrices by  $\mathbb{H}_d$ . A d-dimensional quantum system is described by a positive-semidefinite Hermitian matrix  $\rho\in\mathbb{H}_d$  with  $\mathrm{Tr}[\rho]=1$ . We assume  $d=2^N$  where N is the number of qubits in the system.

Measurements are formulated as positive operator-valued measure (POVM). Let  $\mathcal{X}$  be an outcome set. Then a POVM  $\mathcal{M} = \{M_x\}_{x \in \mathcal{X}}$ , where  $M_x$  is p.s.d. and  $\sum_{x \in \mathcal{X}} M_x = \mathbb{I}_d$ . Let X be the outcome of measuring  $\rho$  with  $\mathcal{M}$ , then the probability observing  $x \in \mathcal{X}$  is given by the Born's rule,

$$\Pr[X = x] = \operatorname{Tr}[\rho M_x].$$

For measurements with at most k outcomes,  $\mathcal{X} = [k] := \{1, \dots, k\}$  is finite<sup>3</sup>, or equivalently  $\log_2 k$  bits of classical memory.

#### <span id="page-4-2"></span>1.1.2 Quantum state testing with unentangled measurements

Given n copies of an unknown state  $\rho \in \mathbb{H}_d$ , we wish to design

- n POVMs  $\mathcal{M}^n = (\mathcal{M}_1, \dots, \mathcal{M}_n)$ , where  $\mathcal{M}_i = \{M_x^{(i)}\}$  is applied to the ith copy and produce an outcome  $x_i$ , which follow a discrete distribution  $\mathbf{p}_{\rho}^{(i)} = [\mathbf{p}_{\rho}^{(i)}(1), \dots, \mathbf{p}_{\rho}^{(i)}(k)]$  where  $\mathbf{p}_{\rho}^{(i)}(x) = \text{Tr}[M_x^{(i)}\rho]$  is defined by the Born's rule. Define  $\mathbf{x} = (x_1, \dots, x_n) \in [k]^n$  to be the collection of all outomces.
- A tester  $T:[k]^n\mapsto \{\mathtt{YES},\mathtt{NO}\}$  that predicts whether  $\rho=\rho_0$  or  $\|\rho-\rho_0\|_1>\varepsilon$  based on the outcomes  $\mathbf{x}$ . We wish to guarantee that the answer is correct with probability at least 2/3,

$$\Pr_{\rho=\rho_0}(T(\mathbf{x}) = \mathtt{YES}) \geq \frac{2}{3}, \quad \text{and} \inf_{\rho: \|\rho-\rho_0\|_1 > \varepsilon} \Pr(T(\mathbf{x}) = \mathtt{NO}) \geq \frac{2}{3}.$$

When  $\rho_0 = \rho_{\rm mm} := \mathbb{I}_d/d$ , the problem is called *mixedness testing*. We wish to characterize the *copy complexity*, the minimum n such that there exists a tester and measurement scheme that achieves the desired 2/3 success probability for all  $\rho_0$ .

Given  $\mathcal{M}^n$ , we define  $\mathbf{P}_{\rho}$  as the distribution of all outcomes  $\mathbf{x}$  when the state is  $\rho$ . We formulate the three unentangled measurement schemes and their outcome distributions  $\mathbf{P}_{\rho}$  and discuss their advantages and drawbacks.

**Fixed.**  $\mathcal{M}_i$ 's are determined *before* receiving copies of  $\rho$ , and  $\mathbf{P}_{\rho} = \bigotimes_{i=1}^{n} \mathbf{p}_{\rho}^{(i)}$  is a product distribution.

A key advantage of such protocols is that the same set of measurements can be used for multiple repetitions of the testing problem. Moreover, there is no latency since the measurements are not designed after the states are made available, which is a drawback of the following protocols.

**Randomized non-adaptive.** There is a random seed  $R \sim \mathcal{R}$ , and each measurement  $\mathcal{M}_i = \mathcal{M}_i(R)$  is a function of R. Conditioned on  $R, \mathbf{P}_{\rho}$  is a product distribution.

Compared to fixed measurements, the drawback is that whenever we wish to run the task again, we need to select a new set of measurements using a new instance of the common randomness<sup>4</sup>. Preparing the new measurements can be costly, and in some cases, the random sampling process may not even be feasible.

<span id="page-4-3"></span> $<sup>^3</sup>$ The set  $\mathcal{X}$  can be countably or uncountably infinite. In both cases, POVMs and Born's rule can be generalized.

<span id="page-4-4"></span><sup>&</sup>lt;sup>4</sup>If the set of measurements is finite, we can prepare all measurements beforehand and sample with classical randomness. However, this could still be difficult if the set is very large.

**Adaptive.** The *i*th measurement depends on a random seed  $R \sim \mathcal{R}$  and all previous outcomes,  $\mathcal{M}_i = \mathcal{M}_i(x_1, \dots, x_{i-1}, R)$ . In general,  $\mathbf{P}_{\rho}$  is not a product distribution.

A primary drawback of this scheme is the latency and complications associated with designing measurements one after another. We note that since the first measurement outcome can be used as a source of common randomness, adaptive schemes are inherently randomized.

#### <span id="page-5-0"></span>1.2 Prior results

When there is no other constraint on measurements besides the measurement scheme, the copy complexity of quantum state certification is well understood. For entangled measurements, [OW15] showed that  $n = \Theta(d/\varepsilon^2)$  is necessary and sufficient for mixedness testing. [BOW19] further showed that  $n = O(d/\varepsilon^2)$  is sufficient for testing against all states  $\rho_0$ . [BCL20, CLO22] showed that for randomized non-adaptive measurements, the copy complexity is  $\Theta(d^{3/2}/\varepsilon^2)$ . [CLHL22] further showed that adaptivity does not help improve the copy complexity. The role of randomness in quantum state certification was very recently initiated. [Yu21] showed that  $n = O(d^2/\varepsilon^2)$  is sufficient. A recent work by [LA24] showed that  $n = \Omega(d^2/\varepsilon^2)$  is also necessary, thus demonstrating a separation with randomized measurements.

To our knowledge, the problem with measurement restrictions beyond measurement schemes has not been extensively studied. We are only aware of [Yu23] which showed that with randomized and non-adaptive Pauli observables,  $n = \Theta(d^2 \text{polylog}(d)/\varepsilon^2)$  copies are necessary and sufficient for state certification. However, the lower bound only holds for Pauli observables and is not general enough even for arbitrary two-outcome measurements. Thus, a huge mystery remains for measurements with a finite number of outcomes in the simplest non-adaptive setting, where we do not know whether the copy complexity can be sublinear, let alone the exact dependency on the number of outcomes. It is also unknown whether randomness helps, even for the simplest case of Pauli observables.

#### <span id="page-5-1"></span>1.3 New results

We prove copy complexity bounds for both randomized and fixed measurements for the problem of unentangled quantum state certification when each measurement is restricted to have at most k outcomes.

<span id="page-5-2"></span>Randomized measurements. We completely characterize the copy complexity for randomized non-adaptive finite-outcome measurements in Theorem 1.1.

**Theorem 1.1.** With randomized non-adaptive k-outcome measurements where  $k \geq 2$ ,

$$n = \Theta\left(\frac{d^2}{\varepsilon^2 \sqrt{\min\{k, d\}}}\right)$$

copies are necessary and sufficient to test whether  $\rho = \rho_0$  or  $\|\rho - \rho_0\|_1 > \varepsilon$  with probability at least 2/3.

Setting  $k \geq d$  recovers the  $\Theta(d^{3/2}/\varepsilon^2)$  bound for general randomized schemes in [BCL20]<sup>5</sup>.

<span id="page-5-4"></span>**Fixed measurements.** We further investigate whether randomization is necessary to achieve the tight bounds above and prove a tight bound for fixed measurements in Theorem 1.2.

**Theorem 1.2.** For all  $k \geq 2$ , with fixed unentangled k-outcome measurements,

$$n = \Theta\left(\frac{d^3}{\varepsilon^2 \min\{k, d\}}\right)$$

copies are necessary and sufficient to test whether  $\rho = \rho_0$  or  $\|\rho - \rho_0\|_1 > \varepsilon$  with probability at least 2/3.

<span id="page-5-3"></span><sup>&</sup>lt;sup>5</sup>The upper bound was corrected by [CLO22].

Setting  $k \ge d$  recovers the  $\Theta(d^2/\varepsilon^2)$  bound for general fixed measurement schemes in [Yu21, LA24]. Observe a large separation between the bounds in Theorems 1.1 and 1.2. To see it more clearly for each k, we set  $k = d^{\alpha}$  where  $\alpha \in (0, 1)$ . With randomness, the copy complexity in Theorem 1.1 is

$$n = \Theta(d^{2-\alpha/2}/\varepsilon^2),$$

which is sublinear (in the dimensionality of quantum states). Without randomness, Theorem 1.2 leads to a bound of

$$n = \Theta(d^{3-\alpha}/\varepsilon^2),$$

which is superlinear. Thus, the copy complexity changes from sublinear to superlinear only due to the lack of randomness. The ratio between fixed and randomized copy complexity is  $\Theta(d^{1-\alpha/2}/\varepsilon^2)$ , which is between  $\sqrt{d}$  and d. This result quantitatively demonstrates the power of randomness in quantum state testing.

For k=2 in Theorem 1.2, we design an optimal algorithm with fixed Pauli observables that uses  $n=O(d^3/\varepsilon^2)$  copies, thereby completely characterizing the copy complexity for fixed Pauli observables and 2-outcome measurements.

<span id="page-6-1"></span>**Theorem 1.3.** Using fixed Pauli observables or 2-outcome measurements,  $n = \Theta(d^3/\varepsilon^2)$  copies are necessary and sufficient to test whether  $\rho = \rho_0$  or  $\|\rho - \rho_0\|_1 > \varepsilon$  with probability at least 2/3.

Thus there is a strict separation with the bound of  $n = \tilde{\Theta}(d^2/\varepsilon^2)$  for random Pauli observables in [Yu23].

### <span id="page-6-0"></span>1.4 Related work

<span id="page-6-4"></span>Quantum state certification [BOW19, CLO22, Yu21, Yu23] proposed algorithms that also apply to closeness testing. [CLO22, CLHL22] went beyond worst-case bounds and derived near-optimal bounds for unentangled measurements that decrease when  $\rho_0$  is approximately low rank. While instance-optimal bounds have very important practical implications, we note that for finite-outcome measurements even the worst-case bounds were not known.

<span id="page-6-2"></span>Related quantum state inference problems Quantum tomography [OW16, Wri16, OW17, GKKT20, FO23] aims learn the full state description of the unknown state  $\rho$ . Tomography algorithms can be applied to state certification, though with far more samples than needed. For full rank  $\rho$ , to estimate up to  $\varepsilon$  in trace distance,  $\Theta(d^3/\varepsilon^2)$  copies are necessary and sufficient for unentangled measurements [KRT17, HHJ<sup>+</sup>17], even with adaptivity [CHL<sup>+</sup>23]. For non-adaptive Pauli observables, the bound is  $\Theta(d^4/\varepsilon^2)$  [FL11, LN22]. In particular, [LN22] developed a lower bound technique for measurements with constant number of outcomes, but their result is not explicitly stated for general k.

There are other closely related problems. [ON00, BHLP20, RLW23] studied hypothesis testing where the goal is to distinguish between two known states. Hypothesis selection [BO21, FFGO23] aims to determine  $\rho$  from a finite set of hypothesis sets. Shadow tomography [Aar20, HKP20, BKL<sup>+</sup>19] aims to learn the statistic of  $\rho$  over a finite set of observables.

<span id="page-6-3"></span>Classical distribution testing Quantum state certification is a generalization of the classical problem of testing discrete distributions, where the goal is to decide whether samples from an unknown distribution are from a desired distribution. Entangled measurement is analogous to the centralized setting where all samples are accessible in one place, while unentangled measurement is similar to the distributed case where samples are over multiple devices and not directly accessible.

Centralized testing of discrete distributions has been well-studied since [BFF<sup>+</sup>01, Pan08]. Recently, various works studied information-constrained testing in the distributed setting. [DJW13, ACFT21] focused on privacy-preserving information. [BHO20, ACT20c] considered communication-constrained inference where each device can only send limited bits for each sample. This is in some sense the classical equivalent of quantum state certification using unentangled finite-outcome measurements. Our framework is qualitatively similar to [ACT20b, ACL<sup>+</sup>22] which developed a unified lower bound framework for information-constrained testing and learning of distributions. We refer the readers to [Can22] for a survey of the above topics.

| Scheme     | Restricted (lower)                                                                             | Pauli                                 | $2 \le k < d$                       | $k \ge d$                       |
|------------|------------------------------------------------------------------------------------------------|---------------------------------------|-------------------------------------|---------------------------------|
| Randomized | $\frac{d^2}{\varepsilon^2 \max_{\mathcal{M}} \ \mathcal{H}_{\mathcal{M}}\ _{\mathrm{HS}}}$     | $\frac{d^2}{\varepsilon^2}^{\dagger}$ | $\frac{d^2}{\varepsilon^2\sqrt{k}}$ | $\frac{d^{3/2}}{\varepsilon^2}$ |
| Fixed      | $\frac{d^2}{\varepsilon^2} \cdot \frac{d}{\max_{\mathcal{M}} \ \mathcal{H}_{\mathcal{M}}\ _1}$ | $\frac{d^3}{\varepsilon^2}$           | $\frac{d^3}{\varepsilon^2 k}$       | $\frac{d^2}{\varepsilon^2}$     |

<span id="page-7-3"></span>Table 1: Existing and new worst-case copy complexity for quantum state certification with non-adaptive measurements. All results are constant-optimal unless otherwise indicated. New results are highlighted in blue. †: tight up to log factors.

**Organization.** In Section 2 we summarize our key technical contributions. In Section 3 we describe additional technical preliminaries. In Section 4 we introduce important properties of the measurement information channel. In Section 5 we prove the key lower bound of Theorem 2.2. In Section 6 we introduce the algorithm using randomized k-outcome measurements. We introduce the algorithms using fixed Pauli observables in Section 7 and general k-outcome measurements in Section 8.

# <span id="page-7-0"></span>2 Our techniques

### <span id="page-7-1"></span>2.1 Lower bound via measurement information channel

<span id="page-7-5"></span>One of our main contributions is a unified lower bound framework for restricted unentangled measurements which relates the hardness of testing to a novel measurement information channel (MIC).

**Definition 2.1.** Let  $\mathcal{M} = \{M_x\}_x$  be a POVM. The measurement information channel (MIC)  $\mathcal{H}_{\mathcal{M}} : \mathbb{C}^{d \times d} \mapsto \mathbb{C}^{d \times d}$  and its matrix representation  $\mathcal{C}_{\mathcal{M}}$  are defined as

$$\mathcal{H}_{\mathcal{M}}(A) := \sum_{x} M_{x} \frac{\text{Tr}[M_{x}A]}{\text{Tr}[M_{x}]}, \quad \mathcal{C}_{\mathcal{M}} := \sum_{x} \frac{|M_{x}\rangle\rangle\langle\langle M_{x}|}{\text{Tr}[M_{x}]} \in \mathbb{C}^{d^{2} \times d^{2}}, \tag{1}$$

where  $|M_x\rangle\rangle = \text{vec}(M_x)$  and  $\langle\langle M_x| = \text{vec}(M_x)^{\dagger}$ .

The channel maps a quantum state to another quantum state. Intuitively, it characterizes the similarity of the outcome distributions after applying  $\mathcal{M}$  to  $\rho$  and the maximally mixed state  $\rho_{\rm mm}$ . The ability to test against the maximally mixed state is described by the eigenvalues of the channel. In Theorem 2.2, we show a unified lower bound for non-adaptive measurements. Depending on the availability of randomness, the bound depends on different norms of  $\mathcal{H}_{\mathcal{M}}$ . We summarize Theorem 2.2 and the existing and new results for non-adaptive state certification in Table 1.

<span id="page-7-2"></span>**Theorem 2.2.** Let  $\mathfrak{M}$  be a set of allowable POVMs on a d-dimensional system. Let  $n_R$  and  $n_F$  be the copy complexity of mixedness testing for randomized and fixed unentangled measurements from  $\mathfrak{M}$  respectively. Then for  $d \geq 16$  and  $\varepsilon \leq 1/200$ ,

$$n_R = \Omega\left(\frac{d^2}{\varepsilon^2 \sup_{\mathcal{M} \in \mathfrak{M}} \|\mathcal{H}_{\mathcal{M}}\|_{HS}}\right), \quad n_F = \Omega\left(\frac{d^2}{\varepsilon^2} \cdot \frac{d}{\sup_{\mathcal{M} \in \mathfrak{M}} \|\mathcal{H}_{\mathcal{M}}\|_1}\right),$$

where  $\|\mathcal{H}_{\mathcal{M}}\|_{HS}$  is the Hilbert-Schmidt/Frobenius norm and  $\|\mathcal{H}_{\mathcal{M}}\|_1$  is the trace norm, which are  $\ell_2$  and  $\ell_1$  norms of the spectrum respectively.

By Cauchy-Schwarz,  $\|\mathcal{H}_{\mathcal{M}}\|_{\mathrm{HS}} \geq \|\mathcal{H}_{\mathcal{M}}\|_{1}/\sqrt{d^2}$  (because the spectrum has dimension  $d^2$ ). Thus the lower bound for  $n_R$  is smaller than that of  $n_F$ , which is consistent with that randomized measurements are more powerful than fixed ones. This plug-and-play result allows us to easily obtain lower bounds for any measurement set  $\mathfrak{M}$ , as long as we can upper bound the respective norms of the MICs in  $\mathfrak{M}$ . For k-outcome measurements, the bounds are stated in Lemma 2.3.

<span id="page-7-4"></span>**Lemma 2.3.** For a POVM  $\mathcal{M}$  with at most k outcomes,  $\|\mathcal{H}_{\mathcal{M}}\|_{HS}^2 \leq \|\mathcal{H}_{\mathcal{M}}\|_1 \leq \min\{k, d\}$ .

Combining Lemma 2.3 and Theorem 2.2 proves all lower bounds in Theorems 1.1 and 1.2.

<span id="page-8-4"></span>**Relation to** [LA24]. When  $M_x$  is rank-1, i.e.  $M_x = |\psi_x\rangle\langle\psi_x|$ , the MIC  $\mathcal{H}_{\mathcal{M}}$  is exactly the Lüders channel [DS19] which describes one possible form of expected post-measurement state after measuring with  $\mathcal{M}$ . However, their arguments using Lüders channel only hold for rank-1 POVMs. Our formulation using MIC is a necessary extension of their argument to arbitrary POVMs which may not be rank-1.

## <span id="page-8-0"></span>2.2 The disadvantages of fixed measurements

One of the key findings in Section 1.3 is the separation between fixed and randomized measurements. We explain the high-level reason why such separation exists through a simple example.

In randomized schemes, given the copies of the state, we then choose the measurements randomly. However, for fixed measurements, the measurement scheme is fixed and the state is then chosen by an imaginary adversary. Thus, without randomness, nature would have the opportunity to *adversarially* design a quantum state that fools the pre-defined set of measurements. When shared randomness is available, we can avoid the bad effect of adversarial choice of quantum states. In principle, this qualitative gap is like the difference between randomized algorithms and deterministic algorithms.

We use a simple example to demonstrate this idea. Suppose we choose each measurement  $\mathcal{M}_i$  simply to be the same canonical basis measurement, i.e.  $\mathcal{M}_i = \{|x\rangle\langle x|\}_{x=0}^{d-1}$ . Then nature can set  $\rho$  to be the "+" state where

<span id="page-8-3"></span>
$$\rho = |\phi\rangle\langle\phi|, \quad |\phi\rangle = \frac{1}{\sqrt{d}} \sum_{x=0}^{d-1} |x\rangle. \tag{2}$$

Note that the trace distance  $\frac{1}{2}\|\rho - \rho_{\rm mm}\|_1 = 1 - 1/d \simeq 1$ . When the underlying state is  $\rho$ , all measurement outcomes  $x_i$  would be independent samples from the uniform distribution over  $\{0, \ldots, d-1\}$ . However, if the state is the maximally mixed state  $\rho_{\rm mm}$ , the distribution of each measurement outcome would also be the uniform distribution over  $\{0, \ldots, d-1\}$ . Thus, even though the trace distance between  $\rho$  and  $\rho_{\rm mm}$  is large, the measurement scheme is completely fooled.

On the other hand, with shared randomness, one can (theoretically) sample a basis uniformly from the Haar measure as in [BCL20] to easily avoid this issue. No fixed  $\rho$  would be able to completely fool the randomized basis measurement sampled uniformly. In fact with high probability, the randomly sampled basis is good in the sense that the outcome distribution would be far enough when the two states  $\rho$  and  $\rho_{\rm mm}$  are far (see [CLO22, Lemma 6.3]).

Similar to [ACT20b], we develop a min-max and max-min framework to formally characterize the difference between fixed and randomized measurements.

#### <span id="page-8-1"></span>2.3 A novel lower bound construction

The design of hard instances has to account for the difference illustrated above when proving lower bounds for randomized and fixed measurements. In particular, for randomized measurements, the lower bound construction can be *measurement independent*. However, for fixed measurements, since the states can be chosen adversarially, the lower bound construction needs to be *measurement-dependent*.

Many prior works on testing and tomography [OW15, OW16, HHJ<sup>+</sup>17, BCL20, CCHL21, CLHL22] use measurement-independent distributions over states in  $\mathbb{C}^{d\times d}$  to prove lower bounds. In particular, [BCL20, CLHL22] show that testing within a specific class requires at least  $n = \Omega(d^{3/2}/\varepsilon^2)$  when working with randomized and adaptive unentangled measurements respectively. Unfortunately, these measurement-independent constructions are unable to capture the disadvantage of fixed measurements illustrated in our simple example in Section 2.2. We note that the lower bound construction in [Yu23] is measurement-dependent, but specifically tailored to Pauli measurements and not general enough for our purpose.

Our generic measurement-dependent lower bound construction is a necessary and novel contribution that leads to tight lower bounds for state certification with fixed measurements. It takes the form

<span id="page-8-2"></span>
$$\sigma_z = \rho_{\rm mm} + \frac{\varepsilon}{\sqrt{d}} \cdot \frac{c}{d} \sum_{i=1}^{d^2/2} z_i V_i, \tag{3}$$

where  $\{V_i\}_{i=1}^{d^2-1}$  are  $d^2-1$  orthonormal trace-0 Hermitian matrices,  $z=(z_1,\ldots,z_{d^2/2})$  are uniformly sampled from  $\{-1,1\}^{d^2/2}$ , and c is an absolute constant. In essence, we perform independent binary perturbations along different trace-0 directions. We show with appropriate choice of c, regardless of the choice of  $\{V_i\}_{i=1}^{d^2-1}$ , with high probability over the randomness of z,  $\sigma_z$  is a valid quantum state and  $\varepsilon$ -far in trace distance from  $\rho_{\rm mm}$ . The matrices  $V_i$ 's can be chosen dependent on the fixed measurement scheme that we want to fool. In particular, the perturbations  $V_1,\ldots,V_{d^2/2}$  can be chosen in directions about which the fixed measurement schemes provide the least information. The matrices  $V_i$ 's can also be fixed, in which case the construction is measurement-independent and our framework naturally leads to the lower bound for randomized non-adaptive measurements in [BCL20].

<span id="page-9-4"></span>**Relation to Paninski's construction [Pan08].** Our construction can be viewed as a generalization of Paninski's construction for classical discrete distribution testing where the hard instances are constructed as perturbations around the uniform distribution. Assume d is even and let  $z \in \{-1,1\}^{d/2}$ . For a distribution over [d] and some constant c,

<span id="page-9-2"></span>
$$\mathbf{p}_{z} = \frac{1}{d} (1 + c\varepsilon z_{1}, 1 - c\varepsilon z_{1}, \dots, 1 + c\varepsilon z_{t}, 1 - 4\varepsilon z_{t}, \dots, 1 + c\varepsilon z_{d/2}, 1 - c\varepsilon z_{d/2}).$$

$$(4)$$

We can see that each z defines a perturbation  $\mathbf{d}_z = \mathbf{p}_z - \mathbf{u}$  in the space of sum-zero vectors, and the number of such perturbations is d/2, the same order as the dimensionality of discrete distributions over [d]. In (3), we make trace-zero perturbations to the maximally mixed state along  $\Theta(d^2)$  different directions. Recall that the dimensionality of quantum states is  $d^2$ , and maximimally mixed state generalizes uniform distributions, our construction (3) can be viewed as a generalization of (4).

<span id="page-9-3"></span>Relation to previous quantum constructions. The binary perturbations in our construction are mathematically easier to handle than previous works. [BCL20, HHJ<sup>+</sup>17, CCHL21] designed the hard cases using random unitary transformations around the maximally-mixed state, which requires difficult calculations using Weingarten calculus [Wei78, Col03]. In contrast, our arguments avoid the difficult representation-theoretic tools. [CLHL22, CHL<sup>+</sup>23] used Gaussian orthogonal ensembles, which perturbs each matrix entry with independent Gaussian distributions. Binary perturbations share many statistical similarities with Gaussian since both are sub-gaussian distributions. However, the former is arguably simpler as the support is finite, and thus information-theoretic tools can be more easily applied. We note that all these constructions are somewhat inspired by Paninski's construction in [Pan08].

# <span id="page-9-1"></span><span id="page-9-0"></span>3 Preliminaries

### 3.1 Classical distribution testing

**Probability distances and divergences** Let  $\mathbf{p}$  and  $\mathbf{q}$  be distributions over a finite domain  $\mathcal{X}$ . The *total* variation distance is defined as

$$d_{\mathrm{TV}}(\mathbf{p}, \mathbf{q}) := \sup_{S \subseteq \mathcal{X}} (\mathbf{p}(S) - \mathbf{q}(S)) = \frac{1}{2} \sum_{x \in \mathcal{X}} |\mathbf{p}(x) - \mathbf{q}(x)|.$$

The KL-divergence is

$$\mathrm{KL}(\mathbf{p} \mid\mid \mathbf{q}) := \sum_{x \in \mathcal{X}} \mathbf{p}(x) \log \frac{\mathbf{p}(x)}{\mathbf{q}(x)}.$$

The chi-square divergence is

$$\mathrm{d}_{\chi^2}(\mathbf{p} \mid\mid \mathbf{q}) := \sum_{x \in \mathcal{X}} \frac{(\mathbf{p}(x) - \mathbf{q}(x))^2}{\mathbf{q}(x)}.$$

By Pinsker's inequality and concavity of logarithm,

$$2d_{\text{TV}}(\mathbf{p}, \mathbf{q})^2 \le \text{KL}(\mathbf{p} \parallel \mathbf{q}) \le d_{\chi^2}(\mathbf{p} \parallel \mathbf{q}).$$

We may also define  $\ell_p$  distances between distributions,  $\|\mathbf{p} - \mathbf{q}\|_p := \left(\sum_{x \in \mathcal{X}} |\mathbf{p}(x) - \mathbf{q}(x)|^p\right)^{1/p}$ .

<span id="page-10-2"></span>**Distribution testing under**  $\ell_2$  **distance** Testing discrete distributions under  $\ell_2$  distance is a well studied problem. The algorithm and its sample complexity is stated as follows.

**Theorem 3.1** ([DK16, Lemma 2.3]). Let  $\mathbf{p}$  be an unknown distribution and  $\mathbf{q}$  be a known target distribution over [k] such that  $\min\{\|p\|_2, \|q\|_2\} \leq b$ . Let  $\mathbf{x} = (x_1, \dots, x_n)$  be n i.i.d. samples from  $\mathbf{p}$ . There exists an algorithm TestIdentityL2( $\mathbf{q}, \mathbf{x}, \varepsilon, \delta$ ) that outputs YES if  $\mathbf{p} = \mathbf{q}$  and NO if  $\|\mathbf{p} - \mathbf{q}\|_2 > \varepsilon$  with probability at least  $1 - \delta$  using  $n = 1000b \log(1/\delta)/\varepsilon^2$  samples.

## <span id="page-10-0"></span>3.2 Hibert space over linear operators

Hilbert space over complex matrices. The space of complex matrices  $\mathbb{C}^{d\times d}$  is a Hilbert space with inner product

$$\langle A, B \rangle := \text{Tr}[A^{\dagger}B], A, B \in \mathbb{C}^{d \times d}.$$

For Hermitian matrices  $A, B, \langle A, B \rangle = \langle B, A \rangle \in \mathbb{R}$ . Thus the subspace of Hermitian matrices  $\mathbb{H}_d$  is a real Hilbert space (i.e. the associated field is  $\mathbb{R}$ ) with the same matrix inner product.

Vectorization defines a homomorphism between  $\mathbb{C}^{d\times d}$  and  $\mathbb{C}^{d^2}$ , where

$$\operatorname{vec}(|i\rangle\langle j|) := |j\rangle \otimes |i\rangle.$$

Vectorization for a general matrix A is defined through linearity. For convenience we denote  $|A\rangle\rangle := \text{vec}(A)$ . Matrix inner product can be written as inner product on  $\mathbb{C}^{d^2}$ ,  $\langle A, B \rangle = \langle \langle A|B \rangle \rangle$ .

(Linear) superoperators. Let  $\mathcal{N}: \mathbb{C}^{d \times d} \mapsto \mathbb{C}^{d \times d}$  be a linear operator over  $\mathbb{C}^{d \times d}$ , which we refer to as superoperators. Every superoperator  $\mathcal{N}$  has a matrix representation  $\mathcal{C}(\mathcal{N}) \in \mathbb{C}^{d^2 \times d^2}$  that satisfies

$$|\mathcal{N}(X)\rangle\rangle = \mathcal{C}(\mathcal{N})|X\rangle\rangle$$

for all matrices  $X \in \mathbb{C}^{d \times d}$ . It can be verified that for the measurement information channel  $\mathcal{H}_{\mathcal{M}}$  in Definition 2.1,  $\mathcal{C}_{\mathcal{M}}|A\rangle\rangle = |\mathcal{H}_{\mathcal{M}}(A)\rangle\rangle$ .

**Schatten norms.** Let  $\Lambda = (\lambda_1, \dots, \lambda_d) \geq 0$  be the *singular values* of a linear operator A, which can be a matrix or a superoperator. For Hermitian matrices, the singular values are the absolute values of the eigenvalues. Then for  $p \geq 1$ , the *Schatten p-norm* is defined as

$$||A||_{S_p} := ||\Lambda||_p.$$

The Schatten norms of a superoperator  $\mathcal{N}$  and its matrix representation  $\mathcal{C}(\mathcal{N})$  match exactly,  $\|\mathcal{N}\|_{S_p} = \|\mathcal{C}(\mathcal{N})\|_{S_p}$ . Some important special cases are trace norm

$$||A||_1 := ||A||_{S_1},$$

Hilbert-Schmidt norm

$$||A||_{\mathrm{HS}} := ||A||_{S_2} = \sqrt{\langle A, A \rangle},$$

<span id="page-10-1"></span><sup>&</sup>lt;sup>6</sup>This is to distinguish from a matrix  $A \in \mathbb{C}^{d \times d}$ , which can be viewed as an operator over  $\mathbb{C}^d$ . Indeed an operator over  $\mathbb{C}^{d \times d}$  need not be linear, but we only deal with linear ones in this work, so we drop "linear" for brevity.

and operator norm

$$||A||_{\text{op}} := ||A||_{S_{\infty}} = \max_{i=1}^{d} \lambda_i.$$

Due to Cauchy-Schwarz and monotonicity of  $\ell_p$  norms,

$$||A||_{HS} \le ||A||_1 \le \sqrt{d} ||A||_{HS}.$$

By Hölder's inequality,

$$||A||_{HS}^2 \le ||A||_{op} ||A||_1$$
.

# <span id="page-11-0"></span>4 The measurement information channel (MIC)

Recall for a measurement  $\mathcal{M}$ , the measurement information channel is

$$\mathcal{H}_{\mathcal{M}}(\rho) := \sum_{x} M_{x} \frac{\operatorname{Tr}[M_{x}\rho]}{\operatorname{Tr}[M_{x}]}.$$

It is a measure and prepare channel [KW21, Eq (4.4.82)] where upon measuring a quantum state  $\rho$  with  $\mathcal{M}$  and observing an outcome x, the system prepares the quantum state  $M_x/\operatorname{Tr}[M_x]$ . Its matrix representation is

$$\mathcal{C}_{\mathcal{M}} := \sum_{x} \frac{|M_x\rangle\rangle\langle\langle M_x|}{\text{Tr}[M_x]} \in \mathbb{C}^{d^2 \times d^2},$$

which satisfies  $\mathcal{C}_{\mathcal{M}}|A\rangle\rangle = |\mathcal{H}_{\mathcal{M}}(A)\rangle\rangle$  for all  $d \times d$  matrix A.

In this section, we first discuss some important properties of MIC. Then we study a special case that links MIC to a natural physical quantity. Finally, we use a simple example to show that the MIC of a measurement characterizes the power of distinguishability of this measurement.

# <span id="page-11-1"></span>4.1 Properties of MIC

<span id="page-11-2"></span>We introduce important properties of the MIC in Lemma 4.1. The proof is in Appendix A.1.

**Lemma 4.1.** Let  $\mathcal{M}$  be a POVM and  $\mathcal{H}_{\mathcal{M}}$  be the MIC with matrix representation  $\mathcal{C}_{\mathcal{M}}$ . Then

- 1.  $\mathcal{C}_{\mathcal{M}}$  is positive semi-definite.
- 2.  $\mathcal{H}_{\mathcal{M}}$  is unital, i.e.  $\mathcal{H}_{\mathcal{M}}(\mathbb{I}_d) = \mathbb{I}_d$ .
- 3.  $\mathcal{H}_{\mathcal{M}}$  is trace-preserving, i.e.  $\operatorname{Tr}[\mathcal{H}_{\mathcal{M}}(X)] = \operatorname{Tr}[X]$ .
- 4.  $\mathcal{H}_{\mathcal{M}}$  is Hermitian preserving, i.e. for all Hermitian X,  $\mathcal{H}_{\mathcal{M}}(X)$  is also Hermitian.

<span id="page-11-5"></span>An immediate corollary is that  $\mathcal{H}_{\mathcal{M}}$  has an eigen-decomposition where one eigenvector is  $\mathbb{I}_d$  and all other eigenvectors are trace-0 Hermitian matrices.

Corollary 4.2. For all POVM  $\mathcal{M}$ , there exists Hermitian matrices  $\mathcal{V} = (V_1, \dots, V_{d^2})$  with  $\text{Tr}[V_j] = 0$  for all  $j \leq d^2 - 1$  and  $V_{d^2} = \mathbb{I}_d / \sqrt{d}$  which form an orthonormal eigenbasis of  $\mathcal{H}_{\mathcal{M}}$ .

*Proof.* Since  $\mathcal{H}_{\mathcal{M}}$  is Hermitian preserving, it is a linear map from  $\mathbb{H}_d$  to  $\mathbb{H}_d$ . The dimension of  $\mathbb{H}_d$  is  $d^2$ . Thus, there exists  $d^2$  matrices  $V_1, \ldots, V_{d^2} \in \mathbb{H}_d$  which are eigenvectors of  $\mathcal{H}_{\mathcal{M}}$ .

Since  $\mathcal{H}_{\mathcal{M}}$  is unital,  $\mathbb{I}_d$  is an eigenvector of  $\mathcal{H}_{\mathcal{M}}$  with eigenvalue of 1. The eigenspace orthogonal to  $\mathbb{I}_d$  is exactly the trace-0 subspace because  $\langle \mathbb{I}_d, X \rangle = 0 \iff \operatorname{Tr}[\mathbb{I}_d X] = \operatorname{Tr}[X] = 0$ . Setting  $V_{d^2} = \mathbb{I}_d/\sqrt{d}$  and with appropriate normalization for the trace-0 eigenvectors, we obtain an orthonormal basis.

<span id="page-11-3"></span>We upper bound the operator norm in Lemma 4.3 and the trace norm in Lemma 4.4. The proofs are in Appendix A.2 and Appendix A.3 respectively.

**Lemma 4.3.** For all POVM  $\mathcal{M}$ ,  $\|\mathcal{H}_{\mathcal{M}}\|_{op} \leq 1$ .

<span id="page-11-4"></span>**Lemma 4.4.** For all POVM  $\mathcal{M}$  with at most k outcomes,  $\|\mathcal{H}_{\mathcal{M}}\|_1 \leq \min\{d, k\}$ .

By Hölder's inequality,  $\|\mathcal{H}_{\mathcal{M}}\|_{\mathrm{HS}}^2 \leq \|\mathcal{H}_{\mathcal{M}}\|_{\mathrm{op}} \|\mathcal{H}_{\mathcal{M}}\|_1 \leq \min\{d, k\}$ , which proves Lemma 2.3.

## <span id="page-12-0"></span>4.2 Special case: Lüders channel

Consider the family of rank-1 measurements  $\mathcal{M} = \{M_x\}$  where each  $M_x = |\psi_x\rangle\langle\psi_x|$  is rank-1. Note that  $|\psi_x\rangle$  may not be normalized. In the *unrestricted case* where we can choose arbitrary measurements for each copy, it is without loss of generality to only consider rank-1 measurements<sup>7</sup>. In this case, the MIC evaluates as

<span id="page-12-3"></span>
$$\mathcal{H}_{\mathcal{M}}(\rho) = \sum_{x=1}^{k} \frac{|\psi_x\rangle\langle\psi_x|\rho|\psi_x\rangle\langle\psi_x|}{\langle\psi_x|\psi_x\rangle} = \sum_{x=1}^{k} K_x \rho K_x, \ K_x = \frac{|\psi_x\rangle\langle\psi_x|}{\sqrt{\langle\psi_x|\psi_x\rangle}}.$$
 (5)

Note that  $K_x^2 = M_x$  so that  $K_x$  is the unique p.s.d. square-root of  $M_x$ .

In fact, (5) has a natural physical interpretation. When  $\mathcal{M}$  acts on  $\rho$  and we obtain an outcome x, then the generalized Lüder's rule [Lüd50] gives one possible form of the post-measurement state<sup>8</sup>,

$$\rho^x := \frac{K_x \rho K_x}{\text{Tr}[M_x \rho]}, \quad K_x = \sqrt{M_x}.$$

 $\mathcal{H}_{\mathcal{M}}(\rho)$  is exactly the expectation of  $\rho^x$  when x follows the outcome distribution defined by the Born's rule,

$$\mathcal{H}_{\mathcal{M}}(\rho) = \sum_{x} \rho^{x} \operatorname{Tr}[M_{x}\rho].$$

Thus, when  $\mathcal{M}$  is rank-1,  $\mathcal{H}_{\mathcal{M}}$  characterizes a natural physical process which describes one possible post-measurement state transition when the measurement outcome is not available, which is called Lüders channel [DS19, Lüd50]. As [LA24] proved, this channel characterizes the fundamental limit of testing: If two input states  $\rho$ ,  $\rho'$  lead to the same post-measurement state, then they are physically indistinguishable after measurement, let alone any algorithms that only rely on the measurement outcomes.

# <span id="page-12-1"></span>4.3 MIC characterizes distinguishability: a toy example

We use the same example in Section 2.2 to demonstrate how MIC characterizes the distinguishability of any fixed measurement. Recall that if we choose  $\mathcal{M} = \{|x\rangle\langle x|\}_{x=0}^{d-1}$ , then nature can set  $\rho$  to be the "+" state where

$$\rho = |\phi\rangle\langle\phi|, \quad |\phi\rangle = \frac{1}{\sqrt{d}} \sum_{x=0}^{d-1} |x\rangle.$$

We argued that both  $\rho$  and  $\rho_{\rm mm}$  yields the uniform distribution when measured with  $\mathcal{M}$  but their trace distance is nearly as large as it can be. Now we look at how MIC plays a role in this argument. For  $\mathcal{M} = \{|x\rangle\langle x|\}_{x=0}^{d-1}$ , the MIC is

$$\mathcal{H}_{\mathcal{M}}(\cdot) = \sum_{x=0}^{d-1} |x\rangle\langle x|(\cdot)|x\rangle\langle x|.$$

It turns out that  $\rho - \rho_{\rm mm}$  exactly falls into the 0-eigenspace of  $\mathcal{H}$ ,

$$\mathcal{H}_{\mathcal{M}}(\rho - \rho_{\mathrm{mm}}) = \sum_{x=0}^{d-1} |x\rangle\langle x|(\rho - \rho_{\mathrm{mm}})|x\rangle\langle x|$$
$$= \sum_{x=0}^{d-1} |x\rangle\langle x|\phi\rangle\langle\phi|x\rangle\langle x| - \sum_{x=0}^{d-1} |x\rangle\langle x| \frac{\mathbb{I}_d}{d} |x\rangle\langle x|$$

<span id="page-12-2"></span><sup>&</sup>lt;sup>7</sup>This is because if some  $M_x$  is not rank-1, then we can apply eigen-decomposition and write it as a sum of rank-1 projection matrices,  $M_x = \sum_j |\phi_{j,x}\rangle\langle\phi_{j,x}|$ . Replacing  $M_x$  with  $\{|\phi_{j,x}\rangle\langle\phi_{j,x}|\}_j$  only increases the power of the measurement because one outcome x can be represented using the collection of outcomes  $\{(j,x)\}_j$ . See [CCHL21, Lemma 4.8] for a formal proof.

<span id="page-12-4"></span><sup>&</sup>lt;sup>8</sup>The post-measurement states are undefined for general POVMs.

$$= \sum_{x=0}^{d-1} |x\rangle\langle x| \frac{1}{d} - \frac{\mathbb{I}_d}{d} = 0.$$

It is reasonable to believe that for any measurement  $\mathcal{M}$ , if the difference of two states  $\rho - \rho'$  fall into an eigenspace of  $\mathcal{H}_{\mathcal{M}}$  with small eigenvalues, then it is hard to distinguish  $\rho, \rho'$  with  $\mathcal{M}$ .

This toy example serves as a good intuition about the role of MIC in testing lower bound, but lacks rigorousness and does not generalize to randomized measurements and the case where measurement applied to each copy can be different. In the following sections, we will formalize this intuition by relating the hardness of testing to the MIC for general non-adaptive measurements.

# <span id="page-13-0"></span>5 Lower bound framework using MIC

This section is dedicated to proving the key lower bound result in Theorem 2.2. We focus on mixedness testing where  $\rho_0 = \rho_{\rm mm} := \mathbb{I}_d/d$ . For an arbitrary state  $\rho$  we define  $\Delta_{\rho} := \rho - \rho_{\rm mm}$ .

# <span id="page-13-1"></span>5.1 The min-max and max-min chi-square divergences

We use the Le Cam's method [LeC73, Yu97] to prove lower bounds. Recall that given measurement scheme  $\mathcal{M}^n$  and a state  $\rho$ , the distribution of the outcomes  $\mathbf{x}$  is  $\mathbf{P}_{\rho}$ . Let  $\mathcal{P}_{\varepsilon} := \{\rho : \|\rho - \rho_{\text{mm}}\|_1 > \varepsilon\}$  be states at least  $\varepsilon$  far from  $\rho_{\text{mm}}$  in trace distance. We define almost- $\varepsilon$  perturbations, which have constant probability mass over  $\mathcal{P}_{\varepsilon}$ .

**Definition 5.1.** A distribution  $\mathcal{D}$  over quantum states is an almost- $\varepsilon$  perturbation if  $\Pr_{\sigma \sim \mathcal{D}}[\sigma \in \mathcal{P}_{\varepsilon}] > \frac{1}{2}$ . Denote the set of almost- $\varepsilon$  perturbation as  $\Gamma_{\varepsilon}$ .

Consider a two-party game played between nature and an algorithm designer. Nature flips a coin Y where Y=0 or 1 with probability 1/2. If Y=1, then nature sets  $\rho=\rho_{\rm mm}$ . Applying  $\mathcal{M}^n$  on n copies, the outcomes  $\mathbf{x}\sim\mathbf{P}_{\rho_{\rm mm}}$ . If Y=0, nature chooses  $\mathcal{D}\in\Gamma_{\varepsilon}$  of its choice and samples  $\rho\sim\mathcal{D}$ . In this case, the outcomes  $\mathbf{x}\sim\mathbb{E}_{\rho\sim\mathcal{D}}[\mathbf{P}_{\rho}]$ . Using a mixedness tester, we should guess Y correctly with constant probability. By Le Cam's and Pinsker's inequality, this means that  $\mathrm{d}_{\chi^2}(\mathbb{E}_{\rho\sim\mathcal{D}}[\mathbf{P}_{\rho}] \mid\mid \mathbf{P}_{\rho_{\rm mm}})$  cannot be too small. Lemma 5.2 states the precise necessary conditions for the existence of a mixedness tester using fixed and randomized measurements.

<span id="page-13-2"></span>**Lemma 5.2** ([ACT20b, Lemma IV.8, IV.10]). If there exists a tester using fixed non-adaptive measurements with a success probability at least 2/3, then

<span id="page-13-3"></span>
$$\frac{2}{25} \le \max_{\mathcal{M}^n \ fixed \ \mathcal{D} \in \Gamma_{\varepsilon}} d_{\chi^2}(\mathbb{E}_{\sigma \sim \mathcal{D}}[\mathbf{P}_{\sigma}] \mid\mid \mathbf{P}_{\rho_{mm}}). \tag{6}$$

If there exists a tester using randomized non-adaptive measurements with 2/3 success rate, then

<span id="page-13-4"></span>
$$\frac{2}{25} \le \min_{\mathcal{D} \in \Gamma_{\varepsilon}} \max_{\mathcal{M}^n \ fixed} d_{\chi^2}(\mathbb{E}_{\sigma \sim \mathcal{D}}[\mathbf{P}_{\sigma}] || \mathbf{P}_{\rho_{mm}}). \tag{7}$$

*Proof.* Recall that Y=0 and  $\rho=\rho_{\rm mm}$  with probability 1/2 and Y=1 and  $\rho\sim\mathcal{D}$  with probability 1/2. First, we prove that for any measurement scheme  $\mathcal{M}^n$ , the chi-square divergence of outcome distributions should be far for Y=0 and Y=1.

In the former case when the state is  $\rho_{\rm mm}$  and Y=0, then the tester outputs the correct answer with probability at least 2/3,

$$\Pr[\hat{Y} = 0|Y = 0] \ge 2/3.$$

When  $\rho \sim \mathcal{D}$ , note that by the definition of almost- $\varepsilon$  perturbations, the probability that  $\|\sigma_z - \rho_{\rm mm}\|_1 > \varepsilon$  is at least 4/5. Denote this event as E, then  $\Pr[E|Y=1] \geq 4/5$ . We can lower bound the success probability as

$$\Pr[\hat{Y} = 1 | Y = 1] \ge \Pr[Y = 1 | E, Y = 1)] \Pr[E | Y = 1] \ge \frac{2}{3} \cdot \frac{4}{5} = \frac{8}{15}.$$

Combining the two parts,

$$\Pr[Y = \hat{Y}] = \frac{1}{2}\Pr[\hat{Y} = 0|Y = 0] + \frac{1}{2}\Pr[\hat{Y} = 1|Y = 1] \ge \frac{1}{2}\left(\frac{2}{3} + \frac{8}{15}\right) = \frac{3}{5}.$$

By Le Cam's method [LeC73, Yu97],

$$1 - \frac{3}{5} \ge \frac{1}{2} (1 - d_{\text{TV}}(\mathbb{E}_z[\mathbf{P}_{\sigma_z}], \mathbf{P}_{\rho_{\text{mm}}})) \implies d_{\text{TV}}(\mathbb{E}_z[\mathbf{P}_{\sigma_z}], \mathbf{P}_{\rho_{\text{mm}}}) \ge \frac{1}{5}.$$

Using Pinsker's inequality and the relation between KL and chi-square divergences, we have,

$$\frac{1}{5} \leq d_{\text{TV}}(\mathbb{E}_{\sigma}[\mathbf{P}_{\sigma}], \mathbf{P}_{\rho_{\text{mm}}}) \leq \sqrt{\frac{1}{2} \text{KL}(\mathbb{E}_{\sigma \sim \mathcal{D}}[\mathbf{P}_{\sigma}] || \mathbf{P}_{\rho_{\text{mm}}})} \leq \sqrt{\frac{1}{2} d_{\chi^{2}}(\mathbb{E}_{\sigma \sim \mathcal{D}}[\mathbf{P}_{\sigma}] || \mathbf{P}_{\rho_{\text{mm}}})}.$$

Rearranging the terms,

<span id="page-14-0"></span>
$$\frac{2}{25} \le d_{\chi^2}(\mathbb{E}_{\sigma \sim \mathcal{D}}[\mathbf{P}_{\sigma}] || \mathbf{P}_{\rho_{mm}}). \tag{8}$$

Now we apply (8) to fixed and randomized measurements to arrive at the min-max and max-min expressions.

For a fixed measurement scheme  $\mathcal{M}^n$ , nature can choose a  $\mathcal{D} \in \Gamma_{\varepsilon}$  that minimizes the chi-square divergence in (8). According to (8), if there exists a fixed  $\mathcal{M}^n$  that achieves at least 2/3 probability in testing maximally mixed states, we must have

$$\frac{2}{25} \leq \max_{\mathcal{M}^n \text{ fixed } \min_{\mathcal{D} \in \Gamma_{\varepsilon}} d_{\chi^2}(\mathbb{E}_{\sigma \sim \mathcal{D}}[\mathbf{P}_{\sigma}] \mid\mid \mathbf{P}_{\rho_{\min}}).$$

Thus a max-min game is played between the two parties and nature has an advantage to decide its best action based on the choice of the algorithm designer.

With randomness, in principle, a max-min game is still played, but instead, the maximization is over all distributions of fixed (non-entangled) measurements. Using a similar argument as [ACT20b, Lemma IV.8], for the best distribution over all  $\mathcal{M}^n$ , the expected accuracy over  $R \sim \mathcal{R}$  is at least 1/2 for all  $\mathcal{D} \in \Gamma_{\varepsilon}$ . Thus, for all  $\mathcal{D}$ , there must exist an instantiation  $R(\mathcal{D})$  such that using the fixed measurement  $\mathcal{M}^n(R(\mathcal{D}))$  the testing accuracy is at least 1/2. Therefore,

$$\frac{2}{25} \leq \min_{\mathcal{D} \in \Gamma_{\varepsilon}} \max_{\mathcal{M}^n \text{ fixed}} d_{\chi^2}(\mathbb{E}_{\sigma \sim \mathcal{D}}[\mathbf{P}_{\sigma}] \mid\mid \mathbf{P}_{\rho_{\mathrm{mm}}}),$$

which intuitively says that a min-max game is played and the algorithm designer has an advantage.  $\Box$ 

The intuition of Lemma 5.2 is that nature and the algorithm designer play a two-party game, where the algorithm designer tries to maximize the chi-square divergence, while nature picks  $\mathcal{D} \in \Gamma_{\varepsilon}$  that minimizes it and fools the algorithm. For fixed measurements, nature can choose the distribution  $\mathcal{D} \in \Gamma_{\varepsilon}$  adversarially depending on the measurement scheme. With randomness, measurements are instantiated after the states are given, which puts the algorithm designer at a second-mover advantage. The min-max and max-min arguments are similar to [ACT20b] and we point to [ACT20b, Lemma IV.8, IV.10] for additional reference.

Therefore, to obtain a copy complexity lower bound for fixed measurements requires upper bounding (6), while for randomized schemes requires upper bounding (7). We can see that randomness is a "game changer" that changes a max-min game to a min-max game. Since min-max is no smaller than max-min, testing with randomness is easier than testing without it. This formalizes the intuition we established from the toy example in Section 2.2.

## <span id="page-15-0"></span>5.2 Relating chi-squared divergence to the MIC

Our central contribution is that we relate the min-max and max-min divergences to the average measurement information channel defined by  $\mathcal{M}^n$ . Define the shorthand  $\mathcal{H}_i := \mathcal{H}_{\mathcal{M}_i}$  and  $\mathcal{C}_i := \mathcal{C}_{\mathcal{M}_i}$ , the channel  $\overline{\mathcal{H}}$  and its matrix representation  $\overline{\mathcal{C}}$  are defined as

<span id="page-15-3"></span>
$$\overline{\mathcal{H}} = \frac{1}{n} \sum_{i=1}^{n} \mathcal{H}_i, \quad \overline{\mathcal{C}} := \frac{1}{n} \sum_{i=1}^{n} \mathcal{C}_i.$$
(9)

<span id="page-15-1"></span>Due to linearity, Lemma 4.1 and Corollary 4.2 hold for  $\overline{\mathcal{H}}, \overline{\mathcal{C}}$ . The key technical result is Lemma 5.3 which upper bounds  $d_{\chi^2}(\mathbb{E}_{\sigma \sim \mathcal{D}}[\mathbf{P}_{\sigma}] || \mathbf{P}_{\rho_{mm}})$  for fixed measurements using the average MIC.

**Lemma 5.3.** Let  $\sigma, \sigma'$  be independently drawn from a distribution  $\mathcal{D}$ , and  $\mathcal{M}^n = (\mathcal{M}_1, \dots, \mathcal{M}_n)$  be a fixed measurement scheme. Define  $\Delta_{\sigma} = \sigma - \rho_{mm}$ . Then

$$d_{\chi^{2}}(\mathbb{E}_{\sigma \sim \mathcal{D}}[\mathbf{P}_{\sigma}] || \mathbf{P}_{\rho_{mm}}) \leq \mathbb{E}_{\sigma, \sigma' \sim \mathcal{D}}[\exp\{nd \cdot \langle\langle \Delta_{\sigma} | \overline{\mathcal{C}} | \Delta_{\sigma'} \rangle\rangle\}] - 1$$
(10)

where  $\overline{\mathcal{C}}$  is the matrix representation of the average measurement information channel.

<span id="page-15-2"></span>*Proof.* We can directly bound the chi-square divergence using the following lemma.

**Lemma 5.4** ([Pol03]). Let  $\mathbf{P} = \mathbf{p}^{(1)} \otimes \cdots \otimes \mathbf{p}^{(n)}$  be a fixed product distribution and  $\mathbf{Q}_{\theta} = \mathbf{q}_{\theta}^{(1)} \otimes \cdots \otimes \mathbf{q}_{\theta}^{(n)}$  be parameterized by a random variable  $\theta$ . Then

$$d_{\chi^2}(\mathbb{E}_{\theta}[\mathbf{Q}_{\theta}] || \mathbf{P}) = \mathbb{E}_{\theta, \theta'} \left[ \prod_{i=1}^n (1 + H_i(\theta, \theta')) \right] - 1,$$

where  $\theta'$  is an independent copy, and  $H_i(\theta, \theta') := \mathbb{E}_{x \sim \mathbf{p}^{(i)}} \left[ \delta_{\theta}^{(i)}(x) \delta_{\theta'}^{(i)}(x) \right], \ \delta_{\theta}^{(i)}(x) := \frac{\mathbf{q}_{\theta}^{(i)}(x) - \mathbf{p}^{(i)}(x)}{\mathbf{p}^{(i)}(x)}$ 

We apply Lemma 5.4 with  $\mathbf{P} = \mathbf{P}_{\rho_{\text{mm}}}$  and  $\mathbf{Q}_{\sigma} = \mathbf{P}_{\sigma}$ , so that  $\delta_{\sigma}^{(i)}(x) = \left(\mathbf{p}_{\sigma}^{(i)}(x) - \mathbf{p}_{\rho_{\text{mm}}}^{(i)}(x)\right)/\mathbf{p}_{\rho_{\text{mm}}}^{(i)}(x)$ . We can now evaluate  $H_i(\sigma, \sigma')$  by expanding the probabilities with the Born's rule,

$$H_{i}(\sigma, \sigma')$$

$$= \mathbb{E}_{x \sim \mathbf{p}_{\rho_{\text{mm}}}^{(i)}} \left[ \frac{(\mathbf{p}_{\sigma}^{(i)}(x) - \mathbf{p}_{\rho_{\text{mm}}}^{(i)}(x))(\mathbf{p}_{\sigma'}^{(i)}(x) - \mathbf{p}_{\rho_{\text{mm}}}^{(i)}(x))}{(\mathbf{p}_{\rho_{\text{mm}}}^{(i)}(x))^{2}} \right]$$

$$= \sum_{x} \frac{(\mathbf{p}_{\sigma}^{(i)}(x) - \mathbf{p}_{\rho_{\text{mm}}}^{(i)}(x))(\mathbf{p}_{\sigma'}^{(i)}(x) - \mathbf{p}_{\rho_{\text{mm}}}^{(i)}(x))}{\mathbf{p}_{\rho_{\text{mm}}}^{(i)}(x)}$$

$$= \sum_{x} \frac{\text{Tr}[M_{x}^{(i)}(\sigma - \rho_{\text{mm}})] \text{Tr}[M_{x}^{(i)}(\sigma' - \rho_{\text{mm}})]}{\text{Tr}[M_{x}^{(i)}]/d}$$

$$= d\sum_{x} \frac{\langle \langle \sigma - \rho_{\text{mm}} | M_{x}^{(i)} \rangle \rangle \langle \langle M_{x}^{(i)} | \sigma' - \rho_{\text{mm}} \rangle \rangle}{\text{Tr}[M_{x}]}$$
(Matrix inner product)
$$= d\langle \langle \Delta_{\sigma} | \mathcal{C}_{i} | \Delta_{\sigma'} \rangle \rangle.$$

Then, using Lemma 5.4, and the fact that  $1 + x \leq \exp(x)$ ,

$$d_{\chi^{2}}(\mathbb{E}_{\sigma \sim \mathcal{D}}[\mathbf{P}_{\sigma}] || \mathbf{P}_{\rho_{mm}}) = \mathbb{E}_{\sigma, \sigma'} \left[ \prod_{i=1}^{n} (1 + H_{i}(\sigma, \sigma')) \right] - 1$$

$$\leq \mathbb{E}_{\sigma, \sigma'} \left[ \exp \left\{ \sum_{i=1}^{n} H_{i}(\sigma, \sigma') \right\} \right] - 1$$

$$= \mathbb{E}_{\sigma,\sigma'} \left[ \exp \left\{ d \sum_{i=1}^{n} \langle \langle \Delta_{\sigma} | \mathcal{C}_{i} | \Delta_{\sigma'} \rangle \rangle \right\} \right] - 1$$
$$= \mathbb{E}_{\sigma,\sigma'} \left[ \exp \left\{ n d \langle \langle \Delta_{\sigma} | \overline{\mathcal{C}}_{i} | \Delta_{\sigma'} \rangle \rangle \right\} \right] - 1.$$

The last step follows by linearity and that  $\overline{C} = \frac{1}{n} \sum_{i=1}^{n} C_i$ .

Explaining the example in Section 2.2. We now use Lemma 5.3 to explain why choosing a fixed basis measurement  $\{|x\rangle\langle x|\}_{x=0}^{d-1}$  for all copies as in Section 2.2 would fail. Since there are only d rank-1 projectors, the rank of  $\overline{\mathcal{C}}$  is d, but  $\overline{\mathcal{C}}$  has a dimension of  $d^2 \times d^2$  and thus there are a total of  $d^2 - d$  eigenvectors with 0 eigenvalues. From Corollary 5.8, we know that there must exist a trace-0  $\Delta$  in the 0-eigenspace such that  $\sigma = \rho_{\text{mm}} + \Delta \in \mathcal{P}_{\varepsilon}$ . For this particular  $\sigma$  the upper bound in (10) is 0, and thus it is impossible to distinguish  $\rho_{\text{mm}}$  and  $\sigma$ . This is consistent with the discussion in Section 2.2.

We can make a more general argument that to avoid the catastrophic failure similar to the dummy example in Section 2.2,  $\overline{\mathcal{C}}$  has to be nearly full-rank: rank( $\overline{\mathcal{C}}$ )  $\geq (1-o(1))d^2$ . Thus  $(1-o(1))d^2$  linearly independent components are needed in all the POVMs. Indeed if otherwise, the dimension of the 0-eigenspace of  $\overline{\mathcal{H}}$  is  $\Omega(d^2)$ , we can again invoke Corollary 5.8 (perhaps with some different constants) to find a *single* fixed  $\sigma$  that completely fools the measurement scheme.

#### <span id="page-16-0"></span>5.3 The new lower bound construction

We now describe a generic construction of a distribution over density matrices that will serve as hard case for both fixed and randomized measurements. We will take a finite set of trace-0 orthonormal Hermitian matrices. Then, we take a linear combination of these matrices with coefficients chosen at random to be  $\pm 1$  (appropriately normalized). When we add maximally mixed state  $\rho_{\rm mm}$  to this distribution's output we obtain a perturbed distribution around  $\rho_{\rm mm}$ .

The construction is defined in Definition 5.5. As discussed in Section 2.3, it can be viewed as a generalization of Paninski's construction Eq. (4) frequently used for discrete distribution learning and testing.

<span id="page-16-2"></span>**Definition 5.5.** Let  $\ell \in [\frac{d^2}{2}, \dim^2 -1]$  and  $\mathcal{V} = (V_1, \dots, V_{d^2} = \frac{\mathbb{I}_d}{\sqrt{d}})$  be an orthonormal basis of  $\mathbb{H}_d$ , and c be a universal constant. Let  $z = (z_1, \dots, z_\ell)$  be uniformly drawn from  $\{-1, 1\}^{\ell}$ ,

$$\Delta_z = \frac{c\varepsilon}{\sqrt{d}} \cdot \frac{1}{\sqrt{\ell}} \sum_{i=1}^{\ell} z_i V_i, \quad \overline{\Delta}_z = \Delta_z \min\left\{1, \frac{1}{d\|\Delta_z\|_{\text{op}}}\right\}. \tag{11}$$

Finally we set  $\sigma_z = \rho_{\rm mm} + \overline{\Delta}_z$  whose distribution we denote as  $\mathcal{D}_c(\mathcal{V})$ .

The goal of normalizing  $\Delta_z$  is to ensure that  $\sigma_z$  is a valid density matrix. However, after normalization, the trace distance  $\|\sigma_z - \rho_{\rm mm}\|_1$  may not be greater than  $\varepsilon$ . Nevertheless, we can show that the probability of this bad event is negligible. The central claim is Theorem 5.6 which states that the operator norm of a random matrix with independently perturbed orthogonal components is  $O(\sqrt{d})$  with high probability. The proof is in Appendix B.1.

<span id="page-16-1"></span>**Theorem 5.6.** Let  $V_1, \ldots, V_{d^2} \in \mathbb{C}^{d \times d}$  be an orthonormal basis of  $\mathbb{C}^{d \times d}$  and  $z_1, \ldots, z_{d^2} \in \{-1, 1\}$  be independent symmetric Bernoulli random variables. Let  $W = \sum_{i=1}^{\ell} z_i V_i$  where  $\ell \leq d^2$ . For all  $\alpha > 0$ , there exists  $\kappa_{\alpha}$ , which is increasing in  $\alpha$  such that

$$\Pr[\|W\|_{op} > \kappa_{\alpha}\sqrt{d}] \le 2\exp\{-\alpha d\}.$$

<span id="page-16-3"></span>Remark 5.7. Standard random matrix theory (e.g. [Tao23][Corollary 2.3.5]) states that if each entry of W is independent and uniform from  $\{-1,1\}$ , i.e.  $W = \sum_{i,j} z_{ij} E_{ij}$  where  $E_{ij}$  is a matrix with 1 at position (i,j) and 0 everywhere else, then  $\|W\|_{\text{op}} = O(\sqrt{d})$  with high probability. Theorem 5.6 generalizes this argument to arbitrary basis  $\{V_i\}_{i=1}^{d^2}$ . This could be of independent interest.

<span id="page-17-2"></span>An immediate corollary of Theorem 5.6 is that with appropriately chosen constant c in Definition 5.5,  $\sigma_z$  is  $\varepsilon$  far from  $\rho_{\rm mm}$  with overwhelming probability, so that we can almost neglect the effect of normalization.

Corollary 5.8. Let  $d^2/2 \le \ell \le d^2 - 1$ . Let z be drawn from a uniform distribution over  $\{-1,1\}^{\ell}$ , and  $\Delta_z, \sigma_z$  are as defined in Definition 5.5. Then, there exists a universal constant  $c \le 10\sqrt{2}$ , such that for  $\varepsilon < \frac{1}{c^2}$ , with probability at least  $1 - 2\exp(-d)$ ,  $\|\Delta_z\|_{op} \le 1/d$  and  $\|\Delta_z\|_1 \ge \varepsilon$ .

*Proof.* By Hölder's inequality, we have that for all matrices A,

$$||A||_{\text{op}} ||A||_1 \ge ||A||_{\text{HS}}^2$$
.

Note that  $\Delta_z = \frac{c\varepsilon}{\sqrt{d\ell}}W$  and  $\|\Delta_z\|_{\mathrm{HS}} = \frac{c\varepsilon}{\sqrt{d}}$ . Thus setting  $\alpha = 1$  and  $\kappa = \kappa_1$  in Theorem 5.6, with probability at least  $1 - 2\exp(-d)$ ,

$$\|\Delta_z\|_{\text{op}} \le \frac{c\varepsilon}{\sqrt{d\ell}} \cdot \kappa \sqrt{d} = \frac{c\kappa\varepsilon}{\sqrt{\ell}}.$$

This implies that

$$\|\Delta_z\|_1 \ge \|\Delta_z\|_{\mathrm{HS}}^2 / \|\Delta_z\|_{\mathrm{op}} \ge \frac{c\varepsilon}{\kappa} \cdot \frac{\sqrt{\ell}}{d}.$$

In the proof of Theorem 5.6 in Appendix B.1, we can show that  $\kappa = \kappa_1 \le 10$ . Thus choosing  $c = \sqrt{2}\kappa \le 10\sqrt{2}$ , we guarantee that  $\|\Delta_z\|_1 > \varepsilon$  due to  $\ell \ge d^2/2$ . As long as  $\varepsilon \le \frac{1}{200}$ , we have  $\|\Delta_z\|_{\rm op} \le 1/d$  and thus  $\sigma_z = \rho_{\rm mm} + \Delta_z$  is a valid density matrix. This completes the proof of Corollary 5.8.

## <span id="page-17-0"></span>5.4 Bounding the min-max and max-min divergences

To complete the lower bound proof, we apply Lemma 5.3 to our new lower bound construction in Definition 5.5.

Different bounds for min-max and max-min divergences in Lemma 5.2 are due to whether or not nature can choose the basis  $\mathcal{V}$  dependent on  $\overline{\mathcal{H}}$ , which in turn depends on the measurements  $\mathcal{M}^n$ . For randomized schemes, we need to upper bound the min-max divergence, and we can simply choose a fixed  $\mathcal{V}$  that is uniformly bad for all  $\mathcal{M}^n$ . For fixed measurements, however, under the max-min framework, nature could choose the hard distribution depending on  $\mathcal{M}^n$ . Specifically, with  $\mathcal{V} = \mathcal{V}_{\overline{\mathcal{H}}}$  and  $\ell$  small,  $\sigma_z - \rho_{\text{mm}}$  completely lies in an eigenspace of  $\overline{\mathcal{H}}$  with the  $\ell$  smallest eigenvalues, thus generalizing the intuition from the toy example in Section 4.3.

Theorem 5.9 upper bounds the chi-square divergence in (10) for the construction in Definition 5.5. We obtain different bounds depending on the choice of  $\mathcal{V}$ . Specifically, if  $\mathcal{V}$  is the eigenbasis of  $\overline{\mathcal{H}}$  where  $V_1, \ldots, V_{\ell}$  have the smallest eigenvalues, the upper bound would be much tighter.

<span id="page-17-1"></span>**Theorem 5.9.** Let  $V = (V_1, \dots, V_{d^2} = \frac{\mathbb{I}_d}{\sqrt{d}})$  be an orthonormal basis of  $\mathbb{H}_d$ , and  $\mathfrak{M}$  be the set of allowed POVMs. Let  $\sigma, \sigma' \sim \mathcal{D}_c(V)$  and  $\Delta_{\sigma} = \sigma - \rho_{mm}$ . Then for  $n \leq \frac{d^2}{6c^2\varepsilon^2 \max_{\mathcal{M} \in \mathfrak{M}} \|\mathcal{H}_{\mathcal{M}}\|_{HS}}$ ,

<span id="page-17-3"></span>
$$\log \mathbb{E}_{\sigma,\sigma'} \left[ \exp \left\{ nd \cdot \left\langle \left\langle \Delta_{\sigma} | \overline{C} | \Delta_{\sigma'} \right\rangle \right\rangle \right\} \right] = O\left( \frac{n^2 \varepsilon^4}{d^4} \max_{\mathcal{M} \in \mathfrak{M}} \left\| \mathcal{H}_{\mathcal{M}} \right\|_{HS}^2 \right). \tag{12}$$

If V is the eigenbasis of  $\overline{\mathcal{H}}$  with eigenvalues  $\lambda(V_1) \leq \cdots \leq \lambda(V_{d^2})$ , then for  $n \leq \frac{d^3}{9c^2\varepsilon^2 \max_{\mathcal{M} \in \mathfrak{M}} \|\mathcal{H}_{\mathcal{M}}\|_1}$ ,

<span id="page-17-4"></span>
$$\log \mathbb{E}_{\sigma,\sigma'} \Big[ \exp \left\{ nd \cdot \langle \langle \Delta_{\sigma} | \overline{\mathcal{C}} | \Delta_{\sigma'} \rangle \rangle \right\} \Big] = O\left( \frac{n^2 \varepsilon^4}{d^6} \max_{\mathcal{M} \in \mathfrak{M}} \|\mathcal{H}_{\mathcal{M}}\|_1^2 \right). \tag{13}$$

We defer the proof to Appendix B.2 and proceed to prove the main result Theorem 2.2. For randomized measurements, we choose  $\mathcal{V}$  to be an arbitrary basis that satisfies Definition 5.5 (e.g. the generalized Gell-Mann basis, or the Pauli basis). Then combining (7) (10) (12), we must have

$$\frac{2}{25} \le \exp\left\{O\left(\frac{n^2 \varepsilon^4}{d^4} \max_{\mathcal{M} \in \mathfrak{M}} \|\mathcal{H}_{\mathcal{M}}\|_{\mathrm{HS}}^2\right)\right\} - 1.$$

Therefore  $n = \Omega\left(\frac{d^2}{\varepsilon^2 \max_{\mathcal{M} \in \mathfrak{M}} \|\mathcal{H}_{\mathcal{M}}\|_{\mathrm{HS}}}\right)$  for randomized measurements.

To bound the max-min divergence (6) for fixed measurements, for all fixed  $\mathcal{M}^n$  we choose we  $\mathcal{V}$  as stated in Theorem 5.9. Combining (6) (10) (13),

$$\frac{2}{25} \le \exp\left\{O\left(\frac{n^2 \varepsilon^4}{d^6} \max_{\mathcal{M} \in \mathfrak{M}} \|\mathcal{H}_{\mathcal{M}}\|_1^2\right)\right\} - 1.$$

Rearranging the terms we get  $n = \Omega\left(\frac{d^3}{\varepsilon^2 \max_{\mathcal{M} \in \mathfrak{M}} \|\mathcal{H}_{\mathcal{M}}\|_1}\right)$  for fixed measurements. This completes the proof of Theorem 2.2.

# <span id="page-18-0"></span>Algorithm for randomized k-outcome measurements

Recall that  $d=2^N$ . We further assume that  $k \leq d$  is a power of 2 without loss of generality, so that d/k is an integer. We use  $\mathcal{U}_d$  to denote the Haar measure over  $d \times d$  unitary matrices.

The idea of the algorithm is to sample k orthogonal projections  $\Pi_1, \ldots, \Pi_k$  uniformly from the Haar measure with rank $(\Pi_i) = r := d/k$ . Then we apply POVM  $\mathcal{M} := \{\Pi_j\}_{j=1}^k$  to all copies. Finally, we apply classical identity testing to the outcomes x. Details are described in Algorithm 1. It generalizes the algorithm in [BCL20] to k < d.

### <span id="page-18-3"></span>**Algorithm 1** State certification with randomized k-outcome measurements

**Input:** n copies of an unknown state  $\rho$ , state description  $\rho_0$ , desired accuracy  $\varepsilon$ .

**Output:** YES if  $\rho = \rho_0$ , NO if  $\|\rho - \rho_0\|_1 > \varepsilon$ .

Sample a unitary matrix  $U = [|u_1\rangle, \dots, |u_d\rangle]$  from the Haar measure  $\mathcal{U}_d$ . Define a POVM  $\mathcal{M}_U := \{\Pi_x^U\}_{x=1}^k$  where  $\Pi_x^U = \sum_{i=r(x-1)+1}^{rx} |u_i\rangle\langle u_i|$ .

Let  $\mathbf{p}_{\rho}^{U}$  be the outcome distribution when applying  $\mathcal{M}_{U}$  to  $\rho$ .

Apply  $\mathcal{M}_U$  to all copies and obtain outcomes  $\mathbf{x} = (x_1, \dots, x_n)$ .

return TestIdentityL2( $\mathbf{p}_{\rho_0}^U, \mathbf{x}, 0.07\varepsilon/d, \delta = 0.01$ ).

The main step is to upper bound  $\|\mathbf{p}_{\rho}^{U}\|_{2}$  and lower bound  $\|\mathbf{p}_{\rho}^{U} - \mathbf{p}_{\rho_{0}}^{U}\|_{2}$  with at least constant probability over U. We state the result in Lemma 6.1, which is similar to domain compression for communicationconstrained classical distribution testing [ACT20c, Theorem VI.2]. The lemma states that under random unitary projection, the  $\ell_2$  distance  $\|\mathbf{p}_{\rho}^U - \mathbf{p}_{\rho_0}^U\|_2$  roughly remains the same with k, but the  $\ell_2$  norm  $\|\mathbf{p}_{\rho}^U\|_2$  becomes smaller with larger k. The proof is in Appendix  $\mathbf{C}$  and involves computing moments of the Haar measure using Weingarten calculus.

<span id="page-18-1"></span>**Lemma 6.1** (Quantum domain compression). Let  $U \sim \mathcal{U}_d$ ,  $\mathcal{M}_U := \{\Pi_x^U\}_{x=1}^k$  where  $\Pi_x^U = \sum_{i=r(x-1)+1}^{rx} |u_i\rangle\langle u_i|$ and  $\mathbf{p}_{\rho}^{U}$  be the outcome distribution when applying  $\mathcal{M}_{U}$  to  $\rho$ . Then, for all states  $\rho, \sigma$ ,

$$\Pr\bigg[\left\|\mathbf{p}_{\rho}^{U}\right\|_{2} \leq \frac{10}{\sqrt{k}}\,\bigg] \geq 0.98, \quad \Pr\bigg[\left\|\mathbf{p}_{\rho}^{U} - \mathbf{p}_{\sigma}^{U}\right\|_{2} \geq \frac{0.07}{\sqrt{d}}\|\rho - \sigma\|_{HS}\,\bigg] \geq 0.13.$$

Using union bound and Theorem 3.1, Lemma 6.1 only ensures that Algorithm 1 outputs the correct answer with probability 0.1 with  $n = O\left(\frac{d^2}{\varepsilon^2\sqrt{k}}\right)$  copies. We can boost the probability using Algorithm 2, which is a standard amplification algorithm. Theorem 6.2 gives its guarantee and completes the upper bound in Theorem 1.1.

<span id="page-18-4"></span>**Theorem 6.2.** Let  $d \ge 100$  and  $2 \le k \le d$ , Algorithm 2 can test whether  $\rho = \rho_0$  or  $\|\rho - \rho_0\|_1 > \varepsilon$  with probability at least 2/3 using  $n = O\left(\frac{d^2}{\varepsilon^2 \sqrt{k}}\right)$  copies of  $\rho$ .

<span id="page-18-2"></span><sup>&</sup>lt;sup>9</sup>If not, we can round k down to the nearest power of 2, and the copy complexity only differs by a constant.

#### <span id="page-19-0"></span>Algorithm 2 State certification: amplification algorithm

**Input:** n copies of an unknown state  $\rho$ , state description  $\rho_0$ , desired accuracy  $\varepsilon$ .

**Output:** YES if  $\rho = \rho_0$ , NO if  $\|\rho - \rho_0\|_1 > \varepsilon$ .

Divide the copies into T groups of equal size.

For group i, run Algorithm 1 and obtain output  $y_i \in \{YES, NO\}$ .

Let  $b = \frac{1}{T} \sum_{i=1}^{T} \mathbb{1}\{y_i = \text{NO}\}, t_1 = 0.03, t_2 = 0.1.$ 

if  $b > (t_1 + t_2)/2$  then return NO

else return YES

*Proof.* First, consider the case when  $\rho = \rho_0$ . Then we always have  $\mathbf{p}_{\rho}^U = \mathbf{p}_{\rho_0}^U$ . Substituting the  $\ell_2$  norms and  $\delta = 0.01$ , Theorem 3.1 guarantees that with  $n/T = O\left(\frac{1}{\sqrt{k}} \cdot \frac{1}{(\varepsilon/d)^2}\right) = O\left(\frac{d^2}{\varepsilon^2 \sqrt{k}}\right)$ ,

$$\Pr\left[y_i = \mathtt{NO} \middle| \mathbf{p}_{\rho}^U \leq \frac{10}{\sqrt{k}} \right] \leq \delta = 0.01.$$

Using the first part of Lemma 6.1, when  $\rho = \rho_0$ , we have

$$\Pr[\,y_i = \texttt{NO}\,] \leq \Pr\bigg[\,\left\|\mathbf{p}^U_\rho\right\|_2 > \frac{10}{\sqrt{k}}\,\bigg] + \Pr\bigg[\,y_i = \texttt{NO}\bigg|\mathbf{p}^U_\rho \leq \frac{10}{\sqrt{k}}\,\bigg]\,\Pr\bigg[\,\left\|\mathbf{p}^U_\rho\right\|_2 \leq \frac{10}{\sqrt{k}}\,\bigg] \leq 0.01 + 0.02 = 0.03$$

Then consider the case when  $\|\rho - \rho_0\|_1 \ge \varepsilon$ . By Cauchy-Schwarz

$$\|\rho - \rho_0\|_{HS} \ge \varepsilon/\sqrt{d}$$
,

and thus  $\|\mathbf{p}_{\rho}^{U} - \mathbf{p}_{\sigma}^{U}\|_{2} \ge 0.07\varepsilon/d$  with probability at least 0.13 by Lemma 6.1.

By union bound, both  $\|\mathbf{p}_{\rho}^{U}\|_{2} \leq \frac{10}{\sqrt{k}}$  and  $\|\mathbf{p}_{\rho}^{U} - \mathbf{p}_{\sigma}^{U}\|_{2} \geq 0.07\varepsilon/d$  with probability at least 0.13-(1-0.98)=0.11. We conclude the algorithm TestIdentityL2 outputs the correct answer NO using  $n/T = O\left(\frac{d^{2}}{\varepsilon^{2}\sqrt{k}}\right)$  copies with probability at least,

$$\Pr[y_i = NO] \ge 0.11(1 - \delta) > 0.1.$$

Thus, our goal is to distinguish between  $Bern(p_1)$  and  $Bern(p_2)$  where  $p_1 \le t_1 := 0.03$  and  $p_2 \ge t_2 := 0.1$  with constant T number of samples. We use the Hoeffding's inequality,

**Lemma 6.3** (Hoeffding). Let  $X_1, \ldots, X_n$  be independent random variables with  $a_i \leq X_i \leq b_i$  and  $X = \sum_{i=1}^n X_i$ . Let  $\mathbb{E}[X] = \mu$ . Then,

$$\Pr[X - \mu > t] \le \exp\left\{-\frac{2t^2}{\sum_{i=1}^{n} (b_i - a_i)^2}\right\}.$$

By symmetry, the same bound holds for the left tail probability  $\Pr[X - \mu < -t]$ . Thus when  $T = \frac{2}{(t_2 - t_1)^2} \log(\frac{1}{\alpha})$ , for both i = 1, 2, we have  $|b - p_i| > (t_2 - t_1)/2$  with probability at most  $\alpha$ . Setting  $\alpha = 2/3$ , T is a constant and thus  $n = O\left(\frac{d^2}{\varepsilon^2 \sqrt{k}}\right)$  as desired.

Remark 6.4. The proof of Theorem 6.2 only uses the 4th moment of the Haar measure. Thus, we can sample U from (approximate) unitary 4-designs instead of the Haar measure.

<span id="page-19-1"></span>Remark 6.5. Lemma 6.1 does not require  $\rho_0$  to be known. In this case, with n copies of  $\rho_0$ , we can adapt Algorithm 1 to closeness testing by measuring all copies of  $\rho_0$  and applying classical closeness testing algorithm [DK16, Lemma 2.3] in the final step. Thus, Algorithm 2 naturally extends to closeness testing with the same copy complexity of  $n = O(d^2/(\sqrt{k\varepsilon^2}))$ .

# <span id="page-20-0"></span>7 Algorithm for fixed Pauli measurements

### <span id="page-20-1"></span>7.1 Pauli observables

For an N-qubit system (and thus  $d=2^N$ ), the set of Pauli observables is  $\mathcal{P}:=\Sigma^{\otimes N}\setminus\{\mathbb{I}_d\}$ , where  $\Sigma:=\{\sigma_I,\sigma_X,\sigma_Y,\sigma_Z\}$  are the Pauli operators,

$$\sigma_I := \mathbb{I}_2 = egin{bmatrix} 1 & 0 \ 0 & 1 \end{bmatrix}, \quad \sigma_X = egin{bmatrix} 0 & 1 \ 1 & 0 \end{bmatrix}, \quad \sigma_Y = egin{bmatrix} 0 & i \ -i & 0 \end{bmatrix}, \quad \sigma_Z = egin{bmatrix} 1 & 0 \ 0 & -1 \end{bmatrix}.$$

 $\mathcal{P}$  consists of  $d^2-1$  matrices. We have the standard fact about Pauli observables,

Fact 7.1. Let  $P, Q \in \mathcal{P}$  be two Pauli observables. Then,

$$P^2 = P$$
,  $\text{Tr}[P] = 0$ ,  $\text{Tr}[PQ] = \langle P, Q \rangle = d\mathbb{1}\{P = Q\}$ .

Therefore, together with  $\mathbb{I}_d$ , the set  $\Sigma^{\otimes N}$  forms an orthogonal basis for  $\mathbb{H}_d$ .

Each  $P \in \mathcal{P}$  defines a 2-outcome POVM,

$$\mathcal{M}_P = \{M_0^P, M_1^P\}, \ M_0^P = \frac{\mathbb{I}_d - P}{2}, M_1^P = \frac{\mathbb{I}_d + P}{2}.$$

For a state  $\rho$ , we define

$$\mathbf{p}_{\rho} := [\mathbf{p}_{\rho}(P) : P \in \mathcal{P}] \in [0, 1]^{d^2 - 1}, \quad \mathbf{p}_{\rho}(P) = \operatorname{Tr}[\rho M_1^P].$$

<span id="page-20-2"></span>which is the collection of probabilities of seeing "1" after applying  $\mathcal{M}_P$ . Lemma 7.2 relates  $\|\mathbf{p}_{\rho} - \mathbf{p}_{\sigma}\|_2$  to  $\|\rho - \sigma\|_{\mathrm{HS}}$  for two arbitrary states  $\rho, \sigma$ .

**Lemma 7.2.** Let  $\rho$  and  $\sigma$  be two quantum states. Then,  $\|\mathbf{p}_{\rho} - \mathbf{p}_{\sigma}\|_{2} = \frac{\sqrt{d}}{2} \|\rho - \sigma\|_{HS}$ .

*Proof.* The proof uses that Pauli observables and  $\mathbb{I}_d$  forms a basis of  $\mathbb{H}_d$ . Thus we can represent a state  $\rho$  as,

$$\rho = \frac{\mathbb{I}_d}{d} + \sum_{P \in \mathcal{P}} \frac{\text{Tr}[\rho P]P}{d}.$$

Therefore, by the definition of Hilbert-Schmidt norm and that  $\text{Tr}[PQ] = d \cdot \delta_{P,Q}$ 

$$\|\rho - \sigma\|_{\mathrm{HS}}^2 = \left\| \sum_{P \in \mathcal{P}} \frac{1}{d} (\operatorname{Tr}[P\rho] - \operatorname{Tr}[P\sigma]) P \right\|_{\mathrm{HS}}^2 = \frac{1}{d} \sum_{P \in \mathcal{P}} (\operatorname{Tr}[P\rho] - \operatorname{Tr}[P\sigma])^2. \tag{14}$$

We can compute  $\mathbf{p}_{\rho}(P) = \text{Tr}[\rho M_1^P]$  using Born's rule,

$$\mathbf{p}_{\rho}(P) = \frac{1 + \text{Tr}[\rho P]}{2}.$$

Therefore,

<span id="page-20-4"></span>
$$\|\mathbf{p}_{\rho} - \mathbf{p}_{\sigma}\|_{2}^{2} = \frac{1}{4} \sum_{P \in \mathcal{P}} (\operatorname{Tr}[P\rho] - \operatorname{Tr}[P\sigma])^{2}. \tag{15}$$

<span id="page-20-3"></span>

Comparing (14) and (15) proves the lemma.

## <span id="page-21-0"></span>7.2 Algorithm

The idea is to reduce the problem to testing product Bernoulli distributions defined as follows.

**Definition 7.3** (Product Bernoulli). Given  $\mathbf{p} = (p_1, \dots, p_d) \in [0, 1]^d$ , Bern $(\mathbf{p})$  is the distribution of  $\mathbf{x} = (x_1, \dots, x_d) \in \{0, 1\}^d$  where  $x_i \sim \text{Bern}(p_i)$  are independent Bernoulli distributions.

When we apply all Pauli observables  $P \in \mathcal{P}$  to  $d^2-1$  copies, the  $d^2-1$  outcomes simulate one i.i.d. sample from Bern( $\mathbf{p}_{\rho}$ ). Thus, we can apply a classical product Bernoulli testing algorithm, whose performance under  $\ell_2$  distance is stated in Theorem 7.4.

<span id="page-21-3"></span>**Theorem 7.4** ([CDKS20, Theorem 6]). Let  $\mathbf{p}, \mathbf{q} \in [0,1]^d$  where  $\mathbf{p}$  is unknown and  $\mathbf{q}$  is known, and  $\mathbf{x}^n$  be n i.i.d. samples from Bern( $\mathbf{p}$ ). There exists an algorithm TestProdBernL2( $\mathbf{q}, \mathbf{x}^n, d, \varepsilon$ ) that outputs YES if  $\mathbf{p} = \mathbf{q}$  and NO if  $\|\mathbf{p} - \mathbf{q}\|_2 > \varepsilon$  w.p. at least 2/3 using  $n = O(\sqrt{d}/\varepsilon^2)$  samples.

Details are in Algorithm 3, which is similar to the simulate-and-infer in [ACT20a]. Theorem 7.5 proves its performance. Combining with Theorem 1.2 for k=2, we prove the tight copy complexity of  $\Theta(d^3/\varepsilon^2)$  in Theorem 1.3 for Pauli observables and 2-outcome measurements.

#### Algorithm 3 Quantum state certification with fixed Pauli observables

**Input**: n copies of  $\rho$ , known state description  $\rho_0$ .

**Output**: YES if  $\rho = \rho_0$ , NO if  $\|\rho - \rho_0\|_1 > \varepsilon$ .

Let  $\mathbf{q} = \mathrm{Bern}(\mathbf{p}_{\rho_0})$ .

Divide n copies into  $L := \lfloor n/(d^2 - 1) \rfloor$  groups, each with size  $d^2 - 1$ . Excess copies are omitted.

Group j apply all  $P \in \mathcal{P}$  to each copy and obtain  $d^2 - 1$  outcomes  $\mathbf{x}_i = (x_{i,P})_{P \in \mathcal{P}}$ .

return TestProdBernL2( $\mathbf{q}, \mathbf{x}^L = (\mathbf{x}_1, \dots, \mathbf{x}_L), d^2 - 1, \varepsilon/2$ ).

<span id="page-21-4"></span>**Theorem 7.5.** Algorithm 3 can test whether  $\rho = \rho_0$  or  $\|\rho - \rho_0\|_1 \ge \varepsilon$  with probability at least 2/3 using  $n = O(d^3/\varepsilon^2)$  copies of  $\rho$ .

*Proof.* If  $\rho = \rho_0$ , then  $\mathbf{p}_{\rho} = \mathbf{p}_{\rho_0}$ . If  $\|\rho - \rho_0\|_1 \ge \varepsilon$ , by Cauchy-Schwarz  $\|\rho - \rho_0\|_{\mathrm{HS}} \ge \frac{\varepsilon}{\sqrt{d}}$ , and thus by Lemma 7.2,

$$\|\mathbf{p}_{\rho} - \mathbf{p}_{\rho_0}\|_2 \ge \varepsilon/2.$$

Setting  $d \leftarrow d^2 - 1$ ,  $\varepsilon \leftarrow \varepsilon/2$  in Theorem 7.4,  $L = O\left(\frac{\sqrt{d^2-1}}{\varepsilon^2}\right) = O\left(\frac{d}{\varepsilon^2}\right)$  samples from Bern $(\mathbf{p}_{\rho})$  are sufficient to test whether  $\mathbf{p}_{\rho} = \mathbf{p}_{\rho_0}$  or  $\|\mathbf{p}_{\rho} - \mathbf{p}_{\rho_0}\|_2 \ge \varepsilon/2$ , which implies  $n \le (d^2 - 1)(L + 1) = O(d^3/\varepsilon^2)$ , exactly as desired.

# <span id="page-21-1"></span>8 Algorithm for k-outcome fixed measurements

Similar to Section 6, we assume that both k and d are powers of 2. We begin with preliminaries for quantum designs and mutually unbiased bases. Then we propose an algorithm for k = d which makes minor modifications to the algorithm in [Yu21] to satisfy the constraint on the number of outcomes.

#### <span id="page-21-2"></span>8.1 Quantum designs and mutually unbiased basis

<span id="page-21-5"></span>Our algorithm uses quantum 2-designs. A t-design preserves the statistics of the Haar measure up to t-th order moments. Below is the formal definition.

**Definition 8.1** (Quantum t-design). Let t be a positive integer, we say that a finite set of normalized vectors  $\{|\psi_x\rangle\}_{x=1}^m$  in  $\mathbb{C}^d$  is a quantum t-design if

$$\frac{1}{m} \sum_{x=1}^{m} |\psi_x\rangle \langle \psi_x|^{\otimes t} = \int |\psi\rangle \langle \psi|^{\otimes t} d\mu(\psi),$$

where  $\mu$  is the Haar measure on the unit sphere in  $\mathbb{C}^d$ .

<span id="page-22-3"></span>Maximal mutually unbiased bases (MUB) is a well-known example of 2-design that exists for d which are prime powers. We refer the readers to [DEB $\dot{\mathbf{Z}}10$ ] for a survey.

**Theorem 8.2** ([KR05]). Let d be a prime power, then there exists a maximal MUB, i.e. d+1 orthonormal bases  $\{|\psi_x^l\rangle\}_{x=1}^d$ ,  $l=1,\ldots,d+1$  such that the collection of all vectors  $\{|\psi_x^l\rangle\}_{x,l}$  is a 2-design.

## <span id="page-22-0"></span>8.2 Algorithm for k = d

We first review the algorithm in [Yu21]. It treats the collection of all d+1 bases as one single POVM,

$$\mathcal{M}_{MUB} = \left\{ \frac{1}{d+1} |\psi_x^l\rangle \langle \psi_x^l| \right\}_{x \in [d], l \in [d+1]},$$

which has d(d+1) outcomes. This measurement is applied to all copies. We denote the outcome distribution for the state  $\rho$  as  $\mathbf{p}_{\rho} \in \mathbb{R}^{d(d+1)}$ . Maximal MUB ensures that for  $\rho$  far from  $\rho_0$ , the outcome distributions  $\mathbf{p}_{\rho}$ ,  $\mathbf{p}_{\rho_0}$  should also be far.

<span id="page-22-4"></span>**Lemma 8.3** ([Yu21, Lemma 2]). Let  $\mathbf{p}_{\rho}$  be the distribution when applying a maximal MUB to  $\rho$ . Then

$$\|\mathbf{p}_{\rho}\|_{2} \leq \frac{\sqrt{2}}{d+1}, \quad \|\mathbf{p}_{\rho} - \mathbf{p}_{\rho_{0}}\|_{2} = \frac{\|\rho - \rho_{0}\|_{HS}}{d+1}.$$

In particular if  $\|\rho - \rho_0\|_1 > \varepsilon$ , due to Cauchy-Schwarz  $\|\mathbf{p}_\rho - \mathbf{p}_{\rho_0}\|_2 = \frac{\|\rho - \rho_0\|_{HS}}{d+1} \ge \frac{\varepsilon}{(d+1)\sqrt{d}}$ .

Thus we can apply the distribution testing algorithm in Theorem 3.1 to distinguish between  $\mathbf{p}_{\rho}$  and  $\mathbf{p}_{\rho_0}$ . Setting  $b \leftarrow \frac{\sqrt{2}}{d+1}$  and  $\varepsilon \leftarrow \frac{\varepsilon}{(d+1)\sqrt{d}}$ , to achieve success probability  $\delta$ , the number of copies required is

$$n = 1000 \frac{\sqrt{2}}{d+1} \cdot \frac{d(d+1)^2}{\varepsilon^2} \log \frac{1}{\delta} = 1000\sqrt{2} \cdot \frac{d(d+1)}{\varepsilon^2} \cdot \log \frac{1}{\delta}.$$
 (16)

Note that  $\mathcal{M}_{MUB}$  can be viewed as uniformly drawing l from [d+1] and apply  $\mathcal{M}_l = \{|\psi_x^l\rangle\langle\psi_x^l|\}_{x=1}^d$  for each copy. We can thus parameterize the outcome by  $(X,L) \in [d] \times [d+1]$ . In particular, when  $(X,L) \sim \mathbf{p}_{\rho}$ , we have  $\Pr[L=l] = \frac{1}{d+1}$ .

Using this observation, to design an algorithm with d outcomes per measurement, instead of drawing the d+1 basis measurements uniformly, we divide all copies into d+1 equal groups and then apply a basis measurement  $\mathcal{M}_l = \{|\psi_x^l\rangle\langle\psi_x^l|\}_{x=1}^d$  for the l-th group. Thus we always have the same number of samples for each  $l \in [d+1]$ . We can still apply the identity testing algorithm in Theorem 3.1 via a simple reduction. The full algorithm is stated in Algorithm 4.

#### <span id="page-22-1"></span>**Algorithm 4** Fixed measurement state certification k = d

**Input**: n copies of state  $\rho$ .

**Output** YES if  $\rho = \rho_0$ , NO otherwise.

Let  $\{|\psi_x^l\rangle\}_{x=1}^d$ ,  $l=1,\ldots,d+1$  be a maximal MUB.

Divide the copies into d+1 equally-sized groups, each group has  $n_0 = n/(d+1)$  copies.

For group l, apply basis measurement  $\mathcal{M}_l = \{|\psi_x^l\rangle\langle\psi_x^l|\}_{x=1}^d$ . Let the outcomes be  $x_1^{(l)}, \ldots, x_{n_0}^{(l)}$ 

Generate n/2 i.i.d. samples from the uniform distribution over [d+1], and for  $l \in [d+1]$  let  $m_l$  be the number of times that l appears.

Let 
$$\mathbf{x} = (\mathbf{x}_1, \dots, \mathbf{x}_{d+1})$$
 where  $\mathbf{x}_l = (x_1^{(l)}, \dots, x_{\min\{n_0, m_l\}}^{(l)})$ .

<span id="page-22-2"></span>return TestIdentityL2 $\left(\mathbf{p}_{\rho_0}, \mathbf{x}, \frac{\varepsilon}{(d+1)\sqrt{d}}, \delta = 1/6\right)$ .

**Theorem 8.4.** Given n copies from  $\rho$ , Algorithm  $\frac{4}{2}$  can test whether  $\rho = \rho_0$  or  $\|\rho - \rho_0\|_1 > \varepsilon$  with  $n = O(d^2/\varepsilon^2)$  copies.

<span id="page-23-1"></span>*Proof.* We just need to ensure that with high probability, there are sufficient samples to run TestIdentityL2, i.e. for all l,  $n_0 \ge m_l$ . We use the Chernoff bound,

**Lemma 8.5** (Multiplicative Chernoff bound). Let  $X_1, \ldots, X_n$  be i.i.d. with  $\mathbb{E}[X_i] = \mu$ . Then,

$$\Pr\left[\sum_{i=1}^{n} X_i \ge n(1+\alpha)\mu\right] \le \exp\left\{-\frac{n\alpha^2\mu}{2+\alpha}\right\}, \ \alpha > 0,$$

$$\Pr\left[\sum_{i=1}^{n} X_i \le n(1-\alpha)\mu\right] \le \exp\left\{-\frac{n\alpha^2\mu}{2}\right\}, \ \alpha \in (0,1).$$

Note that  $m_l \sim \text{Bin}\left(\frac{n}{2}, \frac{1}{d+1}\right)$ . Thus setting  $\alpha = 1$  and  $\mu = \frac{n}{2(d+1)}$  in Lemma 8.5,

$$\Pr[m_l > n_0] = \Pr\left[m_l > \frac{n}{d+1}\right] \le \exp\left\{-\frac{n}{6(d+1)}\right\}.$$

By union bound,

$$\Pr[\exists l, m_l > n_0] \le (d+1) \exp\left\{-\frac{n}{6(d+1)}\right\}.$$

Thus probability is at most  $\delta' = \frac{1}{6}$  if  $n > 6(d+1)\ln(6(d+1))$ .

From Theorem 3.1, we can use  $n = 2600d(d+1)/\varepsilon^2$  copies to distinguish between  $\mathbf{p}_{\rho}$  and  $\mathbf{p}_{\rho_0}$  with probability at least  $\frac{5}{6}$ . The number of copies is large enough to ensure that  $\Pr[\exists l, m_l > n_0] \leq \frac{1}{6}$ . Thus, the probability that all  $m_l < n_0$  and TestIdentityL2 returns the correct output is at least  $\frac{5}{6} - \delta' = \frac{2}{3}$ , exactly as desired.

## <span id="page-23-0"></span>8.3 Algorithm for k < d

<span id="page-23-4"></span>When k < d, we need to simulate the output of each  $\mathcal{M}_l$  using multiple copies of  $\rho$ . We use existing results from distributed simulation of discrete distributions under classical information constraints.

**Definition 8.6** ( $\eta$ -simulation). In the problem of  $\eta$ -simulation, we have n players and an unknown distribution  $\mathbf{p}$  over [d]. Each player receives an i.i.d. sample from  $\mathbf{p}$  and can only send  $\ell$  bits to a central server. The server then tries to generate  $[\hat{X}] \in [d] \cup \{\bot\}$  that simulates  $\mathbf{p}$  where

$$\Pr\left[\hat{X} = x | \hat{X} \neq \bot\right] = \mathbf{p}_x, \quad \Pr\left[\hat{X} = \bot\right] \leq \eta.$$

We say  $\hat{X}$  is a successful simulation if and only if  $\hat{X} \neq \bot$ .

<span id="page-23-3"></span>We use the protocol introduced by [ACT20c] that simulates an i.i.d. sample from an arbitrary d-ary distribution.

**Theorem 8.7** ([ACT20c, Theorem IV.5]). For every  $\eta \in (0,1)$ , there exists an algorithm that  $\eta$ -simulates d-ary distributions using

$$M = 40 \left\lceil \log \frac{1}{\eta} \right\rceil \left\lceil \frac{d}{2^{\ell} - 1} \right\rceil$$

players, where each player receives one i.i.d. sample and can only output  $\ell = \log k$  bits. The algorithm is deterministic for each player and only requires private randomness.

<span id="page-23-2"></span>Thus, we use roughly O(d/k) copies to simulate the outcome distribution of applying each basis measurement  $\mathcal{M}_l$  to one copy of  $\rho$ . This results in a O(d/k) factor increase in copy complexity compared to the case when the number of outcomes is at least d. Details are described in Algorithm 5. Formal copy complexity guarantee of Algorithm 5 is stated in Theorem 8.8

#### <span id="page-24-1"></span>**Algorithm 5** Fixed measurement state certification k < d

**Input**: n copies of state  $\rho$ .

Output YES if  $\rho = \rho_0$ , NO otherwise.

Let  $\{|\psi_r^l\rangle\}_{r=1}^d$ ,  $l=1,\ldots,d+1$  be a maximal MUB.

Divide the copies into d+1 equally-sized groups, each group has  $n_0 = n/(d+1)$  copies.

<span id="page-24-0"></span>for l = 1, ..., d + 1 do

For group l, apply basis measurement  $\mathcal{M}_l = \{|\psi_x^l\rangle_{\zeta}\langle\psi_x^l|_{x=1}^d$ . Let the outcomes be  $x_1^{(l)}, \ldots, x_{n_0}^{(l)}$ 

Further divide into groups of size  $M=40\left[\log\frac{1}{\eta}\right]\left[\frac{d}{k-1}\right]$  where  $\eta=0.01$ .

<span id="page-24-2"></span>Apply the  $\ell$ -bit simulation protocol in Theorem 8.7 with  $\ell = \log k$ . Obtain simulated outputs  $\hat{x}_1^{(l)}, \ldots, \hat{x}_{n_0/M}^{(l)}$ .

Let  $(\tilde{x}_1, \dots, \tilde{x}_{n_l})$  be the set of successful simulations (i.e. those that are not  $\perp$ ) where  $n_l$  is the number of successful simulations.

Generate n/(2M) i.i.d. samples from the uniform distribution over [d+1], and for  $l \in [d+1]$  let  $m_l$  be the number of times that l appears.

Let  $\mathbf{x}_l = (\tilde{x}_1^{(l)}, \dots, \tilde{x}_{\min\{n_l, m_l\}}^{(l)})$  which keeps at most  $m_l$  successful simulations from each group.

Let  $\mathbf{x} = (\mathbf{x}_1, \dots, \mathbf{x}_{d+1})$ .

return TestIdentityL2 $\left(\mathbf{p}_{\rho_0}, \mathbf{x}, \frac{\varepsilon}{(d+1)\sqrt{d}}, \delta = 1/6\right)$ .

**Theorem 8.8.** For k < d, Algorithm 5 can test whether  $\rho = \rho_0$  or  $\|\rho - \rho_0\|_1 > \varepsilon$  with probability at least 2/3 using  $n = O(\frac{d^3}{k\varepsilon^2})$  copies.

*Proof.* The proof is very similar to Theorem 8.4 where we argue that with high probability there are enough samples to run TestIdentityL2, or  $m_l < n_l$  for all group l. The only difference is that for each group l the number of samples  $n_l$  is random.

For convenience we set  $\hat{n} = n/M$  and  $\hat{n}_0 = n_0/M$ . Note that

$$m_l > n_l \implies m_l > \frac{3}{4}\hat{n}_0 \text{ or } n_l < \frac{3}{4}\hat{n}_0.$$

Thus it suffices to show that both events occur with very small probability. Since  $m_l \sim \text{Bin}\left(\frac{\hat{n}}{2}, \frac{1}{d+1}\right)$  and  $\mathbb{E}[m_l] = \hat{n}_0/2$ , using multiplicative Chernoff bound (Lemma 8.5) with  $\alpha = 1/2$ ,

$$\Pr\left[m_l > \frac{3}{4}\hat{n}_0\right] \le \exp\left\{-\frac{\hat{n}}{10(d+1)}\right\}.$$

Note that  $n_l \sim \text{Bin}(\hat{n}_0, 1 - \eta)$  where  $\eta = 0.01$  and  $\mathbb{E}[n_l] = \hat{n}_0(1 - \eta)$ , using the left tail of Lemma 8.5 with  $\alpha = \frac{1/4 + \eta}{1 - \eta} > 1/4$ ,

$$\Pr\left[n_l < \frac{3}{4}\hat{n}_0\right] \le \exp\left\{-\frac{\hat{n}}{32(d+1)}\right\}.$$

Combining the two parts,

$$\Pr[m_l > n_l] \le \Pr\left[m_l > \frac{3}{4}\hat{n}_0 \text{ or } n_l < \frac{3}{4}\hat{n}_0\right] \le 2\exp\left\{-\frac{\hat{n}}{32(d+1)}\right\}.$$

By union bound,

$$\Pr[\exists l, m_l > n_l] \le 2(d+1) \exp\left\{-\frac{\hat{n}}{32(d+1)}\right\}.$$

The probability is at most  $\delta' = 1/6$  if  $\hat{n} > 32(d+1)\ln(12(d+1))$ . Using  $\hat{n} = 2600d(d+1)/\varepsilon^2$  samples, we can distinguish between  $\mathbf{p}_{\rho}$  and  $\mathbf{p}_{\rho_0}$  with probability at least 5/6, which is large enough to ensure

 $\Pr[\exists l, m_l > n_l] \le 1/6$ . The probability that the entire Algorithm 5 outputs the correct answer is at least  $5/6 - \delta' = 2/3$  as desired.

Recall that  $\hat{n} = n/M$  where  $M = \Theta(d/k)$ , therefore the number of copies  $n = O(\frac{d^3}{k\varepsilon^2})$  as desired.

### <span id="page-25-0"></span>8.4 Remarks

We make some important remarks about the algorithms presented in this section.

Random processing of measurement outcomes Algorithms 4 and 5 relies on random post-processing of measurement outcomes when generating i.i.d. samples from the uniform distribution over [d+1]. The goal is to establish a simple reduction to the case where the d+1 MUBs are sampled uniformly and thus simplify the presentation and proof. However, the formulation of POVM so general that it can be used to describe any classical algorithms. Thus, strictly speaking, the MUB measurements and the random post-processing step can be formulated as a randomized measurement scheme. Nevertheless, it is practically reasonable and relevant to allow randomized post-processing of measurement outcomes as it can be easily implemented with classical computers and provide algorithmic advantages. The lower bound in Theorem 1.2 is still valid for random classical algorithms applied to the outcomes of fixed measurements, so the copy complexity bound is still tight in this setting.

To obtain an algorithm using "truly fixed" measurements, we can apply any deterministic  $\ell_2$  identity testing algorithm using the outcomes with reference distribution  $\mathbf{p}_{\rho_0}$ .

On the algorithm for k < d Algorithm 5 relies on ad-hoc compression of the outcomes obtained from measuring with the MUBs. When all copies are in one place and one can freely process the measurement outcomes, performing the compression step is not very reasonable. Thus the algorithm is more relevant when the copies are distributed across multiple quantum devices with limited bandwidth to communicate the outcomes to some central server. Nevertheless, after compressing each outcome to  $\ell = \log k$  bits, the resulting POVM has at most k outcomes, and thus the algorithm indeed shows that the lower bound from Theorem 1.2 is tight.

# References

- <span id="page-25-1"></span>[Aar20] Scott Aaronson. Shadow tomography of quantum states. SIAM J. Comput., 49(5), 2020. 1.4
- <span id="page-25-2"></span>[ACFT21] Jayadev Acharya, Clément L. Canonne, Cody Freitag, and Himanshu Tyagi. Inference under information constraints iii: Local privacy constraints. IEEE Journal on Selected Areas in Information Theory, 2(1):253–267, 2021. 1.4
- <span id="page-25-4"></span>[ACL<sup>+</sup>22] Jayadev Acharya, Clément L. Canonne, Yuhan Liu, Ziteng Sun, and Himanshu Tyagi. Interactive inference under information constraints. *IEEE Transactions on Information Theory*, 68(1):502–516, 2022. 1.4
- <span id="page-25-5"></span>[ACT20a] Jayadev Acharya, Clément L Canonne, and Himanshu Tyagi. Distributed signal detection under communication constraints. In Jacob Abernethy and Shivani Agarwal, editors, Proceedings of Thirty Third Conference on Learning Theory, volume 125 of Proceedings of Machine Learning Research, pages 41–63. PMLR, 09–12 Jul 2020. 7.2
- <span id="page-25-3"></span>[ACT20b] Jayadev Acharya, Clément L. Canonne, and Himanshu Tyagi. Inference under information constraints I: lower bounds from chi-square contraction. *IEEE Trans. Inf. Theory*, 66(12):7835–7855, 2020. 1.4, 2.2, 5.2, 5.1, B.9

- <span id="page-26-8"></span>[ACT20c] Jayadev Acharya, Clément L. Canonne, and Himanshu Tyagi. Inference under information constraints II: Communication constraints and shared randomness. *IEEE Trans. Inform. Theory*, 66(12):7856–7877, 2020. Available at abs/1905.08302. [1.4,](#page-6-3) [6,](#page-24-2) [8.3,](#page-23-4) [8.7](#page-23-3)
- <span id="page-26-12"></span>[BCHJ+21] Fernando GSL Brandão, Wissam Chemissany, Nicholas Hunter-Jones, Richard Kueng, and John Preskill. Models of quantum complexity growth. *PRX Quantum*, 2(3):030316, 2021. [C.2](#page-37-2)
- <span id="page-26-2"></span>[BCL20] Sébastien Bubeck, Sitan Chen, and Jerry Li. Entanglement is necessary for optimal quantum property testing. In Sandy Irani, editor, *61st IEEE Annual Symposium on Foundations of Computer Science, FOCS 2020, Durham, NC, USA, November 16-19, 2020*, pages 692–703. IEEE, 2020. [1,](#page-3-0) [1.2,](#page-5-0) [1.3,](#page-5-2) [2.2,](#page-8-3) [2.3,](#page-8-1) [2.3,](#page-8-2) [2.3,](#page-9-3) [6](#page-18-0)
- <span id="page-26-6"></span>[BFF+01] Tugkan Batu, Lance Fortnow, Eldar Fischer, Ravi Kumar, Ronitt Rubinfeld, and Patrick White. Testing random variables for independence and identity. In *42nd Annual Symposium on Foundations of Computer Science, FOCS 2001, 14-17 October 2001, Las Vegas, Nevada, USA*, pages 442–451. IEEE Computer Society, 2001. [1.4](#page-6-3)
- <span id="page-26-3"></span>[BHLP20] Fernando G. S. L. Brandão, Aram W. Harrow, James R. Lee, and Yuval Peres. Adversarial hypothesis testing and a quantum stein's lemma for restricted measurements. *IEEE Transactions on Information Theory*, 66(8):5037–5054, 2020. [1.4](#page-6-2)
- <span id="page-26-7"></span>[BHO20] Leighton Pate Barnes, Yanjun Han, and Ayfer Ozgur. Lower bounds for learning distributions under communication constraints via fisher information. *Journal of Machine Learning Research*, 21(236):1–30, 2020. [1.4](#page-6-3)
- <span id="page-26-5"></span>[BKL<sup>+</sup>19] Fernando G. S. L. Brandão, Amir Kalev, Tongyang Li, Cedric Yen-Yu Lin, Krysta M. Svore, and Xiaodi Wu. Quantum SDP solvers: Large speed-ups, optimality, and applications to quantum learning. In Christel Baier, Ioannis Chatzigiannakis, Paola Flocchini, and Stefano Leonardi, editors, *46th International Colloquium on Automata, Languages, and Programming, ICALP 2019, July 9-12, 2019, Patras, Greece*, volume 132 of *LIPIcs*, pages 27:1–27:14. Schloss Dagstuhl - Leibniz-Zentrum für Informatik, 2019. [1.4](#page-6-2)
- <span id="page-26-4"></span>[BO21] Costin Badescu and Ryan O'Donnell. Improved quantum data analysis. In Samir Khuller and Virginia Vassilevska Williams, editors, *STOC '21: 53rd Annual ACM SIGACT Symposium on Theory of Computing, Virtual Event, Italy, June 21-25, 2021*, pages 1398–1411. ACM, 2021. [1.4](#page-6-2)
- <span id="page-26-0"></span>[BOW19] Costin Badescu, Ryan O'Donnell, and John Wright. Quantum state certification. In Moses Charikar and Edith Cohen, editors, *Proceedings of the 51st Annual ACM SIGACT Symposium on Theory of Computing, STOC 2019, Phoenix, AZ, USA, June 23-26, 2019*, pages 503–514. ACM, 2019. [1,](#page-3-0) [1,](#page-3-1) [1.2,](#page-5-0) [1.4](#page-6-4)
- <span id="page-26-1"></span>[Can20] Clément L Canonne. A survey on distribution testing: Your data is big. but is it blue? *Theory of Computing*, pages 1–100, 2020. [1](#page-3-0)
- <span id="page-26-9"></span>[Can22] Clément L. Canonne. Topics and techniques in distribution testing: A biased but representative sample. *Foundations and Trends® in Communications and Information Theory*, 19(6):1032– 1198, 2022. [1.4](#page-6-3)
- <span id="page-26-10"></span>[CCHL21] Sitan Chen, Jordan Cotler, Hsin-Yuan Huang, and Jerry Li. Exponential separations between learning with and without quantum memory. In *62nd IEEE Annual Symposium on Foundations of Computer Science, FOCS 2021, Denver, CO, USA, February 7-10, 2022*, pages 574–585. IEEE, 2021. [2.3,](#page-8-1) [2.3,](#page-9-3) [7](#page-12-2)
- <span id="page-26-11"></span>[CDKS20] Clément L. Canonne, Ilias Diakonikolas, Daniel M. Kane, and Alistair Stewart. Testing bayesian networks. *IEEE Transactions on Information Theory*, 66(5):3132–3170, 2020. [7.4](#page-21-3)

- <span id="page-27-6"></span>[CHL+23] Sitan Chen, Brice Huang, Jerry Li, Allen Liu, and Mark Sellke. When does adaptivity help for quantum state learning? In *64th IEEE Annual Symposium on Foundations of Computer Science, FOCS 2023, Santa Cruz, CA, USA, November 6-9, 2023*, pages 391–404. IEEE, 2023. [1.4,](#page-6-2) [2.3](#page-9-3)
- <span id="page-27-1"></span>[CLHL22] Sitan Chen, Jerry Li, Brice Huang, and Allen Liu. Tight bounds for quantum state certification with incoherent measurements. In *63rd IEEE Annual Symposium on Foundations of Computer Science, FOCS 2022, Denver, CO, USA, October 31 - November 3, 2022*, pages 1205–1213. IEEE, 2022. [1,](#page-3-0) [1.2,](#page-5-0) [1.4,](#page-6-4) [2.3,](#page-8-1) [2.3](#page-9-3)
- <span id="page-27-2"></span>[CLO22] Sitan Chen, Jerry Li, and Ryan O'Donnell. Toward instance-optimal state certification with incoherent measurements. In Po-Ling Loh and Maxim Raginsky, editors, *Conference on Learning Theory, 2-5 July 2022, London, UK*, volume 178 of *Proceedings of Machine Learning Research*, pages 2541–2596. PMLR, 2022. [1.2,](#page-5-0) [5,](#page-5-3) [1.4,](#page-6-4) [2.2,](#page-8-3) [C.3](#page-37-3)
- <span id="page-27-11"></span>[Col03] Benoît Collins. Moments and cumulants of polynomial random variables on unitarygroups, the itzykson-zuber integral, and free probability. *International Mathematics Research Notices*, 2003(17):953–982, 2003. [2.3,](#page-9-3) [C.1.2](#page-36-3)
- <span id="page-27-14"></span>[CŚ06] Benoît Collins and Piotr Śniady. Integration with respect to the haar measure on unitary, orthogonal and symplectic group. *Communications in Mathematical Physics*, 264(3):773–795, 2006. [C.1.2,](#page-36-3) [C.1](#page-36-4)
- <span id="page-27-13"></span>[DEBŻ10] Thomas Durt, Berthold-Georg Englert, Ingemar Bengtsson, and Karol Życzkowski. On mutually unbiased bases. *International journal of quantum information*, 8(04):535–640, 2010. [8.1](#page-21-5)
- <span id="page-27-9"></span>[DJW13] John C. Duchi, Michael I. Jordan, and Martin J. Wainwright. Local privacy and statistical minimax rates. In *54th Annual IEEE Symposium on Foundations of Computer Science, FOCS 2013, 26-29 October, 2013, Berkeley, CA, USA*, pages 429–438. IEEE Computer Society, 2013. [1.4](#page-6-3)
- <span id="page-27-12"></span>[DK16] Ilias Diakonikolas and Daniel M. Kane. A new approach for testing properties of discrete distributions. In Irit Dinur, editor, *IEEE 57th Annual Symposium on Foundations of Computer Science, FOCS 2016, 9-11 October 2016, Hyatt Regency, New Brunswick, New Jersey, USA*, pages 685–694. IEEE Computer Society, 2016. [3.1,](#page-10-2) [6.5](#page-19-1)
- <span id="page-27-10"></span>[DS19] John B DeBrota and Blake C Stacey. Lüders channels and the existence of symmetricinformationally-complete measurements. *Physical Review A*, 100(6):062327, 2019. [2.1,](#page-8-4) [4.2](#page-12-3)
- <span id="page-27-8"></span>[FFGO23] Omar Fawzi, Nicolas Flammarion, Aurélien Garivier, and Aadil Oufkir. On Adaptivity in Quantum Testing. *Transactions on Machine Learning Research Journal*, pages 1–33, September 2023. [1.4](#page-6-2)
- <span id="page-27-7"></span>[FL11] Steven T. Flammia and Yi-Kai Liu. Direct fidelity estimation from few pauli measurements. *Phys. Rev. Lett.*, 106:230501, Jun 2011. [1.4](#page-6-2)
- <span id="page-27-4"></span>[FO23] Steven T. Flammia and Ryan O'Donnell. Quantum chi-squared tomography and mutual information testing. *CoRR*, abs/2305.18519, 2023. [1.4](#page-6-2)
- <span id="page-27-3"></span>[GKKT20] Madalin Guţă, Jonas Kahn, Richard Kueng, and Joel A Tropp. Fast state tomography with optimal error bounds. *Journal of Physics A: Mathematical and Theoretical*, 53(20):204001, 2020. [1.4](#page-6-2)
- <span id="page-27-0"></span>[Gol17] Oded Goldreich. *Introduction to property testing*. Cambridge University Press, 2017. [1](#page-3-0)
- <span id="page-27-5"></span>[HHJ<sup>+</sup>17] Jeongwan Haah, Aram W. Harrow, Zhengfeng Ji, Xiaodi Wu, and Nengkun Yu. Sample-optimal tomography of quantum states. *IEEE Trans. Inf. Theory*, 63(9):5628–5641, 2017. [1.4,](#page-6-2) [2.3,](#page-8-1) [2.3](#page-9-3)

- <span id="page-28-9"></span>[HKP20] Hsin-Yuan Huang, Richard Kueng, and John Preskill. Predicting many properties of a quantum system from very few measurements. *Nature Physics*, 16(10):1050–1057, 2020. [1.4](#page-6-2)
- <span id="page-28-16"></span>[KR05] Andreas Klappenecker and Martin Rotteler. Mutually unbiased bases are complex projective 2-designs. In *Proceedings. International Symposium on Information Theory, 2005. ISIT 2005.*, pages 1740–1744. IEEE, 2005. [8.2](#page-22-3)
- <span id="page-28-5"></span>[KRT17] Richard Kueng, Holger Rauhut, and Ulrich Terstiege. Low rank matrix recovery from rank one measurements. *Applied and Computational Harmonic Analysis*, 42(1):88–116, 2017. [1.4](#page-6-2)
- <span id="page-28-11"></span>[KW21] Sumeet Khatri and Mark M Wilde. Principles of quantum communication theory: A modern approach. 2021. [4](#page-11-0)
- <span id="page-28-2"></span>[LA24] Yuhan Liu and Jayadev Acharya. The role of randomness in quantum state certification with unentangled measurements. In Shipra Agrawal and Aaron Roth, editors, *Proceedings of Thirty Seventh Conference on Learning Theory*, volume 247 of *Proceedings of Machine Learning Research*, pages 3523–3555. PMLR, 30 Jun–03 Jul 2024. [1,](#page-3-0) [1.2,](#page-5-0) [1.3,](#page-5-4) [2.1,](#page-8-4) [4.2](#page-12-3)
- <span id="page-28-13"></span>[LeC73] L. LeCam. Convergence of estimates under dimensionality restrictions. *The Annals of Statistics*, 1(1):38–53, 1973. [5.1,](#page-13-1) [5.1](#page-13-4)
- <span id="page-28-6"></span>[LN22] Angus Lowe and Ashwin Nayak. Lower bounds for learning quantum states with single-copy measurements. *CoRR*, abs/2207.14438, 2022. [1.4](#page-6-2)
- <span id="page-28-12"></span>[Lüd50] Gerhart Lüders. Über die zustandsänderung durch den meßprozeß. *Annalen der Physik*, 443(5- 8):322–328, 1950. [4.2](#page-12-3)
- <span id="page-28-1"></span>[MdW16] Ashley Montanaro and Ronald de Wolf. A survey of quantum property testing. *Theory of Computing*, pages 1–81, 2016. [1](#page-3-0)
- <span id="page-28-7"></span>[ON00] T. Ogawa and H. Nagaoka. Strong converse and stein's lemma in quantum hypothesis testing. *IEEE Transactions on Information Theory*, 46(7):2428–2433, 2000. [1.4](#page-6-2)
- <span id="page-28-0"></span>[OW15] Ryan O'Donnell and John Wright. Quantum spectrum testing. In Rocco A. Servedio and Ronitt Rubinfeld, editors, *Proceedings of the Forty-Seventh Annual ACM on Symposium on Theory of Computing, STOC 2015, Portland, OR, USA, June 14-17, 2015*, pages 529–538. ACM, 2015. [1,](#page-3-0) [1.2,](#page-5-0) [2.3](#page-8-1)
- <span id="page-28-3"></span>[OW16] Ryan O'Donnell and John Wright. Efficient quantum tomography. In Daniel Wichs and Yishay Mansour, editors, *Proceedings of the 48th Annual ACM SIGACT Symposium on Theory of Computing, STOC 2016, Cambridge, MA, USA, June 18-21, 2016*, pages 899–912. ACM, 2016. [1.4,](#page-6-2) [2.3](#page-8-1)
- <span id="page-28-4"></span>[OW17] Ryan O'Donnell and John Wright. Efficient quantum tomography II. In Hamed Hatami, Pierre McKenzie, and Valerie King, editors, *Proceedings of the 49th Annual ACM SIGACT Symposium on Theory of Computing, STOC 2017, Montreal, QC, Canada, June 19-23, 2017*, pages 962–974. ACM, 2017. [1.4](#page-6-2)
- <span id="page-28-10"></span>[Pan08] Liam Paninski. A coincidence-based test for uniformity given very sparsely sampled discrete data. *IEEE Trans. Inf. Theory*, 54(10):4750–4755, 2008. [1.4,](#page-6-3) [2.3,](#page-9-4) [2.3](#page-9-3)
- <span id="page-28-14"></span>[Pol03] David Pollard. Asymptopia, 2003. Manuscript. [5.4](#page-15-2)
- <span id="page-28-8"></span>[RLW23] Bartosz Regula, Ludovico Lami, and Mark M. Wilde. Postselected quantum hypothesis testing. *IEEE Transactions on Information Theory*, pages 1–1, 2023. [1.4](#page-6-2)
- <span id="page-28-15"></span>[Tao23] Terence Tao. *Topics in random matrix theory*, volume 132. American Mathematical Society, 2023. [5.7,](#page-16-3) [B.1,](#page-31-2) [B.4,](#page-32-0) [B.5](#page-32-1)

- <span id="page-29-8"></span>[Ver18] Roman Vershynin. *High-dimensional probability: An introduction with applications in data science*, volume 47. Cambridge university press, 2018. [B.2,](#page-31-3) [B.3](#page-31-2)
- <span id="page-29-6"></span>[Wei78] Don Weingarten. Asymptotic behavior of group integrals in the limit of infinite rank. *Journal of Mathematical Physics*, 19(5):999–1001, 1978. [2.3](#page-9-3)
- <span id="page-29-3"></span>[Wri16] John Wright. *How to learn a quantum state*. PhD thesis, Carnegie Mellon University, 2016. [1,](#page-3-0) [1.4](#page-6-2)
- <span id="page-29-7"></span>[Yu97] Bin Yu. Assouad, fano, and le cam. In *Festschrift for Lucien Le Cam*, pages 423–435. Springer, 1997. [5.1,](#page-13-1) [5.1](#page-13-4)
- <span id="page-29-4"></span>[Yu21] Nengkun Yu. Sample efficient identity testing and independence testing of quantum states. In James R. Lee, editor, *12th Innovations in Theoretical Computer Science Conference, ITCS 2021, January 6-8, 2021, Virtual Conference*, volume 185 of *LIPIcs*, pages 11:1–11:20. Schloss Dagstuhl - Leibniz-Zentrum für Informatik, 2021. [1,](#page-3-0) [1.2,](#page-5-0) [1.3,](#page-5-4) [1.4,](#page-6-4) [8,](#page-21-1) [8.2,](#page-22-0) [8.3](#page-22-4)
- <span id="page-29-5"></span>[Yu23] Nengkun Yu. Almost tight sample complexity analysis of quantum identity testing by pauli measurements. *IEEE Transactions on Information Theory*, 69(8):5060–5068, 2023. [1.2,](#page-5-0) [1.3,](#page-6-1) [1.4,](#page-6-4) [2.3](#page-8-1)

# <span id="page-29-0"></span>**A Proof of MIC properties**

# <span id="page-29-1"></span>**A.1 Proof of Lemma [4.1](#page-11-2)**

*Proof.* 1. Since each |*Mx*iihh*Mx*| is p.s.d. and Tr[*Mx*] ≥ 0, C<sup>M</sup> is also p.s.d. 2.

$$\mathcal{H}_{\mathcal{M}}(\mathbb{I}_d) = \sum_x M_x \frac{\text{Tr}[M_x \mathbb{I}_d]}{\text{Tr}[M_x]} = \sum_x M_x = \mathbb{I}_d.$$

The last equality is by the definition of POVM.

3. For all matrices *<sup>X</sup>* <sup>∈</sup> <sup>C</sup> *d*×*d* ,

$$\operatorname{Tr}[\mathcal{H}_{\mathcal{M}}(X)] = \sum_{x} \operatorname{Tr}[M_{x}] \frac{\operatorname{Tr}[M_{x}X]}{\operatorname{Tr}[M_{x}]} = \sum_{x} \operatorname{Tr}[M_{x}X] = \operatorname{Tr}\left[\sum_{x} M_{x}X\right] = \operatorname{Tr}[X].$$

4. Let *X* be Hermitian, then

$$\mathcal{H}_{\mathcal{M}}(X)^{\dagger} = \sum_{x} M_{x}^{\dagger} \frac{\overline{\text{Tr}[M_{x}X]}}{\overline{\text{Tr}[M_{x}]}} = \sum_{x} M_{x} \frac{\overline{\text{Tr}[M_{x}X]}}{\overline{\text{Tr}[M_{x}]}} = \mathcal{H}_{\mathcal{M}}(X)$$

The second step is because both *X* and *M<sup>x</sup>* are Hermitian and thus Tr[*MxX*]*,* Tr[*Mx*] are real numbers. The proof is complete.

# <span id="page-29-2"></span>**A.2 Proof of Lemma [4.3](#page-11-3)**

*Proof.* It suffices to prove that for all matrix *X*, hh*X*|CM|*X*ii ≤ hh*X*|*X*ii = Tr[*X*†*X*]. Without loss of generality, we can assume that *X* is Hermitian. Indeed, all matrices *X* can be written as *X* = *A* + *iB* where both *A* and *B* are Hermitian, and so hh*X*|*X*ii = hh*A*|*A*ii+hh*B*|*B*ii. If the statement is true for all Hermitian matrices, then

$$\langle \langle X | \mathcal{C}_{\mathcal{M}} | X \rangle \rangle = \langle \langle A | \mathcal{C}_{\mathcal{M}} | A \rangle \rangle + \langle \langle B | \mathcal{C}_{\mathcal{M}} | B \rangle \rangle + i \langle \langle A | \mathcal{C}_{\mathcal{M}} | B \rangle \rangle - i \langle \langle B | \mathcal{C}_{\mathcal{M}} | A \rangle \rangle$$

$$= \langle \langle A | \mathcal{C}_{\mathcal{M}} | A \rangle \rangle + \langle \langle B | \mathcal{C}_{\mathcal{M}} | B \rangle \rangle$$
  
$$\leq \langle \langle A | A \rangle \rangle + \langle \langle B | B \rangle \rangle = \langle \langle X | X \rangle \rangle.$$

In the second step we used that  $\mathcal{C}_{\mathcal{M}}$  a Hermitian matrix and that  $\mathcal{H}_{\mathcal{M}}$  is Hermitian-preserving, so  $\langle \langle B | \mathcal{C}_{\mathcal{M}} | A \rangle \rangle = \langle \langle A | \mathcal{C}_{\mathcal{M}} | B \rangle \rangle \in \mathbb{R}$ .

We now evaluate the expression assuming X is Hermitian.

$$\langle \langle X | \mathcal{C}_{\mathcal{M}} | X \rangle \rangle = \sum_{x} \frac{\langle \langle X | M_x \rangle \rangle \langle \langle M_x | X \rangle \rangle}{\operatorname{Tr}[M_x]} = \sum_{x} \frac{\operatorname{Tr}[M_x X]^2}{\operatorname{Tr}[M_x]}.$$

Our goal is to prove that  $\frac{\text{Tr}[M_xX]^2}{\text{Tr}[M_x]} \leq \text{Tr}[M_xX^2]$ . If so, then we would have,

$$\langle\langle X|\mathcal{C}_{\mathcal{M}}|X\rangle\rangle = \sum_{x} \frac{\mathrm{Tr}[M_{x}X]^{2}}{\mathrm{Tr}[M_{x}]} \leq \sum_{x} \mathrm{Tr}[M_{x}X^{2}] = \mathrm{Tr}\left[\sum_{x} M_{x}X^{2}\right] = \mathrm{Tr}[X^{2}],$$

exactly as desired. To prove this statement, let  $M_x = \sum_j \lambda_{x,j} |\psi_{x,j}\rangle \langle \psi_{x,j}|$  be the eigen-decomposition so that  $\sum_j \lambda_{x,j} = \text{Tr}[M_x]$ . Then,

$$Tr[M_x X]^2 = \sum_{i,j} \lambda_{x,i} \lambda_{x,j} \langle \psi_{x,i} | X | \psi_{x,i} \rangle \langle \psi_{x,j} | X | \psi_{x,j} \rangle$$
$$= \sum_{i,j} \lambda_{x,i} \lambda_{x,j} Tr[X | \psi_{x,i} \rangle \langle \psi_{x,j} | X | \psi_{x,j} \rangle \langle \psi_{x,i} |].$$

By Cauchy-Schwarz,

$$\begin{aligned} \operatorname{Tr}[X|\psi_{x,i}\rangle\langle\psi_{x,j}|X|\psi_{x,j}\rangle\langle\psi_{x,i}|] &= \langle|\psi_{x,j}\rangle\langle\psi_{x,i}|X,X|\psi_{x,j}\rangle\langle\psi_{x,i}|\rangle\\ &\leq |||\psi_{x,j}\rangle\langle\psi_{x,i}|X||_{\operatorname{HS}}||X|\psi_{x,j}\rangle\langle\psi_{x,i}||_{\operatorname{HS}}\\ &= \sqrt{\operatorname{Tr}[X|\psi_{x,i}\rangle\langle\psi_{x,j}|\psi_{x,j}\rangle\langle\psi_{x,i}|X]}\operatorname{Tr}[||\psi_{x,i}\rangle\langle\psi_{x,j}|X^2|\psi_{x,j}\rangle\langle\psi_{x,i}|]\\ &= \sqrt{\langle\psi_{x,i}|X^2|\psi_{x,i}\rangle\langle\psi_{x,j}|X^2|\psi_{x,j}\rangle}\\ &\leq \frac{1}{2}(\langle\psi_{x,i}|X^2|\psi_{x,i}\rangle + \langle\psi_{x,j}|X^2|\psi_{x,j}\rangle).\end{aligned}$$

The final step follows by AM-GM inequality. Plugging in all the expressions,

$$\frac{\operatorname{Tr}[M_x X]^2}{\operatorname{Tr}[M_x]} \leq \frac{\sum_{i,j} \lambda_{x,i} \lambda_{x,j} \frac{1}{2} (\langle \psi_{x,i} | X^2 | \psi_{x,i} \rangle + \langle \psi_{x,j} | X^2 | \psi_{x,j} \rangle)}{\sum_j \lambda_{x,j}}$$

$$= \frac{\sum_j \lambda_{x,j} \sum_i \lambda_{x,i} \langle \psi_{x,i} | X^2 | \psi_{x,i} \rangle}{\sum_j \lambda_{x,j}}$$

$$= \sum_i \lambda_{x,i} \langle \psi_{x,i} | X^2 | \psi_{x,i} \rangle$$

$$= \operatorname{Tr}[M_x X^2].$$

The proof is complete.

#### <span id="page-30-0"></span>A.3 Proof of Lemma 4.4

*Proof.* First, we note that

$$\operatorname{Tr}[\mathcal{C}_{\mathcal{M}}] = \sum_{x} \frac{\langle \langle M_x | M_x \rangle \rangle}{\operatorname{Tr}[M_x]} = \sum_{x} \frac{\|M_x\|_{\mathrm{HS}}^2}{\operatorname{Tr}[M_x]}.$$

Since  $||M_x||_{HS} \leq ||M_x||_1 = Tr[M_x]$ , we have

$$\operatorname{Tr}[\mathcal{C}_{\mathcal{M}}] \le \sum_{x} \frac{\operatorname{Tr}[M_{x}]^{2}}{\operatorname{Tr}[M_{x}]} = \sum_{x} \operatorname{Tr}[M_{x}] = d.$$

We also note that since  $M_x \leq \mathbb{I}_d$ ,  $\|M_x\|_{\text{op}} \leq 1$ . By Hölder's inequality,  $\|M_x\|_{\text{HS}}^2 \leq \|M_x\|_{\text{op}} \text{Tr}[M_x]$ . Thus, when the size of  $\mathcal{M}$  is at most k,

$$\operatorname{Tr}[\mathcal{C}_{\mathcal{M}}] \le \sum_{x=1}^{k} \|M_x\|_{\operatorname{op}} \le k.$$

Since  $\mathcal{C}_{\mathcal{M}}$  is p.s.d by Lemma 4.1, we have  $\|\mathcal{C}_{\mathcal{M}}\|_1 = \operatorname{Tr}[\mathcal{C}_{\mathcal{M}}]$ , thereby completing the proof.

# <span id="page-31-0"></span>B Missing proofs in the lower bound

# <span id="page-31-1"></span>B.1 Proof of Theorem 5.6

*Proof.* We first prove that for any fixed unit vector  $x \in \mathbb{C}^d$ , the norm of Wx is at most  $O(\sqrt{d})$  with high probability. Then we use an  $\epsilon$ -net argument to show that the probability is also high for *all* unit vectors. We start with the following lemma.

<span id="page-31-4"></span>**Lemma B.1.** Let  $\{z_i\}_{i=1}^{d^2}$ ,  $\{V_i\}_{i=1}^{d^2}$  and W be defined in Theorem 5.6. Then there exists a universal constant c' for any fixed unit vector x and all s > 0,

$$\Pr \Big[ \left\| Wx \right\|_2 \geq (1+s)\sqrt{d} \, \Big] \leq 2 \exp\{-c's^2d\}.$$

*Proof.* Let  $z=(z_1,\ldots,z_{d^2})\in\mathbb{R}^{d^2}$ , and  $\Pi_\ell\in\mathbb{R}^{d^2\times d^2}$  be a diagonal matrix with 1 in the first  $\ell$  diagonal entries and 0 everywhere else. Then

$$Wx = \sum_{i=1}^{\ell} z_i V_i x = V_x \Pi_{\ell} z,$$

where

$$V_x := [V_1 x, \dots, V_{d^2} x] \in \mathbb{C}^{d \times d^2}$$

which is an isometry, i.e.  $V_x V_x^{\dagger} = \mathbb{I}_d$ , as stated in Claim B.6 which will be proved at the end of this section. Therefore,

$$||V_x||_{\text{OD}} = 1, \quad ||V_x||_{\text{HS}}^2 = \text{Tr}[V_x V_x^{\dagger}] = d.$$

<span id="page-31-3"></span>From this, we can apply concentration for linear transforms of independent sub-Gaussian random variables.

**Theorem B.2** ([Ver18, Theorem 6.3.2]). Let  $B \in \mathbb{C}^{m \times n}$  be a fixed  $m \times n$  matrix and let  $X = (X_1, \ldots, X_n) \in \mathbb{R}^n$  be a random vector with independent, mean zero, unit variance, and sub-Gaussian coordinates with Orlicz-2 norm  $||X_i||_{\psi_2} \leq K$ . Then there exists a universal constant  $C = \frac{3}{8}$  such that for all t > 0,

$$\Pr[\,|\|BX\|_2 - \|B\|_{HS}| > t\,] \le 2\exp\left\{-\frac{Ct^2}{K^4\|B\|_{op}^2}\right\}.$$

<span id="page-31-2"></span>Remark B.3. The original [Ver18, Theorem 6.3.2] was stated for real matrix B. However, it is straightforward to extend the argument to complex B by considering  $\tilde{B} = \begin{bmatrix} \operatorname{Re}(B) \\ \operatorname{Im}(B) \end{bmatrix}$ . Then  $\|\tilde{B}\|_{\operatorname{op}} = \|B\|_{\operatorname{op}}, \|\tilde{B}\|_{\operatorname{HS}} = \|B\|_{\operatorname{HS}}$ , and  $\|BX\|_2 = \|\tilde{B}X\|_2$ .

Setting  $B = V_x \Pi_\ell$ , we observe that

$$||B||_{\text{op}} \le ||V_x||_{\text{op}} ||\Pi_\ell||_{\text{op}} = 1, \quad ||B||_{\text{HS}} \le ||V_x||_{\text{HS}} = \sqrt{d}.$$

Thus, plugging  $t = s\sqrt{d}$ , and noting that  $||z_i||_{\psi_2} = 1/\sqrt{\ln 2} = K$ , we have

$$\Pr\Big[\left\|Wx\right\|_2 > (1+s)\sqrt{d}\,\Big] \leq \Pr\Big[\left\|Bz\right\|_2 > s\sqrt{d} + \left\|B\right\|_{\mathrm{HS}}\,\Big] \leq 2\exp\left\{-Cd(\ln 2)^2s^2\right\}.$$

Setting  $c' = C(\ln 2)^2 = \frac{3(\ln 2)^2}{8}$  completes the proof.

<span id="page-32-0"></span>We can then proceed to use the  $\epsilon$ -net argument, which follows closely to [Tao23, Section 2.3].

**Lemma B.4** ([Tao23, Lemma 2.3.2]). Let  $\Sigma$  be a maximal 1/2-net of the unitary sphere, i.e., a maximal set of points that are separated from each other by at least 1/2. Then for any matrix  $M \in \mathbb{C}^{d \times d}$  and  $\lambda > 0$ ,

$$\Pr \Big[ \left\| M \right\|_{op} > \lambda \, \Big] \leq \sum_{y \in \Sigma} \Pr [ \left\| My \right\|_2 > \lambda/2 \, ].$$

<span id="page-32-1"></span>By standard volume packing argument, the size of  $\Sigma$  is at most  $\exp(O(d))$ ,

**Lemma B.5** ([Tao23, Lemma 2.3.4]). Let  $\epsilon \in (0,1)$  and let  $\Sigma$  be an  $\epsilon$ -net of the unit sphere. Then  $|\Sigma| \leq (C'/\epsilon)^d$  where C' = 3.

Thus with c' defined in Lemma B.1 and C' defined in Lemma B.5 we conclude that

$$\Pr \Big[ \left\| W \right\|_{\text{op}} > 2(1+s)\sqrt{d} \, \Big] \leq 2(2C')^d \exp\{-c's^2d\} = 2 \exp\left\{-(c's^2 - \ln(2C'))d\right\}.$$

Thus choosing s sufficiently large, we can guarantee that the tail probability decays exponentially in d. Specifically, let  $\alpha > 0$  and  $s^2 = \frac{\alpha + \ln(2C')}{c'}$ , then we have

$$\Pr\left[\|W\|_{\text{op}} > 2(1+s)\sqrt{d}\,\right] \le 2e^{-\alpha d}.$$

Setting  $\kappa_{\alpha} = 2(1+s) = 2\left(1+\sqrt{\frac{\alpha+\ln(2C')}{c'}}\right)$  proves the theorem. In particular,  $\kappa_1 \leq 10$  when substituting the values of c' and C'.

We end this section with the proof of the isometry claim.

<span id="page-32-2"></span>Claim B.6. Let  $V_1, \ldots, V_{d^2}$  be an orthonormal basis of  $\mathbb{C}^{d \times d}$  and  $x \in \mathbb{C}^d$  be a unit vector. Then  $V_x := [V_1 x, \ldots, V_{d^2} x] \in \mathbb{C}^{d \times d^2}$  is an isometry:  $V_x V_x^{\dagger} = \mathbb{I}_d$ .

*Proof.* Let  $V_x^{(k)}$  be the kth row of  $V_x$  written as row vector. It suffices to prove that

$$V_x^{(k)}(V_x^{(l)})^{\dagger} = \delta_{kl}$$

Let  $V_i^{(k)}$  be the kth row of  $V_i$ , written as a row vector. Then the kth element of  $V_i x$  is

$$v_i^{(k)} := V_i^{(k)} x.$$

Since  $V_1, \ldots, V_{d^2}$  are orthonormal, we know that

$$V := [\operatorname{vec}(V_1), \dots, \operatorname{vec}(V_{d^2})]$$

is a unitary matrix in  $\mathbb{C}^{d^2 \times d^2}$ . Let  $V^j$  be the jth row of V, then because V is unitary, the vector dot product  $\langle V^j, V^i \rangle = \delta_{ij}$ . Let

$$V^{(k)} = [(V^k)^{\dagger}, (V^{k+d})^{\dagger}, \dots (V^{k+d(j-1)})^{\dagger}, \dots, (V^{k+d(d-1)})^{\dagger}]^{\dagger}$$

which picks out the kth row of all  $V_1, \ldots, V_{d^2}$ . Then, we have

$$V^{(k)} = [(V_1^{(k)})^\top, \dots, (V_{d^2}^{(k)})^\top].$$

Thus,

$$\sum_{i=1}^{d^2} (V_i^{(k)})^{\dagger} V_i^{(k)} = \overline{V^{(k)}(V^{(k)})^{\dagger}} = \mathbb{I}_d,$$

and for  $k \neq l$ ,

$$\sum_{i=1}^{d^2} (V_i^{(k)})^{\dagger} V_i^{(l)} = \overline{V^{(k)}(V^{(l)})^{\dagger}} = 0.$$

Therefore,

$$V_x^{(k)}(V_x^{(l)})^{\dagger} = \sum_{i=1}^{d^2} v_i^{(k)}(v_i^{(l)})^{\dagger} = \sum_{i=1}^{d^2} x^{\dagger}(V_i^{(l)})^{\dagger} V_i^{(k)} x = x^{\dagger} \delta_{kl} \mathbb{I}_d x = \delta_{kl},$$

exactly as desired, completing the proof.

### <span id="page-33-0"></span>B.2 Proof of Theorem 5.9

<span id="page-33-4"></span>We first prove a general upper bound for Lemma 5.4 with  $\sigma, \sigma' \sim \mathcal{D}_c(\mathcal{V})$ .

**Theorem B.7.** Let  $\ell \in [\frac{d^2}{2}, d^2 - 1]$ ,  $\mathcal{V} = (V_1, \dots, V_{d^2} = \frac{\mathbb{I}_d}{\sqrt{d}})$  be an orthonormal basis of  $\mathbb{H}_d$ , and  $V := [|V_1\rangle\rangle, \dots, |V_\ell\rangle\rangle]$ ,  $\sigma, \sigma' \sim \mathcal{D}_c(\mathcal{V})$  defined in Definition 5.5. Then for  $n < \frac{d^2}{6c^2\varepsilon^2||V^{\dagger}\overline{C}V||_{cr}}$ ,

$$\mathbb{E}_{\sigma,\sigma'}\left[\exp\left\{nd\langle\langle\overline{\Delta}_{\sigma'}|\overline{\mathcal{C}}|\overline{\Delta}_{\sigma}\rangle\rangle\right\}\right] \le \exp\left\{\frac{c^2n^2\varepsilon^4}{\ell^2} \left\|V^{\dagger}\overline{\mathcal{C}}V\right\|_{HS}^2\right\} + \frac{4}{e^d}.$$
 (17)

Proof. We parameterize the distribution  $\mathcal{D}_c(\mathcal{V})$  using  $z, z' \sim \{-1, 1\}^{\ell}$  and  $\Delta_z, \overline{\Delta}_z, \sigma_z$  defined in Definition 5.5. First, we claim that due to the exponentially small probability of the bad event  $\sigma_z = \Delta_z + \rho_{\text{mm}} \notin \mathcal{P}_{\varepsilon}$  as stated in Corollary 5.8, we can consider  $\Delta_z$  instead of the normalized perturbation  $\overline{\Delta}_z$ . The claim is proved at the end of this section.

<span id="page-33-1"></span>**Lemma B.8.** Let  $z, z' \sim \{-1, 1\}^{\ell}$  be uniform and  $\overline{\Delta}_z$  and  $\Delta_z$  be defined in Definition 5.5, then

$$\mathbb{E}_{z,z'}\left[\exp\left\{nd\langle\langle\overline{\Delta}_z|\overline{\mathcal{C}}|\overline{\Delta}_z\rangle\rangle\right\}\right] \leq \mathbb{E}_{z,z'}\left[\exp\left\{nd\langle\langle\Delta_{z'}|\overline{\mathcal{C}}|\Delta_z\rangle\rangle\right\}\right] + \frac{4}{cd}.$$

<span id="page-33-2"></span>We then apply a standard result on the moment generating function of Radamacher chaos.

**Lemma B.9** ([ACT20b, Claim IV.17]). Let z, z' be two independent random vectors distributed uniformly over  $\{-1, 1\}^{\ell}$ . Then for any positive semi-definite real matrix H,

$$\log \mathbb{E}_{z,z'} \left[ \exp \{ \lambda \theta^\top H \theta' \} \right] \le \frac{\lambda^2}{2} \frac{\|H\|_{HS}^2}{1 - 4\lambda^2 \|H\|_{op}^2}, \quad for \ 0 \le \lambda < \frac{1}{\|H\|_{op}}.$$

We now evaluate the inner product. Note that  $C_i$  and  $\overline{C}$  are p.s.d. Hermitian matrices. Setting  $V = [\text{vec}(V_1), \dots, \text{vec}(V_\ell)] \in \mathbb{C}^{d^2 \times \ell}$ , we have  $|\Delta_z\rangle\rangle = \frac{c\varepsilon}{\sqrt{d\ell}} Vz$ . Therefore, set  $H := V^{\dagger} \overline{C} V$ ,

<span id="page-33-3"></span>
$$\langle\langle \overline{\Delta}_{z'} | \overline{\mathcal{C}} | \overline{\Delta}_z \rangle\rangle = \frac{c^2 \varepsilon^2}{d\ell} z^{\dagger} V^{\dagger} \overline{\mathcal{C}} V z' = \frac{c^2 \varepsilon^2}{d\ell} z^{\dagger} H z'. \tag{18}$$

We now show that H is a real matrix when each  $V_i$  is Hermitian. First note that  $\overline{C}|V_j\rangle\rangle = |\overline{H}(V_j)\rangle\rangle$ . Therefore element i, j in H is

<span id="page-34-2"></span>
$$H_{ij} = \langle \langle V_i | \overline{C} | V_j \rangle \rangle = \langle V_i, \overline{H}(V_j) \rangle \in \mathbb{R}.$$
(19)

We used the fact that  $\overline{\mathcal{H}}$  is Hermiticity preserving and thus  $\overline{\mathcal{H}}(V_j)$  is Hermitian. Since  $\mathbb{H}_d$  is a real Hilbert space, the inner product is a real number.

space, the inner product is a real number. We then set  $\lambda = \frac{c^2 n \varepsilon^2}{\ell}$  in Lemma B.9. Thus for  $n < \frac{\ell}{3c^2 \varepsilon^2 ||H||_{\text{op}}}$ , we have

$$\lambda \|H\|_{\mathrm{op}} \leq \frac{c^2 \varepsilon^2}{\ell} \cdot \frac{\ell}{3c^2 \varepsilon^2 \|H\|_{\mathrm{op}}} \cdot \|H\|_{\mathrm{op}} = \frac{1}{3}.$$

The condition on  $\lambda$  in Lemma B.9 is satisfied. Hence, combining (18) and Lemma B.9,

$$\mathbb{E}_{z,z'} \left[ \exp \left\{ nd \langle \langle \Delta_{z'} | \overline{\mathcal{C}} | \Delta_z \rangle \rangle \right\} \right] = \mathbb{E}_{z,z'} \left[ \exp \left\{ \frac{c^2 n \varepsilon^2}{\ell} z^{\top} H z' \right\} \right]$$

$$\leq \exp \left\{ \frac{\lambda^2}{2(1 - 4\lambda^2 \|H\|_{\text{op}}^2)} \|H\|_{\text{HS}}^2 \right\}$$

$$< \exp \left\{ \frac{c^4 n^2 \varepsilon^4}{\ell^2} \|H\|_{\text{HS}}^2 \right\}.$$

The final inequality is because  $\lambda \|H\|_{\text{op}} \leq 1/3$ , and thus  $2(1-4\lambda^2\|H\|_{\text{op}}^2) \geq 2(1-4/9) > 1$ . Combining with Lemma B.8 and plugging in  $H = V^{\dagger} \overline{\mathcal{C}} V$  proves Theorem 5.9.

Set  $H = V^{\dagger} \overline{\mathcal{C}} V$ . To finish the proof of Theorem 5.9, we obtain different bounds for  $\|V^{\dagger} \overline{\mathcal{C}} V\|_{\mathrm{HS}}$  for different choices of the basis  $\mathcal{V}$ . For all orthonormal basis  $\mathcal{V} = (V_1, \dots, V_{d^2})$  of  $\mathbb{H}_d$ , we must have  $V^{\dagger} V = \mathbb{I}_{\ell}$ , and thus V is an isometry and  $\|V\|_{\mathrm{op}} = \|V^{\dagger}\|_{\mathrm{op}} = 1$ . Using  $\|AB\|_{\mathrm{HS}} \leq \|A\|_{\mathrm{op}} \|B\|_{\mathrm{HS}}$ , we obtain a sequence of inequalities for the norms,

$$\|V^{\dagger} \overline{C} V\|_{\text{op}} \le \|V^{\dagger} \overline{C} V\|_{\text{HS}} \le \|\overline{C}\|_{\text{HS}} \tag{20}$$

<span id="page-34-1"></span><span id="page-34-0"></span>
$$\leq \frac{1}{n} \sum_{i=1}^{n} \|\mathcal{C}_i\|_{\mathrm{HS}} \leq \max_{\mathcal{M} \in \mathfrak{M}} \|\mathcal{H}_{\mathcal{M}}\|_{\mathrm{HS}} \tag{21}$$

The second line is due to triangle inequality. Therefore,

$$n \leq \frac{d^2}{6c^2\varepsilon^2 \max_{\mathcal{M} \in \mathfrak{M}} \|\mathcal{C}_{\mathcal{M}}\|_{\mathrm{HS}}} \implies n \leq \frac{d^2}{6c^2\varepsilon^2 \|V^{\dagger} \overline{\mathcal{C}} V\|_{\mathrm{CP}}}.$$

Thus the condition on n in Theorem B.7 is satisfied. Applying the theorem and (20) (21),

$$\mathbb{E}_{\sigma,\sigma'}\left[\exp\left\{nd\langle\langle\overline{\Delta}_{\sigma'}|\overline{\mathcal{C}}|\overline{\Delta}_{\sigma}\rangle\rangle\right\}\right] \leq \exp\left\{\frac{c^2n^2\varepsilon^4}{\ell^2}\max_{\mathcal{M}\in\mathfrak{M}}\left\|\mathcal{H}_{\mathcal{M}}\right\|_{\mathrm{HS}}^2\right\} + \frac{4}{e^d}.$$

Substituting  $\ell = d^2/2$  proves the first part Eq. (12) of Theorem 5.9.

When  $\mathcal{V} = (V_1, \dots, V_{d^2})$  is the eigenbasis of  $\overline{\mathcal{H}}$ , let  $\lambda_i$  be the eigenvalue of  $V_i$ , and by assumption  $\lambda_1 \leq \dots \leq \lambda_{d^2}$ . In this case, using (19)

$$H_{ij} = \langle V_i, \overline{\mathcal{H}}(V_j) \rangle = \lambda_j \langle V_i, V_j \rangle = \lambda_j \delta_{ij}.$$

Therefore  $H = V^{\dagger} \overline{\mathcal{C}} V = \operatorname{diag}\{\lambda_1, \dots, \lambda_\ell\}$ , and  $\|H\|_{\mathrm{HS}}^2 = \sum_{i=1}^{\ell} \lambda_i^2$ . This can be bounded in terms of the trace norm  $\|\overline{\mathcal{H}}\|_1$ . Recall the eigenvalues are sorted in increasing order,

$$\lambda_{\ell} \le \frac{1}{d^2 - \ell} \sum_{i=\ell+1}^{d^2} \lambda_i \le \frac{\|\overline{\mathcal{H}}\|_1}{d^2 - \ell}.$$

The final inequality is due to  $\|\overline{\mathcal{H}}\|_1 = \sum_i \lambda_i$ . Therefore,

<span id="page-35-1"></span>
$$||H||_{HS}^{2} = \sum_{i=1}^{\ell} \lambda_{i}^{2} \le \ell \lambda_{\ell}^{2} \le \ell \left(\frac{||\overline{\mathcal{H}}||_{HS}}{d^{2} - \ell}\right)^{2} = \frac{2||\overline{\mathcal{H}}||_{1}^{2}}{d^{2}}$$
(22)

By linearity of trace,  $\|\overline{\mathcal{H}}\|_1 = \frac{1}{n} \sum_{i=1}^n \|\mathcal{H}_i\|_1 \le \max_{\mathcal{M} \in \mathfrak{M}} \|\mathcal{H}_{\mathcal{M}}\|_1$ . Using (20) and (22),

$$\frac{d^3}{6\sqrt{2}c^2\varepsilon^2\max_{\mathcal{M}\in\mathfrak{M}}\|\mathcal{H}_{\mathcal{M}}\|_1}\leq \frac{d^3}{6\sqrt{2}c^2\varepsilon^2d\|H\|_{\mathrm{HS}}/\sqrt{2}}\leq \frac{d^3}{6c^2\varepsilon^2d\|H\|_{\mathrm{op}}}.$$

The condition is satisfied as long as n is upper bounded by the first expression in the above equation. Therefore, by Theorem B.7,

$$\mathbb{E}_{\sigma,\sigma'}\left[\exp\left\{nd\langle\langle\overline{\Delta}_{\sigma'}|\overline{\mathcal{C}}|\overline{\Delta}_{\sigma}\rangle\rangle\right\}\right] \leq \exp\left\{\frac{2c^2n^2\varepsilon^4}{\ell^2d^4}\max_{\mathcal{M}\in\mathfrak{M}}\left\|\mathcal{H}_{\mathcal{M}}\right\|_1^2\right\} + \frac{4}{e^d}.$$

When  $d \ge 16$ , the extra term  $4/\exp\{d\}$  is negligible. Thus we complete the proof of Theorem 5.9.

#### <span id="page-35-0"></span>B.2.1 Proof of Lemma B.8

*Proof.* Note that  $\overline{\Delta}_z = a_z \Delta_z$  where

$$a_z := \min\left\{1, \frac{1}{d\|\Delta_z\|_{\text{op}}}\right\} \in [0, 1].$$

Therefore

$$\langle \langle \overline{\Delta}_z | \overline{\mathcal{C}} | \overline{\Delta}_z \rangle \rangle = a_z a_{z'} \langle \langle \Delta_z | \overline{\mathcal{C}} | \Delta_z \rangle \rangle.$$

As a short hand let  $f(z,z') = nd\langle\langle\overline{\Delta}_z|\overline{\mathcal{C}}|\overline{\Delta}_z\rangle\rangle$ . Denote event E as f(z,z') < 0 and  $a_za_{z'} < 1$ . When this event occors,  $\exp\{a_za_{z'}f(z,z')\} \leq 1$ . Using Corollary 5.8, let  $\delta = 2\exp(-d)$ ,

$$\Pr[a_z < 1] < \delta.$$

Thus by union bound,

$$\Pr[E] < \Pr[a_z a_{z'} < 1] = \Pr[a_z < 1 \text{ or } a_{z'} < 1] < 2\delta.$$

Note that  $E^c$  denotes the event that  $f(z,z') \ge 0$  or  $a_z a_z' = 1$ . When this occurs,  $a_z a_{z'} f(z,z') \le f(z,z')$ . Thus,

$$\mathbb{E}_{z,z'} [\exp \{a_z a_{z'} f(z,z')\}]$$

$$= \mathbb{E}_{z,z'} [\exp \{a_z a_{z'} f(z,z')\} \mid E^c] \Pr[E^c] + \mathbb{E}_{z,z'} [\exp \{a_z a_{z'} f(z,z')\} \mid E] \Pr[E]$$

$$\leq \mathbb{E}_{z,z'} [\exp \{f(z,z')\} \mid E^c] \Pr[E^c] + 2\delta$$

$$\leq \mathbb{E}_{z,z'} [\exp \{f(z,z')\}] + 2\delta,$$

as desired. The second-to-last inequality uses  $a_z f_z' f(z, z') \le 0$  when event E happens, and the final inequality uses  $\exp\{f(z, z')\} > 0$  and therefore

$$\mathbb{E}_{z,z'}[\exp\{f(z,z')\}] = \mathbb{E}_{z,z'}[\exp\{f(z,z')\} \mid E^c] \Pr[E^c] + \mathbb{E}_{z,z'}[\exp\{f(z,z')\} \mid E] \Pr[E]$$

$$\geq \mathbb{E}_{z,z'}[\exp\{f(z,z')\} \mid E^c] \Pr[E^c].$$

Plugging in the definition of  $a_z$  and f(z, z') completes the proof.

| λ                    | $(1^4)$  | $(21^2)$  | $(2^2)$  | (31)      | (4)        |
|----------------------|----------|-----------|----------|-----------|------------|
| $ \{\lambda\} $      | 1        | 6         | 3        | 8         | 6          |
| $\mathrm{Wg}_d(\pi)$ | $d^{-4}$ | $-d^{-5}$ | $d^{-6}$ | $2d^{-6}$ | $-5d^{-7}$ |

<span id="page-36-5"></span>Table 2: Size of each equivalent class  $\{\lambda\}$  and the asymptotics of Wg<sub>d</sub> for  $\mathcal{S}_4$ .

# <span id="page-36-0"></span>C Proof of quantum domain compression

# <span id="page-36-2"></span><span id="page-36-1"></span>C.1 Weingarten calculus

#### C.1.1 Partitions and permutations

Let d, q be positive integers. A partition  $\lambda \vdash q$  is an integer vector  $\lambda = (\lambda_1, \dots, \lambda_q)$  where  $\lambda_1 \geq \dots \geq \lambda_q \geq 0$  and  $\sum_i \lambda_i = q$ .  $\lambda$  can also be represented in terms of the unique elements and their multiplicity. For example,  $(2^11^2)$  represents the partition  $\lambda = (2, 1, 1)$ .

A permutation  $\pi:[n] \mapsto [n]$  is a bijection over [n]. Let  $\mathcal{S}_n$  be the group of permutations over [n] (also called the symmetric group). Each permutation  $\pi \in \mathcal{S}_n$  can be decomposed into cycles. We denote  $\mathcal{C}(\pi)$  as the set of cycles in  $\pi$ . For example, for the permutation  $\pi = (2, 3, 1, 4)$ , the cycles are

$$C(\pi) = \{(1, 2, 3), (4)\}.$$

The cycle lengths  $|c|, c \in \mathcal{C}(\pi)$  form a partition of n, which is (31) for the previous example. We say that  $\pi$  has a cycle type  $\lambda \vdash n$  if the cycle lengths form a partition  $\lambda$ . We can thus group the permutations according to their cycle types  $\lambda$ . Let  $\{\lambda\}$  be the set of permutations with cycle type  $\lambda$ . We sometimes abuse notation and use  $\lambda$  to denote  $\{\lambda\}$  when it is clear from the context.

We use e to denote the identity permutation, which has cycle type  $(1^n)$ .

### <span id="page-36-3"></span>C.1.2 Weingartun functions

The Weingarten function  $\operatorname{Wg}_{d,q}: \mathcal{S}_q \mapsto \mathbb{R}$  is defined for permutations in  $\mathcal{S}_q$ . If  $\pi$  and  $\tau$  have the same cycle type, then  $\operatorname{Wg}_{d,q}(\pi) = \operatorname{Wg}_{d,q}(\tau)$ . Thus we can parameterize the input to  $\operatorname{Wg}_{d,q}$  by partitions of q. We drop q in the subscript when it can be clearly defined by the permutation  $\pi$ .

The precise definition can be found in [Col03, CS06] It involves Schur polynomials and character functions which we do not need in our proof. Below are some simple examples of Weingarten functions with q = 1, 2.

<span id="page-36-6"></span>
$$\operatorname{Wg}_{d}(1) = \frac{1}{d}, \quad \operatorname{Wg}_{d}(2) = -\frac{1}{d(d^{2} - 1)}, \quad \operatorname{Wg}_{d}(1^{2}) = \frac{1}{d^{2} - 1}.$$
 (23)

<span id="page-36-4"></span>The asymptotic behavior of  $Wg_d$  is characterized by the lemma below,

**Lemma C.1** ([CŚ06, Corollary 2.7]). Let  $C(\pi)$  be the set of cycles in  $\pi \in S_q$ , and  $|\pi| := q - |C(\pi)|$ . As  $d \to \infty$ ,

$$Wg_d(\pi) = (1 + O(d^{-2}))Mob(\pi)d^{-q-|\pi|}.$$

Here  $Mob(\pi) = \prod_{c \in \mathcal{C}(\pi)} (-1)^{|c|-1} \operatorname{Cat}_{|c|-1}$ , |c| is the length of cycle c, and  $\operatorname{Cat}_n = \frac{1}{2n+1} \binom{2n+1}{n}$  is the Catalan number.

Thus,  $\operatorname{Wg}_{d,q}$  is a rational function with respect to d with degree at most  $d^{-q}$ , which is achieved if and only if  $\pi = e$ , the identity. The leading constant factor is determined by  $\operatorname{Mob}(\pi)$ . We compute the asymptotics of  $\operatorname{Wg}_d(\pi)$  for  $\pi \in \mathcal{S}_4$  in Table 2 which we will use in our proof.

#### <span id="page-37-0"></span>C.1.3 Computing Haar integrals

For each permutation  $\pi \in \mathcal{S}_{\ell}$ , we can define the permutation operator  $P_{\pi} \in \mathbb{C}^{d^{\ell} \times d^{\ell}}$ , which acts on  $\mathbb{C}^{d^{\ell}}$  as

$$P_{\pi}|x_1\rangle \otimes \cdots \otimes |x_{\ell}\rangle = |x_{\pi(1)}\rangle \otimes \cdots \otimes |x_{\pi(\ell)}\rangle.$$

<span id="page-37-2"></span>Let  $\mathcal{U}_d$  be the Haar measure over unitary matrices in  $\mathbb{C}^{d\times d}$ . Lemma C.2 helps us to compute expectations of unitary transformations of matrices.

**Lemma C.2** ([BCHJ<sup>+</sup>21], Eq.7.32). For all matrix  $M \in \mathbb{C}^{d^{\ell} \times d^{\ell}}$ ,

$$\mathbb{E}_{U \sim \mathcal{U}_d} \left[ (U^{\dagger})^{\otimes \ell} M U^{\otimes \ell} \right] = \sum_{\pi, \tau \in \mathcal{S}_{\ell}} W g_d(\pi^{-1} \tau) P_{\pi} \operatorname{Tr}[P_{\tau} M].$$

For  $A \in \mathbb{C}^{d \times d}$  and a permutation  $\pi \in \mathcal{S}_{\ell}$ , we define

<span id="page-37-5"></span>
$$\langle A \rangle_{\pi} := \text{Tr}[P_{\pi}A^{\otimes \ell}] = \prod_{c \in \mathcal{C}(\pi)} \text{Tr}[A^{|c|}].$$
 (24)

<span id="page-37-3"></span>The following useful lemma is a corollary of Lemma C.2.

**Lemma C.3** ([CLO22], Lemma 3.13). For  $d \geq 2$ ,  $\ell$  positive integer,  $A, B \in \mathbb{C}^{d \times d}$ , we have

$$\mathbb{E}_{U \sim \mathcal{U}_d} \left[ \operatorname{Tr} [AU^{\dagger} BU]^{\ell} \right] = \sum_{\pi, \tau \in \mathcal{S}_{\ell}} W g_d(\pi^{-1} \tau) \langle A \rangle_{\pi} \langle B \rangle_{\tau}.$$

When  $\ell = 1$ ,  $\mathbb{E}_{U \sim \mathcal{U}_d} \left[ \operatorname{Tr}[AU^{\dagger}BU] \right] = \operatorname{Tr}[A] \operatorname{Tr}[B]/d$ .

#### <span id="page-37-1"></span>C.2 Proof of Lemma 6.1

We first recall some definitions. Let  $k \leq d$  be powers of 2 and r := d/k. Let  $U = [|u_1\rangle, \dots, |u_d\rangle]$  be drawn from the Haar measure. We define the projections  $\Pi_x^U := \sum_{i=(r-1)x+1}^{rx} |u_i\rangle\langle u_i|$ , which divides  $\mathbb{C}^d$  into orthogonal subspaces with equal dimensions. Let  $\mathcal{M}_U = \{\Pi_x^U\}_{x=1}^k$ . The distribution  $\mathbf{p}_\rho^U$  is defined by the Born's rule where  $\mathbf{p}_\rho^U(x) = \text{Tr}[\Pi_x^U\rho]$ .

For brevity, we omit all the superscripts and subscripts of U when it is clear from the context. The projection matrices satisfy  $(\Pi_x)^2 = \Pi_x$  and  $\text{Tr}[\Pi_x] = r = d/k$ . Furthermore, we can write  $\Pi_x = UD_xU^{\dagger}$ , where  $D_x$  is a diagonal matrix with 1 at the (r-1)x+1 to rx diagonal entries and 0 elsewhere.

We now compute the  $\ell_2$  norms. Let  $\Delta = \rho - \rho_0$ ,

$$\|\mathbf{p}_{\rho}\|_{2}^{2} = \sum_{x=1}^{k} \operatorname{Tr}[\Pi_{x}\rho]^{2}, \quad \|\mathbf{p}_{\rho} - \mathbf{p}_{\rho_{0}}\|_{2}^{2} = \sum_{x=1}^{k} \operatorname{Tr}[\Pi_{x}\Delta]^{2}.$$

By symmetry of the Haar measure,

$$\mathbb{E}_{U}\left[\left\|\mathbf{p}_{\rho}\right\|_{2}^{2}\right] = k\mathbb{E}_{U}\left[\operatorname{Tr}[\Pi_{1}\rho]^{2}\right], \quad \mathbb{E}_{U}\left[\left\|\mathbf{p}_{\rho} - \mathbf{p}_{\rho_{0}}\right\|_{2}^{2}\right] = k\mathbb{E}_{U}\left[\operatorname{Tr}[\Pi_{x}\Delta]^{2}\right].$$

<span id="page-37-4"></span>Both quantities can be computed using the lemma below,

**Lemma C.4.** Let  $M \in \mathbb{C}^{d \times d}$  be a matrix,  $U = [|u_1\rangle, \dots, |u_d\rangle]$  drawn from the Haar measure, and  $\Pi_1 = \sum_{i=1}^r |u_i\rangle\langle u_i|$  where r = d/k. Then

$$\mathbb{E}_{U}\left[\operatorname{Tr}[\Pi_{1}M]^{2}\right] = \frac{1}{k(d^{2}-1)}\left(\operatorname{Tr}[M]^{2}\left(\frac{d^{2}}{k}-1\right) + \operatorname{Tr}[M^{2}]d\left(1-\frac{1}{k}\right)\right).$$

*Proof.* Let  $D_1$  be a diagonal matrix where the first r diagonal entries are 1 and 0 everywhere else, then  $\Pi_1 = UD_1U^{\dagger}$ . Thus, we can apply Lemma C.3 and (23),

$$\begin{split} &\mathbb{E}_{U}\left[\operatorname{Tr}[\Pi_{1}M]^{2}\right] \\ =& \mathbb{E}_{U}\left[\operatorname{Tr}[UD_{1}U^{\dagger}M]^{2}\right] = \mathbb{E}_{U}\left[\operatorname{Tr}[D_{1}U^{\dagger}MU]^{2}\right] \\ =& \sum_{\pi,\tau\in\mathcal{S}_{2}} \operatorname{Wg}_{d}(\pi^{-1}\tau)\langle D_{1}\rangle_{\pi}\langle M\rangle_{\tau} \\ =& \frac{1}{d^{2}-1}(\operatorname{Tr}[D_{1}]^{2}\operatorname{Tr}[M]^{2}+\operatorname{Tr}[D_{1}^{2}]\operatorname{Tr}[M^{2}]) - \frac{1}{d(d^{2}-1)}(\operatorname{Tr}[D_{1}]^{2}\operatorname{Tr}[M^{2}]+\operatorname{Tr}[D_{1}^{2}]\operatorname{Tr}[M]^{2}) \\ =& \frac{\operatorname{Tr}[D_{1}]}{d(d^{2}-1)}\left(\operatorname{Tr}[M]^{2}(d\operatorname{Tr}[D_{1}]-1)+\operatorname{Tr}[M^{2}](d-\operatorname{Tr}[D_{1}])\right) \\ =& \frac{1}{k(d^{2}-1)}\left(\operatorname{Tr}[M]^{2}\left(\frac{d^{2}}{k}-1\right)+\operatorname{Tr}[M^{2}]d\left(1-\frac{1}{k}\right)\right). \end{split}$$

In the last two steps, we used  $Tr[D_1^2] = Tr[D_1] = d/k$ .

#### <span id="page-38-0"></span>C.2.1 Upper bounding $\|\mathbf{p}_{\rho}\|_{2}$

Note that  $\text{Tr}[\rho^2] \leq \text{Tr}[\rho] = 1$ . From Lemma C.4, we can immediately upper bound  $\mathbb{E}_U \left[ \|\mathbf{p}_\rho\|_2^2 \right]$ ,

$$\mathbb{E}_{U} \left[ \|\mathbf{p}_{\rho}\|_{2}^{2} \right] = \frac{1}{d^{2} - 1} \left( \text{Tr}[\rho]^{2} \left( \frac{d^{2}}{k} - 1 \right) + \text{Tr}[\rho^{2}] d \left( 1 - \frac{1}{k} \right) \right)$$

$$\leq \frac{1}{d^{2} - 1} \left( \frac{d^{2}}{k} - 1 + d - \frac{d}{k} \right)$$

$$= \frac{d - 1}{d^{2} - 1} \left( \frac{d}{k} + 1 \right)$$

$$= \frac{d + k}{k(d + 1)} \leq \frac{2}{k}.$$

The final inequality is due to  $k \leq d$  and thus  $d + k \leq 2(d + 1)$ . Therefore by Markov's inequality,

$$\Pr_{U} \left[ \|\mathbf{p}_{\rho}\|_{2} \ge \frac{10}{\sqrt{k}} \right] = \Pr_{U} \left[ \|\mathbf{p}_{\rho}\|_{2}^{2} \ge \frac{100}{k} \right] \le \frac{\mathbb{E}_{U} \left[ \|\mathbf{p}_{\rho}\|_{2}^{2} \right]}{100/k} \le \frac{1}{50} = 0.02.$$
 (25)

<span id="page-38-2"></span>

# <span id="page-38-1"></span>C.2.2 Lower bounding $\|\mathbf{p}_{\rho} - \mathbf{p}_{\rho_0}\|_2$

For convenience we set  $Z = \|\mathbf{p}_{\rho} - \mathbf{p}_{\rho_0}\|_2^2$ . First from Lemma C.4,

$$\mathbb{E}[Z] = \mathbb{E}_{U} \left[ \| \mathbf{p}_{\rho} - \mathbf{p}_{\rho_{0}} \|_{2}^{2} \right] = \frac{1}{d^{2} - 1} \left( \operatorname{Tr}[\Delta]^{2} \left( \frac{d^{2}}{k} - 1 \right) + \operatorname{Tr}[\Delta^{2}] d \left( 1 - \frac{1}{k} \right) \right)$$

$$= \operatorname{Tr}[\Delta^{2}] \cdot \frac{d}{d^{2} - 1} \left( 1 - \frac{1}{k} \right)$$

$$= \frac{\operatorname{Tr}[\Delta^{2}]}{d} \left( 1 - \frac{1}{k} \right) (1 + O(d^{-2})). \tag{26}$$

Thus  $\mathbb{E}[Z] = \Theta\left(\frac{\text{Tr}[\Delta^2]}{d}\right)$ . Intuitively, the random variable should concentrate around its mean, so we expect  $Z < \theta \mathbb{E}[Z]$  with high probability. To formally prove this, we need to upper bound the second moment  $\mathbb{E}[Z^2]$ 

by roughly  $\mathbb{E}[Z]^2 = \Theta\left(\frac{\text{Tr}[\Delta^2]^2}{d^2}\right)$ .

$$\mathbb{E}[Z^2] = \sum_{x,y=1}^k \operatorname{Tr}[\Pi_x \Delta]^2 \operatorname{Tr}[\Pi_y \Delta]^2$$

$$= k \mathbb{E}_U \left[ \operatorname{Tr}[\Pi_1 \Delta]^4 \right] + k(k-1) \mathbb{E}_U \left[ \operatorname{Tr}[\Pi_1 \Delta]^2 \operatorname{Tr}[\Pi_2 \Delta]^2 \right]. \tag{27}$$

<span id="page-39-0"></span>The two terms are bounded in Lemmas C.5 and C.6. The proofs are very technical and can be found in Appendices C.3.1 and C.3.2 respectively.

**Lemma C.5.** Let  $\Delta \in \mathbb{C}^{d \times d}$  be  $\text{Tr}[\Delta] = 0$  and  $\Pi = \Pi_1$  defined in Lemma C.4. Then,

<span id="page-39-2"></span>
$$\mathbb{E}_{U}\left[\operatorname{Tr}[\Pi\Delta]^{4}\right] \leq \frac{3\operatorname{Tr}[\Delta^{2}]^{2}}{d^{2}k^{2}}\left(\left(1 - \frac{1}{k}\right)^{2} + \frac{2k}{d} + O(d^{-1})\right).$$

<span id="page-39-1"></span>**Lemma C.6.** Let  $\Delta \in \mathbb{C}^{d \times d}$  be trace-0 and  $\Pi_1, \Pi_2$  defined in the beginning of Appendix C.2. Then

$$\mathbb{E}_{U}\left[\operatorname{Tr}[\Pi_{1}\Delta]^{2}\operatorname{Tr}[\Pi_{2}\Delta]^{2}\right] \leq \frac{\operatorname{Tr}[\Delta^{2}]^{2}}{d^{2}k^{2}}\left(1 - \frac{2}{k} + \frac{3}{k^{2}} + O(d^{-1})\right).$$

Combining (27) and Lemmas C.5 and C.6,

$$\begin{split} \mathbb{E}\big[Z^2\big] &= \frac{3\operatorname{Tr}[\Delta^2]^2}{d^2k} \Bigg( \bigg(1 - \frac{1}{k}\bigg)^2 + \frac{2k}{d} + O(d^{-1}) \Bigg) + \frac{\operatorname{Tr}[\Delta^2]^2(k-1)}{d^2k} \bigg(1 - \frac{2}{k} + \frac{3}{k^2} + O(d^{-1}) \bigg) \\ &= \frac{\operatorname{Tr}[\Delta^2]^2}{d^2} \bigg( \bigg(1 - \frac{1}{k}\bigg) \bigg(\frac{3}{k} - \frac{3}{k^2} + 1 - \frac{2}{k} + \frac{3}{k^2}\bigg) + O(d^{-1}) \bigg) \\ &= \frac{\operatorname{Tr}[\Delta^2]^2}{d^2} \bigg(1 - \frac{1}{k^2} + O(d^{-1})\bigg). \end{split}$$

Combining with (26), by Paley-Zygmund, for  $\theta \in (0,1)$ 

$$\Pr[Z > \theta \mathbb{E}[Z]] \ge (1 - \theta)^2 \frac{\mathbb{E}[Z]^2}{\mathbb{E}[Z^2]}$$

$$\ge (1 - \theta)^2 \frac{(1 - k^{-1})^2}{1 - k^{-2}} \cdot \frac{1 + O(d^{-1})}{1 + O(d^{-1})}$$

$$= (1 - \theta)^2 \frac{k - 1}{k + 1} \cdot \frac{1 + O(d^{-1})}{1 + O(d^{-1})}.$$

Finally note that  $\mathbb{E}[Z] \simeq \frac{\text{Tr}[\Delta^2]}{d}(1-1/k) \geq \frac{\|\rho-\rho_0\|_{HS}^2}{2d}$ . For  $k \geq 2$  and sufficiently large d, e.g.  $d \geq 100$ ,

$$\Pr\left[\left\|\mathbf{p}_{\rho} - \mathbf{p}_{\rho_{0}}\right\|_{2} > 0.07 \cdot \frac{\left\|\rho - \rho_{0}\right\|_{\mathrm{HS}}}{\sqrt{d}}\right] = \Pr\left[Z > 0.0049 \frac{\left\|\rho - \rho_{0}\right\|_{\mathrm{HS}}^{2}}{d}\right]$$

$$\geq \Pr\left[Z > 0.01\mathbb{E}[Z]\right]$$

$$\geq 0.99^{2} \cdot \frac{1}{3} \cdot \frac{k - 1}{k + 1} \cdot \frac{1 + O(d^{-1})}{1 + O(d^{-1})} \geq 0.13.$$

This completes the proof of Lemma 6.1.

## <span id="page-40-1"></span><span id="page-40-0"></span>C.3 Upper bounding the 4th order terms

#### C.3.1 Proof of Lemma C.5

*Proof.* We directly apply Lemma C.4. Recall  $\Pi = UDU^{\dagger}$  where  $D = D_1$ .

$$\mathbb{E}_{U}\left[\operatorname{Tr}[\Pi\Delta]^{4}\right] = \mathbb{E}_{U}\left[\operatorname{Tr}[UDU^{\dagger}\Delta]^{4}\right]$$
$$= \sum_{\pi,\tau \in \mathcal{S}_{4}} \operatorname{Wg}_{d}(\pi^{-1}\tau)\langle D \rangle_{\pi}\langle \Delta \rangle_{\tau}$$

We first compute  $\langle D \rangle_{\pi}, \langle \Delta \rangle_{\tau}$  using (24). Since  $D^2 = D$  and Tr[D] = r = d/k

<span id="page-40-3"></span>
$$\langle D \rangle_{\pi} = \text{Tr}[D]^{|\mathcal{C}(\pi)|} = (d/k)^{|\mathcal{C}(\pi)|}.$$
(28)

Since  $\text{Tr}[\Delta] = 0$ ,  $\langle \Delta \rangle_{\tau} = 0$  if  $\tau$  has a cycle of length 1. Thus,  $\langle \Delta \rangle_{\tau} \neq 0$  only if (4) or (2<sup>2</sup>) where

$$\langle \Delta \rangle_{\tau} = \begin{cases} \operatorname{Tr}[\Delta^{4}], & \tau \in \{(4)\} \\ \operatorname{Tr}[\Delta^{2}]^{2}, & \tau \in \{(2^{2})\}. \end{cases}$$
 (29)

Therefore,

$$\begin{split} \mathbb{E}_{U} \left[ \operatorname{Tr}[\Pi_{1} \Delta]^{4} \right] &= \operatorname{Tr}[\Delta^{2}]^{2} \sum_{\pi \in \mathcal{S}_{4}, \tau \in (2^{2})} \operatorname{Wg}_{d}(\pi^{-1} \tau) \langle D \rangle_{\pi} + \operatorname{Tr}[\Delta^{4}] \sum_{\pi \in \mathcal{S}_{4}, \tau \in (4)} \operatorname{Wg}_{d}(\pi^{-1} \tau) \langle D \rangle_{\pi} \\ &= 3 \operatorname{Tr}[\Delta^{2}]^{2} \sum_{\pi \in \mathcal{S}_{4}} \operatorname{Wg}_{d}(\pi^{-1} \tau_{0}) \langle D \rangle_{\pi} + 6 \operatorname{Tr}[\Delta^{4}] \sum_{\pi \in \mathcal{S}_{4}} \operatorname{Wg}_{d}(\pi^{-1} \tau_{1}) \langle D \rangle_{\pi}, \end{split}$$

where  $\tau_0$  is a permutation with cycle type (2<sup>2</sup>), e.g. (2,1,4,3) and  $\tau_1$  has cycle type (4), e.g. (2,3,4,1). The second step follows by symmetry.

<span id="page-40-2"></span>The next step is to find all terms of  $Wg_d(\pi^{-1}\tau)\langle D\rangle_{\pi}$  with order  $d^{-2}$ . Given  $\tau$ , the cycle types of  $\pi^{-1}\tau$  and their multiplicities are listed in Table 3.

| $\pi^{-1}$                     | $(1^4)$    | $(21^2)$    | $(2^2)$     | (31)        | (4)         |
|--------------------------------|------------|-------------|-------------|-------------|-------------|
| $\pi^{-1}\tau, \tau \in (2^2)$ | $(2^2), 1$ | $(21^2), 2$ | $(1^4), 1$  | (31),8      | $(21^2), 4$ |
| $n  r, r \in (2)$              |            | (4), 4      | $(2^2), 2$  |             | (4), 2      |
| $\pi^{-1}\tau, \tau \in (4)$   | (4), 1     | $(2^2), 2$  | $(21^2), 2$ | (4), 4      | (31), 4     |
|                                |            | (31), 4     | (4), 1      | $(21^2), 4$ | $(1^4), 1$  |
|                                |            |             |             |             | $(2^2), 1$  |

Table 3: Cycle types of  $\pi^{-1}\tau$  when  $\tau$  has cycle type (2<sup>2</sup>) and (4). The number after each cycle type indicates the multiplicity for fixed  $\tau$ . The red entries are of order  $\Theta_k(d^{-2})$  and the blue entry is  $d^{-3}k^{-1}$ . All other terms are  $O(d^{-3}k^{-2})$ .

Using (28), Table 2, and that  $Tr[\Delta^4] \leq Tr[\Delta^2]^2$ , we have

$$\mathbb{E}_{U}\left[\operatorname{Tr}[\Pi_{1}\Delta]^{4}\right] = 3\operatorname{Tr}[\Delta^{2}]^{2}\left(\frac{1}{d^{2}k^{4}} - \frac{2}{d^{2}k^{3}} + \frac{1}{d^{2}k^{2}} + O(d^{-3})\right) + 6\operatorname{Tr}[\Delta^{4}]\left(\frac{1}{d^{3}k} + O(d^{-3}k^{-2})\right)$$

$$\leq \frac{3\operatorname{Tr}[\Delta^{2}]^{2}}{d^{2}k^{2}}\left(\left(1 - \frac{1}{k}\right)^{2} + \frac{2k}{d} + O(d^{-1})\right).$$

The proof is complete.

#### <span id="page-41-0"></span>C.3.2 Proof of Lemma C.6

*Proof.* Recall that  $\Pi_x = UD_xU^{\dagger}$ . First, we apply Lemma C.2.

$$\begin{split} \mathbb{E}_{U} \big[ \operatorname{Tr}[\Pi_{1} \Delta]^{2} \operatorname{Tr}[\Pi_{2} \Delta]^{2} \big] &= \mathbb{E}_{U} \big[ \operatorname{Tr} \big[ (\Pi_{1}^{\otimes 2} \otimes \Pi_{2}^{\otimes 2}) \Delta^{\otimes 4} \big] \big] \\ &= \operatorname{Tr} \big[ \mathbb{E}_{U} \big[ U^{\otimes 4} (D_{1}^{\otimes 2} \otimes D_{2}^{\otimes 2}) (U^{\dagger})^{\otimes 4} \Delta^{\otimes 4} \big] \big] \\ &= \sum_{\pi, \tau \in \mathcal{S}_{4}} \operatorname{Wg}_{d}(\pi^{-1} \tau) \operatorname{Tr}[P_{\pi} (D_{1}^{\otimes 2} \otimes D_{2}^{\otimes 2})] \operatorname{Tr}[P_{\tau} \Delta^{\otimes 4}] \\ &= \sum_{\pi, \tau \in \mathcal{S}_{4}} \operatorname{Wg}_{d}(\pi^{-1} \tau) \operatorname{Tr}[P_{\pi} (D_{1}^{\otimes 2} \otimes D_{2}^{\otimes 2})] \langle \Delta \rangle_{\tau}. \end{split}$$

We need to compute  $\text{Tr}[P_{\pi}(D_1^{\otimes 2} \otimes D_2^{\otimes 2})]$ . Write  $D_1 = \sum_{i=1}^r |e_i\rangle\langle e_i|$  and  $D_2 = \sum_{i=1}^r |f_i\rangle\langle f_i|$  where  $\langle e_i|f_j\rangle = 0$ . Then,

$$D_1^{\otimes 2} \otimes D_2^{\otimes 2} = \sum_{i,j,k,l} |e_i, e_j, f_k, f_l\rangle \langle e_i, e_j, f_k, f_l|.$$

Let  $S^* = S_2 \times S_2$  be the set of permutations that maps  $\{1, 2\}$  to  $\{1, 2\}$  and  $\{3, 4\}$  to  $\{3, 4\}$ , which only has 4 permutations,

$$S^* = \{(1, 2, 3, 4), (2, 1, 3, 4), (1, 2, 4, 3), (2, 1, 4, 3)\}.$$

If  $\pi \notin \mathcal{S}^*$ , then  $\text{Tr}[P_{\pi}(D_1^{\otimes 2} \otimes D_2^{\otimes 2})] = 0$ . For example, if 1 maps to 3, then

$$\operatorname{Tr}[P_{\sigma}|e_{i}, e_{j}, f_{k}, f_{l}\rangle\langle e_{i}, e_{j}, f_{k}, f_{l}|] = \operatorname{Tr}[|\cdot, \cdot, e_{i}, \cdot\rangle\langle e_{i}, e_{j}, f_{k}, f_{l}|]$$

$$= \langle e_{i}|\cdot\rangle\langle e_{j}|\cdot\rangle\langle f_{k}|e_{i}\rangle\langle f_{l}|\cdot\rangle$$

$$= 0$$

Thus we only need to consider  $\pi \in \mathcal{S}^*$ . Observe that for  $\pi \in \mathcal{S}^*$ , we can write  $P_{\pi} = P_{\pi_1} \otimes P_{\pi_2}$  where  $\pi_1, \pi_2 \in \mathcal{S}_2$ . Therefore,

$$\operatorname{Tr}[P_{\pi}(D_{1}^{\otimes 2} \otimes D_{2}^{\otimes 2}) = \operatorname{Tr}[P_{\pi_{1}} \otimes P_{\pi_{2}}(D_{1}^{\otimes 2} \otimes D_{2}^{\otimes 2})$$

$$= \operatorname{Tr}[P_{\pi_{1}}D_{1}^{\otimes 2}] \operatorname{Tr}[P_{\pi_{2}}D_{2}^{\otimes 2}]$$

$$= \langle D_{1} \rangle_{\pi_{1}} \langle D_{2} \rangle_{\pi_{2}}$$

$$= \left(\frac{d}{k}\right)^{|\mathcal{C}(\pi)|}.$$

We proceed to evaluate the expression,

$$\begin{split} & \mathbb{E}_{U} \left[ \operatorname{Tr}[\Pi_{1} \Delta]^{2} \operatorname{Tr}[\Pi_{2} \Delta]^{2} \right] \\ &= \sum_{\pi \in \mathcal{S}^{*}, \tau \in \mathcal{S}_{4}} \operatorname{Wg}_{d}(\pi^{-1} \tau) \left( \frac{d}{k} \right)^{|\mathcal{C}(\pi)|} \langle \Delta \rangle_{\tau} \\ &= \operatorname{Tr}[\Delta^{4}] \sum_{\pi \in \mathcal{S}^{*}, \tau \in (4)} \operatorname{Wg}_{d}(\pi^{-1} \tau) \left( \frac{d}{k} \right)^{|\mathcal{C}(\pi)|} + \operatorname{Tr}[\Delta^{2}]^{2} \sum_{\pi \in \mathcal{S}^{*}, \tau \in (2^{2})} \operatorname{Wg}_{d}(\pi^{-1} \tau) \left( \frac{d}{k} \right)^{|\mathcal{C}(\pi)|}. \end{split}$$

The cycle types in Table 3 also apply here. Only for  $\tau \in (2^2)$ , the term has order  $\Theta_k(d^{-2})$ , and for all other terms the order is  $O(d^{-3}k^{-2})$ . We can count the multiplicity of the red terms.

- 1. Wg<sub>d</sub>(2<sup>2</sup>) has 3 terms, where  $\pi = e$ , and  $\tau \in (2^2)$  can be arbitrary.
- 2. Wg<sub>d</sub>(21<sup>2</sup>) has 2 terms. From Table 3, we know that  $|\{\pi^{-1}\tau \in (21^2) : \pi \in (21^2), \tau \in (2^2)\}| = 2 \times 3 = 6$ . By symmetry for each fixed  $\pi_0 \in (21^2)$ ,  $|\{\pi_0^{-1}\tau \in (21^2) : \tau \in (2^2)\}| = 6/|(21^2)| = 1$ . There are two permutations  $\pi \in \mathcal{S}^*$  with cycle (21<sup>2</sup>), so the multiplicity is 2.

3. Wg*<sup>d</sup>* (1<sup>4</sup> ) has 1 term. The only *<sup>π</sup>* ∈ S<sup>∗</sup> with cycle (2<sup>2</sup> ) is *π* = (2*,* 1*,* 4*,* 3), and *π* −1 *τ* = *e* if and only if *τ* = *π* = (2*,* 1*,* 4*,* 3).

Summarizing the results and using the asymptotics in Table [2,](#page-36-5)

$$\mathbb{E}_{U}\left[\operatorname{Tr}[\Pi_{1}\Delta]^{2}\operatorname{Tr}[\Pi_{2}\Delta]^{2}\right] = \operatorname{Tr}[\Delta^{4}]O(d^{-3}k^{-2}) + \operatorname{Tr}[\Delta^{2}]^{2}\left(\frac{1}{d^{2}k^{2}} - \frac{2}{d^{2}k^{3}} + \frac{3}{d^{2}k^{4}}\right)$$

$$\leq \frac{\operatorname{Tr}[\Delta^{2}]^{2}}{d^{2}k^{2}}\left(1 - \frac{2}{k} + \frac{3}{k^{2}} + O(d^{-1})\right).$$

The proof is complete.