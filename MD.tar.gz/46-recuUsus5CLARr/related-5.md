# Big O notation

Contributors to Wikimedia projects

![](_page_0_Figure_2.jpeg)

Example of Big O notation:

$$f(x)=O(g(x))$$
 as  $x o\infty$  since there exists  $M>0$  (e.g.,  $M=1$ ) and  $x_0$  (e.g.,  $x_0=5$ ) such that  $0 \le f(x) \le Mg(x)$  whenever  $x \ge x_0$ 

Big O notation is a <u>mathematical notation</u> that describes the <u>limiting behavior</u> of a <u>function</u> when the <u>argument</u> tends towards a particular value or infinity. Big O is a member of a invented by German mathematicians <u>Paul Bachmann</u>, <u>Edmund Landau</u>, and others, collectively called **Bachmann–Landau notation** or **asymptotic notation**. The letter O was chosen by Bachmann to stand for <u>Ordnung</u>, meaning the order of approximation.

In <u>computer science</u>, big O notation is used to <u>classify algorithms</u> according to how their run time or space requirements grow as the input size grows. In <u>analytic number theory</u>, big O notation is often used to express a bound on the difference between an <u>arithmetical function</u> and a better understood approximation; one well-known example is the remainder term in the <u>prime number theorem</u>. Big O notation is also used in many other fields to provide similar estimates.

Big O notation characterizes functions according to their growth rates: different functions with the same asymptotic growth rate may be represented using the same O notation. The letter O is used because the growth rate of a function is also referred to as the **order of the function**. A description of a function in terms of big O notation only provides an <u>upper bound</u> on the growth rate of the function.

Associated with big O notation are several related notations, using the symbols o ,  $\Omega$ 

,

[Image]  $\omega$ 

, and  $\Theta$ 

to describe other kinds of bounds on asymptotic growth rates.

Let

[Image]

the function to be estimated, be a  $\underline{\text{real}}$  or  $\underline{\text{complex}}$  valued function, and let g,

the comparison function, be a real valued function. Let both functions be defined on some unbounded subset of the positive real numbers, and

[Image]

g(x)

be non-zero (often, but not necessarily, strictly positive) for all large enough values of

x.

One writes

![](_page_2_Figure_0.jpeg)

such that

$$|f(x)| \le M |g(x)|$$
 for all  $x \ge x_0$ .

In many contexts, the assumption that we are interested in the growth rate as the variable

- 2

goes to infinity or to zero is left unstated, and one writes more simply that

$$f(x) = O(g(x)).$$

The notation can also be used to describe the behavior of

[Image]

near some real number

[Image]

a

(often,

a = 0

): we say

$$f(x) = O(g(x))$$
 as  $x \to a$ 

if there exist positive numbers

[Image]

δ

and

[Image]

M

such that for an uchinou

x

with

 $\begin{aligned} 0 &< |x-a| < \delta, \\ |f(x)| &\le M|g(x)|. \end{aligned}$ 

As

[Image]

g(x)

is non-zero for adequately large (or small) values of

both of these definitions can be unified using the limit superior:

$$f(x) = O(g(x))$$
 as  $x \to a$ 

if

(whether

$$\limsup_{x\to a}\frac{|f(x)|}{|g(x)|}<\infty.$$

And in both of these definitions the limit point

[Image]

-----

.....

a

[Image]

or not) is a cluster point of the domains of

[Image]

f

and

![](_page_5_Figure_1.jpeg)

there have to be infinitely many points in common. Moreover, as pointed out in the article about the limit inferior and limit superior, the

 $\limsup_{x\to a}$ 

(at least on the extended real number line) always exists.

In computer science, a slightly more restrictive definition is common:

![](_page_5_Picture_6.jpeg)

and

[Image]

are both required to be functions from some unbounded subset of the positive integers to the nonnegative real numbers; then

$$f(x) = O(g(x))$$

if there exist positive integer numbers

![](_page_5_Picture_13.jpeg)

and

 $n_0$ 

such that

|f(n)| < M|g(n)|

 $n \geq n_0$ .

In typical usage the

notation is asymptotical, that is, it refers to very large

. In this setting, the contribution of the terms that grow "most quickly" will eventually make the other ones irrelevant. As a result, the following simplification rules can be applied:

For example, let

$$f(x) = 6x^4 - 2x^3 + 5$$

, and suppose we wish to simplify this function, using

notation, to describe its growth rate as

$$x \to \infty$$

. This function is the sum of three terms:

 $6x^4$ 

 $-2x^3$ 

, and

5

. Of these three terms, the one with the highest growth rate is the one with the largest exponent as a function of

x

, namely

 $6x^4$ 

. Now one may apply the second rule:

 $6x^4$ 

is a product of

6

and

 $x^4$ 

in which the first factor does not depend on

. Omitting this factor results in the simplified form

. Thus, we say that

f(x)

is a "big O" of

 $x^4$ 

. Mathematically, we can write

$$f(x) = O(x^4)$$

. One may confirm this calculation using the formal definition: let

$$f(x) = 6x^4 - 2x^3 + 5$$

and

$$g(x) = x^4$$

. Applying the from above, the statement that

$$f(x) = O(x^4)$$

is equivalent to its expansion,

$$|f(x)| \le Mx^4$$

for some suitable choice of a real number

and a positive real number

[Image]

M

and for all

 $x > x_0$ 

. To prove this, let

 $x_0 = 1$ 

and

M = 13

. Then, for all

 $x > x_0$ 

:

$$|6x^4 - 2x^3 + 5| \le 6x^4 + |-2x^3| + 5$$
  
 $\le 6x^4 + 2x^4 + 5x^4$   
 $= 13x^4$ 

S0

$$|6x^4-2x^3+5| \leq 13x^4.$$

Big O notation has two main areas of application:

- In <u>mathematics</u>, it is commonly used to describe, especially in the case of a truncated Taylor series or asymptotic expansion.
- In computer science, it is useful in the .

In both applications, the function

[Image]

g(x)

appearing within the

 $O(\cdot)$ 

is typically chosen to be as simple as possible, omitting constant factors and lower order terms.

There are two formally close, but noticeably different, usages of this notation: [citation needed]

- \* infinite asymptotics
- infinitesimal asymptotics.

This distinction is only in application and not in principle, however—the formal definition for the "big O" is the same for both cases, only with different limits for the function argument.[original research?]

## Infinite asymptotics

[edit]

![](_page_8_Figure_0.jpeg)

Graphs of functions commonly used in the analysis of algorithms, showing the number of operations

![](_page_8_Picture_2.jpeg)

versus input size

for each function

Big O notation is useful when <u>analyzing algorithms</u> for efficiency. For example, the time (or the number of steps) it takes to complete a problem of size

might be found to be

$$T(n) = 4n^2 - 2n + 2$$

. As

n

grows large, the

 $n^2$ 

 $\overline{ ext{term}}$  will come to dominate, so that all other terms can be neglected—for instance when n=500

, the term

 $4n^2$ 

is 1000 times as large as the

[Image]

2n

term. Ignoring the latter would have negligible effect on the expression's value for most purposes. Further, the <u>coefficients</u> become irrelevant if we compare to any other <u>order</u> of expression, such as an expression containing a term

 $n^3$ 

or

 $n^4$ 

. Even if

 $T(n) = 1000000n^2$ 

, if

$$U(n) = n^3$$

, the latter will always exceed the former once n grows larger than

1000000

, viz.

$$T(1000000) = 1000000^3 = U(1000000)$$

. Additionally, the number of steps depends on the details of the machine model on which the algorithm runs, but different types of machines typically vary by only a constant factor in the number of steps needed to execute an algorithm. So the big O notation captures what remains: we write either

$$T(n) = O(n^2)$$

or

$$T(n) \in O(n^2)$$

and say that the algorithm has order of  $n^2$  time complexity. The sign "=" is not meant to express "is equal to" in its normal mathematical sense, but rather a more colloquial "is", so the second expression is sometimes considered more accurate (see the "" discussion below) while the first is considered by some as an <u>abuse of notation</u>.

## Infinitesimal asymptotics

[edit]

Big O can also be used to describe the <u>error term</u> in an approximation to a mathematical function. The most significant terms are written explicitly, and then the least-significant terms are summarized in a single big O term. Consider, for example, the <u>exponential</u> series and two expressions of it that are valid when x is small:

$$e^x=1+x+rac{x^2}{2!}+rac{x^3}{3!}+rac{x^4}{4!}+\cdots$$
 for all finite  $x^2=1+x+rac{x^2}{2}+O(x^3)$  as  $x o 0$  as  $x o 0$ 

The middle expression (the line with "

$$O(x^3)$$

") means the absolute-value of the error

$$e^x - (1 + x + \frac{x^2}{2})$$

is at most some constant times

$$|x^3|$$

when

If the function f can be written as a finite sum of other functions, then the fastest growing one determines the order of f(n). For example,

$$f(n) = 9 \log n + 5(\log n)^4 + 3n^2 + 2n^3 = O(n^3)$$
 as  $n \to \infty$ .

In particular, if a function may be bounded by a polynomial in n, then as n tends to infinity, one may disregard lower-order terms of the polynomial. The sets  $O(n^c)$  and  $O(c^n)$  are very different. If c is greater than one, then the latter grows much faster. A function that grows faster than  $n^c$  for any c is called superpolynomial. One that grows more slowly than any exponential function of the form  $c^n$  is called subexponential. An algorithm can require time that is both superpolynomial and subexponential; examples of this include the fastest known algorithms for integer factorization and the function  $n^{\log n}$ .

We may ignore any powers of n inside of the logarithms. The set  $O(\log n)$  is exactly the same as  $O(\log(n^c))$ . The logarithms differ only by a constant factor (since  $\log(n^c) = c \log n$ ) and thus the big O notation ignores that. Similarly, logs with different constant bases are equivalent. On the other hand, exponentials with different bases are not of the same order. For example,  $2^n$  and  $3^n$  are not of the same order.

Changing units may or may not affect the order of the resulting algorithm. Changing units is equivalent to multiplying the appropriate variable by a constant wherever it appears. For example, if an algorithm runs in the order of  $n^2$ , replacing n by cn means the algorithm runs in the order of  $c^2n^2$ , and the big O notation ignores the constant  $c^2$ . This can be written as  $c^2n^2 = O(n^2)$ . If, however, an algorithm runs in the order of  $2^n$ , replacing n with cn gives  $2^{cn} = (2^c)^n$ . This is not equivalent to  $2^n$  in general. Changing variables may also affect the order of the resulting algorithm. For example, if an algorithm's run time is O(n) when measured in terms of the number n of digits of an input number x, then its run time is  $O(\log x)$  when measured as a function of the input number x itself, because  $n = O(\log x)$ .

$$f_1=O(g_1) ext{ and } f_2=O(g_2)\Rightarrow f_1f_2=O(g_1g_2)$$
  $f\cdot O(g)=O(fg)$  If 
$$f_1=O(g_1) ext{ and } f_2=O(g_2) ext{ then } f_1+f_2=O(\max(|g_1|,|g_2|))$$
 . It follows that if 
$$f_1=O(g) ext{ and } f_2=O(g) ext{ then } f_1+f_2\in O(g)$$

#### Multiplication by a constant

#### [edit]

Let k be a nonzero constant. Then

 $O(|k| \cdot g) = O(g)$ . In other words, if f = O(g), then  $k \cdot f = O(g)$ . Big O (and little o,  $\Omega$ , etc.) can also be used with multiple variables. To define big Oformally for multiple variables, suppose [Image] f and [Image] gare two functions defined on some subset of [Image]  $\mathbb{R}^n$ . We say  $f(\mathbf{x})$  is  $O(g(\mathbf{x}))$ as  $\mathbf{x} \to \infty$ if and only if there exist constants [Image]

M

and

such that

 $|f(\mathbf{x})| \le C|g(\mathbf{x})|$ 

for all

х

with

 $x_i \ge M$ 

for some

i.

Equivalently, the condition that

 $x_i \ge M$ 

for some

i

can be written

 $\|\mathbf{x}\|_{\infty} \geq M$ 

, where

 $\|\mathbf{x}\|_{\infty}$ 

denotes the Chebyshev norm. For example, the statement

$$f(n,m) = n^2 + m^3 + O(n+m)$$
 as  $n, m \to \infty$ 

asserts that there exist constants C and M such that

$$|f(n,m)-(n^2+m^3)|\leq C|n+m|$$

whenever either

m > M

or

$$n \ge M$$

holds. This definition allows all of the coordinates of

x

to increase to infinity. In particular, the statement

$$f(n,m) = O(n^m)$$
 as  $n, m \to \infty$ 

(i.e.,

 $\exists C \exists M \, \forall n \, \forall m \, \cdots$ 

) is quite different from

$$\forall m: f(n,m) = O(n^m) \quad \text{as } n \to \infty$$

(i.e.,

 $\forall m \exists C \exists M \forall n \cdots$ 

).

Under this definition, the subset on which a function is defined is significant when generalizing statements from the univariate setting to the multivariate setting. For example, if

f(n, m) = 1

and

g(n, m) = n

, then

f(n,m) = O(g(n,m))

if we restrict

[Image]

![](_page_13_Figure_0.jpeg)

This is not the only generalization of big O to multivariate functions, and in practice, there is some inconsistency in the choice of definition.

## Matters of notation

## [edit]

The statement "f(x) is O[g(x)]" as defined above is usually written as f(x) = O[g(x)]. Some consider this to be an <u>abuse of notation</u>, since the use of the equals sign could be misleading as it suggests a symmetry that this statement does not have. As <u>de Bruijn</u> says,  $O[x] = O[x^2]$  is true but  $O[x^2] = O[x]$  is not. <u>Knuth</u> describes such statements as "one-way equalities", since if the sides could be reversed, "we could deduce ridiculous things like  $n = n^2$  from the identities  $n = O[n^2]$  and  $n^2 = O[n^2]$ ". In another letter, Knuth also pointed out that

the equality sign is not symmetric with respect to such notations [as, in this notation,] mathematicians customarily use the '=' sign as they use the word 'is' in English: Aristotle is a man, but a man isn't necessarily Aristotle.

For these reasons, it would be more precise to use <u>set notation</u> and write  $f(x) \in O[g(x)]$  – read as: "f(x) is an element of O[g(x)]", or "f(x) is in the set O[g(x)]" – thinking of O[g(x)] as the class of all functions h(x) such that  $|h(x)| \le C|g(x)|$  for some positive real number C. However, the use of the equals sign is customary.

## Other arithmetic operators

#### [edit]

Big O notation can also be used in conjunction with other arithmetic operators in more complicated equations. For example, h(x) + O(f(x)) denotes the collection of functions having the growth of h(x) plus a part whose growth is limited to that of f(x). Thus,

$$g(x) = h(x) + O(f(x))$$

expresses the same as

$$g(x) - h(x) = O(f(x)).$$

Suppose an algorithm is being developed to operate on a set of n elements. Its developers

are interested in finding a function I(n) that will express now long the algorithm will take to run (in some arbitrary measurement of time) in terms of the number of elements in the input set. The algorithm works by first calling a subroutine to sort the elements in the set and then perform its own operations. The sort has a known time complexity of  $O(n^2)$ , and after the subroutine runs the algorithm must take an additional  $55n^3 + 2n + 10$  steps before it terminates. Thus the overall time complexity of the algorithm can be expressed as  $I(n) = 55n^3 + O(n^2)$ . Here the terms 2n + 10 are subsumed within the faster-growing  $O(n^2)$ . Again, this usage disregards some of the formal meaning of the "=" symbol, but it does allow one to use the big O notation as a kind of convenient placeholder.

In more complicated usage,  $O(\cdot)$  can appear in different places in an equation, even several times on each side. For example, the following are true for

$$n \to \infty$$

:

$$(n+1)^2 = n^2 + O(n), \ (n+O(n^{1/2})) \cdot (n+O(\log n))^2 = n^3 + O(n^{5/2}), \ n^{O(1)} = O(e^n).$$

The meaning of such statements is as follows: for any functions which satisfy each  $O(\cdot)$  on the left side, there are some functions satisfying each  $O(\cdot)$  on the right side, such that substituting all these functions into the equation makes the two sides equal. For example, the third equation above means: "For any function f(n) = O(1), there is some function  $g(n) = O(e^n)$  such that  $n^{f(n)} = g(n)$ ". In terms of the "set notation" above, the meaning is that the class of functions represented by the left side is a subset of the class of functions represented by the right side. In this use the "=" is a formal symbol that unlike the usual use of "=" is not a symmetric relation. Thus for example  $n^{O(1)} = O(e^n)$  does not imply the false statement  $O(e^n) = n^{O(1)}$ .

Big O is typeset as an italicized uppercase "O", as in the following example:

$$O(n^2)$$

. In <u>TeX</u>, it is produced by simply typing 'O' inside math mode. Unlike Greek-named Bachmann-Landau notations, it needs no special symbol. However, some authors use the calligraphic variant

![](_page_14_Picture_9.jpeg)

instead.

## Orders of common functions

#### edit

Here is a list of classes of functions that are commonly encountered when analyzing the running time of an algorithm. In each case, c is a positive constant and n increases without bound. The slower-growing functions are generally listed first.

| Notation Nam | e Example |
|--------------|-----------|
|--------------|-----------|

| (Image)  O(1)              | constant                                       | Finding the median value for a sorted array of numbers; Calculating $(-1)^n$ ; Using a constant-size $\underline{\text{lookup table}}$                                                         |
|----------------------------|------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| $O(\alpha(n))$             | inverse<br>Ackermann<br>function               | Amortized complexity per operation for the<br><u>Disjoint-set data structure</u>                                                                                                               |
| $O(\log \log n)$           | double<br>logarithmic                          | Average number of comparisons spent finding an item using <u>interpolation search</u> in a sorted array of uniformly distributed values                                                        |
| $O(\log n)$                | logarithmic                                    | Finding an item in a sorted array with a<br>binary search or a balanced search tree as<br>well as all operations in a binomial heap                                                            |
| $O((\log n)^c)$ $c>1$      | polylogarithmic                                | Matrix chain ordering can be solved in polylogarithmic time on a parallel random-access machine.                                                                                               |
| $O(n^c)$ $0 < c < 1$       | fractional<br>power                            | Searching in a <u>k-d tree</u>                                                                                                                                                                 |
| [Image] $O(n)$             | linear                                         | Finding an item in an unsorted list or in an unsorted array; adding two <i>n</i> -bit integers by ripple carry                                                                                 |
| - (117)                    |                                                | Denfamilia del mandation del 100                                                                                                                                                               |
| $O(n \log^* n)$            | n <u>log-star</u> n                            | Performing <u>triangulation</u> of a simple polygon using Seidel's algorithm, where $\log^*(n) = \begin{cases} 0, & \text{if } n \leq 1 \\ 1 + \log^*(\log n), & \text{if } n > 1 \end{cases}$ |
| $O(n \log n) = O(\log n!)$ | linearithmic,<br>loglinear,<br>quasilinear, or | Performing a <u>fast Fourier transform</u> ; fastest possible <u>comparison sort</u> ; <u>heapsort</u> and                                                                                     |

|                                                                   | " $n \log n$ "                       | merge sort                                                                                                                                                                                                                                                |
|-------------------------------------------------------------------|--------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| $O(n^2)$                                                          | quadratic                            | Multiplying two n-digit numbers by schoolbook multiplication; simple sorting algorithms, such as bubble sort, selection sort and insertion sort; (worst-case) bound on some usually faster sorting algorithms such as quicksort, Shellsort, and tree sort |
| $O(n^c)$                                                          | polynomial or<br>algebraic           | Tree-adjoining grammar parsing; maximum matching for bipartite graphs; finding the determinant with LU decomposition                                                                                                                                      |
| $L_n[lpha,c] = e^{(c+o(1))(\ln n)^lpha (\ln \ln n)^{1-lpha}}$ $0$ | L-notation or<br>sub-<br>exponential | Factoring a number using the <u>quadratic</u><br>sieve or <u>number field sieve</u>                                                                                                                                                                       |
| $O(c^n)$ $c>1$                                                    | exponential                          | Finding the (exact) solution to the <u>travelling</u> <u>salesman problem</u> using <u>dynamic</u> <u>programming</u> ; determining if two logical statements are equivalent using <u>brute-force</u> <u>search</u>                                       |
| [Image]                                                           | <u>factorial</u>                     | Solving the <u>travelling salesman problem</u> via brute-force search; generating all unrestricted permutations of a <u>poset</u> ; finding the <u>determinant</u> with <u>Laplace</u> <u>expansion</u> ; enumerating <u>all partitions of a set</u>      |
| O(n!)                                                             |                                      |                                                                                                                                                                                                                                                           |

The statement

$$f(n) = O(n!)$$

is sometimes weakened to

$$f(n) = O(n^n)$$

to derive simpler formulas for asymptotic complexity. For any

k > 0

and

c > 0

 $O(n^c(\log n)^k)$ 

is a subset of

 $O(n^{c+\varepsilon})$ 

for any

 $\varepsilon > 0$ 

, so may be considered as a polynomial with some bigger order.

Big O is widely used in computer science. Together with some other related notations, it forms the family of Bachmann-Landau notations. [citation needed]

"Little o" redirects here. For the baseball player, see  $\underline{\text{Omar Vizquel}}$ . For the Greek letter, see  $\underline{\text{Omicron}}$ .

Intuitively, the assertion "f(x) is o(g(x))" (read "f(x) is little-o of g(x)" or "f(x) is of

inferior order to g(x)") means that g(x) grows much faster than f(x), or equivalently f(x) grows much slower than g(x). As before, let f be a real or complex valued function and g a real valued function, both defined on some unbounded subset of the positive <u>real</u> numbers, such that

[Image]

g(x)

is strictly positive for all large enough values of x. One writes

$$f(x) = o(g(x))$$
 as  $x \to \infty$ 

if for every positive constant  $\epsilon$  there exists a constant

 $x_0$ 

such that

$$|f(x)| \le \varepsilon g(x)$$
 for all  $x \ge x_0$ .

For example, one has

and  $2x = o(x^2)$  and 1/x = o(1), both as  $x o \infty.$ 

The difference between the and the definition of little-o is that while the former has to be true for at least one constant M, the latter must hold for every positive constant  $\varepsilon$ , however small. In this way, little-o notation makes a stronger statement than the corresponding big-O notation: every function that is little-o of g is also big-O of g, but not every function that is big-O of g is little-o of g. For example,

 $2x^2 = O(x^2)$ 

but

 $2x^2 \neq o(x^2)$ 

If

[Image]

g(x)

is nonzero, or at least becomes nonzero beyond a certain point, the relation

$$f(x) = o(g(x))$$

is equivalent to

f(x)

$$\lim_{x \to \infty} \frac{1}{g(x)} = 0$$

(and this is in fact how Landau originally defined the little-o notation).

Little-o respects a number of arithmetic operations. For example,

if c is a nonzero constant and

f = o(g)

then

 $c \cdot f = o(g)$ 

, and

if

f = o(F)

and

g = o(G)

then

 $f \cdot g = o(F \cdot G).$ 

if

f = o(F)

and

g = o(G)

then

$$f + g = o(F + G)$$

It also satisfies a transitivity relation:

if

f = o(g)

and

g = o(h)

then

f = o(h).

Little-o can also be generalized to the finite case:

f(x) = o(g(x)) as  $x \to x_0$ 

if

 $f(x) = \alpha(x)g(x)$ 

for some

[Image]

 $\alpha(x)$ 

with

 $\lim_{x\to x_0}\alpha(x)=0$ 

- .

Or, if

[Image]

g(x)

is nonzero in a neighbourhood around

 $x_0$ 

:

f(x) = o(g(x)) as  $x \to x_0$ 

if

$$\lim_{x \to x_0} \frac{f(x)}{g(x)} = 0$$

This definition is especially useful in the computation of <u>limits</u> using <u>Taylor series</u>. For example:

$$\sin x = x - \frac{x^3}{3!} + \ldots = x + o(x^2) \text{ as } x \to 0$$

, so

$$\lim_{x \to 0} \frac{\sin x}{x} = \lim_{x \to 0} \frac{x + o(x^2)}{x} = \lim_{x \to 0} 1 + o(x) = 1$$

Another asymptotic notation is

 $\Omega$ 

, read "big omega". There are two widespread and incompatible definitions of the statement

 $f(x) = \Omega(g(x))$ 

as

$$x \rightarrow a$$
,

where a is some real number,

[Image]

, or

 $-\infty$ 

, where f and g are real functions defined in a neighbourhood of a, and where g is positive in this neighbourhood.

The Hardy-Littlewood definition is used mainly in <u>analytic number theory</u>, and the Knuth definition mainly in <u>computational complexity theory</u>; the definitions are not equivalent.

#### The Hardy-Littlewood definition

[edit]

In 1914 G.H. Hardy and J.E. Littlewood introduced the new symbol

 $\Omega$ ,

which is defined as follows:

 $f(x) = \Omega(g(x))$ 

 $x o \infty$ 

if

$$\limsup_{x\to\infty} \ \left|\frac{f(x)}{g(x)}\right|>0 \ .$$

Thus

$$f(x) = \Omega(g(x))$$

is the negation of

$$f(x) = o(g(x))$$
.

In 1916 the same authors introduced the two new symbols

 $\Omega_R$ 

and

 $\Omega_L$ ,

defined as:

$$f(x) = \Omega_R(g(x))$$

as

 $x \to \infty$ 

if

$$\limsup_{x\to\infty}\ \frac{f(x)}{g(x)}>0\ ;$$

$$f(x) = \Omega_L(g(x))$$

as

 $x \to \infty$ 

if

$$\liminf_{x\to\infty}\,\frac{f(x)}{g(x)}<0\;.$$

These symbols were used by <u>E. Landau</u>, with the same meanings, in 1924. Authors that followed Landau, however, use a different notation for the same definitions: [citation needed] The symbol

 $\Omega_R$ 

has been replaced by the current notation

 $\Omega_{+}$ 

with the same definition, and

 $\Omega_L$ 

became

 $\Omega$ .

These three symbols

$$\Omega$$
 ,  $\Omega_+$  ,  $\Omega_-$  ,

as well as

$$f(x) = \Omega_{\pm}(g(x))$$

(meaning that

$$f(x) = \Omega_+ (g(x))$$

and

$$f(x) = \Omega_{-}(g(x))$$

are both satisfied), are now currently used in analytic number theory.

We have

 $\sin x = \Omega(1)$  as  $x o \infty$  ,

and more precisely

 $\sin x = \Omega_{\pm}(1)$ 

as

 $x \to \infty$ .

We have

 $1 + \sin x = \Omega(1)$ 

as

 $x \to \infty$ ,

and more precisely

 $1+\sin x=\Omega_+(1)$ 

as

 $x \to \infty$ ;

however

 $1 + \sin x \neq \Omega_{-}(1)$ 

as

 $x \to \infty$ .

#### The Knuth definition

## [edit]

In 1976 <u>Donald Knuth</u> published a paper to justify his use of the

 $\Omega$ 

-symbol to describe a stronger property. Knuth wrote: "For all the applications I have seen so far in computer science, a stronger requirement ... is much more appropriate". He defined

$$f(x) = \Omega(g(x)) \iff g(x) = O(f(x))$$

with the comment: "Although I have changed Hardy and Littlewood's definition of

, I feel justified in doing so because their definition is by no means in wide use, and because there are other ways to say what they want to say in the comparatively rare cases when their definition applies."

## Family of Bachmann-Landau notations

#### [edit]

| Notation     | Name                                            | Description                                                     | Formal definition                                        | Limit definition                     |
|--------------|-------------------------------------------------|-----------------------------------------------------------------|----------------------------------------------------------|--------------------------------------|
| f(n)=o(g(n)) | Small O;<br>Small Oh;<br>Little O;<br>Little Oh | f is dominated by g asymptotically (for any constant factor $k$ | $orall k>0\exists n_0orall n>n_0\!:\! f(n) \leq kg(n)$ | $\lim_{n	o\infty}rac{f(n)}{g(n)}=0$ |
|              | Big O; Big                                      | f  is asymptotically bounded                                    |                                                          | f(n)                                 |

| f(n) = O(g(n))                                | Oh; Big<br>Omicron                                         | factor k                                                                                                  | $\exists k>0\ \exists n_0\ orall n>n_0$ : $ f(n) \leq kg(n)$                                                   | $\limsup_{n \to \infty} \frac{1}{g(n)} < \infty$ |  |
|-----------------------------------------------|------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|--------------------------------------------------|--|
| f(n)symp g(n)                                 | f(n) symp g(n) Of the                                      | f is asymptotically bounded by g both above (with constant factor $k_2$ ) and below (with constant factor |                                                                                                                 | f(n) = O(g(n))<br>and<br>g(n) = O(f(n))          |  |
| (Hardy's same order<br>notation) or as (Hardy | same order<br>as (Hardy);<br>Big Theta<br>(Knuth)          | [Image]                                                                                                   | $\exists k_1>0\exists k_2>0\exists n_0orall n>n_0\colon \ k_1g(n)\leq f(n)\leq k_2g(n)$                        |                                                  |  |
|                                               |                                                            | k <sub>1</sub>                                                                                            |                                                                                                                 |                                                  |  |
| $f(n) \sim g(n)$                              | Asymptotic equivalence                                     | f is equal to g <u>asymptotically</u>                                                                     | $\left  orall arepsilon > 0  \exists n_0  orall n > n_0  vert \left  rac{f(n)}{g(n)} - 1  ight  < arepsilon$ | $\lim_{n\to\infty}\frac{f(n)}{g(n)}=1$           |  |
| $f(n) = \Omega(g(n))$                         | Big Omega<br>in<br>complexity<br>theory<br>(Knuth)         | f is bounded below by g<br>asymptotically                                                                 | $\exists k>0 \exists n_0\ orall n>n_0$ : $f(n)\geq k g(n)$                                                     | $\liminf_{n	o\infty}rac{f(n)}{g(n)}>0$          |  |
| $f(n) = \omega(g(n))$                         | Small<br>Omega;<br>Little<br>Omega                         | f dominates g<br>asymptotically                                                                           | $orall k > 0  \exists n_0  orall n > n_0 \colon \! f(n) > k  g(n)$                                            | $\lim_{n	o\infty}rac{f(n)}{g(n)}=\infty$        |  |
| $f(n) = \Omega(g(n))$                         | Big Omega<br>in number<br>theory<br>(Hardy–<br>Littlewood) | f  is not dominated by g asymptotically                                                                   | $\exists k>0  orall n_0  \exists n>n_0 \colon \lvert f(n) vert \geq k  g(n)$                                   | $\limsup_{n	o\infty}rac{ f(n) }{g(n)}>0$        |  |

The limit definitions assume

for sufficiently large

n

. The table is (partly) sorted from smallest to largest, in the sense that

$$o, O, \Theta, \sim,$$

(Knuth's version of)

 $\Omega, \omega$ 

on functions correspond to

$$<, \leq, \approx, =, \\ \geq, >$$

on the real line (the Hardy–Littlewood version of

Ω

, however, doesn't correspond to any such description).

| Computer science uses the big    | 0                                |
|----------------------------------|----------------------------------|
| , big Theta                      |                                  |
| , little                         | Θ                                |
| , little omega                   | o                                |
|                                  | [Image]                          |
| and Knuth's big Omega            | $\omega$                         |
| notations. Analytic number the   | $\Omega$ eory often uses the big |
| , small                          | 0                                |
| , Hardy's                        | 0                                |
| , Hardy–Littlewood's big Ome     | ga                               |
| (with or without the +, - or ± : | Ω                                |
|                                  | [Image]                          |
| notations. The small omega       | ~                                |
|                                  | [Image]                          |
|                                  | $\omega$                         |

## Use in computer science

notation is not used as often in analysis.

## [edit]

Informally, especially in computer science, the big O notation often can be used somewhat differently to describe an asymptotic <u>tight</u> bound where using big Theta  $\Theta$  notation might be more factually appropriate in a given context. For example, when considering a function  $T(n) = 73n^3 + 22n^2 + 58$ , all of the following are generally

acceptable but tighter hounds (such as numbers a and a below) are usually strong

acceptable, but tighter bounds (such as numbers 2 and 3 below) are usually strongly preferred over looser bounds (such as number 1 below).

1. 
$$T(n) = O(n^{100})$$

<sup>2</sup>· 
$$T(n) = O(n^3)$$

3. 
$$T(n) = \Theta(n^3)$$

The equivalent English statements are respectively:

- <sup>1.</sup> T(n) grows asymptotically no faster than  $n^{100}$
- T(n) grows asymptotically no faster than n<sup>3</sup>
- T(n) grows asymptotically as fast as n<sup>3</sup>.

So while all three statements are true, progressively more information is contained in each. In some fields, however, the big O notation (number 2 in the lists above) would be used more commonly than the big Theta notation (items numbered 3 in the lists above). For example, if T(n) represents the running time of a newly developed algorithm for input size n, the inventors and users of the algorithm might be more inclined to put an upper asymptotic bound on how long it will take to run without making an explicit statement about the lower asymptotic bound.

In their book <u>Introduction to Algorithms</u>, <u>Cormen</u>, <u>Leiserson</u>, <u>Rivest</u> and <u>Stein</u> consider the set of functions f which satisfy

$$f(n) = O(g(n)) \quad (n \to \infty)$$
.

In a correct notation this set can, for instance, be called O(g), where

$$O(g) = \{f : \text{there exist positive constants } c \text{ and } n_0 \text{ such that } 0 \le f(n) \le cg(n) \text{ for all } n \ge n_0 \}.$$

The authors state that the use of equality operator (=) to denote set membership rather than the set membership operator ( $\in$ ) is an abuse of notation, but that doing so has advantages. Inside an equation or inequality, the use of asymptotic notation stands for an <u>anonymous function</u> in the set O(g), which eliminates lower-order terms, and helps to reduce inessential clutter in equations, for example:

$$2n^2 + 3n + 1 = 2n^2 + O(n).$$

#### Extensions to the Bachmann-Landau notations

[edit]

Another notation sometimes used in computer science is  $\underline{O}$  (read soft-O), which hides polylogarithmic factors. There are two definitions in use: some authors use  $f(n) = \overline{O}(g(n))$  as  $\underline{shorthand}$  for  $f(n) = O(g(n) \underline{\log^k n})$  for some k, while others use it as shorthand for  $f(n) = O(g(n) \log^k g(n))$ . When g(n) is polynomial in n, there is no difference; however, the latter definition allows one to say, e.g. that

$$n2^n = \tilde{O}(2^n)$$

while the former definition allows for

$$\log^k n = \tilde{O}(1)$$

for any constant k. Some authors write  $O^*$  for the same purpose as the latter definition. Essentially, it is big O notation, ignoring <u>logarithmic factors</u> because the <u>growth-rate</u> effects of some other super-logarithmic function indicate a growth-rate explosion for large-sized input parameters that is more important to predicting bad run-time performance than the finer-point effects contributed by the logarithmic-growth factor(s). This notation is often used to obviate the "nitpicking" within growth-rates that are stated

as too tightly bounded for the matters at hand (since  $\log^k n$  is always  $o(n^{\varepsilon})$  for any constant k and any  $\varepsilon > 0$ ).

Also, the L notation, defined as

$$L_n[\alpha, c] = e^{(c+o(1))(\ln n)^{\alpha}(\ln \ln n)^{1-\alpha}}$$

is convenient for functions that are between <u>polynomial</u> and <u>exponential</u> in terms of  $\ln n$ 

.

The generalization to functions taking values in any <u>normed vector space</u> is straightforward (replacing absolute values by norms), where f and g need not take their values in the same space. A generalization to functions g taking values in any <u>topological group</u> is also possible [citation needed]. The "limiting process"  $x \to x_0$  can also be generalized by introducing an arbitrary <u>filter base</u>, i.e. to directed <u>nets</u> f and g. The g notation can be used to define <u>derivatives</u> and <u>differentiability</u> in quite general spaces, and also (asymptotical) equivalence of functions,

$$f \sim g \iff (f - g) \in o(g)$$

which is an equivalence relation and a more restrictive notion than the relationship "f is  $\Theta(g)$ " from above. (It reduces to  $\lim f/g = 1$  if f and g are positive real valued functions.) For example, 2x is  $\Theta(x)$ , but 2x - x is not o(x).

## History (Bachmann-Landau, Hardy, and Vinogradov notations)

[edit]

The symbol O was first introduced by number theorist <a href="Paul Bachmann">Paul Bachmann</a> in 1894, in the second volume of his book <a href="Analytische Zahlentheorie">Analytische Zahlentheorie</a> ("analytic number theory"). The number theorist <a href="Edmund Landau">Edmund Landau</a> adopted it, and was thus inspired to introduce in 1909 the notation o; hence both are now called Landau symbols. These notations were used in applied mathematics during the 1950s for asymptotic analysis. The symbol

Ω

(in the sense "is not an o of") was introduced in 1914 by Hardy and Littlewood. Hardy and Littlewood also introduced in 1916 the symbols

 $\Omega_R$ 

("right") and

 $\Omega_L$ 

("left"), precursors of the modern symbols

 $\Omega_{+}$ 

("is not smaller than a small o of") and

 $\Omega_{-}$ 

("is not larger than a small o of"). Thus the Omega symbols (with their original meanings) are sometimes also referred to as "Landau symbols". This notation

Ω

became commonly used in number theory at least since the 1950s.

The symbol

[Image]

, although it had been used before with different meanings, was given its modern definition by Landau in 1909 and by Hardy in 1910. Just above on the same page of his tract Hardy defined the symbol

, where

$$f(x) \approx g(x)$$

 $\asymp$ 

means that both

$$f(x) = O(g(x))$$

and

$$g(x) = O(f(x))$$

are satisfied. The notation is still currently used in analytic number theory. In his tract Hardy also proposed the symbol

, where

$$f \times g$$

means that

$$f \sim Kg$$

for some constant

$$K \neq 0$$

In the 1970s the big O was popularized in computer science by Donald Knuth, who proposed the different notation

$$f(x) = \Theta(g(x))$$

for Hardy's

$$f(x) \simeq g(x)$$

, and proposed a different definition for the Hardy and Littlewood Omega notation.

Two other symbols coined by Hardy were (in terms of the modern O notation)

$$f \preccurlyeq g \iff f = O(g)$$

and

$$f \prec g \iff f = o(g);$$

(Hardy however never defined or used the notation

, nor

[Image]

, as it has been sometimes reported). Hardy introduced the symbols

and

(as well as the already mentioned other symbols) in his 1910 tract "Orders of Infinity", and made use of them only in three papers (1910-1913). In his nearly 400 remaining papers and books he consistently used the Landau symbols O and o.

![](_page_27_Figure_0.jpeg)

) are not used anymore. On the other hand, in the 1930s, the Russian number theorist Ivan Matveyevich Vinogradov introduced his notation

![](_page_27_Picture_2.jpeg)

, which has been increasingly used in number theory instead of the

notation. We have

$$f \ll g \iff f = O(g),$$

and frequently both notations are used in the same paper.

The big-O originally stands for "order of" ("Ordnung", Bachmann 1894), and is thus a Latin letter. Neither Bachmann nor Landau ever call it "Omicron". The symbol was much later on (1976) viewed by Knuth as a capital <u>omicron</u>, probably in reference to his definition of the symbol Omega. The digit zero should not be used.

- \* Asymptotic computational complexity
- Asymptotic expansion: Approximation of functions generalizing Taylor's formula
- Asymptotically optimal algorithm: A phrase frequently used to describe an algorithm that has an upper bound asymptotically within a constant of a lower bound for the problem
- Big O in probability notation: Op, op
- <u>Limit inferior and limit superior</u>: An explanation of some of the limit notation used in this article
- Master theorem (analysis of algorithms): For analyzing divide-and-conquer recursive algorithms using big O notation
- Nachbin's theorem: A precise method of bounding complex analytic functions so that the domain of convergence of integral transforms can be stated
- \* Order of approximation
- Order of accuracy
- Computational complexity of mathematical operations

## References and notes

[edit]

- <u>\*\*Bachmann, Paul</u> (1894). Analytische Zahlentheorie [Analytic Number Theory] (in German). Vol. 2. Leipzig: Teubner.
- 2. ^ <u>Landau, Edmund</u> (1909). Handbuch der Lehre von der Verteilung der Primzahlen [Handbook on the theory of the distribution of the primes] (in German). Vol. 1. Leipzig: B. G. Teubner. p. 61. Also see page 883 in vol. 2 of the

- book (not available from the link given).
- 3. ^ Cormen, Thomas H.; Leiserson, Charles E.; Rivest, Ronald L. (1990). "Growth of Functions". Introduction to Algorithms (1st ed.). MIT Press and McGraw-Hill. pp. 23-41. ISBN 978-0-262-53091-0.
- 4. <u>Landau, Edmund</u> (1909). Handbuch der Lehre von der Verteilung der Primzahlen [Handbook on the theory of the distribution of the primes] (in German). Leipzig: B.G. Teubner. p. 31.
- 5. Sipser, Michael (1997). Introduction to the Theory of Computation. Boston, MA: PWS Publishing. p. 227, def. 7.2.
- 6. ^ Cormen, Thomas H.; Leiserson, Charles E.; Rivest, Ronald L. (2009). Introduction to Algorithms (3rd ed.). Cambridge/MA: MIT Press. p. 45. ISBN 978-0-262-53305-8. Because θ(g(n)) is a set, we could write "f(n) ∈ θ(g(n))" to indicate that f(n) is a member of θ(g(n)). Instead, we will usually write f(n) = θ(g(n)) to express the same notion. You might be confused because we abuse equality in this way, but we shall see later in this section that doing so has its advantages.
- 7·, p. 53
- Howell, Rodney. "On Asymptotic Notation with Multiple Variables" (PDF).
   Archived (PDF) from the original on 2015-04-24. Retrieved 2015-04-23.
- 9. ^ de Bruijn, N.G. (1958). Asymptotic Methods in Analysis. Amsterdam: North-Holland. pp. 5-7. ISBN 978-0-486-64221-5. Archived from the original on 2023-01-17. Retrieved 2021-09-15.
- 10. ^ Graham, Ronald; Knuth, Donald; Patashnik, Oren (1994). Concrete Mathematics (2 ed.). Reading, Massachusetts: Addison—Wesley. p. 446. <u>ISBN</u> 978-0-201-55802-9. <u>Archived</u> from the original on 2023-01-17. Retrieved 2016-09-23.
- 11. Donald Knuth (June-July 1998). <u>"Teach Calculus with Big O"</u> (PDF). <u>Notices of the American Mathematical Society</u>. 45 (6): 687. <u>Archived</u> (PDF) from the original on 2021-10-14. Retrieved 2021-09-05. (<u>Unabridged version Archived</u> 2008-05-13 at the <u>Wayback Machine</u>)
- 12. Donald E. Knuth, The art of computer programming. Vol. 1. Fundamental algorithms, third edition, Addison Wesley Longman, 1997. Section 1.2.11.1.
- 13. Ronald L. Graham, Donald E. Knuth, and Oren Patashnik, Concrete Mathematics: A Foundation for Computer Science (2nd ed.), Addison-Wesley, 1994. Section 9.2, p. 443.
- 14. Sivaram Ambikasaran and Eric Darve, An

$$\mathcal{O}(N \log N)$$

Fast Direct Solver for Partial Hierarchically Semi-Separable Matrices, J. Scientific Computing 57 (2013), no. 3, 477–501.

15. Saket Saurabh and Meirav Zehavi,

$$(k, n-k)$$

-Max-Cut: An

$$\mathcal{O}^*(2^p)$$

- -Time Algorithm and a Polynomial Kernel, Algorithmica 80 (2018), no. 12, 3844–3860.
- Seidel, Raimund (1991), "A Simple and Fast Incremental Randomized Algorithm for Computing Trapezoidal Decompositions and for Triangulating Polygons", Computational Geometry, 1: 51–64, CiteSeerX 10.1.1.55.5877, doi:10.1016/0925-7721(91)90012-4
- 17. ^ <u>Landau, Edmund</u> (1909). Handbuch der Lehre von der Verteilung der Primzahlen [Handbook on the theory of the distribution of the primes] (in German). Leipzig: B. G. Teubner. p. 61.
- 18. Thomas H. Cormen et al., 2001, Introduction to Algorithms, Second Edition, Ch.

- 3.1 Archived 2009-01-16 at the Wayback Machine
- 19. Baratchart, L.; Grimm, J.; LeBlond, J.; Partington, J.R. (2003). "Asymptotic estimates for interpolation and constrained approximation in H2 by diagonalization of Toeplitz operators". Integral Equations and Operator Theory. 45 (3): 269–29. doi:10.1007/s000200300005.
- Cormen TH, Leiserson CE, Rivest RL, Stein C (2009). Introduction to algorithms (3rd ed.). Cambridge, Mass.: MIT Press. p. 48. <u>ISBN</u> 978-0-262-27083-0. OCLC 676697295.
- 21. ^ Hardy, G.H.; Littlewood, J.E. (1914). "Some problems of diophantine approximation: Part II. The trigonometrical series associated with the elliptic θ functions". Acta Mathematica. 37: 225. doi:10.1007/BF02401834. Archived from the original on 2018-12-12. Retrieved 2017-03-14.
- 22. ^ Hardy, G.H.; Littlewood, J.E. (1916). "Contribution to the theory of the Riemann zeta-function and the theory of the distribution of primes". <u>Acta</u> Mathematica. 41: 119–196. doi:10.1007/BF02422942.
- <sup>23</sup>· <u>Landau, E.</u> (1924). "Über die Anzahl der Gitterpunkte in gewissen Bereichen. IV" [On the number of grid points in known regions]. Nachr. Gesell. Wiss. Gött. Mathphys. (in German): 137–150.
- 24. ^ <u>Ivić, A.</u> (1985). The Riemann Zeta-Function. John Wiley & Sons. chapter 9.
- 25. <u>Tenenbaum, G.</u> (2015). Introduction to Analytic and Probabilistic Number Theory. Providence, RI: American Mathematical Society. § 1.5.
- Knuth, Donald (April–June 1976). "Big Omicron and big Omega and big Theta". SIGACT News. 8 (2): 18–24. doi:10.1145/1008328.1008329. S2CID 5230246.
- 27. Balcázar, José L.; Gabarró, Joaquim. "Nonuniform complexity classes specified by lower and upper bounds" (PDF). RAIRO Theoretical Informatics and Applications Informatique Théorique et Applications. 23 (2): 180. ISSN 0988-3754. Archived (PDF) from the original on 14 March 2017. Retrieved 14 March 2017 via Numdam.
- Cucker, Felipe; Bürgisser, Peter (2013). "A.1 Big Oh, Little Oh, and Other <u>Comparisons</u>". Condition: The Geometry of Numerical Algorithms. Berlin, Heidelberg: Springer. pp. 467–468. doi:10.1007/978-3-642-38896-5. ISBN 978-3-642-38896-5.
- 29. ^ Vitányi, Paul; Meertens, Lambert (April 1985). "Big Omega versus the wild functions" (PDF). ACM SIGACT News. 16 (4): 56-59. CiteSeerX 10.1.1.694.3072. doi:10.1145/382242.382835. S2CID 11700420. Archived (PDF) from the original on 2016-03-10. Retrieved 2017-03-14.
- Cormen, Thomas H.; Leiserson, Charles E.; Rivest, Ronald L.; Stein, Clifford (2001) [1990]. Introduction to Algorithms (2nd ed.). MIT Press and McGraw-Hill. pp. 41–50. <u>ISBN</u> 0-262-03293-7.
- 31. ^ Gérald Tenenbaum, Introduction to analytic and probabilistic number theory, « Notation », page xxiii. American Mathematical Society, Providence RI, 2015.
- 32. for example it is omitted in: Hildebrand, A.J. "Asymptotic Notations" (PDF). Department of Mathematics. Asymptotic Methods in Analysis. Math 595, Fall 2009. Urbana, IL: University of Illinois. Archived (PDF) from the original on 14 March 2017. Retrieved 14 March 2017.
- 33. , p. 64: "Many people continue to use the O-notation where the Θ-notation is more technically precise."
- 34. Cormen, Thomas H.; Leiserson, Charles E.; Rivest, Ronald L. (2009).
  Introduction to Algorithms (3rd ed.). Cambridge/MA: MIT Press. p. 47.
  <u>ISBN</u> 978-0-262-53305-8. When we have only an asymptotic upper bound, we use O-notation. For a given function g(n), we denote by O(g(n)) (pronounced "big-oh of g of n" or sometimes just "oh of g of n") the set of functions O(g(n)) = {

- f(n): there exist positive constants c and  $n_o$  such that  $o \le f(n) \le cg(n)$  for all  $n \ge n_o$ }
- 35. Cormen, Thomas H.; Leiserson, Charles E.; Rivest, Ronald L. (2009).
  Introduction to Algorithms (3rd ed.). Cambridge/MA: MIT Press. p. 49.
  ISBN 978-0-262-53305-8. When the asymptotic notation stands alone (that is, not within a larger formula) on the right-hand side of an equation (or inequality), as in n = O(n²), we have already defined the equal sign to mean set membership: n ∈ O(n²). In general, however, when asymptotic notation appears in a formula, we interpret it as standing for some anonymous function that we do not care to name. For example, the formula 2n² + 3n + 1 = 2n² + θ(n) means that 2n² + 3n + 1 = 2n² + f(n), where f(n) is some function in the set θ(n). In this case, we let f(n) = 3n + 1, which is indeed in θ(n). Using asymptotic notation in this manner can help eliminate inessential detail and clutter in an equation.
- Cormen, Thomas H.; Leiserson, Charles E.; Rivest, Ronald L.; Stein, Clifford (2022). Introduction to Algorithms (4th ed.). Cambridge, Mass.: The MIT Press. pp. 74–75. ISBN 9780262046305.
- 37. Andreas Björklund and Thore Husfeldt and Mikko Koivisto (2009). "Set partitioning via inclusion-exclusion" (PDF). SIAM Journal on Computing. 39 (2): 546–563. doi:10.1137/070683933. Archived (PDF) from the original on 2022-02-03. Retrieved 2022-02-03. See sect.2.3, p.551.
- Erdelyi, A. (1956). Asymptotic Expansions. Courier Corporation. <u>ISBN</u> 978-0-486-60318-6.
- E. C. Titchmarsh, The Theory of the Riemann Zeta-Function (Oxford; Clarendon Press, 1951)
- 40. <u>Landau, Edmund</u> (1909). Handbuch der Lehre von der Verteilung der Primzahlen [Handbook on the theory of the distribution of the primes] (in German). Leipzig: B. G. Teubner. p. 62.
- 41. <u>Hardy, G. H.</u> (1910). Orders of Infinity: The 'Infinit\u00e4rcalc\u00fcl' of Paul du Bois-Reymond. <u>Cambridge University Press.</u> p. 2.
- <sup>42.</sup> Hardy, G. H.; <u>Wright, E. M.</u> (2008) [1st ed. 1938]. "1.6. Some notations". An Introduction to the Theory of Numbers. Revised by <u>D. R. Heath-Brown</u> and <u>J. H. Silverman</u>, with a foreword by <u>Andrew Wiles</u> (6th ed.). Oxford: Oxford University Press. <u>ISBN</u> 978-0-19-921985-8.
- 43. See for instance "A new estimate for G(n) in Waring's problem" (Russian). Doklady Akademii Nauk SSSR 5, No 5-6 (1934), 249-253. Translated in English in: Selected works / Ivan Matveevič Vinogradov; prepared by the Steklov Mathematical Institute of the Academy of Sciences of the USSR on the occasion of his 90th birthday. Springer-Verlag, 1985.
- Note that the "size" of the input [data stream] is typically used as an indication of [that is, it is assumed to "reflect"] how challenging a given instance is, of the problem to be solved. The amount of [execution] time, and the amount of [memory] space required to compute the answer, (or to "solve' the problem, whatever it is), are seen as indicating or "reflecting" the difficulty of that instance of the problem (along with, in some cases, [the 'related' issue, of] the power of the algorithm that is used by a certain program). For purposes of Computational complexity theory, Big O notation is used for [the "order of magnitude" of] all 3 of those: the size of the input [data stream], the amount of [execution] time required, and the amount of [memory] space required.
- \* Hardy, G. H. (1910). Orders of Infinity: The 'Infinitärcalcül' of Paul du Bois-Reymond. Cambridge University Press.
- Knuth, Donald (1997). "1.2.11: Asymptotic Representations". Fundamental

Algorithms. The Art of Computer Programming. Vol. 1 (3rd ed.). Addison-Wesley. ISBN 978-0-201-89683-1.

- \* Cormen, Thomas H.; Leiserson, Charles E.; Rivest, Ronald L.; Stein, Clifford (2001). "3.1: Asymptotic notation". Introduction to Algorithms (2nd ed.). MIT Press and McGraw-Hill. ISBN 978-0-262-03293-3.
- Sipser, Michael (1997). Introduction to the Theory of Computation. PWS Publishing. pp. 226–228. ISBN 978-0-534-94728-6.
- \* Avigad, Jeremy; Donnelly, Kevin (2004). Formalizing O notation in Isabelle/HOL (PDF). International Joint Conference on Automated Reasoning. doi:10.1007/978-3-540-25984-8\_27.
- \* Black, Paul E. (11 March 2005). Black, Paul E. (ed.). "big-O notation". Dictionary of Algorithms and Data Structures. U.S. National Institute of Standards and Technology. Retrieved December 16, 2006.
- \* Black, Paul E. (17 December 2004). Black, Paul E. (ed.). "<u>little-o notation</u>". Dictionary of Algorithms and Data Structures. U.S. National Institute of Standards and Technology. Retrieved December 16, 2006.
- \* Black, Paul E. (17 December 2004). Black, Paul E. (ed.). "Ω". Dictionary of Algorithms and Data Structures. U.S. National Institute of Standards and Technology. Retrieved December 16, 2006.
- \* Black, Paul E. (17 December 2004). Black, Paul E. (ed.). "ω". Dictionary of Algorithms and Data Structures. U.S. National Institute of Standards and Technology. Retrieved December 16, 2006.
- \* Black, Paul E. (17 December 2004). Black, Paul E. (ed.). <u>"⊕"</u>. Dictionary of Algorithms and Data Structures. U.S. National Institute of Standards and Technology. Retrieved December 16, 2006.

![](_page_31_Picture_9.jpeg)

- \* Growth of sequences OEIS (Online Encyclopedia of Integer Sequences) Wiki
- \* Introduction to Asymptotic Notations
- Big-O Notation What is it good for
- An example of Big O in accuracy of central divided difference scheme for first derivative
- \* A Gentle Introduction to Algorithm Complexity Analysis