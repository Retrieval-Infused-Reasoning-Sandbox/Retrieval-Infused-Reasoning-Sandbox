![](_page_0_Picture_0.jpeg)

![](_page_0_Picture_1.jpeg)

# **RESEARCH ARTICLE**

10.1029/2020JB021027

#### **Key Points:**

- The distribution of magnitude differences is identical to the distribution of magnitudes, but with no reference to a minimum magnitude
- The positive subset of the differences between successive earthquakes is minimally biased by changing catalog completeness
- Unbiased statistics confirm subtle differences in *b*-value between foreshock and aftershocks in several recent sequences

#### **Supporting Information:**

• Supporting Information S1

#### **Correspondence to:**

N. J. van der Elst, nvanderelst@usgs.gov

#### **Citation:**

van der Elst, N. J. (2021). *B-positive*: A robust estimator of aftershock magnitude distribution in transiently incomplete catalogs. *Journal of Geophysical Research: Solid Earth*, *126*, e2020JB021027. [https://doi.](https://doi.org/10.1029/2020JB021027) [org/10.1029/2020JB021027](https://doi.org/10.1029/2020JB021027)

Received 18 SEP 2020 Accepted 5 JAN 2021

#### Published 2021. This article is a U.S. Government work and is in the public domain in the USA.

# *B-Positive***: A Robust Estimator of Aftershock Magnitude Distribution in Transiently Incomplete Catalogs**

**Nicholas J. van der Elst1**

U.S. Geological Survey, Earthquake Science Center, Pasadena, CA, USA

**Abstract** The earthquake magnitude-frequency distribution is characterized by the *b*-value, which describes the relative frequency of large versus small earthquakes. It has been suggested that changes in *b*-value after an earthquake can be used to discriminate whether that earthquake is part of a foreshock sequence or a more typical mainshock-aftershock sequence, with a decrease in *b*-value heralding a larger earthquake to come. However, the measurement of *b*-value during an active aftershock sequence is strongly biased by short-term incompleteness of the earthquake catalog and by data-windowing, and these biases have the same direction as the proposed signal. Here I develop a new estimator of the *b-*value that is insensitive to transient changes in catalog completeness and that does not require data windowing. The new estimator "*b*-positive" is based on the positive-only subset of the differences in magnitude between successive earthquakes, which are described by a double-exponential (Laplace) distribution with the same *b*-value as the magnitude distribution itself. The *b*-positive estimator greatly improves the robustness of continuous *b*-value measurements during active earthquake sequences, as well as in historical catalogs with unknown or variable completeness. The new estimator confirms some of the observations of Gulia and Wiemer (2019), although at a reduced level, showing a decrease and recovery of the *b*-value during several recent foreshock sequences that cannot be attributed simply to measurement bias. However, the unbiased *b*-value changes may be too subtle to use in a real-time earthquake alarm system.

**Plain Language Summary** Earthquakes come in many sizes. Fortunately for us, small earthquakes are exponentially more common than large ones. Seismologists use a parameter called the "*b*-value" to characterize just how many small earthquakes you expect (on average) for every big one. All else being equal, a high *b*-value means a lower than average chance of a large earthquakes, while a low *b*-value means a higher chance. *B*-value is hard to measure in very active sequences where many smaller earthquakes go undetected. In this study, I propose an improved method for measuring *b*-value that isn't affected by the detection problem. The new method is called "*B*-positive" and is measured from the distribution of positive magnitude differences between successive earthquakes. This works because the distribution of magnitude differences is identical to the distribution of earthquake magnitudes, with the same *b*-value, and because positive magnitude differences are not very affected by the small earthquake detection problem. The new tool confirms recent observations of low *b*-value in some sequences that turn out to be foreshocks.

# **1. Introduction**

Earthquake magnitudes are exponentially distributed. This means that for any magnitude *M*, the number of earthquakes *N* with magnitude larger than *M* can be written <sup>10</sup> log N bM , in what is known as the Gutenberg-Richter (GR) distribution. The parameter *b* describes the slope of the distribution in log-linear space. In probabilistic terms, the *b*-value characterizes the relative likelihood of small versus large earthquakes within a population of earthquakes, and therefore has utility in earthquake forecasting.

It has also been argued that *b*-value may carry diagnostic information about the state of stress on the faults generating the earthquakes (Amitrano, [2003;](#page-17-0) Gulia et al., [2018](#page-17-1); Scholz, [2015;](#page-18-0) Schorlemmer et al., [2005;](#page-18-1) Spada et al., [2013](#page-18-2)). This has led to the idea that *b* has potential for discriminating between foreshock and aftershock sequences (Gulia & Wiemer, [2019\)](#page-17-2). Specifically, it is claimed that a shift in *b* to lower values within the aftershock zone of a large earthquake is an indicator that stress has increased on neighboring faults, and that the earthquake is likely to be a foreshock to something larger. Conversely, if *b* shifts to higher values,

VAN DER ELST 1 of 19

1699356, 2021, 2, Downloaded from https://agupubs.onlinelibrary.wiley.com/doi/10.1029/2020JB021027, Wiley Online Library on [21/10/2025]. See the Terms and Conditions

conditions) on Wiley Online Library for rules of use; OA articles

then the stress has been relaxed, making a larger earthquake less likely. Regardless of whether b actually acts as a physical stress meter, the b-value of a sequence has real value in forecasting, because it describes the relative probability of large versus small earthquakes within a set of forecast earthquakes.

Unfortunately, it is very difficult to measure *b* early in an aftershock sequence when the catalog is incomplete (Helmstetter et al., 2006; Kagan, 2004; Knopoff et al., 1982; Woessner & Wiemer, 2005). The "completeness" magnitude—the magnitude above which a network is likely to resolve and record earthquakes—varies strongly in the early part of an aftershock sequences when aftershock rates are high, and events overlap in time on seismograms. Since incompleteness appears as a reduction in the relative number of small versus large earthquakes, this can heavily bias *b* estimates. Typical fixes involve masking out the early period of an aftershock sequence or defining a time-varying magnitude of completeness that is a function of the previous mainshock magnitude (Helmstetter et al., 2006).

If we are to evaluate whether the *b*-value can actually discriminate between foreshock and aftershock sequences, we need to be able to observe a robust decrease in the *b*-value in the immediate aftermath of an earthquake. Here I propose an alternative approach to estimating *b* that is based on the distribution of magnitude *differences*. This approach assumes only that the magnitude of completeness is constant between any two successive events in a population, rather than constant for the entire population, as is commonly done. When formulated in terms of differences, the completeness magnitude drops out of the equation entirely. The distribution of magnitude differences can therefore be used to estimate *b* during periods of strongly varying incompleteness level, making it the perfect tool for analyzing aftershock sequences.

In this study, I introduce the magnitude difference distribution, characterized by the Laplace (Double Exponential) distribution, and derive the maximum likelihood estimate of b. Just as with the GR (Exponential) distribution for earthquake magnitudes, some corrections need to be made for incompleteness and for magnitude rounding. The Laplace-based estimator is made even more robust by restricting the analysis to positive-only magnitude differences ("b-positive"), where the second earthquake is larger than the first. This allows for robust measurement of the b-value at all times within the earthquake sequence.

I compare the performance of the b-positive estimator to the standard GR estimator for some recent sequences analyzed by Gulia and Wiemer (2019), and for the 2019 Ridgecrest, California, sequence, analyzed by Gulia et al. (2020). Importantly, the b-positive estimator can be applied to populations containing the foreshock or mainshock themselves, with no need to separate the populations into "before" and "after," and no need to mask out the early time after the mainshock or foreshock. This makes the b-positive estimator uniquely powerful in application to real-time foreshock discrimination.

This study is meant primarily to introduce a new method for estimating b-value in catalogs with heterogeneous completeness, and to address potential measurement errors within recent studies (Gulia & Wiemer, 2019; Gulia et al., 2020). The new analysis shows that the reduction in b-value at or around the time of selected foreshocks cannot be simply dismissed as measurement error, although it may be less pronounced than earlier estimates. It remains unclear whether the b-value changes are significant enough to be used as an earthquake precursor in operational aftershock forecasting.

#### 2. Methods

### 2.1. The Laplace Distribution

<span id="page-1-0"></span>Suppose that magnitudes m follow an Exponential distribution with location parameter equal to some lower cutoff magnitude  $M_c$ , and scale parameter  $\beta$ ,

$$f(m \mid \beta, M_c) = \begin{cases} \beta e^{-\beta(m - M_c)} & m \ge M_c \\ 0 & m < M_c \end{cases}$$
(1)

where I have substituted the exponential parameter  $\beta = b \times ln10$  for mathematical convenience. This distribution is known as the GR distribution (Gutenberg & Richter, 1944). The actual observed magnitude distribution is the product of both the magnitude probability distribution and a magnitude-detection function.

VAN DER ELST 2 of 19

Equation 1 describes an idealized case where the probability of detecting an earthquake of a given size is described by a unit step at  $m = M_c$ . (In practice, observed earthquakes below  $M_c$  are discarded) More complicated models of the "incompleteness function" will be discussed below.

For an Exponential distribution, the difference between independent and identically distributed (iid) magnitudes m' follows a Laplace or Double Exponential distribution (Abramowitz & Stegun, 1972) also with scale parameter  $\beta$ . For the absolute value of the difference |m'|, the distribution of the differences is identical to the distribution of the magnitudes

$$f(|m'| \mid \beta) = \beta e^{-\beta|m'|}.$$
 (2)

<span id="page-2-0"></span>Notice that the Laplace distribution for *iid* magnitudes (Equation 2) does not contain the completeness magnitude. If one further defines *m*' as being the absolute difference between any two *successive* magnitudes, then the distribution is insensitive to the completeness magnitude as long as it is sufficiently similar between any two successive earthquakes. Thus one can use the Laplace distribution as a more robust tool for estimating the magnitude distribution in populations where the completeness magnitude is nonstationary.

The  $\beta$  parameter is traditionally estimated by maximum likelihood. For the Exponential (GR) distribution (1), the maximum likelihood estimate (Aki, 1965) is given by

$$\tilde{\beta} = \left(\overline{m} - M_c\right)^{-1},\tag{3}$$

<span id="page-2-2"></span>where  $\overline{m}$  is the sample mean.

For the Laplace distribution, the estimator has the same form, but in terms of the magnitude differences.

$$\tilde{\beta}' = \left(\overline{|m'|}\right)^{-1},\tag{4}$$

<span id="page-2-3"></span>where  $|\overline{m'}|$  is the sample mean of the absolute magnitude differences.

The Laplace estimator can also be applied to positive or negative magnitude differences independently, which will be useful when I discuss short-term aftershock incompleteness, below.

All of the estimators are biased if the magnitudes are discretized (rounded). The estimators for discrete distributions are included in the appendix. Uncertainties are computed via the bootstrap method.

# 2.2. Incompleteness

Earthquake catalogs are incomplete records of the earthquakes that have happened in any region. The first order limitation is the signal-to-noise ratio for small earthquakes. Below a certain magnitude, the ground motions are not large enough to be detected at an adequate number of seismic stations, and these earthquakes go uncataloged. This shows up as a saturation or "roll-over" of the GR distribution at small magnitudes. I will refer to this as network incompleteness. Network incompleteness is typically addressed by measuring  $\beta$  only above some completeness magnitude that is larger than the minimum magnitude in the catalog. How does this incompleteness affect the Laplace distribution?

I analyze the effect of network incompleteness on the Laplace distribution by using a simulation that has been filtered according to the detection model of Ogata and Katsura (1993). These authors suggested a detection filter based on a cumulative normal distribution.

$$d_{M}\left(m\mid\mu,\sigma\right) = \int_{-\infty}^{m} \frac{1}{\sigma\sqrt{2\pi}} e^{\frac{-(\theta-\mu)^{2}}{2\sigma^{2}}} d\theta,\tag{5}$$

<span id="page-2-1"></span>The incomplete magnitude-probability distribution is then given by the (appropriately normalized) product of Equations 5 and 1. The location parameter  $\mu$  gives the magnitude at which one expects 50% detection

VAN DER ELST 3 of 19

![](_page_3_Figure_3.jpeg)

<span id="page-3-0"></span>**Figure 1.** (a) The complete Gutenberg-Richter and Laplace distributions for  $\beta = \ln 10$ ,  $\mu = 0$ , and  $\sigma = 0$  (Equation 5). (b) The incomplete distributions with  $\sigma = 0.2$ .

probability, and the scale parameter  $\sigma$  describes how quickly 100% detection is achieved. For instance, one could define a ~84% completeness magnitude as  $M_c = \mu + \sigma$ . The scale parameter  $\sigma$  is typically around 0.2 for modern catalogs.

The incomplete Laplace distribution derived from the detection filter (Equation 5) cannot be written down in terms of elementary functions, but it can be computed numerically. Figure 1 shows the effect of incompleteness (Equation 5) on the Laplace distribution. The gradient of the incomplete Laplace distribution approaches the true gradient ( $\beta$ ) above some minimum value, and one can accurately measure  $\beta$  by imposing a minimum magnitude or magnitude difference. The Laplace estimator then becomes

$$\tilde{\beta}' = \left( \overline{|m'|} - M_c' \right)^{-1}, \tag{6}$$

<span id="page-3-1"></span>where  $|\overline{m'}|$  is again the sample mean of the absolute magnitude differences, and  $M_c^{'}$  is a minimum magnitude difference.

The estimators in Equations 3, 4, and 6 assume that magnitudes are continuous random variables. This is seldom the case in earthquake catalogs, where magnitudes are often reported only to 1 or 2 decimal places. The estimators for rounded (discrete) catalogs are given in Appendix A. Uncertainties on all statistics are estimated by bootstrap.

### 2.3. Time-Varying Incompleteness

The completeness magnitude is rarely homogeneous during an active aftershock sequence. This is because catalog processing systems can be overwhelmed by superimposed signals from many earthquakes, causing the completeness magnitude to rise with the activity rate (Hainzl, 2016; Helmstetter et al., 2006; Kagan, 2004).

To illustrate, Figure 2 shows a magnitude-ranked time plot for the 2019 Ridgecrest earthquake sequence, which contains a M6.4 foreshock, followed 1.5 days later by a M7.1 mainshock. Plotting by ranked time spreads the data points out to have uniform density along the *x*-axis, so that the homogeneity of the magnitude distribution can be assessed visually. Note that the distribution of magnitude differences is far less perturbed by the occurrence of the large earthquakes.

The completeness level is clearly not constant with time and can go up by several magnitude units during robust aftershock sequences. A single completeness magnitude may not be appropriate for any population of aftershocks early in a sequence. Furthermore, because M6's block out M5's, M5's block out M4's, and so on, the distribution is incomplete across the entire magnitude range.

VAN DER ELST 4 of 19

![](_page_4_Figure_3.jpeg)

<span id="page-4-0"></span>**Figure 2.** (a) Magnitude versus ranked time for earthquakes recorded during the 2019 Ridgecrest sequence. "*Mc* binned" is determined by maximum curvature (see text) for a running window of 400 events. "*Mc*(*t*) modeled" is the modeled instantaneous magnitude of completeness according to Equations [5](#page-2-1) and [7.](#page-4-1) (b) Magnitude differences. (c) Magnitude differences for earthquakes above the running *Mc* estimate in panel (a).

The instantaneous magnitude of completeness can be modeled as a function of the magnitudes and times of previous earthquakes (Ogata & Katsura, [2006\)](#page-18-4). Helmstetter et al. [\(2006](#page-17-3)) proposed a time-dependent magnitude of completeness of the form

$$M_c(t) = M_i - G - H\log(t - t_i), \tag{7}$$

<span id="page-4-1"></span>following some earthquake *i*. The instantaneous completeness magnitude at any time *t* in the catalog is the maximum value of Equation [7](#page-4-1) computed over all previous earthquakes. In the context of the Ogata and Katsura [\(1993](#page-17-10)) incompleteness model, Equation [7](#page-4-1) can be taken to describe the evolution of the 50% completeness magnitude *µ*(*t*) = *M*c(*t*) in the cumulative normal detection function (Equation [5](#page-2-1)). The incompleteness magnitude in Equation [7](#page-4-1) is bounded from above by the magnitude of the considered mainshock *Mi* (i.e., I assume perfect detection of an earthquake if it is larger than the event potentially obscuring it), and from below by the network incompleteness value *M*cat. I set parameters *G* = 5.6, *H* = 1, and *M*cat = 0.95 (Table [1\)](#page-4-2) based on forward modeling and a qualitative comparison to the observed catalog (Figure [2](#page-4-0)). These parameters are fairly consistent with the values previously reported for Southern California (*G* = 4.5, *H* = 0.75, *M*cat = 2.0) (Helmstetter et al., [2006\)](#page-17-3).

Using Equation [7](#page-4-1), I compute the theoretical instantaneous completeness level for the observed Ridgecrest sequence (sampled at the time of each cataloged earthquake) and compare this to the common maximum curvature estimate [Woessner & Wiemer, [2005\]](#page-18-3)). In the maximum curvature method, the completeness magnitude is defined as the mode of the distribution of rounded magnitudes, plus some arbitrary correction. Since the mode of the distribution is very close to the 50% detection value *µ* of the Ogata and Katsura method (Equation [5\)](#page-2-1), the max-curvature method gives a very good estimate of the Ogata and Katsura com-

<span id="page-4-2"></span>

| G<br>H<br>Mcat<br>σ<br>b<br>p<br>log10k<br>c<br>5.6<br>1<br>0.95<br>0.2<br>1.0<br>1.06<br>−2.5<br>0.001 | Table 1<br>Input Model Parameters |  |  |  |  |  |  |  |  |  |
|---------------------------------------------------------------------------------------------------------|-----------------------------------|--|--|--|--|--|--|--|--|--|
|                                                                                                         |                                   |  |  |  |  |  |  |  |  |  |
|                                                                                                         |                                   |  |  |  |  |  |  |  |  |  |

pleteness level if one defines *Mc*(*t*) = *µ* + *σ*, with *σ* = *δM*c. I use a rounding precision of 0.1 units, a correction *δM*c = 0.2 units, and a running window of 400 events. The maximum curvature estimate of completeness is plotted as the green line in Figure [2a.](#page-4-0)

The distribution of instantaneous completeness magnitudes (Equation [7\)](#page-4-1) is compared to the 400-event maximum-curvature estimate in Figure [3.](#page-5-0)

VAN DER ELST 5 of 19

21699356, 2021, 2, Downloaded from https://agupubs.onlinelibrary.wiley.com/doi/10.1029/20201B021027, Wiley Online Library on [21/10/2025]. See the Terms and Conditions (https://agupubs.onlinelibrary.wiley.com/doi/10.1029/20201B021027, Wiley Online Library on [21/10/2025]. See the Terms and Conditions (https://agupubs.onlinelibrary.wiley.com/doi/10.1029/20201B021027, Wiley Online Library on [21/10/2025]. See the Terms and Conditions (https://agupubs.onlinelibrary.wiley.com/doi/10.1029/20201B021027, Wiley Online Library on [21/10/2025]. See the Terms and Conditions (https://agupubs.onlinelibrary.wiley.com/doi/10.1029/20201B021027, Wiley Online Library on [21/10/2025]. See the Terms and Conditions (https://agupubs.onlinelibrary.wiley.com/doi/10.1029/20201B021027, Wiley Online Library on [21/10/2025]. See the Terms and Conditions (https://agupubs.onlinelibrary.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.com/doi/10.1029/20201B021027, Wiley Online Library.wiley.wiley.com/doi/10.1029/20201B021

nd-conditions) on Wiley Online Library for rules of use; OA articles

![](_page_5_Figure_3.jpeg)

<span id="page-5-0"></span>**Figure 3.** Distribution of completeness magnitude  $M_c$  in the days after the M6.4 Ridgecrest mainshock. The green histograms ( $M_c$  binned) give the distribution of  $M_c$  determined by maximum-curvature on a running window of 400 events. The yellow histograms show the distribution of the modeled instantaneous  $M_c(t)$  (Equation 7) sampled at the times of cataloged earthquakes.

There is a roughly exponential distribution of incompleteness magnitudes, and the 400-event max-curvature method fails to capture important excursions in the completeness magnitude. This effect is strongest early on (Figure 3a) but persists throughout the first month of the sequence (Figure 3b).

Short-term aftershock incompleteness (STAI) affects the slope of the GR distribution, because earthquakes are missing over a range of magnitudes (Figure 3). How does STAI affect the Laplace distribution? The Laplace distribution is based on the assumption of constant  $M_c$  between any two earthquakes. But this cannot always be true, given that the first earthquake in a pair influences the completeness level for subsequent detections (Equation 7). A large negative magnitude difference is only possible after a large earthquake, but a large earthquake limits the detection of much smaller earthquakes. One would therefore expect negative magnitude differences to saturate at some value. This is not true, however, for positive magnitude differences, which should be unaffected by STAI.

<span id="page-5-1"></span>I therefore make one final adjustment to the Laplace estimator (Equation 6), defining

$$\tilde{\beta}^{+} = \left(\overline{m'} - M'_{c}\right)^{-1} \qquad m' \ge M'_{c}$$

$$\tilde{\beta}^{-} = \left(\overline{-m'} - M'_{c}\right)^{-1} \quad m' \le -M'_{c}$$
(8)

The estimator  $\beta^+$  ("b-positive"), is based on positive magnitude differences only (i.e., where the second earthquake is larger than the first), and should be minimally affected by STAI, which I confirm in the next section for a simulated catalog. Note that for a discrete distribution of magnitudes and magnitude differences, the population with m'=0 contains both positive and negative true magnitude differences. To restrict the analysis to strictly positive magnitude differences, one should set  $M_c' \ge 2\delta$ , where  $2\delta$  is the discretization level (Appendix A).

#### 3. Results

#### 3.1. Demonstration of the Laplace Estimator for a Simulated Catalog

I generate 100 simulated catalogs, designed to mimic the 2019 Ridgecrest earthquake sequence, using an Epidemic Type Aftershock Sequence (ETAS) model (Ogata, 1998), using a code modified from Hardebeck et al. (2008). The model is formulated with  $\beta = \ln 10$  (b = 1), and other parameters optimized to give a similar number of total aftershocks as in the first 7 days of the Ridgecrest sequence (Table 1).

The Ridgecrest sequence is defined as starting at 0000UTC July 4, 2019 and including events with a lat/lon box with corners [35.2, -118.2], [36.4, -117.0]. Data for the Ridgecrest sequence are taken from the U.S.

VAN DER ELST 6 of 19

![](_page_6_Figure_3.jpeg)

<span id="page-6-0"></span>**Figure 4.** Magnitudes and magnitude differences versus time for the Ridgecrest 2019 sequence (left) and a simulated sequence for comparison.

Geological Survey (USGS) Comprehensive Catalog (ComCat), using the default "preferred" magnitudes returned by the ComCat web services API.

The M6.4 foreshock is somewhat more productive than average for its magnitude, and I find that a magnitude correction of +0.3 provides a good match to the number of early aftershocks. I therefore seed the ETAS catalog with a M6.7 and a M7.1 earthquake at the appropriate times, from which I generate random catalogs containing primary aftershocks and multiple generations of secondary aftershocks.

The simulated catalogs are made incomplete (filtered) according to Equations [5](#page-2-1) and [7](#page-4-1). That is, simulated earthquakes are randomly included or discarded according to their modeled detection probability. A representative simulated catalog is compared to the observed Ridgecrest sequence in Figure [4.](#page-6-0)

The distribution of magnitudes and magnitude differences is plotted in Figure [5](#page-7-0) for the cataloged data and for a stack of the 100 simulated catalogs. The slope of the GR distribution is affected over almost the entire magnitude range, as expected, while the Laplace estimator returns the correct *b*-value above a small minimum difference cutoff. The *b*-positive (*β+*) estimator (Equation [8\)](#page-5-1), which is most robust against short-term aftershock incompleteness, performs especially well.

#### **3.2. Application to the 2019 Ridgecrest Sequence**

In the previous section, we saw that the distribution of positive magnitude differences *β<sup>+</sup>* yields an estimate of *b*-value that is mostly immune to short-term aftershock incompleteness, making it a perfect tool for continuously measuring variations in *b*-value in an ongoing aftershock sequence. In this section, I compare the time-varying *β+* estimator to the classical GR estimator during the 2019 Ridgecrest earthquake sequence.

The M6.4 foreshock generated a complex rupture pattern with slip occurring on at least two orthogonal strands (Ross et al., [2019](#page-18-5)). Gulia et al. [\(2020](#page-17-6)) restrict their *b*-value analysis to the NW-SE trending fault strand, based on a previously established method for discriminating between primary and auxiliary planes of the earthquake focal mechanism. The method identifies the primary fault plane as the one with the largest number of aftershocks within a 3 km distance of the projected fault trace (Gulia & Wiemer, [2019\)](#page-17-2). While the method does select the "correct" plane in this case—that is, the plane that includes the *b*-value anomaly and the eventual mainshock—the method was designed to select between auxiliary focal planes, not between orthogonal rupture traces, and the method could have easily selected the other fault plane if it happened to have generated more aftershocks, missing the anomaly entirely. To address this potential ambiguity, I perform the analysis both on the complete aftershock zone and on the more restricted region analyzed by Gulia et al. ([2020](#page-17-6)).

VAN DER ELST 7 of 19

![](_page_7_Figure_3.jpeg)

<span id="page-7-0"></span>**Figure 5.** (Top) Distribution of magnitudes and magnitude differences in a real and simulated catalog that includes time-varying incompleteness. The input *b*-value is 1.0. (Bottom) Recovered *b*-value as a function of magnitude/difference cutoff using the classical GR and the Laplace (*b*-positive, *b*-negative) estimators. Values are only calculated if more than 20 events remain in the population. Ranges for the Ridgecrest data (left) are the 1−sigma (∼84%) quantiles derived by bootstrap; ranges for the simulated data (right) are the 84% quantiles for 100 randomly generated catalogs. GR, Gutenberg-Richter.

The *b*-positive (*β<sup>+</sup>*) estimate is computed using two different options for handling incompleteness. In the first, I use all cataloged earthquakes to compute the distribution of magnitude differences, and then apply the *β+* estimator above a minimum positive magnitude difference. In the second option, I use only the earthquakes with magnitude greater than the time-varying *Mc and* apply the *β<sup>+</sup>* estimator to all positive magnitude differences. I refer to this second option as *β+*(*Mc*).

The Ridgecrest earthquake sequence included a M6.4 foreshock on July 4, 2019, followed by a M7.1 mainshock on July 5, 2019. Going back to July 4, 2009, I compute *b*-value for a 400-event running window. I use the maximum curvature +0.2 method to determine the magnitude of completeness for the traditional GR estimate. The correction of 0.2 is chosen to be consistent with the value used by Gulia et al. (2019, [2020](#page-17-6)). I use a minimum magnitude difference of +0.2 for the *β<sup>+</sup>* estimate. Note that the magnitude cutoff is imposed after the events are binned, meaning that fewer than 400 events are being used to constrain the *b*-value, by either technique. For the GR estimate, the actual population number (and standard deviation) is 185 ± 41 events; for the *β<sup>+</sup>* estimate, the number is 142 ± 8; and for the *β+(Mc)* estimator, the number is 92 ± 21. The results presented here are fairly insensitive to changes in bin sizes or magnitude corrections. The curious reader can investigate the impact of different parameter choices on the classical GR estimate in Dascher-Cousineau et al. [\(2020\)](#page-17-14), or on their own by inserting the *b*-positive estimator into the scripts provided by Gulia and Wiemer ([2019](#page-17-2)) and Gulia et al. [\(2020\)](#page-17-6).

All of the methods return relatively similar *b*-values over most of the examined time interval, going back to July 4, 2009 (Figure [6\)](#page-8-0). During the active aftershock sequence of the M6.4, the *b*-value as determined by the GR method appears biased low, particularly for windows that actually include the M6.4 foreshock or the M7.1. This is expected due to the heterogeneous *Mc* within these windows. The *β<sup>+</sup>* estimator, on the other hand, appears relatively insensitive to the presence of large earthquakes within the window (marked by

VAN DER ELST 8 of 19

![](_page_8_Figure_3.jpeg)

<span id="page-8-0"></span>**Figure 6.** (a–c) Ridgecrest sequence *b*-value as a function of ranked event time as computed by the three methods. Gray vertical bars show where the M6.4 or M7.1 earthquakes are included in the 400-event sliding window. (d) Magnitudes versus time and time-varying magnitude of completeness (maximum curvature).

gray bars in Figure [6](#page-8-0)). All of the models resolve an increase in *b*-value at the time of the M7.1 mainshock, compared to the time period between the foreshock and mainshock, consistent with the findings of Gulia et al. [\(2020\)](#page-17-6). The *β+* estimator also confirms that the *b*-value reaches one of its lowest values in the entire data set soon after the M6.4.

However, the evolution of the *β+* estimate appears a bit more complicated than the simple story suggested by Gulia et al. ([2020](#page-17-6)). The *b*-value does not remain depressed throughout the entire period between foreshock and mainshock. Rather, it rises to one of its highest levels (relative to the past 10 years) just after a M5.4 event 0.73 days after the M6.4 foreshock (0.67 days prior to the M7.1 mainshock) (Figure [6](#page-8-0)). The *β+*(*Mc*) estimate also recovers to typical long-term values prior to the occurrence of the M7.1 mainshock.

If I restrict myself to the more limited data set (the NW-SE trending fault plane) analyzed by Gulia et al. [\(2020](#page-17-6)), the *b*-value recovery prior to the mainshock persists, though at a lower level, with the *b*-value rising unsteadily from a value of 0.78 ± 0.7 immediately after the foreshock to a maximum value of 0.85 ± 0.07 just prior to the mainshock (Figure S1). This is almost equal to the *b*-value of 0.88 ± 0.11 estimated for the preforeshock earthquakes, but considerably lower than the postmainshock value of 1.02 ± 0.02 (Figure S2).

The magnitude/difference distributions for time periods before, between, and after the foreshock-mainshock pair are shown in Figure [7](#page-9-0). For the classical GR estimate, the data are windowed to exclude the incomplete period within 0.5 days following the foreshock and 1.5 days following the mainshock, following Gulia et al. ([2020\)](#page-17-6). All of the estimators confirm a reduction in *b*-value between the foreshock and mainshock compared to the decade prior, or to aftershocks of the M7.1. However, the effect is smallest for the *β+* estimator, which is also the least sensitive to bias, and it is not clear that the Ridgecrest sequence would satisfy the 10% change criterion used to trigger a red "traffic light' in the model of Gulia and Wiemer ([2019\)](#page-17-2).

VAN DER ELST 9 of 19

![](_page_9_Figure_3.jpeg)

<span id="page-9-0"></span>**Figure 7.** Clockwise: (a) Map of the 2019 Ridgecrest sequence. Events in gray occurred prior to the M6.4 foreshock, events in red occurred between the foreshock and the M7.1 mainshock, and those in green occurred after the mainshock. (b) Magnitude distributions and GR *b*-value estimates for populations mapped in (a). Minimum magnitude/difference cutoffs are marked by the vertical dashed lines. (c) Magnitude difference distributions and *b*-positive estimates. (d) Distribution of running window *b*-values from Figure [6.](#page-8-0) The red vertical line shows the *b*-value estimate and 1−sigma uncertainty at the time of occurrence of the mainshock.

These observations complicate the interpretation of the *b*-value as a simple measurement of static stress changes caused by large earthquakes, but do not necessarily invalidate the idea that *b*-value has some power to discriminate between foreshock and aftershock sequences.

### **3.3. Application to Select Past Sequences**

I repeat the analysis for three sequences previously identified by Gulia and Wiemer ([2019\)](#page-17-2) as having clear *b*-value precursors: The 2016 Amatrice-Norcia, Italy, sequence, the 2016 Kumamoto, Japan, sequence, and the 2011 Tohoku-oki, Japan, sequence. For these sequences I use the catalogs provided by Gulia and Wiemer [\(2019](#page-17-2)), excluding any events that have a time separation of less than 1 s to filter out suspected duplicates. I use this data, even though there appears to be a problem with the magnitude determination that makes M1.7 and M3.3 events appear extremely rare in the Amatrice-Norcia catalog. This appears to be a catalog processing artifact that was overlooked in previous publications. It is beyond the scope of this study to determine the source of the artifact, but it should not substantially affect the maximum likelihood estimate of the *b*-value, which is based only on the mean of the distributions.

# **3.4. Amatrice-Norcia**

The Amatrice-Norcia foreshock-mainshock sequence consisted of a magnitude 6.2 earthquake on August 24, 2016 followed by a M6.6 earthquake on October 30, 2016 (and a M6.1 aftershock just a few days earlier on 26 October). The *b*-value, estimated by the three methods is plotted in Figure [8.](#page-10-0) Completeness magnitude for the GR estimate is determined by maximum curvature plus +0.3 units. The *b*-positive (*β+*) estimate is

VAN DER ELST 10 of 19

![](_page_10_Figure_3.jpeg)

<span id="page-10-0"></span>**Figure 8.** (a–c) Amatrice-Norcia *b*-value as a function of ranked time as computed by the three methods. Gray bars show where M6 or greater earthquakes are included in the 400-event sliding window. (d) Magnitudes versus time and time-varying magnitude of completeness.

calculated with a minimum difference cutoff *dMc* = 0.3. The *β<sup>+</sup>* estimate of *b*-value drops significantly after the first M6.2 earthquake in August but shows only a gradual increase and recovery after the final M6.6 earthquake in October. The *β<sup>+</sup>*(Mc) estimator also detects a reduction in b-value at the time of the foreshock, as well as evidence for a recovery post mainshock. Overall, the pattern is suggestive of a *b*-value decrease roughly coinciding with the period between the foreshock and mainshock (Figure [9](#page-11-0)), but the recovery to premainshock levels takes on the order of 100 days, according to the robust *β+* estimator.

### **3.5. Kumamoto**

The Kumamoto sequence involved a M6.5 on April 15, 2016, followed by a M7.3 earthquake a mere 28 h later. The sequence included a M6.4 earthquake 2.6 h after the foreshock, which again complicates the use of the GR estimator by contaminating the catalog with short-term aftershock incompleteness. For the Kumamoto sequence, I use a minimum magnitude difference *dMc* = +0.3.

The Kumamoto analysis is presented in Figures [10](#page-12-0) and [11.](#page-13-0) The running-window analysis with the *β<sup>+</sup>* estimator confirms a reduction in *b*-value after the foreshock and a recovery after the mainshock.

Figures [10](#page-12-0) and [11](#page-13-0) show a significant reduction in *b*-value for the period between the foreshock and mainshock. However, the *β*+ does not confirm a sudden recovery of *b*-value at the time of the mainshock. This result is somewhat ambiguous, given that the *β*+(M*c*) estimate seems to show an even larger spike in *b*-value than the classical GR estimate. This may reflect biases inherent in the *Mc* estimation, but this is beyond the scope of this article.

Note that neither the *β*+ or *β*+(Mc) estimators reproduce the dip in *b*-value for populations containing the mainshock itself (Figure [10](#page-12-0)), which in the *GR* estimate is caused by the heterogeneous completeness magnitude. This demonstrates the robustness of the b-positive estimate in real-time applications. No windowing is required.

VAN DER ELST 11 of 19

![](_page_11_Figure_3.jpeg)

<span id="page-11-0"></span>**Figure 9.** Clockwise: (a) Map of the 2016 Amatrice-Norcia sequence. Events in gray occurred prior to the M6.2 foreshock, events in red occurred between the foreshock and the M6.6 mainshock, and those in green occurred after the mainshock. (b) Magnitude distributions and GR *b*-value estimates. Minimum magnitude/difference cutoffs are marked by the vertical dashed lines. GR estimate is calculated with *Mc =* 1.75 to avoid catalog artifact at *M =* 1.7. (c) Magnitude difference distributions and *b*-positive estimates. (d) Distribution of running window *b*-values from Figure [8.](#page-10-0) The red vertical line shows the *b*-value estimate and 1−sigma uncertainty at the time of occurrence of the mainshock. GR, Gutenberg-Richter.

# **3.6. Tohoku**

The 2011 Tohoku-Oki, Japan, sequence gives us an especially useful test case—one in which the foreshock and mainshock are separated by only a few hundred earthquakes, and there is no intervening period over which the catalog can be considered complete. The sequence consisted of a M7.3 foreshock on March 9, 2011, followed 2 days later by a M9.1 mainshock on March 11. There are only 323 events cataloged between the two earthquakes, smaller than the running window of 400 events that I have used in the analysis of the previous sequences in this article. For the Tohoku analysis, I used a running window of 200 events.

The results of the Tohoku analysis are also suggestive of a decrease in *b*-value between the foreshock and aftershock. Figure [12](#page-14-0) shows the time evolution of the *b*-value. While there does appear to be a *b*-value reduction in the period between foreshock and mainshock, the reduction does not seem particularly significant when computed by the unbiased *β<sup>+</sup>* or *β<sup>+</sup>*(Mc) estimators. There are multiple dips in the *b*-value in the years prior to 2011 that match or exceed the dip after the foreshock. On the other hand, the recovery to higher *b*-values after the M9.1 mainshock is robustly recovered by all three methods (Figure [13\)](#page-15-1). For more analysis and discussion of the *b*-value increase, see Tormann et al. [\(2015\)](#page-18-6) and Bürgmann et al. [\(2016](#page-17-15)).

# **4. Discussion**

The *b*-positive (*β+*) estimator provides a measure of *b*-value based only on the positive differences between successive earthquake magnitudes, making it relatively robust to temporal variations in the completeness magnitude. As such, it is particularly useful for applications like the "Traffic Light" system of Gulia and

VAN DER ELST 12 of 19

![](_page_12_Figure_3.jpeg)

<span id="page-12-0"></span>**Figure 10.** (a–c) Kumamoto *b*-value as a function of ranked time as computed by the three methods. Gray bars show where M6 or greater earthquakes are included in the 400-event sliding window. (d) Magnitudes versus time and timevarying magnitude of completeness.

Wiemer [\(2019\)](#page-17-2), which requires rapid determination of *b*-value during the most incomplete periods of an aftershock sequence. Gulia and Wiemer propose that a significant (10%) reduction in *b*-value during an active earthquake sequence heralds a larger event to come (red light), while a significant increase in the *b*-value signals that the largest earthquake has already passed (green light).

The *β<sup>+</sup>* estimator for the most part confirms the results of Gulia and Wiemer ([2019](#page-17-2)) and Gulia et al. ([2020\)](#page-17-6), although the results tend to be somewhat muted compared to the standard GR estimator, as might be expected, given the known bias of the GR estimator. Table [2](#page-14-1) summarizes the results for the four sequences analyzed here, using the *β*+ estimator, and separating the data into populations before, between, and after the foreshock and mainshock. All of the sequences show a reduced *b*-value during the foreshock sequence, compared to the previous long-term average. In most cases the *b*-value drop meets the −10% threshold suggested by Gulia and Wiemer ([2019\)](#page-17-2). All of the sequences also show a recovery (increase) in the *b*-value after the occurrence of the mainshocks, although the *b*-value postmainshock is not always significantly higher than the long-term average before the foreshock.

The running window measurements of *b*-value (Figures [6,](#page-8-0) [8,](#page-10-0) and [12](#page-12-0)) also show that the *b*-value begins to recover almost immediately after the foreshocks, such that the mainshock usually occurs at one of the highest *b*-values of the intervening period. These observations suggest that the system may be more complicated than can be captured by coseismic stress change alone.

Some observers have taken issue with the idea of *b*-value as a "precursor," noting that one would expect large earthquakes to be more probable during periods of reduced *b*-value, simply based on the magnitude-probability distribution. The sequence with the most substantial *b*-value difference (0.29) before and after the mainshock is the 2011 Tohoku-oki sequence (Table [2\)](#page-14-1). For some hypothetical sample of aftershocks above magnitude 3, a *b*-value decrease of 0.29 translates to about a 50 times higher chance of finding at least one magnitude 9 in the sample (1 in 2000 earthquakes vs. 1 in 100,000), lending this hypothesis some plausibility.

VAN DER ELST 13 of 19

![](_page_13_Figure_3.jpeg)

<span id="page-13-0"></span>**Figure 11.** (a) Map of the 2016 Kumamoto sequence. Events in blue occurred prior to the M6.5 foreshock, events in red occurred between the foreshock and the M7.5 mainshock, and those in green occurred after the mainshock. (b) Magnitude distributions and GR *b*-value estimates. Minimum magnitude/difference cutoffs are marked by the vertical dashed lines. (c) Magnitude difference distributions and *b*-positive estimates. (d) Distribution of running window *b*-values from Figure [10](#page-12-0). The red vertical line shows the *b*-value estimate and 1−sigma uncertainty at the time of occurrence of the mainshock.

In this study, I restrict myself to analysis of the sequences previously analyzed by Gulia et al. (2019, [2020](#page-17-6)). This study therefore does not address any potential issues of selection bias within the original data set. I also do not revisit postmainshock *b*-value increases (Gulia et al., [2018\)](#page-17-1), as *b*-value increases are in the opposite direction of the expected bias, and there is no reason to doubt those *b*-value measurements.

# **5. Conclusion**

I have presented a new estimator for the b-value of the magnitude-frequency distribution, based on the differences between successive earthquake magnitudes. The *b*-positive (*β<sup>+</sup>*) estimator gives robust measurements of the time-varying *b*-value during the most active periods of an aftershock sequence, where the completeness magnitude can vary wildly. As such, it can provide an early assessment of whether *b*-value has changed substantially after a large earthquake. The *β<sup>+</sup>* estimator can also simplify the measurement of *b*-value in historical catalogs with time-varying completeness due to evolving seismic network configuration.

The results presented here support the idea that the *b*-value may communicate statistical or other information about the likelihood of larger aftershocks within a sequence. However, the improved measurement technique shows a more muted response of the *b*-value in the sequences analyzed by Gulia & Wiemer ([2019](#page-17-2)). This is especially true for the purported drop in *b*-value after the foreshocks, which is affected by incompleteness bias and substantially overestimated in the previous work.

VAN DER ELST 14 of 19

![](_page_14_Figure_3.jpeg)

<span id="page-14-0"></span>**Figure 12.** (a–c) Tohoku *b*-value as a function of ranked time as computed by the three methods. Gray bars show where M7 or greater earthquakes are included in the 200-event sliding window. (d) Magnitudes versus time and timevarying magnitude of completeness.

While the observation of diminished *b*-value at the time of some foreshocks cannot be dismissed as simple measurement error, this study does not resolve whether the traffic light system (Gulia & Wiemer, [2019\)](#page-17-2) could be made operational. Considerable art is required in reading the time-series of *b*-value changes for the selected sequences, and the purported signals are on the same scale as random fluctuations within the time-series.

Gulia and Wiemer ([2019\)](#page-17-2) attribute the *b*-value changes to precursory stress changes, with the stress being increased by the foreshock, and relaxed by the final mainshock. The increased postseismic *b*-value within the mainshock rupture zone is consistent with other observations of a truncation in the magnitude distribution within previous ruptures. (A truncation in the magnitude distribution is mapped to an increase in the maximum likelihood estimate of the *b*-value in the classical GR formula) The truncation has been attributed to the "sweeping away" of potential large nucleation sites from the previous rupture plane (van der Elst & Shaw, [2015\)](#page-18-7), or to expenditure of the elastic stress budget in the surrounding rock (Stallone & Marzocchi, [2019](#page-18-8)).

<span id="page-14-1"></span>**Table 2** *Summary of Windowed B-Values Determined by the β+ Estimator*

| Sequence                | Before foreshock | Between fore- and mainshock | At time of mainshock | After mainshock |
|-------------------------|------------------|-----------------------------|----------------------|-----------------|
| Ridgecrest              | 0.89 ± 0.02      | 0.83 ± 0.03                 | 0.98 ± 0.08          | 0.95 ± 0.01     |
| Ridgecrest (restricted) | 0.88 ± 0.11      | 0.81 ± 0.04                 | 0.85 ± 0.07          | 1.02 ± 0.02     |
| Amatrice                | 1.26 ± 0.05      | 0.97 ± 0.02                 | 1.08 ± 0.10          | 1.12 ± 0.02     |
| Kumamoto                | 0.81 ± 0.03      | 0.65 ± 0.04                 | 0.68 ± 0.06          | 0.84 ± 0.02     |
| Tohoku                  | 0.68 ± 0.02      | 0.54 ± 0.05                 | 0.58 ± 0.07          | 0.83 ± 0.03     |

VAN DER ELST 15 of 19

21699356, 2021, 2, Downloaded from https://agupubs.onlinelibrary.wiley.com/doi/10.1029/2020/1B021027, Wiley Online Library on [21/10/2025]. See the Terms and Conditions (https://onlinelibrary.wiley.

and-conditions) on Wiley Online Library for rules of use; OA articles

![](_page_15_Figure_3.jpeg)

<span id="page-15-1"></span>**Figure 13.** Clockwise: (a) Map of the 2011 off-Tohoku sequence. Events in gray occurred prior to the M7.3 foreshock, events in red occurred between the foreshock and the M9.1 mainshock, and those in green occurred after the mainshock. (b) Magnitude distributions and GR *b*-value estimates. Minimum magnitude/difference cutoffs are marked by the vertical dashed lines. (c) Magnitude difference distributions and *b*-positive estimates. (d) Distribution of running window *b*-values from Figure 12. The red vertical line shows the *b*-value estimate and 1–sigma uncertainty at the time of occurrence of the mainshock. GR, Gutenberg-Richter.

Alternatively, the *b*-value could be merely a probabilistic precursor, where the decrease in *b*-value reflects activation (via stress transfer and triggering) of a region of crust with a higher than average propensity to generate large earthquakes. Whether this propensity is related to stress levels, fault rheology, or fault zone structure is important from an earthquake physics perspective but may not ultimately matter for the purposes of forecasting if the statistics speak for themselves.

# <span id="page-15-0"></span>**Appendix A: The Discrete Laplace Distribution**

The derivation of the Laplace Distribution from an exponential distribution can be easily found in the literature. The discrete Laplace distribution is less commonly discussed, so I derive it here. The discrete Laplace distribution is used when dealing with rounded magnitudes. For magnitude increments larger than 0.1, this bias can be significant.

Start with the discrete Exponential (GR) distribution, discretized in intervals of  $2\delta$ .

$$P_{M}(m \mid \beta) = c \int_{m-\delta}^{m+\delta} \beta e^{-\beta \mu} d\mu, \tag{A1}$$

The constant c is obtained by normalizing the sum of the probabilities over all magnitudes  $m = M_c + 2n\delta$  where  $n = 0,1,...,\infty$ . This gives the probability mass function

$$P_M(m \mid \beta) = 2\sinh(\beta\delta)e^{-\beta(m-M_c+\delta)},$$
(A2)

<span id="page-15-2"></span>The maximum likelihood estimate of  $\beta$  for the Exponential distribution is

VAN DER ELST 16 of 19

wiley.com/doi/10.1029/2020JB021027, Wiley Online Library on [21/10/2025]. See the Terms

$$\tilde{\beta} = \frac{1}{\delta} \coth^{-1} \left[ \frac{1}{\delta} (\bar{m} - M_c + \delta) \right], \tag{A3}$$

<span id="page-16-5"></span>The distribution of the differences (Laplace distribution) can be derived from the joint distribution of two independent random magnitudes  $m_1$ ,  $m_2$ , each with probability mass function given by Equation A2. Start with the case where  $m' = m_2 - m_1 \ge 0$ .

$$P_{M'}(m_1, m') = cP_{M_1}(m_1)P_{M_2}(m_1 + m'), m' \ge 0$$
(A4)

$$P_{M'}(m_1, m') = 4\sinh^2(\beta\delta)e^{-\beta(m_1 - M_c + \delta)}e^{-\beta(m_1 + m' - M_c + \delta)}$$
(A5)

<span id="page-16-0"></span>Now sum over all discrete values of  $m_1$  from  $M_c$  to infinity to get the marginal distribution with respect to m', or recognize that the probability mass must add up to unity, and save the summation for later. Equation A5 simplifies to

$$P_{M'}(m') = ce^{-\beta m'}, m' \ge 0$$
 (A6)

<span id="page-16-1"></span>where c is a constant to be determined below.

For the case where  $m' = m_2 - m_1 \le 0$ , flip the sign of m' and sum over  $m_2$  to recover the same distribution as in Equation A6, suggesting the complete distribution

$$P_{M'}(m') = ce^{-\beta|m'|},\tag{A7}$$

<span id="page-16-2"></span>To find the constant c, normalize Equation A7 such that the sum over all m' is equal to unity

$$\sum P(m') = c \sum_{n} e^{-\beta(2n\delta)} = 1, n = -\infty, \dots, -1, 0, 1, \dots, \infty$$
 (A8)

Taking care not to count n = 0 twice, this simplifies to

$$\sum P(m') = c \left( 2 \sum_{n=0}^{\infty} e^{-\beta(2n\delta)} - 1 \right) = 1.$$
 (A9)

<span id="page-16-3"></span>The geometric series in Equation A9 reduces to

$$\sum P(m') = c \left( \frac{2e^{2\beta\delta}}{e^{2\beta\delta} - 1} - 1 \right) = c \left( \frac{e^{\beta\delta} + e^{-\beta\delta}}{e^{\beta\delta} - e^{-\beta\delta}} \right) = 1, \tag{A10}$$

<span id="page-16-4"></span>and rearranging for c:

$$c = \tanh(\beta \delta) \tag{A11}$$

Finally, inserting Equation A11 back into Equation A7 gives

$$P_{M'}(m' \mid \beta) = \tanh(\beta \delta) e^{-\beta |m'|}, \tag{A12}$$

It follows that the maximum likelihood estimate of  $\beta$  for the discrete Laplace distribution is

$$\tilde{\beta} = \frac{1}{2\delta} c \operatorname{sch}^{-1} \left( \frac{1}{2\delta} \overline{|m'|} \right), \tag{A13}$$

which reduces to Equation 4 (main text) as  $\delta \rightarrow 0$ .

Incompleteness affects the Laplace distribution just as it does the GR distribution. Numerical analysis shows that the effect is strongest at small magnitude differences, and a robust estimate of  $\beta$  obtains above

VAN DER ELST 17 of 19

21699356, 2021, 2, Downloaded from https://agupubs.onlinelibrary.wiley.com/doi/10.1029/2020JB021027, Wiley Online Library on [21/10/2023]. See the Terms and Conditions (https://onlin

ind-conditions) on Wiley Online Library for rules of use; OA articles

some minimum magnitude difference. The incomplete Laplace estimator is obtained by changing the range of the sum in the normalization step (A8).

To estimate  $\beta$  only for  $|m'| \ge M_c$ , normalize over the more limited support. For  $M_c \ge 2\delta$ , the summation is

$$\sum P(m') = 2c \sum_{n=0}^{\infty} e^{-\beta \left(M'_C + 2n\delta\right)} = 1. \tag{A14}$$

Carrying out the sum, rearranging for c, and simplifying,

$$c = \sinh(\beta \delta) e^{-\beta \left(-M_c' + \delta\right)}$$
(A15)

and inserting into (A7),

$$P_{M'}(m') = \sinh(\beta \delta) e^{-\beta \left( |m'| - M_C' + \delta \right)}. \tag{A16}$$

<span id="page-17-16"></span>Expressed in terms of the absolute value,

$$P_{|M'|}(|m'|) = 2\sinh(\beta\delta)e^{-\beta(|m'|-M'_c+\delta)}.$$
(A17)

Equation A17 is identical to the incomplete GR distribution (A2). The maximum likelihood Laplace estimator for  $\beta$  is therefore given by Equation A3.

Uncertainties for the discrete distributions are calculated via bootstrap.

# **Data Availability Statement**

Earthquake catalog data are taken from the USGS Comprehensive Catalog (https://earthquake.usgs.gov/earthquakes/search/), last accessed May 2020.

#### Acknowledgments

This manuscript benefited from reviews by Andrew Michael, David Shelly, Laura Gulia, and an anonymous reviewer.

# References

<span id="page-17-8"></span>Abramowitz, M., & Stegun, I. A. (1972). Handbook of mathematical functions with formulas, graphs, and mathematical tables (p. 930). New York, NY: Dover.

<span id="page-17-9"></span>Aki, K. (1965). Maximum likelihood estimate of b in the Formula log N = a - bM and its confidence limits. Bulletin of the Earthquake Research Institute, 43, 237–239.

<span id="page-17-0"></span>Amitrano, D. (2003). Brittle-ductile transition and associated seismicity: Experimental and numerical studies and relationship with the b value. *Journal of Geophysical Research*, 108(B1), e000680. https://doi.org/10.1029/2001JB000680

<span id="page-17-15"></span>Bürgmann, R., Uchida, N., Hu, Y., & Matsuzawa, T. (2016). Tohoku rupture reloaded? Nature Geoscience, 9(3), 183-184.

<span id="page-17-14"></span>Dascher-Cousineau, K., Lay, T., & Brodsky, E. E. (2020). Two foreshock sequences post Gulia and Wiemer. Seismological Research Letters, 91(5), 2843–2850. https://doi.org/10.1785/0220200082

<span id="page-17-1"></span>Gulia, L., Rinaldi, A. P., Tormann, T., Vannucci, G., Enescu, B., & Wiemer, S. (2018). The effect of a mainshock on the size distribution of the aftershocks. *Geophysical Research Letters*, 45(24), 13–277. https://doi.org/10.1029/2018GL080619

<span id="page-17-2"></span>Gulia, L., & Wiemer, S. (2019). Real-time discrimination of earthquake foreshocks and aftershocks. *Nature*, 574(7777), 193–199. https://doi.org/10.1038/s41586-019-1606-4

<span id="page-17-6"></span>Gulia, L., Wiemer, S., & Vannucci, G. (2020). Pseudoprospective evaluation of the foreshock traffic-light system in ridgecrest and implications for aftershock hazard assessment. Seismological Research Letters, 91(5), 2828–2842.

<span id="page-17-11"></span><span id="page-17-7"></span>Gutenberg, B., & Richter, C. F. (1944). Frequency of earthquakes in California. *Bulletin of the Seismological Society of America*, 4, 185–188. Hainzl, S. (2016). Apparent triggering function of aftershocks resulting from rate-dependent incompleteness of earthquake catalogs. *Journal of Geophysical Research: Solid Earth*, 121(9), 6499–6509. https://doi.org/10.1002/2016JB013319

<span id="page-17-13"></span>Hardebeck, J. L., Felzer, K. R., & Michael, A. J. (2008). Improved tests reveal that the accelerating moment release hypothesis is statistically insignificant. *Journal of Geophysical Research*, 113(B8), B08310. https://doi.org/10.1029/2007jb005410

<span id="page-17-3"></span>Helmstetter, A., Kagan, Y. Y., & Jackson, D. D. (2006). Comparison of short-term and time-independent earthquake forecast models for southern California. *Bulletin of the Seismological Society of America*, 96(1), 90–106.

<span id="page-17-4"></span>Kagan, Y. Y. (2004). Short-term properties of earthquake catalogs and models of earthquake source. *Bulletin of the Seismological Society of America*, 94(4), 1207–1228.

<span id="page-17-5"></span>Knopoff, L., Kagan, Y. Y., & Knopoff, R. (1982). b-values for foreshocks and aftershocks in real and simulated earthquake sequences. Bulletin of the Seismological Society of America, 72(5), 1663–1676.

<span id="page-17-12"></span>Ogata, Y. (1998). Space-time point-process models for earthquake occurrences. Annals of the Institute of Statistical Mathematics, 50(2), 379–402.

<span id="page-17-10"></span>Ogata, Y., & Katsura, K. (1993). Analysis of temporal and spatial heterogeneity of magnitude frequency distribution inferred from earth-quake catalogues. *Geophysical Journal International*, 113(3), 727–738.

VAN DER ELST 18 of 19

![](_page_18_Picture_1.jpeg)

# **Journal of Geophysical Research: Solid Earth**

- 10.1029/2020JB021027
- <span id="page-18-4"></span>Ogata, Y., & Katsura, K. (2006). Immediate and updated forecasting of aftershock hazard. *Geophysical Research Letters*, *33*(10), e025888. <https://doi.org/10.1029/2006GL025888>
- <span id="page-18-5"></span>Ross, E. Z., Idini, B., Jia, Z., Stephenson, O. L., Zhong, M., Wang, X., et al. (2019). Hierarchical interlocked orthogonal faulting in the 2019 Ridgecrest earthquake sequence. *Science*, *366*, 346–351.
- <span id="page-18-0"></span>Scholz, C. H. (2015). On the stress dependence of the earthquake b value. *Geophysical Research Letters*, *42*(5), 1399–1402. [https://doi.](https://doi.org/10.1002/2014GL062863) [org/10.1002/2014GL062863](https://doi.org/10.1002/2014GL062863)
- <span id="page-18-1"></span>Schorlemmer, D., Wiemer, S., & Wyss, M. (2005). Variations in earthquake-size distribution across different stress regimes. *Nature*, *437*(7058), 539–542.
- <span id="page-18-2"></span>Spada, M., Tormann, T., Wiemer, S., & Enescu, B. (2013). Generic dependence of the frequency-size distribution of earthquakes on depth and its relation to the strength profile of the crust. *Geophysical Research Letters*, *40*(4), 709–714.<https://doi.org/10.1029/2012GL054198> Stallone, A., & Marzocchi, W. (2019). Empirical evaluation of the magnitude-independence assumption. *Geophysical Journal Internation-*
- <span id="page-18-8"></span><span id="page-18-6"></span>*al*, *216*(2), 820–839. Tormann, T., Enescu, B., Woessner, J., & Wiemer, S. (2015). Randomness of megathrust earthquakes implied by rapid stress recovery after the Japan earthquake. *Nature Geoscience*, *8*(2), 152–158.
- <span id="page-18-7"></span>van der Elst, N. J., & Shaw, B. E. (2015). Larger aftershocks happen farther away: Nonseparability of magnitude and spatial distributions of aftershocks. *Geophysical Research Letters*, *42*(14), 5771–5778.<https://doi.org/10.1002/2015GL064734>
- <span id="page-18-3"></span>Woessner, J., & Wiemer, S. (2005). Assessing the quality of earthquake catalogues: Estimating the magnitude of completeness and its uncertainty. *Bulletin of the Seismological Society of America*, *95*(2), 684–698.

VAN DER ELST 19 of 19