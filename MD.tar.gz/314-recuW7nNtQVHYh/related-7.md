# One-Dimensional Quantum Liquids: Beyond the Luttinger Liquid Paradigm

Adilet Imambekov

Department of Physics and Astronomy, Rice University, Houston, TX, 77005, USA

Thomas L. Schmidt<sup>∗</sup> and Leonid I. Glazman†

Department of Physics, Yale University, New Haven, Connecticut 06520, USA

(Dated: November 27, 2024)

For many years, the Luttinger liquid theory has served as a useful paradigm for the description of one-dimensional (1D) quantum fluids in the limit of low energies. This theory is based on a linearization of the dispersion relation of the particles constituting the fluid. We review the recent progress in understanding 1D quantum fluids beyond the low-energy limit, where the nonlinearity of the dispersion relation becomes essential. The novel methods which have been developed to tackle such systems combine phenomenology built on the ideas of the Fermi edge singularity and the Fermi liquid theory, perturbation theory in the interaction strength, and new ways of treating finitesize properties of integrable models. These methods can be applied to a wide variety of 1D fluids, from 1D spin liquids to electrons in quantum wires to cold atoms confined by 1D traps. We review existing results for various dynamic correlation functions, in particular the dynamic structure factor and the spectral function. Moreover, we show how a dispersion nonlinearity leads to finite particle lifetimes, and its impact on the transport properties of 1D systems at finite temperatures is discussed. The conventional Luttinger liquid theory is a special limit of the new theory, and we explain the relation between the two.

#### CONTENTS

| I. INTRODUCTION                           |                                                       |          |  |
|-------------------------------------------|-------------------------------------------------------|----------|--|
| II. SINGULARITIES OF THE DYNAMIC RESPONSE |                                                       |          |  |
| FUNCTIONS                                 |                                                       |          |  |
|                                           | A. Perturbative treatment of interactions             | 4<br>7   |  |
|                                           | 1. Dynamic structure factor (DSF)                     | 7        |  |
|                                           | 2. Spectral function                                  | 10       |  |
|                                           | B. The universal limit of nonlinear Luttinger liquids | 12       |  |
|                                           | C. Phenomenology beyond the low-energy limit: the     |          |  |
|                                           | mobile quantum impurity model                         | 17       |  |
|                                           | D. Phenomenology of spin liquids                      | 20       |  |
|                                           | 1. XY model at zero magnetic field                    | 22       |  |
|                                           | 2. Generic spin chains at zero magnetic field         | 23       |  |
|                                           | 3. Generic spin chains at finite magnetic field       | 24       |  |
|                                           | E. Bosonic systems with or without spin               | 25       |  |
|                                           | F. Fermionic systems with spin                        | 26       |  |
|                                           | G. Finite-size and finite-temperature effects         | 31       |  |
|                                           | H. Real-space correlation functions                   | 33       |  |
| III. EXACTLY SOLVABLE MODELS              |                                                       |          |  |
|                                           | A. Calogero-Sutherland model                          | 35<br>35 |  |
|                                           | B. Lieb-Liniger model                                 | 37       |  |
|                                           | C. Yang-Gaudin models                                 | 40       |  |
|                                           | D. Lattice models: XXZ, spinless fermions and 1D      |          |  |
|                                           | Hubbard model                                         | 41       |  |

|  | IV. KINETICS OF AND TRANSPORT IN A NONLINEAR          |    |
|--|-------------------------------------------------------|----|
|  | LUTTINGER LIQUID                                      | 42 |
|  | A. Relaxation processes of excitations in a nonlinear |    |
|  |                                                       |    |

|                |                 |  | Luttinger liquid                                        | 43 |  |  |  |
|----------------|-----------------|--|---------------------------------------------------------|----|--|--|--|
|                |                 |  | 1. Weakly interacting fermions                          | 43 |  |  |  |
|                |                 |  | 2. Spinful fermions at arbitrary interaction strength:  |    |  |  |  |
|                |                 |  | holon lifetimes                                         | 47 |  |  |  |
|                |                 |  | 3. Relaxation of excitations in a weakly interacting 1D |    |  |  |  |
|                |                 |  | Bose gas                                                | 49 |  |  |  |
|                |                 |  | B. Conductivity and Drude weight for interacting        |    |  |  |  |
|                |                 |  | particles                                               | 51 |  |  |  |
|                |                 |  | C. Conductance of interacting fermions in 1D            | 52 |  |  |  |
|                |                 |  |                                                         |    |  |  |  |
| V. CONCLUSIONS |                 |  |                                                         | 54 |  |  |  |
|                | Acknowledgments |  |                                                         |    |  |  |  |
|                |                 |  |                                                         |    |  |  |  |
|                |                 |  |                                                         |    |  |  |  |
|                | References      |  |                                                         |    |  |  |  |

# I. INTRODUCTION

The conventional description of the low-energy properties of quantum condensed matter uses the notion of quasiparticles: elementary excitations behaving as free quantum particles with some energy spectrum which depends on the microscopic interactions. The low-energy properties of interacting electrons in normal metals, for example, are well represented by the theory of a Fermi liquid (Nozieres, 1997). Its elementary excitations are similar to free fermions. One may view the quasiparticle

<sup>∗</sup> thomas@thoschmidt.de

<sup>†</sup> leonid.glazman@yale.edu

states as those evolving from free fermions when adiabatically turning on the interactions.

Quasiparticle states are labeled by their momenta, but their dispersion relation (i.e., the quasiparticle energy ξ measured from the Fermi level as a function of the momentum k) differs from the one for free fermions. These states combine the best of the two worlds – on the one hand, their overlap with free fermions is significant. On the other hand, their lifetimes τ become infinitely long as their energy ξ vanishes: in the absence of static disorder, τ ∝ ξ −2 . An electron easily tunnels into a metal, "dressing up" in the tunneling process to become a quasiparticle. Neglecting the small relaxation rate 1/τ , an electron entering a Fermi liquid with momentum k creates a single quasiparticle with a well-defined energy ξ(k). In an inverse process, an electron may tunnel out, leaving behind a hole with well-defined energy. In either case, the tunneling probability per unit time of an electron with given momentum k and energy ε or, more precisely, its spectral function A(k, ε) is close to a delta-function, A(k, ε) ∝ δ(ε − ξ(k)). Residual interactions between the quasiparticles can be readily accounted for within conventional perturbation theory. A perturbative evaluation of the quasiparticle's self-energy leads to a finite relaxation rate 1/τ and to a slight broadening of the spectral function, transforming it into a Lorentzian with a width δε ∼ 1/τ .

If the momentum is not conserved in the tunneling event (this happens, for example, if the electron tunnels through a point contact), then the electron extracted from the Fermi liquid leaves behind a superposition of holes, each of them having the same energy ε. The area of the constant-energy surface in momentum space defined by the equation ξ(k) = ε determines the density of states ν(ε) ∝ R dkA(k, ε) available for tunneling (Nozieres, 1997) at energy ε. Similar to the case of free fermions, the tunneling density of states at the Fermi level ν(0) in the Fermi liquid is finite.

One can find a more subtle example of a quasiparticle description in the Bogoliubov treatment of the excitations of a Bose gas with weak inter-particle repulsion (Pitaevskii and Stringari, 2003). Bogoliubov quasiparticles are the bosonic excitations above the Bose condensate; their spectrum differs qualitatively from the spectrum of "bare" bosons: due to the interaction between the "bare" particles, the Bogoliubov quasiparticles are characterized by a sound-like spectrum, ξ(k) ∝ k, at low energies. Still, a particle entering the system of interacting bosons easily "dresses up" to become a quasiparticle. The spectral function A(k, ε) of a boson with momentum k is close to a delta-function centered at energy ε = ξ(k). At small energies, the lifetime of a Bogoliubov quasiparticle (Beliaev, 1958) with energy ξ diverges as τ ∝ 1/ξ<sup>5</sup> , making the quasiparticle states well-defined. The rate 1/τ determines the broadening of the spectral function.

In the above examples, the affinity between the free particle and an elementary excitation of the many-body system is exemplified by the narrow energy width of the spectral function A(k, ε): the spectral weight is concentrated around the quasiparticle energy ε = ξ(k) within a region δε ξ(k). While working well in higher dimensions, this picture fails in the case of a one-dimensional (1D) gas of quantum particles. This is clearly visible, e.g., for 1D fermions in the presence of even a weak interaction between them. The correction to the fermionic spectral function to the second (lowest nonvanishing) order in the interaction potential decays as 1/[ε − ξ(k)] (Dzyaloshinskii and Larkin, 1974), transferring the spectral weight away from the quasiparticle mass shell ε = ξ(k). Along with the slow decay of the spectral function, the second-order corrections to the tunneling density of states ν(ε) at ε = 0 and to the momentum distribution function n(k) ∝ R 0 −∞ dεA(k, ε) at the Fermi points k = ±k<sup>F</sup> , are singular.

The "magic bullet" effective in resolving many of the difficulties of the 1D quantum many-body problem was suggested in a seminal paper by Tomonaga (Tomonaga, 1950). It was noticed there that replacing the generic dispersion relation ξ(k) of 1D fermions with a linear one, ξ(k) = ±v<sup>F</sup> (k ∓ k<sup>F</sup> ), immensely simplifies finding the many-body dynamics of the system (here the upper/lower signs correspond to the right-/left-moving particles, and k<sup>F</sup> is the Fermi momentum). For free fermions with a linear spectrum, the energy E of a right-moving excitation consisting of an arbitrary number of particlehole pairs with a given total momentum q depends only on that total momentum, E = v<sup>F</sup> q. This degeneracy allowed Tomonaga to encode the excitations of the Fermi gas (at fixed numbers of left- and right-movers) into the excitation spectrum of free bosons. These 1D bosons are nothing but quantized waves of density of a 1D Fermi gas, and their description is identical to that of acoustic phonons (Ziman, 1960). The beauty of the encoding is that it puts the free-fermion Hamiltonian and densitydensity interactions on an equal footing. Indeed, the full Hamiltonian of interacting 1D fermions now becomes a bilinear form in bosonic creation-annihilation operators. Its diagonalization is standard and not different from the corresponding procedure for phonons (Ziman, 1960). This way, the Hamiltonian for interacting 1D fermions with linear spectrum is diagonalized and cast in terms of free bosons with linear dispersion relation, ω(q) = v|q| (we use units ~ = 1 throughout the text); the velocity v differs from v<sup>F</sup> because of the interactions.

The bosonic representation introduced by Tomonaga makes the calculation of the density correlation function of 1D fermions straightforward. Indeed, the density fluctuation operator ρ(x, t) is linear in boson creation/annihilation operators. According to the diagonalized form of the Hamiltonian, those represent excitations which propagate freely with a constant velocity v. This is reflected in the dynamic structure factor (DSF), which is defined as the probability per unit time to excite a density fluctuation by an external source coupled to  $\rho$ . The DSF takes the form  $S(q,\omega) \propto |q|\delta(\omega-v|q|)$ .

The evaluation of the propagator of a fermion, its spectral function  $A(k,\varepsilon)$ , the tunneling density of states  $\nu(\varepsilon)$ , or the distribution function n(k) is somewhat more complicated. Luttinger (1963) attempted to evaluate the distribution function using the fermionic representation; some aspects of that calculation were clarified later by Mattis and Lieb (1965). The spin-1/2 fermion propagator G(x,t) in space and time domain was evaluated for the Tomonaga-Luttinger model by Dzyaloshinskii and Larkin (1974). Their diagrammatic technique heavily relied on the linear dispersion relation of fermions. Luther and Peschel (1974) evaluated G(x,t) with the help of the bosonic representation of the Tomonaga-Luttinger model (Luther and Peschel, 1974; Mattis, 1974), and also showed that the tunneling density of states  $\nu(\varepsilon)$  displays a power-law behavior at energies  $\varepsilon$  much smaller that the Fermi energy. Similar techniques have been used to calculate the long-distance behavior of correlation functions for 1D bosonic systems (Efetov and Larkin, 1975).

At low energies, the excitations of noninteracting fermions are particles and holes with momenta k in the vicinity of  $\pm k_F$ . The energy of, say, a right-mover is  $\xi(k) = v_F(k - k_F) + (k - k_F)^2/(2m^*)$ . The second term here may be considered as the lowest-order expansion of a general nonlinearity of the dispersion relation (in case of particle-hole symmetry, such an expansion would start from the cubic  $(k-k_F)^3$  term). For noninteracting fermions with Galilean-invariant spectrum,  $m^*$ is equal to the bare mass. The quadratic term here scales as  $\xi^2/(m^*v_F^2)$  at small  $\xi$ : by a power-counting argument, this term is irrelevant. Indeed, it has been shown by Haldane (1981b) that the spectrum nonlinearity does not significantly affect the long-range behavior of the fermion propagator G(x,0) at fixed time (t=0). That gives an incentive to dispense with the nonlinearity of the dispersion relation. After that, a wide variety of 1D systems with gapless excitation spectra can be mapped, at low energies, on the Tomonaga-Luttinger model. Thus, the Tomonaga-Luttinger model provided the foundation for the concept of the Luttinger liquid (LL), a phenomenological description of the low-energy excitations of interacting quantum particles confined to 1D (Haldane, 1981a,b). In addition to liquids of fermions or bosons, these include also the low-energy excitations of half-integer spin chains, i.e., spin liquids (Haldane, 1980).

After a real system is replaced by the corresponding LL, the "good" low-energy excitations appear to be waves of density of the corresponding liquid which have a linear spectrum  $\omega(q) = v|q|$ . These excitations propagate along the x-axis with fixed velocities  $\pm v$  and without any dispersion: a perturbation created at some point x propagates without changing its shape to the points  $x \pm vt$ . The

presence of the formally irrelevant term  $(k-k_F)^2/(2m^*)$  in the spectrum results in a dispersion of the propagating perturbation. In analogy with single-particle quantum mechanics, the width of the perturbation grows with time  $\propto \sqrt{t/m^*}$ . The irrelevance of the quadratic term in  $\xi(k)$  means that the growth is slow compared to the rate of linear displacement of the perturbation:  $\sqrt{t/m^*}/(vt) \to 0$  at  $t \to \infty$ . The infinitely "sharp" DSF of the Tomonaga-Luttinger model,  $S(q,\omega) \propto |q|\delta(\omega-v|q|)$ , reflects the propagation of the density perturbation with fixed velocities  $\pm v$ . The  $\propto \sqrt{t/m^*}$  dispersion of the perturbation corresponds to some kind of broadening of the DSF: at given  $|q| \approx \omega/v$  the characteristic width of the DSF is  $\delta\omega \sim \omega^2/(m^*v^2)$ .

It may look like the designation of density waves in 1D as the proper excitations parallels the Fermi-liquid idea in higher dimensions. Indeed, dispensing with irrelevant perturbations in these two systems, one finds a deltafunction structure of  $S(q,\omega)$  for 1D bosons and similarly of  $A(\mathbf{k}, \varepsilon)$  for Fermi quasiparticles in higher dimensions. From a dimensional analysis, one expects the irrelevant terms to broaden these delta-functions by  $\propto \omega^2$  and  $\varepsilon^2$ , respectively, at given q and k. However, the similarity stops there. In a Fermi liquid, irrelevant interactions lead to a self-energy with small imaginary part in the quasiparticle Green function, which transforms  $A(\mathbf{k}, \varepsilon)$  to a Lorentzian. The self-energy can then be evaluated within perturbation theory in the irrelevant terms (Abrikosov et al., 1963). In contrast, a naïve attempt to use perturbation theory to evaluate the self-energy of bosons and thus "broaden up"  $S(q,\omega)$  in the LL is doomed (Andreev, 1980; Pirooznia and Kopietz, 2007; Punk and Zwerger, 2006; Samokhin, 1998). The symmetry (in fact, Lorentzinvariance) introduced by the linearization results in a degeneracy of the excitation spectrum. The terms describing the curvature of the dispersion relation break that symmetry. The very same simplification which allowed Tomonaga (1950) to find the exact solution of the problem makes the perturbation theory in the curvature strongly degenerate. The nominally irrelevant terms remove the degeneracy, lead to the emergence of new qualitative behavior of the dynamic correlation functions, and to relaxation processes which do not exist in the linear LL.

The perturbation theory in curvature is plagued by onshell divergencies, and is in need of a proper resummation procedure, yet to be developed (Aristov, 2007; Samokhin, 1998). A possible way of building a perturbation theory in boson representation may involve studying the responses in an off-shell domain and comparing the results to the known limits, such as the free fermions (Pereira et al., 2007; Pereira et al., 2006; Teber, 2006, 2007).

A progress, however, was achieved along a different route, via linking the properties of a nonlinear LL to the well-known Fermi edge singularity effect (Mahan, 1981; Nozières and De Dominicis, 1969; Ohtaka and Tanabe, 1990). That connection was quite easy to notice for weakly-interacting fermions with a generic (nonlinear) spectrum (Pustilnik et al., 2006). Further development of that relation put the problem of edge singularities in a nonlinear LL into the class of so-called "quantum impurity" models (Affleck, 2009; Balents, 2000; Castella and Zotos, 1993; Castro Neto and Caldeira, 1994; Castro Neto and Fisher, 1996; Cheianov and Pustilnik, 2008; Imambekov and Glazman, 2008, 2009a,b; Khodas et al., 2007a,b; Lamacraft, 2008, 2009; Pereira and Sela, 2010; Pereira et al., 2008, 2009; Schmidt et al., 2010a,b; Sorella and Parola, 1996; Tsukamoto et al., 1998; Zvonarev et al., 2009a,b).

The use of the field-theoretical approach based on quantum impurity models has led eventually to a new phenomenological theory of nonlinear LLs. Remarkably, the threshold power-law singularities in the dynamic responses [S(q, ω) and A(k, ε) are the examples] occur not only in the vicinity of special points (k = ±k<sup>F</sup> for the spectral function), but at arbitrary momenta. The nonlinear LL phenomenology relates the exponents characterizing the singularities to the properties of the threshold spectra, thus establishing a relation between two sets of independently measurable quantities.

The phenomenology also provides effective tools for the evaluation of the exponents characterizing the dynamic responses: one may find first the energy spectra and then use the phenomenological relations to find the exponents. A class of systems for which such a program is especially attractive are the models exactly solvable by the Bethe ansatz. The thermodynamic Bethe ansatz is well suited for the evaluation of the spectra but not for the dynamic responses. However, the corresponding exponents can be found exactly by combining the thermodynamic Bethe ansatz with a field-theoretical description (Cheianov and Pustilnik, 2008; Essler, 2010; Imambekov and Glazman, 2008; Pereira et al., 2008, 2009). Exactly solvable models provide stringent nontrivial tests of the field-theoretical approaches.

The linear LL theory does not discriminate between integrable and generic 1D systems: in either case, the original system is replaced by free particles devoid of any relaxation mechanisms. Methods emerging within the nonlinear theory pave a way of studying the kinetics of a 1D quantum liquid and see the differences between generic and integrable systems.

In summary, understanding 1D quantum liquids outside the sector of low-energy excitations requires breaking the spell of linearization. The emerging theory, which accounts for the nonlinear energy spectrum of particles forming the liquid, answers that challenge. We review a number of methods of the nonlinear LL theory and expose relations between them. These methods have already led to a progress in understanding the dynamic responses and relaxation of 1D quantum liquids. The approaches we describe are controllable, yet versatile enough for application to a broad class of systems, from electrons in quantum wires (Deshpande et al., 2010), to spin liquids and cold atoms confined to 1D.

This review is organized as follows. In Sec. II, we introduce and develop in detail the general field-theoretical approach to describe the singularities of dynamic response functions in the momentum-energy plane. That approach is based on the phenomenology of effective mobile impurities moving in LLs. In Sec. III we combine this field-theoretical approach with the analysis of exactly solvable models, which allows one to obtain a plethora of new results for the latter, and provides stringent nonperturbative checks of the phenomenological approaches. In Sec. IV, we illustrate the importance of the physics beyond the linear LL theory for the kinetics and the transport in 1D quantum liquids.

# II. SINGULARITIES OF THE DYNAMIC RESPONSE FUNCTIONS

An adequate description of a quantum many-body system not only requires an understanding of the ground state, but also a characterization of its excitations. One of the most natural ways to probe the excitation spectrum is to measure the dynamic responses of the system to external fields, such as electromagnetic radiation of a given momentum and energy. Within Fermi's golden rule, the scattering rate of such external fields is related to various dynamic response functions, such as the DSF or the spectral function (see precise definitions below). This motivates the interest in studying qualitative features of the dynamic response functions of low-dimensional systems. In particular, we will mostly be interested in their behavior near the spectrum of elementary excitations. Many experimental techniques can be applied to probe the dynamic responses of 1D systems, such as neutron scattering (Lake et al., 2005, 2010; Masuda et al., 2006; Nagler et al., 1991; R¨uegg et al., 2005; Stone et al., 2003; Tennant, 2009; Thielemann et al., 2009; Zheludev et al., 2008, 2002), angle resolved photoemission spectroscopy (ARPES) (Blumenstein et al., 2011; Claessen et al., 2002; Hoinkis et al., 2005; Kim et al., 2006; Kondo et al., 2010; Sing et al., 2003; Wang et al., 2009, 2006), and various forms of Bragg spectroscopy (Cl´ement et al., 2009; Ernst et al., 2010; Fabbri et al., 2009; Stamper-Kurn et al., 1999) and photoemission spectroscopy (Dao et al., 2007; Gaebler et al., 2010; Stewart et al., 2008). Additional interest in the response functions of 1D systems is driven by a rapid progress in their numerical evaluation (Barthel et al., 2009; Feiguin and Huse, 2009; Kohno, 2010; Kokalj and Prelovsek, 2009; White and Affleck, 2008) based on time-dependent extensions of Density Matrix Renormalization Group (DMRG) techniques (De Chiara et al., 2008; Schollw¨ock, 2005; Vidal, 2003, 2004; White, 1992).

A nonlinear dispersion relation and interactions between particles forming a 1D quantum liquid modify in a nontrivial way all dynamical responses of the liquid, resolved in energies and momenta. The DSF provides one of the examples. It is defined as

$$S(q,\omega) = \int_{-\infty}^{\infty} dt \int_{-\infty}^{\infty} dx e^{i(\omega t - qx)} \langle \rho(x,t)\rho(0,0) \rangle. \quad (1)$$

Here,  $\rho(x,t)$  is the density operator and the averaging  $\langle \dots \rangle$  is performed over the Gibbs ensemble or the ground state in the case of finite or zero temperature, respectively. In the Tomonaga-Luttinger model, at small wavevectors q the DSF takes the form  $S_{\rm LL} \propto |q|\delta(\omega-v|q|)$  at any temperature. The dispersion results in a "broadening" of the delta-function. Accounting for a finite width of  $S(q,\omega)$  even for small q is important (Pustilnik et al., 2003) for understanding Coulomb drag experiments (Debray et al., 2001, 2002; Laroche et al., 2011; Yamamoto et al., 2002, 2006). The broadening occurs even at zero temperature (T=0), and we will concentrate on that case.

To illustrate the origin of the structure arising in  $S(q,\omega)$  due to the dispersion, let us consider first the simplest case of free spinless fermions with a quadratic dispersion relation,

$$\xi(k) = \frac{k^2 - k_F^2}{2m} \,. \tag{2}$$

At zero temperature, the structure factor can be thought of as an absorption coefficient, *i.e.*, the dissipative part of the linear susceptibility with respect to a perturbation  $\delta \mathcal{H} = U(x,t)\rho(x,t)$  by a potential U(x,t) varying in space and time with the wave vector q and frequency  $\omega$ , respectively. In the case of free fermions, dissipation is caused by creation of particle-hole pairs by the perturbing potential, see Fig. 1. At  $q < 2k_F$ , a simple evaluation of Eq. (1) yields

$$S_0(q,\omega) = (m/q)\theta(q^2/(2m) - |\omega - v_F q|)$$
 (3)

with the Fermi velocity  $v_F = k_F/m$ . The two thresholds for absorption correspond to two special configurations in the momentum space of the particle-hole pairs, see Fig. 1. Specifically, the lower boundary,  $\omega_-(q) = v_F q - q^2/(2m)$ , corresponds to a particle just above the Fermi level, and a "deep" hole with momentum  $k_F - q$ , moving with velocity  $v_h = v_F - q/m$ , smaller than  $v_F$ . Equation (3) and Fig. 1 allow us to make three interesting observations:

First, at fixed  $q \ll 2k_F$ , the width of the structure factor in the frequency domain  $\delta\omega \sim \omega^2/(mv_F^2)$  scales as  $\propto \omega^2$ . This is consistent with the power-counting argument for the irrelevant curvature term in the spectrum  $\xi(k)$ . The limit of linear spectrum (which is also a trivial limit of an LL at zero inter-particle interaction) corresponds to taking  $m \to \infty$  at fixed value of  $v_F$ . In this limit,  $\delta\omega \to 0$ .

![](_page_4_Figure_10.jpeg)

FIG. 1 (Color online) Density structure factor  $S(q,\omega)$  for noninteracting fermions [see Eq. (3)] and weakly interacting fermions [see Eqs. (27), (30) and (32)]. In the noninteracting case,  $S_0(q,\omega)$  is constant in the dark shaded region and vanishes otherwise. Left: Particle-hole configurations responsible for the upper and lower thresholds. Right:  $S(q,\omega)$  for fixed  $0 < q < 2k_F$ . In the noninteracting case,  $S(q,\omega)$  has a rectangular shape. Interactions turn the steps into power-law singularities, and  $S(q,\omega)$  becomes nonzero in the light shaded region.

Second, the dependence of  $S_0(q,\omega)$  on its arguments is not analytic; besides, if one allows an arbitrary sign of the mass m, it becomes immediately clear that  $\delta\omega\propto 1/|m|$  at a fixed value of the Fermi velocity  $v_F$ . Each of these two facts kills the hope to develop a simple perturbation theory in the irrelevant perturbation, i.e., the curvature of the particles dispersion relation. Indeed, it is clear from the above discussion that the perturbing part of the Hamiltonian associated with the curvature is proportional to 1/m. To obtain a broadened structure factor, one needs to evaluate the self-energy of the density propagator. The form of Eq. (3) tells us that the imaginary part of self-energy is  $\propto 1/|m|$  and may result only from a summation of some infinite series in 1/m.

Third, the specific structure of the particle-hole pair corresponding to the edge  $\omega_{-}(q)$  gives us a hint at how weak interactions may modify Eq. (3). Indeed, suppose fermions weakly repel each other. Then, the created particle would be attracted to the hole it left upon excitation. This interaction would lead to the Mahan (excitonic) singularity in the absorption coefficient (Mahan, 1981). That is, the step-like threshold at  $\omega = \omega_{-}(q)$  would transform into a divergent power-law function with an exponent dependent on the inter-particle repulsion strength.

The above simple picture establishes the relation, which is central for this section, of the nonlinear LL problem to the well-studied problem of Fermi-edge singularities (Nozières and De Dominicis, 1969). The latter is reviewed in great detail elsewhere (Gogolin  $et\ al.$ , 1998; Mahan, 1981; Ohtaka and Tanabe, 1990). We will see that the power-law asymptote of the DSF at energies close to the threshold is a robust feature valid at arbitrary interaction strength and arbitrary q. We will also develop ways to evaluate the corresponding exponent, which does depend on these parameters.

A nonlinear dispersion relation of interacting quantum particles confined to 1D affects also their spectral func-

![](_page_5_Figure_1.jpeg)

![](_page_5_Figure_2.jpeg)

FIG. 2 (Color online) Spectral function  $A(k \approx k_F, \varepsilon)$  for a Luttinger liquid (LL) with linearized spectrum. Left:  $A(k,\varepsilon)$  vanishes in the white regions. Right:  $A(k,\varepsilon)$  for fixed  $k \lesssim k_F$ . Interactions cause a power-law divergence at the mass shell  $\varepsilon \approx v(k-k_F)$  with exponent  $\mu_- = 1 - (K + K^{-1} - 2)/4$ . A convergent power-law cusp with exponent  $\mu_+ = -(K + K^{-1} - 2)/4$  emerges at the inverted mass shell  $\varepsilon \approx -v(k-k_F)$ .

tion  $A(k,\varepsilon)$ . The latter is defined as

$$A(k,\varepsilon) = -\frac{1}{\pi} \text{Im} G(k,\varepsilon) \text{sign}\varepsilon$$
 (4)

with the Green's function (Abrikosov et al., 1963)

$$G(k,\varepsilon) = -i \int_{-\infty}^{\infty} dt \int_{-\infty}^{\infty} dx e^{i(\varepsilon t - kx)} \langle T[\Psi(x,t)\Psi^{\dagger}(0,0)] \rangle.$$
(5)

Here  $\Psi(x,t)$  and  $\Psi^{\dagger}(x,t)$  are the particle (fermion or boson) annihilation and creation operators, respectively, T denotes the time ordering, and the energy  $\varepsilon$  is measured from the chemical potential.

The spectral function may be thought of as a tunneling density of states: the probability for a particle (hole) with given momentum k and energy  $\varepsilon > 0$  ( $\varepsilon < 0$ ) to tunnel into a system is proportional to  $A(k,\varepsilon)$ . It can be measured using ARPES (Kim et al., 2006; Kondo et al., 2010; Wang et al., 2009, 2006) for solid state systems or photoemission spectroscopy (Gaebler et al., 2010; Stewart et al., 2008) for low-dimensional ultracold atomic systems (Görlitz et al., 2001; Kinoshita et al., 2004, 2006; Paredes et al., 2004). It also determines electronic transport in systems with momentum and energy conserving tunneling (Auslaender et al., 2005, 2002; Barak et al., 2010; Jompol et al., 2009). In the absence of interactions, a particle with a given momentum may tunnel only if its energy fits the dispersion relation of the particles constituting the system,  $A_0(k,\varepsilon) = \delta[\varepsilon - \xi(k)]$ . The right-hand side here is the density of single-particle eigenstates with given energy and momentum.

Before considering the effects of a nonlinear dispersion, let us recall the behavior of  $A(k,\varepsilon)$  in a fermionic LL. In the absence of interactions, the tunneling density of states for, say, right-movers is  $A(k,\varepsilon) = \delta[\varepsilon - v(k-k_F)]$ . Interactions between the particles forming the LL broaden the spectrum of energies at which tunneling is possible. In the vicinity of the Fermi point

![](_page_5_Figure_11.jpeg)

FIG. 3 (Color online) (a) An incoming particle with momentum  $k \approx k_F$  and energy above the mass shell can tunnel into the system by creating a particle with momentum near  $k_F$  on the mass shell and a low-energy particle-hole pair near the opposite Fermi point. (b) If the spectrum is curved, an incoming particle with momentum  $k \gtrapprox k_F$  and energy below the mass shell can tunnel into the system by creating a particle on mass shell and a low-energy particle-hole pair near the same Fermi point.

 $+k_F$  one has (Luther and Peschel, 1974; Meden and Schönhammer, 1992; Voit, 1993a,b, 1995)

$$A(k,\varepsilon) \propto \operatorname{sign}(\varepsilon) \frac{\theta[\varepsilon^2 - v^2(k - k_F)^2]}{\varepsilon - v(k - k_F)} \times \left[\varepsilon^2 - v^2(k - k_F)^2\right]^{\frac{1}{4}\left(K + \frac{1}{K}\right) - \frac{1}{2}}.$$
 (6)

The shape of  $A(k,\varepsilon)$  for a linear LL is shown in Fig. 2. Here, the LL parameter K depends on the interaction strength (K < 1 for repulsion); free fermions correspond to the limit  $K \to 1$ . The delta-function in the tunneling density of states of free particles got transformed into a power-law, divergent at the line  $\varepsilon = v(k - k_F)$  if the interaction is not too strong, see Eq. (6). Note that an important feature of the linear LL result is the particle-hole symmetry under the transformation

$$\varepsilon \to -\varepsilon,$$

$$(k - k_F) \to -(k - k_F), \tag{7}$$

which is a necessary consequence of the spectrum linearization.

The nonzero values of  $A(k,\varepsilon)$  outside the line  $\varepsilon=v(k-k_F)$  may be understood within the perturbation theory if one invokes the notion of tunneling probability. In the presence of interactions between particles, the tunneling free particle with energy  $\varepsilon>v|k-k_F|$  may spend the extra energy on the creation of a particle-hole pair on the branch of left-movers and land on the mass shell  $\xi(k)=v(k-k_F)$  for the right-moving particles. This process is depicted in Fig. 3a. Similarly, the tunneling of a particle at energy  $-\varepsilon>v|k-k_F|$  out of the system creates a right-moving hole and left-moving particle-hole pair. To summarize, in this perturbative picture tunneling of a particle into (out of) the system creates three excitations: a right-moving particle (hole) and a particle-hole pair on the opposite branch.

The above perturbative consideration is easy to carry over to fermions with the nonlinear dispersion relation (2). We see immediately the difference between the particle-like  $(k > k_F)$  and hole-like parts of the spectrum. The hole-like part of the spectrum becomes the energy threshold  $\xi(k) < 0$  for tunneling at  $|k| < k_F$ . Indeed, because the hole's velocity  $|k/m| < v_F$ , it is not capable of emitting "Cherenkov radiation" of low-energy particle-hole pairs in either of the two allowed directions. At energies  $\varepsilon < \xi(k) < 0$ , the tunneling of a hole is accompanied by the creation of particle-hole pairs at both Fermi points.

However, as shown in Fig. 3, the particle-like part of the spectrum (2) falls into a continuum of energies available for tunneling at given  $|k| > k_F$ . To see this, we may again concentrate on the tunneling of a rightmoving free particle with momentum  $k > k_F$ . Unlike in the case of a linear spectrum, now a particle with energy  $0 < \varepsilon < \xi(k)$  may tunnel by creating a comoving particle and a particle-hole pair. The total of three excitations should have the momentum k, but the sum of their energies is less than  $\xi(k)$  if all three momenta are within the region of width  $k - k_F$  around  $k_F$ . Within perturbation theory, we find the threshold in this region at  $-\xi(k-2k_F)$  for  $k_F < k < 3k_F$ , see Fig. 3b. Consequently, states at the free-particle mass shell  $\xi(k)$  at  $k > k_F$  are not protected by kinematics: particles move fast enough  $(|k/m| > v_F)$  to allow Cherenkov radiation of particle-hole pairs.

A comparison of the perturbative pictures for the linear and nonlinear dispersion relations reveals some substantial ramifications introduced by the nonlinearity. The nonlinearity destroys the particle-hole symmetry, Eq. (7), which existed in the LL. The hole-like part of the threshold morphs from a straight line into a nonlinear function; the nature of excitations created by a tunneling hole is not changed by the introduction of the curvature. However, the particle-like part of the threshold changes drastically; the excitations defining it have no counterpart in the linear LL. In Sec. II.B we will review a universal nonlinear LL theory valid in the vicinities of Fermi points (Imambekov and Glazman, 2009b).

We should emphasize that at  $k \to \pm k_F$  the range of energies in which  $A(k,\varepsilon)$  is substantially modified compared to linear LL theory becomes narrow, since it scales as  $|\varepsilon - \xi(k)| \propto (k - k_F)^2/m$ . At energies  $|\varepsilon - \xi(k)| \gg (k - k_F)^2/m$  the linear LL theory does indeed describe the structure of spectral function. This is consistent with the curvature being an irrelevant perturbation (Haldane, 1981b). However, the true threshold behavior of the spectral function is controlled by the nonlinear spectrum at any wavevector k, close to or far away from  $\pm k_F$ .

The above discussion based on the perturbation theory tells us that the presence of thresholds in the dynamic response functions is protected by kinematics: a slowmoving excitation (a hole in the above consideration) can not decay in 1D. An inspection of Figs. 1 and 3b may raise a question, whether the response functions of a nonlinear LL have singularities within the spectral continuum. The answer is: "it depends". In the case of integrable models, these singularities do survive, while in a generic liquid they are broadened and get progressively washed out if one moves away from the Fermi points. We discuss the singularities in the continuum in Sec. III devoted to the integrable models, and the broadening of singularities by relaxation processes in Sec. IV devoted to the kinetics of nonlinear LLs.

The remainder of this section is organized as follows. In Sec. II.A we make the above perturbative considerations quantitative and derive the effective mobileimpurity Hamiltonian for weakly interacting spinless fermions. The perturbation theory gives a clear hint on how to proceed with the calculation of the threshold singularities at arbitrary interaction strength. In Sec. II.B we explain the theory of a nonlinear LL at arbitrary interactions in the vicinity of the points  $k = \pm k_F$ , considering in detail the crossover between the generic threshold behavior and the linear LL asymptote. The adequate apparatus based on a mobile quantum impurity moving in a linear LL is extended further, and we develop the phenomenology of the threshold behavior of the dynamic responses for spinless fermions (Sec. II.C), spin liquids (Sec. II.D), bosonic systems (Sec. II.E), as well as for spinful fermionic systems (Sec. II.F). Next, Sec. II.G is devoted to effects which arise due to a finite system size and finite temperatures. Finally, in Sec. II.H we discuss the implications of the threshold singularities for correlation functions in the space-time domain and for the breakdown of conformal invariance.

#### A. Perturbative treatment of interactions

# 1. Dynamic structure factor (DSF)

The DSF  $S(q, \omega)$  characterizes the linear response of the density to an external field which couples to the density. The absorption rate for quanta of momentum q and energy  $\omega$  of such a field (e.g., photons) is proportional to  $S(q, \omega)$ . The rate is given by Fermi's golden rule,

$$S(q,\omega) = \frac{2\pi}{L} \sum_{|f\rangle} |\langle f|\rho_q^{\dagger}|0\rangle|^2 \delta(\omega - \epsilon_f). \tag{8}$$

The equivalence of Eqs. (1) and (8) can be demonstrated using the Lehmann spectral representation. Here, the system length is denoted by L, and the Fourier components of the density are defined by  $\rho_q^{\dagger} = \sum_k \Psi_{k+q}^{\dagger} \Psi_k$ .

In noninteracting systems, the ground state  $|0\rangle$  at zero temperature consists of a Fermi sea filled up to the Fermi momentum  $k_F$ . A nonzero matrix element  $\langle f|\rho_q^{\dagger}|0\rangle$  emerges only for final states  $|f\rangle$  which contain exactly one particle-hole pair with momentum q. All possible

final states can thus be parameterized by the particle momentum  $k_p$  and the hole momentum  $k_h$ ,

$$|f\rangle = \Psi_{k_p}^{\dagger} \Psi_{k_h} |0\rangle, \tag{9}$$

where  $|k_p| > k_F$ ,  $|k_h| < k_F$ , and  $k_p - k_h = q$ . For the quadratic spectrum (2), the energy of such a state is  $\epsilon_f = (k_p^2 - k_h^2)/(2m)$ . The evaluation of the DSF according to Eq. (8) is then straightforward and yields for  $q < 2k_F$ ,

$$S_0(q,\omega) = \frac{m}{|q|} \theta[\omega - \omega_-(q)] \theta[\omega_+(q) - \omega]. \tag{10}$$

It turns out that  $S_0(q,\omega)$  is nonzero only within the interval  $\omega_-(q) < \omega < \omega_+(q)$ . The upper and lower edges of support physically correspond to final states  $|f\rangle$  which have the highest and lowest possible energies, respectively, for a given momentum q. As shown in Fig. 1, for q>0 the final state with the maximum energy contains a hole with momentum  $k_h=k_F$  and a particle with momentum  $k_p=k_F+q$ . The energy of this state is  $\omega_+(q)=v_Fq+q^2/(2m)$ . Similarly, the density excitation with the minimum energy for q>0 contains a hole with momentum  $k_h=k_F-q$  and a particle near the Fermi point,  $k_p=k_F$ . This state has the lower threshold energy  $\omega_-(q)=v_Fq-q^2/(2m)$ . The width of support of  $S_0(q,\omega)$  for fixed q is therefore

$$\delta\omega(q) = \omega_+(q) - \omega_-(q) = \frac{q^2}{m}.$$
 (11)

In view of a perturbative analysis, it is convenient to express the noninteracting DSF in terms of fermionic Green's functions. Using the fluctuation-dissipation theorem, the DSF at zero temperature can be related to the susceptibility (Doniach and Sondheimer, 1998),  $S(q, \omega > 0) = -2\operatorname{Im}\chi(q,\omega)$ , where  $\chi(q,\omega)$  is the Fourier transform of

$$\chi(x,t) = -i\theta(t) \langle [\rho(x,t), \rho(0,0)] \rangle. \tag{12}$$

For  $\omega > 0$ , the imaginary part of the retarded densitydensity correlation function  $\chi(q,\omega)$  coincides with the imaginary part of the polarization diagram,

$$\mathcal{P}_0(q,\omega) = \underbrace{\begin{array}{c} q + q_1, \omega + \omega_1 \\ -q_1, -\omega_1 \end{array}}_{(13)},$$

where solid lines denote time-ordered fermion Green's functions, and the internal momentum  $q_1$  and the internal energy  $\omega_1$  are integrated over. Therefore, for the noninteracting system  $S_0(q, \omega > 0) = -2 \operatorname{Im} \mathcal{P}_0(q, \omega)$ , yielding again Eq. (10).

Next, let us calculate the correction to the DSF for a weak density-density interaction,

$$H_{int} = \frac{1}{2} \int dx dy \rho(x) V(x - y) \rho(y). \tag{14}$$

The first-order term  $\delta S^{(1)}(q,\omega)$  can be cast into an RPA-like diagram and a vertex correction,

$$\delta S^{(1)}(q,\omega) \propto \operatorname{Im} \left[ \begin{array}{c} \\ \\ \end{array} \right]$$

$$+ \operatorname{Im} \left[ \begin{array}{c} \\ \end{array} \right] . \tag{15}$$

The wiggly lines denote the interaction. Let us start with the first diagram and estimate its contribution towards the lower edge of support,  $\omega \approx \omega_{-}(q)$ . Its imaginary part is proportional to  $V_q \operatorname{Im} \mathcal{P}_0(q,\omega) \operatorname{Re} \mathcal{P}_0(q,\omega)$ . However, we showed that  $\operatorname{Im} \mathcal{P}_0(q,\omega)$  is proportional to the noninteracting DSF, so  $\operatorname{Im} \mathcal{P}_0(q,\omega) \propto \theta[\omega - \omega_{-}(q)]$  contains a threshold. The Kramers-Kronig relation (Landau and Lifshitz, 1980) therefore predicts a logarithm in the real part,  $\operatorname{Re} \mathcal{P}_0(q,\omega) \propto \ln\{[\omega - \omega_{-}(q)]/\delta\omega(q)\}$ . So, the first diagram diverges logarithmically towards the edge. The second diagram can also be calculated and leads to an identical asymptote but with a prefactor  $-V_0$ . As a result, the total first order correction near the threshold reads

$$\delta S^{(1)}(q,\omega) = \frac{m^2(V_q - V_0)}{\pi |q|^2} \theta[\omega - \omega_-(q)] \ln\left[\frac{\omega - \omega_-(q)}{\delta \omega(q)}\right]. \tag{16}$$

Hence, a straightforward calculation of the first-order correction  $\delta S^{(1)}(q,\omega)$  leads to a logarithmic threshold divergence. The underlying physical mechanism is reminiscent of the Fermi edge singularity problem (Anderson, 1967; Gogolin et al., 1998; Mahan, 1967, 1981; Nozières and De Dominicis, 1969; Ohtaka and Tanabe, 1990; Schotte and Schotte, 1969): the final state  $|f\rangle$  for  $\omega = \omega_{-}(q)$  and  $0 < q < 2k_F$  contains a hole at momentum  $k_F - q$  which generates a scattering potential. The infrared divergence is produced by scattering of particles near the Fermi points with small momentum exchange. In order to obtain a viable result, a partial resummation of the perturbation series is needed.

The analogy between the physics of the Fermi edge singularity and the threshold behavior of the DSF can be exploited (Pustilnik et al., 2006) by using a method which is familiar from the solution of the Fermi edge singularity problem by Schotte and Schotte (1969). In the calculation of  $S(q,\omega)$  near the threshold  $\omega \approx \omega_{-}(q)$ , the hole with momentum  $k_F - q$  assumes the role of a "deep" hole. The energy left for additional excitations  $|\omega - \omega_{-}(q)|$  is small, so all particle-hole pairs created due to the interaction are restricted to a small window of width  $k_0 \ll q$  around the Fermi points. The Hamiltonian can then be projected onto three subbands of width  $k_0$ , one centered around  $k_F - q$  containing the deep hole and two containing the Fermi points  $\pm k_F$ . We note that this projection into subbands is in fact very similar to a conventional procedure employed in the Fermi edge singularity problem. In the latter, a full fermionic operator

is split into contributions from non-overlapping conduction and core-hole bands. In our case, all fermions are in the same band, but since the momenta of the important states do not overlap due to kinematic constraints, splitting the fermionic operator into subbands is a legitimate procedure. In contrast to the original Fermi edge problem, the deep hole is mobile but this does not destroy the edge singularity (Balents, 2000; Ogawa et al., 1992).

Let us illustrate the calculation for  $0 < q < 2k_F$ . In this case, the fermion annihilation operator  $\Psi(x)$  is projected onto the three subbands using

$$\Psi(x) \to e^{ik_F x} \psi_R(x) + e^{-ik_F x} \psi_L(x) + e^{ikx} d(x), \quad (17)$$

where  $k = k_F - q$  lies within the Fermi sea and the projected operators d(x) and  $\psi_{R,L}(x)$  have nonzero Fourier components only within the narrow bandwidth  $k_0$ . Using this projection in the definition of the DSF and retaining only Fourier components close to q leads to

$$S(q,\omega) = \int dx dt e^{i\omega t - iqx} \langle \Psi^{\dagger}(x,t)\Psi(x,t)\Psi^{\dagger}(0,0)\Psi(0,0)\rangle$$
$$= \int dx dt e^{i\omega t} \langle d^{\dagger}(x,t)\psi_R(x,t)\psi_R^{\dagger}(0,0)d(0,0)\rangle. \tag{18}$$

The next step is to project the interacting system Hamiltonian onto the narrow subbands. Because the reduced bandwidth  $k_0$  is small, the spectrum within each of the subbands can be linearized. This makes it convenient to bosonize  $\psi_{R,L}$  using

$$\psi_{R,L}(x) \propto e^{-i[\pm\phi(x)-\theta(x)]},$$
 (19)

and to write the corresponding terms in the Hamiltonian in the bosonic basis. In Eq. (19), the conventional bosonic fields  $\theta$  and  $\phi$  satisfy a canonical commutation relation (we use the notations of Giamarchi (2004) thoughout the text),

$$[\phi(x), \nabla \theta(x')] = i\pi \delta(x - x'). \tag{20}$$

After a projection of the microscopic interactions onto subbands and bosonization, the Hamiltonian becomes  $H = H_0 + H_d + H_{int}$ , where

$$H_{0} = \frac{v_{F}}{2\pi} \int dx [(\nabla \theta)^{2} + (\nabla \phi)^{2}], \qquad (21)$$

$$H_{d} = \int dx d^{\dagger}(x) [\xi(k) - iv_{d} \nabla] d(x),$$

$$H_{int} = \int dx [(V_{k-k_{F}} - V_{0})\rho_{R} + (V_{k+k_{F}} - V_{0})\rho_{L}] dd^{\dagger}.$$

The term  $H_0$  describes the kinetic energy of the particles near the Fermi points. The energy of the impurity dis close to  $\xi(k)$ , its motion is described by  $H_d$ , and its velocity reads

$$v_d = \frac{\partial \xi(k)}{\partial k} = \frac{k}{m} = v_F - \frac{q}{m}.$$
 (22)

Last but not least, the term  $H_{int}$  contains the densitydensity interactions between the impurity and the particles near the Fermi points. The densities of right- and left-movers are given by

$$\rho_{\alpha}(x) = \frac{1}{2\pi} \nabla(-\phi + \alpha\theta), \tag{23}$$

where  $\alpha = R, L = +, -$ . Interactions lead to the formation of low-energy particle-hole pairs and are thus crucial for the shape of the DSF. Schotte and Schotte (1969) showed that  $H_{int}$  can be removed using a unitary transformation. Indeed, introducing the unitary operator

$$U = \exp\left\{i \int dx \left(\frac{\delta_{+}}{2\pi} [\theta - \phi] - \frac{\delta_{-}}{2\pi} [\theta + \phi]\right) dd^{\dagger}\right\} \quad (24)$$

one finds  $U^{\dagger}(H_0 + H_d + H_{int})U = H_0 + H_d$  by using the phase shifts

$$\delta_{+} = \frac{V_0 - V_{k-k_F}}{v_d - v_F}, \ \delta_{-} = \frac{V_0 - V_{k+k_F}}{v_d + v_F}.$$
 (25)

Physically, the values of  $\delta_{\pm}(k)$  correspond to the scattering phase shifts between the deep hole and the low-energy particles near the right and left Fermi points in the Born approximation. In order to calculate  $S(q,\omega)$  using Eq. (18), the same unitary transformation has to be applied to the operators  $\psi_R(x)$  and d(x). The impurity operator acquires a phase shift in the rotation,

$$U^{\dagger}d(x)U = e^{i\left(\frac{\delta_{+}}{2\pi}[\phi(x) - \theta(x)] + \frac{\delta_{-}}{2\pi}[\phi(x) + \theta(x)]\right)}d(x). \tag{26}$$

Note the similarity to the bosonization formula (19). Indeed, the "shake-up" of the particles at the right Fermi point caused by the interaction with the deep hole manifests itself as an additional phase in the bosonic representation of the operator  $\psi_R(x)$ , and similarly for the left Fermi point.

After bosonization and rotation, the expectation value in Eq. (18) thus factorizes into a term containing the bosonic fields  $\phi$  and  $\theta$ , and a term containing the impurity operator d. The dynamics of the fields  $\phi(x)$  and  $\theta(x)$  is governed by  $H_0$  and is therefore linear. Hence, the expectation values of exponentials of bosonic operators can be calculated straightforwardly (Giamarchi, 2004). The impurity dynamics is governed by  $H_d$  and leads to  $\langle d^{\dagger}(x,t)d(0,0)\rangle = e^{-i\omega_{-}(q)t}\delta(x-v_dt)$ . Upon Fourier transformation of the time-dependent correlation function, the result for the DSF at its lower edge of support reads

$$\frac{S(q,\omega)}{m/q} = \left[\frac{\delta\omega(q)}{\omega - \omega_{-}(q)}\right]^{\mu_{0}(q)} \text{ for } \delta\omega(q) \gg \omega - \omega_{-}(q) > 0.$$
(27)

The threshold exponent of  $S(q,\omega)$  depends on momen-

tum and interaction strength and reads

$$\mu_0(q) = 1 - \left(1 + \frac{\delta_+}{2\pi}\right)^2 - \left(\frac{\delta_-}{2\pi}\right)^2 \\ \approx -\frac{\delta_+}{\pi} = \frac{m}{\pi|q|} (V_0 - V_q).$$
 (28)

For generic repulsive interaction potentials µ0(q) > 0, so the DSF has a power-law divergence at the lower threshold. The expansion of Eq. (27) for µ0(q) ln {[ω − ω−(q)]/δω(q)} 1 coincides with the leading order logarithmic result (16). The present calculation corresponds to a resummation of the leading logarithmic divergences to each order in the perturbation series and thus yields the exponent µ0(q) to first order in the interaction potential Vq.

For momenta |q| ≈ 2k<sup>F</sup> , the exponent (28) evaluated in the leading order of perturbation theory in the interaction potential coincides with the corresponding limit of the linear LL exponents. Indeed, at q → 2k<sup>F</sup> , the LL theory predicts a power-law divergence, S(q, ω) ∝ θ[ω − |v(q − 2k<sup>F</sup> )|][ω − |v(q − 2k<sup>F</sup> )|] K−1 , with an exponent K − 1. For weak interaction, K can be calculated perturbatively, and one finds (Giamarchi, 2004)

$$K \approx 1 - (V_0 - V_{2k_F})/(2\pi v_F),$$
 (29)

thus reproducing the prediction (28). At q → 0 and V (x) decaying faster than ∝ 1/x<sup>2</sup> ,(V<sup>q</sup> − V0)/q → 0. Then the exponent (28) vanishes, and for a fixed q a rectangular shape of S(q, ω) is recovered. The latter has a width δω(q) ∝ q 2 , height m/q, and is located at the mass shell ω = v<sup>F</sup> q. In the limit q → 0, this peak indeed acquires a delta-shape as predicted by the LL theory. Later we will see that the relation µ0(0) = 0 for a short-range potential holds beyond the perturbation theory; the rectangular shape of S(q, ω) at small fixed q is quite generic.

The procedure that led to the DSF near its lower threshold exemplifies a rather versatile framework for the perturbative calculation of various dynamic response functions near singular thresholds. Generally, singularities appear whenever conservation laws allow that the entire energy of an incoming density- or single-particle excitation is transferred to a single particle or hole in the system. As illustrated above, the general procedure consists of the following three steps: (i) Identification of the "deep hole" configuration responsible for the singular behavior at the threshold of interest. This configuration always follows from momentum and energy conservation. (ii) Projection of the Hamiltonian onto a reduced band structure containing narrow bands around the deep hole and the Fermi points. (iii) Determination of the phase shifts due to the interactions between the deep hole and particles at the Fermi points by applying a unitary transformation.

The shape of the threshold singularity of S(q, ω) for ω ≈ ω+(q) can be obtained similarly. For q > 0, the configuration giving rise to this singularity contains a hole near the right Fermi point as well as a particle near k<sup>F</sup> +q (see Fig. 1). Projecting the Hamiltonian onto narrow bands around the Fermi points and a narrow band around k<sup>F</sup> + q, and following essentially the same procedure as before, it was found that for δω(q) |ω −ω+(q)| (Pustilnik et al., 2006)

$$\frac{S(q,\omega)}{m/q} = \begin{cases}
\frac{\nu(q)}{\mu_0(q)} + \left[\frac{\delta\omega(q)}{\omega_+(q)-\omega}\right]^{-\mu_0(q)} & \omega < \omega_+(q), \\
\frac{\nu(q)}{\mu_0(q)} \left(1 - \left[\frac{\delta\omega(q)}{\omega-\omega_+(q)}\right]^{-\mu_0(q)}\right) & \omega > \omega_+(q).
\end{cases}$$
(30)

where

$$\nu(q) = \left(\frac{q}{4mv_F}\right)^2 \left(\frac{V_0 - V_{2k_F}}{2\pi v_F}\right)^2.$$
 (31)

Hence, power-law singularities with identical exponents −µ0(q) appear on both sides of the threshold ω+(q). In stark contrast to the noninteracting limit, S(q, ω) no longer vanishes above the upper threshold. Also note that the prefactors are different on both flanks.

The DSF S(q, ω) remains nonzero even above the upper threshold because any excess energy ω − ω+(q) can be used for the creation of an additional particle-hole pair on the left branch. As the excess energy increases, the momenta of the two particles and two holes may be increasingly far away from the Fermi points. Hence, ordinary second-order perturbation theory works well for ω − ω+(q) δω. In this range, one finds

$$S(q,\omega) = 2\nu(q)\frac{v_F q^2}{\omega^2 - v_F^2 q^2}.$$
 (32)

The DSF for a weakly interacting system is depicted in Fig. 1.

In conclusion, interactions lead to notable changes in S(q, ω). Instead of the rectangular shape of S(q, ω) for any given q in the noninteracting case, interactions lead to the appearance of power-law singularities at the thresholds ω±(q). Moreover, the function no longer vanishes above the upper edge ω+(q).

#### 2. Spectral function

The procedure employed for the perturbative calculation of the DSF can also be used for the calculation of the edge singularities of the spectral function (Khodas et al., 2007b). In contrast to S(q, ω), the spectral function A(k, ε) characterizes the response of the system to the addition of a single particle or hole. It determines the probability for a particle with energy ε and momentum k to enter (or, at ε < 0, emerge from) the system in a momentum-conserving tunneling event; particle and hole sectors correspond to ε > 0 and ε < 0, respectively.

![](_page_10_Picture_1.jpeg)

FIG. 4 (Color online) Spectral function  $A(k,\varepsilon)$  for interacting fermions, with notations for the edge exponents. The configurations determining the edge exponents  $\mu_{0,-}$  and  $\mu_{1,+}$  are indicated. In the weakly interacting case, the edge of support  $\varepsilon_{\rm th}(k)$  at  $|k| < k_F$  coincides with the mass shell  $\xi(k)$ , see Eq. (2). In the noninteracting case, the spectral function  $A(k,\varepsilon)$  is a delta-function at the mass shell,  $A_0(k,\varepsilon) = \delta[\varepsilon - \xi(k)]$ .

In the absence of interactions,  $A(k,\varepsilon) = \delta[\varepsilon - \xi(k)]$ , because a particle or hole with momentum k can only be absorbed if its energy is on the mass shell  $\xi(k)$ . In an interacting system, on the other hand, the spectral function will generally become nonzero even away from the mass shell  $\xi(k)$ , because incoming particles or holes may give up part of their energy and momentum to excite additional particle-hole pairs.

For  $|k| < k_F$  and  $\varepsilon < 0$ , the edge of support of  $A(k,\varepsilon)$  coincides with the fermion mass shell. In this case, the calculation of the edge singularity is very analogous to the previous section. If a particle with momentum k and energy  $\varepsilon \approx \xi(k)$  is extracted from the system, it leaves behind a hole with momentum near k on mass shell, as well as low-energy particle-hole pairs near either of the Fermi points. Therefore, it is again sufficient to retain narrow bands of widths  $k_0 \ll |k|$  around k and  $\pm k_F$ , and project the fermion operator as in Eq. (17). The remaining calculations closely follow Sec. II.A.1.

The spectral function in the vicinity of  $\xi(k) < 0$  can be calculated as

$$A(k,\varepsilon) \propto \int dt dx e^{-i\varepsilon t} \left\langle d^{\dagger}(x,t) d(0,0) \right\rangle_{H_0 + H_d + H_{int}}$$
$$\propto \theta[\xi(k) - \varepsilon] [\xi(k) - \varepsilon]^{-\mu_{0,-}}. \tag{33}$$

The exponent to lowest order in the interaction strength reads

$$\mu_{0,-} = 1 - \left(\frac{\delta_{-}}{2\pi}\right)^2 - \left(\frac{\delta_{+}}{2\pi}\right)^2.$$
 (34)

The phase shifts  $\delta_{\pm}$  are defined in Eq. (25). For  $k \to k_F$ , the phase shift  $\delta_+$  vanishes linearly for interaction potentials decaying faster than  $1/x^2$  in real space. On the other hand,  $\delta_-$  at  $k \to k_F$  remains finite,  $\delta_- = -(V_{2k_F} - V_{2k_F})$ 

 $V_0)/(2v_F)$ . Therefore, in the limit  $k \to k_F$ , the exponent  $\mu_{0,-}$  coincides with the Luttinger model prediction for weak interactions (Luther and Peschel, 1974).

Note that to lowest order the exponent is quadratic in the interaction potential  $V_k$ , which is in contrast to the result (28) for the DSF. Moreover, the interactions of the impurity with left-movers and right-movers are equally important.

Outside the regime  $\varepsilon < 0$  and  $|k| < k_F$ , the edge of support of the spectral function no longer coincides with the mass shell, but it is still determined by kinematic considerations: the injection of a particle or hole and the ensuing creation of particle-hole pairs due to the interactions must respect momentum and energy conservation. For weak interactions, the edge of support can be determined quantitatively by using the Lehmann spectral representation (Abrikosov et al., 1963). Let us focus on the particle sector ( $\varepsilon > 0$ ) and the momentum range  $k_F < k < 3k_F$ , where

$$A(k,\varepsilon) = \sum_{|f\rangle} |\langle f|\Psi_k^{\dagger}|0\rangle|^2 \delta_{k-P_f,0} \delta(\varepsilon - E_f).$$
 (35)

The initial state  $|0\rangle$  corresponds to the ground state of the system and the sum runs over a complete basis  $\{|f\rangle\}$  of the Fock space. The energies and momenta of the final states are denoted by  $E_f$  and  $P_f$ , respectively. In the absence of interactions, the ground state  $|0\rangle$  is the filled Fermi sea and the only final state with nonzero overlap is  $|f\rangle = \Psi_k^{\dagger}|0\rangle$ . This immediately leads to  $A(k,\varepsilon) = \delta[\varepsilon - \xi(k)]$ .

In an interacting system, on the other hand, the ground state  $|0\rangle$ , written in the basis generated by the operators  $\Psi_k$  and  $\Psi_k^{\dagger}$ , may contain particle-hole pairs. Therefore, a nonzero overlap can also be achieved for final states which contain additional excitations. The simplest set of such final states is

$$|f\rangle = \Psi_{k_1}^{\dagger} \Psi_{k_2}^{\dagger} \Psi_{k_3} |0\rangle, \tag{36}$$

and it can be parametrized by the momenta  $k_1, k_2, k_3$ . The edge of support of  $A(k,\varepsilon)$  can be determined by enforcing momentum and energy conservation and finding the configuration with lowest excitation energy  $E_f$ . Within perturbation theory, the energy  $E_f$  is determined using the noninteracting Hamiltonian. The result for the particle sector  $(\varepsilon > 0)$  at  $k > k_F$  is  $k_1 = k_2 = k_F$  and  $k_3 = 2k_F - k$ , i.e., at the edge of support the entire energy is carried by a single hole with momentum  $2k_F - k$ . The energy of this configuration and thus the edge of support of  $A(k,\varepsilon)$  is given by

$$-\xi(2k_F - k) = v_F(k - k_F) - \frac{(k - k_F)^2}{2m}.$$
 (37)

The configuration yielding the threshold (37) remains the lowest energy state with total momentum  $k_F < k < 3k_F$ 

even if compared to states with a higher number of particle-hole pairs than Eq. (36). Hence, the edge of support in this region coincides with the shifted and inverted mass shell  $-\xi(2k_F - k)$ .

The threshold configuration consists of a hole at momentum  $2k_F - k$  and two particles with momenta infinitesimally close to  $k_F$ . Hence, the Hamiltonian must be projected onto narrow bands (of widths  $k_0 \ll k - k_F$ ) around these momenta. However, the initial particle with momentum k is outside this band structure, so the operator  $\Psi_k^{\dagger}$  would vanish in a naïve projection of the form (17). The solution is to use a Schrieffer-Wolff transformation (Schrieffer and Wolff, 1966) to derive a projection which is of first order in the interactions. Then, it can be shown explicitly that the particle at momentum k creates the threshold configuration (Khodas et al., 2007b),

$$\Psi_k^{\dagger} \propto \sum_{k_1, k_2} \psi_{R, k_1}^{\dagger} \psi_{R, k_2}^{\dagger} d_{k_1 + k_2},$$
 (38)

where  $k_1, k_2 \ll k_0$ . The impurity operator d creates a hole near momentum  $2k_F - k$ , whereas the operators  $\psi_{R,k_{1,2}}^{\dagger}$  create particles close to the right Fermi point. The fact that a single incoming particle now has to form three excitations in order to be able to tunnel into the system opens up the phase space available for the process, due to the free variables  $k_1$  and  $k_2$  in the projection (38). The spectral function in the vicinity of the edge is proportional to the Fourier transform of  $\langle \Psi_k(t) \Psi_k^{\dagger}(0) \rangle$ . Neglecting the interactions between the subbands, a direct calculation of this correlator using Eq. (38) leads to  $A(k,\varepsilon) \propto [\varepsilon + \xi(2k_F - k)]^3$ , i.e., a convergent threshold behavior. An increased number of excitations in the projection of the physical fermion operators, as required at momenta  $|k| > k_F$ , generally leads to more convergent power-laws. It is a recurring feature that all thresholds are characterized by configurations in which the entire energy is carried by a single particle or hole, while additional particle-hole pairs reside close to the Fermi points.

Interactions between the impurity d and the particles near the Fermi points again lead to a correction to this exponent. Using a mobile impurity Hamiltonian, the ensuing calculation is analogous to the previous discussion. The operator  $\Psi_k^{\dagger}$  can be bosonized as  $\Psi_k^{\dagger} \propto e^{2i(\phi-\theta)}d$ , and the spectral function near the edge behaves as

$$A(k,\varepsilon) \propto \theta[\varepsilon + \xi(2k_F - k)][\varepsilon + \xi(2k_F - k)]^{-\mu_{1,+}},$$
 (39)

where

$$\mu_{1,+} = 1 - \left(2 + \frac{\delta_+}{2\pi}\right)^2 - \left(\frac{\delta_-}{2\pi}\right)^2 \approx -3 - \frac{2\delta_+}{\pi}.$$
 (40)

The thresholds in the other sectors of the  $(k, \varepsilon)$ -plane can be derived similarly. The support of the spectral function in the weakly interacting limit and the lowest-energy configurations at the respective edges are displayed in Fig. 4.

The configurations which give rise to singularities at the edges of support are always stable: they represent the excitations of lowest energy for a given momentum and are thus protected from decay by conservation laws. On the other hand and in striking contrast to the non-interacting case, the mass shell  $\xi(k)$  no longer forms the edge of support for momenta  $k > k_F$ . Instead, it now lies within a continuum of excitations. Therefore, particles on the mass shell are generally subject to decay. In the spectral function, this will give rise to a broadening of the singularity at  $\varepsilon = \xi(k)$ . This will be discussed more in detail in Sec. IV.A.

# B. The universal limit of nonlinear Luttinger liquids

The analysis presented in the previous section predicts the dynamic response functions for weakly interacting Fermi systems at arbitrary momenta. In many realistic systems, however, the interaction energy can be of the same order as the kinetic energy, thus making perturbation theory inapplicable. To treat such systems, having a theory which accounts for the interactions exactly would be desirable. If the fermionic spectrum is strictly linear, all dynamic response functions at low energies can be calculated exactly (Dzyaloshinskii and Larkin, 1974; Luther and Peschel, 1974). Close to Fermi points, it is tempting to consider the band curvature as a small perturbation to the linear spectrum. The resulting corrections to singlevariable correlation functions (for example in the fermion distribution function  $n_k = \langle \Psi_k^{\dagger} \Psi_k \rangle$  are indeed uniformly small. This is not the case, however, for the dynamic response functions. We will see here that the true values of the threshold exponents are different from the predictions of the linear LL theory even in the limit  $|k| \to k_F$  (Imambekov and Glazman, 2009b). The frequency domain near the threshold where these strong deviations take place, narrows down as  $(|k| - k_F)^2$ .

Phenomenological bosonization is the obvious approach to tackle a strongly interacting 1D system in the low-energy regime (Efetov and Larkin, 1975; Haldane, 1981a,b). This approach is based on rephrasing the fermionic problem in a bosonic language using the bosonization identities (19) and (23). Using this basis offers the advantage that a density-density interaction between the physical fermions produces a quadratic term in the bosonic variables. At low energies, where only degrees of freedom close to the Fermi points are involved, bosonization allows an exact treatment of the interaction.

However, for the quadratic spectrum (2) the kinetic energy becomes more complicated when expressed using the bosonic fields  $\theta(x)$  and  $\phi(x)$ . The kinetic energy density of an ideal gas in the ground state can be calculated by integrating the spectrum  $\xi(k)$  over  $k \in [-k_F, k_F]$ . Local fluctuations of the left and right particle densities shift the Fermi points,  $k_F^{R,L}(x) = \pm [k_F + \pi \rho_{R,L}(x)]$ , and

therefore change this energy density. By expressing the density fluctuations using Eq. (23), the kinetic Hamiltonian can be derived. Near the two Fermi points, the spectrum for noninteracting fermions can be expanded as  $\xi(k) \approx v_F(\pm k - k_F) + (k \mp k_F)^2/(2m)$ . Its linear component together with the interaction term produces the conventional LL Hamiltonian,

$$H_{\rm LL} = \frac{v}{2\pi} \int dx \left[ K(\nabla \theta)^2 + \frac{1}{K} (\nabla \phi)^2 \right], \quad (41)$$

where v denotes the renormalized Fermi velocity, and K is the Luttinger parameter, which is in the interval 0 < K < 1 for repulsive interactions. For the noninteracting system, K = 1 and  $v = v_F$ . The quadratic component of the spectrum, on the other hand, leads to cubic terms in the bosonic fields (Haldane, 1981b),

$$H_{nl} = -\frac{1}{6\pi m} \int dx \left[ (\nabla \phi)^3 + 3(\nabla \phi)(\nabla \theta)^2 \right]. \tag{42}$$

As soon as the cubic band curvature terms are taken into account, an exact diagonalization of the Hamiltonian  $H_{\rm LL} + H_{nl}$  in terms of the fields  $\phi$  and  $\theta$  is no longer possible. The most obvious route is to treat  $H_{nl}$ , which is proportional to 1/m, as a perturbation. Diagrammatically, the terms in Eq. (42) correspond to three-boson interaction vertices. It turns out, however, that such an endeavor is far from trivial because the bosonic self-energy diverges at the mass shell  $\omega = vk$  (Samokhin, 1998). The physical reason is the linear spectrum of the bosonic modes: all bosonic excitations propagate with the same velocity v independent of their momentum and therefore - semiclassically speaking - have an infinite time to interact.

This difficulty precludes a straightforward calculation of the DSF near the mass shell. Far away from the mass shell  $(\omega \gg vq)$ , on the other hand, the perturbation theory in the band curvature is convergent and a high-energy tail in  $S(q,\omega)$  emerges in the order  $(1/m)^2$  (Pereira *et al.*, 2007). For small nonzero interactions, this agrees with the perturbative result (32).

An expansion of the free-fermion result (10) in orders of 1/m reveals that each individual term of the series diverges at the mass shell. Therefore, in order to access  $S(k,\omega)$  close to the mass shell, an efficient resummation scheme is required. Standard procedures like the Born approximation fail because they still produce a divergence at  $\omega = vq$ . Various approximate schemes have been developed (Aristov, 2007; Pirooznia and Kopietz, 2007; Pirooznia et al., 2008; Schönhammer, 2007; Teber, 2007), but even the free-fermion result has been reproduced in the bosonic basis only up to the order  $(1/m)^4$  (Pereira et al., 2007).

Many of the complications which plague the bosonic perturbation theory can be avoided by using a basis of fermionic quasiparticles (Mattis and Lieb, 1965; Rozhkov, 2005). Similar to the bosonic fields, the quasiparticles remain free in the case of a strictly linear spectrum whereas a nonzero band curvature of the underlying particles, together with the inter-particle interactions, leads to interactions between the fermionic quasiparticles. In contrast to the bosonic theory, however, the spectrum nonlinearity of the physical fermions also entails a band curvature of the quasiparticles. Hence, quasiparticles with different momenta propagate at different velocities. We will see that the scattering between them at momenta close to the Fermi points can be treated, for instance, within the Born approximation. Moreover, the use of a fermionic basis allows again the introduction of a mobile impurity Hamiltonian and thus connects to the method employed in the perturbative calculation.

To illustrate the origin of the fermionic quasiparticle representation of the Luttinger model, let us diagonalize the Hamiltonian (41) by introducing the rescaled fields

$$\tilde{\theta}(x) = \sqrt{K}\theta(x), \quad \tilde{\phi}(x) = \phi(x)/\sqrt{K}.$$
 (43)

Since this is a canonical Bogoliubov transformation, the fields  $\tilde{\theta}(x)$  and  $\tilde{\phi}(x)$  are still canonically conjugate. In the new variables  $\tilde{\theta}$  and  $\tilde{\phi}$ , the Hamiltonian is indistinguishable from the bosonized version of the Hamiltonian of free fermions with linear spectrum. These free left- and right-moving fermionic quasiparticles can be defined by using the bosonization identity (Haldane, 1981b; Luther and Peschel, 1974; Mattis, 1974) on the rescaled fields,

$$\tilde{\Psi}_{\alpha}(x) \propto \exp\{-i[\alpha\tilde{\phi}(x) - \tilde{\theta}(x)]\},$$
 (44)

for  $\alpha=R, L=+,-$ . Here  $\tilde{\Psi}_{R(L)}^{\dagger}, \tilde{\Psi}_{R(L)}$  are creation and annihilation operators for quasiparticles on the right (left) branch, satisfying usual fermionic commutation relations [as usually, we didn't write out the Klein factors explicitly (Giamarchi, 2004)]. In terms of quasiparticles,  $H_{\rm LL}$  becomes

$$H_{\rm LL} = -iv \int dx \left[ : \tilde{\Psi}_R^{\dagger}(x) \nabla \tilde{\Psi}_R(x) : - : \tilde{\Psi}_L^{\dagger}(x) \nabla \tilde{\Psi}_L(x) : \right]. \tag{45}$$

Colons indicate the normal ordering with respect to filled Fermi seas: for the right (left) branch all states with negative (positive) momenta are occupied. The relations between  $\tilde{\rho}_{R(L)}$  and  $\rho_{R(L)}$  are linear, and follow from Eqs. (23) and (43).

To proceed further, we need relations between  $\tilde{\Psi}_{R(L)}$  and  $\Psi_{R(L)}$ . Since both  $\tilde{\Psi}_R$  and  $\Psi_R$  carry momentum  $+k_F$  and change the total number of particles by one,  $\Psi_R$  should contain  $\tilde{\Psi}_R$  and low-energy particle-hole pairs. Using the bosonization formula for expressing  $\Psi_{R,L}$  in terms of  $\tilde{\phi}$  and  $\tilde{\theta}$ , and using Eq. (44) to "pull out" an operator  $\tilde{\Psi}_R$ , one finds for right-movers

$$\Psi_R(x) = F_R(x)\tilde{\Psi}_R(x). \tag{46}$$

An analogous expression holds for the left-movers. The string operator  $F_R(x)$  is an exponential of the left-moving and right-moving quasiparticle densities (23),

$$F_R(x) = \exp\left\{-i\int_{-\infty}^x dy [\delta_+\tilde{\rho}_R(y) + \delta_-\tilde{\rho}_L(y)]\right\}. \quad (47)$$

The described refermionization procedure defines uniquely the two parameters

$$\frac{\delta_{+}}{2\pi} = 1 - \frac{1}{2\sqrt{K}} - \frac{\sqrt{K}}{2} < 0, \ \frac{\delta_{-}}{2\pi} = \frac{1}{2\sqrt{K}} - \frac{\sqrt{K}}{2}. \ \ (48)$$

According to Eq. (46), the annihilation of a physical right-moving fermion in the liquid causes the annihilation of a right-moving quasiparticle. In addition it leads to a shake-up of the Fermi seas of the left-moving and right-moving quasiparticles which is described by  $F_R$ . The parameters  $\delta_{\pm}$  can be interpreted as the phase shifts for the scattering of quasiparticles at  $\pm k_F$  off the right-moving hole in the quasiparticle distribution.

The mapping between the interacting physical fermions and the noninteracting fermionic quasiparticles can also be performed directly via a unitary transformation (Mattis and Lieb, 1965; Rozhkov, 2005), without invoking bosonization as an intermediate step, and produces identical results. The Hamiltonian (45) together with Eqs. (47) and (48) reproduces the usual results for the fermionic Green's function (Rozhkov, 2005).

The quadratic spectrum (2) of the physical fermions leads to additional terms in the quasiparticle Hamiltonian. Most importantly, a quadratic term emerges in the quasiparticle spectrum (Rozhkov, 2006, 2008, 2009). It is reflected in the Hamiltonian

$$H'_{nl} = \frac{1}{2\tilde{m}} \int dx \left[ : (\nabla \tilde{\Psi}_R^{\dagger} \nabla \tilde{\Psi}_R) : + : (\nabla \tilde{\Psi}_L^{\dagger} \nabla \tilde{\Psi}_L) : \right]. \tag{49}$$

The effective mass  $\tilde{m}$  depends on interactions, and using the methods described in Sec. II.C, it is possible to express it via low energy properties as (Pereira *et al.*, 2006)

$$\frac{1}{\tilde{m}} = \frac{v}{K} \frac{\partial}{\partial \mu} (v\sqrt{K}),\tag{50}$$

where  $\mu$  is the chemical potential. From Eqs. (45) and (49), the quasiparticle mass shell for  $k \approx k_F$  is given by

$$\tilde{\xi}(k) = v(k - k_F) + \frac{(k - k_F)^2}{2\tilde{m}}.$$
 (51)

In addition, a spectrum curvature of and interactions between the physical fermions generally lead to interactions between the fermionic quasiparticles. One such term describes an interaction between quasiparticles on opposite branches (Rozhkov, 2006),

$$H'_{int} = i\tilde{g} \sum_{\alpha = R,L} \int dx \tilde{\rho}_{-\alpha} \left[ : \tilde{\Psi}^{\dagger}_{\alpha}(\nabla \tilde{\Psi}_{\alpha}) : - : (\nabla \tilde{\Psi}^{\dagger}_{\alpha}) \tilde{\Psi}_{\alpha} : \right].$$
(52)

In order to understand the effect of this term, we consider the scattering phase shift between two quasiparticles with momenta  $p + k_F$  ( $|p| \ll k_F$ ) and  $-k_F$  as in Sec.II.A. Fourier transforming Eq. (52) reveals that for small p, the interaction potential is proportional to p. This has to be compared with the difference in velocities, which according to Eq. (51) is finite and close to  $2v_F$ . Therefore, the term (52) produces only small additional phase shifts of order  $p/k_F \ll 1$ .

Another interaction term can appear as a consequence of a momentum dependence of the physical interaction potential. It corresponds to a density-density interaction between quasiparticles on the same branch (Imambekov and Glazman, 2009b),

$$H_{int}'' = \sum_{\alpha = R, L} \int_{|p| \ll k_F} dp \tilde{W}(p) \tilde{\rho}_{\alpha}(p) \tilde{\rho}_{\alpha}(-p).$$
 (53)

The Luttinger parameter K already accounts for interaction processes with momentum exchange close to zero, so the additional quasiparticle interaction potential must fulfill  $\tilde{W}(0) = 0$ . Moreover, it should be symmetric  $\tilde{W}(p) = \tilde{W}(-p)$ . For small p, the scattering phase shift between two particles with momenta  $p + k_F$  and  $k_F$  is now of order  $\tilde{m}\tilde{W}(p)/p$ . This phase shift therefore becomes small for generic interaction potentials which fulfill  $\tilde{W}(p) \propto p^2$  for  $p \to 0$ . This requirement is only violated for real-space potentials decaying as  $\propto 1/x^2$  or slower. In particular, this excludes Haldane-Shastry (Haldane, 1988; Shastry, 1988) or Calogero-Sutherland (Calogero, 1969, 1971; Sutherland, 1971, 2004) type models.

The above arguments establish that Eqs. (45) and (49), written in terms of fermionic quasiparticles, serve as the universal low-energy Hamiltonian which captures the leading role of the spectrum nonlinearity. The crucial advantage of the quasiparticle representation is that unlike in bosonic extensions of the LL theory, the universal Hamiltonian does not contain interactions. The nonlinearity of the spectrum lifts the "accidental" degeneracies existing in the Luttinger model, and allows to treat small interaction terms (such as given in Eqs. (52) and (53)) in addition to the universal Hamiltonian within convergent perturbation theory. Surprisingly, the only additional phenomenological parameter is the effective mass  $\tilde{m}$ , which sets the energy scale for nonlinear effects. Below we will work out universal predictions for the lowenergy DSF and the spectral function beyond the linear spectrum approximation. We will show that the true values of the threshold exponents differ from predictions of the linear LL theory, but nevertheless can be expressed as functions of the LL parameter K only.

The relation between the total physical particle density and the total quasiparticle density is linear,  $\rho_L + \rho_R = \sqrt{K}[\tilde{\rho}_L + \tilde{\rho}_R]$ . Therefore, the shape of the DSF  $S(q, \omega)$  for  $q \ll k_F$  remains identical to the noninteracting result

(10), albeit with a renormalized mass  $\tilde{m}$ ,

$$S(q,\omega) = \frac{K\tilde{m}}{|q|} \theta \left( \frac{q^2}{2\tilde{m}} - |\omega - vq| \right)$$
 (54)

This agrees with the perturbative results (27) and (30) in the limit  $q \to 0$ . Power-law singularities at the upper and lower thresholds  $\omega_{\pm}(q) = vq \pm q^2/(2\tilde{m})$ , respectively, as well as a high-energy tail would be produced by the quasiparticle interaction term (52) which becomes relevant only beyond the limit  $q/k_F \ll 1$ .

Let us first investigate the spectral function  $A(k,\varepsilon)$  in the presence of band curvature in the hole sector  $(0 < k_F - k \ll k_F \text{ and } \varepsilon < 0)$ . In this region, the kinematic edge of support of  $A(k,\varepsilon)$  coincides with the mass shell (51), so we assume  $\varepsilon \approx \xi(k)$ . According to Eq. (46), the extraction of a physical particle with momentum k from the system leads to the formation of a quasiparticle hole with momentum near k on mass shell, and the excess energy is used for the formation of excitations near the Fermi points. In analogy to the previous section, the Hamiltonian (45)-(49) as well as the single-particle operator (46) should be projected onto small bands around the momenta  $\pm k_F$  and k. The right-moving quasiparticle operator is projected as

$$e^{ik_Fx}\tilde{\Psi}_R(x) \to e^{ik_Fx}\tilde{\psi}_R(x) + e^{ikx}\tilde{d}(x)$$
 (55)

and  $\tilde{\Psi}_L(x) \to \tilde{\psi}_L(x)$  is used for left-movers; here,  $\tilde{\psi}_{R,L}(x)$  denote quasiparticles within a narrow momentum range around the Fermi points  $^1$ , while  $\tilde{d}(x)$  denotes an impurity with momentum close to k. Projecting the string operators  $F_R(x)$  requires a projection of the quasiparticle densities  $\tilde{\rho}_{\alpha}(x) = \tilde{\Psi}^{\dagger}_{\alpha}(x)\tilde{\Psi}_{\alpha}(x)$  in Eq. (47). This produces terms containing the quasiparticle densities in the narrow bands around the Fermi points,  $\tilde{\psi}^{\dagger}_{\alpha}(x)\tilde{\psi}_{\alpha}(x)$ . In addition, the projection leads to impurity terms of the form  $\tilde{d}^{\dagger}(x)\tilde{d}(x)$  and mixed terms  $\tilde{\psi}^{\dagger}_{\alpha}(x)\tilde{d}(x)$ . However, the former is a constant, and the latter can be neglected close to the edges because they require a higher energy. Therefore, projecting the string operators corresponds to replacing  $\tilde{\rho}_{\alpha}(x)$  in Eq. (47) with  $\tilde{\psi}^{\dagger}_{\alpha}(x)\tilde{\psi}_{\alpha}(x)$ .

A projection of the kinetic Hamiltonian  $H_{LL} + H'_{nl}$  onto the three subbands leads to the mobile impurity Hamiltonian  $H_0 + H_d$ , where

$$H_{0} = -iv \int dx \left[ : \tilde{\psi}_{R}^{\dagger}(x) \nabla \tilde{\psi}_{R}(x) : - : \tilde{\psi}_{L}^{\dagger}(x) \nabla \tilde{\psi}_{L}(x) : \right],$$

$$H_{d} = \int dx \tilde{d}^{\dagger}(x) \left[ \tilde{\xi}(k) - iv_{d} \nabla \right] \tilde{d}(x), \tag{56}$$

![](_page_14_Figure_10.jpeg)

FIG. 5 (Color online) Band structure for right-movers used for the calculation of  $A(k,\varepsilon)$  for  $0 < k_F - k \ll k_F$  and  $\varepsilon < 0$ , see Eq. (55). It contains the impurity band near momentum k and a low-energy band near the right Fermi point  $+k_F$ . The injection of a hole with momentum k and energy  $\varepsilon$  into the system leads to the formation of a hole (empty circle) with momentum near k on the mass shell, as well as a particle-hole pair near the Fermi point. For  $|\varepsilon - \tilde{\xi}(k)| \ll (k - k_F)^2/(2\tilde{m})$ , the subbands are well separated and the mobile-impurity Hamiltonian can be applied.

where the impurity velocity is  $v_d = \partial \tilde{\xi}(k)/\partial k$ . Note that the requirement that the impurity band be separated from the low-energy bands means that this mobile impurity Hamiltonian can be used to calculate the spectral function at energies  $\varepsilon$  satisfying  $|\varepsilon - \tilde{\xi}(k)| \ll (k - k_F)^2/(2\tilde{m})$ . This is illustrated in Fig. 5.

Then, the spectral function in the region  $0 < k_F - k \ll k_F$  and  $\varepsilon < 0$  becomes

$$A(k,\varepsilon) = \int dt dx e^{-i\varepsilon t} \langle \tilde{d}^{\dagger}(x,t)\tilde{d}(0,0)\rangle$$

$$\times \langle F_R^{\dagger}(x,t)F_R(0,0)\rangle$$
(57)

The impurity correlation function can easily be calculated using the noninteracting Hamiltonian  $H_d$ . The free string correlation function can most conveniently be derived by bosonizing  $H_0$  and  $F_R$ . One finds that  $A(k,\varepsilon) \propto \theta(\tilde{\xi}(k)-\varepsilon)[\varepsilon-\tilde{\xi}(k)]^{-\mu_{0,-}}$ , where

$$\mu_{0,-} = 1 - \left(\frac{\delta_{-}}{2\pi}\right)^2 - \left(\frac{\delta_{+}}{2\pi}\right)^2.$$
 (58)

As in the previous section, one of the consequences of a nonlinear spectrum with  $\tilde{m} > 0$  is that the edge of support of the spectral function in the particle sector no longer coincides with the quasiparticle mass shell  $\tilde{\xi}(k)$  but rather with the shifted and inverted quasiparticle spectrum. For instance, for  $0 < k - k_F \ll k_F$ , the threshold is given by  $-\tilde{\xi}(2k_F - k)$ . The threshold configuration generated at this edge contains a quasihole with momentum  $2k_F - k < k_F$ , as well as two

<sup>&</sup>lt;sup>1</sup> Hereinafter, we reserve the upper-case symbols  $\tilde{\Psi}_{L,R}(x)$  and the lower-case symbols  $\tilde{\psi}_{L,R}(x)$  for operators before and after the projection, respectively

quasiparticles with total momentum  $2k_F$ . The powerlaw at this threshold can be derived using the same mobile-impurity Hamiltonian (56) but the projection of the quasiparticle operator has to be done analogous to Eq. (38). Due to the creation of additional particles, the spectral function at this edge is convergent. One finds  $A(k,\varepsilon) \propto \theta(\varepsilon + \tilde{\xi}(2k_F - k))[\varepsilon + \tilde{\xi}(2k_F - k)]^{-\mu_{1,+}}$ , where

$$\mu_{1,+} = 1 - \left(\frac{\delta_{-}}{2\pi}\right)^2 - \left(2 + \frac{\delta_{+}}{2\pi}\right)^2.$$
 (59)

Similar to the weakly interacting case, the singularity at the mass shell for  $k > k_F$  and  $\varepsilon \approx \xi(k)$  now lies within a continuum of excitations. Since interactions neglected in the universal Hamiltonian generally lead to a nonzero decay rate for quasiparticles on mass shell, one may expect that the singularity may be smeared. Within perturbation theory, the decay rate close to the Fermi points scales as  $\Gamma \propto (k - k_F)^8$  (Khodas et al., 2007b), and will be discussed in detail in Sec. IV.A. However, the power-law behavior is expected to be observable within an energy window of width  $(k - k_F)^2/(2\tilde{m})$  around the mass shell (Imambekov and Glazman, 2009b). Therefore, the singularity is indeed resolved for  $k \to k_F$ . Using the mobile-impurity Hamiltonian, one finds power laws with identical exponents on both sides of the mass shell,  $A(k,\varepsilon) \propto |\varepsilon - \xi(k)|^{-\mu_{0,-}}$ , where the exponent is given by Eq. (58). Despite the fact that the exponents on both sides of the singularity are identical, the prefactors are not. It can be shown that (Imambekov and Glazman, 2009b)

$$\lim_{\delta \varepsilon \to 0} \frac{A[k, \tilde{\xi}(k) + \delta \varepsilon]}{A[k, \tilde{\xi}(k) - \delta \varepsilon]} = \frac{\sin\left[\pi \left(\frac{\delta_{-}}{2\pi}\right)^{2}\right]}{\sin\left[\pi \left(\frac{\delta_{+}}{2\pi}\right)^{2}\right]}.$$
 (60)

The exponents at the mass shell are identical in the particle and hole sectors, and they differ from the predictions of the linear LL theory. As has been established in Sec. II.A.2, the expansion of the exponent (58) to leading order in K-1 coincides with the Luttinger model prediction (62). However, a difference to the LL exponent emerges in the order  $(K-1)^4$ , and is of order one for strong interactions  $(|K-1| \sim 1)$ .

The result of the linear LL theory is recovered for energies further above the mass shell,  $\varepsilon - \tilde{\xi}(k) \gg (k - k_F)^2/(2\tilde{m})$ . As illustrated in Fig. 5, in this regime the momentum bands encountered in the projection start to overlap, and the mobile-impurity Hamiltonian ceases to be applicable. From the point of view of an incoming particle, the band curvature becomes irrelevant at these energy scales. Therefore, the spectral function can be calculated using

$$A(k,\varepsilon) \propto \int dt dx e^{i\varepsilon t} e^{-ikx}$$

$$\times \langle \tilde{\psi}_R^{\dagger}(x,t) F_R^{\dagger}(x,t) F_R(0,0) \tilde{\psi}_R(0,0) \rangle, \qquad (61)$$

and by assuming that the quasiparticle spectrum is linear. In this case, the time evolution of the quasiparticle densities becomes simple,  $\tilde{\rho}_{\alpha}(x,t) = \tilde{\rho}_{\alpha}(x-\alpha vt)$  and allows for a calculation of the dynamics of the string operator  $F_R(x,t)$ . This makes it possible to calculate Eq. (61) in the basis of fermionic quasiparticles (Rozhkov, 2005). Alternatively, Eq. (61) with a linear spectrum may be calculated by bosonizing it. As a result, for  $\varepsilon - \tilde{\xi}(k) \gg (k-k_F)^2/(2\tilde{m})$  one finds  $A(k,\varepsilon) \propto [\varepsilon - \tilde{\xi}(k)]^{-\mu_{\rm LL}}$  with the LL exponent

$$\mu_{\rm LL} = 1 - \left(\frac{\delta_{-}}{2\pi}\right)^2 = 1 - \frac{1}{4}\left(K + \frac{1}{K} - 2\right).$$
(62)

Compared to the exponent  $\mu_{0,-}$  near the mass shell, see Eq. (58), the  $\delta_+$  term is missing. The phase  $\delta_+$  is the scattering phase shift for interactions between the impurity at momentum  $k \approx k_F$  and particles near the right Fermi point. Because the impurity band around k and the band around  $+k_F$  start to merge for energies further away from the mass shell, this phase is absent in Eq. (62). The phase  $\delta_-$ , in contrast, is brought about by interactions with particles near the left Fermi point, and continues to be present.

Understanding the crossover between regions with exponents (59), (58) and (62) requires a calculation of  $A(k,\varepsilon)$  at intermediate energies. Due to kinematic constraints, only the nonlinearity of the spectrum of rightmovers is important for  $k > k_F$  and  $\varepsilon > \tilde{\xi}(k)$ . Therefore, an analysis of the exact dynamics of the string operators  $F_R(x)$  is needed. Similar correlators have attracted attention recently in connection with the nonlinear quantum shock wave dynamics of a free Fermi gas (Bettelheim et al., 2006a,b; Bettelheim et al., 2007; Bettelheim et al., 2008). Even though the quasiparticles are noninteracting, this is a highly nontrivial problem due to the nonlinear spectrum  $\xi(k)$ . since it is essentially a single-particle problem, it can be mapped onto a calculation of certain infinite-size determinants (Abanin and Levitov, 2004, 2005) and then tackled numerically (Imambekov and Glazman, 2009b). The spectral function for momenta  $k \approx k_F$  at arbitrary energies  $\varepsilon$  can be written as a function of a single variable,

$$A(k,\varepsilon) \propto A(x)$$
, where  $x = \frac{\varepsilon - v(k - k_F)}{(k - k_F)^2/(2\tilde{m})}$ , (63)

where the function A(x) depends only on the Luttinger parameter K. In this sense, for momenta close to the Fermi points, the universality present in the linear LL theory persists even in the presence of band curvature. The results of a numerical evaluation of A(x) for a particular value of K are shown in Fig. 6.

Note that the width of the energy window where the exponent differs from the predictions of the linear LL theory is proportional to  $(k-k_F)^2$ . The fact that this width vanishes quadratically for  $k \to k_F$  is consistent with the

![](_page_16_Figure_1.jpeg)

FIG. 6 The numerically evaluated function A(x), see Eq. (63), for a fixed value of the Luttinger parameter K = 4.54 (corresponding to δ+/(2π) = −0.3). This function determines the behavior of A(k, ε) in the crossover region between the threshold (left end) and the linear Luttinger liquid (LL) asymptotes.

irrelevance of the band curvature in the universal limit k → k<sup>F</sup> .

# C. Phenomenology beyond the low-energy limit: the mobile quantum impurity model

In Sec. II.A, the dynamic response functions were calculated perturbatively for weak interactions and at arbitrary momenta. A complementary result, valid for arbitrary interactions but only close to the Fermi points, was derived in Sec. II.B. In this section, the basic ideas of the two approaches, refermionization and the use of a quantum impurity model, will be combined in order to obtain phenomenological relations determining the exponents of the threshold singularities at arbitrary interaction strengths and momenta.

To be specific, let us discuss the edge of support of the spectral function in the momentum region |k| < k<sup>F</sup> in the hole sector, i.e., for energies ε < 0. For a given k, the creation of a hole will generally require a nonzero minimum energy. At zero temperature, this entails the existence of a sharp edge of support which we will denote by εth(k), see Fig. 4 for an illustration. The extraction of a physical particle is impossible for |ε| < |εth(k)|. For a generic system with arbitrary interaction potential, the exact shape of εth(k) is not known, because it is related to the exact eigenenergies which crucially depend on the microscopic nature of the interactions.

For noninteracting systems at zero temperature, the Fermi momentum k<sup>F</sup> is defined as the momentum of the highest occupied single-particle state in the Fermi sea. The concept of a Fermi momentum can be extended to gapless interacting systems by defining k<sup>F</sup> as the smallest positive momentum k for which A(k, ε = 0) 6= 0, i.e., at momentum ±k<sup>F</sup> , the system is capable of absorbing even infinitesimal quanta of energy. Applied to this definition, the Luttinger theorem (Blagoev and Bedell, 1997; Luttinger, 1960; Yamanaka et al., 1997) ensures that the

value of k<sup>F</sup> is independent of the interaction strength. Therefore, the edge of support still satisfies εth(±k<sup>F</sup> ) = 0 even in an interacting system.

In Sec. II.A and Sec. II.B, it was established for weak interactions and for momenta close to Fermi points for arbitrary interactions, that the behavior of the spectral function near the edges of support can be understood by introducing effective models of impurities moving in LLs. It is important to emphasize that, similar to Fermi liquid quasiparticles, such impurities have a finite overlap with the original fermionic operators, and possess the same quantum numbers. Extracting a physical fermion with momentum k and energy close to εth(k) creates an impurity with momentum near k which carries almost the entire energy, as well as additional low-energy excitations near Fermi points. It is not the overlap between the impurity and the fermion, but the "shake-up" of lowenergy modes near Fermi points which causes the powerlaw divergences in the spectral function as a function of the excess energy εth(k) − ε > 0.

Combining these two limits, we may expect that even away from the low-energy limit for arbitrary interactions, the threshold properties of response functions near the edges of support can be described in terms of mobileimpurity Hamiltonians (Pereira et al., 2008). For this purpose, the interacting Hamiltonian is projected onto a band structure which contains two subbands around the Fermi points ±k<sup>F</sup> and one mobile-impurity subband around the momentum k. By continuity from the limit of the universal nonlinear LL, this impurity must carry the same quantum numbers as the fermion, and its overlap with the fermion must be finite. The width of all subbands is small compared to the distance between k and the Fermi points, so the spectra in all subbands can be linearized. The low-energy excitations near ±k<sup>F</sup> can be modeled using a linear LL Hamiltonian with Fermi velocity v and Luttinger parameter K. In analogy to the previous section, the mobile impurity Hamiltonian thus becomes for |k| < k<sup>F</sup> ,

$$H_0 = \frac{v}{2\pi} \int dx \left[ K(\nabla \theta)^2 + \frac{1}{K} (\nabla \phi)^2 \right],$$
  

$$H_d = \int dx \ d^{\dagger}(x) \left[ \varepsilon_{\text{th}}(k) - i v_d \nabla \right] d(x).$$
 (64)

It is assumed throughout the paper that microscopic interactions decay faster than ∝ 1/x, so that compressibility and sound velocity are finite. The impurity velocity is given by v<sup>d</sup> = ∂εth(k)/∂k. In general, there are interactions between the impurity and right- and left-moving particles near the Fermi points,

$$H_{int} = \int dx \left[ V_R(k) \rho_R(x) + V_L(k) \rho_L(x) \right] d(x) d^{\dagger}(x)$$
$$= \int dx \left[ V_R(k) \nabla \frac{\theta - \phi}{2\pi} - V_L(k) \nabla \frac{\theta + \phi}{2\pi} \right] dd^{\dagger}.$$
 (65)

Unlike in the perturbative regime, Eq. (21), where  $V_R(k)$  and  $V_L(k)$  can be directly evaluated, here they have to be treated as momentum-dependent phenomenological parameters. Similar to Sec. II.A, they determine the exponents of threshold singularities in all dynamic response functions.

The Hamiltonian (64)-(65) was derived from simple phenomenological considerations, and provides a generalization of the LL theory beyond the low-energy limit. We note that effective quantum impurity Hamiltonians have been used before in the literature to describe the response properties when the effective impurity belongs to a band different from the one which forms the LL (Balents, 2000; Carmelo et al., 1999; Castella and Zotos, 1993; Friedrich et al., 2007; Furusaki and Zhang, 1999; Lamacraft, 2009; Mishchenko and Starykh, 2011; Sorella and Parola, 1996, 1998). Here we extend their application to the case when both bands coincide. Similarly to the case of a conventional LL, the Hamiltonian (64)-(65) predicts not only the edge exponents in terms of  $V_R(k)$ and  $V_L(k)$ , but also the structure of the finite-size theory (see Sec. II.G). For integrable models, some finite-size properties can be analytically extracted from the exact solutions (Cheianov and Pustilnik, 2008; Imambekov and Glazman, 2008; Karimi and Affleck, 2011; Pereira et al., 2008, 2009; Shashi et al., 2010; Zvonarev et al., 2009b), and in combination with Eqs. (64)-(65) lead to nonperturbative predictions for the edge exponents. Various examples of this procedure will be reviewed in Sec. III. In the rest of this section, we will describe an alternative procedure to phenomenologically relate the edge exponents to  $\varepsilon_{\rm th}(k)$  only, which works for generic Galilean invariant systems (Imambekov and Glazman, 2009a).

Basically, the parameters  $V_R(k)$  and  $V_L(k)$  can be fixed by considering the shift of the edge  $\varepsilon_{\rm th}(k)$  as a reaction to a uniform density variation and to a Galilean boost. These variations change  $\rho_R$  and  $\rho_L$ , and the resulting change in  $\varepsilon_{\rm th}(k)$  is determined by  $V_R(k)$  and  $V_L(k)$ . First, consider the effect of a uniform variation of the system density  $\delta \rho$ . Because the edge of support is measured with respect to the chemical potential  $\mu$ , its position shifts by

$$\delta E = \left[ \frac{\partial \varepsilon_{\rm th}(k)}{\partial \rho} + \frac{\partial \mu}{\partial \rho} \right] \delta \rho = \left[ \frac{\partial \varepsilon_{\rm th}(k)}{\partial \rho} + \frac{\pi v}{K} \right] \delta \rho. \quad (66)$$

The second equality follows from the general result for the compressibility of a LL (Giamarchi, 2004). Next,  $\delta E$  is calculated using the mobile impurity Hamiltonian (64)-(65), where a uniform density variation leads to a nonzero expectation value  $\langle \nabla \phi \rangle = -\pi \delta \rho$ . We use this Hamiltonian to calculate the energy of a state containing an impurity at momentum k, and compare the energies with and without the density variation  $\delta \rho$ . A difference only emerges in  $\langle H_{int} \rangle$  because it contains a term linear

in  $\langle \nabla \phi \rangle$ . The total shift in the energy of the state reads

$$\delta E = -\frac{V_R(k) + V_L(k)}{2} \delta \rho. \tag{67}$$

Equating the energy shifts (66) and (67) leads to  $V_R(k) + V_L(k) = -2[\partial \varepsilon_{\text{th}}(k)/\partial \rho + \pi v/K].$ 

A second equation is needed to fix the difference  $V_R(k) - V_L(k)$ . For Galilean invariant systems, it can be derived by considering the shift of the edge position as a response to a boost with a small velocity  $\delta u$  (Baym and Ebner, 1967). Let us consider a hole at the edge of support in the moving frame which has momentum k' and energy  $\varepsilon' = \varepsilon_{\rm th}(k')$ . Galilean invariance requires that in the rest frame it has momentum and energy

$$k = k' + m\delta u, \quad \varepsilon = \varepsilon' + k'\delta u + m\delta u^2/2.$$
 (68)

Since the hole was at the edge in the moving frame and the system is Galilean invariant, this also corresponds to the edge in the rest frame. Thus the shift of the threshold in the rest frame to linear order in  $\delta u$  equals

$$\delta E' = \left[ \varepsilon_{\rm th}(k - m\delta u) + (k - m\delta u)\delta u + m\delta u^2 / 2 - \varepsilon_{\rm th}(k) \right]$$

$$\approx \left[ k - m \frac{\partial \varepsilon_{\rm th}(k)}{\partial k} \right] \delta u. \tag{69}$$

Again, we can now calculate the same energy using the mobile impurity Hamiltonian (64)-(65). The boost changes the Fermi momenta of the right-moving and left-moving particles,  $k_F^{R,L} = \pm k_F + m\delta u$ , and thus leads to a difference between the densities of right- and left-movers. This, in turn, leads to a nonzero expectation value  $\langle \nabla \theta \rangle = m\delta u$ . Substituting this into Eq. (65), we calculate the energy of a state with impurity at momentum k with the help of Eqs. (64) and (65). Subtracting the corresponding energy for  $\delta u = 0$ , we find the energy shift due to the boost,

$$\delta E' = -\frac{V_R(k) - V_L(k)}{2\pi} m \delta u. \tag{70}$$

Combining Eqs. (69)-(70) leads to  $V_R(k) - V_L(k) = 2\pi [\partial \varepsilon_{\rm th}(k)/\partial k - k/m]$ . Thus, both interaction potentials  $V_{R,L}(k)$  can be expressed in terms of derivatives of the threshold  $\varepsilon_{\rm th}(k)$  for arbitrary momenta  $-k_F < k < k_F$ .

In order to calculate the dynamic correlation functions, the interaction Hamiltonian  $H_{int}$ , see Eq. (65), is removed like in Sec. II.A using a unitary transformation  $U^{\dagger}(H_0 + H_d + H_{int})U$ , where

$$U = \exp\left\{i \int dx \left(\frac{\delta_{+}(k)}{2\pi} [\tilde{\theta} - \tilde{\phi}] - \frac{\delta_{-}(k)}{2\pi} [\tilde{\theta} + \tilde{\phi}]\right) dd^{\dagger}\right\},$$
(71)

and  $\tilde{\theta}$  and  $\tilde{\phi}$  are defined in Eq. (43). Such a transformation removes  $H_{int}$  if the momentum dependent phase shifts  $\delta_{+}(k)$  and  $\delta_{-}(k)$  are chosen such that

$$\delta_{-}(k) = -\frac{\tilde{V}_L}{v_d + v}, \quad \delta_{+}(k) = -\frac{\tilde{V}_R}{v_d - v}, \tag{72}$$

where  $\tilde{V}_{L(R)}$  are the couplings which are obtained after rescaling the bosonic fields using Eq. (43). They are related to parameters of  $H_{int}$  by

$$(V_L - V_R) / \sqrt{K} = \tilde{V}_L - \tilde{V}_R, \tag{73}$$

$$(V_L + V_R)\sqrt{K} = \tilde{V}_L + \tilde{V}_R. \tag{74}$$

Using the expressions for  $V_R(k) \pm V_L(k)$ , they can now be expressed in terms of derivatives of  $\varepsilon_{\rm th}(k)$ ,

$$\frac{\delta_{\pm}(k)}{2\pi} = \frac{1}{2(\pm \frac{\partial \varepsilon_{\rm th}(k)}{\partial k} - v)} \left\{ \frac{1}{\sqrt{K}} \left[ \frac{k}{m} - \frac{\partial \varepsilon_{\rm th}(k)}{\partial k} \right] \right. \\
\pm \sqrt{K} \left[ \frac{1}{\pi} \frac{\partial \varepsilon_{\rm th}(k)}{\partial \rho} + \frac{v}{K} \right] \right\}.$$
(75)

These phase shifts have the following symmetry property:

$$\delta_{\pm}(k) = -\delta_{\mp}(-k) \text{ for } |k| < k_F. \tag{76}$$

The knowledge of the phase shifts allows the calculation of the edge singularities of  $A(k,\varepsilon)$  at arbitrary momenta. In the interval  $k \in [-k_F, k_F]$ , the edge of support for negative (positive) energies is located at  $\varepsilon = \varepsilon_{\rm th}(k)$  ( $\varepsilon = -\varepsilon_{\rm th}(k)$ ). A periodic continuation of the functions  $\pm \varepsilon_{\rm th}(k)$  yields the edge of support for arbitary k, as depicted in Fig. 4. Such thresholds, which can be constructed from  $\varepsilon_{\rm th}(k)$  in the main region  $k \in [-k_F, k_F]$  by using shifts and inversions, are called shadow bands. Hence, for  $(2n-1)k_F < k < (2n+1)k_F$  ( $n \in \mathbb{Z}$ ), the lower and upper edges of support are at the energy  $\varepsilon = \pm \varepsilon_{\rm th}(k_n)$ , respectively, where

$$k_n = k - 2nk_F \in [-k_F, k_F].$$
 (77)

Let us first discuss the hole sector,  $\varepsilon \approx \varepsilon_{\rm th}(k_n) < 0$ , at arbitrary k. The configuration responsible for the edge singularity can again be determined by requiring energy and momentum conservation. It contains an impurity hole on mass shell near momentum  $k_n$ , which carries almost the entire energy  $\varepsilon$ . The remaining momentum  $2nk_F$  is absorbed by creating n low-energy holes near the right Fermi point and n low-energy particles near the left Fermi point. Therefore, one projects the fermion operator as follows,

$$\Psi(x) \to e^{ikx} [\psi_L^{\dagger} \psi_R]^n d \propto e^{ikx} \exp[-2in\phi(x)] d(x), \quad (78)$$

where we used the bosonization formula  $\psi_{R,L} \propto \exp[-i(\pm \phi - \theta)]$ . In this sector, the spectral function is the Fourier transform of  $\langle \Psi^{\dagger}(0,0)\Psi(x,t)\rangle$  and its threshold singularities can be calculated using Eq. (78).

An analogous calculation is used in the particle sector,  $\varepsilon \approx -\varepsilon_{\rm th}(k_n) > 0$  at arbitrary k. Here, the threshold configuration is a generalization of the one used in the perturbative calculation in Eq. (38). For  $k_F < k < 3k_F$ , it contains an impurity hole at momentum  $-k_1 = 2k_F - k \in [-k_F, k_F]$  on mass shell, as well

as two particles close to the right Fermi point. Similarly, for general  $(2n-1)k_F < k < (2n+1)k_F$ , the impurity carries the momentum  $-k_n$ , and there are n+1 particles at the right Fermi point and n-1 holes at the left Fermi point. The corresponding projection now reads,

$$\Psi^{\dagger}(x) \to e^{ikx} [\psi_R^{\dagger} \psi_L]^{n-1} \psi_R^{\dagger} \psi_R^{\dagger} d$$

$$\propto e^{ikx} \exp[2in\phi(x)] \exp[-2i\theta(x)] d(x). \tag{79}$$

The spectral function can now be found by calculating the correlation function  $\langle \Psi(x,t)\Psi^{\dagger}(0,0)\rangle$  with the help of the diagonalized mobile-impurity Hamiltonian (64)-(65). Combining the particle and hole sectors, the spectral function near the edges of support  $\mp \varepsilon_{\rm th}(k_n)$  at arbitrary momentum k reads, respectively,

$$A(k,\varepsilon) \propto \theta[\varepsilon_{\rm th}(k_n) \pm \varepsilon]|\varepsilon_{\rm th}(k_n) \pm \varepsilon|^{-\mu_{n,\pm}(k)}.$$
 (80)

Here the threshold exponents are given by (Imambekov and Glazman, 2009a)

$$\mu_{n,\pm}(k) = 1 - \mu_{n,\pm,R} - \mu_{n,\pm,L},\tag{81}$$

where  $\mu_{n,\pm,R}$  and  $\mu_{n,\pm,L}$  denote the contributions due to left and right Fermi points. They are given by

$$\mu_{n,-,\alpha} = \left[ n\sqrt{K} - \delta_{\alpha}(k_n)/(2\pi) \right]^2, \tag{82}$$

$$\mu_{n,+,\alpha} = \left[ n\sqrt{K} + \alpha/\sqrt{K} + \delta_{\alpha}(-k_n)/(2\pi) \right]^2, \quad (83)$$

where  $\alpha=R, L=+,-$ . In conclusion, the spectral function at the edge of support still displays a sharp powerlaw even for momenta far away from the Fermi points. However, in contrast to the linear LL theory, the exponents become nonuniversal and momentum-dependent. In particular, they depend on the microscopic interactions not only through the Luttinger parameter K, but also through the phase shifts  $\delta_{\pm}(\pm k_n)$ , which according to Eq. (75) are determined by the shape of the edge  $\varepsilon_{\rm th}(k)$ .

Let us now turn to the DSF  $S(q,\omega)$ . The key to the calculation of its edge singularities is finding the correct projection of the density operator  $\rho(x) = \Psi^{\dagger}(x)\Psi(x)$ . It was shown in Eq. (54) that for  $q \to 0$ ,  $S(q,\omega)$  has a rectangular shape and the lower edge of support is at  $-\tilde{\xi}(k_F - q) = vq - q^2/(2\tilde{m})$ . The configuration which gives rise to this threshold consists of a hole on mass shell and a particle near the Fermi point. Therefore, by continuity the threshold for general momenta  $0 < q < 2k_F$  is at  $-\varepsilon_{\rm th}(k_F - q)$ , and the density operator must be projected to  $\rho(x) \propto \psi_R^{\dagger}(x)d(x)$ . Here,  $\psi_R^{\dagger}$  creates a particle near the right Fermi point and d creates a hole at momentum  $k_F - q$ .

Let us generalize this argument to arbitrary momenta,  $2nk_F < q < 2(n+1)k_F \ (n \in \mathbb{Z})$ . Because  $S(q,\omega)$  is symmetric, let us focus on  $q \geq 0$ . In analogy to the previous

paragraph, the configuration responsible for the edge singularity at momentum q now contains an impurity hole d at momentum

$$q_n = (2n+1)k_F - q \in [-k_F, k_F].$$
 (84)

Moreover, it contains n+1 particles near the right Fermi point and n holes near the left Fermi point. Therefore, the density operator for momenta near q is projected as

$$\rho(x) \to e^{iqx} \psi_R^{\dagger} [\psi_R^{\dagger} \psi_L]^n d$$

$$\propto e^{iqx} \exp[i(2n+1)\phi(x)] \exp[-i\theta(x)] d(x), \quad (85)$$

and  $S(q,\omega)$  can be found by calculating the correlation function  $\langle \rho(x,t)\rho(0,0)\rangle$  using the projection (85). The total energy of this configuration is close to  $-\varepsilon_{\rm th}(q_n)$ . Hence, as a result one finds that

$$S(q,\omega) \propto \theta[\omega + \varepsilon_{\rm th}(q_n)][\omega + \varepsilon_{\rm th}(q_n)]^{-\mu_n(q)}$$
 (86)

with a momentum-dependent exponent

$$\mu_n(q) = 1 - \mu_{n,R} - \mu_{n,L}, \qquad (87)$$

$$\mu_{n,\alpha} = \left[ \frac{(2n+1)\sqrt{K}}{2} + \frac{\alpha}{2\sqrt{K}} + \frac{\delta_{\alpha}(q_n)}{2\pi} \right]^2,$$

where  $\alpha = R, L = +, -$ , and  $\mu_{n,R}$  and  $\mu_{n,L}$  denote contributions due to left and right Fermi points.

For momenta close to  $\pm k_F$  and interaction potentials decaying faster than  $1/x^2$ , the results of this section reproduce the universal phase shifts of Sec. II.B at arbitrary interaction strength. Moreover, for  $V(x) \propto 1/x^2$ , the corresponding phase shifts confirm those found from the Bethe ansatz solution of the Calogero-Sutherland model, see Eq. (158). For generic weak interaction potentials, the threshold position  $\varepsilon_{\rm th}(k)$  can be calculated perturbatively and the phase shifts  $\delta_{\pm}(k)$  can be derived from Eq. (75). In this limit it is possible to recover the results of Sec. II.A.

The crucial step in the calculation of the exponents we outlined above is the identification of the fermionic operator at the edges in terms of the corresponding impurity operator, see Eqs. (78) and (79). A comparison with the solvable cases above shows that such an identification indeed holds in the vicinity of the Fermi points for any interaction strength, as well as at arbitrary momenta for weak interactions. However, the identification of the state which corresponds to the edge of support may have to be modified if the interactions affect the impurity spectrum too much, so that even in the region  $|k| < k_F$  the impurity band doesn't correspond to edge of support. The simplest scenario would be if at some k the true edge of support contains a single impurity with momentum close to k, as well as a low energy particle-hole pair at one of the branches. We expect that it doesn't happen as long as

$$\left| \frac{\partial \varepsilon_{\text{th}}(k)}{\partial k} \right| < v \text{ for } |k| < k_F.$$
 (88)

Equation (88) guarantees that the phases in Eq. (75) are continuous functions of momentum, and the state which corresponds to the edge of the spectral function in the basic region will contain a single impurity. We note that the condition (88) can be violated, e.g., for a microscopic model which describes ultracold fermions with resonant interactions (Imambekov et al., 2010).

### D. Phenomenology of spin liquids

Besides fermionic systems, spin chains constitute another noteworthy branch in the family of 1D quantum liquids. There is a plethora of experimentally accessible compounds which form antiferromagnetic Heisenberg chains and whose spin structure factor can be probed using neutron scattering. In addition to neutron scattering, electron spin resonance (ESR) can be used to probe some of the results discussed here in the presence of Dzvaloshinskii-Moriva interactions (Karimi and Affleck, 2011; Povarov et al., 2011). In the present context, antiferromagnetic spin-1/2 systems are of particular importance because their low-energy degrees of freedom often fall into the universality class of a linear LL (Giamarchi, 2004). The goal of this section is to extend the phenomenological considerations of Sec. II.C towards response functions of 1D spin liquids. Beyond the lowenergy limit, various microscopic models are used for the theoretical description of spin-1/2 chains. The phenomenological results of this section apply to a wide variety of model Hamiltonians of the form

$$H = \sum_{n,n'} J_{n-n'} \left[ S_n^x S_{n'}^x + S_n^y S_{n'}^y + \Delta_{n-n'} S_n^z S_{n'}^z \right] - h \sum_{n} S_n^z,$$
(89)

where  $\vec{S}_n = (S_n^x, S_n^y, S_n^z)$  are spin-1/2 operators located on the lattice sites n. The coupling between spins on different lattice sites is denoted by  $J_n$ . The exchange is anisotropic for  $\Delta_n \neq 1$ . An applied magnetic field in z-direction is denoted by h. Importantly, we assume throughout this section that the parameters  $J_n$ ,  $\Delta_n$  and h are chosen such that the system is a liquid, *i.e.*, the spectrum is gapless.

In order to introduce some general concepts of spin liquids on a simpler model, we start the discussion from the spin-1/2 XXZ model,

$$H_{XXZ} = J \sum_{n} \left[ S_{n}^{x} S_{n+1}^{x} + S_{n}^{y} S_{n+1}^{y} + \Delta S_{n}^{z} S_{n+1}^{z} \right] - h \sum_{n} S_{n}^{z}.$$
(90)

The XXZ model can be solved exactly using the Bethe ansatz (Korepin *et al.*, 1993; Orbach, 1958) and this aspect will be discussed in more detail in Sec. III.D. At

 $\Delta = 0$  the Hamiltonian (90) is easily mapped onto a model of free spinless fermions, see Eq. (94) below. For  $\Delta = 1$  the nearest-neighbor couplings are isotropic, and this case is referred to as XXX model. If additionally h=0, it also becomes SU(2) invariant. For  $|\Delta|>1$ and h=0, the system is gapped and the ground state becomes ferromagnetic or antiferromagnetic, depending on the sign of  $\Delta$ . On the other hand, the system remains gapless for  $|\Delta| < 1$  and sufficiently small magnetic fields (Haldane, 1980; Korepin et al., 1993; Takahashi, 2005). The low-energy sector in the corresponding parameter range can be modeled as an LL, characterized by a Luttinger parameter  $K \geq 1/2$ . The limit K = 1/2is reached for the isotropic Heisenberg model ( $\Delta = 1$ , h=0), while the noninteracting case ( $\Delta=0$ ) leads to K=1. Certain properties of XXZ model which are specific to its integrability can be calculated using approaches which combine the phenomenology with the results of the Bethe ansatz (Cheianov and Pustilnik, 2008; Pereira et al., 2006, 2008, 2009), see Sec. III.D. In this section, however, we will focus on its generic properties.

The XXZ model and its extensions we consider here preserve rotation symmetry in the xy plane. The dynamic responses of this type of spin chain are therefore encoded in the transversal and longitudinal spin structure factors, respectively,

$$S^{-+}(q,\omega) = \sum_{n} e^{-iqn} \int dt e^{i\omega t} \left\langle S_n^{-}(t) S_0^{+}(0) \right\rangle, \quad (91)$$

$$S^{zz}(q,\omega) = \sum_{n} e^{-iqn} \int dt e^{i\omega t} \langle S_n^z(t) S_0^z(0) \rangle, \qquad (92)$$

where  $S_n^{\pm} = S_n^x \pm i S_n^y$  and we assumed an infinite number of lattice sites. Due to the presence of the lattice, the quasimomentum q is bounded,  $|q| \leq \pi$ . Let us also mention that although we focus on the spin structure factors, a similar phenomenology can also be used to find other correlation functions, e.g., the spin-exchange structure factor (Klauser et al., 2011) which determines the rate of resonant inelastic X-ray scattering (Ament et al., 2011).

The spin operators can be mapped onto spinless fermions using a Jordan-Wigner transformation (Giamarchi, 2004),

$$S_n^+ \to (-1)^n c_n^{\dagger} e^{i\pi\phi_n}, \ S_n^- \to (-1)^n c_n e^{-i\pi\phi_n},$$
  
 $S_n^z \to c_n^{\dagger} c_n - \frac{1}{2},$  (93)

where  $c_n^{\dagger}$  ( $c_n$ ) is a creation (annihilation) operator for a fermion on lattice site n and the exponential of  $\phi_n = \sum_{j=-\infty}^{n-1} c_j^{\dagger} c_j$  denotes a Jordan-Wigner string. The latter is needed to ensure the proper anticommutation relation for fermions on different lattice sites,  $\{c_n^{\dagger}, c_m\} = \delta_{nm}$ . Because the operator  $S_n^z$  has the simple representation (93) in terms of the fermionic density  $\rho_n = c_n^{\dagger} c_n$ ,  $S^{zz}(q,\omega)$  is identical to the DSF of a system of spinless

fermions if the density is measured with respect to the half-filled band.

The XXZ Hamiltonian has the following fermionic representation,

$$H_{XXZ} = -\frac{J}{2} \sum_{n} (c_{n}^{\dagger} c_{n+1} + \text{h.c.}) - h \sum_{n} \left( \rho_{n} - \frac{1}{2} \right) + J\Delta \sum_{n} \left( \rho_{n} - \frac{1}{2} \right) \left( \rho_{n+1} - \frac{1}{2} \right).$$
(94)

In the fermionic language, a nonzero  $\Delta$  corresponds to a short-range interaction potential. The magnetic field h plays the role of the chemical potential. The Jordan-Wigner transformation can also be applied to the more general Hamiltonian (89) and leads to higher-order, possibly non-local interaction terms in addition to Eq. (94).

Due to this mapping on spinless fermions, many of the methods presented in the previous sections can be generalized to spin-1/2 chains with gapless spectra, but with certain peculiarities. First, one sees that unlike for Galilean invariant systems, the kinetic part in Eq. (94) can have different signs of the nonlinearity. This results in a much wider variety of threshold behaviors. Second, for a general filling fraction  $(h \neq 0)$  the concept of an edge of support is, strictly speaking, not defined. This is a consequence of the presence of the lattice which results in "foldings" of the shadow bands of Sec. II.C into the reduced zone scheme. However, the contributions to response functions from higher shadow bands are suppressed exponentially in their order. Indeed, in the language of fermions, the foldings come from umklapp processes which create additional particle-hole pairs and change the momentum of fermion system by multiples of the Brillouin zone period. If the Fermi wave vector is incommensurate with it, the creation of pairs is capable of reducing the energy of the "deep" hole to an arbitrarily low value (Pereira et al., 2009). The lower the resulting energy value, the more particle-hole pairs need to be created. The creation of these additional particle-hole pairs makes the Anderson orthogonality catastrophe stronger and thus suppresses the corresponding contributions to the response functions.

In the most natural case of h=0, Eq. (89) is  $Z_2$ -invariant, which corresponds to a particle-hole symmetric Hamiltonian in the fermionic representation (94). As a consequence of particle-hole symmetry, the leading correction to spectrum is cubic in momenta. This new feature appears due to the presence of a lattice and has ramifications regarding the universal description of Sec. II.B. At the same time, the edge of support is still well-defined, since shadow bands fold onto each other (Pereira et al., 2009); we will focus on the h=0 case in the bulk of this section, deferring to its end the consideration of the  $h\neq 0$  case.

![](_page_21_Figure_1.jpeg)

FIG. 7 (Color online) Longitudinal spin structure factor  $S_{XY}^{zz}(q,\omega)$  for the isotropic XY model, see Eq. (100). For fixed  $q < \pi$ , the function has a step-function threshold at the lower edge of support  $\omega_L(q)$  and diverges as an inverse square-root at the upper edge of support  $\omega_U(q)$ .

#### 1. XY model at zero magnetic field

First, we will illustrate some of the generic properties of spin liquids and their field theoretical description by considering in detail the isotropic XY model which corresponds to  $\Delta=0$  in the Hamiltonian (90). Its counterpart (94) describes free fermions. Their single-particle spectrum reads

$$\xi(k) = -J[\cos(k) - \cos(k_F)], \quad k \in [-\pi, \pi],$$
 (95)

and at h=0, it is particle-hole symmetric,  $k_F=\pi/2$ . In order to evaluate the longitudinal structure factor  $S_{\rm XY}^{zz}(q,\omega)$  with the help of quantum impurity model, we need to find the appropriate projections of the operators  $S_n^z$ . The lower threshold for  $S_{\rm XY}^{zz}(q,\omega)$  is reached at the energy

$$\omega_L(q) = -\xi(\pi/2 - q) = \xi(\pi/2 + q).$$
 (96)

The two corresponding configurations consist, respectively, of a deep hole with an accompanying low-energy particle, and a finite-energy particle accompanied by a low-energy hole (the low-energy particle and hole, respectively, are near the right Fermi point). Introducing the operator  $d_1$  creating a hole with a momentum close to  $\pi/2 - q$ , and the operator  $d_2^{\dagger}$  creating a particle with momentum in the vicinity of  $\pi/2 + q$ , we may write (Pereira  $et\ al.,\ 2008$ )

$$S_n^z \to e^{iqn} \psi_R^{\dagger} d_1 + e^{iqn} d_2^{\dagger} \psi_R.$$
 (97)

Having two rather than one threshold configurations in the projection Eq. (97) is a consequence of the particle-hole symmetry. Similar to the free-fermion density structure factor (10), the threshold frequency  $\omega_L(q)$  reaches zero at q=0 and  $q=2k_F=\pi$ . The threshold energy as a function of q is determined by the free-fermion spectrum (95), and the corresponding exponent  $\mu_z^-=0$ .

The nonzero values of  $S_{\rm XY}^{zz}(q,\omega)$  are confined to a finite energy window (Müller *et al.*, 1979, 1981). The upper threshold at h=0 is generated by particle-hole pairs with

particle and hole momentum in the vicinity of  $(\pi + q)/2$  and  $(\pi - q)/2$ , respectively. The projection of  $S_n^z$  onto these states reads (Pereira *et al.*, 2009)

$$S_n^z \to e^{iqn} d_1^{\dagger} d_2 \,, \tag{98}$$

and the threshold energy is given by

$$\omega_U(q) = \xi(\pi/2 + q/2) - \xi(\pi/2 - q/2). \tag{99}$$

The structure factor is proportional to the convolution of the particle and hole spectral functions, resulting in the exponent  $\mu_z^+ = 1/2$ , independently of q. A direct calculation of the structure factor yields (Müller *et al.*, 1979, 1981)

$$S_{XY}^{zz}(q,\omega) = \frac{\theta[\omega - \omega_L(q)]\theta[\omega_U(q) - \omega]}{[\omega_U^2(q) - \omega^2]^{1/2}}$$
(100)

The threshold energies and the edges of support of  $S_{\rm XY}^{zz}(q,\omega)$  are depicted in Fig. 7.

The evaluation of the transversal structure factor  $S_{\rm XY}^{-+}(q,\omega)$ , even at  $\Delta=0$ , is more complicated due to the presence of the string operators in the fermionic representation of  $S_n^{\pm}$ , see Eq. (93). The Jordan-Wigner transformation shifts the locations of zero modes of  $S_{\rm XY}^{-+}(q,\omega)$  to  $q=\pi\pm 2nk_F$ , as in the conventional LL theory (Giamarchi, 2004) (note that zero mode at  $q=\pi$  is present at any value of h). The thresholds of  $S_{\rm XY}^{-+}(q,\omega)$  are determined by the same configurations that define the thresholds of the spectral function  $A(k,\omega)$  for spinless fermions at momenta  $k=\pi-q+k_F$ . For simplicity, we will refer here to the vicinity of  $q=\pi$ , i.e.,  $0< k-k_F \ll k_F$ . Note that in the case of h=0, which we are still interested in, the threshold exponents obtained below are valid for the entire interval  $|q|\leq \pi$ .

The mapping onto spinless fermions allows us to use the results of Sec. II.B for the threshold configurations. The singularity in  $S_{\rm XY}^{-+}(q,\omega)$  at energy  $\omega=\xi(3\pi/2-q)=-\xi(q-\pi/2)$  is the counterpart of the "mass shell" singularity in the spectral function of free fermions, see Sec. II.A.2. The particle-like configuration contributing to the projection of spin operators takes the form

$$S_n^+ \to e^{i\pi n} e^{-ikn} d^{\dagger} \exp\left[i\pi \int^x dy \rho(y)\right],$$
 (101)

where  $d^{\dagger}$  creates an impurity particle at momentum  $k_d=3\pi/2-q$ . As  $\Delta=0$ , there is no interaction between the impurity and excitations near the Fermi level, and a straightforward calculation yields the threshold exponent  $\mu_x^-=1/2$ . Remarkably, even at  $\Delta=0$  the nonlinear LL theory yields a result for  $S_{\rm XY}^{-+}(q,\omega)$  which is different from the result  $\mu_{\rm LL}=3/4$  obtained from an analysis of a linearized fermionic spectrum (Giamarchi, 2004). The qualitative behavior of  $S_{\rm XY}^{-+}$  is illustrated in Fig. 8.

Turning now to the peculiarity in  $S_{XY}^{-+}(q,\omega)$  at the upper threshold  $\xi(\pi - q/2) - \xi(q/2) = 2\xi(\pi - q/2)$ , we notice that the configuration representing  $S_n^+$  and consisting of a minimal number of excitations should contain a

![](_page_22_Figure_1.jpeg)

FIG. 8 (Color online) Transversal structure factor  $S_{\rm XY}^{-+}(q,\omega)$  for the isotropic XY model for  $q\approx\pi$  at h=0. A divergent power-law with exponent  $\mu_x^-=1/2$  is found at the lower edge  $\xi(3\pi/2-q)=-\xi(q-\pi/2)$ . Note that the linearized Luttinger liquid (LL) theory predicts only one singularity with a different exponent  $\mu_{\rm LL}=3/4$ . At higher energy,  $\xi(\pi-q/2)-\xi(q/2)=2\xi(\pi-q/2)$ , the transversal structure factor has a step-like feature,  $\mu_x^+=0$ .

particle-hole pair at momenta  $k = \pi/2 \pm (\pi - q)/2$  and a low-energy particle near the Fermi level,

$$S_n^+ \to e^{i\pi n} e^{-ikn} d_1^{\dagger} d_2 \psi_R^{\dagger} \exp\left[i\pi \int^x dy \rho(y)\right].$$
 (102)

The time evolutions of the two impurities' creation and annihilation operators are independent of each other and of the evolution of the rest of the product, which includes the creation operator of a particle near the Fermi point and the string operator. The time evolution of the impurities is controlled by the corresponding singleparticle Hamiltonians. The third component of the product can be treated by the standard bosonization. This way, the spin correlation function in real space-time factorizes into a product of three functions. Taking the proper long-time asymptotes and performing a Fourier transform, one finds  $\mu_x^+ = 0$ . Note that because of the presence of the string operator in Eq. (102), the structure factor  $S_{\rm XY}^{-+}(q,\omega)$  remains finite after the drop at  $\omega = 2\xi(\pi - q/2)$ , see the sketch in Fig. 8. The closed-form analytical expression for the correlation function  $\langle S_n^-(t)S_0^+(0)\rangle$  has been obtained recently (Zvonarev et al., 2009c) as a Fredholm determinant, and in principle contains the full information about the properties of the spectral function  $S_{XY}^{-+}(q,\omega)$ .

#### 2. Generic spin chains at zero magnetic field

Moving away from the XY model to the general Hamiltonian (89) introduces interactions between the Jordan-Wigner fermions. The location of zero modes of the spin liquid  $(q=0 \text{ and } q=\pi \text{ at } h=0)$  is preserved, but the interactions affect the detailed shape of the thresh-

olds  $\omega_L(q)$  and  $\omega_U(q)$ , and generically lead to smearing of  $\omega_U(q)$  away from the low-energy regions. The particle-hole symmetry inherent to the case of zero field brings several new qualitative features which are absent for models in the continuum. As a consequence of particle-hole symmetry, the quadratic term in the band curvature vanishes  $(\tilde{m} = \infty)$  and the leading spectrum nonlinearity at momenta close to  $\pm k_F = \pm \pi/2$  becomes cubic. This makes a direct application of the universal results of Sec. II.B to the investigation of the singularities at  $\omega = \omega_L(q)$  impossible. One still may use perturbation theory of Sec. II.A if the interaction constants  $\Delta_n$  are small, and, e.g., for the XXZ model one obtains  $\mu_z^- \approx 2\Delta/\pi$  (Pereira et al., 2008). If the phase shifts are known non-perturbatively, then the exponents for  $S^{zz}(q,\omega)$  and  $S^{-+}(q,\omega)$  can be evaluated using Eqs. (87) and (112), respectively. For the case of isotropic exchange  $(\Delta_n = 1)$ , the SU(2) invariance of the equal-time correlations dictates (Giamarchi, 2004) K = 1/2 irrespective of  $J_n$ . The universal values of the threshold exponents can be established similarly with the help of SU(2) symmetry in conjunction with the phenomenology.

The quasiparticle configurations with energies near the upper threshold  $\omega_U(q)$ , which is well defined in the lowenergy region  $(q \ll \pi)$ , involve two mobile impurities. Generically these two interact with each other, but as long as h = 0 and particle-hole symmetry for fermions is preserved, there is no interaction of the two-impurity configuration with the low-energy excitations (Pereira et al., 2008). That brings universality to the exponents  $\mu_z^+$  and  $\mu_x^+$ . The response function  $S^{zz}(q,\omega)$  is associated with the creation of a particle  $(d_1^{\dagger})$  and a hole  $(d_2)$  having respective momenta  $\pi/2 + p \pm q/2$ , where  $p \ll q$ . Here, q and p are the total and relative momentum, respectively. The relative velocity of particle and hole motion vanishes at p = 0, so the particle-hole interaction effect is strong even at infinitesimal interaction. The DSF near the threshold is proportional to the probability density w(q,p) to create a particle and a hole at the same point, and to the joint density of states,

$$S(q,\omega) \propto \int dp \, \delta[\varepsilon(q,p) - \omega] w(q,p).$$
 (103)

Here,  $\varepsilon(q,p) = \omega_U(q) + E_r(p)$  is the energy of the pair near the threshold. The energy of the relative motion  $E_r(p) = p^2/(2M)$  depends on q via  $1/M \propto d^2\omega_U/dq^2 \propto q$ , while  $w(q,p) \propto |\psi_p(x=0)|^2$  is found from the solution  $\psi_p(x) = \cos(p|x| + \vartheta)$  of the Schrödinger equation for the relative motion in the pair,  $\mathcal{H}_r\psi_p(x) = E_r(p)\psi_p(x)$ . Here

$$\mathcal{H}_r = -\frac{1}{2M} \frac{\partial^2}{\partial x^2} + U_{12}\delta(x), \tag{104}$$

and  $U_{12} \propto q^2$  is the effective interaction between the particle and hole (note that M<0). The solution at small  $|E_r(p)| \ll |M|U_{12}^2 \propto q^3$  yields  $\psi_p(x=0) \propto$ 

 $\sqrt{E_r(p)/(|M|U_{12}^2)}$ . Therefore, using Eq. (103) at  $0 < \omega_U(q) - \omega \ll |\omega_U(q) - vq|$ , one obtains

$$S^{zz}(q,\omega) \propto q^{-7/2}\theta[\omega_U(q) - \omega]\sqrt{\omega_U(q) - \omega} + \text{regular terms.}$$
 (105)

The momentum independent threshold exponent  $\mu_z^+ = -1/2$  differs from its value at  $\Delta_n = 0$ : interactions cause a discontinuous change in the edge exponent (Pereira et al., 2008).

To describe  $S^{-+}(q,\omega)$  near the upper threshold, we may use projection of spin operators of Eq. (102). The real space-time correlation function factorizes into a product of two functions. The first one describes the evolution of the particle-hole pair, identical to that appearing in the  $S^{zz}(q,\omega)$  correlation function. The second function in the product comes from the evolution of the string operator multiplied by the creation operator of a fermion near the  $k_F = \pi/2$  point; that function depends on K. The resulting convolution yields  $\mu_x^+ = -3/2 + 1/(2K)$ .

As we may see from the derivation of Eq. (105), the asymptotic behavior of  $S^{zz}(q,\omega)$  at small positive  $\omega_U(q) - \omega$  is independent of the sign of the particle-hole interaction. However, at  $U_{12} > 0$  (we assume that M < 0, as it is in the XXZ model), a bound particle-hole state is formed. It would show up, for instance, as an additional peak in  $S^{zz}(q,\omega)$  at some value  $\omega > \omega_U(q)$ . Generically the energy of such bound state is finite for all momenta (as is illustrated by the XXZ model (Pereira et al., 2009)), and can be of the order of bandwidth for strong interactions. The possible bound state peak as well as the upper threshold  $\omega_U(q)$  (away from special points q=0 and  $q=\pm\pi$ ) appear on the background of the spectral continuum, and will be generically smeared out.

Considering the upper threshold, we find  $\mu_x^+ = \mu_z^+$  at SU(2) invariance, K=1/2. This is not a coincidence but rather a consequence of SU(2) symmetry which enforces  $S^{xx}(q,\omega) = S^{yy}(q,\omega) = S^{zz}(q,\omega)$ . Now we will use that constraint on the correlation functions in order to obtain their threshold behavior at  $\omega = \omega_L(q)$ . Together with the constraint, phenomenology alone is sufficient to establish momentum-independent  $\mu_z^- = 1/2$  as the universal value independent of the microscopic details. Using the mobile impurity Hamiltonian (64)-(65) and the projections similar to Eq. (97) and (101), the edge exponents of both  $S^{-+}(q,\omega)$  and  $S^{zz}(q,\omega)$  can be calculated independently as functions of the phase shifts  $\delta_{+}(q)$ . Moreover, since the system is half-filled, umklapp scattering is allowed and can produce terms of the form  $[\psi_L^{\dagger}\psi_L^{\dagger}\psi_R\psi_R]^m$   $(m \in \mathbb{Z})$  in the projections of  $S_n^z$  and  $S_n^+$ . The edge exponents of the longitudinal and transversal spin structure factors,  $\mu_{z,m}^-$  and  $\mu_{x,m}^-$ , become functions of m. As a consequence, the structure factors at the edge

are characterized by sums of the form,

$$S^{zz}(q,\omega) \propto \sum_{m} |\omega - \omega_L(q)|^{-\mu_{z,m}^-},$$
  
$$S^{-+}(q,\omega) \propto \sum_{n} |\omega - \omega_L(q)|^{-\mu_{x,n}^-}.$$
 (106)

A calculation similar to Eqs. (81)-(83) combined with K=1/2 leads to

$$\begin{split} \mu_{z,m}^{-} &= 1 - \frac{1}{2} \left( \sqrt{2} + \frac{\delta_{+} - \delta_{-}}{2\pi} \right)^{2} \\ &- \frac{1}{2} \left( -\frac{4m - 1}{\sqrt{2}} + \frac{\delta_{+} + \delta_{-}}{2\pi} \right)^{2} \\ \mu_{x,n}^{-} &= 1 - \frac{1}{2} \left( \frac{\delta_{+} - \delta_{-}}{2\pi} \right)^{2} - \frac{1}{2} \left( -\frac{4n + 1}{\sqrt{2}} + \frac{\delta_{+} + \delta_{-}}{2\pi} \right)^{2}. \end{split}$$

As a consequence of SU(2) invariance the entire series for  $\mu_{z,m}^-$  and  $\mu_{x,n}^-$  have to coincide at each q. This requirement leads to the momentum-independent phase shifts  $\delta_{\pm} = \mp \pi/\sqrt{2}$  and exponents (Imambekov and Glazman, 2009a),

$$S^{zz}(q,\omega) = \frac{1}{2}S^{-+}(q,\omega) \propto |\omega - \omega_L(q)|^{-1/2}.$$
 (108)

It coincides with the result of linear LL theory for  $S^{-+}(q,\omega)$  at  $q\to\pi$ ,  $\mu_{\rm LL}=1-1/(4K)=1/2$  (Giamarchi, 2004). Note that similar to equal-time correlators (Affleck *et al.*, 1989; Singh *et al.*, 1989), Eq. (108) will also have logarithmic corrections due to existence of marginally relevant terms in the Luttinger Hamiltonian.

# 3. Generic spin chains at finite magnetic field

A finite magnetic field  $(h \neq 0)$  violates the  $Z_2$  invariance of the spin liquid and destroys the particle-hole symmetry of the corresponding Hamiltonian in the fermionic variables. It shifts the Fermi points  $\pm k_F$  away from  $\pm \pi/2$ ; their new positions  $\pm k_F = \pm \pi (\langle S^z \rangle + 1/2)$ , are fully determined by the induced magnetization  $\langle S^z \rangle$ . The positions of two of the low-energy regions, q = 0 for  $S^{zz}(q,\omega)$  and  $q=\pi$  for  $S^{-+}(q,\omega)$ , do not shift. The other two regions are shifted from  $q = \pi$  to  $q = \pm 2k_F$ in  $S^{z}(q,\omega)$ , and from q=0 to  $q=\pm(\pi-2k_{F})$  in  $S^{-+}(q,\omega)$  (Giamarchi, 2004). As we already mentioned earlier in this section, folding of the shadow bands at  $h \neq 0$  makes the thresholds in the response functions at arbitrary q ill-defined. However, sharp threshold lines in the  $(q,\omega)$ -plane remain intact in the vicinities of the  $\omega = 0$  singularities of the response functions. Moreover, now the expansion in  $k-k_F$  of the elementary excitations spectrum does contain the quadratic term,  $1/\tilde{m} \neq 0$ , so one may use the universal nonlinear LL theory, see Sec. II.B. This theory is valid as long as the interaction potential  $J_n\Delta_n$  decays faster than  $1/n^2$ . For  $k\to\pm k_F$ , the phase shifts  $\delta_{\pm}(k)$  reach the universal values (48).

The threshold behavior of  $S^{zz}(q,\omega)$  at  $q \to 0$  is identical to Eq. (54),

$$S^{zz}(q,\omega) = \frac{K|\tilde{m}|}{|q|} \theta \left( \frac{q^2}{2|\tilde{m}|} - |\omega - vq| \right), \qquad (109)$$

and the exponents  $\mu_z^{\pm}=0$  are independent of the interactions. Here v and K are the characteristics of the linear LL, and  $1/\tilde{m}=(v/K^{1/2})\partial v/\partial h+v^2/(2K^{3/2})\partial K/\partial h$  is phenomenologically related to these quantities (Pereira et al., 2006). Similarly, for  $q\to\pi$  (Imambekov and Glazman, 2009b)

$$S^{-+}(q,\omega) \propto \left| \omega - \left( v|q - \pi| \pm \frac{(q - \pi)^2}{2\tilde{m}} \right) \right|^{\mp \frac{1}{\sqrt{K}} + \frac{1}{2K}}.$$
(110)

Note that the exponents  $\mu_x^{\pm} = \pm (1/\sqrt{K}) - 1/(2K)$  differ from the linear LL prediction  $\mu_{\rm LL} = 1 - 1/(4K)$  (Giamarchi, 2004).

We also note that the region of validity of Eqs. (109)-(110) in q becomes narrow ( $\propto h$ ), as the magnetic field decreases. The interesting question of whether there is a universal description of the crossover from the results of Sec. II.D.2 to the universal description at nonzero magnetic fields remains to be addressed. The behavior of the response functions in the  $(q, \omega)$  plane away from the zero-frequency special points is generally model-dependent.

# E. Bosonic systems with or without spin

The interest in interacting 1D bosonic systems, see the recent review by Cazalilla et al. (2011), has soared in past years mostly thanks to an increasing variety of experiments. The 1D bosons can be realized using Josephson junction arrays (Fazio and van der Zant, 2001), helium in nanopores (Del Maestro and Affleck, 2010; Del Maestro et al., 2011; Wada et al., 2001), as an effective description of magnons in magnetic insulators (Giamarchi et al., 2008), and most prominently in systems of ultracold atomic gases. In the latter case, one quite naturally often ends up with exactly solvable models, and these will be reviewed in detail in Sec. III. Here we will focus on a general phenomenological description of bosonic systems, both spinless and spinful.

Let us start with the discussion of the spinless case. In the absence of interactions, 1D bosonic systems are very different from fermionic ones. The former have a quadratic spectrum of excitations, while the excitation spectrum of the latter is linear. However, even for infinitesimally small repulsive interactions, bosons acquire a finite compressibility and their spectrum also becomes linear. The description of such bosons within the linear LL theory is not that different from the description of fermions (Efetov and Larkin, 1975; Giamarchi, 2004; Haldane, 1981a). The slowly varying component of the bosonic field is given by  $\Psi(x) \sim e^{i\theta(x)}$ .

The difference between this equation and, e.g., the bosonized expression for the right-moving fermionic field (19) is the factor  $\exp\left[i(\pi\rho x-\phi)\right]$ , which is nothing but a bosonized version of the Jordan-Wigner string operator  $\exp\left[i\pi\int_{-\infty}^{x}\Psi^{\dagger}(y)\Psi(y)dy\right]$  discussed in Sec. II.D. As a consequence of that, the edge of support of the bosonic spectral function, which we denote by  $A(q,\varepsilon)$ , is shifted by  $k_F$  compared to fermionic case. For  $\varepsilon>0$ , it coincides with that of the DSF, and for historical reasons we shall denote it by  $\varepsilon_2(q)>0$  in the region  $0< q<2k_F$ . For weakly interacting bosons,  $\varepsilon_2(q)$  corresponds to excitation spectrum of dark solitons, see Sec. III.B.

The Jordan-Wigner string does not appear in the bosonized form of the density operator. Therefore, the low-energy projection of the density operator does not depend on statistics of the particles (bosons or fermions). If one considers the DSF, it is not possible to distinguish spinless bosonic systems from spinless fermionic systems. Hence, the phenomenological relations of Sec. II.C determine the DSF exponents (87) as well as the phenomenological phase shifts (75), assuming that the effective threshold position is identified as

$$\varepsilon_{\text{th}}(k = k_F - q) = -\varepsilon_2(q) < 0 \text{ for } 0 < q < 2k_F.$$
 (111)

The same phase shifts and effective Hamiltonian also determine the edge exponents of the spectral function, when combined with proper operator identifications similar to Eq. (101) for spin chains. Similarly to the equal-time field correlator, only contributions arising from the Jordan-Wigner string from the vicinities of the Fermi points have to be treated differently compared to the fermionic case. Near the thresholds in the regions  $2nk_F < q < 2(n+1)k_F$ , the exponents for  $\varepsilon \geq 0$  are given by, (Imambekov and Glazman, 2009a)

$$\begin{split} \mu_{n,\pm}^{b}(q) &= 1 - \mu_{n,\pm,R}^{b} - \mu_{n,\pm,L}^{b}, \\ \mu_{n,-,\alpha}^{b} &= \left[ (2n+1)\sqrt{K}/2 + \delta_{\alpha}(q_{n})/(2\pi) \right]^{2}, \\ \mu_{n,+,\alpha}^{b} &= \left[ (2n+1)\sqrt{K}/2 + \alpha/\sqrt{K} - \delta_{\alpha}(-q_{n})/(2\pi) \right]^{2}, \end{split}$$

where  $\alpha = R, L = +, -$ , and  $q_n = (2n+1)k_F - q$ . The notation is illustrated in Fig. 12. Since the operators  $S^{\pm}$  carry the same Jordan-Wigner string as the boson creation-annihilation operators, Eqs. (112) can also be used to express the exponents of  $S^{-+}(q,\omega)$  in terms of the phase shifts.

Next, let us consider a system of interacting bosons which possess (iso)spin, and we will focus on the discussion of the SU(2) symmetric case. Such systems in quasi 1D configurations have already been realized with ultracold atomic gases (Higbie *et al.*, 2005; McGuirk *et al.*, 2002; Sadler *et al.*, 2006). In addition to the DSF and the spectral function, we will be also interested in the longitudinal and transverse spin structure factors,  $S^{zz}(q,\omega)$ 

and  $S^{\pm\mp}(q,\omega)$  respectively. These are defined by

$$S^{\pm\mp}(q,\omega) = \int dx dt e^{i(\omega t - qx)} \left\langle S^{\pm}(x,t) S^{\mp}(0,0) \right\rangle,$$
  
$$S^{zz}(q,\omega) = \int dx dt e^{i(\omega t - qx)} \left\langle S^{z}(x,t) S^{z}(0,0) \right\rangle, \quad (113)$$

where  $S^{\pm}(x) = S^x(x) \pm i S^y(x)$ . In terms of the physical particles, the spin density  $\vec{S}(x) = (S^x(x), S^y(x), S^z(x))$  reads

$$\vec{S}(x) = \sum_{\sigma, \sigma'} \Psi_{\sigma}^{\dagger}(x) \vec{S}_{\sigma \sigma'} \Psi_{\sigma'}(x), \tag{114}$$

where  $\vec{S}_{\sigma\sigma'}$  denotes the vector of spin matrices (half of the Pauli matrices for spin-1/2).

Bose statistics requires that the total N-particle wave function, which consists of a spatial part and a spin part, must be symmetric under exchange of the positions and spins of any two particles. Eisenberg and Lieb (2002) found that the unique spatial component of the ground state wave function is symmetric, so the spin wave function has to be symmetric as well. As a consequence, the ground state of the spinful Bose system is ferromagnetic (we will assume that the magnetization is pointing in +z direction). This is in striking contrast to the case of spinful fermions, where the ground state is usually a spin singlet (Lieb and Mattis, 1962). Due to the spinpolarized ground state, the bosonic system responds very differently to external perturbations which conserve the total spin and perturbations which change it. For simplicity, in what follows we will discuss only the case of (iso)spin-1/2.

The longitudinal spin structure factor  $S^{zz}(q,\omega)$  does not change the total spin and is simply proportional to the DSF  $S(q,\omega)$  for all  $(q,\omega)$ . The transverse spin structure factor  $S^{-+}(q,\omega)$  vanishes because the system is already in a state with largest possible  $S^z$ , and the action of the operator  $S^+(0) = \Psi^{\dagger}_{\uparrow}(0)\Psi_{\downarrow}(0)$  destroys it. On the other hand,  $S^{+-}(q,\omega)$  involves the action of the operators  $S^{-}(0) = \Psi_{\perp}^{\dagger}(0)\Psi_{\uparrow}(0)$  and  $S^{+}(x) = [S^{-}(x)]^{\dagger}$  that flip the spin of a single boson. The excitation of lowest energy which is created when  $S^{-}(0)$  acts on the ferromagnetic ground state is a magnon. In an SU(2) invariant system, the magnon spectrum towards small momenta is quadratic,  $\omega_m(q) = q^2/(2m^*)$ , where  $m^*$  denotes the effective magnon mass. Due to the quadratic spectrum, the threshold energy at small q of the transversal structure factor is always lower than that of  $S^{zz}(q,\omega)$  and  $S(q,\omega)$ . Note that the quadratic form of the magnon spectrum makes the calculation of the transversal response function based on the linear LL theory impossible (Akhanjee and Tserkovnyak, 2007; Kamenev and Glazman, 2009; Matveev and Furusaki, 2008; Zvonarev et al., 2007, 2009a).

A magnon can be thought of a spin-down impurity moving in a liquid of spin-up particles. Unlike the mobile impurities introduced in previous sections as an effective description, these magnons can be separately experimentally addressed, as has been demonstrated recently in experiments with ultracold gases (Catani et al., 2012; Palzer et al., 2009). An effective Hamiltonian similar to Eqs. (64)-(65) can be used to describe the singularities in the spin structure factors, if one introduces an operator  $d^{\dagger}(x)$  creating a bosonic spin-down impurity with momentum near q and energy near  $\omega_m(q)$ . Then the projection of the operator  $S^-(x)$  onto the three-subband model reads

$$S^{-}(x) \propto e^{-iqx} d^{\dagger}(x) e^{i\theta(x)}$$
. (115)

The phenomenological approach of Sec. II.C can also be directly generalized, and leads again to explicit predictions for the transverse spin structure exponent at the magnon spectrum  $\mu_m(q)$  which were presented by Kamenev and Glazman (2009). The general expressions simplify somewhat in the limit  $|q| \ll m^* v$  due to the quadratic spectrum, and in order  $O(q^4)$  are given by

$$\mu_m(q) = 1 - \frac{Kq^2}{2(\pi\rho)^2} \left[ 1 + \left( \frac{q}{m^* v} \right)^2 (3 + 4\sigma + \sigma^2) \right],$$

where  $\sigma = -\rho/(2m^*)\partial m^*/\partial \rho$ .

# F. Fermionic systems with spin

In this section, some of the concepts introduced in the previous sections will be applied for the exploration of the properties of spin-1/2 fermions in 1D. Compared to spinless fermions, a complication arises due to the spincharge separation encountered in interacting 1D systems: a generic density-density interaction couples fermions of opposite spins and lifts the degeneracy between charge modes (excitations symmetric in spin-up and spin-down) and spin modes (excitations antisymmetric in spin-up and spin-down) present in the noninteracting system. Within the linear LL theory, the eigenstates of the interacting system are then linear combinations of spin-up and spin-down excitations and can be interpreted as density waves which carry either only spin or only charge. These two types of excitations propagate at different velocities,  $v_s$  and  $v_c$ , respectively.

The phenomenon of spin-charge separation is the hall-mark of the linear spinful LL theory (Dzyaloshinskii and Larkin, 1974): the fermionic Green's function is a product of two parts which describe excitations propagating with velocities  $\pm v_s$  and  $\pm v_c$ , respectively. The fermionic spectral function which can be obtained from the Green's function by Fourier transformation thus has power-law singularities at the spin and charge modes (Meden and Schönhammer, 1992; Voit, 1993a,b). The spin and charge density structure factors, on the other hand, are deltafunctions reflecting the linear spectra of the two types of bosonic modes.

The existence of two distinct excitation energies for a given momentum has already been observed in a number of experiments with solid state systems (Auslaender et al., 2005, 2002; Jompol et al., 2009; Kim et al., 2006). Moreover, experiments using 1D ultracold fermions (Liao et al., 2010) could allow the observation of spin-charge separation in real space (Kollath and Schollw¨ock, 2006; Recati et al., 2003).

In this section, we will review recent theoretical progress (Pereira and Sela, 2010; Schmidt et al., 2010a,b) in understanding the notion of spin-charge separation in 1D models beyond the linear LL paradigm. This question has received some attention over the years. The existence of a certain form of spin-charge separation at all energy scales is implicitly built into the structure of the exact solutions of spinful integrable models which will be discussed in more detail in Sec. III. For instance, Ogata and Shiba (1990) demonstrated that the eigenstates of the strongly interacting 1D Hubbard model (see Sec. III.D) factorize into charge parts and spin parts. The former are identical to the eigenmodes of free spinless fermions, whereas the latter are solutions of the XXZ model. In an extension of this approach called pseudofermion dynamical theory (Carmelo et al., 1999; Carmelo et al., 2005, 2004, 2006), some of the results of the present section have been envisioned before for the integrable 1D Hubbard model, but its field-theoretical basis and applicability for general nonintegrable models remain unclear.

The approach of Ogata and Shiba (1990) can be applied even without an underlying lattice or integrability, because strong repulsion makes the charge mode stiffer while softening the spin excitations. The enhanced rigidity of the charge spatial structure allows one (Matveev, 2004a,b; Matveev et al., 2007a,b) to invoke the notion of a Wigner crystal (Wigner, 1934), in which fermions arrange on a 1D lattice, as a starting point for the consideration of the dynamics, notwithstanding the absence of long-range crystalline order in 1D. The dispersion of the spin excitations is suppressed in the amplitude of the repulsion potential. In the limit of strong repulsion it is tempting to dispense with the spin dynamics altogether, and to assume that arbitrarily oriented spins are attached to the sites of the Wigner crystal and that its excitations are sound waves. Such a model was dubbed spin-incoherent LL. The bandwidth of the spin excitations is zero in the spin-incoherent LL, and at any temperature the real-space electron Green's function decays exponentially in the spatial coordinate. This reflects the absence of any order in the spin system in the absence of exchange interaction between the spins (Cheianov and Zvonarev, 2004a,b; Fiete, 2006; Fiete, 2009; Fiete and Balents, 2004). We refer the reader to an excellent review of spin-incoherent LLs for details (Fiete, 2007).

In contrast to the notion of the spin-incoherent LL, here we concentrate on the generic case of comparable (but different) velocities of spin and charge excitations. As we shall see, the concept of spin-charge separation survives, albeit in a modified form, beyond the low-energy limit and the assumption of a linear spectrum. In the following, we shall focus on the case of repulsive interactions. In this case, the system remains gapless in both charge and spin sectors, and charge excitations propagate faster than spin excitations (v<sup>c</sup> > vs). The parameter K<sup>c</sup> characterizing the linear LL of charge excitations is in the range 0 < K<sup>c</sup> < 1. For simplicity, we will only consider systems without Zeeman splitting, although a small magnetic field might be beneficial to detect spincharge separation in experiments (Grigera et al., 2004; Rabello and Si, 2002). The resulting SU(2) invariance generically leads to the spin LL parameter K<sup>s</sup> = 1.

The investigation of a nonlinear spectrum in the bosonic language runs into similar problems as in the spinless case (Sec. II.B). A nonlinearity leads to interactions between the bosonic modes. To lowest order, the corresponding self-energy diverges at energies ω = vc,sk. It is still possible to investigate certain properties using the bosonic approach (Brazovskii et al., 1993, 1994; Vekua et al., 2009), e.g., the dynamic response functions sufficiently far away from the thresholds (Pereira and Sela, 2010; Teber, 2007), but closer to the threshold perturbation theory fails. An efficient resummation scheme which eliminates these divergencies has not been developed yet. Therefore, it is easier to generalize the fermionic quasiparticle methods used in the previous sections to spinful systems. The path to a fermionic description is similar to the one followed in Sec. II.B for spinless fermions. For a linear fermion spectrum, the Hamiltonian becomes a sum of independent charge and spin parts, HLL = H<sup>c</sup> +Hs. The charge term H<sup>c</sup> has the form of the linear LL Hamiltonian (41) and it is characterized by the charge velocity v<sup>c</sup> and the Luttinger parameter Kc. Its eigenmodes are bosonic charge density waves. The spin part H<sup>s</sup> also contains a quadratic term of the form (41), characterized now by a different Luttinger parameter K<sup>s</sup> and the spin velocity vs. In addition, however, H<sup>s</sup> generally contains a sine-Gordon term, which describes spinflip scattering between the physical fermions. For repulsive interactions it is marginally irrelevant and vanishes in the limit of small bandwidth (S´olyom, 1979). Then, the eigenmodes of H<sup>s</sup> are bosonic spin density waves.

Within the linear LL theory, the physical fermions can be expressed is terms of left- and right-movers using Ψσ(x) = e ik<sup>F</sup> <sup>x</sup>ΨRσ(x) + e <sup>−</sup>ik<sup>F</sup> <sup>x</sup>ΨLσ(x) where σ =↑, ↓ denotes the spin. The bosonization rules for the fermionic operators are given by (Giamarchi, 2004)

$$\Psi_{\alpha\sigma}(x) \propto e^{-i/\sqrt{2}[\alpha\phi_c(x) - \theta_c(x) + \alpha\sigma\phi_s(x) - \sigma\theta_s(x)]}, \quad (116)$$

where α = R, L = +, −. Because H<sup>c</sup> and H<sup>s</sup> are formally identical to linear LL Hamiltonians, it is possible to express them in terms of free quasiparticles by generalizing

Eq. (45),

$$H_{c} = -\sum_{\alpha} i\alpha v_{c} \int dx : \tilde{\Psi}_{\alpha c}^{\dagger}(x) \nabla \tilde{\Psi}_{\alpha c}(x) :,$$

$$H_{s} = -\sum_{\alpha} i\alpha v_{s} \int dx : \tilde{\Psi}_{\alpha s}^{\dagger}(x) \nabla \tilde{\Psi}_{\alpha s}(x) :, \qquad (117)$$

where  $\alpha=R, L=+,-$ . The fermionic quasiparticles  $\tilde{\Psi}_{\alpha\nu}(x)$  ( $\nu=c,s$ ) describe low-energy charge and spin excitations, which we shall refer to as holons and spinons, respectively. As in the spinless case, see Eq. (46), the physical fermions  $\Psi_{\alpha\sigma}(x)$  can be expressed in terms of the quasiparticles by using the bosonization identity (116), then rescaling the bosonic fields and finally refermionizing them. For the right-movers, the result reads

$$\Psi_{R\uparrow}(x) \propto \tilde{\Psi}_{Rc}(x) F_{Rc}(x) \tilde{\Psi}_{Rs}(x) F_{Rs}(x),$$

$$\Psi_{R\downarrow}(x) \propto \tilde{\Psi}_{Rc}(x) F_{Rc}(x) \tilde{\Psi}_{Rs}^{\dagger}(x) F_{Rs}^{\dagger}(x). \tag{118}$$

The string operators are given by

$$F_{R\nu}(x) = \exp\left\{-i\int_{-\infty}^{x} dy \left[\delta_{+\nu}\tilde{\rho}_{R\nu}(y) + \delta_{-\nu}\tilde{\rho}_{L\nu}(y)\right]\right\},\tag{119}$$

where  $\tilde{\rho}_{\alpha\nu}(x) = \tilde{\Psi}^{\dagger}_{\alpha\nu}(x)\tilde{\Psi}_{\alpha\nu}(x)$  ( $\alpha = R, L, \nu = c, s$ ) denote the right- and left-moving quasiparticle densities, respectively. Note that Eq. (118) contains charge and spin string operators, although we assume only  $K_c \neq 1$ . The appearance of the string operators in Eq. (118) is an inevitable consequence of the attempted "splitting" of a spinful fermion into two spinless fermionic excitations. The phase shifts are determined by  $K_c$ ,

$$\begin{split} \frac{\delta_{+c}}{2\pi} &= 1 - \sqrt{\frac{1}{8K_c}} - \sqrt{\frac{K_c}{8}}, \\ \frac{\delta_{-c}}{2\pi} &= \sqrt{\frac{1}{8K_c}} - \sqrt{\frac{K_c}{8}}, \\ \frac{\delta_{+s}}{2\pi} &= 1 - \frac{1}{\sqrt{2}}, \ \frac{\delta_{-s}}{2\pi} = 0. \end{split}$$
 (120)

Note that the Klein factors, which are required to ensure the correct fermionic anticommutation relations, were neglected in Eq. (118). This is justified as long as it is used to calculate expectation values of operators which conserve charge as well as spin. This is indeed the case for all dynamic response functions.

According to Eq. (118), the creation of a physical spinup (spin-down) particle leads to the formation of a holon and the creation (annihilation) of a spinon. The string operators  $F_{R\nu}(x)$  reflect the shake-up of the spinon and holon Fermi seas due to the addition of the physical fermion. The phase shifts (120) characterize the strength of the shake-up. Keeping the spectrum of fermions linear as in Eq. (117), and using Eqs. (118)-(120), one may readily reproduce the known results for the spectral function of fermions in a spinful linear LL (Schmidt et al., 2010b). The spectral function  $A(k,\varepsilon)$  for fixed  $k>k_F$  now displays two peaks: divergent power-law singularities are located at the energies of the spinons and the holons,  $\varepsilon=v_s(k-k_F)$  and  $\varepsilon=v_c(k-k_F)$ . Within the linear LL theory, the exponents at both thresholds are determined by the phase shifts  $\delta_{\pm\nu}$  and thus by the Luttinger parameter  $K_c$  (Meden, 1999; Meden and Schönhammer, 1992; Voit, 1993a,b).

A nonzero curvature of the physical fermion spectrum generally leads to interactions between the spinons and holons. Moreover, it also bends the spectra of both the spinons and the holons. For  $k \to k_F$ , the leading correction to the holon spectrum is quadratic,

$$\tilde{\xi}_c(k) \approx v_c(k - k_F) + \frac{(k - k_F)^2}{2\tilde{m}}.$$
 (121)

The effective mass  $\tilde{m}$  can be determined phenomenologically and the result resembles the spinless case (50),

$$\frac{1}{\tilde{m}} = \frac{v_c}{\sqrt{2}K_c} \frac{\partial}{\partial \mu} (v_c \sqrt{K_c}). \tag{122}$$

The shape of the spinon spectrum  $\tilde{\xi}_s(q)$ , on the other hand, becomes rather different. From Eq. (118), it can be inferred that the spin-up/spin-down symmetry of the physical fermions entails particle-hole symmetry of the spinons. Therefore, there is no quadratic term in  $\tilde{\xi}_s(q)$ . Instead, for  $q \to 0$  the leading nonlinearity is cubic,

$$\tilde{\xi}_s(q) \approx v_s q - \gamma q^3 \quad \text{for } |q| \ll k_F,$$
 (123)

with  $\gamma > 0$ . The spinon spectrum near the Fermi points is therefore similar to the low-energy spectrum of the XXX model in zero magnetic field encountered in Sec. II.D. In both cases, the shape is a direct consequence of SU(2) symmetry.

For repulsive interactions one has  $v_s < v_c$ , so for a given momentum  $k \approx \pm k_F$  exciting a spinon requires less energy than exciting a holon. Since the thresholds in all dynamic correlation functions should be continuous, they coincide with a shifted spinon mass shell  $\tilde{\xi}_s(q)$  for arbitrary momenta. The precise shape of  $\tilde{\xi}_s(q)$  away from Fermi points depends on the microscopic details of the interaction and is generally unknown.

The power-law singularities characterizing the dynamic responses beyond the linearized theory can be determined by generalizing the mobile-impurity Hamiltonian (56) to the spinful case. Within the linearized theory, all threshold singularities in the dynamic response functions are characterized by configurations where a spinon carries almost the entire available energy. Hence, the quantum numbers of the effective impurity should coincide with that of a spinon near the Fermi points. By continuity, this remains true also for momenta away from Fermi points. For a spinon impurity at momentum  $q_d = k - k_F$  where  $k \in [-k_F, k_F]$ , we use the projection

 $\tilde{\Psi}_{Rs}(x) \to e^{iq_dx}\tilde{d}(x) + \tilde{\psi}_{Rs}(x)$ . The spinons and holons near the Fermi points, as well as the impurity at momentum  $q_d$  are then described by

$$H_{0} = -\sum_{\alpha} i\alpha v_{c} \int dx \left[ : \tilde{\psi}_{\alpha c}^{\dagger}(x) \nabla \tilde{\psi}_{\alpha c}(x) : \right]$$
$$-\sum_{\alpha} i\alpha v_{s} \int dx \left[ : \tilde{\psi}_{\alpha s}^{\dagger}(x) \nabla \tilde{\psi}_{\alpha s}(x) : \right],$$
$$H_{d} = \int dx \tilde{d}_{s}^{\dagger}(x) \left[ \tilde{\xi}_{s}(q) - iv_{d} \nabla \right] \tilde{d}_{s}(x), \tag{124}$$

where  $\alpha = R, L = +, -$  and  $v_d = \partial \tilde{\xi}_s(q)/\partial q$ . The interaction between the impurity and the low-energy spinon and holon degrees of freedom leads to

$$H_{int} = \int dx \sum_{\alpha=R,L} \sum_{\nu=c,s} \tilde{V}_{\alpha\nu}(k) \tilde{\rho}_{\alpha\nu}(x) \tilde{d}_s^{\dagger}(x) \tilde{d}_s(x). \tag{125}$$

The term  $H_{int}$  can be removed by using a unitary transformation similar to Eq. (71).

The impurity causes phase shifts of the quasiparticles near the Fermi points,

$$\Delta \delta_{\alpha\nu}(k) = \frac{\tilde{V}_{\alpha\nu}(k)}{v_d - \alpha v_{\nu}},\tag{126}$$

where  $\alpha=R, L=+,-$  and  $\nu=c,s$ . Let us first investigate these phase shifts in the limit  $k\to k_F$ . For interactions between the physical fermions which decay faster than  $\propto 1/x^2$ , the interaction potentials  $\tilde{V}_{\alpha\nu}(k)$  fulfill  $\tilde{V}_{\alpha\nu}(k)\propto (k-k_F)^2$ . The denominators in Eq. (126) are determined by the cubic shape of the spinon spectrum (123). In the limit  $k\to k_F$ , one finds  $v_d\pm v_c\to {\rm const.}$  and  $v_d+v_s\to {\rm const.}$ , so the phase shifts  $\Delta\delta_{\pm c}$  and  $\Delta\delta_{-s}$  vanish. In contrast,  $v_d-v_s\propto (k-k_F)^2$ , so the phase shift  $\Delta\delta_{+s}$  remains nonzero even for  $k\to k_F$ .

This is a striking contrast to the spinless case, where all phase shifts vanish in the limit  $k \to k_F$ , see Eq. (56). The latter is a consequence of the quadratic spectrum of the spinless fermions near  $k_F$  (Imambekov and Glazman, 2009b). The spinon spectrum (123), on the other hand, is cubic due to SU(2)-symmetry. Thankfully, the phase shifts  $\Delta \delta_{\pm s}(k)$  can be determined for arbitrary momenta by exploiting the SU(2) symmetry.

In order to determine these phase shifts, we use the same argument that led to the spin structure factor of the XXX model in Eq. (108): for an SU(2) symmetric system, the threshold exponents of the two components of the spin structure factors  $S^{-+}(q,\omega)$  and  $S^{zz}(q,\omega)$ , defined in Eq. (113), have to coincide at arbitrary momenta q.

As previously, the first step in calculating these exponents consists in identifying the threshold configuration and projecting the operators  $S^{\pm}(x)$  and  $S^{z}(x)$  accordingly. Then, the mobile impurity Hamiltonian (124)-(125) can be used to calculate the threshold exponents as

functions of  $\Delta \delta_{\alpha\nu}(k)$ . The requirement of identical exponents for  $S^{-+}(q,\omega)$  and  $S^{zz}(q,\omega)$  unambiguously entails that for arbitrary momentum k (Pereira and Sela, 2010; Schmidt et~al., 2010a)

$$\delta_{\pm s} + \Delta \delta_{\pm s}(k) = 0. \tag{127}$$

Having fixed the phase shifts  $\Delta \delta_{\pm s}$  by Eq. (127), only the values of  $\Delta \delta_{\pm c}(k)$  are left to be determined. For integrable models,  $\Delta \delta_{\pm c}$  can be extracted exactly from the finite-size corrections of the Bethe ansatz spectrum (Carmelo *et al.*, 2008; Essler, 2010) similar to the procedure discussed in Sec. II.G. For generic Galilean invariant models, a generalization of the phenomenological approach of Sec. II.C is possible. It relates  $\Delta \delta_{\pm c}$  in the interval  $|k| < k_F$  to the shape of the edge of support  $\epsilon_s(k) = \tilde{\xi}_s(k - k_F) < 0$  (Schmidt *et al.*, 2010a):

$$\frac{\Delta \delta_{\pm c}(k)}{2\pi} = \pm \frac{\frac{k - k_F}{m\sqrt{K_c}} \pm \sqrt{K_c} \left(\frac{2}{\pi} \frac{\partial \epsilon_s(k)}{\partial \rho_c} + \frac{\partial \epsilon_s(k)}{\partial k}\right)}{2\sqrt{2} \left(\frac{\partial \epsilon_s(k)}{\partial k} \mp \frac{k_F}{mK_c}\right)}, \quad (128)$$

where m is the mass of the physical fermions. In the limit  $k \to \pm k_F$ , the low-energy expansion of the spinon spectrum  $\tilde{\xi}_s(q)$  leads back to  $\Delta \delta_{\pm c} = 0$ . This is a consequence of the conventional spin-charge separation of the linear LL theory. The equations (127) and (128) fix all parameters in the mobile impurity Hamiltonian (124) and are thus the key for the calculation of edge exponents in the various dynamic response functions.

Let us start with the spectral function. For the calculation of the threshold behavior of  $A(k, \varepsilon)$  for  $0 < k < k_F$ , one needs to consider the response of the system to the addition of a physical spinful fermionic hole with a given momentum k and the threshold energy  $\epsilon_s(k) < 0$ . The incoming hole creates a spinon on the mass shell, which absorbs the entire energy, as well as a holon at a Fermi point. That spinon is protected from decay by energy and momentum conservation. If the energy of the incoming hole is slightly below  $\epsilon_s(k)$ , the excess energy is used for the creation of low-energy particle-hole pairs in the holon sector. However, due to Eq. (127) it cannot be used for the creation of additional spinons! Since the velocity of the spinon impurity is smaller than the holon velocity,  $v_d = \partial \epsilon_s(k)/\partial k < v_c$ , the spinon becomes spatially separated from the holons. While this effect is reminiscent of the conventional spin-charge separation of the linear LL theory, it should be pointed out that this new form of spin-charge separation survives for arbitrary momenta only for energies close to the threshold. Finding the threshold exponents of the spectral function  $A(k,\varepsilon)$  at k>0 requires a projection of the fermionic operator  $\Psi_{R\sigma}(x)$  in Eq. (118). Due to SU(2) symmetry, the result does not depend on the choice of  $\sigma = \uparrow, \downarrow$ . For  $0 < k < 2k_F$ , one can therefore project

$$\Psi_{R\uparrow}(x) \to e^{ikx} \tilde{\psi}_{Rc} F_{Rc} \tilde{d}_s F_{Rs}.$$
 (129)

![](_page_29_Figure_1.jpeg)

FIG. 9 (Color online) Spectral function  $A(k,\varepsilon)$  for spinful fermions ( $|k| < k_F$ ), see Eq. (130). For repulsive interactions, the edge of support is determined by the spinon spectrum  $\epsilon_s(k)$ . The power-law singularity at the holon mass shell  $\tilde{\xi}_c(k)$  is generally broadened away from Fermi points.

For general  $(2n-1)k_F < k < (2n+1)k_F$   $(n \in \mathbb{Z})$ , the excess momentum can be used to create additional particle-hole interbranch pairs similar to Sec. II.C. The mobile-impurity Hamiltonian now allows a calculation of the spectral function and the result is,

$$A(k,\varepsilon) \propto \theta[\epsilon_s(k_n) \pm \varepsilon] |\epsilon_s(k_n) \pm \varepsilon|^{-\mu_{n,\pm}^s(k)},$$
 (130)

where  $k_n = k - 2nk_F \in [-k_F, k_F]$ . The location of the edges and the respective exponents are sketched in Fig. 9. The momentum-dependent exponents are given by

$$\mu_{n,\pm}^{s}(k) = 1 - \left( -\frac{(2n+1)\sqrt{K_c}}{\sqrt{8}} - \frac{1}{\sqrt{8K_c}} + \frac{\Delta\delta_{+c}}{2\pi} \right)^2 - \left( -\frac{(2n+1)\sqrt{K_c}}{\sqrt{8}} + \frac{1}{\sqrt{8K_c}} + \frac{\Delta\delta_{-c}}{2\pi} \right)^2 - m_{\pm}^2, \quad (131)$$

where  $\Delta \delta_{\pm c} = \Delta \delta_{\pm c}(k_n)$  and  $m_{\pm} = (n + 1/2 \pm 1/2) \mod 2$ .

Farther away from the threshold, a second peak emerges at energies which correspond to the holon mass shell,  $\varepsilon \approx \tilde{\xi}_c(k)$ . Near this energy, the incoming physical particle triggers the formation of a holon on its mass shell as well as a low-energy spinon. Away from the Fermi momentum, interactions between holons and spinons generally lead to a nonzero decay rate for holons and thus a smearing of this peak. This will be discussed in more detail in Sec. IV.A.

Let us conclude the discussion of the spectral function by a closer look at momenta  $k \approx k_F$ . In that limit,  $\Delta \delta_{\pm c} = 0$  and the exponent (131) coincides with the prediction of the linear LL theory,  $\mu_{0,-}^s = 1 - 1/(4K_c) - K_c/4$  (Giamarchi, 2004). At  $k \to k_F$ , the peak at the holon mass shell becomes sharp. However, the exponent  $1 - [\delta_{-,c}/(2\pi)]^2 - [\delta_{+,s}/(2\pi) - 1]^2 - [\delta_{-,s}/(2\pi)]^2$  found

in the vicinity of the holon mass shell,  $|\varepsilon - \xi_c(k)| \ll (k - k_F)^2/(2\tilde{m})$ , is different from the LL prediction, just as in the case of spinless fermions. At larger detunings from the threshold, the power-law behavior with the LL value of the exponent is restored (Schmidt *et al.*, 2010b). Unlike in the case of spinless fermions, here the crossover function between the two asymptotes of  $A(k,\varepsilon)$  is not known. The spectral function  $A(k,\varepsilon)$  and notations for exponents are illustrated schematically in Fig. 9.

Next, we turn to the discussion of the spin structure factors. Due to SU(2) symmetry, they are related by  $S^{zz}(q,\omega) = \frac{1}{2}S^{-+}(q,\omega)$ . The calculation of  $S^{zz}(q,\omega)$  requires a projection of the spin density operator  $S^z(x)$ . The configuration of lowest energy for the momentum  $0 < q < 2k_F$  contains a single particle-hole pair in the spinon sector,

$$S^z(x) \to e^{iqx} \tilde{\psi}_{Rs}^{\dagger} F_{Rs} d_s F_{Rs}.$$
 (132)

For general momenta  $2nk_F < q < 2(n+1)k_F$ , the projection contains n additional low-energy particle-hole pairs which carry the momentum  $2nk_F$ . Using the mobile impurity Hamiltonian, it can be shown that

$$S^{zz}(q,\omega) \propto \theta[\omega - |\epsilon_s(q_d)|][\omega - |\epsilon_s(q_d)|]^{-\mu_n^{\mathrm{DSF}}(q)}$$
 (133)

where  $q_d = (2n+1)k_F - q$  and the exponents are

$$\mu_n^{\rm DSF}(q) = \frac{1}{2} - \left(\frac{n\sqrt{K_c}}{\sqrt{2}} + \frac{\Delta\delta_{+c}}{2\pi}\right)^2 - \left(\frac{n\sqrt{K_c}}{\sqrt{2}} + \frac{\Delta\delta_{-c}}{2\pi}\right)^2.$$
(134)

The phase shifts are taken at momentum  $q_d$ , i.e.,  $\Delta \delta_{\pm c} = \Delta \delta_{\pm c}(q_d)$ . Note that at  $q \to 0$  the scattering phase shifts  $\Delta \delta_{\pm c} \to 0$ . Therefore, the exponent of the spin structure factor approaches the universal value 1/2, coinciding with the respective spin liquid exponent of the spin-1/2 XXX chain, see Sec. II.D. Similar to the spin chain model, the region of frequencies  $|\omega - |\epsilon_s(q_d)||$  where Eq. (134) is applicable, shrinks as  $q^3$ . The latter parameter defines the width of the peak in the spin structure factor. Its detailed structure has not been investigated yet. In the linear LL, it is replaced by a  $\delta$ -function at  $\omega = v_s q$ .

The quadratic dispersion of the holon spectrum leads to  $\Delta \delta_{\pm c} \to 0$  for  $k \to \pm k_F$  and results in a rectangular-shaped peak in the charge DSF  $S(q,\omega)$  similar to the case of spinless fermions, see Eq. (27). For  $\omega \approx v_c q$  and  $|q| \ll k_F$ , the result up to order  $q^2$  reads

$$S(q,\omega) = \frac{2\tilde{m}K_c}{|q|}\theta\left(\frac{q^2}{2\tilde{m}} - |\omega - v_c q|\right)$$
(135)

with an effective mass  $\tilde{m}$ . Because the width of the peak  $\delta\omega(q)=q^2/\tilde{m}$  is proportional to  $q^2$  whereas its height scales as 1/|q|, the limit  $q\to 0$  reproduces the linear LL result,  $S(q,\omega)=2K_c|q|\delta(\omega-v_cq)$ . The DSF (135)

already satisfies the f-sum rule (Nozieres, 1997). Hence, additional features may exist with weights at most of order  $(q/k_F)^3$ .

A second peak in  $S(q,\omega)$  occurs at energies close to the spinon mass shell. Indeed, the coupling between spinons and holons has the remarkable consequence that the lower edge of support of the *charge* DSF now coincides with the shifted *spinon* spectrum. The weight of this additional peak can be estimated by using perturbation theory in the spin-charge coupling amplitudes  $\kappa_{\pm}$ , which can be also defined phenomenologically (Pereira and Sela, 2010), see Eq. (199).

For  $\omega \approx v_s q$ , the total weight in the vicinity of  $\omega \approx v_s q$ equals  $K_c(\alpha_- + \alpha_+)^2 q^3/12$ , where  $\alpha_{\pm} = \kappa_{\pm}/(v_c \pm v_s)$ . At small q, the perturbation theory correctly predicts the peak with weight  $\propto q^3$  at the spinon mass shell. However, it is unable to predict the precise shape of the peak. An analysis using a mobile impurity Hamiltonian reveals again that at the lower threshold  $S(q,\omega)$  has a power-law singularity (Pereira and Sela, 2010). The singularity remains intact for arbitrary momenta (Schmidt et al., 2010a). The calculation of the exponent requires a projection of the charge density operator  $\rho(x)$ . Using Eq. (118), one finds that the configuration with least energy for a momentum  $0 < q < 2k_F$  reads  $\rho(x) \rightarrow$  $e^{iqx}\psi_{Rs}^{\dagger}F_{Rs}d_sF_{Rs}$  and has the energy  $\approx |\epsilon_s(k_F-q)|$ . Interestingly, this configuration is identical to the threshold configuration for the spin structure factor (132). Therefore, near the edge of support  $S(q,\omega) \propto S^{zz}(q,\omega)$ . In particular, the threshold exponent for  $S(q,\omega)$  is given by Eq. (134).

#### G. Finite-size and finite-temperature effects

One of the successes of the linear LL theory is its ability to easily predict finite-size and finite-temperature effects. This can be achieved because the Gaussian Hamiltonian of the LL is conformally invariant (Gogolin et al., 1998), which results in a universality of the finite-size corrections, such as in the  $\propto 1/L$  correction to the ground state energy or the  $\propto T$  correction to specific heat at low temperatures (Affleck, 1986; Blöte et al., 1986). It can be used as a powerful tool when combined with exact solutions, since the energies in the latter case can be evaluated up to 1/L corrections: such an approach was used to evaluate the Luttinger parameters of the Lieb-Liniger, the XXZ (Bogoliubov et al., 1987) and the 1D Hubbard models (Frahm and Korepin, 1990). Conformal invariance also fixes the time dependence and the finite-size effects in correlation functions.

For example, for spinless fermions at  $\rho |x \pm vt| \gg 1$ , one

has (Cazalilla, 2004)

$$\left\langle \Psi^{\dagger}(0,0)\Psi(x,t)\right\rangle_{\mathrm{LL}} \sim$$
 (136)

$$\sum_{n} \frac{\rho e^{i(2n+1)k_F x}}{2i(-1)^n} \frac{C_n}{(i\rho(vt+x)+0)^{\mu_L} (i\rho(vt-x)+0)^{\mu_R}},$$

where  $C_n$  are "nonuniversal" prefactors, and

$$\mu_{R(L)} = (2n+1)^2 K/4 \pm (2n+1)/2 + 1/4K \ge 0.$$

For a finite system with periodic boundary conditions on a circle of length L, conformal invariance dictates (Cazalilla, 2004; Shashi *et al.*, 2011) that the nth term in Eq. (136) gets modified to

$$\frac{\rho e^{i(2n+1)k_F x} C_n}{2i(-1)^n} \prod_{L,R} \left( \frac{\pi e^{i\pi(vt\pm x)/L}}{i\rho L \sin\frac{\pi(vt\pm x)}{L} + 0} \right)^{\mu_{L(R)}}. \quad (137)$$

The goal of this section is to promote the phenomenological theory based on impurity Hamiltonians to the same status. It will not only provide new predictions, but will also serve as a calculational tool to extract information from exactly solvable models (see Sec. III) and interpret the results of numerical simulations.

Let us start with the discussion of finite-size effects. For concreteness, we will focus on spinless fermions and the vicinity of the edge of support. The finite-size spectrum of  $\propto 1/L$  corrections is that of a shifted Gaussian conformal theory (Tsukamoto *et al.*, 1998), and can be determined using conventional techniques. The correction to the position of the edge in standard notations (Korepin *et al.*, 1993) is given by (Pereira *et al.*, 2008, 2009)

$$\Delta E = \frac{2\pi v}{L} \left[ \frac{1}{4K} (\Delta N - n_{imp})^2 + K(D - d_{imp})^2 \right],$$
(138)

where  $\Delta N$  and D are quantum numbers specifying the excitations, while  $n_{imp}$  and  $d_{imp}$  are related to phenomenological phases in Eq. (75) via

$$n_{imp} = \frac{\delta_{-}(k) - \delta_{+}(k)}{2\pi/\sqrt{K}}, \ d_{imp} = -\frac{\delta_{+}(k) + \delta_{-}(k)}{4\sqrt{K}\pi}.$$
 (139)

The quantum numbers  $\Delta N$  and D are related to the numbers  $N_R$  and  $N_L$  of fermions created at each Fermi point, which define the exponents as discussed in Sec. II.C. For fermionic models, they are given by  $\Delta N = N_R + N_L$  and  $D = (N_R - N_L)/2$ . Thus, Eq. (138) allows one to calculate the phase-shifts  $\delta_{\pm}(k)$  by, e.g., numerical tracking of the  $\propto 1/L$  corrections to energies.

We will now consider the finite-size  $\propto 1/L$  structure of low-lying levels at fixed k, as well as the scalings of various matrix elements (Shashi *et al.*, 2011). Using a resolution of the identity in the expectation value  $\langle \Psi^{\dagger}(0,0)\Psi(x,t)\rangle$ , we get

$$\langle \Psi^{\dagger}(0,0)\Psi(x,t)\rangle = \sum_{s'} e^{-i(k_{s'}x - \varepsilon_{s'}t)} |\langle s', N - 1|\Psi|N\rangle|^2,$$
(140)

where  $|s', N-1\rangle$  denote eigenstates with N-1 particles. In a finite-size system, the formfactors in this equation have to be matched with the field-theoretical predictions.

To understand the procedure, let us first consider the scaling of the formfactors between low-energy states for 1D fermions (Bogoliubov *et al.*, 1987), which can be described by the conventional LL theory. We can now expand terms in Eq. (137) using a Fourier series as

$$\left(\frac{\pi e^{i\pi(vt\pm x)/L}}{iL\sin\frac{\pi(vt\pm x)}{L} + 0}\right)^{\mu} = \sum_{n_{\mp} \ge 0} C(n_{\mp}, \mu) \frac{e^{2i\pi n_{\mp}} \frac{vt\pm x}{L}}{(L/2\pi)^{\mu}},$$

$$C(n_{\pm}, \mu) = \frac{\Gamma(\mu + n_{\pm})}{\Gamma(\mu)\Gamma(n_{\pm} + 1)}.$$
(141)

In this equation, the summation only over  $n_+$  is implied for right branch contribution, and the summation only over  $n_-$  is implied for left branch contribution. Plugging Eq. (141) into Eq. (137), and comparing the result to Eq. (140), one can clearly identify contributions from excitations at the right (left) Fermi branches with energies  $2\pi v n_{\pm}/L > 0$ , respectively. To accommodate the additional momentum  $-(2n+1)k_F$ , one needs to put n+1 holes at the right Fermi point and n particles at the left Fermi point. The contributions from  $n_+ = n_- = 0$  give the scalings of the "parent" formfactors (Bogoliubov et al., 1987)

$$|\langle n, N - 1 | \Psi | N \rangle|^2 \approx \frac{C_n \rho_0}{2(-1)^n} \left(\frac{2\pi}{\rho_0 L}\right)^{\frac{(2n+1)^2 K^2 + 1}{2K}}, (142)$$

where  $|n, N-1\rangle$  is the lowest energy state of N-1fermions with momentum  $-(2n+1)k_F$ . The nontrivial scaling of this formfactor with L is a consequence of the criticality of the LL. The studies of scalings of the formfactors serve as a tool to evaluate the nonuniversal prefactors  $C_n$  (Shashi et al., 2011, 2010), which are usually not known except for a few cases (Astrakharchik et al., 2006; Gangardt, 2004; Gangardt and Kamenev, 2001; Jimbo et al., 1980; Lukyanov and Terras, 2003; Popov, 1980; Vaidya and Tracy, 1979). Within  $\propto 1/L$  accuracy, for  $n_{\pm} \geq 2$  the excited states of N-1 particles are degenerate, while the degeneracy within each "multiplet" is lifted by  $\propto 1/L^2$  corrections due to the nonlinear spectrum. The universal Hamiltonian of Sec. II.B predicts the distribution of the spectral weight within each "multiplet", as has been shown by Shashi et al. (2011).

Let us now apply a similar logic to the finite-size behavior of the response functions near the edge of support, and for concreteness we will focus on the spectral function  $A(k,\varepsilon)$  for  $|k| < k_F$  and  $\varepsilon < 0$ . In addition to the LL, we now also need to take into account the finite-size quantization of the momentum of the impurity moving with velocity  $|v_d| < v$ . For an infinite-size system,  $A(k,\varepsilon)$  in the vicinity of the edge  $\varepsilon_{\rm th}(k) < 0$  (see notations in

Sec. II.C) can be written as

$$A(k,\varepsilon) = A_{0,-}(k) \int dx dt e^{-i\delta\varepsilon t} D(x,t) L(x,t) R(x,t),$$
(143)

where  $\delta \varepsilon = \varepsilon - \varepsilon_{\text{th}}(k)$ ,  $D(x,t) = \delta(x - v_d t)$  is the impurity correlator,  $L(R)(x,t) = (i(vt \pm x) + 0)^{-\mu_{0,-,L(R)}}$ , and  $A_{0,-}(k)$  is a "nonuniversal" prefactor, see Eqs. (80) and (81). After (x,t) integration, Eq. (143) results in

$$A(k,\varepsilon) = \frac{2\pi\theta(-\delta\varepsilon)A_{0,-}(k)|\delta\varepsilon|^{-\mu_{0,-}}}{\Gamma(1-\mu_{0,-})(v+v_d)^{\mu_{0,-,L}}(v-v_d)^{\mu_{0,-,R}}}.$$
(144)

In finite-size systems, L(x,t) and R(x,t) get modified, see Eq. (141). Similarly, the change of D(x,t) to  $\sum_{n_D} e^{2i\pi n_D(x-v_dt)/L}$  corresponds to the quantization of the impurity momentum. Since we are considering fixed k, the total momentum of the excitations on the left and right branches should be equal to the inverse of the shift of the momentum of the impurity  $2\pi n_D/L$ , which implies  $n_D = n_- - n_+$ . Combining these terms, we get for  $A(k, \varepsilon)$ 

$$\sum_{n_{\pm}\geq 0} \delta \left( \delta \varepsilon - \Delta E + \frac{2\pi n_{+}}{L} (v - v_{d}) + \frac{2\pi n_{-}}{L} (v + v_{d}) \right) \times A_{0,-}(k) \frac{(2\pi)^{\mu_{0,-,R} + \mu_{0,-,L} + 1}}{L^{\mu_{0,-,R} + \mu_{0,-,L}}} C(n_{+}, \mu_{0,-,R}) C(n_{-}, \mu_{0,-,L}).$$
(145)

At  $\propto 1/L$  accuracy, the finite-size structure of the response function is given by the sum of two generically incommensurate frequency "ladders", with the relative spectral weights in each "multiplet" controlled by the phase shifts  $\delta_{\pm}(k)$ . Equation (145) allows for an analytical or numerical evaluation of  $A_{0,-}(k)$  based on the scaling of the single formfactor with  $n_{+}=n_{-}=0$  as

$$\left| \langle k; N-1 | \Psi | N \rangle \right|^2 \approx \frac{A_{0,-}(k)}{L} \left( \frac{2\pi}{L} \right)^{\mu_{0,-,R} + \mu_{0,-,L}}$$

where  $|k;N-1\rangle$  in the eigenstate of N-1 particles corresponding to the edge of support at  $|k| < k_F$ . The structure described by Eqs. (142) and (145) can be explicitly confirmed for certain integrable models (Kitanine et al., 2009a,b, 2011; Shashi et al., 2010) using known expressions for the finite-size formfactors. This provides a stringent microscopic check of the phenomenological impurity Hamiltonians and allows to analytically calculate various "nonuniversal" prefactors for these models. In addition, it allows to calculate various prefactors perturbatively (Shashi et al., 2011).

Let us now comment on the effects of finite temperatures, which are quite different for nonlinear LLs compared to linear ones. In the latter, conformal invariance allows one to calculate (Giamarchi, 2004) most of the finite-temperature effects by simple substitutions such as

v/L → iT. This cannot be done for nonlinear LLs. The full analysis of the finite-temperature effects, especially in kinetic problems (see Sec. IV), remains an open problem. Let us make some general remarks here focusing on the response functions of spinless fermions.

For the interacting case, a finite temperature smears the sharp edges of support of the spectral function. However, far away from the Fermi points and at |εth(k)| T (we use k<sup>B</sup> = 1 throughout the text), there is a large interval of energies where the effect of temperature can be captured by substituting the Fermi point correlators by their finite-temperature versions (Karimi and Affleck, 2011), i.e., in Eq. (143)

$$L_T(R_T)(x,t) \to \left(\frac{2\pi T/v}{\sin\left[2\pi i T(t\pm x/v) + 0\right]}\right)^{-\mu_{0,-,L(R)}}.$$

At the same time, the impurity correlator D(x, t) can be kept as a delta-function, because the correction to the impurity "occupation number" is exponentially suppressed. These substitutions result in universal functions characterizing the smearing of the edge singularities

$$A_T(k,\varepsilon) = A_{0,-}(k) \int dt e^{-i\delta\varepsilon t} L_T(v_d t, t) R_T(v_d t, t).$$

Note that these functions can be evaluated numerically and generically have a strongly non-Lorentzian shape. The temperature mostly affects the response functions at energies of the order of ∼ T from the edges of support.

In the vicinities of the Fermi points, one can use the universal Hamiltonian of Sec. II.B to take a finite temperature into account. A na¨ıve extension of the above argument would imply a smearing of the nonlinear LL physics for the DSF at temperatures on the order of ∼ q <sup>2</sup>/( ˜m). We note, however, that this is not the case, as can be illustrated by the DSF of noninteracting fermions. The latter can be straightforwardly evaluated as in Sec. II.A.1, and in the limit q k<sup>F</sup> reads

$$S_0(q,\omega) = \frac{m}{q} \prod_{\pm} n_F \left[ v_F \frac{\pm m(\omega - v_F q) - q^2/2}{q} \right], \quad (146)$$

where the Fermi-Dirac distribution function n<sup>F</sup> () = 1/[exp (/T) + 1] replaces the step functions in Eq. (10). One sees that the zero-temperature result (10) survives up to temperatures on the order of ∼ v<sup>F</sup> q. Similarly, the universal Hamiltonian of Sec. II.B implies that at finite temperatures Eq. (54) is replaced by

$$S(q,\omega) = \frac{K\tilde{m}}{q} \prod_{\pm} n_F \left[ v \frac{\pm \tilde{m}(\omega - vq) - q^2/2}{q} \right], \quad (147)$$

so that the DSF is barely different from its T = 0 form as long as the temperature is small compared to vq. The mechanism of the DSF smearing by finite temperature expressed in Eq. (146) is the same as in Eq. (147). At

q k<sup>F</sup> , the DSF involves only contributions from the right-moving quasiparticle and quasihole with momenta of the order ∼ q around the Fermi point. A finite temperature smears their velocities by δv ∼ T /( ˜mv). The corresponding energy variation qδv ∼ qT /( ˜mv) is small compared to q <sup>2</sup>/m˜ as long as T vq.

There is a substantial difference between the domains of applicability of Eqs. (146) and Eq. (147) though. In the former, the limits q → 0 and T → 0 may be taken in any order. The latter is valid only in the limit when, in addition to keeping ˜m(ω−vq)/q<sup>2</sup> constant at q → 0 as in Eqs. (54) and (63), T /(qv) is kept constant. As a result, Eq. (147) does not hold at fixed T and q → 0, which will be important in Sec. IV.B.

Unlike the DSF, the spectral function in the universal limit is a convolution of contributions from both left and right Fermi points. The kinematic considerations of Sec. II.A and Sec. II.B imply that the quasiparticles at the left branch have energies of the order ∼ (k−k<sup>F</sup> ) <sup>2</sup>/m, ˜ , so the finite-temperature smearing of the nonlinear effects in the spectral function is a two-step process (Ma and Imambekov, 2012).

First, at temperatures ∼ (k−k<sup>F</sup> ) <sup>2</sup>/m˜ , the contribution from the left branch gets smeared out. The contribution from the right branch gets affected significantly only at temperatures on the order of ∼ v(k − k<sup>F</sup> ). It should be noted that the spectral function of chiral fermions at the edges of quantum Hall states (Altimiras et al., 2009; Altimiras et al., 2010; Chang, 2003; Granger et al., 2009; Heyl et al., 2010; Jolad et al., 2010; Lunde et al., 2010; Neuenhahn and Marquardt, 2009; Paradiso et al., 2011; le Sueur et al., 2010) should be more robust to finite temperatures due to the absence of the counter-propagating branch.

# H. Real-space correlation functions

In the previous sections, we showed that the powerlaw singularities of the spectral function A(k, ε) near the edge of support can be described with the help of mobileimpurity Hamiltonians for 1D fermionic, bosonic and spin systems. We will show in this section that the existence of these threshold singularities has important implications for the space-time correlation functions in the limit of large x and t. In particular, we will elucidate the connection between the threshold singularities and the breakdown of conformal invariance, focusing on the case of spinless fermions.

Using a Lehmann spectral representation (Abrikosov et al., 1963), various space-time Green's functions can be obtained by Fourier transforming the spectral function.

![](_page_33_Picture_1.jpeg)

![](_page_33_Picture_2.jpeg)

FIG. 10 (Color online) (a) Calculation of the real-space correlation functions. The integration range for the calculation of  $\langle \Psi^{\dagger}(0,0)\Psi(x,t)\rangle$  from  $A(k,\varepsilon)$  is shaded. For large t and fixed  $x/t=v_d$ , the contributions to the integral come from a region around  $\varepsilon=0$ , and from points at which the lines  $\varepsilon-kv_d=$  const. touch the edge of support. (b) Breakdown of conformal invariance in  $\langle \Psi^{\dagger}(0,0)\Psi(x=v_dt,t)\rangle$ . In the shaded areas  $(|v_d|>v)$  only the linear Luttinger liquid (LL) power laws survive, see Eq. (136). In the white areas, for  $|v_d|< v$ , new power laws appear in addition, see Eq. (151).

For example,

$$\left\langle \Psi^{\dagger}(0,0)\Psi(x,t)\right\rangle = \frac{1}{2\pi} \int dk \int_{-\infty}^{0} d\varepsilon e^{ikx} e^{-i\varepsilon t} A(k,\varepsilon). \tag{148}$$

In a similar way,  $\langle \Psi(x,t)\Psi^{\dagger}(0,0)\rangle$  can be expressed via the Fourier transform of  $A(k,\epsilon>0)$  in the particle sector.

As is well known in the theory of Fourier transformations (Bleistein and Handelsman, 1986), the nonanalyticities of  $A(k,\epsilon)$  control the long space-time behavior of its Fourier transforms. The spectral function is non-analytic in the vicinities of the Fermi points and their  $2nk_F$  images. We showed in the previous sections that the regions where  $A(k,\varepsilon)$  deviates significantly from the predictions of the linear LL theory become narrow in the limit  $\varepsilon \to 0$ . As a consequence, the effects of the spectrum nonlinearity are suppressed near  $\varepsilon \approx 0$  when integrating over k. Neglecting the nonlinear effects in the vicinities of the Fermi points produces the well-known space-time power-law behavior of the correlation functions in Eq.(136) at  $\rho |x \pm vt| \gg 1$ . This result is manifestly conformal invariant due to the conformal invariance of the LL Hamiltonian (41). If one considers the limit

$$t \to \infty$$
 and  $v_d = x/t$  fixed, (149)

Eq. (136) results in the same set of power-law tails in t irrespective of the ratio  $v_d/v$ .

We will show now that in the limit (149), the threshold singularities in  $A(k,\varepsilon)$  may generate a new set of power-law tails in t. For generic interacting spinless fermions,

such power laws appear only for  $|v_d| < v$  and, moreover, the exponents depend on the ratio  $v_d/v$ . The origin of these power laws is very similar to that of van Hove singularities in the density of states of noninteracting systems (Landau and Lifshitz, 1980) and is illustrated in Fig. 10a. To study the limit (149), it is convenient first to make a rotation of coordinates in the (x,t) and  $(k,\varepsilon)$  planes to

$$x' = \frac{x - v_d t}{2}, \qquad t' = \frac{x + v_d t}{2v_d},$$
  

$$k' = \varepsilon / v_d + k, \qquad \varepsilon' = \varepsilon - k v_d. \qquad (150)$$

In these coordinates, one has  $kx - \varepsilon t = k'x' - \varepsilon't'$ , and we are interested in the limit  $x'=0, t'=t\to\infty$ . Therefore, to study this limit one needs first to keep  $\varepsilon'$  constant (tangential lines in Fig. 10a) and integrate over k'. The non-analyticities near the Fermi points and their  $2nk_F$ images produce the conventional LL power laws (136). In addition, after the integral over k' is performed, for  $|v_d| < v$ , the existence of sharp edges of support produces new non-analyticities in  $\varepsilon'$  from the vicinities of the touching points, see Fig. 10a. The origin of these non-analyticities is very similar to that of van Hove singularities, but unlike the latter they also depend on the threshold exponents of the spectral function. The touching condition implies that  $v_d$  is nothing but the impurity velocity. Each "shadow band" produces a separate power law and an evaluation of the Fourier transform (148) results in

$$\langle \Psi^{\dagger}(0,0)\Psi(x=v_{d}t,t)\rangle = \langle \Psi^{\dagger}(0,0)\Psi(v_{d}t,t)\rangle_{\text{LL}}$$
(151) 
$$+ \sqrt{\frac{m_{d}}{-2i\pi}} \sum_{n} \frac{e^{-i\pi\mu_{n,-}/2}A_{n,-}(k_{d})e^{-i\epsilon(k_{d})t + i(k_{d}+2nk_{F})x}}{t^{1/2}(vt+x)^{\mu_{n,-,L}}(vt-x)^{\mu_{n,-,R}}}$$

where the correlation function of the linear LL  $\langle \Psi^{\dagger}(0,0)\Psi(v_dt,t)\rangle_{\mathrm{LL}}$  is defined in Eq. (136) and the momentum  $k_d$  is defined by the touching condition  $v_d=\frac{\partial \varepsilon_{\mathrm{th}}(k)}{\partial k}\Big|_{k=k_d}$ . The effective mass  $m_d$  is given by  $1/m_d=\frac{\partial v_d/\partial k|_{k=k_d}}{\partial v_d/\partial k|_{k=k_d}}$ . The exponents  $\mu_{n,-,R(L)}$  are defined by Eq. (82) and  $A_{n,-}(k_d)$  are the non-universal prefactors from Sec. II.G.

We note that for sufficiently weak interactions the new "nonlinear" tails in t decay slower than the linear LL tails for all  $|v_d| < v$ . Indeed, for noninteracting fermions and  $v_d = 0$ , the contributions from the Fermi points decay as  $\propto 1/t$ , whereas the contribution from the bottom of the band decays only as  $\propto 1/\sqrt{t}$  due to a conventional van Hove singularity there (Gutman, 2008). For the integrable Lieb-Liniger model, expansions similar to our Eq. (151) have been obtained from purely microscopic considerations (Kozlowski, 2011; Kozlowski and Terras, 2011) and match the exact results for the exponents calculated in Sec. III.B. Similar results have been obtained for a gas of 1D Lieb-Liniger anyons (Patu  $et\ al.$ , 2009).

In Sec. II.B, we have established that in the vicinity of the Fermi points, the response functions are universal within the nonlinear LL theory. The results of this section then imply that for  $|v_d \pm v| \ll v$ , the time dependence of the field correlator, and its crossover between linear and nonlinear regimes is universal as well. Using the universal expressions (48) for the phase shifts in this limit and Eqs. (136) and (151), one can establish that  $\mu_L + \mu_R > \frac{1}{2} + \mu_{0,-,R} + \mu_{0,-,L}$ . Therefore, the nonlinear results always decays slower in time than the linear LL result. Using a more careful analysis of the prefactors (Imambekov and Glazman, 2009b), one can also establish the scaling of the crossover time  $t_c$  between the two regimes as  $\rho v t_c \sim \left(\frac{\tilde{m}(v-v_d)}{k_F}\right)^{\frac{4-6\sqrt{K}+4K}{2-5\sqrt{K}+2K}}$ For weakly interacting fermions, this condition reduces to  $\rho v_F t_c \sim v_F^2 / (v_F - v_d)^2$ .

Let us now comment on the space and time behavior of the transverse spin correlation function of SU(2) invariant spinful bosons. In Sec. II.E, it has been established that for small momenta  $S^{+-}(q,\omega) \propto$  $(\omega - q^2/(2m^*))^{1-Kq^2/(2\pi^2\rho^2)}$ . Of particular interest is the regime when repulsive interactions between spin-up and spin-down particles are strong. Then the spin-down impurity cannot exchange positions with other particles and effectively becomes trapped (Zvonarev et al., 2007). In the thermodynamic limit, the magnon mass  $m^*$  diverges and the bandwidth of spin excitations becomes very narrow. This is very reminiscent of the narrow-band spinon excitations of strongly-interacting s = 1/2 fermions discussed by Matveev (2004a); Matveev et al. (2007a,b), and mentioned in Sec. II.F. In both cases, the large difference between the bandwidths of spin and charge excitations results in the existence of a new regime where a certain new universal behavior of correlations takes place. Performing the inverse of the Fourier transformation (113) within the saddle point approximation, one obtains (Zvonarev et al., 2007)  $\langle S^{+}(x,t)S^{-}(0,0)\rangle \propto \left[\frac{K}{2(\pi\rho)^{2}}\ln(E_{F}t) + \frac{it}{2m^{*}}\right]^{-1/2} \times \exp\left\{\frac{im^{*}x^{2}}{2t - 2iKm^{*}/(\pi\rho)^{2}\ln(E_{F}t)}\right\}, \text{ where } E_{F} \sim (\pi\rho)^{2}/(2m)$ is introduced to provide a short-time cutoff. For generic interactions, the logarithmic term can be ignored and one obtains the scaling  $x^2 \propto t/m^*$  characteristic of a singleparticle wave packet spreading. However, in the limit of infinitely strong interactions  $m^*$  diverges and one obtains a logarithmic scaling  $(\pi \rho x)^2 \sim K \ln(E_F t)$ . For large but finite  $m^*$  a logarithmic scaling law is applicable in an intermediate time interval, the length of which grows with

# III. EXACTLY SOLVABLE MODELS

the increase of  $m^*$ .

In the previous section, we concentrated on the properties of generic 1D quantum systems beyond the linear

LL description. However, in 1D there exists a class of exactly solvable (or integrable) models, for which energy spectra and thermodynamical properties can be calculated exactly using the Bethe ansatz. The calculation of their correlation functions, on the other hand, is a much more complicated task (Korepin et al., 1993), because it requires not only the knowledge of the exact energies, but also of the matrix elements (formfactors). In addition, one needs to be able to sum over all excited stated in the Lehmann representation in order to obtain answers in the thermodynamic limit. The exact expressions for the formfactors are usually known only in finite-size systems (Ha, 1996; Kitanine et al., 1999; Kojima et al., 1997; Slavnov, 1989, 1990), and so far only few-spinon approximations (Bougourzi, 1996; Bougourzi et al., 1998; Karbach et al., 1997) or fully numerical summations over formfactors (Caux and Calabrese, 2006; Caux et al., 2007, 2005; Caux and Maillet, 2005; Gritsev et al., 2010; Kohno et al., 2010) have been implemented for certain gapless models.

In this section, we review some recent results for the correlation functions of integrable models which have been obtained by combining exact results with field theories beyond the linear LL theory. We will show that a plethora of new results can be derived using this approach. More importantly, exactly solvable models also provide nontrivial checks of the phenomenology and provide additional verification of the effective impurity models. It should be noted that, historically, the analysis of exactly solvable models (Haldane, 1980, 1981a) played an important role in the justification of the linear LL theory. Now these models are proving their worth to extensions of the LL theory as well.

The rest of this section is organized as follows. In Sec. III.A we review some recent progress for the Calogero-Sutherland model (Calogero, 1969, 1971; Sutherland, 1971, 2004). In Sec. III.B we discuss the Lieb-Liniger model and demonstrate several approaches (Cheianov and Pustilnik, 2008; Imambekov and Glazman, 2008; Pereira et al., 2008) to extract parameters of the effective impurity Hamiltonians. In Sec. III.C we consider Yang-Gaudin models (Gaudin, 1967, 1983; Yang, 1967) which describe spinful multi-component systems interacting via a contact potential. In Sec. III.D, we discuss 1D lattice models, such as the spin-1/2 XXZ model (which is equivalent to spinless fermions on a lattice), and 1D Hubbard model (Essler et al., 2005; Lieb and Wu, 1968).

# A. Calogero-Sutherland model

In this subsection, we will discuss the Calogero-Sutherland (CS) model (Calogero, 1969, 1971; Sutherland, 1971, 2004), the most well studied model with inverse square interactions (Haldane, 1988; Kuramoto and

![](_page_35_Figure_1.jpeg)

FIG. 11 (Color online) (a) The DSF  $S(q, \omega)$  of the Calogero-Sutherland (CS) model differs from zero only in a finite interval of frequencies  $\omega_{-} < \omega < \omega_{+}$ . At the boundaries of this interval,  $S(q, \omega)$  exhibits power-law singularities, see Eq. (156) (b) Dependence of  $S(q, \omega)$  on  $\omega$  at a fixed  $q < 2k_F$  and for repulsive interactions,  $\lambda > 1$ .

Kato, 2009; Kuramoto and Yokoyama, 1991; Shastry. 1988). Such models are special among exactly solvable models, because their ground state wavefunctions can often be expressed as Jastrow-type products, and their dynamical correlation functions can be derived in a closed form as multiple integrals because of special properties of their excitations (Arikawa and Saiga, 2006; Arikawa et al., 2001, 1999, 2004; Ha, 1994, 1995; Ha, 1996; Ha and Haldane, 1994; Haldane, 1991; Haldane et al., 1992; Haldane and Zirnbauer, 1993; Kato, 1998; Lesage et al., 1995; Pustilnik, 2006; Talstra and Haldane, 1994; Yamamoto and Arikawa, 1999; Yamamoto et al., 2000). The special quantum mechanical properties of a system with inverse-square ( $\propto 1/r^2$ ) interaction potential can already be seen at the classical level, because a liquid of such particles admits a description using integrable hydrodynamics (Abanov et al., 2009; Abanov and Wiegmann, 2005; Kulkarni et al., 2009; Stone et al., 2008). For concreteness, here we will focus on the DSF of the CS model following Khodas et al. (2007b) and Pustilnik (2006), and illustrate connections to the phenomenology discussed in Sec. II.C. Most of the related results on other inversesquare models are reviewed in a recent book by Kuramoto and Kato (2009).

The CS Hamiltonian is given by

$$H_{CS} = -\frac{1}{2m} \sum_{i=1}^{N} \frac{\partial^2}{\partial x_i^2} + \sum_{i < j} V(x_i - x_j).$$
 (152)

Here m is the mass, and the interaction potential is

$$V(x) = \frac{\lambda(\lambda - 1)/m}{(L/\pi)^2 \sin^2(\pi x/L)} = \frac{\lambda(\lambda - 1)}{mx^2} \quad \text{(for } L \to \infty\text{)}$$

where  $\lambda > 1/2$  is a dimensionless interaction strength defining the LL parameter as  $K = 1/\lambda$ .

Excitations can be simply classified using the language of quasiparticles and quasiholes with respect to a filled "Fermi sea". The long range of the interactions results in a rather peculiar excitation spectrum. For quasiparticles with velocities  $v_+$  larger in absolute value than the

sound velocity  $v = \pi \lambda \rho/m$ , the spectrum is given by  $m(v_+^2 - v^2)/2$ . In contrast, for quasiholes with velocities  $|v_-| < v$ , the spectrum is given by  $m\lambda(v^2 - v_-^2)/2$ . The discontinuity of the effective mass near the Fermi points can be expected from perturbation theory, since the Fourier transform of the  $1/r^2$  potential is nonanalytic,  $V_k \propto |k|$ . Because of that, the universal Hamiltonian of Sec. II.B is not applicable to the CS model.

A special feature of this model is that for rational  $\lambda=r/s$  (where r and s are coprime), the operator  $\rho_{q>0}^{\dagger}$  acting on the ground state creates only right-moving excitations: s quasiparticles and r quasiholes (Ha, 1994, 1995; Ha, 1996). This is not a generic property of integrable systems and has a profound effect on the dynamic response functions. In particular, since no left-moving excitations are created, the DSF  $S(q,\omega)$  is nonzero only in a finite interval of energies,  $\omega_{-}(q) < \omega < \omega_{+}(q)$ , see Fig. 11. The existence of an upper threshold is not expected for generic 1D systems, see Sec. II.A.1. The upper threshold corresponds to a configuration where the entire energy is given to a single quasiparticle, while for  $q < 2k_F$  the lower threshold corresponds to all energy being given to a single quasihole. One can show that for q > 0,

$$\omega_{+}(q) = vq + q^2/(2m),$$
(153)

$$\omega_{-}(q) = vq - \lambda q^2/(2m) \text{ for } q < 2k_F.$$
 (154)

The DSF can be written as

$$S(q,\omega) = q^2 \int \prod_{i,j} dv_{+,i} dv_{-,j} F_{s,r} \delta(q-P) \delta(\omega-E),$$
(155)

where P and E are the total momentum and energy of the excitations, respectively, and the expression for the formfactor  $F_{s,r}$  is given by (Ha, 1994, 1995; Ha, 1996; Haldane, 1995)

$$\propto \frac{\prod_{i < i'} |v_{+,i} - v_{+,i'}|^{2\lambda} \prod_{j < j'} |v_{-,j} - v_{-,j'}|^{2/\lambda}}{\prod_{i,j} (v_{+,i} - v_{-,j})^2 \left(v_{+,i}^2 - v^2\right)^{1-\lambda} \left(v^2 - v_{-,j}^2\right)^{1-1/\lambda}} \,.$$

The analysis of the multidimensional integral in Eq. (155) performed by Pustilnik (2006) then yields a power-law behavior in the allowed regions as

$$\frac{S(q,\omega)}{m/q} \propto \left| \frac{\omega_{+} - \omega_{-}}{\omega - \omega_{\pm}} \right|^{1 - \lambda^{\pm 1}} \text{ for } |\omega - \omega_{\pm}| \ll \omega_{+} - \omega_{-}.$$
(156)

The prefactors of the DSF have also been evaluated following Sec. II.G (Shashi *et al.*, 2010).

The analysis of the spectral function can be performed similarly (Khodas *et al.*, 2007b), and for  $|k| < k_F$ ,  $\varepsilon < 0$  results in the power-law behavior

$$A(k,\epsilon) \propto \theta(\varepsilon_{\rm th}(k) - \varepsilon)(\varepsilon_{\rm th}(k) - \varepsilon)^{1 - (\lambda - 1)^2/(2\lambda)}$$
. (157)

These exponents at generic edges of support  $\pm \varepsilon_{\rm th}(k) = \pm \omega_{-}(k_F - k)$  can be simply recovered from the phenomenological considerations of Sec. II.C, with Eq. (75) resulting in momentum-independent phase shifts

$$\frac{\delta_{-}^{CS}}{2\pi} = -\frac{\delta_{+}^{CS}}{2\pi} = \frac{1}{2} \left( \frac{\lambda - 1}{\sqrt{\lambda}} \right) = \frac{1}{2} \left( \frac{K - 1}{\sqrt{K}} \right). \tag{158}$$

We see that near the right Fermi point, the phase shift  $\delta_{-}^{CS}$  follows the prediction of Eq. (48) in Sec. II.B, while  $\delta_{+}^{CS}$  differs from the universal prediction, as expected due to the slow decay of the inverse-square potential.

#### B. Lieb-Liniger model

Arguably the simplest exactly solvable model, the seminal Lieb-Liniger (Korepin et al., 1993; Lieb, 1963; Lieb and Liniger, 1963) model of 1D bosons interacting via a contact potential, played an important role in the development of both Bethe ansatz ideas (Korepin et al., 1993) as well as the LL description (Efetov and Larkin, 1975; Haldane, 1981a). Although the studies of this model were mostly an academic exercise for more than 40 years, its experimental realization in ultracold atomic gases (van Amerongen et al., 2008; Haller et al., 2009; Kinoshita et al., 2004; Kinoshita et al., 2005; Kinoshita et al., 2006; Tolra et al., 2004) now allows for a parameter-free comparison of theoretical predictions with measurements. Generally, ultracold 1D Bose gases are realized by loading a Bose-Einstein condensate into a deep 2D optical lattice in the y-z plane formed by perpendicular laser beams, or using atom chips. The tight transversal confinement inhibits the occupation of higher transverse modes and provides a clean realization of the Lieb-Liniger model (Olshanii, 1998). These experiments stimulated significant interest in the long-standing problem of calculating its correlation functions (Korepin et al., 1993), which can be measured using interference (Donner et al., 2007; Hofferberth et al., 2007, 2008; Imambekov et al., 2007, 2008; Polkovnikov et al., 2006), photoassociation (Kinoshita et al., 2005), analysis of particle losses (Haller et al., 2011; Tolra et al., 2004), density fluctuation statistics (Armijo et al., 2010; Jacqmin et al., 2011), time-of-flight correlation statistics (Hodgman et al., 2011; Imambekov et al., 2009; Manz et al., 2010), scanning electron microscopy (Guarrera et al., 2012, 2011), or Bragg and photoemission spectroscopy (Clément et al., 2009; Dao et al., 2007; Ernst et al., 2010; Fabbri et al., 2009; Gaebler et al., 2010; Papp et al., 2008; Stamper-Kurn et al., 1999; Stewart et al., 2008; Veeravalli et al., 2008). Recently many new theoretical results were obtained in this direction (Calabrese and Caux, 2007; Caux and Calabrese, 2006; Caux et al., 2007; Cazalilla et al., 2011; Cheianov et al., 2006a,b; Cherny and Brand, 2009; Deuar et al., 2009; Gangardt

and Shlyapnikov, 2003a,b; Golovach et al., 2009; Imambekov and Glazman, 2008; Kheruntsyan et al., 2003; Khodas et al., 2008, 2007a; Kitanine et al., 2009a; Kormos et al., 2011, 2009, 2010; Kozlowski, 2011; Kozlowski and Terras, 2011; Pozsgay, 2011; Shashi et al., 2010; Sykes et al., 2008), but a fully analytical calculation of the correlation functions is still lacking. In this subsection, we will review recent progress for the Lieb-Liniger model based on combining the phenomenology beyond the LL theory with the Bethe ansatz.

The exactly solvable Lieb-Liniger model is given by

$$H_{\text{LiLi}} = -\frac{1}{2m} \sum_{i=1}^{N} \frac{\partial^2}{\partial x_j^2} + 2c \sum_{1 \le i \le k \le N} \delta(x_j - x_k), \quad (159)$$

where c > 0 is the interaction constant and m is the particle mass. In the thermodynamic limit, the ground state is fully characterized by the dimensionless parameter

$$\gamma = 2mc/\rho,\tag{160}$$

where  $\rho=N/L$  is the density. The regime of weak interactions corresponds to  $\gamma\ll 1$ , while strong repulsion, i.e., the Tonks-Girardeau limit (Girardeau, 1960) corresponds to  $\gamma\gg 1$ . The LL parameter equals  $K=v_F/v$ , where v is the sound velocity and  $v_F=\pi\rho/m$  is the Fermi velocity of a noninteracting Fermi gas of density  $\rho$ . The parameter K is uniquely defined by  $\gamma$ , with  $K\approx\pi\gamma^{-1/2}$  for  $\gamma\ll 1$  and  $K\approx 1+4/\gamma$  for  $\gamma\gg 1$  (Cazalilla, 2004).

Let us briefly review the solution of the Lieb-Liniger model to introduce the notation. We will mostly follow the conventions of Korepin et al. (1993). The ground state quasimomenta  $\nu_j$  ( $1 \le j \le N$ ) are given by the solutions of nonlinear Bethe equations

$$L\nu_j + \sum_{k=1}^{N} \theta(\nu_j - \nu_k) = 2\pi n_j,$$
 (161)

where  $\theta(\nu) = 2 \arctan \frac{\nu}{2mc}$  is the two-particle phase shift and the ground state quantum numbers are  $n_j = j - 1 - (N-1)/2$ . In the thermodynamic limit, this system gives rise to the linear integral equation

$$\rho(\nu) - \frac{1}{2\pi} \int_{-Q}^{Q} K(\nu, \eta) \rho(\eta) d\eta = \frac{1}{2\pi}.$$
 (162)

Here,  $\rho(\nu) = \lim_{L\to\infty} 1/(L(\nu_{k+1}-\nu_k))$  is the density of roots,  $K(\nu,\eta) = 4mc/[(2mc)^2 + (\nu-\eta)^2]$ , and Q(-Q) is the highest (lowest) filled quasimomentum; Q is defined by the normalization condition  $\rho = \int_{-Q}^{Q} \rho(\nu) d\nu$ .

Particle-like excitations (Lieb-I mode) can be constructed by adding an extra quasimomentum  $|\lambda| > Q$ , while hole-like excitations (Lieb-II mode) are obtained by removing a quasimomentum  $|\lambda| < Q$ . Such excitations change the total number of particles, and it is customary in the literature (Korepin *et al.*, 1993) to change

![](_page_37_Figure_1.jpeg)

FIG. 12 (Color online) (a) Dynamic structure factor (DSF)  $S(q,\omega)$  and (b) spectral function  $A(q,\varepsilon)$  for the Lieb-Liniger model. Shaded areas indicate the regions where the functions are nonvanishing. Lieb's particle mode  $\varepsilon_1(q)$  and hole excitation mode  $\varepsilon_2(q)$  are indicated.

the boundary conditions for wavefunction from periodic to antiperiodic when the number of particles changes by  $\pm 1$ . Since all quasimomenta  $\nu_j$  are coupled to each other by Eq. (161), the addition of an extra particle or hole will shift all quasimomenta. A convenient way to take this change into account is to introduce a shift function

$$F(\nu|\lambda) = \pm (\nu_j - \tilde{\nu}_j)/(\nu_{j+1} - \nu_j),$$
 (163)

where  $\tilde{\nu}_j$  are the new solutions with antiperiodic boundary conditions, and the upper (lower) sign corresponds to an extra particle (hole). In the thermodynamic limit,  $F(\nu|\lambda)$  satisfies an integral equation

$$F(\nu|\lambda) - \frac{1}{2\pi} \int_{-Q}^{Q} K(\nu, \eta) F(\eta|\lambda) d\eta = \frac{\theta(\nu - \lambda)}{2\pi}. \quad (164)$$

Due to the antiperiodic boundary conditions of  $\tilde{\nu}_j$ , the shift function  $F(\nu|\lambda)$  in fact corresponds to the fermionic Cheon-Shigehara model (Cheon and Shigehara, 1998, 1999), which is dual to the Lieb-Liniger model. However, all results for the Lieb-Liniger model can be formulated using Jordan-Wigner strings and  $F(\nu|\lambda)$ , so we will use the fermionic language for consistency with Sec. II.C.

As will be shown below, the shift functions  $F(\pm Q|\lambda)$  play a crucial role in the calculation of the edge singularities, so we will investigate them in more detail. One can analytically derive the limiting behavior

$$F(Q|Q) = 1 - \frac{1}{2\sqrt{K}} - \frac{\sqrt{K}}{2},$$
 (165)

$$F(-Q|Q) = \frac{1}{2\sqrt{K}} - \frac{\sqrt{K}}{2},$$
 (166)

and  $F(\pm Q|-Q) = -F(\mp Q|Q)$ . Moreover, one can show,

$$F(\pm Q|\lambda) \approx -\frac{\sqrt{K}}{2} + \frac{2mc\sqrt{K}}{\pi\lambda}$$
 for  $Q, mc \ll \lambda$ . (167)

Equations (165)-(166) have been derived by Korepin and Slavnov (1998), and Eq. (167) follows from an expansion

of the right hand side of Eq. (164) combined with

$$\rho(\pm Q) = \sqrt{K/2\pi},\tag{168}$$

see, e.g., Eqs. (I.9.20)-(I.9.22) in Korepin et al. (1993).

The shift function can be used to calculate the exact energies of Lieb's particle  $(\varepsilon_1 > 0)$  and hole  $(\varepsilon_2 > 0)$  excitations as a function of the momentum  $q(\lambda)$ . They are given by  $\varepsilon_{1,2}(q) = \pm \epsilon(\lambda)$ , with  $\epsilon(\lambda)$  defined by

$$\epsilon(\lambda) - \frac{1}{2\pi} \int_{-Q}^{Q} K(\lambda, \eta) \epsilon(\eta) d\eta = \lambda^2 / (2m) - \mu, \quad (169)$$

where  $\mu$  is the chemical potential and  $\epsilon(\pm Q)=0$ . The momentum corresponding to a quasimomentum  $\lambda$  is given by

$$q(\lambda) = \pm \left(\lambda - \pi\rho + \int_{-Q}^{Q} \theta(\lambda - \nu)\rho(\nu)d\nu\right). \tag{170}$$

Here the upper (lower) sign corresponds to a particle (hole) excitation with  $\lambda > Q$  ( $|\lambda| < Q$ ), and q(Q) = 0,  $q(-Q+0) = 2\pi\rho = 2k_F$ . Equations (169) and (170), together with the normalization condition mentioned earlier for  $\rho(\nu)$  provide the full set of equations to determine the form of  $\varepsilon_{1,2}(q)$ , see Fig. 12. Lieb's particle and hole modes can be simply understood in the limits of weak and strong interactions.

In the limit of weak interactions ( $\gamma \ll 1$ ) 1D bosons form a quasicondensate characterized by slow algebraic decay of real-space correlation functions at long distances (Mora and Castin, 2003; Petrov *et al.*, 2000; Popov, 1980). On a semiclassical level, its state can be described by a macroscopic wave function  $\Psi(x,t)$  which is a solution of the 1D Gross-Pitaevskii equation (Pitaevskii and Stringari, 2003),

$$i\partial_t \Psi(x,t) + \frac{1}{2m} \partial_x^2 \Psi(x,t) + 2c(\rho - |\Psi(x,t)|^2) \Psi(x,t) = 0.$$
 (171)

One class of wave-like solutions of Eq. (171) describes Bogoliubov quasiparticles with a dispersion relation  $\varepsilon_1(q) = vq\sqrt{1+(q/2mv)^2}$ , where  $v=\sqrt{\gamma}\rho/m$  is the sound velocity for the weakly interacting gas. A second class of solutions of Eq. (171) are dark solitons (Khodas *et al.*, 2008; Kulish *et al.*, 1976) which have energies  $\varepsilon_2(q) < \varepsilon_1(q)$ . They correspond to localized perturbations of the quasicondensate density and travel at velocities  $v_s(q) = \partial \varepsilon_2(q)/\partial q < v$ . The spectrum is defined implicitly by

$$\varepsilon_2 = \frac{4\rho v}{3} \sin^3\left(\frac{\theta_s}{2}\right), \quad q = \rho[\theta_s - \sin(\theta_s)], \quad (172)$$

where the parameter  $\theta_s \in [0, 2\pi]$  is related to the ratio of the soliton velocity  $v_s(q)$  and the sound velocity v by  $\cos(\theta_s/2) = v_s/v$ .

In the Tonks-Girardeau limit (Girardeau, 1960) of strong interactions (γ 1), a large contact repulsion enforces the equivalent of a Pauli exclusion principle, so the system becomes analogous to weakly interacting fermions. For 0 < q < 2πρ, the Lieb-II mode approaches ε2(q) = vq − q <sup>2</sup>/(2m). The Lieb-I mode approaches ε1(q) = vq + q <sup>2</sup>/(2m) for any q. The exact solution described above smoothly interpolates between the limits of strong and weak interactions. The small-q behavior of the spectra preserves the form ε1,2(q) = vq ± q <sup>2</sup>/(2 ˜m) at any γ, with v and ˜m being functions of γ. We find m˜ = 4π <sup>1</sup>/2m/(3γ 1/4 ) at γ 1 from Eq. (50). Matching the above asymptotes with the spectra of the corresponding wavelike solutions of Eq. (171) determines the region of applicability of the asymptotes, q . ργ3/<sup>4</sup> (Khodas et al., 2008).

Let us now describe the response functions, and for concreteness we will focus on the vicinity of ε2(q). As has been explained in Sec. II.C, the phase shifts δ±(k) define the exponents of the dynamic response functions and can be extracted from the Bethe ansatz by various techniques. The first approach, which does not rely on integrability, is based on Eq. (75), where εth(k = k<sup>F</sup> − q) = −ε2(q) < 0. Another technique is based on the calculation of the finite-size (∝ 1/L) energy shifts defined by Eqs. (138) and (139). This was pioneered by Pereira et al. (2008, 2009) and results in (see Eqs. (138)-(139) for definitions)

$$n_{imp} = \int_{-Q}^{Q} \rho_{imp}(\nu) d\nu, \qquad (173)$$

$$2d_{imp} = \int_{-\infty}^{-Q} \rho_{imp}(\nu) d\nu - \int_{Q}^{\infty} \rho_{imp}(\nu) d\nu, \qquad (174)$$

where ρimp(ν) is defined by

$$\rho_{imp}(\nu) - \frac{1}{2\pi} \int_{-Q}^{Q} K(\nu, \eta) \rho_{imp}(\eta) d\eta = -K(\nu, \lambda).$$
 (175)

Finally, Cheianov and Pustilnik (2008) and Imambekov and Glazman (2008) showed that

$$\delta_{\pm}(k) = 2\pi F(\pm Q|\lambda). \tag{176}$$

This result is based on an identification of the operator U in Eq. (71) with a boundary condition changing operator (Affleck and Ludwig, 1994; Schotte and Schotte, 1969) of the LL particles whenever they pass the mobile impurity d. The LL describes the low energy particles near Fermi points ±Q, and thus the phase shifts δ±(k) are proportional to the shifts of the quasimomenta of particles near these points. Since the shift functions F(±Q|λ) are proportional to the shifts of the quasimomenta due to the presence of a hole, they are proportional to the phase shifts δ±(k). The proportionality coefficient in Eq. (176) is fixed by requiring that the excitation of a particle near

±Q to the next allowed energy state corresponds to a phase shift ±2π.

It is not at all obvious that three approaches described above should lead to the same phase shifts δ±(k). It was shown analytically by Pereira et al. (2009) that the predictions of the latter two coincide, and it can be checked numerically that Eqs. (75) result in the same phase shifts. Thus the coincidence of the three different predictions of the phenomenological Hamiltonian given by Eqs. (64)- (65) provides an unambiguous microscopic confirmation for its validity for the Lieb-Liniger model. Since the effective field theory near the edge of support did not rely on integrability, it is natural to assume that such an approach holds universally for a large class of microscopic non-integrable models as well. Equations (165)- (166) together with (176) are nothing but the universal phase shifts given by Eq. (48). Here the universal phase shifts were derived in a purely microscopic fashion, which provides an independent check of renormalization group (RG) arguments of Sec. II.B.

The phase shifts (176) evaluated at |λ| < Q provide nonperturbative expressions for the exponents of the DSF S(q, ω) and the spectral function A(k, ε) at their edges of support, see Eq. (112). It should be noted however, that the response functions of integrable systems might also have protected singularities (or non-analyticities) within a continuum. For the Lieb-Liniger model, the most prominent of these occur at ε = ±ε1(q). In addition, various weaker "shadow" singularities occur at ε = ±ε1(±q − 2nk<sup>F</sup> ). The exponents can be calculated as in Sec. II.C by introducing the effective mobile impurity with v<sup>d</sup> = ∂ε1(q)/∂q > v, and they are given by (see Fig. 12 for notations)

$$\overline{\mu} = 1 - \mu_{0,R} - \mu_{0,L},$$

$$\mu_{\pm} = 1 - \mu_{0,\mp,R}^b - \mu_{0,\mp,L}^b,$$
(177)

where µ0,R(L) , and µ b 0,∓,R(L) are defined by Eqs. (87) and (112), and one needs to use the phase shifts (176) evaluated at λ > Q.

For singularities which occur within a continuum, one can also calculate the "shoulder ratios" of the weights right above and below the singular line. For instance, for the DSF one obtains (Pereira et al., 2009)

$$\lim_{\delta \varepsilon \to 0} \frac{S[q, \varepsilon_1(q) + \delta \varepsilon]}{S[q, \varepsilon_1(q) - \delta \varepsilon]} = \frac{\sin(\pi \mu_{0,L})}{\sin(\pi \mu_{0,R})}.$$
 (178)

If the exponent µ is negative (i.e., there is a nonanalyticity and not a singularity), then Eq. (178) describes only the non-analytic parts. Similar to Eq. (60), the shoulder ratios are determined only by the phase shifts. The perturbative result (31) can be also interpreted in terms of perturbative phase shifts (25). In addition to the phenomenologically determined shoulder ratios, for the Lieb-Liniger model one can combine the known expressions for the finite size form-factors (Slavnov, 1989, 1990) with the field theoretical predictions of Sec. II.G to obtain predictions for the non-universal prefactors of the edge singularities (Shashi et al., 2010). Such a finite-size analysis also provides a microscopic justification for the existence of the singularities within a continuous spectrum for the Lieb-Liniger model.

#### C. Yang-Gaudin models

It has been established by Yang (1967) and Gaudin (1967) that the Hamiltonian (159) of the previous section remains exactly solvable using the so-called nested Bethe ansatz, even if one does not require the wave function to be symmetric with respect to permutations of  $x_i$  and  $x_i$ . One can impose either symmetry or antisymmetry with respect to permutations of certain subsets of  $x_i$ . This leads to a family of exactly solvable models for 1D multi-component systems, such as spin-1/2 (Gaudin, 1967; Yang, 1967) and SU(N) (Sutherland, 1968) fermions, as well as Bose-Bose (Fuchs et al., 2005; Guan et al., 2007; Li et al., 2003) and Bose-Fermi (Batchelor et al., 2005; Frahm and Palacios, 2005; Imambekov and Demler, 2006a,b; Lai and Yang, 1971) mixtures. In this section, we will review recent exact results for repulsive (iso)spin-1/2 bosonic and fermionic Yang-Gaudin models, illustrating connections with the universal phenomenological description of Sec. II.E and Sec. II.F, respectively.

The general approach is based on the calculation of finite-size corrections to the edge state energies, and their interpretation in terms of phase shifts. This procedure is aided by the known finite-size structure of the effective impurity theories described in Sec. II.G.

Let us start from the discussion of bosons (Zvonarev et al., 2009b), which have a ferromagnetic ground state (Eisenberg and Lieb, 2002). As in Sec. II.E, we choose the magnetization to be pointing in +z direction. The microscopic wave functions in the ferromagnetic sector coincide with those of the Lieb-Liniger model, so all dynamic response functions which do not involve the spin-down state, such as  $S(q,\omega)$ ,  $S^{zz}(q,\omega)$ , and the spectral function for spin-up particles  $A_{\uparrow}(q,\varepsilon)$ , coincide with those of the Lieb-Liniger model. The response functions which involve one spin-down state, e.g.,  $S^{+-}(q,\omega)$ , will have singularities at the magnon spectrum  $\omega_m(q)$ . The states which contain one magnon are characterized by a set of quasimomenta  $\{\nu_1, \ldots, \nu_N, \lambda\}$  which satisfy the set of equations (Gaudin, 1983)

$$L\nu_j + \sum_{k=1}^{N} \theta(\nu_j - \nu_k) = 2\pi n_j + \theta(2\nu_j - 2\lambda) + \pi. \quad (179)$$

![](_page_39_Figure_7.jpeg)

FIG. 13 (Color online) The function  $\alpha(q)$  defining the transverse spin structure exponent for isospin-1/2 bosonic Yang-Gaudin model, see Eq. (181), is plotted for different values of the dimensionless coupling constant  $\gamma$ . The values of the Luttinger parameter K are indicated for each curve and correspond in increasing order to  $\gamma = \infty$ , 1.65, 0.56, 0.238 and 0.109 respectively. Adapted from Zvonarev *et al.* (2009b).

The total momentum P and the energy E are

$$P = \sum_{j=1}^{N} \nu_j, \quad E = \frac{1}{2m} \sum_{j=1}^{N} \nu_j^2. \tag{180}$$

For  $q \ll \pi \rho$ , the magnon spectrum can be expanded as  $\omega_m(q) \approx q^2/(2m^*)$ , and the expression for  $m/m^*$  as a function of  $\gamma$  can be obtained analytically from the exact solution (Fuchs et al., 2005). It has the asymptotic behavior  $1 - 2\sqrt{\gamma}/(3\pi)$  for  $\gamma \ll 1$ , and  $2\pi^2/(3\gamma)$  for  $\gamma \gg 1$ . An analysis of the finite-size corrections to the energy of the magnon allows one to derive equations similar to Eqs. (164) and (176) which define the phase shifts for arbitrary interactions and momenta, see Zvonarev et al. (2009b) for more details. Similar to the Lieb-Liniger model, the phase shifts evaluated from the finite-size corrections coincide numerically with the phenomenological predictions (Kamenev and Glazman, 2009). In Fig. 13, we present the exact results of Zvonarev et al. (2009b) for the transverse spin structure exponent  $\mu_m$ after reparametrization

$$\mu_m(q) = 1 - \frac{K}{2} \left(\frac{q}{k_F}\right)^2 - \frac{(K-1)^2}{K} \alpha(q),$$
 (181)

which is chosen such that  $\alpha(q)$  vanishes at  $q = 0, 2k_F$ .

Considerably more complicated is the case of spin-1/2 fermions (Essler, 2010), since for repulsive interactions the ground state is a singlet (Lieb and Mattis, 1962) and both spin and charge Fermi surfaces are present, as was discussed in Sec. II.F. The existence of two Fermi points is implicitly built into the structure of the Bethe ansatz solution, because instead of a single set of quasimomenta  $\nu_i$  as in Eq. (161), one needs to introduce the spin quasimomenta  $\Lambda_j$  which live in an auxiliary spin space. In

a finite-size system, periodic boundary conditions lead to (Lee *et al.*, 2011; Yang, 1967)

$$L\nu_j = 2\pi I_j - \sum_{\alpha=1}^{N_{\downarrow}} \theta(2\nu_j - 2\Lambda_{\alpha}), \quad (182)$$

$$\sum_{j=1}^{N} \theta(2\Lambda_{\alpha} - 2\nu_{j}) = 2\pi J_{\alpha} - \sum_{\beta=1}^{N_{\downarrow}} \theta(\Lambda_{\alpha} - \Lambda_{\beta}).$$
 (183)

where in the first equation j = 1, ..., N, and in the second equation  $\alpha = 1, ..., N_{\downarrow}$ , while  $I_j, J_{\alpha}$  are integer or half-integer depending on the parities of  $N, N_{\uparrow}$ . The energies and momenta of the eigenstates are given by Eq. (180).

The ground state is characterized by two filled "Fermi seas", one for the quasimomenta  $\nu_i$ , and another for the spin quasimomenta  $\Lambda_{\alpha}$ . Similarly to the Lieb-Liniger model, excitations can be constructed by creating holes in these distributions. At zero magnetic field, the edge of support for the spectral function at  $|k| < k_F$  corresponds to a spinon excitation, where a hole is created in the spinon Fermi sea while a holon is created at the Fermi surface, in complete accordance with the field-theoretical description of Sec. II.F. Equations (180) and (182)-(183) contain the full information about the excitation spectrum of both holons and spinons. In addition, finitesize corrections to their energies can be analyzed similar to Sec. III.B. When combined with the extension of Sec. II.G, they lead to explicit predictions (Essler, 2010) for the phase shifts in terms of microscopic parameters, and the obtained results coincide numerically with the phenomenological predictions (127) and (128). This coincidence provides a nontrivial non-perturbative check of the RG arguments of Sec. II.F, justifying the effective Hamiltonians of impurities with fractional quantum numbers.

Finally, let us mention that recent experimental progress with alkaline earth ultracold atoms (DeSalvo et al., 2010; de Escobar et al., 2009; Fukuhara et al., 2007; Kraft et al., 2009; Stellmer et al., 2009; Taie et al., 2010; Takasu et al., 2003) which naturally posses a higher symmetry of interactions (Cazalilla et al., 2009; Gorshkov et al., 2010) calls for extensions of the present approach to SU(N) invariant Sutherland-type models (Sutherland, 1968).

# D. Lattice models: XXZ, spinless fermions and 1D Hubbard model

As has been discussed in Sec. II.D, the presence of a lattice leads to much wider possibilities for threshold behaviors. In this section, we will review some recent results obtained by combining field-theoretical approaches with the exact solutions of XXZ (Cheianov and Pustilnik, 2008; Karimi and Affleck, 2011; Pereira et al., 2008), spinless fermion (Pereira et al., 2009) and 1D Hubbard models (Essler, 2010). The main modification for a generic

non-integrable model at arbitrary filling is that, strictly speaking, the edges of support disappear due to the presence of the lattice, as has been discussed in Sec. II.D. For integrable systems, this might not necessarily lead to a smearing of the singularities. Nevertheless, to avoid this possible complication, we will discuss here models at commensurate fillings, such as half-filling.

The XXZ model is given by Eq. (90), and its basic properties were discussed in Sec. II.D. Using a Jordan-Wigner transformation it maps onto a Hamiltonian of spinless fermions with nearest-neighbor interactions, see Eq. (94). The structures of the exact solutions of both models are the same and, e.g.,  $S^{zz}(q,\omega)$  of the XXZ model coincides with the DSF of the fermionic model, while  $S^{+-}(q,\omega)$  and the spectral function differ due to the Jordan-Wigner string. For concreteness, here we will focus on the XXZ model and refer the reader to Ref. (Pereira et al., 2009), where spinless fermions have been discussed in detail.

Similarly to the Lieb-Liniger model, the XXZ wave-

function is written as a combination of plane waves (Korepin et al., 1993; Orbach, 1958). It is convenient to characterize them in terms of rapidities  $\lambda$  which are related to the bare two-particle phase shift  $\theta(\lambda=\lambda_1-\lambda_2)$  and the bare momentum  $p_0(\lambda)$  as  $\theta=i\ln\left[\frac{\sinh(2i\eta+\lambda)}{\sinh(2i\eta-\lambda)}\right]$ ,  $p_0=i\ln\left[\frac{\cosh(\lambda-i\eta)}{\cosh(\lambda+i\eta)}\right]$ , where  $\eta$  conveniently parameterizes the interaction via  $\Delta=-\cos 2\eta$ . The solutions of the Bethe equations in terms of the rapidities can be imaginary, which generally leads to a number of complications, such as the existence of bound states discussed in Sec. II.D. Inside the gapless regime, however, the ground state is constructed similar to the Lieb-Liniger model out of real solutions which occupy a "Fermi sea"  $(-\Lambda,\Lambda)$ . Spin wave-like excitations also can be constructed by creating holes

$$\rho(\nu) - \frac{1}{2\pi} \int_{-\Lambda}^{\Lambda} K(\nu, \mu) \rho(\mu) d\eta = \frac{1}{2\pi} \frac{dp_0(\nu)}{d\nu}.$$
 (184)

$$F(\nu|\lambda) - \frac{1}{2\pi} \int_{-\Lambda}^{\Lambda} K(\nu,\mu) F(\mu|\lambda) d\mu = \frac{\theta(\nu - \lambda)}{2\pi}, \quad (185)$$

and adding particles with real rapidities on the top of

the filled "Fermi sea". The density of ground state roots

 $\rho(\lambda)$  and the shift function  $F(\nu|\lambda)$  satisfy the equations

where  $K(\nu,\mu)=d\theta(\nu-\mu)/d\nu$ , and the normalization condition for N spin-down particles on a lattice of size M reads  $\int_{-\Lambda}^{\Lambda} \rho(\lambda) d\lambda = N/M$ . Away from half-filling, the  $\Lambda$  following from this equation is finite and the leading nonlinearity of the spin wave spectrum is quadratic; the results of Sec. II.D.3 are applicable. The peculiarity of the half-filled case (M=2N), expected from the considerations of Sec. II.D, manifests itself in the exact solution as  $\Lambda \to \infty$ . In this case, all integral equations can be solved analytically by Fourier transformation, which leads, e.g., to an analytical expressions for the Luttinger parameter  $K=(2-2\arccos\Delta/\pi)^{-1}$  and the edge of support

 $\omega_L(q)=v\sin(q)=\frac{\pi\sqrt{1-\Delta^2}}{2\arccos\Delta}\sin(q).$  As expected, the leading nonlinearity of spectrum is cubic.

The central objects which determine the exponents of the response functions are the phase shifts  $\delta_{\pm}(k)$ , which similarly to Eq. (176) are given by  $\delta_{\pm}(k) = 2\pi F(\pm \Lambda | \lambda)$ . However, one needs to take the limit  $\Lambda \to \infty$ , and there is an ambiguity in the way this limit should be approached. This has lead to conflicting predictions by Pereira et al. (2008) and Cheianov and Pustilnik (2008). The ambiguity was resolved by Imambekov and Glazman (2009a) in favor of the former, based on a comparison with the universal results of Sec. II.B and the SU(2) symmetry arguments of Sec. II.D for  $\Delta = 1$ . The resulting phase shifts are momentum-independent, and they are given by  $\delta_{-}/(2\pi) = -\delta_{+}/(2\pi) = 1/(2\sqrt{K}) - \sqrt{K}/2$ . The exponents of  $S^{zz}(q,\omega)$  and  $S^{+-}(q,\omega)$  can now be explicitly evaluated using Eqs. (87) and (112), and are given by (Karimi and Affleck, 2011; Pereira et al., 2009)  $\mu_z^- = 1 - K$ ,  $\mu_x^- = 2 - \frac{1}{2K} - K$ . These exponents are momentum-independent and interpolate between the results of the XY and the XXX models of Sec. II.D.

The results for the phase shifts and exponents away from half-filling can be obtained by numerically solving Eq. (185). The behavior of the response function near the energy of the bound state can be also analyzed: such a bound state merges with the spinon excitation at finite momentum, and the field-theoretical description of the singularity changes at this point (Karimi and Affleck, 2011; Pereira et al., 2009).

Finally, let us also briefly comment on the application to the 1D Hubbard model (Essler et al., 2005; Lieb and Wu, 1968), which describes spinful fermions on a lattice. The Lieb-Wu system of equations which determines the energies and momenta of the eigenstates is similar to Eqs. (182)-(183), but with  $\sin \nu_i$  substituting  $\nu_i$  inside the phase shifts. The finite-size corrections to the energies of holon and spinon excitations have been calculated (Essler, 2010), and were used in conjunction with the field-theoretical results of Sec. II.F to obtain predictions for some of the threshold exponents. For certain values of the parameters they coincide numerically with the results of Carmelo et al. (2008, 2004, 2006) obtained using completely different methods. We note, however, that the detailed analysis of the 1D Hubbard model is rather complicated due to the rich kinematics, and some of the first steps in this direction have been made recently (Pereira et al., 2012).

# IV. KINETICS OF AND TRANSPORT IN A NONLINEAR LUTTINGER LIQUID

In this Section, we will review some elementary processes of relaxation, as well as kinetic and transport phenomena emerging in a nonlinear LL. In statistical mechanics, one assumes that a generic macroscopic system,

even if isolated from the rest of the world, will eventually reach a local thermal equilibrium. The density matrix of a finite-size part of such a system will reach the Gibbs distribution as long as that part comprises many particles. The parameters of the equilibrium distribution are fixed by additive conserved quantities (particle number, energy, momentum). Normally, we expect the approach to equilibrium to be controlled by a spectrum of relaxation rates found from an appropriate kinetic equation (Huang, 1987). However, there are prominent counterexamples to that common wisdom. The approach to thermal equilibrium of a system of interacting particles, in any dimension, may be hindered by disorder, resulting in a "many-body localization". This possibility was raised by Anderson (1958), analyzed in the contexts of disordered solid-state conductors (Basko et al., 2006) and atomic cold gases (Aleiner et al., 2010) recently, and currently receives a considerable attention, see Pal and Huse (2010) and references therein. Closer to the subject of this review, the abundance of integrals of motion in a disorder-free system is also deemed to prevent equilibration (Polkovnikov et al., 2011). Such a possibility is foreseen in quantum integrable 1D systems (Sutherland, 2004). Quite remarkably, an experimental investigation of the latter subtle roadblock to equilibration became possible in the context of cold gases (Kinoshita et al., 2006). A restricted phase space for scattering events suppresses relaxation processes even in a generic (nonintegrable) 1D system. Recently, some peculiar features of the electron equilibration were found in experiments with quantum wires formed within a GaAs heterostructure (Barak et al., 2010) and carbon nanotubes (Chen et al., 2009).

Related but not identical to the equilibration problem is the question about singularities in the dependence of the response functions on momentum and frequency. As we saw in Sec. III.B, integrability allows the functions  $A(k,\varepsilon)$  and  $S(q,\omega)$  to be singular within the spectral continuum of excitations, in addition to the "mandatory" non-analytical behavior at the thresholds of the continuum. If integrability is violated, the singularities within the continuum vanish even at zero temperature. At small  $\varepsilon$  or  $\omega$ , the singularities are smeared but not washed out completely, being rather replaced by some finite-width peaks. Like in the theory of Fermi liquids, these widths may be associated with the inverse lifetimes of the quasiparticle states which approximately diagonalize the many-body Hamiltonian of the nonlinear LL. Peak broadening of  $A(k,\varepsilon)$  may be measured, in principle, in a tunneling experiment. We will identify some important elementary relaxation processes specific for various 1D systems in Sec. IV.A.

Equilibration processes and the dynamic density responses of the liquid determine some of its transport properties. The most studied of those are the linear conductivity and the linear conductance of electron liquids

subject to an external electric field. In a 1D system, the relation between the conductivity and the conductance is not trivial. The conductivity is well-defined in a contactless setting, for a homogeneous liquid filling the entire 1D space. Contrary to that, the conductance is determined as the current flowing through a system attached to leads biased with some small voltage. The conductance does depend on the properties of the leads. In fact, the linear LL theory predicts that the dc conductance is determined by the properties of the leads and is independent of the parameters of the LL (Maslov and Stone, 1995; Ponomarenko, 1995; Safi and Schulz, 1995).

The conductivity σ(q, ω) of a homogeneous liquid is related by the Kubo formula to the current-current correlation function (Mahan, 1981). The real part σ 0 (q, ω) = Re σ(q, ω) of the conductivity can be expressed, with the help of the continuity relation and the fluctuationdissipation theorem, in terms of the DSF. The expression for the DSF obtained in the linear LL theory at any temperature results then in σ 0 (0, ω) ∝ δ(ω), commonly referred to as the Drude peak. For Galilean-invariant systems it is not destroyed by spectrum curvature or finite temperatures, regardless of the interactions between particles (Sirker et al., 2011). However, predicting its fate at finite temperatures and in the presence of a lattice is beyond the linear LL description. The umklapp processes which are caused by the lattice and are formally irrelevant at T = 0, may smear the δ-function singularity in σ <sup>0</sup> at finite temperatures. We briefly review this question in Sec. IV.B.

Equilibration processes do affect the conductance G of a 1D electron liquid. These processes, absent in the linear LL, make the conductance temperature-dependent. We review various elementary processes leading to equilibration and their effect on the conductance and other transport characteristics in Sec. IV.C.

Concluding the introduction to this section, we wish to emphasize that all of the questions raised here are beyond of the realm of the linear LL theory. The latter is trivially integrable and easily mapped onto a system of free bosons or free fermions, so one does not expect to find any finite relaxation.

# A. Relaxation processes of excitations in a nonlinear Luttinger liquid

Like in higher dimensions, it is instructive to start the consideration of relaxation processes in 1D by discussing the case of almost-free spinless fermions. At zero interaction, the single-fermion excitations are the true eigenstates with no degeneracies in the single-particle sector, and the ground state is not degenerate or pathological (unlike in the case of free bosons). This is helpful in building a theory of relaxation processes using perturbation theory in the interaction strength. The main part of Sec. IV.A.1 is devoted to the identification and evaluation of the elementary relaxation processes for spinless fermions. We will see that the lack of particle-hole symmetry leads to drastically different relaxation rates for particles and holes at low temperatures. We will also investigate the peculiarities of the energy and particle number transfer between the left- and right-moving species.

Similar to the relaxation rates in higher dimensions, the perturbatively evaluated relaxation rate in 1D vanishes when the particle's excess energy tends to zero. Due to phase space constraints, the rate is proportional to a higher power of the excess energy, see e.g., Eq. (188). This should help in building a full analogue of the Fermi liquid and the kinetic theories of the quasiparticles emerging in the universal description of the nonlinear LL, see Sec. II.B. Such a program for spinless fermions has not been performed yet.

A step in that direction for an actually more complicated case of spin-1/2 fermions is described in Sec. IV.A.2. The complication arises from the spin degeneracy of the free-fermion single-particle states. A harbinger of the difficulties is already seen within the perturbation theory: the scattering cross-section evaluated in the basis of free fermions is divergent at low energies, leading to a relatively slow dependence of the relaxation rate on the particle's energy, see Eq. (191) in Sec. IV.A.1. We will see in Sec. IV.A.2 that upon proper removal of the degeneracy and introduction of spinons and holons, the decay of the latter branch is efficiently suppressed.

Methods built in Sec. IV.A.1 to consider the relaxation of fermions help in the investigation of the relaxation in a 1D Bose liquid. We move to 1D bosons in Sec. IV.A.3. For a weakly interacting gas, the relaxation of particlelike excitations can be understood with the help of perturbation theory, with some improvements required for taking care of the strong modification of the low-energy excitation spectrum. The relaxation of the other important branch of excitations – dark solitons – turns out to be similar to the relaxation of holes in a Fermi gas near the bottom of the band, but requires a non-perturbative treatment.

#### 1. Weakly interacting fermions

In order to identify processes important in relaxation, we first turn to the case of spinless weakly interacting fermions. The curvature of the dispersion relation ξ(k) introduces particle-hole asymmetry into the problem. For relaxation processes, the importance of particlehole asymmetry is already seen within perturbation theory. Indeed, it follows from Eq. (2) that the hole velocity is smaller than the velocity of low-energy excitations, i.e., particle-hole pairs near the Fermi points. Therefore, according to the Cherenkov radiation criterion, a hole introduced into the system cannot emit these exci-

![](_page_43_Figure_1.jpeg)

FIG. 14 (Color online) (a) Relaxation of a high-energy particle due to three-particle scattering (b) Relaxation process for high-energy holes at nonzero temperatures. Filled states are depicted in blue (darker), empty states in white (lighter) color.

tations and consequently cannot relax at zero temperature. On the other hand, a particle moves faster than the low-energy excitations. The emission of particle-hole pairs by a moving particle is therefore allowed by energy and momentum conservation laws. The emission of a single particle-hole pair is identical to a two-particle collision. In this case, energy and momentum conservation can only be satisfied if the two incoming particles with momenta  $k_1$  and  $k_2$  either keep their initial momenta,  $(k_1, k_2) \rightarrow (k_1, k_2)$ , or switch their momenta with the other particle,  $(k_1, k_2) \rightarrow (k_2, k_1)$ . Neither of these options can cause relaxation.

Scattering processes that result in a redistribution of momenta and thus potentially lead to a finite relaxation rate must involve at least three particles. In such three-body collisions three particles with momenta  $k=k_F+p$ ,  $k_R=k_F+p_R$ , and  $k_L=-k_F+p_L$  in the initial state  $|i\rangle$  end up in a final state  $|f\rangle$  with different momenta  $k'=k_F+p'$ ,  $k'_R=k_F+p'_R$ , and  $k'_L=-k_F+p'_L$ , see Fig. 14a. For a generic interaction the transition  $|i\rangle \rightarrow |f\rangle$  has a nonvanishing momentum-dependent amplitude  $\mathcal{A}$ .

In order to evaluate the T=0 relaxation rate of an extra right-moving particle with momentum  $k=k_F+p$   $(0< p\ll k_F)$  due to three-body collisions, we note that the single-particle states  $p_R,p_L$  in the initial state of the transition  $|i\rangle$  are below the Fermi level, while all three single-particle states in the final state  $|f\rangle$  are above it. Applying now Fermi's golden rule, we find

$$\frac{1}{\tau_{p}(k)} \propto \int_{0}^{\infty} dp' dp'_{R} dp_{L} \int_{-\infty}^{0} dp'_{L} dp_{R} |\mathcal{A}|^{2} \tag{186}$$

$$\times \delta \left[ (p + p_{R} + p_{L}) - (p' + p'_{R} + p'_{L}) \right]$$

$$\times \delta \left\{ \left[ \xi(k_{F} + p) + \xi(k_{F} + p_{R}) + \xi(-k_{F} + p_{L}) \right] - \left[ \xi(k_{F} + p') + \xi(k_{F} + p'_{R}) + \xi(-k_{F} + p'_{L}) \right] \right\},$$

where  $\mathcal{A}$  is the three-body collision amplitude introduced above, and the  $\delta$ -functions express the energy and momentum conservation.

In writing Eq. (186) we took into account that for  $p = k - k_F \ll k_F$  the conservation laws cannot be sat-

is fied unless the collision involves both right- and left-moving particles.<sup>2</sup> Further analysis shows that the conservation laws allow a small  $(\lesssim p^2/m)$  energy transfer to the left-movers. Such a solution can be found by iterations. To zero order in  $p_L-p_L'$ , the momentum conservation gives  $p-p'=p_R'-p_R$ . The energy released in the collision of two right-moving particles then is  $\xi(k_F+p)+\xi(k_F+p_R)-\xi(k_F+p')-\xi(k_F+p_R')\lesssim p^2/m$ . This energy is transferred to the left-movers,  $\xi(-k_F+p_L')-\xi(-k_F+k_L)\lesssim p^2/m$ , which corresponds to the momentum transfer  $p_L-p_L'\lesssim p^2/(mv_F)\ll p$ . Accordingly, energy and momentum conservation restrict the range of the momenta contributing to the integral in Eq. (186) to

$$p', p'_R, |p_R| \lesssim p, \qquad p_L, |p'_L| \lesssim p^2/(mv_F).$$
 (187)

The  $\delta$ -functions in Eq. (186) remove the integrations over  $p'_R$  and  $p'_L$ . The remaining phase space constraints yield integration domains  $\sim p^2/(mv_F)$  for  $p_L$  and  $\sim p$  for p' and  $|p_R|$ , see Eq. (187). These three factors (one  $\propto p^2$  and two  $\propto p$ ) yield the estimate (Khodas *et al.*, 2007b)

$$\frac{1}{\tau_p(k)} \propto |\mathcal{A}|^2 [\xi(k)/v_F]^4.$$
 (188)

For a weak generic interaction, the nonvanishing threeparticle collision amplitude  $\mathcal{A}$  appears already in the second order in the interaction strength. In the case of a long-range potential, allowing one to neglect terms proportional to  $V(2k_F)$ , the relaxation rate is (Khodas *et al.*, 2007b)

$$\frac{1}{\tau_p(k)} = C \left[ \nu^2 V_0 (V_0 - V_{k-k_F}) \right]^2 \frac{[\xi(k)]^4}{(mv_F^2)^3}$$
 (189)

where  $C=3^3\pi/(5\cdot 2^8)\approx 0.06$  and  $\nu$  is the density of states. For a potential falling off faster than  $1/x^2$  in real space,  $V_0-V_{k-k_F}\propto (k-k_F)^2$ , which leads to  $1/\tau_p(k)\propto (k-k_F)^8$ . Perturbation theory in the irrelevant interactions Eqs. (52) and (53) to the universal-limit Hamiltonian hints that such behavior persists beyond the perturbation theory.

In the special case of an integrable model, one may expect  $\mathcal{A}$  to be identically zero (Sutherland, 2004). Within the lowest-order perturbation theory, it was checked by Lunde *et al.* (2007) for the Cheon-Shigehara model (Cheon and Shigehara, 1998, 1999) and by Khodas *et al.* (2007b) for the Calogero-Sutherland model that indeed  $1/\tau_n(k) = 0$  for these models.

A vanishing relaxation rate would entail the presence of a power-law singularity in the spectral function  $A(k, \varepsilon)$ 

<sup>&</sup>lt;sup>2</sup> The relaxation rates presented below in Eqs. (188)-(191) assume  $|\xi(k_F+p)| \ll \epsilon_F$ . In addition, we set a constraint  $T \ll \epsilon_F$  for Eqs. (190)-(193).

at the energy spectrum of a particle excitation. That singularity lies within the spectral continuum. Apart from integrable models, however,  $1/\tau_p(k) \neq 0$  at finite k and therefore the particle peak in  $A(k,\varepsilon)$  is broadened within the energy range defined by  $1/\tau_p(k)$ . We notice here, that in a generic case this range scales to zero faster than  $(k-k_F)^4$  with  $k \to k_F$ , cf. Eq. (188), while the deviations from the linear spectrum occur on the scale  $(k-k_F)^2/m$ . This justifies the consideration of power-law singularities in the limit  $k \to k_F$ .

A finite temperature trivially broadens the singularities in  $A(k,\varepsilon)$  even within the linear LL description (Giamarchi, 2004). It would also broaden the singularities in  $S(q,\omega)$  even in the absence of relaxation mechanisms (with a possible exception of the finite-temperature behavior of  $S(q,\omega)$  at  $q\to 0$  which we briefly review in Sec. IV.B). This broadening comes from the smearing of the edge of the Fermi distribution. Relaxation would manifest itself in the time evolution of the distribution function of excitations (thermalization) and in a number of transport phenomena. Here we concentrate just on the elementary processes of relaxation of particles (p) and holes (h).

Turning to the case of small finite temperatures, we notice that the above consideration of the zero-temperature particle relaxation rate remains valid as long as the particle energy  $\xi(k) \gg \sqrt{\epsilon_F T}$ , where  $\epsilon_F = k_F^2/(2m)$  is the Fermi energy. At smaller  $\xi(k)$ , the phase space of left-moving excitations participating in the collision  $(p_L, |p_L'|)$  is not controlled any more by the small transferred momentum of Eq. (187), but rather by thermal smearing  $\sim T/v_F$  of the momentum distribution function. As a result, the factor  $\propto (k - k_F)^2$  coming from integration over  $p_L$  is replaced by a factor  $\propto mT$ , yielding

$$\frac{1}{\tau_p(k,T)} \propto |\mathcal{A}|^2 m T[\xi(k)/v_F]^2 \,, \quad T \ll \xi(k) \ll \sqrt{\epsilon_F T}$$

instead of Eq. (188).

The finite-temperature effect is more dramatic for holes, since it makes their relaxation possible in the first place, see Fig. 14b. Due to thermal smearing, a counterpropagating particle can give up an energy of order of T. Thus, a hole can relax its energy with a characteristic energy loss of  $\Delta\epsilon \sim \epsilon_F T/|\xi(k)|$ . It means that an energetic hole "floats" towards the Fermi level in many steps small compared to  $|\xi(k)|$ , as long as the hole energy remains large compared to  $\sqrt{\epsilon_F T}$ . Under this condition, application of Fermi's golden rule yields the rate

$$\frac{1}{\tau_h(k,T)} \propto |\mathcal{A}|^2 m^2 \epsilon_F \frac{T^3}{|\xi(k)|^2}, \quad |\xi(k)| \gg \sqrt{\epsilon_F T}, \quad (190)$$

for a single step of the relaxation process; this rate defines the lifetime of a state with given energy  $\xi(k)$ .

Within the perturbative treatment, the evaluation of the relaxation rates was generalized to the case of spin1/2 fermions by Karzig *et al.* (2010). Targeting the experiment by Barak *et al.* (2010), the evaluation was performed for electrons in a quantum wire of a small width  $a \ll 1/k_F$  interacting via a Coulomb potential which is screened by a gate at some large distance compared to a and  $1/k_F$ . The relaxation rates were found to be

$$\frac{1}{\tau_p(k,T)} = \frac{9\epsilon_F}{32\pi^3\hbar} \left(\frac{e^2}{\kappa\hbar v_F}\right)^4 \lambda^2 [\xi(k)]|\xi(k)/\epsilon_F|^2, \quad T = 0$$
(191)

for particle excitations. Here,  $\kappa$  is the dielectric constant of the host material, and  $\lambda(\xi) = \ln|1/2k_F a| \ln|\xi/4\epsilon_F|$ . At finite temperatures and excitation energies  $|\xi(k)| \ll \sqrt{\epsilon_F T}$ , particles and holes relax with the same rate,

$$\frac{1}{\tau_p(k,T)} \approx \frac{1}{\tau_h(k,T)} \approx \frac{3c_1 \epsilon_F}{4\pi^3 \hbar} \left(\frac{e^2}{\kappa \hbar v_F}\right)^4 \lambda^2 [\xi(k)] (T/\epsilon_F),$$
$$|\xi(k)| \ll \sqrt{\epsilon_F T}, \tag{192}$$

where the numerical constant is  $c_1 = 4 \ln 2 - 1$ .

Note that the rate Eq. (192) with  $|\xi(k)| \sim T$  also determines the thermalization time of the system towards a boosted equilibrium distribution function [cf. Eq. (227)]. For the relaxation of spinless fermions such thermalization process was addressed rigorously by solving a linearized quantum Boltzmann equation exactly in Ref. (Micklitz and Levchenko, 2011). Interestingly, the equilibrium is not characterized by an equipartitioning of the injected excitation energy. Most of the injected energy rather stays within the, say, right moving branch because the energy transfer between right and left movers is suppressed as can be seen from Eq. (187) and Fig. 14: if a right moving excitation loses an energy  $\sim |\xi(k)|$ , only a fraction  $\sim |\xi(k)/\epsilon_F|$  of that energy is transferred to the left moving branch.

The perturbative treatment of scattering of a spin-1/2 electron off an electron in the Fermi sea requires that the incoming electron has energy  $\xi(k) \gg m v_F V(q \to 0)/\hbar$ . This is the applicability condition for the Born approximation. One may view this condition as the one allowing the electron to preserve its integrity without separating into spin and charge modes in the collision process. Indeed, in the weak-coupling limit, the difference between holon and spinon velocities is  $v_c - v_s \simeq V(q \to 0)/\hbar$ , so one may recast the condition for the applicability of the perturbation theory as  $v_c - v_s \ll \Delta v$ , where  $\Delta v = \xi(k)/(mv_F)$  is the difference of the velocities of the colliding particles; in other words, holon and spinon have no time to separate in the course of the electron collision (Karzig et al., 2010). We note that the perturbative result for particles at the boundary of its applicability,  $\xi(k) \sim m v_F V(q \to 0)/\hbar$ , matches the estimate of the holon relaxation rate evaluated in the limit of low energies, see Sec. IV.A.2 (Schmidt et al., 2010b).

The asymmetry in the relaxation rates of particles and holes is a direct consequence of the nonlinearity of the

![](_page_45_Figure_1.jpeg)

FIG. 15 (Color online) (a) Schematic representation of the experimental setup used by Barak et al. (2010). A bias applied to lead 1 injects the current  $I_1$  through the left tunnel junction into the grounded wire; the current  $I_2$  through the right tunnel junction is collected in lead 2. Depending on the bias polarity, particles or holes are injected. The injection occurs in a window of momenta (marked by shaded regions in panels (b) and (c)) around a value k controlled by the magnetic field B. (b) A hole  $(0 < k < k_F)$  injected from lead 1 cannot relax, and will be collected in lead 2. (c) The relaxation of a particle  $(k > k_F)$  injected from lead 1 results in the formation of additional particle-hole pairs. Since only the particles are extracted into lead 2, the collected current exceeds the injected current; the difference, drawn from the ground corresponds to the hole current sinking into the ground, see the dashed line in panel (a).

excitation spectrum. It naturally explains the results of the experiment (Barak et al., 2010) in which electrons were injected in and extracted from a quantum wire. In the experiment, two tunnel junctions designed to have a momentum-dependent tunneling rate, were attached to a grounded quantum wire, see Fig. 15a. Because of the device constraints, it was possible to inject particles or holes within some band of momenta, with the center of the band controlled by a magnetic field applied perpendicular to the wires comprising the device. When holes were injected through the left junction, the current collected by the right junction was equal to the injected current (blue and red dots follow the same curve in the left portion of Fig. 16). That is naturally explained by the absence of hole relaxation: a single hole injected through the left junction is extracted with the right one, see Fig. 15b. However, once the junctions (and the ap-

![](_page_45_Figure_4.jpeg)

FIG. 16 (Color online) Injected current  $I_1$  (dark dots) and collected current  $I_2$  (light dots) as a function of the magnetic field, which controls the momentum of injected carriers. The two currents coincide in the case of hole injection. If particles are injected, on the other hand, the collected current exceeds the injected one due to relaxation. The experimental setup and physical explanation are shown in Fig. 15. Adapted from Barak *et al.* (2010).

plied injection bias) are tuned to inject and collect particles, the collector current exceeds the injected one. This striking behavior can be explained by the relaxation of an injected particle, which creates a number of particlehole pairs. Particles of these pairs are "scooped" by the collector, while holes are allowed to sink into the ground, see Fig. 15c. A simple set of rate equations explained quantitatively the observations (Barak et al., 2010).

The relaxation processes considered above involve only low-energy excitations and do not change the numbers  $N_L$  and  $N_R$  of left- and right-moving particles. Changing those numbers bears consequences for the conductance, the thermopower, and the thermal conductance (Karzig et al., 2010; Levchenko et al., 2010, 2011a,b; Matveev et al., 2010; Micklitz et al., 2010; Rech and Matveey, 2008; Rech et al., 2009). At low temperatures, the relaxation of the difference  $N_R - N_L$  involves states close to the bottom of the band, see Fig. 17 (Lunde et al., 2007; Matveev and Andreev, 2011). We define the corresponding relaxation time  $\tau_N$  by relation  $d(N_R-N_L)/dt =$  $-(N_R-N_L)/\tau_N$ , assuming that the temperature is the same for the left- and right-movers, while their chemical potentials are slightly different. Because a "deep" hole is involved in the relaxation, the rate is exponentially small at low temperature,  $1/\tau_N \propto \exp(-\epsilon_F/T)$ . The pre-exponential factor scales as a power of temperature, with an exponent depending on the type of interaction potential and the presence of spin degeneracy. If one assumes a smooth (in real space) potential and sets

![](_page_46_Picture_1.jpeg)

FIG. 17 (Color online) A small-momentum relaxation process leading to a change in the numbers of left- and right-movers

V<sup>q</sup> = V0(1 − q <sup>2</sup>/q<sup>2</sup> 0 ) at small q, while Vk&k<sup>F</sup> = 0, then (Lunde et al., 2007; Micklitz et al., 2010)

$$\frac{1}{\tau_N} \sim \epsilon_F \left(\frac{V_0}{v_F}\right)^4 \left(\frac{k_F}{q_0}\right)^4 \left(\frac{T}{\epsilon_F}\right)^7 \exp\left(-\frac{\epsilon_F}{T}\right). \quad (193)$$

The T 7 temperature dependence of the pre-exponential factor comes from the phase space constraints on the scattering event (yielding a factor ∝ T 3 ), and from the partial cancelation of the direct and exchange contributions to the scattering amplitude, similar to the one occurring in Eq. (189), which provides an additional factor ∝ T 4 . Note that the latter factor is not present in higher-order terms with respect to the inter-particle interaction potential. Therefore, in the generic case 1/τ<sup>N</sup> ∝ T 3 exp[εth(0)/T], where εth(0) < 0 is the energy of a hole at the bottom of the band, renormalized by interactions.

We should emphasize that the above estimates of τ<sup>N</sup> refer to an "elementary act" of changing NR−NL. In that act, a hole in the fermion distribution near the bottom of the band changes the direction of its motion. The exponential factor in 1/τ<sup>N</sup> comes from the probability for the existence of such a hole, and the prefactor comes from the inverse lifetime 1/τdh ∝ T <sup>3</sup> of the existing deep hole, see Eq. (190). The characteristic variation of the hole momentum in the scattering event depicted in Fig. 17 is ∆p ∼ T /v<sup>F</sup> , while its energy variation ∼ T <sup>2</sup>/<sup>F</sup> is small compared to the characteristic change of energy (∼ T) in each of the involved particle-hole pairs near the Fermi levels. This is why the hole dynamics may be viewed as diffusion in momentum space with the diffusion constant

$$B \sim (\Delta p)^2 / \tau_{\rm dh} \propto T^5 \tag{194}$$

and is described by a Fokker-Planck equation (Castro Neto and Fisher, 1996). The proportionality coefficient missing in Eq. (194) was found for the case of weak and strong interactions in a system of spinless fermions, respectively, by Micklitz et al. (2010) and Matveev et al. (2010). For arbitrary interaction strength, the results are discussed in Sec. IV.C.

To conclude the discussion of relaxation processes within the perturbative treatment of interactions, we mention here a peculiarity of the scattering processes for spinless fermions on a lattice (Pereira et al., 2009). The free-particle spectrum ξ(k) ∝ − cos k of a tightbinding model allows for two particles with momenta k and k<sup>3</sup> = π − k to scatter into two other states, k<sup>1</sup> and k<sup>2</sup> = π − k1. If the chemical potential is shifted from the middle of the band, this process apparently yields a finite decay rate for a range of possible particle momenta k within first-order perturbation theory. However, it is not fully clear if the lowest-order perturbative treatment is applicable in that special case: for a given state k, the mentioned states k1, k2, k<sup>3</sup> involved in the relaxation process are also involved in the formation of two-particle bound states (Pereira et al., 2009).

# 2. Spinful fermions at arbitrary interaction strength: holon lifetimes

In this section, we will go beyond the weakly interacting limit for spinful fermions, and consider the lifetimes of holons in the low-energy limit.

As we already mentioned, the phase space argument applied to interacting spinless fermions in 1D leads to the estimate of the lifetime in Eq. (188). This estimate is valid at small energies of excitations whose dispersion relation resides within the particle-hole continuum. A similar argument applied to a decay of a holon into two spinons in a 1D spin-1/2 fermionic system would lead to a decay rate ∝ |k−k<sup>F</sup> |, possibly contradicting the notion of a well-defined holon branch at small k − k<sup>F</sup> .

A combination of the methods described in Secs. II.B and II.C should allow us to express the proportionality coefficient in Eq. (188) in terms of higher derivatives of the dispersion relation with respect to momentum and particle density; similarly, these methods should allow one to reliably evaluate the decay rate of a holon. Such a program was not implemented yet for spinless fermions, but an attempt was made to evaluate the broadening of the holon branch of excitations in a spin-1/2 1D fermion system. There is some disagreement in the conclusions of Schmidt et al. (2010b) and Pereira and Sela (2010). We find that the decay rate of a holon close to a Fermi point (+k<sup>F</sup> , for definiteness) scales to zero faster than |k − k<sup>F</sup> | 3 , as we discuss next.

In order to elucidate the possible decay processes for holons, it is convenient to start again from a description in terms of refermionized quasiparticles. The band curvature of the physical fermions leads to interactions between the quasiparticles. Away from the Fermi points, it is advantageous to classify the interaction processes by their relevance in the RG sense and to consider all possible interaction operators which are allowed by SU(2) symmetry and Galilean invariance. Due to its builtin SU(2)-symmetry, non-Abelian bosonization (Gogolin et al., 1998) is a convenient tool to achieve this. Expressed using the left- and right-moving holon densities  $J_{\alpha}(x)$  and spinon densities  $\vec{J}_{\alpha}(x)$  ( $\alpha = L, R$ ), the Hamiltonian of the linear LL reads  $H_0 = H_c + H_s$ , where

$$H_c = 2\pi v_c \int dx [J_R^2(x) + J_L^2(x)],$$

$$H_s = \frac{2\pi v_s}{3} \int dx [\vec{J}_R^2(x) + \vec{J}_L^2(x)].$$
 (195)

The holon and spinon densities are related to the physical fermion operators by

$$J_{\alpha}(x) = \frac{1}{2} \sum_{\sigma} \psi_{\alpha\sigma}^{\dagger}(x) \psi_{\alpha\sigma}(x),$$

$$\vec{J}_{\alpha}(x) = \sum_{\sigma\sigma'} \psi_{\alpha\sigma}^{\dagger}(x) \vec{S}_{\sigma\sigma'} \psi_{\alpha\sigma'}(x),$$
(196)

and  $\vec{S}_{\sigma\sigma'}$  denotes the vector of spin matrices (half of the Pauli matrices for spin-1/2). The operators  $J_{\alpha}(x)$  are related to the physical charge density by  $\rho_c(x) = 2\sqrt{K_c} \langle J_L(x) + J_R(x) \rangle$ . This Hamiltonian emerges at the low-energy RG fixed point and is valid in the narrow-band limit. The leading correction for increased bandwidth is an interaction between left-moving and right-moving spin densities, (Gogolin *et al.*, 1998)

$$H_g = -2\pi v_s g \int dx \ \vec{J}_R(x) \cdot \vec{J}_L(x). \tag{197}$$

Note that when expressed in terms of the Abelian spinon fields  $\tilde{\phi}_s$  and  $\tilde{\theta}_s$ , the operator  $H_g$  generates the sine-Gordon term (Giamarchi, 2004). The band curvature of the physical fermions leads to interaction operators which are cubic in spin and charge densities,

$$H_{\eta} = \frac{4\pi^{2}}{3} \int dx \left[ \eta_{-} (J_{R}^{3} + J_{L}^{3}) - \eta_{+} (J_{R}^{2} J_{L} + J_{L}^{2} J_{R}) \right],$$

$$H_{\kappa} = \frac{4\pi^{2}}{3} \int dx \left[ \kappa_{-} (J_{R} \vec{J}_{R}^{2} + J_{L} \vec{J}_{L}^{2}) + \kappa_{+} (J_{R} \vec{J}_{L}^{2} + J_{L} \vec{J}_{R}^{2}) \right],$$

$$H_{\zeta} = \frac{4\pi^{2} \zeta}{3} \int dx \left( J_{L} + J_{R} \right) \vec{J}_{R} \cdot \vec{J}_{L}.$$
(198)

Note that these operators represent all cubic terms which are compatible with SU(2)-symmetry. In particular, this symmetry prohibits terms linear in the vector operators  $\vec{J}_{\alpha}(x)$ . Interaction operators containing quartic and higher-order terms in  $\vec{J}_{\alpha}(x)$  and  $J_{\alpha}(x)$  do exist but their contribution is subleading for small bandwidths.

The prefactors g,  $\zeta$ ,  $\kappa_{\pm}$  and  $\eta_{\pm}$  can be fixed phenomenologically by relating them to other observable quantities. The modification of the constants of the Hamiltonian Eq. (195) in response to a small density variation yields the relations (Pereira and Sela, 2010; Pereira

et al., 2006; Schmidt et al., 2010b)

$$\kappa_{-} + \kappa_{+} = \frac{v_{c}}{\sqrt{K_{c}}} \frac{\partial v_{s}}{\partial \mu}, \quad \zeta = -\frac{3}{2} \frac{v_{c}}{\sqrt{K_{c}}} \frac{\partial (v_{s}g)}{\partial \mu}.$$
(199)

The difference  $\kappa_- - \kappa_+$  can be related to the mass m of the physical fermions by considering a charge current variation of the Galilean-invariant system. One finds (Nayak et al., 2001; Pereira and Sela, 2010)

$$\kappa_{-} - \kappa_{+} = \frac{1}{m\sqrt{K_c}}. (200)$$

It is known that upon a bandwidth reduction g flows logarithmically to zero (Gogolin et~al., 1998). Assuming the initial bandwidth to be of order  $k_F$ , for a smaller bandwidth of order  $k-k_F$  the effective coupling constant will flow to  $g(k)=1/\ln[k_F/(k-k_F)]$ . As the chemical potential  $\mu$  is proportional to  $k_F$ , the derivative  $\partial g/\partial \mu \propto -g^2/k_F$ , as noted by Schmidt et~al. (2010b). The derivative  $\partial v_s/\partial \mu$ , on the other hand, remains finite for small bandwidths. Therefore, in leading logarithmic approximation,  $\partial g/\partial \mu$  can be neglected and the coupling constants  $\kappa_{\pm}$  and  $\zeta$  can be related as

$$\zeta \approx -\frac{3}{2}g \frac{v_c}{\sqrt{K_c}} \frac{\partial v_s}{\partial \mu} = -\frac{3}{2}g(\kappa_- + \kappa_+). \tag{201}$$

Holons can relax via the creation of low-energy spinons. Let us investigate the decay of an initial state  $|i\rangle=|k\rangle_c|0\rangle_s$  which contains an additional holon with momentum above the Fermi edge and no spinon excitations. Relaxation of the holon to a momentum k' < k can happen via the creation of two spinon density excitations with momenta  $p_L < 0$  and  $p_R > 0$ . This final state will be labeled  $|f\rangle = |k'\rangle_c|p_L,p_R\rangle_s$ . For momenta k close to the Fermi point, momentum and energy conversation for this process read

$$k = k' + p_R + p_L$$
,  $v_c k = v_c k' + v_s (p_R - p_L)$ ,

and have nontrivial solutions  $(k \neq k')$  for  $v_c > v_s$ .

The holon lifetimes associated with this decay channel can be calculated using Fermi's golden rule. Two combinations of operators from the interaction terms (198) have a nonzero matrix element between the states  $|i\rangle$  and  $|f\rangle$ . To first order in the interaction,  $\langle f|H_{\zeta}|i\rangle$  is the only such term. To second order, only  $\langle f|H_gH_{\kappa}|i\rangle$  and  $\langle f|H_{\kappa}H_g|i\rangle$  are nonzero.

For the first-order matrix element  $T_{\zeta} = \langle f|H_{\zeta}|i\rangle$ , one finds (Schmidt *et al.*, 2010b)

$$T_{\zeta} = \frac{\pi \zeta}{2L} \delta_{k-k'-p_L-p_R} \sqrt{|p_L p_R|}.$$
 (202)

The matrix elements  $\langle f|H_g|i\rangle$  and  $\langle f|H_{\eta}|i\rangle$  vanish because  $H_g$  and  $H_{\eta}$  do not couple spinons and holons. The remaining first-order matrix element  $\langle f|H_{\kappa}|i\rangle=0$  because it contains only terms of the form  $\bar{J}_{\alpha}^2(x)$ , which do not create spinons on opposite branches.

To the second order, cross-terms of the operators H<sup>g</sup> and H<sup>κ</sup> may couple the same initial and final states as above, yielding the amplitude

$$T_{\kappa g} = \frac{3\pi g}{4L} (\kappa_{-} + \kappa_{+}) \delta_{k-k'-p_{L}-p_{R}} \sqrt{|p_{L}p_{R}|}.$$
 (203)

Other second-order terms exist but they contain higher powers of p<sup>L</sup> and p<sup>R</sup> and are therefore subleading compared to Tκg for holon momenta k near the Fermi points. According to Fermi's golden rule the rate is

$$\frac{1}{\tau_{\text{holon}}} = 2\pi \sum_{|f\rangle} |T_{\zeta} + T_{\kappa g}|^2 \delta(\epsilon_f - \epsilon_i), \qquad (204)$$

where <sup>i</sup> and <sup>f</sup> are the energies of the initial state |ii and the final state |fi, respectively. The sum over all final states |fi translates to a summation over the momenta p<sup>L</sup> < 0, p<sup>R</sup> > 0 and k <sup>0</sup> ∈ [k<sup>F</sup> , k]. It can be seen from Eqs. (202) and (203) that each of the decay channels taken individually would lead to a decay rate 1/τholon ∝ (k −k<sup>F</sup> ) 3 . However, Fermi's golden rule (204) contains the square of the sum of the probability amplitudes T<sup>ζ</sup> and Tκg. The prefactors of both amplitudes are related according to Eq. (201) and one finds T<sup>ζ</sup> +Tκg = 0. Therefore, the decay rate vanishes<sup>3</sup> up to terms proportional to g 2 (k − k<sup>F</sup> ) 3 , in the calculation of 1/τholon performed to the second order in g = 1/ ln[k<sup>F</sup> /(k − k<sup>F</sup> )]. Retaining in Eq. (199) the derivative ∂g/∂µ ∝ g <sup>2</sup>/<sup>F</sup> exceeds the accuracy of our calculation. It is not clear if the evaluation of 1/τholon to order g <sup>4</sup> would yield zero. Possibly, in that order the distinction between integrable and non-integrable systems emerges.

In the limit of weak backscattering, V (2k<sup>F</sup> ) V (0) v<sup>F</sup> , the universal logarithmic dependence for g(k − k<sup>F</sup> ) is reached only at very low energies, while its bare value g ∝ V (2k<sup>F</sup> )/v<sup>F</sup> is applicable as long as [V (2k<sup>F</sup> )/v<sup>F</sup> ] ln[k<sup>F</sup> /(k − k<sup>F</sup> )] 1. In that limit, which includes weak Coulomb repulsion, Eqs. (199) and (203) yield

$$\frac{1}{\tau_{\text{holon}}} \propto \epsilon_F \frac{V(0)}{v_F} \left[ \frac{V(2k_F)}{v_F} \right]^2 \left[ \frac{k - k_F}{k_F} \right]^3. \tag{205}$$

This estimate should be viewed as the result of perturbation theory in V (2k<sup>F</sup> ) in the basis of well-defined holon and spinon modes with linear spectrum, which sets a limit on the holon momenta, k − k<sup>F</sup> . mV (0) (we also used vc−v<sup>s</sup> ∼ V (0) in the derivation). Curiously, the latter estimate for 1/τholon at the limit of its applicability, k − k<sup>F</sup> ∼ mV (0), matches the estimate of the relaxation rate of a spinful fermion evaluated in the basis of free fermions perturbatively, see Eq. (191).

### 3. Relaxation of excitations in a weakly interacting 1D Bose gas

Within the integrable Lieb-Liniger model, see Eq. (159), the excitations of a 1D Bose gas do not relax. The DSF exhibits a power-law singularity at the Lieb-I mode and a power-law behavior converging to zero at the Lieb-II mode, see Sec. II.E. As discussed in Sec. III.B, in the limit of weak interactions the dispersion relation for the Lieb-I mode approaches the Bogoliubov quasiparticle spectrum, while the dispersion of the Lieb-II mode corresponds to the spectrum of "dark" solitons. A weak perturbation breaking the integrability leads to finite lifetimes of the excitations (Muryshev et al., 2002). At zero temperature, the finite relaxation rate of the Bogoliubov quasiparticles smears the singularity in the response functions at the Lieb-I mode (Tan et al., 2010). At T 6= 0, the relaxation rate of a dark soliton prepared in some high-energy state also becomes finite (Gangardt and Kamenev, 2010; Mazets et al., 2008; Muryshev et al., 2002). The relaxation rates of Bogoliubov quasiparticles and dark solitons in 1D strongly depend on temperature. The theory of dark soliton relaxation was also extended to include the dissipative dynamics of the so-called depletons forming around an impurity imbedded in a 1D Bose gas or a spin-flipped particle in a spinor 1D Bose gas (Gangardt and Kamenev, 2009; Schecter et al., 2011).

The leading corrections to the Lieb-Liniger model (159) have the form of a three-body interaction term,

$$V = -\frac{\alpha}{9m} \int dx : \rho^3(x) : . \tag{206}$$

These terms of the Hamiltonian H = HLiLi + V can be derived explicitly by a projection onto the lowest subband of transverse quantization in a confining potential with cylindrical symmetry. For a model in which the interaction in 3D is described by a pseudopotential V3D(r) = 4π(a/m)δ(r), where a is the scattering length (Pitaevskii and Stringari, 2003), and with the amplitude of radial zero-point motion a<sup>r</sup> = (mωr) <sup>−</sup>1/<sup>2</sup> a one finds <sup>4</sup> (Mazets et al., 2008; Muryshev et al., 2002; Olshanii, 1998; Tan et al., 2010)

$$\gamma = 2mc/\rho = 2a/(\rho a_r^2), \ \alpha = 18\ln(4/3)(a/a_r)^2.$$
 (207)

Here, ρ is the density of 1D Bose gas. The limit of weak interaction means γ 1.

A finite three-particle scattering amplitude which leads to a damping of the Bogoliubov mode appears already in the first order in α 1. The evaluation of the corresponding relaxation rate is especially simple for quasiparticles with energies ε1(q) γmρ<sup>2</sup> , so that ε1(q) ≈

<sup>3</sup> This conclusion of Schmidt et al. (2010b) differs from the one of Pereira and Sela (2010).

<sup>4</sup> The value of α in (Mazets et al., 2008) contains a spurious factor of 4 compared to Eq. (207).

 $q^2/2m$ . In addition, we assume  $\varepsilon_1(q) \gg T$ . To the lowest order in  $\alpha$ , the differential rate of inelastic scattering in which a quasiparticle with momentum q loses energy  $\omega$  is given by

$$\sigma_q(\omega) = \frac{\alpha^2}{2\pi m^2} \int dp \delta[\omega - \varepsilon_1(q) + \varepsilon_1(q-p)] \mathcal{G}(p,\omega) . \quad (208)$$

The Fourier transform  $\mathcal{G}(p,\omega) = \int dx dt e^{i\omega t - ipx} \mathcal{G}(x,t)$  of the correlation function

$$G(x,t) = \langle : \rho^2(x,t) :: \rho^2(0,0) : \rangle$$
 (209)

should be evaluated for the Lieb-Liniger model, Eq. (159). In terms of  $\sigma_q(\omega)$ , the inverse lifetime for a given momentum q is given by

$$\frac{1}{\tau_q} = \int d\omega \sigma_q(\omega) \,. \tag{210}$$

The set of equations (208)–(210) allows one to evaluate the temperature dependence of  $1/\tau_q$ . The characteristic temperature scale for the variation of  $1/\tau_q$  is the quasi-condensation temperature  $T_s = \gamma^{1/2} \rho^2/m$ , accessible experimentally (Armijo *et al.*, 2011). By the order-of-magnitude, this is the temperature at which the chemical potential of the 1D interacting bosons crosses zero.

In the limits of low  $(T \ll T_s)$  and high  $(T \gg T_s)$  temperatures, one may use the proper asymptotes of the correlation function Eq. (209) to evaluate  $\sigma_q(\omega)$  and  $1/\tau_q$ . It turns out that in these limits the lifetime given by Eq. (210) is controlled by scattering processes with energy transfer in a broad range,  $\omega \lesssim \varepsilon_1(q)/2$  and is independent of q (Tan et~al., 2010)

$$\frac{1}{\tau_q^{(0)}} = \frac{2}{3\sqrt{3}} \frac{\alpha^2 \rho^2}{m} g_2(T) \,. \tag{211}$$

Here  $g_2 = \langle : \rho^2(0,0) : \rangle / \rho^2$  is the two-particle correlation function (normalized by  $\rho^2$ ). For weak interactions  $g_2$  decreases monotonically with T from  $g_2 = 2$  at  $T \gg T_s$  to  $g_2 = 1$  at  $T \ll T_s$  (Kheruntsyan et al., 2003). The presence of  $g_2$  in Eq. (211) is due to the fact that the two particles receiving the energy  $\omega$  in the three-particle collision must be at the same spot.

A more detailed analysis actually indicates that Eq. (211) yields the dominant contribution to the relaxation rate only outside the range of temperatures

$$\gamma^{3/8} \left(\frac{\varepsilon_1(q)}{T_s}\right)^{1/4} \lesssim \frac{T}{T_s} \lesssim \gamma^{-3/4} \left(\frac{T_s}{\varepsilon_1(q)}\right)^{1/2} .$$
 (212)

That range is broad as long as the energy of incoming quasiparticle is not too high,  $\varepsilon_1(q)/T_s \ll 8/\gamma^{3/2}$ , and includes some parts of temperature intervals where, respectively,  $T \ll T_s$ , and  $T \gg T_s$ . Within the range given by Eq. (212), relaxation is dominated by processes with

small energy transfer,  $|\omega| \lesssim \max\{T, \gamma \rho^2/m\}$ . These processes are Bose-enhanced by the high occupation factors of the final states of the quasiparticles receiving the energy  $\omega$ . Finding the full dependence of  $1/\tau_q$  on temperature within this range would require a full knowledge of the correlation function Eq. (209), which is still not available. However, matching the results obtained at low and high values of  $T/T_s$ , one may see that  $1/\tau_q$  reaches a maximum (Tan et al., 2010)

$$1/\tau_q^{\text{max}} \approx \frac{\alpha^2 \rho^2}{m} \sqrt{\frac{T_s}{\gamma^{-3/2} \varepsilon_1(q)}}$$
 (213)

at  $T_{\rm max} \approx 1.6 T_s$ . Under the assumed condition on  $\varepsilon_1(q)$ , the temperature dependence of  $1/\tau_q$  is not monotonic, the maximal rate (213) significantly exceeds the limits given in Eq. (211). The kinetic equation accounting for the small-energy transfers effective in the temperature interval (212) was considered by Mazets (2011).

The relaxation of dark solitons in the interacting 1D Bose gas is very similar to the relaxation of holes in the interacting Fermi gas which we considered in Sec. IV.A.1. Dark solitons correspond to the excitations over the ground state with the minimal energy  $\varepsilon_2(q)$  at given momentum q. The soliton velocity  $v_s(q)$  at any q is smaller than the sound velocity in the Bose gas,  $v = (\rho/m)\sqrt{\gamma}$ , see Eq. (171). Therefore, the relaxation of solitons is possible only at finite temperatures in a Raman-like process in which two phonons are created (each of the two participating phonons replaces a low-energy particle-hole pair in the case of the fermionic hole relaxation, see Figs. 14 and 17.)

The two-phonon processes lead to a typical momentum transfer  $\Delta q \sim T/v$ . The soliton's velocity is zero at  $q = \pi \rho$ , so the transferred energy in the elementary act of relaxation of a dark soliton is on the order of  $T^2/(|M^*|v^2) \sim T^2/T_s$  and much smaller than T. Here  $M^* = -4\rho/v$  is the soliton's (negative) effective mass; following Gangardt and Kamenev (2010), we consider  $T \ll T_s$ . The smallness of the energy allows one to use the Fokker-Planck equation (Landau and Lifshitz, 1980) to describe the time evolution of the momentum distribution function f(q) of a dark soliton. The problem is similar to the previously considered kinetics of a heavy particle in a linear LL (Castro Neto and Fisher, 1996) and to the diffusion of a deep hole in an interacting electron gas, see e.g., Matveev and Andreev (2012b). Using the notations of the latter work, we write the Fokker-Planck equation in the form of a continuity condition for the distribution function in the momentum space,

$$\partial_t f = -\partial_q J, \quad J = -\frac{B(q)}{2} \left[ \frac{1}{T} \frac{dE}{dq} + \partial_q \right] f$$
 (214)

with J being the corresponding current  $^{5}$ .

The applicability of Eq. (214) is confined to the vicinity of  $q=\pi\rho$  in order to satisfy the requirement of the smallness of the energy transfer. Thus, one may use the expansion  $\varepsilon_2(q)=\varepsilon_2(0)+(q-\pi\rho)^2/(2M^*)$  for the soliton's energy, and replace B(q) by a constant,  $B=B(q=\pi\rho)$ . After that, the meaning of Eq. (214) becomes quite clear: it describes the motion of a "particle" (dark soliton) subject to a Langevin random force (yielding the second term in the brackets) and a viscous force

$$F = -\chi v$$
,  $\chi = B/2T$ ,  $v = \partial_q \varepsilon_2(q)$ . (215)

The viscous force leads to a particle acceleration as  $M^* < 0$  for the dark soliton. Once the soliton's velocity  $v_s(q)$  becomes of the order of v, Eq. (214) becomes invalid. However, if the initial velocity was on the order of the thermal one,  $v_s(q) \sim \sqrt{|M^*|T}$ , then the Fokker-Planck equation describes the longest part of relaxation process, which takes a time  $\tau \sim |M^*|/\chi$ .

The viscosity coefficient was evaluated by Gangardt and Kamenev (2010),<sup>6</sup>

$$\chi(T) = \frac{128\pi^3}{1215} \frac{\alpha^2 \rho^2 m^2}{\gamma} \left(\frac{T}{\sqrt{\gamma} T_s}\right)^2, T \ll \sqrt{\gamma} T_s.$$
(216)

To obtain this result one needs to include not only linear but also quadratic terms in  $\partial_x \varphi$  and  $\partial_x \theta$  in the interaction Hamiltonian of the quantum impurity with the LL describing the low-energy excitations. Such terms are necessary because they account for the three-particle collisions which are needed to capture two-phonon processes and the resulting soliton relaxation. At  $q=\pi\rho$  the terms allowed by symmetries are

$$H_3 = \int dx \left[ V_{\theta\theta} (\partial_x \theta)^2 + V_{\varphi\varphi} (\partial_x \varphi)^2 \right] d^{\dagger}(x) d(x). \quad (217)$$

An extension of the phenomenological approach of Sec. II.C leads to the coupling strengths

$$V_{\theta\theta} = \frac{1}{2} \left( \frac{1}{m} + \frac{\partial^2 \varepsilon_2}{\partial a^2} \right), \tag{218}$$

$$V_{\varphi\varphi} = \frac{1}{2\pi^2} \left( \frac{\partial^2 \varepsilon_2}{\partial \rho^2} + \frac{\partial^2 \mu}{\partial \rho^2} \right). \tag{219}$$

The evaluation then proceeds by removing from the Hamiltonian the terms linear in  $\partial_x \varphi$  and  $\partial_x \theta$  using the unitary transformation (71), and then treating the remainder within perturbation theory. As was shown explicitly by Gangardt and Kamenev (2010), the coefficients of the interaction Hamiltonian yield a vanishing

relaxation rate for the integrable Lieb-Liniger model. In the weakly interacting regime, the lowest-order correction appears in the order  $\alpha^2$  due to corrections to  $\varepsilon_2(q)$  coming from three-particle interactions (206). Later on, the outlined approach to the relaxation of dark solitons was generalized to the case of a depleton, the dressed impurity state in a quantum liquid (Schecter et al., 2011).

### B. Conductivity and Drude weight for interacting particles

So far in this section we concentrated on the relaxation of excitations. A related question which has attracted a lot of attention recently is the effect of such relaxation on transport, and specifically the relation between transport properties and integrability (Grossjohann and Brenig, 2010; Heidrich-Meisner et al., 2003; Herbrych et al., 2011; Jung et al., 2006; Jung and Rosch, 2007; Karrasch et al., 2011; Prosen, 2011; Rosch and Andrei, 2000; Sirker et al., 2009, 2011; Žnidarič, 2011; Wu and Berciu, 2011).

The current response j(x,t) to a force  $f(x,t)=f_{q,\omega}\exp(i\omega t-qx)e^{+0t}$  applied to a linear LL is easily evaluated by solving the corresponding classical equation for the density waves in the liquid. It yields for the Fourier components of the current

$$j(q,\omega) = -i\frac{Kv}{\pi} \frac{f_{q,\omega}}{\omega - qv - i0}.$$
 (220)

In a Galilean-invariant system, the factor  $Kv/\pi$  equals  $\rho/m$ , where the average particle density  $\rho$  and the mass m are independent of interactions. The linear response of the current to a force field applied to a spatially-homogeneous system is characterized by the conductivity,  $j(q,\omega) = \sigma(q,\omega)f_{q,\omega}$ , which is a complex function,  $\sigma(q,\omega) = \sigma'(q,\omega) + i\sigma''(q,\omega)$ . Its real component,  $\sigma'(q,\omega)$ , is the dissipative part of the response. The response of a Galilean-invariant system at q=0 is purely inertial and independent of interactions, since it is nothing but a center-of-mass motion caused by an applied force uniform in space. According to Eq. (220), the corresponding dissipative part of conductivity,  $\sigma'(\omega) = \sigma'(q,\omega)|_{q=0}$ , is

$$\sigma'(\omega) = 2\pi D\delta(\omega). \tag{221}$$

The magnitude of the "Drude peak" D in the conductivity  $\sigma'(\omega)$  is given by  $D=\rho/(2m)$ . In the presence of a periodic lattice potential,  $\sigma(q,\omega)$  is still well-defined for wave vectors much smaller than the size of the Brillouin zone (Sirker et al., 2011). By continuity equations, the conductivity is related to the susceptibility; the dissipative part of the latter is related to the DSF by the fluctuation-dissipation theorem (Doniach and Sondheimer, 1998). Therefore, for small q

$$S(q,\omega) = \frac{2q^2}{\omega(1 - e^{-\beta\omega})} \sigma'(q,\omega). \tag{222}$$

<sup>&</sup>lt;sup>5</sup> The function B(q) at arbitrary interaction strength was recently evaluated (Matveev and Andreev, 2012a).

<sup>&</sup>lt;sup>6</sup> The numerical coefficient in Eq. (216) corrects an error in the original publication (Kamenev, 2011).

As we have seen in the previous parts of the review, the delta peak in  $S(q,\omega)$  at finite wave vectors q becomes broadened in a nonlinear LL, and according to Eq. (222) leads to a finite width of the peak in the dissipative conductivity. At T=0, the peak at  $\omega=vq$  has a width which scales as a higher power of wave vector,  $\propto q^2$  in the absence of particle-hole symmetry or  $\propto |q|^3$  in the presence of the symmetry (Khodas et~al., 2007a; Pereira et~al., 2006). In either case, taking the limit  $q\to 0$  one recovers the Drude peak in the conductivity in the limit  $q\to 0$ .

At  $T \neq 0$ , the universal nonlinear LL theory leading to Eq. (147) is insufficient for understanding the fate of the Drude peak. Indeed, the applicability of Eq. (147) in the limit  $q \to 0$  requires that T scales to zero not slower than q; one is not allowed to take the limit  $q \to 0$  at fixed T. However, in a Galilean invariant system, the existence of a Drude peak is protected even at finite temperatures, since the constant uniform external field causes the same center-of-mass motion irrespective of the temperature.

The real part of the conductivity (at q = 0) can be written as (Sirker *et al.*, 2011)

$$\sigma'(\omega) = 2\pi D\delta(\omega) + \sigma_{\text{reg}}(\omega). \tag{223}$$

Invoking the notion of a finite relaxation time  $\tau$ , one may expect  $\sigma'(\omega) \propto (1/\tau)/[\omega^2 + (1/\tau)^2]$ . In order to reproduce the correct zero-temperature limit, we have to set  $1/\tau(T) = 0$  at T = 0. In a generic system, one expects  $1/\tau(T)$  finite at  $T \neq 0$  which means zero Drude weight, D(T) = 0 at any finite temperature. In the special case of integrable models, one may conjecture  $1/\tau(T) = 0$  and consequently  $D(T) \neq 0$  even at finite temperature.

One way of checking this conjecture relies on the rigorous Mazur inequality (Mazur, 1969; Zotos et al., 1997)

$$D \ge \frac{1}{2LT} \sum_{k} \frac{\langle \mathcal{I}Q_k \rangle^2}{\langle Q_k^2 \rangle^2} \,. \tag{224}$$

Here L is the length of the system,  $\mathcal{I}$  is the spatial integral of the current density operator, and the operators  $Q_k$  form a set of commuting conserved quantities, orthogonal to each other  $(\langle Q_l Q_k \rangle \propto \delta_{kl})$ . Moreover, if the set includes all conserved quantities  $Q_k$ , then equality is reached in Eq. (224) (Suzuki, 1971). Finding at least one conserved quantity  $Q_n$  with a nonzero overlap with  $\mathcal{I}$  allows one to prove  $D(T) \neq 0$  at finite temperature. This is the case, for example, for charge transport in the Hubbard model away from half-filling and spin transport in the S = 1/2 XXZ model at finite magnetic field, where a proper local conserved quantity can be found. At zero field, all local conserved quantities for the XXZ model are even under the transformation  $S_j^z \to -S_j^z, \, S_j^\pm \to S_j^\pm,$  while  $\mathcal I$  is odd, and the corresponding overlaps equal zero. It seems that a conserved quantity which has finite overlap with  $\mathcal{I}$  was recently constructed (Prosen, 2011), supporting the claim of finite D(T) for the XXZ model at

zero field. Recent numerical results seem to support this claim (Karrasch *et al.*, 2011).

Alternatives to the investigation methods based on Mazur's inequality are reviewed in a recent excellent paper by Sirker *et al.* (2011).

#### C. Conductance of interacting fermions in 1D

The conductance of ballistic quantum wires adiabatically connected to leads is quantized in units of  $e^2/(\pi\hbar)$ at low temperatures. This experimental observation (van Wees et al., 1988; Wharam et al., 1988) was first understood in terms of adiabatic transport of free fermions (Glazman et al., 1988). It was realized later that interactions, taken into account within the framework of the linear LL theory, do not affect the quantization of adiabatic transport (Maslov and Stone, 1995; Ponomarenko, 1995; Safi and Schulz, 1995). Finite-temperature corrections to the quantized conductance, whether in the picture of free or interacting fermions, are associated with the electron states near the bottom of the conduction band. In the case of free fermions the correction is easily evaluated and shows no dependence on the wire length L, but an activated temperature dependence  $\delta G \propto e^{-\epsilon_F/T}$ , see Eq. (226) below. Interactions do not alter the activated nature of the temperature dependence for relatively short wires (Lunde et al., 2007). In sufficiently long wires, however, equilibration facilitated by the scattering of holes near the bottom of the band, see Fig. 17, ultimately leads to a much bigger correction,  $\delta G \propto T^2$ (Rech et al., 2009). We will mostly concentrate on the transport of spinless fermions below; one may think of fully spin-polarized electrons, the corresponding conductance quantum is  $e^2/(2\pi\hbar)$ .

In the absence of interactions, the distribution functions of fermions in the wire, see Fig. 18, keep the memory of the distribution in the lead they originated from,

$$f^{(0)}(k) = \frac{\theta(k)}{\exp(\xi^L(k)/T) + 1} + \frac{\theta(-k)}{\exp(\xi^R(k)/T) + 1}.$$
(225)

Here  $\xi^{L,R}(k)=k^2/(2m)-\epsilon_F^{L,R}$  are the energies of electrons coming from the left (L) or right (R) leads, respectively. The difference between the chemical potentials is determined by the bias V applied to the wire,  $\epsilon_F^L=\epsilon_F^R+eV$ . Evaluating the current  $I=e\int (dk/2\pi\hbar)(k/m)f^{(0)}(k)$  at small bias  $(V\to 0)$ , one easily finds

$$G_0 = \frac{e^2}{2\pi\hbar} \frac{1}{e^{-\epsilon_F/T} + 1},\tag{226}$$

which is equal to the quantum  $e^2/(2\pi\hbar)$ , up to a correction proportional to  $e^{-\epsilon_F/T}$ , which is exponentially small at low temperatures ( $\epsilon_F^L = \epsilon_F^R = \epsilon_F$  at V = 0).

The presence of a current  $I \neq 0$  means that there is some finite average velocity of electrons in the wire. An

![](_page_52_Picture_1.jpeg)

FIG. 18 Schematic picture of the quantum wire of length L which is formed by confining a 2D electron gas with gates (dark regions). Electrons in the left and right leads are described by Fermi distribution functions characterized by a temperature T and chemical potentials  $\epsilon_F^L$  and  $\epsilon_F^R$ , respectively. As particles propagate from the left lead to the right one, some get reflected due to the momentum-conserving electron-electron interaction, creating  $dN_R/dt \neq 0$ , see Eq. (233). Adapted from Micklitz et al. (2010).

equilibrium distribution function in the rest frame, at given drift velocity, chemical potential, and temperature  $(u, \tilde{T}, \text{ and } \tilde{\mu}, \text{ respectively})$  would be

$$f(k) = \frac{1}{\exp[k^2/(2m) - uk - \tilde{\mu}]/\tilde{T} + 1}$$
 (227)

At  $T = \tilde{T} = 0$ , the distribution function (225) may be brought to the form of Eq. (227). Therefore, we do not expect equilibration (caused by electron-electron interaction) to bring any corrections to the ballistic conductance at T=0. Besides, each of the two parts of Eq. (225) represents a distribution describing equilibrium separately within the left- and right-movers with  $N_L \neq N_R$ . At T=0, the relaxation rate  $1/\tau_N=0$ , and the distribution (225) is stable. However, at finite temperature the processes depicted in Fig. 17 cause a redistribution between  $N_R$  and  $N_L$ . To the lowest order in  $1/\tau_N$ , the correction  $\delta G \sim L/(v_F \tau_N)$  to the ballistic conductance (226) increases linearly with the wire length L (Lunde et al., 2007; Micklitz et al., 2010). This defines a new characteristic equilibration length,  $l_{\rm eq} \sim v_F \tau_N \propto e^{\epsilon_F/T}$ . The resulting resistance reduces G by an L-independent amount,  $\delta G \sim -(e^2/\hbar)(T/\epsilon_F)^2$  which can be found essentially from particle number and energy conservation laws (Rech et al., 2009). The initial consideration of weak interactions (Rech et al., 2009) was generalized later to the case of strong (Matveev et al., 2010) and arbitrary (Matveev and Andreev, 2012b) interactions. We address next that latest development.

The Hamiltonian (41) in a finite-size system written in terms of individual bosonic modes reads (Haldane, 1981b)

$$H = \sum_{q} v|q|b_q^{\dagger} b_q + \frac{\pi}{2L} \left[ v_N N^2 + v_J J^2 \right], \qquad (228)$$

while its momentum is

$$P = k_F J + \sum_q q b_q^{\dagger} b_q, \qquad (229)$$

where  $v_J = v_F$  and  $v_N = v_F/K^2$  as a consequence of Galilean invariance. An eigenstate of the system is described by boson occupation numbers, and the total numbers of the left- and right-movers with respect to the ground state,  $N_{R,L} = (N \pm J)/2$ . It is worth noting that an excitation of the boson modes does not contribute to the current: a creation of bosons corresponds to exciting particle-hole pairs within the branches of leftor right-movers. So, the electric current I is related by  $I = ev_J(J/L)$  to the difference  $N_R - N_L$  (Haldane, 1981b). On the other hand, conservation of energy and momentum determine the form of the equilibrium distribution,  $e^{-(H-uP)/T}/Z$  with some parameters u and T (here Z is the proper partition function). Using here Eqs. (228) and (229), we find the average value of J to be  $\pi k_F Lu/v_J$ . Using that together with the relation between I and J, we see that u is nothing but the drift velocity:

$$u = \frac{I}{e} \frac{1}{\pi k_F} \,. \tag{230}$$

In equilibrium, the very same velocity "shifts" the boson distribution function:

$$n(q) = \langle b_q^{\dagger} b_q \rangle = \left[ e^{(v|q| - uq)/T} - 1 \right]^{-1}. \tag{231}$$

That distribution does not carry any charge, but does create energy current,

$$j_E = (\pi/3)(T^2/v)u$$
. (232)

As we already discussed, at zero temperature the distribution  $e^{-(H-uP)/T}/Z$  with a finite drift velocity can be viewed as two counter-propagating fluxes of particles with different chemical potentials, resulting in the quantized conductance  $G_0 = e^2/(2\pi\hbar)$  (Maslov and Stone, 1995; Ponomarenko, 1995; Safi and Schulz, 1995). At finite temperatures, the accommodation of the distributions in the leads to the drifting one in the wire may cause backscattering, see Fig. 18, which leads to relation

$$I = G_0 V + e \frac{dN_R}{dt}. (233)$$

The crucial observation is that  $dN_R/dt$  is related to the energy redistribution between right- and left-movers (Matveev and Andreev, 2011; Rech et al., 2009). Indeed, backscattering of a right-mover corresponds to a change  $\Delta N_R = -1$ , which in the limit of  $u \to 0$  (linear response regime) does not affect the total energy, see Eq. (228). At the same time, by momentum conservation, bosons must acquire the additional momentum of  $2k_F$ , see Eq. (229). This is only possible if momenta and energies given by ∆PR,L = k<sup>F</sup> and ∆ER,L = ±vk<sup>F</sup> are transferred to the left- and right-moving bosons. Therefore,

$$\frac{dE_R}{dt} = -vk_F \frac{dN_R}{dt} \,. \tag{234}$$

By energy conservation, one has

$$j_E = \frac{dE_R}{dt}. (235)$$

Equations (235), (234), and (232) relate dNR/dt to the drift velocity u. Using then relations (230) and (233), one finds the corrected conductance, (Matveev and Andreev, 2011)

$$G = G_0 \left( 1 - \frac{\pi^2}{3} \frac{T^2}{v^2 k_F^2} \right) . \tag{236}$$

A full equilibration of the bosons to the distribution (231) requires energy equilibration and the adjustment of the velocity to the correct drift value (230). As we discussed for the example of weak interactions, see Eqs. (188)–(192), the energy equilibration rate scales as some power of temperature, while the adjustment of the velocity requires a variation of NR−NL. The corresponding rate has an activated temperature dependence and happens on a much slower scale, see Eq. (193) and the discussion around it. Therefore, there is an exponentially wide interval of wire lengths L for which full equilibration of the energy does occur, but u(L) does not reach the value (230). Considering u(L) as an adjustable parameter replacing the distribution (231), and using the momentum conservation Eq. (229), one finds (Matveev and Andreev, 2011)

$$\frac{1}{L}\frac{dN_R}{dt} = \frac{\pi}{3}\frac{T^2}{v^2k_F}\frac{u(L) - u}{l_{\text{eq}}}$$
(237)

which generalizes Eq. (236) to finite values of L/leq,

$$G = G_0 \left( 1 - \frac{\pi^2}{3} \frac{T^2}{v^2 k_F^2} \frac{L}{L + l_{\text{eq}}} \right). \tag{238}$$

The evaluation of the equilibration length leq = 2vτ<sup>N</sup> is beyond the linear LL theory, and should account for the processes involving holes at the bottom of the band, see Fig. 17. Like in the case of dark solitons considered in Sec. IV.A.3, this problem can be reduced to the one of the kinetics of a mobile impurity and entails a solution of the Fokker-Planck equation (214). It yields (Matveev and Andreev, 2012b)

$$\frac{1}{l_{\rm eq}} = \frac{(3/2)k_F^2 B}{\pi^2 v \sqrt{2\pi M^* T}} \left(\frac{v}{T}\right)^3 e^{\varepsilon_{\rm th}(0)/T}, \qquad (239)$$

where the parameters εth(0) < 0 and M<sup>∗</sup> > 0 are determined by the energy spectrum of the impurity, εth(k) ≈ εth(0) + k <sup>2</sup>/(2M<sup>∗</sup> ), and depend on the equilibrium electron density ρ in the wire. The extension of the phenomenological treatment of Sec. II.C aimed at including the Raman scattering processes, see Eqs. (218), allows to express the coefficient B in terms of the functions ∂εth(0)/∂ρ and ∂v/∂ρ:

$$B = \frac{4\pi^{3}\rho^{2}T^{5}}{15m^{2}v^{8}} \left( -\frac{d^{2}\varepsilon_{\text{th}}(0)}{d\rho^{2}} + \frac{2}{v}\frac{dv}{d\rho}\frac{d\varepsilon_{\text{th}}(0)}{d\rho} + \frac{(d\varepsilon_{\text{th}}(0)/d\rho)^{2}}{M^{*}v^{2}} \right)^{2}.$$
 (240)

The approach leading to Eq. (238) was also applied to spin-1/2 fermions (Matveev and Andreev, 2011). In the most interesting case of strong interactions (v<sup>s</sup> vc) the result is

$$G = \frac{e^2}{\pi \hbar} \left( 1 - \frac{\pi^2}{6} \frac{T^2}{v_s^2 k_F^2} \frac{L}{L + l_{\text{eq}}^{(s)}} \right) ,$$

but the corresponding equilibration length l (s) eq for spinons has not been evaluated yet.

#### V. CONCLUSIONS

The linear Luttinger liquid (LL) theory has been in use for decades by now, and provides an effective tool to describe the low-energy properties of 1D quantum liquids in terms of quantized linear sound modes. Despite its spectacular successes, the linear LL theory has limitations constraining its applicability even in the low-energy physics of quantum 1D systems. Replacing the generic spectrum of particles with a linear one does affect qualitatively the momentum-resolved dynamic responses and introduces an artificial particle-hole symmetry. Furthermore, being a free-field theory, the linear LL description is devoid of any intrinsic mechanisms of relaxation and equilibration.

This review exhibits ways of studying 1D quantum liquids outside these limitations and beyond low energies. For this purpose, the representation of the linear LL theory in terms of the fermionic quasiparticles introduced by Mattis and Lieb (1965) turns out to be more beneficial than the standard bosonization treatment. The quasiparticles share many features with their counterparts in the Fermi liquid theory. If the constituent particles of the liquid have a nonlinear dispersion relation, so do the fermionic quasiparticles. Similarly to the Fermi liquid theory, the interactions between the quasiparticles are weak. That, in principle, should allow one to build a full kinetic theory valid at low energies. The difference from the Fermi liquid theory comes in the relation between the measurable degrees of freedom and the quasiparticles: the corresponding transformation is rather nonlinear. While a nonperturbative kinetic theory based on the fermionic quasiparticle representation has not been developed yet, some elementary relaxation processes in a nonlinear LL are understood.

The realization of links between the physics of a nonlinear LL and the Fermi liquid theory makes available an arsenal of methods existing in the latter. One of them, the theory of the Fermi edge singularity, facilitated the development of new methods for the evaluation of the singularities in the dynamic response functions of 1D quantum liquids. The new paradigm which emerged is the description of the many-body dynamics in terms of effective models of quantum impurities moving in linear LLs.

We reviewed the existing tools for the investigation of nonlinear LLs and some results obtained with these tools. As we mentioned, building a kinetic theory of 1D liquids remains an open question. Other questions closely related to the review include the kinetic theory of weaklynonintegrable systems relevant for cold atomic gases, and the dynamics of edge states (chiral and helical) relevant for electrons in solids. The field remains wide open beyond these few problems, with a variety of practically and conceptually important questions to be answered.

#### ACKNOWLEDGMENTS

The authors wish to thank A. V. Andreev, V. V. Cheianov, A. Kamenev, T. Karzig, A. Levchenko, K. A. Matveev, and R. G. Pereira for discussions and comments which were helpful in writing this review. We acknowledge the support of the NSF under Grants No. 0906498 and 1066293, and the hospitality of the Aspen Center for Physics and of the Nanosciences Foundation (Grenoble, France). AI also acknowledges support from the Texas NHARP Grant No. 01889 and the A. P. Sloan Foundation. TLS acknowledges support from the Swiss NSF.

# REFERENCES

- Abanin, D. A., and L. S. Levitov (2004), Phys. Rev. Lett. 93, 126802.
- Abanin, D. A., and L. S. Levitov (2005), Phys. Rev. Lett. 94, 186803.
- Abanov, A. G., E. Bettelheim, and P. Wiegmann (2009), J. Phys. A 42, 135201.
- Abanov, A. G., and P. B. Wiegmann (2005), Phys. Rev. Lett. 95 (7), 076402.
- Abrikosov, A. A., L. P. Gorkov, and I. E. Dzyaloshinski (1963), Methods of Quantum Field Theory in Statistical Physics (Dover, New York).
- Affleck, I. (1986), Phys. Rev. Lett. 56, 746.
- Affleck, I. (2009), in Exact Methods in Low-Dimensional Statistical Physics and Quantum Computing, edited by J. Jacobsen (Oxford University Press).
- Affleck, I., D. Gepner, H. J. Schulz, and T. Ziman (1989), J. Phys. A 22, 511.

- Affleck, I., and A. W. W. Ludwig (1994), J. Phys. A 27, 5375.
- Akhanjee, S., and Y. Tserkovnyak (2007), Phys. Rev. B 76, 140408.
- Aleiner, I. L., B. L. Altshuler, and G. V. Shlyapnikov (2010), Nat Phys 6 (11), 900.
- Altimiras, C., H. Le Sueur, U. Gennser, A. Cavanna, D. Mailly, and F. Pierre (2009), Nat. Phys. 6, 34.
- Altimiras, C., H. le Sueur, U. Gennser, A. Cavanna, D. Mailly, and F. Pierre (2010), Phys. Rev. Lett. 105, 226804.
- Ament, L. J. P., M. van Veenendaal, T. P. Devereaux, J. P. Hill, and J. van den Brink (2011), Rev. Mod. Phys. 83, 705.
- van Amerongen, A. H., J. J. P. van Es, P. Wicke, K. V. Kheruntsyan, and N. J. van Druten (2008), Phys. Rev. Lett. 100, 090402.
- Anderson, P. W. (1958), Physical Review 109 (5), 1492.
- Anderson, P. W. (1967), Phys. Rev. Lett. 18, 1049.
- Andreev, A. F. (1980), Sov. Phys. JETP 51, 1038.
- Arikawa, M., and Y. Saiga (2006), J. Phys. A 39, 10603.
- Arikawa, M., Y. Saiga, and Y. Kuramoto (2001), Phys. Rev. Lett. 86, 3096.
- Arikawa, M., T. Yamamoto, Y. Saiga, and Y. Kuramoto (1999), J. Phys. Soc. Jpn. 68, 3782.
- Arikawa, M., T. Yamamoto, Y. Saiga, and Y. Kuramoto (2004), J. Phys. Soc. Jpn. 73, 808.
- Aristov, D. N. (2007), Phys. Rev. B 76, 085327.
- Armijo, J., T. Jacqmin, K. Kheruntsyan, and I. Bouchoule (2011), Phys. Rev. A 83, 021605.
- Armijo, J., T. Jacqmin, K. V. Kheruntsyan, and I. Bouchoule (2010), Phys. Rev. Lett. 105 (23), 230402.
- Astrakharchik, G. E., D. M. Gangardt, Y. E. Lozovik, and I. A. Sorokin (2006), Phys. Rev. E 74, 021105.
- Auslaender, O. M., H. Steinberg, A. Yacoby, Y. Tserkovnyak, B. I. Halperin, K. W. Baldwin, L. N. Pfeiffer, and K. W. West (2005), Science 308, 88.
- Auslaender, O. M., A. Yacoby, R. de Picciotto, K. W. Baldwin, L. N. Pfeiffer, and K. W. West (2002), Science 295, 825.
- Balents, L. (2000), Phys. Rev. B 61, 4429.
- Barak, G., H. Steinberg, L. N. Pfeiffer, K. W. West, L. Glazman, F. von Oppen, and A. Yacoby (2010), Nat. Phys. 6, 489.
- Barthel, T., U. Schollw¨ock, and S. R. White (2009), Phys. Rev. B 79, 245101.
- Basko, D., I. Aleiner, and B. Altshuler (2006), Ann. Phys. (N.Y.) 321 (5), 1126.
- Batchelor, M. T., M. Bortz, X. W. Guan, and N. Oelkers (2005), Phys. Rev. A 72, 061603.
- Baym, G., and C. Ebner (1967), Phys. Rev. 164, 235.
- Beliaev, S. T. (1958), Sov. Phys. JETP 7, 289.
- Bettelheim, E., A. G. Abanov, and P. Wiegmann (2006a), Phys. Rev. Lett. 97, 246401.
- Bettelheim, E., A. G. Abanov, and P. Wiegmann (2006b), Phys. Rev. Lett. 97, 246402.
- Bettelheim, E., A. G. Abanov, and P. Wiegmann (2007), J. Phys. A 40, 193.
- Bettelheim, E., A. G. Abanov, and P. B. Wiegmann (2008), J. Phys. A 41, 392003.
- Blagoev, K. B., and K. S. Bedell (1997), Phys. Rev. Lett. 79,
- 1106. Bleistein, N., and R. Handelsman (1986), Asymptotic Expansions of Integrals (Dover Publications, Mineola, N.Y.).

- Bl¨ote, H. W. J., J. L. Cardy, and M. P. Nightingale (1986), Phys. Rev. Lett. 56, 742.
- Blumenstein, C., J. Sch¨afer, S. Mietke, S. Meyer, A. Dollinger, M. Lochner, X. Y. Cui, L. Patthey, R. Matzdorf, and R. Claessen (2011), Nat. Phys. 7, 776.
- Bogoliubov, N. M., A. G. Izergin, and N. Y. Reshetikhin (1987), J. Phys. A 20, 5361.
- Bougourzi, A. H. (1996), Mod. Phys. Lett. B 10, 1237.
- Bougourzi, A. H., M. Karbach, and G. M¨uller (1998), Phys. Rev. B 57, 11429.
- Brazovskii, S., S. Matveenko, and P. Nozi´eres (1993), JETP Lett. 58, 796.
- Brazovskii, S., S. Matveenko, and P. Nozi`eres (1994), J. Phys. I 4, 571.
- Calabrese, P., and J.-S. Caux (2007), Phys. Rev. Lett. 98, 150403.
- Calogero, F. (1969), J. Math. Phys. 10, 2197.
- Calogero, F. (1971), J. Math. Phys. 12, 419.
- Carmelo, J. M. P., D. Bozi, and K. Penc (2008), J. Phys.: Condens. Matter 20, 415103.
- Carmelo, J. M. P., J. M. E. Guerra, J. M. B. Lopes dos Santos, and A. H. Castro Neto (1999), Phys. Rev. Lett. 83, 3892.
- Carmelo, J. M. P., K. Penc, and D. Bozi (2005), Nucl. Phys. B 725, 421.
- Carmelo, J. M. P., K. Penc, L. M. Martelo, P. D. Sacramento, J. M. B. Lopes dos Santos, R. Claessen, M. Sing, and U. Schwingenschl¨ogl (2004), Europhysics Letters 67, 233.
- Carmelo, J. M. P., K. Penc, P. D. Sacramento, M. Sing, and R. Claessen (2006), J. Phys. Condens. Matter 18, 5191.
- Castella, H., and X. Zotos (1993), Phys. Rev. B 47, 16186.
- Castro Neto, A. H., and A. O. Caldeira (1994), Phys. Rev. B 50, 4863.
- Castro Neto, A. H., and M. P. A. Fisher (1996), Phys. Rev. B 53, 9713.
- Catani, J., G. Lamporesi, D. Naik, M. Gring, M. Inguscio, F. Minardi, A. Kantian, and T. Giamarchi (2012), Phys. Rev. A 85, 023623, arXiv:1106.0828 [cond-mat.quant-gas].
- Caux, J.-S., and P. Calabrese (2006), Phys. Rev. A 74, 031605.
- Caux, J.-S., P. Calabrese, and N. A. Slavnov (2007), J. Stat. Mech.: Theory Exp. 2007, P01008.
- Caux, J.-S., R. Hagemans, and J. M. Maillet (2005), Journal of Statistical Mechanics: Theory and Experiment 2005, P09003.
- Caux, J.-S., and J. M. Maillet (2005), Phys. Rev. Lett. 95, 077201.
- Cazalilla, M. A. (2004), J. Phys. B 37, S1.
- Cazalilla, M. A., R. Citro, T. Giamarchi, E. Orignac, and M. Rigol (2011), Rev. Mod. Phys. 83, 1405.
- Cazalilla, M. A., A. F. Ho, and M. Ueda (2009), New J. Phys. 11 (10), 103033.
- Chang, A. M. (2003), Rev. Mod. Phys. 75, 1449.
- Cheianov, V. V., and M. Pustilnik (2008), Phys. Rev. Lett. 100, 126403.
- Cheianov, V. V., H. Smith, and M. B. Zvonarev (2006a), Phys. Rev. A 73, 051604.
- Cheianov, V. V., H. Smith, and M. B. Zvonarev (2006b), J. Stat. Mech.: Theory Exp. 2006, P08015.
- Cheianov, V. V., and M. B. Zvonarev (2004a), Phys. Rev. Lett. 92, 176401.
- Cheianov, V. V., and M. B. Zvonarev (2004b), J. Phys. A 37, 2261.
- Chen, Y.-F., T. Dirks, G. Al-Zoubi, N. O. Birge, and N. Mason (2009), Phys. Rev. Lett. 102, 036804.

- Cheon, T., and T. Shigehara (1998), Phys. Lett. A 243, 111. Cheon, T., and T. Shigehara (1999), Phys. Rev. Lett. 82, 2536.
- Cherny, A. Y., and J. Brand (2009), Phys. Rev. A 79, 043607. Claessen, R., M. Sing, U. Schwingenschl¨ogl, P. Blaha, M. Dressel, and C. S. Jacobsen (2002), Phys. Rev. Lett. 88, 096402.
- Cl´ement, D., N. Fabbri, L. Fallani, C. Fort, and M. Inguscio (2009), Phys. Rev. Lett. 102, 155301.
- Dao, T.-L., A. Georges, J. Dalibard, C. Salomon, and I. Carusotto (2007), Phys. Rev. Lett. 98, 240402.
- De Chiara, G., M. Rizzi, D. Rossini, and S. Montangero (2008), J. Comput. Theor. Nanosci. 5, 1277.
- Debray, P., V. Zverev, O. Raichev, R. Klesse, P. Vasilopoulos, and R. S. Newrock (2001), J. Phys. Condens. Matter 13, 3389.
- Debray, P., V. N. Zverev, V. Gurevich, R. Klesse, and R. S. Newrock (2002), Semicond. Sci. Technol. 17, R21.
- Del Maestro, A., and I. Affleck (2010), Phys. Rev. B 82, 060515.
- Del Maestro, A., M. Boninsegni, and I. Affleck (2011), Phys. Rev. Lett. 106, 105303.
- DeSalvo, B. J., M. Yan, P. G. Mickelson, Y. N. Martinez de Escobar, and T. C. Killian (2010), Phys. Rev. Lett. 105, 030402.
- Deshpande, V. V., M. Bockrath, L. I. Glazman, and A. Yacoby (2010), Nature 464, 209.
- Deuar, P., A. G. Sykes, D. M. Gangardt, M. J. Davis, P. D. Drummond, and K. V. Kheruntsyan (2009), Phys. Rev. A 79, 043619.
- Doniach, S., and E. H. Sondheimer (1998), Green's functions for solid state physicists (Imperial College Press, London).
- Donner, T., S. Ritter, T. Bourdel, A. Ottl, M. K¨ohl, and ¨ T. Esslinger (2007), Science 315, 1556.
- Dzyaloshinskii, I. E., and A. I. Larkin (1974), Sov. Phys. JETP 38, 202.
- Efetov, K. B., and A. I. Larkin (1975), Sov. Phys. JETP 42, 390.
- Eisenberg, E., and E. H. Lieb (2002), Phys. Rev. Lett. 89, 220403.
- Ernst, P. T., S. G¨otze, J. S. Krauser, K. Pyka, D. L¨uhmann, D. Pfannkuche, and K. Sengstock (2010), Nat. Phys. 6, 56.
- de Escobar, Y. N. M., P. G. Mickelson, M. Yan, B. J. DeSalvo, S. B. Nagel, and T. C. Killian (2009), Phys. Rev. Lett. 103, 200402.
- Essler, F. H. L. (2010), Phys. Rev. B 81, 205120.
- Essler, F. H. L., H. Frahm, F. G¨ohmann, A. Kl¨umper, and V. Korepin (2005), The One-Dimensional Hubbard Model (Cambridge University Press, Cambridge).
- Fabbri, N., D. Cl´ement, L. Fallani, C. Fort, M. Modugno, K. M. R. van der Stam, and M. Inguscio (2009), Phys. Rev. A 79, 043623.
- Fazio, R., and H. van der Zant (2001), Physics Reports 355, 235.
- Feiguin, A. E., and D. A. Huse (2009), Phys. Rev. B 79, 100507.
- Fiete, G. A. (2006), Phys. Rev. Lett. 97, 256403.
- Fiete, G. A. (2007), Rev. Mod. Phys. 79, 801.
- Fiete, G. A. (2009), J. Phys. Condens. Matter 21 (19), 193201.
- Fiete, G. A., and L. Balents (2004), Phys. Rev. Lett. 93, 226401.

- Frahm, H., and V. E. Korepin (1990), Phys. Rev. B 42, 10553.
- Frahm, H., and G. Palacios (2005), Phys. Rev. A 72, 061604. Friedrich, A., A. K. Kolezhuk, I. P. McCulloch, and U. Schollw¨ock (2007), Phys. Rev. B 75, 094414.
- Fuchs, J. N., D. M. Gangardt, T. Keilmann, and G. V. Shlyapnikov (2005), Phys. Rev. Lett. 95, 150402.
- Fukuhara, T., Y. Takasu, M. Kumakura, and Y. Takahashi (2007), Phys. Rev. Lett. 98, 030401.
- Furusaki, A., and S.-C. Zhang (1999), Phys. Rev. B 60, 1175. Gaebler, J. P., J. T. Stewart, T. E. Drake, D. S. Jin, A. Perali, P. Pieri, and G. C. Strinati (2010), Nat. Phys. 6, 569.
- Gangardt, D. M. (2004), J. Phys. A 37, 9335.
- Gangardt, D. M., and A. Kamenev (2001), Nucl. Phys. B 610, 578.
- Gangardt, D. M., and A. Kamenev (2009), Phys. Rev. Lett. 102 (7), 070402.
- Gangardt, D. M., and A. Kamenev (2010), Phys. Rev. Lett. 104, 190402.
- Gangardt, D. M., and G. V. Shlyapnikov (2003a), New J. Phys. 5, 79.
- Gangardt, D. M., and G. V. Shlyapnikov (2003b), Phys. Rev. Lett. 90, 010401.
- Gaudin, M. (1967), Phys. Lett. A 24, 55.
- Gaudin, M. (1983), La fonction d'onde de Bethe (Masson, Paris).
- Giamarchi, T. (2004), Quantum Physics in One Dimension (Clarendon Press, Oxford).
- Giamarchi, T., C. R¨uegg, and O. Tchernyshyov (2008), Nature Physics 4, 198.
- Girardeau, M. (1960), Journal of Mathematical Physics 1, 516.
- Glazman, L. I., G. B. Lesovik, D. E. Khmel'nitskii, and R. I. Shekhter (1988), JETP Lett. 48 (4), 238.
- Gogolin, A. O., A. A. Nersesyan, and A. M. Tsvelik (1998), Bosonization and Strongly Correlated Systems (Cambridge University Press, Cambridge).
- Golovach, V. N., A. Minguzzi, and L. I. Glazman (2009), Phys. Rev. A 80, 043611.
- G¨orlitz, A., J. M. Vogels, A. E. Leanhardt, C. Raman, T. L. Gustavson, J. R. Abo-Shaeer, A. P. Chikkatur, S. Gupta, S. Inouye, T. Rosenband, and W. Ketterle (2001), Phys. Rev. Lett. 87, 130402.
- Gorshkov, A. V., M. Hermele, V. Gurarie, C. Xu, P. S. Julienne, J. Ye, P. Zoller, E. Demler, M. D. Lukin, and A. M. Rey (2010), Nature Physics 6, 289.
- Granger, G., J. P. Eisenstein, and J. L. Reno (2009), Phys. Rev. Lett. 102, 086803.
- Grigera, S. A., A. J. Schofield, S. Rabello, and Q. Si (2004), Phys. Rev. B. 69, 245109.
- Gritsev, V., T. Rostunov, and E. Demler (2010), J. Stat. Mech.: Theory Exp. 10, P05012.
- Grossjohann, S., and W. Brenig (2010), Phys. Rev. B 81, 012404.
- Guan, X.-W., M. T. Batchelor, and M. Takahashi (2007), Phys. Rev. A 76, 043617.
- Guarrera, V., D. Muth, R. Labouvie, A. Vogler, G. Barontini, M. Fleischhauer, and H. Ott (2012), arxiv:1201.5015 arXiv:1201.5015 [cond-mat.quant-gas].
- Guarrera, V., P. W¨urtz, A. Ewerbeck, A. Vogler, G. Barontini, and H. Ott (2011), Phys. Rev. Lett. 107 (16), 160403. Gutman, D. B. (2008), Phys. Rev. B 77, 035127.
- Ha, Z. N. C. (1994), Phys. Rev. Lett. 73, 1574.
- Ha, Z. N. C. (1995), Nucl. Phys. B 435, 604.

- Ha, Z. N. C. (1996), Quantum Many-Body Systems in One Dimension (World Scientific, Singapore).
- Ha, Z. N. C., and F. D. M. Haldane (1994), Phys. Rev. Lett. 73, 2887.
- Haldane, F. D. M. (1980), Phys. Rev. Lett. 45, 1358.
- Haldane, F. D. M. (1981a), Phys. Rev. Lett. 47, 1840.
- Haldane, F. D. M. (1981b), J. Phys. C 14, 2585.
- Haldane, F. D. M. (1988), Phys. Rev. Lett. 60, 635.
- Haldane, F. D. M. (1991), Phys. Rev. Lett. 66, 1529.
- Haldane, F. D. M. (1995), in Proceedings of the International Colloquium on Modern Quantum Field Theory II, edited by G. Mandal, S. Mukhi, and S. R. Wadia (World Scientific).
- Haldane, F. D. M., Z. N. C. Ha, J. C. Talstra, D. Bernard, and V. Pasquier (1992), Phys. Rev. Lett. 69, 2021.
- Haldane, F. D. M., and M. R. Zirnbauer (1993), Phys. Rev. Lett. 71, 4055.
- Haller, E., M. Gustavsson, M. J. Mark, J. G. Danzl, R. Hart, G. Pupillo, and H. N¨agerl (2009), Science 325, 1224.
- Haller, E., M. Rabie, M. J. Mark, J. G. Danzl, R. Hart, K. Lauber, G. Pupillo, and H.-C. N¨agerl (2011), Phys. Rev. Lett. 107 (23), 230404.
- Heidrich-Meisner, F., A. Honecker, D. C. Cabra, and W. Brenig (2003), Phys. Rev. B 68, 134436.
- Herbrych, J., P. Prelovˇsek, and X. Zotos (2011), Phys. Rev. B. 84 (15), 155125.
- Heyl, M., S. Kehrein, F. Marquardt, and C. Neuenhahn (2010), Phys. Rev. B 82, 033409.
- Higbie, J. M., L. E. Sadler, S. Inouye, A. P. Chikkatur, S. R. Leslie, K. L. Moore, V. Savalli, and D. M. Stamper-Kurn (2005), Phys. Rev. Lett. 95, 050401.
- Hodgman, S. S., R. G. Dall, A. G. Manning, K. G. H. Baldwin, and A. G. Truscott (2011), Science 331, 1046.
- Hofferberth, S., I. Lesanovsky, B. Fischer, T. Schumm, and J. Schmiedmayer (2007), Nature 449, 324.
- Hofferberth, S., I. Lesanovsky, T. Schumm, A. Imambekov, V. Gritsev, E. Demler, and J. Schmiedmayer (2008), Nat. Phys. 4, 489.
- Hoinkis, M., M. Sing, J. Sch¨afer, M. Klemm, S. Horn, H. Benthien, E. Jeckelmann, T. Saha-Dasgupta, L. Pisani, R. Valent´ı, and R. Claessen (2005), Phys. Rev. B 72, 125127.
- Huang, K. (1987), Statistical Mechanics, 2nd ed. (Wiley).
- Imambekov, A., and E. Demler (2006a), Ann. Phys. (N.Y.) 321, 2390.
- Imambekov, A., and E. Demler (2006b), Phys. Rev. A 73, 021602.
- Imambekov, A., and L. I. Glazman (2008), Phys. Rev. Lett. 100, 206805.
- Imambekov, A., and L. I. Glazman (2009a), Phys. Rev. Lett. 102, 126405.
- Imambekov, A., and L. I. Glazman (2009b), Science 323, 228.
- Imambekov, A., V. Gritsev, and E. Demler (2007), in Proceedings of the 2006 Enrico Fermi Summer School on "Ultracold Fermi gases", edited by M. Inguscio, W. Ketterle, and C. Salomon (IOS press).
- Imambekov, A., V. Gritsev, and E. Demler (2008), Phys. Rev. A 77 (6), 063606.
- Imambekov, A., A. A. Lukyanov, L. I. Glazman, and V. Gritsev (2010), Phys. Rev. Lett. 104, 040402.
- Imambekov, A., I. E. Mazets, D. S. Petrov, V. Gritsev, S. Manz, S. Hofferberth, T. Schumm, E. Demler, and J. Schmiedmayer (2009), Phys. Rev. A 80, 033604.
- Jacqmin, T., J. Armijo, T. Berrada, K. V. Kheruntsyan, and I. Bouchoule (2011), Phys. Rev. Lett. 106, 230405.

- Jimbo, M., T. Miwa, Y. Mori, and M. Sato (1980), Physica (Utrecht) D 1, 80.
- Jolad, S., D. Sen, and J. K. Jain (2010), Phys. Rev. B 82, 075315.
- Jompol, Y., C. J. B. Ford, J. P. Griffiths, I. Farrer, G. A. C. Jones, D. Anderson, D. A. Ritchie, T. W. Silk, and A. J. Schofield (2009), Science 325, 597.
- Jung, P., R. W. Helmes, and A. Rosch (2006), Phys. Rev. Lett. 96, 067202.
- Jung, P., and A. Rosch (2007), Phys. Rev. B 76, 245108. Kamenev, A. (2011), private communication.
- Kamenev, A., and L. I. Glazman (2009), Phys. Rev. A 80, 011603.
- Karbach, M., G. M¨uller, A. H. Bougourzi, A. Fledderjohann, and K.-H. M¨utter (1997), Phys. Rev. B 55, 12510.
- Karimi, H., and I. Affleck (2011), Phys. Rev. B. 84 (17), 174420.
- Karrasch, C., J. H. Bardarson, and J. E. Moore (2011), arXiv:1111.4508v1.
- Karzig, T., L. I. Glazman, and F. von Oppen (2010), Phys. Rev. Lett. 105, 226407.
- Kato, Y. (1998), Phys. Rev. Lett. 81, 5402.
- Kheruntsyan, K. V., D. M. Gangardt, P. D. Drummond, and G. V. Shlyapnikov (2003), Phys. Rev. Lett. 91, 040403.
- Khodas, M., A. Kamenev, and L. I. Glazman (2008), Phys. Rev. A 78, 053630.
- Khodas, M., M. Pustilnik, A. Kamenev, and L. I. Glazman (2007a), Phys. Rev. Lett. 99, 110405.
- Khodas, M., M. Pustilnik, A. Kamenev, and L. I. Glazman (2007b), Phys. Rev. B 76, 155402.
- Kim, B. J., H. Koh, E. Rotenberg, S. Oh, H. Eisaki, N. Motoyama, S. Uchida, T. Tohyama, S. Maekawa, Z. Shen, and C. Kim (2006), Nat. Phys. 2, 397.
- Kinoshita, T., T. Wenger, and D. S. Weiss (2004), Science 305, 1125.
- Kinoshita, T., T. Wenger, and D. S. Weiss (2005), Phys. Rev. Lett. 95, 190406.
- Kinoshita, T., T. Wenger, and D. S. Weiss (2006), Nature 440, 900.
- Kitanine, N., K. K. Kozlowski, J. M. Maillet, N. A. Slavnov, and V. Terras (2009a), J. Stat. Mech.: Theory Exp. 9, P04003.
- Kitanine, N., K. K. Kozlowski, J. M. Maillet, N. A. Slavnov, and V. Terras (2009b), J. Math. Phys. 50 (9), 095209.
- Kitanine, N., K. K. Kozlowski, J. M. Maillet, N. A. Slavnov, and V. Terras (2011), J. Stat. Mech.: Theory Exp. 11, P05028.
- Kitanine, N., J. M. Maillet, and V. Terras (1999), Nucl. Phys. B 554, 647.
- Klauser, A., J. Mossel, J.-S. Caux, and J. van den Brink (2011), Phys. Rev. Lett. 106, 157205.
- Kohno, M. (2010), Phys. Rev. Lett. 105, 106402.
- Kohno, M., M. Arikawa, J. Sato, and K. Sakai (2010), J. Phys. Soc. Jpn. 79, 043707.
- Kojima, T., V. E. Korepin, and N. A. Slavnov (1997), Commun. Math. Phys. 188, 657.
- Kokalj, J., and P. Prelovsek (2009), Phys. Rev. B 80, 205117. Kollath, C., and U. Schollw¨ock (2006), New J. Phys. 8, 220.
- Kondo, T., R. Khasanov, J. Karpinski, S. M. Kazakov, N. D. Zhigadlo, Z. Bukowski, M. Shi, A. Bendounan, Y. Sassa, J. Chang, S. Pailh´es, J. Mesot, J. Schmalian, H. Keller, and A. Kaminski (2010), Phys. Rev. Lett. 105, 267003.
- Korepin, V., and N. Slavnov (1998), Eur. Phys. J. B 5, 555.

- Korepin, V. E., N. M. Bogoliubov, and A. G. Izergin (1993), Quantum Inverse Scattering Method and Correlation Functions (Cambridge University Press, Cambridge).
- Kormos, M., Y.-Z. Chou, and A. Imambekov (2011), Phys. Rev. Lett. 107, 230405.
- Kormos, M., G. Mussardo, and A. Trombettoni (2009), Phys. Rev. Lett. 103, 210404.
- Kormos, M., G. Mussardo, and A. Trombettoni (2010), Phys. Rev. A 81, 043606.
- Kozlowski, K. K. (2011), arXiv:1101.1626.
- Kozlowski, K. K., and V. Terras (2011), J. Stat. Mech.: Theory Exp. 11, P09013.
- Kraft, S., F. Vogt, O. Appel, F. Riehle, and U. Sterr (2009), Phys. Rev. Lett. 103, 130401.
- Kulish, P. P., S. V. Manakov, and L. D. Faddeev (1976), Theoretical and Mathematical Physics 28, 615.
- Kulkarni, M., F. Franchini, and A. G. Abanov (2009), Phys. Rev. B 80, 165105.
- Kuramoto, Y., and Y. Kato (2009), Dynamics of One-Dimensional Quantum Systems: Inverse-Square Interaction Models (Cambridge University Press, Oxford).
- Kuramoto, Y., and H. Yokoyama (1991), Phys. Rev. Lett. 67, 1338.
- Lai, C. K., and C. N. Yang (1971), Phys. Rev. A 3, 393.
- Lake, B., D. A. Tennant, C. D. Frost, and S. E. Nagler (2005), Nat. Mater. 4, 329.
- Lake, B., A. M. Tsvelik, S. Notbohm, D. Alan Tennant, T. G. Perring, M. Reehuis, C. Sekar, G. Krabbes, and B. B¨uchner (2010), Nat. Phys. 6, 50.
- Lamacraft, A. (2008), Phys. Rev. Lett. 101, 225301.
- Lamacraft, A. (2009), Phys. Rev. B 79, 241105.
- Landau, L. D., and E. M. Lifshitz (1980), Statistical Physics, part 1 (Pergamon Press, Oxford).
- Laroche, D., G. Gervais, M. P. Lilly, and J. L. Reno (2011), Nature Nanotechnology 6, 793.
- Lee, J. Y., X. W. Guan, K. Sakai, and M. T. Batchelor (2011), arXiv:1104.2352v2.
- Lesage, F., V. Pasquier, and D. Serban (1995), Nuclear Physics B 435, 585.
- Levchenko, A., T. Micklitz, J. Rech, and K. A. Matveev (2010), Phys. Rev. B 82, 115413.
- Levchenko, A., T. Micklitz, Z. Ristivojevic, and K. A. Matveev (2011a), Phys. Rev. B 84, 115447.
- Levchenko, A., Z. Ristivojevic, and T. Micklitz (2011b), Phys. Rev. B 83, 041303(R).
- Li, Y.-Q., S.-J. Gu, Z.-J. Ying, and U. Eckern (2003), Europhysics Letters 61, 368.
- Liao, Y.-A., A. S. C. Rittner, T. Paprotta, W. Li, G. B. Partridge, R. G. Hulet, S. K. Baur, and E. J. Mueller (2010), Nature 467, 567.
- Lieb, E., and D. Mattis (1962), Phys. Rev. 125, 164.
- Lieb, E. H. (1963), Phys. Rev. 130, 1616.
- Lieb, E. H., and W. Liniger (1963), Phys. Rev. 130, 1605.
- Lieb, E. H., and F. Y. Wu (1968), Phys. Rev. Lett. 20, 1445.
- Lukyanov, S., and V. Terras (2003), Nucl. Phys. B 654, 323.
- Lunde, A. M., K. Flensberg, and L. I. Glazman (2007), Phys. Rev. B 75, 245418.
- Lunde, A. M., S. E. Nigg, and M. B¨uttiker (2010), Phys. Rev. B 81, 041311.
- Luther, A., and I. Peschel (1974), Phys. Rev. B 9, 2911.
- Luttinger, J. M. (1960), Phys. Rev. 119, 1153.
- Luttinger, J. M. (1963), J. Math. Phys. 4, 1154.
- Ma, Y., and A. Imambekov (2012), unpublished.
- Mahan, G. D. (1967), Phys. Rev. 163, 612.

- Mahan, G. D. (1981), Many-Particle Physics (Plenum, New York).
- Manz, S., R. B¨ucker, T. Betz, C. Koller, S. Hofferberth, I. E. Mazets, A. Imambekov, E. Demler, A. Perrin, J. Schmiedmayer, and T. Schumm (2010), Phys. Rev. A 81, 031610.
- Maslov, D. L., and M. Stone (1995), Phys. Rev. B 52, R5539. Masuda, T., A. Zheludev, H. Manaka, L.-P. Regnault, J.-H. Chung, and Y. Qiu (2006), Phys. Rev. Lett. 96, 047210.
- Mattis, D. C. (1974), J. Math. Phys. 15, 609.
- Mattis, D. C., and E. H. Lieb (1965), J. Math. Phys. 6, 304. Matveev, K. A. (2004a), Phys. Rev. B 70, 245319.
- Matveev, K. A. (2004b), Phys. Rev. Lett. 92, 106801.
- Matveev, K. A., and A. V. Andreev (2011), Phys. Rev. Lett. 107, 056402.
- Matveev, K. A., and A. V. Andreev (2012a), arxiv:1204.5827. Matveev, K. A., and A. V. Andreev (2012b), Phys. Rev. B 85, 041102(R).
- Matveev, K. A., A. V. Andreev, and M. Pustilnik (2010), Phys. Rev. Lett. 105, 046401.
- Matveev, K. A., and A. Furusaki (2008), Phys. Rev. Lett. 101, 170403.
- Matveev, K. A., A. Furusaki, and L. I. Glazman (2007a), Phys. Rev. Lett. 98, 096403.
- Matveev, K. A., A. Furusaki, and L. I. Glazman (2007b), Phys. Rev. B 76, 155440.
- Mazets, I. E. (2011), Phys. Rev. A 83, 043625.
- Mazets, I. E., T. Schumm, and J. Schmiedmayer (2008), Phys. Rev. Lett. 100, 210403.
- Mazur, P. (1969), Physica 43 (4), 533.
- McGuirk, J. M., H. J. Lewandowski, D. M. Harber, T. Nikuni, J. E. Williams, and E. A. Cornell (2002), Phys. Rev. Lett. 89, 090402.
- Meden, V. (1999), Phys. Rev. B 60, 4571.
- Meden, V., and K. Sch¨onhammer (1992), Phys. Rev. B 46, 15753.
- Micklitz, T., and A. Levchenko (2011), Phys. Rev. Lett. 106, 196402.
- Micklitz, T., J. Rech, and K. A. Matveev (2010), Phys. Rev. B 81, 115313.
- Mishchenko, E. G., and O. A. Starykh (2011), Phys. Rev. Lett. 107, 116804.
- Mora, C., and Y. Castin (2003), Phys. Rev. A 67, 053615.
- M¨uller, G., H. Beck, and J. C. Bonner (1979), Phys. Rev. Lett. 43, 75.
- M¨uller, G., H. Thomas, H. Beck, and J. C. Bonner (1981), Phys. Rev. B 24, 1429.
- Muryshev, A., G. V. Shlyapnikov, W. Ertmer, K. Sengstock, and M. Lewenstein (2002), Phys. Rev. Lett. 89 (11), 110401.
- Nagler, S. E., D. A. Tennant, R. A. Cowley, T. G. Perring, and S. K. Satija (1991), Physical Review B 44, 12361.
- Nayak, C., K. Shtengel, D. Orgad, M. P. A. Fisher, and S. M. Girvin (2001), Phys. Rev. B 64, 235113.
- Neuenhahn, C., and F. Marquardt (2009), Phys. Rev. Lett. 102, 046806.
- Nozieres, P. (1997), Theory of interacting Fermi systems (Addision-Wesley, Reading, MA).
- Nozi`eres, P., and C. T. De Dominicis (1969), Phys. Rev. 178, 1097.
- Ogata, M., and H. Shiba (1990), Phys. Rev. B 41, 2326.
- Ogawa, T., A. Furusaki, and N. Nagaosa (1992), Phys. Rev. Lett. 68, 3638.
- Ohtaka, K., and Y. Tanabe (1990), Rev. Mod. Phys. 62, 929. Olshanii, M. (1998), Phys. Rev. Lett. 81, 938.

- Orbach, R. (1958), Phys. Rev. 112, 309.
- Pal, A., and D. A. Huse (2010), Phys. Rev. B 82 (17), 174411. Palzer, S., C. Zipkes, C. Sias, and M. K¨ohl (2009), Phys. Rev. Lett. 103, 150601.
- Papp, S. B., J. M. Pino, R. J. Wild, S. Ronen, C. E. Wieman, D. S. Jin, and E. A. Cornell (2008), Phys. Rev. Lett. 101, 135301.
- Paradiso, N., S. Heun, S. Roddaro, D. Venturelli, F. Taddei, V. Giovannetti, R. Fazio, G. Biasiol, L. Sorba, and F. Beltram (2011), Phys. Rev. B 83 (15), 155305.
- Paredes, B., A. Widera, V. Murg, O. Mandel, S. F¨olling, I. Cirac, G. V. Shlyapnikov, T. W. H¨ansch, and I. Bloch (2004), Nature 429, 277.
- Patu, O. I., V. E. Korepin, and D. V. Averin (2009), Europhysics Letters 87, 60006.
- Pereira, R. G., K. Penc, S. R. White, P. D. Sacramento, and J. M. P. Carmelo (2012), arXiv:1111.2009.
- Pereira, R. G., and E. Sela (2010), Phys. Rev. B 82, 115324. Pereira, R. G., J. Sirker, J. Caux, R. Hagemans, J. M. Maillet, S. R. White, and I. Affleck (2007), J. Stat. Mech.: Theory Exp. 2007, P08022.
- Pereira, R. G., J. Sirker, J.-S. Caux, R. Hagemans, J. M. Maillet, S. R. White, and I. Affleck (2006), Phys. Rev. Lett. 96, 257202.
- Pereira, R. G., S. R. White, and I. Affleck (2008), Phys. Rev. Lett. 100, 027206.
- Pereira, R. G., S. R. White, and I. Affleck (2009), Phys. Rev. B 79, 165113.
- Petrov, D. S., G. V. Shlyapnikov, and J. T. M. Walraven (2000), Phys. Rev. Lett. 85, 3745.
- Pirooznia, P., and P. Kopietz (2007), Eur. Phys. J. B 58, 291.
- Pirooznia, P., F. Sch¨utz, and P. Kopietz (2008), Phys. Rev. B 78, 075111.
- Pitaevskii, L. P., and S. Stringari (2003), Bose-Einstein condensation (Oxford University Press, Oxford).
- Polkovnikov, A., E. Altman, and E. Demler (2006), PNAS 103, 6125.
- Polkovnikov, A., K. Sengupta, A. Silva, and M. Vengalattore (2011), Rev. Mod. Phys. 83, 863.
- Ponomarenko, V. V. (1995), Phys. Rev. B 52, R8666.
- Popov, V. N. (1980), JETP Letters 31, 526.
- Povarov, K. Y., A. I. Smirnov, O. A. Starykh, S. V. Petrov, and A. Y. Shapiro (2011), Phys. Rev. Lett. 107, 037204.
- Pozsgay, B. (2011), J. Stat. Mech.: Theory Exp. 11, P11017. Prosen, T. (2011), Phys. Rev. Lett. 106, 217206.
- Punk, M., and W. Zwerger (2006), New J. Phys. 8, 168.
- Pustilnik, M. (2006), Phys. Rev. Lett. 97, 036404.
- Pustilnik, M., M. Khodas, A. Kamenev, and L. I. Glazman (2006), Phys. Rev. Lett. 96, 196405.
- Pustilnik, M., E. G. Mishchenko, L. I. Glazman, and A. V. Andreev (2003), Phys. Rev. Lett. 91, 126805.
- Rabello, S., and Q. Si (2002), Europhysics Letters 60, 882.
- Recati, A., P. O. Fedichev, W. Zwerger, and P. Zoller (2003), Phys. Rev. Lett. 90, 020401.
- Rech, J., and K. A. Matveev (2008), Phys. Rev. Lett. 100, 066407.
- Rech, J., T. Micklitz, and K. A. Matveev (2009), Phys. Rev. Lett. 102, 116402.
- Rosch, A., and N. Andrei (2000), Phys. Rev. Lett. 85, 1092.
- Rozhkov, A. V. (2005), Eur. Phys. J. B 47, 193.
- Rozhkov, A. V. (2006), Phys. Rev. B 74, 245123.
- Rozhkov, A. V. (2008), Phys. Rev. B 77, 125109.
- Rozhkov, A. V. (2009), Phys. Rev. B 79, 249903.

- R¨uegg, C., B. Normand, M. Matsumoto, C. Niedermayer, A. Furrer, K. W. Kr¨amer, H.-U. G¨udel, P. Bourges, Y. Sidis, and H. Mutka (2005), Phys. Rev. Lett. 95, 267201.
- Sadler, L. E., J. M. Higbie, S. R. Leslie, M. Vengalattore, and D. M. Stamper-Kurn (2006), Nature 443, 312.
- Safi, I., and H. J. Schulz (1995), Phys. Rev. B 52, R17040. Samokhin, K. V. (1998), J. Phys. Condens. Matter 10, L533.
- Schecter, M., D. Gangardt, and A. Kamenev (2011), arXiv:1105.6136.
- Schmidt, T. L., A. Imambekov, and L. I. Glazman (2010a), Phys. Rev. Lett. 104, 116403.
- Schmidt, T. L., A. Imambekov, and L. I. Glazman (2010b), Phys. Rev. B 82, 245104.
- Schollw¨ock, U. (2005), Rev. Mod. Phys. 77, 259.
- Sch¨onhammer, K. (2007), Phys. Rev. B 75, 205103.
- Schotte, K. D., and U. Schotte (1969), Phys. Rev. 182, 479. Schrieffer, J. R., and P. A. Wolff (1966), Phys. Rev. 149, 491.
- Shashi, A., L. I. Glazman, J.-S. Caux, and A. Imambekov (2011), Phys. Rev. B 84, 045408.
- Shashi, A., M. Panfil, J.-S. Caux, and A. Imambekov (2010), arXiv:1010.2268v5.
- Shastry, B. S. (1988), Phys. Rev. Lett. 60, 639.
- Sing, M., U. Schwingenschl¨ogl, R. Claessen, P. Blaha, J. M. P. Carmelo, L. M. Martelo, P. D. Sacramento, M. Dressel, and C. S. Jacobsen (2003), Phys. Rev. B 68, 125111.
- Singh, R. R. P., M. E. Fisher, and R. Shankar (1989), Phys. Rev. B 39, 2562.
- Sirker, J., R. G. Pereira, and I. Affleck (2009), Phys. Rev. Lett. 103, 216602.
- Sirker, J., R. G. Pereira, and I. Affleck (2011), Phys. Rev. B 83, 035115.
- Slavnov, N. A. (1989), Teor. Mat. Fiz. 79, 232.
- Slavnov, N. A. (1990), Teor. Mat. Fiz. 82, 389.
- S´olyom, J. (1979), Adv. Phys. 28, 201.
- Sorella, S., and A. Parola (1996), Phys. Rev. Lett. 76, 4604. Sorella, S., and A. Parola (1998), Phys. Rev. B 57, 6444.
- Stamper-Kurn, D. M., A. P. Chikkatur, A. G¨orlitz, S. Inouye, S. Gupta, D. E. Pritchard, and W. Ketterle (1999), Phys. Rev. Lett. 83, 2876.
- Stellmer, S., M. K. Tey, B. Huang, R. Grimm, and F. Schreck (2009), Phys. Rev. Lett. 103, 200401.
- Stewart, J. T., J. P. Gaebler, and D. S. Jin (2008), Nature 454, 744.
- Stone, M., I. Anduaga, and L. Xing (2008), J. Phys. A 41, 275401.
- Stone, M. B., D. H. Reich, C. Broholm, K. Lefmann, C. Rischel, C. P. Landee, and M. M. Turnbull (2003), Physical Review Letters 91, 037205.
- le Sueur, H., C. Altimiras, U. Gennser, A. Cavanna, D. Mailly, and F. Pierre (2010), Phys. Rev. Lett. 105, 056803.
- Sutherland, B. (1968), Phys. Rev. Lett. 20, 98.
- Sutherland, B. (1971), J. Math. Phys. 12, 246.
- Sutherland, B. (2004), Beautiful Models (World Scientific, Singapore).
- Suzuki, M. (1971), Physica 51 (2), 277.
- Sykes, A. G., D. M. Gangardt, M. J. Davis, K. Viering, M. G. Raizen, and K. V. Kheruntsyan (2008), Phys. Rev. Lett. 100, 160406.
- Taie, S., Y. Takasu, S. Sugawa, R. Yamazaki, T. Tsujimoto, R. Murakami, and Y. Takahashi (2010), Phys. Rev. Lett. 105, 190401.

- Takahashi, M. (2005), Thermodynamics of One-Dimensional Solvable Models (Cambridge University Press).
- Takasu, Y., K. Maki, K. Komori, T. Takano, K. Honda, M. Kumakura, T. Yabuzaki, and Y. Takahashi (2003), Phys. Rev. Lett. 91, 040404.
- Talstra, J. C., and F. D. M. Haldane (1994), Phys. Rev. B 50, 6889.
- Tan, S., M. Pustilnik, and L. I. Glazman (2010), Phys. Rev. Lett. 105, 090404.
- Teber, S. (2006), Eur. Phys. J. B 52, 233.
- Teber, S. (2007), Phys. Rev. B 76, 045309.
- Tennant, D. A. e. (2009), arXiv:0907.2067.
- Thielemann, B., C. R¨uegg, H. M. Rønnow, A. M. L¨auchli, J.-S. Caux, B. Normand, D. Biner, K. W. Kr¨amer, H.-U. G¨udel, J. Stahn, K. Habicht, K. Kiefer, M. Boehm, D. F. McMorrow, and J. Mesot (2009), Phys. Rev. Lett. 102, 107204.
- Tolra, B. L., K. M. O'Hara, J. H. Huckans, W. D. Phillips, S. L. Rolston, and J. V. Porto (2004), Phys. Rev. Lett. 92, 190401.
- Tomonaga, S.-I. (1950), Prog. Theor. Phys. 5, 544.
- Tsukamoto, Y., T. Fujii, and N. Kawakami (1998), Phys. Rev. B 58, 3633.
- Vaidya, H. G., and C. A. Tracy (1979), Phys. Rev. Lett. 42, 3.
- Znidariˇc, M. (2011), Phys. Rev. Lett. ˇ 106, 220601.
- Veeravalli, G., E. Kuhnle, P. Dyke, and C. J. Vale (2008), Phys. Rev. Lett. 101, 250403.
- Vekua, T., S. I. Matveenko, and G. V. Shlyapnikov (2009), JETP Lett. 90, 289.
- Vidal, G. (2003), Phys. Rev. Lett. 91, 147902.
- Vidal, G. (2004), Phys. Rev. Lett. 93 (4), 040502.
- Voit, J. (1993a), Phys. Rev. B 47, 6740.
- Voit, J. (1993b), J. Phys. Condens. Matter 5, 8305.
- Voit, J. (1995), Rep. Prog. Phys. 58, 977.
- Wada, N., J. Taniguchi, H. Ikegami, S. Inagaki, and Y. Fukushima (2001), Phys. Rev. Lett. 86, 4322.
- Wang, F., J. V. Alvarez, J. W. Allen, S.-K. Mo, J. He, R. Jin, D. Mandrus, and H. H¨ochst (2009), Phys. Rev. Lett. 103, 136401.
- Wang, F., J. V. Alvarez, S.-K. Mo, J. W. Allen, G.-H. Gweon, J. He, R. Jin, D. Mandrus, and H. H¨ochst (2006), Phys. Rev. Lett. 96, 196403.
- van Wees, B. J., H. van Houten, C. W. J. Beenakker, J. G. Williamson, L. P. Kouwenhoven, D. van der Marel, and C. T. Foxon (1988), Phys. Rev. Lett. 60 (9), 848.
- Wharam, D. A., T. J. Thornton, R. Newbury, M. Pepper, H. Ahmed, J. E. F. Frost, D. G. Hasko, D. C. Peacock, D. A. Ritchie, and G. A. C. Jones (1988), Journal of Physics C: Solid State Physics 21 (8), L209.
- White, S. R. (1992), Phys. Rev. Lett. 69, 2863.
- White, S. R., and I. Affleck (2008), Phys. Rev. B 77, 134437. Wigner, E. (1934), Phys. Rev. 46, 1002.
- Wu, J., and M. Berciu (2011), Phys. Rev. B 83, 214416.
- Yamamoto, M., M. Stopa, Y. Tokura, Y. Hirayama, and S. Tarucha (2002), Physica E (Amsterdam) 12, 726.
- Yamamoto, M., M. Stopa, Y. Tokura, Y. Hirayama, and S. Tarucha (2006), Science 313, 204.
- Yamamoto, T., and M. Arikawa (1999), J. Phys. A 32, 3341. Yamamoto, T., Y. Saiga, M. Arikawa, and Y. Kuramoto (2000), Phys. Rev. Lett. 84, 1308.
- Yamanaka, M., M. Oshikawa, and I. Affleck (1997), Phys. Rev. Lett. 79, 1110.
- Yang, C. N. (1967), Phys. Rev. Lett. 19, 1312.

- Zheludev, A., V. O. Garlea, L.-P. Regnault, H. Manaka, A. Tsvelik, and J.-H. Chung (2008), Phys. Rev. Lett. 100, 157204.
- Zheludev, A., Z. Honda, Y. Chen, C. L. Broholm, K. Katsumata, and S. M. Shapiro (2002), Phys. Rev. Lett. 88, 077206.
- Ziman, J. M. (1960), Electrons and Phonons: The theory of transport phenomena in solids (Oxford University Press, London).
- Zotos, X., F. Naef, and P. Prelovsek (1997), Phys. Rev. B 55 (17), 11029.
- Zvonarev, M. B., V. V. Cheianov, and T. Giamarchi (2007), Phys. Rev. Lett. 99, 240404.
- Zvonarev, M. B., V. V. Cheianov, and T. Giamarchi (2009a), Phys. Rev. Lett. 103, 110401.
- Zvonarev, M. B., V. V. Cheianov, and T. Giamarchi (2009b), Phys. Rev. B 80, 201102.
- Zvonarev, M. B., V. V. Cheianov, and T. Giamarchi (2009c), J. Stat. Mech.: Theory Exp. 2009, P07035.