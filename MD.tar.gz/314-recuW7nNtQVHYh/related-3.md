# Exact formulas for the form factors of local operators in the Lieb-Liniger model

### Lorenzo Piroli and Pasquale Calabrese

SISSA and INFN, via Bonomea 265, 34136 Trieste, Italy

Abstract. We present exact formulas for the form factors of local operators in the repulsive Lieb-Liniger model at finite size. These are essential ingredients for both numerical and analytical calculations. From the theory of Algebraic Bethe Ansatz, it is known that the form factors of local operators satisfy a particular type of recursive relations. We show that in some cases these relations can be used directly to derive practical expressions in terms of the determinant of a matrix whose dimension scales linearly with the system size. Our main results are determinant formulas for the form factors of the operators (Ψ† (0))2Ψ<sup>2</sup> (0) and ΨR(0), for arbitrary integer R, where Ψ, Ψ† are the usual field operators. From these expressions, we also derive the infinite size limit of the form factors of these local operators in the attractive regime.

### 1. Introduction

Exactly solvable models play a unique role in theoretical physics and in particular for manybody systems. Integrability makes it possible to have an analytical control of the underlying physics which is in general out of reach. This gives a remarkable opportunity of sharp theoretical investigations of important aspects of both classical and quantum mechanics, as reported in many excellent textbooks [1, 2, 3, 4, 5]. For a long time exactly solvable models have been the ideal theoretical laboratory where physicists could deepen their understanding of many body physics, develop new mathematical tools and test the limits of approximate methods developed to be applied in the study of more complicated systems. However, integrability in the past has been often relegated to the realm of formal mathematical physics and thought to have little contact with the real physical world. This prejudice has been removed during the last decade mainly thanks to the crucial experimental advances in the field of ultra cold atoms, which have made it possible to realize physical systems that can be described, with a good approximation, by ideal models (see [6, 7] and references therein). One of the prototypical exactly solvable models is the Lieb-Liniger gas introduced in [8]. This is a one-dimensional model of bosons with point-like interaction, closely related to experimentally realized systems of confined bosons in one dimension [9, 10, 11]. Many other integrable models have been engineered in cold atomic laboratories in the last decade, such as the Ising spin chain [12] and one dimensional Fermi gases [13, 14].

Although integrable Hamiltonians can be analytically diagonalized, the computation of most of the physical and experimentally measurable observables remains in general an extremely hard task, because of the difficulty in obtaining manageable expressions for the form factors of a local operator, which are defined as its matrix elements between eigenstates of the model.

In this work we focus on the exact computation of form factors of local operators in the Lieb-Liniger gas with a finite number of particles in a finite system. Despite of more than fifty years of intense investigation following the seminal Bethe ansatz solution of the Lieb-Liniger model [8], there are still many physically interesting quantities for which no practical analytical expression is available. To the date, only the form factors of the fundamental bosonic field [15, 16] and of the density [17] are known in simple enough forms (in a sense which will be clarified later) to allow the computation of the equilibrium correlation function at least numerically [16, 18, 19, 20]. For the calculation of expectation values of all other local operators in equilibrium states (which are particular limits of form factors), other complementary approaches are usually exploited [21, 22, 23, 24, 25].

Recently, the importance of disposing of simple, practical expressions for the form factors of local operators has also emerged in the study of non-equilibrium dynamics of isolated quantum systems following a quantum quench. Indeed, it has been shown [26] that late times after the quench an integrable systems is locally described by a single representative Hamiltonian eigenstate which can be constructed by means of a generalized thermodynamic Bethe ansatz. This approach has been successfully applied to the Lieb-Liniger model [27, 28], to the XXZ spin-chain [29, 30], to transport problems [31], and to the sine-Gordon field theory [32]. For finite times the same approach can be used in conjunction with numerical techniques [26, 33, 34] to provide expectation values of local observables as a single sum of intermediate states, instead of a double one of the direct approach [35, 36, 37, 38]. However, the calculation of measurable observables is limited by the (un-)knowledge of the form factors even for the quench dynamics. Furthermore, the knowledge of more general form factors greatly helps also in the determination of exact formulas for the overlaps between initial state and Bethe states in the quench dynamics which nowadays are known only in very few cases [35, 27, 39, 40, 41, 42, 43].

The organization of this paper is as follows. In section 2 we introduce the Lieb-Liniger gas and its solution via the (Algebraic) Bethe Ansatz. For the sake of clarity we summarize the main results of our work in section 3, while their derivation is presented in section 4. In section 5 we consider the attractive Lieb-Liniger gas and we show how our formulas can be simplified in the infinite size limit. Our conclusions are presented in section 6, while technical aspects of our work are reported in the appendices.

### 2. The Lieb-Liniger model and the Algebraic Bethe Ansatz

The Lieb-Liniger model describes a system of bosons constrained on a one-dimensional system of length L with periodic boundary conditions. The Hamiltonian written in the second quantization formalism is [8]

$$H_{LL} = \int_0^L dx \left( \partial_x \Psi^{\dagger}(x) \partial_x \Psi(x) + c \Psi^{\dagger}(x) \Psi^{\dagger}(x) \Psi(x) \Psi(x) \right) , \qquad (1)$$

where c is the coupling constant (which we now take to be positive, c > 0). The field operators satisfy canonical commutation relations [Ψ(x), Ψ† (y)] = δ(x − y).

The eigenstates of the system have a well defined number of particles, which is conserved by the Hamiltonian (1). The model was originally solved using the Coordinate Bethe Ansatz [8], but the natural framework for the computation of physical quantities like the scalar product of states, form factors and correlation functions is given by the so called Algebraic Bethe Ansatz (ABA) and quantum inverse scattering method [5, 44, 45, 46].

One of the fundamental objects in the ABA method is the monodromy matrix

$$T(\lambda) = \begin{pmatrix} A(\lambda) & B(\lambda) \\ C(\lambda) & D(\lambda) \end{pmatrix} , \qquad (2)$$

where A(λ), B(λ), C(λ), D(λ) are operators acting on a reference state that we indicate with |0i. These operators satisfy a set of non-trivial commutation relations encoded in the Yang-Baxter equations. These, in turn, involve another fundamental object of ABA, namely the R-matrix, a 4 × 4 matrix that in our case reads

$$R(\lambda, \mu) = \begin{pmatrix} f(\mu, \lambda) & & & \\ & g(\mu, \lambda) & 1 & \\ & 1 & g(\mu, \lambda) & \\ & & f(\mu, \lambda) \end{pmatrix}, \tag{3}$$

where empty entries of the matrix are defined to be 0 and where

$$f(\lambda, \mu) = \frac{\lambda - \mu + ic}{\lambda - \mu}, \quad g(\lambda, \mu) = \frac{ic}{\lambda - \mu}.$$
 (4)

The Hilbert space is generated by the Bethe states defined as

$$\prod_{j=1}^{N} B(\lambda_j)|0\rangle , \qquad (5)$$

with dual states

$$\langle 0| \prod_{j=1}^{N} C(\lambda_j) , \qquad (6)$$

while the action on the reference state of the operators A(λ), D(λ) is given by

$$A(\lambda)|0\rangle = a(\lambda)|0\rangle$$
,  $D(\lambda)|0\rangle = d(\lambda)|0\rangle$ . (7)

In the Lieb-Liniger model the functions a(λ), d(λ) are

$$a(\lambda) = e^{-i\frac{L}{2}\lambda}, \qquad d(\lambda) = e^{i\frac{L}{2}\lambda}.$$
 (8)

We further define for later convenience the function

$$r(\lambda) = \frac{a(\lambda)}{d(\lambda)} \,. \tag{9}$$

The parameters {λj} N <sup>j</sup>=1 are called rapidities and can take arbitrary values. The Hamiltonian (1) can be related to the transfer matrix defined to be the trace of the monodromy matrix (2), τ (λ) = trT(λ) . This makes it possible to define a 1-to-1 map between the N-particle eigenstates of the Hamiltonian (1) and the states of the form (5) characterized by a set of rapidities  $\{\lambda_j\}_{j=1}^N$  satisfying the Bethe equations

$$e^{-i\lambda_j L} = \prod_{\substack{k=1\\k \neq j}}^N \frac{\lambda_k - \lambda_j + ic}{\lambda_k - \lambda_j - ic} \,. \tag{10}$$

If a state of the form (5) is characterized by a set of rapidities that satisfy the Bethe equations (10) we call such a state on-shell, otherwise we call it off-shell. On-shell Bethe states have well defined momentum and energy given respectively by

$$P(\{\lambda_j\}) = \sum_{i=1}^{N} \lambda_j , \qquad E(\{\lambda_j\}) = \sum_{i=1}^{N} \lambda_j^2 .$$
 (11)

Finally, it is useful to define rescaled operators

$$\mathcal{B}(\lambda) = \frac{1}{d(\lambda)} B(\lambda) , \qquad \mathcal{C}(\lambda) = \frac{1}{d(\lambda)} C(\lambda) , \qquad (12)$$

where  $d(\lambda)$  is given in (8).

The norm of on-shell Bethe states (5) is given by Gaudin's formula [3, 5, 47], which in our notations reads

$$\langle 0| \prod_{j=1}^{N} \mathcal{C}(\lambda_j) \prod_{j=1}^{N} \mathcal{B}(\lambda_j) |0\rangle = c^N \prod_{j < k} \frac{(\lambda_j - \lambda_k)^2 + c^2}{(\lambda_j - \lambda_k)^2} \det_N \mathcal{N}_{jk} , \qquad (13)$$

where

$$\mathcal{N}_{jk} = \delta_{jk} \left( L + \sum_{l=1}^{N} K(\lambda_j, \lambda_l) \right) - K(\lambda_j, \lambda_k) , \qquad (14)$$

$$K(\lambda, \mu) = \frac{2c}{(\lambda - \mu)^2 + c^2} . \tag{15}$$

It is possible to explicitly define the action of the field operators  $\Psi(0)$ ,  $\Psi^{\dagger}(0)$  on the Bethe states of the form (5), [5]. In particular, one can use the following commutation relations [5]

$$[\Psi(0), B(\lambda)] = -i\sqrt{c}A(\lambda) , \qquad [C(\lambda), \Psi^{\dagger}(0)] = i\sqrt{c}D(\lambda) , \qquad (16)$$

to derive

$$\Psi(0) \prod_{k=1}^{N} B(\lambda_k) |0\rangle = -i\sqrt{c} \sum_{k=1}^{N} \Lambda_k a(\lambda_k) \prod_{\substack{m=1\\m \neq k}}^{N} B(\lambda_m) |0\rangle , \qquad (17)$$

$$\langle 0| \prod_{k=1}^{N} C(\lambda_k) \Psi^{\dagger}(0) = i\sqrt{c} \sum_{k=1}^{N} \langle 0| \prod_{\substack{m=1\\m \neq k}}^{N} C(\lambda_m) \widetilde{\Lambda}_k d(\lambda_k) , \qquad (18)$$

where

$$\Lambda_k = \prod_{\substack{m=1\\m\neq k}}^N f(\lambda_k, \lambda_m), \qquad \widetilde{\Lambda}_k = \prod_{\substack{m=1\\m\neq k}}^N f(\lambda_m, \lambda_k).$$
(19)

Note that the connection between the ABA and the Coordinate Bethe Ansatz solutions of the Lieb-Liniger model can be seen explicitly by computing the wave function corresponding to a Bethe state of the form (5). Indeed, using the action of the operator  $\Psi(x)$  on Bethe states, and standard techniques in ABA [5], it can be seen that the following is valid

$$\langle 0|\Psi(x_N)\dots\Psi(x_1)\prod_{j=1}^N B(\lambda_j)|0\rangle =$$

$$= (-i\sqrt{c})^N \exp\left(-i\frac{L}{2}\sum_{k=1}^N \lambda_k\right) \sum_{P\in S_N} e^{i\sum_{j=1}^N x_j \lambda_{P_j}} \prod_{j\leq k} \left(1 - \frac{ic\operatorname{sgn}(x_k - x_j)}{\lambda_{P_k} - \lambda_{P_j}}\right). \tag{20}$$

Consider now the following class of form factors of local operators

$$\langle 0| \prod_{j=1}^{N} \mathcal{C}(\mu_j) (\Psi^{\dagger}(0))^h \Psi^k(0) \prod_{j=1}^{M} \mathcal{B}(\lambda_j) |0\rangle.$$

$$(21)$$

Note that the above expression is equal to zero unless N-h=M-k. The form factor in (21) can in principle be computed either by repeated action of the fields (17), (18) on Bethe states or through integration of wave-functions in the framework of Coordinate Bethe Ansatz. However, using these methods one arrives at formal expressions which in general involve sums of  $\sim N!M!$  terms. These expressions are too complicated for both numerical and analytical calculations, there existing no available procedure to simplify them.

In general, the derivation of practical formulas for the form factors of local operators like those in (21) for arbitrary N is indeed a very difficult task. In this paper we address this problem and our main results are summarized in the next section. The form factors of local operators in the Lieb-Liniger model have been also studied in the recent papers [25, 48, 49, 50, 51]. In Ref. [52] techniques similar to those exploited in the present work were used to study form factors of local operators in systems solvable by Nested Bethe Ansatz.

#### 3. Summary of our results

In this section we summarize the main results of our work. These are represented by the determinant formulas (22), (27), (30), (32) for the operators  $(\Psi^{\dagger}(0))^2\Psi^2(0)$  and  $\Psi^R(0)$  (with R arbitrary integer).

3.1. Form factor of 
$$(\Psi^{\dagger}(0))^2\Psi^2(0)$$

The first result is a practical expression for the form factor of the operator  $(\Psi^{\dagger}(0))^2\Psi^2(0)$ . Let  $\{\mu_j\}_{j=1}^N$ ,  $\{\lambda_j\}_{j=1}^N$  be two sets of rapidities satisfying the Bethe equations (10) such that  $\mu_j \neq \lambda_k, \forall j, k = 1, \ldots, N$ . Then, our result reads

$$\langle 0 | \prod_{j=1}^{N} \mathcal{C}(\mu_{j}) (\Psi^{\dagger}(0))^{2} \Psi^{2}(0) \prod_{j=1}^{N} \mathcal{B}(\lambda_{j}) | 0 \rangle = (-1)^{N} \frac{\mathcal{J}}{6c} \prod_{j,k=1}^{N} (\lambda_{jk} + ic)$$

$$\times \prod_{j=1}^{N} \prod_{k=1}^{N} \frac{1}{\lambda_{j} - \mu_{k}} \prod_{j=1}^{N} \left( V_{j}^{+} - V_{j}^{-} \right) \frac{\det_{N} \left( \delta_{jk} + U_{jk} \right)}{\left( V_{p}^{+} - V_{p}^{-} \right) \left( V_{s}^{+} - V_{s}^{-} \right)} , \qquad (22)$$

where  $\mathcal{B}$ ,  $\mathcal{C}$  are defined in (12),  $\lambda_{jk} = \lambda_j - \lambda_k$  and

$$V_j^{\pm} = \prod_{m=1}^{N} \frac{\mu_m - \lambda_j \pm ic}{\lambda_m - \lambda_j \pm ic} , \qquad (23)$$

$$U_{jk} = \frac{i}{V_j^+ - V_j^-} \frac{\prod_{m=1}^N (\mu_m - \lambda_j)}{\prod_{\substack{m=1 \ m \neq j}}^N (\lambda_m - \lambda_j)} \left[ K(\lambda_j, \lambda_k) - K(\lambda_p, \lambda_k) K(\lambda_s, \lambda_j) \right] , \qquad (24)$$

$$\mathcal{J} = (P_{\lambda} - P_{\mu})^4 - 4(P_{\lambda} - P_{\mu})(Q_{\lambda} - Q_{\mu}) + 3(E_{\lambda} - E_{\mu})^2, \tag{25}$$

$$P_{\lambda} = \sum_{j=1}^{N} \lambda_{j} , \quad E_{\lambda} = \sum_{j=1}^{N} \lambda_{j}^{2} , \quad Q_{\lambda} = \sum_{j=1}^{N} \lambda_{j}^{3} ,$$
 (26)

and analogously for  $P_{\mu}$ ,  $E_{\mu}$ ,  $Q_{\mu}$ . In the above equation,  $K(\lambda,\mu)$  is given in (15) and the parameters  $\lambda_s$  and  $\lambda_p$  are two arbitrary complex numbers not necessarily in the set  $\{\lambda_j\}_{j=1}^N$ . Note that the form factor (22) does not depend on  $\lambda_p$  and  $\lambda_s$  as it will be proved in the following section.

A formula for this form factor was already given by B. Pozsgay in [25], but there it was expressed as the sum of N(N-1)/2 determinants of  $N \times N$  matrices. In the case of equal sets of rapidities some simplifications occur and Pozsgay's formula remarkably leads to an expression for the thermodynamic limit of the expectation value of  $(\Psi^{\dagger}(0))^2\Psi^2(0)$  (and analogously for  $(\Psi^{\dagger}(0))^K\Psi^K(0)$ ). However the formulas presented in [25] are not very convenient in the case of different sets of rapidities, and equation (22) is more suitable both for numerical and analytical calculations (see section 3.4 for further discussions).

# 3.2. Form factor of $\Psi^R(0)$

Our second result is the form factor of the operator  $\Psi^R(0)$  for arbitrary integer R. Let  $\{\mu_j\}_{j=1}^N$ ,  $\{\lambda_j\}_{j=1}^{N+R}$  be two sets of rapidities satisfying the Bethe equations (10) and such that  $\mu_j \neq \lambda_k$ ,  $\forall j=1,\ldots,N, \forall k=1,\ldots,N+R$ . Then, our result reads

$$\langle 0 | \prod_{j=1}^{N} C(\mu_{j}) \Psi^{R}(0) \prod_{j=1}^{N+R} \mathcal{B}(\lambda_{j}) | 0 \rangle = \frac{(i\sqrt{c})^{R}}{c^{2R-1}(R-1)!} (-1)^{N(R-1)} \prod_{j,k=1}^{N+R} (\lambda_{jk} + ic)$$

$$\times \prod_{j=1}^{N+R} \prod_{k=1}^{N} \frac{1}{\lambda_{j} - \mu_{k}} \prod_{j=1}^{N+R} \left( \widetilde{V}_{R,j}^{+} - \widetilde{V}_{R,j}^{-} \right) \frac{\det_{N+R} \left( \delta_{jk} + \widetilde{U}_{jk}^{(R)} \right)}{\left( \widetilde{V}_{R,p}^{+} - \widetilde{V}_{R,p}^{-} \right) \left( \widetilde{V}_{R,s}^{+} - \widetilde{V}_{R,s}^{-} \right)} , \qquad (27)$$

where again  $\mathcal{B}$ ,  $\mathcal{C}$  are defined in (12),  $\lambda_{jk} = \lambda_j - \lambda_k$  and

$$\widetilde{V}_{R,j}^{\pm} = \frac{\prod_{m=1}^{N} \mu_m - \lambda_j \pm ic}{\prod_{m=1}^{N+R} \lambda_m - \lambda_j \pm ic} \,, \tag{28}$$

$$\widetilde{U}_{jk}^{(R)} = \frac{i}{\widetilde{V}_{R,j}^{+} - \widetilde{V}_{R,j}^{-}} \frac{\prod_{m=1}^{N} (\mu_m - \lambda_j)}{\prod_{\substack{m=1 \ m \neq j}}^{N+R} (\lambda_m - \lambda_j)} \left[ K(\lambda_j, \lambda_k) - K(\lambda_p, \lambda_k) K(\lambda_s, \lambda_j) \right] . \tag{29}$$

In the above expression  $K(\lambda, \mu)$  is given in (15) and  $\lambda_p$ ,  $\lambda_s$  are again two arbitrary complex parameters not necessarily in the set  $\{\lambda_j\}_{j=1}^{N+R}$ . As before, (27) does not depend on  $\lambda_p$  and  $\lambda_s$ .

Note that the form factor of  $\Psi(0)$  was first computed in [15], and a simplified expression for it was given in [16]. Using the techniques discussed in the next section, it is not difficult to see that the expression presented in [16] is equivalent to the case R=1 of equation (27).

#### 3.3. Equivalent formulas

Equation (22) can be cast in different equivalent forms. We give two of them in the following, which are derived in Appendix E.

First, suppose that the two Bethe states have different momentum  $P_{\lambda} \neq P_{\mu}$ . Then (22) can be rewritten as

$$\langle 0 | \prod_{j=1}^{N} \mathcal{C}(\mu_{j}) (\Psi^{\dagger}(0))^{2} \Psi^{2}(0) \prod_{j=1}^{N} \mathcal{B}(\lambda_{j}) | 0 \rangle \Big|_{P_{\lambda} \neq P_{\mu}} = (-1)^{N+1} \frac{i\mathcal{J}}{6c(P_{\lambda} - P_{\mu})}$$

$$\times \prod_{j,k=1}^{N} (\lambda_{jk} + ic) \prod_{j=1}^{N} \prod_{k=1}^{N} \frac{1}{(\lambda_{j} - \mu_{k})} \prod_{j=1}^{N} (V_{j}^{+} - V_{j}^{-}) \frac{\det_{N} \left(\delta_{jk} + U_{jk}^{(1)}\right)}{V_{p}^{+} - V_{p}^{-}} , \qquad (30)$$

where  $\lambda_p$  is again an arbitrary complex parameter,  $\lambda_{jk} = \lambda_j - \lambda_k$  and

$$U_{jk}^{(1)} = \frac{i}{V_j^+ - V_j^-} \frac{\prod_{m=1}^N (\mu_m - \lambda_j)}{\prod_{m \neq j}^N (\lambda_m - \lambda_j)} [K(\lambda_j, \lambda_k) - K(\lambda_p, \lambda_k)],$$
(31)

and where  $K(\lambda, \mu)$ ,  $V_j^{\pm}$ ,  $\mathcal{J}$ ,  $P_{\lambda}$  are defined respectively in (15), (23), (25), (26). Note that  $U_{jk}^{(1)}$  is the same matrix appearing in the form factor of the density operator  $\Psi^{\dagger}(0)\Psi(0)$  as first derived in [17].

Consider now the case where the two Bethe states have equal momentum  $P_{\lambda}=P_{\mu}$ . Then (22) can be rewritten as

$$\langle 0 | \prod_{j=1}^{N} \mathcal{C}(\mu_{j}) (\Psi^{\dagger}(0))^{2} \Psi^{2}(0) \prod_{j=1}^{N} \mathcal{B}(\lambda_{j}) | 0 \rangle \Big|_{P_{\lambda} = P_{\mu}} = (-1)^{N+1} \frac{i(E_{\lambda} - E_{\mu})^{2}}{2Nc}$$

$$\times \prod_{j,k=1}^{N} (\lambda_{jk} + ic) \prod_{j=1}^{N} \prod_{k=1}^{N} \frac{1}{(\lambda_{j} - \mu_{k})} \prod_{j=1}^{N} (V_{j}^{+} - V_{j}^{-}) \frac{\det_{N} \left(\delta_{jk} + U_{jk}^{(2)}\right)}{V_{p}^{+} - V_{p}^{-}} , \qquad (32)$$

where  $\lambda_p$  is an arbitrary complex parameter,  $\lambda_{jk} = \lambda_j - \lambda_k$  and

$$U_{jk}^{(2)} = \frac{i}{V_j^+ - V_j^-} \frac{\prod_{m=1}^N (\mu_m - \lambda_j)}{\prod_{m \neq j}^N (\lambda_m - \lambda_j)} [K(\lambda_j, \lambda_k) - K(\lambda_p, \lambda_k)] + \frac{i}{V_j^+ - V_j^-} K(\lambda_p, \lambda_k) , \quad (33)$$

and where  $K(\lambda, \mu)$ ,  $E_{\lambda}$  are given in (15), (26) respectively.

We stress again that equations (22), (27), (30), (32) are valid only for sets of rapidities  $\{\mu_j\}$ ,  $\{\lambda_j\}$  satisfying the Bethe equations (10) and such that  $\mu_j \neq \lambda_k \ \forall j, k$ . In particular, our formulas cannot be used for the computation of expectation values (corresponding to the case  $\{\mu_j\}_{j=1}^N = \{\lambda_j\}_{j=1}^N$ ).

### *3.4. Numerical checks and discussions*

All the formulas presented in this work have been numerically checked against exact computations for a small number of particles. We remind that the form factors (21) can be computed, for small values of N, by repeated action of the field (17) on Bethe states. We exploited this property and we numerically computed the form factors of Ψ<sup>R</sup>(0) for R = 1, 2, 3, 4, 5 and for a number of particles up to N + R = 9. This procedure gives the same result of our formula (27). Formulas (22), (30), (32) for the form factor of (Ψ† (0))<sup>2</sup>Ψ<sup>2</sup> (0) have been checked numerically for a number of particles up to N = 9 by comparison with the formulas presented in [25] and we found perfect agreement between the two.

The determinant formulas presented in this work are very convenient for numerical calculations. In particular, equation (32) was recently used in Ref. [34] for a study of the relaxation dynamics of local observables following a quantum quench in the Lieb-Liniger model. In this work, within the quench action method [26], the exact time evolution of the normal ordered observable : ˆρ 2 (0) : (where ρˆ is the density operator) was computed for systems with a number of particles up to N = 96.

A possible (straightforward) application of equation (27) is given by the numerical computation of the class of form factors (Ψ† (0))<sup>K</sup>Ψ<sup>K</sup>(0) through a single resolution of the identity, both in the repulsive and the attractive case (see section 5). This can be done very efficiently for example using the so called ABACUS algorithm [18, 20, 53, 54]

The formulas presented in section 3 are also suitable for non-trivial analytical calculations as those performed in [50, 51]. In these works the form factors of the operators Ψ(0), Ψ† (0)Ψ(0) were computed in the thermodynamic limit, starting from the corresponding finite size formulas derived in [15, 16, 17].

Finally, we comment on the fact that equations (22), (27), (30), (32) are valid only for sets of rapidities {µj}, {λj} with µ<sup>j</sup> 6= λ<sup>k</sup> ∀j, k. Note that even if two sets {µj}, {λj} correspond to different Bethe states, it might be that µ<sup>j</sup> = λ<sup>k</sup> for some j, k. However, this will not happen in general because of the constrains imposed by the Bethe equations. One case where this happens is given by two different parity invariant sets of rapidities with an odd number of particles {µj} 2K+1 <sup>j</sup>=1 = {−µj} 2K+1 <sup>j</sup>=1 , {λj} 2K+1 <sup>j</sup>=1 = {−λj} 2K+1 <sup>j</sup>=1 (K being a positive integer). In this case, even if {µj} 6= {λj} the value 0 belongs to both sets of rapidities and our formulas don't apply. This however is a well-known issue true for on-shell form factors (see e.g. [16, 17]) and it is not a limitation in practice when computing correlation functions since one can restrict to even numbers of particles as done in [34].

Form factors for Bethe states corresponding to sets {µj}, {λj} where µ<sup>j</sup> = λ<sup>k</sup> for some j, k cannot be obtained as the limit λ<sup>j</sup> → µ<sup>k</sup> directly from formulas (22) (27). In particular, our formulas cannot be used to compute the expectation value of the operator (Ψ† (0))<sup>2</sup>Ψ<sup>2</sup> (0). This is because all the formulas presented in this work are valid for on-shell rapidities, while one should start from an off-shell expression in order to obtain a meaningful result also in the limit of coinciding rapidities λ<sup>j</sup> → µk, for some j, k.

#### 4. Properties of the form factors and proof of the determinant formulas

In this section we derive the formulas presented above. For the sake of clarity, some of the proofs will be given in the appendices. We begin with some general considerations.

From (12), (17) and (18) it is clear that the form factors in (21) depend only on the rapidities  $\{\mu_j\}_{j=1}^N$ ,  $\{\lambda_j\}_{j=1}^M$ , and on  $\{r(\mu_j)\}_{j=1}^N$ ,  $\{r(\lambda_j)\}_{j=1}^M$ , i.e. the values of  $r(\lambda)$  evaluated at the rapidities. We can thus define the following function

$$\mathcal{G}_{N,M}^{h,k}(\{\mu_j\}, \{\lambda_j\}, \{r(\mu_j)\}, \{r(\lambda_j)\}) = \langle 0 | \prod_{j=1}^{N} \mathcal{C}(\mu_j) (\Psi^{\dagger}(0))^h \Psi^k(0) \prod_{j=1}^{M} \mathcal{B}(\lambda_j) | 0 \rangle . \tag{34}$$

In the ABA approach  $r(\lambda)$  can be considered as a functional parameter. Indeed one could expand the form factor (34) using relations (17) and (18) to obtain a formal expression where  $r(\lambda)$  is kept as a functional variable. The Lieb-Liniger model results for the form factors are recovered by making a specific choice of the function  $r(\lambda)$ . In particular, we can choose  $r(\lambda)$  in such a way that

$$r(\lambda_i) = e^{-iL\lambda_j} , \qquad r(\mu_i) = e^{-iL\mu_j} , \qquad (35)$$

consistently with (8). However, one can make also another choice for the function  $r(\lambda)$  which is as follows. First, define the following function of x, depending on the parameters  $\{\lambda_k\}_{k=1}^N$ 

$$\vartheta_N(\{\lambda_k\};x) = -\prod_{k=1}^N \frac{\lambda_k - x + ic}{\lambda_k - x - ic}.$$
(36)

Then, one can choose the functional parameter  $r(\lambda)$  in such a way that

$$r(\lambda_j) = \vartheta_N(\{\lambda_k\}; \lambda_j) = \prod_{\substack{k=1\\k \neq j}}^N \frac{\lambda_k - \lambda_j + ic}{\lambda_k - \lambda_j - ic},$$
(37)

$$r(\mu_j) = \vartheta_M(\{\mu_k\}; \mu_j) = \prod_{\substack{k=1\\k \neq j}}^M \frac{\mu_k - \mu_j + ic}{\mu_k - \mu_j - ic}.$$
 (38)

Of course, the two definitions (35) and (37), (38) are equivalent if the sets  $\{\lambda_j\}$ ,  $\{\mu_j\}$  satisfy the Bethe equations (10), but for arbitrary rapidities they are not.

Suppose we choose (37) and (38). Then the expression for the form factor becomes a rational function of the rapidities only (that is, no dependence on the functional parameter  $r(\lambda)$  remaining). We can then define

$$\mathcal{F}_{N,M}^{h,k}(\{\mu_k\},\{\lambda_k\}) = \mathcal{G}_{N,M}^{h,k}(\{\mu_k\},\{\lambda_k\},\{r(\mu_j)\},\{r(\lambda_j)\}) \Big|_{\substack{\{r(\mu_j)\} = \{\vartheta_M(\{\mu_k\},\ \mu_j)\}\\\{r(\lambda_j)\} = \{\vartheta_N(\{\lambda_k\},\ \lambda_j)\}}},$$
(39)

where  $\mathcal{G}_{N,M}^{h,k}$  is give in (34). We henceforth focus on the function  $\mathcal{F}_{N,M}^{h,k}$ . We stress again that this function is defined for arbitrary values of the rapidities, even though it is physically relevant only for those satisfying the Bethe equations (10).

We are now ready to present the main ingredient in our derivation of the formulas presented in section 3. It is given by the following proposition regarding some fundamental properties of the form factors of local operators [5, 25, 48, 49, 55, 52].

**Proposition 1** Consider the function  $\mathcal{F}_{N,M}^{h,k}$  defined in (39) (with  $0 \le h \le N$ ,  $0 \le k \le M$ ). Then the following properties hold

(i) 
$$\mathcal{F}_{h,k}^{h,k}(\{\mu_j\}_{j=1}^h, \{\lambda_j\}_{j=1}^k) = (-i)^{k-h}(\sqrt{c})^{k+h}h!k!;$$
 (40)

(ii) consider  $\mu_m \in \{\mu_j\}_{j=1}^N$ ; then the asymptotic behavior of  $\mathcal{F}_{N,M}^{h,k}$  as a function of  $\mu_m$  is given as follows

$$\lim_{\mu_m \to \infty} \mathcal{F}_{N,M}^{h,k}(\{\mu_j\}, \{\lambda_j\}) = \begin{cases} 0, & h = 0, \\ (i\sqrt{c})h\mathcal{F}_{N-1,M}^{h-1,k}(\{\mu_j\}_{j \neq m}, \{\lambda_j\}), & h > 0; \end{cases}$$
(41)

- (iii) consider  $\mathcal{F}_{N,M}^{h,k}(\{\mu_j\}, \{\lambda_j\})$  as a function of  $\mu_m \in \{\mu_j\}_{j=1}^N$ . Then it is a rational function and its only singularities are first order poles at  $\mu_m = \lambda_j$ , j = 1, ... M;
- (iv) the residues of the form factors are given by the following recursive relations

$$\mathcal{F}_{N,M}^{h,k}(\{\mu_{j}\}_{j=1}^{N}, \{\lambda_{j}\}_{j=1}^{M})\Big|_{\mu_{m} \to \lambda_{k}} \sim g(\mu_{m}, \lambda_{k}) \\
\times \left[ \prod_{\substack{j=1 \ j \neq m}}^{N} f(\mu_{j}, \mu_{m}) \prod_{\substack{j=1 \ j \neq k}}^{M} f(\lambda_{k}, \lambda_{j}) - \prod_{\substack{j=1 \ j \neq k}}^{M} f(\lambda_{j}, \lambda_{k}) \prod_{\substack{j=1 \ j \neq m}}^{N} f(\mu_{m}, \mu_{j}) \right]$$

$$\times \left[ \prod_{\substack{j=1\\j\neq m}} f(\mu_{j}, \mu_{m}) \prod_{\substack{j=1\\j\neq k}} f(\lambda_{k}, \lambda_{j}) - \prod_{\substack{j=1\\j\neq k}} f(\lambda_{j}, \lambda_{k}) \prod_{\substack{j=1\\j\neq m}} f(\mu_{m}, \mu_{j}) \right]$$

$$\mathcal{F}_{N-1, M-1}^{h, k} (\{\mu_{j}\}_{j\neq m}, \{\lambda_{j}\}_{j\neq k}) . (42)$$

Properties 1-4 are well known in the theory of Algebraic Bethe Ansatz. For completeness, we present their derivation in Appendix A.

Note that the recursive relation (42), first derived in [55], was also discussed in the recent papers [48, 49, 52]. In particular, in [48, 49] its connection with recursive relations appearing in integrable quantum field theory were investigated.

Our strategy for deriving the formulas presented in the previous section is very simple. As a first step we show that properties 1-4 of Prop. 1 uniquely determine the on-shell form factors (39). As a second step, we prove that the determinant formulas of section 3 satisfy these properties. Note that a similar approach was used in Ref. [52] for the study of local operators in nested Bethe Ansatz systems.

The first step of our derivation is given by the following proposition.

**Proposition 2** Let h, k be two fixed integers, with h, k > 0, and consider a family of functions  $\{\mathcal{H}_{N,M} = \mathcal{H}_{N,M}(\{\mu_j\}_{j=1}^N, \{\lambda_j\}_{j=1}^M)\}$  depending on two integers N, M, with N-h = M-k. Suppose that  $\mathcal{H}_{N,M}$  satisfies properties 1-4 of Prop. 1 for every  $N \geq h$ ,  $M \geq k$ . To be more precise, suppose that, for the given value of h, k the following hold

(i) 
$$\mathcal{H}_{h,k}(\{\mu_j\}_{j=1}^h, \{\lambda_j\}_{j=1}^k) = (-i)^{k-h}(\sqrt{c})^{k+h}h!k!;$$
 (43)

(ii) 
$$\lim_{\mu_m \to \infty} \mathcal{H}_{N,M}(\{\mu_j\}, \{\lambda_j\}) = \begin{cases} 0, & h = 0, \\ (i\sqrt{c})h\mathcal{F}_{N-1,M}^{h-1,k}(\{\mu_j\}_{j \neq m}, \{\lambda_j\}), & h > 0; \end{cases}$$
(44)

- (iii)  $\mathcal{H}_{N,M}(\{\mu_j\},\{\lambda_j\})$  as a function of  $\mu_m \in \{\mu_j\}_{j=1}^N$  is a rational function and its only singularities are first order poles at  $\mu_m = \lambda_j$ , j = 1, ... M;
- (iv) the residues are given by the following recursive relations

$$\mathcal{H}_{N,M}(\{\mu_{j}\}_{j=1}^{N}, \{\lambda_{j}\}_{j=1}^{M})\Big|_{\mu_{m} \to \lambda_{k}} \sim g(\mu_{m}, \lambda_{k})$$

$$\times \left[ \prod_{\substack{j=1\\j \neq m}}^{N} f(\mu_{j}, \mu_{m}) \prod_{\substack{j=1\\j \neq k}}^{M} f(\lambda_{k}, \lambda_{j}) - \prod_{\substack{j=1\\j \neq k}}^{M} f(\lambda_{j}, \lambda_{k}) \prod_{\substack{j=1\\j \neq m}}^{N} f(\mu_{m}, \mu_{j}) \right]$$

$$\times \mathcal{H}_{N-1,M-1}(\{\mu_{j}\}_{j \neq m}, \{\lambda_{j}\}_{j \neq k}) . \tag{45}$$

Then

$$\mathcal{H}_{N,M}(\{\mu_j\}_{j=1}^N, \{\lambda_j\}_{j=1}^M) = \mathcal{F}_{N,M}^{h,k}(\{\mu_j\}_{j=1}^N, \{\lambda_j\}_{j=1}^M).$$
(46)

We present the proof of this proposition in Appendix B. This proof closely follows the one given by Slavnov in [56] for the scalar product formula between on-shell and off-shell Bethe states.

In order to prove the formulas presented in section 3, all we need to do is then to show that they indeed satisfy the properties 1-4 of Prop. 1. This is done in the following, where we separately consider the cases of the form factors of  $\Psi^R(0)$  and of  $(\Psi^{\dagger}(0))^2(\Psi^2(0))$ .

# 4.1. Form factor of $\Psi^R(0)$

Define the rational function  $\mathcal{H_R}(\{\mu_j\}_{j=1}^N,\{\lambda_j\}_{j=1}^{N+R})$  as

$$\mathcal{H}_{\mathcal{R}}(\{\mu_{j}\}, \{\lambda_{j}\}) = \frac{(i\sqrt{c})^{R}}{c^{2R-1}(R-1)!} (-1)^{N(R-1)} \prod_{j,k=1}^{N+R} (\lambda_{jk} + ic)$$

$$\times \prod_{j=1}^{N+R} \prod_{k=1}^{N} \frac{1}{\lambda_{j} - \mu_{k}} \prod_{j=1}^{N+R} \left( \widetilde{V}_{R,j}^{+} - \widetilde{V}_{R,j}^{-} \right) \frac{\det_{N+R} \left( \delta_{jk} + \widetilde{U}_{jk}^{(R)} \right)}{\left( \widetilde{V}_{R,p}^{+} - \widetilde{V}_{R,p}^{-} \right) \left( \widetilde{V}_{R,s}^{+} - \widetilde{V}_{R,s}^{-} \right)} ,$$

$$(47)$$

where  $\widetilde{V}_{R,j}^{\pm}$ ,  $\widetilde{U}_{jk}^{(R)}$  are given in (28) and (29). Before showing that (47) gives the correct expression for the form factors of  $\Psi^R(0)$ , hence proving (27), we briefly discuss some properties of the function  $\mathcal{H}_R$ .

The matrix  $\delta_{jk} + \widetilde{U}_{jk}^{(R)}$  in (47) has a similar structure to those appearing in the formulas for the form factors of  $\Psi(0)$  and  $\Psi^{\dagger}(0)\Psi(0)$  as computed in [15, 16, 17]. When studying the properties of the determinant of such matrices, a set of identities regarding the sum of rational functions are important [17, 57]. For completeness we discuss them in Appendix D.

Using these identities, it is easy to prove for example that  $\mathcal{H}_R$  does not depend on the parameters  $\lambda_p$  and  $\lambda_s$ . This is done in the following way. Define for convenience

$$\Xi_{j}^{(R)} = \frac{\prod_{k=1}^{N} (\mu_{k} - \lambda_{j})}{\prod_{\substack{k=1 \ k \neq j}}^{N+R} (\lambda_{k} - \lambda_{j})}, \qquad \Theta_{j}^{(R)} = \widetilde{V}_{R,j}^{+} - \widetilde{V}_{R,j}^{-}.$$

$$(48)$$

For  $k=2,\ldots,N+R$  add to the first column of the matrix  $\delta_{jk}+\widetilde{U}_{jk}^{(R)}$  column k multiplied by  $\Xi_k^{(R)}/\Xi_1^{(R)}$ . From identity (D.1) in Appendix D it follows that the first column becomes

proportional to  $\widetilde{V}_{R,p}^+ - \widetilde{V}_{R,p}^-$ . Exploiting the multilinearity of the determinant we get

$$\frac{\det_{N+R} \left( \delta_{jk} + \widetilde{U}_{jk}^{(R)} \right)}{\widetilde{V}_{R,p}^{+} - \widetilde{V}_{R,p}^{-}} = \frac{\det_{N+R} \left( \mathcal{M}_{jk}^{(R)} \right)}{\Xi_{1}^{(R)}}, \tag{49}$$

where

$$\mathcal{M}_{jk}^{(R)} = \begin{cases} \Xi_j^{(R)} \frac{K(\lambda_s, \lambda_j)}{\widetilde{V}_{R,j}^+ - \widetilde{V}_{R,j}^-}, & \text{if } k = 1, \\ \delta_{jk} + \widetilde{U}_{jk}^{(R)}, & \text{otherwise}. \end{cases}$$
(50)

Now, for  $k=2,\ldots,N+R$ , add to column k of matrix  $\mathcal{M}_{jk}^{(R)}$  column 1 multiplied by  $iK(\lambda_p,\lambda_k)$ . Exploiting again the multilinearity of the determinant we get

$$\det_{N+R} \left( \mathcal{M}_{jk}^{(R)} \right) = \det_{N+R} \left( \widetilde{\mathcal{M}}_{jk}^{(R)} \right) , \qquad (51)$$

where

$$\widetilde{\mathcal{M}}_{jk}^{(R)} = \begin{cases} \Xi_j^{(R)} \frac{K(\lambda_s, \lambda_j)}{\widetilde{V}_{R,j}^+ - \widetilde{V}_{R,j}^-}, & \text{if } k = 1, \\ \delta_{jk} + \frac{i}{\widetilde{V}_{R,j}^+ - \widetilde{V}_{R,j}^-} \Xi_j^{(R)} K(\lambda_j, \lambda_k), & \text{otherwise}. \end{cases}$$
(52)

In the final expression (52)  $\lambda_p$  has disappeared: we conclude that the l.h.s. of (49) and thus  $\mathcal{H}_R$  in (47) are independent of the parameter  $\lambda_p$ .

To show that  $\mathcal{H}_R$  does not depend on  $\lambda_s$  we proceed as follows. For  $j=2,\ldots,N+R$  add to the first row of the matrix  $\delta_{jk}+\widetilde{U}_{jk}^{(R)}$  row j multiplied by  $\Theta_j^{(R)}/\Theta_1^{(R)}$ . Using again (D.1) of Appendix D, we see that the first row becomes proportional to  $\widetilde{V}_{R,s}^+-\widetilde{V}_{R,s}^-$ . We can then follow a similar procedure to the one used before to conclude that  $\mathcal{H}_R$  does not depend on  $\lambda_s$  either. In a similar fashion, one can prove that the r.h.s. of (22) is independent of both  $\lambda_s$  and  $\lambda_p$ .

We stress here that with the above procedure we also immediately see that  $\mathcal{H}_R$ , as a function of the parameter  $\mu_m$ , does not have poles corresponding to the zeroes of  $(\widetilde{V}_{R,p}^+ - \widetilde{V}_{R,p}^-)$  and  $(\widetilde{V}_{R,s}^+ - \widetilde{V}_{R,s}^-)$ , since these factors are canceled by the determinant in the numerator in the r.h.s. of Eq. (47).

We shall now show that  $\mathcal{H}_R$  satisfies properties 1-4 of Prop. 1. We begin with property 1 namely that  $\mathcal{H}_R(\emptyset, \{\lambda_j\}_{j=1}^R) = (-i\sqrt{c})^R R!$ . Using definition (47) our goal is to prove that

$$\frac{(i\sqrt{c})^R}{c^{2R-1}(R-1)!} \prod_{j,k=1}^R (\lambda_{jk} + ic) \frac{\prod_{j=1}^R (\widetilde{V}_{R,j}^+ - \widetilde{V}_{R,j}^-) \det_R(\delta_{jk} + \widetilde{U}_{jk}^{(R)})}{(\widetilde{V}_{R,p}^+ - \widetilde{V}_{R,p}^-)(\widetilde{V}_{R,s}^+ - \widetilde{V}_{R,s}^-)} = (-i\sqrt{c})^R R!,$$
 (53)

where  $\widetilde{V}_{R,j}^{\pm}$  and  $\widetilde{U}_{jk}^{(R)}$  are given in (28), (29). This can be seen by induction.

The case R=1 is trivial by direct computation. Supposing now equation (53) is true for  $R-1\geq 1$  we show that it is also true for R. Using simple manipulations and the identities discussed in Appendix D, it is not difficult to see that the l.h.s. of (53) as a function of  $\lambda_R$  does not have poles, and it is bounded at infinity. Thus, as a consequence of Liouville theorem in complex analysis, it is a constant. In order to determine this constant, we compute the limit  $\lambda_R \to \infty$  of the l.h.s. of (53).

From (29) we see that  $\det_R(\delta_{jk} + \widetilde{U}_{jk}^{(R)}) \propto 1/\lambda_R^2$  as  $\lambda_R \to \infty$ . Expand now the determinant of the matrix  $\delta_{jk} + \widetilde{U}_{jk}^{(R)}$  along the last row using Laplace expansion:

$$\det_{R} \left( \delta_{jk} + \widetilde{U}_{jk}^{(R)} \right) = \sum_{k=1}^{R-1} (-1)^{R+k} \widetilde{U}_{R,k}^{(R)} \det_{R-1}(\mathcal{A}_{k}) + (1 + \widetilde{U}_{R,R}^{(R)}) \det_{R-1}(\mathcal{A}_{R}) , \qquad (54)$$

where  $\mathcal{A}_j$  is the  $(N-1)\times (N-1)$  matrix obtained by removing the last row and column j from the matrix  $\delta_{jk}+\widetilde{U}_{jk}^{(R)}$ . Using definition (29) we see that  $\widetilde{U}_{R,k}^{(R)}\propto 1/\lambda_R^2$  as  $\lambda_R\to\infty$ . However, for  $k=1,\ldots,R-1$  the matrix  $\mathcal{A}_k$  contains the column  $(\widetilde{U}_{1,R}^{(R)},\ldots,\widetilde{U}_{R-1,R}^{(R)})^t$ . Since  $\widetilde{U}_{j,R}^{(R)}\propto 1/(\lambda_R)^2$ , and  $\widetilde{U}_{jk}^{(R)}=\mathcal{O}(1)$  for  $j,k,\neq R$  we see that all the terms in (54) are of order  $\mathcal{O}(1/\lambda_R)^4$  except for the last one. So

$$\det_{R} \left( \delta_{jk} + \widetilde{U}_{jk}^{(R)} \right) \sim \left( 1 + \widetilde{U}_{R,R}^{(R)} \right) \det_{R-1} \left( \delta_{jk} + \widetilde{U}_{jk}^{(R-1)} \right), \quad \text{for } \lambda_{R} \to \infty.$$
 (55)

From the definition (28), (29) the following expansions are given by straightforward calculations

$$1 + \widetilde{U}_{RR}^{(R)} = -\frac{1}{\lambda_R^2} \frac{R(R-1)}{2} c^2 + \mathcal{O}(1/\lambda_R^4) , \qquad (56)$$

$$\widetilde{V}_{R,R}^{+} - \widetilde{V}_{R,R}^{-} = (-1)^{R} \frac{2i}{c\lambda_{R}^{R-1}} + \mathcal{O}(1/\lambda_{R}^{R}) , \qquad (57)$$

and also

$$\prod_{j,k=1}^{R} (\lambda_{jk} + ic) \frac{\prod_{j=1}^{R-1} \left( \widetilde{V}_{R,j}^{+} - \widetilde{V}_{R,j}^{-} \right)}{\left( \widetilde{V}_{R,p}^{+} - \widetilde{V}_{R,p}^{-} \right) \left( \widetilde{V}_{R,s}^{+} - \widetilde{V}_{R,s}^{-} \right)} = (-1)^{R-1} ic$$

$$\times \lambda_{R}^{R+1} \prod_{j,k=1}^{R-1} (\lambda_{jk} + ic) \frac{\prod_{j=1}^{R-1} \left( \widetilde{V}_{R-1,j}^{+} - \widetilde{V}_{R-1,j}^{-} \right)}{\left( \widetilde{V}_{R-1,p}^{+} - \widetilde{V}_{R-1,p}^{-} \right) \left( \widetilde{V}_{R-1,s}^{+} - \widetilde{V}_{R-1,s}^{-} \right)} + \mathcal{O}(\lambda_{R}^{R}) .$$
(58)

Using (56), (57), (58) and the inductive hypothesis for R-1 we finally have

$$\lim_{\lambda_{R} \to \infty} \frac{(i\sqrt{c})^{R}}{c^{2R-1}(R-1)!} \prod_{j,k=1}^{R} (\lambda_{jk} + ic) \prod_{j=1}^{R} \left( \widetilde{V}_{R,j}^{+} - \widetilde{V}_{R,j}^{-} \right) \times \frac{\det_{R} \left( \delta_{jk} + \widetilde{U}_{jk}^{(R)} \right)}{\left( \widetilde{V}_{R,p}^{+} - \widetilde{V}_{R,p}^{-} \right) \left( \widetilde{V}_{R,s}^{+} - \widetilde{V}_{R,s}^{-} \right)} = (-i\sqrt{c})^{R} R! .$$
(59)

The first property of Prop. 1 is thus proven. To see that the second is true, it is sufficient to observe that

$$\mathcal{H}_R(\{\mu_j\}, \{\lambda_j\}) \propto \frac{1}{\mu_m^2} \to 0 , \quad \text{for } \mu_m \to \infty .$$
 (60)

Furthermore, property 3 is easily seen to be satisfied using simple manipulations and the identities discussed in Appendix D.

Finally, we address property 4. It is enough to consider the case  $\mu_N \to \lambda_{N+R}$  because  $\mathcal{H}_R$  is completely symmetric in the sets  $\{\mu_k\}$  and  $\{\lambda_k\}$ . Define in the following M=N+R.

In the limit  $\mu_N \to \lambda_M$  the last row of the matrix  $\delta_{jk} + \widetilde{U}_{jk}^{(R)}$  becomes  $(0,0,\dots,0,1)$  so it is straightforward to compute

$$\lim_{\mu_{N} \to \lambda_{M}} \mathcal{H}_{\mathcal{R}}(\{\mu_{j}\}, \{\lambda_{j}\}) = g(\mu_{N}, \lambda_{M})$$

$$\times \left[ \prod_{j=1}^{N-1} f(\mu_{j}, \mu_{N}) \prod_{j=1}^{M-1} f(\lambda_{M}, \lambda_{j}) - \prod_{j=1}^{M-1} f(\lambda_{j}, \lambda_{M}) \prod_{j=1}^{N-1} f(\mu_{N}, \mu_{j}) \right] \frac{(i\sqrt{c})^{R}}{c^{2R-1}(R-1)!}$$

$$\times (-1)^{(N-1)(R-1)} \prod_{j,k=1}^{M-1} (\lambda_{jk} + ic) \prod_{j=1}^{M-1} \prod_{k=1}^{N-1} \frac{1}{\lambda_{j} - \mu_{k}} \prod_{j=1}^{M-1} \left( \widetilde{V}_{R,j}^{+} - \widetilde{V}_{R,j}^{-} \right)$$

$$\times \frac{1}{\left( \widetilde{V}_{R,p}^{+} - \widetilde{V}_{R,p}^{-} \right) \left( \widetilde{V}_{R,s}^{+} - \widetilde{V}_{R,s}^{-} \right)} \det_{M-1} \left( \delta_{jk} + \widetilde{U}_{jk}^{(R)} \right). \tag{61}$$

where  $\widetilde{V}_{R,j}^{\pm}$  and  $U_{jk}^{(R)}$  are defined in (28), (29) for the sets of rapidities  $\{\mu_j\}_{j=1}^{N-1}$ ,  $\{\lambda_j\}_{j=1}^{M-1}$ . We have thus shown that the function  $\mathcal{H}_R$  satisfies all the properties of Prop. 1 and, as a consequence of Prop. 2, that equation (27) is correct.

# 4.2. Form factor of $(\Psi^{\dagger}(0))^2\Psi^2(0)$

We now show that the determinant formula in (22) satisfies properties 1-4 of Prop. 1.

The form factor of  $(\Psi^{\dagger}(0))^2\Psi^2(0)$  corresponds to the case (h,k)=(2,2) of the general formula (39). Looking at property 2 of Prop. 1 wee see that in order to prove the validity of (22) we also need an expression for the form factor corresponding to the operator  $\Psi^{\dagger}(0)\Psi^2(0)$ , which we give now. Let  $\{\mu_j\}_{j=1}^N$ ,  $\{\lambda_j\}_{j=1}^{N+1}$  be two sets of rapidities satisfying the Bethe equations (10). The form factor of the operator  $\Psi^{\dagger}(0)\Psi^2(0)$  is

$$\langle 0 | \prod_{j=1}^{N} C(\mu_{j}) \Psi^{\dagger}(0) \Psi^{2}(0) \prod_{j=1}^{N+1} \mathcal{B}(\lambda_{j}) | 0 \rangle = -i \frac{\mathcal{T}}{c\sqrt{c}} \prod_{j,k=1}^{N+1} (\lambda_{jk} + ic)$$

$$\times \prod_{j=1}^{N+1} \prod_{k=1}^{N} \frac{1}{\lambda_{j} - \mu_{k}} \prod_{j=1}^{N+1} \left( \widetilde{V}_{1,j}^{+} - \widetilde{V}_{1,j}^{-} \right) \frac{\det_{N+1} \left( \delta_{jk} + \widetilde{U}_{jk}^{(1)} \right)}{\left( \widetilde{V}_{1,p}^{+} - \widetilde{V}_{1,p}^{-} \right) \left( \widetilde{V}_{1,s}^{+} - \widetilde{V}_{1,s}^{-} \right)},$$
(62)

where as usual  $\mathcal{B}$ ,  $\mathcal{C}$  are defined in (12) and  $\lambda_{jk} = \lambda_j - \lambda_k$ . In the above  $\widetilde{V}_{1,j}^{\pm}$ ,  $\widetilde{U}_{jk}^{(1)}$  are given respectively in (28) and (29) (for R = 1) while

$$\mathcal{T} = \frac{1}{2} \left[ (P_{\lambda} - P_{\mu})^2 - (E_{\lambda} - E_{\mu}) \right] , \tag{63}$$

where  $P_{\lambda}$ ,  $E_{\lambda}$  are defined in (26).

Formula (62) can be proven using the same strategy of the previous subsection. In particular, one needs to show that (62) satisfies properties 1-4 of Prop. 1. It is now straightforward to check property 1, while one proceeds in the same way of the previous subsection to see that properties 3 and 4 are valid. We address property 2. First, note that the following expansions are valid for  $\mu_N \to \infty$ 

$$\frac{\prod_{m=1}^{N} \mu_m - \lambda_j \pm ic}{\prod_{m=1}^{N+1} \lambda_m - \lambda_j \pm ic} \sim \mu_N \frac{\prod_{m=1}^{N-1} \mu_m - \lambda_j \pm ic}{\prod_{m=1}^{N+1} \lambda_m - \lambda_j \pm ic} + \mathcal{O}(1) , \qquad \mu_N \to \infty ,$$
(64)

Exact formulas for the form factors of local operators in the Lieb-Liniger model

$$\prod_{m=1}^{N} (\mu_m - \lambda_j) \sim \mu_N \prod_{m=1}^{N-1} (\mu_m - \lambda_j) + \mathcal{O}(1) , \qquad \mu_N \to \infty ,$$
 (65)

15

$$\mathcal{T} \sim \mu_N^2 + \mathcal{O}(\mu_N) , \qquad \mu_N \to \infty .$$
 (66)

Using (64), (65) and (66) it is straightforward to compute

$$\lim_{\mu_N \to \infty} -i \frac{\mathcal{T}}{c\sqrt{c}} \prod_{j,k=1}^{N+1} (\lambda_{jk} + ic) \prod_{j=1}^{N+1} \prod_{k=1}^{N} \frac{1}{\lambda_j - \mu_k} \prod_{j=1}^{N+1} \left( \widetilde{V}_{1,j}^+ - \widetilde{V}_{1,j}^- \right) \times \frac{\det_{N+1} \left( \delta_{jk} + \widetilde{U}_{jk}^{(1)} \right)}{\left( \widetilde{V}_{1,p}^+ - \widetilde{V}_{1,p}^- \right) \left( \widetilde{V}_{1,s}^+ - \widetilde{V}_{1,s}^- \right)} = i\sqrt{c} \mathcal{H}_2(\{\mu_j\}_{j=1}^{N-1}, \{\lambda_j\}_{j=1}^{N+1}) .$$
(67)

where  $\mathcal{H}_2$  is given in (47) (for R=2). As we proved in the previous subsection

$$\mathcal{H}_2(\{\mu_j\}_{j=1}^{N-1}, \{\lambda_j\}_{j=1}^{N+1}) = \mathcal{F}_{N-1, N+1}^{0, 2}(\{\mu_j\}_{j=1}^{N-1}, \{\lambda_j\}_{j=1}^{N+1}), \tag{68}$$

so we see that property 2 of Prop 1 is satisfied by the r.h.s. of (62) which is thus correct.

We have now all the ingredients to prove formula (22) for the form factor of  $(\Psi^{\dagger}(0))^2\Psi^2(0)$ : one needs to apply the very same procedure just used to prove formula (62). The steps are the same as before and the calculations present no difficulty so we will not present them here.

### 5. Form factors in the attractive regime

In this section we specialise the form factors given in section 3 to the attractive Lieb-Liniger model (i.e. c < 0) when one of the two Bethe states is the ground state, since in this case major simplifications occur and the determinant can be carried out explicitly along the lines of [19]. We start by very briefly introducing the attractive Lieb-Liniger model and we refer to [2, 19] for all the necessary technical details.

We consider the Hamiltonian (1) in the case c < 0 and we define for convenience  $\overline{c} = -c > 0$ . With this choice, the Hamiltonian (1) describes a system of bosons with attractive interaction. The eigenstates are again in 1-to-1 correspondence with the sets of rapidities satisfying the Bethe equations which now read

$$e^{-i\lambda_j L} = \prod_{\substack{k=1\\k\neq j}}^N \frac{\lambda_k - \lambda_j - i\overline{c}}{\lambda_k - \lambda_j + i\overline{c}}.$$
 (69)

In the attractive regime equations (69) admit string solutions corresponding to bound states of bosons [19]. Here we focus on the case where all the N particles of the system form a unique bound state, namely a N-string. The rapidities forming a N-string solution arrange themselves in the following way

$$\lambda_j = \lambda + i\frac{\overline{c}}{2}(N+1-2j) + i\delta_j , \qquad (70)$$

where  $\lambda$  is a real parameter (the center of the string), and where  $\delta_j$  are small deviations vanishing in the limit where the length L is infinity and the number of particles N is kept fixed. The ground state of the system corresponds to a N-string centered at  $\lambda = 0$ .

Following [19] we now wish to obtain a simplified expression for the form factors presented in section 3 when one of the two Bethe states corresponds to the ground state of the attractive model in the limit of vanishing deviations. First, we consider the form factor of (Ψ† (0))<sup>2</sup>Ψ<sup>2</sup> (0). Let {µj} N <sup>j</sup>=1, {λj} N <sup>j</sup>=1 be two sets of rapidities both satisfying the Bethe equations (69), with {λj} corresponding to the ground state (instead the rapidities {µj} N j=1 do not need to form a N-string and correspond to an arbitrary excited state of the system). In a finite system the deviations δ<sup>j</sup> will be in general non vanishing and one can plug the rapidities (70) directly in the equation (22), since singular terms do not appear. Taking then the limit {δj} → 0 the determinant expression gets simplified. We report in Appendix C the calculations. The final result for the form factor (with |{λi}i being the ground state) is

$$\langle 0 | \prod_{j=1}^{N} \mathcal{C}(\mu_j) (\Psi^{\dagger}(0))^2 \Psi^2(0) \prod_{j=1}^{N} \mathcal{B}(\lambda_j) | 0 \rangle =$$
 (71)

$$(-1)^{N} \frac{c^{2(N-1)}}{6} \left[ P_{\mu}^{4} - 4P_{\mu}Q_{\mu} + 3\left(E_{\mu} + \frac{\overline{c}^{2}}{12}N(N^{2} - 1)\right)^{2} \right] \frac{N\Gamma^{2}(N)}{\prod_{m=1}^{N} \left(\mu_{m}^{2} + \frac{\overline{c}^{2}}{4}(N - 1)^{2}\right)}.$$

where Γ is the gamma function and Pµ, Eµ, Q<sup>µ</sup> are defined in (26).

Consider now the form factor of Ψ<sup>R</sup>(0). Let {µj} N <sup>j</sup>=1, {λj} N+R <sup>j</sup>=1 be two sets of rapidities satisfying (69), with {λj} N+R <sup>j</sup>=1 corresponding to the ground state while {µj} N <sup>j</sup>=1 to an arbitrary excited state of the system. The form factor (27) can be simplified in the limit {δj} → 0. The calculations are again reported in Appendix C and the final result for the form factor is

$$\langle 0 | \prod_{j=1}^{N} \mathcal{C}(\mu_{j}) \Psi^{R}(0) \prod_{j=1}^{N+R} \mathcal{B}(\lambda_{j}) | 0 \rangle = (-1)^{N+R} (i\sqrt{c})^{R} c^{2N}$$

$$\times \frac{N+R}{(R-1)!} \frac{\Gamma^{2}(N+R)}{\prod_{m=1}^{N} \left(\mu_{m}^{2} + \frac{\bar{c}^{2}}{4}(N+R-1)^{2}\right)}.$$
 (72)

Apart from the per se interest, the attractive Bose gas became recently a standard tool to solve the one dimensional Kardar Parisi Zhang equation [58] by means of replicas [59, 60, 61, 62, 63, 64]. The form factors provided here are the starting point for the calculation of observables which nowadays are known only in the limit of infinite time [65, 66].

# 6. Conclusions

In this work we presented exact formulas for the form factors of local operators in the Lieb-Liniger model. Our main results are: (i) the determinant formula (27) for the form factor of Ψ<sup>R</sup>(0) with R an arbitrary integer; (ii) two equivalent formulations for the form factors of (Ψ† (0))<sup>2</sup>Ψ<sup>2</sup> (0), i.e. one determinant formula (22) and a set of two determinants (30) and (32) which are valid respectively for different and equal momenta. Along the lines of [19], we also showed how our formulas can be simplified when one is interested in the form factors between the ground state of the attractive model and an arbitrary on-shell Bethe state. Our formulas can be useful for both numerical and analytical calculations, in equilibrium and non-equilibrium settings.

From the theoretical point of view, equation (27) is particularly interesting because it shows that an entire family of local form factors can be expressed as the determinant of a N × N matrix of simple form, similar to those already known for the form factors of Ψ(0) and Ψ† (0)Ψ(0) [15, 16, 17]. It would be extremely useful to find a similar representation for the form factors of the type (Ψ† (0))<sup>k</sup>Ψ<sup>k</sup> (0) considered in [25].

Note that in principle the method applied in this work could be used to derive manageable formulas for the general class of form factors (21). However, as it should be clear from our derivation in section 4, our approach requires a preliminary guesswork: indeed as a first step one tries to guess, for the desired form factor, an expression that satisfies the properties 1 − 4 of Prop. 1. The second step, namely the rigorous proof that the properties 1 − 4 of Prop. 1 are indeed satisfied, is straightforward if the initial guess is correct. Of course, the initial guesswork is not blindfold and one is guided by the constrains imposed by Prop. 1.

The starting point for our initial guesswork leading to formulas (22) and (27) has been given by the already known determinant formulas for the form factors of Ψ(0) and Ψ† (0)Ψ(0) as first derived in [15, 16, 17]. Our strategy has been to look for "minimal" modifications of such formulas that could still satisfy properties 1 − 4 of Prop. 1 for more general form factors. While this approach has turned out to be convenient for the form factors of Ψ<sup>R</sup>(0) and (Ψ† (0))<sup>2</sup>Ψ<sup>2</sup> (0), we have not yet been able to follow this strategy for the general case of Eq. (21).

The Lieb-Liniger model can be obtained as a scaling limit of the XXZ model [3, 67, 68, 25]. It is then natural to wonder whether the methods applied in this work could be used also for the XXZ chain. In particular, it would be interesting to have a single determinant representation for the form factor of σ z j σ z <sup>j</sup>+1 (and so giving a simpler representation than the one in [54]). These issues will be addressed in forthcoming publications.

### 7. Acknowledgments

We acknowledge Jacopo De Nardis for useful discussions and for an independent numerical check of the validity of Eqs. (30), (32). PC acknowledges the financial support by the ERC under Starting Grant 279391 EDEQS.

### Appendix A. Proof of Proposition 1

We now present a detailed proof of Prop. 1. We begin with property 1. To do this, we first prove by induction that

$$\Psi^{N}(0) \prod_{j=1}^{N} \mathcal{B}(\lambda)|0\rangle = (-i\sqrt{c})^{N} N! \prod_{j=1}^{N} r(\lambda_{j})|0\rangle.$$
(A.1)

The case N = 1 is trivial using (16). Suppose (A.1) is true for N ≥ 1. Then using (17) we have

$$\Psi^{N+1}(0) \prod_{j=1}^{N+1} \mathcal{B}(\lambda_{j})|0\rangle = \Psi^{N}(0) \left[ -i\sqrt{c} \sum_{k=1}^{N+1} \Lambda_{k} r(\lambda_{k}) \prod_{\substack{m=1\\m\neq k}}^{N+1} B(\lambda_{m}) \right] |0\rangle = (-i\sqrt{c})^{N+1} N!$$

$$\times \prod_{m=1}^{N+1} r(\lambda_{j}) \sum_{k=1}^{N+1} \prod_{\substack{m=1\\m\neq k}}^{N+1} f(\lambda_{k}, \lambda_{m})|0\rangle = (-i\sqrt{c})^{N+1} \left( \prod_{j=1}^{N+1} r(\lambda_{j}) \right) (N+1)!|0\rangle , \qquad (A.2)$$

where Λ<sup>k</sup> is given in (19) and where we used the inductive hypothesis and the identity

$$\sum_{k=1}^{N+1} \prod_{\substack{m=1\\m\neq k}}^{N+1} f(\lambda_k, \lambda_m) = N+1.$$
 (A.3)

Equation (A.1) is thus proved. Now, for a set of rapidities {λj} satisfying the Bethe equations (10) we have

$$\prod_{j=1}^{N} r(\lambda_j) = 1 , \qquad (A.4)$$

so (A.1) becomes

$$\Psi^{N}(0) \prod_{j=1}^{N} \mathcal{B}(\lambda)|0\rangle = (-i\sqrt{c})^{N} N!|0\rangle.$$
(A.5)

Analogously one can prove

$$\langle 0| \prod_{j=1}^{N} \mathcal{C}(\mu_j) (\Psi^{\dagger}(0))^N = (i\sqrt{c})^N N! \langle 0|.$$
(A.6)

Using (A.5), (A.6) property 1 of Prop. 1 is immediately proved.

We now address property 2. An explicit proof using the Bethe wave functions was given in [52] for the cases (h, k) = (0, 1) and (h, k) = (1, 1) . For the sake of completeness we give here a proof of the general case. This is based on the properties of the scalar product between two Bethe vectors [5, 56]. It is known from the theory of ABA that this is a rational function of the rapidities and that

$$\lim_{\mu_m \to \infty} \langle 0 | \prod_{j=1}^N \mathcal{C}(\mu_j) \prod_{j=1}^N \mathcal{B}(\lambda_j) | 0 \rangle = 0.$$
(A.7)

From (A.7) it is immediately seen by induction and using (17) that

$$\lim_{\mu_m \to \infty} \langle 0 | \prod_{j=1}^N \mathcal{C}(\mu_j) \Psi^k(0) \prod_{j=1}^{N+k} \mathcal{B}(\lambda_j) | 0 \rangle = 0.$$
 (A.8)

We now prove, once again by induction, that

$$\lim_{\mu_m \to \infty} \langle 0 | \prod_{j=1}^{N+h} \mathcal{C}(\mu_j) (\Psi^{\dagger}(0))^h \Psi^k(0) \prod_{j=1}^{N+k} \mathcal{B}(\lambda_j) | 0 \rangle =$$

$$= (i\sqrt{c}) h \langle 0 | \prod_{\substack{j=1 \ j \neq m}}^{N+h} \mathcal{C}(\mu_j) (\Psi^{\dagger}(0))^{h-1} \Psi^k(0) \prod_{j=1}^{N+k} \mathcal{B}(\lambda_j) | 0 \rangle , \qquad h \ge 1 . \tag{A.9}$$

The case h = 1 is immediately seen using (18) and (A.8). Suppose now (A.9) is true for h ≥ 1. Using (18) we have

$$\langle 0| \prod_{j=1}^{N+h+1} C(\mu_{j}) (\Psi^{\dagger}(0))^{h+1} \Psi^{k}(0) \prod_{j=1}^{N+k} \mathcal{B}(\lambda_{j}) |0\rangle =$$

$$= i\sqrt{c} \sum_{t=1}^{N+h+1} \prod_{\substack{o=1\\ o \neq t}}^{N+h+1} f(\mu_{o}, \mu_{t}) \langle 0| \prod_{\substack{j=1\\ j \neq t}}^{N+h+1} C(\mu_{j}) (\Psi^{\dagger}(0))^{h} \Psi^{k}(0) \prod_{j=1}^{N+k} \mathcal{B}(\lambda_{j}) |0\rangle. \tag{A.10}$$

We take now the limit µ<sup>m</sup> → ∞ using the inductive hypothesis

$$\lim_{\mu_{m}\to\infty} \langle 0| \prod_{j=1}^{N+h+1} \mathcal{C}(\mu_{j}) (\Psi^{\dagger}(0))^{h+1} \Psi^{k}(0) \prod_{j=1}^{N+k} \mathcal{B}(\lambda_{j}) |0\rangle =$$

$$= i\sqrt{c} \langle 0| \prod_{\substack{j=1\\j\neq m}}^{N+h+1} \mathcal{C}(\mu_{j}) (\Psi^{\dagger}(0))^{h} \Psi^{k}(0) \prod_{j=1}^{N+k} \mathcal{B}(\lambda_{j}) |0\rangle$$

$$+ (i\sqrt{c})^{2} h \sum_{\substack{t=1\\t\neq m}}^{N+h+1} \prod_{\substack{o=1\\o\neq m\\o\neq t}}^{N+h+1} f(\mu_{o}, \mu_{t}) \langle 0| \prod_{\substack{j=1\\j\neq m\\j\neq t}}^{N+h+1} \mathcal{C}(\mu_{j}) (\Psi^{\dagger}(0))^{h-1} \Psi^{k}(0) \prod_{j=1}^{N+k} \mathcal{B}(\lambda_{j}) |0\rangle.$$
 (A.11)

Using now (18) we have

$$(i\sqrt{c}) \sum_{\substack{t=1\\t\neq m}}^{N+h+1} \prod_{\substack{o=1\\o\neq m\\o\neq t}}^{N+h+1} f(\mu_{o}, \mu_{t}) \langle 0| \prod_{\substack{j=1\\j\neq m\\j\neq t}}^{N+h+1} \mathcal{C}(\mu_{j}) (\Psi^{\dagger}(0))^{h-1} \Psi^{k}(0) \prod_{j=1}^{N+k} \mathcal{B}(\lambda_{j}) |0\rangle =$$

$$= \langle 0| \prod_{\substack{j=1\\j\neq m}}^{N+h+1} \mathcal{C}(\mu_{j}) (\Psi^{\dagger}(0))^{h} \Psi^{k}(0) \prod_{j=1}^{N+k} \mathcal{B}(\lambda_{j}) |0\rangle , \qquad (A.12)$$

showing that (A.9) is true also for h + 1. The proof of (A.9) by induction is completed and so property 2 of Prop. 1 is true.

Property 3 is known from the theory of ABA [5, 47] so we finally discuss property 4 of Prop. 1. The general case for h, k ≥ 0 can be proven once again by induction. The case h = k = 0, corresponding to the scalar product of Bethe states, is well known from the general theory of ABA [5, 47, 56]. Using the action (17), (18) of the local fields on Bethe states one can proceed by induction as done before for property 2. A detailed derivation is also given in Appendix B of Ref. [48]. Since it presents no further difficulty, we will not report a derivation here and we refer to [48] for the details.

### **Appendix B. Proof of Proposition 2**

We present here a proof of Prop. 2, following [56].

Suppose that the function  $\mathcal{H}_{N,M}(\{\mu_j\}_{j=1}^N, \{\lambda_j\}_{j=1}^M)$  satisfies properties 1-4 of Prop. 1 for a specific value of (h,k) and for every  $N \geq h$ ,  $M \geq k$ . We suppose without loss of generality that  $k \geq h$  (the proof is analogous in the case  $k \leq h$ ) and define  $\ell = k - h$ . Note that by hypothesis we have  $M = N + \ell$ . Consider then quantity

$$\Gamma_{N}(\{\mu_{j}\}_{j=1}^{N}, \{\lambda_{j}\}_{j=1}^{N+\ell}) = 
= \mathcal{H}_{N,N+\ell}(\{\mu_{j}\}_{j=1}^{N}, \{\lambda_{j}\}_{j=1}^{N+\ell}) - \mathcal{F}_{N,N+\ell}^{h,k}(\{\mu_{j}\}_{j=1}^{N}, \{\lambda_{j}\}_{j=1}^{N+\ell}) .$$
(B.1)

We prove by induction on N that

$$\Gamma_N(\{\mu_j\}_{j=1}^N, \{\lambda_j\}_{j=1}^{N+\ell}) = 0, \qquad N \ge h.$$
 (B.2)

This is enough to prove Prop. 2. The base of the induction is N = h and it is true since by hypothesis  $\mathcal{H}_{N,M}$  satisfies property 1 of Prop. 1.

Suppose that (B.2) is true for a given  $N \ge h$ . We show that it is also true for N+1. To see this, consider  $\Gamma_{N+1}$  as a function of  $\mu_1$ . Thanks to property 3 it is a rational function with at most first order poles at  $\lambda_j$ ,  $j=1,\ldots,N+1+\ell$ . Now, because both  $\mathcal{H}_{N+1,N+1+\ell}$  and  $\mathcal{F}_{N+1,N+1+\ell}$  satisfy property 4, we can compute the residue at  $\mu_1=\lambda_k$ 

$$\Gamma_{N+1}(\{\mu_j\}, \{\lambda_j\})\Big|_{\mu_1 \to \lambda_k} \propto \mathcal{H}_{N,N+\ell}(\{\mu_j\}_{j \neq 1}, \{\lambda_j\}_{j \neq k}) - \mathcal{F}_{N,N+\ell}^{h,k}(\{\mu_j\}_{j \neq 1}, \{\lambda_j\}_{j \neq k})) 
= \Gamma_N(\{\mu_j\}_{j \neq 1}, \{\lambda_j\}_{j \neq k}) = 0 ,$$
(B.3)

where in the last line we used the inductive hypothesis. Thus  $\Gamma_{N+1}$  as a function of  $\mu_1$  does not have poles. Furthermore, since  $\mathcal{H}_{N+1,N+1+\ell}$  and  $\mathcal{F}_{N+1,N+1+\ell}$  both satisfy property 2 of Prop. 1, they have the same limit as  $\mu_1 \to \infty$ , that is

$$\lim_{\mu_j \to \infty} \Gamma_{N+1}(\{\mu_j\}, \{\lambda_j\}) = 0.$$
(B.4)

Summarizing,  $\Gamma_{N+1}(\{\mu_j\}, \{\lambda_j\})$  as a function of  $\mu_1$  is a rational function with no poles on the complex plane and vanishing at  $\infty$ . Invoking Liouville theorem in complex analysis we thus conclude that it is identically 0 and thus Prop. 2 is proved.

### Appendix C. Form factors in the attractive case

In this appendix we explicitly derive the formulas for the form factors in the attractive regime when one of the Bethe states corresponds to a N-string, as for the ground state. Our derivation follows the one presented in Ref. [19], with only few technical complications arising. We discuss in detail the form factor of  $\Psi^R(0)$ , the case of  $(\Psi^{\dagger}(0))^2\Psi^2(0)$  being completely analogous.

Define M = N + R, and consider the set of rapidities  $\{\lambda_i\}_{i=1}^M$  arranged as

$$\lambda_j = \lambda + i \frac{\overline{c}}{2} (M + 1 - 2j) + i \delta_j . \tag{C.1}$$

As a first ingredient we need the following expansion for  $\{\delta_i\} \to 0$ 

$$K(\lambda_{j}, \lambda_{k}) = \begin{cases} \frac{1}{\delta_{j,j+1}} + \mathcal{O}(1), & k = j+1, \\ \frac{1}{\delta_{j-1,j}} + \mathcal{O}(1), & k = j-1, \\ \mathcal{O}(1), & k \neq j \pm 1, \end{cases}$$
 (C.2)

where we defined  $\delta_{j,k} = \delta_j - \delta_k$ . We define further

$$V_{j} = \frac{\prod_{m=1}^{N} (\mu_{m} - \lambda_{j})}{\prod_{\substack{m=1 \ m \neq j}}^{M} (\lambda_{m} - \lambda_{j})}, \qquad j = 0, 1, \dots, M + 1,$$
(C.3)

where  $\lambda_0$  and  $\lambda_{M+1}$  are given by equation (C.1). Finally, we need the following expansions, which can be easily derived

$$\widetilde{V}_{R,j}^{+} = \begin{cases} V_0, & j = 1, \\ \frac{-i}{\delta_{j-1,j}} V_{j-1}, & j = 2, \dots, M, \end{cases}$$
(C.4)

$$\widetilde{V}_{R,j}^{-} = \begin{cases}
\frac{i}{\delta_{j,j+1}} V_{j+1}, & j = 1, \dots, M-1, \\
V_{M+1}, & j = M,
\end{cases}$$
(C.5)

where  $\widetilde{V}_{R,i}^{\pm}$  is given in (28).

We now plug the rapidities (C.1) into (27) and take the limit  $\{\delta_j\} \to 0$ . Consider the matrix

$$W_{jk} = \delta_{jk} \frac{\widetilde{V}_{R,j}^{+} - \widetilde{V}_{R,j}^{-}}{i} + \frac{\prod_{m=1}^{N} (\mu_m - \lambda_j)}{\prod_{\substack{m=1 \ m \neq i}}^{N+R} (\lambda_m - \lambda_j)} \left[ K(\lambda_j, \lambda_k) - K(\lambda_p, \lambda_k) K(\lambda_s, \lambda_j) \right] , \qquad (C.6)$$

so that

$$\prod_{j=1}^{M} \left( \widetilde{V}_{R,j}^{+} - \widetilde{V}_{R,j}^{-} \right) \det_{M} \left( \delta_{jk} + \widetilde{U}_{jk}^{(R)} \right) = i^{M} \det_{M} W_{jk} . \tag{C.7}$$

The matrix  $W_{jk}$  has singular behavior in the limit  $\{\delta_j\} \to 0$ . Since  $\lambda_p$  is an arbitrary parameter we can choose  $\lambda_p = \lambda_M$ ; with this choice the leading order of the matrix  $W_{jk}$  is

$$\begin{pmatrix} \frac{-V_2}{\delta_{1,2}} & \frac{V_1}{\delta_{1,2}} & 0 & \dots & 0 & \frac{-W_1}{\delta_{M-1,M}} & 0 \\ \frac{V_2}{\delta_{1,2}} & -\frac{V_1}{\delta_{1,2}} & \frac{V_3}{\delta_{2,3}} & \frac{V_2}{\delta_{2,3}} & \dots & 0 & \frac{-W_2}{\delta_{M-1,M}} & 0 \\ \vdots & \vdots & \vdots & \ddots & \vdots & \vdots & \vdots & \vdots \\ 0 & 0 & 0 & \cdots & \frac{-V_{M-3}}{\delta_{M-4,M-3}} & \frac{V_{M-1}}{\delta_{M-2,M-1}} & \frac{V_{M-2}}{\delta_{M-2,M-1}} & -\frac{W_{M-2}}{\delta_{M-1,M}} & 0 \\ 0 & 0 & 0 & \cdots & \frac{V_{M-1}}{\delta_{M-2,M-1}} & \frac{-V_{M-2}}{\delta_{M-2,M-1}} & \frac{W_{M-1}+V_M}{\delta_{M-1,M}} & \frac{V_{M-1}}{\delta_{M-1,M}} \\ 0 & 0 & 0 & \cdots & 0 & \frac{V_M}{\delta_{M-1}} & -\frac{W_M}{\delta_{M-1}} & -\frac{V_{M-1}}{\delta_{M-1}} \end{pmatrix}$$

where we defined  $W_j = V_j K(\lambda_s, \lambda_j)$ . The determinant of this matrix can be computed as follows. First, add the first row to the second, then the second to the third, and iterate this procedure until the last row. The last row of the resulting matrix has only one entry different from 0. Using Laplace expansion on the last row and the fact that the determinant of a triangular matrix is the product of its diagonal elements, we finally have

$$\det_{M} W_{jk} = (-1)^{M-2} \frac{V_{M-1}}{\delta_{M-1,M}} \left[ \prod_{j=1}^{M-1} \frac{1}{\delta_{j,j+1}} \right] \left[ \prod_{j=2}^{M-1} V_{j} \right] \left[ \sum_{j=1}^{M} K(\lambda_{s}, \lambda_{j}) V_{j} \right] . \tag{C.8}$$

Using (C.7) we can plug (C.8) into (27). One then uses (D.1) of appendix Appendix D and the following identity, which is easily derived for rapidities satisfying (C.1)

$$\prod_{\substack{m=1\\m\neq j}}^{M} (\lambda_m - \lambda_j) = (i\overline{c})^{M-1} (-1)^{M-j} (j-1)! (M-j)! .$$
 (C.9)

Putting everything together, after simple manipulations we get (72).

### Appendix D. Useful formulas

In this appendix we discuss identities involving sums of rational functions. These are useful when studying the properties of the determinant of matrices like those appearing in (22) and (27). The prototypical example is

$$i\sum_{j=1}^{N+R} K(\lambda_s, \lambda_j) \frac{\prod_{m=1}^{N} (\mu_m - \lambda_j)}{\prod_{m\neq j}^{N+R} (\lambda_m - \lambda_j)} = -\left(\widetilde{V}_{R,s}^+ - \widetilde{V}_{R,s}^-\right) , \tag{D.1}$$

where  $K(\lambda, \mu)$  and  $\widetilde{V}_{R,s}^{\pm}$  are given in (15), (28) respectively. Identity (D.1) is obtained using the residues theorem on the complex function

$$g_s(z) = \frac{1}{(z - \lambda_s - ic)(z - \lambda_s + ic)} \frac{\prod_{m=1}^{N} (\mu_m - z)}{\prod_{m=1}^{N+R} (\lambda_m - z)}.$$
 (D.2)

Indeed the function  $g_s(z)$  has first order poles for  $z = \lambda_j$ ,  $j = 1, ..., \lambda_{N+R}$  and for  $z = \lambda_s \pm ic$  while it is easy to see that it has vanishing residue at infinity. Using the fact that the sum of the residues has to be zero one immediately arrives at identity (D.1).

#### Appendix E. Derivation of equivalent formulas

In this appendix we show how to derive formulas (30) and (32) from (22). First define the matrix  $E^{\ell}$  as

$$E_{jk}^{\ell} = \begin{cases} \frac{\frac{K(\lambda_{p}, \lambda_{k})}{V_{j}^{+} - V_{j}^{-}}}{V_{j}^{+} - V_{j}^{-}} & \text{if } j = \ell, \\ \delta_{jk} + \frac{i}{V_{j}^{+} - V_{j}^{-}} \frac{\prod_{\substack{m=1 \ m=1 \ m=1 \ m \neq j}}^{N} (\mu_{m} - \lambda_{j})}{\prod_{\substack{m=1 \ m \neq j}}^{m=1} (\lambda_{m} - \lambda_{j})} K(\lambda_{j}, \lambda_{k}), & \text{otherwise}. \end{cases}$$
 (E.1)

Consider the matrix  $\delta_{jk} + U_{jk}$  appearing in (22). For j = 1, ..., N,  $j \neq \ell$ , add to row  $\ell$  row j multiplied by  $\Theta_j/\Theta_\ell$ , with  $\Theta_j$  defined as

$$\Theta_j = V_j^+ - V_j^- \,, \tag{E.2}$$

and where  $V_i^{\pm}$  is given in (23). With this procedure one obtains

$$\det_{N}(\delta_{jk} + U_{jk}) = (V_{s}^{+} - V_{s}^{-})\det_{N} M^{\ell},$$
(E.3)

where the matrix  $M^{\ell}$  is defined by

$$M_{jk}^{\ell} = \begin{cases} \frac{K(\lambda_p, \lambda_k)}{V_j^+ - V_j^-}, & \text{if } j = \ell, \\ \delta_{jk} + U_{jk}, & \text{otherwise}. \end{cases}$$
 (E.4)

For j = 1, ..., N,  $j \neq \ell$ , add now to row j row  $\ell$  multiplied by  $iK(\lambda_s, \lambda_j)\Xi_j$ , where

$$\Xi_{j} = \frac{\prod_{m=1}^{N} (\mu_{m} - \lambda_{j})}{\prod_{\substack{m=1 \ m \neq j}}^{N} (\lambda_{m} - \lambda_{j})}.$$
 (E.5)

Using the above procedure we see that  $\det_N M^{\ell} = \det_N E^{\ell}$ , and thus we obtain

$$\det_{N}(\delta_{jk} + U_{jk}) = (V_{s}^{+} - V_{s}^{-})\det_{N} E^{\ell}.$$
(E.6)

Now consider the matrix  $\delta_{jk} + U_{jk}^{(1)}$  in equation (30). For j = 1, ..., N,  $j \neq \ell$  add to row  $\ell$  row j multiplied by  $\Theta_j/\Theta_\ell$ , with  $\Theta_j$  is defined in (E.2). Using the the identity

$$\sum_{j=1}^{N} \frac{\prod_{m=1}^{N} (\mu_m - \lambda_j)}{\prod_{m \neq j}^{N} (\lambda_m - \lambda_j)} = \sum_{j=1}^{N} (\mu_j - \lambda_j) , \qquad (E.7)$$

which can be derived with the techniques described in Appendix D, one obtains

$$\det_N(\delta_{jk} + U_{jk}^{(1)}) = -i(P_\mu - P_\lambda) \det_N \widetilde{M}^\ell , \qquad (E.8)$$

where the matrix  $\widetilde{M}^{\ell}$  is defined as

$$\widetilde{M}_{jk}^{\ell} = \begin{cases} \frac{K(\lambda_p, \lambda_k)}{V_j^+ - V_j^-}, & \text{if } j = \ell, \\ \delta_{jk} + U_{jk}^{(1)}, & \text{otherwise.} \end{cases}$$
 (E.9)

Using again simple manipulations and the multilinearity of the determinant one sees that

$$\det_{N} \widetilde{M}^{\ell} = \det_{N} E^{\ell} . \tag{E.10}$$

Putting together (E.6), (E.8) and (E.10) it is now straightforward to see that (30) is indeed equivalent to (22).

We now derive (32) from (22). From (E.6) we see that  $\det_N E^{\ell} = \det_N E^m$  for  $\ell \neq m$ , so using (E.10) we can write

$$\det_{N}(\delta_{jk} + U_{jk}) = (V_{s}^{+} - V_{s}^{-}) \frac{1}{N} \sum_{\ell=1}^{N} \det_{N}(\widetilde{M}_{jk}^{\ell}) .$$
 (E.11)

The sum of determinants in the r.h.s of (E.11) can be rewritten as follows

$$\sum_{\ell=1}^{N} \det_{N}(\widetilde{M}_{jk}^{\ell}) = -i \left( \det_{N}(\delta_{jk} + U_{jk}^{(2)}) - \det_{N}(\delta_{jk} + U_{jk}^{(1)}) \right) , \qquad (E.12)$$

where  $U_{jk}^{(1)}$  and  $U_{jk}^{(2)}$  are given in (31), (33). The validity of Eq. (E.12) follows from  $U_{jk}^{(2)} = U_{jk}^{(1)} + iK(\lambda_p, \lambda_k)/(V_j^+ - V_j^-)$  and from the fact that  $N_{jk} = iK(\lambda_p, \lambda_k)/(V_j^+ - V_j^-)$  is a rank 1 matrix.

Now, from (E.8) we see that  $\det_N(\delta_{jk} + U_{jk}^{(1)}) \propto (P_\lambda - P_\mu)$ , and thus its contribution vanishes when we consider Bethe states having the same momentum. Putting together this observation with (E.11) and (E.12) it is then immediate to obtain (32) from (22).

### References

- [1] B. M. McCoy and T. T. Wu, *The Two-Dimensional Ising Model*, Harvard University Press (1973); R. J. Baxter, *Exactly Solvable Models in Statistical Mechanics*, Academic Press (1982);
  - B. Sutherland, *Beautiful Models* World Scientific (2004).
- [2] M. Takahashi, *Thermodynamics of one-dimensional solvable models*, Cambridge University Press (1999).
- [3] M. Gaudin, *La fonction d'onde de Bethe*, Masson (1983); M. Gaudin (translated by J.-S. Caux), *The Bethe wave function* Cambridge University Press (2014).
- [4] H.B. Thacker, Rev. Mod. Phys. 53, 253 (1981).
- [5] V.E. Korepin, N.M. Bogoliubov and A.G. Izergin, *Quantum inverse scattering method and correlation functions*, Cambridge University Press (1993).
- [6] I. Bloch, J. Dalibard and W. Zwerger, Rev. Mod. Phys. 80, 885 (2008); M. A. Cazalilla, R. Citro, T. Giamarchi, E. Orignac and M. Rigol, Rev. Mod. Phys. 83, 1405 (2011).
- [7] A. Polkovnikov, K. Sengupta, A. Silva and M. Vengalattore, Rev. Mod. Phys. 83, 863 (2011).
- [8] E. Lieb and W. Liniger, Phys. Rev. 130, 1605 (1963); E. Lieb, Phys. Rev. 130, 1616 (1963).
- [9] T. Kinoshita, T. Wenger and D. S. Weiss, Science 305, 1125 (2004); B. Paredes, A. Widera, V. Murg, O. Mandel, S. Folling, I. Cirac, G. V. Shlyapnikov, T. W. H ¨ ansch and I. ¨ Bloch, Nature 429, 277 (2004);
  - T. Kinoshita, T. Wenger and D. S. Weiss, Phys. Rev. Lett. 95, 190406 (2005);
  - T. Kinoshita, T. Wenger and D. S. Weiss, Nature 440, 900 (2006).
- [10] A. H. van Amerongen, J. J. P. van Es, P. Wicke, K. V. Kheruntsyan and N. J. van Druten, Phys. Rev. Lett. 100, 090402 (2008).
- [11] N. Fabbri, M. Panfil, D. Clement, L. Fallani, M. Inguscio, C. Fort and J.-S. Caux, Phys. Rev. A 91, 043617 (2015);
  - N. Fabbri, D. Clement, L. Fallani, C. Fort and M. Inguscio, Phys. Rev. A 83, 031604 (2011);
  - T. Jacqmin, J. Armijo, T. Berrada, K. V. Kheruntsyan and I. Bouchoule, Phys. Rev. Lett. 106, 230405 (2011);
  - F. Meinert, M. Panfil, M. J. Mark, K. Lauber, J.-S. Caux and H.-C. Nagerl, Phys. Rev. Lett. ¨ 115, 085301 (2015).
- [12] J. Simon, W. S. Bakr, R. Ma, M. E. Tai, P. M. Preiss and M. Greiner, Nature 472, 307 (2011).
- [13] G. Pagano, M. Mancini, G. Cappellini, P. Lombardi, F. Schafer, H. Hu, X.-J. Liu, J. Catani, C. Sias, M. Inguscio and L. Fallani, Nature Phys. 10, 198 (2014).
- [14] X.-W. Guan, M. T. Batchelor and C. Lee, Rev. Mod. Phys. 85, 1633 (2013).
- [15] T. Kojima, V. E. Korepin and N. A. Slavnov, Comm. Math. Phys. 188, 657 (1997).
- [16] J.-S. Caux, P. Calabrese and N. A. Slavnov, J. Stat. Mech. (2007) P01008.
- [17] N. A. Slavnov, Theor. Math. Phys. 82, 273 (1990).
- [18] J.-S. Caux and P. Calabrese, Phys. Rev. A 74, 031605 (2006).
- [19] P. Calabrese and J.-S. Caux, Phys. Rev. Lett. 98, 150403 (2007); P. Calabrese and J.-S. Caux, J. Stat. Mech. (2007) P08032.
- [20] M. Panfil and J.-S. Caux, Phys. Rev. A 89, 033605 (2014).
- [21] D. M. Gangardt and G. V. Shlyapnikov, Phys. Rev. Lett. 90, 010401 (2003); D. M. Gangardt and G. V. Shlyapnikov, New J. Phys. 5, 79 (2003).
- [22] V. V. Cheianov, H. Smith and M. B. Zvonarev, J. Stat. Mech. (2006) P08015.
- [23] M. Kormos, G. Mussardo and A. Trombettoni, Phys. Rev. Lett. 103, 210404 (2009). M. Kormos, G. Mussardo and A. Trombettoni, Phys. Rev. A 81, 043606, (2010).
- [24] M. Kormos, Y.-Z. Chou and A. Imambekov, Phys. Rev. Lett. 107, 230405 (2011).
- [25] B. Pozsgay, J. Stat. Mech. (2011) P11017.
- [26] J.-S. Caux and F. H. L. Essler, Phys. Rev. Lett. 110 257203 (2013).
- [27] J. De Nardis, B. Wouters, M. Brockmann and J.-S. Caux, Phys. Rev. A 89 033601 (2014).
- [28] G. Goldstein and N. Andrei, arXiv:1505.02585.

- [29] B. Wouters, J. De Nardis, M. Brockmann, D. Fioretto, M. Rigol and J.-S. Caux, Phys. Rev. Lett. 113, 117202 (2014);
  - M. Brockmann, B. Wouters, D. Fioretto, J. De Nardis, R. Vlijm and J.-S. Caux, J. Stat. Mech. (2014) P12009.
- [30] B. Pozsgay, M. Mestyan, M. A. Werner, M. Kormos, G. Zar ´ and and G. Tak ´ acs, Phys. Rev. Lett. ´ 113, 117203 (2014);
  - M. Mestyan, B. Pozsgay, G. Tak ´ acs and M. A. Werner, J. Stat. Mech. (2015) P04001. ´
- [31] A. De Luca, G. Martelloni, and J. Viti, Phys. Rev. A 91, 021603 (2015).
- [32] B. Bertini, D. Schuricht and F. H. L. Essler, J. Stat. Mech. (2014) P10035.
- [33] J. De Nardis and J.-S. Caux, J. Stat. Mech. (2014) P12012.
- [34] J. De Nardis, L. Piroli and J.-S. Caux, arXiv:1505.03080 (2015).
- [35] A. Faribault, P. Calabrese and J.-S. Caux, J. Stat. Mech. (2009) P03018; A. Faribault, P. Calabrese and J.-S. Caux, J. Math. Phys. 50, 095212 (2009).
- [36] V. Gritsev, T. Rostunov and E. Demler, J. Stat. Mech. (2010) P05012.
- [37] J. Mossel and J.-S. Caux, New J. Phy. 14 075006 2012.
- [38] D. Iyer and N. Andrei, Phys. Rev. Lett. 109, 115304 (2012); D. Iyer, H. Guan and N. Andrei, Phys. Rev. A 87 053628 (2013).
- [39] B. Pozsgay, J. Stat. Mech. (2013) P10028; B. Pozsgay, J. Stat. Mech. (2014) P06011.
- [40] J. Mossel, G. Palacios and J.-S. Caux, J. Stat. Mech. (2010) L09001.
- [41] M. Brockmann, J. Stat. Mech. (2014) P05006;
  - M. Brockmann, J. De Nardis, B. Wouters, and J.-S. Caux, J. Phys. A 47, 145003 (2014); M. Brockmann, J. De Nardis, B. Wouters, and J.-S. Caux, J. Phys. A 47, 345003 (2014).
- [42] P. Calabrese and P. Le Doussal, J. Stat. Mech. (2014) P05004.
- [43] L. Piroli and P. Calabrese, J. Phys. A 47, 385003 (2014).
- [44] M. Jimbo and T. Miwa, *Algebraic analysis of solvable lattice models*, Conference Board of the Mathematical Sciences, American Mathematical Society (1995).
- [45] N. Kitanine, J. M. Maillet and V. Terras, Nucl. Phys. B 554, 647 (1999); N. Kitanine, J. M. Maillet and V. Terras, Nucl. Phys. B 567, 554 (2000);
  - N. Kitanine, J. M. Maillet, N. A. Slavnov and V. Terras, Nucl. Phys. B 641, 487 (2002).
- [46] F. Gohmann, A. Kl ¨ umper and A. Seel, J. Phys. A ¨ 37, 7625 (2004); H. E. Boos, J. Damerau, F. Gohmann, A. Kl ¨ umper, J. Suzuki and A. Weiße, J. Stat. Mech. (2008) P08010. ¨
- [47] V.E. Korepin, Commun. Math. Phys. 86, 391 (1982).
- [48] B. Pozsgay, J. Stat. Mech. (2011) P01011.
- [49] M. Kormos, G. Mussardo and B. Pozsgay, J. Stat. Mech. (2010) P05014.
- [50] A. Shashi, M. Panfil, J.-S. Caux and A. Imambekov, Phys. Rev. B 85, 155136 (2012).
- [51] J. De Nardis and M. Panfil, J. Stat. Mech. (2015) P02019.
- [52] B. Pozsgay, W.-V. van Gerven Oei and M. Kormos, J. Phys. A 45, 465007 (2012).
- [53] J.-S. Caux, J. Math. Phys. 50, 095214 (2009).
- [54] A. Klauser, J. Mossel and J.-S. Caux, J. Stat. Mech. (2012) P03012.
- [55] A. G. Izergin, V. E. Korepin and N. Y. Reshetikhin, J. Phys. A 20, 4799 (1987).
- [56] N. A. Slavnov, Theor. Math. Phys. 79, 502 (1989).
- [57] N. Kitanine, K. K. Kozlowski, J. M. Maillet, N. A. Slavnov and V. Terras, J. Stat. Mech. (2009) P04003; N. Kitanine, K. K. Kozlowski, J. M. Maillet, N. A. Slavnov and V. Terras, J. Stat. Mech. (2011) P12010.
- [58] M. Kardar, G. Parisi and Y.C. Zhang, Phys. Rev. Lett. 56, 889 (1986).
- [59] P. Calabrese, P. Le Doussal and A. Rosso, EPL 90, 20002 (2010); P. Calabrese, M. Kormos and P. Le Doussal, EPL 107, 10011 (2014).
- [60] V. Dotsenko, EPL 90, 20003 (2010); V. Dotsenko, J. Stat. Mech. (2010) P07010.
- [61] P. Calabrese and P. Le Doussal, Phys. Rev. Lett. 106, 250603 (2011); P. Le Doussal and P. Calabrese, J. Stat. Mech. (2012) P06001.

- [62] T. Imamura and T. Sasamoto, Phys. Rev. Lett. 108, 190603 (2012); T. Imamura and T. Sasamoto, J. Phys. A 44, 385001 (2011).
- [63] T. Gueudre and P. Le Doussal, EPL 100, 26006 (2012).
- [64] P. Le Doussal, J. Stat. Mech. (2014) P04018.
- [65] V. Dotsenko, J. Phys. A 46, 355001 (2013); J. Stat. Mech. (2013) P06017; J. Stat. Mech. (2013) P02012.
- [66] S. Prolhac and H. Spohn, J. Stat. Mech. (2011) P01031; S. Prolhac and H. Spohn, J. Stat. Mech. (2011) P03020;
  - T. Imamura, T. Sasamoto and H. Spohn, J. Phys. A 46, 355002 (2013).
- [67] B. Golzer and A. Holz, J. Phys. A 20, 3327 (1987).
- [68] A. Seel, T. Bhattacharyya, F. Gohmann and A. Kl ¨ umper, J. Stat. Mech. (2007) P08030. ¨