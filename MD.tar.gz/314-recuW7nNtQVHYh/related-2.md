# Impurity Green's function of a one-dimensional Fermi gas

Oleksandr Gamayun, Andrei G. Pronko, and Mikhail B. Zvonarev

ABSTRACT. We consider a one-dimensional gas of spin-1/2 fermions interacting through  $\delta$ -function repulsive potential of an arbitrary strength. For the case of all fermions but one having spin up, we calculate time-dependent two-point correlation function of the spin-down fermion. This impurity Green's function is represented in the thermodynamic limit as an integral of Fredholm determinants of integrable linear integral operators.

### 1. Introduction

Consider a one-dimensional system of quantum particles driven by the secondary quantized Hamiltonian

$$H = \int_{0}^{L} dx \left( \sum_{s=\uparrow,\downarrow} \partial_{x} \psi_{s}^{\dagger}(x) \partial_{x} \psi_{s}(x) + 2c \, \psi_{\uparrow}^{\dagger}(x) \psi_{\uparrow}(x) \psi_{\downarrow}^{\dagger}(x) \psi_{\downarrow}(x) \right), \tag{1.1}$$

where c is a coupling constant, c > 0. The one-dimensional quantum fields  $\psi_s(x)$  and  $\psi_s^{\dagger}(x)$   $(s = \uparrow, \downarrow)$  satisfy canonical anti-commutation relations

$$\psi_s(x)\psi_{s'}^{\dagger}(x') + \psi_{s'}^{\dagger}(x')\psi_s(x) = \delta_{ss'}\delta(x - x'), \tag{1.2}$$

with all other anticommutators vanishing. The impurity Green's function is the two-point correlation function

$$G_{\downarrow}(x,t) = \langle \Omega_{\uparrow}| e^{itH} \psi_{\downarrow}(x) e^{-itH} \psi_{\downarrow}^{\dagger}(0) |\Omega_{\uparrow}\rangle, \qquad (1.3)$$

where  $|\Omega_{\uparrow}\rangle$  is the normalized ground state of N spin up fermions,  $\langle \Omega_{\uparrow} | \Omega_{\uparrow} \rangle = 1$ . The function (1.3) describes a propagation of an impurity (spin-down fermion) in a gas of free (spin-up) fermions. The impurity interacts with free fermions through a  $\delta$ -function potential of strength 2c.

Eigenfunctions and spectrum of the second-quantized Hamiltonian (1.1) in the sector with N spin-up and one spin-down fermions were found by McGiure [1]. Representations of eigenfunctions in terms of determinants resembling Slater determinant for free fermions were discussed by Edwards [2], Castella and Zotos [3], and Recher and Kohler [4]. A solution to the eigenstates problem for the Hamiltonian (1.1) in a sector with arbitrary number of spin-up and spin-down fermions was given by C. N. Yang [5] and Gaudin, see [6] and references therein.

In this paper we calculate the impurity Green's function (1.3). By exploiting the determinant structure of the eigenfunctions of the problem we employ the technique, known previously in the case of infinite coupling, which leads to determinant

1

representations for form factors and correlation functions. Namely, for the system in a finite volume L and for finite number N of spin-up fermions, we represent the impurity Green's function (1.3) in terms of determinants of N × N matrices. Taking the thermodynamic limit, defined as the limit N, L → ∞ with the ratio N/L kept constant, we get the Green's function (1.3) expressed in terms of Fredholm determinants of integrable linear integral operators, as shown by formula (4.30).

Representations in terms of Fredholm determinants for correlation functions were introduced, on the example of density matrix of the Tonks-Gerardeau gas (impenetrable Bose gas), by Schultz [7] and Lenard [8, 9]. Subsequently, it was realized that the representations of this kind plays an important role in description of correlation functions of one-dimensional quantum solvable models in terms of classical integrable systems [10, 11]. The role of integrable integral operators has been realized in [12]. The whole approach makes it possible to construct asymptotic expansions of correlation functions, e.g., for long times and large distances using the method of matrix Riemann-Hilbert problem [13, 14]; for a recent progress, see [15–17].

At the infinite coupling the general, depending on temperature, time, external magnetic field and chemical potential, two-point correlation functions of the twocomponent Fermi and Bose gases were computed in terms of Fredholm determinants in [18, 19]. Similar results in the context of the Hubbard model and ladder spin (a spin-1/2 Bose-Hubbard) model at the infinite coupling were given in [20, 21]. Various asymptotic results about these correlation functions, using the Reimann-Hilbert problem, have been obtained in [22–25]. Applications of these results to description of physical phenomena are discussed in [26–29].

Recently, a number of new phenomena were predicted for the dynamics and relaxation of the mobile impurity injected into a free Fermi gas [30–38]. We expect that our findings will pave a way towards quantitative description of those phenomena.

### 2. Bethe Ansatz and the impurity problem

The basis in the Fock space of the model is constructed by acting with operators ψ † s (x) onto the pseudovacuum |0i, defined as

$$\psi_s(x)|0\rangle = 0, \qquad \langle 0|\psi_s^{\dagger}(x) = 0, \qquad \langle 0|0\rangle = 1.$$
 (2.1)

We say that a state belongs to the sector (N, M) of the Fock space if it contains N − M particles of spin up and M particles of spin down, so that the total number of particles is N. The number of particles of each type being conserved separately, an eigenstate of the Hamiltonian (1.1) can be obtained as a linear superposition of the basis states from the same sector. In the sector (N, M) the eigenstates are enumerated by two sets, {k} = k1, . . . , k<sup>N</sup> and {λ} = λ1, . . . , λ<sup>M</sup> , of unequal, in each set separately, numbers, called quasi-momenta.

In the sector (N, M) the eigenstates can be written in the form

$$|\Psi_{N,M}(\{k\};\{\lambda\})\rangle = \int_{[0,L]^N} d^N x \sum_{\{s\}} \Psi_{N,M}^{\{s\}}(\{k\},\{\lambda\}|\{x\}) \,\psi_{s_1}^{\dagger}(x_1) \cdots \psi_{s_N}^{\dagger}(x_N) \,|0\rangle \,,$$
(2.2)

where {x} := x1, . . . , x<sup>N</sup> and the wave function Ψ{s} N,M({k}, {λ}|{x}) is not equal to zero only if M elements are equal to ↓ and N − M elements are equal to ↑ in the set  $\{s\} := s_1, \dots, s_N$ . The quasi-momenta are solutions of the nested Bethe Ansatz equations:

$$e^{ik_jL} = \prod_{a=1}^{M} \frac{k_j - \lambda_a + ic/2}{k_j - \lambda_a - ic/2}, \quad j = 1, \dots, N,$$
 (2.3)

$$\prod_{j=1}^{N} \frac{k_j - \lambda_a + ic/2}{k_j - \lambda_a - ic/2} = \prod_{b=1}^{M} \frac{\lambda_b - \lambda_a + ic}{\lambda_b - \lambda_a - ic}, \qquad a = 1, \dots, M.$$
(2.4)

The eigenvalue (energy) of the Hamiltonian (1.1) in the sector (N, M) is

$$E_{N,M}(\{k\},\{\lambda\}) = \sum_{i=1}^{N} k_j^2.$$
(2.5)

For what follows we need only the eigenstates belonging to the sectors (N,0) and (N+1,1). The former are given simply by the Slater determinant wave function while the latter can be constructed using a connection to the problem of mobile impurity interacting with the gas of N free fermions.

In the sector (N,0) the second set of quasi-momenta is empty,  $\{\lambda\} = \emptyset$ , and the Bethe equations for the elements of the first set are given by (2.3) with the right-hand side equal to one. For the sake of further convenience in calculations, we denote the quasi-momenta of the first set as  $\{q\} = q_1, \ldots, q_N$ . The eigenstate (2.2) in this case reads

$$|\Psi_{N,0}(\lbrace q\rbrace)\rangle = \int_{[0,L]^N} d^N x \, \Psi_{N,0}^{\uparrow \dots \uparrow}(\lbrace q\rbrace | \lbrace x\rbrace) \, \psi_{\uparrow}^{\dagger}(x_1) \dots \psi_{\uparrow}^{\dagger}(x_N) \, |0\rangle \,, \qquad (2.6)$$

where the wave function is

$$\Psi_{N,0}^{\uparrow\dots\uparrow}(\lbrace q\rbrace|\lbrace x\rbrace) = \frac{1}{N!L^{N/2}} \det_{1 \leq i, l \leq N} \left( e^{iq_j x_l} \right). \tag{2.7}$$

The quasi-momenta are quantized as

$$q_j = \frac{2\pi}{L} m_j, \qquad m_j \in \mathbb{Z}, \tag{2.8}$$

and in order that the wave function does not vanish, they must all be distinct; the eigenstates in the considered sector are labeled in a unique way by sets  $\{q\}$  in which  $q_1 < q_2 < \cdots < q_N$ . The ground state in the sector (N,0) is the state  $|\Omega_{\uparrow\uparrow}\rangle = |\Psi_{N,0}(\{q\})\rangle$ , in which  $-k_{\rm F} \leq q_1 < \cdots < q_N \leq k_{\rm F}$  for N odd, and  $-k_{\rm F} < q_1 < \cdots < q_N \leq k_{\rm F}$  for N even, where  $k_{\rm F} = \pi N/L$ .

Now we turn to construction of the eigenstates in the sector (N + 1, 1). According to (2.2) they have the form

$$|\Psi_{N+1,1}(\{k\},\lambda)\rangle = \int_{[0,L]^{N+1}} d^{N+1}x \sum_{j=1}^{N+1} \Psi_{N+1,1}^{\uparrow_{j}}(\{k\},\lambda|\{x\}) \times \psi_{\uparrow}^{\dagger}(x_{1}) \cdots \psi_{\uparrow}^{\dagger}(x_{j-1}) \psi_{\downarrow}^{\dagger}(x_{j}) \psi_{\uparrow}^{\dagger}(x_{j+1}) \cdots \psi_{\uparrow}^{\dagger}(x_{N+1}) |0\rangle, \quad (2.9)$$

where  $\uparrow_j$  denotes the set of N+1 spins with all but one spins up,  $\uparrow_j=\uparrow \dots \uparrow\downarrow\uparrow$ ...  $\uparrow$ , with the down spin standing on the jth position. We relabel arguments

 $x_1, \ldots, x_{N+1}$  in (2.9) in such a way that the field operator  $\psi_{\downarrow}^{\dagger}$  always depends on  $x_{N+1}$ :

$$|\Psi_{N+1,1}(\{k\},\lambda)\rangle = \int_{[0,L]^{N+1}} d^{N+1}x \,\widetilde{\Psi}_{N+1,1}(\{k\},\lambda|\{x\})$$
$$\times \psi_{\uparrow}^{\dagger}(x_1) \cdots \psi_{\uparrow}^{\dagger}(x_N) \psi_{\downarrow}^{\dagger}(x_{N+1}) |0\rangle. \quad (2.10)$$

The wave function  $\Psi_{N+1,1}(\{x\})$  (to ease notations, we do not show below the dependence of the wave-functions on quasi-momenta explicitly whenever possible) is expressed in terms of those entering (2.9) as follows

$$\widetilde{\Psi}_{N+1,1}(\{x\}) = \sum_{j=1}^{N+1} (-1)^{N-j} \Psi_{N+1,1}^{\uparrow_j}(x_1, \dots, x_{j-1}, x_{N+1}, x_{j+1}, \dots, x_N), \quad (2.11)$$

and it must be an eigenfunction of the first quantized Hamiltonian

$$\mathcal{H}_{N+1,1} = -\sum_{j=1}^{N+1} \frac{\partial^2}{\partial x_j^2} + 2c \sum_{j=1}^{N} \delta(x_i - x_{N+1}), \tag{2.12}$$

where  $x_1, \ldots, x_{N+1} \in [0, L]$ , with the periodic boundary conditions.

A way to diagonalize the Hamiltonian (2.12) used in [2,3] is to represent it first in the reference frame of the spin down particle, introducing the coordinates

$$y_j = x_j - x_{N+1}, \qquad j = 1, \dots, N.$$
 (2.13)

Hence,  $x_j = y_j + x_{N+1}$ , j = 1, ..., N, and therefore

$$\frac{\partial}{\partial x_j} = \frac{\partial}{\partial y_j}, \quad j = 1, \dots, N, \qquad \frac{\partial}{\partial x_{N+1}} = i\mathcal{P}_{N+1} - \sum_{i=1}^N \frac{\partial}{\partial y_i},$$
 (2.14)

where  $\mathcal{P}_{N+1}$  is the first quantized total momentum operator of N+1 particles,

$$\mathcal{P}_{N+1} = \sum_{i=1}^{N+1} \frac{1}{i} \frac{\partial}{\partial x_j}.$$
 (2.15)

Since  $\mathcal{P}_{N+1}$  is an integral of motion,  $[\mathcal{P}_{N+1}, \mathcal{H}_{N+1,1}] = 0$ , it can be replaced by its eigenvalues P when acting on the eigenfunctions,

$$P = \sum_{j=1}^{N+1} k_j = \frac{2\pi}{L} n, \qquad n \in \mathbb{Z}.$$
 (2.16)

The Hamiltonian in the new coordinates reads

$$\mathcal{H}_{N+1,1} = -\sum_{j=1}^{N} \frac{\partial^2}{\partial y_j^2} + \left(P + i\sum_{j=1}^{N} \frac{\partial}{\partial y_j}\right)^2 + 2c\sum_{j=1}^{N} \delta(y_i). \tag{2.17}$$

Noticing that this in fact an N-particle Hamiltonian and denoting its eigenfunctions as  $\Phi_N(\{y\})$ , where  $\{y\} := y_1, \dots, y_N$ , we have the following relation between the wave functions in the two reference frames [3]:

$$\widetilde{\Psi}_{N+1,1}(\{x\}) = e^{iPx_{N+1}} \Phi_N(x_1 - x_{N+1}, \dots, x_N - x_{N+1}). \tag{2.18}$$

The function  $\Phi_N(\{y\}) = \Phi_N(\{k\}, \lambda | \{y\})$  must be periodic function in each coordinate, and totally antisymmetric with respect to their permutations.

We construct the function  $\Phi_N(\{y\})$  restricting to the domain  $y_1, \ldots, y_N \in [0, L]$ . The periodicity implies that

$$\Phi_N(\{y\})|_{y_i=0} = \Phi_N(\{y\})|_{y_i=L}, \qquad j=1,\dots,N,$$
(2.19)

and that the first derivatives, due to the  $\delta$ -function potential in (2.17), must satisfy the conditions

$$\frac{\partial}{\partial y_j} \Phi_N(\{y\}) \Big|_{y_j = 0} - \frac{\partial}{\partial y_j} \Phi_N(\{y\}) \Big|_{y_j = L} = c \Phi_N(\{y\}) |_{y_j = 0}, \qquad j = 1, \dots, N. \tag{2.20}$$

The antisymmetry implies that  $\Phi_N(\{y\})$  is a determinant

$$\Phi_N(\{y\}) = C_{\Phi_N} \det_{1 \le j,l \le N} (\phi_j(y_l)). \tag{2.21}$$

Here  $C_{\Phi_N}$  is a normalization factor to be found later, and the functions  $\phi_j(y)$  can be represented as a superpositions of at least N+1 plane waves:

$$\phi_j(y) = \sum_{l=1}^{N+1} a_{jl} e^{ik_l y}.$$
 (2.22)

The condition (2.19) implies that

$$\sum_{l=1}^{N+1} a_{jl} (1 - e^{ik_l L}) = 0, \qquad j = 1, \dots, N,$$
(2.23)

and (2.20) that

$$\sum_{l=1}^{N+1} a_{jl} \left( ik_l (1 - e^{ik_l L}) - c \right) = 0, \qquad j = 1, \dots, N.$$
 (2.24)

Subtracting (2.23) from (2.24) with the factor  $i\lambda - c/2$ , where  $\lambda$  is the quasimomentum of the auxiliary Bethe Ansatz problem, and requiring that all coefficients of the sum in the resulting equation vanish, we reproduce the first set of Bethe Ansatz equations (2.3) of the sector (N+1,1):

$$e^{ik_l L} = \frac{k_l - \lambda + ic/2}{k_l - \lambda - ic/2}, \qquad l = 1, \dots, N + 1.$$
 (2.25)

Recalling the quantization condition for the total momentum (2.16), we also have the equation for  $\lambda$ :

$$\prod_{l=1}^{N+1} \frac{k_l - \lambda + ic/2}{k_l - \lambda - ic/2} = 1.$$
 (2.26)

Obviously, this equation is exactly the second set of the Bethe Ansatz equations of the sector (N + 1, 1), see (2.4).

The Bethe Ansatz equations (2.25) can also be written in the form

$$\cot \frac{k_j L}{2} = \frac{2(k_j - \lambda)}{c}, \qquad j = 1, \dots, N + 1.$$
 (2.27)

Introduce the notation

$$\alpha_j = -\operatorname{arccot} \frac{2(k_j - \lambda)}{c}, \qquad j = 1, \dots, N + 1.$$
(2.28)

We use the convention that  $\operatorname{arccot} x \in [0, \pi], x \in \mathbb{R}$ . The quantization conditions for momenta  $\{k\}$  are

$$k_j = \frac{2\pi}{L} n_j - \frac{2}{L} \alpha_j, \qquad n_j \in \mathbb{Z}. \tag{2.29}$$

Equation (2.26) has the form

$$\frac{R_N(\lambda)}{Q_{N+1}(\lambda)} = 0, (2.30)$$

where  $R_N(\lambda)$  and  $Q_{N+1}(\lambda)$  are polynomials in  $\lambda$  of the degrees shown in the subscripts,

$$R_N(\lambda) = Q_{N+1}(\lambda - ic) - Q_{N+1}(\lambda), \qquad Q_{N+1}(\lambda) = \prod_{l=1}^{N+1} \left( k_l - \lambda - \frac{ic}{2} \right).$$
 (2.31)

The quantization condition for the quasi-momentum  $\lambda$ , which takes N+1 values, follows from the relation

$$\sum_{j=1}^{N+1} \alpha_j = -\pi m, \qquad m = 0, 1, \dots, N.$$
 (2.32)

The value m=0 corresponds to  $\lambda=-\infty$ ; the values  $m=1,\ldots,N$  correspond to the roots of the polynomial  $R_N(\lambda)$ .

To finalize the construction of the wave function  $\Phi_N(\{y\})$ , we have to satisfy the conditions (2.23). It can be easily seen that this can be done by choosing

$$\phi_j(y) = \chi_j(y) - \chi_{N+1}(y), \qquad j = 1, \dots, N,$$
 (2.33)

where

$$\chi_l(y) = \frac{e^{ik_l y + i\alpha_l}}{\sin \alpha_l} = -\frac{2}{c} \left( k_l - \lambda - \frac{ic}{2} \right) e^{ik_l y}, \qquad l = 1, \dots, N+1.$$
 (2.34)

With our choice it is obvious that the wave function  $\Phi_N(\{y\})$  can also be represented as the following determinant of an  $(N+1) \times (N+1)$  matrix:

$$\Phi_N(\{y\}) = C_{\Phi_N} \begin{vmatrix} \chi_1(y_1) & \dots & \chi_1(y_N) & 1 \\ \vdots & \ddots & \vdots & \vdots \\ \chi_{N+1}(y_1) & \dots & \chi_{N+1}(y_N) & 1 \end{vmatrix}.$$
 (2.35)

Recalling relation (2.18) one can readily obtain the corresponding expression for the wave function  $\widetilde{\Psi}_{N+1,1}(\{x\})$ . The only point need to be taken into account is that the formulas above have to be extended on the values  $y_1, \ldots, y_N \in [-L, L]$ . Due to the periodicity, for  $y \in [-L, 0]$  we can set  $\chi_l(y) = \chi_l(L+y)$  and using the Bethe Ansatz equations (2.25), we have

$$\chi_l(y) = -\frac{2}{c} \left( k_j - \lambda - \frac{\mathrm{i}c}{2} \operatorname{sgn} y \right) e^{\mathrm{i}k_l y}, \qquad y \in [-L, L], \tag{2.36}$$

where  $\operatorname{sgn} y$  is the signum function. It is worth to mention that the resulting expression for function  $\widetilde{\Psi}_{N+1,1}(\{x\})$  which follows from (2.18), (2.35) and (2.36) coincides with the expression for the wave function proposed in [4].

To satisfy the normalization condition  $\langle \Psi_{N+1,1}(\{k\},\lambda)|\Psi_{N+1,1}(\{k\},\lambda)\rangle = 1$  the constant  $C_{\Phi_N}$  has to be chosen such that

$$|C_{\Phi_N}|^2 = \frac{1}{(N!)^2 L^{N+1}} \left( \sum_{l=1}^{N+1} \prod_{\substack{j=1\\j\neq l}}^{N+1} \left( \frac{1}{\sin^2 \alpha_j} + \frac{4}{Lc} \right) \right)^{-1}.$$
 (2.37)

We prove (2.37) in the next section.

#### 3. Finite volume calculations

In this section we perform various calculations with the wave functions obtained in the previous section. We first prove formula (2.37). We have

$$\langle \Psi_{N+1,1}(\{k\}, \lambda) | \Psi_{N+1,1}(\{k\}, \lambda) \rangle = N! L \int_{[0,L]^N} d^N y \, |\Phi_N(\{y\})|^2$$

$$= |C_{\Phi_N}|^2 (N!)^2 L^{N+1} \det_{1 \le j,l \le N} \left( \frac{1}{L} \int_0^L dy \, \overline{\phi_j(y)} \phi_l(y) \right). \quad (3.1)$$

To evaluate the entries of the matrix here, we use the following relation, valid for  $k_j \neq k_l$ ,

$$\int_{0}^{L} dy \, e^{i(k_l - k_j)y} = \frac{e^{i(k_l - k_j)L} - 1}{i(k_l - k_j)} = -\frac{4\sin\alpha_j \sin\alpha_l}{c} e^{i\alpha_j - i\alpha_l}, \quad (3.2)$$

where the second equality follows by considering a difference of two Bethe Anzatz equations (2.27). For the off-diagonal entries, we obtain

$$\frac{1}{L} \int_{0}^{L} dy \, \overline{\phi_{j}(y)} \phi_{l}(y) = \frac{1}{\sin^{2} \alpha_{N+1}} - \frac{4}{Lc} \qquad (j \neq l), \tag{3.3}$$

and for the diagonal ones, we obtain

$$\frac{1}{L} \int_{0}^{L} dy \, |\phi_j(y)|^2 = \frac{1}{\sin^2 \alpha_j} + \frac{1}{\sin^2 \alpha_{N+1}} - \frac{8}{Lc}.$$
 (3.4)

Denoting  $u_j = 1/\sin^2 \alpha_j - 4/Lc$ , j = 1, ..., N+1, we see that the  $N \times N$  matrix in the determinant in (3.1) is the sum of a diagonal matrix, with entries  $u_j \delta_{jl}$ , and of a matrix of rank one, with all entries equal to  $u_{N+1}$ . Hence,

$$\det_{1 \le j,l \le N} \left( \int_{0}^{L} dy \, \overline{\phi_{j}(y)} \phi_{l}(y) \right) = \det_{1 \le j,l \le N} \left( u_{j} \delta_{jl} + u_{N+1} \right)$$

$$= u_{1} \cdots u_{N} \left( 1 + \left( u_{1}^{-1} + \cdots + u_{N}^{-1} \right) u_{N+1} \right) = \sum_{j=1}^{N+1} u_{j}^{-1} \prod_{j=1}^{N+1} u_{j}, \quad (3.5)$$

and formula (2.37) follows.

Next we consider the form-factors of the operator  $\psi_{\downarrow}(x)$  relevant to the Green's function (1.3). Specifically, these are its matrix elements between the states belonging to the sectors (N,0) and (N+1,1). We have

$$\langle \Psi_{N,0}(\{q\})| e^{\mathrm{i}tH} \psi_{\downarrow}(x) e^{-\mathrm{i}tH} | \Psi_{N+1,1}(\{k\}, \lambda) \rangle$$

$$= \langle \Psi_{N,0}(\{q\})| \psi_{\downarrow}(0) | \Psi_{N+1,1}(\{k\}, \lambda) \rangle \exp \left\{ i \sum_{j=1}^{N} \tau(q_j) - i \sum_{j=1}^{N+1} \tau(k_j) \right\}, \quad (3.6)$$

where  $\tau(q) = tq^2 - xq$ . Using expressions (2.7) and (2.35) for the wave functions involved, for the form-factor we obtain the following representation:

$$\langle \Psi_{N,0}(\{q\}) | \psi_{\downarrow}(0) | \Psi_{N+1,1}(\{k\}, \lambda) \rangle$$

$$= N! \int_{[0,L]^N} d^N x \, \overline{\Psi_{N,0}^{\uparrow \dots \uparrow}(\{x\})} \Phi_N(\{x\}) = \frac{N! C_{\Phi_N}}{L^{N/2}} F_N(\{q\} | \{k\}), \quad (3.7)$$

where

$$F_N(\{q\}|\{k\}) = \det_{1 \le j,l \le N} \left( \int_0^L dx \, e^{-iq_j x} \phi_l(x) \right).$$
 (3.8)

Taking into account that  $e^{iq_jL} = 1$  and  $e^{ik_lL} = e^{-2i\alpha_l}$ , the integrals are evaluated as follows:

$$\int_{0}^{L} dx \, e^{-iq_{j}x} \chi_{l}(x) = \frac{e^{i\alpha_{l}}}{\sin \alpha_{l}} \int_{0}^{L} dx \, e^{i(k_{l}-q_{j})x} = \frac{e^{i\alpha_{j}}}{\sin \alpha_{j}} \frac{e^{i(k_{l}-q_{j})L} - 1}{i(k_{j}-q_{l})} = \frac{2}{q_{j}-k_{l}}. \quad (3.9)$$

Hence,

$$F_N(\{q\}|\{k\}) = 2^N \det_{1 \le j,l \le N} \left( \frac{1}{q_j - k_l} - \frac{1}{q_j - k_{N+1}} \right). \tag{3.10}$$

We also note that the function  $F_N(\{q\}|\{k\})$  can be written as a determinant of an  $(N+1)\times(N+1)$  matrix,

$$F_N(\{q\}|\{k\}) = 2^N \begin{vmatrix} (q_1 - k_1)^{-1} & \dots & (q_1 - k_{N+1})^{-1} \\ \vdots & \ddots & \vdots \\ (q_N - k_1)^{-1} & \dots & (q_N - k_{N+1})^{-1} \\ 1 & \dots & 1 \end{vmatrix},$$
(3.11)

which can be obtained when using (2.35) instead of (2.21).

We now consider the impurity Green's function on the finite lattice, defined as a diagonal matrix element of the two-point field operator in the sector (N,0),

$$G_{\downarrow,N}(x,t|\{q\}) = \langle \Psi_{N,0}(\{q\})| e^{itH} \psi_{\downarrow}(x) e^{-itH} \psi_{\downarrow}^{\dagger}(0) | \Psi_{N,0}(\{q\}) \rangle.$$
 (3.12)

This function can be written as the sum over all states (i.e., all distinct solutions of the Bethe Ansatz equations) in the sector (N + 1, 1):

$$G_{\downarrow,N}(x,t|\{q\}) = \sum_{\{k\},\lambda} |\langle \Psi_{N,0}(\{q\})| \psi_{\downarrow}(0) | \Psi_{N+1,1}(\{k\},\lambda) \rangle|^{2}$$

$$\times \exp\left\{ i \sum_{j=1}^{N} \tau(q_{j}) - i \sum_{j=1}^{N+1} \tau(k_{j}) \right\}. \quad (3.13)$$

Using (3.7) and taking into account (2.37), we have

$$G_{\downarrow,N}(x,t|\{q\}) = \frac{1}{L^{2N+1}} \sum_{\{k\},\lambda} \frac{u_1^{-1} \cdots u_{N+1}^{-1}}{u_1^{-1} + \cdots + u_{N+1}^{-1}} \times F_N^2(\{q\}|\{k\}) \exp\left\{i \sum_{j=1}^N \tau(q_j) - i \sum_{j=1}^{N+1} \tau(k_j)\right\}.$$
(3.14)

Here the quantities  $u_1, \ldots, u_{N+1}$  are

$$u_j = \frac{1}{\sin^2 \alpha_j} + a, \qquad j = 1, \dots, N+1,$$
 (3.15)

where, for a later convenience, we introduced the notation a = 4/Lc.

The sum (3.14) is defined as the sum over values of the set of integers  $\{n\} = n_1, \ldots, n_{N+1}$  and the integer m, which label the solutions of the Bethe Ansatz equations,

$$\sum_{\{k\},\lambda} = \sum_{\substack{n_i \in \mathbb{Z} \\ n_1 < \dots < n_{N+1}}} \sum_{m=0}^{N} .$$
 (3.16)

Since every term of the sum in (3.14), being totally symmetric with respect to permutations of  $k_j$ 's, vanishes as soon as any two of  $k_j$ 's coincide, and since  $k_i = k_j$  if  $n_i = n_j$ , the sum over the ordered set of integers  $\{n\}$  can be replaced by independent sums over these integers,

$$\sum_{\substack{n_i \in \mathbb{Z} \\ n_1 < \dots < n_{N+1}}} \longrightarrow \frac{1}{(N+1)!} \sum_{n_1 \in \mathbb{Z}} \dots \sum_{n_{N+1} \in \mathbb{Z}}.$$
 (3.17)

However, since the Bethe Ansatz equations for the momenta  $\{k\}$  and the quasimomentum  $\lambda$  are coupled, the  $k_j$ 's and  $\lambda$  depend on all these integers,  $k_j = k_j(\{n\}, m)$ ,  $\lambda = \lambda(\{n\}, m)$ , so some further transformations in (3.14) are required to handle the summations. Namely, it would be convenient that the sum over each individual  $n_j$  implies the summation over the admissible values of the momentum  $k_j$  only; it would be useful also to have an interpretation of the sum of  $u_j^{-1}$ 's standing in the denominator in (3.14), which prevents a factorized summation over admissible values of  $k_j$ 's in the multiple sum.

It turns out that all this can be achieved by considering the momenta  $k_j$  as functions of  $\lambda$ , namely,  $k_j = k_j(\lambda)$ , in which  $\lambda$  is allowed to take arbitrary (real) values; the solutions of Bethe Ansatz equations (2.25) and (2.26) correspond to the values  $\lambda = \Lambda_m$ ,  $m = 0, \ldots, N$ . These values will follow as roots of certain (transcendent) equation imposed on the set of functions  $\{k(\lambda)\}$ . To be more precise, let us introduce a function  $z_n(\lambda)$ , where  $n \in \mathbb{Z}$  and  $\lambda \in \mathbb{R}$ , as the solution of the equation

$$z_n(\lambda) = \pi n + \operatorname{arccot}\left(az_n(\lambda) - \frac{2\lambda}{c}\right).$$
 (3.18)

As it can be easily seen (e.g., using graphical interpretation by taking cotangent of both sides) that this equation, for every value of n, defines a single-valued, continuous, monotonously increasing function of  $\lambda$ . The last property can be seen

by taking the derivative in  $\lambda$  of (3.18) and expressing it in terms of  $z(n;\lambda)$ ,

$$\partial_{\lambda} z_n(\lambda) = \frac{2/c}{1 + a + (az_n(\lambda) - 2\lambda/c)^2}.$$
(3.19)

Now, given a set of integers  $\{n\} = n_1, \dots, n_{N+1}$ , we define the set of functions  $\{k(\lambda)\} = k_1(\lambda), \dots, k_{N+1}(\lambda)$  by setting

$$k_j(\lambda) = \frac{2}{L} z_{n_j}(\lambda), \qquad j = 1, \dots, N+1.$$
 (3.20)

Clearly, here each  $k_j(\lambda)$  depends solely on  $n_j$ , as desired. Furthermore, let us introduce functions  $\alpha_j(\lambda)$  and  $u_j(\lambda)$  by defining them by (2.28) and (3.15), respectively, where  $k_j$  is replaced by  $k_j(\lambda)$ . Namely, we set  $\alpha_j(\lambda) := \alpha(k_j(\lambda), \lambda)$  and  $u_j(\lambda) := u(k_j(\lambda), \lambda)$ , where the functions  $\alpha(k, \lambda)$  and  $u(k, \lambda)$  are given by

$$\alpha(k,\lambda) = -\operatorname{arccot}\left(\frac{2(k-\lambda)}{c}\right)$$
 (3.21)

and

$$u(k,\lambda) = \frac{1}{\sin^2 \alpha(k,\lambda)} + a = 1 + a + \left(\frac{2(k-\lambda)}{c}\right)^2,\tag{3.22}$$

respectively. Relation (3.19) then implies

$$\partial_{\lambda} k_j(\lambda) = \frac{a}{u_j(\lambda)}. (3.23)$$

Hence, introducing a  $\lambda$ -dependent "total momentum"  $P(\lambda) = \sum_{j} k_{j}(\lambda)$ , we have

$$\sum_{j=1}^{N+1} u_j^{-1}(\lambda) = a^{-1} \partial_{\lambda} P(\lambda). \tag{3.24}$$

The relation (3.24) may be used to transform the expression  $u_1^{-1} + \cdots + u_N^{-1}$  from (3.14). For that we recall (2.32), which implies that the solutions of Bethe Ansatz equation in our treatment are restored at the values  $\lambda = \Lambda_0, \ldots, \Lambda_N$ , that is

$$\sum_{j=1}^{N+1} \alpha_j(\Lambda_m) = -\pi m, \qquad m = 0, 1, \dots, N.$$
 (3.25)

An equivalent way to impose this condition is to set

$$P(\Lambda_m) = \frac{2\pi}{L} \sum_{j=1}^{N+1} n_j + \frac{2\pi}{L} m.$$
 (3.26)

Hence, for given values of the set of integers  $\{n\}$  and integer m, the sum of  $u_j^{-1}$ 's is exactly the derivative of the total momentum at  $\lambda = \Lambda_m$ ,

$$\sum_{j=1}^{N+1} u_j^{-1} = a^{-1} P'(\Lambda_m), \tag{3.27}$$

where we used the notation  $P'(\Lambda_m) = \partial_{\lambda} P(\lambda)|_{\lambda = \Lambda_m}$ .

To show how these considerations make it possible to factorize of the summation in (3.14), let us consider the sum over m at some fixed set of values of the integers  $\{n\}$ . Using (3.27) for the denominator and regarding the remaining part (the

numerator) of the summands as some trial function  $f(\lambda)$ , we transform this sum using the Dirac  $\delta$ -function as follows:

$$\sum_{m=0}^{N} \frac{f(\Lambda_m)}{P'(\Lambda_m)} = \int_{-\infty}^{+\infty} d\lambda \sum_{m=0}^{N} \frac{\delta(\lambda - \Lambda_m)}{P'(\Lambda_m)} f(\lambda) = \int_{-\infty}^{+\infty} d\lambda \sum_{m=0}^{N} \delta(P(\lambda) - P(\Lambda_m)) f(\lambda)$$

$$= \frac{L}{2} \int_{-\infty}^{+\infty} d\lambda \sum_{m=0}^{N} \delta\left(\sum_{j=1}^{N+1} \alpha_j(\lambda) + \pi m\right) f(\lambda)$$

$$= \frac{L}{4\pi} \int_{-\infty}^{+\infty} d\lambda \int_{-\infty}^{+\infty} ds \frac{1 - e^{i(N+1)\pi s}}{1 - e^{i\pi s}} \exp\left\{is \sum_{j=1}^{N+1} \alpha_j(\lambda)\right\} f(\lambda). \quad (3.28)$$

Here we used relations (3.26) and (3.25) and at the last step we replaced the Dirac  $\delta$ -function by its Fourier transform, to bring the dependence on the  $k_j(\lambda)$ 's (defining the  $\alpha_j(\lambda)$ 's) in a factorized form.

As a result, taking into account (3.17), we have the following representation for the impurity Green's function of the finite system

$$G_{\downarrow,N}(x,t|\{q\}) = \frac{aL}{4\pi} \int_{-\infty}^{+\infty} d\lambda \int_{-\infty}^{+\infty} ds \, \frac{1 - e^{i(N+1)\pi s}}{1 - e^{i\pi s}} \, \Xi_N(x,t|\{q\},\lambda;s), \tag{3.29}$$

where

$$\Xi_{N}(x,t|\{q\},\lambda;s) = \frac{(N+1)!}{L^{2N+1}} \sum_{k_{1}(\lambda)} \cdots \sum_{k_{N+1}(\lambda)} \prod_{j=1}^{N+1} \frac{1}{u_{j}(\lambda)} \times F_{N}^{2}(\{q\}|\{k\}) \exp\left\{i \sum_{j=1}^{N} \tau(q_{j}) - i \sum_{j=1}^{N+1} \left[\tau(k_{j}(\lambda)) - s\alpha_{j}(\lambda)\right]\right\}.$$
(3.30)

Here each sum is performed over all the values of the momentum  $k_j(\lambda)$  defined in (3.20) as the corresponding  $n_j$  runs over all integer values.

The expression (3.30) can be written in terms of determinants of  $N \times N$  matrices, using the procedure of "insertion of the summation in the determinant" similarly to the infinite coupling case [19,39]. Using the total symmetry in permutation of the momenta  $k_1, \ldots, k_{N+1}$  of the general term of the sum in (3.30), one of the functions  $F_N(\{q\}|\{k\})$ , when represented as the determinant (3.11), can be replaced by the product

$$F_N(\{q\}|\{k\}) \longrightarrow (N+1)! \, 2^N \prod_{j=1}^N \frac{1}{q_j - k_j},$$
 (3.31)

while the second one, when using (3.10), can be written as a sum of two terms

$$F_N(\{q\}|\{k\}) = 2^N \left[ \det_{1 \le j, l \le N} \left( \frac{1}{q_j - k_l} - \frac{1}{q_j - k_{N+1}} \right) - \det_{1 \le j, l \le N} \left( \frac{1}{q_j - k_l} \right) \right] + 2^N \det_{1 \le j, l \le N} \left( \frac{1}{q_j - k_l} \right). \quad (3.32)$$

Since the matrix with the entries  $1/(q_j - k_{N+1})$  has rank one, the first term in this sum is a homogeneous linear function of its entries while the second term is independent of this momentum. This makes it possible to perform the summation with respect to  $k_{N+1}$ . The summation with respect to the remaining momenta  $k_1, \ldots, k_N$  are performed in the usual way.

As a result, the quantity  $\Xi_N(x,t|\{q\},\lambda;s)$  is given in terms of determinants of  $N\times N$  matrices:

$$\Xi_N(x,t|\{q\},\lambda;s) = \det(S-R) + (G(x,t;\lambda;s)-1)\det S.$$
 (3.33)

The matrix  $S = S(x, t|\{q\}, \lambda; s)$  has entries

$$S_{jl} = \frac{4e^{i(\tau(q_j) + \tau(q_l))/2}}{L^2} \sum_{k(\lambda)} \frac{e^{-i\tau(k(\lambda)) + is\alpha(k(\lambda), \lambda)}}{u(k(\lambda), \lambda)(k(\lambda) - q_j)(k(\lambda) - q_l)}$$
(3.34)

and the matrix  $R = R(x,t|\{q\},\lambda;s)$ , of rank one, has entries

$$R_{jl} = \frac{4e^{i(\tau(q_j) + \tau(q_l))/2}}{L^3} \sum_{k(\lambda)} \frac{e^{-i\tau(k(\lambda)) + is\alpha(k(\lambda), \lambda)}}{u(k(\lambda), \lambda)(k(\lambda) - q_j)} \sum_{k(\lambda)} \frac{e^{-i\tau(k(\lambda)) + is\alpha(k(\lambda), \lambda)}}{u(k(\lambda), \lambda)(k(\lambda) - q_l)}.$$
(3.35)

The function  $G(x,t;\lambda;s)$  is

$$G(x,t;\lambda;s) = \frac{1}{L} \sum_{k(\lambda)} \frac{e^{-i\tau(k(\lambda)) + is\alpha(k(\lambda),\lambda)}}{u(k(\lambda),\lambda)}.$$
 (3.36)

The functions  $\alpha(k,\lambda)$  and  $u(k,\lambda)$  are defined in (3.21) and (3.22), respectively; the dependence on x and t is contained in the function  $\tau(k) = tk^2 - xk$ .

# 4. Results in the thermodynamic limit

The thermodynamic limit is the limit in which  $L, N \to \infty$  with the ratio N/L kept constant. A convenient property of the representation (3.29) is that in this limit it contains the Dirac  $\delta$ -function:

$$\frac{1 - e^{i(N+1)\pi s}}{1 - e^{i\pi s}} \to 2\delta(s), \qquad N \to \infty.$$
 (4.1)

Hence, in the deriving a thermodynamic limit expression for the Green's function we can restrict ourselves in obtaining that of the quantity  $\Xi_N(x,t|\{q\},\lambda;s)|_{s=0}$ .

To derive an thermodynamic limit expression for this quantity, let us study the matrices  $S = S(x,t|\{q\},\lambda;s)$  and  $R = R(x,t|\{q\},\lambda;s)$  entering representation (3.33), specifying everywhere s=0. We first consider the matrix S. It is useful to consider separately its off-diagonal and diagonal entries. For the off-diagonal entries, since  $q_j \neq q_l$  for  $j \neq l$ , we can use the relation

$$\frac{1}{k(\lambda)-q_j}\frac{1}{k(\lambda)-q_l} = \frac{1}{q_j-q_l}\left(\frac{1}{k(\lambda)-q_j} - \frac{1}{k(\lambda)-q_l}\right),\tag{4.2}$$

and represent them in the form

$$S_{jl} = \frac{2}{L} e^{i(\tau(q_j) + \tau(q_l))/2} \frac{E(q_j|\lambda) - E(q_l|\lambda)}{q_j - q_l}, \qquad j \neq l.$$
 (4.3)

Here the function  $E(q|\lambda)$ ,  $q \in \mathbb{R}$ , is given by the expression

$$E(q|\lambda) = \frac{2}{L} \sum_{k(\lambda)} \frac{1}{k(\lambda) - q} \left( \frac{e^{-i\tau(k(\lambda))}}{u(k(\lambda), \lambda)} - \frac{e^{-i\tau(q)}}{u(q, \lambda)} \right) + \frac{2(q - \lambda)e^{-i\tau(q)}}{cu(q, \lambda)}. \tag{4.4}$$

For  $q = q_j$ , where  $q_j$  is one of the momenta in the set  $\{q\}$  of the sector (N,0), it evaluates as

$$E(q_j|\lambda) = \frac{2}{L} \sum_{k(\lambda)} \frac{e^{-i\tau(k(\lambda))}}{(k(\lambda) - q_j)u(k(\lambda), \lambda)},$$
(4.5)

so (4.3) reproduces (3.34) for  $j \neq l$ . Note, that the function  $E(q|\lambda)$  is well-defined for arbitrary real values of q; the expression in (4.4) follows upon extracting a formal singularity at  $k(\lambda) = q_j$  of the sum over  $k(\lambda)$  in (4.5), using a summation formula for  $\sum_{k(\lambda)} 1/(k(\lambda) - q_j)$ , see formula (A.10) of the appendix. Similarly, for the diagonal entries of the matrix S we obtain

$$S_{jj} = \frac{4e^{-i\tau(q_{j})}}{L^{2}} \sum_{k(\lambda)} \frac{1}{(k(\lambda) - q_{j})^{2}} \times \left\{ \frac{e^{-i\tau(k(\lambda))}}{u(k(\lambda), \lambda)} - \frac{e^{-i\tau(q_{j})}}{u(q_{j}, \lambda)} \left[ 1 + (k(\lambda) - q_{j}) \left( -i\tau'(q_{j}) - \frac{u'(q_{j}, \lambda)}{u(q_{j}, \lambda)} \right) \right] \right\} + \left[ 1 + 2a + \frac{4(q_{j} - \lambda)^{2}}{c^{2}} + a(q_{j} - \lambda) \left( -i\tau'(q_{j}) - \frac{u'(q_{j}, \lambda)}{u(q_{j}, \lambda)} \right) \right] \frac{1}{u(q_{j}, \lambda)} = 1 + \frac{2}{L} e^{i\tau(q_{j})} \partial_{q} E(q|\lambda)|_{q=q_{j}}. \quad (4.6)$$

Here the first equality follows from (3.34) at j = l by extracting a double-pole singularity using a summation formula for  $\sum_{k(\lambda)} 1/(k(\lambda) - q)^2$ , see (A.13), and the second equality follows just by comparing the result with (4.4). Introducing the function

$$V(q, q') = \frac{2}{L} e^{i(\tau(q) + \tau(q'))/2} \frac{E(q|\lambda) - E(q'|\lambda)}{q - q'}, \qquad q, q' \in \mathbb{R}, \tag{4.7}$$

we conclude that

$$S_{il} = \delta_{il} + V(q_i, q_l). \tag{4.8}$$

In other words, S = I + V, where the matrix V has entries  $V_{jl} = V(q_j, q_l)$ . In similar manner, introducing the function

$$R(q, q') = \frac{1}{L} e^{i(\tau(q) + \tau(q'))/2} E(q|\lambda) E(q'|\lambda), \qquad q, q' \in \mathbb{R}, \tag{4.9}$$

for the entries of the matrix R we have

$$R_{il} = R(q_i, q_l). \tag{4.10}$$

We note that, as a result, the matrices V and R are expressed in terms of the functions V(q, q') and R(q, q'), which are well-defined for their arguments taking arbitrary real values. We also note that the entries of the matrices V and R are all of order 1/L, as L is large.

Having all this in mind, we are now ready to address the problem of deriving the thermodynamic limit of the quantity  $\Xi_N(x,t|\{q\},\lambda;s)\big|_{s=0}$ . Consider the determinant of the matrix S=I+V; the case of the matrix S-R=I+V-R is similar. We have

$$\det(I+V) = \sum_{p=0}^{N} \frac{1}{p!} \sum_{q_{j_1} \in \{q\}} \cdots \sum_{q_{j_p} \in \{q\}} \det_{1 \le a, b \le p} V(q_{j_a}, q_{j_b}). \tag{4.11}$$

Here each summation is performed over elements in the set  $\{q\}$ ; in the thermodynamic limit the summations turn into integrations. To define the integrals, we need now specify the values of the momenta in the set  $\{q\}$ . Recall that we are interested in the Green's function of the ground state  $|\Omega_{\uparrow}\rangle = |\Psi_{N,0}(\{q\})\rangle$ , in which the momenta in the set  $\{q\}$  satisfy the relations  $q_{j+1}-q_j=2\pi/L$ ,  $q_1\geq -k_{\rm F}$ ,  $q_N\leq k_{\rm F}$ , where  $k_{\rm F}=\pi N/L$ . In the thermodynamic limit the quasi-momenta in the set  $\{q\}$  are uniformly distributed along the interval  $[-k_{\rm F},k_{\rm F}]$ . Hence,

$$\frac{1}{L} \sum_{q_j \in \{q\}} \longrightarrow \frac{1}{2\pi} \int_{-k_F}^{k_F} dq \tag{4.12}$$

Correspondingly, let us introduce the function

$$\mathcal{V}(q, q') = \lim_{L, N \to \infty} \frac{L}{2\pi} V(q, q'). \tag{4.13}$$

Then, evaluating the limit, we obtain

$$\lim_{L,N\to\infty} \det(I+V) = \sum_{p=0}^{\infty} \frac{1}{p!} \int_{[-k_{\mathrm{F}},k_{\mathrm{F}}]^p} \mathrm{d}q^p \det_{1\leq a,b\leq p} \mathcal{V}(q_{j_a},q_{j_b}) = \det(1+\mathcal{V}). \quad (4.14)$$

Here the second equality follows from the definition of the Fredholm determinant of a linear integral operator  $\mathcal{V}$ ; the function  $\mathcal{V}(q, q')$  is the kernel of the operator, which is defined to act on functions in the interval  $[-k_{\rm F}, k_{\rm F}]$ ,

$$(\mathcal{V}f)(q) = \int_{-k_{\text{F}}}^{k_{\text{F}}} \mathrm{d}q' \, \mathcal{V}(q, q') f(q'). \tag{4.15}$$

Similarly to (4.14), we have

$$\lim_{L,N\to\infty} \det(I+V-R) = \det(1+\mathcal{V}-\mathcal{R}),\tag{4.16}$$

where the kernel of the operator  $\mathcal{R}$  is defined by

$$\mathcal{R}(q, q') = \lim_{L, N \to \infty} \frac{L}{2\pi} R(q, q'). \tag{4.17}$$

Explicitly, the linear integral operator V entering (4.14) and (4.16) possesses the kernel

$$V(q, q') = \frac{1}{\pi} e^{i(\tau(q) + \tau(q'))/2} \frac{e(q|\lambda) - e(q'|\lambda)}{q - q'},$$
(4.18)

and the operator  $\mathcal{R}$ , entering (4.16), possesses the kernel

$$\mathcal{R}(q, q') = \frac{1}{2\pi} e^{i(\tau(q) + \tau(q'))/2} e(q|\lambda) e(q'|\lambda). \tag{4.19}$$

Here the function  $e(q|\lambda) = e(q|x,t;\lambda)$  is the thermodynamic limit of the function  $E(q|\lambda)$ ,

$$e(q|\lambda) = \lim_{L \to \infty} E(q|\lambda).$$
 (4.20)

If we also define the function  $g(x,t|\lambda)$  as the thermodynamic limit of the function  $G(x,t;\lambda;s)|_{s=0}$ ,

$$g(x,t;\lambda) = \lim_{L \to \infty} G(x,t;\lambda;0), \tag{4.21}$$

then we have the following expression for the quantity  $\Xi_N(x,t|\{q\},\lambda;s)\big|_{s=0}$  in the thermodynamic limit:

$$\lim_{L,N\to\infty} \Xi_N(x,t|\{q\},\lambda;0)\big|_{s=0} = \det(1+\mathcal{V}-\mathcal{R}) + (g(x,t;\lambda)-1)\det(1+\mathcal{V}).$$
(4.22)

We recall that the linear integral operators  $\mathcal{V}$  and  $\mathcal{R}$  depend on x, t, and  $\lambda$  via the functions defining their kernels; they also depend implicitly on the Fermi momentum  $k_{\rm F}$ , defining the interval  $[-k_{\rm F}, k_{\rm F}]$  where these operators act.

To finalize our calculation we have to derive the functions  $e(q|\lambda)$  and  $g(x,t;\lambda)$ . These functions contains summation over all values of the momentum  $k(\lambda) = 2z_n(\lambda)/L$ , where  $z_n(\lambda)$  is the solution of (3.18), as n runs over all integer values,

$$\sum_{k(\lambda)} f(k(\lambda)) = \sum_{n \in \mathbb{Z}} f(2z_n(\lambda)/L). \tag{4.23}$$

In the thermodynamic limit the sum turns into an integral. To obtain the limit, we need to find a distribution of the values of the momentum  $k(\lambda)$ . Denoting the value of  $k(\lambda)$  for given n as  $[k(\lambda)]_n = 2z_n(\lambda)/L$ , we can define the density

$$\rho([k(\lambda)]_n) = \frac{1}{L([k(\lambda)]_{n+1} - [k(\lambda)]_n)}.$$
(4.24)

The sum turns into an integral by the rule

$$\frac{1}{L} \sum_{k(\lambda)} \longrightarrow \int_{-\infty}^{+\infty} \mathrm{d}k \, \rho(k). \tag{4.25}$$

Using that  $z_{n+1}(\lambda) = z_n(\lambda) + (2\rho([k(\lambda)]_n))^{-1}$  and recalling that a = 4/Lc, from (3.18) we get

$$z_{n+1}(\lambda) - z_n(\lambda) = \pi - \frac{1}{1 + (az_n(\lambda) - 2\lambda/c)^2} \frac{a}{2\rho([k(\lambda)]_n)} + O(a^2).$$
 (4.26)

Replacing the left-hand side by  $(2\rho([k(\lambda)]_n))^{-1}$ , we obtain

$$2\pi\rho([k(\lambda)]_n) = 1 + \frac{a}{1 + 4([k(\lambda)]_n - \lambda)^2/c^2} + O(a^2).$$
 (4.27)

In the thermodynamic limit we have  $a \to 0$ , so we obtain  $\rho(k) = (2\pi)^{-1}$ . Taking also into account the explicit expression for the function  $u(k,\lambda)$ , see (3.21), for the function  $g(x,t;\lambda)$  we obtain

$$g(x,t;\lambda) = \frac{1}{2\pi} \int_{-\infty}^{+\infty} dk \, \frac{e^{-i\tau(k)}}{1 + 4(k-\lambda)^2/c^2}.$$
 (4.28)

In turn, for the function  $e(q|\lambda) = e(q|x, t; \lambda)$  we have

$$e(q|\lambda) = \frac{1}{\pi} \int_{-\infty}^{+\infty} dk \frac{e^{-i\tau(k)}}{(k-q)(1+4(k-\lambda)^2/c^2)} + \frac{2(q-\lambda)e^{-i\tau(q)}}{\pi c(1+4(q-\lambda)^2/c^2)}, \quad (4.29)$$

where the integral has to be interpreted as a Cauchy principal value.

We may now summarize our results about the Green's function (1.3). Its is given in the thermodynamic limit in terms of an integral of Fredholm determinants:

$$G_{\downarrow}(x,t) = \frac{2}{\pi c} \int_{-\infty}^{+\infty} d\lambda \left\{ \det \left( 1 + \mathcal{V} - \mathcal{R} \right) + \left( g(x,t;\lambda) - 1 \right) \det \left( 1 + \mathcal{V} \right) \right\}. \tag{4.30}$$

The integral operators  $\mathcal{V} = \mathcal{V}(x,t;\lambda)$  and  $\mathcal{R} = \mathcal{R}(x,t;\lambda)$  act on functions in the interval  $[-k_{\rm F},k_{\rm F}]$ , see (4.15), and possess kernels

$$\mathcal{V}(q, q') = \frac{e_{+}(q|\lambda)e_{-}(q') - e_{-}(q)e_{+}(q'|\lambda)}{\pi(q - q')}, \qquad \mathcal{R}(q, q') = \frac{e_{+}(q|\lambda)e_{+}(q'|\lambda)}{2\pi}. \tag{4.31}$$

The functions defining the kernels are

$$e_{+}(q|\lambda) = e_{-}(q) e(q|\lambda), \qquad e_{-}(q) = e^{i\tau(q)/2}.$$
 (4.32)

The functions  $g(x,t;\lambda)$  and  $e(q|\lambda)=e(q|x,t;\lambda)$  are given by (4.28) and (4.29), respectively, and

$$\tau(q) = tq^2 - xq. \tag{4.33}$$

Representation (4.30) is our main result. Let us discuss it in two special cases, namely, in the case of equal time, t = 0, and in the limit of infinite coupling,  $c \to \infty$ .

At t = 0 the anticommutation relations (1.2) give  $G_{\downarrow}(x,t) = \delta(x)$ . To show how this expression follows from (4.30), we first note that at t = 0 the integrals in (4.28) and (4.29) can be explicitly evaluated and the results read

$$g(x,0;\lambda) = \frac{c}{4} e^{ix\lambda - c|x|/2}, \qquad e(q|x,0;\lambda) = c \frac{e^{iqx} - e^{ix\lambda - c|x|/2}}{2q - 2\lambda - ic\operatorname{sgn}(x)}.$$
 (4.34)

Now, we employ the definition of the Fredholm determinant as the expansion (4.14). One can notice that after integration over  $\lambda$  in (4.30) all terms with  $p \geq 1$  in this expansion will vanish since all the singularities of the integrand lie in the lower (respectively, upper) half-plane of the complex variable  $\lambda$  for x > 0 (x < 0), while due to the structure of the exponent  $e^{i\lambda x}$  the contour of integration can be shrunk in the upper (lower)  $\lambda$  half-plane. Finally, the p = 0 term gives

$$G_{\downarrow}(x,0) = \frac{2}{\pi c} \int_{-\infty}^{+\infty} d\lambda \, g(x,0;\lambda) = \frac{e^{-c|x|/2}}{2\pi} \int_{-\infty}^{+\infty} d\lambda \, e^{ix\lambda} = \delta(x), \tag{4.35}$$

and the equal-time expression is reproduced.

Let us now consider the case of the limit  $c \to \infty$ . Setting

$$\lambda = -\frac{c}{2}\cot\vartheta\tag{4.36}$$

and sending c to infinity, we get

$$\lim_{c \to \infty} g(x, t; \lambda) = \sin^2 \theta \cdot g_{\infty}(x, t), \qquad g_{\infty}(x, t) = \frac{1}{2\pi} \int_{-\infty}^{+\infty} dk e^{-i\tau(k)}, \qquad (4.37)$$

and

$$\lim_{c \to \infty} e(q|\lambda) = \frac{\sin^2 \theta}{\pi} \int_{-\infty}^{+\infty} dk \, \frac{e^{-i\tau(k)}}{k-q} + \sin \theta \cos \theta \, e^{-i\tau(q)} =: e_{\infty}(q|\theta). \tag{4.38}$$

Therefore, for the impurity Green's function in the  $c \to \infty$  limit we obtain the following expression

$$\lim_{c \to \infty} G_{\downarrow}(x,t) = \frac{1}{\pi} \int_{0}^{\pi} d\vartheta \left\{ \det \left( 1 + \mathcal{V}_{\infty} - \mathcal{R}_{\infty} \right) + \left( g_{\infty}(x,t) - 1 \right) \det \left( 1 + \mathcal{V}_{\infty} \right) \right\},$$
(4.39)

where the operators  $\mathcal{V}_{\infty} = \mathcal{V}_{\infty}(x,t;\vartheta)$  and  $\mathcal{R}_{\infty} = \mathcal{R}_{\infty}(x,t;\vartheta)$  possess kernels

$$\mathcal{V}_{\infty}(q,q') = \frac{\ell_{+}(q|\vartheta)\ell_{-}(q') - \ell_{-}(q)\ell_{+}(q'|\vartheta)}{\pi(q-q')}, \qquad \mathcal{R}_{\infty}(q,q') = \frac{\ell_{+}(q|\vartheta)\ell_{+}(q'|\vartheta)}{2\pi\sin^{2}\vartheta}, \tag{4.40}$$

and the functions  $\ell_+(q|\vartheta)$  and  $\ell_-(q)$  are

$$\ell_{+}(q|\theta) = \ell_{-}(q) e_{\infty}(q|\theta), \qquad \ell_{-}(q) = e_{-}(q).$$
 (4.41)

The representation (4.39) is the correlation function  $G_2^{(+)}(x,t;h,B)$  of paper [19] at zero temperature in the case of a negative magnetic field B (see [19], Eqs. (6.9)–(6.11)), evaluated at vanishing chemical potential, h=0, and  $B\to 0$ . Hence, the known result for the Green's function (1.3) at  $c=\infty$  is reproduced.

### 5. Conclusion

In this paper, we presented a closed-form analytic expression for the impurity Green's function in a one-dimensional Fermi gas at zero temperature. A single impurity interacts with gas particles through repulsive  $\delta$ -function potential of arbitrary strength. This model is exactly solvable and constitutes a particular case of the model with Hamiltonian (1.1), for which Bethe Ansatz eigenstates have the so-called "nested" form.

Nested Bethe Ansatz wave functions are built for models containing particles of more that one type (e.g., two types of fermions, which are often referred to as spin-up and spin-down). These wave functions are known in a form very distinct from a single Slater determinant representation for the wave functions of the free Fermi gas. However, when only one impurity (particle of other type) is added to a free Fermi gas, any Bethe Ansatz wave function may be represented as a single determinant.

We discussed single determinant representation of the wave functions in Sec. 2 of the paper. Clearly, such a representation greatly simplifies calculations of form factors of local operators, and, ultimately, correlation functions, as may be seen from Sec. 3. There we represented Green's function (1.3) as an infinite sum of the determinants of  $N \times N$  matrices, where N is the number of Fermi gas particles. In the thermodynamic limit of  $N \to \infty$  at a constant gas density the impurity Green's function is given as an integral of some Fredholm determinants, as discussed in Sec. 4.

The Fredholm determinant representation, (4.30), of the Green's function (1.3) is the main result of the present paper. This representation extends our understanding of quantum interacting systems in one dimension in a number of ways.

First, Fredholm determinant representations were so far known for those systems with short-range interaction potential whose wave functions vanish when any two particles approach each other. Wave functions of a free Fermi gas is the basic example of such functions; they all are often put under the name "free-fermion-like wave functions". Wave function of the impurity model considered in the present

paper does not vanish as the impurity approaches any gas particle. We thus found a Fredholm determinant representation for Green's function in not-free-fermion-like model.

Second, Fredholm determinant may be viewed as just a special function in that it can be calculated numerically and tabulated for any finite range of the parameters entering its kernel. Therefore, the expression for the impurity Green's function given here can be used in comparisons of other methods against an exact result.

Third, as far as the representation for the Green's function involves Fredholm determinants of linear integral operators of the so-called integrable type, the standard technique of the analysis of such objects based on the matrix Riemann-Hilbert problem can be applied. This would make it possible for evaluation of asymptotics of the impurity Green's function at long time and large distance separations.

# Acknowledgments

The work of O.G. is supported by the European Research Council, Grant No. 279738-NEDFOQ. The work of A.G.P. is partially supported by the Russian Science Foundation, Grant No. 14-11-00598.

## Appendix A. Summation formulas

To transform the matrices S and R, see (3.34) and (3.35), in a form regular in the thermodynamic limit we used two summation formulas in Sec. 4. Consider the function

$$g(z,\lambda) = \sum_{n} \frac{1}{z - z_n(\lambda)}, \qquad z \in \mathbb{C},$$
 (A.1)

where the sum is taken over all solutions of (3.18). It is assumed that the summation is organized in a such way that the sum is convergent, thus defining g(z, λ) as a meromorphic function in z with simple poles at points zn(λ), n ∈ Z, with the principal parts 1/(z − zn(λ)) at these points. The summation formulas used in Sec. 4 can be obtained from expressions for g(z, λ) and ∂zg(z, λ) at z = Lq/2, where q is a solution of the Bethe Ansatz equations in the sector (N, 0), given by (2.8).

To derive an explicit form of the function g(z, λ) it is useful to look at zn(λ)'s as zeros of some entire function (see, e.g., [40], Vol. II, Chap. 10). In our case this entire function can be easily inferred from (3.18) to be

$$f(z,\lambda) = \cos z - \left(az - \frac{2\lambda}{c}\right)\sin z.$$
 (A.2)

Recalling that a = 4/Lc, we have the functional relation

$$f(z+\pi,\lambda) = -f(z,\lambda - 2\pi/L). \tag{A.3}$$

Correspondingly, zeros satisfy

$$z_{n+1}(\lambda) = \pi + z_n(\lambda - 2\pi/L), \tag{A.4}$$

that can also be seen directly from (3.18). Writing zn(λ) = πn+z0(λ−2πn/L), and taking into account that z0(λ) ∈ [0, π], one can construct from (3.18) an estimate for zn(λ) as n → ±∞. Namely, we have

$$z_{n+1}(\lambda) - z_n(\lambda) = \pi + O(1/n), \qquad n \to \pm \infty.$$
 (A.5)

This estimate allows one to represent the entire function  $f(z,\lambda)$  as an infinite product. Indeed, the estimate shows that the series  $\sum_n 1/z_n^2(\lambda)$  converges, and function (A.2) can be written as an infinite product, similarly to the well-known example of the sine function. By Borel's theorem for representation of an entire function as an infinite product we have the following formula

$$f(z,\lambda) = e^{2\lambda z/c} \prod_{n} \left( 1 - \frac{z}{z_n(\lambda)} \right) e^{z/z_n(\lambda)}.$$
 (A.6)

Comparing (A.1) and (A.6) we conclude (see also [40], Vol. II, Sec. 51, ex. 2) that

$$g(z,\lambda) = \frac{\partial_z f(z,\lambda)}{f(z,\lambda)}.$$
 (A.7)

Substituting (A.2) into (A.7), we obtain that the function  $g(z, \lambda)$  has the following explicit form

$$g(z,\lambda) = -\frac{(1+a)\sin z + (az - 2\lambda/c)\cos z}{\cos z - (az - 2\lambda/c)\sin z}.$$
(A.8)

Note that this expression is in agreement with the special case  $\lambda \to \pm \infty$ , in which the zeros  $z_n(\lambda)$  tend to those of  $\sin z$ , and hence  $g(z,\lambda) \to \cot z$ .

Now we are ready to obtain the summation formulas used in Sec. 4. Setting  $z = Lq_j/2$ , where  $q_j$  is a momentum belonging to the set momenta  $\{q\}$  of the sector (N,0), we have

$$\frac{2}{L} \sum_{k(\lambda)} \frac{1}{k(\lambda) - q_j} = \sum_{n} \frac{1}{z_n(\lambda) - Lq_j/2} = -g(z, \lambda)|_{z = Lq_j/2}.$$
 (A.9)

Since  $q_j = 2\pi m_j/L$ ,  $m_j \in \mathbb{Z}$ , we have  $\sin(Lq_j/2) = \sin \pi m_j = 0$  and  $\cos(Lq_j/2) = \cos \pi m_j = (-1)^{m_j}$ , and we obtain the first formula

$$\frac{2}{L} \sum_{k(\lambda)} \frac{1}{k(\lambda) - q_j} = \frac{2(q_j - \lambda)}{c},\tag{A.10}$$

where we have used that a = 4/Lc.

The second formula, relevant for the diagonal entries of the matrix S, follows from the derivative of the function  $g(z, \lambda)$ ,

$$\frac{4}{L^2} \sum_{k(\lambda)} \frac{1}{(k(\lambda) - q_j)^2} = -\partial_z g(z, \lambda) \big|_{z = Lq_j/2}. \tag{A.11}$$

We have

$$\partial_z g(z,\lambda) = \frac{\partial_z^2 f(z,\lambda) f(z,\lambda) - (\partial_z f(z,\lambda))^2}{f^2(z,\lambda)} = -\frac{1 + 2a + (az - 2\lambda/c)^2 + a^2 \sin^2 z}{(\cos z - (az - 2\lambda/c)\sin z)^2}.$$
(A.12)

Hence,

$$\frac{4}{L^2} \sum_{k(\lambda)} \frac{1}{(k(\lambda) - q_j)^2} = 1 + 2a + \frac{4(q_j - \lambda)^2}{c^2}.$$
 (A.13)

## References

- [1] J. B. McGuire, Interacting fermions in one dimension. I. Repulsive potential, J. Math. Phys. 6 (1965), 432–439.
- [2] D. M. Edwards, Magnetism in single-band models, Prog. Theor. Phys. Suppl. 101 (1990), 453–461.
- [3] H. Castella and X. Zotos, Exact calculation of spectral properties of a particle interacting with a one-dimensional fermionic system, Phys. Rev. B 47 (1993), 16186.
- [4] C. Recher and H. Kohler, From hardcore bosons to free fermions with Painlev´e V, J. Stat. Phys. 147 (2012), 542–564, arXiv:1111.2972.
- [5] C. N. Yang, Some exact results for the many-body problem in one dimension with repulsive delta-function interaction, Phys. Rev. Lett. 19 (1967), 1312–1314.
- [6] M. Gaudin, The Bethe Wavefunction, Cambridge University Press, Cambridge, 2014.
- [7] T. D. Schultz, Note on the one-dimensional gas of impenetrable point-particle bosons, J. Math. Phys. 4 (1963), 666–671.
- [8] A. Lenard, Momentum distribution in the ground state of the one-dimensional system of impenetrable bosons, J. Math. Phys. 5 (1964), 930–943.
- [9] A. Lenard, One-dimensional impenetrable bosons in thermal equilibrium, J. Math. Phys. 7 (1966), 1268–1272.
- [10] M. Sato, T. Miwa, and M. Jimbo, Holonomic quantum fields, Publ. RIMS, Kyoto Univ. 15 (1979), 201–227.
- [11] M. Jimbo, T. Miwa, Y. Mori, and M. Sato, Density matrix of an impenetrable Bose gas and the fifth Painlev´e transcendent, Physica D 1 (1980), 80–158.
- [12] A. R. Its, A. G. Izergin, V. E. Korepin, and N. A. Slavnov, Differential equations for quantum correlation functions, Int. J. Mod. Phys. B 4 (1990), 1003–1037.
- [13] V. E. Korepin, N. M. Bogoliubov, and A. G. Izergin, Quantum Inverse Scattering Method and Correlation Functions, Cambridge University Press, Cambridge, 1993.
- [14] P. A. Deift, A. R. Its, and X. Zhou, A Riemann-Hilbert approach to asymptotic problems arising in the theory of random matrix models, and also in the theory of integrable statistical mechanics, Ann. of Math. 146 (1997), 149–235.
- [15] N. Kitanine, K. K. Kozlowski, J. M. Maillet, N. A. Slavnov, and V. Terras, Riemann-Hilbert approach to a generalised sine kernel and applications, Comm. Math. Phys. 291 (2009), 691– 761, arXiv:0805.4586.
- [16] N. A. Slavnov, Integral operators with the generalized sine kernel on the real axis, Theor. Math. Phys. 165 (2010), 1262–1274, arXiv:1005.5047.
- [17] K. K. Kozlowski, Riemann-Hilbert approach to the time-dependent generalized sine kernel, Adv. Theor. Math. Phys. 15 (2011), 1655–1743, arXiv:1011.5897.
- [18] A. G. Izergin and A. G. Pronko, Correlators in the one-dimensional two-component Bose and Fermi gases, Phys. Lett. A 236 (1997), 445–454.
- [19] A. G. Izergin and A. G. Pronko, Temperature correlators in the two-component onedimensional gas, Nucl. Phys. B 520 (1998), 594–632, arXiv:solv-int/9801004.
- [20] A. G. Izergin, A. G. Pronko, and N. I. Abarenkova, Temperature correlators in the onedimensional Hubbard model in the strong coupling limit, Phys. Lett. A 245 (1998), 537–547, arXiv:hep-th/9801167.
- [21] N. I. Abarenkova, A. G. Izergin, and A. G. Pronko, Correlators of the ladder spin model in the strong coupling limit, J. Math. Sci. 104 (2001), 1087–1096.
- [22] F. G¨ohmann, A.G. Izergin, V.E. Korepin, and A.G. Pronko, Time and temperature dependent correlation functions of the 1D impenetrable electron gas, Int. J. Mod. Phys. B, 12 (1998) 2409 12 (1998), 2409–2433, arXiv:cond-mat/9805192.
- [23] F. G¨ohmann, A. R. Its, and V. E. Korepin, Correlations in the impenetrable electron gas, Phys. Lett. A 249 (1998), 117, arXiv:cond-mat/9809076.
- [24] V. V. Cheianov and M. B. Zvonarev, Zero temperature correlation functions for the impenetrable fermion gas, J. Phys. A 37 (2004), 2261–2297, arXiv:cond-mat/0310499.
- [25] V. V. Cheianov and M. B. Zvonarev, Nonunitary spin-charge separation in a one-dimensional Fermion gas, Phys. Rev. Lett. 92 (2004), 176401, arXiv:cond-mat/0308470.
- [26] F. G¨ohmann and V.E. Korepin, Universal correlations of one-dimensional interacting electrons in the gas phase, Phys. Lett. A 260 (1999), 516–521, arXiv:cond-mat/9906052.

- [27] V. V. Cheianov, H. Smith, and M. B. Zvonarev, Low-temperature crossover in the momentum distribution of cold atomic gases in one dimension, Phys. Rev. A 71 (2005), 033610, arXiv: cond-mat/0408169.
- [28] V. V. Cheianov and M. B. Zvonarev, One-particle equal time correlation function for the spin-incoherent infinite U Hubbard chain, Jour. Phys. A 41 (2008), 045002, arXiv: cond-mat/0311256.
- [29] M. B. Zvonarev, V. V. Cheianov, and T. Giamarchi, Dynamical properties of the onedimensional spin-1/2 Bose-Hubbard model near Mott-insulator to ferromagnetic liquid transition, Phys. Rev. Lett. 103 (2009), 110401, arXiv:0811.2676.
- [30] A. Lamacraft, Dispersion relation and spectral function of an impurity in a one-dimensional quantum liquid, Phys. Rev. B 79 (2009), 241105(R), arXiv:0810.4163.
- [31] C. J. M. Mathy, M. B. Zvonarev, and E. Demler, Quantum flutter of supersonic particles in one-dimensional quantum liquids, Nature Phys. 8 (2012), 881–886, arXiv:1203.4819.
- [32] M. Schecter, D.M. Gangardt, and A. Kamenev, Dynamics and Bloch oscillations of mobile impurities in one-dimensional quantum liquids, Ann. Phys. 327 (2012), no. 3, 639–670, arXiv: 1105.6136.
- [33] M. Schecter, A. Kamenev, D. Gangardt, and A. Lamacraft, Critical velocity of a mobile impurity in one-dimensional quantum liquids, Phys. Rev. Lett. 108 (2012), 207001, arXiv: 1110.2788.
- [34] M. Knap, C. J. M. Mathy, M. Ganahl, M. B. Zvonarev, and E. Demler, Quantum flutter: signatures and robustness, Phys. Rev. Lett. 112 (2014), 015302, arXiv:1303.3583.
- [35] E. Burovski, V. Cheianov, O. Gamayun, and O. Lychkovskiy, Momentum relaxation of a mobile impurity in a one-dimensional quantum gas, Phys. Rev. A 89 (2014), 041601, arXiv: 1308.6147.
- [36] O. Gamayun, Quantum Boltzmann equation for a mobile impurity in a degenerate Tonks-Girardeau gas, Phys. Rev. A 89 (2014), 063627, arXiv:1402.7064.
- [37] O. Gamayun, O. Lychkovskiy, and V. Cheianov, Kinetic theory for a mobile impurity in a degenerate Tonks-Girardeau gas, Phys. Rev. E 90 (2014), 032132, arXiv:1402.6362.
- [38] A. Kantian, U. Schollw¨ock, and T. Giamarchi, Competing regimes of motion of 1D mobile impurities, Phys. Rev. Lett. 113 (2014), 070601, arXiv:1311.1825.
- [39] F. Colomo, A. Izergin, V. Korepin, and V. Tognetti, Temperature correlation functions in the XX0 Heisenberg chain. I, Theor. Math. Phys. 94 (1993), 11–38, arXiv:cond-mat/9205009.
- [40] A. I. Markushevich, Theory of Functions of a Complex Variable, 2nd ed., AMS Chelsea Publishing, 2014.

Lancaster University, Physics Department, Lancaster, LA1 4YB, UK and Bogoluibov Institute for Theoretical Physics, Metrolohichna 14-b, Kiev, 03680,Ukraine

V. A. Steklov Mathematical Institute, Fontanka 27, St. Petersburg, 191023, Russia

Univ Paris-Sud, Laboratoire LPTMS, UMR8626, Orsay, F-91405, France and CNRS, Orsay, F-91405, France