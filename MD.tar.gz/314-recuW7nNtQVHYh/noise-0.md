### Ferromagnetism in a Narrow, Almost Half-Filled s Band\*

YOSUKE NAGAOKA†

Department of Physics, University of California, San Diego, La Jolla, California (Received 17 January 1966)

We consider conduction electrons in a narrow s band with a strong repulsive potential which acts when two electrons are at the same atomic site. It is assumed that the electron-transfer matrix elements are nonvanishing only between nearest-neighbor sites, and that the band is almost half-filled, or  $|N-N_{\epsilon}| \ll N$ , N and No being, respectively, the number of atoms and electrons in the crystal. Then it is proved quite rigorously that, if the repulsive potential is sufficiently strong, the ferromagnetic state with the maximum total spin is the ground state for simple cubic and body centered cubic structures as well as for face centered cubic and hexagonal closed packed structures with  $N_e > N$ , and is not the ground state for face centered cubic and hexagonal closed packed structures with  $N_c < N$ . For the former case, it is also shown that it is not the ground state if the repulsive potential is weaker than some critical value which is of the order  $(\text{bandwidth}) \times N/|N-N_e|$ .

#### 1. INTRODUCTION

HE problem of metallic ferromagnetism has been long investigated by many authors,1-5 and various models and approximations have been proposed for it. It should be said, however, that so far we have no definite answer to the question what is essential for the appearance of ferromagnetism in metals. Therefore, it still has some meaning to study a simple model in detail and to examine whether it can be ferromagnetic or not.

Hubbard,2 Kanamori,3 and some other authors4,5 studied a simple model of a ferromagnetic metal such that conduction electrons in a narrow s band interact with one another by a strong repulsive potential of the δ-function type. The model may be best explained by writing down the Hamiltonian:

$$H = \sum_{ij} \sum_{\sigma} t_{ij} c_{i\sigma}^{\dagger} c_{j\sigma} + I \sum_{i} n_{i\uparrow} n_{i\downarrow},$$

$$(1.1)$$

where  $c_{i\sigma}^{\dagger}$  and  $c_{i\sigma}$  are, respectively, creation and annihilation operators for an electron of spin  $\sigma$  in the atomic state at the *i*th lattice site,  $t_{ij}$  is the matrix element of the electron transfer between the states at the ith and jth sites, and I is the repulsive potential which acts only when two electrons are at the same site. The model is interesting in some aspects, one of which is its simplicity. Because of its simplicity we can treat it in a rather rigorous way for some limiting cases.

To study the model, Hubbard<sup>2</sup> used the Green'sfunction method and introduced an approximation which is exact in the limit  $t_{ij} \rightarrow 0$ . Though he obtained some reasonable results, the validity of his approximation is quite obscure for finite  $t_{ij}$ . On the other hand, Kanamori<sup>3</sup> used the Brueckner approximation<sup>6</sup> for nuclear matter which is valid in the low-density limit. Therefore his theory is applicable to the case where the band is almost vacant or almost filled.

There is another interesting limiting case to which Kanamori's theory is inapplicable, i.e., the case where the band is almost half-filled. The purpose of this paper is to study this case in some detail, and to see whether the ground state of the system is ferromagnetic or not.<sup>7,8</sup> It is easily shown that, when the band is exactly halffilled, the ferromagnetic state with the maximum total spin,  $S_{\text{max}}$ , can never be the ground state. What is interesting now is the role of holes or excess electrons in an almost half-filled band.

We introduce here the following assumptions:

(a) The band is almost half-filled, or

$$|n| \ll N$$
, (1.2)

where

$$n=N-N_e$$

 $N_e$  and N being, respectively, the number of electrons and atoms in the crystal.

- (b)  $t_{ij}$  is nonvanishing only between nearest-neighbor sites, which is denoted by t(<0).
- (c) The bandwidth is narrow enough compared with the repulsive potential, or

$$|t| \ll I$$
. (1.3)

147

<sup>\*</sup> Research supported by U. S. Air Force Grant No. AF-AFOSR-610-64, Theory of Solids.

<sup>†</sup> On leave of absence from Research Institute for Fundamental Physics, Kyoto University, Kyoto, Japan. Present address: De-

Physics, Kyoto University, Kyoto, Japan. Present address: Department of Physics, Nagoya University, Nagoya, Japan.

<sup>1</sup> Some of the recent works are: D. C. Mattis, Physics 1, 183 (1964); T. Moriya, Progr. Theoret. Phys. (Kyoto) 33, 157 (1965).

Other references are cited in these papers.

<sup>2</sup> J. Hubbard, Proc. Roy. Soc. (London) A276, 238 (1963);

281, 401 (1964).

<sup>&</sup>lt;sup>8</sup> J. Kanamori, Progr. Theoret. Phys. (Kyoto) 30, 275 (1963).
<sup>4</sup> M. C. Gutzwiller, Phys. Rev. Letters 10, 159 (1963); Phys. Rev. 134, A923 (1964); 137, A1726 (1965).
<sup>5</sup> J. Callaway and D. M. Edwards, Phys. Rev. 136, A1333 (1964); J. Callaway, *ibid*. 140, A618 (1965).

<sup>&</sup>lt;sup>6</sup> K. A. Brueckner and C. A. Levinson, Phys. Rev. 97, 1344 (1955)

<sup>&</sup>lt;sup>7</sup> Thouless [D. J. Thouless (private communication); Proc. Phys. Soc. (London) 86, 893 (1965)] studied the same case quite independently by a different method, and obtained the same results as obtained here. Though his method is simpler than ours on some points, his proof seems to be incomplete as far as the present author knows it.

<sup>&</sup>lt;sup>8</sup> The preliminary report of this work was given by Y. Nagaoka, Solid State Commun. 3, 409 (1965).

(d) The crystal structure is simple cubic (sc), body centered cubic (bcc), face centered cubic (fcc), or hexagonal closed packed (hcp).

Though assumptions (b) and (d) are not necessary in some of the following arguments, we shall adopt them throughout the paper, for simplicity.

As will be shown later, the following two cases should be discussed separately:

Case A. sc and bcc; fcc and hcp with  $N_e > N$ ; Case B. fcc and hcp with  $N_e < N$ .

It is worthwhile to remark that the case  $N_e > N$  can be discussed in a parallel way to the case  $N_e < N$  by considering holes, in the former case, instead of electrons, in the latter case, and by changing the sign of t. It is also noticed here that for sc and bcc the lattice can be divided into two sublattices such that all the nearest neighbors of a lattice point on one sublattice belong to the other sublattice. Then, if we introduce an extra phase factor (-1) to the atomic wave functions at the lattice points on one sublattice, t changes its sign. Thus, without loss of generality, it can be assumed that  $N_e < N$  and that

$$t>0$$
, for Case A,  
 $t<0$ , for Case B. (1.4)

We first consider a simple case where n=1 and  $I=\infty$ . Then our conclusion is summarized as follows:

- (I) For Case A with n=1 and  $I=\infty$ , the ferromagnetic state with the maximum total spin is the ground state of the system.
- (II) For Case B with n=1 and  $I=\infty$ , the ferromagnetic state with the maximum total spin is not the ground state.

When  $n \ll N$ , it is quite reasonable to expect that the total energy is expanded with n as

$$E = E_0 + E_1(S)n + \cdots,$$
 (1.5)

where S denotes the total spin of the system. As the first term  $E_0$  is just the energy when the band is exactly half-filled, it is independent of the spin configuration if  $I = \infty$ . We put  $E_0 = 0$  by measuring the energy from  $E_0$ . The second term depends on the magnitude of the total spin. As far as this term is concerned, it is sufficient to consider the case n=1. Therefore the above theorems I and II hold even for finite n, if it is sufficiently small. To see how small it should be, we have to study higher terms in the expansion (1.5). We shall discuss this problem later for a special case.

As can be seen easily, if I if finite, it tends to destroy the ferromagnetic state. Then for Case A with finite n and I, there arises a question how large I should be for the ferromagnetic state to be the ground state. In this paper we only give a necessary condition for it. Our conclusion is as follows:

(III) For Case A with finite n and I, the ferromagnetic state with the maximum total spin is not the ground state if

$$\alpha n/N < t/I$$
, (1.6)

where  $\alpha$  is a numerical constant of the order unity, which is different for different lattice structures.

In the following sections we shall give the proofs of the above theorems I, II, and III with some generalization of them and some additional arguments.

#### 2. CASE A: PROOF OF (I)

In this section we consider Case A with n=1 and  $I=\infty$ . Then the problem is to see what the lowest energy state is for arbitrarily given numbers of up- and down-spin electrons,  $N_{\uparrow}$  and  $N_{\downarrow}$ , in the manifold spanned by

$$\Psi_{i\alpha_{i}} = (-1)^{i} c_{1\sigma_{1}}^{\dagger} c_{2\sigma_{2}}^{\dagger} \cdots c_{i-1\sigma_{i-1}}^{\dagger} c_{i+1\sigma_{i+1}}^{\dagger} \cdots c_{N\sigma_{N}}^{\dagger} |0\rangle,$$
(2.1)

where  $\alpha_i$  denotes the set  $(\sigma_1, \sigma_2, \dots, \sigma_{i-1}, \sigma_{i+1}, \dots, \sigma_N)$  and  $|0\rangle$  is the vacuum state, when the Hamiltonian is given by

$$H' = t \sum_{ij} \sum_{\sigma} c_{i\sigma}^{\dagger} c_{j\sigma}, \qquad (2.2)$$

where t>0 and in the summation  $\sum_{ij}'$ , i and j should be the nearest neighbors.

For the case where  $N_{\uparrow}=N_{e}$  and  $N_{\downarrow}=0$  (or  $N_{\downarrow}=N_{e}$  and  $N_{\uparrow}=0$ ), it is quite a trivial task to find the lowest energy state. It is given by filling up the band for upspin electrons (or down-spin electrons) except one level at the band top. It is the state with

$$S = S_{\text{max}} = \frac{1}{2} N_e, \quad S_z = \pm S,$$
 (2.3)

$$E = -zt, (2.4)$$

z being the number of nearest neighbors. Now we prove (I) by two steps: i.e., first it is shown that there is no state with E < -zt, and secondly that there is no state with E = -zt and  $S < S_{\text{max}}$ . Then it immediately follows that the state with E = -zt and  $S = S_{\text{max}}$  is the ground state of the system.

For later convenience, we introduce here the notation of a *superlattice* which consists of the set  $\{(i\alpha_i)\}$ . In this superlattice each  $(i\alpha_i)$  represents a lattice point and  $(i\alpha_i)$  and  $(j\beta_j)$  are called nearest neighbors if  $\langle \Psi_{i\alpha_i}|H'|\Psi_{j\beta_i}\rangle \neq 0$ . That is, we have

$$\langle \Psi_{i\alpha_i} | H' | \Psi_{j\beta_j} \rangle = -t$$
, for  $(j\beta_j) = n [(i\alpha_i)]$   
= 0, otherwise, (2.5)

where  $n[(i\alpha_i)]$  denotes nearest neighbors of  $(i\alpha_i)$ . It is clear that each lattice point in the superlattice has z nearest neighbors as in the real lattice, and that the superlattice is equivalent to the real lattice for  $N_{\uparrow} = N_{e}$  and  $N_{\downarrow} = 0$  (or  $N_{\downarrow} = N_{e}$  and  $N_{\uparrow} = 0$ ).

Let

$$(j\beta_j|i\alpha_i)_\omega = \left\langle \Psi_{j\beta_j} \left| \frac{1}{\omega - H'} \right| \Psi_{i\alpha_i} \right\rangle,$$
 (2.6)

where  $\omega$  is a complex number in general, though in the following we only consider  $(j\beta_j|i\alpha_i)_{\omega}$  on the real axis. The poles of  $(i\alpha_i|i\alpha_i)_{\omega}$  lie on the real axis and give the

energy eigenvalues of the states with  $S \ge |N_{\uparrow} - N_{\downarrow}|/2$ . Using the identity

$$\frac{1}{\omega - H'} = \frac{1}{\omega} + \frac{1}{H'} \frac{1}{\omega - H'}, \tag{2.7}$$

we can derive the equation for  $(j\beta_j|i\alpha_i)_{\omega}$  as

$$\omega (j\beta_{j}|i\alpha_{i})_{\omega} = \delta_{ij}\delta_{\alpha_{i}\beta_{j}} + \langle \Psi_{j\beta_{j}}|H'(\omega - H')^{-1}|\Psi_{i\alpha_{i}}\rangle 
= \delta_{ij}\delta_{\alpha_{i}\beta_{j}} - t \sum_{(k\gamma_{k})=n[(j\beta_{j})]} (k\gamma_{k}|i\alpha_{i})\omega.$$
(2.8)

Equation (2.8) can be solved by a successive iteration, and  $(i\alpha_i|i\alpha_i)_{\omega}$  is found to be

$$(i\alpha_i|i\alpha_i)_{\omega}^{-1} = \omega[1 - f(\omega)],$$
 (2.9)

$$f(\omega) = \sum_{p=2}^{\infty} A_p \left(\frac{-t}{\omega}\right)^p = \sum_{p=2}^{\infty} \frac{A_p}{z^p} \left(\frac{-zt}{\omega}\right)^p, \quad (2.10)$$

where  $A_p$  is the number of paths in which a particle starts from  $(i\alpha_i)$  in the superlattice and comes back to the same site after p nearest-neighbor steps, without passing  $(i\alpha_i)$  on the way. As  $z^p$  is just the number of paths in which a particle starts from  $(i\alpha_i)$  and takes p nearest-neighbor steps without any restrictions, it is clear that

$$A_p < z^p. (2.11)$$

Therefore  $f(\omega)$  is absolutely convergent for real  $\omega < -zt$ . For the case where  $N_{\uparrow} = N_{e}$  and  $N_{\downarrow} = 0$ , Eqs. (2.9) and (2.10) become

$$(i|i)_{\omega}^{-1} = \omega [1 - f_0(\omega)]$$
 (2.12)

$$f_0(\omega) = \sum_{p=2}^{\infty} (A_p^0/z^p) (-zt/\omega)^p,$$
 (2.13)

where we dropped the index  $\alpha_i$ , for the states are uniquely specified only by i in this case. Here, as the superlattice is equivalent to the real lattice,  $A_p^0$  can be defined as the number of paths in the real lattice. Since the lowest energy for this case is given by -zt,  $(i|i)_{\omega}$  has no pole for  $\omega < -zt$ . This means that

$$f_0(\omega) \neq 1$$
 for  $\omega < -zt$ . (2.14)

We again consider general cases of arbitrary numbers of  $N_{\uparrow}$  and  $N_{\downarrow}$ . Let us introduce

$$v_{\alpha\beta}(\omega) = \sum_{n=0}^{\infty} (C_p^{\alpha\beta}/z^p)(-zt/\omega)^p, \qquad (2.15)$$

where  $C_p^{\alpha\beta}$  is the number of paths in which a particle starts from  $(i\alpha_i)$  and arrives at  $(i\beta_i)$  after p nearest-neighbor steps, without passing any  $(i\gamma_i)$  with the same i on the way.  $v_{\alpha\beta}(\omega)$  is also absolutely convergent for  $\omega < -zt$ . Furthermore, it is shown that

$$v_{\alpha\beta}(\omega) > 0$$
, for  $\omega < -zt$ , (2.16)

$$\sum_{\beta} v_{\alpha\beta}(\omega) = f_0(\omega) . \qquad (2.17)$$

Equation (2.16) is obvious, while Eq. (2.17) follows from  $\sum_{\beta} C_p^{\alpha\beta} = A_p^0$ , which is proved by watching the motion of i in each path contributing to  $C_p^{\alpha\beta}$ .

Using  $v_{\alpha\beta}(\omega)$ , we rewrite  $f(\omega)$  as

$$f(\omega) = v_{\alpha\alpha}(\omega) + \sum_{\beta(\pm\alpha)} v_{\alpha\beta}(\omega) v_{\beta\alpha}(\omega)$$

$$\sum_{\beta(\pm\alpha)} \sum_{\gamma(\pm\alpha)} v_{\alpha\beta}(\omega) v_{\beta\gamma}(\omega) v_{\gamma\alpha}(\omega) + \cdots, \quad (2.18)$$

where the *n*th term is the contribution from the paths in which the particle passes the lattice points with the same i (n-1) times on the way. Using Eq. (2.17) repeatedly, we can further rewrite it as follows:

$$f(\omega) = f_0(\omega) + \sum_{\beta(\pm\alpha)} v_{\alpha\beta}(\omega) [v_{\beta\alpha}(\omega) - 1] + \cdots$$

$$= f_0(\omega) + [f_0(\omega) - 1] \sum_{\beta(\pm \alpha)} v_{\alpha\beta}(\omega)$$

$$+ \sum_{\beta(\neq\alpha)} \sum_{\gamma(\neq\alpha)} v_{\alpha\beta}(\omega) v_{\beta\gamma}(\omega) [v_{\gamma\alpha}(\omega) - 1] + \cdots.$$

Finally, we get

$$f(\omega)-1=[f_0(\omega)-1][1+\sum_{\beta(\neq\alpha)}v_{\alpha\beta}(\omega)]$$

$$\sum_{\beta(\pm\alpha)} \sum_{\gamma(\pm\alpha)} v_{\alpha\beta}(\omega) v_{\beta\gamma}(\omega) + \cdots ]. \quad (2.19)$$

Because of Eq. (2.16) the second factor of the right-hand side is positive for  $\omega < -zt$ , while because of Eq. (2.14) the first factor is nonvanishing for  $\omega < -zt$ . Thus it turns out that

$$f(\omega) \neq 1$$
, for  $\omega < -zt$ . (2.20)

This means that  $(i\alpha_i|i\alpha_i)_{\omega}$  for arbitrary numbers of  $N_{\uparrow}$  and  $N_{\downarrow}$  has no pole for  $\omega < -zt$ , and hence that there is no energy eigenvalue lower than -zt.

It has been proved that the ground-state energy should be -zt, while it is already known that there is a state with E=-zt, i.e., the state with  $S=S_{\max}$ . Then there arises a question whether there is another state with E=-zt and  $S<S_{\max}$ . The answer is no.

To prove it, we have to know the structure of the superlattice. To clarify the situation, let us first consider the case of a one-dimensional lattice. We show three spin configurations for N=5 and  $N_{\uparrow}=N_{\downarrow}=2$  in Fig. 1. It is clear that one can arrive at (b) starting from (a) by moving spins to their nearest-neighbor vacant site one by one, but that one can never arrive at (c) starting from (a) or (b). This means that the lattice point in the superlattice corresponding to configuration (a) is connected with the lattice point corresponding to (b), but disconnected from the lattice

![](_page_2_Figure_38.jpeg)

Fig. 1. Some examples of the configuration of spins in the one-dimensional lattice with N=5 and  $N_1=N_1=2$ .

point corresponding to (c). Thus it turns out that the superlattice for the one-dimensional case is decomposed into some disconnected parts.

The situation is, however, quite different for the twoand three-dimensional cases. It is shown in Appendix A that for these cases all lattice points in the superlattice are connected directly or indirectly. This property of the superlattice is essential for the following proof.

Let us denote the wave function of the state with E=-zt and arbitrarily given  $N_{\uparrow}$  and  $N_{\downarrow}$  by  $\Psi$ , and expand it with  $\Psi_{i\alpha_i}$  as

$$\Psi = \sum_{(i\alpha_i)} \Gamma(i\alpha_i) \Psi_{i\alpha_i}. \qquad (2.21)$$

Then from

$$H'\Psi = -zt\Psi \,, \tag{2.22}$$

we get the equation for  $\Gamma$  as

$$\Gamma(i\alpha_i) = z^{-1} \sum_{\substack{(j\beta_i) = n [(i\alpha_i)]}} \Gamma(j\beta_i). \qquad (2.23)$$

Equation (2.23) is a kind of Laplace equation in a discrete space of the superlattice. It is clear from Eq. (2.23) that both the real and the imaginary parts of  $\Gamma(i\alpha_i)$  should have no extremum. Then, if we take the periodic boundary condition,

$$\Gamma(i\alpha_i) = \text{const}$$
 (2.24)

should be the unique solution of Eq. (2.23). The solution (2.24) corresponds to the state with  $S = S_{\text{max}}$  and  $S_z = \frac{1}{2}(N_{\uparrow} - N_{\downarrow})$ , and there is no state with E = -zt and  $S < S_{\text{max}}$ .

## 3. GENERAL FORMULATION FOR ONE-SPIN FLIPPED STATES

Before proceeding to the proofs of (II) and (III), some general formulas are derived in this section for a special case where  $N_{\uparrow} = N_{e} - 1$ ,  $N_{\downarrow} = 1$  and I and n are finite. The formulas will be applied to Case B in Sec. 4 to prove (II), and to Case A in Sec. 5 to prove (III). The assumptions (b) and (d) are not required in the discussion of this section.

For the case where  $N_1 = N_e - 1$  and  $N_4 = 1$ , the wave function of the system can be written in the form

$$\Psi = \{ \sum \Phi_0(j; i_1 \cdots i_n) c_{j\downarrow}^{\dagger} c_{j\uparrow} c_{i_n \uparrow} \cdots c_{i_1 \uparrow} 
+ \sum \Phi_1(j; i_1 \cdots i_{n+1}) c_{j\downarrow}^{\dagger} c_{i_{n+1} \uparrow} \cdots c_{i_1 \uparrow} \} \Psi_f \quad (3.1)$$

$$\equiv T \Psi_f,$$

where

$$\Psi_f = \prod_{i=1}^N c_{i\uparrow}^{\dagger} |0\rangle. \tag{3.2}$$

Here we assume that  $\Phi_0(j; i_1 \cdots i_n)$  and  $\Phi_1(j; i_1 \cdots i_{n+1})$  are antisymmetric with respect to the permutation of i's and that

$$\Phi_0(j; i_1 \cdots j \cdots i_n) = 0, 
\Phi_1(j; i_1 \cdots j \cdots i_{n+1}) = 0.$$
(3.3)

The equations for  $\Phi_0$  and  $\Phi_1$  are derived from

$$\{ [H,T] - ET \} \Psi_f = 0. \tag{3.4}$$

Calculating the commutator, we get

$$\begin{split} \left[\sum\left\{-\sum_{\lambda=1}^{n}\sum_{i'}t_{i'i\lambda}\Phi_{0}(j;i_{1}\cdots i'^{\lambda}\cdots i_{n})-\sum_{\lambda=1}^{n}t_{ji\lambda}\Phi_{0}(i_{\lambda};i_{1}\cdots j^{\lambda}\cdots i_{n})-(n+1)\sum_{i'}t_{i'j}\Phi_{1}(j;i_{1}\cdots i'^{n+1})\right.\\ \left.+(n+1)\sum_{i'}t_{ji'}\Phi_{1}(i';i_{1}\cdots j^{n+1})-E\Phi_{0}(j;i_{1}\cdots i_{n})\right\}c_{j\downarrow}^{\dagger}c_{j\uparrow}c_{in\uparrow}\cdots c_{i1\uparrow}\\ \left.+\sum_{i'}\left\{-t_{ji_{n+1}}\Phi_{0}(j;i_{1}\cdots i_{n})+t_{ji_{n+1}}\Phi_{0}(i_{n+1};i_{1}\cdots i_{n})-\sum_{\lambda=1}^{n+1}\sum_{i'}t_{i'i\lambda}\Phi_{1}(j;i_{1}\cdots i'^{\lambda}\cdots i_{n+1})\right.\\ \left.+\sum_{i'}t_{ji'}\Phi_{1}(i';i_{1}\cdots i_{n+1})+(I-E)\Phi_{1}(j;i_{1}\cdots i_{n+1})\right\}c_{j\downarrow}^{\dagger}c_{i_{n+1}\uparrow}\cdots c_{i1\uparrow}\right]\Psi_{f}=0\,, \end{split}$$

where the term  $j=i_{\mu}(\mu=1,\ldots,n+1)$  should be excluded in the summation  $\sum'$ , and  $i'^{\lambda}$  means that  $i_{\lambda}$  is replaced by i'. From the first term, assuming  $j \neq i_{\mu}(\mu=1,\ldots,n)$ , we get

$$E\Phi_{0}(j; i_{1}\cdots i_{n}) = -\sum_{\lambda=1}^{n} \sum_{i'} t_{i'i\lambda} \Phi_{0}(j; i_{1}\cdots i'^{\lambda}\cdots i_{n}) - \sum_{\lambda=1}^{n} t_{ji\lambda} \Phi_{0}(i_{\lambda}; i_{1}\cdots j^{\lambda}\cdots i_{n}) - (n+1) \sum_{i'} \{t_{j'j} \Phi_{1}(j; i_{1}\cdots j'^{n+1}) - t_{jj'} \Phi_{1}(j'; i_{1}\cdots j^{n+1})\}.$$
(3.5)

From the second term, antisymmetrizing the coefficient with respect to the permutation of i's and assuming  $j \neq i_{\mu} (\mu = 1, ..., n+1)$ , we get

$$(E-I)\Phi_{1}(j; i_{1}\cdots i_{n+1}) = -\sum_{\lambda=1}^{n+1} \sum_{i'} t_{i'i\lambda}\Phi_{1}(j; i_{1}\cdots i'^{\lambda}\cdots i_{n+1})$$

$$+\sum_{j'} t_{jj'}\Phi_{j}(j'; i_{1}\cdots i_{n+1}) - \frac{1}{n+1} \{t_{ji_{n+1}}[\Phi_{0}(j; i_{1}\cdots i_{n}) - \Phi_{0}(i_{n+1}; i_{1}\cdots i_{n})]$$

$$-\sum_{\lambda=1}^{n} t_{ji\lambda}[\Phi_{0}(j; i_{1}\cdots i_{n+1}^{\lambda}\cdots i_{n}) - \Phi_{0}(i_{\lambda}; i_{1}\cdots i_{n+1}^{\lambda}\cdots i_{n})] \}. \quad (3.6)$$

So far, Eqs. (3.5) and (3.6) are exact. Now we introduce the assumptions (a) and (c) and calculate the energy to the order nt and  $t^2/I$ . From Eq. (3.6) we obtain to the first order of t

$$\Phi_1(j; i_1 \cdots j'^{n+1}) = ((n+1)I)^{-1} \{t_{jj'} [\Phi_0(j; i_1 \cdots i_n) - \Phi_0(j'; i_1 \cdots i_n)] \}$$

$$-\sum_{\lambda=1}^{n} t_{ji\lambda} \left[ \Phi_0(j; i_1 \cdots j'^{\lambda} \cdots i_n) - \Phi_0(i_\lambda; i_1 \cdots j'^{\lambda} \cdots i_n) \right] \}. \quad (3.7)$$

Substitution of Eq. (3.7) in Eq. (3.5) gives

$$E\Phi_0(j;i_1\cdots i_n) = -\sum_{\lambda=1}^n \sum_{i'} t_{i'i\lambda} \Phi_0(j;i_1\cdots i'\lambda\cdots i_n) - \sum_{\lambda=1}^n t_{ji\lambda} \Phi_0(i_\lambda;i_1\cdots j'\lambda\cdots i_n)$$

$$+\frac{2}{I}\sum_{j'}t_{jj'}t_{j'j}\left[\Phi_0(j';i_1\cdots i_n)-\Phi_0(j;i_1\cdots i_n)\right]-\frac{1}{I}\sum_{\lambda=1}^n\sum_{j'}\left\{t_{jj'}t_{j'i_\lambda}\left[\Phi_0(j';i_1\cdots j^\lambda\cdots i_n)\right]\right\}$$

$$-\Phi_0(i_{\lambda}; i_1 \cdots j^{\lambda} \cdots i_n)] - t_{ji_{\lambda}} t_{j'j} [\Phi_0(j; i_1 \cdots j'^{\lambda} \cdots i_n) - \Phi_0(i_{\lambda}; i_1 \cdots j'^{\lambda} \cdots i_n)] \}. \quad (3.8)$$

Equation (3.8) is valid only for  $j \neq i_{\mu}(\mu = 1, ..., n)$ . If we add a term

$$\sum_{\lambda=1}^n \delta_{ji_\lambda} \sum_{i'} t_{i'i_\lambda} \Phi_0(j; i_1 \cdots i'^{\lambda} \cdots i_n)$$

to the right-hand side of the equation, it becomes consistent with Eq. (3.3) for  $j=i_{\mu}$ . Further, we neglect the last two lines of the right-hand side, because their contribution is of the order  $nt^2/I$ . Thus we finally obtain

$$E\Phi_0(j;i_1\cdots i_n) = -\sum_{\lambda=1}^n (1-\delta_{ji_{\lambda}}) \sum_{i'} t_{i'i_{\lambda}} \Phi_0(j;i_1\cdots i'^{\lambda}\cdots i_n)$$

$$-\sum_{\lambda=1}^{n} t_{ji\lambda} \Phi_0(i_\lambda; i_1 \cdots j^{\lambda} \cdots i_n) + (2/I) \sum_{i'} t_{jj'} t_{j'j} [\Phi_0(j'; i_1 \cdots i_n) - \Phi_0(j; i_1 \cdots i_n)]. \quad (3.9)$$

In solving Eq. (3.9), it is convenient to introduce Fourier transforms. Then we have to discuss the case of sc, bcc, and fcc and the case of hcp separately, for in the latter lattice structure a unit cell contains two atoms. In this section we only consider the former case, while the latter will be discussed in Appendix C.

Let us introduce Fourier transforms by

$$\Phi_0(j; i_1 \cdots i_n) = \sum_{\mathbf{q} \mathbf{k}_1 \cdots \mathbf{k}_n} \Phi_0(\mathbf{q}; \mathbf{k}_1 \cdots \mathbf{k}_n) \exp[-i\mathbf{q} \cdot \mathbf{r}_j - i \sum_{\lambda=1}^n \mathbf{k}_{\lambda} \cdot (\mathbf{r}_{i\lambda} - \mathbf{r}_j)]$$
(3.10)

$$t_{ij} = N^{-1} \sum_{\mathbf{k}} t(\mathbf{k}) e^{i\mathbf{k} \cdot (\mathbf{r}_i - \mathbf{r}_j)}, \qquad (3.11)$$

where  $\Phi_0(\mathbf{q}; \mathbf{k}_1 \dots \mathbf{k}_n)$  is antisymmetric with respect to the permutation of k's and satisfies

$$\sum_{\mathbf{k}_{\lambda}} \Phi_0(\mathbf{q}; \mathbf{k}_1 \cdots \mathbf{k}_n) = 0, \qquad (3.12)$$

which comes from Eq. (3.3). Then from Eq. (3.9) we have

$$\{E+\sum_{\lambda=1}^{n}t(\mathbf{k}_{\lambda})+(2/NI)\sum_{\mathbf{k}'}t(\mathbf{k}')[t(\mathbf{k}')-t(\mathbf{k}'+\sum_{\lambda=1}^{n}\mathbf{k}_{\lambda}-\mathbf{q})]\}\Phi_{0}(\mathbf{q};\mathbf{k}_{1}\cdots\mathbf{k}_{n})$$

$$=N^{-1}\sum_{\lambda=1}^{n}\sum_{\mathbf{k}'}\left[t(\mathbf{k}')-t(\mathbf{k}'+\sum_{\mu=1}^{n}\mathbf{k}_{\mu}-\mathbf{q})\right]\Phi_{0}(\mathbf{q};\mathbf{k}_{1}\cdots\mathbf{k}'^{\lambda}\cdots\mathbf{k}_{n}). \quad (3.13)$$

It is worthwhile to point out here that Eq. (3.13) has a solution given by

$$\mathbf{q} = \sum_{\lambda=1}^{n} \mathbf{k}_{\lambda}, \quad E = -\sum_{\lambda=1}^{n} t(\mathbf{k}_{\lambda}). \tag{3.14}$$

This solution corresponds to the state with  $S=S_{\text{max}}$  and  $S_z=S-1$ . Especially, if the levels with the wave vectors  $\mathbf{k}_1 \cdots \mathbf{k}_n$  are n highest levels at the band top, we

get the state with the lowest energy. In the following sections we shall look for the solution of Eq. (3.13) other than Eq. (3.14) for some cases.

#### 4. CASE B: PROOF OF (II)

We first apply the formula obtained in the last section to Case B with n=1 and  $I=\infty$  to prove (II). In this section, starting from Eq. (3.13), we only consider

the case of fcc. The case of hcp will be discussed in Appendix C.

Under the assumption (b),  $t(\mathbf{k})$  for fcc is given by

 $t(\mathbf{k}) = 4t \left[ \cos k_x a \cos k_y a + \cos k_y a \cos k_z a \right]$ 

$$+\cos k_z a \cos k_x a$$
 (4.1)

$$\equiv -4|t|\theta_{\mathbf{k}}$$

where a is the lattice constant. In this case, the lowest energy of the  $S = S_{\text{max}}$  states is given by -4|t|. We have to see whether there is any state with E < -4|t|.

We consider the case  $\mathbf{q}=0$  in Eq. (3.13). Putting  $n=1, I=\infty$ , and  $\mathbf{q}=0$  in Eq. (3.13), we get

$$\{E+t(\mathbf{k})\}\Phi(\mathbf{k}) = \frac{1}{N} \sum_{\mathbf{k}'} [t(\mathbf{k}')-t(\mathbf{k}+\mathbf{k}')]\Phi(\mathbf{k}'), \quad (4.2)$$

where we put  $\Phi_0(0; \mathbf{k}) = \Phi(\mathbf{k})$ . Substitution of Eq. (4.1) in Eq. (4.2) gives

$$(\epsilon - \theta_{\mathbf{k}})\Phi(\mathbf{k}) = \sum_{(\lambda,\mu)} \left\{ -(1 - \cos k_{\lambda} a \cos k_{\mu} a) \Phi_{c\lambda\mu} + \sin k_{\lambda} a \sin k_{\mu} a \Phi_{s\lambda\mu} - \cos k_{\lambda} a \sin k_{\mu} a \Phi_{1\lambda\mu} - \sin k_{\lambda} a \cos k_{\mu} a \Phi_{1\mu\lambda} \right\}, \quad (4.3)$$

where  $\sum_{(\lambda,\mu)}$  is the summation over  $(\lambda,\mu)=(x,y)$ , (y,z), and (z,x) and

$$\begin{aligned} \epsilon &= E/4 \, | \, t \, | \, , \\ \Phi_{c\lambda\mu} &= N^{-1} \sum_{\mathbf{k}} \, \cos k_{\lambda} a \, \cos k_{\mu} a \Phi(\mathbf{k}) \, , \\ \Phi_{s\lambda\mu} &= N^{-1} \sum_{\mathbf{k}} \, \sin k_{\lambda} a \, \sin k_{\mu} a \Phi(\mathbf{k}) \, , \\ \Phi_{1\lambda\mu} &= N^{-1} \sum_{\mathbf{k}} \, \cos k_{\lambda} a \, \sin k_{\mu} a \Phi(\mathbf{k}) \, . \end{aligned}$$

$$(4.4)$$

From Eq. (4.3) the equations for  $\Phi_{c\lambda\mu}$ ,  $\Phi_{s\lambda\mu}$ , and  $\Phi_{1\lambda\mu}$  are obtained as

$$\lceil 1 + F_1(\epsilon) \rceil \Phi_{c\lambda\mu} + F_2(\epsilon) (\Phi_{c\mu\nu} + \Phi_{c\nu\lambda}) = 0, \quad (4.5)$$

$$[1-G(\epsilon)]\Phi_{s\lambda\mu}=0,$$
 (4.6)

$$[1+H_1(\epsilon)]\Phi_{1\lambda\mu}+H_2(\epsilon)\Phi_{1\nu\mu}=0, \quad (4.7)$$

where  $(\lambda, \mu, \nu)$  denotes a permutation of (x, y, z) and

$$F_1(\epsilon) = \frac{1}{N} \sum_{\mathbf{k}} \frac{(1 - \cos k_x a \, \cos k_y a) \, \cos k_x a \, \cos k_y a}{\epsilon - \theta_{\mathbf{k}}} \,, \quad (4.8a)$$

$$F_{2}(\epsilon) = \frac{1}{N} \sum_{\mathbf{k}} \frac{(1 - \cos k_{y} a \, \cos k_{z} a) \, \cos k_{x} a \, \cos k_{y} a}{\epsilon - \theta_{\mathbf{k}}}, \quad (4.8b)$$

$$G(\epsilon) = \frac{1}{N} \sum_{\mathbf{k}} \frac{\sin^2 k_x a \sin^2 k_y a}{\epsilon - \theta_{\mathbf{k}}}, \qquad (4.9)$$

$$H_1(\epsilon) = \frac{1}{N} \sum_{\mathbf{k}} \frac{\sin^2 k_x a \cos^2 k_y a}{\epsilon - \theta_{\mathbf{k}}}, \qquad (4.10a)$$

$$H_2(\epsilon) = \frac{1}{N} \sum_{\mathbf{k}} \frac{\sin^2 k_x a \, \cos k_y a \, \cos k_z a}{\epsilon - \theta_{\mathbf{k}}} \,. \tag{4.10b}$$

It is easily verified that Eqs. (4.5) and (4.6) have no nontrivial solution for  $\epsilon < -1$  (i.e., E < -4|t|). Therefore we have to examine Eq. (4.7) in some detail.

In order that Eq. (4.7) has some nontrivial solutions, it should be that  $[1+H_1(\epsilon)]^2-H_2(\epsilon)^2=0$ , or

$$H_{\pm}(\epsilon) = -1, \qquad (4.11)$$

where

$$H_{\pm}(\epsilon) = H_{1}(\epsilon) \pm H_{2}(\epsilon)$$

$$= \frac{1}{N} \sum_{\mathbf{k}} \frac{\sin^{2}k_{x}a \cos k_{y}a (\cos k_{y}a \pm \cos k_{z}a)}{\epsilon - \theta_{\mathbf{k}}}.$$
(4.12)

Let us examine the behavior of  $H_{-}(\epsilon)$  at  $\epsilon \lesssim -1$ . The main contribution to  $H_{-}(\epsilon)$  at  $\epsilon \lesssim -1$  comes from k's at the band top where  $\theta_{\mathbf{k}} \simeq -1$ . Especially we have

 $\lim_{\epsilon \to 1-0} H_{-}(\epsilon) = \langle \sin^2 k_x a \cos k_y a (\cos k_y a - \cos k_z a) \rangle_{\text{band top}}$ 

$$\times \lim_{\epsilon \to -1-0} N^{-1} \sum_{\mathbf{k}} (\epsilon - \theta_{\mathbf{k}})^{-1}, \quad (4.13)$$

where  $\langle \cdots \rangle_{band\ top}$  means the average at the band top given by

$$\cos k_x a \cos k_y a = -1, \cos k_y a \cos k_z a = -1$$

$$\cos k_z a \cos k_z a = -1.$$

$$(4.14)$$

As

 $\langle \sin^2 k_x a \cos k_y a (\cos k_y a - \cos k_z a) \rangle_{\text{band top}} = \frac{1}{3},$  (4.15) we obtain

$$\lim_{\epsilon \to -1-0} H_{-}(\epsilon) = -\infty . \tag{4.16}$$

From Eq. (4.16) it is clear that  $H_{-}(\epsilon) = -1$  has at least one solution for  $\epsilon < -1$ . This means that there exists at least one state with E < -4|t|, and that the state with  $S = S_{\text{max}}$  and E = -4|t| is not the ground state.

Thus we have proved (II) for the case of fcc. It is also proved for the case of hcp in a similar way, as will be shown in Appendix C.

# 5. SPIN-WAVE SPECTRUM FOR CASE A: PROOF OF (III)

Now let us apply Eq. (3.13) to Case A with finite n and I, and look for a spin-wave solution of it to prove (III). Although we can take a much simpler order-of-magnitude argument if we are only concerned with the proof of (III), the following argument is useful to generalize it to some extent as well as to calculate  $\alpha$  explicitly. These problems will also be discussed in this section.

It is already known that for Case A the ground state is the state with  $S = S_{\text{max}}$ , if n is sufficiently small and I is sufficiently large. The ground state is given by

$$\Phi_0(\mathbf{q}; \mathbf{k}_1 \cdots \mathbf{k}_n) = \delta_{q0} \delta_{\{\mathbf{k}_{\lambda}\}, \{\mathbf{p}_{\lambda}\}} \Phi_0 + \Phi'$$
 (5.1)

$$E = -\sum_{\lambda=1}^{n} t(\mathbf{p}_{\lambda}) \equiv E_0, \qquad (5.2)$$

where  $\{p_{\lambda}\}$  is the set of wave vectors of n highest levels in the band, and  $\Phi'$  is at most of the order  $\Phi_0/N$ .  $\{p_{\lambda}\}$  satisfies  $\sum_{\lambda} p_{\lambda} = 0$ .

It is expected that the wave functions of the spinwave states are not much different from that of the ground state. Therefore we look for the solution of Eq. (3.13) by putting

$$\Phi_{0}(\mathbf{q}; \mathbf{p}_{1} \cdots \mathbf{p}_{n}) = \Phi_{\mathbf{q}},$$

$$\Phi_{0}(\mathbf{q}; \mathbf{p}_{1} \cdots \mathbf{k}^{\lambda} \cdots \mathbf{p}_{n}) = \Phi_{\mathbf{q}}(\mathbf{p}_{\lambda} | \mathbf{k}),$$

$$\Phi_{0}(\mathbf{q}; \mathbf{p}_{1} \cdots \mathbf{k}^{\lambda} \cdots \mathbf{k}^{\mu} \cdots \mathbf{p}_{n}) = \Phi_{\mathbf{q}}(\mathbf{p}_{\lambda} \mathbf{p}_{\mu} | \mathbf{k} \mathbf{k}'),$$

$$(5.3)$$

and so on. From Eq. (3.12) they should satisfy

$$\Phi_{\mathbf{q}} + \sum_{\mathbf{k} <} \Phi_{\mathbf{q}}(\mathbf{p} | \mathbf{k}) = 0,$$

$$\Phi_{\mathbf{q}}(\mathbf{p} | \mathbf{k}) + \sum_{\mathbf{k}' <} \Phi_{\mathbf{q}}(\mathbf{p} \mathbf{p}' | \mathbf{k} \mathbf{k}') = 0, \cdots,$$
(5.4)

where **p** or **p'** denotes one of  $\{p_{\lambda}\}$  and  $\sum_{k<}$  is the summation over all levels other than  $\{p_{\lambda}\}$ . The summation over  $\{p_{\lambda}\}$  will be denoted by  $\sum_{p>}$ .

By the use of Eq. (5.3), Eq. (3.13) becomes

$$\{E_{\mathbf{q}} + (2/NI) \sum_{\mathbf{k}} t(\mathbf{k}) \left[t(\mathbf{k}) - t(\mathbf{k} - \mathbf{q})\right] - N^{-1} \sum_{\mathbf{p} > 1} \left[t(\mathbf{p}) - t(\mathbf{p} - \mathbf{q})\right]\}\Phi_{\mathbf{q}} = N^{-1} \sum_{\mathbf{p} > 1} \sum_{\mathbf{k} < 1} \left[t(\mathbf{k}) - t(\mathbf{p} - \mathbf{q})\right]\Phi_{\mathbf{q}}(\mathbf{p} \mid \mathbf{k}), \quad (5.5)$$

$$\{E_{\mathbf{q}}+t(\mathbf{p})-t(\mathbf{k})+(2/NI)\sum_{\mathbf{k}'}t(\mathbf{k}')[t(\mathbf{k}')-t(\mathbf{k}'+\mathbf{k}-\mathbf{p}-\mathbf{q})]\}\Phi_{\mathbf{q}}(\mathbf{p}\,|\,\mathbf{k})=N^{-1}[t(\mathbf{p})-t(\mathbf{k}-\mathbf{q})]\Phi_{\mathbf{q}}(\mathbf{p}|\,\mathbf{k})$$

$$+N^{-1}\sum_{\mathbf{k}'<} [t(\mathbf{k}')-t(\mathbf{k}'+\mathbf{k}-\mathbf{p}-\mathbf{q})] \Phi_{\mathbf{q}}(\mathbf{p}\,|\,\mathbf{k}') + N^{-1}\sum_{\mathbf{p}'>} \sum_{\mathbf{k}'<} [t(\mathbf{k}')-t(\mathbf{k}'+\mathbf{k}-\mathbf{p}-\mathbf{q})] \Phi_{\mathbf{q}}(\mathbf{p}\mathbf{p}'\,|\,\mathbf{k}\mathbf{k}') \quad (5.6)$$

and so on, where

$$E_{\mathbf{q}} = E - E_0 \tag{5.7}$$

is the spin-wave energy to be determined in the following calculation.

Under the assumptions (a) and (c), Eqs. (5.5) and (5.6) can be solved by neglecting higher order terms. In Eq. (5.5)  $\Phi_{\mathbf{q}}(\mathbf{p}|\mathbf{k})$  only appears in the term which contributes to  $E_{\mathbf{q}}$  in the order nt. Therefore we have only to determine it to the lowest order. Neglecting the terms of the order nt and  $t^2/I$  in Eq. (5.6), we have

$$[E_{\mathbf{q}}+t(\mathbf{p})-t(\mathbf{k})]\Phi_{\mathbf{q}}(\mathbf{p}|\mathbf{k})-N^{-1}\sum_{\mathbf{k}'<}[t(\mathbf{k}')-t(\mathbf{k}'+\mathbf{k}+\mathbf{p}-\mathbf{q})]\Phi_{\mathbf{q}}(\mathbf{p}|\mathbf{k}')=N^{-1}[t(\mathbf{p})-t(\mathbf{k}-\mathbf{q})]\Phi_{\mathbf{q}}.$$
 (5.8)

Now it is rather easy to prove (III) without any further calculations. From Eq. (5.5) it turns out that  $E_{\mathbf{q}}$  consists of two contributions; one is of the order  $t^2/I$ , which comes from the second term in the wavy brackets of the left-hand side, and the other is of the order nt, which comes from the rest terms. It is clear that the second contribution is positive, for, if  $I = \infty$ , the  $S = S_{\text{max}}$  state is the ground state for Case A, and hence the spin-wave energy should be positive. On the other hand, the first contribution is negative, because

$$N^{-1} \sum_{\mathbf{k}} t(\mathbf{k}) [t(\mathbf{k}) - t(\mathbf{k} - \mathbf{q})] = \sum_{j} |t_{ij}|^{2} [1 - \cos \mathbf{q} \cdot (\mathbf{r}_{i} - \mathbf{r}_{j})] > 0.$$

Then, if the magnitude of the first contribution is larger than the second one, or if the condition (1.6) holds, the spin-wave energy becomes negative and the state with  $S=S_{\rm max}$  cannot be the ground state. This is the proof of (III). Though Eqs. (5.5) and (5.6) are valid only for sc, bcc, and fcc, the situation is exactly the same for hcp, and we can get the same conclusion for it.

The remaining problem is to determine the numerical constant  $\alpha$  for each lattice structure. In the following we calculate it only for sc, the simplest case among the four. Though there is no essential difficulty in calculating it for other cases, the calculation involved there will be much more complicated.

For sc,  $t(\mathbf{k})$  is given by

$$t(\mathbf{k}) = 2t \sum_{\lambda = x, y, z} \cos(k_{\lambda} a) \equiv 2t\theta_{\mathbf{k}}, \qquad (5.9)$$

where a is the lattice constant. Because of the assumption t>0, the band top is located at k=0. Substitution of Eq. (5.9) in Eq. (5.5) gives

$$\left[\epsilon_{\mathbf{q}} + (2t/I)\sum_{\lambda} (1 - \cos q_{\lambda}a) - N^{-1}\sum_{\mathbf{p}>\lambda} \sum_{\lambda} (1 - \cos q_{\lambda}a)\cos p_{\lambda}a\right]\Phi_{\mathbf{q}}$$

$$= \sum_{\mathbf{p}>\lambda} \sum_{\lambda} \left[ (1 - \cos q_{\lambda} a) \Phi_{\mathbf{q}^{c\lambda}}(\mathbf{p}) - (\sin q_{\lambda} a) \Phi_{\mathbf{q}^{s\lambda}}(\mathbf{p}) \right], \quad (5.10)$$

where

$$\epsilon_{\mathbf{q}} = E_{\mathbf{q}}/2t,$$

$$\Phi_{\mathbf{q}}^{e\lambda}(\mathbf{p}) = N^{-1} \sum_{\mathbf{k} <} (\cos k_{\lambda} a) \Phi_{\mathbf{q}}(\mathbf{p} | \mathbf{k}),$$

$$\Phi_{\mathbf{q}}^{s\lambda}(\mathbf{p}) = N^{-1} \sum_{\mathbf{k} <} (\sin k_{\lambda} a) \Phi_{\mathbf{q}}(\mathbf{p} | \mathbf{k}).$$
(5.11)

The equations for  $\Phi_{\mathbf{q}}^{c\lambda}$  and  $\Phi_{\mathbf{q}}^{s\lambda}$  are derived from Eq. (5.8) as

$$\{1+F(\theta_{p})-\left[\cos(p_{\lambda}+q_{\lambda})a\right]G_{1}(\theta_{p})\}\Phi_{q}^{c\lambda}(\mathbf{p})+\sum_{\mu\neq\lambda}\{F(\theta_{p})-\left[\cos(p_{\mu}+q_{\mu})a\right]G_{2}(\theta_{p})\}\Phi_{q}^{c\mu}(\mathbf{p})$$

$$-\left[\sin(p_{\lambda}+q_{\lambda})a\right]G_{1}(\theta_{p})\Phi_{\mathbf{q}}^{s\lambda}(\mathbf{p}) - \sum_{\mu \neq \lambda}\left[\sin(p_{\mu}+q_{\mu})a\right]G_{2}(\theta_{p})\Phi_{\mathbf{q}}^{s\mu}(\mathbf{p})$$

$$= -\left[(1-\cos q_{\lambda}a)G_{1}(\theta_{p}) + \sum_{\mu \neq \lambda}(1-\cos q_{\mu}a)G_{2}(\theta_{p})\right]\Phi_{\mathbf{q}}/N \quad (5.12)$$

$$\{1 + \left[\cos(p_{\lambda} + q_{\lambda})a\right]H(\theta_{p})\}\Phi_{q}^{s\lambda}(\mathbf{p}) - \left[\sin(p_{\lambda} + q_{\lambda})a\right]H(\theta_{p})\Phi_{q}^{c\lambda}(\mathbf{p}) = \left[\sin(q_{\lambda}a)\right]H(\theta_{p})\Phi_{q}/N, \tag{5.13}$$

where

$$F(\theta) = \frac{1}{N} \sum_{\mathbf{k}} P \frac{\cos k_x a}{\theta - \theta_{\mathbf{k}}},$$

$$G_1(\theta) = \frac{1}{N} \sum_{\mathbf{k}} P \frac{\cos^2 k_x a}{\theta - \theta_{\mathbf{k}}},$$

$$G_2(\theta) = \frac{1}{N} \sum_{\mathbf{k}} P \frac{\cos k_x a \cos k_y a}{\theta - \theta_{\mathbf{k}}},$$

$$H(\theta) = \frac{1}{N} \sum_{\mathbf{k}} P \frac{\sin^2 k_x a}{\theta - \theta_{\mathbf{k}}}.$$

$$(5.14)$$

In the derivation of Eqs. (5.12) and (5.13), there first appear functions of the type

$$N^{-1} \sum_{\mathbf{k} \in \mathcal{L}} f(\mathbf{k}) / (\theta - \theta_{\mathbf{k}})$$
 (5.15)

rather than those defined by Eq. (5.14). If we rewrite them as

$$\frac{1}{N} \sum_{\mathbf{k} < \theta - \theta_{\mathbf{k}}} = \frac{1}{N} \sum_{\mathbf{k}} P \frac{f(\mathbf{k})}{\theta - \theta_{\mathbf{k}}} - \frac{1}{N} \sum_{\mathbf{p} > \theta - \theta_{\mathbf{p}}} P \frac{f(\mathbf{p})}{\theta - \theta_{\mathbf{p}}}, \tag{5.16}$$

then the first term is a continuous function of  $\theta$ , while the second term, which is of the order n/N, has a logarithmic singularity at  $\theta = \theta_m$ ,  $\theta_m$  being the maximum value of  $\theta_{p_\lambda}$ . However, what we need in calculating  $\epsilon_q$  is not the function itself but its integration over  $\theta$  which is convergent. The second term in Eq. (5.16) only contributes to  $\epsilon_q$  in the order  $(n/N)^2$  which is neglected in the present calculation. Thus in Eqs. (5.12) and (5.13) we replaced the functions of the type (5.15) by those defined by Eq. (5.14).

If we confine the calculation to the terms linear to n, we further can simplify the equation by putting

$$\sum_{\mathbf{p}\geq} f(\mathbf{p}) \cong nf(0) . \tag{5.17}$$

Then, eliminating  $\Phi_q^{s\lambda}$  from Eqs. (5.12) and (5.13), we have, to the lowest order of n,

$$\left[\epsilon_{\mathbf{q}} + (2t/I) \sum_{\lambda} (1 - \cos q_{\lambda} a) - (n/N) \sum_{\lambda} A_{\mathbf{q}}^{\lambda}\right] \Phi_{\mathbf{q}} = n \sum_{\lambda} A_{\mathbf{q}}^{\lambda} \Phi_{\mathbf{q}}^{\epsilon \lambda}(0), \qquad (5.18)$$

$$(1+F-G_1+G_1A_{\mathfrak{q}}^{\lambda})\Phi_{\mathfrak{q}}^{c\lambda}(0) + \sum_{\mu \neq \lambda} (F-G_2+G_2A_{\mathfrak{q}}^{\mu})\Phi_{\mathfrak{q}}^{c\mu}(0) = -(G_1A_{\mathfrak{q}}^{\lambda}+G_2\sum_{\mu \neq \lambda}A_{\mathfrak{q}}^{\mu})\Phi_{\mathfrak{q}}/N,$$
 (5.19)

where

$$A_{\mathbf{q}}^{\lambda} = 1 - \frac{H + \cos q_{\lambda} a}{1 + H \cos q_{\lambda} a} \tag{5.20}$$

and F,  $G_1$ ,  $G_2$ , and H denote, respectively, the values of the corresponding functions at  $\theta=3$ .

Solving Eq. (5.19) for  $\Phi_q^{e\lambda}(0)(\lambda=x,y,z)$ , and inserting them in Eq. (5.18), we finally obtain the spin-wave spectrum as

$$E_{\mathbf{q}} = (2nt/N)[\mathfrak{F}(\mathbf{q}) - \kappa \mathfrak{G}(\mathbf{q})], \qquad (5.21)$$

where

$$\kappa = \left(\frac{2t}{I}\right) / \left(\frac{n}{N}\right),\tag{5.22}$$

$$g(\mathbf{q}) = 3 - \sum_{\lambda} \cos q_{\lambda} a, \qquad (5.23)$$

$$\mathfrak{F}(\mathbf{q}) = \frac{\sum_{\lambda} A_{\mathbf{q}}^{\lambda} + a \sum_{(\lambda,\mu)} A_{\mathbf{q}}^{\lambda} A_{\mathbf{q}}^{\mu} + b A_{\mathbf{q}}^{x} A_{\mathbf{q}}^{y} A_{\mathbf{q}}^{z}}{1 + c \sum_{\lambda} A_{\mathbf{q}}^{\lambda} + d \sum_{(\lambda,\mu)} A_{\mathbf{q}}^{\lambda} A_{\mathbf{q}}^{\mu} + e A_{\mathbf{q}}^{x} A_{\mathbf{q}}^{y} A_{\mathbf{q}}^{z}},$$

$$(5.24)$$

$$a = \frac{2(G_1 - G_2)}{1 - G_1 + G_2}$$

$$b = 3\left(\frac{G_1 - G_2}{1 - G_1 + G_2}\right)^2,$$

$$c = \frac{(1 + 2F - G_1 - G_2)G_1 - 2(F - G_2)G_2}{(1 - G_1 + G_2)(1 + 3F - G_1 - 2G_2)},$$

$$d = \frac{(G_1 - G_2)\left[(1 + F - G_1)(G_1 + G_2) - 2(F - G_2)G_2\right]}{(1 - G_1 + G_2)^2(1 + 3F - G_1 - 2G_2)},$$
(5.25)

$$e = \frac{(G_1 - G_2)^2 (G_1 + 2G_2)}{(1 - G_1 + G_2)^2 (1 + 3F - G_1 - 2G_2)}.$$

The numerical calculation of the constants F,  $G_1$ ,  $G_2$ , and H will be given in Appendix C. Using the results obtained there, we have

$$H=0.208$$
,  
 $a=0.463$ ,  $b=0.161$ ,  
 $c=0.326$ ,  $d=0.0974$ ,  $e=0.0276$ . (5.26)

The magnitudes of  $\mathfrak{F}(\mathbf{q})$  and  $\mathfrak{G}(\mathbf{q})$  for some special values of  $\mathbf{q}$  are given in Table I.  $E_{\mathbf{q}}$  as a function of  $|\mathbf{q}|$  is shown in Fig. 2 for  $\mathbf{q}$  parallel to (1.1.1) when  $\kappa$  takes several values. When  $\kappa$  increases,  $E_{\mathbf{q}}$  first becomes zero at  $\mathbf{q} = 1/a(\pi,\pi,\pi)$  for  $\kappa = 0.492$ . If  $\kappa > 0.492$ , there appear spin-wave modes with negative energy and the ferromagnetic state becomes unstable. Then it follows that if

$$0.246n/N < t/I$$
, (5.27)

the ferromagnetic state with  $S = S_{\text{max}}$  is not the ground state.

We can also calculate the spin-wave spectrum to the next order of n from Eqs. (5.10), (5.12), and (5.13) simply by taking into account the  $\mathbf{p}$  dependence of the functions. For the purpose of examining the stability of the ferromagnetic state it is sufficient to calculate it at  $\mathbf{q} = \mathbf{q}_0 \equiv 1/a(\pi,\pi,\pi)$ . Putting  $\mathbf{q} = \mathbf{q}_0$  in Eqs. (5.10), (5.12), and (5.13), and eliminating  $\Phi_{\mathbf{q}_0}^{*a}(\mathbf{p})$  from Eqs. (5.12) and (5.13), we have

$$\left[\epsilon_{q_0} + \frac{12t}{I} - \frac{2}{N} \sum_{p > \lambda} \sum_{\lambda} \cos p_{\lambda} a\right] \Phi_{q_0} = 2 \sum_{p > \lambda} \Phi_{q_0}^{c\lambda}(\mathbf{p}), \qquad (5.28)$$

$$\left[1+F(\theta_{\mathbf{p}})+\frac{\cos p_{\lambda}a-H(\theta_{\mathbf{p}})}{1-(\cos p_{\lambda}a)H(\theta_{\mathbf{p}})}G_{1}(\theta_{\mathbf{p}})\right]\Phi_{\mathbf{q}0}^{c\lambda}(\mathbf{p})+\sum_{\mu\neq\lambda}\left[F(\theta_{\mathbf{p}})+\frac{\cos p_{\mu}a-H(\theta_{\mathbf{p}})}{1-(\cos p_{\mu}a)H(\theta_{\mathbf{p}})}G_{2}(\theta_{\mathbf{p}})\right]\Phi_{\mathbf{q}0}^{c\mu}(\mathbf{p}) \\
=-2\left[G_{1}(\theta_{\mathbf{p}})+2G_{2}(\theta_{\mathbf{p}})\right]\Phi_{\mathbf{q}0}/N. \quad (5.29)$$

From Eq. (5.29) we obtain, to the order of  $p^2$ ,

$$\sum_{\lambda} \Phi_{qo}^{c\lambda}(p) = -\left\{ \frac{18F}{1+6F} + \left[ \frac{1+H}{1-H} \left( \frac{3F}{1+6F} \right)^2 - \frac{6(3\beta+F+3F^2)}{(1+6F)^2} \right] \times \frac{1}{2} (pa)^2 \right\} 2\Phi_{qo} / N,$$
 (5.30)

where use has been made of Eqs. (C4) and (C14). Then the spin-wave energy is found from Eqs. (5.28) and (5.30) to be

$$E_{q0} = 2t \left\{ -\frac{12t}{I} + \frac{6}{1+6F} \frac{n}{N} - \left[ 1 + \frac{1+H}{1-H} \left( \frac{3F}{1+6F} \right)^2 - \frac{6(3\beta+F+3F^2)}{(1+6F)^2} \right] \frac{1}{N} \sum_{p>} (pa)^2 \right\}.$$
 (5.31)

Using

$$N^{-1} \sum_{\mathbf{p}>} (pa)^2 \cong \frac{3}{5} (6\pi^2)^{2/3} (n/N)^{5/3}$$

and substituting the numerical values calculated in Appendix C, we finally obtain

$$E_{q_0} = 12t[-2t/I + 0.492(n/N) - 0.404(n/N)^{5/3}].$$
 (5.32)

The boundary in (2t/I)-(n/N) plane at which the ferromagnetic state becomes unstable is given by

$$2t/I = 0.492(n/N) - 0.404(n/N)^{5/3},$$
 (5.33)

which is shown in Fig. 3. It should be noticed here that, as n increases, the curve deviates downwards from the linear one given by the first term.

Table I. The magnitudes of  $\mathfrak{F}(q)$  and  $\mathfrak{G}(q)$  for some special values of q.

| ${f q}a$                                 | $\mathfrak{F}(\mathbf{q})$                | $g(\mathbf{q})$           |
|------------------------------------------|-------------------------------------------|---------------------------|
| ~0                                       | $0.656 \times \frac{1}{2} (qa)^2$         | $\frac{1}{2}(qa)^2$       |
| $(\pi, 0, 0)$                            | 1.21                                      | 2                         |
| $(\pi,\pi,0)$                            | 2.17                                      | 4                         |
| $\simeq^{(\pi,\pi,0)}_{(\pi,\pi,\pi)^a}$ | $2.96 - 0.370 \times \frac{1}{2} (q'a)^2$ | $6 - \frac{1}{2} (q'a)^2$ |

 $<sup>\</sup>mathbf{q}' = \mathbf{q} - \mathbf{q}_0, \ \mathbf{q}_0 a = (\pi, \pi, \pi).$ 

#### 6. DISCUSSION

In the preceding sections we gave the proof of the theorems (I), (II), and (III) stated in Sec. 1. For Case B (fcc and hcp with  $N_e > N$ ) it was found that when n=1 and  $I=\infty$  the ferromagnetic state with  $S=S_{\max}$  is not the ground state. This seems to be true for finite n and I as long as n/N and t/I are sufficiently small, for there is no interaction which favors the ferromagnetic ordering. On the other hand, it was shown for Case A (sc and bcc; fcc and hcp with  $N_e < N$ ) that if the ratio  $\kappa = (2t/I)/(n/N)$  as well as t/I, and n/N is sufficiently small, the ferromagnetic state with  $S=S_{\max}$  is the ground state, and that if  $\kappa$  is larger than some constant it is not the ground state. In the following we shall discuss this case in some detail.

When n=0 and I is finite, i.e., on the (2t/I) axis in the (n/N)-(2t/I) plane, it is very likely that the ground

state is antiferromagnetic, because we have an effective antiferromagnetic interaction of the order  $t^2/I$  if t/I is small. This seems to be true even for finite n if  $\kappa$  is sufficiently large. Then there arises the question how the transition occurs from the ferromagnetic state with  $S = S_{\text{max}}(F)$  to the antiferromagnetic state (A) when  $\kappa$ increases. There are various possibilities, which are shown schematically in Fig. 4 as a phase diagram in the (n/N)-(2t/I) plane. In Fig. 4(a) the transition  $F \rightarrow A$ occurs discontinuously. What we can say for this case is that the transition should occur at the value of  $\kappa$  small than  $\kappa_0$  predicted by the calculation of the spin-wave energy in Sec. 5. In Fig. 4(b), where F' denotes the ferromagnetic state with  $0 < S < S_{max}$ , there are four possibilities according that the transitions  $F \rightarrow F'$  and  $F' \rightarrow A$  occur continuously or discontinuously. In this case, the transition  $F \to F'$  should occur just at  $\kappa = \kappa_0$  if it is continuous, and at  $\kappa < \kappa_0$  if it is discontinuous. Within the argument of this paper we cannot determine which is the case for each lattice structure among these possibilities.

![](_page_9_Figure_22.jpeg)

Fig. 2. The spin-wave energy as a function of  $|\mathbf{q}|$  for  $\mathbf{q}$  parallel to (1,1,1) when  $\kappa$  takes four values, 0, 0.250, 0.400, and 0.492.

![](_page_10_Figure_1.jpeg)

Fig. 3. The boundary curve for sc in the (2t/I)-(n/N) plane at which the ferromagnetic with  $S = S_{\max}$  becomes unstable for spin-wave excitations. F denotes the region where the ferromagnetic state with  $S = S_{\max}$  is the ground state.

Next we consider what happens when n increases with given I. For small n, the ferromagnetic ordering of the spins are favored energetically by the motion of the holes. As n increases, the volume in which the holes can move decreases. Then it is plausible that the energy gain per hole due to the ferromagnetic ordering decreases with increasing n. The boundary curve of the ferromagnetic region F is therefore expected to bend downwards and to reach finally the (n/N) axis at some value of n. The calculation for sc in Sec. 5 shows that this behavior is seen in the next order of n. According to Kanamori's theory,<sup>3,5</sup> the ground state is not ferromagnetic for sc and bcc if  $n \ge N$ . This is consistent with the above prediction. For fcc and hcp it is very likely that the ground state is ferromagnetic when  $n \simeq N$ , for the density of states diverges at the band edge. Then it seems that the (n/N) axis is divided into three (or more) regions, among which the regions  $0 < n < n_1$  and  $n_2 < n < 1$  are those of the ferromagnetic ground state.

There remain some problems even for the limiting case  $n/N\ll 1$  and  $t/I\ll 1$ . In this paper we first considered the case t/I=0 and  $n/N\neq 0$ , and then proceeded to the case  $t/I\neq 0$  and  $n/N\neq 0$ . The next problem is to start from the case n/N=0 and  $t/I\neq 0$ . This seems to be more difficult than the present problem, since we have no exact ground state even at the starting point n/N=0 and  $t/I\neq 0$ . The problem will be left for future investigations.

![](_page_10_Figure_5.jpeg)

Fig. 4. Possible phase diagrams in the (2t/I)-(n/N) plane for Case A: F, ferromagnetic region,  $S = S_{\rm max}$ ; F', ferromagnetic region,  $0 < S < S_{\rm max}$ ; A, antiferromagnetic region, S = 0.

Note added in proof. Recently Penn<sup>8a</sup> studied the same model for sc, using the self-consistent field approximation. His result for small n/N, t/I and  $\kappa$  seems to be consistent with our rigorous conclusion.

#### ACKNOWLEDGMENTS

I should like to thank Professor Harry Suhl and Professor Kazumi Maki for valuable discussions, R. M. More for reading the manuscript, and Dr. D. J. Thouless for informing me of his unpublished work.

#### APPENDIX A

In this Appendix we show briefly that for two- and three-dimensional lattices the corresponding super-lattice defined in Sec. 2 cannot be decomposed into two or more disconnected parts, or in other words, that it is always possible to rearrange spins in the lattice from one configuration to another.

![](_page_10_Picture_12.jpeg)

Fig. 5. The superlattice for the case of  $2\times2$  square lattice (N=4) with  $N_{\uparrow}=2$  and  $N_{\downarrow}=1$ .

Let us first consider a two-dimensional square lattice by means of mathematical induction. For a  $2\times 2$  lattice  $(N=4, N_e=3)$ , it can be shown directly for any numbers of  $N_{\uparrow}$  and  $N_{\downarrow}$ . When  $N_{\uparrow}=3$  (or  $N_{\downarrow}=3$ ), it is obvious. When  $N_{\uparrow}=2$  and  $N_{\downarrow}=1$  (or  $N_{\downarrow}=2$  and  $N_{\uparrow}=1$ ), we have 12 lattice points in the superlattice, which are shown in Fig. 5. They form one connected ring. Next, let us assume that for an  $N \times M$  lattice all lattice points in the corresponding superlattice are connected, and construct an  $N \times (M+1)$  lattice by adding one column at the edge. In rearranging the spins from one configuration to another, we first consider spins on the added column. Then it is always possible to replace any unwanted spin on the column by the wanted one by moving the vacant site on and near the column. This can easily be verified by considering some examples. If we have succeeded in getting the spin configuration we want on the column, there remains only the problem of the rearrangement in an  $N \times M$  lattice, which is always possible by the assumption. Thus it is proved for a two-dimensional square lattice that all lattice points in the superlattice are connected. It can also be proved for a two-dimensional triangle lattice in a similar way.

Now it is easy to prove it for three-dimensional <sup>8a</sup> D. R. Penn, Phys. Rev. **142**, 350 (1966).

lattices. We have only to divide the lattice into many two-dimensional sheets, and to make the rearrangement for each sheet one by one.

#### APPENDIX B

In this Appendix we prove (II) for hcp in the same way as we did for fcc in Sec. 4.

Putting n=1 and  $I=\infty$  in Eq. (3.9), we have

$$E\Phi_0(j;i) = -(1-\delta_{ij}) \sum_{i'} t_{i'i}\Phi_0(j;i') - t_{ji}\Phi_0(i;j) . \quad (B1)$$

In taking the Fourier transform of Eq. (B1), we should be careful because a unit cell contains two atoms in a hcp structure. Let us denote two atomic sites in the *i*th cell by  $i_1$  and  $i_2$ , and define four  $\Phi_{\alpha\beta}(j;i)$  by

$$\Phi_{\alpha\beta}(j;i) = \Phi_0(j_\alpha;i_\beta), \quad \alpha,\beta = 1,2.$$
 (B2)

Then, introducing Fourier transforms by

$$\Phi_{\alpha\beta}(j;i) = \sum_{\mathbf{q}\mathbf{k}} \Phi_{\alpha\beta}(\mathbf{q};\mathbf{k}) e^{-i\mathbf{q}\cdot\mathbf{r}_j - i\mathbf{k}\cdot(\mathbf{r}_i - \mathbf{r}_j)}, \quad (B3)$$

$$t_{a,b}(\mathbf{k}) = \sum_{i} t_{j_{1,2}i_{1}} e^{-i\mathbf{k}\cdot(\mathbf{r}_{j}-\mathbf{r}_{i})}, \qquad (B4)$$

where  $\mathbf{r}_i$  is the position vector of the representative point of the *i*th cell, we obtain the equation for  $\Phi_{\alpha\beta}(\mathbf{q}; \mathbf{k})$ 

$$\begin{split} E\Phi_{11}(\mathbf{q};\,\mathbf{k}) &= -t_a(\mathbf{k})\Phi_{11}(\mathbf{q};\,\mathbf{k}) - t_b(\mathbf{k})\Phi_{12}(\mathbf{q};\,\mathbf{k}) \\ &+ (2/N) \sum_{\mathbf{k}'} \left[ t(\mathbf{k}') - t(\mathbf{k} + \mathbf{k}' - \mathbf{q}) \right] \Phi_{11}(\mathbf{q};\,\mathbf{k}') + (2/N) \sum_{\mathbf{k}'} t_b(\mathbf{k}')\Phi_{12}(\mathbf{q};\,\mathbf{k}') \;, \\ E\Phi_{12}(\mathbf{q};\,\mathbf{k}) &= -t_a(\mathbf{k})\Phi_{12}(\mathbf{q};\,\mathbf{k}) - t_b^*(\mathbf{k})\Phi_{11}(\mathbf{q};\,\mathbf{k}) - (2/N) \sum_{\mathbf{k}'} t_b^*(\mathbf{k} + \mathbf{k}' - \mathbf{q})\Phi_{21}(\mathbf{q};\,\mathbf{k}') \;, \end{split}$$

$$E\Phi_{21}(\mathbf{q};\mathbf{k}) = -t_a(\mathbf{k})\Phi_{21}(\mathbf{q};\mathbf{k}) - t_b(\mathbf{k})\Phi_{22}(\mathbf{q};\mathbf{k}) - (2/N)\sum_{\mathbf{k}'}t_b(\mathbf{k} + \mathbf{k}' - \mathbf{q})\Phi_{12}(\mathbf{q};\mathbf{k}'),$$
(B5)

$$E\Phi_{22}(\mathbf{q};\mathbf{k}) = -t_a(\mathbf{k})\Phi_{22}(\mathbf{q};\mathbf{k}) - t_b^*(\mathbf{k})\Phi_{21}(\mathbf{q};\mathbf{k})$$

$$+(2/N)\sum_{\bf k'}[t_a({\bf k'})-t_a({\bf k}+{\bf k'}-{\bf q})]\Phi_{22}({\bf q};{\bf k'})+(2/N)\sum_{\bf k'}t_b*({\bf k'})\Phi_{21}({\bf q};{\bf k'}).$$

The solution of Eq. (B5) which corresponds to the solution (3.14) of Eq. (3.13) is given by

$$\Phi_{11}(\mathbf{q}; \mathbf{k}) = A \left( \delta_{\mathbf{k}\mathbf{q}} - 2/N \right), \quad \Phi_{12}(\mathbf{q}; \mathbf{k}) = B \delta_{\mathbf{k}\mathbf{q}}, 
\Phi_{21}(\mathbf{q}; \mathbf{k}) = A \delta_{\mathbf{k}\mathbf{q}}, \qquad \Phi_{22}(\mathbf{q}; \mathbf{k}) = B \left( \delta_{\mathbf{k}\mathbf{q}} - 2/N \right), \tag{B6}$$

with

$$EA = -t_a(\mathbf{q})A - t_b(\mathbf{q})B,$$
  

$$EB = -t_a(\mathbf{q})B - t_b^*(\mathbf{q})A.$$
(B7)

So far we have assumed nothing about the lattice structure and the transfer matrix elements  $t_{ij}$  except that a unit cell contains two atoms. For a special case of hcp with assumption (b) and t<0, we have

$$t_{a}(\mathbf{k}) = -|t|\theta_{a}(\mathbf{k}), \quad \theta_{a}(\mathbf{k}) = \sum_{i=1}^{3} \left(e^{i\mathbf{k}\cdot\mathbf{a}_{i}} + e^{-i\mathbf{k}\cdot\mathbf{a}_{i}}\right),$$

$$t_{b}(\mathbf{k}) = -|t|\theta_{b}(\mathbf{k}), \quad \theta_{b}(\mathbf{k}) = \sum_{j=0}^{2} \left(e^{i\mathbf{k}\cdot\mathbf{a}_{j}} + e^{i\mathbf{k}\cdot\mathbf{a}_{j+1}}\right),$$
(B8)

where

$$\mathbf{a}_{0} = 0,$$

$$\mathbf{a}_{1} = a(\frac{1}{2}, -\sqrt{3}/2, 0),$$

$$\mathbf{a}_{2} = a(1,0,0),$$

$$\mathbf{a}_{3} = a(\frac{1}{2}, \sqrt{3}/2, 0),$$

$$\mathbf{a}_{j+4} = \mathbf{a}_{j} + a(0, 0, -2\sqrt{\frac{2}{3}}),$$
(B9)

a denoting the lattice constant. The energy spectrum of the band is given by

$$t_{\pm}(\mathbf{k}) = -|t|\theta_{\pm}(\mathbf{k}),$$
  

$$\theta_{\pm}(\mathbf{k}) = \theta_{a}(\mathbf{k}) \pm |\theta_{b}(\mathbf{k})|.$$
(B10)

The band top is located at

$$k_z = 0$$
,  $\frac{1}{2}k_x a = \pm (\pi/2)$  or  $\frac{1}{2}k_x a \pm (\sqrt{3}/2)k_y a = \pm \pi$ , (B11)

where the energy is given by 4|t|. Then the lowest energy of the  $S=S_{\text{max}}$  states is given by -4|t|. For  $\mathbf{q}=0$ , substitution of Eq. (B8) in Eq. (B5) gives

$$\begin{bmatrix} \epsilon - \theta_a(\mathbf{k}) \end{bmatrix} \Phi_{11}(\mathbf{k}) - \theta_b(\mathbf{k}) \Phi_{12}(\mathbf{k}) = -\sum_{i=1}^3 \left[ (1 - e^{i\mathbf{k} \cdot \mathbf{a}_i}) \Phi_{11}^i + (1 - e^{-i\mathbf{k} \cdot \mathbf{a}_i}) \overline{\Phi}_{11}^i \right] - \sum_{j=0}^2 \left( \Phi_{12}^j + \overline{\Phi}_{12}^j \right),$$

$$\begin{bmatrix} \epsilon - \theta_a(\mathbf{k}) \end{bmatrix} \Phi_{12}(\mathbf{k}) - \theta_b^*(\mathbf{k}) \Phi_{11}(\mathbf{k}) = \sum_{j=0}^2 \left[ e^{-i\mathbf{k} \cdot \mathbf{a}_j} \Phi_{21}^j + e^{-i\mathbf{k} \cdot \mathbf{a}_j} + \overline{\Phi}_{21}^j \right],$$
(B12)

$$\left[\epsilon - \theta_a(\mathbf{k})\right] \Phi_{21}(\mathbf{k}) - \theta_b(\mathbf{k}) \Phi_{22}(\mathbf{k}) = \sum_{j=0}^{2} \left[ e^{i\mathbf{k} \cdot \mathbf{a}j} \Phi_{12}^{j} + e^{i\mathbf{k} \cdot \mathbf{a}j + 4} \overline{\Phi}_{12}^{j} \right],$$

$$\left[ \epsilon - \theta_a(\mathbf{k}) \right] \Phi_{22}(\mathbf{k}) - \theta_b^*(\mathbf{k}) \Phi_{21}(\mathbf{k}) = -\sum_{i=1}^3 \left[ (1 - e^{i\mathbf{k} \cdot \mathbf{a}_i}) \Phi_{22}^i + (1 - e^{-i\mathbf{k} \cdot \mathbf{a}_i}) \overline{\Phi}_{22}^i \right] - \sum_{j=0}^2 \left( \Phi_{21}^j + \overline{\Phi}_{21}^j \right) ,$$

where

$$\begin{split} & \Phi_{\alpha\beta}(\mathbf{k}) = \Phi_{\alpha\beta}(0; \mathbf{k}) , \\ & \epsilon = E/|t| , \\ & \Phi_{\alpha\alpha}{}^i = (2/N) \sum_{\mathbf{k}} e^{i\mathbf{k} \cdot \mathbf{a}i} \Phi_{\alpha\alpha}(\mathbf{k}) , \\ & \bar{\Phi}_{\alpha\alpha}{}^i = (2/N) \sum_{\mathbf{k}} e^{-i\mathbf{k} \cdot \mathbf{a}i} \Phi_{\alpha\alpha}(\mathbf{k}) , \\ & \bar{\Phi}_{12}{}^j = (2/N) \sum_{\mathbf{k}} e^{i\mathbf{k} \cdot \mathbf{a}j} \Phi_{12}(\mathbf{k}) , \\ & \bar{\Phi}_{12}{}^j = (2/N) \sum_{\mathbf{k}} e^{i\mathbf{k} \cdot \mathbf{a}j} \Phi_{12}(\mathbf{k}) , \\ & \bar{\Phi}_{12}{}^j = (2/N) \sum_{\mathbf{k}} e^{i\mathbf{k} \cdot \mathbf{a}j} \Phi_{12}(\mathbf{k}) , \\ & \Phi_{21}{}^j = (2/N) \sum_{\mathbf{k}} e^{-i\mathbf{k} \cdot \mathbf{a}j} \Phi_{21}(\mathbf{k}) , \\ & \bar{\Phi}_{21}{}^j = (2/N) \sum_{\mathbf{k}} e^{-i\mathbf{k} \cdot \mathbf{a}j} \Phi_{21}(\mathbf{k}) . \end{split}$$

Now our problem is to see whether Eq. (B12) has any nontrivial solution for  $\epsilon < -4$  (i.e., E < -4 |t|). From Eq. (B12) we can derive a set of simultaneous equations for 24 components,  $\Phi_{\alpha\alpha}{}^i$ ,  $\bar{\Phi}_{\alpha\alpha}{}^i$ ,  $\Phi_{\alpha\beta}{}^j$ , and  $\bar{\Phi}_{\alpha\beta}{}^i$ . Though these equations can be diagonalized easily, for our purpose it is sufficient to show, if any, the equation of one component which has a nontrivial solution for  $\epsilon < -4$ .

Putting

$$\begin{split} \Phi_{\alpha} &= (\Phi_{\alpha\alpha}{}^{1} - \overline{\Phi}_{\alpha\alpha}{}^{1}) - (\Phi_{\alpha\alpha}{}^{2} - \overline{\Phi}_{\alpha\alpha}{}^{2}) + (\Phi_{\alpha\alpha}{}^{3} - \overline{\Phi}_{\alpha\alpha}{}^{3}) \;, \quad \alpha = 1, 2, \end{split}$$
 (B14)

we have the equation for  $\Phi_{\alpha}$  as

$$[1-J(\epsilon)]\Phi_{\alpha}=0$$
, (B15)

where

$$J(\epsilon) = \frac{1}{N} \sum_{\mathbf{k}} j(\mathbf{k}) \left\{ \frac{1}{\epsilon - \theta_{+}(\mathbf{k})} + \frac{1}{\epsilon - \theta_{-}(\mathbf{k})} \right\}$$
(B16)

$$j(\mathbf{k}) = -2[\sin^2 \mathbf{k} \cdot \mathbf{a}_2 + (\cos \mathbf{k} \cdot \mathbf{a}_1 - 1) \times \cos \mathbf{k} \cdot \mathbf{a}_2 - \sin \mathbf{k} \cdot \mathbf{a}_1 \sin \mathbf{k} \cdot \mathbf{a}_2].$$

The behavior of  $J(\epsilon)$  for  $\epsilon \rightarrow -4-0$  can be seen in a

similar way to the case of  $H_{-}(\epsilon)$  in Sec. 4. As we have

$$\langle j(\mathbf{k}) \rangle_{\text{band top}} = -\frac{4}{3},$$
 (B17)

it turns out that

$$\lim_{\epsilon \to -4-0} J(\epsilon) = \langle j(\mathbf{k}) \rangle_{\text{band top}} \lim_{\epsilon \to -4-0} \frac{1}{N}$$

$$\times \sum_{\mathbf{k}} \left\{ \frac{1}{\epsilon - \theta_{+}(\mathbf{k})} + \frac{1}{\epsilon - \theta_{-}(\mathbf{k})} \right\} \quad (B18)$$

$$= \infty$$

It is clear from Eq. (B18) that Eq. (B15) has at least one nontrivial solution for  $\epsilon < -4$ , which means the  $S = S_{\text{max}}$  state is not the ground state. This is the proof of (II) for hcp.

## APPENDIX C

In this Appendix we calculate some numerical constants which appeared in the calculation of Sec. 5. Introducing the function

$$I(\theta) = N^{-1} \sum P(\theta - \theta_{\mathbf{k}})^{-1},$$
 (C1)

we can prove the following relations:

$$G_1(\theta) + H(\theta) = I(\theta)$$
, (C2)

$$F(\theta) = \frac{1}{3} \lceil \theta I(\theta) - 1 \rceil$$
, (C3)

$$G_1(\theta) + 2G_2(\theta) = \theta F(\theta)$$
 (C4)

Equation (C2) is obvious, while Eq. (C3) is derived as

$$F(\theta) = \frac{1}{3N} \sum_{\mathbf{k}} \frac{\sum_{\lambda} \cos k_{\lambda} a}{\theta - \sum_{\lambda} \cos k_{\lambda} a}$$
$$= \frac{1}{3N} \sum_{\mathbf{k}} \left( \frac{\theta}{\theta - \sum_{\lambda} \cos k_{\lambda} a} - 1 \right)$$
$$= \frac{1}{3} \left[ \theta I(\theta) - 1 \right].$$

Equation (C4) can also be proved in a similar way. I(3) is one of the so-called Watson integrals, which is given by

$$I(3) = 0.50546$$
. (C5)

For  $\theta \ge 3$ ,  $H(\theta)$  can be rewritten as

$$H(\theta) = \frac{1}{\pi^3} \int \int_0^{\pi} \int \frac{\sin^2 \alpha_1 \prod_i^3 d\alpha_i}{\theta - \sum_i^3 \cos \alpha_i}$$

$$= \int_0^{\infty} dt \frac{1}{\pi^3} \int \int_0^{\pi} \int \sin^2 \alpha_1$$

$$\times \exp[-(\theta - \sum_i^3 \cos \alpha_i)t] \prod_i^3 d\alpha_i$$

$$= \int_0^{\infty} dt e^{-\theta t} I_1(t) [I_0(t)]^2,$$

where  $I_0(t)$  and  $I_1(t)$  are modified Bessel functions of the first kind. Using Eq. (C6), we calculate H(3) numerically.<sup>10</sup> The result is

$$H(3) = 0.208$$
. (C7)

From Eqs. (C2)-(C5) and (C7) we obtain

$$G_1(3) = 0.297$$
, (C8)

$$G_2(3) = 0.109$$
, (C9)

$$F(3) = 0.172$$
. (C10)

Next we consider the  $\theta$  dependence of  $I(\theta)$  near  $\theta = 3$ . For  $\theta \gtrsim 3$ , it is expanded as

$$I(\theta) = I(3) - (\sqrt{2}\pi)^{-1}(\theta - 3)^{1/2} - \alpha(\theta - 3) + \cdots$$
 (C11)

If we consider  $z=\theta-3$  as a complex number, and make an analytic continuation of the function from the positive real axis to the negative real axis, then the  $\sqrt{z}$  term only contributes to the imaginary part, and we have for  $\theta \lesssim 3$ 

$$I(\theta) = I(3) + \alpha(3 - \theta) + \cdots$$
 (C12)

The coefficient  $\alpha$  can be estimated numerically from the table given by Mannari and Kawabata.<sup>11</sup> We get

$$\alpha = 0.054$$
. (C13)

From Eqs. (C3), (C5), (C12) and (C13) we obtain for  $\theta \lesssim 3$ 

$$F(\theta) = F(3) - \beta(3 - \theta) + \cdots, \qquad (C14)$$

where

(C6)

$$\beta = 0.114$$
. (C15)

<sup>&</sup>lt;sup>9</sup> G. N. Watson, Quart. J. Math. (Oxford) 10, 266 (1939).

<sup>&</sup>lt;sup>10</sup> It seems to the author that there is an analytical method to calculate it, though he could not find it.

<sup>&</sup>lt;sup>11</sup> I. Mannari and C. Kawabata, Research Notes of the Department of Physics, Okayama University, Japan, No. 15, 1964 (unpublished).