## Fermi-Edge Singularity in One-Dimensional Systems

## Tetsuo Ogawa

NTT Basic Research Laboratories, Midori-cho, Musashino-shi, Tokyo 180, Japan

## Akira Furusaki and Naoto Nagaosa

Department of Applied Physics, The University of Tokyo, Hongo, Bunkyo-ku, Tokyo 113, Japan (Received 2 March 1992)

The Fermi-edge singularity in optical spectra is studied theoretically using the Tomonaga-Luttinger model for one-dimensional (1D) systems. Its critical exponent is obtained analytically for an arbitrary mass of a valence hole taking into account the electronic correlation. The exponent is found to be independent of the hole dynamics in 1D, which is in striking contrast to the 2D and 3D cases. Weak repulsive interaction among the conduction electrons sharpens the power-law peak in the edge spectrum.

PACS numbers: 78.65.-s, 71.45.-d, 78.70.-g

One-dimensional (1D) structures made of inorganic III-V semiconductor compounds, "quantum wires," have been extensively studied because of the development of microfabrication technology. Their electron-lattice coupling is weaker than in organic semiconductors. Thus, many electrons can be doped heavily into the conduction band by modulation doping, resulting in a 1D metallic material with a Fermi sea. Phonon effects and the lattice distortion can be neglected in the first approximation. Therefore, a heavily doped quantum wire is a good example of a 1D degenerate electron system for studying intrinsic many-body effects in geometrically restricted systems

One of the most striking phenomena due to the Fermisurface effect is the power-law anomaly in optical spectra near the Fermi edge, i.e., the Fermi-edge singularity (FES) [1]. The optical absorption (emission) spectrum  $I(\omega)$  in the vicinity of the absorption (emission) edge  $E_0$  behaves as  $I(\omega) \sim |\omega - E_0|^{\beta}$ . In experiments, the FES in a doped semiconductor wire was observed by Calleja et al. [2], who stressed that the FES peaks (for  $\beta < 0$ ) in 1D are sharper than in higher dimensions.

So far, theoretical studies of the FES have been limited to the case of a *localized* hole (an infinite hole mass) in bulk simple metals [1]. Only for this case does the FES take place and an analytical expression of  $\beta$  was given; the FES disappears when the effective mass of the hole is

finite [3] in bulk or quantum-well semiconductors [4]. Thus the FES has been thought to depend sensitively on the hole dynamics. Hence two questions arise: Why can the FES peaks be observed clearly in 1D semiconductors [2]? How do the hole recoil and the electronic correlations affect the FES in 1D? The main purpose of this Letter is to give an analytical expression for the critical exponent  $\beta$  in 1D systems for an arbitrary hole mass taking into account electronic correlations. The hole-localization problem is first discussed by taking account of the infrared divergence of the Fermi sea. Next physical mechanisms for yielding the FES in 1D are clarified by investigating the exponent.

We shall consider an n-type heavily doped quantum wire with a direct gap (gap energy  $E_G$ ). When the motion perpendicular to a 1D axis (hereafter denoted the x axis) is confined within a radius of R, we have quantized 1D bands with separation of order  $h^2(\pi/R)^2/2m^*$ , where  $m^*$  is the effective mass of conduction electrons. When this separation is greater than the Fermi energy  $E_F = h^2 k_F^2/2m^*$ , only the lowest subband is occupied and the system can be regarded as 1D. This condition is expressed by  $k_F R < \pi$ , i.e.,  $n_{1D} < 2/R$ , where  $n_{1D}$  is the 1D density of the doped electrons. For  $R \approx 10$  nm,  $n_{1D} < 2.0 \times 10^6$  cm<sup>-1</sup>.

In this case, the system is described by the following 1D Hamiltonian:

$$\mathcal{H} = \sum_{p,\sigma} \varepsilon(p) a^{\dagger}_{p\sigma} a_{p\sigma} + \sum_{p,\sigma} [\omega_0 - \varepsilon_v(p)] d^{\dagger}_{p\sigma} d_{p\sigma}$$

$$+ \frac{1}{2L} \sum_{p,p',q} \sum_{\sigma,\sigma'} [V^c(q) a^{\dagger}_{p+q,\sigma} a^{\dagger}_{p'-q,\sigma'} a_{p'\sigma'} a_{p\sigma} - V^{cv}(q) d^{\dagger}_{p+q,\sigma} d_{p\sigma} a^{\dagger}_{p'-q,\sigma'} a_{p',\sigma'}], \qquad (1)$$

where L is the system size,  $\omega_0$  is the energy offset of the valence band  $[\omega_0 = E_F + E_G + \varepsilon_c(0)]$ , and  $a_{p\sigma}^{\dagger}$  and  $a_{p\sigma}$  ( $d_{p\sigma}^{\dagger}$  and  $d_{p\sigma}$ ) are creation and annihilation operators of the conduction electron (valence hole) with momentum p and spin  $\sigma$ , whose dispersion is given by  $\varepsilon(p)$   $[\varepsilon_c(p)]$ . When the doping density is high enough (large  $E_F = k_B T_F$ ), the Fermi points  $\pm k_F$  become well defined at low temperature  $(T \ll T_F)$  so we may linearize the conduction-band dispersion near these points as  $\varepsilon(p) \approx \varepsilon_j(p) \equiv \pm v_F(p \mp k_F)$ , where  $v_F$  is the Fermi velocity

of the conduction electrons and j=1 (j=2) corresponds to the right (left) branch of the conduction band [5]. Since we are interested in  $\beta$  near the Fermi edge, this linearization procedure is a good approximation of the band structure.

The scattering strength within the conduction band is represented by  $g^c = 2V^c/\pi$ , while the simultaneous scattering between a conduction electron and a valence hole is represented by  $g^{cc} = 2V^{cc}/\pi$ . These interaction matrix

elements are assumed to be spin independent. In the low-temperature limit, the interactions between two conduction electrons in 1D are further classified in terms of the momentum transfer q according to the standard definition in g-ology [5]: (i) the forward scattering ( $q \approx 0$ ),  $g_2$  ( $g_4$ ), as an intrabranch scattering of electrons in the different (same) branches and (ii) the backward scattering ( $|q| \approx 2k_F$ ),  $g_1$ , as an interbranch scattering from right to left and from left to right branches. Note that  $|g_1| \ll |g_2|$  and  $|g_1| \ll |g_4|$  because of the  $|q|^{-2}$  dependence of the Coulomb interaction as well as the enhancement of the dielectric function near  $q = \pm 2k_F$  due to the

resonant scattering between the Fermi points. Hence we study the forward-scattering model, which can be solved exactly. The backward-scattering effects due to  $g_1^{cr}$  will be discussed only qualitatively. The umklapp scattering can be neglected in doped semiconductor wires. One of the forward scatterings,  $g_4$ , contributes only to the Fermi-velocity correction. In the following, therefore,  $v_F$  means the Fermi velocity including this correction.

Here we employ the bosonization method [6] to describe the collective excitations of the 1D degenerate electrons [7]. Long-wavelength charge- and spin-density fluctuations are described as Tomonaga-Luttinger (TL) bosons, and Eq. (1) is transformed into

$$\mathcal{H}_{\mathsf{TL}} = \sum_{p} v_{\mathsf{TL}} |p| \alpha_{p}^{\dagger} \alpha_{p} + \sum_{p} v_{F} |p| c_{p}^{\dagger} c_{p} + \sum_{p,\sigma} [\omega_{0} - \varepsilon_{v}(p)] d_{p\sigma}^{\dagger} d_{p\sigma}$$

$$- \frac{g_{2}^{cv}}{2} \left[ \frac{\pi}{L} \right]^{1/2} \left[ \frac{v_{F} - g_{2}^{c}}{v_{F} + g_{2}^{c}} \right]^{1/4} \sum_{p} \sum_{n\sigma} d_{n\sigma}^{\dagger} d_{n\sigma} e^{ipan} \sqrt{|p|} (\alpha_{p} + \alpha_{p}^{\dagger}) , \qquad (2)$$

where *n* is the site index, *a* is the lattice constant, and  $a_p$  and  $a_p^{\dagger}$  ( $c_p$  and  $c_p^{\dagger}$ ) are operators of the charge (spin) of the TL boson whose velocity is  $v_{TL} = [v_F^2 - (g_2^c)^2]^{1/2}$  ( $v_F$ ). We then employ Tomonaga's intermediate-coupling theory and introduce the following unitary transform:

$$U = \exp\left[\sum_{p} \sum_{n\sigma} f_{p} d_{n\sigma}^{\dagger} d_{n\sigma} (e^{ipan} \alpha_{p} - e^{-ipan} \alpha_{p}^{\dagger})\right]. \tag{3}$$

In the case of a single valence hole, the variational parameter  $f_p$  obeys the equation

$$f_p = -\frac{g_2^{cv}}{2} \left( \frac{\pi}{L} \right)^{1/2} \left( \frac{v_F - g_2^c}{v_F + g_2^c} \right)^{1/4} e^{-a|p|/2} \sqrt{|p|} \left[ v_{TL} p - 2te^{-S} (1 - \cos ap) \right]^{-1}, \tag{4}$$

where S is defined as  $S = \sum_{p} |f_p|^2 (1 - \cos ap)$ , t is the transfer integral of the valence hole [i.e.,  $\varepsilon_v(p) = 2t \cos ap$ ], and  $\alpha$  is the cutoff of order  $\alpha \sim a$ .

Our first question is whether the valence hole is localized due to the infrared catastrophe of the Fermi sea. The system with a hole interacting with the degenerate Fermi sea is analogous to a polaron system, provided that the low-energy excitation is described as a TL boson. Using this analogy we evaluate the effective transfer integral  $t^* \equiv te^{-S}$  of the hole, where S is given by a solution of the integral equation

$$S = \frac{(g_2^{cv})^2}{4} \left[ \frac{v_F - g_2^c}{v_F + g_2^c} \right]^{1/2} \int_0^\infty dp \frac{p(1 - \cos ap)e^{-ap}}{[v_{TL}p - 2te^{-S}(1 - \cos ap)]^2}.$$
 (5)

Near  $p \approx 0$  the integrand becomes  $p/2v_{\text{TL}}^2 \approx 0$  without any divergence. Thus S is *finite* and the hole in 1D is not localized even when the low-energy excitations of the 1D Fermi sea are taken into account. This is in contrast to a particle coupled with a dissipative environment, where the factor  $(1 - \cos ap)$  in the numerator of the integrand is missing [8]. The mass renormalization of the hole will be examined in detail elsewhere. Anyway, we need to examine the FES for a *finite* hole mass.

Now we shall turn to the FES for an arbitrary  $t^*$  at zero temperature (T=0). The optical spectrum  $I(\omega)$  is given by the Fourier transform of the correlation function, that is,

$$I(\omega) = 2|M|^2 \operatorname{Re} \int_0^\infty d\tau \, e^{i\omega\tau} C(\tau) \,, \tag{6}$$

$$C(\tau) = \sum_{k,k',\sigma} \langle 0 | e^{i\mathcal{H}_{\mathsf{TL}}\tau} d_{-k,\sigma} a_{k\sigma} e^{-i\mathcal{H}_{\mathsf{TL}}\tau} a_{k'\sigma}^{\dagger} d_{-k',\sigma}^{\dagger} | 0 \rangle, \qquad (7)$$

where M is the interband matrix element (assumed to be constant),  $\tau$  is a real time, and  $|0\rangle$  is the Fermi vacuum at T=0. Using the standard boson algebra and Eq. (3),  $C(\tau)$  is evaluated in the continuum approximation at T=0 as

$$C(\tau) = \frac{e^{-i\hat{\omega}_0 \tau}}{\pi \alpha} \int dx \sum_{p} \exp[i\tau \varepsilon_v(p) e^{-S}] \left\{ \exp[ix(k_F - p) + \Delta_+(x, \tau)] \left[ 1 - i \frac{x - v_F \tau}{\alpha} \right]^{-1/2} + \exp[-ix(k_F + p) + \Delta_-(x, \tau)] \left[ 1 + i \frac{x + v_F \tau}{\alpha} \right]^{-1/2} \right\},$$

$$(8)$$

where  $\varepsilon_{\rm r}(p)e^{-S}$  is the renormalized dispersion of the valence band, and  $\tilde{\omega}_0$  and  $\Delta\pm(x,\tau)$  are given respectively by

$$\tilde{\omega}_0 = \omega_0 + \frac{2}{\pi L} \left( \frac{v_F - g_2^c}{v_F + g_2^c} \right)^{1/2} \sum_{k>0} \left( v_{\text{TL}} h_k^2 - \pi g_2^{c_\ell} h_k \right), \tag{9a}$$

$$\Delta_{\pm}(x,\tau) = -\frac{\pi}{L} \sum_{k \ge 0} \frac{e^{-ak}}{k} \{ c_k^2 [1 - e^{\pm ikx - ikv_{\text{TL}}\tau}] + s_k^2 [1 - e^{\mp ikx - ikv_{\text{TL}}\tau}] \},$$
 (9b)

with  $c_k \equiv \cosh \lambda - h_k e^{-\lambda}/\pi$  and  $s_k \equiv \sinh \lambda - h_k e^{-\lambda}/\pi$ . Here  $\lambda \equiv \frac{1}{4} \ln[(v_F + g_2^c)/(v_F - g_2^c)]$  and  $h_k \equiv \frac{1}{2} \pi g_2^{cc} [v_{TL} - 2t^*(1 - \cos ak)/|k|]^{-1}$ . In the following we investigate the exponent  $\beta$  of the FES determined by the asymptotic form of  $C(\tau) \sim \tau^{-\beta-1}$  for  $\tau \gg h/E_F$ .

In the case of a localized hole  $(t^*=0, \varepsilon_c(p)e^{-S}=0)$ , the p integral in Eq. (8) gives  $\delta(x)$ , which means that the optical transition occurs locally. Then the x integral becomes trivial and  $C(\tau)$  for large  $\tau$  is evaluated as  $C(\tau) \sim \tau^{-\beta_0-1} \exp(-iE_{\rm FES}^0\tau)$ , where  $E_{\rm FES}^0$  is the Fermi-edge energy in the  $t^*=0$  case:  $E_{\rm FES}^0 \equiv \omega_0 - (g_2^{cr})^2/[4a(v_F+g_2^c)]$ . The FES exponent for a localized hole consists of two parts,  $\beta_0 = \beta_{\rm ex} + \beta_{\rm oc}$ , where

$$\beta_{\rm ex} = -\frac{1}{2} + \frac{1}{2} \left( v_F - g_2^{cv} \right) \left[ v_F^2 - (g_2^c)^2 \right]^{-1/2}, \tag{10a}$$

$$\beta_{cc} = \frac{1}{4} (g_2^{cc})^2 (v_F - g_2^c)^{-1/2} (v_F + g_2^c)^{-3/2}. \tag{10b}$$

In the case of a finite hole mass  $(t^* > 0)$ , it has been expected that the recoil of the hole will smear the FES [3,4]. In 1D systems, however, the low-energy excitations have momentum only near 0 or  $2k_F$ , which causes the sharp FES peaks observed even in the  $t^* > 0$  case [2]. The numerical calculation of the finite-size Hubbard model also supports this property [2]. Here we shall analytically confirm this feature and also show that the exponent remains the same as in the case of a localized hole.

In Eq. (8) we linearize the dispersion of the valence hole as  $\varepsilon_r(p)e^{-S} \approx \mp v_F^r(p \mp k_F)$  near  $p = \pm k_F$ . Then integrating over the momentum  $p-k_F$  or  $p+k_F$  gives  $\delta(x+v_F^{\nu}\tau)$  and  $\delta(x-v_F^{\nu}\tau)$  for the first and second terms in the curly brackets of Eq. (8), in contrast to the localized case where  $\delta(x)$  appears. Therefore the exponent  $\beta$ remains the same as that for the localized hole. However, the analyticity of  $\Delta \pm (x, \tau)$  in the complex  $\tau$  plane depends on the sign of  $v_F^v - v_{TL}$ , which appears in the exponents in Eq. (9b). (i) When  $v_F^r < v_{TL}$ ,  $I(\omega) = 0$  for  $\omega < E_{\rm FES}$ , while  $I(\omega) \sim (\omega - E_{\rm FES})^{\beta}$  for  $\omega > E_{\rm FES}$ . Here  $E_{\rm FES}$  is the energy of the absorption edge:  $E_{\rm FES} \equiv \tilde{\omega}_0$  $-\varepsilon_{\rm r}(k_F)e^{-S}$ . (ii) When  $v_F^{\rm r} > v_{\rm TL}$ , on the other hand,  $I(\omega) \sim |\omega - E_{\text{FES}}|^{\beta}$  for both  $\omega < E_{\text{FES}}$  and  $\omega > E_{\text{FES}}$ . In this case, an "indirect" transition takes place at  $\omega$  $\sim E_{\rm FES} - (v_F^c - v_{\rm TL})k_F$  from the top of the valence band (p=0) to the Fermi point in the conduction band  $(p = \pm k_F)$ , together with an excitation of a TL boson (with momentum  $k_F$ ) in the conduction band. Then the FES at  $\omega = E_{\text{FES}}$  will be observed in a continuum spectrum. Physically  $v_F^v < v_{TL}$  is the usual case in the *n*-type doped semiconductors. For p-type doped semiconductors, however, the above discussion can be directly applied by

exchanging the electron and the hole to get  $v_F^v > v_{TL}$ .

Now let us examine the exponent. The critical exponent  $\beta$  is composed of two parts: (i) the many-body excitonic correlation part  $\beta_{\rm ex}$  due to the Coulomb scattering among (N+1) electrons and a valence hole, and (ii) the orthogonality catastrophe part  $\beta_{\rm oc}$  resulting from the infrared divergence of the Fermi sea [9]. Here we note that  $\beta_{\rm oc}$  is also the exponent of the valence-hole Green function, i.e.,  $G_{\rm hole}(\tau) \equiv -i\theta(\tau)\langle d_{\sigma}(\tau)d_{\sigma}^{\dagger}(0)\rangle \sim \tau^{-\beta_{\rm oc}}$  for large  $\tau$ . The phase diagram in the  $(g_2^c, g_2^{cr})$  plane [10] is shown in Fig. 1, which shows the boundary between the divergent edge  $(\beta < 0)$  and the convergent one  $(\beta > 0)$ . We find that electron-hole attraction  $(g_2^{cr} > 0)$  is necessary to obtain the divergent edge.

The dependence of the exponent on  $g_2^{cc}$  is shown in Fig. 2(a). The exciton part  $\beta_{ex}$  is linear in  $g_2^{cc}$  and changes its sign roughly according to the sign of  $g_2^{cc}$ . For  $g_2^{cc} > 0$ ,  $\beta_{ex} < 0$ , while  $\beta_{ex} > 0$  for  $g_2^{cc} < 0$ . On the other hand,  $\beta_{oc}$  is always positive for arbitrary  $g_2^{cc}$ . In usual cases  $(g_2^{cc} > 0)$ , therefore,  $\beta_{ex}$  leads to the divergent edge but  $\beta_{oc}$  tends to make the edge convergent. Thus these two mechanisms compete against each other.

The electronic interaction  $g_2^c$  also affects the exponent [11], as shown in Fig. 2(b). In particular,  $\beta_{oc}$  is asymmetric with respect to  $g_2^c = 0$ , which means that the total exponent  $\beta$  depends on whether the electronic correlation is repulsive  $(g_2^c > 0)$  or attractive  $(g_2^c < 0)$ . For the repulsive case  $[0 < g_2^c < 0.83929v_F]$ ,  $\beta_{oc}$  is smaller than that for  $g_2^c = 0$  and  $\beta_{oc}$  is minimum (but positive) when  $g_2^c = \frac{1}{2}v_F$ . In other words, weak repulsive interaction

![](_page_2_Figure_16.jpeg)

FIG. 1. The phase diagram in the plane of  $\bar{g}_2^c \equiv g_2^c/v_F$  and  $\bar{g}_2^{cc} \equiv g_2^c/v_F$ , showing the boundary between the divergent edge  $(\beta < 0)$  and the convergent one  $(\beta > 0)$ .

![](_page_3_Figure_3.jpeg)

FIG. 2. Total exponent  $\beta$  is plotted by the thick solid curve as a function of (a) the electron-hole interaction  $\bar{g}_2^{cc} = g_2^{cc}/v_F$  for  $g_2^{cc} = 0.3v_F$  and (b) the electronic correlation  $\bar{g}_2^{cc} = g_2^{cc}/v_F$  for  $g_2^{cc} = 0.5v_F$ . Two components,  $\beta_{ex}$  and  $\beta_{oc}$ , are also plotted by thin solid and broken curves, respectively.

among the conduction electrons weakens the orthogonality of the 1D Fermi sea, and consequently makes the FES peak sharper. However, the edge spectrum becomes convergent in the case of strong repulsive correlation, roughly  $g_2^c \gtrsim [g_2^{cr}(2v_F - g_2^{cr})]^{1/2}$ .

Finally we mention the backward scattering between an electron and a hole. Using an analogy to the strong pinning due to an impurity, it is preliminarily found that this backward scattering is irrelevant when  $g_2^c < 0$ . For  $g_2^c > 0$ , a mass gap  $\Delta \epsilon$  is introduced in the excitation spectrum of the Fermi sea, resulting in a cutoff of the FES at  $|\omega - E_{FES}| \sim \Delta \epsilon$ . This problem should be considered using nonperturbative ways. A detailed study on the  $g_1^{cr}$  effects will be reported elsewhere.

In summary, we have shown that the infrared catas-

trophe of the Fermi sea does not lead to the localization of a valence hole in 1D. The critical exponent  $\beta$  of the Fermi-edge singularity has been obtained analytically, taking into account the motion of the hole as well as of the electronic interactions in the conduction band. The  $\beta$  is completely independent of the hole mass in 1D, which is in sharp contrast to the 2D and 3D cases. Weak repulsive interaction among the conduction electrons is favorable to the power-law divergence of the edge spectrum, but strong repulsion makes it convergent. Although our model does not include all the actual details, e.g., lattice distortions, hole lifetime, an exciton bound state, and finite temperature effects, we believe that these new findings hold universally in 1D systems and are of significance in the interpretation of experimental results [2]

The authors thank Professor Kazuo Ohtaka and Dr. Susumu Kurihara for fruitful discussions on the x-ray edge problems.

- [1] G. D. Mahan, Phys. Rev. 153, 882 (1967); 163, 612 (1967); P. Nozières and C. T. DeDominicis, Phys. Rev. 178, 1097 (1969); K. Ohtaka and Y. Tanabe, Rev. Mod. Phys. 62, 929 (1990).
- [2] J. M. Calleja et al., Solid State Commun. 79, 911 (1991).
- [3] E. Müller-Hartmann, T. V. Ramakrishnan, and G. Toulouse, Phys. Rev. B 3, 1102 (1971).
- [4] A. E. Ruckenstein and S. Schmitt-Rink, Phys. Rev. B 35, 7551 (1987); T. Kopp, A. E. Ruckenstein, and S. Schmitt-Rink, Phys. Rev. B 42, 6850 (1990).
- [5] V. J. Emery, in Highly Conducting One-Dimensional Solids, edited by J. T. Devreese, R. P. Evard, and V. E. van Doren (Plenum, New York, 1979); J. Sólyom, Adv. Phys. 28, 201 (1979).
- [6] S. Tomonaga, Prog. Theor. Phys. 5, 544 (1950); J. M. Luttinger, J. Math. Phys. 4, 1154 (1963).
- [7] K. D. Schotte and U. Schotte [Phys. Rev. 182, 479 (1969)] derived the FES exponent using the Tomonaga model for a localized hole, but the electronic correlations and the spin degrees of freedom were disregarded.
- [8] A. Schmid, Phys. Rev. Lett. 51, 1506 (1983); F. Guinea, V. Hakim, and A. Muramatsu, Phys. Rev. Lett. 54, 263 (1985).
- [9] P. W. Anderson, Phys. Rev. Lett. 18, 1049 (1967).
- [10] The critical exponent of the FES and the phase diagram for a *high-density* electron-hole system in 1D are given by N. Nagaosa and T. Ogawa (unpublished).
- [11] K. Yamada and K. Yosida, Prog. Theor. Phys. 60, 353 (1978).

![](_page_4_Figure_0.jpeg)

FIG. 1. The phase diagram in the plane of  $\bar{g}_2^c \equiv g_2^c/v_F$  and  $\bar{g}_2^c \equiv g_2^c/v_F$ , showing the boundary between the divergent edge  $(\beta < 0)$  and the convergent one  $(\beta > 0)$ .