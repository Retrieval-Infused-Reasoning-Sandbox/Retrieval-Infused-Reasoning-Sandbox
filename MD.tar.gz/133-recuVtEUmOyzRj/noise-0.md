# A further generalization of random self-decomposability

S. Satheesha,<sup>∗</sup> , E. Sandhyab,∗∗

<sup>a</sup>NEELOLPALAM, S. N. Park Road, Trichur-680 004, India. <sup>b</sup>Department of Statistics, Prajyoti Niketan College, Pudukkad, Trichur-680 301, India.

### Abstract

The notion of random self-decomposability is generalized further. The notion is then extended to non-negative integer-valued distributions.

Keywords: self-decomposability, random self-decomposability, random infinite divisibility, geometric infinite divisibility, Harris infinite divisibility, geometric distribution, Harris distribution, Laplace transform, characteristic function.

#### 1. Introduction

Recently the notion of random self-decomposability (RSD) has been introduced by Kozubowski and Podg´orski [\[4](#page-6-0)] generalizing SD. They showed that if a CF is RSD then it is both SD and geometrically infinitely divisible (GID). Satheesh and Sandhya [\[9\]](#page-6-1) generalized this notion to Harris-RSD (HRSD) and showed that if a CF is HRSD then it is both SD and Harris-ID (HID). With this nomenclature RSD is geometric-RSD (GRSD). Here we explore further generalizations of HRSD viz. N RSD and ϕRSD, motivated by the elegent Proposition 2.3 in Kozubowski and Podg´orski [\[4\]](#page-6-0).

<sup>∗</sup>Corresponding author e-mail: ssatheesh1963@yahoo.co.in

<sup>∗∗</sup>e-mail: esandhya@hotmail.com

We need the notion of N -infinitely divisible (N ID) laws here. Let ϕ be a Laplace transform (LT) that is also a standard solution to the Poincare equation, ϕ(t) = P(ϕ(θt)), θ ∈ Θ where P is a probability generating function (PGF) (see Gnedenko and Korolev, [\[3\]](#page-6-2), p.140).

Definition 1.1. Let ϕ be a standard solution to the Poincare equation and N<sup>θ</sup> a positive integer-valued random variable (r.v.) having finite mean with PGF Pθ(s) = ϕ( 1 θ ϕ −1 (s)), θ ∈ Θ ⊆ (0, 1). A characteristic function (CF) f(t) is N ID if for each θ ∈ Θ there exists a CF fθ(t) that is independent of N<sup>θ</sup> such that f(t) = Pθ(fθ(t)), for all t ∈ R.

Theorem 1.1. (Gnedenko and Korolev, 1996, Theorem 4.6.3 on p.147) [\[3\]](#page-6-2) Let ϕ be a standard solution to the Poincare equation. A CF f(t) is N ID iff it admits the representation f(t) = ϕ(− log h(t)) where h(t) is a CF that is ID. f(t) is N stable if h(t) is stable (p.151, [\[3](#page-6-2)]).

In the next section we describe N RSD laws and its discrete analogue in Section 3. In Section 4 we describe ϕRSD laws and its discrete analogue.

## 2. NRSD distributions

Definition 2.1. A CF f(t) is N RSD if for each c ∈ (0, 1] and each θ ∈ [0, 1)

$$f_{c,\theta}(t) = f_c(t).f_{\theta}(ct) \tag{1}$$

is a CF, where fc(t) and fθ(t) are given by

$$f_c(t) = \frac{f(t)}{f(ct)} \tag{2}$$

$$f_{\theta}(t) = \varphi\{\theta\varphi^{-1}(f(t))\},\tag{3}$$

ϕ being a standard solution to the Poincare equation.

We now notice that the discussion leading to conceiving and proving Proposition 2.3 in Kozubowski and Podg´orski [\[4\]](#page-6-0) holds in this generalization as well. When c = 1 equation (1) becomes

$$f_{1,\theta}(t) = f_{\theta}(t) = \varphi\{\theta\varphi^{-1}(f(t))\}\tag{4}$$

Or

$$f(t) = \varphi\{\frac{1}{\theta}\varphi^{-1}(f_{\theta}(t))\}\tag{5}$$

for each θ ∈ [0, 1). That is f(t) is N ID and hence has no real zeroes. On the other hand since ϕ(0) = 1, when θ = 0 equation (1) implies

$$f_{c,0}(t) = f_c(t) = \frac{f(t)}{f(ct)}$$
 (6)

is a CF for each c ∈ (0, 1]. That is f(t) is SD.

Conversely, if f(t) is SD then for each c ∈ (0, 1] the function fc(t) in (2) is a genuine CF and similarly if f(t) is N ID then for each θ ∈ [0, 1) the function fθ(t) in (5) also is a genuine CF. Consequently (1) is a well defined CF.

Remark 2.1 It may be noted that for the CF f(t) to be SD we only require that (a result due to Biggins and Shanbhag see Fosum [\[2\]](#page-5-0)) (2) holds for all c in some left neighbourhood of 1. Thus we may simplify the requirement here as: A CF f(t) is N RSD if for each c ∈ (a, 1], and each θ ∈ [0, 1) (1) holds, where 0 < a < 1.

Remark 2.2 In fact we may have apparently still weaker requirement in describing CFs that are N RSD as follows. A CF f(t) is N RSD if for each c ∈ (a, 1), and each θ ∈ (0, 1) (1) holds, where 0 < a < 1. Now letting c ↑ 1 we have f(t) is N ID. On the other hand letting θ ↓ 0 we have f(t) is SD since lim<sup>θ</sup>↓0fθ(t) = 1, see e.g Gnedenko and Korolev [\[3](#page-6-2)], page 149.

Example 2.1 For the LT ϕ(s) = (1 + s) −α , α > 0, ϕ(ϕ −1 (s)/p) is a PGF of a non-degenerate distribution only if α = k , k ≥ 1 integer, see Example 1 in Bunge [\[1](#page-5-1)] or Corollary 4.5 in Satheesh et al. [\[6\]](#page-6-3). This PGF is that of Harris distribution (Satheesh et al. [\[7\]](#page-6-4)) and the corresponding N RSD distribution is HRSD. When k = 1 above, we have GRSD (RSD distributions of Kozubowski and Podg´orski [\[4\]](#page-6-0)).

Example 2.2 Invoking Theorem 1.1 when ϕ(s) is SD and log h(t) = −λ|t| α we have, for each c ∈ (a, 1]

$$f(t) = \varphi(|t|^{\alpha}) = \varphi(c|t|^{\alpha}).\varphi_c(|t|^{\alpha}). \tag{7}$$

That is f(t) is both SD and N -strictly stable. Thus we have a good collection of CFs that are both SD and HID and thus HRSD. Kozubowski and Podg´orski [\[4](#page-6-0)]) present examples of a variety of CFs h(t) that are stable.

## 3. Discrete analogue of NRSD distributions

Steutel and van Harn [\[10\]](#page-6-5) had described discrete SD (DSD) distributions. Satheesh and Sandhya [\[9\]](#page-6-1) have described DHRSD, discrete analogue of HRSD distributions. We now introduce discrete N RSD (DN RSD) distributions.

Definition 3.1. (Satheesh et al. [\[7\]](#page-6-4)) Let ϕ be a standard solution to the Poincare equation and N<sup>θ</sup> a positive integer-valued r.v. having finite mean with PGF Pθ(s) = ϕ( 1 θ ϕ −1 (s)), θ ∈ Θ ⊆ (0, 1). A PGF P(s) is DN ID if for each θ ∈ Θ there exists a PGF Qθ(s) that is independent of N<sup>θ</sup> such that P(s) = Pθ(Qθ(s)), for all |s| ≤ 1.

Theorem 3.1. (Satheesh et al. [\[7](#page-6-4)]) Let ϕ be a standard solution to the Poincare equation. A PGF P(s) is DN ID iff it admits the representation P(s) = ϕ(− log R(s)) where R(s) is a PGF that is DID.

Definition 3.2. A PGF P(s) is DN RSD if for each c ∈ (0, 1] and each θ ∈ [0, 1)

$$P_{c,\theta}(s) = P_c(s).Q_{\theta}(1 - c + cs) \tag{8}$$

is a PGF, where Pc(s) and Qθ(s) are given by

$$P_c(s) = \frac{P(s)}{P(1 - c + cs)} \tag{9}$$

$$Q_{\theta}(s) = \varphi\{\theta\varphi^{-1}(P(s))\},\tag{10}$$

ϕ being a standard solution to the Poincare equation.

We may now proceed as in Section 2 describing the relation between DSD, DN ID and DN RSD distributions. Further, remarks similar to Remarks 2.1 and 2.2 are relevant here also and Examples on the lines of Example 2.1 nad 2.2 can also be discussed.

#### 4. ϕRSD distributions

A further generalization of N RSD distributions is possible invoking the notion of ϕID law that generalizes N ID laws, see Satheesh [\[5\]](#page-6-6) and Satheesh et al. [\[7](#page-6-4)], [\[8\]](#page-6-7)) for its discrete analogue. We first describe the discrete case.

Definition 4.1. (Satheesh et al. [\[7](#page-6-4)]) Let ϕ be a LT. A PGF P(s) is DϕID if there exists a sequence {θn} ↓ 0 as n → ∞ and a sequence of P GFs Qn(s) such that

$$P(s) = \lim_{n \to \infty} \varphi(\frac{1 - Q_n(s)}{\theta_n}). \tag{11}$$

Theorem 4.1. (Satheesh et al. [\[8\]](#page-6-7)) Let {Qθ(s), θ ∈ Θ} be a family of PGFs and ϕ a LT. Then

$$\lim_{\theta \downarrow 0} \varphi(\frac{1 - Q_{\theta}(s)}{\theta}) \tag{12}$$

exists and is DϕID iff there exists a PGF R(s) that is DID such that

$$\lim_{\theta \downarrow 0} \frac{1 - Q_{\theta}(s)}{\theta} = -\log R(s) \tag{13}$$

Definition 4.2. A PGF P(s) is DϕRSD if for each c ∈ (a, 1) and each θ ∈ (0, b), 0 < a, b < 1

$$P_{c,\theta}(s) = P_c(s).Q_{\theta}(1 - c + cs)$$
 (14)

is a PGF, where Pc(s) and Qθ(s) are given by

$$P_c(s) = \frac{P(s)}{P(1 - c + cs)} \tag{15}$$

$$Q_{\theta}(s) = 1 - \theta \varphi^{-1}(P(s)). \tag{16}$$

The restriction of α = 1 k , k ≥ 1 integer in Example 2.1 is not in this notion. We may now proceed as in Section 3 describing the relation between DSD, DϕID and DϕRSD distributions. This has been possible since lim<sup>θ</sup>↓0Qθ(t) = 1. The case of ϕRSD follows on similar lines.

### References

- <span id="page-5-1"></span>[1] Bunge, J (1996), Composition semi-groups and random stability, Ann. Probab., 24, 1476–1489.
- <span id="page-5-0"></span>[2] Fosum, E B (1995), A characterization of discrete self-decomposable distributions in terms of survival distributions and the self-decomposability of discrete logarithmic distribution, Sankhya, 57, 317–341.

- <span id="page-6-2"></span>[3] Gnedenko, B V and Korolev, V Yu. (1996), Random Summation, limit Theorems and Applications, CRC Press, Boca Raton.
- <span id="page-6-0"></span>[4] Kozubowski, T J and Podg´orski, K (2010), Random selfdecomposability and autoregressive processes, Statis. Probab. Lett., doi:10.1016/j.spl.2010.06.014.
- <span id="page-6-6"></span>[5] Satheesh, S (2004), Another look at random infinite divisibility, Statist. Meth., 6, 123–144.
- <span id="page-6-3"></span>[6] Satheesh, S; Nair, N U and Sandhya, E (2002), stability of random sums, Stoch. Model. Appl., 5, 17–26.
- <span id="page-6-4"></span>[7] Satheesh, S; Sandhya, E and Lovely, A T (2010a), Limit distributions of random sums of Z+-valued random variables, Commu. Statist.-Theor. Meth., 39, 1979–1984.
- <span id="page-6-7"></span>[8] Satheesh, S; Sandhya, E and Lovely, A T (2010b), Random infinite divisibility on Z<sup>+</sup> and generalized INAR models, ProbStat Forum, 3, 108–117.
- <span id="page-6-1"></span>[9] Satheesh, S and Sandhya, E (2010), A generalization of random selfdecomposability, submitted, [http://arxiv.org/abs/1009.5141v1.](http://arxiv.org/abs/1009.5141v1)
- <span id="page-6-5"></span>[10] Steutel, F W and van Harn, K (1979), Discrete analogues of selfdecomposability and stability, Ann. Probab., 7, 893–899.