# Graph Matrices: Norm Bounds and Applications

Kwangjun Ahn<sup>1</sup> , Dhruv Medarametla<sup>2</sup> , and Aaron Potechin<sup>3</sup>

<sup>1</sup>Massachusetts Institute of Technology, Cambridge, MA, kjahn@mit.edu <sup>2</sup>Troy, MI, dhruvm321@gmail.com <sup>3</sup>The University of Chicago, Chicago, IL, potechin@uchicago.edu

April 30, 2021

## Abstract

In this paper, we derive nearly tight probabilistic norm bounds for a class of random matrices we call graph matrices. While the classical case of symmetric matrices with independent random entries (Wigner's matrices) is a special case, in general, the entries of our matrices will be dependent in a way that can be specified in terms of a fixed-size graph we refer to as the shape. For Wigner's matrices, this shape is K2, the clique on 2 vertices. To prove our norm bounds, we use the trace power method.

In a recent series of papers by Potechin and coauthors, graph matrices played a crucial role in proving average-case lower bounds for the Sum-of-Squares (SoS) hierarchy of proof systems, one of the most powerful, but difficult to analyze, techniques in combinatorial optimization. In particular, graph matrices played a crucial role in proving that low-degree SoS cannot refute the existence of a large clique in a random graph and proving that low-degree SoS cannot prove a tight lower bound on the ground state energy of the Sherrington-Kirkpatrick Hamiltonian. In this paper, we give several additional applications of graph matrices. We show that for several technical lemmas in the literature, while the original analyses were quite involved, we can give direct proofs using graph matrices and our norm bounds.

# 1 Introduction

## 1.1 Background on random matrix theory

The theory of random matrices is an important area of mathematics with applications in physics, computer science, and many other areas. For random matrices with independent entries, many results are known. Some highlights are as follows:

- 1. For symmetric random n×n matrices whose entries in the upper right triangle are independent random variables with mean 0 and variance 1:
  - (a) Wigner's Semicircle Law [\[Wig58\]](#page-81-0) describes the limit of the mean density of the spectra of these matrices as n → ∞.
  - (b) The distribution of the maximum eigenvalue of these matrices is described by the Tracy-Widom distribution [\[TW94\]](#page-81-1).

- (c) For the special case of the Gaussian Orthogonal Ensemble where the entries are independent Gaussians, Mehta and Gaudin [\[MG60\]](#page-80-0) found the distribution for how far apart consecutive eigenvalues are from each other.
- 2. For random n × n matrices whose entries are independent random variables with mean 0 and variance 1 (where there is no symmetry requirement), Girko's Circular Law [\[Gir85\]](#page-79-0) describes the limit of the mean density of the spectra of these matrices as n → ∞.

However, for random matrices whose entries are dependent, much less is known.

## 1.2 Properties of graph matrices

In this paper, we analyze graph matrices, a class of random matrices which was first explicitly defined in the previous version of this paper [\[MP16\]](#page-80-1) and which has the following properties:

- 1. The entries of the matrix depend on a random input whose size is described by a parameter n and whose entries are labeled by indices in [n] [1](#page-1-0) . For example, this random input could be a random graph on n vertices.
- 2. The dependence of the entries of the matrix on the random input can be described by a small graph which we call a shape [2](#page-1-1) .
- 3. The rows and columns of the matrix are indexed by tuples of indices in [n] and the matrix (as a function of the input) is symmetric under permutations of [n]. As a result, if we permute the entries of the input by applying a permutation of [n], this applies a corresponding permutation to the rows and columns of the matrix.

Our main results are probabilistic norm bounds on all graph matrices. (See Definitions [2.16](#page-9-0) and Definition [7.23](#page-37-0) for the formal definitions of graph matrices and see Theorems [2.24,](#page-11-0) [6.1,](#page-26-0) and [8.4](#page-41-0) for the statements of the norm bounds). The norm bounds we prove are tight up to polylog(n) factors and they are general enough to permit several applications.

## 1.3 Applications of graph matrices

One important application of graph matrices is analyzing the Sum-of-Squares (SoS) hierarchy of proof systems. The Sum-of-Squares hierarchy, independently investigated by Shor, Nesterov, Parrillo, Lasserre, and Grigoriev [\[Sho87,](#page-81-2) [Nes00,](#page-80-2) [Par00,](#page-80-3) [Las01,](#page-80-4) [Gri01a,](#page-79-1) [Gri01b\]](#page-79-2), is a powerful tool for solving combinatorial optimization problems as well as various inference problems arising from physics and machine learning. SoS is an appealing technique because it has the following nice properties:

1. Broadly applicable: SoS can be applied to any system of polynomial equations over the real numbers, a problem class which subsumes most combinatorial problems as a special case.

<span id="page-1-0"></span><sup>1</sup> In the most general case, the size of the input may be described by several parameters n1, . . . , n<sup>t</sup> rather than a single parameter n. We discuss this in Section [7.](#page-32-0)

<span id="page-1-1"></span><sup>2</sup> In the most general case, a shape will be a hypergraph with labeled edges rather than a graph. We discuss this in Section [7.](#page-32-0)

- 2. Surprisingly powerful: SoS captures the Goemans-Williamson algorithm for max-cut [GW95], the Goemans-Linial relaxation for sparsest cut (which was shown to give an O(√log n) approximation by Arora, Rao, and Vazirani [ARV09]), and the subexponential-time algorithm for unique games [ABS15, BRS11, GS11]. SoS has also been used to give algorithms for various inference problems arising from physics and machine learning. Examples include planted sparse vector [BKS14], dictionary learning [BKS15], tensor decomposition [GM15, HSSS16], tensor completion [BM16, PS17], quantum separability [BKS17], and robust estimation/mixtures of Gaussians [HL18, KSS18, BK20, DHKK20].
- 3. In some sense, simple: All that SoS uses is polynomial equalities and the fact that squares are non-negative over the real numbers.

For more information about the sum of squares hierarchy, see the survey of Barak and Steurer [BS14].

Unfortunately, SoS is often difficult to analyze. One reason for this is that the moment matrix, a matrix which appears in the analysis of SoS, is generally very complicated. For average-case problems, the moment matrices often admit a decomposition into graph matrices, which can be useful for the analysis. Indeed, graph matrices played a crucial role in the SoS lower bounds for planted clique (i.e. proving that low-degree SoS cannot refute the existence of a large clique in a random graph) [MPW15, HKP15, DM15, RS15, BHK<sup>+</sup>19]. Recently, graph matrices were used to prove SoS lower bounds for the Sherrington-Kirkpatrick problem (i.e. proving that low-degree SoS cannot prove a tight lower bound on the ground state energy of the Sherrington-Kirkpatrick Hamiltoniam) [GJJ<sup>+</sup>20].

As we demonstrate in Section 9, graph matrices can also capture the proofs of several other technical statements, including the following:

- 1. Graph matrices can be used to capture the proof of Theorem 7 of [BBH<sup>+</sup>12], which says that if A is an  $m \times n$  matrix with each entry drawn independently from  $\mathcal{N}(0,1)$  then with high probability,  $||A||_{2\to 4} \leq 3m + \widetilde{O}\left(\max\left\{n\sqrt{m},\ n^2\right\}\right)$  where  $||A||_{2\to 4} = \max_{||x||_2=1} ||Ax||_4$  is the  $2\to 4$  norm<sup>3</sup> of A (see Section 9.2 for details). This result is the key idea behind the SoS algorithm for planted sparse vector [BKS14].
  - Moreover, graph matrices can be used to capture the proof of the key lemma for analyzing a faster spectral algorithm for planted sparse vector [HSSS16]; see Section 9.4 for details.
- 2. Graph matrices can be used to capture the proofs of key lemmas for analyzing the tensor decomposition algorithm of [GM15] as well as the faster version in [HSSS16]. See Sections 9.3 and 9.5 for details.

For these applications, our proofs based on graph matrices are *mechanical*, whereas the original proofs for those technical statements are involved and often require clever arguments.

#### 1.4 Updates from the previous version of this paper

This paper is a major update of the paper "Bounds on the Norms of Uniform Low Degree Graph Matrices" which appeared in RANDOM 2016 [MP16]. The graph matrices that our previous paper

<span id="page-2-0"></span><sup>&</sup>lt;sup>3</sup>For background on the  $2 \to 4$  norm and the more general  $p \to q$  norm  $||A||_{p \to q} = \max_{||x||_p = 1} ||Ax||_q$ , see the paper [BBH<sup>+</sup>12]. While we limit our discussion to the  $2 \to 4$  norm as it is the most important such norm, we expect that graph matrices can also be used to analyze the  $p \to q$  norm for other p and q.

focused on are those described in Section 2; these matrices were motivated by the analyses of SoS on the planted clique problem. The work done in our previous paper is covered within the first 6 sections of this paper as well as Appendix A.

In this updated paper, we generalize the definition of graph matrices to allow different types of vertices, different input distributions, and hyperedges. We describe these generalizations in Section 7 and prove norm bounds on these generalized graph matrices in Section 8. As discussed above, these generalized norm bounds allow us to capture the proofs of several technical statements in the literature; these proofs are contained in Section 9.

#### 1.5 Notation

Given a matrix M, we write M(i,j) to denote the (i,j)-th element of M; we take ||M|| to be the spectral norm of M, i.e.  $||M|| = \max_{\|v\|_2=1} ||Mv\|_2$ . For a graph G, we denote its vertex set by V(G) and denote its edge set by E(G).

We define  $\widetilde{O}(f(n))$  to mean  $O(f(n)(\log n)^c)$  for some  $c \geq 0$ .

## <span id="page-3-0"></span>2 Graph matrices and their norm bounds

In this section, we will define graph matrices for the setting where the input is an undirected Erdős-Rényi random graph. Before getting into the formal definitions, we begin with some motivating examples.

## <span id="page-3-2"></span>2.1 First motivating example: clique indicator

Given an undirected graph G on the vertex set  $[n] := \{1, 2, ..., n\}$ , we say  $H \subset G$  is a clique if every two vertices in H are adjacent to each other. Suppose that we are interested in studying the  $n(n-1) \times n(n-1)$  clique indicator matrix CLIQUE defined as follows:

$$\mathsf{CLIQUE}\big((i_1, i_2), (j_1, j_2)\big) := \begin{cases} 1, & \text{if } i_1, i_2, j_1, j_2 \text{ are distinct and form a clique in } G, \\ 0, & \text{otherwise.} \end{cases}$$
 (2.1)

Note that here we require that  $i_1 \neq i_2$  and  $j_1 \neq j_2$  but  $(i_1, i_2)$  and  $(j_1, j_2)$  can intersect.

More specifically, we consider the case where G is a random graph generated as per the Erdős-Rényi model: for each pair of vertices, there is an edge between them with probability 1/2 and all of these events are independent. In this case, the clique indicator CLIQUE is a random matrix but its entries are not independent of each other.

One natural way to study the clique indicator is via discrete Fourier analysis. We encode the edges of G as the  $\pm 1$  variables  $\{\chi_{\{l_1,l_2\}}\}$  where  $\chi_{\{l_1,l_2\}} := +1$  if  $\{l_1,l_2\} \in E(G)$ , and -1 otherwise. We can now decompose each entry of CLIQUE as a sum of products of the variables as follows:

**Fact.** The following identity holds for any four distinct indices  $i_1, i_2, j_1, j_2 \in [n]$ :

<span id="page-3-1"></span>
$$\mathsf{CLIQUE}\big((i_1, i_2), (j_1, j_2)\big) = \frac{1}{2^6} \cdot \sum_{R: \ graph \ on \ \{i_1, i_2, j_1, j_2\} \ \{l_1, l_2\} \in E(R)} \prod_{\chi_{\{l_1, l_2\}}} \chi_{\{l_1, l_2\}}. \tag{2.2}$$

*Proof.* If the four vertices  $i_1, i_2, j_1, j_2$  form a clique, each summand  $\prod_{\{l_1, l_2\} \in E(R)} \chi_{\{l_1, l_2\}}$  is equal to 1, which implies that the right hand side of (2.2) is 1. Otherwise, some edge e between  $i_1, i_2, j_1, j_2$ 

is missing. In this case, there are perfect cancellations between the graphs R where e ∈ E(R) and the graphs R where e /∈ E(R) so the right hand side is equal to 0.

Now let us inspect the terms in the decomposition [\(2.2\)](#page-3-1). For concreteness, consider the case i<sup>1</sup> = 1, i<sup>2</sup> = 2, j<sup>1</sup> = 3, j<sup>2</sup> = 4:

$$\mathsf{CLIQUE}\big((1,2),(3,4)\big) = \frac{1}{2^6} \cdot \sum_{R: \text{ graph on } \{1,2,3,4\}} \prod_{\{l_1,l_2\} \in E(R)} \chi_{\{l_1,l_2\}}. \tag{2.3}$$

Notably, each term in the decomposition corresponds to a graph R on four vertices 1, 2, 3, 4. Let us call each such graph R a ribbon (see Definition [2.9](#page-8-0) for precise details). To represent the fact that R corresponds to row (1, 2) and column (3, 4) of CLIQUE, we associate tuples A<sup>R</sup> = (1, 2) and B<sup>R</sup> = (3, 4) to R which we call the left and right vertices of R.

<span id="page-4-0"></span>For example, one term in [\(2.2\)](#page-3-1) is χ{1,3}χ{2,3}χ{2,4} . We represent this term with the ribbon R where A<sup>R</sup> = (1, 2), B<sup>R</sup> = (3, 4), and E(R) = {{1, 3}, {2, 3}, {2, 4}}. See Figure [1](#page-4-0) for an illustration.

![](_page_4_Figure_5.jpeg)

Figure 1: An illustration of the ribbon R where the vertex set V (R) is {1, 2, 3, 4}, A<sup>R</sup> = (1, 2), B<sup>R</sup> = (3, 4), and E(R) = {{1, 3}, {2, 3}, {2, 4}}

Now let us represent [\(2.2\)](#page-3-1) using ribbons. To that end, we define a Fourier character for each ribbon R:

<span id="page-4-1"></span>
$$\chi_R := \prod_{\{l_1, l_2\} \in E(R)} \chi_{\{l_1, l_2\}} \,.$$

Expressing the terms in [\(2.2\)](#page-3-1) using these ribbons and their Fourier characters, we have that

$$\mathsf{CLIQUE}((1,2),(3,4)) = \frac{1}{2^6} \cdot \sum_{\substack{\text{ribbon } R:V(R) = \{1,2,3,4\}\\A_R = (1,2), \ B_R = (3,4)}} \chi_R. \tag{2.4}$$

In fact, there is nothing special about the choice i<sup>1</sup> = 1, i<sup>2</sup> = 2, j<sup>1</sup> = 3, j<sup>2</sup> = 4, and [\(2.4\)](#page-4-1) is true for any choice of i1, i2, j1, j<sup>2</sup> as long as they are distinct. This motivates us to consider the shape α of a ribbon R: to obtain the shape α of a ribbon R, we keep the graph structure of R the same while replacing the vertices 1, 2, 3, 4 by (undetermined) variables u1, u2, v1, v2, respectively. Moreover, we replace A<sup>R</sup> and B<sup>R</sup> with U<sup>α</sup> := (u1, u2) and V<sup>α</sup> := (v1, v2), respectively. See Definition [2.12](#page-9-1) for precise details.

For example, if we consider the ribbon in Figure [1,](#page-4-0) its shape α has V (α) = {u1, u2, v1, v2}, U<sup>α</sup> = (u1, u2), V<sup>α</sup> = (v1, v2), and E(α) = {{u1, v1}, {u2, v1}, {u2, v2}}. See Figure [2](#page-5-0) for an illustration.

<span id="page-5-0"></span>![](_page_5_Picture_0.jpeg)

Figure 2: An illustration of the shape  $\alpha$  where the vertex set  $V(\alpha)$  is  $\{u_1, u_2, v_1, v_2\}$ ,  $U_{\alpha} = (u_1, v_1)$ ,  $V_{\alpha} = (v_1, v_2)$ , and  $E(\alpha) = \{\{u_1, v_1\}, \{u_2, v_1\}, \{u_2, v_2\}\}$ .

Based on shapes, we can write a matrix analogue of the decomposition (2.4). Given a shape  $\alpha$ , we group all of the ribbons with a given shape  $\alpha$  together and then construct a corresponding matrix  $M_{\alpha}$ :

$$M_{\alpha}((i_1, i_2), (j_1, j_2)) := \begin{cases} \chi_{R_{i_1, i_2, j_1, j_2}} & \text{if } i_1, i_2, j_1, j_2 \text{ are distinct,} \\ 0, & \text{otherwise,} \end{cases}$$

where  $R_{i_1,i_2,j_1,j_2}$  is the ribbon with shape  $\alpha$  such that  $A_R = (i_1, i_2)$  and  $B_R = (j_1, j_2)$ . We call this matrix  $M_{\alpha}$  a graph matrix (see Definition 2.16 for precise details). Using these graph matrices, we have the following matrix analogue of (2.4):

CLIQUE = 
$$\frac{1}{2^{6}} \cdot \sum_{\substack{\text{shape } \alpha: V(\alpha) = \{u_{1}, u_{2}, v_{1}, v_{2}\}, \\ U_{\alpha} = (u_{1}, u_{2}), \ V_{\alpha} = (v_{1}, v_{2})}} M_{\alpha}.$$
(2.5)

As we discuss in Example 2.29, this decomposition of CLIQUE into graph matrices allows us to analyze it by separating out the parts of CLIQUE which have large norm from the parts of CLIQUE which have small norm. Now let us take a look at another example.

**Remark 2.1.** For the particular Z-shaped  $\alpha$  shown in Figure 2, the corresponding graph matrix  $M_{\alpha}$  has been analyzed more precisely. In particular, Cai and Potechin [CP20] determined the limit of the mean density of the spectrum of the singular values of this matrix.

#### <span id="page-5-2"></span>2.2 Second motivating example: counting triangles

Under the same random graph model, suppose that now we are interested in counting the number of triangles that include two chosen vertices. More specifically, for any two distinct vertices  $i, j \in [n]$ , define  $\Delta_{i,j}$  be the number of triangles containing i, j, and consider the  $n \times n$  matrix TRIANGLE defined as follows:

<span id="page-5-1"></span>TRIANGLE
$$(i_1, j_1) := \begin{cases} \triangle_{i_1, j_1}, & \text{if } i_1, j_1 \text{ are distinct,} \\ 0, & \text{otherwise.} \end{cases}$$
 (2.6)

Again, we can study TRIANGLE via discrete Fourier analysis. Similar to (2.2), we have the following decomposition:

TRIANGLE
$$(i_1, j_1) = \frac{1}{2^3} \cdot \sum_{k_1 \in [n] \setminus \{i_1, j_1\} \ R: \text{ graph on } \{i_1, j_1, k_1\} \ \{l_1, l_2\} \in E(R)} \prod_{k_1 \in [n] \setminus \{i_1, j_1\} \ R: \text{ graph on } \{i_1, j_1, k_1\} \ \{l_1, l_2\} \in E(R)} \chi_{\{l_1, l_2\}}.$$
 (2.7)

After some inspection of (2.7), one will realize that the terms in the decomposition cannot be characterized using the ribbons and shapes we described in Section 2.1. This is because there is a vertex  $k_1$  in a graph R that does not come from the row/column indices  $i_1, j_1$ . To capture this, we introduce middle vertices in ribbons and shapes.

To illustrate, let us consider the case  $i_1 = 1$ ,  $j_1 = 2$  and  $k_1 = 3$ . In this case, for each ribbon in (2.7), we can set  $A_R = (1)$  and  $B_R = (2)$  but there is still a vertex 3 which is outside of  $A_R$  and  $B_R$ . We will call this vertex a middle vertex and denote the set of middle vertices by  $C_R$  (note that in general there could be more than one middle vertex). Here we have  $C_R = \{3\}$ . See Definition 2.9 for precise details.

<span id="page-6-0"></span>For example, one term in (2.7) is  $\chi_{\{1,3\}}\chi_{\{2,3\}}$ . We represent this term with the ribbon R where  $A_R = (1)$ ,  $B_R = (2)$ ,  $C_R = \{3\}$  and  $E(R) = \{\{1,3\},\{2,3\}\}$ . See Figure 3 for an illustration.

![](_page_6_Picture_3.jpeg)

Figure 3: An illustration of the ribbon R where the vertex set V(R) is  $\{1, 2, 3\}$ ,  $A_R = (1)$ ,  $B_R = (2)$ ,  $C_R = \{3\}$ , and  $E(R) = \{\{1, 3\}, \{2, 3\}\}$ .

Following Section 2.1, we can now similarly abstract away the identity of the indices  $i_1 = 1$ ,  $j_1 = 2$ , and  $k_1 = 3$  and consider the shape of a ribbon. To obtain the shape  $\alpha$  of a ribbon R, we keep the graph structure of R the same while replacing the vertices 1, 2, 3 by (undetermined) variables  $u_1, v_1, w_1$ , respectively. Moreover, we replace  $A_R$ ,  $B_R$ , and  $C_R$  with  $U_\alpha := (u_1)$ ,  $V_\alpha := (v_1)$ , and  $W_\alpha := \{w_1\}$  respectively. See Definition 2.12 for precise details.

<span id="page-6-1"></span>For example, if we consider the ribbon in Figure 3, its shape  $\alpha$  has  $V(\alpha) = \{u_1, v_1, w_1\}$ ,  $U_{\alpha} = \{u_1\}$ ,  $V_{\alpha} = \{v_1\}$ , and  $E(\alpha) = \{\{u_1, w_1\}, \{v_1, w_1\}\}$ . See Figure 4 for an illustration.

![](_page_6_Figure_7.jpeg)

Figure 4: An illustration of a shape  $\alpha$  where the vertex set  $V(\alpha)$  is  $\{u_1, v_1, w_1\}$ ,  $U_{\alpha} = (u_1)$ ,  $V_{\alpha} = (v_1)$ ,  $W_{\alpha} = \{w_1\}$  and  $E(\alpha) = \{\{u_1, w_1\}, \{v_1, w_1\}\}$ .

As in Section 2.1, we can write a matrix analogue of the decomposition (2.7) using shapes. However, since there is a middle vertex, there are many different ribbons which have a given shape  $\alpha$ , row index  $i_1$ , and column index  $j_1$ . To handle this, we need to take the sum of the Fourier characters for these ribbons (see Definition 2.16 for precise details). This gives us the following expression:

$$M_{\alpha}(i_1, j_1) := \begin{cases} \sum_{k_1 \in [n] \setminus \{i_1, j_1\}} \chi_{R_{i_1, j_1, k_1}}, & \text{if } i_1, j_1 \text{ are distinct,} \\ 0, & \text{otherwise.} \end{cases}$$

where  $R_{i_1,j_1,k_1}$  is the ribbon with shape  $\alpha$  such that  $A_R = (i_1)$ ,  $B_R = (j_1)$ , and  $C_R = \{k_1\}$ . Using

these graph matrices, we can decompose TRIANGLE as follows:

TRIANGLE = 
$$\frac{1}{2^3} \cdot \sum_{\substack{\text{shape } \alpha: V(\alpha) = \{u_1, v_1, w_1\}, \\ U_{\alpha} = (u_1), \ V_{\alpha} = (v_1), \ W_{\alpha} = \{w_1\}}} M_{\alpha}.$$
 (2.8)

As this example shows, by introducing middle vertices into graph matrices, we can increase their expressive power. We now give formal definitions of the concepts presented above.

## <span id="page-7-3"></span>2.3 Definition of graph matrices

We consider graph matrices to be matrices whose rows and columns are indexed by monomials. We begin by considering the ground set where the indices of the variables are taken from.

<span id="page-7-0"></span>**Definition 2.2** (Ground set). We set the ground set for the variable indices to be  $[n] := \{1, 2, \dots, n\}$ . In other words, we consider monomials consisting of the variables  $\{x_i\}_{i \in [n]}$ .

For the simplified setting in this section, we focus on the case where the constraint  $x_i^2 = 1$  is present for each i so we have that  $x_i = \pm 1$ . In this case, all monomials can be reduced to multilinear monomials. Since we can represent each multilinear monomial  $\prod_{a \in A} x_a$  by the set of indices A, we make the following definition about matrix indices.

<span id="page-7-1"></span>**Definition 2.3** (Matrix indices). We define a matrix index A to be a tuple of distinct indices  $A = (a_1, \ldots, a_m)$  for some  $m \in \mathbb{N}$ , where  $a_1, \ldots, a_m \in [n]$ . We denote by |A| the size of the index tuple, i.e., |A| = m. Moreover, we let  $V(A) := \{a_1, a_2, \ldots, a_m\}$ .

**Remark 2.4.** Note that there are  $n*(n-1)*...*(n-m+1) = \frac{n!}{(n-m)!}$  different matrix indices A of size m. Thus, if a graph matrix has rows indexed by monomials of degree m and columns indexed by monomials of degree m' then it will be an  $\frac{n!}{(n-m)!} \times \frac{n!}{(n-m')!}$  matrix.

<span id="page-7-2"></span>Remark 2.5. A careful reader might wonder why we chose tuples instead of subsets to represent monomials. For instance, matrix indices (1,2,3) and (1,3,2) both represent the monomial  $x_1x_2x_3$ , and hence, it may seem redundant to consider tuples over subsets. However, it turns out that adopting tuples in lieu of subsets results in a more canonical definition of graph matrices. In particular, if we used sets for the matrix indices rather than tuples then some graph matrices would not be symmetric under permutations of [n] but using tuples ensures that all graph matrices are symmetric under permutations of [n].

Given matrix indices, we now discuss how each entry is defined. We first formally define the input random graph:

**Definition 2.6** (Erdős-Rényi input distribution). We define the Erdős-Rényi input distribution to be the random graph G having [n] as its vertices such that for each pair of distinct vertices  $i, j \in [n]$ , the edge  $e = \{i, j\}$  is present with probability 1/2 and all of these events are independent. We denote the Erdős-Rényi-input distribution by G(n, 1/2).

Having defined the input distribution, we now formalize how the entries of graph matrices depend on this distribution. To that end, we first define Fourier characters over input graphs through the following two definitions:

**Definition 2.7.** For a given graph G on [n] and a pair of distinct indices  $e = \{i, j\} \subset [n]$ , we define  $\chi_e(G)$  to be 1 if  $e \in E(G)$  and -1 if  $e \notin E(G)$ .

**Definition 2.8** (Fourier characters). For a given graph G on [n] and a set  $E = \{e_1, e_2, \ldots, e_l\}$  consisting of pairs of distinct indices in [n], we define the Fourier character  $\chi_E(G) = \prod_{i=1}^l \chi_{e_i}(G) = (-1)^{|E \setminus E(G)|}$ .

With the Fourier characters we have defined over the input  $G \sim G(n, 1/2)$ , the (A, B)-th entry of a graph matrix is defined as a Fourier character on an edge set that depends on A and B. To be more specific about how the edge set depends on A and B, we now formally define ribbons:

<span id="page-8-0"></span>**Definition 2.9** (Ribbons). A ribbon  $R = (A_R, B_R, C_R, E(R))$  consists of two matrix indices  $A_R$  and  $B_R$  (possibly  $V(A_R) \cap V(B_R) \neq \emptyset$ ), an additional set of indices  $C_R$  such that  $C_R \cap (V(A_R) \cup V(B_R)) = \emptyset$ , and a set E(R) of pairs of distinct indices from  $V(A_R) \cup V(B_R) \cup C_R$ . We make the following definitions about ribbons:

- 1. (Graphical representation of a ribbon) We identify R with its graphical representation defined as a graph with vertices  $V(R) = V(A_R) \cup V(B_R) \cup C_R$  and edges E(R). Here we regard  $V(A_R)$  and  $V(B_R)$  as distinguished sets, and refer to them as the left and right vertices of R, respectively. We refer to  $C_R$  as the middle vertices of R.
- 2. (Fourier character of a ribbon) We define the Fourier character  $\chi_R$  to be  $\chi_{E(R)}$ .
- 3. (Matrix associated to a ribbon) Given a ribbon R and an input graph  $G \sim G(n, 1/2)$ , we define  $M_R$  to be a  $\frac{n!}{(n-|A_R|)!} \times \frac{n!}{(n-|B_R|)!}$  matrix such that  $M_R(A_R, B_R) = \chi_R(G)$  and  $M_R(A, B) = 0$  if  $A \neq A_R$  or  $B \neq B_R$ .

See Appendix C for examples of ribbons.

Although Definition 2.9 looks complicated at first sight, ribbons are indeed natural objects to consider when we consider the monomial-indexed matrices defined over the input distribution G(n, 1/2):

**Proposition 2.10** (Ribbons as orthonormal basis for matrix functions). Given  $a, b \in \mathbb{N}$ , the collection of matrices  $M_R$  such that  $|A_R| = a$ ,  $|B_R| = b$ , and  $C_R$  does not contain any isolated vertices forms an orthonormal basis for the space of matrix-valued functions such that:

- 1. Each function maps an input graph  $G \sim G(n, 1/2)$  to an  $\frac{n!}{(n-a)!} \times \frac{n!}{(n-b)!}$  matrix whose rows and columns are indexed by matrix indices A and B of size a and b, respectively.
- 2. We take the inner product  $\langle M, M' \rangle = \mathbb{E}_{G \sim G(n, \frac{1}{2})} \left[ \sum_{A,B} M(A,B) M'(A,B) \right]$ .

We are now ready to define graph matrices. Informally, given the sizes a and b of the row and column matrix index, respectively, a graph matrix of a certain "shape" is an  $\frac{n!}{(n-a)!} \times \frac{n!}{(n-b)!}$  matrix which is the sum of  $M_R$  over all ribbons R whose graphical representation has the designated "shape." To formalize this, we make the following definitions about shapes:

**Definition 2.11** (Index shapes). We define an index shape U to be a tuple of distinct variables  $U = (u_1, \ldots, u_m)$  for some  $m \in \mathbb{N}$ . We denote by |U| the size of the index shape, i.e., |U| = m. Moreover, let  $V(U) := \{u_1, u_2, \cdots, u_m\}$ .

<span id="page-9-1"></span>**Definition 2.12** (Shapes). A shape  $\alpha = (U_{\alpha}, V_{\alpha}, W_{\alpha}, E(\alpha))$  consists of index shapes  $U_{\alpha}$  and  $V_{\alpha}$  (possibly having common variables), an additional set  $W_{\alpha}$  of variables distinct from the ones in  $V(U_{\alpha}) \cup V(V_{\alpha})$ , and a set  $E(\alpha)$  consisting of pairs of distinct variables from  $V(U_{\alpha}) \cup V(V_{\alpha}) \cup W_{\alpha}$ . We use u, v, and w to denote variables in  $U_{\alpha}, V_{\alpha}$ , and  $W_{\alpha}$ , respectively.

Furthermore, we identify  $\alpha$  with its graphical representation defined as a graph with vertices  $V(\alpha) = V(U_{\alpha}) \cup V(V_{\alpha}) \cup W_{\alpha}$  and edges  $E(\alpha)$ . Here we regard  $V(U_{\alpha})$  and  $V(V_{\alpha})$  as distinguished sets and refer to them as the left and right vertices of  $\alpha$ , respectively. We refer to  $W_{\alpha}$  as the middle vertices of  $\alpha$ .

Lastly, we sometimes use the notation  $u \in \alpha$  in place of  $u \in V(\alpha)$  to avoid confusion between  $V_{\alpha}$  and  $V(\alpha)$ .

See Appendix C for examples of shapes.

With Definition 2.12, we can now be formal about what it means for a ribbon R to have a shape  $\alpha$ . To do that, we first define realizations of variables and shapes:

**Definition 2.13** (Realizations of variables). Given a set of variables U, we say a map  $\sigma: U \to [n]$  is a realization of U if  $\sigma$  an injective map. Moreover, for a realization  $\sigma$ , we make the following definitions:

- 1. For an index shape U, We define  $\sigma(U)$  to be the matrix index obtained by applying  $\sigma$  to each variable of U, i.e., if  $U = (u_1, \ldots, u_{|U|})$ , then  $\sigma(U) = (\sigma(u_1), \ldots, \sigma(u_{|U|}))$ .
- 2. Moreover, for a set of pairs of distinct variables E, we define  $\sigma(E)$  to be the set of pairs of distinct indices obtained from E by applying  $\sigma$  to each pair.

**Definition 2.14** (Realizations of shapes). Given a shape  $\alpha$  and a realization  $\sigma: V(\alpha) \to [n]$ , we define  $\sigma(\alpha)$  to be the ribbon  $\sigma(\alpha) = (\sigma(U_{\alpha}), \sigma(V_{\alpha}), \sigma(W_{\alpha}), \sigma(E(\alpha)))$ .

See Appendix C for examples of realizations of shapes. With these definitions, we can formally define shapes of ribbons:

**Definition 2.15** (Shapes of ribbons). Given a shape  $\alpha$  and a ribbon R, we say R has shape  $\alpha$  if there exists a realization  $\sigma$  such that  $\sigma(\alpha) = R$ .

We are now ready to define graph matrices:

<span id="page-9-0"></span>**Definition 2.16** (Graph matrices). Given a shape  $\alpha$ , we define the graph matrix  $M_{\alpha}$  to be the  $\frac{n!}{(n-|U_{\alpha}|)!} \times \frac{n!}{(n-|V_{\alpha}|)!}$  matrix such that for matrix indices A and B with  $|A| = |U_{\alpha}|$  and  $|B| = |V_{\alpha}|$ ,

$$M_{\alpha}(A, B) = \sum_{\substack{\sigma \text{ is a realization of } \alpha, \\ \sigma(U_{\alpha}) = A, \ \sigma(V_{\alpha}) = B}} \chi_{\sigma(E(\alpha))}. \tag{2.9}$$

<span id="page-9-4"></span>**Remark 2.17.** It is sometimes more convenient to work with the following alternative definition of graph matrices:

<span id="page-9-3"></span><span id="page-9-2"></span>
$$M_{\alpha} = \sum_{R: R \text{ has shape } \alpha} M_R. \tag{2.10}$$

This alternative definition is convenient when we are decomposing a matrix M where we have the Fourier coefficient  $c_R$  for each ribbon R (which is generally the case when we are using the pseudo-calibration technique of [BHK<sup>+</sup>19] to analyze the Sum-of-Squares hierarchy). In this case, letting  $\alpha$  be the shape of R, the coefficient for  $M_{\alpha}$  is just  $c_R$ . This would not be the case for our definition.

Fortunately, the two definitions (2.9) and (2.10) only differ by a constant multiplicative factor. More precisely, let  $\operatorname{Aut}(\alpha)$  be the set of graph automorphisms on  $\alpha$  which keep  $U_{\alpha}$  and  $V_{\alpha}$  fixed. One can verify that (2.9) =  $|\operatorname{Aut}(\alpha)| \cdot (2.10)$ . Thus, the norm bounds which we prove in this paper also apply to this alternative definition and are in fact slightly stronger.

## <span id="page-10-5"></span>2.4 Examples of graph matrices

In this section, we provide several examples of graph matrices. Our first example is the  $\pm 1$  Wigner matrix:

<span id="page-10-1"></span>**Example 2.18** (±1 Wigner matrix). Consider  $V(V_{\alpha}) = \{u_1, v_1\}$ ,  $U_{\alpha} = (u_1)$ ,  $V_{\alpha} = (v_1)$ , and  $E(\alpha) = \{\{u_1, v_1\}\}$ . In other words, the graphical representation of  $\alpha$  is the graph with two vertices  $u_1, v_1$  connected by the edge  $\{u_1, v_1\}$ ; see Figure 5. In this case,  $M_{\alpha}$  is an  $n \times n$  symmetric random matrix such that each off-diagonal entry is ±1 with probability 1/2 and the diagonal entries are zeros.

<span id="page-10-0"></span>![](_page_10_Picture_5.jpeg)

Figure 5: The shape corresponding to the  $\pm 1$  Wigner matrix from Example 2.18.

Our second example is the matrix J - I, where J refers to the all 1's matrix. Note that this matrix is deterministic as  $E(\alpha)$  is empty.

<span id="page-10-3"></span><span id="page-10-2"></span>**Example 2.19** (Off-diagonal 1's matrix). Consider  $V(V_{\alpha}) = \{u_1, v_1\}$ ,  $U_{\alpha} = (u_1)$ ,  $V_{\alpha} = (v_1)$ , and  $E(\alpha) = \{\}$ . In other words, the graphical representation of  $\alpha$  is the empty graph with vertices  $u_1$  and  $v_1$ ; see Figure 6. In this case,  $M_{\alpha}$  is an  $n \times n$  symmetric matrix with 0's on the diagonals and 1's off the diagonals.

![](_page_10_Figure_9.jpeg)

Figure 6: The shape corresponding to J - I from Example 2.19.

Our next example is the identity matrix. For this example,  $U_{\alpha} \cap V_{\alpha}$  is nonempty.

<span id="page-10-4"></span>**Example 2.20** (Identity matrix). Consider  $V(V_{\alpha}) = \{\nu_1\}$ ,  $U_{\alpha} = (\nu_1)$ ,  $V_{\alpha} = (\nu_1)$ , and  $E(\alpha) = \{\}$ . Here the graphical representation of  $\alpha$  is a single vertex with both  $U_{\alpha}$  and  $V_{\alpha}$  containing this vertex; see Figure 7.  $M_{\alpha}$  is the  $n \times n$  identity matrix.

<span id="page-11-1"></span>![](_page_11_Picture_0.jpeg)

Figure 7: The shape corresponding to I from Example 2.20.

We end with an example where  $W_{\alpha}$  is nonempty.

<span id="page-11-3"></span>**Example 2.21** (Shifted degree matrix). Consider  $V(V_{\alpha}) = \{\nu_1, w_1\}$ ,  $U_{\alpha} = (\nu_1)$ ,  $V_{\alpha} = (\nu_1)$ ,  $W_{\alpha} = (w_1)$ , and  $E(\alpha) = \{\{\nu_1, w_1\}\}$ . Here the graphical representation of  $\alpha$  is the graph with two vertices  $\nu_1$  and  $w_1$  with both  $U_{\alpha}$  and  $V_{\alpha}$  containing only  $\nu_1$ ; see Figure 8.  $M_{\alpha}$  is the  $n \times n$  random matrix equal to  $deg(G) - \frac{n-1}{2}I$ , where  $G \sim G(n, 1/2)$  and deg(G) is the diagonal matrix containing the degree of each vertex of G.

<span id="page-11-2"></span>![](_page_11_Picture_4.jpeg)

Figure 8: The shape corresponding to the shifted degree matrix from Example 2.21.

For more complicated examples of graph matrices, see Appendix D.

#### 2.5 Norm bounds on graph matrices

We are now ready to state our main theorem, which gives a norm bound on every graph matrix  $M_{\alpha}$  in terms of some combinatorial quantities related to the graphical representation of  $\alpha$ . In particular, it turns out that the minimum size of a vertex separator between  $U_{\alpha}$  and  $V_{\alpha}$  is the relevant quantity for the bound, where the vertex separator is defined as follows:

**Definition 2.22** (Vertex separators). If G is a graph and  $U, V \subseteq V(G)$ , we say S is a vertex separator between U and V if all paths from U to V intersect S.

**Remark 2.23.** We allow paths of length 0, so any separator S between U and V must contain  $U \cap V$ .

Here we give an informal statement of our main theorem. We defer the formal statement to Theorem 6.1.

<span id="page-11-0"></span>**Theorem 2.24** (Informal). Let  $\alpha = (U_{\alpha}, V_{\alpha}, W_{\alpha}, E(\alpha))$  be a shape without isolated middle vertices, and let  $s_{\min}$  be the minimum size of a vertex separator between  $U_{\alpha}$  and  $V_{\alpha}$ . Then with high probability  $||M_{\alpha}|| \leq \widetilde{O}(n^{\frac{1}{2}(|V(\alpha)|-s_{\min})})$ .

Moreover, if  $\alpha$  has u isolated middle vertices, then  $||M_{\alpha}|| \leq \widetilde{O}(n^{\frac{1}{2}(|V(\alpha)|+u-s_{\min})})$ .

We illustrate these norm bounds by revisiting examples we considered in Sections 2.1, 2.2, and 2.4. We refer readers to Appendix D for more examples.

**Example 2.25** (Revisiting Example 2.18:  $\pm 1$  Wigner matrix). For the shape  $\alpha$  from Example 2.18, we have  $s_{\min} = 1$ . By Theorem 2.24, with high probability  $||M_{\alpha}|| \leq \widetilde{O}(n^{\frac{1}{2}})$ . Note that this is consistent with the well-known tight upper bound of  $2(1 + o(1))\sqrt{n}$  [BY88, Sos99] up to a polylogarithmic term.

**Example 2.26** (Revisiting Example 2.19: off-diagonal 1's matrix). For the shape  $\alpha$  from Example 2.19, we have  $s_{\min} = 0$ . By Theorem 2.24, with high probability  $||M_{\alpha}|| \leq \widetilde{O}(n)$ . Calculating the norm of J - I tells us that  $||M_{\alpha}|| = n - 1$ , again showing consistency up to a poly-logarithmic term.

**Example 2.27** (Revisiting Example 2.20: identity matrix). For the shape  $\alpha$  from Example 2.20, we have  $s_{\min} = 1$ . By Theorem 2.24, with high probability  $||M_{\alpha}|| \leq \widetilde{O}(1)$ . We know that  $||M_{\alpha}|| = 1$ , so this result is also consistent.

**Example 2.28** (Revisiting Example 2.21: shifted degree matrix). For the shape  $\alpha$  from Example 2.20, we have  $s_{\min} = 1$ . By Theorem 2.24, with high probability  $||M_{\alpha}|| \leq \widetilde{O}(n^{\frac{1}{2}})$ . Using Chernoff bounds, with high probability the norm is on the order of  $\sqrt{n \log(n)}$  so this is consistent as well.

<span id="page-12-0"></span>**Example 2.29** (Revisiting clique indicator). Let's consider the clique indicator

CLIQUE = 
$$\frac{1}{2^6} \cdot \sum_{\substack{\alpha: shape \\ U_{\alpha} = (u_1, u_2), \ V_{\alpha} = (v_1, v_2)}} M_{\alpha}. \tag{2.11}$$

which we described in Section 2.1.

- 1. For shapes  $\alpha$  with no edges between  $U_{\alpha}$  and  $V_{\alpha}$ ,  $s_{min} = 0$  so  $||M_{\alpha}||$  is  $\widetilde{O}(n^2)$ .
- 2. For shapes  $\alpha$  such that the maximum matching between  $U_{\alpha}$  and  $V_{\alpha}$  has size 1,  $s_{min} = 1$  so  $||M_{\alpha}||$  is  $\widetilde{O}(n^{\frac{3}{2}})$ . These matrices have considerably larger norm than a random  $n(n-1) \times n(n-1)$  matrix and this was a major hurdle for proving tight degree 4 SoS lower bounds for planted clique [MPW15, HKP15, DM15, RS15].
- 3. For shapes  $\alpha$  such that there is a matching with 2 edges between  $U_{\alpha}$  and  $V_{\alpha}$ ,  $s_{min} = 2$  so  $||M_{\alpha}||$  is  $\widetilde{O}(n)$ . As far as their norms are concerned, these matrices behave like random matrices.

**Example 2.30** (Revisiting triangle counter). Let's consider the matrix

TRIANGLE = 
$$\frac{1}{2^3} \cdot \sum_{\substack{\alpha: shape \\ U_{\alpha} = (u_1), \ V_{\alpha} = (v_1), \ W_{\alpha} = \{w_1\}}} M_{\alpha}. \tag{2.12}$$

which we described in Section 2.2.

1. For the shape  $\alpha$  with no edges,  $s_{min} = 0$  and u = 1 so  $||M_{\alpha}||$  is  $\widetilde{O}(n^2)$ .

- 2. For shapes  $\alpha$  with one edge, either  $s_{min} = u = 1$  (if the edge is between u and v) or  $s_{min} = u = 0$  (if the edge is between w and u or v). In either case,  $u s_{min} = 0$  so  $||M_{\alpha}||$  is  $\widetilde{O}(n^{\frac{3}{2}})$ . These matrices correspond to the facts that vertices with higher degrees are contained in more triangles and a pair of vertices  $\{u, v\}$  can only be contained in triangles if  $(u, v) \in E(G)$ .
- 3. For shapes  $\alpha$  with 2 or 3 edges,  $s_{min} = 1$  and u = 0 so  $||M_{\alpha}||$  is  $\widetilde{O}(n)$ .

**Agenda for the proof of Theorem 2.24:** The proof requires some technical preparations, and the techniques will be detailed over the next few sections (Sections 3, 4, 5, and 6):

- 1. In Section 3, we describe the main technical tool we use for proving probabilistic norm bounds, namely the *trace power method*.
- 2. In Section 4, we consider  $\pm 1$  Wigner matrices (Example 2.18) and illustrate how we can obtain probabilistic norm bounds using the trace power method. While this analysis is not new and is less precise than the sharp analyses from the prior works [BY88, Sos99], it serves as a useful warm-up for analyzing more general graph matrices.
- 3. In Section 5, we discuss how to modify the techniques for  $\pm 1$  Wigner matrices to cover more general graph matrices. In particular, we describe a *vertex partitioning argument* which is crucial in simplifying the counting arguments for more general graph matrices.
- 4. In Section 6, we finally prove Theorem 2.24 based on the techniques developed up to that section.

Having outlined our agenda for the proof, we begin with the trace power method.

# <span id="page-13-0"></span>3 The trace power method and constraint graphs

This section describes our main technical tools for establishing probabilistic spectral norm bounds, the trace power method and constraint graphs.

#### 3.1 The trace power method

The most well-known technique for obtaining probabilistic spectral norm bounds on random matrices is called *the trace power method*, perhaps more well-known as *the moment method* (see e.g. [Tao12, Chapter 2.3.4]). We use the trace power method in the form of the following lemma:

<span id="page-13-1"></span>**Lemma 3.1** (The trace power method). Assume that M is a random matrix and that we have bounds  $\{B(2q): q \in \mathbb{N}\}$  such that for all  $q \in \mathbb{N}$ ,  $\mathbb{E}\left[\operatorname{Tr}\left((MM^{\top})^{q}\right)\right] \leq B(2q)$ . Then, for all  $\epsilon > 0$ ,

$$\mathbb{P}\left[\|M\| > \min_{q \in \mathbb{N}} \left\{ \sqrt[2q]{\frac{B(2q)}{\epsilon}} \right\} \right] < \epsilon.$$

*Proof.* To prove this, we first show that for all  $q \in \mathbb{N}$ ,  $||M||^{2q} \leq \text{Tr}((MM^{\top})^q)$ . Indeed, this is an easy consequence from linear algebra. First, observe that

$$\|M\| = \max_{u:\|u\|_2 = 1} \|Mu\|_2 = \max_{u:\|u\|_2 = 1} \sqrt{u^\top M^\top M u} = \sqrt{\lambda_{\max}(M^\top M)} = \sqrt{\lambda_{\max}(MM^\top)} \,.$$

Now let  $\lambda_1, \ldots, \lambda_n \geq 0$  be the eigenvalues of  $MM^{\top}$ . Then, for all  $q \in \mathbb{N}$ ,  $\text{Tr}\left((MM^{\top})^q\right) = \sum_{i=1}^n \lambda_i^q \geq \lambda_{\max}(MM^{\top})^q = \|M\|^{2q}$ , as needed.

Having established the above inequality, Lemma 3.1 is an immediate consequence of Markov's inequality: for all  $q \in \mathbb{N}$  and  $\epsilon > 0$ ,

$$\mathbb{P}\left[\|M\| > \sqrt[2q]{\frac{B(2q)}{\epsilon}}\right] = \mathbb{P}\left[\|M\|^{2q} > \frac{B(2q)}{\epsilon}\right]$$

$$\leq \mathbb{P}\left[\operatorname{Tr}\left((MM^{\top})^{q}\right) > \frac{\mathbb{E}\left[\operatorname{Tr}\left((MM^{\top})^{q}\right)\right]}{\epsilon}\right] < \epsilon.$$

The main message of the trace power method is as follows: to obtain upper bounds on  $||M_{\alpha}||$ , it is sufficient to bound  $\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha}M_{\alpha}^{\top})^{q}\right)\right]$  for an appropriate  $q \in \mathbb{N}$  (which may depend on n).

### 3.2 Constraint graphs

To compute  $\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha}M_{\alpha}^{\top})^{q}\right)\right]$ , we expand it out into a large sum. We will then encode the terms of this sum using a concept which we call *constraint graphs*. For this, we need a few more definitions.

<span id="page-14-0"></span>**Definition 3.2.** Given a shape  $\alpha$  and a  $q \in \mathbb{N}$ , we define  $H(\alpha, 2q)$  to be the multi-graph which is formed as follows:

- 1. Take q copies  $\alpha_1, \ldots, \alpha_q$  of  $\alpha$  and take q copies  $\alpha_1^{\top}, \ldots, \alpha_q^{\top}$  of  $\alpha^{\top}$ , where  $\alpha^{\top}$  is the shape obtained from  $\alpha$  by switching the role of  $U_{\alpha}$  and  $V_{\alpha}$ .
- 2. For all  $i \in [q]$ , we glue them together by setting  $V_{\alpha_i} = U_{\alpha_i^{\top}}$  and  $V_{\alpha_i^{\top}} = U_{\alpha_{i+1}}$  (where  $\alpha_{q+1} = \alpha_1$ ).
- 3. If there are overlapping edges after gluing, we keep them as multiple edges.

We define  $V(\alpha, 2q) = V(H(\alpha, 2q))$  and we define  $E(\alpha, 2q) = E(H(\alpha, 2q))$ .

We now provide a few examples of  $H(\alpha, 2q)$  for different  $\alpha$ . For each example, we will draw  $H(\alpha, 2q)$  according to the following rules:

- We will denote the vertices in  $U_{\alpha_i} \setminus V_{\alpha_i}$ ,  $V_{\alpha_i} \setminus U_{\alpha_i}$ , and  $W_{\alpha_i}$  by  $u_{j;i}$ ,  $v_{j;i}$ , and  $w_{j;i}$ , respectively. Moreover, we will denote the vertices in  $W_{\alpha_i^{\top}}$  by  $w'_{j;i}$ .
- We denote the vertices in  $U_{\alpha} \cap V_{\alpha}$  by  $\nu_{j;0}$ . The reason why the second subscript is 0 is because such vertices appear as a single copy in  $H(\alpha, 2q)$  as we shall see in Figure 10b.
- Consequently,  $\alpha_i^{\top}$  will consist of  $U_{\alpha_i^{\top}} = (v_{j;i}), V_{\alpha_i^{\top}} = (u_{j;i+1}), \text{ and } W_{\alpha_i^{\top}} = \{w'_{j:i}\}$  (where  $u_{j;q+1} = u_{j;1}$ ).
- As for the edges, we draw the edges of  $\alpha_i$  by red solid lines and the edges of  $\alpha_i^{\top}$  by blue dashed lines. We make an exception for the edges such that both endpoints are contained in  $U_{\alpha}$  or both endpoints are contained in  $V_{\alpha}$ . We will draw these edges by purple double lines. We use double lines as these edges are double edges in the constraint graph where the overlap happened due to the gluing step of Definition 3.2.

<span id="page-15-1"></span>Let us first consider the following two examples where  $W_{\alpha} = \emptyset$ .

![](_page_15_Picture_1.jpeg)

Figure 9b:  $H(\alpha, 2q)$  with q = 4.

<span id="page-15-0"></span>![](_page_15_Figure_3.jpeg)

Figure 10b:  $H(\alpha, 2q)$  with q = 4.

From Figures 9b and 10b, one can easily verify that each vertex in  $U_{\alpha} \cup V_{\alpha} \setminus (U_{\alpha} \cap V_{\alpha})$  is duplicated q times in  $H(\alpha, 2q)$ , and each vertex in  $U_{\alpha} \cap V_{\alpha}$  appears as a single copy. Now let us consider an example where  $W_{\alpha} \neq \emptyset$ .

<span id="page-16-0"></span>![](_page_16_Picture_0.jpeg)

Figure 11a:  $\alpha$ .

![](_page_16_Figure_2.jpeg)

Figure 11b:  $H(\alpha, 2q)$  with q = 2.

From Figure 11b, one can easily verify that each vertex in  $W_{\alpha}$  is duplicated 2q times in  $H(\alpha, 2q)$ . To conclude our observations thus far, we obtain:

<span id="page-16-2"></span>**Proposition 3.3.** For a shape  $\alpha = (U_{\alpha}, V_{\alpha}, W_{\alpha}, E(\alpha))$  and  $a \in \mathbb{N}$ ,

$$|V(\alpha, 2q)| = q \cdot (|U_{\alpha}| + |V_{\alpha}| - 2 \cdot |U_{\alpha} \cap V_{\alpha}|) + 2q \cdot |W_{\alpha}| + |U_{\alpha} \cap V_{\alpha}|.$$

Now we consider a map on  $V(\alpha, 2q)$  that assigns indices from [n] to the vertices of a constraint graph. In order for such map to be *valid*, such map should not assign the same index to two different vertices within the same copy of  $\alpha$  or  $\alpha^T$ . Motivated by this, we make the following definition:

**Definition 3.4** (Piecewise injectivity). We say that a map  $\phi: V(\alpha, 2q) \to [n]$  is piecewise injective if  $\phi$  is injective on each piece  $V(\alpha_i)$  and each piece  $V(\alpha_i^\top)$  for all  $i \in [q]$ . In other words,  $\phi(u) \neq \phi(v)$  whenever  $u, v \in V(\alpha_i)$  for some  $i \in [q]$  or  $u, v \in V(\alpha_i^\top)$  for some  $i \in [q]$ .

With this definition of piecewise injectivity, we can express the trace power term as follows:

<span id="page-16-1"></span>**Proposition 3.5.** For all shapes  $\alpha$  and all  $q \in \mathbb{N}$ ,

$$\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha}M_{\alpha}^{\top})^{q}\right)\right] = \sum_{\substack{\phi: V(\alpha, 2q) \to [n]:\\ \phi \text{ is piecewise injective}}} \mathbb{E}\left[\chi_{\phi(E(\alpha, 2q))}(G)\right].$$

We now observe that by symmetry,  $\mathbb{E}[\chi_{\phi(E(\alpha,2q))}(G)]$  only depends on the set of pairs of vertices  $\{(u,v): u,v\in V(\alpha,2q), \phi(u)=\phi(v)\}$  which are mapped to the same index. We capture this set of pairs with a concept which we call *constraint graphs*.

<span id="page-16-3"></span>**Definition 3.6** (Constraint graphs). Given a set of vertices V and a map  $\phi: V \to [n]$ , we construct the constraint graph  $C(\phi)$  on V associated to  $\phi$  as follows:

- 1. We take  $V(C(\phi)) = V$ .
- 2. For each pair of vertices  $u, v \in V$  such that  $\phi(u) = \phi(v)$ , we add a constraint edge between u and v.

3. As long as there is a cycle, we delete one edge of this cycle (this choice is arbitrary). We do this until there are no cycles left.

We say that two constraint graphs C, C' on V are equivalent (which we write as  $C \equiv C'$ ) if for all  $u, v \in V$ , there is a path of constraint edges between u and v in C if and only if there is a path of constraint edges between u and v in C'.

**Remark 3.7.** We delete all cycles from the constraint graph C so that there are no redundant constraints and  $|\phi(V)| = |V| - |E(C)|$ .

For our purpose, we specifically consider constraint graphs on  $H(\alpha, 2q)$  as follows:

**Definition 3.8** (Constraint graphs on  $H(\alpha, 2q)$ ). We define  $C_{(\alpha, 2q)} = \{C(\phi) : \phi : V(\alpha, 2q) \rightarrow [n] \}$  is piecewise injective to be the set of all possible constraint graphs on  $V(\alpha, 2q)$  (up to equivalence) which come from a piecewise independent map  $\phi : V(\alpha, 2q) \rightarrow [n]$ .

Moreover, given a constraint graph  $C \in \mathcal{C}_{(\alpha,2q)}$ , we make the following definitions:

- 1. We define  $N(C) = |\{\phi : V(\alpha, 2q) \to [n] : \phi \text{ is piecewise injective}, C(\phi) \equiv C\}|$ .
- 2. We define val $(C) = \mathbb{E}[\chi_{\phi(E(\alpha,2q))}(G)]$  where  $\phi : V(\alpha,2q) \to [n]$  is any piecewise injective map such that  $C(\phi) = C$ . Note that this is well-defined due to the observation below Proposition 3.5.

With these definitions, we can simplify  $\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha}M_{\alpha}^{\top})^{q}\right)\right]$  as follows:

<span id="page-17-1"></span>**Proposition 3.9.** For all shapes  $\alpha$  and all  $q \in \mathbb{N}$ ,

$$\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha}M_{\alpha}^{\top})^{q}\right)\right] = \sum_{C \in \mathcal{C}_{(\alpha,2q)}} N(C)\operatorname{val}(C).$$

Thus, to analyze  $\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha}M_{\alpha}^{\top})^{q}\right)\right]$  it is sufficient to analyze N(C) and  $\operatorname{val}(C)$  for all  $C \in \mathcal{C}_{(\alpha,2q)}$ . To that end, we make the following observation:

<span id="page-17-0"></span>**Proposition 3.10.** For every constraint graph  $C \in \mathcal{C}_{(\alpha,2q)}$ , val(C) = 1 if every edge in  $\phi(E(\alpha,2q))$  appears an even number of times and val(C) = 0 otherwise (where  $\phi : V(\alpha,2q) \to [n]$  is any piecewise injective map such that  $C(\phi) = C$ ).

*Proof.* Observe that for any multi-set of edges E,  $\chi_E(G) = \chi_{E_{reduced}(G)}$  where  $E_{reduced} = \{e : e \text{ appears in } E \text{ an odd number of times}\}$ . Thus,  $\mathbb{E}[\chi_E(G)] = 1$  if every edge in E appears an even number of times and  $\mathbb{E}[\chi_E(G)] = 0$  otherwise. Taking  $E = \phi(E(\alpha, 2q))$ , the result follows.  $\square$ 

We include two examples of constraint graphs for the case when  $\alpha$  consists of a single edge between  $u_1$  and  $v_1$  (i.e. the shape  $\alpha$  from Example 2.18 whose graph matrix is a  $\pm 1$  Wigner matrix), and q = 4. In both cases, we color equal edges with the same color and style.

![](_page_18_Figure_0.jpeg)

Figure 12: In this constraint graph C,  $u_{1;1} = u_{1;2}$ ,  $v_{1;1} = v_{1;3}$ , and  $v_{1;2} = v_{1;4}$ . Here val(C) = 0 as we see edges that appear only once. More specifically, edges  $\{v_{1;2}, u_{1;3}\}$ ,  $\{u_{1;3}, v_{1;3}\}$ ,  $\{v_{1;3}, u_{1;4}\}$ , and  $\{u_{1;4}, v_{1;4}\}$  appear only once.

![](_page_18_Figure_2.jpeg)

Figure 13: In this constraint graph C,  $v_{1;1} = v_{1;4}$  and  $u_{1;2} = u_{1;3} = u_{1;4}$ . Since every edge appears twice, we have val(C) = 1.

<span id="page-18-1"></span>**Proposition 3.11.** For any constraint graph  $C \in \mathcal{C}_{(\alpha,2q)}$ ,  $N(C) \leq n^{|V(\alpha,2q)|-|E(C)|}$ .

Proof. Observe that choosing a piecewise injective map  $\phi: V(\alpha,2q) \to [n]$  with constraint graph C is equivalent to choosing the distinct indices of  $\phi(V(\alpha,2q))$ . Since there are  $|V(\alpha,2q)|-|E(C)|$  such indices,  $N(C) = \frac{n!}{(n-|V(\alpha,2q)|+|E(C)|)!} \le n^{|V(\alpha,2q)|-|E(C)|}$ 

# <span id="page-18-0"></span>4 Warm-up: The $\pm 1$ Wigner matrix

As a warm-up, we consider the  $\pm 1$  Wigner matrix, i.e.,  $M_{\alpha}$  with the shape  $\alpha$  from Example 2.18. The Wigner matrix and its norm have already been studied extensively; in particular, sharp analyses from the prior works [BY88, Sos99] demonstrate that with high probability, the norm of an  $n \times n$ 

symmetric random  $\pm 1$  matrix is  $2(1 + o(1))\sqrt{n}$ . While our upper bound will not be as strong, it will illustrate the key ideas for the general case.

<span id="page-19-2"></span>**Theorem 4.1.** For all  $\epsilon > 0$ , the following probabilistic upper bound holds:

$$\mathbb{P}\left[\|M_{\alpha}\| > \sqrt{8e\left\lceil\log\left(\frac{n}{\epsilon}\right)\right\rceil n}\right] < \epsilon.$$

*Proof.* We prove this probabilistic norm bound using the trace power method. We have the following upper bound on  $\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha}M_{\alpha}^{\top})^{q}\right)\right]$ .

<span id="page-19-1"></span>**Lemma 4.2.** For all  $q \in \mathbb{N}$  such that  $q \leq \frac{n}{4}$ ,

$$\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha}M_{\alpha}^{\top})^{q}\right)\right] < 2^{2q}(2q)^{q}n^{q+1}.$$

*Proof.* Recall that

$$\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha}M_{\alpha}^{\top})^{q}\right)\right] = \sum_{C \in \mathcal{C}_{(\alpha,2q)}} N(C)\operatorname{val}(C).$$

Also recall from Proposition 3.11 that  $N(C) \leq n^{|V(\alpha,2q)|-|E(C)|}$  and that for all  $C \in \mathcal{C}_{(\alpha,2q)}$ , val(C) = 0 or 1.

To prove our upper bound on  $\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha}M_{\alpha}^{\top})^{q}\right)\right]$ , we prove the following statements:

- 1. For any  $C \in \mathcal{C}_{(\alpha,2q)}$  such that  $\operatorname{val}(C) \neq 0$ ,  $|E(C)| \geq q 1$ .
- 2. For all k, there are at most  $2^{2q-1}(2q)^k$  constraint graphs  $C \in \mathcal{C}_{(\alpha,2q)}$  which have exactly k edges.

Assuming these statements are true, since  $q \leq \frac{n}{4}$ ,

$$\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha}M_{\alpha}^{\top})^{q}\right)\right] \leq \sum_{k=q-1}^{2q-1} n^{2q-k} 2^{2q-1} (2q)^{k} = 2^{2q-1} (2q)^{q-1} n^{q+1} \sum_{k'=0}^{q} \left(\frac{2q}{n}\right)^{k'} < 2^{2q} (2q)^{q} n^{q+1}.$$

Thus, we just need to prove these two statements. We begin with the first statement.

<span id="page-19-3"></span>**Definition 4.3** (Cycles). For all  $k \in \mathbb{N}$ , we take  $C_{2k}$  to be the cycle on 2k vertices, i.e.  $C_{2k}$  is the multi-graph with vertices  $V(C_{2k}) = \{x_i : i \in [2k]\}$  and edges  $E(C_{2k}) = \{\{x_i, x_{i+1}\} : i \in [2k]\}$  (where we take  $v_{2k+1} = v_1$ ).

Since the shape of interest is a single edge (see Example 2.18), the constraint graph  $H(\alpha, 2q)$  will be isomorphic to  $C_{2q}$ . Here and below, we will identify  $H(\alpha, 2q)$  with  $C_{2q}$  to simplify notation. Note from Proposition 3.10 that when  $\operatorname{val}(C) \neq 0$ , it follows that each edge in  $\phi(C_{2q})$  appears an even number of times, in particular, at least twice. Hence, the first statement follows immediately from the following lemma.

<span id="page-19-0"></span>**Lemma 4.4.** For all  $k \in \mathbb{N}$ , for any map  $\phi : V(C_{2k}) \to [n]$  such that each edge in  $\phi(E(C_{2k}))$  appears at least twice,  $|E(C(\phi))| \ge k - 1$ .

*Proof.* We prove this lemma by induction. If k = 1, the result is trivial. If k > 1, assume that the lemma is true up to k - 1 and let  $\phi : V(C_{2k}) \to [n]$  be a map such that each edge in  $\phi(E(C_{2k}))$  appears at least twice.

For our inductive argument, we define the notion of unique vertices: we say a vertex x in  $C_{2k}$  is unique if x is the only vertex with the index  $\phi(x)$ . There are two cases to consider depending on the existence of a unique vertex.

<span id="page-20-0"></span>1. First, assume that  $C(\phi)$  has no unique vertices. In this case,  $|E(C(\phi))| = \frac{V(C_{2k})}{2} = k > k - 1$  and thus the result readily follows. See Figure 14 for an illustration of this fact.

![](_page_20_Figure_3.jpeg)

Figure 14: An illustration of a constraint graph  $C_8$  without unique vertices. Edges of the same value are drawn with the same color and style. Notice that in this case, we have  $|E(C_8)| = \frac{V(C_8)}{2} = 4$  and hence the desired inequality holds.

2. Hence, we may assume that there is a unique vertex  $x_i \in V(C(\phi))$ . We must have that  $\phi(x_{i-1}) = \phi(x_{i+1})$  (where we take  $x_0 = x_{2k}$  and  $x_{2k+1} = x_1$ ) because otherwise both edges  $\phi(\{x_{i-1}, x_i\})$  and  $\phi(\{x_i, x_{i+1}\})$  would appear exactly once in  $\phi(E(C_{2k}))$ .

We now contract the vertices  $x_{i-1}$  and  $x_{i+1}$  together and delete the vertex  $x_i$  to obtain the cycle  $C'_{2k-2}$  of length 2k-2. Moreover, we define the restricted index map  $\phi': V(C'_{2k-2}) \to [n]$  so that the indices match the corresponding indices assigned by  $\phi$  before contraction. Observe that every edge in  $\phi(E(C'_{2k-2}))$  still appears at least twice because the two deleted edges  $\{x_{i-1}, x_i\}$  and  $\{x_i, x_{i+1}\}$  were the only two edges with the value  $\{\phi(x_{i-1}), \phi(x_i)\} = \{\phi(x_i), \phi(x_{i+1})\}$ .

Thus, by the inductive hypothesis,  $|E(C(\phi'))| \ge k - 2$ . Since the contraction got rid of one constraint edge between  $x_{i-1}$  and  $x_{i+1}$ , we have  $|E(C(\phi))| = |E(C(\phi'))| + 1$ , from which we obtain  $|E(C(\phi))| \ge k - 1$ , as needed. An illustration of this process is shown in Figure 15.

<span id="page-21-0"></span>![](_page_21_Figure_0.jpeg)

Figure 15a:  $C(\phi)$ . Figure 15b:  $C(\phi')$ .

Figure 15: An illustration of the contraction argument. Figure 15a illustrates a constraint graph with a unique vertex  $x_5$ . This vertex is indeed unique as there are no constraint edge incident to this vertex. Figure 15b illustrates the contraction process. After the contraction,  $x_5$  disappears and the neighboring vertices, namely  $x_4$  and  $x_6$ , are merged into one. The resulting graph still satisfies the property that every edge value appears at least twice, allowing us to use the inductive hypothesis.

Combining the two cases above, the inductive step is completed, and hence Lemma 4.4 follows.  $\Box$ 

We now prove the second statement.

<span id="page-21-1"></span>**Proposition 4.5.** For all  $k \in \mathbb{N}$ , there are at most  $2^{|V(\alpha,2q)|-1}(2q)^k = 2^{2q-1}(2q)^k$  constraint graphs  $C \in \mathcal{C}_{(\alpha,2q)}$  which have exactly k constraint edges.

*Proof.* To count the number of constraint graphs with exactly k constraint edges, we encode each constraint graph as follows. Let C be a given constraint graph with k constraint edges. Since we have identified the constraint graph with cycles, we can naturally order the vertices according to their indices, i.e.,  $x_1, x_2, \ldots, x_{2q}$ . Having ordered the vertices, define

$$V_{\text{redundant}} := \{ x_i \in V(C_{2q}) : \exists x_j \in V(C_{2q}) : \phi(x_i) = \phi(x_j), \quad j < i \},$$

where  $\phi: V(\alpha, 2q) \to [n]$  is any piecewise injective map such that  $C(\phi) = C$ . Notice that  $V_{\text{redundant}} = k$  as there are k constraint edges in C.

Now we encode the constraint graph C with the following data:

- 1. For each vertex  $x_i \in V(C_{2q})$ , is  $x_i \in V_{\text{redundant}}$ ?
- 2. For each vertex  $x_i \in V_{\text{redundant}}$ , what is the vertex  $x_j \in V(C_{2q})$  which comes before  $x_i$  such that  $\phi(x_i) = \phi(x_j)$ ? Here if there are multiple such vertices, we may pick any of them.

Having defined the encoding scheme, one can easily observe that this encoding is valid, i.e., each encoding corresponds to a unique constraint graph C.

Now, based on this encoding scheme, one can easily count the number of constraint graphs with k constraint edges. Since the first vertex cannot be in  $V_{\text{redundant}}$ , there are at most  $2^{2q-1}$  possibilities for which vertices are in  $V_{\text{redundant}}$ . For each of the k vertices  $x_i \in V_{\text{redundant}}$ , there are at most 2q choices for the vertex  $x_j$  which comes before  $x_i$  such that  $\phi(x_i) = \phi(x_j)$ .

Putting everything together, there are at most  $2^{2q-1}(2q)^k$  constraint graphs  $C \in \mathcal{C}_{(\alpha,2q)}$  which have exactly k constraint edges, as needed.

We have completed the proofs of the two statements, which completes the proof of Lemma 4.2.

Having established Lemma 4.2, one can now prove Theorem 4.1 using the trace power method. By the trace power method (Lemma 3.1), for all  $\epsilon > 0$ ,

$$\mathbb{P}\left[\|M_{\alpha}\| > \min_{q \in \mathbb{N}: q \leq \frac{n}{4}} \left\{ \sqrt[2q]{\frac{B(2q)}{\epsilon}} \right\} \right] < \epsilon$$

where  $B(2q) = 2^{2q}(2q)^q n^{q+1}$ . The derivative of

$$\ln\left(\sqrt[2q]{\frac{B(2q)}{\epsilon}}\right) = \ln\left(2\sqrt{2n}\sqrt{q}\sqrt[2q]{\frac{n}{\epsilon}}\right) = \ln(2\sqrt{2n}) + \frac{\ln(q)}{2} + \frac{\ln(\frac{n}{\epsilon})}{2q}$$

with respect to q is  $\frac{1}{2q} - \frac{\ln(\frac{n}{\epsilon})}{2q^2}$  which is only 0 at  $q = \ln(\frac{n}{\epsilon})$ . Since the second derivative is positive at  $q = \ln(\frac{n}{\epsilon})$ , this is a global minimum for our bound. However, we require that  $q \in \mathbb{N}$ , so we instead take  $q = \lceil \ln(\frac{n}{\epsilon}) \rceil$ . Taking  $q = \lceil \ln(\frac{n}{\epsilon}) \rceil$ ,

$$\sqrt[2q]{\frac{B(2q)}{\epsilon}} = 2\sqrt{2qn} \left(\frac{n}{\epsilon}\right)^{\frac{1}{\lceil 2\ln(\frac{n}{\epsilon})\rceil}} \le 2\sqrt{2e \left[\ln\left(\frac{n}{\epsilon}\right)\right]n}.$$

Note that if  $q = \lceil \ln(\frac{n}{\epsilon}) \rceil \ge \frac{n}{4}$  then  $2\sqrt{2qn} > n$  but  $||M_{\alpha}||$  is always at most n so our bound holds in this case as well.

# <span id="page-22-0"></span>5 Modified techniques for graph matrices

In this section, we modify the techniques in Section 4 so that they can be applied to more general shapes  $\alpha$ . Due to technical reasons, for many of the matrices M which we analyze, it is difficult to analyze  $\mathbb{E}\left[\operatorname{Tr}\left((MM^{\top})^q\right)\right]$  directly. Instead, we break M up into pieces which are easier to analyze. To that end, we consider a vertex partitioning argument which we use to modify the trace power method.

#### 5.1 Vertex partitioning

**Definition 5.1.** Given a shape  $\alpha$ , we define an  $\alpha$ -partition of the indices to be a tuple  $P = (I_v : v \in V(\alpha))$  such that

- 1.  $\forall v \in V(\alpha), I_v \subset [n]$ .
- 2.  $\forall u \neq v \in V(\alpha), I_u \cap I_v = \emptyset$ .
- 3.  $\bigcup_{v \in V(\alpha)} I_v = [n]$

We define  $\mathcal{P}_{\alpha}$  to be the set of all possible  $\alpha$ -partitions of the indices.

<span id="page-23-0"></span>**Proposition 5.2.**  $|\mathcal{P}_{\alpha}| = |V(\alpha)|^n$ .

*Proof.* The proposition follows from the fact that each element in [n] can be assigned to  $|V(\alpha)|$  different  $I_v$ 's.

**Definition 5.3.** Given an  $\alpha$ -partition P of the indices, we say that a map  $\phi: V(\alpha) \to [n]$  is P-respecting if  $\forall v \in V(\alpha), \phi(v) \in I_v$ .

<span id="page-23-1"></span>**Proposition 5.4.** For any injective map  $\phi: V(\alpha) \to [n]$ , there are exactly  $|V(\alpha)|^{n-|V(\alpha)|}$   $\alpha$ -partitions  $P \in \mathcal{P}_{\alpha}$  such that  $\phi$  is P-respecting.

Proof. Consider an integer  $i \in [n]$ . If  $i = \phi(v)$  for some  $v \in V(\alpha)$ , then we have  $i \in I_v$  by definition. Otherwise, i.e.,  $i \notin \phi(V(\alpha))$ , one can assign i to an arbitrary  $I_v$ , which amounts to  $|V(\alpha)|$  different possibilities. Since there are  $n - |V(\alpha)|$  elements outside the image of  $\phi$ , the conclusion follows.  $\square$ 

**Definition 5.5.** We define  $M_{\alpha,P}$  to be the matrix with entries

$$M_{\alpha,P}(A,B) = \sum_{\phi:V(\alpha) \to [n]: \phi \text{ is $P$-respecting, } \phi(U_\alpha) = A, \phi(V_\alpha) = B} \chi_{\phi(E(\alpha))}(G) \,.$$

The following result is an immediate consequence of Propositions 5.2 and 5.4:

<span id="page-23-2"></span>Corollary 5.6. 
$$M_{\alpha} = \frac{|V(\alpha)|^{|V(\alpha)|}}{|\mathcal{P}_{\alpha}|} \sum_{P \in \mathcal{P}_{\alpha}} M_{\alpha,P}$$
.

## <span id="page-23-3"></span>5.2 Constraint graphs and vertex partitioning

We can still use constraint graphs to analyze the matrices  $M_{\alpha,P}$ . To that end, we first consider an expansion similar to Proposition 3.5. One difference is that due to the definition of  $M_{\alpha,P}$  the summation is over only  $\phi$ 's that respect the partition P:

**Definition 5.7.** Given a shape  $\alpha$ ,  $q \in \mathbb{N}$ , and  $P \in \mathcal{P}_{\alpha}$ , we say that a map  $\phi : V(\alpha, 2q) \to [n]$  is P-respecting if  $\phi$  is P-respecting on each piece  $V(\alpha_i)$  and each piece  $V(\alpha_i^{\top})$  for all  $i \in [q]$ . In other words, for all vertices  $v \in V(\alpha)$  and all  $i \in [q]$ , letting  $v_i \in V(\alpha_i)$  be the copy of v in  $V(\alpha_i)$  and letting  $v_i' \in V(\alpha_i^{\top})$  be the copy of v in  $V(\alpha_i^{\top})$ ,  $v_i, v_i' \in I_v$ .

**Remark 5.8.** Note that if a map  $\phi: V(\alpha, 2q) \to [n]$  is P-respecting, then it is automatically piecewise injective. Also note that vertex partitioning does not affect val(C).

The above definition yields the following analogue of Proposition 3.5 for  $M_{\alpha,P}$ :

**Proposition 5.9.** For all shapes  $\alpha$ , all  $P \in \mathcal{P}_{\alpha}$ , and all  $q \in \mathbb{N}$ ,

$$\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha,P}M_{\alpha,P}^{\top})^{q}\right)\right] = \sum_{\phi:V(\alpha,2q)\to[n]:\phi \text{ is }P\text{-respecting}} \mathbb{E}\left[\chi_{\phi(E(\alpha,2q))}(G)\right].$$

In fact, the fact that the summation is over P-respecting maps makes the analysis nicer because the constraint graphs corresponding to those maps are well-behaved:

**Definition 5.10.** We say that a constraint graph  $C \in \mathcal{C}_{(\alpha,2q)}$  is well-behaved if for every edge  $(u,w) \in E(C)$ , u,w are copies of the same vertex  $v \in V(\alpha)$  (or its mirror in  $V(\alpha^{\top})$ ).

Similarly to Proposition 3.9, we represent the summation in terms of constraint graphs by counting the number of maps  $\phi$  corresponding to each constraint graph C.

**Definition 5.11.** Given a constraint graph  $C \in \mathcal{C}_{(\alpha,2q)}$ , we define

$$N_P(C) = |\{\phi : V(\alpha, 2q) \to [n] : \phi \text{ is } P\text{-respecting}, C(\phi) \equiv C\}|.$$

Since every constraint graph corresponding to a P-respecting map  $\phi: V(\alpha, 2q) \to [n]$  is well-behaved, the following holds:

**Proposition 5.12.** If  $C \in \mathcal{C}_{(\alpha,2q)}$  is not well-behaved then for all  $P \in \mathcal{P}_{\alpha}$ ,  $N_P(C) = 0$ .

Consequently, the summation is over only well-behaved constraints, which implies the following representation of the trace power:

<span id="page-24-2"></span>Corollary 5.13. For all shapes  $\alpha$ , all  $P \in \mathcal{P}_{\alpha}$ , and all  $q \in \mathbb{N}$ ,

$$\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha,P}M_{\alpha,P}^{\top})^{q}\right)\right] = \sum_{C \in \mathcal{C}_{(\alpha,2q)} : C \text{ is well-behaved}} N_{P}(C)\operatorname{val}(C).$$

#### 5.3 Vertex partitioning and the trace power method

One way to obtain a norm bound on  $M_{\alpha}$  would be to use the norm bounds on  $M_{\alpha,P}$  and then use a union bound to upper bound the probability that some norm bound fails. Unfortunately, there are too many matrices  $M_{\alpha,P}$  for this naive analysis to work. However, with a careful modification of the trace power method we can obtain probabilistic norm bounds on  $M_{\alpha}$  directly from upper bounds on  $\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha,P}M_{\alpha,P}^{\top})^q\right)\right]$ .

<span id="page-24-1"></span>**Lemma 5.14** (Vertex partitioning lemma). If M is a matrix such that  $M = \frac{1}{K} \sum_{i=1}^{K} M_i$  for some  $K \in \mathbb{N}$  and matrices  $\{M_i : i \in [K]\}$  and  $B : \mathbb{N} \to \mathbb{R}$  is a function such that for all  $i \in [K]$  and all  $q \geq 3$ ,  $\mathbb{E}\left[\operatorname{Tr}\left(\left(M_iM_i^{\top}\right)^q\right)\right] \leq B(2q)$  then for all  $\epsilon > 0$ ,

$$\mathbb{P}\left[\|M\| > \min_{q \ge 3} \left\{ 2 \sqrt[2q]{\frac{B(2q)}{\epsilon}} \right\} \right] < \epsilon.$$

*Proof.* We can prove this lemma as follows:

- 1. Use the trace power method to obtain probabilistic norm bounds on the matrices  $\{M_i : i \in [K]\}$ .
- 2. Combine these probabilistic norm bounds on the matrices  $\{M_i : i \in [K]\}$  to obtain the probabilistic norm bound on M.

We start with step 2 as this determines what probabilistic norm bounds we need on the matrices  $\{M_i : i \in [K]\}$ . For step 2, we use the following lemma.

<span id="page-24-0"></span>**Lemma 5.15.** If M is a matrix such that  $M = \frac{1}{K} \sum_{i=1}^{K} M_i$  for some  $K \in \mathbb{N}$  and matrices  $\{M_i : i \in [K]\}$  and  $B \in \mathbb{R}$  is a bound such that for all  $i \in [K]$  and all  $x \in [\frac{1}{2}, K], \mathbb{P}[\|M_i\| > Bx] \leq \frac{\epsilon}{32x^3}$  then  $\mathbb{P}[\|M\| \geq B] < \epsilon$ .

*Proof of Lemma 5.15.* To prove this, we make the following observation.

<span id="page-25-0"></span>**Proposition 5.16.** For all  $j \in [0, \log_2(K) + 1]$ ,  $\mathbb{P}\left[|\{i \in [K] : ||M_i|| > 2^{j-1}B\}| > \frac{K}{2^{2j+1}}\right] \leq \frac{\epsilon}{2^{j+1}}$ .

Proof of Proposition 5.16. We prove this by contradiction. If  $\mathbb{P}\left[|\{i \in [K] : ||M_i|| > 2^{j-1}B\}| > \frac{K}{2^{2j+1}}\right] > \frac{\epsilon}{2^{j+1}}$ , then  $\mathbb{E}\left[|\{i \in [K] : ||M_i|| > 2^{j-1}B\}|\right] > \frac{K}{2^{2j+1}} \cdot \frac{\epsilon}{2^{j+1}} = \frac{\epsilon K}{2^{3j+2}}$ . However, plugging in  $x = 2^{j-1}$  we have that

$$\mathbb{E}\left[|\{i \in [K] : \|M_i\| > 2^{j-1}B\}|\right] \le K \max_i \left\{\mathbb{P}[\|M_i\| > Bx]\right\} \le \frac{\epsilon K}{32x^3} = \frac{\epsilon K}{2^{3j+2}}$$

which gives a contradiction.

Using this proposition, with probability at least  $1 - \sum_{j=0}^{\lfloor \log_2(K) + 1 \rfloor} \frac{\epsilon}{2^{j+1}} > 1 - \epsilon$ ,

$$\forall j \in [0, \log_2(K) + 1], |\{i : ||M_i|| > 2^{j-1}B\}| \le \frac{K}{2^{2j+1}}.$$

Writing the above statement in a different way, we have

- 1.  $\forall j \in [0, \lceil \log_2(K) \rceil], \ |\{i : 2^{j-1}B < \|M_i\| \le 2^j B\}| \le \frac{K}{2^{2j+1}}$  and
- 2. there are no matrices  $M_i$  such that  $||M_i|| > 2^{\lceil \log_2(K) \rceil} B$ .

This implies that

$$||M|| \le \sum_{j=0}^{\lceil \log_2(K) \rceil} \frac{1}{2^{2j+1}} \cdot 2^j B = \sum_{j=0}^{\lceil \log_2(K) \rceil} \frac{B}{2^{j+1}} < B.$$

Thus,  $\mathbb{P}[\|M\| \geq B] < \epsilon$ , as needed.

With Lemma 5.15 in mind, we now obtain probabilistic norm bounds on the matrices  $\{M_i : i \in [K]\}$  which hold with probability at least  $1 - \frac{\epsilon}{32x^3}$ .

Assume that  $q \geq 3$ ,  $\epsilon > 0$ , and  $x \geq \frac{1}{2}$ . Applying the trace power method (Lemma 3.1) with  $\epsilon' = \frac{\epsilon}{32x^3}$ , we obtain:

$$\mathbb{P}\left[\|M_i\| > \sqrt[2q]{\frac{B(2q)}{\epsilon'}}\right] < \epsilon'.$$

Now take  $B = 2\sqrt[2q]{\frac{B(2q)}{\epsilon}}$ . Since  $q \geq 3$ ,  $\sqrt[2q]{\frac{B(2q)}{\epsilon'}} = \sqrt[2q]{32x^3\frac{B(2q)}{\epsilon}} < Bx$ . Thus, for all  $i \in [K]$  and  $x \geq \frac{1}{2}$ ,  $\mathbb{P}[\|M_i\| > Bx] < \frac{\epsilon}{32x^3}$ .

Plugging these bounds into Lemma 5.15, we obtain  $\mathbb{P}\left[\|M\| \geq 2\sqrt[2q]{\frac{B(2q)}{\epsilon}}\right] < \epsilon$ . Since this holds for all  $q \geq 3$  and  $\epsilon > 0$ , the result follows after taking the minimum over  $q \geq 3$ .

Remark 5.17 (Alternative vertex partitioning arguments). An alternative way to obtain a probabilistic norm bound on M is as follows. Instead of expressing M as the average of K matrices, we "cover" M by  $m = O(\log(n))$  matrices  $\{M_i : i \in [m]\}$ . More precisely, we take each  $M_i$  to be a matrix of the form  $M_{\alpha,P}$  except that we zero out any entry which was already included in a previous matrix. Thus,  $M = \sum_{i=1}^m M_i$ . We can then use the fact that  $\|M\| \leq m \cdot \max_{i \in [m]} \|M_i\|$  and use a union bound to bound the probability that any of the norm bounds on the matrices

 $\{M_i : i \in [m]\}$  fail. Indeed, this argument was employed in prior works (e.g. see the beginning of Section 4 in [BM16]).

While this alternate approach is simpler than the given approach in some ways, the bound it gives is worse by a logarithmic factor.

## <span id="page-26-1"></span>6 Proving norm bounds on graph matrices (Theorem 2.24)

In this section, we prove our main theorem (Theorem 2.24), building on the proof for symmetric  $\pm 1$  Wigner matrices in Section 4. We first give the formal statement of Theorem 2.24:

<span id="page-26-0"></span>**Theorem 6.1** (Formal statement of Theorem 2.24). For a given shape  $\alpha = (U_{\alpha}, V_{\alpha}, W_{\alpha}, E(\alpha))$ , let  $S_{\min}$  be a minimum vertex separator between  $U_{\alpha}$  and  $V_{\alpha}$ , and  $W_{\text{iso}} \subset W_{\alpha}$  be the subset of isolated middle vertices. Based on this, taking  $C_{\alpha} := |W_{\alpha}| + |S_{\min}| - |W_{\text{iso}}| - |U_{\alpha} \cap V_{\alpha}|$  and  $D_{\alpha} := |V(\alpha)| - |W_{\text{iso}}| - |U_{\alpha} \cap V_{\alpha}|$ , the following bounds hold:

1. (Probabilistic bounds for  $C_{\alpha} > 0$ ) If  $C_{\alpha} > 0$ , for all  $\epsilon > 0$ , we have

$$\mathbb{P}\left[\|M_\alpha\| \geq \left(6e\left\lceil\frac{1}{3C_\alpha}\log(n^{|S_{\min}|}/\epsilon)\right\rceil\right)^{\frac{1}{2}C_\alpha} \cdot (2D_\alpha)^{D_\alpha}n^{\frac{1}{2}(|V(\alpha)|+|W_{\mathrm{iso}}|-|S_{\min}|)}\right] \leq \epsilon \,.$$

2. (Trivial deterministic bounds)  $||M_{\alpha}|| \leq n^{\frac{1}{2}(|V(\alpha)| + |W_{\alpha}| - |U_{\alpha} \cap V_{\alpha}|)}$ .

We will first restrict ourselves to the special case where the left and right vertices are disjoint, i.e.,  $U_{\alpha} \cap V_{\alpha} = \emptyset$  and there are no isolated middle vertices, i.e.,  $W_{\text{iso}} = \emptyset$ . This special case delivers the key ideas of the proof while avoiding unnecessary complications. Later in this section, we will discuss how we can relax the restrictions and prove the full results in Theorem 6.1.

## <span id="page-26-2"></span>6.1 Proof for the special case: $U_{\alpha} \cap V_{\alpha} = \emptyset$ and $W_{iso} = \emptyset$

We begin with proving the trivial deterministic bound:

Proof of the trivial deterministic bound. Since we are considering the case when  $U_{\alpha} \cap V_{\alpha} = \emptyset$ , we need to show that  $\|M_{\alpha}\| \leq n^{\frac{1}{2}(|V(\alpha)|+|W_{\alpha}|)}$ . To prove this, we will use a simple fact that an  $n_1 \times n_2$  matrix with the magnitude of each entry bounded by c has spectral norm at most  $c \cdot \sqrt{n_1 n_2}$ . Indeed, this fact is an easy consequence of the inequality  $\|M\| \leq \|M\|_F$  for any matrix M where  $\|M\|_F$  is the Frobenius norm of M. Now it is straightforward from the definition of graph matrices (Definition 2.16) that there are at most  $n^{|U_{\alpha}|}$  rows and at most  $n^{|V_{\alpha}|}$  columns in  $M_{\alpha}$ . Moreover, each entry of  $M_{\alpha}$  is the summation of at most  $n^{|W_{\alpha}|} \pm 1$  random variables, so the magnitude of each entry is bounded by  $n^{|W_{\alpha}|}$ . Hence, from the simple fact above, the trivial deterministic bound follows:  $\|M_{\alpha}\| \leq n^{|W_{\alpha}|} \cdot \sqrt{n^{|U_{\alpha}|} \cdot n^{|V_{\alpha}|}} = n^{\frac{1}{2}(|V(\alpha)| + |W_{\alpha}|)}$ .

Now we prove the probabilistic bound. Before the proof, we make one notation remark:

• Here and below, we simply write  $s := |S_{\min}|$ .

Note that for this special case the probabilistic bound reads:

$$\mathbb{P}\left[\|M_{\alpha}\| \ge \left(6e\left\lceil \frac{1}{3(|W_{\alpha}|+s)}\ln(n^{s}/\epsilon)\right\rceil\right)^{\frac{1}{2}(|W_{\alpha}|+s)} \cdot (2|V(\alpha)|)^{|V(\alpha)|} n^{\frac{1}{2}(|V(\alpha)|-s)}\right] \le \epsilon \tag{6.1}$$

The proof of (6.1) bears great similarities to the proof for the  $\pm 1$  random matrix. One main distinction is that we now decompose  $M_{\alpha}$  into well-behaved pieces and conquer each piece separately. More formally, we decompose  $M_{\alpha}$  as follows in light of Corollary 5.6:

<span id="page-27-2"></span><span id="page-27-0"></span>
$$M_{\alpha} = \frac{|V(\alpha)|^{|V(\alpha)|}}{|\mathcal{P}_{\alpha}|} \sum_{P \in \mathcal{P}_{\alpha}} M_{\alpha,P}.$$
(6.2)

Now, similar to the  $\pm 1$  random matrix case, the key step is to establish upper bounds on the terms  $\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha,P}M_{\alpha,P}^{\top})^q\right)\right]$ . Indeed, one can turn upper bounds on the expected trace power into a probabilistic upper bound on  $\|M_{\alpha}\|$  via the vertex partitioning lemma (Lemma 5.14). As we shall see later, it turns out the following analogue of Lemma 4.2 suffices:

<span id="page-27-1"></span>**Lemma 6.2.** For all  $q \in \mathbb{N}$  such that  $q \leq \frac{n}{4}$ ,

$$\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha,P}M_{\alpha,P}^{\top})^{q}\right)\right] \leq 2^{2q|V(\alpha)|}(2q)^{q(|W_{\alpha}|+s)}n^{q(|V(\alpha)|-s)+s}.$$

*Proof.* Paralleling the proof of Lemma 4.2, the following statements are main ingredients to proving Lemma 6.2:

- 1. For any well-behaved  $C \in \mathcal{C}_{(\alpha,2q)}$  such that  $\operatorname{val}(C) \neq 0, |E(C)| \geq q|W_{\alpha}| + (q-1)s$ .
- 2. For all k, there are at most  $2^{|V(\alpha,2q)|-1}(2q)^k$  well-behaved constraint graphs  $C \in \mathcal{C}_{(\alpha,2q)}$  which have exactly k constraint edges.

Assuming these statements are true, the proof of Lemma 6.2 is immediate. To see this, first recall that by Corollary 5.13,

$$\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha,P}M_{\alpha,P}^{\top})^{q}\right)\right] = \sum_{\substack{C \in \mathcal{C}_{(\alpha,2q)}: C \text{ is well-behaved} \\ \leq \sum_{\substack{C \in \mathcal{C}_{(\alpha,2q)}: C \text{ is well-behaved} \\ \operatorname{val}(C) \neq 0}} n^{|V(\alpha,2q)| - |E(C)|},$$

where the inequality follows from Proposition 3.11 together with the simple fact  $N_P(C) \leq N(C)$ . Now, we rearrange the summation in terms of |E(C)|. Due to the first statement, |E(C)| should be greater than or equal to  $q|W_{\alpha}| + (q-1)s$  and at most  $|V(\alpha, 2q)| - 1$ . Moreover, the summand for |E(C)| = k is at most  $2^{|V(\alpha,2q)|-1}(2q)^k \cdot n^{|V(\alpha,2q)|-k}$  due to the second statement. Thus, the trace power term can be upper bounded as follows:

$$\begin{split} \mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha,P}M_{\alpha,P}^{\top})^{q}\right)\right] &\leq \sum_{k=q|W_{\alpha}|+(q-1)s}^{|V(\alpha,2q)|-1} 2^{|V(\alpha,2q)|-1} (2q)^{k} n^{|V(\alpha,2q)|-k} \\ &\leq 2^{|V(\alpha,2q)|-1} n^{|V(\alpha,2q)|} \left(\frac{2q}{n}\right)^{q|W_{\alpha}|+(q-1)s} \cdot \sum_{k=0}^{\infty} \left(\frac{2q}{n}\right)^{k} \\ &\leq 2^{|V(\alpha,2q)|} n^{|V(\alpha,2q)|} \left(\frac{2q}{n}\right)^{q|W_{\alpha}|+(q-1)s} , \end{split}$$

where the last inequality is due to the assumption  $q \leq \frac{n}{4}$ . It is then straightforward to check that the last upper bound is upper bounded by the bound in Lemma 6.2 using Proposition 3.3 which says that  $|V(\alpha, 2q)| = q|U_{\alpha} \cup V_{\alpha}| + 2q|W_{\alpha}|$ .

Thus, we just need to prove these two statements. We begin with the first statement. For the first statement, we need to recall classical results from graph theory: König's Theorem [Kon31] and Menger's Theorem [Men27]. For completeness, we first state them here:

<span id="page-28-0"></span>**Proposition 6.3** (König's Theorem). Given a graph G, a vertex cover of G is a set of vertices  $V \subseteq V(G)$  such that all edges of G are incident with at least one vertex in V. If G is a bipartite graph with partite sets U and V then the minimal size of a vertex cover of G is equal to the maximal size of a matching between U and V.

<span id="page-28-1"></span>**Proposition 6.4** (Menger's Theorem). If G is a graph and  $U, V \subseteq V(G)$ , we say S is a vertex separator between U and V if all paths from U to V intersect S. If G is a graph and  $U, V \subseteq V(G)$  then the minimum size of a vertex separator between U and V is equal to the maximal number of vertex disjoint paths between U and V.

Now we are ready to prove the first statement:

<span id="page-28-2"></span>**Lemma 6.5.** For any well-behaved  $C \in \mathcal{C}_{(\alpha,2q)}$  such that  $\operatorname{val}(C) \neq 0$ ,  $|E(C)| \geq q|W_{\alpha}| + (q-1)s$ . As a special case, if  $\alpha$  is bipartite, then  $|E(C)| \geq (q-1)s$ .

*Proof.* As a warmup, we begin with the case where  $\alpha$  is bipartite. In this case, s is the minimum size of a vertex cover of  $\alpha$ .

By König's Theorem (Proposition 6.3), there is a matching of size s between  $U_{\alpha}$  and  $V_{\alpha}$  in  $\alpha$ . Choose an arbitrary edge  $\{u,v\}$  from the matching and consider the cycle  $T=C_{2q}$  (see Definition 4.3) formed by the copies of u and v in C. Then, there is no constraint edge between T and  $C \setminus C_{2q}$  because the constraint graph is well-behaved. This implies that edges in  $\phi(E(T))$  do not appear in  $\phi(E(\alpha, 2q) \setminus E(T))$ . Hence, each edge in  $\phi(E(T))$  appears at least twice within  $\phi(E(T))$ . Applying Lemma 4.4 to T, there should be at least q-1 constraint edges between vertices of T.

Since  $\{u, v\}$  was arbitrarily chosen, one can apply this argument to all of the edges in the perfect matching, which gives the desired lower bound of (q-1)s.

For general  $\alpha$ , we can use similar ideas. By Menger's Theorem (Proposition 6.4), there are s vertex-disjoint paths  $P_1, \ldots, P_s$  from  $U_{\alpha}$  to  $V_{\alpha}$  such that for each of these paths  $P_i$ :

- 1. The length of  $P_i$  is at least 1.
- 2.  $P_i$  only intersects  $U_{\alpha}$  in its first vertex and  $P_i$  only intersects  $V_{\alpha}$  in its last vertex. In other words, there is no subpath of  $P_i$  from  $U_{\alpha}$  to  $V_{\alpha}$ .

Let  $l_1, \ldots, l_s$  be the lengths of these paths. Letting  $T_1, \ldots, T_s$  be the vertex disjoint cycles where  $T_i$  consists of all of the copies of the path  $P_i$ ,  $T_i$  has length  $2ql_i$  and following similar logic, there must be at least  $ql_i - 1$  constraint edges within  $T_i$ . Thus, there must be at least  $q(\sum_{i=1}^s l_i) - s$  constraint edges within these cycles.

In addition, there are  $2q(|W_{\alpha}| - \sum_{i=1}^{s} (l_i - 1))$  vertices in  $V(\alpha, 2q)$  which are copies of vertices in  $W_{\alpha}$  but are not part of any of these cycles. Observe that each of these vertices must be incident to at least one constraint edge as otherwise there would be an edge in  $\phi(V(\alpha))$  which only appears once. Thus, there must be at least  $q(|W_{\alpha}| - \sum_{i=1}^{s} (l_i - 1))$  additional constraint edges.

Putting everything together,  $|E(C)| \ge q|W_{\alpha}| + (q-1)s$ .

We now prove the second statement.

<span id="page-29-0"></span>**Proposition 6.6.** For all k, there are at most  $2^{|V(\alpha,2q)|-1}(2q)^k$  well-behaved constraint graphs  $C \in \mathcal{C}_{(\alpha,2q)}$  which have exactly k constraint edges.

*Proof.* The proof is very similar to the proof of Lemma 4.5. To specify the constraint graph, it is sufficient to specify the following data:

- 1. The set of vertices  $V_{\text{redundant}} \subseteq V(\alpha, 2q)$  which are equal to a previously seen vertex.
- 2. For each vertex  $v \in V_{\text{redundant}}$ , which previously seen vertex  $u \in V(\alpha, 2q)$  is v equal to?

The first vertex we consider cannot be in  $V_{\text{redundant}}$  and each vertex we consider afterwards is either in  $V_{\text{redundant}}$  or it is not. Thus, there are at most  $2^{|V(\alpha,2q)|-1}$  choices for which vertices are in  $V_{\text{redundant}}$ .

Since the constraint graph C must be well-behaved, for each vertex  $v \in V_{redundant}$ , there are at most 2q choices for which previous vertex v is equal to. Since  $|V_{redundant}| = k$ , there are at most  $(2q)^k$  choices for the previous vertices.

Putting everything together, there are at most  $2^{|V(\alpha,2q)|-1}(2q)^k$  possibilities, as needed.

This completes the proof of Lemma 6.2.

Having established the upper bounds on the expected trace power terms, one can turn them into a probabilistic norm bound on  $||M_{\alpha}||$  using the vertex partitioning lemma (Lemma 5.14). In particular, due to (6.2) and Lemma 6.2, one can apply the vertex partitioning lemma (Lemma 5.14) with

- 1.  $M \leftarrow \frac{1}{|V(\alpha)||V(\alpha)|} M_{\alpha}$ ,
- 2.  $\{M_i\} \leftarrow \{M_{\alpha,P}\}$ , and
- 3.  $B(2q) \leftarrow 2^{2q|V(\alpha)|}(2q)^{q(|W_{\alpha}|+s)}n^{q(|V(\alpha)|-s)+s}$

This gives the following for all  $\epsilon > 0$ :

$$\mathbb{P}\left[\|M_{\alpha}\| > (2|V(\alpha)|)^{|V(\alpha)|} n^{\frac{1}{2}(|V(\alpha)|-s)} 2^{\frac{1}{2}(|W_{\alpha}|+s)} \min_{3 \leq q \leq \frac{n}{4}} \left\{ q^{\frac{1}{2}(|W_{\alpha}|+s)} (n^s/\epsilon)^{1/2q} \right\} \right] < \epsilon.$$

Now let us estimate the norm bound by computing the minimum value. A similar derivative calculation concludes that the upper bound acheives the minimum at  $q^* := \frac{1}{|W_{\alpha}|+s} \ln(n^s/\epsilon)$ . To ensure that our choice of q is an integer at least 3, let us opt for a slightly suboptimal choice  $q = 3\lceil q^*/3 \rceil$ ; this will surely guarantee  $q \geq 3$  since  $3\lceil a/3 \rceil \geq 3$  for any a > 0.

Let us first assume that  $3\lceil q^*/3\rceil \le n/4$ , then choosing  $q = 3\lceil q^*/3\rceil$  in the minimum term, we obtain:

• 
$$q^{\frac{1}{2}(|W_{\alpha}|+s)} = \left(3\left\lceil\frac{1}{3(|W_{\alpha}|+s)}\ln(n^s/\epsilon)\right\rceil\right)^{\frac{1}{2}(|W_{\alpha}|+s)}$$
.

• 
$$(n^s/\epsilon)^{1/2q} \le (n^s/\epsilon)^{\frac{|W_{\alpha}|+s}{2\ln(n^s/\epsilon)}} = e^{\frac{1}{2}(|W_{\alpha}|+s)}$$
.

Using these, we recover (6.1).

Now we are left with the corner case  $3\lceil q^{\star}/3\rceil = 3\lceil \frac{1}{3(|W_{\alpha}|+s)} \ln(n^s/\epsilon)\rceil > \frac{n}{4}$ , i.e.,  $\epsilon$  is very small In this case, we show that the probabilistic bound trivially holds since it becomes larger than the trivial upper bound on  $||M_{\alpha}||$ :

$$\left(6e \left[\frac{1}{3(|W_{\alpha}|+s)} \ln(n^{s}/\epsilon)\right]\right)^{\frac{1}{2}(|W_{\alpha}|+s)} \cdot (2|V(\alpha)|)^{|V(\alpha)|} n^{\frac{1}{2}(|V(\alpha)|-s)} 
> \left(\frac{en}{2}\right)^{\frac{1}{2}(|W_{\alpha}|+s)} \cdot (2|V(\alpha)|)^{|V(\alpha)|} n^{\frac{1}{2}(|V(\alpha)|-s)} 
= \left(\frac{e}{2}\right)^{\frac{1}{2}(|W_{\alpha}|+s)} \cdot (2|V(\alpha)|)^{|V(\alpha)|} n^{\frac{1}{2}(|V(\alpha)|+|W_{\alpha}|)} \ge n^{\frac{1}{2}(|V(\alpha)|+|W_{\alpha}|)}.$$

## <span id="page-30-1"></span>6.2 The case with nonempty left-right intersection: $U_{\alpha} \cap V_{\alpha} \neq \emptyset$

Now we extend the argument from the previous section to the case where  $U_{\alpha} \cap V_{\alpha} \neq \emptyset$ . The key observation is that in that case  $M_{\alpha}$  is a block-diagonal matrix whose blocks behave like the graph matrices corresponding to the shape without the intersection.

To be specific, consider a submatrix determined by fixing indices corresponding to the intersection  $U_{\alpha} \cap V_{\alpha}$ , i.e, fixing  $\sigma(U_{\alpha} \cap V_{\alpha})$ . Then, one can readily notice from the definition of  $M_{\alpha}$  (Definition 2.16) that  $M_{\alpha}$  is the matrix having such submatrices as diagonal blocks. Note that the total number of blocks is

<span id="page-30-0"></span>
$$n(n-1)\cdots(n+1-|U_{\alpha}\cap V_{\alpha}|)\leq n^{|U_{\alpha}\cap V_{\alpha}|}$$
.

Moreover, one can observe that regardless of what we choose for the  $\sigma(U_{\alpha} \cap V_{\alpha})$ , the distribution of the resulting submatrix is the same.

Since the spectral norm of a block-diagonal matrix is equal to the maximum of those of individual blocks, one can bound the norm of each block and use the union bound to bound  $\|M_{\alpha}\|$ . On the other hand, since each block has the same distribution, it is enough to prove the norm bound for an arbitrarily chosen block. Let  $L_{\alpha}$  be a diagonal block corresponds to an arbitrarily fixed  $\sigma(U_{\alpha} \cap V_{\alpha})$ . Then, in order to prove Theorem 6.1 for this case, the union bound implies that it suffices to show:

$$\mathbb{P}\left[\|L_{\alpha}\| > \left(6e\left\lceil \frac{1}{3C_{\alpha}}\log(n^{s}/\epsilon)\right\rceil\right)^{\frac{1}{2}C_{\alpha}} \cdot (2D_{\alpha})^{D_{\alpha}}n^{\frac{1}{2}(|V(\alpha)|-s)}\right] < \frac{\epsilon}{n^{|U_{\alpha}\cap V_{\alpha}|}}.$$
 (6.3)

Now we apply the same arguments as Section 6.1 to prove (6.3). Since the arguments overlap significantly, we do not repeat them here. Below, we instead provide a high-level intuition as to why (6.3) is true.

The key principle is that  $U_{\alpha} \cap V_{\alpha}$  can be *effectively* ignored throughout the arguments in Section 6.1. To see this more precisely, first note that in the constraint graph, vertices in  $U_{\alpha} \cap V_{\alpha}$  have only a single copy of themselves. Hence for any edge in  $\alpha$  incident to a vertex  $v \in U_{\alpha} \cap V_{\alpha}$ , its copies in the constraint graph will automatically have the copy of v as a common end. Among the edges in  $\alpha$  incident to a vertex in  $U_{\alpha} \cap V_{\alpha}$ , one can easily conclude that the only type of edges that might affect the value of  $\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha,P}M_{\alpha,P}^{\top})^q\right)\right]$  are the edges between  $U_{\alpha} \cap V_{\alpha}$  and  $W_{\alpha}$ . However, even the copies of these edges do not contribute to  $\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha,P}M_{\alpha,P}^{\top})^q\right)\right]$  because for a constraint

graph C with  $val(C) \neq 0$ , the copies of the endpoint in  $W_{\alpha}$  must be paired up with each other. Thus, the product of the edge variables  $\chi_e$  corresponding to the copies of these edges will be equal to 1.

Consequently, the norm bound one can prove is equal to the result obtained in Section 6.1 applied to the shape  $\alpha'$  which is obtained from  $\alpha$  by removing the intersection  $U_{\alpha} \cap V_{\alpha}$ . To write the result explicitly, (6.1) applied to  $\alpha'$  yields

$$\mathbb{P}\left[\|M_{\alpha'}\| \geq \left(6e\left\lceil\frac{1}{3(|W_{\alpha'}|+s')}\ln(n^{s'}/\epsilon')\right\rceil\right)^{\frac{1}{2}(|W_{\alpha'}|+s')} \cdot (2|V(\alpha')|)^{|V(\alpha')|}n^{\frac{1}{2}(|V(\alpha')|-s')}\right] \leq \epsilon'\,,$$

where s' is the size of a minimum vertex separator between  $U_{\alpha'}$  and  $V_{\alpha'}$ . One can easily verify:

- $s' = s |U_{\alpha} \cap V_{\alpha}|$ ;
- $|W_{\alpha'}| + s' = |W_{\alpha}| + s |U_{\alpha} \cap V_{\alpha}| = C_{\alpha};$
- $|V(\alpha')| = |V(\alpha)| |U_{\alpha} \cap V_{\alpha}| = D_{\alpha}$ ; and
- $\bullet |V(\alpha')| s' = |V(\alpha)| s.$

Consequently, the above bound becomes

$$\mathbb{P}\left[\|M_{\alpha'}\| \ge \left(6e\left\lceil \frac{1}{3C_{\alpha}}\ln(n^{s-|U_{\alpha}\cap V_{\alpha}|}/\epsilon')\right\rceil\right)^{\frac{1}{2}C_{\alpha}} \cdot (2D_{\alpha})^{D_{\alpha}}n^{\frac{1}{2}(|V(\alpha)|-s)}\right] \le \epsilon',$$

which recovers (6.3) by making the substitution  $\epsilon' \leftarrow \frac{\epsilon}{n^{|U_{\alpha} \cap V_{\alpha}|}}$ .

## <span id="page-31-1"></span>6.3 The case with isolated middle vertices: $W_{\rm iso} \neq \emptyset$

Lastly, we extend our proof to the case  $W_{\alpha} \neq \emptyset$ . In particular, we reduce the case with isolated vertices to the case without them via the following proposition:

<span id="page-31-0"></span>**Proposition 6.7.** Given a shape  $\alpha = (U_{\alpha}, V_{\alpha}, W_{\alpha}, E(\alpha))$ , let  $W_{\text{iso}} \subset W_{\alpha}$  be the set of isolated vertices in  $W_{\alpha}$ , and let  $t_{\text{noniso}} := |V(\alpha)| - |W_{\text{iso}}|$ . Let  $\beta$  be the shape obtained from  $\alpha$  by removing the isolated middle vertices, i.e.  $\beta = (U_{\alpha}, V_{\alpha}, W_{\alpha} \setminus W_{\text{iso}}, E(\alpha))$ . Then,

$$M_{\alpha} = (n - t_{\text{noniso}})(n - t_{\text{noniso}} - 1) \cdots (n - |V(\alpha)| + 1) \cdot M_{\beta}$$
.

Consequently, we have  $||M_{\alpha}|| \leq n^{|W_{\text{iso}}|} ||M_{\beta}||$ .

*Proof.* Recall from the definition of graph matrices (Definition 2.16) that

$$M_{\alpha}(A, B) = \sum_{\substack{\sigma: V(\alpha) \to [n]: \\ \sigma \text{ is injective,} \\ \sigma(U_{\alpha}) = A, \ \sigma(V_{\alpha}) = B}} \chi_{\sigma(E(\alpha))}.$$

Now observe that  $\chi_{\sigma(E(\alpha))}$  is equal to  $\chi_{\sigma'(E(\alpha))}$  as long as  $\sigma(x) = \sigma'(x)$  for  $x \in V(\alpha) \setminus W_{iso}$ . Thus, we can collect identical Fourier characters in the above summation. After fixing the values of  $\sigma$  restricted to the subset  $V(\alpha) \setminus W_{iso}$ , there are  $(n - t_{noniso})(n - t_{noniso} - 1) \cdots (n - |V(\alpha)| + 1)$  different

possible assignments for  $\sigma(W_{iso})$ . Since each such assignment results in the same Fourier character, we have that

ave that 
$$M_{\alpha}(A,B) = (n - t_{\text{noniso}})(n - t_{\text{noniso}} - 1) \cdots (n - |V(\alpha)| + 1) \cdot \sum_{\substack{\sigma: V(\alpha) \backslash W_{\text{iso}} \to [n]: \\ \sigma \text{ is injective,} \\ \sigma(U_{\alpha}) = A, \ \sigma(V_{\alpha}) = B}} \chi_{\sigma(E(\alpha))}$$
$$= (n - t_{\text{noniso}})(n - t_{\text{noniso}} - 1) \cdots (n - |V(\alpha)| + 1) \cdot M_{\beta}(A,B).$$

Using Proposition 6.7, it is sufficient to prove Theorem 6.1 for the case where there are no isolated vertices, which we did in the previous subsection.

## <span id="page-32-0"></span>7 Generalized graph matrices

So far, we have considered a restrictive setting where the index monomials are multilinear and the input distribution is a random graph on the ground set [n]. In this section, we will relax these restrictions and come up with the notion of generalized graph matrices. We will then extend the techniques developed in Section 5 to this generalized setting.

### 7.1 Motivation for generalizing graph matrices

We begin by giving several examples to illustrate why generalizing the concept of graph matrices is useful.

**Example 7.1.** Let's say that instead of a random graph, the input is a  $m \times n$  matrix X with random  $\pm 1$  entries. In this case, we represent the entry  $X_{ij}$  of X by an edge between a vertex i and a vertex j. However, here it is important to know which index is the row index and which index is the column index. To handle this, we consider two different types of vertices, row vertices and column vertices. Row vertices take values in [m] while column vertices take values in [n].

<span id="page-32-1"></span>**Example 7.2.** Let's say that the input is an  $n \times n \times n$  tensor T such that

- 1. T is symmetric (i.e.  $\forall i, j, k \in [n], T_{ijk} = T_{ikj} = T_{jik} = T_{jki} = T_{kij} = T_{kji}$ ).
- 2. Any entry of T with a repeated index is 0 (i.e  $\forall i \in [n], T_{iii} = 0$  and  $\forall i, j \in [n], T_{iij} = 0$ ).
- 3. All entries  $T_{ijk}$  where i < j < k are independently chosen to be -1 or 1.

In this case, we need 3 indices to describe each entry of the input rather than 2. To handle this, we represent each entry  $T_{ijk}$  where i, j, k are distinct by a hyperedge between vertices i, j and k.

<span id="page-32-2"></span>**Example 7.3.** Let's say that the input is a symmetric matrix X with random Gaussian off-diagonal entries and zeros on the diagonal. In this case, we need to represent higher degree polynomials of the input entries like  $X_{ij}^2$ . To handle this, we take an orthonormal basis  $h_1, h_2, \ldots$  for our input distribution, decompose each polynomial in terms of this basis, and represent  $h_k(X_{ij})$  by an edge between vertices i and j with label k.

For Gaussian inputs, we take the orthonormal basis to be the normalized Hermite polynomials  $h_1(x) = x$ ,  $h_2(x) = \frac{x^2-1}{\sqrt{2!}}$ ,  $h_3(x) = \frac{x^3-3x}{\sqrt{3!}}$ , etc. To represent  $X_{ij}^2$ , we write  $X_{ij}^2 = \sqrt{2}h_2(X_{ij}) + 1$ ,

which then can be represented as  $\sqrt{2}$  times an edge with label 2 between vertices i and j plus a non-edge (which represents 1).

**Remark 7.4.** In Examples 7.2 and 7.3, we restricted which entries of the matrix or tensor were nonzero so that every input entry was represented by the same kind of edge/hyperedge. If we had nonzero  $T_{iii}$ ,  $T_{iij}$ , and/or  $X_{ii}$  entries, we would need to represent these entries with different kinds of hyperedges.

**Example 7.5.** When analyzing the Sum-of-Squares hierarchy, we need to analyze a moment matrix M which is indexed by monomials p and q. When the variables of p and q are Boolean variables or  $\pm 1$  variables, we can assume that p and q are multilinear. However, we cannot make this assumption in general. For example, we may need to consider the entry  $M_{pq}$  where  $p = x_1^2x_2$  and  $q = x_2^2x_3$ .

To handle this, we define non-multilinear matrix indices where we specify the degree of each element of the matrix index.

Based on these examples, we introduce the following generalizations for graph matrices.

- 1. Different types of vertices to handle different types of indices.
- 2. Hyperedges to handle input entries which are described by more than 2 indices.
- 3. Labeled edges/hyperedges to handle different input distributions.
- 4. Non-multilinear matrix indices.

### <span id="page-33-0"></span>7.2 Generalized definitions

#### 7.2.1 Generalized matrix indices and index shapes

We first generalize the index monomials. We consider the index monomials that (i) are not necessarily multilinear and (ii) consist of variables of multiple types. For instance, we can now have  $x_1^2x_2x_3^4y_1y_2^5z_1^3$  as a index monomial (here there are 3 different types of variables, x, y, z). We assume throughout this section that there are t different types of variables, and for each  $t \in [t]$ , let us denote by  $x_{i;1}, x_{i;2}, x_{i;3}, \cdots$  the variables of type t. Now we generalize the definition of ground set (Definition 2.2) as follows:

**Definition 7.6** (Ground sets). For each i = 1, 2, ..., t, we denote by  $N_i$  the *i*-th ground set for the indices of variables of type *i*. In other words, we consider monomials consisting of variables  $\bigcup_{i=1}^{t} \{x_{i:j}\}_{j \in N_i}$ . Unless stated otherwise, we consider  $N_i = [n_i]$  for  $n_i \in \mathbb{N}$ , i = 1, 2, ..., t.

In order to represent the generalized index monomials, we also need to generalize Definition 2.3. More specifically, since an index monomial is no longer multilinear, it *cannot* be represented by a single matrix index. To cope with this, we decompose a given monomial into pieces so that each piece consists of variables of the same type to the same power. To illustrate, let us consider the following example:

**Example 7.7** (Decomposing monomials according to types and powers). Consider the case t = 3, i.e., there are three types of variables. Let us denote the three different variables by x, y, z for simplicity. Moreover assume that  $N_1 = [5], N_2 = [3], N_3 = [2]$  and consider a monomial  $x_1^4 z_1^8 y_1 x_2^4 y_2 x_3^3 y_3 z_2^4 x_4^4 x_5^3$  Then, one can decompose the monomial according to types and powers as follows:

- 1. Decompose them according to types:  $x_1^4 x_2^4 x_3^3 x_4^4 x_5^3$ ,  $y_1 y_2 y_3$ ,  $z_1^8 z_2^4$ .
- 2. Further decompose them according to powers:  $x_3^3x_5^3$ ,  $x_1^4x_2^4x_4^4$ ,  $y_1y_2y_3$ ,  $z_2^4$ ,  $z_1^8$ .

Having decomposed an index monomial into pieces, one can represent each piece with a tuple. Formally, we consider the following definition about generalized matrix index pieces; again due to a technical reason addressed in Remark 2.5 we adopt tuples over subsets for representations.

<span id="page-34-0"></span>**Definition 7.8** (Generalized matrix index pieces). For a given collection of ground sets  $\{N_i\}$ , we define a generalized matrix index piece  $A = ((a_1, \ldots, a_m), i, p)$  for some  $m \in \mathbb{N}$ , where

- (i)  $i \in [t]$  denotes the type of variables,
- (ii)  $p \in \mathbb{N}$  denotes the power of variables, and
- (iii)  $a_1, \ldots, a_m \in N_i$  are distinct elements representing variable indices.

In other words, the generalized matrix index piece A corresponds to the monomial  $p_A := \prod_{j=1}^m x_{i;a_j}^p$ . In addition, we make the following definitions about generalized matrix index pieces:

- 1. We denote by |A| the size of the generalized matrix index piece, i.e., |A| = m.
- 2. We define V(A) to be the set of vertices  $\{(a_j, i) : j = 1, 2, \dots, m\}$ .
- 3. We say that  $A_1$  and  $A_2$  are disjoint if  $V(A_1) \cap V(A_2) = \emptyset$ .

Let us illustrate generalized matrix index pieces through an example:

**Example 7.9** (Examples of generalized matrix index pieces). Let t = 3, i.e., there are 3 different types of variables, and let  $N_1 = [4]$ ,  $N_2 = [5]$ , and  $N_3 = [3]$ . To simplify notations, let us denote the three types of variables by x, y, and z. For example,  $A_1 = ((1,2,4),1,1)$  is the generalized matrix index piece corresponding to the multi-type monomial  $x_1x_2x_4$ . In this example,  $V(A_1) = \{(1,1),(2,1),(4,1)\}$  and |A| = 3. Next,  $A_2 = ((2,5,3,4),2,3)$  corresponds to  $y_2^3y_3^3y_4^3y_5^3$ . In this example,  $V(A_2) = \{(2,2),(3,2),(4,2),(5,2)\}$  and |A| = 4. Lastly,  $A_3 = ((2,1),3,2)$  corresponds to  $z_1^2z_2^2$ . In this example,  $V(A_2) = \{(1,3),(2,3)\}$  and |A| = 2.

With generalized matrix index pieces, we can generalize Definition 2.3 as follows:

**Definition 7.10** (Generalized matrix indices). For a given collection of ground sets  $\{N_i\}$ , we define a generalized matrix index  $A = \{A_i = ((a_{i;1}, \ldots, a_{i;|A_i|}), t_i, p_i)\}$  to be a set of disjoint generalized matrix index pieces where for all i < j, either (i)  $t_i < t_j$  or (ii)  $t_i = t_j$  and  $p_i < p_j$ . We make the following definitions about generalized matrix indices:

- 1. We associate the monomial  $p_A = \prod_{A_i \in A} p_{A_i}$  with A.
- 2. We define the size |A| to be a t-tuple  $(s_1, s_2, \ldots, s_t)$ , where  $s_i$  is the sum of the sizes of the generalized matrix index pieces whose types are i.
- 3. We define V(A) to be the set of vertices  $\bigcup_{A_i \in A} V(A_i)$ .

Next, we consider generalized index shapes. Paralleling Definition 7.8, we first define generalized index shape pieces:

<span id="page-35-0"></span>**Definition 7.11** (Generalized index shape pieces). For a given collection of ground sets  $\{N_i\}$ , we define a generalized index shape piece to be a tuple of distinct variables  $U = ((u_1, \ldots, u_m), i, p)$  for some  $m \in \mathbb{N}$ , where

- (i)  $i \in [t]$  specifies the type of variables,
- (ii)  $p \in \mathbb{N}$  specifies the power of variables, and
- (iii)  $u_1, \ldots, u_m \in N_i$  are distinct variables.

In addition, we make the following definitions about generalized index shape pieces:

- 1. We denote by |U| the size of the generalized index shape piece, i.e., |U| = m.
- 2. We define V(U) to be the set of vertices  $\{(u_j, i) : j = 1, 2, \dots, m\}$ .
- 3. We say that two generalized index shape pieces  $U_1$  and  $U_2$  are disjoint if  $V(U_1) \cap V(U_2) = \emptyset$ .
- 4. If U and V are two generalized index shape pieces, we say that U = V if U and V have the same type and power and |U| = |V|.

Based on Definition 7.11, we can generalize index shapes as follows:

**Definition 7.12** (Generalized index shapes). We define a generalized index shape  $U = \{U_i = ((u_{i;1}, \ldots, u_{i;|U_i|}), t_i, p_i)\}$  to be a set of generalized index shape pieces such that for all i < j, either (i)  $t_i < t_j$  or (ii)  $t_i = t_j$  and  $p_i < p_j$ . We make the following definitions about generalized index shapes:

- 1. We define the size |U| to be a t-tuple  $(s_1, s_2, \ldots, s_t)$ , where  $s_i$  is the sum of the sizes of the generalized index shape pieces whose types are i.
- 2. We define V(U) to be the set of vertices  $\bigcup_{U_i \in U} V(U_i)$ .
- 3. If  $U = \{U_i\}$  and  $V = \{V_i\}$  are two generalized index shapes, we say that U = V if U and V have the same number of pieces and for all i,  $U_i = V_i$ .

Finally, we make the following definition about the relation between generalized matrix indices and generalized index shapes.

**Definition 7.13.** We say a generalized matrix index  $A = \{A_i\}$  has generalized index shape  $U = \{U_i\}$  if A and U have the same number of pieces and for all i,  $|A_i| = |U_i|$  and  $A_i$  and  $U_i$  have the same type and power. In other words, there is an assignment of values to the unspecified indices of U which results in A.

#### 7.2.2 Generalized input distributions

Next, we generalize the input distribution. Since the matrix indices have multiple types, the generalized input distribution is now over vertices of multiple types. Moreover, we generalize random graphs to random hypergraphs, i.e., some subsets of nodes (not necessarily of size 2) are assigned independent random variables. The distribution of these random variables is denoted by  $\Omega$ , which is not necessarily the  $\{\pm 1\}$  Bernoulli distribution. In order to do Fourier analysis on the input, we need to use an orthonormal basis for  $\Omega$ .

**Definition 7.14** (Orthonormal basis for  $\Omega$ ). Given an input distribution  $\Omega$ , we define the polynomials  $\{h_i\}$  to be the ones found through the Gram-Schmidt process such that

- 1.  $\forall i, E_{\Omega}[h_i^2(x)] = 1$
- 2.  $\forall i \neq j, E_{\Omega}[h_i(x)h_i(x)] = 0$
- 3. For all i, the leading coefficient of  $h_i(x)$  is positive.

If  $\Omega$  has finite support, then we will only have the polynomials  $\{h_i : i \in [k-1]\}$  where k is the size of the support of  $\Omega$ .

<span id="page-36-0"></span>**Example 7.15** (Fourier analysis for the normal distribution). If  $\Omega$  is the normal distribution, then the polynomials  $\{h_i\}$  are the Hermite polynomials with the appropriate normalization so that for all i,  $E_{\Omega}[h_i^2(x)] = 1$ . For example,  $h_0(x) = 1$ ,  $h_1(x) = x$ ,  $h_2(x) = \frac{x^2-1}{\sqrt{2!}}$ ,  $h_3(x) = \frac{x^3-3x}{\sqrt{3!}}$ , and  $h_4(x) = \frac{x^4-6x^2+3}{\sqrt{4!}}$ .

Given this orthonormal basis for  $\Omega$ , we assign a label to each hyperedge:

**Definition 7.16** (Labels of hyperedges). We assign a label  $l_e$  to each hyperedge e to denote which element  $h_{l_e}$  of the orthonormal basis to apply to the random variable associated to e. More formally, if the hyperedge e is assigned a label  $l_e$  then this hyperedge corresponds to  $h_{l_e}(x_e)$  where  $x_e$  is the random variable associated with e.

With these edge labels, we consider the following Fourier characters.

**Definition 7.17** (Fourier characters). Given a multi-set of labeled hyperedges E, we define the Fourier character  $\chi_E$  to be

$$\chi_E = \prod_{e: e \in E} h_{l_e}(x_e) .$$

#### 7.2.3 Generalized ribbons and shapes

Having established the above definitions, we are ready to consider generalized ribbons:

**Definition 7.18** (Generalized ribbons). A generalized ribbon  $R = (A_R, B_R, C_R, E(R))$  consists of two generalized matrix indices  $A_R$  and  $B_R$  (possibly  $V(A_R) \cap V(B_R) \neq \emptyset$ ), an additional set of indices with types  $C_R$  such that  $C_R \cap (V(A_R) \cup V(B_R)) = \emptyset$ , and a set E(R) consisting of labeled subsets from  $V(A_R) \cup V(B_R) \cup C_R$ . We make the following definitions about generalized ribbons:

- 1. (Graphical representation of a generalized ribbon) We identify R with its graphical representation defined as a labelled hypergraph with vertices  $V(R) = V(A_R) \cup V(B_R) \cup C_R$  and labelled hyperedges E(R). Here we regard  $V(A_R)$  and  $V(B_R)$  as distinguished sets, and refer to them as the left and right vertices of R, respectively. We refer to  $C_R$  as the middle vertices of R.
- 2. (Fourier character of a generalized ribbon) We define the Fourier character  $\chi_R$  to be  $\chi_{E(R)}$ .
- 3. (Matrix associated to a generalized ribbon) Given a generalized ribbon R where  $|A_R| = (s_1, s_2, \ldots, s_t)$  and  $|B_R| = (r_1, r_2, \ldots, r_t)$  and a random input X with a random variable  $x_e$

for each hyperedge  $e \in E(R)$ , we define  $M_R$  to be a  $\prod_{i=1}^t \frac{n_i!}{(n_i-s_i)!} \times \prod_{i=1}^t \frac{n_i!}{(n_i-r_i)!}$  matrix such that  $M_R(A_R,B_R) = \chi_R(X)$  and  $M_R(A,B) = 0$  if  $A \neq A_R$  or  $B \neq B_R$ .

We also define generalized shapes as follows:

**Definition 7.19** (Generalized shapes). A generalized shape  $\alpha = (U_{\alpha}, V_{\alpha}, W_{\alpha}, E(\alpha))$  consists of generalized index shapes  $U_{\alpha}$  and  $V_{\alpha}$  (possibly having common variables), an additional set  $W_{\alpha}$  of variables with types distinct from the ones in  $V(U_{\alpha}) \cup V(V_{\alpha})$ , and  $E(\alpha)$  consisting of labeled hyperedges from  $V(U_{\alpha}) \cup V(V_{\alpha}) \cup W_{\alpha}$ .

Furthermore, we identify  $\alpha$  with its graphical representation defined as a labeled hypergraph graph with vertices  $V(\alpha) = V(U_{\alpha}) \cup V(V_{\alpha}) \cup W_{\alpha}$  and labeled hyperedges  $E(\alpha)$ . Here we regard  $V(U_{\alpha})$  and  $V(V_{\alpha})$  as distinguished sets, and refer to them as the left and right vertices of  $\alpha$ , respectively. We refer to  $W_{\alpha}$  as the middle vertices of  $\alpha$ .

There are a few more ingredients required for generalized graph matrices.

**Definition 7.20** (Type-respecting realizations). Given a realization  $\sigma: U \to \cup_i N_i$ , it is said to be type-respecting if for each i, vertices of type i are mapped to the i-th ground set  $N_i$ .

**Definition 7.21** (Realizations of generalized shapes). Given a generalized shape  $\alpha$  and a type-respecting realization  $\sigma: V(\alpha) \to \bigcup_i N_i$ , we define the ribbon  $\sigma(\alpha) := (\sigma(U_\alpha), \sigma(V_\alpha), \sigma(W_\alpha), \sigma(E(\alpha)))$ .

**Definition 7.22** (Shapes of generalized ribbons). Given a generalized shape  $\alpha$  and a generalized ribbon R, we say R has shape  $\alpha$  if there exists a type-respecting realization  $\sigma$  such that  $\sigma(\alpha) = R$ .

With all the definitions above, we are now ready to define generalized graph matrices.

<span id="page-37-0"></span>**Definition 7.23** (Generalized graph matrices). Given a generalized shape  $\alpha$ , the generalized graph matrix  $M_{\alpha}$  is defined as follows: for generalized matrix indices A and B such that  $|A| = |U_{\alpha}|$  and  $|B| = |V_{\alpha}|$ ,

$$M_{\alpha}(A,B) = \sum_{\substack{\sigma \text{ is a type-respecting realization of } \alpha, \\ \sigma(U_{\alpha}) = A, \sigma(V_{\alpha}) = B}} \chi_{\sigma(E(\alpha))}. \tag{7.1}$$

**Remark 7.24.** Paralleling Remark 2.17, an alternative way to define the generalized graph matrix is to consider

<span id="page-37-2"></span><span id="page-37-1"></span>
$$M_{\alpha} = \sum_{R \text{ is a generalized ribbon of shape } \alpha} M_R.$$
 (7.2)

Again, similarly to Remark 2.17, the two definitions (7.1) and (7.2) only differ by a multiplicative constant.

#### 7.3 Generalized techniques

In this section, we generalize the techniques in Section 5 so that they can handle this generalized setting. In particular, we will generalize the vertex partitioning technique as well as constraint graphs.

#### 7.3.1 Generalized vertex partitioning

Paralleling the vertex partition argument in Section 5, we consider an  $\alpha$ -partition of the ground set. Here the main difference is that for each  $i \in [t]$ , we partition the *i*-th ground set according to the vertices of type i in  $\alpha$ . Formally, we make the following definitions about  $\alpha$ -partitions.

**Definition 7.25** ( $\alpha$ -partitions). Given a generalized shape  $\alpha$  and for each  $i \in [t]$ , let  $V_i(\alpha)$  be the set of vertices of type i, and let  $P_i$  be a tuple  $(I_v : v \in V_i(\alpha))$  such that  $\bigcup_{v \in V_i(\alpha)} I_v$  is a partition of  $N_i$ . We define an  $\alpha$ -partition of the ground sets to be a tuple of partitions  $(P_i : i \in [t])$ . We define  $\mathcal{P}_{\alpha}$  to be the set of all possible  $\alpha$ -partitions of the ground set.

Similarly to Proposition 5.2, we can count the number of possible  $\alpha$ -partitions:

<span id="page-38-0"></span>**Proposition 7.26.** 
$$|\mathcal{P}_{\alpha}| = \prod_{i=1}^{t} |V_i(\alpha)|^{|N_i|}$$
.

Given this definition of  $\alpha$ -partitions, the notion of P-respecting map can be analogously defined:

**Definition 7.27.** Given an  $\alpha$ -partition P of the indices, we say that a type-respecting and injective map  $\phi: V(\alpha) \to N$  is P-respecting if  $\forall v \in V(\alpha), \ \phi(v) \in I_v$ .

The following is a direct generalization of Proposition 5.4:

<span id="page-38-1"></span>**Proposition 7.28.** For any type-respecting and injective map  $\phi: V(\alpha) \to N$ , there are exactly  $\prod_{i=1}^{t} |V_i(\alpha)|^{|N_i|-|V_i(\alpha)|} \alpha$ -partitions  $P \in \mathcal{P}_{\alpha}$  such that  $\phi$  is P-respecting.

Having established all of this, we can similarly define  $M_{\alpha,P}$  as follows:

**Definition 7.29.** Given a random input X, We define  $M_{\alpha,P}$  to be the matrix with entries

$$M_{\alpha,P}(A,B) := \sum_{\substack{\phi: V(\alpha) \to N: \phi \text{ is } P\text{-respecting,} \\ \phi(U_{\alpha}) = A, \phi(V_{\alpha}) = B}} \chi_{\phi(E(\alpha))}(X).$$

The following result is an immediate consequence of Propositions 7.26 and 7.28:

<span id="page-38-3"></span>Corollary 7.30 (Decomposition induced by an  $\alpha$ -partition).  $M_{\alpha} = \frac{\prod_{i=1}^{t} |V_{i}(\alpha)|^{|V_{i}(\alpha)|}}{|\mathcal{P}_{\alpha}|} \sum_{P \in \mathcal{P}_{\alpha}} M_{\alpha,P}$ 

## 7.3.2 Generalized constraint graphs

Having defined  $\alpha$ -partitions and  $M_{\alpha,P}$ , the constraint graphs can be defined akin to Section 5.2. Actually, the definitions and discussions in Section 5.2 go through in the exactly same manner except that  $\phi$  is now a type-respecting map from  $H(\alpha, 2q)$  to  $\cup_i N_i$ . Moreover, we can define the notion of P-respecting maps and well-behaved constraint graphs analogously. Therefore, we obtain the following generalization of Corollary 5.13:

<span id="page-38-2"></span>**Proposition 7.31.** For all generalized shapes  $\alpha$  and all  $P \in \mathcal{P}_{\alpha}$ , and all  $q \in \mathbb{N}$ ,

$$\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha,P}M_{\alpha,P}^{\top})^{q}\right)\right] = \sum_{C \in \mathcal{C}_{(\alpha,2\alpha)}: C \text{ is well-behaved}} N_{P}(C)\operatorname{val}(C),$$

where  $N_P(C) := |\{\phi : V(H(\alpha, 2q)) \to N : \phi \text{ is } P\text{-respecting}, \ C(\phi) \equiv C\}|.$ 

As we will soon see in Section 8, the proof of norm bounds for generalized graph matrices will follow by bounding the quantities  $N_P(C)$  and  $\operatorname{val}(C)$ . However, since the constraint graphs now admit different types of vertices, counting  $N_P(C)$  will require some more delicate combinatorial arguments. Moreover, since the input distribution no longer satisfies  $\Omega = \{\pm 1\}$ , we cannot simply assert that  $\operatorname{val}(C) \leq 1$  as before. Bounding  $\operatorname{val}(C)$  under some mild conditions on  $\Omega$  will be the focus of the next subsection.

### <span id="page-39-1"></span>7.4 Handling general input distributions

To come up with a bound on val(C), we first make the following definition about bound functions for a given input distribution.

**Definition 7.32** (Bound function of input distribution). For any input distribution  $\Omega$ , we say  $B_{\Omega}: \mathbb{N} \to \mathbb{R}$  is a bound function of  $\Omega$  if it satisfies:

- 1. It is non-decreasing.
- 2.  $\forall j \in \mathbb{N}, \left| \mathbb{E}_{\Omega}[x^j] \right| \leq B_{\Omega}(j)^j$ .

Note that there could be multiple bound functions for a single input distribution. For a better bound on val(C), it is suggested to take one that takes minimal values. This will be clearer when we state our norm bounds for generalized graph matrices.

Moreover, to upper bound each polynomial in the orthonormal basis  $\{h_i\}$  of  $\Omega$ , we consider the following polynomials:

**Definition 7.33.** Given an input distribution  $\Omega$ , if  $h_k(x) = \sum_{j=0}^k c_{kj} x^j$  is the degree k polynomial in the orthonormal basis for  $\Omega$  then we define  $h_k^+(x)$  to be  $h_k^+(x) = \sum_{j=0}^k |c_{kj}| x^j$ .

With these definitions of bound functions and  $h_k^+(x)$ , we obtain the following upper bounds:

<span id="page-39-0"></span>**Lemma 7.34.** For all  $k, r \in \mathbb{N}$ ,  $\mathbb{E}_{\Omega}[h_k(x)^r] \leq h_k^+(B_{\Omega}(kr))^r$ .

*Proof.* Writing  $h_k(x)^r = \sum_{j=0}^{kr} a_j x^j$  and  $h_k^+(x)^r = \sum_{j=0}^{kr} b_j x^j$ , we can easily deduce that  $|a_j| \leq b_j$  for all  $0 \leq j \leq kr$ . Thus, we have

$$\mathbb{E}_{\Omega}[h_k(x)^r] = \sum_{j=0}^{kr} a_j \mathbb{E}_{\Omega}[x^j] \le \sum_{j=0}^{kr} b_j \left| \mathbb{E}_{\Omega}[x^j] \right| \le \sum_{j=0}^{kr} b_j B_{\Omega}(kr)^j = h_k^+ (B_{\Omega}(kr))^r,$$

where the second inequality follows from the definition of the bound function: for  $0 \le j \le kr$ ,  $\left|\mathbb{E}_{\Omega}[x^j]\right| \le B_{\Omega}(j)^j \le B_{\Omega}(kr)^j$ .

Thanks to the above upper bound, we obtain the following upper bound on val(C):

<span id="page-39-2"></span>Corollary 7.35. For a generalized shape  $\alpha$  with labels  $\{l_e\}_{e \in E(\alpha)}$  of the hyperedges, let  $C \in \mathcal{C}_{(\alpha,2q)}$  be a well-behaved constraint graph. Then, the following holds:

$$\operatorname{val}(C) \le \prod_{e \in E(\alpha)} h_{l_e}^+(B_{\Omega}(2ql_e))^{2q}.$$

Proof. Recall that  $\operatorname{val}(C) = \mathbb{E}_X[\chi_{\phi(E(\alpha,2q))}(X)]$ . The bound is trivial when  $\operatorname{val}(C) = 0$ , so consider the case where  $\operatorname{val}(C) \neq 0$ . Then, each hyperedge in the multi-set  $\phi(E(\alpha,2q))$  appears an even number of times. Moreover, since C is well-behaved, two hyperedges in  $E(\alpha,2q)$  correspond to the same hyperedge under the map  $\phi$  only if they are copies to each other. Hence, due to independence between hyperedge variables, the expectation value becomes  $\prod_{e \in E(\alpha)} \mathbb{E}_X[\chi_{\phi(C_e)}(X)]$ , where  $C_e \subset H(\alpha,2q)$  is the subset consisting of 2q copies of e.

Fix a hyperedge  $e \in E(\alpha)$ . Let  $r_1, \ldots, r_p$  be the multiplicaties of hyperedges appearing in the multi-set  $\phi(C_e)$ , i.e., 2q elements of  $\phi(C_e)$  can be partitioned into p subsets so that each subset consists of the same hyperedge, and different subsets contain different elements. Recall that since  $val(C) \neq 0$ , each  $r_i$  is even for  $i = 1, 2, \ldots, p$ . Then, we have

$$\mathbb{E}_{X}[\chi_{\phi(C_{e})}(X)] = \prod_{i=1}^{p} \mathbb{E}_{X}[h_{l_{e}}(x)_{i}^{r}] \leq \prod_{i=1}^{p} h_{l_{e}}^{+}(B_{\Omega}(l_{e}r_{i}))^{r_{i}} \leq \prod_{i=1}^{p} h_{l_{e}}^{+}(B_{\Omega}(2ql_{e}))^{r_{i}} = h_{l_{e}}^{+}(B_{\Omega}(2ql_{e}))^{2q},$$

where the first inequality is due to Lemma 7.34, the second inequality is due to the facts that  $B_{\Omega}(\cdot)$  is increasing and  $r_i \leq 2q \ \forall i = 1, ..., p$ , and the last equality is due to  $\sum_{i=1}^{p} r_i = 2q$ .

Taking a product over all  $e \in E(\alpha)$ , we get

$$\operatorname{val}(C) = \prod_{e \in E(\alpha)} \mathbb{E}[\chi_{\phi(C_e)}(X)] \le \prod_{e \in E(\alpha)} h_{l_e}^+(B_{\Omega}(2ql_e))^{2q},$$

<span id="page-40-0"></span>as desired.

## 8 Norm bounds on generalized graph matrices

In this section, we state and prove norm bounds for generalized graph matrices. Recall that in the case of single-type vertex graph matrices (Section 2), the norm bound depends on the minimal size of a vertex separator of U and V of  $\alpha$ . In the general case of multiple types, a similar story goes through: viewing the shape  $\alpha$  as some type of graph with weighted vertices, it turns out that the combinatorial quantity that captures the norm bound is the weight of the *minimum weight seperator* between U and V. To formalize this, we make the following definitions about weights and minimum weight separators of shapes:

**Definition 8.1** (Weights in shapes and constraint graphs). Let  $n = \max_{i \in [t]} |N_i|$ ,  $\alpha = (U_\alpha, V_\alpha, W_\alpha, E(\alpha))$  be a generalized shape, and  $C \in \mathcal{C}_{(\alpha,2q)}$  be a well-behaved constraint graph. We make the following definitions about weights of vertices in  $\alpha$  or C:

- 1. For each vertex v in  $\alpha$  (or in C), we define the weight w(v) to be  $\log_n |N_i|$ , where i is the type of the vertex v (or the type of the original vertex).
- 2. For a subset S of  $V(\alpha)$  (or V(C)), we define w(S) to be  $\sum_{v \in S} w(v)$ .
- 3. For each constraint edge e in  $E(\alpha)$  (or in E(C)), we define the weight w(e) to be the weight of either end of e. (Note that this is well-defined since C is well-behaved.)
- 4. For a subset of constraint edges D of  $V(\alpha)$  (or V(C)), we define w(D) to be  $\sum_{e \in D} w(e)$ .

**Definition 8.2** (Paths in generalized shapes). Let  $\alpha = (U_{\alpha}, V_{\alpha}, W_{\alpha}, E(\alpha))$  be a generalized shape. We say a sequence of vertices  $v_0, v_1, \dots, v_{\ell}$  is a path from  $U_{\alpha}$  to  $V_{\alpha}$  if it satisfies the following:

- 1.  $v_0 \in U_\alpha$  and  $v_\ell \in V_\alpha$ .
- 2. For each  $i = 0, 1, 2, \dots, \ell 1$ ,  $v_i$  and  $v_i + 1$  are contained in some hyperedge of  $\alpha$ .

**Definition 8.3** (Minimum weight separators). Let  $\alpha = (U_{\alpha}, V_{\alpha}, W_{\alpha}, E(\alpha))$  be a generalized shape. We define a minimum weight separator  $S_{\min}$  to be a subset of vertices that satisfies the followings:

- 1.  $S_{\min}$  separates  $U_{\alpha}$  from  $V_{\alpha}$ . In other words, each path from  $U_{\alpha}$  to  $V_{\alpha}$  intersects  $S_{\min}$ .
- 2. For any subset S that separates  $U_{\alpha}$  from  $V_{\alpha}$ , we have  $w(S_{\min}) \leq w(S)$ .

With the above definitions, we are now ready to state our norm bounds for generalized graph matrices. We first state and prove the most general form of the norm bounds which can handle any input distributions. Later, we will see how the norm bounds can be simplified for common input distributions such as the Bernoulli distribution and the normal distribution.

<span id="page-41-0"></span>**Theorem 8.4** (Bounds on generalized graph matrices). For a given generalized shape  $\alpha = (U_{\alpha}, V_{\alpha}, W_{\alpha}, E(\alpha))$ , let  $S_{\min}$  be a minimum weight vertex separator between  $U_{\alpha}$  and  $V_{\alpha}$ , and let  $W_{iso}$  be the set of isolated vertices in  $W_{\alpha}$ . Further, for each  $i \in [t]$ , let  $m_i$  be the number of vertices of type i excluding those in  $U_{\alpha} \cap V_{\alpha}$ . Adopting notations from Section 7.2 and 7.4, the following norm bound holds with probability at least  $1 - \epsilon$ :

$$||M_{\alpha}|| \leq 2 \left( \prod_{i=1}^{t} m_{i}^{m_{i}} \right) \cdot n^{\frac{w(V(\alpha)) - w(S_{\min}) + w(W_{iso})}{2}} \cdot$$

$$\min_{q \geq 3} \left\{ (2q)^{|V(\alpha) \setminus (U_{\alpha} \cap V_{\alpha})|} \left( \prod_{e \in E(\alpha)} h_{l_{e}}^{+}(B_{\Omega}(2ql_{e})) \right) \left( \frac{n^{w(S_{\min})}}{\epsilon} \right)^{\frac{1}{2q}} \right\}.$$

Remark 8.5. As discussed in the introduction, Theorem 8.4 can be used to give alternative proofs of several technical lemmas in the literature [BBH<sup>+</sup>12, HSSS16, GM15]. Moreover, our proofs based on graph matrices are mechanical, whereas the original analyses often required clever arguments. For details, see Section 9.

Note that the current form of Theorem 8.4 is not user-friendly since the bound is written as the minimum over  $q \geq 3$ . Below, we write the norm bound for  $q = 3 \left\lceil \frac{\log \left(n^{w(S_{\min})}/\epsilon\right)}{3|V(\alpha)\setminus (U_{\alpha}\cap V_{\alpha})|}\right\rceil$ , which will turn out to be a nearly optimal choice for many cases. In the subsequent subsections, we will further tune the choice of q for specific distributions.

Corollary 8.6 (User-friendly version of Theorem 8.4). Under the setting of Theorem 8.4, the following probabilistic upper bound holds: with probability at least  $1 - \epsilon$ ,

$$||M_{\alpha}|| \leq 2 \left( \prod_{i=1}^{t} m_i^{m_i} \right) \cdot \left( \prod_{e \in E(\alpha)} h_{l_e}^+(B_{\Omega}(2ql_e)) \right) (eq)^{|V(\alpha) \setminus (U_{\alpha} \cap V_{\alpha})|} n^{\frac{w(\alpha) - w(S_{\min}) + w(W_{iso})}{2}},$$

where

$$q = 3 \left\lceil \frac{\log \left( n^{w(S_{\min})} / \epsilon \right)}{3 |V(\alpha) \setminus (U_{\alpha} \cap V_{\alpha})|} \right\rceil.$$

#### 8.1 Proof of Theorem 8.4

We first note that the arguments in Section 6.2 and 6.3 work similarly here. Similar to Proposition 6.7, each isolated vertex v gives a multiplicative factor of at most  $n^{w(v)}$ , so it is sufficient to consider the case where there are no isolated vertices. When  $U_{\alpha} \cap V_{\alpha}$  is non-empty, we can still partition  $M_{\alpha}$  into blocks based on the values of the vertices in  $U_{\alpha} \cap V_{\alpha}$  and analyze each block separately (see Section 6.2). To handle hyperedges e with vertices in  $U_{\alpha} \cap V_{\alpha}$ , we can simply delete these vertices from e (viewing e as a hyperedge on its remaining vertices) because in each block of  $M_{\alpha}$ , vertices in  $U_{\alpha} \cap V_{\alpha}$  are fixed. Thus, it suffices to prove Theorem 8.4 for the case where  $U_{\alpha} \cap V_{\alpha} = \emptyset$  and  $W_{\text{iso}} = \emptyset$ . Hence, we assume throughout the proof that  $U_{\alpha} \cap V_{\alpha} = \emptyset$  and  $W_{\text{iso}} = \emptyset$ .

Following the previous proofs, the main step of the proof is to prove upper bounds on the trace power terms. Akin to Section 6, Theorem 8.4 will then be an immediate consequence of the vertex partitioning lemma (Lemma 5.14).

<span id="page-42-0"></span>**Lemma 8.7.** Let  $S_{\min}$  be a minimum weight vertex separator between  $U_{\alpha}$  and  $V_{\alpha}$ . Then, for all  $P \in \mathcal{P}_{\alpha}$  and  $q \in \mathbb{N}$ ,

$$\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha,P}M_{\alpha,P}^{\top})^{q}\right)\right] \leq \left(\prod_{e \in E(\alpha)} h_{l_{e}}^{+}(B_{\Omega}(2ql_{e}))^{2q}\right) (2q)^{2q|V(\alpha)|} n^{q(w(\alpha)-w(S_{\min}))+w(S_{\min})}.$$

Proof of Lemma 8.7. Recall from Proposition 7.31 that

$$\mathbb{E}\left[\operatorname{Tr}\left((M_{\alpha,P}M_{\alpha,P}^{\top})^q\right)\right] = \sum_{C \in \mathcal{C}_{(\alpha,2q)}: C \text{ is well-behaved}} N_P(C) \operatorname{val}(C) \,.$$

By Corollary 7.35, for any well-behaved constraint graph  $C \in \mathcal{C}_{(\alpha,2q)}$ ,

$$val(C) \le \prod_{e \in E(\alpha)} h_{l_e}^+ (B_{\Omega}(2ql_e))^{2q}$$

Now, let us upper bound  $N_P(C)$ . First, we generalize Proposition 3.11 to cover the case with vertices of multiple types:

**Proposition 8.8.** Let  $C \in \mathcal{C}_{(\alpha,2q)}$  be a well-behaved constraint graph. Then, for  $n = \max_{i \in [t]} |N_i|$ , we have  $N_P(C) \leq n^{w(V(C))-w(E(C))}$ .

Proof. Observe that choosing a type-respecting, P-respecting and injective map  $\phi: V(\alpha, 2q) \to N$  with constraint graph C is equivalent to choosing the distinct indices of  $\phi(V(\alpha, 2q))$ . For each vertex  $v \in V(\alpha)$ , let  $C_v$  be the subset of C that consists of the copies of v, and let  $E_v$  be the set of constraint edges between  $C_v$ . Note that  $E(C) = \bigcup_{v \in V(\alpha)} E_v$  due to well-behavedness of C.

Then, it is straightforward to see that the number of different choices for  $\phi(C_v)$  is at most  $|N_i|^{|C_v|-|E_v|} = n^{w(C_v)-w(E_v)}$ , where i is the type of v. Taking a product of these inequalities for all  $v \in V(\alpha)$ , we obtain the result.

Thus, Lemma 8.7 follows directly from the following two statements:

- 1. For any well-behaved  $C \in \mathcal{C}_{(\alpha,2q)}$  such that  $\operatorname{val}(C) \neq 0$ , the total weight of the constraint edges is at least  $q \cdot w(W_{\alpha}) + (q-1) \cdot w(S_{\min})$ .
- 2. There are at most  $(2q)^{2q|V(\alpha)|}$  well-behaved constraint graphs  $C \in \mathcal{C}_{(\alpha,2q)}$ .

Now we prove the two statements. We begin with the second statement.

<span id="page-43-2"></span>**Lemma 8.9.** There are at most  $(2q)^{2q|V(\alpha)|}$  well behaved constraint graphs  $C \in \mathcal{C}_{(\alpha,2q)}$ .

*Proof.* To specify a constraint graph, it is sufficient to take each  $v \in V(\alpha, 2q)$  and specify whether v is equal to a later vertex and if so, what is the next vertex  $w \in V(\alpha, 2q)$  such that v = w. Since  $|V(\alpha, 2q)| \leq 2q|V(\alpha)|$  and there are at most 2q possibilities for each vertex (2q-1) possible vertices w and the possibility that v is not equal to a later vertex), the result follows.

Remark 8.10. A careful reader might notice that the proof of the above lemma is based on a much cruder counting than those appearing in the proof of Lemmas 4.5 and 6.6. Note that the counting arguments in the proof of Lemmas 4.5 and 6.6 do not readily carry over to this case due to the presence of weights in the generalized constraint graph. It would be interesting to investigate whether we can do a better counting and come up with a better bound. On the other hand, for the purpose of our norm bounds, this slack only results in an additional poly-logarithmic factor in the norm bounds.

We now prove the first statement. The proof bears some resemblances to that of Lemma 6.5. However, more sophisticated arguments are needed as we are in the weighted case. We remark that there is an alternative proof to this statement which we present in Appendix B.

<span id="page-43-0"></span>**Lemma 8.11.** For any well-behaved  $C \in \mathcal{C}_{(\alpha,2q)}$  such that  $\operatorname{val}(C) \neq 0$ , the total weight of the constraint edges is at least  $q \cdot w(W_{\alpha}) + (q-1) \cdot w(S_{\min})$ .

*Proof.* First, note that in the constraint graph, every vertex that is a copy of a vertex in  $W_{\alpha}$  must be incident to at least one constraint edge as we have  $\operatorname{val}(C) = 0$  otherwise. Since there are 2q copies of  $W_{\alpha}$ , such constraint edges give a total weight of  $\frac{2q \cdot w(W_{\alpha})}{2} = q \cdot w(W_{\alpha})$ . Thus, to prove Lemma 8.11, we must show that there must be "additional" constraint edges with total weight at least  $(q-1) \cdot w(S_{\min})$ .

For each vertex v in the shape  $\alpha$ , let  $n_v$  be the number of additional constraint edges between the copies of v. Note that  $0 \le n_v \le q-1$  for any  $v \in V(\alpha)$  and also,  $\sum_{v \in V(\alpha)} n_v$  is equal to the total number of constraint edges due to C being well-behaved. Hence, the Lemma 8.11 statement can be rephrased as

<span id="page-43-1"></span>
$$\sum_{v \in V(\alpha)} w(v) n_v \ge (q-1) \cdot w(S_{\min}). \tag{8.1}$$

Now consider any path P in  $\alpha$  from  $U_{\alpha}$  to  $V_{\alpha}$  whose vertices lie in  $W_{\alpha}$  except for the endpoints. Then we can repeat the argument from the proof of Lemma 6.5 to show  $\sum_{v \in P} n_v \ge q - 1$ : Let l be the length of P. Consider the cycle T which consists of the 2q copies of P in the constraint graph. Then, T has length 2ql. Applying Lemma 4.4 to T, we conclude that there must be at least ql-1 constraint edges within T. However, not all of them are "additional" constraint edges that we mentioned earlier. As we noted above, each vertex that is a copy of a vertex in  $W_{\alpha}$  must be incident to a constraint edge. Therefore, in terms of the number of "additional" constraint edges, there are ql-1-q(l-1)=q-1 of them.

In order to show (8.1), we formulate an integer programming problem where we minimize  $\sum_{v \in V(\alpha)} w(v) n_v$  subject to the constraints that  $n_v \in \{0, 1, \dots, q-1\}$  and  $\sum_{v \in P} n_v \ge q-1$  for any path from  $U_\alpha$  to  $V_\alpha$ . Then it suffices to show that the objective value of this integer programming problem is lower bounded by  $(q-1) \cdot w(S_{\min})$ . To simplify our consideration, define  $x_v := n_v/(q-1)$  and relax the constraints  $x_v \in \{0, \frac{1}{q-1}, \dots, 1\}$  to  $x_v \in [0, 1]$ . The resulting linear program is

<span id="page-44-1"></span>
$$\min_{x_v \in [0,1]} \left\{ \sum_{v \in V(\alpha)} w(v) x_v : \sum_{v \in P} x_v \ge 1 \text{ for any path from } U_\alpha \text{ and } V_\alpha \right\}.$$
(8.2)

Now it suffices to show that the objective value of the above linear program is lower bounded by  $w(S_{\min})$ .

**Proposition 8.12.** There is an integral optimal solution to the above linear program.

*Proof.* Let  $\{x_v^*\}$  be an optimal solution to the program. We will show that there is an integral solution whose objective value is less than or equal to that of  $\{x_v^*\}$ . For any path, let us define the weight of the path to be the sum of the weights of vertices along the path. For each vertex v in  $\alpha$ , let d(v) be the minimum weight among the paths from  $U_\alpha$  to v. For instance,  $d(u) = x_u^*$  for any  $u \in U_\alpha$ .

<span id="page-44-0"></span>Claim 8.13. For each  $v \in V_{\alpha}$ , d(v) = 1.

Proof of Claim 8.13. Due to the fact that  $\{x_v^*\}$  satisfies the constraint, we have  $d(v) \geq 1$  for any  $v \in V_{\alpha}$ . Now suppose to the contrary that there is a vertex  $w \in V_{\alpha}$  such that d(w) > 1, say  $d(w) = 1 + \epsilon$  for some constant  $\epsilon > 0$ . Then, there exists a path P from  $u \in U_{\alpha}$  to w with weight  $1 + \epsilon$ . Let w' be the last vertex on P with nonzero  $x^*$ -value, i.e.,  $x_{w'}^* > 0$ . Then, it should be the case that  $d(w') = 1 + \epsilon$ . Note that slightly decreasing  $x_{w'}^*$  does not conflict with any constraints from the program; the only case when it could possibly affect is when w' was on a path with weight exactly equal to 1, which contradicts the fact that  $d(w') = 1 + \epsilon$ . Hence, one can slightly decrease the objective value by decreasing  $x_{w'}^*$ , which contradicts the optimality of  $\{x_v^*\}$ .

Now, for each  $t \in [0,1]$ , let  $S_t := \{u : t \in [d(u) - x_u^*, d(u)]\}$ . Note that  $S_t$  is a vertex separator between  $U_{\alpha}$  and  $V_{\alpha}$  for each  $t \in [0,1]$ . Indeed, for any path P, let w be the first vertex along the path satisfying  $d(w) \geq t$  as we read it from  $U_{\alpha}$  to  $V_{\alpha}$ . If it is the starting vertex of P in  $U_{\alpha}$ , then  $t \in [0, d(w)]$ , which implies  $w \in S_t$ . Otherwise, let w' be the vertex right before w on P. Then,  $d(w') \geq d(w) - x_w^*$ , otherwise there is a path to w with weight smaller than d(w). Since d(w') < t by definition, we have  $d(w) - x_w^* \leq d(w') < t \leq d(w)$ , again implying that  $w \in S_t$ .

Hence, letting  $x_v^{(t)} := \mathbb{I}_{\{v \in S_t\}}$ , we conclude that  $\{x_v^{(t)}\}$  is a feasible solution for each  $t \in [0,1]$ . Consider a uniform random variable T in [0,1]. By the construction, we have  $\mathbb{P}(x_v^{(T)} = 1) = x_v^*$ , which implies  $\mathbb{E}_{t \sim T} \left[ \sum_{v \in V(\alpha)} w(v) x_v^{(t)} \right] = \sum_{v \in V(\alpha)} w(v) \mathbb{P}(x_v^{(T)} = 1) = \sum_{v \in V(\alpha)} w(v) x_v^*$ . Therefore,

there must exist  $t \in [0,1]$  such that the objective value of  $\{x_v^{(t)}\}$  is at least that of  $\{x_v^*\}$ , implying the existence of an integral optimal solution.

Now note that for any integral feasible solution  $\{x_v\}$ , the set  $\{v \in V(\alpha) : x_v = 1\}$  is a separator between  $U_{\alpha}$  and  $V_{\alpha}$ . This is because any path from  $U_{\alpha}$  to  $V_{\alpha}$  must intersect the set due to the constraint. Therefore, the objective value of the linear program (8.2) is lower bounded by  $w(S_{\min})$ , which completes the proof of Lemma 8.11.

Since the two statements (Lemma 8.9 and 8.11) are proved, Lemma 8.7 follows.

Having established Lemma 8.7, Theorem 8.4 follows from the vertex partitioning lemma (Lemma 5.14) together with Corollary 7.30: more precisely, we apply the vertex partitioning lemma (Lemma 5.14) with  $M \leftarrow \frac{1}{\prod_{i=1}^{t} |V_i(\alpha)|^{|V_i(\alpha)|}} M_{\alpha}$ ,  $\{M_i\} \leftarrow \{M_{\alpha,P}\}$ , and

$$B(2q) \leftarrow \left(\prod_{e \in E(\alpha)} h_{l_e}^+(B_{\Omega}(2ql_e))^{2q}\right) (2q)^{2q|V(\alpha)|} n^{q(w(\alpha)-w(S_{\min}))+w(S_{\min})}.$$

This completes the proof of Theorem 8.4.

### 8.2 Explicit bounds for special cases

We now give more explicit and user-friendly bounds for two common input distributions: (i) the  $\pm 1$  Bernoulli distribution and (ii) the normal distribution.

#### 8.2.1 The $\pm 1$ Bernoulli distribution case

For the  $\pm 1$  Bernoulli distributions, it can be easily verified that  $B_{\Omega} = 1$ . Moreover, since the support is of size 2, we have only two elements  $h_0$  and  $h_1$  in the orthonormal basis. Here, one can easily check that  $h_1^+(1) = 1$ . Using these explicit calculations of the input distribution related quantities, one can state a refined version of Theorem 8.4 as follows.

<span id="page-45-0"></span>Corollary 8.14 (Refined bounds for Bernoulli distributions). Under the setting of Theorem 8.4, assume further that the input distribution  $\Omega$  takes value between +1 and -1, i.e. it is a  $\pm 1$ -Bernoulli distribution. Then, the following probabilistic upper bound holds with probability at least  $1 - \epsilon$ :

$$||M_{\alpha}|| \leq 2 \left( \prod_{i=1}^{t} m_i^{m_i} \right) \cdot \left( 6e \left\lceil \frac{\log(\frac{n^{w(S_{\min})}}{\epsilon})}{6|V_{\alpha} \setminus (U_{\alpha} \cap V_{\alpha})|} \right\rceil \right)^{|V_{\alpha} \setminus (U_{\alpha} \cap V_{\alpha})|} n^{\frac{w(V(\alpha)) - w(S_{\min}) + w(W_{iso})}{2}}.$$

*Proof.* Due to the above observations that  $B_{\Omega} = 1$  and  $h_1^+(1) = 1$ , the term we need to minimize over  $q \geq 3$  is equal to

$$(2q)^{|V_{\alpha}\setminus (U_{\alpha}\cap V_{\alpha})|} \left(\frac{n^{w(S_{\min})}}{\epsilon}\right)^{\frac{1}{2q}}.$$

Taking the natural logarithm of the above gives  $|V_{\alpha} \setminus (U_{\alpha} \cap V_{\alpha})| \cdot \log(2q) + \frac{1}{2q} \cdot \log(\frac{n^{w(S_{\min})}}{\epsilon})$ , which after taking the derivative with respect to q becomes  $|V_{\alpha} \setminus (U_{\alpha} \cap V_{\alpha})| \frac{1}{q} - \frac{1}{2q^2} \cdot \log(\frac{n^{w(S_{\min})}}{\epsilon})$ . This

derivative is equal to 0 when  $q = \frac{\log(\frac{n^w(S_{\min})}{2|V_{\alpha}\setminus(U_{\alpha}\cap V_{\alpha})|})}{\frac{\epsilon}{2|V_{\alpha}\setminus(U_{\alpha}\cap V_{\alpha})|}}$ . This suggests that we take  $q = 3\left\lceil\frac{\log(\frac{n^w(S_{\min})}{\epsilon})}{6|V_{\alpha}\setminus(U_{\alpha}\cap V_{\alpha})|}\right\rceil \geq 3$  (again the extra multiplication by 3 is for ensuring  $q \geq 3$ ), which gives Corollary 8.14.

## 8.2.2 The normal distribution case

Again, to come up with a refined bound for normal distributions, we need to first compute  $B_{\Omega}$  and  $h_k^+$  for  $\Omega = N(0,1)$ . The following lemma characterizes these quantities:

<span id="page-46-0"></span>**Lemma 8.15.** If  $\Omega = N(0,1)$  is the normal distribution then we can take  $B_{\Omega}(j) = \sqrt{j}$  and we have that for all  $k \in \mathbb{N}$  and all  $x \in \mathbb{R}$ ,  $h_k^+(x) \leq \frac{1}{\sqrt{k!}}(x^2 + k)^{\frac{k}{2}} \leq \left(\frac{e}{k}(x^2 + k)\right)^{\frac{k}{2}}$ .

*Proof.* For the first part, recall that  $E_{\Omega}[x^j] = \frac{(2j)!}{j!2^j} = \prod_{i=0}^{\frac{j}{2}-1} (2i+1)$  if j is even and  $E_{\Omega}[x^j] = 0$  if j is odd. Thus, for all  $j \in \mathbb{N}$ ,  $|E_{\Omega}[x^j]| \leq j^{\frac{j}{2}} = (\sqrt{j})^j$ .

For the second part, recall that the orthonormal basis for  $\Omega = N(0,1)$  is

$$h_k(x) = \frac{1}{\sqrt{k!}} \sum_{i=0}^{\lfloor \frac{k}{2} \rfloor} (-1)^j \frac{k!}{(k-2j)!(2j)!} \cdot \frac{(2j)!}{j!2^j} x^{k-2j}.$$

Thus,

$$h_k^+(x) = \frac{1}{\sqrt{k!}} \sum_{j=0}^{\lfloor \frac{k}{2} \rfloor} \frac{k!}{(k-2j)!j!2^j} x^{k-2j}$$

$$\leq \frac{1}{\sqrt{k!}} \sum_{j=0}^{\lfloor \frac{k}{2} \rfloor} \frac{(\lfloor \frac{k}{2} \rfloor)!}{(\lfloor \frac{k}{2} \rfloor - j)!j!} k^j (x^2)^{\frac{k}{2} - j}$$

$$= \frac{1}{\sqrt{k!}} (x^2 + k)^{\lfloor \frac{k}{2} \rfloor} (x^2)^{\frac{k}{2} - \lfloor \frac{k}{2} \rfloor} \leq \frac{1}{\sqrt{k!}} (x^2 + k)^{\frac{k}{2}}.$$

Using Lemma 8.15, we can refine Theorem 8.4 as follows:

<span id="page-46-1"></span>Corollary 8.16 (Refined bounds for normal distributions). Under the setting of Theorem 8.4, assume further that the input distribution  $\Omega$  is a normal distribution (Gaussian distribution). Let  $l(\alpha) := \sum_{e \in E(\alpha)} l_e$ . Then, the following probabilistic upper bound holds with probability at least  $1 - \epsilon$ :

$$||M_{\alpha}|| \leq 2 \left( \prod_{i=1}^{t} m_{i}^{m_{i}} \right) \cdot n^{\frac{w(V(\alpha)) - w(S_{\min}) + w(W_{iso})}{2}} \cdot \left( 6e \left[ \frac{\log(\frac{n^{w(S_{\min})}}{\epsilon})}{6(|V(\alpha) \setminus (U_{\alpha} \cap V_{\alpha})| + l(\alpha))} \right] \right)^{l(\alpha) + |V(\alpha) \setminus (U_{\alpha} \cap V_{\alpha})|}$$

*Proof.* By Lemma 8.15, we then have the following for each k:

$$h_k^+(B_{\Omega}(2qk)) \le \left(\frac{e}{k}(B_{\Omega}(2qk)^2 + k)\right)^{k/2}$$
$$= \left(\frac{e}{k}(2qk + k)\right)^{k/2}$$
$$= e^{k/2}(2q + 1)^{k/2}.$$

Plugging this into Theorem 8.4, the term we need to minimize over q becomes (using the notation  $l(\alpha) := \sum_{e \in E(\alpha)} l_e$ ):

$$(2q)^{|V(\alpha)\setminus(U_{\alpha}\cap V_{\alpha})|} \left( \prod_{e\in E(\alpha)} e^{l_e/2} (2q+1)^{l_e/2} \right) \left( \frac{n^{w(S_{\min})}}{\epsilon} \right)^{\frac{1}{2q}}$$
$$= (2q)^{|V(\alpha)\setminus(U_{\alpha}\cap V_{\alpha})|} e^{l(\alpha)/2} (2q+1)^{l(\alpha)/2} \left( \frac{n^{w(S_{\min})}}{\epsilon} \right)^{\frac{1}{2q}}.$$

Using the elementary inequality that  $x + 1 \le x^2$  for  $x \ge 2$ , the above term then becomes:

$$(2q)^{l(\alpha)+|V(\alpha)\setminus (U_{\alpha}\cap V_{\alpha})|}e^{l(\alpha)/2}\left(\frac{n^{w(S_{\min})}}{\epsilon}\right)^{\frac{1}{2q}}.$$

Now choosing  $q = 3 \left\lceil \frac{\log(\frac{n^{w(S_{\min})}}{\epsilon})}{\frac{\epsilon}{6(|V(\alpha)\setminus(U_{\alpha}\cap V_{\alpha})|+l(\alpha))}} \right\rceil \ge 3$  (again the extra multiplication by 3 is for ensuring  $q \ge 3$ ), we recover Corollary 8.16.

# <span id="page-47-0"></span>9 Applications of graph matrix norm bounds

It was already shown in prior works [MPW15, DM15, HKP15, RS15, BHK<sup>+</sup>19, GJJ<sup>+</sup>20] that graph matrices are very useful in proving lower bounds on the Sum-of-Squares hierarchy. In this section, we describe other applications of graph matrices: it turns out one can also capture various *upper bound* analyses for the Sum-of-Squares hierarchy and other spectral algorithms with generalized graph matrices. Here we highlight that our proofs based on graph matrices are *mechanical*, whereas the original analyses often required clever arguments.

## 9.1 Warm-up: How can graph matrices be applied?

In many prior works on the sum of squares hierarchy and other spectral algorithms [BBH<sup>+</sup>12, HSSS16, GM15, BM16, PS17, RRS17], the main step of the analysis was showing some upper bounds on the maximum of a homogeneous polynomial over the unit sphere, an important theoretical question of independent interest extensively studied in [BGL17, BGG<sup>+</sup>17]. To recover such upper bounds using graph matrices, our approach will hinge upon matrix representations of homogeneous polynomials:

**Definition 9.1.** For a degree d (assume d is even) homogeneous polynomial f on n variables  $x_1, \ldots, x_n$ , we say a  $n^{d/2} \times n^{d/2}$  matrix M is a matrix representation of f if  $f(x_1, \ldots, x_n) = 0$ 

 $(x^{\otimes d/2})^{\top} M x^{\otimes d/2}$  for all  $x \in \mathbb{R}^n$ . Moreover, we say a matrix representation M is a graph matrix representation if M is, in addition, a graph matrix. If M is a graph matrix corresponding to a shape  $\alpha$ , i.e.,  $M = M_{\alpha}$ , then we say  $\alpha$  is a shape representation of f.

For an even number d, let f be a degree-d homogeneous polynomial that we want to prove an upper bound for. Assuming that f has a graph matrix representation, one can easily find an upper bound on  $\max_{\|x\|=1} f(x)$ . In particular, if  $\alpha$  is a shape representing f, we have  $f(x) = (x^{\otimes d/2})^{\top} M_{\alpha} x^{\otimes d/2} \leq \|M_{\alpha}\|$ , which implies  $\max_{\|x\|=1} f(x) \leq \|M_{\alpha}\|$ . We can then invoke our main theorems to upper bound  $\|M_{\alpha}\|$ . Therefore, to upper bound f, one needs to find a shape representation of f. We illustrate how one can find a shape representation through the following example. (This example will reappear in Sec. 9.4.) One remark on notation is that we will use  $u_1, u_2, \ldots$  to denote the vertices in  $U, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote the vertices in  $V, v_1, v_2, \ldots$  to denote

<span id="page-48-0"></span>**Example 9.2** (An example adapted from [HSSS16]). For integers n, m such that  $n \leq m$ , let  $\{b_{i,j}\}_{i\in[n], j\in[m]}$  be random variables drawn i.i.d. from  $\mathcal{N}(0,1)$ . Let  $f_{Ex1}(x_1,\ldots,x_n)$  be a degree-2 homogeneous polynomial defined as

$$f_{Ex1}(x_1,\ldots,x_n) := \sum_{\substack{j_1 \neq j_2 \in [n]}} x_{j_1} x_{j_2} \left[ \sum_{\substack{i \in [m], j_3 \in [n] \\ j_3 \notin \{j_1,j_2\}}} b_{i,j_1} b_{i,j_2} \left( b_{i,j_3}^2 - 1 \right) \right].$$

Let us find a shape  $\alpha_{\text{Ex}1}$  that represents  $f_{\text{Ex}1}$ . The principal observations are as follows:

- Since  $j_1, j_2, j_3$  are distinct, there have to be four vertices in  $\alpha_{\text{Ex}1}$ , each representing a different index among  $i, j_1, j_2, j_3$ .
- Since the variable of each summand is equal to  $x_{j_1}x_{j_2}$ , the graph matrix representation will have dimension  $n \times n$ . Moreover, for the two vertices corresponding to  $j_1$  and  $j_2$ , one of them should in U and the other is in V. By symmetry, one may assume that  $u_1 \in U$  and  $v_1 \in V$ .
- The other two vertices corresponding to i and  $j_3$  belong to W. Let us denote those vertices by  $w_1$  and  $w_2$ , respectively.

Accounting for the fact that  $i \in [m]$  and  $j_1, j_2, j_3 \in [n]$ , we follow the setting in Section 8 and assign weight  $\log_N(m)$  to  $w_1$  and assign weight  $\log_N(n)$  to each of  $u_1, v_1, w_2$ , where  $N := \max\{n, m\}$ . In view of Example 7.15, random variables  $b_{i,j_1}$ ,  $b_{i,j_2}$  and  $(b_{i,j_3}^2 - 1)$  are (constant multiples) of the orthonormal basis of  $\mathcal{N}(0,1)$ , and hence, one can represent those random variables by edges  $\{w_1, u_1\}$ ,  $\{w_1, v_1\}$ , and  $\{w_1, w_2\}$  with labels  $l_{\{w_1, u_1\}} = 1$ ,  $l_{\{w_1, v_1\}} = 1$ , and  $l_{\{w_1, w_2\}} = 2$ , respectively. Hence, one can see that  $f_{\text{Ex}1}(x) = x^{\top} M_{\alpha_{\text{Ex}1}} x$ , where  $\alpha_{\text{Ex}1}$  is a shape on four vertices  $u_1, v_1, w_1, w_2$  with weights  $w(u_1) = w(v_1) = w(w_2) = \log_N(n)$ ,  $w(w_1) = \log_N(m)$  and three edges  $\{u_1, u_1\}$ ,  $\{v_1, w_1\}$ ,  $\{w_1, w_2\}$  with labels  $l_{\{w_1, u_1\}} = 1$ ,  $l_{\{w_1, v_1\}} = 1$ , and  $l_{\{w_1, w_2\}} = 2$ . See Figure 16. Here and below, the edges are of label 1 unless specified otherwise.

<span id="page-49-0"></span>![](_page_49_Picture_0.jpeg)

Figure 16: an illustration of how shape  $\alpha_{\text{Ex}1}$  represents  $f_1$ . We depict the nodes with weight  $\log_N(n)$  as circles and a node with weight  $\log_N(m)$  as a diamond. Here node  $u_1$  represents index  $j_1$ ,  $v_1$  represents  $j_2$ ,  $w_1$  represents i, and  $w_2$  represents  $j_3$ . Consequently, the shape represents the random variable  $b_{i,j_1}$  with the edge  $\{w_1, u_1\}$ ,  $b_{i,j_2}$  with the edge  $\{w_1, v_1\}$ , and  $(b_{i,j_3}^2 - 1)$  with the edge  $\{w_1, w_2\}$ . The edges have labels  $l_{\{w_1, u_1\}} = 1$ ,  $l_{\{w_1, v_1\}} = 1$  and  $l_{\{w_1, w_2\}} = 2$ . Here and below, the edges are of label 1 unless specified otherwise.

Hence, we have  $\max_{\|x\|=1} f_{\text{Ex}1}(x) \leq \|M_{\alpha_{\text{Ex}1}}\|$ . To obtain a norm bound, due to Corollary 8.16, it suffices to compute a minimum weight separator of the shape  $\alpha$ . Since we are in the regime  $n \leq m$ ,  $\{u_1\}$  is a minimum weight separator, so  $\max_{\|x\|=1} f_{\text{Ex}1}(x) \leq \|M_{\alpha_{\text{Ex}1}}\| = \widetilde{O}(n\sqrt{m})$ .

Example 9.2 illustrates how we can find a graph matrix representation for a given homogeneous polynomial. However, in some cases, there could be more than one shape representing a single polynomial, as one can see from the following example. (This example will reappear in Sec. 9.3).

<span id="page-49-1"></span>**Example 9.3** (An example excerpted from [GM15]). For integers n, m such that  $n \leq m \leq c \cdot n^{1.5}$  for some constant c, let  $\{b_{i,j}\}_{i \in [m], j \in [n]}$  be i.i.d. Rademacher random variables. Let  $f_{Ex2}(x_1, \ldots, x_n)$  be a degree-4 homogeneous polynomial defined as

$$f_{Ex2}(x_1, \dots, x_n) := \sum_{\substack{j_1, j_2, j_3, j_4 \in [n]:\\ j_1, j_2, j_3, j_4 \text{ are distinct}}} \left[ \sum_{\substack{i_1 \neq i_2 \in [m], \ j_5 \in [n]\\ j_5 \notin \{j_1, j_2, j_3, j_4\}}} b_{i_1, j_5} b_{i_2, j_5} b_{i_1, j_1} b_{i_1, j_2} b_{i_2, j_3} b_{i_2, j_4} x_{j_1} x_{j_2} x_{j_3} x_{j_4} \right].$$

Following similar reasoning to Example 9.2, one can come up with a graph matrix representation. However, one distinction is that for this case, there are multiple shapes representing  $f_{\text{Ex2}}$ . We can easily verify that the following two shapes both represent  $f_{\text{Ex2}}$  (here since the input distribution is Rademacher, we do not need to consider labels of edges):

- $\alpha_{\text{Ex2}}$  is a graph on 7 vertices  $u_1, u_2, v_1, v_2, w_1, w_2, w_3$  with weights  $w(u_1) = w(u_2) = w(v_1) = w(v_2) = w(w_2) = \log_N(n), \ w(w_1) = w(w_3) = \log_N(m)$  and edges  $\{\{u_1, w_1\}, \{u_2, w_3\}, \{w_1, w_2\}, \{w_2, w_3\}, \{w_1, v_1\}, \{w_3, v_2\}\}$ . See Figure 17a.
- $\beta_{\text{Ex}2}$  is a graph on 7 vertices  $u_1, u_2, v_1, v_2, w_1, w_2, w_3$  with weights  $w(u_1) = w(u_2) = w(v_1) = w(v_2) = w(w_2) = \log_N(n), \ w(w_1) = w(w_3) = \log_N(m)$  and edges  $\{\{u_1, w_1\}, \{u_2, w_1\}, \{w_1, w_2\}, \{w_2, w_3\}, \{w_3, v_1\}, \{w_3, v_2\}\}$ . See Figure 17b.

<span id="page-50-1"></span>![](_page_50_Figure_0.jpeg)

![](_page_50_Picture_1.jpeg)

Figure 17a:  $\alpha_{\rm Ex2}$ .

Figure 17b:  $\beta_{\text{Ex}2}$ .

Figure 17: Two shapes  $\alpha_{\text{Ex2}}$  and  $\beta_{\text{Ex2}}$  representing  $f_{\text{Ex2}}$ . As before, nodes with weight  $\log_N(n)$  are depicted as circles and nodes with weight  $\log_N(m)$  are depicted as diamonds.

However, note that each representation gives a different upper bound. More specifically, one can check that the set of two vertices  $\{u_1, u_2\}$  is a minimum weight separator for  $\alpha_{\text{Ex2}}$ , while a single vertex  $\{w_2\}$  is a minimum weight separator for  $\beta_{\text{Ex2}}$ . It follows from Corollary 8.14 that  $\|M_{\alpha_{\text{Ex2}}}\| = \widetilde{O}\left(mn^{1.5}\right)$  and  $\|M_{\beta_{\text{Ex2}}}\| = \widetilde{O}\left(mn^2\right)$ . Hence, it is preferable to choose  $\alpha_{\text{Ex2}}$  as a shape representation of  $f_{\text{Ex2}}$  as it provides a sharper norm bound. Indeed, one can easily verify that  $\alpha_{\text{Ex2}}$  is the shape that gives the best upper bound.

The main takeaway from Example 9.3 is that when there are multiple shapes representing a single polynomial, we should choose the shape that gives the best upper bound on  $\max_{\|x\|=1} f(x)$ . This observation motivates us to consider the following definition:

**Definition 9.4** (Optimal shape). For a homogeneous polynomial f having a graph matrix representation, we say shape  $\alpha$  is an *optimal shape* for f if the graph matrix  $M_{\alpha}$  corresponding to  $\alpha$  gives the best possible upper bound (graph matrix norm bound) on  $\max_{\|x\|=1} f(x)$  up to polylogarithmic factors.

Having established all of this, we finally consider a general case where f does not directly admit a graph matrix representation. As we shall see in the following subsections, this is the case for many applications. The general principle for this case is as follows:

• We decompose f into a sum of homogeneous polynomials  $f_1 + \cdots + f_k$  so that each  $f_i$  admits a graph matrix representation.

With such decomposition, one can obtain an upper bound on each term  $\sup_{\|x\|=1} f_i(x)$  (for i = 1, 2, ..., k) using the graph matrix norm bounds. For the rest of this section, we will recover various upper bound analyses in the literature [BBH<sup>+</sup>12, HSSS16, GM15] using this strategy.

We begin with the results from [BBH<sup>+</sup>12], namely bounding the  $2 \to 4$  norm of a random operator. The original approach therein relies on some advanced large deviation inequalities based on Orlicz norms, whereas our graph matrix approach is fairly mechanical. While recovering the result, we also illustrate several principles that we will use for other applications in later subsections.

#### <span id="page-50-0"></span>9.2 Bound on the $2 \rightarrow 4$ norm of a random operator

Our first application is the upper bound on the  $2 \to 4$  norm of a random operator due to [BBH<sup>+</sup>12]. Here there are two dimension parameters  $n, m \in \mathbb{N}$ . Given these parameters, let A be an  $m \times n$  matrix with each entry drawn independently from  $\mathcal{N}(0,1)$ . Our goal is to prove an upper bound on  $||A||_{2\to 4}$  defined as  $\max_{||x||_2=1} ||Ax||_4$ .

<span id="page-51-1"></span>**Theorem 9.5** ([BBH<sup>+</sup>12, Theorem 7]). With high probability, the following upper bound holds:  $||A||_{2\to 4} \le 3m + \widetilde{O}(\max\{n\sqrt{m}, n^2\})$ .

The original proof in [BBH<sup>+</sup>12] requires some advanced large deviation inequalities based on Orlicz norms. Here, we take a more direct approach and recover the same bound using graph matrices.

Let us first represent the  $2 \to 4$  norm as the maximum of a homogeneous polynomial:

$$\max_{\|x\|_2=1} \|Ax\|_4^4 = \max_{\|x\|_2=1} \sum_{i \in [m]} \sum_{j_1, j_2, j_3, j_4 \in [n]} \left[ A_{i, j_1} A_{i, j_2} A_{i, j_3} A_{i, j_4} x_{j_1} x_{j_2} x_{j_3} x_{j_4} \right] =: \max_{\|x\|_2=1} f(x) \,.$$

With this polynomial representation, our analysis will follow the two steps: (i) we first analyze the dominant terms in the polynomial and then (ii) show that the remaining terms are negligible compared to the dominant terms. Let us begin with the analysis of the dominant terms.

#### 9.2.1 Analysis of dominant terms

Generally, the dominant terms are terms where all indices are distinct and the terms which have nonzero expected value:

<span id="page-51-0"></span>• (**Distinct indices**:) First, consider the case where all four indices are distinct. One can easily verify that this case can be represented by shape which consists of vertices  $\{u_1, u_2, v_1, v_2, w_1\}$ , weights  $w(u_1) = w(u_2) = w(v_1) = w(v_2) = \log_N(n)$ ,  $w(w_1) = \log_N(m)$  (here as before,  $N := \max\{n, m\}$ ), and edges  $\{\{u_1, w_1\}, \{u_2, w_1\}, \{v_1, w_1\}, \{v_2, w_1\}\}$ . See Figure 18.

![](_page_51_Figure_8.jpeg)

Figure 18: A shape representing the case of distinct indices.

Depending on the relative sizes between m and n, either  $\{w_1\}$  or  $\{u_1, u_2\}$  is a minimum weight separator. Hence, the norm bound for this case reads  $\widetilde{O}\left(\max\{n^2, n\sqrt{m}\}\right)$ .

• (Terms with non-zero expected values:) Now let us consider the terms which have nonzero expected values. Note that the terms with non-zero expected values occur only when the shape representation does not contain any edges. Having noticed this, one can easily conclude that the terms with non-zero expected values appear in the following cases: (i) there are two pairs of equal indices or (ii) all four indices are the same.

Let us first find the term with non-zero expected value for the case (i). One can notice that the term corresponding to the zero-expected value is represented by the shape consisting of vertices  $\{\nu_1, \nu_2, w_1\}$  (recall that we use  $\nu$  to denote vertices in the left/right intersection), weights  $w(\nu_1) = w(\nu_2) = \log_N(n)$ ,  $w(w_1) = \log_N(m)$  without edges. See Figure 19.

<span id="page-52-0"></span>![](_page_52_Picture_0.jpeg)

Figure 19: An optimal shape representing the case when there are two pairs of equal indices.

Since the minimum weight separator is  $\{\nu_1, \nu_2\}$ , the norm bound reads  $\widetilde{O}(m)$  due to the fact that the middle vertex is isolated. We will not use this result as our goal is to exactly recover the coefficient appearing in front of the m term. Instead, let us explicitly compute the term: since there are  $\binom{4}{2}/2 = 3$  possible ways of obtaining such equality pattern, the term for this case is equal to

$$3\sum_{i\in[m]}\sum_{\substack{j_1,j_2\in[n]\\j_1,j_2\text{ are distinct}}} \mathbb{E}[A_{i,j_1}^2]\mathbb{E}[A_{i,j_2}^2]x_{j_1}^2x_{j_2}^2 = 3\sum_{i\in[m]}\sum_{\substack{j_1,j_2\in[n]\\j_1,j_2\text{ are distinct}}} x_{j_1}^2x_{j_2}^2. \tag{9.1}$$

<span id="page-52-1"></span>Next, let us find the term with non-zero expected value for the case (ii). One can verify that the nonzero expectation term for this case is represented by the shape which consists of vertices  $\{\nu_1, w_1\}$ , weights  $w(\nu_1) = \log_N(n)$ ,  $w(w_1) = \log_N(m)$  without edges. See Figure 20.

<span id="page-52-3"></span><span id="page-52-2"></span>
$$\begin{array}{c|c}
\hline
\nu_1 & U \cap V \\
\hline
\hline
w_1 & W
\end{array}$$

Figure 20: An optimal shape representing the case where all four indices are equal.

Again the graph matrix norm bound reads  $\widetilde{O}(m)$ , and hence, we explicitly represent the term as before:

$$\sum_{i \in [m]} \sum_{j_1 \in [n]} \mathbb{E}[A_{i,j_1}^4] x_{j_1}^4 = 3 \sum_{i \in [m]} \sum_{j_1 \in [n]} x_{j_1}^4.$$
(9.2)

Combining (9.1) with (9.2), we obtain the term  $3\sum_{i\in[m]}\left(\sum_{j_1}x_{j_1}^2\right)^2=3m$  since  $||x||_2=1$ . This exactly recovers the desired 3m in Theorem 9.5.

Having analyzed the dominant terms, now it suffices to show that the remaining terms are negligible compared to the dominant terms.

#### 9.2.2 Analysis of negligible terms

Below, we take two different approaches for this. The first approach will be more brute-force in nature: it will consider all possible cases and show—using graph matrices—that each case is dominated by the dominant terms. After presenting the brute-force approach, we will present another approach which deals with cases succinctly via some counting arguments. As we move on to other applications where the shape representations become more complicated than Figure 18, such counting arguments will be effective in simplifying our arguments.

- 1) First approach: brute-force case studies. Let us first list all possible equality patterns between the indices:
  - 1.  $|\{j_1, j_2, j_3, j_4\}| = 4$ , i.e.,  $j_1, j_2, j_3$ , and  $j_4$  are all distinct.
  - 2.  $|\{j_1, j_2, j_3, j_4\}| = 3$ , i.e., there is a single pair of indices that are equal.
  - 3.  $|\{j_1, j_2, j_3, j_4\}| = 2$  with each equivalence class of size 2, i.e., there are two pairs of equal indices.
  - 4.  $|\{j_1, j_2, j_3, j_4\}| = 2$  with one equivalence class of size 3, i.e., there are three indices that are equal.
  - 5.  $|\{j_1, j_2, j_3, j_4\}| = 1$ , i.e., all indices are equal.

Note that we already have covered Case 1, and the terms corresponding to the nonzero expectations in Case 3 and 5 are also analyzed. We now represent each of the remaining cases by graph matrices and bound each term with our norm bounds:

2: The second case corresponds to the polynomial

$$f_2(x) := 6 \sum_{i \in [m]} \sum_{\substack{j_1, j_2, j_3 \in [n] \\ j_1, j_2, j_3 \text{ are distinct}}} \left[ A_{i,j_1}^2 A_{i,j_2} A_{i,j_3} x_{j_1}^2 x_{j_2} x_{j_3} \right] .$$

To represent each random variable with a member of the orthonormal basis of  $\mathcal{N}(0,1)$  (see Example 7.15), we further decompose this polynomial as follows:  $f_2 = \sqrt{2} \cdot f_{2-1} + f_{2-2}$ , where

$$f_{2\text{-}1}(x) := 6 \sum_{i \in [m]} \sum_{\substack{j_1, j_2, j_3 \in [n] \\ j_1, j_2, j_3 \text{ are distinct}}} \left[ \frac{A_{i,j_1}^2 - 1}{\sqrt{2}} A_{i,j_2} A_{i,j_3} x_{j_1}^2 x_{j_2} x_{j_3} \right] \text{ and}$$

$$f_{2\text{-}1}(x) := 6 \sum_{i \in [m]} \sum_{\substack{j_1, j_2, j_3 \in [n] \\ j_1, j_2, j_3 \text{ are distinct}}} \left[ A_{i,j_2} A_{i,j_3} x_{j_1}^2 x_{j_2} x_{j_3} \right].$$

<span id="page-53-0"></span>One can easily verify that  $\alpha_{2-1}$  and  $\alpha_{2-2}$  in Figures 21a and 21b are optimal shapes for  $f_{2-1}$  and  $f_{2-2}$ , respectively.

![](_page_53_Figure_12.jpeg)

Figure 21: Shapes for Case 2. We depict nodes with weight  $\log_N(n)$  as circles and a node with weight  $\log_N(m)$  as a diamond. Again, the edges are of label 1 unless specified otherwise.

Notice the edge of label 2 in  $\alpha_{2\text{-}1}$  due to appearance of the random variable  $(A_{i,j_1}^2 - 1)/\sqrt{2}$ . For both  $\alpha_{2\text{-}1}$  and  $\alpha_{2\text{-}2}$ , depending on the relative sizes between m and n, either  $\{\nu_1, u_1\}$  or  $\{\nu_1, w_1\}$  is a minimum weight separator. Hence, the norm bound for both cases reads:  $\widetilde{O}(\max\{n, \sqrt{nm}\})$ , which is dominated by  $\widetilde{O}(\max\{n^2, n\sqrt{m}\})$ .

3: The third case corresponds to the polynomial (since the nonzero expectation term is already handled):

$$f_3(x) := 3 \sum_{i \in [m]} \sum_{\substack{j_1, j_2 \in [n] \\ j_1, j_2 \text{ are distinct}}} \left[ A_{i,j_1}^2 A_{i,j_2}^2 x_{j_1}^2 x_{j_2}^2 - x_{j_1}^2 x_{j_2}^2 \right] .$$

Again, we further decompose the polynomial so that each edge variable is a member of the orthonormal basis of  $\mathcal{N}(0,1)$ :  $f_3(x) := 2 \cdot f_{3-1} + \sqrt{2} \cdot f_{3-2} + \sqrt{2} \cdot f_{3-3}$ , where

$$f_{3\text{-}1}(x) := 3 \sum_{i \in [m]} \sum_{\substack{j_1, j_2 \in [n] \\ j_1, j_2 \text{ are distinct}}} \left[ \frac{A_{i,j_1}^2 - 1}{\sqrt{2}} \frac{A_{i,j_2}^2 - 1}{\sqrt{2}} x_{j_1}^2 x_{j_2}^2 \right]$$

$$f_{3\text{-}2}(x) := 3 \sum_{i \in [m]} \sum_{\substack{j_1, j_2 \in [n] \\ j_1, j_2 \text{ are distinct}}} \left[ \frac{A_{i,j_1}^2 - 1}{\sqrt{2}} A_{i,j_2}^2 x_{j_1}^2 x_{j_2}^2 \right]$$

$$f_{3\text{-}3}(x) := 3 \sum_{i \in [m]} \sum_{\substack{j_1, j_2 \in [n] \\ j_1, j_2 \text{ are distinct}}} \left[ A_{i,j_1}^2 \frac{A_{i,j_2}^2 - 1}{\sqrt{2}} x_{j_1}^2 x_{j_2}^2 \right].$$

<span id="page-54-0"></span>One can easily check that the shapes  $\alpha_{3-1}$ ,  $\alpha_{3-2}$ , and  $\alpha_{3-3}$  in Figures 22a, 22b, and 22c represent  $f_{3-1}$ ,  $f_{3-2}$ , and  $f_{3-3}$ , respectively.

![](_page_54_Figure_5.jpeg)

Figure 22: Shapes for Case 3. The edges have label 1 unless specified otherwise.

For  $\alpha_{3-1}$ ,  $\alpha_{3-2}$ , and  $\alpha_{3-3}$ ,  $\{\nu_1, \nu_2\}$  is a minimum weight separator, and hence, the norm bound reads  $\widetilde{O}(\sqrt{m})$ , which is clearly dominated by  $\widetilde{O}(\max\{n^2, n\sqrt{m}\})$ .

4: The fourth case corresponds to the polynomial

$$f_4(x) := 4 \sum_{i \in [m]} \sum_{\substack{j_1, j_2 \in [n] \\ j_1, j_2 \text{ are distinct}}} \left[ A_{i,j_1}^3 A_{i,j_2} x_{j_1}^3 x_{j_2} \right].$$

To keep the edge variables within the orthonormal basis, we decompose  $A_{i,j_1}^3 = \sqrt{6} \cdot \frac{A_{i,j_1}^3 - 3A_{i,j_1}}{\sqrt{6}} + 3A_{i,j_1}$ . Note that both terms in the decomposition can be represented by the shape consisting of three vertices  $u_1, w_1, \nu_1$  with edges  $\{\{u_1, w_1\}, \{\nu_1, w_1\}\}$ . The only distinction between the two cases is in whether edge  $\{\nu_1, w_1\}$  gets label 3 or 1. See Figure 23.

<span id="page-55-0"></span>![](_page_55_Picture_0.jpeg)

Figure 23: Shapes for Case 4. Here the only distinction between the two subcases is whether edge  $\{\nu_1, w_1\}$  gets label 3 or 1.

For both cases, since  $\{\nu_1\}$  is the minimum weight separator, the norm bound reads  $\widetilde{O}(\sqrt{nm})$ , which is dominated by  $\widetilde{O}(\max\{n^2, n\sqrt{m}\})$ .

5: Lastly, the fifth case corresponds to the polynomial

$$f_5(x) := \sum_{i \in [m]} \sum_{j_1 \in [n]} \left[ \left( A_{i,j_1}^4 - 3 \right) x_{j_1}^4 \right].$$

Again we decompose the random variable  $A_{i,j_1}^4$  as

$$A_{i,j_1}^4 - 3 = \sqrt{4!} \cdot \frac{A_{i,j_1}^4 - 6A_{i,j_1} + 3}{\sqrt{4!}} + 6\sqrt{2} \cdot \frac{A_{i,j_1}^2 - 1}{\sqrt{2}}$$

so that each edge variable becomes a member of the orthonormal basis. Then, following similar reasoning to the previous cases, it turns out each term in the decomposition can be represented by the shapes in Figure 24.

<span id="page-55-1"></span>![](_page_55_Picture_8.jpeg)

Figure 24: Shapes for Case 4. Here the only distinction between the two subcases is whether the edge  $\{\nu_1, w_1\}$  gets label 4 or 2.

For those shapes,  $\{\nu_1\}$  is the minimum weight separator, and hence, the norm bound is  $\widetilde{O}(\sqrt{m})$ , which is dominated by  $\widetilde{O}(\max\{n^2, n\sqrt{m}\})$ .

To summarize, since all the remaining cases are dominated by the bound  $\widetilde{O}\left(\max\{n^2,\ n\sqrt{m}\}\right)$  for the dominant term, Theorem 9.5 follows.

2) Second approach: case reduction via counting arguments. As readers may have noticed, checking cases can become quite laborious, especially when we consider larger shapes. Here we offer a simpler approach which can significantly reduce the number of cases to check. We note that the counting arguments that we will develop here will be used throughout the rest of this section to simplify cases.

Our strategy is to show by counting arguments that the remaining cases are bounded by the bound for the dominant case. First, note that for the remaining cases, the middle vertex is not isolated since they have non-zero expected values and thus have at least one edge incident to the middle vertex. Moreover, since the case where all four indices are distinct has been taken care of, there exists a pair of indices that are equal; without loss of generality, let those indices be  $j_1$  and

 $j_2$ . Now, let us place the vertex corresponding to  $j_1 = j_2$  in the intersection  $U \cap V$  in the shape representation. Then since the vertex is in the intersection, any vertex separator has to contain the vertex, and hence, the norm bound is at most  $\widetilde{O}(n\sqrt{m})$  since we have assumed the middle vertex is not isolated and there are at most two other vertices of weight  $\log_N(n)$  and at most one vertex of weight  $\log_N(m)$ . This is clearly dominated by the norm bound  $\widetilde{O}(\max\{n^2, n\sqrt{m}\})$  for the case where all four indices are distinct.

## <span id="page-56-0"></span>9.3 Overcomplete tensor decomposition algorithm analysis

In this section, we will recover the main component of the overcomplete tensor decomposition analysis in [GM15]. The proof therein relies on some clever arguments: it makes use of a clever decoupling technique due to [dlPMS95] together with some incoherence properties of random vectors. In contrast, we again emphasize that our proof based on graph matrices is *mechanical*.

To describe the setting, it was demonstrated in [GM15] that a key component of analyzing an overcomplete tensor decomposition algorithm is showing an upper bound on the injective tensor norm of random tensors. Formally, for integers n, m such that  $n \leq m \leq c \cdot n^{1.5}$  for some constant c > 0, let  $a_1, \ldots, a_m \in \mathbb{R}^n$  be random vectors whose entries are i.i.d. Rademacher random variables. Consider an  $n \times n \times n$  tensor  $\mathbf{T} = \sum_{i=1}^m a_i^{\otimes 3}$ . Then, our goal is to prove an upper bound on the injective tensor norm defined as  $\|\mathbf{T}\|_{\text{inj}} := \sup_{\|x\|=1} \langle \mathbf{T}, x^{\otimes 3} \rangle$ . In this section, we will recover their upper bound of  $n^3 + \widetilde{O}(n^{1.5}m)$ .

**Theorem 9.6** ([GM15, Theorem 4.2]). Suppose that  $n \leq m \leq c \cdot n^{1.5}$  for some constant c > 0. With high probability, we have  $\|\mathbf{T}\|_{\text{inj}} \leq n^{1.5} + \widetilde{O}(m)$ .

To transform the tensor into a matrix, we use Cauchy-Schwarz inequality following [GM15]:

$$(\langle \mathbf{T}, x^{\otimes 3} \rangle)^2 = \left\langle \sum_{i=1}^m \langle a_i, x \rangle^2 a_i, x \right\rangle^2 \le \left\| \sum_{i=1}^m \langle a_i, x \rangle^2 a_i \right\|^2 \|x\|^2 = \left\| \sum_{i=1}^m \langle a_i, x \rangle^2 a_i \right\|^2.$$

Hence, it suffices to show  $\left\|\sum_{i=1}^{m} \langle a_i, x \rangle^2 a_i \right\|^2 \le n^3 + \widetilde{O}(mn^{1.5})$ . Expanding the term  $\left\|\sum_{i=1}^{m} \langle a_i, x \rangle^2 a_i \right\|^2$  together with the fact that  $\langle a_i, a_i \rangle = n$ , we obtain

$$\left(\left\langle T, x^{\otimes 3} \right\rangle\right)^{2} \leq n \cdot \underbrace{\sum_{i=1}^{m} \left\langle a_{i}, x \right\rangle^{4}}_{=:g(x)} + \underbrace{\sum_{i_{1} \neq i_{2}} \left\langle a_{i_{1}}, a_{i_{2}} \right\rangle \left\langle a_{i_{1}}, x \right\rangle^{2} \left\langle a_{i_{2}}, x \right\rangle^{2}}_{=:h(x)}.$$

Our agenda is to prove that  $\max_{\|x\|=1} g(x) = n^2 + \widetilde{O}\left(m\sqrt{n}\right)$  and  $\max_{\|x\|=1} h(x) = \widetilde{O}\left(mn^{1.5}\right)$ .

# 9.3.1 Showing $\max_{\|x\|=1} h(x) = \widetilde{O}\left(mn^{1.5}\right)$ using graph matrices

First, let us write  $h(x_1, ..., x_n)$  as a polynomial (again, we will simply use  $a_{i,j}$  to denote the j-th coordinate of the vector  $a_i$ ):

$$\sum_{j_1, j_2, j_3, j_4 \in [n]} \left[ x_{j_1} x_{j_2} x_{j_3} x_{j_4} \sum_{i_1 \neq i_2 \in [m], \ j_5 \in [n]} a_{i_1, j_5} a_{i_2, j_5} a_{i_1, j_1} a_{i_1, j_2} a_{i_2, j_3} a_{i_2, j_4} \right].$$

Again, let us first analyze the dominant terms:

• (**Distinct indices**:) Note that the polynomial for the distinct indices corresponds to Example 9.3 wherein we have shown the upper bound  $\widetilde{O}(mn^{1.5})$ . Here we recall the illustration of the optimal shape (Figure 17a) for the reader's convenience.

![](_page_57_Picture_1.jpeg)

Figure 25: An optimal shape representing the case of distinct indices.

• (Terms with non-zero expected values:) In order to have terms with non-zero expected values, note that the shape representation should not contain any edges. In particular, the vertices corresponding to i-indices, namely  $i_1$  and  $i_2$ , need to be isolated.

However, the vertices corresponding  $i_1$  and  $i_2$  cannot be isolated. To see this, first notice that there are three random variables  $a_{i_1,j_1}$ ,  $a_{i_1,j_2}$ , and  $a_{i_1,j_5}$  which has index  $i_1$ . Hence, no matter how  $j_1$ ,  $j_2$ , and  $j_5$  are equal to each other, there will be still an edge incident to the vertex representing  $i_1$ . In particular, even when  $j_1 = j_2 = j_5$ , there is a random variable  $a_{i_1,j_1}^3 = a_{i_1,j_1}$  (:  $a_{i_1,j_1}$  is a Rademacher random variable), which implies that the vertex corresponding to  $i_1$  is still incident to an edge. The same logic applies to  $i_2$ . This implies that there are no terms with non-zero expected values.

Actually, one can argue a stronger statement that any shape representation cannot have isolated middle vertices. We develop it here for later use. To prove this, it is enough to demonstrate for the case where  $j_5$  is not equal to other j-indices that the vertex representing  $j_5$  cannot be isolated. This statement is indeed true because there are two zero-mean random variables  $a_{i_1,j_5}$  and  $a_{i_2,j_5}$ , which are distinct since  $i_1 \neq i_2$ ; hence, there are two edges incident to the vertex representation of  $j_5$ .

Now, it suffices to show that the remaining cases are dominated by the dominant case above. Again, rather than listing all possible equality patterns between indices and analyze them one by one, we follow the previous sections and devise some counting arguments.

As we have demonstrated above, any shape representation does not have isolated middle vertices. Consequently, the upper bound on the maximum value due to our main theorem reads

$$\widetilde{O}\left(mn^{\frac{1}{2}\#} \text{ vertices of weight } \log_N(n) \text{ outside of a weight minimum vertex separator}\right)$$

since there are two vertices of weight  $\log_N(m)$  (corresponding to  $i_1$  and  $i_2$ ). Below, we will demonstrate that for all cases, there are at most three vertices of weight  $\log_N(n)$  outside of a minimum weight separator, yielding the desired upper bound of  $\widetilde{O}(mn^{1.5})$ .

1. First, assume that there is more than one equality between the j-indices, i.e.,  $j_1, j_2, j_3, j_4, j_5$ . In this case, the number of vertices of weight  $\log_N(n)$  becomes at most 3. Hence, we may assume that there is only one equality between  $j_1, j_2, j_3, j_4, j_5$ . If the equality does not involve

 $j_5$ , i.e., it is between  $j_1, j_2, j_3, j_4$ , one can place the vertex corresponding to the equal indices in the intersection  $U \cap V$ . Then, that vertex has to be in any vertex separator, which implies that there are at most three  $\log_N(n)$ -weighted vertices outside of any vertex separator. Thus, if the only equality does not involve  $j_5$ , we get the desired bound.

- 2. Hence, it suffices to consider the case where the equality includes index  $j_5$ . Without loss of generality, assume that the equality is  $j_1 = j_5$ . Let us place the two vertices corresponding to  $j_3$  and  $j_4$  in U and V, respectively. Then, with such a shape representation, there must be a path between the two vertices as there are random variables  $a_{i_2,j_3}$  and  $a_{i_2,j_4}$ . From this, one can deduce that between the vertices corresponding to  $j_3$  and  $j_4$ , one of them needs to be in a vertex separator. Hence, any minimum weight separator has to contain at least one  $\log_N(n)$ -weight vertex and since another  $\log_N(n)$ -weight vertex is removed by the equality, we conclude that there are at most three vertices of weight  $\log_N(n)$  outside of any vertex separator. Therefore, we get the desired bound for this case as well.
- 9.3.2 Showing  $\max_{\|x\|=1} g(x) = n^2 + \widetilde{O}(m\sqrt{n})$  using graph matrices

Recall  $g(x) := \sum_{i=1}^{m} \langle a_i, x \rangle^4$ . Once again, following [GM15], we apply Cauchy-Schwarz on  $g^2$ :

$$\left(\sum_{i=1}^{m} \langle a_i, x \rangle^4\right)^2 = \left\langle \sum_{i=1}^{m} \langle a_i, x \rangle^3 a_i, x \right\rangle^2 \le \left\| \sum_{i=1}^{m} \langle a_i, x \rangle^3 a_i \right\|^2.$$

Hence, it suffices to show  $\left\|\sum_{i=1}^{m} \langle a_i, x \rangle^3 a_i \right\|^2 \le n^4 + \widetilde{O}(mn^{2.5})$ . Expanding the last term together with the fact that  $\langle a_i, a_i \rangle = n$ , we obtain

$$g^{2}(x) \leq n \cdot \underbrace{\sum_{i=1}^{m} \langle a_{i}, x \rangle^{6}}_{=:g_{1}(x)} + \underbrace{\sum_{i \neq j} \langle a_{i}, a_{j} \rangle \langle a_{i}, x \rangle^{3} \langle a_{j}, x \rangle^{3}}_{=:g_{2}(x)},$$

We will show that  $\max_{\|x\|=1} g_1(x) = n^3 + \widetilde{O}(mn^{1.5})$  and  $\max_{\|x\|=1} g_2(x) = \widetilde{O}(mn^{2.5})$ .

1) **Proof for**  $g_2$ : Actually, our graph matrix analysis yields a better bound than what we need to show: we will show that  $\widetilde{O}(\sqrt{m}n^3)$  under a relaxed condition  $m \leq O(n^2)$  rather than  $m \leq O(n^{1.5})$ ; here the bound  $\widetilde{O}(\sqrt{m}n^3)$  is certainly better than  $\widetilde{O}(mn^{2.5})$  since  $n \leq m$ .

Let us first write  $g_2$  as a sum of monomials:

$$\sum_{j_1,j_2,j_3,j_4,j_5,j_6 \in [n]} \left[ x_{j_1} x_{j_2} x_{j_3} x_{j_4} x_{j_5} x_{j_6} \sum_{i_1 \neq i_2 \in [m], \ j_7 \in [n]} a_{i_1,j_7} a_{i_2,j_7} a_{i_1,j_1} a_{i_1,j_2} a_{i_1,j_3} a_{i_2,j_4} a_{i_2,j_5} a_{i_2,j_6} \right].$$

We begin with the dominant terms:

• (**Distinct indices**:) To begin with, we consider the case where  $j_1, j_2, \ldots, j_7$  are all distinct. Similarly to Example 9.3, one can check that the shape in Figure 26 is an optimal shape representing this case.

![](_page_59_Figure_0.jpeg)

<span id="page-59-0"></span>Figure 26: An optimal shape for the case of distinct indices.

Since  $\{w_1, u_3\}$  is a minimum weight separator, we obtain the bound of  $\widetilde{O}(\sqrt{m}n^3)$ .

• (Terms with non-zero expected values:) In order to obtain terms with non-zero expected values, the shape representation should not contain any edges. In particular, the vertices corresponding to i-indices, namely  $i_1$  and  $i_2$  have to be isolated. It turns out from this, one can characterize all possible shapes.

To begin with, to make the vertex corresponding to  $i_1$  isolated, the four random variables that depend on index  $i_1$ , i.e.  $a_{i_1,j_1}$ ,  $a_{i_1,j_2}$ ,  $a_{i_1,j_3}$ , and  $a_{i_1,j_7}$ , need to be either (i) paired up into two equal variables or (ii) all equal. The same two cases apply to the four random variables that depend on index  $i_2$ , i.e.  $a_{i_2,j_4}$ ,  $a_{i_2,j_5}$ ,  $a_{i_2,j_6}$ , and  $a_{i_2,j_7}$ . Hence, there are four different cases in total, and one can show that each case can be represented by one of the shapes in Figure 27:

<span id="page-59-1"></span>![](_page_59_Figure_5.jpeg)

Figure 27: Four shapes that corresponds to the polynomials with non-zero expected values.

In all four different cases, one can easily check that we have the norm bounds  $O\left(m^2\right)$ , which is certainly  $\widetilde{O}\left(\sqrt{m}n^3\right)$  since  $m=O\left(n^2\right)$ .

Having analyzed the dominant terms, following the previous sections, we show that the remaining terms are dominated by the dominant terms. We again divide into cases depending on the existence of isolated middle vertices:

1. First, consider the case where the shape representation has an isolated middle vertex. The vertex corresponding to  $j_7$  cannot be isolated because there are two distinct random variables  $a_{i_1,j_7}$  and  $a_{i_2,j_7}$ . Hence, only vertices corresponding to  $i_1$  and  $i_2$  could be isolated. Since the case where both of them are isolated is covered in the dominant terms, we assume that only one of them is isolated.

Without loss of generality, let us say the vertex corresponds to  $i_1$  is isolated. Then, due to the same reasoning as the dominant term analysis, it should be the case that j-indices appearing with  $i_1$  in random variables, i.e.,  $j_1, j_2, j_3, j_7$ , are either (a) two pairs of two equal indices or (b) all equal.

(a) Let us handle the first case. Without loss of generality, assume that  $j_1 = j_2$  and  $j_3 = j_7$ . One can place the vertex representing  $j_1$  in the intersection  $U \cap V$ . Now, if there is an additional equality among the indices  $j_3(=j_7), j_4, j_5, j_6$ , one can place the vertex corresponding to the equal indices in  $U \cap V$  as well. Then, there are at most 2 vertices of weight  $\log_N(n)$  outside a minimum weight separator. Consequently, the upper bound reads  $\widetilde{O}\left(m^{1.5}n\right)$ , which is certainly of  $\widetilde{O}\left(\sqrt{m}n^3\right)$  since we have assumed  $m = O\left(n^2\right)$ . If there is no additional equality among  $j_3, j_4, j_5, j_6$ , one can verify that the following shape represents this case.

![](_page_60_Figure_2.jpeg)

Figure 28: An optimal shape for the case of no additional equality.

Since  $m = O(n^2)$ ,  $\{w_3\}$  is a minimum weight separator. Hence, the upper bound reads  $\widetilde{O}(mn^2)$ , which is certainly  $\widetilde{O}(\sqrt{m}n^3)$  since  $m = O(n^2)$ .

- (b) When  $j_1, j_2, j_3, j_7$  are all equal, let us again place the equal vertex in the intersection  $U \cap V$ . By dividing into cases depending on whether there is an additional equality between j-indices, one can similarly conclude that there are at most two  $\log_N(n)$ -weighted vertices outside of a vertex separator. Hence, the bound reads  $\widetilde{O}\left(m^{1.5}n\right)$ , which is certainly  $\widetilde{O}\left(\sqrt{m}n^3\right)$  since  $m = O\left(n^2\right)$ .
- 2. Let us move on to the case where there is no isolated vertex outside of  $U \cup V$ . If there are at least two equalities between indices  $j_1, j_2, \ldots, j_7$ , then at least one of them is between indices  $j_1, j_2, \ldots, j_6$ . Let us place the vertex corresponding to the equal indices in  $U \cap V$ . Then any vertex separator will contain the vertex. Since the other equality additionally gets rid of an additional j-index, we conclude that there are at most 4 vertices of weight  $\log_N(n)$  outside of a vertex separator. This implies the bound  $\widetilde{O}(mn^2)$ , which is certainly  $\widetilde{O}(\sqrt{mn^3})$ .
- 3. Hence, it suffices to consider the case where there is only one equality. Let us first assume that the equality is between indices  $j_1, j_2, \ldots, j_6$ . Again, one can place the vertex corresponding to the equal indices in  $U \cap V$ . Let us choose two indices among  $j_1, j_2, \ldots, j_6$  that are not involved in the equality and place the vertices corresponding to those two indices in different subsets between U and V. Then, such two vertices admit a path between them, implying a vertex separator needs to include one of them. Hence, there are at most four  $\log_N(n)$ -weighted vertices, again showing the upper bound of  $\widetilde{O}(mn^2)$ .

Lastly, consider the case where the equality involves the index  $j_7$ . In that case, the shape in Figure 29 is an optimal shape.

![](_page_61_Figure_0.jpeg)

Figure 29: An optimal shape for the corner case

<span id="page-61-0"></span>Since  $\{w_1, u_3\}$  is a minimum weight separator, the upper bound is  $\widetilde{O}(\sqrt{m}n^{2.5})$ .

Combining all the cases, the remaining cases are dominated by the upper bounds on the dominant terms, and hence the proof for  $g_2$  is completed.

2) Proof for  $g_1$ : Here, we use a different trick to recover the bound  $\max_{\|x\|=1} g_1(x) = n^3 + \widetilde{O}\left(mn^{1.5}\right)$ . We note that our trick is helpful in recovering the term  $n^3$  up to its coefficient. It demonstrates a general principle of using the graph matrix machinery that depending on one's target bound, one might need to modify the target matrix.

Our graph matrix analysis actually yields a better bound of  $\max_{\|x\|=1} g_1(x) \leq n^3 + \widetilde{O}(mn)$ . Consider an  $n^3 \times m$  matrix B whose  $((i_1, i_2, i_3), i)$ -th entry is set as  $a_{i,i_1}a_{i,i_2}a_{i,i_3}$ . Then, it is straightforward to check that  $BB^{\top}$  is a matrix representation of  $g_1$ . Hence, we have  $\max_{\|x\|=1} g_1(x) \leq \|BB^{\top}\|$ . Here the trick is to consider  $\|B^{\top}B\|$  instead of  $\|BB^{\top}\|$ . Note that for  $i, j \in [m]$  the (i, j)-th entry of  $B^{\top}B$  is given as

<span id="page-61-1"></span>
$$\sum_{i_1, i_2, i_3} a_{i, i_1} a_{i, i_2} a_{i, i_3} a_{j, i_1} a_{j, i_2} a_{j, i_3}. \tag{9.3}$$

We first decompose  $B^{\top}B$  into the diagonal part D and the non-diagonal part N. One can easily see that the diagonal part is equal to  $n^3 \cdot I_m$  where  $I_m$  is the  $m \times m$  identity matrix.

Now, we will decompose N into graph matrices. To do that we will decompose each entry in terms of the equality patterns between indices  $i_1,i_2,i_3$ . More specifically, we examine the decomposition  $N=N_\emptyset+N_{i_1=i_2}+N_{i_1=i_3}+N_{i_2=i_3}+N_{i_1=i_2=i_3}$  where for each matrix, the (i,j)-th entry is defined as the value of summation (9.3) restricted to the corresponding equality pattern. For instance, for  $i\neq j$ , the (i,j)-th entry of  $N_\emptyset$  is equal to  $\sum_{i_1,i_2,i_3 \text{ are distinct }} a_{i,i_1}a_{i,i_2}a_{i,i_3}a_{j,i_1}a_{j,i_2}a_{j,i_3}$  and the (i,j)-th entry of  $N_{i_1=i_2}$  is equal to  $\sum_{i_1=i_2\neq i_3} a_{i,i_1}a_{i,i_2}a_{i,i_3}a_{j,i_1}a_{j,i_2}a_{j,i_3}$ . Then, one can see that each matrix is a graph matrix. More specifically,  $N_\emptyset$  is represented by

Then, one can see that each matrix is a graph matrix. More specifically,  $N_{\emptyset}$  is represented by shape  $\gamma_{1-1}$  in Figure 30a,  $N_{i_1=i_2}, N_{i_1=i_3}, N_{i_2=i_3}$  are represented by shape  $\gamma_{1-2}$  in Figure 30b and  $N_{i_1,i_2,i_3}$  is represented by shape  $\gamma_{1-3}$  in Figure 30c.

<span id="page-62-1"></span>![](_page_62_Figure_0.jpeg)

Figure 30: Shapes for the matrices  $N_{\emptyset}$ ,  $N_{i_1=i_2}$ ,  $N_{i_1=i_3}$ ,  $N_{i_2=i_3}$ , and  $N_{i_1=i_2=i_3}$ .

It is straightforward to check that a minimum weight separator is  $\{u_1\}$  for  $\gamma_{1\text{-}1}$ ,  $\{w_2\}$  for  $\gamma_{1\text{-}2}$  and  $\{w_1\}$  for  $\gamma_{1\text{-}3}$ . Thus, our main theorem concludes that  $\|N_{\emptyset}\| = \widetilde{O}\left(\sqrt{m}n^{1.5}\right)$ ,  $\|N_{i_1=i_2}\| + \|N_{i_1=i_3}\| + \|N_{i_2=i_3}\| = \widetilde{O}\left(mn\right)$  and  $\|N_{i_1=i_2=i_3}\| = \widetilde{O}\left(m\right)$ . Taken collectively, we have  $\max_{\|x\|=1} g_1(x) \leq \|B^{\top}B\| \leq \|N\| + \|D\| \leq n^3 + \widetilde{O}\left(mn\right)$ .

#### <span id="page-62-0"></span>9.4 Fast spectral algorithm for sparse vector recovery

In this section, we will recover the sparse vector recovery analysis in [HSSS16]. We first describe the setting. The standing assumption is that for two dimension parameters n, m, we have  $n \leq \sqrt{m}$ , i.e.,  $\log_N(n) \leq \frac{1}{2} \log_N(m)$ , where as before  $N := \max\{n, m\}$ . Given the dimensions, let  $b_1, b_2, \ldots b_m \in \mathbb{R}^n$  be random vectors drawn i.i.d. from  $\mathcal{N}(0, I_m)$ . Consider an  $n \times n$  matrix

$$B := \sum_{i \in [m]} (\|b_i\|_2^2 - n) b_i b_i^{\top}.$$

The goal of this setting is to come up with a good estimate on ||B||. Proving a sharp upper bound on ||B|| is a main technical component for analyzing the fast spectral algorithm for sparse vector recovery in [HSSS16]. We refer readers to Section 4 (especially Lemma 4.5) therein for precise details.

<span id="page-62-2"></span>**Theorem 9.7** ([HSSS16, Section 4]). With high probability,  $||B|| \leq 2m + \widetilde{O}(n\sqrt{m})$ .

Our approach is based on decomposing B into several graph matrices based on equality pattern between indices. First, note that the  $(j_1, j_2)$ -th entry of B is expressed as follows:

$$B_{j_1,j_2} = \sum_{i \in [m], j_3 \in [n]} (b_{i,j_3}^2 - 1) b_{i,j_1} b_{i,j_2}.$$

Now, similarly to what we did in Section 9.2, let us first analyze the dominant terms:

• (**Distinct indices**:) First, we consider the case where all indices are distinct, i.e.,  $|\{j_1, j_2, j_3\}| = 3$ . Note that this case corresponds to the graph matrix considered in Example 9.2 where we have shown the upper bound  $\widetilde{O}(n\sqrt{m})$ . Here we recall the illustration of the shape (Figure 16) for the reader's convenience.

![](_page_63_Picture_0.jpeg)

Figure 31: The shape of the graph matrix representing the case of distinct indices.

<span id="page-63-0"></span>• (Terms with non-zero expected values:) Next, we consider the terms having non-zero expected values. Notice that this is only possible when all three indices are the same, i.e.,  $j_1 = j_2 = j_3$ . The corresponding shape is depicted in Figure 32:

![](_page_63_Picture_3.jpeg)

Figure 32: A shape representing the case of all equal indices.

Invoking the fact that for  $X \sim \mathcal{N}(0,1)$ ,  $\mathbb{E}[X^4 - X^2] = 3 - 1 = 2$ , the corresponding term is equal to  $2\sum_{j_1 \in [n]} \sum_{i \in [m]} x_{j_1}^2$ , which is equal to 2m since x is a unit vector.

Now, it suffices to show that the remaining cases are dominated by the dominant terms above. Following the counting arguments in Section 9.2, we again devise an argument to show that the remaining cases are dominated by the dominant cases above. Since we have taken care of the term with non-zero expected value, for the remaining cases, the middle vertex is not isolated. Moreover, since we have already handled the case of distinct indices, we may assume that there exists at least one pair of indices that are equal.

- 1. If  $j_1 = j_2$ , then one can place the vertex corresponding to  $j_1 = j_2$  in the left/right intersection, which results in the norm bound at most  $\widetilde{O}(\sqrt{nm})$ .
- 2. Now if there are more than one equality among j-indices, then it must be the case that  $j_1 = j_2$ . Hence, we are left with the case where there is exactly one equality that is not  $j_1 = j_2$ . Without loss of generality, let the unique equality be  $j_1 = j_3$ . This case corresponds to the matrix whose  $(j_1, j_2)$ -th entry is equal to

<span id="page-63-1"></span>
$$\sum_{i \in [m]} \left( b_{i,j_1}^3 - b_{i,j_1} \right) b_{i,j_2} . \tag{9.4}$$

Again, we decompose the random variable  $b_{i,j_1}^3 - b_{i,j_1}$  so that each edge variable is a member of the orthonormal basis:

$$b_{i,j_1}^3 - b_{i,j_1} = \sqrt{6} \cdot \frac{b_{i,j_1}^3 - 3b_{i,j_1}}{\sqrt{6}} + 2b_{i,j_1}.$$

Then, the graph matrix for this case can be decomposed into two parts accordingly. In either case, it is straightforward to see that for any shape representation, there must be two (labeled)

<span id="page-64-1"></span>edges  $\{j_1, i\}$  and  $\{i, j_2\}$ , which implies that there is a path  $j_1 \to i \to j_2$  from the left vertex to the right vertex. See Figure 33.

![](_page_64_Figure_1.jpeg)

Figure 33: Two shapes representing the decomposition of the polynomial (9.4).

Hence, the minimum weight separator has to contain at least one vertex; consequently, the norm bounds for those shapes are  $\widetilde{O}(\sqrt{nm})$ , which is again dominated by the dominant cases.

Combining the above argument, we conclude that the dominant cases dominate the remaining cases, which finishes the proof of Theorem 9.7.

### <span id="page-64-0"></span>9.5 Fast overcomplete tensor decomposition algorithm analysis

In this section, we will recover the main technical ingredient for a faster overcomplete tensor decomposition [HSSS16]. In particular, we will recover Proposition 5.5 therein using graph matrices. Let us begin with the setting: For integers n, m such that  $n \leq m$ , let  $g, a_1, a_2, \ldots, a_m \in \mathbb{R}^n$  be random vectors whose entries are drawn i.i.d. from  $\mathcal{N}(0,1)$ . Let  $T := \sum_{i \in [m]} a_i (a_i \otimes a_i)^{\top}$ . Consider an  $n^2 \times n^2$  matrix

<span id="page-64-2"></span>
$$M := \sum_{i_1 \neq i_2 \in [m]} \langle g, T(a_{i_1} \otimes a_{i_2}) \rangle a_{i_1} a_{i_1}^{\top} \otimes a_{i_2} a_{i_2}^{\top}.$$
 (9.5)

The goal is then to come up with a good estimate on ||M||. The following is the upper bound proved in [HSSS16].

<span id="page-64-3"></span>**Theorem 9.8** ([HSSS16, Proposition 5.5]). With high probability,  $||M|| \leq \widetilde{O}(n^{2.5}m^{1.5})$ .

Again, similar to Section 9.4, our approach is based on decomposing B into several graph matrices based on equality pattern between indices. First, note that the  $(j_1, j_2, j_3, j_4)$ -th entry of M is expressed as follows:

$$M_{j_1,j_2,j_3,j_4} = \sum_{\substack{i_1,i_2,i_3 \in [m]: \ i_1 \neq i_2, \\ j_5,j_6,j_7 \in [n]}} g_{j_5} a_{i_3,j_5} a_{i_3,j_6} a_{i_3,j_7} a_{i_1,j_6} a_{i_2,j_7} a_{i_1,j_1} a_{i_1,j_2} a_{i_2,j_3} a_{i_2,j_4}. \tag{9.6}$$

As before, let us begin with the dominant terms:

• (**Distinct indices**:) First, consider the case where both *i*-indices, i.e.,  $i_1, i_2, i_3$ , and *j*-indices, i.e.,  $j_1, j_2, \ldots, j_7$ , are all distinct. Since there is a random variable  $g_{j_5}$  depending only on one index  $j_5$ , shape representations need to have a dummy vertex of weight 0; then,  $g_{j_5}$  can be represented by an edge whose one end is equal to the dummy vertex. Having noticed this, one can check that the graph matrix with the following shape represents this case.

<span id="page-65-0"></span>![](_page_65_Picture_0.jpeg)

Figure 34: The shape of the graph matrix for the case of distinct indices. Here, the vertex representing w<sup>7</sup> is depicted with a dotted circle, signifying that it is a dummy vertex of weight 0. This dummy vertex is required to represent gj<sup>5</sup> in [\(9.6\)](#page-64-2) since this random variable has a single index j5; with this dummy vertex, gj<sup>5</sup> now can be represented by edge {w6, w7}.

Since {u1, u2} is a minimum weight separator, we obtain the upper bound Oe n <sup>2</sup>.5m1.<sup>5</sup> .

• (Terms with non-zero expected values:) We demonstrate that there are no terms with non-zero expected values. To see this, we show that for any shape representation, there is an i-index whose vertex representation is not isolated. First, notice that since i<sup>1</sup> 6= i2, iindices cannot be all equal, and hence, there is an i-index that is different for the others. Let the distinct i-index be i<sup>1</sup> without loss of generality. Then by the similar argument to the previous sections, the vertex representation of i<sup>1</sup> cannot be isolated as there are three random variables ai1,j<sup>1</sup> , ai1,j<sup>2</sup> , and ai1,j<sup>6</sup> that contain i1. Consequently, there are no terms with non-zero expected values.

Now, we consider the remaining cases. Here we consider the two cases depending on whether there is an equality between i-indices.

1. First, consider the case where there is an equality between i-indices. Note that since i<sup>1</sup> 6= i2, there could be only one equality present; let the equality be i<sup>2</sup> = i<sup>3</sup> without loss of generality. If there are no additional equalities between indices, one can check that the graph matrix corresponding to the shape in Figure [35](#page-66-0) represents this case:

<span id="page-66-0"></span>![](_page_66_Picture_0.jpeg)

Figure 35: The shape of the graph matrix representing the case where the only equality between indices is  $i_2 = i_3$ .

A minimum weight separator for both shapes is  $\{u_1, u_2\}$ , which implies the bound of  $\widetilde{O}(n^3m)$  (:  $w_4$  could be isolated), which is of  $\widetilde{O}(n^{2.5}m^{1.5})$  since  $n \leq m$ .

Now let us consider the case where there are equalities present between j-indices.

- (a) Let us first consider the case where the equalities are between j-indices corresponding to the middle vertices in Figure 35, i.e.,  $w_2$ ,  $w_4$ , and  $w_6$ . One can notice that these equalities will only reduce the number of  $\log_N(n)$ -weighted vertices, resulting in a smaller graph matrix bound.
- (b) Now let us consider the case where there is an equality involving a left or right vertex in Figure 35, i.e.,  $u_1$ ,  $u_2$ ,  $v_1$ , and  $v_2$ .
  - i. Notice first that such equalities can possibly make the vertex  $w_3$  in Figure 35 isolated. On the other hand, to make  $w_3$  isolated, the j-indices corresponding to its neighbor, i.e.,  $u_2$ ,  $v_2$ ,  $w_2$ , and  $w_6$  need to be paired up into two equal indices. This entails at least two additional equalities. If there is an additional equality, there would be at most four vertices of weight  $\log_N(n)$  with one of the middle vertices (i.e.  $w_4$ ) isolated and two vertices of weight  $\log_N(m)$  with one of them isolated, resulting in the upper bound of  $\widetilde{O}\left(n^{2.5}m^{1.5}\right)$ . Otherwise if there is no additional equality, there is a path  $u_1 \to w_1 \to v_1$  from U to V, which implies that at least one  $\log_N(n)$ -weighted vertex needs to be in a minimum weight separator, resulting in the bound  $\widetilde{O}\left(n^{2.5}m^{1.5}\right)$ .
  - ii. Thus, we may assume that there is no isolated  $\log_N(m)$ -weighted vertex.
    - A. If there are at least two equalities among j-indices, then we get the upper bound of  $\widetilde{O}(n^3m) \leq \widetilde{O}(n^{2.5}m^{1.5})$ .
    - B. Hence, it suffices to consider the case of single equality. If the equality is between indices corresponding to  $u_1, u_2, v_1, v_2$  in Figure 35, then there could be at most five  $\log_N(n)$ -weighted vertices outside of a vertex separator with one of them possibly isolated, which implies the upper bound of  $\widetilde{O}(n^3m) \leq \widetilde{O}(n^{2.5}m^{1.5})$ .
    - C. Hence, we may assume that the equality is between an index corresponding to one of  $u_1, u_2, v_1, v_2$  and an index corresponding to one of  $w_2, w_4, w_6$ . In all cases, one can easily check from Figure 35 that either the path  $u_1 \to w_1 \to v_1$  or  $u_2 \to w_3 \to v_2$  is unaltered, and hence at least one of the  $\log_N(n)$ -weighted

vertex has to be included in a vertex separator. This again implies that there are at most five  $\log_N(n)$ -weighted vertices outside of a vertex separator with one of them possibly isolated, implying the bound  $\widetilde{O}\left(n^3m\right) \leq \widetilde{O}\left(n^{2.5}m^{1.5}\right)$ .

2. Now we consider the case where there is no equality between i-indices. This case corresponds to having no equalities between  $\log_N(m)$ -weight vertices in Figure 34, and hence, one can notice that there cannot be isolated middle vertices.

If there are at least two equalities present among j-indices, then we get the upper bound of  $\widetilde{O}\left(n^{2.5}m^{1.5}\right)$  as there are at most five  $\log_N(n)$ -weighted vertices and at most three  $\log_N(m)$ -weighted vertices.

Hence, it suffices to consider the case of a single equality. Without loss of generality, assume that the index corresponding to  $u_1$  in Figure 34 is involved in the equality. Then the path  $u_2 \to w_5 \to v_2$  in Figure 34 from  $u_2$  to  $v_2$  is unaltered, and hence either  $u_2$  or  $v_2$  has to be included in a vertex separator. Hence, there could be at most five  $\log_N(n)$ -weighted vertices outside of a vertex separator, which again implies the upper bound of  $O(n^{2.5}m^{1.5})$ .

The above arguments demonstrate that the remaining cases are dominated by the dominant terms, which concludes the proof of Theorem 9.8 using graph matrices.

## 10 Conclusion and further studies

In this paper, we analyzed graph matrices, a general class of random matrices which naturally arise when analyzing the Sum-of-Squares hierarchy. Using the trace power method, we proved probabilistic norm bounds on graph matrices, which are tight up to a poly-logarithmic factor. Notably, we showed that for all shapes  $\alpha$ , the minimum size (weight) of a separator between the left and right sides of  $\alpha$  is the key quantity that characterizes the norm bound on  $M_{\alpha}$ . We also showed that graph matrices can be used to simplify the proofs of several technical statements in the literature [BBH<sup>+</sup>12, HSSS16, GM15] about the  $2 \to 4$  norm of a random operator and tensor decomposition.

This paper leaves several interesting open problems. To name a few, one question is to improve our current norm bounds. It is very likely that with a more careful analysis, the poly-logarithmic factor can be reduced or removed. Another interesting question would be to determine the limit of the mean density of the spectra of graph matrices, finding analogues of Wigner's semicircle law [Wig58] and/or Girko's circular law [Gir85] for graph matrices.

## <span id="page-67-0"></span>A Lower bounds

In this appendix, we show that the norm bounds we have obtained are tight up to a factor of polylog(n).

<span id="page-67-1"></span>**Theorem A.1.** If  $\alpha$  is a shape such that for all vertices w in  $W_{\alpha} \setminus W_{\text{iso}}$ , there is a path from w to either  $U_{\alpha}$  or  $V_{\alpha}$  in  $\alpha$ , then with high probability  $\|M_{\alpha}\|$  is  $\Omega\left(n^{\frac{w(V(\alpha))-w(S_{\min})+w(W_{\text{iso}})}{2}}\right)$ .

**Remark A.2.** If  $W_{\alpha}$  has vertices which are not isolated and are not connected to  $U_{\alpha}$  or  $V_{\alpha}$ , there is a non-negligible chance that  $M_{\alpha}$  has considerably smaller norm than expected. To see this, let  $\alpha_0$ 

be the part of  $\alpha$  which is not isolated but is not connected to  $U_{\alpha}$  or  $V_{\alpha}$  and let  $\alpha_1$  be the remaining part of  $\alpha$ . We have that  $M_{\alpha} \approx M_{\alpha_0} M_{\alpha_1}$  where  $M_{\alpha_0}$  is a scalar depending on the input graph G which has a non-negligible chance of being close to 0.

*Proof.* To prove this theorem, we analyze the Frobenius norm of  $M_{\alpha}$ .

**Definition A.3.** The Frobenius norm of an  $m \times n$  matrix M is  $||M||_F = \sqrt{\sum_{i=1}^m \sum_{j=1}^n M_{ij}^2}$ .

<span id="page-68-0"></span>**Lemma A.4.** For any matrix M, if the singular value decomposition of M is  $M = \sum_{i=1}^r \lambda_i u_i v_i^{\dagger}$ then  $||M||_F^2 = \sum_{i=1}^r \lambda_i^2$ .

*Proof.* Observe that

$$||M||_F^2 = \sum_{i=1}^r \sum_{j=1}^r \lambda_i \lambda_j (u_i \cdot u_j) (v_i \cdot v_j) = \sum_{i=1}^r \lambda_i^2.$$

Using Lemma A.4, one can develop a lower bound on the spectral norm of a matrix in terms of the Frobenius norm of the matrix.

<span id="page-68-1"></span>Corollary A.5. For any rank r matrix M where  $r \geq 1$ ,  $||M|| \geq \sqrt{\frac{||M||_F^2}{r}}$ .

With this in mind, our strategy for proving lower bounds on  $||M_{\alpha}||$  is as follows:

- 1. Take a matrix  $M'_{\alpha}$  such that  $M'_{\alpha}$  has rank at most  $n^{w(S_{\min})}$  and with high probability,  $||M'_{\alpha} - M_{\alpha}||$  is negligible.
- 2. Observe that  $\mathbb{E}\left[\left\|M_{\alpha}'\right\|_{F}^{2}\right]$  is  $\Theta(n^{w(V(\alpha))+w(W_{\mathrm{iso}})})$ .
- 3. Show that with high probability,

$$\left| \left\| M_{\alpha}' \right\|_F^2 - \mathbb{E}\left[ \left\| M_{\alpha}' \right\|_F^2 \right] \right| \ll n^{w(V(\alpha)) + w(W_{\text{iso}})}.$$

4. Combining above three statement, the desired probabilistic lower bound on  $||M_{\alpha}||$  follows from Corollary A.5.

For simplicity, we first implement the second and third steps with  $M_{\alpha}$  rather than  $M'_{\alpha}$ . We then describe  $M'_{\alpha}$  and explain why the same techniques can be used for  $M'_{\alpha}$ . To analyze  $\|M_{\alpha}\|_F^2$ , we observe that  $\|M_{\alpha}\|_F^2 = \text{Tr}\left(M_{\alpha}M_{\alpha}^{\top}\right)$ . Expanding out the term using the

definition of  $M_{\alpha}$ , we have the following proposition:

**Proposition A.6.** For any shape  $\alpha$ ,  $\operatorname{Tr}\left(M_{\alpha}M_{\alpha}^{\top}\right) = \sum_{i} c_{i}M_{\beta_{i}}$  where each shape  $\beta_{i}$  is obtained through the following steps and each  $c_i$  is a constant.

- 1. Start with two copies  $\alpha_1$  and  $\alpha_2$  of  $\alpha$ .
- 2. Take some set  $E_{\text{constr}}$  of constraint edges between  $V(\alpha_1)$  and  $V(\alpha_2)$  where  $E_{\text{constr}}$  automatically has constraint edges between  $U_{\alpha_1}$  and  $U_{\alpha_2}$  and between  $V_{\alpha_1}$  and  $V_{\alpha_2}$ .
- 3. Take  $V(\beta_i)$  to be  $V(\alpha_1) \cup V(\alpha_2)$  where we contract all edges in  $E_{\text{constr}}$ . Take  $U_{\beta_i} = V_{\beta_i} = \emptyset$ .

4. Consider  $E(\alpha_1) \cup E(\alpha_2)$  as a multi-set. If there are two edges between the same pair of vertices (or set of vertices if we have hyperedges) in  $V(\alpha')$  and these edges have labels  $l_1$  and  $l_2$  where  $l_1 \leq l_2$  then replace these two edges with a single edge with some label in  $[l_2 - l_1, l_2 + l_1]$  (where an edge with label 0 corresponds to deleting the edge). Take  $E(\beta_i)$  to be the resulting set of labeled edges.

We do this because  $h_{l_1}h_{l_2} = \sum_{j=l_2-l_1}^{l_2+l_1} c_{l_1,l_2,j}h_j$  for some coefficients  $c_{l_1,l_2,j} = \mathbb{E}_{\Omega}[h_{l_1}h_{l_2}h_j]$ .

We now show the following lemma about the shapes  $\beta_i$  which we obtain in this way.

<span id="page-69-0"></span>**Lemma A.7.** Let  $\alpha$  be any shape and  $\beta_i$  be a shape obtained by decomposing  $\operatorname{Tr}(M_{\alpha}M_{\alpha}^{\top})$ . Let  $\operatorname{Iso}(\beta_i)$  be the set of isolated vertices of  $\beta_i$ . Then we have

$$w(V(\beta_i)) + w(\mathsf{Iso}(\beta_i)) \le 2(w(V(\alpha)) + w(W_{\mathrm{iso}})).$$

Moreover, if  $\alpha$  is a shape such that for all vertices w in  $W_{\alpha} \setminus W_{iso}$ , there is a path from w to either  $U_{\alpha}$  or  $V_{\alpha}$  in  $\alpha$ , then for any  $\beta_i$  such that  $E(\beta_i) \neq \emptyset$ , we have

$$w(V(\beta_i)) + w(\mathsf{Iso}(\beta_i)) < 2(w(V(\alpha)) + w(W_{\mathsf{iso}})).$$

*Proof.* Following the argument in Section 6.3, observe that each vertex  $w \in W_{\text{iso}}$  just multiplies  $M_{\alpha}$  by roughly n (or more generally  $n^{w(v)}$ ). Thus, it is sufficient to consider the case when  $W_{\text{iso}}$  is empty.

Take X to be the set of vertices in  $V(\beta_i)$  which resulted from the contraction of a constraint edge and take  $Y = V(\beta_i) \setminus X$ . We have that  $2w(V(\alpha)) = w(V(\alpha_1)) + w(V(\alpha_2)) = 2w(X) + w(Y)$ . Now observe that any  $v \in Y$  must be incident to at least one edge in  $E(\beta_i)$ . Thus,  $\mathsf{lso}(\beta_i) \subseteq X$  so

$$w(V(\beta_i)) + w(\operatorname{Iso}(\beta_i)) = 2w(X \cap \operatorname{Iso}(\beta_i)) + w(X \setminus \operatorname{Iso}(\beta_i)) + w(Y)$$
  
$$\leq 2w(X) + w(Y) = 2w(V(\alpha)).$$

To show the moreover statement, it is sufficient to show that whenever  $E(\beta_i) \neq \emptyset$ ,  $X \setminus \mathsf{Iso}(\beta_i) \neq \emptyset$ . To see this, let w be a vertex in  $V(\beta_i) \setminus \mathsf{Iso}(\beta_i)$ . If  $w \in X$ , then we are done so we may assume that  $w \in Y$ . Now consider  $\alpha_1$  and  $\alpha_2$  before we contract all of the constraint edges to form  $\beta_i$ . w either came from  $V(\alpha_1)$  or  $V(\alpha_2)$ , so without loss of generality we can assume that w came from  $V(\alpha_1)$ . By assumption, there is a path P in  $\alpha_1$  from w to either  $U_{\alpha_1}$  or  $V(\alpha_1)$ . Let v be the first vertex on this path which is incident to a constraint edge and let v be the preceding vertex. Note that v and v must exist because all of the vertices in  $U_{\alpha_1}$  and  $V_{\alpha_1}$  are incident to constraint edges while v is not incident to a constraint edge. When we contract all of the constraint edges, v (or rather the vertex resulting from contracting v and the other endpoint of its constraint edge) will be in v. However, the edge between v and v will not vanish, so v will not be isolated. Thus, v isolated.

Corollary A.8.  $\mathbb{E}\left[\|M_{\alpha}\|_{F}^{2}\right]$  is  $\Theta\left(n^{w(V(\alpha))+w(W_{\mathrm{iso}})}\right)$  and with high probability,  $\left\|\|M_{\alpha}\|_{F}^{2}-\mathbb{E}\left[\|M_{\alpha}\|_{F}^{2}\right]\right|$  is  $\widetilde{O}\left(n^{w(V(\alpha))+w(W_{\mathrm{iso}})-\frac{w_{min}}{2}}\right)$  where  $w_{min}$  is the minimum weight of a vertex in  $V(\alpha)$ .

*Proof.* For the first part, observe that

$$\mathbb{E}\left[\|M_{\alpha}\|_{F}^{2}\right] = \sum_{i: E(\beta_{i}) = \emptyset} c_{i} M_{\beta_{i}}.$$

For these  $\beta_i$ ,  $M_{\beta_i}$  is a scalar which is  $\Theta\left(n^{w(V(\beta_i))}\right) = \Theta\left(n^{\frac{w(V(\beta_i))+w(\operatorname{lso}(\beta_i))}{2}}\right)$ . By Lemma A.7,  $w(V(\beta_i)) + w(\operatorname{lso}(\beta_i)) \le 2w(V(\alpha))$  and this is tight as if we have constraint edges between each vertex in  $V(\alpha_1)$  and its counterpart in  $V(\alpha_2)$  then we will have that  $w(V(\beta_i)) = w(\operatorname{lso}(\beta_i)) = w(V(\alpha))$  and  $E(\beta_i) = \emptyset$ .

For the second part, observe that  $\|M_{\alpha}\|_{F}^{2} = \mathbb{E}\left[\|M_{\alpha}\|_{F}^{2}\right] = \sum_{i:E(\beta_{i})=\emptyset} c_{i}M_{\beta_{i}}$  Combining Theorem 8.4 and Lemma A.7, with high probability each of these terms is  $\widetilde{O}\left(n^{w(V(\alpha))+w(W_{\mathrm{iso}})-\frac{w_{min}}{2}}\right)$ , as needed.

We now implement the second and third steps with an approximation  $M'_{\alpha}$ . For the approximation, we adopt the idea from [BHK<sup>+</sup>19, Section 6] and consider a low rank approximation  $M'_{\alpha}$  of  $M_{\alpha}$  by decomposing  $\alpha$  into left, middle, and right parts  $\sigma$ ,  $\tau$ , and  ${\sigma'}^{\top}$  based on the leftmost and rightmost minimum weight vertex separators of  $\alpha$ .

**Definition A.9.** Given a shape  $\alpha$ , we define the leftmost minimum weight vertex separator  $S_{\alpha}$  to be the set of vertices such that

- 1.  $S_{\alpha}$  is a minimum weight vertex separator between  $U_{\alpha}$  and  $V_{\alpha}$ .
- 2. For any other minimum weight vertex separator S',  $S_{\alpha}$  is a vertex separator between  $U_{\alpha}$  and S'.

Similarly, we define the rightmost minimum weight vertex separator  $T_{\alpha}$  to be the set of vertices such that

- 1.  $T_{\alpha}$  is a minimum weight vertex separator between  $U_{\alpha}$  and  $V_{\alpha}$ .
- 2. For any other minimum weight vertex separator S',  $T_{\alpha}$  is a vertex separator between S' and  $V_{\alpha}$ .

As shown in [BHK<sup>+</sup>19], the leftmost and rightmost minimum vertex separators are well-defined.

**Definition A.10.** Given a shape  $\alpha$ , we define the left, middle, and right parts of  $\alpha$  as follows:

- 1. We define the left part  $\sigma$  of  $\alpha$  to be the part of  $\alpha$  between  $U_{\alpha}$  and  $S_{\alpha}$ .
- 2. We define the middle part  $\tau$  of  $\alpha$  to be the part of  $\alpha$  between  $S_{\alpha}$  and  $T_{\alpha}$ .
- 3. We define the right part  ${\sigma'}^{\top}$  of  $\alpha$  to be the part of  $\alpha$  between  $T_{\alpha}$  and  $V_{\alpha}$ .

**Definition A.11.** Given a shape  $\alpha$ , we define  $M'_{\alpha} = M_{\sigma} M_{\tau} M_{\sigma'}^{\top}$  where  $\sigma$ ,  $\tau$ , and  ${\sigma'}^{\top}$  are the left, middle, and right parts of  $\alpha$ .

Using the intersection tradeoff lemma [BHK<sup>+</sup>19, Lemma 7.12], we have the following lemma **Lemma A.12.** For any shape  $\alpha$ , letting  $\sigma$ ,  $\tau$ , and  ${\sigma'}^{\top}$  be the left, middle, and right parts of  $\alpha$ ,

$$M_{\sigma}M_{ au}M_{\sigma'}{}^{ o}-M_{lpha}=\sum_i c_i M_{lpha_i}$$

1 (C : 1 1 11 1

for some shapes  $\alpha_i$  and coefficients  $c_i$  such that

1.  $\forall i, |c_i| \text{ is } O(1)$ .

2. For each shape  $\alpha_i$ ,  $U_{\alpha_i} = U_{\alpha}$ ,  $V_{\alpha_i} = V_{\alpha}$ , and  $w(V(\alpha_i)) + w(\mathsf{Iso}(\alpha_i)) < w(V(\alpha)) + w(W_{iso})$ , where  $\mathsf{Iso}(\alpha_i)$  is the set of isolated vertices of  $\alpha_i$ .

**Remark A.13.** Intuitively, this lemma says that  $M_{\sigma}M_{\tau}M_{\sigma'}^{\top}$  is a good approximation to  $M_{\alpha}$ .

The rank of  $M_{\sigma}$ ,  $M_{\tau}$ , and  $M_{\sigma'^{\top}}$  are all at most  $n^{w(S_{min})}$ , so it is sufficient to show that  $\mathbb{E}\left[\|M_{\alpha}'\|_F^2\right]$  is  $\Theta(n^{w(V(\alpha))+w(W_{iso})})$  and  $\left|\|M_{\alpha}'\|_F^2 - \mathbb{E}\left[\|M_{\alpha}'\|_F^2\right]\right| \ll n^{w(V(\alpha))+w(W_{iso})}$ . To do this, we write  $M_{\alpha}' = M_{\alpha} + \sum_i c_i M_{\alpha_i}$  and observe that

$$\operatorname{Tr}\left(M_{\alpha}^{\prime}{M^{\prime}}_{\alpha}^{\top}\right) = \operatorname{Tr}\left(M_{\alpha}M_{\alpha}^{\top}\right) + \sum_{i} c_{i} \operatorname{Tr}\left(M_{\alpha_{i}}M_{\alpha}^{\top}\right) + \sum_{i^{\prime}} c_{i^{\prime}} \operatorname{Tr}\left(M_{\alpha}M_{\alpha_{i^{\prime}}}^{\top}\right) + \sum_{i \ i^{\prime}} c_{i} c_{i^{\prime}} tr\left(M_{\alpha_{i}}M_{\alpha_{i^{\prime}}}^{\top}\right)$$

We have already analyzed  $\operatorname{Tr}(M_{\alpha}M_{\alpha}^{\top})$ . To show that the other terms are negligible, we combine the following lemma with Theorem 8.4.

**Lemma A.14.** Let  $\alpha$  and  $\alpha'$  be any shapes such that  $U_{\alpha} = U_{\alpha'}$  and  $V_{\alpha} = V_{\alpha'}$ . Let  $\beta_i$  be a shape obtained from decomposing  $\operatorname{Tr}(M_{\alpha}M_{\alpha'}^{\top})$ . Letting  $\operatorname{Iso}(\beta_i)$  be the set of isolated vertices of  $\beta_i$ , we have

$$w(V(\beta_i)) + w(\operatorname{Iso}(\beta_i)) \le w(V(\alpha)) + w(\operatorname{Iso}(\alpha)) + w(V(\alpha')) + w(\operatorname{Iso}(\alpha')),$$

where  $Iso(\alpha)$  and  $Iso(\alpha')$  are the isolated middle vertices of  $\alpha$  and  $\alpha'$  respectively.

*Proof.* This can be proved in the same way as the first part of Lemma A.7. Again, it is sufficient to consider the case when  $\alpha$  and  $\alpha'$  have no isolated middle vertices. Taking X to be the set of vertices in  $V(\beta_i)$  which resulted from the contraction of a constraint edge and taking  $Y = V(\beta_i) \setminus X$ , we have that  $w(V(\alpha)) + w(V(\alpha')) = 2w(X) + w(Y)$ . Now observe that any  $v \in Y$  must be incident to at least one edge in  $E(\beta_i)$ . Thus,  $\mathsf{Iso}(\beta_i) \subseteq X$  so

$$w(V(\beta_i)) + w(\operatorname{Iso}(\beta_i)) = 2w(X \cap \operatorname{Iso}(\beta_i)) + w(X \setminus \operatorname{Iso}(\beta_i)) + w(Y)$$
  
$$\leq 2w(X) + w(Y) = w(V(\alpha)) + w(V(\alpha')),$$

<span id="page-71-1"></span>

which concludes the proof.

This completes the proof of Theorem A.1.

Remark A.15. A careful reader might notice that [BHK<sup>+</sup>19] only analyzes the graph matrices defined in Section 2 and not the generalized graph matrices in Section 7. That said, these results (the existence of leftmost and rightmost minimum weight vertex separators and the intersection tradeoff lemma) hold for generalized graph matrices as well and this can be shown by generalizing the arguments in [BHK<sup>+</sup>19].

# <span id="page-71-0"></span>B Alternative proof of Lemma 8.11

Here, we provide an alternative proof of Lemma 8.11. We first recall the statement of Lemma 8.11 for readers' convenience: For any shape  $\alpha$  such that  $U_{\alpha} \cap V_{\alpha} = \emptyset$ , for any well-behaved  $C \in \mathcal{C}_{(\alpha,2q)}$  such that  $\operatorname{val}(C) \neq 0$ , the total weight of the constraint edges is at least  $q \cdot w(W_{\alpha}) + (q-1) \cdot w(S_{\min})$ .

To simplify our analysis, we follow the first paragraph of the proof in the main text, and reduce the statement to showing that:

The total weight of the "additional" constraint edges  $\geq (q-1) \cdot w(S_{\min})$ . (B.1)

Our proof proceeds by the following three steps:

- 1. Preprocessing the constraint graph: We will first preprocess the constraint graph so that the task of counting the number of "additional" constraint edges becomes simpler.
- 2. Computing the total weight of the "additional" constraint edges: After the preprocessing step, one can easily count the number of "additional" constraint edges. Consequently, one can easily compute the total weight of the "additional" constraint edges.
- 3. Lower bound using vertex separators: Based on the previous two steps, we will then come up with a lower bound on the total weight in terms of w(Smin). This lower bound will exactly match [\(B.1\)](#page-71-1).

Below, we show the details of the above three steps:

## B.1 Preprocessing the constraint graph

We first define the notion of equivalence for clarity:

Definition B.1. In a constraint graph (Definition [3.6\)](#page-16-3), we say two vertices u and v are equivalent if φ(u) = φ(v). We write u ∼ v to denote that u and v are equivalent.

With this notion of equivalence, we now describe our preprocessing steps:

- 1. We choose a minimum weight separator Smin between Uα<sup>1</sup> and Vα<sup>1</sup> .
- 2. For each vertex v which is not equivalent to some vertex in Smin, we rearrange the constraint edges for the vertices which are equivalent to v so that these edges form a path from left to right (with Smin as the reference point).
- 3. For each vertex v ∈ Smin, we rearrange the constraint edges for the vertices which are equivalent to v so that these edges form a path from left to right starting at v. We then add an additional superfluous constraint edge to make this path into a cycle. Note that if v was not incident to any other constraint edges (which can happen only if v ∈ Uα<sup>1</sup> or v ∈ Vα<sup>1</sup> ) then this superfluous constraint edge is a loop.

Due to the superfluous constraint edges we added at the last step, the statement [\(B.1\)](#page-71-1) we wanted to show now becomes:

<span id="page-72-0"></span>The total weight of "additional" constraint edges 
$$\geq q \cdot w(S_{\min})$$
. (B.2)

We now count the number of "additional" constraint edges in the preprocessed constraint graph.

## B.2 Computing the total weight of "additional" constraint edges

Due to the preprocessing step, the task of counting the number of "additional" constraint edges becomes simpler. More specifically, note that the constraint edges between equivalent vertices now form a path from left to right. Hence, each vertex in the constraint graph is incident to either 0, 1 or 2 constraint edges. Based on this, we define:

**Definition B.2.** For each vertex  $v \in \alpha$ , let  $c_v^{(i)}$  (i = 0, 1, 2) be the number of copies of v that are incident to i non-loop constraint edges. Let  $c_v^{(loop)}$  be the number of copies of v which are incident to a single loop constraint edge. Note that  $c_v^{(loop)}$  is always 0 or 1 and we only have that  $c_v^{(loop)} = 1$  if there is a copy of v in  $S_{\min}$  and this copy of v was originally not incident to any constraint edges.

From this definition, it is straightforward to verify the following:

Claim B.3. The total weight of "additional" constraint edges is equal to

$$\frac{1}{2} \sum_{v \in U_{\alpha} \cup V_{\alpha}} w(v) \cdot \left[ c_v^{(1)} + 2c_v^{(loop)} + 2c_v^{(2)} \right] + \frac{1}{2} \sum_{v \in W_{\alpha}} w(v) \cdot c_v^{(2)}$$
(B.3)

*Proof.* First, every incident constraint edge to a copy of a vertex in  $U_{\alpha} \cup V_{\alpha}$  is an "additional" constraint edge. Hence, the total weight of "additional" constraint edges among the copies of  $U_{\alpha} \cup V_{\alpha}$  is

$$\frac{1}{2} \sum_{v \in U_{\alpha} \cup V_{\alpha}} w(v) \cdot \left[ 0 \cdot c_v^{(0)} + 1 \cdot c_v^{(1)} + 2 \cdot c_v^{(loop)} + 2 \cdot c_v^{(2)} \right], \tag{B.4}$$

where we divide the summation by 2 to avoid double counting.

Next, consider vertices that are copies of  $W_{\alpha}$ . Since we are counting only "additional" constraint edges, we need to reduce the number of incident constraint edges by one. Hence, the total weight among the copies of  $W_{\alpha}$  is equal to

$$\frac{1}{2} \sum_{v \in W_{\alpha}} w(v) \cdot \left[ 0 \cdot c_v^{(0)} + 0 \cdot c_v^{(1)} + 1 \cdot c_v^{(2)} \right]. \tag{B.5}$$

<span id="page-73-2"></span><span id="page-73-1"></span><span id="page-73-0"></span>

Adding the two terms (B.4) and (B.5), (B.3) follows.

### B.3 Lower bound using vertex separators

Now the last step develops a lower bound on (B.3) in terms of  $w(S_{\min})$ . To that end, we first classify the vertices that are incident to only one constraint edge:

**Definition B.4** (Endpoints). Recall that  $S_{\min}$  is the minimum weight vertex separator of  $\alpha_1$  which we chose as a reference point. For a vertex  $v \notin S_{\min}$  that is incident to only one constraint edge, we say

- v is a left endpoint if there is no vertex u such that  $u \sim v$  and u is to the left of v; and
- v is a right endpoint if there is no vertex w such that  $v \sim w$  and w is to the right of v.

For each vertex  $v \in S_{\min}$  which is only incident to a superfluous constraint edge which is a loop,

- If  $v \in U_{\alpha_1}$  then we consider v to be a left endpoint in  $\alpha_1$  and a right endpoint in  $\alpha_{2q}^T$ .
- If  $v \in V_{\alpha_1}$  then we consider v to be a right endpoint in  $\alpha_1$  and a left endpoint in  $\alpha_1^T$ .

With this left/right endpoint classification, one can easily prove the following crucial property:

<span id="page-74-0"></span>Claim B.5. Let  $w_1$  and  $w_2$  be the vertices that belong to the same copy  $\alpha_i$  in the constraint graph. Assume that  $\{w_1, w_2\} \not\subset U_{\alpha_i}$  and  $\{w_1, w_2\} \not\subset V_{\alpha_i}$ . Then  $\{w_1, w_2\} \not\in E(\alpha_i)$  if any of the following hold:

- $w_1$  is a left endpoint and  $w_2$  is a right endpoint.
- $w_1 \in U_{\alpha_1^\top}$ ,  $w_1$  is not incident to a constraint edge, and  $w_2$  is a left endpoint.
- $w_1 \in V_{\alpha_1^\top}$ ,  $w_1$  is not incident to a constraint edge, and  $w_2$  is a right endpoint.
- $w_1 \in U_{\alpha_i^{\top}}$  and  $w_2 \in V_{\alpha_i^{\top}}$  and both are not incident to a constraint edge.

The same conclusion holds when we replace  $\alpha_i$  with  $\alpha_i^{\top}$  in the statement.

*Proof.* Let us consider the first scenario: say  $w_1$  is a left endpoint and  $w_2$  is a right endpoint. Then all of the vertices which are equivalent to  $w_1$  are to the right of  $w_1$  and all vertices which are equivalent to  $w_2$  are to the left of  $w_2$  so if  $\{w_1, w_2\} \in E(\alpha_i)$  (and  $\{w_1, w_2\} \not\subset U_{\alpha_i}$  and  $\{w_1, w_2\} \not\subset V_{\alpha_i}$ ) then there is no way for the copy  $\{w_1, w_2\}$  to appear more than once so we have  $\operatorname{val}(C) = 0$ .

Following similar logic, we can show that in each of the other cases, there is no way for the copy  $\{w_1, w_2\}$  to appear more than once so we have val(C) = 0.

Using Claim B.5, we can characterize all left/right traversing paths within a single copy of  $\alpha$  in the constraint graph. More specifically, for  $i=1,2,\ldots,q$ , any path P from  $U_{\alpha_i}$  to  $V_{\alpha_i}$  within  $\alpha_i$  (respectively, from  $U_{\alpha_i^{\top}}$  to  $V_{\alpha_i^{\top}}$  within  $\alpha_i^{\top}$ ) satisfies one of the following:

- P contains at least one vertex that is incident with two constraint edges.
- All vertices in  $P \setminus V_{\alpha_i}$  (respectively,  $P \setminus V_{\alpha_i^\top}$ ) are left endpoints.
- All vertices in  $P \setminus U_{\alpha_i}$  (respectively,  $P \setminus V_{\alpha_i^{\top}}$ ) are right endpoints.

Consequently, one can construct the following vertex separators:

- Let  $S_i$  be the subset of  $\alpha_i$  consisting of left endpoints in  $U_{\alpha_i}$ , vertices in  $\alpha_i$  that are incident to two constraint edges, and right endpoints in  $V_{\alpha_i}$ . Then  $S_i$  is a vertex separator of  $\alpha_i$ .
- Similarly, define  $S_i'$  to be the subset of  $\alpha_i^{\top}$  consisting of left endpoints in  $U_{\alpha_i^{\top}}$ , vertices in  $\alpha_i^{\top}$  that are incident to two constraint edges, and right endpoints in  $V_{\alpha_i^{\top}}$ . Then,  $S_i'$  is a vertex separator of  $\alpha_i^{\top}$ .

Then, the following identity is straightforward from the construction:

$$(\mathbf{B.3}) = \frac{1}{2} \cdot \sum_{i=1}^{q} \left[ w(S_i) + w(S_i') \right]. \tag{B.6}$$

Now since  $S_i, S_i'$  are vertex separators of  $\alpha_i$  and  $\alpha_i^{\top}$ , it follows that

<span id="page-74-2"></span><span id="page-74-1"></span>
$$w(S_i), w(S_i') \ge w(S_{\min}). \tag{B.7}$$

Combining (B.6) with (B.7), we obtain (B.2), which proves (B.1) since we added superfluous constraint edges of total weight  $w(S_{\min})$  in the preprocessing step.

# <span id="page-75-0"></span>C Examples of shapes and ribbons

In this section, we provide examples that illustrate the concepts from Section 2.3. To begin with, we illustrate a shape without middle vertices and its corresponding ribbon.

<span id="page-75-2"></span>**Example C.1** (A shape without middle vertices). Let us choose the ground set N = [10]. Our first example of a shape is  $\alpha$  with  $U_{\alpha} = (u_1, u_2)$ ,  $V_{\alpha} = (v_1, v_2, v_3)$ , and  $E(\alpha) = \{\{u_1, u_2\}, \{u_2, v_1\}, \{u_2, v_3\}\}$ . The graphical representation of  $\alpha$  is provided in Figure 36a. Notice that we draw boxes around distinguished vertices  $V(U_{\alpha})$  and  $V(V_{\alpha})$ .

<span id="page-75-1"></span>This shape  $\alpha$  can be realized as a ribbon through a realization. For instance, consider a realization  $\sigma: \{u_1, u_2, v_1, v_2, v_3, w_1, w_2\} \rightarrow [10]$  defined as  $\sigma(u_1) = 5$ ,  $\sigma(u_2) = 1$ ,  $\sigma(v_1) = 7$ ,  $\sigma(v_2) = 9$ , and  $\sigma(v_3) = 3$ . Then,  $R = \sigma(\alpha)$  is the ribbon depicted in Figure 36b. Given this,  $\chi_R$  is equal to the product of  $\chi_e(G)$  for all edges e in Figure 36b.

![](_page_75_Picture_4.jpeg)

Figure 36a:  $\alpha$  from Example C.1.

Figure 36b: R from Example C.1

 $B_R$ 

9

3

Figure 36: A shape and a ribbon from Example C.1.

Next, we illustrate a shape with middle vertices and its corresponding ribbon.

<span id="page-75-3"></span>**Example C.2** (A shape with middle vertices and its realization). Let us choose the ground set N = [10]. Our first example of a shape is  $\alpha$  with  $U_{\alpha} = (u_1, u_2)$ ,  $V_{\alpha} = (v_1, v_2, v_3)$ ,  $W_{\alpha} = \{w_1\}$ , and  $E(\alpha) = \{\{u_1, w_1\}, \{u_2, w_1\}, \{v_1, w_1\}, \{v_2, w_1\}, \{v_3, w_1\}\}$ . The graphical representation of  $\alpha$  is provided in Figure 37a. Notice that we again draw boxes around distinguished vertices  $V(U_{\alpha})$  and  $V(V_{\alpha})$ .

This shape  $\alpha$  can be realized as a ribbon through a realization  $\sigma$ . For instance, consider a realization  $\sigma$ :  $\{u_1, u_2, v_1, v_2, v_3, w_1\} \rightarrow [10]$  defined as  $\sigma(u_1) = 5$ ,  $\sigma(u_2) = 1$ ,  $\sigma(v_1) = 7$ ,  $\sigma(v_2) = 9$ ,  $\sigma(v_3) = 3$ , and  $\sigma(w_1) = 2$ . Then,  $R = \sigma(\alpha)$  is the ribbon depicted in Figure 37b. Note that  $\chi_R$  is equal to the product of  $\chi_e(G)$  for all edges e in Figure 36b.

<span id="page-76-1"></span>![](_page_76_Figure_0.jpeg)

![](_page_76_Figure_1.jpeg)

Figure 37a:  $\alpha$  from Example C.2.

Figure 37b: R from Example C.2

Figure 37: A shape and a ribbon from Example C.2.

Lastly, we illustrate a shape with nonempty left/right intersection.

<span id="page-76-3"></span><span id="page-76-2"></span>**Example C.3** (A shape with left/right intersection). Note from Definition 2.12 that left and right vertices could intersect. To illustrate, let us add a single variable  $\nu_1$  to both  $V(U_{\alpha})$  and  $V(V_{\alpha})$  in Example C.1, and hence,  $U_{\alpha} = (u_1, u_2, \nu_1)$  and  $V_{\alpha} = (v_1, v_2, v_3, \nu_1)$ , and also an edge  $\{u_1, \nu_1\}$  to  $E(\alpha)$ . Then the resulting shape satisfies  $V(U_{\alpha}) \cap V(V_{\alpha}) = \nu_1$ . The graphical representation of the resulting shape is provided in Figure 38. Here and below, we reserve the notation  $\nu$  for such vertices in the left/right intersection.

![](_page_76_Figure_7.jpeg)

Figure 38: A shape  $\alpha$  with left/right intersection from Example C.3.

# <span id="page-76-0"></span>D More examples of graph matrices and their norm bounds

In this section, we provide more examples of graph matrices and their norm bounds.

<span id="page-76-4"></span>**Example D.1.** Consider  $V(\alpha) = \{u_1, v_1, v_2, w_1\}$ ,  $U_{\alpha} = (u_1)$ ,  $V_{\alpha} = (v_1, v_2)$ ,  $W_{\alpha} = \{w_1\}$  and  $E(\alpha) = \{\{u_1, w_1\}, \{v_1, w_1\}, \{v_2, w_1\}\}$ . The graphical representation of  $\alpha$  is provided in Figure 39a.

Then,  $M_{\alpha}$  is an  $n \times n(n-1)$  matrix such that for  $a, b_1, b_2 \in [n]$   $(b_1 \neq b_2)$ , the  $(a, (b_1, b_2))$ -th entry is defined as

<span id="page-77-1"></span>
$$M_{\alpha}(a,(b_{1},b_{2})) = \begin{cases} \sum_{c_{1} \in [n] \setminus \{a,b_{1},b_{2}\}} \chi_{\{a,c_{1}\}} \chi_{\{b_{1},c_{1}\}} \chi_{\{b_{2},c_{1}\}}, & a \neq b_{1} \text{ and } a \neq b_{2}, \\ 0, & otherwise. \end{cases}$$
(D.1)

Now let us consider the shape  $\alpha'$  obtained from  $\alpha$  by adding an isolated vertex  $w_2$  to  $W_{\alpha}$ . The graphical representation of  $\alpha'$  is provided in Figure 39b. Then, one can easily verify that for  $a, b_1, b_2 \in [n]$   $(b_1 \neq b_2)$ , the  $(a, (b_1, b_2))$ -th entry is defined as:

$$M_{\alpha'}(a,(b_{1},b_{2})) = \begin{cases} \sum_{c_{1} \in [n] \setminus \{a,b_{1},b_{2}\}} \sum_{c_{2} \in [n] \setminus \{a,b_{1},b_{2},c_{1}\}} \chi_{\{a,c_{1}\}} \chi_{\{b_{1},c_{1}\}} \chi_{\{b_{2},c_{1}\}}, & a \neq b_{1} \text{ and } a \neq b_{2}, \\ 0, & otherwise. \end{cases}$$

$$= \begin{cases} (n-4) \cdot \sum_{c_{1} \in [n] \setminus \{a,b_{1},b_{2}\}} \chi_{\{a,c_{1}\}} \chi_{\{b_{1},c_{1}\}} \chi_{\{b_{2},c_{1}\}}, & a \neq b_{1} \text{ and } a \neq b_{2}, \\ 0, & otherwise. \end{cases}$$

$$(D.2)$$

<span id="page-77-0"></span>Notice the similarity between (D.1) and (D.2): indeed, one can conclude  $M_{\alpha} = (n-4) \cdot M_{\alpha'}$ . This similarity will play a crucial role in reducing the case with isolated middle vertices to the case without them; see Section 6.3.

![](_page_77_Figure_5.jpeg)

Figure 39a: Shape  $\alpha$  from Example D.1

<span id="page-77-2"></span>Figure 39b: Shape  $\alpha'$  from Example D.1

Figure 39: Shapes from Examples D.1.

Now we illustrate Theorem 2.24 for the graph matrix presented in Example D.1.

**Example D.2** (Revisiting Example D.1). For shape  $\alpha$  from Example D.1,  $\{w_1\}$  is a minimum size vertex separator, which implies s=1. By Theorem 2.24, with high probability,  $\|M_{\alpha}\| \leq \widetilde{O}(n^{\frac{3}{2}})$ . Now let us consider shape  $\alpha'$ . For  $\alpha'$ , there is one isolated middle vertex, and consequently by the second statement of Theorem 2.24,  $\|M_{\alpha}\| \leq \widetilde{O}(n^{\frac{3}{2}+1}) = \widetilde{O}(n^{\frac{5}{2}})$  with high probability. This is consistent with the observation we made in Example D.1:  $M_{\alpha'} = (n-4) \cdot M_{\alpha}$ 

We also illustrate Theorem 2.24 for the graph matrices corresponding to the shapes from Appendix C.

**Example D.3** (Revisiting Examples C.1, C.2 and C.3). For the shape  $\alpha$  from Example C.1,  $\{u_2\}$  is a minimum size vertex separator, so s = 1. By Theorem 2.24,  $||M_{\alpha}|| \leq \widetilde{O}(n^2)$  with high probability.

Next, for the shape  $\alpha$  from Example C.2,  $\{w_1\}$  is a minimum size vertex separator, so  $\|M_\alpha\| \leq \widetilde{O}(n^{5/2})$  with high probability. Lastly, for the shape  $\alpha$  from Example C.3,  $\{w_1, \nu_1\}$  is a minimum size vertex separator, and hence,  $\|M_\alpha\| \leq \widetilde{O}(n^{5/2})$  with high probability. Notice that the graph matrices corresponding to shapes from Example C.2 and C.3 have the norm bound of the same order. This similarity is not conincidental, and will be formalized in our proof via the reduction argument; see Section 6.2.

## References

- <span id="page-78-1"></span>[ABS15] Sanjeev Arora, Boaz Barak, and David Steurer. Subexponential algorithms for unique games and related problems. *Journal of the ACM (JACM)*, 62(5):1–25, 2015.
- <span id="page-78-0"></span>[ARV09] Sanjeev Arora, Satish Rao, and Umesh Vazirani. Expander flows, geometric embeddings and graph partitioning. *Journal of the ACM (JACM)*, 56(2):1–37, 2009.
- <span id="page-78-7"></span>[BBH<sup>+</sup>12] Boaz Barak, Fernando GSL Brandao, Aram W Harrow, Jonathan Kelner, David Steurer, and Yuan Zhou. Hypercontractivity, sum-of-squares proofs, and their applications. In *Proceedings of the forty-fourth annual ACM symposium on Theory of computing*, pages 307–326, 2012.
- <span id="page-78-9"></span>[BGG<sup>+</sup>17] Vijay Bhattiprolu, Mrinalkanti Ghosh, Venkatesan Guruswami, Euiwoong Lee, and Madhur Tulsiani. Weak decoupling, polynomial folds and approximate optimization over the sphere. In the 58th Annual Symposium on Foundations of Computer Science (FOCS), pages 1008–1019. IEEE, 2017.
- <span id="page-78-8"></span>[BGL17] Vijay Bhattiprolu, Venkatesan Guruswami, and Euiwoong Lee. Sum-of-squares certificates for maxima of random tensors on the sphere. In *APPROX-RANDOM*, Leibniz International Proceedings in Informatics (LIPIcs), pages 31:1–31:20, 2017.
- <span id="page-78-6"></span>[BHK<sup>+</sup>19] Boaz Barak, Samuel Hopkins, Jonathan Kelner, Pravesh K Kothari, Ankur Moitra, and Aaron Potechin. A nearly tight sum-of-squares lower bound for the planted clique problem. SIAM Journal on Computing, 48(2):687–735, 2019.
- <span id="page-78-5"></span>[BK20] Ainesh Bakshi and Pravesh Kothari. Outlier-robust clustering of non-spherical mixtures. arXiv preprint arXiv:2005.02970, 2020.
- <span id="page-78-2"></span>[BKS14] Boaz Barak, Jonathan A Kelner, and David Steurer. Rounding sum-of-squares relaxations. In *Proceedings of the forty-sixth annual ACM symposium on Theory of computing*, pages 31–40, 2014.
- <span id="page-78-3"></span>[BKS15] Boaz Barak, Jonathan A Kelner, and David Steurer. Dictionary learning and tensor decomposition via the sum-of-squares method. In *Proceedings of the forty-seventh annual ACM symposium on Theory of computing*, pages 143–151, 2015.
- <span id="page-78-4"></span>[BKS17] Boaz Barak, Pravesh K Kothari, and David Steurer. Quantum entanglement, sum of squares, and the log rank conjecture. In *Proceedings of the 49th Annual ACM SIGACT Symposium on Theory of Computing*, pages 975–988, 2017.

- <span id="page-79-6"></span>[BM16] Boaz Barak and Ankur Moitra. Noisy tensor completion via the sum-of-squares hierarchy. In Conference on Learning Theory, pages 417–445, 2016.
- <span id="page-79-3"></span>[BRS11] Boaz Barak, Prasad Raghavendra, and David Steurer. Rounding semidefinite programming hierarchies via global correlation. In 2011 ieee 52nd annual symposium on foundations of computer science, pages 472–481. IEEE, 2011.
- <span id="page-79-8"></span>[BS14] Boaz Barak and David Steurer. Sum-of-squares proofs and the quest toward optimal algorithms. arXiv preprint arXiv:1404.5236, 2014.
- <span id="page-79-11"></span>[BY88] Zhi-Dong Bai and Yong-Qua Yin. Necessary and sufficient conditions for almost sure convergence of the largest eigenvalue of a wigner matrix. The Annals of Probability, pages 1729–1741, 1988.
- <span id="page-79-10"></span>[CP20] Wenjun Cai and Aaron Potechin. The spectrum of the singular values of Z-shaped graph matrices. arXiv preprint arXiv:2006.14144, 2020.
- <span id="page-79-7"></span>[DHKK20] Ilias Diakonikolas, Samuel B Hopkins, Daniel Kane, and Sushrut Karmalkar. Robustly learning any clusterable mixture of gaussians. arXiv preprint arXiv:2005.06417, 2020.
- <span id="page-79-12"></span>[dlPMS95] Victor H de la Pe˜na and Stephen J Montgomery-Smith. Decoupling inequalities for the tail probabilities of multivariate u-statistics. The Annals of Probability, pages 806–816, 1995.
- [DM15] Yash Deshpande and Andrea Montanari. Improved sum-of-squares lower bounds for hidden clique and hidden submatrix problems. In Conference on Learning Theory, pages 523–562, 2015.
- <span id="page-79-0"></span>[Gir85] Vyacheslav L Girko. Circular law. Theory of Probability & Its Applications, 29(4):694– 706, 1985.
- <span id="page-79-9"></span>[GJJ+20] Mrinalkanti Ghosh, Fernando Granha Jeronimo, Chris Jones, Aaron Potechin, and Goutham Rajendran. Sum-of-squares lower bounds for Sherrington-Kirkpatrick via planted affine planes. arXiv preprint arXiv:2009.01874, 2020.
- <span id="page-79-5"></span>[GM15] Rong Ge and Tengyu Ma. Decomposing overcomplete 3rd order tensors using sumof-squares algorithms. In APPROX-RANDOM, Leibniz International Proceedings in Informatics (LIPIcs), pages 829–849, 2015.
- <span id="page-79-1"></span>[Gri01a] Dima Grigoriev. Complexity of positivstellensatz proofs for the knapsack. Computational Complexity, 10(2):139–154, 2001.
- <span id="page-79-2"></span>[Gri01b] Dima Grigoriev. Linear lower bound on degrees of positivstellensatz calculus proofs for the parity. Theoretical Computer Science, 259(1-2):613–622, 2001.
- <span id="page-79-4"></span>[GS11] Venkatesan Guruswami and Ali Kemal Sinop. Lasserre hierarchy, higher eigenvalues, and approximation schemes for graph partitioning and quadratic integer programming with PSD objectives. In 2011 IEEE 52nd Annual Symposium on Foundations of Computer Science, pages 482–491. IEEE, 2011.

- <span id="page-80-5"></span>[GW95] Michel X Goemans and David P Williamson. Improved approximation algorithms for maximum cut and satisfiability problems using semidefinite programming. Journal of the ACM (JACM), 42(6):1115–1145, 1995.
- [HKP15] Samuel B Hopkins, Pravesh K Kothari, and Aaron Potechin. Sos and planted clique: Tight analysis of MPW moments at all degrees and an optimal lower bound at degree four. arXiv preprint arXiv:1507.05230, 2015.
- [HL18] Samuel B Hopkins and Jerry Li. Mixture models, robustness, and sum of squares proofs. In Proceedings of the 50th Annual ACM SIGACT Symposium on Theory of Computing, pages 1021–1034, 2018.
- <span id="page-80-6"></span>[HSSS16] Samuel B Hopkins, Tselil Schramm, Jonathan Shi, and David Steurer. Fast spectral algorithms from sum-of-squares proofs: tensor decomposition and planted sparse vectors. In Proceedings of the forty-eighth annual ACM symposium on Theory of Computing, pages 178–191, 2016.
- <span id="page-80-9"></span>[Kon31] D´enes Konig. Gr´afok ´es m´atrixok. Matematikai ´es Fizikai Lapok, 38:116–119, 1931.
- [KSS18] Pravesh K Kothari, Jacob Steinhardt, and David Steurer. Robust moment estimation and improved clustering via sum of squares. In Proceedings of the 50th Annual ACM SIGACT Symposium on Theory of Computing, pages 1035–1046, 2018.
- <span id="page-80-4"></span>[Las01] Jean B Lasserre. Global optimization with polynomials and the problem of moments. SIAM Journal on optimization, 11(3):796–817, 2001.
- <span id="page-80-10"></span>[Men27] Karl Menger. Zur allgemeinen kurventheorie. Fundamenta Mathematicae, 10(1):96–115, 1927.
- <span id="page-80-0"></span>[MG60] Madan Lal Mehta and Michel Gaudin. On the density of eigenvalues of a random matrix. Nuclear Physics, 18:420–427, 1960.
- <span id="page-80-1"></span>[MP16] Dhruv Medarametla and Aaron Potechin. Bounds on the Norms of Uniform Low Degree Graph Matrices. In Klaus Jansen, Claire Mathieu, Jos´e D. P. Rolim, and Chris Umans, editors, Approximation, Randomization, and Combinatorial Optimization. Algorithms and Techniques (APPROX/RANDOM 2016), volume 60 of Leibniz International Proceedings in Informatics (LIPIcs), pages 40:1–40:26, Dagstuhl, Germany, 2016. Schloss Dagstuhl–Leibniz-Zentrum fuer Informatik.
- <span id="page-80-8"></span>[MPW15] Raghu Meka, Aaron Potechin, and Avi Wigderson. Sum-of-squares lower bounds for planted clique. In Proceedings of the forty-seventh annual ACM symposium on Theory of computing, pages 87–96, 2015.
- <span id="page-80-2"></span>[Nes00] Yurii Nesterov. Squared functional systems and optimization problems. In High performance optimization, pages 405–440. Springer, 2000.
- <span id="page-80-3"></span>[Par00] Pablo A Parrilo. Structured semidefinite programs and semialgebraic geometry methods in robustness and optimization. PhD thesis, California Institute of Technology, 2000.
- <span id="page-80-7"></span>[PS17] Aaron Potechin and David Steurer. Exact tensor completion with sum-of-squares. In Proceedings of Conference on Learning Theory (COLT), pages 1619–1673, 2017.

- <span id="page-81-5"></span>[RRS17] Prasad Raghavendra, Satish Rao, and Tselil Schramm. Strongly refuting random csps below the spectral threshold. In Proceedings of the 49th Annual ACM SIGACT Symposium on Theory of Computing, pages 121–131, 2017.
- [RS15] Prasad Raghavendra and Tselil Schramm. Tight lower bounds for planted clique in the degree-4 sos program. arXiv preprint arXiv:1507.05136, 2015.
- <span id="page-81-2"></span>[Sho87] Naum Z Shor. Class of global minimum bounds of polynomial functions. Cybernetics, 23(6):731–734, 1987.
- <span id="page-81-3"></span>[Sos99] Alexander Soshnikov. Universality at the edge of the spectrum in wigner random matrices. Communications in mathematical physics, 207(3):697–733, 1999.
- <span id="page-81-4"></span>[Tao12] Terence Tao. Topics in random matrix theory, volume 132. American Mathematical Soc., 2012.
- <span id="page-81-1"></span>[TW94] Craig A Tracy and Harold Widom. Level-spacing distributions and the airy kernel. Communications in Mathematical Physics, 159(1):151–174, 1994.
- <span id="page-81-0"></span>[Wig58] Eugene P Wigner. On the distribution of the roots of certain symmetric matrices. Annals of Mathematics, pages 325–327, 1958.

# Acknowledgements

This research was initially supported by the Program for Research in Mathematics, Engineering, and Science (PRIMES) at MIT. We thank the PRIMES faculty, including Dr. Tanya Khovanova, Dr. Pavel Etingof, and Dr. Slava Gerovitch for helpful feedback during the initial stage of this work. We also thank Laci Babai, Fernando Granha Jeronimo, and Chris Jones for helpful comments on this manuscript.