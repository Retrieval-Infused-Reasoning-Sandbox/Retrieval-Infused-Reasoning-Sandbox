# <span id="page-0-0"></span>SQ Lower Bounds for Random Sparse Planted Vector Problem

*ETH Zurich ¨*

Jingqiu Ding JINGQIU.DING@INF.ETHZ.CH

Yiding Hua YIDHUA@STUDENT.ETHZ.CH

*ETH Zurich ¨*

Editors: Shipra Agrawal and Francesco Orabona

## Abstract

Consider the setting where a ρ-sparse Rademacher vector is planted in a random d-dimensional subspace of R <sup>n</sup>. A classical question is how to recover this planted vector given a random basis in this subspace.

A recent result by [Zadik et al.](#page-18-0) [\(2021\)](#page-18-0) showed that the Lattice basis reduction algorithm can recover the planted vector when n ⩾ d + 1. Although the algorithm is not expected to tolerate inverse polynomial amount of noise, it is surprising because it was previously shown that recovery cannot be achieved by low degree polynomials when n ≪ ρ 2d 2 [\(Mao and Wein,](#page-18-1) [2021\)](#page-18-1).

A natural question is whether we can derive an Statistical Query (SQ) lower bound matching the previous low degree lower bound in [Mao and Wein](#page-18-1) [\(2021\)](#page-18-1). This will

- imply that the SQ lower bound can be surpassed by lattice based algorithms;
- predict the computational hardness when the planted vector is perturbed by inverse polynomial amount of noise.

In this paper, we prove such an SQ lower bound. In particular, we show that super-polynomial number of VSTAT queries is needed to solve the easier statistical testing problem when n ≪ ρ 2d 2 and ρ ≫ <sup>√</sup> 1 d . The most notable technique we used to derive the SQ lower bound is the almost equivalence relationship between SQ lower bound and low degree lower bound [\(Brennan et al.,](#page-16-0) [2020;](#page-16-0) [Mao and Wein,](#page-18-1) [2021\)](#page-18-1).

Keywords: Statistical Query lower bound, Sparse Recovery.

## 1. Introduction

The Random Sparse Planted Vector problem is to recover a sparse planted vector x from a ddimensional subspace of R n that is spanned by x and d − 1 spherical random vectors. This problem is interesting in its own and is also closely related to a wide range of problems in data science and statistics, including sparse PCA, Non-Gaussian Component Analysis, Dictionary Learning, etc. There has been significant interest in this problem, leading to algorithms and lower bounds [\(De](#page-17-0)[manet and Hand,](#page-17-0) [2014;](#page-17-0) [Barak et al.,](#page-16-1) [2014;](#page-16-1) [Qu et al.,](#page-18-2) [2014;](#page-18-2) [Hopkins et al.,](#page-18-3) [2016;](#page-18-3) [Qu et al.,](#page-18-4) [2020\)](#page-18-4).

A fascinating phenomenon was discovered recently for the Random Sparse Planted Vector problem. In [Mao and Wein](#page-18-1) [\(2021\)](#page-18-1), an unconditional lower bound against algorithms based on low degree polynomial was developed for the special case where vector x is {±1, 0} vector, which provides evidence of computational hardness. Later in [Zadik et al.](#page-18-0) [\(2021\)](#page-18-0); [Diakonikolas and Kane](#page-17-1) [\(2021\)](#page-17-1), it was surprisingly found that, the Lenstra–Lenstra–Lovasz (LLL) lattice basis reduction algorithm ´ can surpass the low degree lower bound for this instance. The algorithm crucially exploits the fact that the planted vector is integral.

A natural question is whether some other common algorithm frameworks can capture algorithms based on the LLL lattice basis reduction. One promising candidate is Statistical Query (SQ) algorithms. In some cases, the SQ framework can be more powerful than low degree polynomials, e.g. it can simulate some inefficient algorithms since these algorithms have access to some inefficient oracles. As a matter of fact, to our knowledge, before our work there was no known instance where lattice basis reduction algorithm surpasses SQ lower bound. Therefore, we aim to answer the following question in our paper.

**Question 1** Can algorithms based on the LLL lattice basis reduction surpass Statistical Query lower bound in Random Sparse Planted Vector problem?

We give an affirmative answer to this question by deriving an SQ lower bound falling short of matching the guarantees of the lattice-based algorithm in Zadik et al. (2021). More concretely, the SQ lower bound we derive in this paper indicates similar computational hardness as the previous low degree lower bound in Mao and Wein (2021). This provides another natural example for the almost equivalence between SQ algorithms and low degree algorithms that has been characterized in Brennan et al. (2020).

#### 1.1. Models

Throughout the paper, we will use n to denote the dimension of the hidden vector and d to denote the dimension of the subspace where the hidden vector is planted in. For ease of formalization and comparison to previous work, we will focus on the case where the planted vector is Bernoulli-Rademacher, which is defined below.

**Definition 1 (Bernoulli-Rademacher Vector)** A random variable  $\omega \in \mathbb{R}$  is Bernoulli-Rademacher with parameter  $\rho \in (0,1]$  if

<span id="page-1-1"></span><span id="page-1-0"></span>
$$\omega = \begin{cases} 1/\sqrt{\rho} & \text{with probability } \rho/2 \\ -1/\sqrt{\rho} & \text{with probability } \rho/2 \\ 0 & \text{with probability } 1-\rho \end{cases}$$

A random vector  $x \in \mathbb{R}^n$  is Bernoulli-Rademacher with parameter  $\rho$ , denoted by  $x \sim BR(n, \rho)$ , if the entries of x are i.i.d Bernoulli-Rademacher with parameter  $\rho$ .

Notice that our definition for Bernoulli-Rademacher vector is not scaled, i.e.  $\mathbb{E}[\|x\|_2^2] = n$ . Now, we give the precise definition of the (noisy) Sparse Planted Vector problem.

**Model 1** ((Noisy) Sparse Planted Vector Problem) Given a hidden Bernoulli-Rademacher vector  $x \sim BR(n,\rho)$  and d i.i.d. standard Gaussian vectors  $v_0, v_1, v_2, \ldots, v_{d-1} \sim N(0, \mathrm{Id}_n)$ , for an arbitrary  $\sigma \geqslant 0$  (which can depend on d), let  $Z \in \mathbb{R}^{n \times d}$  be the matrix whose columns are  $x + \sigma v_0$  and  $\{v_i\}_{i \in \{1,2,\ldots,d-1\}}$ , i.e.  $Z = [x + \sigma v_0, v_1, v_2, \ldots, v_{d-1}]$ . After observing a rotated matrix  $\tilde{Z} = ZR$ , the goal is to recover the hidden  $\rho$ -sparse vector x.

When  $\sigma = 0$  (which corresponds to the noiseless setting), the planted vector is  $\rho$ -sparse. When  $\sigma$  is small, the planted vector in the subspace is close to a  $\rho$ -sparse vector.

To study the SQ lower bound, we equivalently formulate it as a multi-sample model.

Model 2 (Multi-Sample version) *Given a hidden random unit vector* u ∈ R d *, for an arbitrary* σ ⩾ 0*, we observe* n *independent samples* {z˜i}i∈[n] *such that*

$$\tilde{z}_i \sim N(x_i u, \mathrm{Id}_d - u u^T + \sigma^2 u u^\top)$$

*where* x ∼ BR(n, ρ) *is a hidden Bernoulli-Rademacher vector. For simplicity, we denote the observation as* Z˜ ∈ R <sup>n</sup>×<sup>d</sup> *where the rows are the samples* {z˜i}i∈[n] *. The goal is to recover the hidden vector* x *given observation* Z˜*.*

As pointed out in Lemma 4.21 of [Mao and Wein](#page-18-1) [\(2021\)](#page-18-1), when σ = 0, [Model 1](#page-1-0) and [Model 2](#page-1-1) are equivalent. Using a similar proof (see [Appendix A.1](#page-19-0) for details), it is easy to show that this equivalence also holds when σ ̸= 0.

### 1.2. Estimation and hypothesis testing

There are two types of problems that are of particular interest in the models we consider: estimation and hypothesis testing. Estimation problem aims to recover the planted vector given the observations, while hypothesis testing problem tries to distinguish whether the observations are sampled from the planted distribution or from a null distribution. More precisely, we define the two problems as follows.

<span id="page-2-1"></span>Problem 1 (Estimation) *Under [Model 2,](#page-1-1) given observation* Z˜*, the goal is to estimate or exactly recover the hidden Bernoulli-Rademacher vector* x*.*

<span id="page-2-0"></span>Problem 2 (Hypothesis testing) *Given dimension* d ∈ N*, sample size* n ∈ N *and sparsity* ρ ∈ (0, 1]*, define the following null and planted distributions:*

- *– Under* Q*, observe* Z˜ ∈ R <sup>n</sup>×<sup>d</sup> *whose entries are i.i.d. sampled from standard Gaussian* N(0, 1)*.*
- *– Under* P*, observe* Z˜ *which is sampled from [Model 2.](#page-1-1)*

*The goal is to determine whether the observations are sampled from* Q *or* P*.*

In this work, we will compute the SQ lower bound for the hypothesis testing problem. Then, we will show that the hypothesis testing problem can be reduced to estimation problem, which means lower bounds of the hypothesis testing problem also serve as lower bounds of the estimation problem.

### 1.3. Statistical Query framework

In this paper, we study computational lower bounds for [Model 2](#page-1-1) under the Statistical Query (SQ) framework. The SQ model is a popular computational model in the study of high dimension statistics, including planted clique problem [\(Feldman et al.,](#page-17-2) [2017\)](#page-17-2), random satisfiability problems [\(Feld](#page-17-3)[man et al.,](#page-17-3) [2018\)](#page-17-3), robust Gaussian mixtures [\(Diakonikolas et al.,](#page-17-4) [2017a\)](#page-17-4), etc.

The SQ framework is a restricted computational model where a learning algorithm can make certain types of queries to an oracle and get answers that are subject to certain degree of noise [\(Kearns,](#page-18-5) [1998\)](#page-18-5). We will focus on the SQ model with VSTAT queries which is used in [Brennan et al.](#page-16-0) [\(2020\)](#page-16-0), where the learning algorithm has access to the VSTAT oracle as defined below.

**Definition 2 (VSTAT Oracle)** Given query  $\phi: \mathbb{R}^d \to [0,1]$  and distribution D over  $\mathbb{R}^d$ , the VSTAT(n) oracle returns  $\mathbb{E}_{x \sim D}[\phi(x)] + \zeta$  for an adversarially chosen  $\zeta \in \mathbb{R}$  such that  $|\zeta| \leq \max\left(\frac{1}{n}, \sqrt{\frac{\mathbb{E}[\phi](1 - \mathbb{E}[\phi])}{n}}\right)$ .

One way to show SQ lower bound is by computing statistical dimension of the hypothesis testing problem, which is a measure on the complexity of the testing problem. In this paper, we use the following definition of statistical dimension introduced by Feldman et al. (2017).

**Definition 3 (Statistical Dimension)** Let  $\mu_{\emptyset}$  be some distribution with  $\mathcal{D}_{\emptyset}$  as density function. Let  $\mathcal{S} = \{\mu_u\}$  be some family of distributions indexed by u, such that  $\mu_u$  has density function given by  $\mathcal{D}_u$ . Consider the hypothesis testing problem between

- Null hypothesis: samples  $z_1, z_2, \ldots, z_n \sim \mu_{\emptyset}$ ;
- Alternative hypothesis:  $z_1, z_2, \ldots, z_n \sim \mu_u$  where u is sampled from some prior distribution  $\mu$ .

For  $D_u \in \mathcal{S}$ , define the relative density  $\bar{D}_u(x) = \frac{D_u(x)}{D_\theta(x)}$  and the inner product  $\langle f, g \rangle = \mathbb{E}_{x \sim D_\theta}[f(x)g(x)]$ . The statistical dimension  $SDA(\mathcal{S}, \mu, n)$  measures the tail of  $\langle \bar{D}_u, \bar{D}_v \rangle - 1$  with u, v drawn independently from  $\mu$ :

$$SDA(\mathcal{S}, \mu, n) = \max \left\{ q \in \mathbb{N} : \underset{u,v \sim \mu}{\mathbb{E}} \left[ \left| \langle \bar{D}_u, \bar{D}_v \rangle - 1 \middle| | A \right] \leqslant \frac{1}{m} \text{ for all events A s.t. } \underset{u,v \in \mu}{\mathbb{P}} (A) \geqslant \frac{1}{q^2} \right\}$$

<span id="page-3-1"></span>We will use SDA(n) or SDA(S,n) when S and/or  $\mu$  are clear from the context. In Feldman et al. (2017), it was shown that the statistical dimension is a lower bound on the SQ complexity of the hypothesis test using VSTAT oracle.

**Theorem 1** (Theorem 2.7 of Feldman et al. (2017), Theorem A.5 of Brennan et al. (2020)) Let  $D_{\emptyset}$  be a null distribution and S be a set of alternative distribution. Then any (randomised) statistical query algorithm which solves the hypothesis testing problem of  $D_{\emptyset}$  vs S with probability at least  $1 - \delta$  requires at least  $(1 - \delta)SDA(S, m)$  queries to  $VSTAT(\frac{m}{3})$ .

#### 1.4. Our results

We prove an SQ lower bound for distinguishing samples from Model 2 and from standard Gaussian distribution.

<span id="page-3-0"></span>**Theorem 2 (SQ hardness of testing in noiseless model)** For  $\sigma = 0$ , consider the distinguishing problem between

- planted distribution  $\mathcal{P}$ : the family of distributions  $\mathcal{S}$  parameterized by u as described in Model 2;
- null distribution Q: standard Gaussian  $N(0, \mathrm{Id}_d)$ .

When  $\rho^2 d^{1.99} \leqslant n \leqslant \frac{\rho^2 d^2}{\operatorname{poly} \log d}$ , we have

$$SDA(S, n) \geqslant \exp\left(\left(\frac{\rho^2 d^2}{n \operatorname{poly} \log d}\right)^{0.1}\right)$$

As a by-product of our proof for Theorem 2, we also prove the same SQ lower bound for the noisy case, i.e.  $\sigma > 0$ .

<span id="page-4-0"></span>**Theorem 3 (SQ hardness of testing in noisy model)** For arbitrary  $0 < \sigma < d^{-100}$ , consider the distinguishing problem between

- planted distribution  $\mathcal{P}$ : the family of distributions  $\mathcal{S}$  parameterized by u as described in Model 2;
- null distribution Q: standard Gaussian  $N(0, \mathrm{Id}_d)$ .

When  $\rho^2 d^{1.99} \leqslant n \leqslant \frac{\rho^2 d^2}{\operatorname{poly} \log d}$ , we have

$$SDA(S, n) \geqslant \exp\left(\left(\frac{\rho^2 d^2}{n \operatorname{poly} \log d}\right)^{0.1}\right)$$

**Implication** Notice that, when  $n = \rho^2 d^{1.99}$  and  $\rho \geqslant \frac{1}{d^{0.499}}$ , we have:

$$SDA(S, \rho^2 d^{1.99}) \geqslant \exp(d^{0.001})$$
.

This implies that, any SQ algorithm to solve the testing problem  $D_{\emptyset}$  vs  $D_u$  with probability at least 1-o(1) requires at least  $(1-o(1))\exp\left(d^{0.001}\right)$  queries to VSTAT $(\Theta\left(\rho^2d^{1.99}\right))$ , which corresponds to  $\Theta\left(\rho^2d^{1.99}\right)$  samples.

In previous work (Zadik et al., 2021; Diakonikolas and Kane, 2021), it has been shown that lattice-based algorithm can estimate the component vector x when  $\sigma \leqslant \exp(-\Omega(d))$  and  $n \geqslant \Omega(d)$ . As we will prove in Theorem 6, there is a polynomial time reduction from testing to estimation. Therefore, there is a polynomial-time testing algorithm that is based on the LLL algorithm and can solve the testing problem Problem 2 using  $n \geqslant \Omega(d)$  samples when  $\sigma \leqslant \exp(-\Omega(d))$ . Thus, when  $\rho \gg \frac{1}{\sqrt{d}}$ , the lattice-based algorithm succeeds while the SQ lower bound predicts the problem to be computationally hard. Thus, we can conclude that the LLL algorithm surpasses SQ lower bounds in this problem.

#### 1.5. Background and prior work

### 1.5.1. FAILURE OF SQ LOWER BOUND

Although the majority of machine learning algorithms are captured by SQ algorithm, Gaussian elimination and its alike can surpass SQ lower bounds. A celebrated scenario for the failure of SQ lower bound is learning parity function (Blum et al., 2003). It is worth mentioning that, very recently, the SQ lower bound was also found to fall short in asymmetric tensor PCA model (Dudeja and Hsu, 2021).

### 1.5.2. ALGORITHM RESULTS FOR SPARSE PLANTED VECTOR PROBLEM

For the Random Sparse Planted Vector problem we consider here, it has been shown that the  $l_1/l_2$  minimization problem recovers the planted vector as long as  $\rho \leqslant c$  and  $d \leqslant cn$  for a sufficiently small constant c (Qu et al., 2014). However, the  $l_1/l_2$  minimization problem is non-convex and is computationally expensive. The Sum-of-Squares method proposed in Barak et al. (2014) estimates

the planted vector based on the  $l_2/l_4$  minimization problem in the region  $\rho \leqslant c$  and  $d\sqrt{\rho} \leqslant c\sqrt{n}$ . Inspired by the Sum-of-Squares method, a fast spectral method to estimate the planted vector was proposed in Hopkins et al. (2016) which works in the region  $\rho \leqslant c$  and  $d \ll \sqrt{n}$ . The optimal spectral algorithm was proposed in Mao and Wein (2021) which builds on Hopkins et al. (2016) and recovers the planted vector when  $n \geqslant \tilde{\Omega}\left(\rho^2 d^2\right)$ . Very surprisingly, it was recently shown in Zadik et al. (2021); Diakonikolas and Kane (2021) that lattice-based algorithms can recover the planted sparse vector when  $n \geqslant \Omega(d)$ , which surpasses previous lower bound on low degree polynomials.

#### 1.5.3. COMPUTATIONAL LOWER BOUNDS

For the Random Sparse Planted Vector problem (with  $\sigma=0$ ), it was shown in Mao and Wein (2021) that low-degree polynomial algorithms fail when  $n\leqslant \tilde{O}\left(\rho^2d^2\right)$ . When the sparsity  $\rho=1$ , i.e. the planted vector is Rademacher, Sum-of-Squares lower bound is proved for  $n\ll d^{3/2}$  in Davis et al. (2021). These lower bounds are surpassed by the aforementioned lattice-based algorithm in Zadik et al. (2021). For the noisy case  $\sigma\neq 0$ , similar low degree lower bound has been obtained in d'Orsi et al. (2020b); Chen and d'Orsi (2022).

#### 1.5.4. RELATION TO NON-GAUSSIAN COMPONENT ANALYSIS

The Random Sparse Planted Vector problem can be considered as a special case of non-Gaussian component analysis. In such class of models, conditioning on a hidden direction  $u \in \mathbb{R}^d$ , the samples  $z_1, z_2, \ldots, z_n$  are i.i.d randomly distributed d-dimensional vectors. The projection of  $z_i$  in the direction perpendicular to u follows standard Gaussian distribution, while  $\langle z_i, u \rangle$  follows some specified non-Gaussian distribution. The problem is to estimate the hidden direction u.

Another famous Non-Gaussian component analysis model is homogeneous continuous learning with error (hCLWE) (Bruna et al., 2021). There are SQ lower bounds for this model when inverse polynomial amount of Gaussian noise is added to the hidden direction (Diakonikolas et al., 2017b,a). However, note that lattice-based algorithms are not believed to be robust against inverse polynomial amount of noise (Zadik et al., 2021; Diakonikolas and Kane, 2021). Therefore, we cannot conclude that the LLL algorithm surpasses SQ lower bound in their setting.

#### 2. Preliminaries

#### 2.1. Notations

Let  $D_{\emptyset}$  vs  $\mathcal{S} = \{D_u\}_{u \sim \nu}$  be a hypothesis testing problem with prior  $\nu$ . We write  $\bar{D}_u(z) = \frac{D_u(z)}{D_{\emptyset}(z)}$  to refer to the likelihood ratio or relative density. For real valued functions f and g, we define their inner product with respect to distribution  $D_{\emptyset}$  to be  $\langle f, g \rangle_{D_{\emptyset}} = \mathbb{E}_{z \sim D_{\emptyset}}[f(z)g(z)]$ , we write  $\langle f, g \rangle$  when  $D_{\emptyset}$  is clear from context. The corresponding norm of the inner product is  $\|f\|_{D_{\emptyset}} = \sqrt{\langle f, f \rangle_{D_{\emptyset}}}$ 

For distribution D and integer k, we write  $D^{\otimes k}$  to denote the density function of the joint distribution of k independent samples from D. From the definition of inner product and independence of samples, we have:

$$\langle f^{\otimes k}, g^{\otimes k} \rangle_{D_{\emptyset}^{\otimes k}} = \langle f, g \rangle_{D_{\emptyset}}^{k}$$

### 2.2. Notations for distributions under alternative hypothesis

We define some notations for probability measures under alternative hypothesis in Problem 2.

**Definition 4 (Notations for distributions under alternative hypothesis)** We define  $\mu_{\sigma}$  to be the distribution of alternative hypothesis in distinguishing Problem 2, and  $\mu$  be the distribution of a single sample under alternative hypothesis when  $\sigma=0$ . Furthermore, we define  $\mu_{x_0,u,\sigma}$  to be the distribution of a single sample under alternative hypothesis, conditioning on unit vector u and sparse Bernoulli-Rademacher variable  $x_0$ . We define  $\mu_{u,\sigma}$  to be the distribution of alternative hypothesis conditioning on u, and  $\mu_u$  to be the distribution of alternative hypothesis conditioning on u when  $\sigma=0$ .

#### 2.3. Lower bound from low degree method

Low degree method is a well studied heuristic for computational hardness of hypothesis testing problems. Essentially it rules out testing algorithms which are based on thresholding low degree polynomials. Originating in Hopkins and Steurer (2017) and Hopkins (2018), it has been successfully applied to a wide range of hypothesis testing problems (Kunisky et al., 2019; d'Orsi et al., 2020a; Ding et al., 2019; Kunisky, 2021), optimization problems (Gamarnik et al., 2020; Wein, 2022; Bresler and Huang, 2022) and recovery problems (Schramm and Wein, 2020) (the list is not exhaustive).

In multi-sample hypothesis testing problem, the formulation of low degree method is given in Brennan et al. (2020):

**Definition 5 (Definition 2.3 in Brennan et al. (2020), Samplewise degree)** For integers  $m, n \ge 1$ , we say that a function  $f: (\mathbb{R}^n)^{\otimes m} \to \mathbb{R}$  has samplewise degree (d,k) if  $f(x_1, \ldots, x_m)$  can be written as a linear combination of functions which have degree at most d in each  $x_i$ , and non-zero degree in at most k of the  $x_i$ 's.

**Definition 6 (Definition 2.4 in Brennan et al. (2020), Low degree likelihood ratio)** For a hypothesis testing problem  $D_{\varnothing}$  vs.  $S = \{D_u\}$ , the m-sample  $(\ell, k)$ -low degree likelihood ratio function is the projection of the m-sample likelihood ratio  $\mathbf{E}_{u \sim S}\left(\bar{D}_u^{\otimes m}\right)$  to the span of non-constant functions of sample-wise degree at most  $(\ell, k)$ :

$$\left(\underset{u\sim S}{\mathbf{E}}\bar{D}_{u}^{\otimes m}-1\right)^{\leqslant \ell,k}=\underset{u\sim S}{\mathbf{E}}\left(\bar{D}_{u}^{\otimes m}\right)^{\leqslant \ell,k}-1.$$

In low degree method, we want to show that the variance of low degree likelihood ratio under  $D_{\emptyset}$  is bounded by a constant:

$$\left\| \left( \underbrace{\mathbf{E}}_{u \sim S} \bar{D}_{u}^{\otimes m} - 1 \right)^{\leqslant \ell, k} \right\|^{2} = \left\| \underbrace{\mathbf{E}}_{u \sim S} \left( \bar{D}_{u}^{\otimes m} \right)^{\leqslant \ell, k} - 1 \right\|^{2} \leqslant O(1).$$

where the norm  $\|\cdot\|$  here is defined for distribution  $D_{\varnothing}$ :

$$||f(z)|| \coloneqq \sqrt{\mathop{\mathbb{E}}_{z \sim D_{\varnothing}} f(z)^2}$$

This can be thought of as a computational counterpart of Le-Cam's method, and provides evidence of hardness in its own sense.

### 3. Overview of techniques

#### 3.1. Smoothed measure

When  $\sigma=0$ , for the conditional distribution of sample  $z_i$  given  $x_i$  and u i.e  $N(x_iu,I-uu^\top)$ , the density function is not well defined. Therefore, for technical reasons, we first consider the case  $\sigma\neq 0$ , where the conditional distribution  $N(u,I-uu^\top+\sigma^2uu^\top)$  admits a density function. We will first derive the desired SQ lower bound for such smoothed measure (i.e.  $\sigma\neq 0$  but arbitrarily small), then use weak convergence and continuity arguments to get the same SQ lower bound for the case  $\sigma=0$ . Similar technique has been used for proving information-theoretic lower bound in Zadik et al. (2021).

#### 3.2. Almost equivalence between low degree method and SQ model

Our strategy is to first obtain low degree likelihood ratio (LDLR) lower bound, and then translate it to SQ lower bound using the almost equivalence relationship proved in Brennan et al. (2020). In particular, they proved the following theorem.

Theorem 4 (Theorem 3.1 in Brennan et al. (2020), LDLR to SDA Lower Bounds) Let  $\ell, k \in \mathbb{N}$  with k even and  $S = \{D_v\}_{v \in S}$  be a collection of probability distributions with prior  $\mu$  over S. Suppose that S satisfies:

- The k-sample high-degree part of the likelihood ratio is bounded by  $\left\|\mathbf{E}_{u\sim\mathcal{S}}\left(\bar{D}_{u}^{>\ell}\right)^{\otimes k}\right\| \leqslant \delta$ .
- For some  $m \in \mathbb{N}$ , the  $(\ell, k)$  LDLR<sub>m</sub> is bounded by  $\left\|\mathbf{E}_{u \sim \mathcal{S}} \left(\bar{D}_u^{\otimes m}\right)^{\leqslant \ell, k} 1\right\| \leqslant \varepsilon$ . Then for any  $q \geqslant 1$ , it follows that

<span id="page-7-0"></span>
$$\operatorname{SDA}\left(\mathcal{S}, \frac{m}{q^{2/k}\left(k\varepsilon^{2/k} + \delta^{2/k}m\right)}\right) \geqslant q.$$

Note that for lower bounding the statistical dimension via this almost equivalence relationship, we not only need to bound the low degree likelihood ratio, but also need to verify the bound on high degree part. The condition on high degree part  $(\bar{D}_u^{>\ell})^{\otimes k}$  is inherently needed, since the query functions in SQ model don't need to be low degree polynomials.

### 3.3. Stronger low degree lower bound

A low degree lower bound for  $\sigma=0$  has been developed in Mao and Wein (2021). However, this is not strong enough for applying the almost equivalence relationship, since we also need the bound on the high degree part of likelihood ratio. Let  $D_{\sigma}(z):\mathbb{R}^d\to\mathbb{R}$  be the density function of sample distribution under alternative hypothesis, by taking  $\ell\to\infty$  in Theorem 4, it is sufficient to show that

$$\left\| \mathbb{E}_{u \sim \mathcal{S}} \left( \frac{D_{u,\sigma}^{\otimes m}}{D_{\emptyset}^{\otimes m}} \right)^{\leqslant \infty, k} - 1 \right\|^{2} \leqslant O(1).$$

For this, we use the identity which already appeared in Brennan et al. (2020):

$$\left\| \underset{u \sim \mathcal{S}}{\mathbb{E}} \left( \frac{\bar{D}_{u,\sigma}^{\otimes m}}{\bar{D}_{\emptyset}^{\otimes m}} \right)^{\leqslant \infty, k} - 1 \right\|^{2} = \sum_{t=1}^{k} {m \choose t} \underset{u,v \sim \mathcal{S}}{\mathbb{E}} \left( \langle \bar{D}_{u,\sigma}, \bar{D}_{v,\sigma} \rangle - 1 \right)^{t}.$$

where  $\bar{D}_{u,\sigma}$  is the ratio of density functions  $\bar{D}_{u,\sigma} = \frac{D_{u,\sigma}}{D_{\emptyset}}$ . Then, for any  $t \leqslant n^{0.1}$ , we will prove the bound  $\mathbb{E}_{u,v\sim\mathcal{S}}\left(\langle \bar{D}_{u,\sigma},\bar{D}_{v,\sigma}\rangle-1\right)^t \ll \left(\frac{t}{em}\right)^t$ . Combine the bounds in the summation, we conclude that when  $k \leqslant n^{0.1}$ , we have:

$$\sum_{t=1}^{k} {m \choose t} \underset{u,v \sim \mathcal{S}}{\mathbb{E}} \left( \langle \bar{D}_{u,\sigma}, \bar{D}_{v,\sigma} \rangle - 1 \right)^{t} \leqslant O(1).$$

### 3.4. Inner product between likelihood ratios

We obtain analytical expression for the inner product  $\langle \bar{D}_{u,\sigma}, \bar{D}_{v,\sigma} \rangle$  for arbitrary pairs of unit norm d-dimensional vectors u,v. Let  $D_{x_u,u,\sigma}$  represents the density of distribution of sample conditioning on  $x_u$  and u, and density ratio  $\bar{D}_{x_u,u,\sigma} = D_{x_u,u,\sigma}/D_{\emptyset}$ . It is easy to see that

$$\langle \bar{D}_{u,\sigma}, \bar{D}_{v,\sigma} \rangle = \underset{x_u, x_v}{\mathbb{E}} \langle \bar{D}_{x_u, u, \sigma}, \bar{D}_{x_v, v, \sigma} \rangle$$

where  $x_u, x_v$  are independent  $\rho$ -sparse Bernoulli-Rademacher variables. Notice that  $D_{x_u,u,\sigma}$  follows from Gaussian distribution  $N(x_uu, \operatorname{Id}_d - uu^\top + \sigma^2 uu^\top)$ . Given the observation that  $D_{x_u,u,\sigma}, D_{x_v,v,\sigma}$  and  $D_\emptyset$  are all Gaussian distributions, we can obtain  $\langle \bar{D}_{x_u,u,\sigma}, \bar{D}_{x_u,u,\sigma} \rangle$  exactly and explicitly by Gaussian integral. Finally, by taking expection over  $x_u$  and  $x_v$ , we obtain an explicit expression for  $\langle \bar{D}_{u,\sigma}, \bar{D}_{v,\sigma} \rangle$ . In particular, the inner product turns out to be a function of  $u^\top v$ , that is,

$$\langle \bar{D}_{u,\sigma}, \bar{D}_{v,\sigma} \rangle = f_{\sigma}(u^{\top}v)$$

for some function  $f_{\sigma} : \mathbb{R} \to \mathbb{R}$ .

#### 3.5. Moments of inner product of likelihood ratio

To bound the moments of  $\langle \bar{D}_{u,\sigma}, \bar{D}_{v,\sigma} \rangle$ , we use a standard fact from probability theory that  $\frac{1}{2} \left( u^{\top} v + 1 \right)$  follows Beta distribution Beta $\left( \frac{d-1}{2}, \frac{d-1}{2} \right)$ . Let  $y = \frac{1}{2} \left( u^{\top} v + 1 \right)$ . Using the probability density function for Beta $\left( \frac{d-1}{2}, \frac{d-1}{2} \right)$ , we have the moment bound:

$$\mathbb{E}_{u,v} \left( \langle \bar{D}_{u,\sigma}, \bar{D}_{v,\sigma} \rangle - 1 \right)^k \leqslant O \left( \sqrt{d-1} \, \mathbb{E} \, f(y)^k \left( 4y(1-y) \right)^{d/2-1} \right)$$

To bound this integral, we divide [0,1] into several regions. In particular, when  $y \approx \frac{1}{2}$ , f(c) is small and we can approximate it by its Taylor expansion around 1/2. When y is away from  $\frac{1}{2}$ , the upper bound on the integral is imposed since  $(4y(1-y))^{d/2-1}$  is very small. Combine these regions, we can get our desired bound on the integral between [0,1].

### <span id="page-8-0"></span>4. Statistical Query lower bound for non-zero noise

In this section, we compute the SQ lower bound for noisy Sparse Planted Vector problem by exploiting the almost equivalence relationship between low degree likelihood ratio and SQ lower bound.

### 4.1. Exact formula for projection of likelihood ratio

<span id="page-9-0"></span>First, we show that the second moment of likelihood ratio projection can be reduced to some simple single variable integral.

**Lemma 1** Let  $\theta = 1 - \sigma^2$  and  $c = u^T v$  where  $u, v \sim S^{d-1}$  are independently and uniformly sampled from the sphere. We have

$$\left\| \underset{u \sim S^{d-1}}{\mathbb{E}} \left( \bar{D}_{u,\sigma}^{\otimes n} \right)^{\leqslant \infty, k} - 1 \right\|^{2} = \underset{c}{\mathbb{E}} \sum_{t=1}^{k} \binom{n}{t} \left( \frac{1}{\sqrt{1 - \theta^{2} c^{2}}} \left[ (1 - \rho)^{2} + 2\rho(1 - \rho) \exp(-\frac{1}{\rho} \frac{\theta c^{2}}{2 - 2\theta^{2} c^{2}}) + \frac{\rho^{2}}{2} \exp(\frac{c}{\rho(1 + \theta c)}) + \frac{\rho^{2}}{2} \exp(-\frac{c}{\rho(1 - \theta c)}) \right] - 1 \right)^{t}$$

$$(4.1)$$

For fixed unit vector u, let  $D_{x_u,u,\sigma}(z_i)$  be the density of conditional distribution of sample  $z_i$  given  $x_i$  and u, i.e  $z_i \sim N(x_i u, I - u u^\top + \sigma^2 u u^\top)$ . The critical step for proving Lemma 1 is to compute  $\mathbb{E}_{z \sim D_{\emptyset}}[\bar{D}_{u,x_u}(z) \cdot \bar{D}_{v,x_v}(z)]$  for arbitrary  $x_u, x_v \in \{0, \pm 1\}$ , where  $\bar{D}_{u,x_u}(z) = D_u[z|x_u]/D_{\emptyset}(z)$ . The result of this step is stated in Lemma 2, whose proof is deferred to Appendix C.1.

**Lemma 2** In the setting of Lemma 1, for  $\bar{D}_{x_u,u,\sigma}(z) = \frac{D_{x_u,u,\sigma}(z)}{D_{\emptyset}(z)}$  and  $\bar{D}_{x_v,v,\sigma}(z) = \frac{D_{x_v,v,\sigma}(z)}{D_{\emptyset}(z)}$ ,

<span id="page-9-4"></span><span id="page-9-2"></span><span id="page-9-1"></span>
$$\langle \bar{D}_{x_u,u,\sigma}, \bar{D}_{x_v,v,\sigma} \rangle = \frac{\exp\left(\frac{1}{2-2\theta^2c^2}[2x_ux_vc - \theta(x_u^2 + x_v^2)c^2]\right)}{\sqrt{1-\theta^2c^2}}$$

The next step is to take expectation over  $x_u$  and  $x_v$ . The result is shown in Lemma 3, whose proof is deferred to Appendix C.2.

**Lemma 3** In the setting of Lemma 1, we have

$$\langle \bar{D}_{u,\sigma}, \bar{D}_{v,\sigma} \rangle = \frac{1}{\sqrt{1 - \theta^2 c^2}} \left[ (1 - \rho)^2 + 2\rho (1 - \rho) \exp(-\frac{1}{\rho} \frac{\theta c^2}{2 - 2\theta^2 c^2}) + \frac{\rho^2}{2} \exp(\frac{c}{\rho (1 + \theta c)}) + \frac{\rho^2}{2} \exp(-\frac{c}{\rho (1 - \theta c)}) \right]$$

Given Lemma 3, we can prove Lemma 1.

**Proof** [Proof of Lemma 1] By Claim 3.3 of Brennan et al. (2020), we have:

$$\left\| \underset{u \sim S^{d-1}}{\mathbb{E}} [\bar{D}_{u,\sigma}^{\otimes n}]^{\leqslant l,k} - 1 \right\|^2 = \underset{u,v \sim S^{d-1}}{\mathbb{E}} \sum_{t=1}^k \binom{n}{t} \left( \langle \bar{D}_{u,\sigma}^{\leqslant l}, \bar{D}_{v,\sigma}^{\leqslant l} \rangle - 1 \right)^t$$

Take  $\ell \to \infty$ , we have:

<span id="page-9-3"></span>
$$\left\| \underset{u \sim S^{d-1}}{\mathbb{E}} [\bar{D}_{u,\sigma}^{\otimes n}]^{\leqslant \infty, k} - 1 \right\|^2 = \underset{u,v \sim S^{d-1}}{\mathbb{E}} \sum_{t=1}^k \binom{n}{t} \left( \langle \bar{D}_{u,\sigma}, \bar{D}_{v,\sigma} \rangle - 1 \right)^t \tag{4.2}$$

Plug the expression of  $\langle \bar{D}_{u,\sigma}, \bar{D}_{v,\sigma} \rangle$  from Lemma 3 into Eq. (4.2), we get:

$$\left\| \mathbb{E}_{u \sim S^{d-1}} [\bar{D}_{u,\sigma}^{\otimes n}]^{\leqslant \infty, k} - 1 \right\|^2 = \mathbb{E}_{u,v \sim S^{d-1}} \sum_{t=1}^k \binom{n}{t} \left( \langle \bar{D}_{u,\sigma}, \bar{D}_{v,\sigma} \rangle - 1 \right)^t$$

$$\begin{split} &= \mathbb{E} \sum_{t=1}^{k} \binom{n}{t} \Big( \frac{1}{\sqrt{1-\theta^2 c^2}} \Big[ (1-\rho)^2 + 2\rho (1-\rho) \exp(-\frac{1}{\rho} \frac{\theta c^2}{2-2\theta^2 c^2}) \\ &+ \frac{\rho^2}{2} \exp(\frac{c}{\rho (1+\theta c)}) + \frac{\rho^2}{2} \exp(-\frac{c}{\rho (1-\theta c)}) \Big] - 1 \Big)^t \end{split}$$

Additionally, by Lemma 10,  $\frac{c+1}{2}$  follows Beta distribution Beta $(\frac{d-1}{2}, \frac{d-1}{2})$ . Using the density function of Beta distribution, we can write this expectation explicitly as an integral. In the following sections, we will bound this integral. We will start from the case where  $\sigma \to 0$  in Section 4.2, then bound the integral for  $\sigma \leqslant d^{-K}$  in Section 4.3 where K is a constant that is large enough.

### <span id="page-10-0"></span>**4.2.** Low degree lower bound for $\sigma \to 0$

In this section, we prove that, when  $\sigma \to 0$ , we have lower bound  $n \leqslant \frac{\rho^2 d^2}{k^8}$  for  $\rho$ -sparse vectors with sparsity  $\rho \geqslant \frac{k}{\sqrt{d}}$  and degree  $\log^2 d \leqslant k \leqslant \sqrt{\frac{d}{\log d}}$ .

<span id="page-10-2"></span>**Lemma 4** Suppose  $\rho \geqslant \frac{k}{\sqrt{d}}$ . When  $n \leqslant \frac{\rho^2 d^2}{k^8}$  and  $\log^2 d \leqslant k \leqslant \sqrt{\frac{d}{\log d}}$ , we have

$$\lim_{\sigma \to 0} \quad \left\| \underset{u \sim S^{d-1}}{\mathbb{E}} [\bar{D}_{u,\sigma}^{\otimes n}]^{\leqslant \infty, k} - 1 \right\|^2 \leqslant O(1)$$

When  $\sigma \to 0$ , we can apply a change of variables to Eq. (4.1) by c=2y-1 where  $y \sim \text{Beta}(\frac{d-1}{2},\frac{d-1}{2})$ , then plug in the probability density function of  $\text{Beta}(\frac{d-1}{2},\frac{d-1}{2})$  to get Lemma 5, whose proof is deferred to Appendix C.3.

<span id="page-10-1"></span>**Lemma 5** In the setting of Lemma 4, let  $y = \frac{c+1}{2}$  and  $c = u^{T}v$ , we have

$$\lim_{\sigma \to 0} \left\| \mathbb{E}_{u \sim S^{d-1}} \left( \bar{D}_{u,\sigma}^{\otimes n} \right)^{\leqslant \infty, k} - 1 \right\|^{2}$$

$$\leqslant O\left( 2^{d-2} \sqrt{d-1} \sum_{t=1}^{k} \binom{n}{t} \int_{0}^{1} \left( \frac{1}{2\sqrt{y(1-y)}} [(1-\rho)^{2} + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{(2y-1)^{2}}{8y(1-y)}) + \frac{\rho^{2}}{2} \exp(\frac{1}{\rho} (1 - \frac{1}{2y})) + \frac{\rho^{2}}{2} \exp(\frac{1}{\rho} (1 - \frac{1}{2-2y}))] - 1 \right)^{t} [y(1-y)]^{\frac{d-3}{2}} dy \right)$$
(4.3)

Now, we prove Lemma 4.

**Proof** [Proof of Lemma 4] From Lemma 5, we have:

$$\lim_{\sigma \to 0} \left\| \underset{u \sim S^{d-1}}{\mathbb{E}} [\bar{D}_{u,\sigma}^{\otimes n}]^{\leqslant \infty,k} - 1 \right\|^{2}$$

$$= \Theta \left( 2^{d-2} \sqrt{d-1} \sum_{t=1}^{k} \binom{n}{t} \int_{0}^{1} \left( \frac{1}{2\sqrt{y(1-y)}} [(1-\rho)^{2} + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{(2y-1)^{2}}{8y(1-y)}) + \frac{\rho^{2}}{2} \exp(\frac{1}{\rho} (1 - \frac{1}{2y})) + \frac{\rho^{2}}{2} \exp(\frac{1}{\rho} (1 - \frac{1}{2-2y})) ] - 1 \right)^{t} [y(1-y)]^{\frac{d-3}{2}} dy \right)$$

$$\begin{split} &=\Theta\left(\sqrt{d-1}\sum_{t=1}^{k}\binom{n}{t}\int_{0}^{1}\left(\frac{1}{2\sqrt{y(1-y)}}[(1-\rho)^{2}+2\rho(1-\rho)\exp(-\frac{1}{\rho}\frac{(2y-1)^{2}}{8y(1-y)})\right.\right.\\ &\left.+\frac{\rho^{2}}{2}\exp(\frac{1}{\rho}(1-\frac{1}{2y}))+\frac{\rho^{2}}{2}\exp(\frac{1}{\rho}(1-\frac{1}{2-2y}))]-1\right)^{t}[4y(1-y)]^{\frac{d-3}{2}}dy\right)\\ &=\Theta\left(\sqrt{d-1}\sum_{t=1}^{k}\binom{n}{t}\int_{0}^{\frac{1}{2}}\left(\frac{1}{2\sqrt{y(1-y)}}[(1-\rho)^{2}+2\rho(1-\rho)\exp(-\frac{1}{\rho}\frac{(2y-1)^{2}}{8y(1-y)})\right.\right.\\ &\left.+\frac{\rho^{2}}{2}\exp(\frac{1}{\rho}(1-\frac{1}{2y}))+\frac{\rho^{2}}{2}\exp(\frac{1}{\rho}(1-\frac{1}{2-2y}))]-1\right)^{t}[4y(1-y)]^{\frac{d-3}{2}}dy\right)\\ &=\Theta\left(\sqrt{d-1}(S_{1}+S_{2})\right) \end{split}$$

where we split the integral into two parts:

$$S_{1} = \sum_{t=1}^{k} {n \choose t} \int_{0}^{\frac{1}{2} - \frac{\varepsilon}{2}} \left( \frac{1}{2\sqrt{y(1-y)}} [(1-\rho)^{2} + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{(2y-1)^{2}}{8y(1-y)}) + \frac{\rho^{2}}{2} \exp(\frac{1}{\rho} (1 - \frac{1}{2y})) + \frac{\rho^{2}}{2} \exp(\frac{1}{\rho} (1 - \frac{1}{2-2y}))] - 1 \right)^{t} [4y(1-y)]^{\frac{d-3}{2}} dy$$

$$(4.4)$$

and,

$$S_{2} = \sum_{t=1}^{k} {n \choose t} \int_{\frac{1}{2} - \frac{\varepsilon}{2}}^{\frac{1}{2}} \left( \frac{1}{2\sqrt{y(1-y)}} \left[ (1-\rho)^{2} + 2\rho(1-\rho) \exp\left(-\frac{1}{\rho} \frac{(2y-1)^{2}}{8y(1-y)}\right) + \frac{\rho^{2}}{2} \exp\left(\frac{1}{\rho} (1-\frac{1}{2y})\right) + \frac{\rho^{2}}{2} \exp\left(\frac{1}{\rho} (1-\frac{1}{2-2y})\right) \right] - 1 \right)^{t} \left[ 4y(1-y) \right]^{\frac{d-3}{2}} dy$$

$$(4.5)$$

We set  $\varepsilon = \frac{k}{\sqrt{d}}$ . Combine upper bounds  $S_1 \leqslant \frac{1}{\sqrt{d}}$  from Lemma 11 and  $S_2 \leqslant \frac{1}{\sqrt{d}}$  from Lemma 12 (the details are deferred to Appendix C.4 and Appendix C.5), we get:

<span id="page-11-4"></span><span id="page-11-3"></span>
$$\left\| \underset{u \sim S^{d-1}}{\mathbb{E}} [\bar{D}_{u,\sigma}^{\otimes n}]^{\leq l,k} - 1 \right\|^{2} \leq \Theta \left\{ \sqrt{d-1}(S_{1} + S_{2}) \right\}$$
$$\leq \Theta \left\{ \frac{2\sqrt{d-1}}{\sqrt{d}} \right\}$$
$$= \Theta (1)$$

### <span id="page-11-0"></span>4.3. Low degree lower bound for non-zero $\sigma$

Now, we prove that, when there is non-zero noise  $\sigma \leqslant d^{-K}$  for some constant K that is large enough<sup>1</sup>, we have lower bound  $n \leqslant \frac{\rho^2 d^2}{k^8}$  for  $\rho$ -sparse vectors with sparsity  $\rho \geqslant \frac{k}{\sqrt{d}}$  and degree  $\log^2 d \leqslant k \leqslant \sqrt{\frac{d}{\log d}}$ .

<span id="page-11-2"></span><span id="page-11-1"></span><sup>1.</sup> This is required for technical reasons. Intuitively the problem gets harder for larger noise.

**Lemma 6** Let  $\sigma \leqslant d^{-K}$  for some large enough universal constant K and  $\rho \geqslant \frac{k}{\sqrt{d}}$ . When  $n \leqslant \frac{\rho^2 d^2}{k^8}$  and  $\log^2 d \leqslant k \leqslant \sqrt{\frac{d}{\log d}}$ , we have

$$\left\| \underset{u \sim S^{d-1}}{\mathbb{E}} [\bar{D}_{u,\sigma}^{\otimes n}]^{\leqslant \infty, k} - 1 \right\|^{2} \leqslant \Theta(1)$$

**Proof** From Eq. (4.1), we get:

$$\begin{split} \left\| \underset{u \sim S^{d-1}}{\mathbb{E}} [\bar{D}_{u,\sigma}^{\otimes n}]^{\leqslant \infty, k} - 1 \right\|^2 &= \mathbb{E} \sum_{t=1}^k \binom{n}{t} \left( \frac{1}{\sqrt{1 - \theta^2 c^2}} \left[ (1 - \rho)^2 + 2\rho (1 - \rho) \exp(-\frac{1}{\rho} \frac{\theta c^2}{2 - 2\theta^2 c^2}) \right. \\ &+ \frac{\rho^2}{2} \exp(\frac{c}{\rho (1 + \theta c)}) + \frac{\rho^2}{2} \exp(-\frac{c}{\rho (1 - \theta c)}) \right] - 1 \right)^t \\ &= 2 \int_0^1 \sum_{t=1}^k \binom{n}{t} \left( \frac{1}{\sqrt{1 - \theta^2 c^2}} \left[ (1 - \rho)^2 + 2\rho (1 - \rho) \exp(-\frac{1}{\rho} \frac{\theta c^2}{2 - 2\theta^2 c^2}) \right. \\ &+ \frac{\rho^2}{2} \exp(\frac{c}{\rho (1 + \theta c)}) + \frac{\rho^2}{2} \exp(-\frac{c}{\rho (1 - \theta c)}) \right] - 1 \right)^t P(c) dc \\ &= 2 \left\{ T_1 + T_2 \right\} \end{split}$$

where we split the integral into two parts:

$$T_{1} = \int_{0}^{1-d^{-k\sigma}} \sum_{t=1}^{k} {n \choose t} \left( \frac{1}{\sqrt{1-\theta^{2}c^{2}}} \left[ (1-\rho)^{2} + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{\theta c^{2}}{2-2\theta^{2}c^{2}}) + \frac{\rho^{2}}{2} \exp(\frac{c}{\rho(1+\theta c)}) + \frac{\rho^{2}}{2} \exp(-\frac{c}{\rho(1-\theta c)}) \right] - 1 \right)^{t} P(c) dc$$

$$(4.6)$$

and,

$$T_{2} = \int_{1-d^{-k_{\sigma}}}^{1} \sum_{t=1}^{k} {n \choose t} \left( \frac{1}{\sqrt{1-\theta^{2}c^{2}}} \left[ (1-\rho)^{2} + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{\theta c^{2}}{2-2\theta^{2}c^{2}}) + \frac{\rho^{2}}{2} \exp(\frac{c}{\rho(1+\theta c)}) + \frac{\rho^{2}}{2} \exp(-\frac{c}{\rho(1-\theta c)}) \right] - 1 \right)^{t} P(c) dc$$

$$(4.7)$$

for some constant  $k_{\sigma}$  that is large enough but smaller than  $\frac{K}{2}$ . Combine upper bounds  $T_1 \leqslant \Theta(1)$  from Lemma 13 and  $T_2 \leqslant \Theta(1)$  from Lemma 14 (the details are deferred to Appendix C.6 and Appendix C.7), we get:

<span id="page-12-1"></span><span id="page-12-0"></span>
$$\left\| \underset{u \sim S^{d-1}}{\mathbb{E}} [\bar{D}_{u,\sigma}^{\otimes n}]^{\leqslant \infty, k} - 1 \right\|^{2} = 2 \left\{ T_{1} + T_{2} \right\} \leqslant \Theta \left( 1 \right)$$

when noise is  $\sigma \leqslant d^{-K}$  for some constant K that is large enough.

### 4.4. SQ lower bound via low degree likelihood ratio

Now, we can prove our main theorem on SQ lower bound for noisy Sparse Planted Vector problem. **Proof** [Proof of Theorem 3] By Lemma 6, for  $\rho$ -sparse rademacher vectors with  $\rho \geqslant \frac{k}{\sqrt{d}}$ , when  $n \leqslant \frac{\rho^2 d^2}{k^8}$  and  $\log^2 d \leqslant k \leqslant \sqrt{\frac{d}{\log d}}$ , we have:

$$\left\| \underset{u \sim S^{d-1}}{\mathbb{E}} [\bar{D}_{u,\sigma}^{\otimes n}]^{\leqslant \infty, k} - 1 \right\|^{2} \leqslant \Theta(1)$$

In theorem 3.1 of Brennan et al. (2020) (recorded as Theorem 4 in this paper), taking  $\ell = \infty, \varepsilon = O(1), q = \exp(k)$ , we get for  $\rho \geqslant \frac{k}{\sqrt{d}}$ , when  $n \leqslant \frac{\rho^2 d^2}{k^8}$  and  $\log^2 d \leqslant k \leqslant \sqrt{\frac{d}{\log d}}$ , we have:

$$SDA(S, \Theta(n)) \geqslant \exp(k)$$

Then, by Theorem 1.3 of Brennan et al. (2020), any SQ algorithm to solve the hypothesis testing problem  $D_{\emptyset}$  vs  $D_{u,\sigma}$  with probability at least 1 - o(1) requires at least  $(1 - o(1)) \exp(k)$  queries to  $VSTAT(\Theta(n))$ .

### 5. SQ lower bound in noiseless setting

We have proven the SQ lower bound for distinguishing problem when  $\sigma \to 0$ . In this section, we show that the SQ lower bound for  $\sigma \to 0$  also applies for  $\sigma = 0$ .

<span id="page-13-0"></span>**Theorem 5** [Restatement of Theorem 2] For  $\sigma = 0$ , consider the distinguishing problem between

- planted distribution  $\mathcal{P}$ : the family of distributions  $\mathcal{S}$  parameterized by u as described in Model 2;
- null distribution Q: standard Gaussian  $N(0, \mathrm{Id}_d)$ .

When  $\rho^2 d^{1.99} \leqslant n \leqslant \frac{\rho^2 d^2}{\text{poly log } d}$ , we have

$$SDA(S, n) \geqslant \exp\left(\left(\frac{\rho^2 d^2}{n \operatorname{poly} \log d}\right)^{0.1}\right)$$

The proof is very similar to the proof of lemma 7.3 in Zadik et al. (2021) (in particular the special case n=1). We first prove that the measure  $\mu_{1,\sigma}$  almost surely converges to  $\tilde{\mu}_1$ , such that

$$\lim_{\sigma \to 0} |\mathbb{E}_{\mu_{\sigma}} \phi(z) - \mathbb{E}_{\tilde{\mu}} \phi(z)| = 0.$$

Then we prove that  $\mu_{\sigma}$  weakly converges to  $\mu$ . It follows that  $\mu = \tilde{\mu}$ . Therefore, we obtain

$$\lim_{\sigma \to 0} |\mathbb{E}_{\mu_{\sigma}} \phi(z) - \mathbb{E}_{\mu} \phi(z)| = 0$$

Therefore, if an SQ algorithm can solve testing problem for  $\sigma = 0$ , it can also solve the testing problem for  $\sigma \to 0$ . This implies that SQ lower bound for  $\sigma \to 0$  also applies for the case  $\sigma = 0$ .

#### 5.1. Weak convergence

**Lemma 7** As  $\sigma \to 0$ ,  $\mu_{\sigma}$  weakly converges to a measure  $\tilde{\mu} : \mathbb{R}^d \to \mathbb{R}$ , which satisfies

$$\underset{z \sim \tilde{\mu}}{\mathbb{E}} \phi(z) = \lim_{\sigma \to 0} \underset{z \sim \mu_{\sigma}}{\mathbb{E}} \phi(z)$$

for any query function  $\phi(z): \mathbb{R}^d \to [0,1]$ .

**Proof** Let  $D_{x_0,u,\sigma}$  be the density function of measure  $\mu_{x_0,u,\sigma}$ , the distribution of a single sample given sparse Bernoulli-Rademacher variable  $x_0$  and direction u. Then for  $\Sigma = \operatorname{Id} - uu^\top + \sigma^2 uu^\top$ , we have

$$D_{x_0,u,\sigma} = (2\pi)^{-d/2} \det(\Sigma)^{-1/2} \exp\left(-\frac{1}{2} (z - x_0 u)^{\top} \left(I + (\sigma^{-2} - 1) u u^{\top}\right) (z - x_0 u)\right)$$
$$= (2\pi)^{-d/2} \sigma \exp\left(-\frac{1}{2\sigma^2}\right) \exp\left(-\frac{1}{2} \left(\|z\|^2 + (\sigma^{-2} - 1)\langle z, u \rangle^2 - 2\sigma^{-2} x_0 \langle z, u \rangle\right)\right)$$

Let  $\mu_{x_0,\sigma}$  be the measure for a single sample conditioning on the sparse Rademacher variable  $x_0$  associated with the sample. Let the density function of distribution  $\mu_{x_0,\sigma}$  be  $D_{x_0,\sigma}$ . Then we have

$$D_{x_0,\sigma} = \mathbb{E} D_{x_0,u,\sigma}$$

where the expectation of u is taken uniformly over the d-dimensional sphere. Thus, we have

$$D_{x_0,\sigma} = (2\pi)^{-d/2} \exp\left(-\frac{1}{2}||z||^2\right) \sigma^{-1} \int_{S^{d-1}} \exp\left(-\sigma^{-2}F(u)\right) d\nu(u)$$

where  $F(u) = \frac{1}{2} (1 - \sigma^2) \langle u, z \rangle^2 - x_0 \langle u, z \rangle + \frac{1}{2}$ . Using Laplace's approximation method, we can show that  $D_{x,\sigma}(z)$  point-wise converges to  $\tilde{D}_x(z)$ , where

$$\tilde{D}_x(z) = (2\pi)^{-d/2} \exp\left(-\frac{1}{2}||z||^2\right) \frac{\left(1 - x_0^2 ||z||^{-2}\right)_+^{\frac{d-n-2}{2}}}{||z||}$$

(here  $(\cdot)_+$  is the relu function). Taking the expectation over  $x_0 \sim BR(\rho)$ , we have

$$D_{\sigma} = \underset{x_0}{\mathbb{E}} D_{x_0,\sigma} \to \underset{x_0}{\mathbb{E}} D_{x_0}.$$

Next we show that  $D_{\sigma}(z)$  is dominated by some Lebesgue-integrable functions in  $\mathbb{R}^{d-3}$ . Let  $D_{\emptyset}(z)$  be the density function of  $N(0, \mathrm{Id}_d)$ . By taking n = 1 in Lemma 6, for  $\sigma \neq 0$ , we have

$$\langle \frac{D_{\sigma}(z)}{D_{\emptyset}(z)}, \frac{D_{\sigma}(z)}{D_{\emptyset}(z)} \rangle \leqslant O(1)$$
.

This is equivalent to

$$\int_{z} \frac{D_{\sigma}^{2}(z)}{D_{\emptyset}(z)} dz \leqslant O(1).$$

<span id="page-14-0"></span><sup>2.</sup> The proof is implied in the proof of Lemma 7.3 in Zadik et al. (2021), by taking n=1 and replacing  $\mathbf{1}^n$  with  $x_0$ .

<span id="page-14-1"></span><sup>3.</sup> Alternatively the proof of Lemma 7.3 in Zadik et al. (2021) also contains a proof for this fact.

Since  $D_{\emptyset}(z) \leqslant \frac{1}{(2\pi)^{d/2}}$ , we have  $D_{\sigma}^2(z)$  is dominated by some Lebesgue-integrable function, which implies that  $D_{\sigma}(z)$  is also dominated by some Lebesgue-integrable function.

Let  $\tilde{\mu}$  be the measure induced by density function  $\tilde{D}(z)$ . Now, by dominated convergence theorem (Theorem 1.19 in Evans (1992)), we have measure  $\mu_{\sigma}$  weakly converge to  $\tilde{\mu}$  as  $\sigma \to 0$ . Furthermore, due to pointwise convergence of density function  $D_{\sigma}(z) \to \tilde{D}(z)$ , by dominated convergence theorem, we have

$$\int_{z} \left| \left( D_{\sigma}(z) - \tilde{D}(z) \right) \right| \cdot \phi(z) dz = 0.$$

Therefore, we can conclude

$$\lim_{\sigma \to 0} \underset{z \sim \mu_{\sigma}}{\mathbb{E}} \phi(z) = \underset{z \sim \tilde{\mu}}{\mathbb{E}} \phi(z).$$

#### 5.2. Continous argument

**Lemma 8** As  $\sigma \to 0$ , we have  $\mu_{\sigma}$  weakly converges to  $\mu$ .

The proof already appears in Zadik et al. (2021).

**Proof** The distribution  $\mu_{x_0,u}$  and  $\mu_{x_0,u,\sigma}$  share the same mean, and have covariance matrix  $I-uu^{\top}$  and  $\sigma^2 uu^{\top} + (I-uu^{\top})$  respectively which commute. It follows from Olkin and Pukelsheim (1982) that we have 2-Wasserstein distance bound

$$W_2(\mu_{x_0,u},\mu_{x_0,u,\sigma}) = \left\| \left( \sigma^2 u u^T + \left( I - u u^\top \right) \right)^{1/2} - \left( I - u u^\top \right)^{1/2} \right\|_F^2 = O(\sigma^2)$$

By taking expectation over u, we have

$$W_2(\mu_{x_0}, \mu_{x_0,\sigma}) \leqslant \int_{\mathcal{S}^{d-1}} W_2(\mu_{x_0,u}, \mu_{x_0,u,\sigma}) \, d\nu(u) = O\left(\sigma^2\right)$$

By taking expectation over  $x_0$ , we then have

$$W_2(\mu, \mu_{\sigma}) \leqslant \int_{\mathcal{S}^{d-1}} W_2(\mu_u, \mu_{u,\sigma}) \, d\nu(u) = O\left(\sigma^2\right)$$

Since  $W_2$  metrizes weak convergence on Euclidean spaces, we then have  $\mu$  weakly converges to  $\mu_{\sigma}$ , by theorem 6.9 in Villani (2008).

### 5.3. Proof of Theorem 5

Now we finish the proof of Theorem 5.

**Proof** [Proof of Theorem 5] Since  $\mu_{\sigma}$  weakly converges to both  $\tilde{\mu}$  and  $\mu$ , we have  $\mu = \tilde{\mu}$ . Therefore, we have

$$\underset{z \sim \mu}{\mathbb{E}} \phi(z) = \lim_{\sigma \to 0} \underset{z \sim \mu_{\sigma}}{\mathbb{E}} \phi(z).$$

This means, in SQ model, the query functions always yield the same result under  $\mu$  and  $\mu_{\sigma}$  when  $\sigma \to 0$ . Thus, the SQ lower bound for  $\sigma \to 0$  implies the same SQ lower bound for  $\sigma = 0$ .

## 6. Conclusion and discussions

We have shown that lattice basis reduction algorithm can surpass SQ lower bound in the Random Sparse Planted Vector problem. There are some interesting directions which we leave as future work:

- Can we show SQ lower bound for sparse planted vector problem, where the planted vector is sampled from sparse Gaussian? In this case, the problem is resistant against the attack from lattice basis reduction algorithm, since the planted vector is not integral. Notably, the low degree lower bound for this problem is proved recently by [Mao and Wein](#page-18-1) [\(2021\)](#page-18-1).
- For the noisy version of [Model 1](#page-1-0) or its variants, can we show Cryptographic hardness result for recovering the sparse vector, when n ≪ ρ 2d 2 ? A potential starting point is the continuous learning with error problem(CLWE) [\(Bruna et al.,](#page-16-5) [2021;](#page-16-5) [Gupte et al.,](#page-17-13) [2022\)](#page-17-13).

## Acknowledgments

This project has received funding from the European Research Council (ERC) under the European Union's Horizon 2020 research and innovation programme (grant agreement No 815464). We thank David Steurer and Ilias Zadik for helpful discussions.

## References

- <span id="page-16-1"></span>Boaz Barak, Jonathan A Kelner, and David Steurer. Rounding sum-of-squares relaxations. In *Proceedings of the forty-sixth annual ACM symposium on Theory of computing*, pages 31–40, 2014.
- <span id="page-16-2"></span>Avrim Blum, Adam Tauman Kalai, and Hal Wasserman. Noise-tolerant learning, the parity problem, and the statistical query model. *J. ACM*, 50:506–519, 2003.
- <span id="page-16-0"></span>Matthew Brennan, Guy Bresler, Samuel B Hopkins, Jerry Li, and Tselil Schramm. Statistical query algorithms and low-degree tests are almost equivalent. *arXiv preprint arXiv:2009.06107*, 2020.
- <span id="page-16-6"></span>Guy Bresler and Brice Huang. The algorithmic phase transition of random k-sat for low degree polynomials. *2021 IEEE 62nd Annual Symposium on Foundations of Computer Science (FOCS)*, pages 298–309, 2022.
- <span id="page-16-5"></span>Joan Bruna, Oded Regev, Min Jae Song, and Yi Tang. Continuous lwe. In *Proceedings of the 53rd Annual ACM SIGACT Symposium on Theory of Computing*, STOC 2021, page 694–707, New York, NY, USA, 2021. Association for Computing Machinery. ISBN 9781450380539. doi: 10.1145/3406325.3451000. URL <https://doi.org/10.1145/3406325.3451000>.
- <span id="page-16-4"></span>Hongjie Chen and Tommaso d'Orsi. On the well-spread property and its relation to linear regression. In Po-Ling Loh and Maxim Raginsky, editors, *Conference on Learning Theory, 2-5 July 2022, London, UK*, volume 178 of *Proceedings of Machine Learning Research*, pages 3905–3935. PMLR, 2022. URL <https://proceedings.mlr.press/v178/chen22d.html>.
- <span id="page-16-3"></span>Damek Davis, Mateo D´ıaz, and Kaizheng Wang. Clustering a mixture of gaussians with unknown covariance, 2021. URL <https://arxiv.org/abs/2110.01602>.

- <span id="page-17-0"></span>Laurent Demanet and Paul Hand. Scaling law for recovering the sparsest element in a subspace. *Information and Inference: A Journal of the IMA*, 3(4):295–309, 2014.
- <span id="page-17-1"></span>Ilias Diakonikolas and Daniel M. Kane. Non-gaussian component analysis via lattice basis reduction. *CoRR*, abs/2112.09104, 2021. URL <https://arxiv.org/abs/2112.09104>.
- <span id="page-17-4"></span>Ilias Diakonikolas, Daniel M Kane, and Alistair Stewart. Statistical query lower bounds for robust estimation of high-dimensional gaussians and gaussian mixtures. In *2017 IEEE 58th Annual Symposium on Foundations of Computer Science (FOCS)*, pages 73–84. IEEE, 2017a.
- <span id="page-17-7"></span>Ilias Diakonikolas, Daniel M. Kane, and Alistair Stewart. Statistical query lower bounds for robust estimation of high-dimensional gaussians and gaussian mixtures. In *2017 IEEE 58th Annual Symposium on Foundations of Computer Science (FOCS)*, pages 73–84, 2017b. doi: 10.1109/ FOCS.2017.16.
- <span id="page-17-10"></span>Yunzi Ding, Dmitriy Kunisky, Alexander S. Wein, and Afonso S. Bandeira. Subexponential-time algorithms for sparse pca. *ArXiv*, abs/1907.11635, 2019.
- <span id="page-17-9"></span>Tommaso d'Orsi, Pravesh K Kothari, Gleb Novikov, and David Steurer. Sparse pca: algorithms, adversarial perturbations and certificates. In *2020 IEEE 61st Annual Symposium on Foundations of Computer Science (FOCS)*, pages 553–564. IEEE, 2020a.
- <span id="page-17-6"></span>Tommaso d'Orsi, Pravesh K. Kothari, Gleb Novikov, and David Steurer. Sparse PCA: algorithms, adversarial perturbations and certificates. In Sandy Irani, editor, *61st IEEE Annual Symposium on Foundations of Computer Science, FOCS 2020, Durham, NC, USA, November 16-19, 2020*, pages 553–564. IEEE, 2020b. doi: 10.1109/FOCS46700.2020.00058. URL [https://doi.](https://doi.org/10.1109/FOCS46700.2020.00058) [org/10.1109/FOCS46700.2020.00058](https://doi.org/10.1109/FOCS46700.2020.00058).
- <span id="page-17-5"></span>Rishabh Dudeja and Daniel J. Hsu. Statistical query lower bounds for tensor pca. *J. Mach. Learn. Res.*, 22:83:1–83:51, 2021.
- <span id="page-17-12"></span>Lawrence C Evans. *Measure theory and fine properties of functions*. 1992.
- <span id="page-17-2"></span>Vitaly Feldman, Elena Grigorescu, Lev Reyzin, Santosh S Vempala, and Ying Xiao. Statistical algorithms and a lower bound for detecting planted cliques. *Journal of the ACM (JACM)*, 64(2): 1–37, 2017.
- <span id="page-17-3"></span>Vitaly Feldman, Will Perkins, and Santosh Vempala. On the complexity of random satisfiability problems with planted solutions. *SIAM Journal on Computing*, 47(4):1294–1338, 2018.
- <span id="page-17-11"></span>David Gamarnik, Aukosh Jagannath, and Alexander S. Wein. Low-degree hardness of random optimization problems. In *2020 IEEE 61st Annual Symposium on Foundations of Computer Science (FOCS)*, pages 131–140, 2020. doi: 10.1109/FOCS46700.2020.00021.
- <span id="page-17-13"></span>Aparna Gupte, Neekon Vafa, and Vinod Vaikuntanathan. Continuous lwe is as hard as lwe & applications to learning gaussian mixtures. *2022 IEEE 63rd Annual Symposium on Foundations of Computer Science (FOCS)*, pages 1162–1173, 2022.
- <span id="page-17-8"></span>Samuel Hopkins. Statistical inference and the sum of squares method. *Phd thesis*, 2018.

- <span id="page-18-6"></span>Samuel B. Hopkins and David Steurer. Efficient bayesian estimation from few samples: Community detection and related problems. In Chris Umans, editor, *58th IEEE Annual Symposium on Foundations of Computer Science, FOCS 2017, Berkeley, CA, USA, October 15-17, 2017*, pages 379–390. IEEE Computer Society, 2017. doi: 10.1109/FOCS.2017.42. URL <https://doi.org/10.1109/FOCS.2017.42>.
- <span id="page-18-3"></span>Samuel B Hopkins, Tselil Schramm, Jonathan Shi, and David Steurer. Fast spectral algorithms from sum-of-squares proofs: tensor decomposition and planted sparse vectors. In *Proceedings of the forty-eighth annual ACM symposium on Theory of Computing*, pages 178–191, 2016.
- <span id="page-18-5"></span>Michael Kearns. Efficient noise-tolerant learning from statistical queries. *Journal of the ACM (JACM)*, 45(6):983–1006, 1998.
- <span id="page-18-8"></span>Dmitriy Kunisky. Hypothesis testing with low-degree polynomials in the morris class of exponential families. In Mikhail Belkin and Samory Kpotufe, editors, *Proceedings of Thirty Fourth Conference on Learning Theory*, volume 134 of *Proceedings of Machine Learning Research*, pages 2822–2848. PMLR, 15–19 Aug 2021. URL [https://proceedings.mlr.press/v134/](https://proceedings.mlr.press/v134/kunisky21a.html) [kunisky21a.html](https://proceedings.mlr.press/v134/kunisky21a.html).
- <span id="page-18-7"></span>Dmitriy Kunisky, Alexander S. Wein, and Afonso S. Bandeira. Notes on computational hardness of hypothesis testing: Predictions using the low-degree likelihood ratio, 2019. URL [https:](https://arxiv.org/abs/1907.11636) [//arxiv.org/abs/1907.11636](https://arxiv.org/abs/1907.11636).
- <span id="page-18-1"></span>Cheng Mao and Alexander S Wein. Optimal spectral recovery of a planted vector in a subspace. *arXiv preprint arXiv:2105.15081*, 2021.
- <span id="page-18-11"></span>Ingram Olkin and Friedrich Pukelsheim. The distance between two random vectors with given dispersion matrices. *Linear Algebra and its Applications*, 48:257–263, 1982.
- <span id="page-18-2"></span>Qing Qu, Ju Sun, and John Wright. Finding a sparse vector in a subspace: Linear sparsity using alternating directions. *Advances in Neural Information Processing Systems*, 27, 2014.
- <span id="page-18-4"></span>Qing Qu, Zhihui Zhu, Xiao Li, Manolis C Tsakiris, John Wright, and Rene Vidal. Finding the spars- ´ est vectors in a subspace: Theory, algorithms, and applications. *arXiv preprint arXiv:2001.06970*, 2020.
- <span id="page-18-10"></span>Tselil Schramm and Alexander S. Wein. Computational barriers to estimation from low-degree polynomials. *ArXiv*, abs/2008.02269, 2020.
- <span id="page-18-12"></span>Cedric Villani. ´ *Optimal transport – Old and new*, volume 338, pages xxii+973. 01 2008. doi: 10.1007/978-3-540-71050-9.
- <span id="page-18-9"></span>Alexander S. Wein. Optimal low-degree hardness of maximum independent set. *ArXiv*, abs/2010.06563, 2022.
- <span id="page-18-0"></span>Ilias Zadik, Min Jae Song, Alexander S. Wein, and Joan Bruna. Lattice-based methods surpass sum-of-squares in clustering. *CoRR*, abs/2112.03898, 2021. URL [https://arxiv.org/](https://arxiv.org/abs/2112.03898) [abs/2112.03898](https://arxiv.org/abs/2112.03898).

### **Appendix A. Reductions**

#### <span id="page-19-0"></span>A.1. Equivalence relationship between Model 1 and Model 2

In this section, we show that Model 1 and Model 2 are equivalent when  $\sigma \neq 0$ . The proof is similar to the proof of Lemma 4.21 of Mao and Wein (2021) which shows that Model 1 and Model 2 are equivalent when  $\sigma = 0$ .

**Lemma 9** When u is chosen uniformly at random from the unit sphere in  $\mathbb{R}^d$ , Model 1 is equivalent to Model 2.

**Proof** Consider the setting of Model 1 where we have  $\tilde{Z}=ZR$ . Denote the rows of R as  $\{R_i\}_{i\in\{0,1,\dots,d-1\}}$  and let the first row of R be u, that is  $R_0=u$ . Condition on R and x, row  $\tilde{z}_i$  of  $\tilde{Z}$  can be expressed as:

$$\tilde{z}_i = (x_i + \sigma \mu_0)u + \sum_{j=1}^{d-1} \mu_j R_j$$

where  $\{\mu_i\}_{i\in\{0,1,\dots,d-1\}}$  are sampled independently from N(0,1). Given this expression, it is easy to verify that the rows  $\{\tilde{z}_i\}_{i\in\{0,1,\dots,d-1\}}$  of  $\tilde{Z}$  are independently sampled from  $N(x_iu,\operatorname{Id}_d-uu^T+\sigma^2uu^\top)$ . Thus, Model 1 and Model 2 are equivalent.

#### A.2. From hypothesis testing to estimation

It has been shown in Mao and Wein (2021) that there exists a polynomial time reduction from the hypothesis testing problem Problem 2 to the estimation problem Problem 1 when  $\sigma=0$ , which implies that estimation is at least as hard as hypothesis testing in the noiseless case. Now, we show that the reduction holds for  $\sigma \neq 0$  using the same test  $\tilde{\psi}$  as defined in Theorem 3.1 of Mao and Wein (2021). The key observation is that the test  $\tilde{\psi}$  works as long as the estimator  $\tilde{x}$  satisfies  $\|\tilde{x} - x\| \leqslant C$  for some constant C if  $\tilde{Z} \sim \mathcal{P}$  and  $\tilde{x}$  is in the column span of  $\tilde{Z}$ .

<span id="page-19-1"></span>**Theorem 6** Let us denote the observation as  $\tilde{Z}$ . Given distribution  $\mathcal{P}, \mathcal{Q}$  as defined in Problem 2, if there exists an estimator  $f: \mathbb{R}^{n \times d} \to \mathbb{R}^n$  that,

- when  $\tilde{Z} \sim \mathcal{P}$ , returns a vector  $\tilde{x}$  such that  $\|\tilde{x} x\| \leq C$  for some constant C with probability 1 o(1);
- when  $\tilde{Z} \sim Q$ , returns an arbitrary vector  $\tilde{x}$ ;

then we can construct, in polynomial time, a test that uses the estimator f to solve the hypothesis testing problem Problem 2 with probability 1 - o(1).

**Proof** Let us denote  $\Pi_{\tilde{Z}}$  as the projection matrix onto the column span of  $\tilde{Z}$  and the projection of  $\tilde{x}$  onto the column span of  $\tilde{Z}$  as  $\tilde{x}_p$ , that is  $\tilde{x}_p = \Pi_{\tilde{Z}}\tilde{x}$ . When  $\tilde{Z} \sim \mathcal{P}$ , by the property of the projection matrix, we have:

$$\|\tilde{x}_n - \tilde{x}\| \leqslant \|x - \tilde{x}\| \leqslant C$$

with probability 1 - o(1). Hence, by triangle inequality, we can get:

$$\|\tilde{x}_n - x\| \le \|\tilde{x}_n - \tilde{x}\| + \|\tilde{x} - x\| \le 2C$$

with probability 1-o(1). Now, we have constructed a new estimator  $\tilde{x}_p$  that is in the column span of  $\tilde{Z}$  and  $\|\tilde{x}_p - x\| \leq 2C$  for some constant C when  $\tilde{Z} \sim \mathcal{P}$ . Therefore, we can apply the test  $\tilde{\psi}$  defined in Theorem 3.1 of Mao and Wein (2021) and get:

$$\mathbb{P}_{\mathcal{P}}(\tilde{\psi}(\tilde{x}_p) = \mathcal{Q}) + \mathbb{P}_{\mathcal{Q}}(\tilde{\psi}(\tilde{x}_p) = \mathcal{P}) \leqslant o(1)$$

Since projection  $\tilde{x}_p = \Pi_{\tilde{Z}}\tilde{x}$  can be done in polynomial time and the test  $\tilde{\psi}$  is constructed in polynomial time according to Theorem 3.1 of Mao and Wein (2021), the reduction from hypothesis testing to estimation is in polynomial time.

Theorem 6 implies that the estimation problem Problem 1 is at least as hard as hypothesis testing problem Problem 2. Since the lattice-based reduction algorithm in Zadik et al. (2021); Diakonikolas and Kane (2021) solve the estimation problem exactly given 2d samples when  $\sigma \leqslant O(\exp(-d^2))$ , it can also solve the hypothesis testing problem in polynomial time by this reduction.

#### A.3. Implication of Statistical Query lower bound for estimation

In the SQ model, we are given an SQ oracle that allows us to query the distribution. However, in the given model definition, the planted vector x is sampled at random in the distribution. Therefore, it does not make much sense to estimate x from the distribution in the SQ model.

Despite this fact, the SQ lower bound from Theorem 1 still gives us a glimpse of the computational hardness of estimation algorithms. According to Theorem 6, any polynomial-time estimation algorithm that recovers the hidden vector x from Model 2 can be used to construct a polynomial-time hypothesis testing algorithm. Therefore, the SQ lower bound for hypothesis testing in theorem Theorem 1 can be compared to sample complexity of any polynomial time estimation algorithm.

A key implication from the lattice-based algorithm in Zadik et al. (2021); Diakonikolas and Kane (2021) is that we can estimate the component vector x when  $\sigma \leqslant \exp(-\Omega(d))$  and  $n \geqslant \Omega(d)$ . According to Theorem 6, the lattice-based algorithm can also be used to construct a polynomial-time hypothesis testing algorithm when  $n \geqslant \Omega(d)$ . This surpasses the SQ lower bound as the SQ lower bound predicts the hypothesis testing problem to be computationally hard in this sample complexity region.

### **Appendix B. Probability Theory Facts**

#### **B.1.** Distribution of inner product of random vectors

<span id="page-20-0"></span>**Lemma 10** Let u, v be two random d-dimensional vectors sampled uniformly from the unit sphere. Let  $y = \frac{u^{\top}v + 1}{2}$ ,

$$y \sim \textit{Beta}(\frac{d-1}{2}, \frac{d-1}{2})$$

**Proof** By the spherical symmetry of u,v, we can assume without generality that  $v=e_1$ , i.e the first coordinate vector. Then  $u^\top v=u_1$ . The probability that  $\mathbb{P}\left\{u_1\geqslant t\right\}$  is proportional to the surface area of spherical cap with base radius  $\sqrt{1-t^2}$ . Between t and t+dt, the spherical belt area is then proportional to the  $(\sqrt{1-t^2})^{d-2}$  (which is the circle length of the base) multiplied by the slope  $\frac{1}{\sqrt{1-t^2}}$ . Thus the density of  $u^\top v$  is proportional to  $(\sqrt{1-t^2})^{d-3}$ . Now, using the rule of changing variables in distribution, the density of  $y=\frac{u^\top v+1}{2}$  exactly matches  $B(\frac{d-1}{2},\frac{d-1}{2})$ 

<span id="page-21-2"></span>Using Stirling's approximation, we can get the following well known asymptotic bound for Beta function.

**Fact 7 (Approximation of Beta function)** We have the following asymptotic approximation for Beta function

$$Beta(\frac{d-1}{2}, \frac{d-1}{2}) = \Theta\left(\frac{((d-1)/2)^{d-2}}{(d-1)^{d-3/2}}\right) = \Theta\left(\frac{(1/2)^{d-2}}{\sqrt{d-1}}\right) \tag{B.1}$$

### Appendix C. Deferred proofs from Section 4

#### <span id="page-21-0"></span>C.1. Proof of Lemma 2

**Proof** [Proof of Lemma 2] From the definition of inner product, we have:

<span id="page-21-1"></span>
$$\langle \bar{D}_{x_u,u,\sigma}, \bar{D}_{x_v,v,\sigma} \rangle = \underset{z \sim D_{\emptyset}}{\mathbb{E}} [\bar{D}_{x_u,u,\sigma}(z) \cdot \bar{D}_{x_v,v,\sigma}(z)]$$

Since  $\bar{D}_{x_u,u,\sigma}(z)=\frac{D_{x_u,u,\sigma}(z)}{D_{\emptyset}(z)}$  and  $\bar{D}_{x_v,v,\sigma}(z)=\frac{D_{x_v,v,\sigma}(z)}{D_{\emptyset}(z)}$ , we have:

$$\mathbb{E}_{z \sim D_{\emptyset}} [\bar{D}_{x_{u}, u, \sigma}(z) \cdot \bar{D}_{x_{v}, v, \sigma}(z)] = \int_{z} \frac{D_{x_{u}, u, \sigma}(z)}{D_{\emptyset}(z)} \cdot \frac{D_{x_{u}, u, \sigma}(z)}{D_{\emptyset}(z)} D_{\emptyset}(z) dz$$

$$= \int_{z} \frac{\exp(-\frac{1}{2}\Delta)}{\sqrt{(2\pi)^{d}|\Sigma_{u}||\Sigma_{v}|}} dz$$
(C.1)

where  $\Delta = (z - x_u u)^{\top} \Sigma_u^{-1} (z - x_u u) + (z - x_v v)^{\top} \Sigma_v^{-1} (z - x_v v) - z^{\top} \operatorname{Id}_d^{-1} z$ . Since  $\Sigma_u^{-1} = \operatorname{Id}_d - u u^{\top} + \frac{1}{\sigma^2} u u^{\top}$  and  $\Sigma_v^{-1} = \operatorname{Id}_d - v v^{\top} + \frac{1}{\sigma^2} v v^{\top}$ , we have:

$$\Delta = (z - x_u u)^{\top} \Sigma_u^{-1} (z - x_u u) + (z - x_v v)^{\top} \Sigma_v^{-1} (z - x_v v) - z^{\top} \operatorname{Id}_d^{-1} z$$

$$= z^{\top} (\Sigma_u^{-1} + \Sigma_v^{-1} - \operatorname{Id}_d) z - 2x_u z^{\top} \Sigma_u^{-1} u - 2x_v z^{\top} \Sigma_v^{-1} v + x_u^2 u^{\top} \Sigma_u^{-1} u + x_v^2 v^{\top} \Sigma_v^{-1} v$$

$$= z^{\top} (\Sigma_u^{-1} + \Sigma_v^{-1} - \operatorname{Id}_d) z - \frac{2x_u}{\sigma^2} z^{\top} u - \frac{2x_v}{\sigma^2} z^{\top} v + \frac{x_u^2}{\sigma^2} + \frac{x_v^2}{\sigma^2}$$

$$= z^{\top} (\Sigma_u^{-1} + \Sigma_v^{-1} - \operatorname{Id}_d) z - \frac{2}{\sigma^2} (x_u u + x_v v)^{\top} z + \frac{1}{\sigma^2} (x_u^2 + x_v^2)$$

Let  $M = \Sigma_u^{-1} + \Sigma_v^{-1} - \operatorname{Id}_d$ , we have:

$$\Delta = z^{\top} M z - \frac{2}{\sigma^{2}} (x_{u}u + x_{v}v)^{\top} z + \frac{1}{\sigma^{2}} (x_{u}^{2} + x_{v}^{2})$$

$$= (z - \frac{M^{-1}}{\sigma^{2}} (x_{u}u + x_{v}v))^{\top} M (z - \frac{M^{-1}}{\sigma^{2}} (x_{u}u + x_{v}v)) - \frac{1}{\sigma^{4}} (x_{u}u + x_{v}v)^{\top} M^{-1} (x_{u}u + x_{v}v)$$

$$+ \frac{1}{\sigma^{2}} (x_{u}^{2} + x_{v}^{2})$$

Plug this into Eq. (C.1), we get:

$$\mathbb{E}_{z \sim D_{\emptyset}} [\bar{D}_{x_u, u, \sigma}(z) \cdot \bar{D}_{x_v, v, \sigma}(z)] = \int_z \frac{\exp(-\frac{1}{2}\Delta)}{\sqrt{(2\pi)^d |\Sigma_u| |\Sigma_v|}} dz$$

$$= \int_{z} \frac{\exp(-\frac{1}{2}(z - \frac{M^{-1}}{\sigma^{2}}(x_{u}u + x_{v}v))^{\top}M(z - \frac{M^{-1}}{\sigma^{2}}(x_{u}u + x_{v}v))) \cdot \exp(W)}{\sqrt{(2\pi)^{d}|\Sigma_{u}||\Sigma_{v}|}} dz$$

$$= \frac{\exp(W)}{\sqrt{|\Sigma_{u}||\Sigma_{v}||M|}} \int_{z} \frac{\exp(-\frac{1}{2}(z - \frac{M^{-1}}{\sigma^{2}}(x_{u}u + x_{v}v))^{\top}M(z - \frac{M^{-1}}{\sigma^{2}}(x_{u}u + x_{v}v)))}{\sqrt{(2\pi)^{d}|M^{-1}|}} dz$$

where  $W=\frac{1}{2\sigma^4}(x_uu+x_vv)^\top M^{-1}(x_uu+x_vv)-\frac{1}{2\sigma^2}(x_u^2+x_v^2)$ . Notice that  $\frac{\exp(-\frac{1}{2}(z-\frac{M^{-1}}{\sigma^2}(x_uu+x_vv))^\top M(z-\frac{M^{-1}}{\sigma^2}(x_uu+x_vv)))}{\sqrt{(2\pi)^d|M^{-1}|}} \text{ is the probability density function of Gaussian distribution } N(\frac{M^{-1}}{\sigma^2}(x_uu+x_vv),M^{-1}).$  Therefore, we have:

$$\int_{z} \frac{\exp(-\frac{1}{2}(z - \frac{M^{-1}}{\sigma^{2}}(x_{u}u + x_{v}v))^{\top}M(z - \frac{M^{-1}}{\sigma^{2}}(x_{u}u + x_{v}v)))}{\sqrt{(2\pi)^{d}|M^{-1}|}} dz = 1$$

Plug this into  $\mathbb{E}_{z \sim D_{\emptyset}}[\bar{D}_{x_{u},u,\sigma}(z) \cdot \bar{D}_{x_{v},v,\sigma}(z)]$ , we get:

<span id="page-22-0"></span>
$$\mathbb{E}_{z \sim D_{\emptyset}} [\bar{D}_{x_{u}, u, \sigma}(z) \cdot \bar{D}_{x_{v}, v, \sigma}(z)] = \frac{\exp(W)}{\sqrt{|\Sigma_{u}||\Sigma_{v}||M|}}$$
(C.2)

Now, consider  $M = \Sigma_u^{-1} + \Sigma_v^{-1} - \operatorname{Id}_d$ . Plug in  $\Sigma_u^{-1} = \operatorname{Id}_d - uu^\top + \frac{1}{\sigma^2} uu^\top$  and  $\Sigma_v^{-1} = \operatorname{Id}_d - vv^\top + \frac{1}{\sigma^2} vv^\top$ , we get:

$$M = \operatorname{Id}_d + (\frac{1}{\sigma^2} - 1)uu^{\top} + (\frac{1}{\sigma^2} - 1)vv^{\top}$$
$$= \operatorname{Id}_d + \alpha^2 CC^{\top}$$

where  $\alpha = \sqrt{\frac{1}{\sigma^2} - 1}$  and C = [u, v] is the matrix whose two columns are u and v. By the Woodbury Matrix Identity, we can compute  $M^{-1}$  as:

$$M^{-1} = (\operatorname{Id}_d + \alpha^2 C C^\top)^{-1}$$
$$= \operatorname{Id}_d - \alpha^2 C (\operatorname{Id}_2 + \alpha^2 C^\top C)^{-1} C^\top$$

Since  $C^{\top}C = \begin{bmatrix} 1 & u^{\top}v \\ u^{\top}v & 1 \end{bmatrix}$ , we have:

$$\operatorname{Id}_2 + \alpha^2 C^{\top} C = \operatorname{Id}_2 + \left(\frac{1}{\sigma^2} - 1\right) \begin{bmatrix} 1 & u^{\top} v \\ u^{\top} v & 1 \end{bmatrix} = \begin{bmatrix} \frac{1}{\sigma^2} & \left(\frac{1}{\sigma^2} - 1\right) u^{\top} v \\ \left(\frac{1}{\sigma^2} - 1\right) u^{\top} v & \frac{1}{\sigma^2} \end{bmatrix}$$

Take the inverse of this matrix, we get:

$$(\mathrm{Id}_2 + \alpha^2 C^{\top} C)^{-1} = \frac{1}{1 - (1 - \sigma^2)^2 (u^{\top} v)^2} \begin{bmatrix} \sigma^2 & (\sigma^4 - \sigma^2) u^{\top} v \\ (\sigma^4 - \sigma^2) u^{\top} v & \sigma^2 \end{bmatrix}$$

Plug this into  $M^{-1}$ , we get:

$$M^{-1} = \operatorname{Id}_{d} - \frac{1/\sigma^{2} - 1}{1 - (1 - \sigma^{2})^{2} (u^{\top} v)^{2}} C \begin{bmatrix} \sigma^{2} & (\sigma^{4} - \sigma^{2}) u^{\top} v \\ (\sigma^{4} - \sigma^{2}) u^{\top} v & \sigma^{2} \end{bmatrix} C^{\top}$$

Plug in C = [u, v], we get:

$$M^{-1} = \operatorname{Id}_{d} - \frac{1/\sigma^{2} - 1}{1 - (1 - \sigma^{2})^{2} (u^{\top} v)^{2}} [\sigma^{2} u u^{\top} + \sigma^{2} v v^{\top} + (\sigma^{4} - \sigma^{2}) u^{\top} v v u^{\top} + (\sigma^{4} - \sigma^{2}) u^{\top} v u v^{\top}]$$

$$= \operatorname{Id}_{d} - \frac{1 - \sigma^{2}}{1 - (1 - \sigma^{2})^{2} (u^{\top} v)^{2}} [u u^{\top} + v v^{\top} + (\sigma^{2} - 1) u^{\top} v v u^{\top} + (\sigma^{2} - 1) u^{\top} v u v^{\top}]$$

Plug in  $c = u^{T}v$  and we have:

$$M^{-1} = \operatorname{Id}_{d} - \frac{1 - \sigma^{2}}{1 - (1 - \sigma^{2})^{2} c^{2}} [uu^{\top} + vv^{\top} + (\sigma^{2} - 1)cvu^{\top} + (\sigma^{2} - 1)cuv^{\top}]$$

Plug  $M^{-1}$  into the expression of W, i.e

$$W = \frac{1}{2\sigma^4} (x_u u + x_v v)^{\top} M^{-1} (x_u u + x_v v) - \frac{1}{2\sigma^2} (x_u^2 + x_v^2),$$

we get:

$$\begin{split} W &= \frac{1}{2\sigma^4} (x_u u + x_v v)^\top M^{-1} (x_u u + x_v v) - \frac{1}{2\sigma^2} (x_u^2 + x_v^2) \\ &= \frac{1}{2\sigma^4} (x_u u + x_v v)^\top \mathrm{Id}_d (x_u u + x_v v) - \frac{1}{2\sigma^2} (x_u^2 + x_v^2) \\ &- \frac{1}{2\sigma^4} \frac{1 - \sigma^2}{1 - (1 - \sigma^2)^2 c^2} (x_u u + x_v v)^\top [u u^\top + v v^\top + (\sigma^2 - 1) c v u^\top + (\sigma^2 - 1) c u v^\top] (x_u u + x_v v) \\ &= (\frac{1}{2\sigma^4} - \frac{1}{2\sigma^2}) (x_u^2 + x_v^2) + \frac{x_u x_v c}{\sigma^4} \\ &- \frac{1}{2\sigma^4} \frac{1 - \sigma^2}{1 - (1 - \sigma^2)^2 c^2} [(x_u^2 + x_v^2) + 2(\sigma^2 + 1) x_u x_v c + (2\sigma^2 - 1) (x_u^2 + x_v^2) c^2 + 2(\sigma^2 - 1) x_u x_v c^3] \\ &= \frac{1}{2 - 2(1 - \sigma^2)^2 c^2} [2x_u x_v c - (1 - \sigma^2) (x_u^2 + x_v^2) c^2] \end{split}$$

Plug this into Eq. (C.2), we get:

$$\underset{z \sim D_{\emptyset}}{\mathbb{E}} [\bar{D}_{x_u, u, \sigma}(z) \cdot \bar{D}_{x_v, v, \sigma}(z)] = \frac{\exp\left(\frac{1}{2 - 2(1 - \sigma^2)^2 c^2} [2x_u x_v c - (1 - \sigma^2)(x_u^2 + x_v^2)c^2]\right)}{\sqrt{|\Sigma_u||\Sigma_v||M|}}$$

Next, we compute  $|\Sigma_u|$ ,  $|\Sigma_v|$  and |M|. Since  $\Sigma_u = \operatorname{Id}_d - uu^\top + \sigma^2 uu^\top$  and  $\Sigma_v = \operatorname{Id}_d - vv^\top + \sigma^2 vv^\top$ , we know that  $\Sigma_u$  and  $\Sigma_v$  has eigenvalue  $\sigma^2$  with corresponding eigenvectors u and v respectively, and the rest of the eigenvalues are all 1's. Therefore, we have  $|\Sigma_u| = \sigma^2$  and  $|\Sigma_v| = \sigma^2$ . Regarding |M|, we have  $M = \operatorname{Id}_d + \alpha^2 CC^\top$  where  $\alpha = \sqrt{\frac{1}{\sigma^2} - 1}$  and C = [u, v]. By the Matrix Determinant Lemma, we have:

$$|M| = |\mathrm{Id}_d + \alpha^2 C C^\top| = |\mathrm{Id}_2 + \alpha^2 C^\top C| = \left| \begin{bmatrix} \frac{1}{\sigma^2} & (\frac{1}{\sigma^2} - 1)u^\top v \\ (\frac{1}{\sigma^2} - 1)u^\top v & \frac{1}{\sigma^2} \end{bmatrix} \right| = \frac{1}{\sigma^4} - (\frac{1}{\sigma^2} - 1)^2 c^2$$

Therefore,

$$|\Sigma_u||\Sigma_v||M| = \sigma^2 \cdot \sigma^2 \cdot (\frac{1}{\sigma^4} - (\frac{1}{\sigma^2} - 1)^2 c^2) = 1 - (1 - \sigma^2)^2 c^2$$

Plug this into Eq. (C.2), we get:

$$\mathbb{E}_{z \sim D_{\emptyset}} [\bar{D}_{x_u, u, \sigma}(z) \cdot \bar{D}_{x_v, v, \sigma}(z)] = \frac{\exp\left(\frac{1}{2 - 2(1 - \sigma^2)^2 c^2} [2x_u x_v c - (1 - \sigma^2)(x_u^2 + x_v^2)c^2]\right)}{\sqrt{1 - (1 - \sigma^2)^2 c^2}}$$

Plug in  $\theta = 1 - \sigma^2$ , we get:

$$\mathbb{E}_{z \sim D_{\emptyset}}[\bar{D}_{x_{u}, u, \sigma}(z) \cdot \bar{D}_{x_{v}, v, \sigma}(z)] = \frac{\exp\left(\frac{1}{2 - 2\theta^{2}c^{2}}[2x_{u}x_{v}c - \theta(x_{u}^{2} + x_{v}^{2})c^{2}]\right)}{\sqrt{1 - \theta^{2}c^{2}}}$$

which finishes the proof.

#### <span id="page-24-0"></span>C.2. Proof of Lemma 3

**Proof** [Proof of Lemma 3] By the definition of inner product, we have:

$$\begin{split} \langle \bar{D}_{u,\sigma}, \bar{D}_{v,\sigma} \rangle &= \underset{z \sim D_{\emptyset}}{\mathbb{E}} \left[ \bar{D}_{u,\sigma}(z) \cdot \bar{D}_{v,\sigma}(z) \right] \\ &= \underset{z \sim D_{\emptyset}}{\mathbb{E}} \left[ \underset{x_{u}}{\mathbb{E}} [\bar{D}_{x_{u},u,\sigma}(z)] \cdot \underset{x_{v}}{\mathbb{E}} [\bar{D}_{x_{v},v,\sigma}(z)] \right] \\ &= \underset{x_{u},x_{v}}{\mathbb{E}} \left[ \underset{z \sim D_{\emptyset}}{\mathbb{E}} [\bar{D}_{x_{u},u,\sigma}(z) \cdot \bar{D}_{x_{v},v,\sigma}(z)] \right] \end{split}$$

where  $x_u, x_v$  are two i.i.d sparse Rademacher variables:  $x_u$  and  $x_v$  is  $+1/\sqrt{\rho}$  with probability  $\rho/2$ ,  $-1/\sqrt{\rho}$  with probability  $\rho/2$  and 0 with probability  $1-\rho$ .

Plug in Lemma 2, we get:

$$\langle \bar{D}_{u,\sigma}, \bar{D}_{v,\sigma} \rangle = \mathbb{E}_{x_u, x_v} \left[ \frac{\exp\left(\frac{1}{2 - 2\theta^2 c^2} [2x_u x_v c - \theta(x_u^2 + x_v^2)c^2]\right)}{\sqrt{1 - \theta^2 c^2}} \right]$$

There are 4 cases in the computation of expectation over  $x_u$  and  $x_v$ :

- Case 1 (
$$x_u = x_v = 0$$
): we have  $\frac{\exp\left(\frac{1}{2-2\theta^2c^2}[2x_ux_vc - \theta(x_u^2 + x_v^2)c^2]\right)}{\sqrt{1-\theta^2c^2}} = \frac{1}{\sqrt{1-\theta^2c^2}}$  and  $P[\text{case 1}] = (1-\rho)^2$ .

- Case 2 
$$(x_u = 0, x_v = \pm \frac{1}{\sqrt{\rho}} \text{ or } x_v = 0, x_u = \pm \frac{1}{\sqrt{\rho}})$$
: we have 
$$\frac{\exp\left(\frac{1}{2-2\theta^2c^2}[2x_ux_vc - \theta(x_u^2 + x_v^2)c^2]\right)}{\sqrt{1-\theta^2c^2}} = \frac{\exp\left(-\frac{1}{\rho}\frac{\theta c^2}{2-2\theta^2c^2}\right)}{\sqrt{1-\theta^2c^2}} \text{ and } P[\text{case 2}] = 2\rho(1-\rho).$$

- Case 3 
$$(x_u = x_v = \frac{1}{\sqrt{\rho}} \text{ or } x_u = x_v = -\frac{1}{\sqrt{\rho}})$$
: we have  $\frac{\exp\left(\frac{1}{2-2\theta^2c^2}[2x_ux_vc - \theta(x_u^2 + x_v^2)c^2]\right)}{\sqrt{1-\theta^2c^2}} = \frac{\exp(\frac{c}{\rho(1+\theta c)})}{\sqrt{1-\theta^2c^2}}$  and  $P[\text{case 3}] = \frac{\rho^2}{2}$ .

$$- \operatorname{Case} \ 4 \ (x_u = \frac{1}{\sqrt{\rho}}, \ x_v = -\frac{1}{\sqrt{\rho}} \text{ or } x_u = -\frac{1}{\sqrt{\rho}}, \ x_v = \frac{1}{\sqrt{\rho}}) \text{: we have } \\ \frac{\exp\left(\frac{1}{2-2\theta^2c^2}[2x_ux_vc - \theta(x_u^2 + x_v^2)c^2]\right)}{\sqrt{1-\theta^2c^2}} = \frac{\exp(-\frac{c}{\rho(1-\theta c)})}{\sqrt{1-\theta^2c^2}} \text{ and } P[\operatorname{case} 4] = \frac{\rho^2}{2}.$$

Plug these into  $\langle \bar{D}_{u,\sigma}, \bar{D}_{v,\sigma} \rangle$ , we get:

$$\begin{split} \langle \bar{D}_{u,\sigma}, \bar{D}_{v,\sigma} \rangle &= \underset{x_u, x_v}{\mathbb{E}} \left[ \frac{\exp\left(\frac{1}{2 - 2\theta^2 c^2} [2x_u x_v c - \theta(x_u^2 + x_v^2) c^2]\right)}{\sqrt{1 - \theta^2 c^2}} \right] \\ &= \frac{1}{\sqrt{1 - \theta^2 c^2}} \left[ (1 - \rho)^2 + 2\rho (1 - \rho) \exp(-\frac{1}{\rho} \frac{\theta c^2}{2 - 2\theta^2 c^2}) \right. \\ &+ \frac{\rho^2}{2} \exp(\frac{c}{\rho (1 + \theta c)}) + \frac{\rho^2}{2} \exp(-\frac{c}{\rho (1 - \theta c)}) \right] \end{split}$$

#### <span id="page-25-0"></span>C.3. Proof for Lemma 5

**Proof** [Proof for Lemma 5] When  $\sigma \to 0$ , we have  $\theta \to 1$  in Lemma 1. In this case, it follows that

$$\lim_{\sigma \to 0} \quad \left\| \underset{u \sim S^{d-1}}{\mathbb{E}} [\bar{D}_{u,\sigma}^{\otimes n}]^{\leqslant \infty, k} - 1 \right\|^2 = \mathbb{E} \sum_{t=1}^k \binom{n}{t} \left( \frac{1}{\sqrt{1 - c^2}} \left[ (1 - \rho)^2 + 2\rho (1 - \rho) \exp(-\frac{1}{\rho} \frac{c^2}{2 - 2c^2}) + \frac{\rho^2}{2} \exp(\frac{c}{\rho (1 + c)}) + \frac{\rho^2}{2} \exp(-\frac{c}{\rho (1 - c)}) \right] - 1 \right)^t$$

Apply change of variable c=2y-1 and take expectation over  $y\sim \mathrm{Beta}(\frac{d-1}{2},\frac{d-1}{2}),$ 

$$\begin{split} &\lim_{\sigma \to 0} \left\| \sum_{u \sim S^{d-1}} [\bar{D}_{u,\sigma}^{\otimes n}]^{\leqslant \infty,k} - 1 \right\|^2 \\ &= \mathbb{E} \sum_{t=1}^k \binom{n}{t} \left( \frac{1}{\sqrt{1-c^2}} [(1-\rho)^2 + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{c^2}{2-2c^2}) \right. \\ &\quad + \frac{\rho^2}{2} \exp(\frac{c}{\rho(1+c)}) + \frac{\rho^2}{2} \exp(-\frac{c}{\rho(1-c)})] - 1 \right)^t \\ &= \mathbb{E} \sum_{y \sim Beta(\frac{d-1}{2}, \frac{d-1}{2})} \sum_{t=1}^k \binom{n}{t} \left( \frac{1}{2\sqrt{y(1-y)}} [(1-\rho)^2 + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{(2y-1)^2}{8y(1-y)}) \right. \\ &\quad + \frac{\rho^2}{2} \exp(\frac{1}{\rho} (1-\frac{1}{2y})) + \frac{\rho^2}{2} \exp(\frac{1}{\rho} (1-\frac{1}{2-2y}))] - 1 \right)^t \\ &= \sum_{t=1}^k \binom{n}{t} \int_0^1 \left( \frac{1}{2\sqrt{y(1-y)}} [(1-\rho)^2 + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{(2y-1)^2}{8y(1-y)}) \right. \\ &\quad + \frac{\rho^2}{2} \exp(\frac{1}{\rho} (1-\frac{1}{2y})) + \frac{\rho^2}{2} \exp(\frac{1}{\rho} (1-\frac{1}{2-2y}))] - 1 \right)^t \frac{[y(1-y)]^{\frac{d-3}{2}}}{\mathcal{B}(\frac{d-1}{2}, \frac{d-1}{2})} dy \end{split}$$

where  $\mathcal{B}(\frac{d-1}{2}, \frac{d-1}{2})$  is the Beta function. Plug in the asymptotic approximation for Beta function from Theorem 7, we get:

$$\lim_{\sigma \to 0} \left\| \underset{u \sim S^{d-1}}{\mathbb{E}} [\bar{D}_{u,\sigma}^{\otimes n}]^{\leqslant \infty,k} - 1 \right\|^2$$

$$\leqslant O\left(2^{d-2}\sqrt{d-1}\right) \sum_{t=1}^{k} \binom{n}{t} \int_{0}^{1} \left(\frac{1}{2\sqrt{y(1-y)}} [(1-\rho)^{2} + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{(2y-1)^{2}}{8y(1-y)}) + \frac{\rho^{2}}{2} \exp(\frac{1}{\rho} (1-\frac{1}{2y})) + \frac{\rho^{2}}{2} \exp(\frac{1}{\rho} (1-\frac{1}{2-2y}))] - 1\right)^{t} [y(1-y)]^{\frac{d-3}{2}} dy$$

$$\leqslant O\left(2^{d-2}\sqrt{d-1} \sum_{t=1}^{k} \binom{n}{t} \int_{0}^{1} \left(\frac{1}{2\sqrt{y(1-y)}} [(1-\rho)^{2} + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{(2y-1)^{2}}{8y(1-y)}) + \frac{\rho^{2}}{2} \exp(\frac{1}{\rho} (1-\frac{1}{2-2y})) + \frac{\rho^{2}}{2} \exp(\frac{1}{\rho} (1-\frac{1}{2-2y}))] - 1\right)^{t} [y(1-y)]^{\frac{d-3}{2}} dy \right)$$

#### <span id="page-26-1"></span>C.4. Proof for upper bound of Eq. (4.4)

<span id="page-26-0"></span>**Lemma 11** Suppose  $\rho \geqslant \frac{k}{\sqrt{d}}$ ,  $n \leqslant \frac{\rho^2 d^2}{k^8}$  and  $\log^2 d \leqslant k \leqslant \sqrt{\frac{d}{\log d}}$ . Let  $\varepsilon = k/\sqrt{d}$ . We have

$$S_{1} = \sum_{t=1}^{k} {n \choose t} \int_{0}^{\frac{1}{2} - \frac{\varepsilon}{2}} \left( \frac{1}{2\sqrt{y(1-y)}} [(1-\rho)^{2} + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{(2y-1)^{2}}{8y(1-y)}) + \frac{\rho^{2}}{2} \exp(\frac{1}{\rho} (1 - \frac{1}{2y})) + \frac{\rho^{2}}{2} \exp(\frac{1}{\rho} (1 - \frac{1}{2-2y}))] - 1 \right)^{t} [4y(1-y)]^{\frac{d-3}{2}} dy$$

$$\leq \frac{1}{\sqrt{d}}$$

**Proof** When  $y \in (0, \frac{1}{2} - \frac{\varepsilon}{2})$ , we have  $-\frac{1}{\rho} \frac{(2y-1)^2}{8y(1-y)} \leqslant 0$  and  $\frac{1}{\rho} (1 - \frac{1}{2y}) \leqslant 0$ , which implies that  $\exp(-\frac{1}{\rho} \frac{(2y-1)^2}{8y(1-y)}) \leqslant 1$  and  $\exp(\frac{1}{\rho} (1 - \frac{1}{2y})) \leqslant 1$ . Therefore, we have:

$$\begin{split} S_1 \leqslant & \sum_{t=1}^k \binom{n}{t} \int_0^{\frac{1}{2} - \frac{\varepsilon}{2}} \left( \frac{1}{2\sqrt{y(1-y)}} [(1-\rho)^2 + 2\rho(1-\rho) + \frac{\rho^2}{2} + \frac{\rho^2}{2} \exp(\frac{1}{\rho}(1-\frac{1}{2-2y}))] - 1 \right)^t \\ & [4y(1-y)]^{\frac{d-3}{2}} dy \\ &= \sum_{t=1}^k \binom{n}{t} \int_0^{\frac{1}{2} - \frac{\varepsilon}{2}} \left( \frac{1}{2\sqrt{y(1-y)}} [1 - \frac{\rho^2}{2} + \frac{\rho^2}{2} \exp(\frac{1}{\rho}(1-\frac{1}{2-2y}))] - 1 \right)^t [4y(1-y)]^{\frac{d-3}{2}} dy \\ &= \sum_{t=1}^k \binom{n}{t} \int_0^{\frac{1}{2} - \frac{\varepsilon}{2}} \left( [1 - \frac{\rho^2}{2} + \frac{\rho^2}{2} \exp(\frac{1}{\rho}(1-\frac{1}{2-2y}))] - \sqrt{4y(1-y)} \right)^t [4y(1-y)]^{\frac{d-t-3}{2}} dy \\ &\leqslant \sum_{t=1}^k \binom{n}{t} \int_0^{\frac{1}{2} - \frac{\varepsilon}{2}} \left( 1 - \frac{\rho^2}{2} + \frac{\rho^2}{2} \exp(\frac{1}{\rho}(1-\frac{1}{2-2y})) \right)^t [4y(1-y)]^{\frac{d-t-3}{2}} dy \\ &= \sum_{t=1}^k \int_0^{\frac{1}{2} - \frac{\varepsilon}{2}} \binom{n}{t} \left( 1 - \frac{\rho^2}{2} + \frac{\rho^2}{2} \exp(\frac{1}{\rho}(1-\frac{1}{2-2y})) \right)^t [1 - (2y-1)^2]^{\frac{d-t-3}{2}} dy \\ &\leqslant \sum_{t=1}^k \int_0^{\frac{1}{2} - \frac{\varepsilon}{2}} \binom{n}{t} \left( 1 - \frac{\rho^2}{2} + \frac{\rho^2}{2} \exp(\frac{1}{\rho}(1-\frac{1}{2-2y})) \right)^t \exp\left( - (2y-1)^2 \frac{d-t-3}{2} \right) dy \end{split}$$

Let  $h(y) = \binom{n}{t} \left(1 - \frac{\rho^2}{2} + \frac{\rho^2}{2} \exp(\frac{1}{\rho}(1 - \frac{1}{2 - 2y}))\right)^t \exp\left(-(2y - 1)^2 \frac{d - t - 3}{2}\right)$ , we will prove that for any  $y \in (0, \frac{1}{2} - \frac{\varepsilon}{2})$ , we have:

$$h(y) \leqslant \frac{1}{d}$$

We prove this by showing that this inequality holds for both case (1)  $1 - \frac{\rho^2}{2} \leqslant \frac{\rho^2}{2} \exp(\frac{1}{\rho}(1 - \frac{1}{2 - 2y}))$  and case (2)  $1 - \frac{\rho^2}{2} \geqslant \frac{\rho^2}{2} \exp(\frac{1}{\rho}(1 - \frac{1}{2 - 2y}))$ . We prove case (1) in Theorem 8, and case (2) in Theorem 9. Combine case (1) and case (2), we can plug  $h(y) \leqslant \frac{1}{d}$  into  $S_1$  and get:

$$S_{1} \leqslant \sum_{t=1}^{k} \int_{0}^{\frac{1}{2} - \frac{\varepsilon}{2}} h(y) dy$$

$$\leqslant \sum_{t=1}^{k} \int_{0}^{\frac{1}{2} - \frac{\varepsilon}{2}} \frac{1}{d} dy$$

$$\leqslant \sum_{t=1}^{k} \frac{1}{d}$$

$$= \frac{k}{d}$$

Since  $k \leqslant \sqrt{\frac{d}{\log d}} \leqslant \sqrt{d}$ , we have:

$$S_1 \leqslant \frac{k}{d} \leqslant \frac{1}{\sqrt{d}}$$

<span id="page-27-0"></span>**Fact 8** Under the setting of Lemma 11. When  $1 - \frac{\rho^2}{2} \leqslant \frac{\rho^2}{2} \exp(\frac{1}{\rho}(1 - \frac{1}{2-2y}))$ , for

$$h(y) = \binom{n}{t} \left( 1 - \frac{\rho^2}{2} + \frac{\rho^2}{2} \exp\left(\frac{1}{\rho} \left(1 - \frac{1}{2 - 2y}\right)\right) \right)^t \exp\left(-(2y - 1)^2 \frac{d - t - 3}{2}\right),$$

we have  $h(y) \leq 1/d$ .

**Proof** we have

$$\begin{split} h(y) = &\binom{n}{t} \left(1 - \frac{\rho^2}{2} + \frac{\rho^2}{2} \exp(\frac{1}{\rho} (1 - \frac{1}{2 - 2y}))\right)^t \exp\left(-(2y - 1)^2 \frac{d - t - 3}{2}\right) \\ \leqslant &\binom{n}{t} \left(\rho^2 \exp(\frac{1}{\rho} (1 - \frac{1}{2 - 2y}))\right)^t \exp\left(-(2y - 1)^2 \frac{d - t - 3}{2}\right) \\ \leqslant &\left(\frac{en}{t}\right)^t \left(\rho^2 \exp(\frac{1}{\rho} (1 - \frac{1}{2 - 2y}))\right)^t \exp\left(-(2y - 1)^2 \frac{d - t - 3}{2}\right) \\ = &\left(\frac{e\rho^2}{t}\right)^t n^t \exp\left(\frac{t}{\rho} (1 - \frac{1}{2 - 2y}) - (2y - 1)^2 \frac{d - t - 3}{2}\right) \end{split}$$

$$= \left(\frac{e\rho^2}{t}\right)^t \exp\left(t\log n + \frac{t}{\rho}\frac{1-2y}{2-2y} - (1-2y)^2\frac{d-t-3}{2}\right)$$

$$= \left(\frac{e\rho^2}{t}\right)^t \exp\left(t\log n + (1-2y)\left[\frac{t}{\rho}\frac{1}{2-2y} - (1-2y)\frac{d-t-3}{2}\right]\right)$$

$$\leq \left(\frac{e\rho^2}{t}\right)^t \exp\left(t\log n + (1-2y)\left[\frac{t}{\rho} - (1-2y)\frac{d-t-3}{2}\right]\right)$$

Since  $y \in (0, \frac{1}{2} - \frac{\varepsilon}{2}), t \leqslant k, \rho \geqslant \frac{k}{\sqrt{d}}$  and  $n \leqslant \frac{\rho^2 d^2}{k^8} \leqslant d^2$ , we get:

$$h(y) \leqslant \left(\frac{e\rho^2}{t}\right)^t \exp\left(2k\log d + (1-2y)\left[\sqrt{d} - \varepsilon\frac{d-k-3}{2}\right]\right)$$

Plug in  $\varepsilon = \frac{k}{\sqrt{d}}$ , we get:

$$h(y) \leqslant \left(\frac{e\rho^2}{t}\right)^t \exp\left(2k\log d + (1-2y)\left[\sqrt{d} - \frac{k}{\sqrt{d}}\frac{d-k-3}{2}\right]\right)$$
$$= \left(\frac{e\rho^2}{t}\right)^t \exp\left(2k\log d + (1-2y)\left[-\frac{k\sqrt{d}}{2} + \sqrt{d} + \frac{k^2}{2\sqrt{d}} + \frac{3k}{2\sqrt{d}}\right]\right)$$

Since  $d \to \infty$  and  $\log^2 d \leqslant k \leqslant \sqrt{\frac{d}{\log d}}$ , we can find constant  $C_1 > 0$  such that  $-\frac{k\sqrt{d}}{2} + \sqrt{d} + \frac{k^2}{2\sqrt{d}} + \frac{3k}{2\sqrt{d}} \leqslant -C_1k\sqrt{d}$ . Therefore, we have:

$$h(y) \leqslant \left(\frac{e\rho^2}{t}\right)^t \exp\left(2k\log d - (1-2y)C_1k\sqrt{d}\right)$$
  
$$\leqslant \left(\frac{e\rho^2}{t}\right)^t \exp\left(2k\log d - \varepsilon C_1k\sqrt{d}\right)$$

Again, plug in  $\varepsilon = \frac{k}{\sqrt{d}}$ , we get:

$$h(y) \leqslant \left(\frac{e\rho^2}{t}\right)^t \exp\left(2k\log d - \frac{k}{\sqrt{d}}C_1k\sqrt{d}\right)$$
$$= \left(\frac{e\rho^2}{t}\right)^t \exp\left(2k\log d - C_1k^2\right)$$
$$= \left(\frac{e\rho^2}{t}\right)^t \exp\left(k(2\log d - C_1k)\right)$$

Since  $k \geqslant \log^2 d$ , we have  $2 \log d - C_1 k \leqslant -C_1 \log^2 d + 2 \log d \leqslant -C_2 \log^2 d$  for some constant  $C_2 > 0$ . Therefore, we have:

$$h(y) \leqslant \left(\frac{e\rho^2}{t}\right)^t \exp\left(k(2\log d - C_1 k)\right)$$
$$\leqslant \left(\frac{e\rho^2}{t}\right)^t \exp\left(-C_2 k \log^2 d\right)$$
$$\leqslant \left(\frac{e\rho^2}{t}\right)^t \exp\left(-C_2 \log^4 d\right)$$

Notice that  $\left(\frac{e\rho^2}{t}\right)^t \leqslant \left(\frac{e}{t}\right)^t \leqslant e$ . Therefore,

$$h(y) \leqslant \left(\frac{e\rho^2}{t}\right)^t \exp\left(-C_2 \log^4 d\right)$$
  
$$\leqslant \exp\left(-C_2 \log^4 d + 1\right)$$
  
$$\leqslant \exp\left(-\log d\right)$$
  
$$= \frac{1}{d}$$

<span id="page-29-0"></span>**Fact 9** Under the setting of Lemma 11. When  $1 - \frac{\rho^2}{2} \geqslant \frac{\rho^2}{2} \exp(\frac{1}{\rho}(1 - \frac{1}{2 - 2y}))$ , for

$$h(y) = \binom{n}{t} \Big(1 - \frac{\rho^2}{2} + \frac{\rho^2}{2} \exp(\frac{1}{\rho} (1 - \frac{1}{2 - 2y}))\Big)^t \exp\Big(-(2y - 1)^2 \frac{d - t - 3}{2}\Big),$$

we have  $h(y) \leq 1/d$ .

Proof

$$\begin{split} h(y) &= \binom{n}{t} \left( 1 - \frac{\rho^2}{2} + \frac{\rho^2}{2} \exp(\frac{1}{\rho} (1 - \frac{1}{2 - 2y})) \right)^t \exp\left( - (2y - 1)^2 \frac{d - t - 3}{2} \right) \\ &\leq \left( \frac{en}{t} \right)^t \left( 2 - \rho^2 \right)^t \exp\left( - (2y - 1)^2 \frac{d - t - 3}{2} \right) \\ &\leq \left( \frac{en}{t} \right)^t 2^t \exp\left( - (2y - 1)^2 \frac{d - t - 3}{2} \right) \\ &= \left( \frac{2e}{t} \right)^t n^t \exp\left( - (2y - 1)^2 \frac{d - t - 3}{2} \right) \\ &= \left( \frac{2e}{t} \right)^t \exp\left( t \log n - (2y - 1)^2 \frac{d - t - 3}{2} \right) \end{split}$$

Since  $y \in (0, \frac{1}{2} - \frac{\varepsilon}{2}), t \leqslant k$  and  $n \leqslant \frac{\rho^2 d^2}{k^8} \leqslant d^2$ , we get:

$$h(y) \leqslant \left(\frac{2e}{t}\right)^t \exp\left(2k\log d - \varepsilon^2 \frac{d-k-3}{2}\right)$$

Plug in  $\varepsilon = \frac{k}{\sqrt{d}}$ , we get:

$$h(y) \leqslant \left(\frac{2e}{t}\right)^t \exp\left(2k\log d - \frac{k^2}{d}\frac{d - k - 3}{2}\right)$$
$$\leqslant \left(\frac{2e}{t}\right)^t \exp\left(2k\log d - \frac{k^2}{d}\frac{d - k - 3}{2}\right)$$
$$= \left(\frac{2e}{t}\right)^t \exp\left(-\frac{k^2}{2} + 2k\log d + \frac{k^3}{2d} + \frac{3k^2}{2d}\right)$$

Since  $\log^2 d \leqslant k \leqslant \sqrt{\frac{d}{\log d}}$ , we have  $-\frac{k^2}{2} + 2k \log d + \frac{k^3}{2d} + \frac{3k^2}{2d} \leqslant -C_3 \log^4 d$  for some constant  $C_3 > 0$  and  $\left(\frac{2e}{t}\right)^t \leqslant \exp(10)$ . Hence,

$$h(y) \leq \left(\frac{2e}{t}\right)^t \exp\left(-\frac{k^2}{2} + 2k\log d + \frac{k^3}{2d} + \frac{3k^2}{2d}\right)$$
  
$$\leq \exp(10) \cdot \exp\left(-C_3\log^4 d\right)$$
  
$$= \exp\left(-C_3\log^4 d + 10\right)$$
  
$$\leq \exp\left(-\log d\right)$$
  
$$= \frac{1}{d}$$

### <span id="page-30-1"></span>C.5. Proof for upper bound of Eq. (4.5)

<span id="page-30-0"></span>**Lemma 12** Suppose  $\rho \geqslant \frac{k}{\sqrt{d}}$ ,  $n \leqslant \frac{\rho^2 d^2}{k^8}$  and  $\log^2 d \leqslant k \leqslant \sqrt{\frac{d}{\log d}}$ . Let  $\varepsilon = k/\sqrt{d}$ . We have

$$S_{2} = \sum_{t=1}^{k} {n \choose t} \int_{\frac{1}{2} - \frac{\varepsilon}{2}}^{\frac{1}{2}} \left( \frac{1}{2\sqrt{y(1-y)}} [(1-\rho)^{2} + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{(2y-1)^{2}}{8y(1-y)}) + \frac{\rho^{2}}{2} \exp(\frac{1}{\rho} (1 - \frac{1}{2y})) + \frac{\rho^{2}}{2} \exp(\frac{1}{\rho} (1 - \frac{1}{2-2y}))] - 1 \right)^{t} [4y(1-y)]^{\frac{d-3}{2}} dy$$

$$\leq \frac{1}{\sqrt{d}}$$

**Proof** When  $y\in [\frac{1}{2}-\frac{\varepsilon}{2},\frac{1}{2}]$ , we can apply Mean Value Theorem on the 4-th order Taylor Expansion of  $\frac{1}{2\sqrt{y(1-y)}}[(1-\rho)^2+2\rho(1-\rho)\exp(-\frac{1}{\rho}\frac{(2y-1)^2}{8y(1-y)})+\frac{\rho^2}{2}\exp(\frac{1}{\rho}(1-\frac{1}{2y}))+\frac{\rho^2}{2}\exp(\frac{1}{\rho}(1-\frac{1}{2-2y}))]-1$ . It follows that

$$\frac{1}{2\sqrt{y(1-y)}} \left[ (1-\rho)^2 + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{(2y-1)^2}{8y(1-y)}) + \frac{\rho^2}{2} \exp(\frac{1}{\rho} (1-\frac{1}{2y})) + \frac{\rho^2}{2} \exp(\frac{1}{\rho} (1-\frac{1}{2-2y})) \right] - 1 + \frac{\rho^2}{2} \exp(\frac{1}{\rho} (1-\frac{1}{2-2y}))$$

for some constant  $C_T > 0$ . Plug this into  $S_2$ , we get:

$$\begin{split} S_2 &= \sum_{t=1}^k \binom{n}{t} \int_{\frac{1}{2} - \frac{\varepsilon}{2}}^{\frac{1}{2}} \left( \frac{1}{2\sqrt{y(1-y)}} [(1-\rho)^2 + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{(2y-1)^2}{8y(1-y)}) \right. \\ &+ \frac{\rho^2}{2} \exp(\frac{1}{\rho} (1-\frac{1}{2y})) + \frac{\rho^2}{2} \exp(\frac{1}{\rho} (1-\frac{1}{2-2y}))] - 1 \right)^t [4y(1-y)]^{\frac{d-3}{2}} dy \\ &\leqslant \sum_{t=1}^k \binom{n}{t} \int_{\frac{1}{2} - \frac{\varepsilon}{2}}^{\frac{1}{2}} \left( \frac{C_T (2y-1)^4}{\rho^2} \right)^t [4y(1-y)]^{\frac{d-3}{2}} dy \end{split}$$

$$= \sum_{t=1}^{k} {n \choose t} \int_{\frac{1}{2} - \frac{\varepsilon}{2}}^{\frac{1}{2}} \left( \frac{C_T (2y-1)^4}{\rho^2} \right)^t [1 - (2y-1)^2]^{\frac{d-3}{2}} dy$$

Since  $0 \le (2y-1)^4 \le \varepsilon^4$  and  $0 \le 1 - (2y-1)^2 \le 1$ , we have:

$$S_{2} \leqslant \sum_{t=1}^{k} \binom{n}{t} \int_{\frac{1}{2} - \frac{\varepsilon}{2}}^{\frac{1}{2}} \left( \frac{C_{T}(2y-1)^{4}}{\rho^{2}} \right)^{t} [1 - (2y-1)^{2}]^{\frac{d-3}{2}} dy$$

$$\leqslant \sum_{t=1}^{k} \binom{n}{t} \int_{\frac{1}{2} - \frac{\varepsilon}{2}}^{\frac{1}{2}} \left( \frac{C_{T}\varepsilon^{4}}{\rho^{2}} \right)^{t} dy$$

$$= \sum_{t=1}^{k} \binom{n}{t} \frac{\varepsilon}{2} \left( \frac{C_{T}\varepsilon^{4}}{\rho^{2}} \right)^{t}$$

$$\leqslant \sum_{t=1}^{k} \frac{\varepsilon}{2} \left( \frac{en}{t} \right)^{t} \left( \frac{C_{T}\varepsilon^{4}}{\rho^{2}} \right)^{t}$$

$$= \sum_{t=1}^{k} \frac{\varepsilon}{2} \left( \frac{enC_{T}\varepsilon^{4}}{t\rho^{2}} \right)^{t}$$

Since  $n \leqslant \frac{\rho^2 d^2}{k^8}$ , we have:

$$S_2 \leqslant \sum_{t=1}^k \frac{\varepsilon}{2} \left( \frac{e\rho^2 d^2 C_T \varepsilon^4}{k^8 t \rho^2} \right)^t$$
$$= \sum_{t=1}^k \frac{\varepsilon}{2} \left( \frac{ed^2 C_T \varepsilon^4}{k^8 t} \right)^t$$

Plug in  $\varepsilon = \frac{k}{\sqrt{d}}$ , we get:

$$S_2 \leqslant \sum_{t=1}^k \frac{k}{2\sqrt{d}} \left(\frac{ed^2 C_T k^4}{k^8 t d^2}\right)^t$$
$$= \sum_{t=1}^k \frac{k}{2\sqrt{d}} \left(\frac{eC_T}{k^4 t}\right)^t$$

Since  $k \geqslant \log^2 d$  and  $t \geqslant 1$ , we have  $\left(\frac{eC_T}{k^4t}\right)^t \leqslant \frac{eC_T}{k^4}$ . Hence,

$$S_2 \leqslant \sum_{t=1}^k \frac{k}{2\sqrt{d}} \frac{eC_T}{k^4} = k \frac{k}{2\sqrt{d}} \frac{eC_T}{k^4} = \frac{eC_T}{2k^2\sqrt{d}} \leqslant \frac{eC_T}{2\log^4 d\sqrt{d}} \leqslant \frac{1}{\sqrt{d}}$$

### <span id="page-32-1"></span>C.6. Proof for upper bound of Eq. (4.6)

<span id="page-32-0"></span>**Lemma 13** Suppose  $\sigma \leqslant d^{-K}$  for some universal constant K that is large enough and  $\rho \geqslant \frac{k}{\sqrt{d}}$ . Let  $\theta = 1 - \sigma^2$ . When  $n \leqslant \frac{\rho^2 d^2}{k^8}$  and  $\log^2 d \leqslant k \leqslant \sqrt{\frac{d}{\log d}}$ , we have

$$T_{1} = \int_{0}^{1-d^{-k\sigma}} \sum_{t=1}^{k} \binom{n}{t} \left( \frac{1}{\sqrt{1-\theta^{2}c^{2}}} \left[ (1-\rho)^{2} + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{\theta c^{2}}{2 - 2\theta^{2}c^{2}}) + \frac{\rho^{2}}{2} \exp(\frac{c}{\rho(1+\theta c)}) + \frac{\rho^{2}}{2} \exp(-\frac{c}{\rho(1-\theta c)}) \right] - 1 \right)^{t} P(c) dc$$

$$\leq \Theta(1)$$

for some constant  $k_{\sigma}$  that is large enough but smaller than  $\frac{K}{2}$ .

To prove this lemma, we first prove Theorem 10 and Theorem 11.

**Fact 10** Under the setting of Lemma 13, for  $0 \le c \le 1 - d^{-k_{\sigma}}$ , we have:

<span id="page-32-2"></span>
$$\exp(-\frac{1}{\rho}\frac{\theta c^2}{2-2\theta^2 c^2}) \leqslant \exp(d^{-k'_{\sigma}})\exp(-\frac{1}{\rho}\frac{c^2}{2-2c^2})$$

and

$$\exp(\frac{c}{\rho(1+\theta c)}) \leqslant \exp(d^{-k_\sigma'}) \exp(\frac{c}{\rho(1+c)})$$

and

$$\exp(-\frac{c}{\rho(1-\theta c)}) \leqslant \exp(d^{-k'_\sigma}) \exp(-\frac{c}{\rho(1-c)})$$

**Proof** For  $0 \le c \le 1 - d^{-k_{\sigma}}$ , we have  $1 - \theta c \ge 1 - c \ge d^{-k_{\sigma}}$  and:

$$\frac{\exp(\frac{c}{\rho(1+c)})}{\exp(\frac{c}{\rho(1+c)})} = \exp(\frac{c}{\rho(1+\theta c)} - \frac{c}{\rho(1+c)})$$

$$= \exp(\frac{c^2(1-\theta)}{\rho(1+\theta c)(1+c)})$$

$$= \exp(\frac{c^2\sigma^2}{\rho(1+\theta c)(1+c)})$$

$$\leq \exp(\frac{4\sigma^2}{\rho})$$

and,

$$\frac{\exp(-\frac{c}{\rho(1-\theta c)})}{\exp(-\frac{c}{\rho(1-c)})} = \exp(\frac{-c}{\rho(1-\theta c)} - \frac{-c}{\rho(1-c)})$$
$$= \exp(\frac{c^2(1-\theta)}{\rho(1-\theta c)(1-c)})$$
$$= \exp(\frac{c^2\sigma^2}{\rho(1-\theta c)(1-c)})$$

$$\leqslant \exp(\frac{4\sigma^2}{\rho d^{-2k_\sigma}})$$

and,

$$\frac{\exp(-\frac{1}{\rho}\frac{\theta c^2}{2-2\theta^2c^2})}{\exp(-\frac{1}{\rho}\frac{c^2}{2-2c^2})} \leqslant \frac{\exp(-\frac{1}{\rho}\frac{\theta^2c^2}{2-2\theta^2c^2})}{\exp(-\frac{1}{\rho}\frac{c^2}{2-2c^2})}$$

$$= \exp\left(-\frac{1}{\rho}\frac{\theta^2c^2}{2-2c^2} + \frac{1}{\rho}\frac{c^2}{2-2c^2}\right)$$

$$= \exp\left(\frac{c^2}{\rho}\frac{1-\theta^2}{2(1-\theta^2c^2)(1-c^2)}\right)$$

$$= \exp\left(\frac{c^2}{\rho}\frac{(1+\theta)(1-\theta)}{2(1+\theta c)(1-\theta c)(1+c)(1-c)}\right)$$

$$\leqslant \exp\left(\frac{c^2}{\rho}\frac{2\sigma^2}{2(1-\theta c)(1-c)}\right)$$

$$= \exp\left(\frac{c^2}{\rho}\frac{\sigma^2}{(1-\theta c)(1-c)}\right)$$

$$\leqslant \exp\left(\frac{c^2}{\rho}\frac{\sigma^2}{d^{-2k_\sigma}}\right)$$

$$\leqslant \exp\left(\frac{\sigma^2}{\rho d^{-2k_\sigma}}\right)$$

Since  $\rho\geqslant\frac{k}{\sqrt{d}}\geqslant\frac{1}{\sqrt{d}}$  and  $\sigma\leqslant d^{-K}$ , we have  $\frac{\sigma^2}{\rho d^{-2k\sigma}}\leqslant d^{-2K+2k\sigma+1}$ ,  $\frac{4\sigma^2}{\rho}\leqslant d^{-2K+1}$  and  $\frac{4\sigma^2}{\rho d^{-2k\sigma}}\leqslant d^{-2K+2k\sigma+1}$ . Let  $k'_\sigma=2K-2k_\sigma-1$ , we can get  $\frac{\sigma^2}{2\rho d^{-2k\sigma}}\leqslant d^{-k'_\sigma}$ ,  $\frac{4\sigma^2}{\rho}\leqslant d^{-2K+1}\leqslant d^{-k'_\sigma}$  and  $\frac{4\sigma^2}{\rho d^{-2k\sigma}}\leqslant d^{-k'_\sigma}$ . Notice that, since  $k_\sigma\leqslant\frac{K}{2}$ , we have  $k'_\sigma\geqslant K-1$  which is a large enough constant. Hence, we have:

$$\exp(-\frac{1}{\rho}\frac{\theta c^2}{2-2\theta^2 c^2}) \leqslant \exp(d^{-k'_{\sigma}})\exp(-\frac{1}{\rho}\frac{c^2}{2-2c^2})$$

and

$$\exp(\frac{c}{\rho(1+\theta c)}) \leqslant \exp(d^{-k_\sigma'}) \exp(\frac{c}{\rho(1+c)})$$

and

$$\exp(-\frac{c}{\rho(1-\theta c)}) \leqslant \exp(d^{-k'_\sigma}) \exp(-\frac{c}{\rho(1-c)})$$

<span id="page-33-0"></span>**Fact 11** *Under the setting of Lemma 13, we have:* 

$$T_1 \leqslant \int_0^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \left( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \right)^t P(c) dc$$

where

$$\Upsilon = \frac{1}{\sqrt{1-c^2}} \Big[ (1-\rho)^2 + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{c^2}{2-2c^2}) + \frac{\rho^2}{2} \exp(\frac{c}{\rho(1+c)}) + \frac{\rho^2}{2} \exp(-\frac{c}{\rho(1-c)}) \Big] - 1$$

**Proof** Plug Theorem 10 into  $T_1$ , we get:

$$\begin{split} T_1 &= \int_0^{1-d^{-k\sigma}} \sum_{t=1}^k \binom{n}{t} \Big( \frac{1}{\sqrt{1-\theta^2 c^2}} \Big[ (1-\rho)^2 + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{\theta c^2}{2-2\theta^2 c^2}) \\ &+ \frac{\rho^2}{2} \exp(\frac{c}{\rho(1+\theta c)}) + \frac{\rho^2}{2} \exp(-\frac{c}{\rho(1-\theta c)}) \Big] - 1 \Big)^t P(c) dc \\ &\leqslant \int_0^{1-d^{-k\sigma}} \sum_{t=1}^k \binom{n}{t} \Big( \frac{1}{\sqrt{1-c^2}} \Big[ \exp(d^{-k'\sigma})(1-\rho)^2 + \exp(d^{-k'\sigma}) 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{c^2}{2-2c^2}) \\ &+ \exp(d^{-k'\sigma}) \frac{\rho^2}{2} \exp(\frac{c}{\rho(1+c)}) + \exp(d^{-k'\sigma}) \frac{\rho^2}{2} \exp(-\frac{c}{\rho(1-c)}) \Big] - 1 \Big)^t P(c) dc \\ &= \int_0^{1-d^{-k\sigma}} \sum_{t=1}^k \binom{n}{t} \Big\{ \exp(d^{-k'\sigma}) \Big( \frac{1}{\sqrt{1-c^2}} \Big[ (1-\rho)^2 + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{c^2}{2-2c^2}) \\ &+ \frac{\rho^2}{2} \exp(\frac{c}{\rho(1+c)}) + \frac{\rho^2}{2} \exp(-\frac{c}{\rho(1-c)}) \Big] - 1 \Big) + \exp(d^{-k'\sigma}) - 1 \Big\}^t P(c) dc \\ &= \int_0^{1-d^{-k\sigma}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'\sigma}) \Upsilon + \exp(d^{-k'\sigma}) - 1 \Big)^t P(c) dc \end{split}$$

where, for simplicity, we write:

$$\Upsilon = \frac{1}{\sqrt{1-c^2}} \left[ (1-\rho)^2 + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{c^2}{2-2c^2}) + \frac{\rho^2}{2} \exp(\frac{c}{\rho(1+c)}) + \frac{\rho^2}{2} \exp(-\frac{c}{\rho(1-c)}) \right] - 1$$

Observe that, since  $d^{-k'_{\sigma}} < 0.01$  for large enough d and  $k'_{\sigma}$ , we have  $\exp(d^{-k'_{\sigma}}) \leqslant 1 + d^{-k'_{\sigma}} + d^{-2k'_{\sigma}} \leqslant 1 + d^{-k''_{\sigma}}$  for some constant  $k''_{\sigma}$ . Therefore, we have:

$$T_1 \leqslant \int_0^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \left( \exp(d^{-k'_{\sigma}}) \Upsilon + \exp(d^{-k'_{\sigma}}) - 1 \right)^t P(c) dc$$
  
$$\leqslant \int_0^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \left( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \right)^t P(c) dc$$

**Proof** [Proof of Lemma 13] Given Theorem 11, we further split the integral into two parts  $[0,\eta]$  and  $[\eta,1-d^{-k_\sigma}]$  such that  $\exp(d^{-k_\sigma'})\Upsilon\leqslant d^{-\frac{k_\sigma''}{2}}$  in  $[0,\eta]$  and  $\exp(d^{-k_\sigma'})\Upsilon\geqslant d^{-\frac{k_\sigma''}{2}}$  in  $[\eta,1-d^{-k_\sigma}]$ :

$$T_1 \leqslant \int_0^{\eta} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k'_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k'_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k'_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k'_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^k \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k'_{\sigma}} \Big)^t P(c) dc + \int_{\eta}^{1-$$

For the first part of  $T_1$ , we have:

$$\int_0^{\eta} \sum_{t=1}^k \binom{n}{t} \left( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \right)^t P(c) dc \leqslant \int_0^{\eta} \sum_{t=1}^k \binom{n}{t} \left( d^{-\frac{k''}{2}} + d^{-k''_{\sigma}} \right)^t P(c) dc$$

$$\leqslant \int_0^{\eta} \sum_{t=1}^k \binom{n}{t} \left(2d^{-\frac{k''_{\sigma}}{2}}\right)^t P(c) dc$$

$$\leqslant \int_0^{\eta} \sum_{t=1}^k \left(\frac{en}{t}\right)^t \left(2d^{-\frac{k''_{\sigma}}{2}}\right)^t P(c) dc$$

$$\leqslant \int_0^{\eta} \sum_{t=1}^k \left(\frac{2end^{-\frac{k''_{\sigma}}{2}}}{t}\right)^t P(c) dc$$

Plug in  $n \leqslant \frac{\rho^2 d^2}{k^8}$ ,  $\rho \leqslant 1$  and  $t \geqslant 1$ , we get:

$$\int_{0}^{\eta} \sum_{t=1}^{k} \binom{n}{t} \left( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \right)^{t} P(c) dc \leqslant \int_{0}^{\eta} \sum_{t=1}^{k} \left( \frac{2e\rho^{2} d^{2 - \frac{k''_{\sigma}}{2}}}{k^{8}t} \right)^{t} P(c) dc$$

$$\leqslant \int_{0}^{\eta} \sum_{t=1}^{k} \left( \frac{2ed^{2 - \frac{k''_{\sigma}}{2}}}{k^{8}} \right)^{t} P(c) dc$$

Since constant  $k_{\sigma}''$  is large enough, we have  $\frac{2ed^{2} - \frac{k_{\sigma}''}{2}}{k^{8}} < 1$ . Hence,

$$\int_{0}^{\eta} \sum_{t=1}^{k} \binom{n}{t} \left( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \right)^{t} P(c) dc \leqslant \int_{0}^{\eta} \sum_{t=1}^{k} \frac{2ed^{2 - \frac{k''_{\sigma}}{2}}}{k^{8}} P(c) dc$$

$$= \int_{0}^{\eta} \frac{2ed^{2 - \frac{k''_{\sigma}}{2}}}{k^{7}} P(c) dc$$

$$\leqslant \frac{2ed^{2 - \frac{k''_{\sigma}}{2}}}{k^{7}}$$

Since  $k \geqslant \log^2 d$  and constant  $k_{\sigma}''$  is large enough, we have:

<span id="page-35-0"></span>
$$\int_0^{\eta} \sum_{t=1}^k \binom{n}{t} \left( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \right)^t P(c) dc \leqslant \frac{2ed^{2-\frac{k''_{\sigma}}{2}}}{\log^{14} d} \leqslant \Theta \left( 1 \right) \tag{C.3}$$

For the second part of  $T_1$ , we have  $\exp(d^{-k'_{\sigma}})\Upsilon \geqslant d^{-\frac{k''_{\sigma}}{2}}$ , which implies  $d^{-\frac{k''_{\sigma}}{2}}\exp(d^{-k'_{\sigma}})\Upsilon \geqslant d^{-k''_{\sigma}}$ . Therefore, we can get:

$$\begin{split} & \int_{\eta}^{1-d^{-k\sigma}} \sum_{t=1}^{k} \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \Big)^{t} P(c) dc \\ & \leqslant \int_{\eta}^{1-d^{-k\sigma}} \sum_{t=1}^{k} \binom{n}{t} \Big( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-\frac{k''_{\sigma}}{2}} \exp(d^{-k'_{\sigma}}) \Upsilon \Big)^{t} P(c) dc \\ & = \int_{\eta}^{1-d^{-k\sigma}} \sum_{t=1}^{k} \binom{n}{t} \Big( 1 + d^{-\frac{k''_{\sigma}}{2}} \Big)^{t} \exp(t d^{-k'_{\sigma}}) \Upsilon^{t} P(c) dc \end{split}$$

$$\leqslant \int_{\eta}^{1-d^{-k\sigma}} \sum_{t=1}^{k} \binom{n}{t} \exp(td^{-\frac{k''_{\sigma}}{2}}) \exp(td^{-k'_{\sigma}}) \Upsilon^{t} P(c) dc$$

$$= \int_{\eta}^{1-d^{-k\sigma}} \sum_{t=1}^{k} \binom{n}{t} \exp(td^{-\frac{k''_{\sigma}}{2}} + td^{-k'_{\sigma}}) \Upsilon^{t} P(c) dc$$

$$\leqslant \int_{\eta}^{1-d^{-k\sigma}} \sum_{t=1}^{k} \binom{n}{t} \exp(kd^{-\frac{k''_{\sigma}}{2}} + kd^{-k'_{\sigma}}) \Upsilon^{t} P(c) dc$$

$$\leqslant \exp(kd^{-\frac{k''_{\sigma}}{2}} + kd^{-k'_{\sigma}}) \int_{\eta}^{1-d^{-k\sigma}} \sum_{t=1}^{k} \binom{n}{t} \Upsilon^{t} P(c) dc$$

$$\leqslant \exp(kd^{-\frac{k''_{\sigma}}{2}} + kd^{-k'_{\sigma}}) \int_{-1}^{1} \sum_{t=1}^{k} \binom{n}{t} \Upsilon^{t} P(c) dc$$

$$= \exp(kd^{-\frac{k''_{\sigma}}{2}} + kd^{-k'_{\sigma}}) \mathbb{E}\left[\sum_{t=1}^{k} \binom{n}{t} \Upsilon^{t}\right]$$

Since  $k \leqslant \sqrt{\frac{d}{\log d}} \leqslant \sqrt{d}$  and  $k'_{\sigma}$ ,  $k''_{\sigma}$  are large enough constants, we have:

$$\exp(kd^{-\frac{k_{\sigma}''}{2}} + kd^{-k_{\sigma}'}) \leqslant \exp(d^{\frac{1}{2} - \frac{k_{\sigma}''}{2}} + d^{\frac{1}{2} - k_{\sigma}'}) \leqslant \Theta(1)$$

Notice that, in Section 4.2, we have proved:

<span id="page-36-0"></span>
$$\mathbb{E}_{c}\left[\sum_{t=1}^{k} \binom{n}{t} \Upsilon^{t}\right] \leqslant \Theta(1)$$

Hence, we can get:

$$\int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^{k} \binom{n}{t} \left( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \right)^{t} P(c) dc \leqslant \exp(kd^{-\frac{k''_{\sigma}}{2}} + kd^{-k'_{\sigma}}) \mathbb{E}\left[ \sum_{t=1}^{k} \binom{n}{t} \Upsilon^{t} \right]$$

$$\leqslant \Theta(1)$$
(C.4)

Combine Eq. (C.3) and Eq. (C.4), we get:

$$T_{1} \leq \int_{0}^{\eta} \sum_{t=1}^{k} \binom{n}{t} \left( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \right)^{t} P(c) dc + \int_{\eta}^{1-d^{-k_{\sigma}}} \sum_{t=1}^{k} \binom{n}{t} \left( \exp(d^{-k'_{\sigma}}) \Upsilon + d^{-k''_{\sigma}} \right)^{t} P(c) dc \right)$$

$$\leq \Theta \left( 1 \right)$$

### <span id="page-37-1"></span>C.7. Proof for upper bound of Eq. (4.7)

<span id="page-37-0"></span>**Lemma 14** Suppose  $\sigma \leqslant d^{-K}$  for some constant K that is large enough and  $\rho \geqslant \frac{k}{\sqrt{d}}$ . When  $n \leqslant \frac{\rho^2 d^2}{k^8}$  and  $\log^2 d \leqslant k \leqslant \sqrt{\frac{d}{\log d}}$ , for  $\theta = 1 - \sigma^2$ , we have

$$T_{2} = \int_{1-d^{-k_{\sigma}}}^{1} \sum_{t=1}^{k} \binom{n}{t} \left( \frac{1}{\sqrt{1-\theta^{2}c^{2}}} \left[ (1-\rho)^{2} + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{\theta c^{2}}{2-2\theta^{2}c^{2}}) + \frac{\rho^{2}}{2} \exp(\frac{c}{\rho(1+\theta c)}) + \frac{\rho^{2}}{2} \exp(-\frac{c}{\rho(1-\theta c)}) \right] - 1 \right)^{t} P(c) dc$$

$$\leqslant \Theta(1)$$

for some constant  $k_{\sigma}$  that is large enough but smaller than  $\frac{K}{2}$ .

**Proof** When  $1 - d^{-k_{\sigma}} \leqslant c \leqslant 1$ , we have  $-\frac{1}{\rho} \frac{\theta c^2}{2 - 2\theta^2 c^2} \leqslant 0$ ,  $\frac{c}{\rho(1 + \theta c)} \leqslant \frac{1}{\rho}$  and  $-\frac{c}{\rho(1 - \theta c)} \leqslant 0$ , which implies:

$$T_{2} = \int_{1-d^{-k_{\sigma}}}^{1} \sum_{t=1}^{k} \binom{n}{t} \left( \frac{1}{\sqrt{1-\theta^{2}c^{2}}} \left[ (1-\rho)^{2} + 2\rho(1-\rho) \exp(-\frac{1}{\rho} \frac{\theta c^{2}}{2-2\theta^{2}c^{2}}) \right] \right) + \frac{\rho^{2}}{2} \exp(\frac{c}{\rho(1+\theta c)}) + \frac{\rho^{2}}{2} \exp(-\frac{c}{\rho(1-\theta c)}) - 1 t^{2} P(c) dc$$

$$\leq \int_{1-d^{-k_{\sigma}}}^{1} \sum_{t=1}^{k} \binom{n}{t} \left( \frac{1}{\sqrt{1-c^{2}}} \left[ (1-\rho)^{2} + 2\rho(1-\rho) + \frac{\rho^{2}}{2} \exp(\frac{1}{\rho}) + \frac{\rho^{2}}{2} \right] - 1 t^{2} P(c) dc$$

$$= \int_{1-d^{-k_{\sigma}}}^{1} \sum_{t=1}^{k} \binom{n}{t} \left( \frac{1}{\sqrt{1-c^{2}}} \left[ 1 - \frac{\rho^{2}}{2} + \frac{\rho^{2}}{2} \exp(\frac{1}{\rho}) \right] - 1 t^{2} P(c) dc$$

$$\leq \int_{1-d^{-k_{\sigma}}}^{1} \sum_{t=1}^{k} \binom{n}{t} \left( \frac{1}{\sqrt{1-c^{2}}} \left[ 1 + \frac{1}{2} \exp(\frac{1}{\rho}) \right] - 1 t^{2} P(c) dc$$

$$\leq \int_{1-d^{-k_{\sigma}}}^{1} \sum_{t=1}^{k} \binom{n}{t} \left( \frac{1}{\sqrt{1-c^{2}}} \left[ 1 + \frac{1}{2} \exp(\frac{1}{\rho}) \right] \right)^{t} P(c) dc$$

Since we have  $\frac{1}{2}\exp(\frac{1}{\rho}) \geqslant 1$  for  $\rho \leqslant 1$ , we can get:

$$T_{2} \leqslant \int_{1-d^{-k_{\sigma}}}^{1} \sum_{t=1}^{k} \binom{n}{t} \left(\frac{\exp(\frac{1}{\rho})}{\sqrt{1-c^{2}}}\right)^{t} P(c) dc$$

$$\leqslant \int_{1-d^{-k_{\sigma}}}^{1} \sum_{t=1}^{k} \left(\frac{en}{t}\right)^{t} \left(\frac{\exp(\frac{1}{\rho})}{\sqrt{1-c^{2}}}\right)^{t} P(c) dc$$

$$= \int_{1-d^{-k_{\sigma}}}^{1} \sum_{t=1}^{k} \left(\frac{en \exp(\frac{1}{\rho})}{t\sqrt{1-c^{2}}}\right)^{t} P(c) dc$$

$$\leqslant \int_{1-d^{-k_{\sigma}}}^{1} \sum_{t=1}^{k} \left(\frac{en \exp(\frac{1}{\rho})}{\sqrt{1-c^{2}}}\right)^{k} P(c) dc$$

$$= \int_{1-d^{-k}\sigma}^{1} k \left(\frac{en \exp(\frac{1}{\rho})}{\sqrt{1-c^2}}\right)^k P(c)dc$$
  
$$\leq ke^k n^k \exp(\frac{k}{\rho}) \int_{1-d^{-k}\sigma}^{1} \left(\frac{1}{\sqrt{1-c^2}}\right)^k P(c)dc$$

Now, we apply change of variable c=2y-1 and plug in  $y\sim Beta(\frac{d-1}{2},\frac{d-1}{2})$ :

$$T_{2} \leqslant ke^{k}n^{k} \exp(\frac{k}{\rho}) \int_{1-d^{-k}\sigma/2}^{1} \left(\frac{1}{\sqrt{1-(2y-1)^{2}}}\right)^{k} P(y) dy$$

$$= ke^{k}n^{k} \exp(\frac{k}{\rho}) \int_{1-d^{-k}\sigma/2}^{1} \left(\frac{1}{\sqrt{4y(1-y)}}\right)^{k} \frac{[y(1-y)]^{\frac{d-3}{2}}}{\mathcal{B}(\frac{d-1}{2}, \frac{d-1}{2})} dy$$

$$= \Theta\left\{ke^{k}n^{k} \exp(\frac{k}{\rho}) \int_{1-d^{-k}\sigma/2}^{1} 2^{d-k} \sqrt{d-1} [y(1-y)]^{\frac{d-k-3}{2}} dy\right\}$$

Since  $1 - \frac{d^{-k_{\sigma}}}{2} \leqslant y \leqslant 1$  and  $0 \leqslant 1 - y \leqslant \frac{d^{-k_{\sigma}}}{2}$ , we have:

$$T_{2} \leqslant \Theta \left\{ ke^{k}n^{k} \exp\left(\frac{k}{\rho}\right) \int_{1-d^{-k\sigma/2}}^{1} 2^{d-k} \sqrt{d-1} \left[\frac{d^{-k\sigma}}{2}\right]^{\frac{d-k-3}{2}} dy \right\}$$

$$= \Theta \left\{ ke^{k}n^{k} \exp\left(\frac{k}{\rho}\right) \int_{1-d^{-k\sigma/2}}^{1} 2^{\frac{d-k}{2}} \sqrt{d-1} d^{\frac{-k\sigma(d-k-3)}{2}} dy \right\}$$

$$= \Theta \left\{ ke^{k}n^{k} \exp\left(\frac{k}{\rho}\right) \frac{d^{-k\sigma}}{2} 2^{\frac{d-k}{2}} \sqrt{d-1} d^{\frac{-k\sigma(d-k-3)}{2}} \right\}$$

$$= \Theta \left\{ ke^{k}n^{k} \exp\left(\frac{k}{\rho}\right) 2^{\frac{d-k}{2}} d^{\frac{-k\sigma(d-k-1)}{2} + \frac{1}{2}} \right\}$$

Plug in  $n\leqslant \frac{\rho^2d^2}{k^8}\leqslant d^2,\, \rho\geqslant \frac{k}{\sqrt{d}}\geqslant \frac{1}{\sqrt{d}}$  and  $k\leqslant \sqrt{\frac{d}{\log d}}\leqslant \sqrt{d}$ , we get:

$$T_{2} \leqslant \Theta \left\{ ke^{k} n^{k} \exp(\frac{k}{\rho}) 2^{\frac{d-k}{2}} d^{\frac{-k_{\sigma}(d-k-1)}{2} + \frac{1}{2}} \right\}$$

$$\leqslant \Theta \left\{ \sqrt{d} \exp(\sqrt{d}) d^{2\sqrt{d}} \exp(d) \exp(\frac{d}{2}) d^{-\frac{k_{\sigma}d}{2} + \frac{k_{\sigma}\sqrt{d}}{2} + \frac{k_{\sigma}}{2} + \frac{1}{2}} \right\}$$

$$= \Theta \left\{ \exp\left(-\frac{k_{\sigma}}{2} d \log d + (\frac{k_{\sigma}}{2} + 2)\sqrt{d} \log d + \frac{3}{2} d + \sqrt{d} + (\frac{k_{\sigma}}{2} + 1) \log d\right) \right\}$$

Since  $k_{\sigma}$  is a large enough constant, we have:

$$\exp\left(-\frac{k_{\sigma}}{2}d\log d + (\frac{k_{\sigma}}{2} + 2)\sqrt{d}\log d + \frac{3}{2}d + \sqrt{d} + (\frac{k_{\sigma}}{2} + 1)\log d\right) \leqslant \Theta(1)$$

<span id="page-38-0"></span>Thus, we have:

$$T_2 \leqslant \Theta(1)$$