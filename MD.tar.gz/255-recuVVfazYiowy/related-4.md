# cse547, math547 DISCRETE MATHEMATICS

Professor Anita Wasilewska

### LECTURE 11

### CHAPTER 3 INTEGER FUNCTIONS

PART1: Floors and Ceilings

PART 2: Floors and Ceilings Applications

### PART 1 Floors and Ceilings

#### Floor and Ceiling Definitions

### **Floor Definition**

For any x ∈ R we define

b x c = the greatest integer less than or equal to x

### **Ceiling Definition**

For any *x* ∈ R we define

d x e = the least (smallest) integer greater than or equal to x

## Floor and Ceiling Definitions

## **Definitions** written Symbolicaly

## **Floor**

$$[x] = max\{a \in Z: a \leq x\}$$

### **Ceiling**

$$[x] = min\{a \in Z: a \ge x\}$$

### Floor and Ceiling Basics

**Remark**: we use, after the book the notion of max, min elements instead of the least( smallest) and greatest elements because for the Posets *P*1, *P*<sup>2</sup> we have that

*P*1=({ a∈ Z : a ≤ x },≤) has unique max element that is the greatest and

*P*2=({ a∈ Z : a ≥ x },≥) has unique min element that is the least (smallest)

![](_page_6_Picture_4.jpeg)

### Floor and Ceiling Basics

### **Fact 1**

For any x∈ R b x c and d x e **exist** and are **unique**

We **define** functions **Floor**

$$f_1: R \longrightarrow Z$$

$$f_1(x) = \lfloor x \rfloor = max\{a \in Z : a \leq x\}$$

## **Ceiling**

$$f_2: R \longrightarrow Z$$

$$f_2(x) = [x] = min\{a \in Z : a \ge x\}$$

![](_page_7_Picture_9.jpeg)

## Floor and Ceiling Basics

# Graphs of *f*1, *f*<sup>2</sup>

![](_page_8_Figure_2.jpeg)

**1.** 
$$\lfloor x \rfloor = x$$
 if and only if  $x \in Z$ 

**2.** 
$$\lceil x \rceil = x$$
 if and only if  $x \in Z$ 

**3.** 
$$x-1 < \lfloor x \rfloor \le \lceil x \rceil < x+1 \quad x \in R$$

$$4. \quad \lfloor -x \rfloor = -\lceil x \rceil \quad x \in R$$

$$5. \quad \lceil -x \rceil = -\lfloor x \rfloor \quad x \in R$$

**6.** d*x*e − b*x*c = [*x* < *Z*] characteristic function of *x* < *Z* we re- write **6.** as follows

7. 
$$\lceil x \rceil - \lfloor x \rfloor = 0$$
 for  $x \in Z$ 

$$\lceil x \rceil - \lfloor x \rfloor = 1$$
 for  $x \notin Z$ 

**8.** 
$$[x] = n$$
 if and only if  $n \le x < n+1$  for  $x \in R$ ,  $n \in Z$ 

**9.** 
$$\lfloor x \rfloor = n$$
 if and only if  $x - 1 < n \le x$  for  $x \in R$ ,  $n \in Z$ 

**10.** 
$$[x] = n$$
 if and only if  $n-1 < x \le n$  for  $x \in R$ ,  $n \in Z$ 

**11.** 
$$[x] = n$$
 if and only if  $x \le n < x+1$  for  $x \in R$ ,  $n \in Z$ 

**12.** 
$$\lfloor x+n\rfloor = \lfloor x\rfloor + n$$
 and  $\lceil x+n\rceil = \lceil x\rceil + n$  for  $x \in R, n \in Z$ 

![](_page_12_Picture_4.jpeg)

## Some Proofs

### **Proof** of

**12.** 
$$\lfloor x+n \rfloor = \lfloor x \rfloor + n$$
 for  $x \in R$ ,  $n \in \mathbb{Z}$ 

Directly from definition we have that

$$\lfloor x \rfloor \leq x < \lfloor x \rfloor + 1$$

Adding n to all sides we get

$$\lfloor x \rfloor + n \leq x + n < \lfloor x \rfloor + n + 1$$

Applying

**8.** 
$$[x] = m$$
 if and only if  $m \le x < m+1$  for  $x \in R$ ,  $m \in Z$ 

for 
$$m = |x| + n$$
 we get  $|x+n| = m$ , i.e.

$$|x+n|=|x|+n$$

![](_page_13_Picture_11.jpeg)

### Some Proofs

**Observe** that it is **not true** that for all *x* ∈ *R*, *n* ∈ *Z*

$$\lfloor nx \rfloor = n \lfloor x \rfloor$$

Take *n* = 2, *x* = 1 2 and we get that

$$\left[2\cdot\frac{1}{2}\right]=1\neq 2\left[\frac{1}{2}\right]=0$$

In all properties *x* ∈ *R*, *n* ∈ *Z*

- **13.** *x* < *n* if and only if b*x*c < *n*
- **14.** *n* < *x* if and only if *n* < d*x*e
- **15.** *x* ≤ *n* if and only if d*x*e ≤ *n*
- **16.** *n* ≤ *x* if and only if *n* ≤ b*x*c

### Some Proofs

**Proof** of **13.** 
$$x < n$$
 if and only if  $\lfloor x \rfloor < n$   
Let  $x < n$   
We know that  $\lfloor x \rfloor \le x$  so  $\lfloor x \rfloor \le x < n$   
and hence  $\lfloor x \rfloor < n$   
Let  $\lfloor x \rfloor < n$   
By property **3.**  $x - 1 < \lfloor x \rfloor \le \lceil x \rceil < x + 1$ ,  $x \in R$   
 $x - 1 < \lfloor x \rfloor$ , i.e  $x < \lfloor x \rfloor + 1$   
But  $\lfloor x \rfloor < n$ , so  $\lfloor x \rfloor + 1 \le n$  and  $x < \lfloor x \rfloor + 1 \le n$ 

Hence *x* < *n* what ends the proof

#### Fractional Part of x

#### **Definition**

We define: 
$$\{x\} = x - \lfloor x \rfloor$$

- {*x*} is called a **fractional** part of x
- b*x*c is called the **integer** part of x

By definition

$$0 \le \{x\} < 1$$

and we write

$$X = \lfloor X \rfloor + \{X\}$$

#### Fractional Part of x

### **Fact 2**

IF 
$$x = n + \Theta$$
,  $n \in \mathbb{Z}$  and  $0 \le \Theta < 1$   
THEN  $n = \lfloor x \rfloor$  and  $\Theta = \{x\}$ 

## **Proof**

Let 
$$x = n + \Theta$$
,  $\Theta \in [0,1)$ . We get by **12.**  $\lfloor x \rfloor = \lfloor n + \Theta \rfloor = n + \lfloor \Theta \rfloor = n$  and  $x = n + \Theta = \lfloor x \rfloor + \Theta = \lfloor x \rfloor + \{x\}$  so  $\Theta = \{x\}$ 

### Properties

We have proved in **12.**

$$\lfloor x+n\rfloor = \lfloor x\rfloor + n$$
 for  $x \in R, n \in Z$ 

**Question**: What happens when we consider

$$\lfloor x + y \rfloor$$
 where  $x \in R$  and  $y \in R$ 

Is it possible (and when it is possible) that for any *x*,*y* ∈ *R*

$$\lfloor x + y \rfloor = \lfloor x \rfloor + \lfloor y \rfloor$$

#### Properties

### Consider

$$x = \lfloor x \rfloor + \{x\}, \text{ and } y = \lfloor y \rfloor + \{y\}$$

We evaluate using **12.** b*x* +*n*c = b*x*c+*n*

$$\lfloor x + y \rfloor = \lfloor \lfloor x \rfloor + \lfloor y \rfloor + \{x\} + \{y\} \rfloor = \lfloor x \rfloor + \lfloor y \rfloor + \lfloor \{x\} + \{y\} \rfloor$$

By definition 0 ≤ {*x*} < 1 and 0 ≤ {*y*} < 1 so we have that

$$0 \le \{x\} + \{y\} < 2$$

Hence we have proved the following property

![](_page_20_Picture_8.jpeg)

### Properties

## **Fact 3**

For any *x*,*y* ∈ *R*

$$\lfloor x + y \rfloor = \lfloor x \rfloor + \lfloor y \rfloor$$
 when  $0 \le \{x\} + \{y\} < 1$ 

and

$$[x+y] = [x] + [y] + 1$$
 when  $1 \le \{x\} + \{y\} < 2$ 

![](_page_21_Picture_6.jpeg)

#### Examples

### **Example 1**

Find dlog<sup>2</sup> 35e

**Observe** that 2 <sup>5</sup> < 35 ≤ 2 6

Taking log with respect to base 2 , we get

$$5 < \log_2 35 \le 6$$

We use property

**10.** 
$$\lceil x \rceil = n$$
 if and only if  $n-1 < x \le n$ 

and get

$$\lceil \log_2 35 \rceil = 6$$

### Examples

#### **Example 2**

Find dlog<sup>2</sup> 32e

**Observe** that 2 <sup>4</sup> < 32 ≤ 2 5

Taking log with respect to base 2 , we get

$$4 < \log_2 32 \le 5$$

We use property **10.** and get

$$\lceil \log_2 32 \rceil = 5$$

#### Examples

### **Example 3**

Find 
$$\lfloor \log_2 35 \rfloor$$

**Observe** that 
$$2^5 \le 35 < 2^6$$

Taking log with respect to base 2 , we get

$$5 \le \log_2 32 < 6$$

We use property

**8.** 
$$[x] = n$$
 if and only if  $n \le x < n+1$ 

and we get

$$\lfloor log_2 32 \rfloor = 5 = \lceil log_2 32 \rceil$$

![](_page_24_Picture_10.jpeg)

#### Observation

**Observe** that 35 has 6 digits in its binary representation 35 = (1000011)<sup>2</sup> and dlog<sup>2</sup> 35e = 6

### **Question**

Is the number of digits in binary representation of n always equal dlog<sup>2</sup> *n*e ?

**Answer:** NO, it is not true

Consider 32 = (1000000)<sup>2</sup>

32 has 6 digits in its binary representation but

$$\lceil \log_2 32 \rceil = 5 \neq 6$$

![](_page_25_Picture_8.jpeg)

#### Small Problem

**Question:** Can we develop a connection (formula) between blog<sup>2</sup> *n*c and number of digits (m) in the binary representation of n (*n* > 0)?

**Answer:** YES

### Small Problem Solution

Let *n* , 0, *n* ∈ *N* be such such that it has m bits in **binary representation**

Hence, by definition we have

$$n = a_{m-1}2^{m-1} + \ldots + a_0$$

and

$$2^{m-1} \leq n < 2^m$$

So we get **solution**

$$m-1 \le \log_2 n < m$$
 if and only if  $\lfloor \log_2 n \rfloor = m-1$ 

![](_page_27_Picture_8.jpeg)

#### Small Fact and Exercise

We have proved the following

#### **Fact 4**

For any *n* , 0, *n* ∈ *N* such such that it has m bits in **binary representation** we have that

$$\lfloor \log_2 n \rfloor = m - 1$$

### **Example**

Take 
$$n = 35$$
,  $m = 6$  so  $\lfloor \log_2 35 \rfloor = 6 - 1 = 5$   
Take  $n = 32$ ,  $m = 6$  so we get  $\lfloor \log_2 32 \rfloor = 6 - 1 = 5$ 

**Exercise** Develop similar formula for dlog<sup>2</sup> *n*e

![](_page_28_Picture_8.jpeg)

### Another Small Fact

### **Fact 5**

For any *x* ∈ *R*, *x* ≥ 0 the following property holds

$$\left\lfloor \sqrt{\lfloor X \rfloor} \right\rfloor = \left\lfloor \sqrt{X} \right\rfloor$$

## **Proof**

Take 
$$\sqrt{|x|}$$

We proceed as follows

**First** we get rid of the outside b c and **then** of the square root and of the inside b c

#### Proof

Let 
$$m = \lfloor \sqrt{\lfloor x \rfloor} \rfloor$$
  
By property

**8.** 
$$[x] = n$$
 if and only if  $n \le x < n+1$ 

we get that

$$m = \lfloor \sqrt{\lfloor x \rfloor} \rfloor$$
 if and only if  $m \le \sqrt{\lfloor x \rfloor} < m + 1$ 

Squaring all sides of the inequality we get

(\*) 
$$m = \left| \sqrt{\lfloor x \rfloor} \right|$$
 if and only if  $m^2 \le \lfloor x \rfloor < (m+1)^2$ 

![](_page_30_Picture_7.jpeg)

### Proof

We proved that

$$(\star) \quad m = \left\lfloor \sqrt{\lfloor x \rfloor} \right\rfloor \quad \text{if and only if} \quad m^2 \leq \lfloor x \rfloor < (m+1)^2$$
 Using property

**16.** *n* ≤ *x* if and only if *n* ≤ b*x*c

on the left of inequality in (?) and property

**13.** *x* < *n* if and only if b*x*c < *n* on the right side of inequality in (?) we get

$$(\star\star)$$
  $m = \left\lfloor \sqrt{\lfloor x \rfloor} \right\rfloor$  if and only if  $m^2 \le x < (m+1)^2$ 

![](_page_31_Picture_7.jpeg)

## Proof

We already proved that

$$(\star\star)$$
  $m = \left|\sqrt{\lfloor x\rfloor}\right|$  if and only if  $m^2 \le x < (m+1)^2$ 

Now we retrace our steps backwards. First taking <sup>√</sup> *x* on all sides of inequality (??) (all components are ≥0), we get

$$m = \lfloor \sqrt{\lfloor x \rfloor} \rfloor$$
 if and only if  $m \le \sqrt{x} < m + 1$ 

We use now the property

**8.** 
$$\lfloor x \rfloor = n$$
 if and only if  $n \le x < n+1$ 

$$m = \left| \sqrt{\lfloor x \rfloor} \right|$$
 if and only if  $\lfloor \sqrt{x} \rfloor = m$ 

and hence

and get

$$\left| \sqrt{\lfloor x \rfloor} \right| = \lfloor \sqrt{x} \rfloor$$

It **ends** the **proof**

![](_page_32_Picture_11.jpeg)

### Exercise

Write a proof of

$$\left\lceil \sqrt{\lceil X \rceil} \right\rceil = \left\lceil \sqrt{X} \right\rceil$$

### **Question**

How can we GENERALIZE our just proven properties for other functions then *<sup>f</sup>*(*x*) = <sup>√</sup> *x* ?

For which functions *f* = *f*(*x*) (class of which functions?) the following holds

$$\lfloor f(\lfloor x \rfloor) \rfloor = \lfloor f(x) \rfloor$$

and

$$\lceil f(\lceil x \rceil) \rceil = \lceil f(x) \rceil$$

## Generalization

Here is a proper generalization of the **Fact 4**

### **Fact 5**

Let *f* : *R* <sup>0</sup> −→ *R* where *R* <sup>0</sup> ⊆ *R* is the domain of f **IF** f = f(x) is continuous, monotonically increasing on its domain R' , and additionally has the following property **P**

**P** if 
$$f(x) \in Z$$
 then  $x \in Z$ 

**THEN** for all *x* ∈ *R* 0 for which the property **P** holds we have that

$$\lfloor f(\lfloor x \rfloor) \rfloor = \lfloor f(x) \rfloor$$

and

$$\lceil f(\lceil x \rceil) \rceil = \lceil f(x) \rceil$$

![](_page_34_Picture_9.jpeg)

#### Fact 5 Proof

#### **Proof**

We want to show that under assumption that f is continuous, monotonic, increasing on its domain R' the property

$$\lceil f(\lceil x \rceil) \rceil = \lceil f(x) \rceil$$

holds for all *x* ∈ *R* 0 for which the property **P** holds

Case 1 take 
$$x = [x]$$

We get

$$\lceil f(x) \rceil = \lceil f(\lceil x \rceil) \rceil$$

is trivial as in this case we have that *x* ∈ *Z*

## Fact 5 Proof

**Case 2** take *x* , d*x*e

By definition *x* < d*x*e and function f is monotonically increasing so we have

$$f(x) < f(\lceil x \rceil)$$

By the fact that d e is non- decreasing , i.e.

If 
$$x < y$$
 then  $\lceil x \rceil \le \lceil y \rceil$ 

we get

$$\lceil f(x) \rceil \leq \lceil f(\lceil x \rceil) \rceil$$

Now we show that < is impossible Hence we will have =

![](_page_36_Picture_9.jpeg)

### Fact 5 Proof

Assume

$$\lceil f(x) \rceil < \lceil f(\lceil x \rceil) \rceil$$

Since f is continuous, then there is y , such that

$$f(y) = \lceil f(x) \rceil$$

and

$$(\star) \qquad x \leq y < \lceil x \rceil$$

But *f*(*y*) = d*f*(*x*)e, i.e. *f*(*y*) ∈ *Z* hence by property **P** we get

$$(\star\star)$$
  $y\in Z$ 

**Observe** that (?) and (??) are **contradictory** as there is no *y* ∈ *Z* between x and d*x*e and this **ends the proof**

![](_page_37_Picture_10.jpeg)

## Exercises

### **Exercise 1**

**Prove** the first part of the **Fact 5**, i.e.

$$\left\lfloor \sqrt{\lfloor f(x) \rfloor} \right\rfloor = \left\lfloor \sqrt{f(x)} \right\rfloor$$

### **Exercise 2**

**Prove** that for any *x* ∈ *R*, *n*,*m* ∈ *Z*

1. 
$$\left\lfloor \frac{x+m}{n} \right\rfloor = \left\lfloor \frac{\lfloor x \rfloor + m}{n} \right\rfloor$$

and

$$2. \quad \left\lceil \frac{x+m}{n} \right\rceil = \left\lceil \frac{\lceil x \rceil + m}{n} \right\rceil$$

#### Exercise 2 Solution

Let's prove

1. 
$$\left\lfloor \frac{x+m}{n} \right\rfloor = \left\lfloor \frac{\lfloor x \rfloor + m}{n} \right\rfloor$$

Proof for d e is carried similarly and is left as an exercise Take a function

$$f(x) = \frac{x+m}{n}$$

for *n*,*m* ∈ *Z*, *x* ∈ *R*

**Observe** that

$$f(x) = \frac{x+m}{n} = \frac{x}{n} + \frac{m}{n}$$

is a line *f*(*x*) = *ax* +*b* and hence is continuous, monotonically increasing

![](_page_39_Picture_9.jpeg)

### Exercise 2 Solution

We have to check now if the property **P**

**P** if 
$$f(x) \in Z$$
 then  $x \in Z$ 

holds for it, i.e. to check if all assumptions of the **Fact 5** are fulfilled

Then by the **Fact 5** we will get that

$$\lfloor f(\lfloor x \rfloor) \rfloor = \lfloor f(x) \rfloor$$

i.e.

$$\left\lfloor \frac{\lfloor x \rfloor + m}{n} \right\rfloor = \left\lfloor \frac{x + m}{n} \right\rfloor$$

#### Exercise 2 Solution

**Poof** that the property **P** holds for

$$f(x) = \frac{x+m}{n}$$

Assume *f*(*x*) ∈ *Z*, i.e. there is *k* ∈ *Z* such that

$$\frac{x+m}{n}=k$$

It means that

$$x + m = nk$$

and

$$x = nk - m \in Z$$
 as  $n, k, m \in Z$ 

### Intervals

### **Standard Notation** and definition of a Closed Interval

$$[\alpha, \beta] = \{x \in R : \alpha \le x \le \beta\}$$

### **Book Notation**

$$[\alpha \dots \beta] = \{ x \in R : \quad \alpha \le x \le \beta \}$$

We use book notation, because [*P*(*x*)] denotes in the book the characteristic function of P(x)

![](_page_43_Picture_6.jpeg)

### Intervals

### **Closed Interval**

$$[\alpha, \beta] = \{x \in R : \alpha \le x \le \beta\} = [\alpha \dots \beta]$$

## **Open Interval**

$$(\alpha, \beta) = \{x \in R : \alpha < x < \beta\} = (\alpha \dots \beta)$$

#### **Half Open Interval**

$$[\alpha, \beta) = \{x \in R : \alpha \le x < \beta\} = [\alpha \dots \beta)$$

#### **Half Open Interval**

$$(\alpha, \beta] = \{x \in R : \alpha < x \le \beta\} = (\alpha \dots \beta]$$

![](_page_44_Picture_9.jpeg)

### **Problem**

How many integers are there in the intervals?

In other words, for

$$A = \{ x \in Z : \alpha \le x \le \beta \}$$

$$A = \{ x \in Z : \alpha < x \le \beta \}$$

$$\mathsf{A} = \{ \mathsf{x} \in \mathsf{Z} : \alpha \leq \mathsf{x} < \beta \}$$

$$A = \{ x \in Z : \alpha < x < \beta \}$$

We want to find | *A* |

## **Solution**

We bring our de, bc properties **13. - 16.**

**13.** 
$$x < n$$
 if and only if  $\lfloor x \rfloor < n$ 

**14.** 
$$n < x$$
 if and only if  $n < \lceil x \rceil$ 

**15.** 
$$x \le n$$
 if and only if  $\lceil x \rceil \le n$ 

**16.** 
$$n \le x$$
 if and only if  $n \le \lfloor x \rfloor$ 

and we get for α,β ∈ *R* and *n* ∈ *Z*

$$\alpha \le n < \beta$$
 if and only if  $\lceil \alpha \rceil \le n < \lceil \beta \rceil$ 

$$\alpha < n \le \beta$$
 if and only if  $\lfloor \alpha \rfloor \le n < \lfloor \beta \rfloor$ 

![](_page_46_Picture_10.jpeg)

### **Solution**

```
[α...β) contains exactly dβe − dαe integers
   (α...β] contains exactly bβc − bαc integers
  [α...β] contains exactly bβc − dαe+1 integers
We must assume α , β to evaluate
  (α...β) contains exactly dβe − bαc −1 integers
We
because (α...α) = ∅ and can't contain -1 integers
```

| INTERVAL | Number of INTEGERS | RESTRICTIONS |
|----------|--------------------|--------------|
| [αβ]     | bβc-dαe+1          | ≤<br>α<br>β  |
| [αβ)     | dβe-dαe            | ≤<br>α<br>β  |
| (αβ]     | bβc-bαc            | ≤<br>α<br>β  |
| (αβ)     | dβe-bαc −1         | <<br>α<br>β  |

### Casino Problem

## Casino Problem

### **Casino Problem**

There is a roulette wheel with 1,000 slots numbered 1 ... 1,000

**IF** the number n that comes up on a spin is divisible by √3 *n*c what we write as

$$\lfloor \sqrt[3]{n} \rfloor \mid n$$

**THEN** n is the **winner**

### Reminder

We **define divisibility** | in a standard way: *k* | *n* if and only if there exists *m* ∈ *Z* such that *n* = *km*

![](_page_50_Picture_8.jpeg)

### Average Winnings

In the game Casino pays \$5 if you are the **winner**; but the **loser** has to pay \$1

**Can we expect to make money if we play this game?**

Let's compute average winnings, i.e. the amount we win (or lose) per play

### **Denote**

W - number of **winners**

L - number of **losers** and L = 1000 - W

**Strong Rule**: each number comes once during 1000 plays

![](_page_51_Picture_8.jpeg)

### Casino Winnings

Under the **Strong Rule** we win 5W and lose L dollars and the average winnings in 1000 plays is

$$\frac{5W - L}{1000} = \frac{5W - (1000 - W)}{1000} = \frac{6W - 1000}{1000}$$

We have **advantage** if

6*W* > 1000

i.e. when

*W* > 167

### Casino Winnings

### **Answer**

IF there is 167 or more winners and we play under the

**Strong Rule**: each number comes once during 1000 plays

THEN we have the **advantage**, otherwise **Casino wins**

### Number of Winners

### **Problem**

How to **count** the number of winners among 1 to 1000

### **Method**

Use summation

$$W = \sum_{n=1}^{1000} [n \text{ is a winner }]$$

#### Casino Problem

#### Reminder of Casino Problem

There is a roulette wheel with 1,000 slots numbered  $1 \dots 1,000$ 

**IF** the number n that comes up on a spin is divisible by  $\lfloor \sqrt[3]{n} \rfloor$ , i.e.  $\sqrt[3]{n} \rfloor \mid n$ 

THEN n is the winner

The summations becomes

$$W = \sum_{n=1}^{1000} [n \text{ is a winner}] = \sum_{n=1}^{1000} [\lfloor \sqrt[3]{n} \rfloor \mid n]$$

where we **define divisibility** | in a standard way  $k \mid n$  if and only if there exists  $m \in \mathbb{Z}$  such that n = km

![](_page_55_Picture_8.jpeg)

## Book Solution

Here are 7 steps of our BOOK solution

**1** W = 
$$\sum_{n=1}^{1000} [n \text{ is a winner}] = \sum_{n=1}^{1000} [\lfloor \sqrt[3]{n} \rfloor \mid n]$$

2 W = 
$$\sum_{k,n}^{n=1} [k = \lfloor \sqrt[3]{n} \rfloor] [k|n] [1 \le n \le 1000]$$

3 
$$W = \sum_{k,n,m} \left[ k^3 \le n < (k+1)^3 \right] [n = km] [1 \le n \le 1000]$$

4 W = 1 + 
$$\sum_{k,m} \left[ k^3 \le km < (k+1)^3 \right] [1 \le k < 10]$$

5 W = 1 + 
$$\sum_{k,m} \left[ m \in \left[ k^2 \dots \frac{(k+1)^3}{k} \right) \right] [1 \le k < 10]$$

6 W = 1 + 
$$\sum_{1 \le k < 10} \left( \lceil k^2 + 3k + 3 + \frac{1}{k} \rceil - \lceil k^2 \rceil \right)$$

7 W = 1 + 
$$\sum_{1 \le k < 10} (3k+4) = 1 + \frac{7+31}{2}9 = 172$$

![](_page_56_Picture_9.jpeg)

### Class Problem

Here are the BOOK comments

- 1. This derivation merits careful study
- 2. The only "difficult" maneuver is the decision between lines **3** and **4** to treat n =1000 as a special case
- 3. The inequality *k* <sup>3</sup> ≤ *n* < (*k* +1) <sup>3</sup> does not combine easily with 1 ≤ *n* ≤ 1000 when k=10

#### Book Solution Comments

### **Class Problem**

Write down explanation of **each step** with **detailed** justifications (Facts, definitions) why they are correct

By doing so fill all gaps in the **proof** that

$$W = \sum_{n=1}^{1000} \left[ \left\lfloor \sqrt[3]{n} \right\rfloor \mid n \right] = 172$$

This problem can also appear on your tests

Here are **questions** to answer about the steps in the BOOK solution

**1** W = 
$$\sum_{n=1}^{1000} [n \text{ is a winner }] = \sum_{n=1}^{1000} [\lfloor \sqrt[3]{n} \rfloor \mid n]$$

Q1 Explain why 
$$[n \text{ is a winner }] = [\lfloor \sqrt[3]{n} \rfloor \mid n]$$

**2** W = 
$$\sum_{k,n} [k = \lfloor \sqrt[3]{n} \rfloor] [k|n] [1 \le n \le 1000]$$

Q2 Explain why and how we have changed a sum ∑ 1000 *n*=1 into a sum ∑*k*,*<sup>n</sup>* and

$$\sum_{n=1}^{1000} \left[ \lfloor \sqrt[3]{n} \rfloor \mid n \right] = \sum_{k,n} \left[ k = \lfloor \sqrt[3]{n} \rfloor \right] \left[ k \mid n \right] \left[ 1 \le n \le 1000 \right]$$

![](_page_59_Picture_7.jpeg)

3 
$$W = \sum_{k,n,m} \left[ k^3 \le n < (k+1)^3 \right] [n = km] [1 \le n \le 1000]$$

Q3 Explain why

$$\left[k = \lfloor \sqrt[3]{n} \rfloor\right] \left[k|n\right] = \left[k^3 \le n < (k+1)^3\right] \left[n = km\right]$$

Explain why and how we have changed sum ∑*k*,*<sup>n</sup>* into a sum ∑*k*,*n*,*<sup>m</sup>*

**4** W = 1 + 
$$\sum_{k,m} \left[ k^3 \le km < (k+1)^3 \right] [1 \le k < 10]$$

Q4 There are three sub- questions; the last one is one of the book questions

1. Explain why

$$\begin{bmatrix} k^3 \le n < (k+1)^3 \end{bmatrix} [n = km] [1 \le n \le 1000] =$$

$$\begin{bmatrix} k^3 \le km < (k+1)^3 \end{bmatrix} [1 \le k < 10]$$

- 2. Explain why and how we have changed sum ∑*k*,*n*,*<sup>m</sup>* into
- a sum ∑*k*,*<sup>m</sup>*
- 3. Explain HOW and why we have got 1+ ∑*k*,*<sup>m</sup>*

5 W = 1 + 
$$\sum_{k,m} \left[ m \in \left[ k^2 \dots \frac{(k+1)^3}{k} \right) \right] [1 \le k < 10]$$

## Q5 Explain transition

$$\left[k^3 \leq km < (k+1)^3\right] = \left[m \in \left[k^2 \dots \frac{(k+1)^3}{k}\right)\right]$$

6 W = 1 + 
$$\sum_{1 \le k < 10} \left( \lceil k^2 + 3k + 3 + \frac{1}{k} \rceil - \lceil k^2 \rceil \right)$$

Q6 Explain (prove) why

$$\sum_{k,m} \left[ m \in \left[ k^2 \dots \frac{(k+1)^3}{k} \right) \right] \left[ 1 \le k < 10 \right] =$$

$$\sum_{1 \le k < 10} \left( \left\lceil k^2 + 3k + 3 + \frac{1}{k} \right\rceil - \left\lceil k^2 \right\rceil \right)$$

Observe that h *m* ∈ h *k* 2 ... (*k*+1) *k* i is a characteristic function and d*k* <sup>2</sup> +3*k* +3+ *k* e − d*k* 2 e is an integer

7 W = 1 + 
$$\sum_{1 \le k < 10} (3k+4) = 1 + \frac{7+31}{2}9 = 172$$

Q7 Explain (prove) why

$$\left(\lceil k^2 + 3k + 3 + \frac{1}{k} \rceil - \lceil k^2 \rceil\right) = (3k + 4)$$

Before we giving answers to Q1 - Q7 we need to review some of the SUMS material