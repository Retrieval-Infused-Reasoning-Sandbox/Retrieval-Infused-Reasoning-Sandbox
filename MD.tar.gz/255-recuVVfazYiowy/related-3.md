# The weight enumerator polynomials of the lifted codes of the projective Solomon-Stiffler codes

Minjia Shi, Shitao Li, Tor Helleseth\*

#### Abstract

Determining the weight distribution of a code is an old and fundamental topic in coding theory that has been thoroughly studied. In 1977, Helleseth, Kløve, and Mykkeltveit presented a weight enumerator polynomial of the lifted code over  $\mathbb{F}_{q^{\ell}}$  of a q-ary linear code with significant combinatorial properties, which can determine the support weight distribution of this linear code. The Solomon-Stiffler codes are a family of famous Griesmer codes, which were proposed by Solomon and Stiffler in 1965. In this paper, we determine the weight enumerator polynomials of the lifted codes of the projective Solomon-Stiffler codes using some combinatorial properties of subspaces. As a result, we determine the support weight distributions of the projective Solomon-Stiffler codes. In particular, we determine the weight hierarchies of the projective Solomon-Stiffler codes.

**Keywords:** Solomon-Stiffler code, Griesmer code, weight enumerator polynomial, support weight, r-th generalized Hamming weight

Mathematics Subject Classification 94B05 15B05 12E10

#### 1 Introduction

Let  $\mathbb{F}_q$  denote the finite field with q elements, where q is a prime power. For any  $\mathbf{x} \in \mathbb{F}_q^N$ , the Hamming weight of  $\mathbf{x}$  is the number of nonzero components of  $\mathbf{x}$ . An [N, K, D] linear code C over  $\mathbb{F}_q$  is a K-dimensional subspace of  $\mathbb{F}_q^N$ , where D is the minimum nonzero Hamming weight of C. Let  $A_i$  denote the number of codewords with Hamming weight i in C, where  $0 \le i \le N$ . The sequence  $(A_0, A_1, \ldots, A_N)$  is called the weight distribution of C, and  $\sum_{i=0}^N A_i z^i$  is called the weight enumerator polynomial of C. It is well-known that the weight enumerator polynomials contain important information that allows the computation of the error probability for some algorithms [19]. In the past 70 years, one problem of considerable interest has been to find the weight enumerator polynomials of a family of linear codes with good parameters. For example, MDS codes [22] and some cyclic

<sup>\*</sup>Minjia Shi and Shitao Li are with the School of Mathematical Sciences, Anhui University, Hefei, China (email: smjwcl.good@163.com, lishitao0216@163.com). Tor Helleseth is with the Department of Informatics, University of Bergen, Bergen, Norway (email: tor.helleseth@uib.no).

codes [24]. In general, it is very hard to determine the weight enumerator polynomials of an infinite family of optimal linear codes and the reader is referred to [15, 25].

Let C be an [N, K] linear code over  $\mathbb{F}_q$ . For any subcode D of C, the *support weight* of D is defined by

$$\chi(D) := \#\{i \mid \text{there is } (c_1, c_2, \dots, c_N) \in D \text{ such that } c_i \neq 0\}.$$

If D has dimension 1, then  $\chi(D)$  is exactly the Hamming weight of any nonzero codeword of D. For  $1 \leq r \leq K$  and  $0 \leq i \leq N$ , let  $A_i^{(r)}$  denote the number of r-dimensional subcodes of C with support weight i. The sequence  $(A_0^{(r)}, A_1^{(r)}, \ldots, A_N^{(r)})$  is called the r-th support weight distribution of C. The r-th minimum support weight of C is defined by

$$d_r(C) := \min\{\chi(D) \mid D \text{ is an } [N, r] \text{ subcode of } C\} = \min\{i \mid A_i^{(r)} \neq 0\}.$$

In fact, the concept of support weight distribution can be traced back to the 1970s, which was originally proposed by Helleseth, Kløve, and Mykkeltveit [13,20]. The support weight distribution has application in describing the security of information data when a code is used in the wire-tap channel of type II [28]. Besides, it is also used to determine the separation property and the trellis complexity of linear codes [5, 18].

In 1991, Wei [28] studied the r-th minimum support weight and called it the r-th generalized Hamming weight. Additionally, Wei also mentioned the notation of the weight hierarchy, i.e., the set of integers  $\{d_r(C) \mid 1 \leq i \leq K\}$ , and showed that the weight hierarchy of C determined the performance of C on wire-tap channel of Type II. Subsequently, a series of excellent conclusions on the generalized Hamming weight were provided in [14, 21, 26]. However, it may often be extremely hard to determine the weight hierarchies and usually even harder to determine the support weight distribution. To the best of our knowledge, there are many papers on the generalized Hamming weight, but there are few known results on the support weight distribution.

Let  $C_1$  be an [N, K] linear code over  $\mathbb{F}_q$  with generator matrix G. For  $\ell \geq 1$ , one can consider the lifted code  $C_\ell$  with the same generator matrix G over  $\mathbb{F}_{q^\ell}$ . Helleseth, Kløve, and Mykkeltveit [13] proved an interesting fact that the weight enumerator polynomials of the codes  $C_\ell$  are related in a nice way and can be found by considering the generator matrix G only. They reduced the problem of determining the weight enumerator polynomial of a linear code to the problem of determining the number of certain subspaces, i.e.,

$$A_{\ell}(z) = 1 + \sum_{i=1}^{N} \sum_{j=1}^{K} A_i^{(j)} (q^{\ell} - 1)(q^{\ell} - q) \cdots (q^{\ell} - q^{j-1}) z^i,$$

where  $A_i^{(j)}$  is the number of (K-j)-dimensional subspaces of  $\mathbb{F}_q^K$  which contain exactly N-i of the N columns of G. This result was also discovered independently by Greene [6]. Later, Helleseth, Kløve, and Ytrehus [14] showed that  $A_i^{(j)}$  is the number of j-dimensional subcodes of C with support weight i. Therefore, the determination of the support weight distribution of  $C_1$  is equivalent to the determination of the weight distribution of the lifted code  $C_\ell$  and also to the determination of the number of certain subspaces.

Although the problem of the support weight distribution has been transformed into a pure mathematical problem, it is still quite difficult and challenging. The support weight distributions of some irreducible cyclic codes were obtained in [13]. In [12], Helleseth considered the support weight distributions of two classes of codes. One is related to Simplex codes and the other is related to MDS codes. The main motivation is that these codes have remarkable combinatorial properties. Later, Helleseth [11] proved a similar result for the weight distribution of the coset leaders. Recently, Luo and Liu [17] determined the support weight distributions for several classes of optimal linear codes which were constructed by using the down-sets.

The Solomon-Stiffler codes are a family of famous Griesmer codes by puncturing certain coordinates of the Simplex codes, which were proposed by Solomon and Stiffler [27]. They also presented encoding and decoding procedures for the Solomon-Stiffler codes. Subsequently, a series of work related to the Solomon-Stiffler codes were presented [1,8–10]. The reason why the Solomon-Stiffler codes have been widely concerned is not only their optimality, but also their geometric applications (see [3,4]). In this paper, we describe the definition of the Solomon-Stiffler codes in the language of subspaces. We determine the weight enumerator polynomials of the lifted codes of the projective Solomon-Stiffler codes. As a result, we determine the support weight distributions of the projective Solomon-Stiffler codes. In particular, we determine the weight hierarchies of the projective Solomon-Stiffler codes. Many non-trivial examples are presented to verify the correctness of our results and have been carefully verified by MAGMA [2].

The paper is organized as follows. In Section 2, we give some notation and definitions. In Sections 3 and 4, we determine the weight enumerator polynomials of the lifted codes of two families of the Solomon-Stiffler codes using some combinatorial properties of subspaces. In Section 5, we conclude the paper.

#### 2 Preliminaries

#### 2.1 Linear codes

Let C be an [N, K, D] linear code over  $\mathbb{F}_q$ . The code C is projective if the minimum nonzero weight of its dual code is at least three. Two codes C and D are equivalent if there is a monomial matrix M such that MC = D. The dual code  $C^{\perp}$  of C is defined by

$$C^{\perp} = \{ \mathbf{y} \in \mathbb{F}_q^N \mid \langle \mathbf{x}, \mathbf{y} \rangle = 0, \text{for all } \mathbf{x} \in C \},$$

where  $\langle \mathbf{x}, \mathbf{y} \rangle = \sum_{i=1}^{N} x_i y_i$  for  $\mathbf{x} = (x_1, x_2, \dots, x_N)$  and  $\mathbf{y} = (y_1, y_2, \dots, y_N) \in \mathbb{F}_q^N$ . The Singleton bound [22, Chapter 11, Section 1] for C is defined as  $D \leq N - K + 1$ . The code C is called a maximum distance separable (MDS) code if D = N - K + 1. The Griesmer bound (see [7] or [22, Chapter 17, Section 5]) for C is given by

$$N \ge \sum_{i=0}^{K-1} \left\lceil \frac{D}{q^i} \right\rceil,$$

where  $\lceil a \rceil$  is the least integer greater than or equal to a. The code C is called a *Griesmer code* if its parameters achieve the Griesmer bound with equality.

#### 2.2 The projective Solomon-Stiffler codes

Let  $S_{q,u,k}$  denote a u-dimensional subspace of  $\mathbb{F}_q^k$ , so  $S_{q,k,k} = \mathbb{F}_q^k$ . Let  $S_{q,u,k}^1$  be a set whose elements are made up of precisely one nonzero vector from each vector subspace of dimension 1 of  $S_{q,u,k}$ . Without loss of generality, suppose that  $S_{q,u,k}^1 \subseteq S_{q,k,k}^1$ . Let  $\left[S_{q,u,k}^1\right]$  be a matrix whose columns are elements of  $S_{q,u,k}^1$ . Then the code with the generator matrix  $\left[S_{q,k,k}^1\right]$  is called a  $Simplex\ code$  over  $\mathbb{F}_q$  with parameters  $\left[\frac{q^k-1}{q-1},k,q^{k-1}\right]$  and weight enumerator  $1+(q^k-1)z^{q^{k-1}}$ . The dual code of a Simplex code is called a  $Hamming\ code$ , which has parameters  $\left[\frac{q^k-1}{q-1},\frac{q^k-1}{q-1}-k,3\right]$ . Up to monomial equivalence, Simplex codes and Hamming codes are unique, and are denoted by  $S_{q,k}$  and  $\mathcal{H}_{q,k}$ , respectively.

For  $1 \le i \le p$ , let  $u_i$  be a positive integer. If

$$\sum_{i=1}^{p} u_i \le k, \ 1 \le u_i \le k-1, \ u_i \ne u_j, \ S_{q,u_i,k} \cap S_{q,u_j,k} = \{0\} \ (i \ne j),$$

then the linear code  $SS_1$  with the following generator matrix

$$SS_{q,k} = \left[ S_{q,k,k}^1 \setminus \bigcup_{i=1}^p S_{q,u_i,k}^1 \right]$$

is called the *projective Solomon-Stiffler code* [27]. According to [27, Theorem 2'], the projective Solomon-Stiffler code is a Griesmer code with parameters

$$\left[\frac{q^k-1}{q-1} - \sum_{i=1}^p \frac{q^{u_i}-1}{q-1}, k, q^{k-1} - \sum_{i=1}^p q^{u_i-1}\right].$$

For convenience, consider the code  $SS_2$  with the following generator matrix

$$[SS_{q,k}, \alpha SS_{q,k}, \dots, \alpha^{q-2}SS_{q,k}],$$

where  $\alpha$  is a primitive element of  $\mathbb{F}_q$ . We call  $SS_1$  a projective code of  $SS_2$ . Let  $W_i(z)$  denote the weight enumerator polynomial of  $SS_i$  (i = 1, 2). Then  $W_2(z) = W_1(z^{q-1})$ .

#### 2.3 Some known results

For a number q with  $q \neq 1$ , the Gaussian or q-binomial coefficient  $\begin{bmatrix} n \\ k \end{bmatrix}$  is defined to be

$$\begin{bmatrix} n \\ 0 \end{bmatrix} = 1 \text{ and } \begin{bmatrix} n \\ k \end{bmatrix} = \frac{(q^n - 1)(q^n - q) \cdots (q^n - q^{k-1})}{(q^k - 1)(q^k - q) \cdots (q^k - q^{k-1})}.$$

The Gaussian coefficients have the same symmetry as that of binomial coefficients, *i.e.*,  $\begin{bmatrix} n \\ k \end{bmatrix} = \begin{bmatrix} n \\ n-k \end{bmatrix}$ . The number of k-dimensional subspaces of  $\mathbb{F}_q^n$  is just  $\begin{bmatrix} n \\ k \end{bmatrix}$ .

The following theorem which connects the enumerator polynomial  $A_{\ell}(z)$  of the various  $V_{\ell}$  was proved by Helleseth, Kløve, and Mykkeltveit in 1977 [13].

<span id="page-4-0"></span>Theorem 2.1. [\[13\]](#page-19-5) Let C<sup>1</sup> be an [n, k] linear code over Fq. Then the lifted code C<sup>ℓ</sup> over Fq <sup>ℓ</sup> of C<sup>1</sup> has the following weight enumerator polynomial

$$A_{\ell}(z) = 1 + \sum_{i=1}^{n} \sum_{j=1}^{k} A_i^{(j)} (q^{\ell} - 1)(q^{\ell} - q) \cdots (q^{\ell} - q^{j-1}) z^i,$$

where A (j) i is the number of (k − j)-dimensional subspaces of F k <sup>q</sup> which contain exactly n − i of the n columns of G.

Although Helleseth et al. [\[14\]](#page-19-9) mentioned in the end that the q-ary case is similar to the binary case, it is not redundant to reprove it again. For the completeness of the results, we provide the following proof. For any x ∈ F k q , the multiplicity µG(x) of x in G is defined as the number of occurrences of x as a column vector in G.

<span id="page-4-1"></span>Theorem 2.2. [\[14\]](#page-19-9) Let C be an [n, k] linear code over F<sup>q</sup> with generator matrix G. Then the number of j-dimensional subcodes of C with support weight i is A (j) i , i.e., the number of (k − j)-dimensional subspaces of F k <sup>q</sup> which contain exactly n − i of the n columns of G.

Proof. If A is a j × k matrix of rank j, then the matrix AG generates an [n, j] subcode D of C, and it is obvious that any [n, j] subcode of C is obtained by this way. It follows that

$$\chi(D) = n - \sum_{A\mathbf{x} = \mathbf{0}} \mu_G(\mathbf{x}).$$

Let U be the space orthogonal to the column space of A. Then

$$\sum_{A\mathbf{x}=\mathbf{0}} \mu_G(\mathbf{x}) = \sum_{\mathbf{x}\in U} \mu_G(\mathbf{x}).$$

Since the arbitrariness of A, U can traverse all (k − j)-dimensional subspaces of F k q . If D has the support weight χ(D) = i, i.e., P <sup>x</sup>∈<sup>U</sup> µG(x) = n−i. This implies that the number of j-dimensional subcodes of C with support weight i is the number of (k−j)-dimensional subspaces of F k <sup>q</sup> which contain exactly n − i of the n columns of G.

A simple application is to consider the case of Simplex codes, also shown in [\[13\]](#page-19-5).

Theorem 2.3. Let Sq,k be the [n = q <sup>k</sup>−1 q−1 , k, q<sup>k</sup>−<sup>1</sup> ] simplex code over Fq. Then the lifted code over F<sup>q</sup> <sup>ℓ</sup> of Sq,k has the following weight enumerator polynomial

$$A_{\ell}(z) = 1 + \sum_{j=1}^{k} {k \brack j} (q^{\ell} - 1)(q^{\ell} - q) \cdots (q^{\ell} - q^{j-1}) z^{\frac{q^{k} - q^{k-j}}{q-1}}.$$

In particular, Sq,k has the j-th support weight distribution as follows.

| Support weight | Frequency |
|----------------|-----------|
| k−q            |           |
| k−j            |           |
| q              | k         |
| q−1            | j         |

Moreover,  $S_{q,k}$  has the weight hierarchy  $\{d_1(S_{q,k}), d_2(S_{q,k}), \dots, d_k(S_{q,k})\}$ , where  $d_j(S_{q,k}) = \frac{q^k - q^{k-j}}{q-1}$  for  $1 \leq j \leq k$ .

*Proof.* Let  $\mathcal{G}$  be a set whose elements are the columns of a generator matrix  $[S_{q,k,k}^1]$  of  $\mathcal{S}_{q,k}$ . Assume that V is a (k-j)-dimensional subspace of  $\mathbb{F}_q^k$ . Then

$$|V \cap \mathcal{G}| = |V \setminus \{\mathbf{0}\}| = \frac{q^{k-j}-1}{q-1}.$$

By Theorem 2.1,  $A_i^{(j)}$  is the number of (k-j)-dimensional subspaces of  $\mathbb{F}_q^k$  and contain exactly n-i of the n columns of  $[S_{q,k,k}^1]$ . So  $A_i^{(j)}=0$  for  $n-i\neq\frac{q^{k-j}-1}{q-1}$ . When  $n-i=\frac{q^{k-j}-1}{q-1}$ , i.e.,  $i=\frac{q^k-q^{k-j}}{q-1}$ ,  $A_i^{(j)}$  is the number of (k-j)-dimensional subspaces of  $\mathbb{F}_q^k$ . So

$$A_i^{(j)} = \begin{bmatrix} k \\ k - j \end{bmatrix} = \begin{bmatrix} k \\ j \end{bmatrix},$$

where  $i = \frac{q^k - q^{k-j}}{q-1}$ . Hence

$$A_{\ell}(z) = 1 + \sum_{i=1}^{n} \sum_{j=1}^{k} A_{i}^{(j)} (q^{\ell} - 1) (q^{\ell} - q) \cdots (q^{\ell} - q^{j-1}) z^{i}$$

$$= 1 + \sum_{j=1}^{k} \begin{bmatrix} k \\ j \end{bmatrix} (q^{\ell} - 1) (q^{\ell} - q) \cdots (q^{\ell} - q^{j-1}) z^{\frac{q^{k} - q^{k-j}}{q-1}}.$$

In particular, the j-th support weight distribution of C is obtained by Theorem 2.2. It is well-known that the j-th generalized Hamming weight of a code is defined as the minimum support weight of its j-dimensional subcodes. This completes the proof.

## 3 The weight enumerator polynomials of the lifted codes of the Solomon-Stiffler codes (p=1)

In this section, we use  $S_u$  to denote a *u*-dimensional subspace of  $\mathbb{F}_q^k$ . We study the weight enumerator polynomials of the lifted codes of a family of Solomon-Stiffler codes.

<span id="page-5-0"></span>**Lemma 3.1.** Let  $0 \le t \le u \le k-1$  and N(k, u, j, t) denote the number of j-dimensional subspaces V of  $\mathbb{F}_q^k$  such that  $\dim(V \cap S_u) = t$ . Then

$$N(k, u, j, t) = q^{(u-t)(j-t)} \begin{bmatrix} k - u \\ j - t \end{bmatrix} \begin{bmatrix} u \\ t \end{bmatrix},$$

*Proof.* Let V be a j-dimensional subspace of  $S_k = \mathbb{F}_q^k$ . Assume that  $V \cap S_u = V_2$  is a t-dimensional subspace. Then there is a (j-t)-dimensional subspace  $V_1 \subset S_k \setminus S_u$  such that

$$V = V_1 \oplus V_2$$
.

Let  $\{v_1, v_2, \ldots, v_{j-t}\}$  denote a basis of  $V_1$ . For  $v_1$ , there are  $q^k - q^u$  choices. For  $v_2$ , there are  $q^k - q^{u+1}$  choices. For  $v_i$ , there are  $q^k - q^{u+i-1}$  choices. Hence, there are  $(q^k - q^u)(q^k - q^{u+1}) \cdots (q^k - q^{u+j-t-1})$  distinct ordered choices for  $(v_1, v_2, \ldots, v_{j-t})$ . For any (j-t)-dimensional subspace  $V_1$ , there are  $(q^{j-t}-1)(q^{j-t}-q)\cdots (q^{j-t}-q^{j-t-1})$  choices for  $(v_1, v_2, \ldots, v_{j-t})$  such that  $\{v_1, v_2, \ldots, v_{j-t}\}$  is a basis of  $V_1$ . Therefore, the number of (j-t)-dimensional subspaces  $V_1$  such that  $V_1 \subset S_k \setminus S_u$  is

$$\frac{(q^k - q^u)(q^k - q^{u+1})\cdots(q^k - q^{u+j-t-1})}{(q^{j-t} - 1)(q^{j-t} - q)\cdots(q^{j-t} - q^{j-t-1})} = q^{u(j-t)} \begin{bmatrix} k - u \\ j - t \end{bmatrix}.$$

The number of t-dimensional subspaces  $V_2$  of  $\mathbb{F}_q^k$  such that  $V_2 \subset S_u$  is  $\begin{bmatrix} u \\ t \end{bmatrix}$ . Similarly, for any V and  $V_2$ , the number of (j-t)-dimensional subspaces  $V_1$  such that  $V=V_1 \oplus V_2$  is

$$\frac{(q^j - q^t)(q^j - q^{t+1})\cdots(q^j - q^{j-1})}{(q^{j-t} - 1)(q^{j-t} - q)\cdots(q^{j-t} - q^{j-t-1})} = q^{t(j-t)}.$$

Hence,

$$\begin{split} N(k,u,j,t) &= |\{V \subseteq \mathbb{F}_q^k \mid \dim(V) = j, \ \dim(V \cap S_u) = t\}| \\ &= \frac{|\{V = V_1 \oplus V_2 \mid \dim(V_1) = j - t, \ \dim(V_2) = t, \ V_1 \subset S_k \backslash S_u, \ V_2 \subset S_u\}|}{q^{t(j-t)}} \\ &= \frac{|\{V_1 \mid \dim(V_1) = j - t, \ V_1 \subset S_k \backslash S_u\}| \cdot |\{V_2 \mid \dim(V_2) = t, \ V_2 \subset S_u\}|}{q^{t(j-t)}} \\ &= q^{(u-t)(j-t)} \begin{bmatrix} k - u \\ j - t \end{bmatrix} \begin{bmatrix} u \\ t \end{bmatrix}. \end{split}$$

<span id="page-6-0"></span>This completes the proof.

Corollary 3.2. Let  $t \leq u \leq k-1$  and N(k, u, j, t) denote the number of j-dimensional subspaces V of  $\mathbb{F}_q^k$  such that  $\dim(V \cap S_u) = t$ . Then

$$\sum_{t=0}^{u} N(k, u, j, t) = \sum_{t=0}^{u} q^{(u-t)(j-t)} \begin{bmatrix} k-u \\ j-t \end{bmatrix} \begin{bmatrix} u \\ t \end{bmatrix} = \begin{bmatrix} k \\ j \end{bmatrix}.$$

In particular, when u = 1, we have

$$q^{j} \begin{bmatrix} k-1 \\ j \end{bmatrix} + \begin{bmatrix} k-1 \\ j-1 \end{bmatrix} = \begin{bmatrix} k \\ j \end{bmatrix}.$$

*Proof.* Let  $\mathfrak{F}_{k,u,j,t}$  denote a set consisting of j-dimensional subspaces V of  $\mathbb{F}_q^k$  satisfying  $\dim(V \cap S_u) = t$ . Then

$$|\mathfrak{F}_{k,u,j,t}| = N(k,u,j,t) = q^{(u-t)(j-t)} \begin{bmatrix} k-u \\ j-t \end{bmatrix} \begin{bmatrix} u \\ t \end{bmatrix}$$

and  $\mathfrak{F}_{k,u,j,0},\mathfrak{F}_{k,u,j,1},\ldots,\mathfrak{F}_{k,u,j,u}$  form a partition of all j-dimensional subspaces of  $\mathbb{F}_q^k$ . Hence

$$\sum_{t=0}^{u} N(k, u, j, t) = \sum_{t=0}^{u} q^{(u-t)(j-t)} \begin{bmatrix} k-u \\ j-t \end{bmatrix} \begin{bmatrix} u \\ t \end{bmatrix} = \begin{bmatrix} k \\ j \end{bmatrix}.$$

Substitute u=1 into the above formula, we can obtain the desired result.

In the following, let  $[U \setminus V]$  denote a matrix whose columns consist of the elements of U which do not contain the elements of V, where U and V are two sets whose elements are vectors of length k.

<span id="page-7-0"></span>**Theorem 3.3.** Suppose that  $u \leq k-1$ . Let C be the q-ary linear code with the generator matrix  $[S_k \setminus S_u]$ . Then the lifted code over  $\mathbb{F}_q^{\ell}$  of C is a linear code of length  $n = q^k - q^u$  with the following weight enumerator polynomial

$$A_{\ell}(z) = 1 + \sum_{i=1}^{n} \sum_{j=1}^{k} A_{i}^{(j)} (q^{\ell} - 1)(q^{\ell} - q) \cdots (q^{\ell} - q^{j-1}) z^{i},$$

where

$$A_i^{(j)} = \begin{cases} q^{(u-t)(k-j-t)} \begin{bmatrix} k-u \\ k-j-t \end{bmatrix} \begin{bmatrix} u \\ t \end{bmatrix}, & \text{if } n-i = q^{k-j}-q^t, \ \max\{0, u-j\} \leq t \leq u, \\ 0, & \text{otherwise.} \end{cases}$$

*Proof.* Let  $\mathcal{G}$  be a set whose elements are the columns of G. Assume that V is a (k-j)-dimensional subspace of  $\mathbb{F}_q^k$ . If  $\dim(V \cap S_u) = t$ , then

$$|V \cap \mathcal{G}| = |V \setminus (V \cap S_u)| = q^{k-j} - q^t$$
, where  $0 \le t \le u$ .

By Theorem 2.1,  $A_i^{(j)}$  is the number of (k-j)-dimensional subspaces of  $\mathbb{F}_q^k$  which contain exactly n-i of the n columns of G. So  $A_i^{(j)}=0$  for  $n-i\neq q^{k-j}-q^t$ . When  $n-i=q^{k-j}-q^t$ ,  $A_i^{(j)}$  is the number of (k-j)-dimensional subspaces V of  $\mathbb{F}_q^k$  such that  $\dim(V\cap S_u)=t$ . By Lemma 3.1,

$$A_i^{(j)} = N(k, u, k - j, t) = q^{(u-t)(k-j-t)} \begin{bmatrix} k - u \\ k - j - t \end{bmatrix} \begin{bmatrix} u \\ t \end{bmatrix}.$$

Note that  $\dim(V \cap S_u) \leq \dim(S_u) \leq u$  and

$$\dim(V \cap S_u) = \dim(V) + \dim(S_u) - \dim(V \oplus S_u) \ge \max\{0, u - j\}.$$

This completes the proof.

Remark 3.4. When  $\ell=1$ , the Solomon-Stiffler codes in Theorem 3.3 are a family of two-weight codes, which is also obtained in [15, Proposition 1]. When  $\ell=1$  and u=1, the projective codes of the Solomon-Stiffler codes in Theorem 3.3 are a family of two-weight codes, which is also obtained in [16, Theorem 18].

Corollary 3.5. Let C be the linear code in Theorem 3.3. Then C has the j-th support weight distribution  $(A_0^{(j)}, A_1^{(j)}, \ldots, A_N^{(j)})$ , where

$$A_i^{(j)} = \begin{cases} q^{(u-t)(k-j-t)} \begin{bmatrix} k-u \\ k-j-t \end{bmatrix} \begin{bmatrix} u \\ t \end{bmatrix}, & \text{if } n-i = q^{k-j}-q^t, \ \max\{0,u-j\} \leq t \leq u, \\ 0, & \text{otherwise.} \end{cases}$$

In particular, C has the weight hierarchy  $\{d_1(C), d_2(C), \dots, d_k(C)\}$ , where

$$d_j(C) = \begin{cases} q^k - q^u - q^{k-j} + q^{u-j}, & \text{if } 1 \le j < u, \\ q^k - q^u - q^{k-j} + 1, & \text{if } u \le j \le k. \end{cases}$$

*Proof.* The j-th support weight distribution of C is obtained by Theorem 2.2 and Theorem 3.3. It is well-known that the j-th generalized Hamming weight of a code is defined as the minimum support weight of its j-dimensional subcodes. Hence when  $1 \le j \le u$ , we have  $\max\{0, u - j\} = u - j$ . It follows that

$$d_j(C) = \min_{u-j \le t \le u} \{ q^k - q^u - q^{k-j} + q^t \} = q^k - q^u - q^{k-j} + q^{u-j}.$$

When j > u, we have  $\max\{0, u - j\} = 0$ . It follows that

$$d_j(C) = \min_{0 \le t \le u} \{ q^k - q^u - q^{k-j} + q^t \} = q^k - q^u - q^{k-j} + 1.$$

This completes the proof.

**Example 3.6.** We consider the linear code C over  $\mathbb{F}_3$  with the generator matrix  $G = [S_3 \backslash S_2]$ , where  $S_2 = \langle 110, 011 \rangle$  is a 2-dimensional subspace of  $S_3 = \mathbb{F}_3^3$ . Then C is an [18, 3, 12] linear code with the following generator matrix

$$\left[ \begin{array}{c|c|c} 100120121 & 200210212 \\ 010212021 & 020121012 \\ 001201111 & 002102222 \end{array} \right].$$

By Theorem 3.3,

$$A_{12}^{(1)}=12,\,A_{18}^{(1)}=1,\,A_{16}^{(2)}=9,\,A_{18}^{(2)}=4,\,A_{18}^{(3)}=1,\,A_{i}^{(j)}=0$$
 otherwise.

Note that  $(3^{\ell}-1)(3^{\ell}-3)\cdots(3^{\ell}-3^{j-1})=0$  when  $j\geq 3$ . Hence the lifted code of C over  $\mathbb{F}_{3^2}$  has the weight enumerator polynomial

$$A_2(z) = 1 + 96z^{12} + 432z^{16} + 200z^{18}.$$

Moreover, C has the j-th support weight distribution as follows.

| Case 1: j      | i = 1     | Case 2: $j = 2$ |           | Case 3: $j = 3$ |           |
|----------------|-----------|-----------------|-----------|-----------------|-----------|
| Support weight | Frequency | Support weight  | Frequency | Support weight  | Frequency |
| 12             | 12        | 16              | 9         | 18              | 1         |
| 18             | 1         | 18              | 4         |                 |           |

In particular, C has the weight hierarchy {12, 16, 18}. Consider the projective code C ′ of C with the following generator matrix

$$\begin{bmatrix} 100120121 \\ 010212021 \\ 001201111 \end{bmatrix}.$$

This is a projective [9, 3, 6] linear code, whose the lifted code over F<sup>3</sup> <sup>2</sup> has the weight enumerator polynomial

$$A_2'(z) = 1 + 96z^6 + 432z^8 + 200z^9.$$

Moreover, C ′ has the j-th support weight distribution as follows.

| Case 1:<br>j             | = 1 | Case 2:<br>j<br>= 2      |   | Case 3:<br>j<br>= 3      |   |
|--------------------------|-----|--------------------------|---|--------------------------|---|
| Support weight Frequency |     | Support weight Frequency |   | Support weight Frequency |   |
| 6                        | 12  | 8                        | 9 | 9                        | 1 |
| 9                        | 1   | 9                        | 4 |                          |   |

In particular, C ′ has the weight hierarchy {6, 8, 9}. This is also confirmed by MAGMA [\[2\]](#page-18-9).

## 4 The weight enumerator polynomials of the lifted codes of the Solomon-Stiffler codes (p = 2)

We will consider the case of p = 2. The result shows that the weight enumerator polynomials of the Solomon-Stiffler codes (p ≥ 3) will be too complicated and therefore less interesting.

<span id="page-9-0"></span>Lemma 4.1. Let S<sup>u</sup><sup>1</sup> be a u1-dimensional subspace of F k q and S<sup>u</sup><sup>2</sup> be a u2-dimensional subspace of F k q such that dim(S<sup>u</sup><sup>1</sup> ∩ S<sup>u</sup><sup>2</sup> ) = 0. Let Nt(k, u1, u2, t1, t2) denote the number of (t + t<sup>1</sup> + t2)-dimensional subspaces V of S<sup>u</sup><sup>1</sup> ⊕ S<sup>u</sup><sup>2</sup> such that dim(V ∩ S<sup>u</sup><sup>1</sup> ) = t<sup>1</sup> and dim(V ∩ S<sup>u</sup><sup>2</sup> ) = t2. Then

$$N_{t}(k, u_{1}, u_{2}, t_{1}, t_{2}) = \begin{cases} (q^{t} - 1) \cdots (q^{t} - q^{t-1}) \begin{bmatrix} u_{1} - t_{1} \\ t \end{bmatrix} \begin{bmatrix} u_{2} - t_{2} \\ t \end{bmatrix} \begin{bmatrix} u_{1} \\ t_{1} \end{bmatrix} \begin{bmatrix} u_{2} \\ t_{2} \end{bmatrix}, & t \neq 0, \\ \begin{bmatrix} u_{1} \\ t_{1} \end{bmatrix} \begin{bmatrix} u_{2} \\ t_{2} \end{bmatrix}, & t = 0. \end{cases}$$

Proof. Assume that V is a (t + t<sup>1</sup> + t2)-dimensional subspace of S<sup>u</sup><sup>1</sup> ⊕ S<sup>u</sup><sup>2</sup> such that dim(V ∩ S<sup>u</sup><sup>1</sup> ) = t<sup>1</sup> and dim(V ∩ S<sup>u</sup><sup>2</sup> ) = t2. Then it is easy to check that V can be written in the following form

$$V = S_{t_1} \oplus S_{t_2} \oplus V_t,$$

where S<sup>t</sup><sup>r</sup> is tr-dimensional subspace of S<sup>u</sup><sup>r</sup> for 1 ≤ r ≤ 2, V<sup>t</sup> is a t-dimensional subspace of S<sup>u</sup><sup>1</sup> ⊕ S<sup>u</sup><sup>2</sup> such that Vt\{0} ⊂ (S<sup>u</sup><sup>1</sup> \S<sup>t</sup><sup>1</sup> ) ⊕ (S<sup>u</sup><sup>2</sup> \S<sup>t</sup><sup>2</sup> ). For 1 ≤ r ≤ 2, the number of trdimensional subspaces S<sup>t</sup><sup>r</sup> of S<sup>u</sup><sup>r</sup> is ur tr . If t = 0, then the number of (t1+t2)-dimensional subspaces V of  $S_{u_1} \oplus S_{u_2}$  such that  $\dim(V \cap S_{u_1}) = t_1$  and  $\dim(V \cap S_{u_2}) = t_2$  is

$$N_0(k, u_1, u_2, t_1, t_2) = \begin{bmatrix} u_1 \\ t_1 \end{bmatrix} \begin{bmatrix} u_2 \\ t_2 \end{bmatrix}.$$

Assume that  $t \neq 0$ . For any  $v_1 + v_2$ ,  $v_1' + v_2' \in (S_{u_1} \setminus S_{t_1}) \oplus (S_{u_2} \setminus S_{t_2})$ , it is not difficult to check that

$$S_{t_1} \oplus S_{t_2} \oplus \langle v_1 + v_2 \rangle = S_{t_1} \oplus S_{t_2} \oplus \langle v_1' + v_2' \rangle$$

if and only if  $v_r$  and  $v_r'$  are in the same coset of  $S_{u_r}$  in  $S_{t_r}$  for  $1 \le r \le 2$ . Therefore, for the elements in the same coset, we only need to consider one representative element.

Let  $\{v_1, v_2, \ldots, v_t\}$  denote a basis of  $V_t$ . For  $v_1$ , there are  $(q^{u_1-t_1}-1)(q^{u_2-t_2}-1)$  choices. For  $v_2$ , there are  $(q^{u_1-t_1}-q)(q^{u_2-t_2}-q)$  choices. For  $v_i$ , there are  $(q^{u_1-t_1}-q^{i-1})(q^{u_2-t_2}-q^{i-1})$  choices. Hence, there are  $(q^{u_1-t_1}-1)(q^{u_2-t_2}-1)\cdots(q^{u_1-t_1}-q^{t-1})(q^{u_2-t_2}-q^{t-1})$  distinct ordered choices for  $(v_1, v_2, \ldots, v_t)$ . For any t-dimensional subspace  $V_t$ , there are  $(q^t-1)(q^t-q)\cdots(q^t-q^{t-1})$  choices for  $(v_1, v_2, \ldots, v_t)$  such that  $\{v_1, v_2, \ldots, v_t\}$  is a basis of  $V_t$ . Therefore, the number of t-dimensional subspaces  $V_t$  of  $S_{u_1} \oplus S_{u_2}$  such that  $V_t \setminus \{0\} \subset (S_{u_1} \setminus S_{t_1}) \oplus (S_{u_2} \setminus S_{t_2})$  is

$$\frac{(q^{u_1-t_1}-1)(q^{u_2-t_2}-1)\cdots(q^{u_1-t_1}-q^{t-1})(q^{u_2-t_2}-q^{t-1})}{(q^t-1)(q^t-q)\cdots(q^t-q^{t-1})}$$

$$=(q^t-1)(q^t-q)\cdots(q^t-q^{t-1})\begin{bmatrix} u_1-t_1\\t\end{bmatrix}\begin{bmatrix} u_2-t_2\\t\end{bmatrix}.$$

According to the above statement, the number of  $(t + t_1 + t_2)$ -dimensional subspaces V of  $S_{u_1} \oplus S_{u_2}$  such that  $\dim(V \cap S_{u_1}) = t_1$  and  $\dim(V \cap S_{u_2}) = t_2$  is

$$N_t(k, u_1, u_2, t_1, t_2) = (q^t - 1) \cdots (q^t - q^{t-1}) \begin{bmatrix} u_1 - t_1 \\ t \end{bmatrix} \begin{bmatrix} u_2 - t_2 \\ t_1 \end{bmatrix} \begin{bmatrix} u_1 \\ t_2 \end{bmatrix}.$$

This completes the proof.

Remark 4.2. When  $t > \min\{u_1 - t_1, u_2 - t_2\}$ ,  $N_t(k, u_1, u_2, t_1, t_2) = 0$ , so we suppose that  $0 \le t \le \min\{u_1 - t_1, u_2 - t_2\}$ .

<span id="page-10-0"></span>**Lemma 4.3.** Let  $S_{u_1}$  be a  $u_1$ -dimensional subspace of  $\mathbb{F}_q^k$  and  $S_{u_2}$  be a  $u_2$ -dimensional subspace of  $\mathbb{F}_q^k$  such that  $\dim(S_{u_1} \cap S_{u_2}) = 0$ . Let  $N(k, j, u_1, u_2, t_1, t_2)$  denote the number of j-dimensional subspaces V of  $\mathbb{F}_q^k$  such that  $\dim(V \cap S_{u_1}) = t_1$  and  $\dim(V \cap S_{u_2}) = t_2$ . Then

$$N(k,j,u_1,u_2,t_1,t_2) = \sum_{t=0}^{t'} q^{(u_1+u_2-t-t_1-t_2)(j-t-t_1-t_2)} N_t(k,u_1,u_2,t_1,t_2) \begin{bmatrix} k-u_1-u_2 \\ j-t-t_1-t_2 \end{bmatrix},$$

where  $t' = \min\{u_1 - t_1, u_2 - t_2\}$  and

$$N_t(k,u_1,u_2,t_1,t_2) = \begin{cases} (q^t-1)\cdots(q^t-q^{t-1})\begin{bmatrix} u_1-t_1\\t \end{bmatrix}\begin{bmatrix} u_2-t_2\\t \end{bmatrix}\begin{bmatrix} u_1\\t_1\end{bmatrix}\begin{bmatrix} u_2\\t_2\end{bmatrix}, & t \neq 0, \\ \begin{bmatrix} u_1\\t_1\end{bmatrix}\begin{bmatrix} u_2\\t_2\end{bmatrix}, & t = 0. \end{cases}$$

Proof. For any j-dimensional subspace V of F k <sup>q</sup> with dim(V ∩S<sup>u</sup><sup>1</sup> ) = t<sup>1</sup> and dim(V ∩S<sup>u</sup><sup>2</sup> ) = t2, it can be written in the following form

$$V=V_1\oplus V_2,$$

where V<sup>1</sup> is a (j−t−t1−t2)-dimensional subspace of F k q such that dim(V1∩(S<sup>u</sup>1⊕S<sup>u</sup><sup>2</sup> )) = 0, and V<sup>2</sup> is a (t + t<sup>1</sup> + t2)-dimensional subspace of S<sup>u</sup><sup>1</sup> ⊕ S<sup>u</sup><sup>2</sup> such that dim(V<sup>2</sup> ∩ S<sup>u</sup><sup>1</sup> ) = t<sup>1</sup> and dim(V<sup>2</sup> ∩ S<sup>u</sup><sup>2</sup> ) = t2.

By Lemma [3.1,](#page-5-0) the number of (j − t − t<sup>1</sup> − t2)-dimensional subspaces V<sup>1</sup> such that dim(V<sup>1</sup> ∩ (S<sup>u</sup><sup>1</sup> ⊕ S<sup>u</sup><sup>2</sup> )) = 0 is

$$\frac{(q^{k} - q^{u_1+u_2})(q^{k} - q^{u_1+u_2+1})\cdots(q^{k} - q^{u_1+u_2+j-t-t_1-t_2-1})}{(q^{j-t-t_1-t_2} - 1)(q^{j-t-t_1-t_2} - q)\cdots(q^{j-t-t_1-t_2} - q^{j-t-t_1-t_2-1})}$$

$$=q^{(u_1+u_2)(j-t-t_1-t_2)} \begin{bmatrix} k-u_1-u_2\\ j-t-t_1-t_2 \end{bmatrix}.$$

By Lemma [4.1,](#page-9-0) the number of (t + t<sup>1</sup> + t2)-dimensional subspaces V<sup>2</sup> of S<sup>u</sup><sup>1</sup> ⊕ S<sup>u</sup><sup>2</sup> such that dim(V<sup>2</sup> ∩ S<sup>u</sup><sup>1</sup> ) = t<sup>1</sup> and dim(V<sup>2</sup> ∩ S<sup>u</sup><sup>2</sup> ) = t<sup>2</sup> is

$$N_t(k,u_1,u_2,t_1,t_2) = \left\{ \begin{array}{l} (q^t-1)\cdots(q^t-q^{t-1})\begin{bmatrix}u_1-t_1\\t\end{bmatrix}\begin{bmatrix}u_2-t_2\\t\end{bmatrix}\begin{bmatrix}u_1\\t_1\end{bmatrix}\begin{bmatrix}u_2\\t_2\end{bmatrix}, \quad t\neq 0, \\ \begin{bmatrix}u_1\\t_1\end{bmatrix}\begin{bmatrix}u_2\\t_2\end{bmatrix}, \quad t=0. \end{array} \right.$$

It is easy to see that Nt(k, u1, u2, t1, t2) = 0 if t > min{u<sup>1</sup> − t1, u<sup>2</sup> − t2}.

By Lemma [3.1,](#page-5-0) for any given V and V2, the number of (j − t − t<sup>1</sup> − t2)-dimensional subspaces V<sup>1</sup> such that V = V<sup>1</sup> ⊕ V<sup>2</sup> is

$$\frac{(q^j - q^{t+t_1+t_2})(q^j - q^{t+t_1+t_2+1})\cdots(q^j - q^{j-1})}{(q^{j-t-t_1-t_2} - 1)(q^{j-t-t_1-t_2} - q)\cdots(q^{j-t-t_1-t_2} - q^{j-t-t_1-t_2-1})} = q^{(t+t_1+t_2)(j-t-t_1-t_2)}.$$

Hence

$$N(k, j, u_1, u_2, t_1, t_2) = |\{V \subseteq \mathbb{F}_q^k \mid \dim(V) = j, \dim(V \cap S_{u_1}) = t_1, \dim(V \cap S_{u_2}) = t_2\}|$$

$$= \sum_{t=0}^{t'} \frac{|\{V_1 \oplus V_2 \mid V_1 \in P_1, V_2 \in P_2\}|}{q^{(t+t_1+t_2)(j-t-t_1-t_2)}}$$

$$= \sum_{t=0}^{t'} \frac{|\{V_1 \mid V_1 \in P_1\}| \cdot |\{V_2 \mid V_2 \in P_2\}|}{q^{(t+t_1+t_2)(j-t-t_1-t_2)}}$$

$$= \sum_{t=0}^{t'} q^{(u_1+u_2-t-t_1-t_2)(j-t-t_1-t_2)} N_t(k, u_1, u_2, t_1, t_2) \begin{bmatrix} k-u_1-u_2 \\ j-t-t_1-t_2 \end{bmatrix},$$

where

$$P_1 = \left\{ V_1 \in \mathbb{F}_q^k \mid \dim(V_1) = j - t - t_1 - t_2, \dim(V_1 \cap (S_{u_1} \oplus S_{u_2})) = 0 \right\},$$

$$P_2 = \left\{ V_2 \in (S_{u_1} \oplus S_{u_2}) \mid \dim(V_2) = t + t_1 + t_2, \dim(V_2 \cap S_{u_1}) = t_1, \dim(V_2 \cap S_{u_2}) = t_2 \right\}.$$

This completes the proof.

<span id="page-12-0"></span>**Theorem 4.4.** Let  $S_{u_1}$  be a  $u_1$ -dimensional subspace of  $\mathbb{F}_q^k$  and  $S_{u_2}$  be a  $u_2$ -dimensional subspace of  $\mathbb{F}_q^k$  such that  $\dim(S_{u_1} \cap S_{u_2}) = 0$ . Let C be the q-ary linear code with the generator matrix  $G = [S_k \setminus (S_{u_1} \cup S_{u_2})]$ . Then the lifted code over  $\mathbb{F}_q^\ell$  of C is a linear code of length  $n = q^k - q^{u_1} - q^{u_2} + 1$  with the following weight enumerator polynomial

$$A_{\ell}(z) = 1 + \sum_{i=1}^{n} \sum_{j=1}^{k} A_i^{(j)} (q^{\ell} - 1)(q^{\ell} - q) \cdots (q^{\ell} - q^{j-1}) z^i,$$

where

$$A_i^{(j)} = \begin{cases} N(k, k-j, u_1, u_2, t_1, t_2) + N(k, k-j, u_1, u_2, t_2, t_1), & \text{if } n-i = q^{k-j} - q^{t_1} - q^{t_2} + 1, \ t_1 \neq t_2, \\ N(k, k-j, u_1, u_2, t_1, t_2), & \text{if } n-i = q^{k-j} - q^{t_1} - q^{t_2} + 1, \ t_1 = t_2, \\ 0, & \text{otherwise.} \end{cases}$$

where  $N(k, j, u_1, u_2, t_1, t_2)$  is explained in Lemma 4.3 and  $\max\{0, u_r - j\} \le t_r \le u_r$  for r = 1, 2.

*Proof.* Let  $\mathcal{G}$  be a set whose elements are the columns of G. Assume that V is a (k-j)-dimensional subspace of  $\mathbb{F}_q^k$ . If  $\dim(V \cap S_{u_1}) = t_1$  and  $\dim(V \cap S_{u_2}) = t_2$ , then

$$V \cap \mathcal{G} = (q^{k-j} - 1) - (q^{t_1} - 1) - (q^{t_2} - 1) = q^{k-j} - q^{t_1} - q^{t_2} + 1$$
, where  $0 \le t_i \le u_i$ .

By Theorem 2.1,  $A_i^{(j)}$  is the number of (k-j)-dimensional subspaces of  $\mathbb{F}_q^k$  which contain exactly n-i of the n columns of G. So  $A_i^{(j)}=0$  for  $n-i\neq q^{k-j}-q^{t_1}-q^{t_2}+1$ . When  $n-i=q^{k-j}-q^{t_1}-q^{t_2}+1$ ,  $A_i^{(j)}$  is the number of (k-j)-dimensional subspaces V of  $\mathbb{F}_q^k$  such that  $\dim(V\cap S_{u_1})=a_1$  and  $\dim(V\cap S_{u_2})=a_2$ , where  $(a_1,a_2)\in\{(t_1,t_2),(t_2,t_1)\}$ . By Lemma 4.3, we have the following.

- When  $t_1 \neq t_2$ ,  $A_i^{(j)} = N(k, k j, u_1, u_2, t_1, t_2) + N(k, k j, u_1, u_2, t_2, t_1)$ ,
- When  $t_1 = t_2$ ,  $A_i^{(j)} = N(k, k j, u_1, u_2, t_1, t_2)$ ,

where  $N(k, j, u_1, u_2, t_1, t_2)$  was defined in Lemma 4.3. Note that for r = 1, 2, we have

$$\dim(V \cap S_{u_r}) \le \dim(S_{u_r}) \le u_r, \text{ and}$$
  
$$\dim(V \cap S_{u_r}) = \dim(V) + \dim(S_{u_r}) - \dim(V \oplus S_{u_r}) \ge \max\{0, u_r - j\}.$$

This completes the proof.

**Corollary 4.5.** Let C be the linear code in Theorem 4.4. Then C has the j-th support weight distribution  $(A_0^{(j)}, A_1^{(j)}, \ldots, A_N^{(j)})$ , where

$$A_i^{(j)} = \begin{cases} N(k, k-j, u_1, u_2, t_1, t_2) + N(k, k-j, u_1, u_2, t_2, t_1), & \text{if } n-i = q^{k-j} - q^{t_1} - (q^{t_2} - 1), \ t_1 \neq t_2, \\ N(k, k-j, u_1, u_2, t_1, t_2), & \text{if } n-i = q^{k-j} - q^{t_1} - (q^{t_2} - 1), \ t_1 = t_2, \\ 0, & \text{otherwise.} \end{cases}$$

where  $N(k, j, u_1, u_2, t_1, t_2)$  is explained in Lemma 4.3. In particular, C has the weight hierarchy  $\{d_1(C), d_2(C), \ldots, d_k(C)\}$ , where

$$\mathbf{d}_{j}(C) = \begin{cases} q^{k} - q^{u_{1}} - q^{u_{2}} - q^{k-j} + q^{u_{1}-j} + q^{u_{2}-j}, & \text{if } 1 \leq j < u_{1} \text{ and } 1 \leq j < u_{2}, \\ q^{k} - q^{u_{1}} - q^{u_{2}} - q^{k-j} + q^{u_{1}-j} + 1, & \text{if } 1 \leq j < u_{1} \text{ and } u_{2} \leq j \leq k, \\ q^{k} - q^{u_{1}} - q^{u_{2}} - q^{k-j} + q^{u_{2}-j} + 1, & \text{if } u_{1} \leq j \leq k \text{ and } 1 \leq j < u_{2}, \\ q^{k} - q^{u_{1}} - q^{u_{2}} - q^{k-j} + 2, & \text{if } u_{1} \leq j \leq k \text{ and } u_{2} \leq j \leq k. \end{cases}$$

*Proof.* The j-th support weight distribution of C is obtained by Theorem 2.2 and Theorem 4.4. The j-th generalized Hamming weight of a code is defined as the minimum support weight of its j-dimensional subcodes. We have the following four cases.

• If  $1 \le j < u_1$  and  $1 \le j < u_2$ , then  $\max\{0, u_r - j\} = u_r - j$  for r = 1 and 2. Hence

$$d_{j}(C) = \min_{\substack{u_{1} - j \leq t_{1} < u_{1} \\ u_{2} - j \leq t_{2} < u_{2}}} \left\{ q^{k} - q^{u_{1}} - q^{u_{2}} - q^{k-j} + q^{t_{1}} + q^{t_{2}} \right\}$$
$$= q^{k} - q^{u_{1}} - q^{u_{2}} - q^{k-j} + q^{u_{1}-j} + q^{u_{2}-j}.$$

• When  $1 \le j < u_1$  and  $u_2 \le j \le k$ , we have  $\max\{0, u_1 - j\} = u_1 - j$  and  $\max\{0, u_2 - j\} = 0$ . It follows that

$$d_j(C) = \min_{\substack{u_1 - j \le t_1 < u_1 \\ 0 \le t_2 < u_2}} \{ q^k - q^{u_1} - q^{u_2} - q^{k-j} + q^{t_1} + q^{t_2} \}$$
$$= q^k - q^{u_1} - q^{u_2} - q^{k-j} + q^{u_1-j} + 1.$$

• When  $u_1 \le j \le k$  and  $1 \le j < u_2$ , we have  $\max\{0, u_1 - j\} = 0$  and  $\max\{0, u_2 - j\} = u_2 - j$ . It follows that

$$d_j(C) = \min_{\substack{0 \le t_1 < u_1 \\ u_2 - j \le t_2 < u_2}} \{ q^k - q^{u_1} - q^{u_2} - q^{k-j} + q^{t_1} + q^{t_2} \}$$
$$= q^k - q^{u_1} - q^{u_2} - q^{k-j} + q^{u_2-j} + 1.$$

• When  $u_1 \leq j \leq k$  and  $u_2 \leq j \leq k$ , we have  $\max\{0, u_1 - j\} = 0$  and  $\max\{0, u_2 - j\} = 0$ . It follows that

$$d_j(C) = \min_{\substack{0 \le t_1 < u_1 \\ 0 \le t_2 < u_2}} \left\{ q^k - q^{u_1} - q^{u_2} - q^{k-j} + q^{t_1} + q^{t_2} \right\}$$
$$= q^k - q^{u_1} - q^{u_2} - q^{k-j} + 2.$$

This completes the proof.

**Example 4.6.** We consider the linear code C over  $\mathbb{F}_2$  with the generator matrix  $G = [S_6 \setminus (S_2 \cup S_3)]$ , where  $S_2 = \langle 100000, 010000 \rangle$  and  $S_3 = \langle 001000, 000100, 000010 \rangle$ . Then C is a [53, 6, 26] linear code. By Theorem 4.9,

$$A_{26}^{(1)} = 42, A_{28}^{(1)} = 14, A_{30}^{(1)} = 6, A_{32}^{(1)} = 1, A_{39}^{(2)} = 168, A_{40}^{(2)} = 252, A_{41}^{(2)} = 84, A_{42}^{(2)} = 133, A_{44}^{(2)} = 7, A_{45}^{(2)} = 4, A_{46}^{(2)} = 3, A_{46}^{(3)} = 336, A_{47}^{(3)} = 714, A_{48}^{(3)} = 231, A_{49}^{(3)} = 85, A_{50}^{(3)} = 28, A_{53}^{(3)} = 1, A_{50}^{(4)} = 378, A_{51}^{(4)} = 244, A_{52}^{(4)} = 21, A_{53}^{(4)} = 8, A_{52}^{(5)} = 53, A_{53}^{(5)} = 10, A_{53}^{(6)} = 1, A_{ij}^{(6)} = 0 \text{ otherwise.}$$

Note that  $(2^{\ell}-1)(2^{\ell}-2)\cdots(2^{\ell}-2^{j-1})=0$  when  $j\geq 4$  and  $\ell=3$ . Hence the lifted code of C over  $\mathbb{F}_{2^3}$  has the weight enumerator polynomial

$$A_3(z) = 1 + 294z^{26} + 98z^{28} + 42z^{30} + 7z^{32} + 7056z^{39} + 10584z^{40} + 3528z^{41} + 5586z^{42} + 294z^{44} + 168z^{45} + 56574z^{46} + 119952z^{47} + 38808z^{48} + 14280z^{49} + 4704z^{50} + 168z^{53}.$$

Moreover, C has the j-th support weight distribution as follows.

| Case 1: j       | $\dot{i} = 1$ | Case 2: $j = 2$ |           | Case 3: $j = 3$ |           |
|-----------------|---------------|-----------------|-----------|-----------------|-----------|
| Support weight  | Frequency     | Support weight  | Frequency | Support weight  | Frequency |
| 26              | 42            | 39              | 168       | 46              | 336       |
| 28              | 14            | 40              | 252       | 47              | 714       |
| 30              | 6             | 41              | 84        | 48              | 231       |
| 32              | 1             | 42              | 133       | 49              | 85        |
|                 |               | 44              | 7         | 50              | 28        |
|                 |               | 45              | 4         | 53              | 1         |
|                 |               | 46              | 3         |                 |           |
| Case 4: $j = 4$ |               | Case 5: $j = 5$ |           | Case 6: $j = 6$ |           |
| Support weight  | Frequency     | Support weight  | Frequency | Support weight  | Frequency |
| 50              | 378           | 52              | 53        | 53              | 1         |
| 51              | 244           | 53              | 10        |                 |           |
| 52              | 21            |                 |           |                 |           |
| 53              | 8             |                 |           |                 |           |

In particular, C has the weight hierarchy  $\{26, 39, 46, 50, 52, 53\}$ . This is also confirmed by MAGMA [2].

When  $\ell = 1$ , the q-ary Solomon-Stiffler codes are four-weight codes.

<span id="page-14-0"></span>**Theorem 4.7.** Let  $S_{u_1}$  be a  $u_1$ -dimensional subspace of  $\mathbb{F}_q^k$  and  $S_{u_2}$  be a  $u_2$ -dimensional subspace of  $\mathbb{F}_q^k$  such that  $\dim(S_{u_1} \cap S_{u_2}) = 0$ . Let C be the q-ary Solomon-Stiffler code with the generator matrix  $G = [S_k \setminus (S_{u_1} \cup S_{u_2})]$ . Then C is an  $[q^k - q^{u_1} - q^{u_2} + 1, k, (q - 1)(q^{k-1} - q^{u_1-1} - q^{u_2-1})]$  linear code with the weight distribution as follows:

| Hamming weight                       | Frequency                             |
|--------------------------------------|---------------------------------------|
| 0                                    | 1                                     |
| $q^k - q^{k-1}$                      | $q^{k-u_1-u_2} - 1$                   |
| $(q-1)(q^{k-1}-q^{u_2-1})$           | $q^{k-u_1} - q^{k-u_1-u_2}$           |
| $(q-1)(q^{k-1}-q^{u_1-1})$           | $q^{k-u_2} - q^{k-u_1-u_2}$           |
| $(q-1)(q^{k-1}-q^{u_1-1}-q^{u_2-1})$ | $q^{k-u_1-u_2}(q^{u_1}-1)(q^{u_2}-1)$ |

Proof. Suppose that  $\ell=1$ , we only consider j=1 since  $(q^{\ell}-1)(q^{\ell}-q)\cdots(q^{\ell}-q^{j-1})=0$  for  $j\geq 2$ . Assume that V is a (k-1)-dimensional subspace of  $\mathbb{F}_q^k$ . Then  $\dim(V\cap S_{u_r})=u_r$  or  $u_r-1$  for r=1,2. When  $t_1=u_1$  and  $t_2=u_2$ , we have  $i=q^k-q^{k-1}$ . By Theorem 4.4,

$$A_i^1 = \begin{bmatrix} k - u_1 - u_2 \\ k - 1 - u_1 - u_2 \end{bmatrix} = \frac{q^{k - u_1 - u_2} - 1}{q - 1}.$$

Therefore, the frequency of  $\omega = q^k - q^{k-1}$  is  $q^{k-u_1-u_2} - 1$ . The rest can also be obtained directly and we omit it.

Remark 4.8. When  $u_1 = u_2$ , the Solomon-Stiffler codes in Theorem 4.7 are a family of three-weight codes, which were also obtained in [15, Proposition 5]. When  $u_1 = u_2 = 1$ , according to Section 2, the projective codes of the Solomon-Stiffler codes in Theorem 4.7 are a family of projective three-weight codes, which were also obtained in [16, Theorem 19].

When  $u_1 = 1$ , we have the following theorem.

<span id="page-15-0"></span>**Theorem 4.9.** Let  $S_1$  be a one-dimensional subspace of  $\mathbb{F}_q^k$  and  $S_u$  be a u-dimensional subspace of  $\mathbb{F}_q^k$  such that  $\dim(S_u \cap S_1) = 0$ . Let C be the q-ary linear code with the generator matrix  $G = [S_k \setminus (S_u \cup S_1)]$ . Then the lifted code over  $\mathbb{F}_q^\ell$  of C is a linear code of length  $n = q^k - q^u - q + 1$  with the weight enumerator polynomial

$$A_{\ell}(z) = 1 + \sum_{i=1}^{n} \sum_{j=1}^{k} A_i^{(j)} (q^{\ell} - 1)(q^{\ell} - q) \cdots (q^{\ell} - q^{j-1}) z^i,$$

where

$$A_{i}^{(j)} = \begin{cases} q^{u(k-j-1)} \left( \begin{bmatrix} u \\ 1 \end{bmatrix} + 1 \right) \begin{bmatrix} k-u-1 \\ k-j-1 \end{bmatrix} + q^{(u-1)(k-j-2)} \frac{(q^{u}-1)(q^{u-1}-1)}{(q-1)} \begin{bmatrix} k-u-1 \\ k-j-2 \end{bmatrix}, & \text{if } n-i = q^{k-j} - q, \\ q^{(u-t)(k-j-t-1)} \begin{bmatrix} u \\ t \end{bmatrix} \left( q^{u-t} \begin{bmatrix} k-u \\ k-j-t \end{bmatrix} - \begin{bmatrix} k-u-1 \\ k-j-t-1 \end{bmatrix} \right), & \text{if } n-i = q^{k-j} - q^t, \ t \neq 1, \\ q^{(u-t)(k-j-t-1)} \begin{bmatrix} k-u-1 \\ k-j-t-1 \end{bmatrix} \begin{bmatrix} u \\ t \end{bmatrix}, & \text{if } n-i = q^{k-j} - q^t - q + 1, \ t \neq 0, \\ 0, & \text{otherwise.} \end{cases}$$

*Proof.* It is easy to check that this is a special case of Theorem 4.4, when  $u_1 = 1$  and  $u_2 = u$ . So  $0 \le t_1 \le 1$  and  $t_2 = t$ . By Theorem 4.4,  $A_i^{(j)} = 0$  if  $n - i \ne q^{k-j} - q^t$  or  $q^{k-j} - q^t - q + 1$ . Hence we have

$$\begin{aligned} &(1) \text{ When } t_1 = 0 \text{ and } t_2 = 1, \text{ or } t_1 = 1 \text{ and } t_2 = 0, \, n-i = q^{k-j} - q, \text{ we have} \\ &A_i^{(j)} = N(k,k-j,1,u,0,1) + N(k,k-j,1,u,1,0) \\ &= q^{u(k-j-1)} \left( \begin{bmatrix} u \\ 1 \end{bmatrix} + 1 \right) \begin{bmatrix} k-u-1 \\ k-j-1 \end{bmatrix} + q^{(u-1)(k-j-2)} \frac{(q^u-1)(q^{u-1}-1)}{(q-1)} \begin{bmatrix} k-u-1 \\ k-j-2 \end{bmatrix}. \end{aligned}$$

(2) When  $t_1 = 0$  and  $t_2 \neq 1$ ,  $n - i = q^{k-j} - q^t$ , we have

$$\begin{split} A_i^{(j)} = & N(k,k-j,1,u,0,t) \\ = & q^{(u-t+1)(k-j-t)} \begin{bmatrix} u \\ t \end{bmatrix} \begin{bmatrix} k-u-1 \\ k-j-t \end{bmatrix} + q^{(u-t)(k-j-t-1)} (q-1) \begin{bmatrix} u-t \\ 1 \end{bmatrix} \begin{bmatrix} u \\ t \end{bmatrix} \begin{bmatrix} k-u-1 \\ k-j-t-1 \end{bmatrix} \\ = & q^{(u-t)(k-j-t-1)} \begin{bmatrix} u \\ t \end{bmatrix} \left( q^{u-t+k-j-t} \begin{bmatrix} k-u-1 \\ k-j-t \end{bmatrix} + q^{u-t} \begin{bmatrix} k-u-1 \\ k-j-t-1 \end{bmatrix} - \begin{bmatrix} k-u-1 \\ k-j-t-1 \end{bmatrix} \right) \\ = & q^{(u-t)(k-j-t-1)} \begin{bmatrix} u \\ t \end{bmatrix} \left( q^{u-t} \begin{bmatrix} k-u \\ k-j-t \end{bmatrix} - \begin{bmatrix} k-u-1 \\ k-j-t-1 \end{bmatrix} \right). \end{split}$$

The last step is based on Corollary 3.2.

(3) When  $t_1 = 1$  and  $t_2 \neq 0$ ,  $n - i = q^{k-j} - q^t - q + 1$ , we have

$$A_i^{(j)} = N(k, k - j, 1, u, 1, t) = q^{(u-t)(k-j-t-1)} \begin{bmatrix} u \\ t \end{bmatrix} \begin{bmatrix} k - u - 1 \\ k - j - t - 1 \end{bmatrix}.$$

This completes the proof.

**Example 4.10.** We consider the linear code C over  $\mathbb{F}_3$  with the generator matrix G = $[S_4 \setminus (S_1 \cup S_2)]$ , where  $S_4 = \mathbb{F}_3^4$ ,  $S_1 = \langle 2100 \rangle$  and  $S_2 = \langle 1100, 1010 \rangle$ . Then C is a four-weight [70, 4, 46] linear code with the following generator matrix

 $10002011212012012012012012012012012012\\ |\ 20001022121021021021021021021021021021\\$  $\begin{array}{c|ccccccccccccccccccccccccccccccccccc$ 

By Theorem 4.9,

$$A_{46}^{(1)} = 24, A_{48}^{(1)} = 12, A_{52}^{(1)} = 3, A_{54}^{(1)} = 1, A_{62}^{(2)} = 72, A_{64}^{(2)} = 53, A_{66}^{(2)} = 4, A_{70}^{(2)} = 1, A_{68}^{(3)} = 35, A_{70}^{(3)} = 5, A_{70}^{(4)} = 1, A_{i}^{(j)} = 0 \text{ otherwise.}$$

Note that  $(3^{\ell}-1)(3^{\ell}-3)\cdots(3^{\ell}-3^{j-1})=0$  when  $j\geq 3$  and  $\ell=2$ . Hence the lifted code of C over  $\mathbb{F}_{3^2}$  has the weight enumerator polynomial

$$A_2(z) = 192z^{46} + 96z^{48} + 24z^{52} + 8z^{54} + 3456z^{62} + 2544z^{64} + 192z^{66} + 48z^{70}.$$

Moreover, C has the j-th support weight distribution as follows.

| Case 1: $j = 1$ |           | Case 2: $j = 2$ |           |  |
|-----------------|-----------|-----------------|-----------|--|
| Support weight  | Frequency | Support weight  | Frequency |  |
| 46              | 24        | 62              | 72        |  |
| 48              | 12        | 64              | 53        |  |
| 52              | 3         | 66              | 4         |  |
| 54              | 1         | 70              | 1         |  |
| Case 3: j       | j=3       | Case 4: $j = 4$ |           |  |
| Support weight  | Frequency | Support weight  | Frequency |  |
| 68              | 35        | 70              | 1         |  |
| 70              | 5         |                 |           |  |

In particular, C has the weight hierarchy  $\{46, 62, 68, 70\}$ . Consider the projective code C' of C with the following generator matrix

$$\begin{bmatrix} 10002011212012012012012012012012012\\ 01000112200111222000111222\\ 001011111000000001111111111$$

This is a projective [35, 4, 23] linear code, whose the lifted code over  $\mathbb{F}_{3^2}$  has the weight enumerator polynomial

$$A_2'(z) = 192z^{23} + 96z^{24} + 24z^{26} + 8z^{27} + 3456z^{31} + 2544z^{32} + 192z^{33} + 48z^{35}.$$

Moreover, C' has the j-th support weight distribution as follows.

| Case 1: j      | i = 1     | Case 2: $j = 2$ |           |  |
|----------------|-----------|-----------------|-----------|--|
| Support weight | Frequency | Support weight  | Frequency |  |
| 23             | 24        | 31              | 72        |  |
| 24             | 12        | 32              | 53        |  |
| 26             | 3         | 33              | 4         |  |
| 27             | 1         | 35              | 1         |  |
| Case 3: j      | i = 3     | Case 4: $j$     | =4        |  |
| Support weight | Frequency | Support weight  | Frequency |  |
| 34             | 35        | 35              | 1         |  |
| 35             | 5         |                 |           |  |

In particular, C' has the weight hierarchy  $\{23, 31, 34, 35\}$ . This is also confirmed by MAGMA [2].

Remark 4.11. For the cases of  $p \geq 3$ , a similar method can be used to determine  $A_i^{(j)}$ , but it is technically more complicated.

By MacWilliams theorem [22, Chapter 5] or [21], we can determine the weight enumerator polynomials of lifted codes for the dual codes of two classes of the q-ary Solomon-Stiffler codes, as well as their support weight distributions and weight hierarchies.

#### 5 Conclusion

In this paper, we have determined the weight enumerator polynomials of the lifted codes of the Solomon-Stiffler codes using some combinatorial properties of subspaces. As a result, we have determined the support weight distributions of the Solomon-Stiffler codes. In particular, we have determined the weight hierarchies of the Solomon-Stiffler codes. Some nontrivial examples are also given. Under certain conditions, we have obtained some three or four weight codes. The results have been carefully verified by MAGMA [2]

Conflict of Interest: The authors have no conflicts of interest to declare that are relevant to the content of this article.

Data Deposition Information: Our data can be obtained from the authors upon reasonable request.

Acknowledgement: The research of Minjia Shi and Shitao Li was supported by Natural Science Foundation of China (12071001). The research of Tor Helleseth was supported by the Research Council of Norway under grant number 247742/O70.

### <span id="page-18-4"></span>References

- [1] B. I. Belov, A conjecture on the Griesmer bound, in Optimization Methods and Their Applications, (Russian), Sibirsk. Energet. Inst. Sibirsk. Otdel. Akad. Nauk SSSR, Irkutsk, 1974, 182: 100-106.
- <span id="page-18-9"></span><span id="page-18-7"></span>[2] W. Bosma, J. Cannon, C. Playoust, The Magma algebra system I: The user language, J. Symbolic Comput., 1997, 24: 235-265.
- <span id="page-18-8"></span>[3] C. Ding, Codes from Difference Sets, World Scientific, Singapore, 2015.
- <span id="page-18-0"></span>[4] C. Ding, Designs from Linear Codes, World Scientific, Singapore, 2018.
- [5] G. D. Forney Jr., Dimension/length profiles and trellis complexity of linear block codes, IEEE Trans. Inf. Theory, 1994, 40(6): 1741-1752.
- <span id="page-18-1"></span>[6] C. Greene, Weight enumeration and the geometry of linear codes, Studies in Applied., Math., 1976, 55: 119-128.
- <span id="page-18-10"></span><span id="page-18-5"></span>[7] J. H. Griesmer, A bound for error-correcting codes, IBM J. Res. Dev., 1960, 4(5): 532-542.
- [8] N. Hamada, T. Helleseth, Ø. Ytrehus, A new class of nonbinary codes meeting the Griesmer bound, Discrete Appl. Math., 1993, 47(3): 219-226.
- [9] T. Helleseth, A characterization of codes meeting the Griesmer bound, Inform. Control, 1981, 50: 128-159.
- <span id="page-18-6"></span>[10] T. Helleseth, New constructions of codes meeting the Griesmer bound, IEEE Trans. Inf. Theory, 1983, 29(3): 434-439.
- <span id="page-18-3"></span>[11] T. Helleseth, The weight distribution of the coset leaders for some classes of codes with related parity-check matrices, Discrete Math., 1979, 28(2): 161-171.
- <span id="page-18-2"></span>[12] T. Helleseth, The weight enumerator polynomials of some classes of codes with composite parity-check polynomials, Discrete Math., 1977, 20(1): 21-31.

- <span id="page-19-5"></span>[13] T. Helleseth, T. Kløve, J. Mykkeltveit, The weight distribution of irreducible cyclic codes with block lengths n1((q <sup>l</sup> − 1)/N), Discrete Math., 1977, 18(2): 179-211.
- <span id="page-19-9"></span><span id="page-19-3"></span>[14] T. Helleseth, T. Kløve, O. Ytrehus, Generalized Hamming weights of linear codes, IEEE Trans. Inf. Theory, 1992, 38(3): 1133-1140.
- <span id="page-19-14"></span>[15] Z. Hu, N. Li, X. Zeng, L. Wang, X. Tang, A subfield-based construction of optimal linear codes over finite fields, IEEE Trans. Inf. Theory, 2022, 68(7): 4408-4421.
- <span id="page-19-12"></span>[16] Y. Liu, C. Ding, C. Tang, Shortened linear codes over finite fields, IEEE Trans. Inf. Theory, 2021, 67(8): 5119-5132.
- <span id="page-19-8"></span>[17] Y. Luo, Z, Liu, On the subcode-support-weight distributions of some classes of optimal codes, IEEE Trans. Inf. Theory, 2023, 69(3): 1531-1543.
- [18] T. Kasami, T. Tanaka, T. Fujiwara, S. Lin, On complexity of trellis structure of linear block codes, IEEE Trans. Inf. Theory, 1993, 39(3): 1057-1064.
- <span id="page-19-6"></span><span id="page-19-0"></span>[19] T. Kløve, Codes for Detection, Kluwer, Singapore, 2007.
- [20] T. Kløve, The weight distribution of linear codes over GF(q ℓ ) having generator matrix over GF(q), Discrete Math., 1978, 23(2): 159-168.
- <span id="page-19-10"></span><span id="page-19-1"></span>[21] T. Kløve, Support weight distribution of linear codes, Discrete Math., 1992, 106-107: 311-316.
- [22] F. J. MacWilliams, N. J. A. Sloane, The theory of Error Correcting Codes, Amsterdam. The Netherlands: North-Holland, 1977.
- <span id="page-19-2"></span>[23] W. C. Huffman, V. Pless, Fundamentals of Error-Correcting Codes, Cambridge University Press, 2003.
- [24] C. Li, N. Li, T. Helleseth, C. Ding, The weight distributions of several classes of cyclic codes from APN monomials, IEEE Trans. Inf. Theory, 2014, 60(8): 4710-4721.
- <span id="page-19-4"></span>[25] M. Shi, F. Ozbudak, P. Sol´e, Geometric approach to ¨ b-symbol Hamming weights of cyclic codes. IEEE Trans. Inf. Theory, 2021, 67(6): 3735-3751.
- <span id="page-19-11"></span>[26] M. Shi, H, Zhu, T. Helleseth, The connections among Hamming metric, b-symbol metric, and r-th generalized Hamming metric, IEEE Trans. Inf. Theory, 2023, 69(4): 2485-2493.
- <span id="page-19-13"></span>[27] G. Solomon, J. J. Stiffler, Algebraically punctured cyclic codes, Inform. Control, 1965, 8(2): 170-179.
- <span id="page-19-7"></span>[28] V. K. Wei, Generalized Hamming weights for linear codes, IEEE Trans. Inf. Theory, 1991, 37(5): 1412-1418.