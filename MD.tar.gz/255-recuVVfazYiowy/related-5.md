![](_page_0_Picture_0.jpeg)

# **Sigma notation**

mc-TY-sigma-2009-1

Sigma notation is a method used to write out a long sum in a concise way. In this unit we look at ways of using sigma notation, and establish some useful rules.

In order to master the techniques explained here it is vital that you undertake plenty of practice exercises so that they become second nature.

After reading this text, and/or viewing the video tutorial on this topic, you should be able to:

- expand a sum given in sigma notation into an explicit sum;
- write an explicit sum in sigma notation where there is an obvious pattern to the individual terms;
- use rules to manipulate sums expressed in sigma notation.

## Contents

| 1. | Introduction                         | 2 |
|----|--------------------------------------|---|
| 2. | Some examples                        | 3 |
| 3. | Writing a long sum in sigma notation | 5 |
| 4. | Rules for use with sigma notation    | 6 |

# **1. Introduction**

Sigma notation is a concise and convenient way to represent long sums. For example, we often wish to sum a number of terms such as

$$1+2+3+4+5$$

or

$$1 + 4 + 9 + 16 + 25 + 36$$

where there is an obvious pattern to the numbers involved. The first of these is the sum of the first five whole numbers, and the second is the sum of the first six square numbers. More generally, if we take a sequence of numbers u1, u2, u3, . . . , u<sup>n</sup> then we can write the sum of these numbers as

$$u_1+u_2+u_3+\ldots+u_n.$$

A shorter way of writing this is to let u<sup>r</sup> represent the general term of the sequence and put

$$\sum_{r=1}^{n} u_r .$$

Here, the symbol Σ is the Greek capital letter Sigma corresponding to our letter 'S', and refers to the initial letter of the word 'Sum'. So this expression means the sum of all the terms u<sup>r</sup> where r takes the values from 1 to n. We can also write

$$\sum_{r=a}^{b} u_r$$

to mean the sum of all the terms u<sup>r</sup> where r takes the values from a to b. In such a sum, a is called the lower limit and b the upper limit.

![](_page_1_Picture_12.jpeg)

## **Key Point**

The sum u<sup>1</sup> + u<sup>2</sup> + u<sup>3</sup> + . . . + u<sup>n</sup> is written in sigma notation as

$$\sum_{r=1}^{n} u_r .$$

#### **Exercises**

1. Write out what is meant by

(a) 
$$\sum_{n=1}^{5} n^3$$
 (b)  $\sum_{n=1}^{5} 3^n$  (c)  $\sum_{r=1}^{4} (-1)^r r^2$  (d)  $\sum_{k=1}^{4} \frac{(-1)^{k+1}}{2k+1}$  (e)  $\sum_{i=1}^{N} x_i^2$  (f)  $\sum_{i=1}^{N} f_i x_i$ 

2. Evaluate 
$$\sum_{k=1}^{4} k^2$$
.

# 2. Some examples

#### **Example**

Evaluate 
$$\sum_{r=1}^{4} r^3$$
.

#### Solution

This is the sum of all the  $r^3$  terms from r=1 to r=4. So we take each value of r, work out  $r^3$  in each case, and add the results. Therefore

$$\sum_{r=1}^{4} r^3 = 1^3 + 2^3 + 3^3 + 4^3$$
$$= 1 + 8 + 27 + 64$$
$$= 100.$$

#### **Example**

Evaluate 
$$\sum_{n=2}^{5} n^2$$
.

#### **Solution**

In this example we have used the letter n to represent the variable in the sum, rather than r. Any letter can be used, and we find the answer in the same way as before:

$$\sum_{n=2}^{5} n^2 = 2^2 + 3^2 + 4^2 + 5^2$$
$$= 4 + 9 + 16 + 25$$
$$= 54.$$

#### **Example**

Evaluate 
$$\sum_{k=0}^{5} 2^k$$
.

#### Solution

Notice that, in this example, there are 6 terms in the sum, because we have k = 0 for the first term:

$$\sum_{k=0}^{5} 2^{k} = 2^{0} + 2^{1} + 2^{2} + 2^{3} + 2^{4} + 2^{5}$$

$$= 1 + 2 + 4 + 8 + 16 + 32$$

$$= 63.$$

#### Example

Evaluate 
$$\sum_{r=1}^{6} \frac{1}{2} r(r+1)$$
.

#### Solution

You might recognise that each number <sup>1</sup> 2 r(r + 1) is a triangular number, and so this example asks for the sum of the first six triangular numbers. We get

$$\sum_{r=1}^{6} \frac{1}{2} r(r+1) = \left(\frac{1}{2} \times 1 \times 2\right) + \left(\frac{1}{2} \times 2 \times 3\right) + \left(\frac{1}{2} \times 3 \times 4\right) + \left(\frac{1}{2} \times 4 \times 5\right) + \left(\frac{1}{2} \times 5 \times 6\right) + \left(\frac{1}{2} \times 6 \times 7\right)$$

$$= 1 + 3 + 6 + 10 + 15 + 21$$

$$= 56.$$

What would we do if we were asked to evaluate

$$\sum_{k=1}^{n} 2^k ?$$

Now we know what this expression means, because it is the sum of all the terms 2 <sup>k</sup> where k takes the values from 1 to n, and so it is

$$\sum_{k=1}^{n} 2^{k} = 2^{1} + 2^{2} + 2^{3} + 2^{4} + \ldots + 2^{n}.$$

But we cannot give a numerical answer, as we do not know the value of the upper limit n.

#### Example

Evaluate 
$$\sum_{r=1}^{4} (-1)^r$$
.

#### Solution

Here, we need to remember that (−1)<sup>2</sup> = +1, (−1)<sup>3</sup> = −1, and so on. So

$$\sum_{r=1}^{4} (-1)^r = (-1)^1 + (-1)^2 + (-1)^3 + (-1)^4$$
$$= (-1) + 1 + (-1) + 1$$
$$= 0.$$

#### Example

Evaluate 
$$\sum_{k=1}^{3} \left(-\frac{1}{k}\right)^2$$
.

#### Solution

Once again, we must remember how to deal with powers of -1:

$$\sum_{k=1}^{3} \left( -\frac{1}{k} \right)^{2} = \left( -\frac{1}{1} \right)^{2} + \left( -\frac{1}{2} \right)^{2} + \left( -\frac{1}{3} \right)^{2}$$

$$= 1 + \frac{1}{4} + \frac{1}{9}$$

$$= 1 \frac{13}{36}.$$

## 3. Writing a long sum in sigma notation

Suppose that we are given a long sum and we want to express it in sigma notation. How should we do this?

Let us take the two sums we started with. If we want to write the sum

$$1+2+3+4+5$$

in sigma notation, we notice that the general term is just k and that there are 5 terms, so we would write

$$1+2+3+4+5=\sum_{k=1}^{5} k$$
.

To write the second sum

$$1+4+9+16+25+36$$

in sigma notation, we notice that the general term is  $k^2$  and that there are 6 terms, so we would write

$$1+4+9+16+25+36 = \sum_{k=1}^{6} k^2$$
.

#### Example

Write the sum

$$-1 + \frac{1}{2} - \frac{1}{3} + \frac{1}{4} - \ldots + \frac{1}{100}$$

in sigma notation.

#### Solution

In this example, the first term -1 can also be written as a fraction  $-\frac{1}{1}$ . We also notice that the signs of the terms alternate, with a minus sign for the odd-numbered terms and a plus sign for the even-numbered terms. So we can take care of the sign by using  $(-1)^k$ , which is -1 when k is odd, and +1 when k is even. We can therefore write the sum as

$$(-1)^{1}\frac{1}{1} + (-1)^{2}\frac{1}{2} + (-1)^{3}\frac{1}{3} + (-1)^{4}\frac{1}{4} + \ldots + (-1)^{100}\frac{1}{100}$$

We can now see that k-th term is (−1)<sup>k</sup> 1/k, and that there are 100 terms, so we would write the sum in sigma notation as

$$\sum_{k=1}^{100} (-1)^k \frac{1}{k} \, .$$

![](_page_5_Picture_2.jpeg)

### **Key Point**

To write a sum in sigma notation, try to find a formula involving a variable k where the first term can be obtained by setting k = 1, the second term by k = 2, and so on.

#### Exercises

- 3. Express each of the following in sigma notation:
- (a) <sup>1</sup> <sup>1</sup> + 1 <sup>2</sup> + 1 <sup>3</sup> + 1 <sup>4</sup> + 1 5
- (b) −1 + 2 − 3 + 4 − 5 + 6 − . . . + 20
- (c) (x<sup>1</sup> − µ) <sup>2</sup> + (x<sup>2</sup> − µ) <sup>2</sup> + (x<sup>3</sup> − µ) <sup>2</sup> + (x<sup>4</sup> − µ) 2 .

## **4. Rules for use with sigma notation**

There are a number of useful results that we can obtain when we use sigma notation. For example, suppose we had a sum of constant terms

$$\sum_{k=1}^{5} 3.$$

What does this mean? If we write this out in full then we get

$$\sum_{k=1}^{5} 3 = 3+3+3+3+3$$

$$= 5 \times 3$$

$$= 15.$$

In general, if we sum a constant n times then we can write

$$\sum_{k=1}^{n} c = \underbrace{c + c + \ldots + c}_{n \text{ times}} = nc.$$

Suppose we have the sum of a constant times k. What does this give us? For example,

$$\sum_{k=1}^{4} 3k = (3 \times 1) + (3 \times 2) + (3 \times 3) + (3 \times 4)$$

$$= 3 \times (1 + 2 + 3 + 4)$$

$$= 3 \times 10$$

$$= 30$$

But we can see from this calculation that the result also equals

$$3 \times (1 + 2 + 3 + 4) = 3 \sum_{k=1}^{4} k$$
,

so that

$$\sum_{k=1}^{4} 3k = 3\sum_{k=1}^{4} k.$$

In general, we can say that

$$\sum_{k=1}^{n} ck = (c \times 1) + (c \times 2) + \dots + (c \times n)$$
$$= c \times (1 + \dots + n)$$
$$= c \sum_{k=1}^{n} k.$$

Suppose we have the sum of k plus a constant. What does this give us? For example,

$$\sum_{k=1}^{4} (k+2) = (1+2) + (2+2) + (3+2) + (4+2)$$

$$= (1+2+3+4) + (4 \times 2)$$

$$= 10+8$$

$$= 18.$$

But we can see from this calculation that the result also equals

$$(4 \times 2) + (1 + 2 + 3 + 4) = (4 \times 2) + \sum_{k=1}^{4} k,$$

so that

$$\sum_{k=1}^{4} (k+2) = (4 \times 2) + \sum_{k=1}^{4} k.$$

In general, we can say that

$$\sum_{k=1}^{n} (k+c) = (1+c) + (2+c) + \dots + (n+c)$$

$$= \underbrace{(c+c+\dots+c)}_{n \text{ times}} + (1+2+\dots+n)$$

$$= nc + \sum_{k=1}^{n} k.$$

Notice that we have written the answer with the constant nc on the left, rather than as

$$\sum_{k=1}^{n} k + nc,$$

to make it clear that the sigma refers just to the k and not to the constant nc. Another way of making this clear would be to write

$$\left(\sum_{k=1}^{n} k\right) + nc.$$

In fact we can generalise this result even further. If we have any function g(k) of k, then we can write

$$\sum_{k=1}^{n} (g(k) + c) = nc + \sum_{k=1}^{n} g(k)$$

by using the same type of argument, and we can also write

$$\sum_{k=1}^{n} (ag(k) + c) = nc + a \sum_{k=1}^{n} g(k)$$

where a is another constant. We can also consider the sum of two different functions, such as

$$\sum_{k=1}^{3} (k+k^2) = (1+1^2) + (2+2^2) + (3+3^2)$$

$$= (1+2+3) + (1^2+2^2+3^2)$$

$$= 6+14$$

$$= 20.$$

Notice that

$$(1+2+3) + (1^2+2^2+3^2) = \sum_{k=1}^{3} k + \sum_{k=1}^{3} k^2,$$

so that

$$\sum_{k=1}^{3} (k+k^2) = \sum_{k=1}^{3} k + \sum_{k=1}^{3} k^2.$$

In general, we can write

$$\sum_{k=1}^{n} (f(k) + g(k)) = \sum_{k=1}^{n} f(k) + \sum_{k=1}^{n} g(k),$$

and in fact we could even extend this to the sum of several functions of k.

![](_page_8_Picture_0.jpeg)

## **Key Point**

If a and c are constants, and if f(k) and g(k) are functions of k, then

$$\sum_{k=1}^{n} c = nc,$$

$$\sum_{k=1}^{n} ck = c \sum_{k=1}^{n} k,$$

$$\sum_{k=1}^{n} (k+c) = nc + \sum_{k=1}^{n} k,$$

$$\sum_{k=1}^{n} (ag(k)+c) = nc + a \sum_{k=1}^{n} g(k),$$

$$\sum_{k=1}^{n} (f(k)+g(k)) = \sum_{k=1}^{n} f(k) + \sum_{k=1}^{n} g(k).$$

We shall finish by taking a particular example and using sigma notation. Suppose that we want to find the mean of a set of examination marks. Now

$$mean = \frac{total \ sum \ of \ marks}{no. \ of \ values}$$

So if the marks were 2, 3, 4, 5 and 6 we would have

$$\text{mean} = \frac{2+3+4+5+6}{5} = \frac{20}{5}$$

But more generally, if we have a set of marks x<sup>i</sup> , where i runs from 1 to n, we can write the mean using sigma notation. We write

$$\mathsf{mean} = \frac{1}{n} \sum_{i=1}^n x_i \,.$$

#### Exercises

4. By writing out the terms explicitly, show that

(a) 
$$\sum_{k=1}^{5} 3k = 3\sum_{k=1}^{5} k$$
 (b)  $\sum_{i=1}^{6} 4i^2 = 4\sum_{i=1}^{6} i^2$  (c)  $\sum_{n=1}^{4} 5 = 4 \times 5 = 20$  (d)  $\sum_{k=1}^{6} c = 8c$ .

5. Write out what is meant by

$$\sum_{k=1}^{4} \frac{1}{(2k+1)(2k+3)}.$$

k=1

#### **Answers**

(a) 
$$\sum_{\substack{n=1\\5}}^{5} n^3 = 1^3 + 2^3 + 3^3 + 4^3 + 5^3$$

(b) 
$$\sum_{n=1}^{5} 3^n = 3^1 + 3^2 + 3^3 + 3^4 + 3^5$$

(c) 
$$\sum_{r=1}^{4} (-1)^r r^2 = -1^2 + 2^2 - 3^2 + 4^2$$

(d) 
$$\sum_{k=1}^{4} \frac{(-1)^{k+1}}{2k+1} = \frac{1}{3} - \frac{1}{5} + \frac{1}{7} - \frac{1}{9}$$

(e) 
$$\sum_{i=1}^{N} x_i^2 = x_1^2 + x_2^2 + x_3^2 + \ldots + x_N^2$$

(f) 
$$\sum_{i=1}^{N} f_i x_i = f_1 x_1 + f_2 x_2 + f_3 x_3 + \ldots + f_N x_N$$

2. 30.

3.

(a) 
$$\frac{1}{1} + \frac{1}{2} + \frac{1}{3} + \frac{1}{4} + \frac{1}{5} = \sum_{k=1}^{5} \frac{1}{k}$$

(b) 
$$-1+2-3+4-5+6-\ldots+20 = \sum_{k=1}^{20} (-1)^k k$$

(c) 
$$(x_1 - \mu)^2 + (x_2 - \mu)^2 + (x_3 - \mu)^2 + (x_4 - \mu)^2 = \sum_{k=1}^{4} (x_k - \mu)^2$$

5.

$$\sum_{k=1}^{4} \frac{1}{(2k+1)(2k+3)} = \frac{1}{(3)(5)} + \frac{1}{(5)(7)} + \frac{1}{(7)(9)} + \frac{1}{(9)(11)}$$