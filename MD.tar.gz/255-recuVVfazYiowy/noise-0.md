# An Iterative Coordinate Descent Algorithm to Compute Sparse Low-Rank Approximations

Cristian Rusu

Abstract—In this paper, we describe a new algorithm to build a few sparse principal components from a given data matrix. Our approach does not explicitly create the covariance matrix of the data and can be viewed as an extension of the Kogbetliantz algorithm to build an approximate singular value decomposition for a few principal components. We show the performance of the proposed algorithm to recover sparse principal components on various datasets from the literature and perform dimensionality reduction for classification applications.

Index Terms—Sparse principal component analysis, singular value decomposition approximation, low-rank approximation.

## I. INTRODUCTION

HE singular value decomposition (SVD) is one of the cornerstone algorithms in numerical linear algebra with numerous applications to signal processing.

To perform the complete SVD we have available well-established algorithms (reduction to bidiagonal form via House-holder reflectors followed by the QR algorithm [1][Lecture 31]). But, in many applications, we are interested to compute only a partial, approximate decomposition. For example, in dimensionality reduction (DR) applications such as principal component analysis (PCA) we are interested in computing only a few of the singular vectors associated with the highest singular values.

singular vectors associated with the highest singular values. Given a data matrix  $\mathbf{X} \in \mathbb{R}^{n \times N}$ , where n is the number of features and N is the number of data points, the SVD computes the factorization  $\mathbf{X} = \mathbf{U} \mathbf{\Sigma} \mathbf{V}^T$  where  $\mathbf{U}$  and  $\mathbf{V}$  are orthonormal matrices of appropriate sizes which contain the left and right singular vectors, respectively, and the diagonal matrix  $\mathbf{\Sigma}$  contains the positive singular values  $\sigma_k$  in decreasing order. The first p columns of  $\mathbf{U}$ , denoted  $\mathbf{U}_p$ , represent the first p principal components from the data. We have that  $\mathbf{U}_p$  maximizes  $\|\mathbf{U}_p^T\mathbf{X}\|_F$  with the orthogonality constraint that  $\mathbf{U}_p^T\mathbf{U}_p = \mathbf{I}_p, \ p \leq n$ . PCA is a non-convex optimization problem but due to the SVD, we are able to solve it exactly.

For interpretability and consistency issues [2], researchers have introduced the sparse principal component analysis (sPCA): PCA with the additional constraint that the singular

Manuscript received October 23, 2021; revised November 23, 2021; accepted November 26, 2021. Date of publication December 2, 2021; date of current version January 27, 2022. This work was supported by the Romanian Ministry of Education and Research, CNCS-UEFISCDI, under Grant PN-III-P1-1.1-TE-2019-1843, within PNCDI III. The associate editor coordinating the review of this manuscript and approving it for publication was Dr. Xun Chen.

The author is with the Faculty of Automatic Control and Computer Science, University Politehnica of Bucharest, 060042 Bucharest, Romania, and also with the Research Center for Logic, Optimization, and Security (LOS), Department of Computer Science, Faculty of Mathematics and Computer Science, University of Bucharest, 060042 Bucharest, Romania (e-mail: cristian.rusu@upb.ro).

Digital Object Identifier 10.1109/LSP.2021.3132276

vectors to compute are sparse, i.e.,  $\mathbf{U}_p$  is now sparse and orthonormal. This approach has seen many signal processing applications such as image decomposition and texture segmentation [3], shape encoding in images [4], compressed hyperspectral imaging [5], target localization in hyperspectral imaging [6], and moving object detection in videos [7].

The extra sparsity constraint for sPCA means that the straightforward SVD can no longer provide the optimal solution and therefore the non-convex optimization problem is hard to solve in the general case (simultaneous orthogonality [8] and sparsity constraints [9]).

For this reason, many different approaches have been proposed in the literature to approximately solve the problem. sPCA was first introduced in [10] using simple techniques such as canceling the lowest absolute values entries in the singular vectors (losing orthogonality in the process). Following this work, several LASSO and convex optimization (particularly semidefinite programming) approaches were developed to deal with the sparsity of the singular vectors [11]–[13]. There are numerous ways to deal with the sPCA and these include approaches such as: greedy methods [14], [15], geodesic steepest descent [16], Givens rotations [17], low rank approximations via a regularized (sparsity promoting) singular value decomposition [18], truncated power iterations [19]–[21], steepest descent on the Stiefel manifold using rotations matrices [22] or on the Grassmannian manifold [23], quasi-Newton optimization for the sparse generalized eigenvalue problem [24], iterative deflation techniques [25], the minorization-maximization framework [26] with additional orthogonality constraints [27] or on the Stiefel manifold [28] and statistical methods [29].

We propose a new way to build the left singular vectors by operating directly on a given data matrix (without constructing its covariance matrix) using a product of basic orthonormal transformations that work on two coordinates at a time. Orthogonality is maintained at every step of the algorithm and sparsity is controlled by the number of basic transformations used. The method can be seen as an extension of the Kogbetliantz algorithm [30]–[32] for the case when only a subset p of the most important (sparse) principal components are to be computed. We are not concerned with the choice of p [33], we assume p given and fixed.

The paper is structured as follows: Section II described the proposed method highlighting the three main ingredients of the procedure, Section III gives experimental support for the proposed method and Section IV concludes the paper.

## II. THE PROPOSED METHOD

In this section, we detail the proposed method to approximately compute sparse singular vectors. We start by describing the constrained least-squares optimization problem that we want

1070-9908 © 2021 IEEE. Personal use is permitted, but republication/redistribution requires IEEE permission. See https://www.ieee.org/publications/rights/index.html for more information.

to solve and then proceed to add structured matrices such that closed-form, locally optimal, updates can be iteratively applied to approximately solve this optimization problem.

#### A. The Optimization Problem

We begin by describing the constrained optimization problem whose solutions are the singular vectors of the data matrix.

Result 1: Given a data matrix  $\mathbf{X} \in \mathbb{R}^{n \times N}$ , assuming  $N \geq n$ , i.e., data points are stored columnwise, and denoting W = $\begin{bmatrix} \mathbf{I}_p & \mathbf{0}_{p\times (N-p)} \\ \mathbf{0}_{(n-p)\times p} & \mathbf{0}_{(n-p)\times (N-p)} \end{bmatrix}$  the solution to the following optimization problem

$$\underset{\bar{\mathbf{U}},\bar{\mathbf{V}}}{\text{minimize}} \|\mathbf{W} - \bar{\mathbf{U}}^T \mathbf{X} \bar{\mathbf{V}}\|_F^2 \text{ such that } \bar{\mathbf{U}}^T \bar{\mathbf{U}} = \mathbf{I}_n, \bar{\mathbf{V}}^T \bar{\mathbf{V}}$$

is given when  $\bar{\mathbf{U}} = \mathbf{U}$  and  $\bar{\mathbf{V}} = \mathbf{V}$  from the SVD  $\mathbf{X} = \mathbf{U} \mathbf{\Sigma} \mathbf{V}^T$ . The minimum value is  $\sum_{k=1}^p (\sigma_k - 1)^2 + \sum_{k=p+1}^n \sigma_k^2$ .

*Proof:* We have the SVD  $\mathbf{X} = \mathbf{U} \mathbf{\Sigma} \mathbf{V}^T$ . Use the invariance of the Frobenius norm to orthonormal transformations to reach:

$$\|\mathbf{W} - \bar{\mathbf{U}}^T \mathbf{X} \bar{\mathbf{V}}\|_F^2 = \|\bar{\mathbf{U}} \mathbf{W} \bar{\mathbf{V}}^T - \mathbf{X}\|_F^2$$
$$= \|\bar{\mathbf{U}} \mathbf{W} \bar{\mathbf{V}}^T - \mathbf{U} \mathbf{\Sigma} \mathbf{V}^T\|_F^2.$$
(2)

We have now reached the classic problem of finding the closest orthonormal matrix, the Procrustes problem [34], whose solution is given by  $\bar{\mathbf{U}} = \mathbf{U}$  and  $\bar{\mathbf{V}} = \mathbf{V}$ . For this choice, the quantity in (2) reduces to  $\|\mathbf{U}\mathbf{W}\mathbf{V}^T - \mathbf{U}\mathbf{\Sigma}\mathbf{V}^T\|_F^2 = \|\mathbf{W} - \mathbf{\Sigma}\|_F^2$ .

Solving this constrained optimization problem directly, without using the SVD, is computationally hard. We will next add an additional structural constraint to simplify the problem.

#### B. The Proposed Structure

We propose to factorize the singular vector matrix  $\bar{\mathbf{U}}$  as a product of basic transformations that are easy to manipulate and for which we can write closed-form solutions to (1).

Consider the following  $n \times n$  orthonormal linear transformation, called a G-transform [35], [36]:

$$\mathbf{G}_{ij} = \begin{bmatrix} \mathbf{I}_{i-1} & & & & & \\ & * & & * & & \\ & & \mathbf{I}_{j-i-1} & & & \\ & * & & * & & \\ & & & & \mathbf{I}_{n-j} \end{bmatrix}, \tag{3}$$

$$\text{with}\quad \tilde{\mathbf{G}} \in \left\{ \begin{bmatrix} c & -s \\ s & c \end{bmatrix}, \begin{bmatrix} c & s \\ s & -c \end{bmatrix} \right\}, \quad \text{such} \quad \text{that} \quad c^2 + s^2 = 1,$$

where the non-zero part (denoted by \* and G) is only on rows and columns i and j. These transformations are generalization of Givens rotations that now also include reflection transformations. When optimizing with this structure, we can consider that we are doing coordinate descent with an orthogonality constraint. We need two coordinates (i, j) at a time as on a single coordinate the orthonormal transformation is just  $\{\pm 1\}$ (the identity matrix with a single diagonal element set to -1).

We propose to write our unknowns U and V as a product of transformations (3) which we denote by  $G_{ij}$  and  $H_{ij}$  to distinguish the left and right singular vectors, respectively:

$$\bar{\mathbf{U}} = \mathbf{G}_{i_1 j_1} \cdots \mathbf{G}_{i_m j_m}, \bar{\mathbf{V}} = \mathbf{H}_{i_1 j_1} \cdots \mathbf{H}_{i_m j_m}, \tag{4}$$

where  $m \geq 1$  is fixed. Then we have that  $\bar{\mathbf{U}}_p$  and  $\bar{\mathbf{V}}_p$  consist of the first p columns of  $\bar{\mathbf{U}}$  and  $\bar{\mathbf{V}}$ , respectively.

#### C. The Proposed Solution

We now move to solve the optimization problem in (1) by using the structure (4) for the solutions, i.e., we minimize

$$\|\mathbf{W} - \mathbf{G}_{i_m j_m}^T \cdots \mathbf{G}_{i_1 j_1}^T \mathbf{X} \mathbf{H}_{i_1 j_1} \cdots \mathbf{H}_{i_m j_m} \|_F^2.$$
 (5)

Therefore, we assume that the matrices  $\bar{\mathbf{U}}_p$  and  $\bar{\mathbf{V}}_p$ are updated by adding an extra basic G-transform in its factorization. Assume that we have initialized the first k-1 G-transforms in (3) in order to reduce  $\|\mathbf{W} - \mathbf{G}_{i_{k-1}j_{k-1}}^T \cdots \mathbf{G}_{i_1j_1}^T \mathbf{X} \mathbf{H}_{i_1j_1} \cdots \mathbf{H}_{i_{k-1}j_{k-1}}\|_F^2$  then to optimally update the  $k^{\text{th}}$  transform we have the following result. Herein, we denote  $\mathbf{X}_k = \mathbf{G}_{i_{k-1}j_{k-1}}^T \cdots \mathbf{G}_{i_1j_1}^T \mathbf{X} \mathbf{H}_{i_1j_1} \cdots \mathbf{H}_{i_{k-1}j_{k-1}}$ .

Result 2: Given a data matrix  $\mathbf{X}_k \in \mathbb{R}^{n \times N}$  then we have

$$\min \|\mathbf{W} - \mathbf{G}_{i_k j_k}^T \mathbf{X}_k \mathbf{H}_{i_k j_k} \|_F^2$$

$$= p + \|\mathbf{X}_k\|_F^2 - 2\operatorname{tr}(\mathbf{W}^T \mathbf{X}_k) - 2\mathcal{C}_{i_k j_k}. \tag{6}$$

where 
$$C_{i_k j_k} = \max \left\{ \sqrt{(X_{i_k i_k}^{(k)} + X_{j_k j_k}^{(k)})^2 + (X_{i_k j_k}^{(k)} - X_{j_k i_k}^{(k)})^2}, \right.$$

$$\sqrt{(X_{i_k i_k}^{(k)} - X_{j_k j_k}^{(k)})^2 + (X_{i_k j_k}^{(k)} + X_{j_k i_k}^{(k)})^2} \right\} - X_{i_k i_k}^{(k)} - X_{j_k j_k}^{(k)}}$$
for the choices  $\mathbf{G}_{i_k j_k} = \mathbf{A}$  and  $\mathbf{H}_{i_k j_k} = \mathbf{B}$  from the SVD of the  $2 \times 2$  matrix  $\begin{bmatrix} X_{i_k i_k}^{(k)} & X_{i_k j_k}^{(k)} \\ X_{j_k i_k}^{(k)} & X_{j_k j_k}^{(k)} \end{bmatrix} = \mathbf{ASB}^T.$ 

Proof: We follow and adapt the proof of Theorem 1 from [36] and we develop the Frobenius norm quantity like:

and we develop the Frobenius norm quantity like:

$$\|\mathbf{W} - \mathbf{G}_{i_k j_k}^T \mathbf{X}_k \mathbf{H}_{i_k j_k}\|_F^2 = \|\mathbf{W}\|_F^2 + \|\mathbf{G}_{i_k j_k}^T \mathbf{X}_k \mathbf{H}_{i_k j_k}\|_F^2$$
$$- 2 \text{tr}(\mathbf{W}^T \mathbf{G}_{i_k j_k}^T \mathbf{X}_k \mathbf{H}_{i_k j_k})$$
$$= p + \|\mathbf{X}_k\|_F^2 - 2 \text{tr}(\mathbf{W}^T \mathbf{G}_{i_k j_k}^T \mathbf{X}_k \mathbf{H}_{i_k j_k}).$$

 $\mathbf{G}_{ij} = \begin{bmatrix} \mathbf{I}_{i-1} & & & & \\ & * & & * & \\ & & \mathbf{I}_{j-i-1} & \\ & * & & * & \\ & & & \mathbf{I}_{m-1} & \\ & & & & * & \\ & & & & & \\ & & & & &$ 

$$\operatorname{tr}(\mathbf{W}^T \mathbf{G}_{i_k j_k}^T \mathbf{X}_k \mathbf{H}_{i_k j_k}) = \operatorname{tr}(\mathbf{Z}) + \operatorname{tr}(\tilde{\mathbf{G}}^T \tilde{\mathbf{X}}_k \tilde{\mathbf{H}}) - \operatorname{tr}(\tilde{\mathbf{X}}_k)$$

$$= \sum_{q=1, q \notin \{i_k, j_k\}}^p Z_{qq} + \operatorname{tr}(\tilde{\mathbf{G}}^T \tilde{\mathbf{X}}_k \tilde{\mathbf{H}}).$$

In order to minimize the quantity in (7) we need to maximize the trace term above and the quantity  $tr(\tilde{\mathbf{G}}^T\tilde{\mathbf{X}}_k\tilde{\mathbf{H}})$ . To maximize this, we use the two-sided Procrustes problem [37], the solution is given by the SVD of the  $2 \times 2$  matrix  $\tilde{\mathbf{X}}_k$ . For this optimal choice, the objective function is given by  $p + \|\mathbf{X}_k\|_F^2 - 2\operatorname{tr}(\mathbf{Z}) - 2(\|\mathbf{\tilde{X}}_k\|_* - \operatorname{tr}(\mathbf{\tilde{X}}_k))$  where the critical quantity is the difference between the sum of singular values (nuclear norm) and the sum of eigenvalues (trace) of  $X_k$ . The quantities used for the calculation of  $C_{i_k j_k}$  are reached by using the explicit formulas for the singular values of  $\tilde{\mathbf{X}}_k$ , i.e.,

$$s_{1,2} = \sqrt{\frac{1}{2}(\|\tilde{\mathbf{X}}_k\|_F^2 \pm \sqrt{\|\tilde{\mathbf{X}}_k\|_F^4 - 4\det(\tilde{\mathbf{X}}_k)^2})}.$$

the factorizations in (4) for each k at a time such that at each step we locally minimize the objective function, i.e.,:

$$(i_k^{\star}, j_k^{\star}) = \arg\max \ \mathcal{C}_{ij}, i = 1, \dots, p, j = i + 1, \dots, N.$$
 (8)

As this is the main result of the paper, some clarifying remarks, and connections to previous work are in order.

Remark 1: (Choosing indices  $(i_k, j_k)$ ). The ranges on the indices are described in (8) but note that, because  $X_k$  is not square, we are out of bounds whenever  $j_k > n$  because of the number

of lines in 
$$\mathbf{X}_k$$
. In this case, we take  $\tilde{\mathbf{X}}_k = \begin{bmatrix} X_{i_k i_k}^{(k)} & X_{i_k j_k}^{(k)} \\ 0 & 0 \end{bmatrix}$  and

therefore  $G_{i_k j_k} = I_n$ , i.e., there is no update to the left singular vectors but only on  $\bar{\mathbf{V}}$ .

Remark 2: (Connection to the Kogbetliantz method). The proposed method is based on iterative methods such as the Jacobi diagonalization [38] and the Kogbetliantz [39] methods. This is because we make use of updates  $\mathbf{X}_{k+1} \leftarrow \mathbf{G}_{i_k,i_k}^T \mathbf{X}_k \mathbf{H}_{i_k,i_k}$ to diagonalize the data matrix X. The significant difference with the proposed method is the way we choose indices  $(i_k, j_k)$ to operate on: instead of using the classic largest off-diagonal absolute value from  $X_k$  we choose the indices and the orthonormal transformation on those indices that locally maximizes the trace of  $\mathbf{X}_{k+1}$ . The scores  $\mathcal{C}_{ij}$  are non-negative (nuclear norm is always larger than the trace for a given matrix [40]) and zero only when  $\mathbf{X}_k$  is positive definite. Note that  $\mathbf{X}_{k+1}$  has zeroes on positions  $(i_k, j_k)$  and  $(j_k, i_k)$ .

Remark 3: (Connection to previous work). The matrix structure in (3) and factorizations like (4) have been previously used to compute factorizations of orthonormal matrices where the goal was to maximize quantities such as  $tr(\mathbf{Q}_{i_k j_k} \mathbf{X}_k)$  with an orthonormal  $\mathbf{Q}_{i_k,j_k}$ , i.e., computing a polar decomposition of  $\mathbf{X}_k$ . In our optimization problem we use a two-sided transformation that maximizes  $\operatorname{tr}(\mathbf{G}_{i_k j_k}^T \mathbf{X}_k \mathbf{H}_{i_k j_k})$ , i.e., computing the singular value decomposition. We note that, assuming appropriate dimensions of matrices, because of the trace equality  $\operatorname{tr}(\mathbf{G}_{i_k j_k}^T \mathbf{X}_k \mathbf{H}_{i_k j_k}) = \operatorname{tr}(\mathbf{H}_{i_k j_k} \mathbf{G}_{i_k j_k}^T \mathbf{X}_k)$  the two trace quantities are maximized for the same choices of indices when  $\mathbf{Q}_{i_k j_k} = \mathbf{H}_{i_k j_k} \mathbf{G}_{i_k j_k}^T$ . While the polar decomposition achieves a symmetric positive definite result, our approach diagonalizes the matrix, i.e.,  $\lim_{k \to \infty} \mathbf{X}_k = \begin{bmatrix} \mathbf{\Sigma}_p & \mathbf{0}_{p \times (N-p)} \\ \mathbf{0}_{(n-p) \times p} & \mathbf{Y} \end{bmatrix}$  where

the matrix, i.e., 
$$\lim_{k\to\infty}\mathbf{X}_k=\begin{bmatrix}\mathbf{\Sigma}_p & \mathbf{0}_{p imes(N-p)}\\ \mathbf{0}_{(n-p) imes p} & \mathbf{Y}\end{bmatrix}$$
 where

 $\Sigma_p$  is a diagonal containing the largest p singular values and  $\mathbf{Y} \in \mathbb{R}^{(n-p)\times(N-p)}$  obeys  $\|\mathbf{Y}\|_F^2 = \sum_{k=p+1}^n \sigma_k^2$ . We note that the work in [41], [42] deals with computing the eigenvalue decomposition for symmetric matrices, i.e., when  $X_k$  is square and symmetric, and we also have that  $\mathbf{G}_{i_k j_k} = \mathbf{H}_{i_k j_k}^T$ .

Due to (4) we will see a trade-off between the sparsity of the singular vector and their accuracy (how well they diagonalize the data matrix). Then m order  $O(p \log_2 n)$  leads to sparse solutions that provide a rough approximation while m of order O(np)provides better approximation but fuller vectors.

## D. The Proposed Algorithm

In this section, we describe the detailed proposed algorithm. The idea is to iteratively and approximately solve (1) where the Algorithm 1:

**Input:** Data matrix  $\mathbf{X} \in \mathbb{R}^{n \times N}$ , size of rank approximation  $p \in \mathbb{N}^*$ , and number of basic transformations/iterations m > 1.

**Output:** Approximate left singular space  $\bar{\mathbf{U}} \in \mathbb{R}^{n \times n}$  as (4).

- Initialize:  $\bar{\mathbf{U}} \leftarrow \mathbf{I}_n, \mathbf{X}_0 \leftarrow \mathbf{X}$ , compute  $C_{ij}$  with (6) for  $N \ge j > i \ge 1$  and  $i \le p$ .
- 2: Iterative process, for k = 1, ..., m:
  - Find  $(i_k^{\star}, j_k^{\star}) = \arg \max C_{ij}$ .
  - Find  $(i_k, j_k) = \arg\max_{i,j} C_{ij}$ .
     Get  $\mathbf{G}_{i_k^\star j_k^\star}$  and  $\mathbf{H}_{i_k^\star j_k^\star}$  according to Result 2 with  $\mathbf{X}_{k-1}$ .
     Update  $\mathbf{X}_{(k)} \leftarrow \mathbf{G}_{i_k^\star j_k^\star}^T \mathbf{X}_{(k-1)} \mathbf{H}_{i_k^\star j_k^\star}$ ,  $\bar{\mathbf{U}} \leftarrow \bar{\mathbf{U}} \mathbf{G}_{i_k^\star j_k^\star}$ .
     With (6), update  $\mathcal{C}_{i_k^\star j}$  for  $N \geq j > i_k^\star$ ,  $\mathcal{C}_{ij_k^\star}$  for  $i \leq p$ .

working variables (the singular vectors) are explicitly factored as in (4) and each iteration performs the locally optimal step using Result 2. Because of this, each step of the proposed algorithm ensures the Frobenius norm error is non-increasing and therefore the convergence to a stationary point is guaranteed. For simplicity, we assume the total number of basic transformations m is given and fixed.

The complete proposed procedure is shown in Algorithm 1. From the output  $\bar{\mathbf{U}}$  we keep the first p columns, i.e.,  $\bar{\mathbf{U}}_p$ . The initialization takes O(pN) operations due to the calculations of all scores  $\mathcal{C}_{ij}$  but this step is trivially parallelizable. Each iteration takes  $\tilde{O}(n+N)$ : the updates of the scores and the calculation of  $\mathbf{X}_k$  from  $\mathbf{X}_{k-1}$  are easy as only two rows/columns are updated. The overall complexity of Algorithm 1 is therefore order O(pN + m(n+N)). If we choose  $m \sim O(p \log_2 N)$  then the overall complexity is  $O(pN + pn \log_2 N + pN \log_2 N)$ . In terms of memory, the 2 m transformations accumulate in  $\hat{\mathbf{X}}$ while for  $\bar{\mathbf{U}}$  we store an extra  $O(m \log_2 n)$  or O(np) bits if the transform is stored explicitly (the m transforms  $G_{i_k j_k}$ ) or not (keep in memory  $\overline{\mathbf{U}}$ ), whichever is more convenient.

Remark 4: (Block transformations). Algorithm 1 is designed to be numerically efficient for  $m \sim O(p)$  or  $m \sim O(p \log_2 N)$ . In principle, the algorithm could also be used to compute the non-sparse approximate SVD of X but due to the  $2 \times 2$  updates the number of iterations m would be significant, for example O(pN). In this case, a block version of the algorithm could be used. This approach, which we call Algorithm 1 - block, would pair each index  $i \leq p$  with another index j > p by choosing the next largest  $C_{ij}$  on new indices and thus perform a block SVD of size  $2p \times 2p$  (here we could use a standard SVD algorithm). The benefit is that we exchange a single SVD of size  $n \times N$ with a series of smaller sized SVDs  $2p \ll n$ .

#### III. EXPERIMENTAL RESULTS

In this section we provide experimental results using popular datasets from the machine learning community to highlight the performance of the proposed method.

To measure the performance of the proposed algorithm and competitors, we will use the following accuracy metric:

$$\epsilon = \frac{\operatorname{tr}(\mathbf{W}^T \mathbf{X}_m)}{\sum_{k=1}^p \sigma_i} (\%), \tag{9}$$

<sup>1</sup>[Online]. Available: https://github.com/cristian-rusu-research/JACOBI-

![](_page_3_Figure_2.jpeg)

Fig. 1. We show mean and standard deviation for the accuracy as defined in (9), achieved by the proposed method (blue solid) against the Kogbetliantz (red dashed) and randomized (green dashed-dot) methods. The accuracy improves with the number of transformations m (top) or transformation blocks b of size  $2p \times 2p$  (bottom), see Remark 4. From left to right we have results for the ISOLET, MNIST digits, MNIST fashion, and USPS datasets, respectively. In all cases p=15.

![](_page_3_Figure_4.jpeg)

Fig. 2. Accuracy metric (9) for the Facebook dataset on the left (n=54,p=15,N=40949) and Gene dataset on the right (n=801,p=40,N=20264) from [50].

the denominator represents the sum of the true largest p singular values while the numerator is the sum of the first p diagonal elements from  $\mathbf{X}_m$ , i.e., the data matrix  $\mathbf{X}$  after m steps of the proposed algorithm have been applied.

In Fig. 1 we show the evolution of the error (9) with the number of transformations m for both Algorithm 1 and Algorithm 1 - block. For comparisons and reference we show the Kogbetliantz method (indices  $(i_k,j_k)$  are chosen to maximize  $|X_{i_kj_k}^{(k)}| + |X_{j_ki_k}^{(k)}|$ ) and a randomized approach (indices  $(i_k,j_k)$  are chosen uniformly at random), respectively. The proposed method performs best, while Kogbetliantz picks many times indices that lead to  $\mathbf{G}_{i_kj_k} = \mathbf{I}_n$  (see Remark 1). Due to their prevalence in the numerical linear algebra literature [43], we also test against a randomized method that picks indices  $(i_k,j_k)$  uniformly at random and then performs the optimal transform on those indices. Similar results are observed irrespective of the choice for p.

We also compare with recent developments for sparse PCA from the literature: a convex integer programming (IP) approach [44], a branch and bound (BB) algorithm [45], a bipartite maximum weight matching (BMW) approach [46], an approach that performs low-rank (LR) updates [47], and a coordinate descent (CD) method [48]. These methods usually also come with theoretical guarantees, albeit no always tight, but the disadvantage is that they operate on the covariance matrix  $XX^T$  and not the data matrix X itself. Building the covariance matrix takes  $O(n^2 N)$  operations. In this time, our algorithm can already build U with m of order  $O(n^2)$ . Results for two datasets are shown in Fig. 2. Best results are obtained by IP and BB but these approaches have also the largest running times and in fact just a few data points can be computed for IP. Running times for the Facebook and Gene datasets in the case of sparsity levels 22% and 0.62%, respectively, are: IP takes 12 and

![](_page_3_Figure_9.jpeg)

Fig. 3. Average classification accuracy achieved by k-NN after dimensionality reduction is done with the proposed method choosing p=100 and p=40 for the MNIST (left) and USPS (right) datasets, respectively. Percentages show the fill-in of the projection.

36 hours, respectively, BB is the second slowest (and second best) with 30 minutes and 1 h, respectively, while BMW, LR, and CD all run in approximately 2 and 5 minutes, respectively. The proposed method is faster (37 and 46 seconds for Facebook and Gene, respectively) and generally outperforms them but they all perform similarly in terms of the accuracy (9).

In Fig. 3 we show an application to dimensionality reduction with p = 100 in a classification scenario. We use the following datasets: ISOLET with 26 classes and n = 617, N = 7797; USPS with 10 classes and n = 256, N = 9298; EMNIST digits with 10 classes and n = 784,  $N = 6 \times 10^4$ ; and EMNIST fashion with 10 classes and n = 784,  $N = 6 \times 10^4$ . We consider the USPS and MNIST digits datasets for which we use the k-Nearest Neighbors (k-NN) algorithm with K=25 to perform classification. We randomly split the dataset into  $N_{\text{train}} = 50000$  and  $N_{\rm test}=10000$  for MNIST, and  $N_{\rm train}=7291$  and  $N_{\rm test}=2007$ for USPS. As performance reference, we show the results of the full PCA and the sparse JL (sJL) transforms [49] with s = 10non-zeroes per column. All results are averaged over 10 realizations. We also compare against the sparse PCA (sPCA) [19] and one of the earlier approaches (sPCA Zou) [12] from the literature. It is perhaps surprising how very sparse projections (below 1% fill-in) lead to within a few percentages of the state-of-the-art classification results. Both p and K were chosen such that the full PCA and k-NN lead to the best experimental

We report running times for the proposed method below one second when  $\log_2(m) \leq 8$  while for the largest m, i.e.,  $\log_2(m) = 16$ , we have 300 and 6 seconds for MNIST and USPS, respectively. sPCA takes 540 and 8 seconds while sPCA Zou takes 450 and 6 seconds for MNIST and USPS, respectively. Both previous methods are slower than the proposed method. We would also like to highlight that there are no hyperparameters to tune for Algorithm 1.

# IV. CONCLUSION

In this paper, we have proposed a new algorithm to find a few approximate sparse principal components from a data matrix which we have used to perform dimensionality reduction. The proposed method works directly on the data matrix and does not explicitly build the covariance matrix of the data, and is therefore memory efficient. Numerical results that build sparse principal components and then perform dimensionality reduction with application to classification show that the method is practical and compares very well against the state-of-the-art literature, especially in the running time. Future research should deal with providing theoretical guarantees and ways to randomize the proposed method.

# REFERENCES

- [1] L. N. Trefethen and D. Bau, *Numerical Linear Algebra*. Philadelphia, PA, USA: SIAM, 1997.
- [2] I. M. Johnstone *et al.*, "On consistency and sparsity for principal components analysis in high dimensions," *J. Amer. Statist. Assoc.*, vol. 104, no. 486, pp. 682–703, 2009.
- [3] F. Zhang, X. Ye, and W. Liu, "Image decomposition and texture segmentation via sparse representation," *IEEE Signal Process. Lett.*, vol. 15, pp. 641–644, 2008, doi: [10.1109/LSP.2008.2002722.](https://dx.doi.org/10.1109/LSP.2008.2002722)
- [4] D. Schmitter and M. Unser, "Landmark-based shape encoding and sparsedictionary learning in the continuous domain," *IEEE Trans. Image Process.*, vol. 27, no. 1, pp. 365–378, Jan. 2018.
- [5] Z. Khan, F. Shafait, and A. Mian, "Joint group sparse PCA for compressed hyperspectral imaging," *IEEE Trans. Image Process.*, vol. 24, no. 12, pp. 4934–4942, Dec. 2015.
- [6] S. Rambhatla, X. Li, J. Ren, and J. Haupt, "A dictionary-based generalization of robust PCA with applications to target localization in hyperspectral imaging," *IEEE Trans. Signal Process.*, vol. 68, pp. 1760–1775, 2020, doi: [10.1109/TSP.2020.2977458.](https://dx.doi.org/10.1109/TSP.2020.2977458)
- [7] S. Javed, A. Mahmood, S. Al-Maadeed, T. Bouwmans, and S. K. Jung, "Moving object detection in complex scene using spatiotemporal structured-sparse RPCA," *IEEE Trans. Image Process.*, vol. 28, no. 2, pp. 1007–1022, Feb. 2019.
- [8] J. H. Manton, "Optimization algorithms exploiting unitary constraints," *IEEE Trans. Signal Process.*, vol. 50, no. 3, pp. 635–650, Mar. 2002.
- [9] A. M. Tillmann, "On the computational intractability of exact and approximate dictionary learning," *IEEE Signal Process. Lett.*, vol. 22, no. 1, pp. 45–49, Jan. 2015.
- [10] J. Cadima and I. T. Jolliffe, "Loading and correlations in the interpretation of principle components," *J. Appl. Statist.*, vol. 22, no. 2, pp. 203–214, 1995.
- [11] I. T. Jolliffe, N. T. Trendafilov, and M. Uddin, "A modified principal component technique based on the LASSO," *J. Comput. Graph. Statist.*, vol. 12, no. 3, pp. 531–547, 2003.
- [12] H. Zou, T. Hastie, and R. Tibshirani, "Sparse principal component analysis," *J. Comput. Graph. Statist.*, vol. 15, no. 2, pp. 265–286, 2006.
- [13] T. d'Orsi, P. K. Kothari, G. Novikov, and D. Steurer, "Sparse PCA: Algorithms, adversarial perturbations and certificates," in *Proc. IEEE 61st Annu. Symp. Found. Comput. Sci.*, 2020, pp. 553–564.
- [14] A. d'Aspremont, F. Bach, and L. El Ghaoui, "Optimal solutions for sparse principal component analysis," *J. Mach. Learn. Res.*, vol. 9, pp. 1269–1294, 2008.
- [15] G. Yuan, L. Shen, and W. Zheng, "A decomposition algorithm for the sparse generalized eigenvalue problem," in *Proc. IEEE/CVF Conf. Comput. Vision Pattern Recognit.*, Los Alamitos, CA, USA, 2019, pp. 6106– 6115.
- [16] M. O. Ulfarsson and V. Solo, "Sparse variable PCA using geodesic steepest descent," *IEEE Trans. Signal Process.*, vol. 56, no. 12, pp. 5823–5832, Dec. 2008.
- [17] S. Bartelmaos and K. Abed-Meraim, "Fast principal component extraction using givens rotations," *IEEE Signal Process. Lett.*, vol. 15, pp. 369–372, 2008, doi: [10.1109/LSP.2008.920006.](https://dx.doi.org/10.1109/LSP.2008.920006)
- [18] H. Shen and J. Z. Huang, "Sparse principal component analysis via regularized low rank matrix approximation," *J. Multivariate Anal.*, vol. 99, no. 6, pp. 1015–1034, 2008.
- [19] M. Hein and T. Bühler, "An inverse power method for nonlinear eigenproblems with applications in 1-spectral clustering and sparse PCA," in *Proc. Int. Conf. Neural Inf. Process. Syst.*, 2010, pp. 847–855.
- [20] M. Journée, Y. Nesterov, P. Richtárik, and R. Sepulchre, "Generalized power method for sparse principal component analysis," *J. Mach. Learn. Res.*, vol. 11, pp. 847–855, Mar. 2010.
- [21] Z. Ma, "Sparse principal component analysis and iterative thresholding," *Ann. Statist.*, vol. 41, no. 2, pp. 772–801, 2013.
- [22] P. Xiao and L. Balzano, "Online sparse and orthogonal subspace estimation from partial information," in *Proc. 54th Annu. Allerton Conf. Commun., Control, Comput.*, 2016, pp. 284–291.
- [23] B. Minnehan and A. Savakis, "Grassmann manifold optimization for fast L1-norm principal component analysis," *IEEE Signal Process. Lett.*, vol. 26, no. 2, pp. 242–246, Feb. 2019.
- [24] K. Uchida and I. Yamada, "An -1-penalization of adaptive normalized quasi-Newton algorithm for sparsity-aware generalized eigenvector estimation," in *Proc. IEEE Statist. Signal Process. Workshop*, 2018, pp. 528– 532.

- [25] M. Weylandt, "Multi-rank sparse and functional PCA manifold optimization and iterative deflation techniques," in *Proc. IEEE 8th Int. Workshop Comput. Adv. Multi-Sensor Adapt. Process.*, 2019, pp. 500–504.
- [26] J. Song, P. Babu, and D. Palomar, "Sparse generalized eigenvalue problem via smooth optimization," *IEEE Trans. Signal Process.*, vol. 63, no. 7, pp. 1627–1642, Apr. 2015.
- [27] K. Benidis, Y. Sun, P. Babu, and D. P. Palomar, "Orthogonal sparse PCA and covariance estimation via procrustes reformulation," *IEEE Trans. Signal Process.*, vol. 64, no. 23, pp. 6211–6226, Dec. 2016.
- [28] A. Breloy, S. Kumar, Y. Sun, and D. P. Palomar, "Majorizationminimization on the Stiefel manifold with application to robust sparse PCA," *IEEE Trans. Signal Process.*, vol. 69, pp. 1507–1520, 2021, doi: [10.1109/TSP.2021.3058442.](https://dx.doi.org/10.1109/TSP.2021.3058442)
- [29] J. Janková and S. van de Geer, "De-biased sparse PCA: Inference for eigenstructure of large covariance matrices," *IEEE Trans. Inf. Theory*, vol. 67, no. 4, pp. 2507–2527, Apr. 2021.
- [30] M. R. Hestenes, "Inversion of matrices by biorthogonalization and related results," *J. Soc. Ind. Appl. Math.*, vol. 6, no. 1, pp. 51–90, 1958.
- [31] J. Götze, P. Rieder, and J. A. Nossek, "Implementation of Kogbetliantz's SVD algorithm using orthonormal μ-rotations," in *Proc. 8th Eur. Signal Process. Conf.*, 1996, pp. 1–4.
- [32] J. G. McWhirter, "An algorithm for polynomial matrix SVD based on generalised Kogbetliantz transformations," in *Proc. 18th Eur. Signal Process. Conf.*, 2010, pp. 457–461.
- [33] M. O. Ulfarsson and V. Solo, "Selecting the number of principal components with SURE," *IEEE Signal Process. Lett.*, vol. 22, no. 2, pp. 239–243, Feb. 2015.
- [34] P. Schonemann, "A generalized solution of the orthogonal procrustes problem," *Psychometrika*, vol. 31, no. 1, pp. 1–10, 1966.
- [35] C. Rusu and J. Thompson, "Learning fast sparsifying transforms," *IEEE Trans. Sig. Proc.*, vol. 65, no. 16, pp. 4367–4378, Aug. 2017.
- [36] C. Rusu and L. Rosasco, "Fast approximation of orthogonal matrices and application to PCA," Mar. 2021, *arXiv:1907.08697*.
- [37] P. Schonemann, "On two-sided orthogonal procrustes problems," *Psychometrika*, vol. 33, no. 1, pp. 19–33, 1968.
- [38] C. Jacobi, "Uber ein leichtes verfahren die in der theorie der sacularstorungen Vorkommenden gleichungen numerisch aufzulosen," *J. fur die reine und angewandte Mathematik*, vol. 30, pp. 51–94, 1846.
- [39] J. Charlier, M. Vanbegin, and P. V. Dooren, "On effıcient implementations on Kogbetliantz's algorithm for computing the singular value decomposition," *Numer. Math.*, vol. 52, no. 3, pp. 279–300, 1988.
- [40] R. A. Horn and C. R. Johnson, *Matrix Analysis*. Cambridge, U.K.: Cambridge Univ. Press, 2013.
- [41] C. Rusu and L. Rosasco, "Constructing fast approximate eigenspaces with application to the fast graph Fourier transforms," *IEEE Trans. Signal Process.*, vol. 69, pp. 5037–5050, 2021, doi: [10.1109/TSP.2021.3107629.](https://dx.doi.org/10.1109/TSP.2021.3107629)
- [42] C. Rusu, "An iterative Jacobi-like algorithm to compute a few sparse eigenvalue-eigenvector pairs," Jun. 2021, *arXiv:2105.14642*.
- [43] P. Drineas and M. W. Mahoney, "RandNLA: Randomized numerical linear algebra," *Commun. ACM*, vol. 59, no. 6, pp. 80–90, 2016.
- [44] S. S. Dey, R. Mazumder, and G. Wang, "Using L1-relaxation and integer programming to obtain dual bounds for sparse PCA," Aug. 2021, *arXiv:1810.09062*.
- [45] L. Berk and D. Bertsimas, "Certifiably optimal sparse principal component analysis," *Math. Program. Comput.*, vol. 11, no. 3, pp. 381–420, Sep. 2019.
- [46] M. Asteris, D. Papailiopoulos, A. Kyrillidis, and A. G. Dimakis, "Sparse PCA via bipartite matchings," in *Proc. Adv. Neural Inf. Process. Syst.*, 2015, vol. 28.
- [47] D. Papailiopoulos, A. Dimakis, and S. Korokythakis, "Sparse PCA through low-rank approximations," in *Proc. Int. Conf. Mach. Learn.*, 2013, pp. 747–755.
- [48] A. Beck and Y. Vaisbourd, "The sparse principal component analysis problem: Optimality conditions and algorithms," *J. Optim. Theory Appl.*, vol. 170, no. 1, pp. 119–143, Jul. 2016.
- [49] D. M. Kane and J. Nelson, "Sparser Johnson-Lindenstrauss transforms," *J. ACM*, vol. 61, no. 1, 2014.
- [50] M. Lichman, "UCI machine learning repository," 2017.