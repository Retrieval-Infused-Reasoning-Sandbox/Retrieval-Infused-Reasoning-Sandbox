## Linear codes meeting the Griesmer bound, minihypers, and geometric applications

L. Storme<sup>∗</sup>

#### Abstract

Coding theory and Galois geometries are two research areas which greatly influence each other. In this talk, we focus on the link between linear codes meeting the Griesmer bound and minihypers in finite projective spaces. Minihypers are particular (multiple) blocking sets. We present characterization results on minihypers, leading to equivalent characterization results on linear codes meeting the Griesmer bound. Next to being interesting from a coding-theoretical point of view, minihypers also are interesting for geometrical applications. We present results on maximal partial µ-spreads in P G(N, q), (µ + 1)|(N + 1), on minimal µ-covers in P G(N, q), (µ + 1)|(N + 1), on (N − 1)-covers of Q <sup>+</sup>(2N + 1, q), on partial ovoids and on partial spreads of finite classical polar spaces, and on partial ovoids of generalized hexagons, following from results on minihypers.

### 1 Introduction

#### 1.1 The Griesmer bound

A linear [n, k, d] code C over the finite field F<sup>q</sup> of order q is a k-dimensional subspace of the n-dimensional vector space V (n, q) of vectors of length n over Fq. The minimum distance d of the code C is the minimal number of positions in which two distinct codewords of C differ.

Between the parameters n, k, d of a linear [n, k, d] code C, many relations and bounds exist. One of these bounds is the Griesmer bound.

Namely, from an economical point of view, it is interesting to use linear codes having a minimal length n for given k, d and q. The Griesmer bound states that if there exists an [n, k, d] code for given values of k, d and q, then

$$n \ge \sum_{i=0}^{k-1} \left\lceil \frac{d}{q^i} \right\rceil = g_q(k, d),$$

where dxe denotes the smallest integer greater than or equal to x [13, 25].

<sup>∗</sup>The author thanks the Fund for Scientific Research - Flanders (Belgium) for a Research Grant.

Considering this lower bound on the length n for given values k, d and q, the question arises whether there exists a linear [n, k, d] code whose length n is equal to the lower bound  $g_q(k, d)$ . For some parameters k, d and q, there effectively exist linear codes with length equal to  $g_q(k, d)$ ; for other parameters k, d and q, no such linear codes of length  $g_q(k, d)$  exist.

#### 1.2 Minihypers

This coding-theoretical problem of linear codes meeting the Griesmer bound has been studied in great detail, using various kinds of techniques. One of these techniques translates the problem of linear codes meeting the Griesmer bound into a geometrical problem on *minihypers in finite projective spaces*.

Let PG(N,q) be the N-dimensional projective space over the finite field of order q. Let  $v_{N+1} = (q^{N+1}-1)/(q-1)$  denote the number of points of PG(N,q).

We will now present the definition of a minihyper, not having weighted points. This definition will then be generalized to *weighted minihypers* in Definition 4.1.

**Definition 1.1** (Hamada and Tamari [19]) Let F be a set of f points in PG(N,q), where  $N \geq 2$  and  $f \geq 1$ . If  $|F \cap H| \geq m$  for every hyperplane H in PG(N,q) and  $|F \cap H| = m$  for some hyperplane H in PG(N,q), then F is called an  $\{f, m; N, q\}$ -minihyper.

This definition shows in fact that an  $\{f, m; N, q\}$ -minihyper is an m-fold blocking set with respect to hyperplanes. This link with (multiple) blocking sets is very important in obtaining characterization results on minihypers, as will follow when describing proofs of characterization results on minihypers. But before presenting these results, we describe the link between minihypers and linear codes meeting the Griesmer bound.

To describe this link as easily as possible, we first restrict ourselves to linear [n, k, d] codes, over  $\mathbb{F}_q$ , with  $d < q^{k-1}$ . Linear [n, k, d] codes over  $\mathbb{F}_q$  for which  $d \ge q^{k-1}$  will be discussed in Section 4.

For  $1 \leq d < q^{k-1}$ , d can be written uniquely as  $d = q^{k-1} - \sum_{i=1}^{h} q^{\lambda_i}$  such that:

- (a)  $0 < \lambda_1 < \dots < \lambda_h < k 1$ ,
- (b) at most q-1 of the values  $\lambda_i$  are equal to a given value.

Using this expression for d, the Griesmer bound for a linear [n, k, d] code over  $\mathbb{F}_q$  can be expressed as:

$$n \ge v_k - \sum_{i=1}^h v_{\lambda_i + 1}.$$

Hamada showed that in the case  $d = q^{k-1} - \sum_{i=1}^{h} q^{\lambda_i}$ , there is a one-to-one correspondence between the set of all non-equivalent [n, k, d] codes meeting the

Griesmer bound and the set of all projectively distinct  $\{\sum_{i=1}^h v_{\lambda_i+1}, \sum_{i=1}^h v_{\lambda_i}; k-1, q\}$ -minihypers [14]. More precisely, the link is described in the following way.

Let  $G = (g_1 \cdots g_n)$  be a generator matrix for a linear [n, k, d] code C,  $d < q^{k-1}$ , meeting the Griesmer bound. Then the set  $PG(k-1,q) \setminus \{g_1, \ldots, g_n\}$  is the minihyper linked to the code C meeting the Griesmer bound.

![](_page_2_Figure_2.jpeg)

Figure 1: The minihyper

#### 1.3 The Belov, Logachev and Sandimirov construction

Now the question arises how to construct linear codes meeting the Griesmer bound. The standard construction method is of Belov, Logachev and Sandimirov [1]. This construction method is easily described by using the corresponding minihypers.

Consider in PG(k-1,q) a union of pairwise disjoint

- (0)  $\epsilon_0$  points,
- (1)  $\epsilon_1$  lines,

. . . ,

(k-2)  $\epsilon_{k-2}$  (k-2)-dimensional subspaces,

with 
$$0 \le \epsilon_i \le q-1, i=0,\ldots,k-2$$
.  
Then such a set defines a  $\{\sum_{i=0}^{k-2} \epsilon_i v_{i+1}, \sum_{i=0}^{k-2} \epsilon_i v_i; k-1, q\}$ -minihyper.

**Proof:** An *i*-dimensional space PG(i,q) of PG(k-1,q) intersects every hyperplane in at least an (i-1)-dimensional space. Hence, the above defined set of pairwise disjoint subspaces intersects every hyperplane in at least  $\sum_{i=0}^{k-2} \epsilon_i v_i$  points.

The following figure illustrates this for a minihyper consisting of a number of pairwise disjoint planes  $PG(2,q)_1, PG(2,q)_2, \ldots, PG(2,q)_{\epsilon_2}$ , lines  $L_1, L_2, \ldots, L_{\epsilon_1}$ , and points  $p_1, p_2, \ldots, p_{\epsilon_0}$ . The  $\epsilon_2$  planes  $PG(2,q)_1, PG(2,q)_2, \ldots$ , intersect a hyperplane PG(k-2,q) in at least a line, the  $\epsilon_1$  lines  $L_1, L_2, \ldots$ , intersect this hyperplane in at least a point; thus leading to at least  $\epsilon_2(q+1) + \epsilon_1$  intersection points.

![](_page_3_Figure_4.jpeg)

Figure 2: Minihyper of Belov-Logachev-Sandimirov type

# 2 Characterization results of Hamada, Helleseth, and Maekawa

So finding linear [n, k, d] codes,  $d < q^{k-1}$ , meeting the Griesmer bound, and classifying them in the case of existence, is equivalent to finding and classifying the corresponding minihypers. Deep results for general values of k, d and q

were obtained in [16, 18] by Hamada, Helleseth, and Maekawa, who found the following characterization for minihypers in finite projective spaces.

**Theorem 2.1** (Hamada and Helleseth [16], Hamada and Maekawa [18]) Let q, k and  $\epsilon_i \geq 0, i = 0, \ldots, k-2$ , be any integers such that  $k \geq 3, q > (h-1)^2$  with  $h = \sum_{i=0}^{k-2} \epsilon_i$ .

Then F is a  $\{\sum_{i=0}^{k-2} \epsilon_i v_{i+1}, \sum_{i=0}^{k-2} \epsilon_i v_i; k-1, q\}$ -minihyper if and only if F is a union of pairwise disjoint

- (0)  $\epsilon_0$  points,
- (1)  $\epsilon_1$  lines,

...,

(k-2)  $\epsilon_{k-2}$  (k-2)-dimensional subspaces.

In other words, these latter minihypers are of Belov, Logachev and Sandimirov type.

**Proof:** These results were obtained in two steps. In a first article [16], Hamada and Helleseth characterized the  $\{\epsilon_1(q+1)+\epsilon_0,\epsilon_1;k-1,q\}$ -minihypers,  $\epsilon_0+\epsilon_1<\sqrt{q}+1$ , as consisting of  $\epsilon_1$  lines and  $\epsilon_0$  points which are pairwise disjoint. They found these latter  $\epsilon_1$  lines by using counting arguments. In this first article, they also considered  $\{\epsilon_2v_3+\epsilon_1v_2+\epsilon_0,\epsilon_2v_2+\epsilon_1v_1;k-1,q\}$ -minihypers.

In the second article, of Hamada and Maekawa [18], the other minihypers were characterized. This was done by induction on the maximal i for which  $\epsilon_i > 0$ . By using the induction hypothesis for i = 1, 2, the minihypers for which  $\epsilon_i > 0$ , for some i > 2, could be reconstructed via geometrical arguments.  $\square$ 

## 3 Improvements including a new type of objects

A very nice feature of the results of Hamada, Helleseth and Maekawa is that their condition  $\sum_{i=0}^{k-2} \epsilon_i < \sqrt{q} + 1$  on  $\sum_{i=0}^{k-2} \epsilon_i$  is sharp. Namely, let  $\sum_{i=0}^{k-2} \epsilon_i = \sqrt{q} + 1$ , then a completely new type of minihyper appears.

Consider a Baer subgeometry  $PG(2t+1,\sqrt{q})$  in PG(k-1,q), q square. Such a Baer subgeometry is a  $\{(\sqrt{q}+1)v_{t+1},(\sqrt{q}+1)v_t;k-1,q\}$ -minihyper, with  $\sum_{i=0}^{k-2}\epsilon_i=\epsilon_t=\sqrt{q}+1$ . Similarly, a Baer subgeometry  $PG(2t,\sqrt{q})$  in PG(k-1,q), q square, is a  $\{v_{t+1}+\sqrt{q}v_t,v_t+\sqrt{q}v_{t-1};k-1,q\}$ -minihyper, with  $\epsilon_t+\epsilon_{t-1}=\sqrt{q}+1$ .

These two Baer subgeometries are not minihypers of Belov, Logachev and Sandimirov type. This means that if the results of Theorem 2.1 will have to be improved, two different types of minihypers will have to be obtained; minihypers with Baer subgeometries and minihypers without Baer subgeometries.

The following improvements to the results of Theorem 2.1 were obtained by Ferret and Storme [6].

**Theorem 3.1** (Ferret and Storme [6]) Let F be a  $\{\sum_{i=0}^{k-2} \epsilon_i v_{i+1}, \sum_{i=0}^{k-2} \epsilon_i v_i; k-1, q\}$ -minihyper, q square,  $q = p^f$ , f even, p prime, where  $\sum_{i=0}^{k-2} \epsilon_i \leq \min\{2\sqrt{q}-1, c_p q^{5/9}\}$ ,  $c_p = 2^{-1/3}$ ,  $q \geq 2^{14}$ , when p = 2, 3, and where  $\sum_{i=0}^{k-2} \epsilon_i \leq \min\{2\sqrt{q}-1, c_p q^{5/9}\}$  $1, q^{6/9}/(1+q^{1/9})$ ,  $q \ge 2^{12}$ , when p > 3.

Then F consists of the union of pairwise disjoint

- (1)  $\epsilon_{k-2}$  spaces  $PG(k-2, q), \epsilon_{k-3}$  spaces  $PG(k-3, q), \ldots, \epsilon_0$  points, or
- (2) one subgeometry  $PG(2l+1, \sqrt{q})$ , for some integer l with  $1 \le l \le k-2$ ,  $\epsilon_{k-2}$  spaces  $PG(k-2,q),\ldots,\epsilon_{l+1}$  spaces  $PG(l+1,q),\epsilon_l-\sqrt{q}-1$  spaces  $PG(l,q), \epsilon_{l-1}$  spaces  $PG(l-1,q), \ldots, \epsilon_0$  points, or
- (3) one subgeometry  $PG(2l, \sqrt{q})$ , for some integer l with  $1 \le l \le k-2$ ,  $\epsilon_{k-2}$ spaces  $PG(k-2,q), \ldots, \epsilon_{l+1}$  spaces  $PG(l+1,q), \epsilon_l-1$  spaces  $PG(l,q), \epsilon_{l-1}-1$  $\sqrt{q}$  spaces  $PG(l-1,q), \epsilon_{l-2}$  spaces  $PG(l-2,q), \ldots, \epsilon_0$  points.

**Theorem 3.2** (Ferret and Storme [6]) Let F be a  $\{\sum_{i=0}^{k-2} \epsilon_i v_{i+1}, \sum_{i=0}^{k-2} \epsilon_i v_i; k-1\}$ 

- 1, q}-minihyper,  $k \geq 3$ , where
  (1)  $\sum_{i=0}^{k-2} \epsilon_i \leq q^{6/9}/(1+q^{1/9})$ ,  $q=p^f$ , f odd, p prime, p>3,  $q\geq 661$ ,
  (2)  $\sum_{i=0}^{k-2} \epsilon_i \leq c_p q^{5/9}$ ,  $q=p^f$ , f odd, p=2,3, q>7687,  $c_p=2^{-1/3}$ . Then F is the union of pairwise disjoint
  - (0)  $\epsilon_0$  points.
  - (1)  $\epsilon_1$  lines,

. . . ,

(k-2)  $\epsilon_{k-2}$  spaces PG(k-2,q).

The results of Theorem 3.1 were obtained by using results on (multiple) blocking sets in the Desarguesian plane PG(2,q). So, here, the close link between minihypers and the deeply studied (multiple) blocking sets in finite projective spaces, mentioned in the introduction, arises for the first time.

**Definition 3.3** A t-fold blocking set B in PG(2,q) is a set of points such that any line of PG(2,q) contains at least t points of B. A t-fold blocking set is said to be minimal if it has no proper subset that is still a t-fold blocking set.

A t-fold blocking set B in PG(2,q), with t>1, is also called a multiple blocking set of PG(2,q).

Many results on t-fold blocking sets in PG(2,q) are known. We mention the following result of Blokhuis, Storme and Szőnyi [2].

Theorem 3.4 (Blokhuis, Storme, and Szőnyi [2]) Let B be a t-fold blocking set in PG(2,q),  $q = p^f$ , p prime, of size t(q+1) + c. Let  $c_2 = c_3 = 2^{-1/3}$  and  $c_p = 1 \text{ for } p > 3.$ 

- (1) If  $q = p^{2d+1}$  and  $t < q/2 c_p q^{2/3}/2$ , then  $c \ge c_p q^{2/3}$ , unless t = 1 in which case B, with  $|B| < q + 1 + c_p q^{2/3}$ , contains a line. (2) If 4 < q is a square,  $t < q^{1/4}/2$  and  $c < c_p q^{2/3}$ , then  $c \ge t\sqrt{q}$  and B contains
- (2) If 4 < q is a square,  $t < q^{1/4}/2$  and  $c < c_p q^{2/3}$ , then  $c \ge t\sqrt{q}$  and B contains the union of t pairwise disjoint Baer subplanes, except for t = 1 in which case B contains a line or a Baer subplane. If  $t \ge 2$ , necessarily  $t < c_p q^{1/6}$ .
- (3) If  $q = p^2$ , p prime, and  $t < q^{1/4}/2$  and  $c , then <math>c \ge t\sqrt{q}$  and B contains the union of t pairwise disjoint Baer subplanes, except for t = 1 in which case B contains a line or a Baer subplane.

**Proof of Theorem 3.1.** First of all, the  $\{\epsilon_1(q+1) + \epsilon_0, \epsilon_1; 3, q\}$ -minihypers F were characterized. The results of Theorem 3.4, together with other characterization results on multiple blocking sets in PG(2,q), were used to prove that a plane intersects F in less than  $2\sqrt{q}$  points, or in a 1-fold blocking set containing at most  $q + 2\sqrt{q}$  points. In the latter case, this plane contains a line or a Baer subplane, also contained in F.

Three different cases then needed to be distinguished: (1) no Baer subplane is contained in F, (2) exactly one Baer subplane is contained in F, or (3) at least two Baer subplanes are contained in F. In the third case, it was shown that these two Baer subplanes defined a subgeometry  $PG(3, \sqrt{q})$  completely contained in F. Counting arguments then led to the other lines contained in F.

In a second step, the  $\{\epsilon_1(q+1) + \epsilon_0, \epsilon_1; k-1, q\}$ -minihypers F, with k > 4, were characterized, by induction on the dimension k-1. For such a minihyper, hyperplanes intersect F in  $\{m_1(q+1) + m_0, m_1; k-2, q\}$ -minihypers, with  $m_1 + m_0 \le \epsilon_1 + \epsilon_0$  [15, 16]. These latter hyperplane intersections are characterized by the induction hypothesis. We again distinguish between the three cases mentioned in the preceding paragraph, and this leads via geometrical arguments to the construction of the subgeometry  $PG(3, \sqrt{q})$  of the third case, and via counting arguments to the determination of the lines contained in the minihyper.

In a third step, the  $\{\epsilon_2 v_3 + \epsilon_1 v_2 + \epsilon_0, \epsilon_2 v_2 + \epsilon_1; k-1, q\}$ -minihypers F were characterized. We started from a (k-3)-dimensional subspace  $\Delta$  of PG(k-1,q) intersecting F in  $\epsilon_2$  points. Then it follows from [16, Theorem A.3] that every hyperplane  $\pi_i, i=0,\ldots,q$ , through  $\Delta$  intersects F in a  $\{\epsilon_2(q+1)+\epsilon_1+\delta_i,\epsilon_2; k-2,q\}$ -minihyper, where  $\sum_{i=0}^q \delta_i = \epsilon_0$ . Again, these hyperplane intersections  $\pi_i \cap F$  are characterized by the preceding arguments, and contain either: (1)  $\epsilon_2$  lines, (2)  $\epsilon_2 - 1$  lines and one Baer subplane, or (3)  $\epsilon_2 - \sqrt{q} - 1$  lines and one subgeometry  $PG(3,\sqrt{q})$ .

If for at least two hyperplanes, for instance  $\pi_0$  and  $\pi_1$ , the third possibility occurs, then we proved that these two subgeometries  $PG(3, \sqrt{q})$  intersect  $\Delta$  in the same subline  $PG(1, \sqrt{q})$ , and that they define a subgeometry  $PG(5, \sqrt{q})$  completely contained in F, and that F contains  $\epsilon_2 - \sqrt{q} - 1$  planes. This then made it possible to prove that F also contains  $\epsilon_1$  lines and  $\epsilon_0$  points, which completely described F.

This is illustrated by the following figure, which shows that the subgeometries  $\pi_{0,j} = PG(3, \sqrt{q})$  of F in  $\pi_0$  and  $\pi_{1,j} = PG(3, \sqrt{q})$  of F in  $\pi_1$  define a subgeometry  $\Omega_j = PG(5, \sqrt{q})$  contained in F, and which also shows that a line  $L_{0,i}$  of F in  $\pi_0$  and a line  $L_{1,i}$  of F in  $\pi_1$ , containing the same point of  $\Delta$ , define a plane  $PG(2,q)_i$  contained in F.

![](_page_7_Picture_1.jpeg)

Figure 3: Reconstructing the minihyper F via the hyperplanes through  $\Delta$ 

Similar arguments led to the complete characterization of F in the other cases.

An inductive argument on the maximal integer i, for which  $\epsilon_i > 0$ , then characterized all the remaining minihypers of Theorem 3.1. First of all, a (k-3)-dimensional space  $\Delta$  is considered, intersecting F in  $\sum_{i=0}^{k-2} \epsilon_i v_{i-1}$  points. Then all hyperplanes  $\pi_i$ ,  $i=0,\ldots,q$ , through  $\Delta$  intersect F in  $\sum_{i=0}^{k-2} \epsilon_i v_i + \delta_i$  points, with  $\sum_{i=0}^q \delta_i = \epsilon_0$ , forming a  $\{\sum_{i=0}^{k-2} \epsilon_i v_i + \delta_i, \sum_{i=0}^{k-2} \epsilon_i v_{i-1}; k-2, q\}$ -minihyper [16, Theorem A.3]. Since by the induction hypothesis, these latter hyperplane intersections are characterized, it is possible to reconstruct F completely.  $\square$ 

## 4 A particular class of minihypers

The fact that, in Theorem 3.1, two different types of minihypers appear, makes the characterization of minihypers more difficult. There is however one particular type of minihypers for which a very particular extra argument can be used. This latter extra argument made it possible to obtain stronger characterizations.

Since in the theorems on this particular class of minihypers, the points may have a certain positive weight, we first present the definition of weighted minihyper(F, w) which generalizes Definition 1.1.

#### 4.1 Weighted minihypers

**Definition 4.1** (Hamada and Tamari [19])  $An \{f, m; N, q\}$ -minihyper is a pair (F, w), where F is a subset of the point set of PG(N, q) and where w is a weight function  $w: PG(N,q) \to \mathbb{N}: x \mapsto w(x)$ , satisfying

- (1)  $w(x) > 0 \Leftrightarrow x \in F$ ,
- (2)  $\sum_{x \in F} w(x) = f$ , and (3)  $\min(|F \cap H| = \sum_{x \in H} w(x)||H \in \mathcal{H}) = m$ ; where  $\mathcal{H}$  denotes the set of hyperplanes of PG(N,q).

In the case that w is a mapping onto  $\{0,1\}$ , the minimizer (F,w) can be identified with the set F and is simply denoted by F.

The excess e of a minihyper (F, w) is the number  $\sum_{x \in F} (w(x) - 1)$ .

The link between these weighted minippers (F, w) and linear codes meeting the Griesmer bound is as follows.

Suppose that there exists a linear [n, k, d] code meeting the Griesmer bound  $(d \ge 1, k \ge 3)$ , then we can write d in an unique way as  $d = \theta q^{k-1} - \sum_{i=0}^{k-2} \epsilon_i q^i$ such that  $\theta \geq 1$  and  $0 \leq \epsilon_i < q$ .

Using this expression for d, the Griesmer bound for an [n,k,d] code can be expressed as:  $n \ge \theta v_k - \sum_{i=0}^{k-2} \epsilon_i v_{i+1}$ .

From now on, we suppose that  $0 \le \epsilon_0, \ldots, \epsilon_{k-2} \le q-1$ .

Hamada and Helleseth [17] showed that there is a one-to-one correspondence between the set of all non-equivalent [n, k, d] codes meeting the Griesmer bound and the set of all projectively distinct  $\{\sum_{i=0}^{k-2} \epsilon_i v_{i+1}, \sum_{i=0}^{k-2} \epsilon_i v_i; k-1, q\}$ minihypers (F, w), such that  $1 \leq w(p) \leq \theta$  for every point  $p \in F$ . More precisely, the link is described in the following way.

Let  $G = (g_1 \cdots g_n)$  be a generator matrix for a linear [n, k, d] code, meeting the Griesmer bound. We look at a column of G as being the coordinates of a point in PG(k-1,q). Let the point set of PG(k-1,q) be  $\{s_1,\ldots,s_{v_k}\}$ . Let  $m_i(G)$  denote the number of columns in G defining  $s_i$ . Let  $\theta = \max\{m_i(G)||i=1\}$  $\{1,2,\ldots,v_k\}$ . Define the weight function  $w:PG(k-1,q)\to\mathbb{N}$  as  $w(s_i)=1$  $\theta - m_i(G)$ ,  $i = 1, 2, ..., v_k$ . Let  $F = \{s_i \in PG(k-1, q) | |w(s_i) > 0\}$ , then (F, w) is a  $\{\sum_{i=0}^{k-2} \epsilon_i v_{i+1}, \sum_{i=0}^{k-2} \epsilon_i v_{i}; k-1, q\}$ -minihyper.

The construction of Belov, Logachev and Sandimirov can be generalized in the following way to weighted minihypers.

Consider a number of geometrical objects, such as:

(1) subspaces  $PG(d, q = p^h)$  of  $PG(k - 1, q = p^h)$ .

- (2) subgeometries  $PG(d, p^t)$  of  $PG(k-1, q=p^h)$ , where t|h, and
- (3) projected subgeometries  $PG(d, p^t)$  in  $PG(k-1, q=p^h)$ , where t|h.

In the first two cases, a point of PG(d,q) or  $PG(d,p^t)$  has respectively weight one, while all the other points not belonging to respectively PG(d,q) or  $PG(d,p^t)$  have weight zero. In the latter case, let  $\Pi$  be a projected  $PG(d,p^t)$  in  $PG(k-1,q=p^h)$ . The weight of a point  $s \in \Pi$  is the number of points s' of  $PG(d,p^t)$  that are projected onto s; all other points s of  $PG(k-1,q) \setminus \Pi$  have weight zero.

For instance, when one projects a subgeometry  $PG(k-1,\sqrt{q})$  of PG(k-1,q) from a point r onto a hyperplane PG(k-2,q), then r belongs to exactly one line intersecting this subgeometry  $PG(k-1,\sqrt{q})$  in a Baer subline. The points of this latter Baer subline all are projected onto the same point r'. So, using the definition of weight above, this projected subgeometry  $PG(k-1,\sqrt{q})$  has one point r' of weight  $\sqrt{q}+1$  and all the other points of this projected subgeometry have weight one. This is illustrated by the following figure, where  $q_0=\sqrt{q}$ .

![](_page_9_Figure_4.jpeg)

Figure 4: a projected subgeometry  $PG(k-1,\sqrt{q})$ 

Then the sum of these subspaces and (projected) subgeometries is the weighted set (F, w), where the weight w(s) of a point s of (F, w) is the sum of all the weights of s in the subspaces and (projected) subgeometries of (F, w).

This is illustrated by the following figure. Similarly to Figure 2, we again consider a minihyper consisting of points, lines and planes, but in contrast to Figure 2, where the planes and the lines of the minihyper were pairwise disjoint, the planes and/or lines can now intersect each other.

![](_page_10_Picture_1.jpeg)

Figure 5: a weighted minihyper

**Remark 4.2** Sometimes, we will intersect the minihyper (F, w) with a set of points (for example, a plane)  $\pi$ , and briefly write  $(F, w) \cap \pi$ . With this, we mean the point set  $F \cap \pi$  with as weight function the restriction of w to the point set of  $\pi$ .

In Theorems 4.8 and 4.9, we will consider projected  $(\Omega, w) = PG(5, p)$  in  $PG(3, p^3)$  containing a line N. With the notation  $(\Omega, w) \setminus N$ , we mean the weighted set obtained from  $(\Omega, w)$  by reducing the weight of every point of N by one.

#### 4.2 The particular class of minihypers

The class of minihypers we wish to discuss is the class of  $\{\delta v_{\mu+1}, \delta v_{\mu}; k-1, q\}$ -minihypers (F, w). The main motivation for studying this class arises from its many applications in geometry (see Section 5).

We first repeat three known geometrical objects leading to  $\{\delta v_{\mu+1}, \delta v_{\mu}; k-1, q\}$ -minihypers (F, w):

(1)  $\delta$  subspaces  $PG(\mu, q)$ ,

- (2) a (projected) subgeometry  $PG(2\mu+1, \sqrt{q})$  in PG(k-1, q), q square, defines a  $\{\delta v_{\mu+1}, \delta v_{\mu}; k-1, q\}$ -minihyper, with  $\delta = \sqrt{q} + 1$ ,
- (3) a (projected) subgeometry  $PG(3\mu+2,p)$  in  $PG(k-1,q=p^3)$  defines a  $\{\delta v_{\mu+1}, \delta v_{\mu}; k-1, q\}$ -minihyper, with  $\delta=p^2+p+1$ .

The main goal is to characterize  $\{\delta v_{\mu+1}, \delta v_{\mu}; k-1, q\}$ -minihypers (F, w), involving these three above mentioned examples. The reason why a characterization result involving these three examples was desired, follows again from the link of minihypers with blocking sets. Presently, the following characterization results on the smallest minimal blocking sets in  $PG(2, p^3)$  are known.

**Theorem 4.3** (Polverino, Polverino and Storme [22, 23, 24]) The smallest minimal blocking sets in  $PG(2, p^3)$ ,  $p = p_0^h$ ,  $p_0$  prime,  $p_0 \ge 7$ ,  $h \ge 1$ , are:

- (1) a line,
- (2) a Baer subplane of cardinality  $p^3 + p^{3/2} + 1$ , when p is a square,
- (3) a set of cardinality  $p^3 + p^2 + 1$ , equivalent to

$$\{(x, T(x), 1) | | x \in \mathbb{F}_{n^3} \} \cup \{(x, T(x), 0) | | x \in \mathbb{F}_{n^3} \setminus \{0\} \},$$

with  $T: \mathbb{F}_{p^3} \to \mathbb{F}_p: x \mapsto x + x^p + x^{p^2}$ , (4) a set of cardinality  $p^3 + p^2 + p + 1$ , equivalent to

$$\{(x, x^p, 1)||x \in \mathbb{F}_{p^3}\} \cup \{(x, x^p, 0)||x \in \mathbb{F}_{p^3} \setminus \{0\}\}.$$

**Remark 4.4** The two latter blocking sets of Theorem 4.3 are also characterized [20] as being a projected subgeometry PG(3,p) in the plane  $PG(2,p^3)$ . Namely, embed the plane  $PG(2,p^3)$  in a 3-dimensional space  $PG(3,p^3)$ . Consider a subgeometry PG(3,p) of  $PG(3,p^3)$  and a point r not belonging to this subgeometry PG(3,p) and not belonging to the plane  $PG(2,p^3)$ .

Project PG(3, p) from r onto  $PG(2, p^3)$ .

If the point r belongs to a line of the subgeometry PG(3,p), then this PG(3,p) is projected onto the blocking set of size  $p^3 + p^2 + 1$ ; else we obtain the blocking set of size  $p^3 + p^2 + p + 1$ . This is illustrated in Figure 6, where we have considered the case that r belongs to a line of the subgeometry PG(3,p). The subline of the subgeometry PG(3,p) which passes through r is projected from r onto the point r'; this point r' lies on p+1 distinct lines containing  $p^2+1$  points of the projected PG(3,p).

![](_page_12_Figure_0.jpeg)

Figure 6: A projected PG(3, p) in  $PG(2, p^3)$ 

The fact that these two latter blocking sets are projected subgeometries PG(3,p) explains why projected subgeometries  $PG(3\mu + 2,p)$  appear in the characterization results of Theorems 4.8, 4.9, and 4.10.

We also rely on the following theorem.

**Theorem 4.5** In  $PG(2, p^3)$ ,  $p = p_0^h$ ,  $p_0$  prime,  $p_0 \ge 7$ ,  $h \ge 1$ , every blocking set B of size at most  $p^3 + 2p^2 - 4p$  contains a minimal blocking set of one of the types described in Theorem 4.3.

The following theorem is on weighted  $\{\delta v_{\mu+1}, \delta v_{\mu}; N, q\}$ -minihypers (F, w) with no restrictions on the weight function w. Further results on these minihypers, with restrictions on the weight function w, will be presented in the next subsection.

**Theorem 4.6** (Govaerts and Storme [10]) Let q > 2 and  $\delta < \epsilon$ , where  $q + \epsilon$  is the size of the smallest blocking sets, not containing a line, in PG(2,q). If (F,w) is a  $\{\delta v_{\mu+1}, \delta v_{\mu}; N, q\}$ -minihyper satisfying  $\mu \leq N-1$ , then w is the weight function induced on the points of PG(N,q) by a sum of  $\delta$  subspaces  $PG(\mu,q)$ .

#### 4.3 A particular argument

We now describe the arguments characterizing these  $\{\delta v_{\mu+1}, \delta v_{\mu}; k-1, p^3\}$ -minihypers of Theorems 4.8, 4.9, and 4.10. In Theorem 4.8, the excess of these minihypers is upper bounded by  $e \leq p^3$ , in Theorem 4.9 by  $e \leq p^3 - 4p$ , and in Theorem 4.10 by  $e \leq p^2 + p$ .

The key result that is used to study this particular class of minihypers states a particular property of the points of weight one of a  $\{\delta(q+1), \delta; 3, q\}$ -minihyper (F, w).

In the following result, we rely on the property that a plane  $\pi$  intersects a  $\{\delta(q+1), \delta; 3, q\}$ -minihyper (F, w), with  $\delta \leq (q+1)/2$ , in a weighted  $\{m_1(q+1)+m_0, m_1; 2, q\}$ -minihyper  $(F, w) \cap \pi$ , with  $m_0+m_1=\delta$  [15, 16]. The number  $m_1$  appearing in the description of the  $\{m_1(q+1)+m_0, m_1; 2, q\}$ -minihyper  $(F, w) \cap \pi$  is also denoted by  $m_1(\pi)$ .

In the following lemma, we describe the quotient geometry of a point r of PG(3,q) by using a plane  $\pi_r$  not passing through r.

**Lemma 4.7** (Govaerts and Storme [11]) For a point r of weight one of the weighted  $\{\delta(q+1), \delta; 3, q\}$ -minihyper (F, w),  $\delta \leq (q+1)/2$ , the planes through r for which  $m_1(\pi) > 0$  form a weighted dual blocking set  $B_r^D$ , in the quotient geometry  $\pi_r$  of r, of cardinality  $q + \delta$ .

In Theorems 4.8, 4.9, and 4.10, we impose the upper bound  $\delta \leq 2p^2 - 4p$ . Theorem 4.5 then implies that this dual blocking set of planes through r for which  $m_1(\pi) > 0$  contains the dual of one of the minimal blocking sets described in Theorem 4.3.

The first possibility of Theorem 4.3 leads to lines contained in the  $\{\delta(q+1), \delta; 3, p^3\}$ -minihyper (F, w). We discuss the second possibility more in detail.

The preceding lemma, in combination with Theorem 4.3 (2), implies that there is a Baer subplane  $\pi_0$  in the quotient geometry  $\pi_r$  of r such that all planes  $\pi = \langle r, L \rangle$ , with L a line of  $\pi_0$ , satisfy  $m_1(\pi) > 0$ .

Practically all these planes  $\pi$  intersect F in a 1-fold blocking set of size at most  $p^3+2p^2-4p$ . So, Theorem 4.5 again implies that these latter intersections  $(F,w)\cap\pi$  must contain one of the minimal blocking sets described in Theorem 4.3. It is shown that this minimal blocking set must be a Baer subplane, and that this latter Baer subplane is completely contained in the Baer cone  $\langle r,\pi_0\rangle$  with vertex r and base  $\pi_0$ . This then makes it possible to prove that these Baer subplanes, contained in (F,w), define a Baer subgeometry  $PG(3,\sqrt{q})$ , completely contained in (F,w).

This is illustrated by the next figure. This figure shows the quotient geometry of the point r, represented by the plane  $\pi_r$ , the Baer subplane  $\pi_0$  in the dual blocking set of planes  $\pi$  through r for which  $m_1(\pi) > 0$ . We also selected a line L of  $\pi_0$  for which the plane  $\langle r, L \rangle$  intersects F in a 1-fold blocking set B. As indicated in the preceding paragraph, B contains a Baer subplane  $\pi_{L,r}$ , and this latter Baer subplane  $\pi_{L,r}$  lies completely in the cone with vertex r and base  $\pi_0$ . The Baer subgeometry  $PG(3, \sqrt{q})$  of F through r is denoted by  $PG(3, q_0)$ .

![](_page_14_Figure_0.jpeg)

Figure 7: Dual blocking set argument

The two final possibilities are that the dual blocking set of planes  $\pi$  through r for which  $m_1(\pi) > 0$  contains a dual minimal blocking set of the type described in parts (3) and (4) of Theorem 4.3. These possibilities lead to projected subgeometries PG(5,p) contained in (F,w), or to projected PG(5,p), minus a line N, contained in (F,w).

These results are summarized in the next theorem; in this theorem, the total excess of the points of (F,w) is limited to  $e \leq p^3$ . In the theorems that follow, we use the notations  $L, L^p, L^{p^2}$  for a line L of  $PG(5,p^3)$  skew to a subgeometry PG(5,p) of  $PG(5,p^3)$ , and its two conjugate lines with respect to this subgeometry PG(5,p). If we project a subgeometry PG(5,p) of  $PG(5,p^3)$  from a line L skew to this subgeometry PG(5,p) satisfying  $\dim \langle L, L^p, L^{p^2} \rangle = 3$ , then the projection  $\Omega$  of this subgeometry PG(5,p) from this line L onto a solid  $PG(3,p^3)$  contains a line of  $PG(3,p^3)$ . We denote this latter line by N.

**Theorem 4.8** (Ferret and Storme [8]) A { $\delta(p^3+1), \delta; 3, p^3$ }-minihyper,  $p=p_0^h$ ,  $p_0$  prime,  $h \ge 1$ ,  $p_0 \ge 7$ ,  $p \ge 11$ ,  $\delta \le 2p^2-4p$ , and with excess  $e \le p^3$ , is either: (1) a sum of lines, (projected)  $PG(3, p^{3/2})$ , and of at most one projected PG(5, p) projected from a line L for which  $\dim \langle L, L^p, L^{p^2} \rangle \ge 3$ ,

(2) a sum of lines, (projected)  $PG(3, p^{3/2})$ , and of a  $\{(p^2 + p)(p^3 + 1), p^2 + p; 3, p^3\}$ -minihyper  $(\Omega, w) \setminus N$ , where  $\Omega$  is a PG(5, p) projected from a line L for which  $\dim \langle L, L^p, L^{p^2} \rangle = 3$ , and where N is the line contained in  $\Omega$ .

Using projection arguments and induction on the dimension k-1, the preceding theorem on minihypers in  $PG(3, p^3)$  is now generalized to minihypers in  $PG(k-1, p^3)$ , k>4. The total excess of the points of (F, w) is now limited to  $e \leq p^3 - 4p$ .

Namely, we select a point r in  $PG(k-1,p^3)\setminus F$  lying on the smallest possible number of secants to F. Then r projects (F,w) onto a weighted  $\{\delta(p^3+1),\delta;k-2,p^3\}$ -minihyper (F',w'), in a hyperplane  $\Pi$  not passing through r, having total excess  $e \leq p^3$ . By the induction hypothesis, this projected minihyper (F',w') is characterized according to Theorem 4.8 or Theorem 4.9. Geometrical arguments then make it possible to prove that the original minihyper (F,w) also is described as indicated in Theorem 4.9.

**Theorem 4.9** (Ferret and Storme [9]) A  $\{\delta(p^3+1), \delta; k-1, p^3\}$ -minihyper,  $k>4, p=p_0^h, p_0$  prime,  $p_0\geq 7, p\geq 11, \delta\leq 2p^2-4p$ , with total excess  $e\leq p^3-4p$ , is a sum of either:

- (1) lines, (projected)  $PG(3, p^{3/2})$  (where the projection is from a point), and of at most one (projected) PG(5,p),
- (2) lines, (projected)  $PG(3, p^{3/2})$ , and of a  $\{(p^2 + p)(p^3 + 1), p^2 + p; 3, p^3\}$ -minihyper  $(\Omega, w) \setminus N$ , where  $\Omega$  is a PG(5, p) projected from a line L for which  $\dim \langle L, L^p, L^{p^2} \rangle = 3$ , and where N is the line contained in  $\Omega$ .

These two preceding theorems are then used to characterize  $\{\delta v_3, \delta v_2; k-1, p^3\}$ -minihypers,  $\delta \leq 2p^2 - 4p$ ,  $k \geq 4$ ,  $p = p_0^h$ ,  $p \geq 11$ ,  $p_0 \geq 7$  prime, with excess  $e \leq p^2 + p$ .

Consider again Figure 3. As in the proof of Theorem 3.1, we consider a (k-3)-dimensional space  $\Delta$  intersecting (F,w) in  $\delta$  points of weight one. All the hyperplanes  $\pi_i$ ,  $i=0,\ldots,p^3$ , intersect (F,w) in  $\{\delta(p^3+1),\delta;k-2,p^3\}$ -minihypers which are characterized by Theorems 4.8 and 4.9. Such a hyperplane intersection basically consists of lines, subgeometries  $PG(3,p^{3/2})$ , and a (projected) subgeometry PG(5,p) or a projected subgeometry PG(5,p) of which the weights of the points on one line N are reduced by one.

Via geometrical arguments, the lines of (F, w) contained in these hyperplane intersections, intersecting  $\Delta$  in the same point, lead to planes contained in (F, w), the subgeometries  $PG(3, p^{3/2})$ , intersecting  $\Delta$  in the same subline  $PG(1, p^{3/2})$ , to (projected) subgeometries  $PG(5, p^{3/2})$  contained in (F, w), and the (projected) subgeometries PG(5, p) intersect  $\Delta$  in the same set of  $p^2 + p + 1$  points and lead to (projected) subgeometries PG(8, p) contained in (F, w).

Once these minihypers are characterized,  $\{\delta v_{\mu+1}, \delta v_{\mu}; k-1, p^3\}$ -minihypers,  $\mu \geq 3, \ \delta \leq 2p^2 - 4p, \ k \geq 4, \ p = p_0^h, \ p \geq 11, \ p_0 \geq 7$  prime, with excess  $e \leq p^2 + p$ , are characterized by induction on  $\mu$ . We again start from a (k-3)-dimensional space  $PG(k-3, p^3)$  intersecting (F, w) in  $\delta v_{\mu-1}$  points of weight

one. Then all hyperplanes  $\pi_i$ ,  $i=0,\ldots,p^3$ , intersect (F,w) in  $\{\delta v_\mu,\delta v_{\mu-1};k-2,p^3\}$ -minihypers, which are already characterized by induction on  $\mu$ . These latter hyperplane intersections consist of subspaces  $PG(\mu-1,p^3)$ , (projected) subgeometries  $PG(2\mu-1,p^{3/2})$ , and of at most one (projected) subgeometry  $PG(3\mu-1,p)$ . The subspaces  $PG(\mu-1,p^3)$  of (F,w), in the hyperplanes through  $\Delta$ , intersecting  $\Delta$  in the same  $PG(\mu-2,p^3)$  lead to subspaces  $PG(\mu,p^3)$  contained in (F,w), the (projected) subgeometries  $PG(2\mu-1,p^{3/2})$  of (F,w), in the hyperplanes through  $\Delta$ , intersecting  $\Delta$  in the same  $PG(2\mu-3,p^{3/2})$ , lead to (projected) subgeometries  $PG(2\mu+1,p^{3/2})$  contained in (F,w), and the (projected) subgeometries  $PG(3\mu-1,p)$  of (F,w), in the hyperplanes through  $\Delta$ , intersect  $\Delta$  in the same (projected) subgeometry  $PG(3\mu-4,p)$  and lead to a (projected) subgeometry  $PG(3\mu+2,p)$  contained in (F,w). This leads to the following characterization result.

**Theorem 4.10** (Ferret and Storme [9]) A  $\{\delta v_{\mu+1}, \delta v_{\mu}; k-1, p^3\}$ -minihyper,  $\mu \geq 2$ ,  $\delta \leq 2p^2-4p$ ,  $k \geq 4$ ,  $p=p_0^h$ ,  $p \geq 11$ ,  $p_0 \geq 7$  prime, with excess  $e \leq p^2+p$ , is a sum of spaces  $PG(\mu, p^3)$ , (projected) subgeometries  $PG(2\mu+1, p^{3/2})$ , and of at most one (projected) subgeometry  $PG(3\mu+2, p)$ .

#### 5 Geometrical applications of minihypers

As indicated in the introduction, minihypers also are interesting for studying many geometrical problems. We first mention the application of minihypers for the study of maximal partial  $\mu$ -spreads in PG(N,q),  $(\mu+1)|(N+1)$ .

#### 5.1 Applications to partial $\mu$ -spreads in PG(N,q)

**Definition 5.1** A  $\mu$ -spread of PG(N,q) is a set of  $\mu$ -dimensional subspaces which partitions the point set of PG(N,q).

A partial  $\mu$ -spread S of PG(N,q) is a set of mutually skew  $\mu$ -dimensional subspaces of PG(N,q).

We call a partial  $\mu$ -spread maximal if it cannot be extended to a larger (partial)  $\mu$ -spread.

A point of PG(N,q) not contained in an element of the partial  $\mu$ -spread S is called a hole of S.

There exist  $\mu$ -spreads in PG(N,q) if and only if  $(\mu+1)|(N+1)$ .

Suppose that  $(\mu + 1)|(N + 1)$  and that S is a partial  $\mu$ -spread of PG(N,q) of size  $|S| = (q^{N+1} - 1)/(q^{\mu+1} - 1) - \delta$ . We call  $\delta$  the deficiency of S. Then a partial  $\mu$ -spread in PG(N,q) has a set of  $\delta v_{\mu+1}$  holes.

The following lemma links the study of the set of holes of a partial  $\mu$ -spread of PG(N, q) of small deficiency  $\delta < q$  to the study of minihypers.

**Lemma 5.2** (Govaerts and Storme [10]) Suppose that  $(\mu+1)|(N+1)$  and that S is a partial  $\mu$ -spread of PG(N,q) of deficiency  $\delta < q$ . Then the set of holes forms a  $\{\delta v_{\mu+1}, \delta v_{\mu}; N, q\}$ -minihyper, consisting of points of weight one.

Since this class of  $\{\delta v_{\mu+1}, \delta v_{\mu}; N, q\}$ -minihypers was already studied in Section 4, the characterization results of Theorems 4.8, 4.9, and 4.10 imply the following results on maximal partial  $\mu$ -spreads in PG(N, q),  $(\mu + 1)|(N + 1)$ .

- **Theorem 5.3** (1) A maximal partial  $\mu$ -spread in  $PG(N, p^3)$ ,  $(\mu + 1)|(N + 1)$ ,  $p = p_0^h$ ,  $p \ge 11$ ,  $p_0$  prime,  $p_0 \ge 7$ ,  $h \ge 1$  odd, of deficiency  $0 < \delta \le 2p^2 4p$ , has deficiency  $\delta = p^2 + p + 1$ , and the set of holes is a (projected) subgeometry  $PG(3\mu + 2, p)$  in  $PG(N, p^3)$ .
- (2) A maximal partial  $\mu$ -spread in  $PG(N, p^3)$ ,  $(\mu + 1)|(N + 1)$ ,  $p = p_0^h$ ,  $p_0$  prime,  $p_0 \geq 7$ ,  $h \geq 2$  even, of deficiency  $0 < \delta \leq 2p^2 4p$ , has deficiency  $\delta = r(p^{3/2} + 1) + s(p^2 + p + 1)$ , for a non-negative integer r and  $s \in \{0, 1\}$ , and the set of holes is a union of r subgeometries  $PG(2\mu + 1, \sqrt{q})$  and s (projected) subgeometries  $PG(3\mu + 2, p)$  of  $PG(N, p^3)$ , which all are pairwise disjoint.
- For N=3, stronger results have been obtained [7]. Namely, in this case, we also know that this minihyper of holes of the maximal partial 1-spread of PG(3,q) intersects every plane of PG(3,q) in either  $\delta$  or  $q+\delta$  points, which makes the study of these minihypers easier.
- For  $q=p^3$ , p prime,  $p\geq 17$ ,  $\delta_0$  is the largest integer smaller than  $(3p^3+27p^2-5p+25)/25$ . For p=7,11,13,  $\delta_0=90$ ,  $\delta_0=285$  and  $\delta_0=441$  respectively. For  $q=p^3$ ,  $p=p_0^h$ ,  $p_0$  prime,  $p_0\geq 7$ , h>1,  $\delta_0$  is defined as the largest integer smaller than  $(3p^3+27p^2-5p+25)/25$  and smaller than the value  $\delta'$  for which  $p^3+\delta'$  is the cardinality of the smallest minimal blocking set in  $PG(2,p^3)$  of cardinality larger than  $p^3+p^2+p+1$ . Presently, this value is still unknown, but we know that  $\delta'\leq p^3/p_0+1$ .
- **Theorem 5.4** (Ferret and Storme [7]) Let  $p = p_0^h$ ,  $p_0 \ge 7$  a prime,  $h \ge 1$  odd. Then the minihyper corresponding to a maximal partial spread in  $PG(3, p^3)$  of deficiency  $\delta \le \delta_0$ , is the union of pairwise disjoint projected subgeometries PG(5, p) of cardinality  $p^5 + p^4 + p^3 + p^2 + p + 1$ .
- **Theorem 5.5** (Ferret and Storme [7]) Let  $p = p_0^h$ ,  $p_0 \ge 7$  a prime, h > 1 even. Then the minihyper corresponding to a maximal partial spread in  $PG(3, p^3)$  of deficiency  $\delta \le \delta_0$ , is the union of pairwise disjoint subgeometries  $PG(3, p^{3/2})$  and of projected subgeometries PG(5, p) of cardinality  $p^5 + p^4 + p^3 + p^2 + p + 1$ .

**Corollary 5.6** Under the conditions of Theorems 5.4 and 5.5, the deficiency  $\delta$  of a maximal partial spread in  $PG(3, p^3)$  can be written as  $\delta = r(p^{3/2} + 1) + s(p^2 + p + 1)$  for some non-negative integers r and s.

### 5.2 Applications to $\mu$ -covers of PG(N,q)

**Definition 5.7** A  $\mu$ -cover  $\mathcal{C}$  of PG(N,q) is a set of  $\mu$ -dimensional subspaces of PG(N,q) such that any point of PG(N,q) is contained in at least one element of  $\mathcal{C}$ .

If the  $\mu$ -cover  $\mathcal C$  has no proper subset that is still a  $\mu$ -cover, then we call  $\mathcal C$  a minimal  $\mu$ -cover.

The surplus of a point of PG(N,q) is by definition one less than the number of elements of C passing through it, and a multiple point with respect to C is a point with surplus greater than zero.

Now suppose that  $(\mu + 1)|(N + 1)$ . If  $\mathcal{C}$  is a  $\mu$ -cover of PG(N, q) and  $|\mathcal{C}| = (q^{N+1} - 1)/(q^{\mu+1} - 1) + \delta$ , then we say that  $\mathcal{C}$  has  $excess\ \delta$ .

The following theorem links the minihypers that we have studied in the previous section to  $\mu$ -covers in projective spaces where  $\mu$ -spreads exist.

**Theorem 5.8** (Govaerts and Storme [10]) Let C be a  $\mu$ -cover of PG(N,q),  $(\mu+1)|(N+1)$ , with excess  $\delta < q$ . Let F be the set of multiple points of C and let w(r) = surplus(r) for  $r \in PG(N,q)$ . Then (F,w) is a  $\{\delta v_{\mu+1}, \delta v_{\mu}; N, q\}$ -minihyper.

For constructions of minimal  $\mu$ -covers of PG(N,q), where  $(\mu+1)|(N+1)$ , with small excess  $\delta < q$ , we refer to [10].

## 5.3 Applications to partial $\mu$ -spreads of finite classical polar spaces

The thick finite nondegenerate classical polar spaces are:

- W(2N+1,q), the polar space arising from a symplectic polarity of  $PG(2N+1,q), N \ge 1$ ;
- $Q^-(2N+1,q)$ , the polar space arising from a nonsingular elliptic quadric of  $PG(2N+1,q), N \geq 2$ ;
- Q(2N,q), the polar space arising from a nonsingular parabolic quadric of  $PG(2N,q), N \geq 2$ ;
- $Q^+(2N+1,q)$ , the polar space arising from a nonsingular hyperbolic quadric of PG(2N+1,q),  $N \geq 2$ ;
- $H(N,q^2)$ , the polar space arising from a nonsingular Hermitian variety in  $PG(N,q^2), N \geq 3$ .

Let  $\mathcal{P}$  be a finite classical polar space. A  $\mu$ -spread of  $\mathcal{P}$  is a set of totally isotropic or singular  $\mu$ -dimensional subspaces that partitions the point set of  $\mathcal{P}$ . Partial  $\mu$ -spreads, maximal partial  $\mu$ -spreads, holes and deficiency are defined in the same way as for the finite projective spaces.

Suppose that the size of a finite classical polar space admits a  $\mu$ -spread, then the following theorem again links minihypers to partial  $\mu$ -spreads of small deficiency.

**Theorem 5.9** (Govaerts, Storme and Van Maldeghem [12]) Let  $\mathcal{P}$  be a classical nondegenerate polar space in PG(N,q) whose size admits a  $\mu$ -spread. If  $\mathcal{S}$  is a partial  $\mu$ -spread of  $\mathcal{P}$  with deficiency  $\delta < q$ , then the set of holes forms a  $\{\delta v_{\mu+1}, \delta v_{\mu}; N, q\}$ -minihyper F, having points of weight one.

This again implies that the results of Theorems 4.8, 4.9, and 4.10 can be used. We state the results for partial  $\mu$ -spreads of quadrics, with  $\mu$  the dimension of the *generators* of the quadrics. A *generator* of a quadric is a subspace of maximal dimension contained in this quadric. We let  $q=p^3$ , where p satisfies the conditions of Theorems 4.8, 4.9 and 4.10.

Corollary 5.10 Let Q be a nonsingular quadric in  $PG(N, q = p^3)$ , having generators of dimension  $\mu$ .

Then any partial  $\mu$ -spread S of deficiency  $\delta \leq 2p^2 - 4p$  of Q can be extended to a  $\mu$ -spread of Q.

**Proof:** The minihyper F of holes consists of subspaces  $PG(\mu, q)$ , (projected) subgeometries  $PG(2\mu+1, \sqrt{q})$ , when q is a square, and of at most one projected subgeometry  $PG(3\mu+2, p)$ .

In fact, the Baer sublines and Baer subplanes of the subgeometries  $PG(2\mu+1,\sqrt{q})$  in F imply that the subgeometry defines a subspace  $PG(2\mu+1,q)$  contained in F. This is impossible.

Similarly, it is impossible that this (projected) subgeometry  $PG(3\mu + 2, p)$  lies in F. For, the sublines PG(1, p) and subplanes PG(2, p) of this subgeometry  $PG(3\mu + 2, p)$  would define a subspace  $PG(n_0, p^3)$  completely contained in Q, with  $n_0 > \mu$  since  $|PG(3\mu + 2, p)| = (p^2 + p + 1)|PG(\mu, p^3)|$ ; a contradiction.

So, the minihyper F of holes is a union of pairwise disjoint subspaces  $PG(\mu, p^3)$ , extending the partial  $\mu$ -spread to a  $\mu$ -spread.

#### **5.4** Minimal (N-1)-covers of $Q^+(2N+1,q)$

**Definition 5.11** An (N-1)-cover C of a hyperbolic quadric  $Q = Q^+(2N+1,q)$  is a set C of (N-1)-dimensional subspaces contained in Q such that each point of Q is contained in at least one element of C.

Since the size of an (N-1)-dimensional space PG(N-1,q) does not divide the size of the hyperbolic quadric  $Q^+(2N+1,q)$ , it follows that for an (N-1)-cover C, there are some points of  $Q^+(2N+1,q)$  lying on at least two elements of C.

**Definition 5.12** We define the surplus of a point  $r \in \mathcal{Q}$  with respect to an (N-1)-cover  $\mathcal{C}$  to be the number of elements of  $\mathcal{C}$  through r minus one. The surplus of a point of  $PG(2N+1,q) \setminus \mathcal{Q}$  is defined as zero.

A point with positive surplus is called a multiple point.

It is shown in [5] that an (N-1)-cover of  $Q^+(2N+1,q)$  contains at least  $q^{N+1}+2q+1$  spaces PG(N-1,q). Examples of this size exist for q even.

Namely, suppose that q is even. Then there exists a spread S of the parabolic quadric Q(2N+2,q) (see e.g. [3, 26, 27]).

Let  $Q = Q^+(2N+1,q)$  be a hyperplane section of Q(2N+2,q). Then a counting argument shows that Q contains exactly two elements  $U_!$  and  $U_2$  of S

and intersects the other elements of S in (N-1)-dimensional subspaces. These form a partial (N-1)-spread  $C_0$  of  $Q^+(2N+1,q)$  covering all points except the points of  $U_1, U_2$ . Let  $W_i$  be an (N-2)-dimensional subspace of  $U_i$  (i=1,2). If we add to  $C_0$  the q+1 (N-1)-dimensional subspaces in  $U_i$  through  $W_i$ , we get an (N-1)-cover C. From this construction,  $|C| = q^{N+1} + 2q + 1$ . The multiple points of C are the points of  $W_1$  and  $W_2$ , each having surplus q. The following theorem shows that all (N-1)-covers of size  $q^{N+1}+2q+1$  look like this example.

Namely, from [5, Lemma 3.1], it follows that the multiple points of an (N-1)-cover of size  $q^{N+1}+2q+1$  of  $Q^+(2N+1,q)$  have surplus congruent to  $0 \pmod q$ . If we now divide the surplus of every multiple point of such an (N-1)-cover by q, then we remain with a weighted set of  $2(q^{N-1}-1)/(q-1)$  points intersecting every hyperplane in at least  $2(q^{N-2}-1)/(q-1)$  points. Hence, these surplus points form a weighted  $\{2(q^{N-1}-1)/(q-1), 2(q^{N-2}-1)/(q-1); 2N+1, q\}$ -minihyper (F,w).

For N=2, this means that (F,w) is either a point with multiplicity two or two points with multiplicity one (see also [4, Theorem 3.1]). For arbitrary N, the following result is valid.

**Theorem 5.13** Let C be an (N-1)-cover of  $Q = Q^+(2N+1,q)$ ,  $q \geq 3$ , with  $|C| = q^{N+1} + 2q + 1$ . Then there are two (N-2)-dimensional subspaces  $U_1, U_2$  (possibly coinciding) on Q such that all points of  $U_1 \cap U_2$  have surplus 2q, all points of  $(U_1 \cup U_2) \setminus (U_1 \cap U_2)$  have surplus q, and all points of  $Q \setminus (U_1 \cup U_2)$  have surplus 0.

#### 5.5 The generalized quadrangles $H(3, q^2)$ and $H(4, q^2)$

Corollary 5.10 states the following particular result for the 5-dimensional non-singular elliptic quadric  $Q^-(5,q)$ . Here  $q=p^3$ , where p satisfies the conditions of Corollary 5.10.

**Theorem 5.14** A partial spread of  $Q^-(5, q = p^3)$  of deficiency  $\delta \leq 2p^2 - 4p$  can be extended to a spread of  $Q^-(5, q)$ .

The generalized quadrangle  $Q^-(5,q)$  is dual to the generalized quadrangle  $H(3,q^2)$  [21] arising from the nonsingular Hermitian variety in  $PG(3,q^2)$ . The notions spread and  $partial\ spread$  of  $Q^-(5,q)$  then are equivalent to the notions ovoid and  $partial\ ovoid$  of  $H(3,q^2)$ . Since results on partial ovoids of  $H(3,q^2)$  are also interesting for results on partial ovoids of the generalized quadrangle  $H(4,q^2)$  arising from the nonsingular Hermitian variety in  $PG(4,q^2)$ , we give the definitions for as well  $H(3,q^2)$  as for  $H(4,q^2)$ .

**Definition 5.15** An ovoid O of  $\mathcal{P} = H(3, q^2)$  or  $\mathcal{P} = H(4, q^2)$  is a set of points of  $\mathcal{P}$  such that every line of  $\mathcal{P}$  contains exactly one element of O; a partial ovoid O' of  $\mathcal{P}$  is a set of points of  $\mathcal{P}$  such that no line of  $\mathcal{P}$  contains more than one point of O'.

So Theorem 5.14 leads to the following result.

**Theorem 5.16** A partial ovoid of  $H(3, q^2)$  of deficiency  $\delta \leq 2p^2 - 4p$  can be extended to an ovoid of  $H(3, q^2)$ .

The preceding result then implied the following result on partial ovoids of  $H(4, q^2)$ .

**Theorem 5.17** (Govaerts, Storme and Van Maldeghem [12]) If O is a partial ovoid of  $H(4, q^2)$ , then  $|O| < q^5 - (4q - 1)/3$ .

#### 5.6 Applying the triality principle

Corollary 5.10 implies the following result on partial 3-spreads of the 7-dimensional hyperbolic quadric  $Q^+(7,q)$ . Again,  $q=p^3$ , where p satisfies the conditions of Corollary 5.10.

**Theorem 5.18** A partial 3-spread of  $Q^+(7,q)$  of deficiency  $\delta \leq 2p^2 - 4p$  can be extended to a 3-spread of  $Q^+(7,q)$ .

But under the triality principle [28], partial 3-spreads of  $Q^+(7,q)$  are equivalent to partial ovoids of  $Q^+(7,q)$ . Hence, the preceding theorem implies the following result on extendability of partial ovoids of  $Q^+(7,q)$ .

**Theorem 5.19** (Govaerts, Storme and Van Maldeghem [12]) A partial ovoid of  $Q^+(7,q)$  of deficiency  $\delta \leq 2p^2 - 4p$  can be extended to an ovoid of  $Q^+(7,q)$ .

#### 5.7 Partial ovoids on the Split Cayley hexagon

Let q be a prime power and let H(q) be the split Cayley hexagon, i.e., the generalized hexagon defined in the following way. The points of H(q) are the points of PG(6,q) on the quadric  $Q(6,q): X_0X_4 + X_1X_5 + X_2X_6 = X_3^2$ ; the lines are the lines of this quadric whose Grassmann coordinates satisfy the equations

$$p_{12} = p_{34}, \qquad p_{54} = p_{32}, \qquad p_{20} = p_{35}, \\ p_{65} = p_{30}, \qquad p_{01} = p_{36}, \qquad p_{46} = p_{31},$$

and incidence is the natural one. Opposite points of H(q) are points that are at distance 6 from each other in the incidence graph of H(q) (and that is also the maximal possible distance). The generalized hexagon H(q) has the property that the set of points collinear with a given point x in H(q) is the point set of a unique plane  $x^{\perp}$  contained in Q(6,q). An ovoid of H(q) is a set of  $q^3+1$  mutually opposite points. A simple counting argument yields that every point outside a given ovoid of H(q) is collinear with exactly one point of the ovoid, see also [29, Chapter 7]. Hence, if  $\mathcal{O}$  is an ovoid of H(q), then the set of  $q^3+1$  planes  $x^{\perp}$ , with  $x \in \mathcal{O}$ , is a plane spread of Q(6,q). A partial ovoid of H(q) is a set of mutually opposite points, and this set is called maximal if no point of H(q) is opposite every point of the partial ovoid. The deficiency of a partial

ovoid containing N points is  $\delta = q^3 + 1 - N$ .

Let  $\mathcal{O}$  be a maximal partial ovoid of H(q) with deficiency  $\delta$ . The set of planes  $x^{\perp}$ , with  $x \in \mathcal{O}$ , is a partial plane spread  $\mathcal{S}$  of Q(6,q). The information of Corollary 5.10 on the extendability of this latter partial plane spread  $\mathcal{S}$  to a spread of Q(6,q) can now be used the investigate the deficiency of  $\mathcal{O}$ . Again,  $q=p^3$  where p satisfies the conditions of Corollary 5.10.

**Corollary 5.20** (Govaerts, Storme and Van Maldeghem [12]) If the deficiency  $\delta$  of a maximal partial ovoid of  $H(q=p^3)$  satisfies  $\delta \leq 2p^2 - 4p$ , then  $\delta$  is even.

**Proof:** The minihyper F corresponding to the set of holes of the corresponding partial 2-spread consists of planes, non-projected subgeometries  $PG(5, \sqrt{q})$ , and of (projected) subgeometries PG(8, p).

The subgeometries  $PG(5, \sqrt{q})$  and PG(8, p) can be eliminated using the same arguments as for Corollary 5.10. So, F is a union of pairwise disjoint planes. Now the arguments of [12, Corollary 6.1] can be used to show that  $\delta$  is even

#### References

- [1] B.I. Belov, V.N. Logachev and V.P. Sandimirov, Construction of a class of linear binary codes achieving the Varshamov-Griesmer bound, *Problems of Info. Transmission* **10** (1974), 211-217.
- [2] A. Blokhuis, L. Storme and T. Szőnyi, Lacunary polynomials, multiple blocking sets and Baer subplanes, *J. London Math. Soc.* (2) **60** (1999), 321-332.
- [3] R.H. Dye, Partitions and their stabilizers for line complexes and quadrics, Ann. Mat. Pura Appl. 114 (1977), 173-194.
- [4] J. Eisfeld, L. Storme and P. Sziklai, Minimal covers of the Klein quadric, J. Combin. Theory, Ser. A 95 (2001), 145-157.
- [5] J. Eisfeld, L. Storme and P. Sziklai, Minimal (n-1)-covers and partial (n-1)-spreads of the hyperbolic quadric  $Q^+(2n+1,q)$ , J. Algebraic Combin. **15** (2002), 231-240.
- [6] S. Ferret and L. Storme, Minihypers and linear codes meeting the Griesmer bound: Improvements to results of Hamada, Helleseth and Maekawa, *Des. Codes Cryptogr.* **25** (2002), 143-162.
- [7] S. Ferret and L. Storme, Results on maximal partial spreads in  $PG(3, p^3)$  and on related minihypers, *Des. Codes Cryptogr.* **29** (2003), 105-122.
- [8] S. Ferret and L. Storme, A classification result on weighted  $\{\delta(p^3 + 1), \delta; 3, p^3\}$ -minihypers, J. Combin. Des. 12 (2004), 197-220.

- [9] S. Ferret and L. Storme, A classification result on weighted  $\{\delta v_{\mu+1}, \delta v_{\mu}; N, p^3\}$ -minihypers, *Discr. Appl. Math.*, to appear.
- [10] P. Govaerts and L. Storme, On a particular class of minihypers and its applications. I. The result for general q,  $Des.\ Codes\ Cryptogr.\ 28\ (2003),$  51-63.
- [11] P. Govaerts and L. Storme, On a particular class of minihypers and its applications. II. Improvements for q square, J. Combin. Theory, Ser. A 97(2) (2002), 369-393.
- [12] P. Govaerts, L. Storme and H. Van Maldeghem, On a particular class of minihypers and its applications. III. Applications, *Europ. J. Combin.* **23** (2002), 659-672.
- [13] J.H. Griesmer, A bound for error-correcting codes, *IBM J. Res. Develop.* 4 (1960), 532-542.
- [14] N. Hamada, Characterization of minihypers in a finite projective geometry and its applications to error-correcting codes, *Bull. Osaka Women's Univ.* **24** (1987), 1-24.
- [15] N. Hamada, A characterization of some [n, k, d; q]-codes meeting the Griesmer bound using a minihyper in a finite projective geometry, *Discr. Math.* **116** (1993), 229-268.
- [16] N. Hamada and T. Helleseth, A characterization of some q-ary codes  $(q > (h-1)^2, h \ge 3)$  meeting the Griesmer bound, Math. Japonica 38 (1993), 925-940
- [17] N. Hamada and T. Helleseth, Codes and minihypers. *Optimal codes and related topics*. Proceedings of the EuroWorkshop on Optimal codes and related topics (Sunny Beach, Bulgaria, June 10-16, 2001), pp. 79-84.
- [18] N. Hamada and T. Maekawa, A characterization of some q-ary codes  $(q > (h-1)^2, h \ge 3)$  meeting the Griesmer bound: Part 2, Math. Japonica 46 (1997), 241-252.
- [19] N. Hamada and F. Tamari, On a geometrical method of construction of maximal t-linearly independent sets, J. Combin. Theory, Ser. A 25 (1978), 14-28
- [20] G. Lunardon, P. Polito and O. Polverino, A geometric characterisation of linear k-blocking sets, J. Geom. 74 (2002), 120-122.
- [21] S.E. Payne and J.A. Thas, *Finite Generalized Quadrangles*, Pitman (Advanced Publishing Program), Boston, MA, 1984.
- [22] O. Polverino, Small minimal blocking sets and complete k-arcs in  $PG(2, p^3)$ , Discrete Math. **208/209** (1999), 469-476.

- [23] O. Polverino, Small blocking sets in P G(2, p<sup>3</sup> ), Des. Codes Cryptogr. 20 (2000), 319-324.
- [24] O. Polverino and L. Storme, Minimal blocking sets in P G(2, q<sup>3</sup> ), Europ. J. Combin. 23 (2002), 83-92.
- [25] G. Solomon and J.J. Stiffler, Algebraically punctured cyclic codes, Inform. and Control 8 (1965), 170-179.
- [26] J.A. Thas, Polar spaces, generalized hexagons and perfect codes, J. Combin. Theory, Ser. A 29 (1980), 87-93.
- [27] J.A. Thas, Ovoids and spreads of finite classical polar spaces, Geom. Dedicata 10 (1981), 135-143.
- [28] J. Tits, Sur la trialit´e et certain groupes qui s'en d´eduisent, Inst. Hautes Etudes Sci. Publ. Math. 2 (1959), 14-60.
- [29] H. Van Maldeghem, Generalized Polygons, Birkh¨auser Verlag, Basel, 1998.

Address of the author: Ghent University, Dept. of Pure Maths and Computer Algebra, Krijgslaan 281, 9000 Ghent, Belgium

(ls@cage.ugent.be, http://cage.ugent.be/∼ls)