## Linear Codes from Projective Linear Anticodes Revisited

Hao Chen and Conghui Xie\*

June 12, 2024

#### Abstract

An anticode  $\mathbf{C} \subset \mathbf{F}_q^n$  with the diameter  $\delta$  is a code in  $\mathbf{F}_q^n$  such that the distance between any two distinct codewords in  $\mathbf{C}$  is at most  $\delta$ . The famous Erdös-Kleitman bound for a binary anticode  $\mathbf{C}$  of the length n and the diameter  $\delta$  asserts that

$$|\mathbf{C}| \le \sum_{i=0}^{\frac{\delta}{2}} \binom{n}{i}.$$

In this paper, we give an antiGriesmer bound for q-ary projective linear anticodes, which is stronger than the above Erdös-Kleitman bound for binary anticodes. The antiGriesmer bound is a lower bound on diameters of projective linear anticodes. From some known projective linear anticodes, we construct some linear codes with optimal or near optimal minimum distances. A complementary theorem constructing infinitely many new projective linear (t+1)-weight code from a known t-weight linear code is presented. Then many new optimal or almost optimal few-weight linear codes are given and their weight distributions are determined. As a by-product, we also construct several infinite families of three-weight binary linear codes, which lead to l-strongly regular graphs for each odd integer  $l \geq 3$ .

**Index terms:** Projective linear anticode. The Erdös-Kleitman bound. Anti-Griesmer bound. Anti-Griesmer defect. Optimal or almost optimal few-weight linear code. Complementary Reed-Solomon code. *l*-strongly walk-regular graph.

<sup>\*</sup>Hao Chen and Conghui Xie are with the College of Information Science and Technology/Cyber Security, Jinan University, Guangzhou, Guangdong Province, 510632, China, haochen@jnu.edu.cn, conghui@stu2021.jnu.edu.cn. This research was supported by NSFC Grant 62032009.

## 1 Introduction

### 1.1 Preliminaries

The Hamming weight  $wt(\mathbf{a})$  of a vector  $\mathbf{a} = (a_0, \dots, a_{n-1}) \in \mathbf{F}_q^n$  is the cardinality of its support,

$$supp(\mathbf{a}) = \{i : a_i \neq 0\}.$$

The Hamming distance  $d(\mathbf{a}, \mathbf{b})$  between two vectors  $\mathbf{a}$  and  $\mathbf{b}$  is  $d(\mathbf{a}, \mathbf{b}) = wt(\mathbf{a} - \mathbf{b})$ . Then  $\mathbf{F}_q^n$  is a finite Hamming metric space. The minimum (Hamming) distance of a code  $\mathbf{C} \subset \mathbf{F}_q^n$  is,

$$d(\mathbf{C}) = \min_{\mathbf{a} \neq \mathbf{b}} \{d(\mathbf{a}, \mathbf{b}), \mathbf{a} \in \mathbf{C}, \mathbf{b} \in \mathbf{C}\}.$$

One of the main goals in the theory of error-correcting codes is to construct codes  $\mathbb{C} \subset \mathbb{F}_q^n$  with large cardinalities and minimum distances. In general, there are some upper bounds on cardinalities or minimum distances of codes. Optimal codes attaining these bounds are particularly interesting, see [42]. The Singleton bound for general  $(n, M, d)_q$  codes asserts  $M \leq q^{n-d+1}$  and codes attaining this bound is called (nonlinear) maximal distance separable (MDS) codes. Reed-Solomon codes are well-known linear MDS codes, see [42]. Constructions of non-Reed-Solomon type linear MDS codes have attracted many attentions, see, e.g., [13] and references therein. For counting MDS codes, we refer to [23].

On the other hand, the diameter of a code  $\mathbf{C} \subset \mathbf{F}_q^n$  is

$$\delta(\mathbf{C}) = \max_{\mathbf{a} \neq \mathbf{b}} \{d(\mathbf{a}, \mathbf{b}), \mathbf{a} \in \mathbf{C}, \mathbf{b} \in \mathbf{C}\}.$$

It is also interesting to construct large anticodes with a fixed diameter, see [1, 22, 24, 38]. The following code-anticode bound in [2, 15] asserts that for a code  $\mathbf{C} \subset \mathbf{F}_q^n$  with the minimum distance d and an anticode  $\mathbf{A} \subset \mathbf{F}_q^n$  with the diameter d-1, we have

$$|\mathbf{C}| \cdot |\mathbf{A}| \le q^n.$$

A linear code  $\mathbb{C} \subset \mathbb{F}_q^n$  of the dimension k and the minimum distance d is denoted as a linear  $[n,k,d]_q$  code. It is clear that for a linear code, its minimum distance is just the minimum weight of nonzero codewords. Its diameter is the maximum weight of nonzero codewords. A linear code is called projective if the dual distance is at least three. In this paper, we only consider projective linear anticodes. For fixed q, n, k, if there is an linear  $[n, k, d]_q$  code, and there is no  $[n, k, d+1]_q$  code. We call this code optimal. If there is a linear  $[n, k, d+1]_q$  code, but there is no linear  $[n, k, d+2]_q$  code, we call this code almost optimal. We treat maximum weights of projective linear codes in this paper. The binary simplex  $[2^k-1, k, 2^{k-1}]_2$  code can be considered as an anticode with the diameter  $\delta=2^{k-1}$ . For a linear code  $\mathbb{C} \subset \mathbb{F}_q^n$ , we denote by  $A_i(\mathbb{C})$  the number of codewords with the weight  $i, 0 \leq i \leq n$ .

#### 1.2 Griesmer bound

The Griesmer bound was proved in [26]. It asserts that, for a linear  $[n, k, d]_q$  code,

$$n \ge \sum_{i=0}^{k-1} \lceil \frac{d}{q^i} \rceil,$$

or see [35, Theorem 2.7.4, page 81]. Set  $g_q(k,d) = \sum_{i=0}^{k-1} \lceil \frac{d}{q^i} \rceil$ . The Griesmer defect of the linear code  $\mathbf{C}$  is  $g(\mathbf{C}) = n - g_q(k,d)$ . A linear  $[n,k,d]_q$  code attaining this bound, that is, the Griesmer defect zero code, is called a Griesmer code, see [32, 33, 49]. A Griesmer defect one linear code is called an almost Griesmer code. It was proved in [7] that for fixed q and k, there are Griesmer codes for any given fixed large minimum distance d. Therefore constructions of Griesmer codes have attracted many authors, see [16, 32, 33, 40, 43, 49, 52]. In [49], many binary linear Griesmer codes were constructed and these codes are called Solomon-Stiffler codes later. These Solomon-Stiffler codes motivated the construction of binary linear anticodes in [24], or see [42, pp. 547-556].

## 1.3 Linear codes with few nonzero weights

Weight distributions are important in theory and practice. It is closely related to error probability of decoding algorithms, see [47, Chapter 2]. The famous Assmus-Mattson theorem in [6, 21] gives a construction of good designs from linear codes. Many constructions of designs from linear codes, see [21], depend on weight distributions of dual codes. Therefore it is important and challenging to determine even partial weight distributions  $A_i(\mathbf{C})$  for some weights i in the range  $d \leq i \leq n$ . Exact weight distributions  $A_d(\mathbf{C}), \ldots A_n(\mathbf{C})$  are only determined for very few linear codes, such as MDS codes, some BCH codes and some linear codes with few nonzero weights, see [42, Chapter 11] and [9, 10, 16, 17, 18, 21, 29, 31, 36, 52]. Linear codes with few nonzero weights, or few-weight linear codes, have been studied by many authors, see [9, 10, 16, 17, 18, 21, 29, 31, 36]. Notice that for many few-weight linear codes constructed in previous papers [16, 18, 21, 29, 31, 36, 52], their dual codes are known and have minimum distances at least three. Hence these few-weight linear codes can be thought as projective linear anticodes.

#### 1.4 Minimal codes

Minimal codewords were first introduced in [34] for decoding linear block codes. Then minimal binary linear codes were studied in [14] in the name of linear interesting codes. In [5], minimal codes and minimal codewords were introduced for general q-ary linear codes and studied systematically. A nonzero codeword  $\mathbf{c}$  of a linear  $[n, k, d]_q$  code  $\mathbf{C}$  is called minimal, if for any codeword  $\mathbf{c}'$  satisfying  $supp(\mathbf{c}') \subset supp(\mathbf{c})$ , then there is a nonzero  $\lambda \in \mathbf{F}_q$ , such that,  $\mathbf{c}' = \lambda \mathbf{c}$ . A linear code  $\mathbf{C}$  is called minimal if each nonzero codeword is

minimal. In [3] combinatorial and geometric properties of minimal codes were studied.

In [5], the Ashikhmin-Barg criterion  $\frac{d(\mathbf{C})}{\delta(\mathbf{C})} > \frac{q-1}{q}$  was proposed as a sufficient condition for a q-ary linear code to be minimal. However, this is certainly not a necessary condition for minimality of linear codes. In [11] the first family of minimal binary linear codes violating the Ashikhmin-Barg criterion was constructed. Then several families of minimal binary linear codes violating the Ashikhmin-Barg criterion were constructed in [19] from binary linear codes with three nonzero weights, also see [4, 43, 44, 53].

## 1.5 *l*-strongly walk-regular graphs

We recall some basic facts about the l-strongly walk-regular graph (SWRG or l-SWRG). A strongly regular graph (SRG) is a type of regular graph in which the number of common neighbors of two distinct vertices is determined only by their adjacency. And l-SWRGs are the natural generalization of SRGs where length two paths are replaced by paths of length  $l \geq 2$ , see [50]. The definition of an l-SWRG (defined as  $\Gamma$ ) with parameters ( $\lambda_l, \mu_l, \nu_l$ ) is that there are  $\lambda_l$ ,  $\mu_l$  and  $\nu_l$  walks of length l between every two adjacent, every two non-adjacent, and every two identical vertices, respectively.

SWRGs have wide applications in finite groups, codes, and design, see [37, 50]. In [37], it was proved that a binary three-weight projective linear code satisfying some conditions leads to a 3-strongly walk-regular graph. In a recent paper [41], an infinite family of binary three-weight projective linear codes with new parameters was constructed, which produces l-SWRGs for every odd  $l \geq 3$ , see [41, Section 5].

#### 1.6 Related works

The intuition behind code-anticode bound is that all sets  $\mathbf{C} + a$ ,  $a \in \mathbf{A}$ , are disjoint in  $\mathbf{F}_q^n$ . Sphere-packing bound can be thought as a special case of the code-anticode bound, see [2, 8, 15]. For the diametric theorem on q-ary anticodes, we refer to [1, 2]. The Erdös-Kleitman bound was proved in [22] and [38], when Kleitman was with the Department of Physics in Brandies University. It asserts that an anticode in  $\mathbf{F}_2^n$  with the diameter  $\delta$  has at most  $\sum_{i=0}^{\frac{\delta}{2}} \binom{n}{i}$  elements. It is clear that when  $\delta = 2$ , the anticode consisting of n+1 elements  $\mathbf{0}, \mathbf{e}_1, \ldots, \mathbf{e}_n$  is an anticode attaining the Erdös-Kleitman bound. Here  $\mathbf{e}_i \in \mathbf{F}_2^n$  is the vector with the nonzero coordinate at the position i.

In [24], the lower bound

$$\delta \ge \frac{2^{k-1}n}{2^k - 1}$$

for a binary linear projective anticode of the dimension k and the diameter  $\delta$  was proved. A Gilbert-like bound on anticode was proved in [46]. From a similar idea of constructing Solomon-Stiffler codes, Farrell gave a construction of linear codes with optimal parameters or near optimal parameters from linear anticodes, see [24] and [42, pp. 547-556], and vice versa. Optimal locally repairable codes were constructed from anticodes in [48]. In [54, Conclusion], it was mentioned that the codes generated by the matrices deleting some columns in the generator matrices of the binary simplex codes, could be attractive. Similar idea motivated the paper [39]. However the idea in [24, 39, 49, 54] was not fully developed. We show that this relation between projective linear codes and anticodes can lead to numerous minimal linear codes and linear codes with two, three, and four nonzero weights, from our complementary theorem Corollary 3.1. More interestingly, some of these minimal linear codes and linear codes with few nonzero weights are optimal, almost optimal and near optimal. The basic point is as follows. Considering few-weight linear codes constructed in [10, 16, 17, 18, 21, 29, 31, 36, 52] as projective anticodes, since their maximum weights were determined, then complementary few-weight linear codes can be constructed immediately. The only remaining point is antiGrismer defect of these anticodes should be calculated. If the antiGriesmer defect is small, then the complementary code has a small Griesmer defect, thus optimal, almost optimal or near optimal.

It is well-known that a binary three-weight projective linear code with three weights  $w_1 < w_2 < w_3$  and the length n satisfying

$$w_1 + w_2 + w_3 = \frac{3n}{2}$$

lead to a 3-strongly walk-regular graphs, see [37, 41, 50]. Moreover if  $w_2 = \frac{n}{2}$ , the binary three-weight projective linear code leads to l-strongly walk-regular graphs with each odd  $l \geq 3$ , see [37, 41, 50]. Since several such binary three-weight projective linear codes are constructed in Section 5. They lead to many such 3-strongly walk-regular and l-strongly walk-regular graphs, see Section 9.

### 1.7 Our contributions

Our main results are as follows.

**Theorem 1.1 (AntiGriesmer bound)** Let q be a prime power and n be a positive integer satisfying  $n < q^{k-1}$ . Let  $\mathbf{C} \subset \mathbf{F}_q^n$  be a projective linear code of the dimension k and the maximum weight (diameter)  $\delta$ . Then

$$\sum_{i=0} \lfloor \frac{\delta}{q^i} \rfloor \ge n.$$

First of all, this bound can be thought as lower bounds on maximum weights of projective linear codes. This bound is stronger than the Erdös-Kleitman bound. We construct

many linear projective anticodes from fixed weight vectors, dual of BCH codes and linear codes with few nonzero weights, such that they are close this bound. From the proof of Theorem 2.1, if the complementary code attains the Griesmer bound, then the code attains the above antiGriesmer bound for projective linear anticodes.

**Theorem 1.2** Let q be a prime power and n be a positive integer satisfying  $n < q^{k-1}$ . Let  $\mathbf{C} \subset \mathbf{F}_q^n$  be a projective linear code with the dimension  $k_1$  and the diameter  $\delta$ . Let k be a positive integer satisfying  $k \geq k_1$  be a positive integer. Then a linear projective  $[\frac{q^{k-1}}{q-1} - n, k, q^{k-1} - \delta]_q$  code is constructed.

**Theorem 1.3 (Complementary theorem)** Let q be a prime power and n be a positive integer satisfying  $n < q^{k-1}$ . Let  $\mathbf{C} \subset \mathbf{F}_q^n$  be a projective linear code with the dimension k and t nonzero weights  $w_1 < \cdots < w_t$ . Then we construct an explicit  $[\frac{q^k-1}{q-1} - n, k, q^{k-1} - \delta(\mathbf{C})]_q$  code  $\mathbf{C}'$  with t nonzero weights  $q^{k-1} - w_t < \cdots < q^{k-1} - w_1$ . Moreover

$$A_{w_i}(\mathbf{C}) = A_{q^{k-1} - w_i}(\mathbf{C}').$$

Let K be a positive integer satisfying K > k, then we construct an explicit  $\left[\frac{q^K-1}{q-1}, K, q^{K-1} - \delta(\mathbf{C})\right]_q$  code  $\mathbf{C}''$  with t+1 weights  $q^{K-1} - w_t < \cdots < q^{K-1} - w_1 < q^{K-1}$ . Moreover

$$q^{K-k}A_{w_j}(\mathbf{C}) = A_{q^{K-1}-w_j}(\mathbf{C}''),$$

and

$$A_{q^{K-1}}(\mathbf{C}'') = q^{K-k} - 1.$$

Similarly, we introduce the antiGriesmer defect of a linear code as

$$\sum_{i=0}^{k-1} \lfloor \frac{\delta(\mathbf{C})}{q^i} \rfloor - n.$$

This defect can reflect the Griesmer defect of its complementary code. Projective linear anticode meeting the above bound are called antiGriesmer codes. From the proof of Theorem 2.1, the complementary code of a projective Griesmer code is an antiGriesmer code, ans vice versa. In general, complementary codes of small antiGriesmer defect anticodes have small Griesmer defect. Therefore, we can consider these few-weight linear codes constructed in [10, 16, 17, 18, 21, 29, 31, 36, 43, 44, 52] as projective linear anticodes, and calculate their antiGriesmer defects. If their antiGriesmer defects are small, complementary codes are close to the Griemser bound.

From this complementary theorem, infinitely many projective linear codes with t+1 nonzero weights close to the optimal parameters are constructed, see Section 5 below. Notice that these codes in the following table are minimal binary linear codes, since the Ashikhmin-Barg criterion is satisfied. As far as we know, no such anticode-based construction of few-weight linear codes has been reported in the literature. In the following Tables

1 and 2, we list some optimal, almost optimal, or near optimal few-weight linear codes constructed in this paper.

Table 1: Minimal two-weight and four-weight codes

| q | Parameters          | Weights                                      | Optimal parameters  |
|---|---------------------|----------------------------------------------|---------------------|
| 2 | [9,<br>4,<br>4]2    | 4,<br>5,<br>6,<br>8                          | optimal             |
| 2 | [10,<br>4,<br>4]2   | 4,<br>6                                      | optimal             |
| 2 | [11,<br>4,<br>5]2   | 5,<br>6,<br>7,<br>8                          | optimal             |
| 2 | [23,<br>5,<br>10]2  | 10,<br>12,<br>14,<br>16                      | almost optimal      |
| 2 | [25,<br>5,<br>12]2  | 12,<br>13,<br>14,<br>16                      | optimal             |
| 2 | [27,<br>5,<br>13]2  | 13,<br>14,<br>15,<br>16                      | optimal             |
| 2 | [30,<br>8,<br>8]2   | 8,<br>16                                     | [30,<br>8,<br>12]2  |
| 2 | [35,<br>6,<br>16]2  | 16,<br>20                                    | optimal             |
| 2 | [43,<br>6,<br>20]2  | 20,<br>22,<br>24,<br>32                      | optimal             |
| 2 | [46,<br>6,<br>20]2  | 20,<br>21,<br>22,<br>23,<br>24,<br>25,<br>26 | optimal             |
| 2 | [47,<br>6,<br>22]2  | 22,<br>24,<br>26,<br>32                      | almost optimal      |
| 2 | [48,<br>6,<br>22]2  | 22,<br>24,<br>26,<br>32                      | [48,<br>6,<br>24]2  |
| 2 | [51,<br>6,<br>24]2  | 24,<br>26,<br>28,<br>32                      | optimal             |
| 2 | [51,<br>8,<br>24]2  | 24,<br>32                                    | optimal             |
| 2 | [53,<br>6,<br>22]2  | 22,<br>26,<br>28,<br>32                      | [53,<br>6,<br>26]2  |
| 2 | [55,<br>6,<br>26]2  | 26,<br>28,<br>30,<br>32                      | almost optimal      |
| 2 | [57,<br>6,<br>28]2  | 28,<br>29,<br>30,<br>32                      | optimal             |
| 2 | [59,<br>6,<br>29]2  | 29,<br>30,<br>31,<br>32                      | optimal             |
| 2 | [88,<br>7,<br>40]2  | 40,<br>44,<br>48,<br>64                      | [88,<br>7,<br>42]2  |
| 2 | [95,<br>7,<br>44]2  | 44,<br>48,<br>52,<br>64                      | [95,<br>7,<br>47]2  |
| 2 | [96,<br>7,<br>44]2  | 44,<br>48,<br>52,<br>64                      | [96,<br>7,<br>48]2  |
| 2 | [107,<br>7,<br>52]2 | 52,<br>54,<br>56,<br>64                      | optimal             |
| 2 | [111,<br>7,<br>54]2 | 54,<br>56,<br>58,<br>64                      | almost optimal      |
| 2 | [112,<br>7,<br>54]2 | 54,<br>56,<br>58,<br>64                      | [112,<br>7,<br>56]2 |
| 2 | [115,<br>7,<br>56]2 | 56,<br>58,<br>60,<br>64                      | optimal             |
| 2 | [117,<br>7,<br>54]2 | 54,<br>58,<br>60,<br>64                      | [117,<br>7,<br>58]2 |
| 2 | [119,<br>7,<br>58]2 | 58,<br>60,<br>62,<br>64                      | almost optimal      |
| 2 | [120,<br>7,<br>58]2 | 58,<br>60,<br>62,<br>64                      | [120,<br>7,<br>60]2 |
| 2 | [121,<br>7,<br>60]2 | 60,<br>61,<br>62,<br>64                      | optimal             |
| 2 | [123,<br>7,<br>61]2 | 61,<br>62,<br>63,<br>64                      | optimal             |
| 2 | [126,<br>8,<br>56]2 | 56,<br>60,<br>66,<br>70                      | [126,<br>8,<br>62]2 |
| 2 | [183,<br>8,<br>88]2 | 88,<br>92,<br>96,<br>128                     | [183,<br>8,<br>90]2 |
| 2 | [191,<br>8,<br>92]2 | 92,<br>96,<br>100,<br>128                    | [191,<br>8,<br>95]2 |
| 2 | [192,<br>8,<br>92]2 | 92,<br>96,<br>100,<br>128                    | [192,<br>8,<br>96]2 |
| 2 | [199,<br>8,<br>96]2 | 96,<br>100,<br>104,<br>128                   | [199,<br>8,<br>98]2 |

| 2 | [204,<br>8,<br>96]2  | 96,<br>104                  | [204,<br>8,<br>100]2 |
|---|----------------------|-----------------------------|----------------------|
| 2 | [216,<br>8,<br>104]2 | 104,<br>108,<br>112,<br>128 | [216,<br>8,<br>107]2 |
| 2 | [223,<br>8,<br>108]2 | 108,<br>112,<br>116,<br>128 | [223,<br>8,<br>111]2 |
| 2 | [224,<br>8,<br>108]2 | 108,<br>112,<br>116,<br>128 | [224,<br>8,<br>112]2 |
| 2 | [225,<br>8,<br>112]2 | 112,<br>120                 | optimal              |
| 2 | [235,<br>8,<br>116]2 | 116,<br>118,<br>120,<br>128 | optimal              |
| 2 | [239,<br>8,<br>118]2 | 118,<br>120,<br>122,<br>128 | almost optimal       |
| 2 | [240,<br>8,<br>118]2 | 118,<br>120,<br>122,<br>128 | [240,<br>8,<br>120]2 |
| 2 | [245,<br>8,<br>118]2 | 118,<br>122,<br>124,<br>128 | [245,<br>8,<br>122]2 |
| 2 | [243,<br>8,<br>120]2 | 120,<br>122,<br>124,<br>128 | optimal              |
| 2 | [247,<br>8,<br>122]2 | 122,<br>124,<br>126,<br>128 | almost optimal       |
| 2 | [248,<br>8,<br>122]2 | 122,<br>124,<br>126,<br>128 | [248,<br>8,<br>124]2 |
| 2 | [249,<br>8,<br>124]2 | 124,<br>125,<br>126,<br>128 | optimal              |
| 2 | [251,<br>8,<br>125]2 | 125,<br>126,<br>127,<br>128 | optimal              |
| 3 | [30,<br>4,<br>18]3   | 18,<br>21                   | almost optimal       |
| 3 | [32,<br>4,<br>21]3   | 21,<br>24                   | optimal              |
| 4 | [68,<br>4,<br>48]4   | 48,<br>52                   | [68,<br>4,<br>50]4   |
| 4 | [75,<br>4,<br>56]4   | 56,<br>69                   | optimal              |
| 5 | [130,<br>4,<br>100]5 | 100,<br>105                 | [130,<br>4,<br>103]5 |

Table 2: Minimal three-weight codes

| q | Parameters           | Weights             | Optimal parameters |
|---|----------------------|---------------------|--------------------|
| 2 | [16,                 | 6,                  | [16,               |
|   | 5,                   | 8,                  | 5,                 |
|   | 6]2                  | 10                  | 8]2                |
| 2 | [19,<br>5,<br>8]2    | 8,<br>10,<br>12     | optimal            |
| 2 | [21,                 | 6,                  | [21,               |
|   | 5,                   | 10,                 | 5,                 |
|   | 6]2                  | 12                  | 10]2               |
| 2 | [22,<br>5,<br>10]2   | 10,<br>12,<br>16    | optimal            |
| 2 | [25,                 | 10,                 | [25,               |
|   | 5,                   | 12,                 | 5,                 |
|   | 10]2                 | 14                  | 12]2               |
| 2 | [32,                 | 12,                 | [32,               |
|   | 6,                   | 16,                 | 6,                 |
|   | 12]2                 | 20                  | 16]2               |
| 2 | [48,                 | 22,                 | [46,               |
|   | 6,                   | 24,                 | 6,                 |
|   | 22]2                 | 26                  | 24]2               |
| 2 | [54,<br>6,<br>26]2   | 26,<br>28,<br>32    | optimal            |
| 2 | [56,                 | 26,                 | [56,               |
|   | 6,                   | 28,                 | 6,                 |
|   | 26]2                 | 30                  | 28]2               |
| 2 | [64,                 | 28,                 | [64,               |
|   | 7,                   | 32,                 | 7,                 |
|   | 28]2                 | 36                  | 32]2               |
| 2 | [70,<br>7,<br>32]2   | 32,<br>35,<br>40    | almost optimal     |
| 2 | [71,                 | 32,                 | [71,               |
|   | 7,                   | 36,                 | 7,                 |
|   | 32]2                 | 40                  | 34]2               |
| 2 | [92,<br>7,<br>44]2   | 44,<br>48,<br>64    | almost optimal     |
| 2 | [118,<br>7,<br>58]2  | 58,<br>60,<br>64    | optimal            |
| 2 | [144,                | 64,                 | [144,              |
|   | 8,                   | 72,                 | 8,                 |
|   | 64]2                 | 80                  | 70]2               |
| 2 | [220,<br>8,<br>108]2 | 108,<br>112,<br>128 | almost optimal     |
| 2 | [246,<br>8,<br>122]2 | 122,<br>124,<br>128 | optimal            |

| 3 | $[81, 5, 51]_3$ | 51, 54, 57 | $[81, 5, 54]_3$ |
|---|-----------------|------------|-----------------|
| 4 | $[18, 3, 13]_4$ | 13, 14, 15 | optimal         |
| 5 | $[25, 3, 19]_5$ | 19, 20, 21 | almost optimal  |
| 5 | $[28, 3, 22]_5$ | 22, 23, 24 | optimal         |
| 7 | $[49, 3, 41]_7$ | 41, 42, 43 | almost optimal  |
| 7 | $[54, 3, 46]_7$ | 46, 47, 48 | optimal         |
| 8 | $[70, 3, 61]_8$ | 61, 62, 63 | optimal         |
| 9 | $[81, 3, 71]_9$ | 71, 72, 73 | almost optimal  |
| 9 | $[88, 3, 78]_9$ | 78, 79, 80 | optimal         |

Many minimal binary linear codes satisfying the Ashikhmin-Barg criterion are constructed from the above complementary theorem, see Section 7 below. In the following table some minimal linear codes with optimal or near optimal parameters are listed.

Table 3: Minimal codes

| q | Length | Dimension | Distance | Optimal parameters |
|---|--------|-----------|----------|--------------------|
| 2 | 16     | 5         | 7        | almost optimal     |
| 2 | 28     | 6         | 12       | optimal            |
| 2 | 35     | 6         | 16       | optimal            |
| 2 | 42     | 6         | 20       | optimal            |
| 2 | 48     | 6         | 23       | almost optimal     |
| 2 | 57     | 7         | 24       | $[57, 7, 26]_2$    |
| 2 | 70     | 7         | 32       | almost optimal     |
| 2 | 92     | 7         | 44       | almost optimal     |
| 2 | 99     | 7         | 48       | optimal            |
| 2 | 106    | 7         | 52       | optimal            |
| 2 | 112    | 7         | 55       | almost optimal     |
| 2 | 185    | 8         | 88       | $[185, 8, 91]_2$   |
| 2 | 220    | 8         | 108      | almost optimal     |
| 2 | 227    | 8         | 112      | optimal            |
| 2 | 234    | 8         | 116      | optimal            |
| 2 | 240    | 8         | 119      | almost optimal     |

We also construct complementary Reed-Solomon codes as in the following result, see Section 8.

**Theorem 1.4 (Complementary Reed-Solomon codes)** A complementary Reed-Solomon  $[\frac{q^k-1}{q-1}-q,k,q^{k-1}-q]_q$  code is a minimal k-weight almost Griesmer code. As an anticode, it has a difference k-1 to the antiGriesmer bound.

Complementary Reed-Solomon codes over small fields are optimal minimal codes, as listed in the following table.

Table 4: Minimal complementary RS codes over small fields

| q | Parameters        | Weights                                | Optimality |
|---|-------------------|----------------------------------------|------------|
| 2 | $[29, 5, 14]_2$   | 14, 15, 16, 17, 18                     | optimal    |
| 2 | $[61, 6, 30]_2$   | 30, 31, 32, 33, 34, 35                 | optimal    |
| 2 | $[125, 7, 62]_2$  | 62, 63, 64, 65, 66, 67, 68             | optimal    |
| 2 | $[253, 8, 126]_2$ | 126, 127, 128, 129, 130, 131, 132, 133 | optimal    |
| 3 | $[37, 4, 24]_3$   | 24, 25, 26, 27                         | optimal    |
| 3 | $[118, 5, 78]_3$  | 78, 79, 80, 81, 82                     | optimal    |
| 4 | $[17, 3, 12]_4$   | 12, 13, 14                             | optimal    |
| 4 | $[81, 4, 60]_4$   | 60, 61, 62, 63                         | optimal    |
| 5 | $[26, 3, 20]_5$   | 20, 21, 22                             | optimal    |
| 7 | $[50, 3, 42]_7$   | 42, 43, 44                             | optimal    |
| 8 | $[65, 3, 56]_8$   | 56, 57, 58                             | optimal    |
| 9 | $[82, 3, 72]_9$   | 72, 73, 74                             | optimal    |

Notice that it was proved in [28, Theorem 1 and 5], some binary and q-ary Griesmer codes are actually Solomon-Stiffler codes or Belov codes. Therefore, some optimal codes meeting the Griesmer bound constructed in this paper are not new.

## 2 Bounds for anticodes

We first recall the following code-anticode bound due to [2, 15], or see [8].

**Code-anticode bound.** Let  $\mathbf{C} \subset \mathbf{F}_q^n$  be a code with the minimum distance d and  $\mathbf{A} \subset \mathbf{F}_q^n$  be an anticode with the diameter d-1. Then

$$|\mathbf{C}| \cdot |\mathbf{A}| \le q^n.$$

**Proof.** We consider all sets of the  $\mathbf{C} + a$ , where a takes all elements of the anticode  $\mathbf{A}$ . Then these sets are disjoint subsets of  $\mathbf{F}_q^n$ . Otherwise, there are two elements a and a' of the anticode  $\mathbf{A}$  such that there is an common element c+a and c'+a' in  $\mathbf{C}+a$  and  $\mathbf{C}+a'$ . Therefore

$$c - c' = a' - a,$$

we have

$$d(a, a') = d(c, c') \ge d.$$

This is a contradiction.

Let us observe the implication of code-anticode bound in the Hamming metric space  $\mathbf{F}_2^n$ . From the diameter two anticode with n+1 codewords described in Subsection 1.6, we have the upper bound

 $M \le \frac{2^n}{n+1},$ 

for a binary  $(n, M, 3)_2$  code. Binary Hamming  $[2^m - 1, 2^m - m - 1, 3]_2$  code is certainly such a code attaining this upper bound.

Let  $\mathbf{C} \subset \mathbf{F}_q^n$  be a projective linear code with one generator matrix  $\mathbf{G}$  consisting of n distinct columns  $\mathbf{g}_1, \ldots, \mathbf{g}_n$  in  $\mathbf{F}_q^k$ . Let  $\mathbf{G}$  also be the set of these n vectors in  $\mathbf{F}_q^k$ . Let  $H \subset \mathbf{F}_q^k$  be an arbitrary dimension k-1 subspace, it is clear that the maximum weight of  $\mathbf{C}$  is

$$\delta(\mathbf{C}) = n - \min_{H \subset \mathbf{F}_a^k, \dim H = k-1} |H \cap \mathbf{G}|.$$

and the minimum weight of C is

$$d(\mathbf{C}) = n - \max_{H \subset \mathbf{F}_q^k, \dim H = k-1} |H \cap \mathbf{G}|.$$

The following proposition is clear.

**Proposition 2.1** Let  $C \subset \mathbf{F}_q^n$  be a linear  $[n,k]_q$  code. Then its maximum weight is at least k.

**Proof.** There is a nonzero codeword with k nonzero coordinates.

The linear simplex  $[3, 2, 2]_2$  code is certainly a linear projective anticode attaining this bound.

We introduce the complementary code of a projective linear  $[n,k]_q$  anticode  $\mathbf{C}$  as follows. Here the length satisfies the condition  $n < q^{k-1}$ . Let  $\mathbf{G}$  be the  $k \times n$  generator matrix of the projective linear anticode  $\mathbf{C}$ . Then n columns  $\mathbf{g}_1, \ldots, \mathbf{g}_n$  of  $\mathbf{G}$  are distinct vectors of  $\mathbf{F}_q^k$ . By deleting these n distinct columns in the generator matrix of the q-ary simplex  $[\frac{q^k-1}{q-1},k,q^{k-1}]_q$  code, we get a linear  $[\frac{q^k-1}{q-1}-n,k,q^{k-1}-\delta(\mathbf{C})]_q$  code. The dimension is k, because there are  $\frac{q^k-1}{q-1}-n > \frac{q^{k-1}-1}{q-1}$  columns in the generator matrix of this code. These columns cannot be located in a k-1 dimension linear subspace.

For example, we consider the simplex  $[2^{k-1}-1, k-1, 2^{k-2}]$  as a projective linear anticode with the diameter  $\delta(\mathbf{C}) = d(\mathbf{C})$ , the complementary code is actually a first order Reed-Muller  $[2^{k-1}, k, 2^{k-2}]_2$  code.

We prove the following antiGriesmer lower bound for projective linear anticode.

**Theorem 2.1** Let q be a prime power and n be a positive integer satisfying  $n < q^{k-1}$ . Let  $\mathbf{C} \subset \mathbf{F}_q^n$  be a projective linear code of the dimension k. Then its maximum weight  $\delta(\mathbf{C})$  satisfies

$$\sum_{i=0}^{k-1} \lfloor \frac{\delta(\mathbf{C})}{q^i} \rfloor \ge n.$$

**Proof.** From the Griesmer bound for the complementary code, we have

$$\frac{q^k - 1}{q - 1} - n \ge \sum_{i=0}^{k-1} \lceil \frac{q^{k-1} - \delta(\mathbf{C})}{q^i} \rceil.$$

On the other hand,

$$\lceil \frac{q^{k-1} - \delta(\mathbf{C})}{q^i} \rceil = q^{k-1-i} - \lfloor \frac{\delta(\mathbf{C})}{q^i} \rfloor.$$

The conclusion follows immediately.

The following lower bound for projective linear anticode can be deduced from anti-Griesmer bound directly.

**Corollary 2.1** Let q be a prime power and n be a positive integer satisfying  $n < q^{k-1}$ . Let  $\mathbf{C} \subset \mathbf{F}_q^n$  be a projective linear code of the dimension k. Then its maximum weight (diameter) is at least  $(1 - \frac{1}{q})n$ .

**Proof.** It is clear that

$$\delta(\mathbf{C})(1 + \frac{1}{q} + \dots + \frac{1}{q^{k-1}}) \ge \sum_{i=0}^{k-1} \lfloor \frac{\delta(\mathbf{C})}{q^i} \rfloor \ge n.$$

The conclusion follows immediately.

The above two bounds are stronger than the classical Erdös-Kleitman bound for general binary anticodes. Since when  $\delta(\mathbf{C}) = 2$ , there are optimal binary anticode attaining the Erdös-Kleitman bound as described in Subsection 1.6. However, for a binary linear projective anticode with the dimension k and the diameter two. If the length  $n \leq 2^{k-1}$ , then  $n \leq 4$ . Therefore the above two bounds give much stronger restrictions on binary projective linear anticodes than the Erdös-Kleitman bound.

## 3 Linear codes from projective linear anticodes

In this section, we prove the main results Theorem 1.3 and 1.4.

**Theorem 3.1** Let q be a prime power and n be a positive integer satisfying  $n < q^{k-1}$ . Let  $\mathbf{C} \subset \mathbf{F}_q^n$  be a projective linear code with the dimension  $k_1$  and the maximum weight  $\delta$ . Let  $k \geq k_1$  be a positive integer. Then a projective linear  $\left[\frac{q^k-1}{q-1}-n,k,q^{k-1}-\delta\right]_q$  code is constructed.

**Proof.** Let  $\mathbf{g}_1 \dots, \mathbf{g}_n$  be n distinct columns of the projective linear code  $\mathbf{C}$ . By pending some zero coordinates, we can consider them as n distinct vectors in  $\mathbf{F}_q^k$ . By deleting these columns in  $\frac{q^k-1}{q-1}$  columns of the q-ary simplex code, we get a projective  $\left[\frac{q^k-1}{q-1}-n,k,q^{k-1}-\delta\right]_q$  code.

It is clear that from the interpretation of a projective linear code, the weight of a codeword is  $n - |H \cap G|$ , then we have the following result immediately.

<span id="page-12-0"></span>Corollary 3.1 (Complementary theorem) Let q be a prime power and n be a positive integer satisfying  $n < q^{k-1}$ . Let  $\mathbf{C} \subset \mathbf{F}_q^n$  be a projective linear code with the dimension k and t nonzero weights  $w_1 < \cdots < w_t$ . Then we construct an explicit  $[\frac{q^k-1}{q-1} - n, k, q^{k-1} - \delta(\mathbf{C})]_q$  code  $\mathbf{C}'$  with t nonzero weights  $q^{k-1} - w_t < \cdots < q^{k-1} - w_1$ . Moreover

$$A_{w_i}(\mathbf{C}) = A_{q^{k-1} - w_i}(\mathbf{C}').$$

Let K be a positive integer satisfying K > k, then we construct an explicit  $\left[\frac{q^K-1}{q^-}, K, q^{K-1} - \delta(\mathbf{C})\right]_q$  code  $\mathbf{C}''$  with t+1 weights  $q^{K-1} - w_t < \cdots < q^{K-1} - w_1 < q^{K-1}$ . Moreover

$$q^{K-k}A_{w_j}(\mathbf{C}) = A_{q^{K-1}-w_j}(\mathbf{C}''),$$

and

$$A_{q^{K-1}}(\mathbf{C''}) = q^{K-k} - 1.$$

**Proof.** When K = k, the conclusion follows directly. When K > k. We delete columns  $\mathbf{g}'_1, \ldots, \mathbf{g}'_n$  in the generator matrix of the q-ary simplex  $[\frac{q^K-1}{q-1}, K, q^{K-1}]_q$  code. Then it is the generator matrix  $\mathbf{G}'$  of the complementary code. Here  $\mathbf{g}'_i = (\mathbf{0}, \mathbf{g}_i)$ ,  $i = 1, \ldots, n$ , are vectors in  $\mathbf{F}_q^K$ , with K - k zero coordinates. It is clear that for nonzero vectors of the form  $\mathbf{X} = (\mathbf{x}, \mathbf{0})$ , where  $\mathbf{x} \in \mathbf{F}_q^{K-k}$ , there are  $q^{K-k} - 1$  weight  $q^{K-1}$  codewords  $\mathbf{X} \cdot \mathbf{G}'$  in the complementary code. Considering the the first K - k zero coordinates of  $\mathbf{g}'_1, \ldots, \mathbf{g}'_n$ , the conclusion

$$q^{K-k}A_{w_i}(\mathbf{C}) = A_{q^{K-1}-w_i}(\mathbf{C}'')$$

follows immediately.

## 4 Constructions of projective linear anticodes

In this section, we give several constructions of projective linear anticodes close to the antiGriesmer bound.

## 4.1 t-weight linear anticodes

Let  $n = 2^m - 1$ , t be a positive integer satisfying

$$2t - 1 < 2^{\lceil \frac{m}{2} \rceil} + 1.$$

Then in the dual code of the binary BCH code with the designed distance 2t + 1, then the weight w of any nonzero codeword is in the range

$$2^{m-1} - (t-1)2^{\frac{m}{2}} \le w \le 2^{m-1} + (t-1)2^{\frac{m}{2}}.$$

This is the famous Carlitz-Uchiyama theorem, see [42, Page 280]. Therefore we have projective linear  $[2^m - 1, 2m, 2^{m-1} - 2^{\frac{m}{2}}]_2$  codes with the maximum weight (diameter)  $2^{m-1} + 2^{\frac{m}{2}}$ , when m is an even positive integer. It is clear that these projective linear codes have their maximum weights close to the Plotkin type bound.

Let  $q=p^e$  be an odd prime power and k be an odd positive integer. Then from [29, Theorem 15], projective linear four-weight  $[q^k-1,k+1,q^{k-1}(q-1)-1-\frac{\sqrt{p^*}^{e(k+1)}}{q}]_q$  code was constructed. Four weights are  $q^{k-1}(q-1)-1-\frac{\sqrt{p^*}^{e(k+1)}}{q}$ ,  $q^{k-1}(q-1)$ ,  $q^{k-1}(q-1)-1+\frac{\sqrt{p^*}^{e(k+1)}}{q}$ , and  $q^k-1$ , where  $p^*=(-1)^{\frac{p-1}{2}}p$ .

On the other hand, from our complementary theorem, we have a projective linear four-weight  $[q^{k-1}+q^{k-2}+\cdots+q+2,k+1,1]_q$  code with four weights  $1,\,q^{k-1}+1-\frac{\sqrt{p^{*e}(k+1)}}{q},$   $q^{k-1},\,q^{k-1}+1+\frac{\sqrt{p^{*e}(k+1)}}{q}.$  Then the maximum weight is  $q^{k-1}+1+\frac{\sqrt{p^{*e}(k+1)}}{q},$  which is larger than and close to  $\frac{q-1}{q}\cdot(q^{k-1}+q^{k-2}+\cdots+q+2).$ 

The following table lists some projective linear anticodes obtained from projective linear codes obtained in previous papers [17, 18, 36]

Table 5: Projective linear anticodes

| q | Parameters                                      | Maximum weight (Diameter)       | $\frac{\delta}{n}$                  | References |
|---|-------------------------------------------------|---------------------------------|-------------------------------------|------------|
| 2 | $[2^m - 1, 2m, 2^{m-1} - 2^{m/2}]_2$            | $2^{m-1} + 2^{m/2}$             | $> \frac{1}{2} + \frac{1}{2^{m/2}}$ | [23]       |
| 2 | $[2^{2m}-1,3m,2^{2m-1}-2^{m-1}]_2$              | $2^{m-1} + 2^{m-1}$             | $> \frac{1}{2} + \frac{1}{2^{m+1}}$ | [29]       |
| 2 | $[2^{m-1}-1, m, 2^{m-2}-2^{\frac{m+l-4}{2}}]_2$ | $2^{m-2} + 2^{\frac{m+l-4}{2}}$ | $> \frac{1}{2} + \frac{1}{2^{m/2}}$ | [19]       |

| 3              | $\left[\frac{3^{m-1}}{2}, 2m, 3^{m-1} - 3^{\frac{m-1}{2}}\right]_3$ | $3^{m-1} + 3^{\frac{m-1}{2}}$ | $> \frac{2}{3} + \frac{2}{3^{m/2}}$ | [23]      |
|----------------|---------------------------------------------------------------------|-------------------------------|-------------------------------------|-----------|
| q              | $\left[\frac{q^{k}-1}{q-1}, k, q^{k-1}-1\right]_q$                  | $q^{k-1}$                     | $\frac{q^{k-2}}{q^{k-2}+\dots+q+1}$ | [48]      |
| $\overline{q}$ | $[q^2 + 1, 4, q^2 - q]_q$                                           | $q^2$                         | $\frac{q^2}{q^2+1}$                 | [23]      |
| q              | $[2q+2,4,q]_q$                                                      | 2q                            | $\frac{q}{q+1}$ AntiGriesmer        | Section 5 |

We refer to [21] and Section 5 for last two projective linear anticodes in the above table.

## 4.2 Fixed weight binary vectors

Some good binary linear anticodes were constructed in [48, Theorem 3] and applied to construct optimal locally reparable codes. In this section, we recover and extend their constructions of binary projective linear anticodes without using graph theory. Actually, this kind of binary projective linear codes were constructed in [53, 54] as binary LCD codes, or minimal binary codes. The weight distribution was also calculated in [53, 54].

Let k = 2s be an even positive integer. Let  $\mathbf{g}_1, \ldots, \mathbf{g}_n$ , where n = s(2s - 1), be all length k binary vectors with the fixed weight two. Then  $\mathbf{G} = (\mathbf{g}_1, \ldots, \mathbf{g}_n)$  is a  $k \times n$  matrix with the rank k - 1, since the sum of all coordinates in each column is zero. Then for a fixed subset  $I \subset \{1, \ldots, k\}$  with u elements, we consider the hyperplane  $H_I$  defined by

$$\sum_{i \in I} x_i = 0.$$

It is clear that the number of columns in  $H_I$  is  $\frac{u(u-1)}{2} + \frac{(2s-u)(2s-u-1)}{2}$ . Then this number is minimal when u = s. We construct a projective  $[s(2s-1), 2s-1]_2$  anticode with the maximum weight  $s^2$ . When k = 2s + 1 is odd, from a similar argument, the maximum weight is  $\frac{k^2-1}{4}$ .

Similarly, we consider length k vectors of fixed weight four. Set k=7, there are 35 weight four vectors in  $\mathbf{F}_2^7$ . Then the matrix with these 35 columns generator a projective linear  $[35,6]_2$  code  $\mathbf{C}$ . Suppose that the hyperplane is  $\Sigma_{i\in I}x_i=0$ , where  $I\subset\{1,2,\ldots,7\}$ . We can consider the three possibilities |I|=6, |I|=5. and |I|=4. In the case |I|=6, the number of 35 columns in this hyperplane is

$$\frac{6 \cdot 5 \cdot 4 \cdot 3}{4 \cdot 3 \cdot 2 \cdot 1} = 15.$$

In the case |I| = 5, the number of 35 columns in this hyperplane is

$$\frac{5\cdot 4}{2\cdot 1} + 5 = 15.$$

In the case |I| = 4, the number of 35 columns in this hyperplane is

$$\frac{4 \cdot 3}{2 \cdot 1} \cdot 3 + 1 = 19.$$

Then C is a two-weight linear  $[35, 6, 16]_2$  code with two weights 16, 20. Comparing with the optimal  $[35, 6, 16]_2$  code in [25], it is a three-weight code with weights 16, 20, 24. As a anticode, our code is better, since the diameter is smaller. This is an optimal two-weight  $[35, 6, 16]_2$  code with the following weight distribution.

Table 6: Weight distribution of  $[35, 6, 16]_2$  code

| Weight | Weight distribution |
|--------|---------------------|
| 0      | 1                   |
| 16     | 35                  |
| 20     | 28                  |

From our complementary theorem, a three-weight linear  $[92, 7, 44]_2$  code and a three weight linear  $[220, 8, 108]_2$  are constructed from the second conclusion of Theorem 1.3. They are almost optimal codes.

Set k = 8, there are 70 weight four vectors in  $\mathbf{F}_2^8$ . Then the matrix with these 70 columns generator a projective linear  $[70,7]_2$  code  $\mathbf{C}$ . Suppose that the hyperplane is  $\Sigma_{i\in I}x_i = 0$ , where  $I \subset \{1,2,\ldots,8\}$ . We can consider the four possibilities |I| = 7, |I| = 6. |I| = 5 and |I| = 4. In the case |I| = 7, the number of 70 columns in this hyperplane is

$$\frac{7 \cdot 6 \cdot 5 \cdot 4}{4 \cdot 3 \cdot 2 \cdot 1} = 35.$$

In the case |I| = 6, the number of 70 columns in this hyperplane is

$$\frac{6\cdot 5\cdot 4\cdot 3}{4\cdot 3\cdot 2\cdot 1} + \frac{6\cdot 5}{2\cdot 1} = 30.$$

In the case |I| = 5, the number of 70 columns in this hyperplane is

$$\frac{5\cdot 4}{2\cdot 1}\cdot 3 + 5 = 35.$$

In the case |I| = 4, the number of 70 columns in this hyperplane is

$$\frac{4 \cdot 3}{2 \cdot 1} \cdot \frac{4 \cdot 3}{2 \cdot 1} + 2 = 38.$$

Then **C** is a three-weight linear  $[70, 7, 32]_2$  code with three weights 32, 35, 40. Notice that the optimal minimum distance of a binary linear  $[70, 7]_2$  code is 33, see [25]. The weight distribution of this three-weight linear  $[70, 7, 32]_2$  code is as in the following table.

Table 7: Weight distribution of the  $[70, 7, 32]_2$  code

| Weight | Weight distribution |
|--------|---------------------|
| 0      | 1                   |
| 32     | 35                  |
| 35     | 64                  |
| 40     | 28                  |

When k = 9, we get a four-weight binary linear  $[126, 8, 56]_2$  code with four weights 56, 60, 66, 70, the corresponding optimal minimum distance is 62, see [25]. From Theorem 1.3, a four-weight binary linear  $[129, 8, 58]_2$  code with four weights 58, 62, 68, 72, is constructed, the corresponding optimal minimum distance is 64, see [25].

# <span id="page-16-0"></span>5 Constructions of t-weight codes with optimal or near optimal parameters

In this section, we construct many t-weight or (t+1)-weight projective linear codes from our complementary theorem and known t-weight codes constructed in [9, 10, 17, 18, 21, 36, 42]. The basic point is as follows, if a t-weight projective linear code has its maximum weight close to the anti-Griesmer bound, then its complementary t or (t+1)-weight projective linear codes are close to the Griesmer bound. Therefore, it is necessary to check the anti-Griesmer defect of constructed few-weight q-ary projective linear codes.

Let m be an odd positive integer. The dual code of the primitive BCH  $[2^m-1,2^m-1-2m,3]_2$  code is a linear  $[2^m-1,2m,2^{m-1}-2^{\frac{m-1}{2}}]_2$  code with three nonzero weights  $2^{m-1}-2^{\frac{m-1}{2}},2^{m-1},2^{m-1}+2^{\frac{m-1}{2}}$ , see [10, Theorem 4]. These dual codes are obviously projective. Then we have a family of  $[2^{2m}-2^m,2m,2^{2m-1}-2^{m-1}-2^{\frac{m-1}{2}}]_2$  codes with three nonzero weights from our complementary theorem Corollary 3.1. The three nonzero weights are  $2^{2m-1}-2^{m-1}-2^{\frac{m-1}{2}},2^{2m-1}-2^{m-1},2^{2m-1}-2^{m-1}+2^{\frac{m-1}{2}}$ . The weight distributions are

$$A_{2^{2m-1}-2^{m-1}-2^{\frac{m-1}{2}}} = (2^m - 1)(2^{m-2} - 2^{\frac{m-3}{2}}),$$
  

$$A_{2^{2m-1}-2^{m-1}} = (2^m - 1)(2^{m-1} + 1),$$

and

$$A_{2^{2m-1}-2^{m-1}+2^{\frac{m-1}{2}}} = (2^m - 1)(2^{m-2} + 2^{\frac{m-3}{2}}),$$

see [10, Theorem 4]. In particular, when m = 3, this is a linear  $[56, 6, 26]_2$  code with three nonzero weights 26, 28, 30. Notice that the optimal minimum distance of linear  $[56, 6]_2$  code in [25] is 28. This binary three-weight linear code have near optimal parameters. Actually, Griesmer defects of these codes are upper bounded by  $2^{\frac{m+1}{2}}$ .

From the second conclusion of Corollary 3.1, we have binary linear four-weight  $[2^{2m+1}-2^m,2m+1,2^{2m}-2^{m-1}-2^{\frac{m-1}{2}}]_2$  code, and binary linear four-weight  $[2^{2m+2}-2^m,2m+2,2^{2m+1}-2^{m-1}-2^{\frac{m-1}{2}}]_2$  code, when m is odd. When m=3, we construct explicit four-weight  $[120,7,58]_2$  code and four-weight  $[248,8,122]_2$  code. The optimal codes in [25] are linear  $[120,7,60]_2$  code and  $[248,8,124]_2$  code. Our four-weight binary linear codes are near optimal.

Then we have the following conclusion.

<span id="page-17-2"></span>**Theorem 5.1** Let  $m \geq 3$  be an odd integer, t be a positive integer.

- 1) We construct a family of three-weight minimal  $[2^{2m}-2^m,2m,2^{2m-1}-2^{m-1}-2^{\frac{m-1}{2}}]_2$  codes with the weight distribution in Table 8.
- 2) We construct a family of four-weight minimal  $[2^{2m+t}-2^m, 2m+t, 2^{2m+t-1}-2^{m-1}-2^{\frac{m-1}{2}}]_2$  codes with the weight distribution in Table 9.

<span id="page-17-0"></span>**Proof.** The minimality follows from the Ashikhmin-Barg criterion, see [5].

Table 8: Weight distribution of the codes in Theorem 5.1 1)

| Weight                                   | Weight distribution                      |
|------------------------------------------|------------------------------------------|
| 0                                        | 1                                        |
| $2^{2m-1} - 2^{m-1} - 2^{\frac{m-1}{2}}$ | $(2^m - 1)(2^{m-2} - 2^{\frac{m-3}{2}})$ |
| $2^{2m-1} - 2^{m-1}$                     | $(2^m - 1)(2^{m-1} + 1)$                 |
| $2^{2m-1} - 2^{m-1} + 2^{\frac{m-1}{2}}$ | $(2^m - 1)(2^{m-2} + 2^{\frac{m-3}{2}})$ |

<span id="page-17-1"></span>Table 9: Weight distribution of the codes in Theorem 5.1 2)

| Weight                                     | Weight distribution                         |
|--------------------------------------------|---------------------------------------------|
| 0                                          | 1                                           |
| $2^{2m+t-1} - 2^{m-1} - 2^{\frac{m-1}{2}}$ | $2^{t}(2^{m}-1)(2^{m-2}-2^{\frac{m-3}{2}})$ |
| $2^{2m+t-1} - 2^{m-1}$                     | $2^{t}(2^{m}-1)(2^{m-1}+1)$                 |
| $2^{2m+t-1} - 2^{m-1} + 2^{\frac{m-1}{2}}$ | $2^{t}(2^{m}-1)(2^{m-2}+2^{\frac{m-3}{2}})$ |
| $2^{2m+t-1}$                               | $2^t - 1$                                   |

Kasami codes are a family of  $[2^{2m}-1,3m,2^{2m-1}-2^{m-1}]_2$  codes constructed in [36]. They are famous for their application in constructing sequences with optimal correlation magnitudes. They have three nonzero weights,  $2^{2m-1}-2^{m-1},2^{2m-1},2^{2m-1}+2^{m-1}$ . Let the dual distance of a linear code of the length n be  $d' \geq 1$ , then the r-th generalized Hamming weight  $d_r$  of this code is n-d', where r=k-d'+1, see [27, Page 134]. Then from [27, Theorem 1], the dual distances of Kasami codes, when  $m \geq 2$ , are at least

three. So they are projective linear anticodes. From Corollary 3.1, we have a family of  $[2^{3m} - 2^{2m}, 3m, 2^{3m-1} - 2^{2m-1} - 2^{m-1}]_2$  codes with three nonzero weights. Three weights are  $2^{3m-1} - 2^{2m-1} - 2^{m-1}, 2^{3m-1} - 2^{2m-1}, 2^{3m-1} - 2^{2m-1} + 2^{m-1}$ .

In particular, when m=2, we construct an explicit binary linear  $[48,6,22]_2$  code with three weights 22,24,26. The optimal linear  $[48,6,24]_2$  code was documented in [25]. This binary three-weight code is near optimal. Griesmer defects of these codes are upper bounded by  $2^m$ . From Corollary 3.1, we have binary linear four-weight  $[2^{3m+1}-2^{2m},3m+1,2^{3m}-2^{2m-1}-2^{m-1}]_2$  codes, and binary linear four-weight  $[2^{3m+2}-2^{2m},3m+2,2^{3m+1}-2^{2m-1}-2^{m-1}]_2$  codes. When m=2, we construct explicit four-weight  $[112,7,54]_2$  and  $[240,8,118]_2$  codes. The optimal ones in [25] are  $[112,7,56]_2$  and  $[240,8,120]_2$  codes.

#### <span id="page-18-2"></span>**Theorem 5.2** Let m > 2 be an integer, t be a positive integer.

- 1) We construct a family of three-weight minimal  $[2^{3m}-2^{2m}, 3m, 2^{3m-1}-2^{2m-1}-2^{m-1}]_2$  codes with the weight distribution in Table 10.
- 2) We construct a family of four-weight minimal  $[2^{3m+t}-2^{2m}, 3m+t, 2^{3m+t-1}-2^{2m-1}-2^{m-1}]_2$  codes with the weight distribution in Table 11.

<span id="page-18-0"></span>**Proof.** The minimality follows from the Ashikhmin-Barg criterion.

Table 10: Weight distribution of the codes in Theorem 5.2 1)

| Weight                          | Weight distribution   |
|---------------------------------|-----------------------|
| 0                               | 1                     |
| $2^{3m-1} - 2^{2m-1} - 2^{m-1}$ | $(2^m - 1)2^{2m - 1}$ |
| $2^{3m-1} - 2^{2m-1}$           | $2^{2m}-1$            |
| $2^{3m-1} - 2^{2m-1} + 2^{m-1}$ | $(2^m - 1)2^{2m - 1}$ |

<span id="page-18-1"></span>Table 11: Weight distribution of the codes in Theorem 5.2 2)

| Weight                            | Weight distribution       |
|-----------------------------------|---------------------------|
| 0                                 | 1                         |
| $2^{3m+t-1} - 2^{2m-1} - 2^{m-1}$ | $(2^m - 1)2^{2m + t - 1}$ |
| $2^{3m+t-1} - 2^{2m-1}$           | $(2^{2m}-1)2^t$           |
| $2^{3m+t-1} - 2^{2m-1} + 2^{m-1}$ | $(2^m - 1)2^{2m + t - 1}$ |
| $2^{3m+t-1}$                      | $2^{t} - 1$               |

Let  $\frac{m}{l}$  be odd, a family of three-weight binary projective linear  $[2^{m-1}-1,m,2^{m-2}-2^{\frac{m+l-4}{2}}]_2$  codes was constructed in [17, Theorem 1]. The dual distances of these codes were given in [17, Theorem 7]. Three weights are  $2^{m-2}-2^{\frac{m+l-4}{2}},2^{m-2},2^{m-2}+2^{\frac{m+l-4}{2}}$ . Then a family of three-weight binary  $[2^m-2^{m-1},m,2^{m-2}-2^{\frac{m+l-4}{2}}]_2$  codes is obtained from our

complementary theorem. Additionally, the minimality follows from the Ashikhmin-Barg criterion.

Three-weight  $[16, 5, 6]_2$ ,  $[32, 6, 12]_2$  and  $[64, 7, 28]_2$  codes are obtained. The corresponding optimal distance are 8, 16 and 32, see [25]. Then these three-weight binary linear codes are near optimal. From the second conclusion of our complementary theorem, four-weight linear  $[48, 6, 22]_2$ ,  $[96, 7, 44]_2$ ,  $[112, 7, 54]_2$ , [192, 8, 92],  $[224, 8, 108]_2$  and  $[240, 8, 118]_2$  codes are constructed. The optimal linear codes in [25] are  $[48, 6, 24]_2$ ,  $[96, 7, 48]_2$ ,  $[112, 7, 56]_2$ ,  $[192, 8, 96]_2$ ,  $[224, 8, 112]_2$  and  $[240, 8, 120]_2$  codes.

<span id="page-19-2"></span>**Theorem 5.3** Let t, m and l be positive integers, and satisfying  $\frac{m}{l}$  is odd.

- 1) We construct a family of three-weight minimal  $[2^{m-1}, m, 2^{m-2} 2^{\frac{m+l-4}{2}}]_2$  codes with the weight distribution in Table 12.
- <span id="page-19-0"></span>2) We construct a family of four-weight minimal  $[2^{m+t}-2^{m-1}, m+t, 2^{m+t-1}-2^{m-2}-2^{\frac{m+l-4}{2}}]_2$  codes with the weight distribution in Table 13.

| Table 12: Weight distribution of the code in Theorem 5.3 1 | .) |
|------------------------------------------------------------|----|
|------------------------------------------------------------|----|

| Weight                          | Weight distribution               |
|---------------------------------|-----------------------------------|
| 0                               | 1                                 |
| $2^{m-2} + 2^{\frac{m+l-4}{2}}$ | $2^{m-l-1} + 2^{\frac{m-l-2}{2}}$ |
| $2^{m-2}$                       | $2^m - 1 - 2^{m-l}$               |
| $2^{m-2} - 2^{\frac{m+l-4}{2}}$ | $2^{m-l-1} - 2^{\frac{m-l-2}{2}}$ |

<span id="page-19-1"></span>Table 13: Weight distribution of the code in Theorem 5.3 2)

| Weight                                      | Weight distribution                    |
|---------------------------------------------|----------------------------------------|
| 0                                           | 1                                      |
| $2^{m+t-1} - 2^{m-2} + 2^{\frac{m+t-4}{2}}$ | $2^{t}(2^{m-l-1}+2^{\frac{m-l-2}{2}})$ |
| $2^{m+t-1} - 2^{m-2}$                       | $2^t(2^m - 1 - 2^{m-l})$               |
| $2^{m+t-1} - 2^{m-2} - 2^{\frac{m+l-4}{2}}$ | $2^t(2^{m-l-1}-2^{\frac{m-l-2}{2}})$   |
| $2^{m+t-1}$                                 | $2^{t}-1$                              |

Similarly, let  $\frac{m}{l}$  be even, a family of three-weight binary projective linear  $[2^{m-1} - (-1)^{\frac{m}{2l}}2^{\frac{m}{2}+l-1} - 1, m]$  code was also constructed in [17, Theorem 2]. Three weights are  $2^{m-2}, 2^{m-2} - (-1)^{\frac{m}{2l}}2^{\frac{m}{2}+l-2}, 2^{m-2} - (-1)^{\frac{m}{2l}}2^{\frac{m}{2}+l-1}$ . Then a family of three-weight binary  $[2^m - 2^{m-1} + (-1)^{\frac{m}{2l}}2^{\frac{m}{2}+l-1}, m]_2$  code is obtained from Corollary 3.1.

For example, when m = 8, l = 1, three-weight linear  $[144, 8, 64]_2$  code is obtained. The corresponding optimal distance is 70, see [25]. From the second conclusion of our complementary theorem, when m = 6, l = 1, four-weight linear  $[88, 7, 40]_2$  and  $[216, 8, 104]_2$  codes

are constructed. The optimal linear codes in [25] are [88, 7, 42]<sub>2</sub> and [216, 8, 107]<sub>2</sub> codes.

<span id="page-20-2"></span>**Theorem 5.4** Let t, m and l be positive integers, and satisfying  $\frac{m}{l}$  is even.

- 1) If  $\frac{m}{l} \equiv 0 \pmod{4}$ , we construct a family of three-weight minimal  $[2^{m-1}+2^{\frac{m}{2}+l-1}, m, 2^{m-2}]_2$  codes. The weight distribution is given in Table 14.
- <span id="page-20-0"></span>2) We construct a family of four-weight minimal  $[2^{m+t}-2^{m-1}+(-1)^{\frac{m}{2l}}2^{\frac{m}{2}+l-1}, m+t]_2$  codes with the weight distribution in Table 15.

Table 14: Weight distribution of the code in Theorem 5.4 1)

| Weight | Weight distribution |
|--------|---------------------|
| 0      | 1                   |

Weight Weight distribution  $\begin{array}{c|ccccccccccccccccccccccccccccccccccc$ 

Table 15: Weight distribution of the code in Theorem 5.4 2)

<span id="page-20-1"></span>

| Weight                                                          | Weight distribution                                          |
|-----------------------------------------------------------------|--------------------------------------------------------------|
| 0                                                               | 1                                                            |
| $2^{m+t-1} - 2^{m-2}$                                           | $2^{t}(2^{m-2l-1}-1-(-1)^{\frac{m}{2l}}2^{\frac{m}{2}-l-1})$ |
| $2^{m+t-1} - 2^{m-2} + (-1)^{\frac{m}{2l}} 2^{\frac{m}{2}+l-2}$ | $2^t(2^m-2^{m-2l})$                                          |
| $2^{m+t-1} - 2^{m-2} + (-1)^{\frac{m}{2l}} 2^{\frac{m}{2}+l-1}$ | $2^{t}(2^{m-2l-1} + (-1)^{\frac{m}{2l}}2^{\frac{m}{2}-l-1})$ |
| $2^{m+t-1}$                                                     | $2^t - 1$                                                    |

Let m be an even positive integer, two families of binary projective linear code  $\mathbf{C}_1'$  with parameters  $[2^{m-1}-2^{\frac{m-2}{2}},m+1,2^{m-2}-2^{\frac{m-2}{2}}]_2$  and code  $\mathbf{C}_2'$  with parameters  $[2^{m-1}+2^{\frac{m-2}{2}},m+1,2^{m-2}]_2$  were constructed, see [21, Theorem 14.13]. The weights of  $\mathbf{C}_1'$  are  $2^{m-2}-2^{\frac{m-2}{2}},2^{m-2},2^{m-1}-2^{\frac{m-2}{2}},$  and three weights of  $\mathbf{C}_2'$  are  $2^{m-2},2^{m-2}+2^{\frac{m-2}{2}},2^{m-1}+2^{\frac{m-2}{2}}$ . Then two families of three-weight binary  $[2^{m+1}-1-2^{m-1}+2^{\frac{m-2}{2}},m+1,2^m-2^{m-1}+2^{\frac{m-2}{2}}]_2$  and  $[2^{m+1}-1-2^{m-1}-2^{\frac{m-2}{2}},m+1,2^m-2^{m-1}-2^{\frac{m-2}{2}}]_2$  codes are obtained from Corollary 3.1.

For example, when m=4, the three-weight linear  $[21,5,6]_2$  and  $[25,5,10]_2$  codes are obtained. The corresponding optimal minimum distances are 10 and 12, see [25]. Similarly, four-weight linear  $[53,6,22]_2$ ,  $[57,6,26]_2$ ,  $[117,7,54]_2$ ,  $[121,7,58]_2$ ,  $[245,8,118]_2$  and  $[249,8,122]_2$  are obtained. The optimal linear codes in [25] have parameters  $[53,6,26]_2$ ,  $[57,6,28]_2$ ,  $[117,7,58]_2$ ,  $[121,7,60]_2$ ,  $[245,8,122]_2$  and  $[249,8,124]_2$ , respectively. Then these binary linear codes are near optimal.

Then we have the following conclusion.

<span id="page-21-2"></span>**Theorem 5.5** Let m be even, t be a positive integer.

- 1) Two families of three-weight minimal codes  $C_1$  with parameters  $[2^{m+1}-2^{m-1}+2^{\frac{m-2}{2}}-1,m+1,2^{m-1}+2^{\frac{m-2}{2}}]_2$  and  $C_2$  with parameters  $[2^{m+1}-1-2^{m-1}-2^{\frac{m-2}{2}},m+1,2^{m-1}-2^{\frac{m-2}{2}}]_2$  are constructed. The weight distributions are given in Table 16.
- 2) Two families of four-weight minimal codes  $C_3$  with parameters  $[2^{m+t+1} 2^{m-1} 2^{\frac{m-2}{2}} 1, m+t+1, 2^{m+t} 2^{m-2} 2^{\frac{m-2}{2}}]_2$  and  $C_4$  with parameters  $[2^{m+t+1} 2^{m-1} + 2^{\frac{m-2}{2}} 1, m+t+1, 2^{m+t} 2^{m-2} 2^{\frac{m-2}{2}}]_2$  are constructed. The weight distributions are shown in Table 17.

<span id="page-21-0"></span>

| The weights of $C_1$                | The weights of $C_2$                | Weight distribution |
|-------------------------------------|-------------------------------------|---------------------|
| 0                                   | 0                                   | 1                   |
| $2^m - 2^{m-2} + 2^{\frac{m-2}{2}}$ | $2^m - 2^{m-2}$                     | $2^m - 1$           |
| $2^m - 2^{m-2}$                     | $2^m - 2^{m-2} - 2^{\frac{m-2}{2}}$ | $2^m - 1$           |
| $9m-1 + 9\frac{m-2}{2}$             | $9m-1$ $9^{\frac{m-2}{2}}$          | 1                   |

Table 16: Weight distribution of the code in Theorem 5.5 1)

Table 17: Weight distribution of the codes in Theorem 5.5 2)

<span id="page-21-1"></span>

| The weights of $\mathbb{C}_3$           | The weights of $C_4$                    | Weight distribution |
|-----------------------------------------|-----------------------------------------|---------------------|
| 0                                       | 0                                       | 1                   |
| $2^{m+t} - 2^{m-2} + 2^{\frac{m-2}{2}}$ | $2^{m+t} - 2^{m-2}$                     | $2^t(2^m-1)$        |
| $2^{m+t} - 2^{m-2}$                     | $2^{m+t} - 2^{m-2} - 2^{\frac{m-2}{2}}$ | $2^t(2^m-1)$        |
| $2^{m+t} - 2^{m-1} + 2^{\frac{m-2}{2}}$ | $2^{m+t} - 2^{m-1} - 2^{\frac{m-2}{2}}$ | $2^t$               |
| $2^{m+t}$                               | $2^{m+t}$                               | $2^{t}-1$           |

Let m be an odd positive integer, three families of projective linear  $[n', m, \frac{n'-2^{(m-1)/2}}{2}]_2$  code with three nonzero weights,  $\frac{n'-2^{(m-1)/2}}{2}, \frac{n'}{2}, \frac{n'+2^{(m-1)/2}}{2}$ , were constructed in [16, Corollary 11], where  $n'=2^{m-1}-2^{(m-1)/2}, 2^{m-1}$  or  $2^{m-1}+2^{(m-1)/2}$ . For  $n'=2^{m-1}-2^{(m-1)/2}$ , from Corollary 3.1, we have a family of linear  $[2^{m-1}+2^{(m-1)/2}-1, m, 2^{m-2}]_2$  codes. For example, when m=5,7, there are binary linear three-weight codes  $[19,5,8]_2$  and  $[71,7,32]_2$ . The liner code  $[19,5,8]_2$  is optimal, and the optimal distance of  $[71,7]_2$  code is 34, see [25].

From the second conclusion of our complementary theorem, four-weight linear codes with parameters  $[9,4,4]_2$ ,  $[11,4,5]_2$ ,  $[25,5,12]_2$ ,  $[27,5,13]_2$ ,  $[43,6,20]_2$ ,  $[51,6,24]_2$ ,  $[57,6,28]_2$ ,  $[59,6,29]_2$ ,  $[107,7,52]_2$ ,  $[115,7,56]_2$ ,  $[121,7,60]_2$ ,  $[123,7,61]_2$ ,  $[235,8,116]_2$ ,  $[243,8,120]_2$ ,  $[249,8,124]_2$  and  $[251,8,125]_2$  are constructed, all of these codes are optimal. Moreover four-weight linear  $[47,6,22]_2$ ,  $[111,7,54]_2$ ,  $[183,8,88]_2$ ,  $[191,8,92]_2$ ,  $[199,8,96]_2$  and  $[239,8,118]_2$  are constructed, and the optimal distances of corresponding codes are 23, 55, 90, 95, 98 and 119, respectively, see [25].

<span id="page-22-2"></span>**Theorem 5.6** Let m be odd. Let  $n' = 2^{m-1} - 2^{(m-1)/2}$ ,  $2^{m-1}$  or  $2^{m-1} + 2^{(m-1)/2}$ .

- 1) The above projective  $[2^{m-1} + 2^{(m-1)/2} 1, m, 2^{m-2}]_2$  code is a minimal three-weight code. The weight distribution is as in Table 18.
- <span id="page-22-0"></span>2) Let  $t \ge 1$  be an integer. The four-weight minimal code with parameters  $[2^{m+t} - n' - 1, m+t, 2^{m+t-1} - \frac{n'+2^{(m-1)/2}}{2}]_2$  is constructed. The weight distribution is as in Table 19.

Table 18: Weight distribution of the codes in Theorem 5.6 1)

| Weight                  | Weight distribution         |
|-------------------------|-----------------------------|
| 0                       | 1                           |
| $2^{m-2} + 2^{(m-1)/2}$ | $2^{m-2} - 2^{(m-3)/2}$     |
| $2^{m-2} + 2^{(m-3)/2}$ | $2^{m-1}$                   |
| $2^{m-2}$               | $2^{m-2} + 2^{(m-3)/2} - 1$ |

<span id="page-22-1"></span>Table 19: Weight distribution of the codes in Theorem 5.6 2)

| Weight                                 | Weight distribution                        |
|----------------------------------------|--------------------------------------------|
| 0                                      | 1                                          |
| $2^{m+t-1} - \frac{n'-2^{(m-1)/2}}{2}$ | $2^{t}(n'(2^{m}-n')2^{-m}-n'2^{-(m+1)/2})$ |
| $2^{m+t-1} - \frac{n'}{2}$             | $2^{t}(2^{m}-1-n'(2^{m}-n')2^{-(m-1)})$    |
| $2^{m+t-1} - \frac{n'+2^{(m-1)/2}}{2}$ | $2^{t}(n'(2^{m}-n')2^{-m}+n'2^{-(m+1)/2})$ |
| $2^{m+t-1}$                            | $2^t - 1$                                  |

Let  $m \geq 5$  be an odd positive integer, then a family of projective linear  $[2^{m-2}, m-1, 2^{m-3}-2^{\frac{m-3}{2}}]_2$  code with three nonzero weights,  $2^{m-3}-2^{\frac{m-3}{2}}, 2^{m-3}, 2^{m-3}+2^{\frac{m-3}{2}}$ , was constructed in [30, Theorem 3]. Then from Corollary 3.1, we have a family of  $[2^{m+t-1}-2^{m-2}-1, m+t-1, 2^{m+t-2}-2^{m-3}-2^{\frac{m-3}{2}}]_2$  codes, where t is a positive integer. For example, when m=5,7, binary linear four-weight  $[23,5,10]_2$ ,  $[55,6,26]_2$ ,  $[119,7,58]_2$ ,  $[247,8,122]_2$ ,  $[95,7,44]_2$  and  $[223,8,108]_2$  codes are constructed. The optimal distances of corresponding binary linear codes are 11,27,59,123,47 and 111, respectively, see [25].

<span id="page-22-3"></span>**Theorem 5.7** Let  $m \ge 5$  be an odd integer, t be an positive integer. Then we construct a four-weight minimal  $[2^{m+t-1}-2^{m-2}-1,m+t-1,2^{m+t-2}-2^{m-3}-2^{\frac{m-3}{2}}]_2$  codes. The weight distribution is as in the following table.

Table 20: Weight distribution of the code in Theorem 5.7

| Weight | Weight distribution |
|--------|---------------------|
|--------|---------------------|

| 0                                         | 1                                  |
|-------------------------------------------|------------------------------------|
| $2^{m+t-2} - 2^{m-3} + 2^{\frac{m-3}{2}}$ | $2^t(2^{m-4}-2^{\frac{m-5}{2}})$   |
| $2^{m+t-2} - 2^{m-3}$                     | $2^t(3\cdot 2^{m-3}-1)$            |
| $2^{m+t-2} - 2^{m-3} - 2^{\frac{m-3}{2}}$ | $2^t(2^{m-4} + 2^{\frac{m-5}{2}})$ |
| $2^{m+t-2}$                               | $2^t - 1$                          |

Let  $m \geq 3$ , two-weight binary projective linear  $[2^{2m-3}+2^{m-2}-1,2m-2,2^{2m-4}]_2$  codes were given in [51, Theorem 5.2, Corollary 5.4]. Two weights are  $2^{2m-4}$  and  $2^{2m-4}+2^{m-2}$ . Then from Corollary 3.1, let t be a positive integer, we have a family of three-weight projective linear  $[2^{2m+t-2}-2^{2m-3}-2^{m-2},2m+t-2,2^{2m+t-3}-2^{2m-4}-2^{m-2}]_2$  code. When m=3, we obtain linear three-weight  $[22,5,10]_2$ ,  $[54,6,26]_2$ ,  $[118,7,58]_2$  and  $[246,8,122]_2$  codes. All of these codes are optimal, see [25].

<span id="page-23-0"></span>**Theorem 5.8** Let  $m \geq 3$ , t be a positive integer. We construct a family of three-weight minimal  $[2^{2m+t-2}-2^{2m-3}-2^{m-2},2m+t-2,2^{2m+t-3}-2^{2m-4}-2^{m-2}]_2$  codes. The weight distribution is shown in the following table.

Table 21: Weight distribution of the code in Theorem 5.8

| Weight                            | Weight distribution           |
|-----------------------------------|-------------------------------|
| 0                                 | 1                             |
| $2^{2m+t-3}-2^{2m-4}$             | $2^t(2^{2m-3} + 2^{m-2} - 1)$ |
| $2^{2m+t-3} - 2^{2m-4} - 2^{m-2}$ | $2^t(2^{2m-3}-2^{m-2})$       |
| $2^{2m+t-3}$                      | $2^{t} - 1$                   |

Let  $m \geq 3$  be an odd positive integer, a family of ternary three-weight projective linear  $\left[\frac{3^m-1}{2},2m,3^{m-1}-3^{\frac{m-1}{2}}\right]_3$  codes was constructed, see [21, Chapter 8.5]. Three weights are  $3^{m-1}-3^{\frac{m-1}{2}},\ 3^{m-1},\ 3^{m-1}+3^{\frac{m-1}{2}}$ . Then from our complementary theorem, a family of three-weight ternary  $\left[\frac{3^{2m}-3^m}{2},2m,3^{2m-1}-3^{m-1}-3^{\frac{m-1}{2}}\right]_3$  codes is constructed. Three weights are  $3^{2m-1}-3^{m-1}-3^{\frac{m-1}{2}},3^{2m-1}-3^{m-1}$  and  $3^{2m-1}-3^{m-1}+3^{\frac{m-1}{2}}$ . Similarly, the minimality follows from the Ashikhmin-Barg criterion.

When m = 3, a three-weight  $[351, 6, 231]_3$  code is obtained. The Griesmer defect of this code is 4. This three-weight ternary code is near optimal.

<span id="page-23-1"></span>**Theorem 5.9** Let  $m \geq 3$  be odd. We construct a family of three-weight ternary minimal  $\left[\frac{3^{2m}-3^m}{2}, 2m, 3^{2m-1}-3^{m-1}-3^{\frac{m-1}{2}}\right]_3$  codes with the weight distribution as in the following table.

Table 22: Weight distribution of the code in Theorem 5.9

| Weight                                   | Weight distribution                                                                     |
|------------------------------------------|-----------------------------------------------------------------------------------------|
| 0                                        | 1                                                                                       |
| $3^{2m-1} - 3^{m-1} + 3^{\frac{m-1}{2}}$ | $\left(\frac{1}{2}\cdot\left(3^{m-1}+3^{\frac{m-1}{2}}\right)\left(3^m-1\right)\right)$ |
| $3^{2m-1} - 3^{m-1}$                     | $(2 \cdot 3^{m-1} + 1)(3^m - 1)$                                                        |
| $3^{2m-1} - 3^{m-1} - 3^{\frac{m-1}{2}}$ | $\frac{1}{2} \cdot (3^{m-1} - 3^{\frac{m-1}{2}})(3^m - 1)$                              |

Let m be an odd positive integer, then a family of projective linear  $\left[\frac{3^{3m-1}-1}{2}, 3m, 3^{3m-2} - 3^{2m-2}\right]_3$  codes with three nonzero weights,  $3^{3m-2} - 3^{2m-2}$ ,  $3^{3m-2}$ ,  $3^{3m-2} + 3^{2m-2}$ , was constructed in [16, Theorem 16]. From our complementary theorem, we have a family of ternary  $[3^{3m-1}, 3m, 2 \cdot 3^{3m-2} - 3^{2m-2}]_3$  codes. For example, when m = 1, a ternary linear three-weight  $[9, 3, 5]_3$  code is constructed. The optimal distance of the linear  $[9, 3]_3$  code is 6, see [25].

<span id="page-24-0"></span>**Theorem 5.10** Let m be odd. The above projective ternary  $[3^{3m-1}, 3m, 2 \cdot 3^{3m-2} - 3^{2m-2}]_3$  code is a minimal three-weight code. The weight distribution is as in the following table.

Table 23: Weight distribution of the three-weight code in Theorem 5.10

| Weight                        | Weight distribution           |
|-------------------------------|-------------------------------|
| 0                             | 1                             |
| $2 \cdot 3^{3m-2} + 3^{2m-2}$ | $3^{2m} + 3^m$                |
| $2 \cdot 3^{3m-2}$            | $3^{3m} - 2 \cdot 3^{2m} - 1$ |
| $2 \cdot 3^{3m-2} - 3^{2m-2}$ | $3^{2m} - 3^m$                |

When q is a prime power, then two-weight q-ary  $[q^2+1, 4, q^2-q]_q$  codes were constructed in [21, Theorem 13.6]. Two weights are  $q^2-q$  and  $q^2$ . These are well-known ovoid codes. Its dual distance is 4, see [21, Theorem 13.5]. From Corollary 3.1, we have the following result.

**Theorem 5.11** Let q be a prime power. We construct a family of two-weight minimal  $[q^3 + q, 4, q^3 - q^2]_q$  codes. The weight distribution is shown in Table 24.

<span id="page-24-1"></span>Table 24: Weight distribution of the two-weight  $[q^3 + q, 4, q^3 - q^2]_q$  code

| Weight          | Weight distribution |
|-----------------|---------------------|
| 0               | 1                   |
| $q^3 - q^2$     | $(q-1)(q^2+1)$      |
| $q^3 - q^2 + q$ | $(q^2-q)(q^2+1)$    |

For example, when q=4, we get a two-weight  $[68,4,48]_4$  code. The optimal code in [25] is a linear  $[68,4,50]_4$  code. When q=5, we get a two-weight  $[130,4,100]_5$  code. The optimal code in [25] is a linear  $[130,4,103]_5$  code.

Let  $S_1 \subset \mathbf{F}_q^4$  and  $S_2 \subset \mathbf{F}_q^4$  be two linear subspace of the dimension two satisfying  $S_1 \cap S_2 = \mathbf{0}$ . Then using  $\frac{q^2-1}{q-1} + \frac{q^2-1}{q-1}$  columns in these two subspaces as one generator matrix, we have a projective  $[2(q+1),4]_q$  code  $\mathbf{C}$ . Any hyperplane in  $\mathbf{F}_q^4$  intersects such 2(q+1) columns at 2 elements, or q+1+1 elements. Then the code  $\mathbf{C}$  is a two-weight  $[2q+2,4,q]_q$  code. Two weights are q and q. The complementary code is a projective linear  $[q^3+q^2-q-1,4,q^3-2q]_q$  code. This is a two-weight linear code. Two weights are  $q^3-2q$  and  $q^3-q$ . When q=3, this is a two-weight  $[32,4,21]_3$  code. When q=4, this is a two-weight  $[75,4,56]_4$  code. Both codes have optimal parameters, see [25].

In the following table, we list some near-optimal two-weight binary linear codes from the above construction.

Table 25: Two-weight codes

| q | Parameters     | Weights | Optimal parameters |
|---|----------------|---------|--------------------|
| 5 | $[12, 4, 5]_5$ | 5, 10   | $[12, 4, 8]_5$     |
| 7 | $[16, 4, 7]_7$ | 7,14    | $[16, 4, 11]_7$    |
| 8 | $[18, 4, 8]_8$ | 8, 16   | $[18, 4, 13]_8$    |
| 9 | $[20, 4, 9]_9$ | 9, 18   | $[20, 4, 15]_9$    |

**Theorem 5.12** 1) The above projective linear  $[2(q+2), 4, q]_2$  code has the following weight distribution.

Table 26: Weight distribution of the two-weight  $[2q + 2, 4, q]_q$  code

| Weight | Weight distribution |
|--------|---------------------|
| 0      | 1                   |
| q      | $2(q^2-1)$          |
| 2q     | $(q^2-1)^2$         |

2) The above projective linear  $[q^3 + q^2 - q - 1, 4, q^3 - 2q]_q$  code is a minimal two-weight code. The weight distribution is as in Table 27.

<span id="page-25-0"></span>Table 27: Weight distribution of the two-weight  $[q^3 + q^2 - q - 1, 4, q^3 - 2q]_q$  code

| Weight | Weight distribution |
|--------|---------------------|

| 0         | 1           |
|-----------|-------------|
| $q^3 - q$ | $2(q^2-1)$  |
| $q^3-2q$  | $(q^2-1)^2$ |

Let  $m \geq 2$ , q be an prime, then a family of projective linear  $[q^{2m}+1,3m,q^{m-1}(q^{m+1}-q^m-1)]_q$  codes with eight nonzero weights  $q^{m-1}(q^{m+1}-q^m-1), q^{m-1}(q^{m+1}-q^m-1)+1, q^{m-1}(q^{m+1}-q^m-1)+2, q^{2m-1}(q-1), q^{2m-1}(q-1)+1, (q-1)(q^{2m-1}+q^{m-1}), (q-1)(q^{2m-1}+q^{m-1})+1, (q-1)(q^{2m-1}+q^{m-1})+2$  was constructed in [31, Theorem VI.4]. From Corollary 3.1, we have a family of q-ary  $[\frac{q^{3m}-1}{q-1}-q^{2m}-1, 3m, q^{3m-1}-(q-1)(q^{2m-1}+q^{m-1})-2]_q$  codes. For example, when q=2, m=2, linear eight-weight  $[46,6,20]_2$  code is constructed. The optimal distance of  $[46,6]_2$  code is 22, see [25]. When q=3, m=2, a linear  $[282,6,181]_3$  code is constructed. The Griesmer defect of this code is 8.

<span id="page-26-1"></span>**Theorem 5.13** Let  $m \geq 2$  be an integer, q be an prime. The projective q-ary  $\left[\frac{q^{3m}-1}{q-1} - q^{2m} - 1, 3m, q^{3m-1} - (q-1)(q^{2m-1} + q^{m-1}) - 2\right]_q$  code is a minimal eight-weight code. The weight distribution is as in Table 28.

<span id="page-26-0"></span>Table 28: Weight distribution of the eight-weight code in Theorem 5.13

| Weight                                      | Weight distribution                  |
|---------------------------------------------|--------------------------------------|
| 0                                           | 1                                    |
| $q^{3m-1} - q^{m-1}(q^{m+1} - q^m - 1)$     | $(q-1)(q^{m-1}-1)(q^{2m-2}+q^{m-1})$ |
| $q^{3m-1} - q^{m-1}(q^{m+1} - q^m - 1) - 1$ | $q^{2m-2}(q-1)^2(2q^{m-1}-1)$        |
| $q^{3m-1} - q^{m-1}(q^{m+1} - q^m - 1) - 2$ | $q^{2m-2}(q-1)^2(q^m-q^{m-1}+1)$     |
| $q^{3m-1} - q^{2m-1}(q-1)$                  | $q^{2m-1}-1$                         |
| $q^{3m-1} - q^{2m-1}(q-1) - 1$              | $q^{2m} - q^{2m-1}$                  |
| $q^{3m-1} - (q-1)(q^{2m-1} + q^{m-1})$      | $(q^{m-1}-1)(q^{2m-2}-q^m+q^{m-1})$  |
| $q^{3m-1} - (q-1)(q^{2m-1} + q^{m-1}) - 1$  | $q^{2m-2}(q-1)(2q^{m-1}-1)$          |
| $q^{3m-1} - (q-1)(q^{2m-1} + q^{m-1}) - 2$  | $q^{2m-2}(q-1)^2(q^{m-1}-1)$         |

Let m be an odd positive integer, q be an odd prime. A family of projective linear  $[q^m+1,2m,q^{m-1}(q-1)-q^{\frac{m-1}{2}}]_q$  code with nine nonzero weights,  $q^{m-1}(q-1),q^{m-1}(q-1)+1,q^{m-1}(q-1)+2,q^{m-1}(q-1)-q^{\frac{m-1}{2}}(-1)^{\frac{(q-1)(m+1)}{4}},q^{m-1}(q-1)-q^{\frac{m-1}{2}}(-1)^{\frac{(q-1)(m+1)}{4}}+1,q^{m-1}(q-1)-q^{\frac{m-1}{2}}(-1)^{\frac{(q-1)(m+1)}{4}}+2,q^{m-1}(q-1)+q^{\frac{m-1}{2}}(-1)^{\frac{(q-1)(m+1)}{4}},q^{m-1}(q-1)+q^{\frac{m-1}{2}}(-1)^{\frac{(q-1)(m+1)}{4}}+1,q^{m-1}(q-1)+q^{\frac{m-1}{2}}(-1)^{\frac{(q-1)(m+1)}{4}}+2,$  was constructed in [31, Theorem VI.7]. From our complementary theorem, we have a family of q-ary linear  $[\frac{q^{2m}-1}{q-1}-q^m-1,2m,q^{2m-1}-q^{m-1}(q-1)-q^{(m-1)/2}-2]_q$  code. For example, when q=3 and m=3, a ternary linear  $[336,6,220]_3$  codes with weights from 220 to 228 is constructed. In fact, this code is near the optimal code since the Griesmer defect of this code is 4.

<span id="page-27-1"></span>**Theorem 5.14** Let m be an odd positive integer, q be an odd prime. The projective q-ary  $\left[\frac{q^{2m}-1}{q-1}-q^m-1,2m,q^{2m-1}-q^{m-1}(q-1)-q^{(m-1)/2}-2\right]_q$  code is a nine-weight minimal code. The weight distribution is as in Table 29.

Table 29: Weight distribution of the nine-weight code in Theorem 5.14

<span id="page-27-0"></span>

| Weight                                                                       | Weight distribution                                                                           |
|------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------|
| 0                                                                            | 1                                                                                             |
| $q^{2m-1} - q^{m-1}(q-1)$                                                    | $(q^{m-1}-1)(q^{m-2}+1)$                                                                      |
| $q^{2m-1} - q^{m-1}(q-1) - 1$                                                | $q^{m-2}(q-1)(2q^{m-1}+2q-2)$                                                                 |
| $q^{2m-1} - q^{m-1}(q-1) - 2$                                                | $q^{m-2}(q-1)^2(q^{m-1}-1)$                                                                   |
| $q^{2m-1} - q^{m-1}(q-1) + q^{\frac{m-1}{2}}(-1)^{\frac{(q-1)(m+1)}{4}}$     | $\frac{(q-1)(q^{m-1}-1)(q^{m-2}+(-1)^{\frac{(q-1)(m+1)}{4}}q^{\frac{m-1}{2}})}{2}$            |
| $q^{2m-1} - q^{m-1}(q-1) + q^{\frac{m-1}{2}}(-1)^{\frac{(q-1)(m+1)}{4}} - 1$ | $q^{m-2}(q-1)^2(q^{m-1}-1)$                                                                   |
| $q^{2m-1} - q^{m-1}(q-1) + q^{\frac{m-1}{2}}(-1)^{\frac{(q-1)(m+1)}{4}} - 2$ | $\frac{(q-1)^2[q^{m-2}(q^m-q^{m-1}+1)+(-1)\frac{(q-1)(m+1)}{4}q^{\frac{3(m-1)}{2}}]}{2}$      |
| $q^{2m-1} - q^{m-1}(q-1) - q^{\frac{m-1}{2}}(-1)^{\frac{(q-1)(m+1)}{4}}$     | $\frac{(q-1)(q^{m-1}-1)(q^{m-2}+(-1)^{\frac{(q-1)(m+1)+4}{4}}q^{\frac{m-1}{2}})}{2}$          |
| $q^{2m-1} - q^{m-1}(q-1) - q^{\frac{m-1}{2}}(-1)^{\frac{(q-1)(m+1)}{4}} - 1$ |                                                                                               |
| $q^{2m-1} - q^{m-1}(q-1) - q^{\frac{m-1}{2}}(-1)^{\frac{(q-1)(m+1)}{4}} - 2$ | $\frac{(q-1)^2[q^{m-2}(q^m-q^{m-1}+1)+(-1)^{\frac{(q-1)(m+1)+4}{4}}q^{\frac{3(m-1)}{2}}]}{2}$ |

Let  $m \geq 3$  be an odd integer, q be an odd prime. Then there is a projective q-ary linear  $\left[\frac{q^{m-1}-1}{q-1}, m, q^{m-2} - q^{\frac{m-3}{2}}\right]_q$  code with three weights  $q^{m-2} - q^{\frac{m-3}{2}}, q^{m-2}$  and  $q^{m-2} + q^{\frac{m-3}{2}}$  was constructed in [18, Corollary 3]. Then there exists a linear  $[q^{m-1}, m, q^{m-1} - q^{m-2} - q^{\frac{m-3}{2}}]_q$  code with three weights. For example, when q = 3, m = 3, 5, ternary  $[9, 3, 5]_3$  and  $[81, 5, 51]_3$  codes are constructed. When q = 5, m = 3, 5, the quinary  $[25, 3, 19]_5$  and  $[625, 5, 495]_5$  codes are constructed. The optimal distances of  $[9, 3]_3$ ,  $[81, 5]_3$ , and  $[25, 3]_5$  codes are 6, 54, and 20 respectively. The linear  $[625, 5, 495]_5$  code has the Griesmer defect 6.

<span id="page-27-3"></span>**Theorem 5.15** Let  $m \geq 3$  be an odd integer, q be an odd prime. The projective q-ary  $[q^{m-1}, m, q^{m-1} - q^{m-2} - q^{\frac{m-3}{2}}]_q$  code is a minimal three-weight code. The weight distribution is shown in Table 30.

<span id="page-27-2"></span>Table 30: Weight distribution of the three-weight code in Theorem 5.15

| Weight                                  | Weight distribution                        |
|-----------------------------------------|--------------------------------------------|
| 0                                       | 1                                          |
| $q^{m-1} - q^{m-2} + q^{\frac{m-3}{2}}$ | $\frac{q-1}{2}(q^{m-1}+q^{\frac{m-1}{2}})$ |
| $q^{m-1} - q^{m-2}$                     | $q^{m-1} - 1$                              |
| $q^{m-1} - q^{m-2} - q^{\frac{m-3}{2}}$ | $\frac{q-1}{2}(q^{m-1}-q^{\frac{m-1}{2}})$ |

Let  $m \geq 2$  be even, q be an odd prime. Then there is a projective q-ary linear  $\left[\frac{q^{m-1}-1}{q-1}-(-1)^{\left(\frac{q-1}{2}\right)^2\frac{m}{2}}q^{\frac{m-2}{2}},m\right]_q$  code with two weights  $q^{m-2}$  and  $q^{m-2}-(-1)^{\left(\frac{q-1}{2}\right)^2\frac{m}{2}}q^{\frac{m-2}{2}}$  was constructed in [18, Corollary 4]. Then we can construct a linear  $\left[q^{m-1}+(-1)^{\left(\frac{q-1}{2}\right)^2\frac{m}{2}}q^{\frac{m-2}{2}},m\right]_q$  code with two weights. For example, when  $q=3,\ m=4,6$ , there are ternary  $[30,4,18]_3$  and  $[234,6,153]_3$  codes. The optimal distances of codes  $[30,4]_3$  and  $[234,6]_3$  are 19 and 155, respectively. When  $q=5,\ m=4$ , there is a quinary  $[130,4,100]_5$  code. The optimal code in [25] is a  $[130,4,103]_5$  code.

<span id="page-28-1"></span>**Theorem 5.16** Let  $m \ge 4$  be even, q be an odd prime. The projective  $[q^{m-1} + (-1)^{(\frac{q-1}{2})^2 \frac{m}{2}} \cdot q^{\frac{m-2}{2}}, m]_q$  code is a minimal two-weight code. The weight distribution is given in Table 31.

Table 31: Weight distribution of the two-weight code in Theorem 5.16

<span id="page-28-0"></span>

| Weight                                                                  | Weight distribution                                                          |
|-------------------------------------------------------------------------|------------------------------------------------------------------------------|
| 0                                                                       | 1                                                                            |
| $(q-1)q^{m-2}$                                                          | $q^{m-1} - (-1)^{(\frac{q-1}{2})^2 \frac{m}{2}} q^{\frac{m-2}{2}} (q-1) - 1$ |
| $(q-1)q^{m-2} + (-1)^{(\frac{q-1}{2})^2 \frac{m}{2}} q^{\frac{m-2}{2}}$ | $(q-1)(q^{m-1}+(-1)^{(\frac{q-1}{2})^2\frac{m}{2}}q^{\frac{m-2}{2}})$        |

To the best of knowledge, most families of few-weight linear codes constructed in this paper have not been reported in the literature, see [21, Chapter 4, Chapter 14], [9, 10, 17, 18, 29] and references therein.

# 6 Few-weight linear codes from concatenated and complementary codes

It is obvious that t-weight linear codes can be obtained from the concatenation of t'-weight codes over larger fields. For example,  $q=2^s$ , let the outer code be the ovoid code  $[q^2+1,4,q^2-q]_q$  with two weights  $q^2-q$  and  $q^2$ , and the inner code be the the simplex  $[2^s-1,s,2^{s-1}]_2$  code with one weight  $2^{s-1}$ , the concatenation code is a linear  $[(2^s-1)(4^s+1),4s,2^{s-1}(4^s-2^s)]_2$  code  ${\bf C}$ . A nonzero codeword in  ${\bf C}$  has weight  $2^{s-1}(q^2-q)=2^{s-1}(4^s-2^s)$  or  $2^{3s-1}$ , since each nonzero coordinate in  ${\bf F}_{s^s}$  is replaced by a weight  $2^{s-1}$  codeword in the inner code. This code is projective, following the dual code described in [12]. Therefore we have the following result.

<span id="page-28-2"></span>**Theorem 6.1** Let s be a positive integer, we construct a linear two-weight  $[(2^s - 1)(4^s + 1), 4s, 2^{s-1}(4^s - 2^s)]_2$  code. The weight distribution is as in the following table.

Table 32: Weight distribution of the code in Theorem [6.1](#page-28-2)

| Weight | Weight distribution |
|--------|---------------------|
| 0      | 1                   |
| 3s−1   | (2s −               |
| 2      | 1)(4s + 1)          |
| 3s−1 − | (4s −               |
| 2s−1   | s                   |
| 2      | )(4s + 1)           |
| 2      | 2                   |

When s = 2, C is a two-weight linear [51, 8, 24]<sup>2</sup> code. Two weights are 24 and 32. This is an optimal code, see [\[25\]](#page-35-11). Notice that the optimal [51, 8, 24]<sup>2</sup> code in [\[25\]](#page-35-11) is a special cyclic code with two weights 24 and 32. When s = 3, C is a two-weight linear [455, 12, 224]<sup>2</sup> code. Its Griesmer defect is 4.

Corollary 6.1 The complementary code is a linear two-weight [2<sup>4</sup><sup>s</sup> − 1 − (2<sup>s</sup> − 1)(4<sup>s</sup> + 1), 4s, 2 <sup>4</sup>s−<sup>1</sup> − 2 3s−1 ]<sup>2</sup> code.

When s = 2, the complementary code of C is a linear two-weight [204, 8, 96]<sup>2</sup> code. Two weights are 96 and 104. The optimal [204, 8]<sup>2</sup> code in [\[25](#page-35-11)] has the minimum distance 100.

Similarly, we have a two-weight linear [(2<sup>s</sup> −1)(2<sup>s</sup>+1 + 2), 4s, 2 2s−1 ]<sup>2</sup> code from the outer [2q + 2, 4, q]<sup>q</sup> code in Section 5. Two weights are 2<sup>2</sup>s−<sup>1</sup> and 2<sup>2</sup><sup>s</sup> . When s = 2, this is a linear two-weight [30, 8, 8]<sup>2</sup> code. Two weights are 8 and 16. The optimal distance of [30, 8]<sup>2</sup> code in [\[25\]](#page-35-11) is 12. From the dual code described in [\[12](#page-34-14)], this code is projective code. The complementary code is a linear [225, 8, 112]<sup>2</sup> code. Two weights are 112 and 120. This is an optimal code, see [\[25](#page-35-11)].

## 7 Minimal binary linear codes with optimal and near optimal parameters

From projective linear anticodes constructed in Subsection 4.2 and Theorem 3.1, we have the following result. Actually, these codes in the case t = 0, have been constructed in [\[48\]](#page-37-6) as optimal locally reparable codes.

Theorem 7.1 Let s be a positive integer and t be a nonnegative integer. Then an explicit binary linear [2<sup>2</sup>s−1+<sup>t</sup> − s(2s − 1) − 1, 2s − 1 + t, 2 <sup>2</sup>s−2+<sup>t</sup> − s 2 ]<sup>2</sup> is constructed.

For example, when s = 3, we get a projective linear [15, 5]<sup>2</sup> code with the maximum weight 9. Then binary linear [16, 5, 7]2, [48, 6, 23]2, [112, 7, 55]<sup>2</sup> and [240, 8, 119]<sup>2</sup> codes are constructed. These codes are almots optimal. When s = 4, we get a projective linear [28, 7]<sup>2</sup> code with the maximum weight 16. Then binary linear [99, 7, 48]<sup>2</sup> and [227, 8, 112]<sup>2</sup> codes are constructed. These two binary codes are optimal codes, as documented in [\[25\]](#page-35-11). Notice that these codes were not reported in [24]. These codes were reported in [48, Table 1] as optimal locally reparable codes.

Similarly, when k=7 is odd, we construct a binary linear  $[21,6,6]_2$  code with the maximum weight 12. Then we have a binary projective linear  $[42,6,20]_2$  code,  $[106,7,52]_2$  code, and  $[234,8,116]_2$  code. Comparing with [25], these three binary linear codes are optimal.

From the binary three-weight projective linear  $[70, 7, 32]_2$  code constructed in Subsection 4.2, we construct a binary  $[185, 8, 88]_2$  code, the corresponding optimal minimum distance is 91, see [25].

We show that some binary projective linear codes constructed in this section are actually minimal codes. Let **C** be the binary projective linear  $\left[\frac{k(k-1)}{2}, k-1, k-1\right]_2$  code constructed in [53]. The maximum weight of this code is  $\frac{k^2}{2}$ , when k is even, or  $\frac{k^2-1}{4}$  when k is odd. We have the following result.

Corollary 7.1 Let  $C_1$  be the complementary  $[2^{k-1}-1-\frac{k(k-1)}{2},k-1,2^{k-2}-\delta(\mathbf{C})]_2$  code described as above. Then  $C_1$  is a minimal code, when  $k \geq 3$ . Here  $\delta(\mathbf{C}) = \frac{k^2}{4}$  if k is even, or  $\delta(\mathbf{C}) = \frac{k^2-1}{4}$  if k is odd.

**Proof.** The code  $C_1$  satisfies the Ashikhmin-Barg criterion.

Corollary 7.2 Let  $C_1$  be the complementary  $[2^{k-1+t}-1-\frac{k(k-1)}{2},k-1+t,2^{k-2+t}-\delta(\mathbf{C})]_2$  code described as above. Then  $C_1$  is a minimal code. Here  $\delta(\mathbf{C})=\frac{k^2}{4}$  if k is even, or  $\delta(\mathbf{C})=\frac{k^2-1}{4}$  if k is odd.

**Proof.** The conclusion follows from the Ashikhmin-Barg criterion immediately.

From Corollary 7.1 and 7.2, many minimal binary linear codes with optimal or almost optimal parameters are constructed, see Table 3 of Section 1. Most codes constructed in previous section satisfy the Ashikhmin-Barg criterion, they are minimal linear codes.

## 8 Complementary MDS codes

We observe the Reed-Solomon  $[q, k, q + 1 - k]_q$  code. When  $k \geq 2$ , this is a projective linear code. Then the complementary code is a q-ary linear  $[\frac{q^k-1}{q-1} - q, k, q^{k-1} - q]_q$  code. We call this code a complementary Reed-Solomon code. Since the maximum weight is  $q^{k-1} - q + k - 1$ , this code satisfies the Ashikhmin-Barg condition, this is a minimal q-ary

linear code. On the other hand, we have

$$q^{k-1} - q + q^{k-2} - 1 + q^{k-3} + \dots + 1 = \frac{q^k - 1}{q - 1} - q - 1.$$

This is an almost Griesmer code. The diameter of the complementary Reed-Solomon code is  $q^{k-1} - q + k - 1$ . Then the sum

$$\sum_{i=0}^{k-1} \left\lfloor \frac{\delta(\mathbf{C})}{q^i} \right\rfloor = \frac{q^k - 1}{q - 1} - q + k - 1.$$

From complementary theorem, we have the following result.

**Theorem 8.1** Let k be a positive integer and h be a non-negative integer. A complementary Reed-Solomon  $\left[\frac{q^{k+h}-1}{q-1}-q,k+h,q^{k+h-1}-q\right]_q$  code is constructed. It is a minimal k-weight almost Griesmer code when h=0 and it is a (k+1)-weight almost Griesmer code when h>0. As an anticode, it has a difference k-1 to the antiGriesmer bound.

In the table 4 of Section 1, we list some minimal optimal complementary Reed-Solomon code.

**Corollary 8.1** Let q be a prime power. Then we construct a three-weight almost Griesmer  $[q^2 + 1, 3, q^2 - q]_q$  code. Three weights are  $q^2 - q$ ,  $q^2 - q + 1$  and  $q^2 - q + 2$ .

In [31, Theorem V.I], three-weight  $[p^m+1, m+1, p^{m-1}(p-1)]_p$  codes were constructed. Three weights are  $p^{m-1}(p-1)$ ,  $p^{m-1}(p-1)+1$  and  $p^m$ . When m=2, it is clear that our three-weight codes are different to their codes.

Corollary 8.2 A complementary Reed-Solomon  $[q^3+q^2+1,4,q^3-q]_q$  code is a minimal 4-weight almost Griesmer code. Four weights are  $q^3-q$ ,  $q^3-q+1$ ,  $q^3-q+2$  and  $q^3-q+3$ .

Similarly, we can construct complementary code of the trivial MDS  $[k, k, 1]_q$  code. Then we have the following result. The first conclusion is actually a special case of projective Solomon-Stiffler codes, see [49].

**Theorem 8.2** A complementary MDS  $[\frac{q^k-1}{q-1}-k,k,q^{k-1}-k]_q$  code is a minimal k-weight Griesmer code, if k < q. As an anticode, it has a difference k-1 to the antiGriesmer bound, if k > q. A complementary MDS  $[\frac{q^k-1}{q-1}-k,k,q^{k-1}-k]_q$  code is a minimal almost Griesmer k-weight code, if  $q \le k < 2q-1$ .

Corollary 8.3 Let q be a prime power satisfying  $q \ge 4$ . Then we construct a minimal three-weight Griesmer  $[q^2 + q - 2, 3, q^2 - 3]_q$  code.

From Corollary 8.3, we construct optimal minimal linear  $[18, 3, 13]_4$  code,  $[28, 3, 22]_5$ code,  $[54, 3, 46]_7$  code,  $[70, 3, 61]_8$  code and  $[88, 3, 78]_9$  code, see [25].

#### *l*-strongly walk-regular graphs 9

In this section, based on binary three-weight projective linear codes constructed in Section 5, we present some l-SWRGs by applying the construction in [37].

<span id="page-32-0"></span>**Lemma 9.1** ([41], Theorem 5.1) Let C be a binary projective linear three-weight  $[n, k]_2$ code with weights  $0 = w_0 < w_1 < w_2 < w_3$  satisfying

$$w_1 + w_2 + w_3 = \frac{3n}{2}.$$

Then the coset graph  $\Gamma_{\mathbf{C}^{\perp}}$  of the dual code of  $\mathbf{C}$  is a 3-SWRG. Furthermore, if

$$w_2 = \frac{n}{2},$$

then  $\Gamma_{\mathbf{C}^{\perp}}$  is an l-SWRG for every odd  $l \geq 3$ . Moreover, the spectrum of  $\Gamma_{\mathbf{C}^{\perp}}$  is given by  $\{(n-2w_i)^{A_{w_i}}|0\leq i\leq 3\}$ . Additionally, the parameters  $\lambda_l$ ,  $\mu_l$ ,  $\nu_l$  of  $\Gamma_{\mathbf{C}^{\perp}}$  are related to its eigenvalues in the following way:

- 1) The eigenvalues  $\{(n-2w_i)|1 \leq i \leq 3\}$  are the roots of the equation  $x^l + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + (\mu_l \lambda_l)x + ($  $(\mu_l - \nu_l) = 0;$
- 2) The code length n satisfies  $n^l + (\mu_l \lambda_l)n + (\mu_l \nu_l) = \mu_l v$ , where v is the number of vertices of  $\Gamma_{\mathbf{C}^{\perp}}$ , that is, the number of cosets of the code  $\mathbf{C}^{\perp}$ .

Then combining Theorem 5.1, Theorem 5.2, Theorem 5.3 and Theorem 5.4, as well as Lemma 9.1, we have the following result.

**Theorem 9.1** Let C be a binary linear  $[n,k]_2$  code. Let  $l \geq 3$  be an odd positive integer. The coset graphs  $\Gamma_{\mathbf{C}^{\perp}}$  of the dual codes of the following binary three-weight projective linear codes C are l-SWRGs. The spectrum of  $\Gamma_{\mathbf{C}^{\perp}}$  is given by

$${n^1, (n-2w_1)^{A_{w_1}}, 0^{A_{w_2}}, -(n-2w_1)^{A_{w_3}}}.$$

Specifically, when l=3, the parameters  $(\lambda_l, \mu_l, \nu_l)$  of the 3-SWRG with  $2^k$  vertices are given by  $\lambda_3 = \mu_3 + (n-2w_1)^2$ ,  $\mu_3 = \nu_3 = \frac{4nw_1(n-w_1)}{2^k}$ .

1) A family of linear  $[2^{2m} - 2^m, 2m, 2^{2m-1} - 2^{m-1} - 2^{\frac{m-1}{2}}]_2$  codes, where  $m \geq 3$  is odd;
2) A family of linear  $[2^{3m} - 2^{2m}, 3m, 2^{3m-1} - 2^{2m-1} - 2^{m-1}]_2$  codes, where  $m \geq 2$ ;

- 3) A family of linear  $[2^{m-1}, m, 2^{m-2} 2^{\frac{m+r-4}{2}}]_2$  codes, where  $\frac{m}{r}$  is odd; 4) A family of linear  $[2^{m-1} + 2^{\frac{m}{2}+r-1}, m, 2^{m-2}]_2$  codes, where  $\frac{m}{r}$  is even.

**Proof.** Based on these theorems in Section 5 and their corresponding weight distribution tables, it is easy to verify that the above four families of codes are all three-weight binary projective linear codes. Their three weights satisfy above equations in Lemma 9.1. Then the conclusion is proved.

**Example 9.1** Let **C** be a binary three-weight projective linear code with parameters  $[56, 6, 26]_2$ , which is constructed in Theorem 5.1. Three weights are  $w_1 = 26$ ,  $w_2 = 28$ ,  $w_3 = 30$ . The weight distribution is as follows,  $A_{w_1} = 7$ ,  $A_{w_2} = 35$ ,  $A_{w_3} = 21$ . Then the coset grapy  $\Gamma_{\mathbf{C}^{\perp}}$  is an l-SWRG for every  $l \geq 3$ . The spectrum of  $\Gamma_{\mathbf{C}^{\perp}}$  is  $\{56^1, 4^7, 0^{35}, -4^{21}\}$ . When l = 3, the parameters of the 3-SWRG  $\Gamma_{\mathbf{C}^{\perp}}$  with 64 vertices are (2746, 2730, 2730).

## 10 Conclusions

In this paper, we revisited and extended the idea of linear codes from projective linear anticodes in [24]. We gave an antiGriesmer bound on diameters of projective linear anticodes and gave many infinite families of codes attaining or close to the bound. A complementary theorem was proved for t-weight projective linear codes. Then from one t-weight projective linear code, infinitely many (t+1)-weight projective linear codes were constructed and their weight distributions were determined.

In summary, the following codes were constructed in this paper.

- 1) Many t-weight binary linear codes with new parameters were constructed. Many codes in these families are optimal, almost optimal or near optimal. These codes include almost Griesmer complementary Reed-Solomon codes.
- 2) We constructed many optimal or near optimal minimal linear codes. These codes include complementary MDS codes.
- 3) We gave several families of l-strongly walk-regular graphs for each odd  $l \geq 3$ , from complementary three-weight binary projective linear codes constructed in this paper.

## References

- <span id="page-33-0"></span>[1] R. Ahlswede and L. Khachatrian, The diametric theorem in Hamming spaces C optimal anticodes, Advances in Applied Mathematics, vol. 20, pp. 429-449, 1998.
- <span id="page-33-1"></span>[2] R. Ahlswede, H. Aydinian, and L. Khachatrian, On perfect codes and related concepts, Designs, Codes and Cryptography, vol. 22, no. 3, pp. 221-237, 2001.

- <span id="page-34-10"></span>[3] G. N. Alfarano, M. Borello, A. Neri and A. Ravaganani, Three combinatorial aspects on minimal codes, SIAM Journal on Discrete Mathematics, vol. 36, pp. 461-489, 2022.
- <span id="page-34-12"></span>[4] N. Alon, A. Bishnoi, S. Das and A. Neri, Strong blocking sets and minimal codes from expander graphs, [arXiv:2305.15297,](http://arxiv.org/abs/2305.15297) 2023.
- <span id="page-34-9"></span>[5] A. Ashikhmin and A. Barg, Minimal vectors in linear codes, IEEE Transactions on Information Theory, vol. 44, no. 5, pp. 2010-2017, 1998.
- <span id="page-34-4"></span>[6] E. F. Assmus and H. F. Masson, New 5-designs, Journal of Combinatorial Theory, vol. 6, pp. 122-151, 1969.
- <span id="page-34-2"></span>[7] L. D. Baumert and R. J. McEliece, A not on the Griesmer bound, IEEE Transactions on Information Theory, vol. 19, no. 1, pp. 134-135, 1973.
- <span id="page-34-13"></span>[8] E. Byrne, H. Gluesing-Luerssen and A. Ravagnani, Anticodes in the sum-rank metric, Linear Algebras and its Applications, vol. 643, pp. 80-98, 2022.
- <span id="page-34-5"></span>[9] A. R. Calderbank, and J. -M. Goethals, Three-weight codes and association schemes, Philipps Journal of Research , vol. 39, pp. 143-152, 1984.
- <span id="page-34-6"></span>[10] C. Carlet, P. Charpin and V. Zinoviev, Codes,bent functions and permutations suitable for DES-like cryptosystems, Designs, Codes and Cryptography, vol. 15, pp. 125- 156, 1998.
- <span id="page-34-11"></span>[11] S. Chang and J. Y. Hyun, Linear codes from simplicial complexes, Designs, Codes and Cryptography, vol. 86, pp. 2167-2181, 2018.
- <span id="page-34-14"></span>[12] H. Chen, S. Ling and C. Xing, Asymptotically good quantum codes exceeding the Ashikhmin-Litsyn-Tsfasamn bound, IEEE Transactions on Information Theory, vol. 47, no. 5, pp. 2055-2058, 2001.
- <span id="page-34-0"></span>[13] H. Chen, Many non-Reed-Solomon type MDS codes from arbitrary genus alegbraic curves, IEEE Transactions on Information Theory, early access, 2023.
- <span id="page-34-8"></span>[14] G. D. Cohen and A. Lempel, Linear intersecting codes, Discrete Mathematics, vol. 56, pp. 35-43, 1984.
- <span id="page-34-1"></span>[15] P. Delsarte, The association schemes of coding theory, Phillips Journal of Research, 1973.
- <span id="page-34-3"></span>[16] C. Ding, Linear codes from 2-designs, IEEE Transactions on Information Theory, vol. 61, no. 8, pp. 3265-3275, 2015.
- <span id="page-34-7"></span>[17] K. Ding, and C. Ding, Binary linear codes with three weights, IEEE Communication Letters, vol. 18, no. 11, pp. 1679-1882, 2014.

- <span id="page-35-6"></span>[18] K. Ding, and C. Ding, A class of two-weight and three-weight codes and their applications in secret sharing, IEEE Transactions on Information Theory, vol. 61, no. 11, pp. 5835-5842, 2015.
- <span id="page-35-9"></span>[19] C. Ding, Z. Heng and Z. Zhou, Minimal binary linear codes, IEEE Transactions on Information Theory, vol. 64, pp. 6536-6545, 2018.
- [20] C. Ding and Z. Heng, The subfield codes of ovoid codes, IEEE Transactions on Information Theory, vol. 65, pp. 4715-4729, 2019.
- <span id="page-35-5"></span>[21] C. Ding and C. Tang, Designs from linear codes, World Scientific Publ., second edition, 2023.
- <span id="page-35-1"></span>[22] P. Erd¨os, Chao Ko and R. Rado, Intersection theorems of systems of finite sets, Quarter Journal of Mathemtics, Oxford Series, vol. 12, 1961.
- <span id="page-35-0"></span>[23] S. R. Ghorpade and G. Lachaud, Hyperplane sections of Grassmannians and number of MDS linear codes, Finite Fields and Their Applications, vol. 7, pp. 468-506, 2001.
- <span id="page-35-2"></span>[24] P. G. Farrell, An introduction to anticodes, eds: G. Longo, Algebraic coding theory applications, 1973.
- <span id="page-35-11"></span>[25] M. Grassl, Bounds on the minimum distance of linear codes and quantum codes, Online available at [http://www.codetables.de.](http://www.codetables.de)
- <span id="page-35-3"></span>[26] J. H. Griesmer, A bound for error-correcting code, IBM Journal of Research and Development., vol. 4, pp. 532-542, 1960.
- <span id="page-35-12"></span>[27] T. Helleseth and P. V. Kumar, The weight hierarchy of the Kasami codes, Discrte Mathematics, vol. 145, pp. 133-143, 1995.
- <span id="page-35-10"></span>[28] T. Helleseth, Projective codes meeting the Griesmer bound, Discrete Mathematics, vol. 106/107, pp. 265-271, 1985.
- <span id="page-35-7"></span>[29] Z. Heng and Q. Yue, Several classes of cylic codes with either optimal three weights or a few weights, IEEE Transactions on Information Theory, vol. 62, no. 8, pp. 4501-4513, 2016.
- <span id="page-35-13"></span>[30] Z. Heng, W. Wang and Y. Wang, Projective binary linear codes from special Boolean functions, Applied Algebra in Engineering, Communication and Computing, vol. 32, pp. 521-552, 2021.
- <span id="page-35-8"></span>[31] Z. Heng and C. Ding, The subfield codes of some [q + 1, 2, q] MDS codes, IEEE Transactions on Information Theory, vol. 68, no. 6, pp. 3643-3656, 2022.
- <span id="page-35-4"></span>[32] Z. Hu, N. Li, X. Zeng, L. Wang and X. Tang, The subfield-based construction of optimal linear codes over finite fields, IEEE Transactions on Information Theory, vol. 69, no. 7, pp. 4408-4421, 2023.

- <span id="page-36-3"></span>[33] Z. Hu, Y. Xu, N. Li, X. Zeng, L. Wang and X. Tang, New constructions of optimal linear codes from simplicial complexes, IEEE Transactions on Information Theory, vol. 70, no. 3, pp. 1823-1835, 2024.
- <span id="page-36-7"></span>[34] T.-Y. Huang, Decoding linear block codes for minimizing word error rate, IEEE Transactions on Information Theory, vol. 25, pp. 733-737, 1979.
- <span id="page-36-2"></span>[35] W. C. Huffman and V. Pless, Fundamentals of error-correcting codes, Cambridge University Press, Cambridge, U. K., 2003.
- <span id="page-36-6"></span>[36] T. Kasami, Weight distribution formula for some class of cyclic codes, Technical Report R-285, (AD 632574), Coordinated Science Laboratory, University of Illinois, Urbana, IL, 1966
- <span id="page-36-9"></span>[37] M. Kiermaier, S. Kurz, P. Sol´e and M. Stoll, On strongly walk regular graphs, triple sum sets and their codes, Designs, Codes and Cryptography, vol. 91, pp. 645-675, 2023.
- <span id="page-36-1"></span>[38] D. J. Kleitman, On a combinatorial conjecture of Erd¨os, Journal of Combinatorial Theory, vol. 1, pp. 209-214, 1966.
- <span id="page-36-11"></span>[39] Y. Liu, C. Ding and C. Tang, Shortened linear codes over finite fields, IEEE Transactions on Theory, vol. 67, no. 8, pp. 5119-5132, 2021.
- <span id="page-36-4"></span>[40] G. Luo and S. Ling, Applications of optimal p-ary linear codes to alphebet-optimal locally reparable codes, Designs, Codes and Cryptography, vol. 90, pp.1271-1287, 2022.
- <span id="page-36-10"></span>[41] N. K. Mondal and Y. Lee, Optimal binary few-weight codes using a mixed alphabet ring and simplicial complexes, IEEE Transactions on Information Theory, early access, 2024.
- <span id="page-36-0"></span>[42] F. J. MacWilliams and N. J. A. Sloane, The Theory of error-correcting codes, 3rd Edition, North-Holland Mathematical Library, vol. 16. North-Holland, Amsterdam, 1977.
- <span id="page-36-5"></span>[43] S. Mesnager and A. Sinak, Several classes of minimal linear codes with few weights from weakly regular plateaued functions, IEEE Transactions on Information Theory, vol. 66, pp. 2296-2310, 2020.
- <span id="page-36-8"></span>[44] S. Mesnager, Y. Qi, H. Ru, and C. Tang, Minimal linear codes from characteristic functions, IEEE Transactions on Information Theory, vol. 66, pp. 5404-5413, 2020.
- [45] S. Mesnager, L. Qian X. Cao and M. Yuan, Sveral families of minimal binary linear codes from two-to-one functions, IEEE Transactions on Information Theory, vol. 69, pp. 3285-3301, 2023.

- <span id="page-37-5"></span>[46] S. M. Reddy, On block codes with specified maximum distances, IEEE Transactions on Information Theory, vol. 18, no. 6, pp. 823-824, 1972.
- <span id="page-37-2"></span>[47] J. H. van Lint, Introduction to the coding theory, GTM 86, Third and Expanded Edition, Springer, Berlin, 1999.
- <span id="page-37-6"></span>[48] N. Silberstein and A. Zeh, Ancode-based locally repairable codes with high availability, Designs, Codes and Cryptography, vol. 86, pp. 419-445, 2018.
- <span id="page-37-0"></span>[49] G. Solomon and J. J. Stiffler, Algebraically punctured cyclic codes, Information and Controll, vol. 8, pp. 170-179, 1965.
- <span id="page-37-4"></span>[50] E. R. van Dam and G. R. Omidi, Strongly walk-regular graphs, Journal of Combinatorial Theory, Series A, vol. 120, pp. 803-810, 2013.
- <span id="page-37-8"></span>[51] X. Wang, D. Zheng and Y. Zhang, Binary linear codes with few weights from Boolean functions, Designs, Codes and Cryptography, vol. 89, pp. 2009-2030, 2021.
- <span id="page-37-1"></span>[52] L. Xu, S. Mesnager, R. Luo and H. Yan, Subfield codes of several few-weight linear codes parametrized by functions and their consquences, IEEE Transactions on Information Theory, vol. 70, no. 6, pp. 3941-3964, 2024.
- <span id="page-37-3"></span>[53] W. Zhang, H. Yan and H. Wei, Four families of miniaml binary codes with  $\frac{w_{min}}{w_{max}} < \frac{1}{2}$ , Applied Algebra in Engineering, Communication and Computing, vol. 30, pp. 175-184, 2019.
- <span id="page-37-7"></span>[54] Z. Zhou, X. Li, C. Tang and C. Ding, Binary LCD codes and self-orthogonal codes via a generic construction, IEEE Transactions on Information Theory, vol. 69, no. 1, pp. 16-27, 2019.