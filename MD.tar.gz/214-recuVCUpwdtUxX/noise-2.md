# On duality of four dimensional N = 1 gauge theory

## Yuanyuan Fang, Jing Feng, Dan Xie

*Department of Mathematics, Tsinghua University, Beijing, 100084, China*

Abstract: We show that Seiberg-like duality of N = 1 gauge theory coupled with tensor chiral fields and fundamental chiral fields works if the meson spectrum built from the tensor fields takes particular form: a) It should be truncated; b) The R charges of tensor fields {Ra} and the truncated mesons {Rj} take very special values. The meson spectrum so that the duality works is encoded elegantly in the factorization of the polynomial y <sup>n</sup>−1 = Φ+Φ−. Our consideration covers many known N = 1 dualities and generates a large class of new examples.

|   | Contents |              |                                                                        |    |  |
|---|----------|--------------|------------------------------------------------------------------------|----|--|
| 1 |          | Introduction |                                                                        | 1  |  |
| 2 |          |              | General discussion                                                     | 3  |  |
|   | 2.1      |              | Basic picture of N = 1 duality                                         | 3  |  |
|   | 2.2      |              | Truncation by superpotential                                           | 5  |  |
|   | 2.3      |              | Truncation from equality of superconformal index                       | 7  |  |
|   | 2.4      |              | More dualities                                                         | 9  |  |
|   | 2.5      |              | General solutions                                                      | 11 |  |
| 3 |          |              | Duality for simple gauge group                                         | 14 |  |
|   | 3.1      |              | Classical gauge group with adjoint chiral                              | 14 |  |
|   | 3.2      |              | General representations                                                | 16 |  |
|   | 3.3      |              | Exceptional gauge group                                                | 17 |  |
| 4 |          |              | Duality for semi-simple gauge groups                                   | 19 |  |
| 5 |          | Conclusion   |                                                                        | 20 |  |
| A |          |              | Gauge invariant operators                                              | 22 |  |
| B |          |              | Anomaly computations for classical groups                              | 23 |  |
|   | B.1      |              | Adjoint matter                                                         | 23 |  |
|   | B.2      |              | Other matter                                                           | 25 |  |
|   |          | B.2.1        | B,D gauge group with symmetric matter                                  | 25 |  |
|   |          | B.2.2        | C gauge group with anti-symmetric matter                               | 26 |  |
|   |          | B.2.3        | A gauge group with a pair of symmetric (and its conjugate) (X, X˜)     | 26 |  |
|   |          | B.2.4        | A gauge group with pairs of anti-symmetric (and its conjugate) (X, X˜) | 27 |  |
| C |          |              | Formula for superconformal index                                       | 28 |  |

## <span id="page-1-0"></span>1 Introduction

One of the most important discoveries in the study of 4d N = 1 non-abelian gauge theory was the electric-magnetic duality of SQCD found by Seiberg [\[1\]](#page-28-1). The basic features of the Seiberg duality are the following: a) The gauge group is different in the dual description; b) The composite chiral operator of one theory is mapped to the elementary field (gauge singlet) of the dual theory; c) A superpotential is needed so that the composite chiral operators of the dual theory are projected out. Seiberg duality plays a crucial role in understanding the strong coupling dynamics of non-abelian gauge theory [\[2\]](#page-29-0).

Seiberg duality was soon generalized to many other models: theory with one adjoint chiral superfield [\[3,](#page-29-1) [4](#page-29-2)], and theory with two adjoint chiral superfields [\[5\]](#page-29-3), and many other similar models in [\[6](#page-29-4)[–11](#page-29-5)]. The basic picture of the duality is the same as the Seiberg duality, for example, the composite chiral operators are mapped to the elementary fields, and often a dual superpotential is needed.

A crucial ingredient in all the above models is the following: there is a truncation for the chiral spectrum of the mesons built from the tensor field (such as the adjoint chiral of. The truncation was often introduced by a superpotential for the tensor fields, for example, the A<sup>k</sup> or (Dk+1, k odd) type superpotential for the adjoint chirals of N = 1 theory. However, one already needs to impose the so-called quantum constraints to truncate the meson spectrum. Such a strategy has been used in [\[12](#page-29-6)] to find the dual description of the so-called E<sup>7</sup> model [\[13](#page-29-7)] for adjoint SQCD.

The purpose of this paper is to explore the following question: for what kind of truncation of meson spectrum one can find a sensible dual theory. Our main discovery is that the duality is essentially controlled by the truncation of the meson spectrum built from tensorial matter. Assuming our model is given by SU(Nc) gauge group coupled with N<sup>f</sup> flavors of fundamental matter, and N<sup>A</sup> adjoint matters. The basic picture of the duality is shown in Figure [1.](#page-3-2) The duality works if the R charges of the adjoint matter and the truncated set of mesons satisfy the equation [1](#page-2-0)

$$\sum_{j=1}^{\alpha} t^{R_j} = \frac{t^{\Delta+2} - 1}{-1 + t^2 + \sum_{a} (t^{R_a} - t^{2-R_a})}.$$
 (1.1)

Here ∆ is the pairing constant of mesons built from adjoint chirals, and Ra's are the charges for the adjoint chirals, and R<sup>j</sup> 's are the charges for the mesons. Once the R charges satisfy the above equation, we can check that various physical quantifies for dual theory also match: a) the anomalies of the R symmetry such as Tr(R) and Tr R3 agree, which implies the central charges a, c agree; b) the spectrums of mesonic and baryonic operators are mapped perfectly.

It is then quite amazing that as long as the R charges of the adjoint chirals R<sup>a</sup> and the truncated spectrum R<sup>j</sup> are derived from the factorization of the polynomial y <sup>n</sup>−1 = Φ+Φ − (where Φ<sup>+</sup> is a polynomial with positive coefficients), one can get an N = 1 duality. So one immediately gets a large class of new types of N = 1 dualities. Moreover, for each factorization, one can get many new dualities by distributing the gauge singlets in electric and magnetic theory differently.

For other classical gauge groups with tensor fields, one often needs to introduce an involution operation on the above set of R charges so that duality could work. We also studied the duality involving exceptional gauge groups. The generalization to semi-simple groups such as the quiver gauge theory is straightforward as one can perform the duality on each gauge group separately.

<span id="page-2-0"></span><sup>1</sup>This equation has been discussed in [\[14](#page-29-8), [15\]](#page-29-9), and is derived from the match of large Nc, N<sup>f</sup> limit of the superconformal index of dual theory. Our point here is that this equation will ensure that the duality works for the finite Nc, N<sup>f</sup> limit.

The present paper mainly focuses on the combinatorial nature of  $\mathcal{N}=1$  duality. The dynamical questions such as whether such truncation is possible or not would be left for future exploration.

This paper is organized as follows: Section 2 discusses the basic feature of  $\mathcal{N}=1$  duality of  $SU(N_c)$  gauge theory coupled with adjoint chirals and  $N_f$  chirals; Section 3 discusses the generalization to simple gauge groups; Section 4 discusses the duality for theory with semi-simple gauge groups, such as quiver gauge theory; A conclusion is given in Section 5.

#### <span id="page-3-1"></span><span id="page-3-0"></span>2 General discussion

## <span id="page-3-2"></span>2.1 Basic picture of $\mathcal{N} = 1$ duality

![](_page_3_Picture_4.jpeg)

**Figure 1**: Basic picture of  $\mathcal{N} = 1$  duality.

Let's consider duality for  $SU(N_c)$  gauge theory coupled with two adjoint chiral fields  $u, v^2$  and  $N_f$  pairs of fundamental and anti-fundamental chiral fields c, d. Notice that this gauge theory might be a part of a quiver gauge theory. There might be marginal superpotential  $W_E$  for the electric model. The duality works as follows:

- 1. Replace every chiral field of the original theory with a dual chiral field:  $c \to c^*$ ,  $d \to d^*$ ,  $u \to u^*$ ,  $v \to v^*$ . And the dual fields are in the conjugate representation of gauge group: the orientation of the fundamental and anti-fundamental field is reversed, see Figure 1.
- 2. For each oriented loop starting with the flavor node, there is an associated dressed mesonic chiral field, i.e.  $M_I = cu^{a_1}v^{b_1}u^{a_2}v^{b_2}\dots d$ . One adds a dual gauge singlet  $[M_I]$  which is now in adjoint representation of the flavor node. Here I is a sequence of integers  $[a_1, b_1, a_2, b_2, \dots]$ .
- 3. The superpotential term is changed as follows: replace the combination of letters  $M_I$  in  $W_E$  by the gauge singlet  $[M_I]$ , and add new terms in the superpotential as

<span id="page-3-4"></span>
$$\Delta W = \sum_{I} [M_I] d^* u^{a'_1} v^{b'_1} \dots c^* = \sum_{I} [M_I] M_{I'}. \tag{2.1}$$

Here  $M_{I'}$  is the composite dressed meson in the dual theory.

<span id="page-3-3"></span><sup>&</sup>lt;sup>2</sup>Here we use two adjoint chirals to simplify the illustration, and all the following discussions are still valid for any number of adjoint fields.

4. Finally, one might be able to integrate out massive fields using the superpotential in the magnetic theory.

To make the above duality proposal work, the set of undressed mesons (which is formed by just adjoint chiral fields) should satisfy the following constraints: a) The dual theory has a finite number of gauge singlets, which means the set of letters involving u, v should be finite, i.e. there are truncations on the set of mesons. The superpotential  $W_E$  is useful in truncating the set of mesons. However, it is often necessary to use quantum constraints to truncate the mesons. b) The R charges of the allowed mesons  $U_I = u^{a_1}v^{b_1}u^{a_2}v^{b_2}\dots$  are paired:

<span id="page-4-0"></span>
$$R(U_I) + R(U_{I'}) = \Delta$$
. (2.2)

Here  $\Delta$  is a fixed constant. This condition is required so that the added superpotential (2.1) is marginal. This superpotential is crucial as the equation of motion for the gauge singlet  $[M_I]$  would set the composite  $M_{I'}$  operator of the dual theory to be zero in the chiral ring. The duality then maps the composite chiral operator to an elementary chiral operator in the dual theory, and there are no composite chiral operators in the dual theory.

The rank  $N'_c$  of the dual gauge theory can be computed easily from the above general setup of the duality. First, let's fix the R charges of adjoint chiral fields u and v as [u], [v] (it might be fixed by a superpotential term f(u, v) in  $W_E$ ). The anomaly free condition for the  $U(1)_R$  symmetry of electric theory is

$$([u] - 1) + ([v] - 1) + \frac{N_f}{N_c}(R_c - 1) + 1 = 0,$$

$$\Rightarrow R_c = 1 - ([u] + [v] - 1)\frac{N_c}{N_f}.$$

Now for the dual theory, one has the new superpotential term (2.1), which should also have R charge 2:

$$2R_c + R(U_I) + R(U_{I'}) + 2R_{c^*} = 2$$
.

Using the pairing condition for the mesons, the R charge of the  $c^*$  field is:

<span id="page-4-1"></span>
$$R_{c^*} = 1 - R_c - \frac{\Delta}{2} \,. \tag{2.3}$$

This charge might be negative, but it would not cause the problem as long as the gauge invariant operator has positive R charge. We can now compute the rank  $N'_c$  of the dual gauge theory by requiring the anomaly free condition of the dual  $U(1)_R$  symmetry:

$$\begin{split} ([u] + [v] - 1) + \frac{N_f}{N_c'} (R_{c^*} - 1) &= 0, \\ \Rightarrow \ N_c' &= \frac{N_f (R_c + \frac{\Delta}{2})}{[u] + [v] - 1} \\ &= \frac{N_f - N_c ([u] + [v] - 1) + N_f \frac{\Delta}{2}}{[u] + [v] - 1} \\ &= N_f \frac{2 + \Delta}{2([u] + [v] - 1)} - N_c = aN_f - N_c \,. \end{split}$$

The crucial number a is determined by the  $U(1)_R$  charge of u, v and the pairing constant  $\Delta$  of the meson spectrum:

<span id="page-5-3"></span>
$$a = \frac{2 + \Delta}{2([u] + [v] - 1)}.$$
(2.4)

The above formula makes sense if

<span id="page-5-1"></span>
$$[u] + [v] > 1. (2.5)$$

The chiral spectrum is matched as follows: First, the original meson  $M_I$  is mapped to the gauge singlet  $[M_I]$ , and the extra meson  $M_{I'}$  in the dual theory is projected out by using the added new superpotential term. The scaling dimensions of these chiral operators are mapped straightforwardly.

The baryon spectrum is mapped as follows [12]: One first has dressed quark  $c_I = U_I c$ , and the baryons are formed as  $B^{l_1,\dots,l_a} = c_1^{l_1} \dots c_a^{l_a}$  with  $\sum_{i=1}^a l_i = N_c$ . They are simply built as the determinant of the matrix formed by dressed quarks. The total number of baryons is  $C_{aN_f}^{N_c}$ .

The dual baryon is formed by dual dressed quark  $c_I^* = U_I c^*$ , and  $B^{\tilde{l}_1,\dots,\tilde{l}_a} = c_1^{*\tilde{l}_1} \dots c_a^{*\tilde{l}_a}$ , with  $\sum_{i=1}^a \tilde{l}_i = N'_c$ . The number  $\tilde{l}_i = N_f - l_{I^d}$ , with  $I^d$  the paired meson for I.

Let's now verify that their R charges are the same (so the scaling dimension is also the same). The R charge for electric baryon  $B^{l_1,...,l_a}$  is

$$\sum l_j R_j + N_c R_c \,.$$

The R charge for dual baryon  $B^{\tilde{l}_1,\dots,\tilde{l}_a}$  is

$$\sum \tilde{l}_j R_j + N'_c R_{c^*} = \sum (N_f - l_{j^d})(\Delta - R_{j^d}) + (aN_f - N_c)(1 - R_c - \frac{\Delta}{2})$$

$$= N_c R_c + \sum l_j R_j.$$

Firstly we used  $N_c' = aN_f - N_c$ ,  $R_{c^*} = 1 - R_c - \frac{\Delta}{2}$ . Next we used  $\sum_j R_j = \frac{a\Delta}{2}$ ,  $R_c = 1 - \frac{xN_c}{N_f}$  and  $a = \frac{\Delta+2}{2x}$ , with  $x = \sum_u (R_u - 1) + 1$  to verify the equality of the R charges of the baryons.

## <span id="page-5-0"></span>2.2 Truncation by superpotential

We have seen in the last subsection that  $\mathcal{N}=1$  duality might work if the set of mesons involving adjoint chiral fields takes a particular form of truncation. We'd like to find all the consistent truncations satisfying the condition (2.2).

The truncation can be achieved by using a superpotential f(u,v). The superpotential is assumed to be a trace on two matrices u,v. We take an algebraic approach by treating u,v as two non-commutative variables. Each term in the potential  $f(u,v) = \sum_{\alpha} \phi_{\alpha}(u,v)$  has a cyclic equivalence (remember that the trace function on the matrices has this property). The derivative of the superpotential is defined as

<span id="page-5-2"></span>
$$f_u = \sum_{\alpha} \partial_u \phi_{\alpha}(u, v) = \sum_{\alpha} [\partial_u (\sum_{cyc} u \dots)] = \sum_{\alpha} \sum_{cyc} \dots$$
 (2.6)

Here the sum is over the cyclic equivalence classes of  $\phi_{\alpha}$  such that the first term is u. We then have a non-commutative algebra

$$J_f = \frac{C[u, v]}{\{f_u, f_v\}},$$

We are looking for f such that  $J_f$  is finite dimensional, and f is required to be a quasi-homogeneous polynomial (the R charge of f is two) so that there is grading for field u and v

A necessary condition for the classical truncation is that f(u, v) should define an isolated singularity if one regards u, v as commutative variables, so that  $J_f$  is finite dimensional if it is regarded as a commutative Jacobian algebra. The constraint (2.5) would mean that f(u, v) defines an isolated ADE singularity <sup>3</sup>.

However, not every ADE singularity gives rise to a good truncation if u, v are regarded as non-commutative variables. For example, the  $E_6$  potential  $f = u^3 + v^4$  would give the relation

$$u^2 = 0$$
,  $v^3 = 0$ .

As a commutative algebra,  $J_{E_6}$  is finite dimensional and has only 6 elements which are given by  $\{1, u, v, v^2, uv, uv^2\}$ . However, as a non-commutative algebra, the  $J_f$  has an infinite number of elements, i.e words like uvuvuvuv... are nonzero simply because u, v are noncommutative.

<span id="page-6-1"></span>The set of ADE singularities that do give consistent truncation is listed in Table 1. Notice that for  $E_7$ ,  $D_k(k \text{ even})$ , one needs to impose quantum constraints to get consistent truncation. One cannot get consistent truncation for  $E_6$ ,  $E_8$  superpotential.

| Duality | f(u,v)           | ([u],[v])                                   | $\Delta$           | $N_c'$               |
|---------|------------------|---------------------------------------------|--------------------|----------------------|
| $A_1$   | $u^2 + v^2$      | (1,1)                                       | 0                  | $N_c' = N_f - N_c$   |
| $A_k$   | $u^2 + v^{k+1}$  | $(1, \frac{2}{k+1})$                        | $\frac{2k-2}{k+1}$ | $N_c' = kN_f - N_c$  |
| $D_k$   | $u^{k+1} + uv^2$ | $\left(\frac{2}{k+1}, \frac{k}{k+1}\right)$ | $\frac{4k-2}{k+1}$ | $N_c' = 3kN_f - N_c$ |
| $E_7$   | $u^3 + uv^3$     | $(\frac{2}{3}, \frac{4}{9})$                | $\frac{14}{3}$     | $N_c' = 30N_f - N_c$ |

**Table 1**: Summary of superpotential f(u, v) which would give good truncation of mesons. Quantum constraints need to be imposed for  $D_k(k \text{ even})$  and  $E_7$ .

**Example:** Consider  $D_k$  superpotential  $f(u, v) = u^{k+1} + uv^2$ , and the ideal of  $J_f$  is given (see equation (2.6)):

<span id="page-6-2"></span>
$$\frac{\partial f}{\partial v} = uv + vu = 0,$$

$$\frac{\partial f}{\partial u} = (k+1)u^k + v^2 = 0.$$
(2.7)

<span id="page-6-0"></span><sup>&</sup>lt;sup>3</sup>Usually the ADE singularity is defined as surface singularity  $z^2 + f(x, y) = 0$  and the ADE condition implies [z] + [x] + [y] > d assuming the weight of the polynomial is d. In our case, the weight of f is two, and the weight of [z] is one, and so the ADE condition implies the weights of [x] and [y] satisfy [x] + [y] > 2 - [z] = 1.

The first equation simply means that u and v are anticommuting, and the second equation implies that  $u^k$  is the same as  $v^2$  in the chiral ring. The following set is certainly the part of Jacobian algebra  $J_f$ 

<span id="page-7-1"></span>
$$\{1, u, \dots, u^{k-1}\},\$$

$$\{v, vu, \dots, vu^{k-1}\},\$$

$$\{v^2, v^2u, \dots, v^2u^{k-1}\}.$$
(2.8)

Let's now consider  $v^3$ , one gets from two equations in (2.7):

$$(k+1)(u^kv + vu^k) + 2v^3 = 0 \to v^3 = -\frac{k+1}{2}(u^kv + (-1)^ku^kv).$$

So for k odd, we have  $v^3 = 0$ , and the algebra  $J_f$  has 3k elements, see (2.8). For k even, one needs to truncate the set by assuming quantum constraint  $v^3 = 0$ . It is easy to check that the mesons have the desired pairing and the paring constant is listed in Table 1.

## <span id="page-7-0"></span>2.3 Truncation from equality of superconformal index

Instead of using superpotential to find the consistent truncation of the meson spectrum, one can find a large class of new examples by using superconformal index [14, 15]. See [16, 17] for more details on the superconformal index.

In the large  $N_c$ ,  $N_f$  limit, the equality of the index for two dual gauge theories in Figure 1 takes the form

<span id="page-7-2"></span>
$$\frac{g_E \bar{g}_E - g_M \bar{g}_M}{(1-f)} = h_M - h_E.$$

Here f is the contribution of the vector multiplet and adjoint chiral,  $(g_E, g_M)$  are the contribution of the fundamental chirals, and  $(\bar{g}_E, \bar{g}_M)$  are the contribution of the antifundamental chirals,  $(h_E, h_M)$  are the contribution of gauge singlets. The detailed formulas for various fields are given in the appendix  $\mathbb{C}$ . Here E denotes the contribution in the electric frame, and M denotes the contribution in the magnetic frame. The equality of the index gives the equation:

$$(t^{R_Q} - t^{2-R_Q})^2 - (t^{R_q} - t^{2-R_q})^2 = (1 - t^2 - \sum_a (t^{R_a} - t^{2-R_a})) (\sum_j t^{2R_Q + R_j} - t^{2-(2R_Q + R_j)}),$$

$$\Rightarrow \frac{t^{2R_Q} + t^{4-2R_Q} - t^{2R_q} - t^{4-2R_q}}{(1 - t^2 - \sum_a (t^{R_a} - t^{2-R_a}))} = \sum_j (t^{2R_Q + R_j} - t^{2-(2R_Q + R_j)}). \tag{2.9}$$

Here  $R_Q$   $(R_q)$  is the R charge for the fundamental fields in an electric (magnetic) frame. If there is a pairing between the mesons  $R_j + R_j' = \Delta$ , then we have  $\sum_j t^{R_j} = t^{\Delta} \sum_j t^{-R_j}$ , and  $R_Q + R_q = 1 - \frac{\Delta}{2}$  (see equation (2.3)). We then have the equation

$$\frac{(t^{2R_Q}-t^{2R_q})-t^{\Delta+2}(t^{2R_Q}-t^{2R_q})}{(1-t^2-\sum_a(t^{R_a}-t^{2-R_a}))}=[t^{2R_Q}-t^{2R_q}]\sum_j t^{R_j}\,.$$

So the equality of the index is satisfied if we have

<span id="page-8-0"></span>
$$\sum_{j=1}^{\alpha} t^{R_j} = \frac{t^{\Delta+2} - 1}{-1 + t^2 + \sum_{a} (t^{R_a} - t^{2-R_a})}.$$
 (2.10)

We see that whether duality works depends on the factorization of the polynomial

$$y^n - 1 = \prod_{d|n} \Phi_d(y).$$

Here Φd(y) is the cyclotomic polynomial. To find consistent truncation of meson, one just needs to factorize the cyclotomic polynomial into a positive part (all the coefficients are positive) and the negative part [\[15](#page-29-9)]:

$$y^n - 1 = \Phi_+ \Phi_- .$$

From the factorization, one can find the data (∆, Ra, R<sup>j</sup> ) as follows. First, assuming the highest order of Φ<sup>−</sup> is n<sup>1</sup> which is paired with the constant term −1, we can find the normalization constant δ = 2 n1 . Then we have

- 1. The pairing constant is ∆ = nδ − 2 = <sup>2</sup> n1 (n − n1).
- 2. The R charges R<sup>a</sup> for the adjoint fields u<sup>a</sup> are found from the positive exponents (c1, c2, . . .) of Φ<sup>−</sup> as (c1δ, c2δ, . . .).
- 3. The R charges R<sup>j</sup> for the mesons built from adjoint fields are found from the exponents (d0, d1, . . . ,) of Φ<sup>+</sup> as (d0δ, d1δ, . . .).

This is the complete set of data needed for establishing N = 1 duality. Here are some remarks:

- 1. Although the equality of the index is computed in the large Nc, N<sup>f</sup> limit, one can check the central charges agree for the finite Nc, N<sup>f</sup> value, see section [2.5.](#page-11-0)
- 2. Once we find the R charges for the adjoint fields, it might be possible to add the marginal term for the adjoint fields ua. One certainly recovers the known ADE superpotential as a small subset. However, one should not expect to get the mesonic spectrum from the classical relation of the superpotential. Rather, one may simply impose the quantum constraint by hand.
- 3. The construction is symmetric under the exchange of electric and magnetic form, and so the duality is an involution. We will discuss more about this in the next subsection.
- 4. Notice that here we only get the R charges of the mesons, and knowledge about how they are formed from the adjoint chiral fields u<sup>a</sup> is not clear: a) there might be more than one possible combinations of a given R charge R<sup>j</sup> ; b) even if the combination of the u<sup>a</sup> field is given, the ordering of the fields u<sup>a</sup> is not clear as they are noncommutative variables.

<span id="page-9-1"></span>All possible factorizations of  $y^8 - 1$  are shown in Table 2.

| $\Phi_8^+(y)$                                                             | $\Phi_8^-(y)$                                                             | $R_a, R_j$                                                   |
|---------------------------------------------------------------------------|---------------------------------------------------------------------------|--------------------------------------------------------------|
| $\Phi_2(y) = y + 1$                                                       | $\Phi_1(y)\Phi_4(y)\Phi_8(y) = y^7 - y^6 + y^5 - y^4 + y^3 - y^2 + y - 1$ | $(\frac{2}{7}, \frac{6}{7}, \frac{10}{7}), (\frac{2}{7}, 0)$ |
| $\Phi_4(y) = y^2 + 1$                                                     | $\Phi_1(y)\Phi_2(y)\Phi_8(y) = y^6 - y^4 + y^2 - 1$                       | $(\frac{2}{3}), (\frac{2}{3}, 0)$                            |
| $\Phi_8(y) = y^4 + 1$                                                     | $\Phi_1(y)\Phi_2(y)\Phi_4(y) = y^4 - 1$                                   | (1), (2,0)                                                   |
| $\Phi_2(y)\Phi_4(y) = y^3 + y^2 + y + 1$                                  | $\Phi_1(y)\Phi_8(y) = y^5 - y^4 + y - 1$                                  | $(\frac{2}{5}), (\frac{3}{5}, \frac{2}{5}, \frac{1}{5}, 0)$  |
| $\Phi_2(y)\Phi_8(y) = y^5 + y^4 + y + 1$                                  | $\Phi_1(y)\Phi_4(y) = y^3 - y^2 + y - 1$                                  | $(\frac{2}{3}), (\frac{10}{3}, \frac{8}{3}, \frac{2}{3}, 0)$ |
| $\Phi_4(y)\Phi_8(y) = y^6 + y^4 + y^2 + 1$                                | $\Phi_1(y)\Phi_2(y) = y^2 - 1$                                            | (1), (6, 4, 2, 0)                                            |
| $\Phi_2(y)\Phi_4(y)\Phi_8(y) = y^7 + y^6 + y^5 + y^4 + y^3 + y^2 + y + 1$ | $\Phi_1(y) = y - 1$                                                       | (1), (14, 12, 10, 8, 6, 4, 2, 0)                             |

**Table 2**: The possible products of cyclotomic polynomials with all coefficients positive  $\Phi_n^+(y)$  and the corresponding antipalindromic polynomials  $\Phi_n^-(y) = (y^n - 1)/\Phi_n^+(y)$  for n = 8.

Remark: For the given ADE  $R_a$  charges of the adjoint fields listed in Table 1, it is possible to find an infinite sequence of  $R_j$  charges and the paring constant  $\Delta_n^{ADE}$ . These may be thought of as the rank n version of ADE theory. For example, if  $R(u) = \frac{2}{3}$ , then the right hand side of equation (2.10) becomes  $\frac{t^{\Delta+2}-1}{-1+t^2+t^2/3-t^{4/3}} = \frac{y^{\frac{3\Delta}{2}+3}-1}{-1+y^3+y-y^2} = \frac{y^{\frac{3\Delta}{2}+3}-1}{\Phi_1\Phi_4}$ , so as long as  $\frac{3\Delta}{2}+3$  has a divisor 4, one can have a consistent factorization. It would be interesting to realize these spectrums from some physical models.

## <span id="page-9-0"></span>2.4 More dualities

More generally, one may assume that there are already gauge singlets in the electric frame, and the right hand side of the equation (2.9) becomes

$$\sum_{j} (t^{2R_Q + R_j^M} - t^{2 - (2R_Q + R_j^M)}) - \sum_{l} (t^{2R_q + R_l^E} - t^{2 - (2R_q + R_l^E)})$$
 (2.11)

To get good duality, we first assume that the R charges of fundamental fields satisfy  $R_Q + R_q = 1 - \frac{\Delta}{2}$ . The above equation becomes

$$\sum_{j} \left( t^{2R_Q + R_j^M} - t^{2 - (2R_Q + R_j^M)} \right) + \sum_{l} \left( t^{2R_Q + \Delta - R_l^E} - t^{2 - (2R_Q + \Delta - R_l^E)} \right). \tag{2.12}$$

Now define  $R'_l = \Delta - R_l^E$ , and the above equation would take the same form as (2.9). Now the electric and magnetic gauge singlets are found from the set  $\{R_j\}$  in the factorization as follows:

- 1. First find a subset  $\{R_j^M\}$  from the solution, and the R charge of the magnetic gauge singlet is given by  $2R_Q + R_j^M$ .
- 2. For the remaining elements in  $\{R_j^E\} = \{R_j\} \setminus \{R_j^M\}$ , the R charge of the electric gauge singlet is given by  $2R_q + \Delta R_j^E$ .

To make the duality work, one needs to add the superpotential term as follows:

$$W_E = \sum [M_I^E] M_{I^d} \,.$$

Here  $M_{I^d}$  is the composite meson built from the electric fundamental degree of freedoms. This superpotential would couple the gauge singlet to the fundamental fields so that the electric theory is an irreducible theory.

**Example:** Let's take  $f = u^5$ . The set of basic mesonic R charges is  $R_j = \{1, u, u^2, u^3\}$ . Let's take the magnetic part of gauge singlets as  $R_j^M = \{u^2, u^3\}$ , and electric part as  $R_j^E = \{1, u\}$ . So the electric gauge singlets are  $[c^*u^3d^*]$  and  $[c^*u^2d^*]$  (We use these letters to indicate their R charges). An electric superpotential is

$$W_E = [c^*u^3d^*]cd + [c^*u^2d^*]cud,$$

so that the singlet is coupled with the gauge theory. Now let's do duality following the general rule, and there would be four more new magnetic mesons in the magnetic frame. The superpotential takes the form

$$W_M = [c^*u^3d^*][cd] + [c^*u^2d^*][cud] + \dots$$

The singlets  $[c^*u^3d^*]$ , [cd],  $[c^*u^2d^*]$ , [cud] become massive. So we are left with two magnetic gauge singlets  $[cu^2d]$ ,  $[cu^3d]$ , which agrees with our setup. See Figure 2 for the illustration of this duality model.

<span id="page-10-0"></span>![](_page_10_Picture_6.jpeg)

**Figure 2**: Duality for superpotential  $f = u^5$  with magnetic part of gauge singlets  $R_j^M = \{u^2, u^3\}$  and electric part  $R_j^E = \{1, u\}$ .

**Self-dual model**: It is now possible to have self-dual model, i.e. the dual gauge group and matter contents are the same as the original theory. The condition on  $N_f, N_c$  is  $aN_f - N_c = N_c$ . We also have the same R charge for the bi-fundamental fields:  $R(c) = R(c^*) = \frac{1}{2}(1 - \frac{\Delta}{2})$ . We also arrange the electric and magnetic gauge singlets symmetrically. Then we have the following possibilities: a)  $A_1: \Delta = 0$ , and so  $R(c) = R(c^*) = \frac{1}{2}$ ,  $N_f = 2N_c$ ; b)  $A_k: \Delta = \frac{2k-2}{k+1}$ , and so  $R(c) = R(c^*) = \frac{1}{k+1}$ , and  $N_f = \frac{2N_c}{k}$ ; The gauge

singlets are  $[cd], \ldots, [cu^{\left[\frac{k-1}{2}\right]}d]$ . The superpotential may be used to project some mesons out.

#### <span id="page-11-0"></span>2.5 General solutions

Every factorization of  $y^n-1$  would give rise to a possible duality pair: one has complete electric and magnetic descriptions. However, one often could not find a superpotential so that the truncation is derived from the equation of motion of it. One should also be aware that even for  $E_7$  and  $D_k$  (k even) model, one needs to truncate the meson spectrum by hand [5, 12], namely a quantum constraint is needed. However, there is little if any understanding about how such quantum constraint arises.

The author of [15] proposed superpotential for some models from the factorization. However, the potential does just reflect the R charges of adjoint fields, and the proposed superpotential cannot give the truncation by using the equation of motion. Probably one should not take such superpotential too seriously.

Our point of view is that one should not be constrained by the existence of superpotential. Instead, the gauge theory studied above might be just part of a larger gauge theory, and the adjoint fields us could be the composite of other fundamental fields. The truncation on the mesonic spectrum could be due to some unknown quantum constraints. Of course, it would be interesting to identify specific models with these more general solutions. In any case, we just take the specified mesonic spectrum as the input of our theory.

**Example**: Let's discuss a model derived from one factorization, and we will show how the duality in this situation would work. Let's take the factorization  $y^4-1=(y^2-1)(y^2+1)$ , and so  $\Delta=2$  and there is no adjoint field, and  $R_j=\{0,2\}$ . It is not straightforward to form the mesons from the elementary field. However, we may add an adjoint field u with R charge 1, and now the set of mesons is assumed to be cd,  $cu^2d$ . The dual theory works similarly, and a dual superpotential is formed:

$$W = [cd]c^*u^2d^* + [cu^2d]c^*d^*.$$

In the dual theory, the composite meson  $c^*u^2d^*$ ,  $c^*d^*$  are not in the chiral ring. We then have the duality as shown in Figure 3. The rank of the dual gauge group is  $2N_f - N_c$ .

<span id="page-11-1"></span>![](_page_11_Picture_8.jpeg)

**Figure 3**: A duality for a special set of the mesonic spectrum derived from factorization  $y^4 - 1 = (y^2 - 1)(y^2 + 1)$ .

We have verified that the chiral spectrum of the dual pair matches, see the discussion at the end of section 2.1. Let's now verify that for the general duality proposal based on the factorization of the polynomial  $y^n - 1$ . The Tr R and Tr  $R^3$  anomalies match, which

would ensure that the central charges match [18]. The anomaly vanishing conditions of the original and dual gauge theories are (here we take the gauge group as  $U(N_c)$  without losing any generality):

$$N_c[\sum_{u} (R_u - 1) + 1] + (R_c - 1)N_f = 0,$$
  
$$N'_c[\sum_{u} (R_u - 1) + 1] + (R_{c^*} - 1)N_f = 0.$$

The original and dual R anomalies are

<span id="page-12-0"></span>
$$\operatorname{Tr} R = N_c^2 \left[ \sum_{u} (R_u - 1) + 1 \right] + 2N_c N_f (R_c - 1) = N_c N_f (R_c - 1),$$

$$\operatorname{Tr} R_{\text{dual}} = N_c'^2 \left[ \sum_{u} (R_u - 1) + 1 \right] + 2N_c' N_f (R_{c^*} - 1) + N_f^2 \sum_{j} \left[ (2R_c + R_j) - 1 \right]$$

$$= N_c' N_f (R_{c^*} - 1) + N_f^2 \left[ 2aR_c + \frac{\Delta}{2}a - a \right].$$
(2.13)

Substitute  $N_c' = aN_f - N_c$ ,  $R_{c^*} = 1 - R_c - \frac{\Delta}{2}$ , we have

$$\operatorname{Tr} R_{\text{dual}} = (aN_f - N_c)N_f[-R_c - \frac{\Delta}{2}] + N_f^2[2aR_c + \frac{\Delta}{2}a - a]$$

$$= N_cN_f(R_c - 1) + aN_f^2(R_c - 1) + \frac{\Delta N_cN_f}{2} + N_cN_f$$

$$= N_cN_f(R_c - 1) + N_cN_f[1 + \frac{\Delta}{2} - a[\sum_u (R_u - 1) + 1]]$$

$$= N_cN_f(R_c - 1).$$

Here we used the equation  $R_c = 1 - \left[\sum_u (R_u - 1) + 1\right] \frac{N_c}{N_f}$ , and the equation of a (2.4). The original and dual  $R^3$  anomalies are

$$\operatorname{Tr} R^{3} = N_{c}^{2} \left[ \sum_{u} (R_{u} - 1)^{3} + 1 \right] + 2N_{c}N_{f}(R_{c} - 1)^{3}$$

$$= N_{c}^{2} \left[ \sum_{u} (R_{u} - 1)^{3} + 1 \right] - \frac{2N_{c}^{4}}{N_{f}^{2}} \left( \sum_{u} (R_{u} - 1) + 1 \right)^{3},$$

$$\operatorname{Tr} R_{dual}^{3} = N_{c}^{\prime 2} \left[ \sum_{u} (R_{u} - 1)^{3} + 1 \right] + 2N_{c}^{\prime}N_{f}(R_{c^{*}} - 1)^{3} + N_{f}^{2} \sum_{i} \left[ (2R_{c} + R_{i} - 1)^{3} \right].$$

Substitute  $N_c' = aN_f - N_c$ ,  $R_{c^*} = 1 - R_c - \frac{\Delta}{2}$ . Define  $x = \sum_u (R_u - 1)^3 + 1$ ,  $y = \sum_j (R_j - 1)$ ,  $z = \sum_j (R_j - 1)^2$ ,  $w = \sum_j (R_j - 1)^3$ . If these numbers satisfy the following equation:

$$y = \frac{1}{2}a(\Delta - 2), \quad z = \frac{a(-2ax + \Delta^3 + 8)}{3(\Delta + 2)}, \quad w = \frac{a(-4a(\Delta - 2)x + \Delta^4 - 16)}{4(\Delta + 2)}, \quad (2.14)$$

then we also have the equality of the cubic anomalies. We have verified the above equality for many factorizations of polynomial  $y^n - 1$  and it would be interesting to prove the above identity exactly.

Let's check that other global anomalies also match. It is easy to check that  $\text{Tr }SU(N_f)^3 = 0$  and  $\text{Tr }SU(N_F)R^2 = 0$  agree for both sides. The last global anomaly that remains to check is

$$\operatorname{Tr} SU(N_f)^2 R = \sum_i (R_i - 1) \operatorname{Tr} SU(N_f)^2 = \sum_i (R_i - 1) ind.$$

Here ind is the Dynkin index for the representation under the flavor symmetry. The original and dual  $\text{Tr } SU(N_f)^2R$  anomalies are

$$\operatorname{Tr} RFF = 2N_c(R_c - 1)\frac{1}{2} = N_c(R_c - 1);$$

$$\operatorname{Tr} R_{\text{dual}}F_{\text{dual}}F_{\text{dual}} = 2N_c'(R_{c^*} - 1)\frac{1}{2} + N_f \sum_j (2R_c + R_j - 1)$$

$$= N_c'(R_{c^*} - 1) + a(\Delta/2 + 2R_c - 1)N_f.$$

One can check that they are equal from the equality of  $\operatorname{Tr} R$  anomaly, see (2.13).

There is also a baryon number  $U(1)_B$  symmetry. The baryonic charge for quarks  $c_i$  and antiquarks  $d_i$  is normalized to be  $\pm 1$ . Since the duality maps baryons  $B^{l_1 \cdots l_a}$  to  $B^{\tilde{l}_1 \cdots \tilde{l}_a}$  and  $\sum_i l_i = N_c$ ,  $\sum_i \tilde{l}_i = N'_c$ . Therefore the dual quarks  $c_i^*$  should have the normalized  $U(1)_B$  charges  $\frac{N_c}{N'_c} = \frac{N_c}{aN_f - N_c}$ .

It is easy to see  $\text{Tr }U(1)_BRR=\text{Tr }U(1)_B^3=0$  in both electric and magnetic theories. The nonzero anomalies are  $\text{Tr }RU(1)_B^2$ , and the computations are

$$\operatorname{Tr} RU(1)_{B}^{2} = 2N_{f}N_{c}(R_{c} - 1) = -2N_{c}^{2}x,$$

$$\operatorname{Tr} R_{\text{dual}}U(1)_{B}^{2} = 2N_{f}N_{c}'(R_{c^{*}} - 1)(\frac{N_{c}}{aN_{f} - N_{c}})^{2}$$

$$= 2N_{f}(aN_{f} - N_{c})(-R_{c} - \frac{\Delta}{2})(\frac{N_{c}}{aN_{f} - N_{c}})^{2}$$

$$= -2N_{c}^{2}x.$$

Here we used the formula  $a = \frac{d+2}{2x}$ ,  $R_c = 1 - x \frac{N_c}{N_f}$ , with  $x = \sum_u (R_u - 1) + 1$ .

## <span id="page-14-0"></span>3 Duality for simple gauge group

The analysis of duality for other simple gauge groups can be carried out in a similar way. The basic idea is the same as discussed in last subsection: the composite mesons of one theory are mapped to the gauge singlets of the dual theory, and often an extra dual superpotential is needed.

To make the duality work, we also find that the R charges for tensorial fields and the meson spectrum should also satisfy the equation [\(2.2\)](#page-4-0). However, we often have more constraints, namely, sometimes a Z<sup>2</sup> action is needed to further separate the mesons.

## <span id="page-14-2"></span><span id="page-14-1"></span>3.1 Classical gauge group with adjoint chiral

![](_page_14_Picture_4.jpeg)

Figure 4: Duality for classical gauge group with adjoint chiral. The gauge singlets in the dual theory could be in either symmetric or anti-symmetric representation of the flavor group.

<span id="page-14-3"></span>

| Gauge group    | Dual gauge group          |
|----------------|---------------------------|
| SU(Nc)         | SU(aNf<br>− Nc)           |
| SO(2Nc)        | SO(2aNf<br>− 2Nc<br>+ 4)  |
| SO(2Nc<br>+ 1) | SO(2aNf<br>− 2Nc<br>+ 3)  |
| USp(2Nc)       | USp(2aNf<br>− 2Nc<br>− 4) |

Table 3: Gauge groups of the original theory and dual theory.

Let's now assume that the gauge group is of the classical type, and the matter is in fundamental or adjoint representation. The main difference is that the matter transforms in the real (or pseudo-real) representation of the gauge group, so one does not need to add an arrow for the matter in fundamental representation. The original theory and its dual are shown in Figure [4.](#page-14-2) The dual gauge group is determined by using anomaly free condition for U(1)<sup>R</sup> charge:

$$h^{\vee}([u] - 1 + [v] - 1) + N_f^*(R(c) - 1) + h^{\vee} = 0,$$
  
$$h'^{\vee}([u] - 1 + [v] - 1) + N_f^*(R(c^*) - 1) + h'^{\vee} = 0.$$

Here h <sup>∨</sup> is the dual Coxeter number. Now assume that the adjoint chirals have a truncation, and so that the R charges have a pairing Rj+R<sup>j</sup> ′ = ∆. The existence of dual superpotential would relate the R charges of the fundamental fields as  $R(c) + R(c^*) = 1 - \frac{\Delta}{2}$ . Here  $N_f$  denotes the number of hypermultiplets (a pair of fundamental chiral fields).

The dual Coxeter number of the dual gauge group is then

$$h^{\vee'} = aN_f^* - h^{\vee},$$

and a is determined by the paring constant of mesons and R charges of [u], [v]:

$$a = \frac{2 + \Delta}{2([u] + [v] - 1)}.$$
(3.1)

And  $N_f^* = N_f \times b$ , here  $N_f$  denotes the number of hypermultiplets (a pair of fundamental fields), and b = 1 for A, C gauge groups, b = 2 for B, D gauge groups. The change of the gauge group is summarized in the Table 3.

To discuss the detailed duality, one needs to study the transformation behavior of the dressed meson under the flavor symmetry.

**Example**: Let's consider  $SO(N_c)$  type gauge group, and the fundamental representation is denoted as V. The adjoint representation is formed from anti-symmetric tensor product of  $V: \wedge^2 V$ . The basic invariant is  $v^T v$  built from fundamental representation v. The dressed mesons are formed as  $v^T U_I v$ . When there is just one adjoint chiral u, it is easy to find the transformation behavior of the dressed meson under the flavor group: i.e.  $v^T u^i v$  is a symmetric (anti-symmetric) tensor of the flavor group if i is even (odd). For the  $Sp(N_c)$  gauge group, the adjoint representation is the symmetric power of the fundamental representation  $Sym^2V$ , and the invariant is  $v^T Ju^i v$ , with  $J = \begin{bmatrix} 0 & I_n \\ -I_n & 0 \end{bmatrix}$ . It is then straightforward that  $v^T Ju^i v$  is a symmetric (anti-symmetric) tensor of the flavor group if i is even (odd).

For more than one adjoint chirals, to make duality work, one needs to define an involution on the set of mesons from the fundamental solutions: the meson is classified as positive type or negative type. There are  $\frac{a+1}{2}$  ( $\frac{a-1}{2}$ ) mesons with positive (negative) sign for  $SO(N_c)$  gauge group. For  $Sp(N_c)$  gauge group, there are  $\frac{a-1}{2}$  ( $\frac{a+1}{2}$ ) mesons with positive (negative) sign. Here a is the total number of mesons.

We can also distribute electric and magnetic gauge singlets to get more dualities as we did for the SU type theory in the last section.

The detailed computations for the R anomalies can be found in the appendix B.1.

#### <span id="page-16-1"></span><span id="page-16-0"></span>3.2 General representations

| Group/ Index | $Adjoint = h^{\vee}$ | Symmetric         | Antisymmetric     | Fundamental   |
|--------------|----------------------|-------------------|-------------------|---------------|
| SU(N)        | N                    | $\frac{N}{2} + 1$ | $\frac{N}{2} - 1$ | $\frac{1}{2}$ |
| USp(2N)      | N+1                  | Adj               | N-1               | $\frac{1}{2}$ |
| SO(2N)       | 2N-2                 | 2N + 2            | Adj               | 1             |
| SO(2N+1)     | 2N-1                 | 2N + 3            | Adj               | 1             |

**Table 4**: Dynkin indices for some common representations of the classical group. The representation besides the adjoint representation is not irreducible (often one needs to subtract a trivial representation to get an irreducible representation).

Let's now consider a simple gauge group coupled with general representations. The representations are constrained so that there is no gauge anomaly (local gauge anomaly exists only for SU(N) gauge group [19], and global anomaly exists for Sp(2N) gauge group [20]).

The anomaly free condition for  $U(1)_R$  symmetry is

$$\sum_{a} \operatorname{ind}(r_a)([u_a] - 1) + \sum_{i} \operatorname{ind}(r_i)(R(r_i) - 1) + h^{\vee} = 0.$$

Here  $r_a$  could be the general tensor (most often the two tensor) representation of gauge groups. The second sum is over the representation whose index is small, i.e. the defining representation. And  $h^{\vee}$  is the dual Coxeter number. The index for some familiar representations of classical group is shown in Table 4.

The duality often works as follows: First, one assumes that the dual theory involves the conjugate representation of the electric theory, and the gauge group is also the same type of the electric theory. The similar anomaly free condition of the  $U(1)_R$  charge of the dual theory is

$$\sum_{a} \operatorname{ind}(r_{a}^{*})([u_{a}] - 1) + \sum_{i} \operatorname{ind}(r_{i}^{*})(R(r_{i}^{*}) - 1) + h'^{\vee} = 0.$$

Secondly, the dual theory should have gauge singlets which are identified with the composite gauge invariant chiral mesons of the original theory. Therefore, one needs to study the invariant theory involving the fundamental fields and tensorial fields, which may be solved using the Weyl's invariant theory for the classical group case[21]. The case of exceptional group would be discussed in next subsection. The meson spectrum is formed by two vector fields, and the fields involving tensor fields  $u_a$ . They would transform differently under the flavor group depending on the property of the tensor fields.

Once we find out the space of spectrum (again assuming the truncation of the meson spectrum to a finite set), a dual superpotential involving the gauge singlets is added so that the composite gauge invariant operators are projected out. The marginal condition for the added superpotential is then

$$2R(r_i) + 2R(r_i^*) + R(U_I) + R(U_{Id}) = 2$$
.

Now assuming the basic meson involving tensorial field has the pairing  $R(U_I) + R(U_{I^d}) = \Delta$ , and so

$$R(r_i^*) + R(r_i) = 1 - \frac{\Delta}{2}$$
.

We have the equation for the dual Coxeter numbers

$$h^{\vee} + \sum_{a} \operatorname{ind}(r_a)([u_a] - 1) + h^{\vee} + \sum_{a} \operatorname{ind}(r_a^*)([u_a] - 1) + \sum_{i} \operatorname{ind}(r_i)(-1 - \frac{\Delta}{2}) = 0.$$
(3.2)

Here we assume that the index of the vector representation does not depend on the gauge group (this is true for the classical group, as we assume the dual gauge group is of the same type).

From this formula, it is clear that the dual gauge group is determined by the R charges of tensorial fields  $[u_a]$ , and the pairing constant  $\Delta$ . Here more data is needed, one needs to have an extra involution on the set of mesons to indicate the transformation property of the dressed meson under the flavor symmetry group.

**Example**: Let's consider  $SO(2N_c)$  coupled with a traceless symmetric tensor X and  $N_f$  hypermultiplets in fundamental representation, and a superpotential  $Tr X^{k+1}$  is added. The dual gauge group is found from above equations:

$$2N_{c} - 2 + (2N_{c} + 2)\left[\frac{2}{k+1} - 1\right] + 2N_{c}^{'} - 2 + (2N_{c}^{'} + 2)\left[\frac{2}{k+1} - 1\right] + 2N_{f}(-1 - \frac{k-1}{k+1}) = 0,$$

$$\Rightarrow 2N_{c}^{'} = 2kN_{f} + 4k - 2N_{c}.$$

This duality has been studied in [6]. More general classes are discussed in appendix B.2.

General case: In the above analysis, one assumes that dual gauge group is the same type as the original gauge group. It might be possible that the dual theory takes a different form. The duality works similarly: the composite gauge invariant operator of the electric theory is mapped to the elementary (gauge singlet) field of the dual theory. Often a superpotential is needed to project the composite chiral operator of the dual theory out. Again, a detailed knowledge of the chiral spectrum (such as the truncation to a finite set) is crucial to identify the dual theory. See [22] for some examples, and certainly more examples can be found by considering the truncation of tensorial fields discussed in last section.

**Self-dual example:** One may engineer the matter representations so that the gauge groups are not changed, see [23, 24] for some examples. It seems possible to find more examples using our general analysis in last section.

#### <span id="page-17-0"></span>3.3 Exceptional gauge group

For exceptional group, one mostly needs to only consider the fundamental representation F as other representations have large index. The basic idea of duality is still mapping the composite chiral operators in electric theory to the elementary field in the magnetic theory. The first question is to classify the chiral spectrum, which is the study of the invariant theory for exceptional group. As in the classical group case, one can have invariant built from a fundamental field and an anti-fundamental field (mesons), or the invariant built from the determinant (baryons). There are more possibilities for the exceptional groups, see [25]. For example, one could have operators built from three fundamental fields for  $E_6$  group. This makes the study of duality more complicated, i.e. the dual gauge group is often not of the same type.

We may consider the theory where the dual gauge theory has the same type as the electric theory. The duality should work in similar way: one adds gauge singlet [M] for the composite meson in the electric theory, and adds a superpotential to project out the composite meson in the dual gauge theory. The dual gauge group might be found from the anomaly free condition of  $U(1)_R$  charge, and the self-dual condition constraints the possible matter content of the electric theory.

**Example:** For  $E_6$  group, the index of fundamental representation is 3, and the index of adjoint representation is 12. Let's assume that there are  $n_f$  fundamentals F, and it is known that there is a gauge invariant term  $F^3$ . The duality changes the representation F to the dual representation  $F^*$ . To find the dual gauge group, one needs to modify the relation between the R charges of the fundamental fields, as now the basic invariant is a cubic invariant. According to the duality proposal, there should be a superpotential term in the magnetic description

$$W = [F^3]F^{*3}.$$

Here  $[F^3]$  is the gauge singlet, therefore the relation between R charges of F and  $F^*$  is changed as

$$R(F) + R(F^*) = \frac{2}{3}.$$

This is in contrast with the classical group case (Compare (2.3)). The Coxeter number of the dual gauge group takes the form

$$h^{'\vee} = 4n_f - h^{\vee} .$$

When  $n_f = 6$ , one has the self-dual situation  $h^{\vee'} = h^{\vee}$ : one can add a marginal sextice interaction in the electric theory, and the theory is completely symmetric for electric and magnetic description. In this model, although the R charge of the fundamental fields is  $\frac{1}{3}$  which is below the unitarity bound, the gauge invariant operator involves three fundamental fields and so its R charge is 1, which is above the unitarity bound. This model has been studied in [26]. More self-dual examples based on exceptional gauge group were also studied in [27].

Let's now add one more adjoint chiral field u to above model, so that the set of dressed mesons is  $\{Fu^iF^2\}$ . The dual theory should have a superpotential

$$W = \sum [Fu^i F^2] F^* u^j F^{*2} \,.$$

To make the duality work, the undressed mesons should be paired as  $R(u^i) + R(u^j) = \Delta$ , and so  $R_F + R_{F^*} = \frac{2}{3} - \frac{\Delta}{3}$ . The dual Coxeter number of the dual gauge group is

$$h'^{\vee} = n_f \frac{\Delta + 4}{R(u)} - h^{\vee} = (3k+1)n_f - h^{\vee}.$$

Here we assume there is a  $A_k$  type potential for adjoint field u. It would be interesting to identify the dual theory for this more general model (notice that k = 1, 4, 5, 7, 8, 11).

Alternatively, We may have  $N_f$  pairs of fundamentals F and anti-fundamentals  $\bar{F}$ , and an adjoint u with  $A_k$  type superpotential. So there could be gauge invariant  $Fu^k\bar{F}$  besides the cubic invariant  $F^3, \bar{F}^3$ . We now add similar dual potential as for the classical group case, and the data for the dual gauge group would be

$$h^{'\vee} = 6kN_f - h^{\vee}.$$

When k = 1 (no adjoint), one finds that  $N_f = 4$  so that the dual gauge group has the same dual Coxeter number. This example is different from that in [26] as the duality maps gauge invariant  $F\bar{F}$  to the gauge singlet here (the self-dual example in [26] maps a gauge invariant  $F^3$  to a gauge singlet). When  $k = 4, N_f = 1$ , we also have a self-dual model.

| Group/ Index | $Adjoint = h^{\vee}$ | $\operatorname{Fundamental}(\operatorname{\mathbf{dim}})\operatorname{index}$ |
|--------------|----------------------|-------------------------------------------------------------------------------|
| $G_2$        | 4                    | <b>(7)</b> 1                                                                  |
| $F_4$        | 9                    | <b>(26</b> )3                                                                 |
| $E_6$        | 12                   | <b>(27</b> )3                                                                 |
| $E_7$        | 18                   | <b>(56</b> )6                                                                 |
| $E_8$        | 30                   | <b>(248</b> )30                                                               |

**Table 5**: Dynkin indices and dimensions of the adjoint representation and fundamental representation of the exceptional groups. The Dynkin index of the adjoint representation is equal to the dual Coxeter number by our convention.

#### <span id="page-19-0"></span>4 Duality for semi-simple gauge groups

Let's now assume the gauge group is semi-simple, i.e. the gauge group is a product of simple factors. There are two situations that one could consider: the first one regards several simple gauge groups as a single core, and there could be fields such as fundamental representations charged with individual gauge groups, and the duality acts on the gauge groups in the core simultaneously, see [6] for examples; the second one is more common: one could consider quiver gauge theory where the duality acts on each simple gauge group separately, see [28, 29] for examples. The duality works in the similar way: the dual gauge groups are changed, and one adds the gauge singlet in the dual theory and a superpotential to project out the composite mesons. Again, the crucial condition is that the set of mesons is truncated, and there is a paring between the meson spectrum. See Figure 5 for the illustration of an example whose core has more than one gauge groups, and Figure 6 for the quiver gauge theory.

Using the result of last sections, it is possible to have a lot more interesting dualities by considering other truncations. Some examples would be discussed in [30].

<span id="page-20-1"></span>![](_page_20_Picture_0.jpeg)

Figure 5: The original theory has two gauge groups  $G_1$ ,  $G_2$  and two flavor groups denoted by  $N_1$ ,  $N_2$ . There are bifundamental matters between two gauge groups and fundamental charged over one of the gauge group. Dual theory has mesons as adjoint representations of two flavor groups, and the bi-fundamental matter. The spectrum of gauge singlet is determined by the meson spectrum of original theory.

<span id="page-20-2"></span>![](_page_20_Picture_2.jpeg)

**Figure 6**: The original theory has one gauge group G and two flavor groups denoted by  $N_1, N_2$  which could be further gauged. Dual theory has mesons in adjoint representations of  $U(N_1)$  and  $U(N_2)$  group, and there are also new fields in bifundamental representations of  $U(N_1)$  and  $U(N_2)$  group.

## <span id="page-20-0"></span>5 Conclusion

We discussed the general picture of duality of  $\mathcal{N}=1$  non-abelian gauge theory. The main point is that the spectrum of undressed mesons should take particular form to make the duality work. The spectrum is elegantly encoded in the factorization of polynomial  $y^n-1$  into a positive and a negative part  $y^n-1=\Phi_+\Phi_-$ . It is interesting to find physical models with those spectrum.

We mainly discussed the combinatorial nature of duality, and it would be interesting to study the dynamical consequences of the dualities. Notice that the duality often works even if there are subtle dynamical questions such as the appearance of accidental symmetry, and the dual description could be useful to answer some of the difficult dynamical questions.

In this paper, we only study the duality of gauge theory coupled with free matters. It would be interesting to generalize the duality to  $\mathcal{N}=1$  gauge theory coupled with strongly coupled matters. Many interesting  $\mathcal{N}=1$  theories can be formed by relevant deformation of  $\mathcal{N}=2$  theories [31], and it is interesting to generalize the consideration of this paper

to those more general cases. It is quite likely that the unusual meson spectrum studied in this paper could be realized in those models.

It would be interesting to generalize the consideration of this paper to 3d N = 2 theories.

## Acknowledgments

The work of Dan Xie is supported by national key research and development program of China (NO. 2020YFA0713000).

## <span id="page-22-0"></span>A Gauge invariant operators

We summarize the results of the invariant theory of groups, from which one can get the generators for the gauge invariant operators for a single gauge group. For more details, see [32]. The basic invariants for the classical gauge groups with fundamental representations are:

- 1. SU(n) group: one needs to have both the fields  $\phi$  in fundamental representation and u in anti-fundamental representations; The invariants are  $(u, \phi)$  and the bracket denotes the Hermitian form; and we also have the determinantal invariant  $\det(u_1, u_2, \dots, u_n)$ ,  $\det(\phi_1, \phi_2, \dots, \phi_n)$ .
- 2. SO(n) group:  $v_i^T v_j$  and  $det(v_1, v_2, \dots, v_n)$ .

3. 
$$Sp(n)$$
 group:  $v_i^T J v_j$  with  $J$  the matrix  $J = \begin{bmatrix} 0 & I_n \\ -I_n & 0 \end{bmatrix}$ .

<span id="page-22-1"></span>There are also relations between these invariants, and they are summarized in Table 6.

| SU(n) | $\det((u_i,\phi_j))_{i,j=1}^n = \det(u_1,\ldots,u_n)\det(\phi_1,\ldots,\phi_n),$                                                              |
|-------|-----------------------------------------------------------------------------------------------------------------------------------------------|
|       | $\sum_{i} (-1)^{i} \det(u_0, \dots, \hat{u_i}, \dots, u_n)(u_i, \phi) = 0,$                                                                   |
|       | $\sum_{i} (-1)^{i} \det \left( \phi_{0}, \dots, \hat{\phi}_{i}, \dots, \phi_{n} \right) (u, \phi_{i}) = 0,$                                   |
|       | $\sum_{i} (-1)^{i} \det(u_{0}, \dots, \hat{u}_{i}, \dots, u_{n}) \det(u_{i}, v_{1}, \dots, v_{n-1}) = 0,$                                     |
|       | $\sum_{i} (-1)^{i} \det \left( \phi_0, \dots, \hat{\phi}_i, \dots, \phi_n \right) \det \left( \phi_i, \psi_1, \dots, \psi_{n-1} \right) = 0.$ |
| SO(n) | $\det((u_i, v_j))_{i,j=0}^n = 0,$                                                                                                             |
|       | $\det((u_i, v_j))_{i,j=1}^n = \det(u_1, \dots, u_n) \det(v_1, \dots, v_n).$                                                                   |
| Sp(n) | $Pf((u_i, u_j))_{i,j=1}^{n+2} = 0.$                                                                                                           |

**Table 6**: The typical relations for the invariants of classical group. Here the hat over a vector means the omission from the sequence. The Plaffian of a matrix A is defined as  $Pf(A)^2 = \det A$ .

When there are tensor fields, one can build the invariants by first contracting the index and then forming the basic invariant. One uses metric g and  $g^{-1}$  in the SO type case to raise or lower the index, and anti-symmetric form w ( $w^{-1}$ ) in Sp group case to raise or lower the index.

The invariant tensors for exceptional groups are listed in Table 7, see also [25]. The relations for these invariants are more complicated.

| Lie algebra | Invariant tensor       |
|-------------|------------------------|
| $G_2$       | $\delta^{ab}, f^{abc}$ |
| $F_4$       | $\delta^{ab}, d^{abc}$ |
| $E_6$       | $d^{abc}$              |
| $E_7$       | $f^{abc}, d^{abc}$     |
| $E_8$       | $\delta^{AB}, f^{ABC}$ |

<span id="page-23-2"></span>**Table 7**: Invariant tensors for fundamental representation of the exceptional group. Here d is the symmetric tensor, f is the anti-symmetric tensor.

## <span id="page-23-0"></span>B Anomaly computations for classical groups

In this appendix, we will compute the  $\operatorname{Tr} R$  and  $\operatorname{Tr} R^3$  anomalies for gauge theory with classical gauge group.

### <span id="page-23-1"></span>B.1 Adjoint matter

Let's do anomaly computation for the duality of classical gauge groups. We assume that the tensorial fields are all adjoint fields.

First, we have the anomaly free condition for  $U(1)_R$  symmetry:

$$h^{\vee} \left[\sum_{u} (R_u - 1) + 1\right] + (R_c - 1)N_f^* = 0,$$
  
$$h^{\vee} \left[\sum_{u} (R_u - 1) + 1\right] + (R_{c^*} - 1)N_f^* = 0.$$

**B,D** gauge group: For  $SO(N_c)$  gauge group, define  $x = \sum_u (R_u - 1) + 1$ . We have

$$\operatorname{Tr} R = x \dim G + 2N_f N_c (R_c - 1),$$

$$\operatorname{Tr} R_{\text{dual}} = x \dim G' + 2N_f N_c' (R_{c^*} - 1) + (2N_f^2 + N_f) \sum_{j \text{ even}} [(2R_c + R_j) - 1]$$

$$+ (2N_f^2 - N_f) \sum_{j \text{ odd}} [(2R_c + R_j) - 1].$$

Now assume that one can define a parity on the set of adjoint fields, and so the set of mesons built from adjoint also has a parity: there are  $\frac{a-1}{2}$  odd mesons (anti-symmetric representation of Sp flavor group), and  $\frac{a+1}{2}$  even mesons (symmetric representation of Sp flavor group). We have

$$\operatorname{Tr} R_{\text{dual}} = x \dim G' + 2N_f N_c' (R_{c^*} - 1) + (2N_f^2 + N_f) [(2R_c \frac{a+1}{2} + \Delta \frac{a+1}{4}) - \frac{a+1}{2}]$$

$$+ (2N_f^2 - N_f) [(2R_c \frac{a-1}{2} + \Delta \frac{a-1}{4}) - \frac{a-1}{2}]$$

$$= x \dim G' + 2N_f N_c' (R_{c^*} - 1) + 2N_f (2aN_f + 1) [R_c + \frac{\Delta}{4} - \frac{1}{2}].$$

Here dim  $G = \frac{1}{2}(N_c^2 - N_c)$ , and  $N_c' = 2aN_f - N_c + 4$ ,  $R_{c^*} - 1 = -R_c - \frac{\Delta}{2}$ . Using  $R_c = 1 - \frac{(N_c - 2)x}{2N_f}$ ,  $a = \frac{\Delta + 2}{2x}$ , one can finally check that Tr  $R_{\text{dual}} = \text{Tr } R$ .

Next we check that  $\operatorname{Tr} R^3 = \operatorname{Tr} R^3_{\text{dual}}$ . The original and dual  $R^3$  anomalies are

$$\operatorname{Tr} R^{3} = \frac{1}{2} (N_{c}^{2} - N_{c}) \left[ \sum_{u} (R_{u} - 1)^{3} + 1 \right] + 2N_{c}N_{f}(R_{c} - 1)^{3},$$

$$\operatorname{Tr} R_{dual}^{3} = \frac{1}{2} (N_{c}^{\prime 2} - N_{c}^{\prime}) \left[ \sum_{u} (R_{u} - 1)^{3} + 1 \right] + 2N_{c}^{\prime}N_{f}(R_{c^{*}} - 1)^{3}$$

$$+ (2N_{f}^{2} + N_{f}) \sum_{j \text{ even}} \left[ (2R_{c} + R_{j}) - 1 \right]^{3} + (2N_{f}^{2} - N_{f}) \sum_{j \text{ odd}} \left[ (2R_{c} + R_{j}) - 1 \right]^{3}.$$

Substitute  $N_c' = 2aN_f - N_c + 4$ ,  $R_{c^*} = 1 - R_c - \frac{\Delta}{2}$ . Define  $x = \sum_u (R_u - 1)^3$ ;  $y_1 = \sum_{j \text{ odd}} (R_j - 1)$ ,  $y_2 = \sum_{j \text{ even}} (R_j - 1)$ ;  $z_1 = \sum_{j \text{ odd}} (R_j - 1)^2$ ,  $z_2 = \sum_{j \text{ even}} (R_j - 1)^2$ ;  $w_1 = \sum_{j \text{ odd}} (R_j - 1)^3$ ,  $w_2 = \sum_{j \text{ even}} (R_j - 1)^3$ . Then we have  $\operatorname{Tr} R^3 = \operatorname{Tr} R^3_{\text{dual}}$  if these numbers satisfy the following equations:

<span id="page-24-0"></span>
$$y_{1} = \frac{1}{4}(a-1)(\Delta-2), \ y_{2} = \frac{1}{4}(a+1)(\Delta-2),$$

$$z_{1} = -\frac{4a^{2}x + 4a^{2} - 2a\Delta^{3} - 12ax - 28a + 3\Delta^{3} + 6\Delta^{2} + 12\Delta + 24}{12(\Delta+2)},$$

$$z_{2} = -\frac{4a^{2}x + 4a^{2} - 2a\Delta^{3} + 12ax - 4a - 3\Delta^{3} - 6\Delta^{2} - 12\Delta - 24}{12(\Delta+2)},$$

$$w_{1} = -\frac{4a^{2}\Delta x + 4a^{2}\Delta - 8a^{2}x - 8a^{2} - a\Delta^{4} - 12a\Delta x - 12a\Delta + 24ax + 40a + 2\Delta^{4} + 4\Delta^{3} - 16\Delta - 32}{8(\Delta+2)},$$

$$w_{2} = -\frac{4a^{2}\Delta x + 4a^{2}\Delta - 8a^{2}x - 8a^{2} - a\Delta^{4} + 12a\Delta x + 12a\Delta - 24ax - 8a - 2\Delta^{4} - 4\Delta^{3} + 16\Delta + 32}{8(\Delta+2)}.$$
(B.1)

One can check that other global anomalies also match.

**C** gauge group: For  $Sp(N_c)$  gauge group, define  $x = \sum_u (R_u - 1) + 1$ . We have

$$\operatorname{Tr} R = x \dim G + 2N_f N_c (R_c - 1),$$

$$\operatorname{Tr} R_{\text{dual}} = x \dim G' + 2N_f N_c' (R_{c^*} - 1) + (2N_f^2 - N_f) \sum_{j \text{ even}} [(2R_c + R_j) - 1]$$

$$+ (2N_f^2 + N_f) \sum_{j \text{ odd}} [(2R_c + R_j) - 1].$$

Now assume that one can define a parity on the set of adjoint fields, and so the set of mesons built from adjoint also has a parity: there are  $\frac{a-1}{2}$  odd mesons (symmetric representation of flavor group), and  $\frac{a+1}{2}$  even mesons (anti-symmetric representation of flavor group). We have

$$\operatorname{Tr} R_{\text{dual}} = x \operatorname{dim} G' + 2N_f N_c' (R_{c^*} - 1) + (2N_f^2 - N_f) [(2R_c \frac{a+1}{2} + \Delta \frac{a+1}{4}) - \frac{a+1}{2}]$$

$$+ (2N_f^2 + N_f) [(2R_c \frac{a-1}{2} + \Delta \frac{a-1}{4}) - \frac{a-1}{2}]$$

$$= x \operatorname{dim} G' + 2N_f N_c' (R_{c^*} - 1) + 2N_f (2aN_f - 1) [R_c + \frac{\Delta}{4} - \frac{1}{2}].$$

We have  $\dim G = \frac{1}{2}(N_c^2 + N_c)$ , and  $N_c' = 2aN_f - N_c - 4$ ,  $R_{c^*} - 1 = -R_c - \frac{\Delta}{2}$ . Using  $R_c = 1 - \frac{(N_c + 2)x}{2N_f}$ ,  $a = \frac{\Delta + 2}{2x}$ , one can finally check that  $\operatorname{Tr} R_{\text{dual}} = \operatorname{Tr} R$ .

We can also check that  $\operatorname{Tr} R^3 = \operatorname{Tr} R^3_{\text{dual}}$  if these numbers  $x, y_1, y_2, z_1, z_2, w_1, w_2$  satisfy the same equation B.1.

#### <span id="page-25-1"></span><span id="page-25-0"></span>B.2 Other matter

### B.2.1 B,D gauge group with symmetric matter

First, we have the anomaly free condition for  $U(1)_R$  symmetry:

$$h^{\vee} + (h^{\vee} + 4) [\sum_{u} (R_u - 1)] + (R_c - 1) N_f^* = 0,$$
  
 $h^{\vee} + (h^{\vee} + 4) [\sum_{u} (R_u - 1)] + (R_{c^*} - 1) N_f^* = 0.$ 

So we have

$$h^{\vee'} = aN_f^* - h^{\vee} - \frac{8x - 8}{r}.$$

Here  $a = \frac{\Delta+2}{2x}$ ,  $x = \sum_{u} (R_u - 1) + 1$ . The anomalies are

$$\operatorname{Tr} R = \frac{1}{2} (N_c^2 - N_c) + \frac{1}{2} (N_c^2 + N_c) \sum_u (R_u - 1) + 2N_f N_c (R_c - 1),$$

$$\operatorname{Tr} R_{\text{dual}} = \frac{1}{2} (N_c^{'2} - N_c^{'}) + \frac{1}{2} (N_c^{'2} + N_c^{'}) \sum_u (R_u - 1) + 2N_f N_c^{'} (R_{c^*} - 1)$$

$$+ (2N_f^2 + N_f) \sum_{j \in I} [(2R_c + R_j) - 1] + (2N_f^2 - N_f) \sum_{j \notin I} [(2R_c + R_j) - 1].$$

For A type potential, I is the whole set of mesons. For D type potential, I denotes the combination  $u^a v^b$  such that ab is even.

More generally, assume that there are m symmetric mesons, and n antisymmetric mesons under the flavor symmetry. We may fix m, n by matching the anomalies. First we need to have the match of Tr R anomaly:

$$\operatorname{Tr} R_{\text{dual}} = \frac{1}{2} (N_c^{'2} - N_c^{'}) + \frac{1}{2} (N_c^{'2} + N_c^{'}) \sum_{u} (R_u - 1) + 2N_f N_c^{'} (R_{c^*} - 1)$$

$$+ (2N_f^2 + N_f)(m) [2R_c + d/2 - 1] + (2N_f^2 - N_f)(n) [(2R_c + d/2 - 1]].$$

The  $\operatorname{Tr} RUSp(2N_f)^2$  anomalies in electric and magnetic frames are

$$\operatorname{Tr} RFF = \frac{1}{2}N_c(R_c - 1),$$

$$\operatorname{Tr} R_{\text{dual}}FF = \left(\frac{d}{2} + 2R_c - 1\right)\left((m)(N_f + 1) + (n)(N_f - 1)\right) + \frac{1}{2}N'_c(R_{c^*} - 1).$$

By solving  $\operatorname{Tr} R = \operatorname{Tr} R_{\operatorname{dual}}$  and  $\operatorname{Tr} RFF = \operatorname{Tr} R_{\operatorname{dual}}FF$  at the same time, we find m,n:

$$m = -\frac{-d + 2x - 6}{4x} = \frac{a}{2} + \frac{4 - 2x}{4x},$$
$$n = -\frac{-d - 2x + 2}{4x} = \frac{a}{2} - \frac{4 - 2x}{4x}.$$

For  $A_k$  type potential,  $x = \frac{2}{k+1}$ , a = k, we have m = k = a, n = 0. For  $D_k$  type potential,  $x = \frac{1}{k+1}$ , a = 3k, we have  $m = \frac{5k+1}{2}$ ,  $n = \frac{k-1}{2}$ . When k is odd, it gives a possible duality. It is possible to find other solutions from the factorization of the polynomials  $y^n - 1$ .

### <span id="page-26-0"></span>B.2.2 C gauge group with anti-symmetric matter

First, we have the anomaly free condition for  $U(1)_R$  symmetry:

$$h^{\vee} + (h^{\vee} - 2) \left[ \sum_{u} (R_u - 1) \right] + (R_c - 1) N_f^* = 0,$$
  
$$h^{\vee} + (h^{\vee} - 2) \left[ \sum_{u} (R_u - 1) \right] + (R_{c^*} - 1) N_f^* = 0.$$

So we have

$$h^{\vee'} = aN_f^* - h^{\vee} + \frac{4x - 4}{x},$$
  
 $R_c = 1 - \frac{(N_c + 2)x - 4(x - 1)}{2N_f}.$ 

Here  $a = \frac{\Delta+2}{2x}$ ,  $x = \sum_{u} (R_u - 1) + 1$ . So  $N'_c = 2aN_f - N_c + \frac{8x-8}{x} - 4$ . The anomalies are

$$\operatorname{Tr} R = \frac{1}{2} (N_c^2 + N_c) + \frac{1}{2} (N_c^2 - N_c) \sum_{u} (R_u - 1) + 2N_f N_c (R_c - 1),$$

$$\operatorname{Tr} R_{\text{dual}} = \frac{1}{2} (N_c^{'2} + N_c^{'}) + \frac{1}{2} (N_c^{'2} - N_c^{'}) \sum_{u} (R_u - 1) + 2N_f N_c^{'} (R_{c^*} - 1)$$

$$+ (2N_f^2 - N_f) \sum_{j \in I} [(2R_c + R_j) - 1] + (2N_f^2 + N_f) \sum_{j \notin I} [(2R_c + R_j) - 1].$$

For A type potential, I is the whole set of mesons. For D type potential, I denotes the combination  $u^a v^b$  such that ab is even.

## <span id="page-26-2"></span><span id="page-26-1"></span>A gauge group with a pair of symmetric (and its conjugate) (X, X)

![](_page_26_Picture_11.jpeg)

**Figure 7:** A gauge group with a pair of symmetric and its conjugate matters.

First, we have the anomaly free condition for  $U(1)_R$  symmetry:

$$N_c + (\frac{N_c}{2} + 1) \sum_u (R_u - 1) + (R_c - 1) N_f = 0,$$
  
$$N'_c + (\frac{N'_c}{2} + 1) \sum_u (R_u - 1) + (R_{c^*} - 1) N_f = 0.$$

We have

$$N'_{c} = aN_{f} - N_{c} - \frac{4x}{x+2},$$

$$R_{c} = 1 - \frac{N_{c}(1+x/2) + x}{N_{f}}.$$

Here  $x = \sum_{u} (R_u - 1)$  and  $a = \frac{\Delta + 2}{x + 2}$ .  $R_c$  and  $R_{c^*}$  are still paired as  $R_c + R_{c^*} = 1 - \frac{\Delta}{2}$ , and  $\Delta$  is the pairing constant of the (undressed) mesons.

If there is a single pair of symmetric matter, with the superpotential  $\operatorname{Tr}\left(X\tilde{X}\right)^{k+1}$ , then the dressed mesons are  $(M_j)^{f\dot{g}} \equiv Q^f(\tilde{X}X)^j\tilde{Q}^{\dot{g}}, \ j=0,\ldots,k,\ (P_r)^{fg} \equiv Q^f(\tilde{X}X)^r\tilde{X}Q^g$  and  $(\tilde{P}_r)^{\dot{f}\dot{g}} \equiv \tilde{Q}^{\dot{f}}X(\tilde{X}X)^r\tilde{Q}^{\dot{g}}, r=0,\ldots,k-1$  where  $M_j$ 's are adjoint and  $P_r, \tilde{P}_r$ 's are symmetric tensors of the flavor group. There are k+1 adjoint mesons, and 2k symmetric mesons. The transformation property is that of the flavor group.

For Figure 7 we have  $x = 2R_u - 2$ ,  $\Delta = 2kR_u = (2+x)k$  and thus a = 2k+1 4. So the anomalies are

$$\operatorname{Tr} R = N_c^2 + \frac{1}{2}(N_c^2 + N_c) \sum_{u} (R_u - 1) + 2N_f N_c (R_c - 1),$$

$$\operatorname{Tr} R_{\text{dual}} = N_c^{'2} + \frac{1}{2}(N_c^{'2} + N_c^{'}) \sum_{u} (R_u - 1) + 2N_f N_c^{'} (R_{c^*} - 1)$$

$$+ N_f^2 \sum_{\text{adjoint mesons}} (2R_c + R_j - 1) + \frac{N_f^2 + N_f}{2} \sum_{\text{symmetric mesons}} (2R_c + R_j - 1)$$

$$= N_c^{'2} + \frac{1}{2}(N_c^{'2} + N_c^{'}) \sum_{u} (R_u - 1) + 2N_f N_c^{'} (R_{c^*} - 1)$$

$$+ N_f^2 (k + 1)(2R_c - 1 + \Delta/2) + \frac{N_f^2 + N_f}{2} 2k(2R_c - 1 + \Delta/2).$$

<span id="page-27-0"></span>Then one can finally check that  $\operatorname{Tr} R_{\text{dual}} = \operatorname{Tr} R$ .

## B.2.4 A gauge group with pairs of anti-symmetric (and its conjugate) $(X, \tilde{X})$

First, we have the anomaly free condition for  $U(1)_R$  symmetry:

$$N_c + (\frac{N_c}{2} - 1) \sum_u (R_u - 1) + (R_c - 1) N_f = 0,$$
  
$$N'_c + (\frac{N'_c}{2} - 1) \sum_u (R_u - 1) + (R_{c^*} - 1) N_f = 0.$$

We have

$$N'_c = aN_f - N_c + \frac{4x}{x+2},$$
  
 $R_c = 1 - \frac{N_c(1+x/2) - x}{N_f}.$ 

<span id="page-27-1"></span> $<sup>^4</sup>$ In this case, the number a appeared in the dual gauge group rank is not equal to the number of mesons in the spectrum.

Here  $x = \sum_{u} (R_u - 1)$  and  $a = \frac{\Delta + 2}{x + 2}$ .  $R_c$  and  $R_{c^*}$  are still paired as  $R_c + R_{c^*} = 1 - \frac{\Delta}{2}$ , and  $\Delta$  is the pairing constant of the (undressed) mesons.

If there is a single pair of symmetric matter, with the superpotential  $\text{Tr}\left(X\tilde{X}\right)^{k+1}$ , then the dressed mesons are  $(M_j)^{f\dot{g}} \equiv Q^f(\tilde{X}X)^j\tilde{Q}^{\dot{g}}, \ j=0,\ldots,k,\ (P_r)^{fg} \equiv Q^f(\tilde{X}X)^r\tilde{X}Q^g$  and  $(\tilde{P}_r)^{\dot{f}\dot{g}} \equiv \tilde{Q}^{\dot{f}}X(\tilde{X}X)^r\tilde{Q}^{\dot{g}}, \ r=0,\ldots,k-1$  where  $M_j$ 's are adjoint and  $P_r,\tilde{P}_r$ 's are antisymmetric tensors of the flavor group.

For Figure 7 we have  $x = 2R_u - 2$ ,  $\Delta = 2kR_u = (2+x)k$  and thus a = 2k+1. So the anomalies are

$$\operatorname{Tr} R = N_c^2 + \frac{1}{2} (N_c^2 - N_c) \sum_{u} (R_u - 1) + 2N_f N_c (R_c - 1),$$

$$\operatorname{Tr} R_{\text{dual}} = N_c^{'2} + \frac{1}{2} (N_c^{'2} - N_c^{'}) \sum_{u} (R_u - 1) + 2N_f N_c^{'} (R_{c^*} - 1)$$

$$+ N_f^2 \sum_{\text{adjoint mesons}} (2R_c + R_j - 1) + \frac{N_f^2 - N_f}{2} \sum_{\text{anti-symmetric mesons}} (2R_c + R_j - 1)$$

$$= N_c^{'2} + \frac{1}{2} (N_c^{'2} - N_c^{'}) \sum_{u} (R_u - 1) + 2N_f N_c^{'} (R_{c^*} - 1)$$

$$+ N_f^2 (k + 1)(2R_c - 1 + \Delta/2) + \frac{N_f^2 - N_f}{2} 2k(2R_c - 1 + \Delta/2).$$

<span id="page-28-0"></span>Then one can finally check that  $\operatorname{Tr} R_{\text{dual}} = \operatorname{Tr} R$ 

## C Formula for superconformal index

The formula relevant for the computation of the large  $N_c$ ,  $N_f$  index:

$$g_E = \bar{g}_E = \frac{t^{R_c} - t^{2-R_c}}{(1 - tx)(1 - tx^{-1})},$$

$$g_M = \bar{g}_M = \frac{t^{R_{c^*}} - t^{2-R_{c^*}}}{(1 - tx)(1 - tx^{-1})},$$

$$f = \frac{2t^2 - t(x + x^{-1}) + \sum_{u=1}^{N_A} (t^{R_u} - t^{2-R_u})}{(1 - tx)(1 - tx^{-1})},$$

$$h(M_I) = \frac{t^{2R_c + R_j} - t^{2-(2R_c + R_j)}}{(1 - tx)(1 - tx^{-1})}.$$

Here  $R_c$  is the R charge for the fundamental fields c, and  $R_{c^*}$  is the R charge for the dual fundamental fields  $c^*$ .  $R_u$ 's are the R charges for the adjoint fields and their values are the same for electric and magnetic theory. Finally,  $M_I$  denotes the dressed meson whose R charge is  $2R_c + R_j$ , with  $R_j$  the R charge for the meson  $u_I$  formed by adjoint chiral field.

#### References

<span id="page-28-1"></span>[1] N. Seiberg. Electric - magnetic duality in supersymmetric nonAbelian gauge theories. *Nucl. Phys. B*, 435:129–146, 1995.

- <span id="page-29-0"></span>[2] Kenneth A. Intriligator and N. Seiberg. Lectures on supersymmetric gauge theories and electric-magnetic duality. *Nucl. Phys. B Proc. Suppl.*, 45BC:1–28, 1996.
- <span id="page-29-1"></span>[3] D. Kutasov. A Comment on duality in N=1 supersymmetric nonAbelian gauge theories. *Phys. Lett. B*, 351:230–234, 1995.
- <span id="page-29-2"></span>[4] D. Kutasov and A. Schwimmer. On duality in supersymmetric Yang-Mills theory. *Phys. Lett. B*, 354:315–321, 1995.
- <span id="page-29-3"></span>[5] John H. Brodie. Duality in supersymmetric SU(N(c)) gauge theory with two adjoint chiral superfields. *Nucl. Phys. B*, 478:123–140, 1996.
- <span id="page-29-4"></span>[6] Kenneth A. Intriligator, R. G. Leigh, and M. J. Strassler. New examples of duality in chiral and nonchiral supersymmetric gauge theories. *Nucl. Phys. B*, 456:567–621, 1995.
- [7] Kenneth A. Intriligator and N. Seiberg. Duality, monopoles, dyons, confinement and oblique confinement in supersymmetric SO(N(c)) gauge theories. *Nucl. Phys. B*, 444:125–160, 1995.
- [8] P. Pouliot. Duality in SUSY SU(N) with an antisymmetric tensor. *Phys. Lett. B*, 367:151–156, 1996.
- [9] John H. Brodie and Matthew J. Strassler. Patterns of duality in N=1 SUSY gauge theories, or: Seating preferences of theater going nonAbelian dualities. *Nucl. Phys. B*, 524:224–250, 1998.
- [10] P. Pouliot and M. J. Strassler. A Chiral SU(n) gauge theory and its nonchiral spin(8) dual. *Phys. Lett. B*, 370:76–82, 1996.
- <span id="page-29-5"></span>[11] P. Pouliot and M. J. Strassler. Duality and dynamical supersymmetry breaking in Spin(10) with a spinor. *Phys. Lett. B*, 375:175–180, 1996.
- <span id="page-29-6"></span>[12] David Kutasov and Jennifer Lin. Exceptional N=1 Duality. 1 2014.
- <span id="page-29-7"></span>[13] Kenneth A. Intriligator and Brian Wecht. RG fixed points and flows in SQCD with adjoints. *Nucl. Phys. B*, 677:223–272, 2004.
- <span id="page-29-8"></span>[14] David Kutasov and Jennifer Lin. N=1 Duality and the Superconformal Index. 2 2014.
- <span id="page-29-9"></span>[15] Borut Bajc. Kutasov-Seiberg dualities and cyclotomic polynomials. *JHEP*, 06:083, 2019.
- <span id="page-29-10"></span>[16] FA Dolan and H Osborn. Applications of the superconformal index for protected operators and q-hypergeometric identities to n= 1 dual theories. *Nuclear Physics B*, 818(3):137–178, 2009.
- <span id="page-29-11"></span>[17] V. P. Spiridonov and G. S. Vartanov. Elliptic Hypergeometry of Supersymmetric Dualities. *Commun. Math. Phys.*, 304:797–874, 2011.
- <span id="page-29-12"></span>[18] D. Anselmi, D. Z. Freedman, Marcus T. Grisaru, and A. A. Johansen. Nonperturbative formulas for central functions of supersymmetric gauge theories. *Nucl. Phys. B*, 526:543–571, 1998.
- <span id="page-29-13"></span>[19] Jay Banks and Howard Georgi. Comment on gauge theories without anomalies. *Physical Review D*, 14(4):1159, 1976.
- <span id="page-29-14"></span>[20] Edward Witten. An su (2) anomaly. *Physics Letters B*, 117(5):324–328, 1982.
- <span id="page-29-15"></span>[21] Hermann Weyl. *The classical groups: their invariants and representations*, volume 45. Princeton university press, 1946.
- <span id="page-29-16"></span>[22] P. Pouliot. Chiral duals of nonchiral SUSY gauge theories. *Phys. Lett. B*, 359:108–113, 1995.

- <span id="page-30-0"></span>[23] Csaba Csaki, Martin Schmaltz, Witold Skiba, and John Terning. Selfdual N=1 SUSY gauge theories. *Phys. Rev. D*, 56:1228–1238, 1997.
- <span id="page-30-1"></span>[24] Anson Hook. New self dualities and duality cascades. *Phys. Rev. D*, 89(8):086009, 2014.
- <span id="page-30-2"></span>[25] Steven B. Giddings and John M. Pierre. Some exact results in supersymmetric theories based on exceptional groups. *Phys. Rev. D*, 52:6065–6073, 1995.
- <span id="page-30-3"></span>[26] Pierre Ramond. Superalgebras in N=1 gauge theories. *Phys. Lett. B*, 390:179–184, 1997.
- <span id="page-30-4"></span>[27] Jacques Distler and Andreas Karch. N=1 dualities for exceptional gauge groups and quantum global symmetries. *Fortsch. Phys.*, 45:517–533, 1997.
- <span id="page-30-5"></span>[28] Dan Xie and Masahito Yamazaki. Network and Seiberg Duality. *JHEP*, 09:036, 2012.
- <span id="page-30-6"></span>[29] Yuanyuan Fang, Jing Feng, and Dan Xie. Three dimensional quotient singularity and 4d N = 1 AdS/CFT correspondence. 10 2023.
- <span id="page-30-7"></span>[30] Yuanyuan Fang, Jing Feng, and Dan Xie. Two node quiver gauge theory, to appear.
- <span id="page-30-8"></span>[31] Dan Xie. Soft supersymmetry breaking of 4d N = 2 SCFT. 5 2019.
- <span id="page-30-9"></span>[32] VL Popov, TA Springer, and EB Vinberg. *Algebraic Geometry IV: Linear Algebraic Groups Invariant Theory*, volume 55. Springer Science & Business Media, 2012.