# K stability and stability of chiral ring

# Tristan C. Collins<sup>a</sup> Dan Xieb,c Shing-Tung Yaua,b,c

Abstract: We define a notion of stability for chiral ring of four dimensional N = 1 theory by introducing test chiral rings and generalized a maximization. We conjecture that a chiral ring is the chiral ring of a superconformal field theory if and only if it is stable. We then study N = 1 field theory derived from D3 branes probing a three-fold singularity X, and show that the K stability which implies the existence of Ricci-flat conic metric on X is equivalent to the stability of chiral ring of the corresponding field theory.

<sup>a</sup>Department of Mathematics, Harvard University, Cambridge, MA 02138, USA

<sup>b</sup>Center of Mathematical Sciences and Applications, Harvard University, Cambridge, 02138, USA

<sup>c</sup>Jefferson Physical Laboratory, Harvard University, Cambridge, MA 02138, USA

| 1<br>Introduction<br>2<br>Generality of chiral ring |                                                       |                                                 | 1<br>5                                                                                                                               |
|-----------------------------------------------------|-------------------------------------------------------|-------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------|
|                                                     |                                                       |                                                 |                                                                                                                                      |
| 3.1                                                 |                                                       |                                                 | 7                                                                                                                                    |
| 3.2                                                 |                                                       |                                                 | 9                                                                                                                                    |
|                                                     | 3.2.1                                                 | Test configurations                             | 9                                                                                                                                    |
|                                                     | 3.2.2                                                 | Futaki invariant and generalized a-maximization | 10                                                                                                                                   |
|                                                     | 3.2.3                                                 | Some discussions                                | 13                                                                                                                                   |
|                                                     |                                                       |                                                 | 13                                                                                                                                   |
| 4.1                                                 | a-maximization                                        |                                                 | 13                                                                                                                                   |
| 4.2                                                 | Unitarity bound                                       |                                                 | 14                                                                                                                                   |
| 4.3                                                 | Singularity with more than one dimensional symmetries |                                                 | 14                                                                                                                                   |
| 4.4                                                 | Hypersurface singularity                              |                                                 | 15                                                                                                                                   |
|                                                     | 4.4.1                                                 | Irrelevance of superpotential term              | 15                                                                                                                                   |
|                                                     | 4.4.2                                                 | Further obstructions                            | 17                                                                                                                                   |
| 5<br>Conclusion                                     |                                                       |                                                 | 18                                                                                                                                   |
|                                                     |                                                       | Contents                                        | The chiral ring, Hilbert series and the central charge a<br>K Stability and generalized a-maximization<br>Some physical consequences |

# <span id="page-1-0"></span>1 Introduction

The chiral ring of a four dimensional N = 1 theory plays a crucial role in understanding the dynamics of the theory. In particular, the chiral ring can be used to determine the structure of the moduli space of vacua and the phase structure [\[1](#page-19-0)]. Moreover, the chiral ring structure seems to be still quite important even if the theory has a unique vacua [\[2](#page-19-1), [3\]](#page-19-2).

However, little is known about the general structure of the chiral ring of N = 1 theory. The purpose of this paper is to study the chiral ring of a superconformal field theory (SCFT). We ask the following question: when is a chiral ring R the chiral ring of a SCFT? An obvious necessary condition is that the chiral ring has to be graded, since for a SCFT there is always a U(1)<sup>R</sup> symmetry which acts non-trivially on all of the chiral operators. In particular, we really should start with a polarized chiral ring (R, ζ) and ask whether it is a chiral ring of a SCFT with U(1)<sup>R</sup> symmetry ζ. On the other hand, It is also known that the existence of a grading is not sufficient.

A second motivation for asking above question is the following: in many studies of supersymmetric field theory we start with an asymptotically free gauge theory T and assume that it flows to a SCFT T<sup>0</sup> at a certain point of the moduli space (often the most singular point). We can compute the chiral ring R of the theory T , and let us denote by R<sup>0</sup> the chiral ring of T0. Many interesting quantities of the SCFT T<sup>0</sup> can be computed if R = R0. For example, we can use a maximization to determine the U(1)<sup>R</sup> symmetry [\[4\]](#page-19-3) of T0. In general, however, R<sup>0</sup> can differ from R, for example:

- (a) It is believed that the chiral ring R of N = 1 SU(Nc) SQCD with <sup>3</sup> <sup>2</sup>N<sup>c</sup> < N<sup>f</sup> < 3N<sup>c</sup> is the chiral ring R<sup>0</sup> of the SCFT at the origin of the moduli space [\[5,](#page-20-0) [6\]](#page-20-1);
- (b) If N<sup>c</sup> < N<sup>f</sup> ≤ <sup>3</sup> <sup>2</sup>Nc, the chiral ring R of SQCD is not the chiral ring R<sup>0</sup> of the SCFT at the origin, as the mesons become free at the SCFT point [\[5](#page-20-0), [6](#page-20-1)];
- (c) A trivial example is a chiral scalar φ with cubic superpotential, and the chiral ring R of this theory is generated by the ideal φ <sup>2</sup> = 0. However, the superpotential is marginally irrelevant at SCFT point, and the IR SCFT is free so its chiral ring R<sup>0</sup> is free generated by operator φ and is different from R.

From above examples, we learn that the possible reasons for R failing to be the chiral ring of a SCFT are:

- Some operators hit the unitarity bound and become free at SCFT point, and this also modifies the chiral ring.
- Certain superpotential term is irrelevant at the SCFT point, and we should not impose the constraint from superpotential for chiral operators of SCFT T<sup>0</sup> [1](#page-2-0) ;
- There might be some other unknown dynamics that would lead to different chiral ring for SCFT. We do not have a systematical way to detect them.

We can learn several interesting lessons from the above examples. Firstly R<sup>0</sup> has more symmetries than R. Namely, there is a new symmetry generator acting on O alone if O hits unitarity bound and becomes free; If a superpotential term formed by an operator O becomes irrelevant, there could be a new symmetry acting on this operator O alone. Secondly, R<sup>0</sup> either leads to higher central charge a [2](#page-2-1) , or the same central charge as evidenced by example (c), but no less central charge.

Motivated by above examples, we introduce a notion of stability on chiral ring to characterize whether R = R<sup>0</sup> and this notion also gives a method to define the chiral ring of a SCFT. The definition involves two basic elements: test chiral ring and generalized a maximization.

Let's first discuss the test chiral ring. From above examples, if the chiral ring R fails to be the chiral ring of a SCFT, there is an associated different chiral ring R0: R<sup>0</sup> can be derived by forgetting some of the superpotential terms if R is derived from a quiver gauge theory, etc. More generally R<sup>0</sup> should have more symmetries, and it should satisfy certain continuity condition with respect to R. Based on those observations, we propose:

<sup>1</sup>Notice that we can not ignore such superpotential term for T as it could be relevant at other vacua, and they are called dangerously irrelevant operator in [\[7\]](#page-20-2).

<span id="page-2-1"></span><span id="page-2-0"></span><sup>2</sup>This does not violate the a theorem, as R is not the chiral ring of a SCFT.

Definition 1.1 A test chiral ring R<sup>0</sup> can be derived from R by using a symmetry generator η on R and taking a flat limit.

Let's discuss more precisely what this definition means. Assume that the chiral ring R is given by

$$R = \frac{C[x_0, x_1, \dots, x_n]}{I},$$
(1.1)

here x<sup>i</sup> , i = 0, . . . , n are the generators of chiral ring and I = (f1, f2, . . . , fm) is the ideal which gives the chiral ring relation among the generators. Now consider a one parameter subgroup η(t) of C <sup>n</sup>+1 and define its action on the elements of idea I as

$$f(t) = \lambda(t) \cdot f = f(\lambda(t) \cdot (x_0, x_1, \dots, x_n)). \tag{1.2}$$

So we have a family of rings R<sup>t</sup> = C[x0,x1,...,xn] It parameterized by t. The flat limit I<sup>0</sup> = limt→0I<sup>t</sup> is defined as follows. We can decompose any f ∈ I as f = f<sup>1</sup> + . . . + f<sup>k</sup> into elements in distinct weight spaces for the C <sup>∗</sup> action η on C[x0, ..., xn]. Let us write in(f) for the element f<sup>i</sup> with the smallest weight, which we can think of as the "initial term" of f. Then I<sup>0</sup> is the ideal generated by the set of initial terms {in(f)|f ∈ I}. The test chiral ring is defined as R<sup>0</sup> = C[x0,x1,...,xn] I0 .

The test chiral ring has the following crucial proerties: a) The flat limit is the same if we use the symmetry generator sη with s > 0; b) R<sup>0</sup> is invariant with respect to symmetries of R and η; c): The Hilbert series of R and R<sup>0</sup> are the same for the symmetries of R, this is the continuity condition on test configuration. Using above procedure, we can get infinite number of test chiral rings. The criteria for determining whether a test chiral ring R<sup>0</sup> destabilizes a polarized ring (R, ζ) is

Definition 1.2 A test chiral ring R<sup>0</sup> destabilizes (R, ζ) if R<sup>0</sup> gives no less central charge a with respect to the space of possible U(1)<sup>R</sup> symmetries aζ + sη, s ≥ 0.

It is crucial that s ≥ 0 so we have the same test chiral ring using the symmetry generator sη on R. Now we state the definition of stable chiral ring:

Definition 1.3 A polarized chiral ring (R, ζ) is called stable if there is no destabilizing test chiral ring.

This definition can be thought of as the generalized a maximization procedure. For the original a maximization procedure [\[4](#page-19-3)], we do not change the chiral ring, namely we only use the symmetry generator of R to generate the test chiral ring, and the flat limit R<sup>0</sup> is the same as R. The hidden assumption in this process is that the ring R is already the ring of a SCFT, and we would like to determine the correct U(1)<sup>R</sup> symmetry.

Once we define the notion of stability of chiral ring, we would like to state the main conjecture of this paper:

Conjecture 1.1 A polarized chiral ring (R, ζ) is the chiral ring of a SCFT if and only if it is stable.

This conjecture answers the question when a chiral ring can be that of a SCFT. We would like to test the above conjecture for general class of N = 1 theories. However, we face several difficulties. First, it is usually not easy to derive the full chiral ring of a theory, and so examples are in short supply. Secondly, we do not know how to characterize the U(1)<sup>R</sup> like symmetry from the chiral ring itself. Thirdly, it is not known how to determine the trial central charge a(ζ) for a symmetry ζ from the chiral ring itself. However, these problems are solved for a class of models arising from string theory. Precisely, it is possible to determine the exact chiral ring for N = 1 theories derived from N D3 branes probing a three dimensional singularity [\[8](#page-20-3)]: the 3d singularity can be defined by an affine variety X with coordinate ring H<sup>X</sup> := C[x1, . . . , xn]/I, which determines the chiral ring R of field theory. We can characterize U(1)<sup>R</sup> like symmetries by requiring the top form Ω [3](#page-4-0) on X having charge two. In the large N limit, the central charge can be computed from the Hilbert series of X [\[9](#page-20-4)[–11](#page-20-5)].

We would like to determine whether the chiral ring (R, ζ) of above field theory model is stable or not. Assuming our conjecture relating stability of chiral ring and SCFT, the stability of the chiral ring of these models has the following geometric consequence: If the chiral ring is stable, then according to AdS/CFT dictionary [\[12](#page-20-6)[–14](#page-20-7)], in the large N limit the IR SCFT is dual to type IIB string theory on AdS<sup>5</sup> × L<sup>5</sup> [\[8](#page-20-3), [15](#page-20-8)], where L<sup>5</sup> is a five manifold, defined as the link of a 3d singularity X, which carries a Sasaki-Einstein (SE) metric. The U(1)<sup>R</sup> symmetry ζ is identified with the Reeb vector field on L5. In other words, the stability of the chiral ring is equivalent to the existence of Sasaki-Einstein metric on L5, or equivalently the existence of a Ricci-flat conic metric on X.

The existence of Sasaki-Einstein metrics has been studied extensively recently in mathematics literature. Briefly, in the setting of Fano K¨ahler manifolds, the Yau-Tian-Donaldson conjecture predicted that the existence of K¨ahler-Einstein metrics with positive scalar curvature is equivalent to the algebro-geometric notion of K-stability [\[16\]](#page-20-9) which is an improvement of the original conjecture of Yau [\[17\]](#page-20-10). This conjecture was recently proved by Chen-Donaldson-Sun [\[18](#page-20-11)[–20](#page-20-12)]. In our more general context, a notion of K-stability and it's implications for the existence of Sasaki-Einstein metrics was studied by the first author and Sz´ekelyhidi in [\[21,](#page-20-13) [22](#page-20-14)]. The notion of K-stability involves constructions of so called test configurations X and the criteria for determining whether X destabilizes X is determined by the sign of the so-called Donaldson-Futaki invariant. One of major point of this paper is to provide an interpretation of the Donaldson-Futaki invariant as a version of generalized a maximization:

Theroem 1.1 The K-stability of the affine variety X is equivalent to the stability of the chiral ring of the corresponding field theory.

The paper is organized as follows: section two reviews some basic facts about N = 1 chiral ring; section three studies theory engineered using D3 brane probing certain three dimensional singularity X, and K-stability of X is interpreted as the generalized a maximization procedure introduced above; section four discusses some physical consequences from K stability; finally, a conclusion is given in section five.

<span id="page-4-0"></span><sup>3</sup>The existence of such form puts restriction on the singularity type.

## <span id="page-5-0"></span>2 Generality of chiral ring

Consider a four dimensional N = 1 supersymmetric field theories. A chiral operator O<sup>i</sup> is defined as an operator annihilated by supercharges Q¯ α˙ , and is defined modulo cohomology of Q¯ α˙ : O<sup>i</sup> ∼ O<sup>i</sup> + [Q¯ α˙ , χ] [\[1\]](#page-19-0). Chiral operators have some interesting properties:

- The sum of two chiral operators is still a chiral operator, and the product of two chiral operators is still a chiral operator.
- There is an identity operator.
- The expectation value of a product of chiral operators are independent of their positions, and they have the simple OPE structure OiO<sup>j</sup> = PC k ijO<sup>k</sup> with C k ij constant.

These properties imply that the chiral operators form a commutative ring with an identity. To solve a N = 1 theory, one would like to determine the full set of chiral operators. That is, one would like to find the generators and relations determining the chiral ring. For example, for SU(N) gauge theory with an adjoint matter field Φ, the generators of single trace chiral operators are: Tr(Φ<sup>k</sup> ), Tr(WαΦ k ), and Tr(WαWαΦ k ), the full chiral ring relations are determined in [\[1](#page-19-0)]. The chiral ring relations usually are much harder to determine. Typically, we have the following classical chiral ring relations;

- Chiral ring relations come from the finite size of matrices, and we have Caley-Hamilton equation for a matrix. For example, for a chiral field in the adjoint representation of gauge group SU(N), the chiral operators Tr(φ i ), i > N can be expressed in terms of Tr(φ j ) with j ≤ N.
- Chiral ring relations come from the constraints of the superpotential. For example, consider N = 4 SU(N) gauge theory: this theory has three chiral fields X, Y, Z, and a superpotential W = TrXY Z − TrXZY . The F-term equations from the superpotential are

$$[X,Y] = [Y,Z] = [Z,X] = 0,$$
 (2.1)

and so the matrices X, Y, Z commute, which lead to chiral ring relations of the type Tr(XY Z) = Tr(XZY ) and so on.

These classical chiral ring relations can be modified by quantum effects such as instantons, Konishi anomalies and strongly coupled dynamics, and we have the quantum chiral ring. The determination of the generators of chiral ring and the quantum chiral ring relation is a central task in the study of supersymmetric gauge theory. Let's assume that the generators of the chiral ring are x1, x2, . . . xs, and the chiral ring relations are generated by polynomial relations, then the quantum chiral ring is isomorphic to

$$\mathbb{C}[x_1, x_2, \dots, x_s]/I, \tag{2.2}$$

where C[x1, x2, . . . , xs] is ring of polynomials with complex coefficients, and I is the ideal generated by the chiral ring relations. In general, the parameters of our theory such as the dynamically generated scale Λ and masses m<sup>i</sup> should be included into the generators and relations of chiral ring. From now on, by the chiral ring we will always mean the quantum chiral ring.

Example: Consider N = 1 SU(N) SQCD with N<sup>f</sup> = N quarks Q<sup>i</sup> , Q˜ <sup>j</sup> , the space of chiral operators are

$$M_{ij} = Q_i \tilde{Q}_j,$$

$$B = \epsilon_{\alpha_1 \alpha_2 \dots \alpha_N} Q_1^{\alpha_1} \dots Q_N^{\alpha_N},$$

$$\tilde{B} = \epsilon_{\alpha_1 \alpha_2 \dots \alpha_N} \tilde{Q}_1^{\alpha_1} \dots \tilde{Q}_N^{\alpha_N}.$$
(2.3)

The classical chiral ring relation is Det(M)− BB˜ = 0, but quantum mechanically, the ring relation is changed to

$$f = \operatorname{Det}(M) - B\tilde{B} - \Lambda^{2N_c} = 0. \tag{2.4}$$

Here Λ is the dynamical scale of the theory. The chiral ring is then C[M, B, B, ˜ Λ]/f [\[6\]](#page-20-1).

We are interested in the chiral ring of a SCFT. The N = 1 SCFT has a distinguished U(1)<sup>R</sup> symmetry, and the scaling dimension of a chiral operator are related to its U(1)<sup>R</sup> charge by

$$D(\mathcal{O}) = \frac{3}{2}R(\mathcal{O}). \tag{2.5}$$

In general, it is not easy to determine the U(1)<sup>R</sup> symmetry of a SCFT. Intriligator and Wecht found a remarkable a-maximization procedure to determine the R-symmetry [\[4\]](#page-19-3). Namely, they predicted that the correct R-symmetry maximizes the central charge a.

One usually defines a SCFT as the IR limit of a UV quiver gauge theory, and the U(1)<sup>R</sup> symmetry of IR SCFT can be determined as follows: First, find all the anomaly free U(1) symmetries in the UV and define a trial R symmetry U(1)trial = P I sIF<sup>I</sup> . Second, compute the trial central charge using the formula

$$a_{trial}(s_I) = \frac{3}{32} (3\operatorname{Tr}(R_{trial}^3) - \operatorname{Tr}(R_{trial})). \tag{2.6}$$

The true U(1)<sup>R</sup> symmetry is found by maximizing the central charge and this will fix the coefficients s<sup>I</sup> . A crucial assumption of above procedure is that all the symmetries for the IR SCFT are manifest in the UV description! However, this is often not the case. For example, two possible scenarios are

- The violation of unitarity bound: if a gauge invariant operator O violates the unitarity bound after doing a-maximization, it is argued that this field becomes free [\[5](#page-20-0)], and that there is an accidental U(1) symmetry acting on this operator O only.
- Even if there is no violation of unitarity bound, accidental symmetry is still possible as a result of some unknown dynamical effect.

Example: Let's illustrate the above point by an example. Consider N = 1 SU(Nc) SQCD with N<sup>f</sup> fundamental flavors. There is an unique U(1)<sup>R</sup> type symmetry such that the quarks Q and antiquarks Q˜ have the following charges

$$R_Q = R_{\tilde{Q}} = \frac{N_f - N_c}{N_f}. (2.7)$$

We require  $N_f > N_c$  so that the R charge is positive. The mesons has R charge  $R(M) = 2\frac{N_f - N_c}{N_f}$ , and baryons an anti-baryons have R charge  $R(B) = R(\tilde{B}) = \frac{N_c(N_f - N_c)}{N_f}$ . So using this candidate  $U(1)_R$  symmetry for the IR SCFT, we have  $\Delta(M) = \frac{3}{2}R(M) < 1$  if  $N_c < N_f < \frac{3}{2}N_c$  and it is argued that these mesons become free in the IR [5]. The baryons do not violate the unitarity bound, however, it becomes free if  $N_f = N_c + 1$  as we can see it from Seiberg dual description [23].

In fact, the appearance of accidental symmetry implies that the chiral ring of the IR SCFT is different from the UV theory, which means that the chiral ring of UV theory is not stable. Since it is difficult to detect the appearance of accidental symmetry, it is also difficult to tell whether the UV chiral ring is stable or not. In the next section, we will consider a class of  $\mathcal{N}=1$  models where we will relate the stability of chiral ring to a problem in geometry.

#### <span id="page-7-1"></span><span id="page-7-0"></span>3 K-stability and stability of chiral ring

#### 3.1 The chiral ring, Hilbert series and the central charge a

Consider a  $\mathcal{N}=1$  theory on world volume of N D3 branes probing a graded three dimensional normal, Kawamata log-terminal (klt), Gorenstein singularity X, (see figure. 1). The 3d singularity is defined by an affine ring

$$\mathcal{H}_X = \mathbb{C}[x_1, x_2, \dots, x_r]/I,\tag{3.1}$$

here  $\mathbb{C}[x_1, x_2, \dots, x_r]$  is the polynomial ring and I is an ideal. Let's explain the meaning for various terms characterizing our singularity: **normal** means that the codimension of the singular locus P of X is no less than two; **graded** means that there is at least one  $C^*$  action on X; **Gorenstein** means that the canonical sheaf  $K_X$  is a line bundle and one has a non-vanishing top form  $\Omega$  on X/P; **Kawamata log-terminal** can be characterized that the volume form  $\Omega \wedge \overline{\Omega}$  has finite mass near the singularities of X (see [22]).

We have the following map between the properties of the ring X and field theory,

- The automorphism group G of X gives the (complexified) anomaly free symmetries of the field theory, and the possible  $U(1)_R$  symmetry  $\zeta$  is a subgroup of G.
- The coordinate ring of the vacua moduli space is described as the coordinate ring of the variety  $M_N = X^N/S^N$ . In the large N limit, the single trace operators parameterizing  $M_{\infty}$  can be identified as the ring elements of X 4: namely the holomorphic functions on X give the chiral scalar operators of the field theory in the large N limit. So X essentially determines the nontrivial part of the chiral ring  $^5$ .

<span id="page-7-2"></span> $<sup>^4</sup>$ Notice that in the large N limit the ring structure of X is not the chiral ring structure of the field theory. In the large N limit, the chiral ring structure is trivial, namely the product of two single trace operator defines the multiple trace operators.

<span id="page-7-3"></span><sup>&</sup>lt;sup>5</sup>There are other types of scalar chiral operators which do not get expectation value, and also chiral Barvonic operators. These operators seem not affect the stability issue of our model.

• X has a canonical (3,0) form  $\Omega$ , and it has charge 2 under the **possible**  $U(1)_R$  symmetry  $\zeta$ :

$$[\Omega] = 2, \tag{3.2}$$

(in fact, this condition is equivalent X being klt). We also require that the  $U(1)_R$  charge of the coordinates  $x_i$  is positive.

![](_page_8_Picture_3.jpeg)

Figure 1. One can engineer four dimensional  $\mathcal{N}=1$  theories using D3 brane probing three dimensional klt Gorenstein singularity X. For the singularity X, one can define a link L which is a five dimensional Sasakian manifold.

<span id="page-8-0"></span>Consider a possible  $U(1)_R$  symmetry  $\zeta$  which is realized as an automorphism of X. The trial central charge  $a(\zeta)$  (of order  $N^2$ ) of the field theory can be computed from the Hilbert series of the ring X [9–11, 24]. The Hilbert series of X with respect to  $\zeta$  is defined by

$$Hilb(X,\zeta,t) = \sum (dim H_{\alpha})t^{\alpha};$$
 (3.3)

Here  $H_{\alpha}$  is the subspace of ring  $\mathcal{H}_X$  with charge  $\alpha$  under the action  $\zeta$ . The Hilbert series has a Laurent series expansion around t=1 obtained by setting  $t=e^{-s}$  and expanding

$$Hilb(X, \zeta, e^{-s}) = \frac{a_0(\zeta)}{s^3} + \frac{a_1(\zeta)}{s^2} + \dots$$
 (3.4)

The coefficients  $(a_0(\zeta), a_1(\zeta))$  have following properties:

•  $a_0$  is proportional to the volume of the link  $L_5$  of the singularity, and the trial central charge  $a(\zeta)$  (order  $N^2$  term) is related to  $a_0$  as

<span id="page-8-1"></span>
$$a(\zeta) = \frac{27N^2}{32} \frac{1}{a_0(\zeta)}. (3.5)$$

- $a_0 = a_1$  which is due to the condition that  $\Omega$  has charge 2.
- $a_0$  is convex function of the symmetry generators [11].

For the singularity X, one can define a 5 dimensional link  $L_5$  with Sasakian structure [25]. If there is a Sasaki-Einstein metric on the link  $L_5$ , one can find the true  $U(1)_R$  symmetry by minimizing  $a_0$ , and the field theory central charge is given by the formula (3.5). In the large N limit, the SCFT on D3 branes is dual to Type IIB string theory on the following geometry

$$AdS_5 \times L_5. \tag{3.6}$$

The existence of the SE metric on  $L_5$  is also equivalent to the existence of a Ricci-flat conic metric on X.

**Example:** Consider the conifold singularity defined by the principal ideal  $f(z) = z_0^2 + z_1^2 + z_2^2 + z_3^2 = 0$ , and it is known that the link  $L_5$  is the manifold  $T^{1,1}$  and has a Sasaki-Einstein metric. There is a  $C^*$  action  $\zeta$  on this singularity  $f(\lambda^{q_i}z_i) = \lambda f(z_i)$  with weights  $(\frac{1}{2}, \frac{1}{2}, \frac{1}{2}, \frac{1}{2})$ . The canonical three form is  $\Omega = \frac{dz_0 \wedge dz_1 \wedge dz_2 \wedge dz_3}{dF}$ .  $\Omega$  has charge 1 under the symmetry  $\zeta$ , so the possible  $U(1)_R$  symmetry is actually  $\zeta' = 2\zeta$  in order to ensure  $\Omega$  has charge two. The Hilbert series of X with respect to symmetry generator  $\zeta'$  is

$$Hilb(t) = \frac{(1-t^2)}{(1-t)^4}|_{t=e^{-s}} = \frac{2}{s^3} + \frac{2}{s^2} + \dots$$
 (3.7)

Using formula 3.5, We find that the central charge is equal to  $a = \frac{27}{64}N^2$  which agrees with the result derived from field theory [8].

#### <span id="page-9-0"></span>3.2 K Stability and generalized a-maximization

Now thel question is whether the link  $L_5$  has Sasaki-Einstein metric. This question is reduced to studying the K-stability of the ring X [21, 22]. On the other hand, X essentially determines the chiral ring of the field theory, and if the chiral ring of the field theory is stable, i.e. it is a chiral ring of a SCFT, the field theory is dual to type IIB string theory on the background  $AdS_5 \times L_5$ , where  $L_5$  has a Sasaki-Einstein metric. From this AdS/CFT correspondence, one can see that K-stability should be equivalent to the stability of the chiral ring of field theory defined in introduction. In this subsection, we will discuss two crucial ingredients of K-stability; test configuration and the Donaldson-Futaki invariant. We will also give a physical interpretation of these two elements and show that K-stability is equivalent to the stability of the chiral ring.

#### <span id="page-9-1"></span>3.2.1 Test configurations

Let's first describe the definition of a test configuration arising in K stability, which actually motivates our definition of test chiral ring in the introduction. In the K-stability context, one constructs a test configuration by constructing a flat family  $\pi: \mathcal{X} \to \mathbb{C}$  (for a simple illustration of flat and non-flat family, see figure. 2.). This flat family is generated by a one dimensional symmetry generator  $\eta$ , and for  $t \neq 0$ , the ring  $H_{X_t}$  corresponding to the fiber  $X_t = \pi^{-1}(t)$  is isomorphic to the original ring  $\mathcal{H}_X$ . At t = 0, the ring degenerates into a different ring which we call  $H_{X_0}$ , and it is also called central fibre.

The flat limit is a quite common concept in algebraic geometry, but its definition is quite involved and we do not want to give a detailed introduction here. For the interested

reader, see section 6 of [26]. Here, we just want to point out several important features of the flat family constructed above.

- (a) The Hilbert series is not changed if we use the same symmetry generator for the new ring  $\mathcal{H}_{X_0}$ . In particular,  $X_0$  has the same dimension as X.
- (b) The maximal torus in the automorphism group of the central fibre  $X_0$  has one more dimensional symmetry generated by  $\eta$ , unless  $X_0 \cong X$ .

We require that the degeneration is normal (which implies that the codimension of the singular locus is not less than two). The new singularity  $X_0$  is still Gorenstein and klt and, in the non-trivial case, possesses an extra one-dimensional symmetry.

![](_page_10_Picture_4.jpeg)

**Figure 2**. Left: A flat family of rings. At  $t \neq 0$ , there are two points and the configuration degenerates into one point at t = 0, which is the central fibre of this flat limit. Right: A non-flat family of rings. At  $t \neq 0$ , the ring is zero dimensional, but at t = 0, the ring is one dimensional.

<span id="page-10-1"></span>**Example**: Consider the ring X defined by the ideal  $x^2 + y^2 + z^2 + w^k = 0$ , and consider a  $\mathbb{C}^*$  action  $\eta$  which acts only on coordinate w with the action  $\eta(w) = tw$ . We then get a family of rings parametrized by the coordinate t:

$$x^2 + y^2 + z^2 + t^k w^k = 0. (3.8)$$

The flat limit of this family over t = 0 is found (in this case) by keeping the terms with lowest order. The central fiber of this test configuration is then cut out by the equation

$$x^2 + y^2 + z^2 = 0 (3.9)$$

Notice that  $l\eta$  with l>0 gives the same degeneration limit  $X_0$ . On the other hand  $l\eta$  with l<0 gives a different degeneration limit—we get the ring generated by the ideal  $w^k=0$ , which is not normal!

## <span id="page-10-0"></span>3.2.2 Futaki invariant and generalized a-maximization

Now let's start with a ring X with symmetry  $\zeta$  and we also choose the generators  $t_i, i = 1, \ldots, n$  for the Lie algebra  $\mathfrak{t}$  of the maximal torus in the automorphism group G of X. Let us write  $\zeta = \sum_{i=1}^{n} \zeta_i t_i$ , and we may as well assume that  $\zeta$  minimizes the volume over all the possible  $U(1)_R$  symmetries parametrized by  $\mathfrak{t}$ . Consider a test configuration  $\mathcal{X}$  generated

by a symmetry generator  $\eta$  and let  $X_0$  denote the central fibre. We would like to determine whether or not  $X_0$  destabilizes X. The crucial ingredient is the Donaldson-Futaki invariant defined in [16].

The ring  $(X_0, \zeta, \eta)$  is still Gorenstein and klt, and has a at least two dimensional symmetry group generated by  $\zeta$  and  $\eta$ . There is only one dimensional possible  $U(1)_R$  symmetry as we need to impose following two conditions

- (a) The charge on the coordinates  $x_i$  is positive
- (b) The (3,0) form has charge 2.

The second condition can be fixed by computing the Hilbert series of  $X_0$  with respect to symmetry generator and imposing the condition  $a_0 = a_1$ . This one dimensional candidate  $U(1)_R$  symmetry can be parameterized as

$$\zeta(\epsilon) = \zeta + \epsilon(\eta - a\zeta). \tag{3.10}$$

Notice that we require  $\epsilon > 0$  so that the central fibre is the same as the original one if we use the symmetry  $\epsilon(\eta - a\zeta)$  to generate the test configuration. Substitute the above parameterization into the equation  $a_0 = a_1$  and expand it to first order in  $\epsilon$ , we have

$$a_{0}(\zeta + \epsilon(\eta - a\zeta)) = a_{1}(\zeta + \epsilon(\eta - a\zeta)) \rightarrow a_{0}(\zeta) + \epsilon(\eta - a\zeta) \cdot a_{0}' = a_{1}(\zeta) + \epsilon(\eta - a\zeta) \cdot a_{1}'. \quad (3.11)$$

Here  $a_0'$  and  $a_1'$  are the vectors defined by the derivative  $\frac{da_i(\vec{x})}{d\vec{x}}|_{\vec{x}=\zeta}$ , and  $\vec{x}=\sum_{i=1}^n s_i t_i + b\eta$ . Using the result  $a_0(\zeta)=a_1(\zeta)$ , we have

<span id="page-11-0"></span>
$$a = \frac{\eta \cdot (a'_0 - a'_1)}{\zeta \cdot (a'_0 - a'_1)} = \frac{\eta \cdot (a'_1 - a'_0)}{a_0} = \frac{1}{a_0(\zeta)} \left( \frac{da_1(\zeta + \epsilon \eta)}{d\epsilon} - \frac{da_0(\zeta + \epsilon \eta)}{d\epsilon} \right) |_{\epsilon = 0}.$$
 (3.12)

We also use the fact  $\zeta \cdot a_0' = 3a_0(\zeta)$ ,  $\zeta \cdot a_1' = 2a_1(\zeta) = 2a_0(\zeta)$ . Now the Futaki invariant is defined to be

$$F(X,\zeta,\eta) = D_{\epsilon}a_0(\zeta(\epsilon))|_{\epsilon=0}. \tag{3.13}$$

This definition is not of the form of the original Futaki invariant defined in [16], however, we will now show that our definition is equivalent to the original one (see also [22] for more discussion). We have

$$F(X,\zeta,\eta) = D_{\epsilon}a_{0}(\zeta + \epsilon(\eta - a\zeta)) = (\eta - a\zeta) \cdot a'_{0}$$

$$= D_{\epsilon}a_{0}(\zeta + \epsilon\eta) - \frac{\eta \cdot (a'_{0} - a'_{1})}{a_{0}} D_{\epsilon}a_{0}(\zeta + \epsilon\zeta)$$

$$= D_{\epsilon}a_{0}(\zeta + \epsilon\eta) + 3a_{0}(\zeta) \frac{\eta \cdot (a'_{0} - a'_{1})}{a_{0}}$$

$$= D_{\epsilon}a_{0}(\zeta + \epsilon\eta) + 3a_{0}(\zeta) D_{\epsilon} \frac{a_{1}(\zeta + \epsilon\eta)}{a_{0}(\zeta + \epsilon\eta)}.$$
(3.14)

We use the definition from first line to second line, and from second line to third line we use the fact  $D_{\epsilon}a_0(\zeta + \epsilon \zeta) = -3a_0(\zeta)$  (which can be found using the definition of Hilbert series). The formula in the last line is precisely the Futaki invariant defined in [22]. Having defined the Futaki invariant, we can now state the definition of K-stability.

**Theroem 3.1** A polarized ring  $(X,\zeta)$  is stable if for any non-trivial test configuration generated by the symmetry  $\eta$ , the Futaki invariant satisfies

$$F(X,\zeta,\eta) > 0. \tag{3.15}$$

And for the trivial test configuration, namely the central fibre  $X_0$  is the same as X, the Futaki invariant satisfies

$$F(X,\zeta,\eta) \ge 0. \tag{3.16}$$

We now provide a physical interpretation of the Futaki invariant F. Since  $a_0$  is inverse proportional to the central charge of the coordinate ring of the central fiber, the Futaki invariant is directly related to the maximization of the central charge. The shape of the function  $a_0$  with respect to  $\epsilon$  is drawn in figure. 3. F < 0 implies that  $a_0(\epsilon)$  is minimized at  $\epsilon > 0$ , and the new ring gives larger central charge a! When F = 0 and  $X_0$  is different from X, the two ring gives the same central charge a, but the central fiber  $X_0$  has a strictly larger symmetry group which then destabilizes X. When F > 0, the new ring gives less central charge over the allowed space of symmetries ( $\epsilon > 0$ ). In summation, Futaki invariant is actually implying generalized a-maximization. Namely, a test configuration  $X_0$  destabilizes X if it gives no less central charge!

![](_page_12_Figure_5.jpeg)

<span id="page-12-0"></span>Figure 3. Three situations for Futaki invariant. F > 0:  $a_0(\epsilon) > a(0)$  for  $\epsilon > 0$ ; F = 0: the minima of  $a_0$  is achieved at  $\epsilon = 0$ ; F < 0: the minima of  $a_0$  is achieved fro  $\epsilon > 0$ . Notice that we only need to look at  $a_0$  for  $\epsilon > 0$ .

**Example**: Consider the ring X which is generated by the ideal  $x^2 + y^2 + z^2 + w^k = 0$ , this ring has a symmetry  $\zeta$  with charge  $(\frac{2k}{k+2}, \frac{2k}{k+2}, \frac{2k}{k+2}, \frac{4}{k+2})$  on coordinates (x, y, z, w). This symmetry is chosen such that the (3,0) form  $\Omega = \frac{dx \wedge dy \wedge dz \wedge dw}{df}$  has charge two. The Hilbert series for  $\zeta$  is

$$Hilb(X,\zeta,t) = \frac{1 - t^{\frac{4k}{k+2}}}{\left(1 - t^{\frac{4}{k+2}}\right)\left(1 - t^{\frac{2k}{k+2}}\right)^3}.$$
 (3.17)

Expand around t = 1, we find  $a_0(\zeta) = a_1(\zeta) = \frac{(2+k)^3}{8k^2}$ . Now consider the test configuration generated by the symmetry  $\eta$  with charges (0,0,0,1). In this case, the central fibre  $X_0$  is

generated by the ideal  $x^2 + y^2 + z^2 = 0$ . Using formula (3.12), the one parameter possible  $U(1)_R$  symmetry is

$$\zeta(\epsilon) = \zeta + \epsilon(\eta - \frac{1}{2}\zeta). \tag{3.18}$$

The Hilbert series with respect to above symmetry is

$$Hilb(X_0, \zeta(\epsilon), t) = \frac{1 - t^{(1 - \frac{\epsilon}{2}) \frac{4k}{k+2}}}{(1 - t^{(1 - \frac{\epsilon}{2}) \frac{2k}{k+2}})^3 (1 - t^{(1 - \frac{\epsilon}{2}) \frac{4}{k+2} + \epsilon)})}.$$
 (3.19)

Substituting t = exp(-s) and expand the Hilbert series around s = 0, we get

$$a_0(\zeta(\epsilon)) = a_1(\zeta(\epsilon)) = \frac{2(k+2)^3}{(\epsilon-2)^2 k^2 (\epsilon k + 4)}.$$
 (3.20)

The Futaki invariant is computed as

$$F = D_{\epsilon} a_0(\zeta(\epsilon))|_{\epsilon=0} = \frac{(4-k)(k+2)^3}{32k^2}.$$
 (3.21)

So  $F \leq 0$  for  $k \geq 4$ . Since  $X_0$  is clearly not isomorphic to X, we conclude that  $X_0$  destabilizes X for  $k \geq 4$ . A physical interpretation of this result will be given in the next section.

#### <span id="page-13-0"></span>3.2.3 Some discussions

Checking K-stability involves two steps. First, finding a test configuration and then computing the Futaki invariant. While the computation of Futaki invariant is straightforward, the set of possible test configurations is in principle infinite. Thus, in order to check K-stability one needs to reducing the sets of possible test configurations. There are several simplifications we can make

- The first simplification has already been used, namely we require that the central fibre to be normal, Gorenstein and klt. This is simply due to the reason that the central fibre should describe the chiral ring of a  $\mathcal{N}=1$  field theory.
- Assume that the symmetry group of the ring X is G, then one only need to consider the flat families generated by a symmetry which commutes with G [22, 27]. This fact is quite useful for singularities with many symmetries. In particular, if the variety has three dimensional symmetries (or in other words, X is toric), then there are no non-trivial test configurations, and hence checking stability reduces to volume minimization (or a-maximization).

### <span id="page-13-2"></span><span id="page-13-1"></span>4 Some physical consequences

#### 4.1 a-maximization

Let's assume that the ring X is stable and has more than one dimension worth of possible  $U(1)_R$  symmetry. The determination of  $U(1)_R$  symmetry is solved by a-maximization

[\[4\]](#page-19-3) or equivalently volume minimization [\[10](#page-20-16), [11\]](#page-20-5). We now show that a-maximization can be explained using K-stability. Consider a test configuration generated by the symmetry vector η, and the central fibre X<sup>0</sup> is the same as X. The Futaki invariant is

$$F = D_{\zeta} a_0(\zeta + \epsilon \eta)|_{\epsilon=0} = \eta \cdot a'_0(\zeta), \tag{4.1}$$

If F(X, ζ, η) > 0, the test configuration (X0, ζ, η) does not destabilize X. But, since η preserves X, we can use the symmetry generator −η to generate a test configuration with the same central fibre X, and the Futaki invariant now is F(X, ζ, −η) = −F(X, ζ, η) < 0 which will make the ring unstable. So K-stability implies that the symmetry generator has to satisfy

$$a_0'(\zeta) = 0. (4.2)$$

Notice that since a<sup>0</sup> is a convex function, the solution of above equation is the minimum, and therefore the central charge a is maximized.

#### <span id="page-14-0"></span>4.2 Unitarity bound

One can always generate a test chiral ring by using a symmetry acting on a single coordinate x only. The central fibre X<sup>0</sup> is a new ring with x free [6](#page-14-2) . The Futaki invariant is computed in [\[21](#page-20-13)], and the answer is

$$F \propto (dim(x) - 1),\tag{4.3}$$

here we ignore a positive constant, and dim(x) is the scaling dimension of the chiral scalar operator x. X is not destabilized by this particular test configuration if

$$dim(x) > 1. (4.4)$$

<span id="page-14-1"></span>This is nothing but the unitarity bound on scalar operator represented by x.

#### 4.3 Singularity with more than one dimensional symmetries

Consider a toric Gorenstein singularity, and the rank of symmetry group is 3. As we discussed above, there is no non-trivial test configuration, and so toric singularity is stable provided we choose the U(1)<sup>R</sup> symmetry which minimizes the volume. On the other hand, the existence of Sasaki-Einstein metrics on the link of a toric singularity was established using analytic methods in [\[28\]](#page-21-4). For the ring X with two dimensional symmetries, one only needs to check finite number of test configurations, see [\[22](#page-20-14)].

Example: Consider the ring defined by the ideal x <sup>2</sup> + y <sup>2</sup> + z <sup>p</sup> + w <sup>q</sup> = 0. This ring has a two dimensional symmetry group. One can characterize all the test chiral rings, and the ring is proven to be stable if (p, q) satisfies the following condition [\[22](#page-20-14)]:

$$p < 2q \text{ and } q < 2p. \tag{4.5}$$

Notice that this is just the requirement of the unitarity bound on the operators represented by z and w. However, as we will see later, the unitarity bound is not the only obstruction which can appear, even in the case of hypersurface singularities.

<span id="page-14-2"></span><sup>6</sup>Mathematically such test configuration is generated by the so-called Rees algebra.

#### <span id="page-15-0"></span>4.4 Hypersurface singularity

Consider an isolated three-fold hypersurface singularity  $f:(C^4,0)\to(C,0)$  with a  $C^*$  action  $\vec{\zeta}$ :

$$f(\lambda^{w_i}q_i) = \lambda f(z_i). \tag{4.6}$$

Here all the charges  $w_i$  are positive. The canonical three-form is

$$\Omega = \frac{dz_0 \wedge dz_1 \wedge dz_2 \wedge dz_3}{dF}.$$
(4.7)

This form has charge  $\sum w_i - 1$ , and the candidate  $U(1)_R$  symmetry is found by requiring  $\Omega$  to have charge two:

$$\left(\sum w_i - 1\right)\delta = 2 \to \delta = \frac{2}{\sum w_i - 1},\tag{4.8}$$

and the candidate  $U(1)_R$  symmetry is  $\zeta' = \delta \zeta$ . To make the coordinate  $z_i$  have positive r charge, we require  $\sum w_i - 1 > 0$ , which implies that the singularity is a rational Gorenstein (and hence klt) singularity. Such rational hypersurface singularities have been classified by Yau and Yu [29].

The Hilbert series of a hypersurface singularity is easy to compute. It takes the following form

$$Hilb(f, t, \zeta') = \frac{1 - t^{\delta}}{(1 - t^{w_0 \delta})(1 - t^{w_1 \delta})(1 - t^{w_2 \delta})(1 - t^{w_3 \delta})}.$$
(4.9)

Now let's consider a test configuration which is derived by using a one parameter transformation  $\eta$ . For simplicity, let's assume that the action  $\vec{\eta}$  is diagonal on the coordinates with charges  $(v_1, v_2, v_3, v_4)$ . In the flat limit, we get a new polynomial  $f_0$  which does not necessarily define an isolated singularity.  $f_0$  has two dimensional symmetries generated by  $(\zeta', \eta)$ , however, there is only a one dimensional symmetries which could be the possible  $U(1)_R$  symmetry. The one parameter symmetry group can be parameterized as

<span id="page-15-2"></span>
$$\eta(\epsilon) = \zeta' + \epsilon(\eta - a\zeta'), \tag{4.10}$$

and a can be computed using the formula 3.12. The Futaki invariant can be computed using formula 3, and we have

$$F(f,\zeta',\eta) = D_{\epsilon}a_0(\zeta(\epsilon))|_{\epsilon=0} = -[(v_4w_1w_2w_3(w_1+w_2+w_3-2w_4-1)+v_3w_1w_2w_4(w_1+w_2+w_4-2w_3-1)+v_2w_1w_3w_4(w_1+w_3+w_4-2w_2-1)+v_1w_2w_3w_4(w_2+w_3+w_4-2w_1-1).$$
(4.11)

In the following, we are going to use this formula to test whether a hypersurface singularity is stable or not.

#### <span id="page-15-1"></span>4.4.1 Irrelevance of superpotential term

Recall that we have already studied the singularity

$$f = z_0^2 + z_1^2 + z_2^2 + z_3^{2k}, (4.12)$$

from K-stability perspective, and we showed that this ring is unstable for  $k \geq 2$ . The destabilizing configuration has the central fibre  $X_0 = \{z_0^2 + z_1^2 + z_2^2 = 0\}$ ; see section 3.2.2.

Let's interpret this result from field theory point of view. The quiver gauge theory description is found in [30]; see figure 4 below. We have the following superpotential term:

![](_page_16_Picture_2.jpeg)

**Figure 4.** Quiver gauge theory description for D3 brane probing the singularity defined by  $z_0^2 + z_1^2 + z_2^2 + z_3^{2k} = 0$ . The superpotential is described in (4.13).

<span id="page-16-1"></span><span id="page-16-0"></span>
$$W = \text{Tr}(\phi_1(A_1B_1 + A_2B_2)) - \text{Tr}(\phi_2(B_1A_1 + B_2A_2)) - 2\frac{\text{Tr}\phi_1^{k+1}}{k+1} + 2\frac{\text{Tr}\phi_2^{k+1}}{k+1}.$$
 (4.13)

The  $U(1)_R$  charge is fixed such that the NSVZ  $\beta$  function is zero, and each term in superpotential W has charge two:

$$\frac{1}{2}[(R(A_1) - 1) + (R(A_2) - 1) + (R(B_1) - 1) + (R(B_2) - 1)] + (R(\phi_1) - 1) + 1 = 0,$$

$$\frac{1}{2}[(R(A_1) - 1) + (R(A_2) - 1) + (R(B_1) - 1) + (R(B_2) - 1)] + (R(\phi_2) - 1) + 1 = 0,$$

$$R(A_1) + R(B_1) + R(\phi_1) = 2, \quad R(A_2) + R(B_2) + R(\phi_1) = 2,$$

$$R(A_1) + R(B_1) + R(\phi_2) = 2, \quad R(A_2) + R(B_2) + R(\phi_2) = 2,$$

$$R(\phi_1) = R(\phi_2) = \frac{2}{k+1}.$$
(4.14)

We can use symmetry or a maximization to find the following R charges:  $R(A_1) = R(A_2) = R(B_1) = R(B_2) = \frac{k}{k+1}$ ,  $R(\phi_1) = R(\phi_2) = \frac{2}{k+1}$ . The F-term relations from the superpotential are:

$$\frac{\partial W}{\partial A_1} = 0 : B_1 \phi_1 - \phi_2 B_1 = 0, 
\frac{\partial W}{\partial B_1} = 0 : \phi_1 A_1 - A_1 \phi_2 = 0, 
\frac{\partial W}{\partial A_2} = 0 : B_2 \phi_1 - \phi_2 B_2 = 0, 
\frac{\partial W}{\partial B_2} = 0 : \phi_1 A_2 - A_2 \phi_2 = 0, 
\frac{\partial W}{\partial \phi_1} = 0 : A_1 B_1 + A_2 B_2 - 2 \phi_1^k = 0, 
\frac{\partial W}{\partial \phi_2} = 0 : B_1 A_1 + B_2 A_2 - 2 \phi_2^k = 0.$$
(4.15)

– 16 –

The scalar chiral ring of this theory (which is related to the holomorphic functions on X) is generated by the loops in the quiver subject to the above relations. The single trace scalar chiral operators are generated by the simple loops, such as  $\text{Tr}(A_iB_j)$ , and one can order them by their  $U(1)_R$  charge.

Consider the singularity X defined by the equation  $f=z_0^2+z_1^2+z_2^2+z_3^{2k}$ , the unique candidate  $U(1)_R$  symmetry  $\zeta'$  has charge  $(\frac{2k}{k+1},\frac{2k}{k+1},\frac{2k}{k+1},\frac{2}{k+1})$  which is identified as the field theory  $U(1)_R$  charge. We can make a holomorphic change of coordinates to write f as  $f=U^2+V^2+(-W+Z^k)(W+Z^k)$ . The holomorphic functions on X can be identified with the field theory chiral operators as follows:

$$\operatorname{Tr} A_1 B_2 = U,$$
  $\operatorname{Tr} A_2 B_1 = V,$   $\operatorname{Tr} A_1 B_1 = -W + Z^k,$   $\operatorname{Tr} A_2 B_2 = W + Z^k.$  (4.16)

It can be checked that the full set of scalar chiral operators of the field theory which can get expectation value is captured by the ring X.

The properties of the IR SCFT can be derived as follows: The quiver without the superpotential term  $\text{Tr}(\phi_1^{k+1})$  and  $\text{Tr}(\phi_2^{k+1})$  defines a four dimensional  $\mathcal{N}=2$  SCFT  $\mathcal{T}_0$ , and all of the elementary fields  $A_i, B_i, \phi_i$  are free with  $U(1)_R$  charge  $\frac{2}{3}$ . Our  $\mathcal{N}=1$  theory can be thought of as deforming  $\mathcal{N}=2$  SCFT  $\mathcal{T}_0$  by the superpotential terms involving the adjoint chiral superfields  $\phi_1$  and  $\phi_2$ . The scaling dimensions for the superpotential terms  $\mathcal{O}_1=\text{Tr}(\phi_1^{k+1})$  and  $\mathcal{O}_2=\text{Tr}(\phi_2^{k+1})$  are  $\Delta[\mathcal{O}_i]=k+1$ , and so they are irrelevant for k>2; the IR SCFT is just the original SCFT  $\mathcal{T}_0$ . For k=2, the superpotential term is marginally irrelevant [31], and the IR SCFT is also the original SCFT  $\mathcal{T}_0$ .

We have used K stability to check that the ring is unstable for  $k \geq 2$ , and the destabilizing configuration has a central fibre  $X_0: f = z_0^2 + z_1^2 + z_2^2$ . It is interesting to note that the IR SCFT (affine  $A_1, \mathcal{N} = 2$  SCFT) associated with the ring X is actually described by D3 branes probing the singularity  $X_0$ . This fact supports our claim that the central fibre  $X_0$  describes the possible chiral ring of the IR SCFT, and the result from K-stability is in agreement with field theory result!

#### <span id="page-17-0"></span>4.4.2 Further obstructions

The unstable example considered so far have been caused by the irrelevance of superpotential terms or the violation of the unitarity bound. We now give an example where the instability of the chiral ring is more subtle. Consider a singularity

$$f = z_0^2 + z_1^2 + z_2^p + z_2 z_3^q. (4.17)$$

The only possible  $U(1)_R$  symmetry has charge  $(\frac{pq}{p+q-1}, \frac{pq}{p+q-1}, \frac{2q}{p+q-1}, \frac{2(p-1)}{p+q-1})$ . The scaling dimensions of  $z_2$  and  $z_3$  are

$$[z_2] = \frac{3q}{2(p+q-1)}, \quad [z_3] = 3\frac{(p-1)}{p+q-1}.$$
 (4.18)

using the relation  $\Delta(\mathcal{O}) = \frac{3}{2}R(\mathcal{O})$ . The unitarity bound on the scalar operators implies that  $[z_2] > 1$  and  $[z_3] > 1$ , we find

<span id="page-18-1"></span>
$$p < 2q + 1 \& q < 2p - 2.$$
 (4.19)

The unitarity bound can also be found using the test configuration generated by the symmetry acting on coordinate  $z_2$  and  $z_3$  only.

Consider a test configuration generated by the symmetry  $\eta$  with charge (0, 0, 1, -1/q). We have the following family generated by  $\eta$ ;

$$z_0^2 + z_1^2 + t^p z_2^p + z_2 z_3^q = 0. (4.20)$$

The flat limit over t=0 is described by the equation  $z_0^2+z_1^2+z_2z_3^q=0$ . The Futaki invariant can be computed using the formula 4.11:

$$F(X_0,\zeta,\eta) = -\frac{(p+q-1)^2 (p^2 - 2pq + q - 1)}{2(p-1)^2 q^2}.$$
 (4.21)

So the original ring is stable if

<span id="page-18-2"></span>
$$q(2p-1) - (p^2 - 1) > 0 \to q > \frac{p^2 - 1}{2p - 1}.$$
 (4.22)

This bound is stronger than the unitarity bound (4.19) for certain range of the parameters. Let's set p = 6, the unitarity bound from (4.19) implies that

$$\frac{5}{2} < q < 10. ag{4.23}$$

The bound from (4.22) implies that

$$q > 34/11,$$
 (4.24)

which gives a stronger lower bound, i.e. q=3 satisfies the unitarity bound, but is unstable due to some other dynamical reason. The chiral ring of the IR SCFT is described by  $z_0^2 + z_1^2 + z_2 z_3^q = 0$  for q=3 which is also a three dimensional quotient singularity.

#### <span id="page-18-0"></span>5 Conclusion

We introduce a notion of stability for  $\mathcal{N}=1$  chiral rings, and conjecture that a chiral ring is the chiral ring of a SCFT if and only if it is stable. We test our stability notion for models engineered using D3 brane probing 3-fold singularity, and show that the notion of K-stability for the existence of Ricci-flat conic metric is equivalent to the field theory stability. This notion can be used to explain a-maximization, an operator becoming free if it violates unitarily bound, and the irrelevance of superpotential terms, etc. In general, our stability notion explains the consequences of accidental symmetries appearing in the study of quiver gauge theory: the chiral ring of the IR SCFT is different form that of UV theory if there are accidental symmetries. Accidental symmetries cause many problems in

studying supersymmetric field theory with four supercharges [\[32](#page-21-8), [33](#page-21-9)]. Our study shows the importance of the chiral ring, and shows that the generalized notion of a-maximization plays a key role. Similar notion of generalized a maximization idea has already been used by Intriligator to settle some interesting IR phase questions [\[34\]](#page-21-10). It would be interesting to use our stability notion to reconsider those models.

The stability notion proposed here can be generalized to three dimensional N = 2 theory. Although one does not have the central charge notion in this context, we may replace it by the so-called F-function [\[35](#page-21-11)]. For the theory engineered by M2 branes probing a four-fold singularity, one still has the notion of K-stability for the four-fold singularity and much of the theory is similar. We leave the details to the interested reader. Similarly, one can also define the a notion of stability for two dimensional (0, 2) theory, and we hope that the accidental symmetry for (0, 2) theory studied in [\[36](#page-21-12)] can be put into the stability framework.

There are some further questions about the stability of N = 1 chiral ring. Of crucial importance is to understand the constraints on set of possible test chiral rings. At present, unless a large symmetry group intervenes, there are infinite number of possible test rings, and it seems computational impossible to check all of them, even in basic examples. It would be nice to have some physical input which could shed some light on this issue. In this paper, we only studied the models engineered using D3 brane, and it will be of great interest to study other N = 1 theories.

Our primary focus has been on testing whether a chiral ring is the chiral ring of a SCFT. If the chiral ring is unstable, it is important to determine the ring of IR SCFT. Our study shows that the central fibre of the destabilizing test configuration should be the candidate chiral ring of the IR SCFT, and it is interesting to determine the special destabilizing test configuration which would give the chiral ring of IR SCFT. We hope to come to this question in the future.

## Acknowledgments

The work of S.T Yau is supported by NSF grant DMS-1159412, NSF grant PHY- 0937443, and NSF grant DMS-0804454. T.C. Collins is supported by NSF grant DMS-1506652 The work of D. Xie is supported by Center for Mathematical Sciences and Applications at Harvard University, and in part by the Fundamental Laws Initiative of the Center for the Fundamental Laws of Nature, Harvard University.

## References

- <span id="page-19-0"></span>[1] F. Cachazo, M. R. Douglas, N. Seiberg, and E. Witten, Chiral rings and anomalies in supersymmetric gauge theory, JHEP 12 (2002) 071, [[hep-th/0211170](http://xxx.lanl.gov/abs/hep-th/0211170)].
- <span id="page-19-1"></span>[2] D. Xie and K. Yonekura, A search for minimal 4d N=1 SCFT, [arXiv:1602.0481](http://xxx.lanl.gov/abs/1602.0481).
- <span id="page-19-2"></span>[3] M. Buican and T. Nishinaka, A Small Deformation of a Simple Theory, [arXiv:1602.0554](http://xxx.lanl.gov/abs/1602.0554).
- <span id="page-19-3"></span>[4] K. A. Intriligator and B. Wecht, The Exact superconformal R symmetry maximizes a, Nucl. Phys. B667 (2003) 183–200, [[hep-th/0304128](http://xxx.lanl.gov/abs/hep-th/0304128)].

- <span id="page-20-0"></span>[5] N. Seiberg, Exact results on the space of vacua of four-dimensional SUSY gauge theories, Phys. Rev. D49 (1994) 6857–6863, [[hep-th/9402044](http://xxx.lanl.gov/abs/hep-th/9402044)].
- <span id="page-20-1"></span>[6] K. A. Intriligator and N. Seiberg, Lectures on supersymmetric gauge theories and electric-magnetic duality, Nucl. Phys. Proc. Suppl. 45BC (1996) 1–28, [[hep-th/9509066](http://xxx.lanl.gov/abs/hep-th/9509066)]. [,157(1995)].
- <span id="page-20-2"></span>[7] D. Kutasov, A. Schwimmer, and N. Seiberg, Chiral rings, singularity theory and electric magnetic duality, Nucl. Phys. B459 (1996) 455–496, [[hep-th/9510222](http://xxx.lanl.gov/abs/hep-th/9510222)].
- <span id="page-20-3"></span>[8] I. R. Klebanov and E. Witten, Superconformal field theory on three-branes at a Calabi-Yau singularity, Nucl. Phys. B536 (1998) 199–218, [[hep-th/9807080](http://xxx.lanl.gov/abs/hep-th/9807080)].
- <span id="page-20-4"></span>[9] A. Bergman and C. P. Herzog, The Volume of some nonspherical horizons and the AdS / CFT correspondence, JHEP 01 (2002) 030, [[hep-th/0108020](http://xxx.lanl.gov/abs/hep-th/0108020)].
- <span id="page-20-16"></span>[10] D. Martelli, J. Sparks, and S.-T. Yau, The Geometric dual of a-maximisation for Toric Sasaki-Einstein manifolds, Commun. Math. Phys. 268 (2006) 39–65, [[hep-th/0503183](http://xxx.lanl.gov/abs/hep-th/0503183)].
- <span id="page-20-5"></span>[11] D. Martelli, J. Sparks, and S.-T. Yau, Sasaki-Einstein manifolds and volume minimisation, Commun. Math. Phys. 280 (2008) 611–673, [[hep-th/0603021](http://xxx.lanl.gov/abs/hep-th/0603021)].
- <span id="page-20-6"></span>[12] J. M. Maldacena, The Large N limit of superconformal field theories and supergravity, Int. J. Theor. Phys. 38 (1999) 1113–1133, [[hep-th/9711200](http://xxx.lanl.gov/abs/hep-th/9711200)]. [Adv. Theor. Math. Phys.2,231(1998)].
- [13] E. Witten, Anti-de Sitter space and holography, Adv. Theor. Math. Phys. 2 (1998) 253–291, [[hep-th/9802150](http://xxx.lanl.gov/abs/hep-th/9802150)].
- <span id="page-20-7"></span>[14] S. S. Gubser, I. R. Klebanov, and A. M. Polyakov, Gauge theory correlators from noncritical string theory, Phys. Lett. B428 (1998) 105–114, [[hep-th/9802109](http://xxx.lanl.gov/abs/hep-th/9802109)].
- <span id="page-20-8"></span>[15] D. R. Morrison and M. R. Plesser, Nonspherical horizons. 1., Adv. Theor. Math. Phys. 3 (1999) 1–81, [[hep-th/9810201](http://xxx.lanl.gov/abs/hep-th/9810201)].
- <span id="page-20-9"></span>[16] S. K. Donaldson et al., Scalar curvature and stability of toric varieties, Journal of Differential Geometry 62 (2002), no. 2 289–349.
- <span id="page-20-10"></span>[17] S.-T. Yau, Open problems in geometry, in Proc. Symp. Pure Math, vol. 54, pp. 1–28, 1993.
- <span id="page-20-11"></span>[18] X. Chen, S. Donaldson, and S. Sun, K¨ahler-einstein metrics on fano manifolds. i: Approximation of metrics with cone singularities, Journal of the American Mathematical Society 28 (2015), no. 1 183–197.
- [19] X. Chen, S. Donaldson, and S. Sun, K¨ahler-einstein metrics on fano manifolds. ii: Limits with cone angle less than 2π, Journal of the American Mathematical Society 28 (2015), no. 1 199–234.
- <span id="page-20-12"></span>[20] X. Chen, S. Donaldson, and S. Sun, K¨ahler-einstein metrics on fano manifolds. iii: Limits as cone angle approaches 2π and completion of the main proof, Journal of the American Mathematical Society 28 (2015), no. 1 235–278.
- <span id="page-20-13"></span>[21] T. C. Collins and G. Sz´ekelyhidi, K-semistability for irregular sasakian manifolds, arXiv preprint arXiv:1204.2230 (2012).
- <span id="page-20-14"></span>[22] T. C. Collins and G. Sz´ekelyhidi, Sasaki-einstein metrics and k-stability, arXiv preprint arXiv:1512.07213 (2015).
- <span id="page-20-15"></span>[23] N. Seiberg, Electric - magnetic duality in supersymmetric nonAbelian gauge theories, Nucl. Phys. B435 (1995) 129–146, [[hep-th/9411149](http://xxx.lanl.gov/abs/hep-th/9411149)].

- <span id="page-21-0"></span>[24] R. Eager, Equivalence of A-Maximization and Volume Minimization, JHEP 01 (2014) 089, [[arXiv:1011.1809](http://xxx.lanl.gov/abs/1011.1809)].
- <span id="page-21-1"></span>[25] C. Boyer and K. Galicki, Sasakian geometry. Oxford University Press, 2008.
- <span id="page-21-2"></span>[26] D. Eisenbud, Commutative Algebra: with a view toward algebraic geometry, vol. 150. Springer Science & Business Media, 2013.
- <span id="page-21-3"></span>[27] V. Datar and G. Sz´ekelyhidi, Kahler-einstein metrics along the smooth continuity method, arXiv preprint arXiv:1506.07495 (2015).
- <span id="page-21-4"></span>[28] A. Futaki, H. Ono, G. Wang, et al., Transverse k¨ahler geometry of sasaki manifolds and toric sasaki-einstein manifolds, Journal of Differential Geometry 83 (2009), no. 3 585–636.
- <span id="page-21-5"></span>[29] S. S.-T. Yau and Y. Yu, Classification of 3-dimensional isolated rational hypersurface singularities with c\*-action, arXiv preprint math/0303302 (2003).
- <span id="page-21-6"></span>[30] F. Cachazo, B. Fiol, K. A. Intriligator, S. Katz, and C. Vafa, A Geometric unification of dualities, Nucl. Phys. B628 (2002) 3–78, [[hep-th/0110028](http://xxx.lanl.gov/abs/hep-th/0110028)].
- <span id="page-21-7"></span>[31] D. Green, Z. Komargodski, N. Seiberg, Y. Tachikawa, and B. Wecht, Exactly Marginal Deformations and Global Symmetries, JHEP 06 (2010) 106, [[arXiv:1005.3546](http://xxx.lanl.gov/abs/1005.3546)].
- <span id="page-21-8"></span>[32] D. Kutasov, A. Parnachev, and D. A. Sahakyan, Central charges and U(1)(R) symmetries in N=1 superYang-Mills, JHEP 11 (2003) 013, [[hep-th/0308071](http://xxx.lanl.gov/abs/hep-th/0308071)].
- <span id="page-21-9"></span>[33] M. Buican, A Conjectured Bound on Accidental Symmetries, Phys. Rev. D85 (2012) 025020, [[arXiv:1109.3279](http://xxx.lanl.gov/abs/1109.3279)].
- <span id="page-21-10"></span>[34] K. A. Intriligator, IR free or interacting? A Proposed diagnostic, Nucl. Phys. B730 (2005) 239–251, [[hep-th/0509085](http://xxx.lanl.gov/abs/hep-th/0509085)].
- <span id="page-21-11"></span>[35] D. L. Jafferis, The Exact Superconformal R-Symmetry Extremizes Z, JHEP 05 (2012) 159, [[arXiv:1012.3210](http://xxx.lanl.gov/abs/1012.3210)].
- <span id="page-21-12"></span>[36] M. Bertolini, I. V. Melnikov, and M. R. Plesser, Accidents in (0,2) Landau-Ginzburg theories, JHEP 12 (2014) 157, [[arXiv:1405.4266](http://xxx.lanl.gov/abs/1405.4266)].