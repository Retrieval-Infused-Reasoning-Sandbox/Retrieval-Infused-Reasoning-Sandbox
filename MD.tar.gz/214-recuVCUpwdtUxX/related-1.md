# Singularity, Sasaki-Einstein manifold, Log del Pezzo surface and <sup>N</sup> = 1 AdS/CFT correspondence: Part I

# Dan Xiea,b Shing-Tung Yauc,d,e

- <sup>a</sup>Yau Mathematics Science Center, Tsinghua University, Beijing, 10084, China
- <sup>b</sup>Department of Mathematics, Tsinghua University, Beijing, 10084, China
- <sup>c</sup>Department of Mathematics, Harvard University, Cambridge, MA 02138, USA

Abstract: A five dimensional Sasaki-Einstein (SE) manifold provides a AdS/CFT pair for four dimensional N = 1 SCFT, and those pairs are very useful in studying field theory and AdS/CFT correspondence. The space of known SE manifolds is increased significantly in the last decade, and we initiated the study of various field theory properties through the geometric property of these new SE manifolds. There is an associated three dimensional log-terminal singularity X for each SE manifold LX, and for quasi-regular case, there is an associated two dimensional log Del Pezzo surface (S, ∆). The algebraic geometrical methods are quite useful in extracting interesting physical properties from singularity and log Del Pezzo surface. The necessary and sufficient condition for the existence of SE metric on L<sup>X</sup> is related to K stability of X. Motivated by dual field theory, we propose a conjecture on how to reduce the check of K stability to possibly finite cases, which hopefully would give us a guideline to find a much larger space of SE metrics.

<sup>d</sup>Center of Mathematical Sciences and Applications, Harvard University, Cambridge, 02138, USA

<sup>e</sup>Jefferson Physical Laboratory, Harvard University, Cambridge, MA 02138, USA

|   | Contents                                         |                                                                  |          |  |  |  |  |
|---|--------------------------------------------------|------------------------------------------------------------------|----------|--|--|--|--|
| 1 | Introduction                                     |                                                                  |          |  |  |  |  |
| 2 |                                                  | Generalities of four dimensional N = 1 SCFT                      | 3        |  |  |  |  |
| 3 | Sasakian-Einstein Manifold                       |                                                                  |          |  |  |  |  |
|   | 3.1                                              | Sasakian manifold                                                | 5        |  |  |  |  |
|   |                                                  | 3.1.1<br>Definition                                              | 5        |  |  |  |  |
|   |                                                  | ∗ action<br>3.1.2<br>Log terminal singularity with C             | 9        |  |  |  |  |
|   |                                                  | 3.1.3<br>Log Del Pezzo surface                                   | 11       |  |  |  |  |
|   | 3.2                                              | Sasaki-Einstein manifold                                         | 12       |  |  |  |  |
|   |                                                  | 3.2.1<br>Comments on spin structure                              | 13       |  |  |  |  |
|   | 3.3                                              | K stability and Sasaki-Einstein metric                           | 13       |  |  |  |  |
|   |                                                  | ∗ action<br>3.3.1<br>New ring with extra C                       | 13       |  |  |  |  |
|   |                                                  | 3.3.2<br>Futaki invariant                                        | 14       |  |  |  |  |
|   |                                                  | 3.3.3<br>Some discussions                                        | 17       |  |  |  |  |
| 4 | Examples                                         |                                                                  |          |  |  |  |  |
|   | 4.1<br>Simply connected Sasakian five manifold   |                                                                  |          |  |  |  |  |
|   | 4.2<br>Toric singularity                         |                                                                  |          |  |  |  |  |
|   | 4.3<br>Hypersurface singularity                  |                                                                  |          |  |  |  |  |
|   | 4.4                                              | Complete intersection singularity                                | 24       |  |  |  |  |
|   | 4.5<br>Quotient singularity                      |                                                                  |          |  |  |  |  |
|   | 4.6<br>Minimal Gorenstein Log del Pezzo surfaces |                                                                  |          |  |  |  |  |
| 5 | AdS/CFT correspondence                           |                                                                  |          |  |  |  |  |
|   | 5.1                                              | Global symmetries                                                | 29<br>29 |  |  |  |  |
|   |                                                  | 5.1.1<br>Isometry of SE manifold                                 | 29       |  |  |  |  |
|   |                                                  | 5.1.2<br>Baryonic symmetry                                       | 30       |  |  |  |  |
|   | 5.2                                              | Operator spectrum                                                | 30       |  |  |  |  |
|   |                                                  | 5.2.1<br>Harmonic analysis                                       | 31       |  |  |  |  |
|   |                                                  | 5.2.2<br>Hilbert series, central charge a and U(1)R<br>symmetry  | 35       |  |  |  |  |
|   |                                                  | 5.2.3<br>Mesonic and baryonic operators                          | 37       |  |  |  |  |
|   | 5.3                                              | Deformation                                                      | 38       |  |  |  |  |
|   |                                                  | 5.3.1<br>Exact marginal deformations                             | 38       |  |  |  |  |
|   |                                                  | 5.3.2<br>Deformation and resolution of singularity               | 39       |  |  |  |  |
|   | 5.4                                              | Extended objects                                                 | 40       |  |  |  |  |
| 6 |                                                  | A conjecture about reducing checking K stability to finite cases | 41       |  |  |  |  |
| 7 |                                                  | Conclusion                                                       | 44       |  |  |  |  |

# <span id="page-2-0"></span>1 Introduction

AdS/CFT pairs can be found using following method [\[1](#page-48-0)[–3](#page-48-1)]: consider a string/M theory T on following background:

$$R^{1,d} \times X, \tag{1.1}$$

here X is a local singularity which appears in the degeneration limit of a compact manifold with special holonomy X ′ . The metric structure on X ′ would typically constrains the type of singularity X. If we put N branes at the tip of X, one expect to get a supersymmetric local field theory on the world volume of branes (the number of supersymmetries are determined by special holonomy type of X ′ ). If X admits a conical metric of special holonomy: (of the same type as X ′ ):

$$g_X = dr^2 + r^2 dg_{L_X}; (1.2)$$

Here L<sup>X</sup> is a one dimensional lower manifold which is called the link of X; then we have a superconformal field theory (SCFT) on the brane which in the large N limit is dual to string/M theory T on following background

$$AdS_{d+2} \times L_X. \tag{1.3}$$

There is no brane in this background, but one need to turn on corresponding flux of the branes [\[4](#page-48-2)]. In this framework, the task of finding a AdS/CFT pair is reduced to find a singularity X with conic metric of special holonomy, which can be thought of as the definition of SCFT. Many interesting properties of SCFTs can be learned from the geometric properties of X and LX.

In this paper, we take T to be type IIB string theory and X to be a singularity of degeneration limit of a compact Calabi-Yau three manifold. X is called three dimensional log terminal singularity (If the Calabi-Yau manifold is simply connected, one actually get a 3d canonical singularity.). We put D3 branes on the tip of X to get a four dimensional N = 1 supersymmetric field theory. One crucial fact is that not every 3d log terminal singularity admits a Ricci-flat conical metric [1](#page-2-1) . There are sufficient and necessary conditions about the existence of Ricci-flat conic metric on X [\[5\]](#page-48-3):

- X is an affine variety and admits an effective C <sup>∗</sup> action such that the canonical top form Ω has charge two.
- X is K stable with respect to above C <sup>∗</sup> action.

<span id="page-2-1"></span><sup>1</sup>They can admit other type of Calabi-Yau metric though.

The physical interpretation of K stability is given in [\[6\]](#page-48-4). The link L<sup>X</sup> admits a positive Sasakian structure if X is log terminal and has an effective C <sup>∗</sup> action, and it admits a Sasaki-Einstein (SE) metric if X is K stable. Four dimensional N = 1 SCFT has an important U(1)<sup>R</sup> symmetry which is identified with the above C <sup>∗</sup> action of K stable singularity X. Therefore the classification of SCFT in this framework is reduced to find K stable log terminal singularity with a preferred C <sup>∗</sup> action.

In practice, it is not easy to check K stability explicitly; but there are also sufficient theorems on the existence of Ricci-flat conic metric. Examples include the toric SE manifold [\[7\]](#page-48-5), and some hypersurface examples [\[8](#page-48-6)]. With the K stability tools and the existence theorems, we do have a huge class of new SE manifolds which have not been studied physically before. Previously the physical application is mainly focusing on toric singularity [\[9\]](#page-48-7), and the main purpose of this paper is to initiate a study of these new SCFTs defined by these general SE manifolds. These large class of examples provide a very interesting space of theories which one can use to study four dimensional N = 1 SCFT and AdS/CFT correspondence.

It is in general difficult to write down explicit SE metrics on L<sup>X</sup> (see however [\[10](#page-48-8)] for some explicit metrics.), however what makes it possible to learn lots of interesting field theory properties is the connection of SE manifold to algebraic geometry. First, one have an associated algebraic object X which is an affine singularity with a C <sup>∗</sup> action, and some of nontrivial field theory properties are easily found from X:

- The affine ring of X determines the chiral ring of the field theory in the large N limit. One can extract central charge from the Hilbert series of X with respect to C <sup>∗</sup> action.
- The C <sup>∗</sup> action is related to the U(1)<sup>R</sup> symmetry and the normalization is fixed by requiring canonical volume form Ω to have charge two.
- Some mesonic global symmetries can be read from automorphism group of the singularity. The homology group of the link L<sup>X</sup> can often be computed using the data on X too, from which one can get more information of field theory, such as the number of baryonic global symmetries.

Moreover, if the Sasakian structure on L<sup>X</sup> is quasi-regular, one have a C <sup>∗</sup> fibration over a base surface which is a log Del Pezzo surface (S, ∆) [\[11](#page-48-9)]. Such surfaces are studied thoroughly in mathematics literature, and algebraic geometrical methods are also quite useful in studying the field theory properties such as the classification.

The connection between the field theory and singularity X provides a physical interpretation of K stability [\[6\]](#page-48-4), and physical arguments seem to suggest that one only need to check finite number of specific test configurations. We propose an explicit conjecture of such reduction for hypersurface singularity, and if true it would give us a much larger space of SE manifolds.

This paper is organized as follows: Section 2 reviews some basic facts about four dimensional N = 1 SCFT; Section 3 review basic properties of Sasaki-Einstein manifold; Section 4 describes several class of known five dimensional Sasaki-Einstein manifolds; Section 5 describes the map between the physical properties of field theory and the geometric aspect of X and  $L_X$ ; Section 6 gives a conjecture about reducing the check of K stability to finite cases; Finally a conclusion is given in section 7.

# <span id="page-4-0"></span>2 Generalities of four dimensional $\mathcal{N} = 1$ SCFT

Representation of  $\mathcal{N}=1$  superconformal algebra: Four dimensional  $\mathcal{N}=1$  superconformal algebra has a bosonic symmetric group  $SO(2,4)\times U(1)_R\times G$ : here SO(2,4) is four dimensional conformal group,  $U(1)_R$  is a R symmetry group which acts non-trivially on supercharges, and G is other global symmetry group. A highest weight representation of  $\mathcal{N}=1$  superconformal algebra is labeled as  $|\Delta,r,j,\bar{j}\rangle$ , where  $\Delta$  is the scaling dimension, r is  $U(1)_R$  charge and  $j,\bar{j}$  are left and right spins. If these quantum numbers satisfy certain conditions, the corresponding supermultiplet becomes short. The shortening conditions are studied in [12] and is summarized in table 1.  $\mathcal{B}$  type operator is called chiral operator, and

| $\mathcal{B}$       | $ \bar{Q}_{\dot{lpha}} \rangle = 0,,  \bar{j} = 0$                                                             | $\Delta = \frac{3}{2}r$                                          | $\mathcal{B}_{r,(j,0)}$         |
|---------------------|----------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------|---------------------------------|
| $ar{\mathcal{B}}$   | $Q_{\alpha} \rangle = 0,,  j = 0$                                                                              | $\Delta = -\frac{3}{2}r$                                         | $ar{\mathcal{B}}_{r,(0,ar{j})}$ |
| $\mathcal{C}$       | $ (\bar{Q}_1 + \frac{1}{2j}\bar{Q}_2\bar{J}) \rangle = 0, \ \bar{j} > 0, \ \bar{Q}^2 \rangle = 0, \bar{j} = 0$ | $\Delta = 2 + 2\bar{j} + \frac{3}{2}r$                           | $\mathcal{C}_{r,(j,ar{j})}$     |
| $ar{\mathcal{C}}$   | $(Q_2 - \frac{1}{2j}Q_1J) \rangle = 0, \ j > 0, \ Q^2 \rangle = 0, \ j = 0$                                    | $\Delta = 2 + 2j - \frac{3}{2}r$                                 | $ar{\mathcal{C}}_{r,(j,ar{j})}$ |
| $\hat{\mathcal{C}}$ | $\mathcal{C}\cap\bar{\mathcal{C}}$                                                                             | $\Delta = 2 + j + \bar{j}, \ \frac{3}{2}r = j - \bar{j}$         | $\hat{\mathcal{C}}_{(j,ar{j})}$ |
| $\mathcal{D}$       | $\mathcal{B}\cap\bar{\mathcal{C}}$                                                                             | $\bar{j} = 0, \frac{3}{2}r = j + 1, \Delta = 1 + j$              | $\mathcal{D}_{(j,0)}$           |
| $ar{\mathcal{D}}$   | $\bar{\mathcal{B}}\cap\mathcal{C}$                                                                             | $\bar{j} = 0, -\frac{3}{2}r = \bar{j} + 1, \Delta = 1 + \bar{j}$ | $ar{\mathcal{D}}_{(0,ar{j})}$   |

<span id="page-4-1"></span>**Table 1.** Various shorting condition for a highest weight representation of  $\mathcal{N} = 1$  superconformal algebra.

the unitarity bound implies the constraint on r charge:  $r \geq \frac{2}{3}$ ; and  $\hat{\mathcal{C}}$  multiplet contains conserved current, i.e.  $\hat{\mathcal{C}}_{\frac{1}{2},\frac{1}{2}}$  contains the energy-momentum tensor and conserved  $U(1)_R$  current, and  $\hat{\mathcal{C}}_{0,\frac{1}{2}}$  contains conserved current for other supersymmetries, and  $\hat{\mathcal{C}}_{0,0}$  includes the current for other global symmetries.

Superconformal index: Choose a supercharge  $L = \bar{Q}_1$ , which satisfy the commutation relation

$$\{L, L^+\} = 2\mathcal{H}, \ L^2 = 0.$$
 (2.1)

here  $\mathcal{H} = H - 2\bar{j} - \frac{3}{2}r$ . Using the standard argument leading to Witten index [13], we can define superconformal index as the following trace [14]:

$$I(x,t) = \text{Tr}(-1)^F t^{(\frac{2}{3}\Delta + \frac{4}{3}\bar{j})} x^{2J_3}.$$
 (2.2)

The trace only receive contribution from the states with  $\mathcal{H} = 0$ , so only states with  $\Delta = 2\bar{j} + \frac{3}{2}r$  will contribute to this index. The multiplet that contributes to the index are

 $\mathcal{B}, \mathcal{C}, \hat{\mathcal{C}}, \mathcal{D}, \bar{\mathcal{D}}$ :

$$\mathcal{B}_{r,(j,0)}: I(x,t) = (-1)^{2j} t^r \frac{\chi_{2j+1}(x)}{(1-tx)(1-tx^{-1})}$$

$$\mathcal{C}_{r,(j,\bar{j})}: I(x,t) = -(-1)^{2j+2\bar{j}} t^{2\bar{j}+2+r} \frac{\chi_{2j+1}(x)}{(1-tx)(1-tx^{-1})}$$

$$\hat{\mathcal{C}}_{(j,\bar{j})}: I(x,t) = -(-1)^{2j+2\bar{j}} t^{\frac{2}{3}(j+2\bar{j}+3)} \frac{\chi_{2j+1}(x)}{(1-tx)(1-tx^{-1})}$$

$$\mathcal{D}_{(j,0)}: I(x,t) = (-1)^{2j} t^{\frac{2}{3}(j+1)} \frac{\chi_{2j+1}(x) - t\chi_{2j}(x)}{(1-tx)(1-tx^{-1})}$$

$$\bar{\mathcal{D}}_{(0,\bar{j})}: I(x,t) = -(-1)^{2\bar{j}} \frac{t^{\frac{4}{3}(\bar{j}+1)}}{(1-tx)(1-tx^{-1})}$$

$$(2.3)$$

Here  $\chi_{2j+1}(x) = x^j + \ldots + x^{-j}$ .

**Chiral ring**: Of particular interest are the chiral operators  $\mathcal{B}$ . They are defined as the operators such that  $\{\bar{Q}_{\dot{\alpha}},\mathcal{O}\}=0$ . The correlation function of these operators

$$\langle \mathcal{O}_1(x_1) \dots \mathcal{O}_n(x_n) \rangle,$$
 (2.4)

is independent of positions [15]. For a chiral operator, the addition of a  $\bar{Q}_{\dot{\alpha}}$  commutator does not change the chiral correlation function, so by chiral operator we really mean the cohomology class of the operators

$$\mathcal{O} \sim \mathcal{O} + \{\bar{Q}_{\dot{\alpha}}, \chi\}. \tag{2.5}$$

The OPE of chiral operators takes the following structure

$$O_i O_j = \sum_k C_{ij}^k O_k. (2.6)$$

Here  $C_{ij}^k$  does not depend on the position of insertion. So the chiral operators form a commutative ring with a unit, and is called chiral ring. The determination of chiral ring is quite useful in understanding the property of a SCFT, i.e. the moduli space of vacua.

One can also study the counting of chiral operators. We can define following generating function:

$$H(t) = \sum_{\alpha} t^{\alpha} \dim H_{\alpha}; \tag{2.7}$$

Here  $H_{\alpha}$  is the space of chiral operator with  $U(1)_R$  charge  $\alpha$ . The above generating function is not a protected quantity, but it could also contains important information of the field theory.

Central charges: For a 4d CFT, one can define the central charges a, c from the expectation value of the trace part of energy-momentum tensor:

$$\langle T^{\mu}_{\mu} \rangle_{g_{\mu\nu}} = -a \frac{E}{16\pi^2} + c \frac{W^2}{16\pi^2}.$$
 (2.8)

Here E is Euler tensor and W is the Weyl tensor of the background metric gµν . It is often difficult to compute these central charges for a generic 4d CFT. However, for 4d N = 1 SCFT, the central charge is related to the anomaly of U(1)<sup>R</sup> symmetry as follows:

$$a = \frac{3}{32}(3trR^3 - trR), \quad c = \frac{1}{32}(9trR^3 - 5trR),$$
 (2.9)

and the above formula makes it possible to compute central charges exactly by computing the anomaly of U(1)<sup>R</sup> symmetry. In practice, we usually do not know the U(1)<sup>R</sup> symmetry and its anomaly of a 4d N = 1 SCFT. Intrilligator and Wecht proved that the correct R symmetry maximize a [\[16](#page-48-14)]. Namely, consider the linear combination of all anomaly free abelian symmetries of SCFT:

$$R_s = \sum s_I F_I, \tag{2.10}$$

then the correct U(1)<sup>R</sup> symmetry is determined by maximizing the trial central charge a(s<sup>I</sup> ). So if we can determine all possible symmetries and its anomaly of the SCFT, one can also compute the central charges using a maximization. In practice, a SCFT is often described as the IR fixed point of a UV theory with Lagrangian description, and one can do the a maximization using the symmetries and anomalies from UV Lagrangian description. However, one should always keep in mind that the above method often does not include all possible symmetries of IR SCFT, since one could have accidental symmetries which is not visible from the UV Lagrangian.

Deformations: Given a 4d N = 1 SCFT, it is interesting to study its supersymmetry preserving deformations. The relevant and marginal deformations were classified in [\[17\]](#page-48-15). A chiral operator B2,(0,0) is a marginal operator since it has scaling dimension three. To determine whether it is exact marginal, one need to know its quantum property under other global symmetries. It is proven in [\[17\]](#page-48-15) that such an operator is exact marginal if it is a singlet under the global symmetry. The relevant deformations are associated with the operators <sup>B</sup>r,(0,0) with <sup>2</sup> <sup>3</sup> ≤ r < 2.

Parameter N: If is often possible to define a family of 4d N = 1 SCFTs parameterized by an integer N. In the large N limit, various properties of the SCFT can be simplified, i.e. the chiral ring might have a simpler description. Various operators can be separated into two kinds depending its behavior with respect to parameter N: they are called mesonic operator if its scaling dimension do not depend on N, and baryonic operator if it depends on some power of N. If our SCFT has an exact marginal deformation with deformation parameter τ , we might consider a 't Hooft limit

$$N \to \infty$$
,  $N\tau$  fixed, (2.11)

<span id="page-6-0"></span>and properties of the theory might be further simplified in this limit.

# <span id="page-6-1"></span>3 Sasakian-Einstein Manifold

# <span id="page-6-2"></span>3.1 Sasakian manifold

# 3.1.1 Definition

Here we review the basic aspect of Sasakian manifold, for more details, see [\[18,](#page-48-16) [19](#page-48-17)]. We define the Sasakian structure on a (2n + 1) dimensional manifold M by starting with a contact form η, which is a one form such that η ∧ (dη) <sup>n</sup> <sup>6</sup>= 0 everywhere on <sup>M</sup>. There is a unique Reeb vector field ζ associated with it, and satisfying following important conditions:

$$i_{\zeta}(\eta) = 1, \quad i_{\zeta}(d\eta) = 0.$$
 (3.1)

This Reeb vector field ζ plays a distinguished role in the study of Sasakian manifold. η itself defines a 2n dimensional contact bundle D whose fibre is defined as the space of vector fields V satisfying η(V ) = 0. The tangent bundle then has a factorization T<sup>M</sup> = L<sup>ζ</sup> ⊕ D, where L<sup>ζ</sup> is generated by vector field ζ. We then define a complex structure on D, and extend it to a (1, 1) tensor Φ on the tangent bundle of M such that Φζ = 0. Once Φ is given, we get a metric g = dη(Φ) + η Nη. So a Sasakian manifold might be defined by following data:

$$M(\zeta, \eta, \Phi, g) \tag{3.2}$$

with g defined using Φ and η. Let's list some of the metric properties:

$$g(\Phi X, \Phi Y) = g(X, Y) - \eta(X)\eta(Y), \quad L_{\zeta}g = 0, \ L_{\zeta}\Phi = 0,$$
  

$$R(X, Y)\zeta = \eta(Y)X - \eta(X)Y,$$
  

$$R(X, \zeta)Y = \eta(Y)X - g(X, Y)\zeta.$$
(3.3)

Here L<sup>ζ</sup> is the Lie derivative with respect to ζ. The first equation implies that ζ has unit length, and ζ is the Killing vector field. Alternatively, we can define Sasakian structure using the following equivalent characterizations:

1. There exists a Killing vector field ζ of unit length on M so that the tensor field defined by Φ(X) = ∆Xζ satisfies the following condition

$$(\Delta_X \Phi)(Y) = g(\zeta, Y)X - g(X, Y)\zeta. \tag{3.4}$$

2. There exists a Killing vector field ζ of unit length so that the Riemann curvature satisfies the condition

$$R(X,\zeta)Y = \eta(Y)X - g(X,Y)\zeta. \tag{3.5}$$

- 3. There exists a Killing vector field ζ of unit length on M so that the sectional curvature of every section containing ζ equals one.
- 4. The metric cone over <sup>M</sup> is Kahler. Here the metric cone of <sup>M</sup> is <sup>C</sup>(M) = <sup>R</sup><sup>+</sup> <sup>×</sup> <sup>M</sup>, and the conic metric is

$$g = dr^2 + r^2 dg_M^2. (3.6)$$

The fourth definition is the most used one in the literature. Let's describe more details here. Recall that a Sasakian manifold is the data M(ζ, η, Φ, g), and the tangent bundle of C(M) is generated by the vectors Y defined on M, and vector Ψ = r ∂ ∂r . We define a complex structure I on C(M) as follows:

$$I(Y) = \Phi Y + \eta(Y)\Psi, \quad I(\Psi) = -\zeta. \tag{3.7}$$

Using the first equation, we have  $I(\zeta) = \Psi$ . Let's choose holomorphic coordinates  $z_i$  on contact bundle D (recall that the D is the sub-bundle of tangent bundle TM whose fibre are vector fields satisfying  $\eta(X) = 0$ .), so the holomorphic tangent bundle of C(M) is generated by  $(\frac{\partial}{\partial z_1}, \ldots, \frac{\partial}{\partial z_n}, \Psi - i\zeta)$ .  $\Psi - i\zeta$  is a holomorphic vector field and  $L_{\Psi + i\zeta}g = 2g$ . Moreover, let's choose holomorphic coordinates  $(z_1, \ldots, z_n, z)$  and consider the generator of canonical bundle:  $\Omega = dz_1 \wedge \ldots \wedge dz_n \wedge dz$ , here z is the dual holomorphic coordinate for the vector field  $\Psi - i\zeta$ . We then have  $L_{\Psi + i\zeta}\Omega = (n+1)\Omega^2$ .

Sasakian manifold can be further classified using the property of Reeb vector field  $\zeta$ . Given a no-where vanishing vector field V on a manifold M, one can define a one dimensional foliation, i.e. the leaves are one dimensional sub-manifold defined as the integral curve of V. For a Sasakian manifold, one can use Reeb vector field  $\zeta$  to define a foliation. The leafs are the integral curve of  $\zeta$ :

$$\frac{d\vec{x}}{dt} = \zeta(\vec{x}),\tag{3.8}$$

here  $\vec{x}$  is the local coordinates on M. This foliation is called characteristic foliation and we denoted it as  $\mathcal{F}_{\zeta}$ , which can be further classified as follows:  $F_{\zeta}$  is called **quasi-regular** if there is a positive integer k such that each point has a foliated chart U such that each leaf of  $F_{\zeta}$  passes through U at most k times, otherwise we call it **irregular**. If k = 1,  $F_{\zeta}$  is further called **regular**. We call the corresponding foliation by the property of  $F_{\zeta}$ . There are a couple of useful facts:

- There are at least two dimensional space of Killing vector fields for irregular Sasakian manifold [18].
- 2. Every Sasakian manifold *M* admits quasi-regular Sasakian structure [18]. The basic reasoning is follows: if we start with a irregular Sasakian structure, we can deform it to a quasi-regular Sasakian structure.

Given a foliation  $F_{\zeta}$  on Sasakian manifold M, one can define a transverse geometry in the following way. Let  $\{U_{\alpha}\}$  be an open covering of M and  $\pi^{\alpha}: U_{\alpha} \to V_{\alpha} \in C^n$  submersions such that when  $U_{\alpha} \cap U_{\beta} \neq \emptyset$ ,

$$\pi_{\alpha}\pi_{\beta}^{-1}: \pi_{\beta}(U_{\alpha} \cap U_{\beta}) \to \pi_{\alpha}(U_{\alpha} \cap U_{\beta})$$
(3.9)

is bi-holomorphic. On each  $V_{\alpha}$ , we can give a Kahler structure as follows. Let  $D = \text{Ker } \eta \in TM$ , there is a canonical isomorphism

$$d\pi_{\alpha}: D_{n} \to T_{\pi_{\alpha}(n)}V_{\alpha} \tag{3.10}$$

Since  $\zeta$  generates the isometry, the restriction of Sasakian metric g to D gives a well defined Hermitian metric  $g_{\alpha}^T$  on  $V_{\alpha}$ . This metric is in fact Kahler and the proof is as follows. Let  $z^1, \ldots, z^n$  to be the holomorphic coordinates on  $V_{\alpha}$ , and use the same letter as the pull-back

<span id="page-8-0"></span>We use the fact that  $\omega^{n+1} = \Omega \wedge \bar{\Omega}$ , and  $\omega$  is Kahler form which has charge two under anti-holomorphic vector field  $\Psi + i\zeta$ .

coordinates on  $U_{\alpha}$ . Let x be the coordinate along the leaves with  $\zeta = \frac{\partial}{\partial x}$ , then  $x, z^1, \dots, z^n$  forms local coordinates on  $U_{\alpha}$ .  $(D \oplus \mathcal{C})^{1,0}$  is generated by the vectors of the following form

$$\frac{\partial}{\partial z^i} + a_i \zeta \tag{3.11}$$

and  $a_i = -\eta(\frac{\partial}{\partial z_i})$  so that  $\eta(\frac{\partial}{\partial z^i} + a_i\zeta) = 0$ . Since  $i_{\zeta}(d\eta) = 0$ ,

$$d\eta(\frac{\partial}{\partial z^i} + a_i\zeta, \overline{\frac{\partial}{\partial z^j} + a_j\zeta}) = d\eta(\frac{\partial}{\partial z^i}, \frac{\partial}{\partial z^j})$$
(3.12)

Therefore the fundamental two form  $\omega_{\alpha}$  of the Hermitian metric  $g_{\alpha}^{T}$  on  $V_{\alpha}$  is the same as the restriction of  $\frac{1}{2}d\eta$  on slice x=constant in  $U_{\alpha}$ . Since the restriction of a closed two form to a sub-manifold is closed in general, then  $\omega_{\alpha}$  is closed. By this construction  $\pi_{\alpha}\pi_{\beta}^{-1}$  gives an isometry of Kahler manifold. Thus the foliation defined is a transverse Kahler foliation.

A differential form  $\omega$  on M is said to be **basic** for the foliation  $F_{\zeta}$  if the following conditions hold:

$$i_{\zeta}\omega = 0, \quad L_{\zeta}(\omega) = 0.$$
 (3.13)

We use  $\Lambda^p$  to denote the sheaf of basic p forms, and  $\Omega^p$  to denote the space of global section of  $\Lambda^p$ . In a local foliated coordinate with  $\phi = (x; z_1, \ldots, z_n)$ , a basic (p, q) form  $\omega$  takes the form

$$\omega = \omega_{i_1,\dots,i_r,\bar{j}_1,\dots,\bar{j}_q} dz^{i_1} \wedge \dots dz^{i_p} \wedge d\bar{z}^{j_1} \wedge \dots d\bar{z}^{i_q}$$
(3.14)

Let  $\Lambda_B^{p,q}$  be sheaf of basic (p,q) forms, we thus have the well defined operators

$$\partial_B: \ \Lambda^{p,q} \to \Lambda^{p+1,q}, \quad \bar{\partial}_B: \Lambda^{p,q} \to \Lambda^{p,q+1}.$$
 (3.15)

If we set  $d_B = d|\Omega_B^p$ , we have  $d_B = \partial_B + \bar{\partial}_B$ , let  $d_B^c = \frac{i}{2}(\bar{\partial}_B - \partial_B)$ , we have  $d_B d_B^c = i\partial_B \bar{\partial}_B$  and  $d_B^c = (d_B^c)^2 = 0$ . Let  $d_B^*$  be adjoint of  $d_B$ , we thus have the basic Laplacian

$$\Lambda_B = d_B d_B^* + d_B d_B^* \tag{3.16}$$

We then have the basic de Rham complex  $(\Omega_B^*, d_B)$  and the basic Dolbeault complex  $(\Omega^{p,*}, \bar{\partial}_B)$  whose cohomology groups are called the basic cohomology groups.

In our case, we have three important basic forms: the first one is  $d\eta$  and it is obviously satisfying the condition of basic form and it is a (1,1) form; The first Chern class  $c_1(D)$  of contact bundle D; and finally the transverse Ricci form  $Ricci_T$  (Remember the transverse metric is defined as  $g_T = d\eta(\Phi) + \eta \bigotimes \eta$ ). The cohomology class of  $Ricci_T$  is denoted as the basic Chern class  $c_1(F_{\zeta})$ . Using  $c_1(F_{\zeta})$ , we have

**Definition**: A Sasakian structure S is said to be of **positive** (negative) type if  $c_1(F_{\zeta})$  can be represented by a **positive** (negative) definite (1,1) form. If either of these two conditions is satisfied, S is said to be of definite type. S is said to be null type if  $c_1(F_{\zeta}) = 0$ . A Sasakian structure S is called anti-canonical (canonical) if  $c_1(F_{\zeta})$  is a positive (negative) multiple of  $[d\eta]_B$ .

#### <span id="page-10-0"></span>3.1.2 Log terminal singularity with C <sup>∗</sup> action

As we reviewed earlier, one way to define Sasakian structure on a 2n + 1 dimensional manifold <sup>M</sup> is using the metric cone <sup>C</sup>(M) = <sup>R</sup><sup>+</sup> <sup>×</sup>M. We now include the origin to <sup>C</sup>(M) and the corresponding variety is an affine variety so we can use algebraic geometry method to study its property. We are interested in positive Sasakian manifold, and from algebraic geometry point of view, the corresponding cone has following important properties [\[11](#page-48-9)]:

1. The cone plus an extra point at origin is a n + 1 dimensional affine variety which can be defined by the following ring X:

$$X = C[x_1, \dots, x_i]/I \tag{3.17}$$

Here I is an ideal which is defined by some polynomials I = hf1, . . . , fri.

- 2. There is an effective C <sup>∗</sup> action (all the coordinates have positive charge on X, and X has a singularity at origin.
- 3. The singularity is a log terminal singularity, and we will give a definition below. A variety X is said to have canonical singularity if its is normal [3](#page-10-1) and the following two conditions are satisfied [\[20](#page-49-0)]:
  - the Weil divisor K<sup>X</sup> [4](#page-10-2) is Q-Cartier, i.e. rK<sup>X</sup> is a Cartier divisor [5](#page-10-3) . Here r is called index of the singularity.
  - for any resolution of singularities f : Y → X, with exceptional divisors E<sup>i</sup> ∈ Y , the rational numbers a<sup>i</sup> satisfying

$$K_Y = f^* K_X + \sum a_i E_i.$$
 (3.18)

are nonnegative.

It is called log terminal if a<sup>i</sup> > −1. Index one canonical singularity is also called rational Gorenstein singularity.

Log terminal singularity is always rational, and if it is Gorenstein (index is one), then it has to be canonical. Rational Gorenstein singularity is always canonical singularity. Rational Gorenstein singularity plays a special role because any log terminal singularity is just a Z<sup>n</sup> quotient of a rational Gorenstein singularity. In general, however, not every abelian Z<sup>n</sup> quotient of rational Gorenstein singularity would give us a log terminal singularity, and it is also not known which abelian finite group of a rational Gorenstein singularity would give us a log terminal singularity.

Two dimensional log terminal singularity is classified by quotient singularity C <sup>2</sup>/G with G a finite subgroup of U(2); and if G ⊂ SU(2), then it gives all the two dimensional rational Gorenstein singularity.

<sup>3</sup>Normal means that the singularity is at most co-dimension two, i.e., for a three dimensional singularity, the singular locus is at most one dimensional.

<span id="page-10-1"></span><sup>4</sup>K<sup>X</sup> is the canonical divisor associated with X.

<span id="page-10-3"></span><span id="page-10-2"></span><sup>5</sup>A Cartier divisor implies that it can be used to define a line bundle.

There is no complete classification of three dimensional log terminal singularity, but we do know a large class of explicit examples of rational Gorenstein singularity. To a rational Gorenstein 3-fold singularity, one can attach a natural integer  $k \geq 0$ , such that:

• k = 0, the singularity is a compound Du Val (cDV) point, i.e. the singularity can be written as follows

$$f_{ADE}(x, y, z) + tg(x, y, z, t) = 0;$$
 (3.19)

Here  $f_{ADE}(x, y, z)$  denotes two dimensional Du Val singularity:

$$A_N: x^2 + y^2 + z^{N+1} = 0, \quad D_N: x^2 + y^{N-1} + yz^2 = 0, \quad E_6: x^2 + y^3 + z^4 = 0$$
  
 $E_7: x^2 + y^3 + yz^3 = 0, \quad E_8: x^2 + y^3 + z^5 = 0$ 

$$(3.20)$$

If we further require that the singularity is **isolated** and has a  $C^*$  action, the complete list of such singularity has been found in [21], see table. 2.

| J         | Singularity                                   |
|-----------|-----------------------------------------------|
| $A_{N-1}$ | $x_1^2 + x_2^2 + x_3^N + z^k = 0$             |
|           | $x_1^2 + x_2^2 + x_3^N + xz^k = 0$            |
| $D_N$     | $x_1^2 + x_2^{N-1} + x_2 x_3^2 + z^k = 0$     |
|           | $x_1^2 + x_2^{N-1} + x_2 x_3^2 + z^k x_3 = 0$ |
| $E_6$     | $x_1^2 + x_2^3 + x_3^4 + z^k = 0$             |
|           | $x_1^2 + x_2^3 + x_3^4 + z^k x_3 = 0$         |
|           | $x_1^2 + x_2^3 + x_3^4 + z^k x_2 = 0$         |
| $E_7$     | $x_1^2 + x_2^3 + x_2 x_3^3 + z^k = 0$         |
|           | $x_1^2 + x_2^3 + x_2 x_3^3 + z^k x_3 = 0$     |
| $E_8$     | $x_1^2 + x_2^3 + x_3^5 + z^k = 0$             |
|           | $x_1^2 + x_2^3 + x_3^5 + z^k x_3 = 0$         |
|           | $x_1^2 + x_2^3 + x_3^5 + z^k x_2 = 0$         |

<span id="page-11-0"></span>**Table 2**. 3-fold isolated cDV singularities with  $C^*$  action.

- If  $k \geq 2$ , then  $k = mult_P X$ .
- If  $k \geq 3$ , then k+1 is equal to the embedding dimension  $= dim(m_p/m_p^2)$ . if k=2, then  $P \in X$  is isomorphic to a hypersurface given by  $x^2 + f(y, z, t)$  with f a sum of monomials with degree bigger than 4. If k=1, then then  $P \in X$  is isomorphic to a hypersurface given by  $x^2 + y^3 + f(y, z, t) = 0$  with  $f(y, z, t) = yf_1(z, t) + f_2(z, t)$  and  $f_1$  (respectively  $f_2$ ) is a sum of monomials  $z^a t^b$  of degree  $\geq 4$  (respectively  $\geq 6$ ).
- If k=3, the singularity P is given by a hypersurface.
- If k=4, then P is equivalent to a complete intersection.

We then have following three class of log terminal examples:

- 1. Complete intersection singularity (They are Gorenstein). The rational condition implies that the maximal embedding dimension is 5, so such singularities are defined by two polynomials. Hypersurface singularity and complete intersection rational singularity with a C\* action has been classified in [22, 23], see appendix. A for the hypersurface example (we do not list the rational constraints on the parameters in the polynomial here, see [22].).
- 2. The quotient singularity  $C^3/G$  with G a finite subgroup of SU(3), and in fact these singularities are rational Gorenstein.
- 3. Another class is Q-Gorenstein toric singularity, which is defined combinatorially by a convex polygon.

This cone perspective is quite useful as we can use many tools from algebraic geometry to study them. For example, the classification is reduced to the classification of log terminal singularity with a  $C^*$  action. Many of these singularities have been studied in the context of four dimensional  $\mathcal{N}=2$  SCFT in [22, 24]. The Sasakian manifold M is defined as the link of X [25]. If we require that M is smooth, then X is required to have **isolated** singularity.

In summary, one can get a Sasakian manifold  $L_X$  from a n+1 dimensional log terminal singularity X with a  $C^*$  action, and X is an affine variety:

$$X = C[x_1, \dots, x_i]/I. \tag{3.21}$$

This ring is Q-Gorenstein and rational, and has canonical top form  $\Omega$  which has definite weight under  $C^*$  action:  $L_{\zeta}\Omega = (n+1)\Omega$ .

# <span id="page-12-0"></span>3.1.3 Log Del Pezzo surface

There is another way of using algebraic geometry to study positive Sasakian manifold (We focus on Sasakian five manifold in this part). Sasakian manifold has a Reeb vector field  $\zeta$ , and it always admit a quasi-regular Sasakian structure. This implies that the corresponding affine ring X has a rational  $C^*$  action. The above properties make it possible to associate a projective variety  $S = X/\{0\}/C^*$  with cyclic quotient singularity. There is also a natural Q divisor  $\Delta = \sum (1 - \frac{1}{m_i})D_i$  on S, where  $D_i$  is a divisor such that the stabilizer of  $C^*$  action on  $D_i$  has order  $m_i$ . The positivity of the Sasakian structure is equivalent to following condition on S:

$$-(K_S + \Delta)$$
 is ample. (3.22)

Here ample means that  $-(K_S + \Delta) \cdot C > 0$  for any irreducible curve C. Given a pair  $(S, \Delta)$ , the Sasakian structures are specified by the following data:

- 1. Integers  $0 \le b_i < m_i$  and  $b_i$  is co-prime with  $m_i$ .
- 2. A class of Weyl divisor B.

From these data on S, one can define a ring and recover X:

$$R(B, \sum \frac{b_i}{m_i}) = \sum_j \mathcal{O}_X(jB + \sum \left[\frac{jb_i}{m_i}\right]D_i),$$

$$X = Spec_S R(B, \sum \frac{b_i}{m_i}).$$
(3.23)

The map X → (S, ∆) is called a Seifert structure [\[11\]](#page-48-9). The Chern class of the Seifert structure is defined as

$$CS(X/S) = B + \sum_{i} \frac{b_i}{m_i}.$$
(3.24)

Given a pair (S, ∆), we can define the following integer numbers:

$$m(x, \Delta) = \text{lcm}(m_i | x \in D_i),$$
 (3.25)  
 $m(\Delta) = lcm(m_i).$ 

These number plays a crucial role in determining the smooth Seifert structure: we have a smooth Seifert structure if m(x, ∆) ∗ C(X/S) is a generator of local class group at x.

So one can get a positive Sasakian manifold from following data:

$$(S, \Delta = \sum_{i} (1 - \frac{1}{m_i})D_i), B + \sum_{i} \frac{b_i}{m_i}D_i)$$
(3.26)

Here B is a Weyl divisor, 0 ≤ b<sup>i</sup> < m<sup>i</sup> and is coprime with m<sup>i</sup> , −(K<sup>S</sup> + P i (1 − 1 m<sup>i</sup> )Di) is ample. Smooth of M gives further constraint on b<sup>i</sup> and B.

# <span id="page-13-0"></span>3.2 Sasaki-Einstein manifold

We are now looking for a (2n + 1) dimensional Sasakian manifold which is also Einstein

$$R_{ij} = \lambda g_{ij}. (3.27)$$

We are interested in the case where λ is positive, and in this case, the constant is equal to 2n. This is equivalent to the following condition

- 1. The conic metric g = dr<sup>2</sup> + r <sup>2</sup>dg<sup>M</sup> is Ricci flat.
- 2. In the quasi-regular case, it implies that the orbifold Kahler metric on the base is Kahler-Einstein with constant curvature 4n(n+1), and the Einstein constant is 2n+2.
- 3. The transverse Kahler metric g<sup>T</sup> is Einstein with Einstein constant (2n + 2).

Let's fix the Reeb vector field ζ, and the space of Sasaki-Einstein metric with fixed ζ might be called the moduli space of Sasaki-Einstein metric. Little is known about this space though.

# <span id="page-14-0"></span>3.2.1 Comments on spin structure

Not all Sasakian manifold admits spin structure, and there is also Sasaki-Einstein manifold which does not have a spin structure. For a simply connected SE manifold, there is always a spin structure though.

One might wonder whether these non-spin SE manifold can play any role in string theory. In fact, they are also quite useful, and an important example is RP<sup>5</sup> whose associated cone is C <sup>3</sup>/Z<sup>2</sup> with <sup>Z</sup><sup>2</sup> action acts as reflection (−1, <sup>−</sup>1, <sup>−</sup>1), so <sup>Z</sup><sup>2</sup> is not a finite subgroup of SU(3). RP<sup>5</sup> does not admit spin structure, but it is quite useful to describe the gravity dual of SO(N) and Sp(N) N = 4 SYM theory. Although not every Sasakian manifold admits spin structure, they all admit Spin<sup>c</sup> structure [\[26](#page-49-6)], so one could still work with spinors. Since in the RP<sup>5</sup> case, one need to study the orientifold of IIB string theory, and also the discrete torsion of B field is important. We also expect that one need to study orientifold and discrete torsion for these non-spin SE manifold. A useful observation is that non-simply connected SE manifold are derived from abelian quotient of rational Gorenstein singularity and therefore admit a finite abelian group action. It is interesting to further study IIB string construction on these non-spin SE manifolds.

A simply connected Sasaki-Einstein manifold admits at least two real Killing spinor, and the cone X admits two parallel spinors.

# <span id="page-14-1"></span>3.3 K stability and Sasaki-Einstein metric

We focus on Sasakian five manifold in this section. Given a log terminal singularity X with a C <sup>∗</sup> action ζ, the question is to determine whether the link L<sup>5</sup> has Sasaki-Einstein metric. This question is reduced to studying the K-stability of the ring X [\[5](#page-48-3)]. In this subsection, we will discuss two crucial ingredients of K-stability; test configuration and the Futaki invariant. The physical interpretation of K stability has been given in [\[27\]](#page-49-7). K stability works for all log terminal singularity, not necessarily isolated singularity, in fact, in many cases it is crucial to consider test configuration involving non-isolated singularity.

#### <span id="page-14-2"></span>3.3.1 New ring with extra C <sup>∗</sup> action

Let's first describe the definition of a test configuration arising in K stability. Let's start with a 3-fold log terminal singularity with a C <sup>∗</sup> action. In the K-stability context, one constructs a test configuration by constructing a flat family <sup>π</sup> : X → <sup>C</sup> (for a simple illustration of flat and non-flat family, see figure. [1.](#page-15-1)). This flat family is generated by a one dimensional symmetry generator η, and for t 6= 0, the ring corresponding to the fiber X<sup>t</sup> = π −1 (t) is isomorphic to the original ring X. At t = 0, the ring might degenerates into a different ring which we call X0, and it is also called central fibre of a test configuration.

The flat limit is a quite common concept in algebraic geometry, but its definition is quite involved and we do not want to give a detailed introduction here. Here, we just want to point out several important features of the flat family constructed above.

(a) The Hilbert series is not changed if we use the same symmetry generator for the new ring X0. In particular, X<sup>0</sup> has the same dimension as X.

(b) The maximal torus in the automorphism group of the central fibre X<sup>0</sup> has one more dimensional symmetry generated by η, unless X<sup>0</sup> ∼= X.

We require that the degeneration is normal (which implies that the codimension of the singular locus is at less than two). The new singularity X<sup>0</sup> in the non-trivial case, possesses an extra one-dimensional symmetry.

![](_page_15_Picture_2.jpeg)

Figure 1. Left: A flat family of rings. At t 6= 0, there are two points and the configuration degenerates into one point at t = 0, which is the central fibre of this flat limit. Right: A non-flat family of rings. At t 6= 0, the ring is zero dimensional, but at t = 0, the ring is one dimensional.

<span id="page-15-1"></span>Example: Consider the ring X defined by the ideal x <sup>2</sup>+y <sup>2</sup>+z <sup>2</sup>+w <sup>k</sup> = 0, and consider a C <sup>∗</sup> action η which acts only on coordinate w with the action η(w) = tw. We then get a family of rings parametrized by the coordinate t:

$$x^2 + y^2 + z^2 + t^k w^k = 0. (3.28)$$

The flat limit of this family over t = 0 is found (in this case) by keeping the terms with lowest order. The central fiber of this test configuration is then cut out by the equation

$$x^2 + y^2 + z^2 = 0. (3.29)$$

Notice that lη with l > 0 gives the same degeneration limit X0. On the other hand lη with l < 0 gives a different degeneration limit– we get the ring generated by the ideal w <sup>k</sup> = 0, which is not normal!

# <span id="page-15-0"></span>3.3.2 Futaki invariant

Now let's start with a ring X with a Sasakian C <sup>∗</sup> action ζ, and we also choose the generators ti , i = 1, . . . , n for the Lie algebra t of the maximal torus in the automorphism group G of X. We also have a canonical top form Ω which is the section of the sheaf associated with canonical divisor K<sup>X</sup> , and this section is chosen to have definite weight under C <sup>∗</sup> action. Let us write ζ = P<sup>n</sup> <sup>i</sup>=1 ζit<sup>i</sup> . Consider a test configuration X generated by a symmetry generator η and let X<sup>0</sup> denote the central fibre. We would like to determine whether or not X<sup>0</sup> destabilizes X. The crucial ingredient is Donaldson-Futaki invariant defined in [\[28](#page-49-8)].

The ring (X0, ζ, η) is still log terminal, and has a at least two dimensional symmetry group generated by ζ and η. We impose the following two conditions:

- (a) The charge on the coordinates  $x_i$  is positive.
- (b) The (3,0) form  $\Omega$  has charge  $2^6$ .

Hilbert series on ring  $X_0$  with respect a  $C^*$  action  $x\zeta + y\eta$  is defined as

$$H(t) = \sum t^{\alpha(x\zeta + y\eta)} dim H_{\alpha(x\zeta + y\eta)}.$$
 (3.30)

here  $H_{\alpha}$  is the subspace of ring X with charge  $\alpha$  under action  $x\zeta + y\eta$ . If we take  $t = e^{-s}$ , and we have the following expansion [29]:

$$H(e^{-s}) = \frac{a_0(x\zeta + y\eta)}{s^3} + \frac{a_1(x\zeta + y\eta)}{s^2} + \dots$$
 (3.31)

The second condition can be fixed by computing the Hilbert series of  $X_0$  with respect to symmetry generator and imposing the condition  $a_0 = a_1$ , so we get a one dimensional space of Reeb vector field.  $a_0$  is proportional to the volume of the link  $L_X$ . Let's try following parameterization of one dimensional Reeb vector field:

$$\zeta(\epsilon) = \zeta + \epsilon(\eta - a\zeta). \tag{3.32}$$

Notice that we require  $\epsilon > 0$  so that the central fibre is the same as the original one if we use the symmetry  $\epsilon(\eta - a\zeta)$  to generate the test configuration. Substitute the above parameterization into the equation  $a_0 = a_1$  (computed using new ring  $X_0$ ) and expand it to first order in  $\epsilon$ , we have

$$a_0(\zeta + \epsilon(\eta - a\zeta)) = a_1(\zeta + \epsilon(\eta - a\zeta)) \rightarrow a_0(\zeta) + \epsilon(\eta - a\zeta) \cdot a_0' = a_1(\zeta) + \epsilon(\eta - a\zeta) \cdot a_1'. \quad (3.33)$$

Here  $a_0'$  and  $a_1'$  are the vectors defined by the derivative  $\frac{da_i(\vec{x})}{d\vec{x}}|_{\vec{x}=\zeta}$ , and  $\vec{x}=\sum_{i=1}^n s_i t_i + b\eta$ . Using the result  $a_0(\zeta)=a_1(\zeta)$ , we have

<span id="page-16-1"></span>
$$a = \frac{\eta \cdot (a_0' - a_1')}{\zeta \cdot (a_0' - a_1')} = \frac{\eta \cdot (a_1' - a_0')}{a_0} = \frac{1}{a_0(\zeta)} \left( \frac{da_1(\zeta + \epsilon \eta)}{d\epsilon} - \frac{da_0(\zeta + \epsilon \eta)}{d\epsilon} \right) |_{\epsilon = 0}.$$
 (3.34)

We also use the fact  $\zeta \cdot a_0' = 3a_0(\zeta)$ ,  $\zeta \cdot a_1' = 2a_1(\zeta) = 2a_0(\zeta)$ . Now the Futaki invariant is defined to be

$$F(X,\zeta,\eta) = D_{\epsilon}a_0(\zeta(\epsilon))|_{\epsilon=0}. \tag{3.35}$$

This definition is not of the form of the original Futaki invariant defined in [28], however, we will now show that our definition is equivalent to the original one (see also [5] for more discussion). We have

$$F(X,\zeta,\eta) = D_{\epsilon}a_{0}(\zeta + \epsilon(\eta - a\zeta)) = (\eta - a\zeta) \cdot a_{0}'$$

$$= D_{\epsilon}a_{0}(\zeta + \epsilon\eta) - \frac{\eta \cdot (a_{0}' - a_{1}')}{a_{0}} D_{\epsilon}a_{0}(\zeta + \epsilon\zeta)$$

$$= D_{\epsilon}a_{0}(\zeta + \epsilon\eta) + 3a_{0}(\zeta) \frac{\eta \cdot (a_{0}' - a_{1}')}{a_{0}}$$

$$= D_{\epsilon}a_{0}(\zeta + \epsilon\eta) + 3a_{0}(\zeta) D_{\epsilon} \frac{a_{1}(\zeta + \epsilon\eta)}{a_{0}(\zeta + \epsilon\eta)}.$$
(3.36)

<span id="page-16-0"></span><sup>&</sup>lt;sup>6</sup>The holomorphic Reeb vector field has charge three on  $\Omega$ , but here we use a normalization so that the charge is the  $U(1)_R$  charge.

We use the definition from first line to second line, and from second line to third line we use the fact  $D_{\epsilon}a_0(\zeta + \epsilon \zeta) = -3a_0(\zeta)$  (which can be found using the definition of Hilbert series). The formula in the last line is precisely the Futaki invariant defined in [5]. Having defined the Futaki invariant, we can now state the definition of K-stability.

**Theorem 1** A polarized ring  $(X, \zeta)$  is stable if for any non-trivial test configuration generated by the symmetry  $\eta$ , the Futaki invariant satisfies

$$F(X,\zeta,\eta) > 0. (3.37)$$

And for the trivial test configuration, namely the central fibre  $X_0$  is the same as X, the Futaki invariant satisfies

$$F(X,\zeta,\eta) \ge 0. \tag{3.38}$$

![](_page_17_Figure_5.jpeg)

<span id="page-17-0"></span>**Figure 2.** Three situations for Futaki invariant. F > 0:  $a_0(\epsilon) > a(0)$  for  $\epsilon > 0$ ; F = 0: the minima of  $a_0$  is achieved at  $\epsilon = 0$ ; F < 0: the minima of  $a_0$  is achieved for  $\epsilon > 0$ . Notice that we only need to look at  $a_0$  for  $\epsilon > 0$ .

See figure. 2 for the behavior of  $a_0(\epsilon)$  with respect to  $\epsilon$ , and it is clear that if F < 0, minimal of  $a_0$  is achieved for  $\epsilon > 0$ , which implies that the volume of  $X_0$  is smaller than X. So K stability can be interpreted as the generalized volume minimization.

**Example**: Consider the ring X which is generated by the ideal  $x^2 + y^2 + z^2 + w^k = 0$ , this ring has a symmetry  $\zeta$  with charge  $(\frac{2k}{k+2}, \frac{2k}{k+2}, \frac{2k}{k+2}, \frac{4}{k+2})$  on coordinates (x, y, z, w). This symmetry is chosen such that the (3,0) form  $\Omega = \frac{dx \wedge dy \wedge dz \wedge dw}{df}$  has charge two. The Hilbert series for  $\zeta$  is

$$Hilb(X,\zeta,t) = \frac{1 - t^{\frac{4k}{k+2}}}{\left(1 - t^{\frac{4}{k+2}}\right)\left(1 - t^{\frac{2k}{k+2}}\right)^3}.$$
 (3.39)

Expand around t=1, we find  $a_0(\zeta)=a_1(\zeta)=\frac{(2+k)^3}{8k^2}$ . Now consider the test configuration generated by the symmetry  $\eta$  with charges (0,0,0,1). In this case, the central fibre  $X_0$  is

generated by the ideal  $x^2 + y^2 + z^2 = 0$ . Using formula (3.34), the one parameter possible  $U(1)_R$  symmetry is

$$\zeta(\epsilon) = \zeta + \epsilon(\eta - \frac{1}{2}\zeta). \tag{3.40}$$

The Hilbert series with respect to above symmetry is

$$Hilb(X_0, \zeta(\epsilon), t) = \frac{1 - t^{(1 - \frac{\epsilon}{2}) \frac{4k}{k+2}}}{(1 - t^{(1 - \frac{\epsilon}{2}) \frac{2k}{k+2}})^3 (1 - t^{(1 - \frac{\epsilon}{2}) \frac{4}{k+2} + \epsilon)})}.$$
 (3.41)

Substituting t = exp(-s) and expand the Hilbert series around s = 0, we get

$$a_0(\zeta(\epsilon)) = a_1(\zeta(\epsilon)) = \frac{2(k+2)^3}{(\epsilon-2)^2 k^2 (\epsilon k + 4)}.$$
 (3.42)

The Futaki invariant is computed as

$$F = D_{\epsilon} a_0(\zeta(\epsilon))|_{\epsilon=0} = \frac{(4-k)(k+2)^3}{32k^2}.$$
 (3.43)

So  $F \leq 0$  for  $k \geq 4$ . Since  $X_0$  is clearly not isomorphic to X, we conclude that  $X_0$  destabilizes X for  $k \geq 4$ .

#### <span id="page-18-0"></span>3.3.3 Some discussions

Checking K-stability involves two steps. First, finding a test configuration and then computing the Futaki invariant. While the computation of Futaki invariant is straightforward, the set of possible test configurations is in principle infinite. Thus, in order to check K-stability one needs to reducing the sets of possible test configurations. There are several simplifications we can make:

- The first simplification has already been used, namely we require that the central fibre to be normal.
- Assume that the symmetry group of the ring X is G, then one only need to consider the flat families generated by a symmetry which commutes with G [5, 30]. This fact is quite useful for singularities with many symmetries. In particular, if the variety has three dimensional symmetries (or in other words, X is toric), then there are no non-trivial test configurations, and hence checking stability reduces to volume minimization (or a-maximization).

# <span id="page-18-1"></span>4 Examples

In this section, we are going to study several class of isolated three dimensional rational Gorenstein singularity with a  $C^*$  action. The link of such singularity will carry a positive Sasakian structure. We then study the constraints such that there is a SE metric. To begin with, we will first review the topological constraint which obstructs the existence of positive Sasakian structure on simply connected five manifold. We then study the link of toric singularity, complete intersection singularity, quotient singularity and finally study five dimensional SE manifold from two dimensional log del Pezzo surface point of view.

# <span id="page-19-0"></span>4.1 Simply connected Sasakian five manifold

In general, it is not possible to classify five manifold under diffeomorphism. However, simply connected five manifold has been given a classification by Smale and Barden [18]. They are specified by torsion subgroup  $H_2(M_5, Z)$  and an invariant i(M), see table. 3 for the basic building block. i(M) = 0 implies that the manifold is a spin manifold. The class B of simply connected, closed, smooth, 5-manifolds is classifiable under diffeomorphism. Furthermore, any such M is diffeomorphic to one of the spaces:

$$M_{i:k_1,\dots,k_s} = X_i \# M_{k_1} \# \dots \# M_{k_s},$$
 (4.1)

where  $-1 \le j \le \infty$ ,  $1 < k_1$  and  $k_i$  divides  $k_{i+1}$  or  $k_{i+1} = \infty$ . Here

| M                             | $H_2(M,Z)$             | i(M)     |
|-------------------------------|------------------------|----------|
| $M_{-1} = SU(3)/SO(3)$        | $Z_2$                  | 1        |
| $M_1 = X_0 = S^5$             | 0                      | 0        |
| $X_j, 0 < j < \infty$         | $Z_{2j} \oplus Z_{2j}$ | j        |
| $X_{\infty}$                  | Z                      | $\infty$ |
| $M_k, 1 < k < \infty$         | $Z_k \oplus Z_k$       | 0        |
| $M_{\infty} = S^2 \times S^3$ | Z                      | 0        |

<span id="page-19-1"></span>**Table 3**. Basic simply connected five manifolds.

The torsion subgroup of these simply connected manifolds which admit positive Sasakian structure is constrained. This result is proven by Kollar [11] using minimal model program. Recall that each quasi-regular positive Sasakian five manifold gives a two dimensional log del Pezzo surface  $(S, \sum (1 - \frac{1}{m_i})D_i)$ , here S has cyclic quotient singularity. Such S is rational and one can use minimal model program to constrain the topology of  $D_i$ . The minimal model program goes as follows: we first start with a log Del Pezzo surface S and resolve the singularity, we then do the minimal model program and get a minimal rational surface which are  $P^2, P^1 \times P^1$  and Hirzbruch surfaces  $F_n$ . After a case by case analysis, it is proven in [11] that:

1. There is only one  $D_i$  with  $g(D_i) \geq 1$ . Assume  $D_0$  has genus bigger than 0 and  $(1 - \frac{1}{m_0}) \geq \frac{1}{2}$ , then we have

$$g(D_0) = 1 \text{ if } (1 - \frac{1}{m_0}) \ge \frac{5}{6},$$

$$g(D_0) = 2 \text{ if } (1 - \frac{1}{m_0}) \ge \frac{3}{4},$$

$$g(D_0) = 4 \text{ if } (1 - \frac{1}{m_0}) \ge \frac{2}{3}.$$

$$(4.2)$$

2. One can compute the homology and cohomology group of the five dimensional Sasakian manifold M from the data on the base  $(S, \Delta)$ . Let  $f: M^5 \to (S, \Delta = \sum_i (1 - \frac{1}{m_i})D_i)$ 

to be a smooth Seifert bundle over a projective surface with cyclic quotient singularity. Set s = b2(S) and assume that Horb 1 (S, Z) = 0 [7](#page-20-1) [8](#page-20-2). Then the integral cohomology groups H<sup>i</sup> (M<sup>5</sup> , Z) are

| i            | 0 | 1 | 2                | 3                                           | 4  | 5 |
|--------------|---|---|------------------|---------------------------------------------|----|---|
| Hi<br>(M, Z) | Z | 0 | s−1 ⊕<br>Z<br>Zd | 2g(Di)<br>s−1 ⊕<br>P<br>Z<br>(Zmi<br>)<br>i | Zd | Z |

here d is the largest natural number such that m(∆)c1(Y /S) ∈ Cl(S) is divisible by d (see the definitions in section [3.1.3\)](#page-12-0), and g(Di) is the genus of divisor D<sup>i</sup> . One can find the homology group by looking at the dual of above cohomology groups. Because of the constraint presented in 1, the torsion subgroup H2(M, Z) is one of the following:

$$(Z_m)^2$$
,  $(Z_5)^4$ ,  $(Z_4)^4$ ,  $(Z_3)^4$ ,  $(Z_3)^6$ ,  $(Z_3)^8$ ,  $(Z_2)^{2n}$ . (4.3)

The torsion subgroup of non-simply connected Sasakian five manifold is further studied in [\[31](#page-49-11)].

# <span id="page-20-0"></span>4.2 Toric singularity

Let's start with a tree dimensional standard lattice N, and its dual lattice M = Hom(N, Z). A rational convex polyhedral cone σ is defined by a set of lattice vectors {v1, . . . , vn} as follows:

$$\sigma = \{r_1 v_1 + r_2 v_2 + \ldots + r_n v_n | r_i \ge 0\}$$
(4.4)

Its dual cone σ <sup>∨</sup> is defined by the set in M<sup>R</sup> such that

$$\sigma^{\vee} = \{ \langle w | v \rangle \ge 0 | w \in M_R, v \in \sigma \}. \tag{4.5}$$

here we use the standard pairing between two lattices N and M. A ray generator v<sup>ρ</sup> of σ is a lattice vector, such that it is not a multiple of another lattice vector of σ. From σ ∨, one can define a semi-group S = σ <sup>∨</sup> <sup>∩</sup> <sup>M</sup>, and the affine variety associated with <sup>σ</sup> is

$$X_{\sigma} = Spec(\sigma^{\vee} \cap M). \tag{4.6}$$

We have the following further constraints on the cones:

• A strongly rational convex polyhedral cone (s.r.c.p.c) is a convex cone σ such that σ ∩ (−σ) = 0.

- <span id="page-20-2"></span>• H1(S 0 , Z) = 0, here S 0 is the smooth part of S.
- The map H2(S, Z) → P <sup>j</sup> Z/m<sup>j</sup> given by L → (L · D<sup>j</sup> ) mod m<sup>j</sup> is surjective.

<span id="page-20-1"></span><sup>7</sup>The pair (X, ∆) can be interpreted as an orbifold. For an orbifold (X, ∆), the orbifold fundamental group π orb <sup>1</sup> is the fundamental group of X/(SingX ∪ Supp∆) modulo the relations: if γ is any small loop around D<sup>i</sup> at a smooth point then γ <sup>m</sup><sup>i</sup> = 1. The abelianization of π orb <sup>1</sup> is denoted by H orb <sup>1</sup> (X, ∆), called the abelian orbifold fundamental group.

<sup>8</sup>Let S be a normal, projective surface with rational singularities. Then H orb <sup>1</sup> (X, ∆) = 0 if and only if

• A simplicial s.r.c.p.c is a cone whose generator form a R basis of N.

We are interested in affine toric singularity which is defined by a cone  $\sigma$ . The singular locus of affine toric singularity is given by the sub-cone  $\sigma_i$  whose generators do not form a Z-basis, and the singular locus corresponds to the orbit which is determined by  $\sigma_i$ . For 3-fold toric singularity, the maximal dimension of singular locus is one dimensional which is then formed by a two dimensional sub-cone  $\sigma_i$  in  $\sigma$ .

A toric singularity is Q-Gorenstein if one can find a vector  $m_{\sigma}$  in  $M_Q$  such that  $\langle m_{\sigma}, v_{\rho} \rangle = 1$  for all the one dimensional generator  $v_{\rho}$  of  $\sigma$ . A toric singularity is Gorenstein if one can find a vector H in the lattice M such that  $\langle H, v_{\rho} \rangle = 1$ . Equivalently, one can choose a hyperplane in N such that all the ray generators lie on it. For a 3-fold Q-Gorenstein singularity with index r, we take the hyperplane as z = r, and the ray generators form a two dimensional convex polygon P. Our 3-fold Q-Gorenstein toric singularity is then specified by an index r and a two dimensional convex polygon P. The classification of 3-fold canonical and terminal singularity are classified as follows:

- The cone  $\sigma$  of 3-fold **canonical** singularity has the following property: there is no lattice points in  $\sigma$  between the origin and the polygon P. In particular, toric Gorenstein singularity is canonical.
- The cone  $\sigma$  of 3-fold **terminal** singularity is characterized as follows: there is no lattice points in  $\sigma$  between the origin and the polygon P, and furthermore there is no internal lattice points and boundary lattice points for P.

We focus on isolated toric Gorenstein 3-fold singularity  $X_P$  which is specified by a convex polygon P with no lattice points on the boundary. The homology of the link  $L_X$  is easy to compute. We ahve  $\pi_1(L_X) = Z_3/\Gamma$ , with  $\Gamma$  the subgroup generated by the lattice vectors  $v_\rho$ ;  $H_2(L_X, Z)$  has no torsion, and  $b_2 = n - 3$  with n the number of vertices of P.  $H_3(L_X, Z)$  could have torsion though. Simply connected toric Sasakian manifold is just  $S^5 * k(S^2 \times S^3)$ .

It was proven in [7] that the link associated with an isolated toric Gorenstein singularity admits Sasakian-Einstein metric. The corresponding Reeb vector field  $\zeta$  can be determined using volume minimization [32].

#### <span id="page-21-0"></span>4.3 Hypersurface singularity

Let's consider a three dimensional isolated hypersurface singularity defined by the map  $f:(C^4,0)\to(C,0)$ . Isolated condition implies that equations  $f=\frac{\partial f}{\partial z_i}=0$  has a unique solution at the origin. We also require that there is an effective  $C^*$  action on the singularity:

<span id="page-21-1"></span>
$$f(\lambda^{q_i} z_i) = \lambda f(z_i), \quad q_i > 0. \tag{4.7}$$

Hypersurface singularity is Gorenstein, and the rational condition implies that

<span id="page-21-2"></span>
$$\sum q_i - 1 > 0. \tag{4.8}$$

All such rational hypersurface singularities have been classified in [22]. One define a five dimensional link  $L_f$  of the singularity as the intersection with the standard five sphere:

$$L_f = X_f \cap S^5. \tag{4.9}$$

Then  $L_f$  has a positive Sasakian structure for f satisfying condition 4.7 and 4.8.

The topology of  $L_f$  has been studied in mathematics literature, see [8]. We'd like to compute its homology group. One can define the Milnor fibration of the singularity. Let  $\epsilon > 0$  to be sufficiently small. The map  $\phi : S_{\epsilon}^5/L_f \to S^1$  defined by

$$\phi(z) = \frac{f(z)}{|f(z)|},\tag{4.10}$$

is the projection map of a smooth fiber bundle with a smooth parallelizable fibre, and each fibre F has the homotopy type of a bouquet of three spheres  $S^3 \vee ... \vee S^3$ , and is homotopy equivalent to its closure  $\bar{F}$  which is a compact manifold with boundary, where the common boundary  $\partial \bar{F}$  is precisely  $L_f$ . Furthermore,  $L_f$  is a smooth 1-connected manifold of dimension 5, i.e., only  $b_0, b_2, b_3, b_5$  are nonzero. In particular,  $L_f$  is simply connected.

**Definition**: A 5 dimensional manifold is called **homology** sphere if it has the same integral homology type as sphere:  $H_0(M, Z) = H_5(M, Z) = 1, H_i(M, Z) = 0, i \neq 0, 5$ . The homotopy group of homology sphere might be different from standard sphere. A **rational homology** sphere is defined similarly using rational coefficient instead of integer coefficient in homology group. A sphere is called **homotopy** sphere if it has the same homotopy type as standard sphere.

We would like to compute the Betti number and torsion part of homology group of the link  $L_f$ . The topology of the link is encoded by the following important exact sequence (here F is the Milnor fibre, and  $h_*$  is the monodromy group):

$$0 \to H_3(L_f, Z) \to H_3(F, Z) \xrightarrow{1-h_*} H_3(F, Z) \to H_2(L_f, Z) \to 0. \tag{4.11}$$

From this, we see that

- $H_3(L_f, Z) = ker(1 h_*)$  is a free abelian group.
- $H_2(L_f, Z) = coker(1 h_*)$  and in general it has torsion.

The free part of the homology is encoded in the Alexander polynomial:

$$\Delta(t) = \det(tI - h_*), \tag{4.12}$$

and there is an effective way to compute it. Let's start with an isolated rational hypersurface singularity with a  $C^*$  action, we can choose the integral weights  $(w_0, w_1, w_2, w_3)$  which has no common divisor, and the polynomial f has weight d instead of 1. Let's define the new set of rational numbers  $(\frac{d}{w_0}, \frac{d}{w_2}, \dots, \frac{d}{w_3}) = (\frac{u_0}{v_0}, \dots, \frac{u_n}{v_3})$ , here  $u_i$  and  $v_i$  has no common divisor. We have

$$b_2(L_f) = \sum (-1)^{4-s} \frac{u_{i_1} \dots u_{i_s}}{v_{i_1} \dots v_{i_s} \operatorname{lcm}(u_{i_1} \dots, u_{i_s})}$$
(4.13)

with the summation over 16 subsets  $(i_1, \ldots, i_s)$  of  $(0, \ldots, 3)$ .

**Example 1**: Consider the singularity  $f = z_0^2 + z_1^2 + z_2^2 + z_3^2$ , then we have  $(w_0, w_1, w_2, w_3) = (1, 1, 1, 1)$ , d = 2 and u = (2, 2, 2, 2), v = (1, 1, 1, 1). Then we have the subset  $\emptyset$ , (0), (1), (2), and (01), (02), (03), (12), (13), (23), (012), (013), (023), (123), (0123). Using above formula, we find

$$b_2 = 1 - 4 + 2 * 6 - 4 * 4 + 8 = 1. (4.14)$$

**Example 2:** Consider the singularity  $f = z_0^2 + z_1^2 + z_2^2 + z_3^3$ , then the weights are  $(w_0, w_1, w_2, w_3) = (3, 3, 3, 2), d = 6$ , so u = (2, 2, 2, 3) and v = (1, 1, 1, 1), we find

$$b_2 = 1 - 4 + 3 * 3 - 14 + 4 = 0. (4.15)$$

The computation of torsion part of the homology is much more non-trivial, and here let's explain the formula of how to compute it. Given an index set  $(i_1, \ldots, i_s)$ , we will denote by I all its  $2^s$  subsets and by J all its proper subsets. For each ordered subset  $(i_1, \ldots, i_s) \subset (1, \ldots, 4)$  with  $i_1 < i_2 < \ldots < i_s$ , one defines inductively the set of  $2^s$  positive integers, starting with  $C_0 = \gcd(u_0, \ldots, u_n)$ :

$$c_{i_1,\dots,i_s} = \frac{\gcd(u_0,\dots,\hat{u_{i_1}},\dots,\hat{u_{i_s}},\dots,u_n)}{\prod_{I} c_{j_1\dots j_t}}.$$
(4.16)

In addition, starting with  $k_0 = \epsilon_4$ , one defines

$$k_{i_1,\dots,i_s} = \epsilon_{4-s+1} \sum_{I} (-1)^{s-t} \frac{u_{j_1} \dots u_{j_t}}{v_{j_1} \dots v_{j_t} lcm(u_{j_1},\dots,u_{j_t})}$$
(4.17)

where  $\epsilon_{4-s+1} = 0(1)$ , if 4 - s + 1 is even (odd).

Now for any  $1 \leq j \leq r = [max(k_{i_1,...,i_s})]$ , we set

$$d_j = \prod_{k_{i_1...i_s \ge j}} c_{i_1,...,i_s} \tag{4.18}$$

The Orlik conjecture [33] states that the torsion subgroup of  $H_2$  is

$$H_2(L_f, z)_{tor} = Z_{d_1} \bigoplus Z_{d_2} \dots \bigoplus Z_{d_r}. \tag{4.19}$$

**Example**: The singularity is  $f = z_0^2 + z_1^3 + z_2^5 + z_2 z_3^3$ . The weights are (15, 10, 6, 8) and degree is 30. So we have u = (2, 3, 5, 15), v = (1, 1, 1, 4). We have

$$c_{(0)} = 1; c_{(1)} = 1, c_{(2)} = 1, c_{(3)} = 1, c_{(4)} = 1; c_{(12)} = 5, c_{(13)} = 3, c_{(14)} = 1, c_{(23)} = 1, c_{(24)} = 1$$

$$c_{(34)} = 1, c_{(123)} = 1, c_{(124)} = 1, c_{(134)} = 1, c_{(234)} = 2, c_{(1234)} = 1$$

$$(4.20)$$

For the number ks, we get

$$k = (0, 0, 0, 0, -(3/4), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,$$

So we have

$$d_1 = 2, d_2 = 2$$
 (4.22)

and  $H_2(M, Z)_{tor} = Z_2 \bigoplus Z_2$ .

For the singularity of the form  $f = z_0^{a_0} + \ldots + z_3^{a_3}$ , there is an easier way to compute the homology groups. To each polynomial with data  $(a_0, \ldots, a_3)$ , associate a graph G(a) whose vertices are labelled by  $a_0, \ldots, a_3$ . Two vertices  $a_i$  and  $a_j$  are connected if and only if  $gcd(a_i, a_j) > 1$ . Let  $G_{ev}(a) \in G(a)$  denote the connected component of G(a) determined by the **even** integers. Then the following holds

- The link L(a) is a rational homology sphere if and only if either G(a) contains at least one isolated point, or  $G_{ev}(a)$  has an odd number of vertices and for any distinct  $a_i, a_j \in G_{ev}(a), gcd(a_i, a_j) = 2.$
- The link L(a) is a homology sphere if and only if either G(a) contains at least two isolated points, or G(a) contains one isolated point and  $G_{ev}(a)$  has an odd number of vertices and for any distinct  $a_i, a_j \in G_{ev}(a), gcd(a_i, a_j) = 2$ .

Since  $L_f$  is simply connected, and we can identify it as one of Smale-Barden manifolds once we computed the homology groups of the link  $L_f$ ,

Having discussed the topological computation of the link associated with the hypersurface singularity. We would like to determine whether there will be SE metric. Let's now consider the implication of K stability on the existence of SE metric on the link L. It is difficult to construct all test configurations, but it is always possible to generate one type test configuration whose consequence is just the unitarity bound from field theory perspective [34, 35]. Let L(w,d) be a link of a weighted homogeneous hypersurface with weight vector  $w = (w_0, w_1, w_2, w_3)$  ordered as  $w_0 \le w_1 \le w_2 \le w_3$ , the generator of canonical bundle is

$$\Omega = \frac{dx_0 \wedge dx_1 \wedge dx_2 \wedge dx_3}{df},\tag{4.23}$$

and it has weight  $\sum w_i - d$ . The normalization of the  $C^*$  action is that  $\Omega$  has charge two. So the  $C^*$  charge of coordinate  $x_i$  is  $\frac{2w_i}{\sum w_i - d}$ . The K stability implies that

<span id="page-24-0"></span>
$$\frac{2w_i}{\sum w_i - d} \ge \frac{2}{3}.\tag{4.24}$$

The above constraint is a necessary condition for the existence of SE metric on the link. It is also sufficient for the singularity  $f = z_0^{a_0} + z_1^{a_1} + z_2^{a_2} + z_3^{a_3}$  if the exponents  $a_i$  are pairwise coprime. We also have many other results by using K stability and sufficient conditions:

• Let L(w,d) be a link of a weighted homogeneous hypersurface with weight vector  $w = (w_0, w_1, w_2, w_3)$  ordered as  $w_0 \le w_1 \le w_2 \le w_3$ . Let  $Z_w$  denotes the corresponding weighted projective space. Furthermore let  $I = \sum w_i - d$  denote the Fano index. Then (1): The 5-manifold L(w,d) admits a Sasaki-Einstein manifold if  $2Id < 3w_0w_1$ ; 2) if the line  $z_0 = z_1 = 0$  does not lie in  $Z_w$ , and a weaker condition  $2Id < 3w_0w_2$  holds, then L(w,d) admits a Sasaki-Einstein metric; (3) If the point (0,0,0,1) does not lie in  $Z_w$ , and even weaker condition  $2Id < 3w_0w_3$  holds, then L(w,d) admits a Sasaki-Einstein metric. Using this result, many SE manifold has been found in [36].

- If L(w,d) admits a  $T^2$  action, we have following results [5]:
  - (1):  $uv + z^p + w^q = 0 \to 2p > q \text{ and } 2q > p$ ,
  - (2):  $uv + z^p + zw^q = 0 \rightarrow 3(p-1) > (q+p-1)$  and  $2qp+1 > p^2 + q$ ,

(3): 
$$uv + z^p w + zw^q = 0 \to 3(p-1)^2(q-1) > (p+q-2)(pq-2p+1)$$
  
and  $3(q-1)^2(p-1) > (p+q-2)(pq-2q+1)$  (4.25)

The topology of them is respectively (1):  $m(S^2 \times S^3)$  with  $m = \gcd(p,q) - 1$ ; 2)  $m(S^2 \times S^3)$  with  $m = \gcd(p-1,q)$ ; 3)  $m(S^2 \times S^3)$  with  $m = \gcd(p-1,q-1) + 1$ .

• If L(w,d) admits a  $T^3$  action, there is no obstruction. The only example we know is conifold singularity  $x_1^2 + x_2^2 + x_3^2 + x_4^2 = 0$ .

# <span id="page-25-0"></span>4.4 Complete intersection singularity

The story can be easily generalized to an isolated singularity defined by complete intersection. It is proven in [20] that the rational Gorenstein complete intersection singularity has at most embedding dimension 5. Consider an isolated complete intersection defined by two polynomials  $f: (C^5, 0) \to (C^2, 0)$ . We require that complete intersection admits a  $C^*$  action such that the weights are  $(w_1, w_2, \ldots, w_5)$  and the degrees are  $(d_1, d_2)$ . The rational condition implies that

<span id="page-25-2"></span>
$$\sum_{i=1}^{5} w_i - (d_1 + d_2) > 0. (4.26)$$

All these complete intersection singularities are classified in [23]. Consider a complete intersection singularity defined by two polynomials  $f_1$  and  $f_2$  with weights  $(w_1, \ldots, w_5; d_1, d_2)$ , one has a canonical three form

$$\Omega = \frac{dx_1 \wedge dx_2 \dots \wedge dx_5}{df_1 \wedge df_2}.$$
(4.27)

The normalization is that it has charge 2 under the  $C^*$  action, and the charge of each coordinate is constrained as follows:

$$\frac{2w_i}{\sum w_i - d_1 - d_2} \ge \frac{2}{3},\tag{4.28}$$

so that it might admit a SE metric, and the constraint comes from K stability.

**Example:** Consider the complete intersection singularity  $(x_1^2 + x_2^2 + x_3^2 + x_4^2 + x_5^2, x_1^2 + 2x_2^2 + 3x_3^2 + 4x_4^2 + 5x_5^2)$ . The corresponding link is a circle bundle over Del Pezzo five  $(dP_5)$  surface.

#### <span id="page-25-1"></span>4.5 Quotient singularity

Let's consider the quotient singularity of the form  $C^3/G$  with G a finite subgroup of of SL(3). See appendix. B for the classification. The link is  $S^5/G$ . Only G is abelian case, the singularity could be isolated, and these examples are toric so they admit SE metric. The five dimensional link  $S^5/G$  have been studied in many details, and they all admit SE metric.

More generally, we can consider quotient singularity of above hypersurface and complete intersection singularity. To preserve the Gorenstein condition, we require that the finite group action preserves the canonical three form. It would be interesting to study further these large class of examples.

# <span id="page-26-0"></span>4.6 Minimal Gorenstein Log del Pezzo surfaces

For a quasi-regular positive Sasakian manifold, we have a Seifert fibration structure f : X → (S, ∆ = P(1 − 1 m<sup>i</sup> )Di), here S has cyclic quotient singularity and −(K<sup>S</sup> + ∆) is ample. We would like to focus on one type of surface S which is Gorenstein and −K<sup>S</sup> is ample. The Gorenstein condition implies that there are only cyclic du Val singularities (They are A<sup>n</sup> type surface singularities.). The rank of these manifolds is defined as the rank of its Picard group. There is no complete classification for such surfaces, but the rank one and rank two relatively minimal Gorenstein log del Pezzo surfaces are classified in [\[37](#page-49-17)[–39](#page-50-0)], see table [4](#page-29-0) and [5](#page-29-1) for the full list of surfaces with cyclic singularities.

Some deformation class of higher rank Gorenstein log Del Pezzo surfaces can be found as follows [\[11\]](#page-48-9). Let S be a Del Pezzo surface with Du Val singularities and m<sup>1</sup> ≥ . . . ≥ m<sup>k</sup> ≥ 1 integers. We denote by Bm1,...,m<sup>k</sup> S any surface obtained as follows: Pick any smooth elliptic curve C ∈ | − KS| and p1, . . . , p<sup>k</sup> distinct points on C. Then perform a blow up of type m<sup>i</sup> at p<sup>i</sup> . All such surfaces form one deformation type. Furthermore, S and the deformation type determine the numbers m<sup>i</sup> . Indeed, the number m<sup>i</sup> ≥ 2 can be read off from the singularities and the Picard number determines k. The canonical class of Bm1,...,m<sup>k</sup> S is nef and big iff Pm<sup>i</sup> < K<sup>2</sup> S . If this holds then Bm1...m<sup>k</sup> S is a Del Pezzo surface for general choice of the points p<sup>i</sup> . The above process does not change the homology group and fundamental group; and there are 93 deformation types of Del Pezzo surfaces with cyclic Du Val singularities satisfying H1(S) = 0 [9](#page-26-1) . These are

- Bm1,...,m<sup>k</sup> P(1, 2, 3) for Pm<sup>i</sup> < 6 and m<sup>i</sup> ≥ 2.
- Bm1...,mkQ for Pm<sup>i</sup> < 8 and m<sup>i</sup> ≥ 2.
- Bm1,...,m<sup>k</sup> P 2 for Pm<sup>i</sup> < 9 and m<sup>i</sup> ≥ 2.
- Bm1,...,m<sup>k</sup> P <sup>1</sup> <sup>×</sup> <sup>P</sup> 1 for Pm<sup>i</sup> < 8.
- S5, B3S5, B4S<sup>5</sup> and B1P 2 .

And all of them satisfy π1(S) = 0. There are isomorphisms:

$$B_1P(1,2,3) = B_3Q$$
,  $B_1Q = B_2P^2$ ,  $B_{m_1}P^2 = B_m(P^1 \times P^1)$ ,  $B_1S_5 = B_5P^2$ . (4.29)

Let's now study further the possible Sasakian structure built on above log Del Pezzo surfaces. Let's start with a log Del Pezzo surface (S, ∆ = P(1− 1 <sup>m</sup>)D), and we also include a Q divisor ∆. Recall that a Sasakian structure is determined by following data: a) Integers

<span id="page-26-1"></span><sup>9</sup>For a singular surface S, the fundamental group is defined as the fundamental group of its smooth part S 0 , and its homology group is the abelianization of the fundamental group.

0 ≤ b < m with b coprime with m; b) A class of Weyl divisors B. The Chern class of Seifert bundle is

$$c_1(X/S) = B + \frac{b}{m}D.$$
 (4.30)

The smooth condition is that m(x, ∆) · c1(X/S) generates the local class group. Here m(x, ∆) is defined as m(x, ∆) = {lcm(mi)|x ∈ Di}. The corresponding Sasakian manifold has a Einstein metric if

- The Chern class of Seifert bundle is a negative multiple of Chern class of (S, ∆).
- (S, ∆) has a orbifold Kahler-Einstein metric.

The first condition is called pre-SE condition, and we also need to impose smoothness condition which significantly reduce the possible deformation class whose Sasakian manifold might have a SE metric. The proof goes as follows. For each of these rank one surface T, write −K<sup>T</sup> ∼ d(T)H where H ∈ W eil(T) is a positive generator, see table. [4.](#page-29-0) We have

$$d(P^1 \times P^1) = 2$$
,  $d(P^2) = 3$ ,  $d(Q) = 4$ ,  $d(S_5) = 5$ ,  $d(P(1, 2, 3)) = 6$ . (4.31)

Next we perform some weighted blow ups to get S = Bm1...,m<sup>k</sup> T. There are k exceptional curves E1, . . . , Ek. Each E<sup>i</sup> passes through a unique singular point p<sup>i</sup> ∈ S and E<sup>i</sup> generates the local class group which is Z/m<sup>i</sup> . Set d(S) = gcd(m1, . . . , mk, d(T)). The divisor class group Weil(S) is freely generated by

$$\pi^* H, \quad E_1, \dots, E_k, \quad K_S = -d(T)\pi^* H + \sum m_i E_i.$$
 (4.32)

In our case there is only one curve D ∼ −K<sup>S</sup> and S is smooth along D, and

$$c_1(Y/X) = a\pi^* H + \sum_i c_i E_i + \frac{b}{m} D.$$
 (4.33)

Here B = aπ∗H + P i ciE<sup>i</sup> with the coefficients are all integers, and b < m, (b, m) = 1. Now pre-SE condition implies that c1(Y /S) = B + b <sup>m</sup>D is a positive rational multiple of −(K<sup>S</sup> + (1 − 1 <sup>m</sup>)D). In our case D ∼ −KS, hence B itself is a rational multiple of −KS, and

$$B = -\frac{r}{d(S)}K_S = r(\frac{d(T)}{d(S)}\pi^*H - \sum \frac{m_i}{d(S)}E_i).$$
 (4.34)

B generates the local class group at every singular point of T if and only m<sup>i</sup> = d(S) = d(T) for all m<sup>i</sup> . Thus Y (Bm1,...,m<sup>k</sup> T, B = aH + c1E<sup>1</sup> + . . . + ckEk, <sup>m</sup>D) is smooth and pre-SE if and only if

- m<sup>1</sup> = . . . = m<sup>k</sup> = d(S).
- aH + c1E<sup>1</sup> + . . . + ckE<sup>k</sup> = r(− d(T) <sup>d</sup>(S)H + E<sup>1</sup> + . . . + Ek) for some positive integer r which is coprime with d(S).
- If T is singular, then (r, d(T)) = 1 and d(S) = d(T).

This cuts down the 93 deformation classes to the following 19 classes: The pre-SE condition significantly reduces the above list and we have:

• 
$$d(S) = 1$$
:  $B_1 P^2$ ,  $B_{11} P^2$ , ...,  $B_{111111111} P^2$ 

• 
$$d(S) = 2$$
:  $P^1 \times P^1$ ,  $B_2 P_1 \times P^1$ ,  $B_{22} P^1 \times P^1$ ,  $B_{222} P^1 \times P^1$ .

• 
$$d(S) = 3$$
:  $P^2$ ,  $B_3P^2$ ,  $B_{33}P^2$ .

• 
$$d(S) = 4$$
:  $Q, B_4Q$ .

- d(S) = 5: S5.
- d(S) = 6, P(1, 2, 3).

And they are realized by the following hypersurface singularity [\[31\]](#page-49-11):

• 
$$B_2P^1 \times P^1$$
:  $x^3 + y^3 + z^3 + xt^m = 0$ ,  $(m,2) = 1$ .

• 
$$B_{22}P^1 \times P^1$$
:  $x^4 + y^4 + z^2 + zt^m = 0$ ,  $(m,2) = 1$ .

• 
$$B_{222}P^1 \times P^1$$
:  $x^6 + y^3 + z^2 + t^{3m}$ ,  $(m,2) = 1$ .

• 
$$B_3P^2$$
:  $x^4 + y^4 + z^2 + xt^m = 0$ ,  $(m,3) = 1$ .

• 
$$B_{33}P^2$$
:  $x^6 + y^3 + z^2 + zt^m = 0$ ,  $(m,3) = 1$ .

• 
$$Q: x^4 + y^4 + z^2 + t^m = 0, (m, 2) = 1.$$

• 
$$B_4Q$$
:  $x^6 + y^3 + z^2 + yt^m = 0$ ,  $(m, 2) = 1$ .

• 
$$S_5$$
:  $x^6 + y^3 + z^2 + zt^m = 0$ ,  $(m, 5) = 1$ .

• 
$$P(1,2,3)$$
:  $x^6 + y^3 + z^2 + t^m = 0$ ,  $(m,6) = 1$ .

One can compute the homology group of these Sasakian manifold using the method studied in [4.3](#page-21-0) for hypersurface singularity, or the method listed in subsection one of this section. We could also use the K stability to check what kind of m would give us a SE metric. One simple consequence of K stability is that m can not be too large such that we can have a SE metric.

On the other hand, the existence of orbifold Kahler-Einstein metric can be checked using algebraic methods [\[11](#page-48-9)]. We know that P <sup>1</sup> <sup>×</sup> <sup>P</sup> <sup>1</sup> and P 2 surface has Kahler-Einstein metric. For singular surface, the existence of KE metric on following degree one Gorenstein Del Pezzo surface has been established in [\[40](#page-50-1)]:

$$A_4, 2A_4, A_4 + A_3, A_4 + 2A_1, A_4 + A_1, A_3 + 4A_1, A_3 + 3A_1, 2A_3 + 2A_1, A_3 + 2A_1, A_3 + A_1, 2A_3, A_3, (4.35)$$

The above list denotes the singularity type of surface, see table. [4](#page-29-0) and [5](#page-29-1) for some explicit degree one examples.

| degree | singularities | $\pi_1(S^0)$ | Weil/Pic | univ.cover       |
|--------|---------------|--------------|----------|------------------|
| 8      | smooth        | 0            | 1        | $P^1 \times P^1$ |
| 9      | smooth        | 0            | 1        | $P^2$            |
| 8      | $A_1$         | 0            | Z/2      | Q                |
| 6      | $A_1 + A_2$   | 0            | Z/6      | P(1, 2, 3)       |
| 5      | $A_4$         | 0            | Z/5      | $S_5$            |

**Table 4.** The list of rank one and rank two simply connected Gorenstein del Pezzo surface. Here  $S^0$  is the smooth part of S, degree is defined as  $K_S^2$ .

<span id="page-29-0"></span>

| degree | singularities     | $\pi_1(S^0)$ | Weil/Pic          | univ.cover             | $\pi_1(S^0/D)$ |
|--------|-------------------|--------------|-------------------|------------------------|----------------|
| 1      | $A_8$             | Z/3          | Z/3               | $B_{3111}P^2$          | Z/3            |
| 1      | $A_7 + A_1$       | Z/4          | Z/4               | $B_{2111}P^2$          | Z/4            |
| 1      | $A_5 + A_2 + A_1$ | Z/6          | Z/6               | $B_{111}P^2$           | Z/6            |
| 1      | $4A_2$            | $(Z/3)^2$    | $(Z/3)^2$         | $P^2$                  | $G_{27}$       |
| 1      | $2A_3 + 2A_1$     | Z/2 + Z/4    | Z/2 + Z/4         | $P^1 \times P^1$       | $G_{16}$       |
| 1      | $2A_4$            | Z/5          | Z/5               | $B_{1111}P^2$          | Z/5            |
| 1      | $A_3 + 4A_1$      | $(Z/2)^2$    | $(Z/2)^3 + (Z/4)$ | $B_{22}P^1 \times P^1$ | Z/2 + Z/4      |
| 2      | $A_7$             | Z/2          | Z/4               | $B_{41}P^2$            | Z/2            |
| 2      | $A_5 + A_2$       | Z/3          | Z/6               | $B_{11}Q$              | Z/3            |
| 2      | $2A_3 + A_1$      | Z/4          | Z/2 + Z/4         | $P^1 \times P^1$       | Z/2+Z/4        |
| 2      | $6A_1$            | $(Z/2)^2$    | $(Z/2)^4$         | $P^1 \times P^1$       | $G_8$          |
| 2      | $2A_3$            | Z/2          | Z/2 + Z/4         | $B_{22}P^1 \times P^1$ | Z/4            |
| 3      | $A_5 + A_1$       | Z/2          | Z/6               | $B_3P^2$               | Z/6            |
| 3      | $3A_2$            | Z/3          | $(Z/3)^2$         | $P^2$                  | $(Z/3)^2$      |
| 4      | $A_3 + 2A_1$      | Z/2          | Z/2 + Z/4         | Q                      | $(Z/2)^2$      |
| 4      | $4A_1$            | Z/2          | $(Z/2)^3$         | $P^1 \times P^1$       | $(Z/2)^2$      |

<span id="page-29-1"></span>**Table 5.** The list of rank one and rank two non-simply connected Gorenstein del Pezzo surface. Here  $S^0$  is the smooth part of S, degree is defined as  $K_S^2$ .

**Remark**: The SE metric on link L (or Ricci flat conic metric on the cone X) constructed using the orbifold Khaler-Einstein metric on S is quasi-regular. However, not all SE metric can come from this way. For example, it is possible that SE metric on X is irregular and therefore we can not construct them using the orbifold Khaler-Einstein metric on the base.

# <span id="page-30-0"></span>5 AdS/CFT correspondence

As reviewed in introduction, we have a correspondence between large N four dimensional N = 1 SCFT and type IIB string theory on following background:

$$AdS_5 \times L_X; \tag{5.1}$$

Here L<sup>X</sup> is a five manifold with a Sasaki-Einstein metric, and we also need to turn on N unit of five form fluxes on LX. L<sup>X</sup> is defined as the link of a three dimensional log terminal singularity X which is K stable. The field theory is defined as the IR theory on N D3 branes probing X. The main point of this section is to study properties of SCFT from various geometric objects associated with LX.

Type IIB string theory has following bosonic massless fields: (Gµν , Bµν , φ) which is frome gravity multiplet and Ramond-Ramond fields C0, C2, C4, which are zero form, two form and four form fields [\[41\]](#page-50-2). Type IIB string theory also contains half-BPS nonperturbative objects Dp brane with p = −1, 1, 3, 5, 7, 9, and NS5 brane. In general, we actually have (p, q) five branes, and (p, q) strings [\[42](#page-50-3)]. More interestingly, we have quarter BPS (p, q) string junction or (p, q) five brane junctions. One can learn many interesting physics about field theory by studying above objects in AdS<sup>5</sup> × L<sup>X</sup> background, and the geometry of L<sup>X</sup> plays a crucial role.

# <span id="page-30-1"></span>5.1 Global symmetries

From AdS/CFT correspondence, the global symmetries are associated with the massless gauge fields in AdS<sup>5</sup> space. One can have massless gauge fields from isometry of SE metric [\[41](#page-50-2)], and one can also get global symmetry from massless mode of four form RR field C4, and the number is given by Betti number b3. Since the fundamental group of a SE manifold is finite, and so the first homology group is finite, we do not get continuous gauge fields by compactifying two form fields B<sup>2</sup> and C<sup>2</sup> using harmonic one form on SE manifold.

# <span id="page-30-2"></span>5.1.1 Isometry of SE manifold

We know that the Reeb vector field ζ is a Killing vector field and generates an isometry group, and this corresponds to the U(1)<sup>R</sup> symmetry of the field theory. The precise relation is U(1)<sup>R</sup> = <sup>2</sup> 3 ζ, so the ζ charge is just the scaling dimension for a chiral operator. This isometry exists for any SE manifold which matches the fact that U(1)<sup>R</sup> symmetry exists for any 4d N = 1 SCFT. In general, there could be more isometries. Here let's discuss some general facts.

Given a Riemannian manifold (M, g) we let Isom(M, g) denote the isometry group of g which is the subgroup of diffeomorphism group of M which leaves g invariant. It is known that Isom(M, g) is a finite dimensional Lie group and is a compact Lie group if M is compact [\[18](#page-48-16)]. For SE five manifold, we have the relation 1 ≤ dim(Isom(M, g)) ≤ 15, and the upper bound is achieved for S <sup>5</sup> with standard Sasakian structure. For irregular SE manifold, the isometry group is at least two dimensional. We might also have finite isometry subgroup too.

It is not so easy to compute the full isometry group for SE manifold  $L_X$ . However, in many cases, global symmetries can be found from automorphism group aut(X) of the singularity X, and the symmetry group are the maximal compact subgroup of Aut(X). For hypersurface singularity, most of those automorphism group is discrete (except the  $C^*$  action which is identified with the  $U(1)_R$  symmetry). The proof goes as follows: Let's start with a hypersurface singularity  $f(z_0, \ldots, z_3)$ , and consider the one parameter subgroup  $\tau_t$  of aut(f):

$$z'_{i} = z_{i} + \sum_{j>1} t^{j} g_{ij}(z_{0}, \dots, z_{n})$$
 (5.2)

The condition of invariance is

$$f(\tau_t(z_0), \dots, \tau_t(z_3)) = f(z_0, \dots, z_3).$$
 (5.3)

Differentiating with respect to  $z_i$  of above equation, and expanding in a Taylor series in t and equating the coefficients of  $t^j$  for each j gives

$$\sum g_{kj} \frac{\partial f}{\partial z_k} = 0. {(5.4)}$$

Since the degree of  $g_{kj}$  is  $w_k$  and the degree of  $\frac{\partial f}{\partial z_k}$  is  $d-w_k$ , and not all  $\frac{\partial f}{\partial z_k}$  vanish or there is a cancellation for two different values of k, say k and l. But the only way this happen is that  $w_k = w_l$  and that both  $\frac{\partial f}{\partial z_k}$  and  $\frac{\partial f}{\partial z_l}$  are linear in  $z_k$  or  $z_l$ . This implies that  $w_k = w_l = \frac{d}{2}$ . This implies that our singularity is  $z_0^2 + z_1^2 + f(z_2, z_3) = 0$ , and only in this case there is more than one dimensional isometry group.

In the other direction, we know that toric SE manifold admits at least  $U(1)^3$  isometry. For toric singularity, there is an elegant description of three abelian automorphism groups using the combinatorial tools, see [43] for more details. For singularity with rank two automorphism group, there is also a combinatorial description, see [44].

The analysis of discrete symmetry is more subtle, and a detailed analysis for many concrete models will be presented elsewhere.

# <span id="page-31-0"></span>5.1.2 Baryonic symmetry

One can also get baryonic symmetry from RR four form field  $C_4$ , i.e. in the KK analysis, we consider field  $C_{\mu mnp}$  with  $\mu$  the index in AdS direction, and m, n, p the direction in  $SE_5$  direction. The number of such symmetries is equal to Betti number  $b_3$ . These symmetries are called Baryonic as the baryonic operator <sup>10</sup> will be charged under these symmetries.

#### <span id="page-31-1"></span>5.2 Operator spectrum

Using massless fields of type IIB string theory, we can perform a Klazu-Klein (KK) analysis and get various massive fields in five dimensional AdS space, and the masses of these fields depend on the harmonic analysis on  $L_X$ . These KK fields would give us operators for the conformal field theory [45]. We are interested in short multiplets of field theory. The Betti numbers  $b_i$  of  $L_X$  gives harmonic forms which give massless particles in  $AdS_5$  space, and

<span id="page-31-2"></span><sup>&</sup>lt;sup>10</sup>If a dual gauge theory exists, one can construct them explicitly.

they will define some short multiplets. The other important fact is that a large class of chiral scalars are simply given by the coordinate ring of X, and this immediately gives us a lot of information about field theory.

# <span id="page-32-0"></span>5.2.1 Harmonic analysis

One can find scaling dimension of a boundary field theory operator from the mass of a particle in  $AdS_5$  space. One can get the masses from Klazu-Klein analysis of type IIB string theory on  $SE_5$  manifold. The detailed analysis is quite involved, see [46–48]. We are interested in short multiplets, and they have simple origins from cohomology groups of sheafs on singularity X, which is easier to compute. Here let's summarize the main result, see table. 6. First for a holomorphic function f with charge c under  $C^*$  action, one can get three chiral multiplets, and three semi-chiral multiplet [48]. They contribute to single trace index:

$$I_f = t^{2c} + t^{2c+6}. (5.5)$$

Now for a holomorphic one form with charge r under  $C^*$  action, there are associated three semi-chiral multiplet, and they contribute to single trace index [48]:

$$I_v = -t^{2r+6}. (5.6)$$

|       | Multiplet   | Operator                       | $U(1)_R$           | Δ                 |
|-------|-------------|--------------------------------|--------------------|-------------------|
| f     | chiral      | O                              | $\frac{2}{3}c$     | c                 |
|       |             | $\lambda_{\alpha}$             | $\frac{2}{3}c + 1$ | $c + \frac{3}{2}$ |
|       |             | S                              | $\frac{2}{3}c + 2$ | c+3               |
|       | Semi-chiral | $\mathcal{O}_{\dot{lpha}}$     | $\frac{2}{3}c - 1$ | $c + \frac{3}{2}$ |
|       |             | $\mathcal{O}_{lpha\dot{lpha}}$ | $\frac{2}{3}c$     | c+3               |
|       |             | $S_{\dot{lpha}}$               | $\frac{2}{3}c + 1$ | $c + \frac{9}{2}$ |
| $T^z$ | Semi-chiral | С                              | $\frac{2}{3}r$     | r+2               |
|       |             | $C_{\alpha}$                   | $\frac{2}{3}r + 1$ | $r + \frac{7}{2}$ |
|       |             | C'                             | $\frac{2}{3}r + 2$ | r+5               |

<span id="page-32-1"></span>**Table 6.** f is a holomorphic function on X with charge c under  $C^*$  action.  $T^z$  is a holomorphic one form with charge r under  $C^*$  action.

The complex structure on X satisfies the relation (here  $\zeta$  is the Reeb vector field, and  $\Psi = r \frac{\partial}{\partial r}$ ):

$$I(\zeta) = \Psi, \quad I(\Psi) = -\zeta. \tag{5.7}$$

So  $I(\Psi + i\zeta) = i(\Psi + i\zeta)$ , i.e.  $\Psi + i\zeta$  is anti-holomorphic vector field ( $\bar{\partial}$  operator). A holomorphic function on the metric cone obeys the equation

<span id="page-32-2"></span>
$$(\Psi + i\zeta)f = 0, (5.8)$$

Let's now take  $f = r^c \tilde{f}$  with  $\tilde{f}$  has zero charge under  $r \frac{\partial}{\partial r}$ , and  $\zeta \tilde{f} = ic\tilde{f}$ . f now has charge c under the action of holomorphic vector field  $\frac{1}{2}(\Psi - i\zeta)$ 

$$\frac{1}{2}(\Psi - i\zeta)f = cf. \tag{5.9}$$

So a holomorphic function f on X with charge c would give a scalar function  $\tilde{f}$  on SE manifold which has charge ic under the Reeb vector field. One can further show that  $\tilde{f}$  is actually an eigen-form on  $L_X$ , and the eigenvalue is c(c+4).

To see how a holomorphic function f on X would give an eigenfunction of  $L_X$ , We will discuss more detail about the harmonic analysis on Sasakian-Einstein manifold [49, 50]. Let's start with a 2n+1 Sasakian manifold  $(M, \zeta, \eta, \Phi)$ , and define the following operations:

$$L: \Omega^{p}(M) \to \Omega^{p+2}(M), \quad \alpha \to \omega \wedge \alpha$$
$$\Lambda: \Omega^{p}(M) \to \Omega^{p-2}(M), \quad \alpha \to \omega \sqcup \alpha$$
 (5.10)

Here  $\omega = \frac{1}{2}d\eta$ , and  $\Box$  is the contraction operation. Now a differential form  $\alpha \in \Omega^p(M)$  is called

• horizontal if  $\zeta \perp \alpha = 0$ , vertical if  $\eta \wedge \alpha = 0$ , primitive if  $\Lambda \alpha = 0$ .

For a  $\alpha \in \Omega^p(M)$ , we have:

- $h(\alpha) = \zeta \sqcup (\eta \wedge \alpha) \in \Omega^p(M)(H)$  is called the horizontal part of  $\alpha$ .
- $v(\alpha) = \zeta \, \exists \alpha \in \Omega^{p-1}(H)$  is called the vertical prat of  $\alpha$ .

Now we can decompose every form as follows

$$\alpha = h(\alpha) + \eta \wedge v(\alpha) \tag{5.11}$$

and a form is denoted as a two component vector  $\begin{pmatrix} \beta \\ \gamma \end{pmatrix}$ . We have the standard differential operator d, and can define the operators  $d^c: \Omega^p(M) \to \Omega^{p+1}(M)$  and  $\delta^c: \Omega^p(M) \to \Omega^{p-1}(M)$  by

$$d^{c} := \sum \phi e_{i}^{*} \wedge \nabla_{e_{i}},$$

$$\delta^{c} := -\sum \phi e_{i} \nabla_{e_{i}}.$$
(5.12)

where  $e_i$  is the local basis of tangent bundle. The space of horizontal p forms are denoted as  $\Omega^p(M)$ , and we can define the operator  $d_H:\Omega^p(H)\to\Omega^{p+1}(H)$  as

$$d_H := h \circ d|\Omega^p(H), \tag{5.13}$$

here  $h \circ$  means we take the horizontal part. Similarly we can define operator  $d_H^c$  and  $\delta_H^c$ . The Laplacian acting on a p form  $\alpha = \begin{pmatrix} \beta \\ \gamma \end{pmatrix}$  becomes

<span id="page-33-0"></span>
$$\Delta = \begin{pmatrix} \triangle_H - (L_\zeta)^2 + 4L\Lambda & -2d_H^c \\ -2\delta_H^c & \triangle_H - (L_\zeta)^2 + 4L\Lambda \end{pmatrix}.$$
 (5.14)

We now define following differential operators using the complex structure  $\Phi$ :

$$\partial, \bar{\partial}: \Omega_C^p(H) \to \Omega_C^{p+1}(H), \quad \partial^*, \bar{\partial}^*: \Omega_C^p(H) \to \Omega_C^{p-1}(H).$$
 (5.15)

They satisfy the following conditions

$$\partial^2 = \bar{\partial}^2 = (\partial^*)^2 = (\bar{\partial}^*)^2 = 0, \ [\partial, \bar{\partial}] = -2LL_{\zeta}, \ [\partial^*, \bar{\partial}^*] = 2\Lambda L_{\zeta}. \tag{5.16}$$

So  $\Omega^k(H)$  has a hodge decomposition  $\Omega^k(H) = \bigoplus_{p+q=k} \Omega^{p,q}(H)$ . We finally have

$$d_H^c = -i(\partial - \bar{\partial}), \ \delta_H^c = i(\partial^* - \bar{\partial}^*),$$
  

$$\Delta_H = 2\Delta_{\bar{\partial}} - i((2n+1) - 2deg - 1)L_{\zeta}, \ \Delta_H = \Delta_{\bar{\partial}} + \Delta_{\bar{\partial}}.$$
(5.17)

Here  $\triangle_{\bar{\partial}} = \bar{\partial}^* \bar{\partial} + \bar{\partial} \bar{\partial}^*$ . In fact, we also have  $\partial^* = iL\Lambda$ ,  $\bar{\partial}^* = -iL\Lambda$ . We are interested in p forms satisfying following conditions:

- primitive  $\Lambda \alpha = 0$ .
- horizontal  $\zeta \lrcorner \alpha = 0$ .
- $\bar{\partial}\alpha = \bar{\partial}^*\alpha = 0$ , and in particular  $\triangle_{\bar{\partial}}\alpha = 0$ . The condition  $\bar{\partial}^*\alpha = 0$  is actually redundant as the primitive condition already implies it as  $\bar{\partial}^* = -iL\Lambda$ .

Combine with the relation  $[\Lambda, \bar{\partial}] = -i\partial^*$  which holds on horizontal form, we see that  $\partial^* \alpha = 0$  and  $\delta^c_H \alpha = 0$  for primitive, horizontal and holomorphic forms. Now look at the Laplacian 5.14, and its action on primitive and horizontal forms are

$$\Delta = 2\Delta_{\bar{\partial}} - i((2n - 2deg)L_{\zeta} - (L_{\zeta})^2. \tag{5.18}$$

Now we choose a primitive, horizontal and holomorphic p form  $\alpha$  such that  $L_{\zeta}\alpha = ic\alpha$ , we see that  $\alpha$  is an eigenform:  $\Delta\alpha = [2q(n-deg)+q^2]\alpha$ , see 5.14. We have (recall that we are interested in n=2) the eigenvalues of the forms:

zero form: 
$$\lambda_0 = 4c + c^2$$
  
one form:  $\lambda_1 = 2c + c^2$   
two form:  $\lambda_2 = c^2$ . (5.19)

Moreover, for a zero form  $\alpha$ , we take  $\tilde{\alpha} = r^c \alpha$  which is now holomorphic on the cone X with charge c under  $C^*$  action, see 5.8. So we see that a holomorphic function on the cone with charge c would give an eigenfunction on  $L_X$  with eigenvalue  $H_0 = c^2 + 4c$ . This is one of most important relation between the cone X and the geometry of  $SE_5$  manifold. The scaling dimension of bottom component of vector multiplet I (see [47] page 18) is  $E_0 = \sqrt{H_0 + 4} - 2 = c$ , so we get a chiral multiplet  $\hat{B}_{\frac{2}{5}c,(0,0)}$ !

On the other hand, for a primitive, horizontal, and holomorphic one-form v with  $\zeta$  charge c, it can actually be written as  $(df)^{\lambda}\Omega_{\lambda\mu}$  with  $\Omega$  a holomorphic two form with  $\zeta$  charge 3 [48]. Scalar function f is actually also an eigenfunction with  $\zeta$  charge c-3, and its eigenvalues are  $H_0 = c^2 + 2c - 3$ . The scaling dimension of bottom component of vector

multiplet I (see [47] page 18) is  $E_0 = \sqrt{H_0 + 4} - 2 = c - 1$ . So we get a semi-chiral multiplet  $C_{\frac{2}{3}(c-3),(0,0)}$ .

When c=0, those forms are called basic forms. Each basic p form also has a Hodge decomposition, and the dimension of harmonic solution is called basic Hodge number. Now, we have the following important theorem: in the positive Sasakian case, the (p,0)th and (0,q)th Hodge number vanishing for p>0 and q>0 [51]. In the quasi-regular case, they are just the Hodge number of orbifold  $(S,\Delta)$  [51]. So essentially the only nonzero basic Hodge numbers are  $(h^{0,0},h^{1,1})$ .  $h^{0,0}=1$  and so the only non-trivial numbers are  $h_{1,1}$  which determines the second and third Betti numbers of SE manifold.

Let's now interpret those forms with  $c \neq 0$  from base point of view, and we consider quasi-regular SE manifold, so we have an associated surface  $(S, \Delta)$ , and for simplicity, we assume that the branch divisor  $\Delta$  is trivial here. We need to consider following cohomology groups:

$$\bigoplus_n H^p(S, \Omega_S^q \otimes (-aK_S)^n), \quad (p, q) = (0, 0), (0, 1), (1, 1), (0, 2). \tag{5.20}$$

Here a is a positive rational number that determines the Sasakian structure  $^{11}$ , we also use the vanishing theorem to constrain p and  $q^{12}$ . We now have cohomology groups:

$$H^0(S, (-aK_S)^n).$$
 (5.21)

They contribute to three chiral multiplets and the lowest one is a chiral scalar with  $U(1)_R$  charge n and the contribution to single trace index is  $t^{3n}$ . The cohomology groups

$$H^{0}(S, \Omega_{S}^{2} \otimes (-aK_{S})^{n}) = H^{0}(S, (-an+1)K_{S}).$$
(5.22)

contributes to three semi-chiral multiplets and the lowest one has R charge n-2, so the contribution to single trace index is  $t^{3n}$ . Finally, we have cohomology groups

$$H^{0}(S, \Omega \otimes (-aK_{S})^{n}) - H^{1}(S, \Omega \otimes (-aK_{S})^{n}), \tag{5.23}$$

which gives three semi-chiral multiplets and the lowest one has R charge n-2, so the contribution to single trace index is  $-t^{3n}$ . The single trace index can then be computed using Riemann-Roch theorem.

From the cone point view, we have the following cohomology groups:

$$H^{0}(X, \mathcal{O}_{X}) = \bigoplus_{n} H^{0}(S, (-aK_{S})^{n}).$$
 (5.24)

So  $\mathcal{O}_X$  is the structure sheaf of X, and  $H^0(X, \mathcal{O}_X)$  is the coordinate ring of X. Similarly, the other nontrivial cohomology groups on the cone is  $H^0(X, \Omega_X)$  with  $\Omega_X$  the sheaf of one forms.

<span id="page-35-0"></span> $<sup>^{11}</sup>$ Recall that the Sasakian structure constructed from a base surface depends on a choice of Weyl divisor B, and Sasaki-Einstein condition implies that it is a rational positive multiple of  $-K_S$ , so  $B = -aK_S$ . Moreover, if we want a smooth Sasaki-Einstein manifold, a should be chosen so that  $-aK_S$  generates the class group at every point.

<span id="page-35-1"></span> $<sup>^{12}</sup>H^p(S,\Omega^q\oplus L)=0$  for p+q>2 if L is ample, in our case  $L=-aK_S$  which is ample. Moreover,  $H^i(S,K_S+D)=0, i>0$  if D is ample, and in our case  $D=-K_S$  is ample. We also have  $H^i(S,\mathcal{O}_S)=0$  for our rational surface S.

**Example:** Let's take  $S = P^1 \times P^1$ , and  $K_S = -2l - 2m$  with l, m corresponding to two  $P^1$  factors, and the nontrivial intersection numbers are  $l \cdot l = 2$  and  $m \cdot m = 2$ , so  $K_S^2 = 8$ . We choose  $a = \frac{1}{2}$ , and the cone X is the conifold singularity  $x^2 + y^2 + z^2 + w^2 = 0$ . The dimension of cohomology group (using Riemann-Roch theorem <sup>13</sup>)is

$$H^{0}(S, \mathcal{O}_{S} \otimes (-\frac{1}{2}K_{S})^{n}) = (n+1)^{2}.$$
 (5.25)

Each element of  $H^0(S, \mathcal{O}_S \otimes (-\frac{1}{2}K_S)^n)$  contributes to a holomorphic function with R charge n on the cone X.

# <span id="page-36-0"></span>**5.2.2** Hilbert series, central charge a and $U(1)_R$ symmetry

The  $U(1)_R$  symmetry is identified with the Reeb vector field as follows:  $U(1)_R = \frac{2}{3}\zeta$ . In the large N limit, The central charge is inverse proportional to the volume of the SE manifold [52]. The volume can be computed from the Hilbert series of the affine ring X. In practice, there are often many candidate  $U(1)_R$  symmetry, and the way to determine it is to use volume minimization. If there is just one candidate  $U(1)_R$  symmetry, we can use Hilbert series to compute the central charge a.

We would like to focus on Gorenstein ring, and so there is a generator  $\Omega$  of the canonical bundle.  $\Omega$  should have charge two under candidate  $U(1)_R$  symmetry:

$$\zeta(\Omega) = 2. \tag{5.26}$$

This normalization ensures that  $\zeta$  is actually the  $U(1)_R$  symmetry. We also require that the  $\zeta$  action on the coordinates to be positive, and so we have a space of candidate  $U(1)_R$  symmetries:

$$\zeta(x_i) > 0, \quad \zeta(\Omega) = 2. \tag{5.27}$$

In the large N limit, the central charge a of field theory can be extracted from the Hilbert series of X with respect to  $C^*$  action. The Hilbert series of a graded ring is defined as follows:

$$H_{\zeta}(t) = \sum_{\zeta} t^{\alpha} dim H_{\alpha}. \tag{5.28}$$

Here  $H_{\alpha}$  is the subspaces of the ring with charge  $\alpha$  under symmetry  $\zeta$ . For our case, this Hilbert series has the following expansion:

$$H(e^{-s}) = \frac{a_0(\zeta)}{s^3} + \frac{a_1(\zeta)}{s^2} + \dots$$
 (5.29)

Due to the charge two condition on  $\Omega$ , we have  $a_0 = a_1$ .  $a_0$  is proportional to volume of Sasakian manifold with Reeb vector field  $\frac{3}{2}\zeta$ . The central charge of field theory is related to the coefficient  $a_0$  as follows

$$a(\zeta) = \frac{27}{32} N^2 \frac{1}{a_0(\zeta)}. (5.30)$$

<span id="page-36-1"></span><sup>&</sup>lt;sup>13</sup>For a divisor D, the Riemann-Roch theorem gives  $\chi(\mathcal{O}_S(D)) = \frac{(D+K_S)\cdot D}{2} + \chi(\mathcal{O}_S)$ , here  $\chi(\mathcal{O}_S(D))$  is the Euler number of the divisor D, and  $\chi(\mathcal{O}_S)$  is the Euler number of the manifold S. In our case  $D = \frac{-n}{2}K_S$ , and  $\chi(\mathcal{O}_S) = 1$ .

This is the leading order term of central charge a in the large N limit.

The Hilbert series for a complete intersection singularity is rather easy to compute. Let's start with a hypersurface singularity f, and assume the weights are  $(w_1, \ldots, w_4; d)$ , then the Hilbert series is simply

$$H(t) = \frac{(1 - t^d)}{(1 - t^{w_1})(1 - t^{w_2})(1 - t^{w_3})(1 - t^{w_4})}.$$
 (5.31)

The canonical differential is given by

$$\Omega = \frac{dx \wedge dy \wedge dz \wedge dw}{df},\tag{5.32}$$

and it has charge  $\sum w_i - d$ . Normalize the  $C^*$  action so that  $\Omega$  has charge two, so the normalized weights are  $\frac{2}{\sum w_i - d}(w_1, \dots, w_4; d)$ , and we find

<span id="page-37-0"></span>
$$a_0 = \frac{d(-d + w_1 + w_2 + w_3 + w_4)^3}{8w_1w_2w_3w_4}. (5.33)$$

The Hilbert series of a complete intersection singularity with weights  $(w_1, w_2, w_3, w_4, w_5; d_1, d_2)$  is

$$H(t) = \frac{(1 - t^{d_1})(1 - t^{d_2})}{(1 - t^{w_1})(1 - t^{w_2})(1 - t^{w_3})(1 - t^{w_4})(1 - t^{w_5})}.$$
 (5.34)

and the normalized weights are  $\frac{2}{\sum w_i - \sum d_i}(w_1, w_2, w_3, w_4, w_5; d_1, d_2)$  by requiring  $\Omega = \frac{dx_1 \wedge ... \wedge dx_5}{df_1 \wedge df_2}$  to have charge two. We find that

$$a_0 = \frac{d_1 d_2 (-d_1 - d_2 + w_1 + w_2 + w_3 + w_4 + w_5)^3}{8w_1 w_2 w_3 w_4 w_5}.$$
 (5.35)

**Example**: Consider the conifold example. The affine ring is simply given by the ideal  $f = x^2 + y^2 + z^2 + w^2$ , and the weights are (1, 1, 1, 1; 2), and we find (use 5.33):

$$a = \frac{27}{64}N^2. (5.36)$$

Since Hilbert series plays a crucial role in determining the  $U(1)_R$  symmetry and central charge, we would like to make some further comments on the general ring considered in this paper. For our SE manifold, we associate an affine ring X which is further rational Gorenstein. For a general ring R with finite number of generators  $y_i$  with charge  $e_i$  (i = 1, ..., n), the Hilbert series has the following general structure [29]:

$$F(R,t) = \frac{P(R,t)}{\prod_{i} (1 - t^{e_i})}.$$
 (5.37)

Here P(R,t) is a polynomial with integer coefficients. There is a unique number d such that  $\lim_{t\to 1} (1-t)^d F(R,t)$  is nonzero, and this d is the dimension of the ring. Here we consider ring with dimension d=3, and the Hilbert series has an expansion

$$F(R, e^{-s}) = \frac{a_0}{s^3} + \frac{a_1}{s^2} + \dots$$
 (5.38)

here  $a_0 = \frac{e}{\prod_i e_i}$  and e is the leading order coefficient of expansion of  $P(R,t) = e(1-t)^{n-3} + \dots$  Now we would like to restrict to the Gorenstein ring, the Hilbert series satisfy the following condition:

$$F(R, \frac{1}{t}) = (-1)^d t^{\rho} F(R, t). \tag{5.39}$$

Here d is the dimension and  $\rho$  is an integer. For a Gorenstein ring, we have a regular sequence with length d. Let  $\theta_1, \ldots, \theta_d$  to be a homogeneous regular sequence of R, and we have  $deg(\theta_i) = f_i$ , and let  $S = R/(\theta_1, \ldots, \theta_d)$ , then S is a zero dimensional Gorenstein algebra:  $S = S_0 + \ldots + S_s$ . The Hilbert series has the following nice form [29]:

$$F(R,t) = \frac{(h_0 + h_1 t + \dots + h_s t^s)}{\prod_{i=1}^d (1 - t^{f_i})}.$$
 (5.40)

where  $h_i = dim(S_i)$ . There is a perfect pairing  $h_i = h_{s-i}$ , and furthermore  $\rho = \sum f_i - s$ . So it seems that the regular sequence plays an important role, and it would be interesting to understand their meanings in field theory.

We have discussed the consequence of Gorenstein condition on Hilbert series. The rational condition implies that  $a_0 = a_1 > 0$ .

#### <span id="page-38-0"></span>5.2.3 Mesonic and baryonic operators

Let's consider N D3 brane probing three dimensional canonical singularity X. The moduli space of field theory on D3 branes is equal to the symmetric product of X:  $M_{vac} = X^N/S_N$ . One part of chiral ring of the field theory is conjectured to be the coordinate ring of  $M_{vac}$ , and one may call them **mesonic operator**. These chiral operators might be separated into two parts: single trace and multiple trace operators. The name comes from the gauge theory where the chiral operators can be formed from trace of fundamental fields in the Lagrangian (This is the way to produce gauge invariant objects.): the single (multiple) trace operators are formed from a single (multiple) trace.

In the large N limit, the space of single trace scalar chiral operators parameterizing the moduli space have a very nice description:

# The space of single trace chiral operators are described by the affine ring of X.

Because of the  $C^*$  action, this affine ring is a graded ring  $R = R_0 \oplus R_{n_1} \dots$ , here  $R_0 = C$ . Each subspace  $R_{n_i}$  gives rise to a subspace of scalar chiral operator with charge  $n_i$ . The  $C^*$  action is proportional to  $U(1)_R$  charge, so one can find the scaling dimension of these chiral scalar operators from the grading of X. The multiple trace chiral operators are formed by simply multiplying the single trace operators. The chiral ring relation is completely captured by the ring X.

**Example:** Let's consider conifold example which is defined by an ideal  $f = x_1^2 + x_2^2 + x_3^2 + x_4^2$ , and each coordinate  $x_i$  has R charge 1, so we have the graded ring  $R = R_0 \oplus R_1 \oplus R_2 \dots$ , i.e.  $R_1$  has four elements generated by  $x_i$ ; for  $R_2$  we can form 9 elements  $x_i x_j$ , but we have one quadratic relation, so there are 8 independent elements in  $R_2$ .

Let's now consider non-perturbative chiral operators in the large N limit. These operators are derived from wrapped D branes. We have **baryonic chiral operators** [53–55]

derived by wrapping D3 branes on three cycles. The BPS condition is that the three cycles combined with r direction is a holomorphic surface in the cone X [\[56](#page-50-16), [57](#page-50-17)].

For a quasi-regular SE manifold, one can find some of those surfaces from the divisors of the bases. Consider a quasi-regular Sasakian-Einstein manifold, and then we have a Seifert fibration f : X → (S, ∆), here S has cyclic quotient singularity, and ∆ = P(1 − 1 m<sup>i</sup> )D<sup>i</sup> is a Q divisor. One can get baryons by wrapping D3 branes on effective divisors of S (combining with fibre direction, we get a three cycle), and the lift of three cycle to the cone X would be holomorphic, and we expect them to give BPS baryons. Now let's choose a basis of Weyl divisors D<sup>i</sup> on S, and consider a divisor D = P<sup>n</sup> <sup>i</sup>=1 aiD<sup>i</sup> , and the scaling dimension of these baryons are [\[55](#page-50-15)]:

$$\Delta = -3N \frac{K \cdot D}{K \cdot K}.\tag{5.42}$$

Here K = K<sup>S</sup> + ∆ is the canonical divisor of the orbifold (S, ∆). If D is effective (a<sup>i</sup> ≥ 0), the above number is positive as −K is ample, which we might call baryons. On the other hand, if a<sup>i</sup> ≤ 0, we should get anti-baryon. The detailed counting of these baryons needs further study.

If the first homology is nontrivial, one could also get particles by wrapping F1 string and D1 string on one cycles inside SE manifold. These baryons seem to have nilpotent ring relation as the first homology group is finite for SE manifold.

# <span id="page-39-1"></span><span id="page-39-0"></span>5.3 Deformation

# 5.3.1 Exact marginal deformations

It is interesting to study various deformations of the field theory through the deformation of LX. Let's first consider exact marginal deformations:

- 1. We have type IIB dilaton-axion τ in ten dimension, and this always give an exact marginal deformation of field theory. Type IIB string theory has a SL(2, Z) duality acting on τ , so all of these SCFTs also have a SL(2, Z) duality symmetry.
- 2. We also get exact marginal deformations by compactifying two forms B<sup>2</sup> and C<sup>2</sup> if b<sup>2</sup> is nonzero. There are a total of b<sup>2</sup> (second Betti number) exact marginal deformations.
- 3. Moduli space of Sasaki-Einstein metric [\[41\]](#page-50-2). It is also interesting to study S duality on this moduli space.

While the number of first two class of deformations are relatively easy to compute, the third class of exact marginal deformation is more difficult. For hypersurface singularity, however, it is easy to count the number, i.e. they are given by weight one deformations.

Example: Let's consider the singularity f = x <sup>2</sup>+y <sup>2</sup>+z <sup>4</sup>+w 4 , which admits SE metric through section 4, see [4.25.](#page-25-2) There is a weight one deformation of f, i.e. F = f + τx2y 2 , so the corresponding SCFT has one extra exact marginal deformation from the moduli of SE metric.

Notice however that not all exact marginal deformations are captured by geometric properties of SE<sup>5</sup> manifold; Some of exact marginal deformations are captured by turning on other fluxes besides the usual five form flux, i.e. so-called  $\beta$  deformation [58]. Moreover, one can find other multiple trace exact marginal deformations too, and one can find these numbers by computing superconformal index.

# <span id="page-40-0"></span>5.3.2 Deformation and resolution of singularity

Given a singularity, one has two ways to make a singularity non-singular: deformation or resolution. For an isolated rational Gorenstein singularity, we have two special kinds of deformation called mini-versal deformation and crepant resolution, and they should correspond to supersymmetric deformations.

The mini-versal deformation for a hypersurface singularity can be easily described. Let's start with a hypersurface singularity  $f:(C^4,0)\to(C,0)$  which is quasi-homogeneous:

$$f(\lambda^{q_i} z_i) = \lambda f(z_i). \tag{5.43}$$

The canonical differential has the form:

$$\Omega = \frac{dz_1 \wedge dz_2 \wedge dz_3 \wedge dz_4}{df}.$$
(5.44)

The normalization condition implies that  $\Omega$  has charge 2, and we have the normalization constant  $\delta$  such that

$$\delta(\sum q_i - 1) = 2 \to \delta = \frac{2}{\sum q_i - 1}.$$
 (5.45)

The mini-versal deformation of the singularity is just:

$$F(z,\lambda) = f(z) + \sum_{\alpha=1}^{\mu} \lambda_{\alpha} \phi_{\alpha}.$$
 (5.46)

What is the field theory interpretation of these deformations? Here  $\phi_{\alpha} = \prod z_i^{n_i}$  is the monomial basis of the Jacobi algebra  $J_f$  of  $f^{-14}$ . Each  $\phi_{\alpha}$  has  $U(1)_R$  charge  $R(\phi_{\alpha}) = \frac{2\sum n_i q_i}{\sum q_i - 1}$ , and the parameter  $\lambda_{\alpha}$  has  $U(1)_R$  charge  $R(\lambda_{\alpha}) = \frac{2(1-\sum n_i q_i)}{\sum q_i - 1}$ . The deformation can be classified by the scaling dimension of  $\lambda_{\alpha}$ :

- Relevant deformation:  $[\lambda_{\alpha}] > 0$  or  $\sum n_{\alpha}q_{\alpha} < 1$ .
- Marginal deformation:  $[\lambda_{\alpha}] = 0$  or  $\sum n_{\alpha}q_{\alpha} = 1$ .
- Irrelevant deformation:  $[\lambda_{\alpha}] < 0$  or  $\sum n_{\alpha}q_{\alpha} > 1$ .

For hypersurface singularity, generically there is no global symmetry besides the R symmetry, and the marginal deformations are actually exact marginal [17]. So we conclude that the weight one deformation of the singularity gives the exact marginal deformation.

We can turn on relevant deformation and ask what is the IR SCFT. For the hypersurface singularity, one can actually determine the IR SCFT by using similar trick used in [24]. The idea is by simply taking a scaling limit of the deformed polynomial and get a new quasi-homogeneous singularity from which one can read IR SCFT.

<span id="page-40-1"></span> $<sup>^{14}</sup>J_f$  is defined as the space  $\frac{C[z_1, z_2, z_3, z_4]}{\{\frac{\partial f}{\partial z_1}, \dots, \frac{\partial f}{\partial z_4}\}}$ 

**Example:** Consider the singularity  $f = x_1^2 + x_2^2 + x_3^2$ , and  $x_4$  is free. The field theory is four dimensional  $\mathcal{N} = 2$  affine  $A_1$  quiver. The addition of any monomials to f is flat and is a deformation. A particular simple deformation is  $f' = x_1^2 + x_2^2 + x_3^2 + x_4^{2k}$ . The deformation in the field theory side can be described by adding a superpotential deformation  $\text{Tr}(\Phi_1^k) + \text{Tr}(\Phi_2^k)$  [59] to the affine  $A_1$  quiver corresponding to singularity  $f = x_1^2 + x_2^2 + x_3^2$ .

For resolution of singularity, we have a special kind of resolution called crepant resolution. Given a morphism  $f: Y \to X$ , and it is a crepant resolution if

$$K_V = f^* K_X. (5.47)$$

It is proven that for 3-fold canonical singularity X, one can always have a partial crepant resolution such that Y is Q-factorial and has only terminal singularity. Such resolutions are not unique, but the number of crepant divisor is the same! For toric singularity, one can describe the resolution in a very explicit way [43], for crepant resolution of other hypersurface singularity, see [60].

**Example**: For hypersurface singularity  $f = z_1^2 + z_2^2 + z_3^2 + z_4^2$ , there is a crepant resolution such that the exceptional set is just a curve [20]. On the other hand, hypersurface singularity  $f = z_1^2 + z_2^2 + z_3^2 + z_4^3$  is already Q-factorial and is a terminal singularity, so it does not admit a crepant resolution.

From the field theory point of view, it seems that the corresponding field theory for the resolved geometry might be described by fractional branes [61]. Namely, if a quiver gauge theory is known for the original singularity X, then the field theory for resolved geometry might be described by changing the rank of the quiver nodes. See [62–64] for more discussions on this issue. The dynamics of these deformed field theory is very interesting and we plan to study them in the future.

#### <span id="page-41-0"></span>5.4 Extended objects

We have mainly discussed how to find the information of local operators of field theory from geometry of SE manifold, and now we would like to discuss the extended object of field theory. Let's first summarize some topological properties of SE manifold. The fundamental group of a manifold with positive Ricci curvature is finite, and so the first and fourth integral homology group of SE manifold is finite. For simply connected SE manifold, the torsion group of  $H_2(L_X, Z)$  is quite constrained. One can get extended objects by wrapping branes on these non-trivial homology cycles:

**Strings**: One can get strings in  $AdS_5$  space by: a): unwrapped F1 and D1 string; b) wrapping D3 brane one two cycles; c): wrapping D5, NS5 brane on four cycles. These objects are related to line operators of field theory.

**Membranes**: One can get membranes in  $AdS_5$  space by: a): wrapping D3 brane on one cycle; b): wrapping D5, NS5 brane on three cycles. These objects are related to surface defects of field theory.

**Domain walls**: One can get domain walls in  $AdS_5$  space by: a): unwrapped D3 branes; b): wrapping D5, NS5 branes on two cycles; c): wrapping D7 brane on four cycle. These objects are related to domain wall of field theory.

More generally, one can get extended BPS objects in  $AdS_5$  space [65] by wrapping various p branes on calibrated cycles in  $SE_5$ . The calibrated cycle in  $SE_5$  is defined using its extension to the cone: i.e. An odd dimensional cycle in  $SE_5$  is holomorphic if its extension to the cone X is holomorphic; and a two dimensional cycle in  $SE_5$  is special Lagrangian if its three dimensional extension to X is Special Lagrangian (they are called Legendrian submanifold). So we could have calibrated one cycle, two cycle and three cycle in SE manifold.

If one can find Legendrian submanifold (which is two cycle in  $SE_5$ ), one can wrap a D5 brane to get a BPS domain wall for field theory. We actually already studied baryons by wrapping D3 branes one three cycles which is holomorphic in the cone X, see more discussions in [56, 57]. If we use D5 brane on these three cycles, we should get BPS surface defects of field theory.

In general, one could also turn on gauge fields on branes and it is a very interesting question to classify all stable branes on a SE manifold. We leave these quesitons for the future study.

# <span id="page-42-0"></span>6 A conjecture about reducing checking K stability to finite cases

The space of SE manifolds is already quite large due to the results using various sufficient condition methods, see the summary in section 4. The necessary and sufficient condition for the existence is the K stability. While the sufficient condition is technically hard and not optimal, one can actually prove the existence of SE metric for many interesting cases. K stability is technically easier to implement for a given test configuration, but potentially infinite number of test configuration makes it very difficult to get new SE metrics. The known success of using K stability comes from reducing the number of non-trivial test configuration to possibly finite cases, and this is possible mainly for the case with many symmetries, for example, for the toric case, one do not need to consider non-trivial test configuration. To enlarge the space of SE metric by using the method of K stability, one need to have some new insights to reduce the number of test configuration to possibly finite numbers, and the purpose of this section is to propose a conjecture on such reduction based on intuition from field theory.

Let's recall that the definition of K stability of a ring X involves a test configuration and the computation of Futaki invariant. The test configuration is described by a one parameter family of rings such that: a: for  $t \neq 0$ ,  $X_t$  are all isomorphic; b): the central fibre  $X_0$  is different from  $X_t$  for non-trivial test configuration, and  $X_0$  has one more dimensional automorphism group if  $X_0 \neq X_t$ . The Futaki invariant is computed by using Hilbert series:

$$H(s) = \frac{a_0}{s^3} + \frac{a_1}{s^2} + \dots {(6.1)}$$

In particular, a test configuration with central fibre  $X_0$  destablizes X if one can get a lower  $a_0$  from  $X_0$  (Notice that the range of parameter in symmetry space is restricted to positive half of the new symmetry  $\eta$ .). One could reduce the space of test configurations by using symmetries (if X is toric, then no destablizing nontrivial test configuration.), and requiring  $X_0$  to be normal (i.e. the singularity locus of  $X_0$  is at most one dimensional.). However,

in general, it seems that there are infinite number of test configurations that we need to check.

![](_page_43_Picture_1.jpeg)

Figure 3. A test configuration is a family of rings parameterized by t. X<sup>t</sup> for t 6= 0 are isomorphic, while X0 is different from Xt for non-trivial test configuration.

Let's now interpret the ingredients of K stability in terms of field theory terms. As we discussed in last section, X essentially determines the chiral ring of field theory, and this fact is also true even if C is not K stable. Since K stable singularity gives a SE metric, which in turn defines a four dimensional N = 1 SCFT, so from physical point of view, K stability is equivalent to check that whether X is the chiral ring of a SCFT!

Now the test configuration can be thought of as a one parameter deformation of a theory associated with X0, so finding a test configuration is equivalent to find a UV theory and a one parameter deformation such that the chiral ring of deformed theory is described by X<sup>t</sup> . Let's illustrate this point in more detail. Consider the flat family parameterized by t and the central fibre is X0, X<sup>0</sup> is constrained to be also rational Gorenstein so that we still have a local field theory from D3 branes probing the singularity X0. From X<sup>0</sup> point of view, X<sup>t</sup> is just one parameter deformation of X0. From physical point of view, X<sup>t</sup> is derived as a deformation of field theory associated with X<sup>0</sup> [15](#page-43-0):

$$X_t = X_0 + t \int d^4x d^2\theta \mathcal{O} + c.c. \tag{6.2}$$

Here O is a chiral operator of theory associated with X<sup>0</sup> [16](#page-43-1). We have following two scenarios:

1. if O is relevant, then the theory flows to a new SCFT, and the chiral ring of the IR SCFT might be described by X<sup>t</sup> , but it might be described by a ring X<sup>∞</sup> which is different from X<sup>t</sup> . We are definitely sure that X<sup>0</sup> is not the chiral ring of IR SCFT associated with X<sup>t</sup> .

<span id="page-43-0"></span><sup>15</sup>One should be careful that sometimes O is not an element of chiral ring of X<sup>0</sup> as it might involve the fractional power of certain chiral operators, but the physical picture is still correct.

<span id="page-43-1"></span><sup>16</sup>Here we use superpotential to describe the deformation, and it is possible that the deformation is described by giving an expectation value to certain chiral operators, however, in that case, the deformation is necessarily relevant deformation.

2. if  $\mathcal{O}$  is marginal or irrelevant, then  $X_t$  would flow back to theory associated with  $X_0$ , and  $X_0$  would have larger central charge a as it is the UV theory of  $X_t$ . This also means that  $X_t$  can not be the chiral ring of the IR SCFT.

So from field theory point of view, checking K stability is essentially checking whether  $X_t$  is the chiral ring of the IR SCFT for theory defined using  $X_t$ . K stability involves finding all possible RG flow from a UV theory  $X_0$  and a one parameter deformation t such that the chiral ring of deformed theory is given by  $X_t$ . The deformation necessarily breaks some symmetries of the UV theory as  $\mathcal{O}$  would be charged under some symmetries of  $X_0$ .  $X_0$  destablize  $X_t$  if the interaction is marginal or irrelevant. In principle, the above procedure can only tell us the necessary condition for  $X_t$  to be the chiral ring of the IR SCFT, but in this context, it is also the sufficient condition!

Now here comes one crucial point, from  $X_t$  point of view,  $\mathcal{O}$  would have R charge two! So it appears that one only need to study the test configuration involving (perhaps only single trace) chiral operators of theory  $X_t$  with R charge two!

Let's now implement above observations to hypersurface case. Let's start with an isolated quasi-homogeneous hypersurface singularity  $f:(C^4,0)\to(C,0)$ . As we discussed in section 5.3.2, the deformation parameter before each weight one monomial in f has R charge zero, and it should be associated with an operator with R charge two. So if our above physical observations are true, one only need to consider test configuration involving these weight one monomials.

In hypersurface case, there is a nice way of finding such test configuration. Let's recall how to find an isolated hypersurface singularity with  $C^*$  action. First, we have to include one of the monomials in the set  $(z_0^{a_0}, z_1 z_0^{a_0}, z_2 z_0^{a_0}, z_3 z_0^{a_0})$  in  $f(z_0, z_1, z_2, z_3)$ , otherwise f would have a non-isolated singularity in  $z_0$ . Similarly, we need to include one of monomials in each of the following four sets

$$I = (z_0^{a_0}, z_1 z_0^{a_0}, z_2 z_0^{a_0}, z_3 z_0^{a_0}), II = (z_1^{a_1} z_0, z_1^{a_1}, z_2 z_1^{a_1}, z_3 z_1^{a_1}),$$

$$III = (z_0 z_2^{a_2}, z_1 z_2^{a_2}, z_2^{a_2}, z_3 z_2^{a_2}), IV = (z_3^{a_3} z_0, z_3^{a_3} z_1, z_2 z_3^{a_3}, z_3^{a_3})$$

$$(6.3)$$

We call the monomials within above four sets as extremal monomials. Once we pick four monomials from above sets, one can figure out the weights  $w_i$  of coordinates  $z_i$ , and these weights cut a hyperplane H in  $R^4$ . One might also add other monomials if there are other **positive integral** points on H. Generically the polynomial has just one dimensional  $C^*$  action  $\zeta$ . Now let's consider a test configuration which is generated by a  $C^*$  action  $\eta$ , and the central fibre  $X_0$  should have a two dimensional symmetry group, which implies that the singularity of  $X_0$  is not isolated (generically). Let's now assume that we would like to make  $z_0$  axis to be a singular locus of  $X_0$ , we only need to find a test configuration so that one of term in set I of f has highest weight under the symmetry  $\eta$ . Let's choose  $\eta$  which acts on the coordinates as  $z_i \to t^{b_i} z_i$ , and it is always possible to choose  $b_i$  such that  $z_j z_0^{a_0}$  term has weight one and other monomials having weight zero, so this monomial dropped out in defining equation of  $X_0$ . In practice, there might be more than one terms from set I which is compatible with the weights, and we treat them separately as the action  $\eta$  would be different. Now we would like to make the following conjecture:

**Conjecture 1** For isolated hypersurface singularity  $f(z_0, z_1, z_2, z_3)$ , one only need to consider test configurations which eliminate one of extremal monomials in f.

The above conjecture is true for  $f = z_0^{a_0} + z_1^{a_1} + z_2^{a_2} + z_3^{a_3}$  if the exponents  $a_i$  are pairwise coprime, since the monomials appear in the equation are the only allowed monomial, and the test configuration which eliminates one of the extremal monomial will give the constraint 4.24, which is also sufficient for the existence of SE metric [18]. It is also true for the known examples listed in section 4. It would be interesting to further study above conjecture for general case.

#### <span id="page-45-0"></span>7 Conclusion

We initiated a study of AdS/CFT correspondence between four dimensional  $\mathcal{N}=1$  SCFT and newly discovered five dimensional Sasaki-Einstein manifold  $L_X$ . One could get exact results of field theory from the geometric properties of SE manifold. Given that not much is known about the dynamics of general  $\mathcal{N}=1$  SCFT, we believe this class of theories would provide us a very good framework to learn four dimensional  $\mathcal{N}=1$  SCFT and general properties of AdS/CFT correspondence.

Although the metric is not known explicitly, many field theory properties can be learned by using algebraic geometry tools. On the one hand, we have a three dimensional affine ring X which determines a log terminal singularity. For a quasi-regular SE manifold, one can associate a log del Pezzo surfaces  $(S, \Delta)$ . Many questions about SE manifold can be reduced to the study of X and  $(S, \Delta)$ , which is often much easier to deal with as there are many algebraic geometry tools available. One can greatly expand the list of SE manifolds by using K stability, and now we have a much larger space of four dimensional  $\mathcal{N}=1$  SCFTs. The really nice feature of this class of theories is that many exact questions of field theory can be reliably computed from geometry, which will give us many insights about four dimensional  $\mathcal{N}=1$  SCFT.

Previous studies are mostly focusing on toric singularity (see the review [66, 67]) where many features are not generic, for example, in general case, the SE metric would have moduli, the deformation of singularity is more interesting, and homology group is more rich, etc. More studies are needed to understand the field theory implications of these new geometric features.

We have made some conjectures on testing K stability of complete intersection singularity. It would be interesting to prove whether above conjecture is correct or not. In particular, it would be nice to find out all K stable singularities from table. 2.

In this paper, We mainly use SE manifold to define our field theory and learn their properties through . In second part of this series, we will mainly use field theory tools to study AdS/CFT correspondence.

#### Acknowledgements

We would like to thank Tristan Collins and Yifan Wang for helpful discussions. The work of S.T Yau is supported by NSF grant DMS-1159412, NSF grant PHY- 0937443, and NSF

grant DMS-0804454. The work of DX is supported by Yau Mathematical Science Center at Tsinghua University. D.X would like to thank Caltech for hospitality at the final stage of the completion of this paper.

# <span id="page-46-0"></span>A Three dimensional quasi-homogeneous hypersurface singularity

The three dimensional quasi-homogeneous hypersurface singularity has been classified in [22], and we reproduce it here:

| m     | <i>f</i> /                                                                                                                      | $\overline{\nabla}$                                                                                                                                                                                                                                                                                                                                                                                                        |
|-------|---------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Type  | $f(z_0, z_1, z_2, z_3)$                                                                                                         | $\sum_{i=1}^{n}q_{i}$                                                                                                                                                                                                                                                                                                                                                                                                      |
| Ι     | $z_0^a + z_1^b + z_2^c + z_3^d$                                                                                                 | $\frac{1}{a} + \frac{1}{b} + \frac{1}{c} + \frac{1}{d}$                                                                                                                                                                                                                                                                                                                                                                    |
| II    | $z_0^a + z_1^b + z_2^c + z_2 z_3^d$                                                                                             | $\frac{1}{a} + \frac{1}{b} + \frac{1}{c} + \frac{c-1}{cd}$                                                                                                                                                                                                                                                                                                                                                                 |
| III   | $z_0^a + z_1^b + z_2^c z_3 + z_2 z_3^d$                                                                                         | $\frac{\frac{1}{a} + \frac{1}{b} + \frac{1}{c} + \frac{1}{d}}{\frac{1}{a} + \frac{1}{b} + \frac{1}{c} + \frac{c-1}{cd}}$ $\frac{\frac{1}{a} + \frac{1}{b} + \frac{d-1}{cd-1} + \frac{c-1}{cd-1}}{\frac{1}{a} + \frac{1}{b} + \frac{d-1}{cd-1} + \frac{c-1}{cd-1}}$                                                                                                                                                         |
| IV    | $z_0^a + z_0 z_1^b + z_2^c + z_2 z_3^d$                                                                                         | $\frac{1}{a} + \frac{a-1}{ab} + \frac{1}{c} + \frac{c-1}{cd}$                                                                                                                                                                                                                                                                                                                                                              |
| V     | $z_0^a z_1 + z_0 z_1^b + z_2^c + z_2 z_3^d$                                                                                     | $\frac{b-1}{ab-1} + \frac{a-1}{ab-1} + \frac{1}{c} + \frac{c-1}{cd}$                                                                                                                                                                                                                                                                                                                                                       |
| VI    | $z_0^a z_1 + z_0 z_1^b + z_2^c z_3 + z_2 z_3^d$                                                                                 | $\frac{b-1}{ab-1} + \frac{a-1}{ab-1} + \frac{d-1}{c} + \frac{cd-1}{cd}$                                                                                                                                                                                                                                                                                                                                                    |
| VII   | $z_0^a + z_1^b + z_1 z_2^c + z_2 z_3^d$                                                                                         | $\frac{1}{a} + \frac{1}{b} + \frac{b-1}{bc} + \frac{b(c-1)+1}{bcd}$                                                                                                                                                                                                                                                                                                                                                        |
| VIII  | $z_0^a + z_1^b + z_1 z_2^c + z_1 z_3^d + z_2^p z_3^q,$ $\frac{p(b-1)}{bc} + \frac{q(b-1)}{bd} = 1$                              | $ \frac{a + b + cd - 1 + cd - 1}{\frac{1}{a} + \frac{a - 1}{ab} + \frac{1}{c} + \frac{c - 1}{cd}} $ $ \frac{b - 1}{ab - 1} + \frac{a - 1}{ab - 1} + \frac{1}{c} + \frac{c - 1}{cd} $ $ \frac{b - 1}{ab - 1} + \frac{a - 1}{ab - 1} + \frac{d - 1}{c} + \frac{cd - 1}{cd} $ $ \frac{1}{a} + \frac{1}{b} + \frac{b - 1}{bc} + \frac{b(c - 1) + 1}{bcd} $ $ \frac{1}{a} + \frac{1}{b} + \frac{b - 1}{bc} + \frac{b - 1}{bd} $ |
| IX    | $z_0^a + z_1^b z_3 + z_2^c z_3 + z_1 z_3^d + z_1^p z_2^q,$                                                                      | $\frac{1}{a} + \frac{d-1}{bd-1} + \frac{b(d-1)}{c(bd-1)} + \frac{b-1}{bd-1}$                                                                                                                                                                                                                                                                                                                                               |
|       | $\frac{p(d-1)}{bd-1} + \frac{qb(d-1)}{c(bd-1)} = 1$                                                                             | ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,                                                                                                                                                                                                                                                                                                                                                                                    |
| X     | $z_0^a + z_1^b z_2 + z_2^c z_3 + z_1 z_3^d$                                                                                     | $\frac{1}{a} + \frac{d(c-1)+1}{bcd+1} + \frac{b(d-1)+1}{bcd+1} + \frac{c(b-1)+1}{bcd+1}$                                                                                                                                                                                                                                                                                                                                   |
| XI    | $z_0^a + z_0 z_1^b + z_1 z_2^c + z_2 z_3^d$                                                                                     | $\frac{1}{a} + \frac{d(c-1)+1}{bcd+1} + \frac{b(d-1)+1}{bcd+1} + \frac{c(b-1)+1}{bcd+1}$ $\frac{1}{a} + \frac{a-1}{ab} + \frac{a(b-1)+1}{abc} + \frac{ab(c-1)+(a-1)}{abcd}$                                                                                                                                                                                                                                                |
| XII   | $z_0^a + z_0 z_1^b + z_0 z_2^c + z_1 z_3^d + z_1^p z_2^q$                                                                       | $\frac{1}{a} + \frac{a-1}{ab} + \frac{a-1}{ac} + \frac{a(b-1)+1}{abd}$                                                                                                                                                                                                                                                                                                                                                     |
|       | $\frac{p(a-1)}{ab} + \frac{q(a-1)}{ac} = 1$                                                                                     |                                                                                                                                                                                                                                                                                                                                                                                                                            |
| XIII  | $z_0^a + z_0 z_1^b + z_1 z_2^c + z_1 z_2^d + z_2^p z_2^q$                                                                       | $\frac{1}{a} + \frac{a-1}{ab} + \frac{a-1}{ac} + \frac{a(b-1)+1}{abd}$                                                                                                                                                                                                                                                                                                                                                     |
|       | $\frac{p(a(b-1)+1)}{abc} + \frac{q(a(b-1)+1)}{abd} = 1$                                                                         |                                                                                                                                                                                                                                                                                                                                                                                                                            |
| XIV   | $\frac{p(a(b-1)+1)}{abc} + \frac{q(a(b-1)+1)}{abd} = 1$ $z_0^a + z_0 z_1^b + z_0 z_2^c + z_0 z_3^d + z_1^p z_2^q + z_2^r z_3^s$ | $\frac{1}{a} + \frac{a-1}{ab} + \frac{a-1}{ac} + \frac{a-1}{ad}$                                                                                                                                                                                                                                                                                                                                                           |
|       | $\frac{p(a-1)}{ab} + \frac{q(a-1)}{ac} = 1 = \frac{r(a-1)}{ac} + \frac{s(a-1)}{ad}$                                             |                                                                                                                                                                                                                                                                                                                                                                                                                            |
| XV    | $z_0^a z_1 + z_0 z_1^b + z_0 z_2^c + z_2 z_3^d + z_1^p z_2^q$                                                                   | $\frac{b-1}{ab-1} + \frac{a-1}{ab-1} + \frac{b(a-1)}{c(ab-1)} + \frac{c(ab-1)-b(a-1)}{cd(ab-1)}$                                                                                                                                                                                                                                                                                                                           |
|       | $\frac{p(a-1)}{ab-1} + \frac{qb(a-1)}{c(ab-1)} = 1$                                                                             |                                                                                                                                                                                                                                                                                                                                                                                                                            |
| XVI   | $z_0^a z_1 + z_0 z_1^b + z_0 z_2^c + z_0 z_3^d + z_1^p z_2^q + z_2^r z_3^s$                                                     | $\frac{b-1}{ab-1} + \frac{a-1}{ab-1} + \frac{b(a-1)}{c(ab-1)} + \frac{b(a-1)}{d(ab-1)}$                                                                                                                                                                                                                                                                                                                                    |
|       | $\frac{p(a-1)}{ab-1} + \frac{qb(a-1)}{c(ab-1)} = 1 = \frac{r(a-1)}{ac} + \frac{s(a-1)}{ad}$                                     | , , , , , , , , , , , , , , , , , , , ,                                                                                                                                                                                                                                                                                                                                                                                    |
| XVII  | $z_0^a z_1 + z_0 z_1^b + z_1 z_2^c + z_0 z_3^d + z_1^p z_2^q + z_0^r z_2^s$                                                     | $\frac{b-1}{ab-1} + \frac{a-1}{ab-1} + \frac{a(b-1)}{c(ab-1)} + \frac{b(a-1)}{d(ab-1)}$                                                                                                                                                                                                                                                                                                                                    |
|       | $\frac{p(a-1)}{ab-1} + \frac{qb(a-1)}{d(ab-1)} = 1 = \frac{r(b-1)}{ab-1} + \frac{sa(b-1)}{c(ab-1)}$                             | ω 1 ω 1 ε(ων-1) ω(ων-1)                                                                                                                                                                                                                                                                                                                                                                                                    |
| XVIII | $ z_0^a z_2 + z_0 z_1^b + z_1 z_2^c + z_1 z_3^d + z_2^p z_3^q $                                                                 | $\frac{b(c-1)+1}{abc+1} + \frac{c(a-1)+1}{abc+1} + \frac{a(b-1)+1}{c(abc+1)} + \frac{c(a(b-1)+1)}{d(abc+1)}$                                                                                                                                                                                                                                                                                                               |
|       | $\frac{p(a(b-1)+1)}{abc+1} + \frac{qc[a(b-1)+1]}{d(abc+1)} = 1$                                                                 | $u(u) \in \{1, 1\}$ $u(u) \in \{1, 1\}$ $u(u) \in \{1, 1\}$                                                                                                                                                                                                                                                                                                                                                                |
| XIX   | $z_0^a + z_0 z_1^b + z_2^c z_1 + z_2 z_3^d$                                                                                     | $\frac{[b(d(c-1)+1)-1]}{[b(d(c-1)+1)-1]} + \frac{[d(c(a-1)+1)-1]}{[c(a-1)+1]}$                                                                                                                                                                                                                                                                                                                                             |
|       |                                                                                                                                 | $\frac{\frac{ b(d(c-1)+1)-1}{abcd-1} + \frac{ d(c(a-1)+1)-1}{abcd-1}}{+\frac{[a(b(d-1)+1)-1}{abcd-1} + \frac{[c(a(b-1)+1)-1}{abcd-1}}$                                                                                                                                                                                                                                                                                     |
|       |                                                                                                                                 | aoca-1 $aoca-1$                                                                                                                                                                                                                                                                                                                                                                                                            |

# <span id="page-47-0"></span>B Three dimensional Gorenstein quotient singularity

Three dimensional Gorenstein quotient singularity has been classified in [68], and we reproduce it here:

- (A) Diagonal abelian groups. These can be described using toric geometry.
- (B) Group isomorphic to transitive finite subgroups of  $GL(2, \mathbb{C})$ .
- (C) Group generated by (A) and T.
- (D) Group generated by (C) and Q.
- (E) Group of order 108 generated by S, T, V.
- (F) Group of order 216 generated by (E) and  $P = UVU^{-1}$ .
- (G) Hessian group of order 648 generated by (E) and U.
- (H) Simple group of order 60 isomorphic to alternating group  $A_5$ .
- (I) Simple group of order 168 isomorphic to permutation group generated by (1234567), (142)(356), (12)(35).
- (J) Group of order 180 generated by (H) and F .
- (K) Group of order 504 generated by (I) and F.
- (L) Group G of order 1080 its quotient G/F isomorphic to alternating group  $A_6$ , where  $F = \{I, W, W^2\}$  is the center of SL(3, C), I = identity.

The matrices used above are

$$S = \begin{pmatrix} 1 & 0 & 0 \\ 0 & \omega & 0 \\ 0 & 0 & \omega^2 \end{pmatrix}, \ T = \begin{pmatrix} 0 & 1 & 0 \\ 0 & 0 & 1 \\ 1 & 0 & 0 \end{pmatrix}, \ V = \frac{1}{\sqrt{-3}} \begin{pmatrix} 1 & 1 & 1 \\ 1 & \omega & \omega^2 \\ 1 & \omega^2 & \omega \end{pmatrix}, \tag{B.1}$$

$$U = \begin{pmatrix} \epsilon & 0 & 0 \\ 0 & \epsilon & 0 \\ 0 & 0 & \epsilon \omega \end{pmatrix}, \ P = \frac{1}{\sqrt{-3}} \begin{pmatrix} 1 & 1 & \omega^2 \\ 1 & \omega & \omega \\ \omega & 1 & \omega \end{pmatrix}, \ Q = \frac{1}{\sqrt{-3}} \begin{pmatrix} a & 0 & 0 \\ 0 & 0 & b \\ 0 & c & 0 \end{pmatrix}, \tag{B.2}$$

with  $abc = -1, \omega = e^{\frac{2\pi i}{3}}, \epsilon^2 = \omega^2$ . The A and B type matrices are

$$A = \begin{pmatrix} \alpha & 0 & 0 \\ 0 & \beta & 0 \\ 0 & 0 & \gamma \end{pmatrix}, B = \begin{pmatrix} \alpha & 0 & 0 \\ 0 & a & b \\ 0 & c & d \end{pmatrix}, W = \begin{pmatrix} \omega & 0 & 0 \\ 0 & \omega & 0 \\ 0 & 0 & \omega \end{pmatrix}, \tag{B.3}$$

We have  $\alpha\beta\gamma = 1$  and  $ad - bc = \frac{1}{\alpha}$ .

# References

- <span id="page-48-0"></span>[1] J. M. Maldacena, "The Large N limit of superconformal field theories and supergravity," [Int. J. Theor. Phys.](http://dx.doi.org/10.1023/A:1026654312961) 38 (1999) 1113–1133, [arXiv:hep-th/9711200 \[hep-th\]](http://arxiv.org/abs/hep-th/9711200). [Adv. Theor. Math. Phys.2,231(1998)].
- [2] I. R. Klebanov and E. Witten, "Superconformal field theory on three-branes at a Calabi-Yau singularity," Nucl. Phys. B536 [\(1998\) 199–218,](http://dx.doi.org/10.1016/S0550-3213(98)00654-3) [arXiv:hep-th/9807080 \[hep-th\]](http://arxiv.org/abs/hep-th/9807080).
- <span id="page-48-1"></span>[3] D. R. Morrison and M. R. Plesser, "Nonspherical horizons. 1.," Adv. Theor. Math. Phys. 3 (1999) 1–81, [arXiv:hep-th/9810201 \[hep-th\]](http://arxiv.org/abs/hep-th/9810201).
- <span id="page-48-2"></span>[4] O. Aharony, S. S. Gubser, J. M. Maldacena, H. Ooguri, and Y. Oz, "Large N field theories, string theory and gravity," Phys. Rept. 323 [\(2000\) 183–386,](http://dx.doi.org/10.1016/S0370-1573(99)00083-6) [arXiv:hep-th/9905111 \[hep-th\]](http://arxiv.org/abs/hep-th/9905111).
- <span id="page-48-3"></span>[5] T. C. Collins and G. Sz´ekelyhidi, "Sasaki-einstein metrics and k-stability," arXiv preprint arXiv:1512.07213 (2015) .
- <span id="page-48-4"></span>[6] T. C. Collins, D. Xie, and S.-T. Yau, "K stability and stability of chiral ring," arXiv preprint arXiv:1606.09260 (2016) .
- <span id="page-48-5"></span>[7] A. Futaki, H. Ono, G. Wang, et al., "Transverse k¨ahler geometry of sasaki manifolds and toric sasaki-einstein manifolds," Journal of Differential Geometry 83 (2009) no. 3, 585–636.
- <span id="page-48-6"></span>[8] C. P. Boyer, K. Galicki, and J. Koll´ar, "Einstein metrics on spheres," Annals of mathematics 162 (2005) no. 1, 557–580.
- <span id="page-48-7"></span>[9] S. Franco, A. Hanany, D. Martelli, J. Sparks, D. Vegh, and B. Wecht, "Gauge theories from toric geometry and brane tilings," JHEP 01 [\(2006\) 128,](http://dx.doi.org/10.1088/1126-6708/2006/01/128) [arXiv:hep-th/0505211 \[hep-th\]](http://arxiv.org/abs/hep-th/0505211).
- <span id="page-48-8"></span>[10] J. P. Gauntlett, D. Martelli, J. Sparks, D. Waldram, et al., "Sasaki-einstein metrics on s <sup>2</sup> <sup>×</sup> <sup>s</sup> 3 ," Advances in Theoretical and Mathematical Physics 8 (2004) no. 4, 711–734.
- <span id="page-48-9"></span>[11] J. Koll´ar, "Einstein metrics on five-dimensional seifert bundles," Journal of Geometric Analysis 15 (2005) no. 3, 445–476.
- <span id="page-48-10"></span>[12] H. Osborn, "N=1 superconformal symmetry in four-dimensional quantum field theory," Annals Phys. 272 [\(1999\) 243–294,](http://dx.doi.org/10.1006/aphy.1998.5893) [arXiv:hep-th/9808041 \[hep-th\]](http://arxiv.org/abs/hep-th/9808041).
- <span id="page-48-11"></span>[13] E. Witten, "Constraints on supersymmetry breaking," Nuclear Physics B 202 (1982) no. 2, 253–316.
- <span id="page-48-12"></span>[14] J. Kinney, J. M. Maldacena, S. Minwalla, and S. Raju, "An Index for 4 dimensional super conformal theories," [Commun. Math. Phys.](http://dx.doi.org/10.1007/s00220-007-0258-7) 275 (2007) 209–254, [arXiv:hep-th/0510251 \[hep-th\]](http://arxiv.org/abs/hep-th/0510251).
- <span id="page-48-13"></span>[15] F. Cachazo, M. R. Douglas, N. Seiberg, and E. Witten, "Chiral rings and anomalies in supersymmetric gauge theory," Journal of High Energy Physics 2002 (2003) no. 12, 071.
- <span id="page-48-14"></span>[16] K. A. Intriligator and B. Wecht, "The Exact superconformal R symmetry maximizes a," Nucl. Phys. B667 [\(2003\) 183–200,](http://dx.doi.org/10.1016/S0550-3213(03)00459-0) [arXiv:hep-th/0304128 \[hep-th\]](http://arxiv.org/abs/hep-th/0304128).
- <span id="page-48-15"></span>[17] D. Green, Z. Komargodski, N. Seiberg, Y. Tachikawa, and B. Wecht, "Exactly Marginal Deformations and Global Symmetries," JHEP 06 [\(2010\) 106,](http://dx.doi.org/10.1007/JHEP06(2010)106) [arXiv:1005.3546 \[hep-th\]](http://arxiv.org/abs/1005.3546).
- <span id="page-48-16"></span>[18] C. Boyer and K. Galicki, Sasakian geometry. Oxford Univ. Press, 2008.
- <span id="page-48-17"></span>[19] J. Sparks, "Sasaki-einstein manifolds," arXiv preprint arXiv:1004.2461 (2010) .

- <span id="page-49-0"></span>[20] M. Reid, "Canonical 3-folds, journees de geometrie algebrique d'angers," Sijthoff and Nordhoff (1980) 273–310.
- <span id="page-49-1"></span>[21] Y. Wang and D. Xie, "Classification of argyres-douglas theories from m5 branes," Physical Review D 94 (2016) no. 6, 065012.
- <span id="page-49-2"></span>[22] S. S.-T. YAU and Y. YU, "Classification of 3-dimensional isolated rational hypersurface singularities with c-action," JOURNAL OF MATHEMATICS 35 (2005) no. 5, .
- <span id="page-49-3"></span>[23] B. Chen, D. Xie, S.-T. Yau, S. S. T. Yau, and H. Zuo, "4D N = 2 SCFT and singularity theory. Part II: complete intersection," [Adv. Theor. Math. Phys.](http://dx.doi.org/10.4310/ATMP.2017.v21.n1.a2) 21 (2017) 121–145, [arXiv:1604.07843 \[hep-th\]](http://arxiv.org/abs/1604.07843).
- <span id="page-49-4"></span>[24] D. Xie and S.-T. Yau, "4d N=2 SCFT and singularity theory Part I: Classification," [arXiv:1510.01324 \[hep-th\]](http://arxiv.org/abs/1510.01324).
- <span id="page-49-5"></span>[25] E. Looijenga, Isolated singular points on complete intersections, vol. 77. Cambridge University Press, 1984.
- <span id="page-49-6"></span>[26] A. Moroianu, "Parallel and killing spinors on spinc manifolds," Communications in mathematical physics 187 (1997) no. 2, 417–427.
- <span id="page-49-7"></span>[27] T. C. Collins, D. Xie, and S.-T. Yau, "K stability and stability of chiral ring," [arXiv:1606.09260 \[hep-th\]](http://arxiv.org/abs/1606.09260).
- <span id="page-49-8"></span>[28] S. K. Donaldson, "Scalar curvature and stability of toric varieties," Journal of Differential Geometry 62 (2002) no. 2, 289–349.
- <span id="page-49-9"></span>[29] R. P. Stanley, "Hilbert functions of graded algebras," Advances in Mathematics 28 (1978) no. 1, 57–83.
- <span id="page-49-10"></span>[30] V. Datar and G. Sz´ekelyhidi, "Kahler-einstein metrics along the smooth continuity method," arXiv preprint arXiv:1506.07495 (2015) .
- <span id="page-49-11"></span>[31] J. Koll´ar, "Positive sasakian structures on 5-manifolds," Riemannian Topology and Geometric Structures on Manifolds (2009) 93–117.
- <span id="page-49-12"></span>[32] D. Martelli, J. Sparks, and S.-T. Yau, "Sasaki–einstein manifolds and volume minimisation," Communications in Mathematical Physics 280 (2008) no. 3, 611–673.
- <span id="page-49-13"></span>[33] P. Orlik, "On the homology of weighted homogeneous manifolds," in Proceedings of the Second Conference on Compact Transformation Groups, pp. 260–269, Springer. 1972.
- <span id="page-49-14"></span>[34] J. P. Gauntlett, D. Martelli, J. Sparks, and S.-T. Yau, "Obstructions to the existence of sasaki–einstein metrics," Communications in mathematical physics 273 (2007) no. 3, 803–827.
- <span id="page-49-15"></span>[35] T. C. Collins and G. Sz´ekelyhidi, "K-semistability for irregular sasakian manifolds," arXiv preprint arXiv:1204.2230 (2012) .
- <span id="page-49-16"></span>[36] C. P. Boyer and M. Nakamaye, "On sasaki-einstein manifolds in dimension five," Geometriae Dedicata 144 (2010) no. 1, 141–156.
- <span id="page-49-17"></span>[37] M. Miyanishi and D.-Q. Zhang, "Gorenstein log del pezzo surfaces of rank one," Journal of Algebra 118 (1988) no. 1, 63–84.
- [38] M. Miyanishi and D.-Q. Zhang, "Gorenstein log del pezzo surfaces, ii," Journal of Algebra 156 (1993) no. 1, 183–193.

- <span id="page-50-0"></span>[39] Q. Ye, "On gorenstein log del pezzo surfaces," Japanese journal of mathematics. New series 28 (2002) no. 1, 87–136.
- <span id="page-50-1"></span>[40] D. Kosta, "Del pezzo surfaces with du val singularities," arXiv preprint arXiv:0904.0943 (2009) .
- <span id="page-50-2"></span>[41] M. B. Green, E. Witten, and J. H. Schwarz, "Superstring theory vol. 2,".
- <span id="page-50-3"></span>[42] J. Polchinski, String theory: Volume 2, superstring theory and beyond. Cambridge university press, 1998.
- <span id="page-50-4"></span>[43] D. A. Cox, J. B. Little, and H. K. Schenck, Toric varieties. American Mathematical Soc., 2011.
- <span id="page-50-5"></span>[44] K. Altmann, N. O. Ilten, L. Petersen, H. S, and R. Vollmert, "The geometry of t-varieties," IMPANGA Lecture Notes. Contributions to Algebraic Geometry (2012) 17–69.
- <span id="page-50-6"></span>[45] E. Witten, "Anti-de Sitter space and holography," Adv. Theor. Math. Phys. 2 (1998) 253–291, [arXiv:hep-th/9802150 \[hep-th\]](http://arxiv.org/abs/hep-th/9802150).
- <span id="page-50-7"></span>[46] H. J. Kim, L. J. Romans, and P. van Nieuwenhuizen, "The Mass Spectrum of Chiral N=2 D=10 Supergravity on S\*\*5," Phys. Rev. D32 [\(1985\) 389.](http://dx.doi.org/10.1103/PhysRevD.32.389)
- <span id="page-50-11"></span>[47] A. Ceresole, G. Dall?Agata, R. D?Auria, and S. Ferrara, "Spectrum of type iib supergravity on ads 5× t 11: predictions on n= 1 scft?s," Physical Review D 61 (2000) no. 6, 066001.
- <span id="page-50-8"></span>[48] R. Eager, J. Schmude, and Y. Tachikawa, "Superconformal Indices, Sasaki-Einstein Manifolds, and Cyclic Homologies," [Adv. Theor. Math. Phys.](http://dx.doi.org/10.4310/ATMP.2014.v18.n1.a3) 18 (2014) no. 1, 129–175, [arXiv:1207.0573 \[hep-th\]](http://arxiv.org/abs/1207.0573).
- <span id="page-50-9"></span>[49] C. Stromenger, Sasakian manifolds: differential forms, curvature and conformal killing forms. PhD thesis, Universit¨at zu K¨oln, 2010.
- <span id="page-50-10"></span>[50] J. Schmude, "Laplace operators on Sasaki-Einstein manifolds," JHEP 04 [\(2014\) 008,](http://dx.doi.org/10.1007/JHEP04(2014)008) [arXiv:1308.1027 \[hep-th\]](http://arxiv.org/abs/1308.1027).
- <span id="page-50-12"></span>[51] O. Goertsches, H. Nozawa, and D. Toeben, "Rigidity and vanishing of basic dolbeault cohomology of sasakian manifolds," arXiv preprint arXiv:1206.2803 (2012) .
- <span id="page-50-13"></span>[52] D. Martelli, J. Sparks, and S.-T. Yau, "Sasaki-Einstein manifolds and volume minimisation," [Commun. Math. Phys.](http://dx.doi.org/10.1007/s00220-008-0479-4) 280 (2008) 611–673, [arXiv:hep-th/0603021 \[hep-th\]](http://arxiv.org/abs/hep-th/0603021).
- <span id="page-50-14"></span>[53] D. Berenstein, C. P. Herzog, and I. R. Klebanov, "Baryon spectra and AdS /CFT correspondence," JHEP 06 [\(2002\) 047,](http://dx.doi.org/10.1088/1126-6708/2002/06/047) [arXiv:hep-th/0202150 \[hep-th\]](http://arxiv.org/abs/hep-th/0202150).
- [54] K. A. Intriligator and B. Wecht, "Baryon charges in 4-D superconformal field theories and their AdS duals," [Commun. Math. Phys.](http://dx.doi.org/10.1007/s00220-003-1023-1) 245 (2004) 407–424, [arXiv:hep-th/0305046 \[hep-th\]](http://arxiv.org/abs/hep-th/0305046).
- <span id="page-50-15"></span>[55] C. P. Herzog and J. Walcher, "Dibaryons from exceptional collections," JHEP 09 [\(2003\) 060,](http://dx.doi.org/10.1088/1126-6708/2003/09/060) [arXiv:hep-th/0306298 \[hep-th\]](http://arxiv.org/abs/hep-th/0306298).
- <span id="page-50-16"></span>[56] C. E. Beasley, "BPS branes from baryons," JHEP 11 [\(2002\) 015,](http://dx.doi.org/10.1088/1126-6708/2002/11/015) [arXiv:hep-th/0207125 \[hep-th\]](http://arxiv.org/abs/hep-th/0207125).
- <span id="page-50-17"></span>[57] A. Mikhailov, "Giant gravitons from holomorphic surfaces," JHEP 11 [\(2000\) 027,](http://dx.doi.org/10.1088/1126-6708/2000/11/027) [arXiv:hep-th/0010206 \[hep-th\]](http://arxiv.org/abs/hep-th/0010206).
- <span id="page-50-18"></span>[58] O. Lunin and J. M. Maldacena, "Deforming field theories with U(1) x U(1) global symmetry and their gravity duals," JHEP 05 [\(2005\) 033,](http://dx.doi.org/10.1088/1126-6708/2005/05/033) [arXiv:hep-th/0502086 \[hep-th\]](http://arxiv.org/abs/hep-th/0502086).

- <span id="page-51-0"></span>[59] F. Cachazo, B. Fiol, K. A. Intriligator, S. Katz, and C. Vafa, "A Geometric unification of dualities," Nucl. Phys. B628 [\(2002\) 3–78,](http://dx.doi.org/10.1016/S0550-3213(02)00078-0) [arXiv:hep-th/0110028 \[hep-th\]](http://arxiv.org/abs/hep-th/0110028).
- <span id="page-51-1"></span>[60] D. Xie and S.-T. Yau, "Three dimensional canonical singularity and five dimensional N = 1 SCFT," JHEP 06 [\(2017\) 134,](http://dx.doi.org/10.1007/JHEP06(2017)134) [arXiv:1704.00799 \[hep-th\]](http://arxiv.org/abs/1704.00799).
- <span id="page-51-2"></span>[61] I. R. Klebanov and M. J. Strassler, "Supergravity and a confining gauge theory: Duality cascades and chi SB resolution of naked singularities," JHEP 08 [\(2000\) 052,](http://dx.doi.org/10.1088/1126-6708/2000/08/052) [arXiv:hep-th/0007191 \[hep-th\]](http://arxiv.org/abs/hep-th/0007191).
- <span id="page-51-3"></span>[62] S. Franco, A. Hanany, F. Saad, and A. M. Uranga, "Fractional branes and dynamical supersymmetry breaking," JHEP 01 [\(2006\) 011,](http://dx.doi.org/10.1088/1126-6708/2006/01/011) [arXiv:hep-th/0505040 \[hep-th\]](http://arxiv.org/abs/hep-th/0505040).
- [63] S. Pinansky, "Quantum deformations from toric geometry," JHEP 03 [\(2006\) 055,](http://dx.doi.org/10.1088/1126-6708/2006/03/055) [arXiv:hep-th/0511027 \[hep-th\]](http://arxiv.org/abs/hep-th/0511027).
- <span id="page-51-4"></span>[64] A. Butti, "Deformations of Toric Singularities and Fractional Branes," JHEP 10 [\(2006\) 080,](http://dx.doi.org/10.1088/1126-6708/2006/10/080) [arXiv:hep-th/0603253 \[hep-th\]](http://arxiv.org/abs/hep-th/0603253).
- <span id="page-51-5"></span>[65] S. Yamaguchi, "AdS branes corresponding to superconformal defects," JHEP 06 [\(2003\) 002,](http://dx.doi.org/10.1088/1126-6708/2003/06/002) [arXiv:hep-th/0305007 \[hep-th\]](http://arxiv.org/abs/hep-th/0305007).
- <span id="page-51-6"></span>[66] K. D. Kennaway, "Brane Tilings," [Int. J. Mod. Phys.](http://dx.doi.org/10.1142/S0217751X07036877) A22 (2007) 2977–3038, [arXiv:0706.1660 \[hep-th\]](http://arxiv.org/abs/0706.1660).
- <span id="page-51-7"></span>[67] M. Yamazaki, "Brane Tilings and Their Applications," Fortsch. Phys. 56 [\(2008\) 555–686,](http://dx.doi.org/10.1002/prop.200810536) [arXiv:0803.4474 \[hep-th\]](http://arxiv.org/abs/0803.4474).
- <span id="page-51-8"></span>[68] S. S.-T. Yau and Y. Yu, Gorenstein quotient singularities in dimension three, vol. 505. American Mathematical Soc., 1993.