# Equivalence of A-Maximization and Volume Minimization

#### Richard Eager[1](#page-0-0)

Department of Physics University of California Santa Barbara, CA 93106, USA and Institute for the Physics and Mathematics of the Universe The University of Tokyo Kashiwa, Chiba 277-8582, Japan

#### Abstract

The low energy effective theory on a stack of D3-branes at a Calabi-Yau singularity is an N = 1 quiver gauge theory. The AdS/CFT correspondence predicts that the strong coupling dynamics of the gauge theory is described by weakly coupled type IIB supergravity on AdS5×L 5 , where L 5 is a Sasaki-Einstein manifold. Recent results on Calabi-Yau algebras efficiently determine the Hilbert series of any superconformal quiver gauge theory. We use the Hilbert series to determine the volume of the horizon manifold in terms of the fields of the quiver gauge theory. One corollary of the AdS/CFT conjecture is that the volume of the horizon manifold L 5 is inversely proportional to the a-central charge of the gauge theory. By direct comparison of the volume determined from the Hilbert series and the a-central charge, this prediction is proved independently of the AdS/CFT conjecture.

<span id="page-0-0"></span><sup>1</sup> [reager@physics.ucsb.edu](mailto:reager@physics.ucsb.edu)

## Contents

| 1 | Introduction                                                                                                                                              | 2                          |
|---|-----------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------|
| 2 | Predictions from AdS/CFT                                                                                                                                  | 3                          |
| 3 | Quiver Gauge Theories                                                                                                                                     | 6                          |
| 4 | Baryonic and Flavor Symmetries                                                                                                                            | 7                          |
| 5 | A-Maximization                                                                                                                                            | 8                          |
| 6 | Calabi-Yau Algebras                                                                                                                                       | 9                          |
| 7 | Non-Commutative Crepant Resolutions                                                                                                                       | 12                         |
| 8 | Volume Minimization                                                                                                                                       | 13                         |
| 9 | Hilbert Series                                                                                                                                            | 14                         |
|   | 10 Examples<br>C<br>3<br>10.1<br><br>10.2 Conifold<br>                                                                                                    | 15<br>15<br>16             |
|   | 11 Perturbative Expansion of the Hilbert Series<br>11.1 Overview<br>11.2 The Smallest Eigenvalue<br><br>11.3 Absence of Mixing<br><br>11.4 Positivity<br> | 16<br>16<br>20<br>21<br>22 |
|   | 12 Conclusion                                                                                                                                             | 23                         |
|   | 13 Acknowledgments                                                                                                                                        | 24                         |

## <span id="page-2-0"></span>1 Introduction

Maldacena's original AdS/CFT correspondence relates type IIB string theory on AdS5× S 5 to N = 4 supersymmetric Yang-Mills in Minkowski space. Several authors [\[1,](#page-24-1) [2\]](#page-24-2) realized that this correspondence could be extended to cases with fewer supersymmetries. If the five-sphere is replaced by another five-dimensional manifold L 5 , N = 1 SUSY is preserved only if L 5 is Sasaki-Einstein. For these manifolds Gubser, [\[3,](#page-24-3) [4\]](#page-25-0) proposed a simple yet powerful prediction of the AdS/CFT correspondence. Proper normalization of the AdS 3-point functions ensures that the volume of the Sasaki-Einstein manifold is inversely proportional to the central charge a,

$$\operatorname{Vol}(L^5) \propto \frac{\pi^3}{4} \frac{1}{a}.$$

The a-central charge of a 4D SCFT quiver gauge theory can be determined through a variational procedure called a-maximization developed by Intriligator and Wecht [\[5\]](#page-25-1). Martelli, Sparks, and Yau [\[6,](#page-25-2) [7\]](#page-25-3) proposed that the dual variational problem is minimizing the volume of the horizon manifold over all possible choices of a "Reeb" vector.

We show the equivalence of these two procedures by describing volume minimization in terms of the fields of the quiver. The volume of the horizon manifold is governed by the asymptotic growth of the number of holomorphic functions on its metric cone X = C(L 5 ) [\[8\]](#page-25-4). Using the correspondence between holomorphic functions on X and mesonic operators in the quiver, we express the Hilbert series in terms of mesonic operators. Using this correspondence, we formulate volume minimization entirely in terms of the fields of the quiver gauge theory. We will perturbatively expand the expression for the volume. Several terms in the expression vanish from constraints from N = 1 superconformal field theories. After the cancellations are accounted for, we will see that the expressions for volume minimization and a-maximization are identical.

For toric Calabi-Yau singularities, the relationship between the a-central charge and volume has already been established [\[9,](#page-25-5) [10\]](#page-25-6). Our proof applies to both toric and nontoric singularities. While branes at toric singularities have been extensively studied [\[11\]](#page-25-7), far less is known about branes at general Calabi-Yau singularities.

Our plan for the paper is as follows. We first review the relation between the volume and a-central charge predicted by the AdS/CFT correspondence. Next we introduce the general structure of quiver gauge theories and explain the role of baryonic symmetries in quiver gauge theories and their supergravity duals. The subsequent sections form the mathematical core of this paper. Section [6](#page-9-0) introduces Calabi-Yau algebras, which mathematically characterize quiver gauge theories that flow to N = 1 superconformal field theories in the infrared. The next section introduces the stronger notion of a "non-commutative crepant resolution." Non-commutative crepant resolutions describe the N = 1 superconformal field theories which can be engineered from D3-branes at Calabi-Yau singularities. These will be the main source of Calabi-Yau algebras in this paper. Using the projective resolution of modules, a property satisfied by Calabi-Yau algebras, we will explain how to to compute the Hilbert series of a quiver gauge theory in section [9.](#page-14-0) Examples of Hilbert series are given in section [10.](#page-15-0) We review the gauge theories associated to C <sup>3</sup> and the conifold and show how the Hilbert series correctly determines the volume of their horizon manifolds. Finally in section [11,](#page-16-1) we prove the equivalence of a-maximization and volume minimization for general quiver gauge theories.

# <span id="page-3-0"></span>2 Predictions from AdS/CFT

The AdS/CFT correspondence between type IIB string theory with N D3-branes at a local Calabi-Yau singularity X and type IIB string theory on AdS<sup>5</sup> × L 5 leads to a rich interplay between gauge theory, supergravity, and mathematics. In the low-energy limit, the correspondence is a realization of holography [\[12,](#page-25-8) [13\]](#page-25-9). At low energies, the correspondence is between a gauged supergravity theory on AdS<sup>5</sup> and a superconformal field theory living on the boundary of AdS5. We focus on the limit where the number, N, of D3-branes is large. For the low energy effective field theory on the D3-brane world-volume to have N = 1 supersymmetry, X must be Calabi-Yau, possibly with Gorenstein singularities. We will consider only isolated Gorenstein[1](#page-3-1) singularities so that the near horizon limit can easily be defined. Furthermore, we only consider Gorenstein singularities that can be realized as a metric cone over a Sasaki-Einstein base L 5 . As emphasized in [\[14\]](#page-25-10), not all Gorenstein singularities satisfy this property. For the supergravity theory to have N = 1 supersymmetry, L <sup>5</sup> must be Sasaki-Einstein. An odd dimensional Riemannian manifold L is Sasakian if its metric cone (C(L), gL) with

$$g_{C(L)} = dr^2 + r^2 g_L$$

is K¨ahler. The K¨ahler condition implies that C(L) contains an almost-complex structure J. If additionally the metric cone C(L) is a possibly singular Calabi-Yau, then L is called Sasaki-Einstein. Every Sasaki-Einstein manifold posses a distinguished vector field

$$\xi = J\left(r\frac{\partial}{\partial r}\right)$$

<span id="page-3-1"></span><sup>1</sup>An isolated complex threefold singularity is Gorensein if it has a no-where vanishing holomorphic three form Ω<sup>3</sup>,<sup>0</sup> that is well-defined away from the singular point.

called the Reeb vector field. The symmetry generated by the Reeb vector field is dual to the R-symmetry of the superconformal gauge theory. If the orbits of the Reeb vector close, then L 5 is either regular or quasi-regular. This is dual to the field theory having a compact R-symmetry group, isomorphic to U(1) . If the orbits of the Reeb vector do not close, then L 5 is an irregular Sasaki-Einstein manifold and the R-symmetry group of the dual gauge theory is non-compact and isomorphic to R.

The AdS/CFT correspondence matches the isometries of the supergravity theory to global symmetries of the dual four dimensional superconformal field theory. The four dimensional superconformal algebra psu(2, 2|1) contains the bosonic subalgebra so(4, 2) × u(1)R. Under the AdS/CFT correspondence, the SO(4, 2) global symmetry group matches the isometry group of AdS5. Every Sasaki-Einstein manifold has a symmetry generated by the Reeb vector field. Under the AdS/CFT correspondence, this symmetry maps to the R-symmetry of the field theory. We will consider the dimensional reduction of IIB supergravity on L 5 . There are b 3 (L 5 ) gauge fields A<sup>I</sup> , I = 1, . . . b<sup>3</sup> (L 5 ) from dimensional reduction of the RR four-form. There is an additional U(1) gauge field from the Kaluza-Klein reduction of the graviton. If L <sup>5</sup> possesses isometries in addition to the one generated by the Reeb vector field, then the field theory has additional mesonic flavor symmetries [\[15,](#page-25-11) [16\]](#page-25-12), which we will review in section [4.](#page-7-0) Under the AdS/CFT correspondence, the bulk gauge fields correspond to global symmetries of the boundary field theory. In addition to the matching of symmetries, the AdS/CFT correspondence predicts a precise relationship between correlation functions.

Suppose the AdS<sup>5</sup> theory has gauge group G of rank |G| and gauge fields A<sup>I</sup> , I = 1, . . . |G|. The gauge symmetries are mapped to global symmetries of the boundary theory with corresponding currents J<sup>I</sup> . Gubser, Klebanov, Polyakov, and Witten [\[17,](#page-25-13) [18\]](#page-25-14) proposed the following way to match partition functions between the CFT and SUGRA theories. Background gauge fields A<sup>I</sup> 0 turned on in the CFT can be extended to gauge fields A<sup>I</sup> in the interior of AdS<sup>5</sup> in a unique manner up to gauge transformations. The partition function of the CFT with background fields A<sup>I</sup> 0 equals the SUGRA partition function with the restriction that the components of the dynamical gauge fields A<sup>I</sup> approach the CFT background fields A<sup>I</sup> 0 at the boundary of AdS5. We schematically represent this as

$$Z[A_0^I]_{CFT} = Z_{SUGRA}[A^I|_{\partial AdS_5} = A_0^I].$$

Here the CFT generating functional is

$$Z[A_0^I]_{CFT} = \left\langle \exp\left(\int J_I A_0^I\right) \right\rangle_{CFT}.$$

Under the GKP/W prescription, the gauge symmetry of the AdS gauge fields, A<sup>I</sup> → A<sup>I</sup> + ∂χ<sup>I</sup> , translates directly into the condition that the CFT currents are conserved, ∂µJ µ <sup>I</sup> = 0. Since the AdS/CFT correspondence is a weak-strong duality, it is usually difficult to test the equivalence of correlation functions. For the original AdS/CFT correspondence with N = 4 supersymmetry, the additional supersymmetry has enabled extensive tests of the correspondence. For theories with only N = 1 supersymmetry, there are very few quantities we can compute at strong coupling. However, we can still try to match global anomalies, which are one-loop exact and therefore computable at strong coupling. The U(1) global symmetries are exact symmetries of the quantum theory. When coupled to external gauge fields, these symmetries can have ABJ [\[19,](#page-25-15) [20\]](#page-26-0) type triangle anomalies.

A direct check of AdS/CFT can be made by showing that the the three-point functions on both sides of the correspondence match. For anomalies, there is an elegant method that is equivalent to matching the three-point functions of the anomalous currents. Witten [\[18\]](#page-25-14) observed that the 5d Chern-Simons term in the AdS<sup>5</sup> supergravity action is not gauge invariant. Under a gauge transformation, the 5d Chern-Simons term gains a boundary term. Under the GKP/W prescription, this term becomes precisely the 4D ABJ anomaly in the boundary SCFT.

Four dimensional superconformal field theories are parametrized by two central charges, a and c. The central charges can be read off from the two- and three-point function of the stress energy tensor. Alternatively, the anomaly coefficients can be computed from Weyl anomalies. Since the stress energy tensor is a composite operator, it must be appropriately regularized. Conformal symmetry requires that the trace of the stress tensor vanishes. However, the trace and regularization procedures do not commute, and their failure to do so leads to the Weyl anomaly. For any theory with a large N holographic dual, the a and c central charges must be equal [\[4\]](#page-25-0). This is automatically the case for superconformal quiver gauge theories [\[21\]](#page-26-1) [\[22\]](#page-26-2). The difference a − c is proportional to Tr R = 0 to leading order in N. For a superconformal quiver, the condition Tr R = 0 can be seen by taking the linear combination of the NSVZ beta functions [\[23\]](#page-26-3) weighted by the ranks of the gauge groups.

Since the stress energy tensor and the R-symmetry current both reside in the same supersymmetry multiplet, the a central charge can be written as

$$a = \frac{3}{32} \left( 3 \operatorname{Tr} R^3 - \operatorname{Tr} R \right).$$

The trace is over all the fields, and R is the R-charge under the IR R-symmetry.

Either by matching 3-point functions or generalizing Witten's argument, the AdS/CFT correspondence predicts that the volume of the Sasaki-Einstein manifold is inversely proportional to the central charge a,

$$\operatorname{Vol}(L^5) = \frac{\pi^3 N^2}{4a}.$$

After reviewing the general properties of quiver gauge theories, we will explain how the a-central charge is determined by Intriligator and Wecht's a-maximization procedure.

## <span id="page-6-0"></span>3 Quiver Gauge Theories

The world-volume gauge theory on a stack of D3-branes at a Calabi-Yau singularity is often described by a quiver gauge theory. A quiver Q = (V, A, h, t : A → V ) is a collection of vertices V and arrows A between the vertices of the quiver. The arrows are directed edges with the head and tail of an arrow a ∈ A given by maps h(a) and t(a), respectively. A representation X of a quiver is an assignment of C-vector spaces X<sup>v</sup> to every vertex v ∈ V and a C−linear map φ<sup>a</sup> : Xt(a) → Xh(a) to every arrow a ∈ A. The dimension vector n ∈ N <sup>|</sup><sup>V</sup> <sup>|</sup> of a representation X is a vector with an entry for each vertex v ∈ V equal to the dimension of the vector space Xv.

A quiver gauge theory is specified by a quiver and a superpotential in the following manner:

• The gauge group

$$G = \prod_{v \in V} U(n_v)$$

is a product of unitary groups U(nv) of dimension nv.

- Arrows a ∈ A represent chiral superfields Φ<sup>a</sup> transforming in the fundamental representation of U(nh(a)) and in the anti-fundamental representation of U(nt(a)). If the two vertices are distinct, the chiral superfields are called bifundamental fields. Otherwise, the arrow is a loop and the field transforms in the adjoint representation.
- The superpotential

$$W = \sum_{l=a_1 a_2 \dots a_k \in L} \lambda_l \operatorname{Tr} \left[ \Phi_{a_1} \Phi_{a_2} \dots \Phi_{a_k} \right]$$

is a sum of gauge invariant operators Tr [Φ<sup>a</sup>1Φ<sup>a</sup><sup>2</sup> . . . Φ<sup>a</sup><sup>k</sup> ] . Gauge invariance requires l = a1a<sup>2</sup> . . . a<sup>k</sup> to be an oriented loop in the quiver. Each operator has coupling constant λ<sup>l</sup> .

For a quiver gauge theory to be physically sensible, the gauge anomalies for each gauge group must vanish. Vanishing of the triangle anomaly with three external gluons of the U(nv) gauge group yields the condition

<span id="page-6-1"></span>
$$\sum_{a \in A|h(a)=v} n_{t(a)} - \sum_{a \in A|t(a)=v} n_{h(a)} = 0.$$
(3.1)

Linear combinations  $U(1)_q$  of the  $U(1)_v \subset U(n_v)$  groups can mix and lead to triangle anomalies of the form Tr  $[SU(n_v)^2U(1)_q]$ . Vanishing of this mixed anomaly requires

<span id="page-7-1"></span>
$$\sum_{a \in A|h(a)=v} n_{t(a)} q_{t(a)} - \sum_{a \in A|t(a)=v} n_{h(a)} q_{n(a)} = 0.$$
(3.2)

Quiver gauge theories describing the low energy effective field theory of D-branes at a Calabi-Yau singularity have a variant of the Green-Schwarz mechanism to cancel the anomalous U(1)'s. The gauge fields of the anomalous U(1)'s couple to RR-form fields giving them Stückelberg masses [24, 25, 26]. These massive vector fields decouple in the IR. The non-anomalous U(1) fields are free in the infrared so they also decouple and become global U(1) symmetries in the IR. These global U(1) symmetries are called baryonic symmetries. This is explained from a large-volume perspective in [27, 28, 29]. In the next section we will review baryonic symmetries in more detail.

At a conformal fixed point in the infrared, we expect the NSVZ 1-loop exact beta functions of the gauge groups  $SU(n_v)$  and couplings  $\lambda_l$  to vanish. These constraints are

$$\hat{\beta}_{1/g_v^2} = 0 \qquad 2n_v + \sum_{e \in Q_1} (R(e) - 1)n_{t(e)} + \sum_{e \in Q_1} (R(e) - 1)n_{h(e)} = 0 \qquad (3.3)$$

<span id="page-7-2"></span>
$$\hat{\beta}_{\lambda_l} = 0 \qquad \qquad -2 + \sum_{e \in \text{loop } l} R(e) = 0. \tag{3.4}$$

The last condition implies that at a superconformal fixed point, every term in the superpotential has total R-charge 2.

### <span id="page-7-0"></span>4 Baryonic and Flavor Symmetries

Global flavor symmetries play a prominent role in our story because they can mix with the R-symmetry of the superconformal gauge theory. The a-maximization procedure of Intriligator and Wecht determines the precise form of the mixing. In this section, we review the constraints on anomalies with flavor symmetries. These constraints will be essential when we analyze the perturbative expansion of the Hilbert series in section 9.

After dimensional reduction, D3 branes wrapping 3-cycles in  $L^5$  become baryonic particles in the  $AdS_5$  supergravity theory. They are charged under the  $b^3(L^5)$  gauge fields coming from dimensional reduction of the RR 4-form on the same cycle. Under the AdS/CFT correspondence, these gauge fields are dual to global baryonic U(1) symmetries. For quiver gauge theories, the baryonic symmetries can be described by charges  $q_v^I$  satisfying equation (3.2). The charge of a bifundamental field  $X_{t(a),h(a)}$ 

under the  $I^{th}$  global baryonic symmetry is  $B^I(X) = q^I_{h(a)} - q^I_{t(a)}$ . When  $q_v = 1$ , none of the bifundamental fields is charged under the baryonic symmetry. In this case, (3.2) becomes equivalent to (3.1). The other solutions have non-vanishing baryonic charges, so the dimension of the solution space of (3.2) is  $b^3(L^5) + 1$ .

Mesonic operators in the quiver gauge theory are uncharged under baryonic symmetries. However they are charged under the R-symmetry and possibly additional flavor symmetries. If  $L^5$  has a rank  $\ell$ -dimensional space of isometries, then there are  $\ell$  Kaluza-Klein gauge fields in the  $AdS_5$  supergravity theory [15, 16]. The Kaluza-Klein gauge fields are dual to non-baryonic flavor symmetries in the SCFT. These symmetries are called mesonic flavor symmetries because mesons are charged under them.

In addition to the anomalies (5.1), the baryonic symmetries of four dimensional superconformal field theories satisfy relations:

$$\operatorname{Tr} B^I = 0 \tag{4.1}$$

$$\operatorname{Tr} B^I B^J B^K = 0 \qquad \text{for all } I, J, K. \tag{4.2}$$

since there are no 10-dimensional Chern-Simons couplings that could generate the corresponding anomalies via dimensional reduction [21, 29].

#### <span id="page-8-0"></span>5 A-Maximization

Given the ultraviolet description of a quiver gauge theory, determining the exact R-symmetry in the IR is complicated by the possibility that the R-symmetry can mix with other U(1) global symmetries. Intriligator and Wecht [5] developed a procedure called a-maximization to determine the true R symmetry in the IR. They first consider a trial R-symmetry

<span id="page-8-1"></span>
$$R_t = R_0 + \sum_{I} s^I F^I$$

where  $R_0$  is any U(1) charge assignment whose gauge and superpotential couplings have vanishing beta functions (3.3). The  $F^I$  represent arbitrary U(1) flavor symmetries and  $s^I$  are parameters. Combined with the general results on flavor symmetries in  $\mathcal{N}=1$  SCFTs [30],

$$9\operatorname{Tr}(R^2F^I) = \operatorname{Tr}F^I \tag{5.1}$$

$$\operatorname{Tr} RF^J F^K$$
 is negative definite. (5.2)

Intriligator and Wecht showed that the true R symmetry is the one that minimizes the 4D central charge

$$a = \frac{3}{32} \left( \sum_{\psi} 3R_{\psi}^3 - R_{\psi} \right).$$

Since the a-central charge can be expressed in terms of triangle anomalies, the sum is over all fermions, ψ, in the quiver gauge theory. A chiral multiplet X<sup>e</sup> containing a complex scalar field with R-charge R(e) also contains a fermion with R-charge R(e) − 1. Bifundamental fields between gauge groups of ranks n<sup>v</sup> and n<sup>w</sup> contribute nvn<sup>w</sup> fermions to the gauge theory matter content. Similarly, adjoint fields contribute n 2 v fermions. For each gauge group U(nv), there are n 2 v gauginos, which all have R-charge 1. In terms of the fields of the quiver, the a central charge is

$$a = \frac{3}{32} \left( 2N_G + \sum_{e \in Arr(v \to w)} 3n_v n_w (R(e) - 1)^3 - n_v n_w (R(e) - 1) \right)$$

where N<sup>G</sup> = P v∈Q<sup>0</sup> n 2 v is the number of gauginos. For a superconformal quiver gauge theory Tr R = 0, which lets us write the a-anomaly as

<span id="page-9-1"></span>
$$a = \frac{9}{32} \left( N_G + \sum_{e \in Arr(v \to w)} n_v n_w (R(e) - 1)^3 \right).$$
 (5.3)

As emphasized in [\[31,](#page-26-11) [10,](#page-25-6) [29\]](#page-26-9) the baryonic symmetries decouple from the maximization procedure, so we can restrict the parameters s I to vary over the `-dimensional subspace of mesonic flavor symmetries in a-maximization. The space of mesonic flavor symmetries corresponds directly to the `-dimensional subspace the Reeb vector is varied over in volume minimization. We have given an account of the original Intriligator-Wecht procedure, which is sufficient for our purposes. For further developments and modifications, see [\[32,](#page-26-12) [33,](#page-26-13) [34\]](#page-26-14).

# <span id="page-9-0"></span>6 Calabi-Yau Algebras

Which quiver gauge theories arise from placing a stack of D3-branes at a Calabi-Yau singularity? Berenstein and Douglas [\[35\]](#page-26-15) suggested that the Calabi-Yau condition should be captured by a form of Serre duality. Additionally, they conjectured that the Calabi-Yau condition could be captured by a projective resolution of simple modules. In this section, we will review the homological algebra necessary to state Ginzburg's version [\[36,](#page-26-16) [37\]](#page-27-0) of Berenstein and Douglas' conjecture. We will be able to use Ginzburg's projective resolution to determine the Hilbert series of any Calabi-Yau algebra of dimension three.

Following [\[38\]](#page-27-1), let S := L v∈Q<sup>0</sup> Ce<sup>v</sup> be the semi-simple algebra generated by the paths of length zero. Similarly, let T<sup>1</sup> = L a∈Q<sup>1</sup> Cx<sup>a</sup> be the vector space generated by the arrows. For each arrow a ∈ Q1, there is a relation R<sup>a</sup> ≡ ∂ ∂xaW. Define T<sup>2</sup> = L a∈Q<sup>1</sup> CR<sup>a</sup> to be the vector space generated by the relations R<sup>a</sup> ≡ ∂ ∂xaW. In addition to relations, there can also be relations between relations called syzygies. For any superpotential algebra, there is a universal syzygy [\[39\]](#page-27-2) associated to every vertex v ∈ Q<sup>0</sup> of the form

$$W_v := \sum_{a \in Q_1 | t(a) = v} x_a R_a = \sum_{a \in Q_1 | h(a) = v} R_a x_a.$$

Finally, let T<sup>3</sup> := L v∈Q<sup>0</sup> CW<sup>v</sup> be the vector space spanned by the universal syzygies. There are natural maps µ0, . . . µ<sup>3</sup> between these spaces. The map µ<sup>0</sup> takes two paths and concatenates them. It is extended by linearity to act on the entire path algebra:

$$\mu_0: A \otimes_S A \to A$$
  
 $x \otimes y \to xy.$ 

The map µ<sup>1</sup> is defined on a triple (path, arrow, path) and produces a formal difference of pairs of paths. By linearity the map extends to the entire path algebra.

$$\mu_1: A \otimes_S T \otimes_S A \to A \otimes_S A$$
$$x \otimes x_a \otimes y \to xx_a \otimes y - x \otimes x_a y.$$

The map µ<sup>2</sup> is defined using a new type of derivative

$$\frac{\partial}{\partial x_a} : \mathbb{C}Q \to \mathbb{C}Q \otimes \mathbb{C}Q \qquad x \to \left(\frac{\partial x}{\partial x_a}\right)' \otimes \left(\frac{\partial x}{\partial x_a}\right)''.$$

We first explain how this derivative acts on paths. For each occurrence of an arrow x<sup>a</sup> in a path, the path can be written as xxay. Split this term into x ⊗ y and then sum over all possible positions of the middle arrow. In Sweedler notation the left part, x, is inserted to the first (·) 0 and the right part, y, is inserted into second (·) <sup>00</sup>. Using this derivative, the map µ<sup>2</sup> is defined as

$$\mu_2: A \otimes_S T_2 \otimes_S A \to A \otimes_S T_1 \otimes_S A$$
$$x \otimes R_a \otimes y \to \sum_{b \in Q_1} x \left(\frac{\partial R_a}{\partial x_b}\right)' \otimes x_b \otimes \left(\frac{\partial R_a}{\partial x_b}\right)'' y.$$

Finally, the map µ<sup>3</sup> is defined as

$$\mu_3 : A \otimes_S T_3 \otimes_S A \to A \otimes_S T_2 \otimes_S A$$

$$x \otimes W_v \otimes y \to \sum_{b \in Q_1 \mid t(b) = v} x x_b \otimes R_b \otimes y - \sum_{b \in Q_1 \mid h(b) = v} x \otimes R_b \otimes x_b y$$

It is simple to check that the composition of two successive maps  $\mu_j \circ \mu_{j+1} = 0$  so we can form the following complex:

<span id="page-11-0"></span>
$$0 \longrightarrow A \otimes_S T_3 \otimes_S A \stackrel{\mu_3}{\longrightarrow} A \otimes_S T_2 \otimes_S A \stackrel{\mu_2}{\longrightarrow} A \otimes_S T_1 \otimes_S A \stackrel{\mu_1}{\longrightarrow} A \otimes_S A \stackrel{\mu_0}{\longrightarrow} A \longrightarrow 0 \quad (6.1)$$

Ginzburg's main result is the following theorem:

**Theorem 6.1** ([37]). An associative algebra A is Calabi-Yau of dimension three if and only if the complex (6.1) is exact.

The notion of Calabi-Yau algebras used in this theorem is defined by an analog of Serre duality.

**Definition 6.1** ([37]). A homologically smooth algebra A is said to be Calabi-Yau of dimension d if there is an A-bimodule quasi-isomorphism  $f: A \to A^![d]$  such that  $f = f^![d]$ . Here

$$M \to M^! := RHom_{A-Bimod}(M, A \otimes A).$$

We will use the projective resolution (6.1) to compute the Hilbert series of graded superpontetial algebras.

**Definition 6.2.** The Hilbert series of a graded superpotential algebra  $A = \bigoplus_{r \in \mathbb{N}} A_r$  is the  $Q_0 \times Q_0$  matrix H(A;t) with (v,w) entry

$$H_{v,w}(A;t) = \sum_{r=0}^{\infty} t^r \dim(e_v A_r e_w).$$

**Theorem 6.2** (Ginzburg/Bocklandt [37, 40]). Let  $A = \mathbb{C}Q/(\partial W)$  be a superpotential algebra with W homogeneous of degree d. Associate to the quiver the adjacency matrix  $M_Q(t)$  with (v, w) entry

$$M_{v,w}(Q;t) = \sum_{a \in \operatorname{arr}(v \to w)} t^{\operatorname{deg}(a)}.$$

The Hilbert series of A equals

$$H(A;t) = \frac{1}{1 - M_Q(t) + t^d M_Q^T(t^{-1}) - t^d}$$

where 1 represents the identity matrix.

In the next section we will introduce non-commutative resolutions of local Calabi-Yau singularities. These form a large family of Calabi-Yau algebras. We expect that the condition that a gauge theory is superconformal implies that the corresponding superpotential algebra is Calabi-Yau of dimension three.

Conjecture 6.1. A superpotential algebra A = CQ/(∂W) with an R-charge assignment R : Q<sup>1</sup> → (0, 1] such that

- Each field of Q<sup>1</sup> appears in at least two terms of the superpotential,
- The superpotential W is homogeneous of degree 2,
- The NSVZ beta functions in equation [\(3.3\)](#page-7-2) vanish,

is a Calabi-Yau algebra of dimension 3.

For the special case of dimer models, this conjecture has been proven [\[41,](#page-27-4) [38,](#page-27-1) [42\]](#page-27-5).

## <span id="page-12-0"></span>7 Non-Commutative Crepant Resolutions

Bondal and Orlov conjectured that different crepant resolutions f<sup>1</sup> : Y<sup>1</sup> → X and f<sup>2</sup> : Y<sup>2</sup> → X of a local Calabi-Yau singularity X = Spec R should have equivalent derived categories of coherent sheaves [\[43\]](#page-27-6). Van den Bergh gave a new proof of this conjecture in dimension three [\[44\]](#page-27-7), which was motivated by [\[45\]](#page-27-8). One of his insights was to introduce a non-commutative algebra A as an intermediate object.

$$D^b(\operatorname{Coh} Y_1) \cong D^b(\operatorname{mod} -A) \cong D^b(\operatorname{Coh} Y_2).$$

Abstracting the properties of the algebra A led van den Bergh to define non-commutative crepant resolutions.

Definition 7.1 (van den Bergh [\[46\]](#page-27-9)). A non-commutative crepant resolution (NCCR) of a Gorenstein ring R is an homologically homogeneous R-algebra of the form A = EndR(M) where M is a reflexive R-module.

In practice, we will work with the slightly weaker, but more accessible, class of non-commutative crepant resolutions given by the next theorem.

Theorem 7.1 (van den Bergh [\[46\]](#page-27-9)). The algebra

$$A = \operatorname{End}_R(M)$$

is a non-commutative crepant resolution of a commutative Gorenstein ring R if

- M is a reflexive R-module,
- A has finite global dimension,
- A is a MCM R-module.

The second condition is necessary to show that NCCRs of Gorenstein rings of dimension three are Calabi-Yau three algebras. In this paper, we will focus on NCCRs of the form A = EndR(M), where M = L<sup>N</sup> <sup>i</sup>=0 <sup>M</sup><sup>i</sup> and <sup>M</sup><sup>0</sup> <sup>=</sup> R. Since EndR(M0) <sup>∼</sup><sup>=</sup> <sup>R</sup> we can identify closed loops based at the vertex corresponding to M<sup>0</sup> with the elements of R, or equivalently the holomorphic functions on the variety X = Spec R. If we view the algebra A is a quiver gauge theory, each module M<sup>v</sup> corresponds to a vertex v of the quiver. The gauge groups U(nv) associated to the modules M<sup>v</sup> have ranks

$$n_v = N \dim_R M_v$$

where N is the number of D3-branes at the singularity and dim<sup>R</sup> M<sup>v</sup> is the rank of the R-module Mv.

## <span id="page-13-0"></span>8 Volume Minimization

A-maximization determines the true R-symmetry of a superconformal field theory in the IR. The AdS/CFT dual of this problem is determining the Reeb vector that generates the U(1) isometry of the Sasaki-Einstein geometry. A geometric dual of a−maximization for local toric Calabi-Yau threefolds was found by Martelli, Sparks, and Yau [\[6\]](#page-25-2). They showed that the Reeb vector field, and hence the volume of a Sasaki-Einstein metric on the base of a local toric Calabi-Yau cone could be computed by minimizing a function computed from toric data. Later, they generalized their result to manifolds with only a (C ∗ ) ` symmetry [\[7,](#page-25-3) [14\]](#page-25-10). The basic idea is that the asymptotic growth rate of the number of holomorphic functions on the local Calabi-Yau determines the volume of the Sasaki-Einstein horizon manifold [\[8\]](#page-25-4).

The equivariant index

$$C(q, X) = \operatorname{Tr} \left\{ q \mid \mathcal{H}^0(X) \right\}$$

counts the holomorphic functions on X indexed by their charges q ∈ (C ∗ ) ` . The trace in the definition is of the induced (C ∗ ) ` action defined on the vector space of holomorphic function on X. Let ζa, a = 1 . . . s form a basis for the Lie algebra of U(1)` ⊂ (C ∗ ) ` so we can expand the Reeb vector in components ξ = P` <sup>a</sup>=1 baζa, where b<sup>a</sup> are real parameters. For toric manifolds, the equivariant index reduces to the character

$$C(q, X_{\sigma}) = \sum_{m \in \mathcal{S}_{\sigma}} q^{m}$$

which counts points in a polyhedral cone S<sup>σ</sup> associated to the toric variety. The volume of the horizon manifold L 2n−1 is found by minimizing

$$Vol[L^{2n-1}](b_a) = \frac{2\pi^n}{(n-1)!} \lim_{s \to 0} s^n C(q_a = e^{-sb_a}, X_\sigma)$$

over all possible values of the Reeb vector. For the case of interest, n=3 and the volume is

$$Vol[L^{5}](b_{a}) = \pi^{3} \lim_{s \to 0} s^{3} C(q_{a} = e^{-sb_{a}}, X)$$

as a function of the Reeb vector.

### <span id="page-14-0"></span>9 Hilbert Series

In this section, we will show how the volume of a horizon manifold  $L^5$  can be computed directly from the quiver describing the dual superconformal field theory. As explained in section 7, given a singular local Calabi-Yau  $X = \operatorname{Spec} R$ , a noncommutative crepant resolution describes the gauge theory on a stack of D3-branes placed at the singularity of X. If the noncommutative crepant resolution is of the form  $A = \operatorname{End}_R(M_0 \oplus \cdots \oplus M_{|Q_0|-1})$  with  $M_0 := R$ , then the closed loops based at the vertex corresponding to  $M_0$  are in bijection with the elements of the ring R.

To count paths weighted by R-charge, we simply modify the adjacency matrix to have (v, w) component

$$M_Q(t)_{vw} = \sum_{e \in \text{Arrows}(v \to w)} t^{R(e)}$$

where R(e) is a trial R-charge for the edge e. Since the superpotential has degree 2, the Hilbert series is

<span id="page-14-1"></span>
$$H(Q;t) = \frac{1}{1 - M_Q(t) + t^2 M_Q^T(t^{-1}) - t^2}.$$
(9.1)

The (v, w) entry of the Hilbert series counts the number of distinct paths from vertex v to vertex w weighted by R-charge where paths are counted up to F-term equivalence. Since the module  $M_0$  corresponds to vertex 0 of the quiver, the Hilbert series of  $R = \text{Hom}(M_0, M_0)$  is given by the (0, 0) entry of the Hilbert series.

To match the Hilbert series to the equivariant index C(q, X) of Martelli, Sparks, and Yau, we recall the precise form of the correspondence between the Reeb vector  $\xi$  and the R-symmetry. In their normalization, the weight  $\mu$  of a holomorphic function on X is determined by  $\mathcal{L}_{\xi}f = \mu i f$  where  $\mathcal{L}_{\xi}$  is the Lie derivative along the Reeb vector field. The Reeb vector is normalized by demanding that

$$\mathcal{L}_{\varepsilon}\Omega^{3,0} = 3i\Omega^{3,0}$$

where  $\Omega^{3,0}$  is the no-where vanishing holomorphic three form defined away from the singularity. The holomorphic functions on X determine eigenfunctions of the Laplacian on its horizon manifold  $L^5$ . By carefully performing the Kaluza-Klein reduction,

Martelli, Sparks, and Yau show that the scaling dimension  $\Delta(\mathcal{O})$  of a mesonic operator  $\mathcal{O}$  in the gauge theory is precisely

$$\Delta = \mu$$
.

The superconformal algebra relates the scaling dimensions of chiral primary operators to their R-charge

$$R(\mathcal{O}) = \frac{2}{3}\Delta(\mathcal{O}).$$

Combining these identifications, the volume of the horizon manifold is

$$Vol[L^5] = \left(\frac{2\pi}{3}\right)^3 \lim_{s \to 0} s^3 H_{0,0}(Q; e^{-s}).$$

### <span id="page-15-0"></span>10 Examples

#### <span id="page-15-1"></span>10.1 $\mathbb{C}^3$

The simplest five-dimensional Sasaki-Einstein manifold is the round five-sphere. Its metric cone is simply  $\mathbb{C}^3$ . The dual gauge theory is  $\mathcal{N}=4$  SYM, which has three adjoint scalar fields X,Y,Z, and superpotential  $W=\operatorname{Tr}(XYZ-XYZ)$ . The quiver consists of a single node with three loops corresponding to the three adjoint scalar fields. Let a,b,c denote the trial R-charges for these fields. The weighted adjacency matrix has the single entry

$$M_Q(t; a, b, c) = (t^a + t^b + t^c)$$

The Hilbert series is

$$H(Q;t;a,b,c) = \frac{1}{1 - (t^a + t^b + t^c) - (t^{2-a} + t^{2-b} + t^{2-c}) + t^2}.$$

Imposing the constraint that all the R-charges must sum to 2, we can eliminate c = 2 - a - b. We expand the Hilbert series in  $t = e^{-s}$  as

$$s^{3}H_{0,0}(Q;e^{-s}) = \frac{1}{ab(2-a-b)} \frac{1}{s^{3}} + \mathcal{O}(s).$$

Minimizing the volume over a and b we find that

$$Vol[S^5] = \pi^3$$

which agrees with our choice of normalization.

![](_page_16_Picture_0.jpeg)

Figure 1: Klebanov-Witten quiver for the conifold.

#### <span id="page-16-0"></span>10.2 Conifold

The weighted adjacency matrix of the conifold is

$$M_Q(t; a, b, c, d) = \begin{pmatrix} 0 & t^a + t^b \\ t^c + t^d & 0. \end{pmatrix}$$

From this we determine the Hilbert series

$$H(Q;t;x,y) = \frac{1 - t^2}{(1 - t^{2-x})(1 - t^x)(1 - t^{2-y})(1 - t^y)}.$$

We can impose the constraint that the total R-charge is 2 by eliminating d and writing the Hilbert series in terms of x = b + c and y = a + c. Expanding the Hilbert series in  $t = e^{-s}$  yields

$$s^{3}H_{0,0}(Q; e^{-s}) = \frac{2}{x(2-x)y(2-y)} + \mathcal{O}(s).$$

Minimizing this expression with respect to x and y, we find the volume of the horizon manifold

$$Vol[T^{1,1}] = \frac{16\pi^3}{27}.$$

## <span id="page-16-1"></span>11 Perturbative Expansion of the Hilbert Series

#### <span id="page-16-2"></span>11.1 Overview

In this section, we will prove that the volume formula of Martelli, Sparks, and Yau applied to a quiver arising from a NCCR precisely matches the AdS/CFT prediction from a-maximization. We will perturbatively expand the Hilbert series H(Q;t) in the variable  $t=e^{-s}$ . Our main result is that the expansion takes the form

$$s^{3}H_{v,w}(Q; e^{-s}) = s^{3}\frac{n_{v}n_{w}}{\lambda(s)} + \mathcal{O}(s)$$

where  $n_v$  and  $n_w$  are the ranks of the gauge groups corresponding to vertices v and w,

$$\lambda(s) = \frac{32}{27}as^3 + \mathcal{O}(s^4),$$

and a is the central charge defined in equation (5.3). From this we can compute the volume of the horizon manifold purely in terms of the fields of the quiver gauge theory.

$$Vol[L^{5}] = \left(\frac{2\pi}{3}\right)^{3} \lim_{s \to 0} s^{3} H_{0,0}(Q; e^{-s})$$
$$= \left(\frac{2\pi}{3}\right)^{3} \left(\frac{27}{32}\right) \frac{N^{2}}{a}$$
$$= \frac{\pi^{3} N^{2}}{4a}.$$

The volume is precisely as predicted by the AdS/CFT correspondence.

To determine the most singular term in the expansion of  $H(Q; e^{-s})$ , we must get control over the eigenvalues of the denominator matrix

$$D_Q(s) \equiv (1 - M_Q(e^{-s}) + e^{-2s} M_Q^T(e^s) - e^{-2s}).$$

By a change of basis, the leading pole in the expansion of  $H(Q; e^{-s})$  is governed by the eigenvalue of  $D_Q(s)$  with the highest order zero in s. Using perturbation theory, we will show there is a unique eigenvalue,  $\lambda(s)$ , that vanishes as  $s^3$ . We begin by Taylor expanding the matrix  $D_Q(s)$ , the eigenvalue  $\lambda(s)$ , and its corresponding eigenvector  $|\Psi(s)\rangle$  as follows:

$$D_Q(s) = D_Q^{(0)} + sD_Q^{(1)} + s^2D_Q^{(2)} + \dots$$
  

$$|\Psi(s)\rangle = |\Psi^0\rangle + s|\Psi^{(1)}\rangle + s^2|\Psi^{(2)}\rangle + \dots$$
  

$$\lambda(s) = \lambda^{(0)} + s\lambda^{(1)} + s^2\lambda^{(2)} + \dots$$

We first identify the eigenvectors of the leading term  $D_Q^{(0)}$  in the expansion. The (v, w) component of  $D_Q(s)$  is

$$D_Q^{vw}(s) = \left(\sum_{e \in \operatorname{Arr}(v \to w)} -1 + \sum_{e \in \operatorname{Arr}(w \to v)} 1\right) + \mathcal{O}(s).$$

The null vectors of  $D_Q^{(0)}$  are spanned by the rank vector  $|\phi_0\rangle$  with  $v^{th}$  component  $n_v$  and baryonic charge vectors  $|\phi_J\rangle$  with components  $n_vq_v^J$ . This follows from our definition of baryonic symmetries as solutions of

$$\sum_{a \in A \mid h(a) = v} n_{t(a)} q_{t(a)} - \sum_{a \in A \mid t(a) = v} n_{h(a)} q_{n(a)} = 0.$$

Since  $D_Q^{(0)}$  is a real anti-symmetric matrix, we can choose a complete set of orthogonal eigenvectors  $|\phi_J\rangle$ . Let  $|\phi_0\rangle = |\Psi^{(0)}\rangle$ , and label the other null vectors  $|\phi_J\rangle$ ,  $J=1,\ldots,r$ . Label the remaining non-null eigenvectors  $|\phi_J\rangle$ ,  $J=(r+1),\ldots,|Q_0|-1$ . We will show that  $\lambda(s) = \frac{32}{27}as^3 + \mathcal{O}(s^4)$ . To accomplish this, we will need the following intermediate results:

• The rank vector  $|\Psi^{(0)}\rangle$  is a null vector of  $D_Q^{(0)} + sD_Q^{(1)}$ . We write this as

<span id="page-18-0"></span>
$$\left(D_Q^{(0)} + D_Q^{(1)}s\right)|\Psi^{(0)}\rangle = 0. \tag{11.1}$$

• The order  $s^2$  correction to  $\lambda(s)$  vanishes. That is

<span id="page-18-1"></span>
$$\langle \Psi^{(0)} | D_Q^{(2)} | \Psi^{(0)} \rangle = 0.$$
 (11.2)

• The first non-zero correction to  $\lambda(s)$  is

<span id="page-18-2"></span>
$$\langle \Psi^{(0)} | D_Q^{(3)} | \Psi^{(0)} \rangle = \frac{32}{27} a.$$
 (11.3)

• The baryonic vectors  $|\phi_J\rangle$ ,  $J=1\ldots r$  are orthogonal to the rank vector  $|\Psi^{(0)}\rangle$  to order  $s^3$ , that is

<span id="page-18-3"></span>
$$\langle \phi_J | D_Q^{(2)} | \Psi^{(0)} \rangle = 0 \qquad J = 1, \dots r$$
 (11.4)

• The matrix governing the mixing of the baryonic symmetries

<span id="page-18-4"></span>
$$\langle \phi_J | D_Q^{(1)} | \phi_K \rangle$$
  $J, K = 1, \dots r$  (11.5)

is positive definite.

All of these results will follow from general properties of  $\mathcal{N}=1$  superconformal field theories. We demonstrate properties (11.1), (11.2), and (11.3) in section 11.2. The remaining two properties, (11.4) and (11.5), are shown in sections 11.3 and 11.4, respectively.

We expand the eigenvalue equation

<span id="page-18-5"></span>
$$D_Q(s)|\Psi(s)\rangle = \lambda(s)|\Psi(s)\rangle$$
 (11.6)

order by order in s. Multiplying through by  $\langle \Psi^0 |$  on the left and dropping terms of order  $\mathcal{O}(s^4)$  we have

$$\langle \Psi^{0} | \left( D_{Q}^{(0)} + s D_{Q}^{(1)} + s^{2} D_{Q}^{(2)} + s^{3} D_{Q}^{(3)} \right) \left( | \Psi^{(0)} \rangle + s | \Psi^{(1)} \rangle + s^{2} | \Psi^{(2)} \rangle + s^{3} | \Psi^{(3)} \rangle \right)$$

$$(11.7)$$

$$=s^{3}\left(\langle\Psi^{(0)}|D_{Q}^{(3)}|\Psi^{(0)}\rangle + \langle\Psi^{(0)}|D_{Q}^{(2)}|\Psi^{(1)}\rangle\right)$$
(11.8)

where we have used equations (11.1) and (11.2). For this expression to match the right-hand side of the eigenvalue equation (11.6),  $\lambda^{(0)} = \lambda^{(1)} = \lambda^{(2)} = 0$ , and the first non-vanishing correction to  $\lambda(s)$  is

<span id="page-18-6"></span>
$$\lambda^{(3)} = \langle \Psi^{(0)} | D_O^{(3)} | \Psi^{(0)} \rangle + \langle \Psi^{(0)} | D_O^{(2)} | \Psi^{(1)} \rangle. \tag{11.9}$$

We will show that the first order correction to the eigenvector |Ψ(1)i vanishes and hence

$$\lambda^{(3)} = \langle \Psi^{(0)} | D_Q^{(3)} | \Psi^{(0)} \rangle. \tag{11.10}$$

We again expand [\(11.6\)](#page-18-5) perturbatively in s and multiply both sides of the equation by hφK|. Since hφK| was chosen to be a set of mutually orthogonal eigenvectors to the real anti-symmetric matrix, D (0) <sup>Q</sup> , hφK|D (0) <sup>Q</sup> = −λKhφK|. At order s we have the constraint

$$\langle \phi_K | D_Q^{(0)} | \Psi^{(1)} \rangle = 0$$
 (11.11)

$$-\lambda_K \langle \phi_K | \Psi^{(1)} \rangle = 0. \tag{11.12}$$

where λ<sup>K</sup> is the corresponding eigenvalue of the eigenvector |φKi. The order s 2 term in the expansion is

<span id="page-19-0"></span>
$$\langle \phi_K | D_Q^{(2)} | \Psi^{(0)} \rangle + \langle \phi_K | D_Q^{(1)} | \Psi^{(1)} \rangle + \langle \phi_K | D_Q^{(0)} | \Psi^{(2)} \rangle = 0.$$
 (11.13)

We have shown that the first order correction, |Ψ(1)i, to |Ψ(s)i must lie in the nullspace of D (0) <sup>Q</sup> . The nullspace is spanned by the rank vector |Ψ(0)i and the vectors |φ<sup>J</sup> i, J = 1, . . . , r associated to the baryonic U(1) symmetries.

Restricting the basis vectors to the baryonic vectors |φKi, K = 1, . . . , r we can further simplify [\(11.13\)](#page-19-0). Since the baryonic vectors are in the null space of of D (0) <sup>Q</sup> , equation [\(11.13\)](#page-19-0) reduces to

$$\langle \phi_K | D_Q^{(2)} | \Psi^{(0)} \rangle + \langle \phi_K | D_Q^{(1)} | \Psi^{(1)} \rangle = 0.$$
 (11.14)

By [\(11.4\)](#page-18-3), the first term vanishes. Furthermore, hφK|D (1) <sup>Q</sup> |φ<sup>J</sup> i is positive definite by [\(11.5\)](#page-18-4). Combined, these two results imply that the leading correction, |Ψ(1)i, to the eigenvector |Ψ(s)i must be proportional to |Ψ(0)i. Thus, equation [\(11.9\)](#page-18-6) simplifies, and

$$\lambda^{(3)} = \langle \Psi^{(0)} | D_Q^{(3)} | \Psi^{(0)} \rangle \tag{11.15}$$

as claimed. All that remains to complete our proof is to show the lemmas given in bullet points. This will be accomplished in the rest of this section.

### <span id="page-20-0"></span>11.2 The Smallest Eigenvalue

Let t = e <sup>−</sup><sup>s</sup> and perturbatively expand the denominator about s = 0. The (v, w) entry of the denominator matrix is

$$D_{Q}^{vw}(s) = \left(\sum_{e \in Arr(v \to w)} -1 + \sum_{e \in Arr(w \to v)} 1\right) + \left(2\delta_{vw} + \sum_{e \in Arr(v \to w)} R(e) + \sum_{e \in Arr(w \to v)} (R(e) - 2)\right) s + \left(-2\delta_{vw} + \sum_{e \in Arr(v \to w)} -\frac{R(e)^{2}}{2} + \sum_{e \in Arr(w \to v)} \left(\frac{R(e)^{2}}{2} - 2R(e) + 2\right)\right) s^{2} + \left(\frac{4}{3}\delta_{vw} + \sum_{e \in Arr(v \to w)} \frac{R(e)^{3}}{6} + \sum_{e \in Arr(w \to v)} \left(\frac{R(e)^{3}}{6} - R(e)^{2} + 2R(e) - \frac{4}{3}\right)\right) s^{3} + \dots$$

$$(11.16)$$

The function R(e) is the trial R-charge of an edge. All of the identities we will need to simplify the anomalies with the R-charge will also apply to any trial R-charge R(e) [\[21\]](#page-26-1). The sums P e∈Arr(v→w) are over all arrows from vertex v to vertex w in the quiver. These terms come from expanding MQ(e s ). The sums over the arrows in the reverse direction arise from expanding e <sup>−</sup>2<sup>s</sup>M<sup>T</sup> <sup>Q</sup> (e s ) and the corresponding summands are the terms in the Taylor expansion of exp(s(R(e) − 2)).

Vanishing of the triangle anomaly with three gluons [\(3.1\)](#page-6-1) implies that the sum of the ranks of the incoming and outgoing arrows at each node vanishes. This yields the first half of [\(11.1\)](#page-18-0),

$$D_Q^{(0)}|\Psi^{(0)}\rangle = 0.$$

The second half of [\(11.1\)](#page-18-0),

$$D_Q^{(1)}|\Psi^{(0)}\rangle = 0$$

follows from [\(3.1\)](#page-6-1) and the vanishing of the NSVZ beta function [\(3.3\)](#page-7-2).

At order s 2 , the rank vector, |Ψ(0)i, is not in the null space of D (2) <sup>Q</sup> , but we can show equation [\(11.2\)](#page-18-1)

$$\langle \Psi^{(0)} | D_Q^{(2)} | \Psi^{(0)} \rangle = 0$$

holds by expanding the equation out in components:

$$\langle \Psi^{(0)} | D_Q^{(2)} | \Psi^{(0)} \rangle = \left( -2 \sum_{v \in Q_0} n_v^2 + \sum_{e \in \text{Arr}(v \to w)} -n_v n_w \frac{R(e)^2}{2} + \sum_{e \in \text{Arr}(w \to v)} n_v n_w \left( \frac{R(e)^2}{2} - 2R(e) + 2 \right) \right)$$

$$= \left( -2 \sum_{v \in Q_0} n_v^2 + \sum_{e \in \text{Arr}(w \to v)} n_v n_w \left( -2R(e) + 2 \right) \right)$$

$$= 0.$$
(11.17)

In going from the first line to the second line, we have used the equality of the number of incoming and outgoing arrows. The last equality follows from the vanishing of the NSVZ beta functions of the gauge groups. Finally at order s 3 , we show [\(11.3\)](#page-18-2).

<span id="page-21-1"></span>
$$\langle \Psi^{(0)} | D_Q^{(3)} | \Psi^{(0)} \rangle = \frac{1}{3} \left[ \sum_{v \in Q_0} 4n_v^2 + \sum_{e \in \operatorname{Arr}(w \to v)} n_v n_w \left( (R(e) - 1)^3 + 3(R(e) - 1) \right) \right]$$

$$= \frac{1}{3} \left[ \sum_{v \in Q_0} n_v^2 + \sum_{e \in \operatorname{Arr}(w \to v)} n_v n_w (R(e) - 1)^3 \right]$$

$$= \frac{1}{3} (N_G + \operatorname{Tr} R^3)$$

$$= \frac{32}{27} a$$

where we have used [\(11.17\)](#page-21-1) to simplify the second line. We have found that the smallest eigenvalue is proportional to the a-anomaly.

### <span id="page-21-0"></span>11.3 Absence of Mixing

When the quiver gauge theory has baryonic U(1) symmetries, there are additional null vectors, |φ<sup>J</sup> i, J = 1 . . . r, of D (0) <sup>Q</sup> . In this section we show [\(11.4\)](#page-18-3),

<span id="page-21-2"></span>
$$\langle \phi_J | D_Q^{(2)} | \Psi^{(0)} \rangle = 0 \qquad J = 1, \dots r$$

which we used to simplify [\(11.9\)](#page-18-6). Expanding the order s 2 term,

$$-2\sum_{v\in Q_0} n_v^2 q_v^I - \sum_{e\in Arr(v\to w)} n_v n_w q_v^I \frac{R(e)^2}{2} + \sum_{e\in Arr(w\to v)} n_v n_w q_v^I \left(\frac{R(e)^2}{2} - 2R(e) + 2\right)$$

$$= -2\sum_{v\in Q_0} n_v^2 q_v^I + \sum_{e\in Arr(w\to v)} n_v n_w \left((q_v^I - q_w^I) \frac{R(e)^2}{2} - 2q_v^I R(e) + 2q_v^I\right). \tag{11.18}$$

To simplify this, we multiply the equation  $\hat{\beta}_{1/g_v^2} = 0$  by  $n_v q_v^I$  and sum over the vertices, v, of the quiver.

$$0 = 2n_v + \sum_{e \in Arr(v \to w)} (R(e) - 1)n_w + \sum_{e \in Arr(w \to v)} (R(e) - 1)n_w$$

$$0 = 2\sum_{v \in Q_0} n_v^2 q_v^I + \sum_{e \in Arr(v \to w)} n_v n_w q_v^I (R(e) - 1) + \sum_{e \in Arr(w \to v)} n_v n_w q_v^I (R(e) - 1)$$

$$0 = 2\sum_{v \in Q_0} n_v^2 q_v^I + \sum_{e \in Arr(w \to v)} n_v n_w q_w^I (R(e) - 1) + n_v n_w q_v^I (R(e) - 1)$$
(11.19)

Using equation (11.19), the quadratic term (11.18) simplifies to

<span id="page-22-1"></span>
$$\frac{1}{2} \sum_{e \in \text{Arr}(w \to v)} n_v n_w (q_v^I - q_w^I) \left( \frac{R(e)^2}{2} - R(e) + 1 \right). \tag{11.20}$$

The constraint  $\operatorname{Tr} B^I = 0$  implies  $\sum_{e \in \operatorname{Arr}(w \to v)} n_v n_w (q_v^I - q_w^I) = 0$ . We use this constraint to bring equation (11.20) to the form

<span id="page-22-2"></span>
$$\frac{1}{2} \sum_{e \in \operatorname{Arr}(w \to v)} n_v n_w (q_v^I - q_w^I) (R(e) - 1)^2$$

$$= \frac{1}{2} \operatorname{Tr} R^2 B^I$$

$$= 0$$

where we have used the vanishing of the  $\operatorname{Tr} R^2 B^I$  anomaly.

### <span id="page-22-0"></span>11.4 Positivity

In this section we show that the matrix in (11.5),

$$\langle \phi_J | D_Q^{(1)} | \phi_K \rangle$$
  $J, K = 1, \dots r$ 

is negative definite. This will complete the proof of our main result. It is necessary to show this lemma to ensure that  $\lambda(s)$  is the only eigenvalue that vanishes as  $s^3$ . The new field theory ingredient we will need is that the matrix of trace anomalies,  $\operatorname{Tr} RB^IB^J$  is negative definite. For a trial R-charge,  $\operatorname{Tr} R_tB^IB^J$  is also negative definite if the trial R-charge is sufficiently close to the true R-charge. From  $\hat{\beta}_{1/g_v^2}=0$  we can multiply equation (3.3) by  $n_vq_v^Iq_v^J$  and sum over v to obtain

$$2\sum_{v \in Q_0} n_v^2 q_v^I q_v^J + \sum_{e \in Arr(v \to w)} (R(e) - 1) n_v n_w q_v^I q_w^J + \sum_{e \in Arr(w \to v)} (R(e) - 1) n_v n_w q_v^I q_w^J = 0.$$

From Tr B<sup>I</sup> = 0 we can multiply through by nvq I v q J v and sum over v to obtain

$$\sum_{e \in \operatorname{Arr}(v \to w)} n_v n_w q_v^I q_w^J = \sum_{e \in \operatorname{Arr}(w \to v)} n_v n_w q_v^I q_w^J.$$

Using these identities we can simplify

$$\operatorname{Tr} RB^{I}B^{J} = \sum_{e \in \operatorname{Arr}(v \to w)} n_{v} n_{w} (q_{v}^{I} - q_{w}^{I}) (q_{v}^{J} - q_{w}^{J}) (R(e) - 1) + \sum_{e \in \operatorname{Arr}(w \to v)} n_{v} n_{w} (q_{v}^{I} - q_{w}^{I}) (q_{v}^{J} - q_{w}^{J}) (R(e) - 1)$$

to conclude that

$$n_v q_v^I Q_{vw} n_w q_w^J = -\frac{1}{2} \operatorname{Tr} R B^I B^J.$$

Therefore the matrix

$$\langle \phi_J | D_Q^{(1)} | \phi_K \rangle$$
  $J, K = 1, \dots r$ 

is positive definite since Tr RB<sup>I</sup>B<sup>J</sup> is negative definite. This completes the proof of our main result.

## <span id="page-23-0"></span>12 Conclusion

We have established the equivalence of a-maximization and volume minimization for AdS<sup>5</sup> × L 5 compactifications where L 5 is Sasaki-Einstein whenever the quiver gauge theory is known. These are the most general supersymmetric compactifications with only self-dual five-form flux. By restricting to this family of Freund-Rubin compactifications, we have essentially restricted to non-commutative crepant resolutions of the cone X = C(L 5 ). However, more general supersymmetric compactifications of the form AdS<sup>5</sup> × L 5 exist. One famous example is the Pilch-Warner solution [\[47,](#page-27-10) [48,](#page-27-11) [49\]](#page-27-12), which has RR and NS-NS three-form fluxes in addition to the self-dual RR five-form flux.

The most general N = 1 compactification of the form AdS<sup>5</sup> × L <sup>5</sup> with all possible fluxes turned on was considered in [\[50\]](#page-27-13). These geometries can be systematically studied using generalized complex geometry [\[51\]](#page-27-14). The volume calculations of Martelli, Sparks, and Yau based on Duistermaat-Heckman localization have been adapted to this setting [\[52\]](#page-27-15). These geometries are the natural candidates for duals of general superconformal quiver gauge theories. Since our computation of the Hilbert series only required the superpotential algebra to be Calabi-Yau of dimension three, it is likely that the equivalence of volume minimization and a-maximization can be extended to this setting.

Generalizing to AdS5×L 5 compactifications with all fluxes turned on can be viewed as a non-commutative deformation of the usual AdS/CFT correspondence. These deformations have been studied in the context of quiver gauge theories, Calabi-Yau algebras, and in supergravity. Deformations of Calabi-Yau algebras are captured by Hochschild cohomology and correspond to superpotential deformations [\[53,](#page-27-16) [54\]](#page-27-17). A very interesting class of deformations comes from exactly marginal deformations [\[55,](#page-27-18) [56,](#page-28-0) [57\]](#page-28-1). It would be exciting to match exactly marginal deformations of quiver gauge theories to deformations of corresponding generalized complex geometries [\[58\]](#page-28-2).

Hilbert series play an important role in the computation of the BPS index of multitrace operators [\[59,](#page-28-3) [60\]](#page-28-4). Further exploitation of Calabi-Yau algebras [\[37\]](#page-27-0) may yield new results about the BPS index. Another closer related index is the N = 1 superconformal index [\[61,](#page-28-5) [62\]](#page-28-6). It is possible that the superconformal index for quiver gauge theories might have a simple expression as well.

Our method of determining the Hilbert series [\(9.1\)](#page-14-1) provides a new way of determining the singularity associated to a quiver gauge theory. It would be interesting to apply it to gauge theories engineered from branes wrapping obstructed curves [\[63\]](#page-28-7) [\[64\]](#page-28-8). We hope that the Hilbert series will help elucidate the structure of N = 1 superconformal quiver gauge theories. This would greatly enhance our understanding of the AdS/CFT correspondence.

# <span id="page-24-0"></span>13 Acknowledgments

The author would like to thank Charlie Beil, David Berenstein, Aaron Bergman, Johanna Knapp, David Morrison, and Yuji Tachikawa for helpful discussions and the Institute for the Physics and Mathematics of the Universe for providing an ideal environment for the completion of this work. This research was supported in part by the National Science Foundation under grants DMS-0606578 and DMS-1007414 and by the World Premier International Research Center Initiative (WPI Initiative), MEXT, Japan.

## References

- <span id="page-24-1"></span>[1] D. R. Morrison and M. R. Plesser, "Non-spherical horizons. I," Adv. Theor. Math. Phys. 3 (1999) 1–81, [hep-th/9810201](http://arxiv.org/abs/hep-th/9810201).
- <span id="page-24-2"></span>[2] B. S. Acharya, J. M. Figueroa-O'Farrill, C. M. Hull, and B. J. Spence, "Branes at conical singularities and holography," Adv. Theor. Math. Phys. 2 (1999) 1249–1286, [arXiv:hep-th/9808014](http://arxiv.org/abs/hep-th/9808014).
- <span id="page-24-3"></span>[3] S. S. Gubser, "Einstein manifolds and conformal field theories," Phys. Rev. D59 (1999) 025006, [hep-th/9807164](http://arxiv.org/abs/hep-th/9807164).

- <span id="page-25-0"></span>[4] M. Henningson and K. Skenderis, "The holographic Weyl anomaly," JHEP 07 (1998) 023, [arXiv:hep-th/9806087](http://arxiv.org/abs/hep-th/9806087).
- <span id="page-25-1"></span>[5] K. A. Intriligator and B. Wecht, "The exact superconformal R-symmetry maximizes a," Nucl. Phys. B667 [\(2003\) 183–200,](http://dx.doi.org/10.1016/S0550-3213(03)00459-0) [arXiv:hep-th/0304128](http://arxiv.org/abs/hep-th/0304128).
- <span id="page-25-2"></span>[6] D. Martelli, J. Sparks, and S.-T. Yau, "The geometric dual of a-maximisation for toric Sasaki- Einstein manifolds," [Commun. Math. Phys.](http://dx.doi.org/10.1007/s00220-006-0087-0) 268 (2006) 39–65, [arXiv:hep-th/0503183](http://arxiv.org/abs/hep-th/0503183).
- <span id="page-25-3"></span>[7] D. Martelli, J. Sparks, and S.-T. Yau, "Sasaki-Einstein manifolds and volume minimisation," [Commun. Math. Phys.](http://dx.doi.org/10.1007/s00220-008-0479-4) 280 (2008) 611–673, [arXiv:hep-th/0603021](http://arxiv.org/abs/hep-th/0603021).
- <span id="page-25-4"></span>[8] A. Bergman and C. P. Herzog, "The volume of some non-spherical horizons and the AdS/CFT correspondence," JHEP 01 (2002) 030, [arXiv:hep-th/0108020](http://arxiv.org/abs/hep-th/0108020).
- <span id="page-25-5"></span>[9] A. Butti and A. Zaffaroni, "From toric geometry to quiver gauge theory: The equivalence of a-maximization and Z-minimization," [Fortsch. Phys.](http://dx.doi.org/10.1002/prop.200510276) 54 (2006) [309–316,](http://dx.doi.org/10.1002/prop.200510276) [arXiv:hep-th/0512240](http://arxiv.org/abs/hep-th/0512240).
- <span id="page-25-6"></span>[10] S. Lee and S.-J. Rey, "Comments on anomalies and charges of toric-quiver duals," JHEP 03 [\(2006\) 068,](http://dx.doi.org/10.1088/1126-6708/2006/03/068) [arXiv:hep-th/0601223](http://arxiv.org/abs/hep-th/0601223).
- <span id="page-25-7"></span>[11] S. Franco, A. Hanany, K. D. Kennaway, D. Vegh, and B. Wecht, "Brane dimers and quiver gauge theories," JHEP 01 (2006) 096, [arXiv:hep-th/0504110](http://arxiv.org/abs/hep-th/0504110).
- <span id="page-25-8"></span>[12] G. 't Hooft, "Dimensional reduction in quantum gravity," [arXiv:gr-qc/9310026](http://arxiv.org/abs/gr-qc/9310026).
- <span id="page-25-9"></span>[13] L. Susskind, "The world as a hologram," J. Math. Phys. 36 (1995) 6377–6396, [hep-th/9409089](http://arxiv.org/abs/hep-th/9409089).
- <span id="page-25-10"></span>[14] J. P. Gauntlett, D. Martelli, J. Sparks, and S.-T. Yau, "Obstructions to the existence of Sasaki-Einstein metrics," [Commun. Math. Phys.](http://dx.doi.org/10.1007/s00220-007-0213-7) 273 (2007) [803–827,](http://dx.doi.org/10.1007/s00220-007-0213-7) [arXiv:hep-th/0607080](http://arxiv.org/abs/hep-th/0607080).
- <span id="page-25-11"></span>[15] E. Barnes, E. Gorbatov, K. A. Intriligator, and J. Wright, "Current correlators and AdS/CFT geometry," Nucl. Phys. B732 [\(2006\) 89–117,](http://dx.doi.org/10.1016/j.nuclphysb.2005.10.013) [arXiv:hep-th/0507146](http://arxiv.org/abs/hep-th/0507146).
- <span id="page-25-12"></span>[16] S. Benvenuti, L. A. Pando Zayas, and Y. Tachikawa, "Triangle anomalies from Einstein manifolds," Adv. Theor. Math. Phys. 10 (2006) 395–432, [arXiv:hep-th/0601054](http://arxiv.org/abs/hep-th/0601054).
- <span id="page-25-13"></span>[17] S. S. Gubser, I. R. Klebanov, and A. M. Polyakov, "Gauge theory correlators from non-critical string theory," Phys. Lett. B428 (1998) 105–114, [hep-th/9802109](http://arxiv.org/abs/hep-th/9802109).
- <span id="page-25-14"></span>[18] E. Witten, "Anti-de sitter space and holography," Adv. Theor. Math. Phys. 2 (1998) 253–291, [hep-th/9802150](http://arxiv.org/abs/hep-th/9802150). <http://arxiv.org/abs/hep-th/9802150>.
- <span id="page-25-15"></span>[19] S. L. Adler, "Axial vector vertex in spinor electrodynamics," [Phys. Rev.](http://dx.doi.org/10.1103/PhysRev.177.2426) 177 [\(1969\) 2426–2438.](http://dx.doi.org/10.1103/PhysRev.177.2426)

- <span id="page-26-0"></span>[20] J. Bell and R. Jackiw, "A PCAC puzzle: π <sup>0</sup> → γγ in the σ-model," [Nuovo Cim.](http://dx.doi.org/10.1007/BF02823296) A60 [\(1969\) 47–61.](http://dx.doi.org/10.1007/BF02823296)
- <span id="page-26-1"></span>[21] K. A. Intriligator and B. Wecht, "Baryon charges in 4D superconformal field theories and their AdS duals," [Commun. Math. Phys.](http://dx.doi.org/10.1007/s00220-003-1023-1) 245 (2004) 407–424, [arXiv:hep-th/0305046](http://arxiv.org/abs/hep-th/0305046).
- <span id="page-26-2"></span>[22] S. Benvenuti and A. Hanany, "New results on superconformal quivers," JHEP 04 (2006) 032, [arXiv:hep-th/0411262](http://arxiv.org/abs/hep-th/0411262).
- <span id="page-26-3"></span>[23] V. A. Novikov, M. A. Shifman, A. I. Vainshtein, and V. I. Zakharov, "Instanton effects in supersymmetric theories," Nucl. Phys. B229 (1983) 407.
- <span id="page-26-4"></span>[24] M. R. Douglas and G. W. Moore, "D-branes, quivers, and ALE instantons," [hep-th/9603167](http://arxiv.org/abs/hep-th/9603167). <http://arxiv.org/abs/hep-th/9603167>.
- <span id="page-26-5"></span>[25] L. E. Ibanez, R. Rabadan, and A. M. Uranga, "Anomalous U(1)'s in type I and type IIB D = 4, N = 1 string vacua," Nucl. Phys. B542 [\(1999\) 112–138,](http://dx.doi.org/10.1016/S0550-3213(98)00791-3) [arXiv:hep-th/9808139](http://arxiv.org/abs/hep-th/9808139).
- <span id="page-26-6"></span>[26] I. Antoniadis, E. Kiritsis, and J. Rizos, "Anomalous U(1)s in type I superstring vacua," Nucl. Phys. B637 [\(2002\) 92–118,](http://dx.doi.org/10.1016/S0550-3213(02)00458-3) [arXiv:hep-th/0204153](http://arxiv.org/abs/hep-th/0204153).
- <span id="page-26-7"></span>[27] H. Jockers and J. Louis, "The effective action of D7-branes in N = 1 Calabi-Yau orientifolds," Nucl. Phys. B705 [\(2005\) 167–211,](http://dx.doi.org/10.1016/j.nuclphysb.2004.11.009) [arXiv:hep-th/0409098](http://arxiv.org/abs/hep-th/0409098).
- <span id="page-26-8"></span>[28] M. Buican, D. Malyshev, D. R. Morrison, H. Verlinde, and M. Wijnholt, "D-branes at singularities, compactification, and hypercharge," JHEP 01 (2007) 107, [arXiv:hep-th/0610007](http://arxiv.org/abs/hep-th/0610007).
- <span id="page-26-9"></span>[29] D. Martelli and J. Sparks, "Symmetry-breaking vacua and baryon condensates in AdS/CFT," Phys. Rev. D79 [\(2009\) 065009,](http://dx.doi.org/10.1103/PhysRevD.79.065009) [arXiv:0804.3999 \[hep-th\]](http://arxiv.org/abs/0804.3999).
- <span id="page-26-10"></span>[30] D. Anselmi, D. Z. Freedman, M. T. Grisaru, and A. A. Johansen, "Nonperturbative formulas for central functions of supersymmetric gauge theories," Nucl. Phys. B526 (1998) 543–571, [hep-th/9708042](http://arxiv.org/abs/hep-th/9708042).
- <span id="page-26-11"></span>[31] A. Butti and A. Zaffaroni, "R-charges from toric diagrams and the equivalence of a- maximization and Z-minimization," JHEP 11 (2005) 019, [arXiv:hep-th/0506232](http://arxiv.org/abs/hep-th/0506232).
- <span id="page-26-12"></span>[32] D. Kutasov, "New results on the 'a-theorem' in four dimensional supersymmetric field theory," [arXiv:hep-th/0312098](http://arxiv.org/abs/hep-th/0312098).
- <span id="page-26-13"></span>[33] M. Bertolini, F. Bigazzi, and A. L. Cotrone, "New checks and subtleties for AdS/CFT and a- maximization," JHEP 12 [\(2004\) 024,](http://dx.doi.org/10.1088/1126-6708/2004/12/024) [arXiv:hep-th/0411249](http://arxiv.org/abs/hep-th/0411249).
- <span id="page-26-14"></span>[34] S. Benvenuti, S. Franco, A. Hanany, D. Martelli, and J. Sparks, "An infinite family of superconformal quiver gauge theories with Sasaki-Einstein duals," JHEP 06 (2005) 064, [arXiv:hep-th/0411264](http://arxiv.org/abs/hep-th/0411264).
- <span id="page-26-15"></span>[35] D. Berenstein and M. R. Douglas, "Seiberg duality for quiver gauge theories," [arXiv:hep-th/0207027](http://arxiv.org/abs/hep-th/0207027).
- <span id="page-26-16"></span>[36] M. van den Bergh, "Introduction to super potentials." Oberwolfach talk, 2005. [http://www.mfo.de/programme/schedule/2005/06/OWR\\_2005\\_06.pdf](http://www.mfo.de/programme/schedule/2005/06/OWR_2005_06.pdf).

- <span id="page-27-0"></span>[37] V. Ginzburg, "Calabi-yau algebras," [math.RA/0612139](http://arxiv.org/abs/math.RA/0612139).
- <span id="page-27-1"></span>[38] N. Broomhead, Dimer models and Calabi-Yau algebras. PhD thesis, University of Bath, 2009. [arXiv:0901.4662](http://arxiv.org/abs/arXiv:0901.4662).
- <span id="page-27-2"></span>[39] M. Kontsevich, "Formal (non)commutative symplectic geometry," in The Gel<sup>0</sup> fand Mathematical Seminars, 1990–1992, pp. 173–187. Birkh¨auser Boston, Boston, MA, 1993.
- <span id="page-27-3"></span>[40] R. Bocklandt, "Graded Calabi Yau algebras of dimension 3," J. Pure Appl. Algebra 212 (2008) no. 1, 14–32, [math.RA/0603558](http://arxiv.org/abs/math.RA/0603558).
- <span id="page-27-4"></span>[41] S. Mozgovoy and M. Reineke, "On the noncommutative Donaldson-Thomas invariants arising from brane tilings," [arXiv:0809.0117 \[math.AG\]](http://arxiv.org/abs/0809.0117).
- <span id="page-27-5"></span>[42] B. Davison, "Consistency conditions for brane tilings," [arXiv:0812.4185](http://arxiv.org/abs/arXiv:0812.4185).
- <span id="page-27-6"></span>[43] A. I. Bondal and D. Orlov, "Semiorthogonal decompositions for algebraic varieties," [alg-geom/9506012](http://arxiv.org/abs/alg-geom/9506012).
- <span id="page-27-7"></span>[44] M. Van den Bergh, "Three-dimensional flops and noncommutative rings," Duke Math. J. 122 (2004) no. 3, 423–455, [math.AG/0207170](http://arxiv.org/abs/math.AG/0207170).
- <span id="page-27-8"></span>[45] T. Bridgeland, "Flops and derived categories," Invent. Math. 147 (2002) no. 3, 613–632, [math.AG/0009053](http://arxiv.org/abs/math.AG/0009053).
- <span id="page-27-9"></span>[46] M. van den Bergh, "Non-commutative crepant resolutions," in The legacy of Niels Henrik Abel, pp. 749–770. Springer, Berlin, 2004. [math.RA/0211064](http://arxiv.org/abs/math.RA/0211064).
- <span id="page-27-10"></span>[47] A. Khavaev, K. Pilch, and N. P. Warner, "New vacua of gauged N = 8 supergravity in five dimensions," Phys. Lett. B487 [\(2000\) 14–21,](http://dx.doi.org/10.1016/S0370-2693(00)00795-4) [arXiv:hep-th/9812035](http://arxiv.org/abs/hep-th/9812035).
- <span id="page-27-11"></span>[48] D. Z. Freedman, S. S. Gubser, K. Pilch, and N. P. Warner, "Renormalization group flows from holography supersymmetry and a c-theorem," Adv. Theor. Math. Phys. 3 (1999) 363–417, [arXiv:hep-th/9904017](http://arxiv.org/abs/hep-th/9904017).
- <span id="page-27-12"></span>[49] K. Pilch and N. P. Warner, "A new supersymmetric compactification of chiral IIB supergravity," Phys. Lett. B487 [\(2000\) 22–29,](http://dx.doi.org/10.1016/S0370-2693(00)00796-6) [arXiv:hep-th/0002192](http://arxiv.org/abs/hep-th/0002192).
- <span id="page-27-13"></span>[50] J. P. Gauntlett, D. Martelli, J. Sparks, and D. Waldram, "Supersymmetric AdS(5) solutions of type IIB supergravity," [Class. Quant. Grav.](http://dx.doi.org/10.1088/0264-9381/23/14/009) 23 (2006) [4693–4718,](http://dx.doi.org/10.1088/0264-9381/23/14/009) [arXiv:hep-th/0510125](http://arxiv.org/abs/hep-th/0510125).
- <span id="page-27-14"></span>[51] M. Gualtieri, "Generalized complex geometry," [arXiv:math/0401221](http://arxiv.org/abs/math/0401221).
- <span id="page-27-15"></span>[52] M. Gabella, J. P. Gauntlett, E. Palti, J. Sparks, and D. Waldram, "AdS(5) solutions of type IIB supergravity and generalized complex geometry," [Commun.](http://dx.doi.org/10.1007/s00220-010-1083-y) Math. Phys. 299 [\(2010\) 365–408,](http://dx.doi.org/10.1007/s00220-010-1083-y) [arXiv:0906.4109 \[hep-th\]](http://arxiv.org/abs/0906.4109).
- <span id="page-27-16"></span>[53] A. Bergman, "Deformations and D-branes," Adv. Theor. Math. Phys. 12 (2008) 781–815, [arXiv:hep-th/0609225](http://arxiv.org/abs/hep-th/0609225).
- <span id="page-27-17"></span>[54] R. Berger and R. Taillefer, "Poincar´e-Birkhoff-Witt deformations of Calabi-Yau algebras," [J. Noncommut. Geom.](http://dx.doi.org/10.4171/JNCG/6) 1 (2007) no. 2, 241–270.
- <span id="page-27-18"></span>[55] R. G. Leigh and M. J. Strassler, "Exactly marginal operators and duality in four-dimensional N=1 supersymmetric gauge theory," Nucl. Phys. B447 (1995) 95–136, [hep-th/9503121](http://arxiv.org/abs/hep-th/9503121).

- <span id="page-28-0"></span>[56] D. Green, Z. Komargodski, N. Seiberg, Y. Tachikawa, and B. Wecht, "Exactly marginal deformations and global symmetries," JHEP 06 [\(2010\) 106,](http://dx.doi.org/10.1007/JHEP06(2010)106) [arXiv:1005.3546 \[hep-th\]](http://arxiv.org/abs/1005.3546).
- <span id="page-28-1"></span>[57] D. Erkal and D. Kutasov, "a-maximization, global symmetries and RG flows," [arXiv:1007.2176 \[hep-th\]](http://arxiv.org/abs/1007.2176).
- <span id="page-28-2"></span>[58] P. Koerber and L. Martucci, "Deformations of calibrated D-branes in flux generalized complex manifolds," JHEP 12 (2006) 062, [arXiv:hep-th/0610044](http://arxiv.org/abs/hep-th/0610044).
- <span id="page-28-3"></span>[59] S. Benvenuti, B. Feng, A. Hanany, and Y.-H. He, "Counting BPS operators in gauge theories: Quivers, syzygies and plethystics," [hep-th/0608050](http://arxiv.org/abs/hep-th/0608050).
- <span id="page-28-4"></span>[60] D. Forcella, A. Hanany, Y.-H. He, and A. Zaffaroni, "The Master Space of N=1 Gauge Theories," JHEP 08 [\(2008\) 012,](http://dx.doi.org/10.1088/1126-6708/2008/08/012) [arXiv:0801.1585 \[hep-th\]](http://arxiv.org/abs/0801.1585).
- <span id="page-28-5"></span>[61] C. Romelsberger, "Counting chiral primaries in N = 1, d=4 superconformal field theories," Nucl. Phys. B747 [\(2006\) 329–353,](http://dx.doi.org/10.1016/j.nuclphysb.2006.03.037) [arXiv:hep-th/0510060](http://arxiv.org/abs/hep-th/0510060).
- <span id="page-28-6"></span>[62] J. Kinney, J. M. Maldacena, S. Minwalla, and S. Raju, "An index for 4 dimensional super conformal theories," [Commun. Math. Phys.](http://dx.doi.org/10.1007/s00220-007-0258-7) 275 (2007) [209–254,](http://dx.doi.org/10.1007/s00220-007-0258-7) [arXiv:hep-th/0510251](http://arxiv.org/abs/hep-th/0510251).
- <span id="page-28-7"></span>[63] F. Cachazo, S. Katz, and C. Vafa, "Geometric transitions and N = 1 quiver theories," [arXiv:hep-th/0108120](http://arxiv.org/abs/hep-th/0108120).
- <span id="page-28-8"></span>[64] P. S. Aspinwall and D. R. Morrison, "Quivers from matrix factorizations," [arXiv:1005.1042 \[hep-th\]](http://arxiv.org/abs/1005.1042).