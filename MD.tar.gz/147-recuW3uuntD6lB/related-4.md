## Non-equilibrium thermodynamics

Contributors to Wikimedia projects

**Non-equilibrium thermodynamics** is a branch of <u>thermodynamics</u> that deals with physical systems that are not in <u>thermodynamic equilibrium</u> but can be described in terms of macroscopic quantities (non-equilibrium state variables) that represent an extrapolation of the variables used to specify the system in thermodynamic equilibrium. Non-equilibrium thermodynamics is concerned with <u>transport processes</u> and with the rates of chemical reactions.

Almost all systems found in nature are not in thermodynamic equilibrium, for they are changing or can be triggered to change over time, and are continuously and discontinuously subject to flux of matter and energy to and from other systems and to chemical reactions. Many systems and processes can, however, be considered to be in equilibrium locally, thus allowing description by currently known equilibrium thermodynamics. Nevertheless, some natural systems and processes remain beyond the scope of equilibrium thermodynamic methods due to the existence of non variational dynamics, where the concept of free energy is lost.

The thermodynamic study of non-equilibrium systems requires more general concepts than are dealt with by equilibrium thermodynamics. One fundamental difference between equilibrium thermodynamics and non-equilibrium thermodynamics lies in the behaviour of inhomogeneous systems, which require for their study knowledge of rates of reaction which are not considered in equilibrium thermodynamics of homogeneous systems. This is discussed below. Another fundamental and very important difference is the difficulty, in defining entropy at an instant of time in macroscopic terms for systems not in thermodynamic equilibrium. However, it can be done locally, and the macroscopic entropy will then be given by the integral of the locally defined entropy density. It has been found that many systems far outside global equilibrium still obey the concept of local equilibrium.

# Difference between equilibrium and non-equilibrium thermodynamics

#### [edit]

A profound difference separates equilibrium from non-equilibrium thermodynamics. Equilibrium thermodynamics ignores the time-courses of physical processes. In contrast, non-equilibrium thermodynamics attempts to describe their time-courses in

continuous detail.

Equilibrium thermodynamics restricts its considerations to processes that have initial and final states of thermodynamic equilibrium; the time-courses of processes are deliberately ignored. Non-equilibrium thermodynamics, on the other hand, attempting to describe continuous time-courses, needs its <u>state variables</u> to have a very close connection with those of equilibrium thermodynamics. This conceptual issue is overcome under the assumption of local equilibrium, which entails that the relationships that hold between macroscopic state variables at equilibrium hold locally, also outside equilibrium. Throughout the past decades, the assumption of local equilibrium has been tested, and found to hold, under increasingly extreme conditions, such as in the shock front of violent explosions, on reacting surfaces, and under extreme thermal gradients.

Thus, non-equilibrium thermodynamics provides a consistent framework for modelling not only the initial and final states of a system, but also the evolution of the system in time. Together with the concept of entropy production, this provides a powerful tool in process optimisation, and provides a theoretical foundation for exergy analysis.

## Non-equilibrium state variables

## [edit]

The suitable relationship that defines non-equilibrium thermodynamic state variables is as follows. When the system is in local equilibrium, non-equilibrium state variables are such that they can be measured locally with sufficient accuracy by the same techniques as are used to measure thermodynamic state variables, or by corresponding time and space derivatives, including fluxes of matter and energy. In general, non-equilibrium thermodynamic systems are spatially and temporally non-uniform, but their non-uniformity still has a sufficient degree of smoothness to support the existence of suitable time and space derivatives of non-equilibrium state variables.

Because of the spatial non-uniformity, non-equilibrium state variables that correspond to extensive thermodynamic state variables have to be defined as spatial densities of the corresponding extensive equilibrium state variables. When the system is in local equilibrium, intensive non-equilibrium state variables, for example temperature and pressure, correspond closely with equilibrium state variables. It is necessary that measuring probes be small enough, and rapidly enough responding, to capture relevant non-uniformity. Further, the non-equilibrium state variables are required to be mathematically functionally related to one another in ways that suitably resemble corresponding relations between equilibrium thermodynamic state variables. In reality, these requirements, although strict, have been shown to be fulfilled even under extreme

conditions, such as during phase transitions, at reacting interfaces, and in plasma droplets surrounded by ambient air. There are, however, situations where there are appreciable non-linear effects even at the local scale.

Some concepts of particular importance for non-equilibrium thermodynamics include time rate of dissipation of energy (Rayleigh 1873, Onsager 1931, also), time rate of entropy production (Onsager 1931), thermodynamic fields, dissipative structure, and non-linear dynamical structure.

One problem of interest is the thermodynamic study of non-equilibrium <u>steady states</u>, in which <u>entropy</u> production and some <u>flows</u> are non-zero, but there is no <u>time variation</u> of physical variables.

One initial approach to non-equilibrium thermodynamics is sometimes called 'classical irreversible thermodynamics'. There are other approaches to non-equilibrium thermodynamics, for example <u>extended irreversible thermodynamics</u>, and generalized thermodynamics, but they are hardly touched on in the present article.

# Quasi-radiationless non-equilibrium thermodynamics of matter in laboratory conditions

## [edit]

According to Wildt (see also Essex), current versions of non-equilibrium thermodynamics ignore radiant heat; they can do so because they refer to laboratory quantities of matter under laboratory conditions with temperatures well below those of stars. At laboratory temperatures, in laboratory quantities of matter, thermal radiation is weak and can be practically nearly ignored. But, for example, atmospheric physics is concerned with large amounts of matter, occupying cubic kilometers, that, taken as a whole, are not within the range of laboratory quantities; then thermal radiation cannot be ignored.

## Local equilibrium thermodynamics

## [edit]

The terms 'classical irreversible thermodynamics' and 'local equilibrium thermodynamics' are sometimes used to refer to a version of non-equilibrium thermodynamics that demands certain simplifying assumptions, as follows. The assumptions have the effect of making each very small <u>volume element</u> of the system effectively homogeneous, or well-mixed, or without an effective spatial structure. Even within the thought-frame of classical irreversible thermodynamics, care is needed in

titiiii tiio tiiougiit iitiiiio oi viiddiciii iitotoldidio tiioliiioujiiiiiiioo, ciito ii iioouou iii

choosing the independent variables for systems. In some writings, it is assumed that the intensive variables of equilibrium thermodynamics are sufficient as the independent variables for the task (such variables are considered to have no 'memory', and do not show <a href="https://www.hysteresis">hysteresis</a>); in particular, local flow intensive variables are not admitted as independent variables; local flows are considered as dependent on quasi-static local intensive variables.

Also it is assumed that the local entropy density is the same function of the other local intensive variables as in equilibrium; this is called the local thermodynamic equilibrium assumption (see also Keizer (1987)). Radiation is ignored because it is transfer of energy between regions, which can be remote from one another. In the classical irreversible thermodynamic approach, there is allowed spatial variation from infinitesimal volume element to adjacent infinitesimal volume element, but it is assumed that the global entropy of the system can be found by simple spatial integration of the local entropy density. This approach assumes spatial and temporal continuity and even differentiability of locally defined intensive variables such as temperature and internal energy density. While these demands may appear severely constrictive, it has been found that the assumptions of local equilibrium hold for a wide variety of systems, including reacting interfaces, on the surfaces of catalysts, in confined systems such as zeolites, under temperature gradients as large as

 $10^{12}$  K m  $^{-1}$ 

, and even in shock fronts moving at up to six times the speed of sound.

In other writings, local flow variables are considered; these might be considered as classical by analogy with the time-invariant long-term time-averages of flows produced by endlessly repeated cyclic processes; examples with flows are in the <a href="https://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://examples.com/htm://

## Local equilibrium thermodynamics with materials with "memory"

#### [edit]

A further extension of local equilibrium thermodynamics is to allow that materials may have "memory", so that their <u>constitutive equations</u> depend not only on present values but also on past values of local equilibrium variables. Thus time comes into the picture more deeply than for time-dependent local equilibrium thermodynamics with

memoryless materials, but fluxes are not independent variables of state.

## **Extended irreversible thermodynamics**

[edit]

Extended irreversible thermodynamics is a branch of non-equilibrium thermodynamics that goes outside the restriction to the local equilibrium hypothesis. The space of state variables is enlarged by including the <u>fluxes</u> of mass, momentum and energy and eventually higher order fluxes. The formalism is well-suited for describing high-frequency processes and small-length scales materials.

There are many examples of stationary non-equilibrium systems, some very simple, like a system confined between two thermostats at different temperatures or the ordinary <a href="Couette flow">Couette flow</a>, a fluid enclosed between two flat walls moving in opposite directions and defining non-equilibrium conditions at the walls. <a href="Laser">Laser</a> action is also a non-equilibrium process, but it depends on departure from local thermodynamic equilibrium and is thus beyond the scope of classical irreversible thermodynamics; here a strong temperature difference is maintained between two molecular degrees of freedom (with molecular laser, vibrational and rotational molecular motion), the requirement for two component 'temperatures' in the one small region of space, precluding local thermodynamic equilibrium, which demands that only one temperature be needed. Damping of acoustic perturbations or shock waves are non-stationary non-equilibrium processes. Driven <a href="Complex fluids">complex fluids</a>, turbulent systems and glasses are other examples of non-equilibrium systems.

The mechanics of macroscopic systems depends on a number of extensive quantities. It should be stressed that all systems are permanently interacting with their surroundings, thereby causing unavoidable fluctuations of extensive quantities. Equilibrium conditions of thermodynamic systems are related to the maximum property of the entropy. If the only extensive quantity that is allowed to fluctuate is the internal energy, all the other ones being kept strictly constant, the temperature of the system is measurable and meaningful. The system's properties are then most conveniently described using the thermodynamic potential Helmholtz free energy (A = U - TS), a Legendre transformation of the energy. If, next to fluctuations of the energy, the macroscopic dimensions (volume) of the system are left fluctuating, we use the Gibbs free energy (G = U + PV - TS), where the system's properties are determined both by the temperature and by the pressure.

Non-equilibrium systems are much more complex and they may undergo fluctuations of more extensive quantities. The boundary conditions impose on them particular intensive variables, like temperature gradients or distorted collective motions (shear motions,

vortices, etc.), often called thermodynamic forces. If free energies are very useful in equilibrium thermodynamics, it must be stressed that there is no general law defining stationary non-equilibrium properties of the energy as is the second law of thermodynamics for the <u>entropy</u> in equilibrium thermodynamics. That is why in such cases a more generalized Legendre transformation should be considered. This is the extended Massieu potential. By definition, the <u>entropy</u> (*S*) is a function of the collection of extensive quantities

 $E_i$ 

. Each extensive quantity has a conjugate intensive variable

 $I_i$ 

(a restricted definition of intensive variable is used here by comparison to the definition given in this link) so that:

$$I_i = rac{\partial S}{\partial E_i}.$$

We then define the extended Massieu function as follows:

$$k_{
m B}M=S-\sum_i (I_iE_i),$$

where

 $k_{
m B}$ 

is the Boltzmann constant, whence

$$k_{
m B} \ dM = \sum_i (E_i \ dI_i).$$

The independent variables are the intensities.

Intensities are global values, valid for the system as a whole. When boundaries impose to the system different local conditions, (e.g. temperature differences), there are intensive variables representing the average value and others representing gradients or higher moments. The latter are the thermodynamic forces driving fluxes of extensive properties through the system.

It may be shown that the Legendre transformation changes the maximum condition of the entropy (valid at equilibrium) in a minimum condition of the extended Massieu function for stationary states, no matter whether at equilibrium or not.

## Stationary states, fluctuations, and stability

[edit]

In thermodynamics one is often interested in a stationary state of a process, allowing

in mormougnamics one is often interested in a stationary state of a process, anowing

that the stationary state include the occurrence of unpredictable and experimentally unreproducible fluctuations in the state of the system. The fluctuations are due to the system's internal sub-processes and to exchange of matter or energy with the system's surroundings that create the constraints that define the process.

If the stationary state of the process is stable, then the unreproducible fluctuations involve local transient decreases of entropy. The reproducible response of the system is then to increase the entropy back to its maximum by irreversible processes: the fluctuation cannot be reproduced with a significant level of probability. Fluctuations about stable stationary states are extremely small except near critical points (Kondepudi and Prigogine 1998, page 323). The stable stationary state has a local maximum of entropy and is locally the most reproducible state of the system. There are theorems about the irreversible dissipation of fluctuations. Here 'local' means local with respect to the abstract space of thermodynamic coordinates of state of the system.

If the stationary state is unstable, then any fluctuation will almost surely trigger the virtually explosive departure of the system from the unstable stationary state. This can be accompanied by increased export of entropy.

## Local thermodynamic equilibrium

#### [edit]

The scope of present-day non-equilibrium thermodynamics does not cover all physical processes. A condition for the validity of many studies in non-equilibrium thermodynamics of matter is that they deal with what is known as *local thermodynamic equilibrium*.

Local thermodynamic equilibrium of matter (see also Keizer (1987) means that conceptually, for study and analysis, the system can be spatially and temporally divided into 'cells' or 'micro-phases' of small (infinitesimal) size, in which classical thermodynamical equilibrium conditions for matter are fulfilled to good approximation. These conditions are unfulfilled, for example, in very rarefied gases, in which molecular collisions are infrequent; and in the boundary layers of a star, where radiation is passing energy to space; and for interacting fermions at very low temperature, where dissipative processes become ineffective. When these 'cells' are defined, one admits that matter and energy may pass freely between contiguous 'cells', slowly enough to leave the 'cells' in their respective individual local thermodynamic equilibria with respect to intensive variables.

One can think here of two 'relaxation times' separated by order of magnitude. The longer

relaxation time is of the order of magnitude of times taken for the macroscopic dynamical structure of the system to change. The shorter is of the order of magnitude of times taken for a single 'cell' to reach local thermodynamic equilibrium. If these two relaxation times are not well separated, then the classical non-equilibrium thermodynamical concept of local thermodynamic equilibrium loses its meaning and other approaches have to be proposed, see for instance <a href="Extended irreversible">Extended irreversible</a> thermodynamics. For example, in the atmosphere, the speed of sound is much greater than the wind speed; this favours the idea of local thermodynamic equilibrium of matter for atmospheric heat transfer studies at altitudes below about 60 km where sound propagates, but not above 100 km, where, because of the paucity of intermolecular collisions, sound does not propagate.

## Milne's definition in terms of radiative equilibrium

## [edit]

Edward A. Milne, thinking about stars, gave a definition of 'local thermodynamic equilibrium' in terms of the <a href="thermal radiation">thermal radiation</a> of the <a href="matter">matter</a> in each small local 'cell'. He defined 'local thermodynamic equilibrium' in a 'cell' by requiring that it macroscopically absorb and spontaneously emit radiation as if it were in radiative equilibrium in a cavity at the <a href="temperature">temperature</a> of the matter of the 'cell'. Then it strictly obeys Kirchhoff's law of equality of radiative emissivity and absorptivity, with a black body source function. The key to local thermodynamic equilibrium here is that the rate of collisions of ponderable matter particles such as molecules should far exceed the rates of creation and annihilation of photons.

## **Entropy in evolving systems**

#### [edit]

It is pointed out by W.T. Grandy Jr, that entropy, though it may be defined for a non-equilibrium system is—when strictly considered—only a macroscopic quantity that refers to the whole system, and is not a dynamical variable and in general does not act as a local potential that describes local physical forces. Under special circumstances, however, one can metaphorically think as if the thermal variables behaved like local physical forces. The approximation that constitutes classical irreversible thermodynamics is built on this metaphoric thinking.

This point of view shares many points in common with the concept and the use of entropy in continuum thermomechanics, which evolved completely independently of statistical mechanics and maximum-entropy principles.

## **Entropy in non-equilibrium**

## [edit]

To describe deviation of the thermodynamic system from equilibrium, in addition to constitutive variables

$$x_1, x_2, \ldots, x_n$$

that are used to fix the equilibrium state, as was described above, a set of variables

$$\xi_1, \xi_2, \dots$$

that are called *internal variables* have been introduced. The equilibrium state is considered to be stable and the main property of the internal variables, as measures of non-equilibrium of the system, is their tending to disappear; the local law of disappearing can be written as relaxation equation for each internal variable

$$rac{d\xi_i}{dt} = -rac{1}{ au_i}\,\left(\xi_i - \xi_i^{(0)}
ight), \quad i=1,\,2,\ldots,$$

1

where

$$au_i = au_i(T, x_1, x_2, \ldots, x_n)$$

is a relaxation time of a corresponding variables. It is convenient to consider the initial value

$$\xi_i^0$$

are equal to zero. The above equation is valid for small deviations from equilibrium; The dynamics of internal variables in general case is considered by Pokrovskii.

Entropy of the system in non-equilibrium is a function of the total set of variables

$$S=S(T,x_1,x_2,,x_n;\xi_1,\xi_2,\ldots)$$
 1

The essential contribution to the thermodynamics of the non-equilibrium systems was brought by the <u>Nobel Prize</u> winner Ilya <u>Prigogine</u>, when he and his collaborators investigated the systems of chemically reacting substances. The stationary states of such systems exists due to exchange both particles and energy with the environment. In section 8 of the third chapter of his book, Prigogine has specified three contributions to the variation of entropy of the considered system at the given volume and constant temperature

T

. The increment of entropy

S

can be calculated according to the formula

1

The first term on the right hand side of the equation presents a stream of thermal energy into the system; the last term—a part of a stream of energy

 $h_{0}$ 

coming into the system with the stream of particles of substances

$$\Delta N_{\rm o}$$

that can be positive or negative,

$$\eta_{\alpha} = h_{\alpha} - \mu_{\alpha}$$

, where

 $\mu_{\alpha}$ 

is chemical potential of substance

 $\alpha$ 

. The middle term in (1) depicts <u>energy dissipation</u> (<u>entropy production</u>) due to the relaxation of internal variables

 $\xi_j$ 

. In the case of chemically reacting substances, which was investigated by Prigogine, the internal variables appear to be measures of incompleteness of chemical reactions, that is measures of how much the considered system with chemical reactions is out of equilibrium. The theory can be generalised, to consider any deviation from the equilibrium state as an internal variable, so that we consider the set of internal variables

 $\xi_i$ 

in equation (1) to consist of the quantities defining not only degrees of completeness of all chemical reactions occurring in the system, but also the structure of the system, gradients of temperature, difference of concentrations of substances and so on.

The fundamental relation of classical equilibrium thermodynamics

$$dS = rac{1}{T}dU + rac{p}{T}dV - \sum_{i=1}^s rac{\mu_i}{T}dN_i$$

expresses the change in entropy

dS

of a system as a function of the intensive quantities temperature

T

, pressure

p

and

 $i^{th}$ 

chemical potential

 $\mu_i$ 

and of the differentials of the extensive quantities energy

| , <u>volume</u> | V        |
|-----------------|----------|
| and             | V        |
| 2.20            | $i^{th}$ |
| particle number | $N_{i}$  |
|                 | ·        |

Following Onsager (1931,I), let us extend our considerations to thermodynamically nonequilibrium systems. As a basis, we need locally defined versions of the extensive macroscopic quantities

|                                             | U       |
|---------------------------------------------|---------|
| ,                                           | V       |
| and                                         | 3.7     |
| and of the intensive macroscopic quantities | $N_i$   |
|                                             | T       |
| ,                                           | p       |
| and                                         | $\mu_i$ |
|                                             | , ,     |

For classical non-equilibrium studies, we will consider some new locally defined intensive macroscopic variables. We can, under suitable conditions, derive these new variables by locally defining the gradients and flux densities of the basic locally defined macroscopic quantities.

Such locally defined gradients of intensive macroscopic variables are called 'thermodynamic forces'. They 'drive' flux densities, perhaps misleadingly often called 'fluxes', which are dual to the forces. These quantities are defined in the article on Onsager reciprocal relations.

Establishing the relation between such forces and flux densities is a problem in statistical mechanics. Flux densities (

 $J_i$ 

) may be coupled. The article on Onsager reciprocal relations considers the stable nearsteady thermodynamically non-equilibrium regime, which has dynamics linear in the forces and flux densities.

In stationary conditions, such forces and associated flux densities are by definition time invariant, as also are the system's locally defined entropy and rate of entropy production. Notably, according to <u>Ilya Prigogine</u> and others, when an open system is in conditions that allow it to reach a stable stationary thermodynamically non-equilibrium state, it

organizes itself so as to minimize total entropy production defined locally. This is considered further below.

One wants to take the analysis to the further stage of describing the behaviour of surface and volume integrals of non-stationary local quantities; these integrals are macroscopic fluxes and production rates. In general the dynamics of these integrals are not adequately described by linear equations, though in special cases they can be so described.

## **Onsager reciprocal relations**

[edit]

Following Section III of Rayleigh (1873), Onsager (1931, I) showed that in the regime where both the flows (

 $J_i$ 

) are small and the thermodynamic forces (

 $F_i$ 

) vary slowly, the rate of creation of entropy

 $(\sigma)$ 

is linearly related to the flows:

$$\sigma = \sum_i J_i rac{\partial F_i}{\partial x_i}$$

and the flows are related to the gradient of the forces, parametrized by a <u>matrix</u> of coefficients conventionally denoted

L

:

$$J_i = \sum_j L_{ij} rac{\partial F_j}{\partial x_j}$$

from which it follows that:

$$\sigma = \sum_{i,j} L_{ij} rac{\partial F_i}{\partial x_i} rac{\partial F_j}{\partial x_j}$$

The second law of thermodynamics requires that the matrix

L

be <u>positive definite</u>. <u>Statistical mechanics</u> considerations involving microscopic reversibility of dynamics imply that the matrix

L

is symmetric. This fact is called the *Onsager reciprocal relations*.

The generalization of the above equations for the rate of creation of entropy was given by Pokrovskii.

## Speculated extremal principles for nonequilibrium processes

### [edit]

Until recently, prospects for useful extremal principles in this area have seemed clouded. Nicolis (1999) concludes that one model of atmospheric dynamics has an attractor which is not a regime of maximum or minimum dissipation; she says this seems to rule out the existence of a global organizing principle, and comments that this is to some extent disappointing; she also points to the difficulty of finding a thermodynamically consistent form of entropy production. Another top expert offers an extensive discussion of the possibilities for principles of extrema of entropy production and of dissipation of energy: Chapter 12 of Grandy (2008) is very cautious, and finds difficulty in defining the 'rate of internal entropy production in many cases, and finds that sometimes for the prediction of the course of a process, an extremum of the quantity called the rate of dissipation of energy may be more useful than that of the rate of entropy production; this quantity appeared in Onsager's 1931 origination of this subject. Other writers have also felt that prospects for general global extremal principles are clouded. Such writers include Glansdorff and Prigogine (1971), Lebon, Jou and Casas-Vásquez (2008), and Šilhavý (1997). There is good experimental evidence that heat convection does not obey extremal principles for time rate of entropy production. Theoretical analysis shows that chemical reactions do not obey extremal principles for the second differential of time rate of entropy production. The development of a general extremal principle seems infeasible in the current state of knowledge.

Non-equilibrium thermodynamics has been successfully applied to describe biological processes such as protein folding/unfolding and transport through membranes. It is also used to give a description of the dynamics of nanoparticles, which can be out of equilibrium in systems where catalysis and electrochemical conversion is involved. Also, ideas from non-equilibrium thermodynamics and the informatic theory of entropy have been adapted to describe general economic systems.

- \* Time crystal
- \* Dissipative system
- Entropy production
- \* Extremal principles in non-equilibrium thermodynamics

- Self-organization
- Autocatalytic reactions and order creation
- Self-organizing criticality
- Bogoliubov-Born-Green-Kirkwood-Yvon hierarchy of equations
- \* Boltzmann equation
- \*Vlasov equation
- Maxwell's demon
- Information entropy
- Spontaneous symmetry breaking
- Frenesy
- \* Autopoiesis
- Maximum power principle
- <sup>1.</sup> ^ Kjelstrup, S; Bedeaux, D; Johannessen, E; Gross, J (June 2010). Non-Equilibrium Thermodynamics for Engineers. WORLD SCIENTIFIC. doi:10.1142/7869. ISBN 978-981-4322-15-7.
- <sup>2.</sup> Bodenschatz, Eberhard; Cannell, David S.; de Bruyn, John R.; Ecke, Robert; Hu, Yu-Chou; <u>Lerman, Kristina</u>; Ahlers, Guenter (December 1992). "Experiments on three systems with non-variational aspects". Physica D: Nonlinear Phenomena. 61 (1–4): 77–93. <u>Bibcode</u>:1992PhyD...61...77B. doi:10.1016/0167-2789(92)90150-L.
- <sup>3.</sup> Pokrovskii, Vladimir (2020). Thermodynamics of Complex Systems: Principles and applications. IOP Publishing, Bristol, UK. Bibcode: 2020tcsp.book....P.
- <sup>4.</sup> Groot, Sybren Ruurds de; Mazur, Peter (1984). Non-equilibrium thermodynamics. Dover books on physics (Dover ed., 1. publ., unabridged, corr. republ ed.). New York, NY: Dover Publ. ISBN 978-0-486-64741-8.
- Stability, and Fluctuations, Wiley-Interscience, London, 1971, <u>ISBN</u> 0-471-30280-
- 6. ^ De Groot, S.R., Mazur, P. (1962). *Non-equilibrium Thermodynamics*, North-Holland, Amsterdam.
- 7. ^ Hafskjold, Bjørn; Bedeaux, Dick; Kjelstrup, Signe; Wilhelmsen, Øivind (2021-07-23). "Theory and simulation of shock waves: Entropy production and energy conversion". Physical Review E. 104 (1) 014131. arXiv:2102.09019.
  Bibcode:2021PhRvE.104a4131H. doi:10.1103/PhysRevE.104.014131. ISSN 2470-0045. PMID 34412362.
- 8. ^ Kjelstrup, S.; Bedeaux, D.; Inzoli, I.; Simon, J. -M. (2008-08-01). "Criteria for validity of thermodynamic equations from non-equilibrium molecular dynamics simulations". Energy. 33 (8): 1185–1196. Bibcode: 2008Ene....33.1185K. doi:10.1016/j.energy.2008.04.005. ISSN 0360-5442.

- tool to describe phase transitions far from global equilibrium". Chemical Engineering Science. **59** (1): 109–118. <u>Bibcode</u>: 2004ChEnS..59..109B. doi:10.1016/j.ces.2003.09.028. ISSN 0009-2509.
- <sup>10.</sup> ^ Gyarmati, I. (1967/1970).
- <sup>11.</sup> Barthélemy, Olivier; Margot, Joëlle; Laville, Stéphane; Vidal, François; Chaker, Mohamed; Le Drogoff, Boris; Johnston, Tudor W.; Sabsabi, Mohamad (April 2005). "Investigation of the State of Local Thermodynamic Equilibrium of a Laser-Produced Aluminum Plasma". Applied Spectroscopy. 59 (4): 529–536. <a href="Bibcode:2005ApSpe..59..529B">Bibcode:2005ApSpe..59..529B</a>. doi:10.1366/0003702053641531. ISSN 0003-7028. PMID 15901339. S2CID 31762955.
- <sup>12.</sup> Kjelstrup Ratkje, Signe (1991-01-01). "Local heat changes during aluminium electrolysis". Electrochimica Acta. **36** (3): 661–665. doi:10.1016/0013-4686(91)85155-Z. ISSN 0013-4686.
- 13. Costa e Silva, André; Ågren, John; Clavaguera-Mora, Maria Teresa; Djurovic, D.; Gomez-Acebo, Tomas; Lee, Byeong-Joo; Liu, Zi-Kui; Miodownik, Peter; Seifert, Hans Juergen (2007-03-01). "Applications of computational thermodynamics the extension from phase equilibrium to phase transformations and other properties". Calphad. 31 (1): 53-74. doi:10.1016/j.calphad.2006.02.006. ISSN 0364-5916.
- <sup>14.</sup> Sobolev, S. L. (October 2015). "Rapid phase transformation under local non-equilibrium diffusion conditions". Materials Science and Technology. **31** (13): 1607–1617. Bibcode: 2015MatST..31.1607S. doi:10.1179/1743284715Y.0000000051. ISSN 0267-0836. S2CID 59366545.
- <sup>15.</sup> Hillert, M.; Rettenmayr, M. (2003-06-11). "Deviation from local equilibrium at migrating phase interfaces". Acta Materialia. **51** (10): 2803–2809.

  <u>Bibcode: 2003AcMat..51.2803H</u>. doi:10.1016/S1359-6454(03)00085-5.

  ISSN 1359-6454.
- 16. ^ Strutt, J. W. (1871). "Some General Theorems relating to Vibrations".

  Proceedings of the London Mathematical Society. **\$1-4**: 357–368.

  doi:10.1112/plms/\$1-4.1.357.
- <sup>17.</sup> ^ Onsager, L. (1931). <u>"Reciprocal relations in irreversible processes, I"</u>. Physical Review. **37** (4): 405–426. <u>Bibcode</u>:1931PhRv...37..4050. doi:10.1103/PhysRev.37.405.
- <sup>18.</sup> ^ Lavenda, B.H. (1978). *Thermodynamics of Irreversible Processes*, Macmillan, London, <u>ISBN</u> 0-333-21616-4.
- <sup>19</sup>· Gyarmati, I. (1967/1970), pages 4-14.
- <sup>20</sup> Ziegler, H., (1983). An Introduction to Thermomechanics, North-Holland, Amsterdam, <u>ISBN</u> 0-444-86503-9.
- <sup>21.</sup> Balescu, R. (1975). Equilibrium and Non-equilibrium Statistical Mechanics,
  Wiley-Interscience, New York, ISBN 0-471-04600-0, Section 2-2, pages 64-72

- 11110) III. (150101100, 11011 1011, 10111 0 4/1 04000 0, 00011011 3.2, pages 04 /2.
- <sup>22.</sup> ^ Lebon, G., Jou, D., Casas-Vázquez, J. (2008). *Understanding Non-equilibrium Thermodynamics: Foundations, Applications, Frontiers*, Springer-Verlag, Berlin, e-ISBN 978-3-540-74252-4.
- <sup>23.</sup> ^ Jou, D., Casas-Vázquez, J., Lebon, G. (1993). *Extended Irreversible Thermodynamics*, Springer, Berlin, ISBN 3-540-55874-8, ISBN 0-387-55874-8.
- <sup>24.</sup> Eu, B.C. (2002).
- <sup>25.</sup> Wildt, R. (1972). "Thermodynamics of the gray atmosphere. IV. Entropy transfer and production". Astrophysical Journal. 174: 69–77.

  Bibcode:1972ApJ...174...69W. doi:10.1086/151469.
- <sup>26.</sup> Essex, C. (1984a). "Radiation and the irreversible thermodynamics of climate".

  Journal of the Atmospheric Sciences. **41** (12): 1985–1991.

  <u>Bibcode</u>: 1984JAtS...41.1985E. doi:10.1175/15200469(1984)041<1985:RATITO>2.0.CO;2...
- <sup>27.</sup> Essex, C. (1984b). "Minimum entropy production in the steady state and radiative transfer". Astrophysical Journal. **285**: 279–293. <u>Bibcode</u>:1984ApJ...285..279E. doi:10.1086/162504.
- <sup>28.</sup> Essex, C. (1984c). "Radiation and the violation of bilinearity in the irreversible thermodynamics of irreversible processes". Planetary and Space Science. **32** (8): 1035–1043. Bibcode:1984P&SS...32.1035E. doi:10.1016/0032-0633(84)90060-6.
- <sup>29.</sup> Prigogine, I., Defay, R. (1950/1954). *Chemical Thermodynamics*, Longmans, Green & Co, London, page 1.
- <sup>30.</sup> ^ Balescu, R. (1975). *Equilibrium and Non-equilibrium Statistical Mechanics*, John Wiley & Sons, New York, ISBN 0-471-04600-0.
- 31. ^ Mihalas, D., Weibel-Mihalas, B. (1984). Foundations of Radiation

  Hydrodynamics, Oxford University Press, New York Archived 2011-10-08 at the

  Wayback Machine ISBN 0-19-503437-6.
- <sup>32.</sup> ^ Schloegl, F. (1989). *Probability and Heat: Fundamentals of Thermostatistics*, Freidr. Vieweg & Sohn, Braunschweig, ISBN 3-528-06343-2.
- 33. ^ Keizer, J. (1987). Statistical Thermodynamics of Nonequilibrium Processes, Springer-Verlag, New York, ISBN 0-387-96501-7.
- <sup>34.</sup> Kjelstrup, Signe; Bedeaux, Dick (September 2020). Non-equilibrium

  Thermodynamics of Heterogeneous Systems. Series on Advances in Statistical

  Mechanics. Vol. 20 (2 ed.). WORLD SCIENTIFIC. doi:10.1142/11729. ISBN 978-981-12-1676-3.
- <sup>35.</sup> Kondepudi, D. (2008). *Introduction to Modern Thermodynamics*, Wiley, Chichester UK, ISBN 978-0-470-01598-8, pages 333-338.
- 36. Coleman, B.D.; Noll, W. (1963). "The thermodynamics of elastic materials with heat conduction and viscosity". Arch. Ration. Mach. Analysis. 13 (1): 167–178.

  Bibcode:1963ArRMA..13..167C. doi:10.1007/bf01262690. S2CID 189793830.
- 37. Kondepudi, D., Prigogine, I. (1998). Modern Thermodunamics. From Heat

- Engines to Dissipative Structures, Wiley, Chichester, 1998, ISBN 0-471-97394-7.
- <sup>38.</sup> ^ <u>Zubarev D. N.</u>,(1974). *Nonequilibrium Statistical Thermodynamics*, translated from the Russian by P.J. Shepherd, New York, Consultants Bureau. <u>ISBN</u> 0-306-10895-X; <u>ISBN</u> 978-0-306-10895-2.
- 39. Milne, E.A. (1928). <u>"The effect of collisions on monochromatic radiative</u> equilibrium". <u>Monthly Notices of the Royal Astronomical Society</u>. **88** (6): 493–502. Bibcode:1928MNRAS..88..493M. doi:10.1093/mnras/88.6.493.
- 40. Grandy, W.T. Jr. (2004). <u>"Time Evolution in Macroscopic Systems. I. Equations of Motion"</u>. Foundations of Physics. **34** (1): 1. <u>arXiv:cond-mat/0303290</u>. <u>Bibcode:2004FoPh...34....1G</u>. <u>doi:10.1023/B:FOOP.0000012007.06843.ed</u>. S2CID 13096766.
- 41. Grandy, W.T. Jr. (2004). <u>"Time Evolution in Macroscopic Systems. II. The Entropy"</u>. Foundations of Physics. **34** (1): 21. <u>arXiv:cond-mat/0303291</u>. <u>Bibcode:2004FoPh...34...21G</u>. <u>doi:10.1023/B:FOOP.0000012008.36856.c1</u>. S2CID 18573684.
- 42. Grandy, W. T. Jr (2004). <u>"Time Evolution in Macroscopic Systems. III: Selected Applications"</u>. Foundations of Physics. **34** (5): 771. <u>Bibcode</u>:2004FoPh...34..771G. doi:10.1023/B:FOOP.0000022187.45866.81. S2CID 119406182.
- 43. Grandy 2004 see also [1].
- <sup>44.</sup> Truesdell, Clifford (1984). Rational Thermodynamics (2 ed.). Springer.
- 45. Maugin, Gérard A. (2002). Continuum Thermomechanics. Kluwer.
- 46. Gurtin, Morton E. (2010). The Mechanics and Thermodynamics of Continua. Cambridge University Press.
- <sup>47.</sup> Amendola, Giovambattista (2012). Thermodynamics of Materials with Memory: Theory and Applications. Springer.
- 48. ^ Pokrovskii V.N. (2013) A derivation of the main relations of non-equilibrium thermodynamics. Hindawi Publishing Corporation: ISRN Thermodynamics, vol. 2013, article ID 906136, 9 p. https://dx.doi.org/10.1155/2013/906136.
- <sup>49.</sup> Prigogine, I. (1955/1961/1967). *Introduction to Thermodynamics of Irreversible Processes*. 3rd edition, Wiley Interscience, New York.
- <sup>50.</sup> Pokrovskii V.N. (2005) Extended thermodynamics in a discrete-system approach, Eur. J. Phys. vol. 26, 769-781.
- <sup>51.</sup> W. Greiner, L. Neise, and H. Stöcker (1997), Thermodynamics and Statistical Mechanics (Classical Theoretical Physics), Springer-Verlag, New York, P85, 91, 101,108,116, ISBN 0-387-94299-8.
- 52. Nicolis, C. (1999). "Entropy production and dynamical complexity in a low-order atmospheric model". Quarterly Journal of the Royal Meteorological Society. 125 (557): 1859–1878. <u>Bibcode</u>:1999QJRMS.125.1859N. <u>doi:10.1002/qj.49712555718</u>. <u>S2CID</u> 121536072.
- 53. Grandy, W.T., Jr (2008).

- <sup>54.</sup> Attard, P. (2012). "Optimising Principle for Non-Equilibrium Phase Transitions and Pattern Formation with Results for Heat Convection". <u>arXiv</u>:1208.5105 [cond-mat.stat-mech].
- 55. Keizer, J.; Fox, R. (January 1974). "Qualms Regarding the Range of Validity of the Glansdorff-Prigogine Criterion for Stability of Non-Equilibrium States".

  PNAS. 71 (1): 192–196. Bibcode:1974PNAS...71..192K. doi:10.1073/pnas.71.1.192. PMC 387963. PMID 16592132.
- <sup>56.</sup> Kimizuka, Hideo; Kaibara, Kozue (September 1975). "Nonequilibrium thermodynamics of ion transport through membranes". Journal of Colloid and Interface Science. **52** (3): 516–525. <u>Bibcode</u>: 1975JCIS...52..516K. doi:10.1016/0021-9797(75)90276-3.
- <sup>57.</sup> Baranowski, B. (April 1991). "Non-equilibrium thermodynamics as applied to membrane transport". Journal of Membrane Science. **57** (2–3): 119–159. doi:10.1016/S0376-7388(00)80675-4.
- <sup>58.</sup> Bazant, Martin Z. (22 March 2013). "Theory of Chemical Kinetics and Charge Transfer based on Nonequilibrium Thermodynamics". Accounts of Chemical Research. 46 (5): 1144–1160. arXiv:1208.1587. doi:10.1021/ar300145c. PMID 23520980. S2CID 10827167.
- <sup>59.</sup> Pokrovskii, Vladimir (2011). Econodynamics. The Theory of Social Production. Springer, Dordrecht-Heidelberg-London-New York.
- <sup>60.</sup> Chen, Jing (2015). The Unity of Science and Economics: A New Foundation of Economic Theory. Springer.
  - <u>Callen, H.B.</u> (1960/1985). Thermodynamics and an Introduction to Thermostatistics, (1st edition 1960) 2nd edition 1985, Wiley, New York, <u>ISBN</u> 0-471-86256-8.
  - Eu, B.C. (2002). Generalized Thermodynamics. The Thermodynamics of Irreversible Processes and Generalized Hydrodynamics, Kluwer Academic Publishers, Dordrecht, <u>ISBN</u> 1-4020-0788-4.
  - Glansdorff, P., <u>Prigogine, I.</u> (1971). *Thermodynamic Theory of Structure, Stability, and Fluctuations*, Wiley-Interscience, London, 1971, ISBN 0-471-30280-5.
  - Grandy, W.T. Jr (2008). Entropy and the Time Evolution of Macroscopic Systems. Oxford University Press. ISBN 978-0-19-954617-6.
  - Gyarmati, I. (1967/1970). *Non-equilibrium Thermodynamics. Field Theory and Variational Principles*, translated from the Hungarian (1967) by E. Gyarmati and W.F. Heinz, Springer, Berlin.
  - <u>Lieb, E.H.</u>, <u>Yngvason, J.</u> (1999). 'The physics and mathematics of the second law of thermodynamics', *Physics Reports*, **310**: 1–96. See also this.
  - \* Ziegler, Hans (1977): An introduction to Thermomechanics. North Holland, Amsterdam. ISBN 0-444-11080-1. Second edition (1983) ISBN 0-444-86503-9.

• Visiter A. Lenner D.D. editerra (2007). New confliction There are described

Kleidon, A., Lorenz, R.D., editors (2005). *Non-equilibrium Thermodynamics and the Production of Entropy*, Springer, Berlin. <u>ISBN</u> 3-540-22495-5.

- Prigogine, I. (1955/1961/1967). Introduction to Thermodynamics of Irreversible Processes. 3rd edition, Wiley Interscience, New York.
- <sup>•</sup> Zubarev D. N. (1974): *Nonequilibrium Statistical Thermodynamics*. New York, Consultants Bureau. ISBN 0-306-10895-X; ISBN 978-0-306-10895-2.
- Keizer, J. (1987). Statistical Thermodynamics of Nonequilibrium Processes, Springer-Verlag, New York, ISBN 0-387-96501-7.
- Zubarev D. N., Morozov V., Ropke G. (1996): Statistical Mechanics of Nonequilibrium Processes: Basic Concepts, Kinetic Theory. John Wiley & Sons. ISBN 3-05-501708-0.
- <u>Zubarev D. N.</u>, Morozov V., Ropke G. (1997): Statistical Mechanics of Nonequilibrium Processes: Relaxation and Hydrodynamic Processes. John Wiley & Sons. ISBN 3-527-40084-2.
- Tuck, Adrian F. (2008). Atmospheric turbulence: a molecular dynamics perspective. Oxford University Press. ISBN 978-0-19-923653-4.
- Grandy, W.T. Jr (2008). *Entropy and the Time Evolution of Macroscopic Systems*. Oxford University Press. ISBN 978-0-19-954617-6.
- \* Kondepudi, D., Prigogine, I. (1998). *Modern Thermodynamics: From Heat Engines to Dissipative Structures*. John Wiley & Sons, Chichester. <u>ISBN</u> 0-471-97393-9.
- de Groot S.R., <u>Mazur P.</u> (1984). *Non-Equilibrium Thermodynamics* (Dover). <u>ISBN</u> 0-486-64741-2
- Ramiro Augusto Salazar La Rotta. (2011). The Non-Equilibrium Thermodynamics, Perpetual
- Stephan Herminghaus' Dynamics of Complex Fluids Department at the Max Planck Institute for Dynamics and Self Organization
- Non-equilibrium Statistical Thermodynamics applied to Fluid Dynamics and Laser Physics 1992- book by Xavier de Hemptinne.
- \* Nonequilibrium Thermodynamics of Small Systems PhysicsToday.org
- Into the Cool 2005 book by Dorion Sagan and Eric D. Schneider, on nonequilibrium thermodynamics and evolutionary theory.
- \* "Thermodynamics "beyond" local equilibrium"