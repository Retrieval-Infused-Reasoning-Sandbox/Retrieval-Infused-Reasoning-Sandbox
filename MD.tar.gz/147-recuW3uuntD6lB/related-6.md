# Physics of Active Emulsions

Christoph A. Weber1,2,3,<sup>∗</sup> , David Zwicker1,4,<sup>∗</sup> , Frank J¨ulicher1,<sup>2</sup> and Chiu Fan Lee<sup>5</sup>

- <sup>1</sup> Max Planck Institute for the Physics of Complex Systems, N¨othnitzer Str. 38, 01187 Dresden, Germany
- <sup>2</sup> Center for Systems Biology Dresden, CSBD, Dresden, Germany
- <sup>3</sup> Paulson School of Engineering and Applied Sciences, Harvard University, Cambridge, MA 02138, USA
- <sup>4</sup> Max Planck Institute for Dynamics and Self-Organization, Am Faßberg 17, 37077 G¨ottingen, Germany
- <sup>5</sup> Department of Bioengineering, Imperial College London, South Kensington Campus, London SW7 2AZ, U.K.
- <sup>∗</sup> equal contribution

E-mail: weber@pks.mpg.de, david.zwicker@ds.mpg.de, julicher@pks.mpg.de, c.lee@imperial.ac.uk

Version of draft: 12 October 2018

Abstract. Phase separating systems that are maintained away from thermodynamic equilibrium via molecular processes represent a class of active systems, which we call active emulsions. These systems are driven by external energy input for example provided by an external fuel reservoir. The external energy input gives rise to novel phenomena that are not present in passive systems. For instance, concentration gradients can spatially organise emulsions and cause novel droplet size distributions. Another example are active droplets that are subject to chemical reactions such that their nucleation and size can be controlled and they can spontaneously divide. In this review we discuss the physics of phase separation and emulsions and show how the concepts that governs such phenomena can be extended to capture the physics of active emulsions. This physics is relevant to the spatial organisation of the biochemistry in living cells, for the development novel applications in chemical engineering and models for the origin of life.

PACS numbers: 47.55.D-, 05.70.Ln, 47.10.ab, 82.40.Qt, 82.60.Hc, 83.80.Tc, 87.10.Ca, 87.15.R-, 87.16.Uv

Keywords: active emulsions, active droplets, liquid phase separation, droplet ripening in concentration gradients, positioning of droplets, driven chemical reactions in emulsions, suppression of Ostwald-ripening, division of droplets, shape deformations and instabilities of droplets.

### 1. Introduction: From passive to active emulsions

The formation and dynamics of condensed phases such as droplets represent ubiquitous phenomena that we all experience in our daily life [\[1\]](#page-39-0). Examples are droplets condensing on the leaves of flowers and trees due to the supersaturated fog in the morning of some autumn day, or the "ouzo effect", where the oil droplets in Ouzo grow in size and cloud the liquid. These transitions from a homogeneous mixture to a system with coexisting phases can be controlled by temperature or by changing the composition of the mixture. The physical conditions under which a mixture phase separates are well-understood. The interactions that favour the accumulation of components of the same type must exceed the entropic tendency of the system to remain mixed [\[2–](#page-39-1)[4\]](#page-39-2). After drops have been nucleated, they undergo a ripening dynamics. Droplets either fuse, or larger droplets grow at the expense of smaller ones which then disappear. The latter phenomenon is referred to as Ostwald ripening [\[5\]](#page-39-3). During the ripening dynamics the droplet size distribution continuously broadens. In the case of Ostwald ripening the droplet size distribution exhibits an universal scaling in time t with the mean droplet size ∝ t 1/3 , which was derived by Lifschitz and Slyozov [\[6](#page-39-4)[–8\]](#page-39-5). However, at large times-scales, droplet growth saturates and ripening stops as there is only one droplet left in the system. This condensed droplet stably coexists with a surrounding minority phase of lower solute concentration.

The behaviour of droplets can change in more complex environments. For instance, liquid condensed phases can interact with surfaces by wetting [\[9](#page-39-6)[–11\]](#page-39-7). Droplets embedded in a gel matrix interact such that the droplet size can be tuned by changing the mechanical properties of the gel [\[12\]](#page-39-8). Droplets can also behave differently in transient systems, which have not yet reached equilibrium. For instance, surfactants exchanging with the surrounding solvent can induce Marangoni flows, which can propel droplets [\[13–](#page-39-9)[17\]](#page-39-10) and even lead to spontaneous division [\[18\]](#page-39-11). Generally, more complex behavior can be expected when multiple phases of different composition come in contact and exchange material [\[19–](#page-39-12)[23\]](#page-39-13).

Liquid condensed phases are also influenced by external "forces" such as gravitation, concentration or temperature gradients, magnetic or electric fields [\[24,](#page-39-14) [25\]](#page-39-15). In industrial manufacturing and processing, temperature gradients and sedimentation are explicitly taken advantage of, e.g., for extracting crude oil [\[26\]](#page-39-16). Moreover, concentration [\[27,](#page-39-17) [28\]](#page-39-18) and temperature gradients [\[29,](#page-39-19)[30\]](#page-40-0) are commonly used to assemble synthetic membranes for electro-optical devices. Recently, the equations governing the ripening dynamics of droplets derived by Lifschitz and Slyozov have been extended to account for the presence of a concentration gradient [\[31,](#page-40-1) [32\]](#page-40-2). It has been theoretically shown that droplets can be positioned along the concentration gradient and that the universal scaling in time of droplet ripening breaks down.

Liquid condensed phases are also ideal compartments to organise chemical reactions since they can enrich specific chemical components. In particular, chemical agents mix rapidly in small droplets, and thus control the timing of chemical reactions [\[33,](#page-40-3) [34\]](#page-40-4). The interface of droplets can serve to concentrate reactants, resulting in a speed up of the reaction [\[35\]](#page-40-5). Liquid droplets in the presence of chemical reactions can even propel across a solid substrate [\[15,](#page-39-20) [36–](#page-40-6)[38\]](#page-40-7) or flow past a chemically patterned substrate leading to unique morphological instabilities [\[39\]](#page-40-8). They also provide model systems to study interactions of pattern forming systems. For example, droplets containing agents undergoing oscillatory Belousov-Zhabotinsky reactions have been considered as coupled phase oscillators [\[40,](#page-40-9) [41\]](#page-40-10). Recently, it had been suggested that phase separated liquid-like compartments composted of oppositely charged molecules, called coacervates, could be ideal seeds for prebiotic life [\[42\]](#page-40-11). In particular, RNA catalysis is viable within these coacervate droplets and they even provide a mechanism for length selection of RNA [\[43\]](#page-40-12). In all these systems, the droplet material does not participate in the chemical reaction.

If the phase separated material undergoes a chemical reaction itself, new physical behaviours can emerge. In passive systems, where phase separation and chemical reactions are in thermal equilibrium, coexisting phases cannot be stable. These systems settle in a homogeneous state that corresponds to the free energy minimum [\[44\]](#page-40-13). Conversely, if the chemical reaction is driven away from equilibrium, phase separation can be maintained. Under some conditions an arrest of the ripening dynamics has been observed in numerical simulations [\[45–](#page-40-14)[58\]](#page-40-15) and in experiments where chemical reactions are induced by light [\[59–](#page-40-16)[66\]](#page-41-0) or proceed spontaneously [\[67–](#page-41-1)[74\]](#page-41-2). Recently, it has been shown that the chemical reaction between the droplet material can indeed suppress Oswald ripening leading to an emulsion composed of drops of identical size [\[75–](#page-41-3)[77\]](#page-41-4). Driven chemical reactions can initiate droplet formation as a response to external stimuli [\[78\]](#page-41-5) and they can even trigger the division of droplets [\[79\]](#page-41-6). Recent experiments on droplets in the presence of nonequilibrium turnover reactions showed the assembly of supramolecular structures with a tuneable lifetime [\[80\]](#page-41-7) and serve as a model for molecular selection of reaction products and their assemblies [\[81\]](#page-41-8). These examples highlight the rich phenomenology emerging from the interplay of phase separation with chemical reactions.

Phase separated systems in the presence of external forces and chemical reactions actively driven away from thermal equilibrium are a novel class of physical systems. Many physical properties known from passive emulsions are altered and novel phenomena occur. Since energy input is typically necessary to generate external forces, and to drive chemical reactions away from equilibrium, we refer to these systems as active emulsions.

An intriguing example where the physics of these active emulsions is relevant are living cells. Biological function inside cells is attained by the spatial-temporal organisation of biomolecules and the control of their chemical reactions. For this purpose the interior of the cell is divided into compartments, referred to as organelles. Each organelle has a chemical identity due to a distinct composition of functional biomolecules. Some organelles, such as mitochondria, are surrounded by membranes that are permeated by active channels regulating chemical potential differences across the membrane [82]. However, there are also organelles that do not posses any membrane; they are called non-membrane bound compartments or biomolecular condensates [83–88]. To maintain their chemical identity in the absence of a membrane, it has been suggested that these compartments are liquid droplets formed by liquid-liquid phase separation [31, 89, 90]. Recently, many organelles have been found with properties reminiscent of liquid droplets [87, 91, 92]. Examples include mRNA-protein-condensates [90, 93], RNA polymerase clusters [94,95], centrosomes [75,96], and multiple nuclear subcompartments [97, 98]. These findings suggest that the cytoplasm can be regarded as a multi-component emulsion hosting a large variety of coexisting phases, each of distinct composition [99– 102. In contrast to passive emulsions, cellular droplets exist in the non-equilibrium environment of living cells. The associated continuous dissipation of energy can be used to drive chemical reactions or generate concentration gradients of molecular species. processes can affect the dynamics and stability of these active droplets and cause behaviours not observed for passive droplets [88, 103].

Here we review recent theoretical approaches used to describe droplets and emulsions under conditions that deviate from passive phase separating systems. Our review starts with an introduction to passive phase separation and dynamics of emulsion undergoing Ostwald ripening (section 2). In section 3, we discuss phase separation and dynamics of droplets in the presences of external forces and concentrations gradients, while section 4 considers the dynamics and stability of droplets under the influence of chemical reactions that are driven away from thermal equilibrium.

# <span id="page-2-0"></span>2. Liquid-liquid phase separation of binary mixtures

Phase separation refers to the spontaneous partitioning of a system into subsystems with distinct macroscopic properties. Examples include the cellular compartments mentioned in the introduction, but also many everyday phenomena that range from fog in the morning to oil droplet formation in salad dressings. In this section, we will discuss the physical principles and derive the equations describing the dynamics of phase separation and the ripening of droplets in liquid emulsions.

#### <span id="page-2-3"></span>2.1. Statistical mechanics of a binary mixture

We start by considering a binary, incompressible mixture consisting of two types of molecules on a lattice with M sites. Each lattice site is occupied by either molecule A or B, with  $N_A$  and  $N_B$  representing their total numbers in the system, so  $N_A + N_B = M$ . The system is at thermal equilibrium with a heat bath at temperature T. The thermodynamic properties of the system are thus dictated by the partition function [104]

<span id="page-2-1"></span>
$$Z = \sum_{\Omega} \exp\left(-\frac{H(\sigma_1, ..., \sigma_M)}{k_{\rm B}T}\right) , \qquad (2.1)$$

where the Hamiltonian  $H(\sigma_1, ..., \sigma_M)$  denotes the energy of a particular arrangement  $\sigma_1, ..., \sigma_M$  of the molecules on the lattice and  $k_B$  is the Boltzmann constant. Here, we encode the arrangements using a binary variable  $\sigma_n$ , where  $\sigma_n = 1$  if the lattice site n is occupied by molecule A and  $\sigma_n = 0$  if it is occupied by B.  $\Omega$  refers to the set of all possible arrangements considering that the molecules A are indistinguishable from each other; the same applies to molecules B [105]. For simplicity, we only consider nearest neighbour interactions, which are described by the following Hamiltonian [106]

<span id="page-2-2"></span>
$$H(\lbrace \sigma \rbrace) = \frac{1}{2} \sum_{(m,n)} \left( e_{AA} \sigma_m \sigma_n + e_{BB} (1 - \sigma_m) (1 - \sigma_n) + e_{AB} \left[ \sigma_m (1 - \sigma_n) + \sigma_n (1 - \sigma_m) \right] \right), \quad (2.2)$$

where the summation is over all nearest neighbour pairs (m,n) on the lattice and the factor  $\frac{1}{2}$  avoids the double counting of interaction pairs. Here, the interaction parameters  $e_{ij}$  determine what particle types tend to be next to each other. For instance, if  $e_{AA} < 0$ , two A molecules on neighbouring sites lower the total energy, making this configuration more probable. In general, these interaction parameters can arise from various physical interactions that may include dipolar and van der Waals interactions, screened electrostatic interactions

between charged molecular groups or entropy-driven hydrophobic interactions [106–108].

<span id="page-3-2"></span>2.1.1. Thermodynamics of a homogeneous mixture. Within the canonical ensemble a homogeneous binary mixture of volume V can be characterised by the Helmholtz free energy F = E - TS, which combines the internal energy E and the entropy S of a system. This free energy can be expressed by the partition function (2.1) [104, 109, 110]

<span id="page-3-0"></span>
$$F(T, V, N_A, N_B) = -k_B T \ln Z(T, V, N_A, N_B)$$
. (2.3)

Derivatives of the free energy F are related to thermodynamic quantities that are relevant in our discussion of phase separation. In particular, the entropy is given as  $S = -\partial F/\partial T|_{V,N_A,N_B}$ , the pressure is  $p = -\partial F/\partial V|_{T,N_A,N_B}$  and the chemical potentials read  $\mu_A = \partial F/\partial N_A|_{T,V,N_B}$  and  $\mu_B = \partial F/\partial N_B|_{T,V,N_A}$ .

For simplicity, we focus on an incompressible binary system of constant volume  $V = \nu M$  and constant molecular volume  $\nu$  of the two components. In this case, adding an A molecule to the system corresponds to removing a B molecule. Consequently, the relevant thermodynamic quantities are the exchange chemical potential  $\bar{\mu}$  and the osmotic pressure  $\Pi$  [106, 111]:

$$\bar{\mu} = \left. \frac{\partial F}{\partial N_A} \right|_{T,V} = -\left. \frac{\partial F}{\partial N_B} \right|_{T,V} = \nu \left. \frac{\partial f}{\partial \phi} \right|_{T}, \quad (2.4a)$$

$$\Pi = -\left. \frac{\partial F}{\partial V} \right|_{T, N_A} = -f + \phi \left. \frac{\partial f}{\partial \phi} \right|_T, \qquad (2.4b)$$

where the number of lattice sites M is slaved to the total volume by  $M=V/\nu$ . Here, we used the homogeneity of the system,  $F=Vf(\phi)$ , where  $f(\phi)$  is the free energy density as a function of the volume fraction  $\phi=N_A\nu/V$  of A molecules.

The homogeneous state for a given volume is a stable thermodynamic state if it corresponds to a minimum of the free energy F. This requires that the curvature of the free energy density as a function of volume fraction is convex, i.e.,  $f''(\phi) \geq$ 0. The link between stability and curvature of the free energy density can be understood qualitatively: conservation of molecule numbers implies that raising the volume fraction in one spatial region requires lowering it in another. If the free energy density is convex, any such perturbation increases the overall free energy. This can be shown rigorously by considering spatially inhomogeneous perturbations that conserve molecule numbers. We will discuss this approach after introducing the free energy functional in section 2.1.5.

The stability of the homogenous state can also be shown using an ensemble where the particle number  $N_A$  is fixed and the volume V can change. This ensemble is governed by the thermodynamic potential

 $G(N_A,\Pi) = F(N_A,V) + V\Pi$ , where  $\Pi$  is the osmotic pressure given by equation (2.4b) and the volume  $V = \partial G/\partial \Pi$ . A homogeneous state with the osmotic pressure  $\Pi$  is stable if the free energy G as a function of  $\Pi$  is concave,  $\partial^2 G/\partial \Pi^2 < 0$ . The concavity of G with respect to variations of the osmotic pressure can be seen by writing  $\partial^2 G/\partial \Pi^2 = \partial V/\partial \Pi = -V\kappa$ , where  $\kappa$  is the osmotic compressibility  $\kappa = -V^{-1}\partial V/\partial \Pi$ . For the homogeneous state to be stable, the osmotic pressure should increase as the volume decreases, i.e.,  $\kappa > 0$ , to push the system back to its thermodynamic state after a perturbation in volume. This condition is satisfied if the free energy density is convex,  $f''(\phi) > 0$ , since  $\kappa =$  $(\phi^2 f''(\phi))^{-1}$ . In the thermodynamic limit, ensembles become equivalent and thus the convexity of the free energy density determines the thermodynamic stability of the homogeneous state, not only in the ensemble  $(N_A,\Pi)$  where the osmotic pressure is imposed but also in the ensemble  $(N_A, V)$  where the volume is fixed.

2.1.2. Mean field free energy density of an incompressible mixture. To determine the relevant thermodynamic quantities for phase separation, we need to evaluate the free energy and the partition function given in equation (2.3). Since this is generally difficult, we discuss a mean-field approximation for the homogeneous case of the incompressible binary mixture on a lattice characterised by the Hamiltonian given in equation (2.2). This approximation neglects the spatial correlations between the molecules. Within the mean field approximation, the probability that lattice site n is occupied by A, is given by  $\langle \sigma_n \rangle = N_A/M$ , where  $\langle \ldots \rangle$  denotes the average in the canonical ensemble and  $\phi = N_A/M$  is the volume fraction of A molecules in the system. Due to incompressibility the probability of the site being occupied by B is  $N_B/M = 1 - \phi$ . The partition function hence is

<span id="page-3-3"></span><span id="page-3-1"></span>
$$Z \simeq |\Omega| \exp\left(-\frac{E(\phi)}{k_{\rm B}T}\right)$$
 (2.5)

with the internal energy given as

$$E(\phi) = \frac{zM}{2} \left[ e_{AA}\phi^2 + 2e_{AB}\phi(1-\phi) + e_{BB}(1-\phi)^2 \right],$$
(2.6)

where z is the number of neighbours per lattice site (e.g., z=6 for a cubic lattice), and zM/2 is the total number of distinct nearest neighbours. The number  $|\Omega|$  of all possible arrangements on the lattice appearing in equation (2.5),

$$|\Omega| = {M \choose N_A} = {M \choose N_B} = \frac{M!}{N_A!N_B!}, \qquad (2.7)$$

determines the entropy  $S = k_{\rm B} \ln |\Omega|$  for the incompressible binary mixture on a lattice, which

is also referred to as mixing entropy. Using equations (2.3), we obtain the free energy density

$$f(\phi) \simeq \frac{z}{2\nu} \left[ e_{AA} \phi^2 + 2e_{AB} \phi (1 - \phi) + e_{BB} (1 - \phi)^2 \right] + \frac{k_{\rm B} T}{\nu} \left[ \phi \ln \phi + (1 - \phi) \ln (1 - \phi) \right],$$
(2.8)

where we have used Stirling's approximation,  $\ln N! \simeq N \ln N - N$ , to evaluate the factorials. The free energy density can also be written as  $f(\phi) = \phi f(1) + (1 - \phi) f(0) + f_{\text{mix}}(\phi)$ , which separates the contribution of the pure systems from the *free energy of mixing* [106, 108],

<span id="page-4-1"></span>
$$f_{\text{mix}}(\phi) = \frac{k_{\text{B}}T}{\nu} \left[ \phi \ln \phi + (1 - \phi) \ln(1 - \phi) + \chi \phi (1 - \phi) \right]$$
(2.9)

where

<span id="page-4-5"></span>
$$\chi = \frac{z}{2k_{\rm B}T} \left( 2e_{AB} - e_{AA} - e_{BB} \right) \tag{2.10}$$

is the Flory-Huggins interaction parameter [3, 4].  $f_{\rm mix}$  captures the competition between the mixing entropy  $S = -k_{\rm B}(V/\nu) \left[\phi \ln \phi + (1-\phi) \ln(1-\phi)\right]$  and the molecular interactions characterised by the single parameter  $\chi$ . In the next section, we will see that both the free energy density (equation (2.8)) and the free energy density of mixing (equation (2.9)) lead to the same phase separation equilibrium. However, the difference will become apparent when we discuss chemical reactions in section 4.

The free energy density  $f_{\rm mix}$  is a symmetric function with respect to  $\phi = \frac{1}{2}$ . This symmetry stems from considering equal molecular volumes of components A and B and the subtraction of the free energy before mixing. Conversely, if the molecules A and B have different molecular volumes  $n_A \nu$  and  $n_B \nu$ , the free energy of mixing is not symmetric [3,4]:

$$\tilde{f}_{\text{mix}}(\phi) = \frac{k_{\text{B}}T}{\nu} \left[ \frac{\phi}{n_A} \ln \phi + \frac{(1-\phi)}{n_B} \ln(1-\phi) + \chi \phi (1-\phi) \right], \qquad (2.11)$$

where  $n_A$  and  $n_B$  denote the non-dimensional molecular size in multiples of the volume  $\nu$  of a single lattice site.

Homogeneous states governed by the free energy density  $f(\phi)$  are only stable when the free energy density is convex,  $f''(\phi) > 0$ ; see section 2.1.1. For the expression given in equation (2.8) this is the case for all  $\phi$  in the absence of interactions  $(e_{ij} = 0$  for i, j = A, B) and when entropic effects dominate. In the presence of interactions however, the free energy density of the homogeneous system can become concave  $(f''(\phi) < 0)$  within a range of volume fractions  $\phi$ , see figure 2.1(a). Within this range, the homogeneous state is not stable, implying that the thermodynamic equilibrium state is inhomogeneous.

<span id="page-4-0"></span>![](_page_4_Figure_13.jpeg)

<span id="page-4-2"></span>Figure 2.1. (a) Sketch of an asymmetric free energy density  $f(\phi)$  for an incompressible binary mixture as a function of volume fraction  $\phi$ , e.g., equation (2.11) for the case  $n_B > n_A$ and  $\chi > 2$ . In the presence of interactions, there can be a range of volume fractions where the free energy density is concave with  $f''(\phi) < 0$ . The Maxwell tangent construction modifies the free energy within the volume fraction range  $[\phi_1, \phi_2]$  (orange line). As a result the free energy density becomes convex for all volume fractions. The equilibrium volume fraction of each phase are  $\phi_1$ and  $\phi_2$ . The impact of surface tension slightly increases the equilibrium volume fractions (blue dots, see section 2.5.1). (b) Phase diagram as a function of the Flory-Huggins interaction parameter  $\chi$  and volume fraction  $\phi$ . For large enough interaction parameters, phase separation can occur. The corresponding region in the phase diagram is bordered by the binodal line. The tie lines (green) connect the equilibrium volume fractions of two coexisting phases on the binodal line. The dashed line refers to the spinodal. Within the spinodal lines, the mixture can undergo a spontaneous partitioning into two phases, while between the spinodal and the binodal, only large enough phase separated domains can grow. This regime is referred to as nucleation & growth.

<span id="page-4-6"></span>2.1.3. Phase coexistence. The simplest inhomogeneous state corresponds to two subsystems of different volume fractions, also referred to as phases. The associated free energy can be written as

<span id="page-4-4"></span>
$$F \simeq V_1 f(\phi_1) + V_2 f(\phi_2)$$
, (2.12)

<span id="page-4-3"></span>where  $\phi_{\alpha}$  and  $V_{\alpha}$  denote the volume fraction and volume of phase  $\alpha$ , with  $\alpha=1,2$ . The incompressibility assumption combined with conservation of particles implies  $V_1 + V_2 = V$  and  $V_1\phi_1 + V_2\phi_2 = V\phi$ . Consequently, there are only two independent variables in the free energy above, e.g.,  $\phi_1$  and  $V_1$ . In equation (2.12) we neglected the energetic contribution of the interface region that separates the two phases. This is valid in the thermodynamic limit where the system and the volumes of the phases are infinitely large, so the energetic contribution of the interface is negligible relative to the contribution of the phases. We will have to refine equation (2.12) when discussing finite systems in section 2.2.

The inhomogeneous state is stable if it corresponds to a minimum of the free energy (2.12) consistent with the imposed constraint of particle conservation and in the absence of vacancies. To find this minimum, we differentiate F with respect to  $\phi_1$  and  $V_1$ , respectively, use the relationship  $\phi_2 = (\phi V - \phi_1 V_1)/(V - V_1)$  and set each expression to zero:

<span id="page-5-0"></span>
$$0 = f'(\phi_1) - f'(\phi_2), \qquad (2.13a)$$

$$0 = f(\phi_1) - f(\phi_2) + (\phi_2 - \phi_1) f'(\phi_2). \tag{2.13b}$$

The first equation is a balance of the exchange chemical potentials between phases,  $\bar{\mu}_1 = \bar{\mu}_2$ , with  $\bar{\mu}_{\alpha} = \bar{\mu}|_{\phi = \phi_{\alpha}}$  with  $\alpha = 1, 2$ ; see equation (2.4a)). The second equation corresponds to the balance of the osmotic pressures between the two phases,  $\Pi_1 = \Pi_2$ , with  $\Pi_{\alpha} = \Pi|_{\phi = \phi_{\alpha}}$ ; see equation (2.4b).

Obviously, equations (2.13) are satisfied for homogeneous systems with  $\phi_1 = \phi_2$ . To see that there also exist solutions with  $\phi_1 \neq \phi_2$ , the two conditions can be represented by a graphical tangent construction using the free energy density  $f(\phi)$ , see figure 2.1(a). Here, condition (2.13a) implies that the slopes at the volume fractions  $\phi_1$  and  $\phi_2$  are the same and condition (2.13b) states that they are also equal to the slope of the line connecting the points  $(\phi_1, f(\phi_1))$  and  $(\phi_2, f(\phi_2))$ . Taken together, these conditions can only be satisfied by a common tangent to the two points. This procedure of finding the equilibrium volume fractions is known as Maxwell's tangent construction or construction of the convex hull. The orange line in figure 2.1(a) shows the result of such a construction. In fact, inserting condition (2.13b) into equation (2.12)(and using conservation of A particles) shows that this line corresponds to the volume weighted average of the free energy density of the two subsystems. Consequently, the corresponding demixed system is the thermodynamic equilibrium since it has a lower free energy than the mixed system described by the black line in figure 2.1(a). Accordingly,  $\phi_1$  and  $\phi_2$  are referred to as equilibrium volume fractions of the coexisting phases. Clearly, a separation into two phases with volume fractions  $\phi_1$  and  $\phi_2$  is only possible when the average volume fraction  $\phi$  obeys  $\phi_1 < \phi < \phi_2$ . Outside this region, the homogeneous state is stable, since  $f''(\phi) > 0$ .

The parameter region where phase separation is possible can be determined from the solutions  $\phi_1$ and  $\phi_2$  as a function of the interaction parameter  $\chi$ , see figure 2.1(b). The corresponding line is called the binodal line. In the simple case of the symmetric free energy of mixing (equation (2.9)),  $f_{\text{mix}}(\phi_1) = f_{\text{mix}}(\phi_2)$ and  $f'_{\text{mix}}(\phi_1) = f'_{\text{mix}}(\phi_2) = 0$ . The binodal line is then given by  $\chi_b(\phi) = \ln(\phi/(1-\phi))/(2\phi-1)$  and phase separation occurs only for  $\chi > \chi_b$ . In particular, the minimal interaction parameter is  $\chi_b^{min} = 2$ , which is obtained at the critical point  $\phi = \frac{1}{2}$ . Near the critical point, the equilibrium volume fractions inside each phase obey  $\phi_1 \simeq \frac{1}{2} - \left[\frac{3}{8}(\chi - 2)\right]^{1/2}$  and  $\phi_2 \simeq$  $\frac{1}{2} + \left[\frac{3}{8}(\chi - 2)\right]^{1/2}$ . Note that the same results are obtained when equation (2.8) is used instead of  $f_{\text{mix}}$ , since terms linear in  $\phi$  do not alter the conditions given in equations (2.13).

2.1.4. Free energy of inhomogeneous systems. The discussion of the previous section neglected the contribution of the interfacial region on the equilibrium free energy. This interfacial region is always present since the volume fraction is continuous in space and must thus interpolate between the values  $\phi_1$  and  $\phi_2$  in the two phases. The additional free energy contribution associated with this spatial variation can be estimated within our lattice model. For simplicity, we first consider a one-dimensional system with discrete lattice positions  $x_n$  for which the Hamiltonian given in equation (2.2) can be written as

$$H(\{\sigma\}) = \sum_{n} \left[ e_{AB} \left( \sigma_n (1 - \sigma_{n+1}) + \sigma_{n+1} (1 - \sigma_n) \right) + e_{AA} \sigma_n \sigma_{n+1} + e_{BB} (1 - \sigma_n) (1 - \sigma_{n+1}) \right].$$
(2.14)

We proceed analogously to section 2.1 and perform a mean-field approximation after rewriting the coupling terms using  $2\sigma_n(1-\sigma_{n+1}) = (\sigma_n - \sigma_{n+1})^2 - \sigma_n^2 - \sigma_{n+1}^2 + 2\sigma_n$ . Additionally, generalising to three dimensions and taking the continuum limit, we replace  $\sum_n \mapsto \nu^{-1} \int d^3r$ ,  $\langle \sigma_n \rangle \mapsto \phi(\mathbf{r})$ , and  $\langle \sigma_{n+1} - \sigma_n \rangle \mapsto \nu^{\frac{1}{3}} \nabla \phi(\mathbf{r})$ . Hence,

$$E \simeq \frac{k_{\rm B}T\chi}{\nu} \int d^3r \left[ \phi(\mathbf{r}) \left( 1 - \phi(\mathbf{r}) \right) + \frac{\nu^{\frac{2}{3}}}{2} \left| \nabla \phi(\mathbf{r}) \right|^2 \right]$$
$$+ \frac{z}{2\nu} \int d^3r \left[ e_{AA} \phi(\mathbf{r}) + e_{BB} \left( 1 - \phi(\mathbf{r}) \right) \right], \quad (2.15)$$

where  $\chi$  is the Flory-Huggins parameter given in equation (2.10). The associated free energy F can be expressed as a functional of  $\phi(\mathbf{r})$ ,

$$F = \frac{1}{\nu} \int d^3r \left[ \frac{\kappa}{2\nu} |\nabla \phi|^2 + \frac{z}{2} \left( e_{AA} \phi + e_{BB} (1 - \phi) \right) + k_{\rm B} T \left[ \phi \ln(\phi) + (1 - \phi) \ln(1 - \phi) + \chi \phi (1 - \phi) \right] \right],$$
(2.16)

<span id="page-5-2"></span>where

<span id="page-5-1"></span>
$$\kappa = k_{\rm B} T \chi \nu^{\frac{5}{3}} \tag{2.17}$$

characterises the change of free energy density due to concentration inhomogeneities. Since the interaction parameter  $\chi > 2$  in the phase separating regime, we have  $\kappa > 0$  and the gradient term thus penalises spatial inhomogeneities. We identify the integrand of the free energy given in equation (2.16) as the total free energy density  $f_{\rm tot}$ . Expressing it in terms of concentrations  $c = \phi/\nu$ , we obtain

$$f_{\text{tot}}(c, \nabla c) = f_{\text{mix}}(c) + f_0(c) + \frac{\kappa}{2} |\nabla c|^2,$$
 (2.18)

where  $f_{\text{mix}}$  follows from equation (2.9) and  $f_0(c) = (z/2) \left( e_{AA} c + e_{BB} \left( \nu^{-1} - c \right) \right)$  is the free energy of the pure system before mixing.

<span id="page-6-0"></span>2.1.5. Ginzburg-Landau free energy. In the previous sections we have derived the free energy density of an incompressible binary mixture using statistical mechanics. We have seen that phase separation occurs when the free energy density exhibits a concave region enclosed by convex branches. The simplest free energy for an incompressible mixture that has such a shape is known as the Ginzburg-Landau free energy [8]:

$$F_{\rm GL}[c] = \int d^3r \left( f_{\rm GL}(c) + \frac{\kappa}{2} \left| \nabla c \right|^2 \right) , \qquad (2.19)$$

with the corresponding free energy density given as

$$f_{\rm GL}(c) = \tilde{b} (c - c_{\rm c}) - \frac{b}{2} (c - c_{\rm c})^{2}$$

$$+ \frac{\tilde{a}}{3} (c - c_{\rm c})^{3} + \frac{a}{4} (c - c_{\rm c})^{4} .$$
(2.20)

This free energy density is parameterised by the phenomenological coefficients a,  $\tilde{a}$ , b,  $\tilde{b}$ , and  $c_c$ . As discussed in section 2.1.3, phase separation equilibrium is not affected by the linear term, thus we choose  $\tilde{b}=0$ , and for reason of simplicity, we also consider the special case  $\tilde{a}=0$ , leading to the bi-quadratic form of the Ginzburg-Landau free energy density:

$$f_{\rm GL}(c) = -\frac{b}{2} (c - c_{\rm c})^2 + \frac{a}{4} (c - c_{\rm c})^4$$
, (2.21)

which is symmetric around the concentration  $c_{\rm c}$ . This free energy density has a concave region if b>0 and the parameter a>0 characterises the convex branches of the energy density. Using equation (2.13a) the equilibrium concentrations within each phase separated domain are

<span id="page-6-3"></span>
$$c_1 = c_c - \sqrt{b/a}$$
, (2.22a)

$$c_2 = c_c + \sqrt{b/a}$$
. (2.22b)

The Ginzburg-Landau free energy density  $f_{\rm GL}(c)$  given in equation (2.21) can either be understood as a phenomenological free energy density that exhibits the qualitative feature necessary for phase separation, i.e., a concave domain enclosed by two convex domains, or as an expansion of the free energy of mixing around a constant concentration  $c_{\rm c}$ , typically the critical concentration [8, 112–114]. In particular, expanding the symmetric free energy of mixing  $f_{\rm mix}(c)$  (equation (2.9)) around  $c_{\rm c}=1/(2\nu)$  up to the fourth order, we find

<span id="page-6-6"></span>
$$a = \frac{16}{3}k_{\rm B}T\nu^3$$
 ,  $b = 2(\chi - 2)k_{\rm B}T\nu$  , (2.23)

which links the phenomenological parameters a and b with the molecular parameters of the lattice model. Using the expressions above in equations (2.22) we consistently obtain the equilibrium concentration found in section 2.1.3.

### <span id="page-6-1"></span>2.2. Equilibrium states of a binary mixture

In this section, we determine the equilibrium concentration profiles that minimise the free energy  $F_{\rm GL}$ . Specifically, we calculate the extremal solutions of  $F_{\rm GL}$  and discuss their stability in different regions of the phase diagram, see figure 2.1(b). An explicit expression of the interfacial profile will allow us to relate the free energy contribution characterised by  $\kappa$  to the surface tension between phases.

<span id="page-6-7"></span><span id="page-6-4"></span>2.2.1. Stationary states. We start by determining the stationary states  $c_*(\mathbf{r})$  of the bi-quadratic Ginzburg-Landau free energy  $F_{\rm GL}$  given in equation (2.19). Such states have an extremal free energy subjected to the constraint that the number of A and B molecules are conserved, i.e.,

<span id="page-6-5"></span>
$$\bar{c} = \frac{1}{V} \int_{V} d^{3}r \, c(\mathbf{r}) , \qquad (2.24)$$

<span id="page-6-2"></span>where  $\bar{c} = N_A/V$  denotes the mean concentration of A molecules in the mixture of the finite volume V. To enforce this constraint, we introduce a Lagrange multiplier  $\lambda$  and vary the functional  $F_{\rm GL} - \lambda \int_V {\rm d}^3 r \, c(\mathbf{r})$ . Here, the functional derivative of the free energy is the generalization of the exchange chemical potential generalized to inhomogeneous systems,

$$\bar{\mu} = \frac{\delta F}{\delta c} \,, \tag{2.25}$$

which reads  $\bar{\mu} = a (c(\mathbf{r}) - c_c)^3 - b (c(\mathbf{r}) - c_c) - \kappa \nabla^2 c(\mathbf{r})$  for  $F_{GL}$ . Consequently, the Euler-Lagrange equation for the stationary state is

<span id="page-6-8"></span>
$$\bar{\mu} = \lambda$$
, (2.26)

where we dropped a boundary term proportional to  $\kappa \nabla c$ , assuming no-flux boundary conditions at the system boundary. The stationary states thus correspond to a spatially uniform exchange chemical potential  $\bar{\mu}$ , which may be realised for both homogeneous and inhomogeneous concentration profiles  $c_*(r)$ .

We start by considering the spatially homogeneous equilibrium states  $c_*(\mathbf{r}) = c_0$ . Particle conservation implies  $c_0 = \bar{c}$  (equation (2.24)) and the Euler-Langrange equations read  $\lambda = a(\bar{c} - c_c)^3 - b(\bar{c} - c_c)$ . The homogeneous state  $c(\mathbf{r}) = \bar{c}$  is thus an extremal state of the free energy  $F_{\rm GL}$  and we will check whether it corresponds to a minimum in the next section.

We showed above that states with coexisting phases can be stable in some regions of the phase diagram shown in figure 2.1(b). Here, we determine the concentration profile that connects the two phases from extremising the free energy  $F_{\rm GL}$ . In the following, we restrict ourselves to a flat interface oriented perpendicular to the x-axis at the position x=0 with

a concentration  $c(x=0)=c_c$ . For simplicity, we extend the system to infinity while keeping the position and concentration value of the interface fixed. For the symmetric free energy density (equation (2.21)), this implies  $\bar{\mu}=0$ , thus  $\lambda=0$ , at the interface, and in the case of an extremal inhomogeneous state,  $\bar{\mu}=0$  at all positions. Far away from the interface, the concentration inside the phases should be governed by the equilibrium concentrations (equation (2.22)),

$$\lim_{x \to -\infty} c(x) = c_1, \qquad \lim_{x \to \infty} c(x) = c_2.$$
 (2.27)

With the boundary conditions above the unique solution is [44]:

<span id="page-7-0"></span>
$$c_{\rm I}(x) = c_{\rm c} + \sqrt{\frac{b}{a}} \tanh\left(\sqrt{\frac{b}{2\kappa}}x\right)$$
 (2.28)

Since this interfacial profile varies substantially only within the region  $|x| \lesssim \sqrt{2\kappa/b}$ , we introduce the interfacial width

$$w = \sqrt{\frac{2\kappa}{b}} \simeq \nu^{\frac{1}{3}} \sqrt{\frac{\chi}{\chi - 2}} . \tag{2.29}$$

The right hand side relates w to the lattice model using equations (2.17) and (2.23). In the limit of strong phase separation (large  $\chi$ ) the interfacial width approaches the linear dimension  $\nu^{1/3}$  of the molecules.

<span id="page-7-2"></span>2.2.2. Stability of stationary states. The homogeneous and inhomogeneous stationary states of the Ginzburg-Landau free energy,  $c_*(x) = \bar{c}$  and  $c_*(x) = c_{\rm I}(x)$ , respectively, can be either stable or unstable. They are stable if they correspond to a free energy minimum, i.e., if all small concentration perturbations increase the free energy. To test this, we consider concentration profiles  $c = c_* + \epsilon$ , where  $\epsilon(\mathbf{r})$  is a small, position dependent concentration perturbation. To quadratic order, the change in the free energy due to this perturbation is

$$\Delta F[c_*, \epsilon] = F_{\rm GL}(c_* + \epsilon) - F_{\rm GL}(c_*)$$

$$\simeq \int d^3r \left[ \frac{\epsilon^2}{2} \left( 3a(c_* - c_{\rm c})^2 - b \right) + \frac{\kappa}{2} \left( \nabla \epsilon \right)^2 \right].$$
(2.30)

The state  $c_*(\mathbf{r})$  is stable if all perturbations increase the free energy, i.e., if  $\Delta F[c_*,\epsilon]>0$  for all  $\epsilon(\mathbf{r})$ . In the case of the homogeneous state  $c_*(\mathbf{r})=\bar{c}$  both terms in the integrand are positive if  $|\bar{c}-c_{\rm c}|>\sqrt{b/(3a)}$ , which implies  $\Delta F[c_*,\epsilon]>0$ . Conversely,  $\Delta F[c_*,\epsilon]$  can be negative for  $|\bar{c}-c_{\rm c}|<\sqrt{b/(3a)}$  in sufficiently large systems, e.g., for the perturbation  $\epsilon(x)\propto \tanh(x/w)$ , which implies that the homogeneous state is unstable for these parameters. Consequently, the stationary homogeneous state can be either stable or

unstable to infinitesimal perturbations. In contrast, the inhomogeneous state  $c_*(x) = c_{\rm I}(x)$  given by equation (2.28) is always stable if it is a stationary state, i.e., when  $|\bar{c} - c_{\rm c}| < \sqrt{b/a}$ , see Appendix A.

<span id="page-7-4"></span>Taken together, we can distinguish three different parameter regimes with different stable stationary states. For mean concentrations  $\bar{c}$  far away from the symmetry point  $c_c$ , i.e., when  $|\bar{c} - c_c| > \sqrt{b/a}$ , the homogeneous state is the only stable one. Conversely, when  $|\bar{c} - c_c| < \sqrt{b/(3a)}$ , only the inhomogeneous state is stable and phase separation will thus happen spontaneously. This region is known as the *spinodal* decomposition region [115-121] which is enclosed by the spinodal line (dashed line in figure 2.1(b)). Between the spinodal region and the homogeneous region, for  $\sqrt{b/(3a)} < |\bar{c} - c_{\rm c}| < \sqrt{b/a}$ , both states are stable to infinitesimal perturbations. In this case, phases can only originate from the homogeneous state by large fluctuations, known as nucleation events. Consequently, the respective region in the phase diagram is known as the nucleation and growth regime. All three phases are shown in the phase diagram in figure 2.1(b).

#### 2.3. Surface tension of interfaces.

The surface tension of the interface can be determined from the profile  $c_{\rm I}(x)$ . To this end, we separate the energetic contributions of the bulk phases to the free energy from a contribution that is related to the interface. For large volumes of the coexisting phases  $V_1$  and  $V_2$ , the total free energy F can be written as

<span id="page-7-1"></span>
$$F = V_1 f(c_1) + V_2 f(c_2) + \gamma A, \qquad (2.31)$$

where  $c_1$  and  $c_2$  are the corresponding equilibrium concentrations. Here, A is the area of the interface and  $\gamma$  denotes the surface energy, which is also known as the *surface tension* [122]. Its value is obtained from the condition that the total free energy given in equation (2.31) equals the free energy of the interfacial profile,  $F = F[c_1]$ :

<span id="page-7-3"></span>
$$\gamma A = \int_{V} d^{3}r \left[ f(c_{I}) + \frac{\kappa}{2} (\nabla c_{I})^{2} \right] - V_{1} f(c_{1}) - V_{2} f(c_{2}) .$$
(2.32)

In the simple case where a flat interface is oriented perpendicular to the x-axis and the system is extended to infinity while keeping the position of the interface fixed at x = 0, the surface tension reads

$$\gamma = \int_{-\infty}^{\infty} dx \left[ f(c_{\rm I}) - \frac{1}{2} \left[ f(c_{1}) + f(c_{2}) \right] + \frac{\kappa}{2} (\nabla c_{\rm I})^{2} \right].$$
(2.33)

Considering the Ginzburg-Landau free energy and the corresponding interfacial profile  $c_{\rm I}(x)$  (equation (2.28)),

we find  $f_{\rm GL}(c_1) = f_{\rm GL}(c_2) = -b^2/(4a)$  and thus

$$\gamma = \int_{-\infty}^{\infty} dx \left[ f_{GL}(c_{I}) + \frac{\kappa}{2} (\partial_{x} c_{I})^{2} + \frac{b^{2}}{4a} \right]$$

$$= \frac{2\sqrt{2\kappa b^{3}}}{3a} \simeq \frac{k_{B} T \chi^{\frac{1}{2}} (\chi - 2)^{\frac{3}{2}}}{2\nu^{\frac{2}{3}}} . \qquad (2.34)$$

In the last approximation, we have used the expressions for the lattice model (equations (2.17) and (2.23)), which shows that  $\gamma$  scales like  $\chi^2$  in the limit of strong phase separation (large  $\chi$ ).

#### <span id="page-8-4"></span>2.4. Dynamical equations of phase separation

We next derive the dynamical equations describing how the binary mixture reaches its equilibrium state. Considering an incompressible mixture, the volume fractions obey  $\phi_A + \phi_B = 1$ , and thus  $\partial_t \phi_A = -\partial_t \phi_B$ . Using  $\phi_i = c_i \nu_i$  (i = A, B) and considering for simplicity the case where molecular volumes of the two components are equal to  $\nu_i = \nu$ , the incompressibility condition leads to  $\partial_t c_A = -\partial_t c_B$ . The particle conservation of A and B molecules can be expressed by the continuity equations

$$\partial_t c_A = -\nabla \cdot \boldsymbol{j}_A \,, \tag{2.35a}$$

$$\partial_t c_B = -\nabla \cdot \boldsymbol{j}_B \,, \tag{2.35b}$$

where incompressibility and equal molecular volumes imply that the particle fluxes of component A and B read  $\mathbf{j}_A = \mathbf{v}c_A + \mathbf{j}$  and  $\mathbf{j}_B = \mathbf{v}c_B - \mathbf{j}$ , and that the volume flow velocity  $\mathbf{v}$  obeys  $\nabla \cdot \mathbf{v} = 0$ . In the following sections, we restrict ourselves to a reference frame where  $\mathbf{v} = \mathbf{0}$ . In this case the exchange current reads  $\mathbf{j} = (\mathbf{j}_A - \mathbf{j}_B)/2$ , which drives the time evolution of the concentration of components A,

$$\partial_t c = -\nabla \cdot \boldsymbol{j} \,, \tag{2.36}$$

where we abbreviated  $c=c_A$  for simplicity. In linear response, the exchange current is proportional to the thermodynamic force of the gradient of the exchange chemical potential  $-\nabla \bar{\mu}$ , implying  $\mathbf{j}=-\Lambda(c)\nabla \bar{\mu}$ ; see Appendix B. Here,  $\Lambda(c)$  denotes a mobility coefficient, which is positive to ensure that the second law of thermodynamics is fulfilled, i.e., that the corresponding entropy production,  $-\int \mathrm{d}^3 r \, \mathbf{j} \cdot \nabla \bar{\mu}$ , is positive [110,123]. The resulting dynamical equation is

<span id="page-8-0"></span>
$$\partial_t c = \nabla \cdot (\Lambda(c) \nabla \bar{\mu}(c)). \tag{2.37}$$

This equation is also known as the deterministic version of the so-called model B [114, 124]. Note, that by considering v = 0, we do not discuss the transport of momentum and the associated couplings to fluid flow. The interested reader is referred to Refs. [8, 112, 113, 125].

In the simple case of the Ginzburg-Landau free energy functional  $F_{\rm GL}$  given in equation (2.19), the dynamical equation (2.37) reads

<span id="page-8-1"></span>
$$\partial_t c = \nabla \cdot \left[ \Lambda(c) \, \nabla \left( a(c - c_c)^3 - b(c - c_c) - \kappa \, \nabla^2 c \right) \right], \tag{2.38}$$

<span id="page-8-2"></span>which is known as the Cahn-Hilliard equation [115]. We can use this equation to scrutinize the stability of the homogeneous state,  $c(\mathbf{r}) = \bar{c}$ , by performing a linear stability analysis. We denote the perturbed state as  $c(\mathbf{r},t) = \bar{c} + \epsilon \exp(\omega t + \mathrm{i} \mathbf{q} \cdot \mathbf{r})$ , where  $\omega$  denotes the perturbation growth rate,  $\mathbf{q}$  the perturbation wave vector, and  $\epsilon$  the associated small amplitude,  $|\epsilon| \ll \bar{c}$ . To linear order, the growth rate is

$$\omega(\mathbf{q}) = -\mathbf{q}^2 \Lambda(\bar{c}) \left[ 3a(\bar{c} - c_c)^2 - b + \kappa \mathbf{q}^2 \right] . \quad (2.39)$$

The homogeneous state is stable if all perturbations decay, i.e., if  $\omega(\mathbf{q}) < 0$  for all  $\mathbf{q}$ . However,  $\omega(\mathbf{q})$  can become positive for small  $|\mathbf{q}|$  if  $|\bar{c} - c_{\rm c}| < \sqrt{b/3a}$ . This parameter region corresponds to the spinodal decomposition that we found above (figure 2.1). The stability associated with the dynamical equations is therefore consistent with the one derived from the free energy discussed in section 2.2.2.

Beyond the linear regime, equation (2.38) is difficult to solve as it is non-linear and involves fourth order spatial derivatives. However, inside the two coexisting phases and far away from the interface, concentration variations are small, so we can ignore the fourth order derivative and linearize equation (2.37) around the equilibrium concentrations  $c_1$  and  $c_2$  (equation (2.22)). Hence, we arrive at two diffusion equations which are valid inside phase 1 and 2, respectively,

<span id="page-8-3"></span>
$$\partial_t c \simeq D_\alpha \, \nabla^2 c \,,$$
 (2.40)

where the collective diffusion coefficient inside phase  $\alpha = 1, 2$  reads

<span id="page-8-5"></span>
$$D_{\alpha} = \Lambda(c_{\alpha}) f''(c_{\alpha}) . \tag{2.41}$$

Note that  $D_{\alpha}$  is positive when phase separation occurs  $(f''(c_{\alpha}) > 0)$  and that an equivalent argument leads to positive diffusivity when phase separation is absent  $(f''(\bar{c}) > 0)$ . In the simple case of the symmetric Ginzburg-Landau free energy given in equation (2.21) and for a constant mobility  $\Lambda$ , the diffusion coefficients are identical in both phases and equal to  $D = 2b\Lambda$ . Using the expressions corresponding to the lattice model (equation (2.23)), we obtain  $D \simeq 4(\chi - 2)\nu\Lambda k_{\rm B}T$  close to the critical point, which is positive as phase separation occurs only when  $\chi > 2$ .

#### 2.5. Dynamics of droplets

In this section, we focus on droplets, which are small condensed phases coexisting with a large dilute phase.

<span id="page-9-0"></span>Impact of surface tension on the local equilibrium concentrations. One important difference between droplets and the condensed phases that we discussed so far is the curvature of the droplet interface, which is inevitable due to the finite size. The surface tension  $\gamma$  of this curved interface affects the equilibrium concentrations inside and outside the droplet, which we denote by  $c_{\rm in}^{\rm eq}$  and  $c_{\rm out}^{\rm eq}$ , respectively. following, we consider the case where the surface tension  $\gamma$  is constant and independent of the interface curvature, which is valid for droplets large compared to the Tolman length [126, 127]. To derive how the equilibrium concentrations depend on the droplet curvature, we write equation (2.31) for a spherical droplet of radius R,

$$F = V_{\rm d} f(c_{\rm in}^{\rm eq}) + (V - V_{\rm d}) f(c_{\rm out}^{\rm eq}) + 4\pi R^2 \gamma$$
, (2.42)

where  $V_{\rm d}=\frac{4\pi}{3}R^3$  denotes the droplet volume and V is the volume of the system. Minimizing the free energy above analogously to section 2.1.3, we obtain the equilibrium conditions

<span id="page-9-1"></span>
$$0 = f'(c_{\text{in}}^{\text{eq}}) - f'(c_{\text{out}}^{\text{eq}}), \qquad (2.43a)$$

$$0 = f(c_{\text{in}}^{\text{eq}}) - f(c_{\text{out}}^{\text{eq}}) + (c_{\text{out}}^{\text{eq}} - c_{\text{in}}^{\text{eq}}) f'(c_{\text{out}}^{\text{eq}}) + \frac{2\gamma}{R}.$$
 (2.43b)

Comparing these expressions to equations (2.13) in the thermodynamic limit, we find that the pressure balance (2.43b) contains an additional term  $2\gamma/R$ , which is known as the *Laplace pressure*. Graphically, the Laplace pressure corresponds to the free energy difference of the tangents in the Maxwell construction, see Fig. 2.1(a). The Laplace pressure is proportional to the interface curvature  $R^{-1}$  and thus disappears in the thermodynamic limit  $(R \to \infty)$ .

The conditions (2.43) determine the equilibrium concentrations  $c_{\rm in}^{\rm eq}$  and  $c_{\rm out}^{\rm eq}$  inside and outside the droplet, respectively. We derive approximate expressions by expanding  $c_{\rm in/out}^{\rm eq} = c_{\rm in/out}^{(0)} + \delta c_{\rm in/out}$  in equations (2.43) to linear order in  $\delta c_{\rm in/out}$ . Here,  $c_{\rm in}^{(0)}$  and  $c_{\rm out}^{(0)}$  denote the equilibrium concentration in the thermodynamic limit in the condensed and dilute phase, respectively, so  $\delta c_{\rm in/out}$  captures the effects of Laplace pressure. We find

$$\delta c_{\text{out}} \simeq \frac{2\gamma}{\left(c_{\text{in}}^{(0)} - c_{\text{out}}^{(0)}\right) f''(c_{\text{out}}^{(0)}) R},$$
 (2.44a)

$$\delta c_{\rm in} \simeq \frac{f''(c_{\rm out}^{(0)})}{f''(c_{\rm in}^{(0)})} \delta c_{\rm out} ,$$
 (2.44b)

which are known as the *Gibbs-Thomson relations*. Since both expressions are positive, the Laplace pressure elevates the concentrations both inside and

outside the droplet. This effect is stronger for smaller droplets, which becomes explicit when writing the equilibrium concentrations as

<span id="page-9-3"></span>
$$c_{\text{out}}^{\text{eq}} = c_{\text{out}}^{(0)} \left( 1 + \frac{\ell_{\gamma, \text{out}}}{R} \right) ,$$
 (2.45a)

$$c_{\rm in}^{\rm eq} = c_{\rm in}^{(0)} \left( 1 + \frac{\ell_{\gamma,\rm in}}{R} \right) ,$$
 (2.45b)

where we defined for both phases the capillary lengths

$$\ell_{\gamma,\text{out}} = \frac{2\gamma}{\left(c_{\text{in}}^{(0)} - c_{\text{out}}^{(0)}\right)f''(c_{\text{out}}^{(0)})c_{\text{out}}^{(0)}}, \qquad (2.45c)$$

$$\ell_{\gamma,\text{in}} = \frac{f''(c_{\text{out}}^{(0)})c_{\text{out}}^{(0)}}{f''(c_{\text{in}}^{(0)})c_{\text{in}}^{(0)}}\ell_{\gamma,\text{out}}.$$
(2.45d)

In the following, we are interested in the limit of strong phase separation with  $c_{\rm in}^{(0)} \gg c_{\rm out}^{(0)}$  and thus  $\ell_{\gamma,\rm in} \ll \ell_{\gamma,\rm out}$ . In this case, the impact of the Laplace pressure on the equilibrium concentration inside the droplet can be neglected, i.e.,  $c_{\rm in}^{\rm eq} \simeq c_{\rm in}^{(0)}$ . Since this leaves us with a single capillary length, which we define  $\ell_{\gamma} = \ell_{\gamma,\rm out}$ . When the phase outside is dilute, i.e., the chemical potential can be written as  $\bar{\mu}(c) \simeq k_{\rm B}T \ln(\nu c)$  [128], we find

<span id="page-9-2"></span>
$$\ell_{\gamma} \simeq \frac{2\gamma}{c_{\rm in}^{(0)} k_{\rm B} T} \,. \tag{2.46}$$

If we additionally assume that the condensed phase is highly packed such that  $c_{\rm in}^{(0)} \simeq \nu^{-1}$ , equation (2.46) provides a useful estimate of the capillary length when the surface tension  $\gamma$  is known [128]. Using equation (2.34) from our lattice model, the capillary length can also be expressed as  $\ell_{\gamma} \simeq \chi^{1/2} (\chi - 2)^{3/2} \nu^{1/3}$ . This expression demonstrates that for interaction parameters not too far away from the critical value,  $\chi_{\rm b}^{\rm min} = 2$ , it is typically on the order of the molecular length scale  $\nu^{1/3}$ . Consequently, we have  $\ell_{\gamma} \ll R$  and the increase of the equilibrium concentrations predicted by the Gibbs Thomson relations (2.45) is actually small, supporting the validity of the linear approximation.

<span id="page-9-4"></span>2.5.2. Growth of a single droplet in a supersaturated environment. The dynamics of the droplet size and its shape are linked to the movement of its interface, which we assume to be thin compared to the droplet size in the following. To describe the dynamics of the interface, we consider a spherical coordinate system  $(r, \varphi, \theta)$  centered on the droplet. Assuming the interface does not deviate strongly from a spherical shape, we parameterize its shape  $\mathbf{R}(\varphi, \theta; t) = \mathcal{R}(\varphi, \theta; t)\mathbf{e}_r$  by the radial distance  $\mathcal{R}(\varphi, \theta; t)$  as a function of the polar angle  $\varphi$  and the azimuthal angle  $\theta$ . The movement of the interface is most naturally

described in the local coordinate system spanned by the two tangential directions  $e_1 = \partial R/\partial \varphi$  and  $e_2 = \partial R/\partial \theta$  and the outward normal vector  $n = \frac{e_1 \times e_2}{|e_1 \times e_2|}$ . Note that the droplet shape is only affected by the normal component  $v_n$  of the interfacial velocity, while the tangential components transport material along the interface. Material conservation implies that this normal component is proportional to the net material flux toward the interface,

<span id="page-10-1"></span>
$$v_n = \frac{\mathbf{j}_{\text{in}} - \mathbf{j}_{\text{out}}}{c_{\text{in}}^{\text{eq}} - c_{\text{out}}^{\text{eq}}} \cdot \mathbf{n} , \qquad (2.47)$$

where  $j_{\text{in}} = \lim_{\epsilon \to 0} j(\mathbf{R} - \epsilon \mathbf{n})$  and  $j_{\text{out}} = \lim_{\epsilon \to 0} j(\mathbf{R} + \epsilon \mathbf{n})$  are the local material fluxes right inside and outside of the interface, respectively. Expressing the time evolution of the interface in the spherical coordinate system gives  $\partial_t \mathbf{R} = \partial_t \mathcal{R} \mathbf{e}_r$ , while in the local coordinate system of the interface,

$$\partial_t \mathbf{R} = v_n \mathbf{n} + v_{t,1} \mathbf{e}_1 + v_{t,2} \mathbf{e}_2.$$
 (2.48)

We can use the connection between the local and the global coordinate system to identify conditions  $\partial_t \mathbf{R} \cdot \mathbf{e}_{\theta} = 0$  and  $\partial_t \mathbf{R} \cdot \mathbf{e}_{\varphi} = 0$ , which can be used to obtain the in plane velocity components  $v_{\rm t,1}$  and  $v_{\rm t,2}$ . The radial interface velocity then reads

$$\partial_t \mathcal{R} = v_n \left[ 1 + \left( \frac{\partial_\theta \mathbf{R}}{R} \right)^2 + \left( \frac{\partial_\varphi \mathbf{R}}{R \sin(\theta)} \right)^2 \right]^{\frac{1}{2}} .$$
 (2.49)

In the case where the dynamics within the phases are described by the diffusion equation (2.40), the material flux is given by  $\mathbf{j} = -D\nabla c$  and equation (2.49) directly determines the time evolution of the interface.

Before we consider shape perturbations in the subsequent chapters, we here focus on a spherical droplet,  $\mathcal{R}(\varphi, \theta; t) = R(t)$ , in a spherically symmetric system. To derive its growth dynamics, we employ the quasi-static approximation, which assumes that the droplet radius varies slowly such that transients in the diffusion equation (2.40) can be neglected. Within this approximation, the diffusion equation (2.40) reduces to a Laplace equation inside and outside the droplet,

$$0 \simeq \nabla^2 c(r) = \frac{1}{r^2} \frac{\partial}{\partial r} \left( r^2 \frac{\partial c}{\partial r} \right) \,, \tag{2.50}$$

where we have written the Laplace operator in spherical coordinates considering that there is no polar and azimuthal dependence of the concentration field. The associated boundary conditions are given by the Gibbs-Thomson relations (2.45) at the droplet interface and no flux conditions at the droplet centre. Moreover, we consider the case where the droplet is embedded in a large system and the concentration far

away is fixed to  $c_{\infty}$ :

<span id="page-10-3"></span>
$$\partial_r c(r) = 0$$
 at  $r = 0$ , (2.51a)

$$\lim_{r \to \infty} c(r) = c_{\infty} . \tag{2.51b}$$

Using these boundary conditions the solutions inside and outside the droplet read

$$c(r) = c_{\infty} + (c_{\text{out}}^{\text{eq}} - c_{\infty}) \frac{R}{r}, \quad r > R, \quad (2.52a)$$

$$c(r) = c_{\rm in}^{\rm eq} \,, \qquad r < R \,, \qquad (2.52b)$$

which are illustrated in figure 2.2(a). These solutions imply that the fluxes  $\mathbf{j}_{\text{in}} = \mathbf{0}$  and  $\mathbf{j}_{\text{out}} = DR^{-1}(c_{\text{out}}^{\text{eq}} - c_{\infty})\mathbf{e}_{r}$  inside and outside of the interface, respectively. The growth rate of the droplet then follows from equation (2.47),

<span id="page-10-2"></span>
$$\frac{\mathrm{d}R}{\mathrm{d}t} = \frac{D c_{\mathrm{out}}^{(0)}}{R c_{\mathrm{in}}^{(0)}} \left( \varepsilon - \frac{\ell_{\gamma}}{R} \right) , \qquad (2.53)$$

where we consider the case of strong phase separation  $(c_{\text{in}}^{(0)} \gg c_{\text{out}}^{(0)})$ . We have defined the *supersaturation* 

$$\varepsilon = \frac{c_{\infty}}{c_{\text{out}}^{(0)}} - 1 \,, \tag{2.54}$$

<span id="page-10-0"></span>which measures the excess concentration relative to the equilibrium concentration  $c_{\text{out}}^{(0)}$  in the dilute Equation (2.53) shows that the droplet only grows in sufficiently supersaturated environments where  $\varepsilon > \ell_{\gamma} R^{-1}$ . The droplet dynamics are thus directly linked to the concentration of droplet material in its environment. In particular, we can define the critical radius  $R_c = \ell_{\gamma} \varepsilon^{-1}$ , below which the droplet shrinks, see figure 2.2(b). this deterministic description cannot account for the spontaneous emergence of droplets, the critical radius is key to estimate the frequency of such nucleation events [129, 130]. In essence, nucleation relies on large fluctuations that spontaneously enrich droplet material in a region of radius  $R_c$ . In this case, the resulting droplet starts growing spontaneously according to equation (2.53).

<span id="page-10-5"></span><span id="page-10-4"></span>2.5.3. Droplet coarsening by Ostwald ripening. So far, we focused on a single droplet, but most phase separated systems contain many droplets. In such emulsions, large droplets typically grow at the expense of smaller droplets, which vanish eventually. This phenomena is referred to as Ostwald ripening [5].

In the following we consider the interactions of many droplets that are far apart from each other in a dilute system with small supersaturation. In this case, nucleation events are rare and the surrounding of droplets can be considered to be spherically symmetric

![](_page_11_Figure_2.jpeg)

<span id="page-11-0"></span>Figure 2.2. (a) Illustration of the concentration field inside and outside of the droplet; see equations (2.52). These concentration fields can be obtained from solving the diffusion equations (2.40) using quasi-static approximation and considering the case of an infinitely thin interface. (b) The droplet growth speed dR/dt is shown as a function of droplet radius R. There is a critical radius  $R_c(t) = \ell_{\gamma}/\varepsilon(t)$  above/below which a droplet grows/shrinks. As the supersaturation  $\varepsilon(t)$  decreases with time, the critical radius increases. (c) Frequency of droplets as a function of droplet radius R. As the critical radius increases with time, the distribution broadens. Rescaling the radius by  $R_c(t) \propto t^{1/3}$ , leads to a collapse of all droplet radius distributions.

with a common concentration  $c_{\infty}$  far away from each droplet. This implies a common supersaturation  $\varepsilon$ , which depends on time and mediates the interactions between the droplets. As the supersaturation  $\varepsilon$  can be determined from the total amount of material, the state of the system is fully specified by the radii  $R_i$  of the N droplets in the system. Their dynamics follows from equation (2.53) and reads [6]:

$$\frac{dR_{i}(t)}{dt} = \frac{D c_{\text{out}}^{(0)}}{R_{i}(t) c_{\text{in}}^{(0)}} \left( \frac{c_{\infty}(t)}{c_{\text{out}}^{(0)}} - 1 - \frac{\ell_{\gamma}}{R_{i}(t)} \right), \quad (2.55a)$$

$$\bar{c}V = c_{\text{in}}^{(0)} \sum_{i=1}^{N} \frac{4\pi}{3} R_{i}(t)^{3} + c_{\infty}(t) \left[ V - \sum_{i=1}^{N} \frac{4\pi}{3} R_{i}(t)^{3} \right].$$

Equation (2.55b) states that the material is shared between the droplets of radius  $R_i$  and the dilute phase of concentration  $c_{\infty}(t)$ . In order to neglect the spatial correlations between the droplets [131,132], we assumed that the system volume V is large compared to all droplets,  $V \gg \sum_i V_i$  with  $V_i = \frac{4\pi}{3} R_i^3$ . In this limit, equation (2.55b) can also be approximated as  $\bar{c}V \simeq c_{\rm in}^{(0)} \sum_{i=1}^N V_i(t) + c_{\infty}(t)V$ .

In the limit of many droplets, the system can be described by a continuous droplet size distribution. If additionally the supersaturation is small, Lifshitz and Slyozov [6] demonstrated that this size distribution converges to a universal form

$$P(\tilde{R}) = \frac{4}{9} \,\tilde{R}^2 \left( 1 + \tilde{R}/3 \right)^{-7/3}$$

$$\times \left( 1 - 2\tilde{R}/3 \right)^{-11/3} \exp\left( -\frac{1}{1 - 2\tilde{R}/3} \right),$$
(2.56)

when normalised by the critical radius  $R_c$ , i.e.,  $R = R/R_c$ , irrespective of the initial size distribution, see figure 2.2(c). In such a coarsening system where

droplets grow and shrink, the critical radius scales with the average droplet radius,  $R_{\rm c}(t) \simeq \langle R(t) \rangle$ . Moreover, a droplet radius  $R_i$  is typically in the order of the critical radius  $R_{\rm c}(t) = \ell_\gamma / \left(\frac{c_\infty(t)}{c_{\rm out}^{(0)}} - 1\right)$ . Thus, equation (2.55) gives  $\frac{{\rm d}R_{\rm c}(t)}{{\rm d}t} \simeq \frac{D\ell_\gamma c_{\rm out}^{(0)}}{c_{\rm in}^{(0)}R_{\rm c}^2}$  leading to the scaling

<span id="page-11-2"></span>
$$\langle R(t) \rangle \simeq R_{\rm c}(t) \propto \left( \frac{D\ell_{\gamma} c_{\rm out}^{(0)}}{c_{\rm in}^{(0)}} t \right)^{\frac{1}{3}},$$
 (2.57)

<span id="page-11-1"></span>which is the *Lifshitz-Slyozov scaling law*. In summary, the increasing mean droplet radius and critical radius reflect coarsening dynamics where large droplets grow at the expense of smaller ones.

Droplet coarsening by coalescence. Another coarsening mechanism in emulsions, besides Ostwald ripening, is the coalescence of droplets driven by their Brownian motion [125, 133]. Brownian coalescence is not included in the theory presented here, since we neglected momentum transport and thermal fluctuations. However, the evolution of the mean droplet size due to droplet coalescence can be determined by estimating the change in radius  $\Delta \langle R \rangle$  for a typical fusion event and the frequency  $\Delta t^{-1}$  of inter-droplet encounters assuming that most encounters lead to coalescence. Since the droplet volume is conserved during fusion, two equally sized droplet of size  $\langle R \rangle$  lead to a change of the mean radius of  $\Delta \langle R \rangle \simeq \left(2^{\frac{1}{3}} - 1\right) \langle R \rangle$ . The frequency of inter-droplet encounters can be estimated by the diffusion time leading to  $\Delta t^{-1} \simeq \lambda D_R/\ell_{\rm p}^2$ , where  $D_R = k_{\rm B}T/(6\pi\eta_R\langle R\rangle)$  is the Stokes-Einstein diffusion constant of a spherical droplet with  $\eta_R$  denoting the viscosity of the surrounding fluid experienced by the droplet of average size  $\langle R \rangle$ . Moreover,  $\ell_p$  $V/(\pi N \langle R \rangle^2)$  is the mean free path between the droplets, where the droplet number can be estimated as  $N \simeq V_{\rm tot}/(\frac{4\pi}{3}\langle R \rangle^3)$  and the volume occupied by droplets  $V_{\rm tot}$  is determined by particle conservation, i.e.,  $V_{\rm tot}/V = (\bar{c} - c_{\rm out}^{\rm eq})/(c_{\rm in}^{\rm eq} - c_{\rm out}^{\rm eq})$ . Not every inter-droplet encounter leads to a coalescence event in particular in the presence of surfactants [134, 135]. To account for the stochastic initiation of a coalescence event we have introduced the parameter  $\lambda \in [0,1]$  characterising the average fraction of encounters that lead to coalescence. By writing  $\langle R \rangle^{-1} \mathrm{d}\langle R \rangle/\mathrm{d}t \simeq \langle R \rangle^{-1} \Delta \langle R \rangle/\Delta t \simeq \lambda k_{\mathrm{B}} T V_{\mathrm{tot}}^2/(V^2 \eta_R \langle R \rangle^3)$ , skipping the numerical prefactors, we obtain a differential equation for the mean radius  $\langle R \rangle$ , where integration gives the scaling for the mean radius arising from fusion of droplets:

<span id="page-12-1"></span>
$$\langle R(t) \rangle \propto \left( \lambda \left( \frac{\bar{c} - c_{\text{out}}^{\text{eq}}}{c_{\text{in}}^{\text{eq}} - c_{\text{out}}^{\text{eq}}} \right)^2 \frac{k_{\text{B}} T}{\eta_R} t \right)^{\frac{1}{3}}$$
 (2.58)

Remarkably, the coarsening due to droplet coalescence has the same scaling with time as the growth of droplets by Ostwald ripening described by equation (2.57).

2.5.5. Comparison between coarsening via Ostwaldripening and coalescence. We can use our lattice model to determine the relative contributions of the two coarsening mechanisms to the growth of droplets. In the case of Ostwald ripening, we have to estimate the molecular diffusion constant D, the capillary length  $\ell_{\gamma}$  and the relative dilution of the minority phase,  $c_{\rm out}^{(0)}/c_{\rm in}^{(0)}$ . We use the Stokes-Einstein relationship to express the diffusivity as  $D \simeq k_{\rm B}T/\left(6\pi\eta_{\rm m}\nu^{1/3}\right)$ , where  $\eta_{\rm m}$  denotes the fluid viscosity felt by the molecules of volume  $\nu$ . Moreover, from equations (2.34) and (2.46), the capillary length  $\ell_{\gamma} \simeq \frac{1}{2} \nu^{1/3} \chi^{1/2} (\chi - 2)^{3/2}$ . Finally, the binodal line corresponding to our lattice model with equal-size molecules A and B (see end of section 2.1.3) can be used to estimate the relative dilution of the minority phase. It turns out that the fraction between the equilibrium concentrations  $c_{\rm out}^{(0)}/c_{\rm in}^{(0)} \propto \exp(-\chi)$ , i.e., it decreases exponentially to zero as the interaction strength  $\chi$  becomes large (limit of strong phase separation), while  $c_{\rm out}^{(0)}/c_{\rm in}^{(0)} \simeq$  $1-\sqrt{(6(\chi-2))}$  changes only weakly close to the critical point (weak phase separation). By comparing equation (2.57) to (2.58), we find that Ostwald ripening dominates coarsening if

<span id="page-12-2"></span>
$$\chi^{\frac{1}{2}}(\chi-2)^{\frac{3}{2}} \frac{c_{\text{out}}^{(0)}}{c_{\text{in}}^{(0)}} \left(\frac{c_{\text{in}}^{\text{eq}} - c_{\text{out}}^{\text{eq}}}{\overline{c} - c_{\text{out}}^{\text{eq}}}\right)^{2} \frac{\eta_{R}}{\eta_{\text{m}}} \lambda^{-1} \gg 1, \quad (2.59)$$

where we dropped all numerical prefactors. In the simple case of a constant size-independent viscosity,  $\eta_{\rm m} = \eta_R$ , our estimates from the simple binary lattice

model indicate that coalescence typically dominates Oswald ripening for most interaction parameters  $\chi$ . In particular, the left hand side of equation (2.59) goes to zero close to the critical point ( $\chi = 2$ ) and in the limit of strong phase separation  $(\chi \to \infty)$ . However, for intermediate  $\chi$ -values, the dominant coarsening mechanism could still be Ostwald ripening because coalescence events may be suppressed by surfactants  $(\lambda \ll 1)$  or when the ratio of the viscosities often satisfies  $\eta_R/\eta_{\rm m} \gg 1$ . Such different viscosities are particularly relevant for condensed phases in polymer or protein solutions, or droplet-like compartments in living cells. These complex, phase separated liquids can even show visco-elastic effects leading to a dramatic slow down of the movements of large droplet-like phases [136–138]. In particular, inside cells, diffusion of very large compartments is strongly suppressed by the cytoskeleton [139], while the diffusion of small molecules may experience less hinderance. We therefore expect that Ostwald ripening is the dominant mechanism of droplet coarsening inside cells since it relies on evaporation and condensation of small diffusing molecules.

#### <span id="page-12-0"></span>3. Positioning of condensed phases

In this chapter, we discuss the positioning of condensed phases (e.g., droplets) by external fields and nonequilibrium concentration gradients. We focus on the case where two components phase separate while a third component, referred to as regulator, influence the phase separation. Here we discuss two scenarios of how to affect the position of condensed phases: (i) The position of a condensed phase can be influenced by an external field such as gravitation, electric or magnetic fields [140]. These fields position the phase of higher mass density, larger charge or larger magnetic moment toward regions of lower potential energy. The resulting stationary states correspond to a minimum of the total free energy of the system and are inhomogeneous thermodynamic states. (ii) Positioning of a condensed phase can also be affected by a regulator gradient that is driven and maintained by boundary conditions. The presence of a regulator flux may let the system settle in (stationary) non-equilibrium states. Such a concentration gradient could be generated for example by concentration boundary conditions, or sources and sinks [93], or via position-dependent reaction kinetics with broken detailed balance [141, 142].

In section 3.1, we discuss a simple system of two phase separating components and illustrate how an external field can affect the average position of the phase separated concentration profiles. The corresponding stationary states are inhomogeneous thermodynamic states and can thus be accessed through a minimisation of the free energy. Section 3.2 is then devoted to discuss how a concentration gradient of a regulator can affect the dynamics of droplet position.

#### <span id="page-13-0"></span>3.1. Positioning of condensed phases by external fields

External fields can influence the position of components in a mixture and thereby also the position of condensed phases. In this section, we investigate how external fields affect a mixture which undergoes phase separation. To this end, we briefly review the thermodynamics with external fields.

3.1.1. Thermodynamics of binary mixtures in external fields. Here we discuss the thermodynamics of binary mixtures in the presence of external fields such as gravitation with a gravitational acceleration g, and electric or magnetic, position-dependent potentials denoted as U(x). The presence of such an inhomogeneous external potential can influence the shape and the mean position of the concentration profiles  $c_A(x)$  and  $c_B(x)$ , which can be defined as

$$x_i = \frac{1}{L} \int_0^L \mathrm{d}x \, x \, \frac{c_i(x)}{\bar{c}_i} \,, \tag{3.1}$$

where  $\bar{c}_i = L^{-1} \int_0^L dx \, c_i(x)$  denotes the mean concentration and L is the size of the system.

For a compressible system the binary mixture is described by two concentration fields  $c_A$  and  $c_B$ . Considering the case where the external fields vary along the x-coordinate, the total free energy density reads

$$f_{\text{tot}} = f(c_A, c_B, \nabla c_A, \nabla c_B) + \rho g x + U_A(x) c_A + U_B(x) c_B.$$
(3.2)

The interactions between the components are governed by the free energy density f,  $\rho = m_A c_A + m_B c_B$  is the mass density, and  $m_A$  and  $m_B$  denote the molecular mass of each component. The contributions of the external potentials can be combined to  $\tilde{U}_A(x)c_A + \tilde{U}_B(x)c_B$ , where  $\tilde{U}_i(x) = U_i(x) + m_i g x$ , i = A, B.

Thermodynamic equilibrium for systems with external fields can be defined at each position. The position-dependent equilibrium profile  $c_i(x)$  is then determined by a spatially constant generalised chemical potential,  $\mu_{\text{tot},i} = \mu_i(x) + \tilde{U}_i(x)$ , where  $\mu_i(x) = \delta F/\delta c_i$  with  $F = \int \mathrm{d}^3 x f$ . As an example of a system with such a position-dependent equilibrium profile we consider an incompressible system  $(\nu_A c_A + \nu_B c_B = 1)$  with gravitation as the only external potential and where the A-molecules are dilute,  $\nu_A c_A \ll 1$  [140]. The generalised exchange chemical potential then reads  $\bar{\mu}_{\text{tot}} \simeq k_B T \ln(\nu c_A) + \nu_A \Delta \rho g x$ 

with the density difference  $\Delta \rho = m_A/\nu_A - m_B/\nu_B$ . At thermodynamic equilibrium, this gives the barometric height formula,  $c_A(x) \propto \exp(-\Delta \rho \nu_A gx/(k_B T))$ . Thus gravitation always positions the molecules of highest mass density toward the lower gravitational potential. A similar result occurs if the binary mixture phase separates. In this case the condensed phase of larger mass density is positioned toward the region of lower gravitational potential. However, for fixed difference in mass density and gravitational potential, there is no way to switch the concentration profiles or the position of the condensed phases with respect to gravitation. In order to create a possibility to switch the position of condensed phases, we ask what happens if an additional component that affects phase separation is added to the system and subject to an external Specifically, we wonder what are the stationary concentration profiles and which physical parameters control their positions?

<span id="page-13-2"></span>3.1.2. Positioning of condensed phases by a regulator potential. To explore the propensity to switch the position of condensed phases using such an additional component we propose a simple ternary model [143]. This model accounts for the demixing of two components, A and B, and a regulator component R that interacts with the other components and thereby affects phase separation between A and B. The regulator component R is influenced by an external potential U(x). Interactions between the components i and j are captured by the mean-field interaction parameters  $\chi_{ij}$ . The scenario of regulation of phase separation can be described by the following free energy density

<span id="page-13-3"></span><span id="page-13-1"></span>
$$f_{\text{tot}} = k_{\text{B}} T \left[ \sum_{i=\text{A,B,R}} c_i \ln(\nu c_i) + \chi_{AB} \nu c_A c_B + c_R (\chi_{BR} c_B + \chi_{AR} c_A) \nu \right] + U(x) c_R + \frac{\kappa_R}{2} |\nabla c_R|^2 + \frac{\kappa_A}{2} |\nabla c_A|^2 , \qquad (3.3)$$

which is a Flory-Huggins free energy density [3,4] for three components. Analogously to the case of the binary system discussed in section 2.1, the ternary free energy given above can be derived from a partition sum using a mean-field approximation (see [144,145] and Appendix of Ref. [143]). In equation (3.3) we consider an incompressible system where the molecular volumes are constant and equal to  $\nu$  for all components, and the concentrations thus obey  $c_B = \nu^{-1} - c_R - c_A$ . The logarithmic terms in equation (3.3) correspond to entropic contributions related to the number of possible configurations. The remaining contributions characterise the interactions between the three components with the (dimensionless) mean

![](_page_14_Figure_2.jpeg)

<span id="page-14-2"></span>**Figure 3.1.** Spatial regulation of phase separation in an external potential by a discontinuous phase transition. The regulator forms a spatially inhomogeneous profile due to an external potential. As the interactions with the regulator are changed, the spatial distribution of component A switches from a spatially correlated (left) to an anti-correlated (right) distribution with respect to the regulator. The switch corresponds to a discontinuous phase transition.

field interaction parameter  $\chi_{ij}$ , also referred to as Flory-Huggins interaction parameter. The interaction parameter between A and B,  $\chi_{AB}$ , determines the tendency of A and B to phase separate. The two terms in equation (3.3) proportional to the regulator concentration  $c_R$  describe the interactions between the regulator R and the demixing components A and B. To ensure that R acts as a regulator we choose these interaction parameters such that the regulator R does not demix from A or B. The terms in equation (3.3) with spatial derivatives represent contributions to the free energy associated with spatial inhomogeneities  $\ddagger$ .

In the following we consider a periodic system with a periodic potential U(x) that varies solely along the x-coordinate. We choose a potential that affects the distribution of the regulator component of the form

$$U(x) = -k_{\rm B}T \ln (1 - Q \sin (2\pi x/L)) , \qquad (3.4)$$

where 0 < Q < 1 characterises the strength of the potential and L denotes the size of the system along the x-direction.

In the case where the components A and R are dilute,  $\nu \bar{c}_A \ll 1$  and  $\nu \bar{c}_R \ll 1$ , and for weak external potentials  $(\kappa_R(Q/L)^2 \ll 1)$  such that the the gradient terms in free energy can be neglected, the profile of the regulator component is solely given by the external potential U(x) with the regulator profile  $c_R(x)$  assuming the shape of negative sine function,  $-\sin(2\pi x/L)$ . Thus the regulator profile has one minimum and one maximum in the periodic domain. The interaction of such a regulator profile with the components A and B causes a positional dependence of their concentration profiles. We would like to understand how these interactions affect the system if A and B phase separate.

<span id="page-14-0"></span>‡ We neglected a mixed term proportional to  $\nabla c_A \cdot \nabla c_R$  since it has only little quantitative impact on the spatial profiles of the phase separated profiles [143]

For simplicity, we also consider a one dimensional system of size L in the absence of boundaries. In this one dimensional system the periodic boundary conditions are  $c_i(0) = c_i(L)$  and  $c'_i(0) = c'_i(L)$ , where the primes denote spatial derivatives. For the considered case of an external potential U(x) varying only along the x-coordinate, the restriction to a one dimensional, phase separating system represents a valid approximation for large system sizes, where the interface between the condensed phases becomes flat.

3.1.3. Minimisation of free energy. To find the equilibrium states in a phase separating system in the presence of a regulator gradient induced by the external potential U(x), we determine the concentration profiles  $c_i(x)$  of all components i=A,B,R by minimising the total free energy (equation (3.3); see Ref. [143]). Due to particle number conservation, there are two constraints for the minimisation imposing  $\bar{c}_i = L^{-1} \int_0^L \mathrm{d}x \, c_i(x)$  for i=A,R, where  $\bar{c}_i$  are the average concentrations and  $\bar{c}_B = \nu^{-1} - \bar{c}_A - \bar{c}_R$ . Variation of the total free energy with the constraints of particle number conservation implies (i=A,R):

<span id="page-14-1"></span>
$$0 = \int_{0}^{L} dx \left( \frac{\partial f_{\text{tot}}}{\partial c_{i}} - \frac{d}{dx} \frac{\partial f_{\text{tot}}}{\partial c'_{i}} + \lambda_{i} \right) \delta c_{i} + \kappa_{i} \delta c_{i} c'_{i} \Big|_{0}^{L},$$
(3.5)

where  $\lambda_R$  and  $\lambda_A$  are Lagrange multipliers and the  $\delta c_i$  is the variation of the concentration corresponding to component i. The boundary term in equation (3.5) is zero in case of periodic boundary conditions. Using the explicit form of the free energy density (equation (3.3)), a set of Euler-Lagrange equations can be derived from equation (3.5) (see Ref. [143]). These equations can be solved numerically using a finite difference solver but also approximately investigated analytically (see section 3.1.5). As control parameters we consider the three interaction parameters  $\chi_{AR}$ ,  $\chi_{AB}$  and  $\chi_{BR}$ ,

the strength of the external potential Q and the mean concentration of A-material,  $\bar{c}_A$ . The mean concentration of the regulator material is fixed to a small volume fraction  $\nu \bar{c}_R = 0.02$  in all presented studies to avoid phase separation of the regulator. Moreover, we focus on the limit of strong phase segregation, where the interfacial width determined by  $\kappa_A$  are small compared to the system size. We verified that our results depend only weakly on the specific values of  $\kappa_A$  and  $\kappa_R$ .

3.1.4. Discontinuous switching of average position of  $phase\ separated\ concentration\ profiles\ in\ external\ fields.$ Solving the Euler-Lagrange equations, we find two extremal profiles of the phase separating component A,  $c_A^-(x)$  and  $c_A^+(x)$ , and two corresponding profiles of the regulator component R, denoted as  $c_R^-(x)$ and  $c_R^+(x)$  (the profile of B follows from number conservation). The phase separating material A can be accumulated at larger regulator concentration and correlates (+) with the concentration of the regulator material (figure 3.1(a)). The corresponding solutions are  $c_A^+(x)$  and  $c_B^+(x)$ . Alternatively, the A-material accumulates at smaller regulator concentrations ( $c_A^-(x)$ and  $c_R^-(x)$ ) corresponding to an anti-correlation (-) with respect to the regulator profile (figure 3.1(b)). The free energies of the correlated and the anticorrelated states,  $F^+ = F[c_A^+, c_R^+]$  and  $F^- = F[c_A^-, c_R^-]$ , are different for most interaction parameters. The free energies only intersect at one point  $\chi_{BR}$  =  $\chi_{BR}^*$  (figure 3.2(a)). At this point the minimal free energy exhibits a kink. This means that the system undergoes a discontinuous phase transition when switching between a spatially anti-correlated (-)and a spatially correlated (+) solution with respect to the regulator.

To study this phase transition the appropriate set of order parameters can be defined from the changes of the free energy upon varying the interaction parameters (see figure 3.2):

$$\rho_{ij} = (k_{\rm B}T\mathcal{N}_{ij}\nu L)^{-1} \frac{\mathrm{d}}{\mathrm{d}\chi_{ij}} \Delta F(c_i(x), c_j(x)), \quad (3.6)$$

where  $\Delta F(c_i(x), c_j(x)) = F(c_i(x), c_j(x)) - F(\bar{c}_i, \bar{c}_j)$ . The normalisation  $\mathcal{N}_{ij}$  is chosen such that  $-1 < \rho_{ij} < 1$ . When inserting equations (3.3), the order parameter  $\rho_{ij}$  becomes the covariance,

$$\rho_{ij} = (\mathcal{N}_{ij}L)^{-1} \int_0^L dx \ (c_i(x)c_j(x) - \bar{c}_i\bar{c}_j) \ , \qquad (3.7)$$

which characterises the spatial correlation between the concentration profiles  $c_i(x)$  and  $c_j(x)$ . If the fields are spatially correlated (+),  $\rho_{ij} > 0$ , and if they are anti-correlated (-),  $\rho_{ij} < 0$ , and  $\rho_{ij} = \pm 1$  if the

concentration profiles of component i and j follow spatially correlated or anti-correlated step functions. If the regulator is homogeneous,  $c_R(x) = \bar{c}_R$ , the order parameter is zero,  $\rho_{iR} = 0$  for i = A, B.

Varying the interaction parameter  $\chi_{BR}$  (figure 3.2(b)), the order parameters  $\rho_{BR}$  and  $\rho_{AR}$  jump at the threshold value  $\chi_{BR}^*$ . The jump of both order parameters in the presence of a regulator gradient indicates that the spatial correlation of A and B with respect to R changes abruptly, which is expected in case of a first order phase transition.

By means of the order parameter  $\rho_{BR}$  (equation (3.7)) we can now discuss the phase diagrams as a function of the interaction parameters. In the case of a spatial correlation (+), we have  $\rho_{ij} > 0$ , while for an anti-correlation (-),  $\rho_{ij} < 0$ . We thus find three regions (figure 3.2(c)): A mixed region, where concentration profiles are only weakly inhomogeneous and no phase separation occurs, and two additional regions, where components A and B phase separate and A is spatially correlated or anti-correlated with the regulator R, respectively. There exists a triple point where all three states have the same free energy.

In summary, the presence of a concentration gradient in phase separating systems leads to equilibrium states of different spatial correlation with the regulator profile. The regulator gradient creates a bias in the position of the phase separated concentration profiles for almost all parameters in the phase diagram. If the external potential acting on the regulator has exactly one minimum and one maximum, there are two stationary states with different mean positions of the phase separating material. One of these stationary states corresponds to a global minimum of the free energy while the other state may only be locally stable. The parameters characterising the interactions between the regulator and the phase separating material determine which of these states corresponds to equilibrium. There is a discontinuous phase transition between both states upon changing these interaction parameters.

For simplicity we have discussed a phase separating system in the presence of an external potential restricting to inhomogeneities in one dimension. However, preliminary Monte-Carlo studies in three dimensions with phase separated droplets in a regulator gradient suggest that the position of droplets can be switched in a discontinuous manner [146].

<span id="page-15-1"></span><span id="page-15-0"></span>3.1.5. Analytic argument of the occurrence of a discontinuous phase transition In the previous section we have considered the numerical minimisation of a set of non-linear Euler-Lagrange equations derived from the free energy density (equation (3.3)). Here we give some approximate analytic arguments to understand the minimal ingredients for the occurrence of the

![](_page_16_Figure_2.jpeg)

<span id="page-16-0"></span>Figure 3.2. Discontinuous phase transition of a ternary phase separating systems in a periodic potential and with periodic boundary conditions. (a) Free energy F as a function of the B-R interaction parameter  $\chi_{BR}$ .  $F^-$  and  $F^+$  are the free energies of the correlated and anti-correlated stationary solution with respect to the regulator gradient, respectively. Lines are dashed when solutions are metastable. At  $\chi_{BR}^*$ ,  $F^-$  and  $F^+$  intersect and the solution of minimal free energy exhibits a kink. This shows that the transition between correlation and anti-correlation is a discontinuous phase transition. (b) The order parameter  $\rho_{BR}$  corresponding to the solution of minimal free energy jumps at  $\chi_{BR}^*$ . (c) Phase diagrams of our ternary model for spatial regulation in a periodic potential and periodic boundary conditions ( $\nu \bar{c}_A = 0.1$ ). The color code depicts the order parameter  $\rho_{BR}$ . Component B is spatially correlated (+) with the regulator profile if  $\rho_{BR} > 0$ , and anti-correlated (-) otherwise. When the system is mixed,  $\rho_{BR} \approx 0$ , and spatial profiles of all components are only weakly inhomogeneous (no phase separation). The black lines corresponds to the transition where the free energy has a kink. Parameters for (a-c):  $\chi_{AR} = 1$ ,  $\nu \bar{c}_A = 0.5$ ,  $\nu \bar{c}_R = 0.02$ ,  $\kappa_R/(k_{\rm B}T\nu L^2) = 7.63 \cdot 10^{-5}$ ,  $\kappa_A/(k_{\rm B}T\nu L^2) = 6.10 \cdot 10^{-5}$ , Q = 0.5. For (a) and (b),  $\chi_{AB} = 4$ . For plotting,  $\nu = L/256$  was chosen.

discontinuous phase transition. To this end, we would like to simplify the system further and consider the dilute limit of the regulator, i.e.,  $\nu \bar{c}_R \ll 1$  and thus approximate  $\bar{c}_B \simeq 1 - \nu^{-1}\bar{c}_A$  in equation (3.3). For such dilute conditions, the equilibrium concentrations (for A component) in each phase,  $c_{\rm in}^{(0)}$  and  $c_{\rm out}^{(0)}$ , are then well given by the binary A-B system. In addition, for strong enough external potential U(x), the regulator profile follows well,  $c_R(x) = \hat{A} - \hat{B}\sin(2\pi x/L)$ , apart from the peaks (see figure 3.1), where  $\tilde{A} > 0$  is some concentration offset and B > 0 characterises the strength of the spatial modulations of the regulator For a discussion of the relevance of the regulator peaks at the interface see Ref. [143]; here we simply neglect these peaks for simplicity. We expect that the extrema of the regulator profile  $c_R(x)$  at x = L/4, 3L/4, determine the position of the A-rich condensed phase. As obtained from the numerical analysis presented in the last section, there are two solutions, either spatially correlated (+) or anticorrelated (-) with the regulator. These solutions can be approximated in the dilute limit of the regulator as:

$$\begin{split} c_A^+(x) &\simeq c_{\rm out}^{(0)} + \left(c_{\rm in}^{(0)} - c_{\rm out}^{(0)}\right) \Theta\left(x - 3L/4 + x_0/2\right) \\ &\times \Theta\left(3L/4 + x_0/2 - x\right) \;, \qquad (3.8a) \\ c_A^-(x) &\simeq c_{\rm out}^{(0)} + \left(c_{\rm in}^{(0)} - c_{\rm out}^{(0)}\right) \Theta\left(x - L/4 + x_0/2\right) \\ &\times \Theta\left(L/4 + x_0/2 - x\right) \;, \qquad (3.8b) \end{split}$$

where  $\Theta(\cdot)$  denotes the Heaviside step function. These solutions describe the A-rich domains either localised around the maximal (+) or minimal (-) amount of regulator. The domain size of the A-rich phase denoted as  $x_0$  is determined by conservation of particles, i.e.,

 $\bar{c}_A L = \int \mathrm{d}x c_A^+(x) = \int \mathrm{d}x c_A^-(x)$ , leading to  $x_0 = L(\bar{c}_A - c_{\mathrm{out}}^{(0)})/(c_{\mathrm{in}}^{(0)} - c_{\mathrm{out}}^{(0)})$ . Using the approximate solutions above we can calculate the difference in free energy corresponding to correlated and anti-correlated states,

<span id="page-16-1"></span>
$$F^{+} - F^{-} \simeq W k_{\rm B} T L (\chi_{AR} - \chi_{BR}) \tilde{B},$$
 (3.9)

where  $W = 2\pi^{-1} \sin\left(\pi \frac{x_0}{L}\right) > 0$  is a positive constant. Please note that all contributions apart from the A-R and B-R interaction vanish in the dilute limit and due to conservation of A and B material. As B characterises the concentration modulations of the regulator profile, the free energy difference  $(F^+ - F^-)$ consistently vanishes for zero  $\tilde{B}$  (equation (3.9)). In the case of non-zero  $\hat{B}$ , the free energy difference is determined by the difference in the interactions of A and B with respect to the regulator R,  $\Delta \chi =$  $\chi_{AR} - \chi_{BR}$ . Most importantly, at  $\Delta \chi = 0$ , the two solutions switch their thermodynamic stability: for  $\Delta \chi > 0$ , the anti-correlated state is favoured, while for  $\Delta \chi < 0$ , the correlated state is preferred;  $\Delta \chi = 0$ indicates the transition point. In addition, the slopes of correlated and anti-correlated free energy,  $F^+$  and  $F^-$ , with respect to  $\Delta \chi$  at the transition point are not equal. The difference in slopes implies that the minimal free energy exhibits a kink at the transition point  $\Delta \chi = 0$ , which means that the system undergoes a discontinuous phase transition switching from a correlated to an anti-correlated state for increasing  $\Delta \chi$ . The discontinuous phase transition occurs at  $\Delta \chi = 0$ , which agrees with the numerical predictions shown in figure 3.2(c) (note that the corresponding volume fraction of the regulator is rather dilute). Our approximate analytic treatment indicates that the occurrence of a discontinuous phase transition solely relies on the existence of the position-dependent profile of the regulator and the interactions of the regulator molecules with the liquid condensed phases. It seems that the peaks of regulator material at the interface of the condensed phase, which we neglected in this approximate analytic argument, are not necessary to observe the discontinuous transition. Maybe the discontinuous nature is also preserved if the regulator gradient is driven by boundary conditions? We leave this question to future research.

# <span id="page-17-0"></span>3.2. Dynamics and coarsening of droplets in concentration gradients

In this section we discuss the dynamics of multiple droplets in a one-dimensional gradient of a regulator component that affects the phase separation of droplets. For simplicity, we consider the case where the regulator profile is not affected by the phase separating components. Given a regulator gradient  $c_R(x)$  we introduce a set of physical quantities such as the position dependent supersaturation, which determine the inhomogeneous ripening dynamics. These quantities depend on position and will be used to develop a generic theory of droplet ripening in concentration gradients. This theory extends the classical laws of droplet growth derived by Lifschitz & Slyozov [6] and can explain the positioning of droplets in concentration gradients by droplet drift and spatially dependent growth.

3.2.1. Spatially varying supersaturation. Here we discuss the ripening dynamics of droplets in a regulator gradient that varies only along the x-coordinate. To this end, we modify the concept of a common far field concentration introduced in section 2.5.3 to a concentration field  $c_{\infty}(x)$  that changes on the length scale of the system size L.

In the absence of a regulator gradient, the concentration outside approaches the "far field" of the droplet,  $c_{\infty}$ , as the distance to the droplet interface increases. The far field is created by the surrounding droplets and is well reached if the length scale corresponding to the mean distance between droplets  $\ell$  exceeds the droplet radius R, i.e.,  $\ell \gg R$ .

In the presence of a regulator gradient varying along the x-coordinate, the far field seen by the droplet  $c_{\infty}(x)$  is now also position dependent and can be approximately written as:

$$c_{\infty}(x) \simeq \frac{1}{L_y L_z} \int_0^{L_y} dy \int_0^{L_z} dz \, c_{\text{out}}(x, y, z), \quad (3.10)$$

where  $c_{\text{out}}(x, y, z)$  is the concentration field outside the droplets and  $L_y$  and  $L_z$  denote the system size in the y and z-direction, respectively. The expression above is an approximation because we have neglected weak

![](_page_17_Figure_10.jpeg)

<span id="page-17-1"></span>Figure 3.3. (a) Sketch of a ternary phase diagram as a function of the homogenous regulator concentration  $c_R$  and the droplet material  $c_A$ . The tie lines (green) connect the equilibrium concentration values of the coexisting phases. Each position x of a system subject to a different regulator gradient (e.g. blue line in (b)) may correspond to a point in the phase diagram along the orange line. If the position is inside the phase separation region, droplets can form, while outside phase separation is absent. The position  $x_c$ , referred to as dissolution boundary, marks the location below which there is no phase separation and vice versa. (b) Sketch of a representative regulator gradient  $c_R(x)$  (blue) and the equilibrium concentration  $c_{\rm in}^{(0)}(x)$  and  $c_{\rm out}^{(0)}(x)$  obtained from the phase diagram (a).

concentration perturbations close to droplet interfaces described by the Gibbs Thomson relationship (2.45). However, for the typical case of droplet radii exceeding the capillary length  $(R \gg \ell_{\gamma})$  and the mean interdroplet distance being larger than the droplet size  $(\ell \gg R)$ , these concentration perturbations are very small (see section 2.5.1).

Finally, to make sure that the spatial variations of the position dependent far field are large on the system size but comparably small on the droplet scale, we consider the case where all these length scales separate,  $\ell_{\gamma} \ll R \ll \ell \ll L$ . This separation of length scales will allow us to investigate weak perturbations of the droplet shape parallel to the concentration gradient and also to construct the equilibrium concentration at each position x along the gradient.

The separation of length scales suggests to divide the system into independent slices of a size corresponding to the intermediate length scale  $\ell$ . The phase separation dynamics can then be discussed locally for each position x corresponding to a slice element of linear length  $\ell$ . For this discussion, we consider a simplified model with a free energy density given by equation (3.3) and calculate the corresponding phase diagram (figure 3.3(a)). If the droplet material is roughly constant each position x maps on a single point in the phase diagram because the regulator profile is fixed. The corresponding curve in the phase diagram due to the spatial dependence of the regulator defines local values of the equilibrium concentrations inside and outside of the droplet (figure 3.3(b)). In other words, droplets in the slice corresponding to the position x feel the local equilibrium concentrations,

 $c_{\rm in}^{(0)}(x)$  and  $c_{\rm out}^{(0)}(x)$ . For simplicity, we restrict ourselves to a special case where the equilibrium concentration inside is position independent,  $c_{\rm in}^{(0)}(x) \simeq c_{\rm in}^{(0)}$ , thus droplet growth is solely determined by the conditions outside of the droplet. Moreover, as concentration inhomogeneities of droplet material are in general weak, we do not consider weak transients of  $c_{\rm out}^{(0)}(x)$  due to the space and time varying  $c_{\infty}(x)$ . The actual concentration of droplet material outside,  $c_{\infty}(x)$ , together with the equilibrium concentration outside,  $c_{\rm out}^{(0)}(x)$ , determine a spatially dependent supersaturation

<span id="page-18-0"></span>
$$\varepsilon(x) = \frac{c_{\infty}(x)}{c_{\text{out}}^{(0)}(x)} - 1. \tag{3.11}$$

There is a dissolution boundary located at the position  $x = x_c$  where the supersaturation  $\varepsilon(x_c) =$  $\ell_{\gamma}/R$ . For the considered case of  $\ell_{\gamma} \ll R$ , this boundary approximately corresponds to a vanishing supersaturation  $\varepsilon(x_c) \simeq 0$ . In the illustration in figure 3.3(a), the fluid is mixed for  $x < x_c$ , while droplets can form  $(\varepsilon > 0)$  for  $x > x_c$ . In the absence of droplets, the concentration field  $c_{\infty}(x)$  evolves in time satisfying a diffusion equation, which we will derive in the next section. When droplets are nucleated, their local dynamics of growth or shrinkage is guided by the local supersaturation  $\varepsilon(x)$  as well as  $c_{\text{out}}^{(0)}(x)$  (see section 2.5.3). This local droplet dynamics then in turn also influences the concentration field  $c_{\infty}(x)$ . As time proceeds, diffusion of droplet material occurs on length scales larger than the intermediate length scale  $\ell$ . For this regime, we will derive a dynamical theory and extend the Lifschitz & Slyozov theory to concentration gradients.

3.2.2. Dynamics of a single droplet in a concentration gradient. A regulator concentration gradient generates a position-dependent equilibrium concentration  $c_{\text{out}}^{(0)}(x)$  and a position-dependent supersaturation  $\varepsilon(x)$  (equation (3.11)). This supersaturation will drive the droplet dynamics and lead to a position-dependent growth, drift of droplets and even deformations of their shape. In the following we discuss the dynamics of growth of a single droplet where the equilibrium concentration,  $c_{\text{out}}^{(0)}(x)$ , and the concentration of droplet material,  $c_{\infty}(x)$ , are position dependent. The case of multiple droplets is studied in the next section.

The concentration inside the droplet can be approximated by the equilibrium concentration  $c_{\rm in}^{\rm eq} \simeq c_{\rm in}^{(0)}$  in the limit of strong phase separation ( $c_{\rm in}^{(0)} \gg c_{\rm out}^{(0)}$ ; see section 2.5.1). This allows us to restrict the analysis to the concentration field  $c(r, \theta, \varphi)$  outside of a droplet. Here, we use spherical coordinates centred at the droplet position  $x_0$ , with r denoting the radial

![](_page_18_Figure_7.jpeg)

<span id="page-18-3"></span>Figure 3.4. Sketch of the concentration field inside and outside of a droplet in a position-dependent supersaturation field. The droplet center is located at x=0. The equilibrium concentration inside is  $c_{\rm in}^{\rm eq}$ . Right outside the droplet at  $\pm R$  the concentration is given by the Gibbs-Thomson relation  $c_{\rm out}^{\rm eq}$  (equation (3.12)). Far away from the droplet center, the concentration approaches  $c_{\infty}(x)$  (equation (3.13)).

distance from the centre, and  $\theta$  and  $\varphi$  are the azimuthal and polar angles relative to the x-axis. Within the quasi-stationary approximation (see section 2.5.2) the concentration outside but near the droplet obeys the steady state of a diffusion equation (2.50). For large r the concentration field approaches the "far field" which in the presence of a linear gradient reads (figure 3.4):

<span id="page-18-2"></span><span id="page-18-1"></span>
$$c_{\infty} = \lim_{r \to \infty} c(r, \theta, \varphi) \simeq \alpha + \beta r \cos \theta$$
. (3.12)

This inhomogeneous far field concentration is locally (with respect to inter-droplet distance  $\ell$ ) characterised by the concentration  $\alpha = c_{\infty}(x_0)$  and the gradient  $\beta = \partial_x c_{\infty}(x)|_{x_0}$  at the position of the droplet  $x_0$ . At the surface of the spherical droplet, r = R, the boundary condition is

$$c(R, \theta, \varphi) = c_{\text{out}}^{\text{eq}}(\theta)$$

$$\simeq \left( c_{\text{out}}^{(0)} + R \cos(\theta) \partial_x c_{\text{out}}^{(0)}(x) |_{x_0} \right) (1 + \ell_{\gamma}/R) .$$
(3.13)

Here,  $\ell_{\gamma}$  is the capillary length as introduced in section 2.5.1. Equation (3.13) corresponds to the Gibbs-Thomson relation (see section 2.5.2), which describes the increase of the local concentration at the droplet interface relative to the equilibrium concentration due to the surface tension of the droplet interface. The presence of spatial inhomogeneities on the scale of the droplet R lead to an additional term in the Gibbs-Thomson relation. To linear order, this contribution to  $c_{\text{out}}^{\text{eq}}$  reads  $R\cos(\theta)\partial_x c_{\text{out}}^{(0)}(x)|_{x_0}$ . The values of  $\beta$  and  $\alpha$  characterising the far field,  $c_{\infty}(x_0)$ , together with the local equilibrium concentration at the droplet surface,  $c_{\text{out}}^{\text{eq}}(\theta)$ , determine the local rates of growth or shrinkage of the drop at  $x = x_0$  in a spatially inhomogeneous regulator gradient.

The solution to the Laplace equation with cylindrical symmetry is of the form  $c(r,\theta) = \sum_{i=0}^{\infty} (A_i r^i + B_i r^{-i-1}) P_i(\cos \theta)$ , where  $P_i(\cos \theta)$  are

the Legendre polynomials. Using the boundary conditions (3.12) and (3.13), we find

<span id="page-19-0"></span>
$$\begin{split} c(r,\theta) &= \alpha \left( 1 - \frac{R}{r} \right) + \beta \cos \theta \left( r - \frac{R^3}{r^2} \right) \\ &+ \left( c_{\text{out}}^{(0)} + R \cos(\theta) \partial_x c_{\text{out}}^{(0)}(x) |_{x_0} \right) \left( 1 + \frac{\ell_{\gamma}}{R} \right) \frac{R}{r} \,. \end{split}$$

The droplet could grow, drift or deform due to normal fluxes of droplet material at the interface leading to a movement of the interface. The speed normal to the interface reads  $v_{\rm n} = \boldsymbol{n} \cdot \boldsymbol{v}_{\rm n}$ , where  $\boldsymbol{n}$  denotes the normal vector to the interface. In case of a spherical droplet,  $\boldsymbol{n} = \boldsymbol{e}_r$ , where  $\boldsymbol{e}_r$  is the radial unit vector in spherical coordinates. In the limit of strong phase separation, i.e.,  $c_{\rm in}^{(0)} \gg c_{\rm out}^{(0)}$ ,  $c_{\rm in}^{\rm eq} \simeq c_{\rm in}^{(0)}$ , and the velocity normal to the interface,  $v_{\rm n}$  (equation (2.47)), can be expressed by  $v_{\rm n} \simeq \boldsymbol{n} \cdot (\boldsymbol{j}_{\rm in} - \boldsymbol{j}_{\rm out})/c_{\rm in}^{(0)}$ . For weak spatial variations inside and outside of the droplet, the local flux is defined as  $\boldsymbol{j} = -D\nabla c$ . The concentration inside the droplet is approximately constant and for simplicity we consider it to be independent of the droplet position. Thus the flux inside the droplet vanishes,  $\boldsymbol{j}_{\rm in} = 0$ , while the flux outside reads  $\boldsymbol{j}_{\rm out} = -D\nabla c|_R$ .

Now we discuss how the normal speed  $v_{\rm n}$ can be used to calculate the droplet growth speed  $v_0$ , the droplet drift velocity  $v_1$ , and the rate of deformations from the spherical shape,  $v_2$ . this end, we parametrise the surface of the droplet in terms of Legendre polynomials as there is no dependence on the polar angle, which gives  $\mathcal{R}(\theta,t) = \sum_{i} d_{i}(t) P_{i}(\cos \theta)$ , where  $d_{i}(t)$  are the expansion coefficients characterising the shape of the interface. The corresponding interface velocity of an approximately spherical droplet is  $v_n \simeq \partial_t \mathcal{R}(\theta, t) =$  $\sum_{i} v_i(t) P_i(\cos \theta)$ , where the speeds for droplet growth, drift and deformations along the regulator gradient read  $v_i(t) = \partial_t d_i(t)$ . We can now identify the radius R as  $d_0 = \langle \mathcal{R}, P_0 \rangle / \langle P_0, P_0 \rangle$ , the position of the droplet center  $x_0$  as  $d_1 = \langle \mathcal{R}, P_1 \rangle / \langle P_1, P_1 \rangle$ , and the deformations are characterised by  $d_2 =$  $\langle \mathcal{R}, P_2 \rangle / \langle P_2, P_2 \rangle$  Here, the brackets indicate the scalar product  $\langle h, g \rangle = \int_0^{\pi} d\theta \sin \theta \, h \, g$  between the functions gand h. Most importantly, we can identify  $v_0 = dR/dt$ as the rate of change of the radius and  $v_1 = dx_0/dt$  as the drift velocity of the droplet center.

Using equation (3.14), we find for the droplet growth speed

<span id="page-19-1"></span>
$$\frac{\mathrm{d}R}{\mathrm{d}t} = \frac{D}{c_{\mathrm{in}}^{(0)}R} \left[ \alpha - c_{\mathrm{out}}^{(0)}(x_0) \left( 1 + \frac{\ell_{\gamma}}{R} \right) \right]. \tag{3.15}$$

In the presence of concentration gradients there also exists a net droplet drift speed

$$\frac{dx_0}{dt} = \frac{D}{c_{\text{in}}^{(0)}} \left[ 3\beta - \partial_x c_{\text{out}}^{(0)}(x) |_{x_0} \left( 1 + \frac{\ell_{\gamma}}{R} \right) \right] , \quad (3.16)$$

where we found in contrast to Ref. [32] an additional factor of 3 in front of the coefficient  $\beta$ . Note that both the growth rate and the drift speed are proportional to the molecular diffusion constant D of droplet material.

If the far field  $c_{\infty}(x)$  is well parametrised a linear gradient (equation (3.12)), there are deformations from the spherical shape,  $v_2 =$ Deformations of the spherical shape can only occur if higher order polynomials  $P_n(\cos \theta)$ with  $n \geq 2$  are necessary to describe the far If we include the quadratic order in the parametrisation of the far field (equation (3.12)),  $(r\cos\theta)^2\partial_x^2 c_\infty(x)|_{x_0}$ , the deformation speed reads  $v_2=(10/3)(RD/c_{\rm in}^{(0)})\partial_x^2 c_\infty(x)|_{x_0}$ . This quadratic contribution does not affect the droplet drift  $v_1$  but the growth law  $v_0$  is changed. The quadratic term gives an extra contribution inside the brackets of equation (3.15) of the form  $(5/3)R^2\partial_x^2 c_\infty(x)|_{x_0}$ . Thus, shape deformations and their impact on the growth law in the case of a non-linear far field gradient are negligible if

$$\frac{5\partial_x^2 c_{\infty}(x)|_{x_0}}{3c_{\infty}(x)|_{x_0}} R^2 \ll 1.$$
 (3.17)

For the system under consideration where length scales separate, i.e.,  $R \ll \ell \ll L$ , deformations from the spherical shape are weak because gradients of the far field  $c_{\infty}(x)$  occurs on the length scale of the system size L. In recent numerical studies considering a continuous phase separating Flory-Huggins model in a regulator gradient maintained by sink and source terms, droplet deformations are indeed visible when droplets approach the order of the system size [93].

3.2.3. Dynamical equation of multiple droplets in a concentration gradient. We can now describe the dynamics of many droplets, i = 1, ..., N, with positions  $x_i$  and radii  $R_i$ . If droplets are far apart from each other, the rate of growth of droplet i reads

<span id="page-19-3"></span>
$$\frac{\mathrm{d}R_i}{\mathrm{d}t} = \frac{D}{R_i} \frac{c_{\mathrm{out}}^{(0)}(x_i)}{c_{\mathrm{in}}^{(0)}} \left[ \varepsilon(x_i) - \frac{\ell_{\gamma}}{R_i} \right]. \tag{3.18a}$$

The drift velocity of droplet i,  $v_1(x_i) = dx_i/dt$ , is

$$\frac{\mathrm{d}x_i}{\mathrm{d}t} = \frac{D}{c_{\mathrm{in}}^{(0)}} \left[ 3\partial_x c_{\infty}(x)|_{x_i} - \partial_x c_{\mathrm{out}}^{(0)}(x)|_{x_i} \left( 1 + \frac{\ell_{\gamma}}{R_i} \right) \right]. \tag{3.18b}$$

<span id="page-19-2"></span>If the distance between droplets is large relative to their size, droplets only interact via the far field concentration field  $c_{\infty}(x,t)$ . It is governed by a diffusion equation including gain and loss terms associated with growth or shrinkage of drops:

$$\partial_t c_{\infty}(x,t) = D \frac{\partial^2}{\partial x^2} c_{\infty}(x,t)$$

$$-H(t) \sum_{i=1}^N \delta(x_i - x) \frac{4\pi}{3} \frac{\mathrm{d}}{\mathrm{d}t} R_i(t)^3,$$
(3.18c)

where the time-dependent function

$$H(t) = \frac{c_{\text{in}}^{(0)} - c_{\infty}(t)}{V - \sum_{i=1}^{N} \delta(x_i - x) \frac{4\pi}{3} R_i(t)^3}$$
(3.19)

is approximately constant,  $H \simeq c_{\rm in}^{(0)}/V$ , in the limit of strong phase separation  $c_{\rm in}^{(0)} \gg c_{\infty}(t)$  and for very large inter-droplet distances corresponding to  $V \gg \sum_{i=1}^N \delta(x_i-x) \frac{4\pi}{3} R_i(t)^3$  with V.

Equation (3.18c) describes the effects of large scale spatial inhomogeneities on the ripening dynamics for the case of a regulator gradient varying along the x-axis. Since large scale variations of  $c_{\infty}(x,t)$  only build up along the x-directions, derivatives of  $c_{\infty}$  along the y and z directions do not contribute as  $c_{\infty}$  and  $c_{\text{out}}^{(0)}$  are constant along these directions.

In the absence of a regulator gradient,  $c_{\mathrm{out}}^{(0)}$  and  $c_{\infty}$ are constant in space implying a position-independent and common supersaturation level  $\varepsilon$  for all droplets (equation (3.11)). In this case equation (3.18a) gives the classical law of droplet ripening derived by Lifschitz-Slyozov [6, 7] (also referred to as Ostwald ripening), and the net drift vanishes (equation (3.18b)). In the case of Ostwald ripening, droplets larger than the critical radius  $R_{\rm c} = \ell_{\gamma}/\varepsilon$  grow at the expense of smaller shrinking drops which then disappear. This competition between smaller and larger drops causes an increase of the average droplet size and a broadening of the droplet size distribution with time. Ostwald ripening is characterised by a supersaturation that decreases with time, leading to an increase of the critical droplet radius  $R_c = \ell_{\gamma}/\varepsilon(t) \propto t^{1/3}$ . The droplet size distribution P(R) exhibits an universal shape and is nonzero only in the interval  $[0, 3R_c/2]$ (figure 3.5(b), blue graph). In other words, there are no droplets larger than  $3R_c/2$  and thus also no droplets exist beyond the maximum of dR/dt at  $R = 2R_c$ where larger droplet could grow slower. Therefore, in homogeneous systems the broadening of P(R) follows from larger droplets growing at a larger rate dR/dtthan smaller droplets and because all droplets feel the same supersaturation level droplet positions remain homogeneously distributed in the system. presence of a regulator gradient the droplet dynamics exhibits a different behaviour.

3.2.4. Droplet positioning via position dependent growth and drift. There are two novel possibilities of

how droplet material is transported: There is exchange of material between droplets at different positions along the concentration gradient due to a position dependent droplet growth, and droplets can drift along the concentration gradient.

Droplets grow or shrink with rates that vary along the gradient because the local equilibrium concentration  $c_{\text{out}}^{(0)}(x)$  and the far field concentration  $c_{\infty}(x)$  are position dependent (equation (3.18a)). For a supersaturation  $\varepsilon(x) = \left(c_{\infty}(x)/c_{\text{out}}^{(0)}(x) - 1\right) > \ell_{\gamma}/R$ , a droplet located at position x grows, and shrinks in the opposite case. In other words, the critical droplet radius depends on position, and droplets with radii below or above  $R_c(x) = \ell_{\gamma}/\varepsilon(x)$  shrink or grow. This position dependence implies a movement of the dissolution boundary  $x_c(t)$  which is defined where the supersaturation  $\varepsilon(x_c(t)) = \ell_{\gamma}/R$  (equation 3.11). This definition can be simplified for the case where the capillary length, which is typically in the order of the molecular size, is small relative to the droplet radii, i.e.,  $\ell_{\gamma} \ll R$ , leading to  $c_{\infty}(x_{\rm c}(t)) \simeq c_{\rm out}^{(0)}(x_{\rm c}(t))$ . Taking the derivative in time gives the speed of the dissolution boundary,  $v_c(t) = \frac{\mathrm{d}x_c(t)}{\mathrm{d}t}$ :

<span id="page-20-0"></span>
$$v_{c}(t) = \frac{\mathrm{d}c_{\infty}(x)}{\mathrm{d}t} \bigg|_{x=x_{c}(t)} \bigg/ \frac{\mathrm{d}c_{\mathrm{out}}^{(0)}(x)}{\mathrm{d}x} \bigg|_{x=x_{c}(t)}. \tag{3.20}$$

We can now discuss the movement direction of the dissolution boundary. If droplets can grow in the system, the far field concentration should decay,  $\frac{\mathrm{d}c_{\infty}}{\mathrm{d}t} < 0$ . Thus the dissolution boundary always moves toward positions corresponding to smaller values of  $c_{\mathrm{out}}^{(0)}$ . When the dissolution boundary moves through the system it dissolves all droplets on its way. The dissolved droplet material will diffuse and feed the growth of the remaining droplets. Thus the moving dissolution boundary positions the phase separated material toward one boundary of the system corresponding to the lower values of the position-dependent equilibrium concentration  $c_{\mathrm{out}}^{(0)}(x)$ .

Another mechanism of positioning is via droplet drift (equation (3.18b)). The drift of a droplet results from an asymmetry of material flux at the interface parallel to the regulator gradient. To be more specific, we have to distinguish between the scenario of many droplets and the case of a single droplet. In the case of many droplets to the right of the dissolution boundary, the presence of these droplets keep the position-dependent supersaturation small, thus  $\frac{dc_{\infty}}{dx} \simeq \frac{dc_{\text{out}}^{(0)}}{dx}$ . Using the derived equation for droplet drift 3.16, the drift of droplet 'd' in a system with many droplets roughly follows

$$\frac{\mathrm{d}x_{\mathrm{d}}}{\mathrm{d}t} \simeq 2 \frac{D}{c_{\mathrm{in}}^{(0)}} \frac{\mathrm{d}c_{\mathrm{out}}^{(0)}}{\mathrm{d}x}.$$
 (3.21)

This equation implies that droplets drift into the opposite direction of the dissolution boundary. Thus droplets are pushed toward dissolution making it impossible for them to escape their dissolution via drift. This picture can be different for a single droplet. When diffusion is fast, the far field concentration is expected for be roughly homogeneous,  $\frac{dc_{\infty}}{dx} \simeq 0$ . As a consequence the drift points parallel to the direction of the dissolution boundary in the case of single droplet:

$$\frac{\mathrm{d}x_0}{\mathrm{d}t} \simeq -\frac{D}{c_{\text{in}}^{(0)}} \frac{\mathrm{d}c_{\text{out}}^{(0)}}{\mathrm{d}x}$$
 (3.22)

The droplet may thereby escape its dissolution by drift. The drift of a single droplet in a roughly homogeneous far-field concentration should be driven by the efflux of material at the back, which diffuses to the front of the droplet (droplet front is faced into the direction of movement of the dissolution boundary). Droplet movement then arises from asymmetric droplet growth between the back and the front of the droplet. The associated time-scale of this process is roughly given by the time to diffuse the droplet radii, i.e.,  $R^2/D$ . If this time-scale is smaller than the time-scale  $R/v_c$  necessary for the dissolution boundary to move the distance R, a single droplet may escape the dissolution boundary. Using equation 3.20 the condition for a single droplet to drift can thus be written as

$$D\frac{\mathrm{d}c_{\mathrm{out}}^{(0)}}{\mathrm{d}x} < R\frac{\mathrm{d}c_{\infty}}{\mathrm{d}t} \,. \tag{3.23}$$

Otherwise, the droplet would dissolve and recondense via nucleation typically in domains corresponding to lower values of the position-dependent equilibrium concentration  $c_{\text{out}}^{(0)}(x)$ .

*3.2.5.* Narrowing of the droplet size distribution. Numerically solving equations (3.18) for a large number of droplets we find that the droplet size distribution narrows during the positioning of droplets toward one boundary of the system. For details on the numerics, please refer to reference [32]. This narrowing of the droplet size distribution in a concentration gradient is fundamentally different from the broadening of the droplet size distributions during classical Ostwald ripening [6, 7]; see figure 3.5 for an illustration of the mechanism underlying the narrowing. Imagine we spatially quench the system by imposing a spatially varying equilibrium concentration  $c_{\mathrm{out}}^{(0)}(x)=c_{\mathrm{out}}^{(0)}(0)\,(1-m\,x)$ , where  $c_{\mathrm{out}}^{(0)}(0)$  denotes the equilibrium concentration before the quench and mis the slope of the "spatial quench". Such a spatial quench reduces the critical radius at the right boundary at x = L from  $R_c(0)$  (critical radius before the quench) to  $R_{\rm c}(x=L) = \ell_{\gamma}/\epsilon(x=L)$  (equation (3.11)). This

![](_page_21_Figure_8.jpeg)

![](_page_21_Figure_9.jpeg)

<span id="page-21-0"></span>Figure 3.5. Sketch depicting the mechanism of the narrowing of the droplet size distribution due to the presence of concentration gradients. (a) The black curve depicts the droplet growth speed dR/dt before the spatial quench, where the system undergoes Ostwald ripening with a homogenous far field  $c_{\infty}$  and a homogenous equilibrium concentration  $c_{\text{out}}^{(0)}(0)$ . The corresponding droplet size distribution is shown in (b). The spatial quench  $c_{\text{out}}^{(0)}(x) = c_{\text{out}}^{(0)}(0) (1 - mx)$  reduces the equilibrium concentration at x = L. Therefore, the local supersaturation increases which amounts to a decrease of the critical radius at x = 0 from  $R_c(0)$  to  $R_c(L)$  (indicated by red arrow). This change in supersaturation changes the droplet growth velocity dR/dt (orange). Subsequent to such a spatial quench mostly all droplets at x = L grow. However, larger droplets typically grow less than smaller drops. Consequently, the size distribution will narrow. The narrowing is most pronounced close to the rightmost boundary at x = L since the moving dissolution boundary dissolves all droplets at x < L. In addition, the dissolution of these droplets will keep the far field concentration  $c_{\infty}(x)$  at x = L at increased level which maintains a small value of critical radius until the dissolution boundary has reached the boundary at x = L.

quench also shifts the maximum of dR/dt for droplets at x = L to smaller radii since the radius corresponding to the maximum occurs at  $R = 2R_c$ . After the spatial quench there are many droplets with radii  $R > 2R_{\rm c}(x=L)$ . According to dR/dt (figure 3.5(a)) these droplets grow more slowly than those around  $R = 2R_{\rm c}$  which leads to a narrowing of the droplet size distribution P(R) at x = L. The critical radius  $R_c(x =$ L) remains small because dissolution of droplets at x < L leads to a diffusive flux toward x = L and thus keeps the concentration  $c_{\infty}(L)$  at increased levels. These conditions hold for a longer time if the spatial quench has a steeper slope. As a result the distribution narrows more for steeper quenches. For weak enough slopes of the quench, the narrowing of the droplet size distribution vanishes, however, droplet positioning still occurs as long as this slope is not zero.

When the dissolution boundary reaches the rightmost boundary close to x = L the critical radius catches up with the mean droplet size. Concomitantly,

narrowing of the droplet size distribution stops. Because all droplets are approximately of equal size the exchange of material between droplets via Ostwald ripening is slowed down dramatically. This slowing down of inter-droplet diffusion via Ostwald ripening leads to a long phase where droplet number and size is almost constant. Close to the end of this arrest phase, the droplet distribution begins to broaden slowly and the dynamics approaches classical Ostwald ripening.

In summary, a concentration gradient of a regulator component that affects phase separation can significantly change the dynamics of droplet The regulator gradient causes an coarsening. inhomogeneity of the equilibrium concentration and the concentration field far away from the droplet. Both induce a position-dependent ripening process where droplets can drift along the gradient and dissolve everywhere besides to a region close to one boundary of the system. During this positioning process of droplets to one boundary the droplet size distribution can dramatically narrow for steep enough quenches which causes a transient arrest of droplet growth. After this arrest phase the positioned droplets are subject to a locally homogenous concentration environment and the system recovers the dynamics of classical Ostwald ripening.

#### <span id="page-22-0"></span>4. Droplets driven by chemical turnover

Droplets can also be controlled by chemical reactions that directly affect the concentrations of the segregating species. For instance the building blocks B that form droplets could emerge from precursors P by a chemical reaction. While simple conversion reactions typically suppress phase separation, chemical reactions that are driven by an external energy input allow to control the droplet size as well as the droplet count and can even lead to spontaneous droplet division. To describe such phenomena, we start by deriving the dynamical equations from a thermodynamic consistent description of phase separation in the presence of chemical reactions.

#### <span id="page-22-3"></span>4.1. Thermodynamics of chemical reactions

Before we consider the coupling of phase separation and chemical reactions, we review the thermodynamics of chemical reactions in homogeneous systems. To highlight the core concepts, we here focus on very simple chemical reactions.

4.1.1. Chemical reactions in homogeneous systems We start by considering an isolated system where the two chemical species, the building block B and the precursor P, are converted into each other by the

<span id="page-22-1"></span>reaction

$$P \rightleftharpoons B$$
 . (R1)

At constant temperature T and volume V, the system is described by a free energy  $F(N_P, N_B)$ , where  $N_i$  are the particle numbers of type i = P, B. The thermodynamic equilibrium of the system corresponds to the minimum of F. The necessary condition for this minimum reads  $\mu_P dN_P + \mu_B dN_B = 0$ , where the chemical potentials are  $\mu_P = \partial F/\partial N_P|_{N_B}$  and  $\mu_B = \partial F/\partial N_B|_{N_P}$ . Note that in contrast to phase separation without reactions, species can now be converted into each other and only the total number of particles,  $M = N_P + N_B$ , is conserved. This implies  $dN_P = -dN_B$ , such that the equilibrium condition requires  $\mu_P - \mu_B = 0$ . Consequently, at equilibrium, the chemical reaction equalises the chemical potentials of the two species.

The difference between the chemical potentials,  $\mu_P - \mu_B$ , also affects the relaxation rate toward equilibrium. This rate is quantified by the total reaction flux  $s = -\mathrm{d}c_P/\mathrm{d}t = \mathrm{d}c_B/\mathrm{d}t$ , where  $c_i = N_i/V$  denotes the concentrations in the homogeneous system for i = P, B. Since the reaction can proceed in both directions, the total reaction flux  $s = s_{\rightarrow} - s_{\leftarrow}$  is given by the difference of the forward reaction flux  $s_{\rightarrow}$  associated with the conversion of P to B and the reverse flux  $s_{\leftarrow}$ . As a consequence of detailed balance, the ratio of the two reaction fluxes obey (see Appendix C)

$$\frac{s_{\rightarrow}}{s_{\leftarrow}} = \exp\left(-\frac{\mu_B - \mu_P}{k_{\rm B}T}\right) , \qquad (4.1)$$

which we call detailed balance of the rates [147]. The relation shows that the net direction in which the reaction proceeds depends on the sign of the chemical potential difference  $\mu_B - \mu_P$ . Moreover, the net reaction flux s vanishes at chemical equilibrium ( $\mu_P = \mu_B$ ) since  $s_{\rightarrow} = s_{\leftarrow}$ . Close to chemical equilibrium, equation (4.1) can be linearized and the reaction flux  $s = s_{\rightarrow} - s_{\leftarrow}$  can be expressed as

<span id="page-22-2"></span>
$$s = -\Lambda_{\rm r}(c_P, c_B) \left(\mu_B - \mu_P\right), \qquad (4.2)$$

where the function  $\Lambda_{\rm r}(c_P, c_B)$  determines the reaction rate.  $\Lambda_{\rm r}(c_P, c_B)$  is an Onsager coefficient, which must be positive to ensure a positive entropy production rate [110,123]; see Appendix B.

<span id="page-22-4"></span>4.1.2. Chemical reactions in inhomogeneous systems and stability of homogeneous states To describe chemical reactions in inhomogeneous systems, we assume local thermodynamic equilibrium, i.e., there exist local volume elements where thermodynamic quantities such as concentrations and temperature can be defined. This is possible when the local volumes equilibrate quickly compared to the rates of the processes

that we want to describe. In particular, the exchange with neighbouring volumes, associated with diffusive transport, and the conversion of particles into different species, associated with chemical reactions, should take place on timescales longer than the equilibration timescale of the volumes. If this is the case, a system of reacting and diffusing particles can be described by concentration fields  $c_i(\mathbf{r})$  for all species i.

To study the interplay of the chemical reaction (R1) with phase separation, we first consider a binary, incompressible system described by the concentration of the droplet component,  $c_B(\mathbf{r}) = c(\mathbf{r})$ , while  $c_P(\mathbf{r}) = \nu^{-1} - c(\mathbf{r})$  with  $\nu$  denoting the molecular volume of P and B. The behavior of the system is governed by the free energy F[c], which is now a functional of the concentration field  $c(\mathbf{r})$ . For simplicity, we here consider the form

$$F[c] = \int d^3r \left( f(c) + \frac{\kappa}{2} |\nabla c|^2 \right) , \qquad (4.3)$$

which combines a local contribution of the free energy density f(c) with a term that accounts for the free energy costs of spatial inhomogeneities proportional to  $\kappa$ , analogous to section 2.1.5. The exchange chemical potential  $\bar{\mu} = \mu_B - \mu_P$  is thus given by  $\bar{\mu} = \delta F[c]/\delta c$ . The resulting equilibrium condition of the chemical reaction is  $\bar{\mu}(\mathbf{r}) = 0$ , which includes the equilibrium condition for phase separation,  $\bar{\mu}(\mathbf{r}) = \text{const.}$ , see section 2.2.1.

The dynamical equation of the system follows from the conservation law  $\,$ 

$$\partial_t c + \nabla \cdot \mathbf{j} = s \,, \tag{4.4}$$

where  $\boldsymbol{j}$  is the diffusive flux and s is the net flux of the production of species B by the reaction (R1). These two thermodynamic fluxes are driven by their respective conjugated forces  $\nabla \bar{\mu}$  and  $\bar{\mu}$ ; see Appendix B. Using linear response theory,  $\boldsymbol{j} = -\Lambda \nabla \bar{\mu}$  and  $s = -\Lambda_r \bar{\mu}$ , we arrive at the dynamical equation

$$\partial_t c = \nabla \cdot \left[ \Lambda(c) \, \nabla \bar{\mu}(c) \right] - \Lambda_{\rm r}(c) \, \bar{\mu}(c) \,, \tag{4.5}$$

which describes a binary system that exhibits phase separation and chemical reactions. Note that we recover the Cahn-Hilliard equation if chemical reactions are absent ( $\Lambda_{\rm r}=0$ ). Conversely, in the limit where  $\Lambda_{\rm r}$  is constant and diffusive fluxes vanish ( $\Lambda=0$ ), we obtain the Allen-Cahn model [148], which is the deterministic version of model A [124].

We study the effects of chemical reactions by first analyzing homogeneous equilibrium states  $c(\mathbf{r}) = c_0$ , which are governed by the equilibrium condition  $\bar{\mu}(\mathbf{r}) = 0$ . This condition implies vanishing chemical reaction flux, see equation (4.2), and  $f'(c_0) = 0$ , so that  $c_0$  is a (local) extremum of the free energy

![](_page_23_Figure_12.jpeg)

<span id="page-23-1"></span>Figure 4.1. Schematic representation of the impact of chemical reactions on phase separation. (a) In chemical equilibrium, a system that is able to phase separate settles in the minimum of the free energy density corresponding to the homogeneous concentration  $c_0$ . Phase separated states with concentrations  $c_1 = \phi_1/\nu$  and  $c_2 = \phi_2/\nu$  are no more stable. (b) Growth rate as a function of the wavenumber q = |q| (q: wave vector) for phase separation in the absence of chemical reactions (grey), phase separation in the presence of a chemical reaction tending toward chemical equilibrium satisfying detailed balance of the rates (blue), and phase separation combined with non-equilibrium chemical reactions which break detailed balance of the rates (red). The sign of  $s'(c_0)$  can be adjusted by the chemical potential difference between fuel and waste,  $\bar{\mu}_2$ , for example. The homogeneous concentration  $c_0$  is defined as the concentration at which  $s(c_0) = 0$ .

density f(c). To assess the stability of these states, we consider harmonic perturbations with wave vector  $\mathbf{q}$ , as described in section 2.4. In the linear regime, these perturbations grow with a rate

<span id="page-23-0"></span>
$$\omega(\mathbf{q}) = -\left[\Lambda(c_0)\mathbf{q}^2 + \Lambda_{\mathrm{r}}(c_0)\right]\left[f''(c_0) + \kappa \mathbf{q}^2\right]. \quad (4.6)$$

<span id="page-23-2"></span>The system is stable if all perturbations decay, i.e., if  $\omega(\mathbf{q}) < 0$  for all wave vectors  $\mathbf{q}$ . Since  $\Lambda, \Lambda_{\rm r} \geq 0$ , the stability is governed by the sign of the second bracket in equation (4.6) and the homogeneous state becomes unstable when  $f''(c_0) < 0$  [149]. This condition is identical to the condition for the spinodal instability in the case without chemical reactions ( $\Lambda_{\rm r}=0$ ). However, in the presence of chemical reactions, only the homogeneous states with  $f'(c_0) = 0$  are stationary states because particles numbers of P and B are not conserved. In contrast, in the absence of chemical reactions, all homogeneous states are stationary with the homogeneous concentrations of P and B being conserved. Particle conservation also implies  $\omega(0) = 0$ , while the q = 0 mode is unstable when chemical reactions are present, see figure 4.1(b).

<span id="page-23-3"></span>Taken together, we showed that if the system settles in a homogeneous state it will attain minimal free energy [149, 150], see figure 4.1(a). The major difference to the case without chemical reactions is that the species are not conserved individually and the system can thus relax by altering the composition locally. In the next section, we will show that this local conversion destabilises all inhomogeneous states including the ones corresponding to coexisting phases.

<span id="page-24-0"></span>4.1.3. Dissolution of droplets by chemical reactions We now investigate the stability of inhomogeneous states to see how chemical reactions that can relax to equilibrium (¯µ = 0) affect droplets. As an example, we first discuss the Ginzburg-Landau free energy presented in equation [\(2.19\)](#page-6-4). When chemical reactions are present, this free energy permits two stable homogeneous solutions, corresponding to the two minima of the free energy density. Without chemical reactions, we have shown in section [2.2](#page-6-1) that there is also a stable inhomogeneous stationary state, which consists of two bulk phases separated by an interfacial region. In the simple case of a onedimensional system, the interfacial profile cI(x) is given by equation [\(2.28\)](#page-7-0). This interfacial profile is also a stationary state in the case with chemical reactions, since the symmetric free energy implies vanishing chemical potentials in the two bulk phases and thus satisfies the equilibrium condition µ(r) = 0.

To scrutinise the stability of the interfacial profile in the presence of chemical reactions, we determine whether a small change δc in the concentration profile could possibly decrease the free energy. Mathematically, this corresponds to calculating the second variation ∆F[c<sup>I</sup> , δc] of the free energy, which is given by equation [\(2.30\)](#page-7-3). The stationary state is stable if ∆F[c<sup>I</sup> , δc] is positive for every nonzero variation δc. We show in [Appendix A](#page-36-0) that indeed almost all perturbations δc increase the free energy. The only exception is δc = ∂xc<sup>I</sup> , for which ∆F = 0, implying that this perturbation does not decay in time and the state is marginally stable. This perturbation corresponds to an infinitesimal translation, indicating that interfaces can move without changing the total free energy when chemical reactions are present. Note that this perturbation does not conserve the mass of the individual species and is thus forbidden in the case without chemical reactions discussed in section [2.2.2.](#page-7-2) Taken together, we showed that the sigmoidal interface profile given by equation [\(2.28\)](#page-7-0) is neither stable nor unstable in the special case of the Ginzburg-Landau free energy, where both minima have the same energy.

In the general case where the minima of the free energy density are at different energies (see figure [2.1\(](#page-4-2)a)), the global free energy decreases when the interface moves such that the phase with the smaller free energy density expands [\[150\]](#page-43-11). Consequently, coexisting phases in asymmetric free energies are unstable due to presence of chemical reactions. Similarly, curved interfaces are unstable (also in the case of a symmetric free energy density), since the associated Laplace pressure implies elevated concentrations on both sides of the interface, see equations [\(2.45\)](#page-9-3). The Laplace pressure, and thus the concentrations and the free energy, decrease when the interface moves towards its concave side, implying that droplets shrink [\[150\]](#page-43-11). Taken together, these arguments show that inhomogeneous states are generally unstable when chemical reactions are present and the system attains the global free energy minimum everywhere, see figure [4.1\(](#page-23-1)a).

A hint of these dynamics is visible in the simulation results shown in the middle column in figure [4.3,](#page-26-0) where the chemical potential difference ¯µ is very close to zero in the bulk phases but finite at the interfaces. In fact, the chemical potential deviates from zero more strongly at interfacial regions of larger curvature. One consequence of this observations is that the local entropy production Λrµ¯ <sup>2</sup> by the chemical reactions is also largest at the interfaces.

Taken together, we showed that droplets are destabilised by the simple conversion reaction [\(R1\)](#page-22-1) obeying detailed balance of the rates. In particular, the system always settles in a homogeneous state, even if droplets appear initially due to a spinodal instability or nucleation. The reason for the initial appearance of droplets is that diffusion is fast on small length scales and the formation of droplets locally reduces the free energy density. On longer time scales, the chemical reaction drives the system into a homogeneous equilibrium state. To compensate this destabilisation of droplets due to the reaction [\(R1\)](#page-22-1) we will introduce an additional chemical reaction in the bulk phases. This chemical reaction is driven by fuel, and thereby breaks detailed balance of the rates and can prevent the chemical reaction driving the system to a homogeneous equilibrium state. This additional chemical reaction allows us to control the behaviour of droplets. In particular, we will show that systems where droplet material is produced in one phase while it is destroyed in the other can lead to interesting phenomena such as mono-disperse emulsions or dividing droplets.

## 4.2. Phase separation with broken detailed balance of the rates

The detailed balance of the conversion reaction between the precursor P and the building block B can be broken effectively by coupling the system to an external energy supply. This can for instance be achieved by adding a second reaction that converts P into B using additional energy supplied by fuel and waste components, which we respectively denote by F and W; see figure [4.2\(](#page-25-0)a). The associated chemical reactions,

$$P \rightleftharpoons B$$
, (R1)

$$P + F \rightleftharpoons B + W$$
, (R2)

will allow us to drive the system out of equilibrium by controlling the concentrations of F and W externally.

![](_page_25_Picture_2.jpeg)

<span id="page-25-0"></span>Figure 4.2. Illustration of the fuel-driven chemical reactions and the diffusive fluxes relevant for an active emulsion. (a) The key feature required for an active emulsion is that precursor molecules P are turned into building blocks B by a chemical reaction that consumes energy. This energy could be supplied by fuel that turns into waste during this transition. Energy is dissipated when the building block of higher chemical potential spontaneously transitions to the precursor of lower chemical potential. The reaction rates, and thus also the lifetime of the building block, depend strongly on the chemical composition, i.e., whether the reaction takes place in a droplet or not [80,151]. (b) This schematic depicts the processes occurring inside and outside of a building block rich droplet in an active emulsion considering the example of an externally maintained droplet. Building blocks inside such a droplet are turned into precursors. The resulting precursors diffusive out of the droplet where they may get transformed into building blocks again by the consumption of fuel. These building blocks may in turn diffusive into the droplet and replenish the spontaneously degraded building blocks inside the droplet.

precursor rich solvent

To study the interplay of these reactions with phase separation, we describe the system using a free energy density  $f_4(c_P, c_B, c_F, c_W)$ . A simple choice is

$$f_4 = k_{\rm B}T \left[ \sum_i c_i \log(\nu c_i) + \chi \nu c_P c_B \right], \qquad (4.7)$$

where the sum captures the entropic contributions of all species i=P,B,F,W and the last term accounts for the interaction between P and B. For simplicity, we consider the case where the additional components F and W are dilute and do not interact with P and B. In this case, the additional components do not affect the phase separation of P and B. Without chemical reactions, this system phase separates similar to the binary system discussed in section 2. In particular, the chemical potentials  $\mu_i = \partial f_4/\partial c_i$  for i=P,B,F,W are homogeneous throughout the system and the chemical potential difference  $\bar{\mu} = \mu_B - \mu_P$  between P and B is generally non-zero and equal to the Lagrange multiplier fixing the conservation of components; see equation (2.26).

When chemical reactions are present, they are driven by the chemical potential differences of their products and reactants. If the system is isolated, it will typically evolve toward a homogeneous thermodynamic equilibrium, as described in section 4.1.3. In contrast, this thermodynamic equilibrium may not be reached in open systems, for instance when the concentrations of the fuel and waste components are controlled at the boundary by coupling the system to a reservoir. In particular, the chemical potential difference  $\bar{\mu}_2$  =  $\mu_F - \mu_W$  between fuel and waste can be directly controlled at the boundary. To show that imposing  $\bar{\mu}_2 \neq 0$  breaks detailed balance of the conversion rates between the precursor P and the building block B, we next investigate the forward and backward fluxes of the two reaction pathways (R1) and (R2). These fluxes must obey conditions analogous to equation (4.1),

<span id="page-25-1"></span>
$$\frac{s_{\rightarrow}^{(1)}}{s_{\leftarrow}^{(1)}} = \exp\left(-\frac{\bar{\mu}}{k_{\rm B}T}\right) \tag{4.8a}$$

$$\frac{s_{\rightarrow}^{(2)}}{s_{\leftarrow}^{(2)}} = \exp\left(\frac{\bar{\mu}_2 - \bar{\mu}}{k_{\rm B}T}\right) . \tag{4.8b}$$

These equations show that detailed balance of the individual reaction pathways can only be obtained for vanishing exchange chemical potentials,  $\bar{\mu} = \bar{\mu}_2 = 0$ . Moreover, the total forward flux  $s_{\rightarrow} = s_{\rightarrow}^{(1)} + s_{\rightarrow}^{(2)}$  and total reverse flux  $s_{\leftarrow} = s_{\leftarrow}^{(1)} + s_{\leftarrow}^{(2)}$  of the conversion between P and B obey

$$\frac{s_{\to}}{s_{\leftarrow}} = e^{-\frac{\bar{\mu}}{k_{\rm B}T}} \left[ 1 + \frac{1}{1 + \frac{s_{\leftarrow}^{(1)}}{s_{\leftarrow}^{(2)}}} \left( e^{\frac{\bar{\mu}_2}{k_{\rm B}T}} - 1 \right) \right] , \quad (4.9)$$

which is only compatible with the detailed balance of the rates given by equation (4.1) in the special case  $\bar{\mu}_2 = 0$ . Consequently, detailed balance of the rates is broken for  $\bar{\mu}_2 \neq 0$ .

The detailed balance conditions given by equations (4.8) only constrain the ratios of the forward and backward fluxes of the two chemical reactions (R1) and (R2). Analogous to equation (4.2), the total reaction fluxes  $s^{(i)} = s_{\rightarrow}^{(i)} - s_{\leftarrow}^{(i)}$  for each pathway can be expressed in the linearized regime as

<span id="page-25-2"></span>
$$s^{(1)} = -\Lambda_{\rm r}^{(1)}(\mathbf{c})\,\bar{\mu}\,,$$
 (4.10a)

$$s^{(2)} = -\Lambda_{\rm r}^{(2)}(\mathbf{c})(\bar{\mu} - \bar{\mu}_2) ,$$
 (4.10b)

where  $\Lambda_{\rm r}^{(1)}$  and  $\Lambda_{\rm r}^{(2)}$  are Onsager coefficients that set the reaction rates. These coefficients can depend on the concentrations  $\mathbf{c} = \{c_P, c_B, c_F, c_W\}$  but must be positive to ensure that the entropy productions  $\Lambda_{\rm r}^{(1)} \bar{\mu}^2$ and  $\Lambda_{\rm r}^{(2)} (\bar{\mu} - \bar{\mu}_2)^2$  are positive; see Appendix B. For simplicity, we here consider the case where the fuel F and the waste W are dilute and diffuse fast, so the local composition can be described by a single

![](_page_26_Figure_2.jpeg)

<span id="page-26-0"></span>Figure 4.3. Influence of chemical reactions on phase separation. Shown are concentration profiles (upper row) and associated chemical potentials (lower row) of a binary system with equal amounts of P and B in different situations: Without chemical reactions the system undergoes coarsening by diffusive transport (left column). With an additional conversion reaction between the two species, the bulk phases relax quickly and the interface moves due to localised reactions (middle column). If detailed balance is broken, the system is driven away from equilibrium everywhere and more complex dynamics can occur (right column).

concentration  $c=c_B\simeq \nu^{-1}-c_P$ , where we consider the case of equal molecular volume  $\nu$  for precursors P and building blocks B. In particular,  $\Lambda_{\rm r}^{(1)}$  and  $\Lambda_{\rm r}^{(2)}$  mainly depend on c in this case and we do not need to describe the dynamics of the additional components F and W explicitly. However, their chemical energy  $\bar{\mu}_2$  affects the conversion between P and B. In particular, detailed balance of the conversion between P and B is broken in the reduced system where only these two components are described.

The dynamical equation of the system with broken detailed balance of the rates is given by the conservative diffusion fluxes driven by  $\nabla \bar{\mu}$  together with the non-conservative reaction flux  $s_{\text{tot}} = s^{(1)} + s^{(2)}$  given in equations (4.10). Using a conservation law analogous to equation (4.4), we obtain

$$\partial_t c = \nabla \cdot \left( \Lambda(c) \, \nabla \bar{\mu}(c) \right) + \kappa \Lambda_{\rm r}^{(\rm tot)}(c) \, \nabla^2 c + s(c) \; , \tag{4.11}$$

where  $\Lambda_{\rm r}^{({\rm tot})}=\Lambda_{\rm r}^{(1)}+\Lambda_{\rm r}^{(2)}$  and we split the total reaction flux  $s_{{\rm tot}}$  into a contribution akin to a diffusion term related to surface tension and a local contribution  $s(c)=\Lambda_{\rm r}^{(2)}(c)\bar{\mu}_2-\Lambda_{\rm r}^{({\rm tot})}(c)f'(c)$ . We will show below that the term s(c) can affect the dynamics significantly, while the additional diffusion term has only a minor influence since it only increases the effective diffusion constant. Note that if detailed balance is obeyed

 $(\bar{\mu}_2 = 0)$ , equation (4.11) reduces to equation (4.5) when  $\Lambda_r^{(\text{tot})}$  is replaced by  $\Lambda_r$ . In this case, the system approaches the homogeneous equilibrium states that we discussed in section 4.1. Conversely, more complex behavior can be expected when detailed balanced of the rates is broken by maintaining a non-zero chemical potential difference  $\bar{\mu}_2$ .

Equation (4.11) without the additional diffusion term has been proposed before as a simple combination of phase separation with chemical reactions [46, 51], albeit without an explicit breaking of detailed balance [152]. Instead, simple reaction rate laws s(c) have been analyzed [46, 51, 52, 60, 153]. For instance, it has been shown that first-order rate laws are equivalent to systems with long-ranged interactions of the Coulomb type [51, 154] and that such interactions affect pattern formation [53,54,155–157], e.g., in block copolymers [154,158–161].

<span id="page-26-1"></span>The effect of the chemical reactions with broken detailed balance of the rates can be highlighted by considering the stationary homogeneous states  $c(r) = c_0$ . Equation (4.11) implies that  $c_0$  must satisfy  $s(c_0) = 0$ , i.e., chemical reactions are balanced. When detailed balance is obeyed  $(\bar{\mu}_2 = 0)$ , this condition is equivalent to the equilibrium condition  $f'(c_0) = 0$  that we encountered before. Conversely, the homogeneous stationary states are altered when detailed balance of the rates is broken  $(\bar{\mu}_2 \neq 0)$ .

We examine the stability of the homogeneous states using a linear stability analysis, as described in section 2.4. We find that perturbations described by wave vectors  $\boldsymbol{q}$  grow in the linear regime with a rate

$$\omega(\mathbf{q}) = s'(c_0) - \mathbf{q}^2 \zeta(c_0) - \mathbf{q}^4 \Lambda(c_0) \kappa , \qquad (4.12)$$

where  $\zeta(c_0) = \Lambda(c_0)f''(c_0) + \kappa \Lambda_{\rm r}^{({\rm tot})}(c_0)$  and primes denote derivatives with respect to c. The associated stationary state is stable only if  $\omega(q)$  is negative for all q, which is the case if the maximum

$$\max_{\mathbf{q}} \left( \omega(\mathbf{q}) \right) = \begin{cases} s'(c_0) & \zeta(c_0) \ge 0 \\ s'(c_0) + \frac{\zeta^2(c_0)}{4\kappa\Lambda(c_0)} & \zeta(c_0) < 0 \end{cases}$$
(4.13)

is negative. In the simple case without reactions  $(\Lambda_{\rm r}^{({\rm tot})}(c)=0, {\rm implying}\ \zeta=\Lambda f''(c_0)\ {\rm and}\ s'(c_0)=0),$  we obtain the spinodal instability for  $f''(c_0)<0$ , which is discussed in section 2.4 and shown by the grey line in figure 4.1(b). If the reactions obey detailed balance of the rates, implying  $s(c)=-\Lambda_{\rm r}f'(c)$  and thus  $s'(c_0)=-\Lambda_{\rm r}(c_0)f''(c_0)$ , the homogeneous states corresponding to minima of the free energy density are stable; see section 4.1.2 and the blue line in figure 4.1(b).

Chemical reactions that break detailed balance of the rates  $(\bar{\mu}_2 \neq 0)$  can modify the stability of stationary states; see red lines in figure 4.1(b). Equation (4.13) implies that a homogeneous state can become unstable when  $s'(c_0) > 0$  [162, 163]. This case corresponds to an auto-catalytic reaction, since it implies that the production of building blocks B accelerates with larger concentration of B. Conversely, homogeneous states are generally stabilized by auto-inhibitory reactions, where  $s'(c_0) < 0$ . In particular, these effects can be observed for homogeneous states close to the equilibrium states that we discussed before, where  $f''(c_0) > 0$  and thus  $\zeta > 0$ . In this regime, our stability analysis suggests that droplets form and grow easily in auto-catalytic systems, while spontaneous formation might be suppressed by auto-inhibitory reactions. In particular, the behavior can be regulated independent of the free energy density using the externally controlled chemical potential difference  $\bar{\mu}_2$ .

Although it is not directly relevant to active droplets, the dynamics of homogeneous stationary states with  $\zeta < 0$  is also interesting. It implies  $f''(c_0) < 0$  and the corresponding homogeneous stationary states are thus closer to maxima of the free energy density. In this case, there exists a regime with weakly autoinhibitory reactions  $(-\zeta^2/(4\kappa\Lambda) < s'(c_0) < 0)$  where a range of finite wave vectors q becomes unstable and pattern formation is expected. This regime has been studied extensively in the literature [46, 47, 51] and typically leads to stripe-like patterns. Since we here focus on active emulsions, we exclusively consider the case  $\zeta > 0$  below.

<span id="page-27-2"></span>In this section, we discussed a model system where additional fuel and waste components break the detailed balance of the rates of the conversion of the main components P and B. We showed that this combination of phase separation with non-equilibrium chemical reactions can suppress the instability associated with spinodal decomposition and we will now analyse the impact on the dynamics of droplets.

<span id="page-27-3"></span><span id="page-27-0"></span>4.2.1. Coarse-grained description of active droplets. We next discuss the dynamics of active droplets in the case of strong phase separation, where the interfacial width w is small compared to the droplet radius R. In this case, the volume occupied by the interface and thus the chemical reactions inside the interfacial region are negligible. Conversely, we will show that the chemical reactions producing and destroying droplet material in the bulk phases influence the droplet dynamics significantly. We here consider a coarsegrained description, where a thin interface separates the inside of the droplet with a high concentration of droplet material B from the dilute phase outside, analogous to section 2.5.2. The dynamics in both phases is described by equation (4.11), but since the concentration variations are small within the phases, it can be approximated by a reaction-diffusion equation [76],

<span id="page-27-1"></span>
$$\partial_t c \simeq D_\alpha \nabla^2 c + s(c) ,$$
 (4.14)

where  $D_{\alpha} = \Lambda(c_{\alpha}^{(0)})f''(c_{\alpha}^{(0)}) + \kappa \Lambda_{\rm r}^{({\rm tot})}(c_{\alpha}^{(0)})$  denotes the diffusivity in the two phases  $\alpha = {\rm in}$ , out. The first term in the expression for  $D_{\alpha}$  stems from the conservative fluxes and is thus equivalent to equation (2.41) while the second term captures the apparent diffusion due to chemical conversion. Note that the diffusivity  $D_{\rm in}$  inside the droplet is generally different than the diffusivity  $D_{\rm out}$  outside. The same approximation that led to equation (4.14) can also be used to linearize the reaction flux in the two phases,

$$s(c) \simeq \begin{cases} \Gamma_{\rm in} - k_{\rm in}(c - c_{\rm in}^{(0)}) & \text{inside} \\ \Gamma_{\rm out} - k_{\rm out}(c - c_{\rm out}^{(0)}) & \text{outside} \end{cases} , \tag{4.15}$$

where  $\Gamma_{\rm in} = s(c_{\rm in}^{(0)})$  and  $\Gamma_{\rm out} = s(c_{\rm out}^{(0)})$  are the reaction fluxes when the concentrations are at their equilibrium values  $c_{\rm in}^{(0)}$  and  $c_{\rm out}^{(0)}$  in the two phases, respectively. Deviations from these values are accounted for by  $k_{\rm in} = -s'(c_{\rm in}^{(0)})$  and  $k_{\rm out} = -s'(c_{\rm out}^{(0)})$ , which can be interpreted as elasticity coefficients of the chemical reactions [164].

The basal fluxes  $\Gamma_{\rm in}$  and  $\Gamma_{\rm out}$  need to have opposite sign for droplets to exist. If they had the same sign, droplet material would either be destroyed

 $(\Gamma_{\rm in}, \Gamma_{\rm out} < 0)$  or produced everywhere  $(\Gamma_{\rm in}, \Gamma_{\rm out} > 0)$ , which both implies a homogeneous stationary state. To see under which conditions the basal fluxes have opposite sign, we express them as

$$\Gamma_{\rm in} = -\Lambda_{\rm r}^{(1)}(c_{\rm in}^{(0)})\,\bar{\mu} - \Lambda_{\rm r}^{(2)}(c_{\rm in}^{(0)})(\bar{\mu} - \bar{\mu}_2) , \quad (4.16a)$$

$$\Gamma_{\rm out} = -\Lambda_{\rm r}^{(1)}(c_{\rm out}^{(0)})\,\bar{\mu} - \Lambda_{\rm r}^{(2)}(c_{\rm out}^{(0)})(\bar{\mu} - \bar{\mu}_2) , \quad (4.16b)$$

using equations (4.10). To give a concrete example, we here consider weak chemical reactions, so that the diffusive fluxes almost equilibrate the exchange chemical potential  $\bar{\mu}$ , which is therefore approximately homogeneous. If the building block B is of higher energy than the precursor  $P(\bar{\mu} > 0)$ , equations (4.16) imply that droplet material is produced outside the droplet ( $\Gamma_{\rm out} > 0$ ) and destroyed within ( $\Gamma_{\rm in} < 0$ ) if the fuel supplies sufficient energy ( $\bar{\mu}_2 > \bar{\mu} > 0$ ) and the Onsager coefficients obey

$$\frac{\Lambda_{\rm r}^{(1)}(c_{\rm out}^{(0)})}{\Lambda_{\rm r}^{(2)}(c_{\rm out}^{(0)})} < \frac{\bar{\mu}_2}{\bar{\mu}} - 1 < \frac{\Lambda_{\rm r}^{(1)}(c_{\rm in}^{(0)})}{\Lambda_{\rm r}^{(2)}(c_{\rm in}^{(0)})}.$$
 (4.17)

For instance, if  $\bar{\mu}$  is equal in the two phases and the external energy input is given by  $\bar{\mu}_2 = 2\bar{\mu}$ , reaction (R1) must be faster than reaction (R2) inside the droplet,  $\Lambda_{\rm r}^{(1)}(c_{\rm in}^{(0)}) > \Lambda_{\rm r}^{(2)}(c_{\rm in}^{(0)})$ , while the opposite is true outside,  $\Lambda_{\rm r}^{(1)}(c_{\rm out}^{(0)}) < \Lambda_{\rm r}^{(2)}(c_{\rm out}^{(0)})$ . In this case, the conversion reaction (R1) proceeds from the building block B to the precursor P spontaneously  $(s^{(1)} < 0)$ , while reaction (R2) converts fuel to waste to produce the high-energy building block B from  $P(s^{(2)} > 0)$ ; see figure 4.2. If the coefficients  $\Lambda_{\rm r}^{(1)}$  and  $\Lambda_{\rm r}^{(2)}$  obey equations (4.17) the total reaction flux  $s_{\rm tot} = s^{(1)} + s^{(2)}$  is then positive outside the droplet, while it is negative inside. A concrete implementation of such a system is discussed in the Supporting Information of Ref. [79].

We showed that droplet material can be produced in one phase while it is destroyed in the other when the basal fluxes  $\Gamma_{\rm in}$  and  $\Gamma_{\rm out}$  have opposite sign. Do similar conditions apply to the elasticity coefficients  $k_{\rm in}$  and  $k_{\rm out}$ ? We showed in section 4.2 that negative s'(c) has a stabilising effect and we would thus expect that droplets can persist if k>0; see also figure 4.1(b). Conversely, since positive s'(c) can destabilise homogeneous phases, the active droplets we discuss here might be unstable if k<0. However, there is a smallest length scale  $q_{\rm max}^{-1}$  below which the instability cannot develop. This length scale can be determined from equation (4.12) and the condition  $\omega(q_{\rm max})=0$ , yielding

$$q_{\text{max}}^{-1} \simeq \left[ \frac{\zeta(c_{\text{in}}^{(0)})}{s'(c_{\text{in}}^{(0)})} \right]^{\frac{1}{2}},$$
 (4.18)

for weak reactions,  $s'(c_{\rm in}^{(0)}) \ll \zeta(c_{\rm in}^{(0)})$ . In the case where  $q_{\rm max}^{-1}$  is large compared to the droplet radius,

<span id="page-28-0"></span>![](_page_28_Figure_10.jpeg)

<span id="page-28-2"></span>Figure 4.4. Schematic picture of an externally maintained active droplet, where droplet material is produced in the solvent phase. (a) Concentration c of droplet material as a function of the radial distance r. The chemical reactions modify the profiles compared to the passive droplet shown in Figure 2.2(a). (b) Reaction flux s as a function of r. Droplet material is produced outside the droplet while it is degraded inside. The droplet dynamics can strongly deviate from the passive case. In particular, Ostwald ripening can be suppressed and droplets even divide spontaneously (see section 4.3 and 4.4).

<span id="page-28-1"></span>the instability is effectively suppressed and the droplet could be stable even if  $k_{\rm in} < 0$ . Conversely, the dilute phase will typically be large compared to  $q_{\rm max}^{-1}$ , such that an instability would develop there if  $k_{\rm out} < 0$ . In the following, we thus consider all values of  $k_{\rm in}$ , but restrict our discussion to  $k_{\rm out} > 0$ .

We distinguish different classes of active droplets based on where droplet material is produced. If the reaction fluxes  $\Gamma_{\rm in}$  and  $\Gamma_{\rm out}$  have the same sign, droplet material is produced or destroyed in the entire system and the only stable stationary state are homogeneous. Consequently, stable droplets can only exist if  $\Gamma_{\rm in}$  and  $\Gamma_{\rm out}$  have opposite sign: We denote the case where droplet material is produced outside the droplets ( $\Gamma_{\rm out} > 0$ ,  $\Gamma_{\rm in} < 0$ ) as externally maintained droplets, while the opposite case where droplets produce their own material ( $\Gamma_{\rm in} > 0$ ,  $\Gamma_{\rm out} < 0$ ) is called internally maintained droplets.

<span id="page-28-4"></span>4.2.2. Droplet growth equation. We begin by studying a single, isolated active droplet surrounded by a large dilute phase. The droplet grows if there is a net flux of droplet material toward its surface, see equation (2.47). In the simple case of a spherical droplet of given radius R and volume  $V_{\rm d} = \frac{4\pi}{3} R^3$ , the growth rate reads

<span id="page-28-3"></span>
$$\frac{\mathrm{d}V_{\rm d}}{\mathrm{d}t} \simeq \frac{J_{\rm in} - J_{\rm out}}{c_{\rm in}^{(0)} - c_{\rm out}^{(0)}} \,,\tag{4.19}$$

where we neglected surface tension effects in the denominator and defined the integrated surface fluxes  $J_{\rm in/out} = 4\pi R^2 \, \boldsymbol{n} \cdot \boldsymbol{j}_{\rm in/out}$ . These fluxes can be determined from the stationary solutions  $c_*(r)$  that follow from solving equation (4.14) with the boundary conditions at the interface given in equation (2.45), see figure 4.4(a).

The flux  $J_{in}$  inside the droplet interface can be obtained in the quasi-static limit, where it equals the

reaction flux  $S_{\rm in} = \int {\rm d}^3 r \, s(c_*(r))$  inside the droplet volume. In the typical case where the radius R is small compared to the length  $\ell_{\rm in} = (D_{\rm in}/|k_{\rm in}|)^{\frac{1}{2}}$  generated by the reaction-diffusion system, the concentration inside the droplet is  $c_*(r) \simeq c_{\rm in}^{(0)}$ , implying

$$J_{\rm in} \simeq \Gamma_{\rm in} V_{\rm d}$$
 (4.20)

Droplet material is thus transported toward the interface  $(J_{\rm in}>0)$  only in internally maintained droplets  $(\Gamma_{\rm in}>0)$ .

The integrated flux  $J_{\text{out}}$  outside the droplet interface can also be obtained in a quasi-static approximation. In contrast to the passive case discussed in section 2.5.2, the supersaturation  $\varepsilon =$  $(c_{\infty} - c_{\text{out}}^{(0)})/c_{\text{out}}^{(0)}$  far away from droplets is now created by chemical reactions. In the typical case where the dilute phase is large compared to the length scale  $\ell_{\text{out}} = (D_{\text{out}}/|k_{\text{out}}|)^{\frac{1}{2}}$ , the chemical reactions equilibrate far away from droplets and the composition thus reaches the value  $c_{\infty} = c_{\text{out}}^{(0)} + \Gamma_{\text{out}}/k_{\text{out}}$ , so  $s(c_{\infty}) = 0$ ; see figure 4.4(b). The associated supersaturation reads  $\varepsilon = \Gamma_{\rm out}/(k_{\rm out}c_{\rm out}^{(0)})$  and is thus positive if  $\Gamma_{\rm out}$  > 0 since the reaction is autoinhibitory outside droplets ( $k_{\text{out}} > 0$ ); see section 4.2.1. The resulting transport of droplet material can be quantified by the flux outside the droplet interface, which reads

<span id="page-29-0"></span>
$$J_{\rm out} \simeq 4\pi D_{\rm out} R c_{\rm out}^{(0)} \left(\frac{\ell_{\gamma}}{R} - \varepsilon\right)$$
 (4.21)

in the typical case  $R \ll \ell_{\rm out}$ . The first term in the bracket captures the effect of surface tension, which is typically small. Neglecting this term, we find that droplet material is transported toward the interface  $(J_{\rm out} < 0)$  if the dilute phase is supersaturated  $(\varepsilon > 0)$ , which is the case only in externally maintained droplets  $(\Gamma_{\rm out} > 0)$ .

The droplet growth rate following from combining equations (4.19)–(4.21) reads

$$\frac{dR}{dt} \simeq \frac{D_{\text{out}}c_{\text{out}}^{(0)}}{R(c_{\text{in}}^{(0)} - c_{\text{out}}^{(0)})} \left(\varepsilon - \frac{\ell_{\gamma}}{R} + \frac{R^{2}\Gamma_{\text{in}}}{3D_{\text{out}}c_{\text{out}}^{(0)}}\right) . (4.22)$$

The first term in the bracket describes droplet growth due to a supersaturated environment ( $\varepsilon > 0$ ) or shrinkage in undersaturated environments ( $\varepsilon < 0$ ). The second term, which is only relevant for small droplets, captures the reduction of growth due to surface tension  $\gamma$ . The last term describes the growth of the droplet due to production of droplet material inside if  $\Gamma_{\rm in} > 0$  or its shrinking when  $\Gamma_{\rm in} < 0$ . Note that equation (4.22) reduces to equation (2.53) if chemical reactions are absent ( $\Gamma_{\rm in} = 0$ ) and the supersaturation  $\varepsilon$  is imposed.

4.2.3. Single droplet in an infinite system. We begin by discussing the growth of a single droplet in an environment with constant supersaturation  $\varepsilon$ . This corresponds for instance to an infinite system where the supersaturation reaches its equilibrium value  $\varepsilon_{\rm eq} = \Gamma_{\rm out}/(k_{\rm out}c_{\rm out}^{(0)})$  far away from an isolated droplet. The stationary states of this system can be determined from equation (4.22) and correspond to radii R for which the bracket vanishes. The associated cubic equation in R has at most three solutions, which we now classify. If the chemical reactions are too strong, there are no physical solutions. In particular, if  $|\Gamma_{\rm in}| > \Gamma_{\rm in}^{\rm max}$  with

$$\Gamma_{\rm in}^{\rm max} = \frac{4c_{\rm out}^{(0)} D_{\rm out} |\varepsilon|^3}{9\ell_{\gamma}^2} , \qquad (4.23)$$

two solutions are complex while the third one is either negative (if  $\Gamma_{\rm in} < 0$ ) or smaller than the interface width (if  $\Gamma_{\rm in} > 0$ ), which is both unphysical. Consequently, stable droplets can only exist for moderate chemical reactions,  $|\Gamma_{\rm in}| < \Gamma_{\rm in}^{\rm max}$ . In this case, the polynomial equation has three real solutions. One of the solutions is always negative and thus unphysical, while the other two read

<span id="page-29-2"></span>
$$R^{(1)} \simeq \frac{\ell_{\gamma}}{\varepsilon} \,, \tag{4.24a}$$

$$R^{(2)} \simeq \left(\frac{3D_{\text{out}}\varepsilon c_{\text{out}}^{(0)}}{-\Gamma_{\text{in}}}\right)^{\frac{1}{2}} - \frac{\ell_{\gamma}}{2\varepsilon},$$
 (4.24b)

which is correct up to linear order in  $\ell_{\gamma}/R$ . The dynamics in the vicinity of these states follow from a linear stability analysis of equation (4.22), where the droplet radius is perturbed away from the stationary state and we determine whether the dynamics will bring the droplet back to its stationary state or not [76]. This gives us enough information to discuss the growth behavior of active droplets qualitatively.

<span id="page-29-1"></span>In the case of externally maintained droplets  $(\Gamma_{\rm in} < 0, \, \varepsilon > 0)$ , we have  $0 < R^{(1)} < R^{(2)}$ , since  $|\Gamma_{\rm in}| < \Gamma_{\rm in}^{\rm max}$ . Here, the radius  $R^{(1)}$  corresponds to an unstable state, while  $\mathbb{R}^{(2)}$  is stable, see figure 4.5. Droplets smaller than  $R^{(1)}$  dissolve and disappear, so  $R^{(1)}$  is a critical radius similar to the one discussed in section 2.5.2. Externally maintained droplets that are larger than the critical radius  $R^{(1)}$  grow until they reach the stable stationary state with radius  $R^{(2)}$ . This state is not present for passive droplets in an infinite system and must thus be a consequence of the chemical reactions. This can be seen by analyzing the two fluxes  $J_{\rm in}$  and  $J_{\rm out}$ , which must be equal in the stationary state. However,  $J_{\rm in}$  scales with the droplet volume, while  $J_{\text{out}}$  scales with its radius, see equation (4.21). Consequently, if the droplet radius exceeds  $R^{(2)}$ , the loss due to  $J_{\rm in}$  dominates and the droplet shrinks back to the stationary state. The

![](_page_30_Figure_2.jpeg)

<span id="page-30-0"></span>Figure 4.5. Growth rate dR/dt of a single droplet in an infinite system as a function of the droplet radius R. Shown are the values given by equation (4.22) for passive droplets (blue line;  $\Gamma_{\rm in} = 0$ ,  $\varepsilon = 0.1$ ), externally maintained droplets (orange line;  $\Gamma_{\rm in}/c_{\rm out}^{(0)} = -10^{-4}k_0$ ,  $\varepsilon = 0.1$ ), and internally maintained droplets (green line;  $\Gamma_{\rm in}/c_{\rm out}^{(0)} = 10^{-4}k_0$ ,  $\varepsilon = -0.1$ ) for  $c_{\rm in}^{(0)}/c_{\rm out}^{(0)} = 10$  where  $k_0 = D_{\rm out}/\ell_{\gamma}^2$ . Unstable stationary states are marked with open circles, while the only stable one is marked with a black disk.

chemical turnover inside the droplet thus stabilizes the stationary state. Note that the two stationary states given in equation (4.24) only exist if the chemical reactions are not too strong ( $|\Gamma_{\rm in}| < \Gamma_{\rm in}^{\rm max}$ ). In the limiting case  $\Gamma_{\rm in} = -\Gamma_{\rm in}^{\rm max}$  the situation is degenerated and the two stationary states are identical. The corresponding radius  $R_{\rm min}^{\rm ext} = (3\ell_\gamma)/(2\varepsilon)$  can be determined from equation (4.22) and corresponds to the smallest externally maintained droplet that can be stable.

In the case of internally maintained droplets  $(\Gamma_{\rm in} > 0, \varepsilon < 0)$ , the first solution given in equation (4.24) is negative and thus unphysical. The second solution is always positive, but unstable to Consequently,  $R^{(2)}$  is the critical perturbations. droplets size of internally maintained droplets, which can be significantly larger than critical sizes in externally maintained droplets. Nucleation is thus typically suppressed efficiently, but it can be promoted by catalytically active particles, which catalyze the production of droplet material at their surface [75, 76. Internally maintained droplets larger than the critical size grow up to the system size and there is no characteristic stable size. This is because such droplets grow quicker if they become larger and this autocatalytic growth only stops when the dilute phase is depleted of material P, which can only happen in a finite system [76].

4.2.4. Single droplet in a finite system. So far, we only considered systems that are large compared to the droplet size, so the supersaturation  $\varepsilon$  is effectively

constant. In contrast, in small systems a growing droplet can deplete the surrounding dilute phase significantly. In particular, the average concentration c of droplet material in the dilute phase evolves as

<span id="page-30-1"></span>
$$\frac{\mathrm{d}c}{\mathrm{d}t} = s(c) + \frac{J_{\text{out}}}{V - V_{\text{d}}}, \qquad (4.25)$$

where the first term on the right hand side originates from the chemical reactions in the dilute phase and the last term accounts for the diffusive flux at the interface of the droplet of volume  $V_{\rm d}$ . In large systems  $(V \gg V_{\rm d})$ , the last term is negligible and c relaxes to  $c_{\infty}$ , where chemical equilibrium is obeyed,  $s(c_{\infty}) = 0$ . At this point, the supersaturation  $\varepsilon =$  $(c-c_{
m out}^{(0)})/c_{
m out}^{(0)}$  attains its equilibrium value  $\varepsilon_{
m eq}=$  $\Gamma_{\rm out}/(k_{\rm out}c_{\rm out}^{(0)})$  and is thus independent of the droplet size, consistent with our assumptions in the previous subsection. In small systems, however, the last term in equation (4.25) is not negligible and  $\varepsilon$  depends on the droplet volume  $V_{\rm d}$ . For instance, in the case of externally maintained droplets, we have  $J_{\text{out}} < 0$  and the concentration c outside the droplet is thus lower than  $c_{\infty}$ . Consequently, the supersaturation is smaller for smaller systems and we would expect a reduced stationary droplet radius  $R^{(2)}$ , see equation (4.24b). Indeed, when we solve for the stationary states of equations (4.22) and (4.25), we find in the simple case of large diffusion and small surface tension that there is a stationary state with volume

$$V_* \simeq \frac{\Gamma_{\text{out}} V}{\Gamma_{\text{out}} - \Gamma_{\text{in}}} ,$$
 (4.26)

which is stable for externally maintained droplets and unstable for internally maintained ones. Consequently, the size of stable stationary droplets that are externally maintained depends on system size in small systems, while it is independent of the system size in large systems, see equation (4.24).

Similar to passive droplets, we find that active droplets also have a critical radius, below which they shrink and disappear. Consequently, droplets can only be nucleated spontaneously if a concentration fluctuation creates a large enough initial droplet. In externally maintained droplets, this mechanism is similar to passive droplets, where the nucleation barrier is higher for larger surface tension and smaller supersaturation. Conversely, the critical radius is generally larger for internally maintained droplets, but it becomes smaller for larger surface tension and smaller supersaturation. This is because only a large enough droplet can produce enough droplet material to balance the efflux into the dilute phase. This efflux is smaller for larger surface tension, so surface tension actually helps to nucleate internally maintained droplets.

Once droplets exceed their critical radius they grow spontaneously by absorbing droplet material from the surrounding (passive and externally maintained droplets) or by producing more droplet material (internally maintained droplets). In the first case, the droplet growth rate is larger for smaller droplets and higher supersaturation. However, the growth of externally maintained droplets comes to a stop at a finite size, at which the loss of droplet material due to the chemical reactions inside is balanced by its influx over the surface. Conversely, internally maintained droplets grow indefinitely in an infinite system, similar to passive droplets. However, in contrast to passive droplets, this growth accelerates because of its autocatalytic nature. Consequently, in the simple case of a binary fluid in an infinite system, only externally maintained droplets reach a finite droplet size, while both passive and internally maintained droplets grow to occupy the whole system.

# <span id="page-31-0"></span>4.3. Arrest of droplet coarsening: Suppression of Ostwald ripening

If many active droplets are present in the same system, their dynamics will be coupled because they share the material in the dilute phase. Intuitively, this coupling will be stronger if the droplets are closer For instance, for externally maintained droplets, the length scale over which they deplete the surrounding dilute phase is given by  $\ell_{\text{out}}$  and we thus expect that such droplets do not interact significantly when they are further apart. In particular, their stationary state radius  $R^{(2)}$  given in equation (4.24b) should not be affected much. Conversely, if externally maintained droplets are close, they compete strongly for the material produced in the solvent and might thus only reach a smaller size. This is in strong contrast to passive and internally maintained droplets that grow unbounded and will thus interact eventually, independent of the initial separation.

We study the interaction of multiple droplets in the simple case of sparse systems, where droplets are far apart from each other. In this case, the growth dynamics of the droplets are coupled because they all exchange material with the same dilute phase, but direct interactions between droplets can be neglected. Considering N droplets in a finite system of volume V, the supersaturation  $\varepsilon$  in the dilute phase evolves as

$$\frac{\mathrm{d}\varepsilon}{\mathrm{d}t} \simeq \Gamma_{\mathrm{out}} - k_{\mathrm{out}} c_{\mathrm{out}}^{(0)} \varepsilon + \frac{1}{V} \sum_{i=1}^{N} J_{\mathrm{out},i} , \qquad (4.27)$$

which follows by generalizing equation (4.25) to many droplets in the limit that V is large compared to the total volume of all droplets,  $V \gg \sum_i V_i$ . Here,  $R_i$  and  $V_i = \frac{4\pi}{3}R_i^3$  are the respective radii and volumes

of the droplets for  $i=1,\ldots,N$  and  $J_{{\rm out},i}$  is the flux of droplet material right outside the interface of the i-th droplet integrated over its surface, which follows from equation (4.21). For simplicity, we here consider the quasi-static case, where the concentration profile between droplets relaxes quickly compared to the growth of the droplets themselves, which is the typical situation [76]. In this case,  $\varepsilon$  will attain its stationary state value

<span id="page-31-1"></span>
$$\varepsilon_* = \frac{4\pi N \ell_{\gamma} D_{\text{out}} + \frac{\Gamma_{\text{out}} V}{c_{\text{out}}^{(0)}}}{k_{\text{out}} V + 4\pi D_{\text{out}} \sum_i R_i} . \tag{4.28}$$

Note that in the limit of a dilute system,  $V/N \gg \ell_{\rm out}^3$ , we recover the supersaturation at chemical equilibrium,  $\varepsilon_{\rm eq} = \Gamma_{\rm out}/(k_{\rm out}c_{\rm out}^{(0)})$ . Conversely, in passive or dense systems, the supersaturation is set by the equilibrium condition at the droplet surfaces,  $\varepsilon_* = \ell_\gamma/R_*$ , when all droplets have the same radius  $R_*$ .

The growth rate of each individual droplet is still described by equation (4.22), but with the supersaturation now given by equation (4.28). In the simple case of two droplets in the same system, the growth dynamics can be illustrated graphically. Figure 4.6 shows that passive and internally maintained droplets exhibit Ostwald ripening. Conversely, a new stable stationary state (black dot) can emerge for externally maintained droplets, where both droplets coexist at the same size. Figure 4.6 thus indicates that Ostwald ripening can be suppressed in active droplets.

To understand when Ostwald ripening is suppressed, we next analyze the state where all droplets have the same stationary radius  $R_*$ , which can be determined from the stationary state of equation (4.22). Similar to the discussion of isolated droplets above, we can then use a linear stability analysis to discuss the qualitative dynamics in the vicinity of this state. The detailed analysis given in Ref. [76] shows that there are two independent perturbation modes with qualitatively different dynamics: The fast mode associated with the total droplet volume describes the fact that all droplets quickly take up excess material from the dilute phase until the stationary state of the total droplet volume is reached. All other perturbation modes are associated with a slower exchange of material between droplets. These modes all have the same perturbation growth rate  $\omega$  given by

<span id="page-31-2"></span>
$$\omega = \frac{1}{c_{\rm in}^{(0)} - c_{\rm out}^{(0)}} \left( \frac{\ell_{\gamma} D_{\rm out} c_{\rm out}^{(0)}}{R_*^3} + \frac{2\Gamma_{\rm in}}{3} \right) . \tag{4.29}$$

If  $\omega$  is positive, the associated mode is unstable and material will flow from smaller to larger droplets, e.g., during Ostwald ripening. Conversely, negative  $\omega$  indicates stable states, where this coarsening is suppressed.

![](_page_32_Figure_2.jpeg)

<span id="page-32-1"></span>Figure 4.6. Behavior of two droplets as a function of their radii  $R_1$  and  $R_2$ , normalized with the interface width w. The black arrows indicate the temporal evolution of the state variables  $R_1$  and  $R_2$  following from equation (4.22), with  $\varepsilon$  given by equation (4.28). The blue and orange lines are the nullclines, which indicate where the growth rate of droplets 1 and 2 vanish, respectively. Their intersections are stable (disks) or unstable fixed points (open circles). (a) Passive droplets ( $\Gamma_{\rm in} = \Gamma_{\rm out} = 0$ ) (b) Externally maintained droplets ( $\Gamma_{\rm in} < 0$ ,  $\Gamma_{\rm out} > 0$ ) (c) Internally maintained droplets ( $\Gamma_{\rm in} > 0$ ,  $\Gamma_{\rm out} < 0$ ).

Passive systems ( $\Gamma_{\rm in}=0$ ) are always unstable ( $\omega>0$ ) and the droplets thus exhibit Ostwald ripening as discussed in section 2.5.3 and shown in figure 4.6(a). The redistribution of material between droplets is driven by surface tension, which causes a larger concentration of droplet material right outside of smaller droplets, see equation (2.45). Moreover, the associated perturbation rate  $\omega$  is smaller for larger mean droplet size, such that exchange of material will be slower between larger droplets. This implies that the coarsening of droplets slows down and only stops when a single droplet remains.

Internally maintained droplets ( $\Gamma_{\rm in} > 0$ ) are also unstable and the associated growth rate is larger than that of passive droplets. This is because the autocatalytic growth allows larger droplets to outcompete smaller ones, independent of surface tension effects. Internally maintained droplets are thus more unstable than passive ones, but they can be stabilised by particles that catalyse the production of droplet material within the droplets [75,76].

Multiple externally maintained droplets ( $\Gamma_{\rm in} < 0$ ) can coexist when  $\omega < 0$ . This is the case if their radius  $R_*$  exceeds the critical value

$$R_{\rm stab} = \left(\frac{3D_{\rm out}\ell_{\gamma}c_{\rm out}^{(0)}}{-2\Gamma_{\rm in}}\right)^{\frac{1}{3}},\qquad(4.30)$$

see equation (4.29). This expression reveals that the stability originates from a competition of the destabilising effect of surface tension, which tends to increase  $R_{\rm stab}$ , and the stabilising effects induced by the diffusive fluxes driven by the chemical reactions. This is similar to the isolated droplets that we discussed in the previous section: the influx toward

a droplet scales at most with the droplet radius, see equation (4.21), while the material loss scales with the volume. Consequently, multiple externally maintained droplets can stably coexist when the supersaturation in the dilute phase sustains the influx.

We showed that multiple active droplets interact because they compete for the same material from the dilute phase. The associated diffusive fluxes between droplets are caused by surface tension effects and chemical reactions. The flux due to surface tension is generally destabilising and causes the classical Ostwald ripening. Conversely, the flux due to chemical reactions can be either destabilising (for internally maintained droplets) or stabilising (for externally maintained droplets). If the stabilising contribution of the chemical reactions is stronger than the destabilising one due to surface tension, multiple active droplets can coexist in a stable state; see figure 4.6(b).

# <span id="page-32-0"></span>4.4. Spontaneous division of active droplets

So far, we analyzed the growth rate of active droplets assuming they maintain a spherical shape. We found that the droplet growth dynamics are often determined by a competition between surface tension effects and diffusive fluxes toward the droplet interface. Both effects depend on the droplet radius, or, more precisely, on the mean curvature of the droplet interface, which is given by  $R^{-1}$  for spherical droplets. In contrast, this mean curvature varies in non-spherical droplets, which suggests that the competition between the two effects plays a role in the shape dynamics of active droplets.

The dynamics of a non-spherical droplet are described by the same physical principles that we discussed so far. In particular, the interface velocity

![](_page_33_Figure_2.jpeg)

<span id="page-33-1"></span>Figure 4.7. Spontaneous division of externally maintained droplets. (a) Sequence of shapes of a dividing droplet at different times as indicated (reproduced from [79]) (b) Stationary droplet radii R as a function of the supersaturation  $\varepsilon$  for three different turnovers  $(\Gamma_{\rm in}/\Gamma_0=0,1,5;$  from left to right, with  $\Gamma_0=-10^{-5}c_{\rm in}^{(0)}D_{\rm out}\ell_{\gamma}^{-2}$ ) and  $c_{\rm in}^{(0)}/c_{\rm out}^{(0)}=10$ . Solid lines indicate stable stationary states, while dotted lines indicate states that are unstable with respect to size (black) or shape (orange). The radii R were determined from equation (4.22), assuming that droplets become unstable when  $R>R_{\rm div}$  given by equation (4.31). (c) Stability diagram of externally maintained droplets as a function of the supersaturation  $\varepsilon$  and the turnover  $\Gamma_{\rm in}$  normalized by  $\Gamma_0=c_{\rm out}^{(0)}D_{\rm out}\ell_{\gamma}^{-2}$ . Droplets dissolve and disappear (white region), are stable and attain a spherical shape (blue region), or undergo cycles of growth and division (orange region). The lines were determined analogously to (b) using the same parameters. (d) Schematics of deformed droplets and the surrounding concentration fields created by surface tension effects (left) and an external supersaturation (right). Material is transported from dark to light regions by diffusive fluxes (black arrows) perpendicular to the isocontours (black lines). Fluxes due to surface tension transport material from regions of high to low curvature, thus making droplets more circular (left). Conversely, the influx driven by an external supersaturation amplifies non-spherical shapes (right). The concentration fields have been obtained by solving the stationary diffusion equation (2.40). The boundary condition (2.45) at the surface of the deformed droplet accounts for surface tension effects (left) and a constant concentration  $c_{\infty}$  far away from the droplet represents the external supersaturation (right).

in its normal direction, given by equation (2.47), depends on the local net flux of droplet material, which follows from the reaction-diffusion equations in the bulk phases. Solving these equations numerically reveals that active droplets can show behaviours that are not present in passive droplets [79]. Figure 4.7a shows that externally maintained droplets can divide spontaneously, which can also happen multiple times [79]. A linear stability analysis with respect to the droplet shape reveals that the shape becomes unstable when the mean droplet radius R exceeds the critical value [79]

<span id="page-33-0"></span>
$$R_{\rm div} \simeq \frac{11\ell_{\gamma}}{\varepsilon} \,, \tag{4.31}$$

which is an approximation in the limit of large diffusive length scales ( $\ell_{\rm in}, \ell_{\rm out} \gg R$ ) and equal diffusivities inside and outside the droplet ( $D_{\rm in} = D_{\rm out}$ ). Figure 4.7b shows that there are typically three

different regimes of externally maintained droplets for a given turnover  $\Gamma_{in}$  of droplet material inside the droplet. If the supersaturation  $\varepsilon$  that is set by the chemical reactions in the dilute phase is too low, droplets cannot exists at all. For intermediate values of  $\varepsilon$ , droplets larger than the critical radius grow to their stationary size as discussed in section 4.2.2. For even larger  $\varepsilon$ , droplets at the stationary size become unstable  $(R_* > R_{\rm div})$  and growing droplets start dividing before they reach a stationary size. After division, these droplets can grow further and divide again. This proliferation continues until the system is depleted of droplet material and the supersaturation  $\varepsilon$ decreases to a point where the stationary state is stable with respect to shape changes. Whether externally maintained droplets divide or not depends on the balance between the availability of droplet material (supersaturation  $\varepsilon$ ) and the turnover inside the droplet (reaction flux  $\Gamma_{\rm in}$ ), see figure 4.7(c).

The instability of the shape of externally maintained droplets can be qualitatively explained by a competition of surface tension effects with diffusive fluxes [\[165\]](#page-43-23), similar to the multiple droplets discussed in the previous section. Because of surface tension, interface regions of larger mean curvature exhibit a larger concentration of droplet material right outside the interface, see equation [\(2.45\)](#page-9-3). This reduces the influx of droplet material and thus attenuates growth at regions of high curvature, stabilising the spherical shape, see figure [4.7\(](#page-33-1)d). Conversely, an externally driven material influx enhances the growth at regions of high curvature where the influx is larger, which is evident from the closer isocontour lines in figure [4.7\(](#page-33-1)d). This effect generally destabilises the spherical shape and has been described for phase separating systems by Mullins and Sekerka [\[166,](#page-43-24) [167\]](#page-43-25). In the presence of internal turnover Γin of active droplets, the degradation of building blocks inside may balance their influx leading to a roughly maintained droplet volume. Such a droplet that is fastest growing at its high curvature edges but of roughly maintained volumed may exhibit a narrowing of its waistline. However, whether the instability can dominate the stabilising surface tension effects and lead to a pinching off and thereby the division into two drops depends on the parameters, as shown in figure [4.7\(](#page-33-1)c).

In internally maintained droplets the diffusive fluxes are reversed. Consequently, both the surface tension effect and the closer isocontour lines enhance the efflux of material at regions of higher curvature, which thus stabilizes the spherical shape of internally maintained droplets. We thus expect that internally maintained droplets are more stable with respect to shape perturbations than passive droplets.

### 5. Active emulsions: relevance to biology with versatile applications

In this review we have discussed the physics of phase separation and the dynamics of droplets under conditions that deviate from passive systems. In particular, we discussed demixing systems in the presence of a concentration gradient of a component that affects phase separation and droplets in the presence of chemical reactions that are driven away from thermal equilibrium, see figure [5.1.](#page-35-0) In both systems the dynamics of phase separation is significantly affected. The systems favour non-equilibrium stationary states and exhibit novel phenomena that are not present in phase separating systems at thermal equilibrium. We therefore refer to this novel class of physical systems as active emulsions.

The difference to passive systems becomes apparent already at the level of a single droplet, which can exhibit a qualitatively different growth speed in case of active droplets, see figure [5.1\(](#page-35-0)a). For passive systems, the growth speed as a function of the radius of the droplet has an unstable fixed point. The associated critical radius increases over time and drives the coarsening in emulsions. Actively spending energy to create and maintain a regulator gradient that affects phase separation can reduce the critical radius in a positiondependent manner. Droplets at one end of the regulator gradient grow faster than droplets at the other end. Eventually, the larger droplets outcompete the smaller ones, much like in Ostwald ripening, but the positional bias by the gradient effectively positions the surviving droplets toward one end. Concomitantly, these larger droplets all grow to a similar size, i.e., the droplet size distribution narrows during the positing dynamics (figure [5.1\(](#page-35-0)b)). This narrowing is in stark contrast to the universal size distribution of passive droplets undergoing Ostwald ripening. As most droplets are positioned to one end, the ripening arrests for a certain time period, thus breaking the universal growth law in passive systems where droplet size increases proportional to t 1/3 (figure [5.1\(](#page-35-0)c)). Besides this positiondependent dissolution and growth process, droplets also drift along the gradient (figure [5.1\(](#page-35-0)d)). During this drift, droplets can deform (figure [5.1\(](#page-35-0)e)). In contrast, in passive systems, droplets maintain their spherical shape and do not drift. However, when all droplets are at one end of the gradient, the environment becomes locally homogeneous and the dynamics slowly returns to classical Ostwald ripening.

If the regulator concentration gradient is created by an inhomogeneous external potential, a phase separated system can favour novel equilibrium states. The condensed phase either sits at the minimum or the maximum of the external potential, i.e., the concentration profile describing the condensed phase is either correlated or anti-correlated with the regulator profile. The system can also undergo a discontinuous phase transition between these two states when the interactions between the molecules are changed. In the absence of an external potential there is no positional bias and each position of the condensed phase corresponds to the same free energy.

Droplet dynamics can also be affected by spending energy to drive chemical reactions that involve the droplet material away from equilibrium. In this case, single droplets can exhibit a stable stationary state at a finite size, see figure [5.1\(](#page-35-0)a). Consequently, all droplets larger than the critical size tend toward this stationary radius, leading to a suppression of the Ostwald ripening that would occur in passive systems. These dynamics leads to an infinitely sharp distribution in the absence of fluctuations (figure [5.1\(](#page-35-0)b)) with a mean droplet size that saturates at this stable radius (figure [5.1\(](#page-35-0)c)).

![](_page_35_Figure_2.jpeg)

<span id="page-35-0"></span>Figure 5.1. Overview of the novel behaviour and phenomena that occur in active emulsions. Curves in green correspond to droplets in a gradient of molecules which affect phase separation while blue curves indicate droplets in the presence of non-equilibrium chemical reactions. Results for passive systems are depicted as black lines. (a) Droplet growth speed and (b) droplet frequency as a function of droplet radius R. The (unstable) critical radius is indicated by an open red circle, while there can be a stable stationary radius in the case of non-equilibrium chemical reactions (shown as bold and red circle). (c) Mean droplet radius as a function of time t. The radius of passive droplets grows ∝ t 1/3 , while active emulsion break this scaling law. (d) Positioning of droplets to one boundary of the system (bottom) in the presence of a regulator gradient (top) by droplet drift and position-dependent dissolution and growth. (e) In the presence of a regulator gradient droplet can deform (top), while in the presence of non-equilibrium chemical reactions droplets can even undergo a shape instability and divide (bottom).

Chemical reactions can thus modify the dynamics of phase separation such that the universal broadening is replaced by an evolution to a non-equilibrium stationary state of a monodisperse, active emulsion. Moreover, in the presence of non-equilibrium chemical reactions, droplets can also undergo shape instabilities triggering the division of droplets, see figure [5.1\(](#page-35-0)e). In contrast, passive droplets only exhibit the reverse process of droplet fusion, which is driven by surface tension effects. In active droplets, this stabilising tendency of surface tension can be overcome by the influx of droplet material sustained by the nonequilibrium chemical reactions.

Demixing systems in the presence of external forces, like a maintained regulator gradient or nonequilibrium chemical reactions, share some inherent similarities. Both systems break the universal coarsening dynamics of Ostwald ripening and modify the stationary state of the system. While a regulator gradient causes a bias in the position of the single stationary droplet, the non-equilibrium chemical reactions can select a state composed of multiple droplets of equal size. The breaking of the universal dynamics occurs via additional fluxes that are absent in classical phase separation. These fluxes are generated by the dissipation of energy, either to assemble and maintain a concentration gradient that in turn interacts with the demixing components or to drive chemical reactions of the demixing components away from their equilibrium.

Active fluxes are ubiquitous in living systems to keep them away from thermal equilibrium. In fact, if such systems were to reach equilibrium, they would be non-living, passive matter. At the same time, it has been shown that liquid phase separated compartments are important for the spatial organisation inside a large variety of cells (see reference [\[87\]](#page-41-14) and references therein). Such compartments can organise biomolecules in space and time to control chemical reactions, which is an essential building block for biological function. However, how these compartments are controlled by cells is poorly understood. Studying the physics of phase separation in non-equilibrium environments is thus highly relevant for cell biology [\[88\]](#page-41-11).

Although several novel phenomena arising from active fluxes have been discovered in phase separating systems, many aspects have not been addressed, yet. For example, in order to realise an experimental system in which non-equilibrium reactions suppress Ostwald ripening or drive the division of droplets, a better understanding of the couplings of the chemical pathways to phase separation is necessary. To this end, one major challenge is to find a proper choice of chemicals. Promising candidates are synthetically designed reaction cycles including a fuel-driven reaction from a precursor component toward a building block capable to form liquidlike assemblies [\[151\]](#page-43-12). Specifically, what is the minimal system that can be realised experimentally that shows dividing droplets for example? If such experimental conditions were found, such systems could be used to set the droplet size in microfluidic devices in the context of chemical engineering [\[168\]](#page-43-26) or support the potential role of phase separated liquid-like compartments for the origin of life [\[42\]](#page-40-11).

Droplets can also carry information encoded in their chemical composition, i.e., a specific set of molecules dissolved inside. Controlling such droplets with non-equilibrium chemical reactions not only allows the change of the droplet size but also the information content. Such a system offers the opportunity to perform aqueous computing at larger-than-molecular scales [\[169,](#page-43-27) [170\]](#page-43-28). In addition, concentration gradients can be used to position these droplets. As droplets have reached their target position this chemical information can be released by droplet dissolution, which can be induced by modifying the interactions between the droplet material and the solvent. Such a liquid system could represent a first building block for aqueous computing, which allows to process chemical information in space.

Controlled active emulsions could also be used to physically seal or open junctions in microfluidic devices. The control over the droplet position also enables to modify the physical properties of target surfaces inside devices by wetting. All these tasks require a solid theoretical understanding of how the formation, position and composition of droplets can be controlled and how physical parameters should be chosen.

In summary, we have discussed a new class of physical systems which we refer to as active emulsions. These emulsions are relevant to cell biology. They may allow to develop novel applications in the field of chemical engineering or aqueous computing. Maybe, active emulsions could be relevant in the research of how life could have emerged from an inanimate mixture composed of set of simple chemically active molecules. However, the class of active emulsions also challenge our theoretical understanding of spatially heterogeneous systems driven far away from thermal equilibrium and can be used to refine existing theoretical concepts. In particular, active emulsions are characterised by non-equilibrium fluxes that maintain these system away from thermal equilibrium. The physics of phase separation in the presence of non-equilibrium chemical reactions pose several theoretical challenges and questions, such as the role of fluctuations, the couplings of diffusive and chemical fluxes, and what are the minimally required ingredients necessary for the phenomena discussed in this review.

### Acknowledgments

We would like to thank Omar Adame Arana, Giacomo Bartolucci, Jonathan Bauermann, Siheng Chen, Erwin Frey, Elisabeth Fischer-Friedrich, David Fronk, Lars Hubatsch, Jacqueline Janssen, Jan Kirschbaum, Samuel Kr¨uger, Matthias Merkel, Nirbhay Patil, Payam Payamyar, Orit Peleg, Wolfram P¨onisch, Rabea Seyboldt, and Jean David Wurtz, for helpful comments and discussions on our review. We thank Samuel Kr¨uger for proving the data for Fig. [3.1](#page-14-2) and Fig. [3.2.](#page-16-0) Finally, we would like to acknowledge Simon Alberti, Martin Z. Bazant, Edgar Boczek, Clifford P. Brangwynne, Andres Diaz, Titus Franzmann, Anatol Fritsch, Alf Honigmann, Anthony A. Hyman, Louise Jawerth, Jose Alberto Morin Lantero, Mark Leaver, Avinash Patel, Shambaditya Saha, Jeffrey B. Woodruff, and Oliver Wueseke for stimulating scientific discussions about active emulsions and droplet-like compartment inside cells. C.A.W. and D.Z. also thank the German Research Foundation (DFG) for financial support.

#### <span id="page-36-0"></span>Appendix A. Stability of the interfacial profile

The stability of the inhomogeneous solution cI(x) given in equation [\(2.28\)](#page-7-0) can be assessed by considering the change in free energy ∆F[c<sup>I</sup> , ] due to an infinitesimal perturbation (x). Using equation [\(2.30\)](#page-7-3), we have

$$\Delta F[c_{\rm I}, \epsilon] = \int d^3 \boldsymbol{r} \left[ \frac{b\epsilon^2}{2} \left( 3 \tanh^2 \left( \frac{x}{w} \right) - 1 \right) + \frac{\kappa}{2} \left( \partial_x \epsilon \right)^2 \right]$$
(A.1)

<span id="page-36-1"></span>.

The reference state  $c_{\rm I}(x)$  is stable if all perturbations increase the free energy, i.e., if  $\Delta F[c_{\rm I},\epsilon]>0$  for all permissible functions  $\epsilon(x)$ . Note that without chemical reactions the mass of the individual components is conserved, which implies that only those  $\epsilon(x)$  are permissible that obey the constraint  $\int \epsilon \, \mathrm{d}x = 0$ .

To see whether all perturbations lead to positive  $\Delta F$ , we determine the perturbation  $\epsilon_*(x)$  with the minimal  $\Delta F$ . If this value is positive, all other perturbations also increase the free energy and the base state  $c_{\rm I}(x)$  is stable. A necessary condition for  $\epsilon_*(x)$  is that it satisfies the Euler-Lagrange equations corresponding to equation (A.1). Defining the linear operator  $\mathcal{A}(\epsilon) = \delta \Delta F/\delta \epsilon$ ,

$$\mathcal{A}(\epsilon) = b\epsilon \left[ 3 \tanh^2 \left( \frac{x}{w} \right) - 1 \right] - \kappa \partial_x^2 \epsilon , \qquad (A.2)$$

the Euler-Lagrange equations can be expressed as

$$\mathcal{A}(\epsilon_*) = \tilde{\lambda} \ . \tag{A.3}$$

Here,  $\tilde{\lambda}$  is a Lagrange multiplier that ensures mass conservation in the case without chemical reactions, while  $\tilde{\lambda}=0$  in the case with chemical reactions. Using partial integration on equation (A.1), we also have

$$\Delta F[c_{\rm I}, \epsilon] = \frac{1}{2} \int d^3 \boldsymbol{r} \, \epsilon \, \mathcal{A}(\epsilon) ,$$
 (A.4)

where we neglected the boundary terms assuming that the perturbation vanishes at the boundary or the system exhibits periodic boundary conditions. To evaluate  $\Delta F$ , it is convenient to express  $\epsilon_*(x)$  in terms of the eigenfunctions  $\epsilon_n(x)$  of the operator  $\mathcal{A}$ . The associated eigenvalue problem  $\zeta_n \epsilon_n = \mathcal{A}(\epsilon_n)$  has already been considered in the context of Schrödinger's equation with a potential similar to the first term in equation (A.2) [171]. In particular, it has been shown that the discrete part of the spectrum consists of only two eigenvalues,  $\zeta_0 = 0$  and  $\zeta_1 = \frac{3}{2}b$ , while the continuous spectrum obeys  $\zeta \geq 2b$ . In the following, the sum symbol will denote both summation over the discrete and integration over the continuous part of the spectrum. The solution  $\epsilon_*(x)$  can then be expressed as

$$\epsilon_*(x) = \sum_{n=0}^{\infty} a_n \epsilon_n(x) , \qquad (A.5)$$

where  $a_n$  are the corresponding series coefficients, which have to obey  $\sum_{n=0}^{\infty} a_n \zeta_n = \tilde{\lambda}$ . Using this in equation (A.4), we find

$$\Delta F[c_{\rm I}, \epsilon_*] = \frac{A}{2} \sum_{n=1}^{\infty} \zeta_n \int dx \, a_n^2 \{\epsilon_n(x)\}^2 \ge 0 , \quad (A.6)$$

where A is the cross-sectional area  $A = \int dy dz$ . Equation (A.6) implies  $\Delta F > 0$  if any  $a_n \neq 0$  for  $n \geq 1$ , so the base state is stable with respect to these perturbations. In particular, the state  $c_{\rm I}$  would only be unstable if there are perturbations with  $a_0 \neq 0$  and  $a_n = 0$  for  $n \geq 1$ . Note that the term for n = 0 does not appear in equation (A.6) since the eigenvalue  $\zeta_0$  vanishes. The associated eigenfunction is  $\epsilon_0(x) = \partial_x c_{\rm I}(x)$ , which does not conserve the mass of the individual components since  $\int \epsilon_0(x) dx = 2(b/a)^{1/2}$ . Consequently, this mode is forbidden if chemical reactions are absent, so that all perturbations increase the free energy in this case. Conversely, with chemical reactions,  $a_0 \neq 0$  is allowed and this mode is marginal since it does not change the free energy,  $\Delta F(c_1, \epsilon_0) = 0$ .

<span id="page-37-1"></span>Taken together, we showed that the interfacial profile  $c_{\rm I}(x)$  given in equation (2.28) is stable in the case without chemical reactions. Chemical reactions introduce a marginal mode, which corresponds to a translation of the interface. However, for finite systems, the boundary conditions (2.27), and thus the interface profile  $c_{\rm I}(x)$ , are only approximate and all inhomogeneous states might be unstable in very small systems [44].

# <span id="page-37-2"></span><span id="page-37-0"></span>Appendix B. Entropy production of a system with phase separation and chemical reactions

To derive dynamical equations for a binary fluid exhibiting phase separation and chemical reactions, we here consider the associated entropy production. For a closed, isothermal system of constant volume, the entropy production is related to the change of free energy,  $\mathrm{d}S/\mathrm{d}t = -T^{-1}\mathrm{d}F/\mathrm{d}t$ . For simplicity, we here consider the free energy  $F[c_A, c_B] = \int \mathrm{d}^3 r \, f(c_A, c_B)$ , neglecting the contributions proportional to the gradients of the concentration fields. Hence,

$$\frac{\mathrm{d}F}{\mathrm{d}t} = \int \mathrm{d}^{3}r \left(\mu_{A}\partial_{t}c_{A} + \mu_{B}\partial_{t}c_{B}\right) \tag{B.1}$$

$$= -\int \mathrm{d}^{3}r \left[\mu_{A} \left(\nabla \cdot \boldsymbol{j}_{A} - s\right) + \mu_{B} \left(\nabla \cdot \boldsymbol{j}_{B} + s\right)\right]$$

$$= \int \mathrm{d}^{3}r \left[\boldsymbol{j}_{A} \cdot \nabla \mu_{A} + \boldsymbol{j}_{B} \cdot \nabla \mu_{B} + s \left(\mu_{A} - \mu_{B}\right)\right]$$
+ boundary terms,

where we have used  $\mu_A = \partial f/\partial c_A$ ,  $\mu_B = \partial f/\partial c_B$ , and the conservations laws  $\partial_t c_A = -\nabla \cdot \boldsymbol{j}_A + s$  and  $\partial_t c_B = -\nabla \cdot \boldsymbol{j}_B - s$ . Note that the boundary terms originating from partial integration can be neglected when appropriate boundary conditions are applied or an infinite system is considered.

<span id="page-37-3"></span>For each component i, the flux  $\mathbf{j}_i$  can be split into a convective part with velocity  $\mathbf{v}$  and an exchange current  $\mathbf{j}$ . As discussed in section 2.4, incompressibility and equal molecular volumes then imply  $\mathbf{j}_A = \mathbf{v}c_A + \mathbf{j}$  and  $\mathbf{j}_B = \mathbf{v}c_B - \mathbf{j}$ . Moreover, changes of the intensive

thermodynamic quantities are coupled, implying the Gibbs-Duhem relationship  $c_A d\mu_A + c_B d\mu_B = dp$ , where p is the pressure. Hence,

$$\frac{\mathrm{d}F}{\mathrm{d}t} = \int \mathrm{d}^3 r \left( \boldsymbol{j} \cdot \nabla \bar{\mu} + p \nabla \cdot \boldsymbol{v} + s \,\bar{\mu} \right) , \qquad (B.2)$$

where  $\bar{\mu} = \mu_A - \mu_B$  is the exchange chemical potential. In the case of equal molecular volumes of A and B, incompressibility implies  $\nabla \cdot \mathbf{v} = 0$  [140], leading to

$$\frac{\mathrm{d}S}{\mathrm{d}t} = \frac{1}{T} \int \mathrm{d}^3 r \left( -\boldsymbol{j} \cdot \nabla \bar{\mu} - s \,\bar{\mu} \right) . \tag{B.3}$$

This expression reveals that the thermodynamic fluxes  $\boldsymbol{j}$  and s are coupled to the thermodynamic forces  $\nabla \bar{\mu}$  and  $\bar{\mu}$ , respectively. Expressing the fluxes as linear functions of their forces, we obtain  $\boldsymbol{j} = -\Lambda \nabla \bar{\mu}$  and  $s = -\Lambda_r \bar{\mu}$ , where the Onsager coefficients  $\Lambda$  and  $\Lambda_r$  must be positive to obey the second law of thermodynamics  $(\mathrm{d}S/\mathrm{d}t \geq 0)$ . The entropy production only vanishes at equilibrium, where the equilibrium conditions  $\nabla \bar{\mu} = 0$  and  $\bar{\mu} = 0$  are obeyed and the fluxes vanish.

# <span id="page-38-0"></span>Appendix C. Thermodynamic constraints on chemical reaction rates

We consider a binary system consisting of particles A and B with a simple conversion reaction  $B \rightleftharpoons A$ . Assuming local equilibrium, the system is described by the concentrations  $c_A$  and  $c_B$  of the A and B-particles. Since the particles occupy all the space, both concentrations are connected via the relationship  $c_A = \nu^{-1} - c_B$ , where  $\nu$  is the molecular volume of both species. The concentration of A particles obeys

$$\partial_t c_A = s_{\rightarrow} - s_{\leftarrow} ,$$
 (C.1)

where  $s_{\rightarrow}$  and  $s_{\leftarrow}$  denote the respective forward and backward reaction flux. To derive the condition on the ratio of these fluxes given in equation (4.1), we here analyze the associated lattice model introduced in section 2.1.

We consider a system of M lattice sites and focus on the reactions occurring at the arbitrary lattice site n. The probabilities to find an A or B particle at this site are given by  $P(\boldsymbol{\sigma}_n,t)$  or  $P(\bar{\boldsymbol{\sigma}}_n,t)$ , respectively. Here, the configuration of all particles on the lattice where lattice site n is occupied by an A particle ( $\sigma_n = 1$ ) is denoted as  $\boldsymbol{\sigma}_n = \sigma_1, ..., \sigma_n = 1, ..., \sigma_M$ . Conversely,  $\bar{\boldsymbol{\sigma}}_n = \sigma_1, ..., \sigma_n = 0, ..., \sigma_M$ , is a configuration where the n-th site is occupied by B. These probability functions are related to the volume fraction  $\phi = \nu c_A$  of A particles and concentration fields by

$$\phi = \sum_{\Omega_n} P(\boldsymbol{\sigma}_n, t) = 1 - \sum_{\bar{\Omega}_n} P(\bar{\boldsymbol{\sigma}}_n, t) , \qquad (C.2)$$

where  $\Omega_n$  or  $\bar{\Omega}_n$  denote the set of all possible configurations with an A or B particle at lattice site n, respectively. The time evolution of the probabilities is captured by the master equation

<span id="page-38-5"></span>
$$\partial_t P(\boldsymbol{\sigma}_n, t) = -\partial_t P(\bar{\boldsymbol{\sigma}}_n, t)$$

$$= k_{-}^n (\bar{\boldsymbol{\sigma}}_n) P(\bar{\boldsymbol{\sigma}}_n, t) - k_{-}^n (\boldsymbol{\sigma}_n) P(\boldsymbol{\sigma}_n, t) ,$$
(C.3)

where  $k^n_{\to}(\bar{\sigma}_n)$  and  $k^n_{\leftarrow}(\sigma_n)$  denote the forward and backward rates, which generally depend on the configuration. The equations discussed so far also hold when the reaction is not in equilibrium.

When the chemical reactions are equilibrated, the probability distribution is time independent, leading to the condition of detailed balance:

<span id="page-38-1"></span>
$$k_{\rightarrow}^{n}(\bar{\boldsymbol{\sigma}}_{n})P^{\text{eq}}(\bar{\boldsymbol{\sigma}}_{n}) = k_{\leftarrow}^{n}(\boldsymbol{\sigma}_{n})P^{\text{eq}}(\boldsymbol{\sigma}_{n})$$
. (C.4)

Here, the equilibrium distribution to find a specific configuration,  $\sigma_1, ..., \sigma_M$ , is given as

$$P^{\text{eq}}(\sigma_1, ..., \sigma_M) = \frac{1}{Z} \exp\left(-\frac{H(\sigma_1, ..., \sigma_M)}{k_{\text{B}}T}\right) , \quad (\text{C.5})$$

with the Hamiltonian  $H(\sigma_1, ..., \sigma_M)$  defined in equation (2.2) and the partition function Z given by equation (2.1). Using equation (C.4), we have

<span id="page-38-2"></span>
$$\begin{split} \frac{k_{\rightarrow}^{n}(\bar{\boldsymbol{\sigma}}_{n})}{k_{\leftarrow}^{n}(\boldsymbol{\sigma}_{n})} &= \frac{P^{\mathrm{eq}}(\boldsymbol{\sigma}_{n})}{P^{\mathrm{eq}}(\bar{\boldsymbol{\sigma}}_{n})} \\ &= \exp\left(-\frac{H(\boldsymbol{\sigma}_{n}) - H(\bar{\boldsymbol{\sigma}}_{n})}{k_{\mathrm{B}}T}\right) \;. \quad \text{(C.6)} \end{split}$$

<span id="page-38-6"></span>For the considered case of a single reaction step and for short ranged interactions, the forward and backward rates do not depend on the full configuration  $\{\sigma\}$ . Instead, the rates solely depend on the particle configurations in the vicinity of site n, which is determined by the characteristic length scale of the interaction. In particular, using a mean field approximation, the rates solely depend on the local volume fraction  $\phi$ . In this case, the energy difference appearing in equation (C.6) simplifies to

<span id="page-38-3"></span>
$$H(\boldsymbol{\sigma}_n) - H(\bar{\boldsymbol{\sigma}}_n) = \frac{1}{M} \frac{\mathrm{d}E(\phi)}{\mathrm{d}\phi},$$
 (C.7)

where  $E(\phi)$  is the mean field energy given by equation (2.6), such that

$$\frac{dE(\phi)}{d\phi} = zM \left[ e_{AA}\phi + e_{AB}(1 - 2\phi) - e_{BB}(1 - \phi) \right].$$
(C.8)

Combining equations (C.6) and (C.7), we find that the rates solely depend on the local volume fraction  $\phi$ , i.e.,  $k_{\rightarrow}^{n}(\bar{\sigma}_{n}) = k_{\rightarrow}(\phi)$  and  $k_{\leftarrow}^{n}(\sigma_{n}) = k_{\leftarrow}(\phi)$ .

<span id="page-38-4"></span>We now return to the case where chemical reactions are not equilibrated. Taking the time

derivative of equation (C.2) and using equation (C.3), we write the time evolution of the composition as

$$\partial_t \phi = \sum_{\Omega_n} \left[ k_{\to}^n(\phi) P(\bar{\boldsymbol{\sigma}}_n, t) - k_{\leftarrow}^n(\phi) P(\boldsymbol{\sigma}_n, t) \right]$$
$$= k_{\to}(\phi) (1 - \phi) - k_{\leftarrow}(\phi) \phi , \qquad (C.9)$$

where we have used that the forward and backward rate solely depend on  $\phi$  within the mean field approximation. Comparing with equation (C.1), we can identify the forward and backward reaction flux as  $s_{\rightarrow} = k_{\rightarrow}(\phi) \left(\nu^{-1} - c_A\right)$  and  $s_{\leftarrow} = k_{\leftarrow}(\phi)c_A$ , since  $\phi = \nu c_A$ . Hence, the ratio of the reaction fluxes reads

$$\frac{s_{\rightarrow}}{s_{\leftarrow}} = \frac{k_{\rightarrow}(\phi)}{k_{\leftarrow}(\phi)} \frac{(1-\phi)}{\phi} = \exp\left(-\frac{\bar{\mu}}{k_{\rm B}T}\right). \quad (C.10)$$

where we defined

$$\bar{\mu} = z \left[ e_{AA}\phi + e_{AB}(1 - 2\phi) - e_{BB}(1 - \phi) \right] + k_{\rm B}T \ln \left( \frac{\phi}{1 - \phi} \right),$$
 (C.11)

which can be identified with the exchange chemical potential  $\bar{\mu} = \mu_A - \mu_B = \nu \frac{\partial f}{\partial \phi}$  associated with the free energy density  $f(\phi)$  given in equation (2.8). Note that equation (C.11) does not contain any gradient term since we here focused on the simple case of homogeneous mean field. However, equation (C.10) also holds for more general situations and is referred to as detailed balance of the rates [147].

### References

- <span id="page-39-0"></span> Syrbe A, Bauer W, Klostermeyer H. Polymer science concepts in dairy systems: an overview of milk protein and food hydrocolloid interaction. International Dairy Journal. 1998;8(3):179–193.
- <span id="page-39-1"></span>[2] Clerk-Maxwell J. On the dynamical evidence of the molecular constitution of bodies. Nature. 1875;11(279):357

  359
- <span id="page-39-21"></span>[3] Flory PJ. Thermodynamics of high polymer solutions. The Journal of chemical physics. 1942;10(1):51–61.
- <span id="page-39-2"></span>[4] Huggins ML. Some Properties of Solutions of Longchain Compounds. The Journal of Physical Chemistry. 1942;46(1):151–158.
- <span id="page-39-3"></span>[5] Ostwald W. Studien über die Bildung und Umwandlung fester Körper. Zeitschrift für physikalische Chemie. 1897;22(1):289–330.
- <span id="page-39-4"></span>[6] Lifshitz IM, Slyozov VV. The kinetics of precipitation from supersaturated solid solutions. Journal of Physics and Chemistry of Solids. 1961;19(1?2):35 – 50.
- <span id="page-39-22"></span>[7] Wagner C. Theorie der Alterung von Niederschlägen durch Umlösen (Ostwald-Reifung). Berichte der Bunsengesellschaft für physikalische Chemie. 1961;65(7):581–591.
- <span id="page-39-5"></span>[8] Bray AJ. Theory of phase-ordering kinetics. Advances in Physics. 1994;43(3):357–459.
- <span id="page-39-6"></span>[9] Cahn JW. Critical point wetting. The Journal of Chemical Physics. 1977;66(8):3667–3672.
- [10] Moldover M, Cahn JW. An interface phase transition: Complete to partial wetting. Science. 1980;207(4435):1073–1075.

- <span id="page-39-7"></span>[11] Pohl D, Goldburg W. Wetting transition in lutidine-water mixtures. Physical Review Letters. 1982;48(16):1111.
- <span id="page-39-8"></span>[12] Style RW, Sai T, Fanelli N, Ijavi M, Smith-Mannschott K, Xu Q, et al. Liquid-Liquid Phase Separation in an Elastic Network. Physical Review X. 2018;8(1):011028.
- <span id="page-39-9"></span>[13] Herminghaus S, Maass CC, Krüger C, Thutupalli S, Goehring L, Bahr C. Interfacial mechanisms in active emulsions. Soft Matter. 2014 jun;10(36):7008-7022. Available from: http://pubs.rsc.org/en/content/articlehtml/2014/sm/c4sm00550chttp://xlink.rsc.org/?DOI=C4SM00550C.
- [14] Izri Z, van der Linden MN, Michelin S, Dauchot O. Self-Propulsion of Pure Water Droplets by Spontaneous Marangoni-Stress-Driven Motion. Phys Rev Lett. 2014 dec;113(24):248302. Available from: http://link.aps.org/doi/10.1103/PhysRevLett.113.248302.
- <span id="page-39-24"></span><span id="page-39-20"></span>[15] Maass CC, Krüger C, Herminghaus S, Bahr C. Swimming droplets. Annual Review of Condensed Matter Physics. 2016;7:171–193.
- [16] Seemann R, Fleury JB, Maass CC. Self-propelled droplets. Eur Phys J Spec Top. 2016;225(11-12):2227-2240. Available from: http://link.springer.com/10.1140/epjst/e2016-60061-7.
- <span id="page-39-23"></span><span id="page-39-10"></span>[17] Jin C, Krüger C, Maass CC. Chemotaxis and autochemotaxis of self-propelling droplet swimmers. Proc Natl Acad Sci. 2017;114(20):5089-5094. Available from: http://www.ncbi.nlm.nih.gov/pubmed/28465433.
- <span id="page-39-11"></span>[18] Caschera F, Rasmussen S, Hanczyc MM. An Oil Droplet Division-Fusion Cycle. Chempluschem. 2013 jan;78(1):52-54. Available from: http://doi.wiley. com/10.1002/cplu.201200275.
- <span id="page-39-12"></span>[19] Sellier M, Nock V, Verdier C. Self-propelling, coalescing droplets. International Journal of Multiphase Flow. 2011;37(5):462–468.
- [20] Jehannin M, Charton S, Karpitschka S, Zemb T, Möhwald H, Riegler H. Periodic precipitation patterns during coalescence of reacting sessile droplets. Langmuir. 2015;31(42):11484–11490.
- [21] Cira NJ, Benusiglio A, Prakash M. Vapour-mediated sensing and motility in two-component droplets. Nature. 2015 Mar;519(7544):446–50.
- [22] Tan H, Diddens C, Lv P, Kuerten JGM, Zhang X, Lohse D. Evaporation-triggered microdroplet nucleation and the four life phases of an evaporating Ouzo drop. Proc Natl Acad Sci U S A. 2016 08:113(31):8642-7.
- <span id="page-39-13"></span>[23] Li Y, Lv P, Diddens C, Tan H, Wijshoff H, Versluis M, et al. Evaporation-Triggered Segregation of Sessile Binary Droplets. Phys Rev Lett. 2018 Jun;120(22):224501.
- <span id="page-39-14"></span>[24] Löwen H. Colloidal soft matter under external control. Journal of Physics: Condensed Matter. 2001;13(24):R415. Available from: http://stacks.iop.org/0953-8984/13/i=24/a=201.
- <span id="page-39-15"></span>[25] Lee KWD, Chan PK, Feng X. Morphology development and characterization of the phase-separated structure resulting from the thermal-induced phase separation phenomenon in polymer solutions under a temperature gradient. Chemical Engineering Science. 2004;59(7):1491 – 1504.
- <span id="page-39-16"></span>[26] Kokal SL, et al. Crude oil emulsions: A state-of-the-art review. SPE Production & facilities. 2005;20(01):5–13.
- <span id="page-39-17"></span>[27] Matsuyama H, Berghmans S, Lloyd DR. Formation of anisotropic membranes via thermally induced phase separation. Polymer. 1999;40(9):2289–2301.
- <span id="page-39-18"></span>[28] Matsuyama H, Yuasa M, Kitamura Y, Teramoto M, Lloyd DR. Structure control of anisotropic and asymmetric polypropylene membrane prepared by thermally induced phase separation. Journal of Membrane Science. 2000;179(1):91–100.
- <span id="page-39-19"></span>[29] Caneba GT, Soong DS. Polymer membrane formation

- through the thermal-inversion process. 1. Experimental study of membrane structure formation. Macromolecules. 1985;18(12):2538–2545.
- <span id="page-40-0"></span>[30] Caneba GT, Soong DS. Polymer membrane formation through the thermal-inversion process. 2. Mathematical modeling of membrane structure formation. Macromolecules. 1985;18(12):2545–2555.
- <span id="page-40-1"></span>[31] Lee CF, Brangwynne CP, Gharakhani J, Hyman AA, J¨ulicher F. Spatial Organization of the Cell Cytoplasm by Position-Dependent Phase Separation. Phys Rev Lett. 2013 Aug;111:088101.
- <span id="page-40-2"></span>[32] Weber CA, Lee CF, J¨ulicher F. Droplet ripening in concentration gradients. New Journal of Physics. 2017;19(5):053021. Available from: [http://stacks.](http://stacks.iop.org/1367-2630/19/i=5/a=053021) [iop.org/1367-2630/19/i=5/a=053021](http://stacks.iop.org/1367-2630/19/i=5/a=053021).
- <span id="page-40-3"></span>[33] Song H, Chen DL, Ismagilov RF. Reactions in droplets in microfluidic channels. Angewandte chemie international edition. 2006;45(44):7336–7356.
- <span id="page-40-4"></span>[34] Stroberg W, Schnell S. Do Cellular Condensates Accelerate Biochemical Reactions? Lessons from Microdroplet Chemistry. Biophys J. 2018 Jul;115(1):3– 8.
- <span id="page-40-5"></span>[35] Fallah-Araghi A, Meguellati K, Baret JC, Harrak AE, Mangeat T, Karplus M, et al. Enhanced Chemical Synthesis at Soft Interfaces: A Universal Reaction-Adsorption Mechanism in Microcompartments. Physical Review Letters. 2014 jan;112(2):28301. Available from: [http://link.aps.org/doi/10.1103/](http://link.aps.org/doi/10.1103/PhysRevLett.112.028301 https://link.aps.org/doi/10.1103/PhysRevLett.112.028301) [PhysRevLett.112.028301https://link.aps.org/doi/](http://link.aps.org/doi/10.1103/PhysRevLett.112.028301 https://link.aps.org/doi/10.1103/PhysRevLett.112.028301) [10.1103/PhysRevLett.112.028301](http://link.aps.org/doi/10.1103/PhysRevLett.112.028301 https://link.aps.org/doi/10.1103/PhysRevLett.112.028301).
- <span id="page-40-6"></span>[36] John K, B¨ar M, Thiele U. Self-propelled running droplets on solid substrates driven by chemical reactions. The European Physical Journal E: Soft Matter and Biological Physics. 2005;18(2):183–199.
- [37] Yabunaka S, Ohta T, Yoshinaga N. Self-propelled motion of a fluid droplet under chemical reaction. The Journal of chemical physics. 2012;136(7):074904.
- <span id="page-40-7"></span>[38] Seemann R, Fleury JB, Maass CC. Self-propelled droplets. The European Physical Journal Special Topics. 2016;225(11-12):2227–2240.
- <span id="page-40-8"></span>[39] Kuksenok O, Jasnow D, Yeomans J, Balazs AC. Periodic Droplet Formation in Chemically Patterned Microchannels. Phys Rev Lett. 2003 Sep;91:108303. Available from: [https://link.aps.org/doi/10.1103/](https://link.aps.org/doi/10.1103/PhysRevLett.91.108303) [PhysRevLett.91.108303](https://link.aps.org/doi/10.1103/PhysRevLett.91.108303).
- <span id="page-40-9"></span>[40] Delgado J, Li N, Leda M, Gonz´alez-Ochoa HO, Fraden S, Epstein IR. Coupled oscillations in a 1D emulsion of Belousov–Zhabotinsky droplets. Soft Matter. 2011;7(7):3155–3167.
- <span id="page-40-10"></span>[41] Vanag VK, Epstein IR. Excitatory and inhibitory coupling in a one-dimensional array of Belousov-Zhabotinsky micro-oscillators: Theory. Physical Review E. 2011;84(6):066209.
- <span id="page-40-11"></span>[42] Vieregg JR, Tang TD. Polynucleotides in cellular mimics: Coacervates and lipid vesicles. Current Opinion in Colloid & Interface Science. 2016;26:50–57.
- <span id="page-40-12"></span>[43] Drobot B, Iglesias-Artola JM, Le Vay K, Mayr V, Kar M, Kresying M, et al. Compartmentalized RNA catalysis in membrane-free coacervate protocells. Nature Communications. 2018;9:3643.
- <span id="page-40-13"></span>[44] Krapivsky PL, Redner S, Ben-Naim E. A Kinetic View of Statistical Physics. Cambridge University Press; 2010. Available from: [http://books.google.co.uk/](http://books.google.co.uk/books?id=cc3pApnX3kYC) [books?id=cc3pApnX3kYC](http://books.google.co.uk/books?id=cc3pApnX3kYC).
- <span id="page-40-14"></span>[45] Puri S, Frisch H. Segregation dynamics of binary mixtures with simple chemical reactions. J Phys A. 1994 00;27:6027–6038. Available from: [http://iopscience.](http://iopscience.iop.org/0305-4470/27/18/013) [iop.org/0305-4470/27/18/013](http://iopscience.iop.org/0305-4470/27/18/013).
- <span id="page-40-17"></span>[46] Glotzer SC, Stauffer D, Jan N. Monte Carlo simulations of phase separation in chemically reactive binary

- mixtures. Phys Rev Lett. 1994 00;72(26):4109–4112. Available from: [http://prl.aps.org/abstract/PRL/](http://prl.aps.org/abstract/PRL/v72/i26/p4109_1) [v72/i26/p4109\\_1](http://prl.aps.org/abstract/PRL/v72/i26/p4109_1).
- <span id="page-40-22"></span>[47] Glotzer SC, Coniglio A. Self-consistent solution of phase separation with competing interactions. Phys Rev E. 1994 00;50(5):4241–4244. Available from: [http://pre.](http://pre.aps.org/abstract/PRE/v50/i5/p4241_1) [aps.org/abstract/PRE/v50/i5/p4241\\_1](http://pre.aps.org/abstract/PRE/v50/i5/p4241_1).
- [48] Glotzer SC, Di Marzio EA, Muthukumar M. Reactioncontrolled morphology of phase-separating mixtures. Phys Rev Lett. 1995 00;74(11):2034–2037. Available from: [http://prl.aps.org/abstract/PRL/v74/](http://prl.aps.org/abstract/PRL/v74/i11/p2034_1) [i11/p2034\\_1](http://prl.aps.org/abstract/PRL/v74/i11/p2034_1).
- [49] Glotzer SC, Stauffer D, Jan N. Glotzer, Stauffer, and Jan Reply. Phys Rev Lett. 1995 00;75(8):1675. Available from: [http://prl.aps.org/abstract/PRL/](http://prl.aps.org/abstract/PRL/v75/i8/p1675_1) [v75/i8/p1675\\_1](http://prl.aps.org/abstract/PRL/v75/i8/p1675_1).
- [50] Verdasca J, Borckmans P, Dewel G. Chemically frozen phase separation in an adsorbed layer. Phys Rev E. 1995 00;52(5):R4616–R4619. Available from: [http://apps.webofknowledge.com/](http://apps.webofknowledge.com/InboundService.do?SID=T1DGJ4Ad5Fomi7cfma3&product=WOS&UT=A1995TG33600007&SrcApp=Papers&DestFail=http%3A%2F%2Fwww.webofknowledge.com&Init=Yes&action=retrieve&Func=Frame&customersID=mekentosj&SrcAuth=mekentosj&IsProductCode=Yes&mode=FullRecord) [InboundService.do?SID=T1DGJ4Ad5Fomi7cfma3&](http://apps.webofknowledge.com/InboundService.do?SID=T1DGJ4Ad5Fomi7cfma3&product=WOS&UT=A1995TG33600007&SrcApp=Papers&DestFail=http%3A%2F%2Fwww.webofknowledge.com&Init=Yes&action=retrieve&Func=Frame&customersID=mekentosj&SrcAuth=mekentosj&IsProductCode=Yes&mode=FullRecord) [product=WOS&UT=A1995TG33600007&SrcApp=Papers&](http://apps.webofknowledge.com/InboundService.do?SID=T1DGJ4Ad5Fomi7cfma3&product=WOS&UT=A1995TG33600007&SrcApp=Papers&DestFail=http%3A%2F%2Fwww.webofknowledge.com&Init=Yes&action=retrieve&Func=Frame&customersID=mekentosj&SrcAuth=mekentosj&IsProductCode=Yes&mode=FullRecord) [DestFail=http%3A%2F%2Fwww.webofknowledge.com&](http://apps.webofknowledge.com/InboundService.do?SID=T1DGJ4Ad5Fomi7cfma3&product=WOS&UT=A1995TG33600007&SrcApp=Papers&DestFail=http%3A%2F%2Fwww.webofknowledge.com&Init=Yes&action=retrieve&Func=Frame&customersID=mekentosj&SrcAuth=mekentosj&IsProductCode=Yes&mode=FullRecord) [Init=Yes&action=retrieve&Func=Frame&customersID=](http://apps.webofknowledge.com/InboundService.do?SID=T1DGJ4Ad5Fomi7cfma3&product=WOS&UT=A1995TG33600007&SrcApp=Papers&DestFail=http%3A%2F%2Fwww.webofknowledge.com&Init=Yes&action=retrieve&Func=Frame&customersID=mekentosj&SrcAuth=mekentosj&IsProductCode=Yes&mode=FullRecord) [mekentosj&SrcAuth=mekentosj&IsProductCode=Yes&](http://apps.webofknowledge.com/InboundService.do?SID=T1DGJ4Ad5Fomi7cfma3&product=WOS&UT=A1995TG33600007&SrcApp=Papers&DestFail=http%3A%2F%2Fwww.webofknowledge.com&Init=Yes&action=retrieve&Func=Frame&customersID=mekentosj&SrcAuth=mekentosj&IsProductCode=Yes&mode=FullRecord) [mode=FullRecord](http://apps.webofknowledge.com/InboundService.do?SID=T1DGJ4Ad5Fomi7cfma3&product=WOS&UT=A1995TG33600007&SrcApp=Papers&DestFail=http%3A%2F%2Fwww.webofknowledge.com&Init=Yes&action=retrieve&Func=Frame&customersID=mekentosj&SrcAuth=mekentosj&IsProductCode=Yes&mode=FullRecord).
- <span id="page-40-18"></span>[51] Christensen JJ, Elder K, Fogedby HC. Phase segregation dynamics of a chemically reactive binary mixture. Phys Rev E. 1996 00;54(3):R2212–R2215. Available from: [http://pre.aps.org/abstract/PRE/v54/i3/pR2212\\_1](http://pre.aps.org/abstract/PRE/v54/i3/pR2212_1).
- <span id="page-40-19"></span>[52] Toxvaerd S. Molecular dynamics simulations of phase separation in chemically reactive binary mixtures. Phys Rev E. 1996 00;53(4):3710–3716. Available from: [http:](http://pre.aps.org/abstract/PRE/v53/i4/p3710_1) [//pre.aps.org/abstract/PRE/v53/i4/p3710\\_1](http://pre.aps.org/abstract/PRE/v53/i4/p3710_1).
- <span id="page-40-20"></span>[53] Motoyama M. Morphology of Binary Mixtures Which Undergo Phase Separation during Chemical Reactions. J Phys Soc Jpn. 1996 00;65(7):1894–1897. Available from: [http://www.scopus.com/inward/record.url?](http://www.scopus.com/inward/record.url?partnerID=yv4JPVwI&eid=2-s2.0-0030508032&md5=a77bd1fc1518a4204eeefedbbdb27b6a) [partnerID=yv4JPVwI&eid=2-s2.0-0030508032&md5=](http://www.scopus.com/inward/record.url?partnerID=yv4JPVwI&eid=2-s2.0-0030508032&md5=a77bd1fc1518a4204eeefedbbdb27b6a) [a77bd1fc1518a4204eeefedbbdb27b6a](http://www.scopus.com/inward/record.url?partnerID=yv4JPVwI&eid=2-s2.0-0030508032&md5=a77bd1fc1518a4204eeefedbbdb27b6a).
- <span id="page-40-21"></span>[54] Motoyama M, Ohta T. Morphology of Phase-Separating Binary Mixtures with Chemical Reaction. J Phys Soc Jpn. 1997 00;66(9):2715–2725. Available from: [http://www.scopus.com/inward/record.](http://www.scopus.com/inward/record.url?partnerID=yv4JPVwI&eid=2-s2.0-0031480095&md5=05df460f4fb86d8024dfb60c2de2b9ca) [url?partnerID=yv4JPVwI&eid=2-s2.0-0031480095&](http://www.scopus.com/inward/record.url?partnerID=yv4JPVwI&eid=2-s2.0-0031480095&md5=05df460f4fb86d8024dfb60c2de2b9ca) [md5=05df460f4fb86d8024dfb60c2de2b9ca](http://www.scopus.com/inward/record.url?partnerID=yv4JPVwI&eid=2-s2.0-0031480095&md5=05df460f4fb86d8024dfb60c2de2b9ca).
- [55] Huo Y, Zhang H, Yang Y. Effects of reversible chemical reaction on morphology and domain growth of phase separating binary mixtures with viscosity difference. Macromolecular theory and simulations. 2004;13(3):280–289.
- [56] Travasso RD, Kuksenok O, Balazs AC. Harnessing light to create defect-free, hierarchically structured polymeric materials. Langmuir. 2005;21(24):10912–10915.
- [57] Kuksenok O, Travasso RDM, Balazs AC. Dynamics of ternary mixtures with photosensitive chemical reactions: creating three-dimensionally ordered blends. Phys Rev E. 2006 Jul;74(1 Pt 1):011502.
- <span id="page-40-15"></span>[58] Li H, Liu H, Lu ZY, Wang Q, Sun CC. The effect of viscosity on the phase separation dynamics of binary immiscible mixture coupled with reversible reaction. International Journal of Modern Physics C. 2010 00;21(12):1479–1488. Available from: [http://www.scopus.com/inward/record.url?](http://www.scopus.com/inward/record.url?partnerID=yv4JPVwI&eid=2-s2.0-78650720041&md5=2a9c3be451cf13e8a1fb7e993ec9e82c) [partnerID=yv4JPVwI&eid=2-s2.0-78650720041&md5=](http://www.scopus.com/inward/record.url?partnerID=yv4JPVwI&eid=2-s2.0-78650720041&md5=2a9c3be451cf13e8a1fb7e993ec9e82c) [2a9c3be451cf13e8a1fb7e993ec9e82c](http://www.scopus.com/inward/record.url?partnerID=yv4JPVwI&eid=2-s2.0-78650720041&md5=2a9c3be451cf13e8a1fb7e993ec9e82c).
- <span id="page-40-16"></span>[59] Harada A, Tran-Cong Q. Experimental verification of a scaling law for phase separation kinetics of reacting polymer mixtures. Macromolecules. 1996;29(13):4801– 4803.

- <span id="page-41-20"></span>[60] Tran-Cong Q, Harada A. Reaction-induced ordering phenomena in binary polymer mixtures. Phys Rev Lett. 1996 00;76:1162–1165. Available from: [http:](http://link.aps.org/doi/10.1103/PhysRevLett.76.1162) [//link.aps.org/doi/10.1103/PhysRevLett.76.1162](http://link.aps.org/doi/10.1103/PhysRevLett.76.1162).
- [61] Tran-Cong Q, Ohta T, Urakawa O. Soft-mode suppression in the phase separation of binary polymer mixtures driven by a reversible chemical reaction. Physical Review E. 1997;56(1):R59.
- [62] Ohta T, Urakawa O, Tran-Cong Q. Phase separation of binary polymer blends driven by photoisomerization: An example for a wavelength-selection process in polymers. Macromolecules. 1998;31(20):6845–6854.
- [63] Tran-Cong Q, Kawai J, Endoh K. Modes selection in polymer mixtures undergoing phase separation by photochemical reactions. Chaos. 1999 00;9(2):298–307. Available from: [http://chaos.aip.org/resource/1/](http://chaos.aip.org/resource/1/chaoeh/v9/i2/p298_s1) [chaoeh/v9/i2/p298\\_s1](http://chaos.aip.org/resource/1/chaoeh/v9/i2/p298_s1).
- [64] Tran-Cong Q, Kawai J, Nishikawa Y, Jinnai H. Phase separation with multiple length scales in polymer mixtures induced by autocatalytic reactions. Phys Rev E. 1999 00;60(2 Pt A):R1150–3. Available from: [http:](http://pre.aps.org/abstract/PRE/v60/i2/pR1150_1) [//pre.aps.org/abstract/PRE/v60/i2/pR1150\\_1](http://pre.aps.org/abstract/PRE/v60/i2/pR1150_1).
- [65] Sutton D, Stanford J, Ryan A. Reaction-Induced Phase-Separation in Polyoxyethylene/Polystyrene Blends. II. Structure Development. Journal of Macromolecular Science, Part B. 2004;43(1):233–251.
- <span id="page-41-0"></span>[66] Tran-Cong-Miyata Q, Nakanishi H. Phase separation of polymer mixtures driven by photochemical reactions: current status and perspectives. Polymer International. 2017;66(2):213–222.
- <span id="page-41-1"></span>[67] Tanaka H, Suzuki T, Hayashi T, Nishi T. New type of pattern formation in polymer mixtures caused by competition between phase separation and chemical reaction. Macromolecules. 1992;25(17):4453–4456.
- [68] Inoue T. Reaction-induced phase decomposition in polymer blends. Progress in Polymer Science. 1995;20(1):119–153.
- [69] Williams RJJ, Rozenberg BA, Pascault JP. In: Reactioninduced phase separation in modified thermosetting polymers. Berlin, Heidelberg: Springer Berlin Heidelberg; 1997. p. 95–156. Available from: [https://doi.](https://doi.org/10.1007/3-540-61218-1_7) [org/10.1007/3-540-61218-1\\_7](https://doi.org/10.1007/3-540-61218-1_7).
- [70] Chan PK, Rey AD. Polymerization-induced phase separation. 1. Droplet size selection mechanism. Macromolecules. 1996;29(27):8934–8941.
- [71] Chan PK, Rey AD. Polymerization-induced phase separation. 2. Morphological analysis. Macromolecules. 1997;30(7):2135–2143.
- [72] Girard-Reydet E, Sautereau H, Pascault JP, Keates P, Navard P, Thollet G, et al. Reaction-induced phase separation mechanisms in modified thermosets. Polymer. 1998;39(11):2269–2279.
- [73] Kataoka K, Urakawa O, Nishioka H, Tran-Cong Q. Directional phase separation of binary polymer blends driven by photo-cross-linking with linearly polarized light. Macromolecules. 1998;31(25):8809–8816.
- <span id="page-41-2"></span>[74] Locatelli A, Mentes TO, Aballe L, Mikhailov A, Kiskinova M. Formation of regular surface-supported mesostructures with periodicity controlled by chemical reaction rate. J Phys Chem B. 2006 Oct;110(39):19108– 11.
- <span id="page-41-3"></span>[75] Zwicker D, Decker M, Jaensch S, Hyman AA, J¨ulicher F. Centrosomes are autocatalytic droplets of pericentriolar material organized by centrioles. Proc Natl Acad Sci USA. 2014;111(26):E2636–45.
- <span id="page-41-21"></span>[76] Zwicker D, Hyman AA, J¨ulicher F. Suppression of Ostwald ripening in Active Emulsions. Phys Rev E. 2015;92:012317.
- <span id="page-41-4"></span>[77] Wurtz JD, Lee CF. Chemical-Reaction-Controlled Phase Separated Drops: Formation, Size Selection, and Coars-

- ening. Physical Review Letters. 2018;120(7):078102.
- <span id="page-41-5"></span>[78] Wurtz JD, Lee CF. Stress granule formation via ATP depletion-triggered phase separation. New J Phys. 2018;20:045008.
- <span id="page-41-6"></span>[79] Zwicker D, Seyboldt R, Weber CA, Hyman AA, J¨ulicher F. Growth and division of active droplets provides a model for protocells. Nat Phys. 2017;13:408–413.
- <span id="page-41-7"></span>[80] Tena-Solsona M, Rieß B, Gr¨otsch RK, L¨ohrer FC, Wanzke C, K¨asdorf B, et al. Non-equilibrium dissipative supramolecular materials with a tunable lifetime. Nature communications. 2017;8:15895.
- <span id="page-41-8"></span>[81] Tena-Solsona M, Wanzke B Caren Rieß, Bausch AR, Boekhoven J. Self-selection of dissipative assemblies driven by primitive chemical reaction networks. Nature communications. 2018;9:2044.
- <span id="page-41-9"></span>[82] Ernster L, Schatz G. Mitochondria: a historical review. J Cell Biol. 1981;91(3):227s–255s.
- <span id="page-41-10"></span>[83] Brangwynne CP. Soft active aggregates: mechanics, dynamics and self-assembly of liquid-like intracellular protein bodies. Soft Matter. 2011;7(7):3052–3059.
- [84] Hyman AA, Brangwynne C. Beyond Stereospecificity: Liquids and Mesoscale Organization of Cytoplasm. Dev Cell. 2011 00;21(1):14–16. Available from: [http://eutils.ncbi.nlm.nih.gov/entrez/eutils/](http://eutils.ncbi.nlm.nih.gov/entrez/eutils/elink.fcgi?dbfrom=pubmed&id=21763600&retmode=ref&cmd=prlinks) [elink.fcgi?dbfrom=pubmed&id=21763600&retmode=](http://eutils.ncbi.nlm.nih.gov/entrez/eutils/elink.fcgi?dbfrom=pubmed&id=21763600&retmode=ref&cmd=prlinks) [ref&cmd=prlinks](http://eutils.ncbi.nlm.nih.gov/entrez/eutils/elink.fcgi?dbfrom=pubmed&id=21763600&retmode=ref&cmd=prlinks).
- [85] Hyman AA, Weber CA, J¨ulicher F. Liquid-liquid phase separation in biology. Annual review of cell and developmental biology. 2014;30:39–58.
- [86] Brangwynne CP, Tompa P, Pappu RV. Polymer physics of intracellular phase transitions. Nature Physics. 2015;11(11):899–904.
- <span id="page-41-14"></span>[87] Banani SF, Lee HO, Hyman AA, Rosen MK. Biomolecular condensates: organizers of cellular biochemistry. Nature Reviews Molecular Cell Biology. 2017;18(5):285– 298.
- <span id="page-41-11"></span>[88] Berry J, Brangwynne CP, Haataja M. Physical principles of intracellular organization via active and passive phase transitions. Reports on Progress in Physics. 2018;81(4):046601. Available from: [http://stacks.](http://stacks.iop.org/0034-4885/81/i=4/a=046601) [iop.org/0034-4885/81/i=4/a=046601](http://stacks.iop.org/0034-4885/81/i=4/a=046601).
- <span id="page-41-12"></span>[89] Sear RP. Dishevelled: a protein that functions in living cells by phase separating. Soft Matter. 2007;3(6):680– 684. Available from: [http://dx.doi.org/10.1039/](http://dx.doi.org/10.1039/B618126K) [B618126K](http://dx.doi.org/10.1039/B618126K).
- <span id="page-41-13"></span>[90] Brangwynne CP, Eckmann CR, Courson DS, Rybarska A, Hoege C, Gharakhani J, et al. Germline P Granules Are Liquid Droplets That Localize by Controlled Dissolution/Condensation. Science. 2009;324(5935):1729–1732.
- <span id="page-41-15"></span>[91] Woodruff JB, Hyman AA, Boke E. Organization and Function of Non-dynamic Biomolecular Condensates. Trends Biochem Sci. 2018 Feb;43(2):81–94.
- <span id="page-41-16"></span>[92] Boeynaems S, Alberti S, Fawzi NL, Mittag T, Polymenidou M, Rousseau F, et al. Protein Phase Separation: A New Phase in Cell Biology. Trends Cell Biol. 2018 Jun;28(6):420–435.
- <span id="page-41-17"></span>[93] Saha S, Weber CA, Nousch M, Adame-Arana O, Hoege C, Hein MY, et al. Polar Positioning of Phase-Separated Liquid Compartments in Cells Regulated by an mRNA Competition Mechanism. Cell. 2016;166(6):1572–1584.
- <span id="page-41-18"></span>[94] Boehning M, Dugast-Darzacq C, Rankovic M, Hansen AS, Yu T, Marie-Nelly H, et al. RNA polymerase II clustering through carboxy-terminal domain phase separation. Nat Struct Mol Biol. 2018 Sep;25(9):833– 840.
- <span id="page-41-19"></span>[95] Lu H, Yu D, Hansen AS, Ganguly S, Liu R, Heckert A, et al. Phase-separation mechanism for C-terminal hyperphosphorylation of RNA polymerase II. Nature. 2018 May;.

- <span id="page-42-0"></span>[96] Woodruff JB, Gomes BF, Widlund PO, Mahamid J, Honigmann A, Hyman AA. The centrosome is a selective condensate that nucleates microtubules by concentrating tubulin. Cell. 2017;169(6):1066–1077.
- <span id="page-42-1"></span>[97] Brangwynne CP, Mitchison TJ, Hyman AA. Active liquidlike behavior of nucleoli determines their size and shape in Xenopus laevis oocytes. Proceedings of the National Academy of Sciences. 2011;108(11):4334–4339.
- <span id="page-42-2"></span>[98] Feric M, Vaidya N, Harmon TS, Mitrea DM, Zhu L, Richardson TM, et al. Coexisting liquid phases underlie nucleolar subcompartments. Cell. 2016;165(7):1686– 1697.
- <span id="page-42-3"></span>[99] Sear RP, Cuesta JA. Instabilities in Complex Mixtures with a Large Number of Components. Physical Review Letters. 2003 dec;91(24):245701. Available from: [https://link.aps.org/doi/10.1103/](https://link.aps.org/doi/10.1103/PhysRevLett.91.245701) [PhysRevLett.91.245701](https://link.aps.org/doi/10.1103/PhysRevLett.91.245701).
- [100] Jacobs WM, Frenkel D. Phase Transitions in Biological Systems with Many Components. Biophysical Journal. 2017 feb;112(4):683–691. Available from: [http://www.](http://www.cell.com/article/S0006349516343363/fulltext) [cell.com/article/S0006349516343363/fulltext](http://www.cell.com/article/S0006349516343363/fulltext).
- [101] Ditlev JA, Case LB, Rosen MK. Who's in and Who's Out-Compositional Control of Biomolecular Condensates. J Mol Biol. 2018 Aug;.
- <span id="page-42-4"></span>[102] Mao S, Kuldinow D, Haataja MP, Kosmrlj A. Phase behavior and morphology of multicomponent liquid mixtures. arXiv preprint. 2018;.
- <span id="page-42-5"></span>[103] Cates ME, Tjhung E. Theories of binary fluid mixtures: from phase-separation kinetics to active emulsions. Journal of Fluid Mechanics. 2018;836.
- <span id="page-42-6"></span>[104] Balian R. From microphysics to macrophysics: methods and applications of statistical physics. vol. 1. Springer Science & Business Media; 2007.
- <span id="page-42-7"></span>[105] Frenkel D. Why colloidal systems can be described by statistical mechanics: some not very original comments on the Gibbs paradox. Molecular Physics. 2014;112(17):2325–2329.
- <span id="page-42-8"></span>[106] Safran SA. Statistical Thermodynmics of Surface, Interfaces and Membranes. Addison–Wesley Publishing Company; 1994.
- [107] Israelachvili JN. Intermolecular and surface forces. Academic press; 2011.
- <span id="page-42-9"></span>[108] Rubinstein M, Colby RH. Polymer physics. Oxford: OUP Oxford; 2003.
- <span id="page-42-10"></span>[109] Yeomans JM. Statistical mechanics of phase transitions. Clarendon Press; 1992.
- <span id="page-42-11"></span>[110] Balian R. From microphysics to macrophysics: methods and applications of statistical physics. vol. 2. Springer Science & Business Media; 2007.
- <span id="page-42-12"></span>[111] Callen HB. Thermodynamics and an Introduction to Thermostatistics. Wiley; 1985.
- <span id="page-42-13"></span>[112] De Groot SR, Mazur P. Non-equilibrium thermodynamics. Courier Corporation; 2013.
- <span id="page-42-20"></span>[113] Onuki A. Phase transition dynamics. Cambridge University Press. 2002;.
- <span id="page-42-14"></span>[114] Chaikin PM, Lubensky TC. Principles of Condensed Matter Physics. Cambridge University Press; 2000. Available from: [http://www.amazon.ca/](http://www.amazon.ca/exec/obidos/redirect?tag=citeulike09-20{&}path=ASIN/0521794501) [exec/obidos/redirect?tag=citeulike09-20{&}path=](http://www.amazon.ca/exec/obidos/redirect?tag=citeulike09-20{&}path=ASIN/0521794501) [ASIN/0521794501](http://www.amazon.ca/exec/obidos/redirect?tag=citeulike09-20{&}path=ASIN/0521794501).
- <span id="page-42-15"></span>[115] Cahn JW. On spinodal decomposition. Acta Metallurgica. 1961;9(9):795 – 801. Available from: [http://www.sciencedirect.com/science/article/](http://www.sciencedirect.com/science/article/pii/0001616061901821) [pii/0001616061901821](http://www.sciencedirect.com/science/article/pii/0001616061901821).
- [116] Siggia ED. Late stages of spinodal decomposition in binary mixtures. Phys Rev A. 1979 Aug;20:595–605. Available from: [http://link.aps.org/doi/10.1103/](http://link.aps.org/doi/10.1103/PhysRevA.20.595) [PhysRevA.20.595](http://link.aps.org/doi/10.1103/PhysRevA.20.595).
- [117] Tanaka H. A new coarsening mechanism of droplet spinodal decomposition. The Journal of Chemical

- Physics. 1995;103(6):2361–2364. Available from: [http://scitation.aip.org/content/aip/journal/](http://scitation.aip.org/content/aip/journal/jcp/103/6/10.1063/1.469658) [jcp/103/6/10.1063/1.469658](http://scitation.aip.org/content/aip/journal/jcp/103/6/10.1063/1.469658).
- [118] Mecke KR, Sofonea V. Morphology of spinodal decomposition. Physical Review E. 1997;56(4):R3761.
- [119] Hayward S, Heermann DW, Binder K. Dynamic percolation transition induced by phase separation: A Monte Carlo analysis. Journal of statistical physics. 1987;49(5-6):1053–1081.
- [120] Wagner AJ, Yeomans JM. Spinodal decomposition in two-dimensional binary fluids. International Journal of Modern Physics C. 1998;9(08):1373–1382.
- <span id="page-42-16"></span>[121] Sappelt D, J¨ackle J. Percolation inversion in spinodal decomposition of mixtures with strong kinetic asymmetry. Polymer. 1998;39(21):5253 – 5256. Available from: [http://www.sciencedirect.com/science/](http://www.sciencedirect.com/science/article/pii/S0032386197100829) [article/pii/S0032386197100829](http://www.sciencedirect.com/science/article/pii/S0032386197100829).
- <span id="page-42-17"></span>[122] Ip SW, Toguri JM. The Equivalency of Surface-Tension, Surface-Energy and Surface Free-Energy. J Mater Sci. 1994 00;29(3):688–692.
- <span id="page-42-18"></span>[123] Landau LD, Lifshitz EM. Course of theoretical physics 6, Hydrodynamics. Elsevier; 2013.
- <span id="page-42-19"></span>[124] Hohenberg P, Halperin B. Theory of dynamic critical phenomena. Rev Mod Phys. 1977 00;49:435–479. Available from: [http://rmp.aps.org/abstract/RMP/](http://rmp.aps.org/abstract/RMP/v49/i3/p435_1) [v49/i3/p435\\_1](http://rmp.aps.org/abstract/RMP/v49/i3/p435_1).
- <span id="page-42-21"></span>[125] Cates M. Complex fluids: the physics of emulsions. Soft Interfaces: Lecture Notes of the Les Houches Summer School: Volume 98, July 2012. 2017;98:317.
- <span id="page-42-22"></span>[126] Tolman RC. The effect of droplet size on surface tension. J Chem Phys. 1949;17(3):333–337.
- <span id="page-42-23"></span>[127] Blokhuis EM, Kuipers J. Thermodynamic expressions for the Tolman length. J Chem Phys. 2006 Feb;124(7):74701.
- <span id="page-42-24"></span>[128] Lifshitz EM, Pitaevskii LP. Physical Kinetics: Volume 10 (Course of Theoretical Physics). Butterworth-Heinemann; 1981.
- <span id="page-42-25"></span>[129] Binder K, Stauffer D. Statistical theory of nucleation, condensation and coagulation. Advances in Physics. 1976;25(4):343–396. Available from: [http://www.tandfonline.com/doi/abs/10.1080/](http://www.tandfonline.com/doi/abs/10.1080/00018737600101402) [00018737600101402](http://www.tandfonline.com/doi/abs/10.1080/00018737600101402).
- <span id="page-42-26"></span>[130] Binder K. Nucleation barriers, spinodals, and the Ginzburg criterion. Physical Review A. 1984;29(1):341.
- <span id="page-42-27"></span>[131] Yao JH, Elder K, Guo H, Grant M. Ostwald ripening in two and three dimensions. Physical Review B. 1992;45(14):8173.
- <span id="page-42-28"></span>[132] Yao JH, Elder K, Guo H, Grant M. Theory and simulation of Ostwald ripening. Physical review B. 1993;47(21):14110.
- <span id="page-42-29"></span>[133] Siggia E. Late stages of spinodal decomposition in binary mixtures. Physical Review A. 1979;20(2):595– 605. Available from: [http://dx.doi.org/10.1103/](http://dx.doi.org/10.1103/PhysRevA.20.595) [PhysRevA.20.595](http://dx.doi.org/10.1103/PhysRevA.20.595).
- <span id="page-42-30"></span>[134] van Aken GA. Coalescence mechanisms in proteinstabilized emulsions. Food emulsions. 2004;p. 299–324.
- <span id="page-42-31"></span>[135] Dai B, Leal LG. The mechanism of surfactant effects on drop coalescence. Physics of Fluids. 2008;20(4):040802.
- <span id="page-42-32"></span>[136] Tanaka H. Viscoelastic phase separation. Journal of Physics: Condensed Matter. 2000;12(15):R207. Available from: [http://stacks.iop.org/0953-8984/](http://stacks.iop.org/0953-8984/12/i=15/a=201) [12/i=15/a=201](http://stacks.iop.org/0953-8984/12/i=15/a=201).
- [137] Araki T, Tanaka H. Three-Dimensional Numerical Simulations of Viscoelastic Phase Separation: Morphological Characteristics. Macromolecules. 2001;34(6):1953– 1963. Available from: [http://pubs.acs.org/doi/abs/](http://pubs.acs.org/doi/abs/10.1021/ma001569n) [10.1021/ma001569n](http://pubs.acs.org/doi/abs/10.1021/ma001569n).
- <span id="page-42-33"></span>[138] Tanaka H, Araki T. Viscoelastic phase separation in soft matter: Numerical-simulation study on its physical mechanism. Chemical Engineering Sci-

- ence. 2006;61(7):2108 2141. Available from: [http://www.sciencedirect.com/science/article/](http://www.sciencedirect.com/science/article/pii/S0009250905004069) [pii/S0009250905004069](http://www.sciencedirect.com/science/article/pii/S0009250905004069).
- <span id="page-43-0"></span>[139] Weiss M, Elsner M, Kartberg F, Nilsson T. Anomalous subdiffusion is a measure for cytoplasmic crowding in living cells. Biophysical journal. 2004 nov;87(5):3518– 24.
- <span id="page-43-1"></span>[140] J¨ulicher F, Prost J. Generic theory of colloidal transport. The European Physical Journal E: Soft Matter and Biological Physics. 2009;29(1):27–36.
- <span id="page-43-2"></span>[141] Tenlen J, Molk J, London N, Page B, Priess J. MEX-5 asymmetry in one-cell C. elegans embryos requires PAR-4- and PAR-1-dependent phosphorylation. Development. 2008;135(22):3665–3675.
- <span id="page-43-3"></span>[142] Griffin E, Odde D, Seydoux G. Regulation of the MEX-5 Gradient by a Spatially Segregated Kinase/Phosphatase Cycle. Cell. 2011;146(6):955–968.
- <span id="page-43-4"></span>[143] Kr¨uger S, Weber CA, Sommer JU, J¨ulicher F. Discontinuous switching of position of two coexisting phases. New Journal of Physics. 2018;20(7):075009.
- <span id="page-43-5"></span>[144] Lajzerowicz J, Sivardiere J. Spin-1 lattice-gas model. I. Condensation and solidification of a simple fluid. Physical Review A. 1975;11(6):2079.
- <span id="page-43-6"></span>[145] Sivardi`ere J, Lajzerowicz J. Spin-1 lattice-gas model. II. Condensation and phase separation in a binary fluid. Physical Review A. 1975;11(6):2090.
- <span id="page-43-7"></span>[146] Kr¨uger S, Weber CA, Sommer JU, J¨ulicher F. in preparation;.
- <span id="page-43-8"></span>[147] J¨ulicher F, Ajdari A, Prost J. Modeling molecular motors. Rev Mod Phys. 1997 00;69(4):1269–1282. Available from: [http://link.aps.org/doi/10.1103/](http://link.aps.org/doi/10.1103/RevModPhys.69.1269) [RevModPhys.69.1269](http://link.aps.org/doi/10.1103/RevModPhys.69.1269).
- <span id="page-43-9"></span>[148] Allen SM, Cahn JW. A microscopic theory for antiphase boundary motion and its application to antiphase domain coarsening. Acta Metallurgica. 1979;27(6):1085–1095.
- <span id="page-43-10"></span>[149] Gitterman M, Steinberg V. Thermodynamic stability and phase transitions in systems with a chemical reaction. The Journal of Chemical Physics. 1978;69(6):2763– 2770.
- <span id="page-43-11"></span>[150] Lamorgese A, Mauri R. Spinodal decomposition of chemically reactive binary mixtures. Phys Rev E. 2016 Aug;94(2-1):022605.
- <span id="page-43-12"></span>[151] Boekhoven J, Hendriksen WE, Koper GJ, Eelkema R, van Esch JH. Transient assembly of active materials fueled by a chemical reaction. Science. 2015;349(6252):1075– 1079.
- <span id="page-43-13"></span>[152] Lefever R, Carati D, Hassani N. Comment on "Monte Carlo Simulations of Phase Separation in Chemically Reactive Binary Mixtures". Phys Rev Lett. 1995 00;75(8):1674. Available from: [http://prl.aps.org/](http://prl.aps.org/abstract/PRL/v75/i8/p1674_1) [abstract/PRL/v75/i8/p1674\\_1](http://prl.aps.org/abstract/PRL/v75/i8/p1674_1).
- <span id="page-43-14"></span>[153] Zhu YJ, Ma YQ. Fast growth in phase-separating A-Bcopolymer ternary mixtures with a chemical reaction. Phys Rev E. 2003 00;67(2 Pt 1):021804. Available from: <http://pre.aps.org/abstract/PRE/v67/i2/e021804>.
- <span id="page-43-15"></span>[154] Liu F, Goldenfeld N. Dynamics of phase separation in block copolymer melts. Phys Rev A. 1989 00;39(9):4805–4810. Available from: [http://pra.aps.](http://pra.aps.org/abstract/PRA/v39/i9/p4805_1) [org/abstract/PRA/v39/i9/p4805\\_1](http://pra.aps.org/abstract/PRA/v39/i9/p4805_1).
- <span id="page-43-16"></span>[155] Muratov CB. Theory of domain patterns in systems with long-range interactions of Coulomb type. Phys Rev E. 2002 00;66(6 Pt 2):066108. Available from: <http://pre.aps.org/abstract/PRE/v66/i6/e066108>.
- [156] Sagui C, Desai RC. Ostwald ripening in systems with competing interactions. Phys Rev Lett. 1995;74(7):1119.
- <span id="page-43-17"></span>[157] Sagui C, Desai RC. Effects of long-range repulsive interactions on Ostwald ripening. Phys Rev E. 1995;52(3):2822.
- <span id="page-43-18"></span>[158] Leibler L. Theory of microphase separation in block

- copolymers. Macromolecules. 1980 00;13:1602–1617. Available from: [http://pubs.acs.org/doi/abs/10.](http://pubs.acs.org/doi/abs/10.1021/ma60078a047) [1021/ma60078a047](http://pubs.acs.org/doi/abs/10.1021/ma60078a047).
- [159] Ohta T, Kawasaki K. Equilibrium morphology of block copolymer melts. Macromolecules. 1986 00;19:2621– 2632. Available from: [http://pubs.acs.org/doi/abs/](http://pubs.acs.org/doi/abs/10.1021/ma00164a028) [10.1021/ma00164a028](http://pubs.acs.org/doi/abs/10.1021/ma00164a028).
- [160] Li W, M¨uller M. Defects in the Self-Assembly of Block Copolymers and Their Relevance for Directed Self-Assembly. Annu Rev Chem Biomol Eng. 2015;6:187– 216.
- <span id="page-43-19"></span>[161] Glasner K. Hexagonal phase ordering in strongly segregated copolymer films. Phys Rev E. 2015 Oct;92(4):042602.
- <span id="page-43-20"></span>[162] Carati D, Lefever R. Chemical freezing of phase separation in immiscible binary mixtures. Phys Rev E. 1997 00;56(3 B):3127–3136. Available from: [http://www.scopus.com/inward/record.url?](http://www.scopus.com/inward/record.url?partnerID=yv4JPVwI&eid=2-s2.0-0031222291&md5=e3425af640abdbd6bf5a50f6f36fb76a) [partnerID=yv4JPVwI&eid=2-s2.0-0031222291&md5=](http://www.scopus.com/inward/record.url?partnerID=yv4JPVwI&eid=2-s2.0-0031222291&md5=e3425af640abdbd6bf5a50f6f36fb76a) [e3425af640abdbd6bf5a50f6f36fb76a](http://www.scopus.com/inward/record.url?partnerID=yv4JPVwI&eid=2-s2.0-0031222291&md5=e3425af640abdbd6bf5a50f6f36fb76a).
- <span id="page-43-21"></span>[163] Bazant MZ. Thermodynamic stability of driven open systems and control of phase separation by electroautocatalysis. Faraday discussions. 2017;199:423–463.
- <span id="page-43-22"></span>[164] Kacser H, Burns JA, Fell DA. The control of flux. Biochem Soc Trans. 1995;23(2):341–366.
- <span id="page-43-23"></span>[165] Golestanian R. Origin of life: Division for multiplication. Nature Physics. 2017;13(4):323–324.
- <span id="page-43-24"></span>[166] Mullins WW, Sekerka RF. Morphological stability of a particle growing by diffusion or heat flow. J Appl Phys. 1963;34(2):323–329.
- <span id="page-43-25"></span>[167] Mullins WW, Sekerka RF. Stability of a Planar Interface During Solidification of a Dilute Binary Alloy. J Appl Phys. 1964 00;35(2):444–451. Available from: [http://scitation.aip.org/content/aip/](http://scitation.aip.org/content/aip/journal/jap/35/2/10.1063/1.1713333) [journal/jap/35/2/10.1063/1.1713333](http://scitation.aip.org/content/aip/journal/jap/35/2/10.1063/1.1713333).
- <span id="page-43-26"></span>[168] Morel F, Morgan J. Numerical method for computing equilibriums in aqueous chemical systems. Environmental Science & Technology. 1972;6(1):58–67.
- <span id="page-43-27"></span>[169] Head T, Yamamura M, Gal S. Aqueous computing: writing on molecules. In: Evolutionary Computation, 1999. CEC 99. Proceedings of the 1999 Congress on. vol. 2. IEEE; 1999. p. 1006–1010.
- <span id="page-43-28"></span>[170] Head T, Chen X, Yamamura M, Gal S. Aqueous computing: a survey with an invitation to participate. Journal of Computer Science and Technology. 2002;17(6):672– 681.
- <span id="page-43-29"></span>[171] Landau LD, Lifshitz EM. Quantum Mechanics: Non-Relativistic Theory. Course of Theoretical Physics. Elsevier Science; 1981. Available from: [https://](https://books.google.co.uk/books?id=SvdoN3k8EysC) [books.google.co.uk/books?id=SvdoN3k8EysC](https://books.google.co.uk/books?id=SvdoN3k8EysC).