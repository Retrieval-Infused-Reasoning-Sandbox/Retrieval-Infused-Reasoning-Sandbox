## Conservation Laws and Work Fluctuation Relations in Chemical Reaction Networks

#### Riccardo Rao and Massimiliano Esposito

Complex Systems and Statistical Mechanics, Physics and Materials Science Research Unit, University of Luxembourg, L-1511 Luxembourg, G.D. Luxembourg (Dated: January 14, 2019. Published in J. Chem. Phys., DOI: 10.1063/1.5042253)

We formulate a nonequilibrium thermodynamic description for open chemical reaction networks (CRN) described by a chemical master equation. The topological properties of the CRN and its conservation laws are shown to play a crucial role. They are used to decompose the entropy production into a potential change and two work contributions, the first due to time dependent changes in the externally controlled chemostats concentrations and the second due to flows maintained across the system by nonconservative forces. These two works jointly satisfy a Jarzynski and Crooks fluctuation theorem. In absence of work, the potential is minimized by the dynamics as the system relaxes to equilibrium and its equilibrium value coincides with the maximum entropy principle. A generalized Landauer's principle also holds: the minimal work needed to create a nonequilibrium state is the relative entropy of that state to its equilibrium value reached in absence of any work.

#### PACS numbers: 02.50.Ga, 05.70.Ln, 87.16.Yc

#### I. INTRODUCTION

Nonequilibrium thermodynamic descriptions of stochastic (bio-)chemical processes have long since been developed. Among the first, T.L. Hill and coworkers studied bio-catalysts as small fluctuating machines operating at steady-state. They introduced the concept of free energy transduction and analyzed how one form of chemical work can drive another one against its spontaneous direction [1]. The importance of decomposing currents into network cycles (i.e. cyclic sets of transitions) was already emphasized. These results were however limited to steady-state systems described by linear chemical reaction networks (CRN). The stochastic as well as the deterministic dynamics of these CRNs is described by the same linear rate equations for, respectively, probabilities or concentrations. They model for instance conformational changes of an enzyme or of a membrane transporter. Inspired by these seminal works, J. Schnakenberg formulated a steady-state thermodynamics for generic Markov jump processes and provided a systematic cycle decomposition for the entropy production (EP) rate [2]. He considered in particular the stochastic description in terms of the Chemical Master Equation (CME) [3, 4] of nonlinear chemical reaction networks, i.e. CRNs described at the deterministic level by nonlinear rate equations for concentrations. The Brussels school, J. Ross and many others, focused on the connection between the thermodynamic description resulting from the stochastic and the deterministic dynamics [5-8].

With the advent of Stochastic Thermodynamics [9–12], the focus moved to the study of fluctuations, rather then focusing on the first two moments. Gaspard first showed that EP fluctuations in nonlinear CRNs at steady state satisfy a fluctuation theorem (FT) [13]. This result was

later expressed in terms of currents along Schnakenberg cycles [14, 15]. Fluctuations in complex chemical dynamics such as bistability was analyzed, amongst others, by Qian and coworkers [16–18]. A first formulation of stochastic thermodynamics for CRNs beyond steady state was done by Schmiedl and Seifert [19].

Despite this long history none of these descriptions made use of the specific topology of the CRN encoded in its stoichiometric matrix. Mathematicians know however that the CRN topology plays an important role on its deterministic [20, 21] as well as stochastic dynamics [22, 23]. But the question of how it affects the thermodynamic description was only studied recently: for deterministic dynamics in Refs. [24, 25], and for stochastic dynamics at steady state in [26]. In this paper we address this question in full generality for CRNs whose dynamics is stochastic. We will do so by presenting a formulation of stochastic thermodynamics for CRNs which systematically makes use of the conservation laws. Doing so leads to a significantly more informative thermodynamic description. In particular, we decompose the EP into three fundamental dissipative contributions: a newly defined potential change, a driving work contribution due to time dependent changes in the externally controlled chemostats concentrations, and a nonconservative work contribution due to a minimal set of flows maintained across the system by nonconservative forces. In contrast to the traditional chemical work given by minus the free energy change in the chemostats, these two new work contributions are shown to jointly satisfy a finite-time detailed and integral FT, when the CRN is initially prepared in an equilibrium state. In turn, the importance of the potential lies in the fact that it is minimized by the relaxation dynamics towards equilibrium in absence of the first two work contributions, i.e. when the system is detailed-balanced. It can be seen as a Legendre transform with respect to those conservation laws

that are broken by the chemostats. At equilibrium, it coincides with the potential obtained from maximizing entropy with broken conservation laws as constrains. We also discuss the connection of our findings to absolute irreversibility [27], to free energy transduction in nonlinear CRNs, and to cycle decompositions of the entropy production. Finally, we derive a nonequilibrium Landauer's principle for the driving and nonconservative work which generalizes the previous ones to nondetailed-balanced dynamics [28, 29].

Outline The paper is organized as follows. In § II (Stochastic Dynamics and CRN Topology) we review the stochastic description of closed and open CRNs and introduce conservation laws and stoichiometric cycles. In § III (Stochastic Thermodynamics) the connection with thermodynamics is made. The stochastic reaction rates are expressed in terms of Gibbs potentials via the equilibrium distribution of the closed CRN. Enthalpy and entropy balance are defined along stochastic trajectories and Jarzynski-like FTs for the chemical work are discussed. In § IV (CRN-Specific Stochastic Thermodynamics) the EP is partitioned into its three contributions. In § V (Semigrand Gibbs Potential) we analyze open detailed balanced CRNs, more specifically their relaxation to equilibrium as chemostats are successively introduced. In § VI (Fluctuation Theorems), finite-time detailed FTs for the driving and nonconservative work are derived. In § VII (Ensemble Average Rates Description) the ensemble average description is presented and the nonequilibrium Landauer's principle is derived. Finally in § VIII, our results are applied on a simple model to show the importance of our formulation for free energy transduction. Throughout the paper, our formalism is illustrated using a simple enzymatic scheme, whereas some technical derivations are given in appendices. We also provide a table which lists the symbols used throughout the paper, Tab. III.

## <span id="page-1-0"></span>II. STOCHASTIC DYNAMICS AND CRN TOPOLOGY

#### <span id="page-1-4"></span>A. Chemical Reaction Networks

We consider a homogeneous, isobaric, and isothermal *ideal dilute solution* made of  $N_z$  chemical species, encoded in a vector  $\mathbf{z}$ . Their integer-valued *population*  $\mathbf{n}$  changes due to internal reactions which we label by  $\{\rho_i\}$  for  $\rho_i = \pm 1, \ldots, \pm N_i$ ,

<span id="page-1-1"></span>
$$\mathbf{v}_{\rho_{i}} \cdot \mathbf{z} \stackrel{\mathbf{k}_{\rho_{i}}}{\stackrel{\sim}{\triangleright}_{-\rho_{i}}} \mathbf{v}_{-\rho_{i}} \cdot \mathbf{z}.$$
 (1)

In *open* CRNs, the population of a subset of species, named *exchanged* species and denoted by  $\mathbf{y}$  where  $\mathbf{z} \equiv (\mathbf{x}, \mathbf{y})$ , varies also due to exchanges with external

|         | species                | symbol      | number                                             | abundance                         |    |
|---------|------------------------|-------------|----------------------------------------------------|-----------------------------------|----|
| interna | exchanged chemostatted | x<br>y<br>Y | N <sub>x</sub><br>N <sub>y</sub><br>N <sub>y</sub> | n <sub>x</sub> n <sub>y</sub> [Y] | }n |

<span id="page-1-3"></span>TABLE I. In the second column the symbols used for the various species are listed. The corresponding total number of entries and symbols used to denote their abundance are given in the third and fourth column, respectively. The first column summarizes the name used to refer to these species, while the last one lists the symbol used to collect the abundances of the internal species. Internal species,  $\mathbf{x}$  and  $\mathbf{y}$ , are characterized by low populations,  $\mathbf{n}$ . The population of  $\mathbf{x}$  can change only because of reactions, whereas that of  $\mathbf{y}$  are also exchanged with chemostats, which are identified by  $\mathbf{Y}$ , Eq. (1).

![](_page_1_Figure_10.jpeg)

<span id="page-1-2"></span>FIG. 1. Pictorial representation of an open CRN modeling an enzymatic scheme discused in Ex. 1

chemostats denoted by Y. Their effect is modeled by exchange reactions,  $\{\rho_e\}$  for  $\rho_e = \pm 1, \dots, \pm N_y$ , see Fig. 1,

$$\mathbf{v}_{\rho_{e}}^{\mathbf{y}} \cdot \mathbf{y} \xrightarrow{\overline{k_{\rho_{e}}}} \mathbf{v}_{-\rho_{e}}^{\mathbf{Y}} \cdot \mathbf{Y}. \tag{2}$$

The non-negative integer-valued vectors  $\{ \mathbf{v}_{\rho} \equiv (\mathbf{v}_{\rho}^{x}, \mathbf{v}_{\rho}^{y}) \}$  for  $\rho \in \{ \rho_{i} \} \cup \{ \rho_{e} \}$ , encode the *stoichiometric coefficients* of each reaction. Note that each entry of  $\mathbf{v}_{\rho_{e}}^{y}$  and  $\mathbf{v}_{\rho_{e}}^{Y}$  is nonzero and equal to one only if it corresponds to the species exchanged by  $\rho_{e}$ . Note also that all reactions are assumed *elementary* and *reversible*. For any reaction  $\rho$ ,  $-\rho$  denotes its backward counterpart, and the sums over  $\rho$  includes both + and -. The different types of species are summarized in Tab. I.

The topology of the CRN is encoded in its *stoichiomet-ric vectors*,

<span id="page-1-5"></span>
$$S_\rho := \nu_{-\rho} - \nu_\rho \text{ , and } \quad S_\rho^Y := \nu_{-\rho}^Y - \nu_\rho^Y \,. \tag{3}$$

The former quantifies the change of population induced by a given reaction  $\rho$ , whereas the latter the corresponding amount of chemostatted species that is exchanged. By definition,  $\mathbf{S}_{\rho} = -\mathbf{S}_{-\rho}$  and  $\mathbf{S}_{\rho}^{Y} = -\mathbf{S}_{-\rho}^{Y}$ . Collecting the column vectors  $\mathbf{S}_{\rho}$  (resp.  $\mathbf{S}_{\rho}^{Y}$ ) corresponding to

arbitrarily-chosen forward reactions defines the internal (resp. external) *stoichiometric matrix* denoted by S (resp.  $S^Y$ ). It is not difficult to see that these can be decomposed as

<span id="page-2-5"></span>
$$S \equiv \begin{pmatrix} S_i & S_e \end{pmatrix} \equiv \begin{pmatrix} S_i^x & O \\ S_i^y & S_e^y \end{pmatrix} , \tag{4}$$

<span id="page-2-6"></span>and

$$S^{Y} \equiv \begin{pmatrix} S_{i}^{Y} & S_{e}^{Y} \end{pmatrix} \equiv \begin{pmatrix} O & -S_{e}^{y} \end{pmatrix}. \tag{5}$$

In closed CRNs all exchange reactions disappear and the stoichiometric matrix reduces to  $S_i$ .

*Remark* Previous works on thermodynamics of CRNs, *e.g.* Refs. [19, 24, 25, 30], describe open CRNs by assuming that the exchanged species y are so abundant that they can be regarded as particle reservoirs *within* the system. As a result the exchange reactions are disregarded, y are treated as *chemostatted*, and the stoichiometric matrices read

<span id="page-2-4"></span>
$$S_{alt} = S_i^x$$
, and  $S_{alt}^Y = S_i^y$ . (6)

In the closed CRNs, the stoichiometric matrix becomes  $(S_{alt}, S_{alt}^Y)^T$ . As we will see, the two approach are formally very similar, but the former has the advantage of preserving the number of internal species when the CRN is chemostatted. This makes it more suitable for a stochastic description.

<span id="page-2-0"></span>Example 1. For the open CRN in Fig. 1,

$$\mathbf{x} = (E, E^*, E^{**}), \quad \mathbf{y} = (A, B), \quad \mathbf{Y} = (A_e, B_e),$$
 (7)

and

$$\mathbf{n} = (n_{E,}, n_{F^*}, n_{F^{**}}, n_{A}, n_{B}). \tag{8}$$

Internal reactions,  $\rho_i=\pm 1,\ldots,\pm 4$ , are distinguished from the exchange ones,  $\rho_e=\pm \alpha,\pm b$ , and the stoichiometric matrices read

$$S = E^{**} \begin{pmatrix} +1 & +2 & +3 & +4 & +a & +b \\ -1 & 1 & -1 & 1 & 0 & 0 \\ 1 & -1 & 0 & 0 & 0 & 0 \\ 0 & 0 & 1 & -1 & 0 & 0 \\ A & -1 & 0 & 0 & 1 & 1 & 0 \\ 0 & 1 & -1 & 0 & 0 & 1 \end{pmatrix},$$
(9)

and

$$S^{Y} = \begin{array}{c|ccccccccccccccccccccccccccccccccccc$$

for our arbitrary choice of forward reactions.

*Notation* Henceforth, we will use the following notation

$$\alpha! = \prod_i \alpha_i!$$
 ,  $~~\alpha^{\cdot b} = \prod_i \alpha_i^{b_i}$  , and  $~~c^{\cdot b} = c^{\sum_i b_i}$  ,

for generic vectors  $\mathfrak a$  and  $\mathfrak b$ , and for a generic constant c. "In  $\mathfrak a$ " must be read as a vector whose entries are the logarithm of the entries of  $\mathfrak a$ . 1 denotes a vector whose entries are all equal to 1. Total and partial time derivatives are written as  $d_t$  and  $\partial_t$ , and the overdot "·" denotes rates of change of observables which are not state functions.

## <span id="page-2-3"></span>B. Chemical Master Equation

In our stochastic description, n is treated as a fluctuating variable and all reactions are regarded as stochastic events. The probability of finding the CRN in the state n at time t is denoted by  $p_n \equiv p_n(t)$  and its evolution is ruled by the CME [3, 4, 31]

$$d_{t}p_{n} = \sum_{\rho} \left\{ w_{-\rho}(n + S_{\rho}) p_{n+S_{\rho}} - w_{\rho}(n) p_{n} \right\}$$

$$= \sum_{m} W_{nm} p_{m}, \qquad (11)$$

where the stochastic generator reads

$$W_{\mathbf{n}\mathbf{m}} = \sum_{\rho} w_{\rho}(\mathbf{m}) \left\{ \delta_{\mathbf{n},\mathbf{m}+\mathbf{S}_{\rho}} - \delta_{\mathbf{n},\mathbf{m}} \right\}. \tag{12}$$

Since all reactions are assumed elementary, we consider *mass-action* stochastic reaction rates

<span id="page-2-2"></span>
$$w_{\rho}(\mathbf{n}) := k_{\rho} \frac{V}{V \cdot \mathbf{v}_{\rho}} [\mathbf{Y}] \cdot \mathbf{v}_{\rho}^{Y} \frac{\mathbf{n}!}{(\mathbf{n} - \mathbf{v}_{\rho})!}. \tag{13}$$

where  $\{k_\rho\}$  denote the *rate constants*. The dependence on the volume V ensures the correct scaling when taking the large particle limit and guarantees that  $\{k_\rho\}$  are the same as in deterministic descriptions [32]. The chemostats concentrations [Y] only appear in exchange reactions  $\rho_e$  and quantify the concentration of the exchanged species in the chemostats. Hence, they are real-valued, nonfluctuating, and unaffected by the occurrence of exchange reactions. We assume that [Y] can change over time and their value at each time t is encoded in the driving *protocol*  $\pi_t$ . This may describe for instance, the controlled injection of certain molecules across a cell membrane. In such situations the CRN is said to be subjected to a "driving". In absence of driving the CRNs is instead said to be *autonomous*.

Equilibrium probability distributions are of crucial importance for our discussion. They satisfy the *detailed balance* property

<span id="page-2-1"></span>
$$w_{\rho}(n)p_{n}^{eq}=w_{-\rho}(n+S_{\rho})p_{n+S_{\rho}}^{eq}\,,\quad\text{for all $\rho$, $n$. (14)}$$

This means that the probability current of any reaction  $\rho$  occurring from any state n vanishes. Stochastic CRNs

which admit a steady-state probability distribution satisfying Eq. (14) are referred to as *detailed balanced*. Their stochastic thermodynamics will be analyzed in § V.

**Example 2.** For the CRN in Fig. 1, the transition rates are

$$\begin{split} w_{+1} &= k_{+1} n_A n_E \,, \quad w_{-1} &= k_{-1} n_{E^*} \,, \\ w_{+2} &= k_{+2} n_{E^*} \,, \qquad w_{-2} &= k_{-2} n_E n_B \,, \\ w_{+3} &= k_{+3} n_E n_B \,, \quad w_{-3} &= k_{-3} n_{E^{**}} \,, \\ w_{+4} &= k_{+4} n_{E^{**}} \,, \qquad w_{-4} &= k_{-4} n_E n_A \,, \\ w_{+a} &= k_{+a} [A_e] \,, \qquad w_{-a} &= k_{-a} n_A \,, \\ w_{+b} &= k_{+b} [B_e] \,, \qquad w_{-b} &= k_{-b} n_B \,. \end{split}$$

#### C. Stochastic Trajectories

A stochastic trajectory of duration t,  $\mathfrak{n}_t$ , is defined as a set of reactions  $\{\rho_l\}$  sequentially occurring at times  $\{t_l\}$  starting from  $\mathbf{n}_0$  at time  $t_0$ . Such trajectories can be generated by a *Stochastic Simulation Algorithm* [33]. Given the initial state, a trajectory is completely characterized by

<span id="page-3-0"></span>
$$j_{\rho}(\textbf{n},\tau) := \sum_{l} \delta_{\rho \rho_{l}} \delta_{\textbf{n} \textbf{n}_{t_{l}}} \delta(\tau - t_{l}) \,, \tag{16} \label{eq:16}$$

which encodes the reactions that occur ( $\{\rho_l\}$ ), the states from which these occur ( $\{n_{t_l}\}$ ), and the reaction times ( $\{t_l\}$ ). The transition index l runs from l=1 to the last transition prior to time t,  $N_t$ . The *instantaneous reaction fluxes* 

<span id="page-3-5"></span>
$$J_{\rho}(\tau) := \sum_{\mathbf{n}} j_{\rho}(\mathbf{n}, \tau) = \sum_{\mathbf{l}} \delta_{\rho \rho_{\mathbf{l}}} \delta(\tau - t_{\mathbf{l}}). \tag{17}$$

quantify the instantaneous rate of occurrence of each reaction irrespectively of the state from which it occurs. Additionally, we denote the population of the CRN at time  $\tau \in [t_0 = 0, t]$  by  $n_\tau$ .

The path probability of a trajectory reads

$$\mathcal{P}[\mathfrak{n}_{t}] = \prod_{l=0}^{N_{t}} \exp\left\{-\int_{t_{l}}^{t_{l+1}} d\tau \sum_{\rho} w_{\rho}(\mathfrak{n}_{\tau}, \tau)\right\}$$

$$\times \prod_{l=1}^{N_{t}} w_{\rho_{l}}(\mathfrak{n}_{t_{l}}, t_{l}), \quad (18)$$

where  $t_{N_t+1} := t$  is the final time of the trajectory. The first term accounts for the probability that the system spends  $\{t_{l+1} - t_l\}$  time in the state  $\{n_{t_l}\}$ , while the second accounts for the probability of transitioning. When averaging Eq. (16) over all stochastic trajectories, we obtain the transition rates, Eq. (13),

$$\langle \mathbf{j}_{0}(\mathbf{n}, \tau) \rangle = w_{0}(\mathbf{n}, \tau) p_{\mathbf{n}}(\tau). \tag{19}$$

![](_page_3_Figure_14.jpeg)

<span id="page-3-2"></span>FIG. 2. Pictorial representation of the change of a state variable observable 0 along a trajectory. The orange dashed curves represent the changes due to the protocol—first term in Eq. (21)—while vertical blue lines changes due to reactions—second term in Eq. (21).

Changes of generic observables along trajectories are written as

$$\delta \mathfrak{X}[\mathfrak{n}_t] = \int_0^t d\tau \Big\{ \dot{\mathfrak{X}}(\mathbf{n}_\tau, \tau) + \sum_{\mathbf{n}, \rho} \delta \mathfrak{X}_{\rho}(\mathbf{n}, \tau) \, \mathfrak{j}_{\rho}(\mathbf{n}, \tau) \Big\} \,. \tag{20}$$

where  $\dot{\mathfrak{X}}(\mathbf{n},\pi_{\tau})$  denotes its change in time while the CRN dwells in the state  $\mathbf{n}$  (it need not be an exact time derivative), and  $\delta\mathfrak{X}_{\rho}(\mathbf{n},\pi_{\tau})$  denotes its finite change along the reaction  $\rho$  occurring while in  $\mathbf{n}$ . By contrast, the changes of state observables  $\mathfrak{O}(\mathbf{n},t)$  can be written as

$$\begin{split} &\Delta \mathfrak{O}[\mathfrak{n}_t] = \mathfrak{O}(n_t,t) - \mathfrak{O}(n_0,0) \\ &= \int_0^t d\tau \Big\{ \left. \left[ \partial_\tau \mathfrak{O}(n,\tau) \right] \right|_{n_\tau} + \sum_{n,\rho} \Delta_\rho \mathfrak{O}(n,\tau) \, \mathfrak{j}_\rho(n,\tau) \Big\} \,. \end{split} \tag{21}$$

where  $\partial_{\tau} \mathcal{O}(\mathbf{n}, \tau)$  is the time derivative of  $\mathcal{O}(\mathbf{n}, \tau)$ , and

$$\Delta_{\mathbf{0}} \mathcal{O}(\mathbf{n}, \tau) := \mathcal{O}(\mathbf{n} + \mathbf{S}_{\mathbf{0}}, \tau) - \mathcal{O}(\mathbf{n}, \tau), \tag{22}$$

is the difference of  $O(n, \tau)$  along reactions, see Fig. 2.

#### <span id="page-3-7"></span><span id="page-3-4"></span><span id="page-3-3"></span><span id="page-3-1"></span>D. Conservation Laws

The topological properties of CRNs are encoded in the matrices S and S<sup>Y</sup> and can be identified via their cokernels and kernels. *Conservation laws*  $\ell$  are defined as vectors in coker S,

$$\boldsymbol{\ell}\cdot\boldsymbol{S}_{\rho}=0\,,\quad\text{for all }\rho\,. \tag{23}$$

<span id="page-3-6"></span>They identify conserved quantities, called *components* [34]

<span id="page-3-9"></span>
$$L_{n} := \ell \cdot n. \tag{24}$$

<span id="page-3-8"></span>Despite the fact that  $L_n$  depends on the stochastic variable n, the probability of observing any specific value L,

$$P(L) := \sum_{n} p_n \, \delta[L_n, L], \qquad (25)$$

is constant over time, *i.e.*  $d_tP(L) = 0$ .  $\delta$  is a Kronecker delta. More generally, any observable of type  $O(L_n)$  *does not fluctuate*,

$$d_t \sum_{\mathbf{n}} p_{\mathbf{n}} \, \mathcal{O}(L_{\mathbf{n}}) = 0 \,, \tag{26}$$

as a direct consequence of the fact that  $\Delta_{\rho} \mathcal{O}(L_n) = 0$ . Clearly, P(L) can be deduced from the initial conditions  $p_n(0)$  and only those states for which  $P(L_n,0)$  is non-vanishing have a finite probability of being observed during the subsequent stochastic dynamics.

In closed CRNs, conservation laws (23) follow from

$$\ell^{x} \cdot \mathbf{S}_{\rho_{i}}^{x} + \ell^{y} \cdot \mathbf{S}_{\rho_{i}}^{y} = 0$$
, for all  $\rho_{i}$ . (27)

We denote a set of linearly independent conservation laws of the closed CRN by  $\{\ell_{\lambda}\}$ , and the corresponding components by  $\{L_{n}^{\lambda}:=\ell_{\lambda}\cdot n\}$ , for  $\lambda=1,\ldots,N_{\lambda}:=\dim\operatorname{coker} S_{i}$ . The choice of this set is not unique, and different choices have different physical meanings. This set is never empty since the total mass is always conserved. The latter corresponds to a  $\ell$  whose entries are the masses of each species. Physically, the conservation laws of closed CRNs can always be chosen so as to correspond to *moieties*, which are parts of molecules exchanged between species along reactions or subject to isomerization [35].

For open CRNs, the condition identifying conservation laws, Eq. (23), becomes

$$\label{eq:continuity} \boldsymbol{\ell}^x \cdot \boldsymbol{S}^x_{\rho_i} + \boldsymbol{\ell}^y \cdot \boldsymbol{S}^y_{\rho_i} = 0 \, \text{,} \quad \text{for all } \rho_i \, \text{,} \tag{28a}$$

$$\ell^{y} \cdot \mathbf{S}_{\rho_{e}}^{y} = 0$$
, for all  $\rho_{e}$ . (28b)

We now recall that for all  $\rho_e$  there is one and only one exchanged species for which the corresponding entry of  $\mathbf{S}_{\rho_e}^y$  is different from zero. Hence, Eq. (28b) demands that  $\ell^y = 0$  and Eq. (28) become  $\ell^x \cdot \mathbf{S}_{\rho_i}^x = 0$  for all  $\rho_i$ .

Crucially, any set of independent conservation laws of the open CRN, Eq. (28), denoted by  $\{\ell_{\lambda_u}\}$ , for  $\lambda_u=1,\ldots,N_{\lambda_u}:=\dim \operatorname{coker} S< N_{\lambda}$ , can be regarded as a subset of the conservation laws of the closed CRN,  $\{\ell_{\lambda}\} \equiv \{\ell_{\lambda_u}\} \cup \{\ell_{\lambda_b}\}$ , since they satisfy Eq. (27), too. In view of this, we call them *unbroken conservation laws*. The remaining independent conservation laws, labeled as  $\{\ell_{\lambda_b}\}$  and referred to as *broken*, satisfy Eq. (27) while not Eq. (28). They involve exchanged species,  $\ell_{\lambda_b}^y \neq 0$ , hence  $\ell_{\lambda_b}^y \cdot S_{\rho_e}^y \neq 0$  and the probability distribution of any set  $\{L_n^{\lambda_b} \equiv \ell_{\lambda_b} \cdot n\}$ ,

$$P(\{L_{\lambda_b}\}) := \sum_{\mathbf{n}} p_{\mathbf{n}} \prod_{\lambda_b} \delta[L_{\mathbf{n}}^{\lambda_b}, L_{\lambda_b}], \qquad (29)$$

changes in time.

Summarizing, in open CRNs, the chemostatting breaks a subset of the conservation laws of the corresponding closed CRN,  $\{\ell_{\lambda_b}\}$ . Only the probability distribution of the *unbroken components*  $\{L_n^{\lambda_u} \equiv \ell_{\lambda_u} \cdot n\}$ ,

$$P(\{L_{\lambda_{\mathbf{u}}}\}) := \sum_{\mathbf{n}} p_{\mathbf{n}} \prod_{\lambda_{\mathbf{u}}} \delta[L_{\mathbf{n}}^{\lambda_{\mathbf{u}}}, L_{\lambda_{\mathbf{u}}}], \qquad (30)$$

is invariant and completely determined by the initial probability distribution  $p_{\mathbf{n}}(0)$ . The state space identified by one particular set of values for  $\{L_{\lambda_u}\}$  is called stoichiometric compatibility class.

<span id="page-4-3"></span>**Example 3.** The CRN in Fig. 1 has two conservation laws,

$$\ell_{\rm E} = \begin{pmatrix} E & E^* & E^{**} & A & B \\ 1 & 1 & 1 & 0 & 0 \end{pmatrix},$$
 (31a)

$$\ell_b = \begin{pmatrix} E & E^* & E^{**} & A & B \\ 0 & 1 & 1 & 1 & 1 \end{pmatrix},$$
 (31b)

<span id="page-4-1"></span>among which the second is broken. The unbroken conservation law identifies the enzyme moiety and corresponds to the total number of enzyme molecules populating the CRN,  $L_n^E = n_E + n_{E^*} + n_{E^{**}}$ . Instead, the broken one identifies the moiety A—or equivalently B—,  $L_n^b = n_{E^*} + n_{E^{**}} + n_A + n_B$ .

#### <span id="page-4-6"></span><span id="page-4-5"></span><span id="page-4-2"></span>E. Stoichiometric Cycles

We can now set the stage for the thermodynamic description based on a stoichiometric cycle decomposition. This section, as well as the other ones discussing cycles, may be omitted at a first reading.

<span id="page-4-0"></span>Additional information about the CRN topology is provided by the *stoichiometric cycles*  $\mathbf{c} = \{c_{\rho}\}$  as they are vectors in ker S. Equivalently, these satisfy

$$\sum_{\rho} \mathbf{S}_{\rho} \mathbf{c}_{\rho} = \mathbf{0}, \tag{32}$$

and at most one entry for each forward–backward transition pair is nonzero. Since S is integer-valued, any c can always be chosen non-negative-integer-valued. In this way, its entries denote the number of times each transition occurs along a transformation which overall leaves the state n unchanged. Alternatively, a stoichiometric cycle can be seen as a set of reactions  $\{\rho_{c1}, \rho_{c2}, \ldots, \rho_{cN_c}\}$  identifying a closed loop in the state space

<span id="page-4-4"></span>
$$n \rightarrow n + S_{\rho_{c1}} \rightarrow \cdots \rightarrow n + \sum_{i=1}^{N_c} S_{\rho_{ci}} = n$$
, (33)

where  $\sum_{i=1}^{N_c} \mathbf{S}_{\rho_{ci}} = \sum_{\rho} \mathbf{S}_{\rho} c_{\rho} = 0$ .

We now relate cycles of the closed and open CRNs as previously done for conservation laws. In the closed CRN, the stoichiometric cycles are given by

$$\sum_{\rho_i} \mathbf{S}_{\rho_i}^{\mathbf{x}} \mathbf{c}_{\rho_i} = \mathbf{0} \tag{34a}$$

$$\sum_{\rho_{i}} \mathbf{S}_{\rho_{i}}^{y} c_{\rho_{i}} = 0. \tag{34b}$$

The entries corresponding to the exchange reactions are taken equal to 0:  $c_{\rho_e}=0$ , for all  $\rho_e$ . Let us denote by  $\{c^\alpha\}$ , for  $\alpha=1,\ldots,N_\alpha:=\dim\ker S_i$ , a set of independent stoichiometric cycles of the closed CRN.

In the open CRN, the condition identifying cycles, Eq. (32), reads

$$\sum_{\rho_i} \mathbf{S}_{\rho_i}^{\mathbf{x}} \mathbf{c}_{\rho_i} = \mathbf{0} \tag{35a}$$

$$\sum_{\rho_i} \mathbf{S}_{\rho_i}^y c_{\rho_i} + \sum_{\rho_e} \mathbf{S}_{\rho_e}^y c_{\rho_e} = 0.$$
 (35b)

Since the cycles of the closed CRN satisfy Eq. (35), they can be regarded as a subset of an independent set of cycles for the open CRN,  $\{c^{\alpha}, c^{\eta}\}$ . We refer to the additional cycles  $\{c^{\eta}\}$ , for  $\eta=1,\ldots,N_{\eta}:=\dim\ker S-\dim\ker S_i$ , as *emergent*. They are characterized by at least one nonzero entry for  $\{\rho_e\}$ , and the vectors

$$\mathbf{C}_{\eta}^{\mathrm{Y}} := \sum_{\rho} \left( -\mathbf{S}_{\rho}^{\mathrm{Y}} \right) c_{\rho}^{\eta} = \sum_{\rho_{\mathrm{e}}} \mathbf{S}_{\rho_{\mathrm{e}}}^{\mathrm{y}} c_{\rho_{\mathrm{e}}}^{\eta} \neq \mathbf{0}$$
 (36)

quantify the amount of exchanged species flowing in the system from the corresponding chemostats upon completion of  $c^n$ . As the concentrations of the chemostats are unaffected by the exchange of particles with the system, the emergent stoichiometric cycles can be thought of as pathways transferring chemicals across chemostats while leaving the internal state of the CRN unchanged.

As first proved in Ref. [24], by applying the ranknullity theorem to the stoichiometric matrices of the open and closed CRNs, one can show that

$$N_{v} = N_{\lambda_{h}} + N_{n} . \tag{37}$$

In words, for any exchanged species either a conservation law is broken, or an emergent cycle is created.

**Example 4.** The CRN in Fig. 1 has one cycle

$$\mathbf{c}_{\text{int}} = \begin{pmatrix} +1 & +2 & +3 & +4 & +a & +b \\ 1 & 1 & 1 & 1 & 0 & 0 \end{pmatrix},$$
 (38)

and one emergent cycle

<span id="page-5-3"></span>
$$\mathbf{c}_{\text{ext}} = \begin{pmatrix} +1 & +2 & +3 & +4 & +a & +b \\ 1 & 1 & 0 & 0 & 1 & -1 \end{pmatrix}.$$
 (39)

Negative entries must be interpreted as reactions occurring in the backward direction. The latter cycle corresponds to the injection of one molecule of A, its conversion into one of B passing via  $E^*$ , and its ejection,

$$\mathbf{C}_{\text{ext}} = \begin{pmatrix} A & B \\ 1 & -1 \end{pmatrix}. \tag{40}$$

We can also check the validity of Eq. (37), as the number of chemostats, 2, equals the number of broken conservation laws, 1, see Ex. 3, plus the number of emergent cycles, 1, Eq. (39).

*Remark* Stoichiometric cycles must be distinguished from graph-theoretic cycles, also called *loops* see *e.g.* Ref. [2]. To elucidate this point, we note that the network

<span id="page-5-1"></span>of transitions of a CRN can be regarded as a semi-infinite graph whose vertices are the accessible states n, and whose directed edges are given by the reactions—which are encoded in the stoichiometric matrix, S. Hence, one can see that loops are recursive appearance of stoichiometric cycles, as in Eq. (33). However, they may not be complete at the boundaries of the graph (low n) due to peculiar topological properties of the CRN, see e.g. Ref. [26]. These observations will be used later to relate different approaches for cycle decomposition of thermodynamic quantities.

## <span id="page-5-0"></span>III. STOCHASTIC THERMODYNAMICS

<span id="page-5-6"></span><span id="page-5-2"></span>We now build a nonequilibrium thermodynamic description on top of the stochastic dynamics. We assume that the solvent acts as a thermal reservoir by keeping the temperature, T, and the pressure constant everywhere. Since particle numbers are low, we can assume that that the time scale in which molecules spatially homogenize is much faster than that of reactions. Therefore, if all reactions could be instantaneously shut down, we would observe an equilibrium mixture of inert species at all times. However, due to reactions, the populations of species and their probability distribution can be far from equilibrium. These hypotheses can be regarded as a special case of *local equilibrium* [36], since temperature, pressure, and density are not only locally well defined, but also constant.

#### <span id="page-5-4"></span>A. Equilibrium of Closed CRNs

Equilibrium statistical mechanics requires that the equilibrium distribution of a closed CRN with given values of  $\{L_{\lambda}\}$  reads

$$p^{eq}(\mathbf{n}|\{L_{\lambda}\}) = \frac{\exp\{-\beta g_{\mathbf{n}}\}}{Z(\{L_{\lambda}\})} \prod_{\lambda} \delta[L_{\mathbf{n}}^{\lambda}, L_{\lambda}], \qquad (41)$$

where

<span id="page-5-7"></span>
$$g_{\mathbf{n}} = (\mu^{\circ} - 1k_{B}T \ln n_{s}) \cdot \mathbf{n} + k_{B}T \ln \mathbf{n}!$$
 (42)

is the *Gibbs free energy* of the state n derived in App. A. The first term quantifies the energetic contribution of each single molecule:  $\mu^{\circ} \equiv \mu^{\circ}(T)$  is the vector of *standard-state chemical potentials*, whereas  $-1k_BT\ln n_s$  is an entropic contribution—constant for all species—since  $n_s$  is the population of the solvent. The last term is purely entropic and accounts for the indistinguishability of molecules of the same species. In Eq. (41),

<span id="page-5-5"></span>
$$Z(\{L_{\lambda}\}) = \sum_{m} \exp\{-\beta g_{m}\} \prod_{\lambda} \delta[L_{m}^{\lambda}, L_{\lambda}]$$
 (43)

is the partition function, while  $\beta = 1/(k_BT)$ . When taking into account an ensemble of components,  $P(\{L_{\lambda}\})$ ,

Eq. (41) allows us to write

<span id="page-6-0"></span>
$$p_{\mathbf{n}}^{\text{eq}} = \sum_{\{L_{\lambda}\}} p^{\text{eq}}(\mathbf{n}|\{L_{\lambda}\}) P(\{L_{\lambda}\})$$
$$= p^{\text{eq}}(\mathbf{n}|\{L_{\lambda}^{\lambda}\}) P(\{L_{\lambda}^{\lambda}\}), \tag{44}$$

which can be regarded as a *constrained* equilibrium distribution. Hence,  $p^{eq}(n|\{L_n^{\lambda}\})$  is the conditional probability of observing n given the stoichiometric compatibility class it identifies.

Equation (44) can also be written as

$$p_{\mathbf{n}}^{\text{eq}} = \exp\left\{-\beta\left[g_{\mathbf{n}} - G_{\text{eq}}(\{L_{\mathbf{n}}^{\lambda}\})\right]\right\},\tag{45}$$

in terms of the equilibrium Gibbs potential of the CRN

$$G_{eq}(\{L_{\lambda}\}) = k_B T \ln P(\{L_{\lambda}\}) - k_B T \ln Z(\{L_{\lambda}\}). \quad (46)$$

It is worth emphasizing that  $G_{eq}(\{L_{\lambda}\})$  is function solely of the set of components, and that  $G_{eq}(\{L_{n}^{\lambda}\})$  needs to be understood as  $G_{eq}$  evaluated in  $\{L_{n}^{\lambda}\}$ . Invoking the hypothesis of local equilibrium, we extend  $G_{eq}$  to arbitrary probability distributions  $p_{n}$ ,

<span id="page-6-5"></span>
$$G(\mathbf{n}) := k_B T \ln p_{\mathbf{n}} + g_{\mathbf{n}}, \qquad (47)$$

and we call it *stochastic Gibbs potential*, as it is the far-from-equilibrium fluctuating expression of  $G_{eq}$ . In addition to the Gibbs free energy of the state  $\mathfrak{n}$ ,  $\mathfrak{g}_{\mathfrak{n}}$ , it accounts for the entropic contribution due to the uncertainty of  $\mathfrak{p}_{\mathfrak{n}}$ :  $k_B T \ln \mathfrak{p}_{\mathfrak{n}}$  can indeed be written as  $-T(-k_B \ln \mathfrak{p}_{\mathfrak{n}})$ , where the term in parentheses is the *self-information* measured in  $k_B$  units [37]. For closed CRNs at equilibrium, using Eq. (44),  $G(\mathfrak{n})$  reduces to  $G_{eq}$  in Eq. (46). Also, its average value, the *nonequilibrium Gibbs potential* 

<span id="page-6-9"></span>
$$\langle G \rangle = \sum_{\mathbf{n}} p_{\mathbf{n}} \left[ k_{\mathrm{B}} T \ln p_{\mathbf{n}} + g_{\mathbf{n}} \right],$$
 (48)

takes its minimum value at equilibrium

$$\begin{split} \langle G \rangle - \langle G_{eq} \rangle_L &= \left\langle G - G_{eq} \right\rangle \\ &= k_B T \sum_{\mathbf{n}} p_{\mathbf{n}} \ln \frac{p_{\mathbf{n}}}{p_{\mathbf{n}}^{eq}} \\ &\equiv k_B T \, \mathcal{D}(p \| p^{eq}) \geqslant 0 \,. \end{split} \tag{49}$$

In the first equality, we used the fact that the equilibrium Gibbs potential only depends on the components,

$$\begin{split} \langle G_{eq} \rangle_{L} &\equiv \sum_{\{L_{\lambda}\}} P(\{L_{\lambda}\}) G_{eq}(\{L_{\lambda}\}) \\ &= \sum_{\{L_{\lambda}\}} \left[ \sum_{\mathbf{n}} p_{\mathbf{n}} \prod_{\lambda} \delta \left[ L_{\mathbf{n}}^{\lambda}, L_{\lambda} \right] \right] G_{eq}(\{L_{\lambda}\}) \\ &= \sum_{\mathbf{n}} p_{\mathbf{n}} G_{eq}(\{L_{\mathbf{n}}^{\lambda}\}) \,. \end{split}$$
 (50)

In the last equality of Eq. (49),  $\mathcal{D}(p\|p^{eq})$  is the relative entropy of the transient probability distribution  $p_n$  with respect to the equilibrium one  $p_n^{eq}$ . It is always positive and vanishes only when  $p_n = p_n^{eq}$ . We will see later (§ VII) that Eq. (49) quantifies exactly the average dissipation of the relaxation to equilibrium.

#### <span id="page-6-3"></span>B. Local Detailed Balance

The zero-th law of thermodynamics for CRNs requires that closed CRNs relax to equilibrium. To ensure this, the dynamical requirement for detailed balance, Eq. (14), is combined with the equilibrium distribution, Eq. (44). As a result, the *local detailed balance* ensues

$$\ln \frac{w_{\rho_i}(\mathbf{n})}{w_{-\rho_i}(\mathbf{n} + \mathbf{S}_{\rho_i})} = -\beta \Delta_{\rho_i} g_{\mathbf{n}}, \qquad (51)$$

<span id="page-6-1"></span>where  $\Delta_{\rho_i}$  is defined as in Eq. (22). In agreement with deterministic descriptions, see *e.g.* Ref. [25], we recover the relation between the rate constants and the standard-state chemical potentials

<span id="page-6-10"></span>
$$\ln \frac{k_{\rho_i}}{k_{-\rho_i}} = -\beta \left( \mu^{\circ} - k_B \mathsf{T1} \ln[s] \right) \cdot \mathbf{S}_{\rho_i} , \qquad (52)$$

in which  $[s] := n_s/V$  denotes the concentration of solvent. The local detailed balance (51) should be regarded as a fundamental property of the stochastic reaction rates of elementary reactions valid beyond closed CRNs. This central concept is well known in stochastic thermodynamics because it provides the connection between stochastic dynamics and nonequilibrium thermodynamics.

In open CRNs,

<span id="page-6-4"></span>
$$\ln \frac{w_{\rho}(\mathbf{n})}{w_{-\rho}(\mathbf{n} + \mathbf{S}_{\rho})} = -\beta \left( \Delta_{\rho} g_{\mathbf{n}} + \mu_{Y} \cdot \mathbf{S}_{\rho}^{Y} \right)$$
 (53)

generalizes Eq. (51), where

<span id="page-6-6"></span>
$$\mu_{Y} = \mu_{Y}^{\circ} + k_{B}T \ln\{[Y]/[s]\}$$
 (54)

<span id="page-6-2"></span>are the chemical potentials of the chemostats. The first contribution accounts for the Gibbs free energy change of the internal species, while the second one for the Gibbs free energy exchanged with the chemostats.

We introduce the *transition affinities* which quantify the force acting along each transition

<span id="page-6-8"></span>
$$A_{\rho}(\mathbf{n}) = k_{B} T \ln \frac{w_{\rho}(\mathbf{n}) p_{\mathbf{n}}}{w_{-\rho}(\mathbf{n} + \mathbf{S}_{\rho}) p_{\mathbf{n} + \mathbf{S}_{\rho}}}.$$
 (55)

They measure the distance from detailed balance (14), where they all vanish. Using Eq. (53), they can be rewritten in terms of differences of stochastic Gibbs potential (47),

<span id="page-6-7"></span>
$$A_{\rho}(\mathbf{n}) = -\Delta_{\rho} G(\mathbf{n}) + \mu_{Y} \cdot (-\mathbf{S}_{\rho}^{Y}). \tag{56}$$

This fundamental relation reveals the thermodynamic nature of the dynamical forces acting along reaction. Its early formulation for deterministic chemical kinetics is due to de Donder [38].

We will prove in § VII that our theoretical framework based on Eq. (53) guarantees that closed CRNs described

by a CME (11) relax to equilibrium, Eq. (44): the average potential  $\langle G \rangle$  is minimized by the dynamics during the relaxation and hence plays the role of a Lyapunov function.

## <span id="page-7-9"></span>C. Enthalpy and Entropy Balance

Starting from the stochastic Gibbs potential (47) and the local detailed balance (53), we now formulate the energy and entropy balance along stochastic trajectories.

The *stochastic entropy* of the CRNs follows from the derivative of the stochastic Gibbs potential (47) with respect to the temperature,

<span id="page-7-10"></span>
$$S(\mathbf{n}) = -\left(\frac{\partial G}{\partial T}\right)_{\mathbf{n}} = -k_B \ln p_{\mathbf{n}} + s_{\mathbf{n}}. \tag{57}$$

Similar to G(n), S(n) is the far-from-equilibrium fluctuating expression of the entropy [39]. The first term on the rhs is the self-information, while the second is the entropy of the state n,

<span id="page-7-11"></span>
$$s_{\mathbf{n}} = -\frac{\partial g_{\mathbf{n}}}{\partial T} = (\mathbf{s}^{\circ} + k_{\mathrm{B}} \ln n_{\mathrm{s}}) \cdot \mathbf{n} - k_{\mathrm{B}} \ln \mathbf{n}! . \tag{58}$$

It accounts for both the entropic contribution carried by each species, *i.e.* the *standard entropies of formation* 

$$\mathbf{s}^{\circ} = -\frac{\partial \mu^{\circ}}{\partial \mathsf{T}} \,, \tag{59}$$

as well as the entropic contribution due to the multiplicity of indistinguishable states. When averaged, we recover the *Gibbs–Shannon entropy* plus an internal entropy contribution,

<span id="page-7-12"></span><span id="page-7-5"></span>
$$\langle S \rangle = \sum_{\mathbf{n}} p_{\mathbf{n}} \left[ -k_{\mathbf{B}} \ln p_{\mathbf{n}} + s_{\mathbf{n}} \right]. \tag{60}$$

The enthalpy follows from

<span id="page-7-0"></span>
$$H(\mathbf{n}) = G(\mathbf{n}) + TS(\mathbf{n}) = g_{\mathbf{n}} + Ts_{\mathbf{n}} = \mathbf{h} \cdot \mathbf{n}, \quad (61)$$

where

$$h = \mu^{\circ} + Ts^{\circ} = h^{\circ} \tag{62}$$

denotes the vector of *standard enthalpies of formation*, in agreement with traditional thermodynamics of ideal dilute solutions [34]. Likewise, the chemical potentials of the chemostats, Eq. (54), will be decomposed in terms of enthalpic and entropic contributions,

<span id="page-7-1"></span>
$$\mu_{Y} = h_{Y} - Ts_{Y}, \tag{63}$$

where  $\mathbf{h}_{Y} = \mathbf{h}_{Y}^{\circ}$  and  $\mathbf{s}_{Y} = \mathbf{s}_{Y}^{\circ} - k_{B} \ln{\{[\mathbf{Y}]/[\mathbf{s}]\}}$ .

To recover the enthalpy balance along stochastic trajectories, we write the change of enthalpy as the sum of its changes due to reactions,

<span id="page-7-3"></span>
$$\Delta H[\mathfrak{n}_t] = H(\mathfrak{n}_t) - H(\mathfrak{n}_0)$$

$$= \int_0^t d\tau \sum_{\mathfrak{n},\rho} \Delta_\rho H(\mathfrak{n}) \, j_\rho(\mathfrak{n},\tau), \qquad (64)$$

where

<span id="page-7-2"></span>
$$\Delta_{\rho} H(\mathbf{n}) = \mathbf{h} \cdot \mathbf{S}_{\rho} = \underbrace{\mathbf{h} \cdot \mathbf{S}_{\rho} + \mathbf{h}_{Y} \cdot \mathbf{S}_{\rho}^{Y}}_{=: Q_{\rho}^{chm}} + \underbrace{\mathsf{Ts}_{Y} \cdot \left(-\mathbf{S}_{\rho}^{Y}\right)}_{=: Q_{\rho}^{chm}} + \underbrace{\mu_{Y} \cdot \left(-\mathbf{S}_{\rho}^{Y}\right)}_{=: W_{\rho}^{c}}, \quad \text{for all } \mathbf{n}.$$

$$(65)$$

We used Eqs. (21), (62) and (63). The first two contributions,  $Q_{\rho}^{thr}$ , account for the *heat of reaction*, *i.e.* the heat flowing from the thermal reservoir (the solvent). The third term characterizes the heat flowing from the chemostats,  $Q_{\rho}^{chm}$ . The first three terms,  $Q_{\rho}$ , integrated along the trajectory quantify the total *heat flow* 

$$Q[\mathfrak{n}_t] = \int_0^t d\tau \left\{ \sum_{\rho} Q_{\rho}^{thr} J_{\rho}(\tau) + \mathsf{T} s_{\mathsf{Y}}(\tau) \cdot \mathbf{I}^{\mathsf{Y}}(\tau) \right\} , \quad (66)$$

where the instantaneous external currents

$$\mathbf{I}^{\mathbf{Y}}(\tau) := \sum_{\rho} (-\mathbf{S}_{\rho}^{\mathbf{Y}}) \mathbf{J}_{\rho}(\tau) \tag{67}$$

give the amount of exchanged species injected in the CRN at each time, see Eq. (17).

The last term in Eq. (65),  $W_{\rho}^{c}$ , quantifies the Gibbs free energy exchanged with the chemostats. Once integrated, it gives the *chemical work* 

<span id="page-7-4"></span>
$$W_c[\mathfrak{n}_t] = \int_0^t d\tau \, \mu_Y(\tau) \cdot \mathbf{I}^Y(\tau) \,. \tag{68}$$

<span id="page-7-7"></span>From Eqs. (64)–(68), the *enthalpy balance* along a trajectory follows

<span id="page-7-6"></span>
$$\Delta H[\mathfrak{n}_{\mathsf{t}}] = Q[\mathfrak{n}_{\mathsf{t}}] + W_{\mathsf{c}}[\mathfrak{n}_{\mathsf{t}}]. \tag{69}$$

<span id="page-7-8"></span>This is the expression of the first law of thermodynamics for stochastic CRNs at the trajectory level, *cf.* [40, Eq. 2.10].

To recover the entropy balance along stochastic trajectories, we notice that since the entropy is a state function, its change along a trajectory reads

$$\Delta S[\mathfrak{n}_t] = \int_0^t d\tau \left\{ \left[ -\partial_\tau k_B \ln \mathfrak{p}_{\mathfrak{n}}(\tau) \right] \right|_{\mathfrak{n}_\tau} + \sum_{\mathfrak{n},\rho} \Delta_\rho S(\mathfrak{n}) \, j_\rho(\mathfrak{n},\tau) \right\},\tag{70}$$

as seen in Eq. (21). The changes along transitions can be recast into

$$T\Delta_{\rho}S(\mathbf{n}) = T\Delta_{\rho}s_{\mathbf{n}} - k_{B}T \ln \frac{p_{\mathbf{n}+\mathbf{S}_{\rho}}}{p_{\mathbf{n}}}$$

$$= \underbrace{\mathbf{h} \cdot \mathbf{S}_{\rho} + \mathbf{h}_{Y} \cdot \mathbf{S}_{\rho}^{Y} + Ts_{Y} \cdot \left(-\mathbf{S}_{\rho}^{Y}\right)}_{= Q_{\rho}} - \underbrace{\left[\Delta_{\rho}g_{\mathbf{n}} + k_{B}T \ln \frac{p_{\mathbf{n}+\mathbf{S}_{\rho}}}{p_{\mathbf{n}}}\right]}_{= \Delta_{\rho}G(\mathbf{n})} + \underbrace{\mu_{Y} \cdot \left(-\mathbf{S}_{\rho}^{Y}\right)}_{= W_{\rho}^{c}},$$

$$= A_{\rho}(\mathbf{n})$$

$$(71)$$

where we have used Eq. (61). As highlighted with underbraces, the first three terms are the heat flow along reactions, while the last three correspond to the affinity of transition, Eq. (56). When integrating over the whole trajectory, we recover the entropy balance

<span id="page-8-3"></span>
$$\Delta S[\mathfrak{n}_t] = \frac{1}{T} Q[\mathfrak{n}_t] + \Sigma[\mathfrak{n}_t], \tag{72}$$

where the EP (times the temperature) reads

$$\mathsf{T}\Sigma[\mathfrak{n}_{\mathsf{t}}] = \int_{0}^{\mathsf{t}} \mathsf{d}\tau \left\{ \left. \left[ -\partial_{\tau} \mathsf{k}_{\mathsf{B}} \mathsf{T} \ln \mathfrak{p}_{\mathsf{n}}(\tau) \right] \right|_{\mathfrak{n}_{\tau}} + \sum_{\mathsf{n},\rho} \mathsf{A}_{\rho}(\mathsf{n},\tau) \, \mathfrak{j}_{\rho}(\mathsf{n},\tau) \right\}$$
 (73a)

$$= k_{B} T \ln \frac{p_{n_{0}}(0)}{p_{n_{t}}(t)} + \int_{0}^{t} d\tau j_{\rho}(n,\tau) k_{B} T \ln \frac{w_{\rho}(n,\tau)}{w_{-\rho}(n+S_{\rho},\tau)}$$
(73b)

$$=W_{c}[\mathfrak{n}_{t}]-\Delta G[\mathfrak{n}_{t}]. \tag{73c}$$

The second equality follows from the definition of affinity, Eq. (55), when integrating the changes of the probability distribution. Instead, the third one readily follows from the relationship between affinity and Gibbs potential, Eq. (56). It expresses the overall energy dissipated as the difference between the Gibbs free energy supplied by the chemostats and that changing internally.

Mindful of Eq. (18), the EP can be rewritten as the ratio of the probability of observing the trajectory  $\mathfrak{n}_t$  under a forward dynamics driven by a protocol  $\pi_t$ , over the probability of observing the backward trajectory  $\mathfrak{n}_t^\dagger$  under a dynamics driven by the time-reversed protocol  $\pi^\dagger$  such that  $\pi_\tau^\dagger:=\pi_{t-\tau}$ :

<span id="page-8-0"></span>
$$\mathsf{T}\Sigma[\mathfrak{n}_{\mathsf{t}}] = k_{\mathsf{B}}\mathsf{T}\ln\frac{\mathfrak{p}_{\mathfrak{n}_{\mathsf{0}}}(0)\,\mathfrak{P}[\mathfrak{n}_{\mathsf{t}};\pi]}{\mathfrak{p}_{\mathfrak{n}_{\mathsf{t}}}(\mathsf{t})\,\mathfrak{P}[\mathfrak{n}_{\mathsf{t}}^{\dagger};\pi^{\dagger}]}\,. \tag{74}$$

This central result in stochastic thermodynamics [11, 39] was formulated for CRNs in Ref. [19] and clearly shows that the EP measures the statistical asymmetry of a trajectory under time reversal. It implies that the EP

satisfies the following integral FT

<span id="page-8-6"></span><span id="page-8-5"></span><span id="page-8-4"></span><span id="page-8-1"></span>
$$\langle \exp\{-\Sigma/k_{\rm B}\}\rangle = 1\,,\tag{75}$$

where the *ensemble average*  $\langle \cdot \rangle$  runs over all trajectories. It represents a refinement of the second law of thermodynamics at the trajectory level. Using the Jensen's inequality, the second law ensues:  $\langle \Sigma \rangle \geqslant 0$ .

*Remark* Using Eqs. (62) and (63), the local detailed balance, Eq. (53), can be rewritten as

$$k_{\rm B} \ln \frac{w_{\rho}(\mathbf{n})}{w_{-\rho}(\mathbf{n} + \mathbf{S}_{\rho})} = -\frac{1}{T} Q_{\rho}^{\rm thr} + \mathbf{s}_{\rm Y} \cdot \mathbf{S}_{\rho}^{\rm Y} + \Delta_{\rho} \mathbf{s}_{\mathfrak{n}}. \quad (76)$$

The first term is the entropy change in the thermal bath, the second one the entropy change in the chemostats, whereas the last one the internal entropy change of the CRN.

*Remark* Chemical work and Gibbs potential are defined up to a gauge, which accounts for the choice of the standard-state chemical potentials. Indeed, let us consider the following transformation,

<span id="page-8-2"></span>
$$\mu^{\circ} \to \mu^{\circ} + \sum_{\lambda} \alpha_{\lambda} \ell_{\lambda} \mu^{\circ}_{Y} \to \mu^{\circ}_{Y} + \sum_{\lambda} \alpha_{\lambda} \ell^{y}_{\lambda},$$
 (77)

where the second term is a linear combination of conservation laws. This transformation leaves affinities (56) and EP (74) unchanged, while transforming both the chemical work (69), and the Gibbs potential (47). The former changes as

<span id="page-9-1"></span>
$$W_{c}[\mathfrak{n}_{t}] \to W_{c}[\mathfrak{n}_{t}] + \sum_{\lambda_{b}} \alpha_{\lambda_{b}} \ell_{\lambda_{b}}^{y} \cdot \mathfrak{I}^{Y}[\mathfrak{n}_{t}],$$
 (78)

where

$$\mathfrak{I}^{Y}[\mathfrak{n}_{\mathsf{t}}] = \int_{0}^{\mathsf{t}} \mathsf{d}\tau \, \mathbf{I}^{Y}(\tau) \,, \tag{79}$$

are the integrated currents of exchanged species flowing in the system. Likewise, the Gibbs potential becomes

$$G(\mathbf{n}) \to G(\mathbf{n}) + \sum_{\lambda} a_{\lambda} L_{\mathbf{n}}^{\lambda}$$
 (80)

Using the properties of conservation laws, § IID, it is easy to verify that

$$\Delta L_{\lambda_u}[\mathfrak{n}_t] = 0 \,, \qquad \Delta L_{\lambda_b}[\mathfrak{n}_t] = \boldsymbol{\ell}_{\lambda_b}^y \cdot \boldsymbol{\mathfrak{I}}^Y[\mathfrak{n}_t] \,, \qquad (81)$$

which confirms that the gauge terms cancels in the EP, Eq. (73c).

Alternatively, one can apply the transformation (77) to either  $(h,h_Y)$  or  $(s^\circ,s_Y^\circ)$  and investigate how the terms in the entropy balance (72) change. In the former case, one can easily verify that both  $Q[\mathfrak{n}_t]$  and  $S(\mathfrak{n})$  are unaltered. In the latter case, instead,

$$\begin{split} S(\textbf{n}) &\rightarrow S(\textbf{n}) + \sum_{\lambda} \alpha_{\lambda} L_{\textbf{n}}^{\lambda} \text{,} \\ Q^{thr}[\mathfrak{n}_t] &\rightarrow Q^{thr}[\mathfrak{n}_t] \text{, and} \\ Q^{chm}[\mathfrak{n}_t] &\rightarrow Q^{chm}[\mathfrak{n}_t] + T \sum_{\lambda_h} \alpha_{\lambda_h} \boldsymbol{\ell}_{\lambda_h}^{y} \cdot \boldsymbol{\mathfrak{I}}^{Y}[\mathfrak{n}_t] \text{,} \end{split} \tag{82}$$

where we distinguished the thermal and chemical heat contributions.

We thus emphasize that,  $W_c$ , G(n), S(n), and  $Q^{chm}$  are not uniquely defined, in contrast to  $\Sigma$  and  $Q^{thr}$ . Despite that, once the gauge is fixed—*i.e.* the values of the standard-state quantities are chosen—they are useful concept for characterizing the dissipation of the process. Further discussions on the gauge arising in the work–potential connection will be given in § VC.

Remark Rather than defining the heat as minus the entropy change in the environment times T, Eqs. (65) and (66), we could have defined it as minus the entropy change in the thermal reservoir times T, Q<sup>thr</sup>, thus leaving the chemical part aside. Clearly, this does not affect the EP, but its expression would lose the typical Kelvin–Clausius form, Eq. (72), as it would read  $\Sigma[\mathfrak{n}_t] = \Delta S[\mathfrak{n}_t] - \frac{1}{T}Q^{thr}[\mathfrak{n}_t] - \int_0^t d\tau \, s_Y(\tau) \cdot I^Y(\tau)$ . These two different but equivalent approaches are not new to nonequilibrium thermodynamics and have been discussed in Ref. [41, Ch. III, § 3], for instance.

# <span id="page-9-2"></span>D. FT for the Chemical Work and comparison with previous results

<span id="page-9-0"></span>When combining the EP FT (75) with Eq. (73c) we immediately obtain the integral FT for the chemical work

$$\langle \exp\{-\beta(W_c - \Delta G)\}\rangle = 1.$$
 (83)

However, a Jarzynski-like integral FT [42–45] for the chemical work—i.e. expressions such as  $\langle \exp\{-\beta W_c\}\rangle = \exp\{-\beta\Delta G_{eq}\}$ —does not ensue. This relation would require that (i) the process starts and finishes at equilibrium in a closed network,  $\Delta G = \Delta G_{eq}$ —the condition on the final state can be relaxed, though—, and (ii)  $\Delta G_{eq}$  is a nonfluctuating quantity along the process, so that its exponential can be moved out of the average. However, due to broken conservation laws,  $G_{eq}$  fluctuates along any trajectory of open CRNs.

Let us consider a generic process in which the CRNs is initially closed and at equilibrium, Eq. (44), with a Gibbs free energy  $\sum_{\{L_{\lambda}\}} P(\{L_{\lambda}\}) G_{eq}(\{L_{\lambda}\})$ . The CRN is then open and driven according to some time-dependent protocol,  $\pi_{\tau}$  for  $\tau \in [0, t]$ . At time t the CRN is closed again, and let to relax to a new equilibrium distribution  $p_n^{eq_t}$ . Since the chemostatting procedure unavoidably breaks some conservation laws, the accessible state space suddenly increases. The final distribution of broken components,  $P(\{L_{\lambda_h}\};t)$ , will thus have a support broader than that of the initial distribution,  $P(\{L_{\lambda_h}\}; 0)$ , see *e.g.* Fig. 3. This process is akin to the free expansion of a gas that is initially at equilibrium in a constrained region of space. The crucial point is that the initial state is a constrained, or local, equilibrium with respect to the state space where the dynamics subsequently evolves.

The stochastic thermodynamics of these processes is characterized by absolute irreversibility [27]. Namely, when the EP (74) is integrated over all trajectories to obtain the FT (75), there are some backward trajectories whose corresponding forward probability is vanishing. These are the trajectories leading to values of the broken components not in supp  $\{P(\{L_{\lambda_b}\};0)\}$ . Since the EP of these trajectories diverges negatively, see Eq. (74), the expression of the integral FTs (75), as well as (83), is invalidated, but can be replaced by  $\langle \exp\{-\Sigma/k_B\}\rangle = 1 - \lambda_S$ , where  $0 \le \lambda_S \le 1$  measures the probability of those backward trajectories whose forward one has zero probability [27].

Hence, let us assume that supp  $\{P(\{L_{\lambda_b}\}; 0)\}$  spans all possible values of  $\{L_{\lambda_b}\}$ , so that no absolute irreversibility occurs. By conditioning the average in Eq. (83) upon observation of specific initial and final components

![](_page_10_Figure_1.jpeg)

<span id="page-10-1"></span>FIG. 3. Illustration of the evolution of the probability distribution of the broken components associated to Eq. (31b) in the CRNs in Fig. 1. As the CRN evolves, the state space enlarges, as the stochastic dynamics explores states corresponding to different broken components,  $L_{\rm b}.$  The four distribution are obtained by means of  $10^6$  trajectories simulated using the stochastic simulation algorithm. All rate constants are equal to 1, whereas the concentrations of the chemostatted species are  $[A_{\rm e}]=17$  and  $[B_{\rm e}]=10.$  The value of the enzyme moiety is  $L_{\rm E}=5.$ 

 $(\langle \cdot \rangle_{\{L_{\lambda}\},\{L_{\lambda}'\}})$  we obtain

$$\begin{split} \sum_{\{L_{\lambda}\}} & \sum_{\{L_{\lambda}'\}} P(\{L_{\lambda}\};0) \, P(\{L_{\lambda}'\};t) \\ & \exp\left\{\beta [G_{eq_t}(\{L_{\lambda}'\}) - G_{eq_o}(\{L_{\lambda}\})]\right\} \\ & \left. \left\langle \exp\left\{-\beta W_c\right\} \right\rangle_{\{L_{\lambda}\},\{L_{\lambda}'\}} = 1 \, . \end{split} \tag{84} \end{split}$$

However, this equation cannot be simplified further: since the Gibbs potential depends on the broken components, it fluctuates during the transient dynamics and an average over all components must be taken. As a result, no Jarzynski FT for the chemical work in the Gibbs ensemble can be derived.

In Ref. [19] a Jarzynski relation for the chemical work is derived using the grand canonical ensemble [19, Eq. (61)]. Translated into our notation, this result reads

$$\langle \exp\{-\beta[W_c - \Delta(\mu^{eq} \cdot \mathbf{n})]\}\rangle = \exp\{-\beta\Delta\mathfrak{G}_{eq}\}, (85)$$

where the initial and final equilibrium states are grand canonical:

<span id="page-10-3"></span>
$$p_{n}^{eq} = \exp \left\{ \beta \left[ \mathfrak{G}_{eq} - g_{n} + \mu^{eq} \cdot \mathbf{n} \right] \right\}. \tag{86}$$

The grand potential is defined as

$$\mathfrak{G} := \mathsf{G} - \boldsymbol{\mu}^{\mathrm{eq}} \cdot \boldsymbol{\mathsf{n}} \,, \tag{87}$$

and  $\mu^{eq}$  are implicitly defined by

<span id="page-10-4"></span>
$$\mu_{x}^{eq} \cdot \mathbf{S}_{o_{i}}^{x} + \mu_{v}^{eq} \cdot \mathbf{S}_{o_{i}}^{y} = 0$$
, for all  $\rho_{i}$ , (88)

[19, Eq. (27)]. The absence of the exchange transition is due to a different form of chemostatting, see remark in § II A. The grand potential is naturally suited to describe CRNs in which all species are chemostatted and  $\mu^{eq}$  are their chemical potentials. But for most CRNs, where only a subset of species are typically chemostatted, the grand potential is not the most convenient and intuitive potential to work with. The physical interpretation of the contribution  $-\Delta(\mu^{eq} \cdot n)$  is for instance not transparent. In the following sections we will make use of conservation laws to identify the potential which best describes CRNs where only a subset of species are chemostatted. New work contributions with a transparent physical interpretation will ensue.

## <span id="page-10-0"></span>IV. CRN-SPECIFIC STOCHASTIC THERMODYNAMICS

We now proceed with our main results. Making use of the conservation laws identified in § II D, we decompose the EP into three fundamental contributions: a potential difference, a contribution due to time-dependent driving, and a minimal set of contributions due to nonconservative chemical forces. To do so, we first decompose the local detailed balance and then proceed with the EP.

## A. Entropy Production

We start our EP decomposition by partitioning the set of chemostatted species **Y** into two groups, denoted by  $\mathbf{Y}_p$  and  $\mathbf{Y}_f$ . Likewise, the corresponding exchanged species are denoted by  $\mathbf{y}_p$  and  $\mathbf{y}_f$ , respectively. The former group is composed by a minimal set of chemostatted species which—when starting from the closed CRN—break all broken conservation laws. In other words, each entry of  $\mathbf{Y}_p$  breaks exactly one distinct conservation law. The remaining chemostatted species form the latter group. For a given CRN, our partitioning is not unique but the number of  $\mathbf{y}_p$  and  $\mathbf{y}_f$  is uniquely defined:  $N_{\mathbf{y}_p} = N_{\lambda_b}$  and  $N_{\mathbf{y}_f} = N_{\mathbf{y}} - N_{\lambda_b}$ , respectively, see Ex. 5. We now notice that the linear independence of  $\{\ell_\lambda\}$ 

We now notice that the linear independence of  $\{\ell_{\lambda}\}$  implies that the matrix whose rows are  $\{\ell_{\lambda_b}^{y_p}\}$  is nonsingular. We will denote by  $\{\bar{\ell}_{\lambda_b}^{y_p}\}$  the column vectors of the inverse of the latter matrix. By making use of this important property, we can recast the identity

$$\Delta_{\rho} \mathsf{L}_{\mathbf{n}}^{\lambda_{b}} \equiv \boldsymbol{\ell}_{\lambda_{b}} \cdot \mathbf{S}_{\rho} \equiv \boldsymbol{\ell}_{\lambda_{b}}^{x} \cdot \mathbf{S}_{\rho}^{x} + \boldsymbol{\ell}_{\lambda_{b}}^{y_{p}} \cdot \mathbf{S}_{\rho}^{y_{p}} + \boldsymbol{\ell}_{\lambda_{b}}^{y_{f}} \cdot \mathbf{S}_{\rho}^{y_{f}}$$
(89)

<span id="page-10-5"></span>into

<span id="page-10-2"></span>
$$\mathbf{S}_{\rho}^{y_{p}} = \Delta_{\rho} \mathbf{M}_{\mathbf{n}}^{y_{p}} - \sum_{\lambda_{b}} \overline{\ell}_{\lambda_{b}}^{y_{p}} \left[ \ell_{\lambda_{b}}^{x} \cdot \mathbf{S}_{\rho}^{x} + \ell_{\lambda_{b}}^{y_{f}} \cdot \mathbf{S}_{\rho}^{y_{f}} \right] , \quad (90)$$

where

<span id="page-11-11"></span>
$$\mathbf{M}_{\mathbf{n}}^{\mathrm{yp}} := \sum_{\lambda_{\mathrm{b}}} \overline{\ell}_{\lambda_{\mathrm{b}}}^{\mathrm{yp}} \mathbf{L}_{\mathbf{n}}^{\lambda_{\mathrm{b}}} \,.$$
 (91)

Mindful that  $\mathbf{S}_{\rho}^{Y}=-\mathbf{S}_{\rho}^{y}$  and  $\ell_{\lambda_{b}}^{x}\cdot\mathbf{S}_{\rho_{e}}^{x}=0$  for all  $\rho_{e}$ , one can use Eq. (90) to rewrite the chemical work along reactions as

$$-\mu_{Y}\cdot\boldsymbol{S}_{\rho}^{Y}=\Delta_{\rho}\left[\mu_{Y_{p}}\cdot\boldsymbol{M}_{n}^{y_{p}}\right]-\boldsymbol{\mathcal{F}}_{Y_{f}}\cdot\boldsymbol{S}_{\rho}^{Y_{f}}\text{,}\tag{92}$$

where

<span id="page-11-10"></span>
$$\mathfrak{F}_{Y_f} := \mu_{Y_f} - \mu_{Y_p} \cdot \sum_{\lambda_h} \bar{\ell}_{\lambda_h}^{y_p} \ell_{\lambda_h}^{y_f}. \tag{93}$$

A reformulation of the local detailed balance Eq. (53) readily ensues

<span id="page-11-0"></span>
$$\ln \frac{w_{\rho}(\mathbf{n})}{w_{-\rho}(\mathbf{n} + \mathbf{S}_{\rho})} = -\beta \left( \Delta_{\rho} \mathfrak{g}_{\mathbf{n}} + \mathfrak{F}_{Y_{f}} \cdot \mathbf{S}_{\rho}^{Y_{f}} \right), \quad (94)$$

where

<span id="page-11-6"></span>
$$\mathfrak{g}_{\mathfrak{n}} := \mathfrak{g}_{\mathfrak{n}} - \mu_{Y_{\mathfrak{p}}} \cdot M_{\mathfrak{n}}^{y_{\mathfrak{p}}} \,. \tag{95}$$

We now notice that the expression of the potential  $g_n$ is reminiscent of a Legendre transform of gn with respect to  $\mathbf{M}_{\mathbf{n}}^{y_p}$ , in which  $\mu_{Y_{\mathbf{n}}}$  are the conjugated intensive fields. To reveal the physical meaning of  $M_n^{y_p}$ , let us consider the case in which the broken conservation laws correspond to moieties, see § II D, and hence each species can be thought of as a composition of these. Through yp, some combinations of these moieties are exchanged with the environment. The entries of  $M_n^{y_p}$  quantify the total abundance of these combinations in state n, hence we refer to  $\mathbf{M}_{\mathbf{n}}^{\mathrm{yp}}$  as the moiety population vector. In view of this and the fact that (in general) not all moieties are exchanged, one can interpret  $g_n$  as the *semigrand Gibbs* free energy of the state n [34]. Note also that, from the definition of broken conservation law, Eq. (27), it follows that  $\Delta_{\rho_i} M_{\mathbf{n}}^{y_p} = 0$ , for all  $\rho_i$ —*viz*. internal reactions never create or destroy moieties—whereas only for  $\rho_{\text{e}}$  we have that  $\Delta_{\rho_e} M_n^{y_p} \neq 0$ —*viz.* exchange reactions introduce or remove moieties. We also mention that an alternative interpretation of  $g_n$  can be given once we rewrite it as

<span id="page-11-9"></span>
$$\mathfrak{g}_{\mathfrak{n}} := \mathfrak{g}_{\mathfrak{n}} - \sum_{\lambda_b} f_{\lambda_b} L_{\mathfrak{n}}^{\lambda_b}, \tag{96}$$

where

$$\mathsf{f}_{\lambda_{\mathsf{b}}} := \mu_{\mathsf{Y}_{\mathsf{p}}} \cdot \bar{\ell}_{\lambda_{\mathsf{b}}}^{\mathsf{y}_{\mathsf{p}}} \,. \tag{97}$$

In this form  $\mathfrak{g}_n$  is reminiscent of a Legendre transform with respect to the broken components  $\{L_n^{\lambda_b}\}$ , in which  $\{f_{\lambda_h}\}$  are the conjugated intensive fields.

In the second term on the rhs of Eq. (94),  $\mathcal{F}_{Y_f}$  identifies chemical potential gradients imposed by the chemostats on the CRN. Its entries, denoted by  $\{\mathcal{F}_{Y_f}\}$ , for  $y_f =$ 

1,...,  $N_{y_f}$ , are a maximal independent set of nonconservative chemical forces: if and only if  $\mathcal{F}_{Y_f} = 0$ , then the rhs of Eq. (94) is conservative. In this case, the CRN is detailed-balanced since the steady-state probability distribution defined by  $p_n^{eq} \propto exp\{-\beta\mathfrak{g}_n\}$  satisfies the detailed balance property, Eq. (14). Since  $\{\mathcal{F}_{y_f}\}$  make the CRN non-detailed balanced, we refer to them as fundamental nonconservative chemical forces. Equation (94) is our first major result.

To proceed with our EP decomposition, we combine Eqs. (73b) and (94),

<span id="page-11-1"></span>
$$\begin{split} T\Sigma[\mathfrak{n}_t] &= k_B T \ln \frac{p_{\mathbf{n}_0}(0)}{p_{\mathbf{n}_t}(t)} \\ &- \int_0^t d\tau \sum_{\rho,\mathbf{n}} \Delta_\rho \mathfrak{g}_{\mathbf{n}}(\tau) \, j_\rho(\mathbf{n},\tau) + \sum_{y_f} W_{y_f}^{nc}[\mathfrak{n}_t] \,, \quad (98) \end{split}$$

where

<span id="page-11-5"></span>
$$W_{y_f}^{\text{nc}}[\mathfrak{n}_t] := \int_0^t d\tau \, \mathcal{F}_{y_f}(\tau) I_{y_f}(\tau) \,. \tag{99}$$

<span id="page-11-2"></span> $\{I_{y_f}(\tau)\}\$ , for  $y_f=1,\ldots,N_{y_f}$ , denote the entries of the instantaneous external currents corresponding to  $Y_f$ , Eq. (67). We now recall that  $\mathfrak{g}_n$  is a state function, hence

$$\Delta \mathfrak{g}[\mathfrak{n}_{t}] = W_{d}[\mathfrak{n}_{t}] + \int_{0}^{t} d\tau \sum_{\rho, n} \Delta_{\rho} \mathfrak{g}_{n}(\tau) \, \mathfrak{j}_{\rho}(n, \tau) \,, \tag{100}$$

where

<span id="page-11-4"></span><span id="page-11-3"></span>
$$\begin{split} W_{d}[\mathfrak{n}_{t}] &:= \int_{0}^{t} d\tau \left[ \partial_{\tau} \mathfrak{g}_{\mathfrak{n}}(\tau) \right] \Big|_{\mathfrak{n}_{\tau}} \\ &= \int_{0}^{t} d\tau \left[ -\partial_{\tau} \mu_{Y_{p}}(\tau) \right] \cdot M_{\mathfrak{n}_{\tau}}^{y_{p}} \,. \end{split} \tag{101}$$

Therefore, combining Eqs. (98) and (100) we obtain

$$\mathsf{T}\Sigma[\mathfrak{n}_{\mathsf{t}}] = -\Delta \mathcal{G}[\mathfrak{n}_{\mathsf{t}}] + W_{\mathsf{d}}[\mathfrak{n}_{\mathsf{t}}] + \sum_{\mathsf{y}_{\mathsf{f}}} W_{\mathsf{y}_{\mathsf{f}}}^{\mathsf{nc}}[\mathfrak{n}_{\mathsf{t}}],$$
 (102)

<span id="page-11-7"></span>where the first term is the difference of *stochastic semi-grand Gibbs potential* 

<span id="page-11-8"></span>
$$\mathfrak{G}(\mathfrak{n}) := k_{\mathrm{B}} \mathsf{T} \ln \mathfrak{p}_{\mathfrak{n}} + \mathfrak{g}_{\mathfrak{n}} \,. \tag{103}$$

The EP decomposition in Eq. (102) is a major result of our paper. The first term on the rhs constitutes the conservative force contribution of the EP. It describes the dissipation due to overall changes of thermodynamic state variables: enthalpy, H(n), entropy, S(n), and chemical energy  $\{\,\mu_{Y_p}\cdot M_n^{y_p}\,\}$ . The second term, Eq. (101), arises in presence of time-dependent driving and accounts for the changes caused by manipulations of the chemical potentials  $\mu_{Y_p}$ . As it is a controlled way of

changing the Gibbs free energy landscape of the CRN, we refer to it as driving chemical work. Finally, for each exchanged species Y<sub>f</sub>, a nonconservative force contribution (99) arises,  $\{W_{y_f}^{nc}\}$ . All together, they account for the chemical energy flowing between different chemostats across the CRN, and we refer to them as nonconservative chemical work contributions. Equation (102) holds for an arbitrary CRN, yet it is CRN-specific, as it is derived using the topological properties of the CRN encoded in the conservation laws. To gain more intuition, we now focus on specific classes of CRNs, whose resulting decomposition is summarized in Tab. II. In § IV B we continue our discussion on the work contributions W<sub>d</sub> and  $\{W_{11c}^{nc}\}$ , whereas in Ex. 5 and in § VIII we evaluate them for specific models. Finally, in §§ VI and VII we will further explore the implications of Eq. (102).

Autonomous Detailed-Balanced CRNs: The CRN is autonomous and all fundamental forces vanish. The trajectory EP becomes minus a potential difference,

$$\mathsf{T}\Sigma[\mathfrak{n}_\mathsf{t}] = -\Delta \mathfrak{G}[\mathfrak{n}_\mathsf{t}] \,. \tag{104}$$

We will prove in § VII that this is the class of open CRNs which relax to equilibrium and in which the average potential  $\langle G \rangle$  is minimized at equilibrium by the dynamics described by CME (11).

Unconditionally Detailed-Balanced CRNs: The set of species  $Y_f$  is empty—i.e. each exchanged species breaks a conservation law—and no fundamental force arises. Hence, these CRNs are detailed-balanced irrespective of the values of  $\mu_Y$ , but the time-dependent driving prevents them from reaching equilibrium, and their EP reads

<span id="page-12-4"></span>
$$\mathsf{T}\Sigma[\mathfrak{n}_{\mathsf{t}}] = -\Delta \mathfrak{G}[\mathfrak{n}_{\mathsf{t}}] + W_{\mathsf{d}}[\mathfrak{n}_{\mathsf{t}}]. \tag{105}$$

Autonomous CRNs: The driving work vanishes and the forces are constant in time. Hence, the EP becomes

$$T\Sigma[\mathfrak{n}_{t}] = -\Delta \mathfrak{G}[\mathfrak{n}_{t}] + \sum_{\mathfrak{u}_{t}} \mathfrak{F}_{\mathfrak{Y}_{f}} \mathfrak{I}_{\mathfrak{Y}_{f}}[\mathfrak{n}_{t}]. \tag{106}$$

The nonconservative chemical work display a typical current–force structure. In the long time limit,  $\Delta \mathcal{G}[\mathfrak{n}_t]$  is typically subextensive in time, and we obtain the EP typical of nonequilibrium steady states

$$\mathsf{T}\Sigma[\mathfrak{n}_{\mathsf{t}}] \stackrel{\mathsf{t}\to\infty}{=} \sum_{\mathsf{u}_{\mathsf{t}}} \mathcal{F}_{\mathsf{y}_{\mathsf{f}}} \mathcal{I}_{\mathsf{y}_{\mathsf{f}}}[\mathfrak{n}_{\mathsf{t}}], \tag{107}$$

see Eq. (79). In other words,  $T\Sigma[n_t]$  is dominated by the dissipative flows of chemicals across the CRN.

*Remark* For CRN with infinite number of species and reactions—*e.g.* aggregation–fragmentation and polymerization processes [46–48]—the CRN may undergo steady growth regimes in which  $\Delta \mathcal{G}$  is not subextensive in time and cannot be neglected in long-time limit.

| dynamics                          | $-\Delta 9$  | $W_{\rm d}$  | Wnc          |
|-----------------------------------|--------------|--------------|--------------|
| autonomous detailed-balanced      | <b>√</b>     | О            | О            |
| unconditionally detailed-balanced | $\checkmark$ | $\checkmark$ | О            |
| autonomous                        | $\checkmark$ | O            | $\checkmark$ |
| nonequilibrium steady state       | О            | О            | ✓            |

<span id="page-12-1"></span>TABLE II. Entropy production for specific processes. "o" (resp. " $\checkmark$ ") denotes a vanishing (resp. a finite) contribution.

Remark Our EP decomposition is not unique and different expressions for  $\mathfrak{g}_n$  and  $\mathcal{F}_{Y_f}$  correspond to different ways of partitioning Y into  $Y_p$  and  $Y_f$ .

<span id="page-12-0"></span>**Example 5.** For the open CRN in Fig. 1, the chemostatted species can be split into  $\mathbf{Y}_p$  and  $\mathbf{Y}_f$  in two possible—and trivial—ways: either A is regarded as the species breaking the conservation law (31b), or B. We consider the former choice,  $\mathbf{y}_p = (A)$  and  $\mathbf{y}_f = (B)$ . Since  $\ell_A^b = 1$ , the only entry of the moiety vector reads,

$$M_{\mathbf{n}}^{A} = n_{E^*} + n_{E^{**}} + n_A + n_B = L_{\mathbf{n}}^{b}$$
, (108)

which is equal to the total abundance of the A–B moiety. The intensive variable conjugated to the broken conservation law is equal to the chemical potential of  $A_{\rm e^\prime}$ 

<span id="page-12-2"></span>
$$f_b = \mu_{A_o}. \tag{109}$$

The potential thus readily follows from Eq. (95)—or equivalently Eq. (96)—,

$$g_{\mathbf{n}} = g_{\mathbf{n}} - \mu_{\mathbf{A}_{\mathbf{n}}} M_{\mathbf{n}}^{\mathbf{A}}. \tag{110}$$

The instantaneous driving work rate associated to any manipulation of the latter potential is

<span id="page-12-3"></span>
$$\dot{W}_{\rm d}(\mathbf{n}) = -\partial_{\rm t} \mu_{\rm A_o} M_{\rm n}^{\rm A} \,. \tag{111}$$

Once integrated over a trajectory, it gives the driving work, Eq. (101). Since  $\mathbf{y}_f = (B)$ , the conjugated fundamental chemical force reads

$$\mathcal{F}_{\mathsf{B}_{\mathsf{e}}} = \mu_{\mathsf{B}_{\mathsf{e}}} - \mu_{\mathsf{A}_{\mathsf{e}}}.\tag{112}$$

and the instantaneous dissipative contribution due to this force is

$$\dot{W}_{B_e}^{nc} = \mathcal{F}_{B_e} I_{B_e} , \qquad (113)$$

where  $I_{B_e} = J_{+b} - J_{-b}$ . When integrated over a trajectory, it measures the work spent to sustain a current between  $A_e$  and  $B_e$  across the CRN. A pictorial illustration of the work contributions is given in Fig. 4. The trajectory EP thus reads

$$\begin{split} \mathsf{T}\Sigma[\mathfrak{n}_t] &= \int_0^t d\tau \big[ - \vartheta_\tau \mu_{A_e}(\tau) M_\mathbf{n}^A \big] \big|_{\mathbf{n}_\tau} - \Delta \mathfrak{G}[\mathfrak{n}_t] \\ &+ \int_0^t d\tau \, \mathfrak{F}_{B_e}(\tau) I_{B_e}(\tau) \,. \quad \Box \quad \text{(114)} \end{split}$$

![](_page_13_Picture_1.jpeg)

FIG. 4. Pictorial illustration of the work contributions. The driving one arises when the chemical potential of the chemostat  $A_{\rm e}$  changes in time. The nonconservative chemical work, instead, characterizes the sustained conversion of A into B.

#### <span id="page-13-7"></span><span id="page-13-1"></span><span id="page-13-0"></span>B. Energy Balance

In Eq. (102), the driving and nonconservative chemical work,  $W_d$  and  $\{W_{y_f}^{nc}\}$ , emerge as dissipative contributions. To strengthen their interpretation as work contributions, we now show that they can also be described as part of an energy balance. For this purpose, let us introduce the *semigrand enthalpy* [49],

$$\mathcal{H}(n):=\mathsf{H}(n)-\mu_{Y_p}\cdot M_n^{y_p}=\mathcal{G}(n)+\mathsf{TS}(n)\,. \eqno(115)$$

This CRN-specific potential quantifies the portion of energy which is not attributed to volume (-pV, where p is the external pressure) and exchanged moieties,  $\mu_{Y_p} \cdot M_n^{y_p}$ . It accounts for the energy stored in its internal chemical composition, *i.e.* the internal species x and the unbroken components { $L_{\lambda_u}$ }. When combining its definition with the enthalpy and entropy balances, Eqs. (69), (72) and (102), we obtain

$$\Delta\mathcal{H}[\mathfrak{n}_t] = Q[\mathfrak{n}_t] + W_d[\mathfrak{n}_t] + \sum_{y_f} W_{y_f}^{nc}[\mathfrak{n}_t],$$
 (116)

*viz.* the overall change of semigrand enthalpy is equal to the sum of heat flow, driving and nonconservative chemical work. By analogy with Eq. (69), this can be interpreted as a CRN-specific formulation of the first law.

In § III C, we introduced the chemical work as the Gibbs free energy exchanged with the chemostats, Eq. (68). By comparing Eqs. (61) and (116), we obtain its relationship with  $W_d$  and  $\{W_{lf}^{nc}\}$ ,

$$W_{\rm c}[\mathfrak{n}_{\rm t}] - \Delta \left[ \mu_{\rm Y_p} \cdot M_{\mathfrak{n}}^{\rm y_p} \right] = W_{\rm d}[\mathfrak{n}_{\rm t}] + \sum_{\rm y_f} W_{\rm y_f}^{\rm nc}[\mathfrak{n}_{\rm t}] \,.$$
 (117)

We emphasize that in contrast to the chemical work, the driving one does not account for direct exchanges of Gibbs free energy, but it captures the instantaneous changes of the chemostats Gibbs free energy.

Remark The driving work is reminiscent of the mechanical work as defined in stochastic thermodynamics. In this framework,  $W_{\text{mech}}[\mathfrak{n}_t] = \int_0^t d\tau \ \partial_\tau \mathsf{E}_{\mathfrak{n}}(\tau)|_{\mathfrak{n}_\tau}$ , describes internal energy changes due to external time-dependent control, see *e.g.* [44, 50]. In CRNs, the time-dependent control is exerted via the chemostats, and  $W_d[\mathfrak{n}_t]$  indeed accounts for this fact.

## C. Equilibrium of open CRNs

We have already seen that in absence of fundamental forces, the rhs of the local detailed balance (94) becomes a state function difference. The steady-state probability distribution

<span id="page-13-5"></span>
$$p_{eq}(\mathbf{n}|\{L_{\lambda_u}\}) = \frac{\exp\{-\beta\mathfrak{g}_{\mathbf{n}}\}}{\mathcal{Z}(\{L_{\lambda_u}\})} \prod_{\lambda_u} \delta[L_{\mathbf{n}}^{\lambda_u}, L_{\lambda_u}]. \tag{118}$$

satisfies the detailed balance property (53) and therefore characterizes the equilibrium of open CRNs. Not accidentally, the relationship between the partition function  $\mathcal{Z}(\{L_{\lambda_u}\})$  and that of closed CRNs, Eq. (43),

<span id="page-13-6"></span>
$$\begin{split} \mathcal{Z}(\{L_{\lambda_{\mathbf{u}}}\}) &= \sum_{\mathbf{m}} \exp\left\{-\beta \mathfrak{g}_{\mathbf{m}}\right\} \prod_{\lambda_{\mathbf{u}}} \delta\left[L_{\mathbf{m}}^{\lambda_{\mathbf{u}}}, L_{\lambda_{\mathbf{u}}}\right] \\ &= \sum_{\{L_{\lambda_{\mathbf{h}}}\}} \exp\left\{\beta \sum_{\lambda_{\mathbf{b}}} f_{\lambda_{\mathbf{b}}} L_{\lambda_{\mathbf{b}}}\right\} Z(\{L_{\lambda}\}), \end{split} \tag{119}$$

is akin to that between canonical and grand canonical partition functions, see *e.g.* [51]. With an ensemble of unbroken components,  $P(\{L_{\lambda_u}\})$ , the constrained equilibrium distribution reads

<span id="page-13-3"></span>
$$\begin{aligned} p_{\mathbf{n}}^{\text{eq}} &= \sum_{\{L_{\lambda_b}\}} p_{\text{eq}}(\mathbf{n} | \{L_{\lambda_u}\}) P(\{L_{\lambda_u}\}) \\ &= p_{\text{eq}}(\mathbf{n} | \{L_{\mathbf{n}}^{\lambda_u}\}) P(\{L_{\mathbf{n}}^{\lambda_u}\}), \end{aligned} \tag{120}$$

<span id="page-13-2"></span>where  $p_{eq}(n|\{L_n^{\lambda_u}\})$  is the probability distribution of observing the state n given its stoichiometric compatibility class. Equation (120) thus generalizes the equilibrium probability distribution (44) to open CRNs.

Importantly, the average semigrand Gibbs potential (103) takes its minimum value at  $p_n^{eq}$ , Eq. (120), where it reduces to the equilibrium semigrand Gibbs potential,

$$\mathcal{G}_{eq}(\{L_{\lambda_u}\}) = -k_BT\ln\mathcal{Z}(\{L_{\lambda_u}\}) + k_BT\ln P(\{L_{\lambda_u}\})\,, \ \ \textbf{(121)}$$

averaged over  $P(\{L_{\lambda_n}\})$ . Indeed,

$$\langle \mathfrak{G} \rangle - \langle \mathfrak{G}_{eq} \rangle_{L_{tt}} = \langle \mathfrak{G} - \mathfrak{G}_{eq} \rangle = k_B T \, \mathfrak{D}(\mathfrak{p} \| \mathfrak{p}_{eq}) \geqslant 0$$
, (122)

where

<span id="page-13-4"></span>
$$\label{eq:geq} \left\langle \mathfrak{G}_{eq} \right\rangle_{L_u} \equiv \textstyle \sum_{\{L_{\lambda_u}\}} P(\{L_{\lambda_u}\}) \mathfrak{G}_{eq}(\{L_{\lambda_u}\}) \,. \tag{123}$$

The first equality follows from the fact that  $g_{eq}$  is non-fluctuating, since it depends solely on the unbroken components. As for the Gibbs free energy in closed CRNs, we will show later (§ VII) that Eq. (122) quantifies the average dissipation during the relaxation to equilibrium.

## D. Dissipation Balance along Stoichiometric Cycles

We can now formulate the EP decomposition in term of stoichiometric cycles affinities. These are defined as the sum of the transition affinities along stoichiometric cycles  $\{c \equiv \rho_{c1}, \rho_{c1}, \dots, \rho_{cN_c}\}$ ,

<span id="page-14-0"></span>
$$\begin{split} \mathcal{A} &:= A_{\rho_c 1}(n) + A_{\rho_c 2}(n + S_{\rho_c 1}) + \dots \\ &\dots + A_{\rho_c N_c}(n + \sum_{j=1}^{N_c - 1} S_{\rho_c j}) \,. \end{split} \tag{124}$$

Using Eq. (56), and the fact that  $-\Delta_{\rho} G(n)$  vanishes when summed over the loop c, we obtain

$$\mathcal{A} = -\mu_{Y} \cdot \sum_{i=1}^{N_{c}} \mathbf{S}_{\rho_{c}i}^{Y} = -\mu_{Y} \cdot \sum_{\rho} \mathbf{S}_{\rho}^{Y} c_{\rho}. \tag{125}$$

Since  $\sum_{\rho} \mathbf{S}_{\rho}^{\Upsilon} \mathbf{c}_{\rho}^{\alpha} = 0$ , those evaluated along the stochiometric cycles of the closed CRN,  $\{\mathbf{c}^{\alpha}\}$ , always vanish. In contrast, those along the emergent cycles,  $\{\mathbf{c}^{\eta}\}$ , do not vanish in general,

<span id="page-14-8"></span>
$$\mathcal{A}_{\eta} = \mu_{Y} \cdot \mathbf{C}_{\eta}^{Y}, \tag{126}$$

see Eq. (36). These affinities can be thus understood as the chemical potential gradient imposed by the chemostats on the cycle.

To rewrite the EP (102) in terms  $\{A_{\eta}\}$ , let us highlight their relationship with the fundamental forces,

$$\mathcal{A}_{\eta} = \mathcal{F}_{Y_f} \cdot \mathbf{C}_{\eta}^{Y_f}, \tag{127}$$

which is obtained when summing the local detailed balance (94) along  $\{c^{\eta}\}$  as in Eq. (124). Since the matrix whose columns are  $\{C_{\eta}^{Y_f}\}$  is square and nonsingular—as it can be deduced from the linear independence of the set of emergent cycles—, we can invert it and write

$$\mathfrak{F}_{Y_f} = \sum_{\eta} \overline{C}_{\eta}^{Y_f} \mathcal{A}_{\eta} , \qquad (128)$$

where  $\{\overline{C}_{\eta}^{Y_f}\}$  denote the rows of the inverse matrix. This relation clarifies the one-to-one correspondence which lies between  $\{\mathcal{F}_{y_f}\}$  and  $\{\mathcal{A}_{\eta}\}$ . Inserting the last expression in the local detailed balance, Eq. (94), we obtain

$$\ln \frac{w_{\rho}(\mathbf{n})}{w_{-\rho}(\mathbf{n} + \mathbf{S}_{\rho})} = -\beta \left( \Delta_{\rho} \mathfrak{g}_{\mathbf{n}} - \sum_{\eta} A_{\eta} \zeta_{\eta,\rho} \right), \quad (129)$$

where the coefficients

<span id="page-14-4"></span>
$$\zeta_{\eta,\rho} := -\overline{C}_{\eta}^{Y_f} \cdot \mathbf{S}_{\rho}^{Y_f} \tag{130}$$

quantify how much each reaction contributes to the emergent cycles. Algebraically, the row vectors  $\{\zeta_{\eta}\}$  are dual to the cycles,  $\{c^{\eta}\}$ ,

$$\zeta_{\eta} \cdot c^{\eta'} = -\sum_{\rho} \overline{C}_{\eta}^{Y_f} \cdot S_{\rho}^{Y_f} c_{\rho}^{\eta'} = \overline{C}_{\eta}^{Y_f} \cdot C_{\eta'}^{Y_f} = \delta_{\eta,\eta'}.$$
 (131)

As previously done for Eq. (102), when integrating the trajectory EP (73b) with the local detailed balance (129) we obtain

<span id="page-14-5"></span>
$$\mathsf{T}\Sigma[\mathfrak{n}_{\mathsf{t}}] = -\Delta \mathfrak{G}[\mathfrak{n}_{\mathsf{t}}] + W_{\mathsf{d}}[\mathfrak{n}_{\mathsf{t}}] + \sum_{\mathsf{n}} \mathsf{\Gamma}_{\mathsf{n}}[\mathfrak{n}_{\mathsf{t}}].$$
 (132)

The stochastic semigrand Gibbs potential and the driving work read as in Eqs. (103) and (101), respectively. For each emergent stoichiometric cycle,

<span id="page-14-2"></span>
$$\Gamma_{\eta}[\mathfrak{n}_{t}] := \int_{0}^{t} d\tau \,\mathcal{A}_{\eta}(\tau) \sum_{\rho} \zeta_{\eta,\rho} J_{\rho}(\tau) \,. \tag{133}$$

quantifies the chemical work spent to sustain the related cyclic flow of chemicals. For autonomous CRNs

<span id="page-14-3"></span>
$$\mathsf{T}\Sigma[\mathfrak{n}_{\mathsf{t}}] = -\Delta \mathfrak{G}[\mathfrak{n}_{\mathsf{t}}] + \sum_{\mathsf{n}} \mathcal{A}_{\mathsf{n}} \mathcal{J}_{\mathsf{n}}[\mathfrak{n}_{\mathsf{t}}], \tag{134}$$

where

$$\mathcal{J}_{\eta}[\mathfrak{n}_{\mathsf{t}}] := \int_{0}^{\mathsf{t}} d\tau \sum_{\rho} \zeta_{\eta,\rho} J_{\rho}(\tau) \tag{135}$$

quantifies the integrated current along the cycle  $\eta$ . In the long-time limit, in which  $\Delta \mathcal{G}[\mathfrak{n}_t]$  is negligible, we obtain

<span id="page-14-6"></span>
$$\mathsf{T}\Sigma[\mathfrak{n}_{\mathsf{t}}] \stackrel{\mathsf{t}\to\infty}{=} \sum_{\mathsf{\eta}} \mathcal{A}_{\mathsf{\eta}} \mathcal{J}_{\mathsf{\eta}}[\mathfrak{n}_{\mathsf{t}}]. \tag{136}$$

<span id="page-14-7"></span>When all emergent cycle affinities vanish—as well as when no emergent cycle is created—, the CRN becomes detailed-balanced, in agreement with the Kolmogorov–Wegscheider condition [52–54].

We emphasize that the cycle chemical work contributions and currents, Eqs. (133) and (135), can be written as combinations of fundamental external currents,  $\{I^{Y_f}\}$  Eq. (67), via Eq. (130). The added value of Eq. (102) over (132) lies in the fact that each force is conjugated to the external current of only one external species.

<span id="page-14-1"></span>Remark An alternative approach that can be used for cycle EP decompositions is the graph-theoretic one based on the identification of the loops appearing in the network of transitions [2, 55]. Once these loops are identified, they can be sorted according to the chemostats they are coupled to, as these determine their affinity, see Eq. (124). Equivalently, loops are classified according to the stoichiometric cycle they correspond to. In Ref. [56], a graph-theoretic approach based on loop affinities led to the expression analogous to Eq. (136). In contrast, our cycles EP decomposition is based on a stoichiometric approach: emergent cycles are directly identified by the kernels of  $S_{\rm i}$  and  $S_{\rm i}$ .

This observation points out the redundancy which is intrinsic in bare graph-theoretic EP decompositions: many loops may be coupled to the same set of reservoirs and thus carry the same affinity, while many others may carry a vanishing affinity—for CRN these latter are those corresponding to stoichiometric cycles of the closed network, {  $c^{\alpha}$  }. For generic networks, a systematic way of identifying these so-called *symmetries* was derived in Ref. [57], whereas in Ref. [58] they are used to formulate generic thermodynamic—rather than mere graph-theoretic—EP decompositions.

**Example 6.** The emergent cycle affinity corresponding to the emergent stoichiometric cycle (39) reads

$$A = \mu_{B_e} - \mu_{A_e} = \mathcal{F}_{B_e} \,. \tag{137}$$

The contributions to the corresponding cycle current follows from Eq. (130),

$$\zeta = \begin{pmatrix} +1 & +2 & +3 & +4 & +\alpha & +b \\ \zeta = \begin{pmatrix} 0 & 0 & 0 & 0 & -1 \end{pmatrix}.$$
 (138)

The entries corresponding to the backward reactions are minus those of the forward. Notice that, since the CRN has exactly one emergent cycle, the force and cycle EP decompositions are identical, see Eq. (127).

#### <span id="page-15-0"></span>V. SEMIGRAND GIBBS POTENTIAL

We here further elaborate on equilibrium distributions and semigrand Gibbs potentials by addressing three points: (i) the relationship between Eq. (120), and the equilibrium distributions as expressed in chemical reaction network theory; (ii) the role of conservation laws for characterizing the dissipation of CRNs subject to sequential introduction of exchanged species; (iii) the gauge freedom intrinsic to the definition of driving work. This section can be skipped at a first read.

## <span id="page-15-1"></span>A. Equilibrium Distributions in Chemical Reaction Network Theory

In Ref. [22] (see also [59]) equilibrium distributions of CRNs are proven to be multi-Poissonian

$$p_{eq}(\mathbf{n}|\{L_{\lambda_u}\}) = \frac{\exp\left\{\mathbf{n} \cdot \ln\left\{[\mathbf{z}]_{eq}V\right\}\right\}}{\mathbf{n}! \, \mathcal{Z}(\{L_{\lambda_u}\})} \prod_{\lambda_u} \delta\left[L_{\mathbf{n}}^{\lambda_u}, L_{\lambda_u}\right], \tag{139}$$

where  $[\mathbf{z}]_{eq}$  is the equilibrium concentration distribution of the same CRN described by a set of deterministic rate equations.  $\mathcal{Z}(\{L_{\lambda_u}\})$  is again a normalizing factor. To highlight the relationship between this equation and Eqs. (120) and (86), we need to recall that, for deterministic CRNs, thermodynamic equilibrium is defined by the fact that chemical potential differences along all reactions vanish, see Eqs. (88) and (A8). As observed in Ref. [25], this entails that

<span id="page-15-2"></span>
$$\mu^{eq} = \sum_{\lambda} f_{\lambda} \ell_{\lambda} \,, \tag{140}$$

where  $\{f_{\lambda}\}$  are real coefficients depending on  $\mu_{Y}$  and  $\{L_{\lambda_{u}}\}$ . Those related to the broken components,  $\{f_{\lambda_{b}}\}$ , are indeed those appearing in Eq. (97). Using the expression of chemical potential valid in the thermodynamic limit, Eq. (A7), we therefore have

$$\ln \{ [\mathbf{z}]_{eq} V \} = -\beta (\mu^{\circ} - k_B T \ln n_s - \sum_{\lambda} f_{\lambda} \ell_{\lambda}), \quad (141)$$

from which

$$\begin{split} n \cdot \ln \left\{ [\mathbf{z}]_{eq} V \right\} - \ln n! &= -\beta \left( \mathfrak{g}_{\mathfrak{n}} - \mu^{eq} \cdot \mathbf{n} \right) \\ &= -\beta \left( \mathfrak{g}_{\mathfrak{n}} - \sum_{\lambda_u} f_{\lambda_u} L_{\mathfrak{n}}^{\lambda_u} \right) \end{split} \tag{142}$$

ensues. At this point, Eqs. (86), (118), and (139) appear identical up to  $\sum_{\lambda_u} f_{\lambda_u} L_n^{\lambda_u}$ . However, since this term involves only the unbroken components it vanishes in Eq. (139). This shows the connection between the CRN theoretical and thermodynamic expression of equilibrium distributions.

## B. Hierarchies of Equilibriums

We here show that when starting from a closed CRN, a sequential introduction of exchange reactions that keep the CRN detailed balanced drives it down in semigrand Gibbs potential by equilibrating previously constrained degrees of freedom: the conservation laws, see Fig. 5. Let us imagine a closed CRN whose initial probability distribution is  $p_{\mathbf{n}}(0) = \sum_{\{L_{\lambda}\}} p_{0}(\mathbf{n}|\{L_{\lambda}\}) \, P_{0}(\{L_{\lambda}\})$ , where  $P_{0}(\{L_{\lambda}\}) = \prod_{\lambda} P_{0}^{\lambda}(L_{\lambda})$ , i.e. different components are independently distributed. As it relaxes to equilibrium,  $P_{0}(\{L_{\lambda}\})$  will not change, while  $p_{0}(\mathbf{n}|\{L_{\lambda}\})$  will relax to Eq. (41). The average dissipation is

$$T\left\langle \Sigma\right\rangle = -\Delta\left\langle G\right\rangle = \sum_{\{L_{\lambda}\}} P_{0}(\{L_{\lambda}\}) \left[ k_{B}T \sum_{\mathbf{n}} p(\mathbf{n}|\{L_{\lambda}\}) \ln \frac{p(\mathbf{n}|\{L_{\lambda}\})}{p_{eq}(\mathbf{n}|\{L_{\lambda}\})} \right] \equiv \sum_{\{L_{\lambda}\}} P_{0}(\{L_{\lambda}\}) \left[ -\Delta\left\langle G(\{L_{\lambda}\})\right\rangle \right].$$

This expression is obtained when combining the properties of the Gibbs potential, Eq. (49), with the equilibrium distribution of closed CRNs, Eq. (44). It shows that the average drop of Gibbs free energy can be expressed as the weighted average of the drops of Gibbs free energy at given components,  $-\Delta \langle G(\{L_{\lambda}\}) \rangle$ .

We now open the CRN by chemostatting one species. Hence, one conservation law is broken, *e.g.* the total mass  $\ell_{\lambda_1}$ , and the CRN relaxes to a new equilibrium, Eq. (120), whose partition function is denoted by  $\mathfrak{Z}_{\lambda_1}$ , Eq. (119). Clearly,  $\mathsf{P}^{\lambda}_0(\mathsf{L}_{\lambda})$ , for  $\lambda \neq \lambda_1$ , will not change during the relaxation, and we can rewrite the new equilibrium as

$$p_{eq}^{(\lambda_1)}(\mathbf{n}) = \frac{exp\left\{-\beta g_{\mathbf{n}} + \beta f_{\lambda_1} L_{\mathbf{n}}^{\lambda_1}\right\}}{\mathcal{Z}_{\lambda_1}(\{L_{\mathbf{n}}^{\lambda}\}_{\lambda \neq \lambda_1})} \prod_{\lambda \neq \lambda_1} P_0^{\lambda}(L_{\mathbf{n}}^{\lambda}) = \underbrace{\frac{exp\left\{-\beta g_{\mathbf{n}}\right\}}{Z(\{L_{\mathbf{n}}^{\lambda}\})}}_{=p_{eq}(\mathbf{n}|\{L_{\mathbf{n}}^{\lambda}\})} \underbrace{\frac{Z(\{L_{\mathbf{n}}^{\lambda}\}) \ exp\left\{\beta f_{\lambda_1} L_{\mathbf{n}}^{\lambda_1}\right\}}{\mathcal{Z}_{\lambda_1}(\{L_{\mathbf{n}}^{\lambda}\}_{\lambda \neq \lambda_1})}}_{=:P_{eq}(L_{\mathbf{n}}^{\lambda_1}|\{L_{\mathbf{n}}^{\lambda}\}_{\lambda \neq \lambda_1})} \prod_{\lambda \neq \lambda_1} P_0^{\lambda}(L_{\mathbf{n}}^{\lambda}). \quad (144)$$

The first term is the equilibrium distribution of the closed CRN, while the second can be interpreted as the equilibrium distribution of the broken component, for given unbroken component. In other words, the final equilibrium can be understood as a closed CRN equilibrium with an equilibrium probability distribution over the broken component. Hence, the average amount of semigrand Gibbs free energy,  $g_{\lambda_1}(\mathbf{n}) = G(\mathbf{n}) - f_{\lambda_1} L_{\mathbf{n}}^{\lambda_1}$ , dissipated during the relaxation can be written as

$$-\Delta \left\langle \mathcal{G}_{\lambda_{1}} \right\rangle = k_{B} \mathsf{T} \sum_{\mathbf{n}} \mathsf{p}_{eq}(\mathbf{n} | \{\mathsf{L}_{\mathbf{n}}^{\lambda}\}) \prod_{\lambda} \mathsf{P}_{0}^{\lambda}(\mathsf{L}_{\mathbf{n}}^{\lambda}) \ln \frac{\mathsf{P}_{0}^{\lambda_{1}}(\mathsf{L}_{\mathbf{n}}^{\lambda_{1}})}{\mathsf{P}_{eq}(\mathsf{L}_{\mathbf{n}}^{\lambda_{1}} | \{\mathsf{L}_{\mathbf{n}}^{\lambda}\}_{\lambda \neq \lambda_{1}})}, \tag{145}$$

upon application of Eqs. (122) with the distributions (44) and (144). When rewriting this expression as a sum over all values of the components and performing the summation over the states of  $p_{eq}(n|\{L^{\lambda}\})$  we finally obtain

$$\begin{split} -\Delta \left\langle \mathcal{G}_{\lambda_{1}} \right\rangle &= \sum_{\{L_{\lambda}\}_{\lambda \neq \lambda_{1}}} P_{0}^{\lambda}(L_{\lambda}) \left[ \sum_{L_{\lambda_{1}}} P_{0}^{\lambda_{1}}(L_{\lambda_{1}}) k_{B} T \ln \frac{P_{0}^{\lambda_{1}}(L_{\lambda_{1}})}{P_{eq}(L_{\lambda_{1}} | \{L_{\lambda}\}_{\lambda \neq \lambda_{1}})} \right] \\ &= \sum_{\{L_{\lambda}\}_{\lambda \neq \lambda_{1}}} P_{0}^{\lambda}(L_{\lambda}) \left[ -\Delta \left\langle \mathcal{G}_{\lambda_{1}}(\{L_{\lambda}\}_{\lambda \neq \lambda_{1}}) \right\rangle \right] \,. \end{split} \tag{146}$$

In the first line we recognize the relative entropy between the initial probability of the broken component,  $P_0^{\lambda_1}(L_{\lambda_1})$ , and the equilibrium one,  $P_{eq}(L_{\lambda_1}|\{L_{\lambda}\}_{\lambda\neq\lambda_1}).$  It it is equal to the difference of semigrand Gibbs free energy at given component, as highlighted in the second line. We thus see that the dissipation following the relaxation from one equilibrium to the other is completely characterized by the equilibration of the initially constrained degrees of freedom.

This procedure can of course be repeated when a further species is chemostatted and it breaks another conservation law. The dissipation is quantified by a difference of semigrand Gibbs free energy, which accounts for the relaxation of the degree of freedom which has been released. When the chemostatting breaks all conservation laws without generating fundamental forces, the CRN finally reaches the global minimum of available semigrand Gibbs free energy, Fig. 5. In this case, the potential becomes the grand potential used in Ref. [19] and discussed in § III D, cf. Eqs. (87), (96), (103), and (140).

## <span id="page-16-1"></span><span id="page-16-0"></span>C. $W_d$ – $\mathcal{G}$ Gauge

The driving work and the stochastic semigrand Gibbs potential are defined up to a gauge—distinct from that involving G and  $W_c$ —, which corresponds to the choice of the components. Let us consider a basis change in the space of conservation laws

$$\ell_{\lambda} \to \ell_{\lambda}' = \sum_{\lambda'} \Omega_{\lambda \lambda'} \ell_{\lambda'},$$
 (147)

with  $\Omega_{\lambda_u \lambda_b} = 0$  for all  $\lambda_u$ ,  $\lambda_b$ , so that the unbroken ones preserve their properties. Accordingly, the conjugated intensive variables transform as

$$f_{\lambda} \to f_{\lambda}' = \sum_{\lambda'} f_{\lambda'} \overline{\Omega}_{\lambda'\lambda},$$
 (148)

see Eq. (140), where  $\overline{\Omega}$  denotes the inverse of  $\Omega$ . We now notice that when the sum involves only the broken conservation laws, such a bilinear form becomes

$$\textstyle \sum_{\lambda_b} f_{\lambda_b} \ell_{\lambda_b} \to \sum_{\lambda_b} f_{\lambda_b} \ell_{\lambda_b} - \sum_{\lambda_u} \mathfrak{f}_{\lambda_u} \ell_{\lambda_u} \,, \tag{149}$$

where

$$\mathfrak{f}_{\lambda_{\mathbf{u}}} := \sum_{\lambda_{\mathbf{u}}' \lambda_{\mathbf{h}}'} f_{\lambda_{\mathbf{b}}'} \overline{\Omega}_{\lambda_{\mathbf{b}}' \lambda_{\mathbf{u}}'} \Omega_{\lambda_{\mathbf{u}}' \lambda_{\mathbf{u}}}. \tag{150}$$

![](_page_17_Figure_1.jpeg)

<span id="page-17-1"></span>FIG. 5. Pictorial representation of the hierarchy of equilibrium states and the semigrand Gibbs free energy drops following the relaxation to equilibrium when conservation laws are broken.

Therefore, the instantaneous driving work rate (the integrand of Eq. (101) rewritten with Eq. (97)), and the semigrand potential, become

$$\dot{W}_{d}(\mathbf{n}) \rightarrow \dot{W}_{d}(\mathbf{n}) + \sum_{\lambda_{u}} \partial_{t} f_{\lambda_{u}} L_{\mathbf{n}}^{\lambda_{u}},$$
 (151)

and

$$g(\mathbf{n}) \to g(\mathbf{n}) + \sum_{\lambda_{\mathbf{u}}} f_{\lambda_{\mathbf{u}}} L_{\mathbf{n}}^{\lambda_{\mathbf{u}}},$$
 (152)

respectively. In contrast, the nonconservative forces—and thus the nonconservative work—is left invariant

$$\mathbf{F}_{Y_f} o \mathbf{F}_{Y_f} + \sum_{\lambda_u} \mathfrak{f}_{\lambda_u} \mathbf{\ell}_{\lambda_u}^{y_f} = \mathbf{F}_{Y_f}$$
 , (153)

since  $\ell_{\lambda_u}^{y_f}=0$ . Crucially, the gauge terms in  $W_d$  and  $-\Delta \mathfrak{G}$  cancel and the EP is unaltered. After all, the physical process is not modified. Notice also that since the gauge term is nonfluctuating, it vanishes for cyclic protocols when integrated over a period.

We thus conclude that driving work and semigrand Gibbs potential are not univocally defined as they are affected by a gauge freedom. The gauge affecting the potential—work connection in stochastic thermodynamics led to debates, see Ref. [60] and references therein. As observed in the latter reference, the problem is rooted in what can be experimentally measured as work, as different experimental set-ups entail different gauge choices. In our chemical framework, different choices of the broken components, involve expressions of the work in which different species appear and whose abundances need to be measured to estimate the work.

**Example 7.** To illustrate the potential—work gauge we use the CRN in Fig. 1. Let us consider the transformation

![](_page_17_Picture_12.jpeg)

FIG. 6. Schematic representation of the forward and backward processes. The relaxation to the equilibrium obtained by shutting down the driving and turning off the forces at time t (resp. 0) for the forward (resp. backward) process, merely relates the two processes but it is irrelevant for the FT.

<span id="page-17-3"></span>of the set conservation laws, Eq. (31), identified by the matrix

$$\Omega = \begin{pmatrix} 1 & -1 \\ 0 & 1 \end{pmatrix}, \tag{154}$$

according to which the conservation laws become

$$\ell'_{E} = \ell_{E} = \begin{pmatrix} E & E^{*} & E^{**} & A & B \\ 1 & 1 & 1 & 0 & 0 \end{pmatrix},$$
 (155a)

$$\ell_b' = \ell_b - \ell_E = \begin{pmatrix} E & E^* & E^{**} & A & B \\ -1 & 0 & 0 & 1 & 1 \end{pmatrix}.$$
 (155b)

Using Eqs. (109), the gauge term reads

$$\mathfrak{f}_{\lambda_{1}}(\pi_{\mathsf{t}}) = \mu_{\mathsf{A}}(\pi_{\mathsf{t}}) \tag{156}$$

from which we can easily derive the expression for the new driving work rate

<span id="page-17-2"></span>
$$\dot{W}_{d}(\mathbf{n}) = (\mathbf{n}_{E} - \mathbf{n}_{A} - \mathbf{n}_{B})\partial_{t}\mu_{A}$$
 (157)

The semigrand Gibbs free energy easily follows. We can now highlight the difference between the two definitions of driving work, Eqs. (111) and (157): while the first entails the measurement of the population of A, B, and of the activated complexes  $E^*$  and  $E^{**}$ , the latter entails that of A, B, and of the free enzyme E. The values of the two expressions will differ except for cyclic protocols integrated over a period.

## <span id="page-17-0"></span>VI. FLUCTUATION THEOREMS

We now proceed to show that the driving work and the nonconservative chemical work satisfy a finite-time detailed FT. The FT holds for any process, referred to as forward, if the open CRN is initially prepared at equilibrium, Eq. (120). For the sake of simplicity, and without loss of generality, we assume that the initial distribution of unbroken components is  $P(\{L_n^{\lambda_u}\}) = \prod_{\lambda_u} \delta \left[L_n^{\lambda_u}, L_{\lambda_u}\right]$ . Let  $\pi_0$  be the initial value of the protocol, which corresponds to equilibrium ruled by  $\mathfrak{g}(\pi_0)$ . At time 0, the driving is activated and the CRN evolves controlled by the protocol  $\pi_\tau$ , for  $\tau \in [0,t]$ . The corresponding backward process is again initially prepared at the equilibrium—where  $\mathfrak{F}_{Y_f} = 0$ —, but the chemical potentials  $\mu_{Y_p}$  must have the same value they have at time t in the forward process. This guarantees that the equilibrium distribution is ruled by  $\mathfrak{g}_n(\pi_t)$ . The backward process is driven by the time-reversed protocol,  $\pi_\tau^\dagger := \pi_{t-\tau}$ , for  $\tau \in [0,t]$  (Fig. 6).

The *finite-time detailed FT* establishes the relationship between the forward and backward process

$$\frac{\mathcal{P}_{t}(W_{d}, \{W_{y_{f}}^{nc}\})}{\mathcal{P}_{t}^{\dagger}(-W_{d}, \{-W_{y_{f}}^{nc}\})} = \exp\left\{\beta\left(W_{d} + \sum_{y_{f}}W_{y_{f}}^{nc} - \Delta\mathcal{G}_{eq}\right)\right\},$$
(158)

where  $\mathcal{P}_{\mathbf{t}}(W_{\mathbf{d}},\{W_{y_f}^{nc}\})$  is the probability of observing  $W_{\mathbf{d}}$  driving work and  $\{W_{y_f}^{nc}\}$  nonconservative contributions along the forward process, Eqs. (101) and (99). Instead,  $\mathcal{P}_{\mathbf{t}}^{\dagger}(-W_{\mathbf{d}},\{-W_{y_f}^{nc}\})$  is the probability of observing  $-W_{\mathbf{d}}$  driving work and  $\{-W_{y_f}^{nc}\}$  nonconservative contributions along the backward process. Finally,

$$\Delta \mathcal{G}_{eq} = -k_B T \ln \frac{\mathcal{Z}(\pi_t, \{L_{\lambda_u}\})}{\mathcal{Z}(\pi_0, \{L_{\lambda_u}\})}, \qquad (159)$$

is the difference of equilibrium semigrand Gibbs potential between the backward and forward initial equilibrium states. When integrating this expression over all possible values of  $W_{\rm d}$  and  $\{W_{y_{\rm f}}^{\rm nc}\}$  we recover a Jarzynskilike integral FT

$$\left\langle \exp\left\{-\beta\left(W_{\rm d}+\sum_{y_{\rm f}}W_{y_{\rm f}}^{\rm nc}\right)\right\}\right\rangle = \exp\left\{-\beta\Delta\mathfrak{G}_{\rm eq}\right\}$$
. (160)

We emphasize that in contrast to the FT for the chemical work discussed in the first part of § III D, the driving and nonconservative work contributions require that the process starts from the equilibrium state ruled by  $\mathcal{G}$ , which is that of open CRNs. As a consequence, there is no break of conservation laws happening during the process, and  $\mathcal{G}_{eq}$  is nonfluctuating. The proof of the FT (158) is given in App. B, and it hinges on the generating function techniques presented in Ref. [58].

We now discuss some special yet interesting cases of the FT (158). In unconditionally detailed-balance CRNs, the nonconservative work vanishes and we obtain

$$\frac{\mathcal{P}_{t}(W_{d})}{\mathcal{P}_{t}^{\dagger}(-W_{d})} = \exp\left\{\beta\left(W_{d} - \Delta\mathcal{G}_{eq}\right)\right\}. \tag{161}$$

This is the analogue of Crooks' FT for CRNs [50, 61], since solely the work due to external manipulations is

involved. In contrast, for autonomous processes, the driving chemical work vanishes and the FT can be formulated as

$$\frac{\mathcal{P}_{t}(\{\mathcal{I}_{y_{f}}\})}{\mathcal{P}_{t}(\{-\mathcal{I}_{y_{f}}\})} = exp\left\{\beta\sum_{y_{f}}\mathcal{F}_{y_{f}}\mathcal{I}_{y_{f}}\right\}, \tag{162}$$

which evidences the symmetry that the fluctuations of the fundamental currents (see Eq. (79)) satisfy.

<span id="page-18-0"></span>The FT in Eq. (158) is inspired by an analogous result derived in Refs. [58, 62] in the context of generic Markov jump processes. It is a major result of this paper and its importance is manifold. It holds for processes of finite duration t, and it is expressed in terms of measurable chemical quantities. Its only constraint is the initial state, which must be equilibrium. It reveals the most appropriate boundary conditions under which Jarzynski–Crooks-like FTs can be formulated for CRNs: equilibrium distribution of open CRNs. Most important, it evidences the merits of our stoichiometric approach based on the identification of conservation laws: it allowed us to characterize the potential describing the equilibrium distribution of open CRNs, and to formulate the decomposition of the EP which supports our FTs, Eq. (102).

<span id="page-18-2"></span>Remark A physical interpretation of the argument of the exponential in Eq. (158), follows from the following observation: if, at time t, the driving is stopped and the fundamental forces (93) turned off—viz. set to zero by an appropriate choice of  $\mu_{Y_f}\colon \mu_{Y_f}^*:=\mu_{Y_p}\cdot \sum_{\lambda_b} \overline{\ell}_{\lambda_b}^{y_p} \ell_{\lambda_b}^{y_f}$ —the CRN relaxes to the initial condition of the backward process. During the relaxation neither  $W_d$  nor  $\{W_{y_f}^{nc}\}$  are performed and the related EP is  $\mathsf{T}\Sigma_{relax}=g(\mathfrak{n},\pi_t)+k_B\mathsf{T}\ln\mathcal{Z}(\pi_t,\{\mathsf{L}_{\lambda_u}\}).$  The argument of the exponential can thus be interpreted as the EP of the fictitious combined process "forward process + relaxation to the final equilibrium".

*Remark* For autonomous CRNs and arbitrary initial conditions, the steady-state FT follows

<span id="page-18-1"></span>
$$\frac{\mathcal{P}(\{\dot{\mathcal{I}}_{y_f}\})}{\mathcal{P}(\{-\dot{\mathcal{I}}_{y_f}\})} \stackrel{t \to \infty}{=} \exp\left\{t\beta \sum_{y_f} \mathcal{F}_{y_f} \dot{\mathcal{I}}_{y_f}\right\}, \tag{163}$$

where  $\mathcal{P}(\{\dot{\mathbb{J}}_{y_f}\})$  is the probability of observing average rates of fundamental external currents  $\left\{\frac{1}{t}\int_0^t d\tau\, I_{y_f}(\tau)\right\}$  equal to  $\{\dot{\mathbb{J}}_{y_f}\}$ . Eq. (163) can be proved using the large deviation technique used in Ref. [13] in combination with the local detailed balance (94).

#### FT along Stoichiometric Cycles

An alternative yet equivalent formulation of the FT (158) is that given in terms of nonconservative contributions along emergent stoichiometric cycles, Eq. (133):

<span id="page-19-8"></span>
$$\frac{\mathcal{P}_{t}(W_{d},\{\Gamma_{\eta}\})}{\mathcal{P}_{t}^{\dagger}(-W_{d},\{-\Gamma_{\eta}\})} = \exp\left\{\beta\left(W_{d} + \sum_{\eta}\Gamma_{\eta} - \Delta\mathcal{G}_{eq}\right)\right\},\tag{164}$$

where  $\mathcal{P}_{\mathbf{t}}(W_{\mathbf{d}}, \{\Gamma_{\eta}\})$  is the probability of observing  $W_{\mathbf{d}}$  driving work and  $\{\Gamma_{\eta}\}$  nonconservative contributions along the forward process. We discuss its proof App. B.

*Remark* As for the fundamental currents, the local detailed balance (129) can be used to prove a steady-state FT for currents along emergent stoichiometric cycles

$$\frac{\mathcal{P}(\{\dot{\mathcal{J}}_{\eta}\})}{\mathcal{P}(\{-\dot{\mathcal{J}}_{\eta}\})} \stackrel{t \to \infty}{=} \exp\left\{t\beta \sum_{\eta} \mathcal{A}_{\eta} \dot{\mathcal{J}}_{\eta}\right\}, \tag{165}$$

which is valid for autonomous CRNs and arbitrary initial conditions.  $\mathcal{P}(\{\dot{\mathcal{J}}_{\eta}\})$  is the probability of observing average rates of emergent cycle currents  $\left\{\frac{1}{t}\int_0^t d\tau \sum_{\rho} \zeta_{\eta,\rho} J_{\rho}(\tau)\right\}$  equal to  $\{\dot{\mathcal{J}}_{\eta}\}$ . In contrast to the analogous FT obtained in Ref. [14], Eq. (165) is achieved using a stoichiometric approach based on the identification of stoichiometric cycles. For this reason, it accounts for the minimal set of nonzero macroscopic affinities.

#### <span id="page-19-0"></span>VII. ENSEMBLE AVERAGE RATES DESCRIPTION

We now summarize our main results for ensemble average rates and discuss the relaxation to equilibrium of detailed-balanced CRNs. We also highlight the difference between an approach that does and does not take into account the topology of the CRN. We do so by recapitulating the procedure to decompose the EP into its fundamental contributions. We end by formulating a nonequilibrium Landauer's principle.

## A. Traditional Description

*Enthalpy Balance* The enthalpy balance follows from the time derivative of the average enthalpy, Eq. (61),

$$d_{t} \sum_{\mathbf{n}} p_{\mathbf{n}}(\mathbf{h} \cdot \mathbf{n}) \equiv d_{t} \langle H \rangle = \langle \dot{Q} \rangle + \langle \dot{W}_{c} \rangle. \tag{166}$$

It characterizes the average rate of change of enthalpy in the same way Eq. (69) characterizes the enthalpy change along stochastic trajectories. The average heat flow rate is given by

<span id="page-19-9"></span>
$$\langle \dot{Q} \rangle = \langle \dot{Q}^{thr} \rangle + \langle \dot{Q}^{chm} \rangle.$$
 (167)

The first term quantifies the average rate of heat of reaction.

$$\langle \dot{Q}^{thr} \rangle = \sum_{\rho} \left[ \mathbf{h} \cdot \mathbf{S}_{\rho} + \mathbf{h}_{Y} \cdot \mathbf{S}_{\rho}^{Y} \right] \langle J_{\rho} \rangle, \qquad (168)$$

where  $\langle J_{\rho} \rangle = \sum_{n} w_{\rho}(n) p_{n}$  is the average reaction current. The second term is the average heat flow in the chemostats,

$$\langle \dot{\mathbf{Q}}^{\mathrm{chm}} \rangle = \mathsf{T} \mathbf{s}_{\mathrm{Y}} \cdot \langle \mathbf{I}^{\mathrm{Y}} \rangle \,, \tag{169}$$

where  $\langle I^Y \rangle = \sum_{\rho} (-S_{\rho}^Y) \langle J_{\rho} \rangle$  are the average external currents, Eq. (19). Instead, the ensemble average chemical work rate.

<span id="page-19-2"></span>
$$\langle \dot{W}_{c} \rangle = \mu_{Y} \cdot \langle I^{Y} \rangle$$
, (170)

<span id="page-19-1"></span>quantifies the average rate of exchange of Gibbs free energy with the chemostats.

*Entropy Production Rate* At the ensemble average level, the second law of thermodynamics manifests itself in the non-negative average EP rate

<span id="page-19-4"></span>
$$\begin{split} \langle \dot{\Sigma} \rangle &= d_{\mathbf{t}} \langle S \rangle - \frac{1}{T} \langle \dot{Q} \rangle \\ &= k_{B} \sum_{\mathbf{n}, \rho} w_{\rho}(\mathbf{n}) p_{\mathbf{n}} \ln \frac{w_{\rho}(\mathbf{n}) p_{\mathbf{n}}}{w_{\rho}(\mathbf{n} + \mathbf{S}_{\rho}) p_{\mathbf{n} + \mathbf{S}_{\rho}}} \geqslant 0 \,. \end{split} \tag{171}$$

where  $\langle S \rangle = \sum_n p_n S(n)$ , Eq. (57). Using the expression for the transition affinity, Eq. (56), it can be recast into,

<span id="page-19-5"></span>
$$\mathsf{T}\langle\dot{\Sigma}\rangle = \langle\dot{W}_{c}\rangle - \mathsf{d}_{t}\langle\mathsf{G}\rangle\,,\tag{172}$$

where the chemical work rate and the average Gibbs potential are given in Eqs. (170) and (48), respectively. Equivalently, Eqs. (166), (171), and (172) can be obtained by directly averaging Eqs. (69), (73a), and (73c), respectively, over all stochastic trajectories.

For closed CRNs, Eq. (172) reduces to  $d_t\langle G\rangle = -T\langle \dot{\Sigma}\rangle \leqslant 0$ . This relation, together with Eq. (49), shows that: (i)  $\langle G\rangle$  is a Lyapunov function, and hence that closed CRNs relax to equilibrium, Eq. (44); (ii)  $\langle G\rangle - \langle G_{eq}\rangle_L = T\langle \Sigma\rangle$  is the average dissipation during the relaxation to equilibrium.

### <span id="page-19-7"></span>B. CRN-specific Description

<span id="page-19-3"></span>Entropy Production Rate We now summarize the procedure to recover the EP decomposition (102) at the ensemble average level. (i) Identify the broken and unbroken conservation laws,  $\{\ell_{\lambda_u}, \ell_{\lambda_b}\}$ , § II D. (ii) Identify a set of  $N_{\lambda_b}$  exchanged species,  $\mathbf{y}_p$ , for which the matrix whose rows are  $\{\ell_{\lambda_b}^{y_p}\}$  is nonsingular. The columns of its inverse are denoted by  $\{\bar{\ell}_{\lambda}^{y_p}\}$ . Physically, each species  $\mathbf{y}_p$  breaks exactly one conservation law. The remaining exchanged species form the set denoted by  $\mathbf{y}_f$ . (iii) The nonequilibrium semigrand Gibbs potential follows from the average of Eq. (103),

<span id="page-19-6"></span>
$$\langle \mathfrak{G} \rangle = \sum_{\mathbf{n}} \mathfrak{p}_{\mathbf{n}} \left[ k_{\mathbf{B}} \mathsf{T} \ln \mathfrak{p}_{\mathbf{n}} + \mathfrak{g}_{\mathbf{n}} \right] \,. \tag{173}$$

It depends on the vector  $\langle M^{y_p} \rangle$  which describes the average population of the combination of moieties whose

conservation is broken by the chemostats, § IID and Eq. (91). (*iv*) The change in time of  $\langle \mathfrak{g} \rangle$  due to the time-dependent driving describes the average driving work rate, Eq. (101),

<span id="page-20-2"></span>
$$\langle \dot{W}_{d} \rangle = - \left[ \partial_{t} \mu_{Y_{p}} \right] \cdot \langle \mathbf{M}^{y_{p}} \rangle. \tag{174}$$

It quantifies the average amount of work spent to change the chemical potentials of the chemostats  $\mathbf{Y}_p$ . (v) The second group of exchanged species,  $\mathbf{y}_f$ , is used to identify the minimal set of fundamental nonconservative forces,  $\mathcal{F}_{Y_f} \equiv \{\mathcal{F}_{y_f}\}$ , Eq. (93). The average nonconservative chemical work rate follows from the product of these forces and their corresponding instantaneous external currents, Eq. (67),

<span id="page-20-0"></span>
$$\langle \dot{W}_{y_f}^{nc} \rangle := \mathfrak{F}_{y_f} \langle I_{y_f} \rangle$$
. (175

They quantify the average work per unit time spent to sustain a net current of species  $\mathbf{y}_f$  across the CRN. (vi) The average EP rate decomposed as in Eq. (102) finally follows from Eqs. (173)–(175),

<span id="page-20-1"></span>
$$T\langle\dot{\Sigma}\rangle = -d_t\langle\mathfrak{G}\rangle + \langle\dot{W}_d\rangle + \sum_{y_f}\langle\dot{W}_{y_f}^{nc}\rangle\,. \tag{176}$$

Its three fundamental contributions appear: a conservative force contribution, a time-dependent driving contribution, a minimal set of nonconservative terms.

For open autonomous detailed-balanced CRNs,  $\mathcal{F}_{Y_f} = 0$ ,  $\partial_t \mu_{Y_p} = 0$ , and hence Eq. (176) reduces to  $d_t \langle \mathcal{G} \rangle = -T \langle \dot{\Sigma} \rangle \leqslant 0$ . Recalling Eq. (122), this relation shows that: (i)  $\langle \mathcal{G} \rangle$  is a Lyapunov function, and hence that these CRNs relax to equilibrium, Eq. (120); (ii)  $\langle \mathcal{G} \rangle - \langle \mathcal{G}_{eq} \rangle_{L_u} = T \langle \Sigma \rangle$  is the average dissipation during the relaxation to equilibrium.

Enthalpy Balance By averaging Eq. (116), the CRN-specific average enthalpy balance also ensues

$$d_t \langle \mathcal{H} \rangle = \langle \dot{Q} \rangle + \langle \dot{W}_d \rangle + \sum_{y_f} \langle \dot{W}_{y_f}^{nc} \rangle \, , \tag{177} \label{eq:177}$$

which strengthen the interpretation of  $\langle \dot{W}_d \rangle$  and  $\{\langle \dot{W}_{y_f}^{nc} \rangle\}$  as average work rate contributions.

#### C. Average EP along Stoichiometric Cycles

The average EP decomposition expressed in terms of emergent cycles currents and affinities can be achieved through an analogous recipe. (i) Identify broken and unbroken conservation laws,  $\{\ell_{\lambda_u}, \ell_{\lambda_b}\}$ , as well as stoichiometric and emergent stoichiometric cycles,  $\{c^{\alpha}, c^{\eta}\}$  §§ II D and II E. Steps (ii)–(iv) as above. (v) Identify the emergent stoichiometric cycles affinities, Eq. (126), as well as their corresponding average currents  $\sum_{\rho} \zeta_{\eta,\rho} \langle J_{\rho} \rangle$ , Eq. (130). (vi) The average EP rate follows from Eqs. (173), (174), and the emergent stoichiometric cycles currents and affinities,

$$\mathsf{T}\langle\dot{\Sigma}\rangle = -\mathsf{d}_{\mathsf{t}}\langle\mathcal{G}\rangle + \langle\dot{W}_{\mathsf{d}}\rangle + \sum_{\mathsf{n}}\langle\dot{\Gamma}_{\mathsf{n}}\rangle,\tag{178}$$

![](_page_20_Figure_15.jpeg)

<span id="page-20-3"></span>FIG. 7. Pictorial representation of the transformation between two nonequilibrium probability distributions. The nonequilibrium transformation (blue line) is compared with the equilibrium one (green line). The latter is obtained by shutting down the driving and turning off the forces at each time (dashed gray lines).

where,

<span id="page-20-6"></span>
$$\langle \dot{\Gamma}_{n} \rangle = \mathcal{A}_{n} \sum_{o} \zeta_{n,o} \langle J_{o} \rangle, \tag{179}$$

as in Eqs. (132) and (133).

## D. Nonequilibrium Landauer's Principle

<span id="page-20-5"></span>We can now formulate the nonequilibrium Landauer's principle for the driving and nonconservative work. We have already seen that when the driving is stopped and all forces are turned off, the CRN relaxes to equilibrium by minimizing the nonequilibrium semigrand Gibbs potential. Equation (122) can be thus combined with Eq. (176), and by integrating over time, we obtain

<span id="page-20-4"></span>
$$\begin{split} \langle W_d \rangle + \sum_{y_f} \langle W_{y_f}^{nc} \rangle \\ &= \Delta \langle g_{eq} \rangle_{L_u} + k_B T \Delta \mathcal{D}(p \| p_{eq}) + T \underbrace{\langle \Sigma \rangle}_{\geqslant 0} \; . \quad \text{(180)} \end{split}$$

This fundamental result shows that the minimal cost for transforming a CRN from an arbitrary nonequilibrium state to another is bounded by a relative entropy difference, as depicted in Fig. 7. This entropy is an information-theoretical measure of the dissimilarity between two probability distributions: the actual nonequilibrium one and its corresponding equilibrium, which is used as a reference. For processes starting at equilibrium,  $k_BT\Delta\mathcal{D}=k_BT\mathcal{D}(p_f\|p_{eq_f})\geqslant 0$  quantifies the minimal cost of producing the final nonequilibrium state. In contrast, for processes relaxing to equilibrium,  $k_BT\Delta\mathcal{D}=-k_BT\mathcal{D}(p_i\|p_{eq_i})\leqslant 0$  quantifies the maximum amount of work that can be extracted from the initial nonequilibrium state. For transformations in absence of

nonconservative forces ( $\mathfrak{F}_{Y_f}=0$ ), we obtain the chemical version of the result of Ref. [28]. The original Landauer's principle [63] is recovered when considering erasure in a two state system (0 and 1) with identical energies. In this process, the initial equilibrium state (system equally likely to be found in 0 or 1) is transformed into a metastable nonequilibrium one (system found with probability one in 0) via a cyclic protocol. The difference of relative entropy is  $\Delta \mathfrak{D} = \ln 2$ , and thus  $\langle W_d \rangle \geqslant k_B T \ln 2$ . Finally, Kelvin's formulation of the second law is recovered for transformation between equilibrium states in absence of nonconservative forces,  $\langle W_d \rangle \geqslant \Delta \langle \mathfrak{G}_{eq} \rangle_{L_1}$ .

Remark To obtain the Landauer's principle for  $\langle \dot{W}_d \rangle$  and  $\{\langle \dot{W}^{nc}_{y_f} \rangle\}$ , the equilibrium states of the open CRN have been used as reference states, see Fig. 7. Alternatively, one could use the equilibrium states of the closed CRN, which are obtained by shutting down all exchange reactions. If one does so and uses Eq. (172), an analogous Landauer's principle for the chemical work can be derived,

$$\langle W_c \rangle = \Delta \langle G_{eq} \rangle_L + k_B T \Delta \mathcal{D}(p \| p_{eq}) + T \langle \Sigma \rangle \ . \ \ (181)$$

The traditional thermodynamic work relation  $\langle W_c \rangle \geqslant \Delta \langle G_{eq} \rangle_L$  is recovered for processes whose initial and final states are equilibrium ones.

#### E. Connection with Deterministic Descriptions

For CRNs with very abundant populations of species, a deterministic dynamical description in terms of nonlinear rate equations is justified. The corresponding nonequilibrium thermodynamics was analyzed in Ref. [25], where the counterparts of Eqs. (166), (172), and (105), can be found. Following a procedure similar to that described in this paper, one can also formulate the deterministic analog of the EP decomposition (176).

One can also recover the deterministic thermodynamic description from the ensemble average one by performing the thermodynamic limit— $n\gg 1$ ,  $V\gg 1$ , with n/V=:[z] finite, see App. A—and assuming that  $p_n\simeq \delta_{n,[z]V}$ , i.e. the distribution is very peaked around the population that is solution of the rate equations, [z]V.

We conclude with two remarks.

*Remark* Not all results valid for stochastic CRNs hold for the deterministic ones. An example is provided by the *adiabatic–nonadiabatic EP decomposition* introduced in Ref. [64] for generic stochastic processes: it is valid for deterministic CRNs only for *complex-balanced* CRNs, see Refs. [25, 65].

*Remark* As briefly mentioned in § II A, there is an alternative way of modeling open CRNs in which the exchanged species **v** are treated as particle *reservoir* with

very large population. All main results of our paper—*i.e.* the EP decomposition (102), the finite-time detailed FT (158), and the Landauer's principle (180)—still hold. The only difference lies in the fact that the different definitions of stoichiometric matrices, Eq. (6), also entail slightly different definitions of broken conservation law. Besides that, the procedure described in § VII B can be followed in the same way.

#### <span id="page-21-1"></span><span id="page-21-0"></span>VIII. APPLICATION

We now illustrate our EP decompositions (102) and (132) on a CRN displaying more than one fundamental force, which allows us to introduce the phenomenology of free energy transduction. We consider the following active catalytic mechanism

$$T + E \xrightarrow{k_{+1}} ET \xrightarrow{k_{+5}} ED \xrightarrow{k_{+4}} E + D$$

$$ET + S \xrightarrow{k_{+2}} E^* \xrightarrow{k_{+3}} ED + P.$$
(182)

It describes the T-driven catalysis of S into P, having D as a byproduct, see Fig. 8. All substrates and products are regarded as exchanged species,

<span id="page-21-2"></span>
$$S \underset{\overleftarrow{k_{+s}}}{\longrightarrow} S_e \text{, } P \underset{\overleftarrow{k_{+p}}}{\longrightarrow} P_e \text{, } T \underset{\overleftarrow{k_{+t}}}{\longrightarrow} T_e \text{, } D \underset{\overleftarrow{k_{+d}}}{\longrightarrow} D_e \text{.} \quad (183)$$

The stoichiometric matrices S and  $S^Y$  read

$$\begin{array}{c|ccccccccccccccccccccccccccccccccccc$$

—in which the stoichiometric matrix of the closed CRN is highlighted—and

$$\begin{array}{c|ccccccccccccccccccccccccccccccccccc$$

respectively.

We now follow the procedure described in § VII, and characterize all terms of Eq. (102). (i) The closed CRN

![](_page_22_Picture_1.jpeg)

FIG. 8. Pictorial illustration of the open CRN in Eqs. (182) and (183), from which one can see the more clearly the active catalytic mechanism.

<span id="page-22-0"></span>has three independent conservation laws:

$$\begin{array}{cccccccccccccccccccccccccccccccccccc$$

The first corresponds to the enzyme moiety and it is unbroken in the open CRN. In contrast, the last two correspond to the moieties S–P and T–D, which are broken in the open CRN. (ii) We choose  $S_e$  and  $T_e$  as chemostatted species  $Y_p$ , since the entries of  $\ell_S$  and  $\ell_T$  corresponding to these species identify a nonsingular matrix—it is an identity matrix. (iii) The moiety population vector reads

$$M_{n}^{y_{p}} = {S \over T} \left( {n_{E^{*}} + n_{S} + n_{P} \over n_{ET} + n_{E^{*}} + n_{ED} + n_{T} + n_{D}} \right),$$
 (187)

from which the semigrand Gibbs potential  $\mathcal{G}$  follows, Eqs. (103) and (173). (*iv*) The driving work rate follows from the scalar product of the vector above and

$$-\partial_{t}\mu_{Y_{p}} = \frac{S_{e}}{T_{e}} \begin{pmatrix} -\partial_{t}\mu_{S_{e}} \\ -\partial_{t}\mu_{T_{e}} \end{pmatrix}, \tag{188}$$

Eqs. (101) and (174). (v) The chemostatted species  $P_e$  and  $D_e$  form the set  $\mathbf{Y}_f$  and determine the fundamental forces,

$$\mathfrak{F}_{Y_f} = \begin{pmatrix} \mathfrak{F}_{P_e} \\ \mathfrak{F}_{D_e} \end{pmatrix} = P_e \begin{pmatrix} \mu_{P_e} - \mu_{S_e} \\ \mu_{D_e} - \mu_{T_e} \end{pmatrix}, \tag{189}$$

Eq. (93). Together with the instantaneous external currents

$$\mathbf{I}^{\mathbf{Y}_{\mathbf{f}}} = \begin{pmatrix} \mathbf{I}_{\mathbf{P}_{\mathbf{e}}} \\ \mathbf{I}_{\mathbf{D}_{\mathbf{e}}} \end{pmatrix} = \begin{pmatrix} \mathbf{P}_{\mathbf{e}} \\ \mathbf{D}_{\mathbf{e}} \end{pmatrix} \begin{pmatrix} \mathbf{J}_{+\mathbf{p}} - \mathbf{J}_{-\mathbf{p}} \\ \mathbf{J}_{+\mathbf{d}} - \mathbf{J}_{-\mathbf{d}} \end{pmatrix}, \tag{190}$$

they identify the nonconservative contributions, Eq. (99). The first one,  $\mathcal{F}_{P_o}I_{P_o}$ , characterizes the work spent to

convert S into P, while the second,  $\mathcal{F}_{D_e}I_{D_e}$ , that due to the consumption of T. The sum of these terms and the driving work integrated over time contribute to the EP as in Eq. (102).

The similar EP decomposition written in terms of nonconservative contributions along stoichiometric cycles follows when these latter are identified. The kernel of stoichiometric matrix of the closed CRN is empty, while that of the open is spanned by

$$\begin{array}{cccccccccccccccccccccccccccccccccccc$$

which are regarded as emergent stoichiometric cycles. Along the first, the enzyme converts one molecule of T into one of D, while for the second it processes T and S and produces D and P,

$$C_1^{Y} = \begin{pmatrix} S_e & P_e & T_e & D_e \\ 0 & 0 & 1 & -1 \end{pmatrix},$$
 (192a)

$$\mathbf{C}_{2}^{Y} = \begin{pmatrix} S_{e} & P_{e} & T_{e} & D_{e} \\ 1 & -1 & 1 & -1 \end{pmatrix}.$$
 (192b)

At this point we can proceed from step (v) and determine the affinities,

$$\mathcal{A}_1 = \mu_{T_0} - \mu_{D_0} \tag{193a}$$

$$A_2 = \mu_{T_e} + \mu_{S_e} - \mu_{D_e} - \mu_{P_e}, \qquad (193b)$$

as well as the related instantaneous currents,

$$\mathcal{J}_1 = J_{+p} - J_{-p} - J_{+d} - J_{-d} \tag{194a}$$

$$\mathcal{J}_2 = J_{-p} - J_{+p} \,. \tag{194b}$$

The nonconservative work follows from the products  $\mathcal{A}_1\mathcal{J}_1$  and  $\mathcal{A}_2\mathcal{J}_2$ , and the decomposition in Eq. (132) can be thus expressed. The former characterizes the dissipation due to the futile consumption of T, since S is not converted into P. The latter, instead, is the work spent to convert T and S into D and P.

This system can be used to illustrate free energy transduction when one considers the autonomous regime where  $\mathcal{F}_{D_e} < 0$ ,  $\mathcal{F}_{P_e} > 0$ , but  $\langle \dot{W}_{D_e}^{nc} \rangle > -\langle \dot{W}_{P_e}^{nc} \rangle > 0$ . Namely, the external current of  $P_e$  flows towards the chemostat,  $\langle I_{P_e} \rangle < 0$  ( $P_e$  produced), despite the fact that its force is positive,  $\mathcal{F}_{P_e} > 0$ . This can happen thanks to the free energy provided by the conversion of  $T_e$  into  $D_e$ ,  $\langle \dot{W}_{D_e}^{nc} \rangle > 0$ . In Fig. 9 we illustrate the behavior of the average external currents and work contributions as function of time when the transducer in Fig. 8 is smoothly switched from a nontransducing regime to a transduction one. At early times,  $\mathcal{F}_{D_e} = 0$ ,  $\mathcal{F}_{P_e} > 0$ , and one observes only a consumption of  $P_e$ :  $\langle I_{P_o} \rangle > 0$ 

<span id="page-23-1"></span>![](_page_23_Figure_1.jpeg)

![](_page_23_Figure_2.jpeg)

(a) Average External Currents

<span id="page-23-2"></span>(b) Average Work Contributions

<span id="page-23-0"></span>FIG. 9. (a) average external currents and (b) average work rates vs. time, for the CRN in Fig. 8. The plots are obtained using  $10^4$  trajectories generated via the stochastic simulation algorithm. To simplify the illustration, all substrate and products are treated as chemostatted species. The concentrations of  $S_e$ ,  $P_e$ , and  $D_e$  are kept constant  $[[S_e] = 10$ ,  $[P_e] = 70$ , and  $[D_e] = 10$ ] whereas that of  $T_e$  increases according to a logistic function:  $[T_e] = [T_e]_{max}/(1 + \exp{-\kappa(t - t_0)})$   $[[T_e]_{max} = 200$ ,  $\kappa = 20$ ,  $t_0 = 1.5$ ]. This mimics the process in which the force that sustain the active catalysis,  $\mathcal{F}_{D_e}$ , is switched on from 0 to a finite value after  $t_0$ . The change of chemical potential  $\mu_{T_e}$  is plotted in red in the inset. The choice of the rate constants is as follows:  $k_{+1} = 10^3$ ;  $k_{+2} = 10^3$ ;  $k_{+3} = 10^3$ ;  $k_{+4} = 10^3$ ;  $k_{+5} = 10^2$ ; whereas the backward rates are obtained by means of Eq. (52) using the following values for the standard-state chemical potentials:  $\mu_E^\circ = 1$ ;  $\mu_{ET}^\circ = 3$ ;  $\mu_{E^*}^\circ = 4$ ;  $\mu_{ED}^\circ = 2$ ;  $\mu_{S_e}^\circ = 1$ ;  $\mu_{P_e}^\circ = 2$ ;  $\mu_{T_e}^\circ = 10$ ;  $\mu_{D_e}^\circ = 1$ . Since reactions are unimolecular the constant term  $-k_B T1 \ln[s]$  is ignored. Finally,  $k_B T = 1$  and the value of the enzyme moiety is  $L_E = 10$ .

and  $\langle I_{D_e} \rangle \simeq 0$  (respectively, orange and blue curves in Fig. 9a). Consequently, the nonconservative work contributions are  $\langle \dot{W}^{nc}_{P_e} \rangle > 0$  and  $\langle \dot{W}^{nc}_{D_e} \rangle = 0$  (respectively, orange and blue curves in Fig. 9b). In contrast, when the *motive* force  $\mathcal{F}_{D_e}$  is switched on (at large times), the current  $\langle I_{P_e} \rangle$  turns negative whereas the *motive* current  $\langle I_{P_e} \rangle$  aligns itself with its corresponding force. We thus observe  $\langle \dot{W}^{nc}_{D_e} \rangle > -\langle \dot{W}^{nc}_{P_e} \rangle > 0$ . At intermediate times, driving work is extracted following the smooth increase of the *motive* force (green curve in Fig. 9b).

#### IX. CONCLUSIONS AND PERSPECTIVES

In this paper we presented a thorough description of nonequilibrium thermodynamics of stochastic CRNs. The fundamental results of traditional irreversible chemical thermodynamics (*viz.* enthalpy and entropy balance) are formulated at the level of single trajectories, Eqs. (61) and (72). By making use of the CRN topology and by identifying conservation laws we decompose the EP into two fundamental work contributions and a semigrand potential difference, Eqs. (102) and (176). The driving work describes the thermodynamic cost of manipulating the CRN by changing the chemical potentials of its chemostats. Instead, the nonconservative work quantifies the cost of sustaining chemical currents through the CRN. These currents prevent the CRN from reaching equilibrium, but when the related fundamental forces

vanish (and the chemical potentials of the reservoirs are kept constant in time), the CRN relaxes to equilibrium by minimizing the semigrand Gibbs potential. We elucidate the relationship between this thermodynamic potential and the dynamical potentials used in chemical reaction network theory. Our EP decomposition written in terms of stoichiometric cycles affinities generalizes previous decompositions formulated for linear CRNs or steady-state dynamics.

Two detailed FTs follow from our EP decompositions, Eqs. (158) and (164). They are valid at any time and entirely expressed in terms of physical quantities. Hence, they offer the possibility of validating experimentally our findings, and, from a wider perspective, of validating the foundations of stochastic thermodynamics beyond electronic devices or colloidal particles [66, 67]. Finally, we derive a nonequilibrium Landauer's principle for the work contributions, Eq. (180), which quantifies the minimum thermodynamic cost involved in transformations between arbitrary nonequilibrium states. In contrast to early formulations of the latter principle, we consider not only the cost of external manipulations, but also that related to sustained currents across the system.

Our EP decomposition identifies the fundamental dissipative contributions in CRNs of arbitrary complexity, and it can be thus used to analyze free energy conversion in CRNs beyond single biocatalysts, molecular motors, or sensory systems, which are usually described by linear CRNs [68–71]. The nonconservative work con-

tributions capture Hill's idea of free energy transduction and extend it to nonlinear CRNs with an arbitrary number of chemical forces. [As illustrated in § VIII, transduction occurs whenever one contribution becomes negative, thus requiring the other ones to be positive and larger than the former in absolute value by virtue of the second law of thermodynamics.] In turn, the driving work contribution allows to generalize transduction to CRNs with reservoirs externally controlled in time. Hence, our framework can be used to analyze pumping in CRNs [72, 73], namely mechanisms whose periodic external control sustains a chemical current against its spontaneous direction.

In biochemical information-handling systems [48, 70, 74, 75] and chemical computing [76], information is stored and processed at the molecular level. Conservation laws play a crucial role since they enable to store information in the form of nontrivial probability distributions [77] (see *e.g.* Eq. (120)). Early applications of the nonequilibrium Landauer's principle proved successful for characterizing the thermodynamic cost of information processing in simple mechanisms [78, 79]. Our generalization of this principle could be thus used to analyze biochemical information-handling systems of far greater complexity. This endeavor is important in the light of the current understanding that biological systems evolved by optimizing the gathering and representation of information [80, 81].

Noise is known to play an important role in many biochemical processes. Since a complete stochastic description remains both analytically and computationally demanding, developing hybrid stochastic–deterministic descriptions would be of great importance [25, 82, 83]. Also, many of these processes are regulated by enzymes, thus extending the present theory beyond mass-action kinetics, as already done for deterministic CRNs [84], is also necessary.

### **ACKNOWLEDGMENTS**

R.R. warmly thanks A. Wachtel, A. Lazarescu and M. Polettini for valuable discussions. This work was funded by the National Research Fund of Luxembourg (AFR PhD Grant 2014-2, No. 9114110) and the European Research Council project NanoThermo (ERC-2015-CoG Agreement No. 681456).

#### <span id="page-24-1"></span>Appendix A: Thermodynamic Potentials

Using equilibrium statistical mechanics, we derive the equilibrium Gibbs free energy of a CRN in a given state n. Our derivation is similar to that found in Ref. [85, § 3.2], whereas for different approaches we refer the Reader to Refs. [86–89].

| symbol                                                                                                        | physical quantity                  | equation    |
|---------------------------------------------------------------------------------------------------------------|------------------------------------|-------------|
| $\overline{S_{\rho}}$                                                                                         | stoichiometric vectors             | (3)         |
| s <sup>·</sup>                                                                                                | stoichiometric matrix              | (4)–(5)     |
| $w_{\rho}(\mathbf{n})$                                                                                        | stochastic reaction rates          | (13)        |
| $J_{\rho}(\tau)$                                                                                              | instantaneous reaction fluxes      | (17)        |
| l                                                                                                             | conservation laws                  | (23)        |
| $L_n$                                                                                                         | component                          | (24)        |
| c                                                                                                             | stoichiometric cycles              | (32)        |
| $\mu_{Y}$                                                                                                     | chemostats chemical potential      | (54)        |
| $g_n$                                                                                                         | Gibbs free energy of $\mathfrak n$ | (42)        |
| G(n)                                                                                                          | stochastic Gibbs potential         | (47)        |
| $\langle G(\mathfrak{n}) \rangle$                                                                             | nonequilibrium Gibbs potential     | (48)        |
| Z                                                                                                             | closed-CRN partition function      | (43)        |
| $A_{\rho}(\mathbf{n})$                                                                                        | reaction affinity                  | (56)        |
| $s_n$                                                                                                         | entropy of n                       | (58)        |
| S(n)                                                                                                          | stochastic entropy                 | (57)        |
| $\langle S(n) \rangle$                                                                                        | Gibbs–Shannon entropy              | (60)        |
| $H(\mathbf{n})$                                                                                               | enthalpy                           | (61) (166)  |
| $Q(\langle Q \rangle)$                                                                                        | heat flow (rate)                   | (66) (167)  |
| $W_{\rm c}$ ( $\langle \dot{W}_{\rm c} \rangle$ )                                                             | chemical work (rate)               | (68) (170)  |
| $\mathbf{I}^{\mathbf{Y}}$ .                                                                                   | instantaneous external currents    | (67)        |
| $egin{array}{l} \Sigma \; (\langle \dot{\Sigma}  angle) \ \mathbf{M}^{\mathrm{y_p}}_{\mathbf{n}} \end{array}$ | entropy production (rate)          | (74) (171)  |
|                                                                                                               | moiety population vector           | (91)        |
| $rac{\mathfrak{F}_{\mathrm{Y_f}}}{\mathfrak{I}^{\mathrm{Y_f}}}$                                              | fundamental forces                 | (93)        |
| $\mathfrak{I}^{\mathrm{Y_{\mathrm{f}}}}$                                                                      | fundamental external currents      | (79)        |
| $\mathfrak{g}_{\mathfrak{n}}$                                                                                 | semigrand Gibbs free energy of n   | (95)        |
| $\mathfrak{G}(\mathbf{n})$                                                                                    | stoch. semigrand Gibbs pot.        | (103)       |
| $\langle \mathfrak{G}(\mathfrak{n}) \rangle$                                                                  | noneq. semigrand Gibbs pot.        | (173)       |
| 2                                                                                                             | open-CRN partition function        | (119)       |
| $W_{\rm d}~(\langle W_{\rm d} \rangle)$                                                                       | driving chem. work (rate)          | (101) (174) |
| $W_{y_{\rm f}}^{\rm nc} \left( \langle \dot{W}_{y_{\rm f}}^{\rm nc} \rangle \right)$                          | nonconservative chem. work (rate)  | (99) (175)  |
| $\mathcal{H}(\mathbf{n})$                                                                                     | semigrand enthalpy                 | (115) (177) |
| $\mathcal{A}_{\eta}$                                                                                          | stoichiometric cycle affinity      | (126)       |
| $\mathcal{J}_{\eta}$                                                                                          | stoichiometric cycle current       | (135)       |
| Γη                                                                                                            | nonconservative cycles chem. work  | (133) (179) |

<span id="page-24-0"></span>TABLE III. List of symbols used throughout the text. The physical quantity that they denote and the equation number in which they are defined are also reported.

We regard the reacting species, labeled by  $\sigma=1,\dots,N_z,$  as solutes of an ideal dilute solution in a closed vessel. Since the solvent, s, is much more abundant than the solutes,  $n_s\gg\sum_\sigma n_\sigma.$  As in ideal solutions, interactions among solutes are negligible, and the partition function of the whole solution  $\mathfrak{Q}(T,n,n_s)$  can be written as the product of single species partition functions,  $q\equiv\{q_\sigma(T)\}$  and  $q_s.$  By idealizing the solution as a lattice gas, in which each site is occupied by one molecule, we obtain

<span id="page-24-2"></span>
$$\label{eq:QTn} \text{Q}(\textbf{T},\textbf{n},\textbf{n}_s) = \frac{(\textbf{n}_s + \sum_{\sigma} \textbf{n}_{\sigma})!}{\textbf{n}_s! \prod_{\sigma} \textbf{n}_{\sigma}!} \, \textbf{q}_s(\textbf{n}_s) \prod_{\sigma} \textbf{q}_{\sigma}^{\textbf{n}_{\sigma}} \, . \quad \text{(A1)}$$

The combinatoric term accounts for all possible permutations of molecules, in which the overcounting due to the indistinguishability of molecules of the same species is removed. We note that the fact that different molecules might occupy different volumes is neglected.

Since we deal with dilute solutions,  $q \equiv \{q_\sigma(T)\}$  depends mainly on the temperature and the solutes–solvent interactions, whereas  $q_s$  depends also on the abundance of solvent, as well as the external pressure (which we omit for brevity). Using Stirling's formula and the high relative abundance of the solvent, the combinatoric term can be approximated as

$$\frac{(n_s + \sum_{\sigma} n_{\sigma})!}{n_s! \prod_{\sigma} n_{\sigma}!} \simeq \prod_{\sigma} \frac{n_s^{n_{\sigma}}}{n_{\sigma}!} \equiv \frac{n_s^{\cdot n}}{n!}. \tag{A2}$$

Using Eq. (A1), the Gibbs free energy of a given state  $\mathfrak n$  is thus given by

<span id="page-25-3"></span>
$$\begin{split} g_{\mathbf{n}} &= -k_{B}T\ln \Omega(T, \mathbf{n}, \mathbf{n}_{s}) \\ &= (\mu^{\circ} - 1k_{B}T\ln \mathbf{n}_{s}) \cdot \mathbf{n} + k_{B}T\ln \mathbf{n}! + g_{s}, \end{split} \tag{A3}$$

where

$$\mu^{\circ} := -k_{B}T \ln q \tag{A4}$$

can be identified as *standard chemical potentials*. Since the contribution deriving from the solvent,  $g_s := -k_BT \ln q_s(n_s)$ , is constant, it can be set to zero without loss of generality. We emphasize that despite the idealizations that we introduced, Eq. (A<sub>3</sub>) is consistent with a rigorous approach based on mean-force potentials, *cf.* [8<sub>7</sub>, Eq. F.44.a].

The Gibbs free energy changes along internal reactions read

<span id="page-25-4"></span>
$$\begin{split} &\Delta_{\rho_i} g = g_{\mathfrak{n} + \mathbf{S}_{\rho_i}} - g_{\mathfrak{n}} \\ &= (\mu^\circ - 1 k_B T \ln n_s) \cdot \mathbf{S}_{\rho_i} + k_B T \ln \frac{(\mathfrak{n} + \mathbf{S}_{\rho_i})!}{\mathfrak{n}!} \,. \end{split} \tag{A5}$$

Thermodynamic Limit For  $V \gg 1$ ,  $n \gg 1$ , and finite [z] = n/V, the Gibbs potential (A<sub>3</sub>) becomes

<span id="page-25-1"></span>
$$q_{\mathbf{n}}/V \simeq \mathbf{\mu} \cdot [\mathbf{z}] - k_{\mathbf{B}} T[\mathbf{z}] \cdot \mathbf{1}$$
, (A6)

where

$$\mu = \mu^{\circ} + k_{\mathrm{B}} \mathsf{T} \ln \{ [\mathbf{z}]/[\mathbf{s}] \} \tag{A7}$$

are the *chemical potentials* of solutes in an ideal dilute solution, and  $[s] = n_s/V$  is the concentration of solvent. We thus recover the Gibbs free energy density of ideal dilute solutions, see *e.g.* [51, 90].

When applying the same limit to the Gibbs free energy differences, Eq. (A<sub>5</sub>), we recover the *Gibbs free energies of reaction*,

<span id="page-25-0"></span>
$$\Delta_{o_i} \mathfrak{q} \simeq \mathfrak{u} \cdot \mathbf{S}_{o_i}$$
 (A8)

This result also justifies the form of the second term in the local detailed balance of exchange reactions, Eq. (53).

Remark The chemical potentials of ideal dilute solutions obtained in Eq. (A7) are expressed in terms of the concentration of the solvent. By including this term in  $\mu^{\circ}$  and introducing a reference concentration for each species  $[\mathbf{z}_0]$ , we recover the common expression for the potential of ideal dilute solutions  $\mu = \hat{\mu}^{\circ} + k_B T \ln\{[\mathbf{z}]/[\mathbf{z}_0]\}$ , where the standard-state chemical potential  $\hat{\mu}^{\circ} := \mu^{\circ} + k_B T \ln\{[\mathbf{z}_0]/[\mathbf{s}]\}$  is that measured at the reference concentration.

Summarizing,  $g_n$  given in Eq. (A<sub>3</sub>) characterizes the free energy of each CRN state. In the thermodynamic limit, the traditional potentials of ideal dilute solutions are recovered.

#### <span id="page-25-5"></span><span id="page-25-2"></span>Appendix B: Proofs of Detailed Fluctuation Theorems

To prove the finite time detailed FTs (158) we use a moment generating functions and change the notation in favor of one using brackets and operators.

Let  $P_t(n, W_d, \{W_{y_f}^{nc}\})$  be the joint probability of observing a trajectory ending in the state n along which the driving work is  $W_d$  while the nonconservative contributions are  $\{W_{y_f}^{nc}\}$ . These probabilities, one for each n, are stacked in the ket  $|P_t(W_d, \{W_{y_f}^{nc}\})\rangle$ . The time evolution of their moment generating function,

$$|\Lambda_t(\xi_d,\{\xi_{y_f}\})\rangle := \int dW_d \prod_{y_f} dW_{y_f}^{nc} \exp\left\{-\xi_d W_d - \sum_{y_f} \xi_{y_f} W_{y_f}^{nc}\right\} |P_t(W_d,\{W_{y_f}^{nc}\})\rangle , \tag{B1}$$

is ruled by the biased stochastic dynamics

$$d_{t} |\Lambda_{t}(\xi_{d}, \{\xi_{y_{f}}\})\rangle = \mathcal{W}_{t}(\xi_{d}, \{\xi_{y_{f}}\}) |\Lambda_{t}(\xi_{d}, \{\xi_{y_{f}}\})\rangle , \tag{B2}$$

where the entries of the biased generator are given by

$$\mathcal{W}_{\mathbf{mn},\mathbf{t}}(\xi_{d},\{\xi_{y_{f}}\}) = \sum_{\rho} w_{\rho}(\mathbf{n}) \left\{ \exp\left\{-\sum_{y_{f}} \xi_{y_{f}} \mathcal{F}_{y_{f}}(-S_{\rho}^{y_{f}})\right\} \delta_{\mathbf{m},\mathbf{n}+\mathbf{S}_{\rho}} - \delta_{\mathbf{m},\mathbf{n}} \right\} - \xi_{d} \partial_{\mathbf{t}} \mathfrak{g}_{\mathbf{m}} \delta_{\mathbf{n},\mathbf{m}}. \tag{B3}$$

We denoted the entries of  $S_{\rho}^{Y_f}$  as  $\{S_{\rho}^{y_f}\}$ . As a consequence of the local detailed balance (94), the stochastic generator satisfies the following symmetry

<span id="page-26-6"></span><span id="page-26-5"></span>
$$W_{t}^{T}(\xi_{d},\{\xi_{u_{f}}\}) = \mathcal{B}_{t}^{-1} W_{t}(\xi_{d},\{1-\xi_{u_{f}}\}) \mathcal{B}_{t},$$
(B4)

where the entries of  $\mathcal{B}_t$  are given by

$$\mathcal{B}_{\mathbf{nm},\mathbf{t}} := \exp\{-\beta \mathfrak{g}_{\mathbf{m}}(\mathbf{t})\} \delta_{\mathbf{n},\mathbf{m}}. \tag{B5}$$

Introducing the partition function for the generic equilibrium state identified by the protocol at time  $\tau$ ,  $\mathcal{Z}_{\tau} \equiv \mathcal{Z}(\pi_{\tau}, \{L_{\lambda_n}\}) = \exp\{-\beta \mathcal{G}_{eq_{\tau}}\}$ , the initial condition can be written as

$$|\Lambda_0(\xi_d, \{\xi_{u_f}\})\rangle = |p_{eq_0}\rangle = \mathcal{B}_0/\mathcal{Z}_0|1\rangle . \tag{B6}$$

The ket  $|1\rangle$  refers to the vector in the state space whose entries are all equal to one.

In order to proceed further, it is convenient to first prove a preliminary result. Let us consider the generic biased dynamics, e.g. Eq. (B2),

<span id="page-26-0"></span>
$$d_{t} |\Lambda_{t}(\xi)\rangle = \mathcal{W}_{t}(\xi) |\Lambda_{t}(\xi)\rangle , \qquad (B7)$$

whose initial condition is  $|\Lambda_0(\xi)\rangle = |p(0)\rangle$ . A formal solution of Eq. (B7) is  $|\Lambda_t(\xi)\rangle = \mathcal{U}_t(\xi) |p(0)\rangle$ , where the time-evolution operator reads  $\mathcal{U}_t(\xi) = \mathcal{T}_+ \exp\left\{\int_0^t d\tau \, \mathcal{W}_\tau(\xi)\right\}$ ,  $\mathcal{T}_+$  being the time-ordering operator. We clearly have  $d_t\mathcal{U}_t(\xi) = \mathcal{W}_t(\xi)\mathcal{U}_t(\xi)$ . Let us now consider the following transformed evolution operator

<span id="page-26-2"></span><span id="page-26-1"></span>
$$\tilde{\mathcal{U}}_{\mathsf{t}}(\xi) := \mathcal{X}_{\mathsf{t}}^{-1} \mathcal{U}_{\mathsf{t}}(\xi) \mathcal{X}_{\mathsf{0}} \,, \tag{B8}$$

 $\chi_t$  being a generic invertible operator. Its dynamics is ruled by the following biased stochastic dynamics

<span id="page-26-3"></span>
$$d_t \tilde{\mathcal{U}}_t(\xi) = d_t \mathcal{X}_t^{-1} \mathcal{U}_t(\xi) \mathcal{X}_0 + \mathcal{X}_t^{-1} d_t \mathcal{U}_t(\xi) \mathcal{X}_0 = \left\{ d_t \mathcal{X}_t^{-1} \mathcal{X}_t + \mathcal{X}_t^{-1} \mathcal{W}_t(\xi) \mathcal{X}_t \right\} \tilde{\mathcal{U}}_t(\xi) \equiv \tilde{\mathcal{W}}_t(\xi) \, \tilde{\mathcal{U}}_t(\xi) \, , \tag{B9}$$

which allows us to conclude that the transformed time-evolution operator is given by

$$\tilde{\mathcal{U}}(\xi) = \mathcal{T}_{+} \exp\left\{ \int_{0}^{t} d\tau \, \tilde{\mathcal{W}}_{\tau}(\xi) \right\} \,. \tag{B10}$$

From Eqs. (B8), (B9) and (B10) we deduce that

<span id="page-26-4"></span>
$$\mathcal{X}_{t}^{-1}\mathcal{U}_{t}(\xi)\mathcal{X}_{0} = \mathcal{T}_{+} \exp\left\{\int_{0}^{t} d\tau \left[d_{\tau}\mathcal{X}_{\tau}^{-1}\mathcal{X}_{\tau} + \mathcal{X}_{\tau}^{-1}\mathcal{W}_{\tau}(\xi)\mathcal{X}_{\tau}\right]\right\}. \tag{B11}$$

We can now come back to our specific biased stochastic dynamics (B2). The moment generating function of  $P_t(W_d, \{W_{y_f}^{nc}\})$  is given by

<span id="page-26-7"></span>
$$\Lambda_t(\xi_d,\{\xi_{y_f}\}) = \left\langle 1 | \Lambda_t(\xi_d,\{\xi_{y_f}\}) \right\rangle = \left\langle 1 | \mathcal{U}_t(\xi_d,\{\xi_{y_f}\}) \mathcal{B}_0 / \mathcal{I}_0 | 1 \right\rangle \\ = \left\langle 1 | \frac{\mathcal{B}_t}{\mathcal{I}_t} \mathcal{B}_t^{-1} \, \mathcal{U}_t(\xi_d,\{\xi_{y_f}\}) \, \mathcal{B}_0 | 1 \right\rangle \, \frac{\mathcal{I}_t}{\mathcal{I}_0} \,, \tag{B12}$$

where  $\mathcal{U}_t(\xi_d, \{\xi_{y_f}\})$  is the time-evolution operator of the biased stochastic dynamics (B2). Note that  $\langle 1|\mathcal{B}_t/\mathcal{Z}_t$  is the equilibrium initial distribution of the backward process  $\langle p_{eq_t}|$ . Using the relation in Eq. (B11), the last term can be rewritten as

$$= \langle p_{eq_t} | \mathcal{T}_+ \exp \left\{ \int_0^t d\tau \left[ \partial_\tau \mathcal{B}_\tau^{-1} \mathcal{B}_\tau + \mathcal{B}_\tau^{-1} \mathcal{W}_\tau (\xi_d, \{\xi_{y_f}\}) \, \mathcal{B}_\tau \right] \right\} | 1 \rangle \exp \left\{ -\beta \Delta \mathcal{G}_{eq} \right\} \,, \tag{B13}$$

where  $\Delta g_{eq}$  is defined in Eq. (159). Since  $\partial_{\tau} \mathcal{B}_{\tau}^{-1} \mathcal{B}_{\tau} = \text{diag} \{\partial_{\tau} \mathfrak{g}_{\mathbf{n}}\}$  the first term in square bracket can be added to the diagonal entries of the second term, thus giving

$$= \left\langle p_{eq_t} | \mathcal{T}_+ \exp \left\{ \int_0^t d\tau \left[ \mathcal{B}_\tau^{-1} \, \mathcal{W}_\tau(\xi_d - 1, \{\xi_{y_f}\}) \, \mathcal{B}_\tau \right] \right\} | 1 \right\rangle \exp \left\{ -\beta \Delta \mathcal{G}_{eq} \right\} \,. \tag{B14}$$

The symmetry (B<sub>4</sub>) allow us to recast the latter into

<span id="page-27-0"></span>
$$= \langle p_{eq_t} | \mathcal{T}_+ \exp \left\{ \int_0^t d\tau \, \mathcal{W}_\tau^\mathsf{T} \left( \xi_d - 1, \{1 - \xi_{y_f}\} \right) \right\} | 1 \rangle \exp \left\{ -\beta \Delta \mathcal{G}_{eq} \right\} \,. \tag{B15}$$

The crucial step comes as we transform the integration variable from  $\tau$  to  $\tau^{\dagger} = t - \tau$ . Accordingly, the time-ordering operator,  $\mathcal{T}_+$ , becomes an anti-time-ordering one  $\mathcal{T}_-$ , while the diagonal entries of the biased generator become

$$\mathcal{W}_{\mathbf{mm},\mathbf{t}-\tau^{\dagger}}(\xi_{\mathbf{d}},\{\xi_{\mathbf{y}_{\mathbf{f}}}\}) = \sum_{\mathbf{p}} w_{\mathbf{p}}(\mathbf{m},\mathbf{t}-\tau^{\dagger}) + \xi_{\mathbf{d}} \, \partial_{\tau^{\dagger}} \mathfrak{g}_{\mathbf{m}}(\mathbf{t}-\tau^{\dagger}) \tag{B16}$$

from which we conclude that

$$W_{\mathbf{nm},t-\tau^{\dagger}}(\xi_{d},\{\xi_{y_{f}}\}) = W_{\mathbf{nm},t-\tau^{\dagger}}(-\xi_{d},\{\xi_{y_{f}}\}) =: W_{\mathbf{nm},\tau^{\dagger}}^{\dagger}(-\xi_{d},\{\xi_{y_{f}}\}).$$
(B17)

 $W_{\tau^{\dagger}}^{\dagger}(\xi_{d_f}(\xi_{y_f}))$  is the biased generator of the dynamics subject to the time-reversed protocol,  $\pi^{\dagger}$ , *i.e.* the dynamics of the backward process. Equation (B15) thus becomes

$$= \langle p_{eq_t} | \mathcal{T}_{-} \exp \left\{ \int_0^t d\tau^{\dagger} \, \mathcal{W}_{\tau^{\dagger}}^{\dagger} \left( 1 - \xi_{d}, \{ 1 - \xi_{y_f} \} \right) \right\} | 1 \rangle \exp \left\{ -\beta \Delta \mathcal{G}_{eq} \right\} . \tag{B18}$$

Upon a global transposition, we can write

$$= \langle 1 | \mathcal{T}_{+} \exp \left\{ \int_{0}^{t} d\tau^{\dagger} \, \mathcal{W}_{\tau^{\dagger}}^{\dagger} \left( 1 - \xi_{d}, \{ 1 - \xi_{y_{f}} \} \right) \right\} | p_{eq_{t}} \rangle \exp \left\{ -\beta \Delta \mathcal{G}_{eq} \right\} \,, \tag{B19}$$

where we also used the relationship between transposition and time-ordering

$$\mathfrak{I}_{+}\left(\prod_{i} \mathsf{A}_{\mathsf{t}_{1}}^{\mathsf{T}}\right) = \left(\mathfrak{I}_{-} \prod_{i} \mathsf{A}_{\mathsf{t}_{1}}\right)^{\mathsf{T}},\tag{B20}$$

in which At is a generic operator. From the last expression, we readily obtain

$$\begin{split} &= \langle 1 | \mathcal{U}_{t}^{\dagger} \left( 1 - \xi_{d}, \{ 1 - \xi_{y_{f}} \} \right) | p_{eq_{t}} \rangle \exp \left\{ -\beta \Delta \mathcal{G}_{eq} \right\} \\ &= \Lambda_{t}^{\dagger} \left( 1 - \xi_{d}, \{ 1 - \xi_{y_{f}} \} \right) \exp \left\{ -\beta \Delta \mathcal{G}_{eq} \right\} \,, \end{split} \tag{B21}$$

where  $\Lambda_t^{\dagger}\left(\xi_d,\{\xi_{y_f}\}\right)$  is the moment generating function of  $P_t^{\dagger}(W_d,\{W_{y_f}^{nc}\})$ . Summarizing, we have the following symmetry

<span id="page-27-1"></span>
$$\Lambda_{t}(\xi_{d},\{\xi_{y_{f}}\}) = \Lambda_{t}^{\dagger} \left(1 - \xi_{d},\{1 - \xi_{y_{f}}\}\right) exp\left\{-\beta \Delta \mathcal{G}_{eq}\right\} \,, \tag{B22}$$

whose inverse Laplace transform gives the FT in Eq. (158).

## Fluctuation Theorem for Emergent Stoichiometric Cycles Currents

The finite-time detailed FT for nonconservative contributions along fundamental cycles, Eq. (164), follows the same logic and mathematical steps described above. The moment generating function which now must be taken into account is

<span id="page-27-2"></span>
$$|\Lambda_{t}(\xi_{d}, \{\xi_{\eta}\})\rangle := \int dW_{d} \prod_{\eta} d\Gamma_{\eta} \exp\left\{-\xi_{d}W_{d} - \sum_{\eta} \xi_{\eta} \Gamma_{\eta}\right\} |P_{t}(W_{d}, \{\Gamma_{\eta}\})\rangle , \qquad (B23)$$

which is ruled by the biased generator whose entries are

$$W_{\mathbf{mn},\mathbf{t}}(\xi_{\mathbf{d}},\{\xi_{\mathbf{\eta}}\}) = \sum_{\rho} w_{\rho}(\mathbf{n}) \left\{ \exp\left\{ -\sum_{\eta} \xi_{\eta} \mathcal{A}_{\eta} \zeta_{\eta,\rho} \right\} \delta_{\mathbf{m},\mathbf{n}+\mathbf{S}_{\rho}} - \delta_{\mathbf{m},\mathbf{n}} \right\} - \xi_{\mathbf{d}} \partial_{\mathbf{t}} \mathfrak{g}_{\mathbf{m}} \delta_{\mathbf{n},\mathbf{m}}. \tag{B24}$$

The symmetry of the latter generator—on top of which the proof is constructed—is based on the expression of the local detailed balance given in Eq. (94),

<span id="page-27-3"></span>
$$W_{t}^{\mathsf{T}}(\xi_{\mathsf{d}},\{\xi_{\mathsf{n}}\}) = \mathcal{B}_{t}^{-1} W_{t}(\xi_{\mathsf{d}},\{1-\xi_{\mathsf{n}}\}) \mathcal{B}_{t}, \tag{B25}$$

where the entries of  $\mathcal{B}_t$  are given in Eq. (B5). Following the steps from Eq. (B12) to Eq. (B22), with the definitions and equations in Eqs. (B23)–(B25), proves the FT in Eq. (164).

- <span id="page-28-0"></span>[1] T. L. Hill, Free energy transduction in biology (Academic Press, New York, 1977); Free Energy Transduction and Biochemical Cycle Kinetics (Dover, 2005).
- <span id="page-28-1"></span>[2] J. Schnakenberg, Rev. Mod. Phys. 48, 571 (1976).
- <span id="page-28-2"></span>[3] D. A. McQuarrie, J. Appl. Probab. 4, 413 (1967).
- <span id="page-28-3"></span>[4] D. T. Gillespie, Physica A 188, 404 (1992).
- <span id="page-28-4"></span>[5] J.-l. Luo, C. Van den Broeck, and G. Nicolis, Z. Phys. B **56**, 165 (1984).
- [6] C. Y. Mou, J.-l. Luo, and G. Nicolis, J. Chem. Phys. 84, 7011 (1986).
- [7] Q. Zheng and J. Ross, J. Chem. Phys. 94, 3644 (1991).
- <span id="page-28-5"></span>[8] M. O. Vlad and J. Ross, J. Chem. Phys. 100, 7268 (1994).
- <span id="page-28-6"></span>[9] K. Sekimoto, *Stochastic Energetics*, 1st ed., Lecture Notes in Physics, Vol. 799 (Springer-Verlag Berlin Heidelberg, 2010).
- [10] C. Jarzynski, Annu. Rev. Condens. Matter Phys. 2, 329 (2011).
- <span id="page-28-35"></span>[11] U. Seifert, Rep. Prog. Phys. 75, 126001 (2012).
- <span id="page-28-7"></span>[12] C. Van den Broeck and M. Esposito, Physica A 418, 6
- <span id="page-28-8"></span>[13] P. Gaspard, J. Chem. Phys. 120, 8898 (2004).
- <span id="page-28-9"></span>[14] D. Andrieux and P. Gaspard, J. Chem. Phys. 121, 6167 (2004).
- <span id="page-28-10"></span>[15] D. Andrieux and P. Gaspard, J. Stat. Phys. 127, 107 (2007).
- <span id="page-28-11"></span>[16] H. Ge and H. Qian, Phys. Rev. Lett. 103, 148103 (2009).
- [17] M. Vellela and H. Qian, J. R. Soc. Interface 6, 925 (2009).
- <span id="page-28-12"></span>[18] H. Qian and L. M. Bishop, Int. J. Mol. Sci. 11, 3472 (2010).
- <span id="page-28-13"></span>[19] T. Schmiedl and U. Seifert, J. Chem. Phys. 126, 044101
- <span id="page-28-14"></span>[20] F. Horn and R. Jackson, Arch. Ration. Mech. An. 47, 81 (1972).
- <span id="page-28-15"></span>[21] M. Feinberg, Arch. Ration. Mech. An. 49, 187 (1972).
- <span id="page-28-16"></span>[22] D. F. Anderson, G. Craciun, and T. G. Kurtz, Bull. Math. Biol. 72, 1947 (2010).
- <span id="page-28-17"></span>[23] D. Cappelletti and C. Wiuf, SIAM J. Appl. Math. 76, 411 (2016).
- <span id="page-28-18"></span>[24] M. Polettini and M. Esposito, J. Chem. Phys. **141**, 024117 (2014).
- <span id="page-28-19"></span>[25] R. Rao and M. Esposito, Phys. Rev. X 6, 041064 (2016).
- <span id="page-28-20"></span>[26] M. Polettini, A. Wachtel, and M. Esposito, J. Chem. Phys. 143, 184103 (2015).
- <span id="page-28-21"></span>[27] Y. Murashita, K. Funo, and M. Ueda, Phys. Rev. E 90, 042110 (2014).
- <span id="page-28-22"></span>[28] M. Esposito and C. Van den Broeck, Europhys. Lett. 95, 40004 (2011).
- <span id="page-28-23"></span>[29] J. M. R. Parrondo, J. M. Horowitz, and T. Sagawa, Nature Phys. 11, 131 (2015).
- <span id="page-28-24"></span>[30] H. Qian and D. A. Beard, Biophys. Chem. 114, 213 (2005).
- <span id="page-28-25"></span>[31] G. Nicolis and I. Prigogine, Self-organization in Nonequilibrium Systems: From Dissipative Structures to Order Through Fluctuations (Wiley-Blackwell, 1977).
- <span id="page-28-26"></span>[32] T. G. Kurtz, J. Chem. Phys. 57, 2976 (1972).
- <span id="page-28-27"></span>[33] D. T. Gillespie, Ann. Rev. Phys. Chem. 58, 35 (2007).

- <span id="page-28-28"></span>[34] R. A. Alberty, *Thermodynamics of biochemical reactions* (Wiley-Interscience, 2003).
- <span id="page-28-29"></span>[35] H. S. Haraldsdóttir and R. M. T. Fleming, PLoS Comput. Biol. 12, e1004999 (2016).
- <span id="page-28-30"></span>[36] D. Kondepudi and I. Prigogine, *Modern Thermodynamics:* From Heat Engines to Dissipative Structures, 2nd ed. (Wiley, 2014), § 15.1.I. Prigogine, Physica 15, 272 (1949).
- <span id="page-28-31"></span>[37] T. M. Cover and J. A. Thomas, *Elements of Information Theory*, 2nd ed. (Wiley-Interscience, 2006).
- <span id="page-28-32"></span>[38] T. de Donder, L'affinité, Mémoires de la Classe des sciences No. vol. 1 (Gauthier-Villars, 1927).
- <span id="page-28-33"></span>[39] U. Seifert, Phys. Rev. Lett. 95, 040602 (2005).
- <span id="page-28-34"></span>[40] H. Callen, *Thermodynamics and an Introduction to Thermostatistics* (Wiley, 1985).
- <span id="page-28-36"></span>[41] S. R. de Groot and P. Mazur, Non-equilibrium Thermodynamics (Dover, 1984).
- <span id="page-28-37"></span>[42] G. Bochkov and Y. Kuzovlev, Zh. Eksp. Teor. Fiz. **72**, 238
- [43] G. Bochkov and Y. Kuzovlev, Zh. Eksp. Teor. Fiz. **76**, 1071 (1979).
- <span id="page-28-42"></span>[44] C. Jarzynski, Phys. Rev. Lett. 78, 2690 (1997).
- <span id="page-28-38"></span>[45] J. Horowitz and C. Jarzynski, J. Stat. Mech. Theor. Exp. **2007**, P11002 (2007).
- <span id="page-28-39"></span>[46] P. Krapivsky, S. Redner, and E. Ben-Naim, *A Kinetic View of Statistical Physics* (Cambridge University Press, 2010).
- [47] R. Rao, D. Lacoste, and M. Esposito, J. Chem. Phys. 143, 244903 (2015).
- <span id="page-28-40"></span>[48] D. Andrieux and P. Gaspard, Proc. Natl. Acad. Sci. U.S.A. 105, 9516 (2008).
- <span id="page-28-41"></span>[49] B. Altaner, J. Phys. A: Math. Theor. 50, 454001 (2017).
- <span id="page-28-43"></span>[50] G. E. Crooks, J. Stat. Phys. 90, 1481 (1998).
- <span id="page-28-44"></span>[51] L. Peliti, *Statistical Mechanics in a Nutshell* (Princeton University Press, 2011), § 3.15.
- <span id="page-28-45"></span>[52] A. Kolmogoroff, Math. Ann. 112, 155 (1936).
- [53] F. P. Kelly, *Reversibility and Stochastic Networks* (John Wiley & Sons Ltd., 1979).
- <span id="page-28-46"></span>[54] S. Schuster and R. Schuster, J. Math. Chem. 3, 25 (1989).
- <span id="page-28-47"></span>[55] M. Polettini, Lett. Math. Phys. 105, 89 (2014).
- <span id="page-28-48"></span>[56] D. Andrieux and P. Gaspard, J. Stat. Mech. Theor. Exp., Po2006 (2007).
- <span id="page-28-49"></span>[57] M. Polettini, G. Bulnes Cuetara, and M. Esposito, Phys. Rev. E 94, 052117 (2016).
- <span id="page-28-50"></span>[58] R. Rao and M. Esposito, New J. Phys. 20, 023007 (2018).
- <span id="page-28-51"></span>[59] W. J. Heuett and H. Qian, J. Chem. Phys. **124**, 044110 (2006).
- <span id="page-28-52"></span>[60] M. Campisi, P. Hänggi, and P. Talkner, Rev. Mod. Phys. 83, 771 (2011).
- <span id="page-28-53"></span>[61] G. E. Crooks, Phys. Rev. E 60, 2721 (1999).
- <span id="page-28-54"></span>[62] G. Bulnes Cuetara, M. Esposito, and A. Imparato, Phys. Rev. E 89, 052119 (2014).
- <span id="page-28-55"></span>[63] R. Landauer, IBM J. Res. Dev. 44, 261 (2000).
- <span id="page-28-56"></span>[64] M. Esposito, U. Harbola, and S. Mukamel, *Phys. Rev. E* **76**, 031132 (2007).

- <span id="page-29-0"></span>[65] H. Ge and H. Qian, Chem. Phys. 472, 241 (2016).
- <span id="page-29-1"></span>[66] K. Proesmans, Y. Dreher, M. Gavrilov, J. Bechhoefer, and C. Van den Broeck, Phys. Rev. X 6, 041010 (2016).
- <span id="page-29-2"></span>[67] S. Ciliberto, Phys. Rev. X 7, 021051 (2017).
- <span id="page-29-3"></span>[68] U. Seifert, Eur. Phys. J. E 34, 26 (2011).
- [69] R. Rao and L. Peliti, J. Stat. Mech. Theor. Exp., P06001 (2015).
- <span id="page-29-7"></span>[70] S. Bo, M. Del Giudice, and A. Celani, J. Stat. Mech. Theor. Exp., P01014 (2015).
- <span id="page-29-4"></span>[71] B. Altaner, A. Wachtel, and J. Vollmer, Phys. Rev. E 92, 042133 (2015).
- <span id="page-29-5"></span>[72] R. D. Astumian, Annu. Rev. Biophys. 40, 289 (2011).
- <span id="page-29-6"></span>[73] M. Esposito and J. M. R. Parrondo, Phys. Rev. E 91, 052114 (2015).
- <span id="page-29-8"></span>[74] J. M. Horowitz and M. Esposito, Phys. Rev. X 4, 031015 (2014).
- <span id="page-29-9"></span>[75] T. E. Ouldridge, C. C. Govern, and P. R. ten Wolde, Phys. Rev. X 7, 021004 (2017).
- <span id="page-29-10"></span>[76] D. Soloveichik, M. Cook, E. Winfree, and J. Bruck, Nat. Comp. 7, 615 (2008).
- <span id="page-29-11"></span>[77] W. Poole, A. Ortiz-Muñoz, A. Behera, N. S. Jones, T. E. Ouldridge, E. Winfree, and M. Gopalkrishnan, in *DNA Computing and Molecular Programming*, edited by R. Brijder and L. Qian (Springer, Cham, 2017) pp. 210–231.

- <span id="page-29-12"></span>[78] P. Sartori and S. Pigolotti, Phys. Rev. X 5, 041039 (2015).
- <span id="page-29-13"></span>[79] T. E. Ouldridge and P. R. ten Wolde, Phys. Rev. Lett. 118, 158103 (2017).
- <span id="page-29-14"></span>[80] W. Bialek, *Biophysics: Searching for Principles* (Princeton University Press, 2012).
- <span id="page-29-15"></span>[81] G. Tkačik and W. Bialek, Annu. Rev. Condens. Matter Phys. 7, 1 (2016).
- <span id="page-29-16"></span>[82] P. C. Bressloff and J. M. Newby, Phys. Rev. E **89**, 042701 (2014).
- <span id="page-29-17"></span>[83] S. Winkelmann and C. Schütte, J. Chem. Phys. **147**, 114115 (2017).
- <span id="page-29-18"></span>[84] A. Wachtel, R. Rao, and M. Esposito, New J. Phys. 20, 042002 (2018).
- <span id="page-29-19"></span>[85] R. Dirks, J. Bois, J. Schaeffer, E. Winfree, and N. Pierce, SIAM Rev. 49, 65 (2007).
- <span id="page-29-20"></span>[86] D. A. McQuarrie, *Statistical Mechanics* (Harper & Row, 1976).
- <span id="page-29-22"></span>[87] B. Diu, C. Guthmann, D. Lederer, and B. Roulet, Éléments de physique statistique (Hermann, 1989).
- [88] D. A. Beard and H. Qian, *Chemical Biophysics. Quantitative Analysis of Cellular Systems* (Cambridge University Press, 2008).
- <span id="page-29-21"></span>[89] T. E. Ouldridge, Nat. Comp. 17, 3 (2017).
- <span id="page-29-23"></span>[90] E. Fermi, *Thermodynamics* (Dover, 1956).