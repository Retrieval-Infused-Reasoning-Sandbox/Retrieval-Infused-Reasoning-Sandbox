# Steady state thermodynamics of ideal gas in shear flow

Karol Makuch,[∗](#page-0-0) Konrad Giżyński, and Robert Hołyst[†](#page-0-1) Institute of Physical Chemistry, Polish Academy of Sciences Kasprzaka 44/52, 01-224 Warszawa

## Anna Maciołek

Institute of Physical Chemistry, Polish Academy of Sciences Kasprzaka 44/52, 01-224 Warszawa and Max-Planck-Institut für Intelligente Systeme Stuttgart, Heisenbergstr. 3, D-70569 Stuttgart, Germany

## Paweł J. Żuk

Institute of Physical Chemistry, Polish Academy of Sciences Kasprzaka 44/52, 01-224 Warszawa and Department of Physics, Lancaster University, Lancaster LA1 4YB, United Kingdom

Equilibrium thermodynamics describes the energy exchange of a body with its environment. Here, we describe the global energy exchange of an ideal gas in the Coutte flow in a thermodynamic-like manner. We derive a fundamental relation between internal energy as a function of parameters of state. We analyze a non-equilibrium transition in the system and postulate the extremum principle, which determines stable stationary states in the system. The steady-state thermodynamic framework resembles equilibrium thermodynamics.

## I. INTRODUCTION

There is mounting evidence that the exchange of energy of a macroscopic steady state system with its environment can be described in an equilibrium thermodynamic-like fashion. It has been considered in the 90s of the twentieth century for systems with chemical reactions that may constantly occur in time [\[1–](#page-6-0) [3\]](#page-6-1). Such a steady state situation goes beyond equilibrium thermodynamics which excludes any macroscopic flows and currents [\[4\]](#page-6-2). Around a similar time, the thermodynamic-like approach was introduced for systems with shear-flow [\[5](#page-6-3)[–8\]](#page-6-4) and is still under development [\[9–](#page-6-5) [12\]](#page-6-6). Another class of macroscopic systems for which the attempt to introduce thermodynamic description has been undertaken is systems with heat flow [\[13–](#page-6-7)[17\]](#page-6-8).

The above approaches to formulate steady state thermodynamics focus on chemical reactions and shear flow, both in homogeneous temperature profiles or systems with heat flow without chemical reactions and macroscopic flows. If steady state thermodynamics is ever formulated on general grounds, it is now at its inception. About two decades ago, Oono and Paniconi [\[18\]](#page-6-9) and Sasa and Hatano [\[19\]](#page-7-0) postulated a thermodynamic-like description based on a general footing. However, because the descriptions were postulated, they require validation and further investigation on the eventual limitation. In particular, it is not clear whether the nonequilibrium entropy defined by the integral of the local entropy density over the volume of the system [\[14\]](#page-6-10) or rather the excess heat-based entropy [\[18\]](#page-6-9) should be used to construct the principles of steady-state thermodynamics. These two entropies are not equivalent [\[16\]](#page-6-11). It shows that the steady state thermodynamics is far from complete, and the core fundamental questions still remain open [\[14,](#page-6-10) [17\]](#page-6-8). It is worth mentioning stochastic thermodynamics, which focuses on thermodynamic notions for the system on the level of individual trajectories [\[20,](#page-7-1) [21\]](#page-7-2). Here we focus on a reduced, macroscopic description of a steady state system [\[22\]](#page-7-3).

Allowing various macroscopic constant fluxes drives the system from equilibrium to a steady state and opens up phenomena that eludes equilibrium thermodynamics. Take for example a quiescent liquid in a uniform gravitational field in equilibrium. This situation assumes a uniform temperature and no macroscopic flows, which, together with the equations of state, determine the thermodynamic parameters at each point of the system. Allowing a vertical or horizontal heat flow radically changes the situation. The flow of heat combined with the gravitational force can cause regular mass movement, either because the denser liquid is at the top and the thinner is at the bottom or because gravity unevenly acts on areas with different horizontal densities. This unstable situation causes a mass movement in the atmosphere, oceans, planets, and stars [\[23\]](#page-7-4). The core feature of this phenomenon is the coupling between the heat flow and the mass flow. However, the question arises whether some reduced description for non-equilibrium steady states also emerges from hydrodynamics. Can it take the shape of equilibrium thermodynamics, in which the system's behavior is described by only a few parameters and the rules of extremum containing only these parameters?

Here we present a thermodynamic-like description of a system with heat and mass flow coupling. We consider ideal gas in shear flow with a dissipative temperature profile shown schematically in Fig. [1.](#page-1-0) We introduce the first law for this system that describes different ways of exchanging the system's energy with its environment. We also consider a movable wall as a thermodynamic constraint in the system. We introduce the extremum principle that determines the position of the wall. We

<span id="page-0-0"></span><sup>∗</sup> [kmakuch@ichf.edu.pl](mailto:kmakuch@ichf.edu.pl)

<span id="page-0-1"></span><sup>†</sup> [rholyst@ichf.edu.pl](mailto:rholyst@ichf.edu.pl)

show that there is a critical shear in the system above which the equilibrium position of the internal wall becomes unstable, and the system undergoes a nonequilibrium second order phase transition. We give a complete thermodynamic-like description of this steady state system in which the position of the movable wall is a thermodynamic constraint. For the vanishing shear flow, the steady state extremum principle directly reduces to the minimum principle in the corresponding problem in thermodynamics.

### II. SYSTEM

We consider ideal monoatomic gas between two two parallel walls at walls' temperature  $T_0$ , as shown in Fig. 1. The upper wall moves with speed  $V_w$  moving in x-direction. The system is described by irreversible thermodynamic equations: the continuity equation, Navier-Stokes equation, energy balance and two equations of state [24]. We assume that the system is translationally invariant in x and y directions, therefore the fields depend only on z coordinate. In particular, equations of state are given by,

<span id="page-1-1"></span>
$$p(z) = n(z) k_B T(z), \qquad (1)$$

<span id="page-1-2"></span>
$$u(z) = \frac{3}{2}n(z)k_BT(z), \qquad (2)$$

with pressure p(z), volumetric particle number density n(z), temperature T(z), Boltzmann constant  $k_B$ , and the volumetric energy density, u(z). The velocity field also depends on z coordinate only and is oriented in the direction determined by the moving wall,

<span id="page-1-3"></span>
$$\mathbf{v}\left(x,y,z\right) = \mathbf{e}_{x}v\left(z\right). \tag{3}$$

### III. STEADY STATE

We describe the system within linear response theory [24]. Therefore, the system is locally described by equation of states (1) and (2) supplemented with mass, momentum and energy conservation. We neglect bulk viscosity. We assume that the shear viscosity coefficient  $\eta$  does not depend on the local state of the gas, so the viscosity does not depend on local density and temperature. The translational symmetry for the pressure,  $p(\mathbf{r}) = p(z)$ , and for the velocity given by Eq. (3) reduces the z-component of the Navier-Stokes equation.

$$\rho \left( \partial_t \mathbf{v} + (\mathbf{v} \cdot \nabla) \mathbf{v} \right) = -\nabla p + \eta \Delta \mathbf{v} + \frac{1}{3} \eta \nabla \left( \nabla \cdot \mathbf{v} \right), \quad (4)$$

to the formula, dp(z)/dz = 0, while the x-component of the Navier-Stokes equation gives  $0 = \eta d^2v(z)/dz^2$ . Therefore the pressure in the system is homogeneous,

<span id="page-1-6"></span>
$$p(z) = p, (5)$$

![](_page_1_Picture_13.jpeg)

Figure 1. Ideal gas in shear flow. The gas is confined by the immobile bottom wall and by the upper wall moving with velocity  $V_w$ . There is also a thermally insulating and moving internal wall that divides the gas into two subsystems. Shearing motion causes energy dissipation in the system, which changes the temperature profile. The heat flows out from the system through the confining walls at temperature T. Colors schematically show the temperature profile (red - hotter, blue - colder).

<span id="page-1-0"></span>and, using the boundary conditions v(0) = 0 and  $v(L) = V_w$ , there is a shear flow in the system,

<span id="page-1-4"></span>
$$v\left(z\right) = \frac{z}{L}V_{w}.\tag{6}$$

The continuity equation,

<span id="page-1-5"></span>
$$\partial_t \rho + \mathbf{v} \cdot \nabla \rho = -\rho \nabla \cdot \mathbf{v},\tag{7}$$

with mass density  $\rho\left(z\right)$  and the above velocity field is satisfied automatically for any density profile. The energy balance equation is given by,

$$\rho \left( \partial_t u_m + \mathbf{v} \cdot \nabla u_m \right) = \kappa \Delta T - p \nabla \cdot \mathbf{v} + 2\eta \left[ \mathring{\nabla} \mathbf{v} \right]^s : \left[ \mathring{\nabla} \mathbf{v} \right]^s, \tag{8}$$

where  $\left[\mathring{\nabla}\mathbf{v}\right]_{ij}^{s} = \left(\nabla_{i}\mathbf{v}_{j} + \nabla_{j}\mathbf{v}_{i} - \delta_{ij}\frac{2}{3}\nabla\cdot\mathbf{v}\right)/2$  denotes the symmetrized and traceless velocity gradient matrix, the colon is the double contraction,  $\delta_{ij}$  denotes the Kronecker delta, and  $u_{m} = u/\rho$  is the mass density of the internal energy. Utilizing the shear velocity profile (6) and the translational invariance of the internal energy density,  $u_{m}(z)$ , the energy balance equation reduces to the equation for the temperature profile

<span id="page-1-7"></span>
$$0 = \kappa \frac{d^2}{dz^2} T(z) + \eta \left(\frac{V_w}{L}\right)^2. \tag{9}$$

The above equation has the following form,  $0 = \kappa \frac{d^2}{dz^2} T(z) + \lambda$ , where  $\lambda$  is the volumetric heating rate,

$$\lambda = \eta \left(\frac{V_w}{L}\right)^2. \tag{10}$$

We also introduce the dimensionless parameter

$$D \equiv \frac{\eta V_w^2}{\kappa T_0}.$$

# IV. SHEAR FLOW WITHOUT THE INTERNAL WALL

We first consider the shear flowing system shown in Fig. 1, but without the internal wall. In this situation, the boundary conditions are that on the upper and lower surface and the temperature profile is given by,

<span id="page-2-8"></span>
$$T(z) = T_0 \left[ -\frac{1}{2} \frac{\lambda L^2}{\kappa T_0} \left( \frac{z}{L} \right)^2 + \frac{1}{2} \frac{\lambda L^2}{\kappa T_0} \frac{z}{L} + 1 \right].$$
 (11)

Number of particles in the surface area A of the translationally invariant system is determined by the particle density,  $N = A \int_0^L dz \, n(z)$ , which with the mechanical equation of state (1) and the above temperature profile gives

<span id="page-2-0"></span>
$$p = \frac{Nk_B T_0}{AL} \psi\left(\frac{\eta V_w^2}{\kappa T_0}\right),\tag{12}$$

where

$$\psi(D) \equiv \frac{D}{8\sqrt{\frac{D}{8+D}} \tanh^{-1} \sqrt{\frac{D}{8+D}}}.$$
 (13)

Combination of equations of state (1) and (2) gives the following internal energy density u(z) = 3p(z)/2. Total internal energy in the system is given by

<span id="page-2-7"></span>
$$U = A \int_{0}^{L} dz \, u(z) = \frac{3}{2} A L p, \tag{14}$$

where we used the fact, that the pressure in the system is constant. Utilizing Eq. (12) in the above equation we get,

<span id="page-2-1"></span>
$$U = \frac{3}{2} N k_B T_0 \psi \left( \frac{\eta V_w^2}{\kappa T_0} \right). \tag{15}$$

We determine the kinetic energy due to macroscopic motion,  $E_k = A \int_0^L dz \, mn(z) \, v^2(z) / 2$ , where m is a mass of a single ideal gas molecule. We obtain

<span id="page-2-2"></span>
$$E_k = mN \frac{V_w^2}{2} \varepsilon \left( \frac{\eta V_w^2}{\kappa T_0} \right), \tag{16}$$

where

<span id="page-2-3"></span>
$$\varepsilon(D) = \frac{2}{D} \left( \frac{4+D}{4} \frac{1}{\psi(D)} - 1 \right). \tag{17}$$

Utilizing Eqs. (15), (16) and (17) we obtain the relation between the kinetic and internal energy,

$$E_k \frac{\eta}{mN\kappa T_0} = \frac{4 + \frac{\eta V_w^2}{\kappa T_0}}{4} \frac{\frac{3}{2}Nk_B T_0}{U} - 1.$$
 (18)

### V. TRANSITION BETWEEN STEADY STATES AND ENERGY BALANCE

We consider transitions between steady states in the system. The system is in one steady state at time  $t_i$ , after which we slightly change one or more control parameters that appear in (or are related to) the governing equations. For example, we slowly modify the velocity of the wall, the position of the upper wall (volume V) or the external temperature  $T_0$ . In particular, we increase the velocity of the wall by  $V_w(t) = V_w + (t-t_i) \, dV_w/(t_f-t_i)$  for  $t_i < t < t_f$ , which modifies velocity of the wall from  $V_w$  to  $V_w + dV_w$ . This induces a time dependent hydrodynamic field. After time  $t_f$  the system reaches another steady state close to the previous one due to a small change in the control parameters. We focus on steady, nonequilibrium states with a constant number of particles in the system.

Previously we have analyzed the energy balance for an ideal gas in a heat flow [16] during the transition between steady states. The considerations necessary for Couette flow go along the same line. We do not repeat them but give a sketch. We monitor the change of the energy between times  $t_i$  and  $t_f$ ,

$$dU = U(t_f) - U(t_i) = \int_{t_i}^{t_f} dt \, \frac{dU(t)}{dt},$$

where

$$U(t) = \int_{V(t)} d^3 r \, \rho(\mathbf{r}, t) \, u(\mathbf{r}, t), \qquad (19)$$

and  $\rho(\mathbf{r},t)$  is the density and  $u(\mathbf{r},t)$  is the internal energy density per unit mass at position  $\mathbf{r}$  and time t. We then represent the time derivative of the above integral utilizing the internal energy balance equation (8). Applying analysis from [16] leads to the conclusion that the system exchanges the energy with the environment according to the following formula,

<span id="page-2-4"></span>
$$dU = dQ + dW + dD, \tag{20}$$

with the excess heat defined by

<span id="page-2-9"></span>
$$dQ = -\int_{t_{i}}^{t_{f}} dt \int_{\partial V(t)} d^{2}r \,\hat{n} \cdot \left(J_{q}\left(t\right) - J_{q,st}\left(t\right)\right), \quad (21)$$

where  $\hat{n}$  is the vector normal to the surface of volume V and  $J_q(t)$  is the heat flux in the system, with the work related to the expansion of the gas defined by

<span id="page-2-5"></span>
$$dW = -\int_{t_i}^{t_f} dt \int_{V(t)} d^3 r \, p \nabla \cdot \mathbf{v}, \qquad (22)$$

and the excess dissipation defined by,

<span id="page-2-6"></span>
$$dD = \int_{t_i}^{t_f} dt \int_{V(t)} d^3r \left( \Pi : \left[ \nabla \mathbf{v} \right] - \Pi_{st} \left( t \right) : \left[ \nabla \mathbf{v}_{st} \left( t \right) \right] \right),$$
(23)

where  $[\nabla \mathbf{v}]_{ij} = \nabla_i \mathbf{v}_j$  is the gradient velocity matrix. The subscript st in the above equations means that the quantity should be taken at a stationary state that corresponds to the control parameters at time t. The first term in the internal energy balance (20), dQ, is the heat on top of the steady state heat exchanged during the transition between steady states [18]. The second term in (20) is the volumetric work performed by that wall (more specifically, by the perpendicular component of the force of the wall) when the system is compressed. The third term dD is the energy dissipation in the system on top of the steady state dissipation.

Because the pressure in a steady state is spatially uniform, the work from Eq. (22) for slow transitions between steady states reduces as follows,  $dW \approx -p \int_{t_i}^{t_f} dt \int_{V(t)} d^3r \nabla \cdot \mathbf{v}$ . The integrals of the divergence with the Gauss theorem reduce to the change of the volume, and the work reduces to the volumetric work that also appears in equilibrium thermodynamics,

$$dW = -pdV.$$

To determine the exchange of the kinetic energy, we proceed along the same line as for the internal energy above. Thus we use the kinetic energy balance equation [24],

$$\partial_t \frac{1}{2} \rho \mathbf{v}^2 = -\nabla \cdot \left( \frac{1}{2} \rho \mathbf{v}^2 \mathbf{v} + P \cdot \mathbf{v} \right) + P : [\nabla \mathbf{v}], \quad (24)$$

where the pressure tensor P in the system is given by

$$P_{ij} = p\delta_{ij} + \Pi_{ij},$$
$$\Pi = -2\eta [\mathring{\nabla \mathbf{v}}]^{s}.$$

Analysis of the change of the kinetic energy  $dE_k = E_k(t_f) - E_k(t_i) = \int_{t_i}^{t_f} dt \, \frac{dE_k(t)}{dt}$  leads to the conclusion that during the transition between steady states, the kinetic energy changes according to the following equation,

<span id="page-3-0"></span>
$$dE_k = dW_w - dD, (25)$$

where

$$dW_{w} = \int_{t_{i}}^{t_{f}} dt \int_{\partial V(t)} d^{2}r \,\hat{n} \cdot (\Pi \cdot \mathbf{v} - \Pi_{st}(t) \cdot \mathbf{v}_{st}(t))$$

According to the above equations, the kinetic energy may change in two ways.  $dW_w$  is the work performed by the upper wall on top of the steady work performed to keep the shearing steady state. It may be called the excess shear work of the wall. This effect has been recently discussed by Baranyai [12].

The differential of the total energy,  $E = U + E_k$  follows from Eqs. (20) and (25) and is given by,

<span id="page-3-5"></span>
$$dE = dQ - pdV + dW_w. (26)$$

The total energy changes as a result of the excess heat dQ, volumetric work -pdV, and the excess shear work

 $dW_w$ . Contrary to the energy balance equations (20) and (25), there is no excess dissipation dD defined by Eq. (23) in the above total energy balance equation. It follows that the excess dissipation dD describes an internal transfer of internal and kinetic energy. During the steady state transition, part of the kinetic energy changes to internal energy through the kinetic energy dissipation that occurs on top of the steady state dissipation.

### VI. NONEQUILIBRIUM ENTROPY

By introducing

$$dP \equiv dQ + dD \tag{27}$$

we obtain the internal energy balance (20) in the following form,

<span id="page-3-1"></span>
$$dU = dP - pdV. (28)$$

The above formula holds in the space of the control parameters, which are temperature T, the volume of the system V, and the speed of the moving wall  $V_w$ . We do not change the number of particles N. The above formula has the same form as the internal energy of ideal gas without the macroscopic kinetic energy but with volumetric heating [15, 16]. Because the pressure in a shear flow system is constant, Eq. (5), and due to the ideal gas mechanical equation of state, Eq. (14), we obtain,

<span id="page-3-2"></span>
$$p = \frac{2}{3} \frac{U}{V}. (29)$$

We notice the following two facts. First, the internal energy balance in the transition between steady states given by Eq. (28) is very similar to the equilibrium thermodynamics expression  $dU_{eq} = dQ_{eq} - pdV$ . We see that the differential dP plays the role of the heat differential in equilibrium thermodynamics. Second, the expression for pressure (29) is also the equilibrium ideal gas pressure mechanical equation,  $p = 2U_{eq}/3V$ . The above two similarities between steady state and the equilibrium thermodynamic differentials suggest that there exists the integrating factor for dP differential,

<span id="page-3-3"></span>
$$dP = T^* dS^*, (30)$$

where nonequilibrium (effective) entropy is given by the following fundamental equation for the internal energy,

<span id="page-3-4"></span>
$$S^* (U, V) = Nk_B \log \left[ \frac{V}{N} \left( \frac{U}{N} \right)^{3/2} \right] + Ns_0, \qquad (31)$$

while the nonequilibrium temperature

$$T^* = \frac{\partial U\left(S^*, V\right)}{\partial S^*}. (32)$$

The pressure is determined by  $p = -\partial U(S^*, V)/\partial V$ . Whether the differential dP has integrating factor

(is exact) can also be shown directly by proving that the differential  $dP = dU/T^*(U, V, V_w) + p(U, V, V_w)/T^*(U, V, V_w) dV + 0 \cdot dV_w$  has equal derivatives,  $\partial (1/T^*)/\partial V = \partial (p/T^*)/\partial U$  and that the differential does not explicitly depend on  $V_w$  [25].

#### VII. SYSTEM WITH INTERNAL WALL

Now we focus on the system with the internal wall shown in Fig. 1. The wall splits the system into two parts, upper 1 and lower 2. In a steady state, the velocity field in the system is the shear flow given by Eq. (6). Therefore the velocity of the internal wall is  $V_w^s = V_w z_w / L$ , where  $z_w$  is the position of this wall. The wall is adiabatically insulating, which changes one of the boundary conditions. There is no heat flow through the wall. Without the wall the temperature profile would be given by the symmetric parabola, Eq. (11), but the insertion of the adiabatic wall in the middle of the system leads to the situation with half of the parabolic profile. Using this observation, we conclude that from the perspective of the heat flow equation, we can use the solution without the internal wall to determine the energy of subsystem 2 as follows,  $U_2(T, A, L_2, V_{w,2}^u) = U(T, A, 2L_2, 2V_{w,2}^u)/2$ , where  $V_{w,2}^u$  is the speed of the upper wall in subsystem 2 and  $L_2$  is the vertical length of the subsystem. Because the change to the moving reference frame does not change the internal energy, we can deduce the internal energy of the upper system in a similar manner. The internal energy in both subsystems is given by,

$$\begin{split} &U_{i}\left(T,A,L_{i},V_{w,i}^{u}-V_{w,i}^{l}\right)\\ &=\frac{1}{2}U\left(T,A,2L_{i},2\left(V_{w,i}^{u}-V_{w,i}^{l}\right)\right) \text{ for } i=1,2, \end{split}$$

where  $V_{w,i}^u$  is the speed of the upper wall in subsystem i, and  $V_{w,i}^l$  is the speed of the lower wall in subsystem i. We have  $V_{w,2}^l = 0$  and  $V_{w,2}^u = V_{w,1}^l$ .

Using the properties of the equations of state for ideal gas we can show that the differentials

<span id="page-4-0"></span>
$$dP_i \equiv dU_i^{int} + p_i dV_i \text{ for } i = 1, 2, \tag{33}$$

have integrating factors in agreement with Eq. (30),

$$dP_i = T_i^* dS_i^* \text{ for } i = 1, 2.$$
 (34)

On the other hand, the analysis of the energy balance similar to the one presented in the previous section leads to the conclusion that  $dP_{1/2} = dQ_{1/2} + dD_{1/2}$  is the sum of excess heat and excess dissipation in each subsystem. The differentials  $dQ_{1/2}$  and  $dD_{1/2}$  are determined by a direct application of formulas (21) and (23) with the replacement of the volume of integration with the volume for a particular subsystem.

Until now, we have discussed the energy balance independently for each subsystem. But it is particularly interesting to consider a perpendicular motion of the internal wall. As follows from the dynamics, the normal component of the pressure tensor on the wall in a steady state comes solely from hydrostatic pressure. The wall may move vertically only due to the pressure difference,  $p_1 \neq p_2$ . It's natural position is where these pressures are balanced. Therefore the knowledge of the effective entropy  $S^*$  and volume for each subsystem is sufficient to determine the force acting on the wall. The wall's horizontal velocity enters the problem indirectly. The shear velocity plays the role of energy dissipation. The speed of the wall appears in the energy balance equation (9) in the source term. It thus plays the role of volumetric heating,  $\lambda \equiv \eta \left( V_w / L \right)^2$ .

The ideal gas with volumetric heating and an internal wall has already been considered previously [15]. Such a system exhibits continuous nonequilibrium phase transition. Similarly, the system with macroscopic kinetic energy shown in Fig. 1 will exhibit the phase transition as well for the following reason. Let's focus on the position of the internal wall  $z_w$  and upper wall velocity,  $V_{w,2}^u$ , keeping the external walls temperature T, the total volume of the system,  $L_1 + L_2 = L$ , and other parameters constant. Number of particles in both subsystems is equal,  $N_1 = N_2$ . Because the hydrostatic pressure gives the sole force normal to the walls, the motion of the internal wall can be determined by the fundamental relations (31) for each subsystem. The pressure follows from  $p_i = p_i(U_i, V_i, N_i)$ . Moreover, the internal energy in steady state is determined by Eq. (15). The equivalence is explicit after comparing Eq. (15) to the expression (5) from the reference [15]. This reasoning leads to the conclusion that from the perspective of the position of the internal wall, the steady state behavior of both subsystems is the same. The speed of the upper wall for the system with kinetic energy must be related to the volumetric heating  $\lambda$  from [15] by  $\lambda \equiv \eta (V_w/L)^2$ .

Because there is one-to-one correspondence, we conclude that once the upper wall's speed increases, the shear flow volumetrically heats the system. For the value,  $\lambda L^2/4\kappa T \approx 4.55344$ , equivalently  $\eta V_w^2/4\kappa T_0 \approx 4.55344$ , the central position of the wall ceases to be stable. Above the critical speed, the wall spontaneously chooses one of the two stable positions and moves away from the center.

As we show below, it is possible to introduce an extremum principle that determines the spontaneous position of the internal wall. Let's consider an additional external force  $F_w$  perpendicular to the wall. In a steady state it is determined by the pressure difference,  $F_{ext} = -A(p_2 - p_1)$ . The force performs work on the system,  $dW_{ext} = -A(p_2 - p_1) dz_w$ . Because the spontaneous direction of the wall is toward the equilibration of pressures, the system reaches "equilibrium" for the position of the wall x, for which the work done by the external force is negative,

<span id="page-4-1"></span>
$$dW_{ext} < 0. (35)$$

The above phenomenological fact we use to construct the

thermodynamic-like extremum principle. When the upper wall does not move vertically, the work of the external force is related to the volumetric work in both subsystems,

<span id="page-5-4"></span>
$$dW_{ext} = -p_1 dV_1 - p_2 dV_2. (36)$$

This equation, by utilizing the internal energy balance given by Eqs. (33) and the nonequilibrium entropy, is expressed as follows,

$$dW_{ext} = dU_1 - T_1^* dS_1^* + dU_2 - T_2^* dS_2^*.$$
 (37)

Equivalently, it is given by

<span id="page-5-0"></span>
$$dW_{ext} = dU_{12} - dP_{12}, (38)$$

where

$$dU_{12} = dU_1 + dU_2 (39)$$

and

<span id="page-5-1"></span>
$$dP_{12} = dP_1 + dP_2. (40)$$

Eq. (38) puts us in the same position as in equilibrium thermodynamics: if  $dP_{12}$  has an integrating factor and the corresponding potential,  $dP_{12} = T_{12}^* dS_{12}^*$ , then the condition of minimal work (35) by means of expression (38) follows the condition of the minimum of the energy for 'adiabatically insulated' system defined by  $S_{12}^* = const$  surface. This surface is considered in the space of  $T_0, V_1, V_2, V_w$ , because we keep the number of particles,  $N_1, N_2$ , and other parameters constant. Let's notice that expressions (35-40) for the case of no shear flow (no heating),  $V_w = 0$ , reduces to the problem of finding the position of the wall that separates two homogeneous ideal gases. Thus, in equilibrium thermodynamics, dP, becomes the role the heat differential. The nonequilibrium situation has been discussed earlier [16] and it suggests the minimum principle as follows.

The position of the wall is determined by the minimum of total internal energy,  $U_{12}$ , as a function of parameters of states  $S_1^*, V_1, S_2^*, V_2$ , for the constraint

<span id="page-5-2"></span>
$$S_{12}^* = S_1^* + rS_2^*. (41)$$

The latter condition denotes steady 'adiabatic insulation'. In this principle there appears parameter r. Let's apply the above principle to verify whether it gives a proper position of the wall and to find the meaning of r parameter. We apply the above principle with the constraint of total volume of the system fixed,

<span id="page-5-3"></span>
$$V = V_1 + V_2. (42)$$

The total energy is given by

$$U(S_1^*, V_1, S_2^*, V_2) = U(S_1^*, V_1) + U(S_2^*, V_2),$$
(43)

where  $U\left(S_{1}^{*},V_{1}\right)$  follows from the fundamental relation (31). Minimization of the above energy with constraints (41) and (42) allows us to use  $S_{1}^{*}$  and  $V_{1}$  as two independent parameters and minimize the function  $U\left(S_{1}^{*},V_{1}\right)+U\left(\left(S_{12}^{*}-S_{1}^{*}\right)/r,V-V_{1}\right)$ . Its first derivatives lead to the following necessary conditions for the minimum of the function,

$$T_1^* - \frac{1}{r}T_2^* = 0,$$
 (44)  
 $p_1 - p_2 = 0.$ 

It proves that the necessary condition for the minimum in the presented extremum principle leads to equality of pressures. The first of the above equations gives the interpretation of r parameter. It is the nonequilibrium temperature ratio. Notice that when r=1, the entropy becomes additive (Eq. (41)) and the minimum principle reduces directly to the equilibrium minimum principle.

In the above reasoning the minimum principle follows from the fact, that the internal energy balance is determined by  $dU_i = dP_i - p_i dV_i$  with homogeneous pressure that is solely determined by the internal energy and volume,  $p_i = p_i (U_i, V_i)$ . Both assumptions also hold when transport coefficients depend on parameters of states [17]. In particular, if the viscosity or heat conductivity depends on density or temperature. For this reason, the derived minimum energy principle is also valid beyond the regime of Onsager's linear response theory [24].

It is also worth noting that the inequality (35) which determines the direction of spontaneous motion of the wall, with the use of Eq. (36) and Eq. (26) applied to each subsystem is expressed by

$$dW_{ext} = dE_{12} - dQ_{12} - dW_{w12},$$

with energy differential,  $dE_{12} = dE_1 + dE_2$ , excess heat  $dQ_{12} = dQ_1 + dQ_2$  and excess work performed by wall,  $dW_{w12} = dW_{w1} + dW_{w2}$ . The above formula suggests an approach to identify the quantity that is minimized in the system by subtraction from total energy all other terms (apart from work related to the change of the constraint) that are present in the energy balance equation (here, excess work performed by the wall and heat) which describe the ways the system exchanges energy with the environment. Such a way could lead to a mnemotechnic rule to identify the physical quantity to generalize the second law in other situations than considered in this paper (e.g., with the exchange of particles).

### VIII. SUMMARY

In this article, we investigate whether there is a description similar to equilibrium thermodynamics for out-of-equilibrium steady states. We consider this problem in the context of the Couette flow, where there is a mass current (velocity field), energy dissipation, and a continuous flow of heat. Each feature independently excludes the theory of equilibrium thermodynamics and its tools.

Since, in general, it is still unclear that such a simple, equilibrium thermodynamic-like description of nonequilibrium steady states is possible, we have chosen the most straightforward possible system, which we believe includes the coupling of mass flow and heat current, i.e., an ideal gas in shear flow. We show that nonequilibrium entropy exists, which describes how the system gains energy through excess heat or dissipation. In addition, the nonequilibrium entropy allows us to construct the principle of minimum energy, which leads to the proper state of the system after removing the constraint, which is the force acting on the wall in the system. It proves the existence of a description of a system with an out-ofequilibrium heat and mass flow, which practically takes the form of equilibrium thermodynamics and reduces to the principle of minimum energy in equilibrium thermodynamics when the shear flow disappears.

The thermodynamic-like description introduced in this paper leads to further questions inspired by equilibrium thermodynamics. Particularly interesting are the procedures for measuring non-equilibrium state parameters, effective temperature and entropy, and measuring excess heat, dissipation, and work the wall performs. It is worth noting that the obtained result goes along the line of recent experiments of Yamamoto et al., who extended calorimetry for the measurements of the excess heat of sheared fluids [\[26\]](#page-7-7). Another issue is the possibility of developing the description of interacting systems, where the fundamental relationship for van der Waals gas with heat flow can be introduced. It is also interesting to ask about Maxwell's identities, which in equilibrium thermodynamics appear very practical. Finally, it is fascinating to check whether such a description exists for other systems with coupled heat flow and mass current in the atmosphere and the chemical industry.

### ACKNOWLEDGEMENT

P.J.Z. would like to acknowledge the support of a project that has received funding from the European Union's Horizon 2020 research and innovation program under the Marie Skłodowska-Curie grant agreement No. 847413 and was a part of an international co-financed project founded from the program of the Minister of Science and Higher Education entitled "PMW" in the years 2020–2024; agreement No. 5005/H2020-MSCA-COFUND/2019/2.

- <span id="page-6-0"></span>[1] John Ross, Katharine LC Hunt, and Paul M Hunt. Thermodynamics far from equilibrium: Reactions with multiple stationary states. The Journal of chemical physics, 88(4):2719–2729, 1988.
- [2] Paul M Hunt, Katharine LC Hunt, and John Ross. Thermodynamic and stochastic theory for nonequilibrium systems with more than one reactive intermediate: Nonautocatalytic or equilibrating systems. The Journal of chemical physics, 92(4):2572–2581, 1990.
- <span id="page-6-1"></span>[3] John Ross, Katharine LC Hunt, and Paul M Hunt. Thermodynamic and stochastic theory for nonequilibrium systems with multiple reactive intermediates: The concept and role of excess work. The Journal of chemical physics, 96(1):618–629, 1992.
- <span id="page-6-2"></span>[4] Herbert B Callen. Thermodynamics and an Introduction to Thermostatistics. John Wiley & Sons, 2006.
- <span id="page-6-3"></span>[5] Denis J Evans and HJM Hanley. A thermodynamics of steady homogeneous shear flow. Physics Letters A, 80(2- 3):175–177, 1980.
- [6] HJM Hanley and Denis J Evans. A thermodynamics for a system under shear. The Journal of Chemical Physics, 76(6):3225–3232, 1982.
- [7] Denis J Evans. Computer "experiment" for nonlinear thermodynamics of couette flow. The Journal of Chemical Physics, 78(6):3297–3302, 1983.
- <span id="page-6-4"></span>[8] Denis J Evans. Rheology and thermodynamics from nonequilibrium molecular dynamics. International Journal of Thermophysics, 7:573–584, 1986.
- <span id="page-6-5"></span>[9] PJ Daivis and ML Matin. Steady-state thermodynamics of shearing linear viscoelastic fluids. The Journal of chemical physics, 118(24):11111–11119, 2003.

- [10] Tooru Taniguchi and Gary P Morriss. Steady shear flow thermodynamics based on a canonical distribution approach. Physical Review E, 70(5):056124, 2004.
- [11] Peter J Daivis. Thermodynamic relationships for shearing linear viscoelastic fluids. Journal of non-newtonian fluid mechanics, 152(1-3):120–128, 2008.
- <span id="page-6-6"></span>[12] András Baranyai. Thermodynamic integration for the determination of nonequilibrium entropy. Journal of Molecular Liquids, 266:472–477, 2018.
- <span id="page-6-7"></span>[13] Naoko Nakagawa and Shin-ichi Sasa. Global thermodynamics for heat conduction systems. Journal of Statistical Physics, 177(5):825–888, 2019.
- <span id="page-6-10"></span>[14] Naoko Nakagawa and Shin-ichi Sasa. Unique extension of the maximum entropy principle to phase coexistence in heat conduction. Physical Review Research, 4(3):033155, 2022.
- <span id="page-6-12"></span>[15] Yirui Zhang, Marek Litniewski, Karol Makuch, Paweł J. Żuk, Anna Maciołek, and Robert Hołyst. Continuous nonequilibrium transition driven by heat flow. Phys. Rev. E, 104:024102, Aug 2021.
- <span id="page-6-11"></span>[16] Robert Hołyst, Karol Makuch, Anna Maciołek, and Paweł J Żuk. Thermodynamics of stationary states of the ideal gas in a heat flow. The Journal of Chemical Physics, 157(19):194108, 2022.
- <span id="page-6-8"></span>[17] Robert Holyst, Karol Makuch, Anna Maciolek, Konrad Gizynski, and Pawel J Zuk. Steady thermodynamic fundamental relation for the interacting system in a heat flow. [arXiv:2301.12732](http://arxiv.org/abs/2301.12732), 2023.
- <span id="page-6-9"></span>[18] Yoshitsugu Oono and Marco Paniconi. Steady state thermodynamics. Progress of Theoretical Physics Supplement, 130:29–44, 1998.

- <span id="page-7-0"></span>[19] Shin-ichi Sasa and Hal Tasaki. Steady state thermodynamics. Journal of statistical physics, 125(1):125–224, 2006.
- <span id="page-7-1"></span>[20] Udo Seifert. Stochastic thermodynamics, fluctuation theorems and molecular machines. Reports on progress in physics, 75(12):126001, 2012.
- <span id="page-7-2"></span>[21] Mingnan Ding, Fei Liu, and Xiangjun Xing. Unified theory of thermodynamics and stochastic thermodynamics for nonlinear langevin systems driven by non-conservative forces. Physical Review Research, 4(4):043125, 2022.
- <span id="page-7-3"></span>[22] Thomas Speck. Modeling of biomolecular machines in non-equilibrium steady states. The Journal of Chemical Physics, 155(23):230901, 2021.
- <span id="page-7-4"></span>[23] Eberhard Bodenschatz, Werner Pesch, and Guenter Ahlers. Recent developments in rayleigh-bénard convection. Annual review of fluid mechanics, 32(1):709–778, 2000.
- <span id="page-7-5"></span>[24] Sybren Ruurds De Groot and Peter Mazur. Nonequilibrium thermodynamics. Courier Corporation, 2013.
- <span id="page-7-6"></span>[25] Michael Spivak. Calculus on manifolds: a modern approach to classical theorems of advanced calculus. CRC press, 2018.
- <span id="page-7-7"></span>[26] Taro Yamamoto, Yuki Nagae, Tomonari Wakabayashi, Tadashi Kamiyama, and Hal Suzuki. Calorimetry of phase transitions in liquid crystal 8cb under shear flow. Soft Matter, 19(8):1492–1498, 2023.