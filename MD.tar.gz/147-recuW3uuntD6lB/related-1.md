# Stochastic thermodynamics: From principles to the cost of precision

## Udo Seifert

*II. Institut f ¨ur Theoretische Physik, Universit ¨at Stuttgart, 70550 Stuttgart, Germany*

## Abstract

In these lecture notes, the basic principles of stochastic thermodynamics are developed starting with a closed system in contact with a heat bath. A trajectory undergoes Markovian transitions between observable meso-states that correspond to a coarse-grained description of, e.g., a biomolecule or a biochemical network. By separating the closed system into a core system and into reservoirs for ligands and reactants that bind to, and react with the core system, a description as an open system controlled by chemical potentials and possibly an external force is achieved. Entropy production and further thermodynamic quantities defined along a trajectory obey various fluctuation theorems. For describing fluctuations in a non-equilibrium steady state in the long-time limit, the concept of a rate function for large deviations from the mean behaviour is derived from the weight of a trajectory. Universal bounds on this rate function follow which prove and generalize the thermodynamic uncertainty relation that quantifies the inevitable trade-off between cost and precision of any biomolecular process. Specific illustrations are given for molecular motors, Brownian clocks and enzymatic networks that show how these tools can be used for thermodynamic inference of hidden properties of a system.

*Keywords:*

# 1. Introductory remarks

Over the last about ten to twenty years, stochastic thermodynamics has emerged as a comprehensive framework for describing small driven systems in contact with (or embedded in) a heat bath like colloidal particles in laser traps or biomolecules and biomolecular networks. As an essential concept, the notions of classical thermodynamics like work, heat and entropy production are identified on the level of fluctuating trajectories. The distributions of these quantities obey various universal exact fluctuation relations.

In the first part of these lecture notes, these concepts will be developed for a driven system obeying a Markovian dynamics on a discrete set of states which implicitly also contains the case of overdamped motion on a continuous state space usually described by Langevin equations. Since this part is well established by now, only a few selected references to the original key papers will be given. A more comprehensive guide to the vast literature concerning refinements and theoretical and experimental case studies, can be found, inter alia, in several recent reviews [1, 2, 3, 4].

The second part deals with a more recent development concerning the fluctuations in non-equilibrium steady states for which a family of inequalities were found among which the most prominent one constrains the mean and variance of currents in terms of the overall entropy production. This universal relation can also be expressed as the inevitable trade-off between cost and precision of any thermodynamically consistent process which has been dubbed the thermodynamic uncertainty relation. Its proof follows from a universal bound on the large deviations of any current. Stronger bounds on these fluctuations follow with somewhat more knowledge about the driving forces and the topology of the underlying network. With these relations, measured fluctuations allow to infer otherwise hidden properties of these systems. This presentation is not intended to be an exhaustive review of these recent (and ongoing) developments but rather a pedagogical introduction to them.

*Email address:* useifert@theo2.physik.uni-stuttgart.de ( Udo Seifert )

#### 2. Closed system in contact with a heat bath

#### 2.1. Meso-states

Starting on a very general level, we consider a closed system with micro-states  $\{\xi\}$  and energy  $H(\xi)$  in contact with a heat bath at inverse temperature  $\beta$ . In equilibrium, free energy, internal energy and entropy are given by

$$F = -(1/\beta) \ln \sum_{\xi} \exp[-\beta H(\xi)], \quad E = \partial_{\beta}(\beta F), \quad S = \beta^2 \partial_{\beta} F = \beta (E - F), \tag{1}$$

respectively.

We then partition the total phase space into a set of observable meso-states  $\{I\}$ . Each micro-state  $\xi$  is assumed to belong to one and only one meso-state I to which many micro-states  $\xi \in I$  contribute. In equilibrium (superscript<sup>e</sup>), the probability to find the system in meso-state I is then given by

$$P_I^e = \sum_{\xi \in I} \exp[-\beta(H(\xi) - F)] \equiv \exp[-\beta(F_I - F)]$$
 (2)

where the last equality defines the free energy  $F_I$  of the state I. This identification is justified, first, since the mean energy in state I can be expressed as

$$E_I = \sum_{\xi \in I} P(\xi | I) H(\xi) = \partial_{\beta}(\beta F_I), \tag{3}$$

where

$$P(\xi|I) = \exp[-\beta(H(\xi) - F)]/P_I^e = \exp[-\beta(H(\xi) - F_I)]$$
(4)

is the conditional probability for the micro-state  $\xi$  given the meso-state I. Second, defining an "intrinsic" entropy  $S_I$  from  $F_I$  as in (1) leads to

$$S_I \equiv \beta^2 \partial_{\beta} F_I = \beta (E_I - F_I) = -\sum_{\xi \in I} P(\xi | I) \ln P(\xi | I) \equiv S[P(\xi | I)], \tag{5}$$

which is the Shannon entropy of the conditional probability.<sup>1</sup> With these expressions, in equilibrium, mean energy, entropy and free energy of the system can also be written as

$$E = \sum_{I} P_{I}^{e} E_{I}, \quad S = \left\{ \sum_{I} P_{I}^{e} S_{I} \right\} + S[P_{I}^{e}], \quad F = \left\{ \sum_{I} P_{I}^{e} F_{I} \right\} - (1/\beta) S[P_{I}^{e}], \tag{6}$$

respectively.

# 2.2. Trajectory, time-scale separation, transition rates and master equation

In the course of time, the system moves along a trajectory I(t) of meso-states. While in principle any partition into meso-states is formally possible, such a separation makes physical sense, and will lead to stochastic thermodynamics, if transitions between meso-states are slow while transitions between the micro-states belonging to one meso-state are fast. As a necessary condition, obviously, the heat bath has to relax at least as fast. Ideally, the dynamics along such a trajectory then becomes Markovian, which means that there is a (constant) transition rate  $K_{IJ}$  for the system in state I to jump to state J independent of how long the system has already been in state I and how it got there. Under this assumption, the probability to observe the system at time t in state I follows the master equation

$$\partial_t P_I(t) = \sum_J [P_J(t)K_{JI} - P_I(t)K_{IJ}]. \tag{7}$$

<sup>&</sup>lt;sup>1</sup>Throughout this presentation, entropy is dimensionless, i.e., Boltzmann's constant is set to 1, and  $S[p_i] \equiv -\sum_i p_i \ln p_i$  denotes the Shannon entropy of an arbitrary discrete probability distribution.

The transition rates  $\{K_{IJ}\}$  are not arbitrary but have to fulfill certain conditions. First, under this dynamics, the equilibrium distribution (2) should remain invariant. Second, in equilibrium, there should be no net flow across any link (IJ) which means that in a long trajectory the number of transitions between I and J should be the same as the number of those between J and I. These two conditions imply that

$$K_{IJ}/K_{JI} = P_I^e/P_I^e = \exp[-\beta(F_J - F_I)] = \exp(-\beta\Delta_{IJ}F) = \exp(-\beta\Delta_{IJ}E + \Delta_{IJ}S)$$
(8)

where we use the notation  $\Delta_{IJ}A \equiv A_J - A_I$  throughout for any function defined on meso-states. This constraint does not fully specify the dynamics. In order to determine the rates beyond this constraint on their ratio, one would need a more specific model. It turns out, however, that a number of general results can be derived that are independent of such non-universal choices.

Crucially, under the assumption of fast equilibration within a meso-state, the dynamics (7) can be used not only in genuine equilibrium but also in situations where the system has initially been prepared in one meso-state, or, more generally, in an initial condition  $\{P_I^0\}$  since the future evolution from state I is independent of whether that state has been prepared initially or has been visited in the course of an equilibrium trajectory. If the set of meso-states is connected, i.e., does not split into two subsets among which there is no link, the Perron-Frobenius theorem guarantees that any initial distribution will approach the unique equilibrium distribution,  $P_I(t) \to P_I^e$  as  $t \to \infty$  for all I [5].

# 2.3. Thermodynamics along a trajectory and in the ensemble

Along a trajectory I(t), the internal energy of the system becomes a stochastic quantity,  $E(t) = E_{I(t)}$ . Since the system is closed, any energy change of the system is compensated by a corresponding change in the energy of the heat bath, which can be interpreted as a perpetual exchange of heat along an individual trajectory as introduced by Sekimoto [6]. Quantitatively, for a transition from I to J, this first law reads

$$\Delta_{IJ}E \equiv E_J - E_I = -Q_{IJ}. \tag{9}$$

Here,  $Q_{IJ} > 0$  corresponds to heat dissipated in the bath thus increasing its entropy by  $\beta Q_{IJ}$ . Moreover, the system carries entropy

$$S^{\text{sys}}(t) \equiv S_{I(t)} - \ln[P_{I(t)}(t)]. \tag{10}$$

The first part is the intrinsic entropy defined in (5) above whereas the second is the "stochastic entropy" [7] that can change even while the system remains in the same meso-state. Consequently, a transition from I to J at time t entails the total entropy change

$$\Delta_{IJ}S^{\text{tot}}(t) = \beta Q_{IJ} + \Delta_{IJ}S^{\text{sys}}(t) = \beta Q_{IJ} + S_J - S_I + \ln[P_I(t)/P_J(t)] = \ln[P_I(t)K_{IJ}/P_J(t)K_{JI}]$$
(11)

where we have used (8) and (9).

This particular identification of a trajectory dependent total entropy change gains further justification through the following implications and observations. First, in equilibrium, the entropy is constant along any trajectory since the various contributions in (11) add up to zero for each transition. This would not be the case if we had not included the term called stochastic entropy. Second, on the ensemble level, the probability for a transition from I to J at time t is  $P_I(t)K_{IJ}$ . Consequently, the mean rate of entropy production at time t becomes

$$\langle \dot{S}^{\text{tot}}(t) \rangle = \sum_{IJ} P_I(t) K_{IJ} \Delta_{IJ} S^{\text{tot}}(t) = \sum_{I < I} [P_I(t) K_{IJ} - P_J(t) K_{JI}] \ln[P_I(t) K_{IJ} / P_J(t) K_{JI}]$$
(12)

as introduced by Schnakenberg [8]. Here and throughout, the notation I < J means that each link (IJ) is counted only once. Since  $(x - y) \ln(x/y) \ge 0$  for all non-negative (x, y), we immediately get the second law

$$\langle \dot{S}^{\text{tot}}(t) \rangle \ge 0,$$
 (13)

independently of the initial condition at any time during the evolution. Note that without the term called above stochastic entropy, it is easy to conceive a case for which the mean contribution from heat and intrinsic entropy becomes negative.

Third, as a refinement of the second law (13), using the path weight and the concept of "time-reversal" introduced below in Sect. 4, one can easily prove the integral fluctuation theorem for total entropy production [7]

$$\langle \exp[-\Delta S^{\text{tot}}] \rangle = 1,$$
 (14)

where the exponent corresponds to the total entropy change along a trajectory of arbitrary but fixed length  $\mathcal{T}$  and the average is over the ensemble that evolves from an arbitrary initial condition  $\{P_I^0\}$ .

Fourth, this identification of entropy along a trajectory can be motivated from "time-reversal" by refining an argument indicated at in [9]. Suppose we postulate the following conditions for the entropy change along a trajectory associated with a transition  $I \to J$  at time t: (i) The contribution  $\Delta S_{IJ}^{\text{tot}}$  from this jump is the negative of a putative contribution of the reversed jump taking place at the same time,  $\Delta S_{IJ}^{\text{tot}}(t) = -\Delta S_{IJ}^{\text{tot}}(t)$ . (ii) The mean rate of total entropy production is non-negative at any time t for any initial distribution  $\{P_I^0\}$ . It is then straightforward to show that  $\Delta_{IJ}S^{\text{tot}}(t)$  should be of the form  $g(\ln[P_I(t)K_{IJ}]/P_J(t)K_{JI}])$  with g(y) = -g(-y). If one imposes additionally that along a trajectory the total entropy production is additive in system and bath, with the latter given by  $\beta Q_{IJ}$ , g(y) must be linear leading to (11) up to a multiplicative constant.

## 2.4. Time-dependently driven system

The framework discussed above can easily be adapted to the situation where one assumes that the system is driven externally leading to a time-dependence of the microscopic Hamiltonian as  $H(\xi, \lambda)$  where  $\lambda(t)$  is a time-dependent control parameter [10, 11, 12]. This time-dependence should be slow enough so that the micro-states within each meso-state can still equilibrate. As a first consequence, free energy, internal energy and entropy of the meso-states as defined in (1) above (here with  $H(\xi) \to H(\xi, \lambda)$ ) become time-dependent,  $F_I(\lambda)$ ,  $E_I(\lambda)$ ,  $S_I(\lambda)$ . Second, thermodynamic consistency now requires that the ratio of the transition rates (8) becomes time-dependent and is given by

$$K_{II}(\lambda)/K_{II}(\lambda) = \exp[-\beta \Delta_{II} F(\lambda)]$$
 (15)

with  $\lambda = \lambda(t)$ .

In such a setting, along the trajectory I(t) of meso-states the rate of work applied to the system should be identified as

$$\dot{W}(t) = \sum_{\xi \in I(t)} \exp[-\beta (H(\xi, \lambda) - F_I(\lambda))] (\partial H/\partial \lambda) \dot{\lambda} = \partial_{\lambda} F_I(\lambda)_{|I(t)} \dot{\lambda}, \tag{16}$$

which corresponds to the appropriately averaged change of the microscopic Hamiltonian. Here, and throughout along trajectories, the dot denotes a total time-derivative (possibly delta-like due to jumps). Note that this expression differs slightly from earlier identifications of work,  $\partial_{\lambda}E_{I}(\lambda)_{|I(t)}\dot{\lambda}$ , for a stochastic dynamics [11, 12] since we allow the mesostates to have different intrinsic entropy [9, 13].

The first law then allows us to identify the rate of dissipated heat as

$$\dot{Q}(t) \equiv \dot{W}(t) - \dot{E}(t) = \dot{W}(t) - \sum_{I} \dot{\delta}_{JI(t)} E_{J}(\lambda) - \partial_{\lambda} E_{I}(\lambda)_{|I(t)} \dot{\lambda} = -\sum_{I} \dot{\delta}_{JI(t)} F_{J}(\lambda) - \frac{d}{dt} S_{I(t)}(\lambda)/\beta. \tag{17}$$

Since internal energy and intrinsic entropy of a meso-state can become time-dependent, these expressions show that, in contrast to the case without driving, heat is now exchanged even if the system stays in the same meso-state.

The total entropy change along a trajectory becomes

$$\dot{S}^{\text{tot}}(t) = \beta \dot{Q}(t) + \frac{d}{dt} [S_{I(t)}(\lambda) - \ln P_{I(t)}(\lambda)]. \tag{18}$$

The integral fluctuation theorem for entropy production (14) holds for arbitrary driving  $\lambda(t)$  [7] as does, consequently, the second law on the ensemble level.

#### 3. From a closed to an open system

#### 3.1. Transition rates

So far, we have considered a closed system in contact with a heat bath. For systems involving transport (possibly against an external force) and/or chemical reactions, it is advantantageous to split this system further into (i) a core system of interest, (ii) the surrounding solution, which will effectively act as a particle reservoir, and (iii) a part responsible for providing an external mechanical force. The latter two parts will be associated with external driving and, possibly, with the extraction of chemical or mechanical work.

![](_page_4_Picture_3.jpeg)

![](_page_4_Picture_4.jpeg)

![](_page_4_Picture_5.jpeg)

Figure 1: Scheme of a molecular motor powered by the hydrolysis of an ATP shown here as ATP (red)  $\rightarrow$  ADP (orange) + P (yellow) stepping along a filament against a force represented by a weight. From the closed system's perspective, the mesostates I, J, K contain the state of the enzyme  $i_{I,J,K}$ , the total number of molecules of each species, and the position of the motor relative to the fixed track,  $d_{I,J,K}$ . In the open system's perspective of just the motor, one can focus on the states of the motor, here oversimplified as just two different ones  $i_I = i_K$  (tightly bound to the track) and  $i_J$  (with one "head" loose binding to ATP).

As the core system, we consider paradigmatically an enzyme or a molecular motor (or several of them) that induce enzymatic reactions, like the hydrolysis of ATP, between solutes of various species  $\alpha$  in the solution, see Fig. 1. Consequently, to each meso-state I of the full system there corresponds a state of the enzyme(s)  $i_I$  including tightly bound solutes. The mapping from I to  $i_I$  is unique with many meso-states I leading to the same  $i_I$ .

The change in free energy difference of the full system upon a transition from I to J can then be written as

$$\Delta_{IJ}F = F_{i_J} - F_{i_I} - \sum_{\alpha} \mu^{\alpha} \Delta_{IJ} N^{\alpha} + f d_{IJ}. \tag{19}$$

The first term is the free energy difference of the two enzyme configurations. If these two configurations contain a different number of bound solutes,  $\Delta_{IJ}N^{\alpha}\neq 0$ , the second term quantifies the free energy difference of the surrounding solution which we have characterized by a set of chemical potentials  $\{\mu^{\alpha}\}$  that are essentially determined by the respective concentrations of the various species.<sup>2</sup> Likewise, if the transition  $I\to J$  involves the motor stepping a distance  $d_{IJ}\equiv d_J-d_I$  against the external force f, the last term is the corresponding free energy change. We assume that there are no transitions that change the numbers of free solutes without a concomitant change of the enzyme configuration. This means that there are no chemical reactions taking place in the solvent that are not enzymatically induced. We can then replace all reference to the original meso-states IJ by considering the chemical potentials and the force to be given and write  $IJ\to ij$ . The transitions between the internal states of the motor or enzyme (including binding and release of solutes) must then obey the constraints

$$k_{ij}/k_{ji} = \exp[-\beta(\Delta_{ij}F - \sum_{\alpha} \mu^{\alpha} \Delta_{ij} N^{\alpha} + f d_{ij})]. \tag{20}$$

The core system has thus become an open system connected to a heat bath with inverse temperature  $\beta$  and chemostats with chemical potential  $\{\mu^{\alpha}\}$  possibly subject to an external force f. The master equation (7) expressed for the probability of just the core states reads

$$\partial_t p_i(t) = \sum_j [-k_{ij} p_i(t) + k_{ji} p_j(t)]. \tag{21}$$

<sup>&</sup>lt;sup>2</sup>This identification can be made more formal as discussed in [9].

#### 3.2. Thermodynamics along trajectories and in the ensemble

For this open system, the first law (9) along a transition  $i \rightarrow j$  becomes

$$\Delta_{ij}E + \Delta_{ij}E^{\text{sol}} + W_{ii}^{\text{out}} = -Q_{ij}. \tag{22}$$

On the left hand side, the first term is the energy change of the enzyme, the second one the energy change in the surrounding solution, formally the reservoirs, if the two core states contain a different number of bound solutes, and the third term the extracted mechanical work,  $W_{ij}^{\text{out}} \equiv f d_{ij}$  delived against an external force f in a transition  $i \to j$ . These three different contributions to what would be the internal energy in a description as a closed system must be compensated by the dissipated heat since the total energy, including that of the heat reservoir, must be conserved.

The entropy change (10) of the system, now consisting of core system and solution, that is associated with a transition  $i \rightarrow j$ , becomes

$$\Delta_{ij}S^{\text{sys}}(t) \equiv \Delta_{ij}S + \Delta_{ij}S^{\text{sol}} + \ln[p_i(t)/p_j(t)]. \tag{23}$$

The first term contains the change in intrinsic entropy of the enzyme, the second one the entropy change of the surrounding solution, the last one the stochastic entropy of the enzyme. Note that there is no more stochastic entropy associated with the state of the solution since the reservoir is fully characterized by the chemical potentials. Likewise, there is neither intrinsic nor stochastic entropy associated with a putative mechanical work source. With (20), the total entropy change can be written as

$$\Delta_{ij}S^{\text{tot}}(t) = \beta Q_{ij} + \Delta_{ij}S^{\text{sys}}(t) = \beta Q_{ij} + \Delta_{ij}S + \Delta_{ij}S^{\text{sol}} + \ln[p_i(t)/p_j(t)] = \ln[p_i(t)k_{ij}/p_j(t)k_{ij}]. \tag{24}$$

On the ensemble level, the first and second law now become

$$\langle \dot{E}(t) \rangle + \langle \dot{E}^{\text{sol}}(t) \rangle + \langle \dot{W}^{\text{out}}(t) \rangle = -\langle \dot{Q}(t) \rangle$$
 (25)

and

$$\langle \dot{S}^{\text{tot}}(t) \rangle = \sum_{ij} p_i(t) k_{ij} \Delta_{ij} S^{\text{tot}}(t) = \sum_{i < j} [p_i(t) k_{ij} - p_j(t) k_{ji}] \ln[p_i(t) k_{ij} / p_j(t) k_{ji}] \ge 0, \tag{26}$$

respectively. The integral fluctuation theorem (14) for total entropy production holds unmodified.

#### 3.3. Non-equilibrium steady states (NESSs)

The master equation (21) with the thermodynamic consistency condition (20) will typically approach a unique stationary state,  $\{p_i(t)\} \to \{p_i^s\}$  as  $t \to \infty$  independent of the initial distribution  $\{p_i^0\}$  [5]. This stationary distribution can either be calculated as the right eigenvector to the eigenvalue 0 of the corresponding matrix or obtained from a nice graphical construction explained, e.g., in [14], which works particularly well for small networks.

In this non-equilibrium steady state, there will be net currents across some links,

$$j_{ij}^{s} = p_{i}^{s} k_{ij} - p_{i}^{s} k_{ji} \neq 0, (27)$$

which distinguishes such a NESS fundamentally from genuine equilibrium. In a NESS, the mean rate of entropy production (26) (denoted by  $\sigma$  from now on) is constant and given by

$$\sigma = \sum_{i < j} [p_i^s k_{ij} - p_j^s k_{ji}] \ln[p_i^s k_{ij} / p_j^s k_{ji}] \ge 0.$$
 (28)

## 3.4. Remark on strong coupling and fixed pressure

So far, we have implicitly assumed that the coupling between the system and the heat bath is weak. As shown in [15], a thermodynamically consistent identification of trajectory dependent internal energy and entropy is, however, possible even without this assumption, which, for biomolecular systems, will not necessarily hold. Likewise, for biochemical systems, the assumption that the system (including the particle reservoirs) has a fixed volume should typically be replaced by assuming a fixed pressure  $\mathcal{P}$ . However, all definitions and identifications on the trajectory

level from the above sections remain valid, provided free energies differences  $F_j - F_i$  are replaced by Gibbs free energy differences  $G_j - G_i = F_j - F_i + \mathcal{P}(V_j - V_i)$ . The exception is the first law (22), which now reads

$$E_i - E_i + \Delta_{ij} E^{\text{sol}} + \mathcal{P}(V_i - V_i) + W_{ii}^{\text{out}} = -Q_{ij}, \tag{29}$$

with the concomitant identification of heat. In order not to overburden the presentation, we stick to the weak coupling and constant volume case in the following and refer to [16] for an instructive discussion of the latter and related aspects.

## 4. "Time-reversal", entropy production, and fluctuation relations

For this section, we first return to a general open system characterized by a set of states  $\{i\}$  with time-independent transition rates (20).

# 4.1. Path weight for a trajectory

The probability  $p[i(t)|i_0]$  to observe a trajectory i(t) starting at time t = 0 in  $i(0) = i_0$  and jumping at times  $t_j$  from  $i_j^-$  to  $i_j^+$  ending up after J jumps at time  $t = \mathcal{T}$  in  $i(t) = i_{\mathcal{T}}$  is given by<sup>3</sup>

$$p[i(t)|i_0] = \left\{ \prod_{j=1}^{J} \exp[-r_{i_j^-}(t_j - t_{j-1})] k_{i_j^- i_j^+} \right\} \exp[-r_{i_{\mathcal{T}}}(\mathcal{T} - t_J)] = \exp\left[-\sum_i r_i \tau_i\right] \prod_{ij} k_{ij}^{n_{ij}}$$
(30)

where the last product runs over all links (in both directions). Here,

$$r_i \equiv \sum_i k_{ij} \tag{31}$$

is the escape rate of state i. For J=0, i.e., the trajectory without any jump, the term in curly brackets should be set to 1 and, in the remainder,  $t_J$  to 0 leading to the weight  $\exp[-r_{i_0}\mathcal{T}]$  for this trajectory. The second equality shows that the weight of any trajectory that starts at  $i_0$  is fully determined by knowing the total time  $\tau_i$  it spends in a state i and the number of transitions  $n_{ij}$  from i to j. Of course, there are many different trajectories leading to the same set  $\{\tau_i\}$ ,  $\{n_{ij}\}$ , which are, in general, not easily summed (or integrated) up.

# 4.2. Time-reversed trajectory and time-reversed process

An important concept for deriving fluctuation relations is the time-reversed or "backward" trajectory, or path,  $\widetilde{path} \equiv \widetilde{i}(t) \equiv i(\mathcal{T} - t)$ , running from  $\widetilde{i}_0 = i_{\mathcal{T}}$  to  $\widetilde{i}(\mathcal{T}) = i_0$ . The ratio between the probability to observe this trajectory given its initial value and the original ("forward") one follows from (24) and (30) as

$$\frac{p[\widetilde{\text{path}}|\tilde{i}_0]}{p[\text{path}|i_0]} = \frac{p[\tilde{i}(t)|\tilde{i}_0]}{p[i(t)|i_0]} = \exp\left[-\sum_{ij} n_{ij} \ln(k_{ij}/k_{ji})\right] = \exp\left[-(\beta Q[\text{path}] + \Delta S[\text{path}])\right], \tag{32}$$

since in the path weight the terms involving the escape rates are identical for both paths. This ratio is hence given by the heat dissipated along the original path and the concomitant change in intrinsic entropy.

In a useful generalization, while always drawing the forward path from the original distribution  $\{p_i^0\}$ , the backward one can be drawn from a, in general, fictitious ensemble  $\{\tilde{p}_i^0\}$  not necessarily given by  $\{p_i(\mathcal{T})\}$ , where the latter would be the final distribution along the forward process. Denoting this probability distribution for the backward paths by  $\tilde{p}[\text{path}]$ , we get easily

$$\frac{\tilde{p}[\tilde{\text{path}}]}{p[\text{path}]} = \frac{\tilde{p}[\tilde{\text{path}}|\tilde{i}_0 = i_{\mathcal{T}}]\tilde{p}_{i_{\mathcal{T}}}^0}{p[\text{path}|i_0]p_{i_0}^0} = \exp[-(\ln[p_{i_0}^0/\tilde{p}_{i_{\mathcal{T}}}^0] + \beta Q[\text{path}] + \Delta S[\text{path}])]. \tag{33}$$

This master relation is a useful starting point for a unified derivation of several famous non-equilibrium relations as discussed in the following.

<sup>&</sup>lt;sup>3</sup>This expression arises from applying repeatedly a straightforward generalization of the fact that if an event occurs with a rate k, the probability that it occurs for the first time at time t is  $p(t) = \exp(-kt)k$  given by a product of a waiting probability ("nothing happens") and the rate.

#### 4.3. Fluctuation theorem for entropy production in a non-equilibrium steady state (NESS)

For a NESS, we can draw the initial state for forward and backward path from the stationary distribution  $\{p_i^s\}$ . Since the first term in the exponent of (33) then becomes the change in stochastic entropy along the path, we get

$$\frac{p[\widetilde{\text{path}}]}{p[\text{path}]} = \exp[-\Delta S^{\text{tot}}[\text{path}]]. \tag{34}$$

Hence, in a NESS the probability to observe the time-reversed trajectory compared to the original one is exponentially small in the total entropy production along the original path. For a NESS, this relation quantifies an often somewhat imprecisely insinuated relation between entropy production and the "breaking" of time-reversal symmetry.

This behavior under time-reversal implies a remarkable symmetry of the distribution  $p(\Delta S^{\text{tot}})$  of total entropy production in a NESS, called the fluctuation theorem (FT), since

$$p(-\Delta S^{\text{tot}}) = \sum_{\text{paths}} p[\text{path}] \delta(\Delta S^{\text{tot}}[\text{path}] + \Delta S^{\text{tot}})$$

$$= \sum_{\text{paths}} p[\widetilde{\text{path}}] \exp[\Delta S^{\text{tot}}[\text{path}]] \delta(\Delta S^{\text{tot}}[\text{path}] + \Delta S^{\text{tot}})$$

$$= \sum_{\text{paths}} p[\widetilde{\text{path}}] \exp[-\Delta S^{\text{tot}}[\widetilde{\text{path}}]] \delta(-\Delta S^{\text{tot}}[\widetilde{\text{path}}] + \Delta S^{\text{tot}})$$

$$= \exp[-\Delta S^{\text{tot}}] p(\Delta S^{\text{tot}}). \tag{35}$$

Here, the first equality is the definition of the probability distribution, in the second we use the ratio (34), in the third the anti-symmetry  $\Delta S^{\text{tot}}[\text{path}] = -\Delta S^{\text{tot}}[\text{path}]$  and the fact that summing over the reversed paths is exhaustive. Due to the inclusion of stochastic entropy, this relation holds as shown here even for a finite total time  $\mathcal{T}$  [7]. Without this term, it has been first derived for stochastic dynamics in the long-time limit in [17, 18]. Earlier versions have been derived for thermostatted and chaotic dynamics [19, 20, 21].

### 4.4. Time-dependent driven systems: Jarzynski and Crooks relation

For a closed system connected to a heat bath and driven by a time-dependent Hamiltonian  $H(\xi, \lambda)$  as introduced in Sect. 2.4 above, the weight for a trajectory is slightly more involved than the "simple" expression (30). First, since the escape rate becomes time-dependent, the respective terms in the exponent must be replaced by time-integrals. Second, the weight now depends on the times when the transitions have taken place rather than just on their numbers. Moreover, the reversed process now also involves time-reversal of the control parameter according to  $\tilde{\lambda}(t) \equiv \lambda(T - t)$ .

It is a simple exercise to show that the (inverse) ratio of probabilities of observing the original trajectory under the forward driving and the probability of observing the time-reversed one under the time-reversed driving starting with arbitrary initial conditions is still given by (33) since the crucial time-dependences cancel. For this closed driven system, we should use (33) with capital letters for meso-states and probabilities which was the notation in Sect. 2.

For a system that is driven from an initial parameter  $\lambda_0$  to a final  $\lambda_1$ , by starting the original process in thermal equilibrium and the backward one also in the respective thermal equilibrium,  $P_I^e(\lambda) = \exp[-\beta(F_I(\lambda) - F(\lambda))]$ , the first term in the exponent of (33) becomes

$$\ln[p_{i_0}^0/\tilde{p}_{i_{\mathcal{T}}}^0] \mapsto \ln[P_{I_0}^e(\lambda_0)/P_{I_{\mathcal{T}}}^e(\lambda_{\mathcal{T}})] = \beta[-F_{I_0}(\lambda_0) + F(\lambda_0) + F_{I_{\mathcal{T}}}(\lambda_{\mathcal{T}}) - F(\lambda_{\mathcal{T}})] = \beta[\Delta F[\text{path}] - \Delta F], \tag{36}$$

where  $F(\lambda)$  denotes the free energy at control parameter  $\lambda$  and  $\Delta F \equiv F(\lambda_T) - F(\lambda_0)$  is the free energy difference of the system at the two values of the control parameter. After integrating (16) and (17) along a trajectory, the sum of second and third term in the exponent of (33) becomes

$$\beta Q[path] + \Delta S[path] = \beta (W[path] - \Delta F[path]). \tag{37}$$

Putting everything together, one gets

$$\tilde{p}[\text{path}]/p[\text{path}] = \exp[-\beta(W[\text{path}] - \Delta F)]. \tag{38}$$

By repeating essentially the same calculation as above for the derivation of the FT in a NESS, one gets the Crooks relation [12]

$$\tilde{p}(-W) = p(W) \exp[-\beta(W - \Delta F)]. \tag{39}$$

Consequently, the free energy difference of two states can be determined by measuring the crossing point of the work distributions using the original and the time-reversed protocol. For the beautiful first experimental application of this relation with biomolecules, see [22].

Finally, and here certainly not following the original history, one gets the famous Jarzynski relation [10, 11] by integrating (39) over *W* as

$$\langle \exp[-\beta W] \rangle = \exp[-\beta \Delta F],$$
 (40)

whose manifold consequences are authoratively reviewed in [1].

Note that we have derived the Jarzynski and the Crooks relation here using stochastic dynamics and meso-states that possess intrinsic entropy. The original derivation of the former [10] used Hamiltonian dynamics for the closed system and coupling and decoupling from a heat bath. Likewise, the original (and many present) derivations using stochastic dynamics [11, 12] ignore the intermediate consequences of intrinsic entropy, which are no longer explicitly visible at the end anyway.

## 5. Asymmetric random walk as a simple thermodynamically consistent paradigm

# *5.1. Model*

For a simple asymmetric random walk, we introduce a few concepts that will be explored for more general systems in the following sections. This model can also serve as a simple description of a molecular motor running along a filament. In each step of length *d*, the motor works against an external force *f* and is powered by hydrolysis of one molecule of ATP that provides ∆µ of free energy in each forward reaction (ATP → ADP + P*i*) and generates the same amount in a backward reaction. Thermodynamic consistency (20) demands for the ratio of forward, *k*+, to backward, *k*−, rate

$$k_{+}/k_{-} = \exp[\beta(\Delta\mu - fd)] \equiv \exp A, \tag{41}$$

which defines the (dimensionless) affinity *A*.

## *5.2. Fluctuations*

After a time *t*, the motor has made *n*<sup>+</sup> steps in the forward and *n*<sup>−</sup> steps in the backward direction. Their probability distribution obeys

$$\partial_t p(n_+, n_-, t) = -(k_+ + k_-)p(n_+, n_-, t) + k_+ p(n_+ - 1, n_-, t) + k_- p(n_+, n_- - 1, t). \tag{42}$$

Since the steps in the two directions correspond to two independent Poisson processes, this distribution function is simply

$$p(n_{+}, n_{-}, t) = [(k_{+}t)^{n_{+}}/n_{+}!][(k_{-}t)^{n_{-}}/n_{-}!] \exp[-(k_{+} + k_{-})t],$$
(43)

as is easily verified a posteriori by insertion.<sup>4</sup> Mean value and dispersion are given by

$$\langle n_{\pm} \rangle = k_{\pm}t \text{ and } \langle (n_{\pm} - \langle n_{\pm} \rangle)^2 \rangle = k_{\pm}t.$$
 (44)

For the net number of steps in forward direction, *n* ≡ *n*<sup>+</sup> − *n*−, one gets for mean and dispersion

$$\langle n \rangle = (k_+ - k_-)t \text{ and } \langle (n - \langle n \rangle)^2 \rangle = (k_+ + k_-)t \equiv 2Dt$$
 (45)

with the diffusion constant *D* ≡ (*k*<sup>+</sup> + *k*−)/2.

<sup>4</sup>Note that for this simple asymmetric random walk the summation of (30) over all transition times is obviously possible leading to the additional factor *t <sup>n</sup>*+*n*<sup>−</sup> /(*n*+!*n*−!) when (43) is derived from (30).

The mean rate of entropy production (28) becomes

$$\sigma = (k_{+} - k_{-}) \ln(k_{+}/k_{-}) = i^{s} A \tag{46}$$

with the mean net current  $j^s \equiv v_+^s - v_-^s = k_+ - k_-$ .

For large t, the factorials in (43) can be approximated by Stirling's formula leading to

$$p(n_+, n_-, t) \approx \exp\{-t[\nu_+ \ln(\nu_+/k_+) - \nu_+ + k_+ + \nu_- \ln(\nu_-/k_-) - \nu_- + k_-]\} \equiv \exp[-tI(\nu_+, \nu_-)]$$
(47)

where we have defined the fluctuating rates of directed transition

$$v_{\pm} \equiv n_{\pm}/t \tag{48}$$

with stationary mean value  $v_{+}^{s} = k_{\pm}$  and identified a "rate" function  $I(v_{+}, v_{-})$ .

#### 5.3. Thermodynamic uncertainty relation

The expressions just given allow for another interpretation in terms of the precision of a biomolecular process. After a time t, the motor has "produced" a number of steps n. The uncertainty of this process is defined as

$$\epsilon^2 \equiv \langle (n - \langle n \rangle)^2 \rangle / \langle n \rangle^2 = 2D/j^{s^2} t, \tag{49}$$

which is a measure of its precision. During this time t, on average, running this process has generated  $C \equiv \sigma t$  entropy, which is the (dimensionless) free energy that is not recovered as mechanical work, i.e., the net thermodynamic cost of the process. By combining (46) and (49) one gets

$$C\epsilon^2 = 2\sigma D/j^{s^2} = A \coth(A/2) \ge 2. \tag{50}$$

The product of loss and precision is thus given by a function of the affinity. Independently of the value of this affinity, this product is bounded by, 2 which has been dubbed the "thermodynamic uncertainty relation" [23]. The longer the motor runs the higher the precision, which is a consequence of the diffusive behavior. On the other hand, the cost increases linearly in time which implies that the product  $C\epsilon^2$  is time-independent. A higher precision inevitably comes at a higher cost. The inequality is saturated for vanishing affinity, i.e., close to equilibrium, and also close to the stall force,  $f \simeq \Delta \mu/d$ . The a priori surprising fact is that the thermodynamic uncertainty relation holds in a much more general formulation for any thermodynamically consistent Markov process as we will see below.

## 6. Fluctuations in a non-equilibrium steady state (NESS) in the long-time limit

From now on, we focus on the fluctuations in a NESS in the long-time limit for which general results can be derived based on techniques from large-deviation theory as reviewed in [24, 25, 26] and by Touchette in this volume.

### 6.1. Empirical density, current and traffic

For a Markov process on an arbitrary set of states, we define two classes of observables whose mean is extensive in time. First, there is the (residence or sojourn) time  $\tau_i$  a trajectory spends in the state i with the mean  $\langle \tau_i \rangle = p_i^s t$ . It will become convenient to consider the empirical density

$$p_i \equiv \tau_i/t,\tag{51}$$

whose mean is the stationary distribution  $\langle p_i \rangle = p_i^s$ 

Second, from the number of jumps  $n_{ij}$ , we get the fluctuating, or empirical, currents and traffic, defined as

$$j_{ij} \equiv (n_{ij} - n_{ji})/t$$
 and  $t_{ij} \equiv (n_{ij} + n_{ji})/t$ , (52)

with mean values

$$j_{ij}^s = p_i^s k_{ij} - p_j^s k_{ji}$$
 and  $t_{ij}^s = p_i^s k_{ij} + p_j^s k_{ji}$ , (53)

respectively. For an arbitrary current

$$j_{\alpha} \equiv \sum_{ij} n_{ij} d_{ij}^{\alpha} / t$$
 with mean  $j_{\alpha}^{s} = \sum_{ij} p_{i}^{s} k_{ij} d_{ij}^{\alpha}$  (54)

the generalized distances  $d_{ij}^{\alpha} = -d_{ji}^{\alpha}$  determine how much each transition  $i \to j$  contributes. A prominent current is the one of total entropy production  $j_{\sigma}$  for which  $d_{ij}^{\sigma} \equiv \ln[p_i^s k_{ij}/p_j^s k_{ji}]$ , whose mean is given by the entropy production rate  $\sigma$  (28).

#### 6.2. Level 2.5 rate function and contractions

There is an elegant approach to determine the probability of large fluctuations, i.e., large deviations from the average behavior, in the long-time limit. Let  $p(\{\tau_i\}, \{n_{ij}\}, t)$  be the probability (density) of observing the residence times  $\{\tau_i\}$  and  $\{n_{ij}\}$  transitions from i to j, after a time t. This probability can be calculated by introducing an auxiliary set of rates on the same network of states for which these values would correspond to the mean behavior. Specifically, for the rates  $\hat{k}_{ij} \equiv n_{ij}/\tau_i$  the stationary distribution becomes  $\hat{p}_i = \tau_i/t$  and the mean number of transitions is  $\hat{n}_{ij} = \hat{p}_i\hat{k}_{ij}t = n_{ij}$ . We denote the escape rates for these modified rates as  $\hat{r}_i$ .

Using this auxiliary set of rates, the ratio of probabilities of observing the fluctuation  $\{\tau_i\}$ ,  $\{n_{ij}\}$  in the original network and in the one with the auxiliary set of rates follows from the path integral expression (30) as [27]

$$\frac{p(\{\tau_i\}, \{n_{ij}\}, t | \{k_{ij}\}, i_0)}{p\{\tau_i\}, \{n_{ij}\}, t | \{\hat{k}_{ij}\}, i_0)} = \exp\left[-\sum_i \tau_i(r_i - \hat{r}_i) + \sum_{ij} n_{ij} \ln(k_{ij}/\hat{k}_{ij})\right],$$
 (55)

where we introduce a finally irrelevant common initial state  $i_0$ .<sup>5</sup> By multiplying with the denominator, summing over initial states and normalizing with the typical fluctuation of the original network, the ratio of probabilities of observing the (large) fluctuation and a typical one for the original set of rates now follows as

$$\frac{p(\{\tau_i\}, \{n_{ij}\}, t | \{k_{ij}\})}{p(\{p_i^s t\}, \{p_i^s k_{ij} t\}, t | \{k_{ij}\})} = \exp\left[-\sum_i \tau_i(r_i - \hat{r}_i) + \sum_{ij} n_{ij} \ln(k_{ij}/\hat{k}_{ij})\right] \times \frac{\sum_{i_0} p(\{\hat{p}_i t\}, \{\hat{p}_i \hat{k}_{ij} t\}, t | \{\hat{k}_{ij}\}, i_0) p_{i_0}^s}{\sum_{i_0} p(\{p_i^s t\}, \{p_i^s k_{ij} t\}, t | \{k_{ij}\}, i_0) p_{i_0}^s}.$$
 (56)

The last factor involves the ratio of probabilities of observing the typical behavior for the respective set of rates weighted with the probability of the initial state in the original set of rates. For large t, the latter dependence vanishes and the ratio becomes a time-independent function of both sets of rates in leading order. Consequently, in the long-time limit, the logarithmic ratio of these probabilities can be written in the form

$$-\lim_{t \to \infty} (1/t) \ln \left( \frac{p(\{\tau_i\}, \{n_{ij}\}, t | \{k_{ij}\})}{p(\{p_i^s t\}, \{p_i^s k_{ij} t\}, t | \{k_{ij}\})} \right) = I(\{\tau_i/t\}, \{n_{ij}/t\})$$
(57)

with the rate function

$$I(\{\tau_i/t\}, \{n_{ij}/t\}) = \sum_i (\tau_i/t)(r_i - \hat{r}_i) + \sum_{ij} (n_{ij}/t) \ln(\hat{k}_{ij}/k_{ij}).$$
 (58)

The auxiliary rates have now served their purpose and we can focus on fluctuating quantities for the original set of rates. Specifically, we consider the empirical densities, currents and traffics. Expressed in these quantities, the rate function (58) reads

$$I(\{p_i\}, \{j_{ij}\}, \{t_{ij}\}) = \sum_{ij} \left\{ \frac{j_{ij} + t_{ij}}{2} \left[ \ln \frac{j_{ij} + t_{ij}}{2p_i k_{ij}} - 1 \right] + p_i k_{ij} \right\}.$$
 (59)

This rate function is a very general one, called "level 2.5", which depends on all empirical densities, currents and traffics. It is crucial to note that probability conservation provides a set of constraints  $\sum_j j_{ij} = 0$  for all states  $\{i\}$ , which will be assumed implicitly in the following.

<sup>&</sup>lt;sup>5</sup>Here and in the following, the advantage of including the denominators on the left hand sides is that one avoids introducing the Radon-Nikodym derivative for measures and still deals with dimensionless quantities when later taking logarithms.

Often one is interested in the corresponding rate function of a subset of these quantities, or a set of certain functions of them. Such a rate function can be obtained from the full one through "contraction". Specificially, the rate function for  $f = f(\{p_i\}, \{j_{ij}\}, \{t_{ij}\})$  is obtained through

$$I(f) = \min_{\{p_i\}, \{j_{ij}\}, \{t_{ij}\} | f(\{p_i\}, \{j_{ij}\}, \{t_{ij}\}) = f} I(\{p_i\}, \{j_{ij}\}, \{t_{ij}\})$$

$$(60)$$

since for  $t \to \infty$  one can focus on the most likely fluctuation for given constraints. In general, this constrained minimization cannot be performed analytically. An upper bound on the rate function for f, however, can be obtained by inserting a variational trial solution.

An important contraction is the one eliminating the traffic, which can be performed analytically. Keeping in mind the symmetry properties of  $t_{ij}$  and  $j_{ij}$ , one finds for the optimal value

$$t_{ij}^{*2} = j_{ij}^2 + 4p_i p_j k_{ij} k_{ji}$$
 (61)

and, hence, for the rate function [27]

$$I(\lbrace p_{i}\rbrace, \lbrace j_{ij}\rbrace) = I(\lbrace p_{i}\rbrace, \lbrace j_{ij}\rbrace, \lbrace t_{ij}^{*}\rbrace) = \sum_{i < j} \left\{ j_{ij} \ln \frac{j_{ij} + \sqrt{j_{ij}^{2} + 4p_{i}p_{j}k_{ij}k_{ji}}}{2p_{i}k_{ij}} - \sqrt{j_{ij}^{2} + 4p_{i}p_{j}k_{ij}k_{ji}} + p_{i}k_{ij} + p_{j}k_{ji} \right\}$$
(62)

In this form, the rate function inherits the FT-symmetry (34)

$$I(\{p_i\}, \{j_{ij}\}) - I(\{p_i\}, \{-j_{ij}\}) = -\sum_{i < i} j_{ij} \ln[p_i k_{ij}/p_j k_{ji}] \equiv -\sigma(\{j_{ij}\}), \tag{63}$$

with its time-antisymmetric part given by the corresponding entropy production.

#### 6.3. A universal bound on current fluctuations

A further contraction of (62) to get rid off the empirical densities can not be performed analytically. One can, however, get an upper bound on the rate function for the currents by replacing (the unknown optimal)  $p_i$  by (the stationary)  $p_i^s$ ,

$$I(\{j_{ij}\}) \leq I(\{p_i^s\}, \{j_{ij}\}) = \sum_{i < j} \left\{ j_{ij} \ln \frac{j_{ij} + \sqrt{j_{ij}^2 + t_{ij}^{s^2} - j_{ij}^{s^2}}}{j_{ij}^s + t_{ij}^s} - \sqrt{j_{ij}^2 + t_{ij}^{s^2} - j_{ij}^{s^2}} + t_{ij}^s \right\}.$$
 (64)

This upper bound still obeys the FT-type symmetry

$$I(\{p_i^s\}, \{j_{ij}\}) - I(\{p_i^s\}, \{-j_{ij}\}) = -\sum_{i < j} (\sigma_{ij}^s / j_{ij}^s) j_{ij} = -\sigma(\{j_{ij}\}),$$
(65)

where

$$\sigma_{ij}^{s} \equiv j_{ij}^{s} \ln[p_{i}^{s} k_{ij} / p_{j}^{s} k_{ji}] = j_{ij}^{s} \ln \frac{t_{ij}^{s} + j_{ij}^{s}}{t_{ii}^{s} - j_{ii}^{s}}$$
(66)

is the mean entropy production rate in the link (ij). Remarkably, a quadratic function with the same minimum and the same symmetry provides a global upper bound on the right hand side of (64) leading to [28]

$$I(\{j_{ij}\}) \le \sum_{i < j} \frac{\sigma_{ij}^s (j_{ij} - j_{ij}^s)^2}{4j_{ij}^{s^2}}.$$
 (67)

This bound is tight at  $j_{ij} = \pm j_{ij}^s$  and has, in general, a larger curvature in the minimum than (64). Thus the fluctuations of the current through any link have been shown to be larger than a Gaussian involving the local entropy production.

Finally, to get an upper bound on the rate function for an arbitrary current  $j_{\alpha}$  with mean value  $j_{\alpha}^{s}$ , we can choose  $j_{ij} = j_{ij}^{s} j_{\alpha}/j_{\alpha}^{s}$  leading to

$$I(j_{\alpha}) \le \frac{\sigma(j_{\alpha} - j_{\alpha}{}^s)^2}{4j_{\alpha}{}^{s2}}.$$
(68)

Hence, the rate function for any current is bounded by a simple quadratic function whose curvature is determined by the dissipation rate as first conjectured in [29] and proven along the lines shown here in [28], see also [30].

### 6.4. Bounds on the rate function for empirical densities and traffic

By applying a similar reasoning, Garrahan has derived related bounds for non-negative time-symmetric quantities like empirical densities and traffic [31]. Rather than entropy production  $\sigma$ , the overall activity or traffic  $\sum_{ij} p_i^s k_{ij}$  then plays a crucial role.

#### 7. Thermodynamic uncertainty relation: The cost of precision and thermodynamic inference

#### 7.1. Formulation

In significantly larger generality than for the asymmetric random walk discussed above in Sect. 5.1, the thermodynamic uncertainty relation provides a universal bound on the precision of any biomolecular process. In a NESS, with each stationary current  $j_{\alpha}^s = \sum_{i < j} d_{ij}^{\alpha} j_{ij}^s$ , see (54), there is associated a fluctuating "output"  $X_{\alpha} = \sum_{i j} n_{ij} d_{ij}^{\alpha}$  with mean  $\langle X_{\alpha} \rangle = j_{\alpha}^s t$ . From variance and mean of this output in the long-time limit, we define its precision

$$\epsilon_{\alpha}^2 \equiv \langle (X_{\alpha} - j_{\alpha}^s t)^2 \rangle / (j_{\alpha}^s t)^2 \to 2D_{\alpha} / (j_{\alpha}^s t)$$
 for large  $t$ , (69)

where  $D_{\alpha}$  is the dispersion of the process. On the other hand running this process for a time t generates on average  $C = \sigma t$  entropy, which is the thermodynamic cost associated with it. The thermodynamic uncertainty relation

$$\lim_{\alpha \to \infty} C\epsilon_{\alpha}^2 = 2\sigma D_{\alpha}/j_{\alpha}^{s^2} \ge 2 \tag{70}$$

holds for any Markov process. Thus, precision in the outcome of any such process requires a minimum cost.

This relation was formulated as a conjecture in [23] based on analytical results for the linear response regime of multicyclic networks and for unicyclic networks with their only one independent current. With the bound (68) on the rate function, the proof follows trivially using  $D_{\alpha} = 1/[2I''(j_{\alpha}^s)]$  [28]. Recent work conjectures it to be true even for a finite time t with  $\epsilon_{\alpha}(t)$  [32].

#### 7.2. Thermodynamic inference for a molecular motor

The thermodynamic uncertainty relation can be used to infer physical properties of biomolecular systems from the observation of fluctuations even if the underlying biochemical or enzymatic network is not (fully) known as we will now illustrate for a molecular motor running against a constant force f at a mean velocity v with dispersion D.

Any such motor delivers a mean output power  $P^{\text{out}} = fv = \sum_{i < j} f j_{ij}^s d_{ij}$ , where  $d_{ij}$  denotes the distance the motor steps in a transition  $i \to j$  along its track against the force. The corresponding fluctuating current  $j^{\text{out}}$  is a genuine current to which the uncertainty relation will be applied below. Likewise, this motor is powered by the consumption of ATP leading to a mean input power  $P^{\text{in}}$  that is typically not directly accessible.

In a NESS, the entropy production rate, i.e., the rate of wasted free energy, can then be written as

$$\sigma = \beta(P^{\text{in}} - P^{\text{out}}). \tag{71}$$

The thermodynamic efficiency of such a motor  $\eta \equiv P^{\text{out}}/P^{\text{in}}$  fulfills a universal bound set by the thermodynamic uncertainty relation (70) applied to the output current that can be obtained through a simple algebraic transformations as [33]

$$\eta = \frac{P^{\text{out}}}{P^{\text{out}} + \sigma/\beta} = \frac{vf}{vf + \sigma/\beta} \le \frac{1}{1 + v/(Df\beta)}.$$
 (72)

The intriguing aspect of this bound arises from the fact that v, D and f are experimentally accessible quantities. No knowledge of the underlying network, i.e., of the specific reaction scheme is necessary for applying this bound. There could be idle cycles where ATP is used without advancing the motor. It is not even necessary to know the free energy difference  $\Delta\mu$  associated with the ATP hydrolysis. In Fig. 2, this bound is evaluated with experimental data for a kinesin motor reported in [34].

![](_page_13_Figure_0.jpeg)

![](_page_13_Figure_1.jpeg)

Figure 2: Randomness parameter r = 2D/vd for kinesin as experimentally measured in [34] as a function of ATP-concentration (for a fixed force f = 3.59 pN, left panel) and of load force (for fixed  $c_{ATP} = 2$ mM, right panel). The colored area shows the corresponding theoretical bound (72). At, e.g., 2pN load force (right panel), these experimental data imply that this motor thus converts ATP to mechanical power with an efficiency of at most 45 % for these conditions.

#### 8. Topology- and affinity-dependent bounds for thermodynamic inference

## 8.1. Cycles and their affinities

Cycles and the currents running through them are even better suited for relating statistical with thermodynamic properties than the currents through individual links [8]. A cycle  $C_a$  is a directed, self-avoiding, closed path of length  $N_a$  on the set of states, see Fig. 3. Its adjacency matrix  $\chi_{ij}^a$  has element 1 if the cycle passes the link (ij) in forward direction, -1 if it passes this link in backward direction, and 0 if the link is not part of this cycle. For a complete set of cycles, all stationary currents can be expressed as a linear combination of cycle currents

$$j_{ij}^s = \sum_a \chi_{ij}^a j_a^s. \tag{73}$$

In a NESS, after completing any cycle, the system has returned to its original state and hence all physical changes associated with the cycle have taken place in the surrounding reservoirs. The mean entropy production (28) is time-independent and becomes a linear combination of cycle currents

$$\sigma = j_{\sigma}^{s} = \sum_{i < j} j_{ij}^{s} \ln[p_{i}^{s} k_{ij} / p_{j}^{s} k_{ji}] = \sum_{i < j} j_{ij}^{s} \ln[k_{ij} / k_{ji}] = \sum_{a} j_{a}^{s} A_{a}$$
(74)

where the cycle affinity

$$A_a = \sum_{i < j} \chi_{ij}^a \ln[k_{ij}/k_{ji}] = \sum_I n_a^{\gamma} A^{\gamma}$$

$$\tag{75}$$

is determined by the ratio of forward and backward rates along a cycle. These cycle affinities are (integer) linear combinations of a set of physical affinities  $A^{\gamma}$  that are imposed by the external conditions. Examples for such physical affinities are  $\beta f d$ , where f is a force and d a repeat distance on a filament or  $\beta \Delta \mu$  of an ATP hydrolysis. In the example of the ARW from Sect. 5.1, there is the equivalent of only one cycle with one cycle affinity  $A = A^{\text{in}} - A^{\text{out}} = \beta(\Delta \mu - f d)$ .

#### 8.2. Uniform, unicyclic asymmetric random walk

For a unicyclic network of N states with uniform rates  $k_+, k_-$ , hence affinity  $A = N \ln(k_+/k_-)$ , and mean current  $j^s = \sigma/A$ , the rate function for the probability current can be obtained from (47) through contraction or from (62) using the obvious symmetry  $p_i^* = 1/N$ . In any case, it leads to [18]

$$I(j) = I(\xi j^{s}) = (N/A)\sigma \left[ \xi \ln \frac{a\xi + \sqrt{a^{2}\xi^{2} + 1}}{a + \sqrt{a^{2} + 1}} - \sqrt{\xi^{2} + 1/a^{2}} + \sqrt{1 + 1/a^{2}} \right], \tag{76}$$

with the scaled current  $\xi \equiv j/j^s$  and  $a \equiv \sinh(A/2N)$ .

![](_page_14_Figure_0.jpeg)

![](_page_14_Figure_1.jpeg)

Figure 3: A network with two independent cycles [(1,5,4)] and (1,2,3,4) (left panel). Rate function  $I(j_{\sigma})$  for the entropy current, its quadratic bound (68) and the corresponding topology- and affinity-dependent bound (76) (right panel). Transition rates:  $k_{15} = k_{52} = k_{21} = k_{34} = e^4$ ,  $k_{12} = k_{25} = k_{51} = k_{14} = k_{43} = k_{32} = e^{-4}$ ,  $k_{23} = e^{10}$ ,  $k_{41} = e^6$ , leading to the cycle affinities  $A_1 = A_2 = 24$  and hence  $(A/n)^* = 24/4 = 6$ .

#### 8.3. Nonuniform unicyclic and multicylic networks

For a unicyclic network with non-uniform rates with cycle affinity  $A = \sum_{i < j} \ln[k_{ij}/k_{ji}]$ , one can prove that (76) provides an upper bound on the rate function for the probability current [35]. The physical reason is that at fixed affinity and number of states uniform rates lead to the smallest fluctuations.

An expansion of (76) around the minimum then implies for the dispersion coefficient the inequality

$$D = \frac{1}{2I''(j^s)} \ge \frac{A}{2N} \frac{j^{s^2}}{\sigma} \coth(A/2N) \quad [= (j^s/2N) \coth(A/2N)], \tag{77}$$

which leads for cost and precision to the improved inequality

$$C\epsilon^2 = 2\sigma D/j^{s^2} \ge (A/N) \coth(A/2N) \ge \max(2, A/N). \tag{78}$$

The first inequality is saturated for uniform rates, the second one close to equilibrium  $(A \ll N)$  for the first choice, and far from it for the second one.

An a priori surprising result is that for an arbitrary current  $j_a$  in a multicyclic network the rate function  $I(j_a)$ , the diffusion constant  $D_a$  and the product  $C\epsilon_a^2$  in the refined uncertainty relation are still bounded by the expressions (76), (77, unbracketed) and (78), respectively, if one replaces (A/N) by  $(A/N)^*$  which is the smallest strictly positive value of  $(A_a/N_a)$  among all cycles [35], for an example, see Fig. 3. This proof relies on an identification of a suitable choice of fundamental currents and is somewhat technical. The physics behind it reflects the fact that the cycle with the smallest  $A_a/N_a$  potentially leads to the smallest fluctuations and thus provides a lower bound on the true fluctuations.

#### 8.4. Example: Cost and precision of a Brownian clock

For an example illustrating these concepts, we consider a simple model for a thermodynamically consistent clock [36]. It consists of a unicyclic network of N states driven by an affinity A leading to a mean current  $j^s$ . A unit of measured time is counted whenever the transition from N to 1 occurs. For consistency, we have to allow that this transition may occasionally happen in the reversed direction, in which case time has "advanced" a negative unit. After real time t, the clock has measured X(t) units with mean  $j^s t$  and precision as given by (69). The implications of the bound (78) for the design, precision and cost of such a Brownian clock can best be illustrated by comparing two clocks using familiar notions [36]. Suppose we want to measure reliably, say with a precision  $\epsilon = 0.01$ , a time of one hour with either a slow clock that takes one minute for a revolution or a fast clock that takes only one second implying  $\langle X \rangle = 60$  and 3600 for slow and fast, respectively. With the cost  $C = A\langle X \rangle$ , the second inequality in (78) implies, first, a structural constraint on the minimal number of states making up the cycle, which is  $N_{\min} = 167$  and 3 for the slow and the fast clock, respectively. The slow clock has to have sufficiently many states within its cycle to achieve the required precision. Second, for a given design, i.e., for a given number of states N in the cycle, the affinity driving the clock has to be at least  $A_{\min} = 2N \operatorname{arccoth}(\langle X \rangle N \epsilon^2) \geq 2/(\langle X \rangle \epsilon^2)$ . For the slow clock, we get  $A_{\min} \simeq 333$  and for the fast one,  $A_{\min} \simeq 5.55$ . The overall entropy production associated with measuring one hour with this precision is bounded by

20000 for both types. From an energetic point of view, both designs are equivalent. In a biochemical network the free energy is often provided by ATP hydrolysis, which under physiological conditions liberates approximately  $20 k_B T$  of free energy. The universal result  $C\epsilon^2 \ge 2$  then implies that for an uncertainty of 0.01 the Brownian clock requires the consumption of at least 1000 ATP molecules.

The fact that the bound (78) holds even for the "best" cycle of a multicyclic network implies that a more intricate "wiring" of the network cannot improve the inevitable trade-off between precision and cost. It has been shown, however, that driving such a clock not by a constant affinity but rather by a modulation of energies and barriers, i.e. of the transition rates between the states in a periodic fashion, a given precision requires no minimal cost [36], see also [37]. On the other hand, if one includes the thermodynamic cost of providing such a time-periodic variation of parameters, one is effectively back at the above inequality [38].

# 8.5. Thermodynamic inference: Fano factor in enzyme kinetics

These topology- and affinity-dependent bounds can be used as a diagnostic tool to infer properties of an unknown underlying biochemical network if the fluctuations of a current can be measured and if some information on the driving affinity is known. As an example consider an enzyme E that transforms a substrate S into a product P using hydrolysis of one ATP molecule which liberates  $\Delta\mu$  of free energy. Suppose in a single-molecule experiment one measures that after a long time t on average  $\langle X \rangle = j^s t$  product molecules have been generated with a variance  $\langle (X - j^s t)^2 \rangle = 2Dt$  which defines the dispersion of this current. With  $\sigma = j^s \Delta\mu$ , the bound (77) implies a bound on the Fano factor [39]

$$F = 2D/j^{s} \ge (n/N)^{*} \coth[(\Delta \mu/2)(n/N)^{*}], \tag{79}$$

where  $(n/N)^*$  is the smallest value for the ratio between number of products n and number of states N among all cycles. For a simple Michaelis-Menten scheme with only three states  $(E \to ES \to EP \to E, i.e., N = 3, n = 1)$  the bound reads  $F \ge [\coth(\Delta \mu/6)]/3$ . Any measurement that leads to a smaller value for F implies either that (at least) a fourth state is involved or that the enyzme is able to bind two substrates [39], see Fig. 4.

![](_page_15_Figure_6.jpeg)

Figure 4: Left panel: Simple Michaelis-Menten scheme for an enzyme E binding a substrate S, transforming it into a product P and releasing it. Middle panel: Network for an enzyme that can bind two substrates and transform them into products. Right panel: Lower bound of the Fano factor (79) as a function of  $\Delta\mu$  for various values for N/n = 3 and 5, the latter being relevant for the 5-state cycle ES $\rightarrow$ ESP $\rightarrow$ EPP $\rightarrow$ EP $\rightarrow$ ES. The colored region in between is allowed for the scheme in the middle and excluded for the simple scheme from the left.

#### 9. Concluding remark

The basic principles of stochastic thermodynamics as recalled here are by now firmly established. Whenever a driven system is connected to a heat bath and a set of slow variables can be identified whose dynamics is well-separated from that of the unobserved fast degrees of freedom, thermodynamic quantities like work, heat and entropy production can be identified. Their distributions obey universal fluctuation relations that have been measured computationally and experimentally in many systems. As the second part of these lectures is supposed to demonstrate, we are arguably now entering a second stage where inequalities like the thermodynamic uncertainty relation, which have been derived by following the consistency conditions imposed by stochastic thermodynamics, are used to infer hidden properties of a system, a strategy that could be called "thermodynamic inference" [40]. Quite likely, many exciting insights into the operation of small machines will be unravelled as these concepts are combined with single molecule experiments.

These insights will not be confined to the isothermal realm of biomolecular systems. Analogous progress has indeed been made for heat engines operating between baths of two different temperatures as the identification of a universal trade-off between power, efficiency and constancy of operation paradigmatically shows [41].

Acknowledgments: The results developed in the second part of these lectures have originally been obtained with Andre C. Barato and Patrick Pietzonka. I thank both for an enjoyable ongoing collaboration and the latter for a careful reading of these notes. I am grateful to Marco Baiesi, Alberto Rosso and Thomas Speck for the opportunity to present these lectures at this summer school. The help of Patrick Pietzonka and Matthias Uhl with preparing the figures is gratefully acknowledged.

## References

- [1] C. Jarzynski, Equalities and inequalities: Irreversibility and the second law of thermodynamics at the nanoscale, Ann. Rev. Cond. Mat. Phys. 2 (2011) 329–351.
- [2] U. Seifert, Stochastic thermodynamics, fluctuation theorems, and molecular machines, Rep. Prog. Phys. 75 (2012) 126001.
- [3] C. van den Broeck, M. Esposito, Ensemble and trajectory thermodynamics: A brief introduction, Physica A 418 (2015) 6 16.
- [4] S. Ciliberto, Experiments in stochastic thermodynamics: Short history and perspectives, Phys. Rev. X 7 (2017) 021051.
- [5] N. G. van Kampen, Stochastic Processes in Physics and Chemistry, North-Holland, Amsterdam, 1981.
- [6] K. Sekimoto, Langevin equation and thermodynamics, Prog. Theor. Phys. Supp. 130 (1998) 17.
- [7] U. Seifert, Entropy production along a stochastic trajectory and an integral fluctuation theorem, Phys. Rev. Lett. 95 (2005) 040602.
- [8] J. Schnakenberg, Network theory of microscopic and macroscopic behavior of master equation systems, Rev. Mod. Phys. 48 (1976) 571.
- [9] U. Seifert, Stochastic thermodynamics of single enzymes and molecular motors, Eur. Phys. J. E 34 (2011) 26.
- [10] C. Jarzynski, Nonequilibrium equality for free energy differences, Phys. Rev. Lett. 78 (1997) 2690.
- [11] C. Jarzynski, Equilibrium free-energy differences from nonequilibrium measurements: A master-equation approach, Phys. Rev. E 56 (1997) 5018.
- [12] G. E. Crooks, Entropy production fluctuation theorem and the nonequilibrium work relation for free energy differences, Phys. Rev. E 60 (1999) 2721.
- [13] K. Sekimoto, Microscopic heat from the energetics of stochastic phenomena, Phys. Rev. E 76 (2007) 060103(R).
- [14] R. K. P. Zia, B. Schmittmann, Probability currents as principal characteristics in the statistical mechanics of non-equilibrium steady states, J. Stat. Mech.: Theor. Exp. (2007) P07012.
- [15] U. Seifert, First and second law of thermodynamics at strong coupling, Phys. Rev. Lett. 116 (2016) 020601.
- [16] C. Jarzynski, Stochastic and macroscopic thermodynamics of strongly coupled systems, Phys. Rev. X 7 (2017) 011008.
- [17] J. Kurchan, Fluctuation theorem for stochastic dynamics, J. Phys. A: Math. Gen. 31 (1998) 3719.
- [18] J. L. Lebowitz, H. Spohn, A Gallavotti-Cohen-type symmetry in the large deviation functional for stochastic dynamics, J. Stat. Phys. 95 (1999) 333.
- [19] D. J. Evans, E. G. D. Cohen, G. P. Morriss, Probability of second law violations in shearing steady states, Phys. Rev. Lett. 71 (1993) 2401.
- [20] D. J. Evans, D. J. Searles, Equilibrium microstates which generate second law violating steady states, Phys. Rev. E 50 (1994) 1645.
- [21] G. Gallavotti, E. G. D. Cohen, Dynamical ensembles in nonequilibrium statistical mechanics, Phys. Rev. Lett. 74 (1995) 2694.
- [22] D. Collin, F. Ritort, C. Jarzynski, S. Smith, I. Tinoco, C. Bustamante, Verification of the Crooks fluctuation theorem and recovery of RNA folding free energies, Nature 437 (2005) 231.
- [23] A. C. Barato, U. Seifert, Thermodynamic uncertainty relation for biomolecular processes, Phys. Rev. Lett. 114 (2015) 158101.
- [24] H. Touchette, The large deviation approach to statistical mechanics, Phys. Rep. 478 (2009) 1–69.
- [25] A. Lazarescu, The physicist's companion to current fluctuations: one-dimensional bulk-driven lattice gases, J. Phys. A: Math. Theor. 48 (50) (2015) 503001.
- [26] A. C. Barato, R. Chetrite, A formal view on level 2.5 large deviations and fluctuation relations, J. Stat. Phys. 160 (5) (2015) 1154–1172.
- [27] C. Maes, K. Netoˇcn ´y, Canonical structure of dynamical fluctuations in mesoscopic nonequilibrium steady states, EPL 82 (3) (2008) 30003.
- [28] T. R. Gingrich, J. M. Horowitz, N. Perunov, J. L. England, Dissipation bounds all steady-state current fluctuations, Phys. Rev. Lett. 116 (2016) 120601.
- [29] P. Pietzonka, A. C. Barato, U. Seifert, Universal bounds on current fluctuations, Phys. Rev. E 93 (2016) 052145.
- [30] T. R. Gingrich, G. M. Rotskoff, J. M. Horowitz, Inferring dissipation from current fluctuations, J. Phys. A: Math. Theor. 50 (18) (2017) 184004.
- [31] J. P. Garrahan, Simple bounds on fluctuations and uncertainty relations for first-passage times of counting observables, Phys. Rev. E 95 (2017) 032134.
- [32] P. Pietzonka, F. Ritort, U. Seifert, Finite-time generalization of the thermodynamic uncertainty relation, Phys. Rev. E 96 (2017) 012101.
- [33] P. Pietzonka, A. C. Barato, U. Seifert, Universal bound on the efficiency of molecular motors, J. Stat. Mech.: Theor. Exp. (12) (2016) 124004.
- [34] K. Visscher, M. Schnitzer, S. M. Block, Single kinesin molecules studied with a molecular force clamp, Nature 400 (1999) 184–189.
- [35] P. Pietzonka, A. C. Barato, U. Seifert, Affinity- and topology-dependent bound on current fluctuations, J. Phys. A: Math. Theor. 49 (34) (2016) 34LT01.
- [36] A. C. Barato, U. Seifert, Cost and precision of Brownian clocks, Phys. Rev. X 6 (2016) 041053.
- [37] G. M. Rotskoff, Mapping current fluctuations of stochastic pumps to nonequilibrium steady states, Phys. Rev. E 95 (2017) 030101.
- [38] A. C. Barato, U. Seifert, Thermodynamic cost of external control, arxiv: 1704.03480.
- [39] A. C. Barato, U. Seifert, Universal bound on the Fano factor in enzyme kinetics, J. Phys. Chem. B 119 (22) (2015) 6555–6561.

- [40] A. Alemany, M. Ribezzi-Crivellari, F. Ritort, From free energy measurements to thermodynamic inference in nonequilibrium small systems, New J. Phys. 17 (7) (2015) 075009.
- [41] P. Pietzonka, U. Seifert, Universal trade-off between power, efficiency and constancy in steady-state heat engines, arxiv: 1705.05817.