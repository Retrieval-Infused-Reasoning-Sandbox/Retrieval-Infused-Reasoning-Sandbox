### *Introduction to:*

#### Free Energy of a Nonuniform System. I. Interfacial Free Energy

*and* 

# Free Energy of a Nonuniform System. III. Nucleation in a Two-Component Incompressible Fluid

*by* 

# John W. Cahn and John E. Hilliard

The two elegant pioneering papers that follow, informally known as Cahn-Hillard I [1] and III [2] and hereafter referred to by number, develop respectively the foundation of the theory of diffuse interfaces and the application of this theory to deduce the properties of a critical nucleus. Both treatments are based on thermodynamics and on a continuum description that assumes any variations of intensive variables (e.g. concentration) are gradual on an atomic scale. Paper II [3] in the series is by Cahn alone and shows that the foundation of the Cahn-Hillard treatment is equivalent to the thermodynamic formulation of Hart [4] published after I.

The two papers I and III were written in a collaboration that formed shortly after the two young men joined the General Electric Laboratory in Schenectady, New York. The papers represented a major challenge to and advance over the then orthodoxy of the thermodynamics of surfaces and solutions and nucleation theory and they were not without controversy [5-8]. The papers have had a profound impact on materials science over the years. There have been 1358 citations to I in the period from 1974 to the present (April 1998). On a personal note, I had the pleasure of guiding an analysis and discussion of the papers in a graduate seminar on seminal literature in materials science that I taught for several years at Carnegie Mellon. They are discussed here in turn.

Paper I is cast in terms of an isothermal binary solution of constant molar density with a miscibility gap and is based on the assumption that the free energy density of the solution is a function of both the concentration (of either species) and the spatial derivatives of the concentration considered as independent variables. Physically, an atom is assumed to sense a concentration gradient through the directional dependence of the probability that a neighboring atom is a given type. Formally, expansion of the free energy density in a Taylor series of the concentration and its derivatives, utilization of symmetry arguments for cubic crystals and integration over the system result in the famous expression given by Eq. 2.6 of I (or 2.1 of III). These equations express the total free energy *F* as an integral over the volume of the system of the sum of two terms: a term /(c) corresponding to the free energy density of a homogeneous system of concentration c and a term proportional to the square of the gradient of c corresponding to the energy penalty associated with concentration inhomogeneities; the coefficient *κ* of this gradient term is assumed positive and requires an atomistic model for its evaluation.

Paper I proceeds by applying Eq. 2.6 to an equilibrium system, with a mean concentration inside the miscibility gap, consisting of two phases separated by a planar interface. The calculus of variations is used to find a formal expression for both the spatial concentration profile that minimizes *F* and the resulting free energy *σ* of the interface which turns out to be isotropic under the assumed conditions. The

The following two papers are reprinted from these sources:

*The journal of Chemical Physics,* Vol. 28, No. 2, Feb. 1958, "Free Energy of a Nonuniform System. I. Interfacial Free Energy" by John W. Cahn and John E. Hilliard, pages 258-267, with permission from American Institute of Physics.

*The journal of Chemical Physics,* Vol. 31, No. 3, Sept. 1959, "Free Energy of a Nonuniform System. III. Nucleation in a Two-Component Incompressible Fluid" by John W. Cahn and John E. Hilliard, pages 688-699, with permission from American Institute of Physics.

The Selected Works of John W. Cahn Edited by W.C. Carter and W.C. Johnson The Minerals, Metals & Materials Society, 1998

minimizing solution is determined by a competition between the two terms of Eq. 2.6: the first term favors a narrow interface, since the range of concentrations therein lie in the high energy miscibility gap, whereas the second term favors a wide or diffuse interface associated with a small gradient.

To make further progress, two lines of investigation are pursued. First, additional formal results are obtained by expanding /o about the critical point *(cc,Tc)* of a symmetric miscibility gap to obtain the double-well form for / <sup>0</sup> , discussed earlier by Landau [9], and a parabolic coexistence curve. Wide interfaces with low energy can be expected near the critical point since the free energy penalty for concentrations within the miscibility gap tends to zero as the point is approached. Explicit expressions are obtained that predict that as Δ = (Tc - Γ) -> 0, the interface width diverges to infinity as (ΔΓ) with n = 0.5 and *σ*  goes to zero as (AT) m with *m =* 1.5. These values are modified by the modern theory of critical exponents as discussed below.

Second, a model for a non-uniform regular solution is developed that allows an explicit evaluation of both / and *κ* in Eq. 2.6 in terms of the regular solution parameters. The results are then applied to a liquid/vapor system by adopting the binary molecule/hole model of a liquid and the 6-12 Lennard-Jones potential to obtain the absolute values of σ in terms of the Tc and the molar volume for several elements in the liquid state showing good agreement with experiment.

In paper III, Cahn and Hilliard investigate the properties of a critical nucleus using the theory of an inhomogeneous solution developed in I. They consider the same two component system with a miscibility gap but now assume a non-equilibrium initial condition consisting of a uniform concentration, Co, that lies between the phase boundary concentration, *ca,* and the spinodal boundary concentration *cs* so that nucleation is required for the decomposition of the solution. Since the critical nucleus must be in unstable equilibrium (at the saddle point configuration), it is defined by the (radial) concentration profile *c(r)* that minimizes Eq. 2.1 subject to boundary conditions appropriate to the problem. Again, the calculus of variations yields formal expressions for both the minimizing profile *c(r)* and the corresponding critical energy *W* in terms of a given /(c, Γ) and *κ.* There is no need to model the nucleus as homogeneous (which it is not), nor to introduce the artificial dividing surface of Gibbs nor to define a separate interfacial energy.

The rest of paper III explores the general properties of the critical nucleus and then the form the results take for several limiting and special cases. It is shown that as *CQ* approaches *ca,* the classical description is recovered in which *σ* is given by the flat interface expression derived in I and the interface thickness is small compared to the nucleus size. On the other hand, as *Co* approaches c, Cahn and Hilliard state [2] that "all resemblance to a classical nucleus is lost". Thus *W* is shown to go to zero, the nucleus to be inhomogeneous everywhere, c at the nucleus center to go to *Co* — *cs* and, surprisingly, the effective radius again to go to infinity. The latter means that there is a minimum radius for a value of Co between *ca* and cs. The vanishing of *W* as the mean concentration approaches the spinodal concentration *cs* contrasts with the finite value predicted by classical theories in which the nucleus concentration profile is constrained. It establishes a continuity with the decomposition of the binary solution within the spinodal boundary for which no nucleation is required.

Cahn and Hilliard give a good account of relevant previous work, known to them at the time, including the work of Ono [12] and that of Hillert [13] who gave a discrete one dimensional treatment of the problem considered in I, using difference equations, and also gave a discussion of nucleation using the discrete model in his thesis which Cahn and Hilliard acknowledge as having stimulated their work. The analogy of the problem in I to that of a Bloch domain wall [14] is also mentioned.

Two important papers, predating I, developed theories that are fundamentally equivalent to that developed in I. First was that of van der Waals [15] who developed a continuum thermodynamic gradient theory for a fluid/fluid interface, originally published in Dutch in 1893; it was translated into German by Ostwald in 1894 [16], into French anonymously in 1895 [17] and finally into English by Rowlinson in 1979 [18]. The development of van der Waals was expressed in terms of the fluid density as an order parameter. Second was the paper of Ginsburg and Landau [19] who developed a phenomenological theory of type II superconductors in 1950 that used an order parameter proportional to the density of superconducting electrons to express the free energy density of a superconductor in terms of a Landau expansion in this parameter plus a coefficient times the spatial gradient of the parameter squared [20,21]; formally, the results are equivalent to those of Cahn and Hilliard.

The theories of van der Waals, Landau and Ginsburg and Cahn and Hilliard are all mean field theories that do not properly incorporate the contributions of fluctuations to the equilibrium state. These fluctuations become increasingly important as the critical point is approached and modify the values of the critical exponents *n* and m defined above. The values given by renormalization group calculations [10,11] are *n* = 0.63 and *m* = 1.28 (rather than the mean field values of 0.50 and 1.5, respectively) in good agreement with experiment. Further, the coexistence curve in the vicinity of the critical point is predicted to be described by (ΔΤ) <sup>6</sup> with *b =* 0.325 rather than the parabolic form obtained in I. Nevertheless, the mean field theories predict the correct qualitative behavior of a system near the critical point, give very

good values for the surface energy *σ* and provide a powerful framework for physical insight and reasoning.

If the system is not sufficiently near the critical point, the interface may be too narrow to justify the continuum assumption of I and **III** and the other mean field theories. For crystals, recourse may then be had to lattice discrete theories [22-24] following and generalizing Hillert's discrete description of the thermodynamics of inhomogeneous solutions [13,25]. Lattice discrete theories, both in real and Fourier space, are also able to deal with atomic-scale ordering reactions [24].

Fundamental work that is an outgrowth of the foundation developed in I includes the pioneering work of Cahn on wetting [26,27] and on the development of a spinodal diffusion equation which is connected to I as follows: although I (and **III)** contain no kinetics, Eq. 2.6 suggests that the effective driving force for diffusion in a non-equilibrium system must include the effect of the gradient energy. By defining an effective diffusion potential to be the functional derivative of *F* in Eq. 2.6, Cahn [28,29] derived a flux equation (including the effect of elastic strain-energy) and then, with the use of the continuity equation, a diffusion equation that describes the thermodynamics of spinodal decomposition. This topic is discussed later in this volume and the modifications of the Cahn theory required by statistical mechanics are discussed in [30].

Similarly, a complete theory of nucleation must incorporate an activation energy, as obtained in **III,**  into a kinetic description expressing the temporal and spatial frequency of the critical fluctuation. This synthesis has been discussed from a statistical mechanical viewpoint in [31] and nucleation theory in relation to **III** and to experiment has been reviewed in [32] and [33].

Finally, it should be mentioned that the spinodal diffusion equation that is an outgrowth of paper I, together with the Allen-Cahn equation [34] for a non-conserved parameter, form the basis for the phase field method, attributed to Langer, for describing the evolution of the morphology of a system undergoing a phase transformation. The great advantage of this method [35] is that the same equations hold everywhere as is the case for the free energy density used in I and **III.** There is no need to define, treat separately and track the time dependent position of a phase boundary which, in the phase field method, is simply manifest as a narrow diffuse layer between the two phases.

Acknowledgments: Gratitude is expressed to Prof. D. Jasnow for helpful discussion and comments. Also appreciation is expressed to Angela Locknar for the citation data.

William W. Mullins Carnegie Mellon University

#### References

- [1 J.W. Cahn and J.E. Hilliard, J. Chem. Phys., 28, 258 (1958).
- [2 J.W. Cahn and J.E. Hilliard, J. Chem. Phys., 31, 688 (1959).
- **[3:**  J.W. Cahn, J. Chem. Phys., 30, 1121 (1959).
- **[4;**  E.W. Hart, Phys. Rev., **113,** 412 (1959).
- [5 W.A. Tiller, CM . Pound and J.P. Hirth, Acta Met.. 18, 225 (1970).
- **[e:**  J.P. Hirth, W.A. Tiller and G.M. Pound, Phil. Mag., 22, 117 (1970).
- **[7:**  J.W. Cahn and J.E. Hilliard, Acta Met.. 19, 151 (1971).
- **[β:**  W.A. Tiller, G.M. Pound and J.P. Hirth, Acta Met.. 19, 475 (1971).
- [9 L.D. Landau, Collected Papers of L.D. Landau, Ed. D. Ter Haar, Pergamon Press (1965), p. 193.
- [io; D. Jasnow, Reports on Progress in Physics, 47, 1059 (1984).
- [11 D. Jasnow, Phase Transitions and Critical Phenomena 10, Eds. C. Domb and J.L. Lebowitz, Academic Press, N. Y. (1986), p. 269.
- [12: S. Ono, Mem. Fac. Eng. Kyushu Univ., 10, 195 (1947).
- [13: M. Hillert, D.Sc. Dissertation, Massachusetts Institute of Technology, Cambridge (1956).
- [14 F. Bloch, Z. Physik, 74, 295 (1932).
- [15: J.D. van der Waals, Verhandel. Konink. Acad. Weten. Amsterdam, Sect. 1, Vol. 1, No. 8 (1893).

- 16] J.D. van der Waals, Z. Phys. Chem., 13, 657 (1894).
- 17] J.D. van der Waals, Arch. Nerl., 28, 121 (1895).
- 18] J.S. Rowlinson, J. Stat. Phys., **20,** 200 (1979).
- 19] V.L. Ginsburg and L.D. Landau, J. Exptl. Theoret. Phys. (USSR), **20,** 1064 (1950).
- 20] M. Tinkham, Introduction to Superconductivity, McGraw Hill, New York (1975).
- 21] M.E. McHenry and R.A. Sutton, Prog. Mater. Sei., 38, 159 (1994).
- 22] Y.W. Lee and H.I. Aaronson, Acta Met., 28, 539 (1980).
- ;23] H.E. Cook , D. de Fontaine and J.E. Hilliard, Acta Met., 17, 765 (1969).
- [24] D. de Fontaine, Solid State Physics, **34,** 73 (1979).
- [25] M. Hillert, Acta Met., 9, 525 (1961).
- [26] J.W. Cahn, J. Chem. Phys., 66, 3667 (1977).
- [27] M. Moldover and J.W. Cahn, Science, **207,** 1073 (1980).
- [28] J.W. Cahn, Acta Met., 9, 795 (1961).
- [29] J.W. Cahn, Trans. AIME, **242,** 166 (1968).
- [30] J.S. Langer, Acta Met., 21 , 1649 (1973).
- [31] J.S. Langer, Ann. Phys., 54, 258 (1969).
- [32] H.I. Aaronson and K.C. Russell, Proc. Int. Conf. Solid/Solid Phase Trans., TMS, Warrendale PA. (1982), p. 371.
- [33] H.I. Aaronson and F.K. LeGoues, Metall. Trans., **23A,** 1915 (1992).
- [34] S.M. Allen and J.W. Cahn, Acta Met., **27,** 1085 (1979).
- [35] Y. Wang and L.Q. Chen, JOM, 48, 13 (1996).