## Macroscopic stochastic thermodynamics

Gianmaria Falasco[∗](#page-0-0)

Department of Physics and Astronomy, University of Padova, Via Marzolo 8, I-35131 Padova, Italy.

Massimiliano Esposito[†](#page-0-1)

Complex Systems and Statistical Mechanics, Department of Physics and Materials Science, University of Luxembourg, L-1511 Luxembourg, Luxembourg

Starting at the mesoscopic level with a general formulation of stochastic thermodynamics in terms of Markov jump processes, we identify the scaling conditions that ensure the emergence of a (typically nonlinear) deterministic dynamics and an extensive thermodynamics at the macroscopic level. We then use large deviations theory to build a macroscopic fluctuation theory around this deterministic behavior, which we show preserves the fluctuation theorem. For many systems (e.g. chemical reaction networks, electronic circuits, Potts models), this theory does not coincide with Langevin-equation approaches (obtained by adding Gaussian white noise to the deterministic dynamics) which, if used, are thermodynamically inconsistent. Einstein-Onsager theory of Gaussian fluctuations and irreversible thermodynamics are recovered at equilibrium and close to it, respectively. Far from equilibirum, the free energy is replaced by the dynamically generated quasi-potential (or self-information) which is a Lyapunov function for the macroscopic dynamics. Remarkably, thermodynamics connects the dissipation along deterministic and escape trajectories to the Freidlin-Wentzell quasi-potential, thus constraining the transition rates between attractors induced by rare fluctuations. A coherent perspective on minimum and maximum entropy production principles is also provided. For systems that admit a continuous-space limit, we derive a nonequilibrium fluctuating field theory with its associated thermodynamics. Finally, we coarse grain the macroscopic stochastic dynamics into a Markov jump process describing transitions among deterministic attractors and formulate the stochastic thermodynamics emerging from it.

## CONTENTS

|  | I. Introduction                                 | 2  |
|--|-------------------------------------------------|----|
|  | A. The challenge                                | 2  |
|  | B. What we achieve                              | 3  |
|  | C. Plan of the paper                            | 4  |
|  | II. Stochastic Thermodynamics                   | 5  |
|  | III. Macroscopic limit                          | 8  |
|  | A. Thermodynamic and kinetic conditions         | 8  |
|  | B. Deterministic dynamics                       | 9  |
|  | C. Multistability vs metastability              | 10 |
|  | D. Deterministic thermodynamics                 | 11 |
|  | E. Drift field decomposition                    | 12 |
|  | F. Linearized dynamics and thermodynamics       | 13 |
|  | IV. Macroscopic fluctuations                    | 15 |
|  | A. Dynamics of the state variable               | 15 |
|  | B. Fluctuating Thermodynamics                   | 16 |
|  | C. Gaussian fluctuations                        | 17 |
|  | D. Truncation of the Kramers-Moyal expansion    | 18 |
|  | E. Informational entropy production of Langevin |    |
|  | equations                                       | 18 |
|  | F. Nonreciprocity                               | 19 |
|  | G. Irreversibility of relaxation and instanton  | 20 |
|  |                                                 |    |

|  | H. Thermodynamic constraints on transition rates    |    |
|--|-----------------------------------------------------|----|
|  | between attractors                                  | 20 |
|  | I. Macroscopic time-integrated observables and      |    |
|  | fluctuation theorems                                | 22 |
|  | 1. Entropy production at steady state               | 23 |
|  | 2. Transition currents at steady state              | 24 |
|  | 3. Fluctuation theorems from dual dynamics          | 24 |
|  | V. Macroscopic field theory                         | 25 |
|  | A. Continuous-space limit: dynamics                 | 25 |
|  | B. Continuous-space limit: entropy production       | 27 |
|  | VI. Emergent stochastic thermodynamics              | 28 |
|  | VII. Applications                                   | 30 |
|  | A. Chemical reaction networks                       | 30 |
|  | 1. Dissipative metastability: Schlögel model        | 31 |
|  | 2. Entropy production in a limit cycle: Brusselator |    |
|  | model                                               | 33 |
|  | B. Electronic systems                               | 33 |
|  | 1. Dissipative logical states: CMOS SRAM cell       | 35 |
|  | C. Driven Potts models                              | 36 |
|  | VIII. Discussion                                    | 39 |
|  | A. Critical summary                                 | 39 |
|  | B. Outlook                                          | 40 |
|  | 1. Thermodynamic uncertainty relations              | 40 |
|  | 2. Phase transitions                                | 41 |
|  | 3. Finite size effects                              | 42 |
|  | 4. Odd-parity variables and quantum systems         | 43 |
|  | 5. Response theory                                  | 43 |
|  | 6. Phenomenological laws                            | 43 |

<span id="page-0-0"></span><sup>∗</sup> [gianmaria.falasco@unipd.it](mailto:gianmaria.falasco@unipd.it)

<span id="page-0-1"></span><sup>†</sup> [massimiliano.esposito@uni.lu](mailto:massimiliano.esposito@uni.lu)

References [44](#page-43-0)

- A. Derivation of the entropic upper bound on the transition rates [49](#page-48-0)
- B. Derivation of the emerging transition rates [50](#page-49-0)

## <span id="page-1-0"></span>I. INTRODUCTION

## <span id="page-1-1"></span>A. The challenge

Thermodynamics is a theory describing energy transfers among systems and energy transformations from one form into another. It constitutes a remarkable scientific achievement which started more than three centuries ago with the study of vacuum pumps. During the 19th century its developments were spectacular and instrumental to master the technology of steam engines that literally powered the industrial revolution. In its traditional formulation thermodynamics applies to macroscopic systems at thermodynamic equilibrium. The microscopic foundation of the theory, statistical mechanics, was established during the late 19th and early 20th century. It explains how the observed macroscopic behavior results from very large numbers of microscopic degrees of freedom giving rise to sharply peaked probability distributions. The 20th century witnessed the first development of irreversible thermodynamics to explain transport phenomena, which is based on the assumption that the bulk properties of macroscopic systems remain close to thermodynamic equilibrium [\(de Groot and Mazur,](#page-45-0) [1984;](#page-45-0) [Prigogine,](#page-47-0) [1961\)](#page-47-0).

Since the end of the 20th century, a statistical formulation of nonequilibrium thermodynamics, called stochastic thermodynamics (ST), was established to describe small fluctuating systems [\(Van den Broeck and Esposito,](#page-43-1) [2015;](#page-43-1) [Gaspard,](#page-45-1) [2022;](#page-45-1) [Peliti and Pigolotti,](#page-47-1) [2021;](#page-47-1) [Seifert,](#page-47-2) [2012;](#page-47-2) [Shiraishi,](#page-47-3) [2023\)](#page-47-3). In its general formulation [\(Rao and](#page-47-4) [Esposito,](#page-47-4) [2018b\)](#page-47-4), ST constructs thermodynamic observables (e.g. heat, work, dissipation) on top of the stochastic dynamics of open systems. The key assumption is that all the degrees of freedom which are not explicitly described by the dynamics – i.e. the internal structure of the system states and the reservoirs – must be at equilibrium. The link between observables and dynamics is then provided by the local detailed balance property [\(Bauer and Cornu,](#page-43-2) [2014;](#page-43-2) [Bergmann and Lebowitz,](#page-43-3) [1955;](#page-43-3) [Esposito,](#page-44-0) [2012;](#page-44-0) [Falasco and Esposito,](#page-44-1) [2021;](#page-44-1) [Maes,](#page-46-0) [2021\)](#page-46-0): when an elementary process (e.g. an elementary chemical reaction) induces a transition between two states (e.g. the number of molecules before and after the reaction), the Boltzmann constant k<sup>B</sup> times the log ratio of the forward and backward current of that process between the two states is the entropy production (or dissipation) of the process, i.e. the sum of the entropy changes in the environment and in the system. The successes of

ST over recent years have been impressive both theoretically and experimentally. Since the theory predicts the temporal changes of thermodynamic quantities, it can be used to address typical finite-time thermodynamics questions such as identifying optimal driving protocols leading to maximum power extraction [\(Benenti](#page-43-4) et al., [2017;](#page-43-4) [Seifert,](#page-47-2) [2012\)](#page-47-2). Driven colloidal particles, molecular motors, Brownian ratchets and electrical circuits have for instance been considered [\(Blickle](#page-43-5) et al., [2006;](#page-43-5) [Brown and](#page-43-6) [Sivak,](#page-43-6) [2020;](#page-43-6) [Ciliberto,](#page-44-2) [2017;](#page-44-2) Mehl [et al.](#page-46-1), [2012;](#page-46-1) [Pekola,](#page-47-5) [2015\)](#page-47-5). ST also predicts the nonequilibrium fluctuations of thermodynamic observables. The central discovery of the field is the fluctuation theorem asserting that the probability to observe a given positive dissipation is exponentially larger than the probability of its negative counterpart [\(Gaspard,](#page-45-1) [2022;](#page-45-1) [Jarzynski,](#page-46-2) [2011;](#page-46-2) [Rao and](#page-47-6) [Esposito,](#page-47-6) [2018c;](#page-47-6) [Seifert,](#page-47-2) [2012\)](#page-47-2). This relation generalizes the second law, which only states that on average the dissipation cannot decrease. Previous results such as Onsager reciprocity relations or fluctuation-dissipation relations can be recovered from it. ST also provides very natural connections with information theory [\(Wolpert,](#page-48-1) [2019\)](#page-48-1): The system entropy contains a Shannon entropy contribution; dissipation can be expressed as a Kullback-Leibler entropy quantifying how different probabilities of forward trajectories are from their time-reversed counterpart; the difference between the nonequilibrium and equilibrium thermodynamic potential takes the form of a Kullback-Leibler entropy between the system nonequilibrium and equilibrium probability distributions. These results provide a rigorous ground to assess, both theoretically [\(Horowitz and Esposito,](#page-45-2) [2014;](#page-45-2) [Parrondo](#page-47-7) et al., [2015\)](#page-47-7) and experimentally [\(Bérut](#page-43-7) et al., [2012;](#page-43-7) Jun [et al.](#page-46-3), [2014;](#page-46-3) [Koski](#page-46-4) et al., [2015;](#page-46-4) [Toyabe](#page-48-2) et al., [2010\)](#page-48-2), the cost of various information processing operations such as Landauer erasure or Maxwell's demons. More recently, ST has also been used to show that dissipation sets universal bounds – called thermodynamic uncertainty relations and speed limits – on the precision [\(Barato and Seifert,](#page-43-8) [2015;](#page-43-8) [Falasco](#page-44-3) et al., [2020;](#page-44-3) [Horowitz and Gingrich,](#page-45-3) [2020\)](#page-45-3) as well as on the duration [\(Falasco and Esposito,](#page-44-4) [2020;](#page-44-4) [Shiraishi](#page-47-8) et al., [2018;](#page-47-8) [Van Vu and Saito,](#page-48-3) [2023a;](#page-48-3) Vo [et al.](#page-48-4), [2020\)](#page-48-4) of nonequilibrium processes.

Despite these remarkable achievements, the focus of ST has been the study of small and simple systems farfrom-equilibrium, and important questions remain open when considering larger and more complex systems. In particular, (i) What happens in the thermodynamic limit of ST? (ii) How should ST be modified when detailed balance is broken? These questions remain poorly explored except for specific model-systems studies.

(i) More specifically, what happens when considering systems whose number of degrees of freedom becomes very large? Can one derive from ST a macroscopic thermodynamics valid far away from equilibrium and connect it close-to-equilibrium to irreversible thermodynamics? These general questions remain largely unanswered. This is surprising given that a motivation for the early developments [\(Harada and Sasa,](#page-45-4) [2005;](#page-45-4) [Hatano and Sasa,](#page-45-5) [2001;](#page-45-5) [Sekimoto,](#page-47-9) [2010\)](#page-47-9) that led to the present form of ST was the derivation of a nonequilibrium version of traditional thermodynamics [\(Keizer,](#page-46-5) [1978;](#page-46-5) [Oono and Pani](#page-47-10)[coni,](#page-47-10) [1998\)](#page-47-10). In recent years, only specific classes of systems that exhibit a macroscopic limit have been considered, such as chemical reaction networks [\(Avanzini](#page-43-9) et al., [2021;](#page-43-9) [Falasco](#page-44-5) et al., [2019,](#page-44-5) [2018;](#page-44-6) [Rao and Esposito,](#page-47-11) [2016\)](#page-47-11), electronic circuits [\(Freitas](#page-44-7) et al., [2020,](#page-44-7) [2021a\)](#page-44-8), and meanfield Ising and Potts models [\(Herpich](#page-45-6) et al., [2020a;](#page-45-6) [Her](#page-45-7)[pich and Esposito,](#page-45-7) [2019;](#page-45-7) [Herpich](#page-45-8) et al., [2018a\)](#page-45-8). These results suggest that for these macroscopic systems, one can derive not only a deterministic formulation of nonequilibrium thermodynamics, but also – with the help of large deviations theory [\(Touchette,](#page-48-5) [2009\)](#page-48-5) – a theory of macroscopic fluctuations around the deterministic behavior, similar in spirit to the one valid for diffusive systems [\(Bertini](#page-43-10) et al., [2015\)](#page-43-10). Importantly, the macroscopic fluctuation theories derived for most of the model systems studied are incompatible with a naive approach consisting of adding Gaussian white noise to the deterministic dynamics. A general theory is needed to clarify these crucial questions.

(ii) Most dynamics used to describe complex phenomena are highly coarse-grained and do not resolve all the out-of-equilibrium degrees of freedom, thus compromising the detailed balance assumption essential to build a consistent ST. This situation is ubiquitous in active and biological systems, for instance [\(Bechinger](#page-43-11) et al., [2016;](#page-43-11) [Marchetti](#page-46-6) et al., [2013\)](#page-46-6). While the dynamics of some motile cells can be modeled by active Brownian dynamics [\(Fodor](#page-44-9) et al., [2016\)](#page-44-9), their energetic cost cannot be deduced from the motion of the cells alone as a large number of hidden sub-cellular processes are also dissipating energy. The practical relevance of a thermodynamics of complex systems is huge. It is necessary to address question such as: To what extend are biology and ecology shaped by the energy flows sustaining them [\(Garvey](#page-45-9) [and Whiles,](#page-45-9) [2016;](#page-45-9) Yang [et al.](#page-48-6), [2021\)](#page-48-6)? What are energy efficient design principles for information, computation and communication technologies [\(Auffèves,](#page-43-12) [2022;](#page-43-12) [Lange](#page-46-7) [et al.](#page-46-7), [2020;](#page-46-7) [Wolpert](#page-48-7) et al., [2019\)](#page-48-7)?

A crucial difference between these complex systems and those typically considered in irreversible thermodynamics is that the nonequilibrium constrains or thermodynamic driving forces are not only imposed at the boundaries of the system but throughout the system itself. In biology, for instance, the energy input is chemical (e.g. from ATP hydrolysis) and arises at the molecular scale. This fact a priori jeopardizes notions of equilibrium used to build traditional macroscopic fluctuation theories [\(Bertini](#page-43-10) et al., [2015;](#page-43-10) [De Zarate and Sengers,](#page-44-10) [2006\)](#page-44-10). Despite much ongoing work on coarse-graining stochastic dynamics [\(Bo and Celani,](#page-43-13) [2014,](#page-43-13) [2017;](#page-43-14) [Espos-](#page-44-0) [ito,](#page-44-0) [2012;](#page-44-0) [Esposito and Parrondo,](#page-44-11) [2015;](#page-44-11) [Herpich](#page-45-10) et al., [2020b;](#page-45-10) [Maes,](#page-46-8) [2020;](#page-46-8) [Polettini and Esposito,](#page-47-12) [2017;](#page-47-12) [Puglisi](#page-47-13) [et al.](#page-47-13), [2010;](#page-47-13) [Rahav and Jarzynski,](#page-47-14) [2007;](#page-47-14) [Strasberg and](#page-47-15) [Esposito,](#page-47-15) [2019\)](#page-47-15), beside few exceptions in simple models [\(Bebon](#page-43-15) et al., [2024;](#page-43-15) [Pietzonka and Seifert,](#page-47-16) [2017;](#page-47-16) [Speck,](#page-47-17) [2022\)](#page-47-17) and in the linear regime [\(Gaspard and Kapral,](#page-45-11) [2020\)](#page-45-11), little is known about how to establish a thermodynamically consistent theory of active systems, in particular at a macroscopic level where nonequilibrium field theoretical descriptions (formulated in physical space) would be very useful.

## <span id="page-2-0"></span>B. What we achieve

Starting from a general formulation of ST, we identify the scaling conditions ensuring that a deterministic (typically nonlinear) dynamics and a corresponding extensive thermodynamics emerge in the macroscopic limit. We find that the same conditions ensure the validity of a thermodynamically consistent macroscopic fluctuation theory – based on large deviations theory – describing fluctuations around the deterministic behavior. The importance of these results is manifold. First, ST is proved to be compatible with macroscopic thermodynamics and equilibrium statistical mechanics, thus resolving some controversy concerning the definition of entropy on the basis of information theory [\(Gold](#page-45-12)stein [et al.](#page-45-12), [2019\)](#page-45-12). Second, irreversible thermodynamics and the Einstein-Onsager theory of small fluctuations [\(Henkel,](#page-45-13) [2017;](#page-45-13) [Landau and Lifshitz,](#page-46-9) [1959;](#page-46-9) [Rytov,](#page-47-18) [1958;](#page-47-18) [Rytov](#page-47-19) et al., [1989;](#page-47-19) [de Zárate and Sengers,](#page-48-8) [2006\)](#page-48-8) are derived from our unified framework for close-to-equilibrium conditions, thus providing a more microscopic foundation to these two originally phenomenological theories. Third, we explain how thermodynamic quantities shape the far-from-equilibrium behavior, both the deterministic relaxation and the exponentially (in the system size) rare fluctuations. By doing so, we manage to connect Freidlin–Wentzell theory of large deviations [\(Frei](#page-44-12)[dlin and Wentzell,](#page-44-12) [1998;](#page-44-12) [Graham,](#page-45-14) [1987\)](#page-45-14) to thermodynamics. This allows us to retrieve the minimum entropy production principle close to equilibrium, relate the lifetime of nonequilibrium metastable states to dissipation, and rigorously discuss a maximum entropy production principle. Fourth, we identify the pitfalls of commonly used approximations (e.g. nonlinear Langevin equations with multiplicative noise [\(Gillespie,](#page-45-15) [2000\)](#page-45-15)) and offer as a result a systematic framework to derive thermodynamic consistent fluctuating field theories, e.g. for active matter. Finally, we show that ST allows one to perform a physically-motivated coarse graining tailored to reveal emergent states and transitions between them in complex nonequilibrium systems.

## <span id="page-3-0"></span>C. Plan of the paper

In Sec. [II](#page-4-0) we introduce the dynamical description of the systems, based on the classical master equation for occupation-like variables, e.g. the number of particles in the physical space, of electrons on a conductor, of spins with a certain orientation, or of excitations in some mode space. At such level of description, which we called mesoscopic, all unresolved degrees of freedom (internal and environmental) are assumed to be thermalized. Detailed balance thus ensues, allowing us to introduce a complete thermodynamic superstructure, given by standard ST, which we briefly recapitulate.

We then introduce the macroscopic limit in Sec. [III.A,](#page-7-1) akin to a nonequilibrium thermodynamic limit. We derive the conditions on the transition rate and thermodynamic forces of the mesoscopic dynamics that ensure asymptotically a deterministic dynamics (Sec. [III.B\)](#page-8-0) and an extensive thermodynamics (Sec. [III.D\)](#page-10-0). Large deviations theory, the appropriate language to describe the concentration of probability in the macroscopic limit, is utilized. Thanks to it we explain that the macroscopic entropy of a system is independent of the probability distribution at the mesoscopic level and only made up of the internal entropy of the mesoscopic states. We link the phenomenon of dissipative metastability in the stochastic dynamics with the ergodicity breaking and multistability of the macroscopic deterministic dynamics (Sec. [III.C\)](#page-9-0). In Sec. [III.E](#page-11-0) we consider the macroscopic nonlinear dynamics, identifying the weak-noise quasi-potential as the Lyapunov function and connecting it to thermodynamics. We split the deterministic relaxation in its gradient part and the nonequilibrium circulation due to state-space probability currents (see Fig. [1\)](#page-3-1). In Sec. [III.F](#page-12-0) we examine the linear deterministic relaxation close to nonequilibrium fixed points. Close to equilibrium we retrieve linear irreversible thermodynamics and the minimum entropy production principle.

Next, we obtain in Sec. [IV.A](#page-14-1) the macroscopic fluctuations from the extremum action principle. In Sec. [IV.B](#page-15-0) we formulate the thermodynamics along macroscopic fluctuating trajectories, deriving an emergent second law and connecting the quasi-potential to dissipation close to equilibrium. We focus on the asymptotic form of both small Gaussian fluctuations and rare large ones. The former are described by linear Langevin equations that reduce to the Onsager-Machlup theory at equilibrium (Sec. [IV.C\)](#page-16-0). We highlight the failure in capturing the rare events (Sec. [IV.D\)](#page-17-0) and the thermodynamics (Sec. [IV.E\)](#page-17-1) of the unsystematic truncation of the mesoscopic master equation that gives rise to a nonlinear Langevin equation with multiplicative noise. In Sec. [IV.G](#page-19-0) we quantify the time-reversal asymmetry between relaxation path within an attractor and the escape path out of it (called instanton). Also, the likelihood of rare large fluctuations, encoded into the quasi-potential, al-

![](_page_3_Picture_5.jpeg)

FIG. 1 Sketch of the different levels of description emerging with growing size V and time scale τ . The mesoscopic level (bottom) consists of a Markov jump process in discrete space n that enjoys local detailed balance. For large V the dynamics of the intensive variable c = n/V is dictated by the quasipotential Iss and the nonconservative drift vss (middle). For large τ the dynamics reduces again to a Markov jump process on the space of the attractors, regarded as emergent states with internal dissipation (top).

<span id="page-3-1"></span>lows us to quantify the transition rate out of a basin of attraction. For them we derive in Sec. [IV.H](#page-19-1) upper and lower bounds in terms of the entropy produced in relaxation and escape trajectories – which constitute a novel maximum entropy production principle under certain conditions. In Sec. [IV.I](#page-21-0) we discuss the asymptotic full counting statistics of thermodynamic currents and the fluctuation theorems showing how the multiplicative Gaussian noise approximations break them.

In Sec. [V.A](#page-24-1) we consider a continuous-space limit, making contact with macroscopic fluctuation theory. We explain how fluxes become linear functions of the thermodynamic forces and the notion of local equilibrium appears. The associated thermodynamics is discussed in Sec. [V.B,](#page-26-0) showing that the continuous-space limit of the mesoscopic entropy production differs from the apparent one defined in configuration space only, unless all processes are diffusive.

In Sec. [VI](#page-27-0) we formulate ST for the long-time jump dynamics between attractors. This provides a natural way to coarse-grain the original system into emergent states sustained by an internal dissipation. We discuss the conditions of the underlying mesoscopic dynamics required to obtain the standard form of ST for this emergent jump process (see Fig. 1).

In Sec. VII we provide examples of the general theory, including chemical reaction networks, electronic circuits and driven Potts models. In Sec. VIII we conclude by discussing the strength of our framework, its limitations, and open issues.

## <span id="page-4-0"></span>II. STOCHASTIC THERMODYNAMICS

We consider a small system in contact with several reservoirs, each characterized by prescribed intensive thermodynamic variables (temperature, chemical potential, electric voltage, etc.). We assume that the system's microscopic degrees of freedom are equilibrated and can be grouped into  $i = \{1, \ldots, N\}$  mesoscopic states, with occupation number  $n_i$  evolving under a stochastic dynamics (see Fig. 2). Namely, the occupation number vector  $n = \{n_i\}_{i=1}^N$  changes at random times  $t_k$  by a finite vector  $\Delta_{\rho} = \{\Delta_{\rho}^i\}_{i=1}^N$  due to transitions of type  $\rho$  induced by the coupling with the reservoirs:

$$d_t n(t) = \sum_{\rho} \Delta_{\rho} J_{\rho}(t) = \sum_{\rho > 0} \Delta_{\rho} I_{\rho}(t). \tag{1}$$

Here,  $J_{\rho}(t) = \sum_{k} \delta_{\rho\rho(t)} \delta(t-t_{k})$  is the rate of transitions  $\rho$  occurring at time t (see, e.g. (Rao and Esposito, 2018a)) and  $I_{\rho}(t) = J_{\rho}(t) - J_{-\rho}(t)$  is the net current. We have used microscopic reversibility, which imposes that for each transition  $+\rho$  there exists an inverse transition denoted  $-\rho$  and satisfying  $\Delta_{\rho} = -\Delta_{-\rho}$ . The process (1) is taken to be Markovian by choosing for  $J_{\rho}(t)$  a Poissonian distribution <sup>1</sup> conditioned on the present state n(t) with average value  $R_{\rho}(n(t))^{2}$ . We might also consider systems driven by reservoirs whose intensive thermodynamic properties are externally changed in time. This corresponds to nonautonomous dynamics with rates  $R_o(n(t), \vartheta(t))$  that carry an explicit dependence on time via a protocol  $\vartheta(t)$  – although we will not write this dependence to avoid clutter. For concreteness, we can think of  $n_i$  as the number of molecules of chemical species i, or the number of charges of conductors i, or the number of excitations of modes i (see VII).

A trajectory  $\mathfrak{X}$  is the ordered set of states n(t) and jumps  $\rho(t_k)$  in the time span  $t \in [0, \tau]$ . The entire dynamical description of the system, equivalent to (1), is

![](_page_4_Picture_10.jpeg)

FIG. 2 Schematic representation of a system coupled to three reservoirs with fixed temperature T, (electro)chemical potential  $\mu$ , etc. Each of them can exchange energy, (charged) particles, etc. through various transition mechanisms which result in jumps of the system state n.

<span id="page-4-2"></span><span id="page-4-1"></span>given by the probability density of a trajectory (Maes and Netočný, 2008; Sun, 2006)

<span id="page-4-5"></span>
$$P[\mathfrak{X}] = P(n(0), 0)e^{-\sum_{\rho} \int_{0}^{\tau} dt R_{\rho}(n(t))} \prod_{k} R_{\rho(t_{k})}(n(t_{k}^{-})).$$
(2)

Here appear in order, the probability density of the initial state n(0), the product of probabilities for remaining in a certain state and the product of probability densities for changing state.

The dynamics in the configuration space corresponding to the mesoscopic description (1), or (2), is given by the master equation for the probability density of occupation numbers,

<span id="page-4-6"></span>
$$\partial_t P(n,t) = \sum_{\rho} [R_{\rho}(n - \Delta_{\rho})P(n - \Delta_{\rho}, t) - R_{\rho}(n)P(n,t)]$$
$$= \sum_{n'} \mathcal{R}_{nn'} P(n', t), \tag{3}$$

with  $\Re_{nn'} = \sum_{\rho} R_{\rho}(n')(\delta_{n',n-\Delta_{\rho}} - \delta_{n',n})$  the transition rate matrix, i.e. the generator of the Markovian dynamics. We assume that the Markov jump process has a connected graph, thus is ergodic. For transition rates that carry an explicit time dependence, the instantaneous sta-

<span id="page-4-3"></span> $<sup>^{1}</sup>$  Or, equivalently, an exponential distribution for the waiting times  $t_{k+1}-t_{k}. \label{eq:total_constraint}$ 

<span id="page-4-4"></span><sup>&</sup>lt;sup>2</sup> We chose a compact notation so that the argument of  $R_{\rho}(n)$  (and  $\Gamma_{\rho}(n), \Sigma_{\rho}(n)$ , etc.) denotes the starting state of the transition  $\rho$  but the function can depend as well on the final state  $n + \Delta_{\rho}$ .

tionary probability density is defined by

$$\sum_{n'} \mathcal{R}_{nn'} P_t^{\text{ss}}(n') = 0. \tag{4}$$

For transition rates that do not have any explicit time dependence, the solution of [\(4\)](#page-5-0) is the unique stationary probability density function P ss(n) = limt→∞ P(n, t) reached by the system at long times.

The transition rates satisfy the condition of local detailed balance [\(Bauer and Cornu,](#page-43-2) [2014;](#page-43-2) [Bergmann and](#page-43-3) [Lebowitz,](#page-43-3) [1955;](#page-43-3) [Esposito,](#page-44-0) [2012;](#page-44-0) [Falasco and Esposito,](#page-44-1) [2021;](#page-44-1) [Maes,](#page-46-0) [2021\)](#page-46-0),

$$\Sigma_{\rho}(n) := \ln \frac{R_{\rho}(n)}{R_{-\rho}(n + \Delta_{\rho})} = -\Phi(n + \Delta_{\rho}) + \Phi(n) + a_{\rho},$$
(5)

which states that the logarithm of the ratio between forward and backward rates of a given transition ρ is the entropy production Σ<sup>ρ</sup> of such process – the Boltzmann constant k<sup>B</sup> is set to 1 hereafter. Physically, [\(5\)](#page-5-1) holds when the transitions ±ρ are caused by reservoirs in thermodynamic equilibrium and all microscopic (internal) degrees of freedom of a mesostate n are as well equilibrated. In [\(5\)](#page-5-1), Φ(n) is the negative of the Massieu potential, also called free entropy [\(Callen,](#page-44-13) [1991\)](#page-44-13), defined by subtracting the internal entropy Sint(n) of the mesostate n from the energetic contribution of conserved quantities exchanged with the baths [3](#page-5-2) . For example, in the particular case of a system exchanging only energy with a single thermal bath at temperature T,

$$T\Phi(n) = U(n) - TS_{\text{int}}(n) \tag{6}$$

corresponds to the Helmholtz free energy, with U(n) the internal energy of state n. The quantity

$$a_{\rho} = \mathbb{X}_{\rho} \cdot f_{\text{nc}} = -a_{-\rho} \tag{7}$$

in [\(5\)](#page-5-1) denotes the nonconservative entropy flow in the transition ρ. It is the projection on ρ of the fundamental nonconservative forces fnc, i.e. the minimal set of independent forces generated by the reservoirs, with X<sup>ρ</sup> the variation in the reservoirs of the associated physical quantity due to the transition ρ. For these reasons, a<sup>ρ</sup> is expressed solely in terms of differences of intensive quantities of the reservoirs (e.g. inverse temperatures, chemical and electrical potentials), i.e. it is independent of the state of the system n. Such decomposition into Massieu potential and nonconservative forces can always be performed as outlined in [\(Rao and Esposito,](#page-47-4) [2018b\)](#page-47-4). We note that Σρ(n) = −Σ−<sup>ρ</sup>(n + ∆ρ).

<span id="page-5-0"></span>The total entropy production rate [\(Seifert,](#page-47-21) [2005\)](#page-47-21) along a fluctuating trajectory solution of [\(1\)](#page-4-2),

<span id="page-5-5"></span><span id="page-5-4"></span>
$$\dot{\Sigma}(t) = \dot{\Sigma}_e(t) + d_t S_{\text{sys}}(n(t), t), \tag{8}$$

is the sum of the entropy flow in the environment,

$$\dot{\Sigma}_e(t) := \sum_{\rho} J_{\rho}(t) \Sigma_{\rho}(n(t)) - d_t S_{\text{int}}(n(t)), \qquad (9)$$

plus the time derivative of the system entropy,

<span id="page-5-3"></span>
$$S_{\text{sys}}(n,t) := -\ln P(n,t) + S_{\text{int}}(n).$$
 (10)

<span id="page-5-1"></span>The first term on the righthand side of [\(10\)](#page-5-3) is the system's self-information or surprisal, whose mean value is the Shannon entropy

$$S_{\rm sh}(t) := -\sum_{n} P(n, t) \ln P(n, t).$$
 (11)

The stochastic entropy production, i.e. the time integral of [\(8\)](#page-5-4), can be obtained comparing forward and backward trajectory probabilities

$$\Sigma[\mathfrak{X}] = \int_0^\tau dt \, \dot{\Sigma}(t) = \ln \frac{P[\mathfrak{X}]}{\overline{P}[\mathfrak{X}]},\tag{12}$$

where P[X] is the probability of the time-reversed trajectory obtained from [\(2\)](#page-4-5) by the change of variable t<sup>k</sup> 7→ τ − t<sup>k</sup> and reversing the protocol ϑ(t) 7→ ϑ(τ − t). Therefore, the mean entropy production is the Kullback-Leibler divergence

$$\langle \Sigma[\mathfrak{X}] \rangle = \int \mathfrak{D}\mathfrak{X}P[\mathfrak{X}] \ln \frac{P[\mathfrak{X}]}{\overline{P}[\mathfrak{X}]} \ge 0.$$
 (13)

<span id="page-5-7"></span>Hereafter, the symbol ⟨. . .⟩ denotes the expectation value of an observable, computed with the appropriate probability, namely, P[X] for trajectory functionals or P(n, t) for functions of the state at a single time t.

The mean entropy production rate [\(Schnakenberg,](#page-47-22) [1976\)](#page-47-22) follows from averaging [\(8\)](#page-5-4), [\(9\)](#page-5-5) and [\(10\)](#page-5-3),

$$\langle \dot{\Sigma} \rangle = \sum_{n,\rho} R_{\rho}(n) P(n,t) \Sigma_{\rho}(n) + d_t S_{\rm sh}(t)$$
 (14)

$$= \sum_{n,\rho>0} \left[ R_{\rho}(n) P(n,t) - R_{-\rho}(n+\Delta_{\rho}) P(n+\Delta_{\rho},t) \right]$$

<span id="page-5-6"></span>
$$\times \ln \frac{R_{\rho}(n)P(n,t)}{R_{-\rho}(n+\Delta_{\rho})P(n+\Delta_{\rho},t)} \ge 0.$$

The nonnegativity follows from (x − y) ln(x/y) ≥ 0 valid for all positive x, y.

The dynamics is said to be detailed balanced when a<sup>ρ</sup> = 0 for all ρ. Thus, in the absence of parametric time dependence of the rates in the long time limit, when the initial condition P(n, 0) is relaxed, Σ(t) is identically

<span id="page-5-2"></span><sup>3</sup> In case of nonautonomous dynamics Φ(n, t) carries an explicit time dependence due to ϑ(t) that we avoid to write, though.

zero and the stationary solution of (3) is the equilibrium Gibbs distribution  $P^{eq}(n)$ ,

$$P^{\rm ss}(n) = \frac{e^{-\Phi(n)}}{\sum_{n} e^{-\Phi(n)}} =: P^{\rm eq}(n).$$
 (15)

In view of (5) and (15), when  $a_{\rho} = 0$  the local detailed balance condition on the transition rates can also be written as the equality of forward and backward fluxes at equilibrium:

$$P^{\text{eq}}(n)R_{\rho}(n) = P^{\text{eq}}(n + \Delta_{\rho})R_{-\rho}(n + \Delta_{\rho}). \tag{16}$$

Two other useful decompositions of the entropy production rate (8) can be introduced. First, rearranging (8), we get

$$\dot{\Sigma}(t) = \dot{\Sigma}_{\rm nc}(t) + \dot{\Sigma}_{\rm d}(t) - d_t [\Phi(n(t), t) + \ln P(n(t), t)], \tag{17}$$

where  $\dot{\Sigma}_{\rm nc}(t) := \sum_{\rho} J_{\rho}(t) a_{\rho}$  is the dissipation rate due to nonconservative forces,  $\dot{\Sigma}_{\rm d}(t) := \partial_t \Phi(n,t)|_{n=n(t)}$  is the dissipation rate caused by driving parametrically the reference equilibrium, and  $-[\Phi(n,t) + \ln P(n,t)]$  is the stochastic Massieu potential (Rao and Esposito, 2018b). The decomposition (17) is useful to rationalize which mechanism keeps the system out of equilibrium. In particular, we can name three limiting scenarios: in nonequilibrium stationary states only  $\dot{\Sigma}_{\rm nc}$  is on average nonzero; in periodic detailed balance dynamics only  $\dot{\Sigma}_{\rm d}$  is on average nonzero; in detailed balance dynamics relaxing from an initial nonequilibrium probability distribution only  $d_t(\Phi + \ln P)$  is nonzero. It is worth mentioning that the nonconservative dissipation rate  $\Sigma_{\rm nc}(t)$  can be cast in terms of the physical currents  $\sum_{\rho>0} \mathbb{X}_{\rho} I_{\rho}$  between the reservoirs that generate the fundamental forces  $f_{\rm nc}$ . Note that, for systems in contact with reservoirs at the same temperature T, the nonconservative and driving contributions to the entropy production correspond to work contributions divided by the temperature T.

Second, for systems with nonautonomous dynamics, or with relaxation from a nonstationary initial condition, it is worth recasting the entropy production rates into the adiabatic and nonadiabatic components (Esposito and Van den Broeck, 2010; Esposito et al., 2007; Hatano and Sasa, 2001; Speck and Seifert, 2005),

$$\dot{\Sigma}(t) = \dot{\Sigma}_{ad}(t) + \dot{\Sigma}_{na}(t), \tag{18}$$

with the adiabatic entropy production rate

$$\dot{\Sigma}_{\mathrm{ad}}(t) := \sum_{\rho} J_{\rho}(t) \left( \Sigma_{\rho}(t) + \ln \frac{P_t^{\mathrm{ss}}(n(t))}{P_t^{\mathrm{ss}}(n(t) + \Delta_{\rho})} \right), \quad (19)$$

and the nonadiabatic entropy production rate

<span id="page-6-3"></span><span id="page-6-0"></span>
$$\dot{\Sigma}_{\rm na}(t) := -d_t \ln P(n(t), t) + \sum_{\rho} J_{\rho}(t) \ln \frac{P_t^{\rm ss}(n(t) + \Delta_{\rho})}{P_t^{\rm ss}(n(t))}.$$
(20)

We recall that  $P_t^{ss}(n)$  denotes the stationary solution of the master equation (3) with transition rates held fix at their instantaneous values  $R_{\rho}(n, \vartheta(t))$ . Loosely speaking the splitting in (18) is in terms of the dissipation to maintain a stationary state and to drive it. This consideration becomes exact in two limiting cases: For autonomous systems at stationarity, in which  $P(n,t) = P_t^{ss}(n)$ , so that (20) is identically zero and the adiabatic entropy production rate (19) equals  $\Sigma(t)$ ; for nonautonomous detailed balance dynamics, for which  $P_t^{ss}(n) = P_t^{eq}(n)$ , so that (19) is identically zero and the nonadiabatic entropy production rate (20) equals  $\Sigma(t)$ . It can be shown that both  $\dot{\Sigma}_{\rm ad}(t)$  and  $\dot{\Sigma}_{\rm na}(t)$  are on average positive (Esposito and Van den Broeck, 2010; Esposito et al., 2007; Ge and Qian, 2010; Rao and Esposito, 2018c). Adiabatic and nonadiabatic components are also called housekeeping and excess ones, respectively, even though such names were originally assigned to the decomposition of entropy production of systems in contact with isothermal baths.

<span id="page-6-1"></span>There exists another measure of the time-irreversibility of the dynamics obtained by lumping together in the master equation (3) all the transition rates  $R_{\rho}(n)$  associated to jumps with the same size  $\tilde{\Delta}_{\rho}$ , as  $\tilde{R}_{\rho}(n) := \sum_{\rho:\Delta_{\rho}=\tilde{\Delta}_{\rho}} R_{\rho}(n)^{-4}$ . On the resulting trajectories  $\mathfrak{X}'$  (which are identical to  $\mathfrak{X}$  when restricted to the state space) one can define the Kullback-Leibler divergence:

<span id="page-6-6"></span>
$$\langle \tilde{\Sigma}[\mathfrak{X}'] \rangle = \int \mathfrak{D}\mathfrak{X}' P[\mathfrak{X}'] \ln \frac{P[\mathfrak{X}']}{\overline{P}[\mathfrak{X}']} \ge 0.$$
 (21)

Such trajectories carry no detailed information about the elementary transitions, therefore (21) is a mere information-theoretic with no general connection to thermodynamics. The rate of (21) is obtained as done for (14):

$$\langle \dot{\tilde{\Sigma}}(t) \rangle = \sum_{\substack{n,\rho > 0 \\ \rho: \Delta_{\rho} = \tilde{\Delta}_{\rho}}} \left[ \tilde{R}_{\rho}(n) P(n,t) - \tilde{R}_{-\rho}(n + \Delta_{\rho}, t) P(n + \Delta_{\rho}) \right]$$

<span id="page-6-7"></span>
$$\times \ln \frac{\tilde{R}_{\rho}(n)P(n,t)}{\tilde{R}_{-\rho}(n+\Delta_{\rho})P(n+\Delta_{\rho},t)} \ge 0.$$
 (22)

By applying the log sum inequality to (14), it follows that  $\langle \dot{\hat{\Sigma}} \rangle \leq \langle \dot{\Sigma} \rangle$ .

<span id="page-6-2"></span>We conclude this short summary of the core structure of stochastic thermodynamics with three comments on

<span id="page-6-5"></span><span id="page-6-4"></span><sup>&</sup>lt;sup>4</sup> This happens when a change in the state space can be realized via multiple pathways. See Sec. VII.A.1 for an example.

the transition rates. First, they can be rewritten as

$$R_{\rho}(n) = \Gamma_{\rho}(n)e^{\frac{1}{2}[-\Phi(n+\Delta_{\rho})+\Phi(n)+a_{\rho}]},$$
 (23)

by identifying a symmetric kinetic factor  $\Gamma_{\rho}(n) = \sqrt{R_{\rho}(n)R_{-\rho}(n+\Delta_{\rho})} = \Gamma_{-\rho}(n+\Delta_{\rho})$  not constrained by thermodynamics (Maes, 2018). Second, on can introduce dual (also called adjoint, or reversed) rates,

$$R_{\rho}^{\dagger}(n) := \frac{R_{-\rho}(n + \Delta_{\rho})P_{t}^{\rm ss}(n + \Delta_{\rho})}{P_{t}^{\rm ss}(n)},$$
 (24)

which generate a stochastic process with the same stationary distribution as the original one, namely  $P_t^{\rm ss} = P_t^{\rm ss\dagger}$ , and change the sign of the average stationary currents,  $\langle I_\rho^\dagger \rangle = -\langle I_\rho \rangle$  (Norris, 1998). Third, by combining the escape rate  $\sum_{\rho} R_\rho(n)$ , which gives the mean time to leave the state n, with the entrance rate  $\sum_{\rho} R_\rho(n-\Delta_\rho)$  in the same state, we introduce the inflow rate

$$\Lambda(n) := \sum_{\rho} [R_{\rho}(n - \Delta_{\rho}) - R_{\rho}(n)]$$
 (25)

that measures the rate of contraction of a discrete volume centered on the state n (Baiesi and Falasco, 2015).

## <span id="page-7-0"></span>III. MACROSCOPIC LIMIT

## <span id="page-7-1"></span>A. Thermodynamic and kinetic conditions

We identify a large parameter V on which the rates  $R_{\rho}$  depend. This can be for instance a mesoscopic volume which is large when measured in units of molecular volumes, or a typical particle number per state which is much larger than unity. We focus on systems such that  $n \to \infty$  as  $V \to \infty$  and thus define an intensive state variable c := n/V. We fix the asymptotic behavior of the thermodynamic variables to match the extensivity prescribed by standard (macroscopic) thermodynamics,

$$\phi(c) := \lim_{V \to \infty} \frac{\Phi(n)}{V}.$$
 (26)

Note that  $a_{\rho}$  is already a quantity of order  $O(V^0)$  because the fundamental nonconservative forces are already expressed in terms of *intensive* thermodynamic variables of the reservoirs (that are macroscopic). We also assume that a deterministic macroscopic limit of the dynamics (3) exists, which requires that the transition rates scale asymptotically with V.

$$r_{\rho}(c) := \lim_{V \to \infty} \frac{R_{\rho}(n)}{V} = \gamma_{\rho}(c) e^{\frac{1}{2}[-\Delta_{\rho} \cdot \partial_{c} \phi(c) + a_{\rho}]}, \quad (27)$$

which entails for the macroscopic kinetic coefficients

<span id="page-7-11"></span><span id="page-7-7"></span>
$$\gamma_{\rho}(c) := \lim_{V \to \infty} \frac{\Gamma_{\rho}(n)}{V} = \gamma_{-\rho}(c). \tag{28}$$

Thus the macroscopic expression of the local detailed balance (5) reads

<span id="page-7-9"></span>
$$\sigma_{\rho}(c) := \lim_{V \to \infty} \Sigma_{\rho}(n) = \ln \frac{r_{\rho}(c)}{r_{-\rho}(c)} = -\Delta_{\rho} \cdot \partial_{c} \phi(c) + a_{\rho} .$$
(29)

Note that  $\gamma_{\rho}(c)$  may depend in a symmetric fashion on the forces  $-\Delta_{\rho} \cdot \partial_{c} \phi(c)$  and  $a_{\rho}$ .

Under these assumptions the master equation for the probability density of the intensive state variable,  $p(c,t) = V^N P(n,t)$ , reads

<span id="page-7-4"></span>
$$\partial_t p(c,t) = V \sum_{\rho} \left[ r_\rho \left( c - \frac{\Delta_\rho}{V} \right) p \left( c - \frac{\Delta_\rho}{V}, t \right) - r_\rho(c) p(c,t) \right]. \tag{30}$$

<span id="page-7-10"></span>The scaling imposed in (27) leads to the concentration of probability in the macroscopic limit (Gardiner, 2004; Van Kampen, 2007). Namely, the probability density p(c,t) acquires the large-deviation form

<span id="page-7-3"></span>
$$p(c,t) \approx e^{-VI(c,t)},$$
 (31)

where  $I \geq 0$ , called rate function, is V-independent. The symbol  $\asymp$  stands for the logarithm equality of the two sides of (31), that is  $-\lim_{V\to\infty}\frac{1}{V}\ln p(c,t)=I(c,t)$ . The scaling captures the fact that p is singular in the limit  $V\to\infty$ , wherein the system is described by the deterministic dynamics of the minima of I(c,t) as we are going to show in Sec. III.B.

Plugging (31) into (30) and expanding to leading order in V yields the evolution equation for the rate function

<span id="page-7-5"></span>
$$-\partial_t I(c,t) = \sum_{\rho} \left( e^{\Delta_{\rho} \cdot \partial_c I(c,t)} - 1 \right) r_{\rho}(c), \qquad (32)$$

which is a Hamilton-Jacobi equation with momenta  $\pi = \partial_c I$  and Hamiltonian function (Gang, 1987; Kubo *et al.*, 1973)

$$\mathcal{H}(c,\pi) = \sum_{\rho} \left( e^{\Delta_{\rho} \cdot \pi} - 1 \right) r_{\rho}(c). \tag{33}$$

<span id="page-7-12"></span>The stationary rate function  $I_{ss}(c)$ , also called quasipotential – where it exists and is differentiable – satisfies the time-independent version of (32) (Maes and Netočný, 2007),

<span id="page-7-8"></span><span id="page-7-6"></span>
$$\mathcal{H}(c, \partial_c I_{ss}) = 0, \tag{34}$$

<span id="page-7-2"></span>and gives the stationary probability density function

$$p_{\rm ss}(c) \simeq e^{-VI_{\rm ss}(c)}$$
. (35)

For detailed balanced dynamics, the quasi-potential coincides (up to a constant) with the negative Massieu potential  $\phi$ , whose minima will be denoted by  $x^{\text{eq}}$ . This can be seen by rewriting (34) as

$$\sum_{\rho} (r_{-\rho}^{(0)} - r_{\rho}^{(0)} e^{\Delta_{\rho} \cdot \partial_{c} I_{ss}}) = 0$$
 (36)

with detailed-balanced rates

$$r_{\rho}^{(0)} := \lim_{a_{\rho} \to 0} r_{\rho} = \gamma_{\rho}^{(0)} e^{-\frac{1}{2}\Delta_{\rho} \cdot \partial_{c} \phi},$$
 (37)

and noting that  $I_{\rm ss} = \phi + {\rm const}$  nullifies each summand in (36) by virtue of (29). Hence, the large-scale stochastic dynamics preserves the equilibrium Gibbs distribution (15) and yields the Einstein's fluctuations formula (Einstein, 1910)

$$p_{\rm eq}(c) \simeq e^{-V[\phi(c) - \phi(x^{\rm eq})]},$$
 (38)

with the partition function  $\sum_n e^{-\Phi(n)} \approx e^{-V\phi(x^{eq})}$  obtained by the Laplace approximation. Note that the equilibrium state  $x^{eq}$  is the one that minimizes the thermodynamic potential  $\phi$ .

For transition rates that carry an explicit time dependence, we introduce the instantaneous stationary rate function  $I_{ss}^t(c)$  which satisfies

$$\mathcal{H}_t(c, \partial_c I_{ss}^t) = 0, \tag{39}$$

where  $\mathcal{H}_t$  is the Hamiltonian (33) with transition rates  $r_{\rho}(c, \vartheta(t))$  held fixed at their instantaneous value at time t. We end by noting that, using (24), the scaled dual rate is given by

$$r_{\rho}^{\dagger}(c) := \lim_{V \to \infty} \frac{R_{\rho}^{\dagger}(n)}{V} = r_{-\rho}(c)e^{-\Delta_{\rho} \cdot \partial_{c}I_{ss}(c)} , \qquad (40)$$

and is associated to the macroscopic log-ratio

$$\sigma_{\rho}^{\mathrm{ad}}(c) := \lim_{V \to \infty} \ln \frac{R_{\rho}(n)}{R_{\rho}^{\dagger}(n)} = \ln \frac{r_{\rho}(c)}{r_{\rho}^{\dagger}(c)}$$
$$= \Delta_{\rho} \cdot \partial_{c} [I_{\mathrm{ss}}(c) - \phi(c)] + a_{\rho}. \tag{41}$$

This corresponds to the macroscopic limit of the adiabatic entropy production of transition  $\rho$ , as can be directly seen from (19). The importance of these quantities for the macroscopic dynamics and thermodynamics will be elucidated in following sections.

#### <span id="page-8-0"></span>B. Deterministic dynamics

The macroscopic dynamical equation for the intensive state variable can be obtained multiplying both sides of (30) by c, and integrating over c with the change of vari-

able  $c \mapsto c + \Delta_{\rho}/V$  in the righthand side,

$$d_t \langle c \rangle = \sum_{\rho} \Delta_{\rho} \langle r_{\rho}(c) \rangle = \sum_{\rho > 0} \Delta_{\rho} [\langle r_{\rho}(c) \rangle - \langle r_{-\rho}(c) \rangle]. \tag{42}$$

<span id="page-8-10"></span><span id="page-8-1"></span>The mean value of a generic state observable  $\mathfrak{G}$  at time t is calculated as  $\langle \mathfrak{G}(c(t)) \rangle = \int dc \, \mathfrak{G}(c) p(c,t)$ . In view of the large-deviation scaling of the probability (31), the probability density concentrates around its most likely state x(t) which corresponds to the global minimum of I(c,t) (Hao and Hong, 2011; Huang et al., 2017; Qian et al., 2016), namely,

<span id="page-8-7"></span><span id="page-8-5"></span><span id="page-8-2"></span>
$$x(t) := \operatorname{argmin}_{c} I(c, t), \tag{43}$$

and therefore

$$I(x(t),t) = \partial_c I(x(t),t) = 0$$
,  $\partial_c^2 I(x(t),t) > 0$ . (44)

This implies that, using Laplace method,  $\lim_{V\to\infty}\langle \mathbb{O}(c(t))\rangle=\mathbb{O}(x(t))$  and (42) approaches the dynamics

<span id="page-8-4"></span><span id="page-8-3"></span>
$$d_t x(t) = F(x(t)), \tag{45}$$

<span id="page-8-9"></span>with the deterministic drift field

$$F(c) := \sum_{\rho} \Delta_{\rho} r_{\rho}(c) = \partial_{\pi} \mathcal{H}(c, \pi)|_{\pi = 0}, \tag{46}$$

which we recognize as the derivative of the Hamiltonian (33) with respect to the momenta  $\pi$ . We will thoroughly explore the connection with the Hamiltonian dynamics in Sec. IV.A. Notably, the macroscopic limit of the inflow rate (25) is the negative divergence of the drift field (46),

<span id="page-8-11"></span>
$$\lambda(c) := \lim_{V \to \infty} \Lambda(n) = -\partial_c \cdot F(c). \tag{47}$$

<span id="page-8-12"></span><span id="page-8-8"></span>The latter is a key quantity in the dynamical systems theory as it represents the phase space volume contraction rate (Dorfman, 1999; Gaspard, 2005), that is the negative sum of the Lyapunov exponents (Benettin et al., 1980) of the deterministic dynamics (45). The phase space contraction rate plays a key role in the statistical mechanics of deterministic thermostatted systems (Evans and Morriss, 1990) as it enters the steady state (Gallavotti-Cohen (Evans et al., 1993; Gallavotti and Cohen, 1995a,b)) and the transient (Evans-Searles (Evans and Searles, 1994, 2002)) fluctuation theorems, and can sometimes be identified with the entropy production rate (Cohen and Rondoni, 1998).

For any autonomous dynamics (45), the quasipotential  $I_{ss}$  always decreases along the solution, i.e.

<span id="page-8-6"></span>
$$d_t I_{ss}(x(t)) = F(x(t)) \cdot \partial_c I_{ss}(x(t)) \le 0, \tag{48}$$

where the inequality is proved using the explicit form of

(34) with the fact that  $e^x - 1 \ge x$ . Since (43) implies that  $I_{ss}$  always reaches a minimum on the long-time solutions of (45), be them stable fixed points  $x^*$  (defined by  $F(x^*) = 0$ , see Sec. III.C) or time-dependent attractors  $x^*(t)$ , the quasi-potential is a Lyapunov function of the deterministic dynamics (45). When the dynamics is detailed balanced  $(a_\rho = 0)$ , (48) reduces to

$$d_t \phi(x(t)) \le 0 , \qquad (49)$$

and we recover a central tenet of macroscopic thermodynamics, namely that the thermodynamic potential  $\phi$  is minimized by the dynamics.

We end by introducing the Hamiltonian of the dual process

$$\mathcal{H}^{\dagger}(c,\pi) = \sum_{\rho} \left( e^{\Delta_{\rho} \cdot \pi} - 1 \right) r_{\rho}^{\dagger}(c) , \qquad (50)$$

and its deterministic drift field

$$F^{\dagger}(c) := \sum_{\rho} \Delta_{\rho} r_{\rho}^{\dagger}(c) = \partial_{\pi} \mathcal{H}^{\dagger}(c, \pi)|_{\pi=0} . \tag{51}$$

The dual dynamics shares not only the same fixed point as the original one,  $F^{\dagger}(x^*) = F(x^*) = 0$ , but also the same steady state rate function,

$$\mathcal{H}^{\dagger}(c, \partial_c I_{ss}) = -\mathcal{H}(c, \partial_c I_{ss}) = 0. \tag{52}$$

The dual macroscopic trajectory  $x^{\dagger}(t)$  solution of the equation

$$d_t x^{\dagger}(t) = F^{\dagger}(x^{\dagger}(t)) \tag{53}$$

with initial condition  $x^{\dagger}(0) = x^*$ , will play a central role in the description of macroscopic fluctuations, Sec. IV.

## <span id="page-9-0"></span>C. Multistability vs metastability

A fixed point is stable, and will be denoted  $x^*$ , if all eigenvalues of the Jacobian matrix  $\partial_c F(c)$  evaluated in  $c=x^*$  have negative real part. It is unstable when at least one eigenvalue has positive real part. When F is nonlinear, multiple stable fixed points  $x_{\gamma}^*$  can be present that we indicate with the label  $\gamma \in \mathbb{N}$ . More complex, time-dependent attractors such as limit cycles will only be mentioned later. We assume that the stable fixed points  $x_{\gamma}^*$  are separated by nondegenerate saddle points, denoted  $x_{\nu}$ , i.e. fixed points with real, nonzero eigenvalues, at least one of which is positive. They define the boundaries between the different basins of attraction of F. In this case the dynamics (45) is nonergodic and multistable, since x(t), due to (48), will relax within the basin of attraction selected by the initial condition x(0) to its fixed point. This has to be contrasted with the uniqueness of the stationary solution of the underlying mesoscopic master equation (3). The discrepancy, known as Keizer's paradox (Keizer, 1978), stems from the fact that the long time limit and the macroscopic limit do not commute in general. This phenomenon is understood within the spectral theory of the Markovian generator, which is summarized as follows (Gaveau and Schulman, 1998a; Kurchan, 2009). The time evolution of the probability distribution, can be expanded in the right eigenfunctions  $\psi_{\xi}^{(R)}(n)$  of the matrix  $\Re$  in (3),

$$P(n,t) = \sum_{\xi} b_{\xi} \psi_{\xi}^{(R)}(n) e^{\omega_{\xi} t}, \qquad (54)$$

<span id="page-9-3"></span>where  $b_{\xi} = \sum_{n} \psi_{\xi}^{(L)}(n) P(n,0)$  are the overlap of the initial condition with the left eigenfunctions  $\psi_{\xi}^{(L)}(n)$ . Since  $\Re$  is a stochastic generator on a finite state space, by Perron-Frobenius theorem it has nonpositive eigenvalues (which can be ordered by their real part  $\operatorname{Re}(\omega_{\xi}) \geq \operatorname{Re}(\omega_{\xi+1})$ ), of which  $\omega_0 = 0$  is nondegenerate and associated to a constant left eigenfunction. Metastability appears when there exist eigenvalues  $\omega_1, \ldots, \omega_{\tilde{\xi}}$  whose real part goes to  $0 = \omega_0$  as  $V \to \infty$ , while all others  $\omega_{\xi}$  with  $\xi > \tilde{\xi}$  stay finite. The inverse of this spectral gap corresponds to a diverging time scale separating the fast dynamics within basins of attractions from the slow dynamics) between them. Ultimately, if  $V \to \infty$  at finite t, the system probability can only converge to (linear combinations of) those  $\psi_{\xi}^{(R)}(n)$  with  $\xi \leq \tilde{\xi}$  that are selected by the initial conditions, i.e. with finite overlap  $b_{\xi} \neq 0$ .

<span id="page-9-2"></span><span id="page-9-1"></span>In general  $\Re$  is not similar to a symmetric matrix unless detailed balance holds, hence the eigenvalue  $\omega_{\xi}$  can have a non-zero imaginary part. In this case metastable states can be time-dependent, such as stable limit cycles at  $V \to \infty$  (Herpich et al., 2018b). A limit cycle is a closed trajectory in state space not surrounded by other closed trajectories. It is called stable or attracting if all neighboring trajectories approach it for large times. It appears as a periodic solution of (45),  $x^*(t) = x^*(t+t_p)$ , with period  $t_p = 2\pi/\text{Im}(\omega_{\xi})$  with  $\xi \leq \tilde{\xi}$ . Hereafter, we only briefly mention such periodic attractors, while we do not explicitly consider more general quasi-periodic and chaotic attractors – see the application in Sec. VII.C and the discussion in Sec. VIII, though.

For multistable systems a further comment is in order. For general nondetailed balanced dynamics, the rate function  $I_{\rm ss}$  is locally nondifferentiable and (34) can be solved only piecewise in each basin of attraction (Baek and Kafri, 2015; Graham and Tél, 1986) obtaining the local quasi-potential  $I_{\rm ss}^{(\gamma)}$ . This stems from the fact that only the local stochastic dynamics can be directly determined when the macroscopic limit is taken before the long-time limit (Ge and Qian, 2012; Zhou and Li, 2016). The global quasi-potential defined by first taking the long time limit before the large V limit, is obtained a posteriori by fixing the normalization constants, i.e. the rela-

tive weights  $\alpha_{\gamma}$  of the attractors, and choosing at each c the minimum among the local quasi-potentials (Bouchet et al., 2016):

$$I_{\rm ss}(c) = \min_{\gamma} (I_{\rm ss}^{(\gamma)}(c) + \alpha_{\gamma}) - \min_{\gamma} \alpha_{\gamma}. \tag{55}$$

The last term ensures that  $I_{\rm ss}$  is zero on the most likely attractor. The Markov jump process on attractors which is used to fix the normalization constants (Freidlin and Wentzell, 1998; Graham, 1987) will be discussed in Sec. VI as a coarse-grained description for the long-time macroscopic fluctuating thermodynamics of the systems. If the limit  $V \to \infty$  is taken before the limit  $t \to \infty$  the relative weights are fixed by the initial condition (the relative probability to be on an attractor).

## <span id="page-10-0"></span>D. Deterministic thermodynamics

The first crucial observation regards the macroscopic Shannon entropy

$$S_{\rm sh}(t) = -\int dc \, p(c, t) \ln p(c, t), \qquad (56)$$

where an irrelevant additive constant has been discarded. Its scaled macroscopic limit is identically null, since the randomness associated to the distribution over states c has vanished, see (44):

<span id="page-10-1"></span>
$$-\lim_{V \to \infty} \frac{1}{V} S_{\rm sh}(t) = I(x(t), t) = 0.$$
 (57)

However, the mean of the scaled system entropy (10) is in general finite and entirely given by the internal entropy evaluated on the most likely state,

$$\lim_{V \to \infty} \frac{1}{V} \langle S_{\text{sys}}(n, t) \rangle = s_{\text{int}}(x(t)).$$
 (58)

Here we have required the internal entropy  $S_{\text{int}}$  to be an extensive function of V.

The mean variation rate of thermodynamic observables depends on the average flux of transitions, which at leading order in V reads

$$\langle J_{\rho}(t)\rangle = V \int dc \, r_{\rho}(c) p(c,t).$$
 (59)

The concentration of the probability (31) yields for the scaled macroscopic limit of the transition flux

$$\lim_{V \to \infty} \frac{1}{V} \langle J_{\rho}(t) \rangle = r_{\rho}(x(t)). \tag{60}$$

Hence, the function  $[r_{\rho}(x(t)) - r_{-\rho}(x(t))] o_{\rho}$  represents the mean rate of variation of an intensive quantity  $o_{\rho} = -o_{-\rho}$  due to transition  $\rho$ . In particular, the mean of the scaled entropy production rate  $\dot{\sigma} := \dot{\Sigma}/V$  reads in the macroscopic limit

<span id="page-10-4"></span>
$$\lim_{V \to \infty} \langle \dot{\sigma} \rangle = \sum_{\rho > 0} [r_{\rho}(x(t)) - r_{-\rho}(x(t))] \sigma_{\rho}(x(t)) \ge 0, \quad (61)$$

<span id="page-10-7"></span>where we have used (29) and (57) into (14) – note the absence of the Shannon entropy with respect to (14). In the macroscopic limit, all average quantities at time t are functions of x(t). However, for brevity we avoid to write explicitly this dependence.

Taking the mean value of decomposition (17) and using the concentration of probability (31) and (60), we obtain

$$\lim_{V \to \infty} \langle \dot{\sigma} \rangle = \lim_{V \to \infty} \langle \dot{\sigma}_{\rm nc} \rangle + \lim_{V \to \infty} \langle \dot{\sigma}_{\rm d} \rangle - d_t \phi(x(t), t), \quad (62)$$

which displays the scaled mean of the nonconservative dissipation rate

$$\lim_{V \to \infty} \langle \dot{\sigma}_{\rm nc} \rangle = \sum_{\rho} r_{\rho}(x(t)) a_{\rho} , \qquad (63)$$

<span id="page-10-6"></span>of the driving dissipation rate

$$\lim_{V \to \infty} \langle \dot{\sigma}_{d} \rangle = \partial_{t} \phi(c, t)|_{c=x(t)} , \qquad (64)$$

and the time derivative of the mean scaled thermodynamic potential. Proceeding in the same manner with (18), we can find the alternative decomposition

<span id="page-10-5"></span>
$$\lim_{V \to \infty} \langle \dot{\sigma} \rangle = \lim_{V \to \infty} \langle \dot{\sigma}_{ad} \rangle + \lim_{V \to \infty} \langle \dot{\sigma}_{na} \rangle , \qquad (65)$$

in terms of mean scaled adiabatic entropy production rate

$$\lim_{V \to \infty} \langle \dot{\sigma}_{ad} \rangle = \sum_{\rho > 0} [r_{\rho}(x(t)) - r_{-\rho}(x(t))] \sigma_{\rho}^{ad}(x(t)) \ge 0$$
(66)

<span id="page-10-8"></span>with (41), and the mean scaled nonadiabatic entropy production rate

<span id="page-10-3"></span>
$$\lim_{V \to \infty} \langle \dot{\sigma}_{\text{na}} \rangle = -F(x(t)) \cdot \partial_c I_{\text{ss}}^t(x(t))$$

$$= \partial_t I_{\text{ss}}^t(c)|_{c=x(t)} - d_t I_{\text{ss}}^t(x(t)) \ge 0 ,$$
(67)

where we used (29) and (46). We recall that the rate function  $I_{\rm ss}^t(c)$  is the solution of (39) with the transition rates held fixed at their instantaneous value. Since (19) and (20) are nonnegative on average,  $\langle \dot{\sigma}_{\rm ad} \rangle$  and  $\langle \dot{\sigma}_{\rm na} \rangle$  are nonnegative as well. As a consequence, for autonomous systems ( $I_{\rm ss}^t = I_{\rm ss}$ ), the positivity of the nonadiabatic entropy production (67) provides an alternative proof that the quasi-potential decreases along the solution of (45), as shown in (48).

<span id="page-10-2"></span>Finally, thanks to (27) and (31), the mean value of the scaled information-theoretic entropy production rate  $\dot{\tilde{\sigma}} := \dot{\tilde{\Sigma}}/V$  (cf. (22)) reads

$$\lim_{V \to \infty} \langle \dot{\tilde{\sigma}}(t) \rangle =$$

$$\sum_{\substack{\rho > 0 \\ \rho : \Delta_{\rho} = \tilde{\Delta}_{\rho}}} \left[ \tilde{r}_{\rho}(x(t)) - \tilde{r}_{-\rho}(x(t)) \right] \ln \frac{\tilde{r}_{\rho}(x(t))}{\tilde{r}_{-\rho}(x(t))} \ge 0,$$
(68)

with  $\tilde{r}_{\rho}(c) := \lim_{V \to \infty} \frac{1}{V} \tilde{R}_{\rho}(n)$ . Using again the log sum inequality we find that  $\langle \dot{\tilde{\sigma}} \rangle \leq \langle \dot{\sigma} \rangle$ .

#### <span id="page-11-0"></span>E. Drift field decomposition

For simplicity, we focus on autonomous dynamics in this subsection. A useful decomposition of the macroscopic vector field F(c) can be obtained by retaining the entire Kramers-Moyal expansion of the master equation (Gardiner, 2004). Namely, the Taylor expansion of the righthand side of (30) yields a continuity equation with probability current j(c,t):

$$\partial_t p(c,t) = -\partial_c \cdot \mathfrak{j}(c,t), \tag{69}$$

$$\mathfrak{j}(c,t) := \sum_{l=1}^{\infty} \frac{\Delta_{\rho}}{V^{k-1} k!} (-\Delta_{\rho} \cdot \partial_c)^{k-1} [r_{\rho}(c) p(c,t)].$$

Then plugging the large-deviation ansatz (31) into (69) and restricting to the stationary state, we identify the macroscopic limit of the probability velocity in configuration space (Wu and Wang, 2013),

$$v_{\rm ss}(c) := \lim_{V \to \infty} \lim_{t \to \infty} \frac{\mathbf{j}(c, t)}{p(c, t)} = \sum_{\rho} \Delta_{\rho} r_{\rho}(c) \frac{e^{\Delta_{\rho} \cdot \partial_{c} I_{\rm ss}} - 1}{\Delta_{\rho} \cdot \partial_{c} I_{\rm ss}}.$$
(70)

As a consequence, the deterministic drift vector field

$$F(c) = v_{ss}(c) - \mathcal{F}(c), \tag{71}$$

splits into the asymptotic probability velocity (70) and a gradient-like vector field

$$\mathcal{F}(c) := \sum_{\rho} \Delta_{\rho} r_{\rho}(c) \frac{e^{\Delta_{\rho} \cdot \partial_{c} I_{ss}} - \Delta_{\rho} \cdot \partial_{c} I_{ss} - 1}{\Delta_{\rho} \cdot \partial_{c} I_{ss}}$$

$$= \mathcal{M}(c) \cdot \partial_{c} I_{ss},$$
(72)

with the symmetric positive semidefinite "mobility" matrix

$$\mathcal{M}(c) = \sum_{\rho} \Delta_{\rho} \Delta_{\rho} r_{\rho}(c) \frac{e^{\Delta_{\rho} \cdot \partial_{c} I_{ss}} - \Delta_{\rho} \cdot \partial_{c} I_{ss} - 1}{(\Delta_{\rho} \cdot \partial_{c} I_{ss})^{2}}, \quad (73)$$

<span id="page-11-11"></span>which itself depends on the rate function. They can respectively be rewritten in terms of the Hamiltonian (33)

<span id="page-11-10"></span>
$$v_{\rm ss}(c) = \int_0^1 d\theta \partial_\pi \mathcal{H}(c,\pi)|_{\pi = \theta \partial_c I_{\rm ss}},\tag{74}$$

$$\mathcal{M}(c) := \int_0^1 d\theta (1 - \theta) \partial_{\pi}^2 \mathcal{H}(c, \pi) |_{\pi = \theta \partial_c I_{ss}}.$$
 (75)

These expressions appear in (Gao and Liu, 2022) for polynomial transition rates, but hold irrespective of the specific form of  $r_{\rho}$ .

Equation (71) is an extension of the well-known "orthogonal" decomposition valid for deterministic dynamical systems supplemented by weak Gaussian noise leading to diffusion processes. (Bertini et al., 2015; Zhou and Li, 2016). This decomposition is here generalized to Markov jump processes, where the noise is Poissonian. It expresses the nonlinear downhill motion of x(t) in the gradient of the Lyapunov function  $I_{ss}$  superimposed to the circulation on its level sets with velocity  $v_{ss}(x(t))$ . The major difference is that the mobility matrix  $\mathcal{M}$  of diffusive dynamics is independent of the gradient of the rate function.

<span id="page-11-1"></span>To prove these properties, we first focus on the probability velocity  $v_{\rm ss}(c)$ . It is orthogonal to the gradient of the quasi-potential  $I_{\rm ss}$  since

$$v_{\rm ss} \cdot \partial_c I_{\rm ss} = \mathcal{H}(c, \partial_c I_{\rm ss}) = 0, \tag{76}$$

thanks to the definition (70) and the stationary state condition (34) <sup>5</sup>. Additionally, the probability velocity is divergence-free on the fixed points

<span id="page-11-9"></span><span id="page-11-5"></span>
$$\partial_c \cdot v_{\rm ss}(x^*) = 0. \tag{77}$$

It follows from writing  $v_{\rm ss} = \mathcal{N}(c) \cdot \partial_c I_{\rm ss}$ , with  $\mathcal{N}(c)$  an antisymmetric matrix that enforces (76), and using the condition (44). Note that in general  $\partial_c \cdot v_{\rm ss} \neq 0$  for  $c \neq x^*$ , as one can show by expanding the master equation (30) beyond the leading order approximation (32).

<span id="page-11-3"></span><span id="page-11-2"></span>Then we turn to the gradient part of the dynamics. We already showed in (48) that the quasi-potential  $I_{\rm ss}(c)$  is the Lyapunov function of (45), i.e. it decreases along solutions of (45) and reaches a (local) minimum at a stable fixed point  $x_{\gamma}^{*}$  (or stable time-dependent attractor  $x^{*}(t)$ ). In fact only the gradient part of the drift vector field,  $\mathcal{F}(c)$ , contributes in (48) due to (76), i.e.

<span id="page-11-7"></span><span id="page-11-6"></span>
$$d_t I_{ss}(x(t)) = -\mathcal{F}(x(t)) \cdot \partial_c I_{ss}|_{c=x(t)} \le 0. \tag{78}$$

<span id="page-11-8"></span><span id="page-11-4"></span><sup>&</sup>lt;sup>5</sup> Stationarity of the microscopic stochastic dynamics should not be taken for stationarity of the macroscopic rate equation (45). For example, a time-dependent attractor  $x^*(t)$ , such as a stable limit cycle, corresponds to a stationary probability density  $p_{\rm ss}(c)$  with a rate function  $I_{\rm ss}$  that is zero on the set  $\{x^*(t)\}_{t=0}^{t_p}$ .

For detailed balance dynamics, the velocity  $v_{\rm ss}$  is identically zero because  $\lim_{t\to\infty} \mathfrak{j}=0$ . This can also be proved starting from the explicit expression (70). By using  $I_{\rm ss}=\phi$ , valid for  $a_{\rho}=0$ , and the expression (37) for detailed balance transition rates, we obtain

$$v_{\text{ss}} \underset{a_{\rho}=0}{=} \sum_{\rho} \Delta_{\rho} \gamma_{\rho}^{(0)} e^{-\Delta_{\rho} \cdot \partial_{c} \phi/2} \frac{e^{\Delta_{\rho} \cdot \partial_{c} \phi} - 1}{\Delta_{\rho} \cdot \partial_{c} \phi}$$
$$= 2 \sum_{\rho} \Delta_{\rho} \gamma_{\rho}^{(0)} \frac{\sinh(\Delta_{\rho} \cdot \partial_{c} \phi/2)}{\Delta_{\rho} \cdot \partial_{c} \phi} = 0,$$

where in the last passage we split the sum over forward and backward transitions  $\pm \rho$  and used the anti-symmetry of  $\Delta_{\rho}$  and sinh. In this case the deterministic dynamics is a nonlinear gradient descent in the thermodynamic potential  $\phi$ ,

$$F(c) = \int_{a_{\rho}=0} -\mathcal{F}(c) = \int_{a_{\rho}=0} -D^{(0)}(c) \cdot \partial_{c} \phi(c) + O((\partial_{c} \phi)^{2}),$$
(79)

where we introduced

$$D^{(0)}(c) := \lim_{a_{\rho} \to 0} D(c) = \frac{1}{2} \sum_{\rho} \Delta_{\rho} \Delta_{\rho} r_{\rho}^{(0)}(c) , \qquad (80)$$

the detailed balance limit of the positive definite symmetric diffusion matrix, which in general reads

$$D(c) := \frac{1}{2} \sum_{\rho} \Delta_{\rho} \Delta_{\rho} r_{\rho}(c) = \frac{1}{2} \partial_{\pi}^{2} \mathcal{H}(c, \pi)|_{\pi = 0} .$$
 (81)

Equation (79) means that detailed balance dynamics admit only time-independent attractors, i.e., limit cycles and chaos are ruled out in equilibrium. As indicated in the second equality of (79), neglecting higher order derivatives to get a linear gradient descent dynamics is only possible close to fixed points – or in a continuous limit where  $\Delta_{\rho}$  becomes infinitesimal, as will be shown in Section V.A). We will show in Section IV.B that for small but not vanishing  $a_{\rho}$ , the quasi-potential is still given by thermodynamic quantities.

The splitting (71) with the condition (76) complies with the pre-GENERIC dynamics introduced in (Kraaij et al., 2018) – an extension of GENERIC (Öttinger, 2005). F entails a nonlinear gradient flow (Liero and Mielke, 2013; Mielke et al., 2016) since it can be recast as the product of the jump matrix with a gradient field in the space of transitions,

$$\mathcal{F}(c) = \sum_{\rho} \Delta_{\rho} \partial_{z_{\rho}} \psi(z)|_{z_{\rho} = \Delta_{\rho} \cdot \partial_{c} I_{ss}}, \tag{82}$$

where the potential  $\psi$  is defined for all  $z_{\rho} \neq 0$  as

$$\psi(z) = \sum_{\rho} r_{\rho} \left[ \text{Ei}(z_{\rho}) - \ln(|z_{\rho}|) - z_{\rho} \right],$$
 (83)

and Ei is the exponential integral. One can check that  $\psi(z)$  is convex and nonnegative with minimum at  $z \to 0$ , but it is not symmetric in  $z_{\rho}$ . These properties imply

$$\sum_{\rho} z_{\rho} \partial_{z_{\rho}} \psi \ge \psi(z) - \psi(0) \ge \min_{z} \psi(z) - \psi(0) = 0, \quad (84)$$

which corresponds to (78) with  $z_{\rho} = \Delta_{\rho} \cdot \partial_{c} I_{ss}$ .

We note that the drift field on any attractor reduces to the probability velocity

$$F(x^*(t)) = v_{ss}(x^*(t)), \quad \mathcal{F}(x^*(t)) = 0,$$
 (85)

since  $\partial_c I_{ss}(x^*(t)) = 0$  in (72). In the special case of time-independent attractors (i.e. fixed points), (85) becomes

<span id="page-12-2"></span>
$$F(x_{\gamma}^*) = v_{\rm ss}(x_{\gamma}^*) = \mathcal{F}(x_{\gamma}^*) = 0,$$
 (86)

i.e. the probability velocity nullifies on the fixed points.

<span id="page-12-5"></span><span id="page-12-1"></span>Finally, it is worth considering the drift field decomposition of the dual process,  $F^{\dagger}(c) = v_{\rm ss}^{\dagger}(c) - \mathcal{F}^{\dagger}(c)$ . We find that the dual dynamics reverts the velocity  $v_{\rm ss}^{\dagger}(c) = -v_{\rm ss}(c)$ , the velocity remains orthogonal to the gradient of the quasi-potential  $v_{\rm ss}^{\dagger} \cdot \partial_c I_{\rm ss} = 0$ , and the quasi-potential remains a Lyapunov function of the dual dynamics  $d_t I_{\rm ss}(x^{\dagger}(t)) = -\mathcal{F}^{\dagger}(x^{\dagger}(t)) \cdot \partial_c I_{\rm ss}|_{c=x^{\dagger}(t)} \leq 0$ .

## <span id="page-12-3"></span><span id="page-12-0"></span>F. Linearized dynamics and thermodynamics

The deterministic dynamics (45) linearized around a fixed point reads

<span id="page-12-8"></span>
$$d_t x(t) = (x(t) - x^*) \cdot \partial_c F(x^*) , \qquad (87)$$

where the matrix defining the relaxation coefficients is the Jacobian matrix of the dynamics. In turn, the nonadiabatic entropy production (67) around the fixed point reads

$$\lim_{V \to \infty} \langle \dot{\sigma}_{\text{na}} \rangle = (x(t) - x^*) \cdot \delta(x^*) \cdot (x(t) - x^*) , \quad (88)$$

where we introduced the matrix

<span id="page-12-7"></span><span id="page-12-6"></span>
$$S(c) := -\partial_c F(c) \cdot \partial_c^2 I_{ss},\tag{89}$$

which is symmetric and positive semidefinite when evaluated in a stable fixed point:

<span id="page-12-4"></span>
$$\mathcal{S}(x^*) = \partial_c^2 I_{ss}(x^*) \cdot D(x^*) \cdot \partial_c^2 I_{ss}(x^*) . \tag{90}$$

We used (71)-(73) with (77) and (81).

We now turn to a thermodynamically motivated linearization. Using (27) and (29), we can recast the drift field (46) as

$$F(c) = 2\sum_{\rho>0} \Delta_{\rho} \gamma_{\rho}(c) \sinh\left(\frac{1}{2}(-\Delta_{\rho} \cdot \partial_{c} \phi(c) + a_{\rho})\right)$$
(91)

which shows that F is not a linear function of the thermodynamic forces, unless some limiting cases are considered. First, when  $\Delta_{\rho}$  and  $a_{\rho}$  become small in an appropriate sense, as in the continuous-space limit treated in Sec. V.A. Second, when the nonconservative force  $a_{\rho}$  is small and only small displacements  $x(t) - x^{eq}$  from the equilibrium state  $x^{eq}$  are considered <sup>6</sup>. In this latter case, Eq. (91) can be linearized in  $x - x^{eq}$  and  $a_{\rho}$  to give

$$d_t x(t) = (x(t) - x^{eq}) \cdot \partial_c F^{(0)}(x^{eq}) + M^{(0)} \cdot f_{nc}, \quad (92)$$

where, as can be verified using (46), (37) and (80),

$$\partial_c F^{(0)}(x^{\text{eq}}) := \lim_{a_\rho \to 0} \partial_c F(x^{\text{eq}}) 
= -D^{(0)}(x^{\text{eq}}) \cdot \partial_c \partial_c \phi(x^{\text{eq}}) ,$$
(93)

and the matrix coupling the state dynamics to the fundamental nonconservative forces  $f_{nc}$  reads

$$M^{(0)} := \sum_{\rho > 0} \gamma_{\rho}^{(0)}(x^{\text{eq}}) \Delta_{\rho} \mathbb{X}_{\rho} . \tag{94}$$

The fact that the symmetric positive-definite matrix  $D^{(0)}(x^{eq})$  appears in (92) is a statement of the Onsager reciprocal relations (Forastiere *et al.*, 2022b; Onsager, 1931).

For  $a_{\rho} \neq 0$  the fixed point  $x^*$  of the perturbed near-equilibrium dynamics differs from the equilibrium fixed point  $x^{\text{eq}}$  and is given by

$$-(x^* - x^{eq}) \cdot \partial_c F^{(0)}(x^{eq}) = M^{(0)} \cdot f_{nc}, \qquad (95)$$

which we can use to write (92)

$$d_t x(t) = (x(t) - x^*) \cdot \partial_c F^{(0)}(x^{\text{eq}}).$$
 (96)

This shows that (93) is a fluctuation-dissipation relation, since  $\partial_c \partial_c \phi(x^{eq})$  is related to the scaled correlations of the state variable (see section IV) and  $\partial_c F^{(0)}(x^{eq})$  characterizes the rate of relaxation to equilibrium in an autonomous detailed balanced systems  $(a_{\rho} = 0)$ , as one can see using (96) with  $x^* = x^{eq}$ . For detailed balance systems we retrieve the setting of linear irreversible thermodynamics in which the only force is the (linearized) gradient of the Massieu potential (de Groot and Mazur, 1984; Prigogine, 1961).

Turning now to the dynamics of the scaled nonadiabatic entropy production, using (88) to lowest order in  $a_0$  and (93), we find that

$$\lim_{V \to \infty} \langle \dot{\sigma}_{\text{na}} \rangle = (x - x^*) \cdot \delta^{(0)}(x^{\text{eq}}) \cdot (x - x^*) \ge 0 , \quad (97)$$

with the  $a_{\rho} \to 0$  limit of the matrix (89)

$$S^{(0)}(c) = \partial_c \partial_c \phi(c) \cdot D^{(0)}(c) \cdot \partial_c \partial_c \phi(c) , \qquad (98)$$

<span id="page-13-1"></span>The scaled entropy production rate corresponding to (92) follows by expanding (61) at second order in  $x - x^{eq}$  and  $a_{o}$ ,

<span id="page-13-2"></span>
$$\lim_{V \to \infty} \langle \dot{\sigma} \rangle = \sum_{\rho > 0} \gamma_{\rho}^{(0)}(x^{\text{eq}}) y_{\rho}(x - x^{\text{eq}}) y_{\rho}(x - x^{\text{eq}}), \quad (99)$$

with the forces (nonconservative and conservative) acting along  $\rho$ 

<span id="page-13-7"></span><span id="page-13-5"></span>
$$y_{\rho}(c) := a_{\rho} - \Delta_{\rho} \cdot \partial_{c} \partial_{c} \phi(\mathbf{x}^{eq}) \cdot c .$$
 (100)

Rewriting  $x - x^{eq} = (x^* - x^{eq}) + (x - x^*)$  and using the stationary condition (95) to eliminate the mixed terms, (99) simplifies to

$$\lim_{V \to \infty} \langle \dot{\sigma} \rangle = (x - x^*) \cdot \delta^{(0)}(x^{\text{eq}}) \cdot (x - x^*)$$

$$+ \sum_{\rho > 0} \gamma^{(0)}(x^{\text{eq}}) y_{\rho}(x^* - x^{\text{eq}}) y_{\rho}(x^* - x^{\text{eq}}).$$
(101)

<span id="page-13-4"></span><span id="page-13-3"></span>In view of (97), this is nothing but the nonadiabaticadiabatic decomposition of the scaled entropy production (18) close to equilibrium. The first (nonadiabatic) contribution in the right-hand side of (101) describes the nonegative entropy produced as the system relaxes to the nonequilibrium steady state  $x^*$ . The second (adiabatic) one describes the nonnegative entropy production to sustain that steady state. Hence, the structure of steady state thermodynamics proposed by Oono-Paniconi is recovered here (Oono and Paniconi, 1998). Furthermore, we retrieve the minimum entropy production principle since (101) states that the fixed point  $x^*$  minimizes the entropy production rate among all states solutions of (92) (Jiu-li et al., 1984; Prigogine, 1961). In general, this result holds true only for states  $x^*$  close to detailed balance and linear dynamics. Nevertheless, we will present in Sec. VII.C a class of model systems in which the minimum entropy production principle is valid far from equilibrium. Additionally, computing the time derivative of (101) with the aid of (96),

$$d_t \lim_{V \to \infty} \langle \dot{\sigma} \rangle = 2d_t x \cdot \mathcal{S}^{(0)}(x^{\text{eq}}) \cdot (x - x^*)$$

$$= -2z \cdot \partial_c \partial_c \phi(x^{\text{eq}}) \cdot z^T < 0.$$
(102)

<span id="page-13-6"></span>with  $z = (x - x^*) \cdot \partial_c F^{(0)}(x^{eq})$ , we conclude that the entropy production rate monotonically decreases along solutions of (96) (Maes and Netočný, 2015).

<span id="page-13-0"></span><sup>&</sup>lt;sup>6</sup> We restrict to autonomous dynamics for simplicity.

## <span id="page-14-0"></span>IV. MACROSCOPIC FLUCTUATIONS

In this section we describe the asymptotic stochastic dynamics and the associated thermodynamics.

### <span id="page-14-1"></span>A. Dynamics of the state variable

The macroscopic master equation (30) can be recast as

$$\partial_t p(c,t) = V \mathcal{H}\left(c, -V^{-1}\partial_c\right) p(c,t), \tag{103}$$

by introducing the (scaled) generator of the stochastic dynamics

$$\mathcal{H}(c, -V^{-1}\partial_c) = \sum_{\rho} \left[ e^{-V^{-1}\Delta_{\rho} \cdot \partial_c} - 1 \right] r_{\rho}(c), \quad (104)$$

which contains the operator  $e^{-V^{-1}\Delta_{\rho}\cdot\partial_{c}}$  that shifts by  $-V^{-1}\Delta_{\rho}$  the argument of the function it is applied to. Its identification allows us to switch to an equivalent representation of the stochastic dynamics, consisting in the probability density of stochastic trajectories conditioned on the initial value c(0), namely, the ordered set of states c(t) in some time interval  $[0,\tau] \ni t$  (De Dominicis and Peliti, 1978; Doi, 1976; Grassberger and Manfred, 1980; Peliti, 1985; Weber and Frey, 2017):

$$P[\{c(t)\}|c(0)] = \int \mathfrak{D}\pi \, e^{V \int_0^{\tau} dt [-\pi(t) \cdot d_t c(t) + \mathcal{H}(c(t), \pi(t))]}$$
$$= \int \mathfrak{D}\pi \, e^{V \mathcal{A}[\{c(t)\}, \{\pi(t)\}]}. \tag{105}$$

Here  $\pi$  is an auxiliary variable to integrate out in order to pass from the (Poissonian) generating function of the transitions,  $e^{V\int_0^{\tau} dt \mathcal{H}(c,\pi)}$ , to the probability distribution of trajectories (Gaveau et al., 1999; Lefevre and Biroli, 2007). Equation (105) can be formally obtained by applying a time-slicing to the solution of (103) – that is  $p(c,t)=e^{V\int_0^{\tau} dt \mathcal{H}(c,-V^{-1}\partial_c)}p(c,0)$ , with a time-ordered exponential – very analogously to the derivation of the quantum path integral representation of the Schrödinger equation <sup>7</sup>. Because of the appearance of V in the exponential, the functional integral in (105) is dominated for large V by the trajectories that maximize the action functional (Dykman et al., 1994; Lazarescu et al., 2019; Smith, 2011)

$$\mathcal{A} = \int_0^\tau dt \left[ -\pi(t) \cdot d_t c(t) + \sum_\rho r_\rho(c(t)) (e^{\Delta_\rho \cdot \pi(t)} - 1) \right],$$
(106)

supplemented by the appropriate boundary conditions (Lazarescu *et al.*, 2019). Namely, the solutions of the Hamiltonian equations

<span id="page-14-6"></span>
$$d_t c = \partial_{\pi} \mathcal{H}(c, \pi) = \sum_{\rho} \Delta_{\rho} r_{\rho}(c) e^{\Delta_{\rho} \cdot \pi}$$

$$d_t \pi = -\partial_c \mathcal{H}(c, \pi) = -\sum_{\rho} \partial_c r_{\rho}(c) \left( e^{\Delta_{\rho} \cdot \pi} - 1 \right),$$
(107)

<span id="page-14-3"></span>are the most likely paths, which when inserted into (106), give their (exponentially small) probability

<span id="page-14-11"></span>
$$P[\{c(t)\}|c(0)]p(c(0),0) \approx e^{V\left(\mathfrak{sl}[\{c(t),\pi(t)\}]-I(c(0),0)\right)}.$$
(108)

<span id="page-14-9"></span>While small fluctuations can be described by Langevin dynamics (whose range of validity is discussed in IV.C), large deviations from the average dynamics (45) are correctly described only by (107). In particular, an important class of solutions is that of fluctuating trajectories, called instantons (Coleman, 1988), that connect in a long (formally infinite) time the attractor  $x^*$  to an arbitrary state c in the same basin. These trajectories, starting from a stable fixed point<sup>8</sup>,  $c(0) = x^*_{\gamma}$ , are characterized by  $\pi(0) = 0$  and thus  $\mathcal{H}(c(t), \pi(t)) = 0$  for all t, since  $\mathcal{H}(c) = 0$  is a constant of motion in absence of explicit time dependence of the transition rates  $r_{\rho}$ . It follows from (52) that  $\pi = \partial_c I_{ss}$  on the manifold  $\mathcal{H}(c) = 0$ . Hence, instantons are solutions of

<span id="page-14-10"></span><span id="page-14-2"></span>
$$d_t c(t) = \sum_{\rho} \Delta_{\rho} r_{\rho}(c(t)) e^{\Delta_{\rho} \cdot \partial_c I_{ss}(c(t))} = -F^{\dagger}(c(t)) \quad (109)$$

namely, they are the time reversal of the dual-dynamics trajectories  $x^{\dagger}(t)$  introduced in (53).

As a consequence, the long-time transition probability from  $x_{\gamma}^*$  to c – that is the local stationary probability in the basin of attraction  $\gamma$ ,  $p_{\rm ss}^{(\gamma)}(c)$  – is related at the leading order to the difference of the local quasi-potential (Bouchet and Reygner, 2016),

<span id="page-14-8"></span>
$$\lim_{t \to \infty} P(c(t) = c | c(0) = x^*) = p_{ss}^{(\gamma)}(c)$$

$$\approx e^{-V \int_{c(0) = x^*}^{c(\infty) = c} dt \pi(t) \cdot d_t c(t)} = e^{-V [I_{ss}^{(\gamma)}(c) - I_{ss}^{(\gamma)}(x_{\gamma}^*)]}.$$
(110)

We note that the integral in (110) can be multivalued. This means that a given state c can correspond to different values of  $\pi$  on the instanton. Such Hamiltonian trajectory generates folds, called caustics, when projected onto the state space (Bouchet *et al.*, 2016; Graham and

<span id="page-14-4"></span>More rigorously, one can see (106) as the action associated to the Hamilton-Jacobi equation defined by (32).

<span id="page-14-7"></span><span id="page-14-5"></span><sup>8</sup> In infinite time, the most likely trajectory starting from any point of the attractor displays an initial relaxation to the local stable fixed point in which the velocity is null. This deterministic relaxation nullifies the action, thus can be neglected and the initial condition can be directly placed in the fixed point.

Tél, 1985; Luchinsky et al., 1998; Maier and Stein, 1993). In this case,  $I_{ss}^{\gamma}(c)$  is obtained by taking the minimum value over  $\pi$  of the integral in  $(110)^9$ . Since such minimizer can jump from one branch of the instanton to another when we move away from c in different directions of the state space, the local quasi-potential is generally not differentiable in such points (unless the dynamics is detailed balance), a phenomenon called Lagrangian phase transition (Bertini et al., 2010).

## <span id="page-15-0"></span>**B. Fluctuating Thermodynamics**

In this subsection, we formulate the second law along single fluctuating trajectories and use it to derive a bound on the variation of the rate function. To do so, we first present the asymptotic dynamics that describe the evolution of the states and the single transitions jointly. Because of (28), the transition flux is expected to asymptotically scale linearly with V, i.e.,  $J_{\rho}(t) = V j_{\rho}(t) + o(V)$ , with  $j_{\rho}(t)$  independent of V. So, dividing both sides of (1) by V, we obtain the asymptotic stochastic evolution of the state vector

$$d_t c(t) = \sum_{\rho} \Delta_{\rho} j_{\rho}(t). \tag{111}$$

Since the flux  $j_{\rho}(t)$  can be described by a Poissonian distribution conditioned on the present state c(t) with average  $r_{\rho}(c(t))$ , the average value of (111) coincides with the equation (42) for the mean concentration obtained from the asymptotic form of the master equation (103).

Using the scaling of the flux  $J_{\rho}$  and of the probability distribution (31), the scaled entropy production rate (8) takes the asymptotic form

<span id="page-15-3"></span>
$$\dot{\sigma}(t) = \sum_{\rho} j_{\rho}(t) \sigma_{\rho}(c(t)) + d_t I(c(t), t). \tag{112}$$

The decomposition (17) becomes

<span id="page-15-4"></span>
$$\dot{\sigma}(t) = \dot{\sigma}_{\rm nc}(t) + \dot{\sigma}_{\rm d}(t) + d_t(I - \phi)(c(t), t), \tag{113}$$

namely, it displays the scaled dissipation rate due to nonconservative forces  $\dot{\sigma}_{\rm nc}(t) := \sum_{\rho} j_{\rho}(t) a_{\rho}$  and the scaled dissipation rate needed to parametrically drive the reference equilibrium,  $\dot{\sigma}_{\rm d}(t) := -\partial_t \phi(c,t)|_{c=c(t)}$ , plus the total time derivative of the scaled stochastic Massieu potential  $I(c,t) - \phi(c,t)$ . Note the presence of the scaled variation of self-information on the righthand side of (112) and (113). While it vanishes on average, it is nonzero along macroscopic fluctuating trajectories so that

$$\lim_{V \to \infty} \frac{1}{V} S_{\text{sys}}(n(t), t) = I(c(t), t) + s_{\text{int}}(c(t)).$$
 (114)

The decomposition (18) becomes

<span id="page-15-7"></span>
$$\dot{\sigma}(t) = \sum_{\rho} j_{\rho}(t) \sigma_{\rho}^{\text{ad}} + \dot{\sigma}_{\text{na}}, \qquad (115)$$

using the scaled adiabatic entropy production of each transition, (41), and the scaled nonadiabatic entropy production rate

$$\dot{\sigma}_{\rm na}(t) := d_t [I(c(t), t) - I_{\rm ss}^t(c(t))] + \partial_t I_{\rm ss}^t(c)|_{c=c(t)}.$$
 (116)

Again, for autonomous systems at stationarity  $I(c,t) = I_{ss}(c) = I_{ss}^t(c)$ , so that (116) is identically zero and the scaled adiabatic entropy production rate

<span id="page-15-6"></span><span id="page-15-5"></span>
$$\dot{\sigma}_{\rm ad}(t) = \sum_{\rho} j_{\rho}(t) \sigma_{\rho}^{\rm ad}(t)$$
 (117)

equals  $\dot{\sigma}(t)$ . And for nonautonomous detailed balance dynamics  $I_{\rm ss}^t(c) = \phi(c,t) + {\rm const}$ , so that (117) is identically zero for all  $\rho$  and the scaled nonadiabatic entropy production rate  $\dot{\sigma}_{\rm na}(t)$  equals  $\dot{\sigma}(t)$ . The adiabatic-nonadiabatic decomposition (115) can be used to provide a strengthening of the second law of thermodynamics. This follows from averaging (116) and taking the limit  $V \to \infty$  combined with  $\langle \dot{\sigma}_{\rm na} \rangle \geq 0$  and  $\langle \dot{\sigma}_{\rm ad} \rangle \geq 0$ , which yield

<span id="page-15-2"></span>
$$\lim_{V \to \infty} \langle \dot{\sigma}(x(t)) \rangle \ge -d_t I_{\rm ss}^t(x(t)) + \partial_t I_{\rm ss}^t(c)|_{c=x(t)} \ge 0.$$
(118)

In particular, for autonomous relaxation dynamics the equality  $I_{\rm ss}^t = I_{\rm ss}$  simplifies (118) to (Freitas and Esposito, 2022a)

<span id="page-15-9"></span><span id="page-15-8"></span>
$$\lim_{V \to \infty} \langle \dot{\sigma}(x(t)) \rangle \ge -d_t I_{\rm ss}(x(t)) \ge 0, \tag{119}$$

where the last inequality is the Lyapunov property (48). Equation (119) is the nonlinear extension of (??) and first appeared in (Gaveau et al., 1998) for reaction-diffusion systems. Note that  $I_{\rm ss}$  is replaced by the local quasipotential  $I_{\rm ss}^{(\gamma)}$  if the initial condition of the dynamics is localized on a single basin of attraction  $\gamma$ , a fact that will be used in Sec. IV.H. The first inequality in (119) becomes tight when  $a_{\rho}$  is infinitesimal (Falasco and Esposito, 2021; Freitas and Esposito, 2022a). In that limit the quasi-potential is still determined by thermodynamics. Indeed, a first order expansion in  $a_{\rho}$  of (34) gives within each basin  $\gamma$ 

<span id="page-15-10"></span>
$$I_{\rm ss}^{(\gamma)}(c) = \phi(c) + \sigma_{\rm nc}^{(0)}(c, x_{\gamma}^{\rm eq}),$$
 (120)

where

$$\sigma_{\rm nc}^{(0)}(c, x_{\gamma}^{\rm eq}) := \int_{x(0)=c}^{x(\infty)=x_{\gamma}^{\rm eq}} dt \sum_{\rho} r_{\rho}^{(0)}(x(t)) a_{\rho} \qquad (121)$$

is the dissipation of nonconservative forces along the so-

<span id="page-15-1"></span> $<sup>^9</sup>$  A caustic, in analogy with geometrical optics, is then the set of states c with multiple minimizers.

lution of detailed-balanced deterministic dynamics

$$d_t x(t) = \sum_{\rho} \Delta_{\rho} r_{\rho}^{(0)}(x(t)), \qquad (122)$$

connecting x(0) = c to the equilibrium fixed point  $x(t \to \infty) = x_{\gamma}^{\text{eq}}$  (Falasco and Esposito, 2021; Freitas et al., 2021b). Note that (120) is valid for any c in the basin of attraction  $\gamma$ , not only close to  $x_{\gamma}^*$ . The linear response formula (120) yields the large-deviation form of McLennan-Zubarev probability distribution function (Colangeli et al., 2011; Maes and Netocny, 2010; McLennan Jr, 1959; Zubarev, 1994) by replacing the average of the near-equilibrium dissipation over all trajectories with its most likely value.

By relating the macroscopic entropy production during relaxation to steady state macroscopic fluctuations, the inequalities (118) and (119) can thus be seen as generalized fluctuation-dissipation relations. Standard fluctuation-dissipation relations are recovered using a parabolic approximation of  $I_{\rm s}^{(\gamma)}(c)$  around an equilibrium fixed point (Freitas et al., 2021b), which is equivalent to the alternative derivation based on the Langevin approximation given in Sec. IV.C. Finally, the nonadiabatic entropy production provides a second (upper) bound valid for rare fluctuations (instanton), that is derived in Appendix A and will be used in Section IV.H.

## <span id="page-16-0"></span>C. Gaussian fluctuations

When comparing (107) with (45), we recognize that the solution  $\pi(t) = 0$ , giving  $\mathcal{A} = 0$ , corresponds to the deterministic trajectories. This suggests that small fluctuations around the deterministic behavior are characterized by small values of  $\pi(t)$ . In particular, Gaussian fluctuations around each deterministic solution can be obtained by expanding the action (106) around  $\pi(t) = 0$  and c(t) = x(t) to quadratic order in  $\pi(t)$  and  $\varrho(t) := c(t) - x(t)$ , respectively:

$$\mathcal{A}_{G} = \int_{0}^{\tau} dt \left[ -\pi \cdot d_{t} \varrho + \varrho \cdot \partial_{c} F(x) \cdot \pi + \pi \cdot D(x) \cdot \pi \right]. \tag{123}$$

This approximation holds only for times much shorter than the escape time from a basin of attraction, which will be discussed in Sec. IV.H. It is equivalent to the first order in van Kampen's system size expansion of (30) (Van Kampen, 2007), known as linear noise approximation (Thomas and Grima, 2015). The action (123) contains the scaled generator

$$\mathcal{H}_{\text{FPE}}(\rho, \pi) = \rho \cdot \partial_c F(x) \cdot \pi + \pi \cdot D(x) \cdot \pi, \tag{124}$$

<span id="page-16-6"></span>that depends parametrically on time via x(t) and corresponds to the Fokker-Planck equation

$$\partial_t p(\varrho, t) = -\partial_\varrho \cdot \left[ \varrho \cdot \partial_c F(x) p(\varrho, t) - \frac{D(x)}{V} \partial_\varrho p(\varrho, t) \right]. \tag{125}$$

The associated linear Langevin equation with Gaussian additive noise  $\eta$  reads

<span id="page-16-5"></span><span id="page-16-2"></span>
$$d_t \varrho(t) = \varrho(t) \cdot \partial_c F(x(t)) + \frac{1}{\sqrt{V}} \eta(t). \tag{126}$$

Here  $\eta$  is delta-correlated, with mean zero and covariance matrix 2D(x(t)) defined in (81) and  $\partial_c F$  is the Jacobian matrix of the deterministic drift F given in (46). Equation (126) also amounts to a quadratic approximation of the rate function as

$$I(\varrho,t) = \frac{1}{2}\varrho \cdot \partial_c^2 I(x(t)) \cdot \varrho + O(\varrho^3) , \qquad (127)$$

where the scaled covariance matrix  $\mathscr{C} = (\partial_c^2 I)^{-1}$  is obtained multiplying (126) by  $\varrho(t)$  and averaging over  $\eta$ ,

<span id="page-16-3"></span>
$$\frac{d\mathscr{C}}{dt}(t) = \partial_c F^T(x(t)) \cdot \mathscr{C}(t) + \mathscr{C}(t) \cdot \partial_c F(x(t)) 
+ 2D(x(t)),$$
(128)

with  $\partial_c F^T$  the transpose of  $\partial_c F$  (Tomita and Tomita, 1974). When the expansion is carried out around a limit cycle  $x(t) = x^*(t)$ , (126) allows one to study transversal and longitudinal Gaussian fluctuations (Boland et al., 2008; Dykman et al., 1993; Sheth et al., 2018; Vance and Ross, 1996). The latter are unsuppressed, i.e., free diffusion takes place along the limit cycle with the effective diffusion coefficient proportional to  $\tau_{\rm p}'/2V$ ,  $\tau_{\rm p}'$  being the period variation of the Hamiltonian orbit upon a small perturbation of  $\mathcal{H}_{\text{FPE}}$  (Gaspard, 2002a,b). These fluctuations are stochastic Goldstone modes since they cause the decay in time of correlation functions and ultimately restore the time-translation invariance of the microscopic dynamics, which is spontaneously broken in the limit  $V \to \infty$  (Smith and Morowitz, 2016). Recently, the relation between the number of coherent oscillations and the thermodynamic force (Remlein et al., 2022) – or the entropy production (Marsland III et al., 2019) – has been studied.

<span id="page-16-1"></span>When the expansion is performed around a stable fixed point  $x_{\gamma}^*$ , (128) simplifies to the steady state fluctuation-dissipation theorem (Dykman *et al.*, 1994; Keizer, 1978; Prost *et al.*, 2009).

<span id="page-16-4"></span>
$$\partial_c F^T(x_{\gamma}^*) \cdot \mathcal{C}_{ss} + \mathcal{C}_{ss} \cdot \partial_c F(x_{\gamma}^*) = -2D(x_{\gamma}^*) , \quad (129)$$

also known as Lyapunov equation, with  $\mathscr{C}_{ss} = (\partial_c^2 I_{ss})^{-1}(x_{\gamma}^*)$ . Multiplying (129) by  $\mathscr{C}_{ss}^{-1}$  and taking the

trace, we obtain the relation

$$\lambda_{\gamma} = D(x_{\gamma}^*) : \mathcal{C}_{ss}^{-1} \tag{130}$$

connecting the volume contraction rate (47) on the attractor,  $\lambda_{\gamma} := -\partial_c \cdot F(x_{\gamma}^*)$ , to the state and noise covariance.

Close to detailed balance dynamics, (126) can be recast using (95) and (93) as

$$d_t \varrho(t) = \varrho(t) \cdot \partial_c F^{(0)}(x^{\text{eq}}) + \frac{1}{\sqrt{V}} \eta(t), \qquad (131)$$

which adds to (96) small fluctuations driven by the Gaussian noise  $\eta$  with covariance equal to  $2D^{(0)}$ . For  $a_{\rho} = 0$  (i.e.  $x^* = x^{\text{eq}}$ ), (131) corresponds to the linear theory of fluctuations introduced by Onsager and Machlup (Onsager and Machlup, 1953), and (129), using (93), reduces to  $\mathscr{C}_{cc}^{-1} = \partial_a^2 \phi(x^{\text{eq}})$ .

## <span id="page-17-0"></span>D. Truncation of the Kramers-Moyal expansion

It is worth stressing that an expansion of (106) which is quadratic in  $\pi(t)$  but retains nonlinearities in c(t) is equivalent to an uncontrolled truncation of the full Kramers-Moyal expansion of the master equation (Kampen, 1961). Note that the derivation of (32) hinges on the Taylor expansion of the rate function as

$$p(c - V^{-1}\Delta_{\rho}, t) = p(c, t)e^{\Delta_{\rho} \cdot \partial_{c}I(c, t) + O(V^{-1})}, \quad (132)$$

which is in general different from a direct expansion of the probability density

$$p(c - V^{-1}\Delta_{\rho}, t) \approx \left[1 - \frac{\Delta_{\rho}}{V} \cdot \partial_{c} + \frac{1}{2V^{2}} (\Delta_{\rho} \cdot \partial_{c})^{2}\right] p(c, t).$$
(133)

Equation (133) wrongly assumes that p(c,t) remains a smooth function as V approaches infinity and reduces (103) to the Fokker-Planck equation

$$\partial_t p(c,t) \approx -\partial_c \cdot \left\{ F(c)p(c,t) - \frac{1}{V}\partial_c \cdot [D(c)p(c,t)] \right\}.$$
(134)

Albeit generally incorrect, this approximation is often used. Equation (134) becomes accurate if  $\Delta_{\rho}$  or  $\partial_{c}I(c,t)$  are infinitesimal, namely, when a certain continuous limit exists (as in Sec.V.A) or when only Gaussian fluctuations are considered, as in Sec. IV.C. The latter case corresponds to the linearization around a deterministic solution x of the drift field and the diffusion matrix in (134), which yields (125).

Equation (134) corresponds to the Ito nonlinear Langevin equation (Gillespie, 2000; Vastola and Holmes,

<span id="page-17-8"></span>2020)

<span id="page-17-5"></span>
$$d_t c(t) = F(c(t)) + \frac{1}{\sqrt{V}} \eta(t)$$
 (135)

<span id="page-17-2"></span>with multiplicative Gaussian noise  $\eta(t)$  having covariance 2D(c(t)). This equation in general does not correctly captures the fluctuations of c(t) beyond the Gaussian level. Indeed, as already discussed for some specific models (Gaveau et al., 1997; Gopal et al., 2022; Hänggi and Jung, 1988; Vellela and Qian, 2009a), the approximation (135) mistakes the rate function  $I_{\rm ss}$  away from  $x_{\gamma}^*$  and  $x_{\nu}$ . The discrepancy can be made explicit for one-step processes in one dimension, i.e.  $\Delta_{\pm\rho}=\pm 1$  and N=1, whose exact- and diffusion-approximated rate function can be obtained analytically. For such systems (34) reads

$$\sum_{\rho>0} r_{\rho}(c) (e^{d_c I_{ss}(c)} - 1) = \sum_{\rho>0} r_{-\rho}(c) (1 - e^{-d_c I_{ss}(c)}),$$
(136)

which is solved by

<span id="page-17-9"></span><span id="page-17-7"></span><span id="page-17-6"></span>
$$d_c I_{ss}(c) = \ln \frac{\sum_{\rho > 0} r_{-\rho}(c)}{\sum_{\rho > 0} r_{\rho}(c)},$$
(137)

while the expansion of (136) to second order in  $d_c I_{ss}$  (corresponding to (135)) has solution

$$d_c I_{\text{NLE}}(c) = \frac{\sum_{\rho>0} [r_{-\rho}(c) - r_{\rho}(c)]}{\frac{1}{2} \sum_{\rho>0} [r_{\rho}(c) + r_{-\rho}(c)]} = -\frac{F(c)}{D(c)}, \quad (138)$$

<span id="page-17-3"></span>as can be directly verified by substitution. With the subscript NLE we denote hereafter quantities corresponding to the nonlinear Langevin equation (135). Hence, for this simple model it is easy to see that  $I_{\rm NLE}(c) \neq I_{\rm ss}(c)$  unless c is infinitesimally close to  $x_{\gamma}^*$  or  $x_{\nu}$ . Indeed, in a neighborhood of the fixed points where  $F = \varepsilon \to 0$ , it holds that  $\sum_{\rho>0} r_{-\rho} = \sum_{\rho>0} r_{\rho} + \varepsilon$  and thus  $d_c I_{\rm ss} = \varepsilon/(\sum_{\rho>0} r_{\rho}) = d_c I_{\rm NLE}$  at first oder in  $\varepsilon$ . The use of equation (137) will be exemplified in Secs. VII.A and VII.B.1.

## <span id="page-17-4"></span><span id="page-17-1"></span>E. Informational entropy production of Langevin equations

The nonlinear Langevin approximation of Sec. IV.D is also thermodynamically inconsistent in addition to being incorrect to describe fluctuations beyond the Gaussian level. Here we derive the apparent entropy production associated to (135) and show that its mean value differs from (61). In particular, it vanishes in any stationary state. In Sec. IV.I we will also explicitly show that (135) breaks the fluctuation theorem for currents. As discussed in Sec. V.A, the nonlinear Langevin approximation of an underlying jump process is accurate only in a continuous limit that restores the validity of the Einstein relation.

Given a nonlinear Langevin equation of the type (135), we can write the associated path probability  $P[\{c(t)\}|c(0)]$  starting from the conditional Gaussian weight of the noise  $P[\{\eta(t)\}|c(t)] \propto e^{-\frac{1}{4}\int_0^{\tau}dt\eta(t)\cdot D^{-1}(c(t))\cdot\eta(t)}$  and implementing a change of variables  $\eta(t)\mapsto c(t)$  (Wiegel, 1986; Zinn-Justin, 2002):

$$P[\{c(t)\}|c(0)] \simeq e^{-\frac{V}{4} \int_0^{\tau} dt [d_t c - F(c)] \cdot D^{-1}(c) \cdot [d_t c - F(c)]}.$$
(139)

Here we disregarded the functional Jacobian  $\left|\frac{\delta\eta}{\delta c}\right|$  that is sub-exponential in V. This is equivalent to the statement that the choice of the stochastic calculus to handle (135) is irrelevant at leading order in V. Also the dependence on time are not explicitly written to avoid clutter. Note that the exponent in (139) can be made linear in  $d_t c - F$  by means of a Hubbard-Stratonovich transformation (Negele, 2018), i.e. by introducing the auxiliary Gaussian field  $\pi(t)$  such that

$$P[\{c(t)\}|c(0)] \simeq \int \mathfrak{D}\pi \, e^{-V \int_0^{\tau} dt [\pi \cdot D \cdot \pi - i\pi \cdot (d_t c - F)]},$$
 (140)

with  $\mathfrak{D}\pi$  the appropriately normalized measure.

The path probability associated to a time reversed trajectory satisfying (135) is obtained by swopping the sign of the time derivative in (139),

$$\overline{P}[\{c(t)\}|c(0)] \approx e^{-V\frac{1}{4}\int_0^{\tau} dt [d_t c + F] \cdot D^{-1} \cdot [d_t c + F]}.$$
 (141)

The scaled entropy production estimated by (135) is thus given by the log ratio between forward and time-reversed path probabilities, (139) and (141). It reads, using (31) for the initial and final probability densities (with the truncation of IV.D)

<span id="page-18-3"></span>
$$\sigma_{\text{NLE}} := \frac{1}{V} \ln \frac{P[\{c(t)\}|c(0)]}{\overline{P}[\{c(t)\}|c(t)]} + I_{\text{NLE}}(c(\tau), \tau) - I_{\text{NLE}}(c(0), 0).$$
(142)

This is only an apparent entropy production inferred solely from the dynamics in configuration space. We already explained in Sec. IV the shortcoming of the boundary term in (142). We now show that the informational entropy flow, the first line of (142), is also flawed. Using (139), we obtain for the rate of (142)

$$\dot{\sigma}_{\text{NLE}} = d_t c(t) \cdot D^{-1}(c(t)) \cdot F(c(t)) + d_t I_{\text{NLE}}(c(t), t).$$
(143)

Taking its average and replacing  $d_t c$  by means of (135), we arrive at the expression

$$\lim_{V \to \infty} \langle \dot{\sigma}_{\text{NLE}} \rangle = F(x(t)) \cdot D^{-1}(x(t)) \cdot F(x(t)), \quad (144)$$

recalling that 
$$\left\langle \eta(t)\cdot D^{-1}(c(t))\cdot F(c(t))\right\rangle \ = \ O(V^{-1})$$
 .

Equation (144) is the Kullback-Leibler divergence between forward and backward probability densities of paths solutions of (135), i.e. it is the diffusive approximation of (22). Correlations between fluctuations are at least of order  $O(V^{-1})$  and thus do not appear in the macroscopic limit. Hence, (144) is also the mean entropy production rate of the linear Langevin equation desribed in IV.C, once F is linearized around a stable state.

<span id="page-18-1"></span>In any stationary state the apparent entropy production rate vanishes identically,

<span id="page-18-7"></span>
$$\lim_{V \to \infty} \langle \dot{\sigma}_{\text{NLE}} \rangle = F(x^*) \cdot D^{-1}(x^*) \cdot F(x^*) = 0, \quad (145)$$

since  $F(x^*) = 0$  by definition of fixed point. Namely, the macroscopic entropy production predicted by a Langevin dynamics misses altogether the contribution needed to sustain a time-independent attractor, i.e. the quantity  $\langle \dot{\sigma}_{\gamma} \rangle$  defined in Sec. VI. In particular, if we consider small deviations from a stable fixed point, (144) becomes

<span id="page-18-6"></span>
$$\lim_{V \to \infty} \langle \dot{\sigma}_{\text{NLE}} \rangle \tag{146}$$

$$= (x - x_{\gamma}^*) \cdot \partial_c F(x_{\gamma}^*) \cdot D^{-1}(x_{\gamma}^*) \cdot \partial_c F(x_{\gamma}^*) \cdot (x - x_{\gamma}^*),$$

<span id="page-18-2"></span>that reduces to the first term of (101) close to detailed balance dynamics. Therefore,  $\langle \dot{\sigma}_{\rm NLE} \rangle$  misses the adiabatic component and thus underestimates the thermodynamic entropy production rate. We emphasize that the entropy production has the same formal structure for linear and nonlinear Langevin equations, in the sense that it is a quadratic form of the forces – the Langevin equation linearizes the fluxes in the forces. For the linear Langevin equation, the force is further linearized in the displacement of the state c from its fixed point.

## <span id="page-18-0"></span>F. Nonreciprocity

In conservative mechanical systems that follow Newton's third law of action and reaction, interactions between different degrees of freedom are said to be reciprocal. This holds true when they are brought in contact with thermal reservoirs in such a way that their stochastic dynamics remain detailed balanced. Nonreciprocity arises in presence of dissipative processes, be them nongradient forces or effective time-delayed interactions (Dinelli et al., 2023; Fruchart et al., 2021; Ivlev et al., 2015; Loos and Klapp, 2020; Steffenoni et al., 2016). In stochastic systems characterized by the deterministic asymptotic dynamics (45), nonreciprocity can be defined by means of the Jacobian matrix,

<span id="page-18-5"></span>
$$\lim_{V \to \infty} \frac{\partial \dot{c}}{\partial c}(t) = \partial_c F(x(t)), \tag{147}$$

<span id="page-18-4"></span>which measures the variation rate of a degree of freedom to perturbations in a different one. The trace of (147)

gives the variation rate of phase space volumes introduced in (47). To evaluate (147) in a stable fixed point, we use the decomposition (74). We simplify the gradient part of the drift as

$$\partial_c \mathcal{F}(x^*) = \mathcal{M}(x^*) \cdot \partial_c^2 I_{\rm ss}(x^*) + \partial_c \mathcal{M}(x^*) \cdot \partial_c I_{\rm ss}(x^*)$$
$$= D(x^*) \cdot \partial_c^2 I_{\rm ss}(x^*). \tag{148}$$

while for the dissipative part we employ the property (77) to write  $\partial_c v_{\rm ss}(x^*) =: \varpi = \mathcal{N}(x^*) \cdot \mathscr{C}_{\rm ss}^{-1}$ . The matrix  $\varpi$  has purely imaginary eigenvalues, referred to as cycling frequencies and proposed as empirical quantities to measure irreversibility (Battle *et al.*, 2016; Mura *et al.*, 2018). We thus obtain

$$\partial_c F(x^*) = -D(x^*) \cdot \mathcal{C}_{ss}^{-1} + \varpi. \tag{149}$$

Taking the trace, we regain the relation for the phasespace contraction rate (130). Factoring out the kinetic matrix that sets the time scale of the interactions, we can define the macroscopic response matrix

$$\Re \equiv D^{-1}(x^*) \cdot \partial_c F(x^*) = -\mathscr{C}_{ss}^{-1} + D^{-1}(x^*) \cdot \varpi.$$
(150)

For detailed balanced dynamics,  $\varpi = 0$ , which implies that  $\Re$  is symmetric:

$$\mathcal{R} = -\partial_c^2 \phi(x^{\text{eq}}). \tag{151}$$

Hence, we can extract a measure of nonreciprocity of the coupling between two degrees of freedom from the antisymmetric part of (150),

$$\Re - \Re^T = D^{-1}(x^*) \cdot \varpi - \varpi^T \cdot D^{-1}(x^*). \tag{152}$$

If multiple fixed points exist, such relation is valid for each attractor for t much smaller than the escape time from its basin.

#### <span id="page-19-0"></span>G. Irreversibility of relaxation and instanton

Under the condition of detailed balance,  $a_{\rho} = 0$ , the instantons c(t) that solve (107) are the time reversal of the deterministic trajectories solutions of (45):

<span id="page-19-3"></span>
$$d_t c(t) = -d_t x(t). \tag{153}$$

This relation readily follows from the equality  $r_{\rho}^{\dagger}=r_{\rho}$  valid for detailed balance systems. This result is ultimately a consequence of the symmetry

$$\mathcal{H}(c,\pi) \underset{a_c=0}{=} \mathcal{H}(c, -\pi + \partial_c \phi), \tag{154}$$

that holds in presence of detailed balance (Dykman *et al.*, 1994), and is responsible for the validity of (120) (Falasco

and Esposito, 2021). Its generalization will lead to the fluctuation theorems discussed in Sec. IV.I.

Instead, when the dynamics is not detailed balanced,  $a_{\rho} \neq 0$ , the adiabatic entropy production quantifies the time-asymmetry between relaxational and instantonic trajectories. Equation (153) is replaced by

$$d_t c(t) = \sum_{\rho} \Delta_{\rho} r_{\rho}(c(t)) e^{\Delta_{\rho} \cdot \pi(t)} = -F^{\dagger}(c(t))$$

$$= -\sum_{\rho} \Delta_{\rho} r_{\rho}(c(t)) e^{-\sigma_{\rho}^{\text{ad}}(t)} = -d_t x(t) + O(\sigma_{\rho}^{\text{ad}})$$
(155)

where we used  $\pi(t) = \partial_c I_{ss}(c(t))$  on the manifold  $\mathcal{H} = 0$ , the dual drift (51), the relation

<span id="page-19-4"></span>
$$r_{\rho}^{\dagger}(c) = r_{\rho}(c)e^{-\sigma_{\rho}^{\mathrm{ad}}(c)} \tag{156}$$

<span id="page-19-2"></span>valid for autonomous dynamics, and the relabelling of the transitions  $\rho \mapsto -\rho$ . We point out two important aspects of the instanton dynamics. First, in the case of Gaussian noise the time-reversed dual dynamics that defines the instanton is a simple transformation of the drift field which flips the sign of the gradient part (Bertini et al., 2015; Chernyak et al., 2006), i.e.  $-D(c) \cdot \partial_c I_{ss}(c) \mapsto D(c) \cdot \partial_c I_{ss}(c)$ , without changing the probability velocity  $v_{\rm ss}(c)$ . Away from the diffusive limit, the dual dynamics has to be implemented at the level of single transition rates, i.e.,  $r_{\rho} \mapsto r_{\rho}^{\dagger}$ , rather than directly on quantities defined in configuration space. Second, the dual transition rates  $r_{\rho}^{\dagger}$  do not have in general the same functional form of the transition rate  $r_{\rho}$  unless detailed balance holds, cf. (156). This means that trajectories akin to the most likely fluctuations cannot be generated in the deterministic system only by tuning the nonconservative forces, rather new transitions belonging to different physical classes are required. See Sec. VII.A.1 for an example.

# <span id="page-19-1"></span>H. Thermodynamic constraints on transition rates between attractors

The distribution of exit locations from an attractor asymptotically peaks on the saddle points <sup>10</sup> dividing two basins (Day, 1990; Luchinsky et al., 1999; Maier and Stein, 1997). Therefore, when the end point c of an instanton coincides with a saddle point  $x_{\nu}$  on the separatrix dividing the basin of attraction of  $x_{\gamma}^*$  and  $x_{\gamma'}^*$ , (110) is the macroscopic transition rate  $\kappa_{\nu}$  from the attractor  $\gamma$  to  $\gamma'$  through the saddle point  $\nu$  (see Appendix B):

<span id="page-19-6"></span>
$$\kappa_{\nu} \approx e^{-V[I_{\rm ss}^{(\gamma)}(x_{\nu}) - I_{\rm ss}^{(\gamma)}(x_{\gamma}^*)]}.\tag{157}$$

<span id="page-19-5"></span><sup>&</sup>lt;sup>10</sup> Or close to them, in the case of saddles with flat stable directions.

Since exit times from each attractor are exponential distributed in the large V limit (Bovier et~al., 2002; Day, 1983; Freidlin and Wentzell, 1998), the inverse of the transition rate coincides with the mean first passage time  $1/\kappa_{\nu} := \inf\{t \geq 0 : c(0) = x_{\gamma}^*, c(t) = x_{\nu}\}$ . Hereafter  $\kappa_{-\nu}$  will be used to indicate the rate of the opposite transition, namely from  $x_{\gamma'}^*$  to  $x_{\gamma}^*$  through the same saddle  $\nu$ . Crucially, if one used the quasi-potential  $I_{\rm NLE}$  obtained by the nonlinear Langevin equation in (110) and (157), the transition probability and the escape rate from the attractor would be misestimated with an exponential error (Assaf and Meerson, 2017; Bressloff and Newby, 2014).

For detailed balance dynamics  $I_{\rm ss}$  equals  $\phi$  up to a constant, as shown in Sec. IV.B. Hence (157) takes the form of an Arrhenius rate (Arrhenius, 1889; Hänggi *et al.*, 1990) with the large parameter V playing the role of the (small) inverse temperature:

$$\kappa_{\nu}^{\text{eq}} \approx e^{-V[\phi(x_{\nu}) - \phi(x_{\gamma}^*)]}.$$
 (158)

For later convenience, we have defined an Arrhenius rate  $\kappa_{\nu}^{\rm eq}$  with respect to the fixed and saddle points of the nonequilibrium dynamics. In fact,  $\kappa_{\nu}^{\rm eq} \neq \lim_{a_{\rho} \to 0} \kappa_{\nu}$  since  $x_{\gamma}^* \neq x^{\rm eq}$  and  $x_{\nu}$  may even be absent for  $a_{\rho} = 0$ . In Secs. VII.A and VII.B.1 we give examples of such metastables states created by continuous dissipation in chemical reaction networks and electronic circuits. Note that Eyring-Kramers formula (Eyring, 1935; Kramers, 1940; Landauer and Swanson, 1961; Langer, 1969) for the transition rate is the extension of (158) that includes subexponential prefactors.

Close to detailed balance, i.e. at linear order in  $a_{\rho}$ , the quasi-potential is given by (120) and thus the jump dynamics between attractors inherits the local detailed balance property (Falasco and Esposito, 2021), namely,

$$\lim_{V \to \infty} \frac{1}{V} \ln \frac{\kappa_{\nu}}{\kappa_{-\nu}} = \phi(x_{\gamma}^{\text{eq}}) - \phi(x_{\gamma'}^{\text{eq}}) + \sigma_{\nu}^{(0)}, \quad (159)$$

where  $\sigma_{\nu}^{(0)} := -\sigma_{\rm nc}^{(0)}(x_{\nu}, x_{\gamma}^{\rm eq}) + \sigma_{\rm nc}^{(0)}(x_{\nu}, x_{\gamma'}^{\rm eq})$  becomes the dissipation of nonconservative forces along the equilibrium instanton from  $x_{\gamma}^{\rm eq}$  to  $x_{\nu}$  – the time-reversed solution of (122), see (153) – plus the dissipation in the deterministic relaxation from  $x_{\nu}$  to  $x_{\gamma'}^{\rm eq}$ . We will show in Sec. VI that the property (159) allows us to retrieve standard stochastic thermodynamics when the latter is formulated for the jump dynamics on macroscopic attractors.

Remarkably, thermodynamics constrains the macroscopic transition rate  $\kappa_{\nu}$  from the attractor  $\gamma$  to  $\gamma'$  through the saddle point  $\nu$  in terms of the entropy  $\sigma_{\gamma \to \nu}$  (resp.  $\sigma_{\nu \to \gamma}$ ) produced along the instanton (rep. relaxation):

$$-\sigma_{\nu \to \gamma} \le \lim_{V \to \infty} \frac{1}{V} \ln \kappa_{\nu} \le \sigma_{\gamma \to \nu}. \tag{160}$$

We first derive the lower bound in (160). Integrating

(119) along a relaxation trajectory from a neighborhood of the saddle  $x_{\nu}$  to a neighborhood of the fix point  $x_{\gamma}^{*}$  11, and using (157), we immediately obtain

<span id="page-20-4"></span>
$$\lim_{V \to \infty} \frac{1}{V} \ln \kappa_{\nu} \ge -\sigma_{\nu \to \gamma}. \tag{161}$$

The bound (161) is the conceptual analog of (Falasco and Esposito, 2020; Neri, 2022) for state observables, i.e. a recently discovered speed limit which is an upper bound on the rate of processes defined for current observables. In general, splitting the entropy produced in the relaxation

<span id="page-20-5"></span>
$$\sigma_{\nu \to \gamma} = \phi(x_{\nu}) - \phi(x_{\gamma}^*) + \sigma_{\rm nc}^{\nu \to \gamma} \tag{162}$$

<span id="page-20-0"></span>into the equilibrium part, i.e. the variation of the Massieu potential, and the dissipation of the nonconservative forces along the relaxation trajectory, i.e.

$$\sigma_{\rm nc}^{\nu \to \gamma} := \int_{x(0) = x_{\nu}}^{x(\infty) = x_{\gamma}^*} dt \sum_{\rho} a_{\rho} r_{\rho}(x(t)) , \qquad (163)$$

we can rephrase the bound (161) in terms of the Arrhenius transition rate (158),

$$\frac{\kappa_{\nu}}{\kappa_{\nu}^{\text{eq}}} \ge e^{-V\sigma_{\text{nc}}^{\nu \to \gamma}}.$$
 (164)

The additional upper bound in (160) can be obtained in a similar fashion. The derivation, given in appendix A, is based on averaging the entropy production decomposition (115) by conditioning the initial and final points of trajectories of infinite duration, and on showing that the adiabatic entropy production remains nonnegative along these paths.

<span id="page-20-1"></span>For detailed balance dynamics,  $\sigma_{\nu \to \gamma} = -\sigma_{\gamma \to \nu} > 0$ (the sign comes from the positivity of the mean entropy production (119)), as these entropy productions are just the difference of the Massieu potential between the saddle and the stable fixed point. Therefore, the upper and lower bounds in (160) converge to each other in this limit. Moreover, at linear order in  $a_{\rho}$ , the quasi-potential is given by (120), and thus (160) holds again in the form of equality. In this case we can read (160) as a maximum entropy production principle: the attractor with the largest life-time is the one with the largest relaxation (or smallest instantonic) entropy production. This statement remains true for all systems in which relaxation and instantonic entropy productions are close to each other. However, note that  $\sigma_{\gamma \to \nu}$  need not be negative far from equilibrium, which means that the righthand side of (160) can be a loose bound.

<span id="page-20-3"></span><span id="page-20-2"></span><sup>&</sup>lt;sup>11</sup> See appendix A for a discussion about the exact choice of the trajectory endpoints.

![](_page_21_Picture_1.jpeg)

FIG. 3 Schematic representation, for a system without detailed balance, of relaxation and instanton trajectories connecting the local minimum  $x_{\gamma}^*$  of the rate function  $I_{\rm ss}$  and a saddle point  $x_{\nu}$ .

We can also isolate the equilibrium contribution to the entropy production of the instanton as done in (162),

$$\sigma_{\gamma \to \nu} = \phi(x_{\gamma}^*) - \phi(x_{\nu}) + \sigma_{\rm nc}^{\gamma \to \nu}, \tag{165}$$

to recast the upper bound in (160) as

$$\frac{\kappa_{\nu}}{\kappa_{\nu}^{\text{eq}}} \le e^{V\sigma_{\text{nc}}^{\gamma \to \nu}}.$$
 (166)

This inequality is an exact result – asymptotically in V – and thus improves a similar, but approximated result obtained by neglecting changes in the system's dynamical activity (Kuznets-Speck and Limmer, 2021). The main differences are that  $\sigma_{\rm nc}^{\gamma\to\nu}$  is replaced in (Kuznets-Speck and Limmer, 2021) by one half of the dissipation caused by nonconservative forces along the entire trajectory connecting the two basins of attractions and the Arrhenius rate in (166) is calculated with respect to nonequilibrium fixed points.

Finally, we note that these bounds can be tightened by considering the macroscopic limit of the information-theoretic entropy production (68). If the jump vectors  $\tilde{\Delta}_{\rho}$  are linearly independent, the condition  $F(x^*) = 0$  implies that  $\tilde{r}_{\rho}(x^*) - \tilde{r}_{-\rho}(x^*) = 0$  for all  $\rho$  and the function (68) is zero on the fixed point  $x^*$  (Freitas and Esposito, 2022a). Therefore, replacing  $\sigma$  with  $\tilde{\sigma}$  in (160) we obtain tighter bounds – no longer connected to thermodynamics, though. See Sec. VII.B.1 for an application of such bounds to a model of electronic circuit.

The ability to obtain exact solutions of (45) and (107) underlies the practical applicability of the bounds (160). While relaxation trajectories are relatively easy to find

by a direct numerical integration of an initial value problem, instantons require more advanced approaches in view of the boundary value problem which defines them. One typically employs the shooting method (Keller, 2018; Press et al., 2007) for low-dimensional systems. Alternatively, one resorts to the minimum action method (Grafke et al., 2017; Kikuchi et al., 2020; Weinan and Vanden-Eijnden, 2004; Zakine and Vanden-Eijnden, 2023) that is a fictitious-time gradient descent on the (negative of the) action (106) in the trajectory space satisfying the appropriate boundary conditions.

# <span id="page-21-0"></span>I. Macroscopic time-integrated observables and fluctuation theorems

The trajectory description of the previous section can be complemented by an analysis of the full statistics of thermodynamic observables (Chetrite and Gawedzki, 2008; Esposito et al., 2007; Garrahan et al., 2009; Hurtado et al., 2014; Speck et al., 2012). For observables that are time integrated functionals of the trajectory  $\mathfrak X$  of the form,

<span id="page-21-3"></span>
$$\mathfrak{G}[\mathfrak{X}] = \int_0^\tau dt \underbrace{\sum_{\rho} J_{\rho}(t) \mathfrak{G}_{\rho}(n(t))}_{\dot{\mathfrak{G}}(t)}, \tag{167}$$

<span id="page-21-1"></span>we are interested in the generating function  $G_{\mathbb{G}}(z,t) := \langle e^{z^{\mathbb{G}}[\mathfrak{X}]} \rangle$ , which gives all the moments upon differentiation with respect to z, i.e.  $\partial_z^m G_{\mathbb{G}}(z,\tau)|_{z=0} = \langle \mathbb{G}^m \rangle$ . To this aim, it is customary to start from the time evolution equation of the joint distribution  $P(n,\mathbb{G},t)$  of the occupation number n and the observable  $\mathbb{G}$ ,

$$\partial_t P(n, \mathfrak{G}, t) =$$

$$\sum_{\rho} \left[ R_{\rho}(n - \Delta_{\rho}) P(n - \Delta_{\rho}, \mathfrak{G} - \mathfrak{G}_{\rho}, t) - R_{\rho}(n) P(n, \mathfrak{G}, t) \right].$$
(168)

For extensive observables, i.e. such that  $\lim_{V\to\infty} \mathfrak{G}_{\rho}(n) = \sigma_{\rho}(c)$ , we can perform a large scale expansion analogous to that worked out for the master equation in Sec. III.A. The resulting evolution equation for the joint probability of the intensive variables c and the scaled observable  $\lim_{V\to\infty} \mathfrak{G}[\mathfrak{X}]/V = \mathfrak{o}[\mathfrak{X}]$  reads

$$\partial_{t} p(c, o, t) =$$

$$V \sum_{\rho} \left[ r_{\rho} \left( c - \frac{\Delta_{\rho}}{V} \right) p \left( c - \frac{\Delta_{\rho}}{V}, o - \frac{o_{\rho}}{V}, t \right) - r_{\rho}(c) p(c, o, t) \right].$$
(169)

Equation (169) admits a solution of the large deviations form

<span id="page-21-2"></span>
$$p(c, o, t) \approx e^{-VY(c, o, t)} \tag{170}$$

and suggests to define the scaled cumulants generating function

$$K_o(z,t) := \lim_{V \to \infty} \frac{1}{V} \ln G_6(z,t),$$
 (171)

which encodes all the relevant statistics in the macroscopic limit. It can be obtained in the following way. Multiplying (169) by  $e^{Vzo}$  and integrating over o yields a master equation for  $G_{\mathfrak{G}}(c,z,t) := \langle \delta(c(t)-c)e^{Vzo[\mathfrak{X}]} \rangle$ , which is the generating function of  $\mathfrak{G}$  conditioned on the macroscopic state c at time t:

$$\partial_t G_{\mathbb{G}}(c, z, t) = V \mathcal{H}_z\left(c, -V^{-1}\partial_c\right) G_{\mathbb{G}}(c, z, t). \tag{172}$$

The latter is expressed in terms of the 'tilted' operator

$$\mathcal{H}_z\left(c, -V^{-1}\partial_c\right) := \sum_{\rho} (e^{z\sigma_{\rho} - V^{-1}\Delta_{\rho} \cdot \partial_c} - 1) r_{\rho}(c) , \quad (173)$$

which reduces to the generator of the stochastic dynamics (104) for z = 0, since  $G_0(c, z, t)|_{z=0} = p(c, t)$ . Similarly to Sec. IV, we can obtain the (unconditioned) generating function as the functional integral

$$G_{6}(z,\tau) = \int \mathfrak{D}c \int \mathfrak{D}\pi \, e^{V\{\mathfrak{A}_{z}[\{c(t),\pi(t)\}] - I(c(0),0)\}},$$
(174)

that at leading order in V can be evaluated by Laplace method:

$$G_{\mathbb{G}}(z,\tau) \simeq e^{V \max_{c(t),\pi(t)} \{ \mathcal{A}_z[\{c(t),\pi(t)\}] - I(c(0),0) \}}.$$
 (175)

Namely, we are left with maximizing the tilted (or biased) action

$$\mathcal{A}_z = \int_0^\tau dt \left[ -\pi(t) \cdot d_t c(t) + \mathcal{H}_z(c(t), \pi(t)) \right]$$
 (176)

with respect to c(t) and  $\pi(t)$ , that is to find the solutions of the Hamiltonian equations

$$d_t c = \partial_{\pi} \mathcal{H}_z(c, \pi) \qquad d_t \pi = -\partial_c \mathcal{H}_z(c, \pi), \tag{177}$$

with the appropriate boundary conditions. These read  $\pi(0) = \partial_c I(c(0),0)$  and  $\pi(\tau) = 0$  (Lazarescu *et al.*, 2019) for trajectories drawn from the unconstrained ensemble with initial distribution  $p(c(0),t) \approx e^{-VI(c(0),0)}$ , or  $c(0) = x_{\gamma}^*$ . Finally, the (contracted) rate function of the observable  $\mathfrak G$  is obtained by the Legendre-Fenchel transform

$$Y(o,\tau) := \sup_{z} \{ K_o(z,\tau) - zo \}. \tag{178}$$

Note that if  $K_o(z,\tau)$  has nondifferentiable points, the rate function has a nonconvex part, but (178) returns only its convex envelope.

From (176), one can directly extract the mean value

of the observable along trajectories conditioned on the boundaries,  $\langle \dot{\sigma} \rangle = \partial_z \mathcal{H}_z|_{z=0}(c(t),\pi(t))$ , with c(t) and  $\pi(t)$  the solution of (177) at z=0, which is (107). In particular, following a derivation very analogous to that of IV.G we find

<span id="page-22-8"></span>
$$o_{\gamma \to \nu} = \int dt \sum_{\rho} o_{\rho} r_{\rho}(c(t)) e^{\Delta_{\rho} \cdot \partial_{c} I_{ss}(c(t))}$$

$$= \pm \int dt \sum_{\rho} o_{\rho} r_{\rho}^{\dagger}(c(t)) = \pm o_{\nu \to \gamma} + O(\sigma_{\rho}^{ad}),$$
(179)

where the positive (resp. negative) sign is for observables  $\phi_{\rho} = \phi_{-\rho}$  (resp.  $\phi_{\rho} = -\phi_{-\rho}$ ).

## <span id="page-22-0"></span>1. Entropy production at steady state

Choosing  $\phi_{\rho}(c) = \sigma_{\rho}(c)$  defined in (29) and adding the boundary terms  $q[I(c(\tau), \tau) - I(c(0), 0)]$  to the action in (174), we obtain the scaled cumulant generating function of the entropy production (112):

<span id="page-22-6"></span>
$$K_{\sigma}(z,\tau) = \max_{c(t),\pi(t)} \{ \mathcal{A}_z[\{c(t),\pi(t)\}] + zI(c(\tau),\tau) - (z+1)I(c(0),0)] \}.$$
(180)

<span id="page-22-4"></span>If we restrict to a stationary state, i.e.  $\mathcal{H}_z$  has no explicit time dependence and  $I(c,\tau) = I(c,0) = I_{\rm ss}(c)$ , the scaled cumulant generating function satisfies the symmetry

<span id="page-22-7"></span>
$$K_{\sigma}(z,\tau) = K_{\sigma}(-z-1,\tau). \tag{181}$$

<span id="page-22-2"></span>This follows from the local detailed balance property (29), which ensures the Lebowitz-Spohn symmetry of the tilted operator (Kurchan, 1998; Lebowitz and Spohn, 1999)

<span id="page-22-5"></span>
$$\mathcal{H}_{z}(c,\pi) = \sum_{\rho} r_{-\rho}(c) \left( e^{-\Delta_{\rho} \cdot \pi - z\sigma_{\rho}(c)} - 1 \right)$$

$$= \sum_{\rho} r_{\rho}(c) \left( e^{-\Delta_{\rho} \cdot \pi - (z+1)\sigma_{\rho}(c)} - 1 \right) \qquad (182)$$

$$= \mathcal{H}_{-z-1}(c, -\pi).$$

<span id="page-22-3"></span>Stationarity implies that the generating function can as well be obtained by integrating over the time-reversed trajectories of c(t) and  $\pi(t)$ , defined by the change of variable  $\pi \mapsto -\pi$  and  $t \mapsto \tau - t$ , which maps the tilted action as  $\mathcal{A}_z[\{c(t), \pi(t)\}] \mapsto \mathcal{A}_{-z-1}[\{c(t), \pi(t)\}]$  thanks to (182). Hence, by the Laplace approximation the scaled cumulant generating function is recast as

<span id="page-22-1"></span>
$$K_{\sigma}(z,\tau) = \max_{c(t),\pi(t)} \{ \mathcal{A}_{-z-1}[\{c(t),\pi(t)\}] + zI_{ss}(c(0)) - (z+1)I_{ss}(c(\tau))] \}.$$
(183)

Comparing with (180) evaluated at stationarity, i.e. setting  $I = I_{ss}$ , we arrive at the announced symmetry (181).

By a Legendre-Fenchel transform of  $K_{\sigma}(z,\tau)$  that gives the (convex envelop of the) rate function of the entropy production (178), the symmetry (181) results in finite time the fluctuation theorem

<span id="page-23-2"></span>
$$Y(\sigma, \tau) - Y(-\sigma, \tau) = \sigma. \tag{184}$$

Finally, one can directly check that the diffusion-type approximation of the generating function, obtained by expanding the tilted action (176) to second order in  $\pi(t)$ , does preserve the symmetry (182) and the fluctuation theorem (184), provided that the functional dependence on q is left untouched. This means that preserving the fluctuation relation requires to identify the entropy production at the mesoscopic level, i.e. by resolving the entropy production associated to each transition.

## <span id="page-23-0"></span>2. Transition currents at steady state

Choosing  $o_{\pm\rho}=\pm 1$  and the counting field  $z_{\rho}=-z_{-\rho}$ , we obtain the scaled cumulant generating function  $K_{\iota}(z,\tau)$  of all the time-integrated currents with the reservoirs, each of which reads  $\iota_{\rho}[\mathfrak{X}]:=\int_{0}^{\tau}dt I_{\rho}(t)$ . We assume that the initial state c(0) is sampled from the stationary probability density function  $p_{\rm ss}(c)$ . Thanks to the symmetry

<span id="page-23-3"></span>
$$\mathcal{H}_{z}(c,\pi) = \sum_{\rho} r_{-\rho}(c) \left( e^{-\Delta_{\rho} \cdot \pi - z_{\rho}} - 1 \right)$$

$$= \sum_{\rho} r_{\rho}(c) \left( e^{-\Delta_{\rho} \cdot \pi - z_{\rho} - \sigma_{\rho}(c,t)} - 1 \right) \qquad (185)$$

$$= \mathcal{H}_{-z-\rho}(c, -\pi + \partial_{c}\phi),$$

obtained using (29), the tilted action is mapped as  $\mathcal{A}_z[\{c(t), \pi(t)\}] \mapsto \mathcal{A}_{-z-a}[\{c(t), \pi(t)\}] + o(\tau)$  by the change of variables  $\pi \mapsto -\pi + \partial_c \phi$  and the time-reversal  $t \mapsto \tau - t$ . Therefore, the time- and size scaled cumulant generating function  $K_j(z) := \lim_{\tau \to \infty} \frac{1}{\tau} K_\iota(z, \tau)$  satisfies the symmetry

$$K_{\iota}(z) = K_{\iota}(-z - a), \tag{186}$$

where a is the vector of transition forces  $a_{\rho}$ . It is easy to check that the symmetry (185), and thus (186), are in general broken when  $\mathcal{H}_z(c,\pi)$  is expanded at second order in  $\pi$ , i.e. when the Langevin approximation (135) is employed. Since the symmetry of the full action holds only asymptotically, the fluctuation theorem for the currents is valid for  $\tau \to \infty$ . Namely,

$$Y(\iota) - Y(-\iota) = \sum_{\rho > 0} a_{\rho} \iota_{\rho}, \qquad (187)$$

with the long-time large-V rate function of the currents corresponding to probability  $p(\iota, t) \approx e^{-VtY(\iota)}$ .

For systems with multiple deterministic fixed points

 $x_{\gamma}^{*}$ , in general there exist multiple q-dependent vectors  $(c(t), \pi(t))$  that maximize (185) as  $z \to 0$ . When z departs from zero, the (185) attains a different value on each of these optimal solutions. Hence, the function  $\partial_z K_i(z)$ has a jump discontinuity at z=0, reflecting the coexistence of macroscopic states with different mean currents. Accordingly, Legendre-Fenchel transforming  $K_i(z)$  gives only the convex envelope of the rate function. Such phenomenon, is called dynamical phase transition (Espigares et al., 2013; Garrahan et al., 2007, 2009; Gingrich et al., 2014; Hurtado and Garrido, 2011; Nyawo and Touchette, 2017), given the formal analogy with equilibrium phase transitions in which the free energy develops singularities. Its generality was shown in (Lazarescu et al., 2019) for chemical reaction networks, but extends to all systems displaying multiple stable fixed points in the macroscopic limit.

Without spelling out the derivation, very analogous to that of (Herpich *et al.*, 2020b), we note that (185) implies a finite-time symmetry for the scaled cumulant generating function of nonautonomous systems initially in thermal equilibrium with only one reservoir.

Mind that the validity of such detailed fluctuation theorems hinges on the initial and final probability distribution having support on the same attractors, otherwise absolute irreversibility should be taken into account (Buffoni and Campisi, 2022; Murashita *et al.*, 2014).

## <span id="page-23-1"></span>3. Fluctuation theorems from dual dynamics

Other detailed fluctuations theorems can be obtained invoking additional symmetries of a suitably tilted Hamiltonian. In particular, one can leverage the equality

<span id="page-23-5"></span>
$$\mathcal{H}_{z}(c,\pi) = \sum_{\rho} r_{\rho} \left( e^{\Delta_{\rho} \cdot \pi + z \sigma_{\rho}^{\mathrm{ad}}} - 1 \right)$$

$$= \sum_{\rho} r_{\rho}^{\dagger} \left( e^{\Delta_{\rho} \cdot \pi + (z+1)\sigma_{\rho}^{\mathrm{ad}}} - 1 \right)$$

$$= \mathcal{H}_{-z-1}^{\dagger}(c,\pi), \tag{188}$$

<span id="page-23-4"></span>that follows from the fact that the escape rate of the dual dynamics is the same of the original dynamics,  $\sum_{\rho} r_{\rho} = \sum_{\rho} r_{\rho}^{\dagger}$ , and that  $(\sigma_{\rho}^{\text{ad}})^{\dagger} = -\sigma_{\rho}^{\text{ad}}$  changes sign under the dual transformation. From (188), we obtain the fluctuation relation that links the rate functions of the adiabatic entropy production in the original dynamics, Y, and in the dual one,  $Y^{\dagger}$ :

<span id="page-23-6"></span>
$$Y(\sigma_{\rm ad}, \tau) - Y^{\dagger}(-\sigma_{\rm ad}, \tau) = \sigma_{\rm ad}. \tag{189}$$

Equation (189) also follows, in the large deviations formulation, from the log ratio of path probabilities of states and jumps (Sun, 2006), that is reported in (A2). Analogously, a fluctuation theorem for the nonadiabatic entropy production (116) can be derived by combining the

dual dynamics with the time reversal (Rao and Esposito, 2018c). The positivity of the mean adiabatic and nonadiabatic entropy production readily follows from such symmetry relations.

## <span id="page-24-0"></span>V. MACROSCOPIC FIELD THEORY

### <span id="page-24-1"></span>A. Continuous-space limit: dynamics

We now specify more the structure of the system dividing the transitions  $\rho$  into two sets, named R and C. The label R denotes transition that keep a discrete character (akin to chemical reactions), while C indicates jumps that become infinitesimal in size (such as continuous drift or diffusion is real space). Correspondingly, we enforce a bipartite structure by splitting the entries of the vector c, denoted  $c_{\alpha,x}$ , so that transitions belonging to R (resp. C) only act on the label  $\alpha$  (resp. x). For concreteness, we can think of  $\alpha$  as a label for different particle species and x as a d-dimensional vector for the (discrete) space coordinate. Within this picture, we assume that to each pair of first neighbors (x, x') we associate pairs of transitions  $\pm \rho_{(x,x')}^{\alpha} \in C$  (each pair acting on a single label  $\alpha$ , for simplicity) whose rates are conveniently written as  $r^{\alpha}_{(x,x')}$  and  $r^{\alpha}_{(x',x)}$ , respectively.

We look for the continuous-space limit of (106) when a macroscopic scale  $\Omega$ , e.g. the volume of the whole system, is large with respect to the mesoscopic scale V in which the variable  $c_{\alpha,x}$  is defined. To this aim we introduce a continuous variable  $r=x\epsilon$  with  $\epsilon^d=V/\Omega$ , such that  $c_{\alpha,x}\to c_{\alpha}(r)$  and  $\pi_{\alpha,x}\to \pi_{\alpha}(r)$  become smooth fields as  $\epsilon\to 0$ . With the rewriting  $V\sum_x=\Omega\sum_x\frac{V}{\Omega}\to\Omega\int dr$ , the action in (106) takes the form

$$V\mathcal{A} = \Omega \int_0^{\tau} dt \int dr \left\{ -\pi(r,t) \cdot d_t c(r,t) + \mathcal{H}_R(c(r,t),\pi(r,t)) + \mathcal{H}_C(c(r,t),\pi(r,t)) \right\}.$$
(190)

Here we have isolated the generator of transitions  $\rho \in R$ 

$$\mathcal{H}_R(c,\pi) := \sum_{\rho \in R} r_\rho(c) (e^{\Delta_\rho \cdot \pi} - 1), \qquad (191)$$

which maintains the form of the moment generating function of a Poisson noise, and the generator of transitions  $\rho \in C$  ,

$$\mathcal{H}_{C}(c,\pi) := \tag{192}$$

$$\lim_{\epsilon \to 0} \sum_{c} \left( r_{+\rho}^{\alpha}(c) (e^{\Delta_{+\rho} \cdot \pi} - 1) + r_{-\rho}^{\alpha}(c) (e^{\Delta_{-\rho} \cdot \pi} - 1) \right),$$

with  $+\rho = (x, x')$  and  $-\rho = (x', x)$ , and  $\Delta_{\pm \rho}$  is a discrete gradient acting as, e.g.,  $\Delta_{\pm \rho} \cdot \pi = \pm (\pi_{\alpha,x} - \pi_{\alpha,x'})$ . To avoid clutter, we employ the same symbol "·" to denote the scalar product in the reduced space of  $\alpha$ , e.g.,  $\pi(r)$  ·

 $d_t c(r) = \sum_{\alpha} \pi_{\alpha}(r) d_t c_{\alpha}(r)$ , and also in the physical space coordinatized by r.

To evaluate the limit in (192) we use the following expressions for the discrete gradient of functions

<span id="page-24-4"></span>
$$\Delta_{\pm\rho} \cdot \pi = \pm \left( \epsilon \hat{\nabla} \pi(r) + \frac{1}{2} \epsilon^2 \hat{\nabla}^2 \pi(r) \right) + O(\epsilon^3),$$

$$\Delta_{\pm\rho} \cdot \partial_c \phi(c) = \pm \epsilon \hat{\nabla} \frac{\delta}{\delta c(r)} \phi[c(r)] + O(\epsilon^2),$$
(193)

which yield the expansion of the transition rates <sup>12</sup>

<span id="page-24-5"></span>
$$r_{\pm\rho}^{\alpha}(c) = \epsilon^{-2} [\chi_{\alpha}(c(r)) + O(\epsilon)]$$

$$\times \left[ 1 \mp \frac{\epsilon}{2} \hat{\nabla} \frac{\delta \phi}{\delta c_{\alpha}(r)} \pm \frac{\epsilon}{2} e_{x,x'} f_{\alpha}(r) + O(\epsilon^{2}) \right]$$
(194)

where we write  $\hat{\nabla} := e_{x,x'} \cdot \nabla$ , with  $e_{x,x'}$  the unit vector pointing from x to x'. Here the mobility matrix  $\chi(c)$  (diagonal with entries  $\chi_{\alpha}$ ) and the nonconservative force vector f(r), as well as the thermodynamic functional  $\phi(\{c_{x,\alpha}\}) \to \phi[c(r)]$  are independent of  $\epsilon$ . The scaling  $\gamma_{\rho}(c_{x,\alpha}) = \epsilon^{-2}\chi_{\alpha}(c(r)) + O(\epsilon^{-1})$  of the kinetic part of the rates is imposed to ensure a proper diffusive limit on the same time-scales of transitions  $\rho \in R$ . In addition, we required that the nonconservative force  $a_{\rho} = \epsilon e_{x,x'} f_{\alpha}(r) + O(\epsilon^2)$  is small on the macroscopic scale, a condition called 'weak asymmetry' in the lattice gas literature.

Therefore, neglecting contributions of  $O(\epsilon^2)$  and higher, (193) and (194) reduce the generator  $\mathcal{H}_C$  to

$$\mathcal{H}_C(c,\pi) = \nabla \pi \cdot \chi(c) \cdot \left[ \left( -\nabla \frac{\delta \phi}{\delta c} + f \right) + \nabla \pi \right], \quad (195)$$

<span id="page-24-8"></span>which has the structure (quadratic in  $\pi$ ) of the cumulant generating function of a Gaussian noise field. If the set R is empty, (195) is the generator of the full dynamics, corresponding to the functional Langevin equation

<span id="page-24-7"></span><span id="page-24-6"></span>
$$\partial_t c(r,t) = -\nabla \cdot \left( j[c] + \frac{1}{\sqrt{\Omega}} \xi(r,t) \right),$$

$$j[c] := \chi \cdot \left( -\nabla \frac{\delta \phi}{\delta c} + f \right),$$
(196)

<span id="page-24-2"></span>where  $\xi(r,t)$  is zero-mean, Gaussian with correlations  $\langle \xi(r,t)\xi(r',t')\rangle = 2\chi(c(r,t))\delta(r-r')\delta(t-t')$ . This can be easily seen by performing the Gaussian integral over  $\pi$  and recognizing that the resulting action is the standard one corresponding to the Langevin equation (196) (cf. (140) for the finite dimensional case). A few comments are in order. First, the stochastic partial differential equation (196) is ill-defined (Konarovskyi et al.,

<span id="page-24-3"></span><sup>&</sup>lt;sup>12</sup> We omit to write down the explicit form of terms of order  $\epsilon$  and  $\epsilon^2$  which are symmetric, as they cancel in the sum of (192).

[2020\)](#page-46-41), and has to be interpreted as a formal restatement of the large deviations principle given by the action [\(190\)](#page-24-8). Alternatively, it can be viewed as an effective low-wave-number field theory, which is equivalent to restoring a minimal distance – the underlying lattice constant ϵ. Also, [\(196\)](#page-24-7) is a continuous-space limit of the underlying lattice model, not a hydrodynamic equation for a macroscopic field obtained by locally integrating (i.e. coarse-graining) the variables cα,x [\(Spohn,](#page-47-41) [2012\)](#page-47-41).

Equation [\(196\)](#page-24-7) is at the basis of the macroscopic fluctuation theory [\(Bertini](#page-43-10) et al., [2015\)](#page-43-10), in which the diffusion flux is recast as the Fick law

$$\chi_{\alpha}(c)\nabla\frac{\delta\phi}{\delta c_{\alpha}} = D_{\alpha}(c)\nabla c, \qquad (197)$$

with the diffusivity obeying the Einstein relation

$$D_{\alpha} = \chi_{\alpha} \partial_{c_{\alpha}}^{2} \phi. \tag{198}$$

This is a form of fluctuation-dissipation relation that replaces in continuous space the detailed balance relation. In fact, the continuous-space limit reduces the initial local detailed balance assumption to a condition of local equilibrium: since the transitions ρ ∈ C are associated to points in physical space, the reservoirs responsible for them must be accordingly distributed in space, thus creating a continuum background of local equilibria.

A particularly known instance of [\(196\)](#page-24-7) is the Dean-Kawasaki equation, which describes the density of identical particles interacting through a two-body potential U(r − r ′ ) [\(Dean,](#page-44-38) [1996;](#page-44-38) [Kawasaki,](#page-46-42) [1998\)](#page-46-42). It is obtained by setting

$$\phi[c] = \frac{1}{T}u[c] - s_{\text{int}}[c],$$
 (199)

with the scaled internal energy and entropy

$$u[c] = \frac{1}{2} \int dr \int dr' c(r) U(r - r') c(r')$$

$$s_{\text{int}}[c] = -\int dr c(r) (\ln c(r) - 1),$$
(200)

as well as χ(c) ∝ c. While it was originally derived starting from the overdamped Langevin equations for the coordinates of an ensemble of identical particles, here it follows from the continuous limit of a Markov jump process on the lattice with transition rates satisfying the above mentioned scaling [\(Lefevre and Biroli,](#page-46-20) [2007\)](#page-46-20). For f = 0, the average value of [\(196\)](#page-24-7) reduces to the central equation of dynamic density functional theory [\(Marconi and](#page-46-43) [Tarazona,](#page-46-43) [1999\)](#page-46-43).

Another important class is that of simple exclusion processes obtained using [\(199\)](#page-25-0) with the free energy of an ideal binary mixture,

$$u[c] = 0 (201)$$

$$s_{\text{int}}[c] = -\int dr [c(r) \ln c(r) + (1 - c(r)) \ln(1 - c(r))],$$

and the mobility χ(c) ∝ c(1 − c)[\(Bertini](#page-43-10) et al., [2015;](#page-43-10) [Lefevre and Biroli,](#page-46-20) [2007;](#page-46-20) [Tailleur](#page-48-25) et al., [2007\)](#page-48-25).

The full action [\(190\)](#page-24-8) shows that for large Ω the most likely trajectories dominate the statistical averages. In particular, the probability density function of the stochastic field c(r, t) acquires the large deviations form

<span id="page-25-2"></span><span id="page-25-1"></span>
$$p[c(r), t] \simeq e^{-\Omega I[c(r), t]}, \tag{202}$$

with rate functional I. Analogous considerations on the macroscopic dynamics discussed previously for the finitedimensional case apply here to the field theoretical description [\(Bertini](#page-43-10) et al., [2015\)](#page-43-10). In particular, when the set R is empty, the functional analog of the Hamilton-Jacobi equation [\(32\)](#page-7-5) can be obtained from the Fokker-Planck equation associated to [\(196\)](#page-24-7), [\(Zinn-Justin,](#page-48-21) [2002\)](#page-48-21)

$$\partial_t p = \int dr \frac{\delta}{\delta c(r)} \left[ -p \nabla \cdot j + \frac{1}{\Omega} \frac{\delta(\chi p)}{\delta c(r)} \right] =: -\int dr \frac{\delta \mathfrak{j}}{\delta c(r)}. \tag{203}$$

We have introduced the probability current j[c] as done in Section [III.E](#page-11-0) for the finite dimensional case. It should not be confused with j[c] that is the current of the physical field c(r, t).

<span id="page-25-0"></span>Plugging the large-deviation ansatz for p[c], Eq. [\(202\)](#page-25-1), into [\(203\)](#page-25-2), we obtain the Hamilton-Jacobi equation

$$-\partial_t I[c(r), t] = \int dr \, \mathcal{H}_C\left(c(r), \frac{\delta I}{\delta c(r)}\right), \qquad (204)$$

whose stationary limit (when it exists) gives

<span id="page-25-3"></span>
$$\int dr \,\mathcal{H}_C\bigg(c(r), \frac{\delta I_{\rm ss}}{\delta c(r)}\bigg) = 0. \tag{205}$$

The instanton dynamics outlined in Sec. [IV.A](#page-14-1) remains formally unaltered [\(Elgart and Kamenev,](#page-44-39) [2004\)](#page-44-39).

Moreover, one recognizes that the stationary probability velocity in the macroscopic limit (corresponding to the definition [\(70\)](#page-11-2) for the finite dimensional case),

$$\lim_{V \to \infty} \lim_{t \to \infty} \frac{\mathbf{j}[c]}{p[c]} = -\nabla \cdot \left[ j(c) + \chi(c) \cdot \nabla \frac{\delta I_{ss}}{\delta c} \right]$$

$$= -\nabla \cdot j_A(c),$$
(206)

is the negative divergence of the nonconservative part of the macroscopic physical current j. This generalizes [\(70\)](#page-11-2) to field theories and gives the orthogonal decomposition (cf. Eq. (71)) for the physical current

$$j = -\chi \cdot \nabla \frac{\delta I_{\rm ss}}{\delta c} + j_A, \tag{207}$$

with  $\int dr j_A \cdot \nabla \frac{\delta I_{\rm ss}}{\delta c} = 0$ . A similar decomposition holds for nonautonomous dynamics, just replacing  $I_{\rm ss}$  with  $I_{\rm ss}^t$ , the solution of (205) with driving frozen at its instantaneous value at time t.

In the most general case, i.e. when the set R is not empty, the macroscopic noiseless equation read

$$\partial_t x(r,t) = -\nabla \cdot j + \sum_{\rho \in R} \Delta_\rho r_\rho(x(r,t)), \qquad (208)$$

which is the general form of a reaction-diffusion-advection equation of interacting (Aslyamov et al., 2023) and driven (or active) particles (see Sec. VII.C for an example). The last term in (208) makes the stochastic field c not conserved, i.e. in general  $d_t \int dr c(r,t) = \int dr \sum_{\rho \in R} \Delta_\rho r_\rho(c(r,t)) \neq 0$ . However, there might exist globally conserved quantities  $c \cdot \ell$ , with  $\ell$  the left null vector(s) of the matrix  $\Delta_\rho$ , namely,  $\ell \cdot \Delta_\rho = 0$  for all  $\rho \in R$  (Avanzini et al., 2019; Falasco et al., 2018; Rao and Esposito, 2018b). Note that the decompositions (71) and (207) are still valid, but the orthogonal conditions are replaced by the single property  $\int dr [v_{\rm ss} - \nabla \cdot j_A] \frac{\delta I_{\rm ss}}{\delta c} = 0$ .

Extending the Gaussian theory of Sec. IV.C to the infinite-dimensional case, we can linearize the stochastic dynamics around the solutions x(r,t) of the deterministic equation (208) setting  $\varrho(r,t)=c(r,t)-x(r,t)$ . This amounts to a parabolic approximation of the rate functional  $I[\varrho,t]=-\frac{1}{2}\int dr\int dr'\varrho(r)\cdot \mathscr{C}^{-1}(r,r',t)\cdot\varrho(r')+O(\varrho^3)$ , and gives an equation for the covariance matrix  $\mathscr C$  analogous to (128), and to the Lyapunov equation (129) under stationary conditions. This approach was employed to derive analytic expressions for the correlation length of noisy Turing patterns (Vance and Ross, 1999), but a connection to thermodynamics has not been deeply explored – see (Rana and Barato, 2020), though.

## <span id="page-26-0"></span>B. Continuous-space limit: entropy production

The continuous-space limit can be implemented on the deterministic limit of the microscopic expression of the entropy production (61). For transitions  $\rho \in C$ , the difference of transition rates and the nonconservative forces read at leading order in  $\epsilon$ , respectively,

<span id="page-26-3"></span>
$$r_{\rho}(c) - r_{-\rho}(c) \to \epsilon^{-2} \chi(c) \cdot \epsilon \left[ -\nabla \frac{\delta \phi}{\delta c} + f \right] = \frac{1}{\epsilon} j[c]$$

$$\Delta_{\rho} \partial_{c} \phi + a_{\rho} \to \epsilon \left[ -\nabla \frac{\delta \phi}{\delta c} + f \right] = \epsilon \chi(c)^{-1} \cdot j[c],$$
(209)

<span id="page-26-2"></span>where j[c] is the hydrodynamic current defined in (196). Plugging (209) into (61) we get

<span id="page-26-4"></span>
$$\lim_{\Omega \to \infty} \frac{1}{\Omega} \langle \dot{\Sigma} \rangle = \int dr j[x] \cdot \chi(x(r,t))^{-1} \cdot j[x] + \int dr \sum_{\rho \in R} r_{\rho}(x(r,t)) \sigma_{\rho}(x(r,t)),$$
(210)

<span id="page-26-1"></span>where the first term corresponds to the entropy production associated to the Langevin equation (196). The second term in (210), due to transitions unaffected by this limit, is different from the informational entropy production associated to the Langevin equation (see Sec. IV.E). The thermodynamic inconsistencies arising from an incorrect application of the Langevin approximation have been observed for various specific model systems (Brillouin, 1950; Ceccato and Frezzato, 2018; Horowitz, 2015). Here, we have shown that such inconsistency extends to field theories that try to infer the entropy production solely on the basis of the dynamics in state space. This means, for example, that in field theories of active matter all internal processes must be resolved in general, such as the chemical reactions necessary to self-propulsion. Also, we remark that the second line in (210) differs from the entropy production obtained by linearizing the dynamics of transitions  $\rho \in R$  (Markovich et al., 2021a), unless they are close to detailed balance (i.e.  $a_{\rho \in R} \to 0$ ).

The first term in (210) can be decomposed as done in (113) using (196) and integrating by parts:

<span id="page-26-5"></span>
$$\lim_{\Omega \to \infty} \frac{1}{\Omega} \langle \dot{\Sigma} \rangle = -d_t \phi[x(r,t),t] + \partial_t \phi[c,t]|_{c=x(r,t)} + \dot{\sigma}_{\rm nc}.$$
(211)

On the righthand side, the first two terms are the total variation in time of the thermodynamic potential plus the dissipation of driving (zero only for autonomous dynamics), while the third is the total dissipation due to nonconservative forces acting in the discrete and continuous space,

<span id="page-26-6"></span>
$$\dot{\sigma}_{\rm nc} = \int dr \left[ \sum_{\rho \in R} r_{\rho}(x(r,t)) a_{\rho}(x(r,t)) + j[x] \cdot f(r) \right]. \tag{212}$$

Here we have assumed that the flow  $j \cdot \frac{\delta \phi}{\delta c}$  at the boundaries is zero. However, different boundary conditions can be imposed by a specific scaling of a set of transitions  $\rho \in R$  located at the boundaries (Bertini *et al.*, 2015).

When the set R is empty, one can show that the orthogonal decomposition (207) naturally induces a splitting of the entropy production into the nonadiabiatic component (corresponding to the "excess work" of (Bertini

et al., 2013) for autonomous relaxation),

$$\lim_{\Omega \to \infty} \frac{1}{\Omega} \langle \dot{\Sigma}_{\text{na}} \rangle = -d_t I_t [x(r,t)] + \partial_t I_{\text{ss}}^t [c]|_{c=x(r,t)}$$

$$= \int dr \nabla \frac{\delta I_t}{\delta x} \cdot \chi(x) \cdot \nabla \frac{\delta I_t}{\delta x} \ge 0,$$
(213)

and the adiabatic component.

$$\lim_{\Omega \to \infty} \frac{1}{\Omega} \langle \dot{\Sigma}_{ad} \rangle = \lim_{\Omega \to \infty} \frac{1}{\Omega} (\langle \dot{\Sigma} \rangle - \langle \dot{\Sigma}_{na} \rangle)$$

$$= \int dr j_A[x] \cdot \chi(x)^{-1} \cdot j_A[x] \ge 0.$$
(214)

Both (213) and (214), being quadratic forms, are non-negative. We can combine (211) and (214) to eliminate the entropy production rate,

<span id="page-27-3"></span>
$$\dot{\sigma}_{\rm nc} + \partial_t \phi[c, t]|_{c=x(r,t)} - \lim_{\Omega \to \infty} \frac{1}{\Omega} \langle \dot{\Sigma}_{\rm ad} \rangle 
= d_t \phi[x] + \lim_{\Omega \to \infty} \frac{1}{\Omega} \langle \dot{\Sigma}_{\rm na} \rangle 
\geq d_t \phi[x].$$
(215)

Here, for systems with reservoirs at the same temperature T, the first line is the "renormalized work" rate (times the factor T) and the last line is the nonequilibrium Clausius inequality as defined by macroscopic fluctuation theory (Bertini et al., 2013). The "renormalized work" counts only the energy needed in a transformation, discarding the energy which keeps the system away from equilibrium. In the context of stochastic thermodynamics, different definitions have been proposed for such a quantity (Hatano and Sasa, 2001; Maes and Netočný, 2014), inspired by the early phenomenological approaches to nonequilibrium thermodynamics (Oono and Paniconi, 1998; Sasa and Tasaki, 2006). Notice that (215) is not peculiar to the continuous-space limit, but can be equally written for the intensive quantities appearing in (113), (67) and (66).

## <span id="page-27-0"></span>VI. EMERGENT STOCHASTIC THERMODYNAMICS

The picture appearing in Sec. IV is that of a stochastic dynamics asymptotically characterized by two distinct regimes: relatively fast relaxation in a basin (Eq. (45)) followed by small Gaussian fluctuations on the attractor (Eq. (126)); rare large fluctuations corresponding to jumps between nearby attractors along transition trajectories, i.e. the sum of instanton and noiseless relaxation paths. Hence, it is natural to asymptotically describe the stochastic dynamics as a Markov jump process on the space of the various attractors (see Fig. 1) with transition rates given by (157) at leading order in V (Qian et al., 2016; Smith, 2020). Such description is valid when the macroscopic dynamics (45) have isolated fixed points

and sufficiently regular time-dependent attractors and is far from a bifurcation (see Sec. VII.C for an example in which this condition is not met) (Freidlin and Wentzell, 1998; Graham, 1987). For simplicity we restrict to autonomous dynamics in the following.

<span id="page-27-1"></span>For large V the probability density of states can be approximated as

<span id="page-27-7"></span>
$$p(c,\tau) \approx e^{-VI(c,\tau)} \to \sum_{\gamma} p_{\gamma}(\tau) \delta_V(c - x_{\gamma}^*)$$
 (216)

<span id="page-27-2"></span>where  $\delta_V(c-x_\gamma^*)$  is a strongly peaked function with support on the ball  $\mathcal{B}_\gamma$  of radius  $O(V^{-1/2})^{13}$  centered on  $x_\gamma^*$  (whose boundary is denoted  $\partial \mathcal{B}_\gamma$ ). It is normalized such that  $p_\gamma(\tau) := \int_{\mathcal{B}_\gamma} dc \, p(c,\tau)$  and tends to a Dirac delta as  $V \to \infty$ .

The probability of finding the system in the neighborhood of the attractor  $\gamma$  at time  $\tau$ , i.e.  $p_{\gamma}(\tau)$ , is determined by the master equation

$$d_{\tau} p_{\gamma}(\tau) = \sum_{\nu} \delta_{\mathsf{o}(\nu)\gamma} [\kappa_{-\nu} p_{\mathsf{o}(-\nu)}(\tau) - \kappa_{\nu} p_{\gamma}(\tau)], \quad (217)$$

where  $o(\nu)$  denotes the origin of the transition  $\nu$ .

Time-integrated observables of the form (167) are split by summing the intra- and inter-basins contributions as

<span id="page-27-8"></span><span id="page-27-5"></span>
$$\mathfrak{G}[\mathfrak{X}] = \sum_{\gamma} \int_{0}^{\tau} dt \,\dot{\mathfrak{G}}(t) \Theta_{\gamma}(t) + \sum_{\nu} \int_{0}^{\tau} dt \,\dot{\mathfrak{G}}(t) \Theta_{\nu}(t) + \varepsilon[\mathfrak{X}].$$
(218)

Here,  $\Theta_{\gamma}(t) = 1$  if  $n(t) \in \mathfrak{B}_{\gamma}$  and 0 otherwise, while  $\Theta_{+\nu}(t) = 1$  (resp.  $\Theta_{-\nu}(t) = 1$ ) if n(t) belongs to a tube of width  $V^{-1/2}$  centered on the transition trajectory going from  $\partial \mathfrak{B}_{\gamma}$  to  $\partial \mathfrak{B}_{\gamma'}$  (resp. from  $\partial \mathfrak{B}_{\gamma'}$  to  $\partial \mathfrak{B}_{\gamma}$ ), and 0 otherwise. The functional  $\varepsilon[\mathfrak{X}]$  accounts for trajectories exiting and reentering the same ball, incomplete transition attempts, and transitions between different balls happening far from the transition path. Since they become exponentially unlikely in the macroscopic limit, we neglect  $\varepsilon[\mathfrak{X}]$  in the following. Therefore, for large V and for  $\tau$  much larger than the typical relaxation times within each basin, we can recast the macroscopic rate of the scaled observable (218) as

<span id="page-27-6"></span>
$$\frac{\mathfrak{G}[\mathfrak{X}]}{V\tau} =: \dot{\boldsymbol{\sigma}} = \sum_{\gamma} \dot{\boldsymbol{\sigma}}_{\gamma} \mathcal{P}_{\gamma}(\tau) + \sum_{\nu} \boldsymbol{\sigma}_{\nu} \mathcal{I}_{\nu}(\tau), \qquad (219)$$

where  $\dot{o}_{\gamma}$ ,  $o_{\nu}$ ,  $\mathcal{P}_{\gamma}$  and  $\mathcal{I}_{\nu}$  are independent stochastic variables defined in the following.

<span id="page-27-4"></span> $<sup>^{13}</sup>$  The fact that Gaussian fluctuations are of order  ${\cal O}(V^{-1/2})$  can be seen from the Sec. IV.C.

The observable  $\mathcal{P}_{\gamma}(\tau) := \frac{1}{\tau} \int_{0}^{\tau} dt \Theta_{\gamma}(t)$  is the empirical density on the attractor  $\gamma$  satisfying  $\langle \mathcal{P}_{\gamma} \rangle = p_{\gamma}$ . The number of transitions between attractors  $\gamma$  and  $\gamma'$  through  $x_{\nu}$  divided by the time-span  $\tau$  is given by  $\mathcal{I}_{\nu}(\tau)$ , which asymptotically approaches a conditional Poisson distribution with intensity  $\kappa_{\nu}$  given by (157) (Day, 1983; Freidlin and Wentzell, 1998; Graham, 1987). In other words, it is the empirical flux through the saddle  $\nu$  satisfying  $\langle \mathcal{I}_{\nu} \rangle = \kappa_{\nu} p_{o(\nu)}$ . Note that the sum over  $\nu$ , in (219) and hereafter, counts transitions in the two directions.

The observable

$$\dot{\phi}_{\gamma} := \frac{1}{V} \frac{\int_0^{\tau} dt \, \dot{\Theta}(t) \Theta_{\gamma}(t)}{\int_0^{\tau} dt \, \Theta_{\gamma}(t)}$$
 (220)

is the time-independent rate of  $o[\mathfrak{X}]$  inside the attractor  $\gamma$ , i.e. in an infinitesimal neighborhood of  $x_{\gamma}^*$ . Its scaled cumulant generating function can be obtained by the scaled tilted action (176) evaluated on the constant optimal trajectories  $\bar{c}, \bar{\pi}$ , i.e. the solutions of the time-independent version of (177) such that  $\bar{c} = x_{\gamma}^*$  and  $\bar{\pi} = 0$  as  $z \to 0$ :

$$K_{\dot{\sigma}_{\gamma}}(z) = \mathcal{H}_z(\bar{c}, \bar{\pi}). \tag{221}$$

In practice one may want to approximate the statistics of (221) at Gaussian level by retaining only terms of order  $O(z^2)$  in  $\mathcal{A}_z$  (Nguyen and Seifert, 2020).

The observable  $o_{\nu}$  is the contribution of  $o[\mathfrak{X}]$  along the transition path through  $x_{\nu}$ ,

$$\boldsymbol{\phi}_{\nu} := \frac{1}{V} \int_{0}^{\tau_{\nu}^{\text{tr}}} dt \, \dot{\boldsymbol{\Theta}}(t) \boldsymbol{\Theta}_{\nu}(t). \tag{222}$$

Its scaled cumulant generating function can be approximated by the tilted action (176) evaluated on the optimal trajectories  $\bar{c}(t), \bar{\pi}(t)$ , i.e. the solutions of (177) such that  $\bar{c}(0) \in \partial \mathcal{B}_{\gamma}$  and  $\bar{c}(\tau_{\nu}^{\text{tr}}) \in \partial \mathcal{B}_{\gamma'}$  as  $z \to 0$ :

$$K_{o_{\nu}}(z, \tau_{\nu}^{\text{tr}}) = \mathcal{A}_{z}[\{\bar{c}(t), \bar{\pi}(t)\}].$$
 (223)

The duration  $\tau_{\nu}^{\rm tr}$  of such trajectory is a stochastic variable itself, whose mean differs from the mean escape time  $1/\kappa_{\nu}$  from a basin of attraction:  $\tau_{\nu}^{\rm tr}$  refers to the transition time of those (rare) trajectories that have just exited  $\mathfrak{B}_{\gamma}$ , thus it does not account for the (exponentially long) dwelling time in the neighborhood of a fixed point – which on the contrary enters  $1/\kappa_{\nu}$ . To the best of our knowledge, its probability distribution has been evaluated only for detailed balance systems with Gaussian noise. In this case, the most probable value of  $\tau_{\nu}^{\rm tr}$ and its mean  $\langle \tau_{\nu}^{\rm tr} \rangle$  grow as the logarithm of the inverse noise strength and coincide in the limit of vanishing noise (Caroli et al., 1979, 1981, 1980; Malinin and Chernyak, 2010). Even though we are not aware of similar results for systems with nonconservative forces and nonGaussian noise, one can speculate to replace  $\tau_{\nu}^{\rm tr}$  in (223) with its mean value, as measured in computer simulations or experiments. We remark that not only the statistics of transition times but also those of (thermo)dynamic observables conditioned on transition paths remains a subject to be explored in systems lacking detailed balance.

In particular, we can write the mean entropy production rate on the network of attractors,

<span id="page-28-2"></span>
$$\langle \dot{\sigma} \rangle = \sum_{\gamma} \langle \dot{\sigma}_{\gamma} \rangle p_{\gamma} + \sum_{\nu > 0} (\langle \sigma_{\nu} \rangle \kappa_{\nu} p_{o(\nu)} + \langle \sigma_{-\nu} \rangle \kappa_{-\nu} p_{o(-\nu)}) - d_{\tau} \sum_{\gamma} p_{\gamma} \frac{\ln p_{\gamma}}{V}, \qquad (224)$$

where the last term is obtained by using the expression for the probability density (216) in the Shannon entropy (56). Equation (224) has three important differences with respect to its definition on the mesoscopic dynamics. (i) The existence of a mean state entropy production rate,

<span id="page-28-3"></span>
$$\langle \dot{\sigma}_{\gamma} \rangle = \sum_{\rho > 0} [r_{\rho}(x_{\gamma}^{*}) - r_{-\rho}(x_{\gamma}^{*})] \ln \frac{r_{\rho}(x_{\gamma}^{*})}{r_{-\rho}(x_{\gamma}^{*})} \ge 0, \quad (225)$$

<span id="page-28-0"></span>independent of macroscopic transitions, stemming from the continuous dissipation needed to sustain the attractors. (ii) The mean entropy production associated to a macroscopic transition,  $\langle \sigma_{\nu} \rangle$ , not given by the log ratio of macroscopic transition rates  $\kappa_{+\nu}$ . Indeed, as shown in Sec. IV, the transition rates do not in general obey the local detailed balance condition, unless close to equilibrium, see (159). (iii) The presence of all fluxes in (224), which cannot be written in terms of currents since in general  $\sigma_{-\nu} \neq -\sigma_{\nu}$ . This is because the breaking of time reversibility in the underling mesoscopic dynamics implies that the transition path between  $\gamma$  and  $\gamma'$  is not equal to the time-reversed transition path between  $\gamma'$  and  $\gamma$ . Even when these paths are the same, such as for the low dimensional systems of Secs. VII.A.1 and VII.B.1,  $\sigma_{-\nu}$ need not equal  $-\sigma_{\nu}$  because of (179).

<span id="page-28-1"></span>At linear order in  $a_{\rho}$  around detailed balance, (224) reduces to the standard expression of traditional stochastic thermodynamics (8). In this limit, we find that  $\langle \dot{\sigma}_{\gamma} \rangle = \sum_{\rho} r_{\rho}^{(0)}(x_{\rm eq}) a_{\rho} = 0$ , the transition entropy production  $\sigma_{\nu}$  changes sign under path reversal because of (153), and the transition rates satisfy local detailed balance (159).

Finally, we observe that the constant  $\alpha_{\gamma}$  introduced in (55) as the relative weight of the attractor  $\gamma$  is related to the stationary probability  $p_{\gamma}^{\rm ss}$  solution of (217) as  $\alpha_{\gamma} = -\frac{1}{V} \ln p_{\gamma}^{\rm ss}$ . In the Freidlin-Wentzell theory (Freidlin and Wentzell, 1998),  $p_{\gamma}^{\rm ss}$  is calculated by the martrix-tree theorem for Markov chains (Çetiner and Gunawardena, 2022; Dal Cengio *et al.*, 2023; Polettini, 2015; Zia and Schmittmann, 2007), retaining only the leading spanning tree monomial in the limit  $V \to \infty$  (Maes and Netočný,

2013).

## <span id="page-29-0"></span>VII. APPLICATIONS

We now exemplify the general theory of the previous sections in three prototypical classes of model systems, namely, networks of chemical reactions, nonlinear electronic circuits and driven interacting units.

## <span id="page-29-1"></span>A. Chemical reaction networks

We consider chemical species in a volume V of solvent in equilibrium at temperature T. Mass transport (e.g. by diffusion or advection) is taken to be fast enough to homogenize the local distribution of chemicals on the typical time scales of the reactions. All the internal (e.g. vibrational, rotational) degrees of the chemicals are assumed to be at equilibrium so that the only relevant dynamical variables are the number of particles  $n_i$  of the dynamical species labelled by i. In a closed system, chemical reactions exclusively involve the N chemical species. In open systems, they also involve  $N_Y$  chemostatted species, whose concentrations  $c_y$  are externally prescribed (Rao and Esposito, 2016).

We first consider closed systems and assume that chemical reactions are well described by a Markov jump process with transitions  $\rho \in R$ . The associated transition rates read (Gillespie, 1992; Schmiedl and Seifert, 2007)

$$R_{\rho}(n) = V k_{\rho} \prod_{i=1}^{N} \frac{1}{V^{\nu_{\rho}^{i}}} \frac{n_{i}!}{(n_{i} - \nu_{\rho}^{i})!}, \qquad (226)$$

where the stoichiometric coefficient  $\nu_{\rho}^{i}$  (resp.  $\nu_{-\rho}^{i}$ ) is the number of reactants (resp. products) of species i involved in the reaction  $\rho$ . The entries of the jump matrix are given by  $\Delta_{\rho}^{i} = \nu_{-\rho}^{i} - \nu_{\rho}^{i}$ . Equation (226) is known as mass-action kinetics and holds for elementary reactions between diluted chemicals (Avanzini *et al.*, 2021). The reaction constants  $k_{\rho}$  are independent of V and satisfy

$$T\log\frac{k_{\rho}}{k_{-\rho}} = -\sum_{i=1}^{N} \Delta_{\rho}^{i} \mu_{i}^{\circ}, \qquad (227)$$

where  $\mu_i^{\circ}$  is the standard chemical potential of the dynamical chemical species i, including the contribution of the solvent. The mesoscopic local detailed balance (5) holds in the form

$$T\Sigma_{\rho}(n) = -\Phi_{\text{can}}(n + \Delta_{\rho}) + \Phi_{\text{can}}(n)$$
 (228)

with the 'canonical' Gibbs free energy of a mixture of N ideal gasses,

$$\Phi_{\rm can}(n) = \mu^{\circ} \cdot n + T \ln n! \,, \tag{229}$$

The system is closed, namely, no matter is exchanged with the environment. The system dynamics is detailed balanced since (228) does not display nonconservative forces,  $a_{\rho}=0$ . Moreover, the quantities  $L(n):=\ell\cdot n$  are conserved, with the vectors  $\ell$  defined by  $\ell\cdot\Delta_{\rho}=0$  for all  $\rho$ . The conservation follows from multiplying (1) by  $\ell$ . For instance, the number of atoms of each chemical element and the charges are conserved. The system relaxes to the Gibbs distribution

$$P_{\rm eq}(n) \propto e^{-\Phi_{\rm can}(n)/T} \delta(L(n) - L)$$
 (230)

constrained by the value of the conserved quantities fixed by the initial conditions.

We now turn to open systems where chemostats are present, i.e.  $N_Y \geq 1$  chemical species (labelled by y) have a large copy number controlled by external reservoirs while N species continue to evolve stochastically. The transition rates (226) become

$$R_{\rho}(n) = V k_{\rho} \prod_{y=1}^{N_{Y}} c_{y}^{\nu_{\rho}^{y}} \prod_{i=1}^{N} \frac{1}{V^{\nu_{\rho}^{i}}} \frac{n_{i}!}{(n_{i} - \nu_{\rho}^{i})!}, \qquad (231)$$

where  $c_y = n_y/V$  is the externally controlled concentration of chemostatted species y. The local detailed balance of the open system reads

$$T\Sigma_{\rho}(n) = -\Phi_{\text{can}}(n + \Delta_{\rho}) + \Phi_{\text{can}}(n) - \sum_{y=1}^{N_Y} \Delta_{\rho}^y \mu_y,$$
(232)

<span id="page-29-2"></span>where the last sum represents the free energy exchanged with the reservoirs with  $\mu_y = \mu_y^{\circ} + RT \ln c_y$ , the chemical potential of the chemostats.

We obtain the Massieu potential  $\Phi(n)$  that appears in (5) by subtracting the free-energy contribution of the exchanged matter. The 'semigrandcanonical' Gibbs free energy reads

$$\Phi(n) = \Phi_{\text{can}}(n) - \tilde{\mu} \cdot n, \qquad (233)$$

where  $\tilde{\mu}_i$  is the chemical potential of the part of species i that is exchanged with the chemostats. This is obtained by means of the quantities L(n) that are no longer conserved when the system is opened. The nonconservative forces  $a_{\rho}$  can be given in terms of the projection of cycle affinities  $f_{\rm nc}^k = \sum_{\rho} C_{\rho}^k \sum_{y=1}^{N_Y} \Delta_{\rho}^y \mu_y$  on the transition  $\rho$ ,

<span id="page-29-5"></span>
$$a_{\rho} = \sum_{k} f_{\rm nc}^{k} \mathbb{X}_{\rho}^{k}, \tag{234}$$

<span id="page-29-3"></span>where  $\mathbb{X}_{\rho}^k$  counts how many times the reaction  $\rho$  takes place in the cycle k. A cycle <sup>14</sup> is a sequence of transitions

<span id="page-29-4"></span> $<sup>^{14}</sup>$  Only emergent cycles enter (234), i.e. those that appear when

 $C_{\rho}$ , defined by  $\sum_{\rho} \Delta_{\rho}^{i} C_{\rho} = 0$  for all  $i = \{1, ..., N\}$ , that overall leave the dynamical species unchanged but results in exchange of matter between reservoirs.

In the macroscopic limit  $V \to \infty$  the concentration  $c_i = n_i/V$  of the species i stay finite. From (226) it is straightforward to derive that the macroscopic transition rates (27) are the polynomials

$$r_{\rho}(c) = k_{\rho} \prod_{j=1}^{N} c_{j}^{\nu_{\rho}^{j}}.$$
 (235)

Moreover the Massieu potential (236) is extensive as required by (26), and its density is obtained by applying Stirling's approximation:

$$\phi(c) = \mu_{\circ} \cdot c + T \sum_{i=1}^{N} (c_i \log c_i - c_i) - \tilde{\mu} \cdot c.$$
 (236)

At infinite volume V, the deterministic dynamics (45) is the chemical rate equation (Anderson and Kurtz, 2011; Kurtz, 1972)

$$d_t c = \sum_{\rho} \Delta_{\rho} k_{\rho} \prod_{j=1}^{N} c_j^{\nu_{\rho}^{j}}.$$
 (237)

Since (236) has a single minimum for a given value of conserved quantities, a macroscopic chemical reaction network at detailed balance can only have a single stable fixed point (Snarski, 2021). To create multiple attractors it is necessary either to consider interactions (i.e. to go beyond the mass-action kinetics (Avanzini et al., 2021)) that make (236) non-convex or to introduce nonconservative forces that induce a quasi-potential  $I_{\rm ss}$  with multiple minima. Nonconservative forces can also create more complex time-dependent attractors, such as limit cycles (Boland et al., 2008) or chaos (Epstein and Pojman, 1998; Gaspard, 2020). In the following we provide examples for dissipative multistability and periodic attractors.

#### <span id="page-30-0"></span>1. Dissipative metastability: Schlögel model

We consider the Schlögel model (Lazarescu et al., 2019; Schlögl, 1972; Vellela and Qian, 2009b), an autocatalytic chemical system displaying bistability far from equilibrium. It consists in the following set of chemical reactions,

$$2X + A \xrightarrow[k_{-1}]{k_{-1}} 3X ; B \xrightarrow[k_{-2}]{k_{-2}} X .$$
 (238)

Here, species A and B are chemostated reservoirs with constant concentration a and b, respectively. The only

the system is chemostatted.

degree of freedom is the number n of molecules of species X. The mesoscopic reaction rate (226) read

$$R_1(n) = \frac{k_{+1}}{V} a \, n(n-1), \qquad R_2 = k_{+2} b$$

$$R_{-1}(n) = \frac{k_{-1}}{V^2} n(n-1)(n-2), \quad R_{-2}(n) = k_{-2} n.$$
(239)

<span id="page-30-2"></span>and in the macroscopic limit  $V \to \infty$  they give for (235)

<span id="page-30-6"></span>
$$r_1(c) = k_{+1}a c^2, \quad r_{-1}(c) = k_{-1}c^3,$$
  
 $r_2 = k_{+2}b, \qquad r_{-2}(c) = k_{-2}c.$  (240)

The chemical rate equation reads (237)

$$d_t x = r_1(x) - r_{-1}(x) + r_2 - r_{-2}(x).$$
 (241)

<span id="page-30-1"></span>The only cycle affinity  $f_{nc} = \mu_A - \mu_B =: \Delta \mu$  is the chemical potential difference of the two reservoirs and corresponds to the log ratio of rates along a cycle

<span id="page-30-4"></span>
$$\Delta \mu = \ln \frac{r_1(c)r_{-2}(c)}{r_{-1}(c)r_2} = \ln \frac{ak_1k_{-2}}{bk_{-1}k_2}.$$
 (242)

<span id="page-30-3"></span>If we set  $k_{+1}a=1=k_{+2}b$  by choosing appropriate units for time and concentrations, (242) gives the parametrization of the rate constant  $k_{-1}=k_{-2}e^{-\Delta\mu}$  in terms of  $k_{-2}$  and  $\Delta\mu$ . Detailed balance is realized for  $\Delta\mu=0$ , such that both currents vanish  $r_1(x^{\rm eq})-r_{-1}(x^{\rm eq})=0=r_2-r_{-2}(x^{\rm eq})$ . This condition yields the equilibrium fixed point  $x^{\rm eq}=1/k_{-2}$ .

Since the model is a one-step jump process in one dimension, the exact quasi-potential  $I_{ss}$  is obtained by integrating (137),

<span id="page-30-5"></span>
$$I_{ss}(c) = c \log \left( \frac{c(1 + e^{-\Delta\mu}c^2)}{x^{eq}(1 + c^2)} \right) - c + \text{const}$$

$$+ 2e^{\frac{\Delta\mu}{2}} \arctan \left( e^{-\frac{\Delta\mu}{2}}c \right) - 2 \arctan(c),$$
(243)

where the constant is the normalization ensuring that  $\min_{\gamma} I_{ss}(x_{\gamma}^*) = 0$ . For  $\Delta \mu = 0$  the first line in (243) is the free energy (236). The rate function is non-convex for  $\Delta \mu \geq \ln 9$  and can display two local minima,  $x_1^* < x_2^*$ , only for  $k_{-2} \geq \sqrt{3}$ , corresponding to two stable fixed points of (241). The appearance of metastability at the stochastic level corresponds to a saddle-node or a supercritical pitchfork bifurcation at the deterministic level, depending on how the parameters  $k_{-2}$  and  $\Delta \mu$  are varied (Remlein and Seifert, 2024). At large V the transition times between the two metastable states are determined by the quasi-potential barrier height  $\Delta I_{\rm ss}$  :=  $I_{\rm ss}(x_{\nu}) - I_{\rm ss}(x^*)$ , according to (157). We compare the exact expression (243) with the approximated quasipotential (138) obtained by truncating the master equation into a chemical Fokker-Planck equation (134). Fig. 4 displays the difference in barrier height between the

![](_page_31_Figure_1.jpeg)

<span id="page-31-0"></span>FIG. 4 Difference in the barrier height (244) for the fixed point  $x_2^* > x_1^*$  as a function of the chemical potential difference  $\Delta \mu$  for  $k_{-2} = 3.5$ . Bistability is present above the critical value  $\Delta \tilde{\mu} \simeq 3.85$ . Inset: The quasi-potential  $I_{\rm ss}$  given by (243) (solid) and its approximation  $I_{\rm NLE}$  (dashed) for  $k_{-2} = 3.5$  and  $\Delta \mu = 5$ .

two expressions.

$$\delta := \Delta I_{\rm ss} - \Delta I_{\rm FPE},\tag{244}$$

varying  $\Delta\mu$  at fixed  $k_{-2}$ . The chemical Fokker-Planck equation is accurate close to the bifurcation while it systematically underestimates the barrier height away from it (Gaveau and Schulman, 1998b). Note that a difference  $\delta \simeq 0.2$ , for  $V \simeq 30$ , would result in a transition rate around 400 times larger than  $\kappa_{\nu}$ .

Since the system is one-dimensional, the stationary probability current (69) must be zero everywhere in order to vanish at infinity and to have zero derivative. Therefore,  $v_{\rm ss}(c)=0$  for all c and the deterministic drift  $F(c)=-\mathcal{M}(c)\partial_c I_{\rm ss}$  is only composed of the gradient part with mobility (73),  $\mathcal{M}=(\tilde{r}_1-\tilde{r}_{-1})/\ln\frac{\tilde{r}_1}{\tilde{r}_{-1}}$ , a monotonically growing function of c. Here,  $\tilde{r}_1=r_1+r_2$  and  $\tilde{r}_{-1}=r_{-1}+r_{-2}$  are the lumped rates that enter the information-theoretic entropy production rate (68),

$$\dot{\sigma}_{\rm info}(c) = \underbrace{(\tilde{r}_1(c) - \tilde{r}_{-1}(c))}_{F(c)} \underbrace{\ln \frac{\tilde{r}_1(c)}{\tilde{r}_{-1}(c)}}_{-\partial_c I_{\rm ss}(c)}. \tag{245}$$

Hence, the dynamics in configuration space appears reversible <sup>15</sup> and one can check by direct substitution of (137) into (109) that relaxation and instanton dynamics

![](_page_31_Figure_10.jpeg)

<span id="page-31-5"></span>FIG. 5 Instantaneous entropy production rate (112) along a stochastic trajectory (obtained via Gillespie algorithm (Gillespie, 1977) with  $\Delta\mu=2.84,\,k_{-2}=2.07$  and  $V=10^2$ ) starting in the basin of attraction of  $x_1^*$  and ending in the one of  $x_2^*$ . The solid lines are the constant values of the macroscopic mean entropy production in the two fixed points (225) and the mean entropy production rate along the transition trajectory (249).

<span id="page-31-1"></span>are one the time reversal of the other:

<span id="page-31-4"></span>
$$d_t c(t) = \tilde{r}_1 e^{\partial_c I_{ss}} - \tilde{r}_{-1} e^{-\partial_c I_{ss}} = -(r_1 - r_{-1})$$
  
=  $-d_t x(t)$ . (246)

However, the underlying chemical reactions are not in equilibrium as witnessed by the fact that the dual rates

$$r_{1}^{\dagger} = \frac{c^{4} + c^{2}}{e^{\Delta\mu} + c^{2}}, \qquad r_{-1}^{\dagger} = \frac{e^{-\Delta\mu}c^{5} + c^{3}}{x^{\text{eq}}(x^{2} + 1)},$$

$$r_{2}^{\dagger} = \frac{e^{\Delta\mu}(c^{2} + 1)}{e^{\Delta\mu} + c^{2}}, \qquad r_{-2}^{\dagger} = \frac{e^{-\Delta\mu}c^{3} + c}{x^{\text{eq}}(c^{2} + 1)},$$
(247)

equal the physical rates  $r_{\rho}$  only at  $\Delta \mu = 0$ . Interestingly, for  $\Delta \mu \neq 0$  they do not follow the mass action law (235).

<span id="page-31-3"></span>Since bistability is created only far from equilibrium,  $\sigma_{\gamma \to \nu}$  and  $|\sigma_{\nu \to \gamma}|$  are very large, thus making the bound (160) very loose. Nevertheless, the bound turns into an equality if the thermodynamic entropy production is replaced by (245), which equals the time derivative (resp. negative time derivative) of the rate function (243) along the instanton (resp. the relaxation) thanks to (246):

$$\dot{\sigma}_{\rm info} = d_t I(c(t)) = -d_t I(x(t)). \tag{248}$$

For long times the system can be described by a 2-state Markov jump processes with transition rates  $\kappa_{\pm 1}$  (Vellela and Qian, 2009b). The entropy production (112) of the underlying dynamics is compared in Fig. 5 with the internal entropy production of the metastable states (225) and the entropy production rate calculated along the transition path from a neighborhood of  $x_1^*$  to a neighborhood

<span id="page-31-2"></span><sup>&</sup>lt;sup>15</sup> One can also write the drift field as the derivative of a function  $F(c) = -d_c h(c)$  such that  $d_t h(x(t)) = -F^2(x(t)) \leq 0$ , which has no connection with the quasi-potential, though.

of  $x_2^*$  in time  $\langle \tau^{tr} \rangle$ ,

$$\langle \dot{\sigma}_{\nu}(t) \rangle = \sum_{\rho} r_{\rho}(c(t)) e^{\Delta_{\rho} \cdot \pi(t)} \ln \frac{r_{\rho}(c(t))}{r_{-\rho}(c(t))}. \tag{249}$$

Here, c(t) and  $\pi(t)$  are solution of (107) on the manifold  $\mathcal{H}(c(t), \pi(t)) = E$  implicitly determined by the relation

$$\langle \tau^{\rm tr} \rangle = \int_0^{\langle \tau^{\rm tr} \rangle} dt = \int_{\mathcal{D}} \frac{dc}{\dot{c}(c, \pi(c, E))},$$
 (250)

with integration domain  $\mathfrak{D} = [x_1^* + 1/\sqrt{\Omega}, x_2^* - 1/\sqrt{\Omega}]$ . We note that, since there exist no exact formula for  $\langle \tau_{tr} \rangle$ , its value is estimated using the expression valid for detailed balanced dynamics (Malinin and Chernyak, 2010), replacing the height of the energy barrier with the one of the quasi-potential.

### <span id="page-32-0"></span>2. Entropy production in a limit cycle: Brusselator model

We consider the Brusselator model, a prototypical model displaying a limit cycle far from equilibrium (Andrieux and Gaspard, 2008; Lefever *et al.*, 1988; Nguyen and Seifert, 2020; Prigogine and Lefever, 1968). It is an autocatalytic chemical reaction network,

$$Y_1 \xrightarrow{k_{+1}} X_1 ; X_1 + Y_2 \xrightarrow{k_{+2}} X_2 + Y_3$$
 (251)

$$2 X_1 + X_2 \stackrel{k_{+3}}{\stackrel{}{\overline{\setminus}}} 3 X_1 ; \quad X_1 \stackrel{k_{+4}}{\stackrel{}{\overline{\setminus}}} Y_4 , \qquad (252)$$

made up of two dynamical species  $X_1$  and  $X_2$  and four chemostated species  $Y_y$  (with concentrations denoted  $c_{Y_y}$ ). The model has 2 emergent cycles  $C^1=(1,0,0,1)$  and  $C^2=(0,1,1,0)$  with corresponding cycles affinities  $f_{nc}^1=\log\frac{k_1k_4c_{Y_1}}{k_{-1}k_{-4}c_{Y_4}}$  and  $f_{nc}^2=\log\frac{k_2k_3c_{Y_2}}{k_{-2}k_{-3}c_{Y_3}}$ . The dynamics is detailed balanced when the chemical potentials of all  $c_{Y_i}$ 's are equal, so that the cycle affinities are zero.

Choosing the concentration of  $Y_1$  as a control parameter, the deterministic rate equation (237) displays a supercritical Hopf bifurcation, namely, a transition from a single stable fixed point to a stable limit cycle with period  $t_p$ . This is seen from a linear stability analysis of the deterministic rate equations,

$$d_t x_1 = r_1 - r_{-1} - r_2 + r_{-2} + r_3 - r_{-3} - r_4 + r_{-4},$$
  

$$d_t x_2 = r_2 - r_{-2} - r_3 + r_{-3},$$
(253)

<span id="page-32-2"></span>with macroscopic scaled rates

$$r_{1} = k_{1}c_{Y_{1}}, r_{-1} = k_{-1}c_{1},$$

$$r_{2} = k_{2}c_{1}c_{Y_{2}}, r_{-2} = k_{-2}c_{2}c_{Y_{3}},$$

$$r_{3} = k_{3}c_{1}^{2}c_{2}, r_{-3} = k_{-3}c_{1}^{3},$$

$$r_{4} = k_{4}c_{1}, r_{-4} = k_{-4}c_{Y_{4}}.$$

$$(254)$$

The eigenvalues of the Jacobian of the drift field evaluated at the fixed point,  $\partial_c F(x^*)$ , are a complex pair that develops a positive real part above some critical value  $\tilde{c}_{Y_1}$  and a stable periodic trajectory appears. Here we point out the failure of the Langevin approximation in the description of the system thermodynamics. The macroscopic entropy production rate associated to the chemical Langevin equation (144) time-averaged over a period reads

<span id="page-32-4"></span>
$$\overline{\dot{\sigma}_{\text{NLE}}} := \frac{1}{t_{\text{p}}} \int_{0}^{t_{\text{p}}} dt \lim_{V \to \infty} \langle \dot{\sigma}_{\text{NLE}} \rangle 
= \frac{1}{t_{\text{p}}} \int_{0}^{t_{\text{p}}} dt F(x^{*}(t)) \cdot D^{-1}(x^{*}(t)) \cdot F(x^{*}(t)),$$
(255)

with  $x^*(t) = x^*(t + t_p)$  the periodic solution of (253) In Fig. 6, we show, by integrating numerically the rate equation (237), that the exact period-averaged entropy production rate

$$\overline{\dot{\sigma}} := \frac{1}{t_{\rm p}} \int_0^{t_{\rm p}} dt \lim_{V \to \infty} \langle \dot{\sigma} \rangle \tag{256}$$

$$= \frac{1}{t_{\rm p}} \int_0^{t_{\rm p}} dt \sum_{\rho > 0} [r_{\rho}(x^*(t)) - r_{-\rho}(x^*(t))] \ln \frac{r_{\rho}(x^*(t))}{r_{-\rho}(x^*(t))},$$

is largely underestimated by the approximation (255), and even its qualitative behavior as a function of  $c_{Y_1}$  is incorrect. In particular, the latter is identically zero for  $c_{Y_1} > \tilde{c}_{Y_1}$ , i.e. in the absence of limit cycle, since the drift F is by definition null on the fixed point, as shown in general in (145). Note that the Langevin approach is often used to estimate the energetic cost of biochemical oscillations (Cao et al., 2020; Xiao et al., 2008).

## <span id="page-32-1"></span>B. Electronic systems

<span id="page-32-3"></span>We consider an arrangement of ideal conductors whose state is determined by the charge vector q and electrostatic potential vector V (Freitas et al., 2021a). The potentials are measured with respect to some reference (ground) potential and are linearly related to the charges,  $q = C \cdot V$ , through the capacitance matrix C. The internal energy of the system is thus

<span id="page-32-5"></span>
$$E = \frac{1}{2}q \cdot V. \tag{257}$$

![](_page_33_Figure_1.jpeg)

<span id="page-33-0"></span>FIG. 6 Mean scaled entropy production rate averaged over one period in the infinite system-size limit: Exact expression corresponding to (61) (circles  $\circ$ ) and the approximation based on the expression (144) given by the nonlinear Langevin equation (squares  $\square$ ). The vertical dashed line shows the critical value  $\tilde{c}_{Y_1} \simeq 0.97$  for the onset of the supercritical Hopf bifurcation. Parameters are  $k_1 = 1.00, k_2 c_{Y_2} = 3.00, k_3 = 1.00, k_4 = 1.00, k_{-1} = 0.01, k_{-2} c_{Y_3} = 0.01, k_{-3} = 0.01, k_{-4} c_{Y_4} = 0.01$ .

The system is open when  $N_Y$  conductors have fixed potentials imposed by external voltage sources, so that the state is specified by N charges. Elementary charges with value  $q_e$  are transported between pairs of conductors by two-terminal devices. Each of these channels is modeled as a bidirectional Poisson process labelled by  $\pm \rho$ with rate  $R_{\pm\rho}(q)$ , which changes the system state as  $q \to q \pm q_e \Delta_{\rho}$ . This allows one to describe many relevant devices, e.g., tunnel junctions, diodes, MOS transistors in subthreshold operation (Freitas et al., 2021a). The matrix with entries  $\Delta_{\rho}^{i}$ , encoding the circuit network, is the analogue of the stoichiometric matrix of chemical reactions in Sec. VII.A. Its left (resp. right) null vectors identify the conserved quantities (resp. the cycles). The stochastic dynamics is given by (1) with  $nq_e = q$  and  $q_e J_\rho$  the electric current on each channel device. Heat conduction is assumed large enough such that the temperature in each conductor is constant and equal to T (i.e. no self heating (Semenov et al., 2006)).

A closed circuit satisfies the detailed balance condition

$$T \ln \frac{R_{\rho}(q)}{R_{-\rho}(q + q_e \Delta_{\rho})} = -E(q + q_e \Delta_{\rho}) + E(q),$$
 (258)

with the quadratic energy (257) (because  $S_{\text{int}} = 0$ ), and relaxes to the equilibrium distribution at fixed value of the conserved quantities L(q),

$$P_{\rm eq}(q) \propto e^{-E(q)/T} \delta(L(q) - L). \tag{259}$$

For open circuits, the Massieu potential is obtained by

subtracting from the electrostatic energy the contribution exchanged with the regulated conductors

<span id="page-33-4"></span>
$$\Phi(q) = E(q) - \tilde{V} \cdot q, \tag{260}$$

with an appropriate voltage vector  $\tilde{V}$  that is constructed from the quantities L(q) that are no longer conserved when the system is opened. Very analogously to chemical reaction networks, the forces  $a_{\rho}$  are differences between the voltages of regulated conductors in the connected components of the channel  $\rho$  (Freitas et al., 2021a).

The explicit form of the transition rates can be obtained from the I-V curve that gives the macroscopic average electric current  $\langle I \rangle (V)$  through a two-terminal device as a function of the applied voltage V across it. In the case of a constant voltage V, the mean current

$$\langle I \rangle (V) = q_e (R_+ - R_-) \tag{261}$$

and the local detailed balance

<span id="page-33-2"></span><span id="page-33-1"></span>
$$T \ln \frac{R_+}{R_-} = q_e V \tag{262}$$

are two independent equations that allow one to determine  $R_{\pm}$ . In the general case of a device embedded in a circuit, the transition rates  $R_{\pm\rho}$  are obtained replacing the constant V in (261) and (262) with the average of the voltage difference before and after the transition  $q \to q \pm q_e \Delta_{\rho}$  (Freitas et al., 2021a). In closed circuits, choices different from such midpoint rule would lead to a stationary probability density different from the equilibrium (259), thus entailing the possibility to indefinitely extract energy (see Brillouin paradox (Brillouin, 1950)).

We focus on those devices in which the characteristic capacitance  $C \to \infty$  and the transition rates  $R_{\pm\rho}$  (thus the charges  $q \to \infty$ ) scale with the system size. Hence, in the macroscopic limit we consider the elementary voltage  $v_e = q_e/C \to 0$  negligible in comparison to all other voltage scales of the circuit and equal to the inverse of the large parameter  $V \equiv 1/v_e \to \infty$ .

<span id="page-33-3"></span>Open electronic circuits under detailed balance conditions cannot be used to store information nor to generate signals with specific frequencies. These are prevented by the fact that the Massieu potential (260) has a unique minimum  $x_{\rm eq}=0$  and the spectrum of the generator of the (overdamped) dynamics is real (see Sec. III.C), respectively. Multistability and oscillations require nonconservative forces created by voltage differences. In practice, they can be realized connecting 2 inverters, i.e. NOT gates, in a loop (SRAM cell (Rezaei et al., 2020)) and an odd number of inverters in a chain (ring oscillator (Hajimiri et al., 1999)), respectively.

## <span id="page-34-0"></span>1. Dissipative logical states: CMOS SRAM cell

Low-power static random access memory (SRAM) cells are usually implemented by connecting two CMOS inverters. Each inverter is composed of a pMOS and a nMOS transistor, see Fig. 7, and is powered by a voltage bias  $2V_{dd}$ . Each pMOS (resp. nMOS) transistor can be modeled as a conduction channel between drain and source terminals, with associated transition rates  $R^p_{\pm}$  (resp.  $R^n_{\pm}$ ) (Freitas et al., 2021a). The voltages  $v_1$  and  $v_2$  at the output of each inverter are the two independent degrees of freedom, given by  $v = nq_e/C$  with n the number vector of charges and C the capacitance characterizing the device. Following the general procedure introduced in the previous section based on the I-V curve and the local detailed balance, with Massieu potential  $\Phi(v_1, v_2) = C(v_1^2 + v_2^2)/2 + CV_{\rm dd}^2$ , one obtains

$$R_{+}^{p}(v_{1}, v_{2}) = (I_{0}/q_{e})e^{(V_{dd}-V_{th}-v_{2})/(nV_{T})}$$

$$R_{-}^{p}(v_{1}, v_{2}) = R_{+}^{p}(v_{1}, v_{2})e^{-(V_{dd}-v_{1})/V_{T}-v_{e}/(2V_{T})}$$
(263)

and  $R_{\pm}^{n}(v_1, v_2) = R_{\pm}^{p}(-v_1, -v_2)$  (Freitas *et al.*, 2022a), where  $I_0$ ,  $V_{\rm th}$  and n are parameters characterizing the transistor. The non conservative work of the transitions is  $a_{\pm\rho} = \pm q_e V_{\rm dd}$ .

The macroscopic limit is obtained as  $v_e \to 0$  with the bias voltage  $V_{\rm dd}$  and the thermal voltage  $V_{\rm T} = k_{\rm B}T/q_e$  kept finite. The corresponding macroscopic transition rates read

$$r_{+}^{p}(v_{1}, v_{2}) = (I_{0}/C)e^{(V_{dd} - V_{th} - v_{2})/(nV_{T})}$$

$$r_{-}^{p}(v_{1}, v_{2}) = r_{+}^{p}(v_{1}, v_{2})e^{-(V_{dd} - v_{1})/V_{T}},$$
(264)

and yield the deterministic dynamics of voltages

$$d_t v_1 = I_p(v_1, v_2) - I_n(v_1, v_2) d_t v_2 = I_p(v_2, v_1) - I_n(v_2, v_1),$$
(265)

in terms of the difference of currents between the two transistors,  $I_{p/n}(v_1,v_2) = r_+^{p/n}(v_1,v_2) - r_-^{p/n}(v_1,v_2)$ . Equations (265) admit a single stable fix point  $v_1^* = v_2^* = 0$  for small bias  $V_{\rm dd} \leq V_{\rm T} \ln 2$  and two stable (symmetric) fixed points  $\pm v^* = \pm (v_{\rm bit}, -v_{\rm bit})$  with (n = 1)

$$v_{\rm bit} = V_{\rm dd} + V_{\rm T} \ln \left( \frac{1}{2} + \sqrt{1/4 - e^{-2V_{\rm dd}/V_{\rm T}}} \right), \quad (266)$$

separated by a saddle in the origin for  $V_{\rm dd} > V_{\rm T} \ln 2$ . These explicit formulae hold for n = 1, although more lengthy expressions can also be derived for n  $\neq$  1. The pitchfork bifurcation undergone by the dynamical system (265) at the critical value  $\tilde{V}_{\rm dd} := V_{\rm T} \ln 2$  corresponds to the emergence of bistability in the deterministic dynamics and makes the system usable as a volatile memory. Initializing the voltages in a given basin of attraction allows one to store 1 bit of information for

a mean time equal to the inverse of the escape rate  $\kappa \simeq e^{-[I_{ss}(0)-I_{ss}(v^*)]/v_e}$ . The energy dissipated to maintain such a logical state is  $T\langle \sigma_{\pm 1}\rangle$ , where the mean entropy production rate (225) reads

$$\langle \dot{\sigma}_{\gamma=\pm 1} \rangle = V_{\rm dd} q_e \sum_{\rho} \langle j_{\rho} \rangle = 4V_{\rm dd} I_0 e^{-V_{\rm th}/V_{\rm T}}.$$
 (267)

The quasi-potential cannot be obtained analytically. Nevertheless, if only rare fluctuations leading to memory losses are of interest, we can restrict the analysis to the linear space  $c=(v_1-v_2)/2$ . Due to the symmetry of the rates, relaxation and instanton trajectories that connect the fixed points to the saddle lie entirely on the reaction coordinate c at  $v_1+v_2=0$ , see Fig. 7. The determination of  $I_{\rm ss}(c)$  reduces to a one dimensional problem very analogous to the one of Sec. VII.A.1. Writing (34) in terms of the new variable c and setting  $v_1=-v_2$ ,  $\pi_1=-\pi_2=\partial_c I_{\rm ss}(c)$  gives (136), whose integral is

<span id="page-34-2"></span>
$$I_{ss}(c) = \frac{c^2}{V_{T}} + \frac{n}{V_{T}(n+2)} [L(-c, V_{dd}) - L(c, -V_{dd}) + L(c, V_{dd}) - L(-c, -V_{dd})] + const,$$
(268)

with  $L(c, V_{dd}) = Li_2(-\exp((V_{dd} + c(1 + 2/n))/V_T))$  and  $Li_2(.)$  the polylogarithm function of second order. Equation (268) was derived in (Freitas *et al.*, 2022b) and is reported here in an equivalent form that shows explicitly the symmetry  $I_{ss}(c) = I_{ss}(-c)$ .

For  $V_{\rm dd} \to 0$  (268) reduces to the macroscopic Massieu potential on the subspace  $v_1 = -v_2$ ,

$$\phi(c) := \lim_{v_e \to 0} v_e \Phi(c, -c) = \frac{c^2}{V_T}.$$
 (269)

<span id="page-34-1"></span>The quasi-potential barrier takes the simple expression

$$I_{\rm ss}(0) - I_{\rm ss}(v_{\rm bit}) \simeq \frac{2}{2+n} \frac{V_{\rm dd}^2}{V_{\rm T}}$$
 (270)

in the far-from-equilibrium regime  $V_{\rm dd} \gg V_{\rm dd}$ , and leads to the error rate due to thermal noise

$$-\lim_{v_e \to 0} v_e \ln \kappa \propto \langle \dot{\sigma}_{\gamma = \pm 1} \rangle^2. \tag{271}$$

Remarkably, the stability of the electronic memory grows proportionally to the square of the macroscopic dissipation of the device. This direct relation between the two quantities is made possible by the fact that the macroscopic current  $I_0e^{-V_{\rm th}/V_{\rm T}}$  is constant in the bistable regime.

As for the Schlögl model of Sec. VII.A.1, relaxation and instanton dynamics along c are related by time reversal, sharing the same local speed  $\dot{c}(c)$ . Yet, the corresponding local entropy production rates differ, leading in general

![](_page_35_Figure_1.jpeg)

<span id="page-35-1"></span>FIG. 7 Left: Circuit diagram of a CMOS SRAM cell. Right: Instanton obtained by the minimum action method (Zakine and Vanden-Eijnden, 2023) evolves at  $v_1 = -v_2$  and  $\pi_1 = -\pi_2$ . Parameter values are  $(I_0/C)e^{-V_{\rm th}/V_{\rm T}}$ , n=1,  $V_{\rm T}=1$ ,  $V_{\rm dd}=0.9$ . Right: The height of the quasi-potential barrier obtained from (268) (solid) as a function of  $V_{\rm dd}$ , and its upper and lower bounds, i.e. entropy production of the instanton (square) and negative entropy production of the relaxation (circle), respectively. The latter ones are obtained according to (272) with a small parameter  $\epsilon=0.02$ .

to

$$\sigma_{\nu \to \gamma} = \int_{\mathfrak{D}} dc \frac{\dot{\sigma}_{\nu \to \gamma}(c)}{\dot{c}(c)} \neq -\int_{\mathfrak{D}} dc \frac{\dot{\sigma}_{\gamma \to \nu}(c)}{\dot{c}(c)} = -\sigma_{\gamma \to \nu},$$
(272)

when the integration over the domain  $\mathfrak{D} = [1/\sqrt{\Omega}, v_{\rm bit} - 1/\sqrt{\Omega}]$  is performed. Equality in modulus is achieved only at linear order in  $V_{\rm dd}$ ,

$$\frac{\dot{\sigma}_{\nu \to \gamma}(c)}{\dot{c}(c)} = -\frac{2c}{V_{\rm T}} + \frac{2V_{\rm dd}}{V_{\rm T}} \tanh\left(\frac{(\rm n+2)c}{2\rm n}V_{\rm T}\right) + O(V_{\rm dd}^2),\tag{273}$$

whose integral gives the near-equilibrium approximation (120) of the rate function (Freitas et al., 2021b). Since bistability does not appear at vanishing bias the thermodynamic bounds (160) are quite loose due to large values of the adiabatic entropy production, see Fig. 7. Nevertheless, the bounds (160) turn into an equality by replacing the thermodynamic entropy production by the coarsegrained quantity (245) along c with the lumped rates  $\tilde{r}_{\pm}(v_1,v_2) = r_{\pm}^p(v_1,v_2) + r_{\mp}^n(v_1,v_2)$  (Freitas and Esposito, 2022a). Note that close to the bifurcation point the quasi-potential barrier vanishes and the regions of typical fluctuations around the fixed point overlap. The escape rate between attractors is dominated by sub-exponential terms neglected in (157) and (160) becomes obsolete – see Sec. VII.C for a discussion of the attractor stability in this regime.

## <span id="page-35-0"></span>C. Driven Potts models

We consider a system that consists of  $V\equiv M$  all-to-all interacting identical units subject to the same nonconservative force a and identically coupled to a thermal bath of temperature T. Each unit is made of  $N\equiv q$  identical states on a ring coupled to their nearest neighbors

<span id="page-35-2"></span>16. Due to the mean field nature of the interactions between units, all configurations with the same number  $n_i$  of units in states i = 1, ..., q are equivalent. The internal entropy of the system resulting from such a degeneracy is (Herpich *et al.*, 2020a)

$$S_{\text{int}}(n) = \ln \frac{M!}{\prod_{i=1}^{q} n_i!},$$
 (274)

and the energy accounts for the interactions between all units in the same state i

$$U = \frac{1}{2M} \sum_{i=1}^{q} u_i n_i (n_i - 1), \tag{275}$$

where the prefactor 1/M makes the mean-field energy extensive, according to Kac's prescription (Kac et al., 1963). The system has q forward and q backward mesoscopic transitions each connecting two successive single-unit states. The stochastic transitions  $\rho = \pm i$  change the populations of nearby states i and i+1 as  $(n_i, n_{i+1}) \rightarrow (n_i \mp 1, n_{i+1} \pm 1)$ , that is  $\Delta_{\rho}^i = -\delta_{\rho,i} + \delta_{-\rho,i} + \delta_{\rho,i-1} - \delta_{-\rho,i-1} = -\Delta_{-\rho}^i$ , where i and  $\rho$  are meant modulo q.

In the limit  $M \to \infty$ , we obtain the scaled internal entropy (using Stirling's approximation)

$$s_{\text{int}}(c) = -\prod_{i=1}^{q} c_i \ln c_i,$$
 (276)

constituting the macroscopic system entropy (58), and the scaled energy

$$u(c) = \frac{1}{2} \sum_{i=1}^{q} u_i c_i^2, \tag{277}$$

<span id="page-35-3"></span> $<sup>^{16}</sup>$  We use the letter q to denote the number of accessible mesoscopic states, as customary for the Potts model (Wu, 1982)

![](_page_36_Figure_1.jpeg)

<span id="page-36-1"></span>FIG. 8 Sketch of the driven Potts model. (a) A single unit is composed of q states, identified by a single spin configuration. Counterclockwise transitions are favored by a nonconservative thermodynamic force a>0. (b) Interactions, entering the transition rates (279), are between the same state i of all M units.

in terms of the occupation densities c:=n/M. Hence, the macroscopic entropy production (29) for transitions  $|\rho|=i$  between single-unit states i and i+1 takes the form

$$\sigma_{\rho}(c) = \mp [(\partial_{c_{i+1}} - \partial_{c_i})\phi(c)] \pm a, \qquad (278)$$

where  $\phi(c) = u(c)/T - s_{\rm int}(c)$  is the scaled Helmholtz free energy divided by the temperature T, as introduced in (6), and the nonconservative part  $a_{\pm\rho}=\pm a$  favors unidirectional rotation along the single-unit states. With attractive interactions  $u_i=-\mathcal{F}>0$  equal for all state i, this class of systems includes the driven Curie-Weiss model, i.e. the mean-field Ising model (q=2) – in which  $c_1-c_2=m$  is the magnetization – and the ferromagnetic mean-field Potts model  $(q\geq 3)$ . In all cases, the state of a unit can be identified with a spin orientation, see Fig. 8.

A possible choice of single-unit transition rates that respects the local detailed balance is the so-called Arrhenius form that is characterized by an exponential form and a global time scale  $1/\gamma$  (Meibohm and Esposito, 2024b). In this case, the scaled macroscopic transition rates (27) for transitions  $\rho=i$  (resp.  $\rho=1-i$ ) between single unit states i and i+1 (resp. i-1) reads

$$r_o(c) = \gamma c_i e^{\frac{1}{2} \left[ \frac{1 \mp \xi}{T} (u_{i\pm 1} c_{i\pm 1} - u_i c_i) \pm a \right]},$$
 (279)

with  $-1 \le \xi \le 1$ . Note that the logarithm of  $r_i(c)/r_{-i}(c)$  equals precisely (278) with the change of internal entropy  $s_{\text{int}}$  given by  $\ln(c_i/c_{i+1})$ . Extensions have been studied that include a constant energy bias for each state i, interactions between different single-unit states and coupling to baths at different temperatures (Herpich *et al.*, 2020a).

In the detailed balance Curie-Weiss model in contact with a single thermal bath  $(q = 2 \text{ and } a_{\rho} = 0)$ , the emergence of a dynamical phase transition was observed upon an instantaneous disordering quench from low to high

temperature, i.e. the appearance at the critical time  $t_c$  of a kink in the time-dependent rate function of the magnetization I(m,t) (Meibohm and Esposito, 2022). This corresponds to a sudden change in the optimal fluctuations driven by the competition in (108) between the statistical weights of a trajectory and of its initial condition, which are  $\mathcal{A}$ , as given in (106), and I(m(0), 0), respectively. An analogous dynamical phase transition occurs in the timedependent rate function of the exchanged heat, similarly due to a change of dominance in the most likely trajectories (Meibohm and Esposito, 2023). For the Curie-Weiss model in contact with two different thermal baths (i.e. two sets of transitions (279) each associated with a bath at a different temperature), a different dynamical phase transition appears as a kink in the steady state cumulant generating function of the exchanged heat (Herpich et al., 2020a). In this case, as we have described in Sec. IV.I.2, the singularity stems from the competition between the multiple stationary solutions of the tilted Hamiltonian equations (177), and represents a signature of the bistability of the system in the current statistics.

<span id="page-36-2"></span>The driven Potts model  $(q \geq 3)$  has been extensively studied, e.g. as a model for synchronization in workto-work converters (Herpich and Esposito, 2019; Herpich et al., 2018b). The deterministic dynamics can be examined thoroughly. As  $T/\mathcal{J} \to \infty$  the system becomes effectively detailed balanced and the dynamics is entropydominated with a single stable, disordered fixed point  $x^* = (1/q, \dots, 1/q)$ . Conversely, as  $T/\mathcal{J} \to 0$  the system is energy-dominated with q stable, ordered fixed points characterized by all units in the same state, i.e.  $x_{\gamma=1}^* = (1,0,\ldots,0)$  and  $x_{\gamma>1}^*$  is obtained by cyclic permutations of the elements of the vector  $x_{\gamma=1}^*$ . Above a critical coupling strength  $\mathcal{J}_c$ , the disordered fixed point becomes unstable. For  $|a| \to 0$ , independently of the choice of transition rates (e.g.  $\xi$  in (279)),  $\mathcal{J}_c \rightarrow qT$ and the macroscopic system settles in one ordered fixed point. When detailed balance is broken,  $\mathcal{J}_c$  depends on the specific class of transition rates (279), and for  $\mathcal{J} > \mathcal{J}_{c}$  the system can display time-dependent attractors  $x_{\infty}^{*}(t)$  corresponding to the synchronized motion of all the units. The macroscopic deterministic dynamics close to the bifurcation can be solved exactly by transforming to Fourier modes  $\hat{c}_k := \sum_{j=0}^{q-1} c_j e^{i2\pi jk/q}$  and deriving normalized for the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of the property of mal form equations for their amplitude  $r_k$  and phase  $\varphi_k$ (Meibohm and Esposito, 2024a,b). The emerging phase diagram – as a function of q and the dynamical class. e.g.  $\xi$  in (279) – is extremely rich. One finds regions with a finite number of active modes  $|S_a| = 1, 2, \dots$ , i.e. modes k such that  $r_k > 0$ . In the region  $|S_a| = 1$ , several single-mode oscillating states can be simultaneously stable. For  $|S_a| \geq 2$  a unique multi-mode oscillating state exists, which is in general a quasi-periodic attractor since the different modes show frequencies with irrational ra-

<span id="page-36-0"></span>The coexisting limit cycles at  $|S_a| = 1$  become

metastable at large but finite M. In particular, very close to the bifurcation, the system switches between them thanks to typical fluctuations, not via rare instantons. Indeed, the quasi-potential barrier separating the stochastic limit cycles vanishes,  $\Delta I_{\rm ss} \rightarrow 0$ , and the escape rate is dominated by the subexponential prefactor neglected in (157). The life time of such competing states is decided by the phase space contraction rate  $\lambda$  defined in (47), whose magnitude corresponds to the macroscopic limit of the inflow rate (25) averaged over the attractor. In general, such connection between the Lyapunov stability of the deterministic dynamics and the typical fluctuations is given by (130). Close to the bifurcation point, one can prove the stability-dissipation relation (Meibohm and Esposito, 2024a,b)

$$\Delta \dot{\sigma} \propto \Delta \lambda,$$
 (280)

where  $\Delta\langle 6 \rangle := \lim_{N \to \infty} (\langle 6 \rangle - \langle 6 \rangle_{g=0})/\langle 6 \rangle_{g=0}$  stands for the normalized variation of the average values of the observable 6 between interacting and noninteracting (i.e.  $\mathcal{J} = 0$ ) conditions. The macroscopic mean,  $\lim_{N \to \infty} \langle 6 \rangle$ , is in general different on each attractor. Therefore, the relation (280) implies that the least dissipative attractor is the most stable one. This constitutes the first derivation of a minimum entropy production principle valid far-from-equilibrium. It is crucial to note that the entropy production rate entering (280) is a thermodynamic quantity, linked to the microscopic energetics of the system by the local detailed balance (29), not an abstract definition of dissipation based on information theory arguments (Daems and Nicolis, 1999).

The above Potts model can be embedded in a d-dimensional physical space. To this end, we consider a lattice in which each node contains a large number of q-state units described in the macroscopic limit by a local density  $c_{i,x}$  (see V.A). Units can not only change their internal state, i.e. rotate the spin, but also jump to nearby lattice sites with rates belonging to the sets R and C, respectively. The scaled entropy production rate reads

$$\sigma_{\rho}(\{c_{i,x}\}) = \mp [(\partial_{c_{i+1,x}} - \partial_{c_{i,x}})\phi] \pm a^{\text{rot}},$$
 (281)

for transitions  $\rho \in R$  between states i and i+1 and

$$\sigma_{\rho}(\{c_{i,x}\}) = -[(\partial_{c_{i,x'}} - \partial_{c_{i,x}})\phi] + a_{\rho}^{\text{tra}},$$
 (282)

for transitions  $\rho \in C$  from site x to the neighboring site x'. Detailed balance is broken by the nonconservative contributions  $\pm a^{\rm rot}$  and  $a_{\rho}^{\rm tra}$  that force the spin to rotate and to drift in space, respectively. By choosing  $a_{\rho}^{\rm tra}$  to be constant in magnitude and aligned with the local spin direction, one obtains a toy model for self-propelled particles. In the following, we restrict ourselves to the case of active Ising spins, i.e. q=2, but the discussion can be seamlessly generalized to q>2.

Taking the continuous limit by sending the lattice spac-

ing  $\epsilon$  to zero as detailed in Sec. V.A, one gets a stochastic field theory for  $c_{i,x} \to c_i(r,t)$ ,

<span id="page-37-1"></span>
$$\partial_t c_i = -\nabla \cdot \left[ \underbrace{\gamma c_i \left( -\nabla \frac{\delta u}{\delta c_i} + f_i \right) - \gamma T \nabla c_i + \xi_i}_{j_i[c]} \right] + I_i.$$
(283)

Here  $\xi_i$  are independent zero-mean Gaussian white noise fields with variance  $2\gamma T c_i/\Omega$  and  $\Omega$  the system size,  $I_1 = -I_2$  is a white noise field with Skellam distribution (Skellam, 1946) being the difference of Poissonian jumps in and out of the single-unit state i (e.g. with rates (279)), and constant drift vector  $f \equiv f_1 = -f_2$  that derives from the continuous limit of  $a_\rho^{\rm tra}$ . Note that  $\chi = \gamma c \mathbb{I}$  is the mobility matrix and the diffusive flux  $-\gamma T \nabla c$  stems from the entropic term  $-\chi \cdot \nabla \delta s_{\rm int}/\delta c$ . Summing and subtracting the two equations in (283), one can obtain closed stochastic equations for the local magnetization  $m(r,t) := c_1(r,t) - c_2(r,t)$  and the local density of spins  $c_{\rm tot}(r,t) := c_1(r,t) + c_2(r,t)$ .

<span id="page-37-0"></span>The macroscopic entropy production follows directly from the general expression derived in Sec. V.B. In particular, in a stationary state it reduces to the nonconservative contribution (212),

<span id="page-37-2"></span>
$$\dot{\sigma}_{\rm nc} = \int dr \left[ a^{\rm rot} \langle I_1 \rangle + f \cdot (\langle j_1 \rangle - \langle j_2 \rangle) \right], \qquad (284)$$

which displays, in order, the contribution of the singleunit rotational driving and of the active drift in space. Using the explicit expressions of the currents  $\langle j_i \rangle$  in (283), the entropy production of translation in (284) reads

$$\begin{split} \dot{\sigma}_{\rm nc} &\underset{a^{\rm rot}=0}{=} \int dr f \cdot (\langle j_1 \rangle - \langle j_2 \rangle) \\ &= \gamma f^2 c_{\rm tot} + \gamma f \cdot \int dr \left( c_1 \nabla \frac{\delta \phi}{\delta c_1} - c_2 \nabla \frac{\delta \phi}{\delta c_2} \right). \end{split}$$

In particular, one finds

<span id="page-37-3"></span>
$$\dot{\sigma}_{\rm nc} = \gamma f^2 c_{\rm tot}, \tag{285}$$

<span id="page-37-4"></span>in any homogeneous state or whenever the contribution of interfaces (between magnetized and disordered domains) is negligible compared to the bulk one. Note that (285) is the same dissipation as that of a gas of driven non-interacting particles, and is thus independent of the system phase.

For  $a^{\rm rot}=0$ , one obtains a thermodynamically consistent version (Agranov *et al.*, 2024) of the active Ising model (q=2) (Solon and Tailleur, 2013, 2015), generalized to  $q\geq 2$  in (Mangeat *et al.*, 2020; Solon *et al.*, 2022). Therein, the energy variation due to the jumps of the units in space – namely, the first term on the right hand side of (282) – was neglected. Alternatively, one can interpret the model in (Solon and Tailleur, 2013,

2015) as satisfying local detailed balance with a finetuned field-dependent nonconservative part  $\tilde{a}_{\rho}^{\text{tra}}(\{c_{i,x}\})$ that exactly counterbalances the energy variations, thus yielding a constant drift in space. Here, instead, we discuss a thermodynamic consistent model in which the translational nonconservative force on each spin is constant while the ensuing drift is affected also by the interactions with nearby spins. The original model (Solon and Tailleur, 2013, 2015) predicts the emergence of flocking at sufficiently large density and small temperature, i.e. a state with  $\langle m \rangle \neq 0$ , which can be retrieved by the thermodynamically consistent version by adding nearestneighbour interactions (Agranov et al., 2024; Proesmans et al., 2024). The model by (Solon and Tailleur, 2013, 2015) has been used in (Yu and Tu, 2022) to evaluate the entropy production (61), which was found to display a kink at the onset of flocking in disagreement with (285). In the light of the above discussion, such apparent entropy production is an artifact caused by neglecting the energy variations of translating spins.

Finally, for active particles with internal rotation,  $a^{\rm rot} \neq 0$ , the entropy production cannot be inferred only from the spacial dynamics, as often assumed in active field theories (Nardini *et al.*, 2017). Indeed, the first term on the right hand side of (284) requires explicit knowledge of the internal current between single-unit states and reduces to the quadratic form of linear irreversible thermodynamics (Markovich *et al.*, 2021b), in which  $\langle I_1 \rangle \propto a^{\rm rot}$ , only if  $a^{\rm rot} \to 0$ .

## <span id="page-38-0"></span>VIII. DISCUSSION

## <span id="page-38-1"></span>A. Critical summary

We started from a description of an open system using a stochastic dynamics in terms of mesoscopic configurations specified by the occupation number of mesoscopic states, and we reviewed the standard procedure to build the superstructure of stochastic thermodynamics on it. In doing so, we took for granted that transitions rates between states, and thermodynamic observables associated to the states, can be expressed in terms of occupation numbers only. This means that we assumed that for each mesoscopic state, the internal degrees of freedom are at equilibrium and an equilibrium Massieu potential  $\Phi(n)$  – and thus an internal entropy  $S_{int}(n)$  – can be assigned to them that is solely a function of the occupation number of the mesostate. As a result, the entropy production can be expressed in terms of the mesoscopic transitions and the probability distribution over the mesostates, see (8) and (9). We note that even when these conditions are satisfied, obtaining such transitions rates in practice may not always be straightforward (Prinz et al., 2011).

We then imposed the necessary constraints to obtain a deterministic macroscopic dynamics and an extensive

thermodynamics, namely, extensive transition rates and Massieu potentials, together with nonconservative forces  $a_{\rho}$  that are nonextensive. In the resulting entropy production, the contribution due to the system entropy stemming from the uncertainty of the mesoscopic state (i.e. the Shannon entropy) vanishes, see (57), and only the internal entropy (if there is one) survives. For example, for systems in which the mesoscopic state i is occupied by  $n_i$  noninteracting units (such as reacting chemicals), the internal entropy is just the Boltzmann entropy of the complexion number,  $S_{\rm int}(n) = \ln \frac{|n|!}{\prod_i n_i!}$ , whose scaled macroscopic limit reads  $s_{\text{int}}(c) = -\sum_{i=1}^{n} c_{i} \ln c_{i}$ , see Sec VII.C. Remarkably, this has the form of a Shannon entropy on the space of concentrations, but has nothing to do with the Shannon entropy in terms of the mesoscopic probabilities which, as we just mentioned, vanishes. Accordingly, it counts the uncertainty in the microscopic configurations within the mesoscopic states i, not the randomness in the distribution of the mesoscopic state. However, be aware that an extensive Shannon entropy (57) can appear if a system has a number of (near) degenerate minima of the quasi-potential (55) that scales exponentially with the size  $V \to \infty$ , similarly to glasses (Castellani and Cavagna, 2005).

It is worthwhile stressing that we only focused on thermal noise. We excluded systems whose dynamics remains noisy in the macroscopic limit, e.g., in the presence of a quenched disorder (De Giuli and Scalliet, 2022) or any kind of extrinsic noise (Bressloff, 2017). We also specialized the discussion of the macroscopic limit to dynamics characterized only by isolated, nondegenerate fixed points. However, the theory is expected to hold more generally mutatis mutandis in presence of sufficiently regular time-dependents attractors, such as limit cycles that we mentioned in passing. The practical difficulty in this case is to determine the large fluctuations and the quasi-potential.

We then considered a continuous-space limit that leads to a stochastic field theory. The conserved dynamics - called model B in the standard classification (Hohenberg and Halperin, 1977) – is the special case, extensively treated in (Bertini et al., 2015), that we retrieved when all transitions scale diffusively. In this respect, we reframe and contextualize many results of macroscopic fluctuation theory within ST. In general, we connected with fluctuating hydrodynamic theories (De Zarate and Sengers, 2006; de Groot and Mazur, 1984; Landau and Lifshitz, 1959) – in particular, nonlinear ones (Zubarev and Morozov, 1983) – although in our treatment the intensive thermodynamic quantities characterizing the equilibrium reservoirs are not dynamically coupled to the mesoscopic variable c – e.g. the temperature is unaffected by the dissipated heat. We thus achieved the goal of systematizing all well-established thermodynamics theories, from deterministic to statistical ones, within the overarching

![](_page_39_Figure_1.jpeg)

<span id="page-39-2"></span>FIG. 9 Schematic classification of the thermodynamic theories in terms of the system size and distance from equilibrium. The present paper extends stochastic thermodynamics to macroscopic systems, and recovers Irreversible Thermodynamics (deterministic) and Onsager-Machlup/Laundau-Lifshitz theories (Gaussian fluctuations) in the near-equilibrium regime. It also comprises Macroscopic Fluctuation Theory wherein forces are linearly related to fluxes but are nonlinear functions of macroscopic variables, which thus have nonGaussian fluctuations.

framework offered by ST (see Fig. 9).

It is worth noting that while we have a priori assumed the existence of a well defined large scale parameter that controls the thermodynamic limit, this setting may not be the only one that leads to macroscopic deterministic dynamics. The low temperature limit (with respect to a typical energy scale) is a much studied example, especially in the context of Langevin dynamics (Graham, 1987). Moreover, stochastic dynamics in continuous space converge to deterministic ones within an appropriate hydrodynamic description that averages the microscopic observables over suitably small volumes (Bertini et al., 2015) – without necessarily invoking that the number of particles per lattice site diverges, as we have effectively done in V.A.

Finally, in Section VI, we coarse-grained the long-time dynamics as a Markov jump process over the attractors and discussed the resulting thermodynamics. The attractors provide a notion of states which emerge from the underlying dynamics and are generically out-of-equilibrium, thus overcoming a central starting assumption of ST. This section, together with the bounds on the macroscopic transition rates of Sec. IV.H, creates a long-sought bridge between Freidlin-Wentzell theory of large deviations and thermodynamics (Freidlin and Wentzell, 1998; Graham and Tél, 1985). In this respect, we have worked at a formal level, in particular making use of generating functions conditioned on subsets of trajectories. While conditioning the entropy production on a single basin of attraction has recently received some attention (Fiore et al., 2021), conditioning on transition paths – and the underlying problem of calculating the statistics of transition times out of equilibrium – remains an issue to be explored thoroughly. These tools are needed if one wishes to explicitly compute the emerging observables from the underlying mesoscopic dynamics. However, such bottom-up derivation is expected to be possible only in relatively simple models. The main goal of the coarse-graining in Section VI is to identify the structure of the emerging thermodynamics in terms of nonequilibrium states, so as to guide the construction of effective models in complex systems, possibly informed by measurements of emerging observables.

In Sec. VII we have outlined three classes of models that comply with the general theory, namely, reaction networks of ideal chemicals, nonlinear electronic circuits and driven Potts models.

#### <span id="page-39-0"></span>B. Outlook

We focused on the macroscopic limit of the core structure of ST, thus providing the basis for a systematic analysis of many specific aspects connected to the nonequilibrium thermodynamic limit and for further extensions to other classes of systems.

#### <span id="page-39-1"></span>1. Thermodynamic uncertainty relations

In the simplest formulation, the thermodynamic uncertainty relation (TUR) asserts that the ratio between the squared mean and the variance of a current integrated over a time  $\tau$  is bounded from above by half the entropy produced in the time  $\tau$ , see e.g. (Barato and Seifert, 2015; Dechant and Sasa, 2020, 2021; Falasco *et al.*, 2020;

Gingrich et al., 2017; Hasegawa and Van Vu, 2019; Macieszczak et al., 2018; Timpanaro et al., 2019; Van Vu and Saito, 2023b; Van Vu et al., 2020). For extensive observables of IV.I introduced in (167), it is immediate to conclude that the TUR is valid in terms of the scaled moments, as both sides of the inequality scale as V (Koyuk and Seifert, 2022). Its explicit expression will dramatically depend on the observation timescale  $\tau$ , though. For systems initially prepared in an attractor  $\gamma$ , as a consequence of metastability, the TUR will involve only the entropy production of the attractor  $\gamma$ ,

$$\frac{\langle o \rangle^2}{\langle o^2 \rangle - \langle o^2 \rangle} \le \frac{\langle \dot{\sigma}_{\gamma} \rangle \tau}{2},\tag{286}$$

if the integration time  $\tau$  is much shorter than the minimum escape time  $1/\kappa_{\nu}$ . The TURs (286), if used for inference, provide multiple bounds to the dissipation of each attractor rather than a single bound on the entropy production of the full system. Combining (286) with the TUR evaluated at  $\tau \gg 1/\kappa_{\nu}$ , one can possibly bound the transition entropy production  $\sigma_{\nu}$ .

The macroscopic limit not only decomposes the TUR into multiple bounds for the different macroscopic attractors, as given by (286), but also generates tighter constraints on single degrees of freedom. Indeed, it has been shown in (Yoshimura and Ito, 2021) that the deterministic dynamics (45) is associated to the bound<sup>17</sup>

<span id="page-40-3"></span>
$$|d_t x_i| = |F_i| \le \sqrt{D_{ii}\dot{\sigma}_i},\tag{287}$$

where  $D_{ii}$  is the diagonal component on the diffusion matrix (81), and  $\dot{\sigma}_i := \sum_{\rho>0:\Delta_{\rho}^i\neq 0} [r_{\rho}(x(t)) - r_{-\rho}(x(t))]\sigma_{\rho}(x(t))$  is the scaled macroscopic entropy production associated to variations of the *i*th component of the configuration vector x. Notice that  $\dot{\sigma}_i \leq \langle \dot{\sigma} \rangle$  which means that (287) cannot be obtained by the microscopic TUR, the latter being a global bound in terms of the total dissipation. As a corollary, integration of (287) yields a local speed limit which replaces – with respect to its microscopic counterpart (Shiraishi *et al.*, 2018; Van Vu and Saito, 2023a; Vo *et al.*, 2020) – mesoscopic probabilities p(n,t) with macroscopic configurations x.

It remains to be explored how recent approaches based on the statistics of residence and return times behave in the macroscopic limit (Harunari *et al.*, 2022; Marsland III *et al.*, 2019; Van der Meer *et al.*, 2022; Skinner and Dunkel, 2021a,b).

#### <span id="page-40-0"></span>2. Phase transitions

Macroscopic ST provides a unifying language to describe nonequilibrium phase transitions, not only dynamically but also from an energetic point of view.

<span id="page-40-1"></span>On one hand, bifurcation theory can be employed to study the deterministic dynamics upon changing some external parameter (Strogatz, 2015), for instance the intensive thermodynamic variables of the reservoirs or the system's kinetic factors. Nonconservative forces give rise to a far richer scenario than that encountered in equilibrium phase transitions, where only fix points are present and their statistical weight can be changed. In the macroscopic limit, bistability can emerge as a consequence of a saddle-node (Fig. 10 (a) and (b)) or a pitchfork bifurcation (Fig. 10 (c) and (d)) in processes similar to equilibrium first or second order phase transitions, respectively. A critical point, corresponding to a locally flat quasi-potential (see Fig. 10 (c)), is accompanied by diverging fluctuations so that the Langevin approach of Sec. IV.C breaks down (Van Kampen, 2007). A higher order expansion of the master equation captures the critical slowing down of the mean dynamics and the different scaling in V of the fluctuations (Dekker, 1980; Remlein and Seifert, 2024). This phenomenology is akin to phase transitions in systems with detailed balance dynamics, with the quasi-potential  $I_{ss}$  playing the role of the Massieu potential  $\phi$ . A transition that has no counterpart at equilibrium is the emergence of a limit cycle, e.g., through a Hopf bifurcation (see Fig. 10 (e) and (f)). In this case, the minimum of the quasi-potential lies on a flat manifold, on which a finite dissipative drift  $v_{ss}(x^*(t))$ is present and determines the probability distribution along the cycle as  $p(x^*(t)) \propto |v_{\rm ss}(x^*(t))|^{-1}$  (Vance and On the other, large deviations theory is Ross, 1996). instrumental in identifying dynamical phase transitions. These are singularities in the rate function of dynamical observables appearing either at long times (Espigares et al., 2013; Garrahan et al., 2007, 2009; Gingrich et al., 2014; Hurtado and Garrido, 2011; Nyawo and Touchette, 2017) (see Sec. (IV.I.2)) or developing at some critical finite time (Blom, 2023; Meibohm and Esposito, 2022, 2023) (see Sec. VII.C).

A significant research line concerns the possibility of characterizing the phase transitions and the phase coexistence that appear in the thermodynamic limit by means of the nonequilibrium thermodynamic quantities of the system. The entropy production rate and the Massieu potential (or their derivatives) can display singularities at the critical points, in ways that seem to depend on the specificity of the model under scrutiny (Falasco et al., 2018; Fiore et al., 2021; Martynec et al., 2020; Nguyen and Seifert, 2020; Noa et al., 2019; Rana and Barato, 2020). Nonequilibrium intensive quantities, such as chemical potential (Guioth and Bertin, 2018, 2019a,b), pressure (Joyeux and Bertin, 2016; Solon et al., 2015;

<span id="page-40-2"></span><sup>17</sup> This result was obtained for deterministic chemical reaction networks but clearly holds for all systems described in this review that admit (45) as macroscopic dynamics.

![](_page_41_Figure_1.jpeg)

<span id="page-41-1"></span>FIG. 10 Pictorial representation of the qualitative changes in the quasi-potential  $I_{\rm ss}$  at phase transitions, obtained from variations of an external parameter. The corresponding bifurcations in the macroscopic dynamics (45) are saddle-node bifurcation (from (a) to (b)), pitchfork bifurcation (from (c) to (d)) and Hopf bifurcation (from (e) to (f)) in which a finite circulation is present. While the first two are analogous to first and second order phase transitions at equilibrium, respectively, the last one has a genuine dissipative character.

Takatori et al., 2014) and surface tension (Bialké et al., 2015; Zakine et al., 2020), have been studied to understand whether they can predict the chemical and mechanical stability, especially of active systems. For pressure in particular, a generalized equation of state for generic diffusive systems was derived in (Falasco et al., 2016) that displays the dissipated heat alongside the standard virial terms. For some notable models, such as active Brownian particles (Solon et al., 2015), such formula yields a pressure that is only a function of bulk variables – independent of the details of confinement, as in equilibrium. We believe that the macroscopic ST outlined here can help unifying these somewhat detached research efforts.

### <span id="page-41-0"></span>3. Finite size effects

Within the framework described above, interesting effects often appear at large yet finite system size. Going beyond the asymptotic regime considered here, requires to retain subleading corrections in the thermodynamic and kinetic variables, Eqs. (29) and (28). The resulting modification of the large deviations form for probability distributions can be found by means of WKB expansions (Assaf and Meerson, 2017; Caroli *et al.*, 1979, 1980; Proesmans and Derrida, 2019). For instance, (31) is replaced by

$$p(c,t) = (A_1(c,t) + O(V^{-1})) e^{-VI(c,t)}$$
(288)

with  $A_1$  satisfying a transport equation obtained by expanding the master equation (3). In particular, the longtime limit of  $A_1$  would allow one to compute subleading corrections to the transition rates (157), i.e. the nonequilibrium generalization of the Kramers formula (Hänggi et al., 1990). To the best of our knowledge this has been done only for systems with Gaussian noise (Maier and Stein, 1993, 1997) where  $A_1$  can be linked to the instanton dynamics (Bouchet and Reygner, 2016), and presents an additional contribution due to the phase space contraction rate for systems lacking detailed balance. Moreover, subextensive terms should appear in the deterministic dynamics (45). Such corrections to the drift field are often computed by adding a small fluctuation of order  $O(V^{-1/2})$  to the deterministic solution x and averaging it. This procedure leads to the deterministic evolution

$$\dot{x} = F(x) + \frac{1}{2V} \text{Cov} : \partial_c \partial_c F(x),$$
 (289)

with the covariance  $\text{Cov} := \langle (c-x)(c-x) \rangle$  computed (at the leading order) by means of (126). Such modified drift may better predict the phase diagram of finite systems – e.g. changing the order of phase transitions in extended systems as the active Ising model of Sec. VII.C (Solon and Tailleur, 2015) – but it is not guaranteed to respect the thermodynamic structure of the theory. Even more subtly, at large but finite V the very definition of metastable states cannot be reduced to the sole notion of deterministic attractors, which should be identified by the spectral analysis of the Markov generator (Gaveau and Schulman, 1998a; Kurchan, 2009).

Finally, subextensive contributions play a key role in the information flows within a system (Parrondo et al., 2015). For systems with a (at least) bipartite structure – i.e. with two sets of transitions, each affecting only one set of states, as in section V.A – it is possible to quantify the entropy exchanges via the rate of variation of mutual information between the two sets of states (Hartich et al., 2014; Horowitz and Esposito, 2014). This framework allows one to describe inter alia the thermodynamics of autonomous Maxwell demons, in which a

part of the system creates correlations used by the rest, e.g., to drive a current (Freitas and Esposito, 2021). This mechanism, being based on the rectification of thermal fluctuations, breaks down in the macroscopic limit we considered. Nevertheless, it can be rescued by making the nonconservative force  $a_{\rho}$  extensive in V, although at the expense of a vanishing efficiency (Freitas and Esposito, 2022b, 2023).

#### <span id="page-42-0"></span>4. Odd-parity variables and quantum systems

Importantly, we focused on systems described only by state variables that are even under time reversal. Repeating the approach of this work with odd-parity variables. such as momenta, would lead to, e.g. underdamped fluctuating hydrodynamics (Manacorda and Puglisi, 2017; Nakamura and Yoshimori, 2009). The noiseless limit of such theory has been considered in (Forastiere et al., 2022a) with the conventional approach of closing moments hierarchy based on the Boltzmann equation – while the asymptotic fluctuations should be derivable by using large deviations theory (Bouchet, 2020). The theory can be extended to long-range interacting systems, such as those composed by self-gravitating particles (Chavanis, 2006, 2019), whose energy can be made extensive, albeit not additive, under the Kac's prescription. Generalizing the theory to open quantum systems is also a research program to explore.

## <span id="page-42-1"></span>5. Response theory

We did not discuss response theory around nonequilibrium states (Baiesi and Maes, 2013). The linear theory allows to calculate, e.g., thermodynamic susceptibilities (Baiesi et al., 2014; Boksenbojm et al., 2011; Falasco and Baiesi, 2016a,b) and transport coefficients (Baiesi et al., 2011; Chun et al., 2021; Falasco et al., 2020; Seifert and Speck, 2010; Speck and Seifert, 2006). Arguably, the most general setup to highlight the connection with thermodynamics is the one based on path probabilities, which shows how purely kinetic factors – the excess dynamical activity – pair with the entropy production to produce the system's response (Baiesi et al., 2009). How the macroscopic limit affects the scaling of these two contributions remains to be seen. Thermodynamics bounds on susceptibilities have also recently appeared (Aslyamov and Esposito, 2023; Owen et al., 2020). Nonlinear response, originally developed for thermostatted dynamical systems (Evans and Morriss, 1990; Marini Bettolo Marconi et al., 2008; Ruelle, 2009), has received comparatively less attention in the context of ST (Andrieux and Gaspard, 2007; Dechant and Sasa, 2020; Falasco et al., 2022) despite its experimental importance in dissipative mesoscopic systems, such as in active microrheology (Müller et al., 2020), mechanical resonators (Conti et al., 2013; Geitner et al., 2017) and optical microscopy (Radunz et al., 2009).

### <span id="page-42-2"></span>6. Phenomenological laws

Sections IV.H and VI present new results, emerging as natural consequences of the macroscopic limit of ST. We speculate that they may provide links to some phenomenological laws that have been previously postulated.

On one hand, the maximum entropy production principle of Sec. IV.H is fundamentally different from the usual statement which goes under the same name – an empirical law with mixed success. The latter can be rephrased in the language of this review, by the postulate that the attractor with the largest dissipation  $\langle \dot{\sigma}_{\gamma} \rangle$  is the one with the smaller escape rate, i.e. the longest life time (Martyushev and Seleznev, 2006; Nicolis and Nicolis, 2010). The two statements can agree only under some peculiar conditions, for instance if most of the nonconservative entropy production is localized on a small neighborhood of the stable fixed points. In this case, we should have for the relaxation

$$\sigma_{\nu \to \gamma}^{\rm nc} = \int dt \sum_{\rho} a_{\rho} r_{\rho}(x(t)) \simeq \langle \dot{\sigma}_{\gamma} \rangle \tau_{\gamma}^{\rm rel},$$
 (290)

where  $\tau_{\gamma}^{\rm rel}$  is the longest relaxation time of the linear dynamics (87), i.e. the inverse absolute value of the smallest eigenvalue of  $\partial_c F(x_{\gamma}^*)$ . Similarly, we should have for the instanton

$$\sigma_{\gamma \to \nu}^{\rm nc} = \int dt \sum_{\rho} a_{\rho} r_{\rho}(c(t)) e^{\Delta_{\rho} \cdot \partial_{c} I_{\rm ss}(c(t))} \simeq -\langle \dot{\sigma}_{\gamma} \rangle \tau_{\gamma}^{\rm inst},$$
(291)

where  $\tau_{\gamma}^{\rm inst}$  is the largest timescale of the linearized instanton dynamics

$$d_t c = (c - x_{\gamma}^*) \cdot [\partial_c F(x_{\gamma}^*) + 2D(x_{\gamma}^*) \partial_c^2 I_{ss}(x_{\gamma}^*)], \quad (292)$$

i.e. the inverse absolute value of the smallest eigenvalue of  $\partial_c F^{\dagger}(x_{\gamma}^*)$ . In order for (160) to be tight, one needs  $\tau_{\gamma}^{\rm rel} \simeq \tau_{\gamma}^{\rm inst}$ , which is in general true only if  $\langle \dot{\sigma}_{\gamma} \rangle \to 0$  (see (153)), i.e. close to detailed balance dynamics. This does not exclude that in some specific systems the condition  $\tau_{\gamma}^{\rm rel} \simeq \tau_{\gamma}^{\rm inst}$  can be met even far from detailed balance, but suggests that some fine tuning or peculiar symmetries are present. Nevertheless, it is important to remark that in dissipative stochastic systems a local criterion of stability, e.g. the life-time of an attractor, does not determine the global stability, e.g. the stationary probability of the latter. While detailed balance states that are surrounded by the highest energy barrier (and have hence the largest life-time) are also the most populated in the long time, dissipative states with small escape rate may

have small probability [\(Maes and Netočn`y,](#page-46-47) [2013\)](#page-46-47).

On the other hand, the emergent second law [\(224\)](#page-28-2), when only baths at the same temperature are present, is an energy balance that counts the energy of maintenance of γ and the energy of changing γ. Imagine a system with a very large number M → ∞ of metastable states coordinatized by the continuous variable m := γ/M. In the particular case κ−<sup>ν</sup> ≪ κ<sup>ν</sup> for all ν > 0, the random walk along m is almost surely increasing. Equation [\(224\)](#page-28-2) takes the general form postulated for the energetics of the resting metabolism of organisms [\(Lynch and](#page-46-68) [Marinov,](#page-46-68) [2015\)](#page-46-68), e.g. with m being the (normalized) mass of an individual and ⟨σ˙ <sup>γ</sup>⟩, the resting metabolic expenditure. This analogy highlights the possibility that the emergent thermodynamics of Sec. [VI](#page-27-0) can bridge over to phenomenological energy balances [\(Yang](#page-48-6) et al., [2021\)](#page-48-6), helping to clarify the mesoscopic origin of empirically determined laws such as the allometric scaling of ⟨σ˙ <sup>γ</sup>⟩ [\(Ilker](#page-45-65) [and Hinczewski,](#page-45-65) [2019\)](#page-45-65).

Acknowledgments—The authors thank D. Forastiere, N. Freitas and J. Meibohm for stimulating discussions. GF is funded by the European Union - NextGenerationEU - and by the program STARS@UNIPD with the project "ThermoComplex". ME is supported by project ChemComplex (No. C21/MS/16356329) funded by Fonds National de la Recherche Luxembourg (FNR), and by Project No. INTER/FNRS/20/15074473 funded by FNR and Fonds de la Recherche Scientifique Belgium.

## <span id="page-43-0"></span>REFERENCES

- <span id="page-43-35"></span>Agranov, T., R. L. Jack, M. E. Cates, and É. Fodor (2024), arXiv preprint arXiv:2401.09901.
- <span id="page-43-33"></span>Anderson, D. F., and T. G. Kurtz (2011), Continuous Time Markov Chain Models for Chemical Reaction Networks., edited by Springer (New York).
- <span id="page-43-46"></span>Andrieux, D., and P. Gaspard (2007), [Journal of Statistical](http://dx.doi.org/ 10.1088/1742-5468/2007/02/P02006) [Mechanics: Theory and Experiment](http://dx.doi.org/ 10.1088/1742-5468/2007/02/P02006) 2007 (02), P02006.
- <span id="page-43-34"></span>Andrieux, D., and P. Gaspard (2008), [J. Chem. Phys.](http://dx.doi.org/ 10.1063/1.2894475) 128 [\(15\), 154506,](http://dx.doi.org/ 10.1063/1.2894475) [https://doi.org/10.1063/1.2894475.](http://arxiv.org/abs/https://doi.org/10.1063/1.2894475)
- <span id="page-43-27"></span>Arrhenius, S. (1889), Zeitschrift für physikalische Chemie 4 (1), 226.
- <span id="page-43-29"></span>Aslyamov, T., F. Avanzini, E. Fodor, and M. Esposito (2023), [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.131.138301) 131, 138301.
- <span id="page-43-45"></span>Aslyamov, T., and M. Esposito (2023), arXiv preprint arXiv:2308.04260.
- <span id="page-43-25"></span><span id="page-43-12"></span>Assaf, M., and B. Meerson (2017), J. Phys. A 50 [\(26\), 263001.](http://dx.doi.org/ 10.1088/1751-8121/aa669a) Auffèves, A. (2022), [PRX Quantum](http://dx.doi.org/ 10.1103/PRXQuantum.3.020101) 3, 020101.
- <span id="page-43-30"></span>Avanzini, F., G. Falasco, and M. Esposito (2019), [J. Chem.](http://dx.doi.org/10.1063/1.5126528) Phys. 151 [\(23\), 234103.](http://dx.doi.org/10.1063/1.5126528)
- <span id="page-43-9"></span>Avanzini, F., E. Penocchio, G. Falasco, and M. Esposito (2021), [J. Chem. Phys.](http://dx.doi.org/10.1063/5.0041225) 154 (9), 094114.
- <span id="page-43-18"></span>Baek, Y., and Y. Kafri (2015), [J. Stat. Mech.: Theory Exp.](http://dx.doi.org/10.1088/1742-5468/2015/08/P08026) 2015 [\(8\), P08026.](http://dx.doi.org/10.1088/1742-5468/2015/08/P08026)
- <span id="page-43-41"></span>Baiesi, M., U. Basu, and C. Maes (2014), [Eur. Phys. J. B](http://dx.doi.org/10.1140/epjb/e2014-50622-2) 87 [\(11\), 277.](http://dx.doi.org/10.1140/epjb/e2014-50622-2)
- <span id="page-43-16"></span>Baiesi, M., and G. Falasco (2015), Phys. Rev. E 92 (4), 042162.

- <span id="page-43-40"></span>Baiesi, M., and C. Maes (2013), [New Journal of Physics](http://dx.doi.org/10.1088/1367-2630/15/1/013004) 15 [\(1\), 013004.](http://dx.doi.org/10.1088/1367-2630/15/1/013004)
- <span id="page-43-44"></span>Baiesi, M., C. Maes, and B. Wynants (2009), [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.103.010602) 103[, 010602.](http://dx.doi.org/10.1103/PhysRevLett.103.010602)
- <span id="page-43-43"></span>Baiesi, M., C. Maes, and B. Wynants (2011), Proc. Royal Soc. A 467, 2792.
- <span id="page-43-8"></span>Barato, A. C., and U. Seifert (2015), [Phys. Rev. Lett.](http://dx.doi.org/ 10.1103/PhysRevLett.114.158101) 114, [158101.](http://dx.doi.org/ 10.1103/PhysRevLett.114.158101)
- <span id="page-43-23"></span>Battle, C., C. P. Broedersz, N. Fakhri, V. F. Geyer, J. Howard, C. F. Schmidt, and F. C. MacKintosh (2016), Science 352 (6285), 604.
- <span id="page-43-2"></span>Bauer, M., and F. Cornu (2014), [J. Phys. A: Math. Theor.](http://dx.doi.org/10.1088/1751-8113/48/1/015008) 48 [\(1\), 015008.](http://dx.doi.org/10.1088/1751-8113/48/1/015008)
- <span id="page-43-15"></span>Bebon, R., J. F. Robinson, and T. Speck (2024), arXiv preprint arXiv:2401.02252.
- <span id="page-43-11"></span>Bechinger, C., R. Di Leonardo, H. Löwen, C. Reichhardt, G. Volpe, and G. Volpe (2016), [Rev. Mod. Phys.](http://dx.doi.org/10.1103/RevModPhys.88.045006) 88 (4), [045006.](http://dx.doi.org/10.1103/RevModPhys.88.045006)
- <span id="page-43-7"></span>Bérut, A., A. Arakelyan, A. Petrosyan, S. Ciliberto, R. Dillenschneider, and E. Lutz (2012), Nature 483 [\(7388\), 187.](http://dx.doi.org/10.1038/nature10872)
- <span id="page-43-4"></span>Benenti, G., G. Casati, K. Saito, and R. S. Whitney (2017), [Phys. Rep.](http://dx.doi.org/10.1016/j.physrep.2017.05.008) 694, 1.
- <span id="page-43-17"></span>Benettin, G., L. Galgani, A. Giorgilli, and J.-M. Strelcyn (1980), Meccanica 15, 9.
- <span id="page-43-3"></span>Bergmann, P. G., and J. L. Lebowitz (1955), [Phys. Rev.](http://dx.doi.org/ 10.1103/PhysRev.99.578) 99, [578.](http://dx.doi.org/ 10.1103/PhysRev.99.578)
- <span id="page-43-21"></span>Bertini, L., A. De Sole, D. Gabrielli, G. Jona-Lasinio, and C. Landim (2010), [J. Stat. Mech.: Theory Exp.](http://dx.doi.org/10.1088/1742-5468/2010/11/L11001) 2010 (11), [L11001.](http://dx.doi.org/10.1088/1742-5468/2010/11/L11001)
- <span id="page-43-10"></span>Bertini, L., A. De Sole, D. Gabrielli, G. Jona-Lasinio, and C. Landim (2015), [Rev. Mod. Phys.](http://dx.doi.org/10.1103/RevModPhys.87.593) 87 (2), 593.
- <span id="page-43-32"></span>Bertini, L., D. Gabrielli, G. Jona-Lasinio, and C. Landim (2013), [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.110.020601) 110, 020601.
- <span id="page-43-38"></span>Bialké, J., J. T. Siebert, H. Löwen, and T. Speck (2015), [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.115.098301) 115 (9), 098301.
- <span id="page-43-5"></span>Blickle, V., T. Speck, L. Helden, U. Seifert, and C. Bechinger (2006), [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.96.070603) 96, 070603.
- <span id="page-43-37"></span>Blom, K. (2023), in Pair-Correlation Effects in Many-Body Systems: Towards a Complete Theoretical Description of Pair-Correlations in the Static and Kinetic Description of Many-Body Systems (Springer) pp. 131–162.
- <span id="page-43-14"></span><span id="page-43-13"></span>Bo, S., and A. Celani (2014), [J. Stat. Phys.](http://dx.doi.org/10.1007/s10955-014-0922-1) 154 (5), 1325. Bo, S., and A. Celani (2017), [Phys. Rep.](http://dx.doi.org/10.1016/j.physrep.2016.12.003) 670, 1 .
- <span id="page-43-42"></span>Boksenbojm, E., C. Maes, K. Netočný, and J. Pešek (2011),
- [Europhys. Lett.](http://dx.doi.org/10.1209/0295-5075/96/40001) 96 (4), 40001.
- <span id="page-43-22"></span>Boland, R. P., T. Galla, and A. J. McKane (2008), [J. Stat.](http://dx.doi.org/10.1088/1742-5468/2008/09/P09001) [Mech.: Theory Exp.](http://dx.doi.org/10.1088/1742-5468/2008/09/P09001) 2008 (09), P09001.
- <span id="page-43-39"></span>Bouchet, F. (2020), [J. Stat. Phys.](http://dx.doi.org/10.1007/s10955-020-02588-y) 181 (2), 515.
- <span id="page-43-19"></span>Bouchet, F., K. Gawredzki, and C. Nardini (2016), [J. Stat.](http://dx.doi.org/10.1007/s10955-016-1503-2) Phys 163 [\(5\), 1157.](http://dx.doi.org/10.1007/s10955-016-1503-2)
- <span id="page-43-20"></span>Bouchet, F., and J. Reygner (2016), [Ann. Henri Poincaré](http://dx.doi.org/10.1007/s00023-016-0507-4) 17 [\(12\), 3499.](http://dx.doi.org/10.1007/s00023-016-0507-4)
- <span id="page-43-24"></span>Bovier, A., M. Eckhoff, V. Gayrard, and M. Klein (2002), [Commun. Math. Phys.](http://dx.doi.org/10.1007/s002200200609) 228 (2), 219.
- <span id="page-43-36"></span>Bressloff, P. C. (2017), [J. Phys. A: Math. Theor.](http://dx.doi.org/ 10.1088/1751-8121/aa5db4) 50 (13), [133001.](http://dx.doi.org/ 10.1088/1751-8121/aa5db4)
- <span id="page-43-26"></span>Bressloff, P. C., and J. M. Newby (2014), [Phys. Rev. E](http://dx.doi.org/ 10.1103/PhysRevE.89.042701) 89 (4), [042701.](http://dx.doi.org/ 10.1103/PhysRevE.89.042701)
- <span id="page-43-31"></span>Brillouin, L. (1950), [Phys. Rev.](http://dx.doi.org/ 10.1103/PhysRev.78.627.2) 78 (5), 627.
- <span id="page-43-1"></span>Van den Broeck, C., and M. Esposito (2015), [Physica A](http://dx.doi.org/ 10.1016/j.physa.2014.04.035) 418, [6.](http://dx.doi.org/ 10.1016/j.physa.2014.04.035)
- <span id="page-43-6"></span>Brown, A. I., and D. A. Sivak (2020), [Chem. Rev.](http://dx.doi.org/ 10.1021/acs.chemrev.9b00254) 120 (1), [434.](http://dx.doi.org/ 10.1021/acs.chemrev.9b00254)
- <span id="page-43-28"></span>Buffoni, L., and M. Campisi (2022), [J. Stat. Phys.](http://dx.doi.org/10.1007/s10955-022-02877-8) 186 (2),

- [31.](http://dx.doi.org/10.1007/s10955-022-02877-8)
- <span id="page-44-13"></span>Callen, H. B. (1991), Thermodynamics and an Introduction to Thermostatistics (John Wiley & Sons).
- <span id="page-44-47"></span>Cao, Z., H. Jiang, and Z. Hou (2020), [Phys. Rev. Research](http://dx.doi.org/10.1103/PhysRevResearch.2.043331) 2[, 043331.](http://dx.doi.org/10.1103/PhysRevResearch.2.043331)
- <span id="page-44-41"></span>Caroli, B., C. Caroli, and B. Roulet (1979), [J. Stat. Phys.](http://dx.doi.org/10.1007/BF01009609) 21 [\(4\), 415.](http://dx.doi.org/10.1007/BF01009609)
- <span id="page-44-42"></span>Caroli, B., C. Caroli, and B. Roulet (1981), [J. Stat. Phys.](http://dx.doi.org/10.1007/BF01106788) 26 [\(1\), 83.](http://dx.doi.org/10.1007/BF01106788)
- <span id="page-44-43"></span>Caroli, B., C. Caroli, B. Roulet, and J. F. Gouyet (1980), [J.](http://dx.doi.org/10.1007/BF01011336) [Stat. Phys.](http://dx.doi.org/10.1007/BF01011336) 22 (5), 515.
- <span id="page-44-49"></span>Castellani, T., and A. Cavagna (2005), Journal of Statistical Mechanics: Theory and Experiment 2005 (05), P05012.
- <span id="page-44-44"></span>Çetiner, U. b. u., and J. Gunawardena (2022), [Phys. Rev. E](http://dx.doi.org/10.1103/PhysRevE.106.064128) 106[, 064128.](http://dx.doi.org/10.1103/PhysRevE.106.064128)
- <span id="page-44-40"></span>Ceccato, A., and D. Frezzato (2018), [J. Chem. Phys.](http://dx.doi.org/10.1063/1.5016158) 148 (6), [064114.](http://dx.doi.org/10.1063/1.5016158)
- <span id="page-44-60"></span>Chavanis, P.-H. (2006), Physica A: Statistical Mechanics and its Applications 361 (1), 81.
- <span id="page-44-61"></span>Chavanis, P.-H. (2019), Entropy 21 (10), 1006.
- <span id="page-44-32"></span>Chernyak, V. Y., M. Chertkov, and C. Jarzynski (2006), [J.](http://dx.doi.org/ 10.1088/1742-5468/2006/08/P08001) [Stat. Mech.: Theory Exp.](http://dx.doi.org/ 10.1088/1742-5468/2006/08/P08001) 2006 (08), P08001.
- <span id="page-44-36"></span>Chetrite, R., and K. Gawedzki (2008), Comm. Math. Phys. 282, 469.
- <span id="page-44-64"></span>Chun, H.-M., Q. Gao, and J. M. Horowitz (2021), [Phys. Rev.](http://dx.doi.org/10.1103/PhysRevResearch.3.043172) Res. 3[, 043172.](http://dx.doi.org/10.1103/PhysRevResearch.3.043172)
- <span id="page-44-2"></span>Ciliberto, S. (2017), [Phys. Rev. X](http://dx.doi.org/ 10.1103/PhysRevX.7.021051) 7 (2), 021051.
- <span id="page-44-22"></span>Cohen, E., and L. Rondoni (1998), Chaos 8 (2), 357.
- <span id="page-44-29"></span>Colangeli, M., C. Maes, and B. Wynants (2011), [Journal of](http://dx.doi.org/ 10.1088/1751-8113/44/9/095001) [Physics A: Mathematical and Theoretical](http://dx.doi.org/ 10.1088/1751-8113/44/9/095001) 44 (9), 095001.
- <span id="page-44-27"></span>Coleman, S. (1988), Aspects of symmetry: selected Erice lectures (Cambridge University Press).
- <span id="page-44-66"></span>Conti, L., P. De Gregorio, G. Karapetyan, C. Lazzaro, M. Pegoraro, M. Bonaldi, and L. Rondoni (2013), J. Stat. Mech. , P12003.
- <span id="page-44-48"></span>Daems, D., and G. Nicolis (1999), [Phys. Rev. E](http://dx.doi.org/ 10.1103/PhysRevE.59.4000) 59, 4000.
- <span id="page-44-45"></span>Dal Cengio, S., V. Lecomte, and M. Polettini (2023), Phys. Rev. X 13 (2), 021040.
- <span id="page-44-34"></span>Day, M. V. (1983), Stochastics 8 (4), 297.
- <span id="page-44-33"></span>Day, M. V. (1990), Journal of mathematical analysis and applications 147 (1), 134.
- <span id="page-44-50"></span><span id="page-44-24"></span>De Dominicis, C., and L. Peliti (1978), [Phys. Rev. B](http://dx.doi.org/ 10.1103/PhysRevB.18.353) 18, 353. De Giuli, E., and C. Scalliet (2022), J. Phys. A 55 (47), 474002.
- <span id="page-44-10"></span>De Zarate, J. M. O., and J. V. Sengers (2006), Hydrodynamic fluctuations in fluids and fluid mixtures (Elsevier).
- <span id="page-44-38"></span>Dean, D. S. (1996), J. Phys. A 29 (24), L613.
- <span id="page-44-52"></span>Dechant, A., and S.-i. Sasa (2020), [Proc. Natl. Acad. Sci.](http://dx.doi.org/10.1073/pnas.1918386117) U.S.A. 117 [\(12\), 6430.](http://dx.doi.org/10.1073/pnas.1918386117)
- <span id="page-44-53"></span>Dechant, A., and S.-i. Sasa (2021), Physical Review X 11 (4), 041061.
- <span id="page-44-54"></span>Dekker, H. (1980), Physica A: Statistical Mechanics and its Applications 103 (1-2), 80.
- <span id="page-44-31"></span>Dinelli, A., J. O'Byrne, A. Curatolo, Y. Zhao, P. Sollich, and J. Tailleur (2023), Nature Communications 14 (1), 7035.
- <span id="page-44-25"></span>Doi, M. (1976), [Journal of Physics A: Mathematical and Gen](http://dx.doi.org/10.1088/0305-4470/9/9/008)eral 9 [\(9\), 1465.](http://dx.doi.org/10.1088/0305-4470/9/9/008)
- <span id="page-44-17"></span>Dorfman, J. R. (1999), in Cambridge Lecture Notes in Physics, Vol. 14 (Cambridge).
- <span id="page-44-30"></span>Dykman, M., X. Chu, and J. Ross (1993), [Phys. Rev. E](http://dx.doi.org/10.1103/PhysRevE.48.1646) 48, [1646.](http://dx.doi.org/10.1103/PhysRevE.48.1646)
- <span id="page-44-26"></span>Dykman, M. I., E. Mori, J. Ross, and P. M. Hunt (1994), [J.](http://dx.doi.org/10.1063/1.467139) [Chem. Phys.](http://dx.doi.org/10.1063/1.467139) 100 (8), 5735.
- <span id="page-44-16"></span>Einstein, A. (1910), [Ann. Phys.](http://dx.doi.org/ https://doi.org/10.1002/andp.19103381612) 338 (16), 1275,

- [https://onlinelibrary.wiley.com/doi/pdf/10.1002/andp.19103381612.](http://arxiv.org/abs/https://onlinelibrary.wiley.com/doi/pdf/10.1002/andp.19103381612)
- <span id="page-44-39"></span>Elgart, V., and A. Kamenev (2004), [Phys. Rev. E](http://dx.doi.org/10.1103/PhysRevE.70.041106) 70, 041106.
- <span id="page-44-46"></span>Epstein, I. R., and J. A. Pojman (1998), An Introduction to Nonlinear Chemical Dynamics: Oscillations, Waves, Patterns, and Chaos (Oxford University Press, USA).
- <span id="page-44-37"></span>Espigares, C. P., P. L. Garrido, and P. I. Hurtado (2013), Phys. Rev. E 87 (3), 032115.
- <span id="page-44-0"></span>Esposito, M. (2012), [Phys. Rev. E](http://dx.doi.org/ 10.1103/PhysRevE.85.041125) 85 (4), 041125.
- <span id="page-44-14"></span>Esposito, M., and C. Van den Broeck (2010), [Phys. Rev. E](http://dx.doi.org/10.1103/PhysRevE.82.011143) 82 [\(1\), 011143.](http://dx.doi.org/10.1103/PhysRevE.82.011143)
- <span id="page-44-15"></span>Esposito, M., U. Harbola, and S. Mukamel (2007), [Phys. Rev.](http://dx.doi.org/ 10.1103/PhysRevE.76.031132) E 76 [\(3\), 031132.](http://dx.doi.org/ 10.1103/PhysRevE.76.031132)
- <span id="page-44-11"></span>Esposito, M., and J. M. R. Parrondo (2015), [Phys. Rev. E](http://dx.doi.org/ 10.1103/PhysRevE.91.052114) 91 [\(5\), 052114.](http://dx.doi.org/ 10.1103/PhysRevE.91.052114)
- <span id="page-44-19"></span>Evans, D. J., E. G. D. Cohen, and G. P. Morriss (1993), Phys. Rev. Lett. 71 (15), 2401.
- <span id="page-44-18"></span>Evans, D. J., and G. P. Morriss (1990), Statistical Mechanics of Non Equilibrium Liquids, Theoretical Chemistry Monograph Series (Academic Press, London).
- <span id="page-44-20"></span>Evans, D. J., and D. J. Searles (1994), Phys. Rev. E 50 (2), 1645.
- <span id="page-44-21"></span>Evans, D. J., and D. J. Searles (2002), Advances in Physics 51 (7), 1529.
- <span id="page-44-35"></span>Eyring, H. (1935), The Journal of Chemical Physics 3 (2), 107.
- <span id="page-44-62"></span>Falasco, G., and M. Baiesi (2016a), [New J. Phys.](http://dx.doi.org/ 10.1088/1367-2630/18/4/043039) 18 (4), [043039.](http://dx.doi.org/ 10.1088/1367-2630/18/4/043039)
- <span id="page-44-63"></span>Falasco, G., and M. Baiesi (2016b), [Europhys. Lett.](http://dx.doi.org/ 10.1209/0295-5075/113/20005) 113 (2), [20005.](http://dx.doi.org/ 10.1209/0295-5075/113/20005)
- <span id="page-44-55"></span>Falasco, G., F. Baldovin, K. Kroy, and M. Baiesi (2016), New J. Phys. 18 (9), 093043.
- <span id="page-44-5"></span>Falasco, G., T. Cossetto, E. Penocchio, and M. Esposito (2019), [New J. Phys.](http://dx.doi.org/10.1088/1367-2630/ab28be) 21 (7), 073005.
- <span id="page-44-4"></span>Falasco, G., and M. Esposito (2020), [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.125.120604) 125, [120604.](http://dx.doi.org/10.1103/PhysRevLett.125.120604)
- <span id="page-44-1"></span>Falasco, G., and M. Esposito (2021), [Phys. Rev. E](http://dx.doi.org/10.1103/PhysRevE.103.042114) 103, [042114.](http://dx.doi.org/10.1103/PhysRevE.103.042114)
- <span id="page-44-3"></span>Falasco, G., M. Esposito, and J.-C. Delvenne (2020), [New J.](http://dx.doi.org/10.1088/1367-2630/ab8679) Phys. 22 [\(5\), 053046.](http://dx.doi.org/10.1088/1367-2630/ab8679)
- <span id="page-44-65"></span>Falasco, G., M. Esposito, and J.-C. Delvenne (2022), J. Phys. A 55 (12), 124002.
- <span id="page-44-6"></span>Falasco, G., R. Rao, and M. Esposito (2018), [Phys. Rev.](http://dx.doi.org/10.1103/PhysRevLett.121.108301) Lett. 121 [\(6\), 108301.](http://dx.doi.org/10.1103/PhysRevLett.121.108301)
- <span id="page-44-51"></span>Fiore, C. E., P. E. Harunari, C. E. F. Noa, and G. T. Landi (2021), [Phys. Rev. E](http://dx.doi.org/10.1103/PhysRevE.104.064123) 104, 064123.
- <span id="page-44-9"></span>Fodor, E., C. Nardini, M. E. Cates, J. Tailleur, P. Visco, and F. van Wijland (2016), [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.117.038103) 117, 038103.
- <span id="page-44-59"></span>Forastiere, D., F. Avanzini, and M. Esposito (2022a), arxiv:2306.00911.
- <span id="page-44-23"></span>Forastiere, D., R. Rao, and M. Esposito (2022b), New Journal of Physics 24 (8), 083021.
- <span id="page-44-12"></span>Freidlin, M. I., and A. D. Wentzell (1998), Random perturbations of dynamical systems, 2nd ed. (Springer).
- <span id="page-44-28"></span>Freitas, J. N., and M. Esposito (2022a), [Nat. Commun.](http://dx.doi.org/ 10.1038/s41467-022-32700-7) 13 [\(1\), 5084.](http://dx.doi.org/ 10.1038/s41467-022-32700-7)
- <span id="page-44-7"></span>Freitas, N., J.-C. Delvenne, and M. Esposito (2020), [Phys.](http://dx.doi.org/10.1103/PhysRevX.10.031005) Rev. X 10 [\(3\), 031005.](http://dx.doi.org/10.1103/PhysRevX.10.031005)
- <span id="page-44-8"></span>Freitas, N., J.-C. Delvenne, and M. Esposito (2021a), [Phys.](http://dx.doi.org/ 10.1103/PhysRevX.11.031064) Rev. X 11[, 031064.](http://dx.doi.org/ 10.1103/PhysRevX.11.031064)
- <span id="page-44-56"></span>Freitas, N., and M. Esposito (2021), [Phys. Rev. E](http://dx.doi.org/10.1103/PhysRevE.103.032118) 103, [032118.](http://dx.doi.org/10.1103/PhysRevE.103.032118)
- <span id="page-44-57"></span>Freitas, N., and M. Esposito (2022b), [Phys. Rev. Lett.](http://dx.doi.org/ 10.1103/PhysRevLett.129.120602) 129 [\(12\), 120602.](http://dx.doi.org/ 10.1103/PhysRevLett.129.120602)
- <span id="page-44-58"></span>Freitas, N., and M. Esposito (2023), [Phys. Rev. E](http://dx.doi.org/10.1103/PhysRevE.107.014136) 107,

- [014136.](http://dx.doi.org/10.1103/PhysRevE.107.014136)
- <span id="page-45-33"></span>Freitas, N., G. Falasco, and M. Esposito (2021b), [New J.](http://dx.doi.org/10.1088/1367-2630/ac1bf5) Phys. 23 [\(9\), 093003.](http://dx.doi.org/10.1088/1367-2630/ac1bf5)
- <span id="page-45-54"></span>Freitas, N., K. Proesmans, and M. Esposito (2022a), [Phys.](http://dx.doi.org/ 10.1103/PhysRevE.105.034107) Rev. E 105 [\(3\), 034107.](http://dx.doi.org/ 10.1103/PhysRevE.105.034107)
- <span id="page-45-55"></span>Freitas, N., K. Proesmans, and M. Esposito (2022b), [Phys.](http://dx.doi.org/ 10.1103/PhysRevE.105.034107) Rev. E 105[, 034107.](http://dx.doi.org/ 10.1103/PhysRevE.105.034107)
- <span id="page-45-39"></span>Fruchart, M., R. Hanai, P. B. Littlewood, and V. Vitelli (2021), Nature 592 (7854), 363.
- <span id="page-45-22"></span>Gallavotti, G., and E. G. D. Cohen (1995a), Phys. Rev. Lett. 74, 2694.
- <span id="page-45-23"></span>Gallavotti, G., and E. G. D. Cohen (1995b), J. Stat. Phys. 80, 931.
- <span id="page-45-18"></span>Gang, H. (1987), [Phys. Rev. A](http://dx.doi.org/10.1103/PhysRevA.36.5782) 36 (12), 5782.
- <span id="page-45-28"></span>Gao, Y., and J.-G. Liu (2022), J. Stat. Phys. 189 (2), 1.
- <span id="page-45-17"></span>Gardiner, C. W. (2004), Handbook of stochastic methods for physics, chemistry and the natural sciences, 3rd ed., Springer Series in Synergetics, Vol. 13 (Springer-Verlag, Berlin).
- <span id="page-45-45"></span>Garrahan, J. P., R. L. Jack, V. Lecomte, E. Pitard, K. van Duijvendijk, and F. van Wijland (2007), [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.98.195702) 98[, 195702.](http://dx.doi.org/10.1103/PhysRevLett.98.195702)
- <span id="page-45-43"></span>Garrahan, J. P., R. L. Jack, V. Lecomte, E. Pitard, K. van Duijvendijk, and F. van Wijland (2009), [J. Phys. A](http://dx.doi.org/10.1088/1751-8113/42/7/075007) 42 (7), [075007.](http://dx.doi.org/10.1088/1751-8113/42/7/075007)
- <span id="page-45-9"></span>Garvey, J. E., and M. Whiles (2016), Trophic ecology (CRC Press).
- <span id="page-45-34"></span>Gaspard, P. (2002a), J. Chem. Phys. 117 (19), 8905.
- <span id="page-45-35"></span>Gaspard, P. (2002b), Journal of statistical physics 106, 57.
- <span id="page-45-21"></span>Gaspard, P. (2005), Chaos, scattering and statistical mechanics, Vol. 9 (Cambridge University Press).
- <span id="page-45-50"></span>Gaspard, P. (2020), [Chaos: An Interdisciplinary Journal of](http://dx.doi.org/10.1063/5.0025350) [Nonlinear Science](http://dx.doi.org/10.1063/5.0025350) 30 (11), 113103.
- <span id="page-45-1"></span>Gaspard, P. (2022), The Statistical Mechanics of Irreversible Phenomena (Cambridge University Press).
- <span id="page-45-11"></span>Gaspard, P., and R. Kapral (2020), [Research](http://dx.doi.org/10.34133/2020/9739231) 2020, [10.34133/2020/9739231.](http://dx.doi.org/10.34133/2020/9739231)
- <span id="page-45-36"></span>Gaveau, B., M. Moreau, and J. Toth (1997), Letters in Mathematical Physics 40 (2), 101.
- <span id="page-45-32"></span>Gaveau, B., M. Moreau, and J. Toth (1998), Physical Review E 58 (5), 5351.
- <span id="page-45-30"></span>Gaveau, B., M. Moreau, and J. Toth (1999), J. Chem. Phys. 111 (17), 7748.
- <span id="page-45-24"></span>Gaveau, B., and L. Schulman (1998a), J. Math. Phys. 39 (3), 1517.
- <span id="page-45-51"></span>Gaveau, B., and L. S. Schulman (1998b), [Jour](http://dx.doi.org/ 10.1063/1.532394)[nal of Mathematical Physics](http://dx.doi.org/ 10.1063/1.532394) 39 (3), 1517, [https://doi.org/10.1063/1.532394.](http://arxiv.org/abs/https://doi.org/10.1063/1.532394)
- <span id="page-45-16"></span>Ge, H., and H. Qian (2010), Phys Rev E 81 (5), 051133.
- <span id="page-45-27"></span>Ge, H., and H. Qian (2012), Chaos 22 (2), 023140.
- <span id="page-45-64"></span>Geitner, M., F. Aguilar Sandoval, E. Bertin, and L. Bellon (2017), Phys. Rev. E 95, 032138.
- <span id="page-45-52"></span>Gillespie, D. T. (1977), J. Phys. Chem. 81 (25), 2340.
- <span id="page-45-49"></span>Gillespie, D. T. (1992), Physica A 188 (1-3), 404.
- <span id="page-45-15"></span>Gillespie, D. T. (2000), J. Chem. Phys. 113 (1), 297.
- <span id="page-45-57"></span>Gingrich, T. R., G. M. Rotskoff, and J. M. Horowitz (2017), Journal of Physics A: Mathematical and Theoretical 50 (18), 184004.
- <span id="page-45-46"></span>Gingrich, T. R., S. Vaikuntanathan, and P. L. Geissler (2014), [Phys. Rev. E](http://dx.doi.org/ 10.1103/PhysRevE.90.042123) 90, 042123.
- <span id="page-45-12"></span>Goldstein, S., D. A. Huse, J. L. Lebowitz, and P. Sartori (2019), in Stochastic Dynamics Out of Equilibrium, edited by G. Giacomin, S. Olla, E. Saada, H. Spohn, and G. Stoltz (Springer International Publishing, Cham) pp. 581–596.

- <span id="page-45-37"></span>Gopal, A., M. Esposito, and N. Freitas (2022), [Phys. Rev. B](http://dx.doi.org/10.1103/PhysRevB.106.155303) 106[, 155303.](http://dx.doi.org/10.1103/PhysRevB.106.155303)
- <span id="page-45-42"></span>Grafke, T., T. Schäfer, and E. Vanden-Eijnden (2017), Recent progress and modern challenges in applied mathematics, modeling and computational science , 17.
- <span id="page-45-14"></span>Graham, R. (1987), in Fluctuations and Stochastic Phenomena in Condensed Matter (Springer) pp. 1–34.
- <span id="page-45-31"></span>Graham, R., and T. Tél (1985), Physical Review A 31 (2), 1109.
- <span id="page-45-29"></span><span id="page-45-26"></span>Graham, R., and T. Tél (1986), Phys. Rev. A 33 (2), 1322. Grassberger, P., and S. Manfred (1980), Fortschritte der Physik 28 (10), 547.
- <span id="page-45-0"></span>de Groot, S. R., and P. Mazur (1984), Non-Equilibrium Thermodynamics (Dover).
- <span id="page-45-60"></span>Guioth, J., and E. Bertin (2018), EPL 123 (1), 10002.
- <span id="page-45-61"></span>Guioth, J., and E. Bertin (2019a), J. Chem. Phys. 150 (9), 094108.
- <span id="page-45-62"></span>Guioth, J., and E. Bertin (2019b), Phys. Rev. E 100 (5), 052125.
- <span id="page-45-53"></span>Hajimiri, A., S. Limotyrakis, and T. H. Lee (1999), [IEEE J.](http://dx.doi.org/10.1109/4.766813) [Solid-State Circuits](http://dx.doi.org/10.1109/4.766813) 34 (6), 790.
- <span id="page-45-38"></span>Hänggi, P., and P. Jung (1988), [IBM J. Res. Dev.](http://dx.doi.org/ 10.1147/rd.321.0119) 32 (1), [119.](http://dx.doi.org/ 10.1147/rd.321.0119)
- <span id="page-45-41"></span>Hänggi, P., P. Talkner, and M. Borkovec (1990), [Rev. Mod.](http://dx.doi.org/ 10.1103/RevModPhys.62.251) [Phys.](http://dx.doi.org/ 10.1103/RevModPhys.62.251) 62, 251.
- <span id="page-45-19"></span>Hao, G., and Q. Hong (2011), [J. R. Soc. Interface](http://dx.doi.org/10.1098/rsif.2010.0202) 8 (54), [107.](http://dx.doi.org/10.1098/rsif.2010.0202)
- <span id="page-45-63"></span><span id="page-45-4"></span>Harada, T., and S. Sasa (2005), Phys. Rev. Lett. 95, 130602. Hartich, D., A. C. Barato, and U. Seifert (2014), J. Stat. Mech. 2014 (2), P02016.
- <span id="page-45-59"></span>Harunari, P. E., A. Dutta, M. Polettini, and É. Roldán (2022), Physical Review X 12 (1), 041026.
- <span id="page-45-58"></span>Hasegawa, Y., and T. Van Vu (2019), Physical Review Letters 123 (11), 110602.
- <span id="page-45-13"></span><span id="page-45-5"></span>Hatano, T., and S. Sasa (2001), Phys. Rev. Lett. 86, 3463–. Henkel, C. (2017), [Zeitschrift für Naturforschung A](http://dx.doi.org/10.1515/zna-2016-0372) 72 (2), [99.](http://dx.doi.org/10.1515/zna-2016-0372)
- <span id="page-45-6"></span>Herpich, T., T. Cossetto, G. Falasco, and M. Esposito (2020a), [New J. Phys.](http://dx.doi.org/10.1088/1367-2630/ab882f) 22 (6), 063005.
- <span id="page-45-7"></span>Herpich, T., and M. Esposito (2019), Physical Review E 99 (2), 022135.
- <span id="page-45-10"></span>Herpich, T., K. Shayanfard, and M. Esposito (2020b), [Phys.](http://dx.doi.org/ 10.1103/PhysRevE.101.022116) Rev. E 101[, 022116.](http://dx.doi.org/ 10.1103/PhysRevE.101.022116)
- <span id="page-45-8"></span>Herpich, T., J. Thingna, and M. Esposito (2018a), Phys. Rev. X 8, 031056.
- <span id="page-45-25"></span>Herpich, T., J. Thingna, and M. Esposito (2018b), [Phys.](http://dx.doi.org/10.1103/PhysRevX.8.031056) Rev. X 8 [\(3\), 031056.](http://dx.doi.org/10.1103/PhysRevX.8.031056)
- <span id="page-45-56"></span>Hohenberg, P. C., and B. I. Halperin (1977), [Rev. Mod. Phys.](http://dx.doi.org/ 10.1103/RevModPhys.49.435) 49[, 435.](http://dx.doi.org/ 10.1103/RevModPhys.49.435)
- <span id="page-45-48"></span>Horowitz, J. M. (2015), [J. Chem. Phys.](http://dx.doi.org/ 10.1063/1.4927395) 143 (4), 044111.
- <span id="page-45-2"></span>Horowitz, J. M., and M. Esposito (2014), [Phys. Rev. X](http://dx.doi.org/ 10.1103/PhysRevX.4.031015) 4, [031015.](http://dx.doi.org/ 10.1103/PhysRevX.4.031015)
- <span id="page-45-3"></span>Horowitz, J. M., and T. R. Gingrich (2020), [Nat. Phys.](http://dx.doi.org/ 10.1038/s41567-019-0702-6) 16 [\(1\), 15.](http://dx.doi.org/ 10.1038/s41567-019-0702-6)
- <span id="page-45-20"></span>Huang, S., F. Li, J. X. Zhou, and H. Qian (2017), J. R. Soc. Interface 14 (130), 20170097.
- <span id="page-45-44"></span>Hurtado, P. I., C. P. Espigares, J. J. del Pozo, and P. L. Garrido (2014), J. Stat. Phys. 154 (1), 214.
- <span id="page-45-47"></span>Hurtado, P. I., and P. L. Garrido (2011), [Phys. Rev. Lett.](http://dx.doi.org/ 10.1103/PhysRevLett.107.180601) 107[, 180601.](http://dx.doi.org/ 10.1103/PhysRevLett.107.180601)
- <span id="page-45-65"></span>Ilker, E., and M. Hinczewski (2019), [Phys. Rev. Lett.](http://dx.doi.org/ 10.1103/PhysRevLett.122.238101) 122, [238101.](http://dx.doi.org/ 10.1103/PhysRevLett.122.238101)
- <span id="page-45-40"></span>Ivlev, A. V., J. Bartnick, M. Heinen, C.-R. Du, V. Nosenko, and H. Löwen (2015), [Phys. Rev. X](http://dx.doi.org/10.1103/PhysRevX.5.011035) 5, 011035.

- <span id="page-46-2"></span>Jarzynski, C. (2011), [Annu. Rev. Condens. Matter Phys.](http://dx.doi.org/ 10.1146/annurev-conmatphys-062910-140506) 2 [\(1\), 329.](http://dx.doi.org/ 10.1146/annurev-conmatphys-062910-140506)
- <span id="page-46-18"></span>Jiu-li, L., C. Van den Broeck, and G. Nicolis (1984), [Z. Physik](http://dx.doi.org/10.1007/BF01469698) [B - Condensed Matter](http://dx.doi.org/10.1007/BF01469698) 56 (2), 165.
- <span id="page-46-62"></span><span id="page-46-3"></span>Joyeux, M., and E. Bertin (2016), [Phys. Rev. E](http://dx.doi.org/10.1103/PhysRevE.93.032605) 93, 032605. Jun, Y., M. Gavrilov, and J. Bechhoefer (2014), [Phys. Rev.](http://dx.doi.org/10.1103/PhysRevLett.113.190601) Lett. 113 [\(19\), 190601.](http://dx.doi.org/10.1103/PhysRevLett.113.190601)
- <span id="page-46-50"></span>Kac, M., G. Uhlenbeck, and P. Hemmer (1963), Journal of Mathematical Physics 4 (2), 216.
- <span id="page-46-27"></span>Kampen, N. v. (1961), Canadian Journal of Physics 39 (4), 551.
- <span id="page-46-42"></span>Kawasaki, K. (1998), J. Stat. Phys. 93 (3), 527.
- <span id="page-46-5"></span>Keizer, J. (1978), The Journal of Chemical Physics 69 (6), 2609.
- <span id="page-46-36"></span>Keller, H. B. (2018), Numerical methods for two-point boundary-value problems (Courier Dover Publications).
- <span id="page-46-37"></span>Kikuchi, L., R. Singh, M. E. Cates, and R. Adhikari (2020), Phys. Rev. Res. 2, 033208.
- <span id="page-46-41"></span>Konarovskyi, V., T. Lehmann, and M. von Renesse (2020), J. Stat. Phys. 178 (3), 666.
- <span id="page-46-4"></span>Koski, J. V., A. Kutvonen, I. M. Khaymovich, T. Ala-Nissila, and J. P. Pekola (2015), [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.115.260602) 115 (26), 260602.
- <span id="page-46-59"></span>Koyuk, T., and U. Seifert (2022), [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.129.210603) 129 (21), [210603.](http://dx.doi.org/10.1103/PhysRevLett.129.210603)
- <span id="page-46-15"></span>Kraaij, R., A. Lazarescu, C. Maes, and M. Peletier (2018), Journal of Statistical Physics 170, 492.
- <span id="page-46-32"></span>Kramers, H. (1940), Physica 7 (4), 284.
- <span id="page-46-12"></span>Kubo, R., K. Matsuo, and K. Kitahara (1973), J. Stat. Phys. 9, 51.
- <span id="page-46-38"></span>Kurchan, J. (1998), J. Phys. A: Math. Gen 31, 3719.
- <span id="page-46-14"></span>Kurchan, J. (2009), arXiv:0901.1271.
- <span id="page-46-48"></span>Kurtz, T. G. (1972), [J. Chem. Phys.](http://dx.doi.org/ 10.1063/1.1678692) 57 (7), 2976, [https://doi.org/10.1063/1.1678692.](http://arxiv.org/abs/https://doi.org/10.1063/1.1678692)
- <span id="page-46-35"></span>Kuznets-Speck, B., and D. T. Limmer (2021), [Proc. Natl.](http://dx.doi.org/ 10.1073/pnas.2020863118) [Acad. Sci. U.S.A.](http://dx.doi.org/ 10.1073/pnas.2020863118) 118 (8), e2020863118.
- <span id="page-46-9"></span>Landau, L. D., and E. M. Lifshitz (1959), Fluid Mechanics (Pergamon Press).
- <span id="page-46-33"></span>Landauer, R., and J. Swanson (1961), Physical Review 121 (6), 1668.
- <span id="page-46-7"></span>Lange, S., J. Pohl, and T. Santarius (2020), Ecological economics 176, 106760.
- <span id="page-46-34"></span>Langer, J. S. (1969), Ann. Phys. 54 (2), 258.
- <span id="page-46-21"></span>Lazarescu, A., T. Cossetto, G. Falasco, and M. Esposito (2019), [J. Chem. Phys.](http://dx.doi.org/10.1063/1.5111110) 151 (6), 064117.
- <span id="page-46-49"></span><span id="page-46-39"></span>Lebowitz, J. L., and H. Spohn (1999), J. Stat. Phys. 95, 333. Lefever, R., G. Nicolis, and P. Borckmans (1988), Journal of the Chemical Society, Faraday Transactions 1: Physical Chemistry in Condensed Phases 84 (4), 1013.
- <span id="page-46-20"></span>Lefevre, A., and G. Biroli (2007), Journal of Statistical Mechanics: Theory and Experiment 2007 (07), P07024.
- <span id="page-46-16"></span>Liero, M., and A. Mielke (2013), Philosophical Transactions of the Royal Society A: Mathematical, Physical and Engineering Sciences 371 (2005), 20120346.
- <span id="page-46-28"></span>Loos, S. A., and S. H. Klapp (2020), New Journal of Physics 22 (12), 123051.
- <span id="page-46-22"></span>Luchinsky, D., P. V. McClintock, and M. Dykman (1998), Reports on Progress in Physics 61 (8), 889.
- <span id="page-46-30"></span>Luchinsky, D. G., R. S. Maier, R. Mannella, P. V. E. McClintock, and D. L. Stein (1999), [Phys. Rev. Lett.](http://dx.doi.org/ 10.1103/PhysRevLett.82.1806) 82, 1806.
- <span id="page-46-68"></span>Lynch, M., and G. K. Marinov (2015), Proceedings of the National Academy of Sciences 112 (51), 15690.
- <span id="page-46-58"></span>Macieszczak, K., K. Brandner, and J. P. Garrahan (2018), Physical Review Letters 121 (13), 130601.
- <span id="page-46-11"></span>Maes, C. (2018), Non-dissipative effects in nonequilibrium sys-

- tems (Springer).
- <span id="page-46-8"></span>Maes, C. (2020), [Phys. Rev. Lett.](http://dx.doi.org/ 10.1103/PhysRevLett.125.208001) 125, 208001.
- <span id="page-46-0"></span>Maes, C. (2021), [SciPost Phys. Lect. Notes](http://dx.doi.org/ 10.21468/SciPostPhysLectNotes.32) 32, 1.
- <span id="page-46-24"></span>Maes, C., and K. Netocny (2010), [Journal of Mathematical](http://dx.doi.org/10.1063/1.3274819) Physics 51 [\(1\), 015219,](http://dx.doi.org/10.1063/1.3274819) [https://doi.org/10.1063/1.3274819.](http://arxiv.org/abs/https://doi.org/10.1063/1.3274819)
- <span id="page-46-47"></span>Maes, C., and K. Netočn`y (2013), in Ann. Henri Poincaré, Vol. 14 (Springer) pp. 1193–1202.
- <span id="page-46-19"></span>Maes, C., and K. Netočn`y (2015), J. Stat. Phys. 159 (6), 1286.
- <span id="page-46-13"></span>Maes, C., and K. Netočný (2007), Comptes Rendus Physique 8, 591.
- <span id="page-46-10"></span>Maes, C., and K. Netočný (2008), Europhys. Lett. 82, 30003.
- <span id="page-46-45"></span><span id="page-46-23"></span>Maes, C., and K. Netočný (2014), J. Stat. Phys. 154, 188. Maier, R. S., and D. L. Stein (1993), [Phys. Rev. Lett.](http://dx.doi.org/ 10.1103/PhysRevLett.71.1783) 71,
- [1783.](http://dx.doi.org/ 10.1103/PhysRevLett.71.1783)
- <span id="page-46-31"></span>Maier, R. S., and D. L. Stein (1997), SIAM Journal on Applied Mathematics 57 (3), 752.
- <span id="page-46-46"></span>Malinin, S. V., and V. Y. Chernyak (2010), J. Chem. Phys. 132 (1), 01B602.
- <span id="page-46-63"></span>Manacorda, A., and A. Puglisi (2017), [Phys. Rev. Lett.](http://dx.doi.org/ 10.1103/PhysRevLett.119.208003) 119, [208003.](http://dx.doi.org/ 10.1103/PhysRevLett.119.208003)
- <span id="page-46-55"></span>Mangeat, M., S. Chatterjee, R. Paul, and H. Rieger (2020), Physical Review E 102 (4), 042601.
- <span id="page-46-6"></span>Marchetti, M. C., J. F. Joanny, S. Ramaswamy, T. B. Liverpool, J. Prost, M. Rao, and R. A. Simha (2013), [Rev.](http://dx.doi.org/10.1103/RevModPhys.85.1143) [Mod. Phys.](http://dx.doi.org/10.1103/RevModPhys.85.1143) 85 (3), 1143.
- <span id="page-46-43"></span>Marconi, U. M. B., and P. Tarazona (1999), J. Chem. Phys. 110 (16), 8032.
- <span id="page-46-65"></span>Marini Bettolo Marconi, U., A. Puglisi, L. Rondoni, and A. Vulpiani (2008), Phys. Rep. 461, 111.
- <span id="page-46-44"></span>Markovich, T., E. Fodor, E. Tjhung, and M. E. Cates (2021a), [Phys. Rev. X](http://dx.doi.org/ 10.1103/PhysRevX.11.021057) 11, 021057.
- <span id="page-46-57"></span>Markovich, T., E. Fodor, E. Tjhung, and M. E. Cates (2021b), [Phys. Rev. X](http://dx.doi.org/ 10.1103/PhysRevX.11.021057) 11, 021057.
- <span id="page-46-26"></span>Marsland III, R., W. Cui, and J. M. Horowitz (2019), J. R. Soc. Interface 16 (154), 20190098.
- <span id="page-46-61"></span>Martynec, T., S. H. Klapp, and S. A. Loos (2020), New J. Phys. 22 (9), 093069.
- <span id="page-46-67"></span>Martyushev, L. M., and V. D. Seleznev (2006), Physics reports 426 (1), 1.
- <span id="page-46-25"></span>McLennan Jr, J. A. (1959), Physical review 115 (6), 1405.
- <span id="page-46-60"></span>Van der Meer, J., B. Ertel, and U. Seifert (2022), Physical Review X 12 (3), 031025.
- <span id="page-46-1"></span>Mehl, J., B. Lander, C. Bechinger, V. Blickle, and U. Seifert (2012), [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.108.220601) 108, 220601.
- <span id="page-46-52"></span>Meibohm, J., and M. Esposito (2022), [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.128.110603) 128, [110603.](http://dx.doi.org/10.1103/PhysRevLett.128.110603)
- <span id="page-46-53"></span>Meibohm, J., and M. Esposito (2023), New J. Phys. 25 (2), 023034.
- <span id="page-46-54"></span>Meibohm, J., and M. Esposito (2024a), arXiv preprint arXiv:2401.14982.
- <span id="page-46-51"></span>Meibohm, J., and M. Esposito (2024b), arXiv preprint arXiv:2401.14980.
- <span id="page-46-17"></span>Mielke, A., D. M. Renger, and M. A. Peletier (2016), J. Non-Equilib. Thermodyn. 41 (2), 141.
- <span id="page-46-66"></span>Müller, B., J. Berner, C. Bechinger, and M. Krüger (2020), New Journal of Physics 22 (2), 023014.
- <span id="page-46-29"></span>Mura, F., G. Gradziuk, and C. P. Broedersz (2018), [Phys.](http://dx.doi.org/10.1103/PhysRevLett.121.038002) [Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.121.038002) 121, 038002.
- <span id="page-46-40"></span>Murashita, Y., K. Funo, and M. Ueda (2014), [Phys. Rev. E](http://dx.doi.org/10.1103/PhysRevE.90.042110) 90[, 042110.](http://dx.doi.org/10.1103/PhysRevE.90.042110)
- <span id="page-46-64"></span>Nakamura, T., and A. Yoshimori (2009), J. Phys. A 42 (6), 065001.
- <span id="page-46-56"></span>Nardini, C., É. Fodor, E. Tjhung, F. Van Wijland, J. Tailleur,

- <span id="page-47-35"></span>and M. E. Cates (2017), Physical Review X 7 (2), 021007. Negele, J. W. (2018), Quantum many-particle systems (CRC Press).
- <span id="page-47-37"></span>Neri, I. (2022), [SciPost Phys.](http://dx.doi.org/ 10.21468/SciPostPhys.12.4.139) 12, 139.
- <span id="page-47-70"></span><span id="page-47-45"></span>Nguyen, B., and U. Seifert (2020), [Phys. Rev. E](http://dx.doi.org/10.1103/PhysRevE.102.022101) 102, 022101. Nicolis, C., and G. Nicolis (2010), Quarterly Journal of the Royal Meteorological Society 136 (650), 1161.
- <span id="page-47-62"></span>Noa, C. F., P. E. Harunari, M. de Oliveira, and C. Fiore (2019), Phys. Rev. E 100 (1), 012104.
- <span id="page-47-24"></span>Norris, J. R. (1998), Markov chains, 2 (Cambridge university press).
- <span id="page-47-40"></span><span id="page-47-27"></span>Nyawo, P. T., and H. Touchette (2017), EPL 116 (5), 50009. Onsager, L. (1931), [Phys. Rev.](http://dx.doi.org/10.1103/PhysRev.37.405) 37, 405.
- <span id="page-47-34"></span>Onsager, L., and S. Machlup (1953), [Phys. Rev.](http://dx.doi.org/10.1103/PhysRev.91.1505) 91, 1505.
- <span id="page-47-10"></span>Oono, Y., and M. Paniconi (1998), Progr. Theor. Phys. Suppl. 130, 29.
- <span id="page-47-26"></span>Öttinger, H. C. (2005), Beyond equilibrium thermodynamics (John Wiley & Sons).
- <span id="page-47-67"></span>Owen, J. A., T. R. Gingrich, and J. M. Horowitz (2020), [Phys. Rev. X](http://dx.doi.org/10.1103/PhysRevX.10.011066) 10, 011066.
- <span id="page-47-7"></span>Parrondo, J. M. R., J. M. Horowitz, and T. Sagawa (2015), [Nat. Phys.](http://dx.doi.org/ 10.1038/nphys3230) 11 (2), 131.
- <span id="page-47-5"></span>Pekola, J. P. (2015), [Nat. Phys.](http://dx.doi.org/10.1038/nphys3169) 11 (2), 118.
- <span id="page-47-28"></span>Peliti, L. (1985), [Journal de Physique](http://dx.doi.org/ 10.1051/jphys:019850046090146900) 46 (9), 1469.
- <span id="page-47-1"></span>Peliti, L., and S. Pigolotti (2021), Stochastic Thermodynamics: An Introduction (Princeton University Press).
- <span id="page-47-16"></span>Pietzonka, P., and U. Seifert (2017), Journal of Physics A 51 (1), 01LT01.
- <span id="page-47-46"></span>Polettini, M. (2015), Letters in Mathematical Physics 105, 89.
- <span id="page-47-12"></span>Polettini, M., and M. Esposito (2017), Phys. Rev. Lett. 119, 240601.
- <span id="page-47-38"></span>Press, W. H., S. A. Teukolsky, W. T. Vetterling, and B. P. Flannery (2007), Numerical recipes 3rd edition: The art of scientific computing (Cambridge University Press).
- <span id="page-47-0"></span>Prigogine, I. (1961), Introduction to Thermodynamics of Irreversible Processes, 2nd Ed. (Interscience Publishers, New York).
- <span id="page-47-51"></span>Prigogine, I., and R. Lefever (1968), The Journal of Chemical Physics 48 (4), 1695.
- <span id="page-47-59"></span>Prinz, J.-H., H. Wu, M. Sarich, B. Keller, M. Senne, M. Held, J. D. Chodera, C. Schütte, and F. Noé (2011), J. Chem. Phys. 134 (17), 174105.
- <span id="page-47-64"></span>Proesmans, K., and B. Derrida (2019), Journal of Statistical Mechanics: Theory and Experiment 2019 (2), 023201.
- <span id="page-47-58"></span>Proesmans, K., G. Falasco, A. Mohite, E. Fodor, and M. Esposito (2024), To be submitted.
- <span id="page-47-33"></span>Prost, J., J.-F. Joanny, and J. M. Parrondo (2009), Phys. Rev. Lett. 103, 090601.
- <span id="page-47-13"></span>Puglisi, A., S. Pigolotti, L. Rondoni, and A. Vulpiani (2010), J. Stat. Mech. 2010 (05), P05015.
- <span id="page-47-25"></span>Qian, H., P. Ao, Y. Tu, and J. Wang (2016), [Chem. Phys.](http://dx.doi.org/10.1016/j.cplett.2016.10.059) Lett. 665[, 153.](http://dx.doi.org/10.1016/j.cplett.2016.10.059)
- <span id="page-47-69"></span>Radunz, R., D. Rings, K. Kroy, and F. Cichos (2009), The Journal of Physical Chemistry A 113 (9), 1674.
- <span id="page-47-14"></span>Rahav, S., and C. Jarzynski (2007), J. Stat. Mech. 2007 (09), P09012.
- <span id="page-47-42"></span>Rana, S., and A. C. Barato (2020), Phys. Rev. E 102, 032135.
- <span id="page-47-20"></span><span id="page-47-11"></span>Rao, R., and M. Esposito (2016), [Phys. Rev. X](http://dx.doi.org/10.1103/PhysRevX.6.041064) 6, 041064. Rao, R., and M. Esposito (2018a), [J. Chem. Phys.](http://dx.doi.org/10.1063/1.5042253) 149 (24), [245101.](http://dx.doi.org/10.1063/1.5042253)
- <span id="page-47-4"></span>Rao, R., and M. Esposito (2018b), [New J. Phys.](http://dx.doi.org/ 10.1088/1367-2630/aaa15f) 20 (2), [023007.](http://dx.doi.org/ 10.1088/1367-2630/aaa15f)
- <span id="page-47-6"></span>Rao, R., and M. Esposito (2018c), [Entropy](http://dx.doi.org/10.3390/e20090635) 20 (9), 635.

- <span id="page-47-71"></span>Redner, S. (2001), A guide to first-passage processes (Cambridge University Press).
- <span id="page-47-50"></span>Remlein, B., and U. Seifert (2024), The Journal of Chemical Physics 160 (13).
- <span id="page-47-32"></span>Remlein, B., V. Weissmann, and U. Seifert (2022), [Phys.](http://dx.doi.org/10.1103/PhysRevE.105.064101) Rev. E 105[, 064101.](http://dx.doi.org/10.1103/PhysRevE.105.064101)
- <span id="page-47-53"></span>Rezaei, E., M. Donato, W. R. Patterson, A. Zaslavsky, and R. I. Bahar (2020), [IEEE Trans. Device Mater. Reliab. , 1.](http://dx.doi.org/10.1109/TDMR.2020.2996627) Ruelle, D. (2009), Nonlin. 22, 855.
- <span id="page-47-68"></span><span id="page-47-18"></span>Rytov, S. (1958), Sov. Phys. JETP 6, 130.
- <span id="page-47-19"></span>Rytov, S. M., Y. A. Kravtsov, and V. I. Tatarskii (1989), Priniciples of statistical radiophysics. 3. Elements of random fields. (Springer).
- <span id="page-47-43"></span>Sasa, S., and H. Tasaki (2006), J. Stat. Phys. 125, 125.
- <span id="page-47-49"></span>Schlögl, F. (1972), Zeitschrift für physik 253 (2), 147.
- <span id="page-47-47"></span>Schmiedl, T., and U. Seifert (2007), [J. Chem. Phys.](http://dx.doi.org/ 10.1063/1.2428297) 126 (4), [044101.](http://dx.doi.org/ 10.1063/1.2428297)
- <span id="page-47-22"></span>Schnakenberg, J. (1976), Rev. Mod. Phys. 48 (4), 571.
- <span id="page-47-72"></span>Schuss, Z. (2009), Theory and applications of stochastic processes: an analytical approach, Vol. 170 (Springer Science & Business Media).
- <span id="page-47-21"></span>Seifert, U. (2005), [Phys. Rev. Lett.](http://dx.doi.org/ 10.1103/PhysRevLett.95.040602) 95 (4), 040602.
- <span id="page-47-2"></span>Seifert, U. (2012), [Rep. Prog. Phys.](http://dx.doi.org/ 10.1088/0034-4885/75/12/126001) 75 (12), 126001.
- <span id="page-47-65"></span><span id="page-47-9"></span>Seifert, U., and T. Speck (2010), Europhys. Lett. 89, 10007. Sekimoto, K. (2010), Stochastic Energetics, Lecture Notes in Physics, Vol. 799 (Springer).
- <span id="page-47-52"></span>Semenov, O., A. Vassighi, and M. Sachdev (2006), IEEE transactions on device and materials reliability 6 (1), 17.
- <span id="page-47-30"></span>Sheth, J., S. W. F. Meenderink, P. M. Quiñones, D. Bozovic, and A. J. Levine (2018), [Phys. Rev. E](http://dx.doi.org/10.1103/PhysRevE.97.062411) 97, 062411.
- <span id="page-47-3"></span>Shiraishi, N. (2023), An Introduction to Stochastic Thermodynamics (Springer).
- <span id="page-47-8"></span>Shiraishi, N., K. Funo, and K. Saito (2018), [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.121.070601) 121[, 070601.](http://dx.doi.org/10.1103/PhysRevLett.121.070601)
- <span id="page-47-54"></span>Skellam, J. G. (1946), Journal of the Royal Statistical Society 109 (3), 296.
- <span id="page-47-60"></span>Skinner, D. J., and J. Dunkel (2021a), Physical Review Letters 127 (19), 198101.
- <span id="page-47-61"></span>Skinner, D. J., and J. Dunkel (2021b), Proceedings of the National Academy of Sciences 118 (18), e2024300118.
- <span id="page-47-29"></span>Smith, E. (2011), [Rep. Prog. Phys.](http://dx.doi.org/ 10.1088/0034-4885/74/4/046601) 74 (4), 046601.
- <span id="page-47-44"></span>Smith, E. (2020), Entropy 22 (10), 1137.
- <span id="page-47-31"></span>Smith, E., and H. J. Morowitz (2016), [The Origin and Nature](http://dx.doi.org/ 10.1017/CBO9781316348772) [of Life on Earth: The Emergence of the Fourth Geosphere](http://dx.doi.org/ 10.1017/CBO9781316348772) (Cambridge University Press).
- <span id="page-47-48"></span>Snarski, M. (2021), arXiv preprint arXiv:2108.00514.
- <span id="page-47-57"></span>Solon, A., H. Chaté, J. Toner, and J. Tailleur (2022), [Phys.](http://dx.doi.org/ 10.1103/PhysRevLett.128.208004) [Rev. Lett.](http://dx.doi.org/ 10.1103/PhysRevLett.128.208004) 128, 208004.
- <span id="page-47-63"></span>Solon, A. P., J. Stenhammar, R. Wittkowski, M. Kardar, Y. Kafri, M. E. Cates, and J. Tailleur (2015), Phys. Rev. Lett. 114, 198301.
- <span id="page-47-55"></span>Solon, A. P., and J. Tailleur (2013), Physical Review Letters 111 (7), 078101.
- <span id="page-47-56"></span><span id="page-47-17"></span>Solon, A. P., and J. Tailleur (2015), Phys. Rev. E 92, 042119. Speck, T. (2022), Physical Review E 105 (1), L012601.
- <span id="page-47-39"></span>Speck, T., A. Engel, and U. Seifert (2012), J. Stat. Mech. 2012 (12), P12001.
- <span id="page-47-23"></span>Speck, T., and U. Seifert (2005), J. Phys. A 38 (34), L581.
- <span id="page-47-66"></span>Speck, T., and U. Seifert (2006), Europhys. Lett. 74, 391.
- <span id="page-47-41"></span>Spohn, H. (2012), Large scale dynamics of interacting particles (Springer Science & Business Media).
- <span id="page-47-36"></span>Steffenoni, S., K. Kroy, and G. Falasco (2016), Phys. Rev. E 94 (6), 062139.
- <span id="page-47-15"></span>Strasberg, P., and M. Esposito (2019), [Phys. Rev. E](http://dx.doi.org/ 10.1103/PhysRevE.99.012120) 99 (1),

012120.

<span id="page-48-37"></span>Strogatz, S. H. (2015), *Nonlinear Dynamics And Chaos* (Taylor & Francis Group).

<span id="page-48-9"></span>Sun, S. X. (2006), Phys. Rev. Lett. 96 (21), 210602.

<span id="page-48-25"></span>Tailleur, J., J. Kurchan, and V. Lecomte (2007), Phys. Rev. Lett. 99 (15), 150602.

<span id="page-48-38"></span>Takatori, S. C., W. Yan, and J. F. Brady (2014), Phys. Rev. Lett. 113, 028103.

<span id="page-48-15"></span>Thomas, P., and R. Grima (2015), Phys. Rev. E  $\bf 92$  (1), 012120.

<span id="page-48-33"></span>Timpanaro, A. M., G. Guarnieri, J. Goold, and G. T. Landi (2019), Physical Review Letters 123 (9), 090604.

<span id="page-48-16"></span>Tomita, K., and H. Tomita (1974), Progress of theoretical physics **51** (6), 1731.

<span id="page-48-5"></span>Touchette, H. (2009), Phys. Rep. 478 (1), 1.

<span id="page-48-2"></span>Toyabe, S., T. Sagawa, M. Ueda, E. Muneyuki, and M. Sano (2010), Nat. Phys. 6 (12), 988.

<span id="page-48-10"></span>Van Kampen, N. (2007), Stochastic Processes in Physics and Chemistry (North Holland).

<span id="page-48-34"></span><span id="page-48-3"></span>Van Vu, T., and K. Saito (2023a), Phys. Rev. X 13, 011013.
Van Vu, T., and K. Saito (2023b), Physical Review X 13 (1), 011013.

<span id="page-48-35"></span>Van Vu, T., V. Tuan Vo, and Y. Hasegawa (2020), Physical Review E 101 (4), 042138.

<span id="page-48-17"></span>Vance, W., and J. Ross (1996), The Journal of chemical physics **105** (2), 479.

<span id="page-48-26"></span>Vance, W., and J. Ross (1999), J. Phys. Chem. A 103 (10), 1347.

<span id="page-48-18"></span>Vastola, J. J., and W. R. Holmes (2020), Phys. Rev. E **101** (3), 10.1103/physreve.101.032417.

<span id="page-48-19"></span>Vellela, M., and H. Qian (2009a), J. R. Soc. Interface  ${\bf 6}$  (39), 925.

<span id="page-48-28"></span>Vellela, M., and H. Qian (2009b), Journal of The Royal Society Interface 6 (39), 925.

<span id="page-48-4"></span>Vo, V. T., T. Van Vu, and Y. Hasegawa (2020), Phys. Rev. E 102, 062132.

<span id="page-48-13"></span>Weber, M. F., and E. Frey (2017), Reports on Progress in Physics 80 (4), 046601.

<span id="page-48-22"></span>Weinan, E., and E. Vanden-Eijnden (2004), Commun. Pure Appl. Math. 57 (5), 637.

<span id="page-48-20"></span>Wiegel, F. W. (1986), Introduction to path-integral methods in physics and polymer science (World Scientific Publishing Company).

<span id="page-48-1"></span>Wolpert, D. H. (2019), J. Phys. A 52 (19), 193001.

<span id="page-48-7"></span>Wolpert, D. H., A. Kolchinsky, and J. A. Owen (2019), Nat. Commun. 10 (1), 1727.

<span id="page-48-30"></span>Wu, F. Y. (1982), Rev. Mod. Phys. 54, 235.

<span id="page-48-12"></span>Wu, W., and J. Wang (2013), J. Chem. Phys. **139** (12), 10.1063/1.4816376.

<span id="page-48-29"></span>Xiao, T. J., Z. Hou, and H. Xin (2008), J. Chem. Phys. 129 (11), 114506.

<span id="page-48-6"></span>Yang, X., M. Heinemann, J. Howard, G. Huber, S. Iyer-Biswas, G. Le Treut, M. Lynch, K. L. Montooth, D. J. Needleman, S. Pigolotti, J. Rodenfels, P. Ronceray, S. Shankar, I. Tavassoly, S. Thutupalli, D. V. Titov, J. Wang, and P. J. Foster (2021), Proceedings of the National Academy of Sciences 118 (26), 10.1073/pnas.2026786118.

<span id="page-48-36"></span>Yoshimura, K., and S. Ito (2021), Physical review letters **127** (16), 160601.

<span id="page-48-31"></span>Yu, Q., and Y. Tu (2022), Phys. Rev. Lett. 129, 278001.

<span id="page-48-8"></span>de Zárate, J. M. O., and J. V. Sengers (2006), *Hydrody-namic Fluctuations in Fluids and Fluid Mixtures* (Elsevier Science).

<span id="page-48-23"></span>Zakine, R., and E. Vanden-Eijnden (2023), Phys. Rev. X 13, 041044.

<span id="page-48-39"></span>Zakine, R., Y. Zhao, M. Knežević, A. Daerr, Y. Kafri, J. Tailleur, and F. van Wijland (2020), Phys. Rev. Lett. 124, 248003.

<span id="page-48-27"></span><span id="page-48-21"></span><span id="page-48-11"></span>Zhou, P., and T. Li (2016), J. Chem. Phys. 144 (9), 094109.
Zia, R., and B. Schmittmann (2007), J. Stat. Mech., P07012.
Zinn-Justin, J. (2002), Quantum field theory and critical phenomena, 4th ed. (Clarendon Press, Oxford).

<span id="page-48-14"></span>Zubarev, D. (1994), Cond. Matt. Phys 4 (7).

<span id="page-48-32"></span>Zubarev, D., and V. Morozov (1983), Physica A **120** (3), 411.

# <span id="page-48-0"></span>Appendix A: Derivation of the entropic upper bound on the transition rates

For autonomous systems, we start from the decomposition into adiabatic and nonadiabatic entropy production at the level of single trajectories, multiply both sides of the time-integrated version of (115) by  $\delta(c(0) - x_{\gamma}^*)\delta(c(t) - x_{\nu})$  and take the average. Hence, among all trajectories we sample only those that start from fixed points and reach a saddle. For large t, the lefthand side can be written in terms of the entropy production of the instantonic trajectory, defined as

<span id="page-48-40"></span>
$$\sigma_{\gamma \to \nu} := \tag{A1}$$

$$\frac{1}{p_{\rm ss}^{(\gamma)}(x_{\nu})} \lim_{t \to \infty} \lim_{V \to \infty} \left\langle \sigma \delta(c(0) - x_{\gamma}^{*}) \delta(c(t) - x_{\nu}) \right\rangle,$$

$$= \int_{c(0) = x_{\gamma}^{*}}^{c(\infty) = x_{\nu}} dt \sum_{\rho} r_{\rho}(c(t)) \sigma_{\rho}(c(t)) e^{\Delta_{\rho} \cdot \pi(t)},$$

where the second equality is (179), c(t) and  $\pi(t) = \partial_c I(c(t))$  being solution of (107) with boundary conditions  $c(0) = x_{\gamma}^*$  and  $c(\infty) = x_{\nu}$ . Here, we divided by  $p_{\rm ss}^{(\gamma)}(x_{\nu})$  to get rid of the exponentially small probability of the instanton, see (110), since we are only interested in the value of the entropy production along the trajectory – not on its statistical weight. Note that the macroscopic limit removes the Shannon entropy of the boundary states, so that  $\sigma_{\gamma \to \nu}$  counts only the entropy flow of the instanton.

Next, we show that the conditional mean of the adiabatic entropy production is still positive. The proof goes as follows. First, we note that

<span id="page-48-24"></span>
$$\sigma_{\rm ad}[\mathfrak{X}] = -\frac{1}{V} \ln \frac{P^{\dagger}[\mathfrak{X}]}{P[\mathfrak{X}]},\tag{A2}$$

where  $P^{\dagger}[\mathfrak{X}]$  denotes the path probability under the dual dynamics with transition rates  $r_{\rho}^{\dagger}(c)$  given in (40). We therefore write the transition probability  $P^{\dagger}(x_{\nu}, t|x_{\gamma}^{*}, 0)$  from  $x_{\gamma}^{*}$  to  $x_{\nu}$  under the dual dynamics as the conditional

average over paths,

$$P^{\dagger}(x_{\nu}, t | x_{\gamma}^{*}, 0) = \sum_{\mathfrak{X}} P^{\dagger}[\mathfrak{X}] \delta(c(0) - x_{\gamma}^{*}) \delta(c(t) - x_{\nu})$$

$$= \sum_{\mathfrak{X}} P[\mathfrak{X}] e^{-V\sigma_{\mathrm{ad}}[\mathfrak{X}]} \delta(c(0) - x_{\gamma}^{*}) \delta(c(t) - x_{\nu})$$

$$\geq P(x_{\nu}, t | x_{\gamma}^{*}, 0) e^{-\frac{V}{P(x_{\nu}, t | x_{\gamma}^{*}, 0)} \left\langle \sigma_{\mathrm{ad}} \delta(c(0) - x_{\gamma}^{*}) \delta(c(t) - x_{\nu}) \right\rangle}.$$
(A3)

In the last line we used Jensen's inequality applied to the normalized conditional average,  $\langle \dots \delta(c(0) - x_{\gamma}^*) \delta(c(t) - x_{\nu}) \rangle / P(x_{\nu}, t | x_{\gamma}^*, 0)$ , in the same spirit as (Falasco and Esposito, 2020). Second, we use the fact that for large V and large t the transition probability approaches the (local) stationary probability distribution at the saddle point  $x_{\nu}$ :

$$\lim_{t \to \infty} P(x_{\nu}, t | x_{\gamma}^*, 0) \simeq e^{-V[I_{ss}^{(\gamma)}(x_{\nu}) - I_{ss}^{(\gamma)}(x_{\gamma}^*)]} = p_{ss}^{(\gamma)}(x_{\nu}).$$
(A4)

But since the dual dynamics preserves the steady state  $p_{ss}^{(\gamma)}$ , we have that  $P^{\dagger}(x_{\nu}, t|x_{\gamma}^*, 0) = P(x_{\nu}, t|x_{\gamma}^*, 0)$  for large t. Hence, (A3) gives

$$1 \ge e^{-V\sigma_{\gamma \to \nu}^{\text{ad}}},\tag{A5}$$

which implies that the adiabatic entropy production of an instantonic trajectory is nonnegative:

$$\sigma_{\gamma \to \nu}^{\mathrm{ad}} := \frac{1}{p_{\mathrm{ss}}^{(\gamma)}(x_{\nu})} \lim_{t \to \infty} \lim_{V \to \infty} \left\langle \sigma^{\mathrm{ad}} \delta(c(0) - x_{\gamma}^{*}) \delta(c(t) - x_{\nu}) \right\rangle \ge 0.$$
(A6)

As in (A1), we have factored out the exponentially small probability  $p_{ss}^{(\gamma)} > 0$  of the instanton.

At this point we go back to the conditional average of the entropy production decomposition (115), and use (A6) and (A1) to write

$$\sigma_{\gamma \to \nu} \ge -\int_{x(0)=x_{\gamma}^{*}}^{x(\infty)=x_{\nu}} d_{\tau} I_{ss}^{(\gamma)}(x(\tau)) d\tau$$

$$= -I_{ss}^{(\gamma)}(x_{\nu}) + I_{ss}^{(\gamma)}(x_{\gamma}^{*}). \tag{A7}$$

Multiplying by V and exponentiating, we finally obtain the upper bound (160) on the transition rate  $\kappa_{\nu}$ .

We conclude by pointing out that integrating the entropy production between fixed points gives a diverging quantity – unless detailed balance holds – because relaxation (and instantonic) trajectories have infinite duration. This is traced back to the Laplace approximation (107), which is valid for states c at which the noise is small in comparison to the drift field F(c). This assumption breaks down on fixed points, in which the drift field

<span id="page-49-1"></span>is null. Clearly, one should consider boundary conditions that belong to the boundary of a ball centered on the fixed point with a radius of the order of the Gaussian fluctuations  $O(V^{-1/2})$ . Inside any such ball the weak-noise limit breaks down<sup>18</sup>. Changing the integration boundaries in this way introduces in the left hand side of (A7) a correction of order O(1/V) (since  $\partial_c I_{ss}^{\gamma}$  is zero on every fixed point), hence a subexponential correction to  $\kappa_{\nu}$ , but makes  $\sigma_{\gamma \to \nu}$  and  $\sigma_{\nu \to \gamma}$  finite by discarding the entropy produced at the fixed point. Using (22), for which all the above derivations can be repeated, rather than the thermodynamic entropy production is an alternative approach to remove the divergence (without tuning the integration boundaries) and thus tighten the bounds.

### <span id="page-49-0"></span>Appendix B: Derivation of the emerging transition rates

We give a formal derivation of the relation (157) along the lines of the proof developed in (Bouchet and Reygner, 2016) for diffusive dynamics. We consider an autonomous system initially localized in a basin of attraction  $\gamma$ , and place absorbing boundary conditions in the neighborhood of the saddle points  $x_{\nu}$ . For times much smaller than the escape time from the basin (which we wish to determine) the system probability density  $p_{\rm abs}(c,t)$  coincides with  $p_{\rm ss}^{(\gamma)}(c) \approx e^{-VI_{\rm ss}^{(\gamma)}(c)}$  for all c in the basin but on a tiny boundary layer, of linear size  $O(V^{-1/2})$ , around the saddles  $x_{\nu}$ . To quantify how probability mass gets removed we thus introduce the survival probability, the monotonic decreasing function (Redner, 2001)

<span id="page-49-6"></span>
$$\mathcal{P}_{\text{surv}}(t) = \int dc \, p_{\text{abs}}(c, t),$$
 (B1)

<span id="page-49-2"></span>that we wish to express in terms of the total escape rate  $\kappa$  from the attractor. In general the survival probability depends on all eigenvalues of the master equation operator with absorbing boundary conditions (Freitas et al., 2022a). But in presence of metastability (see Sec. III.B) only the largest contributes,  $-\kappa$ , unless  $t \to 0$ . This means that escape events are exponentially distributed in the limit  $V \to \infty$ , i.e.,  $\mathcal{P}_{\text{surv}}(t) = e^{-\kappa t}$  (Day, 1983). Moreover, we assume that the saddles are well separated and so contribute independently to the escape rate as  $\kappa = \sum_{\nu} \kappa_{\nu}$ . The evolution of the survival probability can be deduced from the master equation

<span id="page-49-5"></span>
$$\partial_t p_{\text{abs}}(c,t) = -\partial_c \cdot \mathbf{j}_{\text{abs}}(c,t)$$
 (B2)

<span id="page-49-4"></span>with absorbing conditions  $p_{abs}(x_{\nu}, t) = 0$ . Integrating (B2) over the basin of attraction, using (B1) and the

<span id="page-49-3"></span><sup>&</sup>lt;sup>18</sup> A rigorous treatment that includes subexponential corrections would require the use of a boundary layer approximation (Schuss, 2009)

divergence theorem, we obtain

$$\mathcal{P}_{\text{surv}}(t) \sum_{\nu} k_{\nu} = \sum_{\nu} \mathfrak{j}_{\text{abs}}(x_{\nu}, t) \cdot \hat{e}(x_{\nu}) \Delta \mathcal{S}$$
 (B3)

where  $\Delta \mathcal{S}$  is a small surface element of the boundary of the basin and  $\hat{e}(x_{\nu})$  is the local outward unit vector. Using the definition of probability current  $\mathbf{j}_{abs}(c,t) = \langle \dot{c}(t)\delta(c(t)-c)\rangle$ , we can write (B3) for  $V \to \infty$ 

$$j_{\text{abs}}(x_{\nu}, t) = \dot{c}(t)p_{\text{abs}}(x_{\nu}, t), \tag{B4}$$

with  $\dot{c}(t)$  the velocity of the typical escape path in a neighborhood of the saddle. Equation (B3) is valid

<span id="page-50-0"></span>in particular at times much shorter than  $1/\kappa$  when  $\mathcal{P}_{\rm surv}(t\ll 1/\kappa)\simeq 1$  and  $p_{\rm abs}(c,t\ll 1/\kappa)\asymp p_{\rm ss}^{(\gamma)}(c)$  is indistinguishable from the local stationary probability (110) at leading order (Bouchet and Reygner, 2016). Therefore, discarding subexponential contributions, (B3) reads

$$\sum_{\nu} k_{\nu} \approx \sum_{\nu} e^{-V[I_{\rm ss}^{(\gamma)}(x_{\nu}) - I_{\rm ss}^{(\gamma)}(x_{\gamma}^{*})]},$$
 (B5)

which gives (157) under the hypothesis of independent escape paths through each separate saddle point.