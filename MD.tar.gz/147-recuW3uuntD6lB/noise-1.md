### **MARINE ECOLOGY**

# Fairy circle landscapes under the sea

Daniel Ruiz-Reynés,<sup>1</sup> Damià Gomila,<sup>1</sup>\* Tomàs Sintes,<sup>1</sup> Emilio Hernández-García,<sup>1</sup> Núria Marbà,<sup>2</sup> Carlos M. Duarte<sup>3</sup>

Short-scale interactions yield large-scale vegetation patterns that, in turn, shape ecosystem function across landscapes. Fairy circles, which are circular patches bare of vegetation within otherwise continuous landscapes, are characteristic features of semiarid grasslands. We report the occurrence of submarine fairy circle seascapes in seagrass meadows and propose a simple model that reproduces the diversity of seascapes observed in these ecosystems as emerging from plant interactions within the meadow. These seascapes include two extreme cases, a continuous meadow and a bare landscape, along with intermediate states that range from the occurrence of persistent but isolated fairy circles, or solitons, to seascapes with multiple fairy circles, banded vegetation, and "leopard skin" patterns consisting of bare seascapes dotted with plant patches. The model predicts that these intermediate seascapes extending across kilometers emerge as a consequence of local demographic imbalances along with facilitative and competitive interactions among the plants with a characteristic spatial scale of 20 to 30 m, consistent with known drivers of seagrass performance. The model, which can be extended to clonal growth plants in other landscapes showing fairy rings, reveals that the different seascapes observed hold diagnostic power as to the proximity of seagrass meadows to extinction points that can be used to identify ecosystems at risks.

Copyright © 2017
The Authors, some rights reserved; exclusive licensee
American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative
Commons Attribution
NonCommercial
License 4.0 (CC BY-NC).

#### INTRODUCTION

The spatial organization of vegetation landscapes is a key factor in assessment of ecosystem health and functioning (1-4). Spatial configurations of vegetation landscapes act as potential indicators of climatic or human forcing affecting the ecosystem (2) and determine energy and material budgets and feedbacks across space (2, 4-6). In addition, although vegetation tends to cover all available ground under favorable conditions, plant distributions can spontaneously develop spatial inhomogeneities under resource limitation, acting as ecosystem engineers that modify the fluxes of nutrients and water to improve their growth conditions (4,7). Hence, the spatial organization of vegetation landscapes provides an indicator of the existence of stressing factors and the proximity of critical thresholds leading to irreversible losses (4,8).

The processes conducive to different dynamics of vegetation landscapes have been assessed in habitats ranging from arid ecosystems and savannahs to forests and wetlands (1, 2, 4). The most striking patterns have been reported in drylands, where competition for water leads to self-organized vegetation patchiness (9-13), including the appearance of the so-called fairy circles, whose origin has stirred significant controversy (12, 14-17). These are bare circular patches surrounded by grass, which appear, for example, in regions of the grassy deserts of Namibia (14) and Australia (16) and have been used as a basis to formulate a theory of self-organization of vegetation landscapes in water-limited ecosystems.

Although self-organized patchiness and pattern formation are well documented in terrestrial ecosystems, their occurrence in marine environments has attracted much less attention. Fairy circle–like structures have been reported in seagrass meadows, such as Mediterranean *Posidonia oceanica* (18, 19) and *Zostera marina* in the Danish Kattegat (20). Complex landscapes, such as bare seascapes dotted with plant patches, termed

<sup>1</sup>IFISC (Instituto de Física Interdisciplinar y Sistemas Complejos) [Universidad Illes Baleares–Consejo Superior de Investigaciones Científicas (UIB-CSIC)], Campus Universitat Illes Balears, 07122 Palma de Mallorca, Spain. <sup>2</sup>Department of Global Change Research, IMEDEA (Mediterranean Institute for Advanced Studies) (UIB-CSIC), Miquel Marqués 21, 07190 Esporles, Spain. <sup>3</sup>King Abdullah University of Science and Technology, Red Sea Research Center, Thuwal 23955-6900, Saudi Arabia. \*Corresponding author. Email: damia@ifisc.uib-csic.es

"leopard skin" (21), and striped vegetation patterns (22, 23), have also been studied. However, inspection of satellite images and side-scan cartography reveals that complex seascapes are abundant in meadows of *P. oceanica*, suggesting that self-organized submarine vegetation patterns may be prevalent but have remained thus far largely hidden under the sea. Obviously, the mechanisms responsible for the formation of these submarine fairy circle landscapes must be necessarily different than those operating in water-limited ecosystems on land (12, 14, 16). Although there are some hypotheses of possible mechanisms in several marine ecosystems (23–26), there is only a partial understanding of the phenomenon in *P. oceanica* meadows.

With a global distribution along the shorelines of all continents except Antarctica, seagrass meadows are valuable ecosystems that provide valuable ecosystem services (27); but they rank among the most threatened ecosystems globally (28). P. oceanica is the dominant seagrass in the Mediterranean Sea, where it forms underwater meadows that support great biodiversity, are a site of intense CO<sub>2</sub> sequestration, and offer shoreline protection (29, 30). Unfortunately, this ecosystem is affected by multiple anthropogenic impacts, including reduced water quality and physical impacts, that have led to a loss of 6.9% per year over the past 50 years (30). Although P. oceanica is a strongly clonal plant propagating through rhizome growth, its very slow horizontal spread of a few centimeters per year implies that losses are essentially irreversible over managerial time scales (30).

Here, we report that inspection of side-scan sonar cartography of seagrass meadows (*P. oceanica* and *Cymodocea nodosa*) in Mallorca Island (Western Mediterranean) reveals that vegetation patterns of holes and spots spanning over many kilometers are prevalent along the coastline of the Balearic Islands (see Fig. 1A) (*31*). We also present a simple, parsimonious model of clonal plant growth yielding self-organized submarine vegetation patterns that encompass the diversity of seascapes observed.

#### **RESULTS**

Sintes et al. (32, 33) developed a model, based on a limited set of simple rules underpinning clonal growth, successfully reproducing seagrass growth: First, the growing apex of seagrass rhizomes elongates in a fixed

![](_page_1_Figure_2.jpeg)

![](_page_1_Figure_3.jpeg)

**Fig. 1.** Examples of fairy circles and spatial patterns in Mediterranean seagrass meadows. (A) Side-scan image of a seagrass meadow in Pollença bay (Mallorca Island, Western Mediterranean) from LIFE Posidonia (*31*) showing different patterns in meadows of *P. oceanica* and *C. nodosa*. Other examples are shown in figs. S9 to S11. (B) Image of a fairy circle in a *P. oceanica* meadow in the Adriatic Sea as seen from the coast. Photography by Zvaqan is available in Google Street View and (C) the same fairy circle in a satellite image of Google maps (44°05'37.5"N, 14°55'37.6"E). Other fairy circles can be found at the following locations: 44°04'01.8"N, 14°57'53.3"E and 39°08'48.2"N, 2°56'07.1"E.

horizontal direction with a velocity  $\nu$ , leaving new shoots behind, which are separated along the rhizome by a typical distance  $\rho$ . Second, the growing apex develops new branches at a rate  $\omega_b$ , with these branches elongating into a horizontal direction at an angle  $\varphi_b$  from the original rhizome. Living shoots have a typical lifetime, depending on external factors and the presence of neighboring shoots, resulting in a per capita mortality rate  $\omega_d$ . If  $\omega_d < \omega_b$  at a given position, the density of shoots will increase locally. The typical value of each parameter is a characteristic feature of each species with some variability driven by genetic and environmental conditions (32).

We have scaled up this model (originally conceived to describe patch development) to landscape scale by coarse-graining it to describe the dynamics of the shoot,  $n_s$ , and apex,  $n_a$ , densities. Total shoot density

 $n_{\rm b}$  is calculated as the sum of shoots and apices growing in all directions. This model, which we call the "Advection-Branching-Death" (ABD) model, includes rhizome growth in different directions, contributions from rhizome branching, and shoot death. Shoot mortality rates are density-dependent as well as dependent on environmental factors (for example, resource availability). More specifically, three terms contribute to the total mortality

$$\omega_{\rm d}[n_{\rm t}(\vec{r},t)] = \omega_{\rm d0} + bn_{\rm t}^2 + \iint \mathcal{K}(\vec{r} - \vec{r}')(1 - e^{-an_{\rm t}(\vec{r}')})d\vec{r}'$$
 (1

On the one hand, the intrinsic mortality rate,  $\omega_{d0} > 0$ , of an individual shoot at a particular position in the landscape depends on environmental factors, and on the other hand, on two density-dependent terms: local saturation and nonlocal interaction. The saturation term  $bn_t^2$  is nonlinear and prevents an unlimited growth, increasing mortality locally when the density increases excessively. The strength b of this density-dependent term reflects the environmental carrying capacity, determining the maximum density in the meadow. Nonlocal interactions are included through an integral term accounting for the interaction of shoots at position  $\vec{r}$  with those in a neighborhood weighted by the kernel  $\mathcal{K}(\vec{r}-\vec{r}')$ . Through nonlocal interactions, the abundance of shoots in a place can affect the growth in a neighborhood. The model therefore includes two essential components to yield self-organization: nonlinearity and spatial interaction.

The three terms in Eq. 1 are consistent with the current functional understanding of seagrass meadows. The intrinsic mortality rate of individual shoots, determining  $\omega_{d0}$ , depends on external factors such as temperature and irradiance regimes (34). Local density dependence results from self-shading, determining the maximum density of shoots for a given plant size (35) and the general decline in seagrass density and biomass with depth (36), as well as local depletion of other resources, such as CO<sub>2</sub>, which is depleted during daytime in dense meadows (37). Nonlocal interactions integrate a number of facilitative and competitive mechanisms. Facilitative interactions arise, for instance, in the form of stress amelioration, when the presence of neighboring plants dissipates wave energy, which may prevent shoot removal from scouring of waves within the meadow (38) and contributes to stabilize and trap sediments (39). Facilitation has been argued to play a role in shaping seagrass landscapes (40, 41). Negative interactions appear, for instance, as a result of anaerobic microbial decomposition in dense meadows, which leads to diffusing sulfide fronts that spread mortality, leading to the appearance of fairy rings (20). Competition can arise also from depletion of nutrients from the flow by plants up-current (42) or of other diffusing resources, such as CO<sub>2</sub>.

Hence, existing evidence suggests intraspecific facilitation and competitive nonlocal interaction whose precise ranges are difficult to determine. As a result of these interactions, the meadow can self-organize enhancing facilitative effects and diminishing competition, altering the environment to yield more favorable growth conditions.

We consider a kernel  ${\cal K}$  with two terms of Gaussian shape

$$\mathcal{K}(\vec{r}) = \kappa \mathcal{G}(\sigma_{\kappa}, \vec{r}) - \mu \mathcal{G}(\sigma_{\mu}, \vec{r}) \tag{2}$$

where  $\kappa > 0$  is the strength of the competitive interaction with width  $\sigma_{\kappa}$ , and  $\mu > 0$  is the strength of facilitation with width  $\sigma_{\mu}$ , where the widths of the Gaussians correspond to the spatial extension of the interactions. Note that we should have  $\mu \leq \omega_{d0}$  to guarantee positive mortality. For simplicity, in the following, we take  $\mu = \omega_{d0}$ . As a result of the two

Gaussians with different widths and signs, the kernel has the shape of an inverted Mexican hat, and the interaction is stronger at short distances, decaying very fast with  $|\vec{r}|$ .

Competition or facilitation may dominate at shorter or longer distances depending on the values of  $\sigma_{\kappa}$  and  $\sigma_{\mu}$ . On general grounds, the main effect of facilitation is to permit the coexistence of the populated and unpopulated homogeneous states, whereas nonlocal competition is one of the mechanisms responsible for the spontaneous formation of regular patterns, either on itself (43) or acting together with the facilitative interaction (4). Thus, observation of spatial patterns suggests the existence of nonlocal competitive interactions. Selecting  $\sigma_{\kappa} > \sigma_{\mu}$  results in a kernel that is weakly competitive at large distances, yielding to a suitable nonlocal interaction for pattern formation (see the Supplementary Materials) (4). The main nonlocal interaction terms ( $\kappa$ ,  $\sigma_{\kappa}$ ,  $\mu$ , and  $\sigma_{\mu}$ ) can be inferred from the comparison of numerical simulations and observed patterns, whereas seagrass growth parameters are largely known [see the study by Sintes *et al.* (33) and references therein].

The ABD model yields a great diversity of complex spatial patterns emerging at different parameter regions, including nonlinear phenomena resulting in the coexistence of different solutions, which are shown in Fig. 2 for the case of constant  $\omega_{d0}$  and b. When mortality is high  $(\omega_{d0}/\omega_b>>1)$ , the only possible solution is bare soil, the unpopulated solution. Decreasing the mortality (or increasing branching rate), the unpopulated solutions become unstable at a threshold  $\omega_{d0}/\omega_b=1$ . Below this mortality, any small nonzero density will grow to form a meadow. If mortality is much smaller than the branching rate,  $\omega_{d0}/\omega_b <<1$ , the vegetation will uniformly cover all the available space. Thus, there are two

![](_page_2_Figure_5.jpeg)

Fig. 2. Mean shoot density  $\overline{n}_t$  (that is, total number of shoots divided by the whole simulation area) as a function of normalized mortality  $\omega_{\text{d0}}/\omega_{\text{b}}$  for five different solutions of the ABD model for homogeneous  $\omega_{\text{d0}}$  and homogeneous b. Homogeneous populated and unpopulated states are shown in red, hexagonal arrangement of fairy circles in yellow, stripes in green, and hexagonal arrangement of spots in blue. Solid (dashed) lines indicate stable (unstable) solutions. The insets show the vegetation patterns in the inhomogeneous cases. Only the stable part of the pattern branches is shown, as obtained from direct numerical simulations of the model. MI corresponds to the modulational instability of the populated state, and T corresponds to the transcritical bifurcation of the bare soil. We take parameter values in a range that reproduce patterns seen in side scans using typical values for P. oceanica for the parameters already known [see the study by Sintes et al. (33) and references therein]:  $\omega_b = 0.06 \text{ year}^{-1}$ , v = 6.11 cmyear<sup>-1</sup>,  $\rho$  = 2.87 cm,  $\phi$ <sub>b</sub> = 45°, b = 1.25 cm<sup>4</sup> year<sup>-1</sup>,  $\kappa$  = 0.048 year<sup>-1</sup>,  $\sigma$ <sub> $\kappa$ </sub> = 2851.4 cm,  $a=27.38~{\rm cm}^2$ ,  $\sigma_{\rm u}=203.7~{\rm cm}$ ,  $\mu=\omega_{\rm d0}$  (see the Supplementary Materials). The formation of the three patterned solutions (negative hexagons, stripes, and positive hexagons) is shown in movies S1, S2, and S3, respectively.

extreme homogeneous stable states: a uniform, continuous meadow  $(\omega_{d0}/\omega_b < < 1)$  and bare seafloor, with no vegetation  $(\omega_{d0}/\omega_b > > 1)$ , as it is shown in Fig. 2 (red solid lines). The parameter values that better reproduce the observed patterns of *P. oceanica* meadows correspond to a kernel  $\mathcal K$  that, although competition extends farther, is overall facilitative. As a result, the transition (T) from bare soil to the populated solution is subcritical, so that there is a mortality range in which both populated and unpopulated solutions coexist (Fig. 2). Competition between shoots can destabilize the populated solution, leading to patterns, whereas the homogeneous states are the only possible solutions in the absence of nonlocal interactions. Therefore, the presence of fairy circle landscapes in seagrass meadows is indirect evidence of nonlocal negative interactions.

A linear stability analysis of the homogeneous populated solution reveals that it undergoes a finite wavelength instability, also known as Turing (4) or modulation instability (MI), at a critical value of mortality rate  $\omega_{d0} = \omega_{d0}^c$  (in Fig. 2,  $\omega_{d0}^c/\omega_b = 1.34$ ), leading to the emergence of complex spatial patterns. Above this mortality, any small perturbation to the homogeneous meadow is enough to trigger a feedback process driving the vegetation to form an inhomogeneous pattern. Different spatial structures are possible. As mortality rate increases, possible patterns shift from negative hexagons (holes arranged in a hexagonal pattern), to stripes, and to positive hexagons (spots of vegetation arranged in a hexagonal pattern), as expected from the general theory of pattern formation (44, 45). Each solution is stable in a different region of parameter space, and two different solutions can be simultaneously stable for the same value of the mortality, a coexistence between solutions that would give rise to hysteresis. In particular, negative hexagons coexist with the homogeneous populated solution in a mortality range below  $\omega_{do}^{c}$ . In part of this region, a single bare hole embedded in a dense meadow (Fig. 3), known as dissipative soliton (46), which is the submarine analog of a terrestrial fairy circle, can be stable (47, 48). Many of the bare circles visible in the coasts of Mallorca and the Adriatic Sea (Fig. 1) can be identified with dissipative solitons.

Thus, our model is able to reproduce and to facilitate understanding of the nonlinear behavior, leading to the emergence of dynamic complex landscape patterns in seagrass meadows. The spatial scale of real patterns is mainly related to the range of the competing interaction  $\sigma_{\kappa}$ . An estimation of the length scale of the observed patterns can be obtained using the Fourier spectrum (see the Supplementary Materials) of images such as Fig. 1A. It is not always possible to obtain a precise estimate of this length scale, because often, patterns are not regular enough, although local hexagonal ordering can be appreciated in the more regular regions. In these regions, one can identify in the Fourier spectrum a typical periodicity of  $62.9 \pm 12.7$  m (see the Supplementary Materials). Choosing  $\sigma_{\kappa}$  = 28.5 m, the critical wavelength at the MI threshold (see the Supplementary Materials) fits this observed characteristic length, and simultaneously, a typical hole size of about 30 m is also correctly reproduced. This result allows us to conjecture the existence of a competitive interaction with a range of around 20 to 30 m, whose specific nature is not yet known. In addition to their local contribution, the competition for natural resources (for example, dissolved inorganic nutrients or CO<sub>2</sub>) and the interactions mediated by toxic compounds, such as sulfide, which is accumulated in the soil (20), are expected to contribute to nonlocal competitive interactions. Other hypotheses include interaction through hydrodynamics, which may modify the sedimentary delivery of nutrients.

The time scales for the landscape dynamics captured by the model are long, encompassing decades to millennia (movies S1 to S5 and the Supplementary Materials), depending on the characteristic demographic

![](_page_3_Figure_2.jpeg)

Fig. 3. Spatial distribution of the shoot density (high densities are represented in dark green and low ones in bright yellow) in a simulation of a *P. oceanica* meadow showing a stable fairy circle. The fairy circle, or dissipative soliton, is clear in the density profile (**B**) along the transverse cut shown in (**A**) by a dashed line. Here,  $\omega_{d0} = 0.057 \text{ year}^{-1}$ . Other parameters are the same as in Fig. 2.

time scales of the species. For instance, *P. oceanica* clones are long-lived organisms, with clones living tens of thousands of years (49) and forming meadows over centuries to millennia (50, 51), whereas *C. nodosa* grows much faster and can form meadows over decades to centuries (50). Hence, the dynamics conducive to formation of complex landscape patterns and the transition between them are too slow to be observed empirically and can be grasped only through a modeling approach, such as the one developed here (movies S1 to S6), with parameter values properly constrained by present-day observations.

In addition to providing qualitative understanding of how demographic imbalances affect the spatial configuration of seagrass meadows, the model proposed provides a remarkable, given its parsimony, description of observed patterns in seagrass meadows (Fig. 4). Two additional model components are needed to reproduce observed density patterns: a decline in mortality rate,  $\omega_{d0}$ , with the distance from the coast, x, and a spatial random noise term that mimics irregular spatial variability of the parameters. Simulations in small systems and under ideal conditions (that is, in the absence of noise) may yield perfectly periodic patterns (insets in Fig. 2), whereas simulations in large domains, including noise, better resemble observed patterns (Figs. 4 and 5, movies S4 to S6, and the Supplementary Materials).

The increase in area coverage from the shore toward moderate depths is characteristic of *P. oceanica* meadows (Fig. 4C) [as is also the its decrease and disappearance toward deep waters; (36)]. This indicates high mortality rates in shallow, nearshore waters, which could be attributed to scouring by waves, leading to the unpopulated model solution in waters shallower than the upslope limit of the seagrass, and low mortality rates in moderately deeper waters, allowing the formation of stable homogeneous meadows. A smooth decline in mortality with depth should then lead to complex spatial patterns at intermediate depths, where the homogeneous solution is unstable (see Fig. 2). Including such decline in mortality (Fig. 4B) with added noise (see the Supplementary Materials), the resulting patterns (Fig. 4A) accurately reproduce observed features in P. oceanica meadows (Fig. 4C), such as more elongated vegetation gaps near the shore and scattered gaps close to the homogeneous meadow. The transition from bare soil to patterns with elongated gaps signals that this region experiences a steep

mortality decrease from very high to moderate values where hexagons begin to be unstable with respect to stripes. Scattered gaps are well reproduced close to the homogeneous meadow, in a mortality range where hexagonal gap patterns coexist with the homogeneous populated state (see Fig. 2) and dissipative solitons (fairy circles) can form. Further downslope, the homogeneous meadow prevails.

The model also reproduces the decline of shoot density and its variability with depth observed in meadows along the littoral of the Balearic Islands (Fig. 4H). Shoot density was measured by scuba divers at random positions in the meadows without previous knowledge of their spatial distribution. The results consistently showed low shoot density variability at depths >10 m compared to high variability at shallower depths (<10 m), ranging from close to 0 to 2000 shoots/m<sup>2</sup>, a variability much larger than that in deeper regions (thick blue dots Fig. 4H). Our model suggests that high shoot density variability in shallow waters is a consequence of the presence of complex spatial patterns near the coast. Simulations using noisy and depth-dependent mortality and carrying capacity, b(x, y) (see Fig. 4G), account for the decrease in shoot density with depth and generate patterns of shoot density that capture the dispersion of the density close to the coast where patterns form (Fig. 4, E to H, and movie S5). The model also reproduces complex patterns in meadows of C. nodosa, such as the transition from holes to patches observed in one of the meadows (Figs. 1 and 5C). Because this transition occurs parallel to the coast, that is, at a uniform depth, we inferred this pattern to be derived from a sudden increase in the mortality rate along the shore (see Fig. 5B). The resulting simulated pattern (Fig. 5A) reproduces very well the observed features of the real meadow, further confirming that the complex seascape of fairy circle patterns observed in Mediterranean seagrass meadows can be reproduced parsimoniously as a consequence of variability in the seagrass demographic balance caused by spatial interaction and nonlinearity.

#### DISCUSSION

We have demonstrated that complex landscape patterns, such as those dotted by fairy circles characteristic of arid grasslands, are also common features of seagrass seascapes in the Mediterranean and have also been

![](_page_4_Figure_2.jpeg)

**Fig. 4.** Comparison of numerical simulations with patterns observed in seagrass meadows. (A) Final spatial density distribution of shoots from a numerical simulation of the ABD model that uses the mortality profile plotted in (B). (C) Observed coverage (31) of *P. oceanica* from LIFE Posidonia side-scan cartography in the Balearic coast area limited by the following coordinates:  $39^{\circ}45'54.1''N$ ,  $3^{\circ}09'49.5''E$ ;  $39^{\circ}47'25.6''N$ ,  $3^{\circ}11'48.7''E$ ;  $39^{\circ}47'48.6''N$ ,  $3^{\circ}11'19.0''E$ ; and  $39^{\circ}46'17.1''N$ ,  $3^{\circ}09'19.9''E$ . (D) Depth in that region averaged along the *y* direction. (E to H) Comparison of a numerical simulation with field density measures: (E) Spatial density distribution of *P. oceanica* as obtained from numerical simulations with a custom spatially dependent mortality [orange line in (G), left scale] and a profile of the saturation strength b(x, y) [blue line in (G), right scale]. (F) Cut of (E) at y = 102. (H) Observed *P. oceanica* density measured by scuba divers (in blue, data file S1) as function of the depth for different locations spread over the coastline of the Balearic Islands and the density in random locations of the numerical simulation shown in (E) (gray). Parameters are same as in Fig. 2. The time evolutions of the simulations are shown in movies S4 and S5.

![](_page_4_Figure_4.jpeg)

Fig. 5. Comparison of numerical simulation with patterns observed by sidescan sonar (31) for a region of coexistence between holes and patches in a meadow of C. nodosa in Mallorca Island (Fig. 1). The set of model parameters for C. nodosa is  $\omega_b=2.3~{\rm year}^{-1}$ ,  $\nu=160~{\rm cm~year}^{-1}$ ,  $\rho=3.7~{\rm cm}$ ,  $\phi_b=45^{\circ}$ ,  $b=112.71~{\rm cm}^4~{\rm year}^{-1}$ ,  $\kappa=2.76~{\rm year}^{-1}$ ,  $\sigma_\kappa=2226.1~{\rm cm}$ ,  $a=21.0~{\rm cm}^2$ ,  $\sigma_\mu=139.1~{\rm cm}$ , and  $\mu=\omega_{d0}$ , and the area modeled (a subset of that shown in Fig. 1A) is bounded by the coordinates 39°53′16.4″N, 3°05′12.7″E; 39°51′52.0″N, 3°06′15.7″E; 39°51′43.1″N, 3°05′55.6″E; and 39°53′07.5″N, 3°04′52.6″E (movie S6). (A) Final spatial density distribution of shoots from a numerical simulation of the ABD model using the mortality profile shown in (B). (C) Observed coverage (31) of C. Nodosa from LIFE Posidonia side-scan cartography in the Balearic coast.

reported in seagrass meadows elsewhere (20-22, 27). The parsimonious model developed here demonstrates that fairy circle seascapes emerge as consequences of nonlinearity and spatial interactions in seagrass meadows at critical levels of demographic imbalances, typically met in relatively shallow nearshore areas of seagrass meadows. In contrast, comparatively low mortality rates in deeper areas lead to a prevalence of stable continuous meadows toward the deeper ranges of seagrass meadows. The model developed here, based on simple inherent growth traits of the seagrass species and variable mortality due to nonlocal interaction and nonlinearity, is able to reproduce the range of complex landscape configurations, including striped, hexagon, and solitondominated landscapes encountered between the bare sediments and continuous meadow end members for these landscapes. The model results are robust enough as to allow inferences on the demographic status of the meadows on the basis of observed landscape configurations. In particular, positive hexagons signal the proximity of tipping points where further increase in seagrass mortality relative to growth may lead to catastrophic loss of seagrass meadows (1, 52). Because seagrass ecosystems rank among the most threatened ecosystems globally (28), the capacity to diagnose the proximity of seagrass meadows to tipping points for catastrophic loss based on landscape configurations provides a tool to guide conservation measures aimed at preventing further losses.

#### **MATERIALS AND METHODS**

### **Derivation of the ABD model**

Focusing on the three main mechanisms involved in the growth of clonal plants, namely, apices' linear growth, branching, and death, we developed

a set of partial differential equations (PDEs; or, more precisely, integro-differential equations) for the density of shoots and apices. These mechanisms were identified and implemented in a previous model, which focused on individual shoots (32, 33). Here, we formulated these mechanisms in terms of upscaled continuous densities, thus allowing for the description of much larger spatial and temporal scales. The spatial density of shoots at position  $\vec{r}=(x,y)$  of the sea bottom at time t is  $n_s(\vec{r},t)$ , and the density of apices growing in the direction given by the angle  $\phi$  is  $n_a(\vec{r},\phi,t)$ . Note that the magnitude of the apices' growth velocity v is assumed constant, and a growth velocity vector can be written as  $\vec{v}(\phi)=(v\cos\phi,v\sin\phi)$ . The total density of shoots,  $n_t$ , considering for simplicity that an apex is carrying a shoot, is the sum of shoots  $n_s$  and apices  $n_a$  growing in all directions,  $n_t(\vec{r},t)=n_s(\vec{r},t)+\int_0^{2\pi}n_a(\vec{r},\phi,t)d\phi$ .

Two PDEs describing the evolution of the densities of shoots and apices can be derived in terms of the contributions of the three growth mechanisms to the number of shoots in an infinitesimal surface. First, the number of apices growing in direction  $\phi$  at t+dt in an infinitesimal surface of area dxdy located at  $\vec{r}$  will be the sum of two contributions: (i) the apices that remain alive coming from  $\vec{r} - \vec{v}(\phi)dt$  because of rhizome elongation and (ii) new apices that appear because of branching from directions of growth  $\phi + \phi_b$  and  $\phi - \phi_b$ , which are the only directions contributing to the growth in direction  $\phi$ .  $\phi_b$  is the branching angle. Note that those apices that go away due to rhizome elongation are contributing to position  $\vec{r} + \vec{v}(\phi)dt$ . Then, we obtain

$$\begin{split} n_{a}(\vec{r},\phi,t+dt) dx dy &= (1-\omega_{d}dt) n_{a}(\vec{r}-\vec{v}dt,\phi,t) dx dy \\ &+ \frac{\omega_{b}dt}{2} (n_{a}(\vec{r},\phi+\phi_{b},t) \\ &+ n_{a}(\vec{r},\phi-\phi_{b},t)) dx dy \end{split} \tag{3}$$

where  $\omega_b$  and  $\omega_d$  are branching and death rates, respectively. Making a Taylor expansion of Eq. 3 and neglecting second-order terms and higher, we obtain

$$\begin{split} n_{\mathrm{a}}(\vec{r}, \phi, t) + \partial_{t} n_{\mathrm{a}}(\vec{r}, \phi, t) dt &= (1 - \omega_{\mathrm{d}} dt) n_{\mathrm{a}}(\vec{r}, \phi, t) - \vec{v} dt \cdot \vec{\nabla} n_{\mathrm{a}}(\vec{r}, \phi, t) \\ &+ \frac{\omega_{\mathrm{b}} dt}{2} (n_{\mathrm{a}}(\vec{r}, \phi + \phi_{b}, t) + n_{\mathrm{a}}(\vec{r}, \phi - \phi_{b}, t)) \end{split}$$

Rewriting Eq. 4, we obtain the PDE that describes the growth of apices in the direction  $\boldsymbol{\varphi}$ 

$$\begin{split} \partial_{t} n_{a}(\vec{r}, \phi, t) &= -\omega_{d} n_{a}(\vec{r}, \phi, t) - \vec{\nu}(\phi) \cdot \vec{\nabla} n_{a}(\vec{r}, \phi, t) \\ &+ \frac{\omega_{b}}{2} \left( n_{a}(\vec{r}, \phi + \phi_{b}, t) + n_{a}(\vec{r}, \phi - \phi_{b}, t) \right) \end{split} \tag{5}$$

where  $\vec{\nabla} = (\partial_x, \partial_y)$ .

The same procedure can be used to obtain the equation for the shoot density. The first contribution is the shoots that remain alive at the same position, and the second contribution is due to the apices that survive and go away in any direction leaving a shoot behind

$$n_{s}(\vec{r}, t + dt)dxdy = (1 - \omega_{d}dt)n_{s}(\vec{r}, t)dxdy + \frac{v}{\rho}dt(1 - \omega_{d}dt)\int_{0}^{2\pi}n_{a}(\vec{r}, \phi, t)dxdyd\phi$$
 (6)

where  $\rho$  is the distance between shoots.

Using the Taylor expansion and keeping first-order terms only, we have

$$n_{s}(\vec{r},t) + \partial_{t}n_{s}(\vec{r},t)dt = (1 - \omega_{d}dt)n_{s}(\vec{r},t) + \frac{\nu}{\rho}dt \int_{0}^{2\pi} n_{a}(\vec{r},\phi,t)d\phi$$
 (7)

which leads to the PDE for the shoot population density

$$\partial_t n_s(\vec{r},t) = -\omega_d n_s(\vec{r},t) + \frac{v}{o} \int_0^{2\pi} n_a(\vec{r},\phi,t) d\phi$$
 (8)

The time evolution of a meadow can then be described by two coupled PDEs, Eqs. 5 and 8, one for each population density. We name this set of two equations the ABD model.

The first term in Eqs. 5 and 8 corresponds to death of shoots and apices. The same death rate  $\omega_d$  is considered. The second term in Eq. 5 is an advection in the direction of the elongation  $\vec{\nu}(\phi)$  of the rhizome, describing the movement of the apices. The last term in Eq. 5 corresponds to the branching process. Finally, the second term in Eq. 8 accounts for the shoots left behind by the apices.

The death rate is given by

$$\omega_{\rm d}[n_{\rm t}(\vec{r},t)] = \omega_{\rm d0} + bn_{\rm t}^2 + \iint \mathcal{K}(\vec{r} - \vec{r}')(1 - e^{-an_{\rm t}(\vec{r}')})d\vec{r}' \quad (9)$$

$$\mathcal{K}(\vec{r}) = \kappa \mathcal{G}(\sigma_{\kappa}, \vec{r}) - \mu \mathcal{G}(\sigma_{\mu}, \vec{r})$$
 (10)

where  $\mu=\omega_{d0}$  for simplicity and  $\omega_{d0}>0$ . Both interaction terms in Eq. 10 are considered to have a Gaussian shape  $\mathcal{G}(\sigma,\vec{r})=e^{-r^2/(2\sigma^2)}/(\sigma^2 2\pi)$ , where  $r^2=x^2+y^2$ . Other kernels have been considered in the literature in different contexts (53), although qualitatively, the pattern formation feature does not depend strongly on the precise shape of the kernel (54, 55), provided it decays faster or equal than exponential (56). Figure S5 shows the form of the kernel used in this work.

Thus, the interaction is stronger for short distances and decreases exponentially fast with  $r^2$ . Because  $\mathcal{G}$  is normalized to 1, if  $\kappa > \omega_{d0}$  $(\kappa < \omega_{d0})$ , then the interaction is overall competitive (facilitative). Depending on the values of  $\sigma_{\kappa}$  and  $\sigma_{\mu}$ , competition or facilitation may dominate at short or long distances. The term  $(1 - e^{-an_t})$  can be expanded for low densities as  $(1 - e^{-an_t}) \simeq an_t$ , leading to the usual nonlocal term in Lotka-Volterra-like models (57). The exponential has been introduced to saturate the interaction strength for high densities, such that the mortality rate ω<sub>d</sub> cannot become negative because of the facilitative interaction leading to the local creation of plants, which is unreal because a new shoot can be created only through the growth of the rhizomes or a branching event. For low densities, then, parameter a multiplies the strength of the nonlocal interaction. However, the larger the parameter a, the faster the saturation of the interaction as the density grows. Varying a and  $\kappa$ , one can change the relative strength between competition and facilitation. Here, we chose a kernel that is facilitative at short ranges and competitive at larger scales (fig. S5).

#### **SUPPLEMENTARY MATERIALS**

Supplementary material for this article is available at http://advances.sciencemag.org/cgi/content/full/3/8/e1603262/DC1

Materials and Methods

fig. S1. Mean shoot density  $\overline{n}_t$  (that is, total number of shoots divided by the whole simulation area) as a function of normalized mortality  $\omega_{d0}/\omega_b$  for the supercritical case.

- fig. S2. Growth rate of perturbation with wave number ( $q_{xr}$ ,  $q_{y}$  = 0) close to the MI.
- fig. S3. Phase diagram of the ABD model for P. oceanica.
- fig. S4. Wavelength of the maximum growth rate as function of the competition range  $\sigma_\kappa$  for five different values of the intrinsic mortality  $\omega_{d0}.$
- fig. S5. Shape of the kernel  $\mathcal{K}(\vec{r})$  in real space (left) and Fourier space (right).
- fig. S6. Comparison of numerical simulations with patterns in real meadows in the absence of noise in the profile corresponding to the same conditions as those in Fig. 4 (A to D).
- fig. S7. Example of noise distribution used in the numerical simulations.
- fig. S8. Fourier transform of a side-scan cartography image of a rectangular region of a meadow of *P. oceanica*.
- fig. S9. Side-scan cartography of Pollença and Alcúdia bays (Mallorca Island, Western Mediterranean)
- fig. S10. Side-scan cartography of Llevant coast (Mallorca Island, Western Mediterranean).
- fig. S11. Side-scan cartography of Cap Enderrocat (Mallorca Island, Western Mediterranean). table S1. Coordinates of analyzed regions.
- table S2. Measured wavelength of the patterns.
- movie S1. Formation of negative hexagons.
- movie S2. Formation of stripes.
- movie S3. Formation of positive hexagons.
- movie S4. Temporal evolution of Fig. 4A.
- movie S5. Temporal evolution of Fig. 4 (E. F. and H).
- movie S6. Temporal evolution of Fig. 5A.

data file S1. *P. oceanica* density as function of the depth for different locations spread over the coastline of the Balearic Islands.

Reference (58)

#### REFERENCES AND NOTES

- M. Rietkerk, S. C. Dekker, P. C. de Ruiter, J. van de Koppel, Self-organized patchiness and catastrophic shifts in ecosystems. Science 305, 1926–1929 (2004).
- N. Barbier, P. Couteron, J. Lejoly, V. Deblauwe, O. Lejeune, Self-organized vegetation patterning as a fingerprint of climate and human impact on semi-arid ecosystems. *J. Ecol.* 94, 537–547 (2006).
- R. Sole, J. Bascompte, Self-Organization in Complex Ecosystems (Princeton Univ. Press, 2006)
- M. Rietkerk, J. Van de Koppel, Regular pattern formation in real ecosystems. Trends Ecol. Evol. 23, 169–175 (2008).
- 5. R. Lefever, O. Lejeune, On the origin of tiger bush. *Bull. Math. Biol.* **59**, 263–294 (1997).
- J. Thiery, J.-M. D'Herbes, C. Valentin, A model simulating the genesis of banded vegetation patterns in Niger. J. Ecol. 83, 497–507 (1995).
- E. Gilad, J. von Hardenberg, A. Provenzale, M. Shachak, E. Meron, A mathematical model of plants as ecosystem engineers. J. Theor. Biol. 244, 680–691 (2007).
- M. Scheffer, J. Bascompte, W. A. Brock, V. Brovkin, S. R. Carpenter, V. Dakos, H. Held, E. H. van Nes, M. Rietkerk, G. Sugihara, Early-warning signals for critical transitions. *Nature* 461, 53–59 (2009).
- J. Von Hardenberg, E. Meron, M. Shachak, Y. Zarmi, Diversity of vegetation patterns and desertification. *Phys. Rev. Lett.* 87, 198101 (2001).
- E. Meron, E. Gilad, J. von Hardenberg, M. Shachak, Y. Zarmi, Vegetation patterns along a rainfall gradient. Chaos Solitons Fractals 19, 367–376 (2004).
- E. Meron, Pattern-formation approach to modelling spatially extended ecosystems. *Ecol. Model.* 234, 70–82 (2012).
- C. Fernandez-Oto, M. Tlidi, D. Escaff, M. G. Clerc, Strong interaction between plants induces circular barren patches: Fairy circles. *Philos. Trans. A Math. Phys. Eng. Sci.* 372, 20140009 (2014).
- T. M. Scanlon, K. K. Caylor, S. A. Levin, I. Rodriguez-Iturbe, Positive feedbacks promote power-law clustering of Kalahari vegetation. *Nature* 449, 209–212 (2007).
- M. D. Cramer, N. N. Barger, Are Namibian "fairy circles" the consequence of selforganizing spatial vegetation patterning? PLOS ONE 8, e70876 (2013).
- N. Juergens, The biological underpinnings of Namib desert fairy circles. Science 339, 1618–1621 (2013).
- S. Getzin, H. Yizhaq, B. Bell, T. E. Erickson, A. C. Postle, I. Katra, O. Tzuk, Y. R. Zelnik, K. Wiegand, T. Wiegand, E. Meron, Discovery of fairy circles in Australia supports selforganization theory. *Proc. Natl. Acad. Sci.* 113, 3551–3556 (2016).
- C. E. Tarnita, J. A. Bonachela, E. Sheffer, J. A. Guyton, T. C. Coverdale, R. A. Long, R. M. Pringle, A theoretical foundation for multi-scale regular vegetation patterns. *Nature* 541, 398–401 (2017).
- V. Pasqualini, C. Pergent-Martini, G. Pergent, Environmental impact identification along the Corsican coast (Mediterranean sea) using image processing. *Aquat. Bot.* 65, 311–320 (1999).
- M. Bonacorsi, C. Pergent-Martini, N. Bréand, G. Pergent, Is Posidonia oceanica regression a general feature in the Mediterranean Sea? Mediterr. Mar. Sci. 14, 193–203 (2013).

- J. Borum, A. Løvendahl, R. H. Hasler-Sheetal, M. Pedersen, O. Pedersen, M. Holmer, Felgrass fairy rings: Sulfide as inhibiting agent. Mar. Biol. 161, 351–358 (2014).
- C. Den Hartog, The dynamic aspect in the ecology of seagrass communities. Thalassia Jugosl. 7, 101–112 (1973).
- M. Frederiksen, D. Krause-Jensen, M. Holmer, J. S. Laursen, Spatial and temporal variation in eelgrass (*Zostera marina*) landscapes: Influence of physical setting. *Aquat. Bot.* 78, 147–165 (2004)
- T. Van Der Heide, T. J. Bouma, E. H. van Nes, J. van de Koppel, M. Scheffer, J. G. Roelofs, M. M. Katwijk, A. J. Smolders, Spatial self-organized patterning in seagrasses along a depth gradient of an intertidal ecosystem. *Ecology* 91, 362–369 (2010).
- N. Marbà, C. M. Duarte, Coupling of seagrass (Cymodocea nodosa) patch dynamics to subaqueous dune migration. J. Ecol. 83, 381–389 (1995).
- N. Marbà, J. Cebrian, S. Enriquez, C. M. Duarte, Migration of large-scale subaqueous bedforms measured with seagrasses (*Cymodocea nodosa*) as tracers. *Limnol. Oceanogr.* 39, 126–133 (1994).
- M. J. Christianen, P. M. Herman, T. J. Bouma, L. P. Lamers, M. M. van Katwijk,
   T. van der Heide, P. J. Mumby, B. R. Silliman, S. L. Engelhard, M. van de Kerk, W. Kiswara,
   J. van de Koppel, Habitat collapse due to overgrazing threatens turtle conservation in marine protected areas. Proc. R. Soc. Lond. B Biol. Sci. 281, 20132890 (2014).
- 27. M. A. Hemminga, C. M. Duarte, Seagrass Ecology (Cambridge Univ. Press, 2000).
- M. Waycott, C. M. Duarte, T. J. B. Carruthers, R. J. Orth, W. C. Dennison, S. Olyarnik, A. Calladine, J. W. Fourqurean, K. L. Heck Jr., A. R. Hughes, G. A. Kendrick, W. J. Kenworthy, F. T. Short, S. L. Williams, Accelerating loss of seagrasses across the globe threatens coastal ecosystems. *Proc. Natl. Acad. Sci. U.S.A.* 106, 12377–12381 (2009).
- C. M. Duarte, T. Sintes, N. Marbà, Assessing the CO<sub>2</sub> capture potential of seagrass restoration projects. J. Appl. Ecol. 50, 1341–1349 (2013).
- N. Marbà, E. Díaz-Almela, C. M. Duarte, Mediterranean seagrass (*Posidonia oceanica*) loss between 1842 and 2009. *Biol. Conserv.* 176, 183–190 (2014).
- 31. We have used side-scan sonar cartography produced by the LIFE Posidonia project http://lifeposidonia.caib.es
- T. Sintes, N. Marbà, C. M. Duarte, G. A. Kendrick, Nonlinear processes in seagrass colonisation explained by simple clonal growth rules. Oikos 108, 165–175 (2005).
- T. Sintes, N. Marbà, C. M. Duarte, Modeling nonlinear seagrass clonal growth: Assessing the efficiency of space occupation across the seagrass flora. Estuaries Coasts 29, 72–80 (2006).
- C. M. Duarte, Temporal biomass variability and production/biomass relationships of seagrass communities. Mar. Ecol. Prog. Ser. 51, 269–276 (1989).
- C. M. Duarte, J. Kalff, Latitudinal influences on the depths of maximum colonization and maximum biomass of submerged angiosperms in lakes. *Can. J. Fish. Aquat. Sci.* 44, 1759–1764 (1987).
- 36. C. M. Duarte, Seagrass depth limits. Aquat. Bot. 40, 363–377 (1991).
- O. Invers, J. Romero, M. Pérez, Effects of ph on seagrass photosynthesis: A laboratory and field assessment. Aquat. Bot. 59, 185–194 (1997).
- D. Patriquin, "Migration" of blowouts in seagrass beds at barbados and carriacou, west indies, and its ecological and geological implications. *Aguat. Bot.* 1, 163–189 (1975).
- J. Gutiérrez, C. G. Jones, J. E. Byers, K. K. Arkema, K. Berkenbusch, J. A. Commito, C. M, Duarte, S. D. Hacker, J. G. Lambrinos, I. E. Hendriks, P. J. Hogarth, M. G. Palomo, C. Wild, Physical ecosystem engineers and the functioning of estuaries and coasts, in *Treatise on Estuarine and Coastal Science* (Elsevier, 2011), pp. 53–81.
- M. S. Fonseca, M. A. R. Koehl, B. S. Kopp, Biomechanical factors contributing to selforganization in seagrass landscapes. J. Exp. Mar. Biol. Ecol. 340, 227–246 (2007).
- C. Boström, E. L. Jackson, C. A. Simenstad, Seagrass landscapes and their effects on associated fauna: A review. Estuar. Coast. Shelf Sci. 68, 383–403 (2006).
- C. D. Cornelisen, F. I. M. Thomas, Water flow enhances ammonium and nitrate uptake in a seagrass community. *Mar. Ecol. Prog. Ser.* 312, 1–13 (2006).
- R. Martínez-García, J. M. Calabrese, E. Hernández-García, C. López, Vegetation pattern formation in semiarid systems without facilitative mechanisms. *Geophys. Res. Lett.* 40, 6143–6147 (2013).
- 44. D. Walgraef, Spatio-Temporal Pattern Formation (Springer-Verlag, 1997).
- K. Gowda, H. Riecke, M. Silber, Transitions between patterned states in vegetation models for semiarid ecosystems. *Phys. Rev. E* 89, 022701 (2015).
- N. Akhmediev, A. Ankiewicz, Dissipative Solitons: From Optics to Biology and Medicine (Springer-Verlag, 2008).
- P. Woods, A. Champneys, Heteroclinic tangles and homoclinic snaking in the unfolding of a degenerate reversible Hamiltonian-Hopf bifurcation. *Physica D.* 129, 147 (1999).
- 48. P. Coullet, C. Riera, C. Tresser, Stable static localized structures in one dimension. *Phys. Rev. Lett.* **84**, 3069–3072 (2000).
- S. Arnaud-Haond, C. M. Duarte, E. Diaz-Almela, N. Marbà, T. Sintes, E. A. Serrão, Implications of extreme life span in clonal organisms: Millenary clones in meadows of the threatened seagrass *Posidonia oceanica*. *PLOS ONE* 7, e30454 (2012).
- C. M. Duarte, Submerged aquatic vegetation in relation to different nutrient regimes. Ophelia 41, 87–112 (1995).

## SCIENCE ADVANCES | RESEARCH ARTICLE

- 51. G. A. Kendrick, N. Marbà, C. M. Duarte, Modelling formation of complex topography by the seagrass Posidonia oceanica. Estuar. Coast. Shelf Sci. 65, 717–725 (2005).
- 52. K. Siteur, E. Siero, M. B. Eppinga, J. D. M. Rademacher, A. Doelman, M. Rietkerk, Beyond turing: The response of patterned ecosystems to environmental change. Ecol. Complex. 20, 81–96 (2014).
- 53. S. Pigolotti, C. López, E. Hernández-García, K. H. Andersen, How Gaussian competition leads to lumpy or uniform species distributions. Theor. Ecol. 3, 89 (2010).
- 54. P. Colet, M. A. Matías, L. Gelens, D. Gomila, Formation of localized structures in bistable systems through nonlocal spatial coupling. I. General framework. Phys. Rev. E 89, 012914 (2014).
- 55. L. Gelens, M. A. Matías, D. Gomila, T. Dorissen, P. Colet, Formation of localized structures in bistable systems through nonlocal spatial coupling. II. The nonlocal Ginzburg-Landau equation. Phys. Rev. E 89, 012915 (2014).
- 56. C. Fernandez-Oto, M. G. Clerc, D. Escaff, M. Tlidi, Strong nonlocal coupling stabilizes localized structures: An analysis based on front dynamics. Phys. Rev. Lett. 110, 174101 (2013).
- 57. S. Pigolotti, C. López, E. Hernández-García, Species clustering in competitive Lotka-Volterra models. Phys. Rev. Lett. 98, 258101 (2007).
- 58. R. Montagne, E. Hernández-García, A. Amengual, M. San Miguel, Wound-up phase turbulence in the complex Ginzburg-Landau equation. Phys. Rev. E 56, 151 (1997).

Acknowledgments: We acknowledge helpful discussions with C. López. Funding: D.R.-R., D.G., T.S., E.H.-G., and N.M. acknowledge financial support from AEI/FEDER [Agencia Estatal de Investigación/Fondo Europeo de Desarrollo Regional, European Union (EU)] (FIS2015-63628-C2-1-R, FIS2015-63628-C2-2-R, and CGL2015-71809-P). C.M.D. was supported by King Abdullah University of Science and Technology through the baseline funding. Author contributions: D.G., E.H.-G., and T.S. conceived and designed the research. D.R.-R., D.G., E.H.-G., and T.S. derived the ABD model. D.R.-R. performed the numerical simulations supervised by D.G. N.M. and C.M.D. provided the experimental data. D.R.-R. processed and analyzed the experimental data. All authors contributed to scientific discussions and to the writing of the paper. Competing interests: The authors declare that they have no competing interests. Data and materials availability: All data needed to evaluate the conclusions in the paper are present in the paper and/or the Supplementary Materials. Additional data related to this paper may be requested from the authors.

Submitted 12 January 2017 Accepted 28 June 2017 Published 2 August 2017 10.1126/sciadv.1603262

Citation: D. Ruiz-Reynés, D. Gomila, T. Sintes, E. Hernández-García, N. Marbà, C. M. Duarte, Fairy circle landscapes under the sea. Sci. Adv. 3, e1603262 (2017).