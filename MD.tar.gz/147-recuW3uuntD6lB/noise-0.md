Analytical expression for end-to-end- auto correlation function of a long chain polymer molecule in solution

Moumita Ganguly1,<sup>∗</sup>

*Indian Institute of Technology Mandi, Kamand, Himachal Pradesh - 175005, India.*

Anirudhha Chakraborty

*Indian Institute of Technology Mandi, Kamand, Himachal Pradesh - 175005, India.*

## Abstract

A diffusion-like theory for real time end-to-end distance of a long polymer chain in dilute solution is formulated. We give a detailed analytical expression for the end-to-end distance auto-correlation function of a long chain polymer in solution. The physical problem of dynamics of end-to-end distance can be modeled mathematically with the use of a Smoluchowski-like equation. Using this equation analytical expression for end-to-end distance auto-correlation function is derived. We find that this auto-correlation function varies with several parameters such as length of the polymer (N), bond length (b) and the relaxation time τR.

*Keywords:* Polymer; Analytical; end-to-end distance; auto-correlation function.

## 1. Introduction

Understanding the dynamics end-to-end distance of a long chain polymer molecules in solution has been an interesting research field [\[1,](#page-4-0) [2](#page-4-1), [3\]](#page-4-2). This will help a lot in understanding polymer looping problem both experimentally [\[4,](#page-4-3) [5](#page-4-4), [6\]](#page-4-5) and theoretically [\[7,](#page-4-6) [8](#page-4-7), [10](#page-4-8), [11,](#page-4-9) [12,](#page-4-10) [13\]](#page-4-11). In this paper, the dynamics of end-to-end distance of a single long polymer chain have been modeled

<sup>∗</sup>Corresponding author

*Email address:* mouganguly09@gmail.com (Moumita Ganguly )

<sup>1</sup>Phone:-+91-1905-267145, Fax: +91-1905-237945

following the work of Szabo *et. al.,* [\[9](#page-4-12)]. In this model dynamics of end-to end distance is mathematically represented by a Smoluchowski-like equation for a single particle under harmonic potential.

## 2. Our Model

In this section we use the simplest one dimensional description of a polymer as given by Szabo *et.al.,* [\[9](#page-4-12)]. Our description consists of a total 2N segments of unit length. The chain consists of 2N monomers following random walk. Thus each monomer is allowed to take two possible orientations, one along the right and the other among the left direction. So the polymer can have any of the total 2<sup>2</sup><sup>N</sup> different conformations. In the following, we define x as the end-to-end distance of the whole polymer, with the value x = 2j. After a total N steps the polymer segments can be either on the right N + j or on the left N − j. This implies that the polymer looping problem can be solved using standard procedure of probability theory. The equilibrium end-to-end distribution P<sup>0</sup><sup>j</sup> of this long polymer is given by

$$P_{0j} = 2^{-2N} \binom{2N}{N+j}. (1)$$

Now if we consider the unbiased random walk problem, then the probability distribution can be very easily calculated by knowing the differences of rate of fluctuations between the polymers moving towards either right or left. If we imagine the polymer molecule to be immersed in a solvent, the motion of polymer will be determined by a wide variety of intra-molecular and intermolecular forces between the polymer and the solvent. When we watch the motion of polymer molecule, the motion would appear to be random. Then considering the variation of all right and left monomer segments being independent of each other the net fluctuation is directed by the following rate equation.

$$\frac{d}{dt} \begin{bmatrix} p \\ n \end{bmatrix} = \frac{1}{\tau_R} \begin{bmatrix} -1 & 1 \\ 1 & -1 \end{bmatrix} \begin{bmatrix} p \\ n \end{bmatrix}, \tag{2}$$

where the vector [<sup>p</sup> n ] represents the activity of right and left segments orientations, τ<sup>R</sup> represent the relaxation time from one configuration to another. Now, the whole event of end-to-end looping of a polymer molecule in solution, can be considered to be a simple random walk model confined in 2<sup>2</sup><sup>N</sup> dimensional configuration space. The individual monomer's re-orientation would result in 2N ways to reorder a x = 2j conformation either to a x = 2j + 2 or x = 2j - 2 conformation and N - J + 1 ways to reorient a x = 2j + 2 conformation into a x = 2j conformation. Then the resulting master equation for the end-to-end distribution P(j,t) in the (2N + 1)-dimensional space is given by [9]

$$\tau_R \frac{d}{dt} P(j,t) = -2NP(j,t) + (N+j+1)P(j+1,t) + (N-j+1)P(j-1,t).$$
 (3)

As we see that for long chain polymer molecule (N large), what we try to search for and measure experimentally is a distribution, *i.e.*, the probability for finding the end-to-end distance of a long polymer molecule. The equilibrium distribution of Eq.(1) can be approximated by the continuous Gaussian distribution (x = 2bj)

<span id="page-2-0"></span>
$$P_0(x) = \frac{e^{-\frac{x^2}{4b^2N}}}{(4\pi b^2 N)^{1/2}}. (4)$$

Now if the individual monomers are further reduced to close points, the whole polymer can be represented in a continuum limit which results in Eq. (4) as its equilibrium distribution. Then the corresponding probability conservation equation is given below

$$\tau_R \frac{\partial P(x,t)}{\partial t} = \left(4Nb^2 \frac{\partial^2}{\partial x^2} + 2\frac{\partial}{\partial x}x\right) P(x,t). \tag{5}$$

In the section this equation will be used to derive an analytical expression for end-to-end auto-correlation function.

# 3. Analytical Calculation of end-to-end distance auto-correlation function

Now we calculate the real time end-to-end distance auto-correlation function  $\langle x(t)x(0)\rangle$  using Eq. (5). This auto-correlation function is defined by

$$\langle x(t)x(0)\rangle = \int_{-\infty}^{\infty} dx \ x \ \int_{-\infty}^{\infty} dx' \ x' \ G(x, x'|t) P_0(x'), \tag{6}$$

where  $P_0(x)$  is given by Eq.(4) and Green's function G(x, x'|t) is to be determined form Eq.(5) as given below

$$\tau_R \frac{\partial}{\partial t} G(x, x'|t) = \left(4Nb^2 \frac{\partial^2}{\partial x^2} + 2\frac{\partial}{\partial x} x\right) G(x, x'|t), \tag{7}$$

where the initial distribution is assumed to be given by

$$G(x, x'|0) = \delta(x - x'). \tag{8}$$

In the following, we will show that  $\langle x(t)x(0)\rangle$  can be calculated without having the complete knowledge of G(x,x'|t). Using Eq. (7) the time derivative of auto-correlation function in Eq. (6) is calculated as

$$\frac{\partial}{\partial t} \langle x(t)x(0) \rangle = \int dx \int dx' \ x \ x' \ \left[ \frac{1}{\tau_R} \frac{\partial}{\partial x} \left( 4Nb^2 \frac{\partial G(x, x'|t)}{\partial x} + 2 \ x \ G(x, x'|t) \right) \right] P_0(x'). \tag{9}$$

The right-hand side of the above equation can be re-written by the method of integration by parts as given by

$$\frac{\partial}{\partial t} \langle x(t)x(0) \rangle = \int dx \int dx' G(x, x'|t) P_0(x') \left[ \frac{4Nb^2}{\tau_R} \frac{\partial}{\partial x} \frac{\partial}{\partial x} (x x') - \frac{2x}{\tau_R} \frac{\partial}{\partial x} (x x') \right] 10$$

$$= -\frac{2}{\tau_R} \int dx \int dx' x x' G(x, x'; t) P_0(x').$$

The initial condition can be obtained from the following equation

$$\langle x(0)^2 \rangle = \int dx \ x^2 \ P_0(x) = 2Nb^2.$$
 (11)

So we get the analytical expression for the end-to-end auto-correlation function s given by

$$\langle x(t)x(0)\rangle = 2Nb^2 e^{-2t/\tau_R}. (12)$$

### 4. Summary and Conclusions

Here we use a very simple model to derive an analytical expression for end-toend distance auto-correlation function for a long chain polymer molecule in solution. This auto-correlation decreases with increase in time and it is very sensitive to  $\tau_R$ , relaxation time from one configuration to another. Stronger correlation is found for polymer with longer bond lengths. Strong correlation is found for longer polymer chain.

#### 5. Acknowledgments:

One of the author (M.G.) would like to thank IIT Mandi for HTRA fellowship and the other author thanks IIT mandi for providing PDA grant.

## 6. References

## References

- <span id="page-4-0"></span>[1] K. Schulten, Z. Schulten and A. Szabo, Physica A 100 (1980) 599.
- <span id="page-4-1"></span>[2] M. Ganguly and A. Chakraborty, Physica A, 484 (2017) 163.
- <span id="page-4-2"></span>[3] M. Ganguly and A. Chakraborty, Chem. Phys. Lett., (under revision) (2017).
- <span id="page-4-3"></span>[4] A. Winnik, In Cyclic Polymers, Chapter 9 Elsivier, 1986.
- <span id="page-4-4"></span>[5] Z. Haung, H. Ji, J. Mays, and M. Dadmun, Langmuir 26 (2010) 202.
- <span id="page-4-5"></span>[6] L. J. Lapidus, P. J. Steinbach, W. A. Eaton, A. Szabo, and J. Hofrichter, J. Phys. Chem. B 106 (2002) 11628.
- <span id="page-4-6"></span>[7] G. Wilemski and M. Fixman, J. Chem. Phys. 60 (1974) 866.
- <span id="page-4-7"></span>[8] M. Doi, Chem. Phys. 9 (1975) 455.
- <span id="page-4-12"></span>[9] A. Szabo, K. Schulten, and Z. Schulten, J. Chem. Phys. 72 (1980) 4350.
- <span id="page-4-8"></span>[10] R. W. Pastor, R. Zwanzig, and A. Szabo, J. Chem. Phys. 105 (1996) 3878.
- <span id="page-4-9"></span>[11] J. J. Portman, J. Chem. Phys. 118 (2003) 2381.
- <span id="page-4-10"></span>[12] I. M. Sokolov, Phys. Rev. Lett. 90 (2003) 080601.
- <span id="page-4-11"></span>[13] N. M. Toan, G. Morrison, C. Hyeon, and D. Thirumalai, J. Phys. Chem. B 112 (2008) 6094.