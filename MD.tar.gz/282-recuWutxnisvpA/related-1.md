## AN ANALYTICAL MODEL FOR SPHERICAL GALAXIES AND BULGES

### LARS HERNOUIST

Institute for Advanced Study, Princeton, New Jersey Received 1989 October 23; accepted 1989 December 19

## **ABSTRACT**

A potential-density pair which closely approximates the de Vaucouleurs  $R^{1/4}$  law for elliptical galaxies is presented. It is shown that the intrinsic properties and projected distributions of this model can be evaluated analytically. In particular, the distribution function, density of states, and projected surface brightness and velocity dispersion are expressible in terms of elementary functions.

Subject headings: galaxies: photometry — galaxies: structure

#### I. INTRODUCTION

It has long been recognized that the observed luminosity distribution of many elliptical galaxies and bulges is well represented by the empirical law

$$\log_{10} \left[ \frac{I(R)}{I(R_e)} \right] = -3.331 \left[ \left( \frac{R}{R_e} \right)^{1/4} - 1 \right], \tag{1}$$

where R is the projected radius on the plane of the sky,  $R_e$  is the effective radius of the isophote enclosing half the light, and I is the surface brightness (de Vaucouleurs 1948; Kormendy 1977). Although convenient for representing the observable properties of galaxies and bulges, the de Vaucouleurs profile is less useful for theoretical analyses since its deprojected mass density,  $\rho(r)$ , is not tractable analytically (e.g., Young 1976). This fact motivates interest in density profiles resembling that of the  $R^{1/4}$  law but which have simple analytic forms.

The model proposed by Jaffe (1983),  $\rho(r) \propto r^{-2}(r+r_{\rm J})^{-2}$ , where  $r_{\rm J}$  is a scale length, has been widely used in numerical studies of spherical galaxies since many of its intrinsic properties can be computed analytically. However, the distribution function derived from the Jaffe model deviates from that of the  $R^{1/4}$  law at large negative energies (e.g., Binney and Tremaine 1987) and involves special functions. Although it is arguable whether the de Vaucouleurs law fits observations better than the Jaffe profile (Jaffe 1983), it is clearly of value to have models whose properties can be expressed in terms of elementary functions.

The deviation of the Jaffe distribution function from that of the  $R^{1/4}$  law can be traced to the fact that  $\rho_{\rm J} \sim r^{-2}$  as  $r \to 0$ , while  $\rho_{R^{1/4}} \sim r^{-3/4}$  in the same limit. Consider the density profile

$$\rho(r) = \frac{M}{2\pi} \frac{a}{r} \frac{1}{(r+a)^3} \,, \tag{2}$$

where M is the total mass and a is a scale length. This mass distribution is quite similar to Jaffe's, but now  $\rho(r) \sim r^{-1}$  as  $r \to 0$ , and hence it more closely resembles the  $R^{1/4}$  law at small radii. Moreover, as summarized below, a number of the intrinsic properties and projected distributions of the model defined by equation (2) are simpler than those of the Jaffe profile.

## II. MODEL

# a) Characteristics

The cumulative mass distribution corresponding to equation (2) is

$$M(r) = M \frac{r^2}{(r+a)^2} \,.$$
(3)

Note that M(a) = M/4. The half-mass radius,  $r_{1/2}$ , follows from equation (3) by setting  $M(r_{1/2}) = M/2$ , with the result

$$r_{1/2} = (1 + \sqrt{2})a. (4)$$

The potential,  $\varphi(r)$ , is found by integrating Poisson's equation. For the density in equation (2)

$$\varphi(r) = -\frac{GM}{r+a}\,,\tag{5}$$

where G is the gravitational constant. Defining dimensionless forms of the density and potential by

$$\tilde{\rho} = \frac{2\pi a^3}{M} \, \rho(r) = \frac{a^4}{r(r+a)^3} \,, \tag{6}$$

and

$$\tilde{\psi} = -\frac{a}{GM}\,\varphi(r) = \frac{a}{r+a}\,,\tag{7}$$

it is possible to relate the density to the potential in the particularly simple form

$$\tilde{\rho} = \frac{\tilde{\psi}^4}{1 - \tilde{\psi}} \,. \tag{8}$$

Note that since  $0 \le \tilde{\psi} \le 1$ ,  $\tilde{\rho}(\tilde{\psi})$  can be expanded in the pure power series

$$\tilde{\rho} = \sum_{n=0}^{\infty} \tilde{\psi}^{n+4} .$$

Equation (8) can be inverted to yield  $\tilde{\psi} = \tilde{\psi}(\tilde{\rho})$ ; the result is given in Appendix A.

For a nonrotating, spherical system the velocity dispersion is determined by the Jeans equation

$$\frac{1}{\rho} \frac{d}{dr} \left( \rho \overline{v_r^2} \right) + 2\beta \frac{\overline{v_r^2}}{r} = -\frac{d\varphi}{dr} \,, \tag{9}$$

where  $\beta(r) = 1 - \overline{v_{\theta}^2/v_r^2}$ ,  $\overline{v_r^2}$  is the radial velocity dispersion, and  $v_{\theta}^2 = v_{\phi}^2$  are the angular velocity dispersions. For an isotropic system  $\beta(r) = 0$ , and equations (2) and (5) yield

$$\overline{v_r^2} = \frac{GM}{12a} \left\{ \frac{12r(r+a)^3}{a^4} \ln\left(\frac{r+a}{r}\right) - \frac{r}{r+a} \left[ 25 + 52\frac{r}{a} + 42\left(\frac{r}{a}\right)^2 + 12\left(\frac{r}{a}\right)^3 \right] \right\}. (10)$$

Note that  $\overline{v_r^2}$  is nowhere divergent. If  $r \ll a$ ,

$$\overline{v_r^2} \sim \frac{GM}{a} \frac{r}{a} \ln \frac{a}{r},\tag{11}$$

and so  $\overline{v_r^2}$  goes to zero at the center, while  $\overline{v_r^2} \sim GM/5r$  in the limit  $r \gg a$ . If, instead, all stars are on circular orbits,  $\overline{v_r^2} = 0$  and  $2v_\theta^2 = r\,d\varphi/dr$ . Defining  $v_T^2 = v_\theta^2 + \overline{v_\phi^2}$ , then  $v_T^2 = v_c^2$ , where  $v_c$  is the circular velocity, given below. The corresponding model with purely radial orbits, i.e.,  $\overline{v_\theta^2} = v_\phi^2 = 0$ , is not of practical interest since its distribution function is not everywhere nonnegative.

For a spherical, isotropic model the kinetic energy is

$$T(r) = 6\pi \int_0^r \rho \overline{v_r^2} \, r^2 \, dr \; .$$

From equations (2) and (10).

$$T = \frac{GM^2}{4a} \left[ 4\left(\frac{r}{a}\right)^3 \ln\left(\frac{r+a}{r}\right) - 4\left(\frac{r}{a}\right)^2 + 2\frac{r}{a} - 1 + \frac{(r/a)^2 + r/a + 1}{(1+r/a)^3} \right].$$
 (12)

As  $r/a \rightarrow 0$ ,

$$T(r) \sim \frac{GM^2}{a} \left(\frac{r}{a}\right)^3 \ln \frac{a}{r} \,. \tag{13}$$

The total kinetic energy,  $T_{\rm tot}$ , follows from equation (22) in the limit  $r \to \infty$ , with the result  $T_{\rm tot} = GM^2/12a$ . The total potential energy,  $\Omega_{\rm tot}$ , is defined by

$$\Omega_{\rm tot} = 2\pi \int_0^\infty \rho(r) \varphi(r) r^2 dr .$$

For the model here this integral yields

$$\Omega_{\rm tot} = -\frac{GM^2}{6a} \,. \tag{14}$$

Note that  $2T_{\text{tot}} + \Omega_{\text{tot}} = 0$ , in accord with the virial theorem.

Other quantities of interest are the local escape velocity,  $v_e = \sqrt{-2\varphi(r)}$  and circular velocity  $v_c = \sqrt{GM(r)/r}$ . From equations (3) and (5),

$$v_e = \sqrt{\frac{2GM}{r+a}},\tag{15}$$

$$v_c = \frac{\sqrt{GMr}}{r+a} \,. \tag{16}$$

As  $r/a \to \infty$ ,  $v_c \sim r^{-1/2}$ , and consequently the rotation curve is asymptotically Keplerian.

Of fundamental dynamical importance is the distribution function, f, here normalized so that f dr dv is the mass in the six-dimensional volume element dr dv centered on the phase-

space point (r, v). For a spherical, isotropic model f can be expressed solely as a function of the total specific energy, E. Obtaining f(E) for the present model is straightforward, owing to the simple relation between density and potential (eq. [8]). Inverting the relation between  $\rho(r)$  and f(E) using an Abel transform (e.g., Binney and Tremaine 1987) gives

$$f(E) = \frac{M}{8\sqrt{2}\pi^3 a^3 v_g^3} \frac{1}{(1-q^2)^{5/2}}$$

$$\times \left[3 \sin^{-1} q + q(1-q^2)^{1/2} (1-2q^2)(8q^4 - 8q^2 - 3)\right], \quad (17)$$

where

$$q = \sqrt{-\frac{a}{GM}E} \,, \tag{18}$$

Vol. 356

and

$$v_g = \left(\frac{GM}{a}\right)^{1/2}. (19)$$

Note that  $0 \le q \le 1$ . This distribution function is everywhere nonnegative. As  $q \to 0$ ,

$$f(E) \sim \frac{M}{\sqrt{2\pi^3 a^3 v_g^3}} \frac{16}{5} q^5 \left( 1 + \frac{10}{7} q^2 + \frac{40}{21} q^4 + \cdots \right).$$
 (20)

In the limit  $q \to 1$ , f(E) diverges according to

$$f(E) \sim \frac{3M}{128\pi^2 a^3 v_a^3} \frac{1}{(1-q^2)^{5/2}} \left[ 1 - \frac{5}{4} (1-q^2) + \dots \right];$$
 (21)

however, as shown immediately below, this is not a serious difficulty since these energies contain vanishingly little mass.

The mass of stars, dM, with binding energies in the energy interval  $\mathscr E$  to  $\mathscr E+d\mathscr E$  is given by the differential energy distribution  $dM/d\mathscr E$ , where  $\mathscr E=-E$ . If the distribution function  $f(\mathscr E)$  depends on energy alone, then

$$\frac{dM}{d\mathscr{E}} = g(\mathscr{E})f(\mathscr{E}) , \qquad (22)$$

where  $g(\mathscr{E})$  is the density of states (Binney and Tremaine 1987). Using a procedure similar to that employed above in computing f(E),  $g(\mathscr{E})$  can be evaluated explicitly for the model here with the result

$$g(\mathscr{E}) = \frac{2\sqrt{2}\pi^2 a^3 v_g}{3q^5} \left[ 3(8q^4 - 4q^2 + 1) \times \cos^{-1} q - q(1 - q^2)^{1/2} (4q^2 - 1)(2q^2 + 3) \right]. \tag{23}$$

In the limit  $\mathscr{E} \to 0$ .

$$g(\mathscr{E}) \sim \frac{\sqrt{2}\pi^3 a^3 v_g}{a^5} (1 - 4q^2 + 8q^4 + \cdots),$$
 (24)

while as  $\mathscr{E} \to 1$ .

$$g(\mathscr{E}) \sim \frac{4096\pi^2 a^3 v_g}{105} (1 - q^2)^{7/2} \left[ 1 - \frac{43}{12} (1 - q^2) + \cdots \right].$$
 (25)

Note that g(1) = 0; i.e., no states are available at the origin, r = 0.

The differential mass distribution is given by the product of equations (17) and (23). In particular, as  $\mathscr{E} \to 0$ ,

$$\frac{dM}{d\mathscr{E}} \sim \frac{16}{5} \frac{M}{v_a^2} \left( 1 - \frac{18}{7} q^2 + \cdots \right),$$
 (26)

while as  $\mathscr{E} \to 1$ .

$$\frac{dM}{d\mathscr{E}} \sim \frac{32}{35} \frac{M}{v_a^2} (1 - q^2) \,. \tag{27}$$

So,  $dM/d\mathscr{E}$  goes smoothly to zero at the center, despite the fact that  $f(\mathscr{E})$  is divergent there.

It is also possible to include the effects of anisotropic velocity dispersion using the procedure introduced by Osipkov (1979) and Merritt (1985a, b). The distribution function now depends on both the energy and specific angular momentum, L. First, define

$$Q = -E - \frac{L^2}{2r_a^2},$$
 (28)

and

$$\rho_Q(r) = \left(1 + \frac{r^2}{r_a^2}\right) \rho(r) , \qquad (29)$$

where  $r_a$  is the anisotropy radius. In the limit  $r_a \to \infty$ ,  $Q \to -E$  and  $\rho_Q(r) \to \rho(r)$ . Then the distribution function corresponding to  $\rho_Q(r)$ ,  $f_Q(Q)$ , can again be computed using an Abel transform (e.g., Binney and Tremaine 1987), with the result

$$f_Q(Q) = f(\tilde{q}) + \frac{M}{\sqrt{2\pi^3 a^3 v_a^3}} \frac{a^2}{r_a^2} \tilde{q} (1 - 2\tilde{q}^2),$$
 (30)

where

$$\tilde{q} = \sqrt{\frac{a}{GM} Q} , \qquad (31)$$

f is defined by equation (17), and, by convention,  $f_Q(Q) = 0$  for  $Q \le 0$ .

# b) Projected Distributions

The projected surface brightness of the present model can be computed by integrating its luminosity density along lines of sight. Let  $\Upsilon$  be the constant mass-to-light ratio. Then the surface brightness is

$$I(R) = \frac{M}{2\pi a^2 \Upsilon(1 - s^2)^2} \left[ (2 + s^2) X(s) - 3 \right],$$
 (32)

where s = R/a, R is the projected radius and

$$X(s) = \frac{1}{\sqrt{1-s^2}} \operatorname{sech}^{-1} s \text{ for } 0 \le s \le 1,$$
 (33)

$$X(s) = \frac{1}{\sqrt{s^2 - 1}} \sec^{-1} s$$
 for  $1 \le s < \infty$ . (34)

Recall that sech<sup>-1</sup>  $s = i \sec^{-1} s$ , so X(s) is continuous at s = 1. For computational purposes, the relations  $\sec^{-1} s = \cos^{-1} 1/s$  and  $\operatorname{sech}^{-1} s = \ln \left[ (1 + \sqrt{1 - s^2})/s \right]$  can be used to express equations (33) and (34) in more convenient forms. In the limit  $s \to 0$   $X(s) \sim \ln 2/s$ , and so I(R) diverges logarithmically:

$$I(R) \sim \frac{M}{\pi a^2 \Upsilon} \ln \frac{2}{s} \,. \tag{35}$$

As  $s \to \infty$ ,  $X(s) \sim \pi/2s$ , implying

$$I(R) \sim \frac{M}{2\pi a^2 \Upsilon} \frac{\pi}{2s^3} \,. \tag{36}$$

At the point R = a, X(1) = 1, and so  $I(a) = 2M/(15\pi a^2\Upsilon)$ . (More detailed expressions can be found in Appendix B.)

The cumulative surface brightness, defined by  $S(R) = 2\pi \int_0^R I(R)R dR$ , is

$$S(R) = \frac{Ms^2}{\Upsilon} \frac{X(s) - 1}{1 - s^2}$$
 (37)

for all s. Note that  $S(R = a) = M/3\Upsilon$ , and the total luminosity is  $S(R = \infty) = M/\Upsilon$ .

The effective radius,  $R_e$ , can be computed from equation (37) by setting  $S(R_e) = M/2\Upsilon$ . A numerical solution gives

$$R_e \approx 1.8153a \ . \tag{38}$$

From equation (4), the effective radius and half-mass radius for the model here are related by

$$r_{1/2} \approx 1.33 R_e \tag{39}$$

For a spherical, nonrotating system the line-of-sight velocity dispersion,  $\sigma_p$ , is given by

$$I(R)\sigma_p^2(R) = \frac{2}{\Upsilon} \int_{R}^{\infty} \left( 1 - \beta \, \frac{R^2}{r^2} \right) \frac{\rho \overline{v_r^2} r \, dr}{\sqrt{r^2 - R^2}} \,, \tag{40}$$

where  $\beta(r)$  is defined following equation (9). If the model is isotropic, i.e.,  $\beta = 0$ , then equation (40) yields

$$\sigma_p^2(R) = \frac{GM^2}{12\pi a^3 I(R)\Upsilon} \left\{ \frac{1}{2} \frac{1}{(1-s^2)^3} \times \left[ -3s^2 X(s)(8s^6 - 28s^4 + 35s^2 - 20) -24s^6 + 68s^4 - 65s^2 + 6 \right] - 6\pi s \right\}.$$
 (41)

For the case of purely circular orbits,  $\overline{v_r^2} = 0$ , and

$$\sigma_p^2(R) = \frac{GM^2R^2}{2\pi a^5 \Upsilon I(R)} \left\{ \frac{1}{24(1-s^2)^4} \times \left[ -X(s)(24s^8 - 108s^6 + 189s^4 - 120s^2 + 120) \right. \right. \\ \left. - 24s^6 + 92s^4 - 117s^2 + 154 \right] + \frac{\pi}{2s} \right\}. \quad (42)$$

Limiting forms of equations (41) and (42) can be found in Appendix B.

Figure 1 compares  $\sigma_p(R)/v_g$  for models with isotropic and purely circular orbits. For values of s=R/a>4,  $\sigma_p(R)$  was computed using asymptotic expansions given in Appendix B. At smaller radii, the general forms in equations (41) and (42) were employed except near R=a where Taylor series expansions, also given in Appendix B, were used. Note, in particular, that  $\sigma_p$  dips to zero at the origin in both models owing to the logarithmic divergence of the projected surface brightness there.

## c) Comparison with R<sup>1/4</sup> Law

The distribution function f(E) defined in equation (17) is plotted in Figure 2 as a function of energy, for various values of a, in units such that G=1 and M=1. Also shown is the distribution function for the  $R^{1/4}$  law, found by numerical integration (e.g., Binney 1982). The latter is normalized so that G=1, M=1, and its effective radius is also unity. The corresponding differential energy distributions, dM/dE, are shown in Figure 3.

![](_page_3_Figure_1.jpeg)

Fig. 1.—Projected velocity dispersion  $\sigma_p$  as a function of s = R/a for models with isotropic (solid curve) and purely circular (dotted curve) orbits. In both cases,  $\sigma_p$  is measured in units of  $v_q = (GM/a)^{1/2}$ .

As can be seen in Figures 2 and 3, the agreement between the present model and the  $R^{1/4}$  law is quite good, especially for values of  $a \approx 0.45$ . In fact, for a = 0.45 the distribution functions and differential energy distributions agree to ≤35% for energies between  $-2.0 \lesssim E \lesssim -0.03$ . This energy interval comprises  $\approx 97\%$  the mass of the  $R^{1/4}$  law and  $\approx 94\%$  the mass of the model here. Larger discrepancies occurring for  $E \lesssim$ -2.0 and  $E \gtrsim -0.03$  are confined to  $\approx 2\%$  and  $\approx 0.4\%$  the mass of the  $R^{1/4}$  law, respectively, and  $\approx 0.2\%$  and  $\approx 6\%$  the mass of the present model, respectively. Slightly better agreement at large negative energies can be obtained by reducing a. The choice a = 0.45 is roughly the mean of the a's for which the two models would have either the same half-mass radius or the same central potential,  $\varphi(0) = -2.62175$  (Young 1976). Over the range in energies where the agreement is especially good, the differential energy distribution of the model here is well fitted by an exponential,  $dM/dE \propto \exp(-\beta |E|)$ . The value of  $\beta$  is similar to that inferred for the  $R^{1/4}$  law (Binney 1982).

![](_page_3_Figure_4.jpeg)

Fig. 2.—Distribution functions for the  $R^{1/4}$  law (solid curve) and for the present model as a function of energy. Units are such that  $G = M = R_e = 1$ , where  $R_e$  is the effective radius of the  $R^{1/4}$  law. The curves for the model discussed here refer to four different values of a: a = 0.55 (dotted), a = 0.5(short-dashed), a = 0.45 (long-dashed), and a = 0.4 (dashed-dotted).

![](_page_3_Figure_6.jpeg)

Fig. 3.—Differential energy distributions for the  $R^{1/4}$  law (solid curve) and for the present model as a function of energy. Units are again such that  $G = M = R_a = 1$ , where  $R_a$  is the effective radius of the  $R^{1/4}$  law. The curves for the model analyzed here have the same meanings as those in Fig. 2.

The projected surface brightness, I(R), normalized to its value at the effective radius,  $I(R_e)$ , is shown in Figure 4 as a function of  $(R/R_o)^{1/4}$  for the current model and the  $R^{1/4}$  law. As for the distribution functions, the agreement between the two is quite good. The surface brightness profiles agree to within  $\approx 35\%$  for radii in the range  $0.06 \lesssim R/R_e \lesssim 14.5$ . This interval in radius encloses ≈94% the total light of each model. Larger discrepancies occurring for  $R/R_e \lesssim 0.06$  and  $R/R_e \gtrsim 14.5$  are confined to  $\approx 4\%$  and  $\approx 2\%$  the light of the  $R^{1/4}$  law, respectively, and  $\approx 0.2\%$  and  $\approx 5.5\%$  the light of the current model.

It is also of interest to compare the ratio  $r_{1/2}/R_e$  for the present model and the  $R^{1/4}$  law. As noted in equation (39),  $r_{1/2}/R_e \approx 1.33$  for the model here, while this ratio is approximately 1.35 for the  $R^{1/4}$  law (Young 1976).

### III. CONCLUSIONS

A new mass model for spherical galaxies and bulges described by the de Vaucouleurs profile has been presented. Its

![](_page_3_Figure_12.jpeg)

Fig. 4.—Surface brightness profiles for the  $R^{1/4}$  law (thick curve) and the present model (thin curve) as a function of  $(R/R_c)^{1/4}$ . Surface brightness is normalized to its value at Re where Re refers separately to the effective radii of the two models.

No. 2, 1990

intrinsic properties and projected distributions are similar to those of the Jaffe model but can all be expressed in terms of elementary functions. The results here are not intended to be comprehensive. More generally, it is of interest to consider the density field defined by

$$\rho(r) = \frac{C(\alpha, \beta, \gamma)}{4\pi a^3} \left(\frac{a}{r}\right)^{\alpha} \frac{1}{\left[1 + (r/a)^{\beta}\right]^{\gamma}}, \tag{43}$$

where  $C(\alpha, \beta, \gamma)$  is a constant. For the special case  $\rho(r) \sim r^{-4}$ when  $r \gg a$  (de Zeeuw 1985a, b), there are nine combinations of integer  $(\alpha, \beta, \gamma)$  which satisfy the constraint  $\alpha + \beta \gamma = 4$ . The two with  $\alpha = 3$  and  $\alpha = 4$  have divergent cumulative mass profiles at the origin and hence are not representative of the normal stellar population of elliptical galaxies. Three others have  $\alpha = 0$ . While of considerable theoretical interest (de Zeeuw 1985a, b; de Zeeuw and Pfenniger 1988), these models do not approximate the  $R^{1/4}$  law well at small radii. Four models remain, having  $(\alpha, \beta, \gamma) = (1, 1, 3)$  (the model presented here), (1, 3, 1), (2, 1, 2) (Jaffe's model), and (2, 2, 1) (a modified Jaffe model; Jaffe 1983). Those with  $(\alpha, \beta, \gamma) = (1, 3, 1)$  and (2, 2, 1) lead to potentials which cannot be expressed analytically in terms of the density. Thus, Jaffe's model and that analyzed in the current paper are unique, given the above conditions. It is possible that other simple, analytical potentialdensity pairs may yet be found for less restricted values of  $\alpha$ ,  $\beta$ , and  $\gamma$ .

The model discussed here should be useful for many theoretical and observational purposes. Since the distribution function is known analytically for both isotropic and anisotropic velocity dispersions, it can be used to construct equilibrium N-body realizations and to perform linear stability analyses. Owing to the simple relation between its density and potential. the model here may, perhaps, be generalized more easily than other approximations to the  $R^{1/4}$  law to include nonspherical effects, such as rotation (e.g., Lynden-Bell 1962; Dejonghe 1986; de Zeeuw 1987). Finally, since the kinematic properties of this model are also known analytically, it can be used to infer dynamical aspects of galaxies directly from observations.

I am especially grateful to John Bahcall for much discussion and encouragement and to Tim de Zeeuw for numerous suggestions on the contents of this paper. I also thank James Binney, Jeremy Goodman, and Scott Tremaine for careful readings of the manuscript and Martin Weinberg for discussion and for providing software to evaluate Abel transforms numerically. This work was supported in part by a grant from the Pittsburgh Supercomputing Center, where some numerical calculations were performed, and by New Jersey High Technology grant No. 88-240090-2.

### APPENDIX A

The quartic relating  $\tilde{\rho}$  and  $\tilde{\psi}$  defined by equation (8) can be inverted using standard procedures (e.g., Press et al. 1986), with the result

$$\tilde{\psi} = \frac{\tilde{\rho}^{1/4}}{2} \left( -u^{1/2} + \sqrt{-u + 4\sqrt{1 + \frac{u^2}{4}}} \right),\tag{A1}$$

where

$$u = \left(\frac{1}{2}\,\tilde{\rho}^{1/2} + \sqrt{\frac{64}{27} + \frac{\tilde{\rho}}{4}}\right)^{1/3} - \left(-\frac{1}{2}\,\tilde{\rho}^{1/2} + \sqrt{\frac{64}{27} + \frac{\tilde{\rho}}{4}}\right)^{1/3}.\tag{A2}$$

(Note that the solution to the general quartic equation given by Abramowitz and Stegun 1972 apparently contains a sign error.)

# APPENDIX B

Computation of the projected distributions defined in § IIb is simplified through the use of the following asymptotic and Taylor series expansions. In the limit  $s = R/a \rightarrow 0$ ,

$$X(s) \sim \ln\frac{2}{s} + \left(2\ln\frac{2}{s} - 1\right)\frac{s^2}{4} + \left(12\ln\frac{2}{s} - 7\right)\frac{s^4}{32} + \cdots,$$
 (B1)

and I(R) diverges logarithmically:

$$I(R) \sim \frac{M}{\pi a^2 \Upsilon} \left[ \ln \frac{2}{s} - \frac{3}{2} + \left( 12 \ln \frac{2}{s} - 13 \right) \frac{s^2}{4} + \left( 180 \ln \frac{2}{s} - 171 \right) \frac{s^4}{32} + \cdots \right].$$
 (B2)

As  $s \to \infty$ ,

$$X(s) \sim \frac{\pi}{2s} - \frac{1}{s^2} + \frac{\pi}{4s^3} - \frac{2}{3s^4} + \frac{3\pi}{16s^5} + \cdots,$$
 (B3)

implying

$$I(R) \sim \frac{M}{2\pi a^2 \Upsilon} \left( \frac{\pi}{2s^3} - \frac{4}{s^4} + \frac{9\pi}{4s^5} - \frac{32}{3s^6} + \frac{75\pi}{16s^7} + \cdots \right).$$
 (B4)

In the vicinity of the point R = a,

$$X(s) = 1 - \frac{2}{3}(s-1) + \frac{7}{15}(s-1)^2 - \frac{12}{35}(s-1)^3 + \frac{83}{315}(s-1)^4 - \frac{146}{693}(s-1)^5 + \cdots,$$
(B5)

$$I(R) = \frac{M}{2\pi a^2 \Upsilon} \left[ \frac{4}{15} - \frac{16}{35} (s-1) + \frac{8}{15} (s-1)^2 - \frac{368}{693} (s-1)^3 + \frac{1468}{3003} (s-1)^4 - \frac{928}{2145} (s-1)^5 + \cdots \right].$$
 (B6)

For the case of isotropic orbits,

$$\sigma_p^2(R) \sim \frac{GM}{a} \left\{ \frac{1}{[8\ln(2/s) - 12]\pi} - \frac{s}{4\ln(2/s) - 6} + \cdots \right\},$$
(B7)

as  $s \to 0$ , while

$$\sigma_p^2(R) \sim \frac{GM}{a} \frac{8}{15\pi} \frac{1}{s} \left[ 1 + \left( \frac{8}{\pi} - \frac{75}{64} \pi \right) \frac{1}{s} + \left( \frac{64}{\pi^2} - \frac{297}{56} \right) \frac{1}{s^2} + \left( \frac{512}{\pi^3} - \frac{1199}{21\pi} + \frac{75\pi}{512} \right) \frac{1}{s^3} + \cdots \right]$$
 (B8)

in the limit  $s \to \infty$ . Near R = a,

$$\sigma_p^2(R) = \frac{GM}{a} \left[ \frac{332 - 105\pi}{28} + \frac{18784 - 5985\pi}{588} (s - 1) + \frac{707800 - 225225\pi}{22638} (s - 1)^2 + \cdots \right].$$
 (B9)

For purely circular orbits,

$$\sigma_p^2(R) \sim \frac{GM}{a} \left[ \frac{\pi s}{4 \ln{(2/s)} - 6} - \frac{60 \ln{(2/s)} - 77}{24 \ln{(2/s)} - 36} s^2 + \cdots \right],$$
 (B10)

as  $s \rightarrow 0$ , while

$$\sigma_p^2(R) \sim \frac{GM}{a} \frac{16}{15\pi} \frac{1}{s} \left[ 1 + \left( \frac{8}{\pi} - \frac{375}{256} \pi \right) \frac{1}{s} + \left( \frac{64}{\pi^2} - \frac{753}{224} \right) \frac{1}{s^2} + \left( \frac{512}{\pi^3} - \frac{3491}{84\pi} - \frac{4875}{2048} \pi \right) \frac{1}{s^3} + \cdots \right]$$
(B11)

in the limit  $s \to \infty$ . Near R = a

$$\sigma_p^2(R) \sim \frac{GM}{a} \left[ \frac{315\pi - 976}{168} + \frac{21945\pi - 68928}{4312} (s - 1) + \frac{975975\pi - 3070640}{196196} (s - 1)^2 + \cdots \right]. \tag{B12}$$

## REFERENCES

Abramowitz, M., and Stegun, I. A. 1972, Handbook of Mathematical Functions (New York: Dover). Binney, J. 1982, M.N.R.A.S., 200, 951.

Binney, J., and Tremaine, S. 1987, Galactic Dynamics (Princeton: Princeton University Press). de Vaucouleurs, G. 1948, Ann. d'Ap., 11, 247. de Zeeuw, T. 1985a, M.N.R.A.S., 216, 273.

-. 1985b, M.N.R.A.S., **216**, 599.

1987, in IAU Symposium 127, Structure and Dynamics of Elliptical

Galaxies, ed. P. T. de Zeeuw (Dordrecht: Reidel), p. 271. de Zeeuw, T., and Pfenniger, D. 1988, M.N.R.A.S., 235, 949.

Dejonghe, H. 1986, *Phys. Rep.*, **133**, 217. Jaffe, W. 1983, *M.N.R.A.S.*, **202**, 995. Kormendy, J. 1977, *Ap. J.*, **218**, 333. Lynden-Bell, D. 1962, *M.N.R.A.S.*, **123**, 447.

Merritt, D. 1985a, A.J., 90, 1027. . 1985b, M.N.R.A.S., 214, 25P

Osipkov, L. P. 1979, Pis'ma Astr. Zh., 5, 77.
Press, W. H., Flannery, B. P., Teukolsky, S. A., and Veterling, W. T. 1986,
Numerical Recipes: The Art of Scientific Computing (Cambridge: Cambridge University Press).

Young, P. J. 1976, A.J., 81, 807.

LARS HERNQUIST: Institute for Advanced Study, Princeton, NJ 08540 [hernquist@iassns.bitnet]