## On the duality in constant-roll inflation

Yue Wang,<sup>1,\*</sup> Qing Gao,<sup>2,†</sup> Shengqing Gao,<sup>1,‡</sup> and Yungui Gong<sup>3,1,§</sup>

<sup>1</sup>School of Physics, Huazhong University of Science and Technology, Wuhan, Hubei 430074, China

<sup>2</sup>School of Physical Science and Technology,

Southwest University, Chongqing 400715, China

<sup>3</sup>Department of Physics, School of Physical Science and Technology,

Ningbo University, Ningbo, Zhejiang 315211, China

There is a duality in the observables  $n_s$ , r and the inflaton potential between large and small  $\eta_H$  for the constant-roll inflation if the slow-roll parameter  $\epsilon_H$  is negligible. In general, the duality between  $\eta_H$  and  $\bar{\eta}_H$  does not hold for the background evolution of the inflaton. For some particular solutions for the constant-roll inflation with  $\eta_H$  being a constant, we find that in the small field approximation, the potential takes the quadratic form and it remains the same when the parameter  $\eta_H$  changes to  $\bar{\eta}_H = 3 - \eta_H$ . If the scalar field is small and the contribution of  $\epsilon_H$  is negligible, we find that there exists the logarithmic duality and the duality between large and small  $\eta_H$  for the primordial curvature perturbation in inflationary models with the quadratic potential.

#### I. INTRODUCTION

As more evidences for the existence of primordial black holes (PBHs) were provided by the observations of gravitational waves (GWs) such as the Laser Interferometer Gravitational Wave Observatory (LIGO) Scientific and Virgo Collaborations [1–6], and the Pulsar Timing Arrays (PTAs) [7–10], PBHs as dark matter attracted a lot of attention. When the density contrast of overdense regions exceeds the threshold value at the horizon reentry during radiation domination, PBHs may form through gravitational collapse [11, 12]. The large density contrast of overdense regions may be seeded from large primordial curvature perturbations at small scales generated during inflation. The large curvature perturbations are

<span id="page-0-1"></span><span id="page-0-0"></span><sup>\*</sup> ywang123@hust.edu.cn

<span id="page-0-2"></span><sup>†</sup> Corresponding author. gaoqing1024@swu.edu.cn

<span id="page-0-3"></span><sup>&</sup>lt;sup>‡</sup> gaoshengqing@hust.edu.cn

<sup>§</sup> gongvungui@nbu.edu.cn

also the sources of secondary gravitational waves (GWs) after the horizon reentry through the scalar-tensor mixing [\[13](#page-10-3)[–16\]](#page-10-4). Therefore, accompanied with the production of PBHs, scalar induced gravitational waves (SIGWs) are generated [\[3](#page-9-3), [13](#page-10-3)[–53\]](#page-13-0).

To produce large curvature perturbations at small scales during inflation, we usually consider inflationary models with an inflection point in the inflaton potential [\[54](#page-13-1)[–57](#page-13-2)]. Near the inflection point, the slow-roll parameter η<sup>H</sup> ≈ 3 and it is called the ultra-slow-roll (USR) inflation [\[58](#page-13-3), [59](#page-13-4)]. More general, the constant-roll inflation with η<sup>H</sup> being a constant was proposed [\[60,](#page-13-5) [61\]](#page-13-6). If η<sup>H</sup> > 1, then the slow-roll condition is violated in constant-roll inflation and the primordial curvature perturbations may evolve outside the horizon [\[59](#page-13-4)[–66\]](#page-13-7). For constant-roll inflation, the inflationary potential and the background equation of motion can be solved analytically. Due to different background evolution for large and small ηH, the observational data constrained η<sup>H</sup> to be small [\[67](#page-14-0)[–70\]](#page-14-1). Since the slow-roll parameter ǫ<sup>H</sup> decreases with time, so it may be negligible during inflation. By neglecting the contribution from ǫ<sup>H</sup> , it was found that there exists a duality between η<sup>H</sup> and ¯η<sup>H</sup> = 3 − η<sup>H</sup> in the observables the scalar spectral tilt n<sup>s</sup> and the tensor-to-scalar ratio r [\[71,](#page-14-2) [72\]](#page-14-3). The duality between η<sup>H</sup> and ¯η<sup>H</sup> = 3 − η<sup>H</sup> connects the constant slow-roll inflation with |ηH| ≪ 1 and the USR inflation with η<sup>H</sup> ≈ 3, so the behavior of the primordial curvature perturbations in USR inflation can be understood from the usual slow-roll inflation. Recently, the logarithmic duality of the primordial curvature perturbation was found for the quadratic potential in Ref. [\[73\]](#page-14-4). Since the logarithmic duality applies to both the slow-roll and USR inflation, we extend the discussion on the duality to constant-roll inflation in this paper.

The paper is organized as follows. In Section [II,](#page-1-0) we discuss the duality in constant-roll inflation. Motivated by the duality in constant-roll inflation, we then discuss the logarithmic duality of the primordial curvature perturbation using the δN formalism in Section [III.](#page-4-0) The conclusion is drawn in Section [IV.](#page-8-0)

### <span id="page-1-0"></span>II. THE CONSTANT-ROLL INFLATION

For the constant-roll inflation, we take the second Hubble flow slow-roll parameter

<span id="page-1-1"></span>
$$\eta_H = \frac{2}{H} \frac{d^2 H}{d\phi^2} = -\frac{\ddot{H}}{2H\dot{H}} = -\frac{\ddot{\phi}}{H\dot{\phi}} \tag{1}$$

to be a constant, i.e., we take  $\eta_H = 3 + \alpha$  with  $\alpha$  being a constant. If  $\alpha \approx -3$ , then  $\eta_H$  is small and the constant-roll inflation is also a slow-roll inflation; If  $\alpha \approx 0$ , then  $\eta_H \approx 3$  and  $dV/d\phi \approx 0$ , the constant-roll inflation is USR inflation. For the constant-roll inflation with a constant  $\eta_H$ , the scalar spectral tilt is [61, 66]

<span id="page-2-0"></span>
$$n_s - 1 \approx 3 - |2\eta_H - 3| - \frac{2(2\eta_H^2 - 9\eta_H + 6)}{|2\eta_H - 3|} \epsilon_H,$$
 (2)

and the tensor-to-scalar ratio is [61, 66]

$$r \approx 2^{7-|2\eta_H - 3|} \left( \frac{\Gamma[3/2]}{\Gamma[|2\eta_H - 3|/2]} \right)^2 \epsilon_H,$$
 (3)

where  $\epsilon_H = 2(dH/d\phi)^2/H^2 = \dot{\phi}^2/(2H^2)$  is the first Hubble flow slow-roll parameter. If the contribution of  $\epsilon_H$  is negligible in Eq. (2), then the scalar spectral tilt remains unchanged with the replacement of  $\eta_H$  by  $\bar{\eta}_H = 3 - \eta_H$ . It is interesting to note that the tensor-to-scalar ratio also keeps the same under the interchange between  $\eta_H$  and  $\bar{\eta}_H$ . The behaviours of  $n_s$  and r under the swap between  $\eta_H$  and  $\bar{\eta}_H = -\alpha$  in the constant-roll inflation are called the duality between large and small  $\eta_H$  in the observables  $n_s$  and r [71, 72]. The duality connects the slow-roll inflation with  $|\eta_H| \ll 1$  and the USR inflation with  $\eta_H \approx 3$ , so it is useful for the understanding of PBH formation and SIGW generation by USR inflation from slow-roll inflation. If the contribution of  $\epsilon_H$  in Eq. (2) is not negligible, then the duality in  $n_s$  does not exist, and the background evolutions are also very different [70]. Therefore, it is important to further explore the duality between  $\eta_H$  and  $\bar{\eta}_H$ .

To see when  $\epsilon_H$  can be neglected, substituting  $\eta_H = 3 + \alpha$  into Eq. (2), we get

$$n_s - 1 \approx -2\alpha - \frac{2(2\alpha^2 + 3\alpha - 3)}{3 + 2\alpha} \epsilon_H,\tag{4}$$

where  $\alpha > -3/2$ . Therefore, the condition that the contribution of  $\epsilon_H$  is negligible is

<span id="page-2-1"></span>
$$\epsilon_H \ll \left| \frac{\alpha(3+2\alpha)}{2\alpha^2 + 3\alpha - 3} \right|.$$
(5)

For the USR inflation,  $|\alpha| \ll 1$ , the condition (5) means that  $\epsilon_H \ll |\alpha| \ll 1$ . Substituting  $\bar{\eta}_H = -\alpha$  into Eq. (2), we get

$$n_s - 1 \approx -2\alpha - \frac{2(2\alpha^2 - 9\alpha + 6)}{3 + 2\alpha} \epsilon_H. \tag{6}$$

For the case with  $\bar{\eta}_H$ , the condition that the contribution of  $\epsilon_H$  is negligible is

<span id="page-2-2"></span>
$$\epsilon_H \ll \left| \frac{\alpha(3+2\alpha)}{2\alpha^2 - 9\alpha + 6} \right|.$$
(7)

For slow-roll constant inflation with |α| ≪ 1, the condition [\(7\)](#page-2-2) becomes ǫ<sup>H</sup> ≪ |α|/2 ≪ 1. Combining the results [\(5\)](#page-2-1) and [\(7\)](#page-2-2), we see that the duality between the USR inflation with η<sup>H</sup> = 3 + α and the slow-roll constant inflation with ¯η<sup>H</sup> = −α holds when ǫ<sup>H</sup> ≪ |α|/2 ≪ 1.

Now we discuss the background evolution of the constant-roll inflation with negligible ǫH. From the background equation

$$3H^2 = \frac{1}{2}\dot{\phi}^2 + V(\phi),\tag{8}$$

we get

<span id="page-3-3"></span>
$$V(\phi) = (3 - \epsilon_H)H^2, \tag{9}$$

and

<span id="page-3-0"></span>
$$\frac{dV}{d\phi} = (3 - \eta_H)H^2 \frac{d\phi}{dN}.$$
 (10)

In terms of the number of e-folds N, dN = −Hdt, the equation of motion for the inflaton becomes

<span id="page-3-1"></span>
$$\frac{d^2\phi}{dN^2} + (\epsilon_H - 3)\frac{d\phi}{dN} + \frac{1}{H^2}\frac{dV}{d\phi} = 0.$$
 (11)

Combining Eqs. [\(10\)](#page-3-0) and [\(11\)](#page-3-1), we get

<span id="page-3-2"></span>
$$\frac{d^2\phi}{dN^2} + (\epsilon_H - \eta_H)\frac{d\phi}{dN} = 0.$$
 (12)

Eq. [\(12\)](#page-3-2) is just the definition [\(1\)](#page-1-1) of ηH. If ǫ<sup>H</sup> is negligible, then Eqs. [\(9\)](#page-3-3), [\(10\)](#page-3-0) and [\(12\)](#page-3-2) become

<span id="page-3-6"></span><span id="page-3-4"></span>
$$V(\phi) \approx 3H^2(\phi),\tag{13}$$

$$\frac{dV}{d\phi} \approx \frac{3 - \eta_H}{3} V(\phi) \frac{d\phi}{dN},\tag{14}$$

$$\frac{d^2\phi}{dN^2} - \eta_H \frac{d\phi}{dN} \approx 0. \tag{15}$$

The solution to Eq. [\(15\)](#page-3-4) is

<span id="page-3-5"></span>
$$\phi(N) \approx Ae^{\eta_H N} + B,\tag{16}$$

where A and B are integration constants. Substituting the solution [\(16\)](#page-3-5) into Eq. [\(14\)](#page-3-6), we get

$$\frac{dV}{V} \approx \frac{1}{3} \eta_H (3 - \eta_H) (\phi - B) d\phi. \tag{17}$$

So the potential is

<span id="page-3-7"></span>
$$V(\phi) \approx V_0 \exp\left[\frac{1}{3}\eta_H(3-\eta_H)\left(\frac{1}{2}\phi^2 - B\phi\right)\right],\tag{18}$$

and H<sup>2</sup> ≈ V (φ)/3, where V<sup>0</sup> is an integration constant. Therefore, if ǫ<sup>H</sup> is negligible, then the potential [\(18\)](#page-3-7) and the Hubble parameter H(φ) are unchanged under the transformation from η<sup>H</sup> to ¯η<sup>H</sup> = 3 − ηH, i.e., both H(φ) and V (φ) have the duality between η<sup>H</sup> and ¯ηH.

# <span id="page-4-0"></span>III. LOGARITHMIC DUALITY OF PRIMORDIAL CURVATURE PERTURBATION

From the definition [\(1\)](#page-1-1) of η<sup>H</sup> , we get

<span id="page-4-1"></span>
$$\frac{d^2H}{d\phi^2} - \frac{\eta_H}{2}H = 0. {19}$$

The solution to Eq. [\(19\)](#page-4-1) is

<span id="page-4-2"></span>
$$H(\phi) = C_1 \exp\left(\sqrt{\frac{\eta_H}{2}}\,\phi\right) + C_2 \exp\left(-\sqrt{\frac{\eta_H}{2}}\,\phi\right),\tag{20}$$

for η<sup>H</sup> > 0, and

<span id="page-4-3"></span>
$$H(\phi) = C_1 \cos\left(\sqrt{-\frac{\eta_H}{2}}\,\phi\right) + C_2 \sin\left(\sqrt{-\frac{\eta_H}{2}}\,\phi\right),\tag{21}$$

for η<sup>H</sup> < 0, where C<sup>1</sup> and C<sup>2</sup> are integration constants. Substituting the solutions [\(20\)](#page-4-2) and [\(21\)](#page-4-3) into Eq. [\(9\)](#page-3-3), we can obtain the potential V (φ). Therefore, the potential and the background evolution of the inflaton are determined by the parameter η<sup>H</sup> only for the constant-roll inflation with the slow-roll parameter η<sup>H</sup> being a constant [\[61\]](#page-13-6).

For the particular solution

<span id="page-4-5"></span>
$$H(\phi) = M \sinh\left(\sqrt{\frac{\eta_H}{2}}\phi\right),$$
 (22)

the potential is

<span id="page-4-6"></span>
$$V(\phi) = M^2 \left[ 3\sinh^2\left(\sqrt{\frac{\eta_H}{2}}\phi\right) - \eta_H \cosh^2\left(\sqrt{\frac{\eta_H}{2}}\phi\right) \right]. \tag{23}$$

In the small field approximation with |φ| ≪ 1, we get

<span id="page-4-4"></span>
$$V(\phi) \approx M^2 \left[ -\eta_H + \eta_H (3 - \eta_H) \frac{\phi^2}{2} \right]. \tag{24}$$

Because of the presence of the first term −η<sup>H</sup> in the right hand side of Eq. [\(24\)](#page-4-4), the duality between η<sup>H</sup> < 3 and ¯η<sup>H</sup> = 3 − η<sup>H</sup> does not hold in both H(φ) and V (φ) for the solutions [\(22\)](#page-4-5) and [\(23\)](#page-4-6). When η<sup>H</sup> > 3, the solution for ¯η<sup>H</sup> = 3 − η<sup>H</sup> < 0 is

<span id="page-4-7"></span>
$$H(\phi) = M \sin\left(\sqrt{-\frac{\bar{\eta}_H}{2}}\,\phi\right),\tag{25}$$

and the potential is

$$V(\phi) = M^2 \left[ 3\sin^2\left(\sqrt{-\frac{\bar{\eta}_H}{2}}\phi\right) + \bar{\eta}_H \cos^2\left(\sqrt{-\frac{\bar{\eta}_H}{2}}\phi\right) \right]. \tag{26}$$

In the small field approximation with |φ| ≪ 1, we get

<span id="page-5-0"></span>
$$V(\phi) \approx M^2 \left[ \bar{\eta}_H - \bar{\eta}_H (3 - \bar{\eta}_H) \frac{\phi^2}{2} \right]. \tag{27}$$

Due to the presence of the first term ¯η<sup>H</sup> in the right hand side of Eq. [\(27\)](#page-5-0), the duality between η<sup>H</sup> > 3 and ¯η<sup>H</sup> = 3 − η<sup>H</sup> does not hold for the solutions [\(25\)](#page-4-7) and [\(27\)](#page-5-0) either even in the small field approximation.

For the particular solution

<span id="page-5-5"></span>
$$H(\phi) = M \cosh\left(\sqrt{\frac{\eta_H}{2}}\phi\right),$$
 (28)

the potential is

<span id="page-5-4"></span>
$$V(\phi) = M^2 \left[ 3 \cosh^2 \left( \sqrt{\frac{\eta_H}{2}} \phi \right) - \eta_H \sinh^2 \left( \sqrt{\frac{\eta_H}{2}} \phi \right) \right]. \tag{29}$$

In the small field approximation with |φ| ≪ 1, we get

<span id="page-5-1"></span>
$$V(\phi) \approx M^2 \left[ 3 + \frac{1}{2} \eta_H (3 - \eta_H) \phi^2 \right].$$
 (30)

It is interesting to note that in the small field approximation with |φ| ≪ 1, the potential [\(30\)](#page-5-1) keeps to be the same if we change η<sup>H</sup> (0 < η<sup>H</sup> < 3) to ¯η<sup>H</sup> = 3 − ηH, i.e., there is a duality between η<sup>H</sup> and ¯η<sup>H</sup> in the potential [\(30\)](#page-5-1), but the duality does not exist in H(φ). If η<sup>H</sup> > 3, then ¯η<sup>H</sup> = 3 − η<sup>H</sup> < 0, the solution for ¯η<sup>H</sup> is

<span id="page-5-6"></span>
$$H(\phi) = M \cos\left(\sqrt{-\frac{\bar{\eta}_H}{2}}\phi\right),\tag{31}$$

and the potential is

<span id="page-5-3"></span>
$$V(\phi) = M^2 \left[ 3\cos^2\left(\sqrt{-\frac{\bar{\eta}_H}{2}}\phi\right) + \bar{\eta}_H \sin^2\left(\sqrt{-\frac{\bar{\eta}_H}{2}}\phi\right) \right]. \tag{32}$$

In the small field approximation with |φ| ≪ 1, we get

<span id="page-5-2"></span>
$$V(\phi) \approx M^2 \left[ 3 + \frac{1}{2} \bar{\eta}_H (3 - \bar{\eta}_H) \phi^2 \right].$$
 (33)

Therefore, in the small field approximation with  $|\phi| \ll 1$ , the potential (33) has the same form as (30) except that here  $\bar{\eta}_H < 0$ , and it seems that there exists the duality between  $\eta_H$  and  $\bar{\eta}_H = 3 - \eta_H$  in the potential (33). When  $\bar{\eta}_H < 0$ ,  $\eta_H = 3 - \bar{\eta}_H > 0$ , actually the potential (32) with  $\bar{\eta}_H < 0$  should be replaced by the potential (29) with  $\eta_H > 0$ , so there is no duality between  $\eta_H$  and  $\bar{\eta}_H = 3 - \eta_H$  in the potential (32) in the small field approximation. In fact, if we replace  $\eta_H = 3 + \alpha$  with  $\alpha > 0$  by  $\bar{\eta}_H = -\alpha$ , the solutions (28) and (29) should be replaced by the solutions (31) and (32), so the potential (30) is dual to the potential (33) under the interchange between  $\eta_H > 3$  and  $\bar{\eta}_H = 3 - \eta_H < 0$ .

Since logarithmic duality of the primordial curvature perturbation was found for the quadratic potential in Ref. [73], we will discuss whether the logarithmic duality exists in the constant-roll inflation for the particular solutions (30) and (33). If  $\epsilon_H \ll 1$  and  $\phi \ll 1$ , then substituting the potential (30) into Eq. (9), we get

$$H^2(\phi) \approx V(\phi)/3 \approx M^2.$$
 (34)

Plugging the potential (30) into Eq. (11) and neglecting  $\epsilon_H$ , we get

<span id="page-6-0"></span>
$$\frac{d^2\phi}{dN^2} - 3\frac{d\phi}{dN} + \eta_H(3 - \eta_H)\phi = 0.$$
 (35)

The solution is

<span id="page-6-1"></span>
$$\phi(N) = C_{+}e^{\lambda_{+}(N-N_{e})} + C_{-}e^{\lambda_{-}(N-N_{e})}, \tag{36}$$

where  $\lambda_{+}$  and  $\lambda_{-}$  are

$$\lambda_{+} = \frac{3 + \sqrt{9 - 4\eta_{H}(3 - \eta_{H})}}{2},$$

$$\lambda_{-} = \frac{3 - \sqrt{9 - 4\eta_{H}(3 - \eta_{H})}}{2},$$
(37)

and  $N_e$  is the number of e-folds at the end of inflation. Note that both  $\lambda_+$  and  $\lambda_-$  are invariant under the interchange between  $\eta_H$  and  $\bar{\eta}_H$ , and the inflationary model is not constant-roll inflation. Remember that for constant-roll inflation with negligible  $\epsilon_H$ , the equation of motion for the scalar field satisfies Eq. (15). Combining Eqs. (35) and (15), we get

$$\frac{d\phi}{dN} = \eta_H \phi, \tag{38}$$

$$\frac{d^2\phi}{dN^2} = \eta_H^2\phi. (39)$$

So the solution (36) is not the solution to constant-roll inflation, but we can still take  $\eta_H$  as a parameter even though it loses the meaning of the second slow-roll parameter as defined in Eq. (1) and think that the quadratic potentials (30) and (33) are motivated from constant-roll inflation. Now back to the solution (36), to determine the coefficients  $C_+$  and  $C_-$ , we use the velocity of the scalar field

$$\pi = -\frac{d\phi}{dN} = -C_{+}\lambda_{+}e^{\lambda_{+}(N-N_{e})} - C_{-}\lambda_{-}e^{\lambda_{-}(N-N_{e})}, \tag{40}$$

to get

$$C_{+} = -\frac{\lambda_{-}\phi_{e} + \pi_{e}}{\lambda_{+} - \lambda_{-}}, \quad C_{-} = \frac{\lambda_{+}\phi_{e} + \pi_{e}}{\lambda_{+} - \lambda_{-}}, \tag{41}$$

where  $\pi_e$  is the value of  $\pi(N)$  at  $N_e$ . Since  $\lambda_+$  and  $\lambda_-$  have the duality between  $\eta_H$  and  $\bar{\eta}_H$ , so  $C_+$  and  $C_-$  also have the duality between  $\eta_H$  and  $\bar{\eta}_H$ . If we swap  $\lambda_+$  and  $\lambda_-$ , then  $C_+$  and  $C_-$  are interchanged, and  $\phi(N)$  and  $\pi(N)$  are invariant. Therefore

$$e^{\lambda_{+}(N-N_{e})} = \frac{\lambda_{-}\phi + \pi}{\lambda_{-}\phi_{e} + \pi_{e}},$$

$$e^{\lambda_{-}(N-N_{e})} = \frac{\lambda_{+}\phi + \pi}{\lambda_{+}\phi_{e} + \pi_{e}},$$
(42)

<span id="page-7-0"></span>and

$$N - N_e = \frac{1}{\lambda_+} \ln \left( \frac{\lambda_- \phi + \pi}{\lambda_- \phi_e + \pi_e} \right)$$

$$= \frac{1}{\lambda_-} \ln \left( \frac{\lambda_+ \phi + \pi}{\lambda_+ \phi_e + \pi_e} \right).$$
(43)

Using the  $\delta N$  formalism [74–77], we get the primordial curvature perturbation

$$\zeta = \delta(N - N_e) 
= \frac{1}{\lambda_+} \ln \left( 1 + \frac{\lambda_- \delta \phi + \delta \pi}{\lambda_- \phi + \pi} \right) - \frac{1}{\lambda_+} \ln \left( 1 + \frac{\delta \pi_e}{\lambda_- \phi_e + \pi_e} \right) 
= \frac{1}{\lambda_-} \ln \left( 1 + \frac{\lambda_+ \delta \phi + \delta \pi}{\lambda_+ \phi + \pi} \right) - \frac{1}{\lambda_-} \ln \left( 1 + \frac{\delta \pi_e}{\lambda_+ \phi_e + \pi_e} \right).$$
(44)

It can be seen that under the interchange between  $\lambda_{+}$  and  $\lambda_{-}$ , the two formulae for the primordial curvature perturbation are equivalent and the equivalence is guaranteed by taking the perturbation on Eq. (42),

<span id="page-7-1"></span>
$$\left(1 + \frac{\delta \pi_e}{\pi_e + \lambda_+ \phi_e}\right)^{-\lambda_+} \left(1 + \frac{\delta \pi_e}{\pi_e + \lambda_- \phi_e}\right)^{\lambda_-} = \left(1 + \frac{\delta \pi + \lambda_- \delta \phi}{\pi + \lambda_- \phi}\right)^{\lambda_-} \left(1 + \frac{\delta \pi + \lambda_+ \delta \phi}{\pi + \lambda_+ \phi}\right)^{-\lambda_+}. (45)$$

The formula [\(45\)](#page-7-1) connects δπ<sup>e</sup> with δφ and δπ. In the same way, we can get the same result for the potential [\(33\)](#page-5-2). The result is the same as that found in [\[73](#page-14-4)] and is called logarithmic duality. Therefore, there exists the logarithmic duality and the duality between large and small η<sup>H</sup> for the primordial curvature perturbation in inflationary models with the potential [\(30\)](#page-5-1) and [\(33\)](#page-5-2).

### <span id="page-8-0"></span>IV. CONCLUSION

PBHs and accompanying SIGWs are usually generated in inflationary models with inflection point. Near the inflection point, the slow-roll parameter η<sup>H</sup> ≈ 3 and the inflation is also USR inflation which is a special case of the constant-roll inflation. For the constant-roll inflation, it is interesting that there is a duality between large and small η<sup>H</sup> in the observables n<sup>s</sup> and r if the slow-roll parameter ǫ<sup>H</sup> is negligible. The duality between η<sup>H</sup> and ¯η<sup>H</sup> = 3−η<sup>H</sup> connects the constant slow-roll inflation with |ηH| ≪ 1 and the USR inflation with η<sup>H</sup> ≈ 3, so the behavior of primordial curvature perturbations in USR inflation can be understood from the usual slow-roll inflation. However, the duality does not hold for the background evolution of the inflaton in general. If we neglect the contribution of ǫ<sup>H</sup> in the background evolution of the inflaton, we find that the inflaton potential has the duality between η<sup>H</sup> and ¯η<sup>H</sup> . We also derive the condition for neglecting ǫ<sup>H</sup> . In some particular solutions of constant-roll inflation and in the small field approximation, the inflaton potential takes a quadratic form and it remains the same under the interchange of the parameter η<sup>H</sup> and η¯H. When 0 < η<sup>H</sup> < 3, in the small field approximation, there is a duality between η<sup>H</sup> and ¯η<sup>H</sup> in the potential [\(30\)](#page-5-1), but there does not exist the duality in H(φ). When η<sup>H</sup> > 3 and ¯η<sup>H</sup> = 3 − η<sup>H</sup> < 0, if we replace η<sup>H</sup> by ¯η<sup>H</sup> , then the potential [\(30\)](#page-5-1) for η<sup>H</sup> > 3 should be replaced by the potential [\(33\)](#page-5-2) for ¯η<sup>H</sup> < 0. Even in the small field approximation, both the potentials [\(30\)](#page-5-1) and [\(33\)](#page-5-2) take the same quadratic form and are invariant under the interchange between η<sup>H</sup> and ¯η<sup>H</sup> , there does not exist the duality between η<sup>H</sup> and ¯η<sup>H</sup> in the potentials [\(30\)](#page-5-1) and [\(33\)](#page-5-2).

If we start with the quadratic potential [\(30\)](#page-5-1) and [\(33\)](#page-5-2) without the restriction on constantroll inflation, then using the δN formalism we find that the primordial curvature perturbation exhibits a logarithmic duality if we neglect the contribution of ǫ<sup>H</sup> . Since both λ<sup>−</sup> and λ<sup>+</sup> are invariant under the interchange between the parameter η<sup>H</sup> and ¯η<sup>H</sup> = 3 − η<sup>H</sup> , φ(N), π(N) and the primordial curvature perturbation also exhibit the duality between the parameters η<sup>H</sup> and ¯ηH.

### ACKNOWLEDGMENTS

This research is supported in part by the National Key Research and Development Program of China under Grant No. 2020YFC2201504, the National Natural Science Foundation of China under Grant No. 12175184 and the Chongqing Natural Science Foundation under Grant No. CSTB2022NSCQ-MSX1324.

- <span id="page-9-0"></span>[1] S. Bird, I. Cholis, J. B. Mu˜noz, Y. Ali-Ha¨ımoud, M. Kamionkowski, E. D. Kovetz, A. Raccanelli, and A. G. Riess, Did LIGO detect dark matter?, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.116.201301) 116, 201301 (2016).
- [2] M. Sasaki, T. Suyama, T. Tanaka, and S. Yokoyama, Primordial Black Hole Scenario for the Gravitational-Wave Event GW150914, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.117.061101) 117, 061101 (2016), [Erratum: Phys.Rev.Lett. 121, 059901 (2018)].
- <span id="page-9-3"></span>[3] K. Inomata, M. Kawasaki, K. Mukaida, Y. Tada, and T. T. Yanagida, Inflationary primordial black holes for the LIGO gravitational wave events and pulsar timing array experiments, Phys. Rev. D 95[, 123510 \(2017\).](https://doi.org/10.1103/PhysRevD.95.123510)
- [4] V. De Luca, V. Desjacques, G. Franciolini, P. Pani, and A. Riotto, GW190521 Mass Gap Event and the Primordial Black Hole Scenario, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.126.051101) 126, 051101 (2021).
- [5] V. De Luca, G. Franciolini, P. Pani, and A. Riotto, Bayesian Evidence for Both Astrophysical and Primordial Black Holes: Mapping the GWTC-2 Catalog to Third-Generation Detectors, [J. Cosmol. Astropart. Phys. 05 \(](https://doi.org/10.1088/1475-7516/2021/05/003)2021) 003.
- <span id="page-9-1"></span>[6] G. Franciolini, V. Baibhav, V. De Luca, K. K. Y. Ng, K. W. K. Wong, E. Berti, P. Pani, A. Riotto, and S. Vitale, Searching for a subpopulation of primordial black holes in LIGO-Virgo gravitational-wave data, Phys. Rev. D 105[, 083526 \(2022\).](https://doi.org/10.1103/PhysRevD.105.083526)
- <span id="page-9-2"></span>[7] V. De Luca, G. Franciolini, and A. Riotto, NANOGrav Data Hints at Primordial Black Holes as Dark Matter, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.126.041303) 126, 041303 (2021).
- [8] V. Vaskonen and H. Veerm¨ae, Did NANOGrav see a signal from primordial black hole formation?, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.126.051303) 126, 051303 (2021).

- [9] A. Afzal et al. (NANOGrav), The NANOGrav 15 yr Data Set: Search for Signals from New Physics, [Astrophys. J. Lett.](https://doi.org/10.3847/2041-8213/acdc91) 951, L11 (2023).
- <span id="page-10-0"></span>[10] J. Antoniadis et al. (EPTA), The second data release from the European Pulsar Timing Array: V. Implications for massive black holes, dark matter and the early Universe, [arXiv:2306.16227.](https://arxiv.org/abs/2306.16227)
- <span id="page-10-1"></span>[11] B. J. Carr and S. W. Hawking, Black holes in the early Universe, [Mon. Not. R. Astron. Soc.](https://doi.org/10.1093/mnras/168.2.399) 168, 399 (1974).
- <span id="page-10-2"></span>[12] S. Hawking, Gravitationally collapsed objects of very low mass, [Mon. Not. R. Astron. Soc.](https://doi.org/10.1093/mnras/152.1.75) 152, 75 (1971).
- <span id="page-10-3"></span>[13] S. Matarrese, S. Mollerach, and M. Bruni, Second order perturbations of the Einstein-de Sitter universe, Phys. Rev. D 58[, 043504 \(1998\).](https://doi.org/10.1103/PhysRevD.58.043504)
- [14] S. Mollerach, D. Harari, and S. Matarrese, CMB polarization from secondary vector and tensor modes, Phys. Rev. D 69[, 063002 \(2004\).](https://doi.org/10.1103/PhysRevD.69.063002)
- [15] K. N. Ananda, C. Clarkson, and D. Wands, The Cosmological gravitational wave background from primordial density perturbations, Phys. Rev. D 75[, 123518 \(2007\).](https://doi.org/10.1103/PhysRevD.75.123518)
- <span id="page-10-4"></span>[16] D. Baumann, P. J. Steinhardt, K. Takahashi, and K. Ichiki, Gravitational Wave Spectrum Induced by Primordial Scalar Perturbations, Phys. Rev. D 76[, 084019 \(2007\).](https://doi.org/10.1103/PhysRevD.76.084019)
- [17] J. Garcia-Bellido, M. Peloso, and C. Unal, Gravitational Wave signatures of inflationary models from Primordial Black Hole Dark Matter, [J. Cosmol. Astropart. Phys. 09 \(](https://doi.org/10.1088/1475-7516/2017/09/013)2017) 013.
- [18] R. Saito and J. Yokoyama, Gravitational wave background as a probe of the primordial black hole abundance, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.102.161101) 102, 161101 (2009), [Erratum: Phys.Rev.Lett. 107, 069901 (2011)].
- [19] R. Saito and J. Yokoyama, Gravitational-Wave Constraints on the Abundance of Primordial Black Holes, [Prog. Theor. Phys.](https://doi.org/10.1143/PTP.126.351) 123, 867 (2010), [Erratum: Prog.Theor.Phys. 126, 351–352 (2011)].
- [20] E. Bugaev and P. Klimai, Induced gravitational wave background and primordial black holes, Phys. Rev. D 81[, 023517 \(2010\).](https://doi.org/10.1103/PhysRevD.81.023517)
- [21] E. Bugaev and P. Klimai, Constraints on the induced gravitational wave background from primordial black holes, Phys. Rev. D 83[, 083521 \(2011\).](https://doi.org/10.1103/PhysRevD.83.083521)
- [22] L. Alabidi, K. Kohri, M. Sasaki, and Y. Sendouda, Observable Spectra of Induced Gravitational Waves from Inflation, [J. Cosmol. Astropart. Phys. 09 \(](https://doi.org/10.1088/1475-7516/2012/09/017)2012) 017.
- [23] K. Inomata, K. Kohri, T. Nakama, and T. Terada, Enhancement of Gravitational Waves

- Induced by Scalar Perturbations due to a Sudden Transition from an Early Matter Era to the Radiation Era, Phys. Rev. D 100[, 043532 \(2019\),](https://doi.org/10.1103/PhysRevD.108.049901) [Erratum: Phys.Rev.D 108, 049901 (2023)].
- [24] M. Braglia, X. Chen, and D. K. Hazra, Probing Primordial Features with the Stochastic Gravitational Wave Background, [J. Cosmol. Astropart. Phys. 03 \(](https://doi.org/10.1088/1475-7516/2021/03/005)2021) 005.
- [25] Z. Yi, Primordial black holes and scalar-induced gravitational waves from the generalized Brans-Dicke theory, [J. Cosmol. Astropart. Phys. 03 \(](https://doi.org/10.1088/1475-7516/2023/03/048)2023) 048.
- [26] N. Orlofsky, A. Pierce, and J. D. Wells, Inflationary theory and pulsar timing investigations of primordial black holes and gravitational waves, Phys. Rev. D 95[, 063518 \(2017\).](https://doi.org/10.1103/PhysRevD.95.063518)
- [27] T. Nakama, J. Silk, and M. Kamionkowski, Stochastic gravitational waves associated with the formation of primordial black holes, Phys. Rev. D 95[, 043511 \(2017\).](https://doi.org/10.1103/PhysRevD.95.043511)
- [28] S.-L. Cheng, W. Lee, and K.-W. Ng, Primordial black holes and associated gravitational waves in axion monodromy inflation, [J. Cosmol. Astropart. Phys. 07 \(](https://doi.org/10.1088/1475-7516/2018/07/001)2018) 001.
- [29] R.-g. Cai, S. Pi, and M. Sasaki, Gravitational Waves Induced by non-Gaussian Scalar Perturbations, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.122.201101) 122, 201101 (2019).
- [30] N. Bartolo, V. De Luca, G. Franciolini, M. Peloso, D. Racco, and A. Riotto, Testing primordial black holes as dark matter with LISA, Phys. Rev. D 99[, 103521 \(2019\).](https://doi.org/10.1103/PhysRevD.99.103521)
- [31] N. Bartolo, V. De Luca, G. Franciolini, A. Lewis, M. Peloso, and A. Riotto, Primordial Black Hole Dark Matter: LISA Serendipity, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.122.211301) 122, 211301 (2019).
- [32] K. Kohri and T. Terada, Semianalytic calculation of gravitational wave spectrum nonlinearly induced from primordial curvature perturbations, Phys. Rev. D 97[, 123532 \(2018\).](https://doi.org/10.1103/PhysRevD.97.123532)
- [33] J. R. Espinosa, D. Racco, and A. Riotto, A Cosmological Signature of the SM Higgs Instability: Gravitational Waves, [J. Cosmol. Astropart. Phys. 09 \(](https://doi.org/10.1088/1475-7516/2018/09/012)2018) 012.
- [34] R.-G. Cai, S. Pi, S.-J. Wang, and X.-Y. Yang, Resonant multiple peaks in the induced gravitational waves, [J. Cosmol. Astropart. Phys. 05 \(](https://doi.org/10.1088/1475-7516/2019/05/013)2019) 013.
- [35] R.-G. Cai, S. Pi, S.-J. Wang, and X.-Y. Yang, Pulsar Timing Array Constraints on the Induced Gravitational Waves, [J. Cosmol. Astropart. Phys. 10 \(](https://doi.org/10.1088/1475-7516/2019/10/059)2019) 059.
- [36] R.-G. Cai, Z.-K. Guo, J. Liu, L. Liu, and X.-Y. Yang, Primordial black holes and gravitational waves from parametric amplification of curvature perturbations, [J. Cosmol. Astropart. Phys. 06 \(](https://doi.org/10.1088/1475-7516/2020/06/013)2020) 013.
- [37] R.-G. Cai, Y.-C. Ding, X.-Y. Yang, and Y.-F. Zhou, Constraints on a mixed model of dark matter particles and primordial black holes from the galactic 511 keV line,

- [J. Cosmol. Astropart. Phys. 03 \(](https://doi.org/10.1088/1475-7516/2021/03/057)2021) 057.
- [38] G. Dom`enech, Induced gravitational waves in a general cosmological background, [Int. J. Mod. Phys. D](https://doi.org/10.1142/S0218271820500285) 29, 2050028 (2020).
- [39] G. Dom`enech, S. Pi, and M. Sasaki, Induced gravitational waves as a probe of thermal history of the universe, [J. Cosmol. Astropart. Phys. 08 \(](https://doi.org/10.1088/1475-7516/2020/08/017)2020) 017.
- [40] S. Pi and M. Sasaki, Gravitational Waves Induced by Scalar Perturbations with a Lognormal Peak, [J. Cosmol. Astropart. Phys. 09 \(](https://doi.org/10.1088/1475-7516/2020/09/037)2020) 037.
- [41] C. Germani and T. Prokopec, On primordial black holes from an inflection point, [Phys. Dark Univ.](https://doi.org/10.1016/j.dark.2017.09.001) 18, 6 (2017).
- [42] J. M. Ezquiaga, J. Garcia-Bellido, and E. Ruiz Morales, Primordial Black Hole production in Critical Higgs Inflation, [Phys. Lett. B](https://doi.org/10.1016/j.physletb.2017.11.039) 776, 345 (2018).
- [43] G. Ballesteros and M. Taoso, Primordial black hole dark matter from single field inflation, Phys. Rev. D 97[, 023501 \(2018\).](https://doi.org/10.1103/PhysRevD.97.023501)
- [44] T.-J. Gao and Z.-K. Guo, Primordial Black Hole Production in Inflationary Models of Supergravity with a Single Chiral Superfield, Phys. Rev. D 98[, 063526 \(2018\).](https://doi.org/10.1103/PhysRevD.98.063526)
- [45] I. Dalianis, S. Karydas, and E. Papantonopoulos, Generalized Non-Minimal Derivative Coupling: Application to Inflation and Primordial Black Hole Production, [J. Cosmol. Astropart. Phys. 06 \(](https://doi.org/10.1088/1475-7516/2020/06/040)2020) 040.
- [46] G. Ballesteros, J. Beltran Jimenez, and M. Pieroni, Black hole formation from a general quadratic action for inflationary primordial fluctuations, [J. Cosmol. Astropart. Phys. 06 \(](https://doi.org/10.1088/1475-7516/2019/06/016)2019) 016.
- [47] Y. Lu, Y. Gong, Z. Yi, and F. Zhang, Constraints on primordial curvature perturbations from primordial black hole dark matter and secondary gravitational waves, [J. Cosmol. Astropart. Phys. 12 \(](https://doi.org/10.1088/1475-7516/2019/12/031)2019) 031.
- [48] S. Passaglia, W. Hu, and H. Motohashi, Primordial black holes and local non-Gaussianity in canonical inflation, Phys. Rev. D 99[, 043536 \(2019\).](https://doi.org/10.1103/PhysRevD.99.043536)
- [49] C. Fu, P. Wu, and H. Yu, Primordial Black Holes from Inflation with Nonminimal Derivative Coupling, Phys. Rev. D 100[, 063532 \(2019\).](https://doi.org/10.1103/PhysRevD.100.063532)
- [50] J. Lin, Q. Gao, Y. Gong, Y. Lu, C. Zhang, and F. Zhang, Primordial black holes and secondary gravitational waves from k and G inflation, Phys. Rev. D 101[, 103515 \(2020\).](https://doi.org/10.1103/PhysRevD.101.103515)
- [51] Z. Yi, Y. Gong, B. Wang, and Z.-h. Zhu, Primordial black holes and secondary gravitational

- waves from the Higgs field, Phys. Rev. D 103[, 063535 \(2021\).](https://doi.org/10.1103/PhysRevD.103.063535)
- [52] Z. Yi, Q. Gao, Y. Gong, and Z.-h. Zhu, Primordial black holes and scalar-induced secondary gravitational waves from inflationary models with a noncanonical kinetic term, Phys. Rev. D 103[, 063534 \(2021\).](https://doi.org/10.1103/PhysRevD.103.063534)
- <span id="page-13-0"></span>[53] Z. Wang, S. Gao, Y. Gong, and Y. Wang, Primordial black holes and scalar-induced gravitational waves from the polynomial attractor model, [arXiv:2401.16069.](https://arxiv.org/abs/2401.16069)
- <span id="page-13-1"></span>[54] H. Di and Y. Gong, Primordial black holes and second order gravitational waves from ultraslow-roll inflation, [J. Cosmol. Astropart. Phys. 07 \(](https://doi.org/10.1088/1475-7516/2018/07/007)2018) 007.
- [55] J. R. Espinosa, D. Racco, and A. Riotto, Cosmological Signature of the Standard Model Higgs Vacuum Instability: Primordial Black Holes as Dark Matter, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.120.121301) 120, 121301 (2018).
- [56] J. Garcia-Bellido and E. Ruiz Morales, Primordial black holes from single field models of inflation, [Phys. Dark Univ.](https://doi.org/10.1016/j.dark.2017.09.007) 18, 47 (2017).
- <span id="page-13-2"></span>[57] M. Sasaki, T. Suyama, T. Tanaka, and S. Yokoyama, Primordial black holes—perspectives in gravitational wave astronomy, [Classical Quantum Gravity](https://doi.org/10.1088/1361-6382/aaa7b4) 35, 063001 (2018).
- <span id="page-13-3"></span>[58] N. C. Tsamis and R. P. Woodard, Improved estimates of cosmological perturbations, Phys. Rev. D 69[, 084005 \(2004\).](https://doi.org/10.1103/PhysRevD.69.084005)
- <span id="page-13-4"></span>[59] W. H. Kinney, Horizon crossing and inflation with large eta, Phys. Rev. D 72[, 023515 \(2005\).](https://doi.org/10.1103/PhysRevD.72.023515)
- <span id="page-13-5"></span>[60] J. Martin, H. Motohashi, and T. Suyama, Ultra Slow-Roll Inflation and the non-Gaussianity Consistency Relation, Phys. Rev. D 87[, 023514 \(2013\).](https://doi.org/10.1103/PhysRevD.87.023514)
- <span id="page-13-6"></span>[61] H. Motohashi, A. A. Starobinsky, and J. Yokoyama, Inflation with a constant rate of roll, [J. Cosmol. Astropart. Phys. 09 \(](https://doi.org/10.1088/1475-7516/2015/09/018)2015) 018.
- [62] S. M. Leach and A. R. Liddle, Inflationary perturbations near horizon crossing, Phys. Rev. D 63[, 043508 \(2001\).](https://doi.org/10.1103/PhysRevD.63.043508)
- [63] S. M. Leach, M. Sasaki, D. Wands, and A. R. Liddle, Enhancement of superhorizon scale inflationary curvature perturbations, Phys. Rev. D 64[, 023512 \(2001\).](https://doi.org/10.1103/PhysRevD.64.023512)
- [64] R. K. Jain, P. Chingangbam, and L. Sriramkumar, On the evolution of tachyonic perturbations at super-Hubble scales, [J. Cosmol. Astropart. Phys. 10 \(](https://doi.org/10.1088/1475-7516/2007/10/003)2007) 003.
- [65] M. H. Namjoo, H. Firouzjahi, and M. Sasaki, Violation of non-Gaussianity consistency relation in a single field inflationary model, EPL 101[, 39001 \(2013\).](https://doi.org/10.1209/0295-5075/101/39001)
- <span id="page-13-7"></span>[66] Z. Yi and Y. Gong, On the constant-roll inflation, [J. Cosmol. Astropart. Phys. 03 \(](https://doi.org/10.1088/1475-7516/2018/03/052)2018) 052.

- <span id="page-14-0"></span>[67] H. Motohashi and A. A. Starobinsky, Constant-roll inflation: confrontation with recent observational data, EPL 117[, 39001 \(2017\).](https://doi.org/10.1209/0295-5075/117/39001)
- [68] Q. Gao, The observational constraint on constant-roll inflation, [Sci. China Phys. Mech. Astron.](https://doi.org/10.1007/s11433-018-9197-2) 61, 070411 (2018).
- [69] J. T. Galvez Ghersi, A. Zucca, and A. V. Frolov, Observational Constraints on Constant Roll Inflation, [J. Cosmol. Astropart. Phys. 05 \(](https://doi.org/10.1088/1475-7516/2019/05/030)2019) 030.
- <span id="page-14-1"></span>[70] Q. Gao, Y. Gong, and Z. Yi, On the constant-roll inflation with large and small ηH, Universe 5[, 215 \(2019\).](https://doi.org/10.3390/universe5110215)
- <span id="page-14-2"></span>[71] K. Tzirakis and W. H. Kinney, Inflation over the hill, Phys. Rev. D 75[, 123510 \(2007\).](https://doi.org/10.1103/PhysRevD.75.123510)
- <span id="page-14-3"></span>[72] M. J. P. Morse and W. H. Kinney, Large-η constant-roll inflation is never an attractor, Phys. Rev. D 97[, 123519 \(2018\).](https://doi.org/10.1103/PhysRevD.97.123519)
- <span id="page-14-4"></span>[73] S. Pi and M. Sasaki, Logarithmic Duality of the Curvature Perturbation, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.131.011002) 131, 011002 (2023).
- <span id="page-14-5"></span>[74] M. Sasaki and E. D. Stewart, A General analytic formula for the spectral index of the density perturbations produced during inflation, [Prog. Theor. Phys.](https://doi.org/10.1143/PTP.95.71) 95, 71 (1996).
- [75] D. Wands, K. A. Malik, D. H. Lyth, and A. R. Liddle, A New approach to the evolution of cosmological perturbations on large scales, Phys. Rev. D 62[, 043527 \(2000\).](https://doi.org/10.1103/PhysRevD.62.043527)
- [76] D. H. Lyth, K. A. Malik, and M. Sasaki, A General proof of the conservation of the curvature perturbation, [J. Cosmol. Astropart. Phys. 05 \(](https://doi.org/10.1088/1475-7516/2005/05/004)2005) 004.
- <span id="page-14-6"></span>[77] N. S. Sugiyama, E. Komatsu, and T. Futamase, δN formalism, Phys. Rev. D 87[, 023530 \(2013\).](https://doi.org/10.1103/PhysRevD.87.023530)