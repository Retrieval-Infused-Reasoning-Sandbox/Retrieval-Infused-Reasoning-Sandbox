# TianQin: a space-borne gravitational wave detector

Jun Luo<sup>1</sup>[∗](#page-0-0) , Li-Sheng Chen<sup>4</sup> , Hui-Zong Duan<sup>2</sup> , Yun-Gui Gong<sup>2</sup> , Shoucun Hu<sup>6</sup> , Jianghui Ji<sup>6</sup> , Qi Liu<sup>2</sup> , Jianwei Mei<sup>2</sup> , Vadim Milyukov<sup>3</sup> , Mikhail Sazhin<sup>3</sup> , Cheng-Gang Shao<sup>2</sup> , Viktor T. Toth<sup>8</sup> , Hai-Bo Tu<sup>5</sup> , Yamin Wang<sup>7</sup> , Yan Wang<sup>2</sup> , Hsien-Chi Yeh<sup>2</sup> , Ming-Sheng Zhan<sup>4</sup> , Yonghe Zhang<sup>6</sup> , Vladimir Zharov<sup>3</sup> , Ze-Bing Zhou<sup>2</sup>

> <sup>1</sup>School of Physics and Astronomy, Sun Yat-Sen University, 135 West Xingang Rd., Guangzhou 510275, P.R. China

<sup>2</sup>MoE Key Laboratory of Fundamental Quantities Measurement, School of Physics, Huazhong University of Science and Technology, 1037 Luoyu Rd., Wuhan 430074, P.R. China <sup>3</sup>Lomonosov Moscow State University, Sternberg Astronomical Institute, Moscow 119992, Russia <sup>4</sup>Wuhan Institute of Physics and Mathematics, Chinese Academy of Sciences, 30 West Xiao Hong Shan, Wuhan 430071, P.R. China

> 5 Institute of Geodesy and Geophysics, Chinese Academy of Sciences, 340 XuDong Rd., Wuhan 430077, P.R. China

<sup>6</sup>Key Laboratory of Planetary Sciences, Purple Mountain Observatory, Chinese Academy of Sciences, 2 West Beijing Rd., Nanjing 210008, P.R. China

> <sup>7</sup>Shanghai Engineering Center for Microsatellites, Building 4, 99 Haike Rd., Shanghai 201203, P.R. China

> > <sup>8</sup>Ottawa, Ontario, K1N 9H5, Canada

#### Abstract

TianQin is a proposal for a space-borne detector of gravitational waves in the millihertz frequencies. The experiment relies on a constellation of three drag-free spacecraft orbiting the Earth. Inter-spacecraft laser interferometry is used to monitor the distances between the test masses. The experiment is designed to be capable of detecting a signal with high confidence from a single source of gravitational waves within a few months of observing time. We describe the preliminary mission concept for TianQin, including the candidate source and experimental designs. We present estimates for the major constituents of the

<span id="page-0-0"></span><sup>∗</sup>Email: junluo@sysu.edu.cn

experiment's error budget and discuss the project's overall feasibility. Given the current level of technology readiness, we expect TianQin to be flown in the second half of the next decade.

# Contents

| 1 | Introduction                            | 3  |  |  |
|---|-----------------------------------------|----|--|--|
| 2 | Preliminary mission concept             |    |  |  |
|   | 2.1<br>The reference source<br>         | 9  |  |  |
|   | 2.2<br>Spacecraft orbit                 | 11 |  |  |
| 3 | Sensitivity goal                        | 14 |  |  |
| 4 | Error budget for the key components     | 17 |  |  |
|   | 4.1<br>Laser interferometer<br>         | 19 |  |  |
|   | 4.2<br>Disturbance reduction system<br> | 20 |  |  |
| 5 | Technology status                       | 25 |  |  |
|   | 5.1<br>Laser interferometer<br>         | 25 |  |  |
|   | 5.2<br>Disturbance reduction system<br> | 26 |  |  |
| 6 | Summary and Outlook                     | 27 |  |  |

# <span id="page-2-0"></span>1 Introduction

The existence of gravitational waves (GWs) is a remarkable prediction of Einstein's general theory of relativity. GWs not only offer an important way to test the foundations of general relativity, they are expected to provide a unique and entirely new way to observe and study the Universe. Although the existence of GWs is confirmed indirectly by binary pulsars [\[1\]](#page-27-0), to date GWs have not been directly observed. Current efforts aiming at direct detection of gravitational waves include several on-going laser interferometer projects on the ground [\[2,](#page-27-1) [3,](#page-27-2) [4\]](#page-27-3) and various proposals for detectors in space (see, e.g., [\[5,](#page-28-0) [6,](#page-28-1) [7,](#page-28-2) [8,](#page-28-3) [9,](#page-28-4) [10\]](#page-28-5)). Pulsar timing arrays are being used to search for GW signals from astrophysical sources [\[11,](#page-28-6) [12,](#page-28-7) [13,](#page-28-8) [14\]](#page-28-9), and the cosmic microwave background is being investigated for signatures of primordial GWs [\[15\]](#page-28-10). In addition, several upgraded versions of the renowned Weber bar detectors have also continued until very recently [\[16,](#page-28-11) [17,](#page-28-12) [18\]](#page-28-13).

In this paper, we discuss a new proposal for a space-borne experiment, TianQin[1](#page-3-0) , aiming to detect gravitational waves in the millihertz (mHz) range (i.e., 0.1 − 100 mHz). GWs in this frequency range could come from a plethora of important astronomical sources, such as ultra-compact galactic binaries, coalescing massive black holes, and from the capture of stellar objects by massive black holes, all of which are exciting. Therefore, in addition to testing gravitational theories under extreme conditions, direct detection of GWs will also unleash the entirely new field of gravitational wave astronomy.

A unique feature of our proposal is that TianQin's instrument and mission designs, the detector's overall response, as well as the data analysis algorithms will be optimized to detect the GW signal from a single most promising source of gravitational radiation (which we shall call the reference source). Although instrument sensitivity would allow TianQin to detect signals from other sources, accommodating such detections could unnecessarily complicate the instrumental and mission designs, put demands on the technology and complicate data analysis efforts, thereby increasing the overall mission costs.

Accordingly, instead of designing TianQin as a gravitational wave observatory capable of studying GWs from a diversity of both known and yet-to-be discovered sources, the design emphasis is placed on the development of a space-borne detector of gravitational radiation from a single well-understood reference source. The primary goal of TianQin is a direct detection of gravitational waves with anticipated properties from this source [\[19\]](#page-29-0), as we will learn how to operate the detector and use it to study the source in great detail.

Our strategy for implementing TianQin is two-pronged. First, we shall identify the strongest source of GWs in the appropriate frequency band and study it with multi-spectral observational tools. Knowledge of the source will help refine the instrumental and mission requirements and focus the overall mission design. Second, we shall, as much as possible, rely on technologies that are readily available or being at advanced stages of development. This will allow us to concentrate our efforts on the development of the two key systems: the laser interferometer and the disturbance reduction system.

<span id="page-3-0"></span>For the reference source, there is a set of ultra compact galactic binaries (known as

<sup>1</sup> In Chinese, TianQin means a musical instrument, namely a zither, in space. The TianQin experiment is metaphorically seen as a zither that is being played by the Nature itself through gravitational waves.

LISA verification binaries [\[20\]](#page-29-1)) that have been identified to verify the performance of the proposed eLISA instruments [\[10\]](#page-28-5). TianQin is sensitive to the same frequency range, thus the LISA verification binaries are natural candidates as TianQin reference sources. At the moment, RX J0806.3+1527 (also known as HM Cancri or HM Cnc, hereafter J0806) stands out as the best choice, due to its orbital period that is the shortest known to date for a binary system, its relative proximity to the Sun and its moderate component masses.

TianQin is a constellation of three Earth-orbiting spacecraft in a nearly equilateral triangle formation. As shown in later sections, a source like J0806 is strong enough that relatively short arm lengths (∼ 10<sup>5</sup> km) can be used for the laser interferometer. Compared to heliocentric orbits, the choice of easily accessible geocentric orbits allows the use of more readily available spacecraft technologies, significantly reducing overall mission cost. Most of the existing proposals for space-borne GW antennas have prohibitively high costs, affecting the feasibility of these projects. Our estimates show that the cost for TianQin will be in the more affordable range of USD 550-800 million. This reduced mission cost is made possible by our strategy of building a GW detector rather than an observatory.

Similar to other proposals for space-borne gravitational wave experiments (notably, [\[5,](#page-28-0) [6,](#page-28-1) [7,](#page-28-2) [8,](#page-28-3) [9,](#page-28-4) [10\]](#page-28-5)), TianQin relies on laser interferometry to monitor distance variations between test masses situated inside the spacecraft forming the constellation. The test masses themselves will be subject to various sources of non-gravitational noise, originating both on-board and external to the spacecraft. Thus, a highly efficient disturbance reduction system will be required to reduce the effect of non-gravitational forces on test masses, which will then follow nearly free-fall trajectories, encoding information of transiting gravitational waves. To reduce the contributions of various sources of instrumental noise (primarily laser frequency noise), the data analysis will rely on time delay interferometry (TDI, see [\[21\]](#page-29-2) for a review) implemented on board each spacecraft.

In this paper we present the preliminary concept for TianQin and address the main features of its mission design. This paper is organized as follows: In Section [2,](#page-5-0) we introduce the preliminary concept of TianQin. In Section [3,](#page-13-0) we discuss the sensitivity goal of TianQin and the requirement on the two key components: the laser interferometer and the disturbance reduction system. The projected error budget for these two key components is discussed in Section [4,](#page-16-0) whereas Section [5](#page-24-0) offers a brief review of the current status of these key technologies. In Section [6](#page-26-0) we present a discussion of the road map towards implementing TianQin and offer conclusions.

# <span id="page-5-0"></span>2 Preliminary mission concept

The design for TianQin is guided by the desire to develop an experiment that can be built and launched within a relatively short period of time. An important step towards implementing such an approach is a realistic assessment of the level of the currently available technologies, identification of technology gaps, and initiating efforts to eliminate these gaps. Before discussing the required technologies, we present the current mission concept for TianQin, which relies on three identical spacecraft, placed on nearly identical geocentric orbits with semi-major axis of ∼ 10<sup>5</sup> km, and forming a nearly equilateral triangle. Easily accessible geocentric orbits have been adopted in several other proposals for space-borne gravitational waves observatories. Notably, these include OMEGA [\[8,](#page-28-3) [9\]](#page-28-4), LAGRANGE [\[9\]](#page-28-4), and gLISA [\[23\]](#page-29-3). The major advantage of geocentric orbits is a significant reduction in operational costs.

Each spacecraft will be equipped with a laser system capable of sending and receiving laser signals to and from the other two TianQin constellation spacecraft. A heterodyne laser interferometer will be used to monitor distance variations between the spacecraft. Each spacecraft can be chosen as the center spacecraft of the laser interferometer, while the other two become the endpoints of the two interferometer baselines.

The spacecraft will each have a disturbance reduction system (DRS) needed to reduce the effects of the non-gravitational forces on the test masses (which are the reference points for the laser interferometer). As the orbital semi-major axes are ∼ 10<sup>5</sup> km in length, the arm lengths of the laser interferometer are also similar in size. The detector plane is chosen to face the reference source. Narrowband band-pass solar filters will be used to block sunlight from entering the telescopes, and active thermal control is planned to keep thermal fluctuations at the acceptable level. The orbits of the spacecraft and observational windows will be designed to further reduce the thermal impact on the spacecraft subsystems

![](_page_6_Picture_0.jpeg)

Figure 1: An illustration of the preliminary concept of TianQin, with J0806 being the reference source. The three TianQin spacecraft are denoted as SC1, SC2 and SC3. The plane of the celestial equator is also shown, together with the direction to J0806 in the sky.

<span id="page-6-0"></span>that may affect the optical path length, e.g., by imposing a sufficient Sun exclusion angle, and if justified, also taking into account effects from Earthshine. An illustration of TianQin with a tentative reference source is shown in Fig. [1.](#page-6-0)

TianQin is benefiting from a number of existing proposals for space-borne gravitational waves detectors [\[5,](#page-28-0) [6,](#page-28-1) [7,](#page-28-2) [8,](#page-28-3) [9,](#page-28-4) [10\]](#page-28-5). The extensive literature on LISA verification binaries [\[20,](#page-29-1) [22\]](#page-29-4) has greatly simplified the task of identifying a possible reference source for TianQin. The use of three identical spacecraft in a nearly equilateral triangle formation, the scheme for the laser interferometer, and many aspects of the DRS closely mimic those of LISA [\[5\]](#page-28-0). The proposed use of narrowband band-pass solar filters in OMEGA [\[9\]](#page-28-4) has encouraged us to do the same for TianQin. Apart from these, however, TianQin has its own unique design features.

To simplify the mission design and reduce technological difficulties as much as possible, the sensitivity of TianQin is set to be just enough to detect the most accessible source. The source should be both strong and permanently available, preferably having a short period. (A shorter period can make it easier for the laser interferometer and the inertial sensor to achieve their desired precision goal in the mHz range.) Checked against these requirements, J0806 stands out as the most suitable choice among all the known sources. Therefore, for now we will use J0806 as a tentative reference source to map out the details of various aspects of the experiment. In Sec. [2.1](#page-8-0) we discuss J0806 in more detail. It should be emphasized, however, that the ultimate choice for the reference source for TianQin is still open and will be refined as time progresses.

We wish to be able to claim a detection within a relatively short period of time, currently identified as approximately three months. This choice of a duration is motivated by an advantageous characteristic of the chosen reference source. As J0806 lies at ∼ 4.7 ◦ from the plane of the ecliptic, the detector plane is nearly vertical to the ecliptic plane. There are two relatively quiet time windows each year when the direction of the Sun is at a large angle relative to the detector plane (Fig. [1\)](#page-6-0). During these times, the amount of sunlight that may enter the telescopes is minimal, which simplifies thermal control. Between these time windows, however, the Sun is near the detector plane, leading to direct sunlight entering the telescopes, causing significant thermal load on the optical system. In this situation, one would have to rely on solar filters and active thermal control to enable continuous science operations of the interferometer throughout the year. Choosing instead a three-month science run, it is possible to operate the constellation only during periods of time when such thermal control is not needed.

The accuracy requirements for the TianQin mission are estimated as <sup>√</sup> S<sup>x</sup> ∼ 1 pm/Hz<sup>1</sup>/<sup>2</sup> for position and <sup>√</sup> S<sup>a</sup> ∼ 10<sup>−</sup><sup>15</sup> m s<sup>−</sup><sup>2</sup>/Hz<sup>1</sup>/<sup>2</sup> for residual acceleration measurements. For a source like J0806 (with parameters given in Table [2,](#page-9-0) assuming a distance of D˜ = 5 kpc from the Sun) and arm lengths of L ∼ 10<sup>5</sup> km, a signal-to-noise ratio (SNR) of 10 is possible in three months of integration time.

We must also consider the stability of orbits to be used. For example, the influence of the Moon on the dynamics of orbits becomes more significant as their semi-major axes increase beyond 1 × 10<sup>5</sup> km. We will discuss the chosen orbits in Sec. [2.2.](#page-10-0)

Although the instruments of TianQin will have the capability to observe sources within a wide range of frequency, at least initially, we will operate the constellation in "detector mode", listening for a signal with a known frequency and phase from a pre-selected reference source. When the frequency and phase of the signal that is to be detected are known in advance, a phase-locked detection scheme can be used to help confirm the presence of

| Parameter                      | Value                          |
|--------------------------------|--------------------------------|
| Number of spacecraft           | N<br>= 3                       |
| Constellation                  | Equilateral triangle           |
| Type of orbit                  | Geocentric                     |
| Arm length                     | 105 km<br>∼<br>L               |
| Position measurement accuracy  | 1 pm/Hz1/2 @ 6 mHz             |
| Residual acceleration accuracy | 2/Hz1/2 @ 6 mHz<br>10−15 m/s   |
| Observation windows            | 2<br>×<br>(3 months) each year |
| Laser wavelength               | λ<br>= 1064 nm                 |
| Optical power                  | Pout<br>= 4 W                  |
| Telescope diameter             | D<br>= 20 cm                   |
| Optical efficiency             | ηopt<br>= 70%                  |

<span id="page-8-1"></span>Table 1: TianQin basic mission parameters.

the signal with high sensitivity. This offers a high degree of confidence that TianQin will achieve its primary mission objective: confirmation of the presence of anticipated mHz gravitational waves by direct detection.

Nonetheless, to achieve some design margin and to leave open the possibility of using TianQin as a GW observatory (perhaps in an extended mission), we aim for SNR = 10 in the construction of the preliminary mission concept.

A brief summary of the basic TianQin mission parameters is provided in Table [1.](#page-8-1)

### <span id="page-8-0"></span>2.1 The reference source

J0806 was discovered as a luminous soft X-ray source in the ROSAT all-sky survey [\[25,](#page-29-5) [26\]](#page-29-6). It has been the subject of intense scrutiny in the form of X-ray [\[27,](#page-29-7) [28\]](#page-29-8) and optical observations [\[29,](#page-29-9) [30,](#page-29-10) [31\]](#page-29-11), due to the fact that, to date, it is the strongest known emitter of periodic GWs in the low frequency band of 10<sup>−</sup><sup>4</sup> − 10<sup>−</sup><sup>1</sup> Hz, which is accessible to space-based GW detectors.

J0806 presents 100% X-ray and optical modulations with an apparent period of 321.5 s

| Parameter | Value                     | Uncertainty            | Comments                            |
|-----------|---------------------------|------------------------|-------------------------------------|
| ν         | 3.11 mHz                  | 10−10 Hz<br>1<br>×     | X-ray/Optical timing                |
| ν˙        | 10−16 Hz s−1<br>3.57<br>× | 10−18 Hz s−1<br>2<br>× | X-ray/Optical timing                |
| M1        | 0.55<br>M                 | –                      | Roche lobe-filling, q, ˙ν           |
| M2/M1     | 0.5                       | 0.13                   | uniform distribution                |
| D˜        | 0.5 to 5 kpc              | –                      | X-ray accretion luminosity [27] and |
|           |                           |                        | temperature of WD components        |
| δ         | 38◦                       | –                      | M1,<br>M2<br>and<br>v4686           |

<span id="page-9-0"></span>Table 2: The system parameters of RX J0806.3+1527. ν is the orbital frequency, ˙ν = dν/dt, M<sup>1</sup> and M<sup>2</sup> are the masses of the two stars, D˜ is distance to J0806, δ is the inclination, and v<sup>4686</sup> is the semi-amplitude of the radial velocity for the He II 4686 line. Unless specified otherwise, all data are from [\[31\]](#page-29-11).

(5.4 mins). High precision X-ray and optical timing conducted with Chandra [\[27\]](#page-29-7) and Keck-I [\[31\]](#page-29-11) allowed the determination of the time derivative of the frequency: ˙ν = 3.6 × 10<sup>−</sup><sup>16</sup>Hz s<sup>−</sup><sup>1</sup> . J0806 is considered a candidate ultra-compact binary white dwarf that can be represented by the "AM CVn" model (semi-detached binary white dwarf) [\[32\]](#page-29-12), with a Roche lobe filling white dwarf losing mass to a more massive white dwarf. In this model, the 5.4 minutes light curve modulation is due to the orbital period of the white dwarf binary.

Other interpretations of this source include the Intermediate Polar (IP) model and the Unipolar Inductor (UI) model. The IP model describes the system not as an ultra-compact binary, but rather as a binary system with an orbital period of several hours. The very short signal period actually comes from the spin of magnetic white dwarf. The UI model is essentially a more energetic version of the Jupiter-Io system. A magnetic white dwarf is orbited by a non-magnetic dwarf. In this model, the 5.4 minute period is also the orbital period, but the two stars are detached.

Using phase-resolved spectroscopy at Keck-I, Roelofs et al. [\[31\]](#page-29-11) have searched for kinematic evidence. They found that the average spectrum of J0806 is dominated by ionized helium emission lines. The full width at half maximum (FWHM) of these lines is about 2500 km s<sup>−</sup><sup>1</sup> . In the time-resolved spectrum, the He I 4471 line has S-shaped Doppler modulation. Its intensity follows the intensity of the variable continuum flux, which suggests that they originate from the same region. The He II 4686 line is doublepeaked and moves in anti-phase with respect to the He I 4471 line. Using the linear back-projection Doppler tomogram, a radial velocity semi-amplitude of 390 ± 40 km s<sup>−</sup><sup>1</sup> is measured for He I 4471 line, and 260 ± 40 km s<sup>−</sup><sup>1</sup> for He II 4686 line.

These results favor the AM-CVn model, as illustrated in Fig. 3 of [\[31\]](#page-29-11). The IP model predicts an hours-long orbital period which is not found in the spectroscopy, and the observed line kinematics do not match the predictions for spectral line variability in the accretor's spin period. The broad and quite constant He II line is a strong signature of accretion, which is not consistent with the UI model.

The system parameters for J0806 are listed in Table [2.](#page-9-0) The parameter with the largest uncertainty is its distance from the Sun. There is approximately a factor of 10 discrepancy between estimates based on X-ray luminosity [\[31\]](#page-29-11) and optical luminosity and temperature [\[27\]](#page-29-7). There is a third, even smaller value (about 0.05 kpc) listed in [\[33\]](#page-29-13).

J0806 has a relatively large galactic latitude of about 20◦ [\[33\]](#page-29-13), suggesting that a distance to J0806 significantly greater than 5 kpc is highly unlikely.

### <span id="page-10-0"></span>2.2 Spacecraft orbit

The orbit of a spacecraft is determined by the influence of both gravitational and nongravitational forces. The motion of the TianQin spacecraft shall be controlled/reconstructed with an accuracy to the order of 10<sup>−</sup><sup>12</sup> m s<sup>−</sup><sup>2</sup> in the relevant frequency band. This will allow the disturbance reduction system (see Sec. [4.2\)](#page-19-0) to reduce the acceleration noise on the test mass to the order of 10<sup>−</sup><sup>15</sup> m s<sup>−</sup><sup>2</sup> .

Important contributions to gravitational forces come from the gravitational field of the extended Earth[2](#page-10-1) (with relativistic corrections) and the Moon, the monopole gravitational field of the Sun, while the Newtonian monopole gravitational fields of Jupiter, other plan-

<span id="page-10-1"></span><sup>2</sup>Higher order multipole moments of the Earth are well known and openly available from projects such as GRACE [\[34\]](#page-30-0). It is possible to account for the influence of the multipole moments, including any differential acceleration (which are known to be small) on test masses, in the project design.

ets, and the largest asteroids may also contribute. These forces will result in variations of the side-lengths (inter-spacecraft distances) and angles of the triangle formed by the constellation. Distance variations will produce Doppler frequency shifts in the laser interferometer signal and will have to be modeled. Changes in the subtended angles necessitates a pointing control mechanism to align the telescopes of the laser interferometers. The orbits are to be optimized to minimize these variations and their contributions to position and acceleration noise.

A set of possible orbits is shown in Fig. [2.](#page-12-0) For these orbits, the relative line-of-sight velocity (range-rates) between each pair of spacecraft varies less than 10 m/s over time, and the general behavior remains largely the same for a period of up to five years. The relative velocities will induce Doppler shifts in the laser signals that will have to be compensated or modeled. In the case of LISA [\[5,](#page-28-0) [45\]](#page-30-1), the nominal plan is to modulate the laser beams with a signal based on the spacecraft oscillators [\[35,](#page-30-2) [36\]](#page-30-3), which allows a range-rate as large as 15 m/s. We will adopt the same approach for TianQin.

The variation of subtended angles can be separated into two parts: short term fluctuations and long-term shifts in the averaged value of the variation. The short term fluctuations have periods on the order of a few days with magnitudes ∼ 0.1 ◦ . This part can be corrected using laser beam pointing control with a fast-steering mirror. On the other hand, attitude control of telescopes using a gimbal mechanism is needed to deal with larger variations that accumulate through a long period of time. This can be done at intervals of the order of several months. A gimballed telescope has the advantage of lower sensitivity to pointing errors when compared to a fast-steering mirror. The choice between these technologies will be made as the mission requirements are refined and as our understanding of the range of available technological solutions improves.

To relax the requirement on the disturbance reduction system even further, we may consider implementing a redundant optical truss architecture, as was proposed for the BEACON mission [\[38\]](#page-30-4). For this, a fourth spacecraft may be added to the constellation. This option is yet to be investigated.

![](_page_12_Figure_0.jpeg)

<span id="page-12-0"></span>Figure 2: Time evolution of the preliminary TianQin orbits. Shown are the range rates (panels 1,2,3 and 7) and the subtended angles (panels 4,5,6 and 8) between each pair of the spacecraft (denoted as SC1, SC2, and SC3) assuming that the three TianQin spacecraft are on nearly identical orbits with a semi-major axis of 10<sup>5</sup> km. The panels 1–6 show five-year spans, while the panels 7 and 8 show more detail in the first few months for the pair SC3-SC1 (the behavior of the pairs SC1-SC2 and SC2-SC3 is very similar). The effects of the Sun, the Moon and major planets in the solar system, multiple moments of the Earth's gravity up to the fifth order, and random noise at the level 10<sup>−</sup><sup>12</sup> m s<sup>−</sup><sup>2</sup> (representing the residual effect of non-gravitational forces, which are largely canceled by the drag-free control) have been included in the simulation of the orbits.

### <span id="page-13-0"></span>3 Sensitivity goal

The sensitivity of TianQin is set to enable detection of GWs emitted by the chosen reference source. In this study, we are using J0806 as an example that allows us to map out the details of the experiment. Using parameter values from Table 2, the GW strain from J0806 is characterized by [39]

<span id="page-13-4"></span>
$$h_0 = \frac{2G_N^2 M_1 M_2}{\tilde{D} a} \approx 6.4 \times 10^{-23} \left(\frac{M_1}{0.55 M_{\odot}}\right) \left(\frac{M_2}{0.27 M_{\odot}}\right) \left(\frac{5 \text{ kpc}}{\tilde{D}}\right) \left(\frac{6.6 \times 10^4 \text{ km}}{a}\right), \quad (1)$$

with a being the distance between the two stars. (The speed of light is taken to be c=1 in this subsection.)

The sensitivity of a Michelson interferometer to gravitational waves is characterized by (see, e.g., [40, 41])

$$h_f = \frac{2}{\sqrt{R(2\pi f)}} \left[ \frac{S_x}{L_0^2} + \frac{S_a}{(2\pi f)^4 L_0^2} \left( 1 + \frac{10^{-4} \,\text{Hz}}{f} \right) \right]^{1/2}, \tag{2}$$

where R(w) is the transfer function,  $L_0$  is the arm length, while  $S_x$  and  $S_a$  are the position noise and in residual acceleration noise power densities, respectively. For LISA-like configurations, one has (see, e.g., [10])

<span id="page-13-3"></span>
$$R(w) \approx \frac{8}{15} \left[ 1 + \left( \frac{wL_0}{0.41\pi} \right)^2 \right]^{-1},$$
 (3)

which is obtained by averaging over all sky directions and polarizations, and neglecting small oscillatory behavior in the higher frequency end [40, 42].

The transfer function R(w) is most useful for a source with unknown characters and/or located in an unknown sky direction. For a given binary source that lies in the optimal direction with respect to the detector plane, one can define a specialized transfer function  $R_0(w)$  that includes contributions from both polarizations.<sup>3</sup> In the low frequency limit, assuming that the detector plane is perpendicular to the incoming gravitational waves, we find

<span id="page-13-2"></span>
$$R_0(w) \approx 3 - 2.6\sin^2\delta\,,\tag{4}$$

<span id="page-13-1"></span><sup>&</sup>lt;sup>3</sup>General transfer functions with the contribution from both polarizations of a gravitational wave have been studied in [41]. Here we define  $R_0(w)$  following [40]. Further detail can be found in [43].

which turns out to be independent of the frequency w. (We will write  $R_0(w)$  as  $R_0$  from now on.) Apart from the inclination  $\delta$ , other parameters describing the orientation of the binary orbit are often uncertain, and have been averaged over in (4).

For J0806,  $\delta \approx 38^{\circ}$  and  $R_0 \approx 2.0$ . The low frequency limit of (3) is  $R(w \to 0) \approx \frac{8}{15}$ , which is about a quarter the optimal value for J0806.<sup>4</sup>

Assuming that TianQin can conduct effective observations only during the quieter time windows, each observation during such a window yields the integrated strain, from (1),

$$h'_0 = h_0 \sqrt{T}$$
  
 $\approx 1.8 \times 10^{-19} / \text{Hz}^{1/2} \left(\frac{M_1}{0.55 M_{\odot}}\right) \left(\frac{M_2}{0.27 M_{\odot}}\right) \left(\frac{5 \text{ kpc}}{\tilde{D}}\right) \left(\frac{6.6 \times 10^4 \text{ km}}{a}\right) \left(\frac{T}{90 \text{ days}}\right)^{1/2} (5)$ 

Requiring that SNR = 10, we find

<span id="page-14-1"></span>
$$\frac{h_0'}{10} \ge \frac{2}{\sqrt{R_0}} \left[ \frac{S_x}{L_0^2} + \frac{S_a}{(2\pi f)^4 L_0^2} \left( 1 + \frac{10^{-4} \text{Hz}}{f} \right) \right]^{1/2}, \tag{6}$$

which is our basic requirement on the noise goal of the laser interferometer and the disturbance reduction system for TianQin.

For the laser interferometer, we expect to achieve a peak positional sensitivity  $\sqrt{S_x} \approx 1 \text{ pm/Hz}^{1/2}$  at  $\sim 6 \text{ mHz}$ . The requirement on the residual acceleration  $\sqrt{S_a}$  then largely depends on the strength of the source. Assuming  $L_0 = \sqrt{3} \times 10^5 \text{ km}$  and  $\sqrt{S_x} = 1 \text{ pm/Hz}^{1/2}$ , Eq. (6) yields

$$\frac{S_a^{1/2}}{10^{-15} \,\mathrm{m \, s^{-2}/Hz^{1/2}}} \lesssim \begin{cases}
34 & \text{when } \tilde{D} = 0.5 \,\mathrm{kpc}, \\
17 & \text{when } \tilde{D} = 1 \,\mathrm{kpc}, \\
3.1 & \text{when } \tilde{D} = 5 \,\mathrm{kpc}.
\end{cases} \tag{7}$$

To ensure mission success, TianQin will aim for a successful detection of J0806 in the worst case scenario characterized by  $\tilde{D}=5$  kpc, by satisfying the most stringent acceleration sensitivity requirement  $S_a^{1/2}\approx 10^{-15}\,\mathrm{m\,s^{-2}/Hz^{1/2}}$  at  $\sim 6\,\mathrm{mHz}$ .

The expected sensitivity of TianQin is illustrated in Fig. 3. The gain in optimizing the detector plane towards J0806 is reflected in the distance between the dashed line and the nearby solid curve (both are marked as TQ SNR=10).

<span id="page-14-0"></span><sup>&</sup>lt;sup>4</sup>Since (4) is defined for both polarizations put together, while (3) is defined for only one polarization, the total gain in orienting the detector toward J0806 is about a factor 2 improvement over average.

![](_page_15_Figure_0.jpeg)

<span id="page-15-0"></span>Figure 3: The expected sensitivity curve of TianQin. The curve for LISA and another short period binary source, SDSS J065133+2844 [\[44\]](#page-30-10), are also plotted for comparison. The magnitudes of sources include 90 days of integration time. The solid curves are obtained by using the all-sky and polarization-averaged transfer function [\(3\)](#page-13-3), while the dashed curve is for sources not only having the same inclination but also lying in the same sky direction as J0806.

# <span id="page-16-0"></span>4 Error budget for the key components

The laser interferometer and the disturbance reduction system are the two key components representing technological challenges. In this section, we discuss a preliminary error budget allocation for each of them.

The preceding section established the position and residual acceleration sensitivity goals of <sup>√</sup> S<sup>x</sup> = 1 pm/Hz<sup>1</sup>/<sup>2</sup> and <sup>√</sup> S<sup>a</sup> = 10<sup>−</sup><sup>15</sup> m s<sup>−</sup><sup>2</sup>/Hz<sup>1</sup>/<sup>2</sup> , respectively. These requirements are challenging, but there appears to be no fatal obstacle along the path to achieve them.

The scheme for the laser interferometer is very similar to that of LISA [\[5\]](#page-28-0). On each spacecraft there are three optical modules: modules for laser frequency stabilization and optical phase locking, and the heterodyne interferometer (see Fig. [4](#page-17-0) for details). The laser frequency stabilization module consists of a master laser, an ultra-stable Fabry-Perot cavity and a frequency stabilization control system based on the Pound-Drever-Hall scheme. The optical phase locking module consists of a slave laser and an offset phase lock loop with which the slave laser is phase-locked to the master laser. The heterodyne interferometer module consists of two interferometer optical systems and their corresponding laser beam pointing control systems. Both are bonded on a single piece of ultra-low expansion (ULE) glass baseplate to form one quasi-monolithic optical bench.

Along each of the three arms, one heterodyne transponder-type laser interferometer and two inertial sensing systems will be used to measure the displacement between pairs of caged test masses, one in each spacecraft. The inertial sensing system measures the distance between the test mass and the interferometer optical bench on each spacecraft, while the displacement between the two interferometer optical benches is measured by the transponder-type interferometer.

For the disturbance reduction system, there are two possible schemes for the inertial sensing system. One is to use a spherical test mass with optical readouts in the inertial sensor. In this case, only one inertial sensor will be needed on each spacecraft. The second choice is to use cubic test masses with capacitive sensors in the inertial sensors, just like in LISA [\[45\]](#page-30-1). At present, we leave it open as to which will ultimately be used for TianQin. Here we will only discuss in detail the scheme with cubic test masses.

<span id="page-17-0"></span>![](_page_17_Picture_0.jpeg)

Figure 4: A schematic of the optical system on each spacecraft. The system includes a heterodyne interferometer optical bench, a frequency stabilization bench, a phase locking optical bench, an FPGA-based phase-meter and two telescopes. On the interferometer optical bench there are four laser interferometers and a signal acquisition pointing and tracking control optical system. On the frequency stabilization optical bench, there is the Fabry-Perot cavity used to stabilize the laser frequency through the Pound-Drever-Hall scheme. On the phase locking module, the slave laser head is heterodyne optical phase-locked with the frequency stabilized laser head, and two pairs of acousto-optic modulators (AOMs) are used to generate the heterodyne frequencies for heterodyne laser interferometer. All the interfering signals are detected with photo detectors, and we use an FPGA-based ultra high precision phase meter to read the phase of each signal.

In the case with cubic test masses, there are two identical inertial sensors on each spacecraft. Each sensor has a frame of electrodes surrounding a (5 cm)<sup>3</sup> cubic test mass, with a capacitive gap of about 5 mm along the sensitive axis. The test masses will be fabricated using an Au-Pt alloy. An audio modulation signal will be injected to the test mass through the injection electrodes on the frame, resulting in a modulated signal. Other electrodes will be used to sense the position of the test mass with respect to the frame and to electrostatic-control the test mass.

In the following subsections, we discuss the main sources of error to the interferometer and the inertial sensors, and then list the preliminary error budget.

### <span id="page-18-0"></span>4.1 Laser interferometer

For the calculations below, we assume the following values: The arm length of the laser interferometer, L = √ 3 × 10<sup>5</sup> km; the laser power, Pout = 4W; the diameter of telescope, D = 20 cm; the efficiency of the optical chain, ε = 0.3 ; the wave-front distortion, d = λ/10 ; and the central frequency of the laser, f ≈ 2.8 × 10<sup>14</sup> Hz .

The main sources of noise for the heterodyne transponder-type laser interferometer are the following [\[45,](#page-30-1) [46\]](#page-30-11):

- Frequency noise: Laser frequency noise (δf/f) coupled to the mismatch (∆L) between the two arm lengths of the interferometer leads to a noise δxFN = (δf/f)∆L. Assuming ∆L = 0.01 L, a frequency noise below δf . 0.1 mHz/Hz<sup>1</sup>/<sup>2</sup> is required for TianQin. This is to be achieved first by using on-board frequency stabilization system to reach better than 10 Hz/Hz<sup>1</sup>/<sup>2</sup> , and then by using the time-delayed interferometry to reach 0.1 mHz/Hz<sup>1</sup>/<sup>2</sup> .
- Shot noise: Quantum fluctuations in the received laser power lead to quantum noise in the phase detection, δxQL = (λ/2π) p hν/Prec, where ν is the laser frequency, λ = c/ν is the wavelength and Prec = εPout(πw0D/2λL) 2 , with w<sup>0</sup> being the radius of the outgoing beam waist. The axis offset (including a DC pointing error θDC and the pointing jitter δθ) of the outgoing beam can cause a reduction in the received power. For TianQin, requiring δxQL . 0.5 pm/Hz<sup>1</sup>/<sup>2</sup> leads to Prec & 20 nW .

- Pointing stability and wavefront distortion: Since the measured phase signal is averaged over the detector surface, wavefront distortion and diffraction (due to the finite diameter of telescopes) will influence the signal, leading to a noise δxPS/WD = 1 <sup>64</sup> (2π/λ) <sup>2</sup>d D<sup>2</sup> θDCδθ . For TianQin, requiring δxPS/WD . 0.5 pm/Hz<sup>1</sup>/<sup>2</sup> constrains the DC pointing error to θDC . 10 nrad and the pointing jitter to δθ . 10 nrad/Hz<sup>1</sup>/<sup>2</sup> .
- Thermal stability: Temperature fluctuations cause the dimensions and the refractive index of optical materials to change, which leads to noise in the optical path length (OPL). To make the whole system stable, ULE will be used to construct the baseplate of the optical system and S-PHM52 [\[47\]](#page-31-0) type optical glass will be used to construct the baseplate of all components. The coefficients of thermal expansion for these materials are of the order 10<sup>−</sup><sup>8</sup>/K and 10<sup>−</sup><sup>6</sup>/K , respectively. The total temperature-to-OPL coupling coefficient is expected to be CTOPL ≈ 5 nm/K. The TianQin phase noise requirement of δxOPL = CTOPLδTOB . 0.5 pm/Hz<sup>1</sup>/<sup>2</sup> leads to δTOB . 0.1 mK/Hz<sup>1</sup>/<sup>2</sup> .
- Clock stability: The frequency reference for the heterodyne phase-locked loop is provided by an ultra-stable oscillator (USO), the frequency drift of which leads to phase noise in the final result, δxUSO = (δF/F)(λF/2πν) , where ν is the frequency of gravitational waves. For TianQin (ν = 6 mHz , and assuming F = 20 MHz), requiring δxUSO . 0.5 pm/Hz<sup>1</sup>/<sup>2</sup> leads to δF/F . 10<sup>−</sup><sup>15</sup> Hz<sup>−</sup>1/<sup>2</sup> , and the corresponding Allan variance σAllan = √ 2ν ln 2 (δF/F) . 10<sup>−</sup><sup>16</sup>. Using inter-spacecraft clock transfer to cancel the clock noise in the measurement data, we expect to lower the requirements on clock stability by several orders of magnitude [\[45\]](#page-30-1).

The preliminary error budget for the laser interferometer is presented in Table [3.](#page-20-0)

### <span id="page-19-0"></span>4.2 Disturbance reduction system

In the calculations below, the test mass (TM) is assumed to be made of a Pt-Au alloy, in the shape of a cube with each side measuring 5 cm and a mass of mTM = 2.45 kg. For temperature, the nominal value of T = 293 K will be used when needed. Along the sensitive direction, there are two pairs of frame electrodes facing the TM. The gap between

| Type                     | Requirements                   | Position error |
|--------------------------|--------------------------------|----------------|
|                          | (at 6 mHz)                     | (pm/Hz1/2<br>) |
| Laser frequency          | 10 Hz/Hz1/2<br>δf<br>(PDH)     | 0.5            |
| stabilization            | 0.1 mHz/Hz1/2<br>δf<br>(TDI)   |                |
| Shot noise               | Pout<br>= 4 W,<br>D<br>= 20 cm | 0.5            |
| Pointing stability       | θDC<br>10 nrad                 | 0.5            |
| and wavefront distortion | 10 nrad/Hz1/2<br>δθ            |                |
| Thermal stability of     | CTOPL<br>5 nm/K                | 0.5            |
| optical bench            | 0.1 mK/Hz1/2<br>δTOB           |                |
| Onboard USO              | 10−15/Hz1/2<br>δF/F            | 0.5            |
|                          | 10−16<br>σAllan                |                |

<span id="page-20-0"></span>Table 3: Preliminary error budget for laser interferometry.

TM and a frame electrode is dx<sup>0</sup> = 5 mm, and the effective area is s<sup>0</sup> = 8.1 cm<sup>2</sup> , leading to a capacitance C<sup>0</sup> = ε0s0/dx<sup>0</sup> ≈ 1.4 pF. In drag-free control, the spacecraft mass is taken to be M = 250 kg.

The main sources of noise for the disturbance reduction system are the following [\[45,](#page-30-1) [48\]](#page-31-1):

• Thermal fluctuation: Temperature differences can result in several different types of forces acting on the TMs: (1) the radiometer effect due to collision with gas molecules, δaradio = (P S/2mTM)(δ(∆T)/T), where P and T are the local pressure and temperature, respectively, ∆T is the temperature difference along the sensitive direction, and δ(∆T) is its fluctuation; (2) radiation pressure, δaradp = (PthS/2mTM)(δ(∆T)/T), where Pth = U/3V is the radiation pressure, U is the internal energy of the radiation and V is the volume of the cavity; and (3) outgassing due to the release of absorbed gas molecules from material surfaces, δaoutgas = [P(1 + 2Θ/T)S/2mTM](δ(∆T)/T), where Θ is the effective activation temperature. Among these, the outgassing effect is less well known and could be more dangerous. The effect depends on the poorly understood effective activation temperature Θ of the sensor surface and the gas conductance of the paths in the sensor head. For TianQin, a preliminary estimation suggests P . 10<sup>−</sup><sup>6</sup> Pa and δ(∆T) . 5 µK/Hz<sup>1</sup>/<sup>2</sup> , assuming Θ = 5000 K.

- Magnetic disturbance: The acceleration due to static magnetic forces is a<sup>m</sup> = ∇(M<sup>p</sup> · B)/mTM, where the TM magnetic moment M<sup>p</sup> consists of the remanence M<sup>r</sup> and the inductive magnetic moment χmVTMB/µ<sup>0</sup> with χ<sup>m</sup> being the magnetic susceptibility, µ<sup>0</sup> the vacuum permeability and B consisting of the spacecraft magnetic field Bsc and the ambient (space) magnetic field Bsp . In calculating the fluctuations, ∇Bsp , δ(∇Bsc) , ∇M<sup>r</sup> and δM<sup>r</sup> are often negligible. The spacecraft magnetic field can come from permanent magnets M<sup>s</sup> used in attitude control or laser frequency stabilization, Bsc ≈ (µ0/4π)(Ms·∇)(r/r<sup>3</sup> ) and |∇Bsc| ≈ 3|Bsc|/r , where r is the displacement from the TM. For TianQin, a preliminary estimation suggests δ|Bsc| . 2 × 10<sup>−</sup><sup>7</sup>T/Hz<sup>1</sup>/<sup>2</sup> , assuming |Ms| . 1 A m<sup>2</sup> at r = 0.8 m , and χ<sup>m</sup> . 10<sup>−</sup><sup>5</sup> .
- Electrostatic force noise: A net charge will build up on the TM due to cosmic rays. For TianQin, the limit on the residual charge is estimated to be qmax . 1.7×10<sup>−</sup><sup>13</sup> C , corresponding to a TM potential bias VTM,max = qmax/Ctot . 10 mV , assuming the total capacitance between the TM and the surrounding conductors to be Ctot = 17 pF . The charge control of TM is to be achieved through the UV discharge technique, either continuously or at discrete intervals. The charged TM can interact with magnetic fields to generate a Lorentz force mTMa<sup>L</sup> = qv×B . The fluctuation then depends on δB and δq = CtotδV , where δV is the error in the measurement of the potential. The residual charge also couples to the fluctuation of the patch potential, δVFE, on the frame electrodes, leading to the acceleration noise δafn,<sup>x</sup> = 2(∂xC)VPMδVFE/mTM . A preliminary estimation suggests δV . 0.1 mV and δVFE . 100 µV/Hz<sup>1</sup>/<sup>2</sup> .
- Capacitive sensor: The capacitive sensing noise is expected to be at the level of δC . 6.9 × 10<sup>−</sup><sup>7</sup> pF/Hz<sup>1</sup>/<sup>2</sup> at 6 mHz for each of the two sensing channels, corresponding to <sup>x</sup><sup>n</sup> = (<sup>√</sup> 2 δC/2C0)dx<sup>0</sup> . 1.7 nm/Hz<sup>1</sup>/<sup>2</sup> in position sensing noise along the sensitive axis. The corresponding acceleration noise is δaCn = |ke| xn/mTM , where k<sup>e</sup> is the negative electrostatic parasitic stiffness caused by the capacitive sensor itself, which is projected to be k<sup>e</sup> = −2.3 × 10<sup>−</sup><sup>7</sup> N/m.
- Crosstalk between axes: The interaction between the TM and the spacecraft in the direction of orthogonal axes can leak into the sensitive axis due to crosstalk be-

| Type                   | Requirements                    | Acceleration error      |
|------------------------|---------------------------------|-------------------------|
|                        | (at 6 mHz)                      | (10−15 m s−2/Hz1/2<br>) |
| Thermal fluctuation    | µK/Hz1/2<br>δ(∆T)<br>5          | 0.52                    |
|                        | 10−6 Pa<br>P                    |                         |
|                        | (assuming Θ = 5000 K )          |                         |
| Magnetic disturbance   | 10−7T/Hz1/2<br>δ Bsc <br>2<br>× | 0.24                    |
|                        | 10−5<br>χm                      |                         |
|                        | 1Am2 at<br> Ms <br>r<br>= 0.8 m |                         |
| Electrostatic force    | 10−13 C<br>qmax<br>1.7<br>×     | 0.24                    |
|                        | VTM,max<br>10 mV                |                         |
|                        | µV/Hz1/2<br>δVFE<br>100         |                         |
| Other parasitic noise  |                                 | 0.36                    |
| Capacitive sensor      | 10−7 pF/Hz1/2<br>δC<br>6.9<br>× | 0.16                    |
|                        | 1.7 nm/Hz1/2<br>xn              |                         |
|                        | 10−7 N/m<br>−2.3<br>×<br>ke     |                         |
| Crosstalk between axes | 10−10 N/Hz1/2<br>fon            | 0.41                    |
|                        | 10−5<br>fc                      |                         |
| Micronewton thrusters  | Fmax<br>100<br>µN               | 0.35                    |
|                        | µN/Hz1/2<br>Fn<br>0.1           |                         |
|                        | Hopen<br>75                     |                         |
| Other coupling noise   |                                 | 0.33                    |
|                        |                                 |                         |

<span id="page-22-0"></span>Table 4: Preliminary error budget for the disturbance reduction system.

tween axes, afn = fonfc/mTM , where fon is the residual non-gravitational force in the orthogonal direction and f<sup>c</sup> is the coupling factor characterizing the crosstalk between axes. For this reason, drag-free behavior is also necessary in the direction of non-sensitive axes. For TianQin, a plausible bound is fon . 10<sup>−</sup><sup>10</sup> N/Hz<sup>1</sup>/<sup>2</sup> and f<sup>c</sup> . 10<sup>−</sup><sup>5</sup> .

• Micronewton thrusters: The maximum force Fmax from the micronewton thrusters should be able to balance the non-gravitational force on the spacecraft, and the force noise F<sup>n</sup> of the thruster determines the noise of the drag-free control. The acceleration noise is athn = |ke|xthn/mTM , where xthn = Fn/[Mw<sup>2</sup> (1 + Hopen)] is the displacement noise (between the spacecraft and the reference frame) due to the drag-free control loop, while Hopen is the open loop gain. A larger open loop gain will help suppress the contribution from the thruster force noise, as long as the control is stable. For TianQin, we expect Fmax . 100 µN , F<sup>n</sup> . 0.1 µN/Hz<sup>1</sup>/<sup>2</sup> , xthn . 4 nm/Hz<sup>1</sup>/<sup>2</sup> and Hopen . 75.

In addition to the noise sources enumerated above, there are more sources of noise to be considered. For instance, the thermal distortion of the spacecraft will induce a gravitational disturbance affecting the TM, which calls for a careful design and simulation of the spacecraft structure. Recently, we initiated such activities; results will be reported elsewhere. In addition, one needs to account for a possible presence of other sources of GWs within the bandwidth expected for the reference source. Not only does such a contribution have a low probability, but given the matched-filter approach that will be used to study the reference source, any such contribution would be small and easily accounted for [\[50\]](#page-31-2). The relevant analysis is ongoing and will be reported elsewhere.

The preliminary error budget of the disturbance reduction system is presented in Table [4.](#page-22-0) This set of noise constraints represents our assessment of the technology requirements that are necessary to implement TianQin. Given currently available technologies, these requirements do not present significant challenges.

# <span id="page-24-0"></span>5 Technology status

In this section, we provide a brief summary of the present status of two key technologies that will be used in the TianQin project: the laser interferometer and the disturbance reduction system.

### <span id="page-24-1"></span>5.1 Laser interferometer

The first prototype heterodyne laser interferometer with a 10 m arm-length was built at Huazhong University of Science and Technology (HUST) in 2010. Preliminary results showed that a resolution of better than 3 nm could be obtained [\[51\]](#page-31-3). In order to achieve higher measurement precision, we developed FPGA-based digital phasemeters and an ultrastable optical bench.

The digital phasemeter worked using a phase-locked loop [\[52\]](#page-31-4). According to preliminary tests and analysis, the measurement error of the digital phasemeter came mainly from the sampling-time jitter of the analog-to-digital converter (ADC). To decompress this noise further, we used the pilot tone correction method to compensate for the influence of the sampling-time jitter of ADC [\[53\]](#page-31-5). The noise level of the phase measurement can be as low as 10<sup>−</sup><sup>6</sup> rad/Hz<sup>1</sup>/<sup>2</sup> at 0.1 Hz, corresponding to a displacement of 0.2 pm/Hz<sup>1</sup>/<sup>2</sup> .

We built the first prototype heterodyne interferometer using hydroxide-catalysis bonding [\[54\]](#page-31-6). In order to evaluate the performance of this quasi-monolithic optical bench, we used this interferometer to perform closed-loop positioning control, achieving picometer level precision.

In order to realize a transponding laser ranging system, we built a heterodyne optical phase-locked loop (OPLL) in which the slave laser is phase-locked with an offset frequency to the incoming laser beam. The whole system consisted of a heterodyne interferometer system (to be installed on the master satellite) and an optical phase-locked loop system (to be installed on the slave satellite). The power of the laser beam received by the slave satellite was attenuated to 10nW by using a neutral filter. The preliminary result showed that the OPLL could maintain the lock for more than 20 hours with a residual error of less than 1 nm.

We are developing a space-qualified laser frequency stabilization system using the Pound-Drever-Hall method [\[55\]](#page-31-7). Since the stability of the reference Fabry-Perot cavity is the key constraint, we bonded the Fabry-Perot cavity and the mode-matching components directly onto the same baseplate and the entire optical bench was put into a vacuum chamber with thermal shielding. Preliminary results show that the laser frequency noise at 1 Hz could be controlled within 10 Hz/Hz<sup>1</sup>/<sup>2</sup> . Further improvements are planned in the form of constructing a Fabry-Perot cavity with higher finesse and compensating for the noise caused by fiber-optic components.

### <span id="page-25-0"></span>5.2 Disturbance reduction system

There has been a continuous effort to develop a low-noise inertial sensor at HUST since 2000. A flight model based on capacitive position transducer and electrostatic feedback control techniques, with a cubic TM surrounded by a series of frame electrodes as described in the last section, has been in orbital test since December of 2013.

The capacitive position transducer is based on the design of a differential transformer bridge [\[56\]](#page-31-8). Experimental studies show that a noise level much below 10<sup>−</sup><sup>6</sup> pF/Hz<sup>1</sup>/<sup>2</sup> in the bandwidth of interest can be reached when the capacitive-inductive bridge is well tuned, meeting the requirement of the TianQin mission. The intrinsic noise for the developed electrostatic feedback actuator has been verified to be in the order of µV/Hz<sup>1</sup>/<sup>2</sup> .

An inertial sensor with a target noise level of 10<sup>−</sup><sup>15</sup> m/s <sup>2</sup>/Hz<sup>1</sup>/<sup>2</sup> is currently under design and investigation. Several torsion pendulum facilities have been built to investigate the performance of electrostatic accelerometers on ground [\[57,](#page-31-9) [58\]](#page-31-10). The noise of the inertial sensor along the rotational degree of freedom and the translational degree of freedom have been verified to be 10<sup>−</sup><sup>13</sup> Nm/Hz<sup>1</sup>/<sup>2</sup> and 10<sup>−</sup><sup>11</sup> N/Hz<sup>1</sup>/<sup>2</sup> , respectively. A torsion pendulum test bench with better common-mode rejection ratio is under development to achieve a better noise performance near the mHz frequencies. The patch potential on a Au-coated material has been studied carefully [\[59\]](#page-31-11).

Thrusters with 1 mN precision are available from several institutes in China. These institutes are now being engaged to start an intense program to accelerate their research on building the micronewton thrusters needed in gravitational wave missions.

Possible ways to further lower the requirement on the disturbance reduction system are also being investigated.

# <span id="page-26-0"></span>6 Summary and Outlook

The proposed TianQin mission is a space-based detector of gravitational waves in the mHz frequency band. To launch this mission in the foreseeable future, we choose the most accessible GW source in the mHz band as the reference source, and optimize all the aspects of the experiment using the properties of the anticipated signal from this source. The primary mission goal is to detect a GW signal with known properties. This makes the experiment more a detector, rather than an observatory.

To reduce mission complexity, we choose geocentric orbits. This makes it possible to focus most of our efforts on the development of the laser interferometer and the disturbance reduction system, which are the two key components showing a gap to what is required by the experiment. A preliminary error budget has been given for them in this paper. All numbers will need to be carefully verified and updated as project development progresses. Nevertheless, we are confident that these two critical systems will reach the required maturity in the near future.

Another element that we need to develop is a comprehensive modeling, simulation, and data analysis software system. We already initiated the development of a simulation system. Preliminary results are encouraging and will be published soon.

We have engaged our colleagues in the astronomical community to initiate a campaign to study J0806 in more detail and also to search for other suitable sources for TianQin.

Two contingent experiments are envisioned to help the development of TianQin. The first one relies on a single Earth-orbiting spacecraft at an altitude of 700 km aiming to test the Equivalence Principle with an accuracy down to 10<sup>−</sup><sup>16</sup> [\[49\]](#page-31-12). This mission will allow us to bring the technologies of laser interferometry and drag-free control to maturity. The second mission relies on two geocentric spacecraft orbiting the Earth at an altitude of 400 km aiming at mapping the global gravitational field of the Earth using laser tracking between the spacecraft [\[51\]](#page-31-3). Among other technologies, this mission will allow us to bring the technology of the high precision inertial sensor to maturity. Both of these missions will benefit from the specialized set of modeling, simulation, and data analysis software that we began to develop, with TianQin as the ultimate intended user. These efforts will allow us to develop and refine all the technologies needed for TianQin in the near future.

Concluding, we would like to emphasize the fact that TianQin is an affordable spacebased experiment with a significant probability of success. With many technologies either already commercially available or being rapidly advanced, and given the planned geocentric orbits, this mission is well-focused and will be capable of direct detection of gravitational waves from a single reference source or a small set of sources. This makes TianQin a scientifically strong and technologically sound candidate for the space-based experiment towards the end of the next decade. Ultimately, TianQin is expected to serve as a spring board for a fleet of future gravitational wave observatories.

# Acknowledgement

This work was supported in part by the National Natural Science Foundation of China (Grants No. 11235004, 11273068, 11473073, 11475064), the Russian Foundation for Basic Research (Grant No. 15-52-53070-NNSF), the Natural Science Foundation of Jiangsu Province (Grant No. BK20141509), and the Foundation of Minor Planets of Purple Mountain Observatory. The authors thank all participants at the first and second Workshop of TianQin Science Mission for very helpful discussions.

# References

- <span id="page-27-0"></span>[1] J. M. Weisberg, D. J. Nice and J. H. Taylor, APJ, 722, 1030 (2010) [\[arXiv:1011.0718\]](http://arxiv.org/abs/1011.0718).
- <span id="page-27-1"></span>[2] S. J. Waldman [LIGO Scientific Collaboration], [arXiv:1103.2728](http://arxiv.org/abs/1103.2728) [gr-qc].
- <span id="page-27-2"></span>[3] J. Degallaix, et al. in Astronomical Society of the Pacific Conference Series, Vol. 467, 9th LISA Symposium, ed. G. Auger, P. Bin´etruy, & E. Plagnol, 151 (2013)
- <span id="page-27-3"></span>[4] K. Somiya, Classical and Quantum Gravity, 29, 124007 (2012)

- <span id="page-28-0"></span>[5] LISA (Laser Interferometer Space Antenna): An international project in the field of Fundamental Physics in Space, Pre-Phase A Report No. MPQ 233, Max-Planck-Institute f¨ur Quantenoptic, Garching bei M¨unchen, 1998.
- <span id="page-28-1"></span>[6] W. T. Ni, Int. J. Mod. Phys. D 11(7), 947 (2002)
- <span id="page-28-2"></span>[7] N. Seto, S. Kawamura, and T. Nakamura, Phys. Rev. Lett. 87, 221103 (2001)
- <span id="page-28-3"></span>[8] B. Hiscock and R. W. Hellings, Bull. Am. Astron. Soc. 29, 1312 (1997)
- <span id="page-28-4"></span>[9] A dozen more can be found here: [http://pcos.gsfc.nasa.gov/studies/](http://pcos.gsfc.nasa.gov/studies/gravwaves/) [gravwaves/](http://pcos.gsfc.nasa.gov/studies/gravwaves/)
- <span id="page-28-5"></span>[10] P. Amaro-Seoane, et al., GW Notes, Vol. 6, p. 4-110 [\[arXiv:1201.3621\]](http://arxiv.org/abs/1201.3621).
- <span id="page-28-6"></span>[11] G. H. Janssen, B. W. Stappers, M. Kramer, M. Purver, A. Jessner and I. Cognard, AIP Conf. Proc. 983, 633 (2008);
- <span id="page-28-7"></span>[12] G. B. Hobbs, M. Bailes, N. D. R. Bhat, S. Burke-Spolaor, D. J. Champion, W. Coles, A. Hotan and F. Jenet et al., Publ. Astron. Soc. Austral. 26, 103 (2009) [\[arXiv:0812.2721](http://arxiv.org/abs/0812.2721) [astro-ph]].
- <span id="page-28-8"></span>[13] <http://www.nanograv.org/index.html>
- <span id="page-28-9"></span>[14] <http://www.ipta4gw.org/>
- <span id="page-28-10"></span>[15] P. A. R. Ade et al. [BICEP2 and Planck Collaborations], Phys. Rev. Lett. 114, no. 10, 101301 (2015) [\[arXiv:1502.00612](http://arxiv.org/abs/1502.00612) [astro-ph.CO]].
- <span id="page-28-11"></span>[16] M. Cerdonio et al., in the proceedings of the "First Eduardo Amaldi conference on gravitational waves experimets" (Roma - Italy, 1994), edited by E. Coccia, G. Pizzella, F. Ronga, World Scientific, Singapore (1995) p. 176.;
- <span id="page-28-12"></span>[17] E. Mauceli, Z. K. Geng, W. O. Hamilton, W. W. Johnson, S. Merkowitz, A. Morse, B. Price, and N. Solomonson, Phys. Rev. D 54, 1264 (1996).
- <span id="page-28-13"></span>[18] A. de Waard and G. Frossati, Proceedings of the 3th Eduardo Amaldi Conference on Gravitational waves (Pasadena, USA), edited by Sydney Meshkov (1999) 268.

- <span id="page-29-0"></span>[19] M. V. Sazhin, Vestnik MGU, Ser 3 23, 45 (1982).
- <span id="page-29-1"></span>[20] A. Stroeer and A. Vecchio, Class. Quant. Grav. 23, S809 (2006) [\[astro-ph/0605227\]](http://arxiv.org/abs/astro-ph/0605227).
- <span id="page-29-2"></span>[21] M. Tinto and S. V. Dhurandhar, Living Rev. Rel. 17, 6 (2014).
- <span id="page-29-4"></span>[22] G. Nelemans, LISA Verification Binaries, web interface to database, Radboud University. URL: [http://www.astro.ru.nl/nelemans/dokuwiki/doku.php?](http://www.astro.ru.nl/nelemans/dokuwiki/doku.php?id= verification_binaries:intro) [id=verification\\_binaries:intro](http://www.astro.ru.nl/nelemans/dokuwiki/doku.php?id= verification_binaries:intro)
- <span id="page-29-3"></span>[23] M. Tinto, J. C. N. de Araujo, O. D. Aguiar, and M. E. S. Alves, Astropart. Phys. 48, 50 (2013)
- [24] J. B. Gerardo and J. T. Verdeyen, Applied Physics Letters, 3 (7) 121-123 (1963).
- <span id="page-29-5"></span>[25] K. Beuermann, H.-C. Thomas, K. Reinsch, A. D. Schwope, J. Tr¨umper, and W. Voges, A&A, 347, 47 (1999).
- <span id="page-29-6"></span>[26] G. L. Israel, W. Hummel, S. Covino, S. Campana, I. Appenzeller, W. G¨assler, K.- H. Mantel, G. Marconi, C. W. Mauche, U. Munari, I. Negueruela, H. Nicklas, G. Rupprecht, R. L. Smart, O. Stahl, and L. Stella, A&A, 386, L13 (2002).
- <span id="page-29-7"></span>[27] T. E. Strohmayer, ApJ, 627, 920 (2005).
- <span id="page-29-8"></span>[28] T. E. Strohmayer, ApJL, 679, L109 (2008).
- <span id="page-29-9"></span>[29] G. Ramsay, P. Hakala, and M. Cropper, MNRAS, 332, L7 (2002).
- <span id="page-29-10"></span>[30] S. C. C. Barros, T. R. Marsh, V. S. Dhillon, P. J. Groot, S. Littlefair, G. Nelemans, G. Roelofs, D. Steeghs, and P. J. Wheatley, MNRAS, 374, 1334 (2007).
- <span id="page-29-11"></span>[31] G. H. A. Roelofs, A. Rau, T. R. Marsh, D. Steeghs, P. J. Groot, and G. Nelemans, ApJ, 711, L138 (2010).
- <span id="page-29-12"></span>[32] J.-E. Solheim, PASP, 122, 1133 (2010).
- <span id="page-29-13"></span>[33] [http://simbad.u-strasbg.fr/simbad/sim-id?Ident=RX+J0806.3%](http://simbad.u-strasbg.fr/simbad/sim-id?Ident=RX+J0806.3%2B1527&NbIdent=1&Radius=2&Radius.unit=arcmin&submit=submit+id) [2B1527&NbIdent=1&Radius=2&Radius.unit=arcmin&submit=submit+id](http://simbad.u-strasbg.fr/simbad/sim-id?Ident=RX+J0806.3%2B1527&NbIdent=1&Radius=2&Radius.unit=arcmin&submit=submit+id)

- <span id="page-30-0"></span>[34] <http://www.csr.utexas.edu/grace/>
- <span id="page-30-2"></span>[35] R. Hellings, G. Giampieri, L. Maleki, M. Tinto, K. Danzmann, J. Hough, D. Robertson, Heterodyne laser tracking at high Doppler rates, Opt. Commun. 124, (1996) 313-20.
- <span id="page-30-3"></span>[36] R.T. Stebbins, P.L. Bender, W.M. Folkner, LISA data acquisition, Class. Quantum Grav. 13 (1996) A285-A289.
- [37] G. Giampieri R.W. Hellings, M. Tinto, and J.E. Faller, Opt. Commun. 123 (1996) 669-678.
- <span id="page-30-4"></span>[38] S.G. Turyshev, B. Lane, M. Shao, and A. Girerd, Int. J. Mod. Phys. D18(6), 1025-1038 (2009), [arXiv:0805.4033](http://arxiv.org/abs/0805.4033) [gr-qc]
- <span id="page-30-5"></span>[39] C.W. Misner, K.S. Thorne, and J.A. Wheeler, Gravitation (Freeman & Co., San Francisco, 1973).
- <span id="page-30-6"></span>[40] S. L. Larson, W. A. Hiscock and R. W. Hellings, Phys. Rev. D 62, 062001 (2000) [\[gr-qc/9909080\]](http://arxiv.org/abs/gr-qc/9909080).
- <span id="page-30-7"></span>[41] N. J. Cornish and L. J. Rubbo, Phys. Rev. D 67, 022001 (2003) [Phys. Rev. D 67, 029905 (2003)] [\[gr-qc/0209011\]](http://arxiv.org/abs/gr-qc/0209011).
- <span id="page-30-8"></span>[42] F. B. Estabrook, M. Tinto and J. W. Armstrong, Phys. Rev. D 62, 042002 (2000).
- <span id="page-30-9"></span>[43] J. Mei, C. G. Shao and Y. Wang, in the proceedings of the "XIIth International Conference on Gravitation, Astrophysics and Cosmology" (Moscow, Russia, 2015), World Scientific, Singapore, accepted.
- <span id="page-30-10"></span>[44] W. R. Brown, M. Kilic, J. J. Hermes, C. Allende Prieto, S. J. Kenyon, and D. E. Winget (2011). ApJ, 737:L23+
- <span id="page-30-1"></span>[45] LISA system and technology study report, July 2000, ESA-SCI (2000) 11
- <span id="page-30-11"></span>[46] Peter L Bender, Class. Quantum Grav. 22 (2005) S339-S346;

- <span id="page-31-0"></span>[47] [http://www.ohara-gmbh.com/e/katalog/d\\_s-phm52\\_e.html](http://www.ohara-gmbh.com/e/katalog/d_s-phm52_e.html)
- <span id="page-31-1"></span>[48] B. L. Schumaker, Disturbance reduction requirement for LISA, Class. Quantum Grav. 20(2003), S239-S253
- <span id="page-31-12"></span>[49] F. Gao, Z. B. Zhou, J. Luo, Chin. Phys. Lett., 28(8): 080401 (2011)
- <span id="page-31-2"></span>[50] E. S. Phinney. A practical theorem on gravitational wave backgrounds. [\[astro](http://arxiv.org/abs/astro-ph/0108028)[ph/0108028v](http://arxiv.org/abs/astro-ph/0108028)1]
- <span id="page-31-3"></span>[51] H.-C. Yeh, Q.-Z. Yan, Y.-R. Liang, Y. Wang and J. Luo, Review of Scientific Instruments 82 (044501) 1 (2011).
- <span id="page-31-4"></span>[52] Y.-R. Liang, H.-Z. Duan, H.-C. Yeh, and J. Luo, Review of Scientific Instruments 83 (095110) 1 (2012).
- <span id="page-31-5"></span>[53] Y.-R. Liang, H.-Z. Duan, X.-L. Xiao, B.-B. Wei, and H.-C. Yeh, Review of Scientific Instruments 86 (016106) 1 (2015).
- <span id="page-31-6"></span>[54] E. J. Elliffe, et al, Classical and Quantum Gravity, 22, S257 (2005).
- <span id="page-31-7"></span>[55] Y. Luo, H. Li, H.-C. Yeh, and J. Luo, Review of Scientific Instruments 86 (044501) 1 (2015).
- <span id="page-31-8"></span>[56] M. Hu, Y.Z. Bai, Z.B. Zhou, Z.X. Li, J Luo, Rev. Sci. Instrum. 85(5) (2014) 055001.
- <span id="page-31-9"></span>[57] H. B. Tu, Y. Z. Bai, Z. B. Zhou, et al., Class Quantum. Grav.,27, 205016 (2010).
- <span id="page-31-10"></span>[58] Z. B. Zhou, S. W. Gao, J. Luo, Class. Quantum Grav.,22, S537-542 (2005).
- <span id="page-31-11"></span>[59] H. Yin, Y.-Z. Bai, M. Hu, L. Liu, J. Luo, D.-Y. Tan, H.-C. Yeh, Z.-B. Zhou, Phys. Rev. D 90(2014) 122001.