# Direct Fidelity Estimation from Few Pauli Measurements

Steven T. Flammia<sup>1</sup> and Yi-Kai Liu<sup>2</sup>

<sup>1</sup>Institute for Quantum Information, California Institute of Technology <sup>2</sup>Computer Science Department, University of California, Berkeley (Dated: April 29, 2011)

We describe a simple method for certifying that an experimental device prepares a desired quantum state  $\rho$ . Our method is applicable to any pure state  $\rho$ , and it provides an estimate of the fidelity between  $\rho$  and the actual (arbitrary) state in the lab, up to a constant additive error. The method requires measuring only a *constant* number of Pauli expectation values, selected at random according to an importance-weighting rule. Our method is faster than full tomography by a factor of d, the dimension of the state space, and extends easily and naturally to quantum channels.

In recent years there has been substantial progress in preparing many-body entangled quantum states in the laboratory [1]. A key step in such experiments is to *verify* that the state of the system is the desired one. This can be done using quantum state tomography, or techniques such as entanglement witnesses [2]. However, in many cases these solutions are not fully satisfactory. Tomography gives complete information about the state, but it is very resource-intensive, and has difficulty scaling to large systems. Entanglement witnesses can be much easier to implement, but are not a generic solution since known constructions only work for special quantum states.

Here we propose a new method, direct fidelity estimation, that is much faster than tomography, is applicable to a large class of quantum states, and requires minimal experimental resources. Let us first describe the setting of the problem. Consider a system of n qubits, with Hilbert space dimension  $d=2^n$ , and let  $\rho$  be the desired state, i.e. the state we hope to accurately prepare. We make two basic assumptions. First, we assume that  $\rho$  is pure. However, we do not assume any additional structure or symmetry, so our method goes beyond previous work [3, 4] to encompass nearly all of the states of interest in experimental quantum information science (e.g., the GHZ and W states, stabilizer states, cluster states, matrix product states, projected entangled pair states, etc.) in a unified framework. Second, we assume that we can measure n-qubit Pauli observables, that is, tensor products of single-qubit Pauli operators; we do not need to perform any other operations. Thus our method is applicable to any system that is capable of single-qubit gates and readout, without needing to rely on 2-qubit gates or entangled measurements.

Our method works by measuring a random subset of Pauli observables chosen according to an "importance-weighting" rule. Roughly, we select Pauli operators that are most likely to detect deviations from the desired state  $\rho$ . We use the resulting measurement statistics to estimate the fidelity  $F(\rho, \sigma)$ , where  $\sigma$  is the actual state in the lab. Surprisingly, although there are  $4^n$  distinct Pauli operators, we only need to sample a constant number of them to estimate  $F(\rho, \sigma)$  up to a constant additive error,

for arbitrary  $\sigma$ . That is, for every possible state  $\sigma$ , with high probability over the choice of Pauli measurements, we get an accurate estimate of  $F(\rho, \sigma)$ .

Although we measure only a constant number of Pauli observables, we need to repeat each measurement many times in order to estimate the corresponding expectation value. The number of repetitions depends on the desired state  $\rho$ . In the worst case, it is O(d), but in many cases of practical interest, it is much smaller. For example, for stabilizer states, the number of repetitions is *constant*, independent of the size of the system; and for the W state, it is only quadratic in the number of qubits n.

Even in the worst case, our method requires far fewer resources than full tomography, both in theory and in practice. We demonstrate this by proving lower bounds on the sample complexity of full tomography, and by numerical simulations.

Finally, we show an analogous method for certifying any unitary quantum channel by estimating the entanglement fidelity. We discuss applications to benchmarking quantum circuits — as a special case, our method can certify Clifford circuits in *constant* time, independent of the number of qubits and gates.

Fidelity Estimation. The fidelity between our desired pure state  $\rho$  and the actual state  $\sigma$  is given by [5]:

$$F(\rho, \sigma) = \left( \operatorname{tr} \left[ \left( \sqrt{\rho} \sigma \sqrt{\rho} \right)^{1/2} \right] \right)^2 = \operatorname{tr}(\rho \sigma). \tag{1}$$

We can write  $\operatorname{tr}(\rho\sigma)$  in terms of the Pauli expectation values of  $\rho$  and  $\sigma$ . Let  $W_k$   $(k=1,\ldots,d^2)$  denote all possible Pauli operators (n-fold tensor products of I,  $\sigma_x$ ,  $\sigma_y$  and  $\sigma_z$ ). Define the characteristic function  $\chi_\rho(k) = \operatorname{tr}(\rho W_k/\sqrt{d})$ , and note that

<span id="page-0-0"></span>
$$\operatorname{tr}(\rho\sigma) = \sum_{k} \chi_{\rho}(k) \chi_{\sigma}(k). \tag{2}$$

In general, Eq. (2) involves the expectation values of all  $d^2$  Pauli operators. However, it is easy to see that in certain cases fewer Pauli operators are required. For example, if  $\rho$  is a stabilizer state,  $\chi_{\rho}(k)$  takes on values of  $\pm 1/\sqrt{d}$  at the d points in the stabilizer group of  $\rho$ , and vanishes everywhere else. So the sum in (2) contains only

d terms, and one can compute  $\operatorname{tr}(\rho\sigma)$  by measuring only d Pauli operators. Furthermore, to merely estimate  $\operatorname{tr}(\rho\sigma)$  one only needs to measure a small random subset of these Pauli operators. We will now generalize this strategy to work with an arbitrary pure state  $\rho$ .

We will construct an estimator for  $\operatorname{tr}(\rho\sigma)$  as follows. Select  $k \in \{1, \dots, d^2\}$  at random with probability [6]

<span id="page-1-0"></span>
$$Pr(k) = (\chi_{\rho}(k))^2. \tag{3}$$

By measuring the expectation value of the Pauli observable  $W_k$ , we can estimate  $\chi_{\sigma}(k)$ , up to some finite precision which we will discuss later. For the time being, let us suppose we can measure  $\chi_{\sigma}(k)$  perfectly. We then construct the estimator

$$X = \chi_{\sigma}(k)/\chi_{\rho}(k). \tag{4}$$

It is easy to see that  $\mathbb{E}X = \operatorname{tr}(\rho\sigma)$  (where  $\mathbb{E}$  denotes the expected value over the random choice of k).

Now say we want to estimate  $\operatorname{tr}(\rho\sigma)$  with some fixed additive error  $\varepsilon$  and failure probability  $\delta$ . We repeat the above process  $\ell = \lceil 1/(\varepsilon^2 \delta) \rceil$  times: we choose  $k_1, \ldots, k_\ell$  independently, which give independent estimates  $X_1, \ldots, X_\ell$ , and we let  $Y = \frac{1}{\ell} \sum_{i=1}^{\ell} X_i$ . By Chebyshev's inequality [7], Y satisfies

<span id="page-1-1"></span>
$$\Pr[|Y - \operatorname{tr}(\rho\sigma)| \ge \varepsilon] \le \delta. \tag{5}$$

To complete the description of our method, we show how the ideal "infinite-precision" estimator Y can be approximated by an estimator  $\tilde{Y}$  that uses a finite number of copies of the state  $\sigma$ . Given any choice of  $k_1, \ldots, k_\ell$ , we proceed as follows. For each  $i = 1, \ldots, \ell$ , we will use  $m_i$  copies of  $\sigma$ , where we set

<span id="page-1-4"></span>
$$m_i = \left\lceil \frac{2}{d\chi_{\rho}(k_i)^2 \ell \varepsilon^2} \log(2/\delta) \right\rceil.$$
 (6)

(Note that  $m_i$  depends on  $k_i$ .) We measure the Pauli observable  $W_{k_i}$  on each of these copies of  $\sigma$ , and get measurement outcomes  $A_{ij} \in \{1, -1\}$   $(j = 1, ..., m_i)$ . Note that  $\mathbb{E}A_{ij} = \sqrt{d}\chi_{\sigma}(k_i)$  (taking the expectation over the random measurement outcomes). Let

$$\tilde{X}_i = \frac{1}{m_i \sqrt{d} \chi_\rho(k_i)} \sum_{i=1}^{m_i} A_{ij}.$$
 (7)

Finally, we let  $\tilde{Y} = \frac{1}{\ell} \sum_{i=1}^{\ell} \tilde{X}_i$ . This is our estimate for Y. (Note that  $\mathbb{E}\tilde{Y} = Y$ .) By Hoeffding's inequality [7],  $\tilde{Y}$  has additive error  $\varepsilon$  and failure probability  $\delta$ :

<span id="page-1-3"></span>
$$\Pr[|\tilde{Y} - Y| > \varepsilon] < \delta. \tag{8}$$

We can then conclude that, with probability  $\geq 1 - 2\delta$ , the fidelity  $F(\rho, \sigma)$  lies in the range  $[\tilde{Y} - 2\varepsilon, \tilde{Y} + 2\varepsilon]$ .

Our method uses  $\ell = \lceil 1/(\varepsilon^2 \delta) \rceil$  Pauli observables, independent of the size of the system. It requires m copies

of the state  $\sigma$ , where  $m = \sum_{i=1}^{\ell} m_i$ . Though this depends on the random choices  $k_i$ , we have

$$\mathbb{E}(m_i) = \sum_{k} (\chi_{\rho}(k_i))^2 m_i \le 1 + \frac{2d}{\ell \varepsilon^2} \log(2/\delta), \quad (9)$$

and hence the expected number of copies satisfies

<span id="page-1-2"></span>
$$\mathbb{E}(m) \le 1 + \frac{1}{\varepsilon^2 \delta} + \frac{2d}{\varepsilon^2} \log(2/\delta). \tag{10}$$

By Markov's inequality, m is unlikely to exceed its expectation by much:  $\Pr(m \ge t \cdot \mathbb{E}(m)) \le 1/t$ , for all  $t \ge 1$ .

Example: the W state. Suppose our desired state  $\rho$  is the W state, i.e. the uniform superposition over computational basis states where a single qubit is  $|1\rangle$  and the rest are  $|0\rangle$ , as previously considered in [3, 4]. To apply our method, we need to sample Pauli operators from the probability distribution (3). It is straightforward to give a short formula for these probabilities, and an explicit algorithm that does the sampling in poly(n) time [7].

The distribution for a W state is quite different from what one would expect for a Haar-random quantum state. For a random state, one expects most of the Pauli matrices to occur with probability  $\sim 1/d^2$ ; but for the W state, most of the Pauli matrices have probability 0, and all the nonzero probabilities are at least  $1/n^2d$ . This is an example of a well-conditioned state. As we now show, our method requires fewer resources for such states.

Well-conditioned states. We say that a state  $\rho$  is well-conditioned with parameter  $\alpha$  if for all k, either  $\operatorname{tr}(\rho W_k)=0$  or  $|\operatorname{tr}(\rho W_k)|\geq \alpha$ . For example, stabilizer states (including the GHZ state) and the W state are well-conditioned with  $\alpha=1$  and  $\alpha=1/n$ , respectively, and Dicke states with k excitations have  $\alpha=O(1/n^k)$ . When  $\rho$  is well-conditioned, our method requires a smaller number of measurement settings, as well as fewer copies of the actual state  $\sigma$ . Note first that the estimator X is bounded:  $|X|\leq 1/\alpha$ . Now we can use the stronger Hoeffding inequality for Eq. (5), and we can choose the number of measurement settings to be  $\ell=O(\frac{\log(1/\delta)}{\alpha^2\varepsilon^2})$ . Thus, the dependence on  $\delta$  is exponentially better, at a cost of a factor of  $1/\alpha^2$ .

The total number of copies used in the procedure, m, is bounded in expectation by (10). For well-conditioned states, we can prove a much stronger bound that holds with certainty:  $m_i \leq 1 + \frac{2\log(2/\delta)}{\alpha^2 \ell \varepsilon^2}$ , and hence  $m \leq O\left(\frac{\log(1/\delta)}{\alpha^2 \varepsilon^2}\right)$ . In particular, when  $\rho$  is a stabilizer state, m is independent of the size of the system; when  $\rho$  is the W state, m is only quadratic in the number of qubits n.

Truncating bad events. For an arbitrary pure state  $\rho$ , it is possible to modify our protocol so that m is always bounded by  $O\left(\frac{1}{\varepsilon^2\delta} + \frac{d\log(1/\delta)}{\varepsilon^2}\right)$ . The idea is to construct a nearby  $\rho'$  which is well-conditioned with  $\alpha = O(1/\sqrt{d})$ , by truncating small values of  $\chi_{\rho}(k)$ . This eliminates the bad choices of k that cause m to be large, at the expense of introducing a small bias into the fidelity estimate [7].

Dephasing and depolarizing noise. Our method also performs better if one makes some mild assumptions about the noise in the system. For an arbitrary pure state  $\rho$ , suppose the actual state  $\sigma$  is given by  $\sigma = \mathcal{E}(\rho)$ , where  $\mathcal{E}$  is some quantum process that shrinks the characteristic function, i.e., for all k,  $|\chi_{\mathcal{E}(\rho)}(k)| \leq |\chi_{\rho}(k)|$ . For example, dephasing and depolarizing noise both do this. Again, this implies that  $|X| \leq 1$ , hence we can use a smaller number of measurement settings,  $\ell = O(\frac{\log(1/\delta)}{\varepsilon^2})$ .

Comparison with full tomography. We have shown that it is possible to estimate the fidelity of an arbitrary pure state using Pauli measurements on O(d) copies of the state. (In this discussion, let us fix the accuracy  $\varepsilon$  and failure probability  $\delta$  to be constant.) How good is this result? We argue that our protocol is more efficient than full tomography by a factor of d. By tomography, we mean any procedure that distinguishes arbitrary quantum states with accuracy  $\Delta$ , so that for every pair of states  $\rho$  and  $\sigma$  with  $F(\rho,\sigma) \leq 1-\Delta$ , the procedure returns different outputs for  $\rho$  and  $\sigma$ .

First, as a toy example, consider what is possible using arbitrary quantum operations. Fidelity estimation of a pure state can then be done with O(1) copies using the swap test [8], while full tomography requires  $\Omega(d/\operatorname{poly}\log d)$  copies, by Holevo's theorem [9] (see [7]).

In the more realistic situation where only Pauli measurements are allowed (and one cannot perform joint measurements on more than one copy of the state), fidelity estimation uses O(d) copies. We now prove that full tomography requires at least  $\Omega(d^2/\log d)$  copies. The idea of the proof is as follows (details in [7]). First, we construct a set of  $2^{\Omega(d)}$  quantum states  $|\phi_i\rangle$  that are almost orthogonal (for all  $i \neq j$ ,  $|\langle \phi_i | \phi_j \rangle|^2 < 1 - \Delta$ ), and whose Pauli expectation values are small (for all i and k with  $W_k \neq I$ ,  $|\langle \phi_i | W_k | \phi_i \rangle| \leq \tau \sqrt{\log d}/\sqrt{d}$ ). (This is done using repeated applications of Levy's lemma [7, 10].)

Now suppose there is some tomography procedure that can distinguish these states, given t copies. This implies the existence of a classical protocol for transmitting  $\Omega(d)$  bits of information over a particular noisy channel  $\mathcal{E}$ . Intuitively, Bob encodes an  $\Omega(d)$ -bit message i by sending a string of  $\pm 1$  bits through the channel  $\mathcal{E}$ , in such a way that when Alice receives these bits, they have the same distribution as the measurement outcomes she would have obtained by measuring Pauli observables on the state  $|\phi_i\rangle$ . Then Alice uses the tomography procedure to reconstruct  $|\phi_i\rangle$  and extract the message i. One can show that the channel  $\mathcal{E}$  has capacity  $O\left((\log d)/d\right)$  (even allowing feedback from Alice to Bob) [11]. Then the converse to Shannon's (classical) noisy coding theorem [11] implies that  $t \geq \Omega(d^2/\log d)$ .

Numerics. In order to evaluate how tight our analysis is for typical states, we simulated our protocol as follows. We sampled Haar-random states of n=8 qubits and ran our protocol with  $\varepsilon=\delta=.05$  (and  $\ell=\frac{1}{\varepsilon^2\delta}$ ) where the true state was created by subjecting the ideal state to

![](_page_2_Figure_7.jpeg)

<span id="page-2-0"></span>FIG. 1. Left: The residual error has a standard deviation of 1.8%. Right: Most states use only a typical number of copies, with just .1% of trials using more than four times the expected number of copies, as shown in the inset.

independent 10% depolarizing noise. The residual error (Y-F) and the total number of copies m are plotted as histograms in Fig. 1. We see that the accuracy is always well-behaved, and the total number of copies, excepting a few bad events (for which our truncation procedure applies) is typically close to the average.

We also compared our method to a recent ion trap experiment, in which an 8-qubit W state was verified using full tomography [12]. Under the plausible assumption that dephasing noise is dominant, we would use our protocol with  $\varepsilon=.03$ ,  $\delta=.10$ , and  $\ell=\lceil\log(1/\delta)/\varepsilon^2\rceil$ . Assuming the realistic parameters of 20 ms to perform one measurement and 400 ms to reconfigure a new measurement basis, we would obtain a fidelity estimate accurate to within  $\pm 1.2\%$  using just 80 minutes of experiments and a few seconds of classical processing; this compares very favorably with the 10 hours of experiments and one week of post-processing carried out in [12].

Extension to channels. We now extend our method to unitary quantum channels. Let  $\mathcal{U}$  be the desired channel corresponding to some unitary evolution U, i.e.,  $\mathcal{U}: \rho \mapsto U\rho U^{\dagger}$ . Let  $\mathcal{E}$  be the actual channel. We will estimate the entanglement fidelity, given by  $F_e = \operatorname{tr}(\mathcal{U}^{\dagger}\mathcal{E})/d^2$  (with  $\mathcal{U}$  and  $\mathcal{E}$  treated as matrices acting via left multiplication).

Most of the analysis for channels is exactly analogous to the case of states. The main difference is that we may also input a state to the channel as well as choose how to measure at the output. Thus, the characteristic function for a channel  $\mathcal E$  is defined by  $\chi_{\mathcal E}(k,k')=\frac{1}{d}\operatorname{tr}\big(W_k\mathcal E(W_{k'})\big)$ , which depends on two indices. The probability distribution from which we sample indices is analogous:  $\Pr(k,k')=\frac{1}{d^2}\big[\chi_{\mathcal U}(k,k')\big]^2$ , and so is our primary estimator:  $X=\chi_{\mathcal E}(k,k')/\chi_{\mathcal U}(k,k')$ , for which we have  $\mathbb E X=F_e$ . Now given  $\ell$  independent samples from our probability distribution  $(k_1,k_1'),\ldots,(k_\ell,k_\ell')$ , we compute  $X_1,\ldots,X_\ell$ , and let  $Y=\frac{1}{\ell}\sum_{i=1}^\ell X_i$ . Then choosing  $\ell=\lceil 1/(\varepsilon^2\delta)\rceil$  means that Y is an estimate of  $F_e$  which is accurate to within  $\varepsilon$  with a failure probability at most  $\delta$ .

The main difference between states and channels comes in how we estimate  $X_i$  for a given sample  $(k_i, k'_i)$ . We will

still measure  $W_{k_i}$  at the output, but how can we simulate inputing  $W_{k'_i}$  into the channel? The key insight is that we can simply sample from states in the eigenbasis of  $W_{k'_i}$  and put these states into the channel. Note that these states can always be chosen to be tensor products of local Pauli eigenstates, so no entangling gates are required.

The total number of uses of the channel is bounded in expectation by  $\mathbb{E}(m) = O\left(\frac{1}{\varepsilon^2 \delta} + \frac{d^2}{\varepsilon^2} \log(1/\delta)\right)$ . Statements about well-conditioned channels and truncation also hold in analogy with states [7].

Benchmarking quantum circuits. One application of the above protocol is to evaluate experimental implementations of large quantum circuits: our method allows one to directly measure the entanglement fidelity and average fidelity of the entire circuit, rather than inferring it from tomography performed on individual gates. This is important because as circuits scale up, correlated noise potentially becomes an issue (c.f. Ref. [13]).

The relationship between  $F_e$  and the Haar-average fidelity is captured by the formula [14]

$$F_{\text{avg}} = \int d\psi F(\mathcal{U}(\psi), \mathcal{E}(\psi)) = \frac{d}{d+1} F_e + \frac{1}{d+1}. \quad (11)$$

Thus, our method also gives us a direct measure of the typical performance of the channel, similar to what is achieved in other random benchmarking schemes [15–17]. Moreover, one can also prove that the worst-case behavior (as quantified by the diamond norm [18]) is bounded by  $4d\sqrt{1-F_e}$  [19], so that for small high-fidelity gates, average and worst-case behavior nearly coincide.

Clifford circuits. Clifford circuits (those consisting of controlled-NOT, Hadamard and phase gates) are key components in many schemes for quantum error-correction, and become universal for quantum computation when augmented with certain state preparations [20, 21]. For a Clifford circuit  $\mathcal{U}$ , the characteristic function is given by  $\chi_{\mathcal{U}}(k,k')=1$  (when  $W_k=\mathcal{U}(W_{k'})$ ) and 0 otherwise. Sampling only requires that we pick  $k'\in\{1,\ldots,d^2\}$  uniformly at random, then use the Gottesman-Knill theorem to efficiently compute the k such that  $W_k=\mathcal{U}(W_{k'})$ . Clifford circuits are well-conditioned, so our method needs fewer measurement settings and uses of the channel, namely  $\ell \leq O\left(\frac{1}{\varepsilon^2}\log(1/\delta)\right)$  and  $m\leq O\left(\frac{1}{\varepsilon^2}\log(1/\delta)\right)$ , which is independent of the number of qubits and gates (see also Ref. [22]).

Outlook. We have presented a general method for certifying pure states and unitary quantum channels, which requires only Pauli measurements and is faster than full tomography by a factor of d. In common cases such as stabilizer states, the W state, and Clifford circuits, our method requires even fewer resources (constant or polynomial in the number of qubits), and it provides an easy recipe to generalize beyond these examples.

Looking beyond fidelity estimation, it would be interesting to directly estimate and bound an entanglement

measure [23], which would obviate the need for an entanglement witness. One may also compare our method with recent proposals for tomography for restricted classes of quantum states [24–27]. Another important direction is to find better techniques for sampling the importance-weighting distribution Pr(k) for different classes of states.

We thank D. Gross, J. Preskill and T. Monz for helpful discussions. YKL was supported by NIST Grant No. 60NANB10D262, and STF by NSF Grant No. PHY-0803371 and ARO Grant No. W911NF-09-1-0442.

We would also like to note that M. da Silva, O. Landon-Cardinal and D. Poulin [28] have recently and independently obtained similar results.

- <span id="page-3-0"></span>[1] Nature 453 (2008), (Nature Insight supplement).
- <span id="page-3-1"></span>[2] O. Gühne and G. Toth, Physics Reports **474**, 1 (2009).
- <span id="page-3-2"></span>[3] R. D. Somma, J. Chiaverini, and D. J. Berkeland, Phys. Rev. A 74, 052302 (2006).
- <span id="page-3-3"></span>[4] O. Gühne, C.-Y. Lu, W.-B. Gao, and J.-W. Pan, Phys. Rev. A 76, 030305 (2007).
- <span id="page-3-4"></span>[5] Some authors define the square root of this as the fidelity.
- <span id="page-3-5"></span>[6] These probabilities are normalized since  $tr(\rho^2) = 1$ .
- <span id="page-3-6"></span>[7] We defer some details to the appendices.
- <span id="page-3-7"></span>[8] H. Buhrman, R. Cleve, J. Watrous, and R. de Wolf, Phys. Rev. Lett. 87, 167902 (2001).
- <span id="page-3-8"></span>[9] A. S. Holevo, Problems of Inform. Transm. 9, 177 (1973).
- <span id="page-3-9"></span>[10] P. Lévy, Problèmes concrets d'analyse fonctionelle (Gauthier Villars, Paris, 1951).
- <span id="page-3-10"></span>[11] T. M. Cover and J. A. Thomas, Elements of Information Theory (Wiley, 1991).
- <span id="page-3-11"></span>[12] H. Häffner, W. Hänsel, C. F. Roos, J. Benhelm, D. Chekal kar, M. Chwalla, T. Körber, U. D. Rapol, M. Riebe, P. O. Schmidt, C. Becher, O. Gühne, W. Dür, and R. Blatt, Nature 438, 643 (2005).
- <span id="page-3-12"></span>[13] T. Monz, P. Schindler, J. T. Barreiro, M. Chwalla, D. Nigg, W. A. Coish, M. Harlander, W. Hänsel, M. Hennrich, and R. Blatt, Phys. Rev. Lett. 106, 130506 (2011).
- <span id="page-3-13"></span>[14] M. Horodecki, P. Horodecki, and R. Horodecki, Phys. Rev. A 60, 1888 (1999).
- <span id="page-3-14"></span>[15] E. Knill, D. Leibfried, R. Reichle, J. Britton, R. B. Blakestad, J. D. Jost, C. Langer, R. Ozeri, S. Seidelin, and D. J. Wineland, Phys. Rev. A 77, 012307 (2008).
- [16] E. Magesan, J. M. Gambetta, and J. Emerson, arXiv:1009.3639 (2010).
- <span id="page-3-15"></span>[17] J. Emerson, M. Silva, O. Moussa, C. Ryan, M. Laforest, J. Baugh, D. G. Cory, and R. Laflamme, Science 317, 1893 (2007).
- <span id="page-3-16"></span>[18] D. Aharonov, A. Kitaev, and N. Nisan, in STOC '98 (1998).
- <span id="page-3-17"></span>[19] S. Beigi and R. Koenig, arXiv:1101.1065 (2011).
- <span id="page-3-18"></span>[20] D. Gottesman and I. L. Chuang, Nature 402, 390 (1999).
- <span id="page-3-19"></span>[21] S. Bravyi and A. Kitaev, Phys. Rev. A **71**, 022316 (2005).
- <span id="page-3-20"></span>[22] R. A. Low, Phys. Rev. A 80, 052314 (2009).
- <span id="page-3-21"></span>[23] R. Blume-Kohout, J. O. S. Yin, and S. J. van Enk, Phys. Rev. Lett. 105, 170501 (2010).
- <span id="page-3-22"></span>[24] D. Gross, Y.-K. Liu, S. T. Flammia, S. Becker, and J. Eisert, Phys. Rev. Lett. 105, 150401 (2010).
- [25] A. Shabani, R. L. Kosut, M. Mohseni, H. Rabitz, M. A.

- Broome, M. P. Almeida, A. Fedrizzi, and A. G. White, [Phys. Rev. Lett.](http://dx.doi.org/ 10.1103/PhysRevLett.106.100401) 106, 100401 (2011) .
- [26] M. Cramer, M. B. Plenio, S. T. Flammia, R. Somma, D. Gross, S. D. Bartlett, O. Landon-Cardinal, D. Poulin, and Y.-K. Liu, Nature Communications 1 (2010).
- <span id="page-4-0"></span>[27] G. T´oth, W. Wieczorek, D. Gross, R. Krischek, C. Schwemmer, and H. Weinfurter, Phys. Rev. Lett. 105 , 250403 (2010).
- <span id="page-4-1"></span>[28] M. P. da Silva, O. Landon-Cardinal, and D. Poulin, arXiv:1104.3835 (2011).
- <span id="page-4-2"></span>[29] P. Sen, in *[Proc. 21st Ann. IEEE Conf. on Computational Complexity](http://dx.doi.org/10.1109/CCC.2006.37)* (2006) pp. 274–287.
- <span id="page-4-3"></span>[30] P. Hayden, D. Leung, P. W. Shor, and A. Winter, [Comm. Math. Phys.](http://dx.doi.org/10.1007/s00220-004-1087-6) 250, 371 (2004) .

### **Bounding the Failure Probabilities**

To show Eq. (5), observe that the variance of each individual estimator  $X_i$  is not too large,

$$Var(X_i) = \mathbb{E}(X_i^2) - (\mathbb{E}X_i)^2$$
(12)

$$= \sum_{k} [\chi_{\sigma}(k)]^2 - [\operatorname{tr}(\rho\sigma)]^2$$
 (13)

$$= \operatorname{tr}(\sigma^2) - [\operatorname{tr}(\rho\sigma)]^2 \le 1. \tag{14}$$

This implies that  $Var(Y) \leq 1/\ell$ . Hence, by Chebyshev's inequality,

$$\Pr[|Y - \operatorname{tr}(\rho\sigma)| \ge \lambda/\sqrt{\ell}] \le \frac{1}{\lambda^2}.$$
 (15)

Then set  $\lambda = 1/\sqrt{\delta}$  and  $\ell = \lceil 1/(\varepsilon^2 \delta) \rceil$ .

To show Eq. (8), we use Hoeffding's inequality, which says that for all  $\varepsilon > 0$ ,

$$\Pr[|\tilde{Y} - Y| \ge \varepsilon] \le 2\exp(-2\varepsilon^2/C),$$
 (16)

where

$$C = \sum_{i=1}^{\ell} \sum_{j=1}^{m_i} (2c_i)^2, \quad c_i = \frac{1}{\ell m_i \sqrt{d} \chi_{\rho}(k_i)}.$$
 (17)

Setting  $m_i$  as in Eq. (6), we get

$$C = \sum_{i=1}^{\ell} \frac{4}{\ell^2 m_i d\chi_{\rho}(k_i)^2} \le \frac{2\varepsilon^2}{\log(2/\delta)},\tag{18}$$

hence the failure probability is  $\leq \delta$ , as claimed.

### Efficient sampling for the W state

Recall the definition of the W state,

$$|W\rangle = \frac{1}{\sqrt{n}} \sum_{|\mathbf{b}|=1} |\mathbf{b}\rangle,$$
 (19)

where the sum is over all *n*-bit strings **b** with Hamming weight  $|\mathbf{b}| = 1$ . We can factor any *n*-qubit Pauli operator into a tensor product of local Pauli  $\sigma_x$  operators times a tensor product of local Pauli  $\sigma_z$  operators (up to an irrelevant phase). Our probability distribution follows from the definition in Eq. (3),

$$p(\mathbf{j}, \mathbf{k}) = \Pr(\sigma_x^{\mathbf{j}} \sigma_z^{\mathbf{k}}) = \frac{1}{d} |\langle W | \sigma_x^{\mathbf{j}} \sigma_z^{\mathbf{k}} | W \rangle|^2, \qquad (20)$$

where we denote the tensor product by a bit string in the exponent. (Thus, for example,  $\sigma_x^{110}\sigma_z^{011} = \sigma_x \otimes \sigma_y \otimes \sigma_z$ , up to an irrelevant phase.)

$$p(\mathbf{j}, \mathbf{k}) = \frac{1}{n^2 d} \left| \sum_{|\mathbf{a}| = |\mathbf{b}| = 1} \langle \mathbf{a} | \sigma_x^{\mathbf{j}} \sigma_z^{\mathbf{k}} | \mathbf{b} \rangle \right|^2$$
 (21)

$$= \frac{1}{n^2 d} \left| \sum_{|\mathbf{a}| = |\mathbf{b}| = 1} (-1)^{\mathbf{b} \cdot \mathbf{k}} \delta_{\mathbf{a}, \mathbf{b} + \mathbf{j}} \right|^2, \qquad (22)$$

where the arithmetic in the delta function is modulo 2. The delta function tells us that the tensor product over  $\sigma_x$  must only contain either 0 or 2 factors of  $\sigma_x$  only; all other terms have zero probability. Let's separate out the case where there are no  $\sigma_x$  operators from when there are two. If there are none, then

$$p(\mathbf{0}, \mathbf{k}) = \frac{1}{n^2 d} \left| \sum_{|\mathbf{b}|=1} (-1)^{\mathbf{b} \cdot \mathbf{k}} \right|^2 = \frac{1}{n^2 d} \left| \sum_{i=1}^n (-1)^{k_i} \right|^2$$
 (23)

$$=\frac{1}{n^2d}(n-2|\mathbf{k}|)^2. \tag{24}$$

If **j** has weight 2, then the summand reduces to only two terms, since flipping two bits in the weight-1 string **b** will (with two exceptions) increase the weight, making it orthogonal to the weight-1 string **a**.

$$p(\mathbf{j}, \mathbf{k}) = \frac{1}{n^2 d} \left| \sum_{|\mathbf{a}| = |\mathbf{b}| = 1} (-1)^{\mathbf{b} \cdot \mathbf{k}} \delta_{\mathbf{a}, \mathbf{b} + \mathbf{j}} \right|^2$$
(25)

$$= \frac{1}{n^2 d} \left(1 + (-1)^{\mathbf{j} \cdot \mathbf{k}}\right)^2. \tag{26}$$

This is clearly either 0 or  $4/n^2d$  depending on  $\mathbf{j} \cdot \mathbf{k}$  mod 2. To summarize, we have the following formula for the probabilities

$$p(\mathbf{j}, \mathbf{k}) = \begin{cases} \frac{1}{n^2 d} (n - 2|\mathbf{k}|)^2 & \text{if } \mathbf{j} = \mathbf{0} \\ \frac{4}{n^2 d} & \text{if } |\mathbf{j}| = 2, \, \mathbf{j} \cdot \mathbf{k} = 0 \\ 0 & \text{otherwise,} \end{cases}$$
(27)

where again, the dot product  $\mathbf{j} \cdot \mathbf{k}$  is taken mod 2.

Given this formula, we have the following simple procedure to sample from this distribution. The procedure consists of two steps. First, flip a weighted coin to see if you are in the first or the second branch. The total weight in the first branch (with  $\mathbf{j}=0$ ) is 1/n, a fact that follows from some simple binomial identities, or by directly computing the weight in the second branch. If we are in this first branch, then all strings  $\mathbf{k}$  of a given Hamming weight are equally probable. We can sample from this by first picking the weight  $w=|\mathbf{k}|$  from the normalized distribution

$$q(w) = \frac{1}{nd} \binom{n}{w} (n - 2w)^2. \tag{28}$$

Since this distribution only has n outcomes, we can sample from it efficiently in n. Then we just choose a random bit string with the given sampled weight. Now consider that we are in the second branch after the initial coin flip. Then we choose uniformly from all  $\binom{n}{2}$  bit strings of length n containing exactly two ones, and this defines  $\mathbf{j}$ . Then we pick a bit string  $\mathbf{k}$  by choosing a uniformly random bit string of length n-1, and we take (say) the first bit and copy it between the two sites in  $\mathbf{k}$  which are supported by  $\mathbf{j}$  to enforce the condition  $\mathbf{j} \cdot \mathbf{k} = 0 \mod 2$  and distribute the remaining random bits over the rest of  $\mathbf{k}$  sequentially.

### **Truncating Bad Events**

The modified procedure is as follows: construct a new state  $\rho_1$  by defining its characteristic function to be

$$\chi_{\rho_1}(k) = \begin{cases} \chi_{\rho}(k) & \text{if } |\chi_{\rho}(k)| \ge \beta/d, \\ 0 & \text{otherwise.} \end{cases}$$
 (29)

Define  $\rho_2 = \rho_1/\|\rho_1\|_2$ , where  $\|\rho\|_2 = \sqrt{\operatorname{tr}(\rho^2)}$  is the Schatten 2-norm. Then perform our original certification procedure using  $\rho_2$ , to estimate  $\operatorname{tr}(\rho_2\sigma)$ . Actually, note that  $\rho_2$  may not be a density matrix (it may not be positive semidefinite with trace 1); nonetheless, it satisfies  $\operatorname{tr}(\rho_2^2) = 1$ , so the certification procedure makes sense.

We can bound m as follows: note that, for all k, either  $\chi_{\rho_2}(k) = 0$ , or  $|\chi_{\rho_2}(k)| \geq |\chi_{\rho_1}(k)| \geq \beta/d$ . Then, with probability 1, we have  $m_i \leq 1 + \frac{2d}{\beta^2 \ell \varepsilon^2} \log(2/\delta)$  and  $m \leq 1 + \frac{1}{\varepsilon^2 \delta} + \frac{2d}{\beta^2 \varepsilon^2} \log(2/\delta)$ .

We claim that  $tr(\rho_2\sigma)$  gives us an estimate of  $tr(\rho\sigma)$ , with some bias that is not too large. Clearly,

$$|\operatorname{tr}(\rho_2 \sigma) - \operatorname{tr}(\rho \sigma)| \le ||\rho_2 - \rho||_2,$$
 (30)

and the quantity on the right-hand side can be calculated explicitly, given knowledge of  $\rho$ . In the worst case, we claim that  $\|\rho_2 - \rho\|_2 \leq 2\beta$ . To see this, note that  $\|\rho_1 - \rho\|_2 \leq \beta$ , and  $1 - \beta \leq \|\rho_1\|_2 \leq 1$ , hence  $\|\rho_2 - \rho_1\|_2 \leq \beta$ .

## Lower Bound for Tomography

As a toy example, consider the situation where we can perform arbitrary quantum operations. In this setting, full tomography of a pure state with constant accuracy requires at least  $\Omega(d)$  copies (up to log factors); this follows from the existence of sets of  $2^{\Omega(d)}$  almost-orthogonal pure states [8], and Holevo's theorem [9]. Note that this lower bound is tight: full tomography can be done with O(d) copies, by using random POVM measurements [29, Thm. 3] to perform state discrimination on an  $\varepsilon$ -net of pure states [30, Lemma II.4].

Now consider the more realistic situation where only Pauli measurements are allowed. We prove that full tomography using Pauli measurements requires  $\Omega(d^2/\log d)$  copies of the state.

First step. We want to construct a large set of nearlyorthogonal quantum states that have small Pauli expectation values. To do this, we will use the following lemma:

**Lemma 1.** Fix any states  $|\phi_1\rangle, \ldots, |\phi_s\rangle \in \mathbb{C}^d$ , where  $s \leq 2^{cd}$  and c is some constant. Then there exists a state  $|\psi\rangle \in \mathbb{C}^d$  such that:

<span id="page-6-0"></span>
$$\forall i \in \{1, \dots, s\}, \ |\langle \phi_i | \psi \rangle| \le \varepsilon, \tag{31}$$

<span id="page-6-1"></span>
$$\forall W_k \neq I, \ |\langle \psi | W_k | \psi \rangle| \le \tau \sqrt{\log d} / \sqrt{d}. \tag{32}$$

Here  $\varepsilon = \sqrt{9\pi^3(\log 2)c}$  and  $\tau = \sqrt{72\pi^3}$ .

The proof of the lemma is as follows. Choose  $\psi$  to be a Haar-random vector in  $S^{d-1}$ . We claim that (31) and (32) are satisfied with high probability.

First, for each i, observe that  $\langle \phi_i | \psi \rangle$  is a smooth function of  $\psi$ , with Lipschitz coefficient  $\eta = 1$ :

$$\left| \langle \phi_i | \psi \rangle - \langle \phi_i | \psi' \rangle \right| \le \|\psi - \psi'\|_2. \tag{33}$$

By symmetry,  $\mathbb{E}\langle \phi_i | \psi \rangle = 0$ . So by Levy's lemma [10],

$$\Pr[|\langle \phi_i | \psi \rangle| \ge \varepsilon] \le 4 \exp(-C_1 d\varepsilon^2 / \eta^2),$$
 (34)

where  $C_1 = 2/9\pi^3$ . Taking the union bound over all *i*, we get that

Pr[Eq. (31) fails for some 
$$i$$
]  

$$\leq 4 \exp(cd(\log 2) - C_1 d\varepsilon^2)$$

$$= 4 \exp(-cd(\log 2)) = 4 \cdot 2^{-cd}.$$
(35)

Next, for each k, observe that  $\langle \psi | W_k | \psi \rangle$  is a smooth function of  $\psi$ , with Lipschitz coefficient  $\eta = 2$ :

$$\begin{aligned} \left| \langle \psi | W_k | \psi \rangle - \langle \psi' | W_k | \psi' \rangle \right| \\ &\leq \left| \langle \psi | W_k \left[ | \psi \rangle - | \psi' \rangle \right] \right| + \left| \left[ \langle \psi | - \langle \psi' | \right] W_k | \psi' \rangle \right| \\ &\leq 2 \| \psi - \psi' \|_2. \end{aligned} (36)$$

By symmetry,  $\mathbb{E}\langle\psi|W_k|\psi\rangle=0$ . So by Levy's lemma [10],

$$\Pr\left[|\langle \psi | W_k | \psi \rangle| \ge \tau \sqrt{\log d} / \sqrt{d}\right] \le 4 \exp(-C_1 \tau^2 (\log d) / \eta^2), \tag{37}$$

where  $C_1 = 2/9\pi^3$ . Taking the union bound over all k, we get that

Pr[Eq. (32) fails for some 
$$k$$
]  
 $\leq 4 \exp(2 \log d - C_1 \tau^2 (\log d)/4)$  (38)  
 $= 4 \exp(-2 \log d) = 4/d^2$ .

This proves the lemma.

By applying the above lemma repeatedly, we can construct a set of  $2^{\Omega(d)}$  quantum states  $|\phi_i\rangle$  that are almost orthogonal (for all  $i \neq j$ ,  $|\langle \phi_i | \phi_j \rangle|^2 < 1 - \Delta$ ), and whose Pauli expectation values are small (for all i and k with  $W_k \neq I$ ,  $|\langle \phi_i | W_k | \phi_i \rangle| \leq \tau \sqrt{\log d} / \sqrt{d}$ ).

Second step. Suppose there is some tomography procedure that can distinguish among the states  $|\phi_i\rangle$ , given t copies. We now construct a classical protocol for transmitting  $\Omega(d)$  bits of information over a particular noisy channel  $\mathcal{E}$ .

Let  $\mathcal{E}$  be the classical channel that takes a bit  $b \in \{1, -1\}$  and outputs a bit  $b' \in \{1, -1\}$ , where with probability  $\tau \sqrt{\log d}/\sqrt{d}$ , the channel sets b' = b, and with probability  $1 - \tau \sqrt{\log d}/\sqrt{d}$ , the channel chooses  $b' \in \{1, -1\}$  uniformly at random. Using the tomography procedure, we will show how to send messages over this channel (together with a noiseless feedback channel).

Say Bob wants to send O(d) bits to Alice. He associates the message with a state  $|\phi_i\rangle$ . Alice runs the tomography procedure. When she wants to measure some Pauli matrix  $W_k$ , she sends k to Bob (over the noiseless feedback channel). Bob chooses a random  $b \in \{1, -1\}$  with expectation value  $\langle \phi_i | W_k | \phi_i \rangle \cdot \sqrt{d} / \tau \sqrt{\log d}$ , and sends b through the channel  $\mathcal{E}$  to Alice. Alice receives b', which has expectation value  $\langle \phi_i | W_k | \phi_i \rangle$ .

For tomography using t copies, Bob sends t bits through the channel  $\mathcal{E}$  (in addition to the feedback bits sent by Alice). But  $\mathcal{E}$  is simply the binary symmetric channel, which has capacity  $\leq \tau^2(\log d)/d$ . Furthermore, feedback does not increase its capacity [11]. So, by the converse to Shannon's (classical) noisy coding theorem [11], Bob must use the channel at least  $\Omega(d^2/\log d)$  times to send  $\Omega(d)$  bits. Hence  $t \geq \Omega(d^2/\log d)$ .

### Estimating entanglement fidelity for channels

Here we give a detailed description of our method for certifying quantum channels. Let  $\mathbb{C}_H^{d\times d}$  denote the set of Hermitian matrices in  $\mathbb{C}^{d\times d}$ . We will view  $\mathbb{C}_H^{d\times d}$  as a vector space, with Hilbert-Schmidt inner product  $\operatorname{tr}(A^\dagger B)$ . We use round bra-kets to denote this: |A| is a vector, |A| is an adjoint vector, and  $|A|B| = \operatorname{tr}(A^\dagger B)$  is an inner product.

Let  $\mathcal{L}(\mathbb{C}_{H}^{d \times d}, \mathbb{C}_{H}^{d \times d})$  be the vector space of all linear maps from  $\mathbb{C}_{H}^{d \times d}$  to  $\mathbb{C}_{H}^{d \times d}$ , again with Hilbert-Schmidt inner product  $\operatorname{tr}(\mathcal{A}^{\dagger}\mathcal{B})$ . Now recall the Pauli matrices  $|W_k\rangle \in \mathbb{C}_{H}^{d \times d}$   $(k=1,\ldots,d^2)$ . Note that  $\frac{1}{d}|W_k\rangle(W_{k'}|(k,k') \in \{1,\ldots,d^2\})$  form an orthonormal basis for  $\mathcal{L}(\mathbb{C}_{H}^{d \times d},\mathbb{C}_{H}^{d \times d})$ . For any channel  $\mathcal{E} \in \mathcal{L}(\mathbb{C}_{H}^{d \times d},\mathbb{C}_{H}^{d \times d})$ , we define its characteristic function to be

$$\chi_{\mathcal{E}}(k, k') = \operatorname{tr}\left[\left[\frac{1}{d}|W_{k}\right](W_{k'}|\right]^{\dagger} \mathcal{E}\right]$$

$$= \frac{1}{d}(W_{k}|\mathcal{E}|W_{k'}) = \frac{1}{d}\operatorname{tr}(W_{k}^{\dagger}\mathcal{E}(W_{k'})).$$
(39)

(Note that  $\chi_{\mathcal{E}}(k, k')$  is real, since  $W_k$  and  $\mathcal{E}(W_{k'})$  are Hermitian.) Then

$$\mathcal{E} = \frac{1}{d} \sum_{k,k'} \chi_{\mathcal{E}}(k,k') |W_k\rangle (W_{k'}|, \tag{40}$$

and the overlap between  $\mathcal{U}$  and  $\mathcal{E}$  is given by

$$\operatorname{tr}(\mathcal{U}^{\dagger}\mathcal{E}) = \sum_{k,k'} \chi_{\mathcal{U}}(k,k') \chi_{\mathcal{E}}(k,k'). \tag{41}$$

Note that for any channel  $\mathcal{E}$ ,  $0 \leq \operatorname{tr}(\mathcal{E}^{\dagger}\mathcal{E}) \leq d^2$ , and since  $\mathcal{U}$  is a unitary channel,  $\operatorname{tr}(\mathcal{U}^{\dagger}\mathcal{U}) = d^2$ . This implies  $|\operatorname{tr}(\mathcal{U}^{\dagger}\mathcal{E})| \leq d^2$ . We will be interested in estimating  $\operatorname{tr}(\mathcal{U}^{\dagger}\mathcal{E})/d^2$  up to an additive error of size  $\varepsilon$ .

We will construct an estimator for  $\operatorname{tr}(\mathcal{U}^{\dagger}\mathcal{E})/d^2$  as follows. Select  $(k, k') \in \{1, \dots, d^2\}^2$  at random with probability

$$\Pr(k, k') = \frac{1}{d^2} [\chi_{\mathcal{U}}(k, k')]^2.$$
 (42)

(Note that these probabilities are normalized, since  $\operatorname{tr}(\mathcal{U}^{\dagger}\mathcal{U}) = d^2$ .) We can estimate  $\chi_{\mathcal{E}}(k, k')$ , up to some finite precision, by preparing eigenstates of  $W_{k'}$ , applying the channel  $\mathcal{E}$ , and then measuring the observable  $W_k$ ; we will discuss this below. We then compute the quantity

$$X = \chi_{\mathcal{E}}(k, k') / \chi_{\mathcal{U}}(k, k'). \tag{43}$$

It is easy to see that  $\mathbb{E}X = \operatorname{tr}(\mathcal{U}^{\dagger}\mathcal{E})/d^2$ .

We want an estimate with additive error  $\varepsilon$  and failure probability  $\delta$ , so we repeat the above process  $\ell = \lceil 1/(\varepsilon^2 \delta) \rceil$  times: we choose  $(k_1, k_1'), \ldots, (k_\ell, k_\ell')$  independently, which give independent estimates  $X_1, \ldots, X_\ell$ , and we let  $Y = \frac{1}{\ell} \sum_{i=1}^{\ell} X_i$ . (Note that the number of Pauli observables  $\ell$  is independent of the size of the system.) By Chebyshev's inequality,

<span id="page-7-0"></span>
$$\Pr[|Y - \operatorname{tr}(\mathcal{U}^{\dagger}\mathcal{E})/d^2| \ge \varepsilon] \le \delta.$$
 (44)

Finally, we describe how to estimate Y from a finite number of uses of the channel  $\mathcal{E}$ . Fix any choice of  $(k_i, k_i')$  for  $i = 1, \ldots, \ell$ . We then estimate Y as follows. For each  $i = 1, \ldots, \ell$ :

- Choose some eigenbasis for the Pauli matrix  $W_{k'_i}$ , call it  $|\phi^i_a\rangle$   $(a=1,\ldots,d)$ , and let  $\lambda^i_a\in\{1,-1\}$  be the corresponding eigenvalues. (Note that one can choose the  $|\phi^i_a\rangle$  to be tensor products of single-qubit Pauli eigenstates.)
- $\bullet$  Let

$$m_i = \left[ \frac{4}{\chi_{\mathcal{U}}(k_i, k_i')^2 \ell \varepsilon^2} \log(4/\delta) \right]. \tag{45}$$

• For each  $j=1,\ldots,m_i$ : choose some  $a_{ij} \in \{1,\ldots,d\}$  uniformly at random, prepare the state  $|\phi_{a_{ij}}^i\rangle$ , apply the channel  $\mathcal{E}$ , and measure the Pauli observable  $W_{k_i}$ , to get an outcome  $A_{ij} \in \{1,-1\}$ ; finally, let  $B_{ij} = \lambda_{a_{ij}}^i A_{ij}$ .

Note that

$$\mathbb{E}B_{ij} = \frac{1}{d} \sum_{a_{ij}=1}^{d} \lambda_{a_{ij}}^{i} \operatorname{tr}(W_{k_{i}} \mathcal{E}(|\phi_{a_{ij}}^{i}\rangle\langle\phi_{a_{ij}}^{i}|))$$

$$= \frac{1}{d} \operatorname{tr}(W_{k_{i}} \mathcal{E}(W_{k'_{i}})) = \chi_{\mathcal{E}}(k_{i}, k'_{i}).$$
(46)

Let

$$\tilde{X}_{i} = \frac{1}{\chi_{\mathcal{U}}(k_{i}, k'_{i})m_{i}} \sum_{j=1}^{m_{i}} B_{ij}.$$
(47)

Finally, we let  $\tilde{Y} = \frac{1}{\ell} \sum_{i=1}^{\ell} \tilde{X}_i$ . This is our estimate for Y; note that  $\mathbb{E}\tilde{Y} = Y$ . By Hoeffding's inequality,

<span id="page-7-1"></span>
$$\Pr[|\tilde{Y} - Y| \ge \varepsilon] \le \delta. \tag{48}$$

This procedure uses the channel  $\mathcal{E}$  a total of m times, where  $m = \sum_{i=1}^{\ell} m_i$ . This number depends on the random choice of  $(k_i, k_i')$   $(i = 1, \dots, \ell)$ . We can bound it in expectation: we have

$$\mathbb{E}(m_i) = \sum_{k_i, k_i'} \frac{1}{d^2} \chi_{\mathcal{U}}(k_i, k_i')^2 m_i \le 1 + \frac{4d^2}{\ell \varepsilon^2} \log(4/\delta), \quad (49)$$

hence

$$\mathbb{E}(m) \le 1 + \frac{1}{\varepsilon^2 \delta} + \frac{4d^2}{\varepsilon^2} \log(4/\delta). \tag{50}$$

Then use Markov's inequality:  $\Pr(m \ge t \cdot \mathbb{E}(m)) \le 1/t$ , for all  $t \ge 1$ .

It remains to prove (44) and (48), bounding the failure probability. To show (44), note that the variance of each  $X_i$  is not too large:

$$\operatorname{Var}(X_{i}) = \mathbb{E}(X_{i}^{2}) - (\mathbb{E}X_{i})^{2}$$

$$= \sum_{k,k'} \frac{1}{d^{2}} \chi_{\mathcal{E}}(k,k')^{2} - \frac{1}{d^{4}} \operatorname{tr}(\mathcal{U}^{\dagger}\mathcal{E})^{2}$$

$$= \frac{1}{d^{2}} \operatorname{tr}(\mathcal{E}^{\dagger}\mathcal{E}) - \frac{1}{d^{4}} \operatorname{tr}(\mathcal{U}^{\dagger}\mathcal{E})^{2} \leq 1.$$
(51)

Then  $Var(Y) \leq 1/\ell$ , so by Chebyshev's inequality,

$$\Pr[|Y - (1/d^2)\operatorname{tr}(\mathcal{U}^{\dagger}\mathcal{E})| \ge \frac{\lambda}{\sqrt{\ell}}] \le \frac{1}{\lambda^2}.$$
 (52)

Now set  $\lambda = 1/\sqrt{\delta}$  and  $\ell = \lceil 1/(\varepsilon^2 \delta) \rceil$ .

To show (48), we use Hoeffding's inequality: for any  $\varepsilon > 0$ ,

$$\Pr[|\tilde{Y} - Y| \ge \varepsilon] \le 2\exp(-2\varepsilon^2/C),$$
 (53)

where

$$C = \sum_{i=1}^{\ell} \sum_{i=1}^{m_i} (2c_i)^2, \quad c_i = \frac{1}{\ell \chi_{\mathcal{U}}(k_i, k_i') m_i}.$$
 (54)

We have

$$C = \sum_{i=1}^{\ell} \frac{4}{\ell^2 \chi_{\mathcal{U}}(k_i, k_i')^2 m_i} \le \frac{\varepsilon^2}{\log(4/\delta)}, \tag{55}$$

hence the failure probability is  $\leq \delta$  as desired.