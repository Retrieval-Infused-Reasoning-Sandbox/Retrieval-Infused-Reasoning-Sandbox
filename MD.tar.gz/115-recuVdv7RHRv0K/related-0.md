Foundations and Trends <sup>R</sup> in Theoretical Computer Science Vol. 10, No. 3 (2014) 159–282 c 2015 S. Gharibian, Y. Huang, Z. Landau and S. W. Shin DOI: 10.1561/0400000066

![](_page_0_Picture_1.jpeg)

# **Quantum Hamiltonian Complexity**

Sevag Gharibian Simons Institute for the Theory of Computing, University of California, Berkeley

> Yichen Huang University of California, Berkeley

Zeph Landau Simons Institute for the Theory of Computing, University of California, Berkeley

> Seung Woo Shin University of California, Berkeley

# **Contents**

| 1 |                                   | Introduction                                                                                       | 2            |
|---|-----------------------------------|----------------------------------------------------------------------------------------------------|--------------|
| 2 | 2.1<br>2.2                        | Preliminaries<br>Basics of quantum information<br><br>Basics of Quantum Hamiltonian Complexity<br> | 6<br>6<br>17 |
| 3 |                                   | Roadmap and Organization                                                                           | 22           |
| 4 |                                   | A Brief History                                                                                    | 24           |
|   | 4.1                               | The computer science perspective<br>                                                               | 24           |
|   | 4.2                               | The physics perspective                                                                            | 29           |
|   | 4.3                               | Selected recent developments                                                                       | 31           |
| 5 | Motivations From Physics          |                                                                                                    |              |
|   | 5.1                               | Setting the stage<br>                                                                              | 33           |
|   | 5.2                               | Time evolution versus thermal equilibrium<br>                                                      | 34           |
|   | 5.3                               | Where do Hamiltonians come from?<br>                                                               | 36           |
|   | 5.4                               | The study of Hamiltonians: Techniques and tools<br>                                                | 37           |
| 6 | Physics Concepts in Greater Depth |                                                                                                    |              |
|   | 6.1                               | A glossary of physics terms<br>                                                                    | 48           |
|   | 6.2                               | Mean-field theory<br>                                                                              | 56           |

|   |                             |                                                           | iii |  |
|---|-----------------------------|-----------------------------------------------------------|-----|--|
|   | 6.3                         | Tensor networks<br>                                       | 60  |  |
|   | 6.4                         | Density Matrix Renormalization Group<br>                  | 63  |  |
|   | 6.5                         | Multi-Scale Entanglement Renormalization Ansatz           | 67  |  |
|   | 6.6                         | Area laws<br>                                             | 70  |  |
| 7 | Reviews of Selected Results |                                                           |     |  |
|   | 7.1                         | 5-local Hamiltonian is QMA-complete<br>                   | 75  |  |
|   | 7.2                         | 2-local Hamiltonian is QMA-complete<br>                   | 82  |  |
|   | 7.3                         | Commuting<br>k-local Hamiltonians and the Structure Lemma | 89  |  |
|   | 7.4                         | Quantum 2-SAT is in P                                     | 94  |  |
|   | 7.5                         | Area laws for one-dimensional gapped quantum systems      | 100 |  |
|   | Acknowledgements            |                                                           |     |  |
|   | References                  |                                                           |     |  |

## **Abstract**

Constraint satisfaction problems are a central pillar of modern computational complexity theory. This survey provides an introduction to the rapidly growing field of Quantum Hamiltonian Complexity, which includes the study of quantum constraint satisfaction problems. Over the past decade and a half, this field has witnessed fundamental breakthroughs, ranging from the establishment of a "Quantum Cook-Levin Theorem" to deep insights into the structure of 1D low-temperature quantum systems via so-called area laws. Our aim here is to provide a computer science-oriented introduction to the subject in order to help bridge the language barrier between computer scientists and physicists in the field. As such, we include the following in this survey: (1) The motivations and history of the field, (2) a glossary of condensed matter physics terms explained in computer-science friendly language, (3) overviews of central ideas from condensed matter physics, such as indistinguishable particles, mean field theory, tensor networks, and area laws, and (4) brief expositions of selected computer science-based results in the area. For example, as part of the latter, we provide a novel information theoretic presentation of Bravyi's polynomial time algorithm for Quantum 2-SAT.

DOI: 10.1561/0400000066.

S. Gharibian, Y. Huang, Z. Landau and S. W. Shin. *Quantum Hamiltonian Complexity*. Foundations and Trends <sup>R</sup> in Theoretical Computer Science, vol. 10, no. 3, pp. 159–282, 2014.

# **1**

# <span id="page-4-0"></span>**Introduction**

*"Computers are physical objects, and computations are physical processes. What computers can or cannot compute is determined by the laws of physics alone. . . "*

*— David Deutsch [\[125\]](#page-122-0)*

The Cook-Levin Theorem [\[53,](#page-117-0) [111\]](#page-121-0), which states that the SATIS-FIABILITY problem is NP-complete, is one of the cornerstones of modern computational complexity theory [\[22\]](#page-114-0). One of its implications is the following simple, yet powerful, statement: Computation is, in a well-defined sense, *local*. Yet, as David Deutsch's quote above perhaps foreshadows, this is not the end of the story, but rather its beginning. Indeed, just as a sequence of computational steps on a Turing machine can be encoded into local classical constraints (as in the Cook-Levin theorem), the quantum world around us also evolves "locally", and this quantum evolution can be encoded into an analogous notion of local *quantum* constraints. The study of such quantum constraint systems underpins an emerging field at the intersection of condensed matter physics, computer science, and mathematics, known as *Quantum Hamiltonian Complexity (QHC)*.

At the heart of QHC lies a central object of study: The notion of a *local Hamiltonian H*, which can intuitively be thought of as a quantum constraint system (in this introduction, we will keep our discussion informal in order to convey high-level ideas; all formal definitions, including an introduction to quantum information, are given in Chapter [2\)](#page-8-0). To introduce local Hamiltonians, we begin with the fact that the state of a quantum system *S* on *n* qudits is described by some *d n* -dimensional complex unit vector |*ψ*i ∈ (C *d* ) ⊗*n* . How can we describe the evolution of the state |*ψ*i of *S* as time elapses? This is given by the Schrödinger equation, which says that after time *t*, the new state of our system is *e* <sup>−</sup>*iHt*|*ψ*i, where *H* is a *d <sup>n</sup>* × *d n* -dimensional complex (more precisely, Hermitian) operator called a *Hamiltonian*. Here, the precise definition of the matrix exponential *e iHt* is irrelevant; what *is* important is the dependence of the Schrödinger equation on *H*. In other words, Hamiltonians are intricately tied to the evolution of quantum systems. We thus arrive at a natural question: Which classes of Hamiltonians correspond to *actual* quantum evolutions for systems occurring in nature? It turns out that typically, only a special class of Hamiltonians is physically relevant: These are known as *local* Hamiltonians.

Roughly, a *k-local* Hamiltonian is a Hermitian matrix which has a succinct representation of the form

$$H = \sum_{i} H_{i},$$

where each *H<sup>i</sup>* acts "non-trivially" only on some subset of *k* qudits. Here, each *H<sup>i</sup>* should be thought of as a "quantum constraint" or "clause", analogous to the notion of a *k*-local clause in classical constraint satisfaction problems. For example, just as a classical clause such as (*x<sup>i</sup>* ∨ *x<sup>j</sup>* ∨ *xk*) for *x<sup>i</sup> , x<sup>j</sup> , x<sup>k</sup>* ∈ {0*,* 1} forces its bits to lie in set *xixjx<sup>k</sup>* ∈ {001*,* 010*,* 011*,* 100*,* 101*,* 110*,* 111} (where ∨ denotes logical OR), a quantum clause *H<sup>i</sup>* restricts the state of the *k* qudits it acts on to lie in a certain *subspace* of (C *d* ) ⊗*n* . Moreover, each clause *H<sup>i</sup>* requires *O*(*k*) bits express (assuming all matrix entries are specified to constant precision). This is because each *H<sup>i</sup>* is given as a *d <sup>k</sup>* ×*d k* complex matrix (this is made formal in Section [2.2\)](#page-19-0). As a result, although *H* itself is a matrix of dimension *d <sup>n</sup>* ×*d n* , i.e. *H* has dimension exponential in *n* the 4 Introduction

number of qudits, the description of *H* in terms of local clauses {*Hi*} has size *polynomial* in *n*.

Since local Hamiltonians are intricately tied to the time evolution of quantum systems in nature, the goal of QHC is to study properties of local Hamiltonians *H*. Common computational tasks include estimating the *ground state energy* (smallest eigenvalue) of *H*, or computing features of *H*'s *ground state* (eigenvector corresponding to the smallest eigenvalue). Intuitively, the ground state can be thought of as the vector |*ψ*i which "maximally satisfies" the constraints {*Hi*} (i.e. the "optimal solution" to the quantum constraint system), and is of particular interest as it encodes the state of the corresponding quantum system when cooled to low temperature. In fact, any classical Constraint Satisfaction Problem (CSP) of arity *k* can be embedded into a *k*-local Hamiltonian, such that determining the ground state of the Hamiltonian yields the optimal solution to the CSP. (This connection is made explicit in [§2.2.](#page-19-0)) Thus, ground states are interesting from a complexity theoretic perspective.

Let us also motivate ground states from a physics perspective. Consider the case of helium-4: When cooled to near absolute zero, helium-4 relaxes to a state |*ψ*i which is the ground state of some local Hamiltonian *H* (the precise form of *H* is beyond the scope of this introduction). This ground state exhibits an exotic phase of matter known as *superfluidity* — it acts like a fluid with zero viscosity. (See [\[1\]](#page-113-1) for a video demonstrating this remarkable phenomenon.) Ideally, we would like to understand the properties of the superfluid phase demonstrated by |*ψ*i, so that, for example, we can in turn use this knowledge to design new, advanced materials. In this direction, QHC might ask questions such as: Which quantum systems in nature have a ground state with a succinct classical representation? Can we run efficient classical simulations to predict when a quantum system will exhibit interesting phenomena, such as a phase transition? Can we quantify the hardness of determining certain properties of local Hamiltonians by establishing connections to computational complexity theory? In the context of helium-4, for example, the first of these questions is particularly relevant — to the best of our knowledge, a closed form for the ground state energy or the ground state of helium-4 remain elusive. (Heuristic approximations based on variational methods, however, have long been known; see, e.g. [\[139\]](#page-123-0).)

This state of affairs illustrates the formidable challenge facing QHC: Namely, we are interested in computing properties of *k*-local Hamiltonians *H*, which are matrices of dimension *d <sup>n</sup>* × *d n* , whereas an efficient algorithm must run in time polynomial in *n*, the number of qudits *H* acts on. Despite this challenge, QHC has proven a very fruitful area of research. For example, in 1999 Kitaev established [\[106\]](#page-121-1) a quantum version of the celebrated Cook-Levin theorem [\[53,](#page-117-0) [111\]](#page-121-0) for local Hamiltonian systems. In 2006, Bravyi gave a polynomial time algorithm for solving the quantum analogue of 2-SATISFIABILITY, known as Quantum 2-SAT [\[38\]](#page-116-0). And though the heuristic approach of White [\[168,](#page-125-0) [169\]](#page-125-1) (known as "Density Matrix Renormalization Group") was known to solve 1-dimensional (gapped) Hamiltonians in practice efficiently, Hastings' 1D area law in 2007 [\[88\]](#page-119-0) helped explain the efficacy of this heuristic by strongly characterizing the entanglement structure of such 1-dimensional systems. This survey aims to review a select subset of such fundamental results in QHC.

To help make this survey accessible to computer scientists with little or no background in quantum information, we begin in [§2.1](#page-8-1) with a review of basic quantum information. We next establish some of the fundamental definitions of QHC in [§2.2,](#page-19-0) including an explicit sketch of how an instance of 3-CSP can be encoded into a local Hamiltonian. With this basic background in place, we finally proceed in Chapter [3](#page-24-0) to give a roadmap for the remainder of this survey.

**2**

# <span id="page-8-0"></span>**Preliminaries**

We now review the basics of quantum information ([§2.1\)](#page-8-1) and introduce fundamental concepts in QHC ([§2.2\)](#page-19-0). For readers interested in further details on quantum information in general, please see the text of Nielsen and Chuang [\[125\]](#page-122-0) (see also [\[106,](#page-121-1) [101\]](#page-120-0) for alternate textbooks) or the thesis of Gharibian [\[71\]](#page-118-0) for a self-contained brief introduction. (We remark that [§2.1](#page-8-1) here is essentially a condensed version of Chapter 1.4 of the thesis of Gharibian [\[71\]](#page-118-0).) For a review of quantum complexity theory, see the survey of Watrous [\[165\]](#page-125-2). For a physics-oriented introduction to Hamiltonian complexity, we refer the reader to the survey of Osborne [\[129\]](#page-122-1).

## <span id="page-8-1"></span>**2.1 Basics of quantum information**

Let us first set notation and state a number of useful linear algebraic definitions; intuitively, the latter are necessary, as the mathematical language behind quantum mechanics is linear algebra.

**Notation.** The symbols C, R, and Z denote the sets of complex, real, and integer numbers, respectively. For *m* a positive integer, the notation [*m*] indicates the set {1*, . . . , m*}. The terms L(X ), U (X ), H (X ), and Pos (X ) denote the sets of linear, unitary, Hermitian, and positive semidefinite operators acting on complex Euclidean space X , respectively. For the purposes of this survey, our choice of X will always be C *d* for some positive integer *d*. Recall that an operator *A* is unitary if *AA*† = *A*†*A* = *I*, *A* is Hermitian if *A* = *A*† (where *A*† denotes the conjugate transpose of *A*), and *A* is positive semidefinite if *x* †*Ax* ≥ 0 for all complex vectors *x*. The orthogonal projector onto vector space X is denoted Π<sup>X</sup> ; by definition, Π<sup>2</sup> <sup>X</sup> = Π<sup>X</sup> . The notation *A B* means operator *A* − *B* is positive semidefinite. The smallest (largest) eigenvalue of *A* ∈ H(X ) is given by *λ*min(*A*) (*λ*max(*A*)). The trace, Frobenius, and spectral (or operator) norms of *A* ∈ L(X ) are defined as

$$\begin{split} \parallel A \parallel_{\operatorname{tr}} &:= & \operatorname{Tr} \left( \sqrt{A^{\dagger} A} \right), \\ \parallel A \parallel_{\operatorname{F}} &:= & \sqrt{\operatorname{Tr} (A^{\dagger} A)}, \\ \parallel A \parallel_{\infty} &:= & \max_{|x\rangle \in \mathcal{X} \text{ s.t. } \parallel x \parallel_2 = 1} \parallel A |x\rangle \parallel_2, \end{split}$$

respectively, where := denotes a definition, and where Tr(*A*) := P *<sup>i</sup> A*(*i, i*) for the (*m, n*)th entry of *A* given by *A*(*m, n*). Unless otherwise noted, all logarithms are taken to base two.

#### <span id="page-9-0"></span>**2.1.1 The four postulates of quantum mechanics**

With our notation in place, we can now provide a brief introduction to quantum information. For this, we introduce the four postulates of quantum mechanics, which intuitively prescribe the following concepts: How a quantum state is described, how one "reads" or measures a quantum state, what operations can be performed on a quantum state, and finally, how one describes multiple quantum systems jointly.

**1. Describing quantum states.** Let X = C *d* for *d* ≥ 2. In a nutshell, a linear operator *ρ* ∈ L(X ) describes a *d*-dimensional quantum state if and only if *ρ* is positive semi-definite and has trace 1, i.e. *ρ* ∈ Pos (X ) and Tr(*ρ*) = 1. Let us now provide some intuition as to how this statement comes about.

8 Preliminaries

In classical computing, the basic unit of information is a bit, which takes on values in the set {0*,* 1}. One can equivalently encode a bit using the set {|0i*,* |1i}, where {|0i*,* |1i} ⊆ C 2 is the standard basis for C 2 , i.e. |0i = (1*,* 0)*<sup>T</sup>* and |1i = (0*,* 1)*<sup>T</sup>* . Here, the notation |*ψ*i (called a "ket") denotes a column vector labeled by *ψ*. The key difference between classical bits and quantum bits (or *qubits*) is that in the quantum world, one can "interpolate" between the two discrete values |0i and |1i by taking a *superposition*, i.e. the vector

$$|\psi\rangle = \alpha|0\rangle + \beta|1\rangle \tag{2.1}$$

describes a valid quantum state if |*α*| <sup>2</sup> + |*β*| <sup>2</sup> = 1. In other words, any unit vector in C <sup>2</sup> describes a quantum bit, or *qubit*.

More generally, any unit vector |*ψ*i ∈ C *<sup>d</sup>* describes a *d*-dimensional quantum state, sometimes dubbed a qu*d*it. Such vectors are called *pure* states, as they describe the state of a quantum system which is not subject to external "noise", or more generally is evolving in isolation from its environment. Sometimes, however, interaction between our system and its environment may be inevitable (such as when we wish to measure our system); this will inherently inject some "noise" into our system, and we thus need a mathematical approach to model this. To do so, we simply permit probabilistic mixtures of pure states, more generally referred to as *mixed* states. Such probabilistic mixtures are described in the following straightforward manner, known as the *density matrix* formalism.

Associated with any probabilistic mixture is an *ensemble E*,

$$E = \left\{ \{p_i\}_{i=1}^k, \{|\psi_i\rangle\langle\psi_i|\}_{i=1}^k \right\},\tag{2.2}$$

where {*pi*} *k <sup>i</sup>*=1 forms a probability distribution and {|*ψi*i} ⊆ X is a set of unit vectors. Here, the notation h*ψ*| (called a "bra") denotes the row vector corresponding to the conjugate transpose of |*ψ*i. Thus, if |*ψ*i ∈ C *d* , then |*ψ*ih*ψ*| is a rank-1 *d* × *d* complex matrix. Returning to our discussion, the mixed quantum state *ρ<sup>E</sup>* corresponding to the ensemble *E* is given by:

<span id="page-10-0"></span>
$$\rho_E = \sum_{i=1}^k p_i |\psi_i\rangle\langle\psi_i|. \tag{2.3}$$

Here, *ρ<sup>E</sup>* is called the *density matrix* describing the underlying quantum system. We denote the set of density operators acting on X as D(X ).

Let us now tie the density operator formalism back into the statement made at the beginning of this section: That *ρ* represents a quantum state if and only if *ρ* 0 and Tr(*ρ*) = 1. Note that since in Equation [2.3,](#page-10-0) *ρ* is a non-negative sum of positive semidefinite operators, we have *ρ* 0. Moreover, by applying the cyclic property of the trace (i.e. that Tr(*ABC*) = Tr(*CAB*) for all *A, B, C*), we have

$$\operatorname{Tr}(\rho) = \sum_{i=1}^{k} p_i \operatorname{Tr}(|\psi_i\rangle\langle\psi_i|) = \sum_{i=1}^{k} p_i \langle\psi_i|\psi_i\rangle = \sum_{i=1}^{k} p_i = 1,$$

where h*v*|*w*i denotes the inner product between vectors |*v*i and |*w*i. Conversely, we can now intuitively see why any *ρ* ∈ X with *ρ* 0 and Tr(*ρ*) = 1 describes a valid quantum state — recall that any positive semi-definite operator *A* can be diagonalized via its *spectral decomposition A* = P *<sup>i</sup> λi*(*A*)|*λi*(*A*)ih*λi*(*A*)|, where *λi*(*A*) ≥ 0 are the eigenvalues of *A*, and |*λi*(*A*)i are the corresponding eigenvectors. Then, given *ρ* satisfying *ρ* 0 and Tr(*ρ*) = 1, taking its spectral decomposition allows us to immediately recover an ensemble {{*pi*}*,* {|*ψi*ih*ψ<sup>i</sup>* |}}. In this case, the *p<sup>i</sup>* , which correspond to the eigenvalues of *ρ*, sum to 1 due to the trace constraint on *ρ*.

Finally, note that although we have attempted to present a simple exposition of how quantum states are classically described via density operators, in reality the precise interpretation of what a density operator *means* is highly non-trivial and remains a subject of intense debate.

**2. Measuring quantum states.** Now that we have an approach for describing quantum states, we require a formalism for modeling how a quantum state is "observed" or measured. For this, let *ρ* ∈ D(X ) be a density matrix. Then, a quantum *measurement* is formalized by a set of operators {*Mi*} ⊆ L(X ) satisfying

$$\sum_{i} M_i^{\dagger} M_i = I, \tag{2.4}$$

where the latter is called the *completeness relation*. The act of measuring *ρ* with {*Mi*} is in general an inherently probabilistic process, 10 Preliminaries

*even if ρ* corresponds to a pure state (unlike in the classical case of bits). Specifically, when measuring *ρ* with respect to {*Mi*}, we obtain outcome *i* with probability given by

Pr(outcome 
$$i \mid \rho$$
) = Tr( $M_i \rho M_i^{\dagger}$ ). (2.5)

Once a particular outcome *i* is observed, the state *ρ* "collapses" to a new state *ρ* 0 consistent with this outcome, i.e.

$$\rho' = \frac{M_i \rho M_i^{\dagger}}{\text{Pr}(\text{outcome } i \mid \rho)}.$$
 (2.6)

Note that the denominator above serves the role of normalizing *ρ* 0 so that Tr(*ρ* 0 ) = 1. Such a measurement {*Mi*} is the most general possible.

Often, however, we are interested in a special type of measurement in which each *M<sup>i</sup>* is an orthogonal projection operator additionally satisfying *MiM<sup>j</sup>* = *δijM<sup>i</sup>* . Such measurements are called *projective* or *von Neumann* measurements. An example of such a measurement used frequently is a measurement in the *computational* or *standard* basis. For X = C *<sup>d</sup>* and standard basis vectors |*i*i (which have a 1 in position *i* and zero elsewhere), such a measurement is specified via {*Mi*} for *M<sup>i</sup>* = |*i*ih*i*|. More generally, given any orthonormal basis *B* = {|*ψi*i}, measuring in basis *B* is formalized by setting *M<sup>i</sup>* = |*ψi*ih*ψ<sup>i</sup>* |.

There is a useful alternate representation of von Neumann measurements via *observables M* ∈ H(X ). Specifically, given an observable *M*, to recover the underlying von Neumann measurement, we take the spectral decomposition of *M* to obtain *M* = P *<sup>i</sup> λi*Π*<sup>i</sup>* , where *λ<sup>i</sup>* 6= *λ<sup>j</sup>* for *i* 6= *j* and each Π*<sup>i</sup>* is a projection operator (of rank possibly greater than one). Then, the measurement operators are defined as *M<sup>i</sup>* = Π*<sup>i</sup>* , and each distinct eigenvalue *λ<sup>i</sup>* corresponds to a distinct label for the corresponding measurement outcome Π*<sup>i</sup>* . The reason this representation via observables proves useful is because the *expected value* of a measurement, denoted E*M*, takes a very simple form in terms of the observable M:

$$\mathbb{E}_{M}(\rho) = \sum_{i} \lambda_{i} \operatorname{Pr}(\operatorname{outcome} i \mid \rho)$$

$$= \sum_{i} \lambda_{i} \operatorname{Tr}(\Pi_{i} \rho \Pi_{i}^{\dagger})$$

$$= \sum_{i} \lambda_{i} \operatorname{Tr}(\Pi_{i} \rho)$$

$$= \operatorname{Tr}(M \rho),$$

where the third equality follows from the cyclic property of the trace and since  $\Pi$  is Hermitian and is a projector, and the last equality since the trace is a linear map.

**3. Evolution of quantum states.** We now know how to describe a quantum state  $\rho \in \mathcal{D}(\mathcal{X})$ , as well how to model a measurement of  $\rho$ . The next question we ask is: What kind of operations (i.e. gates) can we perform on  $\rho$ ? For example, to a classical bit, we can apply a NOT gate to flip its value. What can we do to a qubit?

Just as in the case of describing quantum states, there are two scenarios to consider here: When a quantum system evolves in a manner isolated from its environment (i.e. a *closed* system), and when a system interacts with an environment during its evolution (i.e. an *open* system). Beginning with the former, the set of valid operations on a closed quantum system with state  $\rho \in \mathcal{D}(\mathcal{X})$  is the set of unitary operators  $U \in \mathcal{U}(\mathcal{X})$ . Specifically, U maps  $\rho$  to

$$\rho' := U\rho U^{\dagger}. \tag{2.7}$$

For example, for  $\rho \in \mathcal{D}(\mathbb{C}^2)$ , i.e. a single qubit, a frequently used set of unitary operators are the *Pauli* operators (where  $i := \sqrt{-1} \in \mathbb{C}$ )

$$X = \begin{pmatrix} 0 & 1 \\ 1 & 0 \end{pmatrix} \qquad Y = \begin{pmatrix} 0 & -i \\ i & 0 \end{pmatrix} \qquad Z = \begin{pmatrix} 1 & 0 \\ 0 & -1 \end{pmatrix}.$$

Note, for example, that the Pauli X plays the role of a quantum NOT gate, i.e.  $X|0\rangle = |1\rangle$  and  $X|1\rangle = |0\rangle$ . The Pauli operators are also referred to as  $\sigma_x = X$ ,  $\sigma_y = Y$ , and  $\sigma_z = Z$ . In this survey, we will use

12 Preliminaries

the fact that the operators above can be generalized to act on  $\mathbb{C}^3$ , i.e. on *qutrits*, as

<span id="page-14-1"></span>
$$\sigma_x = \frac{1}{\sqrt{2}} \begin{pmatrix} 0 & 1 & 0 \\ 1 & 0 & 1 \\ 0 & 1 & 0 \end{pmatrix}, \tag{2.8}$$

$$\sigma_x = \frac{1}{\sqrt{2}} \begin{pmatrix} 0 & -i & 0 \\ i & 0 & -i \\ 0 & i & 0 \end{pmatrix}, \tag{2.9}$$

$$\sigma_z = \begin{pmatrix} 1 & 0 & 0 \\ 0 & 0 & 0 \\ 0 & 0 & -1 \end{pmatrix}. \tag{2.10}$$

Moreover, it is common in the physics literature to define vector  $\overrightarrow{\sigma_i} := (\sigma_i^x, \sigma_i^y, \sigma_i^z)$  (sometimes also denoted  $\overrightarrow{S_i}$ ), and dot-product

<span id="page-14-0"></span>
$$\overrightarrow{\sigma_i} \cdot \overrightarrow{\sigma_j} := \sigma_i^x \sigma_i^x + \sigma_i^y \sigma_i^y + \sigma_i^z \sigma_i^z, \tag{2.11}$$

where there is an implicit tensor product between (e.g.)  $\sigma_i^x$  and  $\sigma_j^x$  above. (The tensor product is defined under "Composite quantum systems" below.)

Let us next discuss the time evolution of an open quantum system (i.e. one which interacts with its environment). In this case, the set of allowed operations strictly contains  $\mathcal{U}(\mathcal{X})$ , and is in fact the set of trace-preserving completely-positive (TPCP) maps, which we henceforth refer to as admissible maps or operations. Here, a linear map  $\Phi: \mathcal{L}(\mathcal{X}) \mapsto \mathcal{L}(\mathcal{Y})$  is trace-preserving if  $\mathrm{Tr}(\Phi(A)) = \mathrm{Tr}(A)$  for all  $A \in \mathcal{L}(\mathcal{X})$ . To define "completely positive", let us first define "positive" —  $\Phi$  is positive if  $\Phi(A) \succeq 0$  whenever  $A \succeq 0$ . Then,  $\Phi$  is completely positive if  $\Phi$  is positive even when acting only some subsystem of some larger joint system, i.e. if  $I \otimes \Phi$  is positive, where  $I \in \mathcal{L}(\mathcal{X})$ . Although the notion of TPCP maps plays an important role in quantum information, we remark that there is no loss of generality in restricting oneself to the set of unitary maps. This is because any valid TPCP operation on an open quantum system A can be simulated by moving to a larger closed joint system AB, evolving AB via a unitary operator, and sub-

sequently tracing out part of *AB*. (More on joint systems and tracing parts of them out will be said shortly.)

To further distinguish the cases of open versus closed systems, let us give a concrete example. Suppose one wishes to perform a measurement on *A*. In order to do so in a lab, one introduces a measurement apparatus, which we think of as system *B*. To complete the actual measurement, *B* must interact with *A*, implying *A* is an open system. Thus, if we look at *A* alone, the action of the measurement on *A* is not described by a unitary operator, but by a TPCP map. However, if we instead look at *AB* as a whole, this joint system is now closed, and hence its evolution is described by a unitary operator.

**Aside: Hamiltonians, and the connection to unitary operations.** We are now in a position to understand where the notion of a Hamiltonian comes from, which will be fundamental for this survey.

Recall that any closed quantum system evolves in time according to some unitary operation *U* ∈ U(X ). Now, any unitary *U* can be written as *U* = exp(*iH*) for some Hermitian *H* ∈ H(X ). To see this, let us first define the notion of an *operator function*. Specifically, for any operator *A* ∈ L(X ) admitting a spectral decomposition[1](#page-15-0) , and any function *f* : C 7→ C, we define *f*(*A*) := P *i f*(*λi*)|*λi*ih*λ<sup>i</sup>* |, where P *<sup>i</sup> λ<sup>i</sup>* |*λi*ih*λ<sup>i</sup>* | is the spectral decomposition of *A*. Then, to verify our claim about unitary operators, take the spectral decomposition *U* = P *j e iθ<sup>j</sup>* |*ψ<sup>j</sup>* ih*ψ<sup>j</sup>* | (where recall a unitary operator has its eigenvalues on the unit circle), and observe that defining

$$H = \sum_{j} \theta_{j} |\psi_{j}\rangle\langle\psi_{j}| \tag{2.12}$$

yields *U* = *e iH*. The operator *H* is called a *Hamiltonian*.

We conclude that corresponding to each *U* ∈ U(X ), there exists a Hamiltonian *H* ∈ H(X ). Where does *H* come from? It turns out that the time evolution of a closed quantum system |*ψ*i according to *H* is

<span id="page-15-0"></span><sup>1</sup>Such operators *A* are called *normal*, and satisfy *AA*† = *A* †*A*.

14 Preliminaries

given by the celebrated Schrödinger equation<sup>2</sup>,

$$i\hbar \frac{d|\psi\rangle}{dt} = H|\psi\rangle,$$
 (2.13)

where  $\hbar$  denotes Planck's constant. For a quantum system evolving from time  $t_1$  to  $t_2$ , the solution to this equation is given by

$$|\psi(t_2)\rangle = \exp\left(-i\frac{t_2 - t_1}{\hbar}H\right)|\psi(t_1)\rangle,$$
 (2.14)

i.e.  $|\psi(t_1)\rangle$  evolves to  $|\psi(t_2)\rangle$  via the unitary  $\exp\left(-i\frac{t_2-t_1}{\hbar}H\right)$ ! In other words, the notion of evolution under unitary operations arises precisely because Schrödinger's equation maps any "input" Hamiltonian H to a unitary of the form  $e^{-itH}$ .

**4. Composite quantum systems.** We have stated that a quantum state on  $\mathcal{X}$  is described by a density matrix  $\rho \in \mathcal{D}(\mathcal{X})$ . Suppose now we have two quantum systems A and B — how do we describe their joint state AB? It turns out that if A and B correspond to complex Euclidean spaces  $\mathcal{X} = \mathbb{C}^{d_x}$  and  $\mathcal{Y} = \mathbb{C}^{d_y}$ , then the joint system AB corresponds to the space  $\mathcal{X} \otimes \mathcal{Y} = \mathbb{C}^{d_x + d_y}$ . Here,  $\otimes$  denotes the *tensor product*, and is discussed further shortly.

Before we do so, however, let us make an important observation. Consider a set of n single-qubit systems  $\{\mathcal{X}_i\}_{i=1}^n$ . Then, the joint state of all n qubits is described by a density operator acting on  $\bigotimes_{i=1}^n \mathcal{X}_i = \mathbb{C}^{2^n}$ . In other words, in stark contrast to a classical system of n bits, in order to describe the joint state of n qubits, one requires an *exponential*-size density matrix, i.e.  $\rho \in \mathcal{D}(\mathbb{C}^{2^n})$ ! This was essentially the reason why Richard Feynman originally proposed [66, 67] the concept of quantum computing (see also Benioff [29, 30, 31]) — he believed quantum computers might enable an efficient study of quantum systems (which is otherwise generally intractable on a classical computer).

We now further discuss the tensor product  $\otimes$ , as it is used throughout this survey. First, for vectors  $u \in \mathcal{X}$  and  $y \in \mathcal{Y}$ , we have that

<span id="page-16-0"></span><sup>&</sup>lt;sup>2</sup>Here, we state the time-independent version of Schrödinger's equation, and consider only the corresponding class of time-independent Hamiltonians. More generally, one can consider evolution via Hamiltonians which themselves change with time, i.e. are time-dependent.

*u* ⊗ *v* ∈ X ⊗ Y, such that for all *i* ∈ [*dx*] and *j* ∈ [*dy*]

$$(\boldsymbol{u} \otimes \boldsymbol{v})(i,j) := u(i)v(j). \tag{2.15}$$

For linear operators *A* ∈ L(X ), *B* ∈ L(Y), we similarly have that *A* ⊗ *B* ∈ L(X ⊗ Y), such that *A* ⊗ *B* is a complex matrix whose index sets are given by ([*dx*] × [*dy*]*,* [*dx*] × [*dy*]) satisfying

$$(A \otimes B)((i_1, j_1), (i_2, j_2)) := A(i_1, i_2)B(j_1, j_2)$$
 (2.16)

for all *i*1*, i*<sup>2</sup> ∈ [*dx*] and *j*1*, j*<sup>2</sup> ∈ [*dy*]. The tensor product has the following properties for any *A, C* ∈ X , *B, D* ∈ Y, *c* ∈ C:

$$(A+C)\otimes B = A\otimes B + C\otimes B \tag{2.17}$$

$$A \otimes (B+D) = A \otimes B + A \otimes D \tag{2.18}$$

$$c(A \otimes B) = (cA) \otimes B = A \otimes (cB) \tag{2.19}$$

$$(A \otimes B)(C \otimes D) = AC \otimes BD \tag{2.20}$$

$$\operatorname{Tr}(A \otimes B) = \operatorname{Tr}(A)\operatorname{Tr}(B)$$
 (2.21)

$$(A \otimes B)^{\dagger} = A^{\dagger} \otimes B^{\dagger}. \tag{2.22}$$

These properties hold analogously in the vector setting.

Finally, given a description *ρ* of the state of a joint system *AB*, we now require a method for describing the marginal state on *A* (or *B*) alone. Specifically, given a composite system *ρ* ∈ D(X ⊗Y), the *reduced state ρ<sup>A</sup>* on *A* (analogously, *ρ<sup>B</sup>* on *B*) is prescribed via the linear map known as the *partial trace*, i.e.

$$\rho_A = \text{Tr}_B(\rho). \tag{2.23}$$

The partial trace is defined as follows: For any *A* ⊗ *B* ∈ L(X ⊗ Y), we have that Tr<sup>X</sup> (*A* ⊗ *B*) ∈ Y such that

$$\operatorname{Tr}_{\mathcal{X}}(A \otimes B) := \operatorname{Tr}(A)B.$$
 (2.24)

A second equivalent definition is as follows: For any orthonormal basis {*vi*} *d <sup>i</sup>*=1 for X , we have that for any *C* ∈ L(X ⊗ Y)

$$\operatorname{Tr}_{\mathcal{X}}(C) = \sum_{i=1}^{d} \left( \boldsymbol{v}_{i}^{\dagger} \otimes I \right) C \left( \boldsymbol{v}_{i} \otimes I \right).$$
 (2.25)

16 Preliminaries

For example, Tr*B*(*ρ<sup>A</sup>* ⊗ *ρB*) is simply *ρA*, and Tr*B*(|*φ* <sup>+</sup>ih*φ* <sup>+</sup>|) = *I/*2, where

|*φ* <sup>+</sup>i = 1 √ 2 |00i + 1 √ 2 |11i ∈ C <sup>2</sup> ⊗ C 2

is a special two-qubit state known as a *Bell state*.

Having introduced the concept of partial trace, we arrive at another fundamental point about joint quantum systems: The possibility of exotic *correlations* between a pair of quantum systems *A* and *B*. On one end of the spectrum lies the notion of a *tensor product* state, i.e. a state of the form *ρ<sup>A</sup>* ⊗ *ρB*. Such states are *uncorrelated*, and as such, tracing out system *B* simply yields *ρA*. At the other extreme lie states exhibiting a uniquely quantum form of correlations known as *quantum entanglement*. A canonical example of such a state is the Bell state |*φ* <sup>+</sup>i from above — in contrast to a tensor product state, it is *impossible* to express |*φ* <sup>+</sup>i ∈ X ⊗ Y as the tensor product of a pair of states |*ψ*1i ∈ X and |*ψ*2i ∈ Y! The consequence of this is that even though the joint state |*φ* <sup>+</sup>i of both qubits is fully known (i.e. is pure), tracing out *B* yields a state which is noisy or mixed. (In fact, in this case Tr*B*(|*φ* <sup>+</sup>ih*φ* <sup>+</sup>|) = *I/*2 is *maximally mixed*, in that it yields *no* information about the state of *A*.) Entanglement is one of the key characteristics distinguishing the quantum world from the classical one [\[143\]](#page-123-1), and is in fact a necessary resource for (pure state) quantum computation to exponentially outperform classical computation [\[98\]](#page-120-1).

Delving into entanglement further, it is useful to note that any bipartite pure state |*ψAB*i ∈ C *<sup>d</sup><sup>x</sup>* ⊗ C *<sup>d</sup><sup>y</sup>* can be written in terms of its *Schmidt decomposition*, such that

$$|\psi_{AB}\rangle = \sum_{i=1}^{\min(d_x, d_y)} \alpha_i |\psi_i\rangle \otimes |\phi_i\rangle.$$
 (2.26)

Here, the real *α<sup>i</sup>* ≥ 0 are called *Schmidt coefficients*, and the sets {|*ψi*i} and {|*φi*i} are orthonormal bases for C *<sup>d</sup><sup>x</sup>* and C *dy* , respectively, known as the *Schmidt bases*. The connection to entanglement is simple in the pure state case: The state |*ψ*i is entangled if and only if it has at least two non-zero Schmidt coefficients *α<sup>i</sup>* . For this reason, the number of non-zero *α<sup>i</sup>* has a special name — it is called the *Schmidt rank* of |*ψ*i. Thus, we say that |*ψ*i is entangled if and only if it has Schmidt rank at least 2. But we can do more than simply state whether |*ψ*i is entangled or not; in the pure state case, we can also quantify the *amount* of entanglement, achieved via the *entropy of entanglement*:

$$S(\operatorname{Tr}_B(|\psi\rangle\langle\psi|)) = H(\{\alpha_i\}), \tag{2.27}$$

where *S* : D(X ) 7→ R is the *von Neumann entropy* function defined as *S*(*ρ*) = −Tr(*ρ* log(*ρ*)) (recall that here we treat log as an operator function, i.e. it is applied to the eigenvalues of *ρ*, and we define 0 · log 0 = 0), and *H* denotes the classical Shannon entropy of a probability distribution defined by *H*({*pi*}) = − P *i pi* log *p<sup>i</sup>* . Notions such as the Schmidt rank and entropy of entanglement will play important roles in our discussions on matrix product states ([§6.4.1\)](#page-67-0) and area laws ([§7.5\)](#page-102-0).

We close this discussion with two final remarks. First, the partial trace is employed here as it is the unique function which correctly produces the measurement statistics for arbitrary observables *M* measured on *A* alone. Second, one can also define a notion of entanglement for mixed quantum states (which will not be relevant to this survey). Unlike the case of pure states, however, determining whether a mixed state *ρ* ∈ D(X ⊗ *Y* ) is entangled is highly non-trivial; in fact, it is strongly NP-hard [\[82,](#page-119-1) [70\]](#page-118-3).

## <span id="page-19-0"></span>**2.2 Basics of Quantum Hamiltonian Complexity**

With our background on quantum information in place, we can now introduce some fundamental concepts in Quantum Hamiltonian Complexity (QHC). We begin with a complexity class which has played a central role in the development of the field.

Specifically, the class NP can be generalized to a bounded-error quantum variant known as *Quantum-Merlin Arthur (QMA)*. The intuition behind QMA is analogous to NP, except we now replace the classical prover and verifier by a quantum prover and verifier, respectively, and stipulate that given a quantum proof |*ψ*i from the prover, the verifier is allowed to err with bounded probability at most (say) 1*/*3 as to whether the input instance is a YES or NO instance. More formally, we have the following definition, where a quantum circuit is 18 Preliminaries

simply the quantum analogue of a classical circuit in which classical gates are replaced with quantum ones such as the Pauli *X*, *Y* , and *Z* gates.

**Definition 2.1** (QMA)**.** A promise problem *A* = (*A*yes*, A*no) is in QMA if and only if there exist polynomials *p*, *q* and a polynomial-time uniform family of quantum circuits {*Qn*}, where *Q<sup>n</sup>* takes as input a string *x* ∈ Σ <sup>∗</sup> with |*x*| = *n*, a quantum proof |*y*i ∈ (C 2 ) ⊗*p*(*n*) , and *q*(*n*) ancilla qubits in state |0i ⊗*q*(*n*) , such that:

- (Completeness) If *x* ∈ *A*yes, then there exists a proof |*y*i ∈ (C 2 ) ⊗*p*(*n*) such that *Q<sup>n</sup>* accepts (*x,* |*y*i) with probability at least 2*/*3.
- (Soundness) If *x* ∈ *A*no, then for all proofs |*y*i ∈ (C 2 ) ⊗*p*(*n*) , *Q<sup>n</sup>* accepts (*x,* |*y*i) with probability at most 1*/*3.

Here, the quantum proof is given by |*y*i, and the verification circuit by the circuit family {*Qn*}. We remark that the completeness and soundness parameters of (2*/*3*,* 1*/*3) can be made exponentially close to 1 and 0 in the input size, respectively, via two approaches. The first approach is to apply the verifier's circuit many times in parallel to many copies of the proof |*y*i. The disadvantage of this technique is that it increases the proof size. (Note that it is not entirely trivial that this approach should work; namely, the prover could try to cheat as follows. Instead of sending many copies of |*y*i in tensor product, it could send some arbitrary entangled state across all proof registers. A simple analysis [\[18\]](#page-114-1) shows, however, that this type of parallel repetition indeed correctly reduces the error.) The second approach for error reduction is due to Marriot and Watrous [\[117\]](#page-121-2), who give a non-trivial procedure for exponentially reducing the error *without* increasing the proof size (albeit at the expense of increasing the verification circuit's size).

With QMA defined, we now discuss a canonical QMA-complete problem which plays a role analogous to SATISFIABILITY for NP [\[53,](#page-117-0) [111\]](#page-121-0): The Local Hamiltonian Problem. To define the latter, recall that a *k*-local Hamiltonian acting on *n* qudits is a Hermitian operator *H* = P *<sup>i</sup> H<sup>i</sup>* , where each *H<sup>i</sup>* acts non-trivially on *k* qudits (i.e. to be more accurate, if  $H_i$  acts on a set S of qudits, then the ith constraint  $H_i$  should actually be written as  $(H_i)_S \otimes I_{[n] \setminus S}$ . The motivation for this problem stems partly from the fact that, as discussed in §2.1.1, Hamiltonians are intricately tied to the time evolution of quantum systems. Moreover, in nature, such evolution is typically governed by a local Hamiltonian.

**Problem 2.1** (k-Local Hamiltonian Problem (k-LH) [106]). Given as input a k-local Hamiltonian H acting on n qudits, specified as a collection of constraints  $\{H_i\}_{i=1}^r \subseteq \mathcal{H}\left(\mathbb{C}^d\right)^{\otimes k}$  where  $k,d\in\Theta(1)$ , and threshold parameters  $a,b\in\mathbb{R}$ , such that  $0\leq a< b$  and  $(b-a)\geq 1$ , decide, with respect to the complexity measure  $\langle H\rangle+\langle a\rangle+\langle b\rangle$ :

- 1. If  $\lambda_{\min}(H) \leq a$ , output YES.
- 2. If  $\lambda_{\min}(H) \geq b$ , output NO.

Here,  $\langle A \rangle$  denotes the encoding length of object A in bits, and  $\lambda_{\min}(A)$  denotes the smallest eigenvalue of A. The value  $\lambda_{\min}(A)$  is the ground state energy of H, and its corresponding eigenvector (or eigenspace) is known as the ground state (or ground space). Note that often k-LH is phrased with  $(b-a) \geq 1/p(n)$  for some polynomial p; such an inverse polynomial gap can straightforwardly be boosted to the constant 1 above by defining H to have p(n) many copies of each local term  $H_j$  [165].

To highlight the connection between k-LH and classical satisfiability problems, let us demonstrate how an instance of k-CSP can be embedded into k-LH. Specifically, let  $\phi$  denote an instance of 3-CSP with clauses  $c_i$  which are arbitrary Boolean functions on 3 bits. Then, corresponding to each clause  $c_i$ , we add to our Hamiltonian H a diagonal local constraint  $H_i \in \mathcal{H}\left(\mathbb{C}^2\right)^{\otimes 3}$  which penalizes all non-satisfying assignments, i.e.

$$H_i = \sum_{\substack{x \in \{0,1\}^3 \\ \text{s.t. } c_i(x) = 0}} |x\rangle\langle x|.$$

In other words, suppose our assignment is  $|x\rangle$  for  $x \in \{0,1\}^n$ , such that  $c_i(x) = 0$ . Then, we have  $\text{Tr}(H_i|x\rangle\langle x|) = 1$ . Conversely, if  $c_i(x) = 1$ ,

20 Preliminaries

then Tr(*H<sup>i</sup>* |*x*ih*x*|) = 0. We conclude that a product state |*x*i ∈ (C 2 ) ⊗*n* representing a satisfying binary assignment to *φ* will achieve energy 0 on *H* = P *<sup>i</sup> H<sup>i</sup>* , i.e.

$$Tr(H|x\rangle\langle x|) = 0.$$

On the other hand, if *φ* is unsatisfiable, then for all |*x*i with *x* ∈ {0*,* 1} *n* , we have Tr(*H*|*x*ih*x*|) ≥ 1. In fact, we can conclude the same property holds for *any* |*ψ*i ∈ (C 2 ) ⊗*n* (i.e. not just for binary string assignments); this is because all *H<sup>i</sup>* simultaneously diagonalize in the standard basis, and thus without loss of generality, one can choose the ground state as a binary string. We conclude that k-LH is a generalization of *k*-CSP, and is thus at least NP-hard. Of course, we know that k-LH is expected to be much harder; in [§7.1](#page-77-1) and [§7.2,](#page-84-0) we discuss the proofs of QMA-completeness of 5-LH and 2-LH, respectively.

**The Simulation Problem.** Much of this survey focuses on the Local Hamiltonian Problem, and as such, it is important to place k-LH into the context of QHC as a whole. It turns out that k-LH is a special case of a more general problem capturing the essence of QHC, known as the Simulation Problem [\[129\]](#page-122-1). Intuitively, the latter asks how difficult it is to simulate a physical system. More formally, in the Simulation Problem one is given as input a description of a Hamiltonian *H*, an initial state *ρ*, an observable *M*, and a time *t* ∈ C, and the task is to output an estimate of the expectation

<span id="page-22-0"></span>
$$\operatorname{Tr}\left[M\frac{(e^{iHt})^{\dagger}\rho e^{iHt}}{\operatorname{Tr}\left((e^{iHt})^{\dagger}\rho e^{iHt}\right)}\right].$$
(2.28)

Note here that the denominator, Tr (*e iHt*) †*ρeiHt* , is not redundant, since for *t* ∈ C \ R, *e iHt* is not necessarily unitary. Indeed, this fact is crucial to recovering the local Hamiltonian problem, which is obtained by choosing *H* as a local Hamiltonian, setting *M* = *H*, *ρ* = *I/*Tr(*I*), and considering *t* = *iβ* for *β* ∈ R. Then, Equation [2.28](#page-22-0) reduces to

$$\operatorname{Tr}\left[H\frac{e^{-2\beta H}}{\operatorname{Tr}\left(e^{-2\beta H}\right)}\right].$$

Taking the limit *β* → +∞, the expression (*e* <sup>−</sup>2*βH*)*/*Tr(*e* <sup>−</sup>2*βH*) approaches the projector onto the ground space of *H* (where here, the normalization given by the denominator is crucial to obtain a norm 1 operator), as desired.

Finally let us make an aside: In order to recover the local Hamiltonian problem above, we chose a *complex* time *t*. There is another sense in which complex times *t* are physically important: For complex *t* which is neither purely real or imaginary, the simulation problem addresses the scenario in which a system dynamically evolves at *finite* temperature [\[129\]](#page-122-1). The latter is particularly natural, as in a lab it is often impossible to cool a quantum system all the way down to its actual ground state.

# <span id="page-24-0"></span>**Roadmap and Organization**

With our primer on quantum information ([§2.1\)](#page-8-1) and QHC ([§2.2\)](#page-19-0) covered, we are ready to lay out the roadmap for the remainder of this survey. QHC has evolved into a field with numerous areas of study, some of the most fundamental of which we shall attempt to cover here. Our first step in this journey is to present the reader with a brief history of the field from both computer science ([§4.1\)](#page-26-1) and physics ([§4.2\)](#page-31-0) perspectives.

The remainder of this survey can then be thought of as consisting of two parts: The first half ([§5](#page-35-0) and [§6\)](#page-50-0) explains concepts from condensed matter physics in a computer science-friendly language, and the second half (Chapter [7\)](#page-77-0) discusses selected computer science-inspired results in the field, beginning with Kitaev's celebrated proof that the LH problem is QMA-complete. Let us elaborate on these two parts briefly here.

We begin in the first part by asking one of the most important questions in any field of study: *Why?* Why is the topic of study interesting or useful? What are the connections between the formal model being studied and the underlying reality it is intended to represent? This is precisely the purpose of Chapter [5.](#page-35-0) In particular, here we introduce the motivations for QHC from a physics perspective, explaining key questions of interest such as the study of time evolution versus thermal equilibrium, the origin of local Hamiltonians, and fundamental concepts such as indistinguishable particles (i.e. bosons and fermions).

Chapter [6](#page-50-0) then elaborates further on these physics ideas. It begins with a glossary in [§6.1](#page-50-1) of common terms in the physics literature (such as frequently studied local Hamiltonian models including the Ising and Heisenberg models). We then discuss selected significant physics-based contributions to QHC (some of which predate QHC by decades), such as mean field theory ([§6.2\)](#page-58-0), tensor networks ([§6.3\)](#page-62-0), Density Matrix Renormalization Group ([§6.4\)](#page-65-0), and Multi-Scale Entanglement Renormalization Ansatz ([§6.5\)](#page-69-0). These are techniques used to classically represent, simulate, and compute properties of quantum systems occurring in nature. We close this section with an overview of Area Laws ([§6.6\)](#page-72-0), which are a set of conjectures and theorems about the structure of entanglement present in ground states of physically relevant quantum systems.

Moving to the second part of the survey, in Chapter [7,](#page-77-0) we review selected computer science-inspired results in QHC, beginning with Kitaev's proof that 5-LH is QMA-complete ([§7.1\)](#page-77-1). This is arguably the founding work of QHC. We then discuss Kempe, Kitaev, and Regev's use of perturbation theory gadgets to show that even 2-LH is QMAcomplete ([§7.2\)](#page-84-0); their techniques are powerful, and have since found numerous uses showing hardness results for physically motivated local Hamiltonian models. We next consider Hamiltonian models which *a priori* seem "more classical", namely those with commuting local constraints. In this direction, we discuss Bravyi and Vyalyi's results that the commuting variant of 2-LH is in NP, and thus unlikely to be QMA-complete ([§7.3\)](#page-91-0). This is interesting given that commuting Hamiltonians can nevertheless have ground states demonstrating exotic forms of entanglement. Moving on, we give a new information-theoretic presentation of Bravyi's polynomial time algorithm for Quantum 2-SAT, which we hope makes the algorithm more accessible to a computer science audience. Finally, we review Arad, Kitaev, Landau and Vazirani's combinatorial proof of a 1D area law for gapped systems ([§7.5\)](#page-102-0), which compliments and strengthens Hastings' original physics-inspired proof.

# **4**

# <span id="page-26-0"></span>**A Brief History**

The history of quantum Hamiltonian complexity has its roots in both physics and computer science. In this section, we give a brief survey of both perspectives, beginning with the latter in [§4.1,](#page-26-1) and following with the former in [§4.2.](#page-31-0) In [§4.3,](#page-33-0) we briefly list selected recent developments to both perspectives since this survey first appeared.

## <span id="page-26-1"></span>**4.1 The computer science perspective**

**The general LH problem.** In 1999, Alexei Kitaev presented [\[104,](#page-121-3) [106\]](#page-121-1) what is regarded as the quantum analogue of the Cook-Levin theorem, proving that k-LH is in QMA for *k* ≥ 1 and QMA-hard for *k* ≥ 5. His proof is based on a clever combination of the ideas behind the Cook-Levin theorem and early ideas for a quantum computer of Feynman [\[67\]](#page-118-2), and is surveyed in [§7.1.](#page-77-1) The fact that 3-LH is also QMA-complete was shown subsequently by Kempe and Regev [\[103\]](#page-120-2) (an alternate proof was later given by Nagaj and Mozes [\[124\]](#page-122-2)). Kempe, Kitaev, and Regev then showed [\[102\]](#page-120-3) that 2-LH is QMA-complete; see [§7.2](#page-84-0) for an exposition of the proof. Note that 1-LH is in P, since one can simply optimize for each 1-local term independently.

From a physicist's perspective, however, the Hamiltonians involved in the QMA-hardness reductions above are arguably not "physical", i.e. occurring in nature. To address this, Oliveira and Terhal next showed [\[127\]](#page-122-3) that LH with the Hamiltonians restricted to nearestneighbor interactions on a 2D grid is still QMA-complete. Biamonte and Love proved [\[33\]](#page-115-3) that the XY model with certain linear terms is QMA-complete, and Schuch and Verstraete [\[147\]](#page-124-0) showed a similar result for the Heisenberg model (see Chapter [6](#page-50-0) for definitions of these models). Next, in stark contrast to the classical case of MAX-2-CSP on the line (which is in P), Aharonov, Gottesman, Irani and Kempe [\[16\]](#page-114-2) showed that 2-LH with nearest-neighbor interactions on the line is also QMA-complete if the local systems have dimension at least 12. (Note: Reference [\[85\]](#page-119-2) later pointed out a small error in [\[16\]](#page-114-2), and argued that the error can be fixed using ideas from [\[16\]](#page-114-2), but at the cost of increasing the local dimension from 12 to 13.) The latter was improved to 11 [\[123\]](#page-122-4) and subsequently to 8 [\[85\]](#page-119-2). Gottesman and Irani [\[79\]](#page-119-3) obtained related results for translationally invariant 1D systems; see also Kay [\[100\]](#page-120-4) for results regarding the latter setting.

Finally, very recently, Cubitt and Montanaro established [\[54\]](#page-117-1) a quantum variant of Schaefer's Dichotomy Theorem [\[138\]](#page-123-2) for the setting of 2-LH on qubits, classifying the complexity of a very general version of LH based on which set of 2-qubit quantum constraints one incorporates in the constraint system. Their classification contains the following levels: Problems are either in P, NP-complete, TIM-complete, or QMA-complete, where TIM is defined [\[54\]](#page-117-1) as the set of problems which are polynomial-time equivalent to solving the general Ising model with transverse magnetic fields. Note, however, that due to the perturbation theory techniques employed in [\[54\]](#page-117-1), the use of large and possibly negative weights on local constraints is required; for this reason, the results of [\[54\]](#page-117-1) do not capture the complexity of certain physical models such as the Heisenberg anti-ferromagnet.

**Quantum SAT.** To be precise, the LH problem does not generalize *k*-CSP, but rather (the decision version of) its optimization variant MAX-*k*-CSP. One can ask how the complexity of LH changes if we 26 A Brief History

instead focus on a restricted version intended to generalize *k*-CSP. In this direction, in 2006 Bravyi [\[38\]](#page-116-0) defined Quantum *k*-SAT (*k*-QSAT), in which all local constraints are positive semidefinite, and the question is whether the ground state energy is zero (in this case, *H* is called *frustration-free*, in that the optimal assignment lies in the null space of every interaction term), or bounded away from zero (i.e. the Hamiltonian is *frustrated*). He showed that 2-QSAT is in P (see [§7.4](#page-96-0) for an exposition), and that *k*-QSAT is QMA<sup>1</sup> -complete for *k* ≥ 4, where QMA<sup>1</sup> is QMA with perfect completeness. Recently, Gosset and Nagaj showed [\[77\]](#page-119-4) that 3-QSAT is also QMA<sup>1</sup> -complete.

**Stoquastic LH.** A natural special case of LH is that of *stoquastic* local Hamiltonians, in which the local constraints have only nonpositive off-diagonal matrix elements in the computational basis. This class of LH does not suffer from the so-called "sign problem" in quantum Monte Carlo simulations (quantum Monte Carlo is not a quantum algorithm; it is just a classical Monte Carlo algorithm applied to quantum systems) and is thus heuristically expected to be easier than the general LH problem. Indeed, the Stoquastic *k*-SAT problem, defined as the stoquastic variant of Quantum *k*-SAT, was shown to be in Merlin-Arthur (MA) for *k* ≥ 1 and MA-complete for *k* ≥ 6 by Bravyi, Bessen, and Terhal [\[40\]](#page-116-1) and Bravyi and Terhal [\[44\]](#page-116-2). (Incidentally, this was the first non-trivial example of an MA-complete promise problem.) The problem Stoquastic LH-MIN, defined as k-LH with stoquastic Hamiltonians, was shown to be contained in AM [\[42\]](#page-116-3) and complete for the class StoqMA [\[40\]](#page-116-1) for *k* ≥ 2. Here, StoqMA is a variant of QMA in which the verifier is restricted to preparing qubits in the states |0i and |+i, performing classical reversible gates, and measuring in the Hadamard (i.e. |+i*,* |−i) basis. Finally, Jordan, Gosset, and Love showed that computing the *largest* eigenvalue of a stoquastic local Hamiltonian is QMA-complete [\[96\]](#page-120-5).

**Commuting LH.** Unlike classical constraint satisfaction problems, quantum constraints do not necessarily pairwise commute. It is thus natural to ask how crucial this non-commuting property is to the QMA- completeness of LH. In this direction, Bravyi and Vyalyi showed [\[45\]](#page-116-4) that commuting 2-LH on qudits is in NP. Aharonov and Eldar subsequently showed [\[13\]](#page-114-3) that 3-LH Hamiltonian on *qubits* is in NP, as well as for qutrits on "nearly Euclidean" interaction graphs. Schuch showed that 4-LH on qubits arranged in a square lattice is in NP [\[144\]](#page-123-3). Hastings proved that special cases of 4-LH on *d*-dimensional qudits on a square lattice is in NP [\[89\]](#page-119-5). Aharonov and Eldar proved that approximating the ground state energy of commuting local Hamiltonians on good locally-expanding graphs within an additive error of *O*() is in NP [\[14,](#page-114-4) [15\]](#page-114-5). Finally, Gharibian, Landau, Shin, and Wang showed [\[74\]](#page-118-4) that the commuting variant of the Stoquastic *k*-SAT problem is in NP for logarithmic *k* and any constant *d*.

In terms of efficiently solvable variants of commuting LH, Yan and Bacon [\[178\]](#page-126-0) showed that the special case in which all commuting terms are products of Pauli operators is in P. Aharonov, Arad, and Irani [\[9\]](#page-113-2) and Schuch and Cirac [\[146\]](#page-123-4) showed that commuting LH in 1D can be solved efficiently by dynamic programming.

**Bosons and Fermions.** Approximating the ground state energy of Hamiltonians acting on indistinguishable particles is also QMA-hard, as shown by Liu, Christandl and Verstraete for fermions [\[115\]](#page-121-4) and Wei, Mosca, and Nayak for bosons [\[166\]](#page-125-3). Schuch and Verstraete [\[147\]](#page-124-0) showed QMA-hardness for the Hubbard model, whereas very recently, Childs, Gosset, and Webb showed QMA-hardness for the Bose-Hubbard model [\[49\]](#page-116-5). See Chapter [5](#page-35-0) for more on indistinguishable particles.

**Approximation algorithms for LH.** Given the prevalence of heuristic algorithms for solving k-LH, a natural question is whether rigorous (classical) approximation algorithms for k-LH can be derived. Here, Bansal, Bravyi and Terhal showed [\[27\]](#page-115-4) that *k*-LH on bounded degree planar graphs, as well as on the unbounded degree star graph, can be approximated within relative error for any ∈ Θ(1) in polynomial time, i.e. they gave a Polynomial Time Approximation Scheme (PTAS). Gharibian and Kempe next gave [\[72\]](#page-118-5) a PTAS for approximating the best *product-state* solution for k-LH on dense 28 A Brief History

interaction graphs, and showed that product state solutions yield a (*d* 1−*k* )-approximation to the optimal solution for *arbitrary* (i.e. even non-dense) interaction graphs on *d*-dimensional systems. Based on numerical evidence, they conjectured[1](#page-30-0) that for dense graphs, a quantum de Finetti theorem without symmetry holds, which can in turn be exploited to yield a PTAS for dense k-LH (as suggested by mean-field theory folklore). Indeed, Brandão and Harrow proved [\[37\]](#page-116-6) this conjecture, along with other results: A PTAS for planar graphs (improving on [\[27\]](#page-115-4)), and an efficient approximation algorithm for graphs of low threshold rank. Finally, Bravyi has recently given [\[39\]](#page-116-7) a Fully Polynomial Randomized Approximation Scheme (FPRAS) for approximating the partition function of the transverse field Ising model (which in turn implies an efficient approximation algorithm for determining the ground state energy of the model).

**Hardness of approximation for LH.** The PCP Theorem [\[24,](#page-115-5) [23\]](#page-115-6) is one of the crowning achievements of modern complexity theory. As such, a major open question in quantum Hamiltonian complexity is whether a *quantum* version of this theorem holds [\[18,](#page-114-1) [2\]](#page-113-3). Rigorously formulated in the work of Aharonov, Arad, Landau and Vazirani [\[10\]](#page-114-6), the question has attracted much attention in the last decade. For example, Reference [\[10\]](#page-114-6) proved that a quantum analogue of Dinur's gap amplification step in her proof of the PCP theorem [\[58\]](#page-117-2) can be shown in the quantum setting. For further details on the quantum PCP conjecture, we refer the reader to the recent survey dedicated to the topic by Aharonov, Arad, and Vidick [\[12\]](#page-114-7).

More generally, in terms of hardness of approximation for quantum complexity classes, Gharibian and Kempe [\[73\]](#page-118-6) defined a quantum version of Σ *p* 2 (the second level of the Polynomial Time Hierarchy), and showed hardness of approximation for various local Hamiltonianrelated problems such as Quantum Succinct Set Cover. Reference [\[73\]](#page-118-6) also showed a hardness of approximation and completeness result for QCMA, which is defined as QMA with a *classical* prover [\[18\]](#page-114-1). (QCMA is also known by the name Merlin-Quantum-Arthur (MQA) [\[165\]](#page-125-2).)

<span id="page-30-0"></span><sup>1</sup>Private communication with F. Brandão.

## <span id="page-31-0"></span>**4.2 The physics perspective**

We now briefly describe the history of quantum Hamiltonian complexity from a physics perspective. This section is by no means comprehensive; the reader is referred to the surveys of Verstraete, Murg, and Cirac [\[154\]](#page-124-1) and Osborne [\[129\]](#page-122-1), for example, or to their friendly neighborhood physicist for further details.

**Classical Hamiltonians.** Beginning with the case of classical Hamiltonians, an early and canonical example of computational hardness is Baharona's work [\[26\]](#page-115-7), which showed that finding a ground state and computing the magnetic partition function of an Ising spin glass in a nonuniform magnetic field are NP-hard tasks. Jerrum and Sinclair, on the other hand, showed [\[95\]](#page-120-6) #P-completeness of computing the partition function of the ferromagnetic Ising model, and gave a Fully Polynomial Randomized Approximation Scheme (FPRAS) in the same paper. As implied by the title of this paragraph, note that the Ising model is *classical* in that all variables are assigned values in the set {+1*,* −1}; thus, the ground state has an efficient classical description.

**Quantum Hamiltonians.** In contrast, for *quantum* Hamiltonians, the last two decades have seen much effort towards classifying when a ground state can be described efficiently classically [\[154\]](#page-124-1). One of the main instigators of this push was White's celebrated Density Matrix Renormalization Group[2](#page-31-1) (DMRG) method [\[168,](#page-125-0) [169\]](#page-125-1), which is a heuristic algorithm performing remarkably well in practice for finding ground states of 1D quantum systems. It was later realized [\[130,](#page-122-5) [136,](#page-123-5) [155,](#page-124-2) [154,](#page-124-1) [167\]](#page-125-4) that DMRG can be viewed as a variational algorithm over the class of tensor network states known as Matrix Product States (MPS).

More generally, tensor network states have a long history in physics, appearing in works as early as 1941 [\[108\]](#page-121-5) (see [\[126\]](#page-122-6) for a survey). As 1D tensor networks, MPS [\[131\]](#page-122-7) are arguably the most basic form of

<span id="page-31-1"></span><sup>2</sup>Note: The word *Group* does not actually refer to a group in the usual mathematical sense here.

30 A Brief History

such states. They have been used in the last decade, for example, by Vidal [\[157,](#page-124-3) [158\]](#page-124-4) to efficiently classically simulate "slightly entangled" quantum computation (or quantum evolution). Generalizations of MPS (e.g., to higher dimensions) have also been proposed, such as the Projected Entangled Pair States (PEPS) of Verstraete and Cirac [\[152,](#page-124-5) [156\]](#page-124-6), and the Multiscale Entanglement Renormalization Ansatz (MERA) of Vidal [\[159,](#page-124-7) [160\]](#page-124-8). Note that while MPS and MERA networks can be efficiently contracted, Schuch, Wolf, Verstraete and Cirac have shown that contracting a PEPS network is in general #P-complete [\[148\]](#page-124-9). More recently, Gharibian, Landau, Shin, and Wang showed [\[74\]](#page-118-4) that even the basic task of determining whether an arbitrary tensor network represents a non-zero vector is not in the Polynomial-Time Hierarchy [\[119\]](#page-122-8) unless the hierarchy collapses.

Continuing with applications of tensor networks in the study of ground spaces, Hastings showed [\[88\]](#page-119-0) in 2007 that the ground state of gapped 1D Hamiltonians can be well approximated by an MPS with polynomial bond dimension; this helped explain the effectiveness of DMRG. However, DMRG is a heuristic, and a rigorous proof that such a MPS can be found in polynomial time required further work. In this direction, Aharonov, Arad, and Irani [\[9\]](#page-113-2) and Schuch and Cirac [\[146\]](#page-123-4) showed that given a fixed bond dimension as input, the optimal MPS of that bond dimension can be found efficiently via dynamic programming. Note that their algorithm does not require the 1D Hamiltonian to have a spectral gap. For gapped systems, Arad, Kitaev, Landau and Vazirani subsequently showed [\[19\]](#page-114-8) that an MPS with sublinear bond dimension suffices to approximate the ground state; combined with the algorithms of [\[9,](#page-113-2) [146\]](#page-123-4), this yielded a subexponential time algorithm for gapped systems. Finally, Landau, Vazirani, and Vidick showed [\[110\]](#page-121-6) that the problem of finding an approximation to the ground state of a 1D gapped system is in BPP.

**Area laws.** A key problem in quantum many-body physics is understanding the entanglement structure of a ground state. Here, a specific question which has attracted much attention is the possible existence of area laws. Roughly, an *area law* says that for any subset *S* of particles chosen from an *n*-particle ground state, the amount of entanglement crossing the cut between *S* and its complement scales not with the size of *S*, but rather with the size of the *boundary* of *S*. In this direction, a breakthrough result was Hastings' proof [\[88\]](#page-119-0) of an area law for gapped 1D systems. A combinatorial proof improving on Hastings' result for the frustration-free case was later given by Aharonov, Arad, Landau and Vazirani [\[11,](#page-114-9) [20\]](#page-114-10), followed by a proof of Arad, Kitaev, Landau, and Vazirani's [\[19\]](#page-114-8) which applies in frustrated settings as well. Whether a 2D area law holds remains a challenging open question. This subject will be treated in more detail in [§6.6](#page-72-0) and [§7.5.](#page-102-0)

# <span id="page-33-0"></span>**4.3 Selected recent developments**

The field of Quantum Hamiltonian Complexity is rapidly evolving, with a number of developments having taken place since this survey first appeared. We briefly list a selected number of these developments below.

Beginning with computer science-oriented results, Cubitt, Perez-Garcia and Wolf showed [\[55\]](#page-117-3) that determining whether a translationally-invariant, nearest-neighbor Hamiltonian on a 2D square lattice (with constant local dimension) is gapped is undecidable. Bravyi and Hastings showed [\[43\]](#page-116-8) that estimating the ground state energy of the Transverse field Ising Model on degree-3 graphs is StoqMA-complete, thus completing the complexity classification of Cubitt and Montanaro [\[54\]](#page-117-1). Gosset, Terhal, and Vershynina showed [\[78\]](#page-119-6) how to perform universal adiabatic quantum computation using the space-time circuitto-Hamiltonian construction. Fitzsimons and Vidick gave [\[68\]](#page-118-7) a multiprover interactive proof system for the Local Hamiltonian problem involving a constant number of entangled provers. Chubb and Flammia [\[50\]](#page-117-4) extended the works of Landau, Vazirani and Vidick [\[110\]](#page-121-6) and Huang [\[91\]](#page-120-7) to give a polynomial-time algorithm for approximating ground space projectors of gapped 1D Hamiltonians with degenerate ground spaces. Gharibian and Sikora showed [\[75\]](#page-118-8) that the following problem, motivated by quantum memories, is QCMA-complete: Given a local Hamiltonian *H* and two ground states |*ψ*1i and |*ψ*2i of *H*, is there a sequence of local unitaries mapping |*ψ*1i to |*ψ*2i "through" the 32 A Brief History

ground space of *H*? Arad, Santha, Sundaram and Zhang [\[21\]](#page-114-11) and de Beaudrap and Gharibian [\[56\]](#page-117-5) independently gave linear time classical algorithms for quantum 2-SAT, improving on Bravyi's quartic time algorithm [\[38\]](#page-116-0).

In the physics direction, Ge and Eisert showed [\[69\]](#page-118-9) that in two and higher dimensions, it is not in general true that an area law for the Renyi entanglement entropy implies the ability to faithfully describe a quantum many-body state by an efficient tensor network. Aharonov *et al.* showed [\[17\]](#page-114-12) that a *generalized* version of the area law fails to hold. Movassagh and Shor showed [\[122\]](#page-122-9) that a generalization of Bravyi *et al.*'s [\[41\]](#page-116-9) spin-1 model to integer spin-*s* chains (*s >* 1) yields a power law violation of the area law (the energy gap in these models is an inverse polynomial in the system size). Brandão and Cramer showed [\[36\]](#page-115-8) that exponential decay in the specific heat capacity at low temperatures yields an area law (up to a logarithmic correction) for low-energy states (i.e., not just the ground state). Mariën *et al.* proved [\[116\]](#page-121-7) the stability of the area law for entanglement entropy in quantum spin systems in the setting of adiabatic and quasi-adiabatic evolutions.

# <span id="page-35-0"></span>**Motivations From Physics**

We have thus far defined *k*-local Hamiltonians and discussed a brief history of their study from computer science and physics perspectives. However, we have not yet asked perhaps the most fundamental question: *Why?* Namely, where do Hamiltonians come from, and why do we care about their study? Where does the picture sketched thus far fit into a condensed matter physicist's views of what is important and what is not? In this section, we attempt to answer these questions.

We begin in [§5.1](#page-35-1) and [§5.2](#page-36-0) by discussing the high-level questions condensed matter physics is typically interested in. In [§5.3,](#page-38-0) we briefly pause to consider where Hamiltonians come from, and discuss challenges faced by physicists regarding their use. Finally, [§5.4](#page-39-0) gives a brief introduction to classical and quantum techniques for overcoming the challenges mentioned above.

## <span id="page-35-1"></span>**5.1 Setting the stage**

To set the stage, we first clarify the high-level settings in which the study of local Hamiltonians is relevant to condensed matter physicists: 1. **The question.** Typically, we are interested in this question: Given a quantum state *ρ*, compute some *local* property of *ρ* (see, e.g., Equation [2.28\)](#page-22-0). In other words, determining an accurate description of the *entire* wave function is not always necessary. (There are exceptions to this statement, such as when studying topological properties, which are intrinsically *non*-local.) For example, given a state *ρ* (either in the lab or via some succinct classical representation), we might wish to estimate the 2-point correlation function

$$\langle \sigma_m^z \sigma_n^z \rangle := \operatorname{Tr} \left[ \rho(\sigma_m^z \otimes \sigma_n^z) \right],$$

where *σ z <sup>m</sup>* denotes the Pauli *Z* operator applied to qubit *m*. Such local properties are dubbed *intensive*, in that they do not scale with the system's size. In contrast, the ground state energy of a Hamiltonian may scale with the system size, and is thus *extensive*.

2. **The setting.** When it comes to interaction (i.e. constraint) graphs, it is natural for theoretical computer scientists to study constraint satisfaction problems on a variety of graphs: Sparse graphs, dense graphs, expanders, and so forth. Condensed matter physicists, on the other hand, often simplify their models approximating the physical world by assuming that the collection of quantum particles to be studied lives on a *d*-dimensional lattice of *N* sites, and that all interactions are nearest-neighbor. Indeed, typically in real materials particles *are* arranged in a regular lattice and the interaction range is short. Moreover, we are interested in the behavior of local properties in the thermodynamic limit *N* → +∞, since *N* is very large in a macroscopic piece of material.

We thus henceforth focus mainly on local properties of systems arranged on a lattice in the remainder of this section.

## <span id="page-36-0"></span>**5.2 Time evolution versus thermal equilibrium**

Given that we wish to study local properties of systems arranged on a lattice, we now ask: In which contexts can we study such local properties? Two such contexts are: (a) With respect to the *time evolution* of the quantum system, and (b) at *thermal equilibrium*. We now discuss these in further depth.

**Time evolution.** In this setting, we are interested in how local properties of the system behave as the system evolves in time. Here, recall that the time evolution of a quantum state at time *t*, denoted *ρ*(*t*), is given by the Schrödinger equation, which is a postulate of quantum mechanics:

$$\rho(t) = e^{-iHt}\rho(0)e^{iHt},$$

where *H* is a Hermitian operator known as the *Hamiltonian* of the system. In particular, in this setting, we imagine that the system *S* being studied is *isolated* from the outside world.

**Thermal Equilibrium.** In contrast to the setting of time evolution above, when studying local properties of our system *S* at *thermal equilibrium*, we imagine that *S* is allowed to *interact* with its environment for a "long time". Eventually, the system will reach a stationary state known as the *thermal state*, *ρ*eq, which no longer depends on time. Here, by "stationary state", we mean that the local properties of the system have ceased to fluctuate. The density matrix of our thermal state is known as the *Gibbs state*, which can be derived from the equal *a priori* probability postulate of statistical mechanics:

$$\rho_{\text{eq}} = \frac{e^{-\beta H}}{Z} \quad \text{for} \quad Z := \text{Tr}\left(e^{-\beta H}\right).$$
(5.1)

Here, *Z* is called the *partition function*, and the parameter *β* scales inversely with temperature *T*. Two remarks are in order. First, as stated earlier, *ρ*eq does not depend on time, *t*. Second, *ρ*eq is not *provably* a description of *S* at equilibrium; rather, it is an educated guess from statistical mechanics which works well for many systems in practice, *assuming* one is interested in local properties of *S*. For further reading on notions of equilibration, the reader is referred to (e.g.) [\[114\]](#page-121-8).

## <span id="page-38-0"></span>**5.3 Where do Hamiltonians come from?**

We have now stated that we are interested in studying local properties of Hamiltonians on the lattice, and that we can conduct such studies either with respect to time evolution or at thermal equilibrium. But we still have not answered a key question: Where does our Hamiltonian *come from* to begin with? There are two answers to this question: The easy answer is that Hamiltonians naturally arise from the Schrödinger equation. However, this is somewhat unsatisfying — it gives no intuition as to which classes of Hamiltonians describe physically relevant systems. Thus, the more interesting (and difficult) question is: How do we identify physically motivated classes of Hamiltonians?

To answer this, suppose for a moment that you are a physicist, and you are sitting in your lab observing your experimental apparatus induce some quantum evolution. How would you determine the Hamiltonian *H* governing this evolution? Does the Schrödinger equation give you an efficient approach for deducing *H*? No! In practice, one has no idea what *H* actually is. Thus, we must resort to the grade-school Scientific Method — make an educated guess *H*<sup>0</sup> (a Hamiltonian which might reproduce the local properties of our system), and then corroborate this guess via experiments. In particular, note that our aim is not to guess *H* itself, as this is often intractable due to the large number of degrees of freedom involved. Instead, we desire a *simplified* model *H*<sup>0</sup> which ignores certain degrees of freedom, but nevertheless captures local properties of interest. For example, one might choose to model only the spin of an electron accurately, and ignore the electron's other properties. For this reason, Hamiltonian models appearing in the condensed matter literature should not be thought of as "accurately characterizing a system", but rather as *phenomenological* objects which, up to minor corrections, appear to model certain local properties of the system well.

Summarizing, to determine the Hamiltonian *H* modeling our system, we (1) guess a candidate simplified Hamiltonian *H*<sup>0</sup> , (2) check what a theoretical (i.e. pen-and-paper) calculation on *H*<sup>0</sup> predicts about the behavior of the system, and (3) confirm this prediction via experimental tests. What kind of theoretical calculations might we consider in step (2) above? This is where key issues faced by physicists arise. For example, in step (2) we might wish to estimate a two-point correlation function of *H*<sup>0</sup> 's ground state. However, we immediately hit a brick wall, as the ability to estimate such functions in general implies the ability to estimate a Hamiltonian's ground state energy (which is QMA-hard)! So it seems we are in a bind; to better understand physical systems, we model them using Hamiltonians, but studying Hamiltonians themselves is not necessarily easy.

Indeed, this is precisely the focus of much of condensed matter physics. Here are two key questions faced by the community:

- Given a phenomenological Hamiltonian *H*<sup>0</sup> , how well does it actually model the desired properties of the underlying system *S*?
- How well does *H*<sup>0</sup> allow us to make predictions about future properties of *S* which we might be interested in?

In the next section, we discuss various approaches for answering questions related to these.

# <span id="page-39-0"></span>**5.4 The study of Hamiltonians: Techniques and tools**

In the previous section, we identified key questions faced by the physics community regarding the study of local Hamiltonians. In this section, we give a flavor of both classical and quantum techniques for circumventing the challenges arising in these scenarios. In particular, the basic goal here is: Given a phenomenological Hamiltonian *H*, calculate certain properties of *H*. We begin with classical simulations in [§5.4.1,](#page-39-1) and move to quantum simulations in [§5.4.2.](#page-43-0)

#### <span id="page-39-1"></span>**5.4.1 Classical simulations**

Given a Hamiltonian *H*, in this section, we use classical computers to study the following:

• Are there efficient *algorithms* for approximating local properties of *H*?

- Can objects of interest, such as the ground state of *H*, be represented by a space-efficient *data structure*? Do these structures allow us to perform useful computations?
- Finally, given such a space-efficient data structure, can it be used to make *predictions* about the system for future properties we might be interested in?

Two remarks are in order here. First, an *efficient* algorithm to a theoretical computer scientist typically means a rigorous algorithm which runs in polynomial time on a worst case instance. In contrast, to a physicist, an efficient algorithm often means a fast heuristic algorithm which works well in practice. Second, the third question on the ability to make predictions about a system is vital — it allows us to mathematically predict how the properties of a material will change or behave under certain conditions, which in turn allows us to design advanced materials with desirable properties.

**The variational principle.** To answer the questions above, a primary line of attack is via the heuristic of the *variational principle*. Specifically, suppose one is interested in optimizing a function *f*(*S*) over a set *S*. Then, the variational principle simply means carrying out the optimization over some restricted set *S* <sup>0</sup> ⊆ *S*, which we hope will allow an easier computation.

For example, suppose we wish to compute the ground state energy of Hamiltonian *H* acting on *n* qubits, i.e.

<span id="page-40-0"></span>
$$\min_{\rho \succeq 0, \text{Tr}(\rho) = 1} \text{Tr}(H\rho). \tag{5.2}$$

Since *ρ* can be highly entangled, it may require exponentially many bits to describe classically; this makes designing a heuristic algorithm for solving Equation [5.2](#page-40-0) difficult. Via the variational principle, however, one can instead optimize over a simpler set *S* <sup>0</sup> of quantum states in order to approximate the ground state energy. Which set of states *S* 0 should we choose? Below, we discuss three popular candidates. *Product states.* The most basic set *S* <sup>0</sup> one can choose is the set of all tensor product states *ρ* = *ρ*<sup>1</sup> ⊗ *ρ*<sup>2</sup> ⊗ · · · ⊗ *ρn*. Do not be fooled by the simplicity of this ansatz, however; it has proven quite effective in many scenarios, and there is an entire area of study devoted to it known as *mean field theory*. (See [§6.2](#page-58-0) for more on mean field theory.) In addition, working with product states is by no means easy — optimizing Equation [5.2](#page-40-0) over product states, for example, is NP-hard. (To see this, note that if *H* encodes a 3-SAT instance, then the ground state of *H* is without loss of generality a product state.)

*Gaussian states.* Another common choice of *S* 0 is the set of *Gaussian* states, i.e.

$$\rho = e^{-Q(a_1^{\dagger}, a_2^{\dagger}, \dots, a_1, a_2, \dots)},$$

where *Q* is some quadratic function, and the operators {*a* † *i* } and {*ai*} are known as *creation* and *annihilation* operators, respectively. (See [§5.4.2](#page-43-0) for more on creation and annihilation operators.) Local predictions on Gaussian states can be made efficiently, i.e. in time scaling polynomially with the system size. For further reading on Gaussian states, the reader might consider (e.g.) [\[163,](#page-125-5) [5\]](#page-113-4).

*Tensor network states.* The final choice of *S* <sup>0</sup> we discuss is the set of *tensor network states*. (See [§6.3](#page-62-0) for a definition of tensor networks.) Unlike product states, tensor network states can represent a variety of quantum states with exotic quantum correlations, such as (chiral [\[59,](#page-117-6) [162\]](#page-125-6)) topological states. However, as mentioned in [§4.2,](#page-31-0) this expressive power has a downside: Contracting tensor networks is #P-hard in general. To circumvent this, the strategy is to choose a clever subset of tensor network states *S* <sup>00</sup> which not only allows us to model the system we are interested in, but which also allows efficient calculation of local properties. Arguably the most successful application of this idea in conjunction with the variational principle has been White's DMRG algorithm [\[168,](#page-125-0) [169\]](#page-125-1) on MPS, which is discussed in further depth in [§6.4.](#page-65-0) Note, however, that DMRG is a heuristic; in contrast, rigorously finding a good MPS approximation to the ground state of a 1D (gapless) Hamiltonian is NP-hard [\[145\]](#page-123-6).

Let us delve further into tensor networks, as they have proven a particularly useful ansatz over the last two decades. In particular, a key question regarding them is:

*Which quantum systems have ground states which can be well-approximated by a tensor network of small bond dimension D?*

Here, the *bond dimension* is an important parameter characterizing "how much" entanglement the network can faithfully represent; the larger *D* is, the more quantum states we can represent, at the cost of requiring more storage space. (See [§6.3](#page-62-0) for further details.) Since we are restricted to polynomial-sized descriptions of states in practice, it is thus imperative to keep the bond dimension as small as possible (representing an arbitrary quantum state requires exponential *D*).

We now briefly overview recent progress regarding the question above. In 1D gapped systems, MPS with subpolynomial *D* approximate the ground state well [\[88,](#page-119-0) [19\]](#page-114-8), and moreover, there is a polynomialtime algorithm for finding a good MPS approximation to the ground state [\[110\]](#page-121-6). In 1D gapless (critical) systems, MPS with polynomial *D* approximate the ground state well if certain Rényi entropies diverge at most logarithmically [\[153\]](#page-124-10) (see also [\[149\]](#page-124-11)). On the other hand, at *finite* temperature *T >* 0 in any spatial dimension *d*, Hastings has shown [\[87\]](#page-119-7) that a tensor network with bond dimension *D* = exp(*O*(*β* log(*N/*) *d* )) approximates the Gibbs state of the system within trace distance , where *N* is the size of the lattice, and *β* := 1*/κBT* for temperature *T* and Boltzmann constant *κB*. If *H* is gapped and the density of low energy states grows polynomially in *N* for a fixed energy, then this result also implies a tensor network approximation of the *ground state* with *D* = exp(*O*(log*d*+1(*N/*))). Molnar *et al.* improved [\[120\]](#page-122-10) these results to *D* = (*N/*) *<sup>O</sup>*(*β*) and *D* = exp(*O*(log<sup>2</sup> (*N/*))) in the finite temperature and ground state cases, respectively. Intuitively, the "density of states" assumption here says that the low energy spectrum is "sparsely populated" by eigenvectors; this is, in fact, typical of quantum systems in nature.

For more information on the use of the variational principle in conjunction with tensor networks, the reader is referred to [\[154\]](#page-124-1). An introductory discussion on the variational principle aimed at physicists is given in Chapter 7 of Griffiths [\[80\]](#page-119-8).

#### <span id="page-43-0"></span>**5.4.2 Quantum simulations**

In [§5.4.1,](#page-39-1) we discussed the use of *classical* simulations to study phenomenological Hamiltonians *H*. One particularly difficult setting which, however, does not seem amenable to these techniques is that of *strongly correlated* materials. For example, high-temperature superconductors, despite having seen over two decades of research, remain arguably poorly understood. Recent research in *quantum* simulations has, however, led to exciting advances in this direction [\[134\]](#page-123-7). Key to this progress are two ingredients: One old, and one new. The "old" ingredient is the famous Hubbard model, formulated by John Hubbard in the 1960's. The "new" ingredient is Feynman's remarkable idea [\[66\]](#page-118-1) of building *quantum* devices to efficiently simulate quantum systems. In particular, the idea explored in this section is the use of quantum simulations to uncover properties of the Hubbard model. Further details on this topic can be found, for example, in the brief survey of Quintanilla and Hooley [\[134\]](#page-123-7).

Before we begin, let us stress that to study (say) the Hubbard model, one need not necessarily construct a *general-purpose* quantum computer; rather, a device tailored to simulating this one model would suffice. Thus, the goal of quantum simulations may be easier to achieve than a large scale quantum computer [\[52\]](#page-117-7). Indeed, this is the approach taken in this section.

In order to define the Hubbard model, we must first make a brief detour to introduce the notions of fermions and bosons, which are the types of particles on which the model acts.

**Detour: Indistinguishable particles.** Before defining fermions and bosons formally, let us set the stage with a high-level overview of indistinguishable particles. The Standard Model of particle physics, developed in the latter half of the 20th century, characterizes various types of interactions which occur in nature, such as the electromagnetic interaction. These interactions, in turn, govern the dynamics of subatomic particles such as photons, electrons, and protons. In particular, the model treats these particles as *indistinguishable*. In other words, if for example we are given a pair of photons at positions *X* and *Y* , then the physical state of the photons (described by the wave function, up to global phase) remains *invariant* if we swap the positions of the photons, i.e. the physical state only cares about the *number* of particles at each site. However, there is a twist: The wave function of some particles, such as electrons, obtains a global phase of −1 upon performing a swap. This may *a priori* appear irrelevant, as global phases cannot be physically observed. However, it is a remarkable conclusion of the Standard Model that this seemingly innocuous global phase turns out to dictate the very structure of matter around us.

To understand this phenomenon, the Standard Model differentiates between two types of particles: *Bosons* and *fermions*. Mathematically, these types are characterized by the Spin-Statistics theorem, which states that given a system of identical particles, one of the two cases must hold:

- If the particles have integer spin (i.e. *s* = 0*,* 1*,* 2*, . . .*), then exchanging any pair of them leaves the wave function invariant. Such particles are called *bosons*.
- If the particles have half-integer spin (i.e. *s* = 1*/*2*,* 3*/*2*,* 5*/*2*, . . .*), then exchanging any pair of them induces a global phase of −1 on the wave function. Such particles are called *fermions*.

Note that the latter statement above captures the curious phase of −1 discussed earlier, and is essentially the Pauli exclusion principle.

What does the Spin-Statistics theorem actually mean in terms of how large numbers of bosons or fermions behave? The distinction between bosons and fermions manifests itself at thermal equilibrium by leading to two possible statistical distributions governing how a system of indistinguishable and non-interacting particles populate a set of discrete energy states: Bose-Einstein statistics for bosons, and Fermi-Dirac statistics for fermions. (This also explains the name Spin-*Statistics* Theorem above.) We begin by discussing the former. Note that both statistics hold for sufficiently concentrated systems of particles at low temperature. At high temperature, the same statistics hold; however, these are now well-approximated by classical Maxwell-Boltzmann statistics.

*Bose-Einstein statistics.* Developed by Satyendra Nath Bose and Albert Einstein in the mid-1920's, Bose-Einstein statistics predicts that at low temperature, particles tend to aggregate in the same quantum state, namely the ground state. As a result, bosons typically play the role of "force carrier" particles in nature, i.e. they transmit interactions. A good example of this is a laser, which consists of many bosons in the same state. In addition, the tendency for a system of bosons to occupy the ground state at very low temperatures can lead to a special state of matter known as a *Bose-Einstein condensate*, which can exhibit quantum effects at the macroscopic scale. For example, when Helium-4, which is a gas of bosons, is cooled to temperatures near absolute zero, it becomes a *superfluid*, i.e. it behaves like a fluid with zero viscosity. \*Thus, the ability for many bosons to aggregate in the same mode is crucial to the role they play in nature. Examples of bosons include elementary particles, such as photons, gluons, and the Higgs boson, as well as composite particles, such as the Helium-4.

*Fermi-Dirac statistics.* Named after Enrico Fermi and Paul Dirac, Fermi-Dirac statistics applies to fermions, and in stark contrast to bosons, follows the principle that two fermions cannot occupy the same quantum state. For example, if two electrons (electrons are fermions with spin 1*/*2) are at the same site, then they must differ in at least one property, such as having anti-aligned spins. It is precisely for this reason that electrons arrange themselves in orbits with higher and higher energy about the nucleus of an atom, giving matter a "rigid" structure and non-trivial volume. In this sense one may intuitively think of fermions as the "building blocks of matter". Examples of fermions include elementary particles such as electrons, quarks, and leptons, and composite particles such as protons and neutrons. In fact, any composite particle composed of an odd number of fermions is also a fermion; for example, protons and neutrons consist of three quarks. Any composite particle composed of an even number of fermions, however, is a boson.

**Back to quantum simulation: The Hubbard model.** We now introduce the Hubbard model, which since its inception in 1963 [\[92\]](#page-120-8), has become a "standard model" in condensed matter physics. Hubbard's aim was to propose "the simplest possible model" which would explain the behavior of strongly correlated materials [\[134\]](#page-123-7). In particular, his model aims to describe the behavior of electrons in solids, and can capture the transition of a system between being a conductor and an insulator. It is thus of particular interest in the study of high-temperature superconductivity. Although the original model was proposed using fermions, a bosonic version is also known and referred to as the *Bose-Hubbard* model, which we also introduce here.

To help understand the technical definitions we give below, the intuition behind the Hubbard model is as follows. Previous to Hubbard's proposal, the *tight-binding* approximation from solid-state physics explained conduction by viewing electrons as "hopping" from the electron orbitals of one atom to another. However, when certain materials are heated, thus increasing the spacing between atoms, they can transition from being a conductor to an insulator; the tight-binding approximation fails to account for this. To resolve this, Hubbard introduced a second term to the tight-binding approximation's Hamiltonian which is meant to model the "on-site repulsion" resulting from the Coulomb repulsion between electrons.

For simplicity, we begin with the Bose-Hubbard model (i.e. bosons).

*The Bose-Hubbard model.* The Bose-Hubbard model involves interacting bosons, and its Hamiltonian on a 2D lattice is given by

$$H = -t \sum_{\langle n, m \rangle} a_n^{\dagger} a_m + u \sum_n a_n^{\dagger} a_n^{\dagger} a_n a_n.$$
 (5.3)

Here, h*n, m*i denotes that the summation is taken over nearest neighbors, *t* is the hopping amplitude, *u* is the interaction strength, and {*a* † *<sup>n</sup>*} and {*an*} are the bosonic creation and annihilation operators, respectively. Let us define the latter.

Let  $\{|k\rangle_n\}_{k=0}^{+\infty}$  be a complete set of local orthogonal basis vectors, where  $|k\rangle_n$  means that there are k (identical) bosons in location or mode n (the subscript is omitted if the location is unspecified). Then, the state  $|0\rangle$  has a special name: It is the vacuum state. The bosonic creation and annihilation operators are given by

$$a^{\dagger}|k\rangle = \sqrt{k+1}|k+1\rangle$$
 and  $a|k\rangle = \sqrt{k}|k-1\rangle$ ,

and they satisfy the canonical commutation relations

$$[a_m, a_n] = [a_m^{\dagger}, a_n^{\dagger}] = 0$$
 and  $[a_m, a_n^{\dagger}] = \delta_{mn}$ ,

where [x, y] = xy - yx, and  $\delta_{mn}$  is the Kronecker delta function ( $\delta_{mn} = 1$  if m = n and  $\delta_{mn} = 0$  otherwise). Thus, for example, the state of k (identical) bosons can be expressed as

$$|k\rangle = \frac{(a^{\dagger})^k}{\sqrt{k!}}|0\rangle.$$

The Hubbard model. In the Bose-Hubbard model, one could have arbitrarily many bosons in a single mode. Recall, however, that by the Pauli Exclusion Principle, any pair of fermions occupying the same site must differ in some property, e.g. their spin. The (fermionic) spin-1/2 Hubbard Hamiltonian is

$$H = -t \sum_{\substack{\langle n,m \rangle \\ \sigma \in \{\uparrow,\downarrow\}}} a_{n,\sigma}^{\dagger} a_{m,\sigma} + u \sum_{n} a_{n,\uparrow}^{\dagger} a_{n,\uparrow} a_{n,\downarrow}^{\dagger} a_{n,\downarrow}.$$
 (5.4)

In this case, the fermionic creation and annihilation operators are defined on basis  $\{|0\rangle,|1\rangle\}$  as

$$a^{\dagger}|0\rangle = |1\rangle, \quad a^{\dagger}|1\rangle = 0, \quad a|0\rangle = 0, \quad a|1\rangle = |0\rangle,$$

with the canonical anti-commutation relations

$$\{a_{m,\sigma}, a_{n,\sigma'}\} = \{a_{m,\sigma}^{\dagger}, a_{n,\sigma'}^{\dagger}\} = 0$$
 and  $\{a_{m,\sigma}, a_{n,\sigma'}^{\dagger}\} = \delta_{mn}\delta_{\sigma\sigma'}$ 

where  $\{x,y\} = xy + yx$ . For clarity, in matrix form, we have

$$a^{\dagger} = \left( \begin{array}{cc} 0 & 0 \\ 1 & 0 \end{array} \right), \qquad a = \left( \begin{array}{cc} 0 & 1 \\ 0 & 0 \end{array} \right).$$

Note that, as expected for fermions, *a* † is nilpotent, meaning (*a* † ) <sup>2</sup> = 0 — this implies precisely that a second fermion cannot be created in an occupied mode.

As an aside, for the computer science reader interested in the Bose-Hubbard and Hubbard models, suggested reading might include Schuch and Verstraete's [\[147\]](#page-124-0) QMA-hardness result for the Hubbard model, and Childs, Gosset, and Webb's QMA-hardness result for the Bose-Hubbard model [\[49\]](#page-116-5).

*Studying the Hubbard model.* Shortly after the Hubbard model was proposed, Lieb and Wu solved it exactly in 1D in 1968 [\[113\]](#page-121-9), obtaining its "phase diagram". A *phase diagram* is a diagram depicting the quantum phases (e.g. metal, insulator, etc. . . ) of a system as a function of tuning parameters. In the Hubbard model, the tuning parameters are the electron density and the repulsion strength. In particular, Lieb and Wu found that the system is a *Mott insulator* when there is one electron per site (i.e. at "half filling"), and that it becomes metallic when we add or remove a small number of electrons (i.e. slightly away from half filling). Such transitions between different phases of matter are called *(quantum) phase transitions*.

Beyond 1D, unfortunately, the Hubbard model has proven remarkably difficult to solve analytically. One approach to cracking the higher dimensional case over the last decade or so has involved *quantum* simulation via ultracold atoms [\[134\]](#page-123-7). The idea here is as follows: When ultracold atoms are trapped in crossed laser beams (i.e. in an optical lattice), then under certain circumstances, the behavior of the *atoms themselves* is described by the Hubbard model. Thus, to uncover properties of the Hubbard model, we can instead probe such atomic systems.

Of course, this approach also faces difficulties. For example, when we say "ultracold" atoms, we do mean *ultra*cold: Such systems behave quantumly only when cooled to near absolute zero (for example, a few billionths of a degree above absolute zero). Nevertheless, recent experiments have managed to resolve some of these issues [\[57,](#page-117-8) [97,](#page-120-9) [140\]](#page-123-8), obtaining a good simulation of the 3D Hubbard model. Such experiments have offered evidence of a similar metal-insulator phase transition, just as was discovered analytically for the 1D Hubbard model by Lieb and Wu [\[113\]](#page-121-9). This offers hope for a huge step forward, as obtaining the phase diagrams of the 2D and 3D Hubbard models has been an open question for decades, whose resolution may hopefully lead to further breakthroughs in our understanding of strongly correlated materials.

# <span id="page-50-0"></span>**Physics Concepts in Greater Depth**

In Chapter 5, we gave a high-level overview of certain central questions in condensed matter physics. We now discuss various concepts introduced therein in greater depth. We begin in §6.1 by providing a glossary of selected common terms which appear in the many-body physics literature. §6.2 discusses mean field theory. In §6.3, §6.4, §6.4.1, and §6.5, we review tensor networks and their special cases (e.g., MPS and MERA). §6.4.2 sketches the implementation of the DMRG as a variational algorithm over MPS. Lastly, §6.6 provides a brief survey on the subject of the area laws.

## <span id="page-50-1"></span>6.1 A glossary of physics terms

The following is a glossary of common terms in the physics literature.

#### Basic terminology.

• Singlet: A singlet is a quantum state with zero total spin. In a system of two qubits, it is given by the Bell state:

$$|\psi^{-}\rangle := \frac{1}{\sqrt{2}}(|01\rangle - |10\rangle) = \frac{1}{\sqrt{2}}(|\uparrow\downarrow\rangle - |\downarrow\uparrow\rangle).$$

Note that for two-qubit systems, the singlet projects onto the antisymmetric space, and *I* −|*ψ* <sup>−</sup>ih*ψ* <sup>−</sup>| projects onto the symmetric space.

- *Spin*: Spin is an "intrinsic" type of angular momentum carried by quantum particles. It can be measured along certain directions in real space. Let us fix a set of three orthogonal axes (our world has three spatial dimensions) with respect to which we wish to perform a measurement. This induces a set of observables {*Sx, Sy, Sz*}. The measurement outcomes (eigenvalues) of each observable *Sx, S<sup>y</sup>* or *S<sup>z</sup>* for a *spin-(k/2)* particle (*k* a positive integer) can be −*k/*2*,* −*k/*2+1*, . . . , k/*2. For example, a spin- (3*/*2) particle can yield ±1*/*2 and ±3*/*2 upon measurement. As such, a spin-(*k/*2) particle corresponds to a qudit with dimension *d* = *k* + 1.
- *Many-body system*: A many-body system consists of a large number of particles (usually arranged in a regular lattice). It is governed by a many-body Hamiltonian. The specification of a particular such Hamiltonian is analogous to choosing a family of constraints in a classical CSP. Indeed, one might view 3-SAT as a many-body system in which all constraints are 3-local Boolean formulae in Conjunctive Normal Form (CNF). Note that manybody systems can be either classical or quantum, such as the classical and quantum Ising models.
- *Interaction (hyper)graph*: The interaction (hyper)graph illustrates which sets of particles are constrained by a common local constraint in the Hamiltonian. For 2-local Hamiltonians, this is just an undirected graph in which (*i, j*) is an edge if and only if there exists a term *Hij* in the Hamiltonian acting jointly on particles *i* and *j*.
- *Solving a model*: The meaning of this phrase depends largely on context. Typically, we are given a classical description of a local Hamiltonian *H*, and we wish to find some property of the system governed by *H*. For example, we may wish to solve for the ground

state energy of *H*, or to determine whether *H* is gapped. *Solving the model* means calculating the value of whatever property of *H* we are interested in.

• *Two-point correlation function*: Two-point correlation functions are defined as

$$\langle O_m O'_n \rangle := \operatorname{Tr} \left[ \rho(O_m \otimes O'_n) \right]$$

for some local operators *Om, O*<sup>0</sup> *<sup>n</sup>* acting on sites *m, n*, respectively.

**Commonly studied models in condensed matter physics.** All models listed below are 2-local.

• *Classical Ising model*: We are given a lattice, and at each lattice site *i* there is a binary variable *x<sup>i</sup>* ∈ {+1*,* −1}. Let *x* := (*x*1*, x*2*, . . . , xn*) with *n* the total number of sites. An assignment *x* ∈ {+1*,* −1} *n* is called a *configuration*, and the *energy* of a configuration *x* is given by the Hamiltonian

<span id="page-52-0"></span>
$$H(\mathbf{x}) = \sum_{\langle i,j \rangle} J_{ij} x_i x_j, \tag{6.1}$$

where *Jij* 's are interaction strengths (real numbers), and h*i, j*i denotes summation over nearest-neighbor pairs (*i, j*) (according to whatever underlying lattice we are given, such as a 1D chain or a 2D square lattice). It is common to write *H* instead of *H*(*x*) for notational simplicity.

To illustrate the connection to computer science, note that setting all *Jij* = 1 and searching for the ground state configuration of the Hamiltonian *H*(*x*)−|*E*| is equivalent to the MAX CUT problem, where |*E*| is the number of edges in the interaction graph.

One may also consider adding a linear term to the Ising Hamiltonian, i.e.,

$$H(\boldsymbol{x}) = \sum_{\langle i,j \rangle} J_{ij} x_i x_j + \mu \sum_i m_i x_i,$$

where *m<sup>i</sup>* models the effect of an external magnetic field on site *i*, and *µ* is the magnetic moment. We usually set *µ* = 1 without loss of generality.

• *Quantum Ising model*: The quantum Ising model is also known as the transverse field Ising model [\[132,](#page-122-11) [137\]](#page-123-9). Its Hamiltonian is

$$H = -J \sum_{\langle i,j \rangle} \sigma_i^z \sigma_j^z - g \sum_i \sigma_i^x,$$

where *J* is the coupling constant, and *g* is the magnitude of the transverse magnetic field. Recall that *σ <sup>z</sup>* and *σ <sup>x</sup>* are the Pauli *Z* and *X* matrices, respectively. This model was recently found to characterize a new complexity class called TIM [\[54\]](#page-117-1).

• *Quantum Heisenberg model*: The quantum Heisenberg model's Hamiltonian is given by

$$H = -\sum_{\langle i,j\rangle} (J_x \sigma_i^x \sigma_j^x + J_y \sigma_i^y \sigma_j^y + J_z \sigma_i^z \sigma_j^z) + h \sum_i \sigma_i^z,$$

where *Jx, Jy, J<sup>z</sup>* are coupling constants, and *h* is the external magnetic field. Various special cases of this model are of particular interest, such as the *XX model* [\[112\]](#page-121-10) (also known as the XY model)

$$H = -\sum_{\langle i,j\rangle} \sigma_i^x \sigma_j^x + \sigma_i^y \sigma_j^y,$$

and the *XXZ model* [\[179,](#page-126-1) [180,](#page-126-2) [137\]](#page-123-9)

$$H = -\sum_{\langle i,j\rangle} \sigma_i^x \sigma_j^x + \sigma_i^y \sigma_j^y + \Delta \sigma_i^z \sigma_j^z.$$

• *Anti-ferromagnetic Heisenberg model*: This is another special case of the Heisenberg model. In physics notation the Hamiltonian can be written compactly as (see Equation [2.11](#page-14-0) for the definition of −→*S* )

$$H = \sum_{\langle i,j \rangle} \overrightarrow{S}_i \cdot \overrightarrow{S}_j = \sum_{\langle i,j \rangle} \sigma_i^x \sigma_j^x + \sigma_i^y \sigma_j^y + \sigma_i^z \sigma_j^z,$$

where we have assumed nearest neighbor interactions (of course, in principle the underlying interaction graph can be any simple graph). To intuitively understand what this 2-local constraint enforces for the spin-1*/*2 particle case, note that

$$I - (\sigma^x \sigma^x + \sigma^y \sigma^y + \sigma^z \sigma^z) \propto |\psi^-\rangle \langle \psi^-|,$$

where |*ψ* <sup>−</sup>i is the singlet. Hence, the ground state of this 2-local constraint is the 1-dimensional anti-symmetric subspace, in which spins are aligned in a conflicting fashion, i.e. up-down or down-up.

We now discuss the properties of the 1D spin-*S* antiferromagnetic Heisenberg chain. For *S* = 1*/*2, the model is exactly solvable by the Bethe ansatz [\[32\]](#page-115-9). The energy spectrum is gapless, and the spin correlation functions (e.g., h*σ z i σ z j* i) decay as a power law in |*i* − *j*|. For *S* = 1 (see Equation [2.8](#page-14-1) for the spin-1 definition of −→*<sup>S</sup>* ), the model is difficult to solve, and was historically expected to be gapless and exhibit power-law decay. Surprisingly, in 1983, Haldane [\[83,](#page-119-9) [84\]](#page-119-10) argued that whether *S* is a half-odd-integer or an integer is essential: For half-odd-integer *S* the model was predicted to be gapless and exhibit power-law decay, while for integer *S*, it was predicted to be gapped and exhibit exponential decay. The former, i.e., the absence of an energy gap for half-odd-integer *S*, was proven rigorously [\[8\]](#page-113-5) by using an extension of the Lieb-Shultz-Mattis theorem [\[112\]](#page-121-10). As for the latter, evidence for the existence of the "Haldane gap" for *S* = 1 has been found both numerically and experimentally [\[46,](#page-116-10) [121,](#page-122-12) [135\]](#page-123-10).

• *AKLT model*: As the 1D spin-1 Heisenberg model has proven difficult to solve, Affleck, Kennedy, Lieb, and Tasaki proposed and studied the similar AKLT model in 1987 [\[6,](#page-113-6) [7\]](#page-113-7). The AKLT model is artificial and not believed to be experimentally realizable. However, it has the following desirable properties: (i) It looks superficially similar to the spin-1 anti-ferromagnetic Heisenberg chain; (ii) it can be solved exactly; (iii) Haldane's argument (see *anti-ferromagnetic Heisenberg model*) can be rigorously verified for this model. The AKLT model is also useful for understanding MPS [\[131,](#page-122-7) [142\]](#page-123-11), symmetry protected topological (SPT) order [\[81,](#page-119-11) [133\]](#page-123-12), etc.

The 1D spin-1 AKLT Hamiltonian is defined as (see Equation [2.8](#page-14-1) for definitions of *σx*, *σy*, and *σ<sup>z</sup>* in the spin-1 case)

$$H = \sum_{i} \overrightarrow{S}_{i} \cdot \overrightarrow{S}_{i+1} + \frac{1}{3} \left( \overrightarrow{S}_{i} \cdot \overrightarrow{S}_{i+1} \right)^{2}.$$

This model is best understood via the correspondence between a qutrit (spin-1) and the symmetric subspace of two qubits (spin-1*/*2):

$$|+1\rangle \leftrightarrow |11\rangle, \qquad |0\rangle \leftrightarrow (|01\rangle + |10\rangle)/\sqrt{2}, \qquad |-1\rangle \leftrightarrow |00\rangle.$$

The ground state of the AKLT model can be constructed in three steps: (1) For each site *i*, assign two qubits labeled *i<sup>L</sup>* and *iR*; (2) *i<sup>R</sup>* and (*i* + 1)*<sup>L</sup>* form a singlet; (3) project *i<sup>L</sup>* and *i<sup>R</sup>* onto the symmetric subspace. The ground state is called a "valence-bond state" as it is a tensor product of singlets in the qubit representation. We emphasize that the second term in the AKLT Hamiltonian is intentionally added to ensure exact solvability, i.e., that step (2) is the optimal strategy to minimize energy. (Omitting this second term yields the anti-ferromagnetic Heisenberg chain.) Heuristically, ignoring step (3) does not prevent us from capturing the physics of the model. As such, it is straightforward to understand the following properties of the AKLT model intuitively (see [\[6,](#page-113-6) [7\]](#page-113-7) for rigorous proofs):

- 1. The model is gapped.
- 2. The ground state degeneracy depends on boundary conditions: The dimension of the ground state space is 1 for periodic boundary conditions, and 4 for open boundary conditions. This is because in the latter case we have two free qubits 1*<sup>L</sup>* and *n<sup>R</sup>* (*n* is the number of sites), while in the former case these two qubits form a singlet.
- 3. Correlation functions decay exponentially as the ground state is short ranged.
- 4. The ground state can be written exactly as an MPS of bond dimension 2 [\[131,](#page-122-7) [142\]](#page-123-11), as its Schmidt rank across any bipartite cut is 2.

#### **Physical phenomena.**

• *Ferromagnetic and anti-ferromagnetic order* : In a (spin) system with ferromagnetic order, all spins are aligned in the same direction, e.g., all spins up. In contrast, an anti-ferromagnetic system has alternating up and down spins (i.e., neighboring spins point in opposite directions). Note that for this to make sense, the underlying lattice must be bipartite. (We remark that not all 2D lattices are bipartite, such as the triangular or Kagome lattices.) For example, at zero temperature *H* = − P *i σ z i σ z <sup>i</sup>*+1 has ferromagnetic order (its ground states are the all-spin-up and the allspin-down states), whereas −*H* has anti-ferromagnetic order. To give an intuitive example, a permanent magnet in ordinary life exhibits ferromagnetic order with macroscopic magnetization.

• *Thermal equilibrium, Boltzmann distribution & Gibbs state*: When a classical system is in *thermal equilibrium*, the probability of observing each configuration *x* of the system is proportional to exp (−*βH*(*x*)), where *H* is the Hamiltonian (energy), and *β* = 1*/T* is the inverse temperature[1](#page-56-0) . This distribution of configurations is called the *Boltzmann distribution* or the canonical ensemble. The *partition function Z* is just the normalizing constant of the distribution:

$$Z(\beta) := \sum_{\boldsymbol{x}} \exp(-\beta H(\boldsymbol{x})). \tag{6.2}$$

The *free energy* is defined as

$$F(\beta) := -\log Z(\beta). \tag{6.3}$$

Let *O*(*x*) be a physical quantity as a function of *x*. Its expectation is given by

$$\langle O \rangle = \frac{1}{Z(\beta)} \sum_{x} O(x) \exp(-\beta H(x)).$$
 (6.4)

<span id="page-56-0"></span><sup>1</sup> In real physical systems (e.g., gases made of atoms and/or molecules), we usually work with the International System of Units (SI). The inverse temperature is given by *β* = 1*/*(*kBT*) in SI, where the unit for temperature *T* is Kelvin and *k<sup>B</sup>* ≈ 1*.*38 × 10<sup>−</sup><sup>23</sup>*J/K* is the Boltzmann constant. In the main text, we follow the convention of theoretical physicists and have rescaled the units such that all quantities are dimensionless (numbers) and in particular *k<sup>B</sup>* = 1. Thus, note that it does not make sense to define "room temperature" as having any particular value (such as, say, *T* = 20).

When a quantum system is in *thermal equilibrium*, the system is in a mixed quantum state described by the density matrix

$$\rho \propto \exp(-\beta H) = \exp(-H/T) \tag{6.5}$$

for H the Hamiltonian and  $\beta$  the inverse temperature. This state is known as the Gibbs or thermal state. The quantum partition function and free energy can be defined analogously to the classical setting:

$$Z(\beta) := \operatorname{tr} \exp(-\beta H). \tag{6.6}$$

Similarly, the expectation of an operator  $\hat{O}$  is given by

$$\langle \hat{O} \rangle = \operatorname{tr} \left( \hat{O} \exp(-\beta H) \right) / Z(\beta).$$
 (6.7)

Note that "zero temperature" should be understood as taking the limit  $\beta \to +\infty$ .

• Quantum phase transitions and criticality: Given a family of Hamiltonians  $H(\lambda)$  as a smooth (i.e. infinitely differentiable) function of some tuning parameter  $\lambda$ , let  $|\psi(\lambda)\rangle$  be the ground state of  $H(\lambda)$ . Note that  $|\psi(\lambda)\rangle$  may not be smooth (or continuous) in  $\lambda$  (even if  $H(\lambda)$  is finite dimensional); at such singularities, a quantum phase transition occurs. More specifically, at a first-order quantum phase transition  $|\psi(\lambda)\rangle$  is not continuous in  $\lambda$ , whereas at a continuous (second-order) phase transition,  $|\psi(\lambda)\rangle$  is continuous but not smooth in  $\lambda$ , e.g.,  $d|\psi(\lambda)\rangle/d\lambda$  may not be continuous at  $\lambda = \lambda_c$ . We call  $\lambda = \lambda_c$  a critical point and  $H(\lambda_c)$  a critical system; moreover, the physics in the neighborhood of a critical point is called critical phenomena. Heuristically, a critical system may be scale-invariant so that its low-energy effective theory is a conformal field theory.

A prototypical example of continuous quantum phase transitions is in the context of the transverse field Ising chain

$$H = -\sum_{i} \sigma_{i}^{z} \sigma_{i+1}^{z} + \lambda \sigma_{i}^{x},$$

where we take the *thermodynamic limit* in the sense that the number of spins goes to infinity (i.e., the index i ranges over

all integers). For *λ* → +∞, the ground state is | →→→ · · ·i (unique), where | →i is the ground state of −*σ x* . For *λ* = 0, the ground states are the all-spin-up and the all-spin-down states (2 fold degenerate). Indeed, the dimension of the ground state space is one for *λ >* 1 and two for *λ <* 1, and a second-order phase transition occurs at *λ<sup>c</sup>* = 1.

## <span id="page-58-0"></span>**6.2 Mean-field theory**

In [§5.4.1,](#page-39-1) we alluded to *mean-field theory* as a (heuristic) variational method over the set of product states to qualitatively extract properties of a many-body system. In this section, we develop mean-field theory from a "mean-field" perspective via a textbook example, and briefly comment on its reformulation as a variational method.

A many-body Hamiltonian *H* is in general difficult to solve due to coupling between particles. To circumvent this, mean-field theory constructs a decoupled and exactly solvable Hamiltonian *Hmf* . This process requires good physical intuition and insight into our system of interest, and there is *a priori* no guarantee as to how well *Hmf* approximates *H*. Nevertheless, mean-field theory has proven very successful in some physically important contexts, and thus is among the most widely used approximation methods in condensed matter physics.

The example we study here is the classical Ising model

$$H(\boldsymbol{x}) = -J \sum_{\langle i,j \rangle} x_i x_j$$

on a *D*-dimensional hypercubic lattice (see Equation [6.1\)](#page-52-0) at thermal equilibrium, i.e. we study the system's Boltzmann distribution (see the glossary entry for thermal equilibrium in [§6.1\)](#page-50-1)), and the tuning parameter for us is the temperature *T*. Let us now describe the property of *H* we wish to calculate in terms of *T*. Note that mapping *x<sup>i</sup>* → −*x<sup>i</sup>* for all *i* leaves the Hamiltonian invariant, i.e. the mapping is a symmetry of the Hamiltonian. However, the ground states (i.e. the all-spin-up and the all-spin-down states) do not respect this symmetry, as they are not left invariant under the action of this mapping (i.e. all-spin-up is mapped to all-spin-down and vice versa). This is called *spontaneous symmetry* *breaking*, a phenomenon in which the physical states are less symmetric than the Hamiltonian itself. Note that spontaneous symmetry breaking implies a degenerate ground space.

We can try to break this degeneracy by introducing a symmetry breaking perturbation, e.g., an infinitesimal strength magnetic field in the positive direction. (We use infinitesimal strength here as we do not wish to change our system.) This is modeled via a linear term as follows:

<span id="page-59-0"></span>
$$H(\mathbf{x}) = -J \sum_{\langle i,j \rangle} x_i x_j - h \sum_i x_i$$
 (6.8)

with *h* → 0 <sup>+</sup>. Then, we claim that h*xi*i = 1 for all *i* at zero temperature *T* = 0 and h*xi*i = 0 at *T* = +∞. To see this, first recall that at thermal equilibrium, the probability of observing each configuration *x* of the system is proportional to exp (−*H*(*x*)*/T*). Then, for *T* → 0, our system is in the all-spin-up state, since the magnetic field we added gives this configuration slightly less energy than the all-spin-down state; thus, h*xi*i = 1. For *T* → +∞, on the other hand, all configurations *x* are equally likely; thus, h*xi*i = 0. In physics terminology, when h*xi*i is nonvanishing, we say we have *spontaneous magnetization*. Thus, in our case we have spontaneous magnetization at *T* = 0, and there must exist a critical temperature *T<sup>c</sup>* between *T* = 0 and *T* = +∞ at which point the spontaneous magnetization vanishes. Indeed, the system undergoes a phase transition at *T<sup>c</sup>* in the sense that other physical quantities also become singular, e.g., the specific heat and the correlation length diverge. Hence, in "solving this model", our goal is to estimate the critical temperature *Tc*.

Before doing so, let us briefly review known exact results regarding this model. For *D* = 1, the model is easily solved by dynamic programming (known as the *transfer-matrix method* in physics), and *T<sup>c</sup>* = 0. For *D* = 2, the model was first solved by Onsager [\[128\]](#page-122-13), and *<sup>T</sup><sup>c</sup>* = 2*J/* ln(1 + <sup>√</sup> 2) ≈ 2*.*27*J*. Onsager's method is notorious for being mathematically involved; however, it can be reformulated and simplified by fermionization [\[150\]](#page-124-12). For *D* ≥ 3, no exact solution is known.

Returning to mean-field theory, we now define our decoupled mean field Hamiltonian *Hmf* . For this, consider an unknown parameter (to be determined later) *m* = h*xi*i for all *i*, which is physically motivated since the magnetization is expected to be uniform. Then, by substituting the straightforward identity

$$x_i x_j = x_i \langle x_j \rangle + \langle x_i \rangle x_j - \langle x_i \rangle \langle x_j \rangle + (x_i - \langle x_i \rangle)(x_j - \langle x_j \rangle),$$

into Equation [6.8,](#page-59-0) we can write

<span id="page-60-0"></span>
$$H_{mf}(m, \mathbf{x}) = -J \sum_{\langle i, j \rangle} (x_i \langle x_j \rangle + \langle x_i \rangle x_j - \langle x_i \rangle \langle x_j \rangle +$$

$$(x_i - \langle x_i \rangle)(x_j - \langle x_j \rangle)) - h \sum_i x_i$$

$$\approx -J \sum_{\langle i, j \rangle} \langle x_i \rangle x_j + x_i \langle x_j \rangle - \langle x_i \rangle \langle x_j \rangle$$

$$= DJm^2 - 2DJm \sum_i x_i, \qquad (6.9)$$

where in the second step, we drop the linear magnetization term since *h* → 0 <sup>+</sup> and we use the approximation *x<sup>i</sup>* ≈ h*xi*i for all *i*. *Hmf* (*m*) is now decoupled (non-interacting) and can be easily solved. Let h*xi*i*mf* denote the expectation of *x<sup>i</sup>* evaluated using the Boltzmann distribution of the mean-field Hamiltonian *Hmf* at temperature *T* (we omit parameters *m* and *T* in the notation h*xi*i*mf* for simplicity), i.e. h*xi*i*mf* is the mean-field magnetization. Then:

$$\langle x_i \rangle_{mf} = \frac{\sum_{x} x_i \exp(-\beta H_{mf}(x))}{\sum_{x} \exp(-\beta H_{mf}(x))}$$
$$= \frac{\sum_{x_i = \pm 1} x_i \exp(2\beta DJmx_i)}{\sum_{x_i = \pm 1} \exp(2\beta DJmx_i)}$$
$$= \tanh(2\beta DJm),$$

where the second equality follows by Equation [6.9,](#page-60-0) and where *Hmf* (*x*) also implicitly takes parameter *m*). The mean-field free energy is:

$$F_{mf} = -\ln Z_{mf}$$

$$= -\ln \left( \sum_{\boldsymbol{x}} \exp(-\beta H_{mf}(\boldsymbol{x})) \right)$$

$$= n\beta DJm^2 - n\ln(2\cosh(2\beta DJm)),$$

where *Zmf* is the mean-field partition function, and *n* is the total number of spins. The self-consistency *m* = h*xi*i*mf* of mean-field theory implies the mean-field equation

<span id="page-61-0"></span>
$$m = \tanh(2\beta DJm). \tag{6.10}$$

This equation has only one solution *m* = 0 when 2*βDJ* ≤ 1 and has three solutions *m* = 0*,* ±*m*<sup>0</sup> when 2*βDJ >* 1. In the latter case, one easily verifies *Fmf* (±*m*0) *< Fmf* (0). Since in classical statistical mechanics the physical solution is the one with the lowest free energy, mean-field theory predicts spontaneous magnetization when 2*βDJ >* 1, i.e., *T<sup>c</sup>* = 2*DJ*. In comparison, recall Onsager's result [\[128\]](#page-122-13) for *D* = 2 of *T<sup>c</sup>* ≈ 2*.*27*J*. The mean-field result thus yields a reasonably good approximation for *D* = 2.

As an aside, note that instead of a mean-field approach, one can carry out a renormalization group (RG) analysis [\[171,](#page-125-7) [172,](#page-125-8) [175,](#page-125-9) [173\]](#page-125-10), which is much more sophisticated. For *D* ≤ 3, RG outperforms meanfield theory. For *D* ≥ 4, however, both methods agree with each other (on critical exponents).

We now briefly comment on how to reformulate the technique used here as a variational method. Instead of imposing the self-consistency condition by hand, we can view *Hmf* (*m*) as a family of variational Hamiltonians and do not interpret *m* as h*xi*i. To obtain the most "physical" variational Hamiltonian, we minimize the mean field free energy *Fmf* (*m*) with respect to *m* and find that d*Fmf* (*m*)*/*d*m* = 0 is equivalent to the mean-field equation [\(6.10\)](#page-61-0). This is not a surprise, but rather a general feature of mean-field theory as a consequence of the Hellmann-Feynman theorem [\[65\]](#page-118-10).

Finally, a remark about classical versus quantum phase transitions. In this section, we studied a classical phase transition at finite temperature. Mean-field theory also applies to quantum phase transitions at zero temperature. Briefly speaking, we construct a family of variational (mean-field) Hamiltonians and minimize the mean-field ground state energy. Note that unlike in the finite temperature case discussed above, here we are at zero temperature; thus, our physical state is the ground state and we minimize the ground state energy as opposed to the free energy. (Roughly, free energy takes into account both energy and thermal (entropic) effects at finite temperature.) The ground states of the mean-field Hamiltonians are product states since the mean-field Hamiltonians are decoupled. This roughly explains folklore intuition as to why the variational method over product states is called mean-field theory. We point motivated readers to standard physics textbooks (e.g., [\[137\]](#page-123-9)) for more examples of mean-field theory.

## <span id="page-62-0"></span>**6.3 Tensor networks**

Tensor networks were first discussed in [§5.4.1.](#page-39-1) Due to their success and popularity in the field, we now give an introduction geared towards computer scientists. Specifically, since arbitrary quantum states |*ψ*i ∈ (C 2 ) <sup>⊗</sup>*<sup>n</sup>* may require exponentially many bits to represent classically, physicists have derived clever ways of encoding certain classes of entangled quantum states in succinct forms. One such approach is via *tensor networks*. Such networks include as special cases Matrix Product States (MPS) [\[64,](#page-118-11) [157,](#page-124-3) [131\]](#page-122-7) and Projected Entangled Pair States (PEPS)[\[152,](#page-124-5) [156\]](#page-124-6).

Informally, to a computer programmer, a *tensor M*(*i*1*, i*2*, . . . , ik*) is simply a *k*-dimensional array; one plugs in *k* indices, and out pops a complex number. Hence, in terms of linear algebra, a 1-dimensional tensor is a vector, and a 2-dimensional tensor is a matrix. Physicists often like to make this more confusing than it is by simplifying the notation and placing indices as super- or sub-scripts — for example, they might denote a 3D array *M*(*i*1*, i*2*, i*3) by *M i*1*,i*<sup>2</sup> *i*3 . (There is, of course, a physically motivated reason to write the indices as super- or sub-scripts; however, for those seeing tensor networks for the first time, it is likely simpler to avoid this notation for now.) To make it easier to work with tensors, there is a simple but extremely useful graphical representation. Figure [6.1\(](#page-63-0)a) shows *M*, for example. Here, the vertex corresponds to the tensor *M*. Each edge corresponds to one of the input parameters to *M*.

Continuing our informal discussion, in Figure [6.1\(](#page-63-0)b), an edge with two vertices as endpoints corresponds to the operation of *contracting* tensors on edges. Specifically, Figure [6.1\(](#page-63-0)b) takes two 3D tensors *M*

61

<span id="page-63-0"></span>![](_page_63_Picture_2.jpeg)

**Figure 6.1:** (a) A single tensor  $M(i_1, i_2, i_3)$ . (b) Two tensors  $M(i_1, i_2, i_3)$  and  $N(j_1, j_2, j_3)$  contracted on the edge (M, N).

and N, and contracts them on their  $i_2$  and  $j_2$  inputs, respectively. The resulting mathematical object is a 4-dimensional tensor P defined as

$$P(i_1, i_3, j_1, j_3) = \sum_{k} M(i_1, k, i_3) N(j_1, k, j_3).$$

Note the resulting tensor in Figure 6.1(b) has four "legs" (i.e. edges with only one endpoint); this is because P takes in four inputs.

More formally, a k-dimensional tensor M (as defined above) is a map  $M:[d_1]\times\cdots\times[d_k]\mapsto\mathbb{C}$ , where each  $d_i$  is a natural number. (We remark that sometimes the dimension k of a tensor is referred to as its rank. Note that this notion of "rank" is not the same as the usual linear algebraic notion of rank for matrices.) For this reason, we can observe the following straightforward way to connect n-qubit states  $|\psi\rangle$  and n-tensors. Let  $|\psi\rangle = \sum_{i=1}^{2^n} \alpha_i |i\rangle$  for  $\{|i\rangle\}_{i=1}^{2^n} \subseteq (\mathbb{C}^2)^{\otimes n}$  the computational basis. Then, for any  $i \in [2^n]$ , letting  $i_1 \cdots i_n$  denote the binary expansion of i, we can define an n-tensor  $M(i_1,\ldots,i_n)$  for  $i_k \in \{0,1\}$  which simply stores all  $2^n$  amplitudes of  $|\psi\rangle$ , i.e.  $M(i_1,\ldots,i_n) := \alpha_{i_1\ldots i_n}$ . In other words, we can write

<span id="page-63-1"></span>
$$|\psi\rangle = \sum_{i=1}^{2^n} M(i_1, \dots, i_n)|i\rangle. \tag{6.11}$$

More generally, one can generalize this correspondence to represent n-qudit systems with local dimension d. Then, each index to M would take a value in [d], and d is called the *bond dimension*.

<span id="page-63-2"></span>**Question 1.** In Figure 6.2, we depict five different tensor networks. For simplicity, we assume here that all input parameters to a tensor are from the set [d].

- 1. For (a), what type of linear algebraic object does the figure correspond to?
- 2. Which operations on objects of the type in (a) do images (b) and (c) depict? What is the output of the tensors in (b) and (c)?
- 3. How many tensors is the network in (d) composed of? How many input parameters does each of these constituent tensor networks have (before contraction)? How many input parameters does the final, contracted tensor network have?
- 4. Image (d) corresponds to an *m*-dimensional tensor, which using the tensor-vector correspondence in Equation [6.11,](#page-63-1) can be thought of as representing an *m*-qubit vector |*ψ*i (whose amplitudes are computed using the specific contractions between tensors indicated by the network). With this picture in mind, what does (*e*) correspond to?
- 5. Image (e) combines 2*m* tensors into a network which takes no inputs and outputs a complex number *α*. Assuming the bond dimension *d* is a constant, given these 2*m* tensors, how can we compute *α* in time polynomial in *m*? Hint: Consider an iterative algorithm which in step *i* ∈ [*m*] considers all tensors up to *N<sup>i</sup>* and *M<sup>i</sup>* .

There is another view of tensors which also proves useful, in which a tensor is seen as a linear map. Let *S* denote the set of legs of a tensor *M*, and partition *S* into subsets *S*<sup>1</sup> and *S*2. Then, by fixing inputs to all legs in *S*1, we "collapse" *M* into a new tensor *M*<sup>0</sup> corresponding to some vector in (C *d* ) ⊗|*S*2| . For example, consider again our tensor *M* in Figure [6.1\(](#page-63-0)a), and let *S*<sup>1</sup> = {*i*1} and *S*<sup>2</sup> = {*i*2*, i*3}. Then, denote by *M<sup>k</sup>* the tensor obtained by hardcoding *i*<sup>1</sup> = *k*, i.e. *Mk*(*i*2*, i*3) := *M*(*k, i*2*, i*3). By Equation [6.11,](#page-63-1) *M<sup>k</sup>* corresponds to some vector |*ψk*i ∈ (C *d* ) ⊗|*S*2| . In other words, we have just demonstrated a mapping which, given any computational basis state |*k*i ∈ C *d* , outputs a vector |*ψk*i ∈ (C *d* ) ⊗2 , i.e. we have a linear map Φ : C *d* 7→ (C *d* ) ⊗2 . Returning to our more

<span id="page-65-1"></span>![](_page_65_Figure_2.jpeg)

**Figure 6.2:** Five tensor networks, studied in Question [1.](#page-63-2)

general example with *M*, *S*, *S*<sup>1</sup> and *S*2, this approach allows us to view a tensor *M* with legs in *S* as a linear map *M* : (C *d* ) ⊗|*S*1| 7→ (C *d* ) ⊗|*S*2| .

To demonstrate the effectiveness of this linear map view of tensors, we revisit Question [1\(](#page-63-2)5). This time, we break up this tensor into tensors *T<sup>i</sup>* , as depicted in Figure [6.3.](#page-66-0) Then, we can think of *T*<sup>1</sup> as representing the conjugate transpose of a vector |*ψ*i ∈ (C *d* ) ⊗2 . Next, *T<sup>i</sup>* for *i* ∈ {2*, . . . , m* − 1} can be thought of as linear maps from (C *d* ) ⊗2 to (C *d* ) ⊗2 , where the two left legs are the inputs, and the two right legs are outputs. It follows that after contracting *T*<sup>1</sup> through *Tm*−1, the result is the conjugate transpose of some vector |*ψ*i ∈ (C *d* ) ⊗2 . Since the last tensor *T<sup>m</sup>* represents some |*φ*i ∈ (C *d* ) ⊗2 , performing the final contraction computes the inner product h*ψ*|*φ*i outputting a scalar, as claimed in Question [1\(](#page-63-2)5). Note that since the bond dimension *d* is considered a constant, this linear map view implies that the contraction of the entire network can clearly be performed in time polynomial in *m*.

## <span id="page-65-0"></span>**6.4 Density Matrix Renormalization Group**

In [§5.4.1,](#page-39-1) we discussed the variational principle, and in [§6.3,](#page-62-0) we introduced tensor networks. We now combine the two to discuss the Density

<span id="page-66-0"></span>![](_page_66_Picture_2.jpeg)

**Figure 6.3:** Demonstrating the linear map view of tensor networks.

Matrix Renormalization Group (DMRG) algorithm, which is nowadays generally considered the most powerful numerical method for studying one-dimensional quantum many-body systems. In many applications of DMRG, we are able to obtain the low-energy physics (i.e. physical properties at low energy, such as the ground state energy, ground state correlation functions, etc. . . ) of a 1D quantum lattice model with extraordinary precision and moderate computational resources. Historically, White's invention of DMRG [\[168,](#page-125-0) [169\]](#page-125-1) in the early 1990's was stimulated by the failure of Wilson's numerical renormalization group [\[174\]](#page-125-11) for homogeneous systems. A subsequent milestone was achieved when it was realized [\[130,](#page-122-5) [136,](#page-123-5) [155,](#page-124-2) [154,](#page-124-1) [167\]](#page-125-4) that DMRG is in fact a variational algorithm over a specific class of tensor networks known as Matrix Product States (MPS) (see [§6.4.1](#page-67-0) below for a definition of MPS).

The purpose of this section is to outline at a high level how DMRG works from the MPS point of view. For further details, we refer the reader to the following review papers on the topic. Schollwöck [\[142\]](#page-123-11) is a very detailed account of coding with MPS. The earlier paper of Schollwöck [\[141\]](#page-123-13) discusses DMRG mostly in its original formulation without explicit mention of MPS. Finally, Verstraete, Murg and Cirac [\[154\]](#page-124-1) and Cirac and Verstraete [\[51\]](#page-117-9) focus on the role MPS plays in DMRG, as well as other variational classes of states, such as Tree Tensor States, Multiscale Entanglement Renormalization Ansatz (MERA) and Projected Entangled Pair States (PEPS).

#### <span id="page-67-0"></span>6.4.1 Matrix Product States

Matrix Product States (MPS) are the simplest class of tensor network states, and as such, have received much attention. Consider a 1D quantum spin system of local dimension d. We associate each site i with d matrices  $A_i^{j=1,2,\dots,d}$  of dimension  $D\times D$ , except at the boundaries, where  $A_1^{j=1,2,\dots,d}$  is of dimension  $1\times D$  and  $A_n^{j=1,2,\dots,d}$  is of dimension  $D\times 1$  (where n is the total number of sites). Then an MPS is given by

$$|\psi\rangle = \sum_{j_1,\dots,j_n=1}^d A_1^{j_1} A_2^{j_2} \dots A_n^{j_n} |j_1,\dots,j_n\rangle.$$

How can one interpret this expression for  $|\psi\rangle$ ? First, note that for any  $i \in \{2, \ldots, n-1\}$ , we have  $A_i^{j_i} : [d] \mapsto \mathcal{L}\left(\mathbb{C}^D\right)$ . In other words, fixing an index  $j_i \in [d]$  pops out a  $D \times D$  complex matrix  $A_i^{j_i}$ . Similarly,  $A_n^{j_n} \ (A_1^{j_1})$  outputs a complex vector (conjugate transpose of a complex vector). It follows that for any string  $j_1 \cdots j_n \in [d]^n$ , the expression  $A_1^{j_1} A_2^{j_2} \ldots A_n^{j_n}$  yields a complex number (since it is of the form  $\langle v_1 | V_2 \cdots V_{n-1} | v_n \rangle$ ), i.e. it yields the amplitude corresponding to j. Thus, the amplitudes are encoded as products of matrices, justifying the name  $Matrix\ Product\ State$ . Some additional terminology: The indices  $j_i$  are referred to as physical indices, as their dimension d is fixed by the physical system. The value D is called the bond dimension, which we discuss in more depth shortly. Graphically, an MPS is given by Figure 6.2(d), where the vertical lines denote physical indices, and the horizontal lines represent tensor contractions or matrix products.

With a bit of thought, one can see that any state  $|\psi\rangle \in (\mathbb{C}^d)^{\otimes n}$  can be written as an MPS exactly if the bond dimension D is chosen large enough. Indeed, this can be achieved by setting D to be at least the maximum Schmidt rank of  $|\psi\rangle$  across any bipartite cut. In general, however, such a value of D unfortunately grows exponentially with n, and thus large values of D are not computationally feasible. The strength of MPS is hence as follows: Any n-particle quantum states whose entanglement across bipartite cuts is "small" (i.e. of polynomial Schmidt rank in n) can be represented succinctly by an MPS.

Moreover, this niche filled by MPS turns out to be quite interesting, as condensed matter physicists are mainly interested in ground states which are highly *non*-generic. For example, recall that in 1D gapped systems, we have an area law [\[88,](#page-119-0) [61,](#page-117-10) [35,](#page-115-10) [19,](#page-114-8) [91\]](#page-120-7), implying that in the 1D setting the entanglement entropy across any bipartite cut is bounded by a constant independent of *n*. In particular, Reference [\[19\]](#page-114-8) shows that ground states of 1D gapped systems with energy gap can be well approximated by an MPS with sublinear bond dimension *D* = exp *O*˜ log3*/*<sup>4</sup> *n* 1*/*4 . In conformally invariant critical (gapless) systems, the area law is slightly violated with a logarithmic factor ∼ log *n* [\[47,](#page-116-11) [48\]](#page-116-12), suggesting that MPS is still a fairly efficient parametrization.

Finally, a key property of MPS is that, given an MPS description of a quantum state, we can *efficiently* compute its physical properties, such as energy, expectation of order parameters, correlation functions, and entanglement entropy [\[142\]](#page-123-11). This is in sharp contrast to more complicated tensor networks such as Projected Entangled Pair States (PEPS), which are known to be #P-complete to contract [\[148\]](#page-124-9).

#### <span id="page-68-0"></span>**6.4.2 Implementation of DMRG**

Having introduced MPS, we now briefly review the idea behind DMRG from an MPS perspective. Specifically, given an input Hamiltonian *H*, we compute the MPS of some bond dimension *D* that best approximates the ground state by minimizing the energy h*ψ*|*H*|*ψ*i with respect to all such MPS |*ψ*i, i.e., with respect to *O*(*ndD*<sup>2</sup> ) parameters. Note that in general the bond dimension *D* must to grow with the system size *n* (especially in critical/gapless systems). Unfortunately, if *D* = poly(*n*) the aforementioned minimization problem can be NPhard even for frustration-free Hamiltonians [\[145\]](#page-123-6). To cope with this, DMRG is thus a *heuristic* algorithm for finding local minima: There is no guarantee that the local minima we find are global minima, nor that the algorithm converges rapidly. However, perhaps surprisingly, in practice DMRG works fairly well even in critical/gapless systems.

At a high level, the DMRG algorithm proceeds as follows. We start with an MPS denoted by {*A j*=1*,*2*,...,d <sup>i</sup>*=1*,*2*,...,n*}, and subsequently perform a sequence of local optimizations. A local optimization at site *i*<sup>0</sup> means minimizing h*ψ*|*H*|*ψ*i with respect to *A j*=1*,*2*,...,d i*0 , while keeping all other matrices *A j*=1*,*2*,...,d i*6=*i*<sup>0</sup> fixed. Such local optimizations are performed in a number of "sweeps" until our solution {*A j*=1*,*2*,...,d <sup>i</sup>*=1*,*2*,...,n*} converges. Here, a *sweep* consists of applying local optimizations in sequence starting at site 1 up to site *n*, and then backwards back to site 1. In other words, we apply the optimization locally in the following order of sites: 1*,* 2*, . . . , n* − 1*, n, n* − 1*, . . . ,* 2*,* 1.

## <span id="page-69-0"></span>**6.5 Multi-Scale Entanglement Renormalization Ansatz**

We now discuss a specific type of tensor network known as the Multi-Scale Entanglement Renormalization Ansatz (MERA) [\[159,](#page-124-7) [160\]](#page-124-8) (see [§6.3](#page-62-0) for a definition of tensor networks), which falls somewhere between MPS and PEPS. Like MPS and unlike PEPS, the expectation value of local observables for MERA states can be computed exactly efficiently. Like PEPS and unlike MPS, MERA can be used to well-approximate (certain) states in *D*-dimensional lattices for *D* ≥ 1. It should be noted that, as with MPS and PEPS, there is not necessarily any guarantee as to how well MERA can approximate a particular state; rather, as with many ideas in physics, MERA is an intuitive idea which appears to work well for certain Hamiltonian models, such as the 1D quantum Ising model with transverse magnetic field on an infinite lattice [\[159\]](#page-124-7).

There are two equivalent ways to think about MERA. The first is to give an efficient (log-depth) quantum circuit which, given a MERA description of a state |*ψ*i, prepares |*ψ*i from the state |0i ⊗*n* . The disadvantage of this view, however, is that it does not yield much intuition as to why MERA is structured the way it is. The second way to think about MERA is through a physics-motivated view in terms of DMRG; as this view provides the beautifully simple rationale behind MERA, we present it first.

**The DMRG-motivated view.** This viewpoint is presented in [\[159\]](#page-124-7), and proceeds as follows. To begin, the general idea behind Wilson's realspace renormalization group (RG) methods (see [\[170\]](#page-125-12)) is to partition the sites of a given quantum system into *blocks*. One then simplifies the description of this space by truncating part of the Hilbert space corresponding to each block; this process is known as *coarse-graining*. The entire coarse-graining procedure is repeated iteratively on the new lower dimensional systems produced, until one obtains a polynomialsize (approximate) description (in the number of sites, *n*) of the desired system.

The key insight of White [\[168,](#page-125-0) [169\]](#page-125-1) was to realize that for 1D systems, the "correct" choice of truncation procedure on a block *B* of sites is to simply discard the Hilbert space corresponding to the "small" eigenvalues of *ρB*, where *ρ<sup>B</sup>* is the reduced state on *B* of the initial *n*-site state |*ψ*i. Here, the value of "small" depends on the approximation precision desired in the resulting tensor network representation. Intuitively, such an approximation works well if *B* in |*ψ*i is not highly entangled with the remaining sites. When this condition does not hold, however, DMRG seems to be in a bind. The idea of MERA is hence to precede each truncation step by a *disentangling* step, i.e. by a local unitary which attempts to reduce the amount of entanglement along the boundary of *B* between *B* and the remaining sites before the truncation is carried out.

More formally, MERA is defined on a *D*-dimensional lattice *L* as follows [\[159\]](#page-124-7). For simplicity, we restrict our attention to the case of *D* = 1 on spin-(1*/*2) systems with periodic boundary conditions, but the ideas here extend to *D* ≥ 1 on higher dimensional systems. Let *L* correspond to Hilbert space *V<sup>L</sup>* ≡ N *<sup>s</sup>*∈*<sup>L</sup> Vs*, where *s* ∈ *L* denote the lattice sites with respective finite-dimensional Hilbert spaces *Vs*. Consider now a block *B* ⊂ *L* of neighboring sites, whose Hilbert space we denote as *V<sup>B</sup>* ≡ N *<sup>s</sup>*∈*<sup>B</sup> Vs*. For simplicity, let us assume *B* consists of two sites *s*<sup>1</sup> and *s*2, with neighboring sites *s*<sup>0</sup> and *s*<sup>3</sup> immediately to the left and right, respectively. The disentangling step is performed by carefully choosing unitaries *U*01*, U*<sup>23</sup> ∈ U C 4 (the specific choice of *U*01*, U*<sup>23</sup> depends on the input state |*ψ*i), and applying *Uij* to consecutive sites *i* and *j*. The *truncation* step follows next by applying isometry *V*<sup>12</sup> : L C 4 7→ L C 2 to sites 1 and 2, where C 2 is the truncated space we wish to keep and where *V*12*V* † <sup>12</sup> = *I*. By applying this procedure to neighboring disjoint pairs of spins, we obtain a new spin chain with *n/*2 sites (assuming *n* is even in this example). The entire procedure is now repeated on these *n/*2 coarse-grained sites. After *O*(log *n*) itera-

<span id="page-71-0"></span>![](_page_71_Picture_2.jpeg)

**Figure 6.4:** A MERA network on 8 sites. The circle vertices represent "disentangling" unitaries. The square vertices represent isometries. (a) The tensor network view. (b) The quantum circuit view. (c) The causal cone of the site labeled *s*.

tions, we end up with a single site. The tensor network is then obtained by writing down tensors corresponding to the linear maps of each *Uij* and *Vij* , and connecting these tensors according to the geometry underlying the process outlined above. The resulting tensor network has a tree-like structure, with a single vertex at the top, and *n* legs at the bottom corresponding to each of the *n* original sites. It is depicted in Figure [6.4\(](#page-71-0)a).

Note that if we assume the bond dimension for each isometric tensor *Vij* is *d*, then the MERA representation requires *O*(*nd*<sup>4</sup> ) bits of storage; this is because there are 2*n*−1 tensors in the network, and each tensor stores at most *O*(*d* 4 ) complex numbers.

**The quantum circuit view.** In a sense, we have cheated the reader, because the DMRG view already prescribes the method for the quantum circuit view of MERA. Specifically, imagine we reverse the coarsegraining procedure described above, i.e. instead of working our way from the *n* sites of |*ψ*i up to a single site, we go in the opposite direction. Then, intuitively, the DMRG view yields a quantum circuit which, starting from the state |0i ⊗*n* , prepares (an approximation to) the desired state |*ψ*i via a sequence of the same isometries and unitaries prescribed by the tensor network. This view is depicted in Figure [6.4\(](#page-71-0)b).

**Computing with MERA.** A succinct representation of a quantum system would not necessarily be useful without the ability to compute *properties* of the system from this succinct format. A strength of MERA is that, indeed, expectation values of local observables against |*ψ*i can be efficiently computed. This follows simply because given a MERA network *M* representing |*ψ*i, the reduced state of |*ψ*i on Θ(1) sites can be computed in time *O*(log *n*) (assuming the dimension *D* of our lattice is considered a constant). To see this, we partition the tensors in our MERA network in terms of horizontal layers or *time slices* from top to bottom. Specifically, in Figure [6.4\(](#page-71-0)b), time slice 0 is before the top unitary is run, slice 1 immediately after the top unitary is run and before the following pair of isometries are run, and so forth until slice 5, which is immediately after the four bottom-most unitaries are run. Then, in each layer, the causal cone *C<sup>s</sup>* for any site *s* can be shown to have at most *constant* width (more generally, at most 4 · 3 *<sup>D</sup>*−<sup>1</sup> width [\[160\]](#page-124-8)). Here, the *causal cone* of *C<sup>s</sup>* is the set of vertices and edges in the network which influence the leg of the network corresponding to site *s*; see Figure [6.4\(](#page-71-0)c). The *width* of *C<sup>s</sup>* in a time slice is the number of edges in *C<sup>s</sup>* in that slice. Thus, by viewing the MERA network in terms of the quantum circuit view, we see that the reduced state on site *s* is given by a quantum circuit with *O*(log *n*) gates. Moreover, at any point in the computation, this circuit needs to keep track of the state of only Θ(1) qubits. Such a circuit can be straightforwardly simulated classically in *O*(log *n*) time via brute force (i.e. multiply the unitaries in the circuit and trace out qubits which are no longer needed), yielding the claim.

## <span id="page-72-0"></span>**6.6 Area laws**

We now discuss area laws in further depth, which were first mentioned briefly at the end of [§4.2.](#page-31-0) Recall that, roughly, an *area law* states 6.6. Area laws 71

<span id="page-73-0"></span>![](_page_73_Picture_1.jpeg)

**Figure 6.5:** A quantum lattice system partitioned into two parts L and  $\overline{L}$ . If the represented quantum state obeys an area law, the amount of entanglement between L and  $\overline{L}$  is bounded above by a quantity that is proportional to the surface area  $|\partial L|$ , rather than the volume |L|.

that for certain interesting classes of quantum many-body systems, the amount of entanglement between a subsystem and its complement grows as the *surface area or the boundary* rather than the *volume* of the subsystem. In literature, the amount of entanglement is typically formulated as entanglement entropy, i.e. the von Neumann entropy of the reduced density matrix on the subsystem of interest.

For example, suppose that a region L of a quantum lattice system is carved out as in Figure 6.5. An arbitrary quantum state on such a lattice follows a volume law instead of an area law; to see this, simply consider the case in which every particle in L forms an EPR pair with some other particle in  $\overline{L}$ . In this case, the amount of entanglement between L and  $\overline{L}$  is proportional to the number of particles in L, i.e. the *volume* of L, rather than the size of the boundary  $|\partial L|$ . However, it is widely believed in the physics community that many interesting classes of quantum states do satisfy an area law, most notably the ground states of gapped local Hamiltonians. Note, however, that for critical/gapless systems, there are known constructions which violate the area law [16, 93, 79].

**Motivations.** The idea that the information content of a region depends on its surface area rather than its volume is not foreign to physics. This intuition, often dubbed the *holographic principle*, is inspired by black hole thermodynamics, where the entropy of a black hole is believed to scale as the surface area of the event horizon rather than the

volume of the black hole. In fact, the original interest in area laws in quantum systems also sprang from this intriguing analogy, in connection with the conjecture that the origin of the black hole entropy is the quantum entanglement between the inside and outside of the black hole [\[28,](#page-115-11) [34,](#page-115-12) [151\]](#page-124-13).

Aside from black holes, however, there are other fundamental reasons to study area laws. For instance, area laws are a means for characterizing the structure of entanglement occurring in naturally arising systems. For example, it is well known that a generic state in Hilbert space obeys a volume law rather than an area law [\[90\]](#page-120-11). Therefore, the existence of an area law for most physically relevant systems would imply that much of nature's "interesting physics" takes place in a small corner of Hilbert space.

Last but not least, a significant motivation lies in the classical representability of quantum many-body systems. In contrast to general quantum states that require exponentially many parameters to describe, states that satisfy an area law may be expected to admit an efficient classical description via (e.g.) tensor networks of small bond dimension. In fact, area laws are closely related to tensor networks. For instance, any tensor network with constant bond dimension automatically satisfies an area law in the following sense; if we pick any subset *L* of vertices, the Schmidt rank between *L* and *L* is upper-bounded by *D*|*∂L*<sup>|</sup> , where *D* represents the bond dimension. This immediately implies that the entanglement entropy is bounded by |*∂L*| log *D*, giving rise to an area law. This bound also shows that tensor networks such as MPS or PEPS, even with polynomially large bond dimension, cannot describe entanglement that scales via a volume law.

**Why should area laws hold?** Area laws are a way of formulating (albeit not exactly) the physics intuition that entanglement in "natural" quantum systems should roughly live on the boundary. For example, a seminal work of Hastings [\[86\]](#page-119-12) shows that the ground state of a gapped local Hamiltonian on a lattice of any dimension exhibits an exponential decay of correlations, i.e. two-point correlation functions decay exponentially with respect to spatial separation between the two points. At 6.6. Area laws 73

first glance, this result already seems to suggest that the entanglement between a region and its complement should live mostly on or close to the boundary; unfortunately, it is far from trivial to lift this statement about correlations to one about entanglement.

**Known results.** In general, establishing area laws is a challenging task. While a number of specific Hamiltonian models had been shown to obey an area law [\[61,](#page-117-10) [161,](#page-124-14) [94,](#page-120-12) [63\]](#page-117-11), it was not until 2007 that Hastings proved [\[88\]](#page-119-0) that the ground states of *all* 1D gapped local Hamiltonians obey an area law. (Hastings [\[88\]](#page-119-0) also showed that the ground state of such a system can be well approximated by an MPS of polynomial bond dimension.) Subsequently, Aharonov, Arad, Landau and Vazirani gave an alternative combinatorial proof (whereas Hastings' proof relies on Lieb-Robinson bounds) of Hastings' 1D area law in the frustrationfree case [\[11,](#page-114-9) [20\]](#page-114-10). Yet another combinatorial proof was given by Arad, Kitaev, Landau, and Vazirani [\[19\]](#page-114-8), which also applies in frustrated settings and improves significantly on the area law parameters obtained. The approach of [\[19\]](#page-114-8) was later adapted to the setting of a constant-fold degenerate ground space by Huang [\[91\]](#page-120-7). Here, any state in the ground space obeys an area law. As an aside, we remark that this study of combinatorial proofs of the area law (and in particular, the concept of an *approximate ground state projection*, or AGSP) played an instrumental role in the development of the first rigorous polynomial time algorithm for finding the ground state of a gapped 1D system [\[110\]](#page-121-6). In 2012, Brandão and Horodecki [\[35\]](#page-115-10) showed that 1D local Hamiltonians that have an exponential decay of correlations satisfy an area law. Together with Hastings' result [\[86\]](#page-119-12) that gapped local Hamiltonians exhibit exponential decay of correlations, this yields still another proof of Hastings' 1D area law [\[88\]](#page-119-0). Finally, Wolf [\[176\]](#page-125-13) showed that translationally invariant critical fermionic systems of any spatial dimension satisfy an area law up to a logarithmic correction.

Interestingly, in contrast to the ground state case just discussed, *thermal states* of local Hamiltonians always satisfy an area law regardless of the energy gap or the spatial dimension [\[120,](#page-122-10) [177\]](#page-126-3).

For further details on combinatorial area law proofs, the reader is referred to [§7.5,](#page-102-0) where the result of [\[19\]](#page-114-8) is sketched. For a physicsoriented survey of area laws, see Eisert, Cramer, and Plenio [\[61\]](#page-117-10).

**Open problems.** Arguably the most important open question in this area is whether an area law holds in dimensions larger than 1D. Unfortunately, the known approaches do not seem generalize easily to this setting. As for alternate approaches, we list two possible routes. First, Masanes [\[118\]](#page-121-11) has shown that the following two criteria are sufficient to establish an area law: (1) There is sufficiently fast decay of correlations, and (2) the number of "low-energy" states is not exponentially large. Second, Van Acoleyen, Mariën, and Verstraete [\[4\]](#page-113-8) have recently shown that if two gapped systems *H*<sup>1</sup> and *H*<sup>2</sup> are adiabatically connected, i.e. there is a smooth path between *H*<sup>1</sup> and *H*<sup>2</sup> such that the system remains gapped at every point on the path, then the ground state of *H*<sup>1</sup> satisfies an area law if and only if the ground state of *H*<sup>2</sup> also satisfies an area law.

# **7**

# <span id="page-77-0"></span>**Reviews of Selected Results**

Having discussed a number of Hamiltonian complexity concepts originating from the physics literature in [§5](#page-35-0) and [6,](#page-50-0) we now expound on a selected number of central computer science-based results in the area. Specifically, [§7.1](#page-77-1) reviews Kitaev's original proof that 5-local Hamiltonian is QMA-complete. [§7.2](#page-84-0) discusses the ensuing proof by Kitaev, Kempe and Regev using perturbation theory-based gadgets that 2-local Hamiltonian is QMA-complete. In [§7.3,](#page-91-0) we review Bravyi and Vyalyi's Structure Lemma and its use in proving that the 2-local commuting Hamiltonian problem is in NP, and thus unlikely to be QMA-hard. [§7.4](#page-96-0) gives a quantum information theoretic presentation of Bravyi's polynomial time algorithm for Quantum 2-SAT. Finally, [§7.5](#page-102-0) provides an intuitive review of the combinatorial proof of an area law for 1D gapped systems due to Arad, Kitaev, Landau and Vazirani.

## <span id="page-77-1"></span>**7.1 5-local Hamiltonian is QMA-complete**

One of the cornerstones of classical computational complexity theory is the Cook-Levin theorem, which states that classical constraint satisfaction is NP-complete. The quantum version of this theorem is due to Kitaev, who showed that the 5-local Hamiltonian problem is QMA-complete [106]. In this section, we review Kitaev's proof. For a more in-depth treatment, we refer the reader to the detailed surveys of Aharonov and Naveh [18] and Gharibian [71].

We begin by showing that k-local Hamiltonian for any  $k \in \Theta(1)$  is in QMA.

#### Local Hamiltonian is in QMA

**Theorem 7.1.** (Kitaev [106]) For any constant  $k \ge 1$ , k-LH  $\in$  QMA.

Proof sketch. The basic idea is that whenever we have a YES instance of k-LH, the quantum proof sent to the verifier is essentially the ground state of the local Hamiltonian H in question. The verifier then runs a simple "local" version of phase estimation to roughly determine the energy penalty incurred by the given proof.

To begin, suppose we have an instance (H, a, b) of k-LH with k-local Hamiltonian  $H = \sum_{j=1}^r H_j \in \mathcal{L}((\mathbb{C}^2)^{\otimes n})$ . We construct an efficient quantum verification circuit V as follows. First, the quantum proof is  $|\psi\rangle \in \mathbb{C}^r \otimes (\mathbb{C}^2)^{\otimes n} \otimes \mathbb{C}^2$ , s.t.

$$|\psi\rangle = \left(\frac{1}{\sqrt{r}} \sum_{j=1}^{r} |j\rangle\right) \otimes |\eta\rangle \otimes |0\rangle,$$
 (7.1)

for  $\{|j\rangle\}_{j=1}^r$  an orthonormal basis for  $\mathbb{C}^r$ , and  $|\eta\rangle$  an eigenvector corresponding to some eigenvalue  $\lambda$  of H. We call the first register of  $|\psi\rangle$  the index register, the second the proof register, and the last the answer register. The circuit V is defined as  $V := \sum_{j=1}^r |j\rangle\langle j| \otimes W_j$ , where  $W_j$  is defined as follows. For our Hamiltonian  $H = \sum_{j=1}^r H_j$ , suppose  $H_j$  has spectral decomposition  $H_j = \sum_s \lambda_s |\lambda_s\rangle\langle\lambda_s|$ . Then, define  $W_j$  acting on the proof and answer registers with action

$$W_j(|\lambda_s\rangle \otimes |0\rangle) = |\lambda_s\rangle \otimes \left(\sqrt{\lambda_s}|0\rangle + \sqrt{1-\lambda_s}|1\rangle\right).$$
 (7.2)

**Question 2.** Show that if we apply V to the proof  $|\psi\rangle$  and measure the answer register in the computational basis, the probability of obtaining outcome 1 is  $1 - \frac{1}{r} \langle \eta | H | \eta \rangle$ . Conclude that since the thresholds a and b are inverse polynomially separated, k-LH  $\in$  QMA.

**Hint 1.** Observe that since we may assume the index register is implicitly measured at the end of the verification, V above can be thought of as using the index register to choose an index  $j \in [r]$  uniformly at random, followed by applying  $W_j$  to the proof register. As a result, the probability of outputting 1 can be expressed as

$$Pr(\text{output } 1) = \sum_{j=1}^{r} \frac{1}{r} Pr(\text{output } 1 \mid W_j \text{ is applied}).$$
 (7.3)

**Hint 2.** When considering the action of any  $W_j$  on  $|\eta\rangle$ , rewrite  $|\eta\rangle$  in the eigenbasis of  $H_j$  as  $|\eta\rangle = \sum_s \alpha_s |\lambda_s\rangle$  (the values of the coefficients  $\alpha_s$  will not matter).

#### 5-Local Hamiltonian is QMA-hard

To show that 5-local Hamiltonian is QMA-hard, Kitaev gives a quantum adaptation of the Cook-Levin theorem [106]. Specifically, he shows a polynomial-time many-one or Karp reduction from an arbitrary problem in QMA to 5-LH, which we now discuss.

Let P be a promise problem in QMA, and let  $V = V_L V_{L-1} \dots V_1$  be a verification circuit for P composed of unitaries  $V_k$ . Without loss of generality, we may assume each  $V_k$  acts on pairs of qubits, and that  $V \in \mathcal{U}((\mathbb{C}^2)^{\otimes m} \otimes (\mathbb{C}^2)^{\otimes N-m})$ , where the m-qubit register contains the proof V verifies, and the remaining qubits are ancilla qubits. Using V, our goal is to define a 5-local Hamiltonian H that has a small eigenvalue if and only if there exists a proof  $|\psi\rangle \in (\mathbb{C}^2)^{\otimes m}$  causing V to accept with high probability.

We let H act on  $(\mathbb{C}^2)^{\otimes m} \otimes (\mathbb{C}^2)^{\otimes N-m} \otimes \mathbb{C}^{L+1}$ , which is simply the initial space V acts on, tensored with an (L+1)-dimensional *counter* or *clock* register. We label the three registers H acts on as p for proof, a for ancilla, and c for clock, respectively. We now define H itself:

$$H := H_{\rm in} + H_{\rm prop} + H_{\rm out}, \tag{7.4}$$

with the terms *H*in, *H*prop, and *H*out defined as follows. Let

$$H_{\text{in}} := I_p \otimes (I_a - |0 \dots 0\rangle\langle 0 \dots 0|_a) \otimes |0\rangle\langle 0|_c$$
 (7.5)

$$H_{\text{out}} := \left( |0\rangle\langle 0| \otimes I_{(\mathbb{C}^2)^{\otimes m-1}} \right)_p \otimes I_a \otimes |L\rangle\langle L|_c \tag{7.6}$$

$$H_{\text{prop}} := \sum_{j=1}^{L} H_j, \text{ where}$$

$$H_j := -\frac{1}{2}V_j \otimes |j\rangle\langle j-1|_c - \frac{1}{2}V_j^{\dagger} \otimes |j-1\rangle\langle j|_c + \qquad (7.7)$$

$$\frac{1}{2}I\otimes(|j\rangle\langle j|+|j-1\rangle\langle j-1|)_c. \tag{7.8}$$

**Question 3.** Suppose that for any YES-instance of promise problem *P*, *V* accepts a valid proof |*ψ*i with *certainty*. Verify that the following state |*η*i, known as the *history state*, lies in the null space of *H*. Why do you think |*η*i is called the history state?

$$|\eta\rangle := \frac{1}{\sqrt{L+1}} \sum_{j=0}^{L} \left( V_j \dots V_1 |\psi\rangle_p \otimes |0\rangle_a^{\otimes N-m} \right) \otimes |j\rangle_c.$$
 (7.9)

In order to ease the analysis of *H*'s smallest eigenvalue, it turns out to be extremely helpful to apply the following change-of-basis operator to *H*:

$$W = \sum_{j=0}^{L} V_j \dots V_1 \otimes |j\rangle\langle j|_c.$$
 (7.10)

**Question 4.** Show that:

- 1. |*η*ˆi := *W*|*η*i = |*ψ*i*<sup>p</sup>* ⊗ |0i ⊗*N*−*m <sup>a</sup>* ⊗ |*γ*i*c*, where we define |*γ*i := √ *L*+1 P*<sup>L</sup> <sup>j</sup>*=0 |*j*i*.*
- 2. *H*ˆ in := *W*†*H*in*W* = *H*in,
- 3. *H*ˆ out := *W*†*H*out*W* = (*V* † ⊗ *Ic*)*H*out(*V* ⊗ *Ic*),
- 4. *H*ˆ *<sup>j</sup>* := *W*†*HjW* = *Ip,a* ⊗ 2 (|*j* − 1ih*j* − 1| − |*j* − 1ih*j*| − |*j*ih*j* − 1| +

 $|j\rangle\langle j|)_c$ , and hence  $\hat{H}_{\text{prop}}$  equals

$$I_{p} \otimes I_{a} \otimes \begin{pmatrix} \frac{1}{2} & -\frac{1}{2} & 0 & 0 & 0 & \dots \\ -\frac{1}{2} & 1 & -\frac{1}{2} & 0 & 0 & \dots \\ 0 & -\frac{1}{2} & 1 & -\frac{1}{2} & 0 & \dots \\ 0 & 0 & -\frac{1}{2} & 1 & -\frac{1}{2} & \dots \\ 0 & 0 & 0 & -\frac{1}{2} & \ddots & \ddots \\ \vdots & \vdots & \vdots & \vdots & \ddots & \ddots \end{pmatrix} =: I_{p} \otimes I_{a} \otimes E_{c},$$

$$(7.11)$$

where we have let E denote a tridiagonal matrix acting on the clock register.

Henceforth, when we refer to H,  $H_{\text{in}}$ ,  $H_{\text{out}}$ ,  $H_{\text{prop}}$ ,  $H_j$ , and  $|\eta\rangle$ , we implicitly mean  $\hat{H}$ ,  $\hat{H}_{\text{in}}$ ,  $\hat{H}_{\text{out}}$ ,  $\hat{H}_{\text{prop}}$ ,  $\hat{H}_j$ , and  $|\hat{\eta}\rangle$ , respectively.

#### The YES case: H has a small eigenvalue

**Question 5.** Suppose that given proof  $|\psi\rangle$ , V accepts with probability at least  $1 - \epsilon$  for  $\epsilon \geq 0$ . Show that

$$\langle \eta | H | \eta \rangle \le \frac{1}{L+1} \epsilon.$$
 (7.12)

Conclude that if there exists a proof  $|\psi\rangle$  accepted with "high" probability by V, then H has a "small" eigenvalue.

#### The NO case: H has no small eigenvalues

If there is no proof  $|\psi\rangle$  accepted by V with high probability, then we wish to show that H has no small eigenvalues. To do so, write  $H=A_1+A_2$  for  $A_1:=H_{\rm in}+H_{\rm out}$  and  $A_2:=H_{\rm prop}$ . If  $A_1$  and  $A_2$  were to commute, then analyzing the smallest eigenvalues of  $A_1$  and  $A_2$  independently would yield a lower bound on the smallest eigenvalue of H. Unfortunately,  $A_1$  and  $A_2$  do not commute; hence, if we wish to use information about the spectra of  $A_1$  and  $A_2$  to lower bounds H's eigenvalues, we will need a stronger technical tool, given below.

**Lemma 7.2** (Kitaev [\[106\]](#page-121-1), Geometric Lemma, Lemma 14.4)**.** Let *A*1*, A*<sup>2</sup> 0, such that the minimum *non-zero* eigenvalue of both operators is lower bounded by *v*. Assume that the null spaces L<sup>1</sup> and L<sup>2</sup> of *A*<sup>1</sup> and *A*2, respectively, have trivial intersection, i.e. L<sup>1</sup> ∩ L<sup>2</sup> = {**0**}. Then

$$A_1 + A_2 \succeq 2v \sin^2 \frac{\alpha(\mathcal{L}_1, \mathcal{L}_2)}{2} I , \qquad (7.13)$$

where the *angle α*(X *,* Y) between X and Y is defined over vectors |*x*i and |*y*i as

$$\cos\left[\angle(\mathcal{X},\mathcal{Y})\right] := \max_{\substack{|x\rangle \in \mathcal{X}, |y\rangle \in \mathcal{Y} \\ \| |x\rangle \| = \| |y\rangle \| = 1}} |\langle x|y\rangle|.$$

**Question 6.** For complex Euclidean spaces X and Y, is the statement X ∩ Y = {**0**} equivalent to X and Y being orthogonal spaces?

We use Kitaev's Geometric Lemma with *A*<sup>1</sup> = *H*in + *H*out and *A*<sup>2</sup> = *H*prop to lower bound the smallest eigenvalue of *H* in the NO case.

**Question 7.** For *A*<sup>1</sup> = *H*in+*H*out and *A*<sup>2</sup> = *H*prop, what non-zero value of *v* can we use for the Geometric Lemma?

**Hint 3.** For *A*1, recall that commuting operators simultaneously diagonalize.

**Hint 4.** For *A*2, the eigenvalues are given by *λ<sup>k</sup>* = 1 − cos[*πk/*(*L* + 1)] for 0 ≤ *k* ≤ *L*. Use this to show that the smallest *positive* eigenvalue of *A*<sup>2</sup> is at least 1 − cos(*π/*(*L* + 1)) ≥ *c/L*<sup>2</sup> .

**Question 8.** In order to compute *α*(L1*,*L2), convince yourself first that

<span id="page-82-0"></span>
$$\mathcal{L}_{1} = \left[ ((\mathbb{C}^{2})^{\otimes m})_{p} \otimes |0\rangle_{a}^{\otimes N-m} \otimes |0\rangle_{c} \right] \oplus \\
\left[ ((\mathbb{C}^{2})^{\otimes N})_{p,a} \otimes \operatorname{span}(|1\rangle, \dots |L-1\rangle)_{c} \right] \oplus \\
\left[ V^{\dagger}(|1\rangle \otimes (\mathbb{C}^{2})^{\otimes N-1})_{p,a} \otimes |L\rangle_{c} \right], \tag{7.14}$$

$$\mathcal{L}_{2} = ((\mathbb{C}^{2})^{\otimes N})_{p,a} \otimes |\gamma\rangle_{c}, \tag{7.15}$$

To compute sin<sup>2</sup> *<sup>α</sup>*(L1*,*L2) 2 for the Geometric Lemma, we now upper bound √

$$\cos^2 \alpha(\mathcal{L}_1, \mathcal{L}_2) \le 1 - \frac{1 - \sqrt{\epsilon}}{L + 1}.$$

Question 9. Show that  $\cos^2 \alpha(\mathcal{L}_1, \mathcal{L}_2) = \max_{\substack{|y\rangle \in \mathcal{L}_2 \\ \||y\rangle\|=1}} \langle y|\Pi_{\mathcal{L}_1}|y\rangle.$ 

Observe from Equation 7.14 that  $\mathcal{L}_1$  is a direct sum of three spaces, and hence the projector onto  $\mathcal{L}_1$  can be written as the sum of three respective projectors  $\Pi_1 + \Pi_2 + \Pi_3$ .

**Question 10.** Observe by Equation 7.15 that for any  $|y\rangle \in \mathcal{L}_2$ ,  $|y\rangle = |\zeta\rangle_{p,a} \otimes |\gamma\rangle_c$  for some  $|\zeta\rangle \in (\mathbb{C}^2)^{\otimes m} \otimes (\mathbb{C}^2)^{\otimes N-m}$ .

- 1. Show that  $\langle y|\Pi_1|y\rangle = \frac{L-1}{L+1}$ .
- 2. One can show that

$$\langle y|\Pi_2 + \Pi_3|y\rangle \leq \cos^2\varphi(\mathcal{K}_1,\mathcal{K}_2),$$

where  $\mathcal{K}_1 = (\mathbb{C}^2)^{\otimes m} \otimes |0\rangle^{\otimes N-m}$  and  $\mathcal{K}_2 = V^{\dagger}|1\rangle \otimes (\mathbb{C}^2)^{\otimes N-1}$ . Use the fact that in the NO case, any proof is accepted by V with probability at most  $\epsilon$  to conclude that

$$\langle y|\Pi_2 + \Pi_3|y\rangle \le \frac{1}{L+1}(1+\sqrt{\epsilon}).$$

Combining the results of the question above, we have that  $\cos^2 \alpha(\mathcal{L}_1, \mathcal{L}_2) \leq 1 - ((1 - \sqrt{\epsilon})/(L+1))$ . Using the identities  $\sin^2 x + \cos^2 x = 1$  and  $\sin(2x) = 2\sin x \cos x$ , this yields

$$\sin^2 \frac{\alpha(\mathcal{L}_1, \mathcal{L}_2)}{2} \ge \frac{1}{4} \sin^2 \alpha(\mathcal{L}_1, \mathcal{L}_2) \ge \frac{1 - \sqrt{\epsilon}}{4(L+1)}.$$

We conclude that in the NO case, the minimum eigenvalue of H scales as  $\Omega((1-\sqrt{\epsilon})/L^3)$ .

**Question 11.** Recall that in the YES case, the smallest eigenvalue of H is upper bounded by  $\epsilon/(L+1)$ . Why do the eigenvalue bounds we have obtained in the YES and NO cases thus suffice to show that 5-LH is QMA-hard?

#### Making H 5-local

We are almost done! The only remaining issue is that we would like H to be 5-local, but a binary representation of the (L+1)-dimensional

clock register is unfortunately log(*n*)-local. To alleviate this [\[106\]](#page-121-1), we switch to a *unary* representation of time. In other words, we now let *H* act on (C 2 ) <sup>⊗</sup>*<sup>m</sup>* ⊗ (C 2 ) <sup>⊗</sup>*N*−*<sup>m</sup>* ⊗ (C 2 ) <sup>⊗</sup>*L*, where the counter register is now given in *unary*, i.e. |*j*i ∈ C *<sup>L</sup>*+1 is represented as

$$|\underbrace{1,\ldots,1}_{j},0,\ldots,0\rangle. \tag{7.16}$$

The operator basis |*i*ih*j*| for L(C *<sup>L</sup>*+1) translates easily to this new representation (omitted here; see Reference [\[106\]](#page-121-1)). To enforce the clock register to indeed always be a valid representation of some time *j* in unary, we add a new fourth penalty term to *H* which acts only on the clock register, namely

$$H_{\text{stab}} := I_{p,a} \otimes \sum_{j=1}^{L-1} |0\rangle\langle 0|_j \otimes |1\rangle\langle 1|_{j+1}. \tag{7.17}$$

Hence, the new *H* is given by *H* = *H*in+*H*prop+*H*out+*H*stab. By using the fact that both *H*in + *H*prop + *H*out and *H*stab act invariantly on the original space the old *H* used to act on, it is a fairly straightforward exercise to verify that the analysis obtained above goes through for this new definition of *H* as well [\[106\]](#page-121-1). We conclude that 5-LH is QMA-hard.

## <span id="page-84-0"></span>**7.2 2-local Hamiltonian is QMA-complete**

In [\[106\]](#page-121-1), Kitaev showed that the 5-local Hamiltonian problem is QMAcomplete. In this section, we review Kitaev, Kempe, and Regev's perturbation theory proof that even 2-local Hamiltonian is QMAhard [\[102\]](#page-120-3). Note that Reference [\[102\]](#page-120-3) also provides an alternative "simpler" proof based on elementary linear algebra and the so-called *Projection Lemma* in the same paper; however, as the Projection Lemma can be derived via perturbation theory, and since Reference [\[102\]](#page-120-3)'s idea of using perturbation theory gadgets has since proven useful elsewhere in Hamiltonian complexity (e.g. [\[127\]](#page-122-3)), we focus on the latter proof technique. Besides, perturbation theory is a standard tool in a physicist's toolbox, and our goal in this survey is to better understand what goes on in physicists' minds!

The proof that 2-local Hamiltonian is QMA-complete is quite complicated. To aid in its assimilation, we therefore begin with a highlevel overview of how the pieces of the proof fit together. The starting point shall be Kempe and Regev's result [\[103\]](#page-120-2) that 3-LH is also QMA-complete. Roughly, the latter result is obtained via a circuit-to-Hamiltonian construction similar to Kitaev's from [§7.1,](#page-77-1) except that one first uses only a single qubit to refer to the clock in the propagation Hamiltonian *H*prop — this reduces the Hamiltonian's locality from 5 to 3. To compensate for this, one next imposes a large energy penalty on the invalid clock space by multiplying *H*stab by a polynomial factor.

**Overview of the proof.** To prove that 2-LH is QMA-hard, the approach is to show a Karp or mapping reduction from an arbitrary instance of 3-LH to 2-LH. To achieve this, given a 3-local Hamiltonian *H* acting on *n* qubits, we map it to a 2-local Hamiltonian *H*<sup>e</sup> as follows.

- (Step 1: Rewrite *H* by isolating 3-local terms) Rewrite *H* in a form which resembles *Y* −6*B*1*B*2*B*3, where *B*1*B*2*B*<sup>3</sup> is shorthand for *B*<sup>1</sup> ⊗ *B*<sup>2</sup> ⊗ *B*3, the *B<sup>i</sup>* are one-local and positive semidefinite, and *Y* is a 2-local Hamiltonian.
- (Step 2: Construct *H*<sup>e</sup> ) Define *H*<sup>e</sup> = *Q* + *P*(*Y, B*1*, B*2*, B*3), where *P* is an operator with small norm and which depends on *Y, B*1*, B*2*, B*3, and where *Q* has large spectral gap and depends only on the spectral gap of *H*. We refer to *P* as the *perturbation* and *H*<sup>e</sup> as the *perturbed Hamiltonian*.

This outlines the reduction itself. It now remains to outline the proof of correctness, i.e. to show that the 2-local Hamiltonian *H*<sup>e</sup> reproduces the low energy spectrum of the input 3-local Hamiltonian *H*. In order to facilitate understanding, we present the analysis in a backwards fashion compared to the presentation in [\[102\]](#page-120-3).

• (Step 3: Define an effective Hamiltonian *H*eff) We first define an *effective* 3-local Hamiltonian *H*eff whose low-energy spectrum is (by inspection) identical to that of *H*. We will see next that *H*<sup>e</sup> has been cleverly chosen to simulate *H*eff with only 2-local interactions.

- (Step 4: Define the self-energy, Σ−(*z*)) A standard tool in perturbation theory is an operator-valued function known as the *self-energy*, denoted Σ−(*z*), for *z* ∈ C. In this step, we show that for an appropriate choice of *z*, we have k *H*eff − Σ−(*z*) k<sup>∞</sup> ≤ for some small  *>* 0. Intuitively, this relationship will hold because *H*eff is simply a truncated version of the series expansion of Σ−(*z*).
- (Step 5: Relate the low energy spectrum of Σ−(*z*) to that of *H*<sup>e</sup> ) This step is where the actual perturbation theory analysis comes in. The outcome of this step will be that, assuming k *H*eff − Σ−(*z*) k<sup>∞</sup> ≤ , the *j*th smallest eigenvalue of *H*eff is close to the *j*th smallest eigenvalue of *H*<sup>e</sup> .

To recap, once we define the 2-local Hamiltonian *H*<sup>e</sup> , the spectral analysis we perform follows the chain of relationships:

$$H \approx H_{\text{eff}} \approx \Sigma_{-}(z) \approx \tilde{H},$$

where here ≈ roughly indicates that the two operators in question share a similar ground space. We now discuss each of these steps in further detail.

#### **7.2.1 Step 1: Rewrite** *H* **by isolating 3-local terms**

**Question 12.** Convince yourself that *H* can be rewritten, up to rescaling by a constant, in the form

<span id="page-86-0"></span>
$$H \propto Y - 6\sum_{i=1}^{M} B_{i1} \otimes B_{i2} \otimes B_{i3}, \tag{7.18}$$

where each *Bij* is a one-local positive semidefinite operator and *Y* is a 2-local Hamiltonian whose operator norm is upper bounded by an inverse polynomial in *n*.

**Hint 5.** Rewrite each local term of *H* in the local Pauli operator basis, i.e. as a linear combination of terms of the form *σ*<sup>1</sup> ⊗ *σ*<sup>2</sup> ⊗ *σ*<sup>3</sup> for *σ<sup>i</sup>* ∈ {*I, σ<sup>x</sup> , σ<sup>y</sup> , σz*}. Then, for each such term involving Pauli operators, try to add 1-local multiples of the identity in order to obtain positive semidefinite terms  $B_{i1} \otimes B_{i2} \otimes B_{i3}$ . You will then have to subtract off certain terms to make up for this addition; these subtracted terms will form Y. Think about why Y must indeed be 2-local.

## 7.2.2 Step 2: Construct $\widetilde{H}$

Using the decomposition of H in Equation 7.18, we can now construct our desired 2-local Hamiltonian,  $\widetilde{H}$ . As done in [102], for simplicity, we assume that M=1 in Equation 7.18, i.e. that  $H=Y-6B_1B_2B_3$ . The extension to arbitrary M follows similarly [102].

To construct  $\widetilde{H}$ , suppose  $H \in \mathcal{L}((\mathbb{C}^2)^{\otimes n})$ . Then, we introduce three auxiliary qubits and define  $\widetilde{H} \in \mathcal{L}((\mathbb{C}^2)^{\otimes n} \otimes (\mathbb{C}^2)^{\otimes 3})$  as follows [102].

$$\widetilde{H} := Q + P,$$
(7.19)
$$Q := -\frac{1}{4\delta^{3}} I \otimes (\sigma_{1}^{z} \sigma_{2}^{z} + \sigma_{1}^{z} \sigma_{3}^{z} + \sigma_{2}^{z} \sigma_{3}^{z} - 3I),$$
(7.20)
$$P := (Y + \frac{1}{\delta} (B_{1}^{2} + B_{2}^{2} + B_{3}^{2})) \otimes I -$$

$$\frac{1}{\delta^{2}} (B_{1} \otimes \sigma_{1}^{x} + B_{2} \otimes \sigma_{2}^{x} + B_{3} \otimes \sigma_{3}^{x}),$$
(7.21)

where  $\delta > 0$  is some small constant, and  $\sigma^i_j$  denotes the *i*th Pauli operator applied to qubit j. Notice that the "unperturbed" Hamiltonian Q contains no information about H itself, whereas the term that does contain the information about H, P, is thought of as the "perturbation". The reason for this is that Q is thought of as a penalty term with a large spectral gap (compared to  $\|P\|_{\infty}$ ), so that intuitively, the ground space of  $\tilde{H}$  will be forced to be a subspace of the ground space of Q (since Q will enforce a large penalty on any vector not in this space).

**Question 13.** Show that Q has eigenvalues 0 and  $1/\delta^3$ . Conclude that for "small" constant  $\delta$ , Q has a "large" constant-sized spectral gap.

<span id="page-87-0"></span>**Question 14.** Show that associated with the null space of Q is the space

$$L_{-} = (\mathbb{C}^{2})^{\otimes n} \otimes \operatorname{Span}(|000\rangle, |111\rangle).$$

For simplicity, we henceforth define  $C := \text{Span}(|000\rangle, |111\rangle)$ . Conclude

that we can think of *C* as a *logical* qubit, and that we can define logical Pauli operators *σ i C* acting on *C*.

## **7.2.3 Step 3: Define an effective Hamiltonian** *H***eff**

**Question 15.** Show that the effective Hamiltonian

$$H_{\text{eff}} := Y \otimes I_C - 6B_1B_2B_3 \otimes \sigma_C^x \tag{7.22}$$

has the same ground state energy as *H* = *Y* −6*B*1*B*2*B*3. Conclude that it suffices to show that the ground state energy of *H*eff approximates that of *H*<sup>e</sup> .

#### **7.2.4 Step 4: Define the self-energy Σ−(***z***)**

Let *δ >* 0 be a small constant. In this section, we define an operatorvalued function Σ−(*z*), known as the self-energy, and show that for certain values of *z*, we have k *H*eff − Σ−(*z*) k<sup>∞</sup> ∈ *O*(*δ*). At a high-level, the claim follows by using the series expansion of Σ−(*z*) to observe that for appropriate *z*, one has Σ−(*z*) = *H*eff + *O*(*δ*).

**Definition of Σ−(***z***).** To begin, suppose *H*<sup>e</sup> = *Q* + *P* acts on Hilbert space H, for *Q* the unperturbed Hamiltonian and *P* the perturbation. Let *λ*<sup>∗</sup> ∈ R be some cutoff value. Then, let L<sup>−</sup> (L+) denote the span of *Q*'s eigenvectors with eigenvalue strictly less than *λ*<sup>∗</sup> (at least *λ*∗), and let Π<sup>−</sup> (Π+) denote the projector onto L<sup>−</sup> (L+). For notational convenience, for any operator *A*, we define

$$A_{+} := \Pi_{+}A\Pi_{+}$$
 $A_{+-} := \Pi_{+}A\Pi_{-}$ 
 $A_{-+} := \Pi_{-}A\Pi_{+}$ 
 $A_{-} := \Pi_{-}A\Pi_{-}$ 

To define the self-energy operator Σ−(*z*), we now require the notion of the *resolvent* of an operator *A*, defined *R*(*z, A*) := (*zI* − *A*) −1 . Intuitively, the resolvent will be the vital link allowing us to connect the low-energy eigenvalues of our constructed 2-local Hamiltonian *H*<sup>e</sup> to those of *H*eff (and hence to those of our original 3-local Hamiltonian H). Roughly, the range of z we will be interested in for the resolvent is  $z \in [c - \epsilon, d + \epsilon]$ , where c and d are defined such that the eigenvalues of  $H_{\rm eff}$  lie in the range [c,d] for some c < d. Further details can be found in §7.2.5, where explicit use of the resolvent comes into play. Returning to our discussion here, the self-energy is now defined as  $\Sigma_{-}(z) := zI_{-} - R_{-}^{-1}(z, \widetilde{H})$ . In this section, we use the fact [102] that  $\Sigma_{-}(z)$  has a simple and useful series expansion, given by

<span id="page-89-0"></span>
$$\Sigma_{-}(z) = Q_{-} + P_{-} + P_{-+}R_{+}P_{+-} + P_{-+}R_{+}P_{++}R_{+}P_{+-} + P_{-+}R_{+}P_{+}R_{+}P_{+}R_{+}P_{+-} + \cdots$$

$$(7.23)$$

 $\Sigma_{-}(z)$  is close to  $H_{\rm eff}$ . For our specific definition of  $\widetilde{H}$ , to show that  $\Sigma_{-}(z)$  is close to  $H_{\rm eff}$ , we simply show that  $H_{\rm eff}$  is the series expansion of  $\Sigma_{-}(z)$  up to the third order. Define  $\Delta := 1/\delta^3$ , and consider Equation 7.23.

**Question 16.** We now compute the expression for  $\Sigma_{-}(z)$  for  $\widetilde{H}$ . Recall that our goal is to show that the low order terms of  $\Sigma_{-}(z)$  are precisely our desired effective Hamiltonian,  $H_{\text{eff}}$ .

- 1. Show that the zeroth order term of  $\Sigma_{-}(z)$  is zero, i.e.  $Q_{-}=0$ .
- 2. Show that  $R_{+} = (z \Delta)^{-1} I_{\mathcal{L}_{+}}$ .
- 3. Use parts 1 and 2 above to conclude that in our case,

$$\Sigma_{-}(z) = P_{-} + \frac{1}{z - \Delta} P_{-+} P_{+-} + \frac{1}{(z - \Delta)^{2}} P_{-+} P_{++} P_{+-} + \frac{1}{(z - \Delta)^{3}} P_{-+} P_{+} P_{+-} + \cdots$$

4. Show that

$$P_{-+} = -\frac{1}{\delta^2} (B_1 \otimes |000\rangle\langle 100| + B_2 \otimes |000\rangle\langle 010| + B_3 \otimes |000\rangle\langle 001| + B_1 \otimes |111\rangle\langle 011| + B_2 \otimes |111\rangle\langle 101| + B_3 \otimes |111\rangle\langle 110|).$$

Derive similar expressions for  $P_{+-}$ ,  $P_{-}$ , and  $P_{+}$ .

5. For ease of notation, define  $X := (Y + \frac{1}{\delta}(B_1^2 + B_2^2 + B_3^2))$ , and let  $I_C$  denote the projector onto space C from Question 14. Show that

$$P_{-} = X \otimes I_{C},$$

$$P_{-+}P_{+-} = \frac{1}{\delta^{4}}(B_{1}^{2} + B_{2}^{2} + B_{3}^{2}) \otimes I_{C},$$

$$P_{-+}P_{++}P_{+-} = \frac{1}{\delta^{4}}(B_{1}XB_{1} + B_{2}XB_{2} + B_{3}XB_{3}) \otimes I_{C} - \frac{6}{\delta^{6}}B_{1}B_{2}B_{3} \otimes \sigma_{C}^{x}.$$

- 6. By setting  $z \ll \Delta$  a constant, show that  $(z \Delta)^{-1} = -\delta^3 + O(\delta^6)$ .
- 7. Finally, using all parts above, show that, as desired,

$$\Sigma_{-}(z) = Y \otimes I_{C} - 6B_{1}B_{2}B_{3} \otimes \sigma_{C}^{x} + O(\delta) = H_{\text{eff}} + O(\delta).$$
Conclude that  $\|H_{\text{eff}} - \Sigma_{-}(z)\|_{\infty} \in O(\delta)$ .

# <span id="page-90-0"></span>7.2.5 Step 5: Relate the low energy spectrum of $\Sigma_-(z)$ to that of $\widetilde{H}$

In this section, we plug in Theorem 3 of [102], which allows us to conclude that the small eigenvalues of  $\Sigma_{-}(z)$  are close to the small eigenvalues of  $\widetilde{H}$ .

<span id="page-90-1"></span>**Theorem 7.3.** (Kitaev, Kempe, Regev [102], Theorem 3) Let  $\lambda_*$  be the cutoff on the spectrum of Q, as before. Assume the eigenvalues of Q lie in the range  $(-\infty, \lambda_* + \alpha/2] \cup [\lambda_* + \alpha/2, \infty)$  for some  $\alpha \in \mathbb{R}$ , and that  $\|P\|_{\infty} < \alpha/2$ . Fix arbitrary  $\epsilon > 0$ . Then, if there exists operator  $H_{\text{eff}}$  whose eigenvalues lie in the range [c,d] for some  $c < d < \lambda_* - \epsilon$ , and such that  $\|\Sigma_-(z) - H_{\text{eff}}\|_{\infty} \le \epsilon$  for all  $z \in [c - \epsilon, d + \epsilon]$ , then the jth eigenvalue of  $\widetilde{\Pi}_-\widetilde{H}\widetilde{\Pi}_-$  is  $\epsilon$ -close to the jth eigenvalue of  $H_{\text{eff}}$ . Here, we assume eigenvalues are ordered for each operator in non-decreasing order, and we define  $\widetilde{\Pi}_-$  as the projector onto the span of the eigenvectors of  $\widetilde{H}$  of eigenvalue strictly less than  $\lambda_*$ .

To sketch at a high-level the idea behind the proof of Theorem 7.3, recall that our goal in this section is to approximate the low-energy

spectrum of an input 3-local Hamiltonian H with a 2-local Hamiltonian nian H. To this end, we first observed that the low-energy spectrum of H is identical to that of  $H_{\text{eff}}$ . Next, we showed that  $H_{\text{eff}}$  is wellsimulated in this low-energy space by the self-energy,  $\Sigma_{-}(z)$ , since the former is a truncation of the series expansion of the latter. Finally, it remains to link the spectrum of  $\Sigma_{-}(z)$  to that of  $H_{-}$  (where recall  $\widetilde{H}_{-}$  is  $\widetilde{H}$  projected onto its low-energy space), which is precisely the task of Theorem 7.3. Here, we are interested in the eigenvalues of  $H_{-}$ , and it is here that the resolvent plays a crucial role. Specifically, to show Theorem 7.3, one first shows that the eigenvalues of  $\tilde{H}_{-}$  are encoded in the poles of  $R(z, \tilde{H})$ . Moreover, projecting  $R(z, \tilde{H})$  onto the low energy space of H preserves these poles, i.e. the poles of  $R(z, H)_{-}$ also encode the eigenvalues of H. But now we are in good shape, since the self-energy  $\Sigma_{-}(z)$  is defined directly in terms of  $R(z,H)_{-}$ ; it can thus be shown that the poles of  $R(z, \tilde{H})_{-}$  are related to the eigenvalues of  $\Sigma_{-}(z)$ . Finally, since  $\Sigma_{-}(z)$  is "close" to  $H_{\text{eff}}$  by assumption in Theorem 7.3, the claim follows by applying a (special case of) Weyl's inequalities relating the distance between two operators in spectral norm to distances between their respective eigenvalues. This completes the proof sketch.

Question 17. Apply Theorem 7.3 with  $c = -\|H_{\text{eff}}\|_{\infty}$ ,  $d = \|H_{\text{eff}}\|_{\infty}$ ,  $\lambda_* = \Delta/2$  to complete the proof of correctness for the reduction.

# <span id="page-91-0"></span>7.3 Commuting k-local Hamiltonians and the Structure Lemma

A natural case of the k-local Hamiltonian problem whose complexity remains open (for arbitrary k and local dimension d) is that of commuting local Hamiltonians, i.e. where the local constraints pairwise commute. This class of Hamiltonians is particularly interesting, in that it intuitively seems "closer" to the classical world of constraint satisfaction (in which all constraints are diagonal in the computational basis and hence commute), and yet such Hamiltonians are nevertheless rich enough to give rise to highly entangled ground states, such as the toric code Hamiltonian [105]. The main complexity theoretic question in this

area is to characterize the complexity of the problem for various values of *k* and *d*: Is it in NP? QCMA (i.e. QMA with a classical prover)? Or could it be QMA-complete?

To date, it is known that the commuting cases of 2-local Hamiltonian for *d* ≥ 2 [\[45\]](#page-116-4), 3-local Hamiltonian with *d* = 2 (as well as *d* = 3 with a "nearly Euclidean" interaction graph) [\[13\]](#page-114-3), and 4-local Hamiltonian with *d* = 2 on a square lattice are in NP [\[144\]](#page-123-3). At the heart of these results is Bravyi and Vyalyi's *Structure Lemma* [\[45\]](#page-116-4), which is a powerful tool for dissecting the structure of commuting local Hamiltonians. The primary focus of this section is to prove and discuss this lemma.

We remark that often the commuting k-LH problem is phrased with each local term being an orthogonal projection; this is without loss of generality, as since all terms simultaneously diagonalize, the ground state lies completely in some eigenspace of each constraint.

## **7.3.1 Statement of the Structure Lemma**

Intuitively, the Structure Lemma says the following. Suppose we have two Hermitian operators *A* ∈ H (X ⊗ Y) and *B* ∈ H (Y ⊗ Z) for complex Euclidean spaces X *,* Y*,* Z, such that *A* and *B* commute. Then, the space Y can be sliced up in such a way, that if we focus on just one slice Y*<sup>i</sup>* of the space (which is claimed by the NP prover to contain the ground state), then in this subspace *A* and *B* are completed *decoupled*. Specifically, the lemma says we can write Y = L *<sup>i</sup>* Y*<sup>i</sup>* , such that if we restrict *A* and *B* to any one space Y*<sup>i</sup>* , the resulting operators can be seen to act on disjoint parts of the space Y*<sup>i</sup>* , hence eliminating their overlap. We now state the lemma more formally.

<span id="page-92-0"></span>**Lemma 7.4** (Structure Lemma [\[45\]](#page-116-4))**.** Suppose *A* ∈ H (X ⊗ Y) and *B* ∈ H (Y ⊗ Z) for complex Euclidean spaces X *,* Y*,* Z, and such that [*A, B*] = 0. Then, one can write Y = L *<sup>i</sup>* Y*<sup>i</sup>* , such that for any *i*, the following two properties hold:

- 1. *A* and *B* act invariantly on Y*<sup>i</sup>* , and
- 2. Y*<sup>i</sup>* = Y*i*<sup>1</sup> ⊗ Y*i*<sup>2</sup> for some Hilbert spaces Y*i*<sup>1</sup> and Y*i*2, such that *A*|Y*<sup>i</sup>* ∈ H (X ⊗ Y*i*1) and *B*|Y*<sup>i</sup>* ∈ H (Y*i*<sup>2</sup> ⊗ Z). In other words,

within the subspace Y*<sup>i</sup>* , *A* and *B* act non-trivially only on Y*i*<sup>1</sup> and Y*i*2, respectively.

The strength of the Structure Lemma in proofs placing variants of commuting Hamiltonian in NP is as follows. First, note that by property 1 above, when looking for the joint ground state |*ψ*i of *A* and *B*, we can safely restrict our attention to one appropriately chosen slice *i*. But which slice *i* does |*ψ*i live in? This is not obvious *a priori*; hence, we ask the NP prover to send us the correct choice of *i*. Then, by restricting *A* and *B* to space Y*<sup>i</sup>* , by property 2 above the resulting Hamiltonians are decoupled. We can hence now easily diagonalize this system and determine the ground state energy, thus confirming whether it is indeed zero or bounded away from zero. Applying this idea repeatedly allows one to place the commuting 2-local Hamiltonian problem in NP.

#### **7.3.2 Proof of the Structure Lemma**

In this section, we prove the Structure Lemma. The proof cleverly uses basic *C* <sup>∗</sup> algebraic techniques. We remark that readers unfamiliar with *C* <sup>∗</sup> algebras should not be put off; the Structure Lemma is a powerful tool worth understanding, and to be clear, once the terminology barrier of the *C* ∗ formalism is overcome, the underlying proof is rather intuitive and simple. For this reason, we begin by defining the basic terminology required for the proof.

**Algebra:** Let *A* be a vector space over C. Then *A* is an algebra if it is endowed with a bilinear operation · : *A*×*A* 7→ *A*. In our setting, *A* will be some subset of linear operators taking C *k* to itself, and · is simply matrix multiplication. A Banach algebra is an associative algebra over the real or complex numbers which is also normed and complete, i.e. is a Banach space.

**C\* Algebra:** To get a *C* <sup>∗</sup> algebra, we start with a Banach algebra *A* over C, and add a ∗-operation which has the following properties:

- 1. For all *x* ∈ *A*, *x* = (*x* ∗ ) <sup>∗</sup> = *x* ∗∗ .
- 2. For all *x, y* ∈ *A*, (*xy*) <sup>∗</sup> = *y* ∗*x* <sup>∗</sup> and (*x* + *y*) <sup>∗</sup> = *x* <sup>∗</sup> + *y* ∗ .

- 3. For all *c* ∈ C and *x* ∈ *A*, (*cx*) <sup>∗</sup> = *cx*<sup>∗</sup> .
- 4. For all *x* ∈ *A*, k *xx*<sup>∗</sup> k = k *x* k 2 .

In our setting, the ∗-operation is simply the conjugate transpose of a matrix.

**Commutant:** Let *S* ⊆ L C *k* . Then, the commutant of *S* is defined as

$$S' := \left\{ x \in \mathcal{L}\left(\mathbb{C}^k\right) : xs = sx \text{ for all } s \in S \right\}.$$

A few facts about commutants come in handy: *S* 0 is a *C* <sup>∗</sup> algebra, *S* ⊆ *S* <sup>00</sup> (known as the closure of *S*), and *S* 000 = *S* 0 . Further, the following holds.

<span id="page-94-0"></span>**Lemma 7.5.** Let *A, B* ⊆ L C *k* , and suppose for all *a* ∈ *A* and *b* ∈ *B*, we have *ab* = *ba*. Then, for all *a* ∈ *A* <sup>00</sup> and *b* ∈ *B* <sup>00</sup>, we have *ab* = *ba*.

*Proof.* Observe that *B* ⊆ *A* 0 . Thus, the elements in *A* <sup>00</sup> pair-wise commute with all elements of *B*, as well as those in *A* 0 \*B*. This implies *A* <sup>00</sup> ⊆ *B* 0 . But the elements of *B* <sup>00</sup> pairwise commute with those of *B* 0 , which in turn implies they commute with the elements of *A* 00 .

**Center:** The center of algebra *A* is the set of all elements in *A* which commute with everyone else in *A*, i.e. *C*(*A*) := *A* ∩ *A*<sup>0</sup> (recall *A*<sup>0</sup> is the commutant of *A*). A *trivial* center is one which satisfies *C*(*A*) = {*cI* | *c* ∈ C}.

A simple application of the definition of the center yields some very useful well-known properties for all *x* ∈ *A*, as stated in the following lemma.

**Lemma 7.6.** Let *A* be a *C* <sup>∗</sup> algebra such that *A* ⊆ L(X ) for complex Euclidean space X . Suppose there exists *M* ∈ *C*(*A*) with diagonalization *M* = P *<sup>i</sup> λi*Π*<sup>i</sup>* , where *λ* ∈ R and Π*<sup>i</sup>* are (not necessarily one-dimensional) orthogonal projections. Then, any *N* ∈ *A* has a block diagonal structure with respect to basis {Π*i*}, i.e. can be written

$$N = \bigoplus_{i} N_{i}$$

where *N<sup>i</sup>* is an operator acting on the space Π*<sup>i</sup>* projects onto. *Proof.* We claim that it is true that for all i,  $\Pi_i \in C(A)$ ; assuming this is true, the statement of the lemma holds simply because any  $N \in A$  must now commute with each  $\Pi_i$ . To thus see that  $\Pi_i \in C(A)$ , note that if  $M \in C(A)$ , then for any polynomial p,  $p(M) \in C(A)$ . Then, defining for all j a polynomial  $p_j$  such that  $p_j(\lambda_i) = \delta_{ij}$  completes the proof.

<span id="page-95-1"></span>**Corollary 7.7.** If  $C^*$  algebra  $A \subseteq \mathcal{L}(\mathcal{X})$  has a non-trivial center, then there exists a direct sum decomposition  $\mathcal{X} = \bigoplus_i \mathcal{X}_i$  such that any  $M \in A$  acts invariantly on each subspace  $\mathcal{X}_i$ .

**Proof of Structure Lemma.** We can now proceed with the proof of the Structure Lemma (Lemma 7.4). As in the statement of the claim, let  $A \in \mathcal{H}(\mathcal{X} \otimes \mathcal{Y})$  and  $B \in \mathcal{H}(\mathcal{Y} \otimes \mathcal{Z})$  such that [A, B] = 0. For an appropriate choice of operators  $\{A_{ij}\}, \{B_{kl}\} \subseteq \mathcal{L}(\mathcal{Y})$ , one can write

<span id="page-95-0"></span>
$$A = \sum_{ij} |i\rangle\langle j|_{\mathcal{X}} \otimes (A_{ij})_{\mathcal{Y}} \otimes I_{\mathcal{Z}}$$
 (7.24)

$$B = \sum_{kl} I_{\mathcal{X}} \otimes (B_{kl})_{\mathcal{Y}} \otimes |k\rangle\langle l|_{\mathcal{Z}}. \tag{7.25}$$

**Question 18.** Use Equations 7.24 and 7.25 and the fact that [A, B] = 0 to conclude that for all i, j, k, l, we have  $[A_{ij}, B_{kl}] = 0$ .

Consider now algebras  $\widetilde{A}$  and  $\widetilde{B}$  generated by  $\{A_{ij}\}$  and  $\{B_{kl}\}$ , respectively, i.e.  $\widetilde{A} = \{A_{ij}\}^{"}$  and  $\widetilde{B} = \{B_{kl}\}^{"}$ , whose elements pairwise commute by Lemma 7.5. Focusing first on  $\widetilde{A}$ , assume that  $\widetilde{A}$  has nontrivial center. We reduce this case to one with trivial center, which can then be solved directly. Specifically, by Corollary 7.7, we can first decompose  $\mathcal{Y} = \bigoplus_i \mathcal{Y}_i$  such that  $\widetilde{A}$  acts invariantly on each  $\mathcal{Y}_i$ . In order to decouple A and B, recall that our goal is to split  $\mathcal{Y}_i = \mathcal{Y}_{i1} \otimes \mathcal{Y}_{i2}$  such that A and B act non-trivially only on  $\mathcal{Y}_{i1}$  and  $\mathcal{Y}_{i2}$ , respectively. To this end, let  $\widetilde{A}_i$  denote  $\widetilde{A}$  restricted to space  $\mathcal{Y}_i$ , and assume without loss of generality that the subalgebra  $\widetilde{A}_i$  has trivial center (otherwise, we can decompose the space further). We now apply the following lemma, which is a standard result in the representation theory of  $C^*$  algebras.

**Lemma 7.8** ([107, 45]). Let  $A \subseteq \mathcal{L}(\mathcal{Y})$  be a  $C^*$  algebra with trivial center. Then one can decompose  $\mathcal{Y} = \mathcal{Y}_1 \otimes \mathcal{Y}_2$  such that  $A = \mathcal{L}(\mathcal{Y}_1) \otimes I_{\mathcal{Y}_2}$ .

We hence obtain a decomposition  $\mathcal{Y}_i = \mathcal{Y}_{i1} \otimes \mathcal{Y}_{i2}$  such that  $\widetilde{A}_i$  acts non-trivially only on  $\mathcal{Y}_{i1}$ . In sum, we have thus far shown the following.

<span id="page-96-1"></span>**Observation 7.9.** The algebra  $\widetilde{A}$  is precisely the set of all operators  $W \in \mathcal{L}(\mathcal{Y})$  which can be written as  $W = \bigoplus_i (W_i)_{\mathcal{Y}_i} = \bigoplus_i (W_i)_{\mathcal{Y}_{i1}} \otimes I_{\mathcal{Y}_{i2}}$ .

We now use Observation 7.9 to uncover the structure of  $\widetilde{B}$ .

<span id="page-96-2"></span>**Question 19.** For any  $V \in \widetilde{B}$  and  $\mathcal{Y}_i$  in the decomposition of  $\mathcal{Y}$  above, show that V acts invariantly on  $\mathcal{Y}_i$ . Conclude that V can also be written as a direct sum over spaces  $\mathcal{Y}_i$ , i.e. that  $V = \bigoplus_i (V_i)_{\mathcal{Y}_i}$ . (Hint: Use the fact that all operators in  $\widetilde{A}$  and  $\widetilde{B}$  pairwise commute, and Observation 7.9.)

Having answered Question 19, we can now let  $\widetilde{B}_i$  denote  $\widetilde{B}$  restricted to space  $\mathcal{Y}_i$ . The answer to the following question completes the proof.

**Question 20.** Prove that any  $V \in \widetilde{B}_i$  has the form  $V = I_{\mathcal{Y}_{i1}} \otimes (V_i)_{\mathcal{Y}_{i2}}$ . (Hint: Use the fact that all operators in  $\widetilde{A}$  and  $\widetilde{B}$  pairwise commute, and Observation 7.9.)

#### <span id="page-96-0"></span>7.4 Quantum 2-SAT is in P

In this section, we discuss Bravyi's polynomial time algorithm [38] for the Quantum 2-SAT problem. To begin, recall that in k-SATISFIABILITY (k-SAT), one is given as input a set of k-local constraints  $\{\Pi_i\}$  acting on subsets of k binary variables out of a total of n variables  $x_1, \ldots, x_n$ . Each clause has the form

$$\Pi_i = x_{i,1} \vee \cdots \vee x_{i,k},$$

where each  $x_{i,j}$  is a *literal* corresponding to either a variable or its negation. The question is whether there exists an assignment to the variables  $x_1, \ldots, x_n$  such that all  $\Pi_i$  evaluate to 1.

The study of *k*-SAT has a long and rich history, which we shall not attempt to survey here. However, as is well-known, SAT is historically the first problem to be proven NP-complete [\[53,](#page-117-0) [111\]](#page-121-0). Further, its restricted version *k*-SAT remains NP-complete for *k* ≥ 3 [\[99\]](#page-120-13), but is polynomial-time solvable for *k* = 2 [\[109,](#page-121-14) [62,](#page-117-12) [25\]](#page-115-13). This raises the natural question: Can one define an appropriate quantum generalization of *k*-SAT, and could this generalization also lie in P when *k* = 2?

In 2006, Bravyi answered both these questions in the affirmative [\[38\]](#page-116-0). Here, we define Quantum *k*-SAT as follows.

**Definition 7.1** (Quantum 2-SAT (2-QSAT) [\[38\]](#page-116-0))**.** Given a set of 2-local orthogonal projections {Π*ij* | 1 ≤ *i, j,* ≤ *n*} acting on *n* qubits, does there exist a satisfying quantum assignment, i.e. does there exist a state |*ψ*i ∈ (C 2 ) ⊗*n* such that Π*ij* |*ψ*i = 0 for all 1 ≤ *i, j,* ≤ *n*?

Note that unlike in SAT, which would correspond to rank 1 projections Π*ij* , here the projections are allowed to be arbitrary rank. Thus, Bravyi's definition is more accurately a generalization of 2-CSP, where arbitrary Boolean 2-local constraints are allowed.

#### **7.4.1 The algorithm**

We now discuss Bravyi's algorithm for 2-QSAT. We remark that Bravyi's original exposition involved heavy use of tensors, which are perhaps not a typical tool in the computer scientist's toolkit. In contrast, we give a different description of the algorithm in terms of *local filters* [\[76\]](#page-118-12) from entanglement theory, which, in our opinion, is arguably more accessible to the quantum computing community.

To begin, Bravyi's algorithm consists of three subroutines (defined subsequently), and can be described at a high level as follows.

- 1. While there exists a constraint Π*ij* of rank at least 2, run *rankReduction*(Π*ij* ). If the call fails, reject.
- 2. Run *generateConstraints*. If the call succeeds, return to Step 1.
- 3. Accept and return the output of *solveSaturatedSystem*.

Roughly, *rankReduction* outputs a 2-QSAT instance (on a possibly smaller number of qubits) in which all constraints are rank 1. Once all constraints are rank 1, *generateConstraints* attempts to add "new" constraints which are already implicit in the present constraint system in an attempt to "saturate" the system. If the call succeeds, we return to Step 1 to try to once again simplify the system. If, on the other hand, *generateConstraints* fails, then we have arrived at a "saturated" system of constraints [\[38\]](#page-116-0). At this point, we conclude the system is satisfiable; indeed, *solveSaturatedSystem* outputs a satisfying assignment. We shall shortly discuss each of these three procedures in greater detail.

Before doing so, however, let us compare Bravyi's algorithm with known classical algorithms for 2-SAT. In particular, Bravyi's algorithm can be thought of as a quantum generalization of Krom's 1967 algorithm [\[109\]](#page-121-14), which we briefly sketch now. Specifically, one first runs a classical version of *generateConstraints* repeatedly, which acts as follows: Given a pair of clauses overlapping on a bit with conflicting literals, say (*x*<sup>1</sup> ∨*x*2) and (*x*<sup>2</sup> ∨*x*3), it produces a new redundant clause (*x*1∨*x*3). If we are able to generate a pair of conflicting clauses (*xi*∨*xi*) and (*x<sup>i</sup>* ∨ *xi*) for some *i* (checking for this can be seen as a classical version of *rankReduction*), we conclude the instance is unsatisfiable. Otherwise, as in Step 3 of Bravyi's algorithm, we conclude the instance is "saturated" and hence satisfiable, and we run a classical version of *solveSaturatedSystem*, which extracts the satisfying assignment. We now discuss the components of Bravyi's algorithm in further depth.

*rankReduction*(Π*ij* )**.** Given a constraint Π*ij* of rank at least 2, act as follows:

- If rank(Π*ij* ) = 4, return *fail*, as no assignment could satisfy this clause. This is analogous to checking in Krom's algorithm whether conflicting clauses (*x<sup>i</sup>* ∨ *xi*) and (*x<sup>i</sup>* ∨ *xi*) have been generated.
- If rank(Π*ij* ) = 3, the assignment to qubits *i* and *j* is forced to be *I* − Π*ij* . Set this as their assignment and remove them from the system, updating any 2-local clauses acting on *i* or *j* as necessary.
- If rank(Π*ij* ) = 2, qubits *i* and *j* are allowed to live in a 2-

dimensional subspace. Hence, combine i and j into a single merged qubit via an appropriate isometry. Update clauses acting on i or j as necessary.

generateConstraints. We now give Bravyi's quantum generalization of Krom's iterative procedure for generating new redundant constraints from existing ones. Specifically, this subroutine examines all triples of qubits  $\{a, b, c\}$  on which there exist clauses  $\Pi_{ab} = |\phi\rangle\langle\phi|_{ab}$  and  $\Pi_{bc} = |\phi\rangle\langle\phi|_{bc}$ , and attempts to generate a new clause  $\Pi_{ac}$ .

To motivate the idea [38], suppose  $|\phi\rangle_{ab} = |\phi\rangle_{bc} = |\psi^-\rangle$ , for  $|\psi^-\rangle = |01\rangle - |10\rangle$  the singlet (we omit normalization for simplicity). Then, since for two qubits  $I - |\psi^-\rangle\langle\psi^-|$  projects onto the symmetric space, it follows that any assignment  $|\psi\rangle$  must live in the symmetric space on qubits  $\{a,b\}$  and  $\{b,c\}$ , and hence also on  $\{a,c\}$ . Thus, we can safely add the new (implicit) constraint  $\Pi_{ac} = |\phi\rangle\langle\phi|_{ac}$ .

Now, what if (say)  $|\phi\rangle_{ab}$  is not the singlet? Here, we use the fact that any pure state on two qubits can be produced from the singlet via a local filter [76]. Specifically, there exist linear operators  $A, C \in \mathcal{L}(\mathbb{C}^2)$  such that

<span id="page-99-0"></span>
$$|\phi\rangle_{ab} = A_a \otimes I_b |\psi^-\rangle_{ab}$$
 and  $|\phi\rangle_{bc} = I_b \otimes C_c |\psi^-\rangle_{bc}$ . (7.26)

Note that while local filters were originally introduced to *increase* the entanglement of a previously entangled state [76] (in which case the filter must be invertible, as otherwise one can create entanglement via a local operation from a product state), in this setting, we are *reducing* entanglement using a filter; thus, A and C in general will not be invertible. The following is our analogue of Lemma 1 in Reference [38].

<span id="page-99-1"></span>**Lemma 7.10.** For  $|\phi\rangle_{ab}$  and  $|\phi\rangle_{bc}$  as in Equation 7.26, suppose  $|\psi\rangle \in (\mathbb{C}^2)^{\otimes n}$  satisfies  $\langle \psi | \phi_{ab} \rangle = \langle \psi | \phi_{bc} \rangle = 0$ . Then, the constraint  $|\phi\rangle_{ac} = A_a \otimes C_c |\psi^-\rangle$  on  $\{a, c\}$  satisfies  $\langle \psi | \phi_{ac} \rangle = 0$ .

*Proof.* Suppose for assignment  $|\psi\rangle \in (\mathbb{C}^2)^{\otimes n}$  that

$$\langle \psi | \phi_{ab} \rangle = \langle \psi | A_a \otimes I_b | \psi^- \rangle_{ab} = 0.$$

This implies that  $A_a^{\dagger} \otimes I_b | \psi \rangle$  lives in the symmetric subspace on qubits a and b. An analogous argument implies that  $I_b \otimes C_c^{\dagger} | \psi \rangle$  lives in the

symmetric subspace on *b* and *c*. It follows that *A*† *<sup>a</sup>* ⊗ *C* † *c* |*ψ*i lives in the symmetric subspace of both {*a, b*} and {*b, c*}, and hence also of {*a, c*}. Thus, h*ψ*|*φac*i = h*ψ*|*A<sup>a</sup>* ⊗ *Cc*|*ψ* <sup>−</sup>i = 0, as desired.

*Remark.* For the reader interested in comparing Lemma [7.10](#page-99-1) above directly with Lemma 1 of Reference [\[38\]](#page-116-0), the correspondence is given by *A* = *φ*† and *C* = *θ T* . This is easily seen by using the vec mapping [\[164\]](#page-125-14) (where roughly, vec "reshuffles" matrices into vectors) and its property that *A* ⊗ *B* vec(*X*) = vec(*AXB<sup>T</sup>* ).

In sum, *generateConstraints* applies Lemma [7.10](#page-99-1) on triples of qubits until it generates a new clause on some pair of qubits {*a, c*} which is linearly independent from existing clauses on {*a, c*}. If no such clause is found, the subroutine returns *fail*.

*solveSaturatedSystem***.** A *saturated* system of constraints is one in which (1) all constraints are rank 1, and (2) for any triple of qubits {*a, b, c*}, Lemma [7.10](#page-99-1) fails to produce a new linearly independent constraint on {*a, c*}. We now give our analogue of Lemma 2 of Reference [\[38\]](#page-116-0), which is in turn a quantum analogue of Krom's classical procedure for extracting a satisfying assignment from a "saturated" classical 2-SAT system.

<span id="page-100-0"></span>**Lemma 7.11.** For any saturated system of constraints {Π*ij*}, there exists an efficiently computable product state |*ψ*i = N*<sup>n</sup> <sup>i</sup>*=1 |*ψi*i with |*ψi*i ∈ C 2 such that Π*ij* |*ψ*i = 0 for all *i, j*.

In order to prove Lemma [7.11,](#page-100-0) we first require the following.

<span id="page-100-1"></span>**Lemma 7.12.** Let *E* := *iY* for Pauli operator *Y* . Then, for any *A* ∈ L C 2 ,

$$A \otimes I|\psi^{-}\rangle = I \otimes E^{\dagger}A^{T}E|\psi^{-}\rangle.$$

*Proof.* Let |*φ* <sup>+</sup>i = (|00i + |11i)*/* √ 2. Then,

$$A \otimes I | \psi^{-} \rangle = (I \otimes E^{\dagger}) (A \otimes E) | \psi^{-} \rangle$$
$$= (I \otimes E^{\dagger}) (I \otimes A^{T}) | \phi^{+} \rangle$$
$$= I \otimes E^{\dagger} A^{T} E | \psi^{-} \rangle,$$

where the first equality follows since *E*†*E* = *I*, the second since *I* ⊗ *E*|*ψ* <sup>−</sup>i = |*φ* <sup>+</sup>i and *A* ⊗ *I*|*φ* <sup>+</sup>i = *I* ⊗ *A<sup>T</sup>* |*φ* <sup>+</sup>i, and the third again since *I* ⊗ *E*|*ψ* <sup>−</sup>i = |*φ* <sup>+</sup>i.

*Proof of Lemma [7.11.](#page-100-0)* We give a simple deterministic polynomial time algorithm which outputs |*ψ*i. Pick an arbitrary qubit, *q*1, and set its assignment to |0i, i.e. set |*ψ*1i = |0i. Now consider the neighbor set of *q*1, denoted *N*(*q*1). For any *q<sup>i</sup>* ∈ *N*(*q*1), suppose the forbidden space is spanned by |*φ*1*,i*i. Then, observing that |*φi*i := h*ψ*1|*φ*1*,i*i ∈ C <sup>2</sup> and that h*v*|*E*|*v*i = 0 for any |*v*i ∈ C <sup>2</sup> and where |*v*i denotes the entry-wise complex conjugate of |*v*i, it follows that h*φ*1*,i*|(|*ψ*1i ⊗ *E*|*φi*i) = 0. Thus, setting |*ψi*i = *E*|*φi*i satisfies all clauses between *q*<sup>1</sup> and its neighbors. Moreover, by Lemma [7.10,](#page-99-1) we have that any clause between distinct qubits *q<sup>i</sup> , q<sup>j</sup>* ∈ *N*(*q*1) is also satisfied by this assignment.

Let *S* denote the set of qubits whose shortest path from *q*<sup>1</sup> is precisely 2 in the interaction graph, i.e. *S* = *N*(*N*(*q*1))\(*N*(*q*1) ∪ {*q*1}). If we can now show that for all *q<sup>i</sup>* ∈ *N*(*q*1) and *q<sup>j</sup>* ∈ *S*, the clause |*φi,j* i is satisfied by the current assignment regardless of the assignment on *q<sup>j</sup>* , then note that the proof is complete, as we can simply iterate the argument above by discarding all clauses which act on qubits in {*q*<sup>1</sup> ∪ *N*(*q*1)} and choosing a new starting vertex *q<sup>j</sup>* ∈ *S*.

Thus, we now prove that for all *q<sup>i</sup>* ∈ *N*(*q*1) and *q<sup>j</sup>* ∈ *S*, h*φi,j* |*ψi*i = 0. Let the clauses on (1*, i*) and (*i, j*) be given by

$$|\phi_{1,i}\rangle = A_1 \otimes I_i |\psi^-\rangle$$
 and  $|\phi_{i,j}\rangle = I_i \otimes C_j |\psi^-\rangle$ .

Then, analogous to Reference [\[38\]](#page-116-0), the key observation is that since (1*, j*) is not an edge, then by Lemma [7.10,](#page-99-1) we must have *A*⊗*C*|*ψ* <sup>−</sup>i = 0. This, along with Lemma [7.12,](#page-100-1) together imply:

$$\langle \phi_{i,j} | \psi_i \rangle = (\langle \psi^- | I_i \otimes C_j^{\dagger}) ((\overline{\langle \psi_1 |} \otimes E_i) \overline{| \phi_{1,i} \rangle})$$

$$= (\langle \psi^- | I_i \otimes C_j^{\dagger}) ((\overline{\langle \psi_1 |} \otimes E_i) (\overline{A}_1 \otimes I_i | \psi^- \rangle))$$

$$= (\langle \psi^- | I_i \otimes C_j^{\dagger}) ((\overline{\langle \psi_1 |} \otimes E_i) (I_1 \otimes E_i^{\dagger} A_i^{\dagger} E_i | \psi^- \rangle))$$

$$= (\langle \psi^- | A_i^{\dagger} \otimes C_j^{\dagger}) (\overline{\langle \psi_1 |} \otimes E_i) | \psi^- \rangle$$

$$= 0.$$

## <span id="page-102-0"></span>**7.5 Area laws for one-dimensional gapped quantum systems**

In this section, we review Arad, Kitaev, Landau and Vazirani's combinatorial proof [\[20,](#page-114-10) [19\]](#page-114-8) of Hastings' [\[88\]](#page-119-0) 1D area law for gapped systems. Specifically, we consider a 1D chain of *n* quantum systems governed by a gapped local Hamiltonian *H*. By *gapped*, we mean that the difference between the smallest and second-smallest eigenvalues of *H* is lower bounded by a constant  *>* 0, and that the ground state is unique.

Let us begin by clarifying the statement regarding *H* to be proven. First, note that the statement of an area law is simple in the 1D case, since by definition the surface area of any contiguous region in a 1D system must be constant (i.e. either 1 or 2). It follows that proving an area law for 1D systems is equivalent to proving that for any 1 ≤ *i* ≤ *n*, the entanglement entropy of the ground state between particles 1*, . . . , i* and particles *i* + 1*, . . . , n* is bounded above by a constant. Here, the entanglement entropy is defined as the von Neumann entropy of the reduced density matrix on particles 1*, . . . , i*. Without loss of generality, it suffices to fix an arbitrary cut and prove the statement there; let *C* denote this cut.

**High-level overview.** Conceptually, the proof consists of two steps. First, it is shown that there exists a product state with respect to cut *C* which has reasonably good, i.e. constant, overlap with the ground state of *H*. Second, we show how one can "transform" such a product state to a much better approximation of the ground state *without* increasing the entanglement entropy across *C* too much. (Recall that our goal is to prove that in the ground state, the entanglement entropy across cut *C* is constant.) In the proof of [\[20,](#page-114-10) [19\]](#page-114-8), both of these steps depend crucially on a theoretical construct called an *Approximate Ground-Space Projection (AGSP)*, and the bulk of the work goes into the construction of an AGSP with sufficiently good parameters. In contrast, we remark that Hastings' original proof [\[88\]](#page-119-0) also follows the broad outline of the above two steps, but realizes them using different physics-inspired techniques such as the Lieb-Robinson bound or "monogamy of entanglement"-type arguments.

For simplicity, in this review we focus on the simpler case of frustration-free Hamiltonians. Readers interested in the proof of the frustrated case are referred to §6 of [\[19\]](#page-114-8).

**Organization.** In [§7.5.1,](#page-103-0) we first define an AGSP. Then, we show that if a good AGSP and product state with non-trivial overlap onto the ground state of *H* exist, then an area law holds (Lemma [7.13\)](#page-104-0). In [§7.5.2,](#page-106-0) we show that the existence of a good AGSP already implies a good product state (Lemma [7.14\)](#page-106-1). Finally, [§7.5.3](#page-107-0) constructs a good AGSP.

#### <span id="page-103-0"></span>**7.5.1 Approximate Ground-Space Projection (AGSP)**

We now motivate and define an AGSP. Specifically, returning to the second step of the high-level proof overview discussed above, we ask: Given a product state |*ψ*prodi with non-trivial overlap with the ground state of *H*, how can we map |*ψ*prodi to a good approximation of the ground state? One obvious idea is to apply to |*ψ*prodi the projection onto the ground space, thus obtaining a scaled-down version of the ground state. Unfortunately, this approach does not give us a way to bound the amount of entanglement generated across cut *C* when the projection is applied. The main idea behind an AGSP is to only *approximately* project onto the ground space; in return, we obtain a rigorous bound on how the entanglement grows with each application of the AGSP.

<span id="page-103-1"></span>**Definition 7.2.** An operator *K* is said to be a (*D,* ∆)-AGSP if the following conditions hold:

- 1. **Ground space invariance:** For any ground state |Γi*, K*|Γi = |Γi.
- 2. **Shrinking:** If |Γ <sup>⊥</sup>i is any state orthogonal to the ground space, then *K*|Γ <sup>⊥</sup>i is also orthogonal to the ground space, and moreover ||*K*|Γ <sup>⊥</sup>i||<sup>2</sup> ≤ ∆.
- 3. **Entanglement:** The Schmidt rank of *K* across the given cut is at most *D*. Note that the Schmidt rank of an operator *A* is

defined as the smallest integer *m* such that *A* can be written in the form *A* = P <sup>1</sup>≤*i*≤*<sup>m</sup> L<sup>i</sup>* ⊗ *R<sup>i</sup>* .

In other words, if there exists an AGSP with good parameters, i.e. small *D* and ∆, we can repeatedly apply it to |*ψ*prodi until we obtain a good approximation to the ground state. Note that although the action of an AGSP will converge to that of the exact ground state projection as the number of iterations goes to infinity, a *finite* number of iterations reveals a delicate tradeoff between proximity to the ground state and a bound on the entanglement entropy.

**Using an AGSP with a good product state.** The high-level lemma which stitches together the various parts of the proof is the following. In words, it says that the existence of a good AGSP and a good product state suffices to establish an area law.

<span id="page-104-0"></span>**Lemma 7.13** (Arad, Landau, and Vazirani [\[20\]](#page-114-10))**.** Let |Γi be the ground state of *H* and |*φ*i a product state such that |h*φ*|Γi| = *µ*. Then, the existence of a (*D,* ∆)-AGSP *K* implies that the entanglement entropy *S* of |Γi is bounded by

$$S \le O(1) \cdot \frac{\log \mu^2}{\log \Delta} \log D.$$

*Proof.* Let |Γi = P *<sup>i</sup> λ<sup>i</sup>* |*Li*i ⊗ |*Ri*i be the Schmidt decomposition of the ground state |Γi, where the Schmidt coefficients *λ<sup>i</sup>* are in decreasing order. Then, the entanglement entropy is defined as − P *i λ* 2 *i* log *λ* 2 *i* . To bound this quantity, we consider the family of states *K`* |*φ*i. By Definition [7.2,](#page-103-1) we know that these states satisfy the following two properties:

- 1. The Schmidt rank of *K`* |*φ*i is at most *D`* .
- 2. The inner product between *K`* |*φ*i and |Γi is at least *µ/*<sup>q</sup> *µ*<sup>2</sup> + ∆*`*(1 − *µ*2).

We now use these facts to bound the entropy in two steps. We show the first of these steps, and guide the reader through the second step via a sequence of questions. Our starting point is the Eckart-Young theorem [\[60\]](#page-117-13), which implies that the magnitude of the inner product between  $|\Gamma\rangle$  and any normalized state with Schmidt rank r is upper-bounded by the Euclidean norm of the vector of the first r Schmidt coefficients, i.e. by  $(\sum_{i=1}^r \lambda_i^2)^{1/2}$ . Therefore,

$$\sum_{i < D^\ell} \lambda_i^2 \geq \frac{\mu^2}{\mu^2 + \Delta^\ell (1 - \mu^2)} \geq \frac{\mu^2}{\mu^2 + \Delta^\ell},$$

where the first inequality follows from the Eckart-Young theorem and point 2 above. This implies that

$$\sum_{i > D^{\ell}} \lambda_i^2 \le 1 - \frac{\mu^2}{\mu^2 + \Delta^{\ell}} = \frac{\Delta^{\ell}}{\mu^2 + \Delta^{\ell}} \le \frac{\Delta^{\ell}}{\mu^2} =: p_{\ell}.$$

If we now choose  $\ell_0 = \lceil \frac{\log \mu^2}{\log \Delta} \rceil$  so that  $p_{\ell_0} < 1$ , it follows that the contribution of entropy from the first  $D^{4\ell_0}$  Schmidt coefficients is at most

$$-\sum_{i \le D^{4\ell_0}} \lambda_i^2 \log \lambda_i^2 \le \log D^{4\ell_0} = 4\ell_0 \log D = O(1) \cdot \frac{\log \mu^2}{\log \Delta} \log D,$$

where the first inequality follows since the entropy of a (sub)normalized d-dimensional vector is at most  $\log d$ .

The next step is to bound the contribution to the entropy of the remaining Schmidt coefficients, which the following two questions guide the reader through.

<span id="page-105-0"></span>Question 21. Show that if  $\ell > \ell_0$ , the contribution of entropy from the  $(D^{2\ell}+1)$ -th to  $D^{2(\ell+1)}$ -th Schmidt coefficients is at most  $\Delta^{\ell-\ell_0}(\ell-\ell_0)\log\frac{D^{2(\ell+1)/(\ell-\ell_0)}}{\Delta}$ .

**Hint 6.** Use the fact that  $\sum_{i=D^{2\ell+1}}^{D^{2(\ell+1)}} \lambda_i^2 \leq p_{2\ell} \leq p_\ell$ .

**Question 22.** Using the answer to Question 21, show that

$$-\sum_{i>D^{4\ell_0}} \lambda_i^2 \log \lambda_i^2 \le \frac{\Delta}{(1-\Delta)^2} \log \frac{D^6}{\Delta}.$$

**Hint 7.** Use the series equality  $\sum_{j\geq 1} jr^j = \frac{r}{(1-r)^2}$ .

Combining the two bounds we have derived, it follows that the entanglement entropy of the ground state satisfies

$$S \le O(1) \cdot \frac{\log \mu^2}{\log \Delta} \log D + \frac{\Delta}{(1 - \Delta)^2} \log \frac{D^6}{\Delta}.$$

Finally, note that for any  $k \geq 1$ ,  $K^k$  is a  $(D^k, \Delta^k)$ -AGSP. Moreover, if we choose  $k = \lceil -\frac{1}{\log \Delta} \rceil$ , we can ensure that  $\frac{1}{4} \leq \Delta^k \leq \frac{1}{2}$ . Substituting  $D^k$  for D and  $\Delta^k$  for  $\Delta$ , we obtain

$$S \le O(1) \cdot k \cdot (-\log \mu^2 \log D + \log D - 1) \le O(1) \cdot \frac{\log \mu^2}{\log \Delta} \log D.$$

#### <span id="page-106-0"></span>7.5.2 Good AGSP implies a good product state

Lemma 7.13 stated that to prove the area law, it suffices to have a good AGSP along with a product state with constant overlap with the ground state. It turns out that the former criterion actually implies the latter, as we now show in this section via the following lemma.

<span id="page-106-1"></span>**Lemma 7.14.** If there exists a  $(D, \Delta)$ -AGSP K such that  $D \cdot \Delta \leq \frac{1}{2}$ , then there exists a product state  $|\phi\rangle = |L\rangle \otimes |R\rangle$  whose overlap with the ground state  $|\Gamma\rangle$  is  $\mu = |\langle \Gamma|\phi\rangle| \geq 1/\sqrt{2D}$ .

*Proof.* We proceed by contradiction. Let  $|\phi'\rangle$  be a product state with the maximum possible overlap  $\mu$  with the ground state, and assume for sake of contradiction that  $\mu < 1/\sqrt{2D}$ . Then, consider the state  $|\phi\rangle := K|\phi'\rangle/||K|\phi'\rangle||$ . By definition of an AGSP, the Schmidt rank of  $|\phi\rangle$  is at most D, and therefore it can be written as  $|\phi\rangle = \sum_{i=1}^{D} \lambda_i |L_i\rangle \otimes |R_i\rangle$ . It follows that

$$\frac{\mu^{2}}{||K|\phi'\rangle||^{2}} = |\langle \Gamma|\phi\rangle|^{2}$$

$$\leq \left(\sum_{i=1}^{D} \lambda_{i} |\langle \Gamma|(|L_{i}\rangle \otimes |R_{i}\rangle)|\right)^{2}$$

$$\leq \sum_{i=1}^{D} |\langle \Gamma|(|L_{i}\rangle \otimes |R_{i}\rangle)|^{2},$$

where the last inequality uses the Cauchy-Schwarz inequality and the fact that  $\sum_i \lambda_i^2 = 1$ . Therefore, there exists some *i* such that

$$|\langle \Gamma|(|L_i\rangle \otimes |R_i\rangle)|^2 \ge \frac{\mu^2}{D||K|\phi'\rangle||^2} \ge \frac{\mu^2}{D(\mu^2 + \Delta)},$$

where the last inequality follows from the fact that K is a  $(D, \Delta)$ -AGSP. However,  $D(\mu^2 + \Delta) = D\mu^2 + D\Delta < \frac{1}{2} + \frac{1}{2} = 1$ , which implies that  $|L_i\rangle \otimes |R_i\rangle$  has a larger overlap with the ground state than  $|\phi'\rangle$  does. This is a contradiction, and therefore we have shown that  $\mu \geq 1/\sqrt{2D}$ .

To recap, by combining Lemmas 7.13 and 7.14, we have the following theorem, which sets the stage for our final area laws section on constructing a good AGSP (§7.5.3).

<span id="page-107-1"></span>**Theorem 7.15.** If there exists a  $(D, \Delta)$ -AGSP such that  $D \cdot \Delta \leq \frac{1}{2}$ , the ground state entanglement entropy is bounded by  $O(1) \cdot \log D$ .

#### <span id="page-107-0"></span>7.5.3 Constructing a good AGSP

Theorem 7.15 implies that in order to show an area law, it suffices to construct a good AGSP. In this section, we do precisely this. For simplicity in exposition, in this review, our exposition will attempt to deliver the main ideas behind the construction, without overwhelming the reader with technical details.

To begin, how does one go about constructing an AGSP, i.e. an operator that leaves the ground state invariant and shrinks every vector that is orthogonal to the ground state? Since the only information regarding the ground state in our possession is the Hamiltonian H itself, we use H as our starting point. Consider the first attempt of K = I - H/||H||; it is easy to check that K leaves the ground state invariant and cuts the norm of any orthogonal state to at most  $1 - \frac{\epsilon}{|H||}$  (recall that  $\epsilon$  is the spectral gap of the given Hamiltonian). Thus,  $K^k$  for large values of k yields an AGSP with a good value of  $\Delta$ . Unfortunately, however, in general with this construction D will also grow exponentially in k. Thus, this candidate AGSP does not satisfy our required condition that  $D \cdot \Delta \leq \frac{1}{2}$ .

![](_page_108_Figure_2.jpeg)

Figure 7.1: The polynomial  $C_{36}(x)$ , constructed based upon the Chebyshev polynomial of the first kind.

However, this first attempt has taught us something — that we can manipulate the spectrum of H via matrix polynomials. Namely, if we have a polynomial f(x) that maps 0 to 1 and  $[\epsilon, ||H||]$  to  $[0, \Delta]$ , f(H) will be an AGSP with the shrinking factor  $\Delta$ . The remaining task then would be to show that f(H) has a small Schmidt rank. Naturally one would expect that f must have a small degree, because the naive bound on the Schmidt rank grows at least exponentially in the degree of the polynomial.

But which f should we choose? In approximation theory, there is a well-known family of polynomials  $T_{\ell}$  called the **Chebyshev polynomial of the first kind**, which has the following properties [3]:

- 1. The degree of  $T_{\ell}(x)$  is  $\ell$ .
- 2. For  $x \in [-1, 1], |T_{\ell}(x)| \le 1$ .
- 3. For x > 1,  $T_{\ell}(x) \ge \frac{1}{2} e^{2\ell\sqrt{(x-1)/(x+1)}}$ .

The main point is that once x passes the value 1, the polynomial begins to increase very rapidly, giving rise to a threshold-like behavior. We will use this behavior to address the challenge that the AGSP should have an eigenvalue of 1 for the ground state while it should have a very small eigenvalue for the first excited state which is only  $\epsilon$  away from

<span id="page-109-0"></span>![](_page_109_Picture_2.jpeg)

**Figure 7.2:** Hamiltonian truncation. We focus on a segment of s particles around the cut, denoting the multiparticle Hamiltonians to the left and right of the segment by  $H_L$  and  $H_R$  respectively.

the ground state in the energy spectrum. The strategy is to make the first excited state correspond to  $T_{\ell}(1)$  and the largest eigenvector to  $T_{\ell}(-1)$  so that all excited states have eigenvalues at most 1, while the ground state, which will then correspond to  $T_{\ell}(1+y)$  for some small y, has a much greater eigenvalue. Then we can renormalize the operator so that the eigenvalue of the ground state becomes 1, as required by the definition of an AGSP.

In other words, we construct a family of polynomials  $C_{\ell}$  by scaling and translating  $T_{\ell}$  as follows:

$$C_{\ell}(x) = T_{\ell} \left( \frac{||H|| + \epsilon - 2x}{||H|| - \epsilon} \right) / T_{\ell} \left( \frac{||H|| + \epsilon}{||H|| - \epsilon} \right).$$

It is then straightforward to check that  $C_{\ell}(H)$  is an AGSP with  $\Delta = 4e^{-4\ell\sqrt{\epsilon/||H||}}$ .

Unfortunately, an immediate difficulty in using the above bound on  $\Delta$  is that ||H|| can be very large, significantly slowing down the decay of  $\Delta$ . This issue can be addressed by a technique called *Hamiltonian truncation*. The technique consists in picking out s particles around the cut that we are concerned with and truncating the upper spectrum of the other "less important" particles. More precisely, we write the Hamiltonian as  $H = H_L + H_1 + \cdots + H_s + H_R$  as shown in Figure 7.2, and then replace  $H_L$  and  $H_R$  by their respective truncated versions  $H_L^{\leq t}$  and  $H_R^{\leq t}$ , where  $A^{\leq t}$  denotes the matrix obtained from A by replacing all eigenvalues greater than t with t and leaving the other eigenvalues unchanged. It is clear that the resulting truncated Hamiltonian H' has norm bounded by s+2t, and it can also be shown that there exists some constant t such that the spectral gap of H' remains to be  $\Omega(1) \cdot \epsilon$ . Moreover, since the Hamiltonian is frustration-free, H and H' have the

same (unique) ground state.[1](#page-110-0) This means that we can use *H*<sup>0</sup> in place of *H* in our construction of the AGSP.

Finally, we need to show that the resulting AGSP *C`*(*H*<sup>0</sup> ) has a small Schmidt rank across the given cut. Intuitively speaking, this follows from the fact that each term in the expansion of *C`*(*H*<sup>0</sup> ) is a product of at most *`* terms of *H*<sup>0</sup> , and therefore on average contributes Schmidt rank of *d `/*(*s*+1) to a cut, where *d* is the local dimension of the particles (there are *s*+1 possible cuts in *H*<sup>0</sup> ). The challenge here is that there are exponentially many terms in the expansion of *C`*(*H*<sup>0</sup> ) and thus we cannot simply sum these up. Fortunately, it is possible to circumvent this problem by cleverly grouping the exponential number of terms into a small number of large sums, with each sum again having small entanglement. The argument uses polynomial interpolation (see Lemma 4.2 of [\[19\]](#page-114-8)) and we end up with the bound of *D* = (*d`*) *O*(max{*`/s,*<sup>√</sup> *`*}) .

Comparing this bound with our previously derived expression ∆ = 4*e* −4*`* √ */*||*H*|| reveals that a suitable choice of parameters *`* = *O*(*s* 2 ) and *s* = *O*((log<sup>2</sup> *d*)*/*)) gives us *D* · ∆ ≤ 1 2 . We conclude that, by Theorem [7.15,](#page-107-1) there exists an area law for 1D gapped systems.

<span id="page-110-0"></span><sup>1</sup>Note that this is the only use of the frustration-free assumption in our presentation. In fact, the proof of the frustrated case also follows exactly the same outline except that there we need a more delicate argument to prove that the ground states of *H* and *H*<sup>0</sup> , which may now be distinct, are very close to each other. The interested reader can refer to §6 of [\[19\]](#page-114-8).

# <span id="page-111-0"></span>**Acknowledgements**

This Simons Institute Monograph has its roots in the UC Berkeley Quantum Reading Group of Spring 2013, during which many discussions took place. There were a number of participants involved in these discussions, whom we wish to thank: Piyush Srivastava, who contributed to our discussion on *Thermal equilibrium, Boltzmann distribution & Gibbs state* in [§6.1,](#page-50-1) Guoming Wang, as well as Vamsi K. Devabathini for remote participation and contributions from IIT Madras in India. SG would like to thank Niel de Beaudrap and Or Sattath for very helpful discussions regarding [§7.4,](#page-96-0) Maris Ozols for insightful comments on the first version of this document, Tomotoshi Nishino for helpful comments on the history of tensor network states, and David Gosset.

One of the initial aims of this survey was to act as an introduction to the field for participants of the Spring 2014 program entitled "Quantum Hamiltonian Complexity", held at the Simons Institute for the Theory of Computing at UC Berkeley. Over the course of this program, the survey matured and was improved greatly due to feedback from and exposure to the field. In this regard, SG would like to especially thank Ignacio Cirac for a pair of wonderful talks and ensuing discussions (on which Chapter [5](#page-35-0) is based) at the Simons Institute. We also thank the Simons Institute for hosting both the authors and the Quantum Hamiltonian Complexity program itself.

SG acknowledges financial support from a Government of Canada NSERC Banting Postdoctoral Fellowship and the Simons Institute for the Theory of Computing at UC Berkeley. YH is supported by DARPA OLE. ZL is supported by ARO Grant W911NF-12-1-0541, NSF Grant CCF-0905626, Templeton Foundation Grant 21674, and the Simons Institute for the Theory of Computing. SWS is supported by NSF Grant CCF-0905626 and ARO Grant W911NF-09-1-0440.

- <span id="page-113-1"></span><span id="page-113-0"></span>[1] Superfluid helium. [https://www.youtube.com/watch?v=](https://www.youtube.com/watch?v=2Z6UJbwxBZI) [2Z6UJbwxBZI](https://www.youtube.com/watch?v=2Z6UJbwxBZI).
- <span id="page-113-3"></span>[2] S. Aaronson. The quantum PCP manifesto, 2006. http://scottaaronson.com/blog/?p=139.
- <span id="page-113-9"></span>[3] M. Abramowitz and I. A. Stegun. *Handbook of Mathematical Functions with Formulas, Graphs, and Mathematical Tables*. Dover Publications, New York, 1964.
- <span id="page-113-8"></span>[4] K. Van Acoleyen, M. Mariën, and F. Verstraete. Entanglement rates and area laws. *Physical Review Letters*, 111:170501, 2013.
- <span id="page-113-4"></span>[5] G. Adesso, S. Ragy, and A. R. Lee. Continuous variable quantum information: Gaussian states and beyond. *Open Systems & Information Dynamics*, 21:1440001, 2014.
- <span id="page-113-6"></span>[6] I. Affleck, T. Kennedy, E. Lieb, and H. Tasaki. Rigorous results on valence-bond ground states in antiferromagnets. *Physical Review Letters*, 59:799–802, 1987.
- <span id="page-113-7"></span>[7] I. Affleck, T. Kennedy, E. Lieb, and H. Tasaki. Valence bond ground states in isotropic quantum antiferromagnets. *Communications in Mathematical Physics*, 115(3):477–528, 1988.
- <span id="page-113-5"></span>[8] I. Affleck and E. Lieb. A proof of part of Haldane's conjecture on spin chains. *Letters in Mathematical Physics*, 12(1):57–69, 1986.
- <span id="page-113-2"></span>[9] D. Aharonov, I. Arad, and S. Irani. Efficient algorithm for approximating one-dimensional ground states. *Physical Review A*, 82:012315, 2010.

<span id="page-114-6"></span>[10] D. Aharonov, I. Arad, Z. Landau, and U. Vazirani. The detectability lemma and quantum gap amplification. In *Proceedings of 41st ACM Symposium on Theory of Computing (STOC 2009)*, pages 417–426, 2009.

- <span id="page-114-9"></span>[11] D. Aharonov, I. Arad, Z. Landau, and U. Vazirani. The 1D area law and the complexity of quantum states: A combinatorial approach. In *Proceedings of the IEEE 52nd Annual Symposium on Foundations of Computer Science (FOCS 2011)*, pages 324–333, 2011.
- <span id="page-114-7"></span>[12] D. Aharonov, I. Arad, and T. Vidick. The quantum PCP conjecture. In *ACM SIGACT News*, volume 44, pages 47–79. 2013.
- <span id="page-114-3"></span>[13] D. Aharonov and L. Eldar. On the complexity of commuting local Hamiltonians, and tight conditions for Topological Order in such systems. In *Proceedings of the 52nd IEEE Symposium on Foundations of Computer Science (FOCS 2011)*, pages 334–343, 2011.
- <span id="page-114-4"></span>[14] D. Aharonov and L. Eldar. Commuting local Hamiltonians on expanders, locally testable quantum codes, and the qPCP conjecture. Available at arXiv.org e-Print quant-ph/1301.3407, 2013.
- <span id="page-114-5"></span>[15] D. Aharonov and L. Eldar. The commuting local Hamiltonian problem on locally expanding graphs is approximable in NP. *Quantum Information Processing*, 14(1):83–101, 2015.
- <span id="page-114-2"></span>[16] D. Aharonov, D. Gottesman, S. Irani, and J. Kempe. The power of quantum systems on a line. *Communications in Mathematical Physics*, 287:41–65, 2009.
- <span id="page-114-12"></span>[17] D. Aharonov, A. W. Harrow, Z. Landau, D. Nagaj, M. Szegedy, and U. Vazirani. Local tests of global entanglement and a counterexample to the generalized area law. In *Proceedings of the 55th IEEE Symposium on Foundations of Computer Science (FOCS 2014)*, pages 246–255, 2014.
- <span id="page-114-1"></span>[18] D. Aharonov and T. Naveh. Quantum NP - A survey. Available at arXiv.org e-Print quant-ph/0210077v1, 2002.
- <span id="page-114-8"></span>[19] I. Arad, A. Kitaev, Z. Landau, and U. Vazirani. An area law and subexponential algorithm for 1D systems. Available at arXiv.org e-Print quant-ph/1301.1162, 2013.
- <span id="page-114-10"></span>[20] I. Arad, Z. Landau, and U. Vazirani. Improved one-dimensional area law for frustration-free systems. *Physical Review B*, 85:195145, 2012.
- <span id="page-114-11"></span>[21] I. Arad, M. Santha, A. Sundaram, and S. Zhang. Linear time algorithm for quantum 2SAT. arXiv:1508.06340, 2015.
- <span id="page-114-0"></span>[22] S. Arora and B. Barak. *Computational Complexity: A Modern Approach*. Cambridge University Press, 2009.

<span id="page-115-6"></span>[23] S. Arora, C. Lund, R. Motwani, M. Sudan, and M. Szegedy. Proof verification and the hardness of approximation problems. *Journal of the ACM*, 45(3):501–555, 1998. Prelim. version FOCS '92.

- <span id="page-115-5"></span>[24] S. Arora and S. Safra. Probabilistic checking of proofs: A new characterization of NP. *Journal of the ACM*, 45(1):70–122, 1998. Prelim. version FOCS '92.
- <span id="page-115-13"></span>[25] B. Aspvall, M. F. Plass, and R. E. Tarjan. A linear-time algorithm for testing the truth of certain quantified boolean formulas. *Information Processing Letters*, 8(3):121–123, 1979.
- <span id="page-115-7"></span>[26] F. Baharona. On the computational complexity of ising spin glass models. *Journal of Physics A - Mathematical and General*, 15:3241, 1982.
- <span id="page-115-4"></span>[27] N. Bansal, S. Bravyi, and B. M. Terhal. Classical approximation schemes for the ground-state energy of quantum and classical Ising spin Hamiltonians on planar graphs. *Quantum Information & Computation*, 9(7&8):701–720, 2009.
- <span id="page-115-11"></span>[28] J. D. Bekenstein. Black holes and entropy. *Physical Review D*, 7:2333, 1973.
- <span id="page-115-0"></span>[29] P. Benioff. The computer as a physical system: A microscopic quantum mechanical Hamiltonian model of computers as represented by Turing machines. *Journal of Statistical Physics*, 22:563–591, 1980.
- <span id="page-115-1"></span>[30] P. Benioff. Quantum mechanical Hamiltonian models of Turing machines. *Journal of Statistical Physics*, 29:515–546, 1982.
- <span id="page-115-2"></span>[31] P. Benioff. Quantum mechanical Hamiltonian models of Turing machines that dissipate no energy. *Physical Review Letters*, 48:1581–1585, 1982.
- <span id="page-115-9"></span>[32] H. Bethe. Zur Theorie der Metalle. *Zeitschrift für Physik*, 71(3–4):205– 226, 1931.
- <span id="page-115-3"></span>[33] J. D. Biamonte and P. J. Love. Realizable Hamiltonians for universal adiabatic quantum computers. *Physical Review A*, 78:012352, 2008.
- <span id="page-115-12"></span>[34] L. Bombelli, R. K. Koul, J. Lee, and R. D. Sorkin. Quantum source of entropy for black holes. *Physical Review D*, 34:373, 1986.
- <span id="page-115-10"></span>[35] F. G. S. L. Brandão and M. Horodecki. Exponential decay of correlations implies area law. *Communications in Mathematical Physics*, 333(2):761–798, 2015.
- <span id="page-115-8"></span>[36] F. Brandão and M. Cramer. Entanglement area law from specific heat capacity. *Physical Review B*, 92:115134, 2015.

<span id="page-116-6"></span>[37] F. Brandão and A. Harrow. Product-state approximations to quantum ground states. In *Proceedings of the 45th ACM Symposium on the Theory of Computing (STOC 2013)*, pages 871–880, 2013.

- <span id="page-116-0"></span>[38] S. Bravyi. Efficient algorithm for a quantum analogue of 2-SAT. Available at arXiv.org e-Print quant-ph/0602108v1, 2006.
- <span id="page-116-7"></span>[39] S. Bravyi. Monte Carlo simulation of stoquastic hamiltonians. Available at arXiv.org e-Print quant-ph/1402.2295, 2014.
- <span id="page-116-1"></span>[40] S. Bravyi, A. Bessen, and B. Terhal. Merlin-Arthur games and stoquastic complexity. Available at arXiv.org e-Print quant-ph/0611021v2, 2006.
- <span id="page-116-9"></span>[41] S. Bravyi, L. Caha, R. Movassagh, D. Nagaj, and P. W. Shor. Criticality without frustration for quantum spin-1 chains. *Physical Review Letters*, 109:207202, 2012.
- <span id="page-116-3"></span>[42] S. Bravyi, D. DiVincenzo, R. Oliveira, and B. Terhal. The complexity of stoquastic local Hamiltonian problems. *Quantum Information & Computation*, 8(5):0361–0385, 2008.
- <span id="page-116-8"></span>[43] S. Bravyi and M. Hastings. On complexity of the quantum Ising model. Available at arXiv.org e-Print quant-ph/1410.0703, 2014.
- <span id="page-116-2"></span>[44] S. Bravyi and B. Terhal. Complexity of stoquastic frustration-free Hamiltonians. *SIAM Journal on Computing*, 39(4):1462, 2009.
- <span id="page-116-4"></span>[45] S. Bravyi and M. Vyalyi. Commutative version of the local Hamiltonian problem and common eigenspace problem. *Quantum Information & Computation*, 5(3):187–215, 2005.
- <span id="page-116-10"></span>[46] W. J. L. Buyers, R. M. Morra, R. L. Armstrong, M. J. Hogan, P. Gerlach, and K. Hirakawa. Experimental evidence for the Haldane gap in a spin-1 nearly isotropic, antiferromagnetic chain. *Physical Review Letters*, 56:371–374, Jan 1986.
- <span id="page-116-11"></span>[47] P. Calabrese and J. Cardy. Entanglement entropy and quantum field theory. *Journal of Statistical Mechanics: Theory and Experiment*, 2004(06):P06002, 2004.
- <span id="page-116-12"></span>[48] P. Calabrese and J. Cardy. Entanglement entropy and conformal field theory. *Journal of Physics A: Mathematical and Theoretical*, 42(50):504005, 2009.
- <span id="page-116-5"></span>[49] A. M. Childs, D. Gosset, and Z. Webb. The Bose-Hubbard model is QMA-complete. In *Proceedings of the 41st International Colloquium on Automata, Languages, and Programming (ICALP 2014)*, pages 308–319, 2013.

<span id="page-117-4"></span>[50] C. T. Chubb and S. T. Flammia. Computing the degenerate ground space of gapped spin chains in polynomial time. Available at arXiv.org e-Print quant-ph/1502.06967, 2015.

- <span id="page-117-9"></span>[51] I. Cirac and F. Verstraete. Renormalization and tensor product states in spin chains and lattices. *Journal of Physics A: Mathematical and Theoretical*, 42(50):504004, 2009.
- <span id="page-117-7"></span>[52] J. I. Cirac and P. Zoller. Goals and opportunities in quantum simulation. *Nature Physics*, 8:264–266, 2012.
- <span id="page-117-0"></span>[53] S. Cook. The complexity of theorem proving procedures. In *Proceedings of the 3rd ACM Symposium on Theory of Computing (STOC 1972)*, pages 151–158, 1972.
- <span id="page-117-1"></span>[54] T. Cubitt and A. Montanaro. Complexity classification of local Hamiltonian problems. In *Proceedings of the 55nd IEEE Symposium on Foundations of Computer Science (FOCS 2014)*, pages 120–129, 2014.
- <span id="page-117-3"></span>[55] T. Cubitt, D. Perez-Garcia, and M. M. Wolf. Undecidability of the spectral gap (full version). Available at arXiv.org e-Print quantph/1502.04573, 2015.
- <span id="page-117-5"></span>[56] N. de Beaudrap and S. Gharibian. A linear time algorithm for quantum 2-SAT. Available at arXiv.org e-Print quant-ph/1508.07338, 2015.
- <span id="page-117-8"></span>[57] B. DeMarco and D. S. Jin. Onset of Fermi degeneracy in a trapped atomic gas. *Science*, 285(5434):1703–1706, 1999.
- <span id="page-117-2"></span>[58] I. Dinur. The PCP theorem by gap amplification. *Journal of the ACM*, 54(3), 2007.
- <span id="page-117-6"></span>[59] J. Dubail and N. Read. Tensor network trial states for chiral topological phases in two dimensions. Available at arXiv.org e-Print cond-mat.meshall/1307.7726, 2013.
- <span id="page-117-13"></span>[60] Carl Eckart and Gale Young. The approximation of one matrix by another of lower rank. *Psychometrika*, 1(3):211, 1936.
- <span id="page-117-10"></span>[61] J. Eisert, M. Cramer, and M. B. Plenio. Area laws for the entanglement entropy. *Reviews of Modern Physics*, 82:277–306, Feb 2010.
- <span id="page-117-12"></span>[62] S. Even, A. Itai, and A. Shamir. On the complexity of time table and multi-commodity flow problems. *SIAM Journal on Computing*, 5(4):691–703, 1976.
- <span id="page-117-11"></span>[63] H. Fan, V. Korepin, and V. Roychowdhury. Entanglement in a valencebond solid state. *Physical Review Letters*, 93:227203, 2004.

<span id="page-118-11"></span>[64] M. Fannes, B. Nachtergaele, and R.F. Werner. Finitely correlated states on quantum spin chains. *Communications in Mathematical Physics*, 144(3):443–490, 1992.

- <span id="page-118-10"></span>[65] R. Feynman. Forces in molecules. *Physical Review*, 56:340–343, Aug 1939.
- <span id="page-118-1"></span>[66] R. Feynman. Simulating physics with computers. *International Journal of Theoretical Physics*, 21(6–7):467–488, 1982.
- <span id="page-118-2"></span>[67] R. Feynman. Quantum mechanical computers. *Optics News*, 11:11, 1985.
- <span id="page-118-7"></span>[68] J. Fitzsimons and T. Vidick. A multiprover interactive proof system for the local hamiltonian problem. In *Proceedings of the 2015 Conference on Innovations in Theoretical Computer Science (ITCS 2015)*, pages 103–112, 2015.
- <span id="page-118-9"></span>[69] Y. Ge and J. Eisert. Area laws and efficient descriptions of quantum many-body states. Available at arXiv.org e-Print quant-ph/1411.2995, 2014.
- <span id="page-118-3"></span>[70] S. Gharibian. Strong NP-hardness of the quantum separability problem. *Quantum Information and Computation*, 10(3&4):343–360, 2010.
- <span id="page-118-0"></span>[71] S. Gharibian. *Approximation, proof systems, and correlations in a quantum world*. PhD thesis, University of Waterloo, 2013. Available at arXiv.org e-Print quant-ph/1301.2632.
- <span id="page-118-5"></span>[72] S. Gharibian and J. Kempe. Approximation algorithms for QMAcomplete problems. In *Proceedings of 26th IEEE Conference on Computational Complexity (CCC 2011)*, pages 178–188, 2011.
- <span id="page-118-6"></span>[73] S. Gharibian and J. Kempe. Hardness of approximation for quantum problems. In *Proceedings of 39th International Colloquium on Automata, Languages and Programming (ICALP 2012)*, pages 387–398, 2012.
- <span id="page-118-4"></span>[74] S. Gharibian, Z. Landau, S. W. Shin, and G. Wang. Tensor network non-zero testing. *Quantum Information & Computation*, 15(9&10):885– 899, 2015.
- <span id="page-118-8"></span>[75] S. Gharibian and J. Sikora. Ground state connectivity of local Hamiltonians. In *Proceedings of the 42nd International Colloquium on Automata, Languages, and Programming (ICALP 2015)*, pages 617–628, 2015.
- <span id="page-118-12"></span>[76] N. Gisin. Hidden quantum nonlocality revealed by local filters. *Physics Letters A*, 210(8):151–156, 1996.

<span id="page-119-4"></span>[77] D. Gosset and D. Nagaj. Quantum 3-SAT is QMA1-complete. In *Proceedings of the 54th IEEE Symposium on Foundations of Computer Science (FOCS 2013)*, pages 756–765, 2013.

- <span id="page-119-6"></span>[78] D. Gosset, B. M. Terhal, and A. Vershynina. Universal adiabatic quantum computation via the space-time circuit-to-Hamiltonian construction. *Physical Review Letters*, 114:140501, 2015.
- <span id="page-119-3"></span>[79] D. Gottesman and S. Irani. The quantum and classical complexity of translationally invariant tiling and Hamiltonian problems. In *Proceedings of the 50th IEEE Symposium on Foundations of Computer Science (FOCS 2009)*, pages 95–104, 2009.
- <span id="page-119-8"></span>[80] D. J. Griffiths. *Introduction to Quantum Mechanics*. Pearson Prentice Hall, 2nd edition, 2004.
- <span id="page-119-11"></span>[81] Z.-C. Gu and X.-G. Wen. Tensor-entanglement-filtering renormalization approach and symmetry-protected topological order. *Physical Review B*, 80:155131, Oct 2009.
- <span id="page-119-1"></span>[82] L. Gurvits. Classical deterministic complexity of Edmond's problem and quantum entanglement. In *Proceedings of the 35th Symposium on Theory of computing (STOC 2003)*, pages 10–19. ACM Press, 2003.
- <span id="page-119-9"></span>[83] F. Haldane. Continuum dynamics of the 1-D Heisenberg antiferromagnet: Identification with the O(3) nonlinear sigma model. *Physics Letters A*, 93(9):464–468, 1983.
- <span id="page-119-10"></span>[84] F. Haldane. Nonlinear field theory of large-spin Heisenberg antiferromagnets: Semiclassically quantized solitons of the one-dimensional easyaxis Néel state. *Physical Review Letters*, 50:1153–1156, 1983.
- <span id="page-119-2"></span>[85] S. Hallgren, D. Nagaj, and S. Narayanaswami. The Local Hamiltonian problem on a line with eight states is QMA-complete. *Quantum Information & Computation*, 13(9&10):0721–0750, 2013.
- <span id="page-119-12"></span>[86] M. B. Hastings. Lieb-Schultz-Mattis in higher dimensions. *Physical Review B*, 69:104431, 2004.
- <span id="page-119-7"></span>[87] M. B. Hastings. Solving gapped Hamiltonians locally. *Physical Review B*, 73:085115, 2006.
- <span id="page-119-0"></span>[88] M. B. Hastings. An area law for one-dimensional quantum systems. *Journal of Statistical Mechanics*, P08024(08), 2007.
- <span id="page-119-5"></span>[89] M. B. Hastings. Matrix product operators and central elements: Classical description of a quantum state. *Geometry & Topology Monographs*, 18:115–160, 2012.

<span id="page-120-11"></span>[90] P. Hayden, D. Leung, and A. Winter. Aspects of generic entanglement. *Communications in Mathematical Physics*, 265(1):95–117, 2006.

- <span id="page-120-7"></span>[91] Y. Huang. Area law in one dimension: Degenerate ground states and Renyi entanglement entropy. Available at arXiv.org e-Print condmat.str-el/1403.0327, 2014.
- <span id="page-120-8"></span>[92] J. Hubbard. Electron correlations in narrow energy bands. *Proceedings of the Royal Society of London. Series A, Mathematical and Physical Sciences*, 276(1365):238–257, 1963.
- <span id="page-120-10"></span>[93] S. Irani. Ground state entanglement in one-dimensional translationally invariant quantum systems. *Journal of Mathematical Physics*, 51:022101, 2010.
- <span id="page-120-12"></span>[94] A. R. Its, B.-Q. Jin, and V. E. Korepin. Entanglement in the XY spin chain. *Journal of Physics A: Mathematical and General*, 38:2975, 2005.
- <span id="page-120-6"></span>[95] M. Jerrum and A. Sinclair. Polynomial-time approximation algorithms for the Ising model. *SIAM Journal on Computing*, 22(5):1087–1116, 1993.
- <span id="page-120-5"></span>[96] S. P. Jordan, D. Gosset, and P. J. Love. Quantum-Merlin-Arthurcomplete problems for stoquastic Hamiltonians and Markov matrices. *Physical Review A*, 81:032331, 2010.
- <span id="page-120-9"></span>[97] R. Jördens, N. Strohmaier, K. Günter, H. Moritz, and T. Esslinger. A Mott insulator of fermionic atoms in an optical lattice. *Nature*, 455:204– 207, 2008.
- <span id="page-120-1"></span>[98] R. Jozsa and N. Linden. On the role of entanglement in quantumcomputational speed-up. *Proceedings of the Royal Society of London; Series A, Mathematical and Physical Sciences*, 459:2011–2032, 2003.
- <span id="page-120-13"></span>[99] R. Karp. Reducibility among combinatorial problems. In *Complexity of Computer Computations*, pages 85–103. New York: Plenum, 1972.
- <span id="page-120-4"></span>[100] A. Kay. Quantum-Merlin-Arthur-complete translationally invariant Hamiltonian problem and the complexity of finding ground-state energies in physical systems. *Physical Review A*, 76(3):030307, 2007.
- <span id="page-120-0"></span>[101] P. Kaye, R. Laflamme, and M. Mosca. *An Introduction to Quantum Computing*. Oxford University Press, 2007.
- <span id="page-120-3"></span>[102] J. Kempe, A. Kitaev, and O. Regev. The complexity of the local Hamiltonian problem. *SIAM Journal on Computing*, 35(5):1070–1097, 2006.
- <span id="page-120-2"></span>[103] J. Kempe and O. Regev. 3-local Hamiltonian is QMA-complete. *Quantum Information & Computation*, 3(3):258–264, 2003.

<span id="page-121-3"></span>[104] A. Kitaev. Quantum NP, 1999. Talk at Second Workshop on Algorithms in Quantum Information Processing (AQIP 1999), DePaul University.

- <span id="page-121-12"></span>[105] A. Kitaev. Fault-tolerant quantum computation by anyons. *Annals of Physics*, 303(1):2–30, 2003.
- <span id="page-121-1"></span>[106] A. Kitaev, A. Shen, and M. Vyalyi. *Classical and Quantum Computation*. American Mathematical Society, 2002.
- <span id="page-121-13"></span>[107] E. Knill, R. Laflamme, and L. Viola. Theory of quantum error correction for general noise. *Physical Review Letters*, 84:2525, 2000.
- <span id="page-121-5"></span>[108] H. A. Kramers and G. H. Wannier. Statistics of the two-dimensional ferromagnet. Part II. *Physical Review*, 60:263–276, 1941.
- <span id="page-121-14"></span>[109] M. R. Krom. The decision problem for a class of first-order formulas in which all disjunctions are binary. *Zeitschrift für Mathematische Logik und Grundlagen der Mathematik*, 13:15–20, 1967.
- <span id="page-121-6"></span>[110] Z. Landau, U. Vazirani, and T. Vidick. A polynomial-time algorithm for the ground state of 1D gapped local Hamiltonians. *Nature Physics*, 11:566–569, 2015.
- <span id="page-121-0"></span>[111] L. Levin. Universal sequential search problems. *Problems of Information Transmission*, 9(3):265–266, 1973.
- <span id="page-121-10"></span>[112] E. Lieb, T. Schultz, and D. Mattis. Two soluble models of an antiferromagnetic chain. *Annals of Physics*, 16(3):407–466, 1961.
- <span id="page-121-9"></span>[113] E. H. Lieb and F. Y. Wu. Absence of Mott transition in an exact solution of the short-range, one-band model in one dimension. *Physical Review Letters*, 20(25):1445–1448, 1968.
- <span id="page-121-8"></span>[114] N. Linden, S. Popescu, A. J. Short, and A. Winter. Quantum mechanical evolution towards thermal equilibrium. *Physical Review E*, 79:061103, 2009.
- <span id="page-121-4"></span>[115] Y.-K. Liu, M. Christandl, and F. Verstraete. Quantum computational complexity of the N-representability problem: QMA complete. *Physical Review Letters*, 98:110503, 2007.
- <span id="page-121-7"></span>[116] M. Mariën, K. M. R. Audenaert, K. Van Acoleyen, and F. Verstraete. Entanglement rates and the stability of the area law for the entanglement entropy. Available at arXiv.org e-Print quant-ph/1411.0680, 2014.
- <span id="page-121-2"></span>[117] C. Marriott and J. Watrous. Quantum Arthur-Merlin games. *Computational Complexity*, 14(2):122–152, 2005.
- <span id="page-121-11"></span>[118] L. Masanes. An area law for the entropy of low-energy states. *Physical Review A*, 80:052104, 2009.

<span id="page-122-8"></span>[119] A. Meyer and L. Stockmeyer. The equivalence problem for regular expressions with squaring requires exponential time. In *Proceedings of the 13th Symposium on Foundations of Computer Science*, pages 125– 129, 1972.

- <span id="page-122-10"></span>[120] A. Molnar, N. Schuch, F. Verstraete, and J. I. Cirac. Approximating Gibbs states of local Hamiltonians efficiently with projected entangled pair states. *Physical Review B*, 91(4):045138, 2015.
- <span id="page-122-12"></span>[121] R. M. Morra, W. J. L. Buyers, R. L. Armstrong, and K. Hirakawa. Spin dynamics and the Haldane gap in the spin-1 quasi-one-dimensional antiferromagnet CsNiCl3. *Physical Review B*, 38:543–555, 1988.
- <span id="page-122-9"></span>[122] R. Movassagh and P. W. Shor. Power law violation of the area law in quantum spin chains. Available at arXiv.org e-Print quantph/1408.1657, 2014.
- <span id="page-122-4"></span>[123] D. Nagaj. *Local Hamiltonians in Quantum Computation*. PhD thesis, Massachusetts Institute of Technology, Boston, 2008. Available at arXiv.org e-Print quant-ph/0808.2117v1.
- <span id="page-122-2"></span>[124] D. Nagaj and S. Mozes. A new construction for a QMA complete 3-local Hamiltonian. *Journal of Mathematical Physics*, 48(7):072104, 2007.
- <span id="page-122-0"></span>[125] M. A. Nielsen and I. L. Chuang. *Quantum Computation and Quantum Information*. Cambridge University Press, 2000.
- <span id="page-122-6"></span>[126] T. Nishino, T. Hikihara, K. Okunishi, and Y. Hieida. Density matrix renormalization group: Introduction from a variational point of view. *International Journal of Modern Physics B*, 13(1):1–24, 1999.
- <span id="page-122-3"></span>[127] R. Oliveira and B. M. Terhal. The complexity of quantum spin systems on a two-dimensional square lattice. *Quantum Information & Computation*, 8(10):0900–0924, 2008.
- <span id="page-122-13"></span>[128] L. Onsager. Crystal statistics. I. A two-dimensional model with an order-disorder transition. *Physical Review*, 65:117–149, 1944.
- <span id="page-122-1"></span>[129] T. J. Osborne. Hamiltonian complexity. *Reports on Progress in Physics*, 75(2):022001, 2012.
- <span id="page-122-5"></span>[130] S. Östlund and S. Rommer. Thermodynamic limit of density matrix renormalization. *Physical Review Letters*, 75:3537–3540, 1995.
- <span id="page-122-7"></span>[131] D. Perez-Garcia, F. Verstraete, M. M. Wolf, and J. I. Cirac. Matrix product state representations. *Quantum Information & Computation*, 7(5):401–430, 2007.
- <span id="page-122-11"></span>[132] P. Pfeuty. The one-dimensional Ising model with a transverse field. *Annals of Physics*, 57(1):79–90, 1970.

<span id="page-123-12"></span>[133] F. Pollmann, E. Berg, A. M. Turner, and M. Oshikawa. Symmetry protection of topological phases in one-dimensional quantum spin systems. *Physical Review B*, 85:075125, 2012.

- <span id="page-123-7"></span>[134] J. Quintanilla and C. Hooley. The strong-correlations puzzle. *Physics World*, 22(6):32–37, 2009.
- <span id="page-123-10"></span>[135] J. P. Renard, M. Verdaguer, L. P. Regnault, W. A. C. Erkelens, J. Rossat-Mignod, and W. G. Stirling. Presumption for a quantum energy gap in the quasi-one-dimensional s = 1 Heisenberg antiferromagnet Ni(C2H8N2)2NO2(ClO4). *Europhysics Letters*, 3(8):945, 1987.
- <span id="page-123-5"></span>[136] S. Rommer and S. Östlund. Class of ansatz wave functions for onedimensional spin systems and their relation to the density matrix renormalization group. *Physical Review B*, 55:2164–2181, 1997.
- <span id="page-123-9"></span>[137] Subir Sachdev. *Quantum Phase Transitions*. Cambridge University Press, 2011.
- <span id="page-123-2"></span>[138] T. J. Schaefer. The complexity of satisfiability problems. In *Proceedings of the 10th Symposium on Theory of computing*, pages 216–226, 1978.
- <span id="page-123-0"></span>[139] D. Schiff and L. Verlet. Ground state of liquid helium-4 and helium-3. *Physical Review*, 160:208, 1967.
- <span id="page-123-8"></span>[140] U. Schneider, L. Hackermüller, S. Will, Th. Best, I. Bloch, T. A. Costi, R. W. Helmes, D. Rasch, and A. Rosch. Metallic and insulating phases of repulsively interacting fermions in a 3D optical lattice. *Science*, 322(5907):1520–1525, 2008.
- <span id="page-123-13"></span>[141] U. Schollwöck. The density-matrix renormalization group. *Reviews of Modern Physics*, 77:259–315, 2005.
- <span id="page-123-11"></span>[142] U. Schollwöck. The density-matrix renormalization group in the age of matrix product states. *Annals of Physics*, 326(1):96–192, 2011.
- <span id="page-123-1"></span>[143] E. Schrödinger. Die gegenwärtige Situation in der Quantenmechanik. *Naturwissenschaften*, 23(48):807–812, 1935.
- <span id="page-123-3"></span>[144] N. Schuch. Complexity of commuting Hamiltonians on a square lattice of qubits. *Quantum Information & Computation*, 11:901–912, 2011.
- <span id="page-123-6"></span>[145] N. Schuch, I. Cirac, and F. Verstraete. Computational difficulty of finding matrix product ground states. *Physical Review Letters*, 100:250501, 2008.
- <span id="page-123-4"></span>[146] N. Schuch and J. I. Cirac. Matrix product state and mean-field solutions for one-dimensional systems can be found efficiently. *Physical Review A*, 82:012314, 2010.

<span id="page-124-0"></span>[147] N. Schuch and F. Verstraete. Computational complexity of interacting electrons and fundamental limitations of density functional theory. *Nature Physics*, 5:732–735, 2009.

- <span id="page-124-9"></span>[148] N. Schuch, M. Wolf, F. Verstraete, and J. I. Cirac. Computational complexity of projected entangled pair states. *Physical Review Letters*, 98:140506, 2007.
- <span id="page-124-11"></span>[149] N. Schuch, M. M. Wolf, F. Verstraete, and J. I. Cirac. Entropy scaling and simulability by matrix product states. *Physical Review Letters*, 100:030504, 2008.
- <span id="page-124-12"></span>[150] T. D. Schultz, D. C. Mattis, and E. H. Lieb. Two-dimensional ising model as a soluble problem of many fermions. *Reviews of Modern Physics*, 36:856–871, 1964.
- <span id="page-124-13"></span>[151] M. Srednicki. Entropy and area. *Physical Review Letters*, 71:666, 1993.
- <span id="page-124-5"></span>[152] F. Verstraete and J. I. Cirac. Renormalization algorithms for quantummany body systems in two and higher dimensions. Available at arXiv.org e-Print cond-mat/0407066, 2004.
- <span id="page-124-10"></span>[153] F. Verstraete and J. I. Cirac. Matrix product states represent ground states faithfully. *Physical Review B*, 73(9):094423, 2006.
- <span id="page-124-1"></span>[154] F. Verstraete, V. Murg, and I. Cirac. Matrix product states, projected entangled pair states, and variational renormalization group methods for quantum spin systems. *Advances in Physics*, 57(2):143–224, 2008.
- <span id="page-124-2"></span>[155] F. Verstraete, D. Porras, and J. I. Cirac. Density matrix renormalization group and periodic boundary conditions: A quantum information perspective. *Physical Review Letters*, 93:227205, 2004.
- <span id="page-124-6"></span>[156] F. Verstraete, M. Wolf, D. Pérez-García, and J. I. Cirac. Projected entangled states: Properties and applications. *International Journal of Modern Physics B*, 20:5142, 2006.
- <span id="page-124-3"></span>[157] G. Vidal. Efficient classical simulation of slightly entangled quantum computations. *Physical Review Letters*, 91:147902, 2003.
- <span id="page-124-4"></span>[158] G. Vidal. Efficient simulation of one-dimensional quantum many-body systems. *Physical Review Letters*, 93:040502, 2004.
- <span id="page-124-7"></span>[159] G. Vidal. Entanglement renormalization. *Physical Review Letters*, 99:220405, 2007.
- <span id="page-124-8"></span>[160] G. Vidal. Class of quantum many-body states that can be efficiently simulated. *Physical Review Letters*, 101:110501, 2008.
- <span id="page-124-14"></span>[161] G. Vidal, J. I. Latorre, E. Rico, and A. Kitaev. Entanglement in quantum critical phenomena. *Physical Review Letters*, 90:227902, 2003.

<span id="page-125-6"></span>[162] T. B. Wahl, H.-H. Tu, N. Schuch, and J. I. Cirac. Projected entangledpair states can describe chiral topological states. *Physical Review Letters*, 111:236805, 2013.

- <span id="page-125-5"></span>[163] X.-B. Wang, T. Hiroshima, A. Tomita, and M. Hayashi. Quantum information with Gaussian states. *Physics Reports*, 448(1–4):1–111, 2007.
- <span id="page-125-14"></span>[164] J. Watrous. Lecture 2: Mathematical Preliminaries (Part 2), 2008. Latest version available at: <www.cs.uwaterloo.ca/~watrous/CS766/>.
- <span id="page-125-2"></span>[165] J. Watrous. *Encyclopedia of Complexity and System Science*, chapter Quantum Computational Complexity. Springer, 2009.
- <span id="page-125-3"></span>[166] T.-C. Wei, M. Mosca, and A. Nayak. Interacting boson problems can be QMA hard. *Physical Review Letters*, 104:040501, 2010.
- <span id="page-125-4"></span>[167] A. Weichselbaum, F Verstraete, U Schollwöck, J. I. Cirac, and J. von Delft. Variational matrix product state approach to quantum impurity models. *Physical Review B*, 80:165117, 2009.
- <span id="page-125-0"></span>[168] S. R. White. Density matrix formulation for quantum renormalization groups. *Physical Review Letters*, 69:2863–2866, 1992.
- <span id="page-125-1"></span>[169] S. R. White. Density-matrix algorithms for quantum renormalization groups. *Physical Review B*, 48:10345–10356, 1993.
- <span id="page-125-12"></span>[170] S. R. White and R. M. Noack. Real-space quantum renormalization groups. *Physical Review Letters*, 68:3487–3490, 1992.
- <span id="page-125-7"></span>[171] K. G. Wilson. Renormalization group and critical phenomena. I. Renormalization group and the kadanoff scaling picture. *Physical Review B*, 4:3174–3183, 1971.
- <span id="page-125-8"></span>[172] K. G. Wilson. Renormalization group and critical phenomena. II. Phasespace cell analysis of critical behavior. *Physical Review B*, 4:3184–3205, 1971.
- <span id="page-125-10"></span>[173] K. G. Wilson. Feynman-graph expansion for critical exponents. *Physical Review Letters*, 28:548–551, 1972.
- <span id="page-125-11"></span>[174] K. G. Wilson. The renormalization group: Critical phenomena and the kondo problem. *Reviews of Modern Physics*, 47:773–840, 1975.
- <span id="page-125-9"></span>[175] K. G. Wilson and M. E. Fisher. Critical exponents in 3.99 dimensions. *Physical Review Letters*, 28:240–243, 1972.
- <span id="page-125-13"></span>[176] M. M. Wolf. Violation of the entropic area law for fermions. *Physical Review Letters*, 96:010404, 2006.

<span id="page-126-3"></span>[177] M. M. Wolf, F. Verstraete, M. B. Hastings, and J. I. Cirac. Area laws in quantum systems: Mutual information and correlations. *Physical Review Letters*, 100:070502, 2008.

- <span id="page-126-0"></span>[178] J. Yan and D. Bacon. The k-local Pauli commuting Hamiltonians problem is in P. Available at arXiv.org e-Print quant-ph/1203.3906, 2012.
- <span id="page-126-1"></span>[179] C. N. Yang and C. P. Yang. One-dimensional chain of anisotropic spinspin interactions. I. Proof of Bethe's hypothesis for ground state in a finite system. *Physical Review*, 150:321–327, 1966.
- <span id="page-126-2"></span>[180] C. N. Yang and C. P. Yang. One-dimensional chain of anisotropic spinspin interactions. II. Properties of the ground-state energy per lattice site for an infinite system. *Physical Review*, 150:327–339, 1966.